// RakPeer -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 251 functions


// Address: 0x1039b651a | Name: __ZN6RakNet7RakPeer11AllocPacketEjPKcj
__int64 __fastcall RakNet::RakPeer::AllocPacket(
        RakNet::RakPeer *this,
        unsigned int a2,
        const char *a3,
        unsigned int a4)
{
  RakNet::SimpleMutex *v8; // r13
  __int64 v9; // r14
  unsigned __int64 v10; // rsi

  v8 = (RakNet::RakPeer *)((char *)this + 2688); /*0x1039b6533*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2688)); /*0x1039b653d*/
  v9 = DataStructures::MemoryPool<RakNet::Packet>::Allocate(a1: (__int64 *)this + 344, a2: (unsigned __int64)a3, a3: a4); /*0x1039b6557*/
  RakNet::SimpleMutex::Unlock(this: v8); /*0x1039b655d*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v9); /*0x1039b6565*/
  RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)(v9 + 32)); /*0x1039b656e*/
  *(_OWORD *)(v9 + 88) = 0; /*0x1039b6576*/
  *(_QWORD *)(v9 + 56) = RBX::Memory::allocateOrCrash(this: (RBX::Memory *)a2, a2: v10); /*0x1039b6582*/
  *(_DWORD *)(v9 + 48) = a2; /*0x1039b6586*/
  *(_DWORD *)(v9 + 52) = 8 * a2; /*0x1039b658d*/
  *(_BYTE *)(v9 + 64) = 1; /*0x1039b6591*/
  *(_QWORD *)(v9 + 32) = RakNet::UNASSIGNED_RAKNET_GUID; /*0x1039b659d*/
  *(_WORD *)(v9 + 40) = word_10CC85C98; /*0x1039b65a8*/
  *(_BYTE *)(v9 + 65) = 0; /*0x1039b65ad*/
  *(_QWORD *)(v9 + 96) = 0; /*0x1039b65b2*/
  return v9; /*0x1039b65c1*/
}

// Address: 0x1039b669a | Name: __ZN6RakNet7RakPeer11AllocPacketEjPhPKcj
__int64 __fastcall RakNet::RakPeer::AllocPacket(
        RakNet::RakPeer *this,
        int a2,
        unsigned __int8 *a3,
        const char *a4,
        unsigned int a5)
{
  RakNet::SimpleMutex *v9; // r14
  __int64 v10; // r15

  v9 = (RakNet::RakPeer *)((char *)this + 2688); /*0x1039b66b7*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2688)); /*0x1039b66c1*/
  v10 = DataStructures::MemoryPool<RakNet::Packet>::Allocate( /*0x1039b66db*/
          a1: (__int64 *)this + 344,
          a2: (unsigned __int64)a4,
          a3: a5);
  RakNet::SimpleMutex::Unlock(this: v9); /*0x1039b66e1*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v10); /*0x1039b66e9*/
  RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)(v10 + 32)); /*0x1039b66f2*/
  *(_QWORD *)(v10 + 88) = 0; /*0x1039b66f9*/
  *(_QWORD *)(v10 + 56) = a3; /*0x1039b6701*/
  *(_DWORD *)(v10 + 48) = a2; /*0x1039b6705*/
  *(_DWORD *)(v10 + 52) = 8 * a2; /*0x1039b670c*/
  *(_BYTE *)(v10 + 64) = 1; /*0x1039b6710*/
  *(_QWORD *)(v10 + 32) = RakNet::UNASSIGNED_RAKNET_GUID; /*0x1039b671c*/
  *(_WORD *)(v10 + 40) = word_10CC85C98; /*0x1039b6727*/
  *(_BYTE *)(v10 + 65) = 0; /*0x1039b672c*/
  *(_QWORD *)(v10 + 96) = 0; /*0x1039b6731*/
  return v10; /*0x1039b673c*/
}

// Address: 0x1039b6780 | Name: __ZN6RakNet7RakPeerC1Ev
__int64 __fastcall RakNet::RakPeer::RakPeer(RakNet::RakPeer *this)
{
  return RakNet::RakPeer::RakPeer(this); /*0x1039b6784*/
}

// Address: 0x1039b679c | Name: __ZN6RakNet7RakPeerC2Ev
__int64 __fastcall RakNet::RakPeer::RakPeer(RakNet::RakPeer *this)
{
  char *v2; // r12
  __int64 i; // r14
  WSAStartupSingleton *v4; // rdi
  __int64 v5; // r14
  RBX *v6; // rdi
  RakNet::SimpleMutex *v8; // [rsp+A8h] [rbp-58h]
  RakNet::SimpleMutex *v9; // [rsp+B0h] [rbp-50h]
  _DWORD v10[3]; // [rsp+C4h] [rbp-3Ch] BYREF
  _QWORD v11[6]; // [rsp+D0h] [rbp-30h] BYREF

  *(_QWORD *)this = off_10C902C50; /*0x1039b67c8*/
  *(_OWORD *)((char *)this + 8) = 0; /*0x1039b67ce*/
  *((_QWORD *)this + 3) = 0; /*0x1039b67d2*/
  *(_OWORD *)((char *)this + 36) = 0; /*0x1039b67da*/
  *(_OWORD *)((char *)this + 52) = 0; /*0x1039b67de*/
  *(_OWORD *)((char *)this + 68) = 0; /*0x1039b67e2*/
  *(_OWORD *)((char *)this + 84) = 0; /*0x1039b67e6*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::RakPeer *)((char *)this + 100)); /*0x1039b67ee*/
  *((_WORD *)this + 66) = 0; /*0x1039b67f3*/
  *((_BYTE *)this + 134) = -1; /*0x1039b67fc*/
  *((_BYTE *)this + 163) = 0; /*0x1039b6803*/
  *(_OWORD *)((char *)this + 136) = 0; /*0x1039b6814*/
  *((_QWORD *)this + 19) = 0; /*0x1039b681b*/
  RakNet::LocklessUint32_t::LocklessUint32_t(this: (RakNet::RakPeer *)((char *)this + 164)); /*0x1039b6826*/
  RakNet::BitStream::BitStream(this: (RakNet::RakPeer *)((char *)this + 176)); /*0x1039b6835*/
  *((_QWORD *)this + 101) = 0; /*0x1039b683a*/
  *(_OWORD *)((char *)this + 760) = 0; /*0x1039b6848*/
  *((_DWORD *)this + 194) = 0; /*0x1039b684f*/
  *((_DWORD *)this + 204) = 0x4000; /*0x1039b6859*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 824)); /*0x1039b6874*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 888)); /*0x1039b6883*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 968)); /*0x1039b6892*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 1032)); /*0x1039b68a8*/
  *(_OWORD *)((char *)this + 1112) = 0; /*0x1039b68b0*/
  *(_OWORD *)((char *)this + 1096) = 0; /*0x1039b68b7*/
  *((_DWORD *)this + 282) = 1065353216; /*0x1039b68be*/
  *((_OWORD *)this + 71) = 0; /*0x1039b68c8*/
  *((_DWORD *)this + 288) = 0; /*0x1039b68cf*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 1160)); /*0x1039b68ee*/
  RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::UnboundedCircularBuffer( /*0x1039b6906*/
    a1: (char *)this + 1224,
    a2: 8);
  RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::UnboundedCircularBuffer( /*0x1039b691e*/
    a1: (char *)this + 1256,
    a2: 8);
  boost::mutex::mutex(this: (pthread_mutex_t *)((char *)this + 1288)); /*0x1039b6931*/
  *((_QWORD *)this + 171) = 0; /*0x1039b6941*/
  *((_DWORD *)this + 344) = 0x4000; /*0x1039b694c*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 1384)); /*0x1039b6960*/
  *(_OWORD *)((char *)this + 1448) = 0; /*0x1039b696f*/
  *((_DWORD *)this + 366) = 0; /*0x1039b6976*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 1472)); /*0x1039b6987*/
  *((_QWORD *)this + 194) = 0; /*0x1039b6997*/
  *((_DWORD *)this + 390) = 0x4000; /*0x1039b69a2*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 1568)); /*0x1039b69b6*/
  *((_OWORD *)this + 102) = 0; /*0x1039b69c5*/
  *((_DWORD *)this + 412) = 0; /*0x1039b69cc*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 1656)); /*0x1039b69dd*/
  *((_QWORD *)this + 219) = 0; /*0x1039b69ed*/
  *(_OWORD *)((char *)this + 1720) = 0; /*0x1039b69fb*/
  *((_DWORD *)this + 440) = 0x4000; /*0x1039b6a02*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 1768)); /*0x1039b6a16*/
  *(_OWORD *)((char *)this + 1832) = 0; /*0x1039b6a25*/
  *((_DWORD *)this + 462) = 0; /*0x1039b6a2c*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 1856)); /*0x1039b6a3d*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 1920)); /*0x1039b6a4c*/
  *((_OWORD *)this + 124) = 0; /*0x1039b6a66*/
  *((_QWORD *)this + 250) = 0; /*0x1039b6a6d*/
  *(_OWORD *)((char *)this + 2024) = 0; /*0x1039b6a78*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::RakPeer *)((char *)this + 2048)); /*0x1039b6a86*/
  RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakPeer *)((char *)this + 2088)); /*0x1039b6a99*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::RakPeer *)((char *)this + 2112)); /*0x1039b6aa9*/
  *(_OWORD *)((char *)this + 2152) = 0; /*0x1039b6abf*/
  v2 = (char *)this + 2168; /*0x1039b6ac6*/
  for ( i = 0; i != 320; i += 32 ) /*0x1039b6acd*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)&v2[i]); /*0x1039b6ad4*/
  RBX::CEvent::CEvent(this: (RakNet::RakPeer *)((char *)this + 2512), a2: true); /*0x1039b6af5*/
  RBX::CEvent::CEvent(this: (RakNet::RakPeer *)((char *)this + 2536), a2: true); /*0x1039b6b14*/
  RakNet::SignaledEvent::SignaledEvent(this: (RakNet::RakPeer *)((char *)this + 2560)); /*0x1039b6b24*/
  v8 = (RakNet::RakPeer *)((char *)this + 2688); /*0x1039b6b30*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 2688)); /*0x1039b6b34*/
  *((_QWORD *)this + 346) = 0; /*0x1039b6b39*/
  *((_DWORD *)this + 694) = 0x4000; /*0x1039b6b44*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 2784)); /*0x1039b6b5c*/
  *((_OWORD *)this + 178) = 0; /*0x1039b6b64*/
  *((_DWORD *)this + 716) = 0; /*0x1039b6b6b*/
  *(_OWORD *)((char *)this + 2872) = 0; /*0x1039b6b75*/
  *(_OWORD *)((char *)this + 2888) = 0; /*0x1039b6b7c*/
  *((_DWORD *)this + 726) = 1065353216; /*0x1039b6b83*/
  v9 = (RakNet::RakPeer *)((char *)this + 2912); /*0x1039b6b94*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 2912)); /*0x1039b6b98*/
  *((_OWORD *)this + 190) = 0; /*0x1039b6ba0*/
  *((_QWORD *)this + 382) = 0; /*0x1039b6ba9*/
  *((_OWORD *)this + 192) = 0; /*0x1039b6bb7*/
  *(_OWORD *)((char *)this + 2984) = 0; /*0x1039b6bbe*/
  *(_OWORD *)((char *)this + 3000) = 0; /*0x1039b6bc5*/
  *(_OWORD *)((char *)this + 3016) = 0; /*0x1039b6bcc*/
  *((_DWORD *)this + 758) = 0; /*0x1039b6bd3*/
  *((_QWORD *)this + 383) = (char *)this + 3072; /*0x1039b6be4*/
  *(_OWORD *)((char *)this + 3128) = 0; /*0x1039b6beb*/
  *((_QWORD *)this + 398) = 0; /*0x1039b6bf2*/
  *((_OWORD *)this + 200) = 0; /*0x1039b6bf9*/
  *((_OWORD *)this + 201) = 0; /*0x1039b6c00*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 3232)); /*0x1039b6c15*/
  *((_OWORD *)this + 206) = 0; /*0x1039b6c24*/
  *((_QWORD *)this + 414) = 0; /*0x1039b6c2b*/
  RakNet::SimpleMutex::SimpleMutex(this: (RakNet::RakPeer *)((char *)this + 3320)); /*0x1039b6c3d*/
  *((_OWORD *)this + 212) = 0; /*0x1039b6c45*/
  *(_OWORD *)((char *)this + 3416) = 0; /*0x1039b6c4c*/
  *(_OWORD *)((char *)this + 3432) = 0; /*0x1039b6c53*/
  *((_QWORD *)this + 431) = 0; /*0x1039b6c5c*/
  *(_OWORD *)((char *)this + 3464) = 0; /*0x1039b6c63*/
  *((_DWORD *)this + 870) = 0; /*0x1039b6c6a*/
  *((_QWORD *)this + 436) = 0; /*0x1039b6c70*/
  *((_QWORD *)this + 437) = 0x7FFFFFFF00000000LL; /*0x1039b6c81*/
  *((_DWORD *)this + 876) = 0x80000000; /*0x1039b6c8d*/
  *((_BYTE *)this + 3508) = 0; /*0x1039b6c93*/
  *((_QWORD *)this + 439) = 0; /*0x1039b6c99*/
  *((_QWORD *)this + 440) = 0x7FFFFFFF00000000LL; /*0x1039b6ca0*/
  *((_DWORD *)this + 882) = 0x80000000; /*0x1039b6ca7*/
  *((_QWORD *)this + 444) = 0; /*0x1039b6cad*/
  *((_DWORD *)this + 890) = 0; /*0x1039b6cb4*/
  *((_OWORD *)this + 223) = 0; /*0x1039b6cba*/
  *(_OWORD *)((char *)this + 3580) = 0; /*0x1039b6cc1*/
  *((_DWORD *)this + 900) = 0; /*0x1039b6cc8*/
  *((_DWORD *)this + 927) = 0; /*0x1039b6cce*/
  *((_BYTE *)this + 3712) = 0; /*0x1039b6cd4*/
  *((_DWORD *)this + 929) = 0; /*0x1039b6cda*/
  *(_OWORD *)((char *)this + 3532) = 0; /*0x1039b6ce0*/
  *((_BYTE *)this + 3624) = 0; /*0x1039b6ce7*/
  *(_OWORD *)((char *)this + 3608) = 0; /*0x1039b6ced*/
  *(_OWORD *)((char *)this + 3689) = 0; /*0x1039b6cf4*/
  *((_OWORD *)this + 230) = 0; /*0x1039b6cfb*/
  *((_OWORD *)this + 229) = 0; /*0x1039b6d02*/
  *((_OWORD *)this + 228) = 0; /*0x1039b6d09*/
  *((_OWORD *)this + 227) = 0; /*0x1039b6d10*/
  *((_QWORD *)this + 465) = RBX::Subsystem<RBX::Network::NetworkTracer,true>::startup<RBX::SubsystemDefaultFactory<RBX::Network::NetworkTracer>>(); /*0x1039b6d1c*/
  *((_WORD *)this + 1864) = 1; /*0x1039b6d23*/
  WSAStartupSingleton::AddRef(this: v4); /*0x1039b6d2c*/
  v10[0] = DFInt::RakNetMtuValue1InBytes; /*0x1039b6d3b*/
  v10[1] = DFInt::RakNetMtuValue2InBytes; /*0x1039b6d44*/
  v10[2] = DFInt::RakNetMtuValue3InBytes; /*0x1039b6d4d*/
  std::vector<int>::__assign_with_size[abi:ne200100]<int const*,int const*>(a1: (char *)this + 1984, a2: v10, a3: v11); /*0x1039b6d5d*/
  *((_DWORD *)this + 502) = *(_DWORD *)(*((_QWORD *)this + 249) - 4LL); /*0x1039b6d6c*/
  v5 = 0; /*0x1039b6d72*/
  *((_BYTE *)this + 2012) = 0; /*0x1039b6d75*/
  *(_DWORD *)((char *)this + 170) = 0; /*0x1039b6d7c*/
  *((_OWORD *)this + 46) = 0; /*0x1039b6d86*/
  _InterlockedExchange((volatile __int32 *)this + 188, 0); /*0x1039b6d8f*/
  *((_QWORD *)this + 98) = 0; /*0x1039b6d95*/
  *(_QWORD *)((char *)this + 956) = 0; /*0x1039b6d9c*/
  *((_BYTE *)this + 162) = 1; /*0x1039b6da5*/
  *((_BYTE *)this + 160) = 1; /*0x1039b6dad*/
  *((_BYTE *)this + 161) = 0; /*0x1039b6db5*/
  *((_DWORD *)this + 189) = 0; /*0x1039b6dbb*/
  *((_DWORD *)this + 504) = 1; /*0x1039b6dc2*/
  *((_QWORD *)this + 423) = 0; /*0x1039b6dcc*/
  *((_BYTE *)this + 168) = 1; /*0x1039b6dd3*/
  *((_BYTE *)this + 2488) = 0; /*0x1039b6dda*/
  do /*0x1039b6dff*/
  {
    RakNet::SystemAddress::operator=(a1: &v2[v5], a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS); /*0x1039b6def*/
    v5 += 32; /*0x1039b6df4*/
  }
  while ( v5 != 320 ); /*0x1039b6dff*/
  *((_BYTE *)this + 2108) = 0; /*0x1039b6e03*/
  *((_BYTE *)this + 472) = 0; /*0x1039b6e09*/
  *((_QWORD *)this + 268) = 0x3E800000000LL; /*0x1039b6e19*/
  *((_DWORD *)this + 526) = 0; /*0x1039b6e20*/
  RakNet::SystemAddress::operator=(a1: (char *)this + 2112, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS); /*0x1039b6e35*/
  *((_QWORD *)this + 261) = RakNet::UNASSIGNED_RAKNET_GUID; /*0x1039b6e41*/
  *((_WORD *)this + 1048) = word_10CC85C98; /*0x1039b6e4f*/
  *((_OWORD *)this + 156) = 0; /*0x1039b6e59*/
  *((_DWORD *)this + 521) = DFInt::DefaultTimeoutTimeMs; /*0x1039b6e66*/
  *((_BYTE *)this + 3088) = 0; /*0x1039b6e6c*/
  *((_QWORD *)this + 390) = 0; /*0x1039b6e73*/
  *((_DWORD *)this + 440) = 128; /*0x1039b6e7e*/
  *((_DWORD *)this + 344) = 12608; /*0x1039b6e88*/
  RakNet::SimpleMutex::Lock(this: v8); /*0x1039b6e96*/
  *((_DWORD *)this + 694) = 3584; /*0x1039b6e9b*/
  RakNet::SimpleMutex::Unlock(this: v8); /*0x1039b6ea9*/
  *((_DWORD *)this + 204) = 768; /*0x1039b6eae*/
  *((_QWORD *)this + 261) = RBX::globalRand64(this: v6); /*0x1039b6ec4*/
  RakNet::SignaledEvent::InitEvent(this: (RakNet::RakPeer *)((char *)this + 2560)); /*0x1039b6ecb*/
  *((_BYTE *)this + 2680) = 0; /*0x1039b6ed0*/
  RakNet::SimpleMutex::Lock(this: v9); /*0x1039b6edb*/
  *((_DWORD *)this + 744) = 1; /*0x1039b6ee0*/
  RakNet::SimpleMutex::Unlock(this: v9); /*0x1039b6eee*/
  return __stack_chk_guard; /*0x1039b6f03*/
}

// Address: 0x1039b7382 | Name: __ZN6RakNet7RakPeer12GenerateGUIDEv
__int64 __fastcall RakNet::RakPeer::GenerateGUID(RakNet::RakPeer *this)
{
  __int64 result; // rax

  result = RBX::globalRand64(this); /*0x1039b738b*/
  *((_QWORD *)this + 261) = result; /*0x1039b7390*/
  return result; /*0x1039b739b*/
}

// Address: 0x1039b739e | Name: __ZN6RakNet7RakPeer16ResetSendReceiptEv
__int64 __fastcall RakNet::RakPeer::ResetSendReceipt(RakNet::RakPeer *this)
{
  RakNet::SimpleMutex *v2; // r14

  v2 = (RakNet::RakPeer *)((char *)this + 2912); /*0x1039b73a8*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2912)); /*0x1039b73b2*/
  *((_DWORD *)this + 744) = 1; /*0x1039b73b7*/
  return RakNet::SimpleMutex::Unlock(this: v2); /*0x1039b73c4*/
}

// Address: 0x1039b7488 | Name: __ZN6RakNet7RakPeerD2Ev
void __fastcall RakNet::RakPeer::~RakPeer(RakNet::RakPeer *this)
{
  WSAStartupSingleton *v2; // rdi
  __int64 v3; // rdi
  void *v4; // rdi
  __int64 v5; // rdi
  RakNet::RakPeer *v6; // rdi
  __int64 v7; // rax
  void *v8; // rdi
  void *v9; // rdi
  void *v10; // rdi
  void *v11; // rdi
  void *v12; // rdi
  void *v13; // rdi
  __int64 i; // r15
  void *v15; // rdi
  void *v16; // rdi

  *(_QWORD *)this = off_10C902C50; /*0x1039b749c*/
  RakNet::RakPeer::Shutdown(this); /*0x1039b749f*/
  (*(void (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 312LL))(a1: this); /*0x1039b74aa*/
  WSAStartupSingleton::Deref(this: v2); /*0x1039b74b0*/
  RakNet::SignaledEvent::CloseEvent(this: (RakNet::RakPeer *)((char *)this + 2560)); /*0x1039b74bf*/
  v3 = *((_QWORD *)this + 465); /*0x1039b74c4*/
  if ( v3 != 0 ) /*0x1039b74ce*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 16LL))(a1: v3); /*0x1039b74d3*/
  v4 = *((void **)this + 460); /*0x1039b74d6*/
  if ( v4 != nullptr ) /*0x1039b74e0*/
  {
    *((_QWORD *)this + 461) = v4; /*0x1039b74e2*/
    operator delete(a1: v4); /*0x1039b74e9*/
  }
  if ( (*((_BYTE *)this + 3656) & 1) != 0 ) /*0x1039b74f5*/
    operator delete(a1: *((void **)this + 459)); /*0x1039b74fe*/
  boost::circular_buffer<RakNet::RakPeer::TrackDroppedPackets::DroppedPktInfo,std::allocator<RakNet::RakPeer::TrackDroppedPackets::DroppedPktInfo>>::destroy(a1: (void **)this + 427); /*0x1039b750a*/
  std::shared_ptr<RBX::DownloadBandwidthTracker>::~shared_ptr[abi:ne200100](a1: (char *)this + 3392); /*0x1039b7516*/
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 3320); /*0x1039b7522*/
  v5 = *((_QWORD *)this + 414); /*0x1039b7527*/
  *((_QWORD *)this + 414) = 0; /*0x1039b752e*/
  if ( v5 != 0 ) /*0x1039b753c*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(a1: v5); /*0x1039b7541*/
  std::shared_ptr<RBX::Rupp::Rupp>::~shared_ptr[abi:ne200100](a1: (char *)this + 3296); /*0x1039b754b*/
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 3232); /*0x1039b7557*/
  v6 = *((RakNet::RakPeer **)this + 398); /*0x1039b7563*/
  if ( v6 == (RakNet::RakPeer *)((char *)this + 3152) ) /*0x1039b756d*/
  {
    v7 = 32; /*0x1039b757b*/
    goto LABEL_13; /*0x1039b757b*/
  }
  v7 = 40; /*0x1039b756f*/
  if ( v6 != nullptr ) /*0x1039b7577*/
LABEL_13:
    (*(void (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)v6 + v7))(a1: v6); /*0x1039b7580*/
  std::shared_ptr<RBX::Security::EarlyAuthData>::~shared_ptr[abi:ne200100](a1: (char *)this + 3128); /*0x1039b7586*/
  std::__tree<std::string>::destroy(a1: (__int64)this + 3064, a2: *((_QWORD **)this + 384)); /*0x1039b75a0*/
  if ( (*((_BYTE *)this + 3040) & 1) != 0 ) /*0x1039b75ac*/
    operator delete(a1: *((void **)this + 382)); /*0x1039b75b5*/
  if ( (*((_BYTE *)this + 3008) & 1) != 0 ) /*0x1039b75c1*/
    operator delete(a1: *((void **)this + 378)); /*0x1039b75ca*/
  if ( (*((_BYTE *)this + 2984) & 1) != 0 ) /*0x1039b75d6*/
    operator delete(a1: *((void **)this + 375)); /*0x1039b75df*/
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 2912); /*0x1039b75eb*/
  std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>::~__hash_table(a1: (char *)this + 2872); /*0x1039b75f7*/
  if ( *((_DWORD *)this + 716) != 0 ) /*0x1039b7603*/
  {
    v8 = *((void **)this + 356); /*0x1039b7605*/
    if ( v8 != nullptr ) /*0x1039b760f*/
      operator delete[](a1: v8); /*0x1039b7611*/
  }
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 2784); /*0x1039b761d*/
  DataStructures::MemoryPool<RakNet::Packet>::~MemoryPool(a1: (__int64)this + 2752); /*0x1039b7629*/
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 2688); /*0x1039b7635*/
  RakNet::SignaledEvent::~SignaledEvent(this: (RakNet::RakPeer *)((char *)this + 2560)); /*0x1039b763d*/
  RBX::CEvent::~CEvent(this: (RakNet::RakPeer *)((char *)this + 2536)); /*0x1039b7649*/
  RBX::CEvent::~CEvent(this: (RakNet::RakPeer *)((char *)this + 2512)); /*0x1039b7655*/
  DataStructures::List<RakNet::RakString>::~List(a1: (__int64 *)this + 269); /*0x1039b7661*/
  DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::~List(a1: (__int64 *)this + 253); /*0x1039b766d*/
  v9 = *((void **)this + 248); /*0x1039b7672*/
  if ( v9 != nullptr ) /*0x1039b767c*/
  {
    *((_QWORD *)this + 249) = v9; /*0x1039b767e*/
    operator delete(a1: v9); /*0x1039b7685*/
  }
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 1920); /*0x1039b7691*/
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 1856); /*0x1039b76a4*/
  if ( *((_DWORD *)this + 462) != 0 ) /*0x1039b76b0*/
  {
    v10 = *((void **)this + 229); /*0x1039b76b2*/
    if ( v10 != nullptr ) /*0x1039b76bc*/
      operator delete[](a1: v10); /*0x1039b76be*/
  }
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 1768); /*0x1039b76ca*/
  DataStructures::MemoryPool<RakNet::RakPeer::SocketQueryOutput>::~MemoryPool(a1: (__int64)this + 1736); /*0x1039b76d2*/
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 1656); /*0x1039b76e5*/
  if ( *((_DWORD *)this + 412) != 0 ) /*0x1039b76f1*/
  {
    v11 = *((void **)this + 204); /*0x1039b76f3*/
    if ( v11 != nullptr ) /*0x1039b76fd*/
      operator delete[](a1: v11); /*0x1039b76ff*/
  }
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 1568); /*0x1039b770b*/
  DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::~MemoryPool(a1: (__int64)this + 1536); /*0x1039b7713*/
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 1472); /*0x1039b7726*/
  if ( *((_DWORD *)this + 366) != 0 ) /*0x1039b7732*/
  {
    v12 = *((void **)this + 181); /*0x1039b7734*/
    if ( v12 != nullptr ) /*0x1039b773e*/
      operator delete[](a1: v12); /*0x1039b7740*/
  }
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 1384); /*0x1039b774c*/
  DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::~MemoryPool(a1: (__int64)this + 1352); /*0x1039b7754*/
  boost::mutex::~mutex(this: (pthread_mutex_t *)((char *)this + 1288)); /*0x1039b7760*/
  RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::~UnboundedCircularBuffer(a1: (char *)this + 1256); /*0x1039b776c*/
  RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::~UnboundedCircularBuffer(a1: (char *)this + 1224); /*0x1039b7778*/
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 1160); /*0x1039b7784*/
  if ( *((_DWORD *)this + 288) != 0 ) /*0x1039b7790*/
  {
    v13 = *((void **)this + 142); /*0x1039b7792*/
    if ( v13 != nullptr ) /*0x1039b779c*/
      operator delete[](a1: v13); /*0x1039b779e*/
  }
  std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>>>::~__hash_table(a1: (char *)this + 1096); /*0x1039b77aa*/
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 1032); /*0x1039b77b6*/
  RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + 968); /*0x1039b77c2*/
  for ( i = 0; i != -128; i -= 64 ) /*0x1039b77ce*/
    RakNet::SimpleMutex::~SimpleMutex(a1: (char *)this + i + 888); /*0x1039b77d5*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::~MemoryPool(a1: (__int64)this + 792); /*0x1039b77eb*/
  v15 = *((void **)this + 95); /*0x1039b77f0*/
  *((_QWORD *)this + 95) = 0; /*0x1039b77f7*/
  if ( v15 != nullptr ) /*0x1039b7805*/
    operator delete[](a1: v15); /*0x1039b7807*/
  RakNet::BitStream::~BitStream(this: (RakNet::RakPeer *)((char *)this + 176)); /*0x1039b7813*/
  v16 = *((void **)this + 1); /*0x1039b7818*/
  if ( v16 != nullptr ) /*0x1039b781f*/
  {
    *((_QWORD *)this + 2) = v16; /*0x1039b7821*/
    operator delete(a1: v16); /*0x1039b782f*/
  }
}

// Address: 0x1039b784a | Name: __ZN6RakNet7RakPeerD1Ev
void __fastcall RakNet::RakPeer::~RakPeer(RakNet::RakPeer *this)
{
  RakNet::RakPeer::~RakPeer(this); /*0x1039b784f*/
}

// Address: 0x1039b7854 | Name: __ZN6RakNet7RakPeerD0Ev
void __fastcall RakNet::RakPeer::~RakPeer(RakNet::RakPeer *this)
{
  RakNet::RakPeer::~RakPeer(this); /*0x1039b785d*/
  operator delete(a1: this); /*0x1039b786b*/
}

// Address: 0x1039b7870 | Name: __ZN6RakNet7RakPeer7StartupEtPN4FInt5ValueEPNS_16SocketDescriptorEjtti
__int64 __fastcall RakNet::RakPeer::Startup(
        RakNet::RakPeer *this,
        unsigned int a2,
        FInt::Value *a3,
        RakNet::SocketDescriptor *a4,
        unsigned int a5,
        int a6,
        unsigned __int16 a7,
        int a8)
{
  unsigned int v12; // r14d
  char v13; // al
  RakNet::SystemAddress *v14; // rsi
  int v15; // ecx
  unsigned __int16 *v16; // r13
  __int64 v17; // rbx
  RakNet::RakNetSocket *v18; // r15
  unsigned __int16 v19; // si
  addrinfo *v20; // rax
  unsigned __int16 v21; // r9
  addrinfo *v22; // r15
  int BoundSocket; // eax
  RakNet::SystemAddress *v24; // rdx
  RakNet::SocketLayer *v25; // rdi
  int v26; // r12d
  int v27; // r15d
  RakNet::SocketLayer *v28; // rdi
  int v29; // r12d
  int v30; // r15d
  __int64 v31; // r12
  int v32; // r14d
  __int64 v33; // r15
  unsigned __int16 Port; // ax
  __int64 v35; // rdi
  std::__shared_weak_count *v36; // r15
  RakNet::RakPeer *v37; // rbx
  unsigned int v38; // r12d
  int v39; // ecx
  __int64 v40; // r13
  __int64 v41; // rax
  RakNet::SystemAddress *v42; // rcx
  __int64 v43; // rax
  __int64 v44; // rbx
  RakNet::RakPeer *v45; // rax
  void *v46; // rdi
  __int64 v47; // rax
  __int64 v48; // r15
  RakNet::RakPeer *v49; // rcx
  _BYTE *v50; // rsi
  unsigned int v51; // r15d
  __int64 v52; // r15
  unsigned __int64 v53; // r13
  __int64 v54; // rcx
  unsigned __int64 v55; // rax
  __int64 v56; // rax
  __int64 v57; // rcx
  __int64 v58; // rax
  __int64 v60; // [rsp+18h] [rbp-6A8h]
  char *v61; // [rsp+20h] [rbp-6A0h]
  unsigned __int16 v62; // [rsp+3Ch] [rbp-684h]
  unsigned __int16 v63; // [rsp+48h] [rbp-678h]
  _DWORD v64[3]; // [rsp+4Ch] [rbp-674h] BYREF
  std::__shared_weak_count *v65; // [rsp+58h] [rbp-668h]
  RakNet::RakPeer *v66; // [rsp+60h] [rbp-660h]
  int v67; // [rsp+6Ch] [rbp-654h]
  RakNet::SystemAddress *v68; // [rsp+70h] [rbp-650h]
  unsigned int v69; // [rsp+7Ch] [rbp-644h]
  char v70[16]; // [rsp+80h] [rbp-640h] BYREF
  void *v71; // [rsp+90h] [rbp-630h]
  _BYTE v72[512]; // [rsp+490h] [rbp-230h] BYREF

  v67 = a6; /*0x1039b7884*/
  v63 = a2; /*0x1039b7894*/
  v12 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::RakNet, a2); /*0x1039b78b6*/
  v13 = (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 128LL))(a1: this); /*0x1039b78bf*/
  LODWORD(v68) = 1; /*0x1039b78c5*/
  if ( v13 == 0 )
  {
    v15 = 1000; /*0x1039b78df*/
    if ( a8 != -99999 ) /*0x1039b78e4*/
      v15 = a8; /*0x1039b78e4*/
    v64[0] = v15; /*0x1039b78e7*/
    RakNet::SocketLayer::GetMyIP(this: (RakNet::RakPeer *)((char *)this + 2168), a2: v14); /*0x1039b78f4*/
    LODWORD(v68) = 2; /*0x1039b7907*/
    if ( a4 != nullptr && a5 != 0 )
    {
      if ( a5 != 1
        && DFFlag::RakNetDisablePollAndSelect != 0
        && (unsigned __int8)FLog::Network >= 6u
        && BYTE1(FLog::Network) >= 3u )
      {
        *(_QWORD *)&v64[1] = a5; /*0x1039b7957*/
        *(_QWORD *)v70 = 2; /*0x1039b795a*/
        *(_QWORD *)&v70[8] = &v64[1]; /*0x1039b7965*/
        FLog::detail::FastLogSafeFormattedInternal(
          a1: FLog::Network,
          a2: qword_10D7BBAA8,
          a3: 3,
          a4: (unsigned int)"[FLog::Network] WARNING: {} sockets are being initialized, while DFFlag::RakNetDisablePollAndSel"
                        "ect is enabled.\n"
                        "\t* Recvmsg() will block on the first socket waiting for messages, even if other sockets have me"
                        "ssages in their queue.\n"
                        "\t* If your use-case requires more than one socket, for latency reasons, you may consider disabl"
                        "ing DFFlag::RakNetDisablePollAndSelect and enabling DFFlag::RakNetEnableLinuxEPoll.\n"
                        "\t* Note that disabling DFFlag::RakNetDisablePollAndSelect will increase the number of syscalls "
                        "per received packet by (at least) 1.",
          a5: 540,
          a6: 1,
          2,
          &v64[1]);
      }
      *((_QWORD *)this + 426) = a3; /*0x1039b7994*/
      if ( v63 != 0 )
      {
        v69 = v12; /*0x1039b79aa*/
        RakNet::RakPeer::DerefAllSockets(this); /*0x1039b79c2*/
        v66 = this; /*0x1039b79c7*/
        v61 = (char *)this + 2024; /*0x1039b79d5*/
        v60 = a5; /*0x1039b79df*/
        v16 = (unsigned __int16 *)((char *)a4 + 48); /*0x1039b79e6*/
        v17 = 0; /*0x1039b79ea*/
        v62 = v67; /*0x1039b79f3*/
        v67 = 0; /*0x1039b7a03*/
        do
        {
          v18 = (RakNet::RakNetSocket *)operator new(a1: 0x2Cu); /*0x1039b7a17*/
          RakNet::RakNetSocket::RakNetSocket(this: v18); /*0x1039b7a1d*/
          std::shared_ptr<RakNet::RakNetSocket>::shared_ptr[abi:ne200100]<RakNet::RakNetSocket,0>(a1: &v64[1], a2: v18); /*0x1039b7a2c*/
          v20 = (addrinfo *)RakNet::SocketLayer::GetAddrInfoAllocate(this: (RakNet::SocketLayer *)*v16, a2: v19); /*0x1039b7a36*/
          v22 = v20; /*0x1039b7a3b*/
          if ( v20 != nullptr )
          {
            BoundSocket = RakNet::SocketLayer::CreateBoundSocket( /*0x1039b7a60*/
                            this: v20,
                            a2: (addrinfo *)*(v16 - 24),
                            a3: v62,
                            a4: a7,
                            a5: *v16,
                            a6: v21);
            **(_DWORD **)&v64[1] = BoundSocket; /*0x1039b7a6c*/
            freeaddrinfo(a1: v22); /*0x1039b7a71*/
            ++v67; /*0x1039b7a76*/
            if ( **(_DWORD **)&v64[1] == -1 )
            {
              RakNet::RakPeer::DerefAllSockets(this: v66); /*0x1039b7c86*/
              LODWORD(v68) = 6; /*0x1039b7c8b*/
              v32 = 1; /*0x1039b7c95*/
            }
            else
            {
              if ( DFInt::RakNetSocketSendTimeoutMs > 0
                && (unsigned __int8)RakNet::SocketLayer::SetSocketSendTimeout() == 0 )
              {
                v26 = FLog::Network; /*0x1039b7ab2*/
                if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
                {
                  v27 = qword_10D7BBAA8; /*0x1039b7ad2*/
                  RakNet::SocketLayer::GetLastSystemError(this: v25); /*0x1039b7ad6*/
                  std::error_code::message(this: (std::error_code *)v70); /*0x1039b7af9*/
                  FLog::FastLogSafeFormatted<std::string>(
                    a1: v26,
                    a2: v27,
                    a3: 3,
                    a4: (int)"[FLog::Network] RakNet: failed to set send timeout on socket: {}",
                    a5: 64,
                    a6: (unsigned __int8 *)v70);
                  if ( (v70[0] & 1) != 0 ) /*0x1039b7b25*/
                    operator delete(a1: v71); /*0x1039b7b2e*/
                }
              }
              if ( DFInt::RakNetSocketRecvTimeoutMs > 0
                && (unsigned __int8)RakNet::SocketLayer::SetSocketRecvTimeout(a1: (unsigned int)**(_DWORD **)&v64[1]) == 0 )
              {
                v29 = FLog::Network; /*0x1039b7b60*/
                if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
                {
                  v30 = qword_10D7BBAA8; /*0x1039b7b80*/
                  RakNet::SocketLayer::GetLastSystemError(this: v28); /*0x1039b7b84*/
                  std::error_code::message(this: (std::error_code *)v70); /*0x1039b7ba7*/
                  FLog::FastLogSafeFormatted<std::string>(
                    a1: v29,
                    a2: v30,
                    a3: 3,
                    a4: (int)"[FLog::Network] RakNet: failed to set recv timeout on socket: {}",
                    a5: 64,
                    a6: (unsigned __int8 *)v70);
                  if ( (v70[0] & 1) != 0 ) /*0x1039b7bd3*/
                    operator delete(a1: v71); /*0x1039b7bdc*/
                }
              }
              RakNet::SocketLayer::GetSystemAddress( /*0x1039b7bee*/
                this: (RakNet::SocketLayer *)(unsigned int)**(_DWORD **)&v64[1],
                a2: v64[1] + 8,
                a3: v24);
              if ( DFInt::FirstValidPort <= (unsigned __int16)RakNet::SystemAddress::GetPort(this: (RakNet::SystemAddress *)(*(_QWORD *)&v64[1] + 8LL)) )
              {
                v35 = *(_QWORD *)&v64[1]; /*0x1039b7ca0*/
                *(_DWORD *)(*(_QWORD *)&v64[1] + 4LL) = v17; /*0x1039b7ca7*/
                RakNet::SystemAddress::ToStringN( /*0x1039b7cc8*/
                  this: (RakNet::SystemAddress *)(v35 + 8),
                  a2: true,
                  a3: v70,
                  a4: 1025,
                  a5: 124);
                if ( (unsigned __int8)DFLog::NetworkAudit >= 6u && BYTE1(DFLog::NetworkAudit) >= 3u )
                  FLog::FastLog(
                    a1: DFLog::NetworkAudit,
                    a2: qword_10D783528,
                    a3: "[DFLog::NetworkAudit] RakNet Socket Open: %s",
                    v70);
                v32 = 0; /*0x1039b7d06*/
                DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::Insert( /*0x1039b7d20*/
                  a1: (__int64)v61,
                  a2: (__int64)&v64[1]);
              }
              else
              {
                v31 = FLog::Network; /*0x1039b7c19*/
                LODWORD(v68) = 11; /*0x1039b7c2e*/
                v32 = 1; /*0x1039b7c38*/
                if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
                {
                  v33 = qword_10D7BBAA8; /*0x1039b7c46*/
                  Port = RakNet::SystemAddress::GetPort(this: (RakNet::SystemAddress *)(*(_QWORD *)&v64[1] + 8LL)); /*0x1039b7c55*/
                  FLog::FastLog(
                    a1: v31,
                    a2: v33,
                    a3: "[FLog::Network] RakNet Socket bound to invalid (privileged) port: %u",
                    Port);
                }
              }
            }
          }
          else
          {
            v32 = 6; /*0x1039b7c74*/
          }
          v36 = v65; /*0x1039b7d25*/
          if ( v65 != nullptr /*0x1039b7d41*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v65 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v36 + 16LL))(a1: v36); /*0x1039b7d49*/
            std::__shared_weak_count::__release_weak(this: v36); /*0x1039b7d4f*/
          }
          if ( v32 != 6 && v32 != 0 ) /*0x1039b7d5d*/
          {
            v12 = v69; /*0x1039b7e41*/
            goto LABEL_76; /*0x1039b7e48*/
          }
          ++v17; /*0x1039b7d63*/
          v16 += 25; /*0x1039b7d66*/
        }
        while ( v60 != v17 );
        v37 = v66; /*0x1039b7d77*/
        v12 = v69; /*0x1039b7d86*/
        v38 = v67; /*0x1039b7d8d*/
        if ( *((_WORD *)v66 + 85) == 0 ) /*0x1039b7d94*/
        {
          if ( *((_WORD *)v66 + 86) > v63 ) /*0x1039b7e69*/
            *((_WORD *)v66 + 86) = v63; /*0x1039b7e6b*/
          *((_WORD *)v37 + 85) = v63; /*0x1039b7e72*/
          *((_QWORD *)v37 + 92) = RakNet::OP_NEW_ARRAY<RakNet::RakPeer::RemoteSystemStruct>(a1: v63, a2: "", a3: 0); /*0x1039b7e8d*/
          v40 = *((unsigned __int16 *)v37 + 85); /*0x1039b7e94*/
          if ( *((_WORD *)v37 + 85) != 0 ) /*0x1039b7e9f*/
          {
            *((_QWORD *)v37 + 98) = operator new[](a1: (unsigned int)((_DWORD)v40 << 6)); /*0x1039b7eac*/
            v41 = operator new[](a1: (unsigned int)(8 * v40)); /*0x1039b7ebb*/
            v42 = (RakNet::RakPeer *)((char *)v37 + 784); /*0x1039b7ec0*/
          }
          else
          {
            v42 = (RakNet::RakPeer *)((char *)v37 + 784); /*0x1039b7f15*/
            *((_QWORD *)v37 + 98) = 0; /*0x1039b7f1c*/
            v41 = 0; /*0x1039b7f27*/
          }
          *((_QWORD *)v37 + 93) = v41; /*0x1039b7f29*/
          if ( DFFlag::DebugNetworkProfiler == 1 && DFFlag::DebugNetworkProfilerRakPeer == 1 ) /*0x1039b7f4a*/
          {
            v68 = v42; /*0x1039b7f50*/
            v44 = operator new[](a1: 4176 * v40); /*0x1039b7f66*/
            if ( (_WORD)v40 != 0 ) /*0x1039b7f6d*/
              __bzero(a1: v44, a2: 4176 * ((4176 * v40 - 4176) / 0x1050uLL) + 4176); /*0x1039b7f9b*/
            v45 = v66; /*0x1039b7fa0*/
            v46 = *((void **)v66 + 95); /*0x1039b7fa7*/
            *((_QWORD *)v66 + 95) = v44; /*0x1039b7fae*/
            v37 = v45; /*0x1039b7fb5*/
            if ( v46 != nullptr ) /*0x1039b7fbb*/
            {
              operator delete[](a1: v46); /*0x1039b7fc1*/
              LOWORD(v40) = *((_WORD *)v37 + 85); /*0x1039b7fc6*/
              v47 = (unsigned __int16)v40; /*0x1039b7fce*/
            }
            else
            {
              v47 = v40; /*0x1039b8060*/
            }
            v42 = v68; /*0x1039b8063*/
            *((_QWORD *)v37 + 96) = v47; /*0x1039b806a*/
          }
          if ( (_WORD)v40 != 0 ) /*0x1039b8075*/
          {
            v68 = v42; /*0x1039b807b*/
            v52 = 0; /*0x1039b808c*/
            v53 = 0; /*0x1039b808f*/
            do /*0x1039b8143*/
            {
              *(_BYTE *)(*((_QWORD *)v37 + 92) + v52) = 0; /*0x1039b809b*/
              RakNet::SystemAddress::operator=( /*0x1039b80b1*/
                a1: *((_QWORD *)v37 + 92) + v52 + 4,
                a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS);
              v54 = *((_QWORD *)v37 + 92) + v52; /*0x1039b80bd*/
              *(_QWORD *)(v54 + 5200) = RakNet::UNASSIGNED_RAKNET_GUID; /*0x1039b80c8*/
              *(_WORD *)(v54 + 5208) = word_10CC85C98; /*0x1039b80d7*/
              *(_DWORD *)(v54 + 5364) = 0; /*0x1039b80e0*/
              *(_DWORD *)(v54 + 5216) = *((_DWORD *)v37 + 502); /*0x1039b80ee*/
              *(_WORD *)(v54 + 5248) = v53; /*0x1039b80f6*/
              *(_DWORD *)(v54 + 5252) = 0; /*0x1039b80ff*/
              *(_QWORD *)(v54 + 5256) = 0; /*0x1039b8107*/
              *(_QWORD *)(v54 + 4536) = v37; /*0x1039b8113*/
              *(_BYTE *)(v54 + 5265) = 9; /*0x1039b811b*/
              *(_QWORD *)(*((_QWORD *)v37 + 93) + 8 * v53++) = v54; /*0x1039b812b*/
              v55 = *((unsigned __int16 *)v37 + 85); /*0x1039b8132*/
              v52 += 5368; /*0x1039b8139*/
            }
            while ( v53 < v55 ); /*0x1039b8143*/
            v12 = v69; /*0x1039b814c*/
            v38 = v67; /*0x1039b8153*/
            v14 = v68; /*0x1039b815a*/
            if ( *((_WORD *)v37 + 85) != 0 ) /*0x1039b8161*/
            {
              v56 = (unsigned int)((_DWORD)v55 << 6); /*0x1039b8167*/
              v57 = 0; /*0x1039b816a*/
              do /*0x1039b817e*/
              {
                *(_QWORD *)(*(_QWORD *)v14 + v57) = 0; /*0x1039b816f*/
                v57 += 8; /*0x1039b8177*/
              }
              while ( v56 != v57 ); /*0x1039b817e*/
            }
          }
        }
        if ( v38 != 0 ) /*0x1039b7d9d*/
        {
          if ( (*((_BYTE *)v37 + 160) & 1) != 0 ) /*0x1039b7dab*/
          {
            *((_BYTE *)v37 + 952) = 0; /*0x1039b7db3*/
            *((_BYTE *)v37 + 160) = 0; /*0x1039b7dbb*/
            *((_BYTE *)v37 + 162) = 0; /*0x1039b7dc1*/
            RakNet::RakPeer::ClearBufferedCommands(this: v37); /*0x1039b7dca*/
            DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Clear( /*0x1039b7ddf*/
              a1: (__int64)v37 + 1352,
              a2: "");
            DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Clear( /*0x1039b7df4*/
              a1: (__int64)v37 + 1536,
              a2: "");
            DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Clear( /*0x1039b7e09*/
              a1: (__int64)v37 + 1736,
              a2: "");
            if ( (*((_BYTE *)v37 + 161) & 1) == 0 ) /*0x1039b7e16*/
            {
              if ( (unsigned int)RakNet::RakThread::Create( /*0x1039b7ef7*/
                                   this: (RakNet::RakThread *)RakNet::UpdateNetworkLoop,
                                   a2: (void *(__fastcall *)(void *))v37,
                                   a3: (void *)v64[0],
                                   a4: v39) != 0 )
              {
                v43 = *(_QWORD *)v37; /*0x1039b7efd*/
                LODWORD(v68) = 9; /*0x1039b7f00*/
                (*(void (__fastcall **)(RakNet::RakPeer *))(v43 + 120))(a1: v37); /*0x1039b7f0d*/
                goto LABEL_76; /*0x1039b7f10*/
              }
              v48 = 0; /*0x1039b7fde*/
              do /*0x1039b802e*/
              {
                v49 = v66; /*0x1039b7fef*/
                v50 = &v72[v48]; /*0x1039b8007*/
                *(_DWORD *)v50 = **(_DWORD **)(*((_QWORD *)v66 + 253) + v48); /*0x1039b800e*/
                *((_QWORD *)v50 + 1) = v49; /*0x1039b8010*/
                if ( (unsigned int)RakNet::RakThread::Create( /*0x1039b8021*/
                                     this: (RakNet::RakThread *)RakNet::RecvFromLoop,
                                     a2: (void *(__fastcall *)(void *))&v72[v48],
                                     a3: (void *)v64[0],
                                     a4: (int)v49) != 0 )
                {
                  v58 = *(_QWORD *)v66; /*0x1039b818c*/
                  LODWORD(v68) = 9; /*0x1039b818f*/
                  v12 = v69; /*0x1039b8199*/
                  (*(void (__fastcall **)(RakNet::RakPeer *))(v58 + 120))(a1: v66); /*0x1039b81a0*/
                  goto LABEL_76; /*0x1039b81a0*/
                }
                v48 += 16; /*0x1039b8027*/
              }
              while ( 16LL * v38 != v48 ); /*0x1039b802e*/
              v12 = v69; /*0x1039b8030*/
              v37 = v66; /*0x1039b8037*/
              v51 = v67; /*0x1039b803e*/
              while ( *((_DWORD *)v37 + 41) < v51 ) /*0x1039b804e*/
                RakSleep(a1: 0xAu); /*0x1039b8059*/
            }
            while ( (*((_BYTE *)v37 + 161) & 1) == 0 ) /*0x1039b7e24*/
              RakSleep(a1: 0xAu); /*0x1039b7e2b*/
          }
          LODWORD(v68) = 0; /*0x1039b7e4d*/
        }
        else
        {
          RakNet::RakPeer::DerefAllSockets(this: v37); /*0x1039b7ecc*/
          LODWORD(v68) = 7; /*0x1039b7ed1*/
        }
      }
      else
      {
        LODWORD(v68) = 3; /*0x1039b7e32*/
      }
    }
  }
LABEL_76:
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v12, a2: (unsigned int)v14); /*0x1039b81a3*/
  return (unsigned int)v68; /*0x1039b81c1*/
}

// Address: 0x1039b825c | Name: __ZN6RakNet7RakPeer15DerefAllSocketsEv
void __fastcall RakNet::RakPeer::DerefAllSockets(RakNet::RakPeer *this)
{
  __int64 *v1; // rbx
  __int64 v3; // r15
  unsigned __int64 v4; // r12

  v1 = (__int64 *)((char *)this + 2024); /*0x1039b8267*/
  if ( *((_DWORD *)this + 508) != 0 ) /*0x1039b8275*/
  {
    v3 = 0; /*0x1039b827a*/
    v4 = 0; /*0x1039b827d*/
    do /*0x1039b82a0*/
    {
      std::shared_ptr<RakNet::RakNetSocket>::reset[abi:ne200100](a1: v3 + *((_QWORD *)this + 253)); /*0x1039b828a*/
      ++v4; /*0x1039b828f*/
      v3 += 16; /*0x1039b8299*/
    }
    while ( v4 < *((unsigned int *)this + 508) ); /*0x1039b82a0*/
  }
  DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::Clear(a1: v1, a2: 0); /*0x1039b82b8*/
}

// Address: 0x1039b837c | Name: __ZN6RakNet7RakPeer21ClearBufferedCommandsEv
int __fastcall RakNet::RakPeer::ClearBufferedCommands(RakNet::RakPeer *this)
{
  pthread_mutex_t *v2; // rbx
  void *v3; // rsi
  _QWORD *v4; // r15
  RBX::Network::NetworkTracer *v5; // rdi
  RBX::Memory *v6; // rdi
  unsigned __int64 v7; // rsi
  unsigned __int64 v8; // rtt
  __int64 v9; // rdi

  v2 = (pthread_mutex_t *)((char *)this + 1288); /*0x1039b8389*/
  boost::mutex::lock(this: (pthread_mutex_t *)((char *)this + 1288)); /*0x1039b8393*/
  if ( *((_QWORD *)this + 156) != 0 ) /*0x1039b83a0*/
  {
    do /*0x1039b844a*/
    {
      v4 = (_QWORD *)(*((_QWORD *)this + 153) + 160LL * (*((_QWORD *)this + 155) % *((_QWORD *)this + 154))); /*0x1039b83be*/
      if ( DFFlag::DataPingTrace == 1 ) /*0x1039b83cc*/
      {
        v3 = (void *)v4[19]; /*0x1039b83ce*/
        if ( v3 != nullptr ) /*0x1039b83d8*/
        {
          if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039b83e4*/
            v5 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039b83e6*/
          else
            v5 = nullptr; /*0x1039b83ec*/
          RBX::Network::NetworkTracer::removeTracerObject(this: v5, a2: (unsigned __int64)v3); /*0x1039b83ee*/
        }
      }
      v6 = (RBX::Memory *)v4[13]; /*0x1039b83f3*/
      if ( v6 != nullptr && *v4 == 0 ) /*0x1039b8400*/
        RBX::Memory::deallocate(this: v6, a2: v3); /*0x1039b8402*/
      v7 = *((_QWORD *)this + 154); /*0x1039b8407*/
      v8 = *((_QWORD *)this + 155); /*0x1039b841a*/
      v9 = *((_QWORD *)this + 153) + 160 * (v8 % v7); /*0x1039b8425*/
      *((_QWORD *)this + 155) = (v8 + 1) % v7; /*0x1039b8437*/
      std::shared_ptr<RBX::NetworkCore::AbstractBitStream const>::~shared_ptr[abi:ne200100](a1: v9); /*0x1039b843e*/
    }
    while ( (*((_QWORD *)this + 156))-- != 1 ); /*0x1039b844a*/
  }
  return boost::mutex::unlock(this: v2); /*0x1039b8457*/
}

// Address: 0x1039b8462 | Name: __ZN6RakNet7RakPeer20ClearBufferedPacketsEv
__int64 __fastcall RakNet::RakPeer::ClearBufferedPackets(RakNet::RakPeer *this)
{
  DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Clear(a1: (__int64)this + 1352, a2: ""); /*0x1039b847f*/
  return DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Clear(a1: (__int64)this + 1536, a2: ""); /*0x1039b8493*/
}

// Address: 0x1039b849c | Name: __ZN6RakNet7RakPeer22ClearSocketQueryOutputEv
__int64 __fastcall RakNet::RakPeer::ClearSocketQueryOutput(RakNet::RakPeer *this)
{
  return DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Clear( /*0x1039b84b0*/
           a1: (__int64)this + 1736,
           a2: "");
}

// Address: 0x1039b8c8a | Name: __ZN6RakNet7RakPeer18InitializeSecurityEPKcS2_b
__int64 __fastcall RakNet::RakPeer::InitializeSecurity(RakNet::RakPeer *this, const char *a2, const char *a3)
{
  return 0; /*0x1039b8c90*/
}

// Address: 0x1039b8c92 | Name: __ZN6RakNet7RakPeer15DisableSecurityEv
void __fastcall RakNet::RakPeer::DisableSecurity(RakNet::RakPeer *this)
{
  ; /*0x1039b8c92*/
}

// Address: 0x1039b8c98 | Name: __ZN6RakNet7RakPeer26AddToSecurityExceptionListEPKc
__int64 __fastcall RakNet::RakPeer::AddToSecurityExceptionList(RakNet::RakPeer *this, const char *a2)
{
  RakNet::SimpleMutex *v4; // rbx
  _BYTE v6[40]; // [rsp+8h] [rbp-28h] BYREF

  v4 = (RakNet::RakPeer *)((char *)this + 1920); /*0x1039b8cad*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1920)); /*0x1039b8cb7*/
  RakNet::RakString::RakString(this: (RakNet::RakString *)v6, a2); /*0x1039b8ccf*/
  DataStructures::List<RakNet::RakString>::Insert(a1: (__int64)this + 2152, a2: (__int64)v6, a3: (__int64)"", a4: 0); /*0x1039b8ce3*/
  RakNet::RakString::~RakString(this: (RakNet::RakString *)v6); /*0x1039b8cec*/
  return RakNet::SimpleMutex::Unlock(this: v4); /*0x1039b8cf9*/
}

// Address: 0x1039b8de6 | Name: __ZN6RakNet7RakPeer31RemoveFromSecurityExceptionListEPKc
void __fastcall RakNet::RakPeer::RemoveFromSecurityExceptionList(RakNet::RakPeer *this, const char *a2)
{
  __int64 *v4; // r12
  unsigned int v5; // r13d
  RakNet::SimpleMutex *v6; // [rsp-38h] [rbp-38h]

  if ( *((_DWORD *)this + 540) != 0 ) /*0x1039b8ded*/
  {
    v4 = (__int64 *)((char *)this + 2152); /*0x1039b8e07*/
    v6 = (RakNet::RakPeer *)((char *)this + 1920); /*0x1039b8e15*/
    RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1920)); /*0x1039b8e19*/
    if ( a2 != nullptr ) /*0x1039b8e21*/
    {
      if ( *((_DWORD *)this + 540) != 0 ) /*0x1039b8e2b*/
      {
        v5 = 0; /*0x1039b8e2d*/
        do /*0x1039b8e85*/
        {
          if ( (unsigned __int8)RakNet::RakString::IPAddressMatch(this: (RakNet::RakString *)(*v4 + 8LL * v5), a2) != 0 ) /*0x1039b8e49*/
          {
            RakNet::RakString::operator=( /*0x1039b8e63*/
              a1: *((_QWORD *)this + 269) + 8LL * v5,
              a2: *((_QWORD *)this + 269) + 8LL * (unsigned int)(*((_DWORD *)this + 540) - 1));
            DataStructures::List<RakNet::RakString>::RemoveAtIndex(a1: (__int64)v4, a2: *((_DWORD *)this + 540) - 1); /*0x1039b8e74*/
          }
          else
          {
            ++v5; /*0x1039b8e7b*/
          }
        }
        while ( v5 < *((_DWORD *)this + 540) ); /*0x1039b8e85*/
      }
    }
    else
    {
      DataStructures::List<RakNet::RakString>::Clear(a1: v4, a2: 0); /*0x1039b8e98*/
    }
    RakNet::SimpleMutex::Unlock(this: v6); /*0x1039b8eaf*/
  }
}

// Address: 0x1039b8f7e | Name: __ZN6RakNet7RakPeer25IsInSecurityExceptionListEPKc
__int64 __fastcall RakNet::RakPeer::IsInSecurityExceptionList(RakNet::RakPeer *this, const char *a2)
{
  __int64 v4; // r13
  unsigned __int64 v5; // rbx
  unsigned int v6; // r12d
  RakNet::SimpleMutex *v8; // [rsp+0h] [rbp-30h]

  if ( *((_DWORD *)this + 540) != 0 ) /*0x1039b8f93*/
  {
    v8 = (RakNet::RakPeer *)((char *)this + 1920); /*0x1039b8fa2*/
    RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1920)); /*0x1039b8fa6*/
    if ( *((_DWORD *)this + 540) != 0 ) /*0x1039b8fb3*/
    {
      v4 = 0; /*0x1039b8fb5*/
      v5 = 0; /*0x1039b8fb8*/
      do /*0x1039b8fe4*/
      {
        v6 = RakNet::RakString::IPAddressMatch(this: (RakNet::RakString *)(v4 + *((_QWORD *)this + 269)), a2); /*0x1039b8fcc*/
        if ( (_BYTE)v6 != 0 ) /*0x1039b8fd1*/
          break; /*0x1039b8fd1*/
        ++v5; /*0x1039b8fd3*/
        v4 += 8; /*0x1039b8fdd*/
      }
      while ( v5 < *((unsigned int *)this + 540) ); /*0x1039b8fe4*/
    }
    else
    {
      v6 = 0; /*0x1039b8fed*/
    }
    RakNet::SimpleMutex::Unlock(this: v8); /*0x1039b8ff4*/
  }
  else
  {
    return 0; /*0x1039b8fe8*/
  }
  return v6; /*0x1039b9000*/
}

// Address: 0x1039b900c | Name: __ZN6RakNet7RakPeer20InitBandwidthTrackerEv
__int64 __fastcall RakNet::RakPeer::InitBandwidthTracker(RakNet::RakPeer *this)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  std::__shared_weak_count *v4; // rbx
  __int64 v5; // rax
  int v6; // esi
  __int64 v7; // rdx
  __int64 v8; // rcx
  _QWORD v10[4]; // [rsp+8h] [rbp-2E8h] BYREF
  _QWORD v11[4]; // [rsp+28h] [rbp-2C8h] BYREF
  _BYTE v12[16]; // [rsp+48h] [rbp-2A8h] BYREF
  void *v13; // [rsp+58h] [rbp-298h]
  __int128 v14; // [rsp+60h] [rbp-290h] BYREF
  void *v15; // [rsp+70h] [rbp-280h]
  int v16; // [rsp+78h] [rbp-278h]
  int v17; // [rsp+7Ch] [rbp-274h]
  __int128 v18; // [rsp+80h] [rbp-270h] BYREF
  void *v19; // [rsp+90h] [rbp-260h]
  void *v20[3]; // [rsp+A0h] [rbp-250h] BYREF
  void *v21[9]; // [rsp+B8h] [rbp-238h] BYREF
  _BYTE v22[472]; // [rsp+100h] [rbp-1F0h] BYREF

  if ( *((_QWORD *)this + 424) == 0 ) /*0x1039b9030*/
  {
    v14 = 0; /*0x1039b903d*/
    v15 = nullptr; /*0x1039b9047*/
    v18 = 0; /*0x1039b904e*/
    v19 = nullptr; /*0x1039b9056*/
    RBX::FileSystem::getCacheDirectory(this: (RBX::FileSystem *)v12, a2: true, a3: "raknet"); /*0x1039b9070*/
    std::string::basic_string[abi:ne200100]<0>(a1: v21, a2: "raknet", a3: v2, a4: v3); /*0x1039b9083*/
    v10[0] = reportComputedBwStats; /*0x1039b90a9*/
    v10[3] = (char *)RBX::unique_function<void ()(double,unsigned long long),24ul,8ul,true>::unique_function<void (*)(double,unsigned long long)>(void (*)(double,unsigned long long))::Callback /*0x1039b90b3*/
           + 2;
    v11[0] = reportExpBwCountStats; /*0x1039b90c5*/
    v11[3] = (char *)&RBX::unique_function<void ()(int),24ul,8ul,true>::unique_function<void (*)(int)>(void (*)(int))::Callback /*0x1039b90cf*/
           + 2;
    RBX::DownloadBandwidthTracker::create( /*0x1039b90fa*/
      a1: (unsigned int)v20,
      a2: (unsigned int)v21,
      a3: (unsigned int)v12,
      a4: (unsigned int)&DFString::RaknetDownloadBandwidthCacheFileName,
      a5: (unsigned int)&v14,
      a6: (unsigned int)v10,
      a7: (__int64)v11);
    std::shared_ptr<RBX::DownloadBandwidthTracker>::operator=[abi:ne200100](a1: (char *)this + 3392, a2: v20); /*0x1039b9113*/
    v4 = (std::__shared_weak_count *)v20[1]; /*0x1039b9118*/
    if ( v20[1] != nullptr /*0x1039b9131*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v20[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(a1: v4); /*0x1039b9139*/
      std::__shared_weak_count::__release_weak(this: v4); /*0x1039b913f*/
    }
    RBX::unique_function<void ()(int),24ul,8ul,true>::~unique_function(a1: v11); /*0x1039b914b*/
    RBX::unique_function<void ()(double,unsigned long long),24ul,8ul,true>::~unique_function(a1: v10); /*0x1039b9157*/
    if ( ((__int64)v21[0] & 1) != 0 ) /*0x1039b9163*/
      operator delete(a1: v21[2]); /*0x1039b916c*/
    if ( (v14 & 1) != 0 ) /*0x1039b917a*/
      v5 = *((_QWORD *)&v14 + 1); /*0x1039b917c*/
    else
      v5 = (unsigned __int8)v14 >> 1; /*0x1039b9185*/
    if ( v5 != 0 ) /*0x1039b918a*/
    {
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1039b919e*/
        a1: v21,
        a2: (__int64)&RBX::Telemetry::kDownloadBandwidthNetworkIdNotFound);
      RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v21); /*0x1039b91aa*/
      RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v22); /*0x1039b91c1*/
      RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v21, a2: (void **)off_10C8C7EB0); /*0x1039b91d4*/
      if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x1039b91e6*/
                              this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::DownloadBandwidthNetworkIdFailInfluxHundredthsPercentage,
                              a2: v6) != 0 )
      {
        RBX::Analytics::InfluxDb::Points::Points( /*0x1039b91fd*/
          a1: v21,
          a2: (unsigned int)DFInt::DownloadBandwidthNetworkIdFailInfluxHundredthsPercentage,
          a3: 0,
          a4: 0);
        RBX::Analytics::InfluxDb::Points::addPoint(a1: v21, a2: "NetworkIdNotFoundFailedSyscall", a3: &v14); /*0x1039b9217*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039b9230*/
          this: (RBX::Analytics::InfluxDb::Points *)v21,
          a2: "NetworkIdNotFoundSyscallReturnValue",
          a3: v16);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039b9249*/
          this: (RBX::Analytics::InfluxDb::Points *)v21,
          a2: "NetworkIdNotFoundErrno",
          a3: v17);
        RBX::Analytics::InfluxDb::Points::addPoint(a1: v21, a2: "NetworkIdNotFoundErrData", a3: &v18); /*0x1039b9263*/
        std::string::basic_string[abi:ne200100]<0>(a1: v20, a2: "DownloadBandwidthNetworkId", a3: v7, a4: v8); /*0x1039b9276*/
        RBX::Analytics::InfluxDb::Points::report(a1: v21, a2: v20, a3: 10000, a4: 0); /*0x1039b9290*/
        if ( ((__int64)v20[0] & 1) != 0 ) /*0x1039b929c*/
          operator delete(a1: v20[2]); /*0x1039b92a5*/
        RBX::Analytics::InfluxDb::Points::~Points(this: v21); /*0x1039b92b1*/
      }
    }
    if ( (v12[0] & 1) != 0 ) /*0x1039b92bd*/
      operator delete(a1: v13); /*0x1039b92c6*/
    if ( (v18 & 1) != 0 ) /*0x1039b92d2*/
      operator delete(a1: v19); /*0x1039b92db*/
    if ( (v14 & 1) != 0 ) /*0x1039b92e7*/
      operator delete(a1: v15); /*0x1039b92f0*/
  }
  return __stack_chk_guard; /*0x1039b9305*/
}

// Address: 0x1039b9984 | Name: __ZN6RakNet7RakPeer29SetMaximumIncomingConnectionsEt
void __fastcall RakNet::RakPeer::SetMaximumIncomingConnections(RakNet::RakPeer *this, __int16 a2)
{
  *((_WORD *)this + 86) = a2; /*0x1039b9988*/
}

// Address: 0x1039b9992 | Name: __ZNK6RakNet7RakPeer29GetMaximumIncomingConnectionsEv
__int64 __fastcall RakNet::RakPeer::GetMaximumIncomingConnections(RakNet::RakPeer *this)
{
  return *((unsigned __int16 *)this + 86); /*0x1039b999d*/
}

// Address: 0x1039b99a0 | Name: __ZNK6RakNet7RakPeer19NumberOfConnectionsEv
__int64 __fastcall RakNet::RakPeer::NumberOfConnections(RakNet::RakPeer *this)
{
  unsigned __int16 v1; // bx
  __int128 v3; // [rsp+0h] [rbp-30h] BYREF
  __int128 v4; // [rsp+10h] [rbp-20h] BYREF

  v4 = 0; /*0x1039b99b0*/
  v3 = 0; /*0x1039b99b7*/
  (*(void (__fastcall **)(RakNet::RakPeer *, __int128 *, __int128 *))(*(_QWORD *)this + 296LL))( /*0x1039b99bd*/
    a1: this,
    a2: &v4,
    a3: &v3);
  v1 = WORD4(v4); /*0x1039b99c3*/
  if ( HIDWORD(v3) != 0 && (_QWORD)v3 != 0 ) /*0x1039b99d3*/
    operator delete[](a1: (void *)v3); /*0x1039b99d5*/
  if ( HIDWORD(v4) != 0 && (_QWORD)v4 != 0 ) /*0x1039b99e7*/
    operator delete[](a1: (void *)v4); /*0x1039b99e9*/
  return v1; /*0x1039b99f1*/
}

// Address: 0x1039b9a2c | Name: __ZN6RakNet7RakPeer19SetIncomingPasswordEPKci
__int64 __fastcall RakNet::RakPeer::SetIncomingPassword(RakNet::RakPeer *this, const char *a2, int a3)
{
  __int64 result; // rax
  int v5; // r14d

  result = 255; /*0x1039b9a36*/
  if ( a3 < 255 ) /*0x1039b9a3d*/
    result = (unsigned int)a3; /*0x1039b9a3d*/
  v5 = 0; /*0x1039b9a40*/
  if ( a2 != nullptr ) /*0x1039b9a46*/
    v5 = result; /*0x1039b9a46*/
  if ( v5 > 0 ) /*0x1039b9a4d*/
    result = (__int64)memcpy(__dst: (char *)this + 473, __src: a2, __n: (unsigned int)v5); /*0x1039b9a59*/
  *((_BYTE *)this + 472) = v5; /*0x1039b9a5e*/
  return result; /*0x1039b9a65*/
}

// Address: 0x1039b9a6a | Name: __ZN6RakNet7RakPeer19GetIncomingPasswordEPcPi
RakNet::RakPeer *__fastcall RakNet::RakPeer::GetIncomingPassword(RakNet::RakPeer *this, char *a2, int *a3)
{
  RakNet::RakPeer *result; // rax
  int v4; // ecx
  int v5; // edi

  result = this; /*0x1039b9a6e*/
  if ( a2 != nullptr ) /*0x1039b9a74*/
  {
    v4 = *a3; /*0x1039b9a76*/
    v5 = *((unsigned __int8 *)this + 472); /*0x1039b9a78*/
    if ( *a3 > v5 ) /*0x1039b9a81*/
    {
      *a3 = v5; /*0x1039b9a83*/
      v4 = v5; /*0x1039b9a85*/
    }
    if ( v4 > 0 ) /*0x1039b9a89*/
      return (RakNet::RakPeer *)memcpy(__dst: a2, __src: (char *)result + 473, __n: (unsigned int)v4); /*0x1039b9a9a*/
  }
  else
  {
    result = (RakNet::RakPeer *)*((unsigned __int8 *)this + 472); /*0x1039b9a9f*/
    *a3 = (int)result; /*0x1039b9aa6*/
  }
  return result; /*0x1039b9a99*/
}

// Address: 0x1039b9aaa | Name: __ZN6RakNet7RakPeer14SetDefaultRuppERNSt3__110shared_ptrIN3RBX4Rupp4RuppEEE
__int64 __fastcall RakNet::RakPeer::SetDefaultRupp(__int64 a1)
{
  return std::shared_ptr<RBX::Rupp::Rupp>::operator=[abi:ne200100](a1: a1 + 3296); /*0x1039b9ab5*/
}

// Address: 0x1039b9b0e | Name: __ZN6RakNet7RakPeer7ConnectEPKctS2_iPNS_9PublicKeyEjjjj
__int64 __fastcall RakNet::RakPeer::Connect(
        __int64 a1,
        __int64 a2,
        unsigned __int16 a3,
        __int64 a4,
        int a5,
        __int64 a6,
        unsigned int a7,
        unsigned int a8,
        unsigned int a9,
        unsigned int a10)
{
  __int64 v15; // rcx
  __int64 v16; // r11
  __int64 v17; // r10
  __int64 v18; // r9
  __int64 v19; // rdx
  __int64 v20; // r15
  int v21; // eax
  unsigned int v22; // r13d
  unsigned __int16 v24; // [rsp+0h] [rbp-2Ch]

  if ( DFFlag::SetIsServerInRakPeerConnect == 1 ) /*0x1039b9b32*/
    (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 984LL))(a1, a2: 0); /*0x1039b9b3d*/
  if ( a2 == 0 ) /*0x1039b9b46*/
    return 1; /*0x1039b9b46*/
  if ( (*(_BYTE *)(a1 + 160) & 1) != 0 ) /*0x1039b9b56*/
    return 1; /*0x1039b9b56*/
  v15 = *(unsigned int *)(a1 + 2032); /*0x1039b9b5f*/
  if ( (unsigned int)v15 <= a7 ) /*0x1039b9b69*/
    return 1; /*0x1039b9c26*/
  v24 = a3; /*0x1039b9b6f*/
  v16 = a10; /*0x1039b9b73*/
  v17 = a9; /*0x1039b9b77*/
  v18 = a8; /*0x1039b9b7b*/
  v19 = *(_QWORD *)(a1 + 2024); /*0x1039b9b7f*/
  v20 = 0; /*0x1039b9b87*/
  while ( *(_DWORD *)(*(_QWORD *)v19 + 4LL) != a7 ) /*0x1039b9b90*/
  {
    ++v20; /*0x1039b9b92*/
    v19 += 16; /*0x1039b9b95*/
    if ( v15 == v20 ) /*0x1039b9b9c*/
    {
      v20 = 0xFFFFFFFFLL; /*0x1039b9b9e*/
      break; /*0x1039b9b9e*/
    }
  }
  v21 = 255; /*0x1039b9ba4*/
  if ( a5 < 255 ) /*0x1039b9bac*/
    v21 = a5; /*0x1039b9bac*/
  v22 = 0; /*0x1039b9bb0*/
  if ( a4 != 0 ) /*0x1039b9bb6*/
    v22 = v21; /*0x1039b9bb6*/
  if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
  {
    FLog::FastLogFormatted(
      a1: (_DWORD)DFLog::RakNetConnectTrace,
      a2: qword_10D7BB0C8,
      a3: (unsigned int)"[DFLog::RakNetConnectTrace] RakNet: Connect requested with attempt count %u , time between attempts %u",
      a4: a8,
      a5: a9,
      a6: a8);
    v16 = a10; /*0x1039b9bf1*/
    v17 = a9; /*0x1039b9bf5*/
    v18 = a8; /*0x1039b9bf9*/
  }
  return RakNet::RakPeer::SendConnectionRequest( /*0x1039b9c2f*/
           a1,
           a2,
           a3: v24,
           a4,
           a5: v22,
           a6: v18,
           a7: v20,
           a8: 0,
           a9: v18,
           a10: v17,
           a11: v16);
}

// Address: 0x1039b9c3a | Name: __ZNK6RakNet7RakPeer44GetRakNetSocketFromUserConnectionSocketIndexEj
__int64 __fastcall RakNet::RakPeer::GetRakNetSocketFromUserConnectionSocketIndex(RakNet::RakPeer *this, int a2)
{
  __int64 v2; // rcx
  __int64 result; // rax
  __int64 v4; // rdi
  __int64 v5; // rdx

  v2 = *((unsigned int *)this + 508); /*0x1039b9c3a*/
  result = 0xFFFFFFFFLL; /*0x1039b9c40*/
  if ( *((_DWORD *)this + 508) != 0 ) /*0x1039b9c48*/
  {
    v4 = *((_QWORD *)this + 253); /*0x1039b9c4e*/
    v5 = 0; /*0x1039b9c55*/
    while ( *(_DWORD *)(*(_QWORD *)v4 + 4LL) != a2 ) /*0x1039b9c5e*/
    {
      ++v5; /*0x1039b9c60*/
      v4 += 16; /*0x1039b9c63*/
      if ( v2 == v5 ) /*0x1039b9c6a*/
        return result; /*0x1039b9c6a*/
    }
    return (unsigned int)v5; /*0x1039b9c6e*/
  }
  return result; /*0x1039b9c71*/
}

// Address: 0x1039b9c72 | Name: __ZN6RakNet7RakPeer21SendConnectionRequestEPKctS2_iPNS_9PublicKeyEjjjjj
__int64 __fastcall RakNet::RakPeer::SendConnectionRequest(
        __int64 a1,
        const char *a2,
        unsigned __int16 a3,
        const void *a4,
        int a5,
        __int64 a6,
        int a7,
        int a8,
        int a9,
        int a10,
        int a11)
{
  char v16; // al
  __int64 v17; // r8
  __int64 v18; // r9
  unsigned int v19; // r14d
  __int64 v20; // r14
  RakNet *v21; // rdi
  RBX::Security::SessionCrypto *v22; // r15
  int v23; // r8d
  int v24; // r9d
  unsigned int v25; // r13d
  unsigned int v26; // eax
  unsigned int v27; // ecx
  unsigned int v28; // edx
  unsigned int v29; // edx
  char v30; // al
  _QWORD v32[5]; // [rsp+20h] [rbp-4D0h] BYREF
  _QWORD v33[4]; // [rsp+48h] [rbp-4A8h] BYREF
  __int64 v34; // [rsp+68h] [rbp-488h] BYREF
  void *v35[3]; // [rsp+70h] [rbp-480h] BYREF
  int v36; // [rsp+88h] [rbp-468h]
  __int64 v37; // [rsp+90h] [rbp-460h]
  __int64 v38; // [rsp+98h] [rbp-458h]
  __int64 v39; // [rsp+A0h] [rbp-450h]
  RakNet::SimpleMutex *v40; // [rsp+A8h] [rbp-448h]
  char v41[1040]; // [rsp+B0h] [rbp-440h] BYREF

  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v33); /*0x1039b9caa*/
  v16 = RakNet::SystemAddress::FromStringExplicitPort(this: (RakNet::SystemAddress *)v33, a2, a3); /*0x1039b9cbd*/
  v19 = 2; /*0x1039b9cc2*/
  if ( v16 != 0 )
  {
    v19 = 3; /*0x1039b9cfb*/
    if ( RakNet::RakPeer::GetRemoteSystemFromSystemAddress(
           a1,
           a2: 0,
           a3: 1,
           a4: 0xFFFFFFFFLL,
           a5: v17,
           a6: v18,
           a7: v33[0],
           a8: v33[1],
           a9: v33[2],
           a10: v33[3]) == 0 )
    {
      v20 = operator new(a1: 0x180u); /*0x1039b9d14*/
      RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v20); /*0x1039b9d1a*/
      *(_BYTE *)(v20 + 324) = 0; /*0x1039b9d1f*/
      *(_OWORD *)(v20 + 344) = 0; /*0x1039b9d2a*/
      *(_OWORD *)(v20 + 360) = 0; /*0x1039b9d32*/
      v34 = v20; /*0x1039b9d3a*/
      RakNet::SystemAddress::operator=(a1: v20, a2: v33); /*0x1039b9d4b*/
      *(_QWORD *)(v20 + 32) = (unsigned int)RakNet::GetTimeMS(this: v21); /*0x1039b9d67*/
      *(_BYTE *)(v20 + 40) = 0; /*0x1039b9d6b*/
      *(_QWORD *)(v20 + 48) = 0; /*0x1039b9d70*/
      *(_DWORD *)(v20 + 320) = a8; /*0x1039b9d78*/
      *(_DWORD *)(v20 + 316) = a7; /*0x1039b9d7f*/
      *(_DWORD *)(v20 + 380) = 1; /*0x1039b9d86*/
      *(_DWORD *)(v20 + 328) = a9; /*0x1039b9d91*/
      *(_DWORD *)(v20 + 332) = a10; /*0x1039b9d98*/
      memcpy(__dst: (void *)(v20 + 58), __src: a4, __n: a5); /*0x1039b9dac*/
      *(_BYTE *)(v20 + 314) = a5; /*0x1039b9db1*/
      *(_DWORD *)(v20 + 336) = a11; /*0x1039b9db8*/
      v22 = (RBX::Security::SessionCrypto *)operator new(a1: 0x80u); /*0x1039b9dc9*/
      RBX::Security::SessionCrypto::SessionCrypto(this: v22); /*0x1039b9dcf*/
      *(_QWORD *)v22 = off_10C903070; /*0x1039b9ddb*/
      std::shared_ptr<RBX::Security::RakPeerCrypto>::reset[abi:ne200100]<RBX::Security::RakPeerCrypto,0>( /*0x1039b9deb*/
        a1: v20 + 360,
        a2: v22);
      RBX::Security::RakPeerCrypto::getClientKeyInfo( /*0x1039b9dfe*/
        this: (RBX::Security::RakPeerCrypto *)v35,
        a2: *(_BYTE *)(a1 + 3088));
      RBX::Security::RakPeerCrypto::initClient(this: *(RBX::Security::SessionCrypto **)(v20 + 360)); /*0x1039b9e18*/
      v38 = v20 + 360; /*0x1039b9e1d*/
      *(_DWORD *)(v20 + 376) = v36; /*0x1039b9e2a*/
      v40 = (RakNet::SimpleMutex *)(a1 + 1160); /*0x1039b9e38*/
      RakNet::SimpleMutex::Lock(this: (RakNet::SimpleMutex *)(a1 + 1160)); /*0x1039b9e3f*/
      v39 = v20 + 344; /*0x1039b9e4d*/
      v37 = a1 + 1136; /*0x1039b9e5b*/
      v25 = 0; /*0x1039b9e6c*/
      while ( 1 ) /*0x1039b9e6f*/
      {
        v26 = *(_DWORD *)(a1 + 1144); /*0x1039b9e6f*/
        v27 = *(_DWORD *)(a1 + 1148); /*0x1039b9e75*/
        v28 = v27 - v26; /*0x1039b9e7d*/
        if ( v27 < v26 ) /*0x1039b9e7f*/
        {
          v27 = *(_DWORD *)(a1 + 1152) + v27 - v26; /*0x1039b9e83*/
          v28 = v27; /*0x1039b9e89*/
        }
        if ( v25 >= v28 ) /*0x1039b9e8e*/
          break; /*0x1039b9e8e*/
        v29 = *(_DWORD *)(a1 + 1152); /*0x1039b9e94*/
        if ( v26 + v25 < v29 ) /*0x1039b9e9c*/
          v29 = 0; /*0x1039b9e9c*/
        v30 = RakNet::SystemAddress::operator==( /*0x1039b9eb3*/
                a1: *(_QWORD *)(*(_QWORD *)(a1 + 1136) + 8LL * (v25 + v26 - v29)),
                a2: v33);
        ++v25; /*0x1039b9eb8*/
        if ( v30 != 0 ) /*0x1039b9ebd*/
        {
          RakNet::SimpleMutex::Unlock(this: v40); /*0x1039b9ec6*/
          std::shared_ptr<RBX::Security::RakPeerCrypto>::~shared_ptr[abi:ne200100](a1: v38); /*0x1039b9ed2*/
          std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: v39); /*0x1039b9ede*/
          operator delete(a1: (void *)v20); /*0x1039b9ee6*/
          v19 = 4; /*0x1039b9eeb*/
          goto LABEL_17; /*0x1039b9ef1*/
        }
      }
      if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
      {
        LOBYTE(v27) = (unsigned __int8)DFLog::RakNetConnectTrace < 6u; /*0x1039b9f06*/
        FLog::FastLogFormatted(
          a1: (_DWORD)DFLog::RakNetConnectTrace,
          a2: qword_10D7BB0C8,
          a3: (unsigned int)"[DFLog::RakNetConnectTrace] RakNet: Added connect request to queue",
          a4: v27,
          a5: v23,
          a6: v24);
      }
      DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push(a1: v37, a2: &v34); /*0x1039b9f3e*/
      RakNet::SimpleMutex::Unlock(this: v40); /*0x1039b9f4a*/
      v19 = 0; /*0x1039b9f4f*/
      if ( (_BYTE)DFLog::RakNetConnectTrace != 0 && DFFlag::DebugRakNetConnectTracePrintRcsSystemAddress == 1 )
      {
        RakNet::SystemAddress::ToStringN(this: (RakNet::SystemAddress *)v33, a2: true, a3: v41, a4: 1025, a5: 124); /*0x1039b9f8d*/
        if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
        {
          v32[0] = v41; /*0x1039b9fbc*/
          v32[3] = 12; /*0x1039b9fbf*/
          v32[4] = v32; /*0x1039b9fca*/
          FLog::detail::FastLogSafeFormattedInternal(
            a1: (_DWORD)DFLog::RakNetConnectTrace,
            a2: qword_10D7BB0C8,
            a3: 3,
            a4: (unsigned int)"[DFLog::RakNetConnectTrace] RCS was added for: {}",
            a5: 49,
            a6: 1,
            12,
            v32);
        }
      }
LABEL_17:
      if ( v35[0] != nullptr ) /*0x1039ba003*/
      {
        v35[1] = v35[0]; /*0x1039ba005*/
        operator delete(a1: v35[0]); /*0x1039ba00c*/
      }
    }
  }
  return v19; /*0x1039ba024*/
}

// Address: 0x1039ba07a | Name: __ZN6RakNet7RakPeer27notifyAllAndFlagForShutdownEh14PacketPriority
char __fastcall RakNet::RakPeer::notifyAllAndFlagForShutdown(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        int a5,
        int a6)
{
  __int64 v7; // r14
  unsigned __int64 v8; // r15
  char result; // al
  __int64 v10; // rcx
  __int64 v11; // rax

  if ( *(_WORD *)(a1 + 170) == 0 ) /*0x1039ba082*/
    return 0; /*0x1039ba10f*/
  v7 = 0; /*0x1039ba098*/
  v8 = 0; /*0x1039ba09b*/
  result = 0; /*0x1039ba09e*/
  do /*0x1039ba101*/
  {
    v10 = *(_QWORD *)(a1 + 736); /*0x1039ba0a0*/
    LOBYTE(v10) = *(_BYTE *)(v10 + v7); /*0x1039ba0a7*/
    if ( (v10 & 1) != 0 ) /*0x1039ba0ae*/
    {
      v11 = *(_QWORD *)(a1 + 736); /*0x1039ba0b0*/
      RakNet::RakPeer::NotifyAndFlagForShutdown( /*0x1039ba0e6*/
        a1,
        a2: 1,
        a3: 0,
        a4: v10,
        a5,
        a6,
        *(_QWORD *)(v11 + v7 + 4),
        *(_QWORD *)(v11 + v7 + 12),
        *(_QWORD *)(v11 + v7 + 20),
        *(_QWORD *)(v11 + v7 + 28),
        *(_QWORD *)(v11 + v7 + 4),
        *(_QWORD *)(v11 + v7 + 12),
        *(_QWORD *)(v11 + v7 + 20),
        *(_QWORD *)(v11 + v7 + 28));
      result = 1; /*0x1039ba0eb*/
    }
    ++v8; /*0x1039ba0ed*/
    v7 += 5368; /*0x1039ba0f7*/
  }
  while ( v8 < *(unsigned __int16 *)(a1 + 170) ); /*0x1039ba101*/
  return result; /*0x1039ba113*/
}

// Address: 0x1039ba114 | Name: __ZN6RakNet7RakPeer24NotifyAndFlagForShutdownENS_13SystemAddressEbh14PacketPriorityPKcj
__int64 __fastcall RakNet::RakPeer::NotifyAndFlagForShutdown(
        RakNet::RakPeer *a1,
        char a2,
        _DWORD a3,
        _DWORD a4,
        _DWORD a5,
        _DWORD a6,
        __int128 a7,
        __int128 a8)
{
  int v10; // r8d
  int v11; // r9d
  unsigned int v12; // ecx
  int v13; // r12d
  int v14; // r15d
  bool v15; // si
  unsigned __int64 TimeUS; // rax
  unsigned int RemoteSystemIndex; // eax
  __int64 v18; // rax
  __int64 v19; // rcx
  RakNet::BitStream *v21; // rdi
  unsigned __int8 v22[60]; // [rsp+40h] [rbp-1A0h] BYREF
  unsigned __int8 v23[4]; // [rsp+7Ch] [rbp-164h] BYREF
  RakNet::RakPeer *v24; // [rsp+80h] [rbp-160h]
  _BYTE v25[12]; // [rsp+88h] [rbp-158h] BYREF
  int v26; // [rsp+94h] [rbp-14Ch]
  __int64 v27; // [rsp+A0h] [rbp-140h]

  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v25, a2: 1u); /*0x1039ba148*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
    FLog::FastLogFormatted(
      a1: FLog::Network,
      a2: qword_10D7BBAA8,
      a3: (unsigned int)"[FLog::Network] Sending disconnect with reason: %d",
      a4: *((_DWORD *)a1 + 504),
      a5: v10,
      a6: v11);
  v22[0] = 21; /*0x1039ba18c*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v25, a2: v22, a3: 8u, a4: true); /*0x1039ba1a0*/
  *(_DWORD *)v23 = *((_DWORD *)a1 + 504); /*0x1039ba1ab*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039ba3b3*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v21); /*0x1039ba3be*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039ba3cb*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ba1c6*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v25, a2: v23, a3: 0x20u, a4: true); /*0x1039ba1e0*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v23, a2: v22, a3: (unsigned __int8 *)4, a4: v12); /*0x1039ba1fa*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v25, a2: v22, a3: 0x20u, a4: true); /*0x1039ba217*/
  }
  v24 = a1; /*0x1039ba21c*/
  v13 = v27; /*0x1039ba227*/
  v14 = v26; /*0x1039ba22e*/
  if ( a2 != 0 ) /*0x1039ba238*/
  {
    RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v22, a2: (const RakNet::SystemAddress *)&a7); /*0x1039ba24b*/
    TimeUS = RakNet::GetTimeUS(this: nullptr, a2: v15); /*0x1039ba254*/
    RakNet::RakPeer::SendImmediate( /*0x1039ba296*/
      a1: (_DWORD)v24,
      a2: v13,
      a3: v14,
      a4: 0,
      a5: 1,
      a6: 3,
      a7: (__int64)v22,
      a8: 0,
      a9: 0,
      a10: TimeUS,
      a11: 0,
      a12: 0,
      a13: 0);
    *(_OWORD *)&v22[16] = a8; /*0x1039ba2ac*/
    *(_OWORD *)v22 = a7; /*0x1039ba2b0*/
    if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: v22, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) == 0 ) /*0x1039ba2c1*/
    {
      RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this: v24, a2: (const RakNet::SystemAddress *)v22); /*0x1039ba2d5*/
      if ( RemoteSystemIndex != -1 ) /*0x1039ba2dd*/
      {
        v18 = 5368LL * RemoteSystemIndex; /*0x1039ba2f3*/
        if ( (*(_BYTE *)(*((_QWORD *)v24 + 92) + v18) & 1) != 0 ) /*0x1039ba300*/
        {
          v19 = *((_QWORD *)v24 + 92); /*0x1039ba309*/
          if ( v19 != 0 ) /*0x1039ba313*/
            *(_DWORD *)(v19 + v18 + 5364) = 1; /*0x1039ba315*/
        }
      }
    }
  }
  else
  {
    RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v22, a2: (const RakNet::SystemAddress *)&a7); /*0x1039ba32f*/
    RakNet::RakPeer::SendBuffered( /*0x1039ba372*/
      a1: (_DWORD)v24,
      a2: v13,
      a3: v14,
      a4: 2,
      a5: 3,
      a6: 0,
      a7: (__int64)v22,
      a8: 0,
      a9: 1,
      a10: 0,
      a11: 0,
      a12: 0);
  }
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v25); /*0x1039ba37e*/
  return __stack_chk_guard; /*0x1039ba393*/
}

// Address: 0x1039ba40e | Name: __ZN6RakNet7RakPeer21resetRemoteSystemListEv
unsigned __int64 __fastcall RakNet::RakPeer::resetRemoteSystemList(RakNet::RakPeer *this)
{
  __int64 v2; // r14
  unsigned __int64 v3; // r15
  unsigned __int64 result; // rax

  if ( *((_WORD *)this + 85) != 0 ) /*0x1039ba423*/
  {
    v2 = 5232; /*0x1039ba425*/
    v3 = 0; /*0x1039ba42b*/
    do /*0x1039ba483*/
    {
      *(_BYTE *)(*((_QWORD *)this + 92) + v2 - 5232) = 0; /*0x1039ba437*/
      RakNet::ReliabilityLayer::Reset( /*0x1039ba45b*/
        this: (RakNet::ReliabilityLayer *)(*((_QWORD *)this + 92) + v2 - 4840),
        a2: false,
        a3: *(_DWORD *)(*((_QWORD *)this + 92) + v2 - 4840 + 4824),
        a4: false);
      std::shared_ptr<RakNet::RakNetSocket>::reset[abi:ne200100](a1: v2 + *((_QWORD *)this + 92)); /*0x1039ba46a*/
      ++v3; /*0x1039ba46f*/
      result = *((unsigned __int16 *)this + 85); /*0x1039ba472*/
      v2 += 5368; /*0x1039ba479*/
    }
    while ( v3 < result ); /*0x1039ba483*/
  }
  *((_WORD *)this + 85) = 0; /*0x1039ba485*/
  return result; /*0x1039ba492*/
}

// Address: 0x1039ba4e0 | Name: __ZN6RakNet7RakPeer24freeAllocatedSendPacketsEv
__int64 __fastcall RakNet::RakPeer::freeAllocatedSendPackets(RakNet::RakPeer *this)
{
  RakNet::SimpleMutex *v2; // r14
  unsigned int i; // r12d
  unsigned int v4; // eax
  unsigned int v5; // edx
  bool v6; // cf
  unsigned int v7; // edx
  unsigned int v8; // edx
  __int64 v9; // rcx
  int v10; // esi
  unsigned __int64 v11; // rsi
  RBX::Network::NetworkTracer *v12; // rdi
  unsigned int v13; // eax
  void *v14; // rdi

  v2 = (RakNet::RakPeer *)((char *)this + 2784); /*0x1039ba4ee*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2784)); /*0x1039ba4f8*/
  for ( i = 0; ; ++i ) /*0x1039ba500*/
  {
    v4 = *((_DWORD *)this + 714); /*0x1039ba503*/
    v5 = *((_DWORD *)this + 715); /*0x1039ba50f*/
    v6 = v5 < v4; /*0x1039ba511*/
    v7 = v5 - v4; /*0x1039ba511*/
    if ( v6 ) /*0x1039ba513*/
      v7 = *((_DWORD *)this + 716) + *((_DWORD *)this + 715) - v4; /*0x1039ba51d*/
    if ( i >= v7 ) /*0x1039ba522*/
      break; /*0x1039ba522*/
    v8 = *((_DWORD *)this + 716); /*0x1039ba528*/
    v9 = *((_QWORD *)this + 356); /*0x1039ba52e*/
    if ( DFFlag::DataPingTrace == 1 ) /*0x1039ba53c*/
    {
      v10 = *((_DWORD *)this + 716); /*0x1039ba544*/
      if ( i + v4 < v8 ) /*0x1039ba546*/
        v10 = 0; /*0x1039ba546*/
      v11 = *(_QWORD *)(*(_QWORD *)(v9 + 8LL * (i + v4 - v10)) + 96LL); /*0x1039ba555*/
      if ( v11 != 0 ) /*0x1039ba55c*/
      {
        if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039ba568*/
          v12 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039ba56a*/
        else
          v12 = nullptr; /*0x1039ba570*/
        RBX::Network::NetworkTracer::removeTracerObject(this: v12, a2: v11); /*0x1039ba572*/
        v4 = *((_DWORD *)this + 714); /*0x1039ba577*/
        v8 = *((_DWORD *)this + 716); /*0x1039ba57d*/
        v9 = *((_QWORD *)this + 356); /*0x1039ba583*/
      }
    }
    if ( v4 + i < v8 ) /*0x1039ba590*/
      v8 = 0; /*0x1039ba590*/
    (*(void (__fastcall **)(RakNet::RakPeer *, _QWORD))(*(_QWORD *)this + 240LL))( /*0x1039ba5a3*/
      a1: this,
      a2: *(_QWORD *)(v9 + 8LL * (i + v4 - v8)));
  }
  v13 = *((_DWORD *)this + 716); /*0x1039ba5b1*/
  if ( v13 != 0 ) /*0x1039ba5b9*/
  {
    if ( v13 >= 0x21 ) /*0x1039ba5be*/
    {
      v14 = *((void **)this + 356); /*0x1039ba5c0*/
      if ( v14 != nullptr ) /*0x1039ba5ca*/
        operator delete[](a1: v14); /*0x1039ba5cc*/
      *((_DWORD *)this + 716) = 0; /*0x1039ba5d1*/
    }
    *((_QWORD *)this + 357) = 0; /*0x1039ba5db*/
  }
  RakNet::SimpleMutex::Unlock(this: v2); /*0x1039ba5e9*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2688)); /*0x1039ba5f8*/
  DataStructures::MemoryPool<RakNet::Packet>::Clear(a1: (__int64)this + 2752, a2: ""); /*0x1039ba610*/
  return RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 2688)); /*0x1039ba618*/
}

// Address: 0x1039ba6fa | Name: __ZN6RakNet7RakPeer45SendPacketsToSelfToUnblockSocketReceiveThreadEv
__int64 __fastcall RakNet::RakPeer::SendPacketsToSelfToUnblockSocketReceiveThread(RakNet::RakPeer *this)
{
  RakNet::RakPeer *v1; // rbx
  int v2; // ecx
  __int64 v3; // rdi
  bool v4; // al
  __int64 v5; // rdi
  double v6; // xmm0_8
  unsigned int v7; // eax
  __int64 v8; // rax
  __int128 v9; // xmm0
  __int64 v11[5]; // [rsp+10h] [rbp-90h] BYREF
  double v12; // [rsp+38h] [rbp-68h]
  double v13; // [rsp+40h] [rbp-60h]
  __int64 v14; // [rsp+48h] [rbp-58h]
  int v15[4]; // [rsp+50h] [rbp-50h] BYREF
  __int128 v16; // [rsp+60h] [rbp-40h]
  int v17; // [rsp+74h] [rbp-2Ch] BYREF

  v1 = this; /*0x1039ba70b*/
  v2 = *((_DWORD *)this + 41); /*0x1039ba70e*/
  v3 = FLog::Network; /*0x1039ba71b*/
  v4 = (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 5u; /*0x1039ba72f*/
  if ( v2 != 0 )
  {
    if ( v4 )
    {
      *(_QWORD *)v15 = 0; /*0x1039ba748*/
      *(_QWORD *)&v15[2] = v11; /*0x1039ba750*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: 5,
        a4: (unsigned int)"[FLog::Network] RakPeer::SendPacketsToSelfToUnblockSocketReceiveThread(): Writing to socket to unb"
                      "lock select() or recvmsg()...",
        a5: 127,
        a6: 1,
        0,
        v11);
    }
    v12 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v3); /*0x1039ba780*/
    v14 = (unsigned int)DFInt::RakNetSelectUnblockSocketWriteDurationMs; /*0x1039ba78b*/
    if ( *((_DWORD *)v1 + 41) != 0 ) /*0x1039ba797*/
    {
      v13 = (double)(int)v14; /*0x1039ba7a5*/
      do /*0x1039ba87b*/
      {
        v6 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v5); /*0x1039ba7c0*/
        if ( v13 <= (v6 - v12) * 1000.0 ) /*0x1039ba7db*/
          break; /*0x1039ba7db*/
        v17 = 0; /*0x1039ba7e1*/
        if ( *((_DWORD *)v1 + 508) != 0 ) /*0x1039ba7ef*/
        {
          v7 = 0; /*0x1039ba7f1*/
          do /*0x1039ba867*/
          {
            v8 = *(_QWORD *)(*((_QWORD *)v1 + 253) + 16LL * v7); /*0x1039ba800*/
            v9 = *(_OWORD *)(v8 + 8); /*0x1039ba804*/
            v16 = *(_OWORD *)(v8 + 24); /*0x1039ba80e*/
            *(_OWORD *)v15 = v9; /*0x1039ba813*/
            RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v11, a2: nullptr); /*0x1039ba81d*/
            RakNet::SocketLayer::SendTo( /*0x1039ba854*/
              this: (RakNet::SocketLayer *)**(unsigned int **)(*((_QWORD *)v1 + 253) + 16LL * (unsigned int)v17),
              a2: (int)&v17,
              a3: (const char *)1,
              a4: (int)v15,
              a5: (const RakNet::SystemAddress *)v11,
              a6: nullptr,
              a7: (bool)"",
              a8: nullptr,
              a9: v11[0]);
            v7 = v17 + 1; /*0x1039ba85c*/
            v17 = v7; /*0x1039ba85e*/
          }
          while ( v7 < *((_DWORD *)v1 + 508) ); /*0x1039ba867*/
        }
        RakSleep(a1: 0x1Eu); /*0x1039ba86e*/
      }
      while ( *((_DWORD *)v1 + 41) != 0 ); /*0x1039ba87b*/
    }
    if ( *((_DWORD *)v1 + 41) != 0 )
    {
      if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
      {
        *(_QWORD *)v15 = 1; /*0x1039ba8bd*/
        *(_QWORD *)&v15[2] = v11; /*0x1039ba8cc*/
        FLog::detail::FastLogSafeFormattedInternal(
          a1: FLog::Network,
          a2: qword_10D7BBAA8,
          a3: 3,
          a4: (unsigned int)"[FLog::Network] Timed-out: SendPacketsToSelfToUnblockSocketReceiveThread(): Failed to gracefully"
                        " end receive loop after writing to socket for {} (ms)",
          a5: 149,
          a6: 1,
          1,
          v11,
          v14);
      }
      LODWORD(v1) = 0; /*0x1039ba8f7*/
    }
    else
    {
      LOBYTE(v1) = 1; /*0x1039ba941*/
    }
  }
  else
  {
    LOBYTE(v1) = 1; /*0x1039ba8fb*/
    if ( v4 )
    {
      *(_QWORD *)v15 = 0; /*0x1039ba905*/
      *(_QWORD *)&v15[2] = v11; /*0x1039ba914*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: 5,
        a4: (unsigned int)"[FLog::Network] RakPeer::SendPacketsToSelfToUnblockSocketReceiveThread(): The recv loop thread is "
                      "not active and therefore the recv socket was not blocked. Nothing to do here...",
        a5: 177,
        a6: 1,
        0,
        v11);
    }
  }
  return (unsigned int)v1; /*0x1039ba945*/
}

// Address: 0x1039ba954 | Name: __ZN6RakNet7RakPeer30getExternalIpFromSystemAddressERKNS_13SystemAddressE
RakNet::RakPeer *__fastcall RakNet::RakPeer::getExternalIpFromSystemAddress(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *a2)
{
  RakNet::SystemAddress::SystemAddress(this, a2: nullptr); /*0x1039ba95f*/
  return this; /*0x1039ba96b*/
}

// Address: 0x1039ba96e | Name: __ZN6RakNet7RakPeer8ShutdownEv
__int64 __fastcall RakNet::RakPeer::Shutdown(RakNet::RakPeer *this)
{
  unsigned int v1; // r14d
  RakNet::RakPeer *v2; // rbx
  RBX::Time *v3; // rdi
  double v4; // xmm0_8
  __int64 v5; // rdx
  RBX::Time *v6; // rdi
  __int64 v7; // r14
  __int64 v8; // rcx
  __int64 v9; // r12
  int v10; // r15d
  double v11; // xmm0_8
  __int64 v12; // rdx
  __int64 v13; // rcx
  __int64 v14; // rdx
  RBX::Time *v15; // rdi
  __int64 v16; // r14
  __int64 v17; // rcx
  __int64 v18; // r12
  int v19; // r15d
  double v20; // xmm0_8
  __int64 v21; // rax
  __int64 v22; // rcx
  float v23; // xmm0_4
  double v24; // xmm0_8
  __int64 v25; // rcx
  float v26; // xmm1_4
  __int64 v27; // rax
  __int64 v28; // rax
  __int64 v29; // rcx
  float v30; // xmm0_4
  double v31; // xmm0_8
  __int64 v32; // rcx
  float v33; // xmm1_4
  __int64 v34; // rax
  __int64 v35; // r13
  __int64 v36; // rax
  __int64 v37; // r12
  __int64 v38; // r14
  __int64 v39; // r15
  __int64 i; // rbx
  void *v41; // rdi
  void *v42; // rdi
  __int64 v43; // rdi
  _QWORD v45[9]; // [rsp+10h] [rbp-4F0h] BYREF
  _BYTE v46[504]; // [rsp+58h] [rbp-4A8h] BYREF
  _QWORD v47[2]; // [rsp+250h] [rbp-2B0h] BYREF
  void *v48; // [rsp+260h] [rbp-2A0h]
  _BYTE v49[496]; // [rsp+298h] [rbp-268h] BYREF
  void *v50; // [rsp+488h] [rbp-78h]
  __int128 v51; // [rsp+490h] [rbp-70h] BYREF
  __int128 v52; // [rsp+4A0h] [rbp-60h]
  int v53; // [rsp+4B0h] [rbp-50h]
  unsigned int v54; // [rsp+4C4h] [rbp-3Ch]
  double v55; // [rsp+4C8h] [rbp-38h]
  _BYTE v56[41]; // [rsp+4D7h] [rbp-29h] BYREF

  LOBYTE(v1) = 1; /*0x1039ba988*/
  if ( (*((_BYTE *)this + 162) & 1) == 0 )
  {
    v2 = this; /*0x1039ba993*/
    v52 = 0; /*0x1039ba99a*/
    v51 = 0; /*0x1039ba99f*/
    v53 = 1065353216; /*0x1039ba9a4*/
    *((_BYTE *)this + 162) = 1; /*0x1039ba9ad*/
    RakNet::SignaledEvent::SetEvent(this: (RakNet::RakPeer *)((char *)this + 2560)); /*0x1039ba9ba*/
    RBX::Time::nowFast(this: v3); /*0x1039ba9bf*/
    v55 = v4; /*0x1039ba9c4*/
    LOBYTE(v1) = 1; /*0x1039ba9cf*/
    if ( (*((_BYTE *)v2 + 161) & 1) != 0
      && (unsigned __int8)RBX::CEvent::Wait(
                            this: (RakNet::RakPeer *)((char *)v2 + 2536),
                            a2: DFInt::WaitOnUpdateNetworkLoopEndedMS) == 0 )
    {
      v7 = FLog::Network; /*0x1039ba9fb*/
      v8 = (unsigned int)FLog::Network >> 8; /*0x1039baa01*/
      LOBYTE(v5) = (unsigned __int8)FLog::Network < 6u; /*0x1039baa08*/
      LOBYTE(v8) = (unsigned __int8)FLog::Network < 6u || BYTE1(FLog::Network) < 3u; /*0x1039baa11*/
      if ( (_BYTE)v8 == 0 )
      {
        v9 = qword_10D7BBAA8; /*0x1039baa15*/
        v10 = DFInt::WaitOnUpdateNetworkLoopEndedMS; /*0x1039baa19*/
        RBX::Time::nowFast(this: v6); /*0x1039baa20*/
        FLog::FastLog(
          a1: v7,
          a2: v9,
          a3: "[FLog::Network] Timed-out: Failed to gracefully end update loop within %d (ms). Actual time taken: %d (ms).",
          v10,
          (int)((v11 - v55) * 1000.0));
      }
      if ( DFFlag::DebugRakNetCrashEarlyWhenFailedToStopUpdateLoopGracefully == 1 ) /*0x1039baa58*/
        RBXCRASH(a1: 3, a2: "Crashing to see where RakNet::UpdateNetworkLoop is blocked"); /*0x1039bafd9*/
      std::string::basic_string[abi:ne200100]<0>(a1: v47, a2: "RakNetShutdown_endUpdateLoopFailure", a3: v5, a4: v8); /*0x1039baa6f*/
      v45[0] = v47; /*0x1039baa7b*/
      *(_DWORD *)(std::__hash_table<std::__hash_value_type<std::string,int>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,int>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,int>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,int>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1039baa95*/
                    a1: &v51,
                    a2: v47,
                    a3: std::piecewise_construct,
                    a4: v45,
                    a5: v56)
                + 40) = 1;
      if ( (v47[0] & 1) != 0 ) /*0x1039baaa3*/
        operator delete(a1: v48); /*0x1039baaac*/
      v1 = 0; /*0x1039baab1*/
    }
    _InterlockedExchange((volatile __int32 *)v2 + 188, 0); /*0x1039baab6*/
    if ( DFFlag::RakNetDisablePollAndSelect == 1
      && (unsigned __int8)RakNet::RakPeer::SendPacketsToSelfToUnblockSocketReceiveThread(this: v2) == 0 )
    {
      v13 = (unsigned int)FLog::Network >> 8; /*0x1039baae8*/
      LOBYTE(v12) = (unsigned __int8)FLog::Network < 6u; /*0x1039baaef*/
      LOBYTE(v13) = (unsigned __int8)FLog::Network < 6u || BYTE1(FLog::Network) < 3u; /*0x1039baaf8*/
      if ( (_BYTE)v13 == 0 )
      {
        v47[0] = 1; /*0x1039bab10*/
        v47[1] = v45; /*0x1039bab1b*/
        FLog::detail::FastLogSafeFormattedInternal(
          a1: FLog::Network,
          a2: qword_10D7BBAA8,
          a3: 3,
          a4: (unsigned int)"[FLog::Network] Timed-out: Failed to gracefully end receive loop after writing to socket for {} (ms)",
          a5: 100,
          a6: 1,
          1,
          v45,
          (unsigned int)DFInt::RakNetSelectUnblockSocketWriteDurationMs);
      }
      std::string::basic_string[abi:ne200100]<0>( /*0x1039bab5d*/
        a1: v47,
        a2: "RakNetShutdown_endRecvLoopAfterWritingToSocketFailure",
        a3: v12,
        a4: v13);
      v45[0] = v47; /*0x1039bab69*/
      *(_DWORD *)(std::__hash_table<std::__hash_value_type<std::string,int>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,int>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,int>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,int>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1039bab83*/
                    a1: &v51,
                    a2: v47,
                    a3: std::piecewise_construct,
                    a4: v45,
                    a5: v56)
                + 40) = 1;
      if ( (v47[0] & 1) != 0 ) /*0x1039bab91*/
        operator delete(a1: v48); /*0x1039bab9a*/
    }
    if ( *((_DWORD *)v2 + 41) != 0
      && (unsigned __int8)RBX::CEvent::Wait(
                            this: (RakNet::RakPeer *)((char *)v2 + 2512),
                            a2: DFInt::WaitOnRecvFromLoopEndedMS) == 0 )
    {
      v16 = FLog::Network; /*0x1039babce*/
      v17 = (unsigned int)FLog::Network >> 8; /*0x1039babd4*/
      LOBYTE(v14) = (unsigned __int8)FLog::Network < 6u; /*0x1039babdb*/
      LOBYTE(v17) = (unsigned __int8)FLog::Network < 6u || BYTE1(FLog::Network) < 3u; /*0x1039babe4*/
      if ( (_BYTE)v17 == 0 )
      {
        v18 = qword_10D7BBAA8; /*0x1039babe8*/
        v19 = DFInt::WaitOnUpdateNetworkLoopEndedMS; /*0x1039babec*/
        RBX::Time::nowFast(this: v15); /*0x1039babf3*/
        FLog::FastLog(
          a1: v16,
          a2: v18,
          a3: "[FLog::Network] Timed-out: Failed to gracefully end receive loop within %d (ms). Actual time taken: %d (ms).",
          v19,
          (int)((v20 - v55) * 1000.0));
      }
      std::string::basic_string[abi:ne200100]<0>(a1: v47, a2: "RakNetShutdown_endRecvLoopFailure", a3: v14, a4: v17); /*0x1039bac35*/
      v45[0] = v47; /*0x1039bac41*/
      *(_DWORD *)(std::__hash_table<std::__hash_value_type<std::string,int>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,int>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,int>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,int>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1039bac5b*/
                    a1: &v51,
                    a2: v47,
                    a3: std::piecewise_construct,
                    a4: v45,
                    a5: v56)
                + 40) = 1;
      if ( (v47[0] & 1) != 0 ) /*0x1039bac69*/
        operator delete(a1: v48); /*0x1039bac72*/
      v1 = 0; /*0x1039bac77*/
    }
    if ( *((_QWORD *)&v52 + 1) != 0 ) /*0x1039bac7f*/
      RBX::Analytics::EphemeralCounter::bulkReportCounters(a1: &v51, a2: 0); /*0x1039bac87*/
    RBX::Telemetry::RobloxTelemetryStat::RobloxTelemetryStat( /*0x1039bac9a*/
      a1: (__int64)v47,
      a2: (__int64)&RBX::Telemetry::kSocketBlockedRatio);
    RBX::Telemetry::FieldsContainer::addField( /*0x1039bacbf*/
      a1: v49,
      a2: "isRbxConnection",
      a3: 15,
      a4: *((unsigned __int8 *)v2 + 3088),
      a5: 1);
    v21 = *((_QWORD *)v2 + 454); /*0x1039bacc4*/
    if ( v21 != 0 ) /*0x1039bacce*/
    {
      v22 = *((_QWORD *)v2 + 455); /*0x1039bacd0*/
      if ( v22 < 0 ) /*0x1039bacda*/
      {
        v25 = (*((_QWORD *)v2 + 455) >> 1) | *((_QWORD *)v2 + 455) & 1LL; /*0x1039bacf5*/
        v23 = (float)(int)v25 + (float)(int)v25; /*0x1039bad00*/
      }
      else
      {
        v23 = (float)(int)v22; /*0x1039bacdf*/
      }
      if ( v21 < 0 ) /*0x1039bad07*/
      {
        v27 = (*((_QWORD *)v2 + 454) >> 1) | *((_QWORD *)v2 + 454) & 1LL; /*0x1039bad19*/
        v26 = (float)(int)v27 + (float)(int)v27; /*0x1039bad21*/
      }
      else
      {
        v26 = (float)(int)v21; /*0x1039bad09*/
      }
      v24 = (float)(v23 / v26); /*0x1039bad29*/
    }
    else
    {
      v24 = 0.0; /*0x1039bace6*/
    }
    RBX::Telemetry::RobloxTelemetryStat::setValue(this: (RBX::Telemetry::RobloxTelemetryStat *)v47, a2: v24); /*0x1039bad34*/
    RBX::Telemetry::RobloxTelemetryStat::send(this: (RBX::Telemetry::RobloxTelemetryStat *)v47); /*0x1039bad40*/
    RBX::Telemetry::RobloxTelemetryStat::RobloxTelemetryStat( /*0x1039bad53*/
      a1: (__int64)v45,
      a2: (__int64)&RBX::Telemetry::kSocketOtherFailureRatio);
    RBX::Telemetry::FieldsContainer::addField( /*0x1039bad78*/
      a1: v46,
      a2: "isRbxConnection",
      a3: 15,
      a4: *((unsigned __int8 *)v2 + 3088),
      a5: 1);
    v28 = *((_QWORD *)v2 + 454); /*0x1039bad7d*/
    if ( v28 != 0 ) /*0x1039bad87*/
    {
      v29 = *((_QWORD *)v2 + 456); /*0x1039bad89*/
      if ( v29 < 0 ) /*0x1039bad93*/
      {
        v32 = (*((_QWORD *)v2 + 456) >> 1) | *((_QWORD *)v2 + 456) & 1LL; /*0x1039badad*/
        v30 = (float)(int)v32 + (float)(int)v32; /*0x1039badb8*/
      }
      else
      {
        v30 = (float)(int)v29; /*0x1039bad98*/
      }
      if ( v28 < 0 ) /*0x1039badbf*/
      {
        v34 = (*((_QWORD *)v2 + 454) >> 1) | *((_QWORD *)v2 + 454) & 1LL; /*0x1039badd4*/
        v33 = (float)(int)v34 + (float)(int)v34; /*0x1039baddf*/
      }
      else
      {
        v33 = (float)(int)v28; /*0x1039badc4*/
      }
      v31 = (float)(v30 / v33); /*0x1039bade7*/
    }
    else
    {
      v31 = 0.0; /*0x1039bad9f*/
    }
    RBX::Telemetry::RobloxTelemetryStat::setValue(this: (RBX::Telemetry::RobloxTelemetryStat *)v45, a2: v31); /*0x1039badf2*/
    RBX::Telemetry::RobloxTelemetryStat::send(this: (RBX::Telemetry::RobloxTelemetryStat *)v45); /*0x1039badfe*/
    RakNet::RakPeer::resetRemoteSystemList(this: v2); /*0x1039bae06*/
    RakNet::RakPeer::freeAllocatedSendPackets(this: v2); /*0x1039bae0e*/
    RakNet::RakPeer::DerefAllSockets(this: v2); /*0x1039bae16*/
    RakNet::RakPeer::ClearBufferedCommands(this: v2); /*0x1039bae1e*/
    DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Clear(a1: (__int64)v2 + 1352, a2: ""); /*0x1039bae33*/
    DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Clear(a1: (__int64)v2 + 1536, a2: ""); /*0x1039bae48*/
    DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Clear(a1: (__int64)v2 + 1736, a2: ""); /*0x1039bae5d*/
    RakNet::RakPeer::ClearRequestedConnectionList(this: v2); /*0x1039bae65*/
    *(_QWORD *)((char *)v2 + 956) = 0; /*0x1039bae6c*/
    v35 = *((_QWORD *)v2 + 92); /*0x1039bae73*/
    *((_QWORD *)v2 + 92) = 0; /*0x1039bae7a*/
    if ( v35 != 0 ) /*0x1039bae84*/
    {
      v54 = v1; /*0x1039bae8a*/
      v55 = *(double *)&v2; /*0x1039bae8e*/
      v50 = (void *)(v35 - 8); /*0x1039bae96*/
      v36 = *(_QWORD *)(v35 - 8); /*0x1039bae9a*/
      if ( v36 != 0 ) /*0x1039baea1*/
      {
        v37 = 5368 * v36 + v35; /*0x1039baeaa*/
        v38 = v37 - 288; /*0x1039baeb2*/
        do /*0x1039baf20*/
        {
          v39 = v37 - 5368; /*0x1039baeb9*/
          operator delete(a1: *(void **)(v37 - 32)); /*0x1039baec6*/
          std::shared_ptr<RBX::Rupp::Rupp>::~shared_ptr[abi:ne200100](a1: v37 - 88); /*0x1039baed0*/
          std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: v37 - 136); /*0x1039baedd*/
          for ( i = 0; i != -128; i -= 32 ) /*0x1039baee2*/
          {
            v41 = *(void **)(v37 + i - 312); /*0x1039baee4*/
            if ( (void *)(v38 + i) != v41 ) /*0x1039baef3*/
              operator delete(a1: v41); /*0x1039baef5*/
          }
          RakNet::ReliabilityLayer::~ReliabilityLayer(this: (RakNet::ReliabilityLayer *)(v37 - 4976)); /*0x1039baf0e*/
          v38 -= 5368; /*0x1039baf13*/
          v37 -= 5368; /*0x1039baf1a*/
        }
        while ( v39 != v35 ); /*0x1039baf20*/
      }
      operator delete[](a1: v50); /*0x1039baf26*/
      *(double *)&v2 = v55; /*0x1039baf2b*/
      v1 = v54; /*0x1039baf2f*/
    }
    v42 = *((void **)v2 + 93); /*0x1039baf33*/
    if ( v42 != nullptr ) /*0x1039baf3d*/
      operator delete[](a1: v42); /*0x1039baf3f*/
    *((_QWORD *)v2 + 93) = 0; /*0x1039baf44*/
    RakNet::RakPeer::ClearRemoteSystemLookup(this: v2); /*0x1039baf52*/
    RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)v2 + 2912)); /*0x1039baf61*/
    *((_DWORD *)v2 + 744) = 1; /*0x1039baf66*/
    RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)v2 + 2912)); /*0x1039baf73*/
    v43 = *((_QWORD *)v2 + 424); /*0x1039baf78*/
    if ( v43 != 0 ) /*0x1039baf82*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v43 + 32LL))(a1: v43); /*0x1039baf87*/
    RBX::Telemetry::RobloxTelemetryStat::~RobloxTelemetryStat(this: (RBX::Telemetry::RobloxTelemetryStat *)v45); /*0x1039baf9b*/
    RBX::Telemetry::RobloxTelemetryStat::~RobloxTelemetryStat(this: (RBX::Telemetry::RobloxTelemetryStat *)v47); /*0x1039bafaa*/
    std::__hash_table<std::__hash_value_type<std::string,int>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,int>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,int>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,int>>>::~__hash_table(a1: &v51); /*0x1039bafb3*/
  }
  return v1; /*0x1039bafbb*/
}

// Address: 0x1039bb05a | Name: __ZN6RakNet7RakPeer28ClearRequestedConnectionListEv
void __fastcall RakNet::RakPeer::ClearRequestedConnectionList(
        RakNet::RakPeer *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        int a5,
        int a6)
{
  unsigned int v7; // eax
  unsigned int v8; // edx
  bool v9; // cf
  int v10; // edx
  unsigned int v11; // eax
  unsigned int v12; // ecx
  unsigned int v13; // eax
  unsigned int v14; // edx
  unsigned int v15; // ecx
  unsigned int v16; // edi
  unsigned int v17; // r15d
  unsigned int v18; // edi
  char *v19; // rbx
  unsigned int v20; // edi
  __int64 v21; // [rsp+0h] [rbp-50h] BYREF
  RakNet::SimpleMutex *v22; // [rsp+8h] [rbp-48h]
  void *v23[2]; // [rsp+10h] [rbp-40h] BYREF
  unsigned int v24; // [rsp+20h] [rbp-30h]

  if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
    FLog::FastLogFormatted(
      a1: (_DWORD)DFLog::RakNetConnectTrace,
      a2: qword_10D7BB0C8,
      a3: (unsigned int)"[DFLog::RakNetConnectTrace] RakNet: Clearing Requested Connection List",
      a4: (unsigned __int8)DFLog::RakNetConnectTrace < 6u,
      a5,
      a6);
  *(_OWORD *)v23 = 0; /*0x1039bb0a2*/
  v24 = 0; /*0x1039bb0a6*/
  v22 = (RakNet::RakPeer *)((char *)this + 1160); /*0x1039bb0b4*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1160)); /*0x1039bb0b8*/
  while ( 1 ) /*0x1039bb0cf*/
  {
    v7 = *((_DWORD *)this + 286); /*0x1039bb0cf*/
    v8 = *((_DWORD *)this + 287); /*0x1039bb0db*/
    v9 = v8 < v7; /*0x1039bb0dd*/
    v10 = v8 - v7; /*0x1039bb0dd*/
    if ( v9 ) /*0x1039bb0df*/
      v10 = *((_DWORD *)this + 288) + *((_DWORD *)this + 287) - v7; /*0x1039bb0e9*/
    if ( v10 == 0 ) /*0x1039bb0ed*/
      break; /*0x1039bb0ed*/
    v11 = v7 + 1; /*0x1039bb0ef*/
    v12 = *((_DWORD *)this + 288); /*0x1039bb0f1*/
    if ( v11 == v12 ) /*0x1039bb0f9*/
      v11 = 0; /*0x1039bb0f9*/
    *((_DWORD *)this + 286) = v11; /*0x1039bb0fd*/
    if ( v11 == 0 ) /*0x1039bb105*/
      v11 = v12; /*0x1039bb105*/
    v21 = *(_QWORD *)(*((_QWORD *)this + 142) + 8LL * (v11 - 1)); /*0x1039bb115*/
    DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push(a1: (__int64)v23, a2: &v21); /*0x1039bb124*/
  }
  RakNet::SimpleMutex::Unlock(this: v22); /*0x1039bb12f*/
  v13 = (unsigned int)v23[1]; /*0x1039bb134*/
  v14 = HIDWORD(v23[1]); /*0x1039bb137*/
  v15 = v24; /*0x1039bb141*/
  v16 = 0; /*0x1039bb144*/
  if ( HIDWORD(v23[1]) < LODWORD(v23[1]) ) /*0x1039bb149*/
    v16 = v24; /*0x1039bb149*/
  if ( HIDWORD(v23[1]) - LODWORD(v23[1]) + v16 != 0 ) /*0x1039bb14e*/
  {
    v17 = 0; /*0x1039bb150*/
    do /*0x1039bb1b2*/
    {
      v18 = v15; /*0x1039bb15d*/
      if ( v13 + v17 < v15 ) /*0x1039bb15f*/
        v18 = 0; /*0x1039bb15f*/
      v19 = *((char **)v23[0] + v17 + v13 - v18); /*0x1039bb16c*/
      if ( v19 != nullptr ) /*0x1039bb173*/
      {
        std::shared_ptr<RBX::Security::RakPeerCrypto>::~shared_ptr[abi:ne200100](a1: v19 + 360); /*0x1039bb17c*/
        std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: v19 + 344); /*0x1039bb188*/
        operator delete(a1: v19); /*0x1039bb190*/
        v13 = (unsigned int)v23[1]; /*0x1039bb195*/
        v14 = HIDWORD(v23[1]); /*0x1039bb198*/
        v15 = v24; /*0x1039bb19b*/
      }
      ++v17; /*0x1039bb19e*/
      v20 = 0; /*0x1039bb1a5*/
      if ( v14 < v13 ) /*0x1039bb1aa*/
        v20 = v15; /*0x1039bb1aa*/
    }
    while ( v17 < v20 + v14 - v13 ); /*0x1039bb1b2*/
  }
  if ( v15 != 0 && v23[0] != nullptr ) /*0x1039bb1bf*/
    operator delete[](a1: v23[0]); /*0x1039bb1c1*/
}

// Address: 0x1039bb266 | Name: __ZN6RakNet7RakPeer23ClearRemoteSystemLookupEv
void __fastcall RakNet::RakPeer::ClearRemoteSystemLookup(RakNet::RakPeer *this)
{
  void *v2; // rdi

  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear(a1: (__int64)this + 792, a2: ""); /*0x1039bb27f*/
  v2 = *((void **)this + 98); /*0x1039bb284*/
  if ( v2 != nullptr ) /*0x1039bb28e*/
    operator delete[](a1: v2); /*0x1039bb290*/
  *((_QWORD *)this + 98) = 0; /*0x1039bb295*/
}

// Address: 0x1039bb2a8 | Name: __ZNK6RakNet7RakPeer17GetConnectionListEPNS_13SystemAddressEPt
char __fastcall RakNet::RakPeer::GetConnectionList(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *a2,
        unsigned __int16 *a3)
{
  unsigned __int16 v6; // r15
  unsigned __int64 v7; // r12
  __int64 v8; // r13
  __int128 v10; // [rsp+0h] [rbp-50h] BYREF
  __int128 v11; // [rsp+10h] [rbp-40h] BYREF

  if ( a3 == nullptr ) /*0x1039bb2bc*/
    return 0; /*0x1039bb2bc*/
  if ( *((_QWORD *)this + 92) == 0 || (*((_BYTE *)this + 160) & 1) != 0 ) /*0x1039bb2d3*/
  {
    *a3 = 0; /*0x1039bb2d5*/
    return 0; /*0x1039bb2ea*/
  }
  v11 = 0; /*0x1039bb2f5*/
  v10 = 0; /*0x1039bb2fc*/
  (*(void (__fastcall **)(RakNet::RakPeer *, __int128 *, __int128 *))(*(_QWORD *)this + 296LL))( /*0x1039bb302*/
    a1: this,
    a2: &v11,
    a3: &v10);
  if ( a2 != nullptr ) /*0x1039bb30b*/
  {
    v6 = 0; /*0x1039bb30d*/
    if ( *a3 != 0 && DWORD2(v11) != 0 ) /*0x1039bb31a*/
    {
      v7 = 1; /*0x1039bb31c*/
      v6 = 0; /*0x1039bb322*/
      v8 = 0; /*0x1039bb325*/
      do /*0x1039bb353*/
      {
        RakNet::SystemAddress::operator=(a1: (char *)a2 + v8, a2: v8 + v11); /*0x1039bb333*/
        ++v6; /*0x1039bb33b*/
        if ( v7 >= *a3 ) /*0x1039bb341*/
          break; /*0x1039bb341*/
        v8 += 32; /*0x1039bb343*/
      }
      while ( DWORD2(v11) > (unsigned int)v7++ ); /*0x1039bb353*/
    }
  }
  else
  {
    v6 = WORD4(v11); /*0x1039bb357*/
  }
  *a3 = v6; /*0x1039bb35c*/
  if ( HIDWORD(v10) != 0 && (_QWORD)v10 != 0 ) /*0x1039bb36d*/
    operator delete[](a1: (void *)v10); /*0x1039bb36f*/
  if ( HIDWORD(v11) != 0 && (_QWORD)v11 != 0 ) /*0x1039bb381*/
    operator delete[](a1: (void *)v11); /*0x1039bb383*/
  return 1; /*0x1039bb2dc*/
}

// Address: 0x1039bb3c4 | Name: __ZN6RakNet7RakPeer18GetNextSendReceiptEv
__int64 __fastcall RakNet::RakPeer::GetNextSendReceipt(RakNet::RakPeer *this)
{
  RakNet::RakPeer *v1; // rbx
  RakNet::SimpleMutex *v2; // r14

  v1 = this; /*0x1039bb3cb*/
  v2 = (RakNet::RakPeer *)((char *)this + 2912); /*0x1039bb3ce*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2912)); /*0x1039bb3d8*/
  LODWORD(v1) = *((_DWORD *)v1 + 744); /*0x1039bb3dd*/
  RakNet::SimpleMutex::Unlock(this: v2); /*0x1039bb3e6*/
  return (unsigned int)v1; /*0x1039bb3ed*/
}

// Address: 0x1039bb3f2 | Name: __ZN6RakNet7RakPeer24IncrementNextSendReceiptEv
__int64 __fastcall RakNet::RakPeer::IncrementNextSendReceipt(RakNet::RakPeer *this)
{
  RakNet::SimpleMutex *v2; // r14
  unsigned int v3; // r15d

  v2 = (RakNet::RakPeer *)((char *)this + 2912); /*0x1039bb3ff*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2912)); /*0x1039bb409*/
  v3 = *((_DWORD *)this + 744); /*0x1039bb40e*/
  *((_DWORD *)this + 744) = (v3 == -1) + v3 + 1; /*0x1039bb422*/
  RakNet::SimpleMutex::Unlock(this: v2); /*0x1039bb42b*/
  return v3; /*0x1039bb437*/
}

// Address: 0x1039bb43e | Name: __ZN6RakNet7RakPeer4SendEPKci14PacketPriority17PacketReliabilitycNS_13AddressOrGUIDEbj
__int64 __fastcall RakNet::RakPeer::Send(
        RakNet::RakPeer *this,
        __int64 a2,
        int a3,
        int a4,
        int a5,
        char a6,
        RakNet::AddressOrGUID *a7,
        char a8,
        unsigned int a9)
{
  unsigned int v10; // ebx
  const RakNet::AddressOrGUID *v14; // rsi
  char IsUndefined; // al
  const RakNet::AddressOrGUID *v16; // rbx
  unsigned int v17; // eax
  char IsLoopbackAddress; // al
  _BYTE v20[48]; // [rsp+0h] [rbp-60h] BYREF
  int v21; // [rsp+30h] [rbp-30h]
  int v22; // [rsp+34h] [rbp-2Ch]

  v10 = 0; /*0x1039bb45d*/
  if ( a2 != 0 && a3 >= 0 && *((_QWORD *)this + 92) != 0 && (*((_BYTE *)this + 160) & 1) == 0 ) /*0x1039bb481*/
  {
    v21 = a4; /*0x1039bb48d*/
    v14 = a7; /*0x1039bb490*/
    v22 = a5; /*0x1039bb498*/
    if ( a8 != 0 || (IsUndefined = RakNet::AddressOrGUID::IsUndefined(this: a7), v14 = a7, IsUndefined == 0) ) /*0x1039bb4ac*/
    {
      v10 = a9; /*0x1039bb4b2*/
      if ( a9 == 0 ) /*0x1039bb4b7*/
      {
        v16 = v14; /*0x1039bb4bf*/
        v17 = (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 160LL))(a1: this); /*0x1039bb4c2*/
        v14 = v16; /*0x1039bb4c8*/
        v10 = v17; /*0x1039bb4cb*/
      }
      if ( a8 != 0 /*0x1039bb4ea*/
        || (IsLoopbackAddress = RakNet::RakPeer::IsLoopbackAddress(this, a2: a7, a3: true),
            v14 = a7,
            IsLoopbackAddress == 0) )
      {
        RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v20, a2: v14); /*0x1039bb54c*/
        RakNet::RakPeer::SendBuffered( /*0x1039bb578*/
          a1: (_DWORD)this,
          a2,
          a3: 8 * a3,
          a4: v21,
          a5: v22,
          a6,
          a7: (__int64)v20,
          a8,
          a9: 0,
          a10: v10,
          a11: 0,
          a12: 0);
      }
      else
      {
        (*(void (__fastcall **)(RakNet::RakPeer *, __int64, _QWORD))(*(_QWORD *)this + 176LL))( /*0x1039bb4f8*/
          a1: this,
          a2,
          (unsigned int)a3);
        if ( v22 >= 5 ) /*0x1039bb502*/
        {
          v20[0] = 14; /*0x1039bb508*/
          RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2912)); /*0x1039bb516*/
          *(_DWORD *)&v20[1] = *((_DWORD *)this + 744); /*0x1039bb522*/
          RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 2912)); /*0x1039bb529*/
          (*(void (__fastcall **)(RakNet::RakPeer *, _BYTE *, __int64))(*(_QWORD *)this + 176LL))( /*0x1039bb53c*/
            a1: this,
            a2: v20,
            a3: 5);
        }
      }
    }
  }
  return v10; /*0x1039bb583*/
}

// Address: 0x1039bb5ce | Name: __ZNK6RakNet7RakPeer17IsLoopbackAddressERKNS_13AddressOrGUIDEb
char __fastcall RakNet::RakPeer::IsLoopbackAddress(RakNet::RakPeer *this, const RakNet::AddressOrGUID *a2, char a3)
{
  char *v7; // rbx
  const RakNet::SystemAddress *v8; // r14
  __int64 i; // r12
  RakNet::SystemAddress *v10; // rdi
  char v11; // al
  const RakNet::SystemAddress *v12; // rsi
  RakNet::RakPeer *v13; // [rsp+0h] [rbp-30h]

  if ( (unsigned __int8)RakNet::RakNetGUID::operator!=(a1: a2, a2: &RakNet::UNASSIGNED_RAKNET_GUID) != 0 ) /*0x1039bb5f6*/
    return RakNet::RakNetGUID::operator==(a1: a2, a2: (char *)this + 2088); /*0x1039bb613*/
  v13 = this; /*0x1039bb618*/
  v7 = (char *)this + 2168; /*0x1039bb61c*/
  v8 = (const RakNet::AddressOrGUID *)((char *)a2 + 16); /*0x1039bb623*/
  for ( i = 0; i != 320; i += 32 ) /*0x1039bb627*/
  {
    if ( (unsigned __int8)RakNet::SystemAddress::operator!=(a1: &v7[i], a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) == 0 ) /*0x1039bb63f*/
      break; /*0x1039bb63f*/
    v10 = (RakNet::SystemAddress *)&v7[i]; /*0x1039bb641*/
    if ( a3 != 0 ) /*0x1039bb64a*/
      v11 = RakNet::SystemAddress::operator==(a1: v10, a2: v8); /*0x1039bb64c*/
    else
      v11 = RakNet::SystemAddress::EqualsExcludingPort(this: v10, a2: v8); /*0x1039bb653*/
    if ( v11 != 0 ) /*0x1039bb65a*/
      return 1; /*0x1039bb69e*/
  }
  v12 = (RakNet::RakPeer *)((char *)v13 + 2112); /*0x1039bb66d*/
  if ( a3 != 0 ) /*0x1039bb67e*/
    return RakNet::SystemAddress::operator==(a1: v8, a2: v12); /*0x1039bb68a*/
  else
    return RakNet::SystemAddress::EqualsExcludingPort(this: v8, a2: v12); /*0x1039bb699*/
}

// Address: 0x1039bb6b0 | Name: __ZN6RakNet7RakPeer12SendBufferedEPKcj14PacketPriority17PacketReliabilitycNS_13AddressOrGUIDEbNS0_18RemoteSystemStruct11ConnectModeEjby
int __fastcall RakNet::RakPeer::SendBuffered(
        RakNet *a1,
        void *a2,
        int a3,
        int a4,
        int a5,
        char a6,
        __int64 *a7,
        char a8,
        int a9,
        int a10,
        char a11,
        __int64 a12)
{
  unsigned __int64 v15; // rsi
  void *v16; // rax
  int v17; // r8d
  int v18; // r9d
  RakNet *v19; // rdi
  RBX::Network *v20; // rdi
  __int64 v21; // rdx
  __int64 v22; // rsi
  __int64 v23; // rbx
  __int64 *v24; // rax
  __int64 v25; // rbx
  unsigned __int8 v26; // al
  unsigned __int8 v27; // r14
  RakNet *v28; // rdi
  unsigned int TimeMS; // eax
  pthread_mutex_t *v30; // r12
  std::__shared_weak_count *v31; // rbx
  std::__shared_weak_count *v32; // rbx
  std::__shared_weak_count *v34[2]; // [rsp+0h] [rbp-180h] BYREF
  _BYTE v35[13]; // [rsp+10h] [rbp-170h]
  _OWORD v36[8]; // [rsp+20h] [rbp-160h] BYREF
  __int128 v37; // [rsp+A0h] [rbp-E0h]
  _DWORD v38[4]; // [rsp+B0h] [rbp-D0h]
  __int64 v39; // [rsp+C0h] [rbp-C0h] BYREF
  __int16 v40; // [rsp+C8h] [rbp-B8h]
  _BYTE v41[32]; // [rsp+D0h] [rbp-B0h] BYREF
  __int128 v42; // [rsp+F0h] [rbp-90h]
  __int128 v43; // [rsp+100h] [rbp-80h]
  __int128 v44; // [rsp+110h] [rbp-70h]
  __int128 v45; // [rsp+120h] [rbp-60h]
  __int128 v46; // [rsp+130h] [rbp-50h]
  void *__src; // [rsp+140h] [rbp-40h]
  int v48; // [rsp+14Ch] [rbp-34h]
  RakNet *v49; // [rsp+150h] [rbp-30h]

  v48 = a4; /*0x1039bb6ca*/
  __src = a2; /*0x1039bb6d0*/
  v49 = a1; /*0x1039bb6d4*/
  v37 = 0; /*0x1039bb6e2*/
  RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)&v39); /*0x1039bb6e6*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v41); /*0x1039bb6f2*/
  *((_QWORD *)&v43 + 1) = 0; /*0x1039bb6f9*/
  *((_QWORD *)&v46 + 1) = 0; /*0x1039bb6fd*/
  v16 = (void *)RBX::Memory::allocateOrCrash(this: (RBX::Memory *)((unsigned int)(a3 + 7) >> 3), a2: v15); /*0x1039bb70c*/
  *((_QWORD *)&v43 + 1) = v16; /*0x1039bb711*/
  if ( v16 != nullptr ) /*0x1039bb718*/
  {
    memcpy(__dst: v16, __src, __n: (unsigned int)(a3 + 7) >> 3); /*0x1039bb72c*/
    v38[0] = a3; /*0x1039bb731*/
    v38[1] = v48; /*0x1039bb73b*/
    v38[2] = a5; /*0x1039bb741*/
    LOBYTE(v38[3]) = a6; /*0x1039bb748*/
    v39 = *a7; /*0x1039bb752*/
    v40 = *((_WORD *)a7 + 4); /*0x1039bb75f*/
    RakNet::SystemAddress::operator=(a1: v41, a2: a7 + 2); /*0x1039bb774*/
    LOBYTE(v42) = a8; /*0x1039bb786*/
    DWORD1(v42) = a9; /*0x1039bb78c*/
    LODWORD(v45) = a10; /*0x1039bb792*/
    BYTE4(v45) = a11; /*0x1039bb795*/
    LODWORD(v46) = 0; /*0x1039bb799*/
    *((_QWORD *)&v45 + 1) = (unsigned int)RakNet::GetTimeMS(this: v19); /*0x1039bb7ab*/
    *((_QWORD *)&v46 + 1) = a12; /*0x1039bb7af*/
    if ( a12 != 0 && DFFlag::EnablePingPongPerformanceTraceCLI != 0 ) /*0x1039bb7c3*/
    {
      if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v20) != 0 ) /*0x1039bb7d7*/
      {
        if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039bb7dc*/
          v23 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039bb7de*/
        else
          v23 = 0; /*0x1039bb82c*/
        v26 = (*(__int64 (__fastcall **)(RakNet *, __int64, __int64, __int64))(*(_QWORD *)v49 + 200LL))( /*0x1039bb835*/
                a1: v49,
                a2: v22,
                a3: v21,
                a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
        RBX::Network::NetworkTracer::addCheckpointToTracer(a1: v23, a2: a12, a3: v26, a4: 65); /*0x1039bb849*/
      }
      else
      {
        if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039bb824*/
          v25 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039bb826*/
        else
          v25 = 0; /*0x1039bb850*/
        v27 = (*(__int64 (__fastcall **)(RakNet *, __int64, __int64, __int64))(*(_QWORD *)v49 + 200LL))( /*0x1039bb85f*/
                a1: v49,
                a2: v22,
                a3: v21,
                a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
        TimeMS = RakNet::GetTimeMS(this: v28); /*0x1039bb862*/
        RBX::Network::NetworkTracer::addCheckpointToTracer_deprecated(a1: v25, a2: a12, a3: v27, a4: 65, a5: TimeMS); /*0x1039bb879*/
      }
    }
    v30 = (pthread_mutex_t *)((char *)v49 + 1288); /*0x1039bb882*/
    boost::mutex::lock(this: (pthread_mutex_t *)((char *)v49 + 1288)); /*0x1039bb88c*/
    *(_OWORD *)v34 = v37; /*0x1039bb8a0*/
    if ( *((_QWORD *)&v37 + 1) != 0 ) /*0x1039bb8aa*/
      _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v37 + 1) + 8LL)); /*0x1039bb8ac*/
    qmemcpy(v35, v38, sizeof(v35)); /*0x1039bb8bf*/
    RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v36, a2: (const RakNet::AddressOrGUID *)&v39); /*0x1039bb8ce*/
    v36[7] = v46; /*0x1039bb8e5*/
    v36[6] = v45; /*0x1039bb8f8*/
    v36[5] = v44; /*0x1039bb8fc*/
    v36[4] = v43; /*0x1039bb900*/
    v36[3] = v42; /*0x1039bb904*/
    RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::push_back<std::move_iterator<RakNet::RakPeer::BufferedCommandStruct*>>( /*0x1039bb91a*/
      a1: (char *)v49 + 1224,
      a2: v34);
    v31 = v34[1]; /*0x1039bb91f*/
    if ( v34[1] != nullptr /*0x1039bb93b*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v34[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v31 + 16LL))(a1: v31); /*0x1039bb943*/
      std::__shared_weak_count::__release_weak(this: v31); /*0x1039bb949*/
    }
    LODWORD(v24) = boost::mutex::unlock(this: v30); /*0x1039bb951*/
    if ( v48 == 0 ) /*0x1039bb95a*/
      LODWORD(v24) = RakNet::SignaledEvent::SetEvent(this: (RakNet *)((char *)v49 + 2560)); /*0x1039bb967*/
  }
  else
  {
    v24 = &FLog::Network; /*0x1039bb7e4*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1039bb7fd*/
      LODWORD(v24) = FLog::FastLogFormatted( /*0x1039bb817*/
                       a1: FLog::Network,
                       a2: qword_10D7BBAA8,
                       a3: (unsigned int)"[FLog::Network] out of memory in raknet at callsite %ld",
                       a4: 0,
                       a5: v17,
                       a6: v18);
  }
  v32 = *((std::__shared_weak_count **)&v37 + 1); /*0x1039bb96c*/
  if ( *((_QWORD *)&v37 + 1) != 0 ) /*0x1039bb976*/
  {
    v24 = (__int64 *)_InterlockedExchangeAdd64( /*0x1039bb97f*/
                       (volatile signed __int64 *)(*((_QWORD *)&v37 + 1) + 8LL),
                       0xFFFFFFFFFFFFFFFFLL);
    if ( v24 == nullptr ) /*0x1039bb988*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v32 + 16LL))(a1: v32); /*0x1039bb990*/
      LODWORD(v24) = std::__shared_weak_count::__release_weak(this: v32); /*0x1039bb996*/
    }
  }
  return (int)v24; /*0x1039bb99b*/
}

// Address: 0x1039bb9da | Name: __ZN6RakNet7RakPeer12SendLoopbackEPKci
char __fastcall RakNet::RakPeer::SendLoopback(RakNet::RakPeer *this, const char *a2, signed int a3)
{
  char result; // al
  __int64 v7; // r12
  __int128 v8; // xmm0
  _QWORD v9[8]; // [rsp-48h] [rbp-48h] BYREF

  result = a2 == nullptr; /*0x1039bb9dd*/
  if ( a2 != nullptr && a3 >= 0 ) /*0x1039bb9e2*/
  {
    v7 = RakNet::RakPeer::AllocPacket(this, a2: a3, a3: "", a4: 0); /*0x1039bba16*/
    memcpy(__dst: *(void **)(v7 + 56), __src: a2, __n: (unsigned int)a3); /*0x1039bba23*/
    v8 = *(_OWORD *)((char *)this + 2168); /*0x1039bba28*/
    *(_OWORD *)&v9[2] = *(_OWORD *)((char *)this + 2184); /*0x1039bba3a*/
    *(_OWORD *)v9 = v8; /*0x1039bba3e*/
    RakNet::SystemAddress::operator=(a1: v7, a2: v9); /*0x1039bba44*/
    *(_QWORD *)(v7 + 32) = *((_QWORD *)this + 261); /*0x1039bba50*/
    *(_WORD *)(v7 + 40) = *((_WORD *)this + 1048); /*0x1039bba5c*/
    return (*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, _QWORD))(*(_QWORD *)this + 544LL))( /*0x1039bba6d*/
             a1: this,
             a2: v7,
             a3: 0);
  }
  return result; /*0x1039bba7f*/
}

// Address: 0x1039bba80 | Name: __ZNK6RakNet7RakPeer18GetLoopbackAddressEv
RakNet::RakPeer *__fastcall RakNet::RakPeer::GetLoopbackAddress(RakNet::RakPeer *this, __int64 a2)
{
  __int128 v3; // xmm0

  v3 = *(_OWORD *)(a2 + 2168); /*0x1039bba87*/
  *((_OWORD *)this + 1) = *(_OWORD *)(a2 + 2184); /*0x1039bba95*/
  *(_OWORD *)this = v3; /*0x1039bba99*/
  return this; /*0x1039bba9c*/
}

// Address: 0x1039bba9e | Name: __ZN6RakNet7RakPeer4SendEPKN3RBX11NetworkCore17AbstractBitStreamE14PacketPriority17PacketReliabilitycNS_13AddressOrGUIDEbjy
__int64 __fastcall RakNet::RakPeer::Send(
        RakNet::RakPeer *this,
        char *a2,
        int a3,
        int a4,
        char a5,
        const RakNet::AddressOrGUID *a6,
        char a7,
        unsigned int a8,
        __int64 a9)
{
  unsigned int v13; // ebx
  __int64 v14; // r15
  unsigned int v15; // eax
  __int64 v17[6]; // [rsp+0h] [rbp-70h] BYREF
  void *v18; // [rsp+30h] [rbp-40h]
  int v19; // [rsp+3Ch] [rbp-34h]
  int v20; // [rsp+40h] [rbp-30h]
  int v21; // [rsp+44h] [rbp-2Ch]

  v21 = a4; /*0x1039bbab5*/
  v19 = a3; /*0x1039bbab8*/
  v13 = 0; /*0x1039bbaca*/
  if ( (*(unsigned int (__fastcall **)(char *))(*(_QWORD *)a2 + 24LL))(a1: a2) != 0 /*0x1039bbb01*/
    && *((_QWORD *)this + 92) != 0
    && (*((_BYTE *)this + 160) & 1) == 0
    && (a7 != 0 || (unsigned __int8)RakNet::AddressOrGUID::IsUndefined(this: a6) == 0) )
  {
    v13 = a8; /*0x1039bbb07*/
    if ( a8 == 0 ) /*0x1039bbb0c*/
      v13 = (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 160LL))(a1: this); /*0x1039bbb1a*/
    if ( a7 != 0 || RakNet::RakPeer::IsLoopbackAddress(this, a2: a6, a3: 1) == 0 ) /*0x1039bbb38*/
    {
      v18 = (void *)(*(__int64 (__fastcall **)(char *))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1039bbbb6*/
      v20 = 8 * (*(__int64 (__fastcall **)(char *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1039bbbcb*/
      RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v17, a2: a6); /*0x1039bbbd5*/
      RakNet::RakPeer::SendBuffered( /*0x1039bbc08*/
        a1: this,
        a2: v18,
        a3: v20,
        a4: v19,
        a5: v21,
        a6: a5,
        a7: v17,
        a8: a7,
        a9: 0,
        a10: v13,
        a11: a2[8],
        a12: a9);
    }
    else
    {
      v14 = (*(__int64 (__fastcall **)(char *))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1039bbb44*/
      v15 = (*(__int64 (__fastcall **)(char *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1039bbb4e*/
      (*(void (__fastcall **)(RakNet::RakPeer *, __int64, _QWORD))(*(_QWORD *)this + 176LL))(a1: this, a2: v14, a3: v15); /*0x1039bbb5c*/
      if ( v21 >= 5 ) /*0x1039bbb66*/
      {
        LOBYTE(v17[0]) = 14; /*0x1039bbb70*/
        RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2912)); /*0x1039bbb7e*/
        *(_DWORD *)((char *)v17 + 1) = *((_DWORD *)this + 744); /*0x1039bbb8a*/
        RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 2912)); /*0x1039bbb91*/
        (*(void (__fastcall **)(RakNet::RakPeer *, __int64 *, __int64))(*(_QWORD *)this + 176LL))( /*0x1039bbba4*/
          a1: this,
          a2: v17,
          a3: 5);
      }
    }
  }
  return v13; /*0x1039bbc13*/
}

// Address: 0x1039bbc22 | Name: __ZN6RakNet7RakPeer4SendERNSt3__110shared_ptrIKN3RBX11NetworkCore17AbstractBitStreamEEE14PacketPriority17PacketReliabilitycNS_13AddressOrGUIDEbjy
__int64 __fastcall RakNet::RakPeer::Send(
        RakNet::RakPeer *this,
        _QWORD *a2,
        int a3,
        int a4,
        char a5,
        const RakNet::AddressOrGUID *a6,
        char a7,
        unsigned int a8,
        __int64 a9)
{
  unsigned int v13; // ebx
  __int64 v14; // r15
  unsigned int v15; // eax
  _BYTE v17[52]; // [rsp+8h] [rbp-68h] BYREF
  int v18; // [rsp+3Ch] [rbp-34h]
  int v19; // [rsp+40h] [rbp-30h]
  int v20; // [rsp+44h] [rbp-2Ch]

  v20 = a4; /*0x1039bbc39*/
  v18 = a3; /*0x1039bbc3c*/
  v13 = 0; /*0x1039bbc4e*/
  if ( (*(unsigned int (__fastcall **)(_QWORD))(*(_QWORD *)*a2 + 24LL))(a1: *a2) != 0 /*0x1039bbc85*/
    && *((_QWORD *)this + 92) != 0
    && (*((_BYTE *)this + 160) & 1) == 0
    && (a7 != 0 || (unsigned __int8)RakNet::AddressOrGUID::IsUndefined(this: a6) == 0) )
  {
    v13 = a8; /*0x1039bbc8b*/
    if ( a8 == 0 ) /*0x1039bbc90*/
      v13 = (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 160LL))(a1: this); /*0x1039bbc9e*/
    if ( a7 != 0 || RakNet::RakPeer::IsLoopbackAddress(this, a2: a6, a3: 1) == 0 ) /*0x1039bbcbc*/
    {
      v19 = 8 * (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*a2 + 24LL))(a1: *a2); /*0x1039bbd41*/
      RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v17, a2: a6); /*0x1039bbd4b*/
      RakNet::RakPeer::SendBufferedShared( /*0x1039bbd7f*/
        a1: (_DWORD)this,
        (_DWORD)a2,
        a3: v19,
        a4: v18,
        a5: v20,
        a6: a5,
        a7: (__int64)v17,
        a8: a7,
        a9: 0,
        a10: v13,
        a11: *(_BYTE *)(*a2 + 8LL),
        a12: a9);
    }
    else
    {
      v14 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*a2 + 16LL))(a1: *a2); /*0x1039bbcc8*/
      v15 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*a2 + 24LL))(a1: *a2); /*0x1039bbcd2*/
      (*(void (__fastcall **)(RakNet::RakPeer *, __int64, _QWORD))(*(_QWORD *)this + 176LL))(a1: this, a2: v14, a3: v15); /*0x1039bbce0*/
      if ( v20 >= 5 ) /*0x1039bbcea*/
      {
        v17[0] = 14; /*0x1039bbcf4*/
        RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2912)); /*0x1039bbd02*/
        *(_DWORD *)&v17[1] = *((_DWORD *)this + 744); /*0x1039bbd0e*/
        RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 2912)); /*0x1039bbd15*/
        (*(void (__fastcall **)(RakNet::RakPeer *, _BYTE *, __int64))(*(_QWORD *)this + 176LL))( /*0x1039bbd28*/
          a1: this,
          a2: v17,
          a3: 5);
      }
    }
  }
  return v13; /*0x1039bbd8a*/
}

// Address: 0x1039bbd9a | Name: __ZN6RakNet7RakPeer18SendBufferedSharedERNSt3__110shared_ptrIKN3RBX11NetworkCore17AbstractBitStreamEEEj14PacketPriority17PacketReliabilitycNS_13AddressOrGUIDEbNS0_18RemoteSystemStruct11ConnectModeEjby
int __fastcall RakNet::RakPeer::SendBufferedShared(
        RakNet *a1,
        _QWORD *a2,
        int a3,
        int a4,
        int a5,
        char a6,
        __int64 *a7,
        char a8,
        int a9,
        int a10,
        char a11,
        __int64 a12)
{
  RakNet *v16; // rdi
  RBX::Network *v17; // rdi
  __int64 v18; // rdx
  __int64 v19; // rsi
  __int64 v20; // rbx
  __int64 v21; // rbx
  unsigned __int8 v22; // al
  unsigned __int8 v23; // r14
  RakNet *v24; // rdi
  unsigned int TimeMS; // eax
  pthread_mutex_t *v26; // r12
  std::__shared_weak_count *v27; // rbx
  signed __int64 v28; // rax
  std::__shared_weak_count *v29; // rbx
  std::__shared_weak_count *v31[2]; // [rsp+0h] [rbp-180h] BYREF
  _BYTE v32[13]; // [rsp+10h] [rbp-170h]
  _OWORD v33[8]; // [rsp+20h] [rbp-160h] BYREF
  __int128 v34; // [rsp+A0h] [rbp-E0h] BYREF
  _DWORD v35[4]; // [rsp+B0h] [rbp-D0h]
  __int64 v36; // [rsp+C0h] [rbp-C0h] BYREF
  __int16 v37; // [rsp+C8h] [rbp-B8h]
  _BYTE v38[32]; // [rsp+D0h] [rbp-B0h] BYREF
  __int128 v39; // [rsp+F0h] [rbp-90h]
  __int128 v40; // [rsp+100h] [rbp-80h]
  __int128 v41; // [rsp+110h] [rbp-70h]
  __int128 v42; // [rsp+120h] [rbp-60h]
  __int128 v43; // [rsp+130h] [rbp-50h]
  int v44; // [rsp+14Ch] [rbp-34h]
  RakNet *v45; // [rsp+150h] [rbp-30h]

  v44 = a4; /*0x1039bbdb4*/
  v45 = a1; /*0x1039bbdbd*/
  v34 = 0; /*0x1039bbdcb*/
  RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)&v36); /*0x1039bbdcf*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v38); /*0x1039bbdde*/
  *((_QWORD *)&v40 + 1) = 0; /*0x1039bbdec*/
  *((_QWORD *)&v43 + 1) = 0; /*0x1039bbdf0*/
  std::shared_ptr<RBX::NetworkCore::AbstractBitStream const>::operator=[abi:ne200100](a1: &v34, a2); /*0x1039bbdfa*/
  *((_QWORD *)&v40 + 1) = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*a2 + 16LL))(a1: *a2); /*0x1039bbe0c*/
  v35[0] = a3; /*0x1039bbe10*/
  v35[1] = v44; /*0x1039bbe1a*/
  v35[2] = a5; /*0x1039bbe20*/
  LOBYTE(v35[3]) = a6; /*0x1039bbe27*/
  v36 = *a7; /*0x1039bbe31*/
  v37 = *((_WORD *)a7 + 4); /*0x1039bbe3c*/
  RakNet::SystemAddress::operator=(a1: v38, a2: a7 + 2); /*0x1039bbe4a*/
  LOBYTE(v39) = a8; /*0x1039bbe5c*/
  DWORD1(v39) = a9; /*0x1039bbe62*/
  LODWORD(v42) = a10; /*0x1039bbe68*/
  BYTE4(v42) = a11; /*0x1039bbe6b*/
  LODWORD(v43) = 0; /*0x1039bbe6f*/
  *((_QWORD *)&v42 + 1) = (unsigned int)RakNet::GetTimeMS(this: v16); /*0x1039bbe81*/
  *((_QWORD *)&v43 + 1) = a12; /*0x1039bbe85*/
  if ( a12 != 0 && DFFlag::EnablePingPongPerformanceTraceCLI != 0 ) /*0x1039bbe99*/
  {
    if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v17) != 0 ) /*0x1039bbea9*/
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039bbeae*/
        v20 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039bbeb0*/
      else
        v20 = 0; /*0x1039bbec1*/
      v22 = (*(__int64 (__fastcall **)(RakNet *, __int64, __int64, __int64))(*(_QWORD *)v45 + 200LL))( /*0x1039bbeca*/
              a1: v45,
              a2: v19,
              a3: v18,
              a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
      RBX::Network::NetworkTracer::addCheckpointToTracer(a1: v20, a2: a12, a3: v22, a4: 65); /*0x1039bbede*/
    }
    else
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039bbeb9*/
        v21 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039bbebb*/
      else
        v21 = 0; /*0x1039bbee5*/
      v23 = (*(__int64 (__fastcall **)(RakNet *, __int64, __int64, __int64))(*(_QWORD *)v45 + 200LL))( /*0x1039bbef4*/
              a1: v45,
              a2: v19,
              a3: v18,
              a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
      TimeMS = RakNet::GetTimeMS(this: v24); /*0x1039bbef7*/
      RBX::Network::NetworkTracer::addCheckpointToTracer_deprecated(a1: v21, a2: a12, a3: v23, a4: 65, a5: TimeMS); /*0x1039bbf0e*/
    }
  }
  v26 = (pthread_mutex_t *)((char *)v45 + 1288); /*0x1039bbf17*/
  boost::mutex::lock(this: (pthread_mutex_t *)((char *)v45 + 1288)); /*0x1039bbf21*/
  *(_OWORD *)v31 = v34; /*0x1039bbf35*/
  if ( *((_QWORD *)&v34 + 1) != 0 ) /*0x1039bbf3f*/
    _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v34 + 1) + 8LL)); /*0x1039bbf41*/
  qmemcpy(v32, v35, sizeof(v32)); /*0x1039bbf54*/
  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v33, a2: (const RakNet::AddressOrGUID *)&v36); /*0x1039bbf63*/
  v33[7] = v43; /*0x1039bbf7a*/
  v33[6] = v42; /*0x1039bbf8d*/
  v33[5] = v41; /*0x1039bbf91*/
  v33[4] = v40; /*0x1039bbf95*/
  v33[3] = v39; /*0x1039bbf99*/
  RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::push_back<std::move_iterator<RakNet::RakPeer::BufferedCommandStruct*>>( /*0x1039bbfaf*/
    a1: (char *)v45 + 1224,
    a2: v31);
  v27 = v31[1]; /*0x1039bbfb4*/
  if ( v31[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v31[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039bbfd0*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v27 + 16LL))(a1: v27); /*0x1039bbfd8*/
    std::__shared_weak_count::__release_weak(this: v27); /*0x1039bbfde*/
  }
  LODWORD(v28) = boost::mutex::unlock(this: v26); /*0x1039bbfe6*/
  if ( v44 == 0 ) /*0x1039bbfef*/
    LODWORD(v28) = RakNet::SignaledEvent::SetEvent(this: (RakNet *)((char *)v45 + 2560)); /*0x1039bbffc*/
  v29 = *((std::__shared_weak_count **)&v34 + 1); /*0x1039bc001*/
  if ( *((_QWORD *)&v34 + 1) != 0 ) /*0x1039bc00b*/
  {
    v28 = _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v34 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL); /*0x1039bc014*/
    if ( v28 == 0 ) /*0x1039bc01d*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v29 + 16LL))(a1: v29); /*0x1039bc025*/
      LODWORD(v28) = std::__shared_weak_count::__release_weak(this: v29); /*0x1039bc02b*/
    }
  }
  return v28; /*0x1039bc030*/
}

// Address: 0x1039bc06e | Name: __ZN6RakNet7RakPeer26logRakNetStoppedProductionERKj
void __fastcall RakNet::RakPeer::logRakNetStoppedProduction(RakNet::RakPeer *this, const unsigned int *a2)
{
  unsigned int v4; // r15d
  double v5; // xmm0_8
  __int64 v6; // rax
  _QWORD v7[9]; // [rsp+10h] [rbp-290h] BYREF
  _BYTE v8[536]; // [rsp+58h] [rbp-248h] BYREF
  __int64 v9; // [rsp+270h] [rbp-30h]
  _QWORD *v10; // [rsp+278h] [rbp-28h]
  double v11; // [rsp+280h] [rbp-20h]

  if ( *((_DWORD *)this + 188) != 0 ) /*0x1039bc086*/
  {
    ++*((_DWORD *)this + 900); /*0x1039bc092*/
    v4 = *a2 - *((_DWORD *)this + 902); /*0x1039bc09b*/
    v11 = (double)DFInt::RakNetStoppedProductionThresholdMs / 1000.0; /*0x1039bc0b2*/
    v5 = (double)(int)RBX::TaskScheduler::getDefaultTargetFps(this) * v11; /*0x1039bc0c3*/
    v6 = *((unsigned int *)this + 900); /*0x1039bc0c8*/
    if ( (double)(int)v6 > v5 ) /*0x1039bc0d6*/
    {
      if ( (unsigned __int64)*a2 - *((_QWORD *)this + 452) > DFInt::RakNetStoppedProductionIntervalMs ) /*0x1039bc0f3*/
      {
        *((_QWORD *)this + 452) = *a2; /*0x1039bc0f5*/
        if ( (unsigned __int8)DFLog::RakNetStoppedProduction >= 6u && BYTE1(DFLog::RakNetStoppedProduction) >= 6u ) /*0x1039bc112*/
        {
          v7[2] = v4; /*0x1039bc12d*/
          v9 = 17; /*0x1039bc131*/
          v10 = v7; /*0x1039bc139*/
          FLog::detail::FastLogSafeFormattedInternal( /*0x1039bc15f*/
            a1: DFLog::RakNetStoppedProduction,
            a2: qword_10D7BB740,
            a3: 6,
            a4: (unsigned int)"[DFLog::RakNetStoppedProduction] RakNet has not produced packets for {} frames / {} ms",
            a5: 86,
            a6: 1,
            17,
            v7,
            v6);
        }
      }
      if ( *((_BYTE *)this + 3624) == 0 ) /*0x1039bc16b*/
      {
        *((_BYTE *)this + 3624) = 1; /*0x1039bc16d*/
        RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1039bc182*/
          a1: (__int64)v7,
          a2: (__int64)&RBX::Telemetry::kRakNetStoppedProduction);
        RBX::Telemetry::FieldsContainer::addField( /*0x1039bc1aa*/
          a1: v8,
          a2: "FramesSinceLastPacketProduced",
          a3: 29,
          a4: *((int *)this + 900),
          a5: 1);
        RBX::Telemetry::FieldsContainer::addField( /*0x1039bc1c7*/
          a1: v8,
          a2: "TimeSinceLastPacketProducedMs",
          a3: 29,
          a4: (int)v4,
          a5: 1);
        RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v7); /*0x1039bc1d3*/
        RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v7); /*0x1039bc1e6*/
      }
    }
  }
}

// Address: 0x1039bc21a | Name: __ZN6RakNet7RakPeer13getNextPacketEv
__int64 __fastcall RakNet::RakPeer::getNextPacket(RakNet::RakPeer *this)
{
  RakNet::SimpleMutex *v2; // rbx
  int v3; // r8d
  int v4; // r9d
  int v5; // eax
  __int64 v6; // r14
  int v7; // eax
  int v8; // ecx
  __int64 v9; // rax
  int v10; // edx
  unsigned __int8 v11; // al
  const char *v12; // rcx

  v2 = (RakNet::RakPeer *)((char *)this + 2784); /*0x1039bc228*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2784)); /*0x1039bc232*/
  v5 = *((_DWORD *)this + 714); /*0x1039bc237*/
  v6 = 0; /*0x1039bc23f*/
  if ( v5 != *((_DWORD *)this + 715) ) /*0x1039bc250*/
  {
    v7 = v5 + 1; /*0x1039bc256*/
    v8 = *((_DWORD *)this + 716); /*0x1039bc258*/
    if ( v7 == v8 ) /*0x1039bc262*/
      v7 = 0; /*0x1039bc262*/
    *((_DWORD *)this + 714) = v7; /*0x1039bc266*/
    if ( v7 == 0 ) /*0x1039bc278*/
      v7 = v8; /*0x1039bc278*/
    v6 = *(_QWORD *)(*((_QWORD *)this + 356) + 8LL * (unsigned int)(v7 - 1)); /*0x1039bc27d*/
    if ( DFFlag::CLI56775 == 1 ) /*0x1039bc288*/
    {
      v9 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>::find<RakNet::SystemAddress>( /*0x1039bc297*/
             a1: (char *)this + 2872,
             a2: v6);
      if ( v9 != 0 ) /*0x1039bc29f*/
      {
        v10 = 0; /*0x1039bc2a8*/
        if ( *(_DWORD *)(v9 + 48) - *(_DWORD *)(v6 + 48) > 0 ) /*0x1039bc2ac*/
          v10 = *(_DWORD *)(v9 + 48) - *(_DWORD *)(v6 + 48); /*0x1039bc2ac*/
        *(_DWORD *)(v9 + 48) = v10; /*0x1039bc2af*/
      }
    }
    v11 = **(_BYTE **)(v6 + 56); /*0x1039bc2b6*/
    if ( ((unsigned int)v11 - 21 < 2 || v11 == 144) /*0x1039bc2e1*/
      && (unsigned __int8)DFLog::RaknetJoinOrDisconnectRequest >= 6u
      && BYTE1(DFLog::RaknetJoinOrDisconnectRequest) >= 3u )
    {
      v12 = "disconnect"; /*0x1039bc2fe*/
      if ( v11 == 0x90 ) /*0x1039bc305*/
        v12 = "join"; /*0x1039bc305*/
      FLog::FastLogFormatted( /*0x1039bc312*/
        a1: DFLog::RaknetJoinOrDisconnectRequest,
        a2: qword_10D7BB100,
        a3: (unsigned int)"[DFLog::RaknetJoinOrDisconnectRequest] RakNet Receiving %s packet",
        a4: (_DWORD)v12,
        a5: v3,
        a6: v4);
    }
  }
  RakNet::SimpleMutex::Unlock(this: v2); /*0x1039bc31f*/
  return v6; /*0x1039bc32a*/
}

// Address: 0x1039bc334 | Name: __ZN6RakNet7RakPeer13doReceiveLoopEb
__int64 __fastcall RakNet::RakPeer::doReceiveLoop(RakNet::RakPeer *this, int a2)
{
  unsigned int TimeMS; // r15d
  __int64 NextPacket; // rax
  char v6; // dl
  RBX::Network *v7; // rdi
  __int64 result; // rax
  __int64 v9; // r14
  char v10; // r12
  unsigned int RemoteSystemIndex; // eax
  __int64 v12; // rax
  _BYTE *v13; // rsi
  __int64 v14; // rdx
  __int64 v15; // rsi
  __int64 v16; // r13
  __int64 v17; // r12
  unsigned __int8 v18; // al
  __int64 v19; // r12
  unsigned __int8 v20; // r13
  RakNet *v21; // rdi
  unsigned int v22; // eax
  char v23; // dl
  const char *v24; // r14
  int v25; // r15d
  __int64 v26; // r12
  unsigned __int64 v27; // r13
  unsigned int v28; // [rsp+Ch] [rbp-34h] BYREF
  __int64 v29; // [rsp+10h] [rbp-30h]

  TimeMS = RakNet::GetTimeMS(this); /*0x1039bc350*/
  v28 = TimeMS; /*0x1039bc357*/
  RakNet::RakPeer::logRakNetStoppedProduction(this, a2: &v28); /*0x1039bc35c*/
  if ( a2 == 0 ) /*0x1039bc364*/
  {
    result = (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 128LL))(a1: this); /*0x1039bc415*/
    if ( (_BYTE)result == 0 ) /*0x1039bc41d*/
      return result; /*0x1039bc41d*/
    NextPacket = RakNet::RakPeer::getNextPacket(this); /*0x1039bc426*/
    if ( NextPacket == 0 ) /*0x1039bc42e*/
      goto LABEL_41; /*0x1039bc42e*/
    goto LABEL_12; /*0x1039bc42e*/
  }
  if ( (unsigned __int8)DFLog::ClientRecvFromRaknet >= 6u && BYTE1(DFLog::ClientRecvFromRaknet) >= 3u ) /*0x1039bc37f*/
    FLog::FastLog( /*0x1039bc39b*/
      a1: DFLog::ClientRecvFromRaknet,
      a2: qword_10D7BB078,
      a3: "[DFLog::ClientRecvFromRaknet] RakPeer has distributed %d packets to plugins since last debug time",
      *((_QWORD *)this + 390));
  if ( DFFlag::DebugRakPeerReceiveCountDistributedPackets == 1 ) /*0x1039bc3a7*/
    *((_QWORD *)this + 390) = 0; /*0x1039bc3a9*/
  if ( (*(unsigned __int8 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 128LL))(a1: this) != 0 ) /*0x1039bc3c2*/
  {
    NextPacket = RakNet::RakPeer::getNextPacket(this); /*0x1039bc3cb*/
    if ( NextPacket == 0 ) /*0x1039bc3d3*/
    {
      if ( (unsigned __int8)DFLog::ClientRecvFromRaknet >= 6u && BYTE1(DFLog::ClientRecvFromRaknet) >= 3u ) /*0x1039bc3ea*/
        FLog::FastLog( /*0x1039bc405*/
          a1: DFLog::ClientRecvFromRaknet,
          a2: qword_10D7BB078,
          a3: "[DFLog::ClientRecvFromRaknet] PacketReturnQueue is empty, no work to do",
          0);
LABEL_41:
      result = (__int64)&DFFlag::DebugNetworkProfiler; /*0x1039bc5e3*/
      if ( DFFlag::DebugNetworkProfiler == 1 ) /*0x1039bc5ed*/
      {
        result = (__int64)&DFFlag::DebugNetworkProfilerRakPeer; /*0x1039bc5f3*/
        if ( DFFlag::DebugNetworkProfilerRakPeer == 1 ) /*0x1039bc5fd*/
        {
          result = (__int64)"S:RakPeerRecv"; /*0x1039bc603*/
          v24 = "C:RakPeerRecv"; /*0x1039bc60a*/
          if ( *((_BYTE *)this + 3728) != 0 ) /*0x1039bc618*/
            v24 = "S:RakPeerRecv"; /*0x1039bc618*/
          v25 = *((_DWORD *)this + 194); /*0x1039bc61c*/
          if ( *((_QWORD *)this + 96) != 0 ) /*0x1039bc62b*/
          {
            v26 = 4164; /*0x1039bc631*/
            v27 = 0; /*0x1039bc637*/
            do /*0x1039bc690*/
            {
              result = RBX::NetworkProfiler::CapturePackets::hasData(this: (RBX::NetworkProfiler::CapturePackets *)(*((_QWORD *)this + 95) + v26 - 2084)); /*0x1039bc64c*/
              if ( (_BYTE)result != 0 ) /*0x1039bc653*/
                result = RBX::NetworkProfiler::CapturePackets::flush( /*0x1039bc67a*/
                           this: (RBX::NetworkProfiler::CapturePackets *)(*((_QWORD *)this + 95) + v26 - 2084),
                           a2: v24,
                           a3: *(_DWORD *)(*((_QWORD *)this + 95) + v26),
                           a4: v25,
                           a5: *(_DWORD *)(*((_QWORD *)this + 95) + v26 - 2084 + 2080));
              ++v27; /*0x1039bc67f*/
              v26 += 4176; /*0x1039bc682*/
            }
            while ( v27 < *((_QWORD *)this + 96) ); /*0x1039bc690*/
          }
        }
      }
      return result; /*0x1039bc690*/
    }
LABEL_12:
    v9 = NextPacket; /*0x1039bc434*/
    v10 = v6; /*0x1039bc437*/
    do /*0x1039bc5dd*/
    {
      *((_QWORD *)this + 451) = TimeMS; /*0x1039bc444*/
      *((_DWORD *)this + 900) = 0; /*0x1039bc44b*/
      if ( DFFlag::DebugNetworkProfiler == 1 && DFFlag::DebugNetworkProfilerRakPeer == 1 && *(_DWORD *)(v9 + 48) != 0 ) /*0x1039bc46d*/
      {
        RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, a2: (const RakNet::SystemAddress *)v9); /*0x1039bc475*/
        if ( *((_QWORD *)this + 96) > (unsigned __int64)RemoteSystemIndex ) /*0x1039bc483*/
        {
          v7 = *((RBX::Network **)this + 95); /*0x1039bc485*/
          v12 = 4176LL * RemoteSystemIndex; /*0x1039bc48c*/
          if ( (*((_BYTE *)v7 + v12 + 4168) & 1) != 0 ) /*0x1039bc49d*/
            RBX::NetworkProfiler::CapturePackets::record( /*0x1039bc4b4*/
              this: (RBX::Network *)((char *)v7 + v12 + 2080),
              a2: **(_BYTE **)(v9 + 56),
              a3: *(_DWORD *)(v9 + 48));
        }
      }
      if ( (v10 & 1) == 0 ) /*0x1039bc4bd*/
        *(_QWORD *)(v9 + 80) = TimeMS; /*0x1039bc4bf*/
      if ( *(_DWORD *)(v9 + 48) >= 9u ) /*0x1039bc4c8*/
      {
        v13 = *(_BYTE **)(v9 + 56); /*0x1039bc4ca*/
        if ( *v13 == 27 ) /*0x1039bc4d1*/
          RakNet::RakPeer::ShiftIncomingTimestamp(this, a2: v13 + 1, a3: (const RakNet::SystemAddress *)v9); /*0x1039bc4dc*/
      }
      if ( DFFlag::DebugRakPeerReceiveCountDistributedPackets == 1 ) /*0x1039bc4e8*/
        ++*((_QWORD *)this + 390); /*0x1039bc4ea*/
      if ( *((_QWORD *)this + 423) == 0 ) /*0x1039bc4f9*/
        goto LABEL_39; /*0x1039bc4f9*/
      if ( DFFlag::DataPingTrace == 1 && *(_QWORD *)(v9 + 96) != 0 ) /*0x1039bc511*/
      {
        if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v7) != 0 ) /*0x1039bc525*/
        {
          if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039bc52a*/
            v16 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039bc52c*/
          else
            v16 = 0; /*0x1039bc541*/
          v17 = *(_QWORD *)(v9 + 96); /*0x1039bc544*/
          v18 = (*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64))(*(_QWORD *)this + 200LL))( /*0x1039bc54e*/
                  a1: this,
                  a2: v15,
                  a3: v14,
                  a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
          RBX::Network::NetworkTracer::addCheckpointToTracer(a1: v16, a2: v17, a3: v18, a4: 72); /*0x1039bc562*/
        }
        else
        {
          if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039bc535*/
            v29 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039bc53b*/
          else
            v29 = 0; /*0x1039bc569*/
          v19 = *(_QWORD *)(v9 + 96); /*0x1039bc571*/
          v20 = (*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64))(*(_QWORD *)this + 200LL))( /*0x1039bc581*/
                  a1: this,
                  a2: v15,
                  a3: v14,
                  a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
          v22 = RakNet::GetTimeMS(this: v21); /*0x1039bc584*/
          RBX::Network::NetworkTracer::addCheckpointToTracer_deprecated(a1: v29, a2: v19, a3: v20, a4: 72, a5: v22); /*0x1039bc59c*/
        }
      }
      if ( (*(unsigned int (__fastcall **)(_QWORD, __int64))(**((_QWORD **)this + 423) + 24LL))( /*0x1039bc5bb*/
             a1: *((_QWORD *)this + 423),
             a2: v9) != 2 )
LABEL_39:
        (*(void (__fastcall **)(RakNet::RakPeer *, __int64))(*(_QWORD *)this + 240LL))(a1: this, a2: v9); /*0x1039bc5c6*/
      v9 = RakNet::RakPeer::getNextPacket(this); /*0x1039bc5d4*/
      v10 = v23; /*0x1039bc5d7*/
    }
    while ( v9 != 0 ); /*0x1039bc5dd*/
    goto LABEL_41; /*0x1039bc5dd*/
  }
  result = (unsigned int)DFLog::ClientRecvFromRaknet >> 8; /*0x1039bc69d*/
  LOBYTE(result) = (unsigned __int8)DFLog::ClientRecvFromRaknet < 6u || BYTE1(DFLog::ClientRecvFromRaknet) < 3u; /*0x1039bc6ac*/
  if ( (_BYTE)result == 0 ) /*0x1039bc6ae*/
    return FLog::FastLog( /*0x1039bc6ce*/
             a1: DFLog::ClientRecvFromRaknet,
             a2: qword_10D7BB078,
             a3: "[DFLog::ClientRecvFromRaknet] RakPeer is NOT active, returning",
             0);
  return result; /*0x1039bc6c0*/
}

// Address: 0x1039bc6e2 | Name: __ZNK6RakNet7RakPeer20GetRemoteSystemIndexERKNS_13SystemAddressE
__int64 __fastcall RakNet::RakPeer::GetRemoteSystemIndex(RakNet::RakPeer *this, const RakNet::SystemAddress *a2)
{
  unsigned __int64 v4; // r15
  _QWORD *v5; // r12
  unsigned int v6; // r15d

  v4 = 8; /*0x1039bc703*/
  if ( *((_WORD *)this + 85) != 0 ) /*0x1039bc709*/
    v4 = 8 * (unsigned int)*((unsigned __int16 *)this + 85); /*0x1039bc709*/
  v5 = *(_QWORD **)(*((_QWORD *)this + 98) + 8LL * (unsigned int)(RakNet::SystemAddress::ToInteger(this: a2, a2) % v4)); /*0x1039bc723*/
  v6 = -1; /*0x1039bc727*/
  while ( v5 != nullptr ) /*0x1039bc730*/
  {
    if ( (unsigned __int8)RakNet::SystemAddress::operator==( /*0x1039bc756*/
                            a1: *((_QWORD *)this + 92) + 5368LL * *(unsigned int *)v5 + 4,
                            a2) != 0 )
      return *(unsigned int *)v5; /*0x1039bc75f*/
    v5 = (_QWORD *)v5[1]; /*0x1039bc758*/
  }
  return v6; /*0x1039bc766*/
}

// Address: 0x1039bc770 | Name: __ZNK6RakNet7RakPeer22ShiftIncomingTimestampEPhRKNS_13SystemAddressE
void __fastcall RakNet::RakPeer::ShiftIncomingTimestamp(
        RakNet::RakPeer *this,
        unsigned __int8 *a2,
        const RakNet::SystemAddress *a3)
{
  __int64 UInt64; // rbx
  __int128 v6; // xmm0
  __int64 v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // rsi
  __int64 v10; // r8
  __int64 v11; // r9
  __int64 BestClockDifferential; // r14
  _BYTE v13[64]; // [rsp+20h] [rbp-80h] BYREF
  __int128 v14; // [rsp+60h] [rbp-40h] BYREF
  __int128 v15; // [rsp+70h] [rbp-30h]

  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v13, a2, a3: 8u, a4: false); /*0x1039bc794*/
  UInt64 = RBX::Network::NetworkStream::readUInt64(this: (RBX::Network::NetworkStream *)v13); /*0x1039bc7a1*/
  v6 = *(_OWORD *)a3; /*0x1039bc7a4*/
  v15 = *((_OWORD *)a3 + 1); /*0x1039bc7ad*/
  v14 = v6; /*0x1039bc7b1*/
  BestClockDifferential = RakNet::RakPeer::GetBestClockDifferential( /*0x1039bc7ce*/
                            a1: this,
                            a2: v9,
                            a3: v7,
                            a4: v8,
                            a5: v10,
                            a6: v11,
                            a7: v6,
                            a8: *((_QWORD *)&v6 + 1),
                            a9: v15,
                            a10: *((_QWORD *)&v15 + 1));
  RBX::Network::NetworkStream::SetWriteOffsetBytes(this: (RBX::Network::NetworkStream *)v13, a2: 0, a3: false); /*0x1039bc7d9*/
  *(_QWORD *)&v14 = UInt64 - BestClockDifferential; /*0x1039bc7e5*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v13, a2: &v14, a3: 8u); /*0x1039bc7f1*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v13); /*0x1039bc7fa*/
}

// Address: 0x1039bc822 | Name: __ZN6RakNet7RakPeer16DeallocatePacketEPNS_6PacketE
__int64 __fastcall RakNet::RakPeer::DeallocatePacket(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  if ( a2 != 0 ) /*0x1039bc82f*/
  {
    if ( *(_BYTE *)(a2 + 64) == 1 ) /*0x1039bc838*/
    {
      RBX::Memory::deallocate(this: *(RBX::Memory **)(a2 + 56), (void *)a2); /*0x1039bc841*/
      RakNet::SimpleMutex::Lock(this: (RakNet::SimpleMutex *)(a1 + 2688)); /*0x1039bc850*/
      DataStructures::MemoryPool<RakNet::Packet>::Release(a1: a1 + 2752, (_QWORD *)a2); /*0x1039bc86b*/
      return RakNet::SimpleMutex::Unlock(this: (RakNet::SimpleMutex *)(a1 + 2688)); /*0x1039bc87d*/
    }
    else
    {
      return RBX::Memory::deallocate(this: (RBX::Memory *)a2, (void *)a2); /*0x1039bc89a*/
    }
  }
  return result; /*0x1039bc877*/
}

// Address: 0x1039bc99e | Name: __ZNK6RakNet7RakPeer23GetMaximumNumberOfPeersEv
__int64 __fastcall RakNet::RakPeer::GetMaximumNumberOfPeers(RakNet::RakPeer *this)
{
  return *((unsigned __int16 *)this + 85); /*0x1039bc9a9*/
}

// Address: 0x1039bc9ac | Name: __ZN6RakNet7RakPeer15CloseConnectionENS_13AddressOrGUIDEbbh14PacketPriority
__int64 __fastcall RakNet::RakPeer::CloseConnection(RakNet::RakPeer *a1, RakNet::AddressOrGUID *a2)
{
  return RakNet::RakPeer::CloseConnectionInternal(this: a1, a2); /*0x1039bc9b5*/
}

// Address: 0x1039bc9bc | Name: __ZN6RakNet7RakPeer23CloseConnectionInternalERKNS_13AddressOrGUIDEbbh14PacketPriority
__int64 __fastcall RakNet::RakPeer::CloseConnectionInternal(
        RakNet::RakPeer *this,
        RakNet::AddressOrGUID *a2,
        char a3,
        char a4)
{
  int v8; // ecx
  int v9; // r8d
  int v10; // r9d
  unsigned int RemoteSystemIndex; // eax
  __int64 v12; // r15
  __int64 v13; // rcx
  __int64 v14; // rax
  __int64 v15; // rax
  __int128 v17; // [rsp+20h] [rbp-470h] BYREF
  __int128 v18[2]; // [rsp+30h] [rbp-460h] BYREF
  char v19[1040]; // [rsp+50h] [rbp-440h] BYREF

  if ( (unsigned __int8)RakNet::AddressOrGUID::IsUndefined(this: a2) == 0
    && *((_QWORD *)this + 92) != 0
    && (*((_BYTE *)this + 160) & 1) == 0 )
  {
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v18); /*0x1039bca1d*/
    if ( (unsigned __int8)RakNet::SystemAddress::operator!=(a1: (char *)a2 + 16, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 ) /*0x1039bca37*/
    {
      RakNet::SystemAddress::operator=(a1: v18, a2: (char *)a2 + 16); /*0x1039bca43*/
    }
    else
    {
      (*(void (__fastcall **)(char *, RakNet::RakPeer *, _QWORD, _QWORD))(*(_QWORD *)this + 432LL))( /*0x1039bca5e*/
        a1: v19,
        a2: this,
        a3: *(_QWORD *)a2,
        a4: *((unsigned int *)a2 + 2));
      RakNet::SystemAddress::operator=(a1: v18, a2: v19); /*0x1039bca72*/
    }
    if ( ((unsigned __int8)a4 /*0x1039bca8f*/
        & (unsigned __int8)RakNet::SystemAddress::operator!=(a1: v18, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS)) == 1 )
      RakNet::SystemAddress::FixForIPVersion( /*0x1039bcaa6*/
        this: (RakNet::SystemAddress *)v18,
        a2: (const RakNet::SystemAddress *)(**((_QWORD **)this + 253) + 8LL));
    if ( a3 != 0 )
    {
      RakNet::RakPeer::NotifyAndFlagForShutdown( /*0x1039bcad0*/
        a1: this,
        a2: a4,
        a3: 0,
        a4: v8,
        a5: v9,
        a6: v10,
        a7: v18[0],
        a8: v18[1]);
    }
    else if ( a4 != 0 )
    {
      RakNet::AddressOrGUID::ToStringN(this: a2, a2: true, a3: v19, a4: 1025); /*0x1039bcaf7*/
      if ( (unsigned __int8)DFLog::NetworkAudit >= 6u && BYTE1(DFLog::NetworkAudit) >= 3u )
        FLog::FastLog(
          a1: DFLog::NetworkAudit,
          a2: qword_10D783528,
          a3: "[DFLog::NetworkAudit] RakNet Disconnect: Closing connection to %s",
          v19);
      RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, a2: (const RakNet::SystemAddress *)v18); /*0x1039bcb3d*/
      if ( RemoteSystemIndex != -1 ) /*0x1039bcb45*/
      {
        v12 = 5368LL * RemoteSystemIndex; /*0x1039bcb54*/
        if ( (*(_BYTE *)(*((_QWORD *)this + 92) + v12) & 1) != 0 ) /*0x1039bcb61*/
        {
          v13 = *((_QWORD *)this + 92); /*0x1039bcb67*/
          v14 = *(_QWORD *)(v13 + v12 + 5240); /*0x1039bcb6e*/
          v17 = *(_OWORD *)(v13 + v12 + 5232); /*0x1039bcb7f*/
          if ( v14 != 0 ) /*0x1039bcb89*/
            _InterlockedIncrement64((volatile signed __int64 *)(v14 + 8)); /*0x1039bcb8b*/
          RakNet::RakPeer::FlushArtificialLatencyTransmitPacketsForSocket(a1: this, a2: &v17); /*0x1039bcb9a*/
          std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: &v17); /*0x1039bcba6*/
          RakNet::RakPeer::RemoveFromActiveSystemList(this, a2: (const RakNet::SystemAddress *)v18); /*0x1039bcbb5*/
          *(_BYTE *)(*((_QWORD *)this + 92) + v12) = 0; /*0x1039bcbc3*/
          v15 = *((_QWORD *)this + 92); /*0x1039bcbc7*/
          *(_QWORD *)(v15 + v12 + 5200) = RakNet::UNASSIGNED_RAKNET_GUID; /*0x1039bcbd5*/
          *(_WORD *)(v15 + v12 + 5208) = word_10CC85C98; /*0x1039bcbe4*/
          if ( DFFlag::CLI56775 == 1 ) /*0x1039bcbf4*/
          {
            RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2784)); /*0x1039bcc00*/
            std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>::__erase_unique<RakNet::SystemAddress>( /*0x1039bcc13*/
              a1: (char *)this + 2872,
              a2: v18);
            RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 2784)); /*0x1039bcc1b*/
            v15 = *((_QWORD *)this + 92); /*0x1039bcc20*/
          }
          RakNet::ReliabilityLayer::Reset( /*0x1039bcc3c*/
            this: (RakNet::ReliabilityLayer *)(v15 + v12 + 392),
            a2: false,
            a3: *(_DWORD *)(v15 + v12 + 5216),
            a4: false);
          std::shared_ptr<RakNet::RakNetSocket>::reset[abi:ne200100](a1: *((_QWORD *)this + 92) + v12 + 5232); /*0x1039bcc53*/
        }
      }
    }
  }
  return __stack_chk_guard; /*0x1039bcc68*/
}

// Address: 0x1039bcc9c | Name: __ZN6RakNet7RakPeer18GetConnectionStateENS_13AddressOrGUIDE
__int64 __fastcall RakNet::RakPeer::GetConnectionState(__int64 a1, __int64 a2)
{
  _QWORD *v4; // r15
  unsigned int i; // r12d
  unsigned int v6; // eax
  unsigned int v7; // edx
  bool v8; // cf
  unsigned int v9; // edx
  unsigned int v10; // edx
  char v11; // al
  __int64 result; // rax
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // r8
  __int64 v16; // r9
  int IndexFromSystemAddress; // eax
  int v18; // ecx
  __int64 v19; // rcx
  unsigned int v20; // ecx
  RakNet::SimpleMutex *v21; // [rsp+20h] [rbp-30h]

  v4 = (_QWORD *)(a2 + 16); /*0x1039bccb3*/
  if ( (unsigned __int8)RakNet::SystemAddress::operator!=(a1: a2 + 16, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 ) /*0x1039bccc8*/
  {
    v21 = (RakNet::SimpleMutex *)(a1 + 1160); /*0x1039bccd1*/
    RakNet::SimpleMutex::Lock(this: (RakNet::SimpleMutex *)(a1 + 1160)); /*0x1039bccd5*/
    for ( i = 0; ; ++i ) /*0x1039bccdd*/
    {
      v6 = *(_DWORD *)(a1 + 1144); /*0x1039bcce0*/
      v7 = *(_DWORD *)(a1 + 1148); /*0x1039bccec*/
      v8 = v7 < v6; /*0x1039bccee*/
      v9 = v7 - v6; /*0x1039bccee*/
      if ( v8 ) /*0x1039bccf0*/
        v9 = *(_DWORD *)(a1 + 1152) + *(_DWORD *)(a1 + 1148) - v6; /*0x1039bccfa*/
      if ( i >= v9 ) /*0x1039bccff*/
        break; /*0x1039bccff*/
      v10 = *(_DWORD *)(a1 + 1152); /*0x1039bcd05*/
      if ( i + v6 < v10 ) /*0x1039bcd0d*/
        v10 = 0; /*0x1039bcd0d*/
      v11 = RakNet::SystemAddress::operator==(a1: *(_QWORD *)(*(_QWORD *)(a1 + 1136) + 8LL * (i + v6 - v10)), a2: v4); /*0x1039bcd24*/
      if ( v11 != 0 ) /*0x1039bcd2e*/
      {
        RakNet::SimpleMutex::Unlock(this: v21); /*0x1039bcd34*/
        return 0; /*0x1039bcd3b*/
      }
    }
    RakNet::SimpleMutex::Unlock(this: v21); /*0x1039bcd44*/
  }
  if ( (unsigned __int8)RakNet::SystemAddress::operator!=(a1: v4, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 ) /*0x1039bcd5a*/
    IndexFromSystemAddress = RakNet::RakPeer::GetIndexFromSystemAddress( /*0x1039bcd73*/
                               a1,
                               a2: 0,
                               a3: v13,
                               a4: v14,
                               a5: v15,
                               a6: v16,
                               a7: *v4,
                               a8: v4[1],
                               a9: v4[2],
                               a10: v4[3]);
  else
    IndexFromSystemAddress = RakNet::RakPeer::GetIndexFromGuid(a1, a2: *(_QWORD *)a2, a3: *(unsigned int *)(a2 + 8)); /*0x1039bcd84*/
  v18 = IndexFromSystemAddress; /*0x1039bcd89*/
  result = 6; /*0x1039bcd8b*/
  if ( v18 != -1 ) /*0x1039bcd93*/
  {
    v19 = 5368LL * v18; /*0x1039bcd9f*/
    result = 5; /*0x1039bcda9*/
    if ( (*(_BYTE *)(*(_QWORD *)(a1 + 736) + v19) & 1) != 0 ) /*0x1039bcdb1*/
    {
      v20 = *(_DWORD *)(*(_QWORD *)(a1 + 736) + v19 + 5364) - 1; /*0x1039bcdc1*/
      result = 6; /*0x1039bcdc3*/
      if ( v20 <= 6 ) /*0x1039bcdcb*/
        return dword_10957ADC4[v20]; /*0x1039bcdd6*/
    }
  }
  return result; /*0x1039bcdd9*/
}

// Address: 0x1039bcde8 | Name: __ZNK6RakNet7RakPeer25GetIndexFromSystemAddressENS_13SystemAddressEb
__int64 __fastcall RakNet::RakPeer::GetIndexFromSystemAddress(
        __int64 a1,
        char a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7,
        __int64 a8,
        __int64 a9,
        __int64 a10)
{
  unsigned int v12; // ebx
  __int64 v13; // r13
  unsigned __int64 v14; // r12
  unsigned __int64 v15; // rax
  __int64 v16; // r13

  v12 = -1; /*0x1039bce0f*/
  if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: &a7, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) == 0 ) /*0x1039bce16*/
  {
    if ( HIWORD(a10) != 0xFFFF /*0x1039bce6d*/
      && HIWORD(a10) < *(_WORD *)(a1 + 170)
      && (unsigned __int8)RakNet::SystemAddress::operator==(
                            a1: *(_QWORD *)(a1 + 736) + 5368LL * HIWORD(a10) + 4,
                            a2: &a7) != 0
      && (*(_BYTE *)(*(_QWORD *)(a1 + 736) + 5368LL * HIWORD(a10)) & 1) != 0 )
    {
      return HIWORD(a10); /*0x1039bce6f*/
    }
    else if ( a2 != 0 ) /*0x1039bce7c*/
    {
      return (unsigned int)RakNet::RakPeer::GetRemoteSystemIndex( /*0x1039bce89*/
                             this: (RakNet::RakPeer *)a1,
                             a2: (const RakNet::SystemAddress *)&a7);
    }
    else if ( *(_WORD *)(a1 + 170) != 0 ) /*0x1039bce99*/
    {
      v13 = 4; /*0x1039bce9f*/
      v14 = 0; /*0x1039bcea5*/
      while ( (*(_BYTE *)(*(_QWORD *)(a1 + 736) + v13 - 4) & 1) == 0 /*0x1039bcecc*/
           || (unsigned __int8)RakNet::SystemAddress::operator==(a1: v13 + *(_QWORD *)(a1 + 736), a2: &a7) == 0 )
      {
        ++v14; /*0x1039bcece*/
        v15 = *(unsigned __int16 *)(a1 + 170); /*0x1039bced1*/
        v13 += 5368; /*0x1039bced9*/
        if ( v14 >= v15 ) /*0x1039bcee3*/
        {
          if ( (_WORD)v15 == 0 ) /*0x1039bcee8*/
            return v12; /*0x1039bcee8*/
          v16 = 4; /*0x1039bceea*/
          v14 = 0; /*0x1039bcef0*/
          while ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: v16 + *(_QWORD *)(a1 + 736), a2: &a7) == 0 ) /*0x1039bcf07*/
          {
            ++v14; /*0x1039bcf09*/
            v16 += 5368; /*0x1039bcf14*/
            if ( v14 >= *(unsigned __int16 *)(a1 + 170) ) /*0x1039bcf1e*/
              return v12; /*0x1039bcf1e*/
          }
          return (unsigned int)v14; /*0x1039bcf07*/
        }
      }
      return (unsigned int)v14; /*0x1039bcf22*/
    }
  }
  return v12; /*0x1039bcf2b*/
}

// Address: 0x1039bcf36 | Name: __ZN6RakNet7RakPeer16GetIndexFromGuidENS_10RakNetGUIDE
__int64 __fastcall RakNet::RakPeer::GetIndexFromGuid(__int64 a1, __int64 a2, unsigned __int16 a3)
{
  unsigned int v4; // ebx
  __int64 v5; // r13
  unsigned __int64 v6; // r12
  unsigned __int64 v7; // rax
  __int64 v8; // r13
  __int64 v10; // [rsp+8h] [rbp-38h] BYREF
  unsigned __int16 v11; // [rsp+10h] [rbp-30h]

  v10 = a2; /*0x1039bcf4e*/
  v11 = a3; /*0x1039bcf51*/
  v4 = -1; /*0x1039bcf61*/
  if ( (unsigned __int8)RakNet::RakNetGUID::operator==(a1: &v10, a2: &RakNet::UNASSIGNED_RAKNET_GUID) == 0 ) /*0x1039bcf68*/
  {
    if ( v11 != 0xFFFF /*0x1039bcfc1*/
      && v11 < *(_WORD *)(a1 + 170)
      && (unsigned __int8)RakNet::RakNetGUID::operator==(a1: *(_QWORD *)(a1 + 736) + 5368LL * v11 + 5200, a2: &v10) != 0
      && (*(_BYTE *)(*(_QWORD *)(a1 + 736) + 5368LL * v11) & 1) != 0 )
    {
      return v11; /*0x1039bcfc3*/
    }
    else if ( *(_WORD *)(a1 + 170) != 0 ) /*0x1039bcfd5*/
    {
      v5 = 5200; /*0x1039bcfdb*/
      v6 = 0; /*0x1039bcfe1*/
      while ( (*(_BYTE *)(*(_QWORD *)(a1 + 736) + v5 - 5200) & 1) == 0 /*0x1039bd00f*/
           || (unsigned __int8)RakNet::RakNetGUID::operator==(a1: v5 + *(_QWORD *)(a1 + 736), a2: &v10) == 0 )
      {
        ++v6; /*0x1039bd011*/
        v7 = *(unsigned __int16 *)(a1 + 170); /*0x1039bd014*/
        v5 += 5368; /*0x1039bd01c*/
        if ( v6 >= v7 ) /*0x1039bd026*/
        {
          if ( (_WORD)v7 == 0 ) /*0x1039bd02b*/
            return v4; /*0x1039bd02b*/
          v8 = 5200; /*0x1039bd02d*/
          v6 = 0; /*0x1039bd033*/
          while ( (unsigned __int8)RakNet::RakNetGUID::operator==(a1: v8 + *(_QWORD *)(a1 + 736), a2: &v10) == 0 ) /*0x1039bd04e*/
          {
            ++v6; /*0x1039bd050*/
            v8 += 5368; /*0x1039bd05b*/
            if ( v6 >= *(unsigned __int16 *)(a1 + 170) ) /*0x1039bd065*/
              return v4; /*0x1039bd065*/
          }
          return (unsigned int)v6; /*0x1039bd04e*/
        }
      }
      return (unsigned int)v6; /*0x1039bd069*/
    }
  }
  return v4; /*0x1039bd06e*/
}

// Address: 0x1039bd07e | Name: __ZNK6RakNet7RakPeer25GetIndexFromSystemAddressENS_13SystemAddressE
__int64 __fastcall RakNet::RakPeer::GetIndexFromSystemAddress(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7,
        __int64 a8,
        __int64 a9,
        __int64 a10)
{
  return RakNet::RakPeer::GetIndexFromSystemAddress(a1, a2: 0, a3, a4, a5, a6, a7, a8, a9, a10); /*0x1039bd084*/
}

// Address: 0x1039bd08a | Name: __ZN6RakNet7RakPeer25GetSystemAddressFromIndexEi
RakNet::RakPeer *__fastcall RakNet::RakPeer::GetSystemAddressFromIndex(RakNet::RakPeer *this, __int64 a2, int a3)
{
  RakNet::RakPeer *result; // rax
  __int64 v4; // rcx
  __int64 v5; // rdx
  __int64 v6; // rdx
  __int128 v7; // xmm0

  result = this; /*0x1039bd08e*/
  if ( a3 >= 0 /*0x1039bd0c7*/
    && *(unsigned __int16 *)(a2 + 170) > (unsigned int)a3
    && (v4 = 5368LL * (unsigned int)a3, (*(_BYTE *)(*(_QWORD *)(a2 + 736) + v4) & 1) != 0)
    && *(_DWORD *)((v5 = *(_QWORD *)(a2 + 736)) + v4 + 5364) == 7 )
  {
    v6 = v4 + v5; /*0x1039bd0c9*/
    v7 = *(_OWORD *)(v6 + 4); /*0x1039bd0cc*/
    *((_OWORD *)this + 1) = *(_OWORD *)(v6 + 20); /*0x1039bd0d4*/
  }
  else
  {
    *((_OWORD *)this + 1) = *(__int128 *)((char *)&xmmword_10CDB0CBC + 4); /*0x1039bd0e1*/
    v7 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039bd0e5*/
  }
  *(_OWORD *)this = v7; /*0x1039bd0ec*/
  return result; /*0x1039bd0ef*/
}

// Address: 0x1039bd0f2 | Name: __ZN6RakNet7RakPeer16GetGUIDFromIndexEi
__int64 __fastcall RakNet::RakPeer::GetGUIDFromIndex(RakNet::RakPeer *this, int a2)
{
  __int64 *v2; // rax
  __int64 v3; // rsi
  __int64 v4; // rdx

  v2 = &RakNet::UNASSIGNED_RAKNET_GUID; /*0x1039bd0fd*/
  if ( a2 >= 0 && *((unsigned __int16 *)this + 85) > (unsigned int)a2 ) /*0x1039bd111*/
  {
    v3 = 5368LL * (unsigned int)a2; /*0x1039bd11c*/
    if ( (*(_BYTE *)(*((_QWORD *)this + 92) + v3) & 1) != 0 ) /*0x1039bd129*/
    {
      v4 = *((_QWORD *)this + 92); /*0x1039bd12b*/
      if ( *(_DWORD *)(v4 + v3 + 5364) == 7 ) /*0x1039bd13a*/
        v2 = (__int64 *)(v3 + v4 + 5200); /*0x1039bd13f*/
    }
  }
  return *v2; /*0x1039bd156*/
}

// Address: 0x1039bd158 | Name: __ZNK6RakNet7RakPeer13GetSystemListERN14DataStructures4ListINS_13SystemAddressEEERNS2_INS_10RakNetGUIDEEE
void __fastcall RakNet::RakPeer::GetSystemList(__int64 a1, __int64 a2, __int64 a3)
{
  unsigned __int64 v6; // r13
  __int64 v7; // rsi

  if ( *(_DWORD *)(a2 + 12) != 0 ) /*0x1039bd173*/
  {
    if ( *(_QWORD *)a2 != 0 ) /*0x1039bd17b*/
      operator delete[](a1: *(void **)a2); /*0x1039bd17d*/
    *(_OWORD *)a2 = 0; /*0x1039bd185*/
  }
  if ( *(_DWORD *)(a3 + 12) != 0 ) /*0x1039bd18d*/
  {
    if ( *(_QWORD *)a3 != 0 ) /*0x1039bd195*/
      operator delete[](a1: *(void **)a3); /*0x1039bd197*/
    *(_OWORD *)a3 = 0; /*0x1039bd19f*/
  }
  if ( *(_QWORD *)(a1 + 736) != 0 && (*(_BYTE *)(a1 + 160) & 1) == 0 && *(_DWORD *)(a1 + 752) != 0 ) /*0x1039bd1c4*/
  {
    v6 = 0; /*0x1039bd1c6*/
    do /*0x1039bd233*/
    {
      if ( (**(_BYTE **)(*(_QWORD *)(a1 + 744) + 8 * v6) & 1) != 0 ) /*0x1039bd1df*/
      {
        v7 = *(_QWORD *)(*(_QWORD *)(a1 + 744) + 8 * v6); /*0x1039bd1e8*/
        if ( *(_DWORD *)(v7 + 5364) == 7 ) /*0x1039bd1f3*/
        {
          DataStructures::List<RakNet::SystemAddress>::Insert(a1: a2, a2: v7 + 4, a3: (__int64)"", a4: 0); /*0x1039bd201*/
          DataStructures::List<RakNet::RakNetGUID>::Insert( /*0x1039bd221*/
            a1: (__int64 *)a3,
            a2: *(_QWORD *)(*(_QWORD *)(a1 + 744) + 8 * v6) + 5200LL,
            a3: (__int64)"",
            a4: 0);
        }
      }
      ++v6; /*0x1039bd226*/
    }
    while ( v6 < *(unsigned int *)(a1 + 752) ); /*0x1039bd233*/
  }
}

// Address: 0x1039bd244 | Name: __ZN6RakNet7RakPeer12AddToBanListERKNS_13SystemAddressEj
__int64 __fastcall RakNet::RakPeer::AddToBanList(RakNet::RakPeer *this, const RakNet::SystemAddress *a2, int a3)
{
  int TimeMS; // r12d
  __int64 v6; // rax
  int v7; // r12d
  const RakNet::SystemAddress *v9; // r13
  __int64 v10; // rbx
  int v11; // r12d
  __int128 v12; // xmm0
  __int64 v13; // r12
  unsigned int RemoteSystemIndex; // eax
  __int64 v15; // rcx
  char *v16; // r15
  RakNet::SimpleMutex *v17; // rbx
  _QWORD v18[4]; // [rsp+0h] [rbp-70h] BYREF
  const RakNet::SystemAddress *v19; // [rsp+28h] [rbp-48h]
  char *v20; // [rsp+30h] [rbp-40h]
  RakNet::SimpleMutex *v21; // [rsp+38h] [rbp-38h]
  int v22; // [rsp+40h] [rbp-30h]
  _BYTE v23[41]; // [rsp+47h] [rbp-29h] BYREF

  v22 = a3; /*0x1039bd255*/
  TimeMS = RakNet::GetTimeMS(this); /*0x1039bd263*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1032)); /*0x1039bd270*/
  v19 = a2; /*0x1039bd27f*/
  v6 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>>>::find<RakNet::SystemAddress>( /*0x1039bd286*/
         a1: (char *)this + 1096,
         a2);
  if ( v6 != 0 ) /*0x1039bd28e*/
  {
    v7 = v22 + TimeMS; /*0x1039bd293*/
    if ( v22 == 0 ) /*0x1039bd298*/
      v7 = 0; /*0x1039bd298*/
    *(_DWORD *)(*(_QWORD *)(v6 + 48) + 32LL) = v7; /*0x1039bd2a0*/
    return RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 1032)); /*0x1039bd2b5*/
  }
  else
  {
    v9 = v19; /*0x1039bd2ba*/
    v20 = (char *)this + 1096; /*0x1039bd2be*/
    v21 = (RakNet::RakPeer *)((char *)this + 1032); /*0x1039bd2c2*/
    RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 1032)); /*0x1039bd2c9*/
    v10 = operator new(a1: 0x28u); /*0x1039bd2d8*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v10); /*0x1039bd2de*/
    *(_BYTE *)(v10 + 36) = 0; /*0x1039bd2e3*/
    RakNet::SystemAddress::operator=(a1: v10, a2: v9); /*0x1039bd2f0*/
    v11 = v22 + TimeMS; /*0x1039bd2f8*/
    if ( v22 == 0 ) /*0x1039bd2fd*/
      v11 = 0; /*0x1039bd2fd*/
    *(_DWORD *)(v10 + 32) = v11; /*0x1039bd301*/
    v12 = *(_OWORD *)v9; /*0x1039bd305*/
    *(_OWORD *)&v18[2] = *((_OWORD *)v9 + 1); /*0x1039bd313*/
    *(_OWORD *)v18 = v12; /*0x1039bd317*/
    v13 = v10; /*0x1039bd328*/
    if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: v18, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 /*0x1039bd33c*/
      || (RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, a2: (const RakNet::SystemAddress *)v18)) == -1 )
    {
      v16 = v20; /*0x1039bd36c*/
      v17 = v21; /*0x1039bd370*/
    }
    else
    {
      v15 = *((_QWORD *)this + 92); /*0x1039bd33e*/
      v16 = v20; /*0x1039bd348*/
      v17 = v21; /*0x1039bd34c*/
      if ( v15 != 0 ) /*0x1039bd350*/
        *(_BYTE *)(v13 + 36) = *(_QWORD *)(v15 + 5368LL * RemoteSystemIndex + 5280) != 0; /*0x1039bd364*/
    }
    RakNet::SimpleMutex::Lock(this: v17); /*0x1039bd377*/
    v18[0] = v9; /*0x1039bd380*/
    *(_QWORD *)(std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>>>::__emplace_unique_key_args<RakNet::SystemAddress,std::piecewise_construct_t const&,std::tuple<RakNet::SystemAddress const&>,std::tuple<>>( /*0x1039bd399*/
                  a1: v16,
                  a2: v9,
                  a3: std::piecewise_construct,
                  a4: v18,
                  a5: v23)
              + 48) = v13;
    return RakNet::SimpleMutex::Unlock(this: v17); /*0x1039bd3a0*/
  }
}

// Address: 0x1039bd3c8 | Name: __ZNK6RakNet7RakPeer32GetRemoteSystemFromSystemAddressENS_13SystemAddressEbbi
__int64 __fastcall RakNet::RakPeer::GetRemoteSystemFromSystemAddress(
        __int64 a1,
        char a2,
        unsigned __int8 a3,
        int a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  __int64 v10; // r15
  __int64 v12; // rax
  unsigned int v13; // ecx
  unsigned int v14; // edx
  unsigned int v15; // r13d
  __int64 v16; // r14
  unsigned int v18; // [rsp+4h] [rbp-2Ch]

  if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: &a7, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 ) /*0x1039bd3f4*/
    return 0; /*0x1039bd3f4*/
  if ( a2 == 0 ) /*0x1039bd40e*/
  {
    v13 = *(unsigned __int16 *)(a1 + 170); /*0x1039bd448*/
    v10 = 0; /*0x1039bd44f*/
    if ( *(_WORD *)(a1 + 170) == 0 ) /*0x1039bd454*/
      return v10; /*0x1039bd454*/
    v18 = -1; /*0x1039bd456*/
    do /*0x1039bd4be*/
    {
      v14 = v10; /*0x1039bd45d*/
      if ( a4 != -1 ) /*0x1039bd464*/
        v14 = (a4 + (int)v10) % v13; /*0x1039bd46c*/
      v15 = v14; /*0x1039bd475*/
      v16 = 5368LL * v14; /*0x1039bd478*/
      if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: *(_QWORD *)(a1 + 736) + v16 + 4, a2: &a7) != 0 ) /*0x1039bd492*/
      {
        if ( (*(_BYTE *)(*(_QWORD *)(a1 + 736) + v16) & 1) != 0 ) /*0x1039bd4a1*/
          return *(_QWORD *)(a1 + 736) + v16; /*0x1039bd4f5*/
        if ( v18 != -1 ) /*0x1039bd4a9*/
          v15 = v18; /*0x1039bd4a9*/
        v18 = v15; /*0x1039bd4ad*/
      }
      LODWORD(v10) = v10 + 1; /*0x1039bd4b1*/
      v13 = *(unsigned __int16 *)(a1 + 170); /*0x1039bd4b4*/
    }
    while ( (unsigned int)v10 < v13 ); /*0x1039bd4be*/
    if ( (a3 | (v18 == -1)) != 0 ) /*0x1039bd4cc*/
      return 0; /*0x1039bd4cc*/
    v12 = v18; /*0x1039bd4d2*/
    return *(_QWORD *)(a1 + 736) + 5368 * v12; /*0x1039bd4e6*/
  }
  LODWORD(v12) = RakNet::RakPeer::GetRemoteSystemIndex( /*0x1039bd417*/
                   this: (RakNet::RakPeer *)a1,
                   a2: (const RakNet::SystemAddress *)&a7);
  if ( (_DWORD)v12 != -1 ) /*0x1039bd41f*/
  {
    if ( a3 == 0 ) /*0x1039bd425*/
    {
      v12 = (unsigned int)v12; /*0x1039bd4d6*/
      return *(_QWORD *)(a1 + 736) + 5368 * v12; /*0x1039bd4d6*/
    }
    v12 = (unsigned int)v12; /*0x1039bd432*/
    if ( (*(_BYTE *)(*(_QWORD *)(a1 + 736) + 5368LL * (unsigned int)v12) & 1) != 0 ) /*0x1039bd441*/
      return *(_QWORD *)(a1 + 736) + 5368 * v12; /*0x1039bd441*/
  }
  return 0; /*0x1039bd400*/
}

// Address: 0x1039bd4fa | Name: __ZN6RakNet7RakPeer12ClearBanListEv
__int64 __fastcall RakNet::RakPeer::ClearBanList(RakNet::RakPeer *this)
{
  char *v2; // r14
  RakNet::SimpleMutex *v3; // rbx
  _QWORD *i; // r15
  void *v5; // rdi
  __int64 result; // rax

  if ( *((_QWORD *)this + 140) != 0 ) /*0x1039bd502*/
  {
    v2 = (char *)this + 1096; /*0x1039bd511*/
    v3 = (RakNet::RakPeer *)((char *)this + 1032); /*0x1039bd518*/
    RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1032)); /*0x1039bd522*/
    for ( i = *((_QWORD **)this + 139); i != nullptr; i = (_QWORD *)*i ) /*0x1039bd527*/
    {
      v5 = (void *)i[6]; /*0x1039bd533*/
      if ( v5 != nullptr ) /*0x1039bd53a*/
        operator delete(a1: v5); /*0x1039bd53c*/
    }
    std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>>>::clear(a1: v2); /*0x1039bd549*/
    return RakNet::SimpleMutex::Unlock(this: v3); /*0x1039bd55b*/
  }
  return result; /*0x1039bd560*/
}

// Address: 0x1039bd562 | Name: __ZN6RakNet7RakPeer29SetLimitIPConnectionFrequencyEb
void __fastcall RakNet::RakPeer::SetLimitIPConnectionFrequency(RakNet::RakPeer *this, char a2)
{
  *((_BYTE *)this + 2680) = a2; /*0x1039bd566*/
}

// Address: 0x1039bd570 | Name: __ZN6RakNet7RakPeer8IsBannedERKNS_13SystemAddressE
bool __fastcall RakNet::RakPeer::IsBanned(RakNet::RakPeer *this, const RakNet::SystemAddress *a2)
{
  char *v3; // r15
  RakNet::SimpleMutex *v4; // rbx
  __int64 v5; // r14

  if ( *((_QWORD *)this + 140) == 0 ) /*0x1039bd578*/
    return false; /*0x1039bd5c7*/
  v3 = (char *)this + 1096; /*0x1039bd58a*/
  v4 = (RakNet::RakPeer *)((char *)this + 1032); /*0x1039bd591*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1032)); /*0x1039bd59b*/
  v5 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>>>::find<RakNet::SystemAddress>( /*0x1039bd5ab*/
         a1: v3,
         a2);
  RakNet::SimpleMutex::Unlock(this: v4); /*0x1039bd5b1*/
  return v5 != 0; /*0x1039bd5c6*/
}

// Address: 0x1039bd5ca | Name: __ZN6RakNet7RakPeer23IsBannedPeerRuppOptedInERKNS_13SystemAddressE
__int64 __fastcall RakNet::RakPeer::IsBannedPeerRuppOptedIn(RakNet::RakPeer *this, const RakNet::SystemAddress *a2)
{
  RakNet::SimpleMutex *v4; // rbx
  __int64 v5; // rax

  v4 = (RakNet::RakPeer *)((char *)this + 1032); /*0x1039bd5da*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1032)); /*0x1039bd5e4*/
  if ( *((_QWORD *)this + 140) != 0 /*0x1039bd608*/
    && (v5 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *>>>::find<RakNet::SystemAddress>(
               a1: (char *)this + 1096,
               a2)) != 0 )
  {
    LOBYTE(a2) = *(_BYTE *)(*(_QWORD *)(v5 + 48) + 36LL); /*0x1039bd60e*/
  }
  else
  {
    LODWORD(a2) = 0; /*0x1039bd614*/
  }
  RakNet::SimpleMutex::Unlock(this: v4); /*0x1039bd61a*/
  return (unsigned int)a2; /*0x1039bd626*/
}

// Address: 0x1039bd62e | Name: __ZNK6RakNet7RakPeer14GetJoinRxStatsENS_13AddressOrGUIDERNS_11JoinRxStatsE
__int64 __fastcall RakNet::RakPeer::GetJoinRxStats(__int64 a1, const RakNet::AddressOrGUID *a2, _OWORD *a3)
{
  __int64 result; // rax
  _BYTE v6[72]; // [rsp+8h] [rbp-48h] BYREF

  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v6, a2); /*0x1039bd648*/
  result = RakNet::RakPeer::GetRemoteSystem(a1, a2: v6, a3: 0, a4: 0); /*0x1039bd657*/
  if ( result != 0 ) /*0x1039bd65f*/
    *a3 = *(_OWORD *)(result + 1632); /*0x1039bd668*/
  return result; /*0x1039bd66b*/
}

// Address: 0x1039bd676 | Name: __ZNK6RakNet7RakPeer15GetRemoteSystemENS_13AddressOrGUIDEbb
__int64 __fastcall RakNet::RakPeer::GetRemoteSystem(__int64 a1, __int64 a2, char a3, unsigned __int8 a4)
{
  __int64 v8; // r8
  __int64 v9; // r9

  if ( (unsigned __int8)RakNet::RakNetGUID::operator!=(a1: a2, a2: &RakNet::UNASSIGNED_RAKNET_GUID) != 0 ) /*0x1039bd6a1*/
    return RakNet::RakPeer::GetRemoteSystemFromGUID(a1, a2: *(_QWORD *)a2, a3: *(unsigned int *)(a2 + 8), a4); /*0x1039bd6be*/
  else
    return RakNet::RakPeer::GetRemoteSystemFromSystemAddress( /*0x1039bd6e7*/
             a1,
             a2: a3,
             a3: a4,
             a4: -1,
             a5: v8,
             a6: v9,
             a7: *(_OWORD *)(a2 + 16));
}

// Address: 0x1039bd6fa | Name: __ZN6RakNet7RakPeer20GetRakNetJoinRxStatsENS_13AddressOrGUIDERNS_17RakNetJoinRxStatsE
__int64 __fastcall RakNet::RakPeer::GetRakNetJoinRxStats(__int64 a1, const RakNet::AddressOrGUID *a2, __int64 a3)
{
  __int64 result; // rax
  __int128 v6; // xmm0
  _BYTE v7[72]; // [rsp+8h] [rbp-48h] BYREF

  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v7, a2); /*0x1039bd714*/
  result = RakNet::RakPeer::GetRemoteSystem(a1, a2: (__int64)v7, a3: 0, a4: 0); /*0x1039bd723*/
  if ( result != 0 ) /*0x1039bd72b*/
  {
    *(_DWORD *)(a3 + 32) = *(_DWORD *)(result + 1680); /*0x1039bd733*/
    v6 = *(_OWORD *)(result + 1648); /*0x1039bd736*/
    *(_OWORD *)(a3 + 16) = *(_OWORD *)(result + 1664); /*0x1039bd744*/
    *(_OWORD *)a3 = v6; /*0x1039bd748*/
  }
  return result; /*0x1039bd74b*/
}

// Address: 0x1039bd756 | Name: __ZNK6RakNet7RakPeer29GetRakNetHandshakeStartTimeMsERj
__int64 __fastcall RakNet::RakPeer::GetRakNetHandshakeStartTimeMs(RakNet::RakPeer *this, unsigned int *a2)
{
  __int64 result; // rax

  result = *((unsigned int *)this + 927); /*0x1039bd75a*/
  *a2 = result; /*0x1039bd760*/
  return result; /*0x1039bd762*/
}

// Address: 0x1039bd764 | Name: __ZNK6RakNet7RakPeer14GetAveragePingEPKNS0_18RemoteSystemStructE14PacketPriority
unsigned __int64 __fastcall RakNet::RakPeer::GetAveragePing(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned int v3; // eax
  const mach_header_64 *v4; // rcx
  int v5; // edx
  unsigned __int16 *v6; // rdx
  __int64 v7; // rcx
  unsigned int v8; // eax
  int v9; // esi
  __int64 v10; // rcx
  unsigned int v11; // ecx

  if ( a3 <= 3 ) /*0x1039bd767*/
  {
    v6 = (unsigned __int16 *)(80LL * a3 + a2 + 4608); /*0x1039bd783*/
    v7 = 0; /*0x1039bd78a*/
    v8 = 0; /*0x1039bd78c*/
    while ( 1 ) /*0x1039bd78e*/
    {
      v9 = *v6; /*0x1039bd78e*/
      if ( v9 == 0xFFFF ) /*0x1039bd797*/
        break; /*0x1039bd797*/
      v8 += v9; /*0x1039bd799*/
      --v7; /*0x1039bd79b*/
      v6 += 8; /*0x1039bd79e*/
      if ( v7 == -5 ) /*0x1039bd7a6*/
      {
        LODWORD(v10) = 5; /*0x1039bd7a8*/
LABEL_9:
        v11 = v8 / (unsigned int)v10; /*0x1039bd7b7*/
        v3 = (unsigned __int8)v11; /*0x1039bd7bd*/
        v5 = v11 & 0x7FFFFF00; /*0x1039bd7c2*/
        v4 = &_mh_execute_header; /*0x1039bd7c8*/
        return (unsigned __int64)v4 | v5 | v3; /*0x1039bd7c8*/
      }
    }
    if ( v7 != 0 ) /*0x1039bd7b2*/
    {
      v10 = -v7; /*0x1039bd7b4*/
      goto LABEL_9; /*0x1039bd7b4*/
    }
    v3 = 0; /*0x1039bd7d9*/
    v4 = nullptr; /*0x1039bd7db*/
    v5 = 0; /*0x1039bd7dd*/
  }
  else
  {
    v3 = 0; /*0x1039bd769*/
    v4 = nullptr; /*0x1039bd76b*/
    v5 = 0; /*0x1039bd76d*/
  }
  return (unsigned __int64)v4 | v5 | v3; /*0x1039bd7d8*/
}

// Address: 0x1039bd7e2 | Name: __ZNK6RakNet7RakPeer8GetPingsEPNS0_18RemoteSystemStructERNS_16RakNetStatisticsE
void __fastcall RakNet::RakPeer::GetPings(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        RakNet::RakNetStatistics *a3)
{
  char *v4; // r14
  char *v5; // r15
  __int64 v6; // r13
  unsigned __int64 v7; // rdx
  __int64 v8; // rcx
  unsigned int v9; // eax
  int v10; // esi
  __int64 v11; // rcx
  __int64 v12; // rax
  __int64 AverageAckPingMs; // rax
  __int64 AckPingJitterMs; // rax
  __int64 v15; // rax
  unsigned __int16 v16; // ax
  int v17; // eax
  char *v18; // [rsp-48h] [rbp-48h]
  char *v20; // [rsp-38h] [rbp-38h]

  if ( a2 != nullptr ) /*0x1039bd7e5*/
  {
    v4 = (char *)a2 + 4608; /*0x1039bd7ff*/
    v5 = (char *)a2 + 4960; /*0x1039bd80a*/
    v18 = (char *)a3 + 64; /*0x1039bd815*/
    v6 = 0; /*0x1039bd819*/
    v20 = (char *)a2 + 4608; /*0x1039bd81c*/
    do /*0x1039bd897*/
    {
      v7 = (unsigned __int64)v4; /*0x1039bd820*/
      v8 = 0; /*0x1039bd823*/
      v9 = 0; /*0x1039bd825*/
      while ( 1 ) /*0x1039bd827*/
      {
        v10 = *(unsigned __int16 *)v7; /*0x1039bd827*/
        if ( v10 == 0xFFFF ) /*0x1039bd830*/
          break; /*0x1039bd830*/
        v9 += v10; /*0x1039bd832*/
        --v8; /*0x1039bd834*/
        v7 += 16LL; /*0x1039bd837*/
        if ( v8 == -5 ) /*0x1039bd83f*/
        {
          LODWORD(v11) = 5; /*0x1039bd841*/
LABEL_9:
          v7 = v9 % (unsigned int)v11; /*0x1039bd850*/
          v12 = (v9 / (unsigned int)v11) & 0x7FFFFFFF | 0x100000000LL; /*0x1039bd859*/
          goto LABEL_10; /*0x1039bd859*/
        }
      }
      if ( v8 != 0 ) /*0x1039bd84b*/
      {
        v11 = -v8; /*0x1039bd84d*/
        goto LABEL_9; /*0x1039bd84d*/
      }
      v12 = 0; /*0x1039bd89b*/
LABEL_10:
      *((_DWORD *)a3 + 2 * v6) = v12; /*0x1039bd85e*/
      *((_BYTE *)a3 + 8 * v6 + 4) = BYTE4(v12); /*0x1039bd866*/
      RBX::SmallVectorImpl<unsigned short>::operator=(a1: &v18[32 * v6], a2: &v5[32 * v6], a3: v7); /*0x1039bd87e*/
      *(_QWORD *)&v5[32 * v6++ + 8] = 0; /*0x1039bd883*/
      v4 += 80; /*0x1039bd88f*/
    }
    while ( v6 != 4 ); /*0x1039bd897*/
    AverageAckPingMs = RakNet::ReliabilityLayer::GetAverageAckPingMs(this: (RakNet::RakPeer::RemoteSystemStruct *)((char *)a2 + 392)); /*0x1039bd8ad*/
    *((_DWORD *)a3 + 12) = AverageAckPingMs; /*0x1039bd8b2*/
    *((_BYTE *)a3 + 52) = BYTE4(AverageAckPingMs); /*0x1039bd8b9*/
    AckPingJitterMs = RakNet::ReliabilityLayer::GetAckPingJitterMs(this: (RakNet::RakPeer::RemoteSystemStruct *)((char *)a2 + 392)); /*0x1039bd8bf*/
    *((_DWORD *)a3 + 14) = AckPingJitterMs; /*0x1039bd8c4*/
    *((_BYTE *)a3 + 60) = BYTE4(AckPingJitterMs); /*0x1039bd8cb*/
    v15 = *((_QWORD *)a2 + 616); /*0x1039bd8ce*/
    if ( v15 != 0 ) /*0x1039bd8d8*/
      v16 = *(_WORD *)&v20[16 * v15 - 16]; /*0x1039bd8e2*/
    else
      v16 = *((_WORD *)a2 + 2336); /*0x1039bd8e9*/
    if ( *((_BYTE *)a3 + 36) == 0 ) /*0x1039bd8f5*/
      *((_BYTE *)a3 + 36) = 1; /*0x1039bd8fb*/
    *((_DWORD *)a3 + 8) = v16; /*0x1039bd901*/
    v17 = *((unsigned __int16 *)a2 + 1); /*0x1039bd90d*/
    if ( *((_BYTE *)a3 + 44) == 0 ) /*0x1039bd910*/
      *((_BYTE *)a3 + 44) = 1; /*0x1039bd912*/
    *((_DWORD *)a3 + 10) = v17; /*0x1039bd916*/
  }
}

// Address: 0x1039bd928 | Name: __ZNK6RakNet7RakPeer11GetLastPingENS_13AddressOrGUIDE
__int64 __fastcall RakNet::RakPeer::GetLastPing(__int64 a1, const RakNet::AddressOrGUID *a2)
{
  __int64 RemoteSystem; // rax
  __int64 v4; // r14
  RakNet::SimpleMutex *v5; // rbx
  __int64 v6; // rax
  bool v7; // cf
  unsigned __int16 *v8; // rax
  unsigned int v9; // r14d
  _BYTE v11[64]; // [rsp+0h] [rbp-40h] BYREF

  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v11, a2); /*0x1039bd93d*/
  RemoteSystem = RakNet::RakPeer::GetRemoteSystem(a1, a2: (__int64)v11, a3: 0, a4: 0); /*0x1039bd94c*/
  if ( RemoteSystem != 0 ) /*0x1039bd954*/
  {
    v4 = RemoteSystem; /*0x1039bd956*/
    v5 = (RakNet::SimpleMutex *)(a1 + 3320); /*0x1039bd959*/
    RakNet::SimpleMutex::Lock(this: v5); /*0x1039bd963*/
    v6 = *(_QWORD *)(v4 + 4928); /*0x1039bd968*/
    v7 = v6 == 0; /*0x1039bd97e*/
    v8 = (unsigned __int16 *)(v4 + 16 * (v6 - 1) + 4608); /*0x1039bd982*/
    if ( v7 ) /*0x1039bd98a*/
      v8 = (unsigned __int16 *)(v4 + 4672); /*0x1039bd98a*/
    v9 = *v8; /*0x1039bd98e*/
    RakNet::SimpleMutex::Unlock(this: v5); /*0x1039bd995*/
  }
  else
  {
    return (unsigned int)-1; /*0x1039bd99c*/
  }
  return v9; /*0x1039bd9a5*/
}

// Address: 0x1039bd9ae | Name: __ZNK6RakNet7RakPeer13GetLowestPingENS_13AddressOrGUIDE
__int64 __fastcall RakNet::RakPeer::GetLowestPing(__int64 a1, const RakNet::AddressOrGUID *a2)
{
  __int64 RemoteSystem; // rax
  __int64 v4; // r14
  RakNet::SimpleMutex *v5; // rbx
  unsigned int v6; // r14d
  _BYTE v8[64]; // [rsp+0h] [rbp-40h] BYREF

  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v8, a2); /*0x1039bd9c3*/
  RemoteSystem = RakNet::RakPeer::GetRemoteSystem(a1, a2: (__int64)v8, a3: 0, a4: 0); /*0x1039bd9d2*/
  if ( RemoteSystem != 0 ) /*0x1039bd9da*/
  {
    v4 = RemoteSystem; /*0x1039bd9dc*/
    v5 = (RakNet::SimpleMutex *)(a1 + 3320); /*0x1039bd9df*/
    RakNet::SimpleMutex::Lock(this: v5); /*0x1039bd9e9*/
    v6 = *(unsigned __int16 *)(v4 + 2); /*0x1039bd9f3*/
    RakNet::SimpleMutex::Unlock(this: v5); /*0x1039bd9fa*/
  }
  else
  {
    return (unsigned int)-1; /*0x1039bda01*/
  }
  return v6; /*0x1039bda0a*/
}

// Address: 0x1039bda14 | Name: __ZN6RakNet7RakPeer17SetOccasionalPingEb
void __fastcall RakNet::RakPeer::SetOccasionalPing(RakNet::RakPeer *this, char a2)
{
  *((_BYTE *)this + 168) = a2; /*0x1039bda18*/
}

// Address: 0x1039bda22 | Name: __ZN6RakNet7RakPeer22SetOfflinePingResponseEPKcj
__int64 __fastcall RakNet::RakPeer::SetOfflinePingResponse(RakNet::RakPeer *this, const char *a2, unsigned int a3)
{
  RakNet::SimpleMutex *v6; // rbx
  RakNet::BitStream *v7; // r12

  v6 = (RakNet::RakPeer *)((char *)this + 888); /*0x1039bda36*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 888)); /*0x1039bda40*/
  v7 = (RakNet::RakPeer *)((char *)this + 176); /*0x1039bda45*/
  RakNet::BitStream::Reset(this: v7); /*0x1039bda4f*/
  if ( a2 != nullptr && a3 != 0 ) /*0x1039bda5d*/
    RakNet::BitStream::Write(this: v7, a2, a3); /*0x1039bda6d*/
  return RakNet::SimpleMutex::Unlock(this: v6); /*0x1039bda75*/
}

// Address: 0x1039bda82 | Name: __ZN6RakNet7RakPeer22GetOfflinePingResponseEPPcPj
__int64 __fastcall RakNet::RakPeer::GetOfflinePingResponse(RakNet::RakPeer *this, char **a2, unsigned int *a3)
{
  RakNet::SimpleMutex *v6; // r12

  v6 = (RakNet::RakPeer *)((char *)this + 888); /*0x1039bda96*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 888)); /*0x1039bdaa0*/
  *a2 = *((char **)this + 25); /*0x1039bdaac*/
  *a3 = (unsigned int)(*((_DWORD *)this + 47) + 7) >> 3; /*0x1039bdabc*/
  return RakNet::SimpleMutex::Unlock(this: v6); /*0x1039bdac1*/
}

// Address: 0x1039bdace | Name: __ZNK6RakNet7RakPeer13GetInternalIDENS_13SystemAddressEi
_OWORD *__fastcall RakNet::RakPeer::GetInternalID(
        _OWORD *a1,
        __int64 a2,
        int a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  __int64 v10; // r8
  __int64 v11; // r9
  __int64 v12; // rax
  __int128 v13; // xmm0
  __int128 v14; // xmm1
  __int64 RemoteSystemFromSystemAddress; // rax
  __int64 v16; // rcx

  if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: &a7, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 ) /*0x1039bdafb*/
  {
    v12 = 32LL * a3; /*0x1039bdb00*/
    v13 = *(_OWORD *)(a2 + v12 + 2168); /*0x1039bdb04*/
    v14 = *(_OWORD *)(a2 + v12 + 2184); /*0x1039bdb0d*/
  }
  else
  {
    RemoteSystemFromSystemAddress = RakNet::RakPeer::GetRemoteSystemFromSystemAddress( /*0x1039bdb3b*/
                                      a1: a2,
                                      a2: 0,
                                      a3: 1u,
                                      a4: -1,
                                      a5: v10,
                                      a6: v11,
                                      a7);
    if ( RemoteSystemFromSystemAddress == 0 ) /*0x1039bdb43*/
    {
      a1[1] = *(__int128 *)((char *)&xmmword_10CDB0CBC + 4); /*0x1039bdb74*/
      v13 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039bdb78*/
      goto LABEL_6; /*0x1039bdb7f*/
    }
    v16 = 32LL * a3; /*0x1039bdb48*/
    v13 = *(_OWORD *)(RemoteSystemFromSystemAddress + v16 + 68); /*0x1039bdb4c*/
    v14 = *(_OWORD *)(RemoteSystemFromSystemAddress + v16 + 84); /*0x1039bdb51*/
  }
  a1[1] = v14; /*0x1039bdb56*/
LABEL_6:
  *a1 = v13; /*0x1039bdb5a*/
  return a1; /*0x1039bdb60*/
}

// Address: 0x1039bdb82 | Name: __ZNK6RakNet7RakPeer9GetMyGUIDEv
__int64 __fastcall RakNet::RakPeer::GetMyGUID(RakNet::RakPeer *this)
{
  return *((_QWORD *)this + 261); /*0x1039bdb94*/
}

// Address: 0x1039bdb96 | Name: __ZN6RakNet7RakPeer17GetMyBoundAddressEi
RakNet::RakPeer *__fastcall RakNet::RakPeer::GetMyBoundAddress(RakNet::RakPeer *this, __int64 a2, unsigned int a3)
{
  __int64 v5; // rax
  __int128 v6; // xmm0
  __int64 v8[4]; // [rsp+0h] [rbp-20h] BYREF

  *(_OWORD *)v8 = 0; /*0x1039bdbb1*/
  (*(void (__fastcall **)(__int64, __int64 *))(*(_QWORD *)a2 + 560LL))(a1: a2, a2: v8); /*0x1039bdbba*/
  if ( LODWORD(v8[1]) != 0 ) /*0x1039bdbc4*/
  {
    v5 = *(_QWORD *)(v8[0] + 16LL * a3); /*0x1039bdbd1*/
    v6 = *(_OWORD *)(v5 + 8); /*0x1039bdbd5*/
    *((_OWORD *)this + 1) = *(_OWORD *)(v5 + 24); /*0x1039bdbdd*/
  }
  else
  {
    *((_OWORD *)this + 1) = *(__int128 *)((char *)&xmmword_10CDB0CBC + 4); /*0x1039bdbea*/
    v6 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039bdbee*/
  }
  *(_OWORD *)this = v6; /*0x1039bdbf5*/
  DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::~List(a1: v8); /*0x1039bdbfc*/
  return this; /*0x1039bdc04*/
}

// Address: 0x1039bdc22 | Name: __ZNK6RakNet7RakPeer24GetGuidFromSystemAddressENS_13SystemAddressE
__int64 __fastcall RakNet::RakPeer::GetGuidFromSystemAddress(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7,
        __int64 a8,
        __int64 a9,
        __int64 a10)
{
  __int64 *v11; // r15
  __int64 v12; // r12
  unsigned __int64 v13; // r13

  if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: &a7, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 ) /*0x1039bdc48*/
    return a1 + 2088; /*0x1039bdc51*/
  if ( HIWORD(a10) != 0xFFFF /*0x1039bdc8f*/
    && HIWORD(a10) < *(_WORD *)(a1 + 170)
    && (unsigned __int8)RakNet::SystemAddress::operator==(a1: *(_QWORD *)(a1 + 736) + 5368LL * HIWORD(a10) + 4, a2: &a7) != 0 )
  {
    return *(_QWORD *)(a1 + 736) + 5368LL * HIWORD(a10) + 5200; /*0x1039bdca8*/
  }
  v11 = &RakNet::UNASSIGNED_RAKNET_GUID; /*0x1039bdcb1*/
  if ( *(_WORD *)(a1 + 170) != 0 ) /*0x1039bdcc0*/
  {
    v12 = 5200; /*0x1039bdcc2*/
    v13 = 0; /*0x1039bdcc8*/
    while ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: *(_QWORD *)(a1 + 736) + v12 - 5196, a2: &a7) == 0 ) /*0x1039bdce7*/
    {
      ++v13; /*0x1039bdce9*/
      v12 += 5368; /*0x1039bdcf3*/
      if ( v13 >= *(unsigned __int16 *)(a1 + 170) ) /*0x1039bdcfd*/
        return (__int64)v11; /*0x1039bdcfd*/
    }
    return *(_QWORD *)(a1 + 736) + v12; /*0x1039bdd08*/
  }
  return (__int64)v11; /*0x1039bdd12*/
}

// Address: 0x1039bdd1e | Name: __ZNK6RakNet7RakPeer22GetSystemIndexFromGuidENS_10RakNetGUIDE
__int64 __fastcall RakNet::RakPeer::GetSystemIndexFromGuid(__int64 a1, __int64 a2, unsigned __int16 a3)
{
  unsigned int v4; // ebx
  __int64 v5; // r13
  unsigned __int64 v6; // r12
  __int64 v8; // [rsp+8h] [rbp-38h] BYREF
  unsigned __int16 v9; // [rsp+10h] [rbp-30h]

  v8 = a2; /*0x1039bdd36*/
  v9 = a3; /*0x1039bdd39*/
  v4 = -1; /*0x1039bdd49*/
  if ( (unsigned __int8)RakNet::RakNetGUID::operator==(a1: &v8, a2: &RakNet::UNASSIGNED_RAKNET_GUID) == 0 /*0x1039bdd68*/
    && (unsigned __int8)RakNet::RakNetGUID::operator==(a1: &v8, a2: a1 + 2088) == 0 )
  {
    if ( v9 == 0xFFFF /*0x1039bdda8*/
      || v9 >= *(_WORD *)(a1 + 170)
      || (unsigned __int8)RakNet::RakNetGUID::operator==(a1: *(_QWORD *)(a1 + 736) + 5368LL * v9 + 5200, a2: &v8) == 0 )
    {
      if ( *(_WORD *)(a1 + 170) != 0 ) /*0x1039bddb9*/
      {
        v5 = 5200; /*0x1039bddbb*/
        v6 = 0; /*0x1039bddc1*/
        while ( (unsigned __int8)RakNet::RakNetGUID::operator==(a1: v5 + *(_QWORD *)(a1 + 736), a2: &v8) == 0 ) /*0x1039bdddc*/
        {
          ++v6; /*0x1039bddde*/
          v5 += 5368; /*0x1039bdde9*/
          if ( v6 >= *(unsigned __int16 *)(a1 + 170) ) /*0x1039bddf3*/
            return v4; /*0x1039bddf3*/
        }
        return (unsigned int)v6; /*0x1039bddf7*/
      }
    }
    else
    {
      return v9; /*0x1039bddaa*/
    }
  }
  return v4; /*0x1039bddfc*/
}

// Address: 0x1039bde0c | Name: __ZNK6RakNet7RakPeer24GetSystemAddressFromGuidENS_10RakNetGUIDE
_OWORD *__fastcall RakNet::RakPeer::GetSystemAddressFromGuid(_OWORD *a1, __int64 a2, __int64 a3, unsigned __int16 a4)
{
  __int128 v6; // xmm0
  __int64 v7; // rcx
  __int64 v8; // r8
  __int64 v9; // r9
  __int64 v11; // rax
  __int64 v12; // rcx
  __int128 v13; // xmm1
  __int64 v14; // r12
  unsigned __int64 v15; // r13
  __int64 v16; // rax
  __int64 v17; // [rsp+48h] [rbp-38h] BYREF
  unsigned __int16 v18; // [rsp+50h] [rbp-30h]

  v17 = a3; /*0x1039bde27*/
  v18 = a4; /*0x1039bde2a*/
  if ( (unsigned __int8)RakNet::RakNetGUID::operator==(a1: &v17, a2: &RakNet::UNASSIGNED_RAKNET_GUID) != 0 ) /*0x1039bde3c*/
    goto LABEL_2; /*0x1039bde3c*/
  if ( (unsigned __int8)RakNet::RakNetGUID::operator==(a1: &v17, a2: a2 + 2088) != 0 ) /*0x1039bde67*/
  {
    (*(void (__fastcall **)(_OWORD *, __int64, _QWORD, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)a2 + 400LL))( /*0x1039bde9b*/
      a1,
      a2,
      a3: 0,
      a4: v7,
      a5: v8,
      a6: v9,
      a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
      a8: unk_10CDB0CB8,
      a9: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 4),
      a10: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 12),
      a11: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
      a12: unk_10CDB0CB8,
      a13: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 4),
      a14: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 12));
    return a1; /*0x1039bde9b*/
  }
  if ( v18 != 0xFFFF /*0x1039bdeed*/
    && v18 < *(_WORD *)(a2 + 170)
    && (unsigned __int8)RakNet::RakNetGUID::operator==(a1: *(_QWORD *)(a2 + 736) + 5368LL * v18 + 5200, a2: &v17) != 0 )
  {
    v11 = *(_QWORD *)(a2 + 736); /*0x1039bdeef*/
    v12 = 5368LL * v18; /*0x1039bdefa*/
    v6 = *(_OWORD *)(v11 + v12 + 4); /*0x1039bdf01*/
    v13 = *(_OWORD *)(v11 + v12 + 20); /*0x1039bdf06*/
LABEL_17:
    a1[1] = v13; /*0x1039bdf74*/
    goto LABEL_3; /*0x1039bdf78*/
  }
  if ( *(_WORD *)(a2 + 170) != 0 ) /*0x1039bdf16*/
  {
    v14 = 5200; /*0x1039bdf1c*/
    v15 = 0; /*0x1039bdf22*/
    while ( (unsigned __int8)RakNet::RakNetGUID::operator==(a1: v14 + *(_QWORD *)(a2 + 736), a2: &v17) == 0 ) /*0x1039bdf3d*/
    {
      ++v15; /*0x1039bdf3f*/
      v14 += 5368; /*0x1039bdf4a*/
      if ( v15 >= *(unsigned __int16 *)(a2 + 170) ) /*0x1039bdf54*/
        goto LABEL_2; /*0x1039bdf54*/
    }
    v16 = *(_QWORD *)(a2 + 736); /*0x1039bdf5b*/
    v6 = *(_OWORD *)(v16 + v14 - 5196); /*0x1039bdf62*/
    v13 = *(_OWORD *)(v16 + v14 - 5180); /*0x1039bdf6b*/
    goto LABEL_17; /*0x1039bdf6b*/
  }
LABEL_2:
  a1[1] = *(__int128 *)((char *)&xmmword_10CDB0CBC + 4); /*0x1039bde3e*/
  v6 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039bde49*/
LABEL_3:
  *a1 = v6; /*0x1039bde50*/
  return a1; /*0x1039bdea4*/
}

// Address: 0x1039bdf7e | Name: __ZNK6RakNet7RakPeer35GetClientPublicKeyFromSystemAddressENS_13SystemAddressEPc
__int64 RakNet::RakPeer::GetClientPublicKeyFromSystemAddress()
{
  return 0; /*0x1039bdf84*/
}

// Address: 0x1039bdf86 | Name: __ZN6RakNet7RakPeer14SetTimeoutTimeEjNS_13SystemAddressE
unsigned __int64 __fastcall RakNet::RakPeer::SetTimeoutTime(
        __int64 a1,
        unsigned int a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  unsigned __int64 result; // rax
  __int64 v10; // r8
  __int64 v11; // r9
  __int64 v12; // r15
  unsigned __int64 v13; // r12

  result = RakNet::SystemAddress::operator==(a1: &a7, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS); /*0x1039bdfa8*/
  if ( (_BYTE)result != 0 ) /*0x1039bdfaf*/
  {
    *(_DWORD *)(a1 + 2084) = a2; /*0x1039bdfb1*/
    if ( *(_WORD *)(a1 + 170) != 0 ) /*0x1039bdfc1*/
    {
      v12 = 392; /*0x1039bdfc7*/
      v13 = 0; /*0x1039bdfcd*/
      do /*0x1039be01c*/
      {
        if ( (*(_BYTE *)(*(_QWORD *)(a1 + 736) + v12 - 392) & 1) != 0 ) /*0x1039bdfe1*/
          RakNet::ReliabilityLayer::SetTimeoutTime(this: (RakNet::ReliabilityLayer *)(v12 + *(_QWORD *)(a1 + 736)), a2); /*0x1039be002*/
        ++v13; /*0x1039be007*/
        result = *(unsigned __int16 *)(a1 + 170); /*0x1039be00a*/
        v12 += 5368; /*0x1039be012*/
      }
      while ( v13 < result ); /*0x1039be01c*/
    }
  }
  else
  {
    result = RakNet::RakPeer::GetRemoteSystemFromSystemAddress(a1, a2: 0, a3: 1u, a4: -1, a5: v10, a6: v11, a7); /*0x1039be041*/
    if ( result != 0 ) /*0x1039be049*/
      return RakNet::ReliabilityLayer::SetTimeoutTime(this: (RakNet::ReliabilityLayer *)(result + 392), a2); /*0x1039be056*/
  }
  return result; /*0x1039be05b*/
}

// Address: 0x1039be068 | Name: __ZN6RakNet7RakPeer14GetTimeoutTimeENS_13SystemAddressE
__int64 __fastcall RakNet::RakPeer::GetTimeoutTime(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  __int64 v8; // r8
  __int64 v9; // r9
  __int64 RemoteSystemFromSystemAddress; // rax

  if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: &a7, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) == 0 ) /*0x1039be08b*/
  {
    RemoteSystemFromSystemAddress = RakNet::RakPeer::GetRemoteSystemFromSystemAddress( /*0x1039be0ae*/
                                      a1,
                                      a2: 0,
                                      a3: 1u,
                                      a4: -1,
                                      a5: v8,
                                      a6: v9,
                                      a7);
    if ( RemoteSystemFromSystemAddress != 0 ) /*0x1039be0b6*/
      RakNet::ReliabilityLayer::GetTimeoutTime(this: (RakNet::ReliabilityLayer *)(RemoteSystemFromSystemAddress + 392)); /*0x1039be0c1*/
  }
  return *(unsigned int *)(a1 + 2084); /*0x1039be0cc*/
}

// Address: 0x1039be0d6 | Name: __ZN6RakNet7RakPeer23GetConnectionStatusSafeENS_13SystemAddressEiRiS2_S2_S2_S2_RNS_16RakNetStatisticsE
char __fastcall RakNet::RakPeer::GetConnectionStatusSafe(
        __int64 a1,
        int a2,
        _DWORD *a3,
        int *a4,
        int *a5,
        int *a6,
        char a7,
        __int64 a8,
        __int64 a9,
        __int64 a10,
        _DWORD *a11,
        RakNet::RakNetStatistics *a12)
{
  __int64 v16; // r8
  __int64 v17; // r9
  __int64 RemoteSystemFromSystemAddress; // rax
  _DWORD *v19; // rbx
  RakNet::RakNetStatistics *v20; // r14
  RakNet::RakPeer *v21; // rdi
  int v22; // eax
  int v23; // ecx
  _DWORD *v24; // rcx
  int v25; // eax
  char v26; // bl
  char result; // al

  if ( (unsigned __int8)RakNet::SystemAddress::operator!=(a1: &a7, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) == 0 ) /*0x1039be10f*/
    goto LABEL_10; /*0x1039be10f*/
  RemoteSystemFromSystemAddress = RakNet::RakPeer::GetRemoteSystemFromSystemAddress( /*0x1039be133*/
                                    a1,
                                    a2: 0,
                                    a3: 1u,
                                    a4: a2,
                                    a5: v16,
                                    a6: v17,
                                    a7);
  if ( RemoteSystemFromSystemAddress == 0 ) /*0x1039be13b*/
    goto LABEL_10; /*0x1039be13b*/
  v19 = (_DWORD *)RemoteSystemFromSystemAddress; /*0x1039be141*/
  v20 = a12; /*0x1039be144*/
  RakNet::SimpleMutex::Lock(this: (RakNet::SimpleMutex *)(a1 + 3320)); /*0x1039be153*/
  *a3 = v19[1304]; /*0x1039be15e*/
  RakNet::ReliabilityLayer::GetStatistics(this: (RakNet::ReliabilityLayer *)(v19 + 98), a2: v20); /*0x1039be16f*/
  RakNet::RakPeer::GetPings(this: v21, a2: (RakNet::RakPeer::RemoteSystemStruct *)v19, a3: v20); /*0x1039be17a*/
  v22 = -1; /*0x1039be184*/
  v23 = -1; /*0x1039be189*/
  if ( *((_BYTE *)v20 + 4) != 0 ) /*0x1039be18e*/
    v23 = *(_DWORD *)v20; /*0x1039be190*/
  *a4 = v23; /*0x1039be193*/
  if ( *((_BYTE *)v20 + 36) != 0 ) /*0x1039be19b*/
    v22 = *((_DWORD *)v20 + 8); /*0x1039be19d*/
  v24 = a11; /*0x1039be1a1*/
  *a5 = v22; /*0x1039be1a9*/
  v25 = 0xFFFF; /*0x1039be1b0*/
  if ( *((_BYTE *)v20 + 44) != 0 ) /*0x1039be1b5*/
    v25 = *((_DWORD *)v20 + 10); /*0x1039be1b7*/
  *a6 = v25; /*0x1039be1bf*/
  *v24 = *(_DWORD *)(a1 + 136); /*0x1039be1c8*/
  v26 = *(_BYTE *)(a1 + 160); /*0x1039be1ca*/
  RakNet::SimpleMutex::Unlock(this: (RakNet::SimpleMutex *)(a1 + 3320)); /*0x1039be1d5*/
  result = 1; /*0x1039be1da*/
  if ( (v26 & 1) != 0 ) /*0x1039be1df*/
  {
LABEL_10:
    *a3 = *(_DWORD *)(a1 + 2008); /*0x1039be1e8*/
    *a4 = -1; /*0x1039be1f1*/
    *a5 = -1; /*0x1039be1f8*/
    *a6 = -1; /*0x1039be1fe*/
    return 0; /*0x1039be200*/
  }
  return result; /*0x1039be202*/
}

// Address: 0x1039be212 | Name: __ZNK6RakNet7RakPeer10GetMTUSizeENS_13SystemAddressE
__int64 __fastcall RakNet::RakPeer::GetMTUSize(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  __int64 v8; // r8
  __int64 v9; // r9
  __int64 RemoteSystemFromSystemAddress; // rax
  __int64 v11; // r14
  RakNet::SimpleMutex *v12; // rbx
  unsigned int v13; // r14d

  if ( (unsigned __int8)RakNet::SystemAddress::operator!=(a1: &a7, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 /*0x1039be260*/
    && (RemoteSystemFromSystemAddress = RakNet::RakPeer::GetRemoteSystemFromSystemAddress(
                                          a1,
                                          a2: 0,
                                          a3: 1u,
                                          a4: -1,
                                          a5: v8,
                                          a6: v9,
                                          a7)) != 0 )
  {
    v11 = RemoteSystemFromSystemAddress; /*0x1039be262*/
    v12 = (RakNet::SimpleMutex *)(a1 + 3320); /*0x1039be265*/
    RakNet::SimpleMutex::Lock(this: v12); /*0x1039be26f*/
    v13 = *(_DWORD *)(v11 + 5216); /*0x1039be274*/
    RakNet::SimpleMutex::Unlock(this: v12); /*0x1039be27e*/
  }
  else
  {
    return *(unsigned int *)(a1 + 2008); /*0x1039be285*/
  }
  return v13; /*0x1039be28f*/
}

// Address: 0x1039be298 | Name: __ZN6RakNet7RakPeer42getAvaliableNetworkCapacityInBytesInNextMsERKNS_13SystemAddressEif
__int64 __fastcall RakNet::RakPeer::getAvaliableNetworkCapacityInBytesInNextMs(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *a2,
        int a3,
        float a4,
        __int64 a5,
        __int64 a6,
        __int64 a7)
{
  __int64 RemoteSystemFromSystemAddress; // rax

  RemoteSystemFromSystemAddress = RakNet::RakPeer::GetRemoteSystemFromSystemAddress( /*0x1039be2d1*/
                                    a1: (__int64)this,
                                    a2: 0,
                                    a3: 1u,
                                    a4: -1,
                                    a5: a6,
                                    a6: a7,
                                    a7: *(_OWORD *)a2);
  if ( RemoteSystemFromSystemAddress != 0 ) /*0x1039be2d9*/
    return RakNet::ReliabilityLayer::getAvaliableNetworkCapacityInBytesInNextMs( /*0x1039be2ee*/
             this: (RakNet::ReliabilityLayer *)(RemoteSystemFromSystemAddress + 392),
             a2: a4);
  else
    return 0xFFFFFFFFLL; /*0x1039be2f3*/
}

// Address: 0x1039be2fe | Name: __ZN6RakNet7RakPeer20GetNumberOfAddressesEv
__int64 __fastcall RakNet::RakPeer::GetNumberOfAddresses(RakNet::RakPeer *this)
{
  char *v1; // rbx
  unsigned int v2; // r14d
  char v3; // al

  v1 = (char *)this + 2168; /*0x1039be30b*/
  v2 = -1; /*0x1039be312*/
  do /*0x1039be333*/
  {
    v3 = RakNet::SystemAddress::operator!=(a1: v1, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS); /*0x1039be325*/
    ++v2; /*0x1039be32a*/
    v1 += 32; /*0x1039be32d*/
  }
  while ( v3 != 0 ); /*0x1039be333*/
  return v2; /*0x1039be33c*/
}

// Address: 0x1039be344 | Name: __ZN6RakNet7RakPeer10GetLocalIPEj
char *__fastcall RakNet::RakPeer::GetLocalIP(RakNet::RakPeer *this, unsigned int a2)
{
  RakNet::SystemAddress *v4; // rsi

  if ( (*(unsigned __int8 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 128LL))(a1: this) == 0 ) /*0x1039be35c*/
    RakNet::SocketLayer::GetMyIP(this: (RakNet::RakPeer *)((char *)this + 2168), a2: v4); /*0x1039be365*/
  RakNet::SystemAddress::ToStringN( /*0x1039be393*/
    this: (RakNet::RakPeer *)((char *)this + 32 * a2 + 2168),
    a2: false,
    a3: RakNet::RakPeer::GetLocalIP(unsigned int)::str,
    a4: 1025,
    a5: 124);
  return RakNet::RakPeer::GetLocalIP(unsigned int)::str; /*0x1039be39b*/
}

// Address: 0x1039be3a0 | Name: __ZN6RakNet7RakPeer9IsLocalIPEPKc
__int64 __fastcall RakNet::RakPeer::IsLocalIP(RakNet::RakPeer *this, const char *a2)
{
  unsigned int v2; // r15d
  int v5; // eax
  unsigned int v6; // r13d
  int v7; // r12d
  const char *v8; // rax
  int v9; // eax

  if ( a2 != nullptr && *a2 != 0 ) /*0x1039be3bd*/
  {
    LOBYTE(v2) = 1; /*0x1039be3d5*/
    if ( strcmp(__s1: a2, __s2: "127.0.0.1") == 0 /*0x1039be400*/
      || strcmp(__s1: a2, __s2: "localhost") == 0
      || strcmp(__s1: a2, __s2: "::1") == 0 )
    {
      return v2; /*0x1039be400*/
    }
    v5 = (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 480LL))(a1: this); /*0x1039be408*/
    v6 = 0; /*0x1039be40e*/
    if ( v5 > 0 ) /*0x1039be413*/
    {
      v7 = v5 - 1; /*0x1039be418*/
      do /*0x1039be447*/
      {
        v8 = (const char *)(*(__int64 (__fastcall **)(RakNet::RakPeer *, _QWORD))(*(_QWORD *)this + 488LL))( /*0x1039be424*/
                             a1: this,
                             a2: v6);
        v9 = strcmp(__s1: a2, __s2: v8); /*0x1039be430*/
        LOBYTE(v2) = v9 == 0; /*0x1039be437*/
        if ( v9 == 0 ) /*0x1039be43b*/
          break; /*0x1039be43b*/
      }
      while ( v7 != v6++ ); /*0x1039be447*/
      return v2; /*0x1039be455*/
    }
  }
  return 0; /*0x1039be44b*/
}

// Address: 0x1039be460 | Name: __ZN6RakNet7RakPeer34AllowConnectionResponseIPMigrationEb
void __fastcall RakNet::RakPeer::AllowConnectionResponseIPMigration(RakNet::RakPeer *this, char a2)
{
  *((_BYTE *)this + 2108) = a2; /*0x1039be464*/
}

// Address: 0x1039be46e | Name: __ZN6RakNet7RakPeer31SetSplitMessageProgressIntervalEi
unsigned __int64 __fastcall RakNet::RakPeer::SetSplitMessageProgressInterval(RakNet::RakPeer *this, int a2)
{
  __int64 v3; // r14
  unsigned __int64 v4; // r15
  unsigned __int64 result; // rax

  *((_DWORD *)this + 536) = a2; /*0x1039be46e*/
  if ( *((_WORD *)this + 85) != 0 ) /*0x1039be47c*/
  {
    v3 = 392; /*0x1039be48b*/
    v4 = 0; /*0x1039be491*/
    do /*0x1039be4bd*/
    {
      RakNet::ReliabilityLayer::SetSplitMessageProgressInterval( /*0x1039be4a4*/
        this: (RakNet::ReliabilityLayer *)(v3 + *((_QWORD *)this + 92)),
        a2: *((_DWORD *)this + 536));
      ++v4; /*0x1039be4a9*/
      result = *((unsigned __int16 *)this + 85); /*0x1039be4ac*/
      v3 += 5368; /*0x1039be4b3*/
    }
    while ( v4 < result ); /*0x1039be4bd*/
  }
  return result; /*0x1039be4c9*/
}

// Address: 0x1039be4ca | Name: __ZNK6RakNet7RakPeer31GetSplitMessageProgressIntervalEv
__int64 __fastcall RakNet::RakPeer::GetSplitMessageProgressInterval(RakNet::RakPeer *this)
{
  return *((unsigned int *)this + 536); /*0x1039be4d4*/
}

// Address: 0x1039be4d6 | Name: __ZN6RakNet7RakPeer20SetUnreliableTimeoutEj
unsigned __int64 __fastcall RakNet::RakPeer::SetUnreliableTimeout(RakNet::RakPeer *this, int a2)
{
  __int64 v3; // r14
  unsigned __int64 v4; // r15
  unsigned __int64 result; // rax

  *((_DWORD *)this + 537) = a2; /*0x1039be4d6*/
  if ( *((_WORD *)this + 85) != 0 ) /*0x1039be4e4*/
  {
    v3 = 392; /*0x1039be4f3*/
    v4 = 0; /*0x1039be4f9*/
    do /*0x1039be525*/
    {
      RakNet::ReliabilityLayer::SetUnreliableTimeout( /*0x1039be50c*/
        this: (RakNet::ReliabilityLayer *)(v3 + *((_QWORD *)this + 92)),
        a2: *((_DWORD *)this + 537));
      ++v4; /*0x1039be511*/
      result = *((unsigned __int16 *)this + 85); /*0x1039be514*/
      v3 += 5368; /*0x1039be51b*/
    }
    while ( v4 < result ); /*0x1039be525*/
  }
  return result; /*0x1039be531*/
}

// Address: 0x1039be532 | Name: __ZN6RakNet7RakPeer13SetPeerPluginEPN3RBX7Network5IPeerE
void __fastcall RakNet::RakPeer::SetPeerPlugin(RakNet::RakPeer *this, RBX::Network::IPeer *a2)
{
  *((_QWORD *)this + 423) = a2; /*0x1039be536*/
}

// Address: 0x1039be540 | Name: __ZN6RakNet7RakPeer14PushBackPacketEPNS_6PacketEb
__int64 __fastcall RakNet::RakPeer::PushBackPacket(__int64 a1, __int64 a2, char a3)
{
  RakNet::SimpleMutex *v5; // rbx
  __int64 v6; // r14
  __int64 result; // rax
  __int64 v8[4]; // [rsp+0h] [rbp-20h] BYREF

  v8[0] = a2; /*0x1039be54a*/
  if ( a2 != 0 ) /*0x1039be551*/
  {
    v5 = (RakNet::SimpleMutex *)(a1 + 2784); /*0x1039be559*/
    RakNet::SimpleMutex::Lock(this: (RakNet::SimpleMutex *)(a1 + 2784)); /*0x1039be563*/
    v6 = a1 + 2848; /*0x1039be568*/
    if ( a3 != 0 ) /*0x1039be572*/
      DataStructures::Queue<RakNet::Packet *>::PushAtHead(a1: v6, a2: v8, a3: 0, a4: (__int64)"", a5: 0); /*0x1039be587*/
    else
      DataStructures::Queue<RakNet::Packet *>::Push(a1: v6, a2: v8); /*0x1039be59e*/
    return RakNet::SimpleMutex::Unlock(this: v5); /*0x1039be5a6*/
  }
  return result; /*0x1039be5af*/
}

// Address: 0x1039be756 | Name: __ZN6RakNet7RakPeer14AllocatePacketEj
__int64 __fastcall RakNet::RakPeer::AllocatePacket(RakNet::RakPeer *this, unsigned int a2)
{
  return RakNet::RakPeer::AllocPacket(this, a2, a3: "", a4: 0); /*0x1039be763*/
}

// Address: 0x1039be76a | Name: __ZN6RakNet7RakPeer10GetSocketsERN14DataStructures4ListINSt3__110shared_ptrINS_12RakNetSocketEEEEE
char __fastcall RakNet::RakPeer::GetSockets(__int64 a1, __int64 *a2)
{
  std::__shared_weak_count *v4; // r12
  signed __int64 v5; // rax
  __int64 v6; // rax
  __int64 *v7; // r12
  std::__shared_weak_count *v8; // rbx
  std::__shared_weak_count *v9; // rbx
  std::__shared_weak_count *v11[2]; // [rsp+0h] [rbp-170h] BYREF
  _QWORD v12[2]; // [rsp+10h] [rbp-160h]
  _OWORD v13[8]; // [rsp+20h] [rbp-150h] BYREF
  __int128 v14; // [rsp+A0h] [rbp-D0h]
  _QWORD v15[2]; // [rsp+B0h] [rbp-C0h]
  __int64 v16; // [rsp+C0h] [rbp-B0h] BYREF
  __int16 v17; // [rsp+C8h] [rbp-A8h]
  _BYTE v18[32]; // [rsp+D0h] [rbp-A0h] BYREF
  __int128 v19; // [rsp+F0h] [rbp-80h]
  __int128 v20; // [rsp+100h] [rbp-70h]
  __int128 v21; // [rsp+110h] [rbp-60h]
  __int128 v22; // [rsp+120h] [rbp-50h]
  __int128 v23; // [rsp+130h] [rbp-40h]
  std::__shared_weak_count *v24[2]; // [rsp+140h] [rbp-30h]

  DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::Clear(a1: a2, a2: 0); /*0x1039be790*/
  v14 = 0; /*0x1039be79f*/
  RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)&v16); /*0x1039be7a8*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v18); /*0x1039be7b7*/
  *((_QWORD *)&v20 + 1) = 0; /*0x1039be7be*/
  *((_QWORD *)&v23 + 1) = 0; /*0x1039be7c2*/
  LODWORD(v23) = 1; /*0x1039be7c6*/
  v16 = RakNet::UNASSIGNED_RAKNET_GUID; /*0x1039be7d4*/
  v17 = word_10CC85C98; /*0x1039be7e2*/
  RakNet::SystemAddress::operator=(a1: v18, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS); /*0x1039be7f3*/
  *((_QWORD *)&v20 + 1) = 0; /*0x1039be7f8*/
  boost::mutex::lock(this: (pthread_mutex_t *)(a1 + 1288)); /*0x1039be80a*/
  *(_OWORD *)v11 = 0; /*0x1039be81d*/
  *(_QWORD *)((char *)v12 + 5) = *(_QWORD *)((char *)v15 + 5); /*0x1039be843*/
  v12[0] = v15[0]; /*0x1039be847*/
  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v13, a2: (const RakNet::AddressOrGUID *)&v16); /*0x1039be84e*/
  v13[7] = v23; /*0x1039be85e*/
  v13[6] = v22; /*0x1039be872*/
  v13[5] = v21; /*0x1039be876*/
  v13[4] = v20; /*0x1039be87a*/
  v13[3] = v19; /*0x1039be87e*/
  RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::push_back<std::move_iterator<RakNet::RakPeer::BufferedCommandStruct*>>( /*0x1039be890*/
    a1: a1 + 1224,
    a2: v11);
  v4 = v11[1]; /*0x1039be895*/
  if ( v11[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v11[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039be8b2*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(a1: v4); /*0x1039be8bb*/
    std::__shared_weak_count::__release_weak(this: v4); /*0x1039be8c1*/
  }
  boost::mutex::unlock(this: (pthread_mutex_t *)(a1 + 1288)); /*0x1039be8c9*/
  *(_OWORD *)v24 = 0; /*0x1039be8d1*/
  while ( 1 ) /*0x1039be8dc*/
  {
    LOBYTE(v5) = *(_BYTE *)(a1 + 161); /*0x1039be8dc*/
    if ( (v5 & 1) == 0 ) /*0x1039be8e5*/
      break; /*0x1039be8e5*/
    RakSleep(a1: 0); /*0x1039be8e9*/
    v6 = DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Pop(a1: a1 + 1736); /*0x1039be8f1*/
    v7 = (__int64 *)v6; /*0x1039be8f6*/
    if ( v6 != 0 ) /*0x1039be8fc*/
    {
      DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::operator=(a1: (__int64)a2, a2: v6); /*0x1039be904*/
      DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::Clear(a1: v7, a2: 0); /*0x1039be91a*/
      LOBYTE(v5) = DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Deallocate( /*0x1039be92a*/
                     a1: a1 + 1736,
                     a2: v7);
      break; /*0x1039be92a*/
    }
  }
  v8 = v24[1]; /*0x1039be92f*/
  if ( v24[1] != nullptr ) /*0x1039be936*/
  {
    v5 = _InterlockedExchangeAdd64((volatile signed __int64 *)v24[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x1039be93f*/
    if ( v5 == 0 ) /*0x1039be948*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x1039be950*/
      LOBYTE(v5) = std::__shared_weak_count::__release_weak(this: v8); /*0x1039be956*/
    }
  }
  v9 = *((std::__shared_weak_count **)&v14 + 1); /*0x1039be95b*/
  if ( *((_QWORD *)&v14 + 1) != 0 ) /*0x1039be965*/
  {
    v5 = _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v14 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL); /*0x1039be96e*/
    if ( v5 == 0 ) /*0x1039be977*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x1039be97f*/
      LOBYTE(v5) = std::__shared_weak_count::__release_weak(this: v9); /*0x1039be985*/
    }
  }
  return v5; /*0x1039be98a*/
}

// Address: 0x1039bebb2 | Name: __ZN6RakNet7RakPeer14ReleaseSocketsERN14DataStructures4ListINSt3__110shared_ptrINS_12RakNetSocketEEEEE
void __fastcall RakNet::RakPeer::ReleaseSockets(__int64 a1, __int64 *a2)
{
  DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::Clear(a1: a2, a2: 0); /*0x1039bebc5*/
}

// Address: 0x1039bebca | Name: __ZN6RakNet7RakPeer38SetPerConnectionOutgoingBandwidthLimitEj
void __fastcall RakNet::RakPeer::SetPerConnectionOutgoingBandwidthLimit(RakNet::RakPeer *this, int a2)
{
  *((_DWORD *)this + 526) = a2; /*0x1039bebce*/
}

// Address: 0x1039bebd6 | Name: __ZN6RakNet7RakPeer21SetPeerBandwidthLimitENS_13SystemAddressEj
unsigned __int64 __fastcall RakNet::RakPeer::SetPeerBandwidthLimit(
        __int64 a1,
        int a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int64 a7)
{
  __int64 v9; // r12
  unsigned __int64 v10; // r13
  unsigned __int64 result; // rax

  if ( *(_QWORD *)(a1 + 736) != 0 && *(_WORD *)(a1 + 170) != 0 ) /*0x1039bebf9*/
  {
    v9 = 5252; /*0x1039bec01*/
    v10 = 0; /*0x1039bec07*/
    while ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: *(_QWORD *)(a1 + 736) + v9 - 5248, a2: &a7) == 0 ) /*0x1039bec26*/
    {
      ++v10; /*0x1039bec28*/
      result = *(unsigned __int16 *)(a1 + 170); /*0x1039bec2b*/
      v9 += 5368; /*0x1039bec33*/
      if ( v10 >= result ) /*0x1039bec3d*/
        return result; /*0x1039bec3d*/
    }
    result = *(_QWORD *)(a1 + 736); /*0x1039bec41*/
    *(_DWORD *)(result + v9) = a2; /*0x1039bec48*/
  }
  return result; /*0x1039bec5a*/
}

// Address: 0x1039bec5c | Name: __ZN6RakNet7RakPeer17GetDataStatisticsERKNS_13SystemAddressERNS_14DataStatisticsEb
char __fastcall RakNet::RakPeer::GetDataStatistics(__int64 a1, __int64 a2, __int64 a3, char a4)
{
  __int64 v8; // r13
  __int64 v9; // r12
  unsigned __int64 v10; // r13
  __int64 v12; // r12
  __int128 v13; // xmm0
  __int128 v14; // xmm1
  __int128 v15; // xmm2

  if ( *(_DWORD *)(a1 + 752) != 0 ) /*0x1039bec7e*/
  {
    v8 = 0; /*0x1039bec80*/
    while ( (unsigned __int8)RakNet::SystemAddress::operator==( /*0x1039bec9c*/
                               a1: *(_QWORD *)(*(_QWORD *)(a1 + 744) + 8 * v8) + 4LL,
                               a2) == 0 )
    {
      if ( ++v8 >= (unsigned __int64)*(unsigned int *)(a1 + 752) ) /*0x1039becab*/
        goto LABEL_5; /*0x1039becab*/
    }
    v12 = *(_QWORD *)(*(_QWORD *)(a1 + 744) + 8 * v8) + 1288LL; /*0x1039bed16*/
  }
  else
  {
LABEL_5:
    if ( a4 == 0 || *(_QWORD *)(a1 + 736) == 0 || *(_WORD *)(a1 + 170) == 0 ) /*0x1039becc5*/
      return 0; /*0x1039bed07*/
    v9 = 1288; /*0x1039becc7*/
    v10 = 0; /*0x1039beccd*/
    while ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: *(_QWORD *)(a1 + 736) + v9 - 1284, a2) == 0 ) /*0x1039becec*/
    {
      ++v10; /*0x1039becee*/
      v9 += 5368; /*0x1039becf9*/
      if ( v10 >= *(unsigned __int16 *)(a1 + 170) ) /*0x1039bed03*/
        return 0; /*0x1039bed03*/
    }
    v12 = *(_QWORD *)(a1 + 736) + v9; /*0x1039bed64*/
  }
  *(_QWORD *)(a3 + 80) = *(_QWORD *)(v12 + 80); /*0x1039bed1f*/
  *(_OWORD *)(a3 + 64) = *(_OWORD *)(v12 + 64); /*0x1039bed29*/
  v13 = *(_OWORD *)v12; /*0x1039bed2d*/
  v14 = *(_OWORD *)(v12 + 16); /*0x1039bed32*/
  v15 = *(_OWORD *)(v12 + 32); /*0x1039bed38*/
  *(_OWORD *)(a3 + 48) = *(_OWORD *)(v12 + 48); /*0x1039bed44*/
  *(_OWORD *)(a3 + 32) = v15; /*0x1039bed48*/
  *(_OWORD *)(a3 + 16) = v14; /*0x1039bed4c*/
  *(_OWORD *)a3 = v13; /*0x1039bed50*/
  return 1; /*0x1039bed59*/
}

// Address: 0x1039bed6e | Name: __ZN6RakNet7RakPeer19SetUserUpdateThreadEPFvPNS_16RakPeerInterfaceEPvES3_
void __fastcall RakNet::RakPeer::SetUserUpdateThread(
        RakNet::RakPeer *this,
        void (__fastcall *a2)(RakNet::RakPeerInterface *, void *),
        void *a3)
{
  *((_QWORD *)this + 312) = a2; /*0x1039bed72*/
  *((_QWORD *)this + 313) = a3; /*0x1039bed79*/
}

// Address: 0x1039bed82 | Name: __ZN6RakNet7RakPeer13GetStatisticsENS_13SystemAddressEPNS_16RakNetStatisticsE
void *__fastcall RakNet::RakPeer::GetStatistics(
        __int64 a1,
        void *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7,
        __int64 a8,
        __int64 a9,
        __int64 a10)
{
  __int64 v11; // rbx
  void *v12; // r14
  __int64 v13; // r8
  __int64 v14; // r9
  unsigned __int64 v15; // r14
  __int64 i; // rcx
  __int64 v17; // rcx
  void **v18; // rdx
  void *v19; // rax
  __int64 j; // rbx
  void **v21; // rdi
  __int64 RemoteSystemFromSystemAddress; // rax
  int v24; // [rsp+1Ch] [rbp-2A4h]
  void *__src[76]; // [rsp+20h] [rbp-2A0h] BYREF
  void *v26; // [rsp+280h] [rbp-40h]
  __int64 v27; // [rsp+288h] [rbp-38h]
  void *__dst; // [rsp+290h] [rbp-30h]

  v11 = a1; /*0x1039bed99*/
  v27 = a1; /*0x1039beda4*/
  if ( (_BYTE)`guard variable for'RakNet::RakPeer::GetStatistics(RakNet::SystemAddress,RakNet::RakNetStatistics *)::staticStatistics == 0 /*0x1039bf01e*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::RakPeer::GetStatistics(RakNet::SystemAddress,RakNet::RakNetStatistics *)::staticStatistics) != 0 )
  {
    RakNet::RakNetStatistics::RakNetStatistics(this: (RakNet::RakNetStatistics *)&RakNet::RakPeer::GetStatistics(RakNet::SystemAddress,RakNet::RakNetStatistics *)::staticStatistics); /*0x1039bf02b*/
    __cxa_atexit( /*0x1039bf045*/
      lpfunc: RakNet::RakNetStatistics::~RakNetStatistics,
      obj: &RakNet::RakPeer::GetStatistics(RakNet::SystemAddress,RakNet::RakNetStatistics *)::staticStatistics,
      lpdso_handle: (void *)&_mh_execute_header);
    __cxa_guard_release(a1: &`guard variable for'RakNet::RakPeer::GetStatistics(RakNet::SystemAddress,RakNet::RakNetStatistics *)::staticStatistics); /*0x1039bf051*/
    v11 = v27; /*0x1039bf056*/
  }
  v12 = &RakNet::RakPeer::GetStatistics(RakNet::SystemAddress,RakNet::RakNetStatistics *)::staticStatistics; /*0x1039bedb5*/
  if ( a2 != nullptr ) /*0x1039bedbc*/
    v12 = a2; /*0x1039bedbc*/
  if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: &a7, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 ) /*0x1039bedd1*/
  {
    if ( *(_WORD *)(v11 + 170) != 0 ) /*0x1039beddf*/
    {
      __dst = v12; /*0x1039bede5*/
      v15 = 0; /*0x1039bedfa*/
      v26 = nullptr; /*0x1039bedfd*/
      do /*0x1039befa4*/
      {
        if ( (*(_BYTE *)(*(_QWORD *)(v11 + 736) + 5368 * v15) & 1) != 0 ) /*0x1039bee19*/
        {
          for ( i = 4; i != 36; i += 8 ) /*0x1039bee1f*/
          {
            *((_BYTE *)&v24 + i) = 0; /*0x1039bee24*/
            *((_BYTE *)__src + i) = 0; /*0x1039bee2c*/
          }
          LOBYTE(__src[4]) = 0; /*0x1039bee3e*/
          BYTE4(__src[4]) = 0; /*0x1039bee45*/
          LOBYTE(__src[5]) = 0; /*0x1039bee4c*/
          BYTE4(__src[5]) = 0; /*0x1039bee53*/
          LOBYTE(__src[6]) = 0; /*0x1039bee5a*/
          BYTE4(__src[6]) = 0; /*0x1039bee61*/
          LOBYTE(__src[7]) = 0; /*0x1039bee68*/
          BYTE4(__src[7]) = 0; /*0x1039bee6f*/
          v17 = 128; /*0x1039bee76*/
          v18 = &__src[11]; /*0x1039bee7b*/
          do /*0x1039bee9e*/
          {
            *(v18 - 3) = v18; /*0x1039bee82*/
            *(v18 - 2) = nullptr; /*0x1039bee86*/
            *(v18 - 1) = (void *)4; /*0x1039bee8e*/
            v18 += 4; /*0x1039bee96*/
            v17 -= 32; /*0x1039bee9a*/
          }
          while ( v17 != 0 ); /*0x1039bee9e*/
          memset(&__src[65], 0, 80); /*0x1039beec7*/
          memset(&__src[24], 0, 64); /*0x1039beee2*/
          memset(&__src[54], 0, 28); /*0x1039beef0*/
          memset(&__src[58], 0, 52); /*0x1039bef0b*/
          RakNet::ReliabilityLayer::GetStatistics( /*0x1039bef39*/
            this: (RakNet::ReliabilityLayer *)(*(_QWORD *)(v11 + 736) + 5368 * v15 + 392),
            a2: (RakNet::RakNetStatistics *)__src);
          if ( ((unsigned __int8)v26 & 1) != 0 ) /*0x1039bef42*/
          {
            RakNet::RakNetStatistics::operator+=(a1: __dst, a2: __src); /*0x1039bef4f*/
          }
          else
          {
            v19 = memcpy(__dst, __src, __n: 0x260u); /*0x1039bef66*/
            LOBYTE(v19) = 1; /*0x1039bef6b*/
            v26 = v19; /*0x1039bef6d*/
          }
          for ( j = 0; j != -16; j -= 4 ) /*0x1039bef71*/
          {
            v21 = (void **)__src[j + 20]; /*0x1039bef73*/
            if ( &__src[j + 23] != v21 ) /*0x1039bef82*/
              operator delete(a1: v21); /*0x1039bef84*/
          }
          v11 = v27; /*0x1039bef93*/
        }
        ++v15; /*0x1039bef97*/
      }
      while ( v15 < *(unsigned __int16 *)(v11 + 170) ); /*0x1039befa4*/
      return __dst; /*0x1039befaa*/
    }
  }
  else
  {
    v24 = HIDWORD(a10); /*0x1039befbb*/
    RemoteSystemFromSystemAddress = RakNet::RakPeer::GetRemoteSystemFromSystemAddress( /*0x1039befd0*/
                                      a1: v11,
                                      a2: 0,
                                      a3: 0,
                                      a4: -1,
                                      a5: v13,
                                      a6: v14,
                                      a7);
    if ( RemoteSystemFromSystemAddress != 0 && (*(_BYTE *)(v11 + 160) & 1) == 0 ) /*0x1039befe3*/
      RakNet::ReliabilityLayer::GetStatistics( /*0x1039beff6*/
        this: (RakNet::ReliabilityLayer *)(RemoteSystemFromSystemAddress + 392),
        a2: (RakNet::RakNetStatistics *)v12);
    else
      return nullptr; /*0x1039befe5*/
  }
  return v12; /*0x1039beffe*/
}

// Address: 0x1039bf1e8 | Name: __ZN6RakNet7RakPeer13GetStatisticsEiPNS_16RakNetStatisticsE
char __fastcall RakNet::RakPeer::GetStatistics(RakNet::RakPeer *this, int a2, RakNet::RakNetStatistics *a3)
{
  __int64 v3; // rax

  if ( *((unsigned __int16 *)this + 85) <= a2 ) /*0x1039bf1f1*/
    return 0; /*0x1039bf1f1*/
  v3 = 5368LL * a2; /*0x1039bf1fd*/
  if ( (*(_BYTE *)(*((_QWORD *)this + 92) + v3) & 1) == 0 ) /*0x1039bf20a*/
    return 0; /*0x1039bf22e*/
  RakNet::ReliabilityLayer::GetStatistics(this: (RakNet::ReliabilityLayer *)(*((_QWORD *)this + 92) + v3 + 392), a2: a3); /*0x1039bf225*/
  return 1; /*0x1039bf22d*/
}

// Address: 0x1039bf232 | Name: __ZNK6RakNet7RakPeer23GetPerSecTxBwStatisticsENS_13SystemAddressERNS_8TxBwDataE
__int64 __fastcall RakNet::RakPeer::GetPerSecTxBwStatistics(
        __int64 a1,
        _OWORD *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int128 a7)
{
  unsigned int v9; // r14d
  _OWORD *RemoteSystemFromSystemAddress; // rax
  __int128 v11; // xmm0
  __int128 v12; // xmm1
  __int128 v13; // xmm2

  v9 = 0; /*0x1039bf256*/
  RemoteSystemFromSystemAddress = (_OWORD *)RakNet::RakPeer::GetRemoteSystemFromSystemAddress( /*0x1039bf262*/
                                              a1,
                                              a2: 0,
                                              a3: 0,
                                              a4: -1,
                                              a5,
                                              a6,
                                              a7);
  if ( RemoteSystemFromSystemAddress != nullptr ) /*0x1039bf26a*/
  {
    if ( (*(_BYTE *)(a1 + 160) & 1) != 0 ) /*0x1039bf276*/
    {
      return 0; /*0x1039bf278*/
    }
    else
    {
      a2[4] = RemoteSystemFromSystemAddress[90]; /*0x1039bf284*/
      v11 = RemoteSystemFromSystemAddress[86]; /*0x1039bf288*/
      v12 = RemoteSystemFromSystemAddress[87]; /*0x1039bf28f*/
      v13 = RemoteSystemFromSystemAddress[88]; /*0x1039bf296*/
      a2[3] = RemoteSystemFromSystemAddress[89]; /*0x1039bf2a4*/
      a2[2] = v13; /*0x1039bf2a8*/
      a2[1] = v12; /*0x1039bf2ac*/
      *a2 = v11; /*0x1039bf2b0*/
      LOBYTE(v9) = 1; /*0x1039bf2b3*/
    }
  }
  return v9; /*0x1039bf2b9*/
}

// Address: 0x1039bf2c4 | Name: __ZNK6RakNet7RakPeer27GetBandwidthManagerFeedbackENS_13SystemAddressERNS_28BandwidthManagerFeedbackDataE
__int64 __fastcall RakNet::RakPeer::GetBandwidthManagerFeedback(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int128 a7)
{
  unsigned int v9; // r14d
  __int64 RemoteSystemFromSystemAddress; // rax

  v9 = 0; /*0x1039bf2e8*/
  RemoteSystemFromSystemAddress = RakNet::RakPeer::GetRemoteSystemFromSystemAddress( /*0x1039bf2f4*/
                                    a1,
                                    a2: 0,
                                    a3: 0,
                                    a4: -1,
                                    a5,
                                    a6,
                                    a7);
  if ( RemoteSystemFromSystemAddress != 0 ) /*0x1039bf2fc*/
  {
    if ( (*(_BYTE *)(a1 + 160) & 1) != 0 ) /*0x1039bf308*/
    {
      return 0; /*0x1039bf30a*/
    }
    else
    {
      RakNet::ReliabilityLayer::GetBandwidthManagerFeedback(a1: RemoteSystemFromSystemAddress + 392, a2); /*0x1039bf31b*/
      LOBYTE(v9) = 1; /*0x1039bf320*/
    }
  }
  return v9; /*0x1039bf326*/
}

// Address: 0x1039bf332 | Name: __ZNK6RakNet7RakPeer22getUsableBandwidthMbpsEv
double __fastcall RakNet::RakPeer::getUsableBandwidthMbps(RakNet::RakPeer *this)
{
  void *v3[9]; // [rsp+8h] [rbp-238h] BYREF
  _BYTE v4[472]; // [rsp+50h] [rbp-1F0h] BYREF
  double v5; // [rsp+228h] [rbp-18h]

  if ( *((_QWORD *)this + 424) == 0 ) /*0x1039bf348*/
    return -1.0; /*0x1039bf3ae*/
  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1039bf35e*/
    a1: v3,
    a2: (__int64)&RBX::Telemetry::kRakNetDownloadBandwidthReadCount);
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v3); /*0x1039bf366*/
  v5 = (*(double (__fastcall **)(_QWORD))(**((_QWORD **)this + 424) + 24LL))(a1: *((_QWORD *)this + 424)); /*0x1039bf378*/
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v4); /*0x1039bf38f*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v3, a2: (void **)off_10C8C7EB0); /*0x1039bf3a2*/
  return v5; /*0x1039bf3b6*/
}

// Address: 0x1039bf3da | Name: __ZN6RakNet7RakPeer26ReportRakNetHandshakeStatsEb
__int64 __fastcall RakNet::RakPeer::ReportRakNetHandshakeStats(RakNet::RakPeer *this, bool a2)
{
  return RakNet::RakPeer::ConnectionRequestsStats::Report(this: (RakNet::RakPeer *)((char *)this + 3200), a2); /*0x1039bf3e5*/
}

// Address: 0x1039bf676 | Name: __ZN6RakNet7RakPeer20GetReceiveBufferSizeEv
__int64 __fastcall RakNet::RakPeer::GetReceiveBufferSize(RakNet::RakPeer *this)
{
  RakNet::SimpleMutex *v2; // rbx
  unsigned int v3; // ecx
  unsigned int v4; // r15d
  bool v5; // cf
  unsigned int v6; // r15d

  v2 = (RakNet::RakPeer *)((char *)this + 2784); /*0x1039bf683*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2784)); /*0x1039bf68d*/
  v3 = *((_DWORD *)this + 714); /*0x1039bf692*/
  v4 = *((_DWORD *)this + 715); /*0x1039bf6a0*/
  v5 = v4 < v3; /*0x1039bf6a3*/
  v6 = v4 - v3; /*0x1039bf6a3*/
  if ( v5 ) /*0x1039bf6a6*/
    v6 = *((_DWORD *)this + 716) + *((_DWORD *)this + 715) - v3; /*0x1039bf6b1*/
  RakNet::SimpleMutex::Unlock(this: v2); /*0x1039bf6b7*/
  return v6; /*0x1039bf6c3*/
}

// Address: 0x1039bf6ca | Name: __ZN6RakNet7RakPeer26convertConnectModeToStringEj
const char *__fastcall RakNet::RakPeer::convertConnectModeToString(RakNet::RakPeer *this, unsigned int a2)
{
  if ( a2 > 7 ) /*0x1039bf6d1*/
    return "Unknown"; /*0x1039bf6e2*/
  else
    return off_10C903308[a2]; /*0x1039bf6dc*/
}

// Address: 0x1039bf6ec | Name: __ZNK6RakNet7RakPeer21getCommonCapabilitiesENS_13SystemAddressE
__int64 __fastcall RakNet::RakPeer::getCommonCapabilities(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  __int64 v8; // r12
  __int64 v9; // rbx
  unsigned __int64 v10; // r13

  if ( *(_QWORD *)(a1 + 736) == 0 || *(_WORD *)(a1 + 170) == 0 ) /*0x1039bf70f*/
    return 0; /*0x1039bf757*/
  v8 = 5256; /*0x1039bf715*/
  v9 = 0; /*0x1039bf71b*/
  v10 = 0; /*0x1039bf71d*/
  while ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: *(_QWORD *)(a1 + 736) + v8 - 5252, a2: &a7) == 0 ) /*0x1039bf73c*/
  {
    ++v10; /*0x1039bf73e*/
    v8 += 5368; /*0x1039bf749*/
    if ( v10 >= *(unsigned __int16 *)(a1 + 170) ) /*0x1039bf753*/
      return v9; /*0x1039bf753*/
  }
  return *(_QWORD *)(*(_QWORD *)(a1 + 736) + v8); /*0x1039bf76d*/
}

// Address: 0x1039bf778 | Name: __ZNK6RakNet7RakPeer30doesPeerHaveCapabilityInCommonENS_13SystemAddressEN3RBX7Network14CapabilityBitsE
bool __fastcall RakNet::RakPeer::doesPeerHaveCapabilityInCommon(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int128 a7,
        __int128 a8)
{
  return (a2 /*0x1039bf7a4*/
        & (*(__int64 (__fastcall **)(__int64, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)a1 + 688LL))(
            a1,
            a2,
            a3,
            a4,
            a5,
            a6,
            a7,
            a8: *((_QWORD *)&a7 + 1),
            a9: a8,
            a10: *((_QWORD *)&a8 + 1))) != 0;
}

// Address: 0x1039bf8f4 | Name: __ZN6RakNet7RakPeer21SendConnectionRequestEPKctS2_iPNS_9PublicKeyEjjjjjNSt3__110shared_ptrINS_12RakNetSocketEEE
__int64 __fastcall RakNet::RakPeer::SendConnectionRequest(
        __int64 a1,
        const char *a2,
        unsigned __int16 a3,
        const void *a4,
        int a5,
        __int64 a6,
        int a7,
        int a8,
        int a9,
        int a10,
        int a11,
        __int64 a12)
{
  __int64 v17; // r8
  __int64 v18; // r9
  unsigned int v19; // r14d
  __int64 v20; // r14
  RakNet *v21; // rdi
  RBX::Security::SessionCrypto *v22; // r15
  int v23; // r8d
  int v24; // r9d
  unsigned int v25; // r13d
  unsigned int v26; // eax
  unsigned int v27; // ecx
  unsigned int v28; // edx
  unsigned int v29; // edx
  char v30; // al
  __int128 v32; // [rsp+10h] [rbp-4E0h]
  _BYTE v33[24]; // [rsp+20h] [rbp-4D0h] BYREF
  __int64 v34; // [rsp+38h] [rbp-4B8h]
  _BYTE *v35; // [rsp+40h] [rbp-4B0h]
  _QWORD v36[4]; // [rsp+48h] [rbp-4A8h] BYREF
  __int64 v37; // [rsp+68h] [rbp-488h] BYREF
  void *v38[3]; // [rsp+70h] [rbp-480h] BYREF
  int v39; // [rsp+88h] [rbp-468h]
  __int64 v40; // [rsp+90h] [rbp-460h]
  __int64 v41; // [rsp+98h] [rbp-458h]
  __int64 v42; // [rsp+A0h] [rbp-450h]
  RakNet::SimpleMutex *v43; // [rsp+A8h] [rbp-448h]
  char v44[1040]; // [rsp+B0h] [rbp-440h] BYREF

  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v36); /*0x1039bf92c*/
  RakNet::SystemAddress::FromStringExplicitPort(this: (RakNet::SystemAddress *)v36, a2, a3); /*0x1039bf93f*/
  v32 = *(_OWORD *)&v36[2]; /*0x1039bf952*/
  v19 = 3; /*0x1039bf96f*/
  if ( RakNet::RakPeer::GetRemoteSystemFromSystemAddress(a1, a2: 0, a3: 1u, a4: -1, a5: v17, a6: v18, a7: v36[0]) == 0 )
  {
    v20 = operator new(a1: 0x180u); /*0x1039bf988*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v20); /*0x1039bf98e*/
    *(_BYTE *)(v20 + 324) = 0; /*0x1039bf993*/
    *(_OWORD *)(v20 + 344) = 0; /*0x1039bf99e*/
    *(_OWORD *)(v20 + 360) = 0; /*0x1039bf9a6*/
    v37 = v20; /*0x1039bf9ae*/
    RakNet::SystemAddress::operator=(a1: v20, a2: v36); /*0x1039bf9bf*/
    *(_QWORD *)(v20 + 32) = (unsigned int)RakNet::GetTimeMS(this: v21); /*0x1039bf9de*/
    *(_BYTE *)(v20 + 40) = 0; /*0x1039bf9e2*/
    *(_QWORD *)(v20 + 48) = 0; /*0x1039bf9e7*/
    *(_DWORD *)(v20 + 320) = a8; /*0x1039bf9ef*/
    *(_DWORD *)(v20 + 316) = a7; /*0x1039bf9f6*/
    *(_DWORD *)(v20 + 380) = 1; /*0x1039bf9fd*/
    *(_DWORD *)(v20 + 328) = a9; /*0x1039bfa08*/
    *(_DWORD *)(v20 + 332) = a10; /*0x1039bfa0f*/
    memcpy(__dst: (void *)(v20 + 58), __src: a4, __n: a5); /*0x1039bfa23*/
    *(_BYTE *)(v20 + 314) = a5; /*0x1039bfa28*/
    *(_DWORD *)(v20 + 336) = a11; /*0x1039bfa32*/
    v41 = v20 + 344; /*0x1039bfa39*/
    std::shared_ptr<RakNet::RakNetSocket>::operator=[abi:ne200100](a1: v20 + 344, a2: a12); /*0x1039bfa47*/
    v22 = (RBX::Security::SessionCrypto *)operator new(a1: 0x80u); /*0x1039bfa56*/
    *((_OWORD *)v22 + 7) = 0; /*0x1039bfa5c*/
    *((_OWORD *)v22 + 6) = 0; /*0x1039bfa60*/
    *((_OWORD *)v22 + 5) = 0; /*0x1039bfa64*/
    *((_OWORD *)v22 + 4) = 0; /*0x1039bfa68*/
    *((_OWORD *)v22 + 3) = 0; /*0x1039bfa6c*/
    *((_OWORD *)v22 + 2) = 0; /*0x1039bfa70*/
    *((_OWORD *)v22 + 1) = 0; /*0x1039bfa74*/
    *(_OWORD *)v22 = 0; /*0x1039bfa78*/
    RBX::Security::SessionCrypto::SessionCrypto(this: v22); /*0x1039bfa7e*/
    *(_QWORD *)v22 = off_10C903070; /*0x1039bfa8a*/
    std::shared_ptr<RBX::Security::RakPeerCrypto>::reset[abi:ne200100]<RBX::Security::RakPeerCrypto,0>( /*0x1039bfa9d*/
      a1: v20 + 360,
      a2: v22);
    RBX::Security::RakPeerCrypto::getClientKeyInfo(this: (RBX::Security::RakPeerCrypto *)v38, a2: *(_BYTE *)(a1 + 3088)); /*0x1039bfab0*/
    RBX::Security::RakPeerCrypto::initClient(this: *(RBX::Security::SessionCrypto **)(v20 + 360)); /*0x1039bfaca*/
    v42 = v20 + 360; /*0x1039bfacf*/
    *(_DWORD *)(v20 + 376) = v39; /*0x1039bfadc*/
    v43 = (RakNet::SimpleMutex *)(a1 + 1160); /*0x1039bfaea*/
    RakNet::SimpleMutex::Lock(this: (RakNet::SimpleMutex *)(a1 + 1160)); /*0x1039bfaf1*/
    v40 = a1 + 1136; /*0x1039bfafd*/
    v25 = 0; /*0x1039bfb0e*/
    while ( 1 ) /*0x1039bfb11*/
    {
      v26 = *(_DWORD *)(a1 + 1144); /*0x1039bfb11*/
      v27 = *(_DWORD *)(a1 + 1148); /*0x1039bfb17*/
      v28 = v27 - v26; /*0x1039bfb1f*/
      if ( v27 < v26 ) /*0x1039bfb21*/
      {
        v27 = *(_DWORD *)(a1 + 1152) + v27 - v26; /*0x1039bfb25*/
        v28 = v27; /*0x1039bfb2b*/
      }
      if ( v25 >= v28 ) /*0x1039bfb30*/
        break; /*0x1039bfb30*/
      v29 = *(_DWORD *)(a1 + 1152); /*0x1039bfb36*/
      if ( v26 + v25 < v29 ) /*0x1039bfb3e*/
        v29 = 0; /*0x1039bfb3e*/
      v30 = RakNet::SystemAddress::operator==( /*0x1039bfb55*/
              a1: *(_QWORD *)(*(_QWORD *)(a1 + 1136) + 8LL * (v25 + v26 - v29)),
              a2: v36);
      ++v25; /*0x1039bfb5a*/
      if ( v30 != 0 ) /*0x1039bfb5f*/
      {
        RakNet::SimpleMutex::Unlock(this: v43); /*0x1039bfb68*/
        std::shared_ptr<RBX::Security::RakPeerCrypto>::~shared_ptr[abi:ne200100](a1: v42); /*0x1039bfb74*/
        std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: v41); /*0x1039bfb80*/
        operator delete(a1: (void *)v20); /*0x1039bfb88*/
        v19 = 4; /*0x1039bfb8d*/
        goto LABEL_16; /*0x1039bfb93*/
      }
    }
    if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
    {
      LOBYTE(v27) = (unsigned __int8)DFLog::RakNetConnectTrace < 6u; /*0x1039bfba8*/
      FLog::FastLogFormatted(
        a1: (_DWORD)DFLog::RakNetConnectTrace,
        a2: qword_10D7BB0C8,
        a3: (unsigned int)"[DFLog::RakNetConnectTrace] RakNet: Added connect request to queue (2)",
        a4: v27,
        a5: v23,
        a6: v24);
    }
    DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push(a1: v40, a2: &v37); /*0x1039bfbe0*/
    RakNet::SimpleMutex::Unlock(this: v43); /*0x1039bfbec*/
    v19 = 0; /*0x1039bfbf1*/
    if ( (_BYTE)DFLog::RakNetConnectTrace != 0 && DFFlag::DebugRakNetConnectTracePrintRcsSystemAddress == 1 )
    {
      RakNet::SystemAddress::ToStringN(this: (RakNet::SystemAddress *)v36, a2: true, a3: v44, a4: 1025, a5: 124); /*0x1039bfc2f*/
      if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
      {
        v34 = 12; /*0x1039bfc61*/
        v35 = v33; /*0x1039bfc6c*/
        FLog::detail::FastLogSafeFormattedInternal(
          a1: (_DWORD)DFLog::RakNetConnectTrace,
          a2: qword_10D7BB0C8,
          a3: 3,
          a4: (unsigned int)"[DFLog::RakNetConnectTrace] RCS was added for: {}",
          a5: 49,
          a6: 1,
          12,
          v33,
          v32,
          v44);
      }
    }
LABEL_16:
    if ( v38[0] != nullptr ) /*0x1039bfca5*/
    {
      v38[1] = v38[0]; /*0x1039bfca7*/
      operator delete(a1: v38[0]); /*0x1039bfcae*/
    }
  }
  return v19; /*0x1039bfcc6*/
}

// Address: 0x1039bfd6e | Name: __ZNK6RakNet7RakPeer26ValidateRemoteSystemLookupEv
void __fastcall RakNet::RakPeer::ValidateRemoteSystemLookup(RakNet::RakPeer *this)
{
  ; /*0x1039bfd6e*/
}

// Address: 0x1039bfd74 | Name: __ZNK6RakNet7RakPeer23GetRemoteSystemFromGUIDENS_10RakNetGUIDEb
__int64 __fastcall RakNet::RakPeer::GetRemoteSystemFromGUID(__int64 a1, __int64 a2, __int16 a3, char a4)
{
  __int64 v6; // r15
  unsigned __int64 v7; // r13
  _QWORD v10[7]; // [rsp+8h] [rbp-38h] BYREF

  v10[0] = a2; /*0x1039bfd8e*/
  LOWORD(v10[1]) = a3; /*0x1039bfd91*/
  if ( (unsigned __int8)RakNet::RakNetGUID::operator==(a1: v10, a2: &RakNet::UNASSIGNED_RAKNET_GUID) != 0 /*0x1039bfdae*/
    || *(_WORD *)(a1 + 170) == 0 )
  {
    return 0; /*0x1039bfe02*/
  }
  v6 = 0; /*0x1039bfdb4*/
  v7 = 0; /*0x1039bfdb7*/
  while ( (unsigned __int8)RakNet::RakNetGUID::operator==(a1: *(_QWORD *)(a1 + 736) + v6 + 5200, a2: v10) == 0 /*0x1039bfde9*/
       || a4 != 0 && (*(_BYTE *)(*(_QWORD *)(a1 + 736) + v6) & 1) == 0 )
  {
    ++v7; /*0x1039bfdeb*/
    v6 += 5368; /*0x1039bfdf6*/
    if ( v7 >= *(unsigned __int16 *)(a1 + 170) ) /*0x1039bfe00*/
      return 0; /*0x1039bfe00*/
  }
  return *(_QWORD *)(a1 + 736) + v6; /*0x1039bfe08*/
}

// Address: 0x1039bfe20 | Name: __ZN6RakNet7RakPeer28ParseConnectionRequestPacketEPNS0_18RemoteSystemStructERKNS_13SystemAddressEPKci
__int64 __fastcall RakNet::RakPeer::ParseConnectionRequestPacket(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        const RakNet::SystemAddress *a3,
        char *a4,
        unsigned int a5)
{
  unsigned int v8; // ecx
  unsigned int v9; // ecx
  unsigned int v10; // eax
  size_t v11; // rdx
  RakNet::RakPeer *v12; // rdi
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // rsi
  __int64 v16; // r8
  __int64 v17; // r9
  unsigned int v18; // ecx
  unsigned __int8 *v19; // r12
  int v20; // r12d
  int v21; // r13d
  bool v22; // si
  unsigned __int64 TimeUS; // rax
  RakNet::RakPeer::RemoteSystemStruct *v25; // rbx
  RakNet::BitStream *v26; // rdi
  RakNet::BitStream *v27; // rdi
  RakNet::BitStream *v28; // rdi
  unsigned __int8 v29[16]; // [rsp+38h] [rbp-2D8h] BYREF
  unsigned __int8 v30[8]; // [rsp+48h] [rbp-2C8h] BYREF
  RakNet::RakPeer::RemoteSystemStruct *v31; // [rsp+50h] [rbp-2C0h]
  unsigned __int8 v32; // [rsp+5Fh] [rbp-2B1h] BYREF
  unsigned __int8 v33[16]; // [rsp+60h] [rbp-2B0h] BYREF
  __int128 v34; // [rsp+70h] [rbp-2A0h]
  unsigned __int8 v35[12]; // [rsp+90h] [rbp-280h] BYREF
  int v36; // [rsp+9Ch] [rbp-274h]
  __int64 v37; // [rsp+A8h] [rbp-268h]
  _BYTE v38[20]; // [rsp+1B8h] [rbp-158h] BYREF
  int v39; // [rsp+1CCh] [rbp-144h]
  __int64 v40; // [rsp+1D0h] [rbp-140h]

  v31 = a2; /*0x1039bfe3a*/
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v38, a2: (unsigned __int8 *)a4, a3: a5, a4: false); /*0x1039bfe61*/
  RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v38, a2: 1u); /*0x1039bfe72*/
  RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)v29); /*0x1039bfe7e*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c0181*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v26); /*0x1039c018c*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c0199*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039bfe98*/
  {
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v38, a2: v29, a3: 0x40u, a4: true); /*0x1039bfeb2*/
  }
  else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v38, a2: v35, a3: 0x40u, a4: true) != 0 ) /*0x1039bfed8*/
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v35, a2: v29, a3: (unsigned __int8 *)8, a4: v8); /*0x1039bfeed*/
  }
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c01b1*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v27); /*0x1039c01bc*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c01c9*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039bff07*/
  {
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v38, a2: v30, a3: 0x40u, a4: true); /*0x1039bff21*/
  }
  else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v38, a2: v35, a3: 0x40u, a4: true) != 0 ) /*0x1039bff47*/
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v35, a2: v30, a3: (unsigned __int8 *)8, a4: v9); /*0x1039bff5c*/
  }
  RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v38, a2: &v32, a3: 8u, a4: true); /*0x1039bff79*/
  v10 = (unsigned int)(v39 + 7) >> 3; /*0x1039bff87*/
  v11 = *((unsigned __int8 *)this + 472); /*0x1039bff8d*/
  if ( a5 - v10 == (_DWORD)v11 && memcmp(__s1: (const void *)(v40 + v10), __s2: (char *)this + 473, __n: v11) == 0 ) /*0x1039bffb1*/
  {
    v25 = v31; /*0x1039c0146*/
    *((_DWORD *)v31 + 1341) = 5; /*0x1039c014d*/
    RakNet::RakPeer::rbxProcessApplicationConnectionRequest(this: v12, a2: v25); /*0x1039c015a*/
    RakNet::RakPeer::OnConnectionRequest(this, a2: v25, a3: *(unsigned __int64 *)v30); /*0x1039c016c*/
  }
  else
  {
    RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v35); /*0x1039bffbe*/
    v33[0] = 24; /*0x1039bffca*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v35, a2: v33, a3: 8u, a4: true); /*0x1039bffde*/
    v34 = *(__int128 *)((char *)&xmmword_10CDB0CBC + 4); /*0x1039bffea*/
    *(_OWORD *)v33 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039bfff8*/
    v19 = (unsigned __int8 *)(*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)this + 424LL))( /*0x1039c0025*/
                               a1: this,
                               a2: v15,
                               a3: v13,
                               a4: v14,
                               a5: v16,
                               a6: v17,
                               a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
                               a8: unk_10CDB0CB8,
                               a9: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 4),
                               a10: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 12));
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c01e6*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v28); /*0x1039c01f1*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c01fe*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c003d*/
    {
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v35, a2: v19, a3: 0x40u, a4: true); /*0x1039c0053*/
    }
    else
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v19, a2: v33, a3: (unsigned __int8 *)8, a4: v18); /*0x1039c0069*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v35, a2: v33, a3: 0x40u, a4: true); /*0x1039c0086*/
    }
    v20 = v37; /*0x1039c008b*/
    v21 = v36; /*0x1039c0092*/
    RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v33, a2: a3); /*0x1039c00a6*/
    TimeUS = RakNet::GetTimeUS(this: nullptr, a2: v22); /*0x1039c00af*/
    RakNet::RakPeer::SendImmediate( /*0x1039c00f2*/
      a1: (_DWORD)this,
      a2: v20,
      a3: (unsigned int)(v21 + 7) >> 3,
      a4: 0,
      a5: 2,
      a6: 0,
      a7: (__int64)v33,
      a8: 0,
      a9: 0,
      a10: TimeUS,
      a11: 0,
      a12: 0,
      a13: 0);
    *((_DWORD *)v31 + 1341) = 2; /*0x1039c00fe*/
    RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v35); /*0x1039c010f*/
  }
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v38); /*0x1039c011b*/
  return __stack_chk_guard; /*0x1039c0134*/
}

// Address: 0x1039c0368 | Name: __ZN6RakNet7RakPeer13SendImmediateEPcj14PacketPriority17PacketReliabilitycNS_13AddressOrGUIDEbbyjyb
__int64 __fastcall RakNet::RakPeer::SendImmediate(
        __int64 a1,
        __int64 a2,
        int a3,
        int a4,
        unsigned int a5,
        int a6,
        __int64 a7,
        char a8,
        char a9,
        unsigned __int64 a10,
        int a11,
        __int64 a12,
        unsigned __int8 a13)
{
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // r8
  __int64 v18; // r9
  unsigned int IndexFromSystemAddress; // eax
  __int64 v20; // rdi
  __int64 v21; // rcx
  __int64 v22; // r12
  __int64 v23; // rbx
  __int64 v24; // r14
  unsigned __int64 v25; // r15
  __int64 v26; // rax
  __int64 v27; // r15
  unsigned int v28; // r13d
  char *v29; // r14
  bool v30; // bl
  __int64 v31; // rax
  unsigned int v32; // r12d
  RBX::Rupp::Rupp *v33; // r14
  std::__shared_weak_count *v34; // r13
  unsigned int HeaderTotalByteLength; // eax
  int *v36; // rdi
  int v37; // eax
  __int128 v39; // [rsp+10h] [rbp-B0h] BYREF
  _QWORD v40[2]; // [rsp+20h] [rbp-A0h] BYREF
  __int64 v41; // [rsp+30h] [rbp-90h]
  char v42[8]; // [rsp+38h] [rbp-88h]
  __int64 v43; // [rsp+40h] [rbp-80h]
  __int64 v44; // [rsp+48h] [rbp-78h]
  RBX::Rupp::Rupp *v45[2]; // [rsp+50h] [rbp-70h] BYREF
  int v46; // [rsp+68h] [rbp-58h]
  int v47; // [rsp+6Ch] [rbp-54h]
  __int64 v48; // [rsp+70h] [rbp-50h]
  int v49; // [rsp+78h] [rbp-48h]
  unsigned int v50; // [rsp+7Ch] [rbp-44h]
  char *v51; // [rsp+80h] [rbp-40h]
  __int64 v52; // [rsp+88h] [rbp-38h]

  LODWORD(v48) = a6; /*0x1039c0379*/
  v49 = a4; /*0x1039c0380*/
  v46 = a3; /*0x1039c0383*/
  v40[1] = a2; /*0x1039c0386*/
  v52 = a1; /*0x1039c03bb*/
  if ( (unsigned __int8)RakNet::SystemAddress::operator!=(a1: a7 + 16, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 ) /*0x1039c03bf*/
  {
    IndexFromSystemAddress = RakNet::RakPeer::GetIndexFromSystemAddress( /*0x1039c03df*/
                               a1,
                               a2: 1,
                               a3: v15,
                               a4: v16,
                               a5: v17,
                               a6: v18,
                               a7: *(_OWORD *)(a7 + 16),
                               a8: *(_QWORD *)(a7 + 24),
                               a9: *(_QWORD *)(a7 + 32),
                               a10: *(_QWORD *)(a7 + 40));
  }
  else
  {
    if ( (unsigned __int8)RakNet::RakNetGUID::operator!=(a1: a7, a2: &RakNet::UNASSIGNED_RAKNET_GUID) == 0 ) /*0x1039c03fb*/
    {
      IndexFromSystemAddress = -1; /*0x1039c047a*/
      v20 = v52; /*0x1039c0481*/
      if ( a8 == 0 ) /*0x1039c0485*/
        goto LABEL_42; /*0x1039c0485*/
      goto LABEL_12; /*0x1039c0485*/
    }
    IndexFromSystemAddress = RakNet::RakPeer::GetSystemIndexFromGuid( /*0x1039c040a*/
                               a1: v52,
                               a2: *(_QWORD *)a7,
                               a3: *(_DWORD *)(a7 + 8));
  }
  if ( a8 == 0 ) /*0x1039c0411*/
  {
    v20 = v52; /*0x1039c041c*/
    if ( IndexFromSystemAddress != -1 ) /*0x1039c0420*/
    {
      v21 = 5368LL * IndexFromSystemAddress; /*0x1039c0439*/
      if ( (*(_BYTE *)(*(_QWORD *)(v52 + 736) + v21) & 1) != 0 /*0x1039c045f*/
        && (unsigned int)(*(_DWORD *)(*(_QWORD *)(v52 + 736) + v21 + 5364) - 1) >= 3 )
      {
        v50 = a5; /*0x1039c0465*/
        v51 = (char *)&v39; /*0x1039c0469*/
        LODWORD(v39) = IndexFromSystemAddress; /*0x1039c046d*/
        LODWORD(v22) = 1; /*0x1039c046f*/
        goto LABEL_21; /*0x1039c0475*/
      }
    }
LABEL_42:
    LODWORD(v22) = 0; /*0x1039c06e6*/
    goto LABEL_43; /*0x1039c06e6*/
  }
  v20 = v52; /*0x1039c0413*/
LABEL_12:
  LODWORD(v22) = 0; /*0x1039c048b*/
  if ( *(_WORD *)(v20 + 170) == 0 ) /*0x1039c04aa*/
    goto LABEL_43; /*0x1039c04aa*/
  v51 = (char *)v40 - ((4 * *(unsigned __int16 *)(v20 + 170) + 15) & 0xFFFF0); /*0x1039c04b0*/
  v50 = a5; /*0x1039c04b4*/
  v23 = IndexFromSystemAddress; /*0x1039c04b8*/
  v24 = 4; /*0x1039c04ba*/
  v25 = 0; /*0x1039c04c7*/
  do /*0x1039c051b*/
  {
    if ( v23 != v25 && (*(_BYTE *)(*(_QWORD *)(v20 + 736) + v24 - 4) & 1) != 0 ) /*0x1039c04dd*/
    {
      if ( (unsigned __int8)RakNet::SystemAddress::operator!=( /*0x1039c04f3*/
                              a1: v24 + *(_QWORD *)(v20 + 736),
                              a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 )
      {
        v26 = (unsigned int)v22; /*0x1039c04f5*/
        LODWORD(v22) = v22 + 1; /*0x1039c04f8*/
        *(_DWORD *)&v51[4 * v26] = v25; /*0x1039c04ff*/
      }
      v20 = v52; /*0x1039c0503*/
    }
    ++v25; /*0x1039c0507*/
    v24 += 5368; /*0x1039c0511*/
  }
  while ( v25 < *(unsigned __int16 *)(v20 + 170) ); /*0x1039c051b*/
  if ( (_DWORD)v22 == 0 ) /*0x1039c0520*/
    goto LABEL_42; /*0x1039c0520*/
LABEL_21:
  v43 = (unsigned int)(a10 / 0x3E8); /*0x1039c0526*/
  v41 = (unsigned int)v22; /*0x1039c0548*/
  v44 = (unsigned int)v22 - 1LL; /*0x1039c0552*/
  v27 = 0; /*0x1039c0556*/
  *(_QWORD *)v42 = a13; /*0x1039c055d*/
  v47 = (unsigned __int8)v48; /*0x1039c0568*/
  v22 = 0; /*0x1039c056b*/
  v28 = v50; /*0x1039c056e*/
  v29 = v51; /*0x1039c0572*/
  do /*0x1039c06cc*/
  {
    v30 = false; /*0x1039c0576*/
    if ( a9 != 0 && (v22 & 1) == 0 ) /*0x1039c0583*/
      v30 = v44 == v27; /*0x1039c0589*/
    v31 = *(_QWORD *)(v20 + 736); /*0x1039c058c*/
    *(_OWORD *)v45 = 0; /*0x1039c059a*/
    if ( v31 != 0 ) /*0x1039c05a1*/
    {
      v48 = v22; /*0x1039c05a3*/
      v32 = v28; /*0x1039c05a7*/
      std::shared_ptr<RBX::Rupp::Rupp>::operator=[abi:ne200100](a1: v45); /*0x1039c05c0*/
      v33 = v45[0]; /*0x1039c05c5*/
      v34 = v45[1]; /*0x1039c05c9*/
      if ( v45[1] != nullptr /*0x1039c05e2*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v45[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v34 + 16LL))(a1: v34); /*0x1039c05eb*/
        std::__shared_weak_count::__release_weak(this: v34); /*0x1039c05f1*/
      }
      v28 = v32; /*0x1039c05f9*/
      if ( v33 != nullptr ) /*0x1039c05fc*/
        HeaderTotalByteLength = (unsigned __int16)RBX::Rupp::Rupp::getHeaderTotalByteLength(this: v33); /*0x1039c0606*/
      else
        HeaderTotalByteLength = 0; /*0x1039c060f*/
      v20 = v52; /*0x1039c0611*/
      LOBYTE(v22) = v48; /*0x1039c0615*/
      v29 = v51; /*0x1039c0619*/
    }
    else
    {
      HeaderTotalByteLength = 0; /*0x1039c060b*/
    }
    v36 = (int *)(*(_QWORD *)(v20 + 736) + 5368LL * *(unsigned int *)&v29[4 * v27] + 392); /*0x1039c0633*/
    RakNet::ReliabilityLayer::Send( /*0x1039c0677*/
      this: (RakNet::ReliabilityLayer *)v36,
      a2: !v30,
      a3: v36[1206],
      a4: a10,
      a5: a11,
      a6: HeaderTotalByteLength,
      a7: a12,
      a8: v42[0]);
    v20 = v52; /*0x1039c067c*/
    v22 = (unsigned __int8)v22; /*0x1039c0684*/
    if ( v30 ) /*0x1039c068f*/
      v22 = 1; /*0x1039c068f*/
    if ( v28 <= 7 ) /*0x1039c0697*/
    {
      v37 = 220; /*0x1039c0699*/
      if ( _bittest(&v37, v28) ) /*0x1039c069e*/
        *(_QWORD *)(*(_QWORD *)(v52 + 736) + 5368LL * *(unsigned int *)&v29[4 * v27] + 5176) = v43; /*0x1039c06ba*/
    }
    ++v27; /*0x1039c06c2*/
  }
  while ( v41 != v27 ); /*0x1039c06cc*/
  if ( v49 == 0 ) /*0x1039c06d6*/
    RakNet::SignaledEvent::SetEvent(this: (RakNet::SignaledEvent *)(v20 + 2560)); /*0x1039c06df*/
LABEL_43:
  LOBYTE(v22) = v22 & 1; /*0x1039c06f9*/
  return (unsigned int)v22; /*0x1039c0700*/
}

// Address: 0x1039c0714 | Name: __ZN6RakNet7RakPeer38rbxProcessApplicationConnectionRequestEPNS0_18RemoteSystemStructE
char __fastcall RakNet::RakPeer::rbxProcessApplicationConnectionRequest(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2)
{
  RBX::Security::SessionCrypto *v2; // rbx

  if ( a2 == nullptr ) /*0x1039c0717*/
    return 0; /*0x1039c073b*/
  v2 = *((RBX::Security::SessionCrypto **)a2 + 49); /*0x1039c071f*/
  if ( v2 == nullptr /*0x1039c0735*/
    || (unsigned __int8)RBX::Security::SessionCrypto::isKeyExchangeComplete(this: *((RBX::Security::SessionCrypto **)a2
                                                                                  + 49)) != 0 )
  {
    return 0; /*0x1039c0737*/
  }
  RBX::Security::SessionCrypto::resetKeyExchangeKeys(this: v2, a2: false); /*0x1039c0743*/
  return 1; /*0x1039c073d*/
}

// Address: 0x1039c0752 | Name: __ZN6RakNet7RakPeer19OnConnectionRequestEPNS0_18RemoteSystemStructEy
__int64 __fastcall RakNet::RakPeer::OnConnectionRequest(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        __int64 a3)
{
  __int128 v4; // xmm0
  __int128 v5; // xmm0
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // r8
  __int64 v9; // r9
  unsigned int v10; // ecx
  __int64 i; // r12
  __int128 v12; // xmm0
  unsigned int v13; // ecx
  RakNet::SystemAddress *v14; // r12
  bool v15; // si
  unsigned int v16; // ecx
  RBX::Time *v17; // rdi
  __int64 v18; // rax
  unsigned int v19; // ecx
  __int64 v20; // rbx
  int v21; // r14d
  bool v22; // si
  unsigned __int64 TimeUS; // rax
  RakNet::BitStream *v25; // rdi
  RakNet::BitStream *v26; // rdi
  RakNet::BitStream *v27; // rdi
  RakNet::BitStream *v28; // rdi
  unsigned __int8 v29[8]; // [rsp+38h] [rbp-1B8h] BYREF
  RakNet::RakPeer *v30; // [rsp+40h] [rbp-1B0h]
  RakNet::SystemAddress *v31; // [rsp+48h] [rbp-1A8h]
  unsigned __int8 v32[10]; // [rsp+50h] [rbp-1A0h] BYREF
  unsigned __int8 v33[3]; // [rsp+5Ah] [rbp-196h] BYREF
  unsigned __int8 v34; // [rsp+5Dh] [rbp-193h] BYREF
  unsigned __int8 v35[2]; // [rsp+5Eh] [rbp-192h] BYREF
  bool v36[16]; // [rsp+60h] [rbp-190h] BYREF
  __int128 v37; // [rsp+70h] [rbp-180h]
  _BYTE v38[12]; // [rsp+98h] [rbp-158h] BYREF
  int v39; // [rsp+A4h] [rbp-14Ch]
  __int64 v40; // [rsp+B0h] [rbp-140h]

  v30 = this; /*0x1039c0769*/
  *(_QWORD *)v29 = a3; /*0x1039c077e*/
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v38); /*0x1039c078c*/
  v36[0] = 16; /*0x1039c0798*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: (const unsigned __int8 *)v36, a3: 8u, a4: true); /*0x1039c07ac*/
  v35[0] = 4; /*0x1039c07b8*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: v35, a3: 8u, a4: true); /*0x1039c07cc*/
  v4 = *(_OWORD *)((char *)a2 + 4); /*0x1039c07d5*/
  v37 = *(_OWORD *)((char *)a2 + 20); /*0x1039c07de*/
  *(_OWORD *)v36 = v4; /*0x1039c07e5*/
  *(_DWORD *)v32 = ~*((_DWORD *)a2 + 2); /*0x1039c07f8*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: v32, a3: 0x20u, a4: true); /*0x1039c080b*/
  *(_WORD *)v33 = RakNet::SystemAddress::GetPortNetworkOrder(this: (RakNet::SystemAddress *)v36); /*0x1039c0823*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: v33, a3: 0x10u, a4: true); /*0x1039c0837*/
  v5 = *(_OWORD *)((char *)a2 + 4); /*0x1039c083c*/
  v37 = *(_OWORD *)((char *)a2 + 20); /*0x1039c0845*/
  *(_OWORD *)v36 = v5; /*0x1039c084c*/
  *(_WORD *)v35 = RakNet::RakPeer::GetIndexFromSystemAddress( /*0x1039c087b*/
                    a1: (__int64)v30,
                    a2: 1,
                    a3: v6,
                    a4: v7,
                    a5: v8,
                    a6: v9,
                    a7: v5,
                    a8: *((__int64 *)&v5 + 1),
                    a9: v37,
                    a10: *((__int64 *)&v37 + 1));
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c0bd7*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v25); /*0x1039c0be2*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c0bef*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c0897*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: v35, a3: 0x10u, a4: true); /*0x1039c08b1*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039c08cb*/
      this: (RakNet::BitStream *)v35,
      a2: (unsigned __int8 *)v36,
      a3: (unsigned __int8 *)2,
      a4: v10);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: (const unsigned __int8 *)v36, a3: 0x10u, a4: true); /*0x1039c08e8*/
  }
  v31 = (RakNet::RakPeer::RemoteSystemStruct *)((char *)a2 + 4); /*0x1039c08ed*/
  for ( i = 2172; i != 2492; i += 32 ) /*0x1039c08f4*/
  {
    v34 = 4; /*0x1039c0916*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: &v34, a3: 8u, a4: true); /*0x1039c0931*/
    v12 = *(_OWORD *)((char *)v30 + i - 4); /*0x1039c093d*/
    v37 = *(_OWORD *)((char *)v30 + i + 12); /*0x1039c0949*/
    *(_OWORD *)v36 = v12; /*0x1039c0950*/
    *(_DWORD *)v32 = ~*(_DWORD *)((char *)v30 + i); /*0x1039c095d*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: v32, a3: 0x20u, a4: true); /*0x1039c0973*/
    *(_WORD *)v33 = RakNet::SystemAddress::GetPortNetworkOrder(this: (RakNet::SystemAddress *)v36); /*0x1039c0980*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: v33, a3: 0x10u, a4: true); /*0x1039c0997*/
  }
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c0c07*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v26); /*0x1039c0c12*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c0c1f*/
  }
  v14 = v31; /*0x1039c09c2*/
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c09c9*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: v29, a3: 0x40u, a4: true); /*0x1039c09e3*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039c09fd*/
      this: (RakNet::BitStream *)v29,
      a2: (unsigned __int8 *)v36,
      a3: (unsigned __int8 *)8,
      a4: v13);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: (const unsigned __int8 *)v36, a3: 0x40u, a4: true); /*0x1039c0a1a*/
  }
  *(_QWORD *)v32 = RakNet::GetTime(this: nullptr, a2: v15); /*0x1039c0a26*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c0c37*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v27); /*0x1039c0c42*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c0c4f*/
    v14 = v31; /*0x1039c0c54*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c0a42*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: v32, a3: 0x40u, a4: true); /*0x1039c0a5c*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039c0a76*/
      this: (RakNet::BitStream *)v32,
      a2: (unsigned __int8 *)v36,
      a3: (unsigned __int8 *)8,
      a4: v16);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: (const unsigned __int8 *)v36, a3: 0x40u, a4: true); /*0x1039c0a93*/
  }
  v18 = RBX::Time::epochTimeNs(this: v17); /*0x1039c0a98*/
  v19 = -481036337; /*0x1039c0a9d*/
  *(_QWORD *)v32 = ((unsigned __int64)((unsigned __int128)(0x20C49BA5E353F7CFLL * (__int128)v18) >> 64) >> 63) /*0x1039c0ab8*/
                 + v18 / 1000;
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c0c6e*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v28); /*0x1039c0c79*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c0c86*/
    v14 = v31; /*0x1039c0c8b*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c0ad4*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: v32, a3: 0x40u, a4: true); /*0x1039c0aee*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039c0b08*/
      this: (RakNet::BitStream *)v32,
      a2: (unsigned __int8 *)v36,
      a3: (unsigned __int8 *)8,
      a4: v19);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v38, a2: (const unsigned __int8 *)v36, a3: 0x40u, a4: true); /*0x1039c0b25*/
  }
  v20 = v40; /*0x1039c0b2a*/
  v21 = v39; /*0x1039c0b31*/
  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v36, a2: v14); /*0x1039c0b45*/
  TimeUS = RakNet::GetTimeUS(this: nullptr, a2: v22); /*0x1039c0b4f*/
  RakNet::RakPeer::SendImmediate( /*0x1039c0b92*/
    a1: (__int64)v30,
    a2: v20,
    a3: v21,
    a4: 0,
    a5: 3u,
    a6: 0,
    a7: (__int64)v36,
    a8: 0,
    a9: 0,
    a10: TimeUS,
    a11: 0,
    a12: 0,
    a13: 0);
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v38); /*0x1039c0b9e*/
  return __stack_chk_guard; /*0x1039c0bb7*/
}

// Address: 0x1039c0cda | Name: __ZNK6RakNet7RakPeer37GetNumberOfRemoteInitiatedConnectionsEv
__int64 __fastcall RakNet::RakPeer::GetNumberOfRemoteInitiatedConnections(RakNet::RakPeer *this)
{
  unsigned __int64 v1; // rcx
  __int64 result; // rax
  __int64 v3; // rdx

  if ( *((_QWORD *)this + 92) != 0 && (*((_BYTE *)this + 160) & 1) == 0 && *((_DWORD *)this + 188) != 0 ) /*0x1039c0cf6*/
  {
    v1 = 0; /*0x1039c0cfc*/
    LOWORD(result) = 0; /*0x1039c0cfe*/
    do /*0x1039c0d3b*/
    {
      if ( (**(_BYTE **)(*((_QWORD *)this + 93) + 8 * v1) & 1) != 0 ) /*0x1039c0d10*/
      {
        v3 = *(_QWORD *)(*((_QWORD *)this + 93) + 8 * v1); /*0x1039c0d19*/
        if ( *(_DWORD *)(v3 + 5364) == 7 ) /*0x1039c0d24*/
          LOWORD(result) = (*(unsigned __int8 *)(v3 + 1) ^ 1) + result; /*0x1039c0d2d*/
      }
      ++v1; /*0x1039c0d2f*/
    }
    while ( v1 < *((unsigned int *)this + 188) ); /*0x1039c0d3b*/
  }
  else
  {
    LOWORD(result) = 0; /*0x1039c0d40*/
  }
  return (unsigned __int16)result; /*0x1039c0d45*/
}

// Address: 0x1039c0d46 | Name: __ZN6RakNet7RakPeer37AssignSystemAddressToRemoteSystemListENS_13SystemAddressENS0_18RemoteSystemStruct11ConnectModeENSt3__110shared_ptrINS_12RakNetSocketEEEPbS1_iNS_10RakNetGUIDEbyNS5_IN3RBX8Security13RakPeerCryptoEEENSA_10StringViewERKNSA_4Rupp21DeserializationResultE
__int64 __fastcall RakNet::RakPeer::AssignSystemAddressToRemoteSystemList(
        RakNet::RakPeer *this,
        int a2,
        __int64 a3,
        RakNet::ReliabilityLayer *a4,
        int a5,
        _BOOL4 a6,
        __int128 a7,
        __int128 a8,
        char a9,
        int a10,
        int a11,
        int a12,
        __int64 a13,
        __int16 a14,
        __int64 a15,
        __int64 a16,
        _OWORD *a17,
        __int64 a18,
        __int64 a19)
{
  __int64 v20; // r12
  unsigned __int64 v21; // r15
  __int64 v22; // r13
  unsigned __int64 v23; // r14
  __int64 v24; // r15
  __int64 v25; // r14
  unsigned __int64 v26; // rdx
  __int64 v27; // r13
  __int64 v28; // r12
  int v29; // eax
  __int64 v30; // rax
  _OWORD *v31; // rsi
  char v32; // al
  __int64 v33; // r13
  __int64 v34; // rax
  __int64 v35; // r12
  __int64 i; // rax
  __int64 j; // rcx
  __int64 v38; // rax
  __int64 v39; // rax
  _QWORD v41[6]; // [rsp+10h] [rbp-B0h] BYREF
  _QWORD v42[4]; // [rsp+40h] [rbp-80h] BYREF
  _QWORD v43[2]; // [rsp+68h] [rbp-58h] BYREF
  __int64 v44; // [rsp+78h] [rbp-48h]
  int v45; // [rsp+80h] [rbp-40h]
  _BOOL4 v46; // [rsp+84h] [rbp-3Ch]
  int v47; // [rsp+88h] [rbp-38h]
  unsigned int TimeMS; // [rsp+8Ch] [rbp-34h]
  RakNet::ReliabilityLayer *v49; // [rsp+90h] [rbp-30h]

  v46 = a6; /*0x1039c0d5a*/
  v47 = a5; /*0x1039c0d5e*/
  v49 = a4; /*0x1039c0d62*/
  v44 = a3; /*0x1039c0d66*/
  v45 = a2; /*0x1039c0d6a*/
  v20 = a19; /*0x1039c0d70*/
  *(_OWORD *)&v42[2] = a8; /*0x1039c0d7f*/
  *(_OWORD *)v42 = a7; /*0x1039c0d83*/
  if ( (*(_BYTE *)(a19 + 3) & 1) != 0 )
  {
    if ( (unsigned __int8)DFLog::Rupp >= 6u && (DFLog::Rupp & 0xFC00) != 0 )
    {
      v41[2] = *(unsigned __int16 *)(a19 + 70); /*0x1039c0dca*/
      v43[0] = 44; /*0x1039c0dce*/
      v43[1] = v41; /*0x1039c0dd6*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: DFLog::Rupp,
        a2: qword_10D7BB258,
        a3: 4,
        a4: (unsigned int)"[DFLog::Rupp] Assigning address from reverse endpoint: {} | {}",
        a5: 62,
        a6: 1,
        44,
        v41,
        a19 + 24);
    }
    RakNet::SystemAddress::SystemAddress( /*0x1039c0e16*/
      this: (RakNet::SystemAddress *)v41,
      a2: (const char *)(v20 + 24),
      a3: *(_WORD *)(v20 + 70));
    RakNet::SystemAddress::operator=(a1: v42, a2: v41); /*0x1039c0e22*/
  }
  TimeMS = RakNet::GetTimeMS(this); /*0x1039c0e2c*/
  if ( *((_BYTE *)this + 2680) == 1 ) /*0x1039c0e36*/
  {
    RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v41, a2: (const RakNet::SystemAddress *)v42); /*0x1039c0e4a*/
    if ( RakNet::RakPeer::IsLoopbackAddress(this, a2: (const RakNet::AddressOrGUID *)v41, a3: 0) == 0 /*0x1039c0e68*/
      && *((_WORD *)this + 85) != 0 )
    {
      v21 = TimeMS; /*0x1039c0e6a*/
      v22 = 0; /*0x1039c0e6e*/
      v23 = 0; /*0x1039c0e75*/
      while ( (*(_BYTE *)(*((_QWORD *)this + 92) + v22) & 1) == 0 /*0x1039c0ec3*/
           || (unsigned __int8)RakNet::SystemAddress::EqualsExcludingPort(
                                 this: (RakNet::SystemAddress *)(*((_QWORD *)this + 92) + v22 + 4),
                                 a2: (const RakNet::SystemAddress *)v42) == 0
           || v21 < *(_QWORD *)(*((_QWORD *)this + 92) + v22 + 5184)
           || v21 - *(_QWORD *)(*((_QWORD *)this + 92) + v22 + 5184) >= 0x64 )
      {
        ++v23; /*0x1039c0ec9*/
        v22 += 5368; /*0x1039c0ed3*/
        if ( v23 >= *((unsigned __int16 *)this + 85) ) /*0x1039c0edd*/
          goto LABEL_13; /*0x1039c0edd*/
      }
      *(_BYTE *)v49 = 1; /*0x1039c121b*/
      return 0; /*0x1039c121b*/
    }
  }
LABEL_13:
  RakNet::SystemAddress::CopyPort( /*0x1039c0edf*/
    this: (RakNet::SystemAddress *)&a9,
    a2: (const RakNet::SystemAddress *)(*(_QWORD *)v44 + 8LL));
  *(_BYTE *)v49 = 0; /*0x1039c0ef7*/
  if ( *((_WORD *)this + 85) == 0 ) /*0x1039c0f02*/
    return 0; /*0x1039c121e*/
  v24 = 4616; /*0x1039c0f08*/
  v25 = 0; /*0x1039c0f0e*/
  v26 = 0; /*0x1039c0f11*/
  while ( 1 ) /*0x1039c0f1a*/
  {
    v27 = 5368 * v26; /*0x1039c0f1a*/
    if ( (*(_BYTE *)(*((_QWORD *)this + 92) + 5368 * v26) & 1) == 0 ) /*0x1039c0f27*/
      break; /*0x1039c0f27*/
    ++v26; /*0x1039c0f29*/
    v24 += 5368; /*0x1039c0f33*/
    if ( v26 >= *((unsigned __int16 *)this + 85) ) /*0x1039c0f3d*/
      return v25; /*0x1039c0f3d*/
  }
  v28 = *((_QWORD *)this + 92); /*0x1039c0f44*/
  v25 = v28 + v27; /*0x1039c0f4b*/
  RakNet::RakPeer::ReferenceRemoteSystem(this, a2: (const RakNet::SystemAddress *)v42, a3: v26); /*0x1039c0f56*/
  v29 = *((_DWORD *)this + 502); /*0x1039c0f5b*/
  *(_DWORD *)(v28 + v27 + 5216) = v29; /*0x1039c0f61*/
  *(_QWORD *)(v28 + v27 + 5200) = a13; /*0x1039c0f70*/
  *(_WORD *)(v28 + v27 + 5208) = a14; /*0x1039c0f7c*/
  *(_BYTE *)(v28 + v27) = 1; /*0x1039c0f87*/
  if ( v29 < v47 ) /*0x1039c0f90*/
    *(_DWORD *)(v25 + 5216) = v47; /*0x1039c0f92*/
  v30 = a15; /*0x1039c0f99*/
  *(_QWORD *)(v25 + 5256) = a15; /*0x1039c0f9d*/
  *(_QWORD *)(v25 + 4504) = v30; /*0x1039c0fa4*/
  if ( (v30 & 0x80u) == 0LL && (RakNet::RakPeer *)(v25 + 4512) != (RakNet::RakPeer *)((char *)this + 3680) ) /*0x1039c0fc0*/
    std::vector<int>::__assign_with_size[abi:ne200100]<int *,int *>( /*0x1039c0fda*/
      a1: v25 + 4512,
      a2: *((_QWORD *)this + 460),
      a3: *((_QWORD *)this + 461),
      a4: (__int64)(*((_QWORD *)this + 461) - *((_QWORD *)this + 460)) >> 2);
  v49 = (RakNet::ReliabilityLayer *)(v25 + 392); /*0x1039c0fe6*/
  if ( (*(unsigned __int8 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 800LL))(a1: this) != 0 ) /*0x1039c0ff8*/
  {
    if ( a18 == 16 ) /*0x1039c1009*/
    {
      v31 = a17; /*0x1039c100b*/
      if ( DFFlag::DebugRuppTokenLogService != 0 ) /*0x1039c1010*/
        *(_OWORD *)(v25 + 5296) = *a17; /*0x1039c1015*/
      *(_DWORD *)(v25 + 5272) = RakNet::RakPeer::getEarlyTokenOptions(a1: this, a2: v31, a3: 16); /*0x1039c102a*/
      v32 = 1; /*0x1039c1031*/
    }
    else
    {
      if ( DFFlag::DebugRuppTokenLogService != 0 ) /*0x1039c1037*/
        *(_OWORD *)(v25 + 5296) = 0; /*0x1039c103c*/
      *(_BYTE *)(v25 + 5272) = 0; /*0x1039c1044*/
      v32 = 0; /*0x1039c104c*/
    }
    *(_BYTE *)(v25 + 5276) = v32; /*0x1039c104e*/
  }
  std::shared_ptr<RBX::Security::RakPeerCrypto>::operator=[abi:ne200100](a1: v49, a2: a16); /*0x1039c105d*/
  RakNet::ReliabilityLayer::Reset(this: v49, a2: true, a3: *(_DWORD *)(v25 + 5216), a4: v46); /*0x1039c1076*/
  RakNet::ReliabilityLayer::SetSplitMessageProgressInterval(this: v49, a2: *((_DWORD *)this + 536)); /*0x1039c1085*/
  RakNet::ReliabilityLayer::SetUnreliableTimeout(this: v49, a2: *((_DWORD *)this + 537)); /*0x1039c1094*/
  RakNet::ReliabilityLayer::SetTimeoutTime(this: v49, a2: *((_DWORD *)this + 521)); /*0x1039c10a3*/
  RakNet::ReliabilityLayer::SetMaxRxPayloadSizePtr(this: v49, a2: *((FInt::Value **)this + 426)); /*0x1039c10b3*/
  v33 = *((_QWORD *)this + 92) + v27; /*0x1039c10b8*/
  v34 = *((_QWORD *)this + 93); /*0x1039c10bf*/
  *(_QWORD *)(v34 + 8LL * (unsigned int)_InterlockedExchangeAdd((volatile signed __int32 *)this + 188, 1u)) = v33; /*0x1039c10d3*/
  std::shared_ptr<RakNet::RakNetSocket>::operator=[abi:ne200100](a1: v25 + 5232, a2: v44); /*0x1039c10e2*/
  v35 = v24 + v28; /*0x1039c10e7*/
  for ( i = 0; i != 4; ++i ) /*0x1039c10ea*/
  {
    for ( j = 0; j != 80; j += 16 ) /*0x1039c10ec*/
    {
      *(_WORD *)(v35 + j - 8) = -1; /*0x1039c10ee*/
      *(_QWORD *)(v35 + j) = 0; /*0x1039c10f6*/
    }
    *(_QWORD *)(v25 + 8 * i + 4928) = 0; /*0x1039c1108*/
    v35 += 80; /*0x1039c1117*/
  }
  *(_DWORD *)(v25 + 5364) = v45; /*0x1039c1124*/
  *(_WORD *)(v25 + 2) = -1; /*0x1039c112f*/
  *(_QWORD *)(v25 + 5088) = 0; /*0x1039c1134*/
  *(_BYTE *)(v25 + 1) = 0; /*0x1039c113f*/
  v38 = TimeMS; /*0x1039c1144*/
  *(_QWORD *)(v25 + 5184) = TimeMS; /*0x1039c1147*/
  *(_QWORD *)(v25 + 5176) = v38; /*0x1039c114e*/
  if ( (a15 & 0x80u) == 0LL ) /*0x1039c115b*/
    *(_QWORD *)(v25 + 5192) = v38; /*0x1039c115d*/
  *(_QWORD *)(v25 + 5096) = v38; /*0x1039c1164*/
  *(_QWORD *)(v25 + 5112) = v38; /*0x1039c116b*/
  *(_QWORD *)(v25 + 5104) = v38; /*0x1039c1172*/
  *(_QWORD *)(v25 + 5120) = v38; /*0x1039c1179*/
  *(_QWORD *)(v25 + 5128) = v38; /*0x1039c1180*/
  *(_QWORD *)(v25 + 5136) = v38; /*0x1039c1187*/
  *(_QWORD *)(v25 + 5144) = v38; /*0x1039c118e*/
  *(_QWORD *)(v25 + 5152) = v38; /*0x1039c1195*/
  *(_QWORD *)(v25 + 5168) = v38; /*0x1039c119c*/
  *(_OWORD *)(v25 + 5320) = 0; /*0x1039c11ad*/
  std::shared_ptr<RBX::Rupp::Rupp>::reset[abi:ne200100](a1: v25 + 5280); /*0x1039c11b5*/
  *(_BYTE *)(v25 + 5360) = 0; /*0x1039c11ba*/
  if ( DFFlag::CLI56775 == 1 ) /*0x1039c11c9*/
  {
    RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2784)); /*0x1039c11d5*/
    v41[0] = v42; /*0x1039c11ec*/
    v39 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>::__emplace_unique_key_args<RakNet::SystemAddress,std::piecewise_construct_t const&,std::tuple<RakNet::SystemAddress const&>,std::tuple<>>( /*0x1039c11fd*/
            a1: (char *)this + 2872,
            a2: v42,
            a3: std::piecewise_construct,
            a4: v41,
            a5: v43);
    *(_DWORD *)(v39 + 48) = 0; /*0x1039c1202*/
    *(_BYTE *)(v39 + 52) = 0; /*0x1039c1209*/
    RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 2784)); /*0x1039c1210*/
  }
  return v25; /*0x1039c1224*/
}

// Address: 0x1039c1236 | Name: __ZN6RakNet7RakPeer21ReferenceRemoteSystemERKNS_13SystemAddressEj
__int64 __fastcall RakNet::RakPeer::ReferenceRemoteSystem(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *a2,
        unsigned int a3)
{
  __int64 v6; // rax
  __int64 v7; // r12
  __int128 v8; // xmm0
  unsigned int RemoteSystemIndex; // eax
  __int64 v10; // rcx
  __int64 v11; // rsi
  const RakNet::SystemAddress *v12; // rsi
  unsigned __int64 v13; // r12
  unsigned __int64 v14; // r12
  __int64 *v15; // r15
  __int64 result; // rax
  __int64 v17; // rcx
  __int64 v18; // rdx
  __int64 v19; // r14
  _OWORD v20[4]; // [rsp+0h] [rbp-40h] BYREF

  v6 = *((_QWORD *)this + 92); /*0x1039c124d*/
  v7 = 5368LL * a3; /*0x1039c1256*/
  v8 = *(_OWORD *)(v6 + v7 + 4); /*0x1039c125d*/
  v20[1] = *(_OWORD *)(v6 + v7 + 20); /*0x1039c126d*/
  v20[0] = v8; /*0x1039c1271*/
  if ( (unsigned __int8)RakNet::SystemAddress::operator!=(a1: v20, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 ) /*0x1039c1282*/
  {
    RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, a2: (const RakNet::SystemAddress *)v20); /*0x1039c128b*/
    v10 = *((_QWORD *)this + 92); /*0x1039c1290*/
    v11 = 0; /*0x1039c12a3*/
    if ( RemoteSystemIndex != -1 ) /*0x1039c12a8*/
      v11 = v10 + 5368LL * RemoteSystemIndex; /*0x1039c12a8*/
    if ( v11 == v7 + v10 ) /*0x1039c12b2*/
      RakNet::RakPeer::DereferenceRemoteSystem(this, a2: (const RakNet::SystemAddress *)v20); /*0x1039c12bb*/
  }
  RakNet::RakPeer::DereferenceRemoteSystem(this, a2); /*0x1039c12c6*/
  RakNet::SystemAddress::operator=(a1: *((_QWORD *)this + 92) + v7 + 4, a2); /*0x1039c12dd*/
  v13 = 8; /*0x1039c12f3*/
  if ( *((_WORD *)this + 85) != 0 ) /*0x1039c12f9*/
    v13 = 8 * (unsigned int)*((unsigned __int16 *)this + 85); /*0x1039c12f9*/
  v14 = RakNet::SystemAddress::ToInteger(this: a2, a2: v12) % v13; /*0x1039c130a*/
  v15 = (__int64 *)((char *)this + 792); /*0x1039c130d*/
  result = DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Allocate( /*0x1039c1320*/
             a1: (__int64 *)this + 99,
             a2: (unsigned __int64)"",
             a3: 0);
  v17 = *((_QWORD *)this + 98); /*0x1039c1325*/
  v18 = *(_QWORD *)(v17 + 8LL * (unsigned int)v14); /*0x1039c132f*/
  if ( v18 != 0 ) /*0x1039c1336*/
  {
    do /*0x1039c1342*/
    {
      v19 = v18; /*0x1039c1338*/
      v18 = *(_QWORD *)(v18 + 8); /*0x1039c133b*/
    }
    while ( v18 != 0 ); /*0x1039c1342*/
    result = DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Allocate(a1: v15, a2: (unsigned __int64)"", a3: 0); /*0x1039c1350*/
    *(_QWORD *)(result + 8) = 0; /*0x1039c1355*/
    *(_DWORD *)result = a3; /*0x1039c135d*/
    *(_QWORD *)(v19 + 8) = result; /*0x1039c135f*/
  }
  else
  {
    *(_QWORD *)(result + 8) = 0; /*0x1039c1365*/
    *(_DWORD *)result = a3; /*0x1039c136d*/
    *(_QWORD *)(v17 + 8 * v14) = result; /*0x1039c136f*/
  }
  return result; /*0x1039c1373*/
}

// Address: 0x1039c1380 | Name: __ZN6RakNet7RakPeer20getEarlyTokenOptionsEN3RBX10StringViewE
__int64 __fastcall RakNet::RakPeer::getEarlyTokenOptions(__int64 a1, unsigned __int8 *a2, __int64 a3)
{
  __int64 result; // rax
  __int64 v6; // r15
  __int16 Port; // ax
  __int64 v8; // r8
  __int64 v9; // r9
  const unsigned __int8 *v10; // rsi
  unsigned __int8 v11; // r15
  unsigned int v12; // r14d
  unsigned __int8 isAltToken; // al
  unsigned int v14; // [rsp+40h] [rbp-28h] BYREF
  _DWORD v15[9]; // [rsp+44h] [rbp-24h] BYREF

  if ( *(_QWORD *)(a1 + 3312) == 0 ) /*0x1039c1388*/
    return 0; /*0x1039c1451*/
  v15[0] = 0; /*0x1039c139b*/
  result = 0; /*0x1039c13a2*/
  if ( a3 == 16 ) /*0x1039c13a8*/
  {
    v6 = a1 + 36; /*0x1039c13b4*/
    Port = RakNet::SystemAddress::GetPort(this: (RakNet::SystemAddress *)(a1 + 100)); /*0x1039c13bc*/
    if ( DFFlag::RuppTokenAlgoTelemetry == 1 ) /*0x1039c13cb*/
    {
      v14 = 0; /*0x1039c13d5*/
      v11 = (*(__int64 (__fastcall **)(_QWORD, unsigned __int8 *, _DWORD *, unsigned int *, __int64, __int64, __int64, __int16, _QWORD, _WORD, __int64, __int16, _QWORD, _WORD))(**(_QWORD **)(a1 + 3312) + 24LL))( /*0x1039c1416*/
              a1: *(_QWORD *)(a1 + 3312),
              a2,
              a3: v15,
              a4: &v14,
              a5: v8,
              a6: v9,
              a7: v6,
              a8: Port,
              a9: 0,
              a10: 0,
              a11: v6,
              a12: Port,
              a13: 0,
              a14: 0);
      if ( v11 == 0 ) /*0x1039c141b*/
        v15[0] = RBX::Rupp::RuppTokenProcessor::debugGetOptions( /*0x1039c142c*/
                   this: *(RBX::Rupp::RuppTokenProcessor **)(a1 + 3312),
                   a2);
      v12 = v14; /*0x1039c142f*/
      isAltToken = RBX::Rupp::RuppTokenProcessor::isAltToken(this: (RBX::Rupp::RuppTokenProcessor *)a2, a2: v10); /*0x1039c1436*/
      RBX::Rupp::reportRuppTokenAlgo(a1: 0, a2: v12, a3: isAltToken, a4: v11, a5: 0); /*0x1039c144a*/
    }
    else if ( (*(unsigned __int8 (__fastcall **)(_QWORD, unsigned __int8 *, _DWORD *, char *, __int64, __int64, __int64, __int16, _QWORD, _WORD, __int64, __int16, _QWORD, _WORD))(**(_QWORD **)(a1 + 3312) + 16LL))( /*0x1039c1491*/
                a1: *(_QWORD *)(a1 + 3312),
                a2,
                a3: v15,
                a4: &DFFlag::RuppTokenAlgoTelemetry,
                a5: v8,
                a6: v9,
                a7: v6,
                a8: Port,
                a9: 0,
                a10: 0,
                a11: v6,
                a12: Port,
                a13: 0,
                a14: 0) == 0 )
    {
      v15[0] = RBX::Rupp::RuppTokenProcessor::debugGetOptions(this: *(RBX::Rupp::RuppTokenProcessor **)(a1 + 3312), a2); /*0x1039c14a2*/
    }
    return v15[0]; /*0x1039c14a5*/
  }
  return result; /*0x1039c1453*/
}

// Address: 0x1039c1506 | Name: __ZN6RakNet7RakPeer21AddToActiveSystemListEj
__int64 __fastcall RakNet::RakPeer::AddToActiveSystemList(RakNet::RakPeer *this, unsigned int a2)
{
  __int64 result; // rax
  __int64 v3; // rcx

  result = *((_QWORD *)this + 92) + 5368LL * a2; /*0x1039c1513*/
  v3 = *((_QWORD *)this + 93); /*0x1039c151a*/
  *(_QWORD *)(v3 + 8LL * (unsigned int)_InterlockedExchangeAdd((volatile signed __int32 *)this + 188, 1u)) = result; /*0x1039c152e*/
  return result; /*0x1039c1532*/
}

// Address: 0x1039c157a | Name: __ZNK6RakNet7RakPeer24GetBestClockDifferentialENS_13SystemAddressE
__int64 __fastcall RakNet::RakPeer::GetBestClockDifferential(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int128 a7,
        __int128 a8)
{
  unsigned int RemoteSystemIndex; // eax
  __int64 v10; // r14
  __int64 v11; // r15
  RakNet::SimpleMutex *v12; // rbx
  __int64 v13; // rax
  int v14; // edx
  __int64 v15; // rcx
  __int64 v16; // r14
  int v17; // esi
  _OWORD v19[4]; // [rsp+0h] [rbp-40h] BYREF

  v19[1] = a8; /*0x1039c1596*/
  v19[0] = a7; /*0x1039c159a*/
  if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: v19, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 ) /*0x1039c15ab*/
    return 0; /*0x1039c15ab*/
  RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex( /*0x1039c15b8*/
                        this: (RakNet::RakPeer *)a1,
                        a2: (const RakNet::SystemAddress *)v19);
  if ( RemoteSystemIndex == -1 ) /*0x1039c15c0*/
    return 0; /*0x1039c15c0*/
  v10 = 5368LL * RemoteSystemIndex; /*0x1039c15cb*/
  if ( (*(_BYTE *)(a1[92] + v10) & 1) == 0 ) /*0x1039c15d8*/
    return 0; /*0x1039c15d8*/
  v11 = a1[92]; /*0x1039c15da*/
  if ( v11 == 0 ) /*0x1039c15e4*/
    return 0; /*0x1039c1634*/
  v12 = (RakNet::SimpleMutex *)(a1 + 415); /*0x1039c15e6*/
  RakNet::SimpleMutex::Lock(this: v12); /*0x1039c15f0*/
  v13 = v10 + v11 + 4616; /*0x1039c15f9*/
  v14 = 0xFFFF; /*0x1039c15ff*/
  v15 = 0; /*0x1039c1604*/
  v16 = 0; /*0x1039c1606*/
  do /*0x1039c1628*/
  {
    v17 = *(unsigned __int16 *)(v13 + v15 - 8); /*0x1039c1609*/
    if ( v17 == 0xFFFF ) /*0x1039c1614*/
      break; /*0x1039c1614*/
    if ( v14 > v17 ) /*0x1039c1618*/
    {
      v16 = *(_QWORD *)(v13 + v15); /*0x1039c161a*/
      v14 = *(unsigned __int16 *)(v13 + v15 - 8); /*0x1039c161e*/
    }
    v15 += 16; /*0x1039c1620*/
  }
  while ( v15 != 80 ); /*0x1039c1628*/
  RakNet::SimpleMutex::Unlock(this: v12); /*0x1039c162d*/
  return v16; /*0x1039c163a*/
}

// Address: 0x1039c1646 | Name: __ZN6RakNet7RakPeer20SetArtificialLatencyEyy
__int64 __fastcall RakNet::RakPeer::SetArtificialLatency(RakNet::RakPeer *this, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  _QWORD v7[10]; // [rsp+10h] [rbp-50h] BYREF

  result = (unsigned int)DFLog::NetworkIxp >> 8; /*0x1039c1665*/
  LOBYTE(result) = (unsigned __int8)DFLog::NetworkIxp < 6u || BYTE1(DFLog::NetworkIxp) < 3u; /*0x1039c1674*/
  if ( (_BYTE)result == 0 )
  {
    v7[2] = a3; /*0x1039c1686*/
    v7[5] = 68; /*0x1039c168a*/
    v7[6] = v7; /*0x1039c1692*/
    result = FLog::detail::FastLogSafeFormattedInternal(
               a1: DFLog::NetworkIxp,
               a2: qword_10D7BB110,
               a3: 3,
               a4: (unsigned int)"[DFLog::NetworkIxp] Setting latency from Ixp tx: {} rx: {}",
               a5: 58,
               a6: 0,
               68,
               v7,
               a2);
  }
  *((_QWORD *)this + 216) = a2; /*0x1039c16b8*/
  *((_QWORD *)this + 215) = a3; /*0x1039c16bf*/
  return result; /*0x1039c16c6*/
}

// Address: 0x1039c16d2 | Name: __ZNK6RakNet7RakPeer22GetArtificialLatencyTxEv
__int64 __fastcall RakNet::RakPeer::GetArtificialLatencyTx(RakNet::RakPeer *this)
{
  return *((_QWORD *)this + 216); /*0x1039c16dd*/
}

// Address: 0x1039c16e0 | Name: __ZNK6RakNet7RakPeer22GetArtificialLatencyRxEv
__int64 __fastcall RakNet::RakPeer::GetArtificialLatencyRx(RakNet::RakPeer *this)
{
  return *((_QWORD *)this + 215); /*0x1039c16eb*/
}

// Address: 0x1039c16ee | Name: __ZN6RakNet7RakPeer21AllocateQueueTxPacketEv
_OWORD *__fastcall RakNet::RakPeer::AllocateQueueTxPacket(RakNet::RakPeer *this)
{
  return DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Allocate( /*0x1039c1702*/
           a1: (__int64 *)this + 192,
           a2: (unsigned __int64)"",
           a3: 0);
}

// Address: 0x1039c1786 | Name: __ZN6RakNet7RakPeer21QueueTxPacketForDelayEPNS_19DelayTransmitStructE
__int64 __fastcall RakNet::RakPeer::QueueTxPacketForDelay(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  if ( (*(_BYTE *)(a1 + 163) & 1) == 0 ) /*0x1039c1792*/
    return DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Push(a1: a1 + 1536, a2); /*0x1039c17ce*/
  result = (unsigned int)DFLog::NetworkTrace >> 8; /*0x1039c179d*/
  LOBYTE(result) = (unsigned __int8)DFLog::NetworkTrace < 6u || BYTE1(DFLog::NetworkTrace) < 3u; /*0x1039c17ac*/
  if ( (_BYTE)result == 0 ) /*0x1039c17ae*/
    return FLog::FastLog( /*0x1039c17c1*/
             a1: DFLog::NetworkTrace,
             a2: qword_10D7BB068,
             a3: "[DFLog::NetworkTrace] Did not add packet to tx delay queue, already shutting down",
             0);
  return result; /*0x1039c17c0*/
}

// Address: 0x1039c1822 | Name: __ZN6RakNet7RakPeer21trackSocketSendResultEi
void __fastcall RakNet::RakPeer::trackSocketSendResult(RakNet::RakPeer *this, int a2)
{
  if ( a2 != -3 ) /*0x1039c1829*/
  {
    ++*((_QWORD *)this + 454); /*0x1039c182b*/
    if ( a2 != 0 ) /*0x1039c1834*/
    {
      if ( a2 == -4 ) /*0x1039c1839*/
        ++*((_QWORD *)this + 455); /*0x1039c183b*/
      else
        ++*((_QWORD *)this + 456); /*0x1039c1844*/
    }
  }
}

// Address: 0x1039c184e | Name: __ZNK6RakNet7RakPeer34GetBestClockDifferentialMSInternalEPKNS0_18RemoteSystemStructE
__int64 __fastcall RakNet::RakPeer::GetBestClockDifferentialMSInternal(
        RakNet::RakPeer *this,
        const RakNet::RakPeer::RemoteSystemStruct *a2)
{
  int v2; // edx
  __int64 v3; // rcx
  __int64 result; // rax
  int v5; // edi

  v2 = 0xFFFF; /*0x1039c1852*/
  v3 = 0; /*0x1039c1857*/
  result = 0; /*0x1039c1859*/
  do /*0x1039c1881*/
  {
    v5 = *(unsigned __int16 *)((char *)a2 + v3 + 4608); /*0x1039c185b*/
    if ( v5 == 0xFFFF ) /*0x1039c1869*/
      break; /*0x1039c1869*/
    if ( v2 > v5 ) /*0x1039c186d*/
    {
      result = *(_QWORD *)((char *)a2 + v3 + 4616); /*0x1039c186f*/
      v2 = *(unsigned __int16 *)((char *)a2 + v3 + 4608); /*0x1039c1877*/
    }
    v3 += 16; /*0x1039c1879*/
  }
  while ( v3 != 80 ); /*0x1039c1881*/
  return result; /*0x1039c1883*/
}

// Address: 0x1039c1886 | Name: __ZNK6RakNet7RakPeer27RemoteSystemLookupHashIndexERKNS_13SystemAddressE
unsigned __int64 __fastcall RakNet::RakPeer::RemoteSystemLookupHashIndex(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *a2)
{
  unsigned __int64 v2; // rbx

  v2 = 8; /*0x1039c189c*/
  if ( *((_WORD *)this + 85) != 0 ) /*0x1039c18a1*/
    v2 = 8 * (unsigned int)*((unsigned __int16 *)this + 85); /*0x1039c18a1*/
  return RakNet::SystemAddress::ToInteger(this: a2, a2) % v2; /*0x1039c18b9*/
}

// Address: 0x1039c18bc | Name: __ZNK6RakNet7RakPeer15GetRemoteSystemERKNS_13SystemAddressE
__int64 __fastcall RakNet::RakPeer::GetRemoteSystem(RakNet::RakPeer *this, const RakNet::SystemAddress *a2)
{
  unsigned int RemoteSystemIndex; // eax

  RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, a2); /*0x1039c18c5*/
  if ( RemoteSystemIndex == -1 ) /*0x1039c18cd*/
    return 0; /*0x1039c18e1*/
  else
    return *((_QWORD *)this + 92) + 5368LL * RemoteSystemIndex; /*0x1039c18d8*/
}

// Address: 0x1039c18ea | Name: __ZN6RakNet7RakPeer23DereferenceRemoteSystemERKNS_13SystemAddressE
unsigned __int64 __fastcall RakNet::RakPeer::DereferenceRemoteSystem(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *a2)
{
  unsigned __int64 v4; // r14
  unsigned __int64 v5; // r14
  unsigned __int64 result; // rax
  _QWORD *v7; // r15
  _QWORD *v8; // rcx
  _QWORD *v9; // r13
  _QWORD *v10; // r14

  v4 = 8; /*0x1039c190e*/
  if ( *((_WORD *)this + 85) != 0 ) /*0x1039c1914*/
    v4 = 8 * (unsigned int)*((unsigned __int16 *)this + 85); /*0x1039c1914*/
  v5 = RakNet::SystemAddress::ToInteger(this: a2, a2) % v4; /*0x1039c1925*/
  result = *((_QWORD *)this + 98); /*0x1039c1928*/
  v7 = *(_QWORD **)(result + 8LL * (unsigned int)v5); /*0x1039c1932*/
  if ( v7 != nullptr ) /*0x1039c1939*/
  {
    result = RakNet::SystemAddress::operator==(a1: *((_QWORD *)this + 92) + 5368LL * *(unsigned int *)v7 + 4, a2); /*0x1039c1957*/
    if ( (_BYTE)result != 0 ) /*0x1039c195e*/
    {
      v8 = nullptr; /*0x1039c1960*/
LABEL_9:
      if ( v8 != nullptr ) /*0x1039c19a2*/
        v10 = v8 + 1; /*0x1039c19a8*/
      else
        v10 = (_QWORD *)(*((_QWORD *)this + 98) + 8 * v5); /*0x1039c19c0*/
      *v10 = v7[1]; /*0x1039c19c7*/
      return DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Release(a1: (__int64)this + 792, a2: v7); /*0x1039c19ee*/
    }
    else
    {
      v9 = v7; /*0x1039c1964*/
      while ( 1 ) /*0x1039c1967*/
      {
        v7 = (_QWORD *)v9[1]; /*0x1039c1967*/
        if ( v7 == nullptr ) /*0x1039c196e*/
          break; /*0x1039c196e*/
        result = RakNet::SystemAddress::operator==(a1: *((_QWORD *)this + 92) + 5368LL * *(unsigned int *)v7 + 4, a2); /*0x1039c198c*/
        v8 = v9; /*0x1039c1991*/
        v9 = v7; /*0x1039c1994*/
        if ( (_BYTE)result != 0 ) /*0x1039c1999*/
          goto LABEL_9; /*0x1039c1999*/
      }
    }
  }
  return result; /*0x1039c19b1*/
}

// Address: 0x1039c1c94 | Name: __ZN6RakNet7RakPeer26RemoveFromActiveSystemListERKNS_13SystemAddressE
unsigned __int64 __fastcall RakNet::RakPeer::RemoveFromActiveSystemList(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *a2)
{
  unsigned __int64 result; // rax
  unsigned __int64 v5; // r15

  result = *((unsigned int *)this + 188); /*0x1039c1c94*/
  if ( (_DWORD)result != 0 ) /*0x1039c1c9c*/
  {
    v5 = 0; /*0x1039c1cae*/
    while ( (unsigned __int8)RakNet::SystemAddress::operator==( /*0x1039c1cca*/
                               a1: *(_QWORD *)(*((_QWORD *)this + 93) + 8 * v5) + 4LL,
                               a2) == 0 )
    {
      ++v5; /*0x1039c1ccc*/
      result = *((unsigned int *)this + 188); /*0x1039c1ccf*/
      if ( v5 >= result ) /*0x1039c1cd8*/
        return result; /*0x1039c1cd8*/
    }
    result = *(_QWORD *)(*((_QWORD *)this + 93) + 8LL * (unsigned int)(*((_DWORD *)this + 188) - 1)); /*0x1039c1ceb*/
    *(_QWORD *)(*((_QWORD *)this + 93) + 8 * v5) = result; /*0x1039c1cf6*/
    _InterlockedDecrement((volatile signed __int32 *)this + 188); /*0x1039c1cfa*/
  }
  return result; /*0x1039c1d0b*/
}

// Address: 0x1039c1d0c | Name: __ZNK6RakNet7RakPeer24AllowIncomingConnectionsEv
bool __fastcall RakNet::RakPeer::AllowIncomingConnections(RakNet::RakPeer *this)
{
  unsigned __int16 NumberOfRemoteInitiatedConnections; // r14

  NumberOfRemoteInitiatedConnections = RakNet::RakPeer::GetNumberOfRemoteInitiatedConnections(this); /*0x1039c1d1b*/
  return NumberOfRemoteInitiatedConnections < (*(unsigned __int16 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 72LL))(a1: this); /*0x1039c1d2e*/
}

// Address: 0x1039c1d34 | Name: __ZN6RakNet7RakPeer9SendPingsENS_13SystemAddressE17PacketReliability
__int64 __fastcall RakNet::RakPeer::SendPings(
        RakNet::RakPeer *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        bool a7)
{
  RakNet::RakPeer::PingInternal(this, a2: a7); /*0x1039c1d59*/
  RakNet::RakPeer::PingInternal(this, a2: a7); /*0x1039c1d7b*/
  RakNet::RakPeer::PingInternal(this, a2: a7); /*0x1039c1d9d*/
  RakNet::RakPeer::PingInternal(this, a2: a7); /*0x1039c1dbf*/
  return RakNet::RakPeer::PingInternal(this, a2: a7); /*0x1039c1dd0*/
}

// Address: 0x1039c1dde | Name: __ZN6RakNet7RakPeer12PingInternalENS_13SystemAddressE17PacketReliability14PacketPriorityb
__int64 __fastcall RakNet::RakPeer::PingInternal(
        RakNet::RakPeer *this,
        unsigned int a2,
        int a3,
        char a4,
        __int64 a5,
        __int64 a6,
        __int128 a7,
        __int128 a8)
{
  unsigned int RemoteSystemIndex; // eax
  __int64 v13; // rax
  __int64 v14; // rcx
  unsigned int v15; // esi
  unsigned int v16; // ecx
  bool v17; // si
  RakNet *v18; // rdi
  __int64 TimeMS; // rcx
  RBX *v20; // rdi
  __int64 v21; // r13
  RBX::Network::NetworkTracer *v22; // rdi
  __int64 v23; // r13
  bool v24; // si
  unsigned __int64 TimeUS; // rax
  RBX::Network *v27; // rdi
  __int64 v28; // rdx
  __int64 v29; // rsi
  __int64 v30; // r13
  unsigned __int8 v31; // al
  unsigned __int8 v32; // al
  RakNet::BitStream *v33; // rdi
  RakNet::BitStream *v34; // rdi
  int v35; // [rsp+38h] [rbp-1A8h]
  __int64 v36; // [rsp+38h] [rbp-1A8h]
  unsigned __int8 v37[8]; // [rsp+40h] [rbp-1A0h] BYREF
  __int64 TracerObject; // [rsp+48h] [rbp-198h]
  unsigned __int8 v39[48]; // [rsp+50h] [rbp-190h] BYREF
  __int128 v40; // [rsp+80h] [rbp-160h] BYREF
  __int128 v41; // [rsp+90h] [rbp-150h]

  if ( (*(unsigned __int8 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 128LL))(a1: this) != 0 ) /*0x1039c1e16*/
  {
    v41 = a8; /*0x1039c1e32*/
    v40 = a7; /*0x1039c1e36*/
    if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: &v40, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) == 0 ) /*0x1039c1e47*/
    {
      RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, a2: (const RakNet::SystemAddress *)&v40); /*0x1039c1e57*/
      if ( RemoteSystemIndex != -1 ) /*0x1039c1e5f*/
      {
        v13 = 5368LL * RemoteSystemIndex; /*0x1039c1e6e*/
        if ( (*(_BYTE *)(*((_QWORD *)this + 92) + v13) & 1) != 0 ) /*0x1039c1e7b*/
        {
          v14 = *((_QWORD *)this + 92); /*0x1039c1e81*/
          if ( v14 != 0 ) /*0x1039c1e8b*/
          {
            TracerObject = v13 + v14; /*0x1039c1e94*/
            v15 = 9; /*0x1039c1e9b*/
            if ( a4 != 0 ) /*0x1039c1ea3*/
              v15 = *(_DWORD *)(TracerObject + 5216) - 40; /*0x1039c1eb2*/
            RakNet::BitStream::BitStream(this: (RakNet::BitStream *)&v40, a2: v15); /*0x1039c1ebc*/
            switch ( a3 ) /*0x1039c1edc*/
            {
              case 0: /*0x1039c1edc*/
                v39[0] = 0; /*0x1039c1ee5*/
                RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)&v40, a2: v39, a3: 8u, a4: true); /*0x1039c1ef9*/
                goto LABEL_13; /*0x1039c1efe*/
              case 1: /*0x1039c1edc*/
                v39[0] = 83; /*0x1039c1f4b*/
                RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)&v40, a2: v39, a3: 8u, a4: true); /*0x1039c1f5f*/
                goto LABEL_13; /*0x1039c1f5f*/
              case 2: /*0x1039c1edc*/
                v39[0] = 82; /*0x1039c1f07*/
                RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)&v40, a2: v39, a3: 8u, a4: true); /*0x1039c1f1b*/
                goto LABEL_13; /*0x1039c1f20*/
              case 3: /*0x1039c1edc*/
                v39[0] = 81; /*0x1039c1f29*/
                RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)&v40, a2: v39, a3: 8u, a4: true); /*0x1039c1f3d*/
LABEL_13:
                if ( a2 == 2 ) /*0x1039c1f67*/
                {
                  *(_QWORD *)v37 = 0; /*0x1039c1f69*/
                  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c2255*/
                    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
                  {
                    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v33); /*0x1039c2260*/
                    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c226d*/
                  }
                  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c1f89*/
                  {
LABEL_16:
                    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)&v40, a2: v37, a3: 0x40u, a4: true); /*0x1039c1f8b*/
                    goto LABEL_20; /*0x1039c1fa8*/
                  }
                }
                else
                {
                  *(_QWORD *)v37 = RakNet::GetTime(this: nullptr, a2: v17); /*0x1039c1fb4*/
                  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c2285*/
                    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
                  {
                    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v34); /*0x1039c2290*/
                    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c229d*/
                  }
                  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c1fd0*/
                    goto LABEL_16; /*0x1039c1fd0*/
                }
                RakNet::BitStream::ReverseBytes( /*0x1039c203b*/
                  this: (RakNet::BitStream *)v37,
                  a2: v39,
                  a3: (unsigned __int8 *)8,
                  a4: v16);
                RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)&v40, a2: v39, a3: 0x40u, a4: true); /*0x1039c2058*/
LABEL_20:
                if ( a4 != 0 ) /*0x1039c2060*/
                  RakNet::BitStream::PadWithZeroToByteLength( /*0x1039c2079*/
                    this: (RakNet::BitStream *)&v40,
                    a2: *(_DWORD *)(TracerObject + 5216) - 40);
                TimeMS = (unsigned int)RakNet::GetTimeMS(this: v18); /*0x1039c2083*/
                if ( a4 != 0 ) /*0x1039c2088*/
                {
                  *(_QWORD *)(TracerObject + 5104) = TimeMS; /*0x1039c2091*/
LABEL_28:
                  TracerObject = 0; /*0x1039c20ef*/
                  goto LABEL_29; /*0x1039c20ef*/
                }
                *(_QWORD *)(TracerObject + 5096) = TimeMS; /*0x1039c20a1*/
                if ( DFFlag::RakNetPingTrace != 1 ) /*0x1039c20af*/
                  goto LABEL_28; /*0x1039c20af*/
                v21 = TimeMS; /*0x1039c20b1*/
                if ( (unsigned int)RBX::globalRand(this: v20) % 0xF4240 >= DFInt::RakNetPingTracePointsEventThrottlePerMillion ) /*0x1039c20d4*/
                  goto LABEL_28; /*0x1039c20d4*/
                if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039c20e0*/
                  v22 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle /*0x1039c20e6*/
                                                        + 24);
                else
                  v22 = nullptr; /*0x1039c21a2*/
                TracerObject = RBX::Network::NetworkTracer::createTracerObject(this: v22); /*0x1039c21a9*/
                if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v27) != 0 ) /*0x1039c21be*/
                {
                  if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039c21c3*/
                    v30 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039c21c5*/
                  else
                    v30 = 0; /*0x1039c21dd*/
                  v31 = (*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64))(*(_QWORD *)this + 200LL))( /*0x1039c21e6*/
                          a1: this,
                          a2: v29,
                          a3: v28,
                          a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
                  RBX::Network::NetworkTracer::addCheckpointToTracer(a1: v30, a2: TracerObject, a3: v31, a4: 73); /*0x1039c21fe*/
                }
                else
                {
                  if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039c21ce*/
                    v36 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039c21d4*/
                  else
                    v36 = 0; /*0x1039c2208*/
                  v32 = (*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64))(*(_QWORD *)this + 200LL))( /*0x1039c2219*/
                          a1: this,
                          a2: v29,
                          a3: v28,
                          a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
                  RBX::Network::NetworkTracer::addCheckpointToTracer_deprecated( /*0x1039c2238*/
                    a1: v36,
                    a2: TracerObject,
                    a3: v32,
                    a4: 73,
                    a5: v21);
                }
LABEL_29:
                v23 = *((_QWORD *)&v41 + 1); /*0x1039c20fa*/
                v35 = HIDWORD(v40); /*0x1039c2107*/
                RakNet::AddressOrGUID::AddressOrGUID( /*0x1039c2117*/
                  this: (RakNet::AddressOrGUID *)v39,
                  a2: (const RakNet::SystemAddress *)&a7);
                TimeUS = RakNet::GetTimeUS(this: nullptr, a2: v24); /*0x1039c2121*/
                RakNet::RakPeer::SendImmediate( /*0x1039c216b*/
                  a1: (__int64)this,
                  a2: v23,
                  a3: v35,
                  a4: a3,
                  a5: a2,
                  a6: 0,
                  a7: (__int64)v39,
                  a8: 0,
                  a9: 0,
                  a10: TimeUS,
                  a11: 0,
                  a12: TracerObject,
                  a13: 0);
LABEL_30:
                RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&v40); /*0x1039c2170*/
                break; /*0x1039c2177*/
              default:
                goto LABEL_30;
            }
          }
        }
      }
    }
  }
  return __stack_chk_guard; /*0x1039c2190*/
}

// Address: 0x1039c22f8 | Name: __ZN6RakNet7RakPeer46FlushArtificialLatencyTransmitPacketsForSocketENSt3__110shared_ptrINS_12RakNetSocketEEE
__int64 __fastcall RakNet::RakPeer::FlushArtificialLatencyTransmitPacketsForSocket(_QWORD *a1, unsigned int **a2)
{
  __int64 v2; // rbx
  unsigned int **v3; // rax
  unsigned int **v4; // r14
  std::__shared_weak_count *v5; // rdi
  volatile signed __int64 *v6; // rax
  volatile signed __int64 *v7; // r15
  unsigned int *v8; // rax
  char v9; // r14
  int v10; // eax
  unsigned __int64 v11; // rax
  __m128i v12; // xmm0
  signed __int64 epi64; // rcx
  _QWORD v16[4]; // [rsp+20h] [rbp-70h] BYREF
  __m128i v17; // [rsp+40h] [rbp-50h] BYREF
  unsigned int **v18; // [rsp+58h] [rbp-38h] BYREF
  _QWORD *v19; // [rsp+60h] [rbp-30h]

  v17 = 0; /*0x1039c2315*/
  memset(v16, 0, sizeof(v16)); /*0x1039c2323*/
  v19 = a1; /*0x1039c2329*/
  v2 = (__int64)(a1 + 192); /*0x1039c232d*/
  while ( 1 ) /*0x1039c233b*/
  {
    v3 = (unsigned int **)DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Pop(a1: v2); /*0x1039c233b*/
    v4 = v3; /*0x1039c2340*/
    v18 = v3; /*0x1039c2343*/
    if ( v3 == nullptr ) /*0x1039c234a*/
      break; /*0x1039c234a*/
    v5 = (std::__shared_weak_count *)v3[1]; /*0x1039c2350*/
    if ( v5 != nullptr ) /*0x1039c2357*/
    {
      v6 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v5); /*0x1039c235d*/
      if ( v6 != nullptr ) /*0x1039c2369*/
      {
        v7 = v6; /*0x1039c236f*/
        v8 = *v4; /*0x1039c2372*/
        v9 = 1; /*0x1039c237c*/
        if ( v8 != nullptr && v8 == *a2 ) /*0x1039c238b*/
        {
          v10 = RakNet::SocketLayer::SendToAfterDelay(a1: *v8, a2: v18); /*0x1039c2393*/
          if ( v10 != -3 ) /*0x1039c239b*/
          {
            ++v19[454]; /*0x1039c23a1*/
            if ( v10 != 0 ) /*0x1039c23aa*/
            {
              if ( v10 == -4 ) /*0x1039c23af*/
                ++v19[455]; /*0x1039c23b5*/
              else
                ++v19[456]; /*0x1039c23c2*/
            }
          }
          v9 = 0; /*0x1039c23c9*/
          DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Deallocate(a1: v2, a2: v18); /*0x1039c23dc*/
        }
        if ( _InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039c23f1*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(a1: v7); /*0x1039c23f9*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v7); /*0x1039c23ff*/
        }
        if ( v9 == 0 ) /*0x1039c2407*/
          continue; /*0x1039c2407*/
      }
    }
    std::deque<RakNet::DelayTransmitStruct *>::push_back(a1: v16, a2: &v18); /*0x1039c2413*/
  }
  if ( v17.i64[1] != 0 ) /*0x1039c2422*/
  {
    v11 = v17.i64[0]; /*0x1039c2424*/
    do /*0x1039c249a*/
    {
      DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Push( /*0x1039c244a*/
        a1: v2,
        a2: *(_QWORD *)(*(_QWORD *)(v16[1] + 8 * (v11 >> 9)) + 8 * (v11 & 0x1FF)));
      v12 = _mm_add_epi64(_mm_load_si128(&v17), (__m128i)xmmword_1090631C0); /*0x1039c2454*/
      v17 = v12; /*0x1039c245c*/
      v11 = v12.i64[0]; /*0x1039c2461*/
      if ( v12.i64[0] >= 0x400uLL ) /*0x1039c246c*/
      {
        operator delete(a1: *(void **)v16[1]); /*0x1039c247e*/
        v16[1] += 8LL; /*0x1039c2483*/
        v11 = v17.i64[0] - 512; /*0x1039c248c*/
        v17.i64[0] -= 512; /*0x1039c248f*/
        epi64 = v17.i64[1]; /*0x1039c2493*/
      }
      else
      {
        epi64 = _mm_extract_epi64(v12, 1); /*0x1039c246e*/
      }
    }
    while ( epi64 != 0 ); /*0x1039c249a*/
  }
  return std::deque<RakNet::DelayTransmitStruct *>::~deque[abi:ne200100](a1: v16); /*0x1039c24a5*/
}

// Address: 0x1039c256c | Name: __ZN6RakNet7RakPeer13getRuppHeaderEPKNS0_18RemoteSystemStructE
RakNet::RakPeer *__fastcall RakNet::RakPeer::getRuppHeader(
        RakNet::RakPeer *this,
        const RakNet::RakPeer::RemoteSystemStruct *a2,
        __int64 a3)
{
  *(_OWORD *)this = 0; /*0x1039c2578*/
  if ( a3 != 0 ) /*0x1039c257e*/
    std::shared_ptr<RBX::Rupp::Rupp>::operator=[abi:ne200100](a1: this); /*0x1039c258d*/
  return this; /*0x1039c2599*/
}

// Address: 0x1039c259c | Name: __ZN6RakNet7RakPeer15OnConnectedPongEyyyPNS0_18RemoteSystemStructE14PacketPriority
__int64 __fastcall RakNet::RakPeer::OnConnectedPong(
        __int64 a1,
        _BOOL8 a2,
        __int64 a3,
        unsigned __int64 a4,
        __int64 a5,
        unsigned int a6)
{
  unsigned __int64 TimeUS; // rcx
  unsigned __int64 v11; // r13
  __int64 result; // rax
  RakNet::SimpleMutex *v13; // r15
  unsigned __int64 v14; // r15
  __int64 v15; // rcx
  __int64 v16; // r12
  __int64 v17; // r13
  unsigned __int16 v18; // cx
  __int64 v19; // rdi
  int v20; // edx
  __int64 v21; // rax
  __int64 v22; // rcx
  int v23; // r9d
  __int64 v24; // rcx
  unsigned __int64 v26; // [rsp+8h] [rbp-68h]
  _BOOL8 v27; // [rsp+10h] [rbp-60h]
  unsigned __int64 v28; // [rsp+18h] [rbp-58h]
  int v29; // [rsp+2Ch] [rbp-44h] BYREF
  unsigned int v30; // [rsp+30h] [rbp-40h]
  unsigned int v31; // [rsp+34h] [rbp-3Ch]
  unsigned int v32; // [rsp+38h] [rbp-38h]
  signed int v33; // [rsp+3Ch] [rbp-34h]
  unsigned __int64 v34; // [rsp+40h] [rbp-30h]

  v30 = a6; /*0x1039c25ad*/
  TimeUS = RakNet::GetTimeUS(this: nullptr, a2); /*0x1039c25c8*/
  v11 = TimeUS / 0x3E8; /*0x1039c25df*/
  result = a2 - 1; /*0x1039c25e3*/
  if ( a2 - 1 < TimeUS / 0x3E8 ) /*0x1039c25eb*/
  {
    v28 = a4; /*0x1039c25f1*/
    v26 = TimeUS; /*0x1039c25f5*/
    v27 = a2; /*0x1039c25fc*/
    v34 = v11 - a2; /*0x1039c2603*/
    v13 = (RakNet::SimpleMutex *)(a1 + 3320); /*0x1039c2607*/
    RakNet::SimpleMutex::Lock(this: (RakNet::SimpleMutex *)(a1 + 3320)); /*0x1039c2611*/
    if ( DFFlag::ReportPongTimeDistribution == 1 && FInt::TimeSinceLastPongBucketSizeInSec > 0 ) /*0x1039c262b*/
    {
      v31 = v11 - *(_DWORD *)(a1 + 32); /*0x1039c263c*/
      v32 = 1000 * FInt::TimeSinceLastPongBucketSizeInSec; /*0x1039c2645*/
      v33 = (unsigned int)RakNet::ReliabilityLayer::GetTimeoutTime(this: (RakNet::ReliabilityLayer *)(a5 + 392)) /*0x1039c2662*/
          / (1000
           * FInt::TimeSinceLastPongBucketSizeInSec);
      v14 = v33; /*0x1039c2665*/
      v15 = *(_QWORD *)(a1 + 8); /*0x1039c2668*/
      if ( (*(_QWORD *)(a1 + 16) - v15) >> 2 < (unsigned __int64)v33 ) /*0x1039c267a*/
      {
        do /*0x1039c26a5*/
        {
          v29 = 0; /*0x1039c2680*/
          std::vector<int>::push_back[abi:ne200100](a1: a1 + 8, a2: &v29); /*0x1039c268e*/
          v15 = *(_QWORD *)(a1 + 8); /*0x1039c2693*/
        }
        while ( (*(_QWORD *)(a1 + 16) - v15) >> 2 < v14 ); /*0x1039c26a5*/
      }
      if ( (int)(v31 / v32) < v33 ) /*0x1039c26b2*/
        ++*(_DWORD *)(v15 + 4LL * (int)(v31 / v32)); /*0x1039c26b6*/
      *(_DWORD *)(a1 + 32) = v11; /*0x1039c26b9*/
      v13 = (RakNet::SimpleMutex *)(a1 + 3320); /*0x1039c26bd*/
    }
    v16 = v30; /*0x1039c26c1*/
    v17 = a5 + 80LL * v30; /*0x1039c26cd*/
    v18 = v34; /*0x1039c26dc*/
    *(_WORD *)(16LL * *(_QWORD *)(a5 + 8LL * v30 + 4928) + v17 + 4608) = v34; /*0x1039c26e0*/
    RBX::SmallVectorTemplateBase<unsigned short,true>::push_back(a1: a5 + 32 * v16 + 4960, a2: v18); /*0x1039c26fe*/
    *(_QWORD *)(16LL * *(_QWORD *)(a5 + 8 * v16 + 4928) + v17 + 4616) = a3 /*0x1039c273b*/
                                                                      - (v26 / 0x7D0
                                                                       + ((unsigned __int64)v27 >> 1));
    v19 = *(_QWORD *)(a1 + 3384); /*0x1039c2743*/
    if ( v19 != 0 ) /*0x1039c274d*/
    {
      v20 = 0xFFFF; /*0x1039c274f*/
      v21 = 0; /*0x1039c2754*/
      v22 = 0; /*0x1039c2756*/
      do /*0x1039c2782*/
      {
        v23 = *(unsigned __int16 *)(a5 + v21 + 4608); /*0x1039c2758*/
        if ( v23 == 0xFFFF ) /*0x1039c2768*/
          break; /*0x1039c2768*/
        if ( v20 > v23 ) /*0x1039c276d*/
        {
          v22 = *(_QWORD *)(a5 + v21 + 4616); /*0x1039c276f*/
          v20 = *(unsigned __int16 *)(a5 + v21 + 4608); /*0x1039c2777*/
        }
        v21 += 16; /*0x1039c277a*/
      }
      while ( v21 != 80 ); /*0x1039c2782*/
      (*(void (__fastcall **)(__int64, unsigned __int64, unsigned __int64))(*(_QWORD *)v19 + 16LL))( /*0x1039c27a6*/
        a1: v19,
        a2: v26,
        a3: v22 + v28 / 0x3E8 - a3);
    }
    if ( *(_WORD *)(a5 + 2) == 0xFFFF || *(unsigned __int16 *)(a5 + 2) > (int)v34 ) /*0x1039c27bd*/
      *(_WORD *)(a5 + 2) = v34; /*0x1039c27c3*/
    v24 = 0; /*0x1039c27d2*/
    if ( *(_QWORD *)(a5 + 8 * v16 + 4928) != 4 ) /*0x1039c27d8*/
      v24 = *(_QWORD *)(a5 + 8 * v16 + 4928) + 1LL; /*0x1039c27d8*/
    *(_QWORD *)(a5 + 8 * v16 + 4928) = v24; /*0x1039c27dc*/
    return RakNet::SimpleMutex::Unlock(this: v13); /*0x1039c27e7*/
  }
  return result; /*0x1039c27ec*/
}

// Address: 0x1039c27fe | Name: __ZN6RakNet7RakPeer27getTimeSinceLastPongArrivedEv
__int64 __fastcall RakNet::RakPeer::getTimeSinceLastPongArrived(RakNet::RakPeer *this)
{
  RakNet::SimpleMutex *v2; // rbx
  RakNet *v3; // rdi
  unsigned int v4; // r15d

  v2 = (RakNet::RakPeer *)((char *)this + 3320); /*0x1039c280b*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 3320)); /*0x1039c2815*/
  if ( *((_DWORD *)this + 8) != 0 ) /*0x1039c281f*/
    v4 = RakNet::GetTimeMS(this: v3) - *((_DWORD *)this + 8); /*0x1039c2829*/
  else
    v4 = 0; /*0x1039c282f*/
  RakNet::SimpleMutex::Unlock(this: v2); /*0x1039c2835*/
  return v4; /*0x1039c2841*/
}

// Address: 0x1039c2848 | Name: __ZN6RakNet7RakPeer30getSecondsSinceLastPongBucketsEv
RakNet::RakPeer *__fastcall RakNet::RakPeer::getSecondsSinceLastPongBuckets(RakNet::RakPeer *this, _QWORD *a2)
{
  RakNet::SimpleMutex *v4; // r14

  *(_OWORD *)this = 0; /*0x1039c285b*/
  *((_QWORD *)this + 2) = 0; /*0x1039c285e*/
  v4 = (RakNet::SimpleMutex *)(a2 + 415); /*0x1039c2866*/
  RakNet::SimpleMutex::Lock(this: (RakNet::SimpleMutex *)(a2 + 415)); /*0x1039c2870*/
  if ( a2 + 1 != (_QWORD *)this ) /*0x1039c287c*/
    std::vector<int>::__assign_with_size[abi:ne200100]<int *,int *>( /*0x1039c2893*/
      a1: this,
      a2: a2[1],
      a3: a2[2],
      a4: (__int64)(a2[2] - a2[1]) >> 2);
  RakNet::SimpleMutex::Unlock(this: v4); /*0x1039c289b*/
  return this; /*0x1039c28a7*/
}

// Address: 0x1039c2bd8 | Name: __ZN6RakNet7RakPeer19ProcessBannedPacketERKNS_13SystemAddressES3_PS0_NSt3__110shared_ptrINS_12RakNetSocketEEEy
__int64 __fastcall RakNet::RakPeer::ProcessBannedPacket(
        RakNet::SystemAddress *a1,
        __int64 a2,
        RakNet::RakPeer *a3,
        __int64 a4,
        unsigned __int64 a5)
{
  unsigned int v8; // ebx
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // rsi
  __int64 v12; // r8
  __int64 v13; // r9
  unsigned int v14; // ecx
  unsigned __int8 *v15; // r13
  __int64 v16; // rax
  int v17; // r15d
  std::__shared_weak_count *v18; // r12
  RakNet::BitStream *v20; // rdi
  std::__shared_weak_count *v22[2]; // [rsp+30h] [rbp-1A0h] BYREF
  unsigned __int64 v23; // [rsp+48h] [rbp-188h]
  unsigned __int8 v24[16]; // [rsp+50h] [rbp-180h] BYREF
  __int128 v25; // [rsp+60h] [rbp-170h]
  _BYTE v26[12]; // [rsp+78h] [rbp-158h] BYREF
  int v27; // [rsp+84h] [rbp-14Ch]
  __int64 v28; // [rsp+90h] [rbp-140h]

  v23 = a5; /*0x1039c2bec*/
  v8 = (*(__int64 (__fastcall **)(RakNet::RakPeer *, RakNet::SystemAddress *))(*(_QWORD *)a3 + 320LL))(a1: a3, a2: a1); /*0x1039c2c20*/
  if ( (_BYTE)v8 != 0 ) /*0x1039c2c24*/
  {
    RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v26); /*0x1039c2c31*/
    if ( (unsigned __int8)RakNet::RakPeer::IsBannedPeerRuppOptedIn(this: a3, a2: a1) != 0 ) /*0x1039c2c43*/
      RakNet::RakPeer::startOfflineBitStream(this: a3, a2: (RakNet::BitStream *)v26, a3: nullptr, a4: v23); /*0x1039c2c58*/
    v24[0] = 23; /*0x1039c2c64*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v26, a2: v24, a3: 8u, a4: true); /*0x1039c2c78*/
    RakNet::BitStream::WriteAlignedBytes(this: (RakNet::BitStream *)v26, a2: &OFFLINE_MESSAGE_DATA_ID, a3: 0x10u); /*0x1039c2c90*/
    v25 = *(__int128 *)((char *)&xmmword_10CDB0CBC + 4); /*0x1039c2c9c*/
    *(_OWORD *)v24 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039c2caa*/
    v15 = (unsigned __int8 *)(*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)a3 + 424LL))( /*0x1039c2cd7*/
                               a1: a3,
                               a2: v11,
                               a3: v9,
                               a4: v10,
                               a5: v12,
                               a6: v13,
                               a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
                               a8: unk_10CDB0CB8,
                               a9: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 4),
                               a10: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 12));
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c2e49*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v20); /*0x1039c2e54*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c2e61*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c2cef*/
    {
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v26, a2: v15, a3: 0x40u, a4: true); /*0x1039c2d05*/
    }
    else
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v15, a2: v24, a3: (unsigned __int8 *)8, a4: v14); /*0x1039c2d1b*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v26, a2: v24, a3: 0x40u, a4: true); /*0x1039c2d38*/
    }
    v16 = *(_QWORD *)(a4 + 8); /*0x1039c2d3d*/
    *(_OWORD *)v22 = *(_OWORD *)a4; /*0x1039c2d45*/
    if ( v16 != 0 ) /*0x1039c2d4f*/
      _InterlockedIncrement64((volatile signed __int64 *)(v16 + 8)); /*0x1039c2d51*/
    v17 = RakNet::SocketLayer::SendToOrDelay( /*0x1039c2daa*/
            a1: v22,
            a2: v28,
            a3: (unsigned int)(v27 + 7) >> 3,
            a4: a1,
            a5: a2,
            a6: 0,
            a7: a3,
            a8: 0,
            a9: v23,
            a10: "",
            a11: 0);
    v18 = v22[1]; /*0x1039c2dad*/
    if ( v22[1] != nullptr /*0x1039c2dca*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v22[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(a1: v18); /*0x1039c2dd3*/
      std::__shared_weak_count::__release_weak(this: v18); /*0x1039c2dd9*/
    }
    if ( v17 != -3 ) /*0x1039c2de2*/
    {
      ++*((_QWORD *)a3 + 454); /*0x1039c2de4*/
      if ( v17 != 0 ) /*0x1039c2dee*/
      {
        if ( v17 == -4 ) /*0x1039c2df4*/
          ++*((_QWORD *)a3 + 455); /*0x1039c2df6*/
        else
          ++*((_QWORD *)a3 + 456); /*0x1039c2dff*/
      }
    }
    RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v26); /*0x1039c2e0d*/
  }
  return v8; /*0x1039c2e24*/
}

// Address: 0x1039c2eac | Name: __ZN6RakNet7RakPeer21startOfflineBitStreamERNS_9BitStreamEPKNS0_18RemoteSystemStructEy
__int64 __fastcall RakNet::RakPeer::startOfflineBitStream(
        RakNet::RakPeer *this,
        RakNet::BitStream *a2,
        const RakNet::RakPeer::RemoteSystemStruct *a3,
        __int64 a4)
{
  __int64 HeaderTotalByteLength; // r15
  RBX::Rupp::Rupp *v9; // r12
  __int64 v10; // rax
  __int128 v11; // xmm0
  volatile signed __int64 *v12; // r15
  std::__shared_weak_count *v13; // r15
  std::__shared_weak_count *v14; // rbx
  _BYTE v16[16]; // [rsp+10h] [rbp-60h] BYREF
  std::__shared_weak_count *v17[2]; // [rsp+20h] [rbp-50h] BYREF
  RBX::Rupp::Rupp *v18[2]; // [rsp+40h] [rbp-30h] BYREF

  RakNet::BitStream::Reset(this: a2); /*0x1039c2eca*/
  *(_OWORD *)v18 = 0; /*0x1039c2ed2*/
  if ( a3 != nullptr ) /*0x1039c2ed9*/
  {
    std::shared_ptr<RBX::Rupp::Rupp>::operator=[abi:ne200100](a1: v18); /*0x1039c2eed*/
  }
  else
  {
    (*(void (__fastcall **)(std::__shared_weak_count **, RakNet::RakPeer *))(*(_QWORD *)this + 808LL))( /*0x1039c2fec*/
      a1: v17,
      a2: this);
    v11 = *(_OWORD *)v17; /*0x1039c2ff2*/
    *(_OWORD *)v17 = 0; /*0x1039c2ff9*/
    v12 = (volatile signed __int64 *)v18[1]; /*0x1039c2ffd*/
    *(_OWORD *)v18 = v11; /*0x1039c3001*/
    if ( v12 != nullptr && _InterlockedExchangeAdd64(v12 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039c301a*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v12 + 16))(a1: v12); /*0x1039c3022*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v12); /*0x1039c3028*/
    }
    v13 = v17[1]; /*0x1039c302d*/
    if ( v17[1] != nullptr /*0x1039c304a*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v17[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x1039c3056*/
      std::__shared_weak_count::__release_weak(this: v13); /*0x1039c305c*/
    }
  }
  if ( v18[0] != nullptr )
  {
    HeaderTotalByteLength = (unsigned __int16)RBX::Rupp::Rupp::getHeaderTotalByteLength(this: v18[0]); /*0x1039c2f0f*/
    if ( ((unsigned int)RakNet::BitStream::GetNumberOfBitsAllocated(this: a2) + 7) >> 3 < (unsigned __int16)HeaderTotalByteLength ) /*0x1039c2f1c*/
      RakNet::BitStream::AddBitsAndReallocate(this: a2, a2: 8 * (unsigned __int16)HeaderTotalByteLength); /*0x1039c2f29*/
    if ( (unsigned __int8)DFLog::Rupp >= 6u && BYTE1(DFLog::Rupp) >= 6u )
    {
      v17[0] = (std::__shared_weak_count *)4; /*0x1039c2f58*/
      v17[1] = (std::__shared_weak_count *)v16; /*0x1039c2f60*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: DFLog::Rupp,
        a2: qword_10D7BB258,
        a3: 6,
        a4: (unsigned int)"[DFLog::Rupp] Offline ruppLength: {}",
        a5: 36,
        a6: 1,
        4,
        v16,
        (unsigned __int16)HeaderTotalByteLength);
    }
    v9 = v18[0]; /*0x1039c2f89*/
    v10 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1039c2f93*/
    RBX::Rupp::Rupp::serialize(a1: v17, a2: v9, a3: v10, a4: (unsigned __int16)HeaderTotalByteLength, a5: a4); /*0x1039c2fa6*/
    if ( LODWORD(v17[0]) != 0 ) /*0x1039c2faf*/
    {
      if ( DFFlag::RakNetRuppTelemetryReportNetworkStack == 1 ) /*0x1039c2fc3*/
        RBX::Rupp::reportRuppSerializationFailure(a1: v18[0], a2: v17, a3: 0, a4: 0, a5: 0, a6: 0); /*0x1039c2fd7*/
      else
        RBX::Rupp::reportRuppSerializationFailure_deprecated(a1: v18[0], a2: v17, a3: 0, a4: 0, a5: 0); /*0x1039c3076*/
    }
    RakNet::BitStream::SetWriteOffset(this: a2, a2: 8 * (unsigned __int16)HeaderTotalByteLength, a3: false); /*0x1039c3086*/
  }
  else
  {
    HeaderTotalByteLength = 0; /*0x1039c3066*/
  }
  v14 = v18[1]; /*0x1039c308b*/
  if ( v18[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v18[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039c30a4*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x1039c30ac*/
    std::__shared_weak_count::__release_weak(this: v14); /*0x1039c30b2*/
  }
  return HeaderTotalByteLength; /*0x1039c30ba*/
}

// Address: 0x1039c30e0 | Name: __ZN6RakNet7RakPeer15IsOfflinePacketEPKci
unsigned __int8 __fastcall RakNet::RakPeer::IsOfflinePacket(RakNet::RakPeer *this, const char *a2)
{
  unsigned __int8 result; // al
  unsigned int v3; // ecx
  int v4; // eax
  __int64 v5; // rax
  unsigned int v6; // ecx
  int v7; // edx
  __m128i v8; // xmm0

  result = 1; /*0x1039c30e0*/
  if ( (int)a2 >= 3 ) /*0x1039c30e5*/
  {
    v3 = *(unsigned __int8 *)this; /*0x1039c30e7*/
    if ( v3 <= 0x1A ) /*0x1039c30ed*/
    {
      v4 = 76949984; /*0x1039c30ef*/
      if ( _bittest(&v4, v3) ) /*0x1039c30f7*/
        goto LABEL_10; /*0x1039c30f7*/
      if ( v3 == 25 ) /*0x1039c30fc*/
      {
        v5 = 2; /*0x1039c30fe*/
        if ( (_DWORD)a2 != 26 ) /*0x1039c3106*/
          return 0; /*0x1039c3108*/
LABEL_11:
        v8 = _mm_xor_si128(_mm_loadu_si128((const __m128i *)((char *)this + v5)), (__m128i)xmmword_10957A690); /*0x1039c3129*/
        return _mm_testz_si128(v8, v8); /*0x1039c313f*/
      }
    }
    result = 0; /*0x1039c310b*/
    v6 = v3 - 120; /*0x1039c310d*/
    if ( v6 <= 6 ) /*0x1039c3113*/
    {
      v7 = 105; /*0x1039c3115*/
      if ( _bittest(&v7, v6) ) /*0x1039c311a*/
      {
LABEL_10:
        v5 = 1; /*0x1039c311f*/
        if ( (unsigned int)a2 < 0x19 ) /*0x1039c3127*/
          return 0; /*0x1039c3127*/
        goto LABEL_11; /*0x1039c3127*/
      }
    }
  }
  return result; /*0x1039c310a*/
}

// Address: 0x1039c3144 | Name: __ZN6RakNet7RakPeer27ProcessOfflineNetworkPacketERKNS_13SystemAddressES3_PKciPS0_NSt3__110shared_ptrINS_12RakNetSocketEEEyytN3RBX10StringViewERKNSB_4Rupp21DeserializationResultE
__int64 __fastcall RakNet::RakPeer::ProcessOfflineNetworkPacket(
        RakNet::SystemAddress *a1,
        __int64 a2,
        unsigned __int8 *a3,
        signed int a4,
        __int64 a5,
        __int64 a6,
        __int64 a7,
        __int64 a8,
        __int16 a9,
        char a10,
        int a11,
        __int64 a12)
{
  unsigned int v14; // edx
  int v15; // r11d
  int v16; // r8d
  int v17; // r9d
  unsigned int v18; // ecx
  unsigned int i; // r13d
  unsigned int v20; // eax
  unsigned int v21; // r12d
  bool v22; // cf
  unsigned int v23; // r12d
  unsigned int v24; // edx
  __int64 v25; // rcx
  __int64 v26; // rax
  _DWORD *v27; // r15
  __int64 v28; // r15
  __int64 result; // rax
  int v30; // r11d
  RakNet::BitStream *v31; // rdi
  _QWORD v32[4]; // [rsp+30h] [rbp-5B0h] BYREF
  RakNet::SimpleMutex *v33; // [rsp+50h] [rbp-590h]
  unsigned __int8 *v34; // [rsp+58h] [rbp-588h]
  __int64 v35; // [rsp+60h] [rbp-580h]
  unsigned __int8 v36[8]; // [rsp+68h] [rbp-578h] BYREF
  __int16 v37; // [rsp+70h] [rbp-570h]
  RakNet::SystemAddress *v38; // [rsp+78h] [rbp-568h]
  char v39[1032]; // [rsp+80h] [rbp-560h] BYREF
  _BYTE v40[296]; // [rsp+488h] [rbp-158h] BYREF

  v38 = a1; /*0x1039c3161*/
  v14 = *a3; /*0x1039c3186*/
  if ( v14 <= 0x1A )
  {
    v15 = 127281152; /*0x1039c3193*/
    if ( _bittest(&v15, v14) )
    {
      RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v40, a2: a3, a3: a4, a4: false); /*0x1039c31b1*/
      RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v40, a2: 1u); /*0x1039c31c2*/
      RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v40, a2: 0x10u); /*0x1039c31d3*/
      if ( *a3 == 25 ) /*0x1039c31dc*/
        RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v40, a2: 1u); /*0x1039c31ea*/
      RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)v36); /*0x1039c31f6*/
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c35da*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v31); /*0x1039c35e5*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c35f2*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c3210*/
      {
        RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v40, a2: v36, a3: 0x40u, a4: true); /*0x1039c322a*/
      }
      else if ( (unsigned __int8)RakNet::BitStream::ReadBits( /*0x1039c3250*/
                                   this: (RakNet::BitStream *)v40,
                                   a2: (unsigned __int8 *)v39,
                                   a3: 0x40u,
                                   a4: true) != 0 )
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v39, a2: v36, a3: (unsigned __int8 *)8, a4: v18); /*0x1039c3265*/
      }
      if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
        FLog::FastLogFormatted(
          a1: (_DWORD)DFLog::RakNetConnectTrace,
          a2: qword_10D7BB0C8,
          a3: (unsigned int)"[DFLog::RakNetConnectTrace] RakNet: Bad Offline message received, message id : %u",
          a4: *a3,
          a5: v16,
          a6: v17);
      v34 = a3; /*0x1039c329f*/
      v33 = (RakNet::SimpleMutex *)(a5 + 1160); /*0x1039c32ad*/
      RakNet::SimpleMutex::Lock(this: (RakNet::SimpleMutex *)(a5 + 1160)); /*0x1039c32b4*/
      v35 = a5 + 1136; /*0x1039c32c0*/
      for ( i = 0; ; ++i )
      {
        v20 = *(_DWORD *)(a5 + 1144); /*0x1039c32cd*/
        v21 = *(_DWORD *)(a5 + 1148); /*0x1039c32d9*/
        v22 = v21 < v20; /*0x1039c32dc*/
        v23 = v21 - v20; /*0x1039c32dc*/
        if ( v22 ) /*0x1039c32df*/
          v23 = *(_DWORD *)(a5 + 1152) + *(_DWORD *)(a5 + 1148) - v20; /*0x1039c32e9*/
        if ( i >= v23 ) /*0x1039c32ef*/
          break; /*0x1039c32ef*/
        v24 = *(_DWORD *)(a5 + 1152); /*0x1039c32f9*/
        v25 = *(_QWORD *)(a5 + 1136); /*0x1039c3301*/
        if ( v20 + i < v24 ) /*0x1039c3308*/
          v24 = 0; /*0x1039c3308*/
        v26 = i + v20 - v24; /*0x1039c330e*/
        v27 = *(_DWORD **)(v25 + 8 * v26); /*0x1039c3311*/
        if ( v27[95] == 1
          && (unsigned __int8)RakNet::SystemAddress::operator==(a1: *(_QWORD *)(v25 + 8 * v26), a2: v38) != 0 )
        {
          DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::RemoveAtIndex(a1: v35, a2: i); /*0x1039c3341*/
          if ( (_BYTE)DFLog::RakNetConnectTrace != 0 && DFFlag::DebugRakNetConnectTracePrintRcsSystemAddress == 1 )
          {
            RakNet::SystemAddress::ToStringN(this: v38, a2: true, a3: v39, a4: 1025, a5: 124); /*0x1039c3381*/
            if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
            {
              v32[0] = v39; /*0x1039c33b0*/
              v32[2] = 12; /*0x1039c33b3*/
              v32[3] = v32; /*0x1039c33be*/
              FLog::detail::FastLogSafeFormattedInternal(
                a1: (_DWORD)DFLog::RakNetConnectTrace,
                a2: qword_10D7BB0C8,
                a3: 3,
                a4: (unsigned int)"[DFLog::RakNetConnectTrace] RCS was removed for: {}",
                a5: 51,
                a6: 1,
                12,
                v32);
            }
          }
          std::shared_ptr<RBX::Security::RakPeerCrypto>::~shared_ptr[abi:ne200100](a1: v27 + 90); /*0x1039c33f4*/
          std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: v27 + 86); /*0x1039c3400*/
          operator delete(a1: v27); /*0x1039c3408*/
          break; /*0x1039c3408*/
        }
      }
      RakNet::SimpleMutex::Unlock(this: v33); /*0x1039c340d*/
      if ( i < v23 ) /*0x1039c341c*/
      {
        v28 = RakNet::RakPeer::AllocPacket(this: (RakNet::RakPeer *)a5, a2: 1u, a3: "", a4: 0); /*0x1039c3434*/
        **(_BYTE **)(v28 + 56) = *v34; /*0x1039c3444*/
        *(_DWORD *)(v28 + 52) = 8; /*0x1039c3446*/
        RakNet::SystemAddress::operator=(a1: v28, a2: v38); /*0x1039c3458*/
        *(_QWORD *)(v28 + 32) = *(_QWORD *)v36; /*0x1039c3464*/
        *(_WORD *)(v28 + 40) = v37; /*0x1039c346f*/
        RakNet::RakPeer::AddPacketToProducer(this: (RakNet::RakPeer *)a5); /*0x1039c347c*/
      }
      RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v40); /*0x1039c3488*/
      return __stack_chk_guard; /*0x1039c3488*/
    }
    v30 = 320; /*0x1039c34b3*/
    if ( _bittest(&v30, v14) ) /*0x1039c34bd*/
      return __stack_chk_guard; /*0x1039c34bd*/
  }
  if ( v14 == 5 && a4 >= 18 ) /*0x1039c34c9*/
    return __stack_chk_guard; /*0x1039c34b2*/
  switch ( v14 ) /*0x1039c34e8*/
  {
    case 'x': /*0x1039c34e8*/
      RakNet::RakPeer::processRbxOpenRequest2( /*0x1039c3517*/
        this: (RakNet::RakPeer *)a5,
        a2: a3,
        a3: a4,
        a4: v38,
        a5: a9,
        a6: a10,
        a7: a11,
        a8,
        a9: a12);
      return __stack_chk_guard; /*0x1039c351c*/
    case '{': /*0x1039c34e8*/
      RakNet::RakPeer::processRbxOpenRequest1(this: (RakNet::RakPeer *)a5, a2: a9, a3: a8, a4: a12); /*0x1039c3581*/
      return __stack_chk_guard; /*0x1039c3586*/
    case '}': /*0x1039c34e8*/
      result = RakNet::RakPeer::processRbxOpenReply2(this: (RakNet::RakPeer *)a5, a2: a3, a3: a4, a4: v38); /*0x1039c355c*/
      break; /*0x1039c355c*/
    case '~': /*0x1039c34e8*/
      result = RakNet::RakPeer::processRbxOpenReply1(this: (RakNet::RakPeer *)a5, a2: a3); /*0x1039c35c2*/
      break; /*0x1039c35c2*/
    default:
      return __stack_chk_guard;
  }
  return result; /*0x1039c34a1*/
}

// Address: 0x1039c36be | Name: __ZN6RakNet7RakPeer19AddPacketToProducerEPNS_6PacketEb
__int64 __fastcall RakNet::RakPeer::AddPacketToProducer(RakNet::RakPeer *this, __int64 a2, char a3)
{
  __int64 v6; // rax
  int v7; // ecx
  unsigned __int8 v8; // r12
  char v10; // r12
  char *v11; // rdi
  int v12; // r9d
  __int64 v13; // rdx
  __int64 v14; // rcx
  _BYTE v15[16]; // [rsp+8h] [rbp-468h] BYREF
  void *v16; // [rsp+18h] [rbp-458h]
  RakNet::SystemAddress *v17; // [rsp+38h] [rbp-438h] BYREF
  char v18[1032]; // [rsp+40h] [rbp-430h] BYREF

  v17 = (RakNet::SystemAddress *)a2; /*0x1039c36e7*/
  *(_QWORD *)(a2 + 72) = (unsigned int)RakNet::GetTimeMS(this); /*0x1039c36f5*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 2784)); /*0x1039c3704*/
  if ( DFFlag::CLI56775 != 1 /*0x1039c3724*/
    || (v6 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>::find<RakNet::SystemAddress>(
               a1: (char *)this + 2872,
               a2)) == 0 )
  {
    DataStructures::Queue<RakNet::Packet *>::Push(a1: (__int64)this + 2848, a2: (__int64 *)&v17); /*0x1039c3755*/
    RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 2784)); /*0x1039c375d*/
    return __stack_chk_guard; /*0x1039c375d*/
  }
  v7 = *(_DWORD *)(v6 + 48) + *(_DWORD *)(a2 + 48); /*0x1039c372b*/
  if ( v7 >= (unsigned int)DFInt::CLI56775B ) /*0x1039c3734*/
  {
    v10 = *(_BYTE *)(v6 + 52); /*0x1039c3786*/
    if ( v10 == 0 ) /*0x1039c378d*/
      *(_BYTE *)(v6 + 52) = 1; /*0x1039c378f*/
    v8 = v10 ^ 1; /*0x1039c3793*/
    if ( DFFlag::CLI56775D != 0 ) /*0x1039c379e*/
      goto LABEL_15; /*0x1039c379e*/
  }
  else
  {
    v8 = 0; /*0x1039c3736*/
  }
  *(_DWORD *)(v6 + 48) = v7; /*0x1039c37a0*/
  if ( *((_DWORD *)this + 35) > v7 ) /*0x1039c37ab*/
    v7 = *((_DWORD *)this + 35); /*0x1039c37ab*/
  *((_DWORD *)this + 35) = v7; /*0x1039c37ae*/
  v11 = (char *)this + 2848; /*0x1039c37b4*/
  if ( a3 != 0 ) /*0x1039c37be*/
    DataStructures::Queue<RakNet::Packet *>::PushAtHead(a1: (__int64)v11, a2: &v17, a3: 0, a4: (__int64)"", a5: 0); /*0x1039c37d3*/
  else
    DataStructures::Queue<RakNet::Packet *>::Push(a1: (__int64)v11, a2: (__int64 *)&v17); /*0x1039c37ea*/
LABEL_15:
  RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 2784)); /*0x1039c37ef*/
  if ( ((unsigned __int8)DFFlag::CLI56775 & v8) == 1 )
  {
    RakNet::SystemAddress::ToStringN(this: v17, a2: true, a3: v18, a4: 1025, a5: 124); /*0x1039c3826*/
    v14 = (unsigned int)FLog::Network >> 8; /*0x1039c3837*/
    LOBYTE(v13) = (unsigned __int8)FLog::Network < 6u; /*0x1039c383e*/
    LOBYTE(v14) = (unsigned __int8)FLog::Network < 6u || BYTE1(FLog::Network) < 3u; /*0x1039c3847*/
    if ( (_BYTE)v14 == 0 )
      FLog::FastLogFormatted(
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: (unsigned int)"[FLog::Network] Rx: Peer %s exceeded buffered complete datagram byte cap of %d",
        a4: (unsigned int)v18,
        a5: DFInt::CLI56775B,
        a6: v12);
    std::string::basic_string[abi:ne200100]<0>(a1: v15, a2: "RakNetRxCompleteDatagramByteCapExceeded", a3: v13, a4: v14); /*0x1039c3879*/
    RBX::Analytics::EphemeralCounter::reportCounter(a1: v15, a2: 1, a3: 0); /*0x1039c388c*/
    if ( (v15[0] & 1) != 0 ) /*0x1039c3898*/
      operator delete(a1: v16); /*0x1039c38a1*/
    ++*((_DWORD *)this + 36); /*0x1039c38a6*/
    if ( DFFlag::CLI56775D == 1 ) /*0x1039c38b3*/
    {
      RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v15, a2: v17); /*0x1039c38c7*/
      RakNet::RakPeer::CloseConnectionInternal(this, a2: (RakNet::AddressOrGUID *)v15, a3: 0, a4: 1); /*0x1039c38e0*/
      (*(void (__fastcall **)(RakNet::RakPeer *, RakNet::SystemAddress *))(*(_QWORD *)this + 240LL))(a1: this, a2: v17); /*0x1039c38f2*/
    }
  }
  return __stack_chk_guard; /*0x1039c3776*/
}

// Address: 0x1039c3928 | Name: __ZN6RakNet7RakPeer22processRbxOpenRequest1EPKhmRKNS_13SystemAddressES5_RNSt3__110shared_ptrINS_12RakNetSocketEEEtyRKN3RBX4Rupp21DeserializationResultE
__int64 __fastcall RakNet::RakPeer::processRbxOpenRequest1(
        RakNet::RakPeer *this,
        __int64 a2,
        unsigned __int64 a3,
        RakNet::SystemAddress *a4,
        __int64 a5,
        __int64 a6,
        unsigned __int16 a7,
        __int64 a8,
        __int64 a9)
{
  RakNet::SimpleMutex *v12; // rbx
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // rsi
  __int64 v16; // r8
  int v17; // r9d
  __int64 v18; // r9
  __int64 v19; // rcx
  char v20; // r14
  unsigned int v21; // ebx
  unsigned int v22; // ebx
  char v25[16]; // [rsp+30h] [rbp-440h] BYREF
  __int128 v26; // [rsp+40h] [rbp-430h]

  v12 = (RakNet::RakPeer *)((char *)this + 3232); /*0x1039c3964*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 3232)); /*0x1039c396e*/
  ++*((_DWORD *)this + 801); /*0x1039c3973*/
  RakNet::SimpleMutex::Unlock(this: v12); /*0x1039c397d*/
  if ( a3 < 0x12 || a7 + a3 + 40 <= 0x23F ) /*0x1039c399e*/
  {
    v21 = 0; /*0x1039c3a88*/
    if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c3a73*/
      FLog::FastLogFormatted( /*0x1039c3a8f*/
        a1: DFLog::SessionCrypto,
        a2: qword_10D7BB210,
        a3: (unsigned int)"[DFLog::SessionCrypto] RbxOpenRequest1 has incorrect size %d.",
        a4: a3,
        a5: v16,
        a6: v17);
  }
  else
  {
    v18 = a8; /*0x1039c39a4*/
    LOBYTE(v13) = *(_BYTE *)(a2 + 18); /*0x1039c39a8*/
    if ( *(_BYTE *)(a2 + 17) == 5 ) /*0x1039c39b1*/
    {
      v19 = a9; /*0x1039c39b7*/
      if ( (_BYTE)DFLog::RakNetConnectTrace != 0 ) /*0x1039c39c2*/
      {
        v20 = *(_BYTE *)(a2 + 18); /*0x1039c39c4*/
        RakNet::SystemAddress::ToStringN(this: a4, a2: true, a3: v25, a4: 1025, a5: 124); /*0x1039c39e5*/
        if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u ) /*0x1039c39ff*/
          FLog::FastLogS( /*0x1039c3a1b*/
            this: DFLog::RakNetConnectTrace,
            a2: qword_10D7BB0C8,
            a3: (unsigned __int64)"[DFLog::RakNetConnectTrace] Received RbxOpenRequest1 from %s",
            a4: v25);
        LOBYTE(v13) = v20; /*0x1039c3a24*/
        v19 = a9; /*0x1039c3a27*/
      }
      v21 = a3 + a7; /*0x1039c3a32*/
      RakNet::RakPeer::sendRbxOpenReply1(this, a2: (_BYTE)v13 != 0, a3: v19); /*0x1039c3a54*/
    }
    else
    {
      LOBYTE(v14) = (unsigned __int8)DFLog::SessionCrypto < 6u; /*0x1039c3ab3*/
      if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c3ab8*/
      {
        v22 = v13; /*0x1039c3ac6*/
        FLog::FastLog( /*0x1039c3ad1*/
          a1: DFLog::SessionCrypto,
          a2: qword_10D7BB210,
          a3: "[DFLog::SessionCrypto] RbxOpenRequest1 Incompatible Protocol",
          0,
          v16,
          a8);
        v13 = v22; /*0x1039c3ad6*/
      }
      v21 = (_BYTE)v13 != 0; /*0x1039c3adc*/
      v26 = *(__int128 *)((char *)&xmmword_10CDB0CBC + 4); /*0x1039c3ae6*/
      *(_OWORD *)v25 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039c3af4*/
      (*(void (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)this + 424LL))( /*0x1039c3b18*/
        a1: this,
        a2: v15,
        a3: v13,
        a4: v14,
        a5: v16,
        a6: v18,
        a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
        a8: unk_10CDB0CB8,
        a9: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 4),
        a10: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 12));
      RakNet::RakPeer::sendRbxOpenError(this, a2: v21); /*0x1039c3b3d*/
    }
    LOBYTE(v21) = 1; /*0x1039c3b42*/
  }
  return v21; /*0x1039c3b56*/
}

// Address: 0x1039c3b6e | Name: __ZN6RakNet7RakPeer20processRbxOpenReply1EPKhmRKNS_13SystemAddressERNSt3__110shared_ptrINS_12RakNetSocketEEEy
__int64 __fastcall RakNet::RakPeer::processRbxOpenReply1(
        RakNet::RakPeer *this,
        unsigned __int8 *a2,
        __int64 a3,
        const RakNet::SystemAddress *a4,
        __int64 a5,
        __int64 a6)
{
  RakNet::SimpleMutex *v10; // rbx
  __int64 RequestedConnectionStruct; // rax
  int v12; // r8d
  int v13; // r9d
  __int64 v14; // rdi
  unsigned int v15; // ebx
  unsigned int v16; // ecx
  unsigned int v17; // ecx
  __int64 v18; // r15
  bool v19; // al
  RakNet::BitStream *v21; // rdi
  RakNet::BitStream *v22; // rdi
  _BYTE v23[16]; // [rsp+10h] [rbp-5A0h] BYREF
  __int64 v24; // [rsp+20h] [rbp-590h]
  _BYTE *v25; // [rsp+28h] [rbp-588h]
  unsigned __int8 v26[16]; // [rsp+30h] [rbp-580h] BYREF
  __int64 v27; // [rsp+40h] [rbp-570h]
  unsigned __int8 v28[2]; // [rsp+4Eh] [rbp-562h] BYREF
  char v29[1032]; // [rsp+50h] [rbp-560h] BYREF
  _BYTE v30[296]; // [rsp+458h] [rbp-158h] BYREF

  v27 = a6; /*0x1039c3b82*/
  v10 = (RakNet::RakPeer *)((char *)this + 3232); /*0x1039c3ba3*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 3232)); /*0x1039c3bad*/
  ++*((_DWORD *)this + 803); /*0x1039c3bb2*/
  RakNet::SimpleMutex::Unlock(this: v10); /*0x1039c3bbc*/
  RequestedConnectionStruct = RakNet::RakPeer::findRequestedConnectionStruct(this, a2: a4); /*0x1039c3bc7*/
  if ( RequestedConnectionStruct != 0 ) /*0x1039c3bcf*/
    *(_BYTE *)(RequestedConnectionStruct + 324) = 1; /*0x1039c3bd1*/
  if ( a3 == 28 )
  {
    v14 = *((_QWORD *)this + 423); /*0x1039c3be2*/
    if ( v14 != 0 ) /*0x1039c3bec*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v14 + 32LL))(a1: v14); /*0x1039c3bf1*/
    RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v30, a2, a3: 0x1Cu, a4: false); /*0x1039c3c05*/
    RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v30, a2: 1u); /*0x1039c3c16*/
    RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v30, a2: 0x10u); /*0x1039c3c27*/
    RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)v26); /*0x1039c3c33*/
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c3ee3*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v21); /*0x1039c3eee*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c3efb*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c3c4d*/
    {
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v30, a2: v26, a3: 0x40u, a4: true); /*0x1039c3c67*/
    }
    else if ( (unsigned __int8)RakNet::BitStream::ReadBits( /*0x1039c3ccf*/
                                 this: (RakNet::BitStream *)v30,
                                 a2: (unsigned __int8 *)v29,
                                 a3: 0x40u,
                                 a4: true) != 0 )
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v29, a2: v26, a3: (unsigned __int8 *)8, a4: v16); /*0x1039c3ce4*/
    }
    RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v30, a2: 1u); /*0x1039c3cf5*/
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c3f13*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v22); /*0x1039c3f1e*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c3f2b*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c3d0f*/
    {
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v30, a2: v28, a3: 0x10u, a4: true); /*0x1039c3d29*/
    }
    else if ( (unsigned __int8)RakNet::BitStream::ReadBits( /*0x1039c3d4f*/
                                 this: (RakNet::BitStream *)v30,
                                 a2: (unsigned __int8 *)v29,
                                 a3: 0x10u,
                                 a4: true) != 0 )
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v29, a2: v28, a3: (unsigned __int8 *)2, a4: v17); /*0x1039c3d64*/
    }
    if ( DFInt::ConnectionMTUSize > 0 ) /*0x1039c3d71*/
      *(_WORD *)v28 = DFInt::ConnectionMTUSize; /*0x1039c3d73*/
    if ( (_BYTE)DFLog::RakNetConnectTrace != 0 && DFFlag::DebugRakNetConnectTracePrintRcsSystemAddress == 1 )
    {
      RakNet::SystemAddress::ToStringN(this: a4, a2: true, a3: v29, a4: 1025, a5: 124); /*0x1039c3db1*/
      if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
      {
        v24 = 12; /*0x1039c3de3*/
        v25 = v23; /*0x1039c3dee*/
        FLog::detail::FastLogSafeFormattedInternal(
          a1: (_DWORD)DFLog::RakNetConnectTrace,
          a2: qword_10D7BB0C8,
          a3: 3,
          a4: (unsigned int)"[DFLog::RakNetConnectTrace] Looking up RCS using: {}",
          a5: 52,
          a6: 1,
          12,
          v23,
          v29);
      }
    }
    v18 = RakNet::RakPeer::findRequestedConnectionStruct(this, a2: a4); /*0x1039c3e28*/
    v19 = (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u; /*0x1039c3e43*/
    if ( v18 != 0 )
    {
      if ( v19 )
        FLog::FastLog(
          a1: DFLog::RakNetConnectTrace,
          a2: qword_10D7BB0C8,
          a3: "[DFLog::RakNetConnectTrace] RakNet: OpenReply1 received will send OpenRequest2 with mtu size %d",
          *(unsigned __int16 *)v28);
      v15 = RakNet::RakPeer::sendRbxOpenRequest2(this); /*0x1039c3e81*/
    }
    else
    {
      v15 = 0; /*0x1039c3e85*/
      if ( v19 )
        FLog::FastLog(
          a1: DFLog::RakNetConnectTrace,
          a2: qword_10D7BB0C8,
          a3: "[DFLog::RakNetConnectTrace] RakNet: OpenReply1 received but cannot find related RCS",
          0);
    }
    RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v30); /*0x1039c3ea7*/
  }
  else
  {
    v15 = 0; /*0x1039c3c98*/
    if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c3c83*/
      FLog::FastLogFormatted( /*0x1039c3c9f*/
        a1: DFLog::SessionCrypto,
        a2: qword_10D7BB210,
        a3: (unsigned int)"[DFLog::SessionCrypto] RbxOpenReply1 has invalid size %d.",
        a4: a3,
        a5: v12,
        a6: v13);
  }
  return v15; /*0x1039c3ebe*/
}

// Address: 0x1039c3f6c | Name: __ZN6RakNet7RakPeer22processRbxOpenRequest2EPKhmRKNS_13SystemAddressES5_RNSt3__110shared_ptrINS_12RakNetSocketEEEtN3RBX10StringViewEyRKNSB_4Rupp21DeserializationResultE
__int64 __fastcall RakNet::RakPeer::processRbxOpenRequest2(
        RakNet::RakPeer *this,
        unsigned __int8 *a2,
        unsigned __int64 a3,
        RakNet::SystemAddress *a4,
        __int64 a5,
        __int128 *a6,
        unsigned __int16 a7,
        _OWORD *a8,
        __int64 a9,
        __int64 a10,
        __int64 a11)
{
  RakNet::SimpleMutex *v15; // r12
  int v16; // r8d
  int v17; // r9d
  __int64 (__fastcall ***v18)(); // r12
  unsigned int v19; // ecx
  unsigned int v20; // ecx
  unsigned int v21; // edx
  unsigned __int8 *v22; // rbx
  _OWORD *v23; // rax
  unsigned __int8 *v24; // rsi
  unsigned int v25; // edx
  __int64 v26; // rdx
  char *v27; // rsi
  __int64 v28; // rdx
  __int64 v29; // rcx
  int v30; // r8d
  int v31; // r9d
  int v32; // r12d
  int v33; // r8d
  int v34; // r9d
  int v35; // ebx
  std::__shared_weak_count *v36; // rbx
  __int128 v38; // xmm0
  char *v39; // rdx
  __int64 v40; // rcx
  unsigned int RemoteSystemIndex; // eax
  __int64 v42; // rax
  unsigned int v43; // eax
  __int64 v44; // rax
  RBX::Security::SessionCrypto *v45; // r12
  char v46; // al
  __int64 v47; // rdi
  __int64 CapabilitiesIfAny; // r13
  unsigned __int8 *v49; // rsi
  const char *v50; // rcx
  int v51; // r8d
  int v52; // r9d
  unsigned __int64 v53; // rbx
  __int64 v54; // rdx
  __int64 v55; // rcx
  RakNet::RakPeer::RemoteSystemStruct *RemoteSystemFromGUID; // rax
  __int64 v57; // r8
  char v58; // cl
  char v59; // al
  __int128 v60; // xmm0
  __int64 v61; // rax
  int v62; // r8d
  int v63; // r9d
  std::__shared_weak_count *v64; // rbx
  unsigned __int8 v65; // al
  char isAesGcm; // al
  const char *v67; // rcx
  RakNet::RakPeer::RemoteSystemStruct *v68; // r13
  RBX::Rupp::Rupp **v69; // r12
  __int64 v70; // rdi
  __int64 v71; // rax
  __int64 v72; // rax
  RakNet::BitStream *v73; // rdi
  RakNet::BitStream *v74; // rdi
  char v75[16]; // [rsp+80h] [rbp-A90h] BYREF
  void *v76[2]; // [rsp+90h] [rbp-A80h]
  _BYTE v77[480]; // [rsp+C8h] [rbp-A48h] BYREF
  _QWORD v78[4]; // [rsp+2A8h] [rbp-868h] BYREF
  __int64 v79; // [rsp+2C8h] [rbp-848h]
  char *v80; // [rsp+2D0h] [rbp-840h]
  __int64 v81; // [rsp+2D8h] [rbp-838h]
  __int128 v82; // [rsp+2E0h] [rbp-830h] BYREF
  __int64 v83[2]; // [rsp+2F0h] [rbp-820h] BYREF
  __int64 v84; // [rsp+300h] [rbp-810h]
  unsigned __int8 v85[16]; // [rsp+308h] [rbp-808h] BYREF
  RakNet::RakPeer::RemoteSystemStruct *v86; // [rsp+318h] [rbp-7F8h]
  std::__shared_weak_count *v87[2]; // [rsp+320h] [rbp-7F0h] BYREF
  __int128 *v88; // [rsp+338h] [rbp-7D8h]
  RBX::Security::SessionCrypto *v89[2]; // [rsp+340h] [rbp-7D0h] BYREF
  unsigned __int8 v90; // [rsp+357h] [rbp-7B9h] BYREF
  RakNet::RakPeer::RemoteSystemStruct *v91; // [rsp+358h] [rbp-7B8h]
  unsigned __int8 v92[2]; // [rsp+366h] [rbp-7AAh] BYREF
  unsigned __int8 v93[2]; // [rsp+368h] [rbp-7A8h] BYREF
  unsigned __int8 v94[2]; // [rsp+36Ah] [rbp-7A6h] BYREF
  unsigned __int8 v95; // [rsp+36Ch] [rbp-7A4h] BYREF
  char v96; // [rsp+36Dh] [rbp-7A3h] BYREF
  unsigned __int8 v97; // [rsp+36Eh] [rbp-7A2h] BYREF
  unsigned __int8 v98; // [rsp+36Fh] [rbp-7A1h] BYREF
  _QWORD v99[4]; // [rsp+370h] [rbp-7A0h] BYREF
  _QWORD *v100; // [rsp+390h] [rbp-780h]
  char v101[16]; // [rsp+3A0h] [rbp-770h] BYREF
  char v102; // [rsp+3B0h] [rbp-760h]
  unsigned __int8 v103[16]; // [rsp+3B8h] [rbp-758h] BYREF
  char v104[16]; // [rsp+590h] [rbp-580h] BYREF
  __int128 v105; // [rsp+5A0h] [rbp-570h]
  __int64 v106; // [rsp+5C0h] [rbp-550h]
  __int64 v107; // [rsp+5C8h] [rbp-548h]
  __int64 v108; // [rsp+5D8h] [rbp-538h]
  __int64 v109; // [rsp+5E0h] [rbp-530h]
  unsigned __int8 v110[296]; // [rsp+998h] [rbp-178h] BYREF
  unsigned __int8 v111[32]; // [rsp+AC0h] [rbp-50h] BYREF

  v88 = a6; /*0x1039c3f80*/
  v84 = a5; /*0x1039c3f87*/
  v15 = (RakNet::RakPeer *)((char *)this + 3232); /*0x1039c3fa8*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 3232)); /*0x1039c3fb2*/
  ++*((_DWORD *)this + 805); /*0x1039c3fb7*/
  RakNet::SimpleMutex::Unlock(this: v15); /*0x1039c3fc1*/
  if ( a3 >= 0x6B && a3 + a7 + 40 > 0x23F )
  {
    *(_WORD *)v94 = 0; /*0x1039c3fe7*/
    *(_OWORD *)v87 = 0; /*0x1039c3ff3*/
    RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v104, a2, a3, a4: false); /*0x1039c4008*/
    RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v104, a2: 0x11u); /*0x1039c4019*/
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v104, a2: &v90, a3: 8u, a4: true); /*0x1039c4036*/
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v104, a2: &v97, a3: 8u, a4: true); /*0x1039c4053*/
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c5200*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v73); /*0x1039c520b*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c5218*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c406d*/
    {
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v104, a2: v92, a3: 0x10u, a4: true); /*0x1039c4087*/
    }
    else if ( (unsigned __int8)RakNet::BitStream::ReadBits( /*0x1039c40f0*/
                                 this: (RakNet::BitStream *)v104,
                                 a2: (unsigned __int8 *)v75,
                                 a3: 0x10u,
                                 a4: true) != 0 )
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v75, a2: v92, a3: (unsigned __int8 *)2, a4: v19); /*0x1039c4105*/
    }
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c5230*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v74); /*0x1039c523b*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c5248*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c411f*/
    {
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v104, a2: v94, a3: 0x10u, a4: true); /*0x1039c4139*/
    }
    else if ( (unsigned __int8)RakNet::BitStream::ReadBits( /*0x1039c415f*/
                                 this: (RakNet::BitStream *)v104,
                                 a2: (unsigned __int8 *)v75,
                                 a3: 0x10u,
                                 a4: true) != 0 )
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v75, a2: v94, a3: (unsigned __int8 *)2, a4: v20); /*0x1039c4174*/
    }
    RakNet::BitStream::ReadAlignedBytes(this: (RakNet::BitStream *)v104, a2: v111, a3: 0x20u); /*0x1039c4189*/
    if ( FFlag::DebugLocalRccServerConnection == 1 && FFlag::DebugLocalRccTicketTesting == 1 ) /*0x1039c41a2*/
    {
      v75[0] = 0; /*0x1039c41af*/
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v104, a2: (unsigned __int8 *)v75, a3: 8u, a4: true); /*0x1039c41c3*/
      std::string::resize(a1: &RBX::Http::gameID, a2: (unsigned __int8)v75[0], a3: 0); /*0x1039c41db*/
      if ( (RBX::Http::gameID & 1) != 0 ) /*0x1039c41e6*/
      {
        v21 = DWORD2(RBX::Http::gameID); /*0x1039c41e8*/
        v22 = (unsigned __int8 *)qword_10D783240; /*0x1039c41eb*/
      }
      else
      {
        v21 = (unsigned __int8)RBX::Http::gameID >> 1; /*0x1039c41f1*/
        v22 = (unsigned __int8 *)&RBX::Http::gameID + 1; /*0x1039c41f3*/
      }
      RakNet::BitStream::ReadAlignedBytes(this: (RakNet::BitStream *)v104, a2: v22, a3: v21); /*0x1039c4200*/
      (*(void (__fastcall **)(RakNet::RakPeer *, __int128 *))(*(_QWORD *)this + 872LL))( /*0x1039c4212*/
        a1: this,
        a2: &RBX::Http::gameID);
      if ( RBX::debugLocalRccTicketCallback != nullptr ) /*0x1039c4225*/
        RBX::debugLocalRccTicketCallback(a1: &RBX::Http::gameID); /*0x1039c422e*/
    }
    v23 = (_OWORD *)operator new(a1: 0x38u); /*0x1039c4235*/
    v23[2] = 0; /*0x1039c423d*/
    v23[1] = 0; /*0x1039c4241*/
    *v23 = 0; /*0x1039c4245*/
    std::shared_ptr<RBX::Security::EarlyAuthData>::reset[abi:ne200100]<RBX::Security::EarlyAuthData,0>(a1: v87, a2: v23); /*0x1039c4252*/
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v104, a2: (unsigned __int8 *)v87[0] + 48, a3: 8u, a4: true); /*0x1039c4273*/
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v104, a2: v103, a3: 8u, a4: true); /*0x1039c4290*/
    std::string::resize(a1: v87[0], a2: v103[0], a3: 0); /*0x1039c42a5*/
    if ( (*(_BYTE *)v87[0] & 1) != 0 ) /*0x1039c42b4*/
      v24 = *((unsigned __int8 **)v87[0] + 2); /*0x1039c42bb*/
    else
      v24 = (unsigned __int8 *)v87[0] + 1; /*0x1039c42b6*/
    RakNet::BitStream::ReadAlignedBytes(this: (RakNet::BitStream *)v104, a2: v24, a3: v103[0]); /*0x1039c42cd*/
    v25 = *(unsigned __int8 *)v87[0]; /*0x1039c42d9*/
    if ( (v25 & 1) != 0 ) /*0x1039c42df*/
    {
      v26 = *((_QWORD *)v87[0] + 1); /*0x1039c42e1*/
      v27 = *((char **)v87[0] + 2); /*0x1039c42e5*/
    }
    else
    {
      v27 = (char *)v87[0] + 1; /*0x1039c42eb*/
      v26 = v25 >> 1; /*0x1039c42ee*/
    }
    v32 = RakNet::RakPeer::verifyPreauthMac(a1: this, a2: v27, a3: v26, a4: 0); /*0x1039c42fa*/
    switch ( v32 ) /*0x1039c430d*/
    {
      case 0: /*0x1039c430d*/
        std::string::basic_string[abi:ne200100]<0>(a1: v75, a2: "Preauth-Fail", a3: v28, a4: v29); /*0x1039c431d*/
        RBX::Analytics::EphemeralCounter::reportCounter(a1: v75, a2: 1, a3: 0); /*0x1039c4330*/
        if ( (v75[0] & 1) != 0 ) /*0x1039c433c*/
          operator delete(a1: v76[0]); /*0x1039c4345*/
        if ( FFlag::DebugLocalRccServerConnection == 1 && FFlag::DebugLocalRccTicketTesting == 0 ) /*0x1039c435e*/
          break; /*0x1039c435e*/
        goto LABEL_45; /*0x1039c435e*/
      case 1: /*0x1039c430d*/
        std::string::basic_string[abi:ne200100]<0>(a1: v75, a2: "Preauth-Pass", a3: v28, a4: v29); /*0x1039c4373*/
        RBX::Analytics::EphemeralCounter::reportCounter(a1: v75, a2: 1, a3: 0); /*0x1039c4386*/
        goto LABEL_37; /*0x1039c438b*/
      case 2: /*0x1039c430d*/
        std::string::basic_string[abi:ne200100]<0>(a1: v75, a2: "Preauth-Failover", a3: v28, a4: v29); /*0x1039c439b*/
        RBX::Analytics::EphemeralCounter::reportCounter(a1: v75, a2: 1, a3: 0); /*0x1039c43ae*/
LABEL_37:
        if ( (v75[0] & 1) != 0 ) /*0x1039c43ba*/
          operator delete(a1: v76[0]); /*0x1039c43c3*/
        break; /*0x1039c43c3*/
      case 3: /*0x1039c430d*/
        break;
    }
    if ( DWORD1(v105) >> 3 != v97 ) /*0x1039c43da*/
    {
      if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c4445*/
        FLog::FastLogFormatted( /*0x1039c445c*/
          a1: DFLog::SessionCrypto,
          a2: qword_10D7BB210,
          a3: (unsigned int)"[DFLog::SessionCrypto] RbxOpenRequest2 unexpected aad size %d.",
          a4: v97,
          a5: v30,
          a6: v31);
LABEL_45:
      RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v104); /*0x1039c4461*/
      goto LABEL_46; /*0x1039c4468*/
    }
    RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v104); /*0x1039c43e3*/
    v35 = v97; /*0x1039c43e8*/
    if ( v97 <= 0x34u ) /*0x1039c43f2*/
    {
      if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c440d*/
      {
        LODWORD(v18) = 0; /*0x1039c4414*/
        FLog::FastLogFormatted( /*0x1039c4429*/
          a1: DFLog::SessionCrypto,
          a2: qword_10D7BB210,
          a3: (unsigned int)"[DFLog::SessionCrypto] RbxOpenRequest2 unexpected aad size %d.",
          a4: v97,
          a5: v33,
          a6: v34);
LABEL_47:
        v36 = v87[1]; /*0x1039c4470*/
        if ( v87[1] != nullptr /*0x1039c448c*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v87[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v36 + 16LL))(a1: v36); /*0x1039c4494*/
          std::__shared_weak_count::__release_weak(this: v36); /*0x1039c449a*/
        }
        return (unsigned int)v18; /*0x1039c449a*/
      }
LABEL_46:
      LODWORD(v18) = 0; /*0x1039c446d*/
      goto LABEL_47; /*0x1039c446d*/
    }
    v81 = *(unsigned __int16 *)v92; /*0x1039c44cf*/
    v38 = *(_OWORD *)a4; /*0x1039c44d6*/
    v105 = *((_OWORD *)a4 + 1); /*0x1039c44e6*/
    *(_OWORD *)v104 = v38; /*0x1039c44ea*/
    if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: v104, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 /*0x1039c4533*/
      || (RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, a2: (const RakNet::SystemAddress *)v104)) == -1
      || (v40 = *((_QWORD *)this + 92),
          v42 = 5368LL * RemoteSystemIndex,
          LOBYTE(v40) = *(_BYTE *)(v40 + v42),
          (v40 & 1) == 0)
      || (v40 = *((_QWORD *)this + 92)) == 0 )
    {
      v86 = nullptr; /*0x1039c4545*/
      v42 = 0; /*0x1039c4550*/
    }
    else
    {
      v39 = (char *)(v40 + v42); /*0x1039c4535*/
      v86 = (RakNet::RakPeer::RemoteSystemStruct *)(v40 + v42); /*0x1039c4539*/
      LOBYTE(v42) = *(_BYTE *)(v40 + v42); /*0x1039c4540*/
    }
    v91 = (RakNet::RakPeer::RemoteSystemStruct *)v42; /*0x1039c4552*/
    if ( (v42 & 1) != 0 || v32 != 3 ) /*0x1039c4561*/
    {
      if ( v32 == 3 ) /*0x1039c45b2*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: v104, a2: "Preauth-Dupe-Drop", a3: v39, a4: v40); /*0x1039c45c6*/
        RBX::Analytics::EphemeralCounter::reportCounter(a1: v104, a2: 1, a3: 0); /*0x1039c45d9*/
        if ( (v104[0] & 1) != 0 ) /*0x1039c45e5*/
          operator delete(a1: (void *)v105); /*0x1039c45ee*/
      }
    }
    else
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v104, a2: "Preauth-Dupe", a3: v39, a4: v40); /*0x1039c4571*/
      RBX::Analytics::EphemeralCounter::reportCounter(a1: v104, a2: 1, a3: 0); /*0x1039c4584*/
      if ( (v104[0] & 1) != 0 ) /*0x1039c4590*/
        operator delete(a1: (void *)v105); /*0x1039c4599*/
      v43 = *((unsigned __int8 *)this + 3040); /*0x1039c459e*/
      if ( (v43 & 1) != 0 ) /*0x1039c45a8*/
        v44 = *((_QWORD *)this + 381); /*0x1039c45f5*/
      else
        v44 = v43 >> 1; /*0x1039c45aa*/
      if ( v44 != 0 ) /*0x1039c45ff*/
      {
        if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c4616*/
        {
          LODWORD(v18) = 0; /*0x1039c4621*/
          FLog::FastLog( /*0x1039c4634*/
            a1: DFLog::SessionCrypto,
            a2: qword_10D7BB210,
            a3: "[DFLog::SessionCrypto] RbxOpenRequest2 mac was previously used but did not create active rss",
            0);
          goto LABEL_47; /*0x1039c4639*/
        }
        goto LABEL_46; /*0x1039c461b*/
      }
    }
    *(_OWORD *)v89 = 0; /*0x1039c4641*/
    if ( ((unsigned __int8)v91 & 1) != 0 ) /*0x1039c464f*/
    {
      std::shared_ptr<RBX::Security::RakPeerCrypto>::operator=[abi:ne200100](a1: v89, a2: (char *)v86 + 392); /*0x1039c4666*/
    }
    else
    {
      v45 = (RBX::Security::SessionCrypto *)operator new(a1: 0x80u); /*0x1039c467a*/
      RBX::Security::SessionCrypto::SessionCrypto(this: v45); /*0x1039c4680*/
      *(_QWORD *)v45 = off_10C903070; /*0x1039c468c*/
      std::shared_ptr<RBX::Security::RakPeerCrypto>::reset[abi:ne200100]<RBX::Security::RakPeerCrypto,0>( /*0x1039c469a*/
        a1: v89,
        a2: v45);
      v46 = *((_BYTE *)this + 3088); /*0x1039c46ab*/
      if ( v46 != (*(unsigned __int16 *)v94 != 0) ) /*0x1039c46b4*/
      {
        if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c499b*/
        {
          v50 = "local"; /*0x1039c49b0*/
          if ( v46 != 0 ) /*0x1039c49b9*/
            v50 = "Roblox"; /*0x1039c49b9*/
          FLog::FastLogS( /*0x1039c49c4*/
            this: (FLog *)DFLog::SessionCrypto,
            a2: qword_10D7BB210,
            a3: (unsigned __int64)"[DFLog::SessionCrypto] RbxOpenRequest2 key exchange version incorrect for connecting to %s server",
            a4: v50);
        }
        goto LABEL_89; /*0x1039c49c4*/
      }
      RBX::Security::RakPeerCrypto::getServerDualKeyInfo( /*0x1039c46c1*/
        this: (RBX::Security::RakPeerCrypto *)v104,
        a2: *(unsigned __int16 *)v94);
      *(_QWORD *)v75 = v106; /*0x1039c46f6*/
      *(_QWORD *)&v75[8] = v107 - v106; /*0x1039c4707*/
      *(_QWORD *)v103 = v108; /*0x1039c4715*/
      *(_QWORD *)&v103[8] = v109 - v108; /*0x1039c4726*/
      RBX::Security::RakPeerCrypto::initServer_DualPair( /*0x1039c4744*/
        this: v89[0],
        a2: v106,
        a3: v107 - v106,
        a4: v108,
        a5: v109 - v108);
      RBX::Security::RakPeerCrypto::serverInitEarlySessionKeys_DualPair(this: v89[0]); /*0x1039c4759*/
      std::pair<std::pair<std::vector<unsigned char>,std::vector<unsigned char>>,std::pair<std::vector<unsigned char>,std::vector<unsigned char>>>::~pair(a1: v104); /*0x1039c4765*/
    }
    if ( v89[0] != nullptr )
    {
      RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v110, a2, a3: v35 + v81 + 28, a4: false); /*0x1039c4791*/
      if ( (unsigned __int8)RBX::Security::RakPeerCrypto::earlyDecryptData( /*0x1039c47b2*/
                              this: v89[0],
                              a2: (RakNet::BitStream *)v110,
                              a3: v97) == 0 )
      {
        RakNet::SystemAddress::ToStringN(this: a4, a2: false, a3: v104, a4: 1025, a5: 124); /*0x1039c49e8*/
        if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c4a02*/
          FLog::FastLogS( /*0x1039c4a1e*/
            this: (FLog *)DFLog::SessionCrypto,
            a2: qword_10D7BB210,
            a3: (unsigned __int64)"[DFLog::SessionCrypto] RbxOpenRequest2 decrypt failed for %s",
            a4: v104);
        LODWORD(v18) = 0; /*0x1039c4a23*/
        goto LABEL_126; /*0x1039c4a26*/
      }
      v47 = *((_QWORD *)this + 423); /*0x1039c47b8*/
      if ( v47 != 0 ) /*0x1039c47c2*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v47 + 40LL))(a1: v47); /*0x1039c47c7*/
      RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v110, a2: v97); /*0x1039c47d8*/
      CapabilitiesIfAny = readCapabilitiesIfAny(this: (RakNet::BitStream *)v110); /*0x1039c47e9*/
      *(_QWORD *)v104 = &off_10C443EC0; /*0x1039c47fa*/
      v18 = off_10C8C8838; /*0x1039c4804*/
      RBX::Telemetry::RobloxTelemetryCommon::RobloxTelemetryCommon<(RBX::Telemetry::TelemetryBackend)16>( /*0x1039c4812*/
        a1: v104,
        a2: off_10C8C8838,
        a3: &RBX::Telemetry::kServerIsSendingRupp);
      *(_QWORD *)v104 = &off_10C8C87E8; /*0x1039c4829*/
      LODWORD(v108) = 1; /*0x1039c482c*/
      RBX::Telemetry::RobloxTelemetryEphemeralCounter::send(this: (RBX::Telemetry::RobloxTelemetryEphemeralCounter *)v104); /*0x1039c4833*/
      RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: (void **)v104, a2: (void **)off_10C8C8838); /*0x1039c4842*/
      RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)v85); /*0x1039c484e*/
      RakNet::BitStream::Read<RakNet::RakNetGUID>(this: (RakNet::BitStream *)v110, a2: v85); /*0x1039c4861*/
      RakNet::BitStream::Read<unsigned short>(this: (RakNet::BitStream *)v110, a2: v93); /*0x1039c4874*/
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v110, a2: &v98, a3: 8u, a4: true); /*0x1039c4891*/
      RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v78); /*0x1039c489d*/
      RakNet::BitStream::Read<RakNet::SystemAddress>(this: (RakNet::BitStream *)v110); /*0x1039c48b0*/
      if ( FFlag::DebugLocalRccServerConnection == 1 && FFlag::DebugLocalRccRuppToken == 1 ) /*0x1039c48c5*/
      {
        RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v104); /*0x1039c48ce*/
        RakNet::BitStream::Read<RakNet::SystemAddress>(this: (RakNet::BitStream *)v110); /*0x1039c48e1*/
        (*(void (__fastcall **)(RakNet::RakPeer *, char *))(*(_QWORD *)this + 824LL))(a1: this, a2: v104); /*0x1039c48f3*/
      }
      v95 = 0; /*0x1039c4900*/
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v110, a2: &v95, a3: 8u, a4: true); /*0x1039c4914*/
      std::string::resize(a1: (char *)v87[0] + 24, a2: v95, a3: 0); /*0x1039c492d*/
      if ( (*((_BYTE *)v87[0] + 24) & 1) != 0 ) /*0x1039c493d*/
        v49 = *((unsigned __int8 **)v87[0] + 5); /*0x1039c4a2b*/
      else
        v49 = (unsigned __int8 *)v87[0] + 25; /*0x1039c4943*/
      RakNet::BitStream::ReadAlignedBytes(this: (RakNet::BitStream *)v110, a2: v49, a3: v95); /*0x1039c4a3d*/
      std::shared_ptr<RBX::Security::EarlyAuthData>::operator=[abi:ne200100](a1: (char *)v89[0] + 48, a2: v87); /*0x1039c4a54*/
      if ( *(unsigned __int16 *)v93 <= 0x23Fu ) /*0x1039c4a66*/
      {
        LODWORD(v18) = 0; /*0x1039c4b95*/
        if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c4b92*/
          FLog::FastLogFormatted( /*0x1039c4bb0*/
            a1: DFLog::SessionCrypto,
            a2: qword_10D7BB210,
            a3: (unsigned int)"[DFLog::SessionCrypto] RbxOpenRequest2 invalide mtu %d.",
            a4: *(unsigned __int16 *)v93,
            a5: v51,
            a6: v52);
        goto LABEL_126; /*0x1039c4bb5*/
      }
      *(_QWORD *)v104 = 0; /*0x1039c4a73*/
      RakNet::buildCapabilitiesHelper(a1: v104, a2: 1); /*0x1039c4a7f*/
      v53 = CapabilitiesIfAny & *(_QWORD *)v104; /*0x1039c4a8b*/
      RBX::Analytics::InfluxDb::Points::Points(a1: v103, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1039c4a9e*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039c4ab4*/
        this: (RBX::Analytics::InfluxDb::Points *)v103,
        a2: "NegotiatedCapabilityBit",
        a3: v53);
      std::string::basic_string[abi:ne200100]<0>(a1: v104, a2: "RakNetCapabilityBitNegotiated", a3: v54, a4: v55); /*0x1039c4ac7*/
      RBX::Analytics::InfluxDb::Points::report( /*0x1039c4ae2*/
        a1: v103,
        a2: v104,
        a3: (unsigned int)DFInt::NetworkCapBitReportPerMyriad,
        a4: 0);
      if ( (v104[0] & 1) != 0 ) /*0x1039c4aee*/
        operator delete(a1: (void *)v105); /*0x1039c4af7*/
      RemoteSystemFromGUID = (RakNet::RakPeer::RemoteSystemStruct *)RakNet::RakPeer::GetRemoteSystemFromGUID( /*0x1039c4b11*/
                                                                      a1: (__int64)this,
                                                                      a2: *(__int64 *)v85,
                                                                      a3: *(__int16 *)&v85[8],
                                                                      a4: 1);
      if ( RemoteSystemFromGUID != nullptr ) /*0x1039c4b21*/
      {
        v58 = *(_BYTE *)RemoteSystemFromGUID; /*0x1039c4b27*/
        if ( (*(_BYTE *)RemoteSystemFromGUID & (unsigned __int8)v91 & 1) != 0 ) /*0x1039c4b35*/
        {
          if ( v86 == RemoteSystemFromGUID && *((_DWORD *)v86 + 1341) == 6 ) /*0x1039c4b52*/
          {
            LODWORD(v18) = RakNet::RakPeer::sendRbxOpenReply2(this, a2: v86, a3: a11); /*0x1039c4b75*/
LABEL_125:
            RBX::Analytics::InfluxDb::Points::~Points(this: (void **)v103); /*0x1039c4e5e*/
LABEL_126:
            RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v110); /*0x1039c4e6a*/
            goto LABEL_127; /*0x1039c4e71*/
          }
          goto LABEL_120; /*0x1039c4b52*/
        }
        v59 = v58 ^ 1; /*0x1039c4bc2*/
      }
      else
      {
        v59 = 1; /*0x1039c4bba*/
        v58 = 0; /*0x1039c4bbc*/
      }
      if ( ((unsigned __int8)v91 & 1) != 0 ) /*0x1039c4bd1*/
        v59 = v58; /*0x1039c4bd1*/
      if ( (v59 & 1) == 0 ) /*0x1039c4bd6*/
      {
LABEL_120:
        if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c4de1*/
          FLog::FastLog( /*0x1039c4dfa*/
            a1: DFLog::SessionCrypto,
            a2: qword_10D7BB210,
            a3: "[DFLog::SessionCrypto] RbxOpenRequest2 already connected",
            0,
            v57,
            a10);
LABEL_124:
        LOBYTE(v18) = 1; /*0x1039c4e34*/
        RakNet::RakPeer::sendRbxOpenError(this, a2: 1); /*0x1039c4e59*/
        goto LABEL_125; /*0x1039c4e59*/
      }
      LODWORD(v18) = RakNet::RakPeer::GetNumberOfRemoteInitiatedConnections(this); /*0x1039c4be4*/
      if ( (unsigned __int16)v18 >= (*(unsigned __int16 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 72LL))(a1: this) ) /*0x1039c4bf4*/
      {
        if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c4e16*/
          FLog::FastLog( /*0x1039c4e2f*/
            a1: DFLog::SessionCrypto,
            a2: qword_10D7BB210,
            a3: "[DFLog::SessionCrypto] RbxOpenRequest2 no free incoming connections",
            0);
        goto LABEL_124; /*0x1039c4e2f*/
      }
      v96 = 0; /*0x1039c4bfa*/
      v60 = *(_OWORD *)a4; /*0x1039c4c01*/
      v105 = *((_OWORD *)a4 + 1); /*0x1039c4c0a*/
      *(_OWORD *)v104 = v60; /*0x1039c4c11*/
      v61 = *((_QWORD *)v88 + 1); /*0x1039c4c1f*/
      v82 = *v88; /*0x1039c4c26*/
      if ( v61 != 0 ) /*0x1039c4c30*/
        _InterlockedIncrement64((volatile signed __int64 *)(v61 + 8)); /*0x1039c4c32*/
      *(_OWORD *)v76 = *(_OWORD *)&v78[2]; /*0x1039c4c49*/
      *(_OWORD *)v75 = *(_OWORD *)v78; /*0x1039c4c50*/
      v62 = *(unsigned __int16 *)v93; /*0x1039c4c57*/
      *(_OWORD *)v101 = *(_OWORD *)v85; /*0x1039c4c66*/
      *(_OWORD *)v83 = *(_OWORD *)v89; /*0x1039c4c7b*/
      v18 = (__int64 (__fastcall ***)())a11; /*0x1039c4c85*/
      if ( v89[1] != nullptr ) /*0x1039c4c89*/
        _InterlockedIncrement64((volatile signed __int64 *)v89[1] + 1); /*0x1039c4c8b*/
      v91 = (RakNet::RakPeer::RemoteSystemStruct *)RakNet::RakPeer::AssignSystemAddressToRemoteSystemList( /*0x1039c4d07*/
                                                     this,
                                                     a2: 6,
                                                     a3: (__int64)&v82,
                                                     a4: (RakNet::ReliabilityLayer *)&v96,
                                                     a5: v62,
                                                     a6: false,
                                                     a7: *(__int128 *)v104,
                                                     a8: v105,
                                                     a9: v75[0],
                                                     a10: *(int *)&v75[8],
                                                     a11: (int)v76[0],
                                                     a12: (int)v76[1],
                                                     a13: *(__int64 *)v101,
                                                     a14: *(__int16 *)&v101[8],
                                                     a15: v53,
                                                     a16: (__int64)v83,
                                                     a17: a8,
                                                     a18: a9,
                                                     a19: a11);
      std::shared_ptr<RBX::Security::RakPeerCrypto>::~shared_ptr[abi:ne200100](a1: v83); /*0x1039c4d15*/
      std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: &v82); /*0x1039c4d21*/
      if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
        FLog::FastLogFormatted(
          a1: DFLog::NetworkTrace,
          a2: qword_10D7BB068,
          a3: (unsigned int)"[DFLog::NetworkTrace] Peer has capabilities: 0x%llx ,common capabilities: 0x%llx",
          a4: CapabilitiesIfAny,
          a5: v53,
          a6: v63);
      if ( v96 == 1 ) /*0x1039c4d64*/
      {
        if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c4d7f*/
          FLog::FastLog( /*0x1039c4d96*/
            a1: DFLog::SessionCrypto,
            a2: qword_10D7BB210,
            a3: "[DFLog::SessionCrypto] RbxOpenRequest2 recently connected",
            0);
        goto LABEL_124; /*0x1039c4d96*/
      }
      RBX::Security::RakPeerCrypto::serverInitEphemeralSessionKeys(this: v89[0]); /*0x1039c4eb9*/
      if ( (unsigned __int8)RBX::Security::SessionCrypto::isAesGcm(a1: v98) != 0 /*0x1039c4edc*/
        && (unsigned __int8)RBX::Security::SessionCrypto::getSupportAes(this: v89[0]) == 0 )
      {
        v98 = 1; /*0x1039c4ede*/
      }
      v65 = v98 & 0x7F; /*0x1039c4eeb*/
      v98 &= ~0x80u; /*0x1039c4eed*/
      if ( v98 == 0 ) /*0x1039c4ef3*/
      {
        if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c508d*/
          FLog::FastLog( /*0x1039c50a4*/
            a1: DFLog::SessionCrypto,
            a2: qword_10D7BB210,
            a3: "[DFLog::SessionCrypto] RbxOpenRequest2 desired encryption is unset",
            0);
        RakNet::RakPeer::sendRbxOpenError(this, a2: 1); /*0x1039c50cd*/
        LODWORD(v18) = 0; /*0x1039c50d2*/
        goto LABEL_125; /*0x1039c50d5*/
      }
      RBX::Security::SessionCrypto::setRakCryptoFormat(a1: v89[0], a2: v65); /*0x1039c4f03*/
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1039c4f16*/
        a1: v75,
        a2: (__int64)&RBX::Telemetry::kCryptoSessionSelectedCounter);
      isAesGcm = RBX::Security::SessionCrypto::isAesGcm(a1: v98); /*0x1039c4f22*/
      v67 = "chacha-poly"; /*0x1039c4f39*/
      if ( isAesGcm != 0 ) /*0x1039c4f42*/
        v67 = "aes-gcm"; /*0x1039c4f42*/
      RBX::Telemetry::FieldsContainer::addField(a1: v77, a2: "cipher", a3: 6, a4: v67, a5: 1); /*0x1039c4f58*/
      RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v75); /*0x1039c4f64*/
      if ( (_BYTE)DFLog::RakNetConnectTrace != 0 ) /*0x1039c4f70*/
      {
        RakNet::SystemAddress::ToStringN(this: a4, a2: true, a3: v104, a4: 1025, a5: 124); /*0x1039c4f8c*/
        if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u ) /*0x1039c4fa6*/
          FLog::FastLogS( /*0x1039c4fc2*/
            this: DFLog::RakNetConnectTrace,
            a2: qword_10D7BB0C8,
            a3: (unsigned __int64)"[DFLog::RakNetConnectTrace] Received RbxOpenRequest2 from %s",
            a4: v104);
      }
      if ( (*(unsigned __int8 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 784LL))(a1: this) == 0 ) /*0x1039c4fd5*/
      {
LABEL_153:
        if ( DFFlag::RuppTokenOneBeeRcc == 0 ) /*0x1039c51a2*/
          *((_BYTE *)v91 + 5265) = 9; /*0x1039c51ab*/
        LODWORD(v18) = RakNet::RakPeer::sendRbxOpenReply2(this, a2: v91, a3: (__int64)v18); /*0x1039c51d9*/
        RBX::Telemetry::RobloxTelemetryCounter::~RobloxTelemetryCounter(this: (RBX::Telemetry::RobloxTelemetryCounter *)v75); /*0x1039c51e3*/
        goto LABEL_125; /*0x1039c51e8*/
      }
      RBX::make_shared<RBX::Rupp::Rupp>(a1: v104); /*0x1039c4fe2*/
      v68 = v91; /*0x1039c4fe7*/
      v69 = (RBX::Rupp::Rupp **)((char *)v91 + 5280); /*0x1039c4fee*/
      std::shared_ptr<RBX::Rupp::Rupp>::operator=[abi:ne200100](a1: (char *)v91 + 5280, a2: v104); /*0x1039c5002*/
      std::shared_ptr<RBX::Rupp::Rupp>::~shared_ptr[abi:ne200100](a1: v104); /*0x1039c500a*/
      *(_OWORD *)v101 = 0; /*0x1039c5019*/
      v102 = 0; /*0x1039c501c*/
      RBX::Rupp::Rupp::addTokenTlv(a1: *((_QWORD *)v68 + 660), a2: v101); /*0x1039c5027*/
      v70 = *((_QWORD *)v91 + 660); /*0x1039c5033*/
      v99[0] = off_10C903288; /*0x1039c5048*/
      v99[1] = this; /*0x1039c504c*/
      v99[2] = v91; /*0x1039c5050*/
      v100 = v99; /*0x1039c5054*/
      RBX::Rupp::Rupp::addTokenGenerator(a1: v70, a2: v99); /*0x1039c505b*/
      if ( v100 == v99 ) /*0x1039c506a*/
      {
        v71 = 32; /*0x1039c50da*/
      }
      else
      {
        v71 = 40; /*0x1039c506c*/
        if ( v100 == nullptr ) /*0x1039c5074*/
          goto LABEL_148; /*0x1039c5074*/
      }
      (*(void (**)(void))(*v100 + v71))(); /*0x1039c50e2*/
LABEL_148:
      if ( (*(_BYTE *)(a11 + 3) & 1) != 0 )
      {
        RBX::Rupp::Rupp::addIpv4ReverseEndpointTlv(this: *v69, a2: (const char *)(a11 + 24), a3: *(_WORD *)(a11 + 70)); /*0x1039c5102*/
        if ( (unsigned __int8)DFLog::Rupp >= 6u && BYTE1(DFLog::Rupp) >= 6u )
        {
          v72 = *(unsigned __int16 *)(a11 + 70); /*0x1039c512e*/
          *(_QWORD *)v104 = a11 + 24; /*0x1039c5132*/
          *(_QWORD *)&v105 = v72; /*0x1039c5139*/
          v79 = 44; /*0x1039c5140*/
          v80 = v104; /*0x1039c514b*/
          FLog::detail::FastLogSafeFormattedInternal(
            a1: DFLog::Rupp,
            a2: qword_10D7BB258,
            a3: 6,
            a4: (unsigned int)"[DFLog::Rupp] OpenRequest2 received with reverse endpoint: {} | {}",
            a5: 66,
            a6: 1,
            44,
            v104);
        }
        RakNet::SystemAddress::operator=(a1: (char *)v91 + 4552, a2: a4); /*0x1039c518b*/
      }
      v18 = (__int64 (__fastcall ***)())a11; /*0x1039c5194*/
      goto LABEL_153; /*0x1039c5194*/
    }
    if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c4961*/
    {
      LODWORD(v18) = 0; /*0x1039c4968*/
      FLog::FastLog( /*0x1039c497b*/
        a1: DFLog::SessionCrypto,
        a2: qword_10D7BB210,
        a3: "[DFLog::SessionCrypto] RbxOpenRequest2 no session crypto",
        0);
LABEL_127:
      v64 = v89[1]; /*0x1039c4e76*/
      if ( v89[1] != nullptr /*0x1039c4e96*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v89[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v64 + 16LL))(a1: v64); /*0x1039c4ea2*/
        std::__shared_weak_count::__release_weak(this: v64); /*0x1039c4ea8*/
      }
      goto LABEL_47; /*0x1039c4ead*/
    }
LABEL_89:
    LODWORD(v18) = 0; /*0x1039c49c9*/
    goto LABEL_127; /*0x1039c49cc*/
  }
  LODWORD(v18) = 0; /*0x1039c40b8*/
  if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c40a3*/
    FLog::FastLogFormatted( /*0x1039c40bf*/
      a1: DFLog::SessionCrypto,
      a2: qword_10D7BB210,
      a3: (unsigned int)"[DFLog::SessionCrypto] RbxOpenRequest2 has invalid size %d.",
      a4: a3,
      a5: v16,
      a6: v17);
  return (unsigned int)v18; /*0x1039c44b6*/
}

// Address: 0x1039c5404 | Name: __ZN6RakNet7RakPeer20processRbxOpenReply2EPKhmRKNS_13SystemAddressERNSt3__110shared_ptrINS_12RakNetSocketEEEy
__int64 __fastcall RakNet::RakPeer::processRbxOpenReply2(
        RakNet::RakPeer *this,
        unsigned __int8 *a2,
        unsigned __int64 a3,
        RakNet::SystemAddress *a4,
        RakNet::SimpleMutex *a5,
        void *a6)
{
  RakNet::SimpleMutex *v10; // r14
  int v11; // r8d
  int v12; // r9d
  __int64 RequestedConnectionStruct; // rax
  __int64 v14; // r14
  unsigned int v15; // ecx
  __int64 v16; // rdi
  unsigned int v17; // ecx
  unsigned int v18; // ecx
  int v19; // r12d
  int v20; // r13d
  int v21; // r9d
  __int64 v22; // rdx
  __int64 v23; // rcx
  __int64 v24; // rsi
  __int64 v25; // r8
  __int64 v26; // r9
  __int128 v27; // xmm0
  unsigned int RemoteSystemIndex; // eax
  __int64 v29; // rax
  __int64 v30; // r13
  __int64 v31; // r13
  RakNet::SimpleMutex *v32; // rcx
  __int128 v33; // xmm0
  __int64 v34; // rax
  int v35; // r8d
  __int64 v36; // rax
  unsigned int v37; // esi
  unsigned int i; // r13d
  unsigned int v39; // eax
  unsigned int v40; // edx
  bool v41; // cf
  unsigned int v42; // edx
  unsigned int v43; // edx
  char *v44; // rbx
  RakNet::BitStream *v46; // rdi
  RakNet::BitStream *v47; // rdi
  RakNet::BitStream *v48; // rdi
  char v49[16]; // [rsp+80h] [rbp-660h]
  char v50[16]; // [rsp+A0h] [rbp-640h] BYREF
  int v51[4]; // [rsp+B0h] [rbp-630h]
  unsigned __int8 v52[16]; // [rsp+C0h] [rbp-620h] BYREF
  __int128 v53; // [rsp+D0h] [rbp-610h]
  __int128 v54; // [rsp+E0h] [rbp-600h] BYREF
  __int64 v55[2]; // [rsp+F0h] [rbp-5F0h] BYREF
  unsigned __int8 v56[16]; // [rsp+100h] [rbp-5E0h] BYREF
  __int128 v57; // [rsp+110h] [rbp-5D0h]
  unsigned __int8 v58[16]; // [rsp+120h] [rbp-5C0h] BYREF
  RakNet::SimpleMutex *v59; // [rsp+130h] [rbp-5B0h]
  void *v60; // [rsp+138h] [rbp-5A8h]
  _QWORD *v61; // [rsp+140h] [rbp-5A0h]
  __int64 CapabilitiesIfAny; // [rsp+148h] [rbp-598h]
  unsigned __int8 v63; // [rsp+157h] [rbp-589h] BYREF
  unsigned __int8 v64[2]; // [rsp+158h] [rbp-588h] BYREF
  unsigned __int8 v65[2]; // [rsp+15Ah] [rbp-586h] BYREF
  unsigned __int8 v66; // [rsp+15Dh] [rbp-583h] BYREF
  unsigned __int8 v67; // [rsp+15Eh] [rbp-582h] BYREF
  char v68; // [rsp+15Fh] [rbp-581h] BYREF
  _BYTE v69[40]; // [rsp+160h] [rbp-580h] BYREF
  __int128 v70; // [rsp+188h] [rbp-558h]
  __int128 v71; // [rsp+198h] [rbp-548h]
  char v72; // [rsp+1A8h] [rbp-538h]
  unsigned __int8 v73[23]; // [rsp+1A9h] [rbp-537h] BYREF
  unsigned __int8 v74[32]; // [rsp+568h] [rbp-178h] BYREF
  unsigned __int8 v75[296]; // [rsp+588h] [rbp-158h] BYREF

  v60 = a6; /*0x1039c5418*/
  v59 = a5; /*0x1039c541f*/
  v10 = (RakNet::RakPeer *)((char *)this + 3232); /*0x1039c5440*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 3232)); /*0x1039c544a*/
  ++*((_DWORD *)this + 807); /*0x1039c544f*/
  RakNet::SimpleMutex::Unlock(this: v10); /*0x1039c5459*/
  if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
    FLog::FastLog(
      a1: DFLog::RakNetConnectTrace,
      a2: qword_10D7BB0C8,
      a3: "[DFLog::RakNetConnectTrace] RakNet: OpenReply2 received",
      0);
  if ( a3 <= 0x6A ) /*0x1039c5493*/
  {
    LODWORD(a2) = 0; /*0x1039c54c3*/
    if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c54aa*/
      FLog::FastLogFormatted( /*0x1039c54cb*/
        a1: DFLog::SessionCrypto,
        a2: qword_10D7BB210,
        a3: (unsigned int)"[DFLog::SessionCrypto] RbxOpenReply2 invalid size %d.",
        a4: a3,
        a5: v11,
        a6: v12);
    return (unsigned int)a2; /*0x1039c54d0*/
  }
  RequestedConnectionStruct = RakNet::RakPeer::findRequestedConnectionStruct(this, a2: a4); /*0x1039c54db*/
  if ( RequestedConnectionStruct != 0 )
  {
    v14 = RequestedConnectionStruct; /*0x1039c54e9*/
    if ( *(_QWORD *)(RequestedConnectionStruct + 360) != 0 )
    {
      RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v69, a2, a3, a4: false); /*0x1039c5509*/
      RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v69, a2: 0x11u); /*0x1039c551a*/
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v69, a2: &v63, a3: 8u, a4: true); /*0x1039c5537*/
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v69, a2: &v66, a3: 8u, a4: true); /*0x1039c5554*/
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c5e57*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v46); /*0x1039c5e62*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c5e6f*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c556e*/
      {
        RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v69, a2: v64, a3: 0x10u, a4: true); /*0x1039c558c*/
      }
      else if ( (unsigned __int8)RakNet::BitStream::ReadBits( /*0x1039c562d*/
                                   this: (RakNet::BitStream *)v69,
                                   a2: v75,
                                   a3: 0x10u,
                                   a4: true) != 0 )
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v75, a2: v64, a3: (unsigned __int8 *)2, a4: v15); /*0x1039c5642*/
      }
      RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v69); /*0x1039c564e*/
      RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v75, a2, a3, a4: false); /*0x1039c5662*/
      v61 = (_QWORD *)(v14 + 360); /*0x1039c566e*/
      if ( (unsigned __int8)RBX::Security::RakPeerCrypto::earlyDecryptData( /*0x1039c568d*/
                              this: *(RBX::Security::RakPeerCrypto **)(v14 + 360),
                              a2: (RakNet::BitStream *)v75,
                              a3: v66) == 0 )
      {
        LODWORD(a2) = 0; /*0x1039c573b*/
        if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c5738*/
          FLog::FastLog( /*0x1039c5756*/
            a1: DFLog::SessionCrypto,
            a2: qword_10D7BB210,
            a3: "[DFLog::SessionCrypto] RbxOpenReply2 decrypt failed",
            0);
        goto LABEL_72; /*0x1039c575b*/
      }
      v16 = *((_QWORD *)this + 423); /*0x1039c5693*/
      if ( v16 != 0 ) /*0x1039c569d*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v16 + 40LL))(a1: v16); /*0x1039c56a2*/
      RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v75, a2: 0x15u); /*0x1039c56b1*/
      RakNet::BitStream::ReadAlignedBytes(this: (RakNet::BitStream *)v75, a2: v74, a3: 0x20u); /*0x1039c56c9*/
      CapabilitiesIfAny = readCapabilitiesIfAny(this: (RakNet::BitStream *)v75); /*0x1039c56da*/
      RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)v58); /*0x1039c56e8*/
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c5e87*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v47); /*0x1039c5e92*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c5e9f*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c5702*/
      {
        RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v75, a2: v58, a3: 0x40u, a4: true); /*0x1039c571c*/
      }
      else if ( (unsigned __int8)RakNet::BitStream::ReadBits( /*0x1039c577f*/
                                   this: (RakNet::BitStream *)v75,
                                   a2: v69,
                                   a3: 0x40u,
                                   a4: true) != 0 )
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v69, a2: v58, a3: (unsigned __int8 *)8, a4: v17); /*0x1039c5794*/
      }
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c5eb7*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v48); /*0x1039c5ec2*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c5ecf*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c57ae*/
      {
        RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v75, a2: v65, a3: 0x10u, a4: true); /*0x1039c57c8*/
      }
      else if ( (unsigned __int8)RakNet::BitStream::ReadBits( /*0x1039c57ee*/
                                   this: (RakNet::BitStream *)v75,
                                   a2: v69,
                                   a3: 0x10u,
                                   a4: true) != 0 )
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v69, a2: v65, a3: (unsigned __int8 *)2, a4: v18); /*0x1039c5803*/
      }
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v75, a2: &v67, a3: 8u, a4: true); /*0x1039c5820*/
      RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v52); /*0x1039c582c*/
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v75, a2: v56, a3: 8u, a4: true); /*0x1039c5849*/
      if ( v56[0] == 4 ) /*0x1039c5855*/
      {
        v52[1] = 2; /*0x1039c5857*/
        RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v75, a2: v69, a3: 0x20u, a4: true); /*0x1039c5876*/
        *(_DWORD *)&v52[4] = ~*(_DWORD *)v69; /*0x1039c588a*/
        RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v75, a2: &v52[2], a3: 0x10u, a4: true); /*0x1039c589e*/
        WORD6(v53) = __ROL2__(*(_WORD *)&v52[2], 8); /*0x1039c58ae*/
      }
      v19 = DFLog::NetworkTrace; /*0x1039c58b5*/
      if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
      {
        v20 = qword_10D7BB068; /*0x1039c58d2*/
        *(_QWORD *)v69 = 0; /*0x1039c58e0*/
        RakNet::buildCapabilitiesHelper(a1: v69, a2: 0); /*0x1039c58e9*/
        FLog::FastLogFormatted(
          a1: v19,
          a2: v20,
          a3: (unsigned int)"[DFLog::NetworkTrace] Peer has capabilities: 0x%llx ,common capabilities: 0x%llx",
          a4: *(_DWORD *)v69,
          a5: CapabilitiesIfAny,
          a6: v21);
      }
      RBX::Security::RakPeerCrypto::clientInitEphemeralSessionKeys(this: (RBX::Security::SessionCrypto *)*v61); /*0x1039c5926*/
      LODWORD(a2) = RBX::Security::SessionCrypto::isTestOnly(a1: v67); /*0x1039c5937*/
      LOBYTE(a2) = (v67 == 0) | (unsigned __int8)a2; /*0x1039c5945*/
      if ( (_BYTE)a2 == 1 ) /*0x1039c594c*/
      {
        qmemcpy(v69, &RakNet::UNASSIGNED_SYSTEM_ADDRESS, 32); /*0x1039c5955*/
        LOBYTE(v23) = v67 == 0; /*0x1039c5942*/
        (*(void (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)this + 424LL))( /*0x1039c598e*/
          a1: this,
          a2: v24,
          a3: v22,
          a4: v23,
          a5: v25,
          a6: v26,
          a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
          a8: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
          a9: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
          a10: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3));
        RakNet::RakPeer::sendRbxOpenError(this, a2: 1); /*0x1039c59b3*/
LABEL_71:
        LOBYTE(a2) = (unsigned __int8)a2 ^ 1; /*0x1039c5e0f*/
LABEL_72:
        RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v75); /*0x1039c5e13*/
        return (unsigned int)a2; /*0x1039c5e1a*/
      }
      RBX::Security::SessionCrypto::setRakCryptoFormat(a1: *v61, a2: v67); /*0x1039c59ca*/
      v68 = 0; /*0x1039c59cf*/
      v27 = *(_OWORD *)a4; /*0x1039c59d6*/
      *(_OWORD *)&v69[16] = *((_OWORD *)a4 + 1); /*0x1039c59e4*/
      *(_OWORD *)v69 = v27; /*0x1039c59e9*/
      if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: v69, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0
        || (RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, a2: (const RakNet::SystemAddress *)v69)) == -1
        || (v29 = 5368LL * RemoteSystemIndex, (*(_BYTE *)(*((_QWORD *)this + 92) + v29) & 1) == 0)
        || (v30 = *((_QWORD *)this + 92)) == 0 )
      {
        v32 = (RakNet::SimpleMutex *)(v14 + 344); /*0x1039c5a47*/
        if ( *(_QWORD *)(v14 + 344) == 0 ) /*0x1039c5a56*/
          v32 = v59; /*0x1039c5a56*/
        v33 = *(_OWORD *)a4; /*0x1039c5a5e*/
        v57 = *((_OWORD *)a4 + 1); /*0x1039c5a65*/
        *(_OWORD *)v56 = v33; /*0x1039c5a6c*/
        v34 = *((_QWORD *)v32 + 1); /*0x1039c5a73*/
        v54 = *(_OWORD *)v32; /*0x1039c5a7a*/
        if ( v34 != 0 ) /*0x1039c5a84*/
          _InterlockedIncrement64((volatile signed __int64 *)(v34 + 8)); /*0x1039c5a86*/
        *(_OWORD *)v51 = v53; /*0x1039c5a99*/
        *(_OWORD *)v50 = *(_OWORD *)v52; /*0x1039c5aa0*/
        v35 = *(unsigned __int16 *)v65; /*0x1039c5aa7*/
        *(_OWORD *)v49 = *(_OWORD *)v58; /*0x1039c5ab6*/
        v36 = v61[1]; /*0x1039c5ac4*/
        *(_OWORD *)v55 = *(_OWORD *)v61; /*0x1039c5acb*/
        if ( v36 != 0 ) /*0x1039c5ad5*/
          _InterlockedIncrement64((volatile signed __int64 *)(v36 + 8)); /*0x1039c5ad7*/
        *(_QWORD *)v69 = 0x10000; /*0x1039c5b09*/
        memset(&v69[8], 0, 32); /*0x1039c5b1f*/
        v70 = 0; /*0x1039c5b2d*/
        v71 = 0; /*0x1039c5b34*/
        v72 = 1; /*0x1039c5b3b*/
        memset(v73, 0, sizeof(v73)); /*0x1039c5b41*/
        v31 = RakNet::RakPeer::AssignSystemAddressToRemoteSystemList( /*0x1039c5bca*/
                this,
                a2: 6,
                a3: (__int64)&v54,
                a4: (RakNet::ReliabilityLayer *)&v68,
                a5: v35,
                a6: false,
                a7: *(__int128 *)v56,
                a8: v57,
                a9: v50[0],
                a10: *(int *)&v50[8],
                a11: v51[0],
                a12: v51[2],
                a13: *(__int64 *)v49,
                a14: *(__int16 *)&v49[8],
                a15: CapabilitiesIfAny,
                a16: (__int64)v55,
                a17: nullptr,
                a18: 0,
                a19: (__int64)v69);
        std::shared_ptr<RBX::Security::RakPeerCrypto>::~shared_ptr[abi:ne200100](a1: v55); /*0x1039c5bd4*/
        std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: &v54); /*0x1039c5be0*/
        if ( v31 == 0 )
        {
          if ( BYTE1(DFLog::SessionCrypto) >= 3u && (unsigned __int8)DFLog::SessionCrypto >= 6u ) /*0x1039c5c53*/
            FLog::FastLog( /*0x1039c5c6f*/
              a1: DFLog::SessionCrypto,
              a2: qword_10D7BB210,
              a3: "[DFLog::SessionCrypto] RbxOpenReply2 too many recent connections",
              0);
          RakNet::RakPeer::applicationConnectionFailed(this); /*0x1039c5c81*/
          v31 = 0; /*0x1039c5c86*/
LABEL_58:
          std::shared_ptr<RBX::Rupp::Rupp>::operator=[abi:ne200100](a1: v31 + 5280); /*0x1039c5c89*/
          v59 = (RakNet::RakPeer *)((char *)this + 1160); /*0x1039c5ca6*/
          RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1160)); /*0x1039c5cad*/
          v60 = (void *)v14; /*0x1039c5cb2*/
          CapabilitiesIfAny = (__int64)this + 1136; /*0x1039c5cc0*/
          for ( i = 0; ; ++i )
          {
            v39 = *((_DWORD *)this + 286); /*0x1039c5ccd*/
            v40 = *((_DWORD *)this + 287); /*0x1039c5cdb*/
            v41 = v40 < v39; /*0x1039c5cdd*/
            v42 = v40 - v39; /*0x1039c5cdd*/
            if ( v41 ) /*0x1039c5cdf*/
              v42 = *((_DWORD *)this + 288) + *((_DWORD *)this + 287) - v39; /*0x1039c5cea*/
            if ( i >= v42 ) /*0x1039c5cef*/
              break; /*0x1039c5cef*/
            v43 = *((_DWORD *)this + 288); /*0x1039c5cf9*/
            if ( v39 + i < v43 ) /*0x1039c5d02*/
              v43 = 0; /*0x1039c5d02*/
            if ( (unsigned __int8)RakNet::SystemAddress::operator==(
                                    a1: *(_QWORD *)(*((_QWORD *)this + 142) + 8LL * (i + v39 - v43)),
                                    a2: a4) != 0 )
            {
              DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::RemoveAtIndex( /*0x1039c5d31*/
                a1: CapabilitiesIfAny,
                a2: i);
              if ( (_BYTE)DFLog::RakNetConnectTrace != 0 && DFFlag::DebugRakNetConnectTracePrintRcsSystemAddress == 1 )
              {
                RakNet::SystemAddress::ToStringN(this: a4, a2: true, a3: v69, a4: 1025, a5: 124); /*0x1039c5d6d*/
                if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
                {
                  *(_QWORD *)v50 = v69; /*0x1039c5d9c*/
                  *(_QWORD *)v56 = 12; /*0x1039c5d9f*/
                  *(_QWORD *)&v56[8] = v50; /*0x1039c5daa*/
                  FLog::detail::FastLogSafeFormattedInternal(
                    a1: (_DWORD)DFLog::RakNetConnectTrace,
                    a2: qword_10D7BB0C8,
                    a3: 3,
                    a4: (unsigned int)"[DFLog::RakNetConnectTrace] RCS was removed for: {}",
                    a5: 51,
                    a6: 1,
                    12,
                    v50);
                }
              }
              break; /*0x1039c5dd4*/
            }
          }
          RakNet::SimpleMutex::Unlock(this: v59); /*0x1039c5dd9*/
          v44 = (char *)v60; /*0x1039c5de5*/
          std::shared_ptr<RBX::Security::RakPeerCrypto>::~shared_ptr[abi:ne200100](a1: v61); /*0x1039c5df3*/
          std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: v44 + 344); /*0x1039c5e02*/
          operator delete(a1: v44); /*0x1039c5e0a*/
          goto LABEL_71; /*0x1039c5e0a*/
        }
      }
      else
      {
        v31 = v29 + v30; /*0x1039c5a3c*/
      }
      *(_QWORD *)(v31 + 4600) = *((unsigned int *)this + 758); /*0x1039c5bf1*/
      if ( v68 == 0 ) /*0x1039c5bff*/
      {
        *(_BYTE *)(v31 + 1) = 1; /*0x1039c5c05*/
        *(_DWORD *)(v31 + 5364) = 4; /*0x1039c5c0a*/
        v37 = *(_DWORD *)(v14 + 336); /*0x1039c5c15*/
        if ( v37 != 0 ) /*0x1039c5c1e*/
          RakNet::ReliabilityLayer::SetTimeoutTime(this: (RakNet::ReliabilityLayer *)(v31 + 392), a2: v37); /*0x1039c5c27*/
        RakNet::RakPeer::sendApplicationConnectionRequest(this); /*0x1039c5c3c*/
      }
      goto LABEL_58; /*0x1039c5c41*/
    }
    LOBYTE(a2) = 1; /*0x1039c55e9*/
    if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c55e6*/
      FLog::FastLog( /*0x1039c5604*/
        a1: DFLog::SessionCrypto,
        a2: qword_10D7BB210,
        a3: "[DFLog::SessionCrypto] RbxOpenReply2 no session crypto",
        0);
  }
  else
  {
    LOBYTE(a2) = 1; /*0x1039c55b6*/
    if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039c55b3*/
      FLog::FastLog( /*0x1039c55cf*/
        a1: DFLog::SessionCrypto,
        a2: qword_10D7BB210,
        a3: "[DFLog::SessionCrypto] RbxOpenReply2 unexptected reply",
        0);
  }
  return (unsigned int)a2; /*0x1039c5e32*/
}

// Address: 0x1039c5f54 | Name: __ZNK6RakNet7RakPeer17ProcessRuppHeaderERKNS_13SystemAddressERN3RBX4Rupp21DeserializationResultENS4_9ArrayViewIhEEy
__int64 __fastcall RakNet::RakPeer::ProcessRuppHeader(
        RakNet::RakPeer *this,
        __int64 a2,
        _WORD *a3,
        __int64 a4,
        unsigned __int64 a5)
{
  unsigned int v8; // eax
  unsigned int v9; // ebx
  int v10; // r14d
  int v11; // r13d
  __int128 v13; // [rsp+10h] [rbp-70h] BYREF
  unsigned __int64 v14; // [rsp+20h] [rbp-60h]
  __int64 v15; // [rsp+38h] [rbp-48h]
  _QWORD v16[8]; // [rsp+40h] [rbp-40h] BYREF

  v15 = a2; /*0x1039c5f6e*/
  v8 = RBX::Rupp::Rupp::deserialize(a1: a3, a2: a4, a3: a5); /*0x1039c5f7e*/
  if ( v8 != 0 )
  {
    v9 = v8; /*0x1039c5f8b*/
    v10 = DFLog::Rupp; /*0x1039c5f8d*/
    if ( (unsigned __int8)DFLog::Rupp >= 6u && BYTE1(DFLog::Rupp) >= 6u )
    {
      v11 = qword_10D7BB258; /*0x1039c5faa*/
      v16[0] = RBX::Rupp::RuppError::toString(a1: v8); /*0x1039c5fbc*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: v10,
        a2: v11,
        a3: 6,
        a4: (unsigned int)"[DFLog::Rupp] Rupp deserialization: {}",
        a5: 38,
        a6: 1,
        12,
        v16,
        12,
        v16);
    }
    RakNet::RakPeer::reportRuppDeserializationFailure(this); /*0x1039c601a*/
  }
  else
  {
    v9 = 0; /*0x1039c6026*/
    if ( (unsigned __int16)*a3 > a5 ) /*0x1039c602b*/
    {
      if ( (unsigned __int8)DFLog::Rupp >= 6u && BYTE1(DFLog::Rupp) >= 6u ) /*0x1039c6043*/
      {
        *(_QWORD *)&v13 = (unsigned __int16)*a3; /*0x1039c6055*/
        v14 = a5; /*0x1039c6058*/
        v16[0] = 66; /*0x1039c605c*/
        v16[1] = &v13; /*0x1039c6064*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x1039c6088*/
          a1: DFLog::Rupp,
          a2: qword_10D7BB258,
          a3: 6,
          a4: (unsigned int)"[DFLog::Rupp] Invalid Rupp header length {} > bytes read {}",
          a5: 59,
          a6: 1,
          66,
          &v13,
          (_QWORD)v13);
      }
      *a3 = 0; /*0x1039c608d*/
      return 4; /*0x1039c6094*/
    }
  }
  return v9; /*0x1039c609b*/
}

// Address: 0x1039c60aa | Name: __ZNK6RakNet7RakPeer32reportRuppDeserializationFailureERKNS_13SystemAddressEN3RBX4Rupp9RuppError9ErrorCodeEj
__int64 __fastcall RakNet::RakPeer::reportRuppDeserializationFailure(
        RakNet::RakPeer *this,
        __int128 *a2,
        unsigned int a3,
        unsigned int a4)
{
  __int128 v7; // xmm0
  unsigned int RemoteSystemIndex; // eax
  __int64 v9; // rax
  __int64 v10; // rdx
  unsigned __int64 v11; // rcx
  bool v12; // cl
  __int64 v13; // rsi
  _OWORD v15[4]; // [rsp+0h] [rbp-40h] BYREF

  v7 = *a2; /*0x1039c60bf*/
  v15[1] = a2[1]; /*0x1039c60ca*/
  v15[0] = v7; /*0x1039c60ce*/
  if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: v15, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 /*0x1039c6114*/
    || (RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, a2: (const RakNet::SystemAddress *)v15)) == -1
    || (v9 = 5368LL * RemoteSystemIndex, (*(_BYTE *)(*((_QWORD *)this + 92) + v9) & 1) == 0)
    || (v10 = *((_QWORD *)this + 92)) == 0 )
  {
    v13 = 0; /*0x1039c6146*/
    v12 = false; /*0x1039c6148*/
  }
  else
  {
    v11 = *(_QWORD *)(v10 + v9 + 5320) + 1LL; /*0x1039c611e*/
    *(_QWORD *)(v10 + v9 + 5320) = v11; /*0x1039c6121*/
    v12 = v11 < DFInt::MaxRuppDeserializationFailureReportsToPoints; /*0x1039c6136*/
    v13 = a4 - *(_QWORD *)(v10 + v9 + 5184); /*0x1039c613c*/
  }
  if ( DFFlag::RakNetRuppTelemetryReportNetworkStack == 1 ) /*0x1039c6154*/
    return RBX::Rupp::reportRuppDeserializationFailure(a1: a3, a2: v13, a3: v12, a4: 0); /*0x1039c615d*/
  else
    return RBX::Rupp::reportRuppDeserializationFailure_deprecated(a1: a3, a2: v13, a3: v12); /*0x1039c6169*/
}

// Address: 0x1039c617a | Name: __ZN6RakNet7RakPeer20ProcessNetworkPacketERKNS_13SystemAddressEPKciPS0_yS3_RNS_9BitStreamEtRKN3RBX4Rupp21DeserializationResultE
__int64 __fastcall RakNet::RakPeer::ProcessNetworkPacket(
        __int64 a1,
        __int128 *a2,
        __int64 a3,
        unsigned int a4,
        RakNet::RakPeer *a5,
        RakNet::RakPeer *a6,
        __int64 a7,
        __int64 a8,
        unsigned __int16 a9,
        __int64 a10)
{
  __int128 v12; // xmm0
  __int64 v13; // rax
  unsigned int RemoteSystemIndex; // eax
  __int64 v15; // rax
  __int64 v16; // r14
  __int64 v17; // r14
  unsigned __int64 v18; // rdx
  unsigned int v19; // ebx
  __int64 v21; // rbx
  unsigned int updated; // eax
  unsigned int v23; // r15d
  __int64 v24; // rcx
  __int64 v25; // rax
  char v26; // r12
  std::__shared_weak_count *v27; // r14
  std::__shared_weak_count *v28; // r14
  std::__shared_weak_count *v29; // r14
  __int128 v30; // [rsp+30h] [rbp-D0h] BYREF
  __int128 v31; // [rsp+40h] [rbp-C0h]
  __int64 v32; // [rsp+58h] [rbp-A8h]
  __int64 v33; // [rsp+60h] [rbp-A0h]
  __int64 v34; // [rsp+68h] [rbp-98h]
  std::__shared_weak_count *v35[2]; // [rsp+70h] [rbp-90h] BYREF
  __int128 v36; // [rsp+80h] [rbp-80h] BYREF
  __int128 v37; // [rsp+90h] [rbp-70h]
  __int64 v38; // [rsp+A8h] [rbp-58h]
  std::__shared_weak_count *v39[2]; // [rsp+B0h] [rbp-50h] BYREF
  unsigned int v40; // [rsp+CCh] [rbp-34h]
  RakNet::RakPeer *v41; // [rsp+D0h] [rbp-30h]

  v41 = a6; /*0x1039c618e*/
  v40 = a4; /*0x1039c6195*/
  v38 = a3; /*0x1039c6198*/
  v32 = a1; /*0x1039c619f*/
  v12 = *a2; /*0x1039c61aa*/
  v31 = a2[1]; /*0x1039c61b1*/
  v30 = v12; /*0x1039c61b8*/
  if ( (*(_BYTE *)(a10 + 3) & 1) != 0 )
  {
    RakNet::SystemAddress::SystemAddress( /*0x1039c61dd*/
      this: (RakNet::SystemAddress *)&v36,
      a2: (const char *)(a10 + 24),
      a3: *(_WORD *)(a10 + 70));
    RakNet::SystemAddress::operator=(a1: &v30, a2: &v36); /*0x1039c61ec*/
    if ( (unsigned __int8)DFLog::Rupp >= 6u && BYTE1(DFLog::Rupp) >= 6u )
    {
      v13 = *(unsigned __int16 *)(a10 + 70); /*0x1039c6214*/
      *(_QWORD *)&v36 = a10 + 24; /*0x1039c6219*/
      *(_QWORD *)&v37 = v13; /*0x1039c621d*/
      v39[0] = (std::__shared_weak_count *)44; /*0x1039c6221*/
      v39[1] = (std::__shared_weak_count *)&v36; /*0x1039c6229*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: DFLog::Rupp,
        a2: qword_10D7BB258,
        a3: 6,
        a4: (unsigned int)"[DFLog::Rupp] ProcessPacket from reverse endpoint: {} | {}",
        a5: 58,
        a6: 1,
        44,
        &v36);
    }
  }
  v37 = v31; /*0x1039c6264*/
  v36 = v30; /*0x1039c6268*/
  if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: &v36, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 ) /*0x1039c6279*/
    return 0; /*0x1039c6279*/
  RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this: a5, a2: (const RakNet::SystemAddress *)&v36); /*0x1039c6286*/
  if ( RemoteSystemIndex == -1 ) /*0x1039c628e*/
    return 0; /*0x1039c628e*/
  v15 = 5368LL * RemoteSystemIndex; /*0x1039c629e*/
  if ( (*(_BYTE *)(*((_QWORD *)a5 + 92) + v15) & 1) == 0 ) /*0x1039c62ab*/
    return 0; /*0x1039c62ab*/
  v16 = *((_QWORD *)a5 + 92); /*0x1039c62ad*/
  if ( v16 == 0 ) /*0x1039c62b8*/
  {
    return 0; /*0x1039c632b*/
  }
  else
  {
    v17 = v15 + v16; /*0x1039c62be*/
    v33 = v17 + 36; /*0x1039c62c5*/
    RakNet::SystemAddress::operator=(a1: v17 + 36, a2: a7); /*0x1039c62cc*/
    v36 = 0; /*0x1039c62d8*/
    v34 = v17 + 5280; /*0x1039c62e5*/
    std::shared_ptr<RBX::Rupp::Rupp>::operator=[abi:ne200100](a1: &v36); /*0x1039c62ec*/
    if ( (_QWORD)v36 != 0 ) /*0x1039c62f7*/
    {
      if ( *(_QWORD *)(v36 + 48) != 0 ) /*0x1039c6302*/
      {
        if ( (unsigned int)RBX::Rupp::Rupp::updateTokenFromDeserializationResult(a1: v36, a2: a10, a3: v41) == 0 ) /*0x1039c6312*/
          RakNet::RakPeer::sendClientTokenUpdateTimeTelemetry_deprecated(this: v41, a2: *(_QWORD *)(v36 + 80), a3: v18); /*0x1039c6324*/
      }
      else
      {
        v21 = *(_QWORD *)(v36 + 80); /*0x1039c6341*/
        updated = RBX::Rupp::Rupp::updateTokenFromDeserializationResult(a1: v36, a2: a10, a3: v41); /*0x1039c634c*/
        RakNet::RakPeer::reportLateRuppTokenUpdate( /*0x1039c639b*/
          a1: v32,
          a2: &v30,
          a3: updated,
          a4: ((unsigned __int64)v41 - v21) / 0x3E8,
          a5: (unsigned __int64)v41 / 0x3E8);
      }
    }
    if ( (*(_BYTE *)(a10 + 3) & 1) != 0 ) /*0x1039c63a5*/
      RakNet::SystemAddress::operator=(a1: v17 + 4552, a2); /*0x1039c63b1*/
    v38 += a9; /*0x1039c63c2*/
    v40 -= a9; /*0x1039c63c6*/
    v23 = *(_DWORD *)(v17 + 5216); /*0x1039c63ca*/
    v24 = *((_QWORD *)a5 + 253); /*0x1039c63d1*/
    v25 = *(_QWORD *)(v24 + 8); /*0x1039c63d9*/
    *(_OWORD *)v35 = *(_OWORD *)v24; /*0x1039c63e0*/
    if ( v25 != 0 ) /*0x1039c63ea*/
      _InterlockedIncrement64((volatile signed __int64 *)(v25 + 8)); /*0x1039c63ec*/
    v26 = *(_BYTE *)(v17 + 5264); /*0x1039c63f1*/
    *(_OWORD *)v39 = 0; /*0x1039c63ff*/
    std::shared_ptr<RBX::Rupp::Rupp>::operator=[abi:ne200100](a1: v39); /*0x1039c640d*/
    v19 = RakNet::ReliabilityLayer::HandleSocketReceiveFromConnectedPlayer( /*0x1039c6464*/
            a1: v17 + 392,
            a2: v38,
            a3: v40,
            a4: &v30,
            a5: v23,
            a6: v35,
            a7: v41,
            a8,
            a9: v26 & 1,
            a10: v39,
            a11: v33,
            a12: a9);
    v27 = v39[1]; /*0x1039c6466*/
    if ( v39[1] != nullptr /*0x1039c647f*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v39[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v27 + 16LL))(a1: v27); /*0x1039c6487*/
      std::__shared_weak_count::__release_weak(this: v27); /*0x1039c648d*/
    }
    v28 = v35[1]; /*0x1039c6492*/
    if ( v35[1] != nullptr /*0x1039c64ae*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v35[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v28 + 16LL))(a1: v28); /*0x1039c64b6*/
      std::__shared_weak_count::__release_weak(this: v28); /*0x1039c64bc*/
    }
    v29 = *((std::__shared_weak_count **)&v36 + 1); /*0x1039c64c1*/
    if ( *((_QWORD *)&v36 + 1) != 0 /*0x1039c64de*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v36 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v29 + 16LL))(a1: v29); /*0x1039c64ea*/
      std::__shared_weak_count::__release_weak(this: v29); /*0x1039c64f0*/
    }
  }
  return v19; /*0x1039c632f*/
}

// Address: 0x1039c652c | Name: __ZNK6RakNet7RakPeer25reportLateRuppTokenUpdateERKNS_13SystemAddressEN3RBX4Rupp9RuppError9ErrorCodeEyy
__int64 __fastcall RakNet::RakPeer::reportLateRuppTokenUpdate(
        __int64 a1,
        const RakNet::SystemAddress *a2,
        unsigned int a3,
        unsigned __int64 a4,
        __int64 a5)
{
  __int64 result; // rax
  char v10; // cl
  __int64 v11; // rdx
  __int64 v12; // rbx
  _BYTE v13[88]; // [rsp+8h] [rbp-58h] BYREF

  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v13, a2); /*0x1039c6550*/
  result = RakNet::RakPeer::GetRemoteSystem(a1, a2: (__int64)v13, a3: 1, a4: 1u); /*0x1039c6565*/
  if ( result != 0 ) /*0x1039c656d*/
  {
    if ( a3 != 0 ) /*0x1039c6572*/
    {
      v10 = *(_BYTE *)(result + 5360); /*0x1039c6574*/
    }
    else
    {
      *(_BYTE *)(result + 5360) = 0; /*0x1039c657c*/
      v10 = 0; /*0x1039c6583*/
    }
    if ( (v10 & 1) == 0 && DFInt::ReportTimeBetweenTTServerThresholdMS <= a4 ) /*0x1039c6594*/
    {
      *(_BYTE *)(result + 5360) = 1; /*0x1039c6596*/
      v11 = *(unsigned int *)(*(_QWORD *)(result + 5280) + 64LL); /*0x1039c65a4*/
      v12 = a5 - *(_QWORD *)(result + 5184); /*0x1039c65ae*/
      if ( DFFlag::RakNetRuppTelemetryReportNetworkStack == 1 ) /*0x1039c65b8*/
        return RBX::Rupp::reportLateRuppTokenUpdate(a1: a3, a2: a4, a3: v11, a4: v12, a5: 0); /*0x1039c65c6*/
      else
        return RBX::Rupp::reportLateRuppTokenUpdate_deprecated(a1: a3, a2: a4, a3: v11, a4: v12); /*0x1039c65d6*/
    }
  }
  return result; /*0x1039c65db*/
}

// Address: 0x1039c65ea | Name: __ZN6RakNet7RakPeer45sendClientTokenUpdateTimeTelemetry_deprecatedEyy
__int64 __fastcall RakNet::RakPeer::sendClientTokenUpdateTimeTelemetry_deprecated(RakNet::RakPeer *this, __int64 a2)
{
  unsigned __int64 v2; // rbx
  __int64 v3; // rdx
  __int64 v4; // rcx
  _BYTE v6[16]; // [rsp+0h] [rbp-250h] BYREF
  void *v7; // [rsp+10h] [rbp-240h]
  void *v8[9]; // [rsp+18h] [rbp-238h] BYREF
  _BYTE v9[472]; // [rsp+60h] [rbp-1F0h] BYREF

  if ( a2 != 0 ) /*0x1039c6620*/
  {
    v2 = ((unsigned __int64)this - a2) / 0x3E8; /*0x1039c6629*/
    if ( DFInt::ReportTimeBetweenTTClientThresholdMS <= (int)v2 ) /*0x1039c6633*/
    {
      if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x1039c6646*/
                              this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::ReportTimeBetweenTTClientHundredthsPercentage,
                              a2) != 0 )
      {
        RBX::Analytics::InfluxDb::Points::Points( /*0x1039c6659*/
          a1: v8,
          a2: (unsigned int)DFInt::ReportTimeBetweenTTClientHundredthsPercentage,
          a3: 0,
          a4: 0);
        RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v8, a2: "TimeMS", a3: v2); /*0x1039c666e*/
        std::string::basic_string[abi:ne200100]<0>(a1: v6, a2: "TimeBetweenTTUpdates", a3: v3, a4: v4); /*0x1039c6681*/
        RBX::Analytics::InfluxDb::Points::report( /*0x1039c669c*/
          a1: v8,
          a2: v6,
          a3: (unsigned int)DFInt::ReportTimeBetweenTTClientHundredthsPercentage,
          a4: 0);
        if ( (v6[0] & 1) != 0 ) /*0x1039c66a8*/
          operator delete(a1: v7); /*0x1039c66b1*/
        RBX::Analytics::InfluxDb::Points::~Points(this: v8); /*0x1039c66bd*/
      }
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1039c66d0*/
        a1: v8,
        a2: (__int64)&RBX::Telemetry::kClientReceivedLateTTCounter);
      RBX::Telemetry::FieldsContainer::addField( /*0x1039c66fb*/
        a1: v9,
        a2: "DatacenterId",
        a3: 12,
        a4: RBX::Analytics::datacenterId,
        a5: 1);
      RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v8); /*0x1039c6707*/
      RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v9); /*0x1039c671a*/
      RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v8, a2: (void **)off_10C8C7EB0); /*0x1039c672d*/
    }
  }
  return __stack_chk_guard; /*0x1039c6742*/
}

// Address: 0x1039c679c | Name: __ZN6RakNet7RakPeer20GenerateSeedFromGuidEv
__int64 __fastcall RakNet::RakPeer::GenerateSeedFromGuid(RakNet::RakPeer *this)
{
  return (unsigned int)*((_QWORD *)this + 261) ^ (unsigned int)HIDWORD(*((_QWORD *)this + 261)); /*0x1039c67b0*/
}

// Address: 0x1039c67b2 | Name: __ZN6RakNet7RakPeer35ReportRakNetLatencyMeasurementStatsEy
__int64 __fastcall RakNet::RakPeer::ReportRakNetLatencyMeasurementStats(
        RakNet::RakPeer *this,
        __int64 a2,
        __int64 a3,
        unsigned __int64 a4)
{
  int v5; // esi
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  int v8; // eax
  int v9; // eax
  __m128d v10; // xmm0
  __m128d v11; // xmm0
  __int64 v12; // rdx
  __int64 v13; // rcx
  int v14; // r14d
  int v15; // r14d
  unsigned __int64 v16; // r14
  __m128d v17; // xmm0
  unsigned __int64 v18; // rbx
  __m128d v19; // xmm0
  _BYTE v21[16]; // [rsp+8h] [rbp-3E8h] BYREF
  void *v22; // [rsp+18h] [rbp-3D8h]
  __int128 v23; // [rsp+20h] [rbp-3D0h] BYREF
  __int64 v24; // [rsp+30h] [rbp-3C0h]
  void *v25[2]; // [rsp+200h] [rbp-1F0h] BYREF
  void *v26; // [rsp+210h] [rbp-1E0h]
  double v27; // [rsp+218h] [rbp-1D8h]

  if ( *((_DWORD *)this + 898) != 0 ) /*0x1039c67da*/
  {
    a4 = a2 - *((unsigned int *)this + 898); /*0x1039c67e3*/
    if ( a4 >= DFInt::CLI52064ReportIntervalMS ) /*0x1039c67f0*/
    {
      *((_DWORD *)this + 898) = a2; /*0x1039c67f6*/
      RBX::Analytics::InfluxDb::Points::Points(a1: v25, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1039c680c*/
      if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x1039c681e*/
                              this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::CLI52064InfluxHundredthsPercentage,
                              a2: v5) != 0 )
      {
        RBX::Analytics::InfluxDb::Points::Points( /*0x1039c6835*/
          a1: &v23,
          a2: (unsigned int)DFInt::CLI52064InfluxHundredthsPercentage,
          a3: 0,
          a4: 0);
        v6 = (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 904LL))(a1: this); /*0x1039c6840*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039c6869*/
          this: (RBX::Analytics::InfluxDb::Points *)&v23,
          a2: "AddedTxMs",
          a3: v6 / 0x3E8);
        v7 = (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 912LL))(a1: this); /*0x1039c6874*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039c6893*/
          this: (RBX::Analytics::InfluxDb::Points *)&v23,
          a2: "AddedRxMs",
          a3: v7 / 0x3E8);
        v8 = DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Size(a1: (_DWORD *)this + 384); /*0x1039c689f*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039c68b4*/
          this: (RBX::Analytics::InfluxDb::Points *)&v23,
          a2: "TxQueueSize",
          a3: v8);
        v9 = DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Size(a1: (_DWORD *)this + 338); /*0x1039c68c0*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039c68d5*/
          this: (RBX::Analytics::InfluxDb::Points *)&v23,
          a2: "RxQueueSize",
          a3: v9);
        v10 = _mm_sub_pd( /*0x1039c68e9*/
                (__m128d)_mm_unpacklo_ps((__m128)*((unsigned __int64 *)this + 442), (__m128)xmmword_108F2F9A0),
                (__m128d)xmmword_108F2F9B0);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039c6912*/
          this: (RBX::Analytics::InfluxDb::Points *)&v23,
          a2: "AvgExcessTxDelayUs",
          a3: _mm_hadd_pd(v10, v10).f64[0] / (double)*((int *)this + 886));
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039c692c*/
          this: (RBX::Analytics::InfluxDb::Points *)&v23,
          a2: "MaxExcessTxDelayUs",
          a3: *((_QWORD *)this + 447));
        v11 = _mm_sub_pd( /*0x1039c6940*/
                (__m128d)_mm_unpacklo_ps((__m128)*((unsigned __int64 *)this + 444), (__m128)xmmword_108F2F9A0),
                (__m128d)xmmword_108F2F9B0);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039c696c*/
          this: (RBX::Analytics::InfluxDb::Points *)&v23,
          a2: "AvgExcessRxDelayUs",
          a3: _mm_hadd_pd(v11, v11).f64[0] / (double)*((int *)this + 890));
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039c6986*/
          this: (RBX::Analytics::InfluxDb::Points *)&v23,
          a2: "MaxExcessRxDelayUs",
          a3: *((_QWORD *)this + 446));
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039c699f*/
          this: (RBX::Analytics::InfluxDb::Points *)&v23,
          a2: "PeakTxQueueSize",
          a3: *((_DWORD *)this + 896));
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039c69b8*/
          this: (RBX::Analytics::InfluxDb::Points *)&v23,
          a2: "PeakRxQueueSize",
          a3: *((_DWORD *)this + 897));
        std::string::basic_string[abi:ne200100]<0>(a1: v21, a2: "RaknetArtificialLatency", a3: v12, a4: v13); /*0x1039c69cb*/
        RBX::Analytics::InfluxDb::Points::report(a1: &v23, a2: v21, a3: 10000, a4: 0); /*0x1039c69e5*/
        if ( (v21[0] & 1) != 0 ) /*0x1039c69f1*/
          operator delete(a1: v22); /*0x1039c69fa*/
        RBX::Analytics::InfluxDb::Points::~Points(this: (void **)&v23); /*0x1039c6a06*/
      }
      *((_QWORD *)this + 442) = 0; /*0x1039c6a0d*/
      *((_DWORD *)this + 886) = 0; /*0x1039c6a14*/
      *((_QWORD *)this + 444) = 0; /*0x1039c6a1a*/
      *((_DWORD *)this + 890) = 0; /*0x1039c6a21*/
      RBX::Analytics::InfluxDb::Points::~Points(this: v25); /*0x1039c6a2e*/
    }
  }
  else
  {
    *((_DWORD *)this + 898) = a2; /*0x1039c6a35*/
  }
  if ( (*((_BYTE *)this + 160) & 1) != 0 ) /*0x1039c6a43*/
  {
    v23 = 0; /*0x1039c6a4d*/
    v24 = 0; /*0x1039c6a55*/
    v14 = *((_DWORD *)this + 896); /*0x1039c6a60*/
    if ( v14 != 0 ) /*0x1039c6a6a*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v25, a2: "RakNetLatencyPeakTxQueue", a3, a4); /*0x1039c6a7a*/
      v27 = (double)v14; /*0x1039c6a8e*/
      std::vector<std::pair<std::string,double>>::push_back[abi:ne200100](a1: &v23); /*0x1039c6a9a*/
      if ( ((__int64)v25[0] & 1) != 0 ) /*0x1039c6aa6*/
        operator delete(a1: v26); /*0x1039c6aaf*/
    }
    v15 = *((_DWORD *)this + 897); /*0x1039c6ab4*/
    if ( v15 != 0 ) /*0x1039c6abe*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v25, a2: "RakNetLatencyPeakRxQueue", a3, a4); /*0x1039c6ace*/
      v27 = (double)v15; /*0x1039c6ae2*/
      std::vector<std::pair<std::string,double>>::push_back[abi:ne200100](a1: &v23); /*0x1039c6aee*/
      if ( ((__int64)v25[0] & 1) != 0 ) /*0x1039c6afa*/
        operator delete(a1: v26); /*0x1039c6b03*/
    }
    v16 = *((_QWORD *)this + 447); /*0x1039c6b08*/
    if ( v16 != 0 ) /*0x1039c6b12*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v25, a2: "RakNetLatencyPeakTxDelay", a3, a4); /*0x1039c6b22*/
      v17 = _mm_sub_pd( /*0x1039c6b34*/
              (__m128d)_mm_unpacklo_epi32((__m128i)v16, (__m128i)xmmword_108F2F9A0),
              (__m128d)xmmword_108F2F9B0);
      *(_QWORD *)&v27 = (unsigned __int64)_mm_hadd_pd(v17, v17); /*0x1039c6b47*/
      std::vector<std::pair<std::string,double>>::push_back[abi:ne200100](a1: &v23); /*0x1039c6b53*/
      if ( ((__int64)v25[0] & 1) != 0 ) /*0x1039c6b5f*/
        operator delete(a1: v26); /*0x1039c6b68*/
    }
    v18 = *((_QWORD *)this + 446); /*0x1039c6b6d*/
    if ( v18 != 0 ) /*0x1039c6b77*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v25, a2: "RakNetLatencyPeakRxDelay", a3, a4); /*0x1039c6b87*/
      v19 = _mm_sub_pd( /*0x1039c6b99*/
              (__m128d)_mm_unpacklo_epi32((__m128i)v18, (__m128i)xmmword_108F2F9A0),
              (__m128d)xmmword_108F2F9B0);
      *(_QWORD *)&v27 = (unsigned __int64)_mm_hadd_pd(v19, v19); /*0x1039c6bac*/
      std::vector<std::pair<std::string,double>>::push_back[abi:ne200100](a1: &v23); /*0x1039c6bb8*/
      if ( ((__int64)v25[0] & 1) != 0 ) /*0x1039c6bc4*/
        operator delete(a1: v26); /*0x1039c6bcd*/
    }
    RBX::Analytics::EphemeralCounter::bulkReportStats(a1: &v23, a2: 0); /*0x1039c6bde*/
    v25[0] = &v23; /*0x1039c6bea*/
    std::vector<std::pair<std::string,double>>::__destroy_vector::operator()[abi:ne200100](); /*0x1039c6bed*/
  }
  return __stack_chk_guard; /*0x1039c6c02*/
}

// Address: 0x1039c6d96 | Name: __ZN6RakNet7RakPeer26PrintReceivedBytesSecurityEPKci
void __fastcall RakNet::RakPeer::PrintReceivedBytesSecurity(RakNet::RakPeer *this, const char *a2)
{
  ; /*0x1039c6d96*/
}

// Address: 0x1039c6e52 | Name: __ZN6RakNet7RakPeer39ProcessArtificialLatencyTransmitPacketsEy
__int64 __fastcall RakNet::RakPeer::ProcessArtificialLatencyTransmitPackets(RakNet::RakPeer *this, unsigned __int64 a2)
{
  RakNet::RakPeer::DelayTransmitQueue *v4; // r14
  int v5; // eax
  __int64 v6; // rax
  unsigned int **v7; // r13
  std::__shared_weak_count *v8; // rdi
  volatile signed __int64 *v9; // rax
  volatile signed __int64 *v10; // r12
  int v11; // eax
  unsigned __int64 v12; // rax
  unsigned __int64 v13; // rcx

  v4 = (RakNet::RakPeer *)((char *)this + 1536); /*0x1039c6e69*/
  v5 = DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Size(a1: (_DWORD *)this + 384); /*0x1039c6e73*/
  if ( *((_DWORD *)this + 896) > v5 ) /*0x1039c6e81*/
    v5 = *((_DWORD *)this + 896); /*0x1039c6e81*/
  *((_DWORD *)this + 896) = v5; /*0x1039c6e84*/
  while ( RakNet::RakPeer::DelayTransmitQueue::FrontTimeToSend(this: v4) <= a2 ) /*0x1039c6e96*/
  {
    v6 = DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Pop(a1: (__int64)v4); /*0x1039c6e9f*/
    if ( v6 != 0 ) /*0x1039c6ea7*/
    {
      v7 = (unsigned int **)v6; /*0x1039c6ea9*/
      v8 = *(std::__shared_weak_count **)(v6 + 8); /*0x1039c6eac*/
      if ( v8 != nullptr ) /*0x1039c6eb3*/
      {
        v9 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v8); /*0x1039c6eb9*/
        if ( v9 != nullptr ) /*0x1039c6ec5*/
        {
          v10 = v9; /*0x1039c6ecb*/
          if ( *v7 != nullptr ) /*0x1039c6ed9*/
          {
            v11 = RakNet::SocketLayer::SendToAfterDelay(a1: **v7, a2: v7); /*0x1039c6ee0*/
            if ( v11 != -3 ) /*0x1039c6ee8*/
            {
              ++*((_QWORD *)this + 454); /*0x1039c6eea*/
              if ( v11 != 0 ) /*0x1039c6ef3*/
              {
                if ( v11 == -4 ) /*0x1039c6ef8*/
                  ++*((_QWORD *)this + 455); /*0x1039c6efa*/
                else
                  ++*((_QWORD *)this + 456); /*0x1039c6f32*/
              }
              else
              {
                v12 = a2 - (_QWORD)v7[200]; /*0x1039c6f06*/
                v13 = *((_QWORD *)this + 447); /*0x1039c6f0d*/
                if ( v13 <= v12 ) /*0x1039c6f17*/
                  v13 = a2 - (_QWORD)v7[200]; /*0x1039c6f17*/
                *((_QWORD *)this + 447) = v13; /*0x1039c6f1b*/
                *((_QWORD *)this + 442) += v12; /*0x1039c6f22*/
                ++*((_DWORD *)this + 886); /*0x1039c6f29*/
              }
            }
          }
          if ( _InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039c6f4a*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v10 + 16))(a1: v10); /*0x1039c6f53*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v10); /*0x1039c6f59*/
          }
        }
      }
      DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Deallocate(a1: (__int64)v4, a2: v7); /*0x1039c6f6d*/
    }
  }
  return RakNet::RakPeer::DelayTransmitQueue::FrontTimeToSend(this: v4); /*0x1039c6f7a*/
}

// Address: 0x1039c6ff2 | Name: __ZN6RakNet7RakPeer21AllocateReceivePacketEPKcj
__int64 __fastcall RakNet::RakPeer::AllocateReceivePacket(RakNet::RakPeer *this, const char *a2, unsigned int a3)
{
  return DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Allocate( /*0x1039c6ffd*/
           a1: (__int64 *)this + 169,
           (unsigned __int64)a2,
           a3);
}

// Address: 0x1039c7060 | Name: __ZN6RakNet7RakPeer23DeallocateReceivePacketEPNS0_14RecvFromStructEPKcj
__int64 __fastcall RakNet::RakPeer::DeallocateReceivePacket(__int64 a1, _QWORD *a2)
{
  __int64 v3; // r13
  RakNet::SimpleMutex *v4; // r12

  v3 = a1 + 1352; /*0x1039c7079*/
  v4 = (RakNet::SimpleMutex *)(a1 + 1384); /*0x1039c7080*/
  RakNet::SimpleMutex::Lock(this: (RakNet::SimpleMutex *)(a1 + 1384)); /*0x1039c708a*/
  DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::Release(a1: v3, a2); /*0x1039c709a*/
  return RakNet::SimpleMutex::Unlock(this: v4); /*0x1039c70a6*/
}

// Address: 0x1039c70b6 | Name: __ZN6RakNet7RakPeer17PushReceivePacketEPNS0_14RecvFromStructE
__int64 __fastcall RakNet::RakPeer::PushReceivePacket(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a2 + 1528) += (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 912LL))(a1); /*0x1039c70cc*/
  return DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Push(a1: a1 + 1352, a2); /*0x1039c70e0*/
}

// Address: 0x1039c7136 | Name: __ZN6RakNet7RakPeer16PopReceivePacketEbyRy
__int64 __fastcall RakNet::RakPeer::PopReceivePacket(
        RakNet::RakPeer *this,
        int a2,
        unsigned __int64 a3,
        unsigned __int64 *a4)
{
  int v7; // eax
  __int64 v8; // rax
  __int64 v9; // r13
  unsigned __int64 v10; // r12
  unsigned __int64 v11; // rax

  if ( a2 == 0 ) /*0x1039c7149*/
    return DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Pop(a1: (__int64)this + 1352); /*0x1039c71d4*/
  v7 = DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Size(a1: (_DWORD *)this + 338); /*0x1039c715b*/
  if ( *((_DWORD *)this + 897) > v7 ) /*0x1039c7169*/
    v7 = *((_DWORD *)this + 897); /*0x1039c7169*/
  *((_DWORD *)this + 897) = v7; /*0x1039c716c*/
  if ( RakNet::RakPeer::RecvSpecQueue::FrontTimeReceive(this: (RakNet::RakPeer *)((char *)this + 1352)) <= a3 /*0x1039c718b*/
    && (v8 = DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Pop(a1: (__int64)this + 1352)) != 0 )
  {
    v9 = v8; /*0x1039c718d*/
    v10 = a3 - *(_QWORD *)(v8 + 1528); /*0x1039c7190*/
    v11 = *((_QWORD *)this + 446); /*0x1039c7197*/
    if ( v11 <= v10 ) /*0x1039c71a1*/
      v11 = v10; /*0x1039c71a1*/
    *((_QWORD *)this + 446) = v11; /*0x1039c71a5*/
    *((_QWORD *)this + 444) += v10; /*0x1039c71ac*/
    ++*((_DWORD *)this + 890); /*0x1039c71b3*/
  }
  else
  {
    v9 = 0; /*0x1039c71d9*/
  }
  *a4 = RakNet::RakPeer::RecvSpecQueue::FrontTimeReceive(this: (RakNet::RakPeer *)((char *)this + 1352)); /*0x1039c71e4*/
  return v9; /*0x1039c71ca*/
}

// Address: 0x1039c72a6 | Name: __ZN6RakNet7RakPeer22ProcessBufferedPacketsERNS_9BitStreamEy
unsigned __int64 __fastcall RakNet::RakPeer::ProcessBufferedPackets(
        RakNet::RakPeer *this,
        RakNet::BitStream *a2,
        unsigned __int64 a3)
{
  int v5; // ecx
  int v6; // r8d
  int v7; // r9d
  bool v8; // r12
  int v9; // r15d
  int v10; // eax
  int v11; // ecx
  int v12; // r8d
  int v13; // r9d
  __int64 v14; // r8
  __int64 v15; // r9
  __int64 v16; // r12
  __int64 v17; // rax
  __int64 v18; // r14
  _DWORD **v19; // rcx
  __int128 *v20; // r15
  unsigned __int16 v21; // ax
  int v22; // ecx
  int v23; // eax
  __int64 v24; // rcx
  __int64 v25; // rax
  char v26; // r15
  std::__shared_weak_count *v27; // r13
  unsigned int v28; // r14d
  __int128 v29; // xmm0
  __int128 v30; // xmm0
  bool v31; // r15
  unsigned __int8 *v32; // r13
  signed int v33; // r15d
  __int64 v34; // rcx
  __int64 v35; // rdx
  __int64 v36; // rax
  __int64 v37; // rax
  std::__shared_weak_count *v38; // r15
  unsigned __int8 v39; // al
  unsigned int v40; // ecx
  __int128 v41; // xmm0
  unsigned int RemoteSystemIndex; // eax
  __int64 v43; // rax
  __int64 v44; // rcx
  int v45; // edx
  int v46; // eax
  int v47; // ecx
  const char *v49; // rsi
  const char *v50; // rsi
  _BYTE v51[32]; // [rsp+40h] [rbp-190h] BYREF
  __int128 v52; // [rsp+60h] [rbp-170h]
  __int128 v53; // [rsp+70h] [rbp-160h]
  __int64 v54; // [rsp+80h] [rbp-150h]
  RakNet::RakPeer::TrackDroppedPackets *v55; // [rsp+88h] [rbp-148h]
  RakNet::BitStream *v56; // [rsp+90h] [rbp-140h]
  unsigned __int64 v57; // [rsp+98h] [rbp-138h]
  std::__shared_weak_count *v58[2]; // [rsp+A0h] [rbp-130h] BYREF
  std::__shared_weak_count *v59[2]; // [rsp+B0h] [rbp-120h] BYREF
  char v60[16]; // [rsp+C0h] [rbp-110h] BYREF
  __int128 v61; // [rsp+D0h] [rbp-100h]
  unsigned __int64 v62; // [rsp+E0h] [rbp-F0h] BYREF
  RakNet::SimpleMutex *v63; // [rsp+E8h] [rbp-E8h]
  __int64 v64; // [rsp+F0h] [rbp-E0h]
  __int64 v65; // [rsp+F8h] [rbp-D8h]
  std::__shared_weak_count **v66; // [rsp+100h] [rbp-D0h]
  unsigned int v67; // [rsp+10Ch] [rbp-C4h]
  __int64 v68; // [rsp+110h] [rbp-C0h]
  __int64 v69; // [rsp+118h] [rbp-B8h]
  const char *v70; // [rsp+120h] [rbp-B0h]
  unsigned __int64 v71; // [rsp+128h] [rbp-A8h]
  RakNet::SystemAddress *v72; // [rsp+130h] [rbp-A0h]
  int v73; // [rsp+138h] [rbp-98h]
  unsigned int v74; // [rsp+13Ch] [rbp-94h]
  char *v75; // [rsp+140h] [rbp-90h] BYREF
  __int128 v76; // [rsp+148h] [rbp-88h]
  __int128 v77; // [rsp+158h] [rbp-78h]
  __int128 v78; // [rsp+168h] [rbp-68h]
  __int128 v79; // [rsp+178h] [rbp-58h]
  char v80; // [rsp+188h] [rbp-48h]
  __int128 v81; // [rsp+189h] [rbp-47h]

  v56 = a2; /*0x1039c72bd*/
  v64 = (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 912LL))(a1: this); /*0x1039c72de*/
  if ( (_BYTE)`guard variable for'RakNet::RakPeer::ProcessBufferedPackets(RakNet::BitStream &,unsigned long long)::proflabeltoken == 0 /*0x1039c7a08*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::RakPeer::ProcessBufferedPackets(RakNet::BitStream &,unsigned long long)::proflabeltoken) != 0 )
  {
    v75 = "teControl"; /*0x1039c7a15*/
    RakNet::RakPeer::ProcessBufferedPackets(RakNet::BitStream &,unsigned long long)::proflabeltoken = RBX::Profiler::getLabelToken(this: (RBX::Profiler *)&aAutocompleteke_3[-855998], a2: v49); /*0x1039c7a2f*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::RakPeer::ProcessBufferedPackets(RakNet::BitStream &,unsigned long long)::proflabeltoken); /*0x1039c7a3d*/
  }
  RBX::Profiler::addLabelFormat(
    a1: RakNet::RakPeer::ProcessBufferedPackets(RakNet::BitStream &,unsigned long long)::proflabeltoken,
    a2: (unsigned int)"#clients: %u",
    a3: *((_DWORD *)this + 188),
    a4: v5,
    a5: v6,
    a6: v7);
  if ( (_BYTE)`guard variable for'RakNet::RakPeer::ProcessBufferedPackets(RakNet::BitStream &,unsigned long long)::proflabeltoken == 0 /*0x1039c7a55*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::RakPeer::ProcessBufferedPackets(RakNet::BitStream &,unsigned long long)::proflabeltoken) != 0 )
  {
    v75 = "equesterCalled"; /*0x1039c7a62*/
    RakNet::RakPeer::ProcessBufferedPackets(RakNet::BitStream &,unsigned long long)::proflabeltoken = RBX::Profiler::getLabelToken(this: (RBX::Profiler *)&aSetdirectchatr_0[-550422], a2: v50); /*0x1039c7a7c*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::RakPeer::ProcessBufferedPackets(RakNet::BitStream &,unsigned long long)::proflabeltoken); /*0x1039c7a8a*/
  }
  v8 = v64 != 0; /*0x1039c7327*/
  v9 = RakNet::RakPeer::ProcessBufferedPackets(RakNet::BitStream &,unsigned long long)::proflabeltoken; /*0x1039c732b*/
  v54 = (__int64)this + 1352; /*0x1039c7339*/
  v10 = DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Size(a1: (_DWORD *)this + 338); /*0x1039c7340*/
  RBX::Profiler::addLabelFormat(a1: v9, a2: (unsigned int)"#bufferedPackets: %d", a3: v10, a4: v11, a5: v12, a6: v13);
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v51); /*0x1039c735f*/
  v62 = -1; /*0x1039c736b*/
  v16 = RakNet::RakPeer::PopReceivePacket(this, a2: v8, a3, a4: &v62); /*0x1039c7383*/
  if ( v16 != 0 ) /*0x1039c7389*/
  {
    v57 = a3 / 0x3E8; /*0x1039c73a7*/
    v55 = (RakNet::RakPeer *)((char *)this + 3416); /*0x1039c73b5*/
    v63 = (RakNet::RakPeer *)((char *)this + 1384); /*0x1039c73c3*/
    v68 = 0; /*0x1039c73ca*/
    v66 = v58; /*0x1039c73dc*/
    v71 = a3; /*0x1039c73e3*/
    while ( 1 ) /*0x1039c73ea*/
    {
      v17 = *((unsigned int *)this + 508); /*0x1039c73ea*/
      LODWORD(v18) = 0; /*0x1039c73f0*/
      if ( *((_DWORD *)this + 508) != 0 ) /*0x1039c73f9*/
      {
        v19 = *((_DWORD ***)this + 253); /*0x1039c73fb*/
        v18 = 0; /*0x1039c740a*/
        while ( **v19 != *(_DWORD *)(v16 + 1536) ) /*0x1039c7412*/
        {
          ++v18; /*0x1039c7414*/
          v19 += 2; /*0x1039c7417*/
          if ( v17 == v18 ) /*0x1039c741e*/
            goto LABEL_30; /*0x1039c741e*/
        }
      }
      if ( (_DWORD)v18 == (_DWORD)v17 ) /*0x1039c7428*/
        goto LABEL_30; /*0x1039c7428*/
      v20 = (__int128 *)(v16 + 1496); /*0x1039c742e*/
      LODWORD(v75) = 0x10000; /*0x1039c7436*/
      BYTE4(v75) = 0; /*0x1039c7440*/
      v79 = 0; /*0x1039c7451*/
      v78 = 0; /*0x1039c7455*/
      v77 = 0; /*0x1039c7459*/
      v76 = 0; /*0x1039c745d*/
      v80 = 1; /*0x1039c7460*/
      v81 = 0; /*0x1039c7464*/
      if ( *((_BYTE *)this + 132) == 1 /*0x1039c7493*/
        && (unsigned int)RakNet::RakPeer::ProcessRuppHeader(
                           this,
                           a2: v16 + 1496,
                           a3: &v75,
                           a4: v16,
                           a5: *(int *)(v16 + 1492)) == 0 )
      {
        v21 = (unsigned __int16)v75; /*0x1039c77c5*/
        if ( BYTE4(v75) == 255 || BYTE4(v75) == 1 ) /*0x1039c77de*/
        {
          v69 = *((_QWORD *)&v76 + 1); /*0x1039c77f2*/
          v70 = (const char *)v76; /*0x1039c77f2*/
        }
        else
        {
          v70 = ""; /*0x1039c785e*/
          v69 = 0; /*0x1039c7865*/
        }
      }
      else
      {
        v69 = 0; /*0x1039c7499*/
        v70 = ""; /*0x1039c74ab*/
        v21 = 0; /*0x1039c74b2*/
      }
      v22 = v21; /*0x1039c74b4*/
      v23 = *((unsigned __int8 *)this + 134); /*0x1039c74b7*/
      if ( (unsigned __int16)v22 < (unsigned __int16)v23 ) /*0x1039c74c1*/
        *((_BYTE *)this + 134) = v22; /*0x1039c74c3*/
      LOBYTE(v23) = 1; /*0x1039c74c9*/
      v73 = v23; /*0x1039c74cb*/
      v74 = v22; /*0x1039c74d1*/
      if ( *(_DWORD *)(v16 + 1492) < v22 ) /*0x1039c74df*/
        goto LABEL_24; /*0x1039c74df*/
      v24 = *((_QWORD *)this + 253); /*0x1039c74e5*/
      v25 = *(_QWORD *)(v24 + 8); /*0x1039c74ec*/
      *(_OWORD *)v58 = *(_OWORD *)v24; /*0x1039c74f3*/
      if ( v25 != 0 ) /*0x1039c74fd*/
        _InterlockedIncrement64((volatile signed __int64 *)(v25 + 8)); /*0x1039c74ff*/
      v72 = (RakNet::SystemAddress *)(v16 + 1496); /*0x1039c750c*/
      v65 = v16 + 1540; /*0x1039c7516*/
      v26 = RakNet::RakPeer::ProcessBannedPacket( /*0x1039c752f*/
              a1: (RakNet::SystemAddress *)(v16 + 1496),
              a2: v16 + 1540,
              a3: this,
              a4: (__int64)v58,
              a5: a3);
      v27 = v58[1]; /*0x1039c7532*/
      if ( v58[1] != nullptr /*0x1039c754e*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v58[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v27 + 16LL))(a1: v27); /*0x1039c7557*/
        std::__shared_weak_count::__release_weak(this: v27); /*0x1039c755d*/
      }
      if ( v26 != 0 ) /*0x1039c7565*/
        break; /*0x1039c7565*/
      v32 = (unsigned __int8 *)(v16 + v74); /*0x1039c76ae*/
      v67 = *(_DWORD *)(v16 + 1492); /*0x1039c76b9*/
      v33 = v67 - v74; /*0x1039c76c0*/
      if ( RakNet::RakPeer::IsOfflinePacket(this: (RakNet::RakPeer *)v32, a2: (const char *)(v67 - v74)) != 0 ) /*0x1039c76d0*/
      {
        v34 = *((_QWORD *)this + 253); /*0x1039c76d6*/
        v35 = 16LL * (unsigned int)v18; /*0x1039c76e0*/
        v36 = *(_QWORD *)(v34 + v35 + 8); /*0x1039c76e4*/
        *(_OWORD *)v59 = *(_OWORD *)(v34 + v35); /*0x1039c76ed*/
        if ( v36 != 0 ) /*0x1039c76f7*/
          _InterlockedIncrement64((volatile signed __int64 *)(v36 + 8)); /*0x1039c76f9*/
        v37 = *(_QWORD *)(v16 + 1528); /*0x1039c76fe*/
        *(_QWORD *)v60 = v70; /*0x1039c770d*/
        *(_QWORD *)&v60[8] = v69; /*0x1039c771b*/
        v28 = v74; /*0x1039c773a*/
        RakNet::RakPeer::ProcessOfflineNetworkPacket( /*0x1039c7774*/
          a1: v72,
          a2: v65,
          a3: v32,
          a4: v33,
          a5: (__int64)this,
          a6: (__int64)v59,
          a7: v37,
          a8: v71,
          a9: v74,
          a10: (char)v70,
          a11: v69,
          a12: (__int64)&v75);
        v38 = v59[1]; /*0x1039c7779*/
        a3 = v71; /*0x1039c7783*/
        if ( v59[1] != nullptr /*0x1039c779c*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v59[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v38 + 16LL))(a1: v38); /*0x1039c77a4*/
          std::__shared_weak_count::__release_weak(this: v38); /*0x1039c77aa*/
        }
        v73 = 0; /*0x1039c77af*/
        v20 = (__int128 *)v72; /*0x1039c77b9*/
        goto LABEL_25; /*0x1039c77c0*/
      }
      if ( DFInt::ReportNumDataPacketsPerPeerEachCycle_HundredthsPercentage != 0 ) /*0x1039c7805*/
      {
        v20 = (__int128 *)v72; /*0x1039c780e*/
        RakNet::SystemAddress::operator=(a1: v51, a2: v72); /*0x1039c7818*/
        a3 = v71; /*0x1039c781d*/
        v28 = v74; /*0x1039c7824*/
        v39 = RakNet::SystemAddress::operator==(a1: v20, a2: v51); /*0x1039c7835*/
        v68 = v39 + (unsigned int)v68; /*0x1039c7846*/
        v40 = *(_DWORD *)(v16 + 1492); /*0x1039c784d*/
      }
      else
      {
        a3 = v71; /*0x1039c7875*/
        v20 = (__int128 *)v72; /*0x1039c787c*/
        v28 = v74; /*0x1039c7883*/
        v40 = v67; /*0x1039c788a*/
      }
      if ( (unsigned __int8)RakNet::RakPeer::ProcessNetworkPacket( /*0x1039c78d3*/
                              a1: (__int64)this,
                              a2: v20,
                              a3: v16,
                              a4: v40,
                              a5: this,
                              a6: *(RakNet::RakPeer **)(v16 + 1528),
                              a7: v65,
                              a8: (__int64)v56,
                              a9: v28,
                              a10: (__int64)&v75) == 0 )
      {
        v41 = *v20; /*0x1039c78fe*/
        v61 = v20[1]; /*0x1039c7907*/
        *(_OWORD *)v60 = v41; /*0x1039c790e*/
        if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: v60, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) == 0 ) /*0x1039c792a*/
        {
          RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, a2: (const RakNet::SystemAddress *)v60); /*0x1039c793a*/
          if ( RemoteSystemIndex != -1 ) /*0x1039c7942*/
          {
            v43 = 5368LL * RemoteSystemIndex; /*0x1039c7951*/
            if ( (*(_BYTE *)(*((_QWORD *)this + 92) + v43) & 1) != 0 ) /*0x1039c795e*/
            {
              v44 = *((_QWORD *)this + 92); /*0x1039c7964*/
              if ( v44 != 0 ) /*0x1039c796e*/
                *(_QWORD *)(v44 + v43 + 5168) = v57; /*0x1039c797b*/
            }
          }
        }
        goto LABEL_25; /*0x1039c7983*/
      }
      if ( (_BYTE)DFLog::RakNetPktTrace != 0 && DFFlag::DebugRakNetLogAllPackets == 1 ) /*0x1039c78e9*/
      {
        v73 = 0; /*0x1039c78ef*/
        goto LABEL_26; /*0x1039c78f9*/
      }
LABEL_30:
      v31 = v64 != 0; /*0x1039c763d*/
      RakNet::SimpleMutex::Lock(this: v63); /*0x1039c7653*/
      DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::Release(a1: v54, a2: (_QWORD *)v16); /*0x1039c766b*/
      RakNet::SimpleMutex::Unlock(this: v63); /*0x1039c7677*/
      v16 = RakNet::RakPeer::PopReceivePacket(this, a2: v31, a3, a4: &v62); /*0x1039c7694*/
      if ( v16 == 0 ) /*0x1039c769a*/
      {
        v45 = v68; /*0x1039c798f*/
        if ( DFInt::ReportNumDataPacketsPerPeerEachCycle_HundredthsPercentage != 0 && (int)v68 > 0 ) /*0x1039c799a*/
        {
          *((_QWORD *)this + 436) += (unsigned int)v68; /*0x1039c799e*/
          ++*((_DWORD *)this + 874); /*0x1039c79a5*/
          v46 = *((_DWORD *)this + 875); /*0x1039c79ab*/
          v47 = *((_DWORD *)this + 876); /*0x1039c79b1*/
          if ( v46 >= v45 ) /*0x1039c79b9*/
            v46 = v45; /*0x1039c79b9*/
          *((_DWORD *)this + 875) = v46; /*0x1039c79bc*/
          if ( v45 > v47 ) /*0x1039c79c4*/
            v47 = v45; /*0x1039c79c4*/
          *((_DWORD *)this + 876) = v47; /*0x1039c79c7*/
        }
        return v62; /*0x1039c79c7*/
      }
    }
    a3 = v71; /*0x1039c756b*/
    v20 = (__int128 *)v72; /*0x1039c7572*/
LABEL_24:
    v28 = v74; /*0x1039c7579*/
LABEL_25:
    if ( (_BYTE)DFLog::RakNetPktTrace != 0 ) /*0x1039c7587*/
    {
LABEL_26:
      v29 = *v20; /*0x1039c758d*/
      v61 = v20[1]; /*0x1039c7596*/
      *(_OWORD *)v60 = v29; /*0x1039c759d*/
      v30 = *(_OWORD *)(v16 + 1540); /*0x1039c75a4*/
      v53 = *(_OWORD *)(v16 + 1556); /*0x1039c75b6*/
      v52 = v30; /*0x1039c75bd*/
      RakNet::LogPkt( /*0x1039c7612*/
        a1: v16 + v28,
        a2: *(_DWORD *)(v16 + 1492) - v28,
        a3: "Rx",
        a4: (unsigned __int8)v73,
        a5: v14,
        a6: v15,
        a7: *(_QWORD *)v60,
        a8: *(_QWORD *)&v60[8],
        a9: v61,
        a10: *((_QWORD *)&v61 + 1),
        a11: v30,
        a12: *((_QWORD *)&v30 + 1),
        a13: v53,
        a14: *((_QWORD *)&v53 + 1));
    }
    if ( (_BYTE)v73 != 0 && DFFlag::ReportPktDropStats2 != 0 ) /*0x1039c7627*/
      RakNet::RakPeer::TrackDroppedPackets::AddPkt(this: v55, a2: *(_DWORD *)(v16 + 1492)); /*0x1039c7638*/
    goto LABEL_30; /*0x1039c7638*/
  }
  return v62; /*0x1039c79e8*/
}

// Address: 0x1039c7b20 | Name: __ZN6RakNet7RakPeer23ProcessBufferedCommandsERyS1_
__int64 __fastcall RakNet::RakPeer::ProcessBufferedCommands(
        RakNet::RakPeer *this,
        unsigned __int64 *a2,
        unsigned __int64 *a3)
{
  pthread_mutex_t *v4; // rbx
  __int64 v5; // r13
  __int64 v6; // r12
  __int64 v7; // rax
  __int128 v8; // xmm0
  __int64 v9; // rax
  __int64 result; // rax
  __int64 v11; // rbx
  int v12; // eax
  unsigned int v13; // r14d
  unsigned int v14; // r14d
  bool v15; // zf
  unsigned __int64 v16; // r12
  unsigned __int64 v17; // rax
  __int64 v18; // rdi
  __int64 v19; // rax
  const RakNet::AddressOrGUID *v20; // rbx
  __int64 *v21; // r14
  __int64 *v22; // rbx
  __int64 *v23; // rdi
  __int64 RemoteSystem; // rax
  unsigned int RemoteSystemIndex; // eax
  __int64 v26; // r14
  __int64 v27; // rax
  unsigned __int64 v28; // rax
  __int64 v29; // rdi
  __int64 v30; // rax
  char v31; // r14
  int v32; // r12d
  char v33; // al
  void *v34; // rsi
  __int64 v35; // rax
  unsigned __int64 v36; // rsi
  unsigned __int64 v37; // rtt
  __int64 v38; // rdi
  _QWORD v39[6]; // [rsp+0h] [rbp-C0h] BYREF
  _BYTE v40[32]; // [rsp+30h] [rbp-90h] BYREF
  RakNet::AddressOrGUID *v41; // [rsp+50h] [rbp-70h]
  unsigned __int64 *v42; // [rsp+58h] [rbp-68h]
  unsigned __int64 *v43; // [rsp+60h] [rbp-60h]
  __int64 v44; // [rsp+68h] [rbp-58h]
  void *v45[2]; // [rsp+70h] [rbp-50h]
  int v46; // [rsp+84h] [rbp-3Ch]
  unsigned int v47; // [rsp+88h] [rbp-38h]
  int v48; // [rsp+8Ch] [rbp-34h]
  __int64 *v49; // [rsp+90h] [rbp-30h]

  v42 = a3; /*0x1039c7b34*/
  v43 = a2; /*0x1039c7b38*/
  v4 = (pthread_mutex_t *)((char *)this + 1288); /*0x1039c7b3f*/
  boost::mutex::lock(this: (pthread_mutex_t *)((char *)this + 1288)); /*0x1039c7b49*/
  v5 = *((_QWORD *)this + 153); /*0x1039c7b5c*/
  *((_QWORD *)this + 153) = 0; /*0x1039c7b65*/
  v6 = *((_QWORD *)this + 156); /*0x1039c7b6c*/
  *((_QWORD *)this + 156) = 0; /*0x1039c7b73*/
  *(_OWORD *)v45 = *((_OWORD *)this + 77); /*0x1039c7b82*/
  *((_OWORD *)this + 77) = 0; /*0x1039c7b89*/
  RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::operator=( /*0x1039c7b91*/
    a1: (char *)this + 1224,
    a2: (char *)this + 1256);
  memset(v40, 0, sizeof(v40)); /*0x1039c7ba0*/
  v7 = *((_QWORD *)this + 157); /*0x1039c7ba9*/
  *((_QWORD *)this + 157) = v5; /*0x1039c7bb0*/
  v39[0] = v7; /*0x1039c7bbe*/
  v8 = *((_OWORD *)this + 79); /*0x1039c7bc2*/
  *((_OWORD *)this + 79) = *(_OWORD *)v45; /*0x1039c7bce*/
  *(_OWORD *)&v39[1] = v8; /*0x1039c7bd6*/
  v9 = *((_QWORD *)this + 160); /*0x1039c7bdb*/
  *((_QWORD *)this + 160) = v6; /*0x1039c7be2*/
  v39[3] = v9; /*0x1039c7be9*/
  RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::~UnboundedCircularBuffer(a1: v39); /*0x1039c7bf0*/
  RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::~UnboundedCircularBuffer(a1: v40); /*0x1039c7bf8*/
  boost::mutex::unlock(this: v4); /*0x1039c7c00*/
  result = 0; /*0x1039c7c05*/
  if ( *((_QWORD *)this + 160) != 0 ) /*0x1039c7c0e*/
  {
    v49 = (__int64 *)((char *)this + 1736); /*0x1039c7c1b*/
    v44 = (__int64)this + 2024; /*0x1039c7c26*/
    do /*0x1039c7fa7*/
    {
      v11 = *((_QWORD *)this + 157) + 160LL * (*((_QWORD *)this + 159) % *((_QWORD *)this + 158)); /*0x1039c7c50*/
      v12 = *(_DWORD *)(v11 + 144); /*0x1039c7c54*/
      switch ( v12 ) /*0x1039c7c5e*/
      {
        case 2: /*0x1039c7c5e*/
          RakNet::AddressOrGUID::AddressOrGUID( /*0x1039c7d67*/
            this: (RakNet::AddressOrGUID *)v39,
            a2: (const RakNet::RakNetGUID *)(v11 + 32));
          RemoteSystem = RakNet::RakPeer::GetRemoteSystem(a1: (__int64)this, a2: (__int64)v39, a3: 1, a4: 1u); /*0x1039c7d7c*/
          if ( RemoteSystem != 0 ) /*0x1039c7d84*/
          {
            RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex( /*0x1039c7d94*/
                                  this,
                                  a2: (const RakNet::SystemAddress *)(RemoteSystem + 4));
            RakNet::RakPeer::ReferenceRemoteSystem( /*0x1039c7da5*/
              this,
              a2: (const RakNet::SystemAddress *)(v11 + 48),
              a3: RemoteSystemIndex);
          }
          break;
        case 1: /*0x1039c7c5e*/
          v20 = (const RakNet::AddressOrGUID *)(v11 + 32); /*0x1039c7d28*/
          if ( (unsigned __int8)RakNet::AddressOrGUID::IsUndefined(this: v20) != 0 ) /*0x1039c7d36*/
          {
            v21 = v49; /*0x1039c7d38*/
            v22 = (__int64 *)DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Allocate( /*0x1039c7d49*/
                               a1: v49,
                               a2: (unsigned __int64)"",
                               a3: 0);
            DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::operator=(a1: (__int64)v22, a2: v44); /*0x1039c7d53*/
            v23 = v21; /*0x1039c7d58*/
          }
          else
          {
            RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v39, a2: v20); /*0x1039c7db5*/
            v26 = RakNet::RakPeer::GetRemoteSystem(a1: (__int64)this, a2: (__int64)v39, a3: 1, a4: 1u); /*0x1039c7dcf*/
            v22 = (__int64 *)DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Allocate( /*0x1039c7de0*/
                               a1: v49,
                               a2: (unsigned __int64)"",
                               a3: 0);
            DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::Clear(a1: v22, a2: 0); /*0x1039c7ded*/
            if ( v26 != 0 ) /*0x1039c7df5*/
              DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::Insert(a1: (__int64)v22, a2: v26 + 5232); /*0x1039c7e09*/
            v23 = v49; /*0x1039c7e0e*/
          }
          DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Push( /*0x1039c7e15*/
            a1: (__int64)v23,
            a2: (__int64)v22);
          break;
        case 0: /*0x1039c7c5e*/
          if ( DFFlag::DebugNetworkProfiler == 1 && DFFlag::DebugNetworkProfilerRakPeer == 1 ) /*0x1039c7c8f*/
          {
            v13 = *(_DWORD *)(v11 + 16); /*0x1039c7c95*/
            if ( v13 >= 8 ) /*0x1039c7c9d*/
            {
              v14 = (v13 + 7) >> 3; /*0x1039c7cab*/
              v15 = *(_BYTE *)(v11 + 80) == 1; /*0x1039c7caf*/
              LODWORD(v45[0]) = **(unsigned __int8 **)(v11 + 104); /*0x1039c7cb6*/
              if ( v15 ) /*0x1039c7cb9*/
              {
                if ( *((_DWORD *)this + 188) != 0 ) /*0x1039c7cc8*/
                {
                  v16 = 0; /*0x1039c7cce*/
                  do /*0x1039c7d21*/
                  {
                    v17 = *(unsigned __int16 *)(*(_QWORD *)(*((_QWORD *)this + 93) + 8 * v16) + 5248LL); /*0x1039c7cdc*/
                    if ( *((_QWORD *)this + 96) > v17 ) /*0x1039c7cea*/
                    {
                      v18 = *((_QWORD *)this + 95); /*0x1039c7cec*/
                      v19 = 4176 * v17; /*0x1039c7cf3*/
                      if ( (*(_BYTE *)(v18 + v19 + 4168) & 1) != 0 ) /*0x1039c7d04*/
                        RBX::NetworkProfiler::CapturePackets::record( /*0x1039c7d0f*/
                          this: (RBX::NetworkProfiler::CapturePackets *)(v19 + v18),
                          a2: (unsigned __int8)v45[0],
                          a3: v14);
                    }
                    ++v16; /*0x1039c7d14*/
                  }
                  while ( v16 < *((unsigned int *)this + 188) ); /*0x1039c7d21*/
                }
              }
              else
              {
                RakNet::AddressOrGUID::AddressOrGUID( /*0x1039c7e26*/
                  this: (RakNet::AddressOrGUID *)v39,
                  a2: (const RakNet::AddressOrGUID *)(v11 + 32));
                v27 = RakNet::RakPeer::GetRemoteSystem(a1: (__int64)this, a2: (__int64)v39, a3: 1, a4: 1u); /*0x1039c7e3b*/
                if ( v27 != 0 ) /*0x1039c7e43*/
                {
                  v28 = *(unsigned __int16 *)(v27 + 5248); /*0x1039c7e45*/
                  if ( *((_QWORD *)this + 96) > v28 ) /*0x1039c7e53*/
                  {
                    v29 = *((_QWORD *)this + 95); /*0x1039c7e55*/
                    v30 = 4176 * v28; /*0x1039c7e5c*/
                    if ( (*(_BYTE *)(v29 + v30 + 4168) & 1) != 0 ) /*0x1039c7e6d*/
                      RBX::NetworkProfiler::CapturePackets::record( /*0x1039c7e78*/
                        this: (RBX::NetworkProfiler::CapturePackets *)(v30 + v29),
                        a2: (unsigned __int8)v45[0],
                        a3: v14);
                  }
                }
              }
            }
          }
          *((_DWORD *)this + 34) = *(_DWORD *)v42 - *(_DWORD *)(v11 + 136); /*0x1039c7e89*/
          v31 = *(_QWORD *)v11 == 0; /*0x1039c7e97*/
          v45[0] = *(void **)(v11 + 104); /*0x1039c7e9f*/
          v32 = *(_DWORD *)(v11 + 16); /*0x1039c7ea3*/
          v46 = *(_DWORD *)(v11 + 20); /*0x1039c7eaa*/
          v47 = *(_DWORD *)(v11 + 24); /*0x1039c7eb0*/
          v48 = *(char *)(v11 + 28); /*0x1039c7eb7*/
          v41 = (RakNet::AddressOrGUID *)(v11 + 32); /*0x1039c7ec1*/
          RakNet::AddressOrGUID::AddressOrGUID( /*0x1039c7ec5*/
            this: (RakNet::AddressOrGUID *)v39,
            a2: (const RakNet::AddressOrGUID *)(v11 + 32));
          v33 = RakNet::RakPeer::SendImmediate( /*0x1039c7f0c*/
                  a1: (__int64)this,
                  a2: (__int64)v45[0],
                  a3: v32,
                  a4: v46,
                  a5: v47,
                  a6: v48,
                  a7: (__int64)v39,
                  a8: *(_BYTE *)(v11 + 80),
                  a9: v31,
                  a10: *v43,
                  a11: *(_DWORD *)(v11 + 128),
                  a12: *(_QWORD *)(v11 + 152),
                  a13: *(_BYTE *)(v11 + 132));
          if ( *(_QWORD *)v11 == 0 && v33 == 0 ) /*0x1039c7f1d*/
            RBX::Memory::deallocate(this: *(RBX::Memory **)(v11 + 104), a2: v34); /*0x1039c7f23*/
          if ( *(_DWORD *)(v11 + 84) != 0 ) /*0x1039c7f33*/
          {
            RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v39, a2: v41); /*0x1039c7f3c*/
            v35 = RakNet::RakPeer::GetRemoteSystem(a1: (__int64)this, a2: (__int64)v39, a3: 1, a4: 1u); /*0x1039c7f51*/
            if ( v35 != 0 ) /*0x1039c7f59*/
              *(_DWORD *)(v35 + 5364) = *(_DWORD *)(v11 + 84); /*0x1039c7f5e*/
          }
          break;
        default:
          break; /*0x1039c7c5e*/
      }
      v36 = *((_QWORD *)this + 158); /*0x1039c7f64*/
      v37 = *((_QWORD *)this + 159); /*0x1039c7f77*/
      v38 = *((_QWORD *)this + 157) + 160 * (v37 % v36); /*0x1039c7f82*/
      *((_QWORD *)this + 159) = (v37 + 1) % v36; /*0x1039c7f94*/
      result = std::shared_ptr<RBX::NetworkCore::AbstractBitStream const>::~shared_ptr[abi:ne200100](a1: v38); /*0x1039c7f9b*/
      v15 = (*((_QWORD *)this + 160))-- == 1; /*0x1039c7fa0*/
    }
    while ( !v15 ); /*0x1039c7fa7*/
  }
  return result; /*0x1039c7fad*/
}

// Address: 0x1039c8056 | Name: __ZN6RakNet7RakPeer19sendRbxOpenRequest1EPNS0_25RequestedConnectionStructERKy
__int64 __fastcall RakNet::RakPeer::sendRbxOpenRequest1(
        RakNet::RakPeer *this,
        volatile signed __int64 **a2,
        _QWORD *a3)
{
  __int64 v6; // rbx
  __int64 v7; // r15
  __int64 v8; // rcx
  RakNet::SystemAddress *v9; // r14
  unsigned __int64 v10; // rax
  __int64 v11; // rcx
  unsigned __int64 v12; // rdx
  int v13; // r15d
  RBX::SystemUtil *v14; // rdi
  volatile signed __int64 *v15; // rsi
  volatile signed __int64 *v16; // rax
  RakNet::RakPeer *v17; // rbx
  unsigned int v18; // r12d
  int IPPROTO; // eax
  int v20; // ecx
  bool v21; // si
  __int64 Time; // r13
  bool v23; // si
  int v24; // r12d
  unsigned int v25; // ecx
  unsigned __int64 v26; // rsi
  int v27; // r13d
  int v28; // r9d
  _BYTE *v29; // r8
  int v30; // r13d
  int v31; // r9d
  _BYTE *v32; // r8
  unsigned int v33; // r14d
  int v34; // eax
  int v35; // ecx
  bool v36; // si
  std::__shared_weak_count *v37; // rbx
  __int64 v39; // [rsp+10h] [rbp-5D0h]
  _BYTE v40[32]; // [rsp+18h] [rbp-5C8h] BYREF
  unsigned int *v41; // [rsp+38h] [rbp-5A8h] BYREF
  std::__shared_weak_count *v42; // [rsp+40h] [rbp-5A0h]
  RakNet::RakPeer *v43; // [rsp+48h] [rbp-598h]
  _QWORD *v44; // [rsp+50h] [rbp-590h]
  char v45; // [rsp+58h] [rbp-588h] BYREF
  _BYTE v46[15]; // [rsp+59h] [rbp-587h] BYREF
  void *v47; // [rsp+68h] [rbp-578h]
  unsigned __int64 v48; // [rsp+70h] [rbp-570h]
  int v49; // [rsp+7Ch] [rbp-564h]
  char v50[1032]; // [rsp+80h] [rbp-560h] BYREF
  _BYTE v51[12]; // [rsp+488h] [rbp-158h] BYREF
  int v52; // [rsp+494h] [rbp-14Ch]
  int v53[68]; // [rsp+4A0h] [rbp-140h]

  v49 = *((unsigned __int8 *)a2 + 40); /*0x1039c8082*/
  v48 = *((unsigned int *)a2 + 82); /*0x1039c8091*/
  v6 = *((_QWORD *)this + 248); /*0x1039c8098*/
  v7 = *((_QWORD *)this + 249); /*0x1039c809f*/
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v51); /*0x1039c80ad*/
  v44 = a3; /*0x1039c80b2*/
  v8 = 1000LL * *a3; /*0x1039c80b9*/
  v43 = this; /*0x1039c80c8*/
  RakNet::RakPeer::startOfflineBitStream(this, a2: (RakNet::BitStream *)v51, a3: nullptr, a4: v8); /*0x1039c80d4*/
  v9 = (RakNet::SystemAddress *)a2; /*0x1039c80d9*/
  v10 = v49 / (unsigned int)(v48 / ((v7 - v6) >> 2)); /*0x1039c80fa*/
  v11 = *((_QWORD *)v43 + 248); /*0x1039c8103*/
  v12 = (*((_QWORD *)v43 + 249) - v11) >> 2; /*0x1039c8114*/
  v13 = v12 - 1; /*0x1039c8118*/
  if ( v12 > v10 ) /*0x1039c811f*/
    v13 = v10; /*0x1039c811f*/
  v14 = DFLog::RakNetConnectTrace; /*0x1039c8123*/
  if ( BYTE1(DFLog::RakNetConnectTrace) >= 3u && (unsigned __int8)DFLog::RakNetConnectTrace >= 6u )
  {
    FLog::FastLog(
      a1: DFLog::RakNetConnectTrace,
      a2: qword_10D7BB0C8,
      a3: "[DFLog::RakNetConnectTrace] RakNet: Create OpenRequest1 with MTU %d",
      *(_DWORD *)(v11 + 4LL * v13));
    v11 = *((_QWORD *)v43 + 248); /*0x1039c8160*/
  }
  RakNet::RakPeer::createRbxOpenRequest1(a1: v14, a2: v51, a3: *(int *)(v11 + 4LL * v13) - 40LL); /*0x1039c817b*/
  ++*((_BYTE *)a2 + 40); /*0x1039c8180*/
  a2[4] = (volatile signed __int64 *)(*v44 + *((unsigned int *)a2 + 83)); /*0x1039c8195*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v40, a2: nullptr); /*0x1039c81a2*/
  v15 = a2[43]; /*0x1039c81a7*/
  v41 = (unsigned int *)v15; /*0x1039c81ae*/
  v16 = a2[44]; /*0x1039c81b5*/
  v42 = (std::__shared_weak_count *)v16; /*0x1039c81bc*/
  v17 = v43; /*0x1039c81c6*/
  if ( v16 != nullptr ) /*0x1039c81cd*/
    _InterlockedIncrement64(v16 + 1); /*0x1039c81cf*/
  if ( v15 == nullptr ) /*0x1039c81d7*/
  {
    std::shared_ptr<RakNet::RakNetSocket>::operator=[abi:ne200100]( /*0x1039c81f5*/
      a1: &v41,
      a2: *((_QWORD *)v17 + 253) + 16LL * *((unsigned int *)a2 + 79));
    v15 = (volatile signed __int64 *)v41; /*0x1039c81fa*/
  }
  RakNet::SystemAddress::FixForIPVersion( /*0x1039c8205*/
    this: (RakNet::SystemAddress *)a2,
    a2: (const RakNet::SystemAddress *)(v15 + 1));
  v18 = *v41; /*0x1039c8211*/
  IPPROTO = RakNet::SystemAddress::GetIPPROTO(this: (RakNet::SystemAddress *)(v41 + 2)); /*0x1039c8218*/
  RakNet::SocketLayer::SetDoNotFragment(this: (RakNet::SocketLayer *)v18, a2: 1, a3: IPPROTO, a4: v20); /*0x1039c8227*/
  Time = RakNet::GetTime(this: nullptr, a2: v21); /*0x1039c8233*/
  if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
    FLog::FastLog(
      a1: DFLog::RakNetConnectTrace,
      a2: qword_10D7BB0C8,
      a3: "[DFLog::RakNetConnectTrace] RakNet: Sending OpenRequest1",
      0);
  v24 = RakNet::SocketLayer::SendTo( /*0x1039c82a9*/
          this: (RakNet::SocketLayer *)*v41,
          a2: v53[0],
          a3: (const char *)((unsigned int)(v52 + 7) >> 3),
          a4: (int)v9,
          a5: (const RakNet::SystemAddress *)v40,
          a6: nullptr,
          a7: (bool)"",
          a8: nullptr,
          a9: v39);
  if ( v24 == -3 || (++*((_QWORD *)v17 + 454), v24 == 0) ) /*0x1039c82bb*/
  {
    if ( (unsigned __int64)(RakNet::GetTime(this: nullptr, a2: v23) - Time) < 0x65 ) /*0x1039c82da*/
      goto LABEL_35; /*0x1039c82da*/
    v25 = *((_DWORD *)v9 + 82); /*0x1039c82e0*/
    v26 = (__int64)(*((_QWORD *)v17 + 249) - *((_QWORD *)v17 + 248)) >> 2; /*0x1039c82f5*/
    if ( (int)(v25 / v26 * (v26 - 1)) <= *((unsigned __int8 *)v9 + 40) ) /*0x1039c8314*/
    {
      *((_BYTE *)v9 + 40) = v25 + 1; /*0x1039c83b0*/
      goto LABEL_35; /*0x1039c83b4*/
    }
    *((_BYTE *)v9 + 40) = v25 / v26 * (v26 - 1); /*0x1039c831a*/
  }
  else
  {
    if ( v24 == -4 ) /*0x1039c82c1*/
      ++*((_QWORD *)v17 + 455); /*0x1039c82c3*/
    else
      ++*((_QWORD *)v17 + 456); /*0x1039c8323*/
    v49 = *__error(); /*0x1039c8331*/
    RakNet::SystemAddress::ToStringN(this: v9, a2: false, a3: v50, a4: 1025, a5: 124); /*0x1039c834e*/
    if ( *((_BYTE *)v9 + 40) == 1 ) /*0x1039c8358*/
    {
      v27 = FLog::Network; /*0x1039c8365*/
      if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1039c8378*/
      {
        v48 = qword_10D7BBAA8; /*0x1039c8383*/
        RBX::systemErrorToString(this: (RBX *)&v45, a2: v49); /*0x1039c8397*/
        if ( (v45 & 1) != 0 ) /*0x1039c83a3*/
          LODWORD(v29) = (_DWORD)v47; /*0x1039c83a5*/
        else
          v29 = v46; /*0x1039c83b9*/
        FLog::FastLogFormatted( /*0x1039c83da*/
          a1: v27,
          a2: v48,
          a3: (unsigned int)"[FLog::Network] Socket send OpenRequest1 failed. Tried to connect to %s, %s",
          a4: (unsigned int)v50,
          a5: (_DWORD)v29,
          a6: v28);
        if ( (v45 & 1) != 0 ) /*0x1039c83e6*/
          operator delete(a1: v47); /*0x1039c83ef*/
      }
    }
    v30 = (int)DFLog::RakNetConnectTrace; /*0x1039c83f4*/
    if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u ) /*0x1039c840a*/
    {
      v48 = qword_10D7BB0C8; /*0x1039c8418*/
      RBX::systemErrorToString(this: (RBX *)&v45, a2: v49); /*0x1039c842c*/
      if ( (v45 & 1) != 0 ) /*0x1039c8438*/
        LODWORD(v32) = (_DWORD)v47; /*0x1039c843a*/
      else
        v32 = v46; /*0x1039c8443*/
      FLog::FastLogFormatted( /*0x1039c8464*/
        a1: v30,
        a2: v48,
        a3: (unsigned int)"[DFLog::RakNetConnectTrace] Socket send OpenRequest1 failed. Tried to connect to %s, %s",
        a4: (unsigned int)v50,
        a5: (_DWORD)v32,
        a6: v31);
      if ( (v45 & 1) != 0 ) /*0x1039c8470*/
        operator delete(a1: v47); /*0x1039c8479*/
    }
    *((_BYTE *)v9 + 40) = (v13 + 1) /*0x1039c84a3*/
                        * (*((unsigned int *)v9 + 82)
                         / (unsigned __int64)((__int64)(*((_QWORD *)v17 + 249) - *((_QWORD *)v17 + 248)) >> 2));
  }
  *((_QWORD *)v9 + 4) = *v44; /*0x1039c84b1*/
LABEL_35:
  v33 = *v41; /*0x1039c84b5*/
  v34 = RakNet::SystemAddress::GetIPPROTO(this: (RakNet::SystemAddress *)(v41 + 2)); /*0x1039c84c3*/
  RakNet::SocketLayer::SetDoNotFragment(this: (RakNet::SocketLayer *)v33, a2: 0, a3: v34, a4: v35); /*0x1039c84cf*/
  if ( v24 == 0 || v24 == -3 ) /*0x1039c84dd*/
  {
    RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)v17 + 3232)); /*0x1039c84e9*/
    ++*((_DWORD *)v17 + 800); /*0x1039c84ee*/
    RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)v17 + 3232)); /*0x1039c84f7*/
    if ( *((_BYTE *)v17 + 3712) == 0 ) /*0x1039c850e*/
    {
      *((_BYTE *)v17 + 3712) = 1; /*0x1039c8510*/
      _InterlockedExchange((volatile __int32 *)v17 + 927, RakNet::GetTime(this: nullptr, a2: v36)); /*0x1039c851e*/
    }
  }
  v37 = v42; /*0x1039c8524*/
  if ( v42 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v42 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039c8540*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v37 + 16LL))(a1: v37); /*0x1039c8548*/
    std::__shared_weak_count::__release_weak(this: v37); /*0x1039c854e*/
  }
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v51); /*0x1039c855a*/
  return __stack_chk_guard; /*0x1039c856f*/
}

// Address: 0x1039c85de | Name: __ZN6RakNet7RakPeer21createRbxOpenRequest1ERNS_9BitStreamEmPKNS0_25RequestedConnectionStructE
__int64 __fastcall RakNet::RakPeer::createRbxOpenRequest1(__int64 a1, RakNet::BitStream *a2, unsigned int a3)
{
  unsigned __int8 v6[24]; // [rsp+10h] [rbp-40h] BYREF
  unsigned __int8 v7[16]; // [rsp+28h] [rbp-28h] BYREF

  v7[0] = 123; /*0x1039c85f5*/
  RakNet::BitStream::WriteBits(this: a2, a2: v7, a3: 8u, a4: true); /*0x1039c8609*/
  RakNet::BitStream::WriteAlignedBytes(this: a2, a2: &OFFLINE_MESSAGE_DATA_ID, a3: 0x10u); /*0x1039c861d*/
  v7[0] = 5; /*0x1039c8622*/
  RakNet::BitStream::WriteBits(this: a2, a2: v7, a3: 8u, a4: true); /*0x1039c8637*/
  if ( (unsigned __int8)DFLog::Rupp >= 6u && BYTE1(DFLog::Rupp) >= 5u ) /*0x1039c8651*/
  {
    *(_QWORD *)v7 = 0; /*0x1039c865f*/
    *(_QWORD *)&v7[8] = v6; /*0x1039c866b*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x1039c868f*/
      a1: DFLog::Rupp,
      a2: qword_10D7BB258,
      a3: 5,
      a4: (unsigned int)"[DFLog::Rupp] Client opt in to receiving Rupp headers.",
      a5: 54,
      a6: 1,
      0,
      v6);
  }
  v7[0] = 1; /*0x1039c8698*/
  RakNet::BitStream::WriteBits(this: a2, a2: v7, a3: 8u, a4: true); /*0x1039c86a8*/
  return RakNet::BitStream::PadWithZeroToByteLength(this: a2, a2: a3); /*0x1039c86b7*/
}

// Address: 0x1039c86c2 | Name: __ZN6RakNet7RakPeer30HandleRequestedConnectionQueueERKyS2_
__int64 __fastcall RakNet::RakPeer::HandleRequestedConnectionQueue(
        RakNet::RakPeer *this,
        const unsigned __int64 *a2,
        unsigned __int64 *a3)
{
  RakNet::RakPeer *v4; // r15
  RakNet::SimpleMutex *v5; // rbx
  unsigned int v6; // r12d
  unsigned int v7; // eax
  unsigned int v8; // edx
  bool v9; // cf
  unsigned int v10; // edx
  unsigned int v11; // eax
  unsigned int v12; // ecx
  __int64 v13; // rdx
  const unsigned __int64 *v14; // r15
  __int64 v15; // r14
  int v16; // r8d
  int v17; // r9d
  __int64 v18; // r12
  int v19; // eax
  int v20; // r14d
  bool v21; // bl
  char v22; // al
  int v23; // ecx
  void *v24; // rsi
  int v25; // r8d
  int v26; // r9d
  char v27; // r13
  RBX::Memory *v28; // rdi
  RBX::SystemUtil *v29; // rdi
  bool v30; // al
  const char *v31; // rcx
  _DWORD *v32; // rax
  unsigned __int64 NumOpenFiles; // rax
  void *v34; // rdx
  __int64 v35; // r13
  __int64 v36; // rdi
  unsigned int v37; // eax
  unsigned int v38; // esi
  unsigned int v39; // edi
  unsigned int v40; // r8d
  void *v42[9]; // [rsp+10h] [rbp-280h] BYREF
  _BYTE v43[472]; // [rsp+58h] [rbp-238h] BYREF
  __int64 v44; // [rsp+230h] [rbp-60h]
  void **v45; // [rsp+238h] [rbp-58h]
  __int64 v46; // [rsp+240h] [rbp-50h]
  RakNet::RakPeer *v47; // [rsp+248h] [rbp-48h]
  RakNet::SimpleMutex *v48; // [rsp+250h] [rbp-40h]
  unsigned __int64 *v49; // [rsp+258h] [rbp-38h]
  int v50; // [rsp+260h] [rbp-30h]
  unsigned int v51; // [rsp+264h] [rbp-2Ch]

  v4 = this; /*0x1039c86d9*/
  v5 = (RakNet::RakPeer *)((char *)this + 1160); /*0x1039c86dc*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1160)); /*0x1039c86e6*/
  v46 = (__int64)v4 + 1136; /*0x1039c86f2*/
  v6 = 0; /*0x1039c86f9*/
  v48 = v5; /*0x1039c86fc*/
  v49 = a3; /*0x1039c8700*/
  v47 = v4; /*0x1039c8704*/
  while ( 1 )
  {
    v7 = *((_DWORD *)v4 + 286); /*0x1039c8708*/
    v8 = *((_DWORD *)v4 + 287); /*0x1039c8716*/
    v9 = v8 < v7; /*0x1039c8718*/
    v10 = v8 - v7; /*0x1039c8718*/
    if ( v9 ) /*0x1039c871a*/
      v10 = *((_DWORD *)v4 + 288) + *((_DWORD *)v4 + 287) - v7; /*0x1039c8725*/
    if ( v6 >= v10 ) /*0x1039c872a*/
      return RakNet::SimpleMutex::Unlock(this: v5); /*0x1039c8ac5*/
    v11 = v6 + v7; /*0x1039c8730*/
    v12 = *((_DWORD *)v4 + 288); /*0x1039c8733*/
    v13 = *((_QWORD *)v4 + 142); /*0x1039c873c*/
    if ( v11 < v12 ) /*0x1039c8743*/
      v12 = 0; /*0x1039c8743*/
    v14 = a3; /*0x1039c8749*/
    v15 = *(_QWORD *)(v13 + 8LL * (v11 - v12)); /*0x1039c874c*/
    RakNet::SimpleMutex::Unlock(this: v5); /*0x1039c8753*/
    if ( *(_QWORD *)(v15 + 32) >= *v14 )
    {
      a3 = (unsigned __int64 *)v14; /*0x1039c8880*/
      ++v6; /*0x1039c8883*/
      v4 = v47; /*0x1039c8886*/
    }
    else
    {
      v51 = v6; /*0x1039c8765*/
      v18 = v15; /*0x1039c8783*/
      if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
        FLog::FastLogFormatted(
          a1: (_DWORD)DFLog::RakNetConnectTrace,
          a2: qword_10D7BB0C8,
          a3: (unsigned int)"[DFLog::RakNetConnectTrace] RakNet : OpenRequest1 next request time triggered, requestsMade %u",
          a4: *(unsigned __int8 *)(v15 + 40),
          a5: v16,
          a6: v17);
      v19 = *(unsigned __int8 *)(v15 + 40); /*0x1039c87a3*/
      v20 = *(_DWORD *)(v15 + 328) + 1; /*0x1039c87b1*/
      v50 = v19; /*0x1039c87b4*/
      v21 = v20 == v19; /*0x1039c87ba*/
      v22 = RakNet::SystemAddress::operator==(a1: v18, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS); /*0x1039c87c7*/
      v4 = v47; /*0x1039c87d1*/
      if ( (v22 & 1 | v21) != 0 )
      {
        v27 = v22; /*0x1039c87db*/
        v28 = *(RBX::Memory **)(v18 + 48); /*0x1039c87de*/
        if ( v28 != nullptr ) /*0x1039c87e6*/
        {
          RBX::Memory::deallocate(this: v28, a2: v24); /*0x1039c87e8*/
          *(_QWORD *)(v18 + 48) = 0; /*0x1039c87ed*/
        }
        if ( (v27 & 1 | (v20 != v50)) == 0 && *(_DWORD *)(v18 + 380) == 1 )
        {
          v29 = DFLog::RakNetConnectTrace; /*0x1039c8817*/
          v30 = (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u; /*0x1039c882f*/
          if ( DFFlag::AddRakNetDebugLogs == 1 )
          {
            if ( v30 ) /*0x1039c8843*/
            {
              v31 = "client"; /*0x1039c8858*/
              if ( *((_BYTE *)v4 + 3728) != 0 ) /*0x1039c8866*/
                v31 = "server"; /*0x1039c8866*/
              FLog::FastLogFormatted( /*0x1039c8879*/
                a1: (_DWORD)DFLog::RakNetConnectTrace,
                a2: qword_10D7BB0C8,
                a3: (unsigned int)"[DFLog::RakNetConnectTrace] (%s) RakNet connection failed after too many attempts. Made %d requests.",
                a4: (_DWORD)v31,
                a5: *(unsigned __int8 *)(v18 + 40),
                a6: v26);
            }
          }
          else if ( v30 )
          {
            LOBYTE(v23) = (unsigned __int8)DFLog::RakNetConnectTrace >= 6u; /*0x1039c8827*/
            FLog::FastLogFormatted(
              a1: (_DWORD)DFLog::RakNetConnectTrace,
              a2: qword_10D7BB0C8,
              a3: (unsigned int)"[DFLog::RakNetConnectTrace] RakNet : Too many attempts tries : timed out, inform failure",
              a4: v23,
              a5: v25,
              a6: v26);
          }
          v32 = *(_DWORD **)(v18 + 344); /*0x1039c88d4*/
          if ( v32 != nullptr && *v32 >= 0x400u ) /*0x1039c88eb*/
          {
            NumOpenFiles = RBX::SystemUtil::getNumOpenFiles(this: v29); /*0x1039c88f1*/
            if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u ) /*0x1039c890c*/
            {
              v34 = (void *)**(unsigned int **)(v18 + 344); /*0x1039c892b*/
              v42[2] = (void *)HIDWORD(NumOpenFiles); /*0x1039c8934*/
              v42[4] = v34; /*0x1039c893b*/
              v44 = 529; /*0x1039c8942*/
              v45 = v42; /*0x1039c894a*/
              FLog::detail::FastLogSafeFormattedInternal( /*0x1039c896e*/
                a1: (_DWORD)DFLog::RakNetConnectTrace,
                a2: qword_10D7BB0C8,
                a3: 3,
                a4: (unsigned int)"[DFLog::RakNetConnectTrace] Current file descriptor count is {}, limit {}, fd {}",
                a5: 80,
                a6: 1,
                529,
                v42,
                (unsigned int)NumOpenFiles);
            }
            RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1039c897d*/
              a1: v42,
              a2: (__int64)&RBX::Telemetry::kNetConnectErrorHighFdCount);
            RBX::Telemetry::FieldsContainer::addArchitectureInfo(this: (RBX::Telemetry::FieldsContainer *)v43); /*0x1039c8989*/
            RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v42); /*0x1039c8991*/
            RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v43); /*0x1039c89a8*/
            RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v42, a2: (void **)off_10C8C7EB0); /*0x1039c89b4*/
          }
          v35 = RakNet::RakPeer::AllocPacket(this: v4, a2: 1u, a3: "", a4: 0); /*0x1039c89cf*/
          **(_BYTE **)(v35 + 56) = 4 * *(_BYTE *)(v18 + 324) + 13; /*0x1039c89e3*/
          *(_DWORD *)(v35 + 52) = 8; /*0x1039c89e5*/
          RakNet::SystemAddress::operator=(a1: v35, a2: v18); /*0x1039c89f3*/
          RakNet::RakPeer::AddPacketToProducer(this: v4, a2: v35, a3: 0); /*0x1039c8a00*/
          v36 = *((_QWORD *)v4 + 423); /*0x1039c8a05*/
          if ( v36 != 0 ) /*0x1039c8a0f*/
            (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v36 + 48LL))(a1: v36, a2: v18); /*0x1039c8a17*/
        }
        std::shared_ptr<RBX::Security::RakPeerCrypto>::~shared_ptr[abi:ne200100](a1: v18 + 360); /*0x1039c8a22*/
        std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: v18 + 344); /*0x1039c8a2f*/
        operator delete(a1: (void *)v18); /*0x1039c8a37*/
        v5 = v48; /*0x1039c8a3c*/
        RakNet::SimpleMutex::Lock(this: v48); /*0x1039c8a43*/
        v37 = *((_DWORD *)v4 + 286); /*0x1039c8a48*/
        v38 = 0; /*0x1039c8a5a*/
        a3 = v49; /*0x1039c8a5c*/
        while ( 1 ) /*0x1039c8a63*/
        {
          v39 = *((_DWORD *)v4 + 287) - v37; /*0x1039c8a63*/
          if ( *((_DWORD *)v4 + 287) < v37 ) /*0x1039c8a67*/
            v39 = *((_DWORD *)v4 + 287) - v37 + *((_DWORD *)v4 + 288); /*0x1039c8a70*/
          if ( v38 >= v39 ) /*0x1039c8a74*/
            break; /*0x1039c8a74*/
          v40 = *((_DWORD *)v4 + 288); /*0x1039c8a79*/
          if ( v37 + v38 < v40 ) /*0x1039c8a83*/
            v40 = 0; /*0x1039c8a83*/
          if ( *(_QWORD *)(*((_QWORD *)v4 + 142) + 8LL * (v37 + v38 - v40)) == v18 ) /*0x1039c8a95*/
          {
            DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::RemoveAtIndex(a1: v46, a2: v38); /*0x1039c8a9f*/
            break; /*0x1039c8a9f*/
          }
          ++v38; /*0x1039c8a97*/
        }
        RakNet::SimpleMutex::Unlock(this: v5); /*0x1039c8aa4*/
        v6 = v51; /*0x1039c8aac*/
      }
      else
      {
        a3 = v49; /*0x1039c8895*/
        RakNet::RakPeer::sendRbxOpenRequest1(this: v47, a2: (volatile signed __int64 **)v18, a3: v49); /*0x1039c889c*/
        v6 = v51 + 1; /*0x1039c88a5*/
        v5 = v48; /*0x1039c88a8*/
      }
    }
    RakNet::SimpleMutex::Lock(this: v5); /*0x1039c8ab3*/
  }
}

// Address: 0x1039c8aee | Name: __ZN6RakNet7RakPeer22HandleUnverifiedSenderEPNS0_18RemoteSystemStructERKNS_13SystemAddressEPhj
__int64 __fastcall RakNet::RakPeer::HandleUnverifiedSender(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        const RakNet::SystemAddress *a3,
        char *a4,
        unsigned int a5)
{
  void *v9; // rsi
  unsigned int TimeoutTime; // eax
  void *v12; // rsi
  _BYTE v13[88]; // [rsp+8h] [rbp-58h] BYREF

  if ( *a4 == 9 ) /*0x1039c8b0e*/
  {
    RakNet::RakPeer::ParseConnectionRequestPacket(this, a2, a3, a4, a5); /*0x1039c8b1c*/
    return RBX::Memory::deallocate(this: (RBX::Memory *)a4, a2: v9); /*0x1039c8b32*/
  }
  else
  {
    RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v13, a2: a3); /*0x1039c8b41*/
    RakNet::RakPeer::CloseConnectionInternal(this, a2: (RakNet::AddressOrGUID *)v13, a3: 0, a4: 1); /*0x1039c8b56*/
    TimeoutTime = RakNet::ReliabilityLayer::GetTimeoutTime(this: (RakNet::RakPeer::RemoteSystemStruct *)((char *)a2 + 392)); /*0x1039c8b65*/
    (*(void (__fastcall **)(RakNet::RakPeer *, const RakNet::SystemAddress *, _QWORD))(*(_QWORD *)this + 304LL))( /*0x1039c8b75*/
      a1: this,
      a2: a3,
      a3: TimeoutTime);
    return RBX::Memory::deallocate(this: (RBX::Memory *)a4, a2: v12); /*0x1039c8b7e*/
  }
}

// Address: 0x1039c8b92 | Name: __ZN6RakNet7RakPeer25HandleIDConnectionRequestEPNS0_18RemoteSystemStructERKNS_13SystemAddressEPhj
__int64 __fastcall RakNet::RakPeer::HandleIDConnectionRequest(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        const RakNet::SystemAddress *a3,
        char *a4,
        unsigned int a5)
{
  void *v8; // rsi
  unsigned int v9; // ecx
  RakNet::BitStream *v11; // rdi
  unsigned __int8 v12[8]; // [rsp+8h] [rbp-158h] BYREF
  unsigned __int8 v13[296]; // [rsp+10h] [rbp-150h] BYREF
  unsigned __int8 v14[8]; // [rsp+138h] [rbp-28h] BYREF

  if ( *((_DWORD *)a2 + 1341) == 4 ) /*0x1039c8bc0*/
  {
    RakNet::RakPeer::ParseConnectionRequestPacket(this, a2, a3, a4, a5); /*0x1039c8bcb*/
  }
  else
  {
    RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v13, a2: (unsigned __int8 *)a4, a3: a5, a4: false); /*0x1039c8be4*/
    RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v13, a2: 1u); /*0x1039c8bf5*/
    RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v13, a2: 0x10u); /*0x1039c8c06*/
    RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)v13, a2: 8u); /*0x1039c8c17*/
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c8cdc*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v11); /*0x1039c8ce7*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c8cf4*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c8c31*/
    {
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v13, a2: v12, a3: 0x40u, a4: true); /*0x1039c8c4b*/
    }
    else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v13, a2: v14, a3: 0x40u, a4: true) != 0 ) /*0x1039c8c6e*/
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v14, a2: v12, a3: (unsigned __int8 *)8, a4: v9); /*0x1039c8c80*/
    }
    RakNet::RakPeer::OnConnectionRequest(this, a2, a3: *(__int64 *)v12); /*0x1039c8c92*/
    RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v13); /*0x1039c8c9e*/
  }
  RBX::Memory::deallocate(this: (RBX::Memory *)a4, a2: v8); /*0x1039c8ca6*/
  return __stack_chk_guard; /*0x1039c8cbb*/
}

// Address: 0x1039c8d2e | Name: __ZN6RakNet7RakPeer29HandleIDNewIncomingConnectionEPNS0_18RemoteSystemStructERKNS_13SystemAddressEPhjj
__int64 __fastcall RakNet::RakPeer::HandleIDNewIncomingConnection(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        const RakNet::SystemAddress *a3,
        unsigned __int8 *a4,
        __int64 a5,
        __int64 a6)
{
  unsigned int v6; // r13d
  __int128 v10; // xmm0
  __int64 i; // rbx
  char *v12; // rsi
  RakNet::RakPeer *v13; // rbx
  unsigned __int8 *v14; // r15
  unsigned int v15; // r12d
  unsigned int v16; // ecx
  unsigned int v17; // ecx
  unsigned int v18; // ecx
  __int64 v19; // r15
  __int16 v20; // ax
  RakNet::BitStream *v22; // rdi
  RakNet::BitStream *v23; // rdi
  RakNet::BitStream *v24; // rdi
  unsigned __int8 v25[2]; // [rsp+20h] [rbp-1C0h] BYREF
  unsigned __int8 v26[2]; // [rsp+22h] [rbp-1BEh] BYREF
  int v27; // [rsp+24h] [rbp-1BCh]
  __int16 v28; // [rsp+3Ch] [rbp-1A4h]
  const RakNet::SystemAddress *v29; // [rsp+40h] [rbp-1A0h]
  unsigned __int8 v30[8]; // [rsp+48h] [rbp-198h] BYREF
  int v31; // [rsp+54h] [rbp-18Ch]
  unsigned __int8 v32[8]; // [rsp+58h] [rbp-188h] BYREF
  RakNet::RakPeer *v33; // [rsp+60h] [rbp-180h]
  unsigned __int8 *v34; // [rsp+68h] [rbp-178h]
  unsigned __int8 v35[8]; // [rsp+70h] [rbp-170h] BYREF
  unsigned int v36; // [rsp+7Ch] [rbp-164h]
  _OWORD v37[18]; // [rsp+80h] [rbp-160h] BYREF
  unsigned __int8 v38[8]; // [rsp+1A8h] [rbp-38h] BYREF

  if ( *((_DWORD *)a2 + 1341) == 5 ) /*0x1039c8d57*/
  {
    v6 = a5; /*0x1039c8d5d*/
    v31 = a6; /*0x1039c8d69*/
    *((_DWORD *)a2 + 1341) = 7; /*0x1039c8d70*/
    v10 = *(_OWORD *)a3; /*0x1039c8d7a*/
    v29 = a3; /*0x1039c8d7d*/
    v37[1] = *((_OWORD *)a3 + 1); /*0x1039c8d8f*/
    v37[0] = v10; /*0x1039c8d94*/
    RakNet::RakPeer::SendPings(this, a2: 0, (__int64)a3, (__int64)a4, a5, a6, a7: v10); /*0x1039c8dac*/
    RakNet::SignaledEvent::SetEvent(this: (RakNet::RakPeer *)((char *)this + 2560)); /*0x1039c8db8*/
    RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v37, a2: a4, a3: v6, a4: false); /*0x1039c8dc8*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v25); /*0x1039c8dd4*/
    RakNet::BitStream::IgnoreBits(this: (RakNet::BitStream *)v37, a2: 8u); /*0x1039c8de5*/
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: v35, a3: 8u, a4: true); /*0x1039c8e02*/
    if ( v35[0] == 4 ) /*0x1039c8e0e*/
    {
      v25[1] = 2; /*0x1039c8e10*/
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: v38, a3: 0x20u, a4: true); /*0x1039c8e2c*/
      v27 = ~*(_DWORD *)v38; /*0x1039c8e3d*/
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: v26, a3: 0x10u, a4: true); /*0x1039c8e51*/
      v28 = __ROL2__(*(_WORD *)v26, 8); /*0x1039c8e61*/
    }
    v36 = v6; /*0x1039c8e68*/
    v34 = a4; /*0x1039c8e6f*/
    v33 = this; /*0x1039c8e76*/
    for ( i = -320; i != 0; i += 32 ) /*0x1039c8e7d*/
    {
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: v35, a3: 8u, a4: true); /*0x1039c8ea6*/
      if ( v35[0] == 4 ) /*0x1039c8eb2*/
      {
        *((_BYTE *)a2 + i + 389) = 2; /*0x1039c8eb4*/
        RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: v38, a3: 0x20u, a4: true); /*0x1039c8ecd*/
        v12 = (char *)a2 + i + 390; /*0x1039c8edb*/
        *(_DWORD *)(v12 + 2) = ~*(_DWORD *)v38; /*0x1039c8ee2*/
        RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: (unsigned __int8 *)v12, a3: 0x10u, a4: true); /*0x1039c8ef2*/
        *(_WORD *)((char *)a2 + i + 416) = __ROL2__(*(_WORD *)((char *)a2 + i + 390), 8); /*0x1039c8f04*/
      }
    }
    *(_QWORD *)v32 = 0; /*0x1039c8f13*/
    v13 = v33; /*0x1039c8f26*/
    v14 = v34; /*0x1039c8f2d*/
    v15 = v36; /*0x1039c8f34*/
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c9155*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v22); /*0x1039c9160*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c916d*/
      v13 = v33; /*0x1039c9172*/
      v14 = v34; /*0x1039c9179*/
      v15 = v36; /*0x1039c9180*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c8f48*/
    {
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: v35, a3: 0x40u, a4: true); /*0x1039c8f62*/
    }
    else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: v38, a3: 0x40u, a4: true) != 0 ) /*0x1039c8f85*/
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v38, a2: v35, a3: (unsigned __int8 *)8, a4: v16); /*0x1039c8f97*/
    }
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c919a*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v23); /*0x1039c91a5*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c91b2*/
      v13 = v33; /*0x1039c91b7*/
      v14 = v34; /*0x1039c91be*/
      v15 = v36; /*0x1039c91c5*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c8fb1*/
    {
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: v30, a3: 0x40u, a4: true); /*0x1039c8fcb*/
    }
    else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: v38, a3: 0x40u, a4: true) != 0 ) /*0x1039c8fee*/
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v38, a2: v30, a3: (unsigned __int8 *)8, a4: v17); /*0x1039c9000*/
    }
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c91df*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v24); /*0x1039c91ea*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c91f7*/
      v13 = v33; /*0x1039c91fc*/
      v14 = v34; /*0x1039c9203*/
      v15 = v36; /*0x1039c920a*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c901a*/
    {
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: v32, a3: 0x40u, a4: true); /*0x1039c9034*/
    }
    else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v37, a2: v38, a3: 0x40u, a4: true) != 0 ) /*0x1039c9057*/
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v38, a2: v32, a3: (unsigned __int8 *)8, a4: v18); /*0x1039c9069*/
    }
    RakNet::RakPeer::OnConnectedPong( /*0x1039c908c*/
      a1: (__int64)v13,
      a2: *(_BOOL8 *)v35,
      a3: *(__int64 *)v30,
      a4: *(unsigned __int64 *)v32,
      a5: (__int64)a2,
      a6: 0);
    RakNet::SystemAddress::operator=(a1: (char *)v13 + 2112, a2: v25); /*0x1039c909f*/
    *((_WORD *)v13 + 1070) = __ROL2__(*((_WORD *)v13 + 1057), 8); /*0x1039c90af*/
    v19 = RakNet::RakPeer::AllocPacket(this: v13, a2: v15, a3: v14, a4: "", a5: 0); /*0x1039c90ce*/
    *(_DWORD *)(v19 + 52) = v31; /*0x1039c90d7*/
    RakNet::SystemAddress::operator=(a1: v19, a2: v29); /*0x1039c90e5*/
    v20 = *((_WORD *)a2 + 2624); /*0x1039c90ea*/
    *(_WORD *)(v19 + 30) = v20; /*0x1039c90f2*/
    *(_QWORD *)(v19 + 32) = *((_QWORD *)a2 + 650); /*0x1039c90fe*/
    *(_WORD *)(v19 + 40) = v20; /*0x1039c9102*/
    RakNet::RakPeer::AddPacketToProducer(this: v13, a2: v19, a3: 0); /*0x1039c910f*/
    RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v37); /*0x1039c911b*/
  }
  return __stack_chk_guard; /*0x1039c9130*/
}

// Address: 0x1039c92d0 | Name: __ZNK6RakNet7RakPeer18reportRakPingTraceEyyy14PacketPriorityRKy
void __fastcall RakNet::RakPeer::reportRakPingTrace(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        unsigned __int64 a4,
        int a5,
        _QWORD *a6)
{
  RBX::Network::NetworkTracer *v9; // rdi
  __int64 TracerObject; // rax
  RBX::Network::NetworkTracerObject *v11; // r14
  char *v12; // rcx
  __int64 v13; // r8
  unsigned __int8 v14; // al
  _BYTE v15[72]; // [rsp+8h] [rbp-2B8h] BYREF
  _BYTE v16[528]; // [rsp+50h] [rbp-270h] BYREF
  _QWORD v17[3]; // [rsp+260h] [rbp-60h] BYREF
  unsigned __int8 v18; // [rsp+278h] [rbp-48h] BYREF
  char v19; // [rsp+279h] [rbp-47h] BYREF
  __int64 v20; // [rsp+280h] [rbp-40h]
  void *v21; // [rsp+288h] [rbp-38h]
  int v22; // [rsp+294h] [rbp-2Ch] BYREF

  v22 = a5; /*0x1039c92e4*/
  if ( *a6 - a2 >= (unsigned __int64)DFInt::RakNetPingTraceReportThresholdMS )
  {
    v9 = RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0
       ? *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24)
       : nullptr;
    TracerObject = RBX::Network::NetworkTracer::getTracerObject(this: v9, a2: a4); /*0x1039c931e*/
    if ( TracerObject != 0 ) /*0x1039c9326*/
    {
      v11 = (RBX::Network::NetworkTracerObject *)TracerObject; /*0x1039c932c*/
      RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1039c933d*/
        a1: (__int64)v15,
        a2: (__int64)&RBX::Telemetry::kRakNetPingTracePoints);
      v17[0] = &v22; /*0x1039c934a*/
      v17[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<PacketPriority,fmt::v8::formatter<PacketPriority,char,void>>; /*0x1039c9354*/
      fmt::v8::vformat(a1: &v18, a2: "{}", a3: 2, a4: 15, a5: v17); /*0x1039c936d*/
      if ( (v18 & 1) != 0 ) /*0x1039c9382*/
      {
        v12 = (char *)v21; /*0x1039c9384*/
        v13 = v20; /*0x1039c9388*/
      }
      else
      {
        v13 = v18 >> 1; /*0x1039c938e*/
        v12 = &v19; /*0x1039c9391*/
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "Priority", a3: 8, a4: v12, a5: v13, a6: 1); /*0x1039c93aa*/
      if ( (v18 & 1) != 0 ) /*0x1039c93b3*/
        operator delete(a1: v21); /*0x1039c93b9*/
      RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "RTT", a3: 3, a4: *a6 - a2, a5: 1); /*0x1039c93d9*/
      v14 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 200LL))(a1); /*0x1039c93e4*/
      RBX::Network::NetworkTracerObject::addCheckpointIntervalPoints( /*0x1039c93f7*/
        this: v11,
        a2: v14,
        a3: (RBX::Telemetry::RobloxTelemetryEvent *)v15);
      RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v15); /*0x1039c9403*/
      RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v15); /*0x1039c9416*/
    }
  }
}

// Address: 0x1039c9462 | Name: __ZN6RakNet7RakPeer21HandleIDConnectedPongEPNS0_18RemoteSystemStructEPhjbyRKy
__int64 __fastcall RakNet::RakPeer::HandleIDConnectedPong(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        unsigned __int8 *a3,
        unsigned int a4,
        int a5,
        unsigned __int64 a6)
{
  unsigned int v10; // ecx
  unsigned int v11; // ecx
  unsigned int v12; // ecx
  unsigned int v13; // eax
  unsigned int v14; // r14d
  RakNet *v15; // rdi
  void *v16; // rsi
  __int64 TimeMS; // rbx
  RBX::Network *v18; // rdi
  __int64 v19; // rdx
  __int64 v20; // rsi
  __int64 v21; // rbx
  __int64 v22; // r13
  unsigned __int8 v23; // al
  __int64 v24; // rdx
  unsigned __int8 v25; // al
  RBX::Network::NetworkTracer *v26; // rdi
  bool v27; // si
  __int64 Time; // rax
  __int64 v29; // rcx
  RakNet::BitStream *v31; // rdi
  RakNet::BitStream *v32; // rdi
  RakNet::BitStream *v33; // rdi
  unsigned __int8 v34[8]; // [rsp+0h] [rbp-190h] BYREF
  RakNet::RakPeer::RemoteSystemStruct *v35; // [rsp+8h] [rbp-188h]
  unsigned __int8 v36[8]; // [rsp+10h] [rbp-180h] BYREF
  unsigned __int8 v37[8]; // [rsp+18h] [rbp-178h] BYREF
  RBX::Memory *v38; // [rsp+20h] [rbp-170h]
  int v39; // [rsp+2Ch] [rbp-164h]
  unsigned __int8 v40[296]; // [rsp+30h] [rbp-160h] BYREF
  unsigned __int8 v41[8]; // [rsp+158h] [rbp-38h] BYREF

  v35 = a2; /*0x1039c947f*/
  *(_QWORD *)v37 = 0; /*0x1039c9497*/
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v40, a2: a3, a3: a4, a4: false); /*0x1039c94b0*/
  RakNet::BitStream::IgnoreBits(this: (RakNet::BitStream *)v40, a2: 8u); /*0x1039c94c1*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c97da*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v31); /*0x1039c97e5*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c97f2*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c94db*/
  {
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v40, a2: v36, a3: 0x40u, a4: true); /*0x1039c94f5*/
  }
  else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v40, a2: v41, a3: 0x40u, a4: true) != 0 ) /*0x1039c9518*/
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v41, a2: v36, a3: (unsigned __int8 *)8, a4: v10); /*0x1039c952a*/
  }
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c980a*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v32); /*0x1039c9815*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c9822*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c9544*/
  {
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v40, a2: v34, a3: 0x40u, a4: true); /*0x1039c955e*/
  }
  else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v40, a2: v41, a3: 0x40u, a4: true) != 0 ) /*0x1039c9581*/
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v41, a2: v34, a3: (unsigned __int8 *)8, a4: v11); /*0x1039c9593*/
  }
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c983a*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v33); /*0x1039c9845*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c9852*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c95ad*/
  {
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v40, a2: v37, a3: 0x40u, a4: true); /*0x1039c95c7*/
  }
  else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v40, a2: v41, a3: 0x40u, a4: true) != 0 ) /*0x1039c95ea*/
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v41, a2: v37, a3: (unsigned __int8 *)8, a4: v12); /*0x1039c95fc*/
  }
  v13 = *a3; /*0x1039c9601*/
  if ( v13 > 0x54 ) /*0x1039c9608*/
  {
    if ( v13 == 85 ) /*0x1039c9630*/
    {
      v38 = (RBX::Memory *)a3; /*0x1039c9662*/
      v39 = a5; /*0x1039c9669*/
      v14 = 2; /*0x1039c966f*/
    }
    else
    {
      if ( v13 != 86 ) /*0x1039c9635*/
        goto LABEL_44; /*0x1039c9635*/
      v38 = (RBX::Memory *)a3; /*0x1039c963b*/
      v39 = a5; /*0x1039c9642*/
      v14 = 1; /*0x1039c9648*/
    }
  }
  else if ( v13 == 3 ) /*0x1039c960d*/
  {
    v38 = (RBX::Memory *)a3; /*0x1039c9650*/
    v39 = a5; /*0x1039c9657*/
    v14 = 0; /*0x1039c965d*/
  }
  else
  {
    if ( v13 != 84 ) /*0x1039c9612*/
      goto LABEL_44; /*0x1039c9612*/
    v38 = (RBX::Memory *)a3; /*0x1039c9618*/
    v39 = a5; /*0x1039c961f*/
    v14 = 3; /*0x1039c9625*/
  }
  RakNet::RakPeer::OnConnectedPong( /*0x1039c9697*/
    a1: (__int64)this,
    a2: *(_BOOL8 *)v36,
    a3: *(__int64 *)v34,
    a4: *(unsigned __int64 *)v37,
    a5: (__int64)v35,
    a6: v14);
  if ( a6 != 0 && DFFlag::RakNetPingTrace != 0 ) /*0x1039c96ac*/
  {
    TimeMS = (unsigned int)RakNet::GetTimeMS(this: v15); /*0x1039c96b7*/
    *(_QWORD *)v41 = TimeMS; /*0x1039c96b9*/
    if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v18) != 0 ) /*0x1039c96cb*/
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039c96d3*/
        v21 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039c96d5*/
      else
        v21 = 0; /*0x1039c96e6*/
      v23 = (*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64))(*(_QWORD *)this + 200LL))( /*0x1039c96eb*/
              a1: this,
              a2: v20,
              a3: v19,
              a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
      RBX::Network::NetworkTracer::addCheckpointToTracer(a1: v21, a2: a6, a3: v23, a4: 75); /*0x1039c96ff*/
    }
    else
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039c96de*/
        v22 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039c96e0*/
      else
        v22 = 0; /*0x1039c9706*/
      v25 = (*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64))(*(_QWORD *)this + 200LL))( /*0x1039c970f*/
              a1: this,
              a2: v20,
              a3: v19,
              a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
      RBX::Network::NetworkTracer::addCheckpointToTracer_deprecated(a1: v22, a2: a6, a3: v25, a4: 75, a5: TimeMS); /*0x1039c9726*/
    }
    RakNet::RakPeer::reportRakPingTrace(a1: (__int64)this, a2: *(__int64 *)v36, a3: v24, a4: a6, a5: v14, a6: v41); /*0x1039c973f*/
    if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039c974e*/
      v26 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039c9750*/
    else
      v26 = nullptr; /*0x1039c9756*/
    RBX::Network::NetworkTracer::removeTracerObject(this: v26, a2: a6); /*0x1039c975b*/
  }
  RBX::Memory::deallocate(this: v38, a2: v16); /*0x1039c9767*/
  if ( (_BYTE)v39 != 0 ) /*0x1039c9773*/
  {
    Time = RakNet::GetTime(this: nullptr, a2: v27); /*0x1039c9777*/
    v29 = 5152; /*0x1039c977c*/
  }
  else
  {
    Time = RakNet::GetTime(this: nullptr, a2: v27); /*0x1039c9785*/
    v29 = 5136; /*0x1039c978a*/
  }
  *(_QWORD *)((char *)v35 + v29) = Time; /*0x1039c9796*/
LABEL_44:
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v40); /*0x1039c979a*/
  return __stack_chk_guard; /*0x1039c97ba*/
}

// Address: 0x1039c9896 | Name: __ZN6RakNet7RakPeer21HandleIDConnectedPingEPNS0_18RemoteSystemStructERKNS_13SystemAddressEPhjby
__int64 __fastcall RakNet::RakPeer::HandleIDConnectedPing(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        const RakNet::SystemAddress *a3,
        RBX::Memory *a4,
        unsigned int a5,
        char a6,
        unsigned __int64 a7)
{
  unsigned int v10; // ecx
  unsigned int v11; // eax
  unsigned int v12; // ecx
  bool v13; // si
  unsigned int v14; // ecx
  RBX::Time *v15; // rdi
  __int64 v16; // rax
  unsigned int v17; // ecx
  RBX::Network *v18; // rdi
  __int64 v19; // rax
  __int64 v20; // rcx
  __int64 v21; // rdx
  __int64 v22; // rdx
  __int64 v23; // rsi
  __int64 v24; // rbx
  __int64 v25; // r15
  unsigned __int8 v26; // al
  unsigned __int8 v27; // bl
  RakNet *v28; // rdi
  unsigned int TimeMS; // eax
  void *v30; // r12
  int v31; // r15d
  bool v32; // si
  unsigned __int64 TimeUS; // rax
  void *v34; // rsi
  RakNet::BitStream *v36; // rdi
  RakNet::BitStream *v37; // rdi
  RakNet::BitStream *v38; // rdi
  RakNet::BitStream *v39; // rdi
  unsigned __int8 v40[8]; // [rsp+38h] [rbp-2D8h] BYREF
  RBX::Memory *v41; // [rsp+40h] [rbp-2D0h]
  unsigned __int8 v42[8]; // [rsp+48h] [rbp-2C8h] BYREF
  unsigned __int8 v43[8]; // [rsp+50h] [rbp-2C0h] BYREF
  RakNet *v44; // [rsp+58h] [rbp-2B8h]
  bool v45[48]; // [rsp+60h] [rbp-2B0h] BYREF
  unsigned __int8 v46[12]; // [rsp+90h] [rbp-280h] BYREF
  int v47; // [rsp+9Ch] [rbp-274h]
  void *v48; // [rsp+A8h] [rbp-268h]
  _BYTE v49[296]; // [rsp+1B8h] [rbp-158h] BYREF

  v44 = this; /*0x1039c98b3*/
  v41 = a4; /*0x1039c98cf*/
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v49, a2: (unsigned __int8 *)a4, a3: a5, a4: false); /*0x1039c98de*/
  RakNet::BitStream::IgnoreBits(this: (RakNet::BitStream *)v49, a2: 8u); /*0x1039c98ef*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c9d36*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v36); /*0x1039c9d41*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c9d4e*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c9909*/
  {
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v49, a2: v42, a3: 0x40u, a4: true); /*0x1039c9923*/
  }
  else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v49, a2: v46, a3: 0x40u, a4: true) != 0 ) /*0x1039c9949*/
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v46, a2: v42, a3: (unsigned __int8 *)8, a4: v10); /*0x1039c995e*/
  }
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v46); /*0x1039c996a*/
  v11 = *(unsigned __int8 *)v41; /*0x1039c9976*/
  if ( v11 > 0x51 ) /*0x1039c997c*/
  {
    if ( v11 == 82 ) /*0x1039c99b0*/
    {
      v45[0] = 85; /*0x1039c9a06*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v46, a2: (const unsigned __int8 *)v45, a3: 8u, a4: true); /*0x1039c9a1a*/
    }
    else
    {
      if ( v11 != 83 ) /*0x1039c99b5*/
        goto LABEL_42; /*0x1039c99b5*/
      v45[0] = 86; /*0x1039c99c2*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v46, a2: (const unsigned __int8 *)v45, a3: 8u, a4: true); /*0x1039c99d6*/
    }
  }
  else if ( *(_BYTE *)v41 != 0 ) /*0x1039c9980*/
  {
    if ( v11 != 81 ) /*0x1039c9985*/
      goto LABEL_42; /*0x1039c9985*/
    v45[0] = 84; /*0x1039c9992*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v46, a2: (const unsigned __int8 *)v45, a3: 8u, a4: true); /*0x1039c99a6*/
  }
  else
  {
    v45[0] = 3; /*0x1039c99e4*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v46, a2: (const unsigned __int8 *)v45, a3: 8u, a4: true); /*0x1039c99f8*/
  }
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c9d6b*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v37); /*0x1039c9d76*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c9d83*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c9a34*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v46, a2: v42, a3: 0x40u, a4: true); /*0x1039c9a4e*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039c9a68*/
      this: (RakNet::BitStream *)v42,
      a2: (unsigned __int8 *)v45,
      a3: (unsigned __int8 *)8,
      a4: v12);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v46, a2: (const unsigned __int8 *)v45, a3: 0x40u, a4: true); /*0x1039c9a85*/
  }
  *(_QWORD *)v43 = RakNet::GetTime(this: nullptr, a2: v13); /*0x1039c9a91*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c9d9b*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v38); /*0x1039c9da6*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c9db3*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c9aad*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v46, a2: v43, a3: 0x40u, a4: true); /*0x1039c9ac7*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039c9ae1*/
      this: (RakNet::BitStream *)v43,
      a2: (unsigned __int8 *)v45,
      a3: (unsigned __int8 *)8,
      a4: v14);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v46, a2: (const unsigned __int8 *)v45, a3: 0x40u, a4: true); /*0x1039c9afe*/
  }
  v16 = RBX::Time::epochTimeNs(this: v15); /*0x1039c9b03*/
  v17 = -481036337; /*0x1039c9b08*/
  *(_QWORD *)v40 = ((unsigned __int64)((unsigned __int128)(0x20C49BA5E353F7CFLL * (__int128)v16) >> 64) >> 63) /*0x1039c9b23*/
                 + v16 / 1000;
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c9dcb*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v39); /*0x1039c9dd6*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c9de3*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c9b3f*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v46, a2: v40, a3: 0x40u, a4: true); /*0x1039c9b59*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039c9b73*/
      this: (RakNet::BitStream *)v40,
      a2: (unsigned __int8 *)v45,
      a3: (unsigned __int8 *)8,
      a4: v17);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v46, a2: (const unsigned __int8 *)v45, a3: 0x40u, a4: true); /*0x1039c9b90*/
  }
  if ( a6 != 0 ) /*0x1039c9b98*/
  {
    RakNet::BitStream::PadWithZeroToByteLength(this: (RakNet::BitStream *)v46, a2: *((_DWORD *)a2 + 1304) - 40); /*0x1039c9bac*/
    v19 = 5120; /*0x1039c9bb1*/
    v20 = 5144; /*0x1039c9bb6*/
  }
  else
  {
    v19 = 5112; /*0x1039c9bbd*/
    v20 = 5128; /*0x1039c9bc2*/
  }
  v21 = *(_QWORD *)v43; /*0x1039c9bcb*/
  *(_QWORD *)((char *)a2 + v20) = *(_QWORD *)v43; /*0x1039c9bd2*/
  *(_QWORD *)((char *)a2 + v19) = v21; /*0x1039c9bd6*/
  if ( a7 != 0 && DFFlag::RakNetPingTrace != 0 ) /*0x1039c9bea*/
  {
    if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v18) != 0 ) /*0x1039c9bfa*/
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039c9bff*/
        v24 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039c9c01*/
      else
        v24 = 0; /*0x1039c9c12*/
      v26 = (*(__int64 (__fastcall **)(RakNet *, __int64, __int64, __int64))(*(_QWORD *)v44 + 200LL))( /*0x1039c9c1e*/
              a1: v44,
              a2: v23,
              a3: v22,
              a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
      RBX::Network::NetworkTracer::addCheckpointToTracer(a1: v24, a2: a7, a3: v26, a4: 74); /*0x1039c9c32*/
    }
    else
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039c9c0a*/
        v25 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039c9c0c*/
      else
        v25 = 0; /*0x1039c9c39*/
      v27 = (*(__int64 (__fastcall **)(RakNet *, __int64, __int64, __int64))(*(_QWORD *)v44 + 200LL))( /*0x1039c9c4c*/
              a1: v44,
              a2: v23,
              a3: v22,
              a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
      TimeMS = RakNet::GetTimeMS(this: v28); /*0x1039c9c4e*/
      RBX::Network::NetworkTracer::addCheckpointToTracer_deprecated(a1: v25, a2: a7, a3: v27, a4: 74, a5: TimeMS); /*0x1039c9c64*/
    }
  }
  v30 = v48; /*0x1039c9c69*/
  v31 = v47; /*0x1039c9c70*/
  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v45, a2: a3); /*0x1039c9c84*/
  TimeUS = RakNet::GetTimeUS(this: nullptr, a2: v32); /*0x1039c9c8e*/
  RakNet::RakPeer::SendImmediate( /*0x1039c9cca*/
    a1: (__int64)v44,
    a2: (__int64)v30,
    a3: v31,
    a4: 0,
    a5: 0,
    a6: 0,
    a7: (__int64)v45,
    a8: 0,
    a9: 0,
    a10: TimeUS,
    a11: 0,
    a12: a7,
    a13: 0);
  RakNet::SignaledEvent::SetEvent(this: (RakNet *)((char *)v44 + 2560)); /*0x1039c9cdd*/
  RBX::Memory::deallocate(this: v41, a2: v34); /*0x1039c9ce9*/
LABEL_42:
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v46); /*0x1039c9cee*/
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v49); /*0x1039c9d01*/
  return __stack_chk_guard; /*0x1039c9d16*/
}

// Address: 0x1039c9e50 | Name: __ZN6RakNet7RakPeer33HandleIDDIsconnectionNotificationEPNS0_18RemoteSystemStructEPhjj
__int64 __fastcall RakNet::RakPeer::HandleIDDIsconnectionNotification(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        unsigned __int8 *a3,
        unsigned int a4,
        unsigned int a5)
{
  int v8; // r8d
  int v9; // r9d
  unsigned int v10; // ecx
  int v11; // ecx
  RakNet::BitStream *v13; // rdi
  unsigned __int8 v14[4]; // [rsp+0h] [rbp-150h] BYREF
  unsigned __int8 v15[4]; // [rsp+4h] [rbp-14Ch] BYREF
  _BYTE v16[296]; // [rsp+8h] [rbp-148h] BYREF

  if ( a5 >= 0x28 )
  {
    RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v16, a2: a3, a3: a4, a4: false); /*0x1039c9e8f*/
    RakNet::BitStream::IgnoreBits(this: (RakNet::BitStream *)v16, a2: 8u); /*0x1039c9ea0*/
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c9fa5*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v13); /*0x1039c9fb0*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c9fbd*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c9eba*/
    {
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v16, a2: v15, a3: 0x20u, a4: true); /*0x1039c9ed4*/
    }
    else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v16, a2: v14, a3: 0x20u, a4: true) != 0 ) /*0x1039c9efa*/
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v14, a2: v15, a3: (unsigned __int8 *)4, a4: v10); /*0x1039c9f0f*/
    }
    v11 = *(_DWORD *)v15; /*0x1039c9f14*/
    *((_DWORD *)this + 504) = *(_DWORD *)v15; /*0x1039c9f1a*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
      FLog::FastLogFormatted(
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: (unsigned int)"[FLog::Network] Disconnect reason received: %d",
        a4: v11,
        a5: v8,
        a6: v9);
    RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v16); /*0x1039c9f5c*/
  }
  *((_DWORD *)a2 + 1341) = 3; /*0x1039c9f61*/
  RBX::Memory::deallocate(this: (RBX::Memory *)a3, a2); /*0x1039c9f6f*/
  return __stack_chk_guard; /*0x1039c9f84*/
}

// Address: 0x1039c9ff4 | Name: __ZN6RakNet7RakPeer23HandleIDInvalidPasswordEPNS0_18RemoteSystemStructERKNS_13SystemAddressEPhjj
__int64 __fastcall RakNet::RakPeer::HandleIDInvalidPassword(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        const RakNet::SystemAddress *a3,
        RBX::Memory *a4,
        int a5,
        int a6)
{
  __int64 v10; // r13
  __int16 v11; // ax
  __int64 result; // rax

  if ( *((_DWORD *)a2 + 1341) != 4 ) /*0x1039c9ffb*/
    return RBX::Memory::deallocate(this: a4, a2); /*0x1039ca08a*/
  v10 = RakNet::RakPeer::AllocPacket(this, a2: a5, a3: (unsigned __int8 *)a4, a4: "", a5: 0); /*0x1039ca033*/
  *(_DWORD *)(v10 + 52) = a6; /*0x1039ca036*/
  RakNet::SystemAddress::operator=(a1: v10, a2: a3); /*0x1039ca040*/
  v11 = *((_WORD *)a2 + 2624); /*0x1039ca045*/
  *(_WORD *)(v10 + 30) = v11; /*0x1039ca04c*/
  *(_QWORD *)(v10 + 32) = *((_QWORD *)a2 + 650); /*0x1039ca058*/
  *(_WORD *)(v10 + 40) = v11; /*0x1039ca05c*/
  result = RakNet::RakPeer::AddPacketToProducer(this, a2: v10, a3: 0); /*0x1039ca069*/
  *((_DWORD *)a2 + 1341) = 2; /*0x1039ca06e*/
  return result; /*0x1039ca086*/
}

// Address: 0x1039ca090 | Name: __ZN6RakNet7RakPeer33HandleIDConnectionRequestAcceptedEPNS0_18RemoteSystemStructERKNS_13SystemAddressEPhj
__int64 __fastcall RakNet::RakPeer::HandleIDConnectionRequestAccepted(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        const RakNet::SystemAddress *a3,
        RBX::Memory *a4,
        unsigned int a5)
{
  int v7; // eax
  unsigned int v8; // ecx
  __int64 i; // r13
  __int64 v10; // rsi
  unsigned __int8 *v11; // rbx
  unsigned int v12; // ecx
  unsigned int v13; // ecx
  unsigned int v14; // ecx
  RakNet *v15; // rdi
  __int64 v16; // rbx
  __int128 v17; // xmm0
  __int64 v18; // rdx
  __int64 v19; // rcx
  __int64 v20; // r8
  __int64 v21; // r9
  __int16 IndexFromSystemAddress; // ax
  __int128 v23; // xmm0
  __int64 j; // r13
  __int128 v25; // xmm0
  unsigned int v26; // ecx
  bool v27; // si
  unsigned int v28; // ecx
  RBX::Time *v29; // rdi
  __int64 v30; // rax
  unsigned int v31; // ecx
  __int64 v32; // rbx
  int v33; // r14d
  bool v34; // si
  unsigned __int64 TimeUS; // rax
  __int64 v36; // rdx
  __int64 v37; // rcx
  RakNet *v38; // rdi
  __int64 v39; // r8
  __int64 v40; // r9
  __int128 v41; // xmm0
  int TimeMS; // eax
  RakNet::BitStream *v44; // rdi
  RakNet::BitStream *v45; // rdi
  RakNet::BitStream *v46; // rdi
  RakNet::BitStream *v47; // rdi
  RakNet::BitStream *v48; // rdi
  RakNet::BitStream *v49; // rdi
  RakNet::BitStream *v50; // rdi
  unsigned __int8 v51[2]; // [rsp+38h] [rbp-328h] BYREF
  unsigned __int8 v52[2]; // [rsp+3Ah] [rbp-326h] BYREF
  int v53; // [rsp+3Ch] [rbp-324h]
  __int16 v54; // [rsp+54h] [rbp-30Ch]
  unsigned __int8 v55[8]; // [rsp+58h] [rbp-308h] BYREF
  unsigned __int8 v56[8]; // [rsp+60h] [rbp-300h] BYREF
  unsigned __int8 *v57; // [rsp+68h] [rbp-2F8h]
  unsigned __int8 v58[8]; // [rsp+70h] [rbp-2F0h] BYREF
  int v59; // [rsp+7Ch] [rbp-2E4h]
  RakNet::SystemAddress *v60; // [rsp+80h] [rbp-2E0h]
  unsigned __int8 v61[2]; // [rsp+8Eh] [rbp-2D2h] BYREF
  unsigned __int8 v62[8]; // [rsp+90h] [rbp-2D0h] BYREF
  RakNet::RakPeer::RemoteSystemStruct *v63; // [rsp+98h] [rbp-2C8h]
  RakNet *v64; // [rsp+A0h] [rbp-2C0h]
  unsigned __int8 v65[3]; // [rsp+ACh] [rbp-2B4h] BYREF
  unsigned __int8 v66; // [rsp+AFh] [rbp-2B1h] BYREF
  bool v67[16]; // [rsp+B0h] [rbp-2B0h] BYREF
  __int128 v68; // [rsp+C0h] [rbp-2A0h]
  unsigned __int8 v69[16]; // [rsp+E0h] [rbp-280h] BYREF
  __int128 v70; // [rsp+F0h] [rbp-270h]
  _BYTE v71[296]; // [rsp+208h] [rbp-158h] BYREF

  v60 = a3; /*0x1039ca0a7*/
  v64 = this; /*0x1039ca0ae*/
  if ( a5 < 0x22 ) /*0x1039ca0c7*/
    return RBX::Memory::deallocate(this: a4, a2); /*0x1039ca0c7*/
  v63 = a2; /*0x1039ca0d0*/
  v7 = *((_DWORD *)a2 + 1341); /*0x1039ca0d7*/
  if ( (v7 & 0xFFFFFFFE) != 4 ) /*0x1039ca0e5*/
  {
    if ( *((_BYTE *)v64 + 2108) == 1 ) /*0x1039ca103*/
    {
      v59 = 0; /*0x1039ca109*/
      goto LABEL_6; /*0x1039ca109*/
    }
    return RBX::Memory::deallocate(this: a4, a2); /*0x1039ca9b1*/
  }
  LOBYTE(v7) = v7 == 5; /*0x1039ca0ea*/
  v59 = v7; /*0x1039ca0ed*/
LABEL_6:
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v51); /*0x1039ca113*/
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v71, a2: (unsigned __int8 *)a4, a3: a5, a4: false); /*0x1039ca12e*/
  RakNet::BitStream::IgnoreBits(this: (RakNet::BitStream *)v71, a2: 8u); /*0x1039ca13f*/
  RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: (unsigned __int8 *)v67, a3: 8u, a4: true); /*0x1039ca15c*/
  if ( v67[0] == 4 ) /*0x1039ca168*/
  {
    v51[1] = 2; /*0x1039ca16a*/
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: v69, a3: 0x20u, a4: true); /*0x1039ca189*/
    v53 = ~*(_DWORD *)v69; /*0x1039ca19d*/
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: v52, a3: 0x10u, a4: true); /*0x1039ca1b1*/
    v54 = __ROL2__(*(_WORD *)v52, 8); /*0x1039ca1c1*/
  }
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039ca9c9*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v44); /*0x1039ca9d4*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039ca9e1*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ca1dd*/
  {
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: v61, a3: 0x10u, a4: true); /*0x1039ca1f7*/
  }
  else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: v69, a3: 0x10u, a4: true) != 0 ) /*0x1039ca21d*/
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v69, a2: v61, a3: (unsigned __int8 *)2, a4: v8); /*0x1039ca232*/
  }
  v57 = (unsigned __int8 *)a4; /*0x1039ca237*/
  for ( i = -320; i != 0; i += 32 ) /*0x1039ca23e*/
  {
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: (unsigned __int8 *)v67, a3: 8u, a4: true); /*0x1039ca26a*/
    if ( v67[0] == 4 ) /*0x1039ca276*/
    {
      *((_BYTE *)v63 + i + 389) = 2; /*0x1039ca27f*/
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: v69, a3: 0x20u, a4: true); /*0x1039ca298*/
      v10 = (__int64)v63 + i + 390; /*0x1039ca2b0*/
      *(_DWORD *)(v10 + 2) = ~*(_DWORD *)v69; /*0x1039ca2b7*/
      RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: (unsigned __int8 *)v10, a3: 0x10u, a4: true); /*0x1039ca2c7*/
      *(_WORD *)((char *)v63 + i + 416) = __ROL2__(*(_WORD *)((char *)v63 + i + 390), 8); /*0x1039ca2e0*/
    }
  }
  *(_QWORD *)v56 = 0; /*0x1039ca2f3*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039ca9f9*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v45); /*0x1039caa04*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039caa11*/
  }
  v11 = v57; /*0x1039ca313*/
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ca31a*/
  {
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: v55, a3: 0x40u, a4: true); /*0x1039ca334*/
  }
  else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: v69, a3: 0x40u, a4: true) != 0 ) /*0x1039ca35a*/
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v69, a2: v55, a3: (unsigned __int8 *)8, a4: v12); /*0x1039ca36f*/
  }
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039caa29*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v46); /*0x1039caa34*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039caa41*/
    v11 = v57; /*0x1039caa46*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ca389*/
  {
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: v58, a3: 0x40u, a4: true); /*0x1039ca3a3*/
  }
  else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: v69, a3: 0x40u, a4: true) != 0 ) /*0x1039ca3c9*/
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v69, a2: v58, a3: (unsigned __int8 *)8, a4: v13); /*0x1039ca3de*/
  }
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039caa60*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v47); /*0x1039caa6b*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039caa78*/
    v11 = v57; /*0x1039caa7d*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ca3f8*/
  {
    RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: v56, a3: 0x40u, a4: true); /*0x1039ca412*/
  }
  else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: (RakNet::BitStream *)v71, a2: v69, a3: 0x40u, a4: true) != 0 ) /*0x1039ca438*/
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v69, a2: v56, a3: (unsigned __int8 *)8, a4: v14); /*0x1039ca44d*/
  }
  RakNet::RakPeer::OnConnectedPong( /*0x1039ca478*/
    a1: (__int64)v64,
    a2: *(_BOOL8 *)v55,
    a3: *(__int64 *)v58,
    a4: *(unsigned __int64 *)v56,
    a5: (__int64)v63,
    a6: 0);
  if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
    FLog::FastLog(
      a1: DFLog::RakNetConnectTrace,
      a2: qword_10D7BB0C8,
      a3: "[DFLog::RakNetConnectTrace] RakNet: App Level connection accepted!",
      0);
  *((_DWORD *)v63 + 1341) = 7; /*0x1039ca4b5*/
  RakNet::SystemAddress::operator=(a1: (char *)v64 + 2112, a2: v51); /*0x1039ca4d4*/
  v15 = v64; /*0x1039ca4d9*/
  *((_WORD *)v64 + 1070) = __ROL2__(*((_WORD *)v64 + 1057), 8); /*0x1039ca4eb*/
  v16 = RakNet::RakPeer::AllocPacket(this: v15, a2: a5, a3: v11, a4: "", a5: 0); /*0x1039ca507*/
  *(_DWORD *)(v16 + 52) = 8 * a5; /*0x1039ca50e*/
  RakNet::SystemAddress::operator=(a1: v16, a2: v60); /*0x1039ca51c*/
  v17 = *(_OWORD *)v60; /*0x1039ca528*/
  v70 = *((_OWORD *)v60 + 1); /*0x1039ca52f*/
  *(_OWORD *)v69 = v17; /*0x1039ca536*/
  IndexFromSystemAddress = RakNet::RakPeer::GetIndexFromSystemAddress( /*0x1039ca560*/
                             a1: (__int64)v64,
                             a2: 1,
                             a3: v18,
                             a4: v19,
                             a5: v20,
                             a6: v21,
                             a7: v17,
                             a8: *((__int64 *)&v17 + 1),
                             a9: v70,
                             a10: *((__int64 *)&v70 + 1));
  *(_WORD *)(v16 + 30) = IndexFromSystemAddress; /*0x1039ca565*/
  *(_QWORD *)(v16 + 32) = *((_QWORD *)v63 + 650); /*0x1039ca577*/
  *(_WORD *)(v16 + 40) = IndexFromSystemAddress; /*0x1039ca57b*/
  RakNet::RakPeer::AddPacketToProducer(this: v64, a2: v16, a3: 0); /*0x1039ca58b*/
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v69); /*0x1039ca597*/
  v67[0] = 19; /*0x1039ca5a3*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: (const unsigned __int8 *)v67, a3: 8u, a4: true); /*0x1039ca5b7*/
  v66 = 4; /*0x1039ca5c3*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: &v66, a3: 8u, a4: true); /*0x1039ca5d7*/
  v23 = *(_OWORD *)v60; /*0x1039ca5e3*/
  v68 = *((_OWORD *)v60 + 1); /*0x1039ca5ea*/
  *(_OWORD *)v67 = v23; /*0x1039ca5f1*/
  *(_DWORD *)v62 = ~*((_DWORD *)v60 + 1); /*0x1039ca604*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: v62, a3: 0x20u, a4: true); /*0x1039ca617*/
  *(_WORD *)v65 = RakNet::SystemAddress::GetPortNetworkOrder(this: (RakNet::SystemAddress *)v67); /*0x1039ca62f*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: v65, a3: 0x10u, a4: true); /*0x1039ca643*/
  for ( j = 2172; j != 2492; j += 32 ) /*0x1039ca648*/
  {
    v66 = 4; /*0x1039ca66a*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: &v66, a3: 8u, a4: true); /*0x1039ca685*/
    v25 = *(_OWORD *)((char *)v64 + j - 4); /*0x1039ca691*/
    v68 = *(_OWORD *)((char *)v64 + j + 12); /*0x1039ca69d*/
    *(_OWORD *)v67 = v25; /*0x1039ca6a4*/
    *(_DWORD *)v62 = ~*(_DWORD *)((char *)v64 + j); /*0x1039ca6b1*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: v62, a3: 0x20u, a4: true); /*0x1039ca6c7*/
    *(_WORD *)v65 = RakNet::SystemAddress::GetPortNetworkOrder(this: (RakNet::SystemAddress *)v67); /*0x1039ca6d4*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: v65, a3: 0x10u, a4: true); /*0x1039ca6eb*/
  }
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039caa97*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v48); /*0x1039caaa2*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039caaaf*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ca716*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: v58, a3: 0x40u, a4: true); /*0x1039ca730*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039ca74a*/
      this: (RakNet::BitStream *)v58,
      a2: (unsigned __int8 *)v67,
      a3: (unsigned __int8 *)8,
      a4: v26);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: (const unsigned __int8 *)v67, a3: 0x40u, a4: true); /*0x1039ca767*/
  }
  *(_QWORD *)v62 = RakNet::GetTime(this: nullptr, a2: v27); /*0x1039ca773*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039caac7*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v49); /*0x1039caad2*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039caadf*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ca78f*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: v62, a3: 0x40u, a4: true); /*0x1039ca7a9*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039ca7c3*/
      this: (RakNet::BitStream *)v62,
      a2: (unsigned __int8 *)v67,
      a3: (unsigned __int8 *)8,
      a4: v28);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: (const unsigned __int8 *)v67, a3: 0x40u, a4: true); /*0x1039ca7e0*/
  }
  v30 = RBX::Time::epochTimeNs(this: v29); /*0x1039ca7e5*/
  v31 = -481036337; /*0x1039ca7ea*/
  *(_QWORD *)v62 = ((unsigned __int64)((unsigned __int128)(0x20C49BA5E353F7CFLL * (__int128)v30) >> 64) >> 63) /*0x1039ca805*/
                 + v30 / 1000;
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039caaf7*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v50); /*0x1039cab02*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cab0f*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ca821*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: v62, a3: 0x40u, a4: true); /*0x1039ca83b*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039ca855*/
      this: (RakNet::BitStream *)v62,
      a2: (unsigned __int8 *)v67,
      a3: (unsigned __int8 *)8,
      a4: v31);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v69, a2: (const unsigned __int8 *)v67, a3: 0x40u, a4: true); /*0x1039ca872*/
  }
  v32 = *((_QWORD *)&v70 + 1); /*0x1039ca877*/
  v33 = *(_DWORD *)&v69[12]; /*0x1039ca87e*/
  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v67, a2: v60); /*0x1039ca896*/
  TimeUS = RakNet::GetTimeUS(this: nullptr, a2: v34); /*0x1039ca8a0*/
  RakNet::RakPeer::SendImmediate( /*0x1039ca8e3*/
    a1: (__int64)v64,
    a2: v32,
    a3: v33,
    a4: 0,
    a5: 3u,
    a6: 0,
    a7: (__int64)v67,
    a8: 0,
    a9: 0,
    a10: TimeUS,
    a11: 0,
    a12: 0,
    a13: 0);
  if ( (_BYTE)v59 == 0 ) /*0x1039ca8ef*/
  {
    v41 = *(_OWORD *)v60; /*0x1039ca8f8*/
    v68 = *((_OWORD *)v60 + 1); /*0x1039ca8ff*/
    *(_OWORD *)v67 = v41; /*0x1039ca906*/
    RakNet::RakPeer::SendPings(this: v64, a2: 0, a3: v36, a4: v37, a5: v39, a6: v40, a7: v41); /*0x1039ca92d*/
  }
  *((_BYTE *)v63 + 5264) = 1; /*0x1039ca93b*/
  TimeMS = RakNet::GetTimeMS(this: v38); /*0x1039ca941*/
  *((_DWORD *)v63 + 1317) = TimeMS; /*0x1039ca94d*/
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v69); /*0x1039ca95a*/
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v71); /*0x1039ca966*/
  return __stack_chk_guard; /*0x1039ca97b*/
}

// Address: 0x1039cac40 | Name: __ZN6RakNet7RakPeer19HandlePacketRequestEPNS0_18RemoteSystemStructERKNS_13SystemAddressERKy
__int64 __fastcall RakNet::RakPeer::HandlePacketRequest(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        const RakNet::SystemAddress *a3,
        const unsigned __int64 *a4)
{
  RakNet::ReliabilityLayer *v7; // r12
  __int64 result; // rax
  void *v9; // rsi
  unsigned int v10; // r13d
  RBX::Memory *v11; // rcx
  __int64 v12; // r8
  unsigned __int64 v13; // r9
  RakNet::RakPeer *v14; // rdi
  RakNet::RakPeer::RemoteSystemStruct *v15; // rsi
  unsigned __int8 *v16; // rdx
  unsigned int v17; // ecx
  int v18; // r8d
  __int64 v19; // rax
  __int64 v20; // r13
  RBX::Network *v21; // rdi
  __int16 v22; // ax
  unsigned __int64 v23; // rax
  int v24; // ecx
  __int64 v25; // rdx
  __int64 v26; // rsi
  unsigned __int8 v27; // al
  unsigned __int8 v28; // al
  unsigned __int8 v29; // r13
  RakNet *v30; // rdi
  unsigned int TimeMS; // eax
  __int64 v32; // rdx
  __int64 v33; // [rsp+10h] [rbp-60h]
  RBX::Memory *v34; // [rsp+18h] [rbp-58h] BYREF
  __int64 v35; // [rsp+20h] [rbp-50h]
  int v36; // [rsp+2Ch] [rbp-44h]
  __int64 v37; // [rsp+30h] [rbp-40h]
  int v38; // [rsp+3Ch] [rbp-34h] BYREF
  unsigned __int64 v39[6]; // [rsp+40h] [rbp-30h] BYREF

  v38 = -1; /*0x1039cac5e*/
  v39[0] = 0; /*0x1039cac68*/
  v7 = (RakNet::RakPeer::RemoteSystemStruct *)((char *)a2 + 392); /*0x1039cac6f*/
  result = RakNet::ReliabilityLayer::Receive( /*0x1039cac7d*/
             this: (RakNet::RakPeer::RemoteSystemStruct *)((char *)a2 + 392),
             a2: (unsigned __int8 **)&v34,
             a3: &v38,
             a4: v39);
  if ( (_DWORD)result != 0 ) /*0x1039cac84*/
  {
    v10 = result; /*0x1039cac8a*/
    do /*0x1039cac8d*/
    {
      v11 = v34; /*0x1039cac8d*/
      result = *(unsigned __int8 *)v34; /*0x1039cac91*/
      if ( (_DWORD)result == 13 || (_DWORD)result == 17 ) /*0x1039caca0*/
        return result; /*0x1039caca0*/
      v12 = (v10 + 7) >> 3; /*0x1039cacad*/
      if ( *((_DWORD *)a2 + 1341) == 6 ) /*0x1039cacb9*/
      {
        RakNet::RakPeer::HandleUnverifiedSender(this, a2, a3, a4: (char *)v34, a5: v12); /*0x1039cacc4*/
      }
      else if ( (_DWORD)result == 9 ) /*0x1039cacd1*/
      {
        RakNet::RakPeer::HandleIDConnectionRequest(this, a2, a3, a4: (char *)v34, a5: v12); /*0x1039cacdc*/
      }
      else if ( (_DWORD)result != 19 || v10 + 7 < 0x100 ) /*0x1039cacf3*/
      {
        if ( (_DWORD)result == 3 ) /*0x1039cad14*/
        {
          if ( (_DWORD)v12 == *((_DWORD *)a2 + 1304) - 40 ) /*0x1039cad23*/
          {
            v13 = v39[0]; /*0x1039cad29*/
            v14 = this; /*0x1039cad2d*/
            v15 = a2; /*0x1039cad30*/
            v16 = (unsigned __int8 *)v34; /*0x1039cad33*/
            v17 = (v10 + 7) >> 3; /*0x1039cad36*/
            v18 = 1; /*0x1039cad39*/
          }
          else
          {
            if ( (_DWORD)v12 != 25 ) /*0x1039cadb7*/
              goto LABEL_43; /*0x1039cadb7*/
LABEL_30:
            v13 = v39[0]; /*0x1039cadbd*/
            v14 = this; /*0x1039cadc1*/
            v15 = a2; /*0x1039cadc4*/
            v16 = (unsigned __int8 *)v34; /*0x1039cadc7*/
            v17 = 25; /*0x1039cadca*/
            v18 = 0; /*0x1039cadcf*/
          }
          RakNet::RakPeer::HandleIDConnectedPong(this: v14, a2: v15, a3: v16, a4: v17, a5: v18, a6: v13); /*0x1039cadd2*/
          goto LABEL_32; /*0x1039cadd2*/
        }
        if ( (_DWORD)v12 == 25 && (_BYTE)result == 84 /*0x1039cad60*/
          || (_DWORD)v12 == 25 && (_BYTE)result == 85
          || (_DWORD)v12 == 25 && (_BYTE)result == 86 )
        {
          goto LABEL_30; /*0x1039cad60*/
        }
        if ( *(_BYTE *)v34 != 0 ) /*0x1039cad64*/
        {
          if ( (_DWORD)v12 == 9 && (_BYTE)result == 81 /*0x1039cad8e*/
            || (_DWORD)v12 == 9 && (_BYTE)result == 82
            || (_DWORD)v12 == 9 && (_BYTE)result == 83 )
          {
            goto LABEL_37; /*0x1039cad8e*/
          }
          if ( (_DWORD)result == 21 ) /*0x1039cad97*/
          {
            RakNet::RakPeer::HandleIDDIsconnectionNotification(this, a2, a3: (unsigned __int8 *)v34, a4: v12, a5: v10); /*0x1039cadac*/
          }
          else
          {
            if ( (_DWORD)v12 == 1 && (_BYTE)result == 4 ) /*0x1039cae59*/
              goto LABEL_49; /*0x1039cae59*/
            if ( (_DWORD)result == 16 ) /*0x1039cae62*/
            {
              RakNet::RakPeer::HandleIDConnectionRequestAccepted(this, a2, a3, a4: v34, a5: v12); /*0x1039caff8*/
              goto LABEL_32; /*0x1039caffd*/
            }
            if ( (_DWORD)result != 24 ) /*0x1039cae6b*/
            {
LABEL_43:
              if ( (result & 0xFE) == 14 || (unsigned __int8)result >= 0x1Bu ) /*0x1039cae85*/
              {
                v11 = v34; /*0x1039cae96*/
                if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1039cae9c*/
                {
                  v19 = RakNet::RakPeer::AllocPacket(this, a2: v12, a3: (unsigned __int8 *)v34, a4: "", a5: 0); /*0x1039caeb1*/
                  *(_DWORD *)(v19 + 52) = v10; /*0x1039caeb6*/
                  v20 = v19; /*0x1039caeba*/
                  RakNet::SystemAddress::operator=(a1: v19, a2: a3); /*0x1039caec3*/
                  v22 = *((_WORD *)a2 + 2624); /*0x1039caec8*/
                  *(_WORD *)(v20 + 30) = v22; /*0x1039caed0*/
                  *(_QWORD *)(v20 + 32) = *((_QWORD *)a2 + 650); /*0x1039caedc*/
                  *(_WORD *)(v20 + 40) = v22; /*0x1039caee0*/
                  v23 = v39[0]; /*0x1039caee5*/
                  *(_QWORD *)(v20 + 96) = v39[0]; /*0x1039caee9*/
                  v24 = v38; /*0x1039caeed*/
                  if ( DFFlag::EnablePingPongPerformanceTraceCLI != 0 || DFFlag::RakNetPingTrace != 0 ) /*0x1039caf00*/
                  {
                    if ( v23 == 0 ) /*0x1039caf05*/
                      goto LABEL_61; /*0x1039caf05*/
                  }
                  else if ( ((v23 != 0) & (unsigned __int8)DFFlag::DataPingTrace) == 0 ) /*0x1039caf25*/
                  {
LABEL_61:
                    RakNet::RakPeer::AddPacketToProducer(this, a2: v20, a3: v24 == 1); /*0x1039cafd7*/
                    goto LABEL_32; /*0x1039cafea*/
                  }
                  v36 = v38; /*0x1039caf2b*/
                  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v21) != 0 ) /*0x1039caf3c*/
                  {
                    if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039caf41*/
                      v37 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039caf47*/
                    else
                      v37 = 0; /*0x1039caf5c*/
                    v35 = *(_QWORD *)(v20 + 96); /*0x1039caf68*/
                    v27 = (*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64))(*(_QWORD *)this /*0x1039caf72*/
                                                                                                  + 200LL))(
                            a1: this,
                            a2: v26,
                            a3: v25,
                            a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
                    RBX::Network::NetworkTracer::addCheckpointToTracer(a1: v37, a2: v35, a3: v27, a4: 71); /*0x1039caf88*/
                  }
                  else
                  {
                    if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039caf50*/
                      v37 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039caf56*/
                    else
                      v37 = 0; /*0x1039caf8f*/
                    v33 = *(_QWORD *)(v20 + 96); /*0x1039caf9b*/
                    v28 = (*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64))(*(_QWORD *)this /*0x1039cafa5*/
                                                                                                  + 200LL))(
                            a1: this,
                            a2: v26,
                            a3: v25,
                            a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
                    v35 = v20; /*0x1039cafab*/
                    v29 = v28; /*0x1039cafaf*/
                    TimeMS = RakNet::GetTimeMS(this: v30); /*0x1039cafb2*/
                    v32 = v29; /*0x1039cafba*/
                    v20 = v35; /*0x1039cafbe*/
                    RBX::Network::NetworkTracer::addCheckpointToTracer_deprecated( /*0x1039cafcf*/
                      a1: v37,
                      a2: v33,
                      a3: v32,
                      a4: 71,
                      a5: TimeMS);
                  }
                  v24 = v36; /*0x1039cafd4*/
                  goto LABEL_61; /*0x1039cafd4*/
                }
              }
LABEL_49:
              LOBYTE(v9) = (_DWORD)result != 19; /*0x1039caf0c*/
              RBX::Memory::deallocate(this: v11, a2: v9); /*0x1039caf0f*/
              goto LABEL_32; /*0x1039caf14*/
            }
            RakNet::RakPeer::HandleIDInvalidPassword(this, a2, a3, a4: v34, a5: v12, a6: v10); /*0x1039cae79*/
          }
        }
        else
        {
          if ( (_DWORD)v12 != *((_DWORD *)a2 + 1304) - 40 ) /*0x1039cae0f*/
          {
            if ( (_DWORD)v12 != 9 ) /*0x1039cae2e*/
              goto LABEL_43; /*0x1039cae2e*/
LABEL_37:
            RakNet::RakPeer::HandleIDConnectedPing(this, a2, a3, a4: v34, a5: 9u, a6: 0, a7: v39[0]); /*0x1039cae30*/
            goto LABEL_32; /*0x1039cae4f*/
          }
          RakNet::RakPeer::HandleIDConnectedPing(this, a2, a3, a4: v34, a5: v12, a6: 1, a7: v39[0]); /*0x1039cae28*/
        }
      }
      else
      {
        RakNet::RakPeer::HandleIDNewIncomingConnection(this, a2, a3, a4: (unsigned __int8 *)v34, a5: v12, a6: v10); /*0x1039cad07*/
      }
LABEL_32:
      v38 = -1; /*0x1039cadd7*/
      result = RakNet::ReliabilityLayer::Receive(this: v7, a2: (unsigned __int8 **)&v34, a3: &v38, a4: v39); /*0x1039caded*/
      v10 = result; /*0x1039cadf2*/
    }
    while ( (_DWORD)result != 0 ); /*0x1039cac8d*/
  }
  return result; /*0x1039cb002*/
}

// Address: 0x1039cb012 | Name: __ZN6RakNet7RakPeer18logMissingPingPongEPNS0_18RemoteSystemStructERKjb
void __fastcall RakNet::RakPeer::logMissingPingPong(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        const unsigned int *a3,
        int a4)
{
  unsigned __int64 v5; // rbx
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rcx
  unsigned __int64 v8; // r8
  unsigned __int64 v9; // r12
  unsigned __int64 v10; // rdi
  bool v11; // r14
  bool v12; // r13
  unsigned int OldestSentPacketTimeMs; // eax
  unsigned __int64 v14; // rcx
  unsigned __int64 v15; // r12
  __int64 v16; // r14
  __int64 v17; // r13
  RakNet::ReliabilityLayer *v18; // r14
  __int64 i; // rax
  char *v20; // rax
  __int64 j; // rcx
  unsigned int v22; // ecx
  unsigned int v23; // eax
  __m128i v24; // xmm0
  __int64 v25; // r13
  __int64 v26; // r12
  __int64 v27; // r14
  __int64 v28; // r11
  int v29; // edi
  unsigned int v30; // eax
  __int64 v31; // r10
  void *v32; // r9
  __int64 v33; // r8
  __int64 v34; // r13
  unsigned __int64 v35; // r14
  unsigned __int64 v36; // rsi
  unsigned __int64 v37; // r12
  unsigned __int64 v38; // r13
  unsigned __int64 v39; // r14
  unsigned int v40; // ebx
  unsigned __int64 v41; // r13
  unsigned int v42; // r8d
  char *v43; // rcx
  __int64 v44; // r8
  unsigned int v45; // r8d
  char *v46; // rcx
  __int64 v47; // r8
  __int64 k; // r14
  void **v49; // rdi
  _BYTE v50[4]; // [rsp+5Ch] [rbp-5E4h]
  _QWORD v51[11]; // [rsp+60h] [rbp-5E0h] BYREF
  char v52; // [rsp+B8h] [rbp-588h] BYREF
  void *v53[4]; // [rsp+100h] [rbp-540h] BYREF
  __int128 v54; // [rsp+120h] [rbp-520h]
  __int128 v55; // [rsp+130h] [rbp-510h]
  __int128 v56; // [rsp+140h] [rbp-500h]
  __int128 v57; // [rsp+150h] [rbp-4F0h]
  unsigned __int8 v58; // [rsp+1B8h] [rbp-488h]
  unsigned int v59; // [rsp+1F8h] [rbp-448h]
  __int64 v60; // [rsp+200h] [rbp-440h]
  unsigned int v61; // [rsp+208h] [rbp-438h]
  _BYTE v62[80]; // [rsp+210h] [rbp-430h] BYREF
  int v63; // [rsp+260h] [rbp-3E0h]
  __int128 v64; // [rsp+268h] [rbp-3D8h]
  __int128 v65; // [rsp+278h] [rbp-3C8h]
  __int128 v66; // [rsp+288h] [rbp-3B8h]
  __int128 v67; // [rsp+298h] [rbp-3A8h]
  __int128 v68; // [rsp+2A8h] [rbp-398h]
  _QWORD v69[2]; // [rsp+2C0h] [rbp-380h] BYREF
  void *v70; // [rsp+2D0h] [rbp-370h]
  __int64 v71; // [rsp+2E0h] [rbp-360h]
  __int64 v72; // [rsp+2F0h] [rbp-350h]
  unsigned __int64 v73; // [rsp+300h] [rbp-340h]
  _QWORD v74[66]; // [rsp+308h] [rbp-338h] BYREF
  __int64 v75; // [rsp+518h] [rbp-128h]
  __int64 v76; // [rsp+520h] [rbp-120h]
  unsigned __int64 v77; // [rsp+528h] [rbp-118h]
  void *v78; // [rsp+530h] [rbp-110h]
  __int64 v79; // [rsp+538h] [rbp-108h]
  unsigned __int64 v80; // [rsp+540h] [rbp-100h]
  unsigned __int64 v81; // [rsp+548h] [rbp-F8h] BYREF
  unsigned __int64 v82; // [rsp+550h] [rbp-F0h] BYREF
  unsigned __int64 v83; // [rsp+558h] [rbp-E8h] BYREF
  unsigned __int64 v84; // [rsp+560h] [rbp-E0h] BYREF
  unsigned __int64 v85; // [rsp+568h] [rbp-D8h] BYREF
  unsigned __int64 v86; // [rsp+570h] [rbp-D0h] BYREF
  unsigned __int64 v87; // [rsp+578h] [rbp-C8h] BYREF
  unsigned __int64 v88; // [rsp+580h] [rbp-C0h] BYREF
  unsigned __int64 v89; // [rsp+588h] [rbp-B8h] BYREF
  unsigned __int64 v90; // [rsp+590h] [rbp-B0h] BYREF
  unsigned __int64 v91; // [rsp+598h] [rbp-A8h]
  unsigned __int64 v92; // [rsp+5A0h] [rbp-A0h]
  unsigned __int64 v93; // [rsp+5A8h] [rbp-98h]
  unsigned __int64 v94; // [rsp+5B0h] [rbp-90h]
  unsigned __int64 v95; // [rsp+5B8h] [rbp-88h]
  float v96; // [rsp+5C4h] [rbp-7Ch]
  RakNet::RakPeer *v97; // [rsp+5C8h] [rbp-78h]
  unsigned __int64 v98; // [rsp+5D0h] [rbp-70h]
  __int64 v99; // [rsp+5D8h] [rbp-68h]
  __m128i v100; // [rsp+5E0h] [rbp-60h] BYREF
  void *v101; // [rsp+5F0h] [rbp-50h]
  __int64 v102; // [rsp+5F8h] [rbp-48h]
  unsigned int AvaliableNetworkCapacityInBytesInNextMs; // [rsp+604h] [rbp-3Ch]
  RakNet::ReliabilityLayer *v104; // [rsp+608h] [rbp-38h]
  int v105; // [rsp+610h] [rbp-30h]
  unsigned __int8 IsDeadConnection; // [rsp+615h] [rbp-2Bh]
  unsigned __int8 IsOutgoingDataWaiting; // [rsp+616h] [rbp-2Ah]
  unsigned __int8 v108; // [rsp+617h] [rbp-29h]

  v105 = a4; /*0x1039cb026*/
  v97 = this; /*0x1039cb02c*/
  v5 = *a3; /*0x1039cb030*/
  v6 = v5 - *((_QWORD *)a2 + 641); /*0x1039cb035*/
  v81 = v6; /*0x1039cb03c*/
  v7 = v5 - *((_QWORD *)a2 + 642); /*0x1039cb046*/
  v82 = v7; /*0x1039cb04d*/
  v8 = v5 - *((_QWORD *)a2 + 643); /*0x1039cb057*/
  v9 = DFInt::RakNetPingFrequencyMillisecond + (__int64)DFInt::RakNetMissingPingThresholdMs; /*0x1039cb06f*/
  v10 = v5 - *((_QWORD *)a2 + 644); /*0x1039cb072*/
  v11 = *((_DWORD *)a2 + 1341) == 7 && v5 - *((_QWORD *)a2 + 648) > v9; /*0x1039cb08f*/
  v92 = v5 - *((_QWORD *)a2 + 644); /*0x1039cb098*/
  v91 = v8; /*0x1039cb0a5*/
  v12 = v7 > v9 || v6 > v9 || v10 > v9 || v8 > v9; /*0x1039cb0c4*/
  v104 = (RakNet::RakPeer::RemoteSystemStruct *)((char *)a2 + 392); /*0x1039cb0ce*/
  OldestSentPacketTimeMs = RakNet::ReliabilityLayer::GetOldestSentPacketTimeMs(this: (RakNet::RakPeer::RemoteSystemStruct *)((char *)a2 + 392)); /*0x1039cb0d2*/
  v14 = 0; /*0x1039cb0df*/
  if ( OldestSentPacketTimeMs <= (unsigned int)v5 ) /*0x1039cb0e3*/
    v14 = v5 - OldestSentPacketTimeMs; /*0x1039cb0e3*/
  v83 = v14; /*0x1039cb0e7*/
  v84 = v5 - (unsigned int)(*((_QWORD *)a2 + 91) / 0x3E8uLL); /*0x1039cb112*/
  v85 = v5 - (unsigned int)(*((_QWORD *)a2 + 92) / 0x3E8uLL); /*0x1039cb133*/
  v86 = v5 - *((unsigned int *)a2 + 160); /*0x1039cb156*/
  if ( ((unsigned __int8)v105 | (v12 && v11 && v86 < v9 && v14 > v9 && v84 < v9)) == 1
    && (*((_QWORD *)a2 + 645) == 0 || *((_QWORD *)a2 + 645) < v5) )
  {
    *((_QWORD *)a2 + 645) = v5 + DFInt::RakNetMissingPingLogFrequencyMs; /*0x1039cb19c*/
    v87 = v5 - *((_QWORD *)a2 + 637); /*0x1039cb1ad*/
    v88 = v5 - *((_QWORD *)a2 + 639); /*0x1039cb1be*/
    v94 = v5 - *((_QWORD *)a2 + 638); /*0x1039cb1cf*/
    v15 = v5 - *((_QWORD *)a2 + 640); /*0x1039cb1d9*/
    v89 = v5 - *((unsigned int *)a2 + 181) / 0x3E8uLL; /*0x1039cb1f8*/
    v90 = v5 /*0x1039cb225*/
        - (unsigned int)((*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)a2 + 428) + 248LL))(a1: *((_QWORD *)a2 + 428))
                       / 0x3E8uLL);
    v16 = DFLog::RakNetMissingPingPong; /*0x1039cb22c*/
    if ( (unsigned __int8)DFLog::RakNetMissingPingPong >= 6u && BYTE1(DFLog::RakNetMissingPingPong) >= 6u )
    {
      v17 = qword_10D7BB088; /*0x1039cb24d*/
      v51[0] = v91; /*0x1039cb262*/
      v51[2] = v94; /*0x1039cb26c*/
      v51[4] = v92; /*0x1039cb277*/
      v51[6] = v15; /*0x1039cb27b*/
      fmt::v8::vformat( /*0x1039cb297*/
        a1: v69,
        a2: "mtu ping recv {}, mtu ping sent {}, mtu pong recv {}, mtu pong sent {}, ",
        a3: 72,
        a4: 17476,
        a5: v51);
      FLog::FastLogSafeFormatted<unsigned long long const&,unsigned long long const&,unsigned long long const&,unsigned long long const&,std::string,unsigned long long const&,unsigned long long const&,unsigned long long const&,unsigned long long const&,unsigned long long const&,unsigned long long const&,int &>(
        a1: v16,
        a2: v17,
        a3: 6,
        a4: (__int64)"[DFLog::RakNetMissingPingPong] Time since last (ms): ping recv {}, ping sent {}, pong recv {}, pong sen"
                 "t {}, {}pkt recv {}, pkt sent {}, reliable recv {}, ack recv {}, oldest unacked send {}, oldest unacked"
                 " recv {} | MTU size: {} bytes",
        a5: 235,
        a6: &v81,
        a7: (__int64 *)&v87,
        a8: (__int64 *)&v82,
        a9: (__int64 *)&v88,
        a10: (unsigned __int8 *)v69,
        a11: (__int64 *)&v86,
        a12: (__int64 *)&v89,
        a13: (__int64 *)&v85,
        a14: (__int64 *)&v84,
        a15: (__int64 *)&v83,
        a16: (__int64 *)&v90,
        a17: (unsigned int *)a2 + 1304);
      if ( (v69[0] & 1) != 0 ) /*0x1039cb34a*/
        operator delete(a1: v70); /*0x1039cb353*/
    }
    v18 = v104; /*0x1039cb358*/
    IsDeadConnection = RakNet::ReliabilityLayer::IsDeadConnection(this: v104); /*0x1039cb364*/
    IsOutgoingDataWaiting = RakNet::ReliabilityLayer::IsOutgoingDataWaiting(this: v18); /*0x1039cb36f*/
    v108 = RakNet::ReliabilityLayer::AreAcksWaiting(this: v18); /*0x1039cb37a*/
    AvaliableNetworkCapacityInBytesInNextMs = RakNet::ReliabilityLayer::getAvaliableNetworkCapacityInBytesInNextMs( /*0x1039cb38d*/
                                                this: v18,
                                                a2: 1000.0);
    for ( i = 4; i != 36; i += 8 ) /*0x1039cb390*/
    {
      v50[i] = 0; /*0x1039cb397*/
      *((_BYTE *)v51 + i) = 0; /*0x1039cb39e*/
    }
    v20 = &v52; /*0x1039cb3b1*/
    LOBYTE(v51[4]) = 0; /*0x1039cb3b8*/
    BYTE4(v51[4]) = 0; /*0x1039cb3bb*/
    LOBYTE(v51[5]) = 0; /*0x1039cb3be*/
    BYTE4(v51[5]) = 0; /*0x1039cb3c1*/
    LOBYTE(v51[6]) = 0; /*0x1039cb3c4*/
    BYTE4(v51[6]) = 0; /*0x1039cb3c7*/
    LOBYTE(v51[7]) = 0; /*0x1039cb3ca*/
    BYTE4(v51[7]) = 0; /*0x1039cb3cd*/
    for ( j = 128; j != 0; j -= 32 ) /*0x1039cb3d0*/
    {
      *((_QWORD *)v20 - 3) = v20; /*0x1039cb3d5*/
      *((_QWORD *)v20 - 2) = 0; /*0x1039cb3d9*/
      *((_QWORD *)v20 - 1) = 4; /*0x1039cb3e1*/
      v20 += 32; /*0x1039cb3e9*/
    }
    v68 = 0; /*0x1039cb3fe*/
    v67 = 0; /*0x1039cb406*/
    v66 = 0; /*0x1039cb40e*/
    v65 = 0; /*0x1039cb416*/
    v64 = 0; /*0x1039cb41e*/
    v54 = 0; /*0x1039cb426*/
    v55 = 0; /*0x1039cb42e*/
    v56 = 0; /*0x1039cb436*/
    v57 = 0; /*0x1039cb43e*/
    memset(v62, 0, 28); /*0x1039cb446*/
    memset(&v62[32], 0, 48); /*0x1039cb456*/
    v63 = 0; /*0x1039cb46e*/
    RakNet::ReliabilityLayer::GetStatistics(this: v18, a2: (RakNet::RakNetStatistics *)v51); /*0x1039cb47b*/
    v93 = v59; /*0x1039cb486*/
    v22 = *((_DWORD *)a2 + 104); /*0x1039cb494*/
    v23 = *((_DWORD *)a2 + 105); /*0x1039cb49b*/
    v105 = v23 - v22; /*0x1039cb4a6*/
    v77 = v15; /*0x1039cb4a9*/
    if ( v23 < v22 ) /*0x1039cb4b0*/
      v105 = *((_DWORD *)a2 + 106) + v23 - v22; /*0x1039cb4bb*/
    v24 = _mm_cvtsi32_si128(v61); /*0x1039cb4c5*/
    v25 = *((unsigned int *)a2 + 163); /*0x1039cb4cd*/
    v26 = *((unsigned int *)a2 + 174); /*0x1039cb4d4*/
    v27 = *((unsigned int *)a2 + 175); /*0x1039cb4db*/
    v102 = *((unsigned int *)a2 + 176); /*0x1039cb4e9*/
    v98 = *((unsigned int *)a2 + 177); /*0x1039cb4f4*/
    v101 = (void *)*((unsigned int *)a2 + 178); /*0x1039cb4ff*/
    v104 = (RakNet::ReliabilityLayer *)*((unsigned int *)a2 + 179); /*0x1039cb50a*/
    v28 = *((unsigned int *)a2 + 180); /*0x1039cb50e*/
    v29 = DFLog::RakNetMissingPingPong; /*0x1039cb518*/
    v30 = (unsigned int)DFLog::RakNetMissingPingPong >> 8; /*0x1039cb521*/
    v95 = v5 - *((_QWORD *)a2 + 646); /*0x1039cb52b*/
    v76 = v58; /*0x1039cb540*/
    v96 = COERCE_FLOAT(_mm_cvtsi128_si32(v24)); /*0x1039cb547*/
    v75 = v60; /*0x1039cb54c*/
    if ( (unsigned __int8)DFLog::RakNetMissingPingPong >= 6u && BYTE1(DFLog::RakNetMissingPingPong) >= 6u )
    {
      v99 = v28; /*0x1039cb559*/
      v69[0] = IsDeadConnection; /*0x1039cb568*/
      v70 = (void *)IsOutgoingDataWaiting; /*0x1039cb56f*/
      v71 = v108; /*0x1039cb577*/
      v72 = AvaliableNetworkCapacityInBytesInNextMs; /*0x1039cb57e*/
      v73 = v93; /*0x1039cb58d*/
      v74[1] = v60; /*0x1039cb591*/
      v74[3] = (unsigned int)_mm_cvtsi128_si32(v24); /*0x1039cb595*/
      v74[5] = v58; /*0x1039cb59c*/
      v74[7] = (unsigned int)v105; /*0x1039cb5a0*/
      v100.i64[0] = 0x179421777LL; /*0x1039cb5b1*/
      v100.i64[1] = (__int64)v69; /*0x1039cb5b5*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: DFLog::RakNetMissingPingPong,
        a2: qword_10D7BB088,
        a3: 6,
        a4: (unsigned int)"[DFLog::RakNetMissingPingPong] Other stats: dead {}, outgoingWaiting {}, acksWaiting {}, netCapaci"
                      "ty {}, resendBuf msg{}, resendBuf bytes{}, loss last sec{}, limitedByBw {}, outputQueueSize {}",
        a5: 192,
        a6: 1,
        _mm_loadu_si128(&v100));
      v29 = DFLog::RakNetMissingPingPong; /*0x1039cb5e7*/
      v30 = (unsigned int)DFLog::RakNetMissingPingPong >> 8; /*0x1039cb5f0*/
      v28 = v99; /*0x1039cb5f3*/
    }
    v31 = v5 - v25; /*0x1039cb5fa*/
    v32 = (void *)(v5 - v26); /*0x1039cb600*/
    v33 = v5 - v27; /*0x1039cb606*/
    v34 = v5 - v102; /*0x1039cb60c*/
    v35 = v5 - v98; /*0x1039cb613*/
    v36 = v5 - (_QWORD)v101; /*0x1039cb61a*/
    v37 = v5 - (_QWORD)v104; /*0x1039cb621*/
    v104 = (RakNet::ReliabilityLayer *)(v5 - v28); /*0x1039cb62b*/
    v102 = v5 - v102; /*0x1039cb63d*/
    v79 = v33; /*0x1039cb641*/
    v78 = v32; /*0x1039cb648*/
    v99 = v31; /*0x1039cb64f*/
    if ( (unsigned __int8)v29 >= 6u && (unsigned __int8)v30 >= 6u ) /*0x1039cb638*/
    {
      v69[0] = v31; /*0x1039cb66a*/
      v70 = v32; /*0x1039cb66d*/
      v71 = v33; /*0x1039cb671*/
      v72 = v34; /*0x1039cb675*/
      v38 = v5 - v98; /*0x1039cb679*/
      v73 = v5 - v98; /*0x1039cb67c*/
      v39 = v5 - (_QWORD)v101; /*0x1039cb680*/
      v74[1] = v5 - (_QWORD)v101; /*0x1039cb683*/
      v74[3] = v37; /*0x1039cb687*/
      v74[5] = v104; /*0x1039cb68f*/
      v74[7] = v95; /*0x1039cb69a*/
      v100.i64[0] = 0x444444444LL; /*0x1039cb6ab*/
      v100.i64[1] = (__int64)v69; /*0x1039cb6af*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x1039cb6d5*/
        a1: v29,
        a2: qword_10D7BB088,
        a3: 6,
        a4: (unsigned int)"[DFLog::RakNetMissingPingPong] Decryption failed {}, invalid dhf {}, incoming ack deserialize fail"
                      "ure {}, ack range bad {}, incoming nak deserialize failure {}, nak range bad {}, on got packet fai"
                      "led {}, failed create internal packet {}, dropped packet {}",
        a5: 255,
        a6: 1,
        _mm_loadu_si128(&v100));
      v29 = DFLog::RakNetMissingPingPong; /*0x1039cb6da*/
      v30 = (unsigned int)DFLog::RakNetMissingPingPong >> 8; /*0x1039cb6e3*/
      v36 = v39; /*0x1039cb6e6*/
      v35 = v38; /*0x1039cb6e9*/
      v34 = v102; /*0x1039cb6ec*/
    }
    v101 = (void *)*((unsigned int *)a2 + 161); /*0x1039cb6f7*/
    v40 = v5 - *((_DWORD *)a2 + 162); /*0x1039cb6fb*/
    if ( (unsigned __int8)v29 >= 6u && (unsigned __int8)v30 >= 6u )
    {
      v41 = v36; /*0x1039cb712*/
      v69[0] = v40; /*0x1039cb725*/
      v70 = v101; /*0x1039cb72c*/
      v100.i64[0] = 18; /*0x1039cb730*/
      v100.i64[1] = (__int64)v69; /*0x1039cb738*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: v29,
        a2: qword_10D7BB088,
        a3: 6,
        a4: (unsigned int)"[DFLog::RakNetMissingPingPong] Ack stats: time since last ack sent {}, max ack bitstream size {}",
        a5: 96,
        a6: 1,
        _mm_loadu_si128(&v100));
      v36 = v41; /*0x1039cb763*/
      v34 = v102; /*0x1039cb766*/
    }
    ++*((_DWORD *)a2 + 1306); /*0x1039cb76a*/
    if ( *((_BYTE *)a2 + 5220) != 1 ) /*0x1039cb779*/
    {
      v98 = v36; /*0x1039cb77f*/
      v80 = v37; /*0x1039cb783*/
      *((_BYTE *)a2 + 5220) = 1; /*0x1039cb78a*/
      RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1039cb7a0*/
        a1: (__int64)v69,
        a2: (__int64)&RBX::Telemetry::kRakNetMissingPingPongStats);
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastPingMs", a3: 19, a4: v81, a5: 1); /*0x1039cb7c8*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastMtuPingMs", a3: 22, a4: v91, a5: 1); /*0x1039cb7e9*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastPongMs", a3: 19, a4: v82, a5: 1); /*0x1039cb80a*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastMtuPongMs", a3: 22, a4: v92, a5: 1); /*0x1039cb82b*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastReliableReceiveMs", a3: 30, a4: v85, a5: 1); /*0x1039cb84c*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastAckReceivedMs", a3: 26, a4: v84, a5: 1); /*0x1039cb86d*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastPacketReceivedMs", a3: 29, a4: v86, a5: 1); /*0x1039cb88e*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastPacketSentMs", a3: 25, a4: v89, a5: 1); /*0x1039cb8af*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceOldestSentPacketMs", a3: 27, a4: v83, a5: 1); /*0x1039cb8d0*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceOldestUnsentAckMs", a3: 26, a4: v90, a5: 1); /*0x1039cb8f1*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "IsDeadConnection", a3: 16, a4: IsDeadConnection, a5: 1); /*0x1039cb90f*/
      RBX::Telemetry::FieldsContainer::addField( /*0x1039cb92d*/
        a1: v74,
        a2: "IsOutgoingDataWaiting",
        a3: 21,
        a4: IsOutgoingDataWaiting,
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "AreAcksWaiting", a3: 14, a4: v108, a5: 1); /*0x1039cb94b*/
      RBX::Telemetry::FieldsContainer::addField( /*0x1039cb969*/
        a1: v74,
        a2: "GetAvaliableNetworkCapacityInBytesInNextMs",
        a3: 42,
        a4: (int)AvaliableNetworkCapacityInBytesInNextMs,
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "ResendBufferMessages", a3: 20, a4: v93, a5: 1); /*0x1039cb98a*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "ResendBufferBytes", a3: 17, a4: v75, a5: 1); /*0x1039cb9ab*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "PacketLossLastSecond", a3: 20, a4: 1, a5: v96); /*0x1039cb9c9*/
      RBX::Telemetry::FieldsContainer::addField( /*0x1039cb9ea*/
        a1: v74,
        a2: "IsLimitedByOutgoingBandwidthLimit",
        a3: 33,
        a4: v76,
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "OutputQueueSize", a3: 15, a4: v105, a5: 1); /*0x1039cba08*/
      if ( DFFlag::RakPeerUseInstanceJobId == 1 ) /*0x1039cba14*/
      {
        v42 = *((unsigned __int8 *)v97 + 2984); /*0x1039cba1a*/
        if ( (v42 & 1) != 0 ) /*0x1039cba26*/
        {
          v43 = *((char **)v97 + 375); /*0x1039cba28*/
          v44 = *((_QWORD *)v97 + 374); /*0x1039cba2f*/
        }
        else
        {
          v43 = (char *)v97 + 2985; /*0x1039cba53*/
          v44 = v42 >> 1; /*0x1039cba5a*/
        }
      }
      else if ( (RBX::Http::gameID & 1) != 0 ) /*0x1039cba47*/
      {
        v44 = *((_QWORD *)&RBX::Http::gameID + 1); /*0x1039cba49*/
        v43 = (char *)qword_10D783240; /*0x1039cba4d*/
      }
      else
      {
        v44 = (unsigned __int8)RBX::Http::gameID >> 1; /*0x1039cba5f*/
        v43 = (char *)&RBX::Http::gameID + 1; /*0x1039cba62*/
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "GameId", a3: 6, a4: v43, a5: v44, a6: 1); /*0x1039cba7a*/
      v45 = *((unsigned __int8 *)v97 + 3008); /*0x1039cba83*/
      if ( (v45 & 1) != 0 ) /*0x1039cba8f*/
      {
        v46 = *((char **)v97 + 378); /*0x1039cba91*/
        v47 = *((_QWORD *)v97 + 377); /*0x1039cba98*/
      }
      else
      {
        v46 = (char *)v97 + 3009; /*0x1039cbaa1*/
        v47 = v45 >> 1; /*0x1039cbaa8*/
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "RccLogPrefix", a3: 12, a4: v46, a5: v47, a6: 1); /*0x1039cbac0*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "UserId", a3: 6, a4: *((unsigned int *)v97 + 758), a5: 1); /*0x1039cbae4*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastPingSentMs", a3: 23, a4: v87, a5: 1); /*0x1039cbb05*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastPongSentMs", a3: 23, a4: v88, a5: 1); /*0x1039cbb26*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastMtuPingSentMs", a3: 26, a4: v94, a5: 1); /*0x1039cbb47*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastMtuPongSentMs", a3: 26, a4: v77, a5: 1); /*0x1039cbb68*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastDecryptionFailedMs", a3: 31, a4: v99, a5: 1); /*0x1039cbb86*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastInvalidDhfMs", a3: 25, a4: v78, a5: 1); /*0x1039cbba7*/
      RBX::Telemetry::FieldsContainer::addField( /*0x1039cbbc8*/
        a1: v74,
        a2: "TimeSinceLastIncomingAckDeserializeFailureMs",
        a3: 44,
        a4: v79,
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastAckRangeBadMs", a3: 26, a4: v34, a5: 1); /*0x1039cbbe5*/
      RBX::Telemetry::FieldsContainer::addField( /*0x1039cbc02*/
        a1: v74,
        a2: "TimeSinceLastIncomingNakDeserializeFailureMs",
        a3: 44,
        a4: v35,
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastNakRangeBadMs", a3: 26, a4: v98, a5: 1); /*0x1039cbc20*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastOnGotPacketFailedMs", a3: 32, a4: v80, a5: 1); /*0x1039cbc41*/
      RBX::Telemetry::FieldsContainer::addField( /*0x1039cbc5f*/
        a1: v74,
        a2: "TimeSinceLastFailedCreateInternalPacketMs",
        a3: 41,
        a4: v104,
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastPacketDroppedMs", a3: 28, a4: v95, a5: 1); /*0x1039cbc80*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "TimeSinceLastAckSentMs", a3: 22, a4: v40, a5: 1); /*0x1039cbc9c*/
      RBX::Telemetry::FieldsContainer::addField(a1: v74, a2: "MaxAckBitStreamSizeBytes", a3: 24, a4: (int)v101, a5: 1); /*0x1039cbcba*/
      RBX::Telemetry::FieldsContainer::addField( /*0x1039cbcdb*/
        a1: v74,
        a2: "NumReportsMissingPingPong",
        a3: 25,
        a4: *((int *)a2 + 1306),
        a5: 1);
      RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v69); /*0x1039cbce7*/
      RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v69); /*0x1039cbcfa*/
    }
    for ( k = 0; k != -16; k -= 4 ) /*0x1039cbd06*/
    {
      v49 = (void **)v53[k]; /*0x1039cbd09*/
      if ( &v53[k + 3] != v49 ) /*0x1039cbd18*/
        operator delete(a1: v49); /*0x1039cbd1a*/
    }
  }
}

// Address: 0x1039cbeca | Name: __ZN6RakNet7RakPeer22HandleActiveSystemListERNS_9BitStreamERyS3_
__int64 __fastcall RakNet::RakPeer::HandleActiveSystemList(
        RakNet::RakPeer *this,
        RakNet::BitStream *a2,
        unsigned __int64 *a3,
        unsigned __int64 *a4)
{
  int v5; // r8d
  int v6; // r9d
  int v7; // ecx
  int v8; // r14d
  int v9; // ebx
  __int64 v10; // rcx
  __int64 v11; // rax
  __int64 v12; // r15
  unsigned __int64 *v13; // rbx
  unsigned __int64 v14; // r14
  __int64 i; // rax
  __int64 v16; // rax
  char *v17; // rcx
  __int64 v18; // rdx
  __int64 v19; // rcx
  __int64 v20; // r8
  __int64 v21; // r9
  __int64 j; // rbx
  void **v23; // rdi
  __int64 v24; // rax
  std::__shared_weak_count *v25; // r15
  std::__shared_weak_count *v26; // r15
  RakNet::RakPeer::RemoteSystemStruct *v27; // r13
  bool v28; // r14
  __int64 v29; // rdx
  __int64 v30; // r8
  __int64 v31; // r9
  unsigned int v32; // eax
  _QWORD *v33; // rdi
  __int64 v34; // rax
  int v35; // eax
  const unsigned __int64 *v36; // rcx
  bool v37; // r15
  int v38; // ebx
  int v39; // eax
  int v40; // ecx
  __int64 v41; // r15
  unsigned int v42; // eax
  unsigned __int64 v43; // rax
  const char *v44; // rcx
  __int64 v45; // r14
  RakNet::ReliabilityLayer *v46; // r13
  int v47; // r12d
  RakNet::ReliabilityLayer *v48; // rdi
  unsigned __int8 IsOutgoingDataWaiting; // al
  int v50; // ecx
  int v51; // r8d
  int v52; // r9d
  __int64 v53; // r15
  int v54; // eax
  char v55; // r12
  bool v56; // zf
  const char *v57; // rcx
  RakNet::ReliabilityLayer *v58; // rbx
  __int16 v59; // ax
  unsigned __int64 v60; // rax
  __int64 v61; // rcx
  int v62; // ecx
  int v63; // r8d
  int v64; // r9d
  const char *v66; // rsi
  const char *v67; // rsi
  _BYTE v68[4]; // [rsp+3Ch] [rbp-354h]
  std::__shared_weak_count *v69[2]; // [rsp+40h] [rbp-350h] BYREF
  char v70; // [rsp+60h] [rbp-330h]
  char v71; // [rsp+64h] [rbp-32Ch]
  char v72; // [rsp+68h] [rbp-328h]
  char v73; // [rsp+6Ch] [rbp-324h]
  char v74; // [rsp+70h] [rbp-320h]
  char v75; // [rsp+74h] [rbp-31Ch]
  char v76; // [rsp+78h] [rbp-318h]
  char v77; // [rsp+7Ch] [rbp-314h]
  char v78; // [rsp+98h] [rbp-2F8h] BYREF
  void *v79[4]; // [rsp+E0h] [rbp-2B0h] BYREF
  __int128 v80; // [rsp+100h] [rbp-290h]
  __int128 v81; // [rsp+110h] [rbp-280h]
  __int128 v82; // [rsp+120h] [rbp-270h]
  __int128 v83; // [rsp+130h] [rbp-260h]
  _BYTE v84[80]; // [rsp+1F0h] [rbp-1A0h] BYREF
  int v85; // [rsp+240h] [rbp-150h]
  __int128 v86; // [rsp+248h] [rbp-148h]
  __int128 v87; // [rsp+258h] [rbp-138h]
  __int128 v88; // [rsp+268h] [rbp-128h]
  __int128 v89; // [rsp+278h] [rbp-118h]
  __int128 v90; // [rsp+288h] [rbp-108h]
  unsigned __int64 *v91; // [rsp+2A8h] [rbp-E8h]
  __int64 v92; // [rsp+2B0h] [rbp-E0h]
  RakNet::SignaledEvent *v93; // [rsp+2B8h] [rbp-D8h]
  std::__shared_weak_count *v94[2]; // [rsp+2C0h] [rbp-D0h]
  __int128 v95; // [rsp+2D8h] [rbp-B8h] BYREF
  __int64 v96; // [rsp+2F8h] [rbp-98h]
  int v97; // [rsp+304h] [rbp-8Ch]
  int IsDeadConnection; // [rsp+308h] [rbp-88h]
  _BOOL4 v99; // [rsp+30Ch] [rbp-84h]
  _BOOL4 v100; // [rsp+310h] [rbp-80h]
  int v101; // [rsp+314h] [rbp-7Ch]
  _BOOL4 v102; // [rsp+318h] [rbp-78h]
  int v103; // [rsp+31Ch] [rbp-74h]
  RBX::SystemUtil *v104; // [rsp+320h] [rbp-70h]
  RakNet::RakPeer::RemoteSystemStruct *v105; // [rsp+328h] [rbp-68h]
  int v106; // [rsp+334h] [rbp-5Ch]
  RakNet::RakPeer *v107; // [rsp+338h] [rbp-58h]
  const char *v108; // [rsp+340h] [rbp-50h]
  int v109; // [rsp+34Ch] [rbp-44h]
  RakNet::ReliabilityLayer *v110; // [rsp+350h] [rbp-40h]
  int v111; // [rsp+35Ch] [rbp-34h]
  unsigned __int64 *v112; // [rsp+360h] [rbp-30h]

  v112 = a4; /*0x1039cbede*/
  v91 = a3; /*0x1039cbee2*/
  v92 = (__int64)a2; /*0x1039cbee9*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)&v95); /*0x1039cbefa*/
  v7 = *((_DWORD *)this + 189); /*0x1039cbeff*/
  if ( *((_DWORD *)this + 188) != 0 )
  {
    v93 = (RakNet::RakPeer *)((char *)this + 2560); /*0x1039cbf1f*/
    v8 = 0; /*0x1039cbf28*/
    v9 = 0; /*0x1039cbf2b*/
    v109 = 0; /*0x1039cbf2d*/
    v107 = this; /*0x1039cbf34*/
    while ( 1 )
    {
      v97 = v8; /*0x1039cbf38*/
      v106 = v9; /*0x1039cbf3f*/
      v10 = (unsigned int)(v7 + 1); /*0x1039cbf42*/
      if ( (unsigned int)v10 >= *((_DWORD *)this + 188) ) /*0x1039cbf4e*/
        v10 = 0; /*0x1039cbf4e*/
      v11 = *((_QWORD *)this + 93); /*0x1039cbf51*/
      v96 = v10; /*0x1039cbf59*/
      v12 = *(_QWORD *)(v11 + 8 * v10); /*0x1039cbf60*/
      RakNet::SystemAddress::operator=(a1: &v95, a2: v12 + 4); /*0x1039cbf72*/
      v13 = v112; /*0x1039cbf77*/
      LODWORD(v69[0]) = *(_DWORD *)v112; /*0x1039cbf7d*/
      RakNet::RakPeer::logMissingPingPong( /*0x1039cbf92*/
        this,
        a2: (RakNet::RakPeer::RemoteSystemStruct *)v12,
        a3: (const unsigned int *)v69,
        a4: 0);
      if ( *v13 > *(_QWORD *)(v12 + 5176) ) /*0x1039cbfa1*/
      {
        v14 = *v13 - *(_QWORD *)(v12 + 5176); /*0x1039cbf9a*/
        if ( v14 > (unsigned int)RakNet::ReliabilityLayer::GetTimeoutTime(this: (RakNet::ReliabilityLayer *)(v12 + 392)) >> 1 /*0x1039cbfc9*/
          && *(_DWORD *)(v12 + 5364) == 7 )
        {
          for ( i = 4; i != 36; i += 8 ) /*0x1039cbfcf*/
          {
            v68[i] = 0; /*0x1039cbfd6*/
            *((_BYTE *)v69 + i) = 0; /*0x1039cbfdd*/
          }
          v70 = 0; /*0x1039cbfee*/
          v71 = 0; /*0x1039cbff4*/
          v72 = 0; /*0x1039cbffa*/
          v73 = 0; /*0x1039cc000*/
          v74 = 0; /*0x1039cc006*/
          v75 = 0; /*0x1039cc00c*/
          v76 = 0; /*0x1039cc012*/
          v77 = 0; /*0x1039cc018*/
          v16 = 128; /*0x1039cc01e*/
          v17 = &v78; /*0x1039cc023*/
          do /*0x1039cc046*/
          {
            *((_QWORD *)v17 - 3) = v17; /*0x1039cc02a*/
            *((_QWORD *)v17 - 2) = 0; /*0x1039cc02e*/
            *((_QWORD *)v17 - 1) = 4; /*0x1039cc036*/
            v17 += 32; /*0x1039cc03e*/
            v16 -= 32; /*0x1039cc042*/
          }
          while ( v16 != 0 ); /*0x1039cc046*/
          v90 = 0; /*0x1039cc052*/
          v89 = 0; /*0x1039cc059*/
          v88 = 0; /*0x1039cc060*/
          v87 = 0; /*0x1039cc067*/
          v86 = 0; /*0x1039cc06e*/
          v83 = 0; /*0x1039cc075*/
          v82 = 0; /*0x1039cc079*/
          v81 = 0; /*0x1039cc07d*/
          v80 = 0; /*0x1039cc081*/
          memset(v84, 0, 28); /*0x1039cc08b*/
          memset(&v84[32], 0, 48); /*0x1039cc0a0*/
          v85 = 0; /*0x1039cc0a7*/
          if ( *(_DWORD *)(RakNet::ReliabilityLayer::GetStatistics( /*0x1039cc0ce*/
                             this: (RakNet::ReliabilityLayer *)(v12 + 392),
                             a2: (RakNet::RakNetStatistics *)v69)
                         + 408) == 0 )
          {
            RakNet::RakPeer::SendPings(this, a2: 2, a3: v18, a4: v19, a5: v20, a6: v21, a7: v95); /*0x1039cc0ef*/
            *(_QWORD *)(v12 + 5176) = *v112; /*0x1039cc0fb*/
          }
          for ( j = 0; j != -16; j -= 4 ) /*0x1039cc102*/
          {
            v23 = (void **)v79[j]; /*0x1039cc104*/
            if ( &v79[j + 3] != v23 ) /*0x1039cc113*/
              operator delete(a1: v23); /*0x1039cc115*/
          }
        }
      }
      if ( *(char *)(v12 + 5256) >= 0 && *v112 - *(_QWORD *)(v12 + 5192) >= DFInt::CLI50798MS ) /*0x1039cc149*/
      {
        *(_QWORD *)(v12 + 5192) = *v112; /*0x1039cc14b*/
        RakNet::RakPeer::reportAvoidPacketStatistics(this, a2: (RakNet::RakPeer::RemoteSystemStruct *)v12); /*0x1039cc158*/
      }
      v104 = (RBX::SystemUtil *)(v12 + 4); /*0x1039cc15d*/
      v24 = *(_QWORD *)(v12 + 5240); /*0x1039cc161*/
      *(_OWORD *)v94 = *(_OWORD *)(v12 + 5232); /*0x1039cc170*/
      if ( v24 != 0 ) /*0x1039cc17a*/
        _InterlockedIncrement64((volatile signed __int64 *)(v24 + 8)); /*0x1039cc17c*/
      v111 = *(_DWORD *)(v12 + 5216); /*0x1039cc18f*/
      *(_OWORD *)v69 = 0; /*0x1039cc1a7*/
      std::shared_ptr<RBX::Rupp::Rupp>::operator=[abi:ne200100](a1: v69); /*0x1039cc1bf*/
      v105 = (RakNet::RakPeer::RemoteSystemStruct *)v12; /*0x1039cc1c4*/
      v110 = (RakNet::ReliabilityLayer *)(v12 + 392); /*0x1039cc1e1*/
      v111 = RakNet::ReliabilityLayer::Update( /*0x1039cc204*/
               this: (RakNet::ReliabilityLayer *)(v12 + 392),
               a2: v92,
               a3: (__int64)v69,
               a4: v12 + 36);
      v25 = v69[1]; /*0x1039cc207*/
      if ( v69[1] != nullptr /*0x1039cc22a*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v69[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v25 + 16LL))(a1: v25); /*0x1039cc232*/
        std::__shared_weak_count::__release_weak(this: v25); /*0x1039cc238*/
      }
      v26 = v94[1]; /*0x1039cc23d*/
      this = v107; /*0x1039cc247*/
      v27 = v105; /*0x1039cc24b*/
      if ( v94[1] != nullptr /*0x1039cc261*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v94[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v26 + 16LL))(a1: v26); /*0x1039cc269*/
        std::__shared_weak_count::__release_weak(this: v26); /*0x1039cc26f*/
      }
      v28 = *v112 <= *((_QWORD *)v27 + 648) || *v112 - *((_QWORD *)v27 + 648) < 0x2711; /*0x1039cc28f*/
      LODWORD(v108) = *((_DWORD *)v27 + 1341) - 4; /*0x1039cc29c*/
      if ( (unsigned __int8)RakNet::ReliabilityLayer::IsDeadConnection(this: v110) == 0 ) /*0x1039cc2aa*/
      {
        v35 = *((_DWORD *)v27 + 1341); /*0x1039cc2df*/
        v36 = (const unsigned __int64 *)(unsigned int)(v35 - 1); /*0x1039cc2e6*/
        if ( (unsigned int)v36 <= 1 ) /*0x1039cc2ec*/
        {
          if ( (unsigned __int8)RakNet::ReliabilityLayer::IsOutgoingDataWaiting(this: v110) == 0 ) /*0x1039cc2f9*/
            goto LABEL_30; /*0x1039cc2f9*/
          v35 = *((_DWORD *)v27 + 1341); /*0x1039cc2fb*/
        }
        if ( v35 == 3 ) /*0x1039cc305*/
        {
          if ( (unsigned __int8)RakNet::ReliabilityLayer::AreAcksWaiting(this: v110) != 0 ) /*0x1039cc312*/
          {
            v37 = (unsigned int)v108 >= 3; /*0x1039cc318*/
            if ( (unsigned __int8)RakNet::ReliabilityLayer::AckTimeout(this: v110, a2: *v112) == 0 && (v28 || v37) ) /*0x1039cc334*/
            {
LABEL_47:
              v38 = v106; /*0x1039cc388*/
              if ( (v109 & 1 | (v111 == 0)) == 0 ) /*0x1039cc397*/
              {
                v39 = v96; /*0x1039cc39d*/
                if ( *((_DWORD *)this + 189) == (_DWORD)v96 ) /*0x1039cc3ac*/
                {
                  v109 = 0; /*0x1039cc3b2*/
                }
                else
                {
                  *((_DWORD *)this + 189) = v96; /*0x1039cc791*/
                  LOBYTE(v39) = 1; /*0x1039cc799*/
                  v109 = v39; /*0x1039cc79b*/
                }
              }
              if ( *((_DWORD *)v27 + 1341) == 7 ) /*0x1039cc7a6*/
              {
                v60 = *v112; /*0x1039cc7ac*/
                if ( *v112 > *((_QWORD *)v27 + 636) ) /*0x1039cc7b6*/
                {
                  if ( *((_BYTE *)this + 168) != 0 ) /*0x1039cc7c1*/
                    goto LABEL_88; /*0x1039cc7c1*/
                  if ( *((_WORD *)v27 + 1) == 0xFFFF ) /*0x1039cc7cc*/
                  {
                    v60 = *v112; /*0x1039cc7d2*/
LABEL_88:
                    v61 = v60 + DFInt::RakNetPingFrequencyMillisecond; /*0x1039cc7d5*/
                    *((_QWORD *)v27 + 636) = v61; /*0x1039cc7df*/
                    RakNet::RakPeer::SendPings(this, a2: 0, a3: v29, a4: v61, a5: v30, a6: v31, a7: v95); /*0x1039cc802*/
                    RakNet::SignaledEvent::SetEvent(this: v93); /*0x1039cc80e*/
                  }
                }
              }
              RakNet::RakPeer::HandlePacketRequest(this, a2: v27, a3: (const RakNet::SystemAddress *)&v95, a4: v36); /*0x1039cc820*/
              goto LABEL_80; /*0x1039cc825*/
            }
          }
        }
        else if ( v28 || (unsigned int)v108 >= 3 ) /*0x1039cc380*/
        {
          goto LABEL_47; /*0x1039cc382*/
        }
      }
LABEL_30:
      v32 = *((_DWORD *)v27 + 1341); /*0x1039cc2ac*/
      if ( v32 - 1 >= 2 ) /*0x1039cc2b9*/
      {
        if ( v32 == 3 ) /*0x1039cc2c2*/
        {
          v33 = *((_QWORD **)this + 423); /*0x1039cc2c4*/
          v34 = 80; /*0x1039cc2cc*/
          if ( v33 == nullptr ) /*0x1039cc2d4*/
            goto LABEL_57; /*0x1039cc2d4*/
LABEL_53:
          (*(void (__fastcall **)(_QWORD *, RBX::SystemUtil *))(*v33 + v34))(a1: v33, a2: v104); /*0x1039cc3de*/
        }
        else
        {
          if ( (unsigned __int8)RakNet::ReliabilityLayer::IsDeadConnection(this: v110) != 0 ) /*0x1039cc34d*/
          {
            if ( *((_DWORD *)v27 + 1328) == 1 ) /*0x1039cc357*/
              *((_DWORD *)v27 + 1328) = *((_DWORD *)v27 + 208); /*0x1039cc360*/
            v33 = *((_QWORD **)this + 423); /*0x1039cc367*/
            v34 = 72; /*0x1039cc36f*/
          }
          else
          {
            if ( v28 || (unsigned int)v108 >= 3 ) /*0x1039cc3c8*/
              goto LABEL_54; /*0x1039cc3ca*/
            v33 = *((_QWORD **)this + 423); /*0x1039cc3cc*/
            v34 = 64; /*0x1039cc3d4*/
          }
          if ( v33 != nullptr ) /*0x1039cc3dc*/
            goto LABEL_53; /*0x1039cc3dc*/
        }
LABEL_54:
        v32 = *((_DWORD *)v27 + 1341); /*0x1039cc3e8*/
      }
      if ( v32 <= 7 )
      {
        v40 = 154; /*0x1039cc3f8*/
        if ( _bittest(&v40, v32) )
        {
LABEL_57:
          v41 = FLog::Network; /*0x1039cc406*/
          v42 = (unsigned int)FLog::Network >> 8; /*0x1039cc40c*/
          if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1039cc418*/
          {
            FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] Connection lost", 0); /*0x1039cc42f*/
            v41 = FLog::Network; /*0x1039cc434*/
            v42 = (unsigned int)FLog::Network >> 8; /*0x1039cc43a*/
          }
          if ( (unsigned __int8)v41 >= 6u && (unsigned __int8)v42 >= 3u )
          {
            v43 = *((unsigned int *)v27 + 1341); /*0x1039cc44d*/
            v44 = "Unknown"; /*0x1039cc454*/
            if ( v43 <= 7 ) /*0x1039cc45f*/
              v44 = off_10C903308[v43]; /*0x1039cc468*/
            FLog::FastLogFormatted(
              a1: v41,
              a2: qword_10D7BBAA8,
              a3: (unsigned int)"[FLog::Network] Connection lost: connectMode: %s, timeMS:%llu, connectionTime %llu",
              a4: (_DWORD)v44,
              a5: *v112,
              a6: *((_QWORD *)v27 + 648));
            v41 = FLog::Network; /*0x1039cc48f*/
            v42 = (unsigned int)FLog::Network >> 8; /*0x1039cc495*/
          }
          if ( (unsigned __int8)v41 >= 6u && (unsigned __int8)v42 >= 3u )
          {
            v45 = qword_10D7BBAA8; /*0x1039cc4a8*/
            v46 = v110; /*0x1039cc4b3*/
            v47 = (unsigned __int8)RakNet::ReliabilityLayer::AckTimeout(this: v110, a2: *v112); /*0x1039cc4bf*/
            v48 = v46; /*0x1039cc4c3*/
            v27 = v105; /*0x1039cc4c6*/
            IsOutgoingDataWaiting = RakNet::ReliabilityLayer::IsOutgoingDataWaiting(this: v48); /*0x1039cc4ca*/
            v50 = v47; /*0x1039cc4e0*/
            this = v107; /*0x1039cc4e3*/
            FLog::FastLog(
              a1: v41,
              a2: v45,
              a3: "[FLog::Network] Connection lost: AckTimeout %d, IsOutgoingDataWaiting %d",
              v50,
              IsOutgoingDataWaiting);
          }
          v53 = RakNet::RakPeer::AllocPacket(this, a2: 1u, a3: "", a4: 0); /*0x1039cc505*/
          v54 = *((_DWORD *)v27 + 1341); /*0x1039cc508*/
          if ( v54 == 7 )
          {
            v55 = 22; /*0x1039cc669*/
            if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1039cc666*/
              FLog::FastLog( /*0x1039cc67b*/
                a1: FLog::Network,
                a2: qword_10D7BBAA8,
                a3: "[FLog::Network] Connection lost - Cannot contact server/client",
                0);
          }
          else if ( v54 == 4 )
          {
            if ( DFFlag::AddRakNetDebugLogs == 1 )
            {
              v55 = 17; /*0x1039cc545*/
              if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
              {
                v99 = (unsigned int)v108 < 3; /*0x1039cc559*/
                v56 = *((_BYTE *)v107 + 3728) == 0; /*0x1039cc563*/
                v105 = (RakNet::RakPeer::RemoteSystemStruct *)qword_10D7BB0C8; /*0x1039cc571*/
                v57 = "client"; /*0x1039cc575*/
                if ( !v56 ) /*0x1039cc583*/
                  v57 = "server"; /*0x1039cc583*/
                v108 = v57; /*0x1039cc587*/
                v58 = v110; /*0x1039cc58b*/
                v104 = DFLog::RakNetConnectTrace; /*0x1039cc58f*/
                IsDeadConnection = (unsigned __int8)RakNet::ReliabilityLayer::IsDeadConnection(this: v110); /*0x1039cc59e*/
                v100 = *((_DWORD *)v27 + 1341) == 1; /*0x1039cc5b1*/
                v101 = (unsigned __int8)RakNet::ReliabilityLayer::IsOutgoingDataWaiting(this: v58); /*0x1039cc5bf*/
                v102 = *((_DWORD *)v27 + 1341) == 3; /*0x1039cc5cf*/
                v103 = (unsigned __int8)RakNet::ReliabilityLayer::AreAcksWaiting(this: v58); /*0x1039cc5dd*/
                RakNet::ReliabilityLayer::AckTimeout(this: v58, a2: *v112); /*0x1039cc5ed*/
                FLog::FastLogFormatted(
                  a1: (_DWORD)v104,
                  a2: (_DWORD)v105,
                  a3: (unsigned int)"[DFLog::RakNetConnectTrace] (amServer: %s) RakNet connection failed. IsDeadConnection():"
                                " %d,\n"
                                "connectMode == DISCONNECT_ASAP: %d,\n"
                                "IsOutgoingDataWaiting(): %d,\n"
                                "connectMode == DISCONNECT_PEER_NOTIFY: %d,\n"
                                "AreAcksWaiting(): %d,\n"
                                "AckTimeout(%lld): %d,\n"
                                "isAfterOpenConnectionOneAndTwoButBeforePasswordAccepted: %d,\n"
                                "timeSinceConnectionAttempt: %lld",
                  a4: (_DWORD)v108,
                  a5: IsDeadConnection,
                  a6: v100);
              }
            }
            else
            {
              v55 = 17; /*0x1039cc6ca*/
              if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1039cc6c7*/
                FLog::FastLog( /*0x1039cc6de*/
                  a1: FLog::Network,
                  a2: qword_10D7BBAA8,
                  a3: "[FLog::Network] Connection attempt failed",
                  0);
            }
          }
          else
          {
            v55 = 21; /*0x1039cc691*/
            if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
              FLog::FastLogFormatted(
                a1: FLog::Network,
                a2: qword_10D7BBAA8,
                a3: (unsigned int)"[FLog::Network] Disconnection Notification. Reason: %d",
                a4: *((_DWORD *)v107 + 504),
                a5: v51,
                a6: v52);
          }
          **(_BYTE **)(v53 + 56) = v55; /*0x1039cc6e7*/
          *(_QWORD *)(v53 + 32) = *((_QWORD *)v27 + 650); /*0x1039cc6f1*/
          *(_WORD *)(v53 + 40) = *((_WORD *)v27 + 2604); /*0x1039cc6fd*/
          RakNet::SystemAddress::operator=(a1: v53, a2: &v95); /*0x1039cc70c*/
          v59 = *((_WORD *)v27 + 2624); /*0x1039cc711*/
          *(_WORD *)(v53 + 30) = v59; /*0x1039cc719*/
          *(_WORD *)(v53 + 40) = v59; /*0x1039cc71e*/
          this = v107; /*0x1039cc723*/
          RakNet::RakPeer::AddPacketToProducer(this: v107, a2: v53, a3: 0); /*0x1039cc72f*/
        }
      }
      RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v69, a2: (const RakNet::SystemAddress *)&v95); /*0x1039cc734*/
      RakNet::RakPeer::CloseConnectionInternal(this, a2: (RakNet::AddressOrGUID *)v69, a3: 0, a4: 1); /*0x1039cc75a*/
      v38 = v106; /*0x1039cc75f*/
LABEL_80:
      v8 = v97 + 1; /*0x1039cc762*/
      v9 = v111 + v38; /*0x1039cc76c*/
      v7 = v96; /*0x1039cc77a*/
      if ( (unsigned int)(v97 + 1) >= *((_DWORD *)this + 188) ) /*0x1039cc786*/
        goto LABEL_91; /*0x1039cc786*/
    }
  }
  v9 = 0; /*0x1039cc82a*/
  v8 = 0; /*0x1039cc82c*/
LABEL_91:
  if ( (_BYTE)`guard variable for'RakNet::RakPeer::HandleActiveSystemList(RakNet::BitStream &,unsigned long long &,unsigned long long &)::proflabeltoken == 0 /*0x1039cc892*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::RakPeer::HandleActiveSystemList(RakNet::BitStream &,unsigned long long &,unsigned long long &)::proflabeltoken) != 0 )
  {
    v69[0] = (std::__shared_weak_count *)"lName"; /*0x1039cc89b*/
    RakNet::RakPeer::HandleActiveSystemList(RakNet::BitStream &,unsigned long long &,unsigned long long &)::proflabeltoken = RBX::Profiler::getLabelToken(this: (RBX::Profiler *)&aDebughistoryid[-392619], a2: v66); /*0x1039cc8b5*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::RakPeer::HandleActiveSystemList(RakNet::BitStream &,unsigned long long &,unsigned long long &)::proflabeltoken); /*0x1039cc8c3*/
  }
  RBX::Profiler::addLabelFormat(
    a1: RakNet::RakPeer::HandleActiveSystemList(RakNet::BitStream &,unsigned long long &,unsigned long long &)::proflabeltoken,
    a2: (unsigned int)"#clients: %d",
    a3: v8,
    a4: v7,
    a5: v5,
    a6: v6);
  if ( (_BYTE)`guard variable for'RakNet::RakPeer::HandleActiveSystemList(RakNet::BitStream &,unsigned long long &,unsigned long long &)::proflabeltoken == 0 /*0x1039cc8db*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::RakPeer::HandleActiveSystemList(RakNet::BitStream &,unsigned long long &,unsigned long long &)::proflabeltoken) != 0 )
  {
    v69[0] = (std::__shared_weak_count *)"r is nullptr in alts_tsi_handshaker_handle_response()"; /*0x1039cc8e8*/
    RakNet::RakPeer::HandleActiveSystemList(RakNet::BitStream &,unsigned long long &,unsigned long long &)::proflabeltoken = RBX::Profiler::getLabelToken(this: (RBX::Profiler *)&aRecvBufferIsNu[-285718], a2: v67); /*0x1039cc902*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::RakPeer::HandleActiveSystemList(RakNet::BitStream &,unsigned long long &,unsigned long long &)::proflabeltoken); /*0x1039cc910*/
  }
  return RBX::Profiler::addLabelFormat(
           a1: RakNet::RakPeer::HandleActiveSystemList(RakNet::BitStream &,unsigned long long &,unsigned long long &)::proflabeltoken,
           a2: (unsigned int)"#packets sent: %d",
           a3: v9,
           a4: v62,
           a5: v63,
           a6: v64);
}

// Address: 0x1039cc96c | Name: __ZN6RakNet7RakPeer27reportAvoidPacketStatisticsEPNS0_18RemoteSystemStructE
__int64 __fastcall RakNet::RakPeer::reportAvoidPacketStatistics(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2)
{
  __int64 v4; // rdx
  __int64 v5; // rcx
  int v6; // eax
  __int64 v7; // rdx
  __int64 v8; // rcx
  char v9; // al
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int128 v13; // [rsp+0h] [rbp-210h] BYREF
  void *v14; // [rsp+10h] [rbp-200h]
  void *v15[59]; // [rsp+20h] [rbp-1F0h] BYREF

  if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x1039cc99b*/
                          this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::CLI50798HundredthsPercentage,
                          (int)a2) == 0 )
    goto LABEL_13; /*0x1039cc99b*/
  RBX::Analytics::InfluxDb::Points::Points(a1: v15, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1039cc9b1*/
  v6 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)a2 + 428) + 200LL))(a1: *((_QWORD *)a2 + 428)); /*0x1039cc9c0*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v15, a2: "MTU", a3: v6); /*0x1039cc9d6*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039cc9f2*/
    this: (RBX::Analytics::InfluxDb::Points *)v15,
    a2: "PaddedPacketsRatio",
    a3: *((double *)a2 + 560));
  v9 = *((_BYTE *)this + 3656); /*0x1039cc9f7*/
  if ( (v9 & 1) != 0 ) /*0x1039cc9ff*/
  {
    v7 = *((_QWORD *)this + 458); /*0x1039cca23*/
    if ( v7 != 0 ) /*0x1039cca2d*/
    {
      std::string::__init_copy_ctor_external(a1: &v13, a2: *((_QWORD *)this + 459), a3: v7); /*0x1039cca3d*/
      goto LABEL_8; /*0x1039cca42*/
    }
LABEL_7:
    std::string::basic_string[abi:ne200100]<0>(a1: &v13, a2: ".", a3: v7, a4: v8); /*0x1039cca44*/
    goto LABEL_8; /*0x1039cca52*/
  }
  if ( v9 == 0 ) /*0x1039cca03*/
    goto LABEL_7; /*0x1039cca03*/
  v14 = *((void **)this + 459); /*0x1039cca10*/
  v13 = *(_OWORD *)((char *)this + 3656); /*0x1039cca1a*/
LABEL_8:
  RBX::Analytics::InfluxDb::Points::addPoint(a1: v15, a2: "AvoidedPayloads", a3: &v13); /*0x1039cca57*/
  if ( (v13 & 1) != 0 ) /*0x1039cca78*/
    operator delete(a1: v14); /*0x1039cca81*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v13, a2: "AvoidPayloadSizeStatistics", a3: v10, a4: v11); /*0x1039cca94*/
  RBX::Analytics::InfluxDb::Points::report( /*0x1039ccaaf*/
    a1: v15,
    a2: &v13,
    a3: (unsigned int)DFInt::CLI50798HundredthsPercentage,
    a4: 0);
  if ( (v13 & 1) != 0 ) /*0x1039ccabb*/
    operator delete(a1: v14); /*0x1039ccac4*/
  RBX::Analytics::InfluxDb::Points::~Points(this: v15); /*0x1039ccad0*/
LABEL_13:
  if ( *((_BYTE *)this + 3704) == 1 ) /*0x1039ccadc*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v15, a2: "ReducedMTU", a3: v4, a4: v5); /*0x1039ccaec*/
    RBX::Analytics::EphemeralCounter::reportCounter(a1: v15, a2: 1, a3: 0); /*0x1039ccaff*/
    if ( ((__int64)v15[0] & 1) != 0 ) /*0x1039ccb0b*/
      operator delete(a1: v15[2]); /*0x1039ccb14*/
  }
  return __stack_chk_guard; /*0x1039ccb29*/
}

// Address: 0x1039cd114 | Name: __ZN6RakNet7RakPeer14RunUpdateCycleEyyRNS_9BitStreamE
unsigned __int64 __fastcall RakNet::RakPeer::RunUpdateCycle(
        RakNet::RakPeer *this,
        unsigned __int64 a2,
        unsigned __int64 a3,
        RakNet::BitStream *a4)
{
  unsigned __int64 v5; // r12
  __int64 v7; // r14
  int v8; // r14d
  int v9; // r15d
  const unsigned __int64 *v10; // rsi
  RakNet::BitStream *v11; // r14
  __int64 v12; // r13
  const char *v13; // r15
  int v14; // r13d
  __int64 v15; // r12
  unsigned __int64 v16; // r14
  __int64 v17; // rdx
  unsigned __int64 v18; // rcx
  RBX *v19; // rdi
  unsigned __int64 v20; // r15
  unsigned __int8 v22; // r8
  unsigned __int8 v23; // r8
  _QWORD v24[14]; // [rsp+0h] [rbp-C0h] BYREF
  RakNet::BitStream *v25; // [rsp+70h] [rbp-50h]
  unsigned __int64 v26; // [rsp+78h] [rbp-48h]
  unsigned __int64 v27; // [rsp+80h] [rbp-40h]
  unsigned __int64 v28; // [rsp+88h] [rbp-38h] BYREF
  unsigned __int64 v29[6]; // [rsp+90h] [rbp-30h] BYREF

  v5 = a2; /*0x1039cd12b*/
  v28 = a2; /*0x1039cd131*/
  v29[0] = a3; /*0x1039cd135*/
  if ( DFFlag::ReportPktDropStats2 == 1 ) /*0x1039cd140*/
    RakNet::RakPeer::TrackDroppedPackets::Report(this: (RakNet::RakPeer *)((char *)this + 3416), a2: a3); /*0x1039cd14c*/
  v25 = a4; /*0x1039cd15b*/
  if ( FFlag::DebugClientDumpMicroprofileForJoins == 1 )
  {
    v27 = RakNet::RakPeer::ProcessBufferedPackets(this, a2: a4, a3: v5); /*0x1039cd16f*/
  }
  else
  {
    if ( (_BYTE)`guard variable for'RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7045 == 0
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7045) != 0 )
    {
      v24[0] = " }\n        ,\n        {\n            \"semantic\": [ \"color\", \"normal\", \"specular\" ],\n            \"clientCompressionCaps\": [ \"dxt\" ],\n            \"mipPack\": [ \"legacy\" ]\n        }\n        ,\n        {\n            \"semantic\": [ \"color\", \"normal\", \"specular\" ],\n            \"clientCompressionCaps\": [ \"etc2\" ],\n            \"mipPack\": [ \"legacy\" ]\n        }\n        ,\n        {\n            \"semantic\": [ \"color\", \"normal\", \"specular\" ],\n            \"clientCompressionCaps\": [ \"dxt\" ],\n            \"mipPack\": [ \"pack0\", \"pack1\", \"pack2\", \"pack3\", \"pack4\", \"pack5\", \"pack6\", \"pack7\" ]\n        }\n        ,\n        {\n            \"semantic\": [ \"color\", \"normal\", \"specular\" ],\n            \"clientCompressionCaps\": [ \"etc2\" ],\n            \"mipPack\": [ \"pack0\", \"pack1\", \"pack2\", \"pack3\", \"pack4\", \"pack5\", \"pack6\", \"pack7\" ]\n        }\n        ,\n        {\n            \"semantic\": [ \"color\", \"normal\", \"specular\" ],\n            \"clientCompressionCaps\": [ \"uncompressed\" ],\n            \"mipPack\": [ \"all\" ]\n        }\n        ,\n        {\n            \"semantic\": [ \"color\", \"normal\", \"specular\" ],\n            \"clientCompressionCaps\": [ \"uncompressed\" ],\n            \"mipPack\": [ \"legacy\" ]\n        }\n        ,\n        {\n            \"semantic\": [ \"color\", \"normal\", \"specular\" ],\n            \"clientCompressionCaps\": [ \"uncompressed\" ],\n            \"mipPack\": [ \"pack0\", \"pack1\", \"pack2\", \"pack3\", \"pack4\", \"pack5\", \"pack6\", \"pack7\" ]\n        }\n    ]\n    ";
      RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7045 = RBX::Profiler::getToken(this: (RBX::Profiler *)&aUnableToConver_11[-178065], a2: &aSemanticColorN[-357777], a3: (const char *)0xFFFFFFFFLL, a4: 255, a5: v22); /*0x1039cd4b5*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7045); /*0x1039cd4c3*/
    }
    v7 = RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7045; /*0x1039cd186*/
    *(_OWORD *)v24 = 0; /*0x1039cd197*/
    v24[3] = -1; /*0x1039cd19c*/
    memset(&v24[4], 0, 52); /*0x1039cd1a5*/
    *(_OWORD *)&v24[11] = 0; /*0x1039cd1c0*/
    v24[2] = RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7045; /*0x1039cd1c6*/
    RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v24); /*0x1039cd1ce*/
    v24[3] = RBX::Profiler::enterRegion(a1: v7, a2: -1, a3: 0); /*0x1039cd1e4*/
    v5 = v28; /*0x1039cd1e9*/
    v27 = RakNet::RakPeer::ProcessBufferedPackets(this, a2: a4, a3: v28); /*0x1039cd1fb*/
    RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v24); /*0x1039cd206*/
  }
  RakNet::RakPeer::ProcessBufferedCommands(this, a2: &v28, a3: v29); /*0x1039cd216*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1160)); /*0x1039cd225*/
  v8 = *((_DWORD *)this + 286); /*0x1039cd22a*/
  v9 = *((_DWORD *)this + 287); /*0x1039cd231*/
  RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 1160)); /*0x1039cd23b*/
  if ( v8 != v9 ) /*0x1039cd243*/
    RakNet::RakPeer::HandleRequestedConnectionQueue(this, a2: v10, a3: v29); /*0x1039cd24c*/
  v26 = RakNet::RakPeer::ProcessArtificialLatencyTransmitPackets(this, a2: v5); /*0x1039cd25c*/
  v11 = v25; /*0x1039cd26a*/
  if ( FFlag::DebugClientDumpMicroprofileForJoins == 1 ) /*0x1039cd26e*/
  {
    RakNet::RakPeer::HandleActiveSystemList(this, a2: v25, a3: &v28, a4: v29); /*0x1039cd27e*/
  }
  else
  {
    if ( (_BYTE)`guard variable for'RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7072 == 0 /*0x1039cd4db*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7072) != 0 )
    {
      v24[0] = "nitial_scale_factor value, ignored."; /*0x1039cd504*/
      RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7072 = RBX::Profiler::getToken(this: (RBX::Profiler *)&aFailedToRegist_4[-77233], a2: &aUnsupportedIni[-172103], a3: (const char *)0xFFFFFFFFLL, a4: 255, a5: v23); /*0x1039cd528*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7072); /*0x1039cd536*/
    }
    v12 = RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7072; /*0x1039cd296*/
    *(_OWORD *)v24 = 0; /*0x1039cd2a7*/
    v24[3] = -1; /*0x1039cd2ab*/
    memset(&v24[4], 0, 52); /*0x1039cd2b3*/
    *(_OWORD *)&v24[11] = 0; /*0x1039cd2ca*/
    v24[2] = RakNet::RakPeer::RunUpdateCycle(unsigned long long,unsigned long long,RakNet::BitStream &)::proftoken7072; /*0x1039cd2cf*/
    RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v24); /*0x1039cd2d6*/
    v24[3] = RBX::Profiler::enterRegion(a1: v12, a2: -1, a3: 0); /*0x1039cd2ec*/
    RakNet::RakPeer::HandleActiveSystemList(this, a2: v11, a3: &v28, a4: v29); /*0x1039cd2fe*/
    RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v24); /*0x1039cd30a*/
  }
  if ( DFFlag::DebugNetworkProfiler == 1 && DFFlag::DebugNetworkProfilerRakPeer == 1 ) /*0x1039cd329*/
  {
    v13 = "C:RakPeerSend"; /*0x1039cd332*/
    if ( *((_BYTE *)this + 3728) != 0 ) /*0x1039cd340*/
      v13 = "S:RakPeerSend"; /*0x1039cd340*/
    v14 = *((_DWORD *)this + 194); /*0x1039cd344*/
    if ( *((_QWORD *)this + 96) != 0 ) /*0x1039cd353*/
    {
      v15 = 0; /*0x1039cd355*/
      v16 = 0; /*0x1039cd358*/
      do /*0x1039cd3a5*/
      {
        if ( (unsigned __int8)RBX::NetworkProfiler::CapturePackets::hasData(this: (RBX::NetworkProfiler::CapturePackets *)(v15 + *((_QWORD *)this + 95))) != 0 ) /*0x1039cd36c*/
          RBX::NetworkProfiler::CapturePackets::flush( /*0x1039cd38f*/
            this: (RBX::NetworkProfiler::CapturePackets *)(*((_QWORD *)this + 95) + v15),
            a2: v13,
            a3: *(_DWORD *)(*((_QWORD *)this + 95) + v15 + 4164),
            a4: v14,
            a5: *(_DWORD *)(*((_QWORD *)this + 95) + v15 + 4160));
        ++v16; /*0x1039cd394*/
        v15 += 4176; /*0x1039cd397*/
      }
      while ( v16 < *((_QWORD *)this + 96) ); /*0x1039cd3a5*/
    }
  }
  if ( (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 912LL))(a1: this) != 0 /*0x1039cd3c7*/
    || (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 904LL))(a1: this) != 0 )
  {
    RakNet::RakPeer::ReportRakNetLatencyMeasurementStats(this, a2: v29[0], a3: v17, a4: v18); /*0x1039cd3d0*/
  }
  v20 = v27; /*0x1039cd3df*/
  if ( DFInt::CLI56775MS != 0 && v29[0] - *((unsigned int *)this + 39) >= DFInt::CLI56775MS ) /*0x1039cd3f8*/
  {
    *((_DWORD *)this + 39) = v29[0]; /*0x1039cd401*/
    if ( (unsigned int)RBX::globalRand(this: v19) % 0x2710 < DFInt::CLI56775_HundredthsPercentage ) /*0x1039cd429*/
      RakNet::RakPeer::reportQueuedByteStats(this); /*0x1039cd42e*/
    *(_OWORD *)((char *)this + 140) = 0; /*0x1039cd436*/
  }
  if ( v26 < v20 ) /*0x1039cd441*/
    return v26; /*0x1039cd441*/
  return v20; /*0x1039cd448*/
}

// Address: 0x1039cd576 | Name: __ZN6RakNet7RakPeer21reportQueuedByteStatsEv
__int64 __fastcall RakNet::RakPeer::reportQueuedByteStats(RakNet::RakPeer *this)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  _BYTE v5[16]; // [rsp+0h] [rbp-200h] BYREF
  void *v6; // [rsp+10h] [rbp-1F0h]
  void *v7[59]; // [rsp+18h] [rbp-1E8h] BYREF

  RBX::Analytics::InfluxDb::Points::Points(a1: v7, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1039cd5a3*/
  if ( DFFlag::CLI56775 == 1 ) /*0x1039cd5af*/
  {
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039cd5c5*/
      this: (RBX::Analytics::InfluxDb::Points *)v7,
      a2: "MaxBytesReturnQueue",
      a3: *((_DWORD *)this + 35));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039cd5de*/
      this: (RBX::Analytics::InfluxDb::Points *)v7,
      a2: "PeersExceededReturnQueue",
      a3: *((_DWORD *)this + 36));
  }
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039cd5f7*/
    this: (RBX::Analytics::InfluxDb::Points *)v7,
    a2: "MaxBytesIncompleteDatagrams",
    a3: *((_DWORD *)this + 37));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039cd610*/
    this: (RBX::Analytics::InfluxDb::Points *)v7,
    a2: "PeersExceededIncompleteDatagrams",
    a3: *((_DWORD *)this + 38));
  if ( RBX::Analytics::InfluxDb::Points::size(this: (RBX::Analytics::InfluxDb::Points *)v7) != 0 ) /*0x1039cd624*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v5, a2: "RakNetRxBytesInQueueStats", a3: v2, a4: v3); /*0x1039cd634*/
    RBX::Analytics::InfluxDb::Points::report(a1: v7, a2: v5, a3: 10000, a4: 0); /*0x1039cd64e*/
    if ( (v5[0] & 1) != 0 ) /*0x1039cd65a*/
      operator delete(a1: v6); /*0x1039cd663*/
  }
  RBX::Analytics::InfluxDb::Points::~Points(this: v7); /*0x1039cd66f*/
  return __stack_chk_guard; /*0x1039cd684*/
}

// Address: 0x1039cd6de | Name: __ZN6RakNet7RakPeer29findRequestedConnectionStructERKNS_13SystemAddressE
__int64 __fastcall RakNet::RakPeer::findRequestedConnectionStruct(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *a2)
{
  RakNet::SimpleMutex *v4; // rbx
  unsigned __int64 v5; // r13
  unsigned int v6; // eax
  unsigned int v7; // ecx
  unsigned int v8; // ecx
  int v9; // ecx
  __int64 v10; // r12

  v4 = (RakNet::RakPeer *)((char *)this + 1160); /*0x1039cd6f2*/
  RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 1160)); /*0x1039cd6fc*/
  v5 = 0; /*0x1039cd701*/
  while ( 1 )
  {
    v6 = *((_DWORD *)this + 286); /*0x1039cd704*/
    v7 = *((_DWORD *)this + 287); /*0x1039cd70b*/
    v8 = v7 >= v6 ? v7 - v6 : *((_DWORD *)this + 288) + v7 - v6;
    if ( v5 >= v8 ) /*0x1039cd728*/
      break; /*0x1039cd728*/
    v9 = 0; /*0x1039cd735*/
    if ( v6 + (unsigned int)v5 >= *((_DWORD *)this + 288) ) /*0x1039cd739*/
      v9 = *((_DWORD *)this + 288); /*0x1039cd73b*/
    v10 = *(_QWORD *)(*((_QWORD *)this + 142) + 8LL * ((unsigned int)v5++ + v6 - v9)); /*0x1039cd749*/
    if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: v10, a2) != 0 ) /*0x1039cd75d*/
      goto LABEL_11; /*0x1039cd75d*/
  }
  v10 = 0; /*0x1039cd761*/
LABEL_11:
  RakNet::SimpleMutex::Unlock(this: v4); /*0x1039cd764*/
  return v10; /*0x1039cd773*/
}

// Address: 0x1039cd77e | Name: __ZNK6RakNet7RakPeer10isValidMtuEm
bool __fastcall RakNet::RakPeer::isValidMtu(RakNet::RakPeer *this, unsigned __int64 a2)
{
  return a2 >= 0x240; /*0x1039cd78c*/
}

// Address: 0x1039cd78e | Name: __ZN6RakNet7RakPeer24generateUdmuxTtDbgStringEPKNS_13SystemAddressE
RakNet::RakPeer *__fastcall RakNet::RakPeer::generateUdmuxTtDbgString(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *a2,
        RakNet::SystemAddress *a3)
{
  unsigned int Port; // eax
  __int64 v7; // r8
  __int64 v8; // r9
  __int64 v9; // rcx
  __int128 v10; // xmm0
  unsigned int v11; // ebx
  char *v12; // r13
  __int16 v13; // ax
  __int64 v14; // rsi
  __int128 v16; // [rsp+20h] [rbp-A0h] BYREF
  __int128 v17; // [rsp+30h] [rbp-90h]
  RakNet::RakPeer *v18; // [rsp+48h] [rbp-78h]
  char v19[64]; // [rsp+50h] [rbp-70h] BYREF

  Port = RakNet::SystemAddress::GetPort(this: (const RakNet::SystemAddress *)((char *)a2 + 100)); /*0x1039cd7bd*/
  v9 = Port; /*0x1039cd7c2*/
  if ( a3 != nullptr ) /*0x1039cd7c7*/
  {
    v10 = *(_OWORD *)a3; /*0x1039cd7c9*/
    v17 = *((_OWORD *)a3 + 1); /*0x1039cd7db*/
    v16 = v10; /*0x1039cd7e0*/
    v18 = this; /*0x1039cd7e7*/
    v11 = Port; /*0x1039cd7eb*/
    RakNet::SystemAddress::ConvertToIpV6(this: (RakNet::SystemAddress *)&v16); /*0x1039cd7ed*/
    v12 = v19; /*0x1039cd7f2*/
    RakNet::SystemAddress::ToStringN(this: (RakNet::SystemAddress *)&v16, a2: false, a3: v19, a4: 64, a5: 124); /*0x1039cd809*/
    v13 = RakNet::SystemAddress::GetPort(this: a3); /*0x1039cd811*/
    v9 = v11; /*0x1039cd816*/
    this = v18; /*0x1039cd818*/
  }
  else
  {
    v13 = 0; /*0x1039cd81e*/
    v12 = nullptr; /*0x1039cd820*/
  }
  v14 = *((_QWORD *)a2 + 414); /*0x1039cd823*/
  if ( v14 != 0 ) /*0x1039cd82d*/
  {
    WORD4(v16) = v9; /*0x1039cd83a*/
    WORD4(v17) = v13; /*0x1039cd848*/
    RBX::Rupp::RuppTokenProcessor::generateTtDbgString( /*0x1039cd86b*/
      a1: this,
      a2: v14,
      a3: 0,
      a4: v9,
      a5: v7,
      a6: v8,
      a7: (char *)a2 + 36,
      a8: *((_QWORD *)&v16 + 1),
      a9: v12,
      a10: *((_QWORD *)&v17 + 1),
      a11: (char *)a2 + 36,
      a12: *((_QWORD *)&v16 + 1),
      a13: v12,
      a14: *((_QWORD *)&v17 + 1));
  }
  else
  {
    *(_OWORD *)this = 0; /*0x1039cd875*/
    *((_QWORD *)this + 2) = 0; /*0x1039cd878*/
  }
  return this; /*0x1039cd893*/
}

// Address: 0x1039cd8aa | Name: __ZN6RakNet7RakPeer18getUdmuxTDbgStringERKNS_13SystemAddressE
RakNet::RakPeer *__fastcall RakNet::RakPeer::getUdmuxTDbgString(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *a2,
        _OWORD *a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  __int64 v8; // rdx
  __int64 v9; // rcx
  const char *v10; // r12
  unsigned __int16 Port; // ax

  if ( RakNet::RakPeer::GetRemoteSystemFromSystemAddress(a1: (__int64)a2, a2: 0, a3: 1u, a4: -1, a5, a6, a7: *a3) != 0 ) /*0x1039cd8f8*/
  {
    v10 = *((const char **)a2 + 414); /*0x1039cd8fd*/
    Port = RakNet::SystemAddress::GetPort(this: (const RakNet::SystemAddress *)((char *)a2 + 100)); /*0x1039cd90f*/
    RBX::Rupp::RuppTokenProcessor::getUdmuxTDbgString( /*0x1039cd92a*/
      this,
      a2: v10,
      a3: (_WORD)a2 + 36,
      a4: (const unsigned __int8 *)Port);
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: this, a2: "", a3: v8, a4: v9); /*0x1039cd93b*/
  }
  return this; /*0x1039cd943*/
}

// Address: 0x1039cd952 | Name: __ZN6RakNet7RakPeer18generateUdmuxTokenEPhPKNS_13SystemAddressEjN3RBX8Security24RakPeerTokenLineageFlagsE
__int64 __fastcall RakNet::RakPeer::generateUdmuxToken(
        __int64 a1,
        __int64 a2,
        RakNet::SystemAddress *a3,
        unsigned int a4,
        unsigned __int8 a5)
{
  RBX::Rupp::RuppTokenProcessor *v6; // rdi
  int AltTokenPreferred; // eax
  __int64 v9; // r8
  __int64 v10; // r9
  __int16 Port; // r12
  __int128 v12; // xmm0
  char *v13; // rbx
  __int16 v14; // ax
  __int64 v15; // rdi
  unsigned int v16; // ebx
  __int64 v17; // rdi
  unsigned int v19; // [rsp+24h] [rbp-ACh] BYREF
  __int64 v20; // [rsp+28h] [rbp-A8h]
  __int128 v21; // [rsp+30h] [rbp-A0h] BYREF
  __int128 v22; // [rsp+40h] [rbp-90h]
  unsigned int v23; // [rsp+58h] [rbp-78h]
  int v24; // [rsp+5Ch] [rbp-74h]
  char v25[64]; // [rsp+60h] [rbp-70h] BYREF

  v6 = *(RBX::Rupp::RuppTokenProcessor **)(a1 + 3312); /*0x1039cd977*/
  if ( v6 == nullptr ) /*0x1039cd981*/
    return __stack_chk_guard; /*0x1039cd981*/
  v23 = a4; /*0x1039cd98a*/
  AltTokenPreferred = a5; /*0x1039cd98d*/
  v20 = a2; /*0x1039cd997*/
  if ( (unsigned int)a5 - 9 >= 2 ) /*0x1039cd99e*/
  {
    if ( a5 != 6 ) /*0x1039cd9aa*/
    {
      v24 = 0; /*0x1039cd9b3*/
      goto LABEL_8; /*0x1039cd9b3*/
    }
    LOBYTE(AltTokenPreferred) = 1; /*0x1039cd9ac*/
  }
  else
  {
    AltTokenPreferred = RBX::Rupp::RuppTokenProcessor::getAltTokenPreferred(this: v6); /*0x1039cd9a0*/
  }
  v24 = AltTokenPreferred; /*0x1039cd9ae*/
LABEL_8:
  Port = RakNet::SystemAddress::GetPort(this: (RakNet::SystemAddress *)(a1 + 100)); /*0x1039cd9ba*/
  if ( a3 != nullptr ) /*0x1039cd9c9*/
  {
    v12 = *(_OWORD *)a3; /*0x1039cd9cb*/
    v22 = *((_OWORD *)a3 + 1); /*0x1039cd9dc*/
    v21 = v12; /*0x1039cd9e1*/
    RakNet::SystemAddress::ConvertToIpV6(this: (RakNet::SystemAddress *)&v21); /*0x1039cd9e8*/
    v13 = v25; /*0x1039cd9ed*/
    RakNet::SystemAddress::ToStringN(this: (RakNet::SystemAddress *)&v21, a2: false, a3: v25, a4: 64, a5: 124); /*0x1039cda04*/
    v14 = RakNet::SystemAddress::GetPort(this: a3); /*0x1039cda0c*/
  }
  else
  {
    v14 = 0; /*0x1039cda13*/
    v13 = nullptr; /*0x1039cda15*/
  }
  if ( DFFlag::RuppTokenAlgoTelemetry == 1 ) /*0x1039cda2c*/
  {
    v19 = 0; /*0x1039cda35*/
    v15 = *(_QWORD *)(a1 + 3312); /*0x1039cda3c*/
    *(_QWORD *)&v21 = a1 + 36; /*0x1039cda43*/
    WORD4(v21) = Port; /*0x1039cda4a*/
    *(_QWORD *)&v22 = v13; /*0x1039cda52*/
    WORD4(v22) = v14; /*0x1039cda59*/
    v16 = (unsigned __int8)v24; /*0x1039cda7a*/
    (*(void (__fastcall **)(__int64, __int64, _QWORD, _QWORD, unsigned int *, __int64, __int64, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v15 + 40LL))( /*0x1039cda86*/
      a1: v15,
      a2: v20,
      a3: v23,
      a4: (unsigned __int8)v24,
      a5: &v19,
      a6: v10,
      a7: a1 + 36,
      a8: *((_QWORD *)&v21 + 1),
      a9: v22,
      a10: *((_QWORD *)&v22 + 1));
    RBX::Rupp::reportRuppTokenAlgo(a1: 1, a2: v19, a3: v16, a4: 1, a5: 0); /*0x1039cda9b*/
  }
  else
  {
    v17 = *(_QWORD *)(a1 + 3312); /*0x1039cdaa2*/
    *(_QWORD *)&v21 = a1 + 36; /*0x1039cdaa9*/
    WORD4(v21) = Port; /*0x1039cdab0*/
    *(_QWORD *)&v22 = v13; /*0x1039cdab8*/
    WORD4(v22) = v14; /*0x1039cdabf*/
    (*(void (__fastcall **)(__int64, __int64, _QWORD, _QWORD, __int64, __int64, __int64, _QWORD, char *, _QWORD))(*(_QWORD *)v17 + 32LL))( /*0x1039cdae7*/
      a1: v17,
      a2: v20,
      a3: v23,
      a4: (unsigned __int8)v24,
      a5: v9,
      a6: v10,
      a7: a1 + 36,
      a8: *((_QWORD *)&v21 + 1),
      a9: v13,
      a10: *((_QWORD *)&v22 + 1));
  }
  return __stack_chk_guard; /*0x1039cdafa*/
}

// Address: 0x1039cdb12 | Name: __ZN6RakNet7RakPeer16sendRbxOpenErrorEhRKNS_10RakNetGUIDERKNS_13SystemAddressERNSt3__110shared_ptrINS_12RakNetSocketEEEyb
__int64 __fastcall RakNet::RakPeer::sendRbxOpenError(
        RakNet::RakPeer *this,
        unsigned __int8 a2,
        unsigned __int8 *a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  unsigned int v12; // ecx
  __int64 v13; // rax
  int v14; // r14d
  std::__shared_weak_count *v15; // r15
  RakNet::BitStream *v17; // rdi
  std::__shared_weak_count *v18[2]; // [rsp+30h] [rbp-190h] BYREF
  unsigned __int8 v19; // [rsp+47h] [rbp-179h] BYREF
  unsigned __int8 v20[32]; // [rsp+48h] [rbp-178h] BYREF
  _BYTE v21[12]; // [rsp+68h] [rbp-158h] BYREF
  int v22; // [rsp+74h] [rbp-14Ch]
  __int64 v23; // [rsp+80h] [rbp-140h]

  v19 = a2; /*0x1039cdb43*/
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v21, a2: 0xC8u); /*0x1039cdb56*/
  if ( a7 != 0 ) /*0x1039cdb5f*/
    RakNet::RakPeer::startOfflineBitStream(this, a2: (RakNet::BitStream *)v21, a3: nullptr, a4: a6); /*0x1039cdb70*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v21, a2: &v19, a3: 8u, a4: true); /*0x1039cdb8d*/
  RakNet::BitStream::WriteAlignedBytes(this: (RakNet::BitStream *)v21, a2: &OFFLINE_MESSAGE_DATA_ID, a3: 0x10u); /*0x1039cdba5*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039cdd17*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v17); /*0x1039cdd22*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cdd2f*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039cdbbf*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v21, a2: a3, a3: 0x40u, a4: true); /*0x1039cdbd5*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)a3, a2: v20, a3: (unsigned __int8 *)8, a4: v12); /*0x1039cdbeb*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v21, a2: v20, a3: 0x40u, a4: true); /*0x1039cdc08*/
  }
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v20, a2: nullptr); /*0x1039cdc16*/
  v13 = *(_QWORD *)(a5 + 8); /*0x1039cdc1b*/
  *(_OWORD *)v18 = *(_OWORD *)a5; /*0x1039cdc23*/
  if ( v13 != 0 ) /*0x1039cdc2d*/
    _InterlockedIncrement64((volatile signed __int64 *)(v13 + 8)); /*0x1039cdc2f*/
  v14 = RakNet::SocketLayer::SendToOrDelay( /*0x1039cdc81*/
          a1: v18,
          a2: v23,
          a3: (unsigned int)(v22 + 7) >> 3,
          a4,
          a5: v20,
          a6: 0,
          a7: this,
          a8: 0,
          a9: 0,
          a10: "",
          a11: 0);
  v15 = v18[1]; /*0x1039cdc84*/
  if ( v18[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v18[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039cdca0*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x1039cdca8*/
    std::__shared_weak_count::__release_weak(this: v15); /*0x1039cdcae*/
  }
  if ( v14 != -3 ) /*0x1039cdcb7*/
  {
    ++*((_QWORD *)this + 454); /*0x1039cdcb9*/
    if ( v14 != 0 ) /*0x1039cdcc3*/
    {
      if ( v14 == -4 ) /*0x1039cdcc9*/
        ++*((_QWORD *)this + 455); /*0x1039cdccb*/
      else
        ++*((_QWORD *)this + 456); /*0x1039cdcd4*/
    }
  }
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v21); /*0x1039cdce2*/
  return __stack_chk_guard; /*0x1039cdcf7*/
}

// Address: 0x1039cdd7e | Name: __ZN6RakNet7RakPeer17sendRbxOpenReply1EmRKNS_13SystemAddressES3_RNSt3__110shared_ptrINS_12RakNetSocketEEEybRKN3RBX4Rupp21DeserializationResultE
__int64 __fastcall RakNet::RakPeer::sendRbxOpenReply1(
        RakNet::RakPeer *this,
        __int16 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7,
        __int64 a8)
{
  __int64 v12; // rdx
  char v13; // r15
  __int64 v14; // rdi
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rsi
  __int64 v18; // r8
  __int64 v19; // r9
  unsigned int v20; // ecx
  unsigned __int8 *v21; // r14
  unsigned int v22; // ecx
  __int64 v23; // rax
  int v24; // r14d
  std::__shared_weak_count *v25; // r15
  RakNet::BitStream *v27; // rdi
  RakNet::BitStream *v28; // rdi
  unsigned __int8 v31[16]; // [rsp+40h] [rbp-1A0h] BYREF
  std::__shared_weak_count *v32[2]; // [rsp+50h] [rbp-190h] BYREF
  unsigned __int8 v33[16]; // [rsp+60h] [rbp-180h] BYREF
  __int128 v34; // [rsp+70h] [rbp-170h]
  _BYTE v35[12]; // [rsp+88h] [rbp-158h] BYREF
  int v36; // [rsp+94h] [rbp-14Ch]
  __int64 v37; // [rsp+A0h] [rbp-140h]

  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v35, a2: 0x1Cu); /*0x1039cddc6*/
  if ( a7 != 0 ) /*0x1039cddcf*/
  {
    v13 = *(_BYTE *)(a8 + 3); /*0x1039cddd9*/
    v14 = DFLog::Rupp; /*0x1039cdddd*/
    if ( (unsigned __int8)DFLog::Rupp >= 6u && BYTE1(DFLog::Rupp) >= 5u ) /*0x1039cddf2*/
    {
      *(_QWORD *)v33 = 0; /*0x1039cde00*/
      *(_QWORD *)&v33[8] = v31; /*0x1039cde12*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x1039cde3c*/
        a1: DFLog::Rupp,
        a2: qword_10D7BB258,
        a3: 5,
        a4: (unsigned int)"[DFLog::Rupp] Client opted in to receiving Rupp headers. Sending reply with Rupp header.",
        a5: 88,
        a6: 1,
        0,
        v31);
    }
    if ( (v13 & 1) != 0 ) /*0x1039cde49*/
      RakNet::RakPeer::startOfflineBitStreamReverse(a1: v14, a2: v35, a3: v12, a4: a6); /*0x1039cde9f*/
    else
      RakNet::RakPeer::startOfflineBitStream(this, a2: (RakNet::BitStream *)v35, a3: nullptr, a4: a6); /*0x1039cde5a*/
  }
  else if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && BYTE1(DFLog::RuppTokenLog) >= 3u ) /*0x1039cde7a*/
  {
    FLog::FastLog( /*0x1039cde8e*/
      a1: *(_QWORD *)&DFLog::RuppTokenLog,
      a2: qword_10D7B48E0,
      a3: "[DFLog::RuppTokenLog] Client did not opt in to receiving Rupp headers. Omitting Rupp header.",
      0);
  }
  v33[0] = 126; /*0x1039cdeab*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v35, a2: v33, a3: 8u, a4: true); /*0x1039cdebf*/
  RakNet::BitStream::WriteAlignedBytes(this: (RakNet::BitStream *)v35, a2: &OFFLINE_MESSAGE_DATA_ID, a3: 0x10u); /*0x1039cded7*/
  v34 = *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1); /*0x1039cdee3*/
  *(_OWORD *)v33 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039cdef1*/
  v21 = (unsigned __int8 *)(*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)this + 424LL))( /*0x1039cdf1e*/
                             a1: this,
                             a2: v17,
                             a3: v15,
                             a4: v16,
                             a5: v18,
                             a6: v19,
                             a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
                             a8: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
                             a9: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
                             a10: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3));
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039ce13c*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v27); /*0x1039ce147*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039ce154*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039cdf36*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v35, a2: v21, a3: 0x40u, a4: true); /*0x1039cdf4c*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v21, a2: v33, a3: (unsigned __int8 *)8, a4: v20); /*0x1039cdf62*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v35, a2: v33, a3: 0x40u, a4: true); /*0x1039cdf7f*/
  }
  v33[0] = 0; /*0x1039cdf8b*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v35, a2: v33, a3: 8u, a4: true); /*0x1039cdf9f*/
  *(_WORD *)v31 = a2 + 40; /*0x1039cdfa8*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039ce16c*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v28); /*0x1039ce177*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039ce184*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039cdfc5*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v35, a2: v31, a3: 0x10u, a4: true); /*0x1039cdfdf*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v31, a2: v33, a3: (unsigned __int8 *)2, a4: v22); /*0x1039cdff9*/
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v35, a2: v33, a3: 0x10u, a4: true); /*0x1039ce016*/
  }
  v23 = *(_QWORD *)(a5 + 8); /*0x1039ce01b*/
  *(_OWORD *)v32 = *(_OWORD *)a5; /*0x1039ce025*/
  if ( v23 != 0 ) /*0x1039ce02f*/
    _InterlockedIncrement64((volatile signed __int64 *)(v23 + 8)); /*0x1039ce031*/
  v24 = RakNet::SocketLayer::SendToOrDelay( /*0x1039ce087*/
          a1: v32,
          a2: v37,
          a3: (unsigned int)(v36 + 7) >> 3,
          a4: a3,
          a5: a4,
          a6: 0,
          a7: this,
          a8: 0,
          a9: 0,
          a10: "",
          a11: 0);
  v25 = v32[1]; /*0x1039ce08a*/
  if ( v32[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v32[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039ce0a6*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v25 + 16LL))(a1: v25); /*0x1039ce0ae*/
    std::__shared_weak_count::__release_weak(this: v25); /*0x1039ce0b4*/
  }
  if ( v24 == -3 || (++*((_QWORD *)this + 454), v24 == 0) ) /*0x1039ce0c9*/
  {
    RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 3232)); /*0x1039ce0e4*/
    ++*((_DWORD *)this + 802); /*0x1039ce0e9*/
    RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 3232)); /*0x1039ce0f2*/
  }
  else if ( v24 == -4 ) /*0x1039ce0cf*/
  {
    ++*((_QWORD *)this + 455); /*0x1039ce0d1*/
  }
  else
  {
    ++*((_QWORD *)this + 456); /*0x1039ce0f9*/
  }
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v35); /*0x1039ce107*/
  return __stack_chk_guard; /*0x1039ce11c*/
}

// Address: 0x1039ce1dc | Name: __ZNK6RakNet7RakPeer28startOfflineBitStreamReverseERNS_9BitStreamEPKNS0_18RemoteSystemStructEyRKN3RBX4Rupp21DeserializationResultE
__int64 __fastcall RakNet::RakPeer::startOfflineBitStreamReverse(
        __int64 a1,
        RakNet::BitStream *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5)
{
  __int64 HeaderTotalByteLength; // rbx
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  _BYTE v13[16]; // [rsp+10h] [rbp-130h] BYREF
  _QWORD v14[6]; // [rsp+20h] [rbp-120h] BYREF
  __int64 v15; // [rsp+50h] [rbp-F0h]
  _BYTE *v16; // [rsp+58h] [rbp-E8h]
  _BYTE v17[16]; // [rsp+60h] [rbp-E0h] BYREF
  char v18; // [rsp+70h] [rbp-D0h] BYREF
  char *v19; // [rsp+90h] [rbp-B0h]
  void *v20[6]; // [rsp+B8h] [rbp-88h] BYREF
  char v21; // [rsp+E8h] [rbp-58h] BYREF

  RakNet::BitStream::Reset(this: a2); /*0x1039ce20a*/
  RBX::Rupp::Rupp::Rupp(a1: v17, a2: 1, a3: 1); /*0x1039ce220*/
  RBX::Rupp::Rupp::addIpv4ReverseEndpointTlv( /*0x1039ce23a*/
    this: (RBX::Rupp::Rupp *)v17,
    a2: (const char *)(a5 + 24),
    a3: *(_WORD *)(a5 + 70));
  HeaderTotalByteLength = (unsigned __int16)RBX::Rupp::Rupp::getHeaderTotalByteLength(this: (RBX::Rupp::Rupp *)v17); /*0x1039ce255*/
  if ( ((unsigned int)RakNet::BitStream::GetNumberOfBitsAllocated(this: a2) + 7) >> 3 < (unsigned __int16)HeaderTotalByteLength ) /*0x1039ce260*/
    RakNet::BitStream::AddBitsAndReallocate(this: a2, a2: 8 * (unsigned __int16)HeaderTotalByteLength); /*0x1039ce26c*/
  if ( (unsigned __int8)DFLog::Rupp >= 6u && BYTE1(DFLog::Rupp) >= 6u )
  {
    v9 = *(unsigned __int16 *)(a5 + 70); /*0x1039ce294*/
    v14[0] = (unsigned __int16)HeaderTotalByteLength; /*0x1039ce2a1*/
    v14[2] = a5 + 24; /*0x1039ce2a4*/
    v14[4] = v9; /*0x1039ce2a8*/
    v15 = 708; /*0x1039ce2ac*/
    v16 = v14; /*0x1039ce2b7*/
    FLog::detail::FastLogSafeFormattedInternal(
      a1: DFLog::Rupp,
      a2: qword_10D7BB258,
      a3: 6,
      a4: (unsigned int)"[DFLog::Rupp] Offline reverse ruppLength: {}. Endpoint: {} | {}",
      a5: 63,
      a6: 1,
      708,
      v14);
  }
  v10 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1039ce2ec*/
  RBX::Rupp::Rupp::serialize(a1: v14, a2: v17, a3: v10, a4: (unsigned __int16)HeaderTotalByteLength, a5: a4); /*0x1039ce306*/
  if ( LODWORD(v14[0]) != 0 ) /*0x1039ce312*/
  {
    if ( (unsigned __int8)DFLog::Rupp >= 6u && BYTE1(DFLog::Rupp) >= 6u ) /*0x1039ce32d*/
    {
      v15 = 0; /*0x1039ce33b*/
      v16 = v13; /*0x1039ce34d*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x1039ce377*/
        a1: DFLog::Rupp,
        a2: qword_10D7BB258,
        a3: 6,
        a4: (unsigned int)"[DFLog::Rupp] startOfflineBitStreamReverse serialization failed.",
        a5: 64,
        a6: 1,
        0,
        v13);
    }
    HeaderTotalByteLength = 0; /*0x1039ce388*/
    if ( DFFlag::RakNetRuppTelemetryReportNetworkStack == 1 ) /*0x1039ce386*/
      RBX::Rupp::reportRuppSerializationFailure(a1: v17, a2: v14, a3: 0, a4: 0, a5: 0, a6: 0); /*0x1039ce3a2*/
    else
      RBX::Rupp::reportRuppSerializationFailure_deprecated(a1: v17, a2: v14, a3: 0, a4: 0, a5: 0); /*0x1039ce3d1*/
  }
  else
  {
    RakNet::BitStream::SetWriteOffset(this: a2, a2: 8 * (unsigned __int16)HeaderTotalByteLength, a3: false); /*0x1039ce3b3*/
  }
  if ( v20[3] != &v21 ) /*0x1039ce3e1*/
    operator delete(a1: v20[3]); /*0x1039ce3e3*/
  v14[0] = v20; /*0x1039ce3f6*/
  std::vector<std::unique_ptr<RBX::Rupp::TypeLengthValue>>::__destroy_vector::operator()[abi:ne200100](); /*0x1039ce3f9*/
  if ( v19 == &v18 ) /*0x1039ce40c*/
  {
    v11 = 32; /*0x1039ce41a*/
  }
  else
  {
    v11 = 40; /*0x1039ce40e*/
    if ( v19 == nullptr ) /*0x1039ce416*/
      return HeaderTotalByteLength; /*0x1039ce416*/
  }
  (*(void (**)(void))(*(_QWORD *)v19 + v11))(); /*0x1039ce422*/
  return HeaderTotalByteLength; /*0x1039ce438*/
}

// Address: 0x1039ce472 | Name: __ZN6RakNet7RakPeer19sendRbxOpenRequest2EmPNS0_25RequestedConnectionStructERKNS_13SystemAddressERNSt3__110shared_ptrINS_12RakNetSocketEEEy
__int64 __fastcall RakNet::RakPeer::sendRbxOpenRequest2(
        RakNet::RakPeer *this,
        int a2,
        __int128 *a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  RBX::Security::RakPeerCrypto *v10; // r13
  const unsigned __int8 *PublicKey; // r12
  __int64 v12; // rdx
  unsigned int v13; // r12d
  unsigned __int8 v14; // al
  unsigned int v15; // ecx
  unsigned int v16; // ecx
  unsigned int v17; // ecx
  int v18; // eax
  unsigned int v19; // edx
  const unsigned __int8 *v20; // r12
  __int64 v21; // rsi
  _BYTE *v22; // rcx
  unsigned __int8 v23; // al
  unsigned __int8 *v24; // rsi
  unsigned int v25; // edx
  const unsigned __int8 *v26; // rsi
  __int64 v27; // rdx
  __int64 v28; // rdx
  __int64 v29; // rcx
  __int64 v30; // rsi
  __int64 v31; // r8
  __int64 v32; // r9
  unsigned int v33; // ecx
  unsigned __int8 *v34; // r12
  unsigned int v35; // ecx
  __int128 v36; // xmm0
  __int64 v37; // rcx
  unsigned __int8 v38; // al
  unsigned __int8 v39; // al
  __int64 v40; // rsi
  unsigned int v41; // edx
  const unsigned __int8 *v42; // rsi
  __int64 v43; // rdx
  unsigned int v44; // r12d
  unsigned int v45; // ecx
  __int64 v46; // rdx
  __int64 v47; // rcx
  __int64 v48; // rax
  int v49; // r14d
  std::__shared_weak_count *v50; // r15
  RakNet::BitStream *v52; // rdi
  RakNet::BitStream *v53; // rdi
  RakNet::BitStream *v54; // rdi
  RakNet::BitStream *v55; // rdi
  RakNet::BitStream *v56; // rdi
  RakNet::BitStream *v57; // rdi
  _BYTE v58[16]; // [rsp+28h] [rbp-1E8h] BYREF
  unsigned __int64 v59; // [rsp+38h] [rbp-1D8h]
  std::__shared_weak_count *v60[2]; // [rsp+40h] [rbp-1D0h] BYREF
  unsigned __int8 v61[16]; // [rsp+50h] [rbp-1C0h] BYREF
  __int128 v62; // [rsp+60h] [rbp-1B0h]
  int v63; // [rsp+7Ch] [rbp-194h] BYREF
  __int64 started; // [rsp+80h] [rbp-190h]
  unsigned __int8 v65; // [rsp+8Bh] [rbp-185h] BYREF
  __int16 PortNetworkOrder; // [rsp+8Ch] [rbp-184h] BYREF
  unsigned __int8 v67[2]; // [rsp+8Eh] [rbp-182h] BYREF
  unsigned __int8 v68[2]; // [rsp+90h] [rbp-180h] BYREF
  unsigned __int8 v69; // [rsp+92h] [rbp-17Eh] BYREF
  unsigned __int8 v70; // [rsp+93h] [rbp-17Dh] BYREF
  unsigned __int8 v71[3]; // [rsp+94h] [rbp-17Ch] BYREF
  unsigned __int8 v72; // [rsp+97h] [rbp-179h] BYREF
  _BYTE v73[12]; // [rsp+98h] [rbp-178h] BYREF
  unsigned int v74; // [rsp+A4h] [rbp-16Ch]
  __int64 v75; // [rsp+B0h] [rbp-160h]
  unsigned __int8 v76[16]; // [rsp+1C0h] [rbp-50h] BYREF
  __int128 v77; // [rsp+1D0h] [rbp-40h]

  if ( *((_QWORD *)a3 + 45) != 0 ) /*0x1039ce49c*/
  {
    RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v73, a2: 8 * a2); /*0x1039ce4bc*/
    started = RakNet::RakPeer::startOfflineBitStream(this, a2: (RakNet::BitStream *)v73, a3: nullptr, a4: a6); /*0x1039ce4d5*/
    v69 = 3; /*0x1039ce4dc*/
    *(_WORD *)v67 = *((_WORD *)a3 + 188); /*0x1039ce4eb*/
    v72 = 0; /*0x1039ce4f2*/
    *(_WORD *)v71 = 0; /*0x1039ce4f9*/
    v10 = *((RBX::Security::RakPeerCrypto **)a3 + 45); /*0x1039ce502*/
    PublicKey = (const unsigned __int8 *)RBX::Security::RakPeerCrypto::getPublicKey(this: v10); /*0x1039ce511*/
    if ( PublicKey == nullptr || v12 == 0 ) /*0x1039ce51d*/
    {
      v13 = 0; /*0x1039ce53f*/
      if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039ce53c*/
        FLog::FastLog( /*0x1039ce55a*/
          a1: DFLog::SessionCrypto,
          a2: qword_10D7BB210,
          a3: "[DFLog::SessionCrypto] RbxOpenRequest2 no public key",
          0);
    }
    else
    {
      v14 = RBX::Security::SessionCrypto::getSupportAes(this: v10) + 1; /*0x1039ce5a9*/
      v70 = v14; /*0x1039ce5ab*/
      if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && (DFLog::SessionCrypto & 0xFC00) != 0 ) /*0x1039ce5c5*/
      {
        *(_QWORD *)v61 = v14; /*0x1039ce5dd*/
        *(_QWORD *)v76 = 2; /*0x1039ce5e0*/
        *(_QWORD *)&v76[8] = v61; /*0x1039ce5e8*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x1039ce60c*/
          a1: DFLog::SessionCrypto,
          a2: qword_10D7BB210,
          a3: 4,
          a4: (unsigned int)"[DFLog::SessionCrypto] RbxOpenRequest2 using encryption {}",
          a5: 58,
          a6: 1,
          2,
          v61);
      }
      *(_QWORD *)v76 = 0; /*0x1039ce615*/
      RakNet::buildCapabilitiesHelper(a1: v76, a2: 0); /*0x1039ce61e*/
      v59 = *(_QWORD *)v76; /*0x1039ce627*/
      RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)v58); /*0x1039ce635*/
      v76[0] = 120; /*0x1039ce63e*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v76, a3: 8u, a4: true); /*0x1039ce652*/
      RakNet::BitStream::WriteAlignedBytes(this: (RakNet::BitStream *)v73, a2: &OFFLINE_MESSAGE_DATA_ID, a3: 0x10u); /*0x1039ce66a*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: &v69, a3: 8u, a4: true); /*0x1039ce687*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: &v72, a3: 8u, a4: true); /*0x1039ce6a4*/
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039cee6f*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v52); /*0x1039cee7a*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cee87*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ce6be*/
      {
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v71, a3: 0x10u, a4: true); /*0x1039ce6d8*/
      }
      else
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v71, a2: v76, a3: (unsigned __int8 *)2, a4: v15); /*0x1039ce6f7*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v76, a3: 0x10u, a4: true); /*0x1039ce711*/
      }
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039cee9f*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v53); /*0x1039ceeaa*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039ceeb7*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ce72b*/
      {
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v67, a3: 0x10u, a4: true); /*0x1039ce745*/
      }
      else
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v67, a2: v76, a3: (unsigned __int8 *)2, a4: v16); /*0x1039ce75c*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v76, a3: 0x10u, a4: true); /*0x1039ce776*/
      }
      RakNet::BitStream::WriteAlignedBytes(this: (RakNet::BitStream *)v73, a2: PublicKey, a3: 0x20u); /*0x1039ce78a*/
      if ( FFlag::DebugLocalRccServerConnection == 1 && FFlag::DebugLocalRccTicketTesting == 1 ) /*0x1039ce79f*/
      {
        if ( (RBX::Http::gameID & 1) != 0 ) /*0x1039ce7af*/
          v18 = DWORD2(RBX::Http::gameID); /*0x1039ce7b1*/
        else
          v18 = (unsigned __int8)RBX::Http::gameID >> 1; /*0x1039ce7b8*/
        v76[0] = v18; /*0x1039ce7be*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v76, a3: 8u, a4: true); /*0x1039ce7d1*/
        if ( (RBX::Http::gameID & 1) != 0 ) /*0x1039ce7de*/
        {
          v19 = DWORD2(RBX::Http::gameID); /*0x1039ce7e0*/
          v20 = (const unsigned __int8 *)qword_10D783240; /*0x1039ce7e5*/
        }
        else
        {
          v19 = (unsigned __int8)RBX::Http::gameID >> 1; /*0x1039ce7ec*/
          v20 = (const unsigned __int8 *)&RBX::Http::gameID + 1; /*0x1039ce7ee*/
        }
        RakNet::BitStream::WriteAlignedBytes(this: (RakNet::BitStream *)v73, a2: v20, a3: v19); /*0x1039ce7fb*/
      }
      v21 = *((_QWORD *)this + 391); /*0x1039ce800*/
      if ( v21 != 0 ) /*0x1039ce80a*/
      {
        RakNet::BitStream::WriteBits( /*0x1039ce821*/
          this: (RakNet::BitStream *)v73,
          a2: (const unsigned __int8 *)(v21 + 48),
          a3: 8u,
          a4: true);
        v22 = *((_BYTE **)this + 391); /*0x1039ce826*/
        if ( (*v22 & 1) != 0 ) /*0x1039ce831*/
          v23 = v22[8]; /*0x1039ce876*/
        else
          v23 = *v22 >> 1; /*0x1039ce833*/
        v76[0] = v23; /*0x1039ce87d*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v76, a3: 8u, a4: true); /*0x1039ce890*/
        v24 = *((unsigned __int8 **)this + 391); /*0x1039ce895*/
        v25 = *v24; /*0x1039ce89c*/
        if ( (v25 & 1) != 0 ) /*0x1039ce8a2*/
        {
          v27 = *((_QWORD *)v24 + 1); /*0x1039ce8ab*/
          v26 = *((const unsigned __int8 **)v24 + 2); /*0x1039ce8af*/
        }
        else
        {
          v26 = v24 + 1; /*0x1039ce8a4*/
          LODWORD(v27) = v25 >> 1; /*0x1039ce8a7*/
        }
        RakNet::BitStream::WriteAlignedBytes(this: (RakNet::BitStream *)v73, a2: v26, a3: v27); /*0x1039ce8ba*/
      }
      else
      {
        *(_WORD *)v61 = 0; /*0x1039ce837*/
        if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039cef5f*/
          && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
        {
          RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v57); /*0x1039cef6a*/
          __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cef77*/
        }
        if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ce855*/
        {
          RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v61, a3: 0x10u, a4: true); /*0x1039ce86f*/
        }
        else
        {
          RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v61, a2: v76, a3: (unsigned __int8 *)2, a4: v17); /*0x1039ce8d1*/
          RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v76, a3: 0x10u, a4: true); /*0x1039ce8eb*/
        }
      }
      v72 = (v74 >> 3) - started; /*0x1039ce903*/
      writeRakPeerCapabilities(this: (RakNet::BitStream *)v73, a2: v59); /*0x1039ce910*/
      v77 = *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1); /*0x1039ce91c*/
      *(_OWORD *)v76 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039ce927*/
      v34 = (unsigned __int8 *)(*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)this + 424LL))( /*0x1039ce94b*/
                                 a1: this,
                                 a2: v30,
                                 a3: v28,
                                 a4: v29,
                                 a5: v31,
                                 a6: v32,
                                 a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
                                 a8: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
                                 a9: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
                                 a10: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3));
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039ceecf*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v54); /*0x1039ceeda*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039ceee7*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ce963*/
      {
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v34, a3: 0x40u, a4: true); /*0x1039ce979*/
      }
      else
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v34, a2: v76, a3: (unsigned __int8 *)8, a4: v33); /*0x1039ce98c*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v76, a3: 0x40u, a4: true); /*0x1039ce9a6*/
      }
      *(_WORD *)v68 = a2; /*0x1039ce9ab*/
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039ceeff*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v55); /*0x1039cef0a*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cef17*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ce9c8*/
      {
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v68, a3: 0x10u, a4: true); /*0x1039ce9e2*/
      }
      else
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v68, a2: v76, a3: (unsigned __int8 *)2, a4: v35); /*0x1039ce9f9*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v76, a3: 0x10u, a4: true); /*0x1039cea13*/
      }
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: &v70, a3: 8u, a4: true); /*0x1039cea30*/
      LOBYTE(PortNetworkOrder) = 4; /*0x1039cea3c*/
      RakNet::BitStream::WriteBits( /*0x1039cea50*/
        this: (RakNet::BitStream *)v73,
        a2: (const unsigned __int8 *)&PortNetworkOrder,
        a3: 8u,
        a4: true);
      v36 = *a3; /*0x1039cea55*/
      v77 = a3[1]; /*0x1039cea5e*/
      *(_OWORD *)v76 = v36; /*0x1039cea62*/
      *(_DWORD *)v61 = ~*((_DWORD *)a3 + 1); /*0x1039cea73*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v61, a3: 0x20u, a4: true); /*0x1039cea86*/
      LOWORD(v63) = RakNet::SystemAddress::GetPortNetworkOrder(this: (RakNet::SystemAddress *)v76); /*0x1039cea9b*/
      RakNet::BitStream::WriteBits( /*0x1039ceaaf*/
        this: (RakNet::BitStream *)v73,
        a2: (const unsigned __int8 *)&v63,
        a3: 0x10u,
        a4: true);
      if ( FFlag::DebugLocalRccServerConnection == 1 && FFlag::DebugLocalRccRuppToken == 1 ) /*0x1039ceac8*/
      {
        RakNet::SystemAddress::SystemAddress( /*0x1039ceaea*/
          this: (RakNet::SystemAddress *)v61,
          a2: byte_10D77E578,
          a3: dword_10D77E5FC);
        v65 = 4; /*0x1039ceaf6*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: &v65, a3: 8u, a4: true); /*0x1039ceb0a*/
        v77 = v62; /*0x1039ceb16*/
        *(_OWORD *)v76 = *(_OWORD *)v61; /*0x1039ceb21*/
        v63 = ~*(_DWORD *)&v61[4]; /*0x1039ceb34*/
        RakNet::BitStream::WriteBits( /*0x1039ceb47*/
          this: (RakNet::BitStream *)v73,
          a2: (const unsigned __int8 *)&v63,
          a3: 0x20u,
          a4: true);
        PortNetworkOrder = RakNet::SystemAddress::GetPortNetworkOrder(this: (RakNet::SystemAddress *)v76); /*0x1039ceb5c*/
        RakNet::BitStream::WriteBits( /*0x1039ceb70*/
          this: (RakNet::BitStream *)v73,
          a2: (const unsigned __int8 *)&PortNetworkOrder,
          a3: 0x10u,
          a4: true);
      }
      v37 = *((_QWORD *)this + 391); /*0x1039ceb75*/
      if ( v37 != 0 ) /*0x1039ceb7f*/
      {
        v38 = *(_BYTE *)(v37 + 24); /*0x1039ceb81*/
        if ( (v38 & 1) != 0 ) /*0x1039ceb86*/
          v39 = *(_BYTE *)(v37 + 32); /*0x1039cebab*/
        else
          v39 = v38 >> 1; /*0x1039ceb88*/
        v76[0] = v39; /*0x1039cebb2*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v76, a3: 8u, a4: true); /*0x1039cebc5*/
        v40 = *((_QWORD *)this + 391); /*0x1039cebca*/
        v41 = *(unsigned __int8 *)(v40 + 24); /*0x1039cebd1*/
        if ( (v41 & 1) != 0 ) /*0x1039cebd8*/
        {
          v43 = *(_QWORD *)(v40 + 32); /*0x1039cebe2*/
          v42 = *(const unsigned __int8 **)(v40 + 40); /*0x1039cebe6*/
        }
        else
        {
          v42 = (const unsigned __int8 *)(v40 + 25); /*0x1039cebda*/
          LODWORD(v43) = v41 >> 1; /*0x1039cebde*/
        }
        RakNet::BitStream::WriteAlignedBytes(this: (RakNet::BitStream *)v73, a2: v42, a3: v43); /*0x1039cebf1*/
      }
      else
      {
        v76[0] = 0; /*0x1039ceb90*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v76, a3: 8u, a4: true); /*0x1039ceba4*/
      }
      v44 = v74; /*0x1039cebfd*/
      *(_WORD *)v71 = (v74 >> 3) - started - v72; /*0x1039cec19*/
      RakNet::BitStream::SetWriteOffset( /*0x1039cec2c*/
        this: (RakNet::BitStream *)v73,
        a2: 8 * (unsigned __int16)started + 144,
        a3: false);
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: &v72, a3: 8u, a4: true); /*0x1039cec49*/
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039cef2f*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v56); /*0x1039cef3a*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cef47*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039cec63*/
      {
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v71, a3: 0x10u, a4: true); /*0x1039cec7d*/
      }
      else
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v71, a2: v76, a3: (unsigned __int8 *)2, a4: v45); /*0x1039cec94*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v73, a2: v76, a3: 0x10u, a4: true); /*0x1039cecae*/
      }
      RakNet::BitStream::SetWriteOffset(this: (RakNet::BitStream *)v73, a2: v44 & 0xFFFFFFF8, a3: false); /*0x1039cecc3*/
      v13 = RBX::Security::RakPeerCrypto::earlyEncryptData( /*0x1039cece5*/
              this: v10,
              a2: (RakNet::BitStream *)v73,
              a3: v72,
              a4: started);
      if ( (_BYTE)v13 != 0 ) /*0x1039cecea*/
      {
        RakNet::BitStream::PadWithZeroToByteLength(this: (RakNet::BitStream *)v73, a2: a2 - 40); /*0x1039cecfb*/
        RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v76); /*0x1039ced04*/
        v46 = *((_QWORD *)this + 253); /*0x1039ced10*/
        v47 = 16LL * *((unsigned int *)a3 + 79); /*0x1039ced17*/
        v48 = *(_QWORD *)(v46 + v47 + 8); /*0x1039ced1b*/
        *(_OWORD *)v60 = *(_OWORD *)(v46 + v47); /*0x1039ced24*/
        if ( v48 != 0 ) /*0x1039ced2e*/
          _InterlockedIncrement64((volatile signed __int64 *)(v48 + 8)); /*0x1039ced30*/
        v49 = RakNet::SocketLayer::SendToOrDelay( /*0x1039ced7f*/
                a1: v60,
                a2: v75,
                a3: (v74 + 7) >> 3,
                a4: a3,
                a5: v76,
                a6: 0,
                a7: this,
                a8: 0,
                a9: 0,
                a10: "",
                a11: 0);
        v50 = v60[1]; /*0x1039ced82*/
        if ( v60[1] != nullptr /*0x1039ced9e*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v60[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v50 + 16LL))(a1: v50); /*0x1039ceda6*/
          std::__shared_weak_count::__release_weak(this: v50); /*0x1039cedac*/
        }
        if ( v49 == -3 || (++*((_QWORD *)this + 454), v49 == 0) ) /*0x1039cedc1*/
        {
          RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 3232)); /*0x1039cee0f*/
          ++*((_DWORD *)this + 804); /*0x1039cee14*/
          RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 3232)); /*0x1039cee1d*/
        }
        else if ( v49 == -4 ) /*0x1039cedc7*/
        {
          ++*((_QWORD *)this + 455); /*0x1039cedc9*/
        }
        else
        {
          ++*((_QWORD *)this + 456); /*0x1039cee24*/
        }
      }
      else if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039cede7*/
      {
        FLog::FastLog( /*0x1039cedfe*/
          a1: DFLog::SessionCrypto,
          a2: qword_10D7BB210,
          a3: "[DFLog::SessionCrypto] RbxOpenRequest2 failed to encrypt",
          0);
      }
    }
    RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v73); /*0x1039cee32*/
  }
  else
  {
    v13 = 0; /*0x1039ce592*/
    if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039ce579*/
      FLog::FastLog( /*0x1039ce597*/
        a1: DFLog::SessionCrypto,
        a2: qword_10D7BB210,
        a3: "[DFLog::SessionCrypto] RbxOpenRequest2 no session crypto",
        0);
  }
  return v13; /*0x1039cee4a*/
}

// Address: 0x1039cf120 | Name: __ZN6RakNet7RakPeer16verifyPreauthMacEN3RBX10StringViewEh
__int64 __fastcall RakNet::RakPeer::verifyPreauthMac(__int64 a1, __int64 a2, __int64 a3)
{
  unsigned int v3; // r12d
  unsigned int v7; // edx
  __int64 v8; // rsi
  __int64 v9; // rdx
  __int64 v10; // rax
  __int64 v11; // rdx
  void *v12; // rcx
  char *v13; // rsi
  __int64 v14; // rdx
  unsigned int v15; // r15d
  __int64 v16; // r12
  char *v17; // r13
  char v18; // r15
  __int64 v19; // rax
  _BYTE v21[16]; // [rsp+0h] [rbp-A0h] BYREF
  void *v22; // [rsp+10h] [rbp-90h]
  __int64 v23; // [rsp+18h] [rbp-88h]
  __int128 v24; // [rsp+20h] [rbp-80h] BYREF
  void *v25; // [rsp+30h] [rbp-70h]
  char v26; // [rsp+38h] [rbp-68h]
  __int128 v27; // [rsp+40h] [rbp-60h] BYREF
  void *v28; // [rsp+50h] [rbp-50h]
  __int128 v29; // [rsp+60h] [rbp-40h] BYREF
  void *v30; // [rsp+70h] [rbp-30h]

  v3 = 1; /*0x1039cf131*/
  if ( *(_BYTE *)(a1 + 3088) == 1 ) /*0x1039cf13e*/
  {
    if ( ((a3 == 32) & (unsigned __int8)~DFFlag::ForceNewPaBlob2) != 0 || a3 == 50 || (v3 = 0, a3 == 33) ) /*0x1039cf170*/
    {
      v27 = 0; /*0x1039cf179*/
      v28 = nullptr; /*0x1039cf17d*/
      if ( a2 != 0 ) /*0x1039cf188*/
      {
        std::string::basic_string[abi:ne200100](a1: &v24, a2, a3: 16); /*0x1039cf196*/
      }
      else
      {
        v24 = 0; /*0x1039cf19d*/
        v25 = nullptr; /*0x1039cf1a1*/
      }
      v7 = *(unsigned __int8 *)(a1 + 2984); /*0x1039cf1a9*/
      if ( (v7 & 1) != 0 ) /*0x1039cf1b3*/
      {
        v8 = *(_QWORD *)(a1 + 3000); /*0x1039cf1b5*/
        v9 = *(_QWORD *)(a1 + 2992); /*0x1039cf1bc*/
      }
      else
      {
        v8 = a1 + 2985; /*0x1039cf1c5*/
        v9 = v7 >> 1; /*0x1039cf1cc*/
      }
      v10 = std::string::append(a1: &v24, a2: v8, a3: v9); /*0x1039cf1d2*/
      v12 = *(void **)(v10 + 16); /*0x1039cf1d7*/
      v30 = v12; /*0x1039cf1db*/
      v29 = *(_OWORD *)v10; /*0x1039cf1e2*/
      *(_OWORD *)v10 = 0; /*0x1039cf1e9*/
      *(_QWORD *)(v10 + 16) = 0; /*0x1039cf1ec*/
      if ( (v24 & 1) != 0 ) /*0x1039cf1f8*/
        operator delete(a1: v25); /*0x1039cf1fe*/
      if ( FFlag::FixPreauthKeyRingJobIdDerivation == 1 ) /*0x1039cf20d*/
      {
        if ( (v29 & 1) != 0 ) /*0x1039cf21d*/
        {
          v13 = (char *)v30; /*0x1039cf223*/
          v14 = *((_QWORD *)&v29 + 1); /*0x1039cf227*/
        }
        else
        {
          v14 = (unsigned __int8)v29 >> 1; /*0x1039cf2bd*/
          v13 = (char *)&v29 + 1; /*0x1039cf2bf*/
        }
        RBX::Security::SessionCrypto::verifyPreauthMac(a1: &v24, a2: v13, a3: v14, a4: a2, a5: a3, a6: a1 + 2984); /*0x1039cf2cd*/
        v18 = v26; /*0x1039cf2d2*/
        v27 = v24; /*0x1039cf2da*/
        v28 = v25; /*0x1039cf2e2*/
      }
      else
      {
        v23 = a2; /*0x1039cf230*/
        v15 = (unsigned __int8)v29; /*0x1039cf237*/
        v16 = *((_QWORD *)&v29 + 1); /*0x1039cf23c*/
        v17 = (char *)v30; /*0x1039cf240*/
        std::string::basic_string[abi:ne200100]<0>(a1: v21, a2: "", a3: v11, a4: v12); /*0x1039cf252*/
        if ( (v15 & 1) == 0 ) /*0x1039cf260*/
        {
          v16 = v15 >> 1; /*0x1039cf260*/
          v17 = (char *)&v29 + 1; /*0x1039cf268*/
        }
        RBX::Security::SessionCrypto::verifyPreauthMac(a1: &v24, a2: v17, a3: v16, a4: v23, a5: a3, a6: v21); /*0x1039cf287*/
        v18 = v26; /*0x1039cf28c*/
        v27 = v24; /*0x1039cf294*/
        v28 = v25; /*0x1039cf29c*/
        LOWORD(v24) = 0; /*0x1039cf2a0*/
        if ( (v21[0] & 1) != 0 ) /*0x1039cf2ad*/
          operator delete(a1: v22); /*0x1039cf2b6*/
      }
      if ( (v27 & 1) != 0 ) /*0x1039cf2ec*/
        v19 = *((_QWORD *)&v27 + 1); /*0x1039cf2ee*/
      else
        v19 = (unsigned __int8)v27 >> 1; /*0x1039cf2f4*/
      if ( v19 != 0 ) /*0x1039cf2f9*/
      {
        v3 = 3; /*0x1039cf315*/
        if ( std::__tree<std::string>::find<std::string>(a1: a1 + 3064, a2: (unsigned __int8 *)&v27) == a1 + 3072 ) /*0x1039cf31e*/
        {
          std::__tree<std::string>::__emplace_unique_key_args<std::string,std::string>(a1: a1 + 3064, a2: &v27); /*0x1039cf32a*/
          v3 = 2 - (v18 & 1); /*0x1039cf33c*/
        }
      }
      else
      {
        v3 = 0; /*0x1039cf359*/
        if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039cf356*/
        {
          v3 = 0; /*0x1039cf360*/
          FLog::FastLog( /*0x1039cf373*/
            a1: DFLog::SessionCrypto,
            a2: qword_10D7BB210,
            a3: "[DFLog::SessionCrypto] RbxOpenRequest2 invalid.",
            0);
        }
      }
      if ( (v29 & 1) != 0 ) /*0x1039cf37c*/
        operator delete(a1: v30); /*0x1039cf382*/
      if ( (v27 & 1) != 0 ) /*0x1039cf38b*/
        operator delete(a1: v28); /*0x1039cf391*/
    }
  }
  return v3; /*0x1039cf399*/
}

// Address: 0x1039cf5a2 | Name: __ZN6RakNet7RakPeer17sendRbxOpenReply2EPNS0_18RemoteSystemStructERKNS_13SystemAddressES5_RNSt3__110shared_ptrINS_12RakNetSocketEEEyRKN3RBX4Rupp21DeserializationResultE
__int64 __fastcall RakNet::RakPeer::sendRbxOpenReply2(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        __int128 *a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int64 a7)
{
  __int64 started; // r14
  unsigned __int8 v11; // al
  unsigned int v12; // r14d
  RBX::Security::RakPeerCrypto *v13; // r15
  const unsigned __int8 *PublicKey; // r13
  __int64 v15; // rdx
  unsigned int v16; // ecx
  __int64 v17; // rdx
  __int64 v18; // rcx
  __int64 v19; // rsi
  __int64 v20; // r8
  __int64 v21; // r9
  unsigned int v22; // ecx
  unsigned __int8 *v23; // r13
  unsigned int v24; // ecx
  __int128 v25; // xmm0
  int v26; // r13d
  int v27; // r14d
  char v28; // al
  const char *v29; // rcx
  const char *v30; // r8
  const char *v31; // r9
  unsigned int v32; // r13d
  unsigned __int16 v33; // r14
  unsigned int v34; // ecx
  __int128 v35; // xmm0
  __int128 v36; // xmm0
  __int64 v37; // rax
  int v38; // r15d
  std::__shared_weak_count *v39; // r12
  RakNet::BitStream *v41; // rdi
  RakNet::BitStream *v42; // rdi
  RakNet::BitStream *v43; // rdi
  RakNet::BitStream *v44; // rdi
  unsigned __int8 v45[40]; // [rsp+30h] [rbp-1E0h] BYREF
  __int128 *v46; // [rsp+58h] [rbp-1B8h]
  __int64 v47; // [rsp+60h] [rbp-1B0h]
  __int64 v48; // [rsp+68h] [rbp-1A8h]
  std::__shared_weak_count *v49[2]; // [rsp+70h] [rbp-1A0h] BYREF
  __int64 v50; // [rsp+80h] [rbp-190h]
  unsigned __int8 v51[3]; // [rsp+8Ch] [rbp-184h] BYREF
  unsigned __int8 v52; // [rsp+8Fh] [rbp-181h] BYREF
  unsigned __int8 v53[2]; // [rsp+90h] [rbp-180h] BYREF
  unsigned __int8 RakCryptoFormat; // [rsp+92h] [rbp-17Eh] BYREF
  unsigned __int8 v55; // [rsp+93h] [rbp-17Dh] BYREF
  unsigned __int8 v56[3]; // [rsp+94h] [rbp-17Ch] BYREF
  unsigned __int8 v57; // [rsp+97h] [rbp-179h] BYREF
  _BYTE v58[12]; // [rsp+98h] [rbp-178h] BYREF
  unsigned int v59; // [rsp+A4h] [rbp-16Ch]
  __int64 v60; // [rsp+B0h] [rbp-160h]
  unsigned __int8 v61[16]; // [rsp+1C0h] [rbp-50h] BYREF
  __int128 v62; // [rsp+1D0h] [rbp-40h]

  v48 = a5; /*0x1039cf5b6*/
  v47 = a4; /*0x1039cf5bd*/
  v46 = a3; /*0x1039cf5c4*/
  if ( *((_QWORD *)a2 + 49) != 0 ) /*0x1039cf5e1*/
  {
    RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v58, a2: 0x440u); /*0x1039cf5f8*/
    started = RakNet::RakPeer::startOfflineBitStream(this, a2: (RakNet::BitStream *)v58, a3: a2, a4: a6); /*0x1039cf612*/
    if ( (*(unsigned __int8 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 800LL))(a1: this) != 0 ) /*0x1039cf623*/
      v11 = *((_BYTE *)a2 + 5276); /*0x1039cf625*/
    else
      v11 = 0; /*0x1039cf66c*/
    v55 = v11; /*0x1039cf66e*/
    v57 = 0; /*0x1039cf674*/
    *(_WORD *)v56 = 0; /*0x1039cf67b*/
    v13 = *((RBX::Security::RakPeerCrypto **)a2 + 49); /*0x1039cf684*/
    PublicKey = (const unsigned __int8 *)RBX::Security::RakPeerCrypto::getPublicKey(this: v13); /*0x1039cf694*/
    if ( PublicKey == nullptr || v15 == 0 ) /*0x1039cf6a0*/
    {
      v12 = 0; /*0x1039cf6c2*/
      if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039cf6bf*/
        FLog::FastLog( /*0x1039cf6dd*/
          a1: DFLog::SessionCrypto,
          a2: qword_10D7BB210,
          a3: "[DFLog::SessionCrypto] RbxOpenReply2 no public key",
          0);
    }
    else
    {
      RakCryptoFormat = RBX::Security::SessionCrypto::getRakCryptoFormat(this: v13); /*0x1039cf6ef*/
      v61[0] = 125; /*0x1039cf6f9*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: v61, a3: 8u, a4: true); /*0x1039cf70d*/
      RakNet::BitStream::WriteAlignedBytes(this: (RakNet::BitStream *)v58, a2: &OFFLINE_MESSAGE_DATA_ID, a3: 0x10u); /*0x1039cf725*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: &v55, a3: 8u, a4: true); /*0x1039cf742*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: &v57, a3: 8u, a4: true); /*0x1039cf75f*/
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039cfcf7*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v41); /*0x1039cfd02*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cfd0f*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039cf779*/
      {
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: v56, a3: 0x10u, a4: true); /*0x1039cf793*/
      }
      else
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v56, a2: v61, a3: (unsigned __int8 *)2, a4: v16); /*0x1039cf7b2*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: v61, a3: 0x10u, a4: true); /*0x1039cf7cc*/
      }
      v57 = v59 >> 3; /*0x1039cf7de*/
      RakNet::BitStream::WriteAlignedBytes(this: (RakNet::BitStream *)v58, a2: PublicKey, a3: 0x20u); /*0x1039cf7ec*/
      writeRakPeerCapabilities(this: (RakNet::BitStream *)v58, a2: *((_QWORD *)a2 + 657)); /*0x1039cf800*/
      v62 = *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1); /*0x1039cf80c*/
      *(_OWORD *)v61 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039cf817*/
      v23 = (unsigned __int8 *)(*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)this + 424LL))( /*0x1039cf83b*/
                                 a1: this,
                                 a2: v19,
                                 a3: v17,
                                 a4: v18,
                                 a5: v20,
                                 a6: v21,
                                 a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
                                 a8: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
                                 a9: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
                                 a10: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3));
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039cfd27*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v42); /*0x1039cfd32*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cfd3f*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039cf853*/
      {
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: v23, a3: 0x40u, a4: true); /*0x1039cf869*/
      }
      else
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v23, a2: v61, a3: (unsigned __int8 *)8, a4: v22); /*0x1039cf87c*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: v61, a3: 0x40u, a4: true); /*0x1039cf896*/
      }
      *(_WORD *)v53 = *((_WORD *)a2 + 2608); /*0x1039cf8a4*/
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039cfd57*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v43); /*0x1039cfd62*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cfd6f*/
      }
      v50 = started; /*0x1039cf8b9*/
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039cf8c7*/
      {
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: v53, a3: 0x10u, a4: true); /*0x1039cf8e1*/
      }
      else
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v53, a2: v61, a3: (unsigned __int8 *)2, a4: v24); /*0x1039cf8f8*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: v61, a3: 0x10u, a4: true); /*0x1039cf912*/
      }
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: &RakCryptoFormat, a3: 8u, a4: true); /*0x1039cf92f*/
      v52 = 4; /*0x1039cf93b*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: &v52, a3: 8u, a4: true); /*0x1039cf94f*/
      v25 = *(_OWORD *)((char *)a2 + 4); /*0x1039cf954*/
      v62 = *(_OWORD *)((char *)a2 + 20); /*0x1039cf960*/
      *(_OWORD *)v61 = v25; /*0x1039cf964*/
      *(_DWORD *)v45 = ~*((_DWORD *)a2 + 2); /*0x1039cf976*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: v45, a3: 0x20u, a4: true); /*0x1039cf989*/
      *(_WORD *)v51 = RakNet::SystemAddress::GetPortNetworkOrder(this: (RakNet::SystemAddress *)v61); /*0x1039cf99e*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: v51, a3: 0x10u, a4: true); /*0x1039cf9b2*/
      v26 = DFLog::RuppTokenLog; /*0x1039cf9be*/
      if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && BYTE1(DFLog::RuppTokenLog) >= 3u ) /*0x1039cf9d1*/
      {
        v27 = qword_10D7B48E0; /*0x1039cf9d8*/
        v28 = (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)this + 800LL))(a1: this); /*0x1039cf9e2*/
        v29 = "not expected"; /*0x1039cf9ef*/
        if ( v28 != 0 ) /*0x1039cf9f8*/
          v29 = "expected"; /*0x1039cf9f8*/
        v30 = "not received"; /*0x1039cfa03*/
        if ( *((_BYTE *)a2 + 5276) != 0 ) /*0x1039cfa13*/
          v30 = "received"; /*0x1039cfa13*/
        v31 = "replied."; /*0x1039cfa25*/
        if ( v55 == 0 ) /*0x1039cfa2c*/
          v31 = "not replied."; /*0x1039cfa2c*/
        FLog::FastLogFormatted( /*0x1039cfa3f*/
          a1: v26,
          a2: v27,
          a3: (unsigned int)"[DFLog::RuppTokenLog] Token %s.  RbxOpenRequest2 token %s.  RbxOpenReply2 token %s",
          a4: (_DWORD)v29,
          a5: (_DWORD)v30,
          a6: (_DWORD)v31);
      }
      *(_WORD *)v56 = (v59 >> 3) - v57; /*0x1039cfa5a*/
      RakNet::BitStream::WriteAlignedBytes(this: (RakNet::BitStream *)v58, a2: &kZeroPacket, a3: 0x1Cu); /*0x1039cfa6d*/
      v32 = v59; /*0x1039cfa79*/
      v33 = v50; /*0x1039cfa7d*/
      RakNet::BitStream::SetWriteOffset(this: (RakNet::BitStream *)v58, a2: 8 * v50 + 144, a3: false); /*0x1039cfa8e*/
      RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: &v57, a3: 8u, a4: true); /*0x1039cfaab*/
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039cfd87*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v44); /*0x1039cfd92*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cfd9f*/
        v33 = v50; /*0x1039cfda4*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039cfac5*/
      {
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: v56, a3: 0x10u, a4: true); /*0x1039cfadf*/
      }
      else
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v56, a2: v61, a3: (unsigned __int8 *)2, a4: v34); /*0x1039cfaf6*/
        RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v58, a2: v61, a3: 0x10u, a4: true); /*0x1039cfb10*/
      }
      RakNet::BitStream::SetWriteOffset(this: (RakNet::BitStream *)v58, a2: v32 & 0xFFFFFFF8, a3: false); /*0x1039cfb25*/
      v12 = RBX::Security::RakPeerCrypto::earlyEncryptData(this: v13, a2: (RakNet::BitStream *)v58, a3: v57, a4: v33); /*0x1039cfb44*/
      if ( (_BYTE)v12 != 0 ) /*0x1039cfb49*/
      {
        v35 = *v46; /*0x1039cfb5a*/
        v62 = v46[1]; /*0x1039cfb61*/
        *(_OWORD *)v61 = v35; /*0x1039cfb65*/
        if ( (*(_BYTE *)(a7 + 3) & 1) != 0 ) /*0x1039cfb6d*/
        {
          v36 = *(_OWORD *)((char *)a2 + 4552); /*0x1039cfb6f*/
          *(_OWORD *)&v45[16] = *(_OWORD *)((char *)a2 + 4568); /*0x1039cfb88*/
          *(_OWORD *)v45 = v36; /*0x1039cfb8c*/
          RakNet::SystemAddress::operator=(a1: v61, a2: v45); /*0x1039cfb93*/
        }
        v37 = *(_QWORD *)(v48 + 8); /*0x1039cfb9f*/
        *(_OWORD *)v49 = *(_OWORD *)v48; /*0x1039cfba6*/
        if ( v37 != 0 ) /*0x1039cfbb0*/
          _InterlockedIncrement64((volatile signed __int64 *)(v37 + 8)); /*0x1039cfbb2*/
        v38 = RakNet::SocketLayer::SendToOrDelay( /*0x1039cfc05*/
                a1: v49,
                a2: v60,
                a3: (v59 + 7) >> 3,
                a4: v61,
                a5: v47,
                a6: 0,
                a7: this,
                a8: 0,
                a9: 0,
                a10: "",
                a11: 0);
        v39 = v49[1]; /*0x1039cfc08*/
        if ( v49[1] != nullptr /*0x1039cfc25*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v49[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v39 + 16LL))(a1: v39); /*0x1039cfc2e*/
          std::__shared_weak_count::__release_weak(this: v39); /*0x1039cfc34*/
        }
        if ( v38 == -3 || (++*((_QWORD *)this + 454), v38 == 0) ) /*0x1039cfc49*/
        {
          RakNet::SimpleMutex::Lock(this: (RakNet::RakPeer *)((char *)this + 3232)); /*0x1039cfc97*/
          ++*((_DWORD *)this + 806); /*0x1039cfc9c*/
          RakNet::SimpleMutex::Unlock(this: (RakNet::RakPeer *)((char *)this + 3232)); /*0x1039cfca5*/
        }
        else if ( v38 == -4 ) /*0x1039cfc4f*/
        {
          ++*((_QWORD *)this + 455); /*0x1039cfc51*/
        }
        else
        {
          ++*((_QWORD *)this + 456); /*0x1039cfcac*/
        }
      }
      else if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039cfc6f*/
      {
        FLog::FastLog( /*0x1039cfc86*/
          a1: DFLog::SessionCrypto,
          a2: qword_10D7BB210,
          a3: "[DFLog::SessionCrypto] RbxOpenReply2 encrypt failed",
          0);
      }
    }
    RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v58); /*0x1039cfcba*/
  }
  else
  {
    v12 = 0; /*0x1039cf65d*/
    if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && BYTE1(DFLog::SessionCrypto) >= 3u ) /*0x1039cf644*/
      FLog::FastLog( /*0x1039cf662*/
        a1: DFLog::SessionCrypto,
        a2: qword_10D7BB210,
        a3: "[DFLog::SessionCrypto] RbxOpenReply2 no session crypto",
        0);
  }
  return v12; /*0x1039cfcd2*/
}

// Address: 0x1039cfe94 | Name: __ZN6RakNet7RakPeer22selectRuppTokenLineageEPKh
__int64 __fastcall RakNet::RakPeer::selectRuppTokenLineage(RakNet::RakPeer *this, const unsigned __int8 *a2)
{
  __int64 result; // rax

  LOBYTE(result) = 9; /*0x1039cfe9b*/
  if ( DFFlag::RuppTokenOneBeeRcc == 1 ) /*0x1039cfea0*/
    LOBYTE(result) = RBX::Rupp::RuppTokenProcessor::isAltToken(this, a2) + 9; /*0x1039cfeab*/
  return (unsigned __int8)result; /*0x1039cfeb1*/
}

// Address: 0x1039cfeb2 | Name: __ZN6RakNet7RakPeer32sendApplicationConnectionRequestEPKNS0_25RequestedConnectionStructERKNS_13SystemAddressEy
__int64 __fastcall RakNet::RakPeer::sendApplicationConnectionRequest(
        RakNet::RakPeer *this,
        __int64 a2,
        const RakNet::SystemAddress *a3,
        unsigned __int64 a4)
{
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // rsi
  __int64 v11; // r8
  __int64 v12; // r9
  unsigned int v13; // ecx
  unsigned __int8 *v14; // r13
  __int128 v15; // xmm0
  bool v16; // si
  bool v17; // r14
  unsigned int RemoteSystemIndex; // eax
  unsigned int v19; // ecx
  __int64 v20; // r12
  int v21; // r13d
  RakNet::BitStream *v23; // rdi
  RakNet::BitStream *v24; // rdi
  unsigned __int64 v25; // [rsp+40h] [rbp-1A0h]
  unsigned __int8 v26[8]; // [rsp+48h] [rbp-198h] BYREF
  bool v27[16]; // [rsp+50h] [rbp-190h] BYREF
  __int128 v28; // [rsp+60h] [rbp-180h]
  _BYTE v29[12]; // [rsp+88h] [rbp-158h] BYREF
  int v30; // [rsp+94h] [rbp-14Ch]
  __int64 v31; // [rsp+A0h] [rbp-140h]

  if ( (unsigned __int8)DFLog::RakNetConnectTrace >= 6u && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
    FLog::FastLog(
      a1: DFLog::RakNetConnectTrace,
      a2: qword_10D7BB0C8,
      a3: "[DFLog::RakNetConnectTrace] RakNet: Send App Connection Request",
      0);
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v29); /*0x1039cff18*/
  v27[0] = 9; /*0x1039cff24*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v29, a2: (const unsigned __int8 *)v27, a3: 8u, a4: true); /*0x1039cff38*/
  v28 = *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1); /*0x1039cff44*/
  *(_OWORD *)v27 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039cff52*/
  v14 = (unsigned __int8 *)(*(__int64 (__fastcall **)(RakNet::RakPeer *, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)this + 424LL))( /*0x1039cff7f*/
                             a1: this,
                             a2: v10,
                             a3: v8,
                             a4: v9,
                             a5: v11,
                             a6: v12,
                             a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
                             a8: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
                             a9: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
                             a10: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3));
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039d01a8*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v23); /*0x1039d01b3*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039d01c0*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039cff97*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v29, a2: v14, a3: 0x40u, a4: true); /*0x1039cffad*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039cffc3*/
      this: (RakNet::BitStream *)v14,
      a2: (unsigned __int8 *)v27,
      a3: (unsigned __int8 *)8,
      a4: v13);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v29, a2: (const unsigned __int8 *)v27, a3: 0x40u, a4: true); /*0x1039cffe0*/
  }
  v25 = a4; /*0x1039cffe5*/
  v15 = *(_OWORD *)a3; /*0x1039cffec*/
  v28 = *((_OWORD *)a3 + 1); /*0x1039cfffc*/
  *(_OWORD *)v27 = v15; /*0x1039d0000*/
  v17 = true; /*0x1039d000f*/
  if ( (unsigned __int8)RakNet::SystemAddress::operator==(a1: v27, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) == 0 ) /*0x1039d0014*/
  {
    RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, a2: (const RakNet::SystemAddress *)v27); /*0x1039d0020*/
    if ( RemoteSystemIndex != -1 && (*(_BYTE *)(*((_QWORD *)this + 92) + 5368LL * RemoteSystemIndex) & 1) != 0 ) /*0x1039d003f*/
      v17 = *((_QWORD *)this + 92) == 0; /*0x1039d0049*/
  }
  *(_QWORD *)v26 = RakNet::GetTime(this: (RakNet *)v17, a2: v16); /*0x1039d0056*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039d01d8*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v24); /*0x1039d01e3*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039d01f0*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039d0072*/
  {
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v29, a2: v26, a3: 0x40u, a4: true); /*0x1039d008c*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes( /*0x1039d00a6*/
      this: (RakNet::BitStream *)v26,
      a2: (unsigned __int8 *)v27,
      a3: (unsigned __int8 *)8,
      a4: v19);
    RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v29, a2: (const unsigned __int8 *)v27, a3: 0x40u, a4: true); /*0x1039d00c3*/
  }
  v27[0] = false; /*0x1039d00cf*/
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)v29, a2: (const unsigned __int8 *)v27, a3: 8u, a4: true); /*0x1039d00e3*/
  if ( *(_BYTE *)(a2 + 314) != 0 ) /*0x1039d00f3*/
    RakNet::BitStream::Write( /*0x1039d0103*/
      this: (RakNet::BitStream *)v29,
      a2: (const char *)(a2 + 58),
      a3: *(unsigned __int8 *)(a2 + 314));
  v20 = v31; /*0x1039d0108*/
  v21 = v30; /*0x1039d010f*/
  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v27, a2: a3); /*0x1039d0123*/
  RakNet::RakPeer::SendImmediate( /*0x1039d0167*/
    a1: (__int64)this,
    a2: v20,
    a3: v21,
    a4: 0,
    a5: 2u,
    a6: 0,
    a7: (__int64)v27,
    a8: 0,
    a9: 0,
    a10: v25,
    a11: 0,
    a12: 0,
    a13: 0);
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v29); /*0x1039d0173*/
  return __stack_chk_guard; /*0x1039d0188*/
}

// Address: 0x1039d0236 | Name: __ZN6RakNet7RakPeer27applicationConnectionFailedEPKNS0_25RequestedConnectionStructERKNS_10RakNetGUIDE
__int64 __fastcall RakNet::RakPeer::applicationConnectionFailed(RakNet::RakPeer *this, __int64 a2, __int64 a3)
{
  int v6; // r8d
  int v7; // r9d
  __int64 v8; // r12
  const char *v9; // rcx
  __int64 result; // rax
  __int64 v11; // rdi

  v8 = RakNet::RakPeer::AllocPacket(this, a2: 1u, a3: "", a4: 0); /*0x1039d025d*/
  if ( DFFlag::AddRakNetDebugLogs == 1 /*0x1039d027e*/
    && (unsigned __int8)DFLog::RakNetConnectTrace >= 6u
    && BYTE1(DFLog::RakNetConnectTrace) >= 3u )
  {
    v9 = "client"; /*0x1039d0293*/
    if ( *((_BYTE *)this + 3728) != 0 ) /*0x1039d02a2*/
      v9 = "server"; /*0x1039d02a2*/
    FLog::FastLogFormatted( /*0x1039d02af*/
      a1: (_DWORD)DFLog::RakNetConnectTrace,
      a2: qword_10D7BB0C8,
      a3: (unsigned int)"[DFLog::RakNetConnectTrace] (%s) RakNet connection failed because no connections are available",
      a4: (_DWORD)v9,
      a5: v6,
      a6: v7);
  }
  **(_BYTE **)(v8 + 56) = 17; /*0x1039d02b9*/
  *(_DWORD *)(v8 + 52) = 8; /*0x1039d02bc*/
  RakNet::SystemAddress::operator=(a1: v8, a2); /*0x1039d02cb*/
  *(_QWORD *)(v8 + 32) = *(_QWORD *)a3; /*0x1039d02d3*/
  *(_WORD *)(v8 + 40) = *(_WORD *)(a3 + 8); /*0x1039d02dd*/
  result = RakNet::RakPeer::AddPacketToProducer(this, a2: v8, a3: 0); /*0x1039d02eb*/
  v11 = *((_QWORD *)this + 423); /*0x1039d02f0*/
  if ( v11 != 0 ) /*0x1039d02fa*/
    return (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v11 + 56LL))(a1: v11, a2); /*0x1039d030e*/
  return result; /*0x1039d0307*/
}

// Address: 0x1039d031a | Name: __ZN6RakNet7RakPeer33getSessionCryptoFromSystemAddressENS_13SystemAddressE
RBX::Security::SessionCrypto **__fastcall RakNet::RakPeer::getSessionCryptoFromSystemAddress(
        RBX::Security::SessionCrypto **a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  __int64 v9; // r12
  unsigned __int64 v10; // r13
  __int64 v12; // rax
  RBX::Security::SessionCrypto *v13; // r15
  volatile signed __int64 *v14; // r14

  if ( *(_QWORD *)(a2 + 736) != 0 && *(_WORD *)(a2 + 170) != 0 ) /*0x1039d0343*/
  {
    v9 = 0; /*0x1039d0349*/
    v10 = 0; /*0x1039d034c*/
    while ( (*(_BYTE *)(*(_QWORD *)(a2 + 736) + v9) & 1) == 0 /*0x1039d0377*/
         || (unsigned __int8)RakNet::SystemAddress::operator==(a1: *(_QWORD *)(a2 + 736) + v9 + 4, a2: &a7) == 0 )
    {
      ++v10; /*0x1039d0379*/
      v9 += 5368; /*0x1039d0384*/
      if ( v10 >= *(unsigned __int16 *)(a2 + 170) ) /*0x1039d038e*/
        goto LABEL_7; /*0x1039d038e*/
    }
    v12 = *(_QWORD *)(a2 + 736); /*0x1039d03a8*/
    v13 = *(RBX::Security::SessionCrypto **)(v12 + v9 + 392); /*0x1039d03af*/
    v14 = *(volatile signed __int64 **)(v12 + v9 + 400); /*0x1039d03bb*/
    if ( v14 != nullptr ) /*0x1039d03ca*/
      _InterlockedIncrement64(v14 + 1); /*0x1039d03cc*/
    if ( v13 != nullptr && (unsigned __int8)RBX::Security::SessionCrypto::isKeyExchangeComplete(this: v13) != 0 ) /*0x1039d03e0*/
    {
      *a1 = v13; /*0x1039d03e2*/
      a1[1] = (RBX::Security::SessionCrypto *)v14; /*0x1039d03e5*/
      if ( v14 == nullptr ) /*0x1039d03ec*/
        return a1; /*0x1039d03ec*/
      _InterlockedIncrement64(v14 + 1); /*0x1039d03ee*/
    }
    else
    {
      *(_OWORD *)a1 = 0; /*0x1039d03f8*/
      if ( v14 == nullptr ) /*0x1039d03fe*/
        return a1; /*0x1039d03fe*/
    }
    if ( _InterlockedExchangeAdd64(v14 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039d0410*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v14 + 16))(a1: v14); /*0x1039d0418*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v14); /*0x1039d041e*/
    }
  }
  else
  {
LABEL_7:
    *(_OWORD *)a1 = 0; /*0x1039d0390*/
  }
  return a1; /*0x1039d0399*/
}

// Address: 0x1039d043c | Name: __ZN6RakNet7RakPeer18setIsRbxConnectionEb
void __fastcall RakNet::RakPeer::setIsRbxConnection(RakNet::RakPeer *this, char a2)
{
  *((_BYTE *)this + 3088) = a2; /*0x1039d0440*/
}

// Address: 0x1039d044a | Name: __ZN6RakNet7RakPeer32getTokenOptionsFromSystemAddressENS_13SystemAddressE
unsigned __int64 __fastcall RakNet::RakPeer::getTokenOptionsFromSystemAddress(
        RakNet::RakPeer *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int64 a7)
{
  unsigned int RemoteSystemIndex; // eax
  __int64 v9; // rax
  __int64 v10; // rax
  unsigned __int64 v11; // rcx
  __int64 v12; // rdx
  __int64 v13; // rsi
  __int64 v14; // rax

  if ( *((_QWORD *)a1 + 92) != 0 ) /*0x1039d0452*/
  {
    RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this: a1, a2: (const RakNet::SystemAddress *)&a7); /*0x1039d0461*/
    if ( RemoteSystemIndex == -1 || (v9 = 5368LL * RemoteSystemIndex, (*(_BYTE *)(*((_QWORD *)a1 + 92) + v9) & 1) == 0) ) /*0x1039d0481*/
    {
      v14 = 0; /*0x1039d04b6*/
      v11 = 0; /*0x1039d04b8*/
      v12 = 0; /*0x1039d04ba*/
      v13 = 0; /*0x1039d04bc*/
    }
    else
    {
      v10 = *(_QWORD *)(*((_QWORD *)a1 + 92) + v9 + 5272); /*0x1039d048a*/
      v11 = v10 & 0xFFFFFF0000000000LL; /*0x1039d049c*/
      v12 = v10 & 0xFF00000000LL; /*0x1039d04a9*/
      v13 = (unsigned __int8)v10; /*0x1039d04ac*/
      v14 = (unsigned int)v10 & 0xFFFFFF00; /*0x1039d04af*/
    }
  }
  else
  {
    v14 = 0; /*0x1039d04c6*/
    v11 = 0; /*0x1039d04c8*/
    v12 = 0; /*0x1039d04ca*/
    v13 = 0; /*0x1039d04cc*/
  }
  return v13 | v12 | v11 | v14; /*0x1039d04d7*/
}

// Address: 0x1039d04d8 | Name: __ZN6RakNet7RakPeer32getTokenLineageFromSystemAddressENS_13SystemAddressE
__int64 __fastcall RakNet::RakPeer::getTokenLineageFromSystemAddress(
        RakNet::RakPeer *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  unsigned __int8 v7; // r14
  unsigned int RemoteSystemIndex; // eax
  __int64 v10; // rax

  v7 = 9; /*0x1039d04df*/
  if ( *((_QWORD *)a1 + 92) != 0 ) /*0x1039d04ea*/
  {
    RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this: a1, a2: (const RakNet::SystemAddress *)&a7); /*0x1039d04f3*/
    if ( RemoteSystemIndex != -1 ) /*0x1039d04fb*/
    {
      v10 = 5368LL * RemoteSystemIndex; /*0x1039d0506*/
      if ( (*(_BYTE *)(*((_QWORD *)a1 + 92) + v10) & 1) != 0 ) /*0x1039d0513*/
        return *(unsigned __int8 *)(*((_QWORD *)a1 + 92) + v10 + 5265); /*0x1039d051c*/
    }
  }
  return v7; /*0x1039d0528*/
}

// Address: 0x1039d052e | Name: __ZN6RakNet7RakPeer14setReceiveRuppEb
void __fastcall RakNet::RakPeer::setReceiveRupp(RakNet::RakPeer *this, char a2)
{
  *((_BYTE *)this + 132) = a2; /*0x1039d0532*/
}

// Address: 0x1039d053c | Name: __ZNK6RakNet7RakPeer14getReceiveRuppEv
char __fastcall RakNet::RakPeer::getReceiveRupp(RakNet::RakPeer *this)
{
  return *((_BYTE *)this + 132); /*0x1039d0546*/
}

// Address: 0x1039d0548 | Name: __ZN6RakNet7RakPeer23isRecordJoinDataRxStatsENS_13AddressOrGUIDE
__int64 __fastcall RakNet::RakPeer::isRecordJoinDataRxStats(__int64 a1, const RakNet::AddressOrGUID *a2)
{
  unsigned int v3; // ebx
  __int64 RemoteSystem; // rax
  _BYTE v6[72]; // [rsp+8h] [rbp-48h] BYREF

  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v6, a2); /*0x1039d055f*/
  v3 = 0; /*0x1039d0564*/
  RemoteSystem = RakNet::RakPeer::GetRemoteSystem(a1, a2: (__int64)v6, a3: 0, a4: 1u); /*0x1039d0573*/
  if ( RemoteSystem != 0 ) /*0x1039d057b*/
    LOBYTE(v3) = *(_BYTE *)(RemoteSystem + 5264); /*0x1039d057d*/
  LOBYTE(v3) = v3 & 1; /*0x1039d0583*/
  return v3; /*0x1039d0588*/
}

// Address: 0x1039d0594 | Name: __ZN6RakNet7RakPeer24setRecordJoinDataRxStatsENS_13AddressOrGUIDEb
__int64 __fastcall RakNet::RakPeer::setRecordJoinDataRxStats(__int64 a1, const RakNet::AddressOrGUID *a2, char a3)
{
  __int64 result; // rax
  _BYTE v6[72]; // [rsp+8h] [rbp-48h] BYREF

  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v6, a2); /*0x1039d05ad*/
  result = RakNet::RakPeer::GetRemoteSystem(a1, a2: (__int64)v6, a3: 0, a4: 1u); /*0x1039d05bf*/
  if ( result != 0 ) /*0x1039d05c7*/
    *(_BYTE *)(result + 5264) = a3; /*0x1039d05c9*/
  return result; /*0x1039d05cf*/
}

// Address: 0x1039d05da | Name: __ZN6RakNet7RakPeer31getJoinRequestInitiatedTimeInMSENS_13AddressOrGUIDE
__int64 __fastcall RakNet::RakPeer::getJoinRequestInitiatedTimeInMS(__int64 a1, const RakNet::AddressOrGUID *a2)
{
  unsigned int v3; // ebx
  __int64 RemoteSystem; // rax
  _BYTE v6[72]; // [rsp+8h] [rbp-48h] BYREF

  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v6, a2); /*0x1039d05f1*/
  v3 = 0; /*0x1039d05f6*/
  RemoteSystem = RakNet::RakPeer::GetRemoteSystem(a1, a2: (__int64)v6, a3: 0, a4: 1u); /*0x1039d0605*/
  if ( RemoteSystem != 0 ) /*0x1039d060d*/
    return *(unsigned int *)(RemoteSystem + 5268); /*0x1039d060f*/
  return v3; /*0x1039d0617*/
}

// Address: 0x1039d0622 | Name: __ZN6RakNet7RakPeer19resolveSocketFamilyEPNS_16SocketDescriptorEPKc
__int64 __fastcall RakNet::RakPeer::resolveSocketFamily(
        RakNet::RakPeer *this,
        RakNet::SocketDescriptor *a2,
        const char *a3)
{
  unsigned int v4; // r14d
  addrinfo *v5; // rdi
  addrinfo v7; // [rsp+0h] [rbp-50h] BYREF
  addrinfo *v8; // [rsp+30h] [rbp-20h] BYREF

  *((_WORD *)this + 24) = 2; /*0x1039d0632*/
  v8 = nullptr; /*0x1039d063e*/
  memset(&v7.ai_socktype, 0, 40); /*0x1039d0648*/
  v7.ai_socktype = 2; /*0x1039d0654*/
  *(_QWORD *)&v7.ai_flags = 1536; /*0x1039d065b*/
  v4 = getaddrinfo(a1: (const char *)a2, a2: nullptr, a3: &v7, a4: &v8); /*0x1039d066f*/
  v5 = v8; /*0x1039d0677*/
  if ( v4 == 0 && v8 != nullptr ) /*0x1039d067d*/
  {
    if ( v8->ai_family == 30 ) /*0x1039d068b*/
      *((_WORD *)this + 24) = 30; /*0x1039d068d*/
  }
  else if ( v8 == nullptr ) /*0x1039d0698*/
  {
    return v4; /*0x1039d06a2*/
  }
  freeaddrinfo(a1: v5); /*0x1039d069a*/
  return v4; /*0x1039d069a*/
}

// Address: 0x1039d06ae | Name: __ZN6RakNet7RakPeer9setupRuppEbRN3RBX4Rupp8TokenTlv5TokenEPKct
__int64 __fastcall RakNet::RakPeer::setupRupp(__int64 a1, unsigned __int8 a2)
{
  unsigned int v3; // ebx

  v3 = RakNet::RakPeer::setupRuppImpl(); /*0x1039d06bd*/
  if ( DFFlag::RakNetRuppTelemetryReportNetworkStack == 1 ) /*0x1039d06c9*/
    RBX::Rupp::reportRuppInitStats(a1: v3, a2, a3: 0); /*0x1039d06d3*/
  else
    RBX::Rupp::reportRuppInitStats_deprecated(a1: v3, a2); /*0x1039d06e0*/
  return v3; /*0x1039d06e7*/
}

// Address: 0x1039d06ec | Name: __ZN6RakNet7RakPeer13setupRuppImplEbRN3RBX4Rupp8TokenTlv5TokenEPKct
__int64 __fastcall RakNet::RakPeer::setupRuppImpl(
        RBX::Rupp::Rupp **a1,
        unsigned __int8 a2,
        __int64 a3,
        char *a4,
        int a5)
{
  RBX::Rupp::Rupp **v8; // r14
  std::__shared_weak_count *v9; // r15
  __int64 result; // rax
  char *v11; // rbx
  in6_addr v12; // [rsp+8h] [rbp-48h] BYREF
  char *__s1; // [rsp+18h] [rbp-38h]
  in_addr v14; // [rsp+20h] [rbp-30h] BYREF
  int v15; // [rsp+24h] [rbp-2Ch]

  v15 = a5; /*0x1039d06fd*/
  __s1 = a4; /*0x1039d0701*/
  RBX::make_shared<RBX::Rupp::Rupp>(a1: &v12); /*0x1039d0714*/
  v8 = a1 + 412; /*0x1039d0719*/
  std::shared_ptr<RBX::Rupp::Rupp>::operator=[abi:ne200100](a1: a1 + 412, a2: &v12); /*0x1039d0726*/
  v9 = *(std::__shared_weak_count **)&v12.__u6_addr32[2]; /*0x1039d072b*/
  if ( *(_QWORD *)&v12.__u6_addr32[2] != 0 /*0x1039d0744*/
    && _InterlockedExchangeAdd64(
         (volatile signed __int64 *)(*(_QWORD *)&v12.__u6_addr32[2] + 8LL),
         0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x1039d074c*/
    std::__shared_weak_count::__release_weak(this: v9); /*0x1039d0752*/
  }
  RBX::Rupp::Rupp::setFlag(a1: a1[412], a2: 0, a3: a2); /*0x1039d0763*/
  (*((void (__fastcall **)(RBX::Rupp::Rupp **, __int64))*a1 + 97))(a1, a2: 1); /*0x1039d0774*/
  if ( DFFlag::SetIsServerInRakPeerConnect == 0 ) /*0x1039d0781*/
    (*((void (__fastcall **)(RBX::Rupp::Rupp **, _QWORD))*a1 + 123))(a1, a2: 0); /*0x1039d078c*/
  result = RBX::Rupp::Rupp::addTokenTlv(a1: *v8, a2: a3); /*0x1039d0798*/
  if ( (_DWORD)result == 0 ) /*0x1039d079f*/
  {
    v11 = __s1; /*0x1039d07ac*/
    if ( strcmp(__s1, __s2: "localhost") == 0 || strcmp(__s1: v11, __s2: "::1") == 0 ) /*0x1039d07cd*/
      v11 = "127.0.0.1"; /*0x1039d07cf*/
    if ( inet_pton(a1: 2, a2: v11, a3: &v14) != 0 ) /*0x1039d07e9*/
    {
      return RBX::Rupp::Rupp::addIpv4EndpointTlv(this: *v8, a2: v14, a3: v15); /*0x1039d07f5*/
    }
    else if ( inet_pton(a1: 30, a2: v11, a3: &v12) != 0 ) /*0x1039d080f*/
    {
      return RBX::Rupp::Rupp::addIpv6EndpointTlv(this: *v8, a2: v12, a3: v15); /*0x1039d0820*/
    }
    else
    {
      return 10; /*0x1039d0827*/
    }
  }
  return result; /*0x1039d082c*/
}

// Address: 0x1039d083c | Name: __ZNK6RakNet7RakPeer18utGetMinRuppLengthEv
__int64 __fastcall RakNet::RakPeer::utGetMinRuppLength(RakNet::RakPeer *this)
{
  return *((unsigned __int8 *)this + 134); /*0x1039d0847*/
}

// Address: 0x1039d084a | Name: __ZN6RakNet7RakPeer15setTestSendHookENSt3__18functionIFvPKN3RBX11NetworkCore17AbstractBitStreamEEEE
__int64 __fastcall RakNet::RakPeer::setTestSendHook(__int64 a1)
{
  return std::function<void ()(RBX::NetworkCore::AbstractBitStream const*)>::operator=(a1: a1 + 3152); /*0x1039d0855*/
}

// Address: 0x1039d08d0 | Name: __ZN6RakNet7RakPeer19setServerRuppStemmaEPKc
int *__fastcall RakNet::RakPeer::setServerRuppStemma(RakNet::RakPeer *this, const char *a2)
{
  RBX::Rupp::RuppTokenProcessor *v4; // r14
  __int64 v5; // rdi
  int *result; // rax
  const char *v7; // rcx

  if ( *((_QWORD *)this + 414) == 0 ) /*0x1039d08e2*/
  {
    v4 = (RBX::Rupp::RuppTokenProcessor *)operator new(a1: 0x10u); /*0x1039d08f8*/
    RBX::Rupp::RuppTokenProcessor::RuppTokenProcessor(this: v4, a2); /*0x1039d0901*/
    v5 = *((_QWORD *)this + 414); /*0x1039d0906*/
    *((_QWORD *)this + 414) = v4; /*0x1039d090d*/
    if ( v5 != 0 ) /*0x1039d0917*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(a1: v5); /*0x1039d091c*/
    result = &DFLog::RuppTokenLog; /*0x1039d091f*/
    if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && BYTE1(DFLog::RuppTokenLog) >= 3u ) /*0x1039d0938*/
    {
      v7 = "passed."; /*0x1039d0952*/
      if ( *((_QWORD *)this + 414) == 0 ) /*0x1039d0959*/
        v7 = "failed!"; /*0x1039d0959*/
      return (int *)FLog::FastLog( /*0x1039d096e*/
                      a1: *(_QWORD *)&DFLog::RuppTokenLog,
                      a2: qword_10D7B48E0,
                      a3: "[DFLog::RuppTokenLog] RakPeer::setServerRuppStemma %s",
                      v7);
    }
  }
  return result; /*0x1039d0968*/
}

// Address: 0x1039d0992 | Name: __ZN6RakNet7RakPeer23setServerMachineAddressERKNS_13SystemAddressE
int *__fastcall RakNet::RakPeer::setServerMachineAddress(RakNet::RakPeer *this, const RakNet::SystemAddress *a2)
{
  RakNet::SystemAddress *v3; // r14
  char *v4; // rbx
  int *result; // rax
  _BYTE v6[16]; // [rsp+10h] [rbp-30h] BYREF
  __int64 v7; // [rsp+20h] [rbp-20h]
  _BYTE *v8; // [rsp+28h] [rbp-18h]

  v3 = (RakNet::RakPeer *)((char *)this + 100); /*0x1039d09a0*/
  RakNet::SystemAddress::operator=(a1: (char *)this + 100, a2); /*0x1039d09a7*/
  RakNet::SystemAddress::ConvertToIpV6(this: v3); /*0x1039d09af*/
  v4 = (char *)this + 36; /*0x1039d09b4*/
  RakNet::SystemAddress::ToStringN(this: v3, a2: false, a3: v4, a4: 64, a5: 124); /*0x1039d09cb*/
  result = &DFLog::RuppTokenLog; /*0x1039d09d0*/
  if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && (DFLog::RuppTokenLog & 0xFC00) != 0 ) /*0x1039d09e7*/
  {
    v7 = 12; /*0x1039d09f9*/
    v8 = v6; /*0x1039d0a01*/
    return (int *)FLog::detail::FastLogSafeFormattedInternal( /*0x1039d0a25*/
                    a1: DFLog::RuppTokenLog,
                    a2: qword_10D7B48E0,
                    a3: 4,
                    a4: (unsigned int)"[DFLog::RuppTokenLog] RakPeer::setServerMachineAddress {}",
                    a5: 57,
                    a6: 1,
                    12,
                    v6,
                    v4);
  }
  return result; /*0x1039d0a2a*/
}

// Address: 0x1039d0a34 | Name: __ZN6RakNet7RakPeer13setServerPortEt
__int64 __fastcall RakNet::RakPeer::setServerPort(RakNet::RakPeer *this, unsigned __int16 a2)
{
  return RakNet::SystemAddress::SetPort(this: (RakNet::RakPeer *)((char *)this + 100), a2); /*0x1039d0a3c*/
}

// Address: 0x1039d0a42 | Name: __ZN6RakNet7RakPeer16setEarlyAuthDataENSt3__110shared_ptrIN3RBX8Security13EarlyAuthDataEEE
__int64 __fastcall RakNet::RakPeer::setEarlyAuthData(__int64 a1, __int64 a2)
{
  return std::shared_ptr<RBX::Security::EarlyAuthData>::operator=[abi:ne200100](a1: a1 + 3128, a2); /*0x1039d0a4d*/
}

// Address: 0x1039d0a54 | Name: __ZN6RakNet7RakPeer13setPreauthKeyERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall RakNet::RakPeer::setPreauthKey(__int64 a1, __int64 a2)
{
  return std::string::operator=(a1: a1 + 3040, a2); /*0x1039d0a5f*/
}

// Address: 0x1039d0a66 | Name: __ZN6RakNet7RakPeer8setJobIdERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall RakNet::RakPeer::setJobId(__int64 a1, __int64 a2)
{
  return std::string::operator=(a1: a1 + 2984, a2); /*0x1039d0a71*/
}

// Address: 0x1039d0a78 | Name: __ZN6RakNet7RakPeer38getPacketsPerPeerOneCycleStatsAndResetERfRiS2_
__int64 __fastcall RakNet::RakPeer::getPacketsPerPeerOneCycleStatsAndReset(
        RakNet::RakPeer *this,
        float *a2,
        int *a3,
        int *a4)
{
  if ( *((_DWORD *)this + 874) != 0 ) /*0x1039d0a89*/
    *a2 = (float)(int)(*((_QWORD *)this + 436) / *((int *)this + 874)); /*0x1039d0a9c*/
  *a3 = *((_DWORD *)this + 875); /*0x1039d0aa6*/
  *a4 = *((_DWORD *)this + 876); /*0x1039d0aaf*/
  *((_QWORD *)this + 436) = 0; /*0x1039d0ab1*/
  *((_QWORD *)this + 437) = 0x7FFFFFFF00000000LL; /*0x1039d0ac6*/
  *((_DWORD *)this + 876) = 0x80000000; /*0x1039d0acd*/
  return 0x7FFFFFFF00000000LL; /*0x1039d0ad7*/
}

// Address: 0x1039d0b34 | Name: __ZN6RakNet7RakPeer19setDisconnectReasonENS_13SystemAddressEj
void __fastcall RakNet::RakPeer::setDisconnectReason(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 2016) = a2; /*0x1039d0b38*/
}

// Address: 0x1039d0b40 | Name: __ZN6RakNet7RakPeer19getDisconnectReasonEv
__int64 __fastcall RakNet::RakPeer::getDisconnectReason(RakNet::RakPeer *this)
{
  return *((unsigned int *)this + 504); /*0x1039d0b4a*/
}

// Address: 0x1039d0b4c | Name: __ZN6RakNet7RakPeer11setIsServerEb
void __fastcall RakNet::RakPeer::setIsServer(RakNet::RakPeer *this, char a2)
{
  *((_BYTE *)this + 3728) = a2; /*0x1039d0b50*/
  *((_BYTE *)this + 3729) = a2; /*0x1039d0b57*/
}

// Address: 0x1039d0b60 | Name: __ZN6RakNet7RakPeer47sendServerTokenGenerateTimeTelemetry_deprecatedEyy
__int64 __fastcall RakNet::RakPeer::sendServerTokenGenerateTimeTelemetry_deprecated(RakNet::RakPeer *this, __int64 a2)
{
  unsigned __int64 v2; // rbx
  __int64 v3; // rdx
  __int64 v4; // rcx
  _BYTE v6[16]; // [rsp+0h] [rbp-250h] BYREF
  void *v7; // [rsp+10h] [rbp-240h]
  void *v8[9]; // [rsp+18h] [rbp-238h] BYREF
  _BYTE v9[472]; // [rsp+60h] [rbp-1F0h] BYREF

  if ( a2 != 0 ) /*0x1039d0b96*/
  {
    v2 = ((unsigned __int64)this - a2) / 0x3E8; /*0x1039d0b9f*/
    if ( DFInt::ReportTimeBetweenTTServerThresholdMS <= (int)v2 ) /*0x1039d0ba9*/
    {
      if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x1039d0bbc*/
                              this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::ReportTimeBetweenTTServerHundredthsPercentage,
                              a2) != 0 )
      {
        RBX::Analytics::InfluxDb::Points::Points( /*0x1039d0bcf*/
          a1: v8,
          a2: (unsigned int)DFInt::ReportTimeBetweenTTServerHundredthsPercentage,
          a3: 0,
          a4: 0);
        RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v8, a2: "TimeMS", a3: v2); /*0x1039d0be4*/
        std::string::basic_string[abi:ne200100]<0>(a1: v6, a2: "TimeBetweenSendTTUpdates", a3: v3, a4: v4); /*0x1039d0bf7*/
        RBX::Analytics::InfluxDb::Points::report( /*0x1039d0c12*/
          a1: v8,
          a2: v6,
          a3: (unsigned int)DFInt::ReportTimeBetweenTTServerHundredthsPercentage,
          a4: 0);
        if ( (v6[0] & 1) != 0 ) /*0x1039d0c1e*/
          operator delete(a1: v7); /*0x1039d0c27*/
        RBX::Analytics::InfluxDb::Points::~Points(this: v8); /*0x1039d0c33*/
      }
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1039d0c46*/
        a1: v8,
        a2: (__int64)&RBX::Telemetry::kServerSentLateTTCounter);
      RBX::Telemetry::FieldsContainer::addField( /*0x1039d0c71*/
        a1: v9,
        a2: "DatacenterId",
        a3: 12,
        a4: RBX::Analytics::datacenterId,
        a5: 1);
      RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v8); /*0x1039d0c7d*/
      RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v9); /*0x1039d0c90*/
      RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v8, a2: (void **)off_10C8C7EB0); /*0x1039d0ca3*/
    }
  }
  return __stack_chk_guard; /*0x1039d0cb8*/
}

// Address: 0x1039d0d12 | Name: __ZNK6RakNet7RakPeer27allocateTracerId_deprecatedEPNS0_18RemoteSystemStructE
__int64 __fastcall RakNet::RakPeer::allocateTracerId_deprecated(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2)
{
  RBX::Network::NetworkTracer *v3; // rdi
  __int64 v4; // rdx
  _BYTE v6[24]; // [rsp+0h] [rbp-40h] BYREF
  _QWORD v7[2]; // [rsp+18h] [rbp-28h] BYREF
  _BYTE v8[17]; // [rsp+2Fh] [rbp-11h] BYREF

  if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039d0d2a*/
    v3 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039d0d2c*/
  else
    v3 = nullptr; /*0x1039d0d32*/
  v7[0] = RBX::Network::NetworkTracer::createTracerObject(this: v3); /*0x1039d0d3d*/
  v7[1] = v4; /*0x1039d0d40*/
  RBX::DenseMapBase<RBX::DenseMap<unsigned long long,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseSetPair<unsigned long long>>,unsigned long long,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseSetPair<unsigned long long>>::try_emplace<RBX::detail::DenseSetEmpty&>( /*0x1039d0d59*/
    a1: v6,
    a2: (char *)a2 + 5336,
    a3: v7,
    a4: v8);
  return v7[0]; /*0x1039d0d61*/
}

// Address: 0x1039d0d6a | Name: __ZNK6RakNet7RakPeer29deallocateTracerId_deprecatedEPNS0_18RemoteSystemStructEy
__int64 __fastcall RakNet::RakPeer::deallocateTracerId_deprecated(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2,
        unsigned __int64 a3)
{
  RBX::Network::NetworkTracer *v4; // rdi
  unsigned __int64 v6; // [rsp+0h] [rbp-10h] BYREF

  v6 = a3; /*0x1039d0d73*/
  if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039d0d81*/
    v4 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039d0d83*/
  else
    v4 = nullptr; /*0x1039d0d89*/
  RBX::Network::NetworkTracer::removeTracerObject(this: v4, a2: a3); /*0x1039d0d8e*/
  return RBX::DenseMapBase<RBX::DenseMap<unsigned long long,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseSetPair<unsigned long long>>,unsigned long long,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseSetPair<unsigned long long>>::erase( /*0x1039d0daa*/
           a1: (char *)a2 + 5336,
           a2: &v6);
}

// Address: 0x1039d0dae | Name: __ZNK6RakNet7RakPeer25clearTracerIds_deprecatedEPNS0_18RemoteSystemStructE
__int64 __fastcall RakNet::RakPeer::clearTracerIds_deprecated(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *a2)
{
  char *v2; // rbx
  __int64 v3; // rcx
  unsigned __int64 *i; // r14
  __int64 v5; // rdx
  __int64 v7; // r15
  RBX::Network::NetworkTracer *v8; // rdi

  v2 = (char *)a2 + 5336; /*0x1039d0db8*/
  if ( *((_DWORD *)a2 + 1336) != 0 ) /*0x1039d0dc6*/
  {
    v3 = *((unsigned int *)a2 + 1338); /*0x1039d0dcf*/
    i = *((unsigned __int64 **)a2 + 667); /*0x1039d0dd5*/
    if ( *((_DWORD *)a2 + 1338) != 0 ) /*0x1039d0ddb*/
    {
      v5 = 8 * v3; /*0x1039d0ddd*/
      for ( i = *((unsigned __int64 **)a2 + 667); *i >= 0xFFFFFFFFFFFFFFFELL; ++i ) /*0x1039d0de5*/
      {
        v5 -= 8; /*0x1039d0df2*/
        if ( v5 == 0 ) /*0x1039d0df6*/
          return RBX::DenseMapBase<RBX::DenseMap<unsigned long long,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseSetPair<unsigned long long>>,unsigned long long,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseSetPair<unsigned long long>>::clear( /*0x1039d0df6*/
                   a1: v2,
                   a2: 1);
      }
    }
    v7 = *((_QWORD *)a2 + 667) + 8 * v3; /*0x1039d0e0f*/
    while ( i != (unsigned __int64 *)v7 ) /*0x1039d0e16*/
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039d0e22*/
        v8 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039d0e24*/
      else
        v8 = nullptr; /*0x1039d0e2a*/
      RBX::Network::NetworkTracer::removeTracerObject(this: v8, a2: *i); /*0x1039d0e2f*/
      do /*0x1039d0e41*/
        ++i; /*0x1039d0e34*/
      while ( i != (unsigned __int64 *)v7 && *i >= 0xFFFFFFFFFFFFFFFELL ); /*0x1039d0e41*/
    }
  }
  return RBX::DenseMapBase<RBX::DenseMap<unsigned long long,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseSetPair<unsigned long long>>,unsigned long long,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseSetPair<unsigned long long>>::clear( /*0x1039d0e04*/
           a1: v2,
           a2: 1);
}

// Address: 0x1039d0e46 | Name: __ZNK6RakNet7RakPeer26getTracerPeerId_deprecatedEv
__int64 __fastcall RakNet::RakPeer::getTracerPeerId_deprecated(RakNet::RakPeer *this)
{
  return 2 - (unsigned int)*((unsigned __int8 *)this + 3729); /*0x1039d0e58*/
}

// Address: 0x1039d0e5c | Name: __ZNK6RakNet7RakPeer8IsActiveEv
char __fastcall RakNet::RakPeer::IsActive(RakNet::RakPeer *this)
{
  char v1; // al

  if ( (*((_BYTE *)this + 160) & 1) != 0 ) /*0x1039d0e68*/
    v1 = 0; /*0x1039d0e6a*/
  else
    v1 = *((_BYTE *)this + 162) ^ 1; /*0x1039d0e74*/
  return v1 & 1; /*0x1039d0e78*/
}

// Address: 0x1039d0e7a | Name: __ZN6RakNet7RakPeer20setProfilerLocalInfoEi
void __fastcall RakNet::RakPeer::setProfilerLocalInfo(RakNet::RakPeer *this, int a2)
{
  *((_DWORD *)this + 194) = a2; /*0x1039d0e7e*/
}

// Address: 0x1039d0e86 | Name: __ZN6RakNet7RakPeer17setProfilerPeerIdEij
__int64 __fastcall RakNet::RakPeer::setProfilerPeerId(RakNet::RakPeer *this, unsigned int a2, int a3)
{
  __int64 result; // rax

  if ( (a2 & 0x80000000) == 0 ) /*0x1039d0e88*/
  {
    result = a2; /*0x1039d0e8a*/
    if ( *((_QWORD *)this + 96) > (unsigned __int64)a2 ) /*0x1039d0e93*/
    {
      result = 4176LL * a2; /*0x1039d0ea0*/
      *(_DWORD *)(*((_QWORD *)this + 95) + result + 4164) = a3; /*0x1039d0ea7*/
      *(_BYTE *)(*((_QWORD *)this + 95) + result + 4168) = 1; /*0x1039d0eb5*/
    }
  }
  return result; /*0x1039d0ebe*/
}

// Address: 0x1039d0ec0 | Name: __ZN6RakNet7RakPeer24setProfilerRemoteFrameIdEii
__int64 __fastcall RakNet::RakPeer::setProfilerRemoteFrameId(RakNet::RakPeer *this, unsigned int a2, int a3)
{
  __int64 result; // rax

  if ( (a2 & 0x80000000) == 0 ) /*0x1039d0ec2*/
  {
    result = a2; /*0x1039d0ec4*/
    if ( *((_QWORD *)this + 96) > (unsigned __int64)a2 ) /*0x1039d0ecd*/
    {
      result = 4176LL * a2; /*0x1039d0eda*/
      *(_DWORD *)(*((_QWORD *)this + 95) + result + 4160) = a3; /*0x1039d0ee1*/
    }
  }
  return result; /*0x1039d0ee9*/
}

// Address: 0x1039d0eea | Name: __ZN6RakNet7RakPeer25setServerReceiveRuppTokenEb
void __fastcall RakNet::RakPeer::setServerReceiveRuppToken(RakNet::RakPeer *this, char a2)
{
  *((_BYTE *)this + 133) = a2; /*0x1039d0eee*/
}

// Address: 0x1039d0ef8 | Name: __ZNK6RakNet7RakPeer25getServerReceiveRuppTokenEv
char __fastcall RakNet::RakPeer::getServerReceiveRuppToken(RakNet::RakPeer *this)
{
  return *((_BYTE *)this + 133); /*0x1039d0f02*/
}

// Address: 0x1039d0f04 | Name: __ZN6RakNet7RakPeer13getRuppHeaderEv
RakNet::RakPeer *__fastcall RakNet::RakPeer::getRuppHeader(RakNet::RakPeer *this, __int64 a2)
{
  RakNet::RakPeer *result; // rax
  __int64 v3; // rcx

  result = this; /*0x1039d0f04*/
  v3 = *(_QWORD *)(a2 + 3304); /*0x1039d0f07*/
  *(_OWORD *)this = *(_OWORD *)(a2 + 3296); /*0x1039d0f15*/
  if ( v3 != 0 ) /*0x1039d0f1b*/
    _InterlockedIncrement64((volatile signed __int64 *)(v3 + 8)); /*0x1039d0f21*/
  return result; /*0x1039d0f27*/
}

// Address: 0x1039d0f28 | Name: __ZN6RakNet7RakPeer18setServerLogPrefixENSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall RakNet::RakPeer::setServerLogPrefix(__int64 a1, __int64 a2)
{
  return std::string::operator=(a1: a1 + 3008, a2); /*0x1039d0f33*/
}

// Address: 0x1039d0f3a | Name: __ZN6RakNet7RakPeer9setUserIdEj
void __fastcall RakNet::RakPeer::setUserId(RakNet::RakPeer *this, int a2)
{
  *((_DWORD *)this + 758) = a2; /*0x1039d0f3e*/
}

// Address: 0x1039d0f46 | Name: __ZN6RakNet7RakPeer20overrideCapabilitiesEy
void __fastcall RakNet::RakPeer::overrideCapabilities(RakNet::RakPeer *this, __int64 a2)
{
  *((_QWORD *)this + 387) = a2; /*0x1039d0f4a*/
}

// Address: 0x1039d0f54 | Name: __ZN6RakNet7RakPeer25setCapabilityBitOverridesEy
void __fastcall RakNet::RakPeer::setCapabilityBitOverrides(RakNet::RakPeer *this, __int64 a2)
{
  *((_QWORD *)this + 388) = a2; /*0x1039d0f58*/
}

// Address: 0x1039d0f62 | Name: __ZN6RakNet7RakPeer22setCapabilityBitClearsEy
void __fastcall RakNet::RakPeer::setCapabilityBitClears(RakNet::RakPeer *this, __int64 a2)
{
  *((_QWORD *)this + 389) = a2; /*0x1039d0f66*/
}

// Address: 0x108669905 | Name: __ZN6RakNet7RakPeer13GetStatisticsENS_13SystemAddressEPNS_16RakNetStatisticsE.cold.1
void __fastcall RakNet::RakPeer::GetStatistics(__int64 a1)
{
  char *v1; // rbx
  __int64 i; // r14
  char *v3; // rdi

  v1 = (char *)(a1 + 184); /*0x10866990f*/
  for ( i = -128; i != 0; i += 32 ) /*0x108669918*/
  {
    v3 = *((char **)v1 - 3); /*0x10866991a*/
    if ( v1 != v3 ) /*0x108669921*/
      operator delete(a1: v3); /*0x108669923*/
    v1 -= 32; /*0x108669928*/
  }
}

// Address: 0x108669937 | Name: __ZN6RakNet7RakPeer22HandleActiveSystemListERNS_9BitStreamERyS3_.cold.1
void __fastcall RakNet::RakPeer::HandleActiveSystemList(
        RakNet::RakPeer *this,
        RakNet::BitStream *a2,
        unsigned __int64 *a3,
        unsigned __int64 *a4)
{
  char *v4; // rbx
  __int64 i; // r14
  char *v6; // rdi

  v4 = (char *)this + 184; /*0x108669941*/
  for ( i = -128; i != 0; i += 32 ) /*0x10866994a*/
  {
    v6 = *((char **)v4 - 3); /*0x10866994c*/
    if ( v4 != v6 ) /*0x108669953*/
      operator delete(a1: v6); /*0x108669955*/
    v4 -= 32; /*0x10866995a*/
  }
}

// END RakPeer part 1/1, 251 functions
