// LegacyStatsCollector -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 32 functions


// Address: 0x103d78668 | Name: __ZN6webrtc20LegacyStatsCollectorC2EPNS_22PeerConnectionInternalERNS_5ClockE
__int64 __fastcall webrtc::LegacyStatsCollector::LegacyStatsCollector(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v6; // rax
  __int64 result; // rax

  *(_QWORD *)a1 = off_10C91F938; /*0x103d78686*/
  webrtc::StatsCollection::StatsCollection(this: (webrtc::StatsCollection *)(a1 + 8)); /*0x103d78690*/
  *(_OWORD *)(a1 + 48) = 0; /*0x103d786a4*/
  *(_QWORD *)(a1 + 40) = a1 + 48; /*0x103d786a9*/
  *(_QWORD *)(a1 + 64) = a2; /*0x103d786ad*/
  *(_QWORD *)(a1 + 72) = a3; /*0x103d786b1*/
  *(_OWORD *)(a1 + 80) = 0; /*0x103d786b5*/
  v6 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a2 + 8) + 272LL))(a1: a2 + 8); /*0x103d786c5*/
  result = webrtc::FieldTrialsView::IsEnabled(a1: v6, a2: (__int64)"WebRTC-UseStandardBytesStats", a3: 28); /*0x103d786da*/
  *(_BYTE *)(a1 + 96) = result; /*0x103d786df*/
  *(_OWORD *)(a1 + 104) = 0; /*0x103d786e6*/
  *(_QWORD *)(a1 + 120) = 0; /*0x103d786eb*/
  return result; /*0x103d786f7*/
}

// Address: 0x103d78724 | Name: __ZN6webrtc20LegacyStatsCollectorC1EPNS_22PeerConnectionInternalERNS_5ClockE
__int64 __fastcall webrtc::LegacyStatsCollector::LegacyStatsCollector(__int64 a1, __int64 a2, __int64 a3)
{
  return webrtc::LegacyStatsCollector::LegacyStatsCollector(a1, a2, a3); /*0x103d78728*/
}

// Address: 0x103d7872e | Name: __ZN6webrtc20LegacyStatsCollectorD2Ev
void __fastcall webrtc::LegacyStatsCollector::~LegacyStatsCollector(webrtc::LegacyStatsCollector *this)
{
  void *v2; // rdi

  *(_QWORD *)this = off_10C91F938; /*0x103d7873e*/
  v2 = *((void **)this + 13); /*0x103d78741*/
  if ( v2 != nullptr ) /*0x103d78748*/
  {
    *((_QWORD *)this + 14) = v2; /*0x103d7874a*/
    operator delete(a1: v2); /*0x103d7874e*/
  }
  std::__tree<std::__value_type<std::string,webrtc::StatsReport *>,std::__map_value_compare<std::string,std::__value_type<std::string,webrtc::StatsReport *>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,webrtc::StatsReport *>>>::destroy( /*0x103d7875b*/
    a1: (char *)this + 40,
    a2: *((_QWORD *)this + 6));
  webrtc::StatsCollection::~StatsCollection(this: (webrtc::LegacyStatsCollector *)((char *)this + 8)); /*0x103d7876d*/
}

// Address: 0x103d78774 | Name: __ZN6webrtc20LegacyStatsCollectorD1Ev
void __fastcall webrtc::LegacyStatsCollector::~LegacyStatsCollector(webrtc::LegacyStatsCollector *this)
{
  webrtc::LegacyStatsCollector::~LegacyStatsCollector(this); /*0x103d78779*/
}

// Address: 0x103d7877e | Name: __ZN6webrtc20LegacyStatsCollectorD0Ev
void __fastcall webrtc::LegacyStatsCollector::~LegacyStatsCollector(webrtc::LegacyStatsCollector *this)
{
  webrtc::LegacyStatsCollector::~LegacyStatsCollector(this); /*0x103d78787*/
  operator delete(a1: this); /*0x103d78795*/
}

// Address: 0x103d7879a | Name: __ZN6webrtc20LegacyStatsCollector10GetTimeNowEv
double __fastcall webrtc::LegacyStatsCollector::GetTimeNow(webrtc::LegacyStatsCollector *this)
{
  return (double)(int)webrtc::TimeUTCMillis(this); /*0x103d787a8*/
}

// Address: 0x103d787aa | Name: __ZN6webrtc20LegacyStatsCollector9AddStreamEPNS_20MediaStreamInterfaceE
__int64 __fastcall webrtc::LegacyStatsCollector::AddStream(__int64 a1, __int64 a2)
{
  __int64 v4; // r14
  __int64 v5; // rbx
  _QWORD *v6; // r13
  _QWORD *v7; // r12
  _QWORD *v8; // r15
  _QWORD *v9; // r13
  _QWORD v11[3]; // [rsp+8h] [rbp-48h] BYREF
  _QWORD *v12; // [rsp+20h] [rbp-30h]

  (*(void (__fastcall **)(_QWORD *))(*(_QWORD *)a2 + 40LL))(a1: v11); /*0x103d787cb*/
  v4 = a1 + 8; /*0x103d787ce*/
  v5 = a1 + 40; /*0x103d787d2*/
  v6 = (_QWORD *)v11[0]; /*0x103d787d6*/
  v7 = (_QWORD *)v11[1]; /*0x103d787da*/
  while ( v6 != v7 ) /*0x103d787e2*/
    webrtc::`anonymous namespace'::CreateTrackReport<webrtc::AudioTrackInterface>(a1: *v6++, a2: v4, a3: v5); /*0x103d787ee*/
  v12 = v11; /*0x103d78801*/
  std::vector<webrtc::scoped_refptr<webrtc::AudioTrackInterface>>::__destroy_vector::operator()[abi:ne200100](); /*0x103d78804*/
  (*(void (__fastcall **)(_QWORD *, __int64))(*(_QWORD *)a2 + 48LL))(a1: v11, a2); /*0x103d78816*/
  v8 = (_QWORD *)v11[0]; /*0x103d78819*/
  v9 = (_QWORD *)v11[1]; /*0x103d7881d*/
  while ( v8 != v9 ) /*0x103d78825*/
    webrtc::`anonymous namespace'::CreateTrackReport<webrtc::VideoTrackInterface>(a1: *v8++, a2: v4, a3: v5); /*0x103d78830*/
  v12 = v11; /*0x103d7883f*/
  return std::vector<webrtc::scoped_refptr<webrtc::VideoTrackInterface>>::__destroy_vector::operator()[abi:ne200100](); /*0x103d78847*/
}

// Address: 0x103d78882 | Name: __ZN6webrtc20LegacyStatsCollector8AddTrackEPNS_25MediaStreamTrackInterfaceE
void __fastcall webrtc::LegacyStatsCollector::AddTrack(__int64 a1, __int64 a2)
{
  size_t v4; // rax
  void *v5; // r12
  int v6; // r15d
  size_t v7; // rax
  void *v8; // r12
  int v9; // r15d
  unsigned __int8 v10; // [rsp+8h] [rbp-38h] BYREF
  _BYTE __s1[7]; // [rsp+9h] [rbp-37h] BYREF
  __int64 v12; // [rsp+10h] [rbp-30h]
  void *v13; // [rsp+18h] [rbp-28h]

  (*(void (__fastcall **)(unsigned __int8 *))(*(_QWORD *)a2 + 32LL))(a1: &v10); /*0x103d788a1*/
  v4 = strlen(__s: webrtc::MediaStreamTrackInterface::kAudioKind); /*0x103d788b1*/
  if ( (v10 & 1) != 0 ) /*0x103d788be*/
  {
    if ( v4 == v12 ) /*0x103d788e0*/
    {
      if ( v4 == -1 ) /*0x103d788e6*/
        std::string::__throw_out_of_range[abi:ne200100](); /*0x103d789d0*/
      v5 = v13; /*0x103d788ec*/
      v6 = memcmp(__s1: v13, __s2: webrtc::MediaStreamTrackInterface::kAudioKind, __n: v4); /*0x103d788fe*/
      operator delete(a1: v5); /*0x103d78904*/
      if ( v6 == 0 ) /*0x103d7890c*/
        goto LABEL_8; /*0x103d7890c*/
    }
    else
    {
      operator delete(a1: v13); /*0x103d7892a*/
    }
  }
  else if ( v4 == v10 >> 1 && memcmp(__s1, __s2: webrtc::MediaStreamTrackInterface::kAudioKind, __n: v4) == 0 ) /*0x103d788d8*/
  {
LABEL_8:
    webrtc::`anonymous namespace'::CreateTrackReport<webrtc::AudioTrackInterface>(a1: a2, a2: a1 + 8, a3: a1 + 40); /*0x103d7890e*/
    return; /*0x103d78921*/
  }
  (*(void (__fastcall **)(unsigned __int8 *, __int64))(*(_QWORD *)a2 + 32LL))(a1: &v10, a2); /*0x103d7893c*/
  v7 = strlen(__s: webrtc::MediaStreamTrackInterface::kVideoKind[0]); /*0x103d7894c*/
  if ( (v10 & 1) != 0 ) /*0x103d78959*/
  {
    if ( v7 == v12 ) /*0x103d7897b*/
    {
      if ( v7 == -1 ) /*0x103d78981*/
        std::string::__throw_out_of_range[abi:ne200100](); /*0x103d789d7*/
      v8 = v13; /*0x103d78983*/
      v9 = memcmp(__s1: v13, __s2: webrtc::MediaStreamTrackInterface::kVideoKind[0], __n: v7); /*0x103d78995*/
      operator delete(a1: v8); /*0x103d7899b*/
      if ( v9 == 0 ) /*0x103d789a3*/
        goto LABEL_17; /*0x103d789a3*/
    }
    else
    {
      operator delete(a1: v13); /*0x103d789be*/
    }
  }
  else if ( v7 == v10 >> 1 && memcmp(__s1, __s2: webrtc::MediaStreamTrackInterface::kVideoKind[0], __n: v7) == 0 ) /*0x103d78973*/
  {
LABEL_17:
    webrtc::`anonymous namespace'::CreateTrackReport<webrtc::VideoTrackInterface>(a1: a2, a2: a1 + 8, a3: a1 + 40); /*0x103d789a5*/
  }
}

// Address: 0x103d78af4 | Name: __ZN6webrtc20LegacyStatsCollector18AddLocalAudioTrackEPNS_19AudioTrackInterfaceEj
void __fastcall webrtc::LegacyStatsCollector::AddLocalAudioTrack(
        webrtc::LegacyStatsCollector *this,
        webrtc::AudioTrackInterface *a2,
        int a3)
{
  char *v5; // r14
  __int64 inserted; // r14
  webrtc::AudioTrackInterface *v7; // [rsp+8h] [rbp-38h] BYREF
  int v8; // [rsp+10h] [rbp-30h]
  void *v9; // [rsp+18h] [rbp-28h]
  _QWORD v10[4]; // [rsp+20h] [rbp-20h] BYREF

  v7 = a2; /*0x103d78b0f*/
  v8 = a3; /*0x103d78b12*/
  std::vector<std::pair<webrtc::AudioTrackInterface *,unsigned int>>::push_back[abi:ne200100](a1: (char *)this + 104); /*0x103d78b15*/
  (*(void (__fastcall **)(webrtc::AudioTrackInterface **, webrtc::AudioTrackInterface *))(*(_QWORD *)a2 + 40LL))( /*0x103d78b27*/
    a1: &v7,
    a2);
  webrtc::StatsReport::NewTypedId(a1: v10, a2: 7, a3: &v7); /*0x103d78b36*/
  if ( ((unsigned __int8)v7 & 1) != 0 ) /*0x103d78b3f*/
    operator delete(a1: v9); /*0x103d78b45*/
  v5 = (char *)this + 8; /*0x103d78b4a*/
  if ( webrtc::StatsCollection::Find(a1: v5, a2: v10) == 0 ) /*0x103d78b5d*/
  {
    inserted = webrtc::StatsCollection::InsertNew(a1: v5, a2: v10); /*0x103d78b6b*/
    (*(void (__fastcall **)(webrtc::AudioTrackInterface **, webrtc::AudioTrackInterface *))(*(_QWORD *)a2 + 40LL))( /*0x103d78b78*/
      a1: &v7,
      a2);
    webrtc::StatsReport::AddString(a1: inserted, a2: 135, a3: &v7); /*0x103d78b87*/
    if ( ((unsigned __int8)v7 & 1) != 0 ) /*0x103d78b90*/
      operator delete(a1: v9); /*0x103d78b96*/
  }
  if ( v10[0] != 0 ) /*0x103d78ba2*/
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)v10[0] + 8LL))(a1: v10[0]); /*0x103d78ba7*/
}

// Address: 0x103d78cfa | Name: __ZN6webrtc20LegacyStatsCollector21RemoveLocalAudioTrackEPNS_19AudioTrackInterfaceEj
__int64 __fastcall webrtc::LegacyStatsCollector::RemoveLocalAudioTrack(
        webrtc::LegacyStatsCollector *this,
        webrtc::AudioTrackInterface *a2,
        int a3)
{
  __int64 result; // rax
  __int64 v4; // rcx
  __int64 v5; // r8
  int v6; // r10d

  result = *((_QWORD *)this + 13); /*0x103d78cfe*/
  v4 = *((_QWORD *)this + 14); /*0x103d78d02*/
  while ( result != v4 && (*(webrtc::AudioTrackInterface **)result != a2 || *(_DWORD *)(result + 8) != a3) ) /*0x103d78d13*/
    result += 16; /*0x103d78d15*/
  v5 = result + 16; /*0x103d78d22*/
  if ( result != v4 && result + 16 != v4 ) /*0x103d78d29*/
  {
    while ( *(webrtc::AudioTrackInterface **)v5 == a2 ) /*0x103d78d38*/
    {
      v6 = *(_DWORD *)(v5 + 8); /*0x103d78d40*/
      if ( v6 != a3 ) /*0x103d78d47*/
        goto LABEL_10; /*0x103d78d47*/
LABEL_11:
      v5 += 16; /*0x103d78d54*/
      if ( v5 == v4 ) /*0x103d78d5b*/
        goto LABEL_12; /*0x103d78d5b*/
    }
    v6 = *(_DWORD *)(v5 + 8); /*0x103d78d3a*/
LABEL_10:
    *(_QWORD *)result = *(_QWORD *)v5; /*0x103d78d49*/
    *(_DWORD *)(result + 8) = v6; /*0x103d78d4c*/
    result += 16; /*0x103d78d50*/
    goto LABEL_11; /*0x103d78d50*/
  }
LABEL_12:
  if ( result != v4 ) /*0x103d78d60*/
    *((_QWORD *)this + 14) = result; /*0x103d78d9c*/
  return result; /*0x103d78da0*/
}

// Address: 0x103d78da2 | Name: __ZN6webrtc20LegacyStatsCollector8GetStatsEPNS_25MediaStreamTrackInterfaceEPNSt3__16vectorIPKNS_11StatsReportENS3_9allocatorIS7_EEEE
void __fastcall webrtc::LegacyStatsCollector::GetStats(__int64 a1, __int64 a2, __int64 a3)
{
  webrtc::StatsCollection *v6; // r15
  __int64 v7; // r12
  __int64 v8; // r12
  __int64 v9; // r15
  webrtc::StatsReport::Value *Value; // rax
  unsigned __int8 *v11; // r13
  unsigned int v12; // eax
  size_t v13; // rdx
  char v14; // r14
  __int64 v15; // rcx
  const void *v16; // r13
  bool v17; // r13
  char *v18; // rsi
  webrtc::StatsCollection *v19; // r15
  __int64 v20; // rax
  __int64 v21; // r14
  __int64 i; // r15
  _BYTE v23[16]; // [rsp+8h] [rbp-68h] BYREF
  __int64 v24; // [rsp+18h] [rbp-58h]
  __int64 v25; // [rsp+20h] [rbp-50h] BYREF
  _QWORD v26[2]; // [rsp+28h] [rbp-48h] BYREF
  void *__s2; // [rsp+38h] [rbp-38h]
  _QWORD v28[6]; // [rsp+40h] [rbp-30h] BYREF

  webrtc::Thread::ScopedDisallowBlockingCalls::ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v23); /*0x103d78dc0*/
  v24 = a2; /*0x103d78dc5*/
  if ( a2 != 0 ) /*0x103d78dcc*/
  {
    (*(void (__fastcall **)(_QWORD *, __int64))(*(_QWORD *)(*(_QWORD *)(a1 + 64) + 8LL) + 16LL))( /*0x103d78de2*/
      a1: v26,
      a2: *(_QWORD *)(a1 + 64) + 8LL);
    webrtc::StatsReport::NewTypedId(a1: v28, a2: 0, a3: v26); /*0x103d78def*/
    v6 = (webrtc::StatsCollection *)(a1 + 8); /*0x103d78df4*/
    v7 = webrtc::StatsCollection::Find(a1: v6, a2: v28); /*0x103d78e04*/
    if ( v28[0] != 0 ) /*0x103d78e0e*/
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)v28[0] + 8LL))(a1: v28[0]); /*0x103d78e13*/
    if ( (v26[0] & 1) != 0 ) /*0x103d78e1a*/
      operator delete(a1: __s2); /*0x103d78e20*/
    v25 = v7; /*0x103d78e25*/
    if ( v7 != 0 ) /*0x103d78e2c*/
      std::vector<webrtc::StatsReport const*>::push_back[abi:ne200100](a1: a3, a2: &v25); /*0x103d78e35*/
    (*(void (__fastcall **)(_QWORD *))(*(_QWORD *)v24 + 40LL))(a1: v26); /*0x103d78e45*/
    webrtc::StatsReport::NewTypedId(a1: v28, a2: 7, a3: v26); /*0x103d78e55*/
    v25 = webrtc::StatsCollection::Find(a1: v6, a2: v28); /*0x103d78e66*/
    if ( v28[0] != 0 ) /*0x103d78e71*/
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)v28[0] + 8LL))(a1: v28[0]); /*0x103d78e76*/
    if ( (v26[0] & 1) != 0 ) /*0x103d78e7d*/
      operator delete(a1: __s2); /*0x103d78e83*/
    if ( v25 != 0 ) /*0x103d78e8d*/
    {
      std::vector<webrtc::StatsReport const*>::push_back[abi:ne200100](a1: a3, a2: &v25); /*0x103d78e9a*/
      v8 = webrtc::StatsCollection::begin(this: v6); /*0x103d78ea7*/
      v9 = webrtc::StatsCollection::end(this: v6); /*0x103d78eb2*/
      while ( v8 != v9 ) /*0x103d78eb8*/
      {
        v28[0] = *(_QWORD *)(v8 + 16); /*0x103d78ec3*/
        if ( (unsigned int)webrtc::StatsReport::IdBase::type(this: *(webrtc::StatsReport::IdBase **)v28[0]) == 5 ) /*0x103d78ed2*/
        {
          Value = (webrtc::StatsReport::Value *)webrtc::StatsReport::FindValue(a1: v28[0], a2: 135); /*0x103d78ee1*/
          if ( Value != nullptr ) /*0x103d78ee9*/
          {
            v11 = (unsigned __int8 *)webrtc::StatsReport::Value::string_val(this: Value); /*0x103d78ef7*/
            (*(void (__fastcall **)(_QWORD *))(*(_QWORD *)v24 + 40LL))(a1: v26); /*0x103d78f05*/
            v12 = *v11; /*0x103d78f08*/
            if ( (v12 & 1) != 0 ) /*0x103d78f0f*/
              v13 = *((_QWORD *)v11 + 1); /*0x103d78f11*/
            else
              v13 = v12 >> 1; /*0x103d78f19*/
            v14 = v26[0]; /*0x103d78f1b*/
            if ( (v26[0] & 1) != 0 ) /*0x103d78f24*/
              v15 = v26[1]; /*0x103d78f26*/
            else
              v15 = LOBYTE(v26[0]) >> 1; /*0x103d78f2f*/
            if ( v13 == v15 ) /*0x103d78f34*/
            {
              if ( (v12 & 1) != 0 ) /*0x103d78f38*/
                v16 = *((const void **)v11 + 2); /*0x103d78f3a*/
              else
                v16 = v11 + 1; /*0x103d78f45*/
              v18 = (char *)v26 + 1; /*0x103d78f48*/
              if ( (v26[0] & 1) != 0 ) /*0x103d78f50*/
                v18 = (char *)__s2; /*0x103d78f52*/
              v17 = memcmp(__s1: v16, __s2: v18, __n: v13) == 0; /*0x103d78f60*/
            }
            else
            {
              v17 = false; /*0x103d78f40*/
            }
            if ( (v14 & 1) != 0 ) /*0x103d78f68*/
              operator delete(a1: __s2); /*0x103d78f6e*/
            if ( v17 ) /*0x103d78f76*/
              std::vector<webrtc::StatsReport const*>::push_back[abi:ne200100](a1: a3, a2: v28); /*0x103d78f7f*/
          }
        }
        v8 = *(_QWORD *)(v8 + 8); /*0x103d78f84*/
      }
    }
  }
  else
  {
    v19 = (webrtc::StatsCollection *)(a1 + 8); /*0x103d78f8e*/
    v20 = webrtc::StatsCollection::size(this: v19); /*0x103d78f95*/
    std::vector<webrtc::StatsReport const*>::reserve(a1: a3, a2: v20); /*0x103d78fa0*/
    v21 = webrtc::StatsCollection::begin(this: v19); /*0x103d78fad*/
    for ( i = webrtc::StatsCollection::end(this: v19); v21 != i; v21 = *(_QWORD *)(v21 + 8) ) /*0x103d78fbe*/
    {
      v26[0] = *(_QWORD *)(v21 + 16); /*0x103d78fc8*/
      std::vector<webrtc::StatsReport const*>::push_back[abi:ne200100](a1: a3, a2: v26); /*0x103d78fd2*/
    }
  }
  webrtc::Thread::ScopedDisallowBlockingCalls::~ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v23); /*0x103d78fe4*/
}

// Address: 0x103d791de | Name: __ZN6webrtc20LegacyStatsCollector11UpdateStatsENS_23PeerConnectionInterface16StatsOutputLevelE
webrtc::Clock *__fastcall webrtc::LegacyStatsCollector::UpdateStats(webrtc::Clock **this)
{
  webrtc::Clock *result; // rax
  _QWORD v3[4]; // [rsp+0h] [rbp-20h] BYREF

  result = (webrtc::Clock *)webrtc::Clock::TimeInMilliseconds(this: *(this + 9)); /*0x103d791ee*/
  if ( (__int64)*(this + 10) + 50 <= (__int64)result || *(this + 10) == nullptr ) /*0x103d791fa*/
  {
    *(this + 10) = result; /*0x103d7920b*/
    *((double *)this + 11) = (*((double (__fastcall **)(webrtc::Clock **))*this + 5))(a1: this); /*0x103d79218*/
    webrtc::LegacyStatsCollector::ExtractSessionAndDataInfo(this: (webrtc::LegacyStatsCollector *)v3); /*0x103d79224*/
    webrtc::LegacyStatsCollector::ExtractBweInfo((webrtc::LegacyStatsCollector *)this); /*0x103d7922c*/
    webrtc::LegacyStatsCollector::ExtractMediaInfo(a1: this, a2: v3); /*0x103d79238*/
    webrtc::LegacyStatsCollector::ExtractSenderInfo((webrtc::LegacyStatsCollector *)this); /*0x103d79240*/
    webrtc::LegacyStatsCollector::UpdateTrackReports((webrtc::LegacyStatsCollector *)this); /*0x103d79248*/
    return (webrtc::Clock *)std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy( /*0x103d79255*/
                              a1: v3,
                              a2: v3[1]);
  }
  return result; /*0x103d7925a*/
}

// Address: 0x103d7927a | Name: __ZN6webrtc20LegacyStatsCollector25ExtractSessionAndDataInfoEv
webrtc::LegacyStatsCollector *__fastcall webrtc::LegacyStatsCollector::ExtractSessionAndDataInfo(
        webrtc::LegacyStatsCollector *this,
        webrtc::LegacyStatsCollector *a2)
{
  __int64 v4; // r12
  __int64 v5; // rcx
  __int64 v6; // rdx
  __int64 *v7; // rsi
  _QWORD *v8; // r8
  __int64 v9; // r9
  __int64 v10; // r8
  char *v11; // rax
  __int64 v12; // rcx
  __int64 v13; // rdx
  const char *v15; // rsi
  unsigned __int64 *v16; // [rsp+10h] [rbp-150h]
  _QWORD v17[6]; // [rsp+20h] [rbp-140h] BYREF
  _QWORD *v18; // [rsp+50h] [rbp-110h] BYREF
  _QWORD v19[2]; // [rsp+58h] [rbp-108h] BYREF
  _QWORD *v20; // [rsp+70h] [rbp-F0h] BYREF
  _QWORD v21[2]; // [rsp+78h] [rbp-E8h] BYREF
  _BYTE v22[24]; // [rsp+88h] [rbp-D8h] BYREF
  void *v23[3]; // [rsp+A0h] [rbp-C0h] BYREF
  char v24; // [rsp+B8h] [rbp-A8h]
  char v25[16]; // [rsp+C0h] [rbp-A0h] BYREF
  void *v26; // [rsp+D0h] [rbp-90h]
  char v27; // [rsp+D8h] [rbp-88h]
  _QWORD *v28; // [rsp+E0h] [rbp-80h]
  webrtc::LegacyStatsCollector *v29; // [rsp+E8h] [rbp-78h]
  _BYTE *v30; // [rsp+F0h] [rbp-70h]
  __int64 *v31; // [rsp+F8h] [rbp-68h]
  __int64 v32; // [rsp+100h] [rbp-60h] BYREF
  __int64 *v33; // [rsp+108h] [rbp-58h]
  __int64 v34; // [rsp+110h] [rbp-50h]
  _QWORD v35[2]; // [rsp+118h] [rbp-48h] BYREF
  __int64 v36; // [rsp+128h] [rbp-38h]
  char v37[41]; // [rsp+137h] [rbp-29h] BYREF

  if ( (_BYTE)`guard variable for'webrtc::LegacyStatsCollector::ExtractSessionAndDataInfo(void)::trace_event_unique_catstatic885 == 0 /*0x103d79534*/
    && __cxa_guard_acquire(a1: &`guard variable for'webrtc::LegacyStatsCollector::ExtractSessionAndDataInfo(void)::trace_event_unique_catstatic885) != 0 )
  {
    *(_QWORD *)webrtc::LegacyStatsCollector::ExtractSessionAndDataInfo(void)::trace_event_unique_catstatic885 = webrtc::EventTracer::GetCategoryEnabled(this: (webrtc::EventTracer *)"webrtc", a2: v15); /*0x103d79546*/
    __cxa_guard_release(a1: &`guard variable for'webrtc::LegacyStatsCollector::ExtractSessionAndDataInfo(void)::trace_event_unique_catstatic885); /*0x103d79554*/
  }
  v20 = nullptr; /*0x103d792a2*/
  if ( **(_BYTE **)webrtc::LegacyStatsCollector::ExtractSessionAndDataInfo(void)::trace_event_unique_catstatic885 != 0 ) /*0x103d792b7*/
  {
    LODWORD(v16) = 0; /*0x103d792c0*/
    webrtc::EventTracer::AddTraceEvent( /*0x103d792df*/
      this: (webrtc::EventTracer *)0x42,
      a2: *(__int64 *)webrtc::LegacyStatsCollector::ExtractSessionAndDataInfo(void)::trace_event_unique_catstatic885,
      a3: "LegacyStatsCollector::ExtractSessionAndDataInfo",
      a4: nullptr,
      a5: 0,
      a6: 0,
      a7: nullptr,
      a8: nullptr,
      a9: v16);
    v21[0] = *(_QWORD *)webrtc::LegacyStatsCollector::ExtractSessionAndDataInfo(void)::trace_event_unique_catstatic885; /*0x103d792f2*/
    v21[1] = "LegacyStatsCollector::ExtractSessionAndDataInfo"; /*0x103d792f5*/
    v20 = v21; /*0x103d792f9*/
  }
  *(_OWORD *)v19 = 0; /*0x103d79307*/
  memset(v17, 0, sizeof(v17)); /*0x103d7930c*/
  v18 = v19; /*0x103d7931b*/
  v32 = (__int64)&v32; /*0x103d79323*/
  v33 = &v32; /*0x103d79326*/
  v34 = 0; /*0x103d7932a*/
  (*(void (__fastcall **)(_BYTE *))(**((_QWORD **)a2 + 8) + 552LL))(a1: v22); /*0x103d79340*/
  v4 = (*(__int64 (__fastcall **)(_QWORD *))(**((_QWORD **)a2 + 8) + 528LL))(a1: *((_QWORD **)a2 + 8)); /*0x103d79353*/
  (*(void (__fastcall **)(void **))(**((_QWORD **)a2 + 8) + 568LL))(a1: v23); /*0x103d79364*/
  (*(void (__fastcall **)(char *, __int64))(*(_QWORD *)(*((_QWORD *)a2 + 8) + 8LL) + 32LL))( /*0x103d7937d*/
    a1: v25,
    a2: *((_QWORD *)a2 + 8) + 8LL);
  v28 = v17; /*0x103d7938e*/
  v29 = a2; /*0x103d79392*/
  v30 = v22; /*0x103d7939d*/
  v31 = &v32; /*0x103d793a1*/
  (*(void (__fastcall **)(__int64, void **, __int64 (__fastcall *)(), char *))(*(_QWORD *)v4 + 96LL))( /*0x103d793b7*/
    a1: v4,
    a2: v23,
    a3: webrtc::FunctionView<void ()(void)>::CallVoidPtr<webrtc::LegacyStatsCollector::ExtractSessionAndDataInfo(void)::$_0>,
    a4: v37);
  if ( v27 == 1 && (v25[0] & 1) != 0 ) /*0x103d793ca*/
    operator delete(a1: v26); /*0x103d793d3*/
  if ( v24 == 1 && ((__int64)v23[0] & 1) != 0 ) /*0x103d793e8*/
    operator delete(a1: v23[2]); /*0x103d793f1*/
  v35[0] = v35; /*0x103d793fe*/
  v35[1] = v35; /*0x103d79401*/
  v36 = 0; /*0x103d79405*/
  v5 = v34; /*0x103d7940d*/
  if ( v34 != 0 ) /*0x103d79414*/
  {
    v6 = v32; /*0x103d79416*/
    v7 = v33; /*0x103d7941a*/
    v8 = *(_QWORD **)(v32 + 8); /*0x103d7941e*/
    v9 = *v33; /*0x103d79422*/
    *(_QWORD *)(v9 + 8) = v8; /*0x103d79425*/
    *v8 = v9; /*0x103d79429*/
    v10 = v35[0]; /*0x103d7942c*/
    *(_QWORD *)(v35[0] + 8LL) = v7; /*0x103d79430*/
    *v7 = v10; /*0x103d79434*/
    v35[0] = v6; /*0x103d79437*/
    *(_QWORD *)(v6 + 8) = v35; /*0x103d7943b*/
    v36 = v5; /*0x103d7943f*/
    v34 = 0; /*0x103d79443*/
  }
  webrtc::StatsCollection::MergeCollection(a1: (char *)a2 + 8, a2: v35); /*0x103d7944f*/
  std::__list_imp<webrtc::StatsReport *>::clear(a1: v35); /*0x103d79458*/
  webrtc::LegacyStatsCollector::ExtractSessionInfo_s(this: a2, a2: (webrtc::LegacyStatsCollector::SessionStats *)v17); /*0x103d7946a*/
  *(_QWORD *)this = v18; /*0x103d79479*/
  v11 = (char *)this + 8; /*0x103d7947c*/
  v12 = v19[0]; /*0x103d79480*/
  *((_QWORD *)this + 1) = v19[0]; /*0x103d79484*/
  v13 = v19[1]; /*0x103d79488*/
  *((_QWORD *)this + 2) = v19[1]; /*0x103d7948c*/
  if ( v13 != 0 ) /*0x103d79493*/
  {
    *(_QWORD *)(v12 + 16) = v11; /*0x103d79495*/
    v18 = v19; /*0x103d79499*/
    *(_OWORD *)v19 = 0; /*0x103d794a3*/
  }
  else
  {
    *(_QWORD *)this = v11; /*0x103d794aa*/
  }
  v23[0] = v22; /*0x103d794bb*/
  std::vector<webrtc::scoped_refptr<webrtc::RtpTransceiverProxyWithInternal<webrtc::RtpTransceiver>>>::__destroy_vector::operator()[abi:ne200100](a1: v23); /*0x103d794c2*/
  std::__list_imp<webrtc::StatsReport *>::clear(a1: &v32); /*0x103d794cb*/
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy( /*0x103d794de*/
    a1: &v18,
    a2: v19[0]);
  v23[0] = &v17[3]; /*0x103d794e3*/
  std::vector<webrtc::LegacyStatsCollector::TransportStats>::__destroy_vector::operator()[abi:ne200100](a1: v23); /*0x103d794f1*/
  v23[0] = v17; /*0x103d794f6*/
  std::vector<webrtc::CandidateStats>::__destroy_vector::operator()[abi:ne200100](a1: v23); /*0x103d79500*/
  webrtc::trace_event_internal::TraceEndOnScopeClose::~TraceEndOnScopeClose(this: (webrtc::trace_event_internal::TraceEndOnScopeClose *)&v20); /*0x103d7950c*/
  return this; /*0x103d79514*/
}

// Address: 0x103d79602 | Name: __ZN6webrtc20LegacyStatsCollector14ExtractBweInfoEv
__int64 __fastcall webrtc::LegacyStatsCollector::ExtractBweInfo(webrtc::LegacyStatsCollector *this)
{
  _QWORD *v2; // r13
  _QWORD *v3; // rbx
  __int64 v4; // rdi
  __int64 v5; // rax
  __int64 v6; // r15
  __int64 i; // rbx
  _DWORD v9[4]; // [rsp+8h] [rbp-118h] BYREF
  __int64 v10; // [rsp+18h] [rbp-108h]
  _QWORD *v11; // [rsp+38h] [rbp-E8h] BYREF
  _QWORD *v12; // [rsp+40h] [rbp-E0h]
  int v13; // [rsp+50h] [rbp-D0h] BYREF
  int v14; // [rsp+54h] [rbp-CCh] BYREF
  __int128 v15; // [rsp+58h] [rbp-C8h] BYREF
  __int64 v16; // [rsp+68h] [rbp-B8h]
  void *v17[2]; // [rsp+70h] [rbp-B0h] BYREF
  __int64 v18; // [rsp+80h] [rbp-A0h]
  __int64 v19; // [rsp+88h] [rbp-98h] BYREF
  void **v20; // [rsp+90h] [rbp-90h] BYREF
  int *v21; // [rsp+98h] [rbp-88h]
  int v22; // [rsp+A0h] [rbp-80h]
  int *v23; // [rsp+A8h] [rbp-78h]
  int v24; // [rsp+B0h] [rbp-70h]
  __int128 *v25; // [rsp+B8h] [rbp-68h]
  int v26; // [rsp+C0h] [rbp-60h]
  char *v27; // [rsp+C8h] [rbp-58h]
  int v28; // [rsp+D0h] [rbp-50h]
  char *v29; // [rsp+D8h] [rbp-48h]
  int v30; // [rsp+E0h] [rbp-40h]
  char *v31; // [rsp+E8h] [rbp-38h]

  if ( (*(unsigned int (__fastcall **)(_QWORD))(**((_QWORD **)this + 8) + 424LL))(a1: *((_QWORD *)this + 8)) != 5 ) /*0x103d79637*/
  {
    (*(void (__fastcall **)(_DWORD *))(**((_QWORD **)this + 8) + 592LL))(a1: v9); /*0x103d7964b*/
    v15 = 0; /*0x103d79658*/
    v13 = v9[0]; /*0x103d7966b*/
    v14 = v9[2]; /*0x103d79671*/
    v16 = v10; /*0x103d7967e*/
    (*(void (__fastcall **)(_QWORD **))(**((_QWORD **)this + 8) + 552LL))(a1: &v11); /*0x103d79695*/
    *(_OWORD *)v17 = 0; /*0x103d7969e*/
    v18 = 0; /*0x103d796a5*/
    v2 = v11; /*0x103d796b0*/
    v3 = v12; /*0x103d796b7*/
    if ( v11 != v12 ) /*0x103d796c1*/
    {
      do /*0x103d79717*/
      {
        if ( (*(unsigned int (__fastcall **)(_QWORD))(*(_QWORD *)*v2 + 32LL))(a1: *v2) == 1 ) /*0x103d796e2*/
        {
          v4 = *(_QWORD *)(*(_QWORD *)(*v2 + 16LL) + 200LL); /*0x103d796ec*/
          if ( v4 != 0 ) /*0x103d796f6*/
          {
            v20 = (void **)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 48LL))(a1: v4); /*0x103d796fe*/
            std::vector<webrtc::VideoMediaSendChannelInterface *>::push_back[abi:ne200100](a1: v17, a2: &v20); /*0x103d7970b*/
          }
        }
        ++v2; /*0x103d79710*/
      }
      while ( v2 != v3 ); /*0x103d79717*/
      if ( v17[0] != v17[1] ) /*0x103d7972e*/
      {
        v5 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 8) + 536LL))(a1: *((_QWORD *)this + 8)); /*0x103d79737*/
        v20 = v17; /*0x103d79744*/
        v21 = &v13; /*0x103d7974e*/
        (*(void (__fastcall **)(__int64, void ***, __int64 (__fastcall *)(), __int64 *))(*(_QWORD *)v5 + 96LL))( /*0x103d79766*/
          a1: v5,
          a2: &v20,
          a3: webrtc::FunctionView<void ()(void)>::CallVoidPtr<webrtc::LegacyStatsCollector::ExtractBweInfo(void)::$_0>,
          a4: &v19);
      }
    }
    webrtc::StatsReport::NewBandwidthEstimationId(this: (webrtc::StatsReport *)&v19); /*0x103d79771*/
    v6 = webrtc::StatsCollection::FindOrAddNew(a1: (char *)this + 8, a2: &v19); /*0x103d79786*/
    *(_QWORD *)(v6 + 8) = *((_QWORD *)this + 11); /*0x103d7979d*/
    LODWORD(v20) = 40; /*0x103d797a3*/
    v21 = &v13; /*0x103d797b4*/
    v22 = 39; /*0x103d797bb*/
    v23 = &v14; /*0x103d797c2*/
    v24 = 133; /*0x103d797c6*/
    v25 = &v15; /*0x103d797cd*/
    v26 = 37; /*0x103d797d1*/
    v27 = (char *)&v15 + 4; /*0x103d797df*/
    v28 = 125; /*0x103d797e3*/
    v29 = (char *)&v15 + 8; /*0x103d797f1*/
    v30 = 136; /*0x103d797f5*/
    v31 = (char *)&v15 + 12; /*0x103d79803*/
    for ( i = 1; i != 13; i += 2 ) /*0x103d79807*/
      webrtc::StatsReport::AddInt(a1: v6, a2: *(unsigned int *)((char *)&v19 + i * 8), a3: *(unsigned int *)(&v20)[i]); /*0x103d79820*/
    webrtc::StatsReport::AddInt64(a1: v6, a2: 43, a3: v16); /*0x103d7983e*/
    if ( v19 != 0 ) /*0x103d7984d*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v19 + 8LL))(a1: v19); /*0x103d79852*/
    if ( v17[0] != nullptr ) /*0x103d7985f*/
    {
      v17[1] = v17[0]; /*0x103d79861*/
      operator delete(a1: v17[0]); /*0x103d79868*/
    }
    v20 = (void **)&v11; /*0x103d79874*/
    std::vector<webrtc::scoped_refptr<webrtc::RtpTransceiverProxyWithInternal<webrtc::RtpTransceiver>>>::__destroy_vector::operator()[abi:ne200100](a1: &v20); /*0x103d79877*/
  }
  return __stack_chk_guard; /*0x103d7988c*/
}

// Address: 0x103d79914 | Name: __ZN6webrtc20LegacyStatsCollector16ExtractMediaInfoERKNSt3__13mapINS1_12basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES8_NS1_4lessIS8_EENS6_INS1_4pairIKS8_S8_EEEEEE
__int64 __fastcall webrtc::LegacyStatsCollector::ExtractMediaInfo(webrtc::LegacyStatsCollector *a1, __int64 a2)
{
  __int64 v3; // r13
  __int64 *v4; // r12
  int v5; // eax
  __int64 v6; // rcx
  __int64 v7; // r14
  __int64 v8; // rbx
  __int64 v9; // r14
  __int64 v10; // rax
  __int64 v11; // rbx
  __int64 v12; // rax
  __int64 v13; // rax
  _QWORD *v14; // rbx
  _QWORD *v15; // r14
  __int64 j; // r13
  __int64 v17; // rdx
  __int64 v18; // rcx
  __int64 v19; // rdi
  __int64 v20; // r8
  __int64 v21; // r12
  __int64 v22; // r14
  signed __int64 v23; // r12
  __int64 v24; // r13
  unsigned __int64 v25; // r14
  _QWORD *v26; // rbx
  void *v27; // r13
  webrtc::LegacyStatsCollector *v28; // r12
  __int64 v29; // rax
  _QWORD *v30; // r14
  _QWORD *v31; // r15
  char v32; // bl
  _BYTE v34[16]; // [rsp+0h] [rbp-100h] BYREF
  __int64 v35; // [rsp+10h] [rbp-F0h] BYREF
  __int64 v36; // [rsp+18h] [rbp-E8h]
  __int64 i; // [rsp+28h] [rbp-D8h]
  __int64 v38; // [rsp+30h] [rbp-D0h]
  void *__src; // [rsp+38h] [rbp-C8h]
  char *v40; // [rsp+40h] [rbp-C0h]
  webrtc::LegacyStatsCollector *v41; // [rsp+48h] [rbp-B8h]
  __int128 v42; // [rsp+50h] [rbp-B0h] BYREF
  __int64 v43; // [rsp+60h] [rbp-A0h]
  __int128 v44; // [rsp+70h] [rbp-90h] BYREF
  void *v45; // [rsp+80h] [rbp-80h]
  __int64 v46; // [rsp+88h] [rbp-78h] BYREF
  __int64 *v47; // [rsp+90h] [rbp-70h] BYREF
  __int128 v48; // [rsp+98h] [rbp-68h] BYREF
  void *v49; // [rsp+A8h] [rbp-58h]
  __int128 v50; // [rsp+B0h] [rbp-50h] BYREF
  char *v51; // [rsp+C0h] [rbp-40h]
  __int64 v52; // [rsp+C8h] [rbp-38h]
  __int64 v53; // [rsp+D0h] [rbp-30h]

  v38 = a2; /*0x103d79928*/
  v50 = 0; /*0x103d79935*/
  v51 = nullptr; /*0x103d79939*/
  (*(void (__fastcall **)(__int64 *))(**((_QWORD **)a1 + 8) + 552LL))(a1: &v35); /*0x103d7994f*/
  v41 = a1; /*0x103d79955*/
  webrtc::Thread::ScopedDisallowBlockingCalls::ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v34); /*0x103d79963*/
  v3 = v35; /*0x103d79968*/
  for ( i = v36; v3 != i; v3 += 8 ) /*0x103d79980*/
  {
    v4 = *(__int64 **)(*(_QWORD *)(*(_QWORD *)v3 + 16LL) + 200LL); /*0x103d79992*/
    if ( v4 != nullptr ) /*0x103d7999c*/
    {
      v5 = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 16))(a1: v4); /*0x103d799a9*/
      v6 = *v4; /*0x103d799ac*/
      v52 = v3; /*0x103d799b2*/
      if ( v5 != 0 ) /*0x103d799b6*/
      {
        v7 = (*(__int64 (__fastcall **)(__int64 *))(v6 + 24))(a1: v4); /*0x103d799be*/
        v8 = operator new(a1: 0xE8u); /*0x103d799cb*/
        *(_OWORD *)(v8 + 64) = 0; /*0x103d799d5*/
        *(_OWORD *)(v8 + 8) = 0; /*0x103d799d9*/
        *(_OWORD *)(v8 + 24) = 0; /*0x103d799dd*/
        *(_OWORD *)(v8 + 40) = 0; /*0x103d799e1*/
        *(_QWORD *)(v8 + 56) = v8 + 64; /*0x103d799e5*/
        *(_OWORD *)(v8 + 88) = 0; /*0x103d799ed*/
        *(_QWORD *)(v8 + 80) = v8 + 88; /*0x103d799f1*/
        *(_QWORD *)v8 = off_10C91FA38; /*0x103d799fc*/
        *(_QWORD *)(v8 + 104) = v7; /*0x103d799ff*/
        webrtc::VideoMediaInfo::VideoMediaInfo(this: (webrtc::VideoMediaInfo *)(v8 + 112)); /*0x103d79a0a*/
      }
      else
      {
        v9 = (*(__int64 (__fastcall **)(__int64 *))(v6 + 32))(a1: v4); /*0x103d79a17*/
        v8 = operator new(a1: 0xD8u); /*0x103d79a24*/
        *(_OWORD *)(v8 + 64) = 0; /*0x103d79a2e*/
        *(_OWORD *)(v8 + 8) = 0; /*0x103d79a32*/
        *(_OWORD *)(v8 + 24) = 0; /*0x103d79a36*/
        *(_OWORD *)(v8 + 40) = 0; /*0x103d79a3a*/
        *(_QWORD *)(v8 + 56) = v8 + 64; /*0x103d79a3e*/
        *(_OWORD *)(v8 + 88) = 0; /*0x103d79a46*/
        *(_QWORD *)(v8 + 80) = v8 + 88; /*0x103d79a4a*/
        *(_QWORD *)v8 = off_10C91F9A0; /*0x103d79a55*/
        *(_QWORD *)(v8 + 104) = v9; /*0x103d79a58*/
        webrtc::VoiceMediaInfo::VoiceMediaInfo(this: (webrtc::VoiceMediaInfo *)(v8 + 112)); /*0x103d79a63*/
      }
      v53 = v8; /*0x103d79a68*/
      v10 = (*(__int64 (__fastcall **)(__int64 *))(*v4 + 96))(a1: v4); /*0x103d79a73*/
      v11 = v53 + 8; /*0x103d79a7a*/
      std::string::operator=(a1: v53 + 8, a2: v10); /*0x103d79a84*/
      v12 = std::map<std::string,std::string>::at(a1: v38, a2: v11); /*0x103d79a93*/
      std::string::operator=(a1: v53 + 32, a2: v12); /*0x103d79aa3*/
      v13 = *(_QWORD *)(*(_QWORD *)v52 + 16LL); /*0x103d79aaf*/
      v42 = 0; /*0x103d79ab6*/
      v43 = 0; /*0x103d79abd*/
      std::vector<webrtc::scoped_refptr<webrtc::RtpSenderProxyWithInternal<webrtc::RtpSenderInternal>>>::__init_with_size[abi:ne200100]<webrtc::scoped_refptr<webrtc::RtpSenderProxyWithInternal<webrtc::RtpSenderInternal>>*,webrtc::scoped_refptr<webrtc::RtpSenderProxyWithInternal<webrtc::RtpSenderInternal>>*>( /*0x103d79ae1*/
        a1: &v42,
        a2: *(_QWORD *)(v13 + 72),
        a3: *(_QWORD *)(v13 + 80),
        a4: (__int64)(*(_QWORD *)(v13 + 80) - *(_QWORD *)(v13 + 72)) >> 3);
      v15 = *((_QWORD **)&v42 + 1); /*0x103d79aed*/
      v14 = (_QWORD *)v42; /*0x103d79aed*/
      for ( j = v53; v14 != v15; ++v14 ) /*0x103d79afb*/
      {
        (*(void (__fastcall **)(__int64 *))(*(_QWORD *)*v14 + 40LL))(a1: &v46); /*0x103d79b0f*/
        if ( v46 != 0 ) /*0x103d79b19*/
          (*(void (__fastcall **)(__int128 *))(*(_QWORD *)v46 + 40LL))(a1: &v44); /*0x103d79b25*/
        else
          std::string::basic_string[abi:ne200100]<0>(a1: &v44, a2: "", a3: v17, a4: v18); /*0x103d79b38*/
        LODWORD(v47) = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v14 + 56LL))(a1: *v14); /*0x103d79b46*/
        if ( (v44 & 1) != 0 ) /*0x103d79b50*/
        {
          std::string::__init_copy_ctor_external(a1: &v48, a2: v45, a3: *((_QWORD *)&v44 + 1)); /*0x103d79b79*/
        }
        else
        {
          v49 = v45; /*0x103d79b5a*/
          v48 = v44; /*0x103d79b65*/
        }
        std::__tree<std::__value_type<unsigned int,std::string>,std::__map_value_compare<unsigned int,std::__value_type<unsigned int,std::string>,std::less<unsigned int>,true>,std::allocator<std::__value_type<unsigned int,std::string>>>::__emplace_unique_key_args<unsigned int,std::pair<unsigned int,std::string>>( /*0x103d79b87*/
          a1: j + 56,
          a2: &v47,
          a3: &v47);
        if ( (v48 & 1) != 0 ) /*0x103d79b90*/
          operator delete(a1: v49); /*0x103d79b96*/
        if ( (v44 & 1) != 0 ) /*0x103d79ba2*/
          operator delete(a1: v45); /*0x103d79ba8*/
        if ( v46 != 0 ) /*0x103d79bb4*/
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v46 + 8LL))(a1: v46); /*0x103d79bb9*/
      }
      v47 = (__int64 *)&v42; /*0x103d79bd0*/
      std::vector<webrtc::scoped_refptr<webrtc::RtpSenderProxyWithInternal<webrtc::RtpSenderInternal>>>::__destroy_vector::operator()[abi:ne200100](a1: &v47); /*0x103d79bd7*/
      v21 = *((_QWORD *)&v50 + 1); /*0x103d79bdc*/
      if ( *((_QWORD *)&v50 + 1) >= (unsigned __int64)v51 ) /*0x103d79be7*/
      {
        v23 = *((_QWORD *)&v50 + 1) - v50; /*0x103d79bfd*/
        v24 = (__int64)(*((_QWORD *)&v50 + 1) - v50) >> 3; /*0x103d79c03*/
        if ( (unsigned __int64)(v24 + 1) > 0x1FFFFFFFFFFFFFFFLL ) /*0x103d79c18*/
          std::vector<std::unique_ptr<webrtc::`anonymous namespace'::ChannelStatsGatherer>>::__throw_length_error[abi:ne200100](); /*0x103d79d9a*/
        v25 = (__int64)&v51[-v50] >> 2; /*0x103d79c24*/
        if ( v25 <= v24 + 1 ) /*0x103d79c2b*/
          v25 = (v23 >> 3) + 1; /*0x103d79c2b*/
        if ( (unsigned __int64)&v51[-v50] >= 0x7FFFFFFFFFFFFFF8LL ) /*0x103d79c3c*/
          v25 = 0x1FFFFFFFFFFFFFFFLL; /*0x103d79c3c*/
        __src = (void *)v50; /*0x103d79c43*/
        if ( v25 != 0 ) /*0x103d79c4a*/
        {
          if ( v25 > 0x1FFFFFFFFFFFFFFFLL ) /*0x103d79c4f*/
            std::__throw_bad_array_new_length[abi:ne200100]( /*0x103d79da1*/
              a1: v19,
              a2: v50,
              a3: 0x1FFFFFFFFFFFFFFFLL,
              a4: 0x7FFFFFFFFFFFFFF8LL,
              a5: v20);
          v26 = (_QWORD *)operator new(a1: 8 * v25); /*0x103d79c62*/
        }
        else
        {
          v26 = nullptr; /*0x103d79c67*/
        }
        v40 = (char *)&v26[v25]; /*0x103d79c6d*/
        v22 = (__int64)&v26[v24 + 1]; /*0x103d79c78*/
        v26[v24] = v53; /*0x103d79c80*/
        v27 = __src; /*0x103d79c87*/
        memcpy(__dst: v26, __src, __n: v23); /*0x103d79c94*/
        *(_QWORD *)&v50 = v26; /*0x103d79c99*/
        v51 = v40; /*0x103d79ca4*/
        if ( v27 != nullptr ) /*0x103d79cab*/
          operator delete(a1: v27); /*0x103d79cb0*/
      }
      else
      {
        **((_QWORD **)&v50 + 1) = j; /*0x103d79be9*/
        v22 = v21 + 8; /*0x103d79bf1*/
      }
      v3 = v52; /*0x103d79cb5*/
      *((_QWORD *)&v50 + 1) = v22; /*0x103d79cb9*/
    }
  }
  webrtc::Thread::ScopedDisallowBlockingCalls::~ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v34); /*0x103d79cd5*/
  v28 = v41; /*0x103d79cda*/
  v29 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v41 + 8) + 536LL))(a1: *((_QWORD *)v41 + 8)); /*0x103d79ce9*/
  v47 = &v35; /*0x103d79cfa*/
  *(_QWORD *)&v48 = &v50; /*0x103d79d01*/
  (*(void (__fastcall **)(__int64, __int64 **, __int64 (__fastcall *)(), __int128 *))(*(_QWORD *)v29 + 96LL))( /*0x103d79d19*/
    a1: v29,
    a2: &v47,
    a3: webrtc::FunctionView<void ()(void)>::CallVoidPtr<webrtc::LegacyStatsCollector::ExtractMediaInfo(std::map<std::string,std::string> const&)::$_0>,
    a4: &v42);
  webrtc::Thread::ScopedDisallowBlockingCalls::ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)&v47); /*0x103d79d21*/
  v31 = *((_QWORD **)&v50 + 1); /*0x103d79d2a*/
  v30 = (_QWORD *)v50; /*0x103d79d2a*/
  v32 = 0; /*0x103d79d2e*/
  while ( v30 != v31 ) /*0x103d79d33*/
  {
    (*(void (__fastcall **)(_QWORD, webrtc::LegacyStatsCollector *))(*(_QWORD *)*v30 + 24LL))(a1: *v30, a2: v28); /*0x103d79d3e*/
    v32 |= (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v30 + 32LL))(a1: *v30); /*0x103d79d4a*/
    ++v30; /*0x103d79d4c*/
  }
  webrtc::LegacyStatsCollector::UpdateStatsFromExistingLocalAudioTracks(this: v28, a2: v32 & 1); /*0x103d79d5b*/
  webrtc::Thread::ScopedDisallowBlockingCalls::~ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)&v47); /*0x103d79d67*/
  v47 = &v35; /*0x103d79d73*/
  std::vector<webrtc::scoped_refptr<webrtc::RtpTransceiverProxyWithInternal<webrtc::RtpTransceiver>>>::__destroy_vector::operator()[abi:ne200100](a1: &v47); /*0x103d79d7a*/
  return std::vector<std::unique_ptr<webrtc::`anonymous namespace'::ChannelStatsGatherer>>::~vector[abi:ne200100](a1: &v50); /*0x103d79d88*/
}

// Address: 0x103d79e92 | Name: __ZN6webrtc20LegacyStatsCollector17ExtractSenderInfoEv
__int64 __fastcall webrtc::LegacyStatsCollector::ExtractSenderInfo(webrtc::LegacyStatsCollector *this)
{
  _QWORD *v1; // r14
  _QWORD *v2; // r13
  absl::lts_20240116::strings_internal *v3; // r12
  absl::lts_20240116::strings_internal *v4; // r15
  size_t v5; // rax
  char v6; // r12
  char *v7; // rdi
  int v8; // ebx
  __int64 v9; // rax
  __int64 v10; // rbx
  _QWORD v12[3]; // [rsp+0h] [rbp-80h] BYREF
  _DWORD v13[2]; // [rsp+18h] [rbp-68h] BYREF
  char *__s; // [rsp+20h] [rbp-60h]
  webrtc::LegacyStatsCollector *v15; // [rsp+28h] [rbp-58h]
  __int64 v16; // [rsp+30h] [rbp-50h] BYREF
  _QWORD v17[2]; // [rsp+38h] [rbp-48h] BYREF
  void *__s1; // [rsp+48h] [rbp-38h]
  _QWORD v19[6]; // [rsp+50h] [rbp-30h] BYREF

  v15 = this; /*0x103d79ea3*/
  (*(void (__fastcall **)(_QWORD *))(**((_QWORD **)this + 8) + 128LL))(a1: v12); /*0x103d79eb5*/
  v1 = (_QWORD *)v12[0]; /*0x103d79ebb*/
  v2 = (_QWORD *)v12[1]; /*0x103d79ebe*/
  if ( v12[0] != v12[1] ) /*0x103d79ec5*/
  {
    __s = webrtc::MediaStreamTrackInterface::kVideoKind[0]; /*0x103d79ed5*/
    v15 = (webrtc::LegacyStatsCollector *)((char *)v15 + 8); /*0x103d79ed9*/
    v3 = (absl::lts_20240116::strings_internal *)v17; /*0x103d79ede*/
    while ( 1 ) /*0x103d79ee2*/
    {
      if ( (*(unsigned int (__fastcall **)(_QWORD))(*(_QWORD *)*v1 + 56LL))(a1: *v1) != 0 ) /*0x103d79eed*/
      {
        (*(void (__fastcall **)(_QWORD *))(*(_QWORD *)*v1 + 40LL))(a1: v19); /*0x103d79efd*/
        if ( v19[0] != 0 ) /*0x103d79f07*/
          break; /*0x103d79f07*/
      }
LABEL_23:
      if ( ++v1 == v2 ) /*0x103d7a037*/
        goto LABEL_24; /*0x103d7a037*/
    }
    v4 = v3; /*0x103d79f10*/
    (*(void (__fastcall **)(absl::lts_20240116::strings_internal *))(*(_QWORD *)v19[0] + 32LL))(a1: v3); /*0x103d79f16*/
    v5 = strlen(__s); /*0x103d79f1d*/
    v6 = v17[0]; /*0x103d79f22*/
    if ( (v17[0] & 1) != 0 ) /*0x103d79f2b*/
    {
      if ( v5 != v17[1] ) /*0x103d79f44*/
      {
        operator delete(a1: __s1); /*0x103d7a019*/
LABEL_20:
        v3 = v4; /*0x103d7a01e*/
LABEL_21:
        if ( v19[0] != 0 ) /*0x103d7a028*/
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)v19[0] + 8LL))(a1: v19[0]); /*0x103d7a02d*/
        goto LABEL_23; /*0x103d7a02d*/
      }
      if ( v5 == -1 ) /*0x103d79f4e*/
        std::string::__throw_out_of_range[abi:ne200100](); /*0x103d7a05c*/
      v7 = (char *)__s1; /*0x103d79f54*/
    }
    else
    {
      v7 = (char *)v17 + 1; /*0x103d79f32*/
      if ( v5 != LOBYTE(v17[0]) >> 1 ) /*0x103d79f39*/
        goto LABEL_20; /*0x103d79f39*/
    }
    v8 = memcmp(__s1: v7, __s2: __s, __n: v5); /*0x103d79f64*/
    if ( (v6 & 1) != 0 ) /*0x103d79f6a*/
      operator delete(a1: __s1); /*0x103d79f70*/
    v3 = v4; /*0x103d79f77*/
    if ( v8 == 0 ) /*0x103d79f7a*/
    {
      v9 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)v19[0] + 88LL))(a1: v19[0]); /*0x103d79f87*/
      if ( (*(unsigned __int8 (__fastcall **)(__int64, _DWORD *))(*(_QWORD *)v9 + 64LL))(a1: v9, a2: v13) != 0 ) /*0x103d79f99*/
      {
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v1 + 56LL))(a1: *v1); /*0x103d79fa5*/
        absl::lts_20240116::strings_internal::SingleArgStrCat(this: v4); /*0x103d79fad*/
        webrtc::StatsReport::NewIdWithDirection(a1: &v16, a2: 5, a3: v4, a4: 0); /*0x103d79fc0*/
        if ( (v17[0] & 1) != 0 ) /*0x103d79fc9*/
          operator delete(a1: __s1); /*0x103d79fcf*/
        v10 = webrtc::StatsCollection::FindOrAddNew(a1: v15, a2: &v16); /*0x103d79fe1*/
        webrtc::StatsReport::AddInt(a1: v10, a2: 88, a3: v13[0]); /*0x103d79fef*/
        webrtc::StatsReport::AddInt(a1: v10, a2: 80, a3: v13[1]); /*0x103d79fff*/
        if ( v16 != 0 ) /*0x103d7a00b*/
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v16 + 8LL))(a1: v16); /*0x103d7a010*/
      }
    }
    goto LABEL_21; /*0x103d7a013*/
  }
LABEL_24:
  v17[0] = v12; /*0x103d7a03d*/
  return std::vector<webrtc::scoped_refptr<webrtc::RtpSenderInterface>>::__destroy_vector::operator()[abi:ne200100](); /*0x103d7a04d*/
}

// Address: 0x103d7a0d2 | Name: __ZN6webrtc20LegacyStatsCollector18UpdateTrackReportsEv
void __fastcall webrtc::LegacyStatsCollector::UpdateTrackReports(webrtc::LegacyStatsCollector *this)
{
  webrtc::LegacyStatsCollector *v2; // rcx
  __int64 v3; // xmm0_8
  webrtc::LegacyStatsCollector *v4; // rsi
  webrtc::LegacyStatsCollector *v5; // rdx
  bool v6; // zf
  _BYTE v7[24]; // [rsp+8h] [rbp-18h] BYREF

  webrtc::Thread::ScopedDisallowBlockingCalls::ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v7); /*0x103d7a0e2*/
  v2 = *((webrtc::LegacyStatsCollector **)this + 5); /*0x103d7a0e7*/
  if ( v2 != (webrtc::LegacyStatsCollector *)((char *)this + 48) ) /*0x103d7a0f2*/
  {
    v3 = *((_QWORD *)this + 11); /*0x103d7a0f4*/
    do /*0x103d7a12a*/
    {
      *(_QWORD *)(*((_QWORD *)v2 + 7) + 8LL) = v3; /*0x103d7a0fd*/
      v4 = *((webrtc::LegacyStatsCollector **)v2 + 1); /*0x103d7a102*/
      if ( v4 != nullptr ) /*0x103d7a109*/
      {
        do /*0x103d7a114*/
        {
          v5 = v4; /*0x103d7a10b*/
          v4 = *(webrtc::LegacyStatsCollector **)v4; /*0x103d7a10e*/
        }
        while ( v4 != nullptr ); /*0x103d7a114*/
      }
      else
      {
        do /*0x103d7a122*/
        {
          v5 = *((webrtc::LegacyStatsCollector **)v2 + 2); /*0x103d7a118*/
          v6 = *(_QWORD *)v5 == (_QWORD)v2; /*0x103d7a11c*/
          v2 = v5; /*0x103d7a11f*/
        }
        while ( !v6 ); /*0x103d7a122*/
      }
      v2 = v5; /*0x103d7a124*/
    }
    while ( v5 != (webrtc::LegacyStatsCollector *)((char *)this + 48) ); /*0x103d7a12a*/
  }
  webrtc::Thread::ScopedDisallowBlockingCalls::~ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v7); /*0x103d7a130*/
}

// Address: 0x103d7a13c | Name: __ZN6webrtc20LegacyStatsCollector13PrepareReportEbjRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERKNS_13scoped_refptrINS_11StatsReport6IdBaseEEENSB_9DirectionE
__int64 __fastcall webrtc::LegacyStatsCollector::PrepareReport(
        __int64 a1,
        int a2,
        unsigned int a3,
        unsigned __int8 *a4,
        __int64 a5,
        unsigned int a6)
{
  unsigned int v9; // r15d
  __int64 v10; // rax
  unsigned __int8 *v11; // r14
  __int64 inserted; // r15
  unsigned int v13; // eax
  __int64 v14; // rax
  _BYTE v16[16]; // [rsp+8h] [rbp-58h] BYREF
  void *v17; // [rsp+18h] [rbp-48h]
  unsigned __int8 *v18; // [rsp+20h] [rbp-40h]
  __int64 v19; // [rsp+28h] [rbp-38h]
  _QWORD v20[6]; // [rsp+30h] [rbp-30h] BYREF

  v19 = a5; /*0x103d7a150*/
  v18 = a4; /*0x103d7a154*/
  v9 = 6 - a2; /*0x103d7a164*/
  absl::lts_20240116::strings_internal::SingleArgStrCat(this: (absl::lts_20240116::strings_internal *)v16); /*0x103d7a170*/
  webrtc::StatsReport::NewIdWithDirection(a1: v20, a2: v9, a3: v16, a4: a6); /*0x103d7a181*/
  if ( (v16[0] & 1) != 0 ) /*0x103d7a18a*/
    operator delete(a1: v17); /*0x103d7a190*/
  v10 = webrtc::StatsCollection::Find(a1: a1 + 8, a2: v20); /*0x103d7a1a0*/
  v11 = v18; /*0x103d7a1a5*/
  inserted = v10; /*0x103d7a1a9*/
  if ( v10 == 0 ) /*0x103d7a1af*/
    inserted = webrtc::StatsCollection::InsertNew(a1: a1 + 8, a2: v20); /*0x103d7a1bd*/
  *(_QWORD *)(inserted + 8) = *(_QWORD *)(a1 + 88); /*0x103d7a1c6*/
  webrtc::StatsReport::AddInt64(a1: inserted, a2: 21, a3); /*0x103d7a1d7*/
  v13 = *v11; /*0x103d7a1dc*/
  if ( (v13 & 1) != 0 ) /*0x103d7a1e2*/
    v14 = *((_QWORD *)v11 + 1); /*0x103d7a1e4*/
  else
    v14 = v13 >> 1; /*0x103d7a1ea*/
  if ( v14 != 0 ) /*0x103d7a1ef*/
    webrtc::StatsReport::AddString(a1: inserted, a2: 135, a3: v11); /*0x103d7a1fc*/
  webrtc::StatsReport::AddId(a1: inserted, a2: 26, a3: v19); /*0x103d7a20d*/
  if ( v20[0] != 0 ) /*0x103d7a219*/
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)v20[0] + 8LL))(a1: v20[0]); /*0x103d7a21e*/
  return inserted; /*0x103d7a224*/
}

// Address: 0x103d7a26c | Name: __ZN6webrtc20LegacyStatsCollector16PrepareADMReportEv
__int64 __fastcall webrtc::LegacyStatsCollector::PrepareADMReport(webrtc::LegacyStatsCollector *this)
{
  __int64 v2; // rbx
  _BYTE v4[16]; // [rsp+0h] [rbp-30h] BYREF
  void *v5; // [rsp+10h] [rbp-20h]
  _QWORD v6[3]; // [rsp+18h] [rbp-18h] BYREF

  (*(void (__fastcall **)(_BYTE *, __int64))(*(_QWORD *)(*((_QWORD *)this + 8) + 8LL) + 16LL))( /*0x103d7a28d*/
    a1: v4,
    a2: *((_QWORD *)this + 8) + 8LL);
  webrtc::StatsReport::NewTypedId(a1: v6, a2: 0, a3: v4); /*0x103d7a299*/
  if ( (v4[0] & 1) != 0 ) /*0x103d7a2a2*/
    operator delete(a1: v5); /*0x103d7a2a8*/
  v2 = webrtc::StatsCollection::FindOrAddNew(a1: (char *)this + 8, a2: v6); /*0x103d7a2bd*/
  if ( v6[0] != 0 ) /*0x103d7a2c7*/
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)v6[0] + 8LL))(a1: v6[0]); /*0x103d7a2cc*/
  return v2; /*0x103d7a2d2*/
}

// Address: 0x103d7a314 | Name: __ZN6webrtc20LegacyStatsCollector12IsValidTrackERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
bool __fastcall webrtc::LegacyStatsCollector::IsValidTrack(__int64 a1, __int64 a2)
{
  __int64 v2; // rbx
  __int64 v3; // rbx
  _QWORD v5[3]; // [rsp+8h] [rbp-18h] BYREF

  v2 = a1 + 8; /*0x103d7a325*/
  webrtc::StatsReport::NewTypedId(a1: v5, a2: 7, a3: a2); /*0x103d7a335*/
  v3 = webrtc::StatsCollection::Find(a1: v2, a2: v5); /*0x103d7a345*/
  if ( v5[0] != 0 ) /*0x103d7a34f*/
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)v5[0] + 8LL))(a1: v5[0]); /*0x103d7a354*/
  return v3 != 0; /*0x103d7a35d*/
}

// Address: 0x103d7a38a | Name: __ZN6webrtc20LegacyStatsCollector21AddCertificateReportsENSt3__110unique_ptrINS_19SSLCertificateStatsENS1_14default_deleteIS3_EEEE
__int64 __fastcall webrtc::LegacyStatsCollector::AddCertificateReports(__int64 a1, __int64 *a2)
{
  __int64 v2; // r14
  __int64 v3; // r12
  __int64 v4; // r15
  __int64 v5; // r13
  __int64 v6; // rbx
  __int64 v8; // [rsp+0h] [rbp-40h]
  _QWORD v10[6]; // [rsp+10h] [rbp-30h] BYREF

  v2 = *a2; /*0x103d7a39b*/
  if ( *a2 == 0 ) /*0x103d7a3a1*/
    return 0; /*0x103d7a45d*/
  v8 = a1 + 8; /*0x103d7a3af*/
  v3 = 0; /*0x103d7a3b3*/
  v4 = 0; /*0x103d7a3b6*/
  do /*0x103d7a455*/
  {
    webrtc::StatsReport::NewTypedId(a1: v10, a2: 10, a3: v2); /*0x103d7a3c8*/
    v5 = webrtc::StatsCollection::ReplaceOrAddNew(a1: v8, a2: v10); /*0x103d7a3d9*/
    *(_QWORD *)(v5 + 8) = *(_QWORD *)(a1 + 88); /*0x103d7a3e5*/
    webrtc::StatsReport::AddString(a1: v5, a2: 75, a3: v2); /*0x103d7a3f6*/
    webrtc::StatsReport::AddString(a1: v5, a2: 76, a3: v2 + 24); /*0x103d7a407*/
    webrtc::StatsReport::AddString(a1: v5, a2: 67, a3: v2 + 48); /*0x103d7a418*/
    v6 = v5; /*0x103d7a41d*/
    if ( v3 != 0 ) /*0x103d7a423*/
    {
      webrtc::StatsReport::AddId(a1: v4, a2: 95, a3: v10); /*0x103d7a431*/
      v6 = v3; /*0x103d7a436*/
    }
    if ( v10[0] != 0 ) /*0x103d7a440*/
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)v10[0] + 8LL))(a1: v10[0]); /*0x103d7a445*/
    v2 = *(_QWORD *)(v2 + 72); /*0x103d7a448*/
    v3 = v6; /*0x103d7a44c*/
    v4 = v5; /*0x103d7a44f*/
  }
  while ( v2 != 0 ); /*0x103d7a455*/
  return v6; /*0x103d7a462*/
}

// Address: 0x103d7a496 | Name: __ZN6webrtc20LegacyStatsCollector23AddConnectionInfoReportERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEiiRKNS_13scoped_refptrINS_11StatsReport6IdBaseEEERKNS_14ConnectionInfoE
__int64 __fastcall webrtc::LegacyStatsCollector::AddConnectionInfoReport(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        char *a6)
{
  __int64 v9; // rbx
  __int64 i; // r12
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 j; // r13
  void *v15[51]; // [rsp+0h] [rbp-810h] BYREF
  void *v16[51]; // [rsp+198h] [rbp-678h] BYREF
  void *v17[51]; // [rsp+330h] [rbp-4E0h] BYREF
  char v18; // [rsp+4C8h] [rbp-348h]
  char v19; // [rsp+4E0h] [rbp-330h]
  void *v20[51]; // [rsp+4E8h] [rbp-328h] BYREF
  char v21; // [rsp+680h] [rbp-190h]
  char v22; // [rsp+698h] [rbp-178h]
  __int64 v23; // [rsp+6A0h] [rbp-170h] BYREF
  __int64 v24; // [rsp+6A8h] [rbp-168h] BYREF
  __int64 v25; // [rsp+6B0h] [rbp-160h] BYREF
  __int64 v26; // [rsp+6B8h] [rbp-158h] BYREF
  __int64 v27; // [rsp+6C0h] [rbp-150h] BYREF
  __int64 v28; // [rsp+6C8h] [rbp-148h] BYREF
  __int64 v29; // [rsp+6D0h] [rbp-140h] BYREF
  __int64 v30; // [rsp+6D8h] [rbp-138h] BYREF
  __int64 v31; // [rsp+6E0h] [rbp-130h] BYREF
  __int64 v32; // [rsp+6E8h] [rbp-128h] BYREF
  __int64 v33; // [rsp+6F0h] [rbp-120h] BYREF
  _BYTE v34[16]; // [rsp+6F8h] [rbp-118h] BYREF
  void *v35; // [rsp+708h] [rbp-108h]
  _QWORD v36[2]; // [rsp+710h] [rbp-100h]
  int v37; // [rsp+720h] [rbp-F0h]
  __int64 *v38; // [rsp+728h] [rbp-E8h]
  int v39; // [rsp+730h] [rbp-E0h]
  __int64 *v40; // [rsp+738h] [rbp-D8h]
  int v41; // [rsp+740h] [rbp-D0h]
  __int64 *v42; // [rsp+748h] [rbp-C8h]
  int v43; // [rsp+750h] [rbp-C0h]
  __int64 *v44; // [rsp+758h] [rbp-B8h]
  int v45; // [rsp+760h] [rbp-B0h]
  __int64 *v46; // [rsp+768h] [rbp-A8h]
  int v47; // [rsp+770h] [rbp-A0h]
  __int64 *v48; // [rsp+778h] [rbp-98h]
  int v49; // [rsp+780h] [rbp-90h]
  __int64 *v50; // [rsp+788h] [rbp-88h]
  int v51; // [rsp+790h] [rbp-80h]
  __int64 *v52; // [rsp+798h] [rbp-78h]
  int v53; // [rsp+7A0h] [rbp-70h]
  __int64 *v54; // [rsp+7A8h] [rbp-68h]
  _QWORD v55[2]; // [rsp+7B0h] [rbp-60h]
  int v56; // [rsp+7C0h] [rbp-50h]
  char *v57; // [rsp+7C8h] [rbp-48h]
  int v58; // [rsp+7D0h] [rbp-40h]
  char *v59; // [rsp+7D8h] [rbp-38h]

  webrtc::StatsReport::NewCandidatePairId(a1: &v33); /*0x103d7a4c8*/
  v9 = webrtc::StatsCollection::ReplaceOrAddNew(a1: a1 + 8, a2: &v33); /*0x103d7a4dd*/
  *(_QWORD *)(v9 + 8) = *(_QWORD *)(a1 + 88); /*0x103d7a4e6*/
  LODWORD(v55[0]) = 0; /*0x103d7a4eb*/
  v55[1] = a6; /*0x103d7a4f2*/
  v56 = 19; /*0x103d7a4f6*/
  v57 = a6 + 2; /*0x103d7a501*/
  v58 = 138; /*0x103d7a505*/
  v59 = a6 + 1; /*0x103d7a510*/
  for ( i = 1; i != 7; i += 2 ) /*0x103d7a514*/
    webrtc::StatsReport::AddBoolean(a1: v9, a2: LODWORD(v55[i - 1]), a3: *(unsigned __int8 *)v55[i]); /*0x103d7a52a*/
  webrtc::StatsReport::AddId(a1: v9, a2: 51, a3: a5); /*0x103d7a544*/
  webrtc::Candidate::Candidate(this: (webrtc::Candidate *)v15, a2: (const webrtc::Candidate *)(a6 + 120)); /*0x103d7a557*/
  webrtc::Candidate::Candidate(this: (webrtc::Candidate *)v17, a2: (const webrtc::Candidate *)v15); /*0x103d7a56a*/
  v18 = 0; /*0x103d7a571*/
  v19 = 0; /*0x103d7a577*/
  webrtc::Candidate::~Candidate(this: v15); /*0x103d7a584*/
  webrtc::Candidate::Candidate(this: (webrtc::Candidate *)v16, a2: (const webrtc::Candidate *)(a6 + 528)); /*0x103d7a59a*/
  webrtc::Candidate::Candidate(this: (webrtc::Candidate *)v20, a2: (const webrtc::Candidate *)v16); /*0x103d7a5ad*/
  v21 = 0; /*0x103d7a5b4*/
  v22 = 0; /*0x103d7a5ba*/
  webrtc::Candidate::~Candidate(this: v16); /*0x103d7a5c7*/
  v11 = webrtc::LegacyStatsCollector::AddCandidateReport(a1, a2: v17, a3: 1); /*0x103d7a5db*/
  webrtc::StatsReport::AddId(a1: v9, a2: 100, a3: v11); /*0x103d7a5eb*/
  v12 = webrtc::LegacyStatsCollector::AddCandidateReport(a1, a2: v20, a3: 0); /*0x103d7a5fc*/
  webrtc::StatsReport::AddId(a1: v9, a2: 112, a3: v12); /*0x103d7a60c*/
  LODWORD(v36[0]) = 4; /*0x103d7a611*/
  v23 = *((_QWORD *)a6 + 10); /*0x103d7a626*/
  v36[1] = &v23; /*0x103d7a629*/
  v37 = 5; /*0x103d7a630*/
  v24 = *((_QWORD *)a6 + 3); /*0x103d7a645*/
  v38 = &v24; /*0x103d7a648*/
  v39 = 16; /*0x103d7a64f*/
  v25 = *((_QWORD *)a6 + 6); /*0x103d7a664*/
  v40 = &v25; /*0x103d7a667*/
  v41 = 126; /*0x103d7a66e*/
  v26 = *((_QWORD *)a6 + 1); /*0x103d7a683*/
  v42 = &v26; /*0x103d7a686*/
  v43 = 129; /*0x103d7a68d*/
  v27 = *((_QWORD *)a6 + 5); /*0x103d7a6a2*/
  v44 = &v27; /*0x103d7a6a5*/
  v45 = 27; /*0x103d7a6ac*/
  v28 = *((_QWORD *)a6 + 7); /*0x103d7a6c1*/
  v46 = &v28; /*0x103d7a6c4*/
  v47 = 28; /*0x103d7a6cb*/
  v29 = *((_QWORD *)a6 + 8); /*0x103d7a6e0*/
  v48 = &v29; /*0x103d7a6e3*/
  v49 = 29; /*0x103d7a6ea*/
  v30 = *((_QWORD *)a6 + 9); /*0x103d7a6ff*/
  v50 = &v30; /*0x103d7a702*/
  v51 = 30; /*0x103d7a709*/
  v31 = *((_QWORD *)a6 + 13); /*0x103d7a71b*/
  v52 = &v31; /*0x103d7a71e*/
  v53 = 31; /*0x103d7a722*/
  v32 = *((_QWORD *)a6 + 14); /*0x103d7a734*/
  v54 = &v32; /*0x103d7a737*/
  for ( j = 1; j != 21; j += 2 ) /*0x103d7a73b*/
    webrtc::StatsReport::AddInt64(a1: v9, a2: LODWORD(v36[j - 1]), a3: *(_QWORD *)v36[j]); /*0x103d7a757*/
  webrtc::SocketAddress::ToString(this: (webrtc::SocketAddress *)v34); /*0x103d7a777*/
  webrtc::StatsReport::AddString(a1: v9, a2: 99, a3: v34); /*0x103d7a78b*/
  if ( (v34[0] & 1) != 0 ) /*0x103d7a797*/
    operator delete(a1: v35); /*0x103d7a7a0*/
  webrtc::GetLegacyCandidateTypeName(this: (webrtc *)v34, a2: (const webrtc::Candidate *)(a6 + 120)); /*0x103d7a7af*/
  webrtc::StatsReport::AddString(a1: v9, a2: 101, a3: v34); /*0x103d7a7c3*/
  if ( (v34[0] & 1) != 0 ) /*0x103d7a7cf*/
    operator delete(a1: v35); /*0x103d7a7d8*/
  webrtc::SocketAddress::ToString(this: (webrtc::SocketAddress *)v34); /*0x103d7a7eb*/
  webrtc::StatsReport::AddString(a1: v9, a2: 111, a3: v34); /*0x103d7a7ff*/
  if ( (v34[0] & 1) != 0 ) /*0x103d7a80b*/
    operator delete(a1: v35); /*0x103d7a814*/
  webrtc::GetLegacyCandidateTypeName(this: (webrtc *)v34, a2: (const webrtc::Candidate *)(a6 + 528)); /*0x103d7a823*/
  webrtc::StatsReport::AddString(a1: v9, a2: 113, a3: v34); /*0x103d7a837*/
  if ( (v34[0] & 1) != 0 ) /*0x103d7a843*/
    operator delete(a1: v35); /*0x103d7a84c*/
  webrtc::StatsReport::AddString(a1: v9, a2: 137, a3: a6 + 152); /*0x103d7a860*/
  webrtc::StatsReport::AddString(a1: v9, a2: 140, a3: a6 + 176); /*0x103d7a877*/
  webrtc::Candidate::~Candidate(this: v20); /*0x103d7a883*/
  webrtc::Candidate::~Candidate(this: v17); /*0x103d7a88f*/
  if ( v33 != 0 ) /*0x103d7a89e*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v33 + 8LL))(a1: v33); /*0x103d7a8a3*/
  return v9; /*0x103d7a8b9*/
}

// Address: 0x103d7a974 | Name: __ZN6webrtc20LegacyStatsCollector18AddCandidateReportERKNS_14CandidateStatsEb
__int64 __fastcall webrtc::LegacyStatsCollector::AddCandidateReport(__int64 a1, __int64 a2, unsigned int a3)
{
  char v3; // r15
  __int64 inserted; // rbx
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rdx
  __int64 v10; // rcx
  unsigned int v11; // r8d
  const webrtc::Candidate *v12; // rsi
  __int64 v13; // rax
  float v14; // xmm0_4
  float v15; // xmm0_4
  __int64 v17; // [rsp+8h] [rbp-48h] BYREF
  _BYTE v18[16]; // [rsp+10h] [rbp-40h] BYREF
  void *v19; // [rsp+20h] [rbp-30h]

  v3 = a3; /*0x103d7a985*/
  webrtc::StatsReport::NewCandidateId(a1: &v17, a2: a3, a3: a2); /*0x103d7a99a*/
  inserted = webrtc::StatsCollection::Find(a1: a1 + 8, a2: &v17); /*0x103d7a9af*/
  if ( inserted == 0 ) /*0x103d7a9b5*/
  {
    inserted = webrtc::StatsCollection::InsertNew(a1: a1 + 8, a2: &v17); /*0x103d7a9c7*/
    *(_QWORD *)(inserted + 8) = *(_QWORD *)(a1 + 88); /*0x103d7a9d1*/
    if ( v3 != 0 ) /*0x103d7a9d9*/
    {
      v7 = webrtc::AdapterTypeToStatsType(a1: *(unsigned int *)(a2 + 240)); /*0x103d7a9e2*/
      webrtc::StatsReport::AddString(a1: inserted, a2: 46, a3: v7); /*0x103d7a9f2*/
    }
    v8 = webrtc::SocketAddress::ipaddr(this: (webrtc::SocketAddress *)(a2 + 80)); /*0x103d7a9fe*/
    webrtc::IPAddress::ToString(this: (webrtc::IPAddress *)v18, a2: v8, a3: v9, a4: v10, a5: v11); /*0x103d7aa0a*/
    webrtc::StatsReport::AddString(a1: inserted, a2: 45, a3: v18); /*0x103d7aa1b*/
    if ( (v18[0] & 1) != 0 ) /*0x103d7aa24*/
      operator delete(a1: v19); /*0x103d7aa2a*/
    webrtc::SocketAddress::PortAsString(this: (webrtc::SocketAddress *)v18); /*0x103d7aa36*/
    webrtc::StatsReport::AddString(a1: inserted, a2: 47, a3: v18); /*0x103d7aa47*/
    if ( (v18[0] & 1) != 0 ) /*0x103d7aa50*/
      operator delete(a1: v19); /*0x103d7aa56*/
    webrtc::StatsReport::AddInt(a1: inserted, a2: 48, a3: *(unsigned int *)(a2 + 152)); /*0x103d7aa6a*/
    v13 = webrtc::IceCandidateTypeToStatsType(this: (webrtc *)a2, a2: v12); /*0x103d7aa72*/
    webrtc::StatsReport::AddString(a1: inserted, a2: 50, a3: v13); /*0x103d7aa82*/
    webrtc::StatsReport::AddString(a1: inserted, a2: 49, a3: a2 + 32); /*0x103d7aa93*/
  }
  *(_QWORD *)(inserted + 8) = *(_QWORD *)(a1 + 88); /*0x103d7aa9f*/
  if ( v3 != 0 && *(_BYTE *)(a2 + 432) == 1 ) /*0x103d7aab1*/
  {
    webrtc::StatsReport::AddInt64(a1: inserted, a2: 32, a3: *(int *)(a2 + 408)); /*0x103d7aac2*/
    webrtc::StatsReport::AddInt64(a1: inserted, a2: 33, a3: *(int *)(a2 + 412)); /*0x103d7aad6*/
    v14 = *(double *)(a2 + 416); /*0x103d7aade*/
    webrtc::StatsReport::AddFloat(a1: inserted, a2: 34, a3: v14); /*0x103d7aaef*/
    v15 = *(double *)(a2 + 424); /*0x103d7aaf7*/
    webrtc::StatsReport::AddFloat(a1: inserted, a2: 35, a3: v15); /*0x103d7ab08*/
  }
  if ( v17 != 0 ) /*0x103d7ab14*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v17 + 8LL))(a1: v17); /*0x103d7ab19*/
  return inserted; /*0x103d7ab1f*/
}

// Address: 0x103d7ab6e | Name: __ZZN6webrtc20LegacyStatsCollector25ExtractSessionAndDataInfoEvEN3$_0D1Ev
void __fastcall webrtc::LegacyStatsCollector::ExtractSessionAndDataInfo(void)::$_0::~$_0(__int64 a1)
{
  if ( *(_BYTE *)(a1 + 56) == 1 && (*(_BYTE *)(a1 + 32) & 1) != 0 ) /*0x103d7ab81*/
    operator delete(a1: *(void **)(a1 + 48)); /*0x103d7ab87*/
  if ( *(_BYTE *)(a1 + 24) == 1 && (*(_BYTE *)a1 & 1) != 0 ) /*0x103d7ab95*/
    operator delete(a1: *(void **)(a1 + 16)); /*0x103d7aba8*/
}

// Address: 0x103d7abae | Name: __ZN6webrtc20LegacyStatsCollector20ExtractSessionInfo_sERNS0_12SessionStatsE
void __fastcall webrtc::LegacyStatsCollector::ExtractSessionInfo_s(
        webrtc::LegacyStatsCollector *this,
        webrtc::LegacyStatsCollector::SessionStats *a2)
{
  __int64 v4; // r15
  webrtc::LegacyStatsCollector *v5; // rax
  unsigned __int8 v6; // al
  __int64 v7; // r15
  __int64 v8; // rbx
  _QWORD *v9; // rbx
  webrtc::SSLCertificateStats *v10; // r14
  _QWORD *v11; // r12
  void (__fastcall ***v12)(_QWORD); // r14
  webrtc::SSLCertificateStats *v13; // r14
  _QWORD *v14; // r12
  void (__fastcall ***v15)(_QWORD); // r14
  __int64 v16; // rax
  unsigned int *v17; // rbx
  __int64 v18; // r14
  __int64 v19; // rdi
  int v20; // r12d
  size_t v21; // r15
  size_t v22; // r13
  void *v23; // rsi
  char *v24; // r12
  unsigned __int64 v25; // r15
  __int64 v26; // r12
  __int64 v27; // r15
  char *v28; // r13
  char *v29; // r15
  unsigned int v30; // r12d
  __int64 v31; // rax
  __int64 v32; // rbx
  _BYTE v33[16]; // [rsp+0h] [rbp-B0h] BYREF
  unsigned int *v34; // [rsp+10h] [rbp-A0h]
  char *v35; // [rsp+18h] [rbp-98h]
  void *__src; // [rsp+20h] [rbp-90h]
  _QWORD *v37; // [rsp+28h] [rbp-88h]
  __int64 v38; // [rsp+30h] [rbp-80h] BYREF
  __int64 v39; // [rsp+38h] [rbp-78h] BYREF
  webrtc::SSLCertificateStats *v40; // [rsp+40h] [rbp-70h] BYREF
  webrtc::SSLCertificateStats *v41; // [rsp+48h] [rbp-68h] BYREF
  __int64 v42; // [rsp+50h] [rbp-60h]
  void (__fastcall ***v43)(_QWORD); // [rsp+58h] [rbp-58h] BYREF
  void (__fastcall ***v44)(_QWORD); // [rsp+60h] [rbp-50h] BYREF
  __int64 __dst; // [rsp+68h] [rbp-48h] BYREF
  size_t v46; // [rsp+70h] [rbp-40h]
  void *v47; // [rsp+78h] [rbp-38h]
  webrtc::LegacyStatsCollector *v48; // [rsp+80h] [rbp-30h]

  webrtc::Thread::ScopedDisallowBlockingCalls::ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v33); /*0x103d7abcf*/
  v48 = this; /*0x103d7abd4*/
  (*(void (__fastcall **)(__int64 *, __int64))(*(_QWORD *)(*((_QWORD *)this + 8) + 8LL) + 16LL))( /*0x103d7abe8*/
    a1: &__dst,
    a2: *((_QWORD *)this + 8) + 8LL);
  webrtc::StatsReport::NewTypedId(a1: &v39, a2: 0, a3: &__dst); /*0x103d7abf5*/
  if ( (__dst & 1) != 0 ) /*0x103d7abfe*/
    operator delete(a1: v47); /*0x103d7ac04*/
  v35 = (char *)v48 + 8; /*0x103d7ac15*/
  v4 = webrtc::StatsCollection::ReplaceOrAddNew(a1: (char *)v48 + 8, a2: &v39); /*0x103d7ac21*/
  v5 = v48; /*0x103d7ac24*/
  *(_QWORD *)(v4 + 8) = *((_QWORD *)v48 + 11); /*0x103d7ac2d*/
  v6 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v5 + 8) + 544LL))(a1: *((_QWORD *)v5 + 8)); /*0x103d7ac3a*/
  webrtc::StatsReport::AddBoolean(a1: v4, a2: 93, a3: v6); /*0x103d7ac4b*/
  v7 = *(_QWORD *)a2; /*0x103d7ac50*/
  v8 = *((_QWORD *)a2 + 1); /*0x103d7ac53*/
  while ( v7 != v8 ) /*0x103d7ac5a*/
  {
    webrtc::LegacyStatsCollector::AddCandidateReport(a1: (__int64)v48, a2: v7, a3: 1u); /*0x103d7ac68*/
    v7 += 440; /*0x103d7ac6d*/
  }
  v9 = *((_QWORD **)a2 + 3); /*0x103d7ac76*/
  v37 = *((_QWORD **)a2 + 4); /*0x103d7ac7e*/
  if ( v9 != v37 ) /*0x103d7ac88*/
  {
    while ( 1 ) /*0x103d7ac94*/
    {
      v43 = nullptr; /*0x103d7ac94*/
      v44 = nullptr; /*0x103d7ac98*/
      v10 = (webrtc::SSLCertificateStats *)v9[9]; /*0x103d7ac9c*/
      if ( v10 != nullptr ) /*0x103d7aca3*/
      {
        v9[9] = 0; /*0x103d7aca5*/
        v40 = v10; /*0x103d7acad*/
        v11 = (_QWORD *)webrtc::LegacyStatsCollector::AddCertificateReports(a1: (__int64)v48, a2: (__int64 *)&v40); /*0x103d7acbe*/
        v40 = nullptr; /*0x103d7acc1*/
        webrtc::SSLCertificateStats::~SSLCertificateStats(this: v10); /*0x103d7accc*/
        operator delete(a1: v10); /*0x103d7acd4*/
        if ( v11 != nullptr ) /*0x103d7acdc*/
        {
          v12 = (void (__fastcall ***)(_QWORD))*v11; /*0x103d7acde*/
          if ( *v11 != 0 ) /*0x103d7ace5*/
            (**v12)(a1: *v11); /*0x103d7aced*/
          if ( v43 != nullptr ) /*0x103d7acf6*/
            (*v43)[1](a1: v43); /*0x103d7acfb*/
          v43 = v12; /*0x103d7acfe*/
        }
      }
      v13 = (webrtc::SSLCertificateStats *)v9[10]; /*0x103d7ad02*/
      if ( v13 != nullptr ) /*0x103d7ad09*/
      {
        v9[10] = 0; /*0x103d7ad0b*/
        v41 = v13; /*0x103d7ad13*/
        v14 = (_QWORD *)webrtc::LegacyStatsCollector::AddCertificateReports(a1: (__int64)v48, a2: (__int64 *)&v41); /*0x103d7ad24*/
        v41 = nullptr; /*0x103d7ad27*/
        webrtc::SSLCertificateStats::~SSLCertificateStats(this: v13); /*0x103d7ad32*/
        operator delete(a1: v13); /*0x103d7ad3a*/
        if ( v14 != nullptr ) /*0x103d7ad42*/
        {
          v15 = (void (__fastcall ***)(_QWORD))*v14; /*0x103d7ad44*/
          if ( *v14 != 0 ) /*0x103d7ad4b*/
            (**v15)(a1: *v14); /*0x103d7ad53*/
          if ( v44 != nullptr ) /*0x103d7ad5c*/
            (*v44)[1](a1: v44); /*0x103d7ad61*/
          v44 = v15; /*0x103d7ad64*/
        }
      }
      v16 = (__int64)v9; /*0x103d7ad68*/
      v17 = (unsigned int *)v9[6]; /*0x103d7ad6b*/
      v42 = v16; /*0x103d7ad6f*/
      v34 = *(unsigned int **)(v16 + 56); /*0x103d7ad77*/
      if ( v17 != v34 ) /*0x103d7ad81*/
        break; /*0x103d7ad81*/
LABEL_54:
      if ( v44 != nullptr ) /*0x103d7afa5*/
        (*v44)[1](a1: v44); /*0x103d7afaa*/
      v32 = v42; /*0x103d7afb4*/
      if ( v43 != nullptr ) /*0x103d7afb8*/
        (*v43)[1](a1: v43); /*0x103d7afbd*/
      v9 = (_QWORD *)(v32 + 88); /*0x103d7afc0*/
      if ( v9 == v37 ) /*0x103d7afcb*/
        goto LABEL_59; /*0x103d7afcb*/
    }
    while ( 1 ) /*0x103d7ad94*/
    {
      webrtc::StatsReport::NewComponentId(a1: &v38, a2: v42, a3: *v17); /*0x103d7ad94*/
      v18 = webrtc::StatsCollection::ReplaceOrAddNew(a1: v35, a2: &v38); /*0x103d7ada8*/
      *(_QWORD *)(v18 + 8) = *((_QWORD *)v48 + 11); /*0x103d7adb4*/
      webrtc::StatsReport::AddInt(a1: v18, a2: 53, a3: *v17); /*0x103d7adc4*/
      if ( v43 != nullptr ) /*0x103d7adce*/
        webrtc::StatsReport::AddId(a1: v18, a2: 102, a3: &v43); /*0x103d7addc*/
      if ( v44 != nullptr ) /*0x103d7ade6*/
        webrtc::StatsReport::AddId(a1: v18, a2: 114, a3: &v44); /*0x103d7adf4*/
      v20 = v17[2]; /*0x103d7adf9*/
      if ( v20 != 0 ) /*0x103d7ae00*/
      {
        webrtc::SrtpCryptoSuiteToName(this: (webrtc *)&__dst, a2: v20); /*0x103d7ae08*/
        v21 = (unsigned __int8)__dst >> 1; /*0x103d7ae14*/
        if ( (__dst & 1) != 0 ) /*0x103d7ae19*/
        {
          v21 = v46; /*0x103d7ae1b*/
          operator delete(a1: v47); /*0x103d7ae25*/
        }
        if ( v21 != 0 ) /*0x103d7ae2d*/
        {
          webrtc::SrtpCryptoSuiteToName(this: (webrtc *)&__dst, a2: v20); /*0x103d7ae35*/
          webrtc::StatsReport::AddString(a1: v18, a2: 131, a3: &__dst); /*0x103d7ae45*/
          if ( (__dst & 1) != 0 ) /*0x103d7ae4e*/
            operator delete(a1: v47); /*0x103d7ae54*/
        }
      }
      if ( *((_BYTE *)v17 + 32) != 1 ) /*0x103d7ae5d*/
        goto LABEL_43; /*0x103d7ae5d*/
      v22 = *((_QWORD *)v17 + 3); /*0x103d7ae63*/
      if ( v22 >= 0xFFFFFFFFFFFFFFF8LL ) /*0x103d7ae6b*/
        std::string::__throw_length_error[abi:ne200100](a1: v19); /*0x103d7affe*/
      v23 = *((void **)v17 + 2); /*0x103d7ae71*/
      if ( v22 >= 0x17 ) /*0x103d7ae79*/
        break; /*0x103d7ae79*/
      LOBYTE(__dst) = 2 * v22; /*0x103d7ae83*/
      v24 = (char *)&__dst + 1; /*0x103d7ae86*/
      if ( v22 != 0 ) /*0x103d7ae8d*/
        goto LABEL_40; /*0x103d7ae8d*/
LABEL_41:
      v24[v22] = 0; /*0x103d7aedd*/
      webrtc::StatsReport::AddString(a1: v18, a2: 68, a3: &__dst); /*0x103d7aeee*/
      if ( (__dst & 1) != 0 ) /*0x103d7aef7*/
        operator delete(a1: v47); /*0x103d7aefd*/
LABEL_43:
      v26 = *((_QWORD *)v17 + 7); /*0x103d7af02*/
      v27 = *((_QWORD *)v17 + 8); /*0x103d7af06*/
      while ( v26 != v27 ) /*0x103d7af0d*/
      {
        webrtc::LegacyStatsCollector::AddCandidateReport(a1: (__int64)v48, a2: v26, a3: 1u); /*0x103d7af1b*/
        v26 += 440; /*0x103d7af20*/
      }
      v28 = *((char **)v17 + 10); /*0x103d7af29*/
      v29 = *((char **)v17 + 11); /*0x103d7af2d*/
      if ( v28 != v29 ) /*0x103d7af34*/
      {
        v30 = 0; /*0x103d7af36*/
        do /*0x103d7af75*/
        {
          v31 = webrtc::LegacyStatsCollector::AddConnectionInfoReport( /*0x103d7af4c*/
                  a1: (__int64)v48,
                  a2: v42,
                  a3: *v17,
                  a4: v30,
                  a5: v18,
                  a6: v28);
          if ( *v28 == 1 ) /*0x103d7af56*/
            webrtc::StatsReport::AddId(a1: v18, a2: 20, a3: v31); /*0x103d7af63*/
          v28 += 1016; /*0x103d7af68*/
          ++v30; /*0x103d7af6f*/
        }
        while ( v28 != v29 ); /*0x103d7af75*/
      }
      if ( v38 != 0 ) /*0x103d7af7e*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v38 + 8LL))(a1: v38); /*0x103d7af83*/
      v17 += 48; /*0x103d7af86*/
      if ( v17 == v34 ) /*0x103d7af98*/
        goto LABEL_54; /*0x103d7af98*/
    }
    __src = *((void **)v17 + 2); /*0x103d7ae91*/
    v25 = (v22 | 7) + 1; /*0x103d7ae9f*/
    if ( (v22 | 7) == 0x17 ) /*0x103d7aeac*/
      v25 = 26; /*0x103d7aeac*/
    v24 = (char *)operator new(a1: v25); /*0x103d7aeb8*/
    v47 = v24; /*0x103d7aebb*/
    __dst = v25 | 1; /*0x103d7aec3*/
    v46 = v22; /*0x103d7aec7*/
    v23 = __src; /*0x103d7aecb*/
LABEL_40:
    memmove(__dst: v24, __src: v23, __len: v22); /*0x103d7aed2*/
    goto LABEL_41; /*0x103d7aed8*/
  }
LABEL_59:
  if ( v39 != 0 ) /*0x103d7afd8*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v39 + 8LL))(a1: v39); /*0x103d7afdd*/
  webrtc::Thread::ScopedDisallowBlockingCalls::~ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v33); /*0x103d7afe7*/
}

// Address: 0x103d7b13a | Name: __ZN6webrtc20LegacyStatsCollector20ExtractSessionInfo_nERKNSt3__16vectorINS_13scoped_refptrINS_31RtpTransceiverProxyWithInternalINS_14RtpTransceiverEEEEENS1_9allocatorIS7_EEEENS1_8optionalINS1_12basic_stringIcNS1_11char_traitsIcEENS8_IcEEEEEESJ_
char *__fastcall webrtc::LegacyStatsCollector::ExtractSessionInfo_n(
        char *a1,
        __int64 a2,
        char **a3,
        __int64 a4,
        __int64 a5)
{
  char *v8; // rbx
  char *v9; // rax
  char *v10; // r13
  __int64 v11; // r15
  __int64 v12; // rax
  unsigned __int64 v13; // rdx
  __int64 v14; // rdi
  size_t v15; // r12
  const void *v16; // rsi
  _BYTE *v17; // r14
  unsigned __int64 v18; // rbx
  const void *v19; // r14
  __int64 v20; // rax
  __int64 v21; // rax
  __int64 v22; // r14
  __int64 v23; // rbx
  __int64 v24; // rax
  char *v25; // rbx
  char *v26; // r14
  char *v27; // rcx
  char *v28; // rax
  bool v29; // zf
  _QWORD *v30; // r13
  char *v31; // r15
  unsigned __int64 v32; // r12
  __int64 v33; // r12
  webrtc::SSLCertificateStats *v34; // rsi
  webrtc::SSLCertificateStats *v35; // rbx
  webrtc::SSLCertificateStats *v36; // rsi
  webrtc::SSLCertificateStats *v37; // rbx
  webrtc::SSLCertChain *v38; // rbx
  _QWORD *v39; // rcx
  _QWORD *v40; // rax
  const char *v42; // rsi
  unsigned __int64 *v43; // [rsp+10h] [rbp-E0h]
  _QWORD *v44; // [rsp+20h] [rbp-D0h] BYREF
  _QWORD v45[2]; // [rsp+28h] [rbp-C8h] BYREF
  _BYTE v46[16]; // [rsp+38h] [rbp-B8h] BYREF
  __int64 v47; // [rsp+48h] [rbp-A8h]
  char *v48; // [rsp+50h] [rbp-A0h]
  __int64 v49; // [rsp+58h] [rbp-98h]
  _QWORD *v50; // [rsp+60h] [rbp-90h] BYREF
  _QWORD v51[2]; // [rsp+68h] [rbp-88h] BYREF
  char *v52; // [rsp+78h] [rbp-78h]
  webrtc::SSLCertificateStats *v53; // [rsp+80h] [rbp-70h] BYREF
  __int64 v54; // [rsp+88h] [rbp-68h]
  webrtc::RTCCertificate *v55; // [rsp+90h] [rbp-60h] BYREF
  char **v56; // [rsp+98h] [rbp-58h]
  _BYTE __dst[24]; // [rsp+A0h] [rbp-50h] BYREF
  char *v58; // [rsp+B8h] [rbp-38h]
  webrtc::SSLCertificateStats *v59[6]; // [rsp+C0h] [rbp-30h] BYREF

  v54 = a2; /*0x103d7b157*/
  v58 = a1; /*0x103d7b15b*/
  if ( (_BYTE)`guard variable for'webrtc::LegacyStatsCollector::ExtractSessionInfo_n(std::vector<webrtc::scoped_refptr<webrtc::RtpTransceiverProxyWithInternal<webrtc::RtpTransceiver>>> const&,std::optional<std::string>,std::optional<std::string>)::trace_event_unique_catstatic913 == 0 /*0x103d7b60e*/
    && __cxa_guard_acquire(a1: &`guard variable for'webrtc::LegacyStatsCollector::ExtractSessionInfo_n(std::vector<webrtc::scoped_refptr<webrtc::RtpTransceiverProxyWithInternal<webrtc::RtpTransceiver>>> const&,std::optional<std::string>,std::optional<std::string>)::trace_event_unique_catstatic913) != 0 )
  {
    *(_QWORD *)webrtc::LegacyStatsCollector::ExtractSessionInfo_n(std::vector<webrtc::scoped_refptr<webrtc::RtpTransceiverProxyWithInternal<webrtc::RtpTransceiver>>> const&,std::optional<std::string>,std::optional<std::string>)::trace_event_unique_catstatic913 = webrtc::EventTracer::GetCategoryEnabled(this: (webrtc::EventTracer *)"webrtc", a2: v42); /*0x103d7b620*/
    __cxa_guard_release(a1: &`guard variable for'webrtc::LegacyStatsCollector::ExtractSessionInfo_n(std::vector<webrtc::scoped_refptr<webrtc::RtpTransceiverProxyWithInternal<webrtc::RtpTransceiver>>> const&,std::optional<std::string>,std::optional<std::string>)::trace_event_unique_catstatic913); /*0x103d7b62e*/
  }
  v44 = nullptr; /*0x103d7b16d*/
  if ( **(_BYTE **)webrtc::LegacyStatsCollector::ExtractSessionInfo_n(std::vector<webrtc::scoped_refptr<webrtc::RtpTransceiverProxyWithInternal<webrtc::RtpTransceiver>>> const&,std::optional<std::string>,std::optional<std::string>)::trace_event_unique_catstatic913 != 0 ) /*0x103d7b182*/
  {
    LODWORD(v43) = 0; /*0x103d7b18b*/
    webrtc::EventTracer::AddTraceEvent( /*0x103d7b1aa*/
      this: (webrtc::EventTracer *)0x42,
      a2: *(__int64 *)webrtc::LegacyStatsCollector::ExtractSessionInfo_n(std::vector<webrtc::scoped_refptr<webrtc::RtpTransceiverProxyWithInternal<webrtc::RtpTransceiver>>> const&,std::optional<std::string>,std::optional<std::string>)::trace_event_unique_catstatic913,
      a3: "LegacyStatsCollector::ExtractSessionInfo_n",
      a4: nullptr,
      a5: 0,
      a6: 0,
      a7: nullptr,
      a8: nullptr,
      a9: v43);
    v45[0] = *(_QWORD *)webrtc::LegacyStatsCollector::ExtractSessionInfo_n(std::vector<webrtc::scoped_refptr<webrtc::RtpTransceiverProxyWithInternal<webrtc::RtpTransceiver>>> const&,std::optional<std::string>,std::optional<std::string>)::trace_event_unique_catstatic913; /*0x103d7b1bd*/
    v45[1] = "LegacyStatsCollector::ExtractSessionInfo_n"; /*0x103d7b1c0*/
    v44 = v45; /*0x103d7b1c4*/
  }
  webrtc::Thread::ScopedDisallowBlockingCalls::ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v46); /*0x103d7b1cf*/
  v49 = a5; /*0x103d7b1d4*/
  v47 = a4; /*0x103d7b1db*/
  v8 = v58; /*0x103d7b1e2*/
  v9 = v58 + 56; /*0x103d7b1e6*/
  *(_OWORD *)(v58 + 56) = 0; /*0x103d7b1ed*/
  *(_OWORD *)v8 = 0; /*0x103d7b1f1*/
  *((_OWORD *)v8 + 1) = 0; /*0x103d7b1f4*/
  *((_OWORD *)v8 + 2) = 0; /*0x103d7b1f8*/
  v48 = v9; /*0x103d7b1fc*/
  *((_QWORD *)v8 + 6) = v9; /*0x103d7b203*/
  (*(void (__fastcall **)(_BYTE *))(**(_QWORD **)(v54 + 64) + 576LL))(a1: __dst); /*0x103d7b219*/
  v56 = (char **)(v8 + 48); /*0x103d7b223*/
  std::vector<webrtc::CandidateStats>::__vdeallocate(a1: v8); /*0x103d7b22a*/
  qmemcpy(v8, __dst, 24); /*0x103d7b233*/
  memset(__dst, 0, sizeof(__dst)); /*0x103d7b241*/
  v50 = __dst; /*0x103d7b254*/
  std::vector<webrtc::CandidateStats>::__destroy_vector::operator()[abi:ne200100](a1: &v50); /*0x103d7b257*/
  v10 = *a3; /*0x103d7b25c*/
  v52 = a3[1]; /*0x103d7b263*/
  if ( v10 != v52 ) /*0x103d7b26a*/
  {
    while ( 1 ) /*0x103d7b278*/
    {
      v11 = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)v10 + 16LL) + 200LL); /*0x103d7b278*/
      if ( v11 != 0 ) /*0x103d7b282*/
        break; /*0x103d7b282*/
LABEL_17:
      v10 += 8; /*0x103d7b356*/
      if ( v10 == v52 ) /*0x103d7b35e*/
        goto LABEL_18; /*0x103d7b35e*/
    }
    v12 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v11 + 88LL))(a1: v11); /*0x103d7b28e*/
    v15 = v13; /*0x103d7b291*/
    if ( v13 >= 0xFFFFFFFFFFFFFFF8LL ) /*0x103d7b298*/
      std::string::__throw_length_error[abi:ne200100](a1: v14); /*0x103d7b5f9*/
    v16 = (const void *)v12; /*0x103d7b29e*/
    if ( v13 >= 0x17 ) /*0x103d7b2a5*/
    {
      v18 = (v13 | 7) + 1; /*0x103d7b2c0*/
      if ( (v13 | 7) == 0x17 ) /*0x103d7b2cd*/
        v18 = 26; /*0x103d7b2cd*/
      v19 = (const void *)v12; /*0x103d7b2d4*/
      v20 = operator new(a1: v18); /*0x103d7b2d7*/
      v16 = v19; /*0x103d7b2dc*/
      v17 = (_BYTE *)v20; /*0x103d7b2df*/
      *(_QWORD *)&__dst[16] = v20; /*0x103d7b2e2*/
      *(_QWORD *)__dst = v18 | 1; /*0x103d7b2ea*/
      *(_QWORD *)&__dst[8] = v15; /*0x103d7b2ee*/
    }
    else
    {
      __dst[0] = 2 * v13; /*0x103d7b2ab*/
      v17 = &__dst[1]; /*0x103d7b2ae*/
      if ( v13 == 0 ) /*0x103d7b2b5*/
        goto LABEL_14; /*0x103d7b2b5*/
    }
    memmove(__dst: v17, __src: v16, __len: v15); /*0x103d7b2f8*/
LABEL_14:
    v17[v15] = 0; /*0x103d7b2fd*/
    v50 = (_QWORD *)(*(__int64 (__fastcall **)(__int64, const void *))(*(_QWORD *)v11 + 96LL))(a1: v11, a2: v16); /*0x103d7b30b*/
    v21 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>( /*0x103d7b32b*/
            a1: v56,
            a2: v50,
            a3: std::piecewise_construct,
            a4: &v50,
            a5: &v55);
    v22 = v21; /*0x103d7b330*/
    if ( (*(_BYTE *)(v21 + 56) & 1) != 0 ) /*0x103d7b337*/
      operator delete(a1: *(void **)(v21 + 72)); /*0x103d7b33d*/
    qmemcpy((void *)(v22 + 56), __dst, 24); /*0x103d7b34a*/
    goto LABEL_17; /*0x103d7b34a*/
  }
LABEL_18:
  v23 = v47; /*0x103d7b364*/
  if ( *(_BYTE *)(v47 + 24) != 0 ) /*0x103d7b36f*/
  {
    *(_QWORD *)__dst = v49; /*0x103d7b37c*/
    v24 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>( /*0x103d7b391*/
            a1: v56,
            a2: v49,
            a3: std::piecewise_construct,
            a4: __dst,
            a5: &v50);
    std::string::operator=(a1: v24 + 56, a2: v23); /*0x103d7b3a0*/
  }
  *(_OWORD *)&__dst[8] = 0; /*0x103d7b3ac*/
  *(_QWORD *)__dst = &__dst[8]; /*0x103d7b3af*/
  v25 = *v56; /*0x103d7b3b7*/
  v26 = v48; /*0x103d7b3ba*/
  if ( *v56 != v48 ) /*0x103d7b3c4*/
  {
    do /*0x103d7b401*/
    {
      std::__tree<std::string>::__emplace_unique_key_args<std::string,std::string const&>(a1: __dst, a2: v25 + 56); /*0x103d7b3d4*/
      v27 = *((char **)v25 + 1); /*0x103d7b3d9*/
      if ( v27 != nullptr ) /*0x103d7b3e0*/
      {
        do /*0x103d7b3eb*/
        {
          v28 = v27; /*0x103d7b3e2*/
          v27 = *(char **)v27; /*0x103d7b3e5*/
        }
        while ( v27 != nullptr ); /*0x103d7b3eb*/
      }
      else
      {
        do /*0x103d7b3f9*/
        {
          v28 = *((char **)v25 + 2); /*0x103d7b3ef*/
          v29 = *(_QWORD *)v28 == (_QWORD)v25; /*0x103d7b3f3*/
          v25 = v28; /*0x103d7b3f6*/
        }
        while ( !v29 ); /*0x103d7b3f9*/
      }
      v25 = v28; /*0x103d7b3fb*/
    }
    while ( v28 != v26 ); /*0x103d7b401*/
  }
  (*(void (__fastcall **)(_QWORD **, _QWORD, _BYTE *))(**(_QWORD **)(v54 + 64) + 584LL))( /*0x103d7b419*/
    a1: &v50,
    a2: *(_QWORD *)(v54 + 64),
    a3: __dst);
  v30 = v50; /*0x103d7b426*/
  v31 = v58; /*0x103d7b42d*/
  if ( v50 != v51 ) /*0x103d7b431*/
  {
    v52 = v58 + 40; /*0x103d7b43b*/
    v56 = (char **)(v58 + 24); /*0x103d7b443*/
    do /*0x103d7b5a9*/
    {
      v32 = *((_QWORD *)v31 + 4); /*0x103d7b452*/
      if ( v32 >= *((_QWORD *)v31 + 5) ) /*0x103d7b45a*/
      {
        v33 = std::vector<webrtc::LegacyStatsCollector::TransportStats>::__emplace_back_slow_path<std::string const&,webrtc::TransportStats>( /*0x103d7b47d*/
                a1: v56,
                a2: v30 + 4,
                a3: v30 + 7);
      }
      else
      {
        std::allocator<webrtc::LegacyStatsCollector::TransportStats>::construct[abi:ne200100]<webrtc::LegacyStatsCollector::TransportStats,std::string const&,webrtc::TransportStats>( /*0x103d7b463*/
          a1: v52,
          a2: *((_QWORD *)v31 + 4),
          a3: v30 + 4,
          a4: v30 + 7);
        v33 = v32 + 88; /*0x103d7b468*/
      }
      *((_QWORD *)v31 + 4) = v33; /*0x103d7b480*/
      v55 = nullptr; /*0x103d7b489*/
      if ( (*(unsigned __int8 (__fastcall **)(_QWORD, __int64, webrtc::RTCCertificate **))(**(_QWORD **)(v54 + 64) /*0x103d7b4ab*/
                                                                                         + 608LL))(
             a1: *(_QWORD *)(v54 + 64),
             a2: v33 - 88,
             a3: &v55) != 0 )
      {
        webrtc::RTCCertificate::GetSSLCertificateChain(this: v55); /*0x103d7b4b1*/
        webrtc::SSLCertChain::GetStats(this: (webrtc::SSLCertChain *)v59); /*0x103d7b4bd*/
        v34 = v59[0]; /*0x103d7b4c7*/
        v59[0] = nullptr; /*0x103d7b4cb*/
        std::unique_ptr<webrtc::SSLCertificateStats>::reset[abi:ne200100](a1: v33 - 16, a2: v34); /*0x103d7b4cf*/
        v35 = v59[0]; /*0x103d7b4d4*/
        v59[0] = nullptr; /*0x103d7b4d8*/
        if ( v35 != nullptr ) /*0x103d7b4df*/
        {
          webrtc::SSLCertificateStats::~SSLCertificateStats(this: v35); /*0x103d7b4e4*/
          operator delete(a1: v35); /*0x103d7b4ec*/
        }
      }
      (*(void (__fastcall **)(webrtc::SSLCertificateStats **, _QWORD, __int64))(**(_QWORD **)(v54 + 64) + 616LL))( /*0x103d7b503*/
        a1: v59,
        a2: *(_QWORD *)(v54 + 64),
        a3: v33 - 88);
      v31 = v58; /*0x103d7b510*/
      if ( v59[0] != nullptr ) /*0x103d7b514*/
      {
        webrtc::SSLCertChain::GetStats(this: (webrtc::SSLCertChain *)&v53); /*0x103d7b51a*/
        v36 = v53; /*0x103d7b523*/
        v53 = nullptr; /*0x103d7b527*/
        std::unique_ptr<webrtc::SSLCertificateStats>::reset[abi:ne200100](a1: v33 - 8, a2: v36); /*0x103d7b52e*/
        v37 = v53; /*0x103d7b533*/
        v53 = nullptr; /*0x103d7b537*/
        if ( v37 != nullptr ) /*0x103d7b53e*/
        {
          webrtc::SSLCertificateStats::~SSLCertificateStats(this: v37); /*0x103d7b543*/
          operator delete(a1: v37); /*0x103d7b54b*/
        }
        v38 = v59[0]; /*0x103d7b550*/
        v59[0] = nullptr; /*0x103d7b554*/
        if ( v38 != nullptr ) /*0x103d7b55f*/
        {
          webrtc::SSLCertChain::~SSLCertChain(this: v38); /*0x103d7b564*/
          operator delete(a1: v38); /*0x103d7b56c*/
        }
      }
      webrtc::scoped_refptr<webrtc::RTCCertificate>::~scoped_refptr(a1: &v55); /*0x103d7b575*/
      v39 = (_QWORD *)v30[1]; /*0x103d7b57a*/
      if ( v39 != nullptr ) /*0x103d7b581*/
      {
        do /*0x103d7b58c*/
        {
          v40 = v39; /*0x103d7b583*/
          v39 = (_QWORD *)*v39; /*0x103d7b586*/
        }
        while ( v39 != nullptr ); /*0x103d7b58c*/
      }
      else
      {
        do /*0x103d7b59a*/
        {
          v40 = (_QWORD *)v30[2]; /*0x103d7b590*/
          v29 = *v40 == (_QWORD)v30; /*0x103d7b594*/
          v30 = v40; /*0x103d7b597*/
        }
        while ( !v29 ); /*0x103d7b59a*/
      }
      v30 = v40; /*0x103d7b59c*/
    }
    while ( v40 != v51 ); /*0x103d7b5a9*/
  }
  std::__tree<std::__value_type<std::string,webrtc::TransportStats>,std::__map_value_compare<std::string,std::__value_type<std::string,webrtc::TransportStats>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,webrtc::TransportStats>>>::destroy( /*0x103d7b5ba*/
    a1: &v50,
    a2: v51[0]);
  std::__tree<std::string>::destroy(a1: (__int64)__dst, a2: *(_QWORD **)&__dst[8]); /*0x103d7b5c7*/
  webrtc::Thread::ScopedDisallowBlockingCalls::~ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v46); /*0x103d7b5d3*/
  webrtc::trace_event_internal::TraceEndOnScopeClose::~TraceEndOnScopeClose(this: (webrtc::trace_event_internal::TraceEndOnScopeClose *)&v44); /*0x103d7b5df*/
  return v31; /*0x103d7b5e7*/
}

// Address: 0x103d7b7f6 | Name: __ZN6webrtc20LegacyStatsCollector39UpdateStatsFromExistingLocalAudioTracksEb
void __fastcall webrtc::LegacyStatsCollector::UpdateStatsFromExistingLocalAudioTracks(
        webrtc::LegacyStatsCollector *this,
        unsigned __int8 a2)
{
  __int64 v2; // r14
  webrtc::LegacyStatsCollector *v3; // rbx
  webrtc::AudioTrackInterface *v4; // r12
  int v5; // r15d
  __int64 v6; // rdi
  webrtc::StatsReport *Report; // r13
  webrtc::StatsReport::Value *Value; // rax
  unsigned __int8 *v9; // rbx
  _QWORD *v10; // rdi
  unsigned int v11; // eax
  size_t v12; // rdx
  int v13; // r9d
  unsigned __int8 v14; // bl
  __int64 v15; // rcx
  bool v16; // r15
  const void *v17; // rdi
  char *v18; // rsi
  __int64 v19; // [rsp+8h] [rbp-58h]
  unsigned __int8 v21; // [rsp+18h] [rbp-48h] BYREF
  char v22; // [rsp+19h] [rbp-47h] BYREF
  __int64 v23; // [rsp+20h] [rbp-40h]
  void *__s2; // [rsp+28h] [rbp-38h]
  int v25; // [rsp+30h] [rbp-30h] BYREF
  bool v26[44]; // [rsp+34h] [rbp-2Ch]

  v2 = *((_QWORD *)this + 13); /*0x103d7b807*/
  v19 = *((_QWORD *)this + 14); /*0x103d7b80f*/
  if ( v2 != v19 ) /*0x103d7b816*/
  {
    v3 = this; /*0x103d7b81c*/
    *(_DWORD *)v26 = a2; /*0x103d7b823*/
    do /*0x103d7b95d*/
    {
      v4 = *(webrtc::AudioTrackInterface **)v2; /*0x103d7b82a*/
      v5 = *(_DWORD *)(v2 + 8); /*0x103d7b82d*/
      v25 = 5; /*0x103d7b831*/
      absl::lts_20240116::strings_internal::SingleArgStrCat(this: (absl::lts_20240116::strings_internal *)&v21); /*0x103d7b842*/
      Report = (webrtc::StatsReport *)webrtc::LegacyStatsCollector::GetReport(a1: v3, a2: &v25, a3: &v21, a4: 0); /*0x103d7b858*/
      if ( (v21 & 1) != 0 ) /*0x103d7b85f*/
        operator delete(a1: __s2); /*0x103d7b865*/
      if ( Report != nullptr ) /*0x103d7b86d*/
      {
        Value = (webrtc::StatsReport::Value *)webrtc::StatsReport::FindValue(a1: Report, a2: 135); /*0x103d7b877*/
        if ( Value != nullptr ) /*0x103d7b87f*/
        {
          v9 = (unsigned __int8 *)webrtc::StatsReport::Value::string_val(this: Value); /*0x103d7b88d*/
          (*(void (__fastcall **)(unsigned __int8 *, webrtc::AudioTrackInterface *))(*(_QWORD *)v4 + 40LL))( /*0x103d7b89b*/
            a1: &v21,
            a2: v4);
          v10 = v9; /*0x103d7b89e*/
          v11 = *v9; /*0x103d7b8a1*/
          if ( (v11 & 1) != 0 ) /*0x103d7b8a6*/
            v12 = *((_QWORD *)v9 + 1); /*0x103d7b8a8*/
          else
            v12 = v11 >> 1; /*0x103d7b8e3*/
          v14 = v21; /*0x103d7b8e5*/
          if ( (v21 & 1) != 0 ) /*0x103d7b8ec*/
            v15 = v23; /*0x103d7b8ee*/
          else
            v15 = v21 >> 1; /*0x103d7b8f6*/
          v16 = true; /*0x103d7b8f8*/
          if ( v12 == v15 ) /*0x103d7b8fe*/
          {
            if ( (v11 & 1) != 0 ) /*0x103d7b902*/
              v17 = (const void *)v10[2]; /*0x103d7b904*/
            else
              v17 = (char *)v10 + 1; /*0x103d7b90a*/
            v18 = &v22; /*0x103d7b90d*/
            if ( (v21 & 1) != 0 ) /*0x103d7b914*/
              v18 = (char *)__s2; /*0x103d7b916*/
            v16 = memcmp(__s1: v17, __s2: v18, __n: v12) != 0; /*0x103d7b921*/
          }
          if ( (v14 & 1) != 0 ) /*0x103d7b928*/
            operator delete(a1: __s2); /*0x103d7b92e*/
          v3 = this; /*0x103d7b936*/
          if ( !v16 ) /*0x103d7b93a*/
          {
            *((_QWORD *)Report + 1) = *((_QWORD *)this + 11); /*0x103d7b941*/
            webrtc::LegacyStatsCollector::UpdateReportFromAudioTrack( /*0x103d7b950*/
              this: (webrtc::LegacyStatsCollector *)v10,
              a2: v4,
              a3: Report,
              a4: v26[0]);
          }
        }
      }
      else if ( (unsigned __int8)webrtc::LogMessage::IsNoop<(webrtc::LoggingSeverity)3>(a1: v6) == 0 ) /*0x103d7b8b5*/
      {
        webrtc::webrtc_logging_impl::Log( /*0x103d7b8da*/
          a1: (unsigned int)&webrtc::webrtc_logging_impl::LogStreamer<>::Call<webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)13,webrtc::webrtc_logging_impl::LogMetadata>,webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)9,char const*>,webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)4,unsigned int>>(webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)13,webrtc::webrtc_logging_impl::LogMetadata>,webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)9,char const*>,webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)4,unsigned int> const&)::t,
          a2: (unsigned int)"legacy_stats_collector.cc",
          a3: 10923,
          a4: (unsigned int)"Stats report does not exist for ssrc ",
          a5: v5,
          a6: v13);
      }
      v2 += 16; /*0x103d7b955*/
    }
    while ( v2 != v19 ); /*0x103d7b95d*/
  }
}

// Address: 0x103d7b9ee | Name: __ZN6webrtc20LegacyStatsCollector17ExtractDataInfo_nEPNS_15StatsCollectionE
void __fastcall webrtc::LegacyStatsCollector::ExtractDataInfo_n(
        webrtc::LegacyStatsCollector *this,
        webrtc::StatsCollection *a2)
{
  __int64 v3; // rbx
  __int64 i; // r14
  __int64 v5; // r13
  __int64 v6; // rdx
  char *v7; // rax
  _BYTE v8[16]; // [rsp+0h] [rbp-60h] BYREF
  __int64 v9; // [rsp+10h] [rbp-50h] BYREF
  __int64 v10; // [rsp+18h] [rbp-48h]
  webrtc::StatsCollection *v11; // [rsp+28h] [rbp-38h]
  _QWORD v12[6]; // [rsp+30h] [rbp-30h] BYREF

  v11 = a2; /*0x103d7b9ff*/
  webrtc::Thread::ScopedDisallowBlockingCalls::ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v8); /*0x103d7ba0a*/
  (*(void (__fastcall **)(__int64 *))(**((_QWORD **)this + 8) + 560LL))(a1: &v9); /*0x103d7ba1a*/
  v3 = v9; /*0x103d7ba20*/
  for ( i = v10; v3 != i; v3 += 88 ) /*0x103d7ba2b*/
  {
    webrtc::StatsReport::NewTypedIntId(a1: v12, a2: 11, a3: *(unsigned int *)(v3 + 4)); /*0x103d7ba40*/
    v5 = webrtc::StatsCollection::ReplaceOrAddNew(a1: v11, a2: v12); /*0x103d7ba51*/
    *(_QWORD *)(v5 + 8) = *((_QWORD *)this + 11); /*0x103d7ba5a*/
    webrtc::StatsReport::AddString(a1: v5, a2: 98, a3: v3 + 8); /*0x103d7ba6b*/
    v6 = *(unsigned int *)(v3 + 4); /*0x103d7ba70*/
    if ( (int)v6 >= 0 ) /*0x103d7ba75*/
      webrtc::StatsReport::AddInt(a1: v5, a2: 9, a3: v6); /*0x103d7ba7f*/
    webrtc::StatsReport::AddString(a1: v5, a2: 17, a3: v3 + 32); /*0x103d7ba90*/
    v7 = webrtc::DataChannelInterface::DataStateString(a1: *(_DWORD *)(v3 + 56)); /*0x103d7ba98*/
    webrtc::StatsReport::AddString(a1: v5, a2: 22, a3: v7); /*0x103d7baa8*/
    if ( v12[0] != 0 ) /*0x103d7bab4*/
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)v12[0] + 8LL))(a1: v12[0]); /*0x103d7bab9*/
  }
  v12[0] = &v9; /*0x103d7bad1*/
  std::vector<webrtc::DataChannelStats>::__destroy_vector::operator()[abi:ne200100](); /*0x103d7bad4*/
  webrtc::Thread::ScopedDisallowBlockingCalls::~ScopedDisallowBlockingCalls(this: (webrtc::Thread::ScopedDisallowBlockingCalls *)v8); /*0x103d7badd*/
}

// Address: 0x103d7bb7e | Name: __ZN6webrtc20LegacyStatsCollector9GetReportERKNS_11StatsReport9StatsTypeERKNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS1_9DirectionE
__int64 __fastcall webrtc::LegacyStatsCollector::GetReport(__int64 a1, unsigned int *a2, __int64 a3, __int64 a4)
{
  __int64 v4; // rbx
  __int64 v5; // rbx
  _QWORD v7[3]; // [rsp+8h] [rbp-18h] BYREF

  v4 = a1 + 8; /*0x103d7bb8c*/
  webrtc::StatsReport::NewIdWithDirection(a1: v7, a2: *a2, a3, a4); /*0x103d7bb99*/
  v5 = webrtc::StatsCollection::Find(a1: v4, a2: v7); /*0x103d7bba9*/
  if ( v7[0] != 0 ) /*0x103d7bbb3*/
    (*(void (__fastcall **)(_QWORD))(*(_QWORD *)v7[0] + 8LL))(a1: v7[0]); /*0x103d7bbb8*/
  return v5; /*0x103d7bbbe*/
}

// Address: 0x103d7bbec | Name: __ZN6webrtc20LegacyStatsCollector26UpdateReportFromAudioTrackEPNS_19AudioTrackInterfaceEPNS_11StatsReportEb
void __fastcall webrtc::LegacyStatsCollector::UpdateReportFromAudioTrack(
        webrtc::LegacyStatsCollector *this,
        webrtc::AudioTrackInterface *a2,
        webrtc::StatsReport *a3,
        unsigned __int8 a4)
{
  const webrtc::AudioProcessingStats *v7; // rdx
  _BYTE v8[8]; // [rsp+8h] [rbp-A8h] BYREF
  _BYTE v9[112]; // [rsp+10h] [rbp-A0h] BYREF
  __int64 v10; // [rsp+80h] [rbp-30h] BYREF
  _DWORD v11[9]; // [rsp+8Ch] [rbp-24h] BYREF

  if ( (*(unsigned __int8 (__fastcall **)(webrtc::AudioTrackInterface *, _DWORD *))(*(_QWORD *)a2 + 96LL))( /*0x103d7bc16*/
         a1: a2,
         a2: v11) != 0 )
    webrtc::StatsReport::AddInt(a1: a3, a2: 2, a3: v11[0]); /*0x103d7bc23*/
  (*(void (__fastcall **)(__int64 *, webrtc::AudioTrackInterface *))(*(_QWORD *)a2 + 104LL))(a1: &v10, a2); /*0x103d7bc35*/
  if ( v10 != 0 ) /*0x103d7bc3f*/
  {
    (*(void (__fastcall **)(_BYTE *, __int64, _QWORD))(*(_QWORD *)v10 + 32LL))(a1: v8, a2: v10, a3: a4); /*0x103d7bc4f*/
    webrtc::`anonymous namespace'::SetAudioProcessingStats(this: a3, a2: (webrtc::StatsReport *)v9, a3: v7); /*0x103d7bc5f*/
    webrtc::AudioProcessingStats::~AudioProcessingStats(this: (webrtc::AudioProcessingStats *)v9); /*0x103d7bc67*/
    if ( v10 != 0 ) /*0x103d7bc73*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v10 + 8LL))(a1: v10); /*0x103d7bc78*/
  }
}

// Address: 0x103d7bd8a | Name: __ZN6webrtc20LegacyStatsCollector15InvalidateCacheEv
void __fastcall webrtc::LegacyStatsCollector::InvalidateCache(webrtc::LegacyStatsCollector *this)
{
  *((_QWORD *)this + 10) = 0; /*0x103d7bd8e*/
}

// Address: 0x103d7e32a | Name: __ZN6webrtc20LegacyStatsCollector12SessionStatsaSEOS1_
__int64 __fastcall webrtc::LegacyStatsCollector::SessionStats::operator=(__int64 a1, __int64 a2)
{
  std::vector<webrtc::CandidateStats>::__vdeallocate(a1); /*0x103d7e33a*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x103d7e343*/
  *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x103d7e34a*/
  *(_QWORD *)(a2 + 16) = 0; /*0x103d7e351*/
  *(_OWORD *)a2 = 0; /*0x103d7e358*/
  std::vector<webrtc::LegacyStatsCollector::TransportStats>::__vdeallocate(a1: a1 + 24); /*0x103d7e360*/
  *(_OWORD *)(a1 + 24) = *(_OWORD *)(a2 + 24); /*0x103d7e36a*/
  *(_QWORD *)(a1 + 40) = *(_QWORD *)(a2 + 40); /*0x103d7e372*/
  *(_QWORD *)(a2 + 40) = 0; /*0x103d7e376*/
  *(_OWORD *)(a2 + 24) = 0; /*0x103d7e37d*/
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__move_assign( /*0x103d7e38d*/
    a1: a1 + 48,
    a2: a2 + 48);
  return a1; /*0x103d7e399*/
}

// END LegacyStatsCollector part 1/1, 32 functions
