// Host -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 2 functions


// Address: 0x106b2c106 | Name: __ZN17grpc_event_engine12experimental12TimerManager4Host3NowEv
__int64 __fastcall grpc_event_engine::experimental::TimerManager::Host::Now(
        grpc_event_engine::experimental::TimerManager::Host *this)
{
  __int64 v1; // rax
  __int64 v2; // rdx

  v1 = gpr_now(a1: 0); /*0x106b2c10c*/
  return grpc_core::Timestamp::FromTimespecRoundDown(a1: v1, a2: v2); /*0x106b2c117*/
}

// Address: 0x106b2c96a | Name: __ZN17grpc_event_engine12experimental12TimerManager4Host4KickEv
__int64 __fastcall grpc_event_engine::experimental::TimerManager::Host::Kick(
        grpc_event_engine::experimental::TimerManager **this)
{
  return grpc_event_engine::experimental::TimerManager::Kick(this: *(this + 1)); /*0x106b2c972*/
}

// END Host part 1/1, 2 functions
