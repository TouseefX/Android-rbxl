// RakNet -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 54 functions


// Address: 0x1039b42a5 | Name: __ZN6RakNet23buildCapabilitiesHelperERyN3RBX7Network8PeerTypeE
__int64 __fastcall RakNet::buildCapabilitiesHelper(__int64 *a1, unsigned int a2)
{
  __int64 v2; // rax
  __int64 v3; // rax
  unsigned __int64 v4; // rax
  __int64 v5; // rax
  unsigned __int64 v6; // rcx
  __int64 v7; // rcx
  __int64 v8; // rdx
  __int64 v9; // rcx
  unsigned __int64 v10; // rax
  unsigned __int64 v11; // rax
  unsigned __int64 v12; // rcx
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // rdx
  bool v16; // al
  __int64 v17; // rsi
  __int64 v18; // rdx
  __int64 v19; // rsi
  __int64 v20; // rdx
  unsigned __int64 v21; // rax
  __int64 v22; // rcx
  __int64 result; // rax
  __int64 v24; // rcx

  v2 = *a1; /*0x1039b42a9*/
  if ( DFFlag::DebugForceStreamingEnabled == 1 ) /*0x1039b42b3*/
  {
    v3 = v2 | 0x1C2; /*0x1039b42b5*/
    *a1 = v3; /*0x1039b42bb*/
  }
  else
  {
    v3 = v2 | 0xC2; /*0x1039b42c0*/
  }
  v4 = v3 /*0x1039b42e4*/
     | ((unsigned __int64)(unsigned __int8)FFlag::AvatarChatProtocolV1 << 38)
     | (4 * (unsigned int)(unsigned __int8)FFlag::VoxelGridLeanDM);
  if ( DFFlag::CLI139085 == 1 ) /*0x1039b42ee*/
  {
    v5 = v4 | 0x20000B10E30LL; /*0x1039b42fd*/
    *a1 = v5; /*0x1039b4303*/
  }
  else
  {
    v5 = v4 | 0x20000B10A30LL; /*0x1039b4312*/
  }
  v6 = v5 | (8 * (unsigned int)(a2 < 2)) | (unsigned __int64)((unsigned __int8)DFFlag::RaknetPacketTracing << 19); /*0x1039b432d*/
  if ( FFlag::DebugEnableStreamOutToDisk == 1 ) /*0x1039b433a*/
  {
    v7 = v6 | 0x4000002E000LL; /*0x1039b434d*/
    *a1 = v7; /*0x1039b4350*/
  }
  else
  {
    v7 = v6 | 0x2E000; /*0x1039b4355*/
  }
  v8 = v7 | 0x80000000000LL; /*0x1039b4366*/
  if ( FFlag::EnableStreamingBitStreamStateFlags == 0 ) /*0x1039b436e*/
    v8 = v7; /*0x1039b436e*/
  v9 = v8 | 0x100000000000LL; /*0x1039b437c*/
  if ( FFlag::EnableSharedStringCaching == 0 ) /*0x1039b4384*/
    v9 = v8; /*0x1039b4384*/
  v10 = v9 | ((unsigned __int64)(unsigned __int8)DFFlag::SimParentPrimSpacePVsRead << 45) | 0x40000; /*0x1039b4399*/
  if ( FFlag::AddCompressionInConnectionInternalSend == 1 && FFlag::DebugDisableCompressionInConnectionInternalSend == 0 ) /*0x1039b43b2*/
  {
    if ( DFFlag::PartiallyCompressPhysicsPackets == 1 ) /*0x1039b43be*/
    {
      v11 = v9 | ((unsigned __int64)(unsigned __int8)DFFlag::SimParentPrimSpacePVsRead << 45) | 0x2440000; /*0x1039b43c0*/
      *a1 = v11; /*0x1039b43c6*/
    }
    else
    {
      v11 = v9 | ((unsigned __int64)(unsigned __int8)DFFlag::SimParentPrimSpacePVsRead << 45) | 0x440000; /*0x1039b43cb*/
    }
    v12 = v11; /*0x1039b43d1*/
    v10 = v11 | 0x800000000LL; /*0x1039b43d4*/
    if ( DFFlag::AddHashToCompressedPayload == 0 ) /*0x1039b43e0*/
      v10 = v12; /*0x1039b43e0*/
  }
  v13 = v10 | 0x4000000; /*0x1039b43e7*/
  if ( FFlag::ServerTimeItem == 0 ) /*0x1039b43f5*/
    v13 = v10; /*0x1039b43f5*/
  v14 = v13 | 0x18000000; /*0x1039b43fc*/
  if ( FFlag::BugfixCLI184305 == 1 && FFlag::EnableNetAssetProxiesCache == 1 ) /*0x1039b4419*/
  {
    v15 = v13 | 0x38000000; /*0x1039b441b*/
    *a1 = v15; /*0x1039b4422*/
    v14 = v15; /*0x1039b4425*/
  }
  v16 = a2 == 1; /*0x1039b442b*/
  v17 = v14 | 0x80000000LL; /*0x1039b4438*/
  if ( DFFlag::BatchNetAssetJoinBlob == 0 ) /*0x1039b4440*/
    v17 = v14; /*0x1039b4440*/
  v18 = v17 | 0x400000000LL; /*0x1039b444e*/
  if ( DFFlag::ServerAuthorityEnableInputLatency == 0 ) /*0x1039b4456*/
    v18 = v17; /*0x1039b4456*/
  v19 = v18 | 0x1000000000000LL; /*0x1039b4464*/
  if ( DFFlag::ReplicateCameraStateForSA == 0 ) /*0x1039b446c*/
    v19 = v18; /*0x1039b446c*/
  v20 = v19 | 0x40000000000000LL; /*0x1039b447a*/
  if ( FFlag::PlayerControlStateEnabled == 0 ) /*0x1039b4482*/
    v20 = v19; /*0x1039b4482*/
  v21 = v20 /*0x1039b44a5*/
      | ((unsigned __int64)(((unsigned __int8)DFFlag::DebugNetworkProfilerForce
                           | (unsigned __int8)DFFlag::DebugNetworkProfiler & v16)
                          & 1) << 61)
      | 0x40000000;
  if ( FFlag::DebugAddTestStreamingFrustum != 0 /*0x1039b44ec*/
    || FFlag::StreamingObserverUsesOctree == 1
    && FFlag::UseExpandedSpatialQueryShapes == 1
    && FFlag::UseCoreSpatialQueryShapesForGC == 1
    && FFlag::EnableFrustumAutomation == 1 )
  {
    v21 |= 0x400000000000uLL; /*0x1039b44b7*/
  }
  v22 = v21 | 0x2000000000LL; /*0x1039b44f8*/
  if ( FFlag::SupportGcRegionQuotaSource == 0 ) /*0x1039b4500*/
    v22 = v21; /*0x1039b4500*/
  result = v22 | 0x300000000LL; /*0x1039b450e*/
  *a1 = v22 | 0x300000000LL; /*0x1039b4511*/
  if ( FFlag::ReplicateFocusTargetRadius == 1 ) /*0x1039b451e*/
  {
    v24 = v22 | 0x8300000000LL; /*0x1039b452a*/
    *a1 = v24; /*0x1039b452d*/
    result = v24; /*0x1039b4530*/
  }
  if ( DFFlag::AndroidSurfaceCompositor == 1 ) /*0x1039b453a*/
  {
    result |= 0x800000000000uLL; /*0x1039b453c*/
    *a1 = result; /*0x1039b4541*/
  }
  if ( DFFlag::PingItemReportClientMemory == 1 ) /*0x1039b454b*/
  {
    result |= 0x8000000000000uLL; /*0x1039b454d*/
    *a1 = result; /*0x1039b4552*/
  }
  if ( DFFlag::EvictDynamicMetadata == 1 ) /*0x1039b455c*/
  {
    result |= 0x4000000000000uLL; /*0x1039b455e*/
    *a1 = result; /*0x1039b4563*/
  }
  if ( FFlag::TagRuleReplicationPipelineEnabled == 1 && (FFlag::TagRuleCoreEnabled & 1) != 0 ) /*0x1039b457c*/
  {
    result |= 0x10000000000000uLL; /*0x1039b457e*/
    *a1 = result; /*0x1039b4583*/
  }
  if ( DFFlag::UseCompressedPVSerialization == 1 ) /*0x1039b458d*/
  {
    result |= 0x20000000000000uLL; /*0x1039b458f*/
    *a1 = result; /*0x1039b4594*/
  }
  return result; /*0x1039b4597*/
}

// Address: 0x1039b48c3 | Name: __ZN6RakNet7GetTimeEb
unsigned __int64 __fastcall RakNet::GetTime(RakNet *this)
{
  unsigned __int64 TimeUS_Linux; // rax

  if ( (_DWORD)this != 0 ) /*0x1039b48c9*/
    TimeUS_Linux = GetTimeUS_Linux(); /*0x1039b48cb*/
  else
    TimeUS_Linux = (unsigned int)(int)(RBX::Time::now(a1: 2) * 1000000.0); /*0x1039b4900*/
  return TimeUS_Linux / 0x3E8; /*0x1039b491b*/
}

// Address: 0x1039b491d | Name: __ZN6RakNet9GetTimeUSEb
__int64 __fastcall RakNet::GetTimeUS(RakNet *this)
{
  if ( (_DWORD)this != 0 ) /*0x1039b491f*/
    return GetTimeUS_Linux(); /*0x1039b491f*/
  else
    return (unsigned int)(int)(RBX::Time::now(a1: 2) * 1000000.0); /*0x1039b4957*/
}

// Address: 0x1039b495c | Name: __ZN6RakNet9GetTimeMSEv
unsigned __int64 __fastcall RakNet::GetTimeMS(RakNet *this)
{
  return (unsigned int)(int)(RBX::Time::now(a1: 2) * 1000000.0) / 0x3E8uLL; /*0x1039b49a9*/
}

// Address: 0x1039b4a11 | Name: __ZN6RakNet11GreaterThanEyy
unsigned __int64 __fastcall RakNet::GreaterThan(RakNet *this, __int64 a2)
{
  return (unsigned __int64)(a2 - (_QWORD)this) >> 63; /*0x1039b4a1f*/
}

// Address: 0x1039b4a21 | Name: __ZN6RakNet8LessThanEyy
bool __fastcall RakNet::LessThan(RakNet *this, RakNet *a2)
{
  return a2 != this && (unsigned __int64)(a2 - this) < 0x7FFFFFFFFFFFFFFFLL; /*0x1039b4a3d*/
}

// Address: 0x1039b4d52 | Name: __ZN6RakNet13SystemAddressaSERKS0_
__int64 __fastcall RakNet::SystemAddress::operator=(__int64 a1, __int128 *a2)
{
  __int128 v3; // xmm0

  v3 = *a2; /*0x1039b4d59*/
  *(_OWORD *)(a1 + 12) = *(__int128 *)((char *)a2 + 12); /*0x1039b4d60*/
  *(_OWORD *)a1 = v3; /*0x1039b4d64*/
  *(_DWORD *)(a1 + 28) = *((_DWORD *)a2 + 7); /*0x1039b4d6a*/
  return a1; /*0x1039b4d6d*/
}

// Address: 0x1039b4df4 | Name: __ZNK6RakNet10RakNetGUIDneERKS0_
bool __fastcall RakNet::RakNetGUID::operator!=(_QWORD *a1, _QWORD *a2)
{
  return *a1 != *a2; /*0x1039b4e01*/
}

// Address: 0x1039b5017 | Name: __ZN6RakNet20NonNumericHostStringEPKc
bool __fastcall RakNet::NonNumericHostString(RakNet *this, const char *a2)
{
  return (unsigned __int8)(*(_BYTE *)this - 48) >= 0xAu /*0x1039b5023*/
      && (*(_BYTE *)this != 45 || (unsigned __int8)(*((_BYTE *)this + 1) - 48) >= 0xAu)
      && strchr(__s: (const char *)this, __c: 58) == nullptr;
}

// Address: 0x1039b52d4 | Name: __ZNK6RakNet13SystemAddresseqERKS0_
__int64 __fastcall RakNet::SystemAddress::operator==(RakNet::SystemAddress *a1, const RakNet::SystemAddress *a2)
{
  if ( *((_WORD *)a1 + 1) == *((_WORD *)a2 + 1) ) /*0x1039b52e0*/
    return RakNet::SystemAddress::EqualsExcludingPort(this: a1, a2); /*0x1039b52e3*/
  else
    return 0; /*0x1039b52e8*/
}

// Address: 0x1039b52ec | Name: __ZNK6RakNet13SystemAddressneERKS0_
char __fastcall RakNet::SystemAddress::operator!=(RakNet::SystemAddress *a1, const RakNet::SystemAddress *a2)
{
  char result; // al

  result = 1; /*0x1039b52f0*/
  if ( *((_WORD *)a1 + 1) == *((_WORD *)a2 + 1) ) /*0x1039b52f6*/
    return RakNet::SystemAddress::EqualsExcludingPort(this: a1, a2) ^ 1; /*0x1039b5301*/
  return result; /*0x1039b5304*/
}

// Address: 0x1039b5306 | Name: __ZNK6RakNet13SystemAddressgtERKS0_
bool __fastcall RakNet::SystemAddress::operator>(__int64 a1, __int64 a2)
{
  unsigned __int16 v2; // ax
  bool v3; // cf
  bool v4; // zf
  unsigned __int8 v5; // al
  unsigned int v6; // eax
  unsigned __int64 v8; // rax
  unsigned __int64 v9; // rcx
  int v10; // edx

  v2 = *(_WORD *)(a2 + 2); /*0x1039b530a*/
  v3 = *(_WORD *)(a1 + 2) < v2; /*0x1039b530e*/
  v4 = *(_WORD *)(a1 + 2) == v2; /*0x1039b530e*/
  if ( *(_WORD *)(a1 + 2) != v2 ) /*0x1039b5312*/
    return !v3 && !v4; /*0x1039b5312*/
  v5 = *(_BYTE *)(a1 + 1); /*0x1039b5314*/
  v3 = v5 < *(_BYTE *)(a2 + 1); /*0x1039b5317*/
  v4 = v5 == *(_BYTE *)(a2 + 1); /*0x1039b5317*/
  if ( v5 != *(_BYTE *)(a2 + 1) ) /*0x1039b531a*/
    return !v3 && !v4; /*0x1039b531a*/
  if ( v5 == 2 ) /*0x1039b531e*/
  {
    v6 = *(_DWORD *)(a1 + 4); /*0x1039b5320*/
    v3 = v6 < *(_DWORD *)(a2 + 4); /*0x1039b5323*/
    v4 = v6 == *(_DWORD *)(a2 + 4); /*0x1039b5323*/
    return !v3 && !v4; /*0x1039b532a*/
  }
  v8 = _byteswap_uint64(*(_QWORD *)(a1 + 8)); /*0x1039b532f*/
  v9 = _byteswap_uint64(*(_QWORD *)(a2 + 8)); /*0x1039b5336*/
  if ( v8 != v9
    || (v8 = _byteswap_uint64(*(_QWORD *)(a1 + 16)), v9 = _byteswap_uint64(*(_QWORD *)(a2 + 16)), v10 = 0, v8 != v9) )
  {
    v10 = v8 < v9 ? -1 : 1;
  }
  return v10 > 0; /*0x1039b5329*/
}

// Address: 0x1039b5364 | Name: __ZNK6RakNet13SystemAddressltERKS0_
char __fastcall RakNet::SystemAddress::operator<(__int64 a1, __int64 a2)
{
  unsigned __int16 v2; // ax
  bool v3; // cf
  unsigned __int8 v4; // al
  int v5; // eax
  unsigned __int64 v6; // rcx
  unsigned __int64 v7; // rdx
  unsigned int v8; // eax

  v2 = *(_WORD *)(a2 + 2); /*0x1039b5368*/
  v3 = *(_WORD *)(a1 + 2) < v2; /*0x1039b536c*/
  if ( *(_WORD *)(a1 + 2) != v2 ) /*0x1039b5370*/
    goto LABEL_5; /*0x1039b5370*/
  v4 = *(_BYTE *)(a1 + 1); /*0x1039b5372*/
  v3 = v4 < *(_BYTE *)(a2 + 1); /*0x1039b5375*/
  if ( v4 != *(_BYTE *)(a2 + 1) ) /*0x1039b5378*/
    goto LABEL_5; /*0x1039b5378*/
  if ( v4 == 2 ) /*0x1039b537c*/
  {
    v3 = *(_DWORD *)(a1 + 4) < *(_DWORD *)(a2 + 4); /*0x1039b5381*/
LABEL_5:
    LOBYTE(v5) = v3; /*0x1039b5384*/
    return v5; /*0x1039b5388*/
  }
  v6 = _byteswap_uint64(*(_QWORD *)(a1 + 8)); /*0x1039b538d*/
  v7 = _byteswap_uint64(*(_QWORD *)(a2 + 8)); /*0x1039b5394*/
  if ( v6 != v7
    || (v6 = _byteswap_uint64(*(_QWORD *)(a1 + 16)), v7 = _byteswap_uint64(*(_QWORD *)(a2 + 16)), v8 = 0, v6 != v7) )
  {
    v8 = v6 < v7 ? -1 : 1;
  }
  return v8 >> 31; /*0x1039b5387*/
}

// Address: 0x1039b58a8 | Name: __ZNK6RakNet10RakNetGUIDeqERKS0_
bool __fastcall RakNet::RakNetGUID::operator==(_QWORD *a1, _QWORD *a2)
{
  return *a1 == *a2; /*0x1039b58b5*/
}

// Address: 0x1039b58b8 | Name: __ZNK6RakNet10RakNetGUIDgtERKS0_
bool __fastcall RakNet::RakNetGUID::operator>(_QWORD *a1, _QWORD *a2)
{
  return *a1 > *a2; /*0x1039b58c5*/
}

// Address: 0x1039b58c8 | Name: __ZNK6RakNet10RakNetGUIDltERKS0_
bool __fastcall RakNet::RakNetGUID::operator<(_QWORD *a1, _QWORD *a2)
{
  return *a1 < *a2; /*0x1039b58d5*/
}

// Address: 0x1039b62f5 | Name: __ZN6RakNet8isLogPktEh
const char *__fastcall RakNet::isLogPkt(RakNet *this)
{
  int v1; // eax
  const char *result; // rax
  int v3; // eax
  unsigned int v4; // edi
  int v5; // eax

  if ( (unsigned int)this > 0x1C ) /*0x1039b62fc*/
    goto LABEL_8; /*0x1039b62fc*/
  v1 = 127281152; /*0x1039b62fe*/
  if ( _bittest(&v1, (unsigned int)this) ) /*0x1039b6303*/
    return "failure"; /*0x1039b630f*/
  v3 = 268435942; /*0x1039b6311*/
  if ( _bittest(&v3, (unsigned int)this) ) /*0x1039b6316*/
  {
    result = nullptr; /*0x1039b6322*/
    if ( DFFlag::LogUnusedMessages != 0 ) /*0x1039b632b*/
      return "unused"; /*0x1039b632b*/
  }
  else
  {
LABEL_8:
    v4 = (_DWORD)this - 120; /*0x1039b6331*/
    if ( v4 <= 6 && (v5 = 105, _bittest(&v5, v4)) ) /*0x1039b633e*/
      return "handshake"; /*0x1039b6343*/
    else
      return "unknown"; /*0x1039b634c*/
  }
  return result; /*0x1039b634a*/
}

// Address: 0x1039b6355 | Name: __ZN6RakNet6LogPktENS_13SystemAddressES0_PKciS2_b
__int64 __fastcall RakNet::LogPkt(
        unsigned __int8 *a1,
        int a2,
        const char *a3,
        unsigned __int8 a4,
        __int64 a5,
        __int64 a6,
        char a7,
        __int64 a8,
        __int64 a9,
        __int64 a10,
        char a11)
{
  const char *v15; // rax
  const char *v16; // r15
  int v17; // r13d
  __int64 v18; // rax
  __int64 v19; // rbx
  __int64 v20; // r14
  int v21; // r15d
  const char *v23; // [rsp+8h] [rbp-848h]
  const char *v24; // [rsp+10h] [rbp-840h]
  unsigned __int8 v25; // [rsp+1Ch] [rbp-834h]
  char v26[512]; // [rsp+20h] [rbp-830h] BYREF
  char v27[1024]; // [rsp+220h] [rbp-630h] BYREF
  char v28[512]; // [rsp+620h] [rbp-230h] BYREF

  v15 = RakNet::isLogPkt(this: (RakNet *)*a1); /*0x1039b6385*/
  if ( v15 != nullptr ) /*0x1039b638d*/
  {
    v16 = v15; /*0x1039b6393*/
    RakNet::SystemAddress::ToStringN(this: (RakNet::SystemAddress *)&a7, a2: true, a3: v28, a4: 512, a5: 124); /*0x1039b63b1*/
    v17 = a2 - 1; /*0x1039b63bc*/
    if ( DFInt::NumberOfBytesToLogForPktTracing < v17 ) /*0x1039b63c2*/
      v17 = DFInt::NumberOfBytesToLogForPktTracing; /*0x1039b63c2*/
    v18 = 0; /*0x1039b63c6*/
    v23 = a3; /*0x1039b63cb*/
    if ( v17 > 0 ) /*0x1039b63d2*/
    {
      v25 = a4; /*0x1039b63d4*/
      v24 = v16; /*0x1039b63da*/
      v19 = 204; /*0x1039b63e4*/
      if ( (unsigned int)v17 < 0xCCuLL ) /*0x1039b63ec*/
        v19 = (unsigned int)v17; /*0x1039b63ec*/
      v20 = 0; /*0x1039b63f7*/
      v21 = 0; /*0x1039b63fa*/
      do /*0x1039b642c*/
        v21 += snprintf(__str: &v27[v21], __size: 1024LL - v21, __format: "%#x ", a1[++v20]); /*0x1039b6423*/
      while ( v19 != v20 ); /*0x1039b642c*/
      v18 = v21; /*0x1039b642e*/
      v16 = v24; /*0x1039b6431*/
      a4 = v25; /*0x1039b6438*/
    }
    v27[v18] = 0; /*0x1039b643e*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v26, a2: nullptr); /*0x1039b6452*/
    if ( RakNet::SystemAddress::operator!=(a1: (RakNet::SystemAddress *)&a11, a2: (const RakNet::SystemAddress *)v26) != 0 ) /*0x1039b6468*/
      RakNet::SystemAddress::ToStringN(this: (RakNet::SystemAddress *)&a11, a2: true, a3: v26, a4: 512, a5: 124); /*0x1039b6484*/
    else
      v26[0] = 0; /*0x1039b648b*/
    if ( (unsigned __int8)DFLog::RakNetPktTrace >= 6u && BYTE1(DFLog::RakNetPktTrace) >= 3u ) /*0x1039b64a7*/
      FLog::FastLogFormatted( /*0x1039b64ea*/
        a1: (FLog *)DFLog::RakNetPktTrace,
        a2: qword_10D7BB2F8,
        a3: "[DFLog::RakNetPktTrace] [%s][%s][ext=%s][%s][drop=%d][%#x][%s]",
        v23,
        v28,
        v26,
        v16,
        a4,
        *a1,
        v27);
  }
  return __stack_chk_guard; /*0x1039b6503*/
}

// Address: 0x1039b82bf | Name: __ZN6RakNet12OP_NEW_ARRAYINS_7RakPeer18RemoteSystemStructEEEPT_iPKcj
_QWORD *__fastcall RakNet::OP_NEW_ARRAY<RakNet::RakPeer::RemoteSystemStruct>(int a1)
{
  __int64 v1; // r15
  __int64 v2; // rax
  bool v3; // cl
  bool v4; // cf
  __int64 v5; // rax
  unsigned __int64 v6; // rdi
  _QWORD *v7; // rax
  _QWORD *v8; // r14
  __int64 v9; // r13
  __int64 v10; // r12
  RakNet::RakPeer::RemoteSystemStruct *v11; // r15

  if ( a1 == 0 ) /*0x1039b82cf*/
    return nullptr; /*0x1039b8330*/
  v1 = a1; /*0x1039b82d1*/
  v2 = 5368LL * a1; /*0x1039b82dc*/
  v3 = (0x14F8 * (unsigned __int128)(unsigned __int64)a1) >> 64 != 0; /*0x1039b82df*/
  v4 = __CFADD__(v2, 8); /*0x1039b82e2*/
  v5 = v2 + 8; /*0x1039b82e2*/
  v6 = -1; /*0x1039b82e6*/
  if ( v4 ) /*0x1039b82ed*/
    v5 = -1; /*0x1039b82ed*/
  if ( !v3 ) /*0x1039b82f3*/
    v6 = v5; /*0x1039b82f3*/
  v7 = (_QWORD *)operator new[](a1: v6); /*0x1039b82f7*/
  *v7 = v1; /*0x1039b82ff*/
  v8 = v7 + 1; /*0x1039b8302*/
  v9 = -5368 * v1; /*0x1039b8306*/
  v10 = 0; /*0x1039b830d*/
  v11 = (RakNet::RakPeer::RemoteSystemStruct *)(v7 + 1); /*0x1039b8310*/
  do /*0x1039b832c*/
  {
    RakNet::RakPeer::RemoteSystemStruct::RemoteSystemStruct(this: v11); /*0x1039b8316*/
    v10 -= 5368; /*0x1039b831b*/
    v11 = (RakNet::RakPeer::RemoteSystemStruct *)((char *)v11 + 5368); /*0x1039b8322*/
  }
  while ( v9 != v10 ); /*0x1039b832c*/
  return v8; /*0x1039b833a*/
}

// Address: 0x1039b84b6 | Name: __ZN6RakNet17UpdateNetworkLoopEPv
__int64 __fastcall RakNet::UpdateNetworkLoop(RakNet *this, void *a2)
{
  const char *v3; // rsi
  void *v4; // rsi
  int v5; // ebx
  int v6; // r12d
  unsigned __int64 v7; // rbx
  __int64 v8; // r12
  void (__fastcall *v9)(RakNet *, _QWORD); // rax
  unsigned __int64 v10; // r12
  void (__fastcall *v11)(RakNet *, _QWORD); // rax
  __int64 v12; // r12
  void (__fastcall *v13)(RakNet *, _QWORD); // rax
  int v14; // esi
  unsigned __int8 v15; // r8
  __int64 Token; // r12
  unsigned __int8 v17; // r8
  unsigned int v18; // esi
  _QWORD v20[4]; // [rsp+0h] [rbp-220h] BYREF
  _BYTE v21[32]; // [rsp+20h] [rbp-200h] BYREF
  unsigned __int64 v22[2]; // [rsp+40h] [rbp-1E0h] BYREF
  __int64 v23; // [rsp+50h] [rbp-1D0h]
  __int64 v24; // [rsp+58h] [rbp-1C8h]
  __int128 v25; // [rsp+60h] [rbp-1C0h]
  __int128 v26; // [rsp+70h] [rbp-1B0h]
  __int128 v27; // [rsp+80h] [rbp-1A0h]
  int v28; // [rsp+90h] [rbp-190h]
  __int128 v29; // [rsp+98h] [rbp-188h]
  _BYTE v30[16]; // [rsp+A8h] [rbp-178h] BYREF
  unsigned __int64 TimeUS; // [rsp+B8h] [rbp-168h] BYREF
  unsigned int v32; // [rsp+C4h] [rbp-15Ch]
  _BYTE v33[296]; // [rsp+C8h] [rbp-158h] BYREF

  v32 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::RakNet, (unsigned int)a2); /*0x1039b84e6*/
  RBX::setThreadName(this: (RBX *)"RakNet::UpdateNetworkLoop", a2: v3); /*0x1039b84f3*/
  RBX::Profiler::onThreadCreateSized(a1: "RakNet::UpdateNetworkLoop", a2: 2u); /*0x1039b8504*/
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v33, a2: 0x5D4u); /*0x1039b8515*/
  *((_BYTE *)this + 161) = 1; /*0x1039b851c*/
  v20[0] = this; /*0x1039b852a*/
  v20[3] = (char *)&RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<RakNet::UpdateNetworkLoop(void *)::$_0>(RakNet::UpdateNetworkLoop(void *)::$_0)::Callback /*0x1039b8534*/
         + 2;
  RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<24ul,8ul>(a1: v21, a2: v20); /*0x1039b8542*/
  RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v20, a2: v4); /*0x1039b854a*/
  while ( 1 ) /*0x1039b855d*/
  {
    if ( (*((_BYTE *)this + 160) & 1) != 0 ) /*0x1039b8566*/
    {
      RakNet::SimpleMutex::Lock(this: (RakNet *)((char *)this + 1656)); /*0x1039b856b*/
      v5 = *((_DWORD *)this + 410); /*0x1039b8570*/
      v6 = *((_DWORD *)this + 411); /*0x1039b8577*/
      RakNet::SimpleMutex::Unlock(this: (RakNet *)((char *)this + 1656)); /*0x1039b8581*/
      if ( v5 == v6 ) /*0x1039b8589*/
        break; /*0x1039b8589*/
    }
    TimeUS = RakNet::GetTimeUS(this: nullptr); /*0x1039b8596*/
    v7 = TimeUS / 0x3E8; /*0x1039b85b1*/
    if ( (*((_BYTE *)this + 162) & 1) != 0 ) /*0x1039b85be*/
    {
      RakNet::RakPeer::notifyAllAndFlagForShutdown(a1: this, a2: 0, a3: 0); /*0x1039b88f6*/
      v22[0] = (unsigned int)v7; /*0x1039b8904*/
      RakNet::RakPeer::HandleActiveSystemList(this, a2: (RakNet::BitStream *)v33, a3: &TimeUS, a4: v22); /*0x1039b8918*/
      *((_BYTE *)this + 160) = 1; /*0x1039b891f*/
      *((_BYTE *)this + 163) = 1; /*0x1039b8928*/
      break; /*0x1039b8928*/
    }
    if ( DFFlag::AddProfilerTelemetryScopeForRakNet == 1 ) /*0x1039b85cb*/
    {
      if ( FFlag::DebugClientDumpMicroprofileForJoins != 1 ) /*0x1039b85db*/
      {
        if ( (_BYTE)`guard variable for'RakNet::UpdateNetworkLoop(void *)::proftoken7296 == 0 /*0x1039b8800*/
          && __cxa_guard_acquire(a1: &`guard variable for'RakNet::UpdateNetworkLoop(void *)::proftoken7296) != 0 )
        {
          v22[0] = (unsigned __int64)"Log::CameraTrace] CameraCapture::~CameraCapture"; /*0x1039b882c*/
          Token = RBX::Profiler::getToken( /*0x1039b8853*/
                    this: (RBX::Profiler *)&aSimcsgiterativ[-1042703],
                    a2: &aDflogCameratra_0[-12571],
                    a3: (const char *)0xFFFFFFFFLL,
                    a4: 255,
                    a5: v15);
          RBX::Profiler::PerFrameTelemetry::activateForTelemetry(a1: Token); /*0x1039b8859*/
          RakNet::UpdateNetworkLoop(void *)::proftoken7296 = Token; /*0x1039b885e*/
          __cxa_guard_release(a1: &`guard variable for'RakNet::UpdateNetworkLoop(void *)::proftoken7296); /*0x1039b886c*/
        }
        v8 = RakNet::UpdateNetworkLoop(void *)::proftoken7296; /*0x1039b85ef*/
        *(_OWORD *)v22 = 0; /*0x1039b85f9*/
        v24 = -1; /*0x1039b8600*/
        v27 = 0; /*0x1039b8612*/
        v26 = 0; /*0x1039b8616*/
        v25 = 0; /*0x1039b861a*/
        v28 = 0; /*0x1039b861d*/
        v29 = 0; /*0x1039b8624*/
        v23 = RakNet::UpdateNetworkLoop(void *)::proftoken7296; /*0x1039b8628*/
        RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v22); /*0x1039b8636*/
        v24 = RBX::Profiler::PerFrameTelemetry::enterTelemetryRegion(a1: v8, a2: v30, a3: 1); /*0x1039b864f*/
        v9 = *((void (__fastcall **)(RakNet *, _QWORD))this + 312); /*0x1039b8656*/
        if ( v9 != nullptr ) /*0x1039b8660*/
          v9(a1: this, a2: *((_QWORD *)this + 313)); /*0x1039b866c*/
        v10 = (*(__int64 (__fastcall **)(RakNet *, unsigned __int64, _QWORD, _BYTE *))(*(_QWORD *)this + 992LL))( /*0x1039b868a*/
                a1: this,
                a2: TimeUS,
                a3: (unsigned int)v7,
                a4: v33);
        RBX::Profiler::TelemetryScope::~TelemetryScope(this: (RBX::Profiler::TelemetryScope *)v22); /*0x1039b8694*/
        goto LABEL_20; /*0x1039b8699*/
      }
LABEL_13:
      v11 = *((void (__fastcall **)(RakNet *, _QWORD))this + 312); /*0x1039b86ba*/
      if ( v11 != nullptr ) /*0x1039b86c4*/
        v11(a1: this, a2: *((_QWORD *)this + 313)); /*0x1039b86d0*/
      v10 = (*(__int64 (__fastcall **)(RakNet *, unsigned __int64, _QWORD, _BYTE *))(*(_QWORD *)this + 992LL))( /*0x1039b86ee*/
              a1: this,
              a2: TimeUS,
              a3: (unsigned int)v7,
              a4: v33);
      goto LABEL_20; /*0x1039b86f1*/
    }
    if ( *RBX::Profiler::active == 0 || FFlag::DebugClientDumpMicroprofileForJoins != 0 ) /*0x1039b86b8*/
      goto LABEL_13; /*0x1039b86b8*/
    if ( (_BYTE)`guard variable for'RakNet::UpdateNetworkLoop(void *)::proftoken7307 == 0 /*0x1039b8884*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::UpdateNetworkLoop(void *)::proftoken7307) != 0 )
    {
      v22[0] = (unsigned __int64)"orAssetID"; /*0x1039b88b0*/
      RakNet::UpdateNetworkLoop(void *)::proftoken7307 = RBX::Profiler::getToken( /*0x1039b88d7*/
                                                           this: (RBX::Profiler *)&aWrapdeformerme_0[-924694],
                                                           a2: &aGetcreatorasse[-815772],
                                                           a3: (const char *)0xFFFFFFFFLL,
                                                           a4: 255,
                                                           a5: v17);
      __cxa_guard_release(a1: &`guard variable for'RakNet::UpdateNetworkLoop(void *)::proftoken7307); /*0x1039b88e5*/
    }
    v12 = RakNet::UpdateNetworkLoop(void *)::proftoken7307; /*0x1039b8704*/
    *(_OWORD *)v22 = 0; /*0x1039b870e*/
    v24 = -1; /*0x1039b8715*/
    v27 = 0; /*0x1039b8727*/
    v26 = 0; /*0x1039b872b*/
    v25 = 0; /*0x1039b872f*/
    v28 = 0; /*0x1039b8732*/
    v29 = 0; /*0x1039b8739*/
    v23 = RakNet::UpdateNetworkLoop(void *)::proftoken7307; /*0x1039b873d*/
    RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v22); /*0x1039b874b*/
    v24 = RBX::Profiler::enterRegion(a1: v12, a2: -1, a3: 0); /*0x1039b8761*/
    v13 = *((void (__fastcall **)(RakNet *, _QWORD))this + 312); /*0x1039b8768*/
    if ( v13 != nullptr ) /*0x1039b8772*/
      v13(a1: this, a2: *((_QWORD *)this + 313)); /*0x1039b877e*/
    v10 = (*(__int64 (__fastcall **)(RakNet *, unsigned __int64, _QWORD, _BYTE *))(*(_QWORD *)this + 992LL))( /*0x1039b879c*/
            a1: this,
            a2: TimeUS,
            a3: (unsigned int)v7,
            a4: v33);
    RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v22); /*0x1039b87a6*/
LABEL_20:
    if ( (*((_BYTE *)this + 160) & 1) != 0 ) /*0x1039b87b4*/
      *((_BYTE *)this + 163) = 1; /*0x1039b87b8*/
    v14 = DFInt::RakNetLoopMs; /*0x1039b87d9*/
    if ( DFInt::RakNetLoopMs >= (int)(v10 / 0x3E8 - v7) ) /*0x1039b87e1*/
      v14 = v10 / 0x3E8 - v7; /*0x1039b87e3*/
    RakNet::SignaledEvent::WaitOnEvent(this: (RakNet *)((char *)this + 2560), a2: v14); /*0x1039b87e8*/
  }
  Defer::~Defer(this: (Defer *)v21); /*0x1039b892f*/
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v33); /*0x1039b8942*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v32, a2: v18); /*0x1039b894d*/
  return 0; /*0x1039b8964*/
}

// Address: 0x1039b8a0e | Name: __ZN6RakNet12RecvFromLoopEPv
__int64 __fastcall RakNet::RecvFromLoop(RakNet *this, void *a2)
{
  const char *v3; // rsi
  __int64 v4; // r14
  void *v5; // rsi
  __int64 v6; // rax
  __int64 v7; // r12
  RakNet::SocketLayer *v8; // rdi
  int *v9; // r15
  __int64 v10; // rbx
  __int128 *v11; // r13
  __int64 v12; // r8
  __int64 v13; // r9
  __int128 v14; // xmm0
  __int64 v15; // rbx
  __int64 v16; // rdi
  unsigned int v17; // esi
  RakNet::SystemAddress *v19; // [rsp+8h] [rbp-E8h]
  _QWORD v20[4]; // [rsp+40h] [rbp-B0h] BYREF
  _BYTE v21[32]; // [rsp+60h] [rbp-90h] BYREF
  __int128 v22; // [rsp+80h] [rbp-70h]
  __int128 v23; // [rsp+90h] [rbp-60h]
  RakNet::SignaledEvent *v24; // [rsp+A0h] [rbp-50h]
  RakNet::SimpleMutex *v25; // [rsp+A8h] [rbp-48h]
  _DWORD v26[4]; // [rsp+B4h] [rbp-3Ch]
  RBX::Memory *v27; // [rsp+C4h] [rbp-2Ch]

  LODWORD(v27) = RBX::Memory::setCurrentCategory( /*0x1039b8a30*/
                   this: (RBX::Memory *)(unsigned int)RBX::Memory::RakNet,
                   (unsigned int)a2);
  RBX::setThreadName(this: (RBX *)"RakNet::RecvFromLoop", a2: v3); /*0x1039b8a3a*/
  RBX::Profiler::onThreadCreateSized(a1: "RakNet::RecvFromLoop", a2: 2u); /*0x1039b8a4b*/
  v4 = *((_QWORD *)this + 1); /*0x1039b8a50*/
  v26[0] = *(_DWORD *)this; /*0x1039b8a56*/
  RakNet::LocklessUint32_t::Increment(this: (RakNet::LocklessUint32_t *)(v4 + 164)); /*0x1039b8a60*/
  v20[0] = v4; /*0x1039b8a6c*/
  v20[3] = (char *)RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<RakNet::RecvFromLoop(void *)::$_0>(RakNet::RecvFromLoop(void *)::$_0)::Callback /*0x1039b8a76*/
         + 2;
  RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<24ul,8ul>(a1: v21, a2: v20); /*0x1039b8a84*/
  RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v20, a2: v5); /*0x1039b8a8c*/
  if ( (*(_BYTE *)(v4 + 162) & 1) == 0 ) /*0x1039b8a9a*/
  {
    *(_QWORD *)&v26[1] = v4 + 1352; /*0x1039b8aa7*/
    v24 = (RakNet::SignaledEvent *)(v4 + 2560); /*0x1039b8ab2*/
    v25 = (RakNet::SimpleMutex *)(v4 + 1384); /*0x1039b8abd*/
    do /*0x1039b8ace*/
    {
      v6 = DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Allocate( /*0x1039b8ace*/
             a1: *(__int64 **)&v26[1],
             a2: (unsigned __int64)"",
             a3: 0);
      v7 = v6; /*0x1039b8ad3*/
      if ( v6 != 0 ) /*0x1039b8ad9*/
      {
        v8 = (RakNet::SocketLayer *)v26[0]; /*0x1039b8adf*/
        *(_DWORD *)(v6 + 1536) = v26[0]; /*0x1039b8ae2*/
        v9 = (int *)(v6 + 1492); /*0x1039b8aea*/
        v10 = v6 + 1496; /*0x1039b8af2*/
        v11 = (__int128 *)(v6 + 1540); /*0x1039b8b05*/
        RakNet::SocketLayer::RecvFromBlocking( /*0x1039b8b1c*/
          this: v8,
          a2: v4,
          a3: (RakNet::RakPeer *)v6,
          a4: (char *)(v6 + 1492),
          a5: (int *)(v6 + 1496),
          a6: (RakNet::SystemAddress *)(v6 + 1528),
          a7: (unsigned __int64 *)(v6 + 1540),
          a8: v19);
        if ( DFInt::FirstValidPort <= (unsigned __int16)RakNet::SystemAddress::GetPort(this: (RakNet::SystemAddress *)(v7 + 1496)) ) /*0x1039b8b32*/
        {
          v15 = *v9; /*0x1039b8bac*/
          if ( v15 > 0 ) /*0x1039b8bb2*/
          {
            *(_QWORD *)(v7 + 1528) += (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 912LL))(a1: v4); /*0x1039b8bc0*/
            DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Push( /*0x1039b8bcf*/
              a1: *(__int64 *)&v26[1],
              a2: v7);
            RakNet::SignaledEvent::SetEvent(this: v24); /*0x1039b8bd8*/
            v16 = *(_QWORD *)(v4 + 3392); /*0x1039b8bdd*/
            if ( v16 != 0 ) /*0x1039b8be7*/
              (*(void (__fastcall **)(__int64, __int64, double))(*(_QWORD *)v16 + 16LL))(a1: v16, a2: v15, a3: 0.0); /*0x1039b8bf2*/
            continue; /*0x1039b8bf5*/
          }
        }
        else
        {
          if ( (_BYTE)DFLog::RakNetPktTrace != 0 ) /*0x1039b8b3b*/
          {
            v14 = *v11; /*0x1039b8b3d*/
            v23 = *(_OWORD *)(v7 + 1556); /*0x1039b8b47*/
            v22 = v14; /*0x1039b8b4b*/
            RakNet::LogPkt( /*0x1039b8b88*/
              a1: (unsigned __int8 *)v7,
              a2: *(_DWORD *)(v7 + 1492),
              a3: "Rx",
              a4: 1u,
              a5: v12,
              a6: v13,
              a7: *(_OWORD *)v10,
              a8: *(_QWORD *)(v10 + 8),
              a9: *(_QWORD *)(v7 + 1512),
              a10: *(_QWORD *)(v7 + 1520),
              a11: v14);
          }
          if ( DFFlag::ReportPktDropStats2 == 1 ) /*0x1039b8b94*/
            _InterlockedIncrement((volatile signed __int32 *)(v4 + 3480)); /*0x1039b8b96*/
        }
        RakNet::SimpleMutex::Lock(this: v25); /*0x1039b8bfb*/
        DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::Release(a1: *(__int64 *)&v26[1], a2: (_QWORD *)v7); /*0x1039b8c10*/
        RakNet::SimpleMutex::Unlock(this: v25); /*0x1039b8c19*/
      }
      else
      {
        RakSleep(a1: 0x1Eu); /*0x1039b8ba5*/
      }
    }
    while ( (*(_BYTE *)(v4 + 162) & 1) == 0 ); /*0x1039b8ace*/
  }
  Defer::~Defer(this: (Defer *)v21); /*0x1039b8c2d*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)v27, a2: v17); /*0x1039b8c3c*/
  return 0; /*0x1039b8c43*/
}

// Address: 0x1039bf18a | Name: __ZN6RakNet16RakNetStatisticspLERKS0_
__int64 __fastcall RakNet::RakNetStatistics::operator+=(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  __int64 i; // rcx
  __int64 j; // rcx

  result = a1; /*0x1039bf18e*/
  for ( i = 0; i != 16; i += 4 ) /*0x1039bf191*/
  {
    *(_DWORD *)(a1 + i + 360) += *(_DWORD *)(a2 + i + 360); /*0x1039bf19a*/
    *(double *)(a1 + 2 * i + 376) = *(double *)(a2 + 2 * i + 376) + *(double *)(a1 + 2 * i + 376); /*0x1039bf1b3*/
  }
  for ( j = 32; j != 40; ++j ) /*0x1039bf1c6*/
  {
    *(_QWORD *)(a1 + 8 * j - 64) += *(_QWORD *)(a2 + 8 * j - 64); /*0x1039bf1d0*/
    *(_QWORD *)(a1 + 8 * j) += *(_QWORD *)(a2 + 8 * j); /*0x1039bf1d9*/
  }
  return result; /*0x1039bf1e6*/
}

// Address: 0x1039c24db | Name: __ZN6RakNet17notifyOutOfMemoryEPKcl
__int64 *__fastcall RakNet::notifyOutOfMemory(RakNet *this, const char *a2)
{
  __int64 *result; // rax

  result = &FLog::Network; /*0x1039c24e2*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1039c24fc*/
    return (__int64 *)FLog::FastLogFormatted( /*0x1039c2512*/
                        a1: (FLog *)FLog::Network,
                        a2: qword_10D7BBAA8,
                        a3: "[FLog::Network] out of memory in raknet at callsite %ld",
                        a2);
  return result; /*0x1039c2511*/
}

// Address: 0x1039cd6d8 | Name: __ZN6RakNet25CheckOverloadedRecvThreadERjS0_Rd
void __fastcall RakNet::CheckOverloadedRecvThread(RakNet *this, unsigned int *a2, unsigned int *a3, double *a4)
{
  ; /*0x1039cd6d8*/
}

// Address: 0x1039d1d5f | Name: __ZN6RakNet12OP_NEW_ARRAYINS_9RakStringEEEPT_iPKcj
_QWORD *__fastcall RakNet::OP_NEW_ARRAY<RakNet::RakString>(int a1)
{
  __int64 v1; // r14
  unsigned __int64 v2; // r13
  unsigned __int64 v3; // rax
  _QWORD *v4; // rax
  _QWORD *v5; // r14
  __int64 v6; // r13
  __int64 v7; // r12
  RakNet::RakString *v8; // r15

  if ( a1 == 0 ) /*0x1039d1d6f*/
    return nullptr; /*0x1039d1dc6*/
  v1 = a1; /*0x1039d1d71*/
  v2 = 8LL * a1; /*0x1039d1d74*/
  v3 = v2 + 8; /*0x1039d1d7f*/
  if ( v2 >= 0xFFFFFFFFFFFFFFF8LL ) /*0x1039d1d8a*/
    v3 = -1; /*0x1039d1d8a*/
  if ( a1 < 0 ) /*0x1039d1d90*/
    v3 = -1; /*0x1039d1d90*/
  v4 = (_QWORD *)operator new[](a1: v3); /*0x1039d1d97*/
  *v4 = v1; /*0x1039d1d9f*/
  v5 = v4 + 1; /*0x1039d1da2*/
  v6 = -(__int64)v2; /*0x1039d1da6*/
  v7 = 0; /*0x1039d1da9*/
  v8 = (RakNet::RakString *)(v4 + 1); /*0x1039d1dac*/
  do /*0x1039d1dc2*/
  {
    RakNet::RakString::RakString(this: v8); /*0x1039d1db2*/
    v7 -= 8; /*0x1039d1db7*/
    v8 = (RakNet::RakString *)((char *)v8 + 8); /*0x1039d1dbb*/
  }
  while ( v6 != v7 ); /*0x1039d1dc2*/
  return v5; /*0x1039d1dd0*/
}

// Address: 0x1039d2039 | Name: __ZN6RakNet12OP_NEW_ARRAYINS_13SystemAddressEEEPT_iPKcj
__int64 __fastcall RakNet::OP_NEW_ARRAY<RakNet::SystemAddress>(int a1)
{
  __int64 v1; // r14
  bool v2; // sf
  unsigned __int64 v3; // rdi
  __int64 v4; // rbx
  __int64 v5; // r15

  if ( a1 == 0 ) /*0x1039d2045*/
    return 0; /*0x1039d207a*/
  v1 = 32LL * a1; /*0x1039d204a*/
  v2 = a1 < 0; /*0x1039d204e*/
  v3 = -1; /*0x1039d2050*/
  if ( !v2 ) /*0x1039d2057*/
    v3 = v1; /*0x1039d2057*/
  v4 = operator new[](a1: v3); /*0x1039d2060*/
  v5 = 0; /*0x1039d2063*/
  do /*0x1039d2076*/
  {
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)(v4 + v5)); /*0x1039d206a*/
    v5 += 32; /*0x1039d206f*/
  }
  while ( v1 != v5 ); /*0x1039d2076*/
  return v4; /*0x1039d2083*/
}

// Address: 0x1039d213d | Name: __ZN6RakNet12OP_NEW_ARRAYINS_10RakNetGUIDEEEPT_iPKcj
__int64 __fastcall RakNet::OP_NEW_ARRAY<RakNet::RakNetGUID>(int a1)
{
  __int64 v1; // r14
  bool v2; // sf
  unsigned __int64 v3; // rdi
  __int64 v4; // rbx
  __int64 v5; // r15

  if ( a1 == 0 ) /*0x1039d2149*/
    return 0; /*0x1039d217e*/
  v1 = 16LL * a1; /*0x1039d214e*/
  v2 = a1 < 0; /*0x1039d2152*/
  v3 = -1; /*0x1039d2154*/
  if ( !v2 ) /*0x1039d215b*/
    v3 = v1; /*0x1039d215b*/
  v4 = operator new[](a1: v3); /*0x1039d2164*/
  v5 = 0; /*0x1039d2167*/
  do /*0x1039d217a*/
  {
    RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)(v4 + v5)); /*0x1039d216e*/
    v5 += 16; /*0x1039d2173*/
  }
  while ( v1 != v5 ); /*0x1039d217a*/
  return v4; /*0x1039d2187*/
}

// Address: 0x1039d7556 | Name: __ZN6RakNet9RakStringaSERKS0_
RakNet::RakString *__fastcall RakNet::RakString::operator=(RakNet::RakString *a1, RakNet::SimpleMutex ***a2)
{
  RakNet::SimpleMutex **v4; // r15
  RakNet::SimpleMutex **v5; // rax
  int v6; // ecx

  RakNet::RakString::Free(this: a1); /*0x1039d7566*/
  v4 = (RakNet::SimpleMutex **)&RakNet::RakString::emptyString; /*0x1039d756e*/
  if ( *a2 != (RakNet::SimpleMutex **)&RakNet::RakString::emptyString ) /*0x1039d7578*/
  {
    RakNet::SimpleMutex::Lock(this: **a2); /*0x1039d757d*/
    v5 = *a2; /*0x1039d7582*/
    v6 = *((_DWORD *)*a2 + 2); /*0x1039d7585*/
    if ( v6 != 0 ) /*0x1039d758a*/
    {
      *((_DWORD *)v5 + 2) = v6 + 1; /*0x1039d758e*/
      v4 = v5; /*0x1039d7591*/
    }
    *(_QWORD *)a1 = v4; /*0x1039d7594*/
    RakNet::SimpleMutex::Unlock(this: **a2); /*0x1039d759d*/
  }
  return a1; /*0x1039d75a9*/
}

// Address: 0x1039d75b0 | Name: __ZN6RakNet9RakStringaSEPKc
RakNet::RakString *__fastcall RakNet::RakString::operator=(RakNet::RakString *this, char *a2)
{
  RakNet::RakString::Free(this); /*0x1039d75bd*/
  RakNet::RakString::Assign(this, a2); /*0x1039d75c8*/
  return this; /*0x1039d75d0*/
}

// Address: 0x1039d75d6 | Name: __ZN6RakNet9RakStringaSEPc
RakNet::RakString *__fastcall RakNet::RakString::operator=(RakNet::RakString *this, char *a2)
{
  RakNet::RakString::Free(this); /*0x1039d75e3*/
  RakNet::RakString::Assign(this, a2); /*0x1039d75ee*/
  return this; /*0x1039d75f6*/
}

// Address: 0x1039d75fc | Name: __ZN6RakNet9RakStringaSEPKh
RakNet::RakString *__fastcall RakNet::RakString::operator=(RakNet::RakString *this, char *a2)
{
  RakNet::RakString::Free(this); /*0x1039d7609*/
  RakNet::RakString::Assign(this, a2); /*0x1039d7614*/
  return this; /*0x1039d761c*/
}

// Address: 0x1039d7622 | Name: __ZN6RakNet9RakStringaSEPh
RakNet::RakString *__fastcall RakNet::RakString::operator=(RakNet::RakString *this, char *a2)
{
  RakNet::RakString::Free(this); /*0x1039d762f*/
  RakNet::RakString::Assign(this, a2); /*0x1039d763a*/
  return this; /*0x1039d7642*/
}

// Address: 0x1039d7648 | Name: __ZN6RakNet9RakStringaSEc
RakNet::RakString *__fastcall RakNet::RakString::operator=(RakNet::RakString *this, char a2)
{
  char v4[18]; // [rsp+Eh] [rbp-12h] BYREF

  v4[0] = a2; /*0x1039d765a*/
  v4[1] = 0; /*0x1039d765d*/
  RakNet::RakString::Free(this); /*0x1039d7662*/
  RakNet::RakString::Assign(this, a2: v4); /*0x1039d766d*/
  return this; /*0x1039d7675*/
}

// Address: 0x1039d76f6 | Name: __ZN6RakNet9RakStringpLERKS0_
RakNet::RakString *__fastcall RakNet::RakString::operator+=(RakNet::RakString *this, RakNet::SimpleMutex ***a2)
{
  size_t v4; // r15
  size_t v5; // rax
  __int64 v6; // rdi

  if ( *a2 != (RakNet::SimpleMutex **)&RakNet::RakString::emptyString ) /*0x1039d770e*/
  {
    if ( *(_UNKNOWN **)this == &RakNet::RakString::emptyString ) /*0x1039d7716*/
    {
      RakNet::RakString::operator=(a1: this, a2); /*0x1039d7766*/
    }
    else
    {
      RakNet::RakString::Clone(this); /*0x1039d771b*/
      v4 = strlen(__s: (const char *)(*a2)[4]); /*0x1039d772c*/
      v5 = strlen(__s: *(const char **)(*(_QWORD *)this + 32LL)); /*0x1039d7737*/
      RakNet::RakString::Realloc(a1: v6, a2: *(_QWORD *)this, a3: v4 + 2 * v5 + 1); /*0x1039d7746*/
      strcat(__s1: *(char **)(*(_QWORD *)this + 32LL), __s2: (const char *)(*a2)[4]); /*0x1039d7759*/
    }
  }
  return this; /*0x1039d776e*/
}

// Address: 0x1039d7800 | Name: __ZN6RakNet9RakStringpLEPKc
RakNet::RakString *__fastcall RakNet::RakString::operator+=(RakNet::RakString *this, char *a2)
{
  size_t v4; // r15
  size_t v5; // rax
  __int64 v6; // rdi

  if ( a2 != nullptr && *a2 != 0 ) /*0x1039d7819*/
  {
    if ( *(_UNKNOWN **)this == &RakNet::RakString::emptyString ) /*0x1039d7825*/
    {
      RakNet::RakString::Assign(this, a2); /*0x1039d786d*/
    }
    else
    {
      RakNet::RakString::Clone(this); /*0x1039d782a*/
      v4 = strlen(__s: a2); /*0x1039d7837*/
      v5 = strlen(__s: *(const char **)(*(_QWORD *)this + 32LL)); /*0x1039d7842*/
      RakNet::RakString::Realloc(a1: v6, a2: *(_QWORD *)this, a3: v4 + v5 + 1); /*0x1039d7851*/
      strcat(__s1: *(char **)(*(_QWORD *)this + 32LL), __s2: a2); /*0x1039d7860*/
    }
  }
  return this; /*0x1039d7875*/
}

// Address: 0x1039d787e | Name: __ZN6RakNet9RakStringpLEPc
RakNet::RakString *__fastcall RakNet::RakString::operator+=(RakNet::RakString *this, char *a2)
{
  return RakNet::RakString::operator+=(this, a2); /*0x1039d7882*/
}

// Address: 0x1039d7888 | Name: __ZN6RakNet9RakStringpLEPKh
RakNet::RakString *__fastcall RakNet::RakString::operator+=(RakNet::RakString *this, char *a2)
{
  return RakNet::RakString::operator+=(this, a2); /*0x1039d788c*/
}

// Address: 0x1039d7892 | Name: __ZN6RakNet9RakStringpLEPh
RakNet::RakString *__fastcall RakNet::RakString::operator+=(RakNet::RakString *this, char *a2)
{
  return RakNet::RakString::operator+=(this, a2); /*0x1039d7896*/
}

// Address: 0x1039d789c | Name: __ZN6RakNet9RakStringpLEc
RakNet::RakString *__fastcall RakNet::RakString::operator+=(RakNet::RakString *a1, char a2)
{
  char v4[10]; // [rsp+0h] [rbp-Ah] BYREF

  v4[0] = a2; /*0x1039d78a9*/
  v4[1] = 0; /*0x1039d78ac*/
  RakNet::RakString::operator+=(this: a1, a2: v4); /*0x1039d78b3*/
  return a1; /*0x1039d78bf*/
}

// Address: 0x1039d78c2 | Name: __ZNK6RakNet9RakStringixEj
__int64 __fastcall RakNet::RakString::operator[](__int64 a1, unsigned int a2)
{
  return *(unsigned __int8 *)(*(_QWORD *)(*(_QWORD *)a1 + 32LL) + a2); /*0x1039d78d3*/
}

// Address: 0x1039d78d6 | Name: __ZNK6RakNet9RakStringeqERKS0_
bool __fastcall RakNet::RakString::operator==(__int64 a1, __int64 a2)
{
  return strcmp(__s1: *(const char **)(*(_QWORD *)a1 + 32LL), __s2: *(const char **)(*(_QWORD *)a2 + 32LL)) == 0; /*0x1039d78f2*/
}

// Address: 0x1039d78f4 | Name: __ZNK6RakNet9RakStringeqEPKc
bool __fastcall RakNet::RakString::operator==(__int64 a1, const char *a2)
{
  return strcmp(__s1: *(const char **)(*(_QWORD *)a1 + 32LL), __s2: a2) == 0; /*0x1039d7909*/
}

// Address: 0x1039d790c | Name: __ZNK6RakNet9RakStringeqEPc
bool __fastcall RakNet::RakString::operator==(__int64 a1, const char *a2)
{
  return strcmp(__s1: *(const char **)(*(_QWORD *)a1 + 32LL), __s2: a2) == 0; /*0x1039d7921*/
}

// Address: 0x1039d7924 | Name: __ZNK6RakNet9RakStringltERKS0_
__int64 __fastcall RakNet::RakString::operator<(__int64 a1, __int64 a2)
{
  return (unsigned int)strcmp( /*0x1039d793e*/
                         __s1: *(const char **)(*(_QWORD *)a1 + 32LL),
                         __s2: *(const char **)(*(_QWORD *)a2 + 32LL)) >> 31;
}

// Address: 0x1039d7940 | Name: __ZNK6RakNet9RakStringleERKS0_
bool __fastcall RakNet::RakString::operator<=(__int64 a1, __int64 a2)
{
  return strcmp(__s1: *(const char **)(*(_QWORD *)a1 + 32LL), __s2: *(const char **)(*(_QWORD *)a2 + 32LL)) <= 0; /*0x1039d795c*/
}

// Address: 0x1039d795e | Name: __ZNK6RakNet9RakStringgtERKS0_
bool __fastcall RakNet::RakString::operator>(__int64 a1, __int64 a2)
{
  return strcmp(__s1: *(const char **)(*(_QWORD *)a1 + 32LL), __s2: *(const char **)(*(_QWORD *)a2 + 32LL)) > 0; /*0x1039d797a*/
}

// Address: 0x1039d797c | Name: __ZNK6RakNet9RakStringgeERKS0_
bool __fastcall RakNet::RakString::operator>=(__int64 a1, __int64 a2)
{
  return strcmp(__s1: *(const char **)(*(_QWORD *)a1 + 32LL), __s2: *(const char **)(*(_QWORD *)a2 + 32LL)) >= 0; /*0x1039d7998*/
}

// Address: 0x1039d799a | Name: __ZNK6RakNet9RakStringneERKS0_
bool __fastcall RakNet::RakString::operator!=(__int64 a1, __int64 a2)
{
  return strcmp(__s1: *(const char **)(*(_QWORD *)a1 + 32LL), __s2: *(const char **)(*(_QWORD *)a2 + 32LL)) != 0; /*0x1039d79b6*/
}

// Address: 0x1039d79b8 | Name: __ZNK6RakNet9RakStringneEPKc
bool __fastcall RakNet::RakString::operator!=(__int64 a1, const char *a2)
{
  return strcmp(__s1: *(const char **)(*(_QWORD *)a1 + 32LL), __s2: a2) != 0; /*0x1039d79cd*/
}

// Address: 0x1039d79d0 | Name: __ZNK6RakNet9RakStringneEPc
bool __fastcall RakNet::RakString::operator!=(__int64 a1, const char *a2)
{
  return strcmp(__s1: *(const char **)(*(_QWORD *)a1 + 32LL), __s2: a2) != 0; /*0x1039d79e5*/
}

// Address: 0x1039d979e | Name: __ZN6RakNet15SplitPacketListixEj
__int64 __fastcall RakNet::SplitPacketList::operator[](_QWORD *a1, unsigned int a2)
{
  if ( (__int64)(a1[1] - *a1) >> 3 <= (unsigned __int64)a2 ) /*0x1039d97b1*/
    std::vector<RakNet::InternalPacket *>::__throw_out_of_range[abi:ne200100](a1); /*0x1039d97bc*/
  return *a1 + 8LL * a2; /*0x1039d97b7*/
}

// Address: 0x1039da692 | Name: __ZN6RakNet22SplitPacketChannelCompERKtRKPNS_18SplitPacketChannelE
__int64 __fastcall RakNet::SplitPacketChannelComp(unsigned __int16 *a1, __int64 a2)
{
  unsigned int v2; // eax
  bool v3; // cc
  _BOOL4 v4; // edx
  __int64 result; // rax

  v2 = *a1; /*0x1039da696*/
  v3 = *(_DWORD *)(*(_QWORD *)a2 + 40LL) <= v2; /*0x1039da69e*/
  v4 = *(_DWORD *)(*(_QWORD *)a2 + 40LL) != v2; /*0x1039da6a1*/
  result = 0xFFFFFFFFLL; /*0x1039da6a4*/
  if ( v3 ) /*0x1039da6a9*/
    return v4; /*0x1039da6a9*/
  return result; /*0x1039da6ac*/
}

// Address: 0x1039e0ed6 | Name: __ZN6RakNet8TxBwDatapLERKS0_
__m128i *__fastcall RakNet::TxBwData::operator+=(__m128i *a1, const __m128i *a2)
{
  __m128i v3; // xmm0

  v3 = _mm_loadu_si128(a1 + 1); /*0x1039e0eeb*/
  *a1 = _mm_add_epi32(_mm_loadu_si128(a1), _mm_loadu_si128(a2)); /*0x1039e0ef0*/
  a1[1] = _mm_add_epi32(_mm_loadu_si128(a2 + 1), v3); /*0x1039e0efd*/
  a1[2].i32[0] += a2[2].i32[0]; /*0x1039e0f05*/
  RakNet::TxBwInfluencers::operator+=(a1: (char *)a1[2].i64 + 4, a2: (char *)a2[2].i64 + 4); /*0x1039e0f10*/
  return a1; /*0x1039e0f1c*/
}

// Address: 0x1039e2148 | Name: __ZN6RakNet15TxBwInfluencerspLERKS0_
__m128i *__fastcall RakNet::TxBwInfluencers::operator+=(__m128i *a1, const __m128i *a2)
{
  __m128i v3; // xmm0

  v3 = _mm_loadu_si128(a1 + 1); /*0x1039e215b*/
  *a1 = _mm_add_epi32(_mm_loadu_si128(a1), _mm_loadu_si128(a2)); /*0x1039e2160*/
  a1[1] = _mm_add_epi32(_mm_loadu_si128(a2 + 1), v3); /*0x1039e216d*/
  a1[2].i64[0] = _mm_add_epi32(_mm_loadl_epi64(a1 + 2), _mm_loadl_epi64(a2 + 2)).u64[0]; /*0x1039e2180*/
  a1[2].i32[2] += a2[2].i32[2]; /*0x1039e2188*/
  return a1; /*0x1039e218b*/
}

// END RakNet part 1/1, 54 functions
