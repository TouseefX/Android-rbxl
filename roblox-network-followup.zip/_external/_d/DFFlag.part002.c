// DFFlag -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 400 functions, part 2 of 8


// Address: 0x10292e54e | Name: __ZN6DFFlagL66rbxImplDynInit_DisableTriangleCountCheckForWMSDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DisableTriangleCountCheckForWMSDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10292e565*/
           a1: (__int64)"DisableTriangleCountCheckForWMS",
           a2: (__int64)&DFFlag::DisableTriangleCountCheckForWMS,
           a3: 2u);
}

// Address: 0x10292e56b | Name: __ZN6DFFlagL52rbxImplDynInit_CheckQuadricErrorDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CheckQuadricErrorDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"CheckQuadricError", a2: (__int64)&DFFlag::CheckQuadricError, a3: 2u); /*0x10292e582*/
}

// Address: 0x10292e588 | Name: __ZN6DFFlagL69rbxImplDynInit_WMSRemoveInteriorBidirectionalRaysDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_WMSRemoveInteriorBidirectionalRaysDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10292e59f*/
           a1: (__int64)"WMSRemoveInteriorBidirectionalRays",
           a2: (__int64)&DFFlag::WMSRemoveInteriorBidirectionalRays,
           a3: 2u);
}

// Address: 0x10292e5a5 | Name: __ZN6DFFlagL73rbxImplDynInit_WMSDuplicateLodVerticesOppositeNormalsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_WMSDuplicateLodVerticesOppositeNormalsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10292e5bc*/
           a1: (__int64)"WMSDuplicateLodVerticesOppositeNormals",
           a2: (__int64)&DFFlag::WMSDuplicateLodVerticesOppositeNormals,
           a3: 2u);
}

// Address: 0x1029ce280 | Name: __ZN6DFFlagL54rbxImplDynInit_FixHastefulEdgeCaseDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FixHastefulEdgeCaseDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"FixHastefulEdgeCase", a2: (__int64)&DFFlag::FixHastefulEdgeCase, a3: 2u); /*0x1029ce297*/
}

// Address: 0x1029e8eba | Name: __ZN6DFFlagL47rbxImplDynInit_CLI185000FixDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CLI185000FixDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"CLI185000Fix", a2: (__int64)&DFFlag::CLI185000Fix, a3: 2u); /*0x1029e8ed1*/
}

// Address: 0x102a02216 | Name: __ZN6DFFlagL82rbxImplDynInit_NextGenReplicatorEnabledWriteServerSynchronizedDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_NextGenReplicatorEnabledWriteServerSynchronizedDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0222d*/
           a1: (__int64)"NextGenReplicatorEnabledWriteServerSynchronized",
           a2: (__int64)&DFFlag::NextGenReplicatorEnabledWriteServerSynchronized,
           a3: 2u);
}

// Address: 0x102a023ec | Name: __ZN6DFFlagL67rbxImplDynInit_DebugISRForcePacketToFinishGroupDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugISRForcePacketToFinishGroupDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a02403*/
           a1: (__int64)"DebugISRForcePacketToFinishGroup",
           a2: (__int64)&DFFlag::DebugISRForcePacketToFinishGroup,
           a3: 2u);
}

// Address: 0x102a02461 | Name: __ZN6DFFlagL48rbxImplDynInit_CLI183138PostDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CLI183138PostDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"CLI183138Post", a2: (__int64)&DFFlag::CLI183138Post, a3: 2u); /*0x102a02478*/
}

// Address: 0x102a024d7 | Name: __ZN6DFFlagL47rbxImplDynInit_CLI183138PreDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CLI183138PreDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"CLI183138Pre", a2: (__int64)&DFFlag::CLI183138Pre, a3: 2u); /*0x102a024ee*/
}

// Address: 0x102a025a4 | Name: __ZN6DFFlagL73rbxImplDynInit_UseLowerFrequencyForISRPhysicsOnlyModeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_UseLowerFrequencyForISRPhysicsOnlyModeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a025bb*/
           a1: (__int64)"UseLowerFrequencyForISRPhysicsOnlyMode",
           a2: (__int64)&DFFlag::UseLowerFrequencyForISRPhysicsOnlyMode,
           a3: 2u);
}

// Address: 0x102a0261a | Name: __ZN6DFFlagL71rbxImplDynInit_DeferTriggerReplicationPVDirtySignalDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DeferTriggerReplicationPVDirtySignalDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a02631*/
           a1: (__int64)"DeferTriggerReplicationPVDirtySignal",
           a2: (__int64)&DFFlag::DeferTriggerReplicationPVDirtySignal,
           a3: 2u);
}

// Address: 0x102a027cf | Name: __ZN6DFFlagL64rbxImplDynInit_ChangeFlagGuardsForNewTerrainDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_ChangeFlagGuardsForNewTerrainDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a027e6*/
           a1: (__int64)"ChangeFlagGuardsForNewTerrain",
           a2: (__int64)&DFFlag::ChangeFlagGuardsForNewTerrain,
           a3: 2u);
}

// Address: 0x102a028d8 | Name: __ZN6DFFlagL60rbxImplDynInit_SimParentPrimSpacePVsReadDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SimParentPrimSpacePVsReadDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a028ef*/
           a1: (__int64)"SimParentPrimSpacePVsRead",
           a2: (__int64)&DFFlag::SimParentPrimSpacePVsRead,
           a3: 2u);
}

// Address: 0x102a02988 | Name: __ZN6DFFlagL56rbxImplDynInit_BatchNetAssetJoinBlobDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_BatchNetAssetJoinBlobDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"BatchNetAssetJoinBlob", a2: (__int64)&DFFlag::BatchNetAssetJoinBlob, a3: 2u); /*0x102a0299f*/
}

// Address: 0x102a029a5 | Name: __ZN6DFFlagL68rbxImplDynInit_ServerAuthorityEnableInputLatencyDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_ServerAuthorityEnableInputLatencyDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a029bc*/
           a1: (__int64)"ServerAuthorityEnableInputLatency",
           a2: (__int64)&DFFlag::ServerAuthorityEnableInputLatency,
           a3: 2u);
}

// Address: 0x102a029df | Name: __ZN6DFFlagL60rbxImplDynInit_ReplicateCameraStateForSADynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_ReplicateCameraStateForSADynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a029f6*/
           a1: (__int64)"ReplicateCameraStateForSA",
           a2: (__int64)&DFFlag::ReplicateCameraStateForSA,
           a3: 2u);
}

// Address: 0x102a029fc | Name: __ZN6DFFlagL63rbxImplDynInit_FixScratchSpaceLatencyBypassDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FixScratchSpaceLatencyBypassDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a02a13*/
           a1: (__int64)"FixScratchSpaceLatencyBypass",
           a2: (__int64)&DFFlag::FixScratchSpaceLatencyBypass,
           a3: 2u);
}

// Address: 0x102a02cf8 | Name: __ZN6DFFlagL60rbxImplDynInit_DebugNetworkProfilerForceDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugNetworkProfilerForceDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a02d0f*/
           a1: (__int64)"DebugNetworkProfilerForce",
           a2: (__int64)&DFFlag::DebugNetworkProfilerForce,
           a3: 2u);
}

// Address: 0x102a02d15 | Name: __ZN6DFFlagL55rbxImplDynInit_DebugNetworkProfilerDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugNetworkProfilerDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"DebugNetworkProfiler", a2: (__int64)&DFFlag::DebugNetworkProfiler, a3: 2u); /*0x102a02d2c*/
}

// Address: 0x102a0443c | Name: __ZN6DFFlagL65rbxImplDynInit_FixIpV6SubnetContainsLoopBoundDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FixIpV6SubnetContainsLoopBoundDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a04453*/
           a1: (__int64)"FixIpV6SubnetContainsLoopBound",
           a2: (__int64)&DFFlag::FixIpV6SubnetContainsLoopBound,
           a3: 2u);
}

// Address: 0x102a06c10 | Name: __ZN6DFFlagL68rbxImplDynInit_DebugIgnoreNetAssetChecks_FLIPPEDDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugIgnoreNetAssetChecks_FLIPPEDDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a06c27*/
           a1: (__int64)"DebugIgnoreNetAssetChecks_FLIPPED",
           a2: (__int64)&DFFlag::DebugIgnoreNetAssetChecks_FLIPPED,
           a3: 2u);
}

// Address: 0x102a06c2d | Name: __ZN6DFFlagL73rbxImplDynInit_DebugLargeReplicatorDisableCompressionDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugLargeReplicatorDisableCompressionDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a06c44*/
           a1: (__int64)"DebugLargeReplicatorDisableCompression",
           a2: (__int64)&DFFlag::DebugLargeReplicatorDisableCompression,
           a3: 2u);
}

// Address: 0x102a06c67 | Name: __ZN6DFFlagL47rbxImplDynInit_SkipNetAssetDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SkipNetAssetDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"SkipNetAsset", a2: (__int64)&DFFlag::SkipNetAsset, a3: 2u); /*0x102a06c7e*/
}

// Address: 0x102a06cb7 | Name: __ZN6DFFlagL44rbxImplDynInit_CLI209395DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CLI209395DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"CLI209395", a2: (__int64)&DFFlag::CLI209395, a3: 2u); /*0x102a06cce*/
}

// Address: 0x102a0b65a | Name: __ZN6DFFlagL64rbxImplDynInit_DebugDisableNetworkDataAssertDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugDisableNetworkDataAssertDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0b671*/
           a1: (__int64)"DebugDisableNetworkDataAssert",
           a2: (__int64)&DFFlag::DebugDisableNetworkDataAssert,
           a3: 2u);
}

// Address: 0x102a0b677 | Name: __ZN6DFFlagL61rbxImplDynInit_EnableNetworkDataAssertLogDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableNetworkDataAssertLogDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0b68e*/
           a1: (__int64)"EnableNetworkDataAssertLog",
           a2: (__int64)&DFFlag::EnableNetworkDataAssertLog,
           a3: 2u);
}

// Address: 0x102a0b806 | Name: __ZN6DFFlagL65rbxImplDynInit_DebugNetworkProfilerReplicatorDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugNetworkProfilerReplicatorDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0b81d*/
           a1: (__int64)"DebugNetworkProfilerReplicator",
           a2: (__int64)&DFFlag::DebugNetworkProfilerReplicator,
           a3: 2u);
}

// Address: 0x102a0b823 | Name: __ZN6DFFlagL66rbxImplDynInit_DebugNetworkProfilerDeserializeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugNetworkProfilerDeserializeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0b83a*/
           a1: (__int64)"DebugNetworkProfilerDeserialize",
           a2: (__int64)&DFFlag::DebugNetworkProfilerDeserialize,
           a3: 2u);
}

// Address: 0x102a0b840 | Name: __ZN6DFFlagL62rbxImplDynInit_DebugNetworkProfilerRakPeerDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugNetworkProfilerRakPeerDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0b857*/
           a1: (__int64)"DebugNetworkProfilerRakPeer",
           a2: (__int64)&DFFlag::DebugNetworkProfilerRakPeer,
           a3: 2u);
}

// Address: 0x102a0b873 | Name: __ZN6DFFlagL65rbxImplDynInit_DebugNetworkProfilerAllPacketsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugNetworkProfilerAllPacketsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0b88a*/
           a1: (__int64)"DebugNetworkProfilerAllPackets",
           a2: (__int64)&DFFlag::DebugNetworkProfilerAllPackets,
           a3: 2u);
}

// Address: 0x102a0bdee | Name: __ZN6DFFlagL53rbxImplDynInit_FixStringCheckInNSDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FixStringCheckInNSDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"FixStringCheckInNS", a2: (__int64)&DFFlag::FixStringCheckInNS, a3: 2u); /*0x102a0be05*/
}

// Address: 0x102a0be0b | Name: __ZN6DFFlagL58rbxImplDynInit_EnforceIgnoreBytesLimitDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnforceIgnoreBytesLimitDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0be22*/
           a1: (__int64)"EnforceIgnoreBytesLimit",
           a2: (__int64)&DFFlag::EnforceIgnoreBytesLimit,
           a3: 2u);
}

// Address: 0x102a0be28 | Name: __ZN6DFFlagL67rbxImplDynInit_NetworkStreamUnderflowProtectionDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_NetworkStreamUnderflowProtectionDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0be3f*/
           a1: (__int64)"NetworkStreamUnderflowProtection",
           a2: (__int64)&DFFlag::NetworkStreamUnderflowProtection,
           a3: 2u);
}

// Address: 0x102a0be45 | Name: __ZN6DFFlagL77rbxImplDynInit_CheckStreamHasEnoughBytesInWriteFromStreamDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CheckStreamHasEnoughBytesInWriteFromStreamDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0be5c*/
           a1: (__int64)"CheckStreamHasEnoughBytesInWriteFromStream",
           a2: (__int64)&DFFlag::CheckStreamHasEnoughBytesInWriteFromStream,
           a3: 2u);
}

// Address: 0x102a0fa80 | Name: __ZN6DFFlagL68rbxImplDynInit_ApplicationReasonCodeEnumToStringDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_ApplicationReasonCodeEnumToStringDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0fa97*/
           a1: (__int64)"ApplicationReasonCodeEnumToString",
           a2: (__int64)&DFFlag::ApplicationReasonCodeEnumToString,
           a3: 2u);
}

// Address: 0x102a0fa9d | Name: __ZN6DFFlagL65rbxImplDynInit_RbxTransportIsolateIdleTimeoutDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportIsolateIdleTimeoutDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a0fab4*/
           a1: (__int64)"RbxTransportIsolateIdleTimeout",
           a2: (__int64)&DFFlag::RbxTransportIsolateIdleTimeout,
           a3: 2u);
}

// Address: 0x102a20366 | Name: __ZN6DFFlagL66rbxImplDynInit_FacsMappingSwapJointsKeepSortedDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FacsMappingSwapJointsKeepSortedDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a2037d*/
           a1: (__int64)"FacsMappingSwapJointsKeepSorted",
           a2: (__int64)&DFFlag::FacsMappingSwapJointsKeepSorted,
           a3: 2u);
}

// Address: 0x102a2defc | Name: __ZN6DFFlagL74rbxImplDynInit_CreatableDeleterScopedScriptRestrictionDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CreatableDeleterScopedScriptRestrictionDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a2df13*/
           a1: (__int64)"CreatableDeleterScopedScriptRestriction",
           a2: (__int64)&DFFlag::CreatableDeleterScopedScriptRestriction,
           a3: 2u);
}

// Address: 0x102a2df19 | Name: __ZN6DFFlagL79rbxImplDynInit_CreatableDeleterScopedScriptRestrictionBlockDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CreatableDeleterScopedScriptRestrictionBlockDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a2df30*/
           a1: (__int64)"CreatableDeleterScopedScriptRestrictionBlock",
           a2: (__int64)&DFFlag::CreatableDeleterScopedScriptRestrictionBlock,
           a3: 2u);
}

// Address: 0x102a2df36 | Name: __ZN6DFFlagL80rbxImplDynInit_CreatableDeleterScopedScriptRestrictionReportDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CreatableDeleterScopedScriptRestrictionReportDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a2df4d*/
           a1: (__int64)"CreatableDeleterScopedScriptRestrictionReport",
           a2: (__int64)&DFFlag::CreatableDeleterScopedScriptRestrictionReport,
           a3: 2u);
}

// Address: 0x102a2df53 | Name: __ZN6DFFlagL79rbxImplDynInit_CreatableDeleterScopedScriptRestrictionCrashDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CreatableDeleterScopedScriptRestrictionCrashDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a2df6a*/
           a1: (__int64)"CreatableDeleterScopedScriptRestrictionCrash",
           a2: (__int64)&DFFlag::CreatableDeleterScopedScriptRestrictionCrash,
           a3: 2u);
}

// Address: 0x102a306d4 | Name: __ZN6DFFlagL58rbxImplDynInit_DeprecatableBroadcasts2DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DeprecatableBroadcasts2DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a306eb*/
           a1: (__int64)"DeprecatableBroadcasts2",
           a2: (__int64)&DFFlag::DeprecatableBroadcasts2,
           a3: 2u);
}

// Address: 0x102a36462 | Name: __ZN6DFFlagL67rbxImplDynInit_CapsBetterUnassignedErrorMessageDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CapsBetterUnassignedErrorMessageDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a36479*/
           a1: (__int64)"CapsBetterUnassignedErrorMessage",
           a2: (__int64)&DFFlag::CapsBetterUnassignedErrorMessage,
           a3: 2u);
}

// Address: 0x102a3647f | Name: __ZN6DFFlagL65rbxImplDynInit_CapsSandboxedAwareErrorMessageDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CapsSandboxedAwareErrorMessageDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a36496*/
           a1: (__int64)"CapsSandboxedAwareErrorMessage",
           a2: (__int64)&DFFlag::CapsSandboxedAwareErrorMessage,
           a3: 2u);
}

// Address: 0x102a3649c | Name: __ZN6DFFlagL53rbxImplDynInit_SimpleTextMessagesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SimpleTextMessagesDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"SimpleTextMessages", a2: (__int64)&DFFlag::SimpleTextMessages, a3: 2u); /*0x102a364b3*/
}

// Address: 0x102a41b69 | Name: __ZN6DFFlagL69rbxImplDynInit_InstanceNullEngineContextTelemetryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_InstanceNullEngineContextTelemetryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a41b80*/
           a1: (__int64)"InstanceNullEngineContextTelemetry",
           a2: (__int64)&DFFlag::InstanceNullEngineContextTelemetry,
           a3: 2u);
}

// Address: 0x102a41b86 | Name: __ZN6DFFlagL76rbxImplDynInit_InstanceNullEngineContextTelemetryPlaceIDDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_InstanceNullEngineContextTelemetryPlaceIDDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a41b9d*/
           a1: (__int64)"InstanceNullEngineContextTelemetryPlaceID",
           a2: (__int64)&DFFlag::InstanceNullEngineContextTelemetryPlaceID,
           a3: 2u);
}

// Address: 0x102a88420 | Name: __ZN6DFFlagL57rbxImplDynInit_EnableCreatorLogGroupsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableCreatorLogGroupsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"EnableCreatorLogGroups", a2: (__int64)&DFFlag::EnableCreatorLogGroups, a3: 2u); /*0x102a88437*/
}

// Address: 0x102a8a1f8 | Name: __ZN6DFFlagL63rbxImplDynInit_EnableForceSetDMRecorderFlagDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableForceSetDMRecorderFlagDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a8a20f*/
           a1: (__int64)"EnableForceSetDMRecorderFlag",
           a2: (__int64)&DFFlag::EnableForceSetDMRecorderFlag,
           a3: 2u);
}

// Address: 0x102a8a26e | Name: __ZN6DFFlagL63rbxImplDynInit_DebugLargeReplicatorValidateDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugLargeReplicatorValidateDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a8a285*/
           a1: (__int64)"DebugLargeReplicatorValidate",
           a2: (__int64)&DFFlag::DebugLargeReplicatorValidate,
           a3: 2u);
}

// Address: 0x102a8a444 | Name: __ZN6DFFlagL57rbxImplDynInit_RecordEngineApiMetricsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RecordEngineApiMetricsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"RecordEngineApiMetrics", a2: (__int64)&DFFlag::RecordEngineApiMetrics, a3: 2u); /*0x102a8a45b*/
}

// Address: 0x102a96da6 | Name: __ZN6DFFlagL75rbxImplDynInit_RCCMultiplexingUsePerGameIdsForTelemetryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RCCMultiplexingUsePerGameIdsForTelemetryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a96dbd*/
           a1: (__int64)"RCCMultiplexingUsePerGameIdsForTelemetry",
           a2: (__int64)&DFFlag::RCCMultiplexingUsePerGameIdsForTelemetry,
           a3: 2u);
}

// Address: 0x102a98007 | Name: __ZN6DFFlagL52rbxImplDynInit_AnalyticsNewHttp2DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AnalyticsNewHttp2DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"AnalyticsNewHttp2", a2: (__int64)&DFFlag::AnalyticsNewHttp2, a3: 2u); /*0x102a9801e*/
}

// Address: 0x102a989ea | Name: __ZN6DFFlagL81rbxImplDynInit_DontRegisterCallbackToAccumulateStatsAnalyticsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DontRegisterCallbackToAccumulateStatsAnalyticsDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102a98a01*/
           a1: (__int64)"DontRegisterCallbackToAccumulateStatsAnalytics",
           a2: (__int64)&DFFlag::DontRegisterCallbackToAccumulateStatsAnalytics,
           a3: 2u);
}

// Address: 0x102aa088b | Name: __ZN6DFFlagL59rbxImplDynInit_NonBlockingAnalyticsExitDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_NonBlockingAnalyticsExitDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102aa08a2*/
           a1: (__int64)"NonBlockingAnalyticsExit",
           a2: (__int64)&DFFlag::NonBlockingAnalyticsExit,
           a3: 2u);
}

// Address: 0x102aaa3ac | Name: __ZN6DFFlagL87rbxImplDynInit_AnalyticsDeferredEventIngestReportUnsentEventsOnExitDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AnalyticsDeferredEventIngestReportUnsentEventsOnExitDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102aaa3c3*/
           a1: (__int64)"AnalyticsDeferredEventIngestReportUnsentEventsOnExit",
           a2: (__int64)&DFFlag::AnalyticsDeferredEventIngestReportUnsentEventsOnExit,
           a3: 2u);
}

// Address: 0x102aaa3c9 | Name: __ZN6DFFlagL86rbxImplDynInit_AnalyticsDeferredEventIngestEmptyQueueEveryIntervalDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AnalyticsDeferredEventIngestEmptyQueueEveryIntervalDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102aaa3e0*/
           a1: (__int64)"AnalyticsDeferredEventIngestEmptyQueueEveryInterval",
           a2: (__int64)&DFFlag::AnalyticsDeferredEventIngestEmptyQueueEveryInterval,
           a3: 2u);
}

// Address: 0x102aaa3e6 | Name: __ZN6DFFlagL66rbxImplDynInit_EventIngestUseContextInfoGameIdDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EventIngestUseContextInfoGameIdDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102aaa3fd*/
           a1: (__int64)"EventIngestUseContextInfoGameId",
           a2: (__int64)&DFFlag::EventIngestUseContextInfoGameId,
           a3: 2u);
}

// Address: 0x102ab6f8a | Name: __ZN6DFFlagL62rbxImplDynInit_FlagRolloutTestDynamicBool0DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool0DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab6fa1*/
           a1: (__int64)"FlagRolloutTestDynamicBool0",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool0,
           a3: 2u);
}

// Address: 0x102ab6fa7 | Name: __ZN6DFFlagL62rbxImplDynInit_FlagRolloutTestDynamicBool1DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool1DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab6fbe*/
           a1: (__int64)"FlagRolloutTestDynamicBool1",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool1,
           a3: 2u);
}

// Address: 0x102ab6fc4 | Name: __ZN6DFFlagL62rbxImplDynInit_FlagRolloutTestDynamicBool2DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool2DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab6fdb*/
           a1: (__int64)"FlagRolloutTestDynamicBool2",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool2,
           a3: 2u);
}

// Address: 0x102ab6fe1 | Name: __ZN6DFFlagL62rbxImplDynInit_FlagRolloutTestDynamicBool3DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool3DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab6ff8*/
           a1: (__int64)"FlagRolloutTestDynamicBool3",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool3,
           a3: 2u);
}

// Address: 0x102ab6ffe | Name: __ZN6DFFlagL62rbxImplDynInit_FlagRolloutTestDynamicBool4DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool4DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7015*/
           a1: (__int64)"FlagRolloutTestDynamicBool4",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool4,
           a3: 2u);
}

// Address: 0x102ab701b | Name: __ZN6DFFlagL62rbxImplDynInit_FlagRolloutTestDynamicBool5DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool5DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7032*/
           a1: (__int64)"FlagRolloutTestDynamicBool5",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool5,
           a3: 2u);
}

// Address: 0x102ab7038 | Name: __ZN6DFFlagL62rbxImplDynInit_FlagRolloutTestDynamicBool6DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool6DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab704f*/
           a1: (__int64)"FlagRolloutTestDynamicBool6",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool6,
           a3: 2u);
}

// Address: 0x102ab7055 | Name: __ZN6DFFlagL62rbxImplDynInit_FlagRolloutTestDynamicBool7DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool7DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab706c*/
           a1: (__int64)"FlagRolloutTestDynamicBool7",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool7,
           a3: 2u);
}

// Address: 0x102ab7072 | Name: __ZN6DFFlagL62rbxImplDynInit_FlagRolloutTestDynamicBool8DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool8DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7089*/
           a1: (__int64)"FlagRolloutTestDynamicBool8",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool8,
           a3: 2u);
}

// Address: 0x102ab708f | Name: __ZN6DFFlagL62rbxImplDynInit_FlagRolloutTestDynamicBool9DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool9DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab70a6*/
           a1: (__int64)"FlagRolloutTestDynamicBool9",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool9,
           a3: 2u);
}

// Address: 0x102ab70ac | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool10DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool10DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab70c3*/
           a1: (__int64)"FlagRolloutTestDynamicBool10",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool10,
           a3: 2u);
}

// Address: 0x102ab70c9 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool11DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool11DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab70e0*/
           a1: (__int64)"FlagRolloutTestDynamicBool11",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool11,
           a3: 2u);
}

// Address: 0x102ab70e6 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool12DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool12DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab70fd*/
           a1: (__int64)"FlagRolloutTestDynamicBool12",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool12,
           a3: 2u);
}

// Address: 0x102ab7103 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool13DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool13DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab711a*/
           a1: (__int64)"FlagRolloutTestDynamicBool13",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool13,
           a3: 2u);
}

// Address: 0x102ab7120 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool14DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool14DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7137*/
           a1: (__int64)"FlagRolloutTestDynamicBool14",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool14,
           a3: 2u);
}

// Address: 0x102ab713d | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool15DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool15DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7154*/
           a1: (__int64)"FlagRolloutTestDynamicBool15",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool15,
           a3: 2u);
}

// Address: 0x102ab715a | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool16DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool16DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7171*/
           a1: (__int64)"FlagRolloutTestDynamicBool16",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool16,
           a3: 2u);
}

// Address: 0x102ab7177 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool17DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool17DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab718e*/
           a1: (__int64)"FlagRolloutTestDynamicBool17",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool17,
           a3: 2u);
}

// Address: 0x102ab7194 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool18DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool18DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab71ab*/
           a1: (__int64)"FlagRolloutTestDynamicBool18",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool18,
           a3: 2u);
}

// Address: 0x102ab71b1 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool19DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool19DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab71c8*/
           a1: (__int64)"FlagRolloutTestDynamicBool19",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool19,
           a3: 2u);
}

// Address: 0x102ab71ce | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool20DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool20DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab71e5*/
           a1: (__int64)"FlagRolloutTestDynamicBool20",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool20,
           a3: 2u);
}

// Address: 0x102ab71eb | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool21DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool21DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7202*/
           a1: (__int64)"FlagRolloutTestDynamicBool21",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool21,
           a3: 2u);
}

// Address: 0x102ab7208 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool22DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool22DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab721f*/
           a1: (__int64)"FlagRolloutTestDynamicBool22",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool22,
           a3: 2u);
}

// Address: 0x102ab7225 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool23DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool23DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab723c*/
           a1: (__int64)"FlagRolloutTestDynamicBool23",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool23,
           a3: 2u);
}

// Address: 0x102ab7242 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool24DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool24DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7259*/
           a1: (__int64)"FlagRolloutTestDynamicBool24",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool24,
           a3: 2u);
}

// Address: 0x102ab725f | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool25DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool25DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7276*/
           a1: (__int64)"FlagRolloutTestDynamicBool25",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool25,
           a3: 2u);
}

// Address: 0x102ab727c | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool26DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool26DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7293*/
           a1: (__int64)"FlagRolloutTestDynamicBool26",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool26,
           a3: 2u);
}

// Address: 0x102ab7299 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool27DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool27DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab72b0*/
           a1: (__int64)"FlagRolloutTestDynamicBool27",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool27,
           a3: 2u);
}

// Address: 0x102ab72b6 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool28DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool28DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab72cd*/
           a1: (__int64)"FlagRolloutTestDynamicBool28",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool28,
           a3: 2u);
}

// Address: 0x102ab72d3 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool29DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool29DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab72ea*/
           a1: (__int64)"FlagRolloutTestDynamicBool29",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool29,
           a3: 2u);
}

// Address: 0x102ab72f0 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool30DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool30DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7307*/
           a1: (__int64)"FlagRolloutTestDynamicBool30",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool30,
           a3: 2u);
}

// Address: 0x102ab730d | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool31DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool31DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7324*/
           a1: (__int64)"FlagRolloutTestDynamicBool31",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool31,
           a3: 2u);
}

// Address: 0x102ab732a | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool32DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool32DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7341*/
           a1: (__int64)"FlagRolloutTestDynamicBool32",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool32,
           a3: 2u);
}

// Address: 0x102ab7347 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool33DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool33DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab735e*/
           a1: (__int64)"FlagRolloutTestDynamicBool33",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool33,
           a3: 2u);
}

// Address: 0x102ab7364 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool34DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool34DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab737b*/
           a1: (__int64)"FlagRolloutTestDynamicBool34",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool34,
           a3: 2u);
}

// Address: 0x102ab7381 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool35DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool35DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7398*/
           a1: (__int64)"FlagRolloutTestDynamicBool35",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool35,
           a3: 2u);
}

// Address: 0x102ab739e | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool36DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool36DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab73b5*/
           a1: (__int64)"FlagRolloutTestDynamicBool36",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool36,
           a3: 2u);
}

// Address: 0x102ab73bb | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool37DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool37DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab73d2*/
           a1: (__int64)"FlagRolloutTestDynamicBool37",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool37,
           a3: 2u);
}

// Address: 0x102ab73d8 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool38DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool38DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab73ef*/
           a1: (__int64)"FlagRolloutTestDynamicBool38",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool38,
           a3: 2u);
}

// Address: 0x102ab73f5 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool39DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool39DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab740c*/
           a1: (__int64)"FlagRolloutTestDynamicBool39",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool39,
           a3: 2u);
}

// Address: 0x102ab7412 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool40DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool40DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7429*/
           a1: (__int64)"FlagRolloutTestDynamicBool40",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool40,
           a3: 2u);
}

// Address: 0x102ab742f | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool41DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool41DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7446*/
           a1: (__int64)"FlagRolloutTestDynamicBool41",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool41,
           a3: 2u);
}

// Address: 0x102ab744c | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool42DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool42DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7463*/
           a1: (__int64)"FlagRolloutTestDynamicBool42",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool42,
           a3: 2u);
}

// Address: 0x102ab7469 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool43DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool43DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7480*/
           a1: (__int64)"FlagRolloutTestDynamicBool43",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool43,
           a3: 2u);
}

// Address: 0x102ab7486 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool44DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool44DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab749d*/
           a1: (__int64)"FlagRolloutTestDynamicBool44",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool44,
           a3: 2u);
}

// Address: 0x102ab74a3 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool45DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool45DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab74ba*/
           a1: (__int64)"FlagRolloutTestDynamicBool45",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool45,
           a3: 2u);
}

// Address: 0x102ab74c0 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool46DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool46DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab74d7*/
           a1: (__int64)"FlagRolloutTestDynamicBool46",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool46,
           a3: 2u);
}

// Address: 0x102ab74dd | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool47DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool47DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab74f4*/
           a1: (__int64)"FlagRolloutTestDynamicBool47",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool47,
           a3: 2u);
}

// Address: 0x102ab74fa | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool48DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool48DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab7511*/
           a1: (__int64)"FlagRolloutTestDynamicBool48",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool48,
           a3: 2u);
}

// Address: 0x102ab7517 | Name: __ZN6DFFlagL63rbxImplDynInit_FlagRolloutTestDynamicBool49DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FlagRolloutTestDynamicBool49DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ab752e*/
           a1: (__int64)"FlagRolloutTestDynamicBool49",
           a2: (__int64)&DFFlag::FlagRolloutTestDynamicBool49,
           a3: 2u);
}

// Address: 0x102abdc2a | Name: __ZN6DFFlagL61rbxImplDynInit_DebugRemoteReporterEnabledDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugRemoteReporterEnabledDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102abdc41*/
           a1: (__int64)"DebugRemoteReporterEnabled",
           a2: (__int64)&DFFlag::DebugRemoteReporterEnabled,
           a3: 2u);
}

// Address: 0x102ac8a3b | Name: __ZN6DFFlagL63rbxImplDynInit_SharedStringTagsOptimizationDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SharedStringTagsOptimizationDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ac8a52*/
           a1: (__int64)"SharedStringTagsOptimization",
           a2: (__int64)&DFFlag::SharedStringTagsOptimization,
           a3: 2u);
}

// Address: 0x102ac8be3 | Name: __ZN6DFFlagL69rbxImplDynInit_CheckEngineContextOnInstanceAccessDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CheckEngineContextOnInstanceAccessDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ac8bfa*/
           a1: (__int64)"CheckEngineContextOnInstanceAccess",
           a2: (__int64)&DFFlag::CheckEngineContextOnInstanceAccess,
           a3: 2u);
}

// Address: 0x102ac8c76 | Name: __ZN6DFFlagL67rbxImplDynInit_StitchInstancesCloneFromExistingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_StitchInstancesCloneFromExistingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ac8c8d*/
           a1: (__int64)"StitchInstancesCloneFromExisting",
           a2: (__int64)&DFFlag::StitchInstancesCloneFromExisting,
           a3: 2u);
}

// Address: 0x102ae6b3a | Name: __ZN6DFFlagL58rbxImplDynInit_EnablePerfPlaytestIdTagDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnablePerfPlaytestIdTagDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ae6b51*/
           a1: (__int64)"EnablePerfPlaytestIdTag",
           a2: (__int64)&DFFlag::EnablePerfPlaytestIdTag,
           a3: 2u);
}

// Address: 0x102ae6b91 | Name: __ZN6DFFlagL58rbxImplDynInit_EnableInfluxKeyValidateDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableInfluxKeyValidateDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ae6ba8*/
           a1: (__int64)"EnableInfluxKeyValidate",
           a2: (__int64)&DFFlag::EnableInfluxKeyValidate,
           a3: 2u);
}

// Address: 0x102ae6bae | Name: __ZN6DFFlagL63rbxImplDynInit_EnablePointsHardwareBitDepthDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnablePointsHardwareBitDepthDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ae6bc5*/
           a1: (__int64)"EnablePointsHardwareBitDepth",
           a2: (__int64)&DFFlag::EnablePointsHardwareBitDepth,
           a3: 2u);
}

// Address: 0x102ae6bcb | Name: __ZN6DFFlagL62rbxImplDynInit_AnalyticsPointsDisallowNansDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AnalyticsPointsDisallowNansDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ae6be2*/
           a1: (__int64)"AnalyticsPointsDisallowNans",
           a2: (__int64)&DFFlag::AnalyticsPointsDisallowNans,
           a3: 2u);
}

// Address: 0x102ae6be8 | Name: __ZN6DFFlagL65rbxImplDynInit_AnalyticsPointsReportDebugInfoDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AnalyticsPointsReportDebugInfoDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ae6bff*/
           a1: (__int64)"AnalyticsPointsReportDebugInfo",
           a2: (__int64)&DFFlag::AnalyticsPointsReportDebugInfo,
           a3: 2u);
}

// Address: 0x102b11c92 | Name: __ZN6DFFlagL57rbxImplDynInit_SupportEncryptedAssetsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SupportEncryptedAssetsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"SupportEncryptedAssets", a2: (__int64)&DFFlag::SupportEncryptedAssets, a3: 2u); /*0x102b11ca9*/
}

// Address: 0x102b1df10 | Name: __ZN6DFFlagL58rbxImplDynInit_HangDetectionForceCrashDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HangDetectionForceCrashDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b1df27*/
           a1: (__int64)"HangDetectionForceCrash",
           a2: (__int64)&DFFlag::HangDetectionForceCrash,
           a3: 2u);
}

// Address: 0x102b1df2d | Name: __ZN6DFFlagL54rbxImplDynInit_HangDetectionReportDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HangDetectionReportDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"HangDetectionReport", a2: (__int64)&DFFlag::HangDetectionReport, a3: 2u); /*0x102b1df44*/
}

// Address: 0x102b20cbe | Name: __ZN6DFFlagL60rbxImplDynInit_DebugUpdateClientChannelBDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugUpdateClientChannelBDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b20cd5*/
           a1: (__int64)"DebugUpdateClientChannelB",
           a2: (__int64)&DFFlag::DebugUpdateClientChannelB,
           a3: 2u);
}

// Address: 0x102b20d50 | Name: __ZN6DFFlagL65rbxImplDynInit_InferredCrashReportToBacktraceDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_InferredCrashReportToBacktraceDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b20d67*/
           a1: (__int64)"InferredCrashReportToBacktrace",
           a2: (__int64)&DFFlag::InferredCrashReportToBacktrace,
           a3: 2u);
}

// Address: 0x102b20e8b | Name: __ZN6DFFlagL64rbxImplDynInit_FixExitImportanceWrongStorageDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FixExitImportanceWrongStorageDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b20ea2*/
           a1: (__int64)"FixExitImportanceWrongStorage",
           a2: (__int64)&DFFlag::FixExitImportanceWrongStorage,
           a3: 2u);
}

// Address: 0x102b333ec | Name: __ZN6DFFlagL64rbxImplDynInit_LocalStorageArenaOptimizationDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LocalStorageArenaOptimizationDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b33403*/
           a1: (__int64)"LocalStorageArenaOptimization",
           a2: (__int64)&DFFlag::LocalStorageArenaOptimization,
           a3: 2u);
}

// Address: 0x102b37e9e | Name: __ZN6DFFlagL64rbxImplDynInit_UseVerboseLogPrefixEverywhereDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_UseVerboseLogPrefixEverywhereDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b37eb5*/
           a1: (__int64)"UseVerboseLogPrefixEverywhere",
           a2: (__int64)&DFFlag::UseVerboseLogPrefixEverywhere,
           a3: 2u);
}

// Address: 0x102b381a6 | Name: __ZN6DFFlagL58rbxImplDynInit_DisableFastLogTelemetryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DisableFastLogTelemetryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b381bd*/
           a1: (__int64)"DisableFastLogTelemetry",
           a2: (__int64)&DFFlag::DisableFastLogTelemetry,
           a3: 2u);
}

// Address: 0x102b381c3 | Name: __ZN6DFFlagL59rbxImplDynInit_EnableLogTelemetrySinkV2DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableLogTelemetrySinkV2DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b381da*/
           a1: (__int64)"EnableLogTelemetrySinkV2",
           a2: (__int64)&DFFlag::EnableLogTelemetrySinkV2,
           a3: 2u);
}

// Address: 0x102b3829f | Name: __ZN6DFFlagL56rbxImplDynInit_LogSystemSinkSupport2DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LogSystemSinkSupport2DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LogSystemSinkSupport2", a2: (__int64)&DFFlag::LogSystemSinkSupport2, a3: 2u); /*0x102b382b6*/
}

// Address: 0x102b382bc | Name: __ZN6DFFlagL62rbxImplDynInit_LogChannelThrottlingEnabledDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LogChannelThrottlingEnabledDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b382d3*/
           a1: (__int64)"LogChannelThrottlingEnabled",
           a2: (__int64)&DFFlag::LogChannelThrottlingEnabled,
           a3: 2u);
}

// Address: 0x102b38365 | Name: __ZN6DFFlagL69rbxImplDynInit_LogChannelThrottleTelemetryEnabledDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LogChannelThrottleTelemetryEnabledDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b3837c*/
           a1: (__int64)"LogChannelThrottleTelemetryEnabled",
           a2: (__int64)&DFFlag::LogChannelThrottleTelemetryEnabled,
           a3: 2u);
}

// Address: 0x102b4226e | Name: __ZN6DFFlagL63rbxImplDynInit_ReportMemoryDumpToTelemetry1DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_ReportMemoryDumpToTelemetry1DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b42285*/
           a1: (__int64)"ReportMemoryDumpToTelemetry1",
           a2: (__int64)&DFFlag::ReportMemoryDumpToTelemetry1,
           a3: 2u);
}

// Address: 0x102b436f1 | Name: __ZN6DFFlagL47rbxImplDynInit_PredictedOOMDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_PredictedOOMDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"PredictedOOM", a2: (__int64)&DFFlag::PredictedOOM, a3: 2u); /*0x102b43708*/
}

// Address: 0x102b43ac8 | Name: __ZN6DFFlagL68rbxImplDynInit_MemoryProfilingTopLevelUsageMutexDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MemoryProfilingTopLevelUsageMutexDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b43adf*/
           a1: (__int64)"MemoryProfilingTopLevelUsageMutex",
           a2: (__int64)&DFFlag::MemoryProfilingTopLevelUsageMutex,
           a3: 2u);
}

// Address: 0x102b43ae5 | Name: __ZN6DFFlagL65rbxImplDynInit_FixCpuMemGpuMemSessionTrackingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FixCpuMemGpuMemSessionTrackingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b43afc*/
           a1: (__int64)"FixCpuMemGpuMemSessionTracking",
           a2: (__int64)&DFFlag::FixCpuMemGpuMemSessionTracking,
           a3: 2u);
}

// Address: 0x102b43b02 | Name: __ZN6DFFlagL67rbxImplDynInit_MemoryPageFaultsTelemetryEnabledDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MemoryPageFaultsTelemetryEnabledDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b43b19*/
           a1: (__int64)"MemoryPageFaultsTelemetryEnabled",
           a2: (__int64)&DFFlag::MemoryPageFaultsTelemetryEnabled,
           a3: 2u);
}

// Address: 0x102b43bb8 | Name: __ZN6DFFlagL68rbxImplDynInit_MemoryPageFaultsIncludeUniverseIdDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MemoryPageFaultsIncludeUniverseIdDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b43bcf*/
           a1: (__int64)"MemoryPageFaultsIncludeUniverseId",
           a2: (__int64)&DFFlag::MemoryPageFaultsIncludeUniverseId,
           a3: 2u);
}

// Address: 0x102b43bd5 | Name: __ZN6DFFlagL65rbxImplDynInit_MemoryPageFaultsIncludePlaceIdDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MemoryPageFaultsIncludePlaceIdDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b43bec*/
           a1: (__int64)"MemoryPageFaultsIncludePlaceId",
           a2: (__int64)&DFFlag::MemoryPageFaultsIncludePlaceId,
           a3: 2u);
}

// Address: 0x102b55c22 | Name: __ZN6DFFlagL66rbxImplDynInit_DebugMicroprofilerDumpAllFramesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugMicroprofilerDumpAllFramesDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b55c39*/
           a1: (__int64)"DebugMicroprofilerDumpAllFrames",
           a2: (__int64)&DFFlag::DebugMicroprofilerDumpAllFrames,
           a3: 2u);
}

// Address: 0x102b55c3f | Name: __ZN6DFFlagL62rbxImplDynInit_DebugMicroprofilerOutputRawDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugMicroprofilerOutputRawDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b55c56*/
           a1: (__int64)"DebugMicroprofilerOutputRaw",
           a2: (__int64)&DFFlag::DebugMicroprofilerOutputRaw,
           a3: 2u);
}

// Address: 0x102b55c5c | Name: __ZN6DFFlagL60rbxImplDynInit_MicroProfilerStrSanitizerDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MicroProfilerStrSanitizerDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b55c73*/
           a1: (__int64)"MicroProfilerStrSanitizer",
           a2: (__int64)&DFFlag::MicroProfilerStrSanitizer,
           a3: 2u);
}

// Address: 0x102b55cef | Name: __ZN6DFFlagL70rbxImplDynInit_MicroProfilerMemoryTrackingAlertWebDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MicroProfilerMemoryTrackingAlertWebDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b55d06*/
           a1: (__int64)"MicroProfilerMemoryTrackingAlertWeb",
           a2: (__int64)&DFFlag::MicroProfilerMemoryTrackingAlertWeb,
           a3: 2u);
}

// Address: 0x102b55d46 | Name: __ZN6DFFlagL53rbxImplDynInit_LibMpScriptEventSaDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpScriptEventSaDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpScriptEventSa", a2: (__int64)&DFFlag::LibMpScriptEventSa, a3: 2u); /*0x102b55d5d*/
}

// Address: 0x102b55d63 | Name: __ZN6DFFlagL50rbxImplDynInit_LibMpDumpBtnOneDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpDumpBtnOneDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpDumpBtnOne", a2: (__int64)&DFFlag::LibMpDumpBtnOne, a3: 2u); /*0x102b55d7a*/
}

// Address: 0x102b55d80 | Name: __ZN6DFFlagL50rbxImplDynInit_LibMpDumpBtnTwoDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpDumpBtnTwoDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpDumpBtnTwo", a2: (__int64)&DFFlag::LibMpDumpBtnTwo, a3: 2u); /*0x102b55d97*/
}

// Address: 0x102b55d9d | Name: __ZN6DFFlagL52rbxImplDynInit_LibMpDumpBtnThreeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpDumpBtnThreeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpDumpBtnThree", a2: (__int64)&DFFlag::LibMpDumpBtnThree, a3: 2u); /*0x102b55db4*/
}

// Address: 0x102b55dba | Name: __ZN6DFFlagL46rbxImplDynInit_LibMpApiOneDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpApiOneDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpApiOne", a2: (__int64)&DFFlag::LibMpApiOne, a3: 2u); /*0x102b55dd1*/
}

// Address: 0x102b55dd7 | Name: __ZN6DFFlagL49rbxImplDynInit_LibMpApiStudioDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpApiStudioDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpApiStudio", a2: (__int64)&DFFlag::LibMpApiStudio, a3: 2u); /*0x102b55dee*/
}

// Address: 0x102b55df4 | Name: __ZN6DFFlagL46rbxImplDynInit_LibMpApiRccDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpApiRccDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpApiRcc", a2: (__int64)&DFFlag::LibMpApiRcc, a3: 2u); /*0x102b55e0b*/
}

// Address: 0x102b55e2e | Name: __ZN6DFFlagL48rbxImplDynInit_LibMpFxRccOneDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpFxRccOneDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpFxRccOne", a2: (__int64)&DFFlag::LibMpFxRccOne, a3: 2u); /*0x102b55e45*/
}

// Address: 0x102b55e4b | Name: __ZN6DFFlagL48rbxImplDynInit_LibMpFxRccTwoDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpFxRccTwoDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpFxRccTwo", a2: (__int64)&DFFlag::LibMpFxRccTwo, a3: 2u); /*0x102b55e62*/
}

// Address: 0x102b55e68 | Name: __ZN6DFFlagL50rbxImplDynInit_LibMpFxTelemUpdDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpFxTelemUpdDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpFxTelemUpd", a2: (__int64)&DFFlag::LibMpFxTelemUpd, a3: 2u); /*0x102b55e7f*/
}

// Address: 0x102b55e85 | Name: __ZN6DFFlagL50rbxImplDynInit_LibMpFxLimitRstDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpFxLimitRstDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpFxLimitRst", a2: (__int64)&DFFlag::LibMpFxLimitRst, a3: 2u); /*0x102b55e9c*/
}

// Address: 0x102b55ea2 | Name: __ZN6DFFlagL57rbxImplDynInit_LibMpRccCompleteFramesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpRccCompleteFramesDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpRccCompleteFrames", a2: (__int64)&DFFlag::LibMpRccCompleteFrames, a3: 2u); /*0x102b55eb9*/
}

// Address: 0x102b55ebf | Name: __ZN6DFFlagL52rbxImplDynInit_LibMpTelemUpdContDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpTelemUpdContDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpTelemUpdCont", a2: (__int64)&DFFlag::LibMpTelemUpdCont, a3: 2u); /*0x102b55ed6*/
}

// Address: 0x102b55edc | Name: __ZN6DFFlagL52rbxImplDynInit_LibMpTelemetryOneDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpTelemetryOneDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpTelemetryOne", a2: (__int64)&DFFlag::LibMpTelemetryOne, a3: 2u); /*0x102b55ef3*/
}

// Address: 0x102b55ef9 | Name: __ZN6DFFlagL52rbxImplDynInit_LibMpTelemetryTwoDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LibMpTelemetryTwoDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"LibMpTelemetryTwo", a2: (__int64)&DFFlag::LibMpTelemetryTwo, a3: 2u); /*0x102b55f10*/
}

// Address: 0x102b55f42 | Name: __ZN6DFFlagL52rbxImplDynInit_MpUiFrameAbsIdOneDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MpUiFrameAbsIdOneDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"MpUiFrameAbsIdOne", a2: (__int64)&DFFlag::MpUiFrameAbsIdOne, a3: 2u); /*0x102b55f59*/
}

// Address: 0x102b55f5f | Name: __ZN6DFFlagL69rbxImplDynInit_MicroprofilerDumpUseCompleteFramesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MicroprofilerDumpUseCompleteFramesDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b55f76*/
           a1: (__int64)"MicroprofilerDumpUseCompleteFrames",
           a2: (__int64)&DFFlag::MicroprofilerDumpUseCompleteFrames,
           a3: 2u);
}

// Address: 0x102b55f7c | Name: __ZN6DFFlagL63rbxImplDynInit_MicroprofilerShowRecentDumpsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MicroprofilerShowRecentDumpsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b55f93*/
           a1: (__int64)"MicroprofilerShowRecentDumps",
           a2: (__int64)&DFFlag::MicroprofilerShowRecentDumps,
           a3: 2u);
}

// Address: 0x102b65f59 | Name: __ZN6DFFlagL60rbxImplDynInit_DebugMicroprofilerJsLocalDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugMicroprofilerJsLocalDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b65f70*/
           a1: (__int64)"DebugMicroprofilerJsLocal",
           a2: (__int64)&DFFlag::DebugMicroprofilerJsLocal,
           a3: 2u);
}

// Address: 0x102b6e285 | Name: __ZN6DFFlagL56rbxImplDynInit_RccEnableMultiplexingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RccEnableMultiplexingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"RccEnableMultiplexing", a2: (__int64)&DFFlag::RccEnableMultiplexing, a3: 2u); /*0x102b6e29c*/
}

// Address: 0x102b70206 | Name: __ZN6DFFlagL72rbxImplDynInit_GetDetailedNetworkAddressesAppleLinuxDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_GetDetailedNetworkAddressesAppleLinuxDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b7021d*/
           a1: (__int64)"GetDetailedNetworkAddressesAppleLinux",
           a2: (__int64)&DFFlag::GetDetailedNetworkAddressesAppleLinux,
           a3: 2u);
}

// Address: 0x102b7277a | Name: __ZN6DFFlagL54rbxImplDynInit_GatherStatsPerFrameDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_GatherStatsPerFrameDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"GatherStatsPerFrame", a2: (__int64)&DFFlag::GatherStatsPerFrame, a3: 2u); /*0x102b72791*/
}

// Address: 0x102b7283f | Name: __ZN6DFFlagL62rbxImplDynInit_RCCMicroprofilingRomarkModeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RCCMicroprofilingRomarkModeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b72856*/
           a1: (__int64)"RCCMicroprofilingRomarkMode",
           a2: (__int64)&DFFlag::RCCMicroprofilingRomarkMode,
           a3: 2u);
}

// Address: 0x102b72872 | Name: __ZN6DFFlagL60rbxImplDynInit_PercentileReportOnOneLineDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_PercentileReportOnOneLineDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b72889*/
           a1: (__int64)"PercentileReportOnOneLine",
           a2: (__int64)&DFFlag::PercentileReportOnOneLine,
           a3: 2u);
}

// Address: 0x102b7288f | Name: __ZN6DFFlagL60rbxImplDynInit_EnablePercentileTelemetryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnablePercentileTelemetryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b728a6*/
           a1: (__int64)"EnablePercentileTelemetry",
           a2: (__int64)&DFFlag::EnablePercentileTelemetry,
           a3: 2u);
}

// Address: 0x102b728df | Name: __ZN6DFFlagL57rbxImplDynInit_DebugRomarkPhaseMemoryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugRomarkPhaseMemoryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"DebugRomarkPhaseMemory", a2: (__int64)&DFFlag::DebugRomarkPhaseMemory, a3: 2u); /*0x102b728f6*/
}

// Address: 0x102b728fc | Name: __ZN6DFFlagL66rbxImplDynInit_AddRomarkPhasenameToEventIngestDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AddRomarkPhasenameToEventIngestDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b72913*/
           a1: (__int64)"AddRomarkPhasenameToEventIngest",
           a2: (__int64)&DFFlag::AddRomarkPhasenameToEventIngest,
           a3: 2u);
}

// Address: 0x102b78584 | Name: __ZN6DFFlagL78rbxImplDynInit_EnablePerfDataCoreCategoryTimersCollection2DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnablePerfDataCoreCategoryTimersCollection2DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b7859b*/
           a1: (__int64)"EnablePerfDataCoreCategoryTimersCollection2",
           a2: (__int64)&DFFlag::EnablePerfDataCoreCategoryTimersCollection2,
           a3: 2u);
}

// Address: 0x102b785a1 | Name: __ZN6DFFlagL67rbxImplDynInit_EnablePerfDataCountersCollectionDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnablePerfDataCountersCollectionDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b785b8*/
           a1: (__int64)"EnablePerfDataCountersCollection",
           a2: (__int64)&DFFlag::EnablePerfDataCountersCollection,
           a3: 2u);
}

// Address: 0x102b785be | Name: __ZN6DFFlagL68rbxImplDynInit_EnableMicroProfilerDumpScreenshotDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableMicroProfilerDumpScreenshotDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b785d5*/
           a1: (__int64)"EnableMicroProfilerDumpScreenshot",
           a2: (__int64)&DFFlag::EnableMicroProfilerDumpScreenshot,
           a3: 2u);
}

// Address: 0x102b785db | Name: __ZN6DFFlagL47rbxImplDynInit_AggCpuMemRCCDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AggCpuMemRCCDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"AggCpuMemRCC", a2: (__int64)&DFFlag::AggCpuMemRCC, a3: 2u); /*0x102b785f2*/
}

// Address: 0x102b7c0e8 | Name: __ZN6DFFlagL67rbxImplDynInit_DebugOverrideProfileFrameTimeNowDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugOverrideProfileFrameTimeNowDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b7c0ff*/
           a1: (__int64)"DebugOverrideProfileFrameTimeNow",
           a2: (__int64)&DFFlag::DebugOverrideProfileFrameTimeNow,
           a3: 2u);
}

// Address: 0x102b7c686 | Name: __ZN6DFFlagL67rbxImplDynInit_MicroProfilerMemoryTrackingAlertDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MicroProfilerMemoryTrackingAlertDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b7c69d*/
           a1: (__int64)"MicroProfilerMemoryTrackingAlert",
           a2: (__int64)&DFFlag::MicroProfilerMemoryTrackingAlert,
           a3: 2u);
}

// Address: 0x102b7c6a3 | Name: __ZN6DFFlagL69rbxImplDynInit_MicroprofilerShowFrameRangeOnGraphDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MicroprofilerShowFrameRangeOnGraphDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b7c6ba*/
           a1: (__int64)"MicroprofilerShowFrameRangeOnGraph",
           a2: (__int64)&DFFlag::MicroprofilerShowFrameRangeOnGraph,
           a3: 2u);
}

// Address: 0x102b7c6c0 | Name: __ZN6DFFlagL55rbxImplDynInit_MicroprofilerZoomFixDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MicroprofilerZoomFixDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"MicroprofilerZoomFix", a2: (__int64)&DFFlag::MicroprofilerZoomFix, a3: 2u); /*0x102b7c6d7*/
}

// Address: 0x102b8a230 | Name: __ZN6DFFlagL57rbxImplDynInit_EnablePerFrameSamplingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnablePerFrameSamplingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"EnablePerFrameSampling", a2: (__int64)&DFFlag::EnablePerFrameSampling, a3: 2u); /*0x102b8a247*/
}

// Address: 0x102b8a263 | Name: __ZN6DFFlagL59rbxImplDynInit_MicroProfilerMemoryScopeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MicroProfilerMemoryScopeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b8a27a*/
           a1: (__int64)"MicroProfilerMemoryScope",
           a2: (__int64)&DFFlag::MicroProfilerMemoryScope,
           a3: 2u);
}

// Address: 0x102b8a3c7 | Name: __ZN6DFFlagL76rbxImplDynInit_DebugMicroProfilerAutoCaptureUseCustomDirDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugMicroProfilerAutoCaptureUseCustomDirDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b8a3de*/
           a1: (__int64)"DebugMicroProfilerAutoCaptureUseCustomDir",
           a2: (__int64)&DFFlag::DebugMicroProfilerAutoCaptureUseCustomDir,
           a3: 2u);
}

// Address: 0x102b92986 | Name: __ZN6DFFlagL55rbxImplDynInit_EnablePerfPlaytestIdDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnablePerfPlaytestIdDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"EnablePerfPlaytestId", a2: (__int64)&DFFlag::EnablePerfPlaytestId, a3: 2u); /*0x102b9299d*/
}

// Address: 0x102b929a3 | Name: __ZN6DFFlagL65rbxImplDynInit_EnablePerfDataGatherTelemetry2DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnablePerfDataGatherTelemetry2DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b929ba*/
           a1: (__int64)"EnablePerfDataGatherTelemetry2",
           a2: (__int64)&DFFlag::EnablePerfDataGatherTelemetry2,
           a3: 2u);
}

// Address: 0x102b92a1f | Name: __ZN6DFFlagL48rbxImplDynInit_DebugPerfModeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugPerfModeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"DebugPerfMode", a2: (__int64)&DFFlag::DebugPerfMode, a3: 2u); /*0x102b92a36*/
}

// Address: 0x102b92a3c | Name: __ZN6DFFlagL73rbxImplDynInit_SendPerfDataFromRccIgnoringPlaceFilterDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SendPerfDataFromRccIgnoringPlaceFilterDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b92a53*/
           a1: (__int64)"SendPerfDataFromRccIgnoringPlaceFilter",
           a2: (__int64)&DFFlag::SendPerfDataFromRccIgnoringPlaceFilter,
           a3: 2u);
}

// Address: 0x102b92a59 | Name: __ZN6DFFlagL80rbxImplDynInit_GraphicsOptimizationModeMVPExposureEnrollmentDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_GraphicsOptimizationModeMVPExposureEnrollmentDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b92a70*/
           a1: (__int64)"GraphicsOptimizationModeMVPExposureEnrollment",
           a2: (__int64)&DFFlag::GraphicsOptimizationModeMVPExposureEnrollment,
           a3: 2u);
}

// Address: 0x102b92acf | Name: __ZN6DFFlagL51rbxImplDynInit_EnableFdTrackingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableFdTrackingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"EnableFdTracking", a2: (__int64)&DFFlag::EnableFdTracking, a3: 2u); /*0x102b92ae6*/
}

// Address: 0x102b92b02 | Name: __ZN6DFFlagL62rbxImplDynInit_PerfDataUseAdaptiveSamplingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_PerfDataUseAdaptiveSamplingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b92b19*/
           a1: (__int64)"PerfDataUseAdaptiveSampling",
           a2: (__int64)&DFFlag::PerfDataUseAdaptiveSampling,
           a3: 2u);
}

// Address: 0x102b92bed | Name: __ZN6DFFlagL59rbxImplDynInit_PerfDataCategoryGroupingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_PerfDataCategoryGroupingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b92c04*/
           a1: (__int64)"PerfDataCategoryGrouping",
           a2: (__int64)&DFFlag::PerfDataCategoryGrouping,
           a3: 2u);
}

// Address: 0x102b92c79 | Name: __ZN6DFFlagL60rbxImplDynInit_CheckPerfDataValueInRangeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CheckPerfDataValueInRangeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102b92c90*/
           a1: (__int64)"CheckPerfDataValueInRange",
           a2: (__int64)&DFFlag::CheckPerfDataValueInRange,
           a3: 2u);
}

// Address: 0x102b92c96 | Name: __ZN6DFFlagL52rbxImplDynInit_TrimPerfTelemetryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TrimPerfTelemetryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"TrimPerfTelemetry", a2: (__int64)&DFFlag::TrimPerfTelemetry, a3: 2u); /*0x102b92cad*/
}

// Address: 0x102b92ced | Name: __ZN6DFFlagL53rbxImplDynInit_PerfDataIncludeRslDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_PerfDataIncludeRslDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"PerfDataIncludeRsl", a2: (__int64)&DFFlag::PerfDataIncludeRsl, a3: 2u); /*0x102b92d04*/
}

// Address: 0x102ba03fa | Name: __ZN6DFFlagL56rbxImplDynInit_DebugCrashOnShutdown1DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugCrashOnShutdown1DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"DebugCrashOnShutdown1", a2: (__int64)&DFFlag::DebugCrashOnShutdown1, a3: 2u); /*0x102ba0411*/
}

// Address: 0x102ba042d | Name: __ZN6DFFlagL56rbxImplDynInit_DebugCrashOnShutdown2DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugCrashOnShutdown2DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"DebugCrashOnShutdown2", a2: (__int64)&DFFlag::DebugCrashOnShutdown2, a3: 2u); /*0x102ba0444*/
}

// Address: 0x102ba0460 | Name: __ZN6DFFlagL56rbxImplDynInit_DebugCrashOnShutdown3DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugCrashOnShutdown3DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"DebugCrashOnShutdown3", a2: (__int64)&DFFlag::DebugCrashOnShutdown3, a3: 2u); /*0x102ba0477*/
}

// Address: 0x102ba0493 | Name: __ZN6DFFlagL56rbxImplDynInit_DebugCrashOnShutdown4DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugCrashOnShutdown4DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"DebugCrashOnShutdown4", a2: (__int64)&DFFlag::DebugCrashOnShutdown4, a3: 2u); /*0x102ba04aa*/
}

// Address: 0x102ba04c6 | Name: __ZN6DFFlagL56rbxImplDynInit_DebugCrashOnShutdown5DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugCrashOnShutdown5DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"DebugCrashOnShutdown5", a2: (__int64)&DFFlag::DebugCrashOnShutdown5, a3: 2u); /*0x102ba04dd*/
}

// Address: 0x102ba1467 | Name: __ZN6DFFlagL61rbxImplDynInit_DebugDisableRCCChannelAPIsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugDisableRCCChannelAPIsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ba147e*/
           a1: (__int64)"DebugDisableRCCChannelAPIs",
           a2: (__int64)&DFFlag::DebugDisableRCCChannelAPIs,
           a3: 2u);
}

// Address: 0x102ba3fb6 | Name: __ZN6DFFlagL65rbxImplDynInit_DebugEnableClientPhaseTrackingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugEnableClientPhaseTrackingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ba3fcd*/
           a1: (__int64)"DebugEnableClientPhaseTracking",
           a2: (__int64)&DFFlag::DebugEnableClientPhaseTracking,
           a3: 2u);
}

// Address: 0x102ba4650 | Name: __ZN6DFFlagL64rbxImplDynInit_DebugEnableDisconnectionLabelDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugEnableDisconnectionLabelDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ba4667*/
           a1: (__int64)"DebugEnableDisconnectionLabel",
           a2: (__int64)&DFFlag::DebugEnableDisconnectionLabel,
           a3: 2u);
}

// Address: 0x102ba466d | Name: __ZN6DFFlagL65rbxImplDynInit_DebugDisableTelemetryAfterTestDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugDisableTelemetryAfterTestDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ba4684*/
           a1: (__int64)"DebugDisableTelemetryAfterTest",
           a2: (__int64)&DFFlag::DebugDisableTelemetryAfterTest,
           a3: 2u);
}

// Address: 0x102ba46f0 | Name: __ZN6DFFlagL59rbxImplDynInit_DebugEnablePhaseTrackingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugEnablePhaseTrackingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ba4707*/
           a1: (__int64)"DebugEnablePhaseTracking",
           a2: (__int64)&DFFlag::DebugEnablePhaseTracking,
           a3: 2u);
}

// Address: 0x102ba47d2 | Name: __ZN6DFFlagL56rbxImplDynInit_DebugRomarkDisconnectDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugRomarkDisconnectDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"DebugRomarkDisconnect", a2: (__int64)&DFFlag::DebugRomarkDisconnect, a3: 2u); /*0x102ba47e9*/
}

// Address: 0x102ba687a | Name: __ZN6DFFlagL61rbxImplDynInit_ReportClientUpdateShutdownDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_ReportClientUpdateShutdownDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ba6891*/
           a1: (__int64)"ReportClientUpdateShutdown",
           a2: (__int64)&DFFlag::ReportClientUpdateShutdown,
           a3: 2u);
}

// Address: 0x102ba6897 | Name: __ZN6DFFlagL64rbxImplDynInit_FixSuccessOOMExitedAccountingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FixSuccessOOMExitedAccountingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102ba68ae*/
           a1: (__int64)"FixSuccessOOMExitedAccounting",
           a2: (__int64)&DFFlag::FixSuccessOOMExitedAccounting,
           a3: 2u);
}

// Address: 0x102bac134 | Name: __ZN6DFFlagL69rbxImplDynInit_AddAppSessionIdL0ToCrashAnnotationDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AddAppSessionIdL0ToCrashAnnotationDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bac14b*/
           a1: (__int64)"AddAppSessionIdL0ToCrashAnnotation",
           a2: (__int64)&DFFlag::AddAppSessionIdL0ToCrashAnnotation,
           a3: 2u);
}

// Address: 0x102bac151 | Name: __ZN6DFFlagL65rbxImplDynInit_CollectSessionBatteryTelemetryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CollectSessionBatteryTelemetryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bac168*/
           a1: (__int64)"CollectSessionBatteryTelemetry",
           a2: (__int64)&DFFlag::CollectSessionBatteryTelemetry,
           a3: 2u);
}

// Address: 0x102bac16e | Name: __ZN6DFFlagL60rbxImplDynInit_IncludeThermalStatusTimesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_IncludeThermalStatusTimesDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bac185*/
           a1: (__int64)"IncludeThermalStatusTimes",
           a2: (__int64)&DFFlag::IncludeThermalStatusTimes,
           a3: 2u);
}

// Address: 0x102bb3822 | Name: __ZN6DFFlagL58rbxImplDynInit_AddMoreSysTrayTelemetryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AddMoreSysTrayTelemetryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bb3839*/
           a1: (__int64)"AddMoreSysTrayTelemetry",
           a2: (__int64)&DFFlag::AddMoreSysTrayTelemetry,
           a3: 2u);
}

// Address: 0x102bb97b6 | Name: __ZN6DFFlagL66rbxImplDynInit_FixTimestampedSafeQueueDeadlockDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FixTimestampedSafeQueueDeadlockDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bb97cd*/
           a1: (__int64)"FixTimestampedSafeQueueDeadlock",
           a2: (__int64)&DFFlag::FixTimestampedSafeQueueDeadlock,
           a3: 2u);
}

// Address: 0x102bbc972 | Name: __ZN6DFFlagL56rbxImplDynInit_EnableRemoteProfilingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableRemoteProfilingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"EnableRemoteProfiling", a2: (__int64)&DFFlag::EnableRemoteProfiling, a3: 2u); /*0x102bbc989*/
}

// Address: 0x102bbc9bb | Name: __ZN6DFFlagL73rbxImplDynInit_TaskSchedulerBlockingShutdownInClientsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TaskSchedulerBlockingShutdownInClientsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bbc9d2*/
           a1: (__int64)"TaskSchedulerBlockingShutdownInClients",
           a2: (__int64)&DFFlag::TaskSchedulerBlockingShutdownInClients,
           a3: 2u);
}

// Address: 0x102bbca30 | Name: __ZN6DFFlagL59rbxImplDynInit_TaskSchedulerPinArbitersDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TaskSchedulerPinArbitersDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bbca47*/
           a1: (__int64)"TaskSchedulerPinArbiters",
           a2: (__int64)&DFFlag::TaskSchedulerPinArbiters,
           a3: 2u);
}

// Address: 0x102bcec3d | Name: __ZN6DFFlagL63rbxImplDynInit_UnexpectedEventGlobalEnabledDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_UnexpectedEventGlobalEnabledDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bcec54*/
           a1: (__int64)"UnexpectedEventGlobalEnabled",
           a2: (__int64)&DFFlag::UnexpectedEventGlobalEnabled,
           a3: 2u);
}

// Address: 0x102bcecdf | Name: __ZN6DFFlagL58rbxImplDynInit_EnableNetworkDataAssertDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableNetworkDataAssertDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bcecf6*/
           a1: (__int64)"EnableNetworkDataAssert",
           a2: (__int64)&DFFlag::EnableNetworkDataAssert,
           a3: 2u);
}

// Address: 0x102bcf2de | Name: __ZN6DFFlagL44rbxImplDynInit_CLI111800DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CLI111800DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"CLI111800", a2: (__int64)&DFFlag::CLI111800, a3: 2u); /*0x102bcf2f5*/
}

// Address: 0x102bd7bbe | Name: __ZN6DFFlagL65rbxImplDynInit_EnableMacVmStatsBufferOversizeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableMacVmStatsBufferOversizeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bd7bd5*/
           a1: (__int64)"EnableMacVmStatsBufferOversize",
           a2: (__int64)&DFFlag::EnableMacVmStatsBufferOversize,
           a3: 2u);
}

// Address: 0x102bd7e68 | Name: __ZN6DFFlagL67rbxImplDynInit_RevertMacOSFreeMemoryCalculationDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RevertMacOSFreeMemoryCalculationDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bd7e7f*/
           a1: (__int64)"RevertMacOSFreeMemoryCalculation",
           a2: (__int64)&DFFlag::RevertMacOSFreeMemoryCalculation,
           a3: 2u);
}

// Address: 0x102bd8f66 | Name: __ZN6DFFlagL68rbxImplDynInit_MicroProfileAppleAsmChainCpuSpeedDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MicroProfileAppleAsmChainCpuSpeedDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bd8f7d*/
           a1: (__int64)"MicroProfileAppleAsmChainCpuSpeed",
           a2: (__int64)&DFFlag::MicroProfileAppleAsmChainCpuSpeed,
           a3: 2u);
}

// Address: 0x102bdad2a | Name: __ZN6DFFlagL59rbxImplDynInit_EnableIOSGPUFriendlyNameDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableIOSGPUFriendlyNameDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102bdad41*/
           a1: (__int64)"EnableIOSGPUFriendlyName",
           a2: (__int64)&DFFlag::EnableIOSGPUFriendlyName,
           a3: 2u);
}

// Address: 0x102f4e2f7 | Name: __ZN6DFFlagL62rbxImplDynInit_DebugGameServerHeaderBypassDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugGameServerHeaderBypassDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f4e30e*/
           a1: (__int64)"DebugGameServerHeaderBypass",
           a2: (__int64)&DFFlag::DebugGameServerHeaderBypass,
           a3: 2u);
}

// Address: 0x102f4e382 | Name: __ZN6DFFlagL56rbxImplDynInit_EnableRobloxCNDomainsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableRobloxCNDomainsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"EnableRobloxCNDomains", a2: (__int64)&DFFlag::EnableRobloxCNDomains, a3: 2u); /*0x102f4e399*/
}

// Address: 0x102f4e39f | Name: __ZN6DFFlagL59rbxImplDynInit_EnableRobloxLabsCnDomainDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableRobloxLabsCnDomainDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f4e3b6*/
           a1: (__int64)"EnableRobloxLabsCnDomain",
           a2: (__int64)&DFFlag::EnableRobloxLabsCnDomain,
           a3: 2u);
}

// Address: 0x102f4e3d9 | Name: __ZN6DFFlagL56rbxImplDynInit_CookieStoreEnabledMacDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CookieStoreEnabledMacDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"CookieStoreEnabledMac", a2: (__int64)&DFFlag::CookieStoreEnabledMac, a3: 2u); /*0x102f4e3f0*/
}

// Address: 0x102f4e40c | Name: __ZN6DFFlagL69rbxImplDynInit_CheckContextInfoAgainstHttpGlobalsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CheckContextInfoAgainstHttpGlobalsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f4e423*/
           a1: (__int64)"CheckContextInfoAgainstHttpGlobals",
           a2: (__int64)&DFFlag::CheckContextInfoAgainstHttpGlobals,
           a3: 2u);
}

// Address: 0x102f4e49f | Name: __ZN6DFFlagL54rbxImplDynInit_HttpAcceptNewCdnUrlDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpAcceptNewCdnUrlDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"HttpAcceptNewCdnUrl", a2: (__int64)&DFFlag::HttpAcceptNewCdnUrl, a3: 2u); /*0x102f4e4b6*/
}

// Address: 0x102f4e4bc | Name: __ZN6DFFlagL56rbxImplDynInit_AllowFtsVendorPinningDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AllowFtsVendorPinningDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"AllowFtsVendorPinning", a2: (__int64)&DFFlag::AllowFtsVendorPinning, a3: 2u); /*0x102f4e4d3*/
}

// Address: 0x102f4e4d9 | Name: __ZN6DFFlagL71rbxImplDynInit_HttpAcceptAssetQualityTempStoreS3UrlDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpAcceptAssetQualityTempStoreS3UrlDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f4e4f0*/
           a1: (__int64)"HttpAcceptAssetQualityTempStoreS3Url",
           a2: (__int64)&DFFlag::HttpAcceptAssetQualityTempStoreS3Url,
           a3: 2u);
}

// Address: 0x102f4e4f6 | Name: __ZN6DFFlagL53rbxImplDynInit_FtsVersionCacheKeyDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FtsVersionCacheKeyDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"FtsVersionCacheKey", a2: (__int64)&DFFlag::FtsVersionCacheKey, a3: 2u); /*0x102f4e50d*/
}

// Address: 0x102f5a7e1 | Name: __ZN6DFFlagL65rbxImplDynInit_HttpRedirCacheUseRefactoredAPIDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpRedirCacheUseRefactoredAPIDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f5a7f8*/
           a1: (__int64)"HttpRedirCacheUseRefactoredAPI",
           a2: (__int64)&DFFlag::HttpRedirCacheUseRefactoredAPI,
           a3: 2u);
}

// Address: 0x102f5a82a | Name: __ZN6DFFlagL64rbxImplDynInit_HttpUncompressedSizeKeepEntryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpUncompressedSizeKeepEntryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f5a841*/
           a1: (__int64)"HttpUncompressedSizeKeepEntry",
           a2: (__int64)&DFFlag::HttpUncompressedSizeKeepEntry,
           a3: 2u);
}

// Address: 0x102f6182b | Name: __ZN6DFFlagL61rbxImplDynInit_HttpSendMatchmakingContextDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpSendMatchmakingContextDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f61842*/
           a1: (__int64)"HttpSendMatchmakingContext",
           a2: (__int64)&DFFlag::HttpSendMatchmakingContext,
           a3: 2u);
}

// Address: 0x102f61848 | Name: __ZN6DFFlagL52rbxImplDynInit_HttpEnableTracingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpEnableTracingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"HttpEnableTracing", a2: (__int64)&DFFlag::HttpEnableTracing, a3: 2u); /*0x102f6185f*/
}

// Address: 0x102f61bea | Name: __ZN6DFFlagL74rbxImplDynInit_EarlyOutOnHttpRequestSendDuringShutdownDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EarlyOutOnHttpRequestSendDuringShutdownDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f61c01*/
           a1: (__int64)"EarlyOutOnHttpRequestSendDuringShutdown",
           a2: (__int64)&DFFlag::EarlyOutOnHttpRequestSendDuringShutdown,
           a3: 2u);
}

// Address: 0x102f61c50 | Name: __ZN6DFFlagL59rbxImplDynInit_HttpReportJobSigFallbackDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpReportJobSigFallbackDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f61c67*/
           a1: (__int64)"HttpReportJobSigFallback",
           a2: (__int64)&DFFlag::HttpReportJobSigFallback,
           a3: 2u);
}

// Address: 0x102f61c6d | Name: __ZN6DFFlagL71rbxImplDynInit_HttpSkipJobSigFallbackWhenAlreadySetDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpSkipJobSigFallbackWhenAlreadySetDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f61c84*/
           a1: (__int64)"HttpSkipJobSigFallbackWhenAlreadySet",
           a2: (__int64)&DFFlag::HttpSkipJobSigFallbackWhenAlreadySet,
           a3: 2u);
}

// Address: 0x102f61d9a | Name: __ZN6DFFlagL63rbxImplDynInit_HttpClientCookieStoreMetricsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpClientCookieStoreMetricsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f61db1*/
           a1: (__int64)"HttpClientCookieStoreMetrics",
           a2: (__int64)&DFFlag::HttpClientCookieStoreMetrics,
           a3: 2u);
}

// Address: 0x102f61db7 | Name: __ZN6DFFlagL69rbxImplDynInit_HttpCacheCleanScheduleBasedOnBytesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpCacheCleanScheduleBasedOnBytesDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f61dce*/
           a1: (__int64)"HttpCacheCleanScheduleBasedOnBytes",
           a2: (__int64)&DFFlag::HttpCacheCleanScheduleBasedOnBytes,
           a3: 2u);
}

// Address: 0x102f61e00 | Name: __ZN6DFFlagL54rbxImplDynInit_ReportCacheDirSizesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_ReportCacheDirSizesDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"ReportCacheDirSizes", a2: (__int64)&DFFlag::ReportCacheDirSizes, a3: 2u); /*0x102f61e17*/
}

// Address: 0x102f61fb2 | Name: __ZN6DFFlagL57rbxImplDynInit_ReportSendSpireSvidJwtDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_ReportSendSpireSvidJwtDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"ReportSendSpireSvidJwt", a2: (__int64)&DFFlag::ReportSendSpireSvidJwt, a3: 2u); /*0x102f61fc9*/
}

// Address: 0x102f61fcf | Name: __ZN6DFFlagL74rbxImplDynInit_HttpClientSkipRetryForStreamingRequestsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpClientSkipRetryForStreamingRequestsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f61fe6*/
           a1: (__int64)"HttpClientSkipRetryForStreamingRequests",
           a2: (__int64)&DFFlag::HttpClientSkipRetryForStreamingRequests,
           a3: 2u);
}

// Address: 0x102f61fec | Name: __ZN6DFFlagL58rbxImplDynInit_UseFtsThumbEnrollHeaderDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_UseFtsThumbEnrollHeaderDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f62003*/
           a1: (__int64)"UseFtsThumbEnrollHeader",
           a2: (__int64)&DFFlag::UseFtsThumbEnrollHeader,
           a3: 2u);
}

// Address: 0x102f62135 | Name: __ZN6DFFlagL55rbxImplDynInit_HttpUncompressedSizeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpUncompressedSizeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"HttpUncompressedSize", a2: (__int64)&DFFlag::HttpUncompressedSize, a3: 2u); /*0x102f6214c*/
}

// Address: 0x102f62152 | Name: __ZN6DFFlagL57rbxImplDynInit_HttpUncompressedSizeAPDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpUncompressedSizeAPDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"HttpUncompressedSizeAP", a2: (__int64)&DFFlag::HttpUncompressedSizeAP, a3: 2u); /*0x102f62169*/
}

// Address: 0x102f6216f | Name: __ZN6DFFlagL61rbxImplDynInit_HttpUncompressedSizeCommonDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpUncompressedSizeCommonDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f62186*/
           a1: (__int64)"HttpUncompressedSizeCommon",
           a2: (__int64)&DFFlag::HttpUncompressedSizeCommon,
           a3: 2u);
}

// Address: 0x102f6218c | Name: __ZN6DFFlagL80rbxImplDynInit_DontReportAccumulatedStatsInHttpClientDestroyDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DontReportAccumulatedStatsInHttpClientDestroyDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f621a3*/
           a1: (__int64)"DontReportAccumulatedStatsInHttpClientDestroy",
           a2: (__int64)&DFFlag::DontReportAccumulatedStatsInHttpClientDestroy,
           a3: 2u);
}

// Address: 0x102f621a9 | Name: __ZN6DFFlagL71rbxImplDynInit_FixHttpStreamingCallbackUseAfterFreeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FixHttpStreamingCallbackUseAfterFreeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f621c0*/
           a1: (__int64)"FixHttpStreamingCallbackUseAfterFree",
           a2: (__int64)&DFFlag::FixHttpStreamingCallbackUseAfterFree,
           a3: 2u);
}

// Address: 0x102f6221f | Name: __ZN6DFFlagL66rbxImplDynInit_HttpClientDontSendDisableSignalDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpClientDontSendDisableSignalDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f62236*/
           a1: (__int64)"HttpClientDontSendDisableSignal",
           a2: (__int64)&DFFlag::HttpClientDontSendDisableSignal,
           a3: 2u);
}

// Address: 0x102f7f9f7 | Name: __ZN6DFFlagL70rbxImplDynInit_DebugHttpSyncCallsForStatsReportingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugHttpSyncCallsForStatsReportingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f7fa0e*/
           a1: (__int64)"DebugHttpSyncCallsForStatsReporting",
           a2: (__int64)&DFFlag::DebugHttpSyncCallsForStatsReporting,
           a3: 2u);
}

// Address: 0x102f8692c | Name: __ZN6DFFlagL63rbxImplDynInit_UnifiedCookieProtocolEnabledDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_UnifiedCookieProtocolEnabledDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f86943*/
           a1: (__int64)"UnifiedCookieProtocolEnabled",
           a2: (__int64)&DFFlag::UnifiedCookieProtocolEnabled,
           a3: 2u);
}

// Address: 0x102f86983 | Name: __ZN6DFFlagL71rbxImplDynInit_EnableHttpCookieStorageChangedSignalDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableHttpCookieStorageChangedSignalDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f8699a*/
           a1: (__int64)"EnableHttpCookieStorageChangedSignal",
           a2: (__int64)&DFFlag::EnableHttpCookieStorageChangedSignal,
           a3: 2u);
}

// Address: 0x102f8c19e | Name: __ZN6DFFlagL64rbxImplDynInit_DebugHttpRequestSecondaryImplDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugHttpRequestSecondaryImplDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f8c1b5*/
           a1: (__int64)"DebugHttpRequestSecondaryImpl",
           a2: (__int64)&DFFlag::DebugHttpRequestSecondaryImpl,
           a3: 2u);
}

// Address: 0x102f8c228 | Name: __ZN6DFFlagL48rbxImplDynInit_TestHttp3ReqsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TestHttp3ReqsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"TestHttp3Reqs", a2: (__int64)&DFFlag::TestHttp3Reqs, a3: 2u); /*0x102f8c23f*/
}

// Address: 0x102f95aca | Name: __ZN6DFFlagL50rbxImplDynInit_HttpNetworkTypeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpNetworkTypeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"HttpNetworkType", a2: (__int64)&DFFlag::HttpNetworkType, a3: 2u); /*0x102f95ae1*/
}

// Address: 0x102f95ae7 | Name: __ZN6DFFlagL63rbxImplDynInit_HttpDynamicSuccessStatusCodeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpDynamicSuccessStatusCodeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f95afe*/
           a1: (__int64)"HttpDynamicSuccessStatusCode",
           a2: (__int64)&DFFlag::HttpDynamicSuccessStatusCode,
           a3: 2u);
}

// Address: 0x102f95b30 | Name: __ZN6DFFlagL71rbxImplDynInit_HttpClientDetectInvalidRangeResponseDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpClientDetectInvalidRangeResponseDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f95b47*/
           a1: (__int64)"HttpClientDetectInvalidRangeResponse",
           a2: (__int64)&DFFlag::HttpClientDetectInvalidRangeResponse,
           a3: 2u);
}

// Address: 0x102f95b4d | Name: __ZN6DFFlagL72rbxImplDynInit_HttpClientResolveInvalidRangeResponseDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpClientResolveInvalidRangeResponseDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f95b64*/
           a1: (__int64)"HttpClientResolveInvalidRangeResponse",
           a2: (__int64)&DFFlag::HttpClientResolveInvalidRangeResponse,
           a3: 2u);
}

// Address: 0x102f95b6a | Name: __ZN6DFFlagL51rbxImplDynInit_UseSizedHttpBodyDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_UseSizedHttpBodyDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"UseSizedHttpBody", a2: (__int64)&DFFlag::UseSizedHttpBody, a3: 2u); /*0x102f95b81*/
}

// Address: 0x102f97802 | Name: __ZN6DFFlagL60rbxImplDynInit_HttpRetryOnExplicitHeaderDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpRetryOnExplicitHeaderDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102f97819*/
           a1: (__int64)"HttpRetryOnExplicitHeader",
           a2: (__int64)&DFFlag::HttpRetryOnExplicitHeader,
           a3: 2u);
}

// Address: 0x102fa3e57 | Name: __ZN6DFFlagL69rbxImplDynInit_EnableHttpThrottlingPrefixWildcardDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableHttpThrottlingPrefixWildcardDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102fa3e6e*/
           a1: (__int64)"EnableHttpThrottlingPrefixWildcard",
           a2: (__int64)&DFFlag::EnableHttpThrottlingPrefixWildcard,
           a3: 2u);
}

// Address: 0x102fb66d6 | Name: __ZN6DFFlagL60rbxImplDynInit_HttpBlockWhenAppSuspendedDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpBlockWhenAppSuspendedDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x102fb66ed*/
           a1: (__int64)"HttpBlockWhenAppSuspended",
           a2: (__int64)&DFFlag::HttpBlockWhenAppSuspended,
           a3: 2u);
}

// Address: 0x102fb6709 | Name: __ZN6DFFlagL44rbxImplDynInit_CLI206370DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CLI206370DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"CLI206370", a2: (__int64)&DFFlag::CLI206370, a3: 2u); /*0x102fb6720*/
}

// Address: 0x102fb6726 | Name: __ZN6DFFlagL55rbxImplDynInit_HttpLastAppSuspendedDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpLastAppSuspendedDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"HttpLastAppSuspended", a2: (__int64)&DFFlag::HttpLastAppSuspended, a3: 2u); /*0x102fb673d*/
}

// Address: 0x102fb67ec | Name: __ZN6DFFlagL54rbxImplDynInit_Http2ExcludeCdnReqsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_Http2ExcludeCdnReqsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"Http2ExcludeCdnReqs", a2: (__int64)&DFFlag::Http2ExcludeCdnReqs, a3: 2u); /*0x102fb6803*/
}

// Address: 0x102fb6835 | Name: __ZN6DFFlagL47rbxImplDynInit_Http3CdnReqsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_Http3CdnReqsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"Http3CdnReqs", a2: (__int64)&DFFlag::Http3CdnReqs, a3: 2u); /*0x102fb684c*/
}

// Address: 0x102fb68ab | Name: __ZN6DFFlagL47rbxImplDynInit_Http3FtsReqsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_Http3FtsReqsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"Http3FtsReqs", a2: (__int64)&DFFlag::Http3FtsReqs, a3: 2u); /*0x102fb68c2*/
}

// Address: 0x102fb6921 | Name: __ZN6DFFlagL56rbxImplDynInit_Http3FtsReqsAndroid32DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_Http3FtsReqsAndroid32DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"Http3FtsReqsAndroid32", a2: (__int64)&DFFlag::Http3FtsReqsAndroid32, a3: 2u); /*0x102fb6938*/
}

// Address: 0x102fb693e | Name: __ZN6DFFlagL47rbxImplDynInit_Http3BackoffDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_Http3BackoffDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"Http3Backoff", a2: (__int64)&DFFlag::Http3Backoff, a3: 2u); /*0x102fb6955*/
}

// Address: 0x1030097fc | Name: __ZN6DFFlagL61rbxImplDynInit_FileCacheDisableFileBufferDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FileCacheDisableFileBufferDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103009813*/
           a1: (__int64)"FileCacheDisableFileBuffer",
           a2: (__int64)&DFFlag::FileCacheDisableFileBuffer,
           a3: 2u);
}

// Address: 0x103009819 | Name: __ZN6DFFlagL59rbxImplDynInit_FileCacheFlushAfterWriteDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FileCacheFlushAfterWriteDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103009830*/
           a1: (__int64)"FileCacheFlushAfterWrite",
           a2: (__int64)&DFFlag::FileCacheFlushAfterWrite,
           a3: 2u);
}

// Address: 0x103009862 | Name: __ZN6DFFlagL56rbxImplDynInit_FileCacheDirSizeYieldDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FileCacheDirSizeYieldDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"FileCacheDirSizeYield", a2: (__int64)&DFFlag::FileCacheDirSizeYield, a3: 2u); /*0x103009879*/
}

// Address: 0x10300987f | Name: __ZN6DFFlagL54rbxImplDynInit_FileCacheClearYieldDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FileCacheClearYieldDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"FileCacheClearYield", a2: (__int64)&DFFlag::FileCacheClearYield, a3: 2u); /*0x103009896*/
}

// Address: 0x10300989c | Name: __ZN6DFFlagL53rbxImplDynInit_FileCacheCheckSizeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FileCacheCheckSizeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"FileCacheCheckSize", a2: (__int64)&DFFlag::FileCacheCheckSize, a3: 2u); /*0x1030098b3*/
}

// Address: 0x1030098d6 | Name: __ZN6DFFlagL61rbxImplDynInit_FileCacheGuardLowDiskSpaceDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FileCacheGuardLowDiskSpaceDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1030098ed*/
           a1: (__int64)"FileCacheGuardLowDiskSpace",
           a2: (__int64)&DFFlag::FileCacheGuardLowDiskSpace,
           a3: 2u);
}

// Address: 0x103009935 | Name: __ZN6DFFlagL61rbxImplDynInit_FileCacheManualStatsReloadDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_FileCacheManualStatsReloadDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10300994c*/
           a1: (__int64)"FileCacheManualStatsReload",
           a2: (__int64)&DFFlag::FileCacheManualStatsReload,
           a3: 2u);
}

// Address: 0x10300ffd2 | Name: __ZN6DFFlagL55rbxImplDynInit_MemCacheRetryPendingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MemCacheRetryPendingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"MemCacheRetryPending", a2: (__int64)&DFFlag::MemCacheRetryPending, a3: 2u); /*0x10300ffe9*/
}

// Address: 0x10300ffef | Name: __ZN6DFFlagL57rbxImplDynInit_MemCacheFixSetFromFileDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MemCacheFixSetFromFileDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"MemCacheFixSetFromFile", a2: (__int64)&DFFlag::MemCacheFixSetFromFile, a3: 2u); /*0x103010006*/
}

// Address: 0x103015ec2 | Name: __ZN6DFFlagL61rbxImplDynInit_RbxStorageQueryNumExternalDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageQueryNumExternalDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103015ed9*/
           a1: (__int64)"RbxStorageQueryNumExternal",
           a2: (__int64)&DFFlag::RbxStorageQueryNumExternal,
           a3: 2u);
}

// Address: 0x10301614d | Name: __ZN6DFFlagL66rbxImplDynInit_RbxStorageSkipFileCacheNumItemsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageSkipFileCacheNumItemsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103016164*/
           a1: (__int64)"RbxStorageSkipFileCacheNumItems",
           a2: (__int64)&DFFlag::RbxStorageSkipFileCacheNumItems,
           a3: 2u);
}

// Address: 0x10301616a | Name: __ZN6DFFlagL70rbxImplDynInit_RbxStorageSkipFileCachePermNumItemsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageSkipFileCachePermNumItemsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103016181*/
           a1: (__int64)"RbxStorageSkipFileCachePermNumItems",
           a2: (__int64)&DFFlag::RbxStorageSkipFileCachePermNumItems,
           a3: 2u);
}

// Address: 0x103016187 | Name: __ZN6DFFlagL58rbxImplDynInit_RbxStorageReportHitRateDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageReportHitRateDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10301619e*/
           a1: (__int64)"RbxStorageReportHitRate",
           a2: (__int64)&DFFlag::RbxStorageReportHitRate,
           a3: 2u);
}

// Address: 0x10301622f | Name: __ZN6DFFlagL74rbxImplDynInit_RbxStorageCleanupBeforeCleanupTelemetryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageCleanupBeforeCleanupTelemetryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103016246*/
           a1: (__int64)"RbxStorageCleanupBeforeCleanupTelemetry",
           a2: (__int64)&DFFlag::RbxStorageCleanupBeforeCleanupTelemetry,
           a3: 2u);
}

// Address: 0x1030162a5 | Name: __ZN6DFFlagL82rbxImplDynInit_RbxStorageDontQueryForNonPermanentCategorySizesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageDontQueryForNonPermanentCategorySizesDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1030162bc*/
           a1: (__int64)"RbxStorageDontQueryForNonPermanentCategorySizes",
           a2: (__int64)&DFFlag::RbxStorageDontQueryForNonPermanentCategorySizes,
           a3: 2u);
}

// Address: 0x103016404 | Name: __ZN6DFFlagL67rbxImplDynInit_RbxStorageLogReadWriteByCategoryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageLogReadWriteByCategoryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10301641b*/
           a1: (__int64)"RbxStorageLogReadWriteByCategory",
           a2: (__int64)&DFFlag::RbxStorageLogReadWriteByCategory,
           a3: 2u);
}

// Address: 0x10301643e | Name: __ZN6DFFlagL64rbxImplDynInit_RbxStorageReportHitRateFromTCDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageReportHitRateFromTCDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103016455*/
           a1: (__int64)"RbxStorageReportHitRateFromTC",
           a2: (__int64)&DFFlag::RbxStorageReportHitRateFromTC,
           a3: 2u);
}

// Address: 0x10301645b | Name: __ZN6DFFlagL74rbxImplDynInit_RbxStorageContinueAfterOldCacheEvictionDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageContinueAfterOldCacheEvictionDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103016472*/
           a1: (__int64)"RbxStorageContinueAfterOldCacheEviction",
           a2: (__int64)&DFFlag::RbxStorageContinueAfterOldCacheEviction,
           a3: 2u);
}

// Address: 0x103021e06 | Name: __ZN6DFFlagL58rbxImplDynInit_SqliteCacheUseTTLOnReadDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SqliteCacheUseTTLOnReadDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103021e1d*/
           a1: (__int64)"SqliteCacheUseTTLOnRead",
           a2: (__int64)&DFFlag::SqliteCacheUseTTLOnRead,
           a3: 2u);
}

// Address: 0x103021e39 | Name: __ZN6DFFlagL64rbxImplDynInit_EnableNewRollingCategoryStatsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_EnableNewRollingCategoryStatsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103021e50*/
           a1: (__int64)"EnableNewRollingCategoryStats",
           a2: (__int64)&DFFlag::EnableNewRollingCategoryStats,
           a3: 2u);
}

// Address: 0x103021ec5 | Name: __ZN6DFFlagL64rbxImplDynInit_SQLiteCacheReportSizeMismatchDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SQLiteCacheReportSizeMismatchDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103021edc*/
           a1: (__int64)"SQLiteCacheReportSizeMismatch",
           a2: (__int64)&DFFlag::SQLiteCacheReportSizeMismatch,
           a3: 2u);
}

// Address: 0x103021f3b | Name: __ZN6DFFlagL57rbxImplDynInit_SQLiteBadSizeTelemetryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SQLiteBadSizeTelemetryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"SQLiteBadSizeTelemetry", a2: (__int64)&DFFlag::SQLiteBadSizeTelemetry, a3: 2u); /*0x103021f52*/
}

// Address: 0x103021f84 | Name: __ZN6DFFlagL59rbxImplDynInit_SQLiteCacheBatchEvictionDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SQLiteCacheBatchEvictionDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103021f9b*/
           a1: (__int64)"SQLiteCacheBatchEviction",
           a2: (__int64)&DFFlag::SQLiteCacheBatchEviction,
           a3: 2u);
}

// Address: 0x103021ffa | Name: __ZN6DFFlagL57rbxImplDynInit_SQLiteCacheBatchUpdateDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SQLiteCacheBatchUpdateDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"SQLiteCacheBatchUpdate", a2: (__int64)&DFFlag::SQLiteCacheBatchUpdate, a3: 2u); /*0x103022011*/
}

// Address: 0x1030220a3 | Name: __ZN6DFFlagL72rbxImplDynInit_SQLiteCacheCreateIndexForExternalKeysDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SQLiteCacheCreateIndexForExternalKeysDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1030220ba*/
           a1: (__int64)"SQLiteCacheCreateIndexForExternalKeys",
           a2: (__int64)&DFFlag::SQLiteCacheCreateIndexForExternalKeys,
           a3: 2u);
}

// Address: 0x103029556 | Name: __ZN6DFFlagL58rbxImplDynInit_SQLiteStatementLogErrorDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SQLiteStatementLogErrorDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10302956d*/
           a1: (__int64)"SQLiteStatementLogError",
           a2: (__int64)&DFFlag::SQLiteStatementLogError,
           a3: 2u);
}

// Address: 0x103029573 | Name: __ZN6DFFlagL61rbxImplDynInit_SQLiteStatementLogErrorMsgDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SQLiteStatementLogErrorMsgDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10302958a*/
           a1: (__int64)"SQLiteStatementLogErrorMsg",
           a2: (__int64)&DFFlag::SQLiteStatementLogErrorMsg,
           a3: 2u);
}

// Address: 0x1030295bc | Name: __ZN6DFFlagL54rbxImplDynInit_SQLiteClearBindingsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SQLiteClearBindingsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"SQLiteClearBindings", a2: (__int64)&DFFlag::SQLiteClearBindings, a3: 2u); /*0x1030295d3*/
}

// Address: 0x10302c2ae | Name: __ZN6DFFlagL64rbxImplDynInit_RbxStorageAvailableSpaceErrorDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageAvailableSpaceErrorDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10302c2c5*/
           a1: (__int64)"RbxStorageAvailableSpaceError",
           a2: (__int64)&DFFlag::RbxStorageAvailableSpaceError,
           a3: 2u);
}

// Address: 0x10302c2cb | Name: __ZN6DFFlagL65rbxImplDynInit_RbxStorageRemoveFileCacheYieldDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageRemoveFileCacheYieldDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10302c2e2*/
           a1: (__int64)"RbxStorageRemoveFileCacheYield",
           a2: (__int64)&DFFlag::RbxStorageRemoveFileCacheYield,
           a3: 2u);
}

// Address: 0x10302c2e8 | Name: __ZN6DFFlagL64rbxImplDynInit_RbxStorageRemoveOldCacheYieldDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageRemoveOldCacheYieldDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10302c2ff*/
           a1: (__int64)"RbxStorageRemoveOldCacheYield",
           a2: (__int64)&DFFlag::RbxStorageRemoveOldCacheYield,
           a3: 2u);
}

// Address: 0x10302f2ba | Name: __ZN6DFFlagL59rbxImplDynInit_RbxStorageTCTrackHitRateDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxStorageTCTrackHitRateDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10302f2d1*/
           a1: (__int64)"RbxStorageTCTrackHitRate",
           a2: (__int64)&DFFlag::RbxStorageTCTrackHitRate,
           a3: 2u);
}

// Address: 0x103207ee0 | Name: __ZN6DFFlagL63rbxImplDynInit_QueryNearestTriangleUseScaleDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_QueryNearestTriangleUseScaleDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103207ef7*/
           a1: (__int64)"QueryNearestTriangleUseScale",
           a2: (__int64)&DFFlag::QueryNearestTriangleUseScale,
           a3: 2u);
}

// Address: 0x1032115d7 | Name: __ZN6DFFlagL74rbxImplDynInit_SplineFixRemoveControlPointStaleSegmentDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SplineFixRemoveControlPointStaleSegmentDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1032115ee*/
           a1: (__int64)"SplineFixRemoveControlPointStaleSegment",
           a2: (__int64)&DFFlag::SplineFixRemoveControlPointStaleSegment,
           a3: 2u);
}

// Address: 0x103216a24 | Name: __ZN6DFFlagL54rbxImplDynInit_RBXASSERT_CLI155121DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RBXASSERT_CLI155121DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"RBXASSERT_CLI155121", a2: (__int64)&DFFlag::RBXASSERT_CLI155121, a3: 2u); /*0x103216a3b*/
}

// Address: 0x103216ab0 | Name: __ZN6DFFlagL54rbxImplDynInit_RBXASSERT_CLI155122DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RBXASSERT_CLI155122DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"RBXASSERT_CLI155122", a2: (__int64)&DFFlag::RBXASSERT_CLI155122, a3: 2u); /*0x103216ac7*/
}

// Address: 0x10322231c | Name: __ZN6DFFlagL69rbxImplDynInit_SimAlwaysOrthonormalizeJointCoordsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SimAlwaysOrthonormalizeJointCoordsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103222333*/
           a1: (__int64)"SimAlwaysOrthonormalizeJointCoords",
           a2: (__int64)&DFFlag::SimAlwaysOrthonormalizeJointCoords,
           a3: 2u);
}

// Address: 0x103249e45 | Name: __ZN6DFFlagL73rbxImplDynInit_DisableAutoTagLocationToV2CounterStatsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DisableAutoTagLocationToV2CounterStatsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103249e5c*/
           a1: (__int64)"DisableAutoTagLocationToV2CounterStats",
           a2: (__int64)&DFFlag::DisableAutoTagLocationToV2CounterStats,
           a3: 2u);
}

// Address: 0x103249e8e | Name: __ZN6DFFlagL81rbxImplDynInit_TelemetryAddStreamingEnabledToCountersAndStatsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryAddStreamingEnabledToCountersAndStatsDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103249ea5*/
           a1: (__int64)"TelemetryAddStreamingEnabledToCountersAndStats",
           a2: (__int64)&DFFlag::TelemetryAddStreamingEnabledToCountersAndStats,
           a3: 2u);
}

// Address: 0x103249eab | Name: __ZN6DFFlagL58rbxImplDynInit_TelemetryValidateFieldsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryValidateFieldsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103249ec2*/
           a1: (__int64)"TelemetryValidateFields",
           a2: (__int64)&DFFlag::TelemetryValidateFields,
           a3: 2u);
}

// Address: 0x103249ec8 | Name: __ZN6DFFlagL61rbxImplDynInit_TelemetryDropInvalidFieldsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryDropInvalidFieldsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103249edf*/
           a1: (__int64)"TelemetryDropInvalidFields",
           a2: (__int64)&DFFlag::TelemetryDropInvalidFields,
           a3: 2u);
}

// Address: 0x103249ee5 | Name: __ZN6DFFlagL60rbxImplDynInit_TelemetryPreventNaNAndInfDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryPreventNaNAndInfDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103249efc*/
           a1: (__int64)"TelemetryPreventNaNAndInf",
           a2: (__int64)&DFFlag::TelemetryPreventNaNAndInf,
           a3: 2u);
}

// Address: 0x103249f02 | Name: __ZN6DFFlagL62rbxImplDynInit_TelemetryPreventEmptyFieldsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryPreventEmptyFieldsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103249f19*/
           a1: (__int64)"TelemetryPreventEmptyFields",
           a2: (__int64)&DFFlag::TelemetryPreventEmptyFields,
           a3: 2u);
}

// Address: 0x103249f1f | Name: __ZN6DFFlagL70rbxImplDynInit_TelemetryPreventInvalidValueStringsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryPreventInvalidValueStringsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103249f36*/
           a1: (__int64)"TelemetryPreventInvalidValueStrings",
           a2: (__int64)&DFFlag::TelemetryPreventInvalidValueStrings,
           a3: 2u);
}

// Address: 0x103249f3c | Name: __ZN6DFFlagL68rbxImplDynInit_TelemetryPreventInvalidKeyStringsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryPreventInvalidKeyStringsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103249f53*/
           a1: (__int64)"TelemetryPreventInvalidKeyStrings",
           a2: (__int64)&DFFlag::TelemetryPreventInvalidKeyStrings,
           a3: 2u);
}

// Address: 0x103249f76 | Name: __ZN6DFFlagL59rbxImplDynInit_TelemetryPreventLongKeysDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryPreventLongKeysDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103249f8d*/
           a1: (__int64)"TelemetryPreventLongKeys",
           a2: (__int64)&DFFlag::TelemetryPreventLongKeys,
           a3: 2u);
}

// Address: 0x103249fa9 | Name: __ZN6DFFlagL61rbxImplDynInit_TelemetryPreventLongValuesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryPreventLongValuesDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103249fc0*/
           a1: (__int64)"TelemetryPreventLongValues",
           a2: (__int64)&DFFlag::TelemetryPreventLongValues,
           a3: 2u);
}

// Address: 0x103255ff8 | Name: __ZN6DFFlagL64rbxImplDynInit_MigrateRenderingTelemetryToV2DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MigrateRenderingTelemetryToV2DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10325600f*/
           a1: (__int64)"MigrateRenderingTelemetryToV2",
           a2: (__int64)&DFFlag::MigrateRenderingTelemetryToV2,
           a3: 2u);
}

// Address: 0x103256015 | Name: __ZN6DFFlagL71rbxImplDynInit_DisableRenderingLegacyTelemetryCallsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DisableRenderingLegacyTelemetryCallsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10325602c*/
           a1: (__int64)"DisableRenderingLegacyTelemetryCalls",
           a2: (__int64)&DFFlag::DisableRenderingLegacyTelemetryCalls,
           a3: 2u);
}

// Address: 0x1032562ea | Name: __ZN6DFFlagL88rbxImplDynInit_TelemetryMigrationEnableNewAndroidSettingsLoadSuccessDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationEnableNewAndroidSettingsLoadSuccessDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103256301*/
           a1: (__int64)"TelemetryMigrationEnableNewAndroidSettingsLoadSuccess",
           a2: (__int64)&DFFlag::TelemetryMigrationEnableNewAndroidSettingsLoadSuccess,
           a3: 2u);
}

// Address: 0x103256307 | Name: __ZN6DFFlagL91rbxImplDynInit_TelemetryMigrationRemoveLegacyAndroidSettingsLoadSuccessDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationRemoveLegacyAndroidSettingsLoadSuccessDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10325631e*/
           a1: (__int64)"TelemetryMigrationRemoveLegacyAndroidSettingsLoadSuccess",
           a2: (__int64)&DFFlag::TelemetryMigrationRemoveLegacyAndroidSettingsLoadSuccess,
           a3: 2u);
}

// Address: 0x103256324 | Name: __ZN6DFFlagL84rbxImplDynInit_TelemetryMigrationEnableNewIosSettingsLoadSuccessDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationEnableNewIosSettingsLoadSuccessDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10325633b*/
           a1: (__int64)"TelemetryMigrationEnableNewIosSettingsLoadSuccess",
           a2: (__int64)&DFFlag::TelemetryMigrationEnableNewIosSettingsLoadSuccess,
           a3: 2u);
}

// Address: 0x103256341 | Name: __ZN6DFFlagL87rbxImplDynInit_TelemetryMigrationRemoveLegacyIosSettingsLoadSuccessDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationRemoveLegacyIosSettingsLoadSuccessDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103256358*/
           a1: (__int64)"TelemetryMigrationRemoveLegacyIosSettingsLoadSuccess",
           a2: (__int64)&DFFlag::TelemetryMigrationRemoveLegacyIosSettingsLoadSuccess,
           a3: 2u);
}

// Address: 0x10325635e | Name: __ZN6DFFlagL84rbxImplDynInit_TelemetryMigrationEnableNewRCCSettingsLoadSuccessDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationEnableNewRCCSettingsLoadSuccessDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103256375*/
           a1: (__int64)"TelemetryMigrationEnableNewRCCSettingsLoadSuccess",
           a2: (__int64)&DFFlag::TelemetryMigrationEnableNewRCCSettingsLoadSuccess,
           a3: 2u);
}

// Address: 0x10325637b | Name: __ZN6DFFlagL87rbxImplDynInit_TelemetryMigrationRemoveLegacyRCCSettingsLoadSuccessDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationRemoveLegacyRCCSettingsLoadSuccessDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103256392*/
           a1: (__int64)"TelemetryMigrationRemoveLegacyRCCSettingsLoadSuccess",
           a2: (__int64)&DFFlag::TelemetryMigrationRemoveLegacyRCCSettingsLoadSuccess,
           a3: 2u);
}

// Address: 0x103256398 | Name: __ZN6DFFlagL79rbxImplDynInit_TelemetryMigrationEnableNewMacOSSettingsLoadDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationEnableNewMacOSSettingsLoadDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1032563af*/
           a1: (__int64)"TelemetryMigrationEnableNewMacOSSettingsLoad",
           a2: (__int64)&DFFlag::TelemetryMigrationEnableNewMacOSSettingsLoad,
           a3: 2u);
}

// Address: 0x1032563b5 | Name: __ZN6DFFlagL82rbxImplDynInit_TelemetryMigrationRemoveLegacyMacOSSettingsLoadDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationRemoveLegacyMacOSSettingsLoadDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1032563cc*/
           a1: (__int64)"TelemetryMigrationRemoveLegacyMacOSSettingsLoad",
           a2: (__int64)&DFFlag::TelemetryMigrationRemoveLegacyMacOSSettingsLoad,
           a3: 2u);
}

// Address: 0x1032563d2 | Name: __ZN6DFFlagL99rbxImplDynInit_TelemetryMigrationEnableNewFlagFetchingStarterModuleSettingsLoadDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationEnableNewFlagFetchingStarterModuleSettingsLoadDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1032563e9*/
           a1: (__int64)"TelemetryMigrationEnableNewFlagFetchingStarterModuleSettingsLoad",
           a2: (__int64)&DFFlag::TelemetryMigrationEnableNewFlagFetchingStarterModuleSettingsLoad,
           a3: 2u);
}

// Address: 0x1032563ef | Name: __ZN6DFFlagL102rbxImplDynInit_TelemetryMigrationRemoveLegacyFlagFetchingStarterModuleSettingsLoadDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationRemoveLegacyFlagFetchingStarterModuleSettingsLoadDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103256406*/
           a1: (__int64)"TelemetryMigrationRemoveLegacyFlagFetchingStarterModuleSettingsLoad",
           a2: (__int64)&DFFlag::TelemetryMigrationRemoveLegacyFlagFetchingStarterModuleSettingsLoad,
           a3: 2u);
}

// Address: 0x10325640c | Name: __ZN6DFFlagL85rbxImplDynInit_TelemetryMigrationEnableNewXboxSettingsLoadSuccessDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationEnableNewXboxSettingsLoadSuccessDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103256423*/
           a1: (__int64)"TelemetryMigrationEnableNewXboxSettingsLoadSuccess",
           a2: (__int64)&DFFlag::TelemetryMigrationEnableNewXboxSettingsLoadSuccess,
           a3: 2u);
}

// Address: 0x103256429 | Name: __ZN6DFFlagL88rbxImplDynInit_TelemetryMigrationRemoveLegacyXboxSettingsLoadSuccessDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TelemetryMigrationRemoveLegacyXboxSettingsLoadSuccessDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103256440*/
           a1: (__int64)"TelemetryMigrationRemoveLegacyXboxSettingsLoadSuccess",
           a2: (__int64)&DFFlag::TelemetryMigrationRemoveLegacyXboxSettingsLoadSuccess,
           a3: 2u);
}

// Address: 0x10325c7c2 | Name: __ZN6DFFlagL64rbxImplDynInit_DualWriteEphemeralCounterToV2DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DualWriteEphemeralCounterToV2DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10325c7d9*/
           a1: (__int64)"DualWriteEphemeralCounterToV2",
           a2: (__int64)&DFFlag::DualWriteEphemeralCounterToV2,
           a3: 2u);
}

// Address: 0x10325c812 | Name: __ZN6DFFlagL67rbxImplDynInit_DeprecateLegacyTelemetryCountersDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DeprecateLegacyTelemetryCountersDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10325c829*/
           a1: (__int64)"DeprecateLegacyTelemetryCounters",
           a2: (__int64)&DFFlag::DeprecateLegacyTelemetryCounters,
           a3: 2u);
}

// Address: 0x10325c8c2 | Name: __ZN6DFFlagL76rbxImplDynInit_DeprecateLegacyTelemetryCountersReportingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DeprecateLegacyTelemetryCountersReportingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10325c8d9*/
           a1: (__int64)"DeprecateLegacyTelemetryCountersReporting",
           a2: (__int64)&DFFlag::DeprecateLegacyTelemetryCountersReporting,
           a3: 2u);
}

// Address: 0x10325d81c | Name: __ZN6DFFlagL61rbxImplDynInit_DualWriteEphemeralStatToV2DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DualWriteEphemeralStatToV2DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10325d833*/
           a1: (__int64)"DualWriteEphemeralStatToV2",
           a2: (__int64)&DFFlag::DualWriteEphemeralStatToV2,
           a3: 2u);
}

// Address: 0x10325d86c | Name: __ZN6DFFlagL64rbxImplDynInit_DeprecateLegacyTelemetryStatsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DeprecateLegacyTelemetryStatsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10325d883*/
           a1: (__int64)"DeprecateLegacyTelemetryStats",
           a2: (__int64)&DFFlag::DeprecateLegacyTelemetryStats,
           a3: 2u);
}

// Address: 0x10325d91c | Name: __ZN6DFFlagL73rbxImplDynInit_DeprecateLegacyTelemetryStatsReportingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DeprecateLegacyTelemetryStatsReportingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10325d933*/
           a1: (__int64)"DeprecateLegacyTelemetryStatsReporting",
           a2: (__int64)&DFFlag::DeprecateLegacyTelemetryStatsReporting,
           a3: 2u);
}

// Address: 0x10325e8f1 | Name: __ZN6DFFlagL68rbxImplDynInit_RobloxTelemetryAddOTAVersionAsTagDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RobloxTelemetryAddOTAVersionAsTagDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10325e908*/
           a1: (__int64)"RobloxTelemetryAddOTAVersionAsTag",
           a2: (__int64)&DFFlag::RobloxTelemetryAddOTAVersionAsTag,
           a3: 2u);
}

// Address: 0x1032669ed | Name: __ZN6DFFlagL69rbxImplDynInit_RobloxTelemetryRemovePlaceIdSuffixDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RobloxTelemetryRemovePlaceIdSuffixDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103266a04*/
           a1: (__int64)"RobloxTelemetryRemovePlaceIdSuffix",
           a2: (__int64)&DFFlag::RobloxTelemetryRemovePlaceIdSuffix,
           a3: 2u);
}

// Address: 0x103266a0a | Name: __ZN6DFFlagL76rbxImplDynInit_RobloxTelemetryAddAppBuildVariantToPointsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RobloxTelemetryAddAppBuildVariantToPointsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103266a21*/
           a1: (__int64)"RobloxTelemetryAddAppBuildVariantToPoints",
           a2: (__int64)&DFFlag::RobloxTelemetryAddAppBuildVariantToPoints,
           a3: 2u);
}

// Address: 0x103266a27 | Name: __ZN6DFFlagL56rbxImplDynInit_AddEngineMajorVersionDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AddEngineMajorVersionDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"AddEngineMajorVersion", a2: (__int64)&DFFlag::AddEngineMajorVersion, a3: 2u); /*0x103266a3e*/
}

// Address: 0x103467a77 | Name: __ZN6DFFlagL62rbxImplDynInit_ConvertFontMetricsToNominalDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_ConvertFontMetricsToNominalDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103467a8e*/
           a1: (__int64)"ConvertFontMetricsToNominal",
           a2: (__int64)&DFFlag::ConvertFontMetricsToNominal,
           a3: 2u);
}

// Address: 0x10348759a | Name: __ZN6DFFlagL64rbxImplDynInit_AssetProviderExecutorUseBoostDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AssetProviderExecutorUseBoostDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034875b1*/
           a1: (__int64)"AssetProviderExecutorUseBoost",
           a2: (__int64)&DFFlag::AssetProviderExecutorUseBoost,
           a3: 2u);
}

// Address: 0x1034951d2 | Name: __ZN6DFFlagL70rbxImplDynInit_AssetProviderCacheAcrStringInMemoryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_AssetProviderCacheAcrStringInMemoryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034951e9*/
           a1: (__int64)"AssetProviderCacheAcrStringInMemory",
           a2: (__int64)&DFFlag::AssetProviderCacheAcrStringInMemory,
           a3: 2u);
}

// Address: 0x10349521b | Name: __ZN6DFFlagL61rbxImplDynInit_ExpandInstanceSanitizationDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_ExpandInstanceSanitizationDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103495232*/
           a1: (__int64)"ExpandInstanceSanitization",
           a2: (__int64)&DFFlag::ExpandInstanceSanitization,
           a3: 2u);
}

// Address: 0x10349a7de | Name: __ZN6DFFlagL69rbxImplDynInit_SendDetailedARWorkflowFailureTelemDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_SendDetailedARWorkflowFailureTelemDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10349a7f5*/
           a1: (__int64)"SendDetailedARWorkflowFailureTelem",
           a2: (__int64)&DFFlag::SendDetailedARWorkflowFailureTelem,
           a3: 2u);
}

// Address: 0x1034a0552 | Name: __ZN6DFFlagL55rbxImplDynInit_MoveAPTelemToBgFiberDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_MoveAPTelemToBgFiberDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"MoveAPTelemToBgFiber", a2: (__int64)&DFFlag::MoveAPTelemToBgFiber, a3: 2u); /*0x1034a0569*/
}

// Address: 0x1034a383e | Name: __ZN6DFFlagL74rbxImplDynInit_DebugForceUseProductionForAssetFetchingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugForceUseProductionForAssetFetchingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034a3855*/
           a1: (__int64)"DebugForceUseProductionForAssetFetching",
           a2: (__int64)&DFFlag::DebugForceUseProductionForAssetFetching,
           a3: 2u);
}

// Address: 0x1034b359c | Name: __ZN6DFFlagL52rbxImplDynInit_TestHttp3FallbackDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_TestHttp3FallbackDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"TestHttp3Fallback", a2: (__int64)&DFFlag::TestHttp3Fallback, a3: 2u); /*0x1034b35b3*/
}

// Address: 0x1034c0c52 | Name: __ZN6DFFlagL62rbxImplDynInit_UseNewContentDeliveryDomainDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_UseNewContentDeliveryDomainDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034c0c69*/
           a1: (__int64)"UseNewContentDeliveryDomain",
           a2: (__int64)&DFFlag::UseNewContentDeliveryDomain,
           a3: 2u);
}

// Address: 0x1034d9bc8 | Name: __ZN6DFFlagL44rbxImplDynInit_CLI207295DynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CLI207295DynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"CLI207295", a2: (__int64)&DFFlag::CLI207295, a3: 2u); /*0x1034d9bdf*/
}

// Address: 0x1034e7a59 | Name: __ZN6DFFlagL67rbxImplDynInit_DebugBreakOnExcessivelyLoudAudioDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugBreakOnExcessivelyLoudAudioDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034e7a70*/
           a1: (__int64)"DebugBreakOnExcessivelyLoudAudio",
           a2: (__int64)&DFFlag::DebugBreakOnExcessivelyLoudAudio,
           a3: 2u);
}

// Address: 0x1034e7af9 | Name: __ZN6DFFlagL55rbxImplDynInit_DebugReportLoudAudioDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugReportLoudAudioDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"DebugReportLoudAudio", a2: (__int64)&DFFlag::DebugReportLoudAudio, a3: 2u); /*0x1034e7b10*/
}

// Address: 0x1034e7b66 | Name: __ZN6DFFlagL60rbxImplDynInit_DebugCrashIfFmodFailsInitDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugCrashIfFmodFailsInitDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034e7b7d*/
           a1: (__int64)"DebugCrashIfFmodFailsInit",
           a2: (__int64)&DFFlag::DebugCrashIfFmodFailsInit,
           a3: 2u);
}

// Address: 0x1034f17c4 | Name: __ZN6DFFlagL66rbxImplDynInit_DebugMuteVoiceOutputThroughFmodDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugMuteVoiceOutputThroughFmodDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034f17db*/
           a1: (__int64)"DebugMuteVoiceOutputThroughFmod",
           a2: (__int64)&DFFlag::DebugMuteVoiceOutputThroughFmod,
           a3: 2u);
}

// Address: 0x1034f62b3 | Name: __ZN6DFFlagL58rbxImplDynInit_DebugFmodUseVoiceDriverDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugFmodUseVoiceDriverDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034f62ca*/
           a1: (__int64)"DebugFmodUseVoiceDriver",
           a2: (__int64)&DFFlag::DebugFmodUseVoiceDriver,
           a3: 2u);
}

// Address: 0x1034f6328 | Name: __ZN6DFFlagL72rbxImplDynInit_ReportOutputDeviceWithRobloxTelemetryDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_ReportOutputDeviceWithRobloxTelemetryDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034f633f*/
           a1: (__int64)"ReportOutputDeviceWithRobloxTelemetry",
           a2: (__int64)&DFFlag::ReportOutputDeviceWithRobloxTelemetry,
           a3: 2u);
}

// Address: 0x1034f63d8 | Name: __ZN6DFFlagL64rbxImplDynInit_DebugFmodUseAndroidAudioTrackDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugFmodUseAndroidAudioTrackDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034f63ef*/
           a1: (__int64)"DebugFmodUseAndroidAudioTrack",
           a2: (__int64)&DFFlag::DebugFmodUseAndroidAudioTrack,
           a3: 2u);
}

// Address: 0x1034f63f5 | Name: __ZN6DFFlagL60rbxImplDynInit_DebugFmodUseAndroidOpenSlDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugFmodUseAndroidOpenSlDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034f640c*/
           a1: (__int64)"DebugFmodUseAndroidOpenSl",
           a2: (__int64)&DFFlag::DebugFmodUseAndroidOpenSl,
           a3: 2u);
}

// Address: 0x1034f642f | Name: __ZN6DFFlagL69rbxImplDynInit_DebugFmodEnableAsyncThreadCallbackDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugFmodEnableAsyncThreadCallbackDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1034f6446*/
           a1: (__int64)"DebugFmodEnableAsyncThreadCallback",
           a2: (__int64)&DFFlag::DebugFmodEnableAsyncThreadCallback,
           a3: 2u);
}

// Address: 0x103503874 | Name: __ZN6DFFlagL55rbxImplDynInit_DebugAudioWarnStallsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugAudioWarnStallsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"DebugAudioWarnStalls", a2: (__int64)&DFFlag::DebugAudioWarnStalls, a3: 2u); /*0x10350388b*/
}

// Address: 0x10364cdbf | Name: __ZN6DFFlagL68rbxImplDynInit_HttpWrapperPropagateEngineContextDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_HttpWrapperPropagateEngineContextDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10364cdd6*/
           a1: (__int64)"HttpWrapperPropagateEngineContext",
           a2: (__int64)&DFFlag::HttpWrapperPropagateEngineContext,
           a3: 2u);
}

// Address: 0x1036505cd | Name: __ZN6DFFlagL62rbxImplDynInit_DebugTestPeerMonotonicClockDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugTestPeerMonotonicClockDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036505e4*/
           a1: (__int64)"DebugTestPeerMonotonicClock",
           a2: (__int64)&DFFlag::DebugTestPeerMonotonicClock,
           a3: 2u);
}

// Address: 0x103650a12 | Name: __ZN6DFFlagL69rbxImplDynInit_OpenTelemetryUsePeerMonotonicClockDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_OpenTelemetryUsePeerMonotonicClockDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103650a29*/
           a1: (__int64)"OpenTelemetryUsePeerMonotonicClock",
           a2: (__int64)&DFFlag::OpenTelemetryUsePeerMonotonicClock,
           a3: 2u);
}

// Address: 0x103650c0d | Name: __ZN6DFFlagL69rbxImplDynInit_D3D11TextureNoThrowForVideoCaptureDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_D3D11TextureNoThrowForVideoCaptureDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103650c24*/
           a1: (__int64)"D3D11TextureNoThrowForVideoCapture",
           a2: (__int64)&DFFlag::D3D11TextureNoThrowForVideoCapture,
           a3: 2u);
}

// Address: 0x103654804 | Name: __ZN6DFFlagL71rbxImplDynInit_GraphicsValidateOrbisResourceBindingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_GraphicsValidateOrbisResourceBindingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10365481b*/
           a1: (__int64)"GraphicsValidateOrbisResourceBinding",
           a2: (__int64)&DFFlag::GraphicsValidateOrbisResourceBinding,
           a3: 2u);
}

// Address: 0x1036589fc | Name: __ZN6DFFlagL63rbxImplDynInit_VideoCaptureUseStagingBufferDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_VideoCaptureUseStagingBufferDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103658a13*/
           a1: (__int64)"VideoCaptureUseStagingBuffer",
           a2: (__int64)&DFFlag::VideoCaptureUseStagingBuffer,
           a3: 2u);
}

// Address: 0x103659878 | Name: __ZN6DFFlagL71rbxImplDynInit_PerformanceControlClientMemoryBudgetDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_PerformanceControlClientMemoryBudgetDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10365988f*/
           a1: (__int64)"PerformanceControlClientMemoryBudget",
           a2: (__int64)&DFFlag::PerformanceControlClientMemoryBudget,
           a3: 2u);
}

// Address: 0x1036686cb | Name: __ZN6DFFlagL83rbxImplDynInit_DebugPerformanceControlEnableMemoryOverrideImGuiDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugPerformanceControlEnableMemoryOverrideImGuiDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036686e2*/
           a1: (__int64)"DebugPerformanceControlEnableMemoryOverrideImGui",
           a2: (__int64)&DFFlag::DebugPerformanceControlEnableMemoryOverrideImGui,
           a3: 2u);
}

// Address: 0x1036686e8 | Name: __ZN6DFFlagL76rbxImplDynInit_DebugPerformanceControlFreeMemoryOverrideDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugPerformanceControlFreeMemoryOverrideDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036686ff*/
           a1: (__int64)"DebugPerformanceControlFreeMemoryOverride",
           a2: (__int64)&DFFlag::DebugPerformanceControlFreeMemoryOverride,
           a3: 2u);
}

// Address: 0x103668a48 | Name: __ZN6DFFlagL82rbxImplDynInit_CrashMetricStorageEnableBufferConstantReportingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_CrashMetricStorageEnableBufferConstantReportingDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103668a5f*/
           a1: (__int64)"CrashMetricStorageEnableBufferConstantReporting",
           a2: (__int64)&DFFlag::CrashMetricStorageEnableBufferConstantReporting,
           a3: 2u);
}

// Address: 0x10368bdb2 | Name: __ZN6DFFlagL70rbxImplDynInit_PerformanceControlUpdateSystemStateDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_PerformanceControlUpdateSystemStateDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10368bdc9*/
           a1: (__int64)"PerformanceControlUpdateSystemState",
           a2: (__int64)&DFFlag::PerformanceControlUpdateSystemState,
           a3: 2u);
}

// Address: 0x10369b336 | Name: __ZN6DFFlagL87rbxImplDynInit_PerformanceControlUseExcessInBudgetCalculationsDebugDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_PerformanceControlUseExcessInBudgetCalculationsDebugDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10369b34d*/
           a1: (__int64)"PerformanceControlUseExcessInBudgetCalculationsDebug",
           a2: (__int64)&DFFlag::PerformanceControlUseExcessInBudgetCalculationsDebug,
           a3: 2u);
}

// Address: 0x10369f0a1 | Name: __ZN6DFFlagL72rbxImplDynInit_PerformanceControlImGuiMemoryOverrideDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_PerformanceControlImGuiMemoryOverrideDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x10369f0b8*/
           a1: (__int64)"PerformanceControlImGuiMemoryOverride",
           a2: (__int64)&DFFlag::PerformanceControlImGuiMemoryOverride,
           a3: 2u);
}

// Address: 0x1036ae6de | Name: __ZN6DFFlagL86rbxImplDynInit_DebugPerformanceControlEnableFrameTimeOverrideImGuiDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugPerformanceControlEnableFrameTimeOverrideImGuiDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036ae6f5*/
           a1: (__int64)"DebugPerformanceControlEnableFrameTimeOverrideImGui",
           a2: (__int64)&DFFlag::DebugPerformanceControlEnableFrameTimeOverrideImGui,
           a3: 2u);
}

// Address: 0x1036b8f2e | Name: __ZN6DFFlagL84rbxImplDynInit_PerformanceControlV3ReportSecondaryTunableMetricsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_PerformanceControlV3ReportSecondaryTunableMetricsDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036b8f45*/
           a1: (__int64)"PerformanceControlV3ReportSecondaryTunableMetrics",
           a2: (__int64)&DFFlag::PerformanceControlV3ReportSecondaryTunableMetrics,
           a3: 2u);
}

// Address: 0x1036c675e | Name: __ZN6DFFlagL58rbxImplDynInit_RbxTransportUseRtcioRnaDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportUseRtcioRnaDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036c6775*/
           a1: (__int64)"RbxTransportUseRtcioRna",
           a2: (__int64)&DFFlag::RbxTransportUseRtcioRna,
           a3: 2u);
}

// Address: 0x1036c69b2 | Name: __ZN6DFFlagL56rbxImplDynInit_RtcIoTransportConnApiDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RtcIoTransportConnApiDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"RtcIoTransportConnApi", a2: (__int64)&DFFlag::RtcIoTransportConnApi, a3: 2u); /*0x1036c69c9*/
}

// Address: 0x1036c7d1e | Name: __ZN6DFFlagL70rbxImplDynInit_RbxTransportRtcioCollapseRecvQueuesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportRtcioCollapseRecvQueuesDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036c7d35*/
           a1: (__int64)"RbxTransportRtcioCollapseRecvQueues",
           a2: (__int64)&DFFlag::RbxTransportRtcioCollapseRecvQueues,
           a3: 2u);
}

// Address: 0x1036c7d3b | Name: __ZN6DFFlagL70rbxImplDynInit_RbxTransportRtcioConnStartReentrantDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportRtcioConnStartReentrantDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036c7d52*/
           a1: (__int64)"RbxTransportRtcioConnStartReentrant",
           a2: (__int64)&DFFlag::RbxTransportRtcioConnStartReentrant,
           a3: 2u);
}

// Address: 0x1036c7d58 | Name: __ZN6DFFlagL63rbxImplDynInit_RbxTransportTxOverflowBufferDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportTxOverflowBufferDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036c7d6f*/
           a1: (__int64)"RbxTransportTxOverflowBuffer",
           a2: (__int64)&DFFlag::RbxTransportTxOverflowBuffer,
           a3: 2u);
}

// Address: 0x1036d08d1 | Name: __ZN6DFFlagL63rbxImplDynInit_RtcIoSupportNetworkEmulationDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RtcIoSupportNetworkEmulationDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036d08e8*/
           a1: (__int64)"RtcIoSupportNetworkEmulation",
           a2: (__int64)&DFFlag::RtcIoSupportNetworkEmulation,
           a3: 2u);
}

// Address: 0x1036d08ee | Name: __ZN6DFFlagL74rbxImplDynInit_RbxTransportRtcioRejectDuplicateChannelDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportRtcioRejectDuplicateChannelDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036d0905*/
           a1: (__int64)"RbxTransportRtcioRejectDuplicateChannel",
           a2: (__int64)&DFFlag::RbxTransportRtcioRejectDuplicateChannel,
           a3: 2u);
}

// Address: 0x1036d090b | Name: __ZN6DFFlagL65rbxImplDynInit_RbxTransportServerStreamLimitsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportServerStreamLimitsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036d0922*/
           a1: (__int64)"RbxTransportServerStreamLimits",
           a2: (__int64)&DFFlag::RbxTransportServerStreamLimits,
           a3: 2u);
}

// Address: 0x1036d093e | Name: __ZN6DFFlagL65rbxImplDynInit_RbxTransportCloseInvalidStreamDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportCloseInvalidStreamDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036d0955*/
           a1: (__int64)"RbxTransportCloseInvalidStream",
           a2: (__int64)&DFFlag::RbxTransportCloseInvalidStream,
           a3: 2u);
}

// Address: 0x1036d095b | Name: __ZN6DFFlagL84rbxImplDynInit_RbxTransportRtcioRejectChannelOpenOnFailedConnectDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportRtcioRejectChannelOpenOnFailedConnectDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036d0972*/
           a1: (__int64)"RbxTransportRtcioRejectChannelOpenOnFailedConnect",
           a2: (__int64)&DFFlag::RbxTransportRtcioRejectChannelOpenOnFailedConnect,
           a3: 2u);
}

// Address: 0x1036d0978 | Name: __ZN6DFFlagL67rbxImplDynInit_LastTTTokenUpdateTimeDiagnosticsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_LastTTTokenUpdateTimeDiagnosticsDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036d098f*/
           a1: (__int64)"LastTTTokenUpdateTimeDiagnostics",
           a2: (__int64)&DFFlag::LastTTTokenUpdateTimeDiagnostics,
           a3: 2u);
}

// Address: 0x1036e6b1f | Name: __ZN6DFFlagL63rbxImplDynInit_RbxTransportEnforcePortRangeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportEnforcePortRangeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036e6b36*/
           a1: (__int64)"RbxTransportEnforcePortRange",
           a2: (__int64)&DFFlag::RbxTransportEnforcePortRange,
           a3: 2u);
}

// Address: 0x1036e6b68 | Name: __ZN6DFFlagL64rbxImplDynInit_RbxTransportListenerWtEnabledDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportListenerWtEnabledDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036e6b7f*/
           a1: (__int64)"RbxTransportListenerWtEnabled",
           a2: (__int64)&DFFlag::RbxTransportListenerWtEnabled,
           a3: 2u);
}

// Address: 0x1036e6b85 | Name: __ZN6DFFlagL58rbxImplDynInit_RbxTransportIpRateLimitDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportIpRateLimitDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036e6b9c*/
           a1: (__int64)"RbxTransportIpRateLimit",
           a2: (__int64)&DFFlag::RbxTransportIpRateLimit,
           a3: 2u);
}

// Address: 0x1036e6bce | Name: __ZN6DFFlagL72rbxImplDynInit_RbxTransportRtcioNativeControlChannelDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportRtcioNativeControlChannelDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036e6be5*/
           a1: (__int64)"RbxTransportRtcioNativeControlChannel",
           a2: (__int64)&DFFlag::RbxTransportRtcioNativeControlChannel,
           a3: 2u);
}

// Address: 0x1036e6c17 | Name: __ZN6DFFlagL80rbxImplDynInit_RbxTransportRtcIoTrackPendingConnectionClosesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportRtcIoTrackPendingConnectionClosesDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036e6c2e*/
           a1: (__int64)"RbxTransportRtcIoTrackPendingConnectionCloses",
           a2: (__int64)&DFFlag::RbxTransportRtcIoTrackPendingConnectionCloses,
           a3: 2u);
}

// Address: 0x1036e6c34 | Name: __ZN6DFFlagL78rbxImplDynInit_RbxTransportFailClosedCapabilityNegotiationDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportFailClosedCapabilityNegotiationDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036e6c4b*/
           a1: (__int64)"RbxTransportFailClosedCapabilityNegotiation",
           a2: (__int64)&DFFlag::RbxTransportFailClosedCapabilityNegotiation,
           a3: 2u);
}

// Address: 0x1036f00e9 | Name: __ZN6DFFlagL62rbxImplDynInit_RbxTransportPureQuicSupportDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportPureQuicSupportDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036f0100*/
           a1: (__int64)"RbxTransportPureQuicSupport",
           a2: (__int64)&DFFlag::RbxTransportPureQuicSupport,
           a3: 2u);
}

// Address: 0x1036f1a5b | Name: __ZN6DFFlagL68rbxImplDynInit_RbxTransportFixClientConnIndexingDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportFixClientConnIndexingDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036f1a72*/
           a1: (__int64)"RbxTransportFixClientConnIndexing",
           a2: (__int64)&DFFlag::RbxTransportFixClientConnIndexing,
           a3: 2u);
}

// Address: 0x1036f1a78 | Name: __ZN6DFFlagL63rbxImplDynInit_RbxTransportRtcIoAddMemScopeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportRtcIoAddMemScopeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036f1a8f*/
           a1: (__int64)"RbxTransportRtcIoAddMemScope",
           a2: (__int64)&DFFlag::RbxTransportRtcIoAddMemScope,
           a3: 2u);
}

// Address: 0x1036f1a95 | Name: __ZN6DFFlagL79rbxImplDynInit_RbxTransportRtcIoUseMultipleEventLoopThreadsDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportRtcIoUseMultipleEventLoopThreadsDynInit_FlagRegister(
        DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036f1aac*/
           a1: (__int64)"RbxTransportRtcIoUseMultipleEventLoopThreads",
           a2: (__int64)&DFFlag::RbxTransportRtcIoUseMultipleEventLoopThreads,
           a3: 2u);
}

// Address: 0x1036f1ac8 | Name: __ZN6DFFlagL61rbxImplDynInit_RtcIoSharedSocketResourcesDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RtcIoSharedSocketResourcesDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036f1adf*/
           a1: (__int64)"RtcIoSharedSocketResources",
           a2: (__int64)&DFFlag::RtcIoSharedSocketResources,
           a3: 2u);
}

// Address: 0x1036f1ae5 | Name: __ZN6DFFlagL53rbxImplDynInit_RbxNetDoctorClientDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxNetDoctorClientDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag(a1: (__int64)"RbxNetDoctorClient", a2: (__int64)&DFFlag::RbxNetDoctorClient, a3: 2u); /*0x1036f1afc*/
}

// Address: 0x1036fbabb | Name: __ZN6DFFlagL63rbxImplDynInit_DebugRbxTransportClientUseWtDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_DebugRbxTransportClientUseWtDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036fbad2*/
           a1: (__int64)"DebugRbxTransportClientUseWt",
           a2: (__int64)&DFFlag::DebugRbxTransportClientUseWt,
           a3: 2u);
}

// Address: 0x1036ff99e | Name: __ZN6DFFlagL75rbxImplDynInit_RbxTransportRtcioValidateApplicationEnumDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportRtcioValidateApplicationEnumDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1036ff9b5*/
           a1: (__int64)"RbxTransportRtcioValidateApplicationEnum",
           a2: (__int64)&DFFlag::RbxTransportRtcioValidateApplicationEnum,
           a3: 2u);
}

// Address: 0x103732da3 | Name: __ZN6DFFlagL74rbxImplDynInit_RbxTransportDisableIoEventLoopPerfScopeDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportDisableIoEventLoopPerfScopeDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x103732dba*/
           a1: (__int64)"RbxTransportDisableIoEventLoopPerfScope",
           a2: (__int64)&DFFlag::RbxTransportDisableIoEventLoopPerfScope,
           a3: 2u);
}

// Address: 0x10374158c | Name: __ZN6DFFlagL70rbxImplDynInit_RbxTransportGracefulDontFragFailureDynInit_FlagRegisterEv
__int64 __fastcall DFFlag::rbxImplDynInit_RbxTransportGracefulDontFragFailureDynInit_FlagRegister(DFFlag *this)
{
  return FLog::RegisterFlag( /*0x1037415a3*/
           a1: (__int64)"RbxTransportGracefulDontFragFailure",
           a2: (__int64)&DFFlag::RbxTransportGracefulDontFragFailure,
           a3: 2u);
}

// END DFFlag part 2/8, 400 functions
