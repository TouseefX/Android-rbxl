// Workspace -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 307 functions

// Field names below come from the 2022 PDB, which is the only
// build that has them. Each is marked: bare `this->x` was
// corroborated by a store of matching width in that same
// function; UNVERIFIED means the 2022 layout says so and
// nothing target-era has confirmed it.


// Address: 0x100b1dd34 | Name: __ZN3RBX9Workspace9doNothingEb
void __fastcall RBX::Workspace::doNothing(RBX::Workspace *this)
{
  ; /*0x100b1dd34*/
}

// Address: 0x100b22380 | Name: __ZNK3RBX9Workspace13getAsInternalENS_10Reflection11InterfaceIdE
__int64 __fastcall RBX::Workspace::getAsInternal(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  result = 0; /*0x100b2238b*/
  if ( a2 == 1 ) /*0x100b22391*/
    return a1 + 1304; /*0x100b22391*/
  return result; /*0x100b22395*/
}

// Address: 0x100b22398 | Name: __ZN3RBX9Workspace35writeAllPropertiesForChangeTrackingEPNS_23DataModelChangeTracking13ChangeTrackerENS1_12DeltaTypeTagE
__int64 __fastcall RBX::Workspace::writeAllPropertiesForChangeTracking(__int64 a1, __int64 a2, int a3)
{
  __int64 result; // rax

  result = RBX::WorldRoot::writeAllPropertiesForChangeTracking(a1); /*0x100b223ab*/
  if ( a3 == 4 ) /*0x100b223b4*/
    return RBX::WorkspaceProp::writeAllPropertiesForChangeTrackingImpl<(RBX::DataModelChangeTracking::DeltaTypeTag)4>( /*0x100b223ef*/
             a1: a1 + 1056,
             a2);
  if ( a3 == 3 ) /*0x100b223ba*/
    return RBX::WorkspaceProp::writeAllPropertiesForChangeTrackingImpl<(RBX::DataModelChangeTracking::DeltaTypeTag)3>( /*0x100b223d3*/
             a1: a1 + 1056,
             a2);
  return result; /*0x100b223cd*/
}

// Address: 0x100b23cba | Name: __ZNK3RBX9Workspace22getOverflowModifiedBitEj
unsigned __int8 __fastcall RBX::Workspace::getOverflowModifiedBit(RBX::Workspace *this, unsigned __int64 a2)
{
  __int64 v2; // rax

  if ( (unsigned int)a2 > 0x3F ) /*0x100b23cc1*/
    return 0; /*0x100b23cd3*/
  v2 = *((_QWORD *)this + 177) /* +1416 likely dataState -- UNVERIFIED */; /*0x100b23cc3*/
  return _bittest64(&v2, a2); /*0x100b23cd5*/
}

// Address: 0x100b23cd8 | Name: __ZN3RBX9Workspace22setOverflowModifiedBitEjb
void __fastcall __spoils<> RBX::Workspace::setOverflowModifiedBit(RBX::Workspace *this, unsigned int a2, char a3)
{
  __int64 v3; // rax
  __int64 v4; // rax

  if ( a2 <= 0x3F ) /*0x100b23cdf*/
  {
    v3 = 1LL << a2; /*0x100b23ce8*/
    if ( a3 != 0 ) /*0x100b23ced*/
      v4 = this->dataState /* +1416 */ | v3; /*0x100b23cef*/
    else
      v4 = this->dataState /* +1416 */ & ~v3; /*0x100b23cfb*/
    this->dataState /* +1416 */ = v4; /*0x100b23d02*/
  }
}

// Address: 0x100b23d0c | Name: __ZN3RBX9Workspace21clearOverflowModifiedEv
void __fastcall RBX::Workspace::clearOverflowModified(RBX::Workspace *this)
{
  this->dataState /* +1416 */ = 0; /*0x100b23d10*/
}

// Address: 0x100b23d1e | Name: __ZN3RBX9Workspace14render3dSelectEPNS_5AdornENS_11SelectStateE
void RBX::Workspace::render3dSelect()
{
  ; /*0x100b23d1e*/
}

// Address: 0x100b23d24 | Name: __ZNK3RBX9Workspace16teardownPriorityEv
__int64 __fastcall RBX::Workspace::teardownPriority(RBX::Workspace *this)
{
  return 100; /*0x100b23d2d*/
}

// Address: 0x100b23d30 | Name: __ZN3RBX9Workspace15onShutdownBeginENSt3__18functionIFvvEEE
__int64 RBX::Workspace::onShutdownBegin()
{
  return 0; /*0x100b23d36*/
}

// Address: 0x100b23d38 | Name: __ZN3RBX9Workspace37deprecatedSetFilteringEnabledCallbackEb
void __fastcall RBX::Workspace::deprecatedSetFilteringEnabledCallback(RBX::Workspace *this)
{
  ; /*0x100b23d38*/
}

// Address: 0x100b23d3e | Name: __ZN3RBX9Workspace32deprecatedSetInsertPointCallbackERKNS_7Vector3E
__int64 __fastcall RBX::Workspace::deprecatedSetInsertPointCallback(RBX::Workspace *this, const RBX::Vector3 *a2)
{
  return RBX::WorldRoot::setInsertPoint(this, a2); /*0x100b23d42*/
}

// Address: 0x100b23d4a | Name: __ZThn320_N3RBX9Workspace14render3dSelectEPNS_5AdornENS_11SelectStateE
void `non-virtual thunk to'RBX::Workspace::render3dSelect()
{
  ; /*0x100b23d4a*/
}

// Address: 0x100b23d5e | Name: __ZThn1056_N3RBX9Workspace37deprecatedSetFilteringEnabledCallbackEb
void __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetFilteringEnabledCallback(RBX::Workspace *this)
{
  ; /*0x100b23d5e*/
}

// Address: 0x100b23d64 | Name: __ZThn1056_N3RBX9Workspace32deprecatedSetInsertPointCallbackERKNS_7Vector3E
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetInsertPointCallback(
        RBX::Workspace *this,
        const RBX::Vector3 *a2)
{
  return RBX::WorldRoot::setInsertPoint(this: (RBX::Workspace *)((char *)this - 1056), a2); /*0x100b23d6f*/
}

// Address: 0x100b23d78 | Name: __ZThn1408_NK3RBX9Workspace16teardownPriorityEv
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::teardownPriority(RBX::Workspace *this)
{
  return 100; /*0x100b23d81*/
}

// Address: 0x100b23d86 | Name: __ZThn1408_N3RBX9Workspace15onShutdownBeginENSt3__18functionIFvvEEE
__int64 `non-virtual thunk to'RBX::Workspace::onShutdownBegin()
{
  return 0; /*0x100b23d8c*/
}

// Address: 0x104f7e3d6 | Name: __ZN3RBX9Workspace31resetDebugVisualizationsToFalseEv
__int64 __fastcall RBX::Workspace::resetDebugVisualizationsToFalse(RBX::Workspace *this)
{
  RBX::Workspace::showContactIslands = 0; /*0x104f7e3dc*/
  RBX::Workspace::showCollisionCosts = 0; /*0x104f7e3e2*/
  RBX::Workspace::showWorldCoordinateFrame = 0; /*0x104f7e3e8*/
  RBX::Workspace::showEPhysicsOwners = 0; /*0x104f7e3ee*/
  RBX::Workspace::showEPhysicsRegions = 0; /*0x104f7e3f4*/
  return 0; /*0x104f7e3fa*/
}

// Address: 0x104f7e3fc | Name: __ZN3RBX9Workspace25findWorkspaceNotWorldRootEPNS_8InstanceE
__int64 __fastcall RBX::Workspace::findWorkspaceNotWorldRoot(RBX::Workspace *this, RBX::Instance *a2)
{
  return RBX::Workspace::findConstWorkspaceNotWorldRoot(this, a2); /*0x104f7e400*/
}

// Address: 0x104f7e406 | Name: __ZN3RBX9Workspace30findConstWorkspaceNotWorldRootEPKNS_8InstanceE
__int64 __fastcall RBX::Workspace::findConstWorkspaceNotWorldRoot(RBX::Workspace *this, const RBX::Instance *a2)
{
  __int64 ConstWorldRootIfInWorldRoot; // rax
  __int64 v4; // rdi
  __int64 v5; // rsi
  __int64 v6; // rbx
  __int64 v7; // r14
  __int64 v8; // rax
  unsigned int v9; // ecx
  unsigned int v10; // edx
  __int64 result; // rax

  ConstWorldRootIfInWorldRoot = RBX::WorldRoot::getConstWorldRootIfInWorldRoot(this, a2); /*0x104f7e410*/
  if ( ConstWorldRootIfInWorldRoot == 0 ) /*0x104f7e418*/
    return RBX::ServiceProvider::find<RBX::Workspace>(a1: this); /*0x104f7e452*/
  v6 = ConstWorldRootIfInWorldRoot; /*0x104f7e41a*/
  v7 = *(_QWORD *)(ConstWorldRootIfInWorldRoot + 24); /*0x104f7e41d*/
  v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::Workspace>(a1: v4, a2: v5); /*0x104f7e421*/
  v9 = *(unsigned __int16 *)(v7 + 440) - *(unsigned __int16 *)(v8 + 440); /*0x104f7e435*/
  v10 = *(unsigned __int16 *)(v8 + 442); /*0x104f7e437*/
  result = 0; /*0x104f7e43e*/
  if ( v9 <= v10 ) /*0x104f7e442*/
    return v6; /*0x104f7e442*/
  return result; /*0x104f7e446*/
}

// Address: 0x104f7e458 | Name: __ZN3RBX9Workspace42getConstWorkspaceIfInWorkspaceNotWorldRootEPKNS_8InstanceE
__int64 __fastcall RBX::Workspace::getConstWorkspaceIfInWorkspaceNotWorldRoot(
        RBX::Workspace *this,
        const RBX::Instance *a2)
{
  __int64 ConstWorldRootIfInWorldRoot; // rax
  __int64 v3; // rdi
  __int64 v4; // rsi
  __int64 v5; // rbx
  __int64 v6; // r14
  __int64 v7; // rax
  unsigned int v8; // ecx
  unsigned int v9; // edx
  __int64 result; // rax

  ConstWorldRootIfInWorldRoot = RBX::WorldRoot::getConstWorldRootIfInWorldRoot(this, a2); /*0x104f7e45f*/
  if ( ConstWorldRootIfInWorldRoot == 0 ) /*0x104f7e467*/
    return 0; /*0x104f7e497*/
  v5 = ConstWorldRootIfInWorldRoot; /*0x104f7e469*/
  v6 = *(_QWORD *)(ConstWorldRootIfInWorldRoot + 24); /*0x104f7e46c*/
  v7 = RBX::Reflection::Class_getDescriptorPtr<RBX::Workspace>(a1: v3, a2: v4); /*0x104f7e470*/
  v8 = *(unsigned __int16 *)(v6 + 440) - *(unsigned __int16 *)(v7 + 440); /*0x104f7e484*/
  v9 = *(unsigned __int16 *)(v7 + 442); /*0x104f7e486*/
  result = 0; /*0x104f7e48d*/
  if ( v8 <= v9 ) /*0x104f7e491*/
    return v5; /*0x104f7e491*/
  return result; /*0x104f7e499*/
}

// Address: 0x104f7e49e | Name: __ZN3RBX9Workspace33getWorldIfInWorkspaceNotWorldRootEPNS_8InstanceE
__int64 __fastcall RBX::Workspace::getWorldIfInWorkspaceNotWorldRoot(RBX::Workspace *this, RBX::Instance *a2)
{
  __int64 ConstWorkspaceIfInWorkspaceNotWorldRoot; // rax

  ConstWorkspaceIfInWorkspaceNotWorldRoot = RBX::Workspace::getConstWorkspaceIfInWorkspaceNotWorldRoot(this, a2); /*0x104f7e4a2*/
  if ( ConstWorkspaceIfInWorkspaceNotWorldRoot != 0 ) /*0x104f7e4aa*/
    return *(_QWORD *)(ConstWorkspaceIfInWorkspaceNotWorldRoot + 944); /*0x104f7e4ac*/
  else
    return 0; /*0x104f7e4b5*/
}

// Address: 0x104f7e4ba | Name: __ZN3RBX9Workspace42getContactManagerIfInWorkspaceNotWorldRootEPNS_8InstanceE
__int64 __fastcall RBX::Workspace::getContactManagerIfInWorkspaceNotWorldRoot(RBX::Workspace *this, RBX::Instance *a2)
{
  __int64 ConstWorkspaceIfInWorkspaceNotWorldRoot; // rax
  __int64 v3; // rax

  ConstWorkspaceIfInWorkspaceNotWorldRoot = RBX::Workspace::getConstWorkspaceIfInWorkspaceNotWorldRoot(this, a2); /*0x104f7e4be*/
  if ( ConstWorkspaceIfInWorkspaceNotWorldRoot != 0 /*0x104f7e4d2*/
    && (v3 = *(_QWORD *)(ConstWorkspaceIfInWorkspaceNotWorldRoot + 944)) != 0 )
  {
    return *(_QWORD *)(v3 + 2056); /*0x104f7e4d4*/
  }
  else
  {
    return 0; /*0x104f7e4dd*/
  }
}

// Address: 0x104f7e4e2 | Name: __ZN3RBX9Workspace30contextInWorkspaceNotWorldRootEPKNS_8InstanceE
bool __fastcall RBX::Workspace::contextInWorkspaceNotWorldRoot(RBX::Workspace *this, const RBX::Instance *a2)
{
  RBX::Workspace *ConstWorkspaceIfInWorkspaceNotWorldRoot; // rax

  ConstWorkspaceIfInWorkspaceNotWorldRoot = (RBX::Workspace *)RBX::Workspace::getConstWorkspaceIfInWorkspaceNotWorldRoot( /*0x104f7e4eb*/
                                                                this,
                                                                a2);
  return ConstWorkspaceIfInWorkspaceNotWorldRoot != nullptr && ConstWorkspaceIfInWorkspaceNotWorldRoot != this; /*0x104f7e502*/
}

// Address: 0x104f7e506 | Name: __ZN3RBX9Workspace30getConstWorkspaceIfInWorkspaceEPKNS_8InstanceE
RBX::Workspace *__fastcall RBX::Workspace::getConstWorkspaceIfInWorkspace(
        RBX::Workspace *this,
        const RBX::Instance *a2)
{
  RBX::Workspace *v2; // rbx
  __int64 v3; // r14
  __int64 v4; // rax

  if ( this == nullptr ) /*0x104f7e510*/
    return nullptr; /*0x104f7e543*/
  v2 = this; /*0x104f7e512*/
  while ( 1 ) /*0x104f7e515*/
  {
    v3 = *((_QWORD *)v2 + 3); /*0x104f7e515*/
    v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::Workspace>(a1: this, a2); /*0x104f7e519*/
    if ( *(unsigned __int16 *)(v3 + 440) - (unsigned int)*(unsigned __int16 *)(v4 + 440) <= *(unsigned __int16 *)(v4 + 442) ) /*0x104f7e538*/
      break; /*0x104f7e538*/
    v2 = *((RBX::Workspace **)v2 + 13); /*0x104f7e53a*/
    if ( v2 == nullptr ) /*0x104f7e541*/
      return nullptr; /*0x104f7e541*/
  }
  return v2; /*0x104f7e548*/
}

// Address: 0x104f7e54e | Name: __ZN3RBX9Workspace21getWorldIfInWorkspaceEPNS_8InstanceE
__int64 __fastcall RBX::Workspace::getWorldIfInWorkspace(RBX::Workspace *this, RBX::Instance *a2)
{
  RBX::Workspace *ConstWorkspaceIfInWorkspace; // rax

  ConstWorkspaceIfInWorkspace = RBX::Workspace::getConstWorkspaceIfInWorkspace(this, a2); /*0x104f7e552*/
  if ( ConstWorkspaceIfInWorkspace != nullptr ) /*0x104f7e55a*/
    return *((_QWORD *)ConstWorkspaceIfInWorkspace + 118); /*0x104f7e55c*/
  else
    return 0; /*0x104f7e565*/
}

// Address: 0x104f7e56a | Name: __ZN3RBX9Workspace30getContactManagerIfInWorkspaceEPNS_8InstanceE
__int64 __fastcall RBX::Workspace::getContactManagerIfInWorkspace(RBX::Workspace *this, RBX::Instance *a2)
{
  RBX::Workspace *ConstWorkspaceIfInWorkspace; // rax
  __int64 v3; // rax

  ConstWorkspaceIfInWorkspace = RBX::Workspace::getConstWorkspaceIfInWorkspace(this, a2); /*0x104f7e56e*/
  if ( ConstWorkspaceIfInWorkspace != nullptr && (v3 = *((_QWORD *)ConstWorkspaceIfInWorkspace + 118)) != 0 ) /*0x104f7e582*/
    return *(_QWORD *)(v3 + 2056); /*0x104f7e584*/
  else
    return 0; /*0x104f7e58d*/
}

// Address: 0x104f7e592 | Name: __ZN3RBX9Workspace18contextInWorkspaceEPKNS_8InstanceE
bool __fastcall RBX::Workspace::contextInWorkspace(RBX::Workspace *this, const RBX::Instance *a2)
{
  RBX::Workspace *ConstWorkspaceIfInWorkspace; // rax

  ConstWorkspaceIfInWorkspace = RBX::Workspace::getConstWorkspaceIfInWorkspace(this, a2); /*0x104f7e59b*/
  return ConstWorkspaceIfInWorkspace != nullptr && ConstWorkspaceIfInWorkspace != this; /*0x104f7e5b2*/
}

// Address: 0x104f7e5b6 | Name: __ZN3RBX9WorkspaceC2ERNS_28ForceConstructionInCreatableEPNS_10IDataStateEb
void __fastcall RBX::Workspace::Workspace(RBX::Workspace *a1, _QWORD *a2, int a3, __int64 a4, char a5)
{
  RBX::Time *v8; // rdi
  __int64 v9; // xmm0_8
  __int64 v10; // rcx
  RSL::Arena *v11; // rdi
  std::__shared_weak_count *v12; // r12
  std::__shared_weak_count *v13; // r12
  __int64 DefaultArena; // rax
  __int64 v15; // r12
  RSL::Arena *v16; // rdi
  __int64 v17; // rax
  RSL::Arena *v18; // rdi
  __int64 v19; // rax
  RBX::VerbContainer *v20; // r15
  RBX::World *v21; // rsi
  RSL::Arena *v22; // rdi
  __int64 v23; // rax
  __int64 v24; // rdi
  std::__shared_weak_count *v25; // r13
  __int64 v26; // rax
  RBX::Profiler::ProfileTelemetry *v27; // rdi
  __int64 ProfileSignal; // rax
  void *v29; // rdi
  std::__shared_weak_count *v30; // r13
  std::__shared_weak_count *v31; // r13
  __int64 v32; // rdi
  __int64 v33; // rax
  unsigned int v34; // esi
  std::__shared_weak_count *v35; // r13
  RBX::Constraints::GizmoManager *v36; // r13
  RBX::Physics::ConvexDecompVisualizer *v37; // r13
  RBX::Physics::ConvexDecompVisualizer *v38; // rsi
  std::__shared_weak_count *v39; // rsi
  RBX::World *v40; // rdi
  char v41; // al
  int v42; // ecx
  char v43; // si
  __int64 v44; // r15
  __int64 v45; // rsi
  void *v46; // rdi
  __int64 v47; // rsi
  void *v48; // rdi
  __int64 v49; // rsi
  void *v50; // rdi
  char v51; // al
  __int64 v52; // rsi
  std::__shared_weak_count *v53; // rdi
  __int64 v54; // rsi
  __int64 v55; // rsi
  std::__shared_weak_count *v56; // rdi
  __int64 v57; // rsi
  std::__shared_weak_count *v58; // rdi
  __int64 v59; // rax
  __int64 v60; // rax
  void *v61; // rdi
  __int128 v62; // [rsp+10h] [rbp-120h] BYREF
  _QWORD *v63; // [rsp+20h] [rbp-110h]
  char *v64; // [rsp+28h] [rbp-108h]
  char *v65; // [rsp+40h] [rbp-F0h]
  char *v66; // [rsp+48h] [rbp-E8h]
  char *v67; // [rsp+50h] [rbp-E0h]
  rbx::signals::connection *v68; // [rsp+58h] [rbp-D8h]
  rbx::signals::connection *v69; // [rsp+60h] [rbp-D0h]
  rbx::signals::connection *v70; // [rsp+68h] [rbp-C8h]
  rbx::signals::connection *v71; // [rsp+70h] [rbp-C0h]
  rbx::signals::connection *v72; // [rsp+78h] [rbp-B8h]
  rbx::signals::connection *v73; // [rsp+80h] [rbp-B0h]
  char *v74; // [rsp+88h] [rbp-A8h]
  __int128 v75; // [rsp+90h] [rbp-A0h] BYREF
  __int128 v76; // [rsp+A0h] [rbp-90h]
  RBX::Physics::ConvexDecompVisualizer **v77; // [rsp+B8h] [rbp-78h]
  char v78; // [rsp+C7h] [rbp-69h] BYREF
  rbx::signals::connection *v79; // [rsp+C8h] [rbp-68h]
  std::__shared_weak_count *v80[2]; // [rsp+D0h] [rbp-60h] BYREF
  RBX::Workspace *v81; // [rsp+E0h] [rbp-50h]
  void *v82[8]; // [rsp+F0h] [rbp-40h] BYREF

  v78 = a5; /*0x104f7e5d7*/
  LOBYTE(v80[0]) = 1; /*0x104f7e5de*/
  LODWORD(v75) = 0; /*0x104f7e5e9*/
  RBX::Described<RBX::Workspace,RBX::WorldRoot>::Described<RBX::ForceConstructionInCreatable &,FInt::Value &,FInt::Value &,bool,bool &,RBX::WorldOwnerType>( /*0x104f7e60a*/
    (_DWORD)a1,
    a2: (_DWORD)a2 + 8,
    a3,
    a4: (unsigned int)&FInt::PhysicsGridHierarchyLowestLevelInitBinCount,
    a5: (unsigned int)&FInt::PhysicsSolverCollisionPoolBucketSize,
    a6: (unsigned int)v80,
    a7: (__int64)&v78,
    a8: (__int64)&v75);
  *((_QWORD *)a1 + 132) = &off_10C5E6018; /*0x104f7e616*/
  v63 = a2; /*0x104f7e62b*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)a1 + 1064, a2: ""); /*0x104f7e632*/
  *(_OWORD *)((char *)a1 + 1132) = 0; /*0x104f7e63b*/
  *((_OWORD *)a1 + 70) = 0; /*0x104f7e644*/
  *((_OWORD *)a1 + 69) = 0; /*0x104f7e64d*/
  *((_OWORD *)a1 + 68) = 0; /*0x104f7e656*/
  *((_DWORD *)a1 + 287) = 1; /*0x104f7e664*/
  *((_OWORD *)a1 + 72) = 0; /*0x104f7e66b*/
  *((_OWORD *)a1 + 73) = 0; /*0x104f7e674*/
  *((_OWORD *)a1 + 74) = 0; /*0x104f7e67d*/
  *((_OWORD *)a1 + 75) = 0; /*0x104f7e686*/
  *((_OWORD *)a1 + 76) = 0; /*0x104f7e68f*/
  *((_OWORD *)a1 + 77) = 0; /*0x104f7e698*/
  *((_OWORD *)a1 + 78) = 0; /*0x104f7e6a1*/
  *((_DWORD *)a1 + 316) = 0; /*0x104f7e6aa*/
  *(_QWORD *)((char *)a1 + 1268) = 0x40000000040LL; /*0x104f7e6bf*/
  *((_DWORD *)a1 + 319) = 1; /*0x104f7e6c6*/
  *((_OWORD *)a1 + 80) = 0; /*0x104f7e6cd*/
  *((_BYTE *)a1 + 1296) = 0; /*0x104f7e6d6*/
  *(_WORD *)((char *)a1 + 1297) = 1; /*0x104f7e6de*/
  *((_QWORD *)a1 + 163) = &off_10C9F0298; /*0x104f7e6ef*/
  *((_BYTE *)a1 + 1312) = 1; /*0x104f7e6f6*/
  *((_QWORD *)a1 + 165) = &off_10C9F02B0; /*0x104f7e705*/
  *((_QWORD *)a1 + 166) = &off_10C9F02C8; /*0x104f7e713*/
  *(_OWORD *)((char *)a1 + 1368) = 0; /*0x104f7e721*/
  *(_OWORD *)((char *)a1 + 1352) = 0; /*0x104f7e72a*/
  *(_OWORD *)((char *)a1 + 1336) = 0; /*0x104f7e733*/
  *((_QWORD *)a1 + 173) = 0; /*0x104f7e73c*/
  *((_DWORD *)a1 + 348) = 1065353216; /*0x104f7e747*/
  RBX::Time::nowFast(this: v8); /*0x104f7e752*/
  v65 = (char *)a1 + 1328; /*0x104f7e75e*/
  *((_QWORD *)a1 + 175) = v9; /*0x104f7e765*/
  *((_QWORD *)a1 + 176) = off_10C9F02E0; /*0x104f7e775*/
  v10 = *a2; /*0x104f7e77c*/
  *(_QWORD *)a1 = *a2; /*0x104f7e77f*/
  *((_QWORD *)a1 + 22) = off_10C5E6650; /*0x104f7e790*/
  *(_QWORD *)((char *)a1 + *(_QWORD *)(v10 - 24)) = a2[19]; /*0x104f7e7a2*/
  *((_QWORD *)a1 + 23) = &off_10C5E6670; /*0x104f7e7ad*/
  *((_QWORD *)a1 + 40) = off_10C5E6700; /*0x104f7e7bd*/
  *((_QWORD *)a1 + 44) = a2[20]; /*0x104f7e7cb*/
  *((_QWORD *)a1 + 45) = off_10C5E67C0; /*0x104f7e7d9*/
  *((_QWORD *)a1 + 100) = off_10C5E67E8; /*0x104f7e7e7*/
  *((_QWORD *)a1 + 101) = off_10C5E6820; /*0x104f7e7f5*/
  *((_QWORD *)a1 + 132) = &off_10C5E6840; /*0x104f7e803*/
  *((_QWORD *)a1 + 163) = &off_10C5E6958; /*0x104f7e811*/
  *((_QWORD *)a1 + 165) = &off_10C5E6970; /*0x104f7e81f*/
  *((_QWORD *)a1 + 166) = &off_10C5E6988; /*0x104f7e82d*/
  *((_QWORD *)a1 + 176) = off_10C5E69A0; /*0x104f7e83a*/
  *(_OWORD *)((char *)a1 + 1416) = 0; /*0x104f7e845*/
  *(_OWORD *)((char *)a1 + 1432) = 0; /*0x104f7e84e*/
  *(_OWORD *)((char *)a1 + 1448) = 0; /*0x104f7e857*/
  *(_OWORD *)((char *)a1 + 1464) = 0; /*0x104f7e860*/
  *(_OWORD *)((char *)a1 + 1480) = 0; /*0x104f7e869*/
  *(_OWORD *)((char *)a1 + 1496) = 0; /*0x104f7e872*/
  *(_OWORD *)((char *)a1 + 1512) = 0; /*0x104f7e87b*/
  *(_OWORD *)((char *)a1 + 1528) = 0; /*0x104f7e884*/
  *(_OWORD *)((char *)a1 + 1544) = 0; /*0x104f7e88d*/
  *((_QWORD *)a1 + 195) = RBX::Subsystem<RBX::PeerMonotonicClockManager,true>::startup<RBX::SubsystemDefaultFactory<RBX::PeerMonotonicClockManager>>(); /*0x104f7e89b*/
  *((_QWORD *)a1 + 196) = 850045863; /*0x104f7e8a2*/
  *((_QWORD *)a1 + 208) = 0; /*0x104f7e8ad*/
  *((_BYTE *)a1 + 1672) = 0; /*0x104f7e8ba*/
  v68 = (RBX::Workspace *)((char *)a1 + 1696); /*0x104f7e8c8*/
  v69 = (RBX::Workspace *)((char *)a1 + 1704); /*0x104f7e8d6*/
  v70 = (RBX::Workspace *)((char *)a1 + 1712); /*0x104f7e8e4*/
  v71 = (RBX::Workspace *)((char *)a1 + 1720); /*0x104f7e8f2*/
  v72 = (RBX::Workspace *)((char *)a1 + 1728); /*0x104f7e900*/
  v73 = (RBX::Workspace *)((char *)a1 + 1736); /*0x104f7e90e*/
  *(_OWORD *)((char *)a1 + 1576) = 0; /*0x104f7e920*/
  *(_OWORD *)((char *)a1 + 1592) = 0; /*0x104f7e929*/
  *(_OWORD *)((char *)a1 + 1608) = 0; /*0x104f7e932*/
  *(_OWORD *)((char *)a1 + 1624) = 0; /*0x104f7e93b*/
  *((_BYTE *)a1 + 1640) = 0; /*0x104f7e944*/
  *((_OWORD *)a1 + 106) = 0; /*0x104f7e94b*/
  *((_OWORD *)a1 + 107) = 0; /*0x104f7e954*/
  *((_OWORD *)a1 + 108) = 0; /*0x104f7e95d*/
  *((_OWORD *)a1 + 109) = 0; /*0x104f7e966*/
  *((_OWORD *)a1 + 110) = 0; /*0x104f7e96f*/
  *((_OWORD *)a1 + 111) = 0; /*0x104f7e978*/
  *((_OWORD *)a1 + 112) = 0; /*0x104f7e981*/
  v76 = 0; /*0x104f7e991*/
  v75 = 0; /*0x104f7e996*/
  RBX::detail::DenseHashTable<RBX::SignalPair,std::pair<RBX::SignalPair,RBX::TouchStateManager>,std::pair<RBX::SignalPair const,RBX::TouchStateManager>,RBX::detail::ItemInterfaceMap<RBX::SignalPair,RBX::TouchStateManager>,RBX::Hash<RBX::SignalPair>,std::equal_to<RBX::SignalPair>>::DenseHashTable( /*0x104f7e99f*/
    a1: (char *)a1 + 1808,
    a2: &v75,
    a3: 0);
  v12 = *((std::__shared_weak_count **)&v76 + 1); /*0x104f7e9a4*/
  if ( *((_QWORD *)&v76 + 1) != 0 /*0x104f7e9c1*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v76 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x104f7e9ca*/
    std::__shared_weak_count::__release_weak(this: v12); /*0x104f7e9d0*/
  }
  v13 = *((std::__shared_weak_count **)&v75 + 1); /*0x104f7e9d5*/
  if ( *((_QWORD *)&v75 + 1) != 0 /*0x104f7e9f2*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v75 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x104f7e9fb*/
    std::__shared_weak_count::__release_weak(this: v13); /*0x104f7ea01*/
  }
  v66 = (char *)a1 + 1808; /*0x104f7ea06*/
  DefaultArena = RSL::Arena::getDefaultArena(this: v11); /*0x104f7ea0d*/
  *(_OWORD *)((char *)a1 + 1880) = 0; /*0x104f7ea16*/
  *((_QWORD *)a1 + 237) = 0; /*0x104f7ea1f*/
  *((_QWORD *)a1 + 238) = DefaultArena; /*0x104f7ea2a*/
  v77 = (RBX::Physics::ConvexDecompVisualizer **)((char *)a1 + 1920); /*0x104f7ea38*/
  *(_OWORD *)((char *)a1 + 1912) = 0; /*0x104f7ea3c*/
  v15 = operator new(a1: 0x40u); /*0x104f7ea4f*/
  v17 = RSL::Arena::getDefaultArena(this: v16); /*0x104f7ea59*/
  *(_OWORD *)v15 = 0; /*0x104f7ea62*/
  *(_QWORD *)(v15 + 16) = 0; /*0x104f7ea6b*/
  *(_QWORD *)(v15 + 24) = v17; /*0x104f7ea70*/
  v19 = RSL::Arena::getDefaultArena(this: v18); /*0x104f7ea75*/
  *(_OWORD *)(v15 + 32) = 0; /*0x104f7ea7e*/
  *(_QWORD *)(v15 + 48) = 0; /*0x104f7ea85*/
  *(_QWORD *)(v15 + 56) = v19; /*0x104f7ea8a*/
  v67 = (char *)a1 + 1928; /*0x104f7ea8f*/
  std::shared_ptr<RBX::IAdornableCollector>::shared_ptr[abi:ne200100]<RBX::IAdornableCollector,0>( /*0x104f7ea9c*/
    a1: (char *)a1 + 1928,
    a2: v15);
  *(_OWORD *)((char *)a1 + 1992) = 0; /*0x104f7eaa5*/
  *(_OWORD *)((char *)a1 + 1976) = 0; /*0x104f7eaae*/
  *(_OWORD *)((char *)a1 + 1960) = 0; /*0x104f7eab7*/
  *(_OWORD *)((char *)a1 + 1944) = 0; /*0x104f7eac0*/
  *((_QWORD *)a1 + 251) = 0; /*0x104f7eac9*/
  *((_QWORD *)a1 + 252) = 0xFFEFFFFFFFFFFFFFLL; /*0x104f7eade*/
  *(_OWORD *)((char *)a1 + 2024) = 0; /*0x104f7eae5*/
  *((_QWORD *)a1 + 255) = a4; /*0x104f7eaee*/
  *((_BYTE *)a1 + 2048) = 0; /*0x104f7eaf5*/
  *(_OWORD *)((char *)a1 + 2056) = 0; /*0x104f7eafd*/
  *(_OWORD *)((char *)a1 + 2072) = 0; /*0x104f7eb06*/
  *(_OWORD *)((char *)a1 + 2088) = 0; /*0x104f7eb0f*/
  v20 = (RBX::VerbContainer *)operator new(a1: 0x60u); /*0x104f7eb22*/
  RBX::VerbContainer::VerbContainer(this: v20, a2: nullptr); /*0x104f7eb2a*/
  *((_QWORD *)a1 + 263) = v20; /*0x104f7eb2f*/
  *((_DWORD *)a1 + 528) = 0x1000000; /*0x104f7eb36*/
  *(_OWORD *)((char *)a1 + 2120) = 0; /*0x104f7eb44*/
  *(_OWORD *)((char *)a1 + 2136) = 0; /*0x104f7eb4c*/
  *(_OWORD *)((char *)a1 + 2152) = 0; /*0x104f7eb54*/
  *(_OWORD *)((char *)a1 + 2168) = 0; /*0x104f7eb5c*/
  *(_OWORD *)((char *)a1 + 2184) = 0; /*0x104f7eb64*/
  *(_OWORD *)((char *)a1 + 2200) = 0; /*0x104f7eb6c*/
  *((_DWORD *)a1 + 554) = 1065353216; /*0x104f7eb74*/
  *((_OWORD *)a1 + 139) = 0; /*0x104f7eb7f*/
  *((_OWORD *)a1 + 140) = 0; /*0x104f7eb87*/
  *((_OWORD *)a1 + 141) = 0; /*0x104f7eb8f*/
  *((_WORD *)a1 + 1136) = 0; /*0x104f7eb97*/
  *((_BYTE *)a1 + 2274) = 1; /*0x104f7eba3*/
  *((double *)a1 + 285) = 1.0 / (double)(int)DFInt::PhysicsEMAInverseSmoothingFactor; /*0x104f7ebcb*/
  *((_OWORD *)a1 + 143) = 0; /*0x104f7ebd4*/
  *((_QWORD *)a1 + 288) = 0; /*0x104f7ebdc*/
  *((_BYTE *)a1 + 2312) = 1; /*0x104f7ebe7*/
  *((_OWORD *)a1 + 145) = 0; /*0x104f7ebee*/
  *((_OWORD *)a1 + 146) = 0; /*0x104f7ebf6*/
  *((_OWORD *)a1 + 147) = 0; /*0x104f7ebfe*/
  *((_QWORD *)a1 + 296) = 0x400000000LL; /*0x104f7ec10*/
  *(_OWORD *)((char *)a1 + 2376) = 0; /*0x104f7ec1e*/
  v21 = *((RBX::World **)a1 + 118); /*0x104f7ec2d*/
  v74 = (char *)a1 + 2376; /*0x104f7ec37*/
  RBX::WorkspaceSynchHelper::WorkspaceSynchHelper(this: (RBX::Workspace *)((char *)a1 + 2392), a2: v21); /*0x104f7ec3e*/
  v23 = RSL::Arena::getDefaultArena(this: v22); /*0x104f7ec43*/
  *((_OWORD *)a1 + 201) = 0; /*0x104f7ec4c*/
  *((_QWORD *)a1 + 404) = 0; /*0x104f7ec57*/
  *((_QWORD *)a1 + 405) = v23; /*0x104f7ec5e*/
  *((_QWORD *)a1 + 406) = 0; /*0x104f7ec65*/
  v64 = (char *)a1 + 2392; /*0x104f7ec75*/
  RBX::EngineNetConfiguration::EngineNetConfiguration(a1: (char *)a1 + 3256, a2: 0); /*0x104f7ec7c*/
  *((_OWORD *)a1 + 204) = 0; /*0x104f7ec85*/
  *((_DWORD *)a1 + 820) = 0; /*0x104f7ec8e*/
  *(_OWORD *)((char *)a1 + 3288) = 0; /*0x104f7eca0*/
  *(_OWORD *)((char *)a1 + 3304) = 0; /*0x104f7eca9*/
  *(_OWORD *)((char *)a1 + 3313) = 0; /*0x104f7ecb2*/
  *((_QWORD *)a1 + 417) = RBX::Subsystem<RBX::Profiler::ProfileTelemetry,false>::startup<RBX::SubsystemDefaultFactory<RBX::Profiler::ProfileTelemetry>>(a1: v24); /*0x104f7ecc0*/
  v79 = (RBX::Workspace *)((char *)a1 + 3344); /*0x104f7ecce*/
  *((_OWORD *)a1 + 209) = 0; /*0x104f7ecd6*/
  *((_OWORD *)a1 + 210) = 0; /*0x104f7ecdf*/
  RBX::Creatable::createWithEngineContext<RBX::Camera>(a1: &v75, a2: *((_QWORD *)a1 + 11) & 0xFFFFFFFFFFFFFFF8LL); /*0x104f7ecf7*/
  std::shared_ptr<RBX::Camera>::operator=[abi:ne200100](a1: (char *)a1 + 2136, a2: &v75); /*0x104f7ed09*/
  v25 = *((std::__shared_weak_count **)&v75 + 1); /*0x104f7ed0e*/
  if ( *((_QWORD *)&v75 + 1) != 0 /*0x104f7ed27*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v75 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v25 + 16LL))(a1: v25); /*0x104f7ed30*/
    std::__shared_weak_count::__release_weak(this: v25); /*0x104f7ed36*/
  }
  if ( DFFlag::PerfDataServerAuthorityMode == 1 )
  {
    v26 = *((_QWORD *)a1 + 417); /*0x104f7ed44*/
    v27 = v26 != 0 ? *(RBX::Profiler::ProfileTelemetry **)(v26 + 24) : nullptr;
    ProfileSignal = RBX::Profiler::ProfileTelemetry::getProfileSignal(this: v27); /*0x104f7ed58*/
    v80[0] = a1; /*0x104f7ed61*/
    rbx::direct_signal<void ()(RBX::Profiler::ProfileSignalParams &)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_1>( /*0x104f7ed6e*/
      a1: &v75,
      a2: ProfileSignal);
    rbx::signals::scoped_connection::operator=(this: v79); /*0x104f7ed7e*/
    v29 = (void *)v75; /*0x104f7ed83*/
    if ( (_QWORD)v75 != 0 && _InterlockedDecrement((volatile signed __int32 *)(v75 + 4)) == 0 ) /*0x104f7ed93*/
      rbx::signals::slot_base::operator delete(a1: v29); /*0x104f7ed95*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v75, a2: "Workspace"); /*0x104f7eda8*/
  RBX::Instance::setName(a1, a2: &v75); /*0x104f7edb7*/
  if ( (v75 & 1) != 0 ) /*0x104f7edc3*/
    operator delete(a1: (void *)v76); /*0x104f7edcc*/
  if ( (unsigned __int8)FLog::GuiTargetLifetime >= 6u && BYTE1(FLog::GuiTargetLifetime) >= 3u )
    FLog::FastLog(
      a1: *(_QWORD *)&FLog::GuiTargetLifetime,
      a2: qword_10D7F3AC0,
      a3: "[FLog::GuiTargetLifetime] Workspace created: %p",
      a1);
  *((_BYTE *)a1 + 952) = 0; /*0x104f7ee04*/
  v75 = (unsigned int)FInt::SimWorldTaskQueueParallelTasks; /*0x104f7ee2f*/
  LOWORD(v76) = 1; /*0x104f7ee32*/
  *(_OWORD *)v82 = 0; /*0x104f7ee41*/
  RBX::TaskScheduler::createTaskQueue(a1: v80, a2: "WorkspaceTaskQueue", a3: 18, a4: v82, a5: 7); /*0x104f7ee5b*/
  std::shared_ptr<RBX::TaskQueue>::operator=[abi:ne200100](a1: (char *)a1 + 2376, a2: v80); /*0x104f7ee6a*/
  v30 = v80[1]; /*0x104f7ee6f*/
  if ( v80[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v80[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f7ee88*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v30 + 16LL))(a1: v30); /*0x104f7ee91*/
    std::__shared_weak_count::__release_weak(this: v30); /*0x104f7ee97*/
  }
  v31 = (std::__shared_weak_count *)v82[1]; /*0x104f7ee9c*/
  if ( v82[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v82[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f7eeb5*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v31 + 16LL))(a1: v31); /*0x104f7eebe*/
    std::__shared_weak_count::__release_weak(this: v31); /*0x104f7eec4*/
  }
  v32 = *((_QWORD *)a1 + 118); /*0x104f7eec9*/
  v33 = *((_QWORD *)a1 + 298); /*0x104f7eed0*/
  v62 = *(_OWORD *)((char *)a1 + 2376); /*0x104f7eee0*/
  if ( v33 != 0 ) /*0x104f7eeeb*/
    _InterlockedIncrement64((volatile signed __int64 *)(v33 + 8)); /*0x104f7eeed*/
  std::shared_ptr<RBX::TaskQueue>::operator=[abi:ne200100](a1: v32 + 1008, a2: &v62); /*0x104f7ef03*/
  v35 = *((std::__shared_weak_count **)&v62 + 1); /*0x104f7ef08*/
  if ( *((_QWORD *)&v62 + 1) != 0 /*0x104f7ef21*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v62 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v35 + 16LL))(a1: v35); /*0x104f7ef2a*/
    std::__shared_weak_count::__release_weak(this: v35); /*0x104f7ef30*/
  }
  RBX::World::createWorldInterpolator(this: *((RBX::World **)a1 + 118), a2: v34); /*0x104f7ef3c*/
  *(_QWORD *)(*((_QWORD *)a1 + 118) + 184LL) = v65; /*0x104f7ef4f*/
  v36 = (RBX::Constraints::GizmoManager *)operator new(a1: 0x1430u); /*0x104f7ef60*/
  RBX::Constraints::GizmoManager::GizmoManager(this: v36, a2: a1); /*0x104f7ef69*/
  *((_QWORD *)a1 + 272) = v36; /*0x104f7ef6e*/
  if ( FFlag::UseAdornBasedCDDebugVis == 1 ) /*0x104f7ef7c*/
  {
    v37 = (RBX::Physics::ConvexDecompVisualizer *)operator new(a1: 0x30u); /*0x104f7ef88*/
    RBX::Physics::ConvexDecompVisualizer::ConvexDecompVisualizer(this: v37); /*0x104f7ef8e*/
    v80[0] = nullptr; /*0x104f7ef93*/
    v38 = *v77; /*0x104f7ef9f*/
    *v77 = v37; /*0x104f7efa2*/
    if ( v38 != nullptr ) /*0x104f7efa8*/
    {
      std::default_delete<RBX::Physics::ConvexDecompVisualizer>::operator()[abi:ne200100](a1: v77); /*0x104f7efae*/
      v39 = v80[0]; /*0x104f7efb3*/
      v80[0] = nullptr; /*0x104f7efb7*/
      if ( v39 != nullptr ) /*0x104f7efc2*/
        std::default_delete<RBX::Physics::ConvexDecompVisualizer>::operator()[abi:ne200100](a1: v80); /*0x104f7efc8*/
    }
  }
  if ( DFFlag::FluidForcesSwitchToThreePhaseRollout == 1 ) /*0x104f7efd4*/
  {
    v40 = *((RBX::World **)a1 + 118); /*0x104f7efd6*/
    if ( DFFlag::FluidForcesThreePhaseRolloutProperty == 1 && *((_DWORD *)a1 + 292) == 1 ) /*0x104f7eff0*/
      v41 = 1; /*0x104f7f019*/
    else
      v41 = DFFlag::FluidForcesDefaultEnabled; /*0x104f7eff4*/
  }
  else
  {
    if ( *((_DWORD *)a1 + 292) != 0 ) /*0x104f7f004*/
      goto LABEL_44; /*0x104f7f004*/
    v40 = *((RBX::World **)a1 + 118); /*0x104f7f006*/
    v41 = FInt::SimDefaultFluidForceEnabled != 0; /*0x104f7f014*/
  }
  RBX::World::setEnableFluidForces(this: v40, a2: v41); /*0x104f7f01e*/
LABEL_44:
  v42 = *((_DWORD *)a1 + 308); /*0x104f7f023*/
  if ( v42 != 0 ) /*0x104f7f03b*/
    v43 = v42 == 1; /*0x104f7f045*/
  else
    v43 = FFlag::DebugCLI122361Alpha; /*0x104f7f03d*/
  RBX::World::setEnablePrimalSolver(this: *((RBX::World **)a1 + 118), a2: v43 & 1); /*0x104f7f04b*/
  if ( FFlag::UseFixedSimulationThreePhaseRolloutProperty != 0 || FFlag::UseFixedSimulationDefaultEnabled == 1 ) /*0x104f7f060*/
  {
    v44 = *((_QWORD *)a1 + 118); /*0x104f7f062*/
    *(_BYTE *)(v44 + 553) = RBX::Workspace::getUseFixedSimulationEnabled(this: a1); /*0x104f7f071*/
  }
  v45 = *((_QWORD *)a1 + 118); /*0x104f7f078*/
  v80[0] = (std::__shared_weak_count *)RBX::Workspace::handleNetworkOwnershipUnitMovedWorldSignal; /*0x104f7f08a*/
  v80[1] = nullptr; /*0x104f7f08d*/
  v81 = a1; /*0x104f7f095*/
  rbx::signal<void ()(RBX::Primitive *)>::connect<std::__bind<void (RBX::Workspace::*)(RBX::Primitive *),RBX::Workspace*,std::placeholders::__ph<1> const&>>( /*0x104f7f0a1*/
    a1: v82,
    a2: v45 + 40);
  rbx::signals::scoped_connection::operator=(this: v68); /*0x104f7f0b1*/
  v46 = v82[0]; /*0x104f7f0b6*/
  if ( v82[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v82[0] + 1) == 0 ) /*0x104f7f0c3*/
    rbx::signals::slot_base::operator delete(a1: v46); /*0x104f7f0c5*/
  v47 = *((_QWORD *)a1 + 118); /*0x104f7f0ca*/
  v80[0] = (std::__shared_weak_count *)RBX::Workspace::handleNetworkOwnershipUnitAddedWorldSignal; /*0x104f7f0dc*/
  v80[1] = nullptr; /*0x104f7f0df*/
  v81 = a1; /*0x104f7f0e7*/
  rbx::signal<void ()(RBX::Primitive *,bool,bool)>::connect<std::__bind<void (RBX::Workspace::*)(RBX::Primitive *,bool,bool),RBX::Workspace*,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&,std::placeholders::__ph<3> const&>>( /*0x104f7f0f3*/
    a1: v82,
    a2: v47 + 48);
  rbx::signals::scoped_connection::operator=(this: v69); /*0x104f7f103*/
  v48 = v82[0]; /*0x104f7f108*/
  if ( v82[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v82[0] + 1) == 0 ) /*0x104f7f115*/
    rbx::signals::slot_base::operator delete(a1: v48); /*0x104f7f117*/
  v49 = *((_QWORD *)a1 + 118); /*0x104f7f11c*/
  v80[0] = (std::__shared_weak_count *)RBX::Workspace::handleNetworkOwnershipUnitRemovingWorldSignal; /*0x104f7f12e*/
  v80[1] = nullptr; /*0x104f7f131*/
  v81 = a1; /*0x104f7f139*/
  rbx::signal<void ()(RBX::Primitive *,bool)>::connect<std::__bind<void (RBX::Workspace::*)(RBX::Primitive *,bool),RBX::Workspace*,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>( /*0x104f7f145*/
    a1: v82,
    a2: v49 + 56);
  rbx::signals::scoped_connection::operator=(this: v70); /*0x104f7f155*/
  v50 = v82[0]; /*0x104f7f15a*/
  if ( v82[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v82[0] + 1) == 0 ) /*0x104f7f167*/
    rbx::signals::slot_base::operator delete(a1: v50); /*0x104f7f169*/
  v51 = FFlag::SAuthWorkspaceFlagged; /*0x104f7f17c*/
  if ( (((unsigned __int8)FFlag::SAuthWorkspaceFlagged | (unsigned __int8)FFlag::DebugHashTableMetrics) & 1) != 0 /*0x104f7f194*/
    || FFlag::NextGenReplicatorEnabledRead == 1 )
  {
    v52 = *((_QWORD *)a1 + 118) + 72LL; /*0x104f7f19d*/
    v82[0] = a1; /*0x104f7f1a5*/
    rbx::signal<void ()(int)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_2>( /*0x104f7f1ac*/
      a1: v80,
      a2: v52);
    rbx::signals::scoped_connection::operator=(this: v72); /*0x104f7f1bc*/
    v53 = v80[0]; /*0x104f7f1c1*/
    if ( v80[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v80[0] + 1) == 0 ) /*0x104f7f1ce*/
      rbx::signals::slot_base::operator delete(a1: v53); /*0x104f7f1d0*/
    v51 = FFlag::SAuthWorkspaceFlagged; /*0x104f7f1d5*/
  }
  if ( (v51 & 1) != 0 ) /*0x104f7f1db*/
  {
    v54 = *((_QWORD *)a1 + 118) + 80LL; /*0x104f7f1e4*/
    v82[0] = a1; /*0x104f7f1ec*/
    rbx::signal<void ()(RBX::Primitive *)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_3>( /*0x104f7f1f3*/
      a1: v80,
      a2: v54);
    rbx::signals::scoped_connection::operator=(this: v73); /*0x104f7f203*/
  }
  else
  {
    RBX::EngineNetConfiguration::EngineNetConfiguration(a1: v80, a2: 0); /*0x104f7f210*/
    if ( FFlag::DebugHashTableMetrics == 0 ) /*0x104f7f219*/
    {
      if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x104f7f335*/
      {
        if ( ((__int64)v80[0] & 8) == 0 && FFlag::NextGenReplicatorEnabledWrite == 0 && ((__int64)v80[0] & 1) == 0 ) /*0x104f7f355*/
          goto LABEL_72; /*0x104f7f355*/
      }
      else if ( FFlag::NextGenReplicatorEnabledRead == 0 || FFlag::NextGenReplicatorEnabledWrite != 1 ) /*0x104f7f37a*/
      {
        goto LABEL_72; /*0x104f7f37a*/
      }
    }
    v55 = *((_QWORD *)a1 + 118) + 80LL; /*0x104f7f226*/
    v82[0] = a1; /*0x104f7f22e*/
    rbx::signal<void ()(RBX::Primitive *)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_4>( /*0x104f7f235*/
      a1: v80,
      a2: v55);
    rbx::signals::scoped_connection::operator=(this: v73); /*0x104f7f245*/
  }
  v56 = v80[0]; /*0x104f7f24a*/
  if ( v80[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v80[0] + 1) == 0 ) /*0x104f7f257*/
    rbx::signals::slot_base::operator delete(a1: v56); /*0x104f7f259*/
LABEL_72:
  v57 = *((_QWORD *)a1 + 118) + 64LL; /*0x104f7f25e*/
  v82[0] = a1; /*0x104f7f26d*/
  rbx::signal<void ()(RBX::Primitive *,bool)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_5>( /*0x104f7f274*/
    a1: v80,
    a2: v57);
  rbx::signals::scoped_connection::operator=(this: v71); /*0x104f7f284*/
  v58 = v80[0]; /*0x104f7f289*/
  if ( v80[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v80[0] + 1) == 0 ) /*0x104f7f296*/
    rbx::signals::slot_base::operator delete(a1: v58); /*0x104f7f298*/
  if ( FFlag::SimTurbulentFlow == 1 ) /*0x104f7f2a7*/
    RBX::World::setAirTurbulenceIntensity( /*0x104f7f2b9*/
      this: *((RBX::FluidModels::FixedProfileFluid ***)a1 + 118),
      a2: *((float *)a1 + 286));
  v59 = *((_QWORD *)a1 + 2); /*0x104f7f2be*/
  *(_OWORD *)v80 = *(_OWORD *)((char *)a1 + 8); /*0x104f7f2c8*/
  if ( v59 != 0 ) /*0x104f7f2d0*/
    _InterlockedIncrement64((volatile signed __int64 *)(v59 + 16)); /*0x104f7f2d2*/
  v60 = RBX::CorePhysicsSettings::singleton(this: v58); /*0x104f7f2d7*/
  rbx::signal<void ()(RBX::Reflection::PropertyDescriptor const*)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_0 &>( /*0x104f7f2eb*/
    a1: v82,
    a2: v60 + 32,
    a3: v80);
  rbx::signals::scoped_connection::operator=(this: (RBX::Workspace *)((char *)a1 + 3320)); /*0x104f7f2f7*/
  v61 = v82[0]; /*0x104f7f2fc*/
  if ( v82[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v82[0] + 1) == 0 ) /*0x104f7f309*/
    rbx::signals::slot_base::operator delete(a1: v61); /*0x104f7f30b*/
  if ( v80[1] != nullptr ) /*0x104f7f317*/
    std::__shared_weak_count::__release_weak(this: v80[1]); /*0x104f7f319*/
}

// Address: 0x104f7fc32 | Name: __ZNK3RBX9Workspace21getFluidForcesEnabledEv
char __fastcall RBX::Workspace::getFluidForcesEnabled(RBX::Workspace *this)
{
  if ( DFFlag::FluidForcesThreePhaseRolloutProperty == 1 && *((_DWORD *)this + 292) /* +1168 likely monotonicClock.lastComputedTimeUS -- UNVERIFIED */ == 1 ) /*0x104f7fc48*/
    return 1; /*0x104f7fc54*/
  else
    return DFFlag::FluidForcesDefaultEnabled; /*0x104f7fc4c*/
}

// Address: 0x104f7fc58 | Name: __ZNK3RBX9Workspace28getUseFixedSimulationEnabledEv
char __fastcall RBX::Workspace::getUseFixedSimulationEnabled(RBX::Workspace *this)
{
  int UseFixedSimulation; // eax

  if ( FFlag::UseFixedSimulationThreePhaseRolloutProperty != 1 ) /*0x104f7fc5f*/
    return FFlag::UseFixedSimulationDefaultEnabled; /*0x104f7fc5f*/
  UseFixedSimulation = RBX::WorkspaceProp::getUseFixedSimulation(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f7fc6c*/
  if ( UseFixedSimulation == 2 ) /*0x104f7fc75*/
    return 1; /*0x104f7fc88*/
  if ( UseFixedSimulation != 1 ) /*0x104f7fc7a*/
    return FFlag::UseFixedSimulationDefaultEnabled; /*0x104f7fc84*/
  return 0; /*0x104f7fc84*/
}

// Address: 0x104f7fd66 | Name: __ZN3RBX9Workspace42handleNetworkOwnershipUnitMovedWorldSignalEPNS_9PrimitiveE
__int64 __fastcall RBX::Workspace::handleNetworkOwnershipUnitMovedWorldSignal(RBX::Workspace *this, RBX::Primitive *a2)
{
  __int64 result; // rax
  __int64 v4; // [rsp+0h] [rbp-10h] BYREF

  result = RBX::BasePart::fromPrimitive(this: a2, a2); /*0x104f7fd72*/
  v4 = result; /*0x104f7fd77*/
  if ( result != 0 ) /*0x104f7fd7e*/
    return rbx::signal<void ()(RBX::BasePart *)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x104f7fd8e*/
             a1: (char *)this + 1496 /* +1496 = showGridMaterial (bool, 1B) -- SIZE CONFLICT, see --verify */,
             a2: &v4);
  return result; /*0x104f7fd97*/
}

// Address: 0x104f7fe74 | Name: __ZN3RBX9Workspace42handleNetworkOwnershipUnitAddedWorldSignalEPNS_9PrimitiveEbb
__int64 __fastcall RBX::Workspace::handleNetworkOwnershipUnitAddedWorldSignal(
        RBX::Workspace *this,
        RBX::Primitive *a2,
        char a3,
        char a4)
{
  __int64 result; // rax
  __int64 v6; // [rsp+8h] [rbp-18h] BYREF
  char v7; // [rsp+16h] [rbp-Ah] BYREF
  _BYTE v8[9]; // [rsp+17h] [rbp-9h] BYREF

  v7 = a3; /*0x104f7fe80*/
  v8[0] = a4; /*0x104f7fe83*/
  result = RBX::BasePart::fromPrimitive(this: a2, a2); /*0x104f7fe89*/
  v6 = result; /*0x104f7fe8e*/
  if ( result != 0 ) /*0x104f7fe95*/
    return rbx::signal<void ()(RBX::BasePart *,bool,bool)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x104f7fead*/
             a1: (char *)this + 1504 /* +1504 = overrideCamera.._Ptr (RBX::Camera *, 8B) -- SIZE CONFLICT, see --verify */,
             a2: &v6,
             a3: &v7,
             a4: v8);
  return result; /*0x104f7feb2*/
}

// Address: 0x104f7ff94 | Name: __ZN3RBX9Workspace45handleNetworkOwnershipUnitRemovingWorldSignalEPNS_9PrimitiveEb
__int64 __fastcall RBX::Workspace::handleNetworkOwnershipUnitRemovingWorldSignal(
        RBX::Workspace *this,
        RBX::Primitive *a2,
        char a3)
{
  __int64 result; // rax
  __int64 v5; // [rsp+8h] [rbp-18h] BYREF
  _BYTE v6[9]; // [rsp+17h] [rbp-9h] BYREF

  v6[0] = a3; /*0x104f7ffa0*/
  result = RBX::BasePart::fromPrimitive(this: a2, a2); /*0x104f7ffa6*/
  v5 = result; /*0x104f7ffab*/
  if ( result != 0 ) /*0x104f7ffb2*/
    return rbx::signal<void ()(RBX::BasePart *,bool)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x104f7ffc6*/
             a1: (char *)this + 1512 /* +1512 = overrideCamera.._Rep (std::_Ref_count_base *, 8B) -- SIZE CONFLICT, see --verify */,
             a2: &v5,
             a3: v6);
  return result; /*0x104f7ffcb*/
}

// Address: 0x104f8045e | Name: __ZN3RBX9WorkspaceC1ERNS_28ForceConstructionInCreatableEPNS_10IDataStateEb
void __fastcall RBX::Workspace::Workspace(RBX::Workspace *a1, int a2, __int64 a3, char a4)
{
  RBX::Time *v6; // rdi
  __int64 v7; // xmm0_8
  RSL::Arena *v8; // rdi
  std::__shared_weak_count *v9; // r14
  std::__shared_weak_count *v10; // r14
  __int64 DefaultArena; // rax
  __int64 v12; // r12
  RSL::Arena *v13; // rdi
  __int64 v14; // rax
  RSL::Arena *v15; // rdi
  __int64 v16; // rax
  RBX::VerbContainer *v17; // r15
  RSL::Arena *v18; // rdi
  __int64 v19; // rax
  __int64 v20; // rdi
  std::__shared_weak_count *v21; // r14
  __int64 v22; // rax
  RBX::Profiler::ProfileTelemetry *v23; // rdi
  __int64 ProfileSignal; // rax
  void *v25; // rdi
  std::__shared_weak_count *v26; // r14
  std::__shared_weak_count *v27; // r14
  __int64 v28; // rdi
  __int64 v29; // rax
  unsigned int v30; // esi
  std::__shared_weak_count *v31; // r14
  RBX::Constraints::GizmoManager *v32; // r14
  RBX::Physics::ConvexDecompVisualizer *v33; // r14
  RBX::Physics::ConvexDecompVisualizer *v34; // rsi
  std::__shared_weak_count *v35; // rsi
  RBX::World *v36; // rdi
  char v37; // al
  int v38; // ecx
  char v39; // si
  __int64 v40; // r14
  __int64 v41; // rsi
  void *v42; // rdi
  __int64 v43; // rsi
  void *v44; // rdi
  __int64 v45; // rsi
  void *v46; // rdi
  char v47; // al
  __int64 v48; // rsi
  std::__shared_weak_count *v49; // rdi
  __int64 v50; // rsi
  __int64 v51; // rsi
  std::__shared_weak_count *v52; // rdi
  __int64 v53; // rsi
  std::__shared_weak_count *v54; // rdi
  __int64 v55; // rax
  __int64 v56; // rax
  void *v57; // rdi
  __int128 v58; // [rsp+10h] [rbp-120h] BYREF
  char *v59; // [rsp+28h] [rbp-108h]
  char *v60; // [rsp+40h] [rbp-F0h]
  char *v61; // [rsp+48h] [rbp-E8h]
  rbx::signals::connection *v62; // [rsp+50h] [rbp-E0h]
  rbx::signals::connection *v63; // [rsp+58h] [rbp-D8h]
  rbx::signals::connection *v64; // [rsp+60h] [rbp-D0h]
  rbx::signals::connection *v65; // [rsp+68h] [rbp-C8h]
  rbx::signals::connection *v66; // [rsp+70h] [rbp-C0h]
  rbx::signals::connection *v67; // [rsp+78h] [rbp-B8h]
  __int128 v68; // [rsp+80h] [rbp-B0h] BYREF
  __int128 v69; // [rsp+90h] [rbp-A0h]
  char *v70; // [rsp+A8h] [rbp-88h]
  char *v71; // [rsp+B0h] [rbp-80h]
  RBX::Physics::ConvexDecompVisualizer **v72; // [rsp+B8h] [rbp-78h]
  rbx::signals::connection *v73; // [rsp+C0h] [rbp-70h]
  char v74; // [rsp+CFh] [rbp-61h] BYREF
  std::__shared_weak_count *v75[2]; // [rsp+D0h] [rbp-60h] BYREF
  RBX::Workspace *v76; // [rsp+E0h] [rbp-50h]
  void *v77[8]; // [rsp+F0h] [rbp-40h] BYREF

  v74 = a4; /*0x104f8047f*/
  *((_QWORD *)a1 + 44) = &off_10C539050; /*0x104f80488*/
  LOBYTE(v75[0]) = 1; /*0x104f80493*/
  LODWORD(v68) = 0; /*0x104f8049e*/
  RBX::Described<RBX::Workspace,RBX::WorldRoot>::Described<RBX::ForceConstructionInCreatable &,FInt::Value &,FInt::Value &,bool,bool &,RBX::WorldOwnerType>( /*0x104f804c6*/
    (_DWORD)a1,
    a2: (unsigned int)&off_10C5E69D8,
    a3: a2,
    a4: (unsigned int)&FInt::PhysicsGridHierarchyLowestLevelInitBinCount,
    a5: (unsigned int)&FInt::PhysicsSolverCollisionPoolBucketSize,
    a6: (unsigned int)v75,
    a7: (__int64)&v74,
    a8: (__int64)&v68);
  *((_QWORD *)a1 + 132) = &off_10C5E6018; /*0x104f804d2*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)a1 + 1064, a2: ""); /*0x104f804e7*/
  *(_OWORD *)((char *)a1 + 1132) = 0; /*0x104f804f0*/
  *((_OWORD *)a1 + 70) = 0; /*0x104f804f8*/
  *((_OWORD *)a1 + 69) = 0; /*0x104f80500*/
  *((_OWORD *)a1 + 68) = 0; /*0x104f80508*/
  *((_DWORD *)a1 + 287) = 1; /*0x104f80515*/
  *((_OWORD *)a1 + 72) = 0; /*0x104f8051b*/
  *((_OWORD *)a1 + 73) = 0; /*0x104f80523*/
  *((_OWORD *)a1 + 74) = 0; /*0x104f8052b*/
  *((_OWORD *)a1 + 75) = 0; /*0x104f80533*/
  *((_OWORD *)a1 + 76) = 0; /*0x104f8053b*/
  *((_OWORD *)a1 + 77) = 0; /*0x104f80543*/
  *((_OWORD *)a1 + 78) = 0; /*0x104f8054b*/
  *((_DWORD *)a1 + 316) = 0; /*0x104f80553*/
  *(_QWORD *)((char *)a1 + 1268) = 0x40000000040LL; /*0x104f80567*/
  *((_DWORD *)a1 + 319) = 1; /*0x104f8056e*/
  *((_OWORD *)a1 + 80) = 0; /*0x104f80574*/
  *((_BYTE *)a1 + 1296) = 0; /*0x104f8057c*/
  *(_WORD *)((char *)a1 + 1297) = 1; /*0x104f80583*/
  *((_QWORD *)a1 + 163) = &off_10C9F0298; /*0x104f80593*/
  *((_BYTE *)a1 + 1312) = 1; /*0x104f8059a*/
  *((_QWORD *)a1 + 165) = &off_10C9F02B0; /*0x104f805a8*/
  *((_QWORD *)a1 + 166) = &off_10C9F02C8; /*0x104f805b6*/
  *(_OWORD *)((char *)a1 + 1368) = 0; /*0x104f805c4*/
  *(_OWORD *)((char *)a1 + 1352) = 0; /*0x104f805cc*/
  *(_OWORD *)((char *)a1 + 1336) = 0; /*0x104f805d4*/
  *((_QWORD *)a1 + 173) = 0; /*0x104f805dc*/
  *((_DWORD *)a1 + 348) = 1065353216; /*0x104f805e7*/
  RBX::Time::nowFast(this: v6); /*0x104f805f1*/
  v60 = (char *)a1 + 1328; /*0x104f805fd*/
  *((_QWORD *)a1 + 175) = v7; /*0x104f80604*/
  *(_QWORD *)a1 = off_10C5E6138; /*0x104f80617*/
  *((_QWORD *)a1 + 22) = off_10C5E6650; /*0x104f80621*/
  *((_QWORD *)a1 + 23) = &off_10C5E6670; /*0x104f8062f*/
  *((_QWORD *)a1 + 40) = off_10C5E6700; /*0x104f8063f*/
  *((_QWORD *)a1 + 44) = &off_10C5E6770; /*0x104f8064d*/
  *((_QWORD *)a1 + 45) = off_10C5E67C0; /*0x104f8065b*/
  *((_QWORD *)a1 + 100) = off_10C5E67E8; /*0x104f80669*/
  *((_QWORD *)a1 + 101) = off_10C5E6820; /*0x104f80677*/
  *((_QWORD *)a1 + 132) = &off_10C5E6840; /*0x104f80685*/
  *((_QWORD *)a1 + 163) = &off_10C5E6958; /*0x104f80693*/
  *((_QWORD *)a1 + 165) = &off_10C5E6970; /*0x104f806a1*/
  *((_QWORD *)a1 + 166) = &off_10C5E6988; /*0x104f806af*/
  *((_QWORD *)a1 + 176) = off_10C5E69A0; /*0x104f806bc*/
  *(_OWORD *)((char *)a1 + 1416) = 0; /*0x104f806c7*/
  *(_OWORD *)((char *)a1 + 1432) = 0; /*0x104f806cf*/
  *(_OWORD *)((char *)a1 + 1448) = 0; /*0x104f806d7*/
  *(_OWORD *)((char *)a1 + 1464) = 0; /*0x104f806df*/
  *((_QWORD *)a1 + 185) = 0; /*0x104f806e9*/
  *((_QWORD *)a1 + 186) = 0; /*0x104f806f0*/
  *(_OWORD *)((char *)a1 + 1512) = 0; /*0x104f806f7*/
  *(_OWORD *)((char *)a1 + 1496) = 0; /*0x104f806ff*/
  *(_OWORD *)((char *)a1 + 1528) = 0; /*0x104f80707*/
  *(_OWORD *)((char *)a1 + 1544) = 0; /*0x104f8070f*/
  *((_QWORD *)a1 + 195) = RBX::Subsystem<RBX::PeerMonotonicClockManager,true>::startup<RBX::SubsystemDefaultFactory<RBX::PeerMonotonicClockManager>>(); /*0x104f8071c*/
  *((_QWORD *)a1 + 196) = 850045863; /*0x104f80723*/
  *((_QWORD *)a1 + 208) = 0; /*0x104f8072e*/
  *((_BYTE *)a1 + 1672) = 0; /*0x104f8073b*/
  v62 = (RBX::Workspace *)((char *)a1 + 1696); /*0x104f80748*/
  v63 = (RBX::Workspace *)((char *)a1 + 1704); /*0x104f80756*/
  v64 = (RBX::Workspace *)((char *)a1 + 1712); /*0x104f80764*/
  v65 = (RBX::Workspace *)((char *)a1 + 1720); /*0x104f80772*/
  v66 = (RBX::Workspace *)((char *)a1 + 1728); /*0x104f80780*/
  v67 = (RBX::Workspace *)((char *)a1 + 1736); /*0x104f8078e*/
  *(_OWORD *)((char *)a1 + 1576) = 0; /*0x104f807a0*/
  *(_OWORD *)((char *)a1 + 1592) = 0; /*0x104f807a8*/
  *(_OWORD *)((char *)a1 + 1608) = 0; /*0x104f807b0*/
  *(_OWORD *)((char *)a1 + 1624) = 0; /*0x104f807b8*/
  *((_BYTE *)a1 + 1640) = 0; /*0x104f807c0*/
  *((_OWORD *)a1 + 106) = 0; /*0x104f807c6*/
  *((_OWORD *)a1 + 107) = 0; /*0x104f807ce*/
  *((_OWORD *)a1 + 108) = 0; /*0x104f807d6*/
  *((_OWORD *)a1 + 109) = 0; /*0x104f807de*/
  *((_OWORD *)a1 + 110) = 0; /*0x104f807e6*/
  *((_OWORD *)a1 + 111) = 0; /*0x104f807ee*/
  *((_OWORD *)a1 + 112) = 0; /*0x104f807f6*/
  v69 = 0; /*0x104f80805*/
  v68 = 0; /*0x104f8080a*/
  RBX::detail::DenseHashTable<RBX::SignalPair,std::pair<RBX::SignalPair,RBX::TouchStateManager>,std::pair<RBX::SignalPair const,RBX::TouchStateManager>,RBX::detail::ItemInterfaceMap<RBX::SignalPair,RBX::TouchStateManager>,RBX::Hash<RBX::SignalPair>,std::equal_to<RBX::SignalPair>>::DenseHashTable( /*0x104f80813*/
    a1: (char *)a1 + 1808,
    a2: &v68,
    a3: 0);
  v9 = *((std::__shared_weak_count **)&v69 + 1); /*0x104f80818*/
  if ( *((_QWORD *)&v69 + 1) != 0 /*0x104f80834*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v69 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x104f8083c*/
    std::__shared_weak_count::__release_weak(this: v9); /*0x104f80842*/
  }
  v61 = (char *)a1 + 1808; /*0x104f80847*/
  v10 = *((std::__shared_weak_count **)&v68 + 1); /*0x104f8084e*/
  if ( *((_QWORD *)&v68 + 1) != 0 /*0x104f8086a*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v68 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x104f80872*/
    std::__shared_weak_count::__release_weak(this: v10); /*0x104f80878*/
  }
  DefaultArena = RSL::Arena::getDefaultArena(this: v8); /*0x104f8087d*/
  *(_OWORD *)((char *)a1 + 1880) = 0; /*0x104f80886*/
  *((_QWORD *)a1 + 237) = 0; /*0x104f8088e*/
  *((_QWORD *)a1 + 238) = DefaultArena; /*0x104f80899*/
  v72 = (RBX::Physics::ConvexDecompVisualizer **)((char *)a1 + 1920); /*0x104f808a7*/
  *(_OWORD *)((char *)a1 + 1912) = 0; /*0x104f808ab*/
  v12 = operator new(a1: 0x40u); /*0x104f808bd*/
  v14 = RSL::Arena::getDefaultArena(this: v13); /*0x104f808c7*/
  *(_OWORD *)v12 = 0; /*0x104f808d0*/
  *(_QWORD *)(v12 + 16) = 0; /*0x104f808d9*/
  *(_QWORD *)(v12 + 24) = v14; /*0x104f808de*/
  v16 = RSL::Arena::getDefaultArena(this: v15); /*0x104f808e3*/
  *(_OWORD *)(v12 + 32) = 0; /*0x104f808ec*/
  *(_QWORD *)(v12 + 48) = 0; /*0x104f808f3*/
  *(_QWORD *)(v12 + 56) = v16; /*0x104f808f8*/
  v59 = (char *)a1 + 1928; /*0x104f808fd*/
  std::shared_ptr<RBX::IAdornableCollector>::shared_ptr[abi:ne200100]<RBX::IAdornableCollector,0>( /*0x104f8090a*/
    a1: (char *)a1 + 1928,
    a2: v12);
  *(_OWORD *)((char *)a1 + 1992) = 0; /*0x104f80913*/
  *(_OWORD *)((char *)a1 + 1976) = 0; /*0x104f8091b*/
  *(_OWORD *)((char *)a1 + 1960) = 0; /*0x104f80923*/
  *(_OWORD *)((char *)a1 + 1944) = 0; /*0x104f8092b*/
  *((_QWORD *)a1 + 251) = 0; /*0x104f80933*/
  *((_QWORD *)a1 + 252) = 0xFFEFFFFFFFFFFFFFLL; /*0x104f80948*/
  *(_OWORD *)((char *)a1 + 2024) = 0; /*0x104f8094f*/
  *((_QWORD *)a1 + 255) = a3; /*0x104f80957*/
  *((_BYTE *)a1 + 2048) = 0; /*0x104f8095e*/
  *(_OWORD *)((char *)a1 + 2056) = 0; /*0x104f80965*/
  *(_OWORD *)((char *)a1 + 2072) = 0; /*0x104f8096d*/
  *(_OWORD *)((char *)a1 + 2088) = 0; /*0x104f80975*/
  v17 = (RBX::VerbContainer *)operator new(a1: 0x60u); /*0x104f80987*/
  RBX::VerbContainer::VerbContainer(this: v17, a2: nullptr); /*0x104f8098f*/
  *((_QWORD *)a1 + 263) = v17; /*0x104f80994*/
  *((_DWORD *)a1 + 528) = 0x1000000; /*0x104f8099b*/
  *(_OWORD *)((char *)a1 + 2120) = 0; /*0x104f809a8*/
  *(_OWORD *)((char *)a1 + 2136) = 0; /*0x104f809af*/
  *(_OWORD *)((char *)a1 + 2152) = 0; /*0x104f809b6*/
  *(_OWORD *)((char *)a1 + 2168) = 0; /*0x104f809bd*/
  *(_OWORD *)((char *)a1 + 2184) = 0; /*0x104f809c4*/
  *(_OWORD *)((char *)a1 + 2200) = 0; /*0x104f809cb*/
  *((_DWORD *)a1 + 554) = 1065353216; /*0x104f809d2*/
  *((_OWORD *)a1 + 139) = 0; /*0x104f809dc*/
  *((_OWORD *)a1 + 140) = 0; /*0x104f809e3*/
  *((_OWORD *)a1 + 141) = 0; /*0x104f809ea*/
  *((_WORD *)a1 + 1136) = 0; /*0x104f809f1*/
  *((_BYTE *)a1 + 2274) = 1; /*0x104f809fc*/
  v70 = (char *)a1 + 2136; /*0x104f80a17*/
  *((double *)a1 + 285) = 1.0 / (double)(int)DFInt::PhysicsEMAInverseSmoothingFactor; /*0x104f80a2a*/
  *((_OWORD *)a1 + 143) = 0; /*0x104f80a32*/
  *((_QWORD *)a1 + 288) = 0; /*0x104f80a39*/
  *((_BYTE *)a1 + 2312) = 1; /*0x104f80a44*/
  *((_OWORD *)a1 + 145) = 0; /*0x104f80a4a*/
  *((_OWORD *)a1 + 146) = 0; /*0x104f80a51*/
  *((_OWORD *)a1 + 147) = 0; /*0x104f80a58*/
  *((_QWORD *)a1 + 296) = 0x400000000LL; /*0x104f80a69*/
  v71 = (char *)a1 + 2376; /*0x104f80a77*/
  *(_OWORD *)((char *)a1 + 2376) = 0; /*0x104f80a7b*/
  RBX::WorkspaceSynchHelper::WorkspaceSynchHelper( /*0x104f80a93*/
    this: (RBX::Workspace *)((char *)a1 + 2392),
    a2: *((RBX::World **)a1 + 118));
  v19 = RSL::Arena::getDefaultArena(this: v18); /*0x104f80a98*/
  *((_OWORD *)a1 + 201) = 0; /*0x104f80aa1*/
  *((_QWORD *)a1 + 404) = 0; /*0x104f80aab*/
  *((_QWORD *)a1 + 405) = v19; /*0x104f80ab2*/
  *((_QWORD *)a1 + 406) = 0; /*0x104f80ab9*/
  RBX::EngineNetConfiguration::EngineNetConfiguration(a1: (char *)a1 + 3256, a2: 0); /*0x104f80ac9*/
  *((_OWORD *)a1 + 204) = 0; /*0x104f80ad2*/
  *((_DWORD *)a1 + 820) = 0; /*0x104f80ada*/
  *(_OWORD *)((char *)a1 + 3288) = 0; /*0x104f80aeb*/
  *(_OWORD *)((char *)a1 + 3304) = 0; /*0x104f80af3*/
  *(_OWORD *)((char *)a1 + 3313) = 0; /*0x104f80afb*/
  *((_QWORD *)a1 + 417) = RBX::Subsystem<RBX::Profiler::ProfileTelemetry,false>::startup<RBX::SubsystemDefaultFactory<RBX::Profiler::ProfileTelemetry>>(a1: v20); /*0x104f80b08*/
  v73 = (RBX::Workspace *)((char *)a1 + 3344); /*0x104f80b16*/
  *((_OWORD *)a1 + 209) = 0; /*0x104f80b1e*/
  *((_OWORD *)a1 + 210) = 0; /*0x104f80b26*/
  RBX::Creatable::createWithEngineContext<RBX::Camera>(a1: &v68, a2: *((_QWORD *)a1 + 11) & 0xFFFFFFFFFFFFFFF8LL); /*0x104f80b3d*/
  std::shared_ptr<RBX::Camera>::operator=[abi:ne200100](a1: v70, a2: &v68); /*0x104f80b53*/
  v21 = *((std::__shared_weak_count **)&v68 + 1); /*0x104f80b58*/
  if ( *((_QWORD *)&v68 + 1) != 0 /*0x104f80b71*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v68 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(a1: v21); /*0x104f80b79*/
    std::__shared_weak_count::__release_weak(this: v21); /*0x104f80b7f*/
  }
  if ( DFFlag::PerfDataServerAuthorityMode == 1 )
  {
    v22 = *((_QWORD *)a1 + 417); /*0x104f80b8d*/
    v23 = v22 != 0 ? *(RBX::Profiler::ProfileTelemetry **)(v22 + 24) : nullptr;
    ProfileSignal = RBX::Profiler::ProfileTelemetry::getProfileSignal(this: v23); /*0x104f80ba1*/
    v75[0] = a1; /*0x104f80baa*/
    rbx::direct_signal<void ()(RBX::Profiler::ProfileSignalParams &)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_1>( /*0x104f80bb7*/
      a1: &v68,
      a2: ProfileSignal);
    rbx::signals::scoped_connection::operator=(this: v73); /*0x104f80bc7*/
    v25 = (void *)v68; /*0x104f80bcc*/
    if ( (_QWORD)v68 != 0 && _InterlockedDecrement((volatile signed __int32 *)(v68 + 4)) == 0 ) /*0x104f80bdc*/
      rbx::signals::slot_base::operator delete(a1: v25); /*0x104f80bde*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v68, a2: "Workspace"); /*0x104f80bf1*/
  RBX::Instance::setName(a1, a2: &v68); /*0x104f80c00*/
  if ( (v68 & 1) != 0 ) /*0x104f80c0c*/
    operator delete(a1: (void *)v69); /*0x104f80c15*/
  if ( (unsigned __int8)FLog::GuiTargetLifetime >= 6u && BYTE1(FLog::GuiTargetLifetime) >= 3u )
    FLog::FastLog(
      a1: *(_QWORD *)&FLog::GuiTargetLifetime,
      a2: qword_10D7F3AC0,
      a3: "[FLog::GuiTargetLifetime] Workspace created: %p",
      a1);
  *((_BYTE *)a1 + 952) = 0; /*0x104f80c4d*/
  v68 = (unsigned int)FInt::SimWorldTaskQueueParallelTasks; /*0x104f80c77*/
  LOWORD(v69) = 1; /*0x104f80c7a*/
  *(_OWORD *)v77 = 0; /*0x104f80c89*/
  RBX::TaskScheduler::createTaskQueue(a1: v75, a2: "WorkspaceTaskQueue", a3: 18, a4: v77, a5: 7); /*0x104f80ca3*/
  std::shared_ptr<RBX::TaskQueue>::operator=[abi:ne200100](a1: v71, a2: v75); /*0x104f80cb3*/
  v26 = v75[1]; /*0x104f80cb8*/
  if ( v75[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v75[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f80cd1*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v26 + 16LL))(a1: v26); /*0x104f80cd9*/
    std::__shared_weak_count::__release_weak(this: v26); /*0x104f80cdf*/
  }
  v27 = (std::__shared_weak_count *)v77[1]; /*0x104f80ce4*/
  if ( v77[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v77[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f80cfd*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v27 + 16LL))(a1: v27); /*0x104f80d05*/
    std::__shared_weak_count::__release_weak(this: v27); /*0x104f80d0b*/
  }
  v28 = *((_QWORD *)a1 + 118); /*0x104f80d10*/
  v29 = *((_QWORD *)a1 + 298); /*0x104f80d17*/
  v58 = *(_OWORD *)((char *)a1 + 2376); /*0x104f80d26*/
  if ( v29 != 0 ) /*0x104f80d31*/
    _InterlockedIncrement64((volatile signed __int64 *)(v29 + 8)); /*0x104f80d33*/
  std::shared_ptr<RBX::TaskQueue>::operator=[abi:ne200100](a1: v28 + 1008, a2: &v58); /*0x104f80d49*/
  v31 = *((std::__shared_weak_count **)&v58 + 1); /*0x104f80d4e*/
  if ( *((_QWORD *)&v58 + 1) != 0 /*0x104f80d67*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v58 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v31 + 16LL))(a1: v31); /*0x104f80d6f*/
    std::__shared_weak_count::__release_weak(this: v31); /*0x104f80d75*/
  }
  RBX::World::createWorldInterpolator(this: *((RBX::World **)a1 + 118), a2: v30); /*0x104f80d81*/
  *(_QWORD *)(*((_QWORD *)a1 + 118) + 184LL) = v60; /*0x104f80d94*/
  v32 = (RBX::Constraints::GizmoManager *)operator new(a1: 0x1430u); /*0x104f80da5*/
  RBX::Constraints::GizmoManager::GizmoManager(this: v32, a2: a1); /*0x104f80dae*/
  *((_QWORD *)a1 + 272) = v32; /*0x104f80db3*/
  if ( FFlag::UseAdornBasedCDDebugVis == 1 ) /*0x104f80dc1*/
  {
    v33 = (RBX::Physics::ConvexDecompVisualizer *)operator new(a1: 0x30u); /*0x104f80dcd*/
    RBX::Physics::ConvexDecompVisualizer::ConvexDecompVisualizer(this: v33); /*0x104f80dd3*/
    v75[0] = nullptr; /*0x104f80dd8*/
    v34 = *v72; /*0x104f80de4*/
    *v72 = v33; /*0x104f80de7*/
    if ( v34 != nullptr ) /*0x104f80ded*/
    {
      std::default_delete<RBX::Physics::ConvexDecompVisualizer>::operator()[abi:ne200100](a1: v72); /*0x104f80df3*/
      v35 = v75[0]; /*0x104f80df8*/
      v75[0] = nullptr; /*0x104f80dfc*/
      if ( v35 != nullptr ) /*0x104f80e07*/
        std::default_delete<RBX::Physics::ConvexDecompVisualizer>::operator()[abi:ne200100](a1: v75); /*0x104f80e0d*/
    }
  }
  if ( DFFlag::FluidForcesSwitchToThreePhaseRollout == 1 ) /*0x104f80e19*/
  {
    v36 = *((RBX::World **)a1 + 118); /*0x104f80e1b*/
    if ( DFFlag::FluidForcesThreePhaseRolloutProperty == 1 && *((_DWORD *)a1 + 292) == 1 ) /*0x104f80e34*/
      v37 = 1; /*0x104f80e5c*/
    else
      v37 = DFFlag::FluidForcesDefaultEnabled; /*0x104f80e38*/
  }
  else
  {
    if ( *((_DWORD *)a1 + 292) != 0 ) /*0x104f80e47*/
      goto LABEL_44; /*0x104f80e47*/
    v36 = *((RBX::World **)a1 + 118); /*0x104f80e49*/
    v37 = FInt::SimDefaultFluidForceEnabled != 0; /*0x104f80e57*/
  }
  RBX::World::setEnableFluidForces(this: v36, a2: v37); /*0x104f80e61*/
LABEL_44:
  v38 = *((_DWORD *)a1 + 308); /*0x104f80e66*/
  if ( v38 != 0 ) /*0x104f80e7d*/
    v39 = v38 == 1; /*0x104f80e87*/
  else
    v39 = FFlag::DebugCLI122361Alpha; /*0x104f80e7f*/
  RBX::World::setEnablePrimalSolver(this: *((RBX::World **)a1 + 118), a2: v39 & 1); /*0x104f80e8d*/
  if ( FFlag::UseFixedSimulationThreePhaseRolloutProperty != 0 || FFlag::UseFixedSimulationDefaultEnabled == 1 ) /*0x104f80ea2*/
  {
    v40 = *((_QWORD *)a1 + 118); /*0x104f80ea4*/
    *(_BYTE *)(v40 + 553) = RBX::Workspace::getUseFixedSimulationEnabled(this: a1); /*0x104f80eb3*/
  }
  v41 = *((_QWORD *)a1 + 118); /*0x104f80eba*/
  v75[0] = (std::__shared_weak_count *)RBX::Workspace::handleNetworkOwnershipUnitMovedWorldSignal; /*0x104f80ecc*/
  v75[1] = nullptr; /*0x104f80ecf*/
  v76 = a1; /*0x104f80ed7*/
  rbx::signal<void ()(RBX::Primitive *)>::connect<std::__bind<void (RBX::Workspace::*)(RBX::Primitive *),RBX::Workspace*,std::placeholders::__ph<1> const&>>( /*0x104f80ee3*/
    a1: v77,
    a2: v41 + 40);
  rbx::signals::scoped_connection::operator=(this: v62); /*0x104f80ef3*/
  v42 = v77[0]; /*0x104f80ef8*/
  if ( v77[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v77[0] + 1) == 0 ) /*0x104f80f05*/
    rbx::signals::slot_base::operator delete(a1: v42); /*0x104f80f07*/
  v43 = *((_QWORD *)a1 + 118); /*0x104f80f0c*/
  v75[0] = (std::__shared_weak_count *)RBX::Workspace::handleNetworkOwnershipUnitAddedWorldSignal; /*0x104f80f1e*/
  v75[1] = nullptr; /*0x104f80f21*/
  v76 = a1; /*0x104f80f29*/
  rbx::signal<void ()(RBX::Primitive *,bool,bool)>::connect<std::__bind<void (RBX::Workspace::*)(RBX::Primitive *,bool,bool),RBX::Workspace*,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&,std::placeholders::__ph<3> const&>>( /*0x104f80f35*/
    a1: v77,
    a2: v43 + 48);
  rbx::signals::scoped_connection::operator=(this: v63); /*0x104f80f45*/
  v44 = v77[0]; /*0x104f80f4a*/
  if ( v77[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v77[0] + 1) == 0 ) /*0x104f80f57*/
    rbx::signals::slot_base::operator delete(a1: v44); /*0x104f80f59*/
  v45 = *((_QWORD *)a1 + 118); /*0x104f80f5e*/
  v75[0] = (std::__shared_weak_count *)RBX::Workspace::handleNetworkOwnershipUnitRemovingWorldSignal; /*0x104f80f70*/
  v75[1] = nullptr; /*0x104f80f73*/
  v76 = a1; /*0x104f80f7b*/
  rbx::signal<void ()(RBX::Primitive *,bool)>::connect<std::__bind<void (RBX::Workspace::*)(RBX::Primitive *,bool),RBX::Workspace*,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>( /*0x104f80f87*/
    a1: v77,
    a2: v45 + 56);
  rbx::signals::scoped_connection::operator=(this: v64); /*0x104f80f97*/
  v46 = v77[0]; /*0x104f80f9c*/
  if ( v77[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v77[0] + 1) == 0 ) /*0x104f80fa9*/
    rbx::signals::slot_base::operator delete(a1: v46); /*0x104f80fab*/
  v47 = FFlag::SAuthWorkspaceFlagged; /*0x104f80fbe*/
  if ( (((unsigned __int8)FFlag::SAuthWorkspaceFlagged | (unsigned __int8)FFlag::DebugHashTableMetrics) & 1) != 0 /*0x104f80fd6*/
    || FFlag::NextGenReplicatorEnabledRead == 1 )
  {
    v48 = *((_QWORD *)a1 + 118) + 72LL; /*0x104f80fdf*/
    v77[0] = a1; /*0x104f80fe7*/
    rbx::signal<void ()(int)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_2>( /*0x104f80fee*/
      a1: v75,
      a2: v48);
    rbx::signals::scoped_connection::operator=(this: v66); /*0x104f80ffe*/
    v49 = v75[0]; /*0x104f81003*/
    if ( v75[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v75[0] + 1) == 0 ) /*0x104f81010*/
      rbx::signals::slot_base::operator delete(a1: v49); /*0x104f81012*/
    v47 = FFlag::SAuthWorkspaceFlagged; /*0x104f81017*/
  }
  if ( (v47 & 1) != 0 ) /*0x104f8101c*/
  {
    v50 = *((_QWORD *)a1 + 118) + 80LL; /*0x104f81025*/
    v77[0] = a1; /*0x104f8102d*/
    rbx::signal<void ()(RBX::Primitive *)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_3>( /*0x104f81034*/
      a1: v75,
      a2: v50);
    rbx::signals::scoped_connection::operator=(this: v67); /*0x104f81044*/
  }
  else
  {
    RBX::EngineNetConfiguration::EngineNetConfiguration(a1: v75, a2: 0); /*0x104f81051*/
    if ( FFlag::DebugHashTableMetrics == 0 ) /*0x104f8105b*/
    {
      if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x104f81174*/
      {
        if ( ((__int64)v75[0] & 8) == 0 && FFlag::NextGenReplicatorEnabledWrite == 0 && ((__int64)v75[0] & 1) == 0 ) /*0x104f81194*/
          goto LABEL_72; /*0x104f81194*/
      }
      else if ( FFlag::NextGenReplicatorEnabledRead == 0 || FFlag::NextGenReplicatorEnabledWrite != 1 ) /*0x104f811b9*/
      {
        goto LABEL_72; /*0x104f811b9*/
      }
    }
    v51 = *((_QWORD *)a1 + 118) + 80LL; /*0x104f81068*/
    v77[0] = a1; /*0x104f81070*/
    rbx::signal<void ()(RBX::Primitive *)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_4>( /*0x104f81077*/
      a1: v75,
      a2: v51);
    rbx::signals::scoped_connection::operator=(this: v67); /*0x104f81087*/
  }
  v52 = v75[0]; /*0x104f8108c*/
  if ( v75[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v75[0] + 1) == 0 ) /*0x104f81099*/
    rbx::signals::slot_base::operator delete(a1: v52); /*0x104f8109b*/
LABEL_72:
  v53 = *((_QWORD *)a1 + 118) + 64LL; /*0x104f810a0*/
  v77[0] = a1; /*0x104f810af*/
  rbx::signal<void ()(RBX::Primitive *,bool)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_5>( /*0x104f810b6*/
    a1: v75,
    a2: v53);
  rbx::signals::scoped_connection::operator=(this: v65); /*0x104f810c6*/
  v54 = v75[0]; /*0x104f810cb*/
  if ( v75[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v75[0] + 1) == 0 ) /*0x104f810d8*/
    rbx::signals::slot_base::operator delete(a1: v54); /*0x104f810da*/
  if ( FFlag::SimTurbulentFlow == 1 ) /*0x104f810e9*/
    RBX::World::setAirTurbulenceIntensity( /*0x104f810fa*/
      this: *((RBX::FluidModels::FixedProfileFluid ***)a1 + 118),
      a2: *((float *)a1 + 286));
  v55 = *((_QWORD *)a1 + 2); /*0x104f810ff*/
  *(_OWORD *)v75 = *(_OWORD *)((char *)a1 + 8); /*0x104f81108*/
  if ( v55 != 0 ) /*0x104f81110*/
    _InterlockedIncrement64((volatile signed __int64 *)(v55 + 16)); /*0x104f81112*/
  v56 = RBX::CorePhysicsSettings::singleton(this: v54); /*0x104f81117*/
  rbx::signal<void ()(RBX::Reflection::PropertyDescriptor const*)>::connect<RBX::Workspace::Workspace(RBX::ForceConstructionInCreatable &,RBX::IDataState *,bool)::$_0 &>( /*0x104f8112b*/
    a1: v77,
    a2: v56 + 32,
    a3: v75);
  rbx::signals::scoped_connection::operator=(this: (RBX::Workspace *)((char *)a1 + 3320)); /*0x104f81137*/
  v57 = v77[0]; /*0x104f8113c*/
  if ( v77[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v77[0] + 1) == 0 ) /*0x104f81149*/
    rbx::signals::slot_base::operator delete(a1: v57); /*0x104f8114b*/
  if ( v75[1] != nullptr ) /*0x104f81157*/
    std::__shared_weak_count::__release_weak(this: v75[1]); /*0x104f81159*/
}

// Address: 0x104f817e4 | Name: __ZN3RBX9WorkspaceD2Ev
void __fastcall RBX::Workspace::~Workspace(RBX::Workspace *this, __int64 *a2)
{
  __int64 v2; // rax
  __int64 v4; // rax
  void *v5; // r15
  __int64 v6; // rsi
  std::__shared_weak_count *v7; // rdi
  __int64 v8; // rdi
  std::__shared_weak_count *v9; // rdi
  std::__shared_weak_count *v10; // rdi
  __int64 v11; // rdi
  __int64 v12; // rsi
  void *v13; // rdi
  __int64 v14; // rdi
  _QWORD v15[6]; // [rsp+0h] [rbp-30h] BYREF

  v15[0] = v2; /*0x104f817f1*/
  v4 = *a2; /*0x104f817f8*/
  this->... /* +0 */= *a2; /*0x104f817fb*/
  *((_QWORD *)this + 22) /* +176: NO 2022 FIELD */ = off_10C5E6650; /*0x104f8180c*/
  *(_QWORD *)((char *)this + *(_QWORD *)(v4 - 24)) = a2[19]; /*0x104f8181e*/
  *((_QWORD *)this + 23) /* +184: NO 2022 FIELD */ = &off_10C5E6670; /*0x104f81829*/
  *((_QWORD *)this + 40) /* +320: NO 2022 FIELD */ = off_10C5E6700; /*0x104f81837*/
  *((_QWORD *)this + 44) /* +352: NO 2022 FIELD */ = a2[20]; /*0x104f81845*/
  *((_QWORD *)this + 45) /* +360: NO 2022 FIELD */ = off_10C5E67C0; /*0x104f81853*/
  this->..tempJointInstances /* +800 */ = off_10C5E67E8; /*0x104f81861*/
  *((_QWORD *)this + 101) /* +808: NO 2022 FIELD */ = off_10C5E6820; /*0x104f8186f*/
  this->networkOwnershipUnitMovedSignal..slots /* +1056 */ = &off_10C5E6840; /*0x104f8187d*/
  this->pendingSendTouches.impl.empty_key.second /* +1304 */ = &off_10C5E6958; /*0x104f8188b*/
  *((_QWORD *)this + 165) /* +1320 likely pendingSendTouches.impl.hasher -- UNVERIFIED */ = &off_10C5E6970; /*0x104f81899*/
  this->allWorlds.array.data /* +1328 */ = &off_10C5E6988; /*0x104f818a7*/
  this->statsItem.._Rep /* +1408 */ = off_10C5E69A0; /*0x104f818b5*/
  v5 = *((void **)this + 272); /*0x104f818bc*/
  if ( v5 != nullptr ) /*0x104f818c6*/
  {
    RBX::Constraints::GizmoManager::~GizmoManager(this: *((RBX::Constraints::GizmoManager **)this + 272)); /*0x104f818cb*/
    operator delete(a1: v5); /*0x104f818d3*/
  }
  if ( *((_QWORD *)this + 239) /* +1912 likely currentCameraChangedSignal..head.px -- UNVERIFIED */ != 0 ) /*0x104f818e0*/
    RBX::Workspace::deleteConvexDecompVisualizer(this); /*0x104f818e5*/
  if ( (unsigned __int8)FLog::GuiTargetLifetime >= 6u && BYTE1(FLog::GuiTargetLifetime) >= 3u )
    FLog::FastLog(
      a1: *(_QWORD *)&FLog::GuiTargetLifetime,
      a2: qword_10D7F3AC0,
      a3: "[FLog::GuiTargetLifetime] Workspace destroyed: %p",
      this);
  v6 = *((_QWORD *)this + 421) /* +3368: NO 2022 FIELD */; /*0x104f8191d*/
  *((_QWORD *)this + 421) /* +3368: NO 2022 FIELD */ = 0; /*0x104f81924*/
  if ( v6 != 0 ) /*0x104f81932*/
    std::default_delete<RBX::Workspace::CollisionSummaryState>::operator()[abi:ne200100](a1: (char *)this + 3368 /* +3368: NO 2022 FIELD */); /*0x104f8193b*/
  v7 = *((std::__shared_weak_count **)this + 420); /*0x104f81940*/
  if ( v7 != nullptr ) /*0x104f8194a*/
    std::__shared_weak_count::__release_weak(this: v7); /*0x104f8194c*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Workspace *)((char *)this + 3344 /* +3344: NO 2022 FIELD */)); /*0x104f81958*/
  v8 = *((_QWORD *)this + 417) /* +3336: NO 2022 FIELD */; /*0x104f8195d*/
  if ( v8 != 0 ) /*0x104f81967*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x104f8196c*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Workspace *)((char *)this + 3320 /* +3320: NO 2022 FIELD */)); /*0x104f81976*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Workspace *)((char *)this + 3312 /* +3312: NO 2022 FIELD */)); /*0x104f81982*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 413); /*0x104f8198e*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 412); /*0x104f8199a*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 411); /*0x104f819a6*/
  operator delete(a1: *((void **)this + 408)); /*0x104f819b2*/
  v15[0] = (char *)this + 3216 /* +3216: NO 2022 FIELD */; /*0x104f819c2*/
  std::vector<std::pair<std::weak_ptr<RBX::BasePart>,bool>,RSL::Detail::Allocator<std::pair<std::weak_ptr<RBX::BasePart>,bool>>>::__destroy_vector::operator()[abi:ne200100](a1: v15); /*0x104f819c5*/
  if ( (*((_BYTE *)this + 2440) /* +2440: NO 2022 FIELD */ & 1) == 0 ) /*0x104f819d2*/
    operator delete(a1: *((void **)this + 306)); /*0x104f819db*/
  RBX::DenseMap<RBX::Guid,RBX::SmallVector<RBX::PhysicsSynchPackage,1u>,RBX::DenseMapInfo<RBX::Guid,void>,RBX::detail::DenseMapPair<RBX::Guid,RBX::SmallVector<RBX::PhysicsSynchPackage,1u>>>::~DenseMap(a1: (char *)this + 2416 /* +2416: NO 2022 FIELD */); /*0x104f819e7*/
  std::shared_ptr<RBX::TaskQueue>::~shared_ptr[abi:ne200100](a1: (char *)this + 2376 /* +2376: NO 2022 FIELD */); /*0x104f819f3*/
  v9 = *((std::__shared_weak_count **)this + 295); /*0x104f819f8*/
  if ( v9 != nullptr ) /*0x104f81a02*/
    std::__shared_weak_count::__release_weak(this: v9); /*0x104f81a04*/
  v10 = *((std::__shared_weak_count **)this + 293); /*0x104f81a09*/
  if ( v10 != nullptr ) /*0x104f81a13*/
    std::__shared_weak_count::__release_weak(this: v10); /*0x104f81a15*/
  std::shared_ptr<RBX::DataModelJob>::~shared_ptr[abi:ne200100](a1: (char *)this + 2320 /* +2320: NO 2022 FIELD */); /*0x104f81a21*/
  std::__hash_table<std::shared_ptr<RBX::PartOperation>,std::hash<std::shared_ptr<RBX::PartOperation>>,std::equal_to<std::shared_ptr<RBX::PartOperation>>,std::allocator<std::shared_ptr<RBX::PartOperation>>>::~__hash_table(a1: (char *)this + 2184 /* +2184: NO 2022 FIELD */); /*0x104f81a2d*/
  v15[0] = (char *)this + 2152 /* +2152: NO 2022 FIELD */; /*0x104f81a3d*/
  std::vector<std::shared_ptr<RBX::BasePart>>::__destroy_vector::operator()[abi:ne200100](a1: v15); /*0x104f81a40*/
  std::shared_ptr<RBX::Camera>::~shared_ptr[abi:ne200100](a1: (char *)this + 2136 /* +2136: NO 2022 FIELD */); /*0x104f81a4c*/
  std::shared_ptr<RBX::Camera>::~shared_ptr[abi:ne200100](a1: (char *)this + 2120 /* +2120: NO 2022 FIELD */); /*0x104f81a58*/
  v11 = *((_QWORD *)this + 263) /* +2104: NO 2022 FIELD */; /*0x104f81a5d*/
  *((_QWORD *)this + 263) /* +2104: NO 2022 FIELD */ = 0; /*0x104f81a64*/
  if ( v11 != 0 ) /*0x104f81a72*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v11 + 8LL))(a1: v11); /*0x104f81a77*/
  std::shared_ptr<RBX::InputObject>::~shared_ptr[abi:ne200100](a1: (char *)this + 2088 /* +2088: NO 2022 FIELD */); /*0x104f81a81*/
  std::shared_ptr<RBX::MouseCommand>::~shared_ptr[abi:ne200100](a1: (char *)this + 2072 /* +2072: NO 2022 FIELD */); /*0x104f81a8d*/
  std::shared_ptr<RBX::MouseCommand>::~shared_ptr[abi:ne200100](a1: (char *)this + 2056 /* +2056: NO 2022 FIELD */); /*0x104f81a99*/
  std::shared_ptr<RBX::Instance>::~shared_ptr[abi:ne200100](a1: (char *)this + 2024 /* +2024: NO 2022 FIELD */); /*0x104f81aa5*/
  std::shared_ptr<RBX::EditableAnalytics>::~shared_ptr[abi:ne200100](a1: (char *)this + 1976 /* +1976: NO 2022 FIELD */); /*0x104f81ab1*/
  std::shared_ptr<RBX::CSG3::GeometryAnalytics>::~shared_ptr[abi:ne200100](a1: (char *)this + 1960 /* +1960 = currentMouseCommandChanged (rbx::signal<void __cdecl(std::string const &)>, 24B) -- SIZE CONFLICT, see --verify */); /*0x104f81abd*/
  std::shared_ptr<RBX::PhysicsAnalytics>::~shared_ptr[abi:ne200100](a1: (char *)this + 1944 /* +1944: NO 2022 FIELD */); /*0x104f81ac9*/
  std::shared_ptr<RBX::IAdornableCollector>::~shared_ptr[abi:ne200100](a1: (char *)this + 1928 /* +1928: NO 2022 FIELD */); /*0x104f81ad5*/
  v12 = this->currentCameraChangedSignal..slots /* +1920 */; /*0x104f81ada*/
  this->currentCameraChangedSignal..slots /* +1920 */ = 0; /*0x104f81ae1*/
  if ( v12 != 0 ) /*0x104f81aef*/
    std::default_delete<RBX::Physics::ConvexDecompVisualizer>::operator()[abi:ne200100](a1: (char *)this + 1920 /* +1920 = currentCameraChangedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) */); /*0x104f81af8*/
  v15[0] = (char *)this + 1880 /* +1880 = taskQueue.._Rep (std::_Ref_count_base *, 8B) -- SIZE CONFLICT, see --verify */; /*0x104f81b08*/
  std::vector<RBX::WorldModel *,RSL::Detail::Allocator<RBX::WorldModel *>>::__destroy_vector::operator()[abi:ne200100](a1: v15); /*0x104f81b0e*/
  std::shared_ptr<RBX::BasePart>::~shared_ptr[abi:ne200100](a1: (char *)this + 1856 /* +1856 = lastSurfaceGUI.._Rep (std::_Ref_count_base *, 8B) -- SIZE CONFLICT, see --verify */); /*0x104f81b28*/
  std::shared_ptr<RBX::BasePart>::~shared_ptr[abi:ne200100](a1: (char *)this + 1840 /* +1840 = allowThirdPartySales (bool, 1B) -- SIZE CONFLICT, see --verify */); /*0x104f81b30*/
  v15[0] = (char *)this + 1808 /* +1808 = meshPartHeadsAndAccessories (RBX::Workspace::MeshPartHeadsAndAccessories, 4B) -- SIZE CONFLICT, see --verify */; /*0x104f81b35*/
  std::vector<std::pair<RBX::SignalPair,RBX::TouchStateManager>>::__destroy_vector::operator()[abi:ne200100](a1: v15); /*0x104f81b3b*/
  v15[0] = (char *)this + 1784 /* +1784 = interpolationThrottlingMode (RBX::Workspace::InterpolationThrottlingMode, 4B) -- SIZE CONFLICT, see --verify */; /*0x104f81b47*/
  std::vector<std::pair<RBX::SignalPair,std::pair<RBX::TouchEventType,bool>>>::__destroy_vector::operator()[abi:ne200100](a1: v15); /*0x104f81b4e*/
  v13 = *((void **)this + 220); /*0x104f81b53*/
  if ( v13 != nullptr ) /*0x104f81b5d*/
  {
    *((_QWORD *)this + 221) /* +1768 likely streamingMinRadius -- UNVERIFIED */ = v13; /*0x104f81b5f*/
    operator delete(a1: v13); /*0x104f81b66*/
  }
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Workspace *)((char *)this + 1752 /* +1752 = statsJoinAllTime (long double, 8B) -- SIZE CONFLICT, see --verify */)); /*0x104f81b72*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Workspace *)((char *)this + 1744 /* +1744 = statsXMLLoadTime (long double, 8B) -- SIZE CONFLICT, see --verify */)); /*0x104f81b7e*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Workspace *)((char *)this + 1736 /* +1736 = statsSyncHttpGetTime (long double, 8B) -- SIZE CONFLICT, see --verify */)); /*0x104f81b8a*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Workspace *)((char *)this + 1728 /* +1728 = distributedGameTime (long double, 8B) -- SIZE CONFLICT, see --verify */)); /*0x104f81b96*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Workspace *)((char *)this + 1720 /* +1720: NO 2022 FIELD */)); /*0x104f81ba2*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Workspace *)((char *)this + 1712 /* +1712: NO 2022 FIELD */)); /*0x104f81bae*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Workspace *)((char *)this + 1704 /* +1704: NO 2022 FIELD */)); /*0x104f81bba*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Workspace *)((char *)this + 1696 /* +1696: NO 2022 FIELD */)); /*0x104f81bc6*/
  std::mutex::~mutex(this: (RBX::Workspace *)((char *)this + 1568 /* +1568: NO 2022 FIELD */)); /*0x104f81bd2*/
  v14 = *((_QWORD *)this + 195) /* +1560: NO 2022 FIELD */; /*0x104f81bd7*/
  if ( v14 != 0 ) /*0x104f81be1*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x104f81be6*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 194); /*0x104f81bf7*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 193); /*0x104f81c03*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 192); /*0x104f81c0f*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 191); /*0x104f81c1b*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 190); /*0x104f81c27*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 189); /*0x104f81c33*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 188); /*0x104f81c3f*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 187); /*0x104f81c4b*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 186); /*0x104f81c57*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 185); /*0x104f81c63*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 184); /*0x104f81c76*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 183); /*0x104f81c7e*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 182); /*0x104f81c8a*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 181); /*0x104f81c96*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 180); /*0x104f81ca2*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 179); /*0x104f81cae*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 178); /*0x104f81cba*/
  this->allWorlds.array.data /* +1328 */ = &off_10C9F02C8; /*0x104f81cc6*/
  std::__hash_table<std::__hash_value_type<RBX::SignalPair,std::pair<RBX::Time,RBX::SystemAddress>>,std::__unordered_map_hasher<RBX::SignalPair,std::__hash_value_type<RBX::SignalPair,std::pair<RBX::Time,RBX::SystemAddress>>,RBX::Hash<RBX::SignalPair>,std::equal_to<RBX::SignalPair>,true>,std::__unordered_map_equal<RBX::SignalPair,std::__hash_value_type<RBX::SignalPair,std::pair<RBX::Time,RBX::SystemAddress>>,std::equal_to<RBX::SignalPair>,RBX::Hash<RBX::SignalPair>,true>,std::allocator<std::__hash_value_type<RBX::SignalPair,std::pair<RBX::Time,RBX::SystemAddress>>>>::~__hash_table(a1: (char *)this + 1360 /* +1360 = adornableCollector.._Rep (std::_Ref_count_base *, 8B) -- SIZE CONFLICT, see --verify */); /*0x104f81cd4*/
  v15[0] = (char *)this + 1336 /* +1336 = allWorlds.array.num (int, 4B) -- SIZE CONFLICT, see --verify */; /*0x104f81ce4*/
  std::vector<std::pair<RBX::Time,RBX::DenseHashMap<RBX::SignalPair,RBX::TouchStateManager,RBX::Hash<RBX::SignalPair>,std::equal_to<RBX::SignalPair>>>>::__destroy_vector::operator()[abi:ne200100](a1: v15); /*0x104f81ce7*/
  RBX::WorkspaceProp::~WorkspaceProp(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) */)); /*0x104f81cef*/
  RBX::WorldRoot::~WorldRoot(this); /*0x104f81cfe*/
}

// Address: 0x104f81d1e | Name: __ZN3RBX9Workspace28deleteConvexDecompVisualizerEv
void __fastcall RBX::Workspace::deleteConvexDecompVisualizer(RBX::Workspace *this)
{
  __int64 v2; // r14
  void *v3; // rdi

  v2 = this->currentCameraChangedSignal..head.px /* +1912 */; /*0x104f81d28*/
  if ( v2 != 0 ) /*0x104f81d32*/
  {
    v3 = *(void **)(v2 + 96); /*0x104f81d34*/
    if ( v3 != nullptr ) /*0x104f81d3b*/
    {
      *(_QWORD *)(v2 + 104) = v3; /*0x104f81d3d*/
      operator delete(a1: v3); /*0x104f81d41*/
    }
    boost::circular_buffer<RBX::DecompDebugVisualizer::DecompFrame,std::allocator<RBX::DecompDebugVisualizer::DecompFrame>>::destroy(a1: (void **)v2); /*0x104f81d49*/
    operator delete(a1: (void *)v2); /*0x104f81d51*/
  }
  this->currentCameraChangedSignal..head.px /* +1912 */ = 0; /*0x104f81d56*/
}

// Address: 0x104f81d66 | Name: __ZN3RBX9WorkspaceD1Ev
void __fastcall RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  RBX::Workspace::~Workspace(this, a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81d72*/
}

// Address: 0x104f81d78 | Name: __ZTv0_n32_N3RBX9WorkspaceD1Ev
void __fastcall `virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  RBX::Workspace::~Workspace( /*0x104f81d8b*/
    this: (RBX::Workspace *)((char *)this + *(_QWORD *)(*(_QWORD *)this  /* +0 likely ... -- UNVERIFIED */- 32LL)),
    a2: (__int64 *)&`VTT for'RBX::Workspace);
}

// Address: 0x104f81d90 | Name: __ZThn352_N3RBX9WorkspaceD1Ev
void __fastcall `non-virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  RBX::Workspace::~Workspace(this: (RBX::Workspace *)((char *)this - 352), a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81da3*/
}

// Address: 0x104f81da8 | Name: __ZThn360_N3RBX9WorkspaceD1Ev
void __fastcall `non-virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  RBX::Workspace::~Workspace(this: (RBX::Workspace *)((char *)this - 360), a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81dbb*/
}

// Address: 0x104f81dc0 | Name: __ZThn800_N3RBX9WorkspaceD1Ev
void __fastcall `non-virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  RBX::Workspace::~Workspace(this: (RBX::Workspace *)((char *)this - 800), a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81dd3*/
}

// Address: 0x104f81dd8 | Name: __ZThn808_N3RBX9WorkspaceD1Ev
void __fastcall `non-virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  RBX::Workspace::~Workspace(this: (RBX::Workspace *)((char *)this - 808), a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81deb*/
}

// Address: 0x104f81df0 | Name: __ZThn1408_N3RBX9WorkspaceD1Ev
void __fastcall `non-virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  RBX::Workspace::~Workspace(this: (RBX::Workspace *)((char *)this - 1408), a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81e03*/
}

// Address: 0x104f81e08 | Name: __ZN3RBX9WorkspaceD0Ev
void __fastcall RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  RBX::Workspace::~Workspace(this, a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81e18*/
  operator delete(a1: this); /*0x104f81e26*/
}

// Address: 0x104f81e2c | Name: __ZTv0_n32_N3RBX9WorkspaceD0Ev
void __fastcall `virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  RBX::Workspace *v1; // rbx

  v1 = (RBX::Workspace *)((char *)this + *(_QWORD *)(*(_QWORD *)this  /* +0 likely ... -- UNVERIFIED */- 32LL)); /*0x104f81e38*/
  RBX::Workspace::~Workspace(this: v1, a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81e46*/
  operator delete(a1: v1); /*0x104f81e54*/
}

// Address: 0x104f81e5a | Name: __ZThn352_N3RBX9WorkspaceD0Ev
void __fastcall `non-virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  char *v1; // rbx

  v1 = (char *)this - 352; /*0x104f81e63*/
  RBX::Workspace::~Workspace(this: (RBX::Workspace *)((char *)this - 352), a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81e74*/
  operator delete(a1: v1); /*0x104f81e82*/
}

// Address: 0x104f81e88 | Name: __ZThn360_N3RBX9WorkspaceD0Ev
void __fastcall `non-virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  char *v1; // rbx

  v1 = (char *)this - 360; /*0x104f81e91*/
  RBX::Workspace::~Workspace(this: (RBX::Workspace *)((char *)this - 360), a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81ea2*/
  operator delete(a1: v1); /*0x104f81eb0*/
}

// Address: 0x104f81eb6 | Name: __ZThn800_N3RBX9WorkspaceD0Ev
void __fastcall `non-virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  char *v1; // rbx

  v1 = (char *)this - 800; /*0x104f81ebf*/
  RBX::Workspace::~Workspace(this: (RBX::Workspace *)((char *)this - 800), a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81ed0*/
  operator delete(a1: v1); /*0x104f81ede*/
}

// Address: 0x104f81ee4 | Name: __ZThn808_N3RBX9WorkspaceD0Ev
void __fastcall `non-virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  char *v1; // rbx

  v1 = (char *)this - 808; /*0x104f81eed*/
  RBX::Workspace::~Workspace(this: (RBX::Workspace *)((char *)this - 808), a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81efe*/
  operator delete(a1: v1); /*0x104f81f0c*/
}

// Address: 0x104f81f12 | Name: __ZThn1408_N3RBX9WorkspaceD0Ev
void __fastcall `non-virtual thunk to'RBX::Workspace::~Workspace(RBX::Workspace *this)
{
  char *v1; // rbx

  v1 = (char *)this - 1408; /*0x104f81f1b*/
  RBX::Workspace::~Workspace(this: (RBX::Workspace *)((char *)this - 1408), a2: (__int64 *)&`VTT for'RBX::Workspace); /*0x104f81f2c*/
  operator delete(a1: v1); /*0x104f81f3a*/
}

// Address: 0x104f81f40 | Name: __ZN3RBX9Workspace15joinToOutsidersENSt3__110shared_ptrIKNS1_6vectorINS2_INS_8InstanceEEENS1_9allocatorIS5_EEEEEENS_29AdvArrowToolJointCreationModeE
__int64 __fastcall RBX::Workspace::joinToOutsiders(RBX::WorldRoot *a1, __int64 **a2, int a3)
{
  __int64 result; // rax
  __int64 v6[4]; // [rsp+0h] [rbp-60h] BYREF
  __int64 v7[4]; // [rsp+20h] [rbp-40h] BYREF
  __int64 *v8; // [rsp+40h] [rbp-20h] BYREF

  result = RBX::WorldRoot::reEnableWeldConstraints(this: a1); /*0x104f81f52*/
  if ( a3 != 2 ) /*0x104f81f5a*/
  {
    memset(v6, 0, 24); /*0x104f81f63*/
    memset(v7, 0, 24); /*0x104f81f74*/
    RBX::DragUtilities::instancesToParts(a1: *a2, a2: v6, a3: v7); /*0x104f81f81*/
    RBX::DragUtilities::joinToOutsiders(a1: v6, a2: 1); /*0x104f81f92*/
    v8 = v7; /*0x104f81f9b*/
    std::vector<std::weak_ptr<RBX::ModelInstance>>::__destroy_vector::operator()[abi:ne200100](a1: &v8); /*0x104f81f9e*/
    v7[0] = (__int64)v6; /*0x104f81fa7*/
    return std::vector<std::weak_ptr<RBX::BasePart>>::__destroy_vector::operator()[abi:ne200100](a1: v7); /*0x104f81faa*/
  }
  return result; /*0x104f81faf*/
}

// Address: 0x104f81fde | Name: __ZN3RBX9Workspace19unjoinFromOutsidersENSt3__110shared_ptrIKNS1_6vectorINS2_INS_8InstanceEEENS1_9allocatorIS5_EEEEEE
__int64 __fastcall RBX::Workspace::unjoinFromOutsiders(__int64 a1, __int64 **a2)
{
  __int64 v3[4]; // [rsp+0h] [rbp-60h] BYREF
  __int64 v4[4]; // [rsp+20h] [rbp-40h] BYREF
  __int64 *v5; // [rsp+40h] [rbp-20h] BYREF

  memset(v3, 0, 24); /*0x104f81ff2*/
  memset(v4, 0, 24); /*0x104f82003*/
  RBX::DragUtilities::instancesToParts(a1: *a2, a2: v3, a3: v4); /*0x104f82010*/
  RBX::DragUtilities::unJoinFromOutsiders(a1: (__int64)v3); /*0x104f8201c*/
  v5 = v4; /*0x104f82025*/
  std::vector<std::weak_ptr<RBX::ModelInstance>>::__destroy_vector::operator()[abi:ne200100](a1: &v5); /*0x104f82028*/
  v4[0] = (__int64)v3; /*0x104f82031*/
  return std::vector<std::weak_ptr<RBX::BasePart>>::__destroy_vector::operator()[abi:ne200100](a1: v4); /*0x104f82039*/
}

// Address: 0x104f82068 | Name: __ZNK3RBX9Workspace25computeExtentsWorldApproxEv
RBX::Workspace *__fastcall RBX::Workspace::computeExtentsWorldApprox(RBX::Workspace *this, __int64 a2)
{
  _QWORD *v4; // r14
  __int64 v5; // r15
  __int64 v6; // rax
  _BYTE v8[48]; // [rsp+0h] [rbp-30h] BYREF

  this->... /* +0 */= 0x7F7FFFFF7F7FFFFFLL; /*0x104f82083*/
  *((_DWORD *)this + 2) /* +8: NO 2022 FIELD */ = 2139095039; /*0x104f82087*/
  *(_QWORD *)((char *)this + 12 /* +12: NO 2022 FIELD */) = 0xFF7FFFFFFF7FFFFFLL; /*0x104f82096*/
  *((_DWORD *)this + 5) /* +20: NO 2022 FIELD */ = -8388609; /*0x104f8209b*/
  RBX::ContactManager::computeWorldExtents(this, a2: *(_QWORD *)(*(_QWORD *)(a2 + 944) + 2056LL)); /*0x104f820b0*/
  v4 = *(_QWORD **)(a2 + 1120); /*0x104f820b5*/
  if ( v4 != nullptr ) /*0x104f820bf*/
  {
    v5 = v4[3]; /*0x104f820c1*/
    v6 = RBX::Reflection::Class_getDescriptorPtr<RBX::MegaClusterInstance>(); /*0x104f820c5*/
    if ( *(unsigned __int16 *)(v5 + 440) - (unsigned int)*(unsigned __int16 *)(v6 + 440) <= *(unsigned __int16 *)(v6 + 442) ) /*0x104f820e4*/
    {
      (*(void (__fastcall **)(_BYTE *, _QWORD *))(*v4 + 632LL))(a1: v8, a2: v4); /*0x104f820f3*/
      RBX::Extents::unionWith(this, a2: (const RBX::Extents *)v8); /*0x104f820ff*/
    }
  }
  if ( *((float *)this + 3) /* +12: NO 2022 FIELD */ < this->... /* +0 *//*0x104f82122*/
    || *((float *)this + 4) /* +16: NO 2022 FIELD */ < *((float *)this + 1) /* +4: NO 2022 FIELD */
    || *((float *)this + 5) /* +20: NO 2022 FIELD */ < *((float *)this + 2) /* +8: NO 2022 FIELD */ )
  {
    *(_OWORD *)this = 0; /*0x104f82127*/
    *((_QWORD *)this + 2) /* +16: NO 2022 FIELD */ = 0; /*0x104f8212a*/
  }
  return this; /*0x104f82135*/
}

// Address: 0x104f82140 | Name: __ZN3RBX9Workspace25computeExtentsWorldCachedEb
RBX::Workspace *__fastcall RBX::Workspace::computeExtentsWorldCached(RBX::Workspace *this, double *a2, int a3)
{
  double v5; // xmm0_8
  _BYTE v7[48]; // [rsp+0h] [rbp-30h] BYREF

  if ( a3 != 0 || (v5 = a2[252]) == 0.0 || a2[142] - v5 > 2.0 ) /*0x104f82181*/
  {
    RBX::Workspace::computeExtentsWorldApprox(this: (RBX::Workspace *)v7, (__int64)a2); /*0x104f8218d*/
    qmemcpy(a2 + 249, v7, 24); /*0x104f82196*/
    a2[252] = a2[142]; /*0x104f821b2*/
  }
  *((double *)this + 2) /* +16: NO 2022 FIELD */ = a2[251]; /*0x104f821c2*/
  *(_OWORD *)this = *(_OWORD *)(a2 + 249); /*0x104f821ce*/
  return this; /*0x104f821d4*/
}

// Address: 0x104f821e0 | Name: __ZN3RBX9Workspace32setDistributedGameTimeNoTransmitEd
__int64 __fastcall RBX::Workspace::setDistributedGameTimeNoTransmit(RBX::Workspace *this, double a2)
{
  return RBX::WorkspaceProp::setDistributedGameTimeSetOnly(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */), a2); /*0x104f821eb*/
}

// Address: 0x104f821f2 | Name: __ZN3RBX9Workspace16getServerTimeNowEv
__m128d __fastcall RBX::Workspace::getServerTimeNow(RBX::Workspace *this, RBX::Instance *a2)
{
  char *Dangerous_DEPRECATED; // rax
  const RBX::Instance *v4; // rsi
  RBX::DataModel *v5; // r15
  const RBX::Instance *v6; // rsi
  std::mutex *v7; // r13
  RBX::PeerMonotonicClock *v8; // r12
  bool isNonNetworkOrEditClientLaunchIntent; // r13
  char v11; // bl
  bool v12; // al
  bool v13; // zf
  __m128d v14; // xmm0
  __m128d v15; // xmm0
  bool v16; // al
  __m128d v17; // xmm0
  bool isServerLaunchIntent; // al
  __int64 v19; // rax
  bool v20; // al
  __m128d v21; // xmm0
  __m128d v22; // xmm0
  __m128d v23; // [rsp+0h] [rbp-40h]
  std::mutex *v24; // [rsp+10h] [rbp-30h]

  Dangerous_DEPRECATED = RBX::DataModel::getDangerous_DEPRECATED(this, a2); /*0x104f82206*/
  if ( Dangerous_DEPRECATED == nullptr ) /*0x104f8220e*/
    return (__m128d)0LL; /*0x104f82247*/
  v5 = (RBX::DataModel *)Dangerous_DEPRECATED; /*0x104f82210*/
  if ( !RBX::DataModel::isCloudEdit(this, a2: v4) ) /*0x104f8221d*/
  {
    isNonNetworkOrEditClientLaunchIntent = RBX::DataModel::isNonNetworkOrEditClientLaunchIntent(this: v5, a2: v6); /*0x104f82254*/
    v24 = (RBX::Workspace *)((char *)this + 1568 /* +1568: NO 2022 FIELD */); /*0x104f8225e*/
    std::mutex::lock(this: (RBX::Workspace *)((char *)this + 1568 /* +1568: NO 2022 FIELD */)); /*0x104f82262*/
    if ( DFFlag::WorkspaceUseRbxTransportPeerMonotonicClockDryRun != 0 ) /*0x104f8226e*/
    {
      v8 = (RBX::Workspace *)((char *)this + 1632 /* +1632: NO 2022 FIELD */); /*0x104f82274*/
      v11 = 1; /*0x104f8227b*/
      v12 = true; /*0x104f8227d*/
      v13 = !isNonNetworkOrEditClientLaunchIntent; /*0x104f8227f*/
      v7 = (RBX::Workspace *)((char *)this + 1568 /* +1568: NO 2022 FIELD */); /*0x104f82282*/
      if ( !v13 ) /*0x104f82286*/
        goto LABEL_9; /*0x104f82286*/
      goto LABEL_8; /*0x104f82286*/
    }
LABEL_14:
    if ( DFFlag::WorkspaceUseRbxTransportPeerMonotonicClock == 1 && *((_BYTE *)this + 1672) /* +1672: NO 2022 FIELD */ == 1 ) /*0x104f82346*/
    {
      isServerLaunchIntent = true; /*0x104f82348*/
      v13 = !isNonNetworkOrEditClientLaunchIntent; /*0x104f8234a*/
      v7 = v24; /*0x104f8234d*/
      if ( v13 ) /*0x104f82351*/
        isServerLaunchIntent = RBX::DataModel::isServerLaunchIntent(this: v5); /*0x104f82356*/
      v19 = RBX::PeerMonotonicClock::now(this: (RBX::Workspace *)((char *)this + 1664 /* +1664 = partOperationsPendingDataMigration (std::unordered_set<std::shared_ptr<RBX::PartOperation>>, 64B) -- SIZE CONFLICT, see --verify */), a2: isServerLaunchIntent); /*0x104f82368*/
    }
    else
    {
      v20 = true; /*0x104f8236f*/
      v13 = !isNonNetworkOrEditClientLaunchIntent; /*0x104f82371*/
      v7 = v24; /*0x104f82374*/
      if ( v13 ) /*0x104f82378*/
        v20 = RBX::DataModel::isServerLaunchIntent(this: v5); /*0x104f8237d*/
      v19 = RBX::PeerMonotonicClock::now(this: (RBX::Workspace *)((char *)this + 1632 /* +1632: NO 2022 FIELD */), a2: v20); /*0x104f8238f*/
    }
    v21 = _mm_sub_pd( /*0x104f823a1*/
            (__m128d)_mm_unpacklo_epi32((__m128i)(unsigned __int64)v19, (__m128i)xmmword_108F2F9A0),
            (__m128d)xmmword_108F2F9B0);
    v22 = _mm_hadd_pd(v21, v21); /*0x104f823a9*/
    v22.f64[0] = v22.f64[0] / 1000000.0; /*0x104f823ad*/
    v23 = v22; /*0x104f823b5*/
    goto LABEL_24; /*0x104f823ba*/
  }
  v7 = (RBX::Workspace *)((char *)this + 1568 /* +1568: NO 2022 FIELD */); /*0x104f8221f*/
  std::mutex::lock(this: (RBX::Workspace *)((char *)this + 1568 /* +1568: NO 2022 FIELD */)); /*0x104f82229*/
  if ( DFFlag::WorkspaceUseRbxTransportPeerMonotonicClockDryRun != 1 ) /*0x104f82235*/
  {
    v24 = (RBX::Workspace *)((char *)this + 1568 /* +1568: NO 2022 FIELD */); /*0x104f8232e*/
    isNonNetworkOrEditClientLaunchIntent = false; /*0x104f82332*/
    goto LABEL_14; /*0x104f82332*/
  }
  v8 = (RBX::Workspace *)((char *)this + 1632 /* +1632: NO 2022 FIELD */); /*0x104f8223b*/
LABEL_8:
  v12 = RBX::DataModel::isServerLaunchIntent(this: v5); /*0x104f82288*/
  v11 = 0; /*0x104f82290*/
LABEL_9:
  v14 = _mm_sub_pd( /*0x104f82292*/
          (__m128d)_mm_unpacklo_epi32(
                     (__m128i)(unsigned __int64)RBX::PeerMonotonicClock::now(this: v8, a2: v12),
                     (__m128i)xmmword_108F2F9A0),
          (__m128d)xmmword_108F2F9B0);
  v15 = _mm_hadd_pd(v14, v14); /*0x104f822b2*/
  v15.f64[0] = v15.f64[0] / 1000000.0; /*0x104f822b6*/
  v23 = v15; /*0x104f822be*/
  if ( *((_BYTE *)this + 1672) /* +1672: NO 2022 FIELD */ == 1 ) /*0x104f822cb*/
  {
    v16 = true; /*0x104f822d1*/
    if ( v11 == 0 ) /*0x104f822d5*/
      v16 = RBX::DataModel::isServerLaunchIntent(this: v5); /*0x104f822da*/
    v17 = _mm_sub_pd( /*0x104f822fb*/
            (__m128d)_mm_unpacklo_epi32(
                       (__m128i)(unsigned __int64)RBX::PeerMonotonicClock::now(
                                                    this: (RBX::Workspace *)((char *)this + 1664 /* +1664 = partOperationsPendingDataMigration (std::unordered_set<std::shared_ptr<RBX::PartOperation>>, 64B) -- SIZE CONFLICT, see --verify */),
                                                    a2: v16),
                       (__m128i)xmmword_108F2F9A0),
            (__m128d)xmmword_108F2F9B0);
    RBX::Workspace::reportRbxTransportTimeDifferenceTelemetry( /*0x104f82317*/
      this,
      a2: _mm_hadd_pd(v17, v17).f64[0] / 1000000.0 - v23.f64[0]);
    RBX::Workspace::reportRbxTransportTimeInitializationTelemetry(this, a2: true); /*0x104f82324*/
  }
  else
  {
    RBX::Workspace::reportRbxTransportTimeInitializationTelemetry(this, a2: false); /*0x104f823c1*/
  }
LABEL_24:
  std::mutex::unlock(this: v7); /*0x104f823c6*/
  return v23; /*0x104f823d2*/
}

// Address: 0x104f82400 | Name: __ZN3RBX9Workspace41reportRbxTransportTimeDifferenceTelemetryEd
void __fastcall RBX::Workspace::reportRbxTransportTimeDifferenceTelemetry(RBX::Workspace *this, double a2)
{
  double v3; // xmm0_8
  _BYTE v4[568]; // [rsp+8h] [rbp-248h] BYREF
  double v5; // [rsp+240h] [rbp-10h]

  v5 = a2; /*0x104f8240c*/
  if ( DFFlag::ReportRbxTransportTimeDifferenceTelemetry == 1 ) /*0x104f82418*/
  {
    if ( DFFlag::UseTaskSchedulerTimestampForRbxTransportClockTelemetry == 1 ) /*0x104f82428*/
      RBX::TaskScheduler::getLastCycleTimestamp(this); /*0x104f8242a*/
    else
      RBX::Time::nowFast(this); /*0x104f82431*/
    if ( (double)DFInt::RbxTransportTimeDifferenceTelemetrySamplingIntervalMs / 1000.0 <= v3 - *((double *)this + 278) /* +2224: NO 2022 FIELD */ ) /*0x104f82456*/
    {
      *((double *)this + 278) /* +2224: NO 2022 FIELD */ = v3; /*0x104f82458*/
      RBX::Telemetry::RobloxTelemetryStat::RobloxTelemetryStat( /*0x104f82471*/
        a1: (__int64)v4,
        a2: (__int64)&RBX::Telemetry::kRbxTransportTimeDifferenceStat);
      RBX::Telemetry::RobloxTelemetryStat::setValue(this: (RBX::Telemetry::RobloxTelemetryStat *)v4, a2: v5); /*0x104f8247e*/
      RBX::Telemetry::RobloxTelemetryStat::send(this: (RBX::Telemetry::RobloxTelemetryStat *)v4); /*0x104f8248a*/
      RBX::Telemetry::RobloxTelemetryStat::~RobloxTelemetryStat(this: (RBX::Telemetry::RobloxTelemetryStat *)v4); /*0x104f8249d*/
    }
  }
}

// Address: 0x104f824ca | Name: __ZN3RBX9Workspace45reportRbxTransportTimeInitializationTelemetryEb
void __fastcall RBX::Workspace::reportRbxTransportTimeInitializationTelemetry(RBX::Workspace *this, unsigned __int8 a2)
{
  double v4; // xmm0_8
  _BYTE v5[72]; // [rsp+8h] [rbp-268h] BYREF
  _BYTE v6[544]; // [rsp+50h] [rbp-220h] BYREF

  if ( DFFlag::ReportRbxTransportTimeInitializationTelemetry == 1 ) /*0x104f824df*/
  {
    if ( DFFlag::UseTaskSchedulerTimestampForRbxTransportClockTelemetry == 1 ) /*0x104f824f1*/
      RBX::TaskScheduler::getLastCycleTimestamp(this); /*0x104f824f3*/
    else
      RBX::Time::nowFast(this); /*0x104f824fa*/
    if ( (double)DFInt::RbxTransportTimeInitializationTelemetrySamplingIntervalMs / 1000.0 <= v4 /*0x104f82520*/
                                                                                            - *((double *)this + 279) /* +2232: NO 2022 FIELD */ )
    {
      *((double *)this + 279) /* +2232: NO 2022 FIELD */ = v4; /*0x104f82522*/
      RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x104f82539*/
        a1: (__int64)v5,
        a2: (__int64)&RBX::Telemetry::kRbxTransportMonotonicClockNetworkInitialized);
      RBX::Telemetry::FieldsContainer::addField(a1: v6, a2: "networkInitialized", a3: 18, a4: a2, a5: 1); /*0x104f8255a*/
      RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v5); /*0x104f82566*/
      RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v5); /*0x104f82579*/
    }
  }
}

// Address: 0x104f825a8 | Name: __ZN3RBX9Workspace33setPeerMonotonicClockDifferentialEyx
__int64 __fastcall RBX::Workspace::setPeerMonotonicClockDifferential(
        RBX::Workspace *this,
        unsigned __int64 a2,
        __int64 a3)
{
  return RBX::PeerMonotonicClock::setDifferential(this: (RBX::Workspace *)((char *)this + 1632 /* +1632: NO 2022 FIELD */), a2, a3); /*0x104f825b3*/
}

// Address: 0x104f825ba | Name: __ZN3RBX9Workspace45setRbxTransportPeerMonotonicClockDifferentialEyx
__int64 __fastcall RBX::Workspace::setRbxTransportPeerMonotonicClockDifferential(
        RBX::Workspace *this,
        unsigned __int64 a2,
        __int64 a3)
{
  return RBX::PeerMonotonicClock::setDifferential(this: (RBX::Workspace *)((char *)this + 1664 /* +1664 = partOperationsPendingDataMigration (std::unordered_set<std::shared_ptr<RBX::PartOperation>>, 64B) -- SIZE CONFLICT, see --verify */), a2, a3); /*0x104f825c5*/
}

// Address: 0x104f825ce | Name: __ZN3RBX9Workspace41deprecatedSetAllowThirdPartySalesCallbackEb
__int64 __fastcall RBX::Workspace::deprecatedSetAllowThirdPartySalesCallback(RBX::Workspace *this, char a2)
{
  char v4; // r15
  __int64 result; // rax

  v4 = *((_BYTE *)this + 1296) /* +1296: NO 2022 FIELD */; /*0x104f825e5*/
  result = RBX::WorkspaceProp::setAllowThirdPartySalesSetOnly(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */), a2); /*0x104f825ec*/
  if ( v4 != a2 ) /*0x104f825f4*/
    return RBX::Object::raisePropertyChanged( /*0x104f8260d*/
             this,
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_AllowThirdPartySales);
  return result; /*0x104f82607*/
}

// Address: 0x104f8261e | Name: __ZThn1056_N3RBX9Workspace41deprecatedSetAllowThirdPartySalesCallbackEb
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetAllowThirdPartySalesCallback(
        RBX::Workspace *this,
        char a2)
{
  return RBX::Workspace::deprecatedSetAllowThirdPartySalesCallback(this: (RBX::Workspace *)((char *)this - 1056), a2); /*0x104f82629*/
}

// Address: 0x104f82630 | Name: __ZNK3RBX9Workspace32getDataModelPlaceVersionCallbackEv
__int64 __fastcall RBX::Workspace::getDataModelPlaceVersionCallback(RBX::Workspace *this, const RBX::Instance *a2)
{
  char *Dangerous_DEPRECATED; // rax

  Dangerous_DEPRECATED = RBX::DataModel::getDangerous_DEPRECATED(this, a2); /*0x104f82634*/
  if ( Dangerous_DEPRECATED != nullptr ) /*0x104f8263c*/
    return *((unsigned int *)Dangerous_DEPRECATED + 217); /*0x104f8263e*/
  else
    return 0; /*0x104f82646*/
}

// Address: 0x104f8264a | Name: __ZN3RBX9Workspace42deprecatedSetDataModelPlaceVersionCallbackEi
RBX::DataModel *__fastcall RBX::Workspace::deprecatedSetDataModelPlaceVersionCallback(
        RBX::Workspace *this,
        RBX::DataModel *a2)
{
  unsigned int v2; // ebx
  RBX::DataModel *result; // rax
  RBX::DataModelPlaceVersion *v5; // r15
  int v6; // edx

  v2 = (unsigned int)a2; /*0x104f82654*/
  result = RBX::DataModel::get(this, a2); /*0x104f82659*/
  if ( result != nullptr ) /*0x104f82661*/
  {
    v5 = result; /*0x104f82663*/
    if ( *((_DWORD *)result + 217) != v2 ) /*0x104f8266c*/
    {
      RBX::Object::raisePropertyChanged( /*0x104f82686*/
        this,
        a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_DataModelPlaceVersion);
      return (RBX::DataModel *)RBX::DataModelPlaceVersion::setPlaceVersion(this: v5, a2: (RBX::DataModel *)v2, a3: v6); /*0x104f8269a*/
    }
  }
  return result; /*0x104f82672*/
}

// Address: 0x104f826a0 | Name: __ZThn1056_N3RBX9Workspace42deprecatedSetDataModelPlaceVersionCallbackEi
RBX::DataModel *__fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetDataModelPlaceVersionCallback(
        RBX::Workspace *this,
        RBX::DataModel *a2)
{
  return RBX::Workspace::deprecatedSetDataModelPlaceVersionCallback(this: (RBX::Workspace *)((char *)this - 1056), a2); /*0x104f826ab*/
}

// Address: 0x104f826b2 | Name: __ZN3RBX9Workspace52deprecatedSetReplicateInstanceDestroySettingCallbackENS_5Enums31ReplicateInstanceDestroySettingE
__int64 __fastcall RBX::Workspace::deprecatedSetReplicateInstanceDestroySettingCallback(RBX::Object *a1, int a2)
{
  __int64 result; // rax

  if ( DFFlag::HideDestroySetting == 0 && *((_DWORD *)a1 + 311) != a2 ) /*0x104f826c5*/
  {
    *((_DWORD *)a1 + 311) = a2; /*0x104f826c9*/
    return RBX::Object::raisePropertyChanged( /*0x104f826da*/
             this: a1,
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_ReplicateInstanceDestroySetting);
  }
  return result; /*0x104f826c7*/
}

// Address: 0x104f826e0 | Name: __ZThn1056_N3RBX9Workspace52deprecatedSetReplicateInstanceDestroySettingCallbackENS_5Enums31ReplicateInstanceDestroySettingE
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetReplicateInstanceDestroySettingCallback(
        __int64 a1,
        int a2)
{
  __int64 result; // rax

  if ( DFFlag::HideDestroySetting == 0 && *(_DWORD *)(a1 + 188) != a2 ) /*0x104f826f3*/
  {
    *(_DWORD *)(a1 + 188) = a2; /*0x104f826f7*/
    return RBX::Object::raisePropertyChanged( /*0x104f8270f*/
             this: (RBX::Object *)(a1 - 1056),
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_ReplicateInstanceDestroySetting);
  }
  return result; /*0x104f826f5*/
}

// Address: 0x104f82714 | Name: __ZNK3RBX9Workspace34getReplicateInstanceDestroyEnabledEv
bool __fastcall RBX::Workspace::getReplicateInstanceDestroyEnabled(RBX::Workspace *this)
{
  bool result; // al

  result = true; /*0x104f82718*/
  if ( DFFlag::HideDestroySetting == 0 ) /*0x104f82721*/
    return *((_DWORD *)this + 311) /* +1244: NO 2022 FIELD */ != 1; /*0x104f8272a*/
  return result; /*0x104f8272d*/
}

// Address: 0x104f82730 | Name: __ZN3RBX9Workspace40workspaceUsesMeshPartHeadsAndAccessoriesEPKNS_8InstanceE
char __fastcall RBX::Workspace::workspaceUsesMeshPartHeadsAndAccessories(RBX::Workspace *this, const RBX::Instance *a2)
{
  char *Dangerous_DEPRECATED; // rax
  RBX::Workspace *v3; // rdi
  int v5; // edx
  _QWORD *v6; // rbx
  int v7; // r8d
  int v8; // r9d
  __int64 v9; // rax
  __int64 (__fastcall *v10)(__int64, _QWORD); // rcx

  Dangerous_DEPRECATED = RBX::DataModel::getDangerous_DEPRECATED(this, a2); /*0x104f82736*/
  if ( Dangerous_DEPRECATED != nullptr ) /*0x104f8273e*/
  {
    v3 = *(RBX::Workspace **)RBX::ServiceProvider::refByClass<RBX::Workspace>(this: (RBX::ServiceProvider *)(Dangerous_DEPRECATED + 464)); /*0x104f8274e*/
    if ( v3 != nullptr ) /*0x104f82754*/
      return RBX::Workspace::useMeshPartHeadsAndAccessories(this: v3); /*0x104f8275c*/
  }
  v6 = (_QWORD *)RBX::Security::Context::current(this: v3); /*0x104f82766*/
  v9 = v6[5]; /*0x104f82769*/
  v10 = (__int64 (__fastcall *)(__int64, _QWORD))v6[6]; /*0x104f8276d*/
  if ( v10 != nullptr ) /*0x104f82774*/
  {
    v9 = v10(a1: v9, a2: v6[3]); /*0x104f8277d*/
    v6[5] = v9; /*0x104f8277f*/
    v6[6] = 0; /*0x104f82783*/
  }
  if ( (v9 & 8) == 0 ) /*0x104f8278d*/
    RBX::CreatorLog::printf( /*0x104f8279d*/
      a1: 2,
      a2: (unsigned int)"Instance outside of DataModel; could not read property Workspace.MeshPartHeadsAndAccessories",
      a3: v5,
      a4: (_DWORD)v10,
      a5: v7,
      a6: v8);
  return 1; /*0x104f8275a*/
}

// Address: 0x104f827ac | Name: __ZNK3RBX9Workspace30useMeshPartHeadsAndAccessoriesEv
bool __fastcall RBX::Workspace::useMeshPartHeadsAndAccessories(RBX::Workspace *this)
{
  bool result; // al
  _QWORD v3[3]; // [rsp-40h] [rbp-40h] BYREF
  _QWORD *v4; // [rsp-28h] [rbp-28h] BYREF
  RBX::Workspace *v5; // [rsp-20h] [rbp-20h] BYREF
  int v6; // [rsp-14h] [rbp-14h] BYREF

  result = true; /*0x104f827ac*/
  if ( FFlag::SunsetMPHA == 0 ) /*0x104f827b5*/
  {
    v6 = *((_DWORD *)this + 299) /* +1196: NO 2022 FIELD */; /*0x104f827c9*/
    v5 = this; /*0x104f827cc*/
    if ( RBX::Workspace::useMeshPartHeadsAndAccessories(void)const::flag != -1 ) /*0x104f827db*/
    {
      v3[0] = RBX::reportMeshPartHeadsAndAccessories; /*0x104f827e8*/
      v3[1] = &v6; /*0x104f827ef*/
      v3[2] = &v5; /*0x104f827f7*/
      v4 = v3; /*0x104f827ff*/
      std::__call_once( /*0x104f82810*/
        a1: &RBX::Workspace::useMeshPartHeadsAndAccessories(void)const::flag,
        a2: &v4,
        a3: std::__call_once_proxy[abi:ne200100]<std::tuple<void (&)(RBX::Enums::MeshPartHeadsAndAccessories,RBX::Workspace const*),RBX::Enums::MeshPartHeadsAndAccessories&&,RBX::Workspace const*&&>>);
    }
    return (*((_DWORD *)this + 299) /* +1196: NO 2022 FIELD */ & 0xFFFFFFFD) == 0; /*0x104f8281f*/
  }
  return result; /*0x104f82828*/
}

// Address: 0x104f82830 | Name: __ZN3RBX9Workspace33luaSetMeshPartHeadsAndAccessoriesENS_5Enums27MeshPartHeadsAndAccessoriesE
__int64 __fastcall RBX::Workspace::luaSetMeshPartHeadsAndAccessories(__int64 a1, int a2)
{
  __int64 result; // rax

  if ( *(_DWORD *)(a1 + 1196) != a2 ) /*0x104f8283a*/
    return RBX::WorkspaceProp::setMeshPartHeadsAndAccessories(a1: a1 + 1056); /*0x104f82846*/
  return result; /*0x104f8283c*/
}

// Address: 0x104f8284c | Name: __ZNK3RBX9Workspace18useDeferredSignalsEv
char __fastcall RBX::Workspace::useDeferredSignals(RBX::Workspace *this)
{
  RBX::WorkspaceProp *v2; // rbx

  if ( (unsigned __int8)RBX::isBehaviorSupportEnabled(this) != 0 && *((_DWORD *)this + 287) /* +1148: NO 2022 FIELD */ == 0 ) /*0x104f82865*/
    return 1; /*0x104f82892*/
  v2 = (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */); /*0x104f82867*/
  if ( (unsigned int)RBX::WorkspaceProp::getSignalBehavior(this: v2) != 0 ) /*0x104f82878*/
    return (unsigned int)RBX::WorkspaceProp::getSignalBehavior(this: v2) == 2; /*0x104f82885*/
  else
    return FFlag::DebugForceDeferredSignalBehavior; /*0x104f8288a*/
}

// Address: 0x104f8289c | Name: __ZNK3RBX9Workspace26useAncestryDeferredSignalsEv
char __fastcall RBX::Workspace::useAncestryDeferredSignals(RBX::Workspace *this)
{
  RBX::WorkspaceProp *v1; // rbx

  v1 = (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */); /*0x104f828a5*/
  if ( (unsigned int)RBX::WorkspaceProp::getSignalBehavior(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)) != 0 ) /*0x104f828b6*/
    return (unsigned int)RBX::WorkspaceProp::getSignalBehavior(this: v1) == 3; /*0x104f828c3*/
  if ( FFlag::DebugForceAncestryDeferredSignalBehavior == 1 ) /*0x104f828cf*/
    return FFlag::DebugForceDeferredSignalBehavior ^ 1; /*0x104f828d7*/
  return 0; /*0x104f828e1*/
}

// Address: 0x104f828e4 | Name: __ZNK3RBX9Workspace27useRejectCharacterDeletionsEv
bool __fastcall RBX::Workspace::useRejectCharacterDeletions(RBX::Workspace *this)
{
  int v2; // eax
  __int64 (__fastcall **v4)(); // [rsp+0h] [rbp-30h] BYREF
  __int64 (__fastcall ***v5)(); // [rsp+8h] [rbp-28h] BYREF
  __int64 (__fastcall *v6)(); // [rsp+10h] [rbp-20h] BYREF
  int v7; // [rsp+18h] [rbp-18h]
  RBX::Workspace *v8; // [rsp+20h] [rbp-10h]

  v2 = *((_DWORD *)this + 309) /* +1236: NO 2022 FIELD */; /*0x104f828f0*/
  v6 = RBX::reportRejectCharacterDeletions; /*0x104f828fd*/
  v7 = v2; /*0x104f82901*/
  v8 = this; /*0x104f82904*/
  if ( RBX::Workspace::useRejectCharacterDeletions(void)const::flag != -1 ) /*0x104f82913*/
  {
    v4 = &v6; /*0x104f8291d*/
    v5 = &v4; /*0x104f82924*/
    std::__call_once( /*0x104f82935*/
      a1: &RBX::Workspace::useRejectCharacterDeletions(void)const::flag,
      a2: &v5,
      a3: std::__call_once_proxy[abi:ne200100]<std::tuple<std::__bind<void (*)(RBX::RejectCharacterDeletions,RBX::Workspace const*),RBX::RejectCharacterDeletions,RBX::Workspace const*> &&>>);
  }
  return (*((_DWORD *)this + 309) /* +1236: NO 2022 FIELD */ & 0xFFFFFFFD) == 0; /*0x104f82947*/
}

// Address: 0x104f82954 | Name: __ZN3RBX9Workspace37workspaceUsesRejectCharacterDeletionsEPKNS_8InstanceE
bool __fastcall RBX::Workspace::workspaceUsesRejectCharacterDeletions(RBX::Workspace *this, const RBX::Instance *a2)
{
  RBX::DataModel *v2; // rax
  RBX::Workspace *v3; // rdi

  v2 = RBX::DataModel::get(this, a2); /*0x104f82958*/
  return v2 == nullptr /*0x104f82978*/
      || (v3 = *(RBX::Workspace **)RBX::ServiceProvider::refByClass<RBX::Workspace>(this: (RBX::DataModel *)((char *)v2 + 464))) == nullptr
      || RBX::Workspace::useRejectCharacterDeletions(this: v3);
}

// Address: 0x104f82982 | Name: __ZN3RBX9Workspace27applyDeferredTerrainChangesEv
void __fastcall RBX::Workspace::applyDeferredTerrainChanges(RBX::Workspace *this, RBX::Instance *a2)
{
  RBX::DataModel *v3; // r14
  RBX::ContactManager *v4; // rbx
  bool isServerLaunchIntent; // cl
  bool isNonNetworkedLaunchIntent; // al

  v3 = RBX::DataModel::get(this, a2); /*0x104f82991*/
  v4 = *(RBX::ContactManager **)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 2056LL); /*0x104f8299b*/
  isServerLaunchIntent = RBX::DataModel::isServerLaunchIntent(this: v3); /*0x104f829aa*/
  isNonNetworkedLaunchIntent = true; /*0x104f829ac*/
  if ( !isServerLaunchIntent ) /*0x104f829b0*/
    isNonNetworkedLaunchIntent = RBX::DataModel::isNonNetworkedLaunchIntent(this: v3); /*0x104f829b5*/
  RBX::ContactManager::applyDeferredTerrainChanges(this: v4, a2: isNonNetworkedLaunchIntent); /*0x104f829c4*/
}

// Address: 0x104f829ca | Name: __ZN3RBX9Workspace11onHeartbeatERKNS_9HeartbeatE
__int64 __fastcall RBX::Workspace::onHeartbeat(RBX::Workspace *this, unsigned int a2)
{
  unsigned int v3; // ebx
  __int64 v4; // r15
  __int64 v5; // r15
  __int64 v6; // r12
  RBX::Instance *v7; // rsi
  RBX::Workspace **v8; // rdi
  std::__shared_weak_count *v9; // r15
  RBX::UserInputService *v10; // rax
  const RBX::Instance *v11; // rsi
  int LastInputType; // eax
  __int64 v13; // rax
  RBX::InputObject *v14; // rdi
  volatile signed __int64 *v15; // r15
  RBX::Instance *v16; // rsi
  __m128 v17; // xmm0
  __int64 v18; // rdi
  RBX::EngineContext *v19; // rdi
  std::__shared_weak_count *v20; // r15
  __int64 v21; // r15
  __int64 v22; // rax
  __int64 v23; // rax
  const RBX::Instance *v24; // rsi
  __int64 v25; // r12
  __int64 v26; // rdi
  RBX::Instance *v27; // rsi
  __int64 LocalPlayer; // rax
  volatile signed __int64 *v29; // r15
  RBX::Instance *v30; // rsi
  __int64 v31; // r15
  RBX::DataModel *v32; // rax
  unsigned int v33; // esi
  unsigned __int8 v35; // r8
  _QWORD v36[3]; // [rsp+10h] [rbp-100h] BYREF
  __int64 v37; // [rsp+28h] [rbp-E8h]
  __int128 v38; // [rsp+30h] [rbp-E0h]
  __int128 v39; // [rsp+40h] [rbp-D0h]
  __int128 v40; // [rsp+50h] [rbp-C0h]
  int v41; // [rsp+60h] [rbp-B0h]
  __int128 v42; // [rsp+68h] [rbp-A8h]
  _QWORD v43[2]; // [rsp+80h] [rbp-90h] BYREF
  __int128 v44; // [rsp+90h] [rbp-80h]
  __int64 ThreadLocal; // [rsp+A0h] [rbp-70h] BYREF
  volatile signed __int64 *v46; // [rsp+A8h] [rbp-68h]
  RBX::InputObject *v47; // [rsp+B0h] [rbp-60h]
  volatile signed __int64 *v48; // [rsp+B8h] [rbp-58h]
  __int64 v49; // [rsp+C0h] [rbp-50h] BYREF
  int v50; // [rsp+C8h] [rbp-48h]
  __int64 v51; // [rsp+D0h] [rbp-40h] BYREF
  int v52; // [rsp+D8h] [rbp-38h]
  RBX::DataModel *v53; // [rsp+E0h] [rbp-30h] BYREF

  v3 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::Workspace, a2); /*0x104f829ec*/
  if ( (_BYTE)`guard variable for'RBX::Workspace::onHeartbeat(RBX::Heartbeat const&)::proftoken1165 == 0 /*0x104f82dab*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Workspace::onHeartbeat(RBX::Heartbeat const&)::proftoken1165) != 0 )
  {
    v36[0] = "bugRender createBatch Indices"; /*0x104f82dd4*/
    RBX::Workspace::onHeartbeat(RBX::Heartbeat const&)::proftoken1165 = RBX::Profiler::getToken( /*0x104f82df8*/
                                                                          this: (RBX::Profiler *)&aNoDefaultAppli[-493486],
                                                                          a2: &aDebugrenderCre_0[-15406],
                                                                          a3: (const char *)0xFFFFFFFFLL,
                                                                          a4: 255,
                                                                          a5: v35);
    __cxa_guard_release(a1: &`guard variable for'RBX::Workspace::onHeartbeat(RBX::Heartbeat const&)::proftoken1165); /*0x104f82e06*/
  }
  v4 = RBX::Workspace::onHeartbeat(RBX::Heartbeat const&)::proftoken1165; /*0x104f829fc*/
  *(_OWORD *)v36 = 0; /*0x104f82a0d*/
  v37 = -1; /*0x104f82a10*/
  v38 = 0; /*0x104f82a18*/
  v39 = 0; /*0x104f82a1c*/
  v40 = 0; /*0x104f82a20*/
  v41 = 0; /*0x104f82a24*/
  v42 = 0; /*0x104f82a2b*/
  v36[2] = RBX::Workspace::onHeartbeat(RBX::Heartbeat const&)::proftoken1165; /*0x104f82a2f*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v36); /*0x104f82a33*/
  v37 = RBX::Profiler::enterRegion(a1: v4, a2: -1, a3: 0); /*0x104f82a49*/
  RBX::IVisuallyMovingManager::updateVisuallySleeping(this: (RBX::Workspace *)((char *)this + 808 /* +808: NO 2022 FIELD */)); /*0x104f82a57*/
  if ( (int)((*((_QWORD *)this + 236) /* +1888 likely stepTouch..head.px -- UNVERIFIED */ - *((_QWORD *)this + 235) /* +1880 likely taskQueue.._Rep -- UNVERIFIED */) >> 3) > 0 ) /*0x104f82a71*/
  {
    v5 = ((*((_QWORD *)this + 236) /* +1888 likely stepTouch..head.px -- UNVERIFIED */ - *((_QWORD *)this + 235) /* +1880 likely taskQueue.._Rep -- UNVERIFIED */) >> 3) & 0x7FFFFFFFLL; /*0x104f82a73*/
    v6 = 0; /*0x104f82a7a*/
    do /*0x104f82a9c*/
      RBX::IVisuallyMovingManager::updateVisuallySleeping(this: (RBX::IVisuallyMovingManager *)(*(_QWORD *)(*((_QWORD *)this + 235) /* +1880 likely taskQueue.._Rep -- UNVERIFIED */ + 8 * v6++) /*0x104f82a91*/
                                                                                              + 808LL));
    while ( v5 != v6 ); /*0x104f82a9c*/
  }
  RBX::Workspace::replenishCamera(this); /*0x104f82aa1*/
  v8 = *((RBX::Workspace ***)this + 140); /*0x104f82aa6*/
  if ( v8 != nullptr && v8[13] != this ) /*0x104f82ab6*/
  {
    v44 = 0; /*0x104f82abf*/
    RBX::Instance::setAndLockParent(this: (RBX::Instance *)v8); /*0x104f82ac7*/
    v9 = *((std::__shared_weak_count **)&v44 + 1); /*0x104f82acc*/
    if ( *((_QWORD *)&v44 + 1) != 0 /*0x104f82ae5*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v44 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x104f82aed*/
      std::__shared_weak_count::__release_weak(this: v9); /*0x104f82af3*/
    }
  }
  RBX::Workspace::applyDeferredTerrainChanges(this, a2: v7); /*0x104f82afb*/
  v10 = (RBX::UserInputService *)RBX::ServiceProvider::find<RBX::UserInputService>(a1: this); /*0x104f82b03*/
  if ( v10 != nullptr ) /*0x104f82b0b*/
  {
    LastInputType = RBX::UserInputService::getLastInputType(this: v10, a2: v11); /*0x104f82b14*/
    if ( (unsigned int)RBX::GamepadService::getGamepadIntForEnum(a1: LastInputType) != -1 ) /*0x104f82b23*/
    {
      v13 = RBX::ServiceProvider::find<RBX::MouseService>(a1: this); /*0x104f82b2c*/
      if ( v13 != 0 ) /*0x104f82b34*/
      {
        v14 = *(RBX::InputObject **)(v13 + 256); /*0x104f82b3a*/
        v47 = v14; /*0x104f82b41*/
        v15 = *(volatile signed __int64 **)(v13 + 264); /*0x104f82b45*/
        v48 = v15; /*0x104f82b4c*/
        if ( v15 != nullptr ) /*0x104f82b53*/
          _InterlockedIncrement64(v15 + 1); /*0x104f82b55*/
        if ( v14 != nullptr ) /*0x104f82b5d*/
        {
          v17 = RBX::InputObject::get2DPosition(this: v14); /*0x104f82b63*/
          v18 = *((_QWORD *)this + 261) /* +2088: NO 2022 FIELD */; /*0x104f82b68*/
          if ( v18 != 0 ) /*0x104f82b72*/
          {
            RBX::InputObject::setPosition(a1: v18, a2: v17, a3: 0.0); /*0x104f82b77*/
          }
          else
          {
            _mm_storel_ps((double *)&v49, v17); /*0x104f82b81*/
            v50 = 0; /*0x104f82b87*/
            v51 = 0; /*0x104f82b8a*/
            v52 = 0; /*0x104f82b92*/
            v53 = RBX::DataModel::get(this, a2: v16); /*0x104f82b9d*/
            ThreadLocal = RBX::EngineContext::getThreadLocal(this: v19); /*0x104f82baa*/
            LODWORD(v46) = 8018; /*0x104f82bad*/
            RBX::Creatable::createImpl<RBX::InputObject,RBX::ForceConstructionInCreatable &,RBX::Enums::UserInputTypeEnum::UserInputType const&,RBX::Enums::UserInputStateEnum::UserInputState const&,RBX::Vector3,RBX::Vector3,RBX::DataModel *>( /*0x104f82bd9*/
              a1: (unsigned int)v43,
              a2: (unsigned int)&ThreadLocal,
              a3: (unsigned int)&RBX::InputObjectProp::TYPE_MOUSEIDLE,
              a4: (unsigned int)&RBX::InputObjectProp::INPUT_STATE_CHANGE,
              a5: (unsigned int)&v49,
              a6: (unsigned int)&v51,
              a7: (__int64)&v53);
            std::shared_ptr<RBX::InputObject>::operator=[abi:ne200100](a1: (char *)this + 2088 /* +2088: NO 2022 FIELD */, a2: v43); /*0x104f82bef*/
            v20 = (std::__shared_weak_count *)v43[1]; /*0x104f82bf4*/
            if ( v43[1] != 0 /*0x104f82c0d*/
              && _InterlockedExchangeAdd64((volatile signed __int64 *)(v43[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
            {
              (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(a1: v20); /*0x104f82c15*/
              std::__shared_weak_count::__release_weak(this: v20); /*0x104f82c1b*/
            }
            v15 = v48; /*0x104f82c20*/
          }
        }
        if ( v15 != nullptr && _InterlockedExchangeAdd64(v15 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f82c39*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v15 + 16))(a1: v15); /*0x104f82c41*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v15); /*0x104f82c47*/
        }
      }
    }
  }
  v21 = *((_QWORD *)this + 257) /* +2056: NO 2022 FIELD */; /*0x104f82c4c*/
  if ( v21 != 0 ) /*0x104f82c56*/
  {
    v22 = *((_QWORD *)this + 261) /* +2088: NO 2022 FIELD */; /*0x104f82c5c*/
    if ( v22 != 0 && *(_DWORD *)(v22 + 204) == 5 ) /*0x104f82c73*/
    {
      v23 = RBX::ServiceProvider::find<RBX::UserInputService>(a1: this); /*0x104f82c7c*/
      v25 = v23; /*0x104f82c81*/
      if ( v23 != 0 /*0x104f82d8b*/
        && ((unsigned __int8)RBX::UserInputServiceProp::getVREnabled(this: (RBX::UserInputServiceProp *)(v23 + 192)) != 0
         || (unsigned __int8)RBX::UserInputServiceProp::getGamepadEnabled(this: (RBX::UserInputServiceProp *)(v25 + 192)) != 0
         || (unsigned __int8)RBX::UserInputServiceProp::getMouseEnabled(this: (RBX::UserInputServiceProp *)(v25 + 192)) != 0
         && !RBX::UserInputService::getStudioEmulatingMobileWithAvatarForLocalUser(
               this: (RBX::UserInputService *)v25,
               a2: v24)) )
      {
        (*(void (__fastcall **)(__int64, char *))(*(_QWORD *)v21 + 104LL))(a1: v21, a2: (char *)this + 2088 /* +2088: NO 2022 FIELD */); /*0x104f82cba*/
      }
      if ( RBX::DataModel::frontendProcessing(this, a2: v24) != 0 ) /*0x104f82cc7*/
      {
        LocalPlayer = RBX::Players::findLocalPlayer(this, a2: v27); /*0x104f82ccc*/
        if ( LocalPlayer != 0 ) /*0x104f82cd4*/
        {
          v26 = *(_QWORD *)(LocalPlayer + 4304); /*0x104f82cd6*/
          ThreadLocal = v26; /*0x104f82cdd*/
          v29 = *(volatile signed __int64 **)(LocalPlayer + 4312); /*0x104f82ce1*/
          v46 = v29; /*0x104f82ce8*/
          if ( v29 != nullptr ) /*0x104f82cef*/
            _InterlockedIncrement64(v29 + 1); /*0x104f82cf1*/
          if ( v26 != 0 ) /*0x104f82cf9*/
            rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (rbx::signals *)(v26 + 248)); /*0x104f82d02*/
          if ( v29 != nullptr && _InterlockedExchangeAdd64(v29 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f82d1c*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v29 + 16))(a1: v29); /*0x104f82d24*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v29); /*0x104f82d2a*/
          }
        }
      }
      v31 = RBX::IPluginLegacyApi::get(this: (RBX::IPluginLegacyApi *)v26); /*0x104f82d34*/
      if ( v31 != 0 ) /*0x104f82d3a*/
      {
        v32 = RBX::DataModel::get(this, a2: v30); /*0x104f82d3f*/
        (*(void (__fastcall **)(__int64, RBX::DataModel *))(*(_QWORD *)v31 + 168LL))(a1: v31, a2: v32); /*0x104f82d4d*/
      }
    }
  }
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v36); /*0x104f82d5a*/
  return RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v3, a2: v33); /*0x104f82d66*/
}

// Address: 0x104f82e8a | Name: __ZN3RBX9Workspace15replenishCameraEv
RBX::Workspace *__fastcall RBX::Workspace::replenishCamera(RBX::Workspace *this)
{
  RBX::Workspace *result; // rax
  __int64 v3; // rax
  RBX::Camera *v4; // rsi
  __int128 v5; // xmm0
  volatile signed __int64 *v6; // r14
  std::__shared_weak_count *v7; // r14
  __int64 v8; // rax
  __int64 v9; // rax
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11[2]; // [rsp+0h] [rbp-30h] BYREF
  std::__shared_weak_count *v12[2]; // [rsp+10h] [rbp-20h] BYREF

  result = *((RBX::Workspace **)this + 138); /*0x104f82e98*/
  if ( result != nullptr ) /*0x104f82ea2*/
  {
    while ( result != nullptr ) /*0x104f82ea7*/
    {
      result = *((RBX::Workspace **)result + 13); /*0x104f82ea9*/
      if ( result == this ) /*0x104f82eb0*/
        return result; /*0x104f82eb0*/
    }
  }
  v3 = RBX::Instance::findConstFirstChildOfType<RBX::Camera>(a1: this); /*0x104f82eba*/
  RBX::shared_from<RBX::Camera>(a1: v12, a2: v3); /*0x104f82ec9*/
  v4 = v12[0]; /*0x104f82ece*/
  if ( v12[0] == nullptr ) /*0x104f82ed4*/
  {
    RBX::Instance::clone(a1: v11, a2: *((_QWORD *)this + 267) /* +2136: NO 2022 FIELD */, a3: 3); /*0x104f82eea*/
    v5 = *(_OWORD *)v11; /*0x104f82eef*/
    if ( v11[1] != nullptr ) /*0x104f82efa*/
      _InterlockedIncrement64((volatile signed __int64 *)v11[1] + 1); /*0x104f82efc*/
    v6 = (volatile signed __int64 *)v12[1]; /*0x104f82f01*/
    *(_OWORD *)v12 = v5; /*0x104f82f05*/
    if ( v6 != nullptr && _InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f82f1e*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(a1: v6); /*0x104f82f26*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v6); /*0x104f82f2c*/
    }
    v7 = v11[1]; /*0x104f82f31*/
    if ( v11[1] != nullptr /*0x104f82f4a*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v11[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x104f82f52*/
      std::__shared_weak_count::__release_weak(this: v7); /*0x104f82f58*/
    }
    RBX::Instance::setCanDirtyDataModel(this: v12[0], a2: false); /*0x104f82f63*/
    v8 = *((_QWORD *)this + 138) /* +1104 likely networkOwnershipUnitRemovingSignal..slots -- UNVERIFIED */; /*0x104f82f68*/
    if ( v8 != 0 ) /*0x104f82f72*/
    {
      RBX::Camera::setRenderingViewport(a1: v12[0], a2: *(_DWORD *)(v8 + 644)); /*0x104f82f7e*/
      v9 = RBX::ServiceProvider::find<RBX::GuiService>(a1: this); /*0x104f82f86*/
      if ( v9 != 0 ) /*0x104f82f8e*/
        RBX::CameraProp::setScreenInsetsModel(a1: (char *)v12[0] + 184, a2: v9 + 752); /*0x104f82fa2*/
    }
    RBX::Instance::setParent(this: v12[0], a2: this); /*0x104f82fae*/
    v4 = v12[0]; /*0x104f82fb3*/
  }
  result = (RBX::Workspace *)RBX::WorkspaceProp::setCurrentCamera(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */), a2: v4); /*0x104f82fc1*/
  v10 = v12[1]; /*0x104f82fc6*/
  if ( v12[1] != nullptr ) /*0x104f82fcd*/
  {
    result = (RBX::Workspace *)_InterlockedExchangeAdd64((volatile signed __int64 *)v12[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x104f82fd6*/
    if ( result == nullptr ) /*0x104f82fdf*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x104f82fe7*/
      return (RBX::Workspace *)std::__shared_weak_count::__release_weak(this: v10); /*0x104f82fed*/
    }
  }
  return result; /*0x104f82ff2*/
}

// Address: 0x104f83036 | Name: __ZN3RBX9Workspace21buildWorkspaceMetricsEPNS_9DataModelE
void __fastcall RBX::Workspace::buildWorkspaceMetrics(RBX::Workspace *this, RBX::DataModel *a2)
{
  rbx::signals::slots_holder **v3; // r14
  unsigned int v4; // ebx
  unsigned __int64 v5; // rsi
  volatile signed __int32 *v6; // r15
  rbx::signals::slots_holder *v7; // rax
  unsigned __int64 v8; // rax
  unsigned int v9; // esi

  v3 = (rbx::signals::slots_holder **)((char *)a2 + 992); /*0x104f83047*/
  v4 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, (unsigned int)a2); /*0x104f8305c*/
  rbx::lazyInitSlotsHolder(a1: v3); /*0x104f83061*/
  v6 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v5); /*0x104f83070*/
  *(_QWORD *)v6 = &_mh_execute_header; /*0x104f8307d*/
  *((_QWORD *)v6 + 1) = rbx::signals::slot_with_functor<RBX::Workspace::buildWorkspaceMetrics(RBX::DataModel *)::$_0>::do_call; /*0x104f83087*/
  *((_OWORD *)v6 + 1) = 0; /*0x104f8308e*/
  v7 = *v3; /*0x104f83093*/
  *((_QWORD *)v6 + 4) = *v3; /*0x104f83096*/
  if ( v7 != nullptr ) /*0x104f8309d*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v7 + 1); /*0x104f8309f*/
    v8 = *((_QWORD *)v6 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x104f830a7*/
  }
  else
  {
    v8 = 0; /*0x104f830ad*/
  }
  *((_QWORD *)v6 + 3) = v8; /*0x104f830af*/
  *((_QWORD *)v6 + 5) = this; /*0x104f830b3*/
  rbx::signals::slots_holder::insert(this: *v3, a2: (unsigned __int64)v6); /*0x104f830bd*/
  _InterlockedIncrement(v6 + 1); /*0x104f830c9*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v4, a2: v9); /*0x104f830cf*/
  if ( _InterlockedDecrement(v6 + 1) == 0 ) /*0x104f830d8*/
    rbx::signals::slot_base::operator delete(a1: (void *)v6); /*0x104f830e5*/
}

// Address: 0x104f83112 | Name: __ZN3RBX9Workspace35collectAndSendRolloutPhaseTelemetryEv
void __fastcall RBX::Workspace::collectAndSendRolloutPhaseTelemetry(RBX::Workspace *this)
{
  RBX::Workspace *v1; // r15
  _BYTE *v2; // rbx
  _BYTE *v3; // r13
  __int64 v4; // rbx
  unsigned __int8 *v5; // r12
  RBX::Workspace *v6; // rdx
  __int64 v7; // r14
  unsigned __int8 *v8; // r15
  __int64 v9; // rax
  __int64 v10; // rsi
  RBX::Workspace *v11; // rbx
  unsigned __int8 *v12; // r12
  unsigned __int8 *v13; // rsi
  char *v14; // rcx
  __int64 v15; // r8
  _BYTE v16[72]; // [rsp+0h] [rbp-2D0h] BYREF
  _BYTE v17[528]; // [rsp+48h] [rbp-288h] BYREF
  _BYTE v18[24]; // [rsp+258h] [rbp-78h] BYREF
  __int64 v19; // [rsp+270h] [rbp-60h]
  _BYTE v20[16]; // [rsp+278h] [rbp-58h] BYREF
  void *v21; // [rsp+288h] [rbp-48h]
  unsigned __int8 v22; // [rsp+290h] [rbp-40h] BYREF
  char v23; // [rsp+291h] [rbp-3Fh] BYREF
  __int64 v24; // [rsp+298h] [rbp-38h]
  void *v25; // [rsp+2A0h] [rbp-30h]

  if ( *((_BYTE *)this + 3328) /* +3328: NO 2022 FIELD */ == 0 ) /*0x104f8312d*/
  {
    v1 = this; /*0x104f83133*/
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x104f83144*/
      a1: (__int64)v16,
      a2: (__int64)&RBX::Telemetry::kClientRolloutPhaseTelemetryEvent);
    RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::PropertyDescriptor>::MemberDescriptorContainerV2Iterator( /*0x104f83155*/
      a1: v20,
      a2: *((_QWORD *)v1 + 3) + 40LL);
    RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::PropertyDescriptor>::MemberDescriptorContainerV2Iterator( /*0x104f83160*/
      a1: v18,
      a2: 0);
    v2 = v20; /*0x104f8316c*/
    while ( (unsigned __int8)RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::PropertyDescriptor>::operator==( /*0x104f8317e*/
                               a1: v2,
                               a2: v18) == 0 )
    {
      v3 = v2; /*0x104f83184*/
      v4 = RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::PropertyDescriptor>::operator*(a1: v2); /*0x104f8318f*/
      if ( *(_BYTE *)(v4 + 138) == 1 /*0x104f831ad*/
        && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v4 + 192LL))(a1: v4) != 0 )
      {
        v5 = *(unsigned __int8 **)(v4 + 8); /*0x104f831b3*/
        v6 = v1; /*0x104f831b7*/
        v19 = *v5; /*0x104f831bf*/
        v7 = *((_QWORD *)v5 + 1); /*0x104f831c3*/
        v8 = *((unsigned __int8 **)v5 + 2); /*0x104f831c8*/
        v9 = *(_QWORD *)v4; /*0x104f831cd*/
        v10 = v4; /*0x104f831d4*/
        v11 = v6; /*0x104f831d7*/
        (*(void (__fastcall **)(unsigned __int8 *, __int64))(v9 + 200))(a1: &v22, a2: v10); /*0x104f831da*/
        v12 = v5 + 1; /*0x104f831e8*/
        if ( (v19 & 1) == 0 ) /*0x104f831ee*/
        {
          v7 = (unsigned int)v19 >> 1; /*0x104f831ee*/
          v8 = v12; /*0x104f831f2*/
        }
        v13 = v8; /*0x104f831ff*/
        if ( (v22 & 1) != 0 ) /*0x104f83202*/
        {
          v14 = (char *)v25; /*0x104f83204*/
          v15 = v24; /*0x104f83208*/
        }
        else
        {
          v15 = v22 >> 1; /*0x104f8320e*/
          v14 = &v23; /*0x104f83211*/
        }
        v1 = v11; /*0x104f83215*/
        RBX::Telemetry::FieldsContainer::addField(a1: v17, a2: v13, a3: v7, a4: v14, a5: v15, a6: 1); /*0x104f8322b*/
        if ( (v22 & 1) != 0 ) /*0x104f83234*/
          operator delete(a1: v25); /*0x104f8323a*/
      }
      v2 = v3; /*0x104f8323f*/
      RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::PropertyDescriptor>::operator++(a1: v3); /*0x104f83245*/
    }
    std::string::basic_string[abi:ne200100]<0>(a1: v20, a2: ""); /*0x104f8328a*/
    RBX::Telemetry::FieldsContainer::addPlaceId(this: (RBX::Analytics *)v17); /*0x104f83296*/
    if ( (v20[0] & 1) != 0 ) /*0x104f8329f*/
      operator delete(a1: v21); /*0x104f832a5*/
    RBX::Telemetry::FieldsContainer::addPlaySessionId(this: (RBX::Telemetry::FieldsContainer *)v17); /*0x104f832ad*/
    RBX::Telemetry::FieldsContainer::addPlaceInstanceId(this: (RBX::Telemetry::FieldsContainer *)v17); /*0x104f832b5*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v16); /*0x104f832c1*/
    *((_BYTE *)v1 + 3328) = 1; /*0x104f832c6*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v16); /*0x104f832dc*/
  }
}

// Address: 0x104f83330 | Name: __ZNK3RBX9Workspace11askAddChildEPKNS_8InstanceE
bool __fastcall RBX::Workspace::askAddChild(RBX::Workspace *this, const RBX::Instance *a2)
{
  return a2 != nullptr /*0x104f83360*/
      && __dynamic_cast(
           lpsrc: a2,
           lpstype: (const struct __class_type_info *)&`typeinfo for'RBX::Instance,
           lpdtype: (const struct __class_type_info *)&`typeinfo for'RBX::IAdornable,
           s2d: -2) != nullptr;
}

// Address: 0x104f83364 | Name: __ZN3RBX9Workspace20onDescendantRemovingERKNSt3__110shared_ptrINS_8InstanceEEE
__int64 __fastcall RBX::Workspace::onDescendantRemoving(RBX::Constraints::GizmoManager **this, RBX::Instance **a2)
{
  RBX::IAdornable *v4; // rax

  RBX::Constraints::GizmoManager::onInstanceRemoved(this: *(this + 272), a2: *a2); /*0x104f8337b*/
  if ( *a2 != nullptr ) /*0x104f83386*/
  {
    v4 = (RBX::IAdornable *)__dynamic_cast( /*0x104f8339d*/
                              lpsrc: *a2,
                              lpstype: (const struct __class_type_info *)&`typeinfo for'RBX::Instance,
                              lpdtype: (const struct __class_type_info *)&`typeinfo for'RBX::IAdornable,
                              s2d: -2);
    if ( v4 != nullptr ) /*0x104f833a5*/
      RBX::IAdornableCollector::onRenderableDescendantRemoving(this: *(this + 241), a2: v4); /*0x104f833b1*/
  }
  return RBX::ModelInstance::onDescendantRemoving((RBX::ModelInstance *)this, (__int64 *)a2); /*0x104f833bc*/
}

// Address: 0x104f833c6 | Name: __ZN3RBX9Workspace17onDescendantAddedEPNS_8InstanceE
__int64 __fastcall RBX::Workspace::onDescendantAdded(RBX::IAdornableCollector **this, RBX::Instance *a2)
{
  RBX::IAdornable *v4; // rax

  RBX::ModelInstance::onDescendantAdded((RBX::ModelInstance *)this, a2); /*0x104f833d3*/
  if ( a2 != nullptr ) /*0x104f833db*/
  {
    v4 = (RBX::IAdornable *)__dynamic_cast( /*0x104f833f5*/
                              lpsrc: a2,
                              lpstype: (const struct __class_type_info *)&`typeinfo for'RBX::Instance,
                              lpdtype: (const struct __class_type_info *)&`typeinfo for'RBX::IAdornable,
                              s2d: -2);
    if ( v4 != nullptr ) /*0x104f833fd*/
      RBX::IAdornableCollector::onRenderableDescendantAdded(this: *(this + 241), a2: v4); /*0x104f83409*/
  }
  return RBX::Constraints::GizmoManager::onInstanceAdded(this: *(this + 272), a2); /*0x104f83418*/
}

// Address: 0x104f83422 | Name: __ZN3RBX9Workspace14startDecalDragEPNS_5DecalENS_10InsertModeE
bool __fastcall RBX::Workspace::startDecalDrag(RBX::Workspace *a1, RBX::Instance *a2, int a3)
{
  rbx::signals::slots_holder **v5; // rax
  std::__shared_weak_count *v6; // rbx
  __int64 v7; // r14
  std::__shared_weak_count *v8; // rbx
  std::__shared_weak_count *v9; // rbx
  RBX::Workspace *v11; // [rsp+0h] [rbp-70h] BYREF
  __int64 v12; // [rsp+8h] [rbp-68h] BYREF
  volatile signed __int64 *v13; // [rsp+10h] [rbp-60h]
  RBX::Workspace *v14; // [rsp+18h] [rbp-58h] BYREF
  std::__shared_weak_count *v15[2]; // [rsp+20h] [rbp-50h]
  RBX::Instance *v16; // [rsp+30h] [rbp-40h] BYREF
  __int64 v17; // [rsp+38h] [rbp-38h]
  std::__shared_weak_count *v18; // [rsp+40h] [rbp-30h]
  __int64 v19; // [rsp+48h] [rbp-28h]
  std::__shared_weak_count *v20; // [rsp+50h] [rbp-20h]
  _DWORD v21[5]; // [rsp+5Ch] [rbp-14h] BYREF

  v16 = a2; /*0x104f83430*/
  v21[0] = a3; /*0x104f83434*/
  v14 = a1; /*0x104f83437*/
  *(_OWORD *)v15 = 0; /*0x104f8343e*/
  if ( a2 != nullptr ) /*0x104f83445*/
  {
    v5 = (rbx::signals::slots_holder **)RBX::ServiceClient<RBX::Selection>::createService(a1: &v14); /*0x104f8344e*/
    RBX::Selection::setSelection(this: v5, a2); /*0x104f83459*/
  }
  v11 = a1; /*0x104f83462*/
  RBX::Creatable::createImpl<RBX::DecalTool,RBX::Workspace *,RBX::Decal *&,RBX::InsertMode &>( /*0x104f83471*/
    a1: &v12,
    a2: &v11,
    a3: &v16,
    a4: v21);
  v17 = v12; /*0x104f8347e*/
  v18 = (std::__shared_weak_count *)v13; /*0x104f83482*/
  v19 = v12; /*0x104f83486*/
  v20 = (std::__shared_weak_count *)v13; /*0x104f8348a*/
  if ( v13 != nullptr ) /*0x104f83491*/
    _InterlockedIncrement64(v13 + 1); /*0x104f83493*/
  RBX::Workspace::setMouseCommand(this: a1); /*0x104f834a1*/
  v6 = v20; /*0x104f834a6*/
  if ( v20 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v20 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f834bf*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x104f834c7*/
    std::__shared_weak_count::__release_weak(this: v6); /*0x104f834cd*/
  }
  v7 = v17; /*0x104f834d2*/
  v8 = v18; /*0x104f834d6*/
  if ( v18 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v18 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f834ef*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x104f834f7*/
    std::__shared_weak_count::__release_weak(this: v8); /*0x104f834fd*/
  }
  v9 = v15[1]; /*0x104f83502*/
  if ( v15[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v15[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8351b*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x104f83523*/
    std::__shared_weak_count::__release_weak(this: v9); /*0x104f83529*/
  }
  return v7 != 0; /*0x104f83534*/
}

// Address: 0x104f8356a | Name: __ZN3RBX9Workspace15setMouseCommandENSt3__110shared_ptrINS_12MouseCommandEEEb
void __fastcall RBX::Workspace::setMouseCommand(RBX::IPluginLegacyApi **this, const RBX::Instance *a2, char a3)
{
  unsigned __int8 v5; // r13
  __int64 ServiceProvider; // rax
  RBX::IPluginLegacyApi *v7; // rdi
  __int64 v8; // r12
  __int64 v9; // r15
  RBX::IPluginLegacyApi *v10; // rcx
  __int64 v11; // rax
  int v12; // r14d
  int v13; // r15d
  __int64 v14; // rsi
  std::__shared_weak_count *v15; // r12
  int v16; // r12d
  std::__shared_weak_count *v17; // r12
  RBX::IPluginLegacyApi *v18; // rdi
  __int64 v19; // rax
  __int64 v20; // rdx
  __int64 v21; // rcx
  __int64 v22; // r12
  __int64 *v23; // rsi
  int v24; // r12d
  int v25; // r13d
  __int64 v26; // rsi
  bool v27; // r13
  std::__shared_weak_count *v28; // r12
  __int64 *v29; // r15
  __int64 v30; // rdi
  __int64 v31; // rax
  std::__shared_weak_count *v32; // r12
  bool v33; // r15
  int v34; // r14d
  int v35; // r12d
  __int64 v36; // rax
  __int64 v37; // rax
  std::__shared_weak_count *v38; // rbx
  std::__shared_weak_count *v39[2]; // [rsp+10h] [rbp-80h] BYREF
  __int64 v40; // [rsp+20h] [rbp-70h] BYREF
  std::__shared_weak_count *v41; // [rsp+28h] [rbp-68h]
  _QWORD v42[2]; // [rsp+30h] [rbp-60h] BYREF
  void *v43; // [rsp+40h] [rbp-50h]
  __int64 *v44; // [rsp+48h] [rbp-48h]
  _QWORD v45[2]; // [rsp+50h] [rbp-40h] BYREF
  void *v46; // [rsp+60h] [rbp-30h]

  v5 = a3 ^ 1; /*0x104f83584*/
  ServiceProvider = RBX::ServiceProvider::findServiceProvider((RBX::ServiceProvider *)this, a2); /*0x104f83588*/
  v8 = ServiceProvider - 464; /*0x104f8358d*/
  v9 = ServiceProvider - 464; /*0x104f83597*/
  if ( ServiceProvider == 0 ) /*0x104f8359a*/
    v9 = 0; /*0x104f8359a*/
  v10 = *(RBX::IPluginLegacyApi **)a2; /*0x104f8359e*/
  if ( (v5 & (*(_QWORD *)a2 != 0)) == 0 ) /*0x104f835aa*/
  {
    if ( ServiceProvider != 0 ) /*0x104f835b3*/
    {
      v11 = RBX::IPluginLegacyApi::get(this: v7); /*0x104f835b9*/
      if ( v11 != 0 /*0x104f835d8*/
        && (*(unsigned __int8 (__fastcall **)(__int64, __int64))(*(_QWORD *)v11 + 144LL))(a1: v11, a2: v8) != 0 )
      {
        v12 = FLog::ChangeMouseCommand; /*0x104f835da*/
        if ( (unsigned __int8)FLog::ChangeMouseCommand >= 6u && (FLog::ChangeMouseCommand & 0xFC00) != 0 ) /*0x104f835ef*/
        {
          v13 = qword_10D7E4810; /*0x104f835fa*/
          RBX::getMouseCommandName(a1: v45, a2: this + 259); /*0x104f83612*/
          FLog::FastLogSafeFormatted<std::string>( /*0x104f83632*/
            a1: v12,
            a2: v13,
            a3: 4,
            a4: (int)"[FLog::ChangeMouseCommand] Rejecting new mouse command {} because of active tool plugin",
            a5: 87,
            a6: (unsigned __int8 *)v45);
          if ( (v45[0] & 1) != 0 ) /*0x104f8363b*/
            operator delete(a1: v46); /*0x104f83645*/
        }
        return; /*0x104f8364a*/
      }
      v10 = *(RBX::IPluginLegacyApi **)a2; /*0x104f8364f*/
    }
    if ( v10 == nullptr ) /*0x104f83655*/
    {
      v14 = (__int64)*(this + 259); /*0x104f8365b*/
      if ( v14 != 0 ) /*0x104f83665*/
      {
        (*(void (__fastcall **)(_QWORD *))(*(_QWORD *)v14 + 280LL))(a1: v45); /*0x104f83675*/
        std::shared_ptr<RBX::MouseCommand>::operator=[abi:ne200100](a1: a2, a2: v45); /*0x104f83681*/
        v15 = (std::__shared_weak_count *)v45[1]; /*0x104f83686*/
        if ( v45[1] != 0 /*0x104f836a1*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(v45[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x104f836aa*/
          std::__shared_weak_count::__release_weak(this: v15); /*0x104f836b0*/
        }
        v16 = FLog::ChangeMouseCommand; /*0x104f836b5*/
        if ( (unsigned __int8)FLog::ChangeMouseCommand >= 6u && (FLog::ChangeMouseCommand & 0xFC00) != 0 ) /*0x104f836ca*/
        {
          v44 = (__int64 *)qword_10D7E4810; /*0x104f836df*/
          RBX::getMouseCommandName(a1: v45, a2: this + 259); /*0x104f836e7*/
          RBX::getMouseCommandName(a1: v42, a2); /*0x104f836f6*/
          FLog::FastLogSafeFormatted<std::string,std::string>( /*0x104f8371c*/
            a1: v16,
            a2: (int)v44,
            a3: 4,
            a4: (int)"[FLog::ChangeMouseCommand] New mouse command was nullptr, have sticky command {}, generated new mouse command {}",
            a5: 112,
            a6: (unsigned __int8 *)v45,
            a7: (unsigned __int8 *)v42);
          if ( (v42[0] & 1) != 0 ) /*0x104f83725*/
            operator delete(a1: v43); /*0x104f8372b*/
          if ( (v45[0] & 1) != 0 ) /*0x104f83734*/
            operator delete(a1: v46); /*0x104f8373a*/
        }
      }
      v10 = *(RBX::IPluginLegacyApi **)a2; /*0x104f8373f*/
      if ( *(_QWORD *)a2 == 0 ) /*0x104f83745*/
      {
        v42[0] = this; /*0x104f8374b*/
        RBX::Creatable::createImpl<RBX::NewNullTool,RBX::Workspace *&>(a1: v45); /*0x104f83755*/
        std::shared_ptr<RBX::MouseCommand>::operator=[abi:ne200100]<RBX::NewNullTool,0>(a1: a2, a2: v45); /*0x104f83760*/
        v17 = (std::__shared_weak_count *)v45[1]; /*0x104f83765*/
        if ( v45[1] != 0 /*0x104f83780*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(v45[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x104f83789*/
          std::__shared_weak_count::__release_weak(this: v17); /*0x104f8378f*/
        }
        v10 = *(RBX::IPluginLegacyApi **)a2; /*0x104f83794*/
      }
    }
  }
  v18 = *(this + 257); /*0x104f83797*/
  if ( v10 != v18 ) /*0x104f837a1*/
  {
    if ( v18 != nullptr ) /*0x104f837aa*/
      (*(void (__fastcall **)(RBX::IPluginLegacyApi *))(*(_QWORD *)v18 + 216LL))(a1: v18); /*0x104f837af*/
    v19 = RBX::IPluginLegacyApi::get(this: v18); /*0x104f837b5*/
    if ( v19 != 0 ) /*0x104f837bd*/
    {
      v22 = v19; /*0x104f837bf*/
      if ( (*(unsigned __int8 (__fastcall **)(__int64, __int64))(*(_QWORD *)v19 + 144LL))(a1: v19, a2: v9) != 0 ) /*0x104f837d3*/
        (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v22 + 160LL))(a1: v22, a2: v9); /*0x104f837df*/
    }
    v23 = (__int64 *)(this + 257); /*0x104f837e5*/
    v24 = FLog::ChangeMouseCommand; /*0x104f837ec*/
    LOBYTE(v21) = (unsigned __int8)FLog::ChangeMouseCommand < 6u || (FLog::ChangeMouseCommand & 0xFC00) == 0; /*0x104f83804*/
    v44 = (__int64 *)(this + 257); /*0x104f83806*/
    if ( (_BYTE)v21 == 0 ) /*0x104f8380a*/
    {
      v25 = qword_10D7E4810; /*0x104f8380c*/
      RBX::getMouseCommandName(a1: v45, a2: v23); /*0x104f83817*/
      RBX::getMouseCommandName(a1: v42, a2); /*0x104f83826*/
      FLog::FastLogSafeFormatted<std::string,std::string>( /*0x104f8384b*/
        a1: v24,
        a2: v25,
        a3: 4,
        a4: (int)"[FLog::ChangeMouseCommand] Changing mouse command from {} to {}",
        a5: 63,
        a6: (unsigned __int8 *)v45,
        a7: (unsigned __int8 *)v42);
      if ( (v42[0] & 1) != 0 ) /*0x104f83854*/
        operator delete(a1: v43); /*0x104f8385a*/
      if ( (v45[0] & 1) != 0 ) /*0x104f83863*/
        operator delete(a1: v46); /*0x104f83869*/
      v23 = v44; /*0x104f8386e*/
    }
    v26 = *v23; /*0x104f83872*/
    if ( v26 != 0 ) /*0x104f83878*/
    {
      (*(void (__fastcall **)(_QWORD *, __int64, __int64, __int64))(*(_QWORD *)v26 + 280LL))( /*0x104f83888*/
        a1: v45,
        a2: v26,
        a3: v20,
        a4: v21);
      v27 = v45[0] != 0; /*0x104f83892*/
      v28 = (std::__shared_weak_count *)v45[1]; /*0x104f83896*/
      if ( v45[1] != 0 /*0x104f838b0*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)(v45[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v28 + 16LL))(a1: v28); /*0x104f838b9*/
        std::__shared_weak_count::__release_weak(this: v28); /*0x104f838bf*/
      }
      v29 = v44; /*0x104f838c4*/
      if ( *v44 != 0 ) /*0x104f838ce*/
      {
        (*(void (__fastcall **)(__int64))(*(_QWORD *)*v44 + 240LL))(a1: *v44); /*0x104f838d3*/
        v30 = *v29; /*0x104f838d9*/
        v31 = *((_QWORD *)a2 + 1); /*0x104f838dc*/
        *(_OWORD *)v39 = *(_OWORD *)a2; /*0x104f838e4*/
        if ( v31 != 0 ) /*0x104f838eb*/
          _InterlockedIncrement64((volatile signed __int64 *)(v31 + 8)); /*0x104f838ed*/
        (*(void (__fastcall **)(__int64, std::__shared_weak_count **))(*(_QWORD *)v30 + 96LL))(a1: v30, a2: v39); /*0x104f838f9*/
        v32 = v39[1]; /*0x104f838fc*/
        v33 = v27; /*0x104f83903*/
        if ( v39[1] != nullptr /*0x104f83919*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v39[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v32 + 16LL))(a1: v32); /*0x104f83922*/
          std::__shared_weak_count::__release_weak(this: v32); /*0x104f83928*/
        }
      }
      else
      {
        v33 = v27; /*0x104f83934*/
      }
    }
    else
    {
      v33 = false; /*0x104f8392f*/
    }
    std::shared_ptr<RBX::MouseCommand>::operator=[abi:ne200100](a1: v44, a2); /*0x104f8393e*/
    (*(void (__fastcall **)(__int64 *))(**(_QWORD **)a2 + 280LL))(a1: &v40); /*0x104f83950*/
    if ( v40 != 0 ) /*0x104f8395a*/
    {
      v34 = FLog::ChangeMouseCommand; /*0x104f83960*/
      if ( (unsigned __int8)FLog::ChangeMouseCommand >= 6u && (FLog::ChangeMouseCommand & 0xFC00) != 0 ) /*0x104f83975*/
      {
        v35 = qword_10D7E4810; /*0x104f8397c*/
        RBX::getMouseCommandName(a1: v45, a2: this + 259); /*0x104f8398e*/
        RBX::getMouseCommandName(a1: v42, a2: &v40); /*0x104f8399e*/
        FLog::FastLogSafeFormatted<std::string,std::string>( /*0x104f839c3*/
          a1: v34,
          a2: v35,
          a3: 4,
          a4: (int)"[FLog::ChangeMouseCommand] Changing sticky command from {} to {}",
          a5: 64,
          a6: (unsigned __int8 *)v45,
          a7: (unsigned __int8 *)v42);
        if ( (v42[0] & 1) != 0 ) /*0x104f839cc*/
          operator delete(a1: v43); /*0x104f839d2*/
        if ( (v45[0] & 1) != 0 ) /*0x104f839db*/
          operator delete(a1: v46); /*0x104f839e1*/
      }
      std::shared_ptr<RBX::MouseCommand>::operator=[abi:ne200100](a1: this + 259, a2: &v40); /*0x104f839f4*/
      if ( v33 && v40 != 0 ) /*0x104f839ff*/
      {
        v36 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v40 + 240LL))(a1: v40); /*0x104f83a0c*/
        rbx::signal<void ()(std::string const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: this + 412, a2: v36); /*0x104f83a1c*/
      }
    }
    RBX::Workspace::updatePlayerMouseCommand((RBX::Workspace *)this); /*0x104f83a24*/
    v37 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)*v44 + 240LL))(a1: *v44); /*0x104f83a33*/
    rbx::signal<void ()(std::string const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: this + 413, a2: v37); /*0x104f83a46*/
    v38 = v41; /*0x104f83a4b*/
    if ( v41 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v41 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f83a64*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v38 + 16LL))(a1: v38); /*0x104f83a6c*/
      std::__shared_weak_count::__release_weak(this: v38); /*0x104f83a72*/
    }
  }
}

// Address: 0x104f83afc | Name: __ZN3RBX9Workspace9getCameraEv
__int64 __fastcall RBX::Workspace::getCamera(RBX::Workspace *this)
{
  return (*(__int64 (__fastcall **)(RBX::Workspace *))(*(_QWORD *)this + 936 /* +7488: NO 2022 FIELD */LL))(a1: this);
}

// Address: 0x104f83b0a | Name: __ZThn800_N3RBX9Workspace9getCameraEv
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::getCamera(RBX::Workspace *this)
{
  return (*(__int64 (__fastcall **)(char *))(*((_QWORD *)this  /* +0 likely ... -- UNVERIFIED */- 100) + 936LL))(a1: (char *)this - 800);
}

// Address: 0x104f83b24 | Name: __ZNK3RBX9Workspace14getConstCameraEv
__int64 __fastcall RBX::Workspace::getConstCamera(RBX::Workspace *this)
{
  __int64 result; // rax

  result = *((_QWORD *)this + 265) /* +2120: NO 2022 FIELD */; /*0x104f83b28*/
  if ( result == 0 ) /*0x104f83b32*/
  {
    result = *((_QWORD *)this + 138) /* +1104 likely networkOwnershipUnitRemovingSignal..slots -- UNVERIFIED */; /*0x104f83b34*/
    if ( result == 0 ) /*0x104f83b3e*/
      return *((_QWORD *)this + 267) /* +2136: NO 2022 FIELD */; /*0x104f83b40*/
  }
  return result; /*0x104f83b47*/
}

// Address: 0x104f83b4a | Name: __ZThn800_NK3RBX9Workspace14getConstCameraEv
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::getConstCamera(RBX::Workspace *this)
{
  __int64 result; // rax

  result = *((_QWORD *)this + 165) /* +1320 likely pendingSendTouches.impl.hasher -- UNVERIFIED */; /*0x104f83b4e*/
  if ( result == 0 ) /*0x104f83b58*/
  {
    result = *((_QWORD *)this + 38) /* +304: NO 2022 FIELD */; /*0x104f83b5a*/
    if ( result == 0 ) /*0x104f83b64*/
      return *((_QWORD *)this + 167) /* +1336 likely allWorlds.array.num -- UNVERIFIED */; /*0x104f83b66*/
  }
  return result; /*0x104f83b6d*/
}

// Address: 0x104f83b70 | Name: __ZN3RBX9Workspace17swapCurrentCameraENSt3__110shared_ptrINS_6CameraEEE
__int64 __fastcall RBX::Workspace::swapCurrentCamera(RBX::Instance *a1, RBX::Instance **a2)
{
  __int64 result; // rax
  __int64 v5; // rax

  if ( *a2 != nullptr ) /*0x104f83b83*/
  {
    RBX::Instance::setCanDirtyDataModel(this: *a2, a2: false); /*0x104f83b8a*/
    v5 = *((_QWORD *)a1 + 138); /*0x104f83b96*/
    if ( v5 != 0 ) /*0x104f83ba0*/
    {
      RBX::Camera::setRenderingViewport(a1: *a2, a2: *(_DWORD *)(v5 + 644)); /*0x104f83bab*/
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)a1 + 138) + 280LL))(a1: *((_QWORD *)a1 + 138)); /*0x104f83bba*/
    }
    RBX::Instance::setParent(this: *a2, a2: a1); /*0x104f83bc6*/
    return RBX::WorkspaceProp::setCurrentCamera(this: (RBX::Instance *)((char *)a1 + 1056), a2: *a2); /*0x104f83bdb*/
  }
  return result; /*0x104f83bd5*/
}

// Address: 0x104f83c4c | Name: __ZN3RBX9Workspace17getOverrideCameraEv
__int64 __fastcall RBX::Workspace::getOverrideCamera(RBX::Workspace *this)
{
  return *((_QWORD *)this + 265) /* +2120: NO 2022 FIELD */; /*0x104f83c57*/
}

// Address: 0x104f83c5a | Name: __ZN3RBX9Workspace17setOverrideCameraEPNS_6CameraE
__int64 __fastcall RBX::Workspace::setOverrideCamera(RBX::Camera **this, RBX::Camera *a2)
{
  char *v2; // rbx
  __int64 result; // rax
  std::__shared_weak_count *v4; // rbx
  _QWORD v5[5]; // [rsp-28h] [rbp-28h] BYREF

  if ( *(this + 265) != a2 ) /*0x104f83c61*/
  {
    v2 = (char *)(this + 265); /*0x104f83c71*/
    RBX::shared_from<RBX::Camera>(a1: v5, a2); /*0x104f83c7f*/
    result = std::shared_ptr<RBX::Camera>::operator=[abi:ne200100](a1: v2, a2: v5); /*0x104f83c8a*/
    v4 = (std::__shared_weak_count *)v5[1]; /*0x104f83c8f*/
    if ( v5[1] != 0 ) /*0x104f83c96*/
    {
      result = _InterlockedExchangeAdd64((volatile signed __int64 *)(v5[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL); /*0x104f83c9f*/
      if ( result == 0 ) /*0x104f83ca8*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(a1: v4); /*0x104f83cb0*/
        return std::__shared_weak_count::__release_weak(this: v4); /*0x104f83cb6*/
      }
    }
  }
  return result; /*0x104f83cc3*/
}

// Address: 0x104f83cc4 | Name: __ZN3RBX9Workspace34deprecatedSetCurrentCameraCallbackEPNS_6CameraE
void __fastcall RBX::Workspace::deprecatedSetCurrentCameraCallback(RBX::Workspace *this, RBX::Camera *a2)
{
  char *v4; // r14
  std::__shared_weak_count *v5; // r12
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // rsi
  __int64 v9; // r8
  __int64 v10; // r9
  _QWORD *v11; // rax
  volatile signed __int64 *v12; // r15
  __int64 v13; // r12
  __int64 v14; // r14
  __int64 (__fastcall *v15)(); // [rsp+0h] [rbp-50h] BYREF
  RBX::Camera *v16; // [rsp+8h] [rbp-48h]
  _QWORD *v17; // [rsp+10h] [rbp-40h] BYREF
  volatile signed __int64 *v18; // [rsp+18h] [rbp-38h]
  char *v19; // [rsp+20h] [rbp-30h]

  if ( *((RBX::Camera **)this + 138) != a2 ) /*0x104f83cdc*/
  {
    v4 = (char *)this + 1104 /* +1104 = networkOwnershipUnitRemovingSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */; /*0x104f83ce8*/
    RBX::shared_from<RBX::Camera>(a1: &v17, a2); /*0x104f83cf6*/
    std::shared_ptr<RBX::Camera>::operator=[abi:ne200100](a1: v4, a2: &v17); /*0x104f83d01*/
    v5 = (std::__shared_weak_count *)v18; /*0x104f83d06*/
    if ( v18 != nullptr && _InterlockedExchangeAdd64(v18 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f83d21*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x104f83d2a*/
      std::__shared_weak_count::__release_weak(this: v5); /*0x104f83d30*/
    }
    RBX::Object::raisePropertyChanged( /*0x104f83d42*/
      this,
      a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_CurrentCamera);
    if ( a2 != nullptr ) /*0x104f83d4a*/
    {
      v15 = RBX::destroyIfNotCurrent; /*0x104f83d57*/
      v16 = a2; /*0x104f83d5b*/
      v11 = *((_QWORD **)this + 15); /*0x104f83d5f*/
      if ( v11 != nullptr ) /*0x104f83d66*/
      {
        v19 = v4; /*0x104f83d68*/
        v17 = v11; /*0x104f83d6c*/
        v12 = *((volatile signed __int64 **)this + 16); /*0x104f83d70*/
        v18 = v12; /*0x104f83d77*/
        if ( v12 != nullptr ) /*0x104f83d7e*/
          _InterlockedIncrement64(v12 + 1); /*0x104f83d80*/
        v13 = *v11; /*0x104f83d85*/
        v14 = v11[1]; /*0x104f83d88*/
        if ( *v11 != v14 ) /*0x104f83d8f*/
        {
          do /*0x104f83da7*/
          {
            ((void (__fastcall *)(__int64 (__fastcall **)(), __int64))std::__bind<void (*)(std::shared_ptr<RBX::Instance>,RBX::Camera const*),std::placeholders::__ph<1> const&,RBX::Camera*&>::operator()[abi:ne200100]<std::shared_ptr<RBX::Instance> const&>)( /*0x104f83d9b*/
              a1: &v15,
              a2: v13);
            v13 += 16; /*0x104f83da0*/
          }
          while ( v13 != v14 ); /*0x104f83da7*/
        }
        v4 = v19; /*0x104f83dac*/
        if ( v12 != nullptr && _InterlockedExchangeAdd64(v12 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f83dc2*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *, __int64, __int64, __int64, __int64, __int64, __int64 (__fastcall *)(), RBX::Camera *, _QWORD *, volatile signed __int64 *))(*v12 + 16))( /*0x104f83dca*/
            a1: v12,
            a2: v8,
            a3: v6,
            a4: v7,
            a5: v9,
            a6: v10,
            a7: v15,
            a8: v16,
            a9: v17,
            a10: v18);
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v12); /*0x104f83dd0*/
        }
      }
    }
    rbx::signal<void ()(std::shared_ptr<RBX::Camera>)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x104f83de2*/
      a1: (char *)this + 3288 /* +3288: NO 2022 FIELD */,
      a2: v4);
  }
}

// Address: 0x104f83e0a | Name: __ZThn1056_N3RBX9Workspace34deprecatedSetCurrentCameraCallbackEPNS_6CameraE
void __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetCurrentCameraCallback(
        RBX::Workspace *this,
        RBX::Camera *a2)
{
  RBX::Workspace::deprecatedSetCurrentCameraCallback(this: (RBX::Workspace *)((char *)this - 1056), a2); /*0x104f83e16*/
}

// Address: 0x104f83e1c | Name: __ZN3RBX9Workspace9setCloudsEPNS_8InstanceE
__int64 __fastcall RBX::Workspace::setClouds(RBX::Workspace *this, RBX::Instance *a2)
{
  __int64 result; // rax
  std::__shared_weak_count *v5; // rbx
  __int128 v6[2]; // [rsp+8h] [rbp-28h] BYREF

  if ( (unsigned __int8)FLog::Clouds >= 6u && BYTE1(FLog::Clouds) >= 3u ) /*0x104f83e48*/
    FLog::FastLog( /*0x104f83e5d*/
      a1: *(_QWORD *)&FLog::Clouds,
      a2: qword_10D7F3BA0,
      a3: "[FLog::Clouds] Setting clouds on workspace, %p",
      a2);
  RBX::shared_from<RBX::Instance>(a1: v6, a2); /*0x104f83e6c*/
  result = std::shared_ptr<RBX::Instance>::operator=[abi:ne200100](a1: (__int64)this + 1000, a2: v6); /*0x104f83e7e*/
  v5 = *((std::__shared_weak_count **)&v6[0] + 1); /*0x104f83e83*/
  if ( *((_QWORD *)&v6[0] + 1) != 0 ) /*0x104f83e8a*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v6[0] + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL); /*0x104f83e93*/
    if ( result == 0 ) /*0x104f83e9c*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x104f83ea4*/
      return std::__shared_weak_count::__release_weak(this: v5); /*0x104f83eaa*/
    }
  }
  return result; /*0x104f83eaf*/
}

// Address: 0x104f83ebc | Name: __ZN3RBX9Workspace28deprecatedSetTerrainCallbackEPNS_19MegaClusterInstanceE
__int64 __fastcall RBX::Workspace::deprecatedSetTerrainCallback(RBX::Workspace *this, RBX::MegaClusterInstance *a2)
{
  std::__shared_weak_count *v4; // r15
  __int64 result; // rax
  __int64 v6; // rdi
  std::__shared_weak_count *v7; // rbx
  _QWORD v8[2]; // [rsp+0h] [rbp-40h] BYREF
  __int128 v9; // [rsp+10h] [rbp-30h] BYREF

  if ( (unsigned __int8)FLog::MegaClusterInit >= 6u && BYTE1(FLog::MegaClusterInit) >= 3u ) /*0x104f83ee8*/
    FLog::FastLog( /*0x104f83efd*/
      a1: *(_QWORD *)&FLog::MegaClusterInit,
      a2: qword_10D7F3C70,
      a3: "[FLog::MegaClusterInit] Setting terrain on workspace, %p",
      a2);
  RBX::shared_from<RBX::MegaClusterInstance>(a1: v8, a2); /*0x104f83f0c*/
  std::shared_ptr<RBX::MegaClusterInstance>::operator=[abi:ne200100](a1: (char *)this + 1120 /* +1120 = networkOwnershipUnitChanged..head.px (rbx::signals::slot_base *, 8B) -- SIZE CONFLICT, see --verify */, a2: v8); /*0x104f83f1b*/
  v4 = (std::__shared_weak_count *)v8[1]; /*0x104f83f20*/
  if ( v8[1] != 0 && _InterlockedExchangeAdd64((volatile signed __int64 *)(v8[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f83f39*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(a1: v4); /*0x104f83f41*/
    std::__shared_weak_count::__release_weak(this: v4); /*0x104f83f47*/
  }
  result = RBX::Object::raisePropertyChanged( /*0x104f83f59*/
             this,
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_Terrain);
  if ( a2 != nullptr ) /*0x104f83f61*/
  {
    v6 = *((_QWORD *)this + 140) /* +1120 likely networkOwnershipUnitChanged..head.px -- UNVERIFIED */; /*0x104f83f63*/
    *(_BYTE *)(v6 + 170) |= 1u; /*0x104f83f6a*/
    v9 = 0; /*0x104f83f78*/
    result = RBX::Instance::setLockedParent(a1: v6, a2: this, a3: 0, a4: &v9); /*0x104f83f80*/
    v7 = *((std::__shared_weak_count **)&v9 + 1); /*0x104f83f85*/
    if ( *((_QWORD *)&v9 + 1) != 0 ) /*0x104f83f8c*/
    {
      result = _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v9 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL); /*0x104f83f95*/
      if ( result == 0 ) /*0x104f83f9e*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x104f83fa6*/
        return std::__shared_weak_count::__release_weak(this: v7); /*0x104f83fac*/
      }
    }
  }
  return result; /*0x104f83fb1*/
}

// Address: 0x104f84092 | Name: __ZThn1056_N3RBX9Workspace28deprecatedSetTerrainCallbackEPNS_19MegaClusterInstanceE
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetTerrainCallback(
        RBX::Workspace *this,
        RBX::MegaClusterInstance *a2)
{
  return RBX::Workspace::deprecatedSetTerrainCallback(this: (RBX::Workspace *)((char *)this - 1056), a2); /*0x104f8409d*/
}

// Address: 0x104f840a4 | Name: __ZN3RBX9Workspace21preSetTerrainCallbackEPNS_19MegaClusterInstanceE
int *__fastcall RBX::Workspace::preSetTerrainCallback(RBX::Workspace *this, RBX::MegaClusterInstance *a2)
{
  int *result; // rax

  result = &FLog::MegaClusterInit; /*0x104f840ab*/
  if ( (unsigned __int8)FLog::MegaClusterInit >= 6u && BYTE1(FLog::MegaClusterInit) >= 3u ) /*0x104f840c5*/
    return (int *)FLog::FastLog( /*0x104f840d9*/
                    a1: *(_QWORD *)&FLog::MegaClusterInit,
                    a2: qword_10D7F3C70,
                    a3: "[FLog::MegaClusterInit] Setting terrain on workspace, %p",
                    a2);
  return result; /*0x104f840d8*/
}

// Address: 0x104f840e0 | Name: __ZThn1056_N3RBX9Workspace21preSetTerrainCallbackEPNS_19MegaClusterInstanceE
int *__fastcall `non-virtual thunk to'RBX::Workspace::preSetTerrainCallback(
        RBX::Workspace *this,
        RBX::MegaClusterInstance *a2)
{
  int *result; // rax

  result = &FLog::MegaClusterInit; /*0x104f840e7*/
  if ( (unsigned __int8)FLog::MegaClusterInit >= 6u && BYTE1(FLog::MegaClusterInit) >= 3u ) /*0x104f84101*/
    return (int *)FLog::FastLog( /*0x104f84115*/
                    a1: *(_QWORD *)&FLog::MegaClusterInit,
                    a2: qword_10D7F3C70,
                    a3: "[FLog::MegaClusterInit] Setting terrain on workspace, %p",
                    a2);
  return result; /*0x104f84114*/
}

// Address: 0x104f8411c | Name: __ZN3RBX9Workspace29postPropSignalTerrainCallbackEv
__int64 __fastcall RBX::Workspace::postPropSignalTerrainCallback(RBX::Workspace *this)
{
  __int64 v2; // rdi
  __int64 result; // rax
  std::__shared_weak_count *v4; // rbx
  __int128 v5; // [rsp+0h] [rbp-20h] BYREF

  v2 = *((_QWORD *)this + 140) /* +1120 likely networkOwnershipUnitChanged..head.px -- UNVERIFIED */; /*0x104f84128*/
  if ( v2 != 0 ) /*0x104f84132*/
  {
    *(_BYTE *)(v2 + 170) |= 1u; /*0x104f84134*/
    v5 = 0; /*0x104f84142*/
    result = RBX::Instance::setLockedParent(a1: v2, a2: this, a3: 0, a4: &v5); /*0x104f84147*/
    v4 = *((std::__shared_weak_count **)&v5 + 1); /*0x104f8414c*/
    if ( *((_QWORD *)&v5 + 1) != 0 ) /*0x104f84153*/
    {
      result = _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v5 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL); /*0x104f8415c*/
      if ( result == 0 ) /*0x104f84165*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(a1: v4); /*0x104f8416d*/
        return std::__shared_weak_count::__release_weak(this: v4); /*0x104f84173*/
      }
    }
  }
  return result; /*0x104f84178*/
}

// Address: 0x104f84194 | Name: __ZThn1056_N3RBX9Workspace29postPropSignalTerrainCallbackEv
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::postPropSignalTerrainCallback(RBX::Workspace *this)
{
  return RBX::Workspace::postPropSignalTerrainCallback(this: (RBX::Workspace *)((char *)this - 1056)); /*0x104f8419f*/
}

// Address: 0x104f841a6 | Name: __ZN3RBX9Workspace13createTerrainEv
void __fastcall RBX::Workspace::createTerrain(RBX::Workspace *this)
{
  RBX::EngineContext *v1; // rdi
  RBX::Instance *v2; // r14
  __m128 PhysicalSize; // xmm0
  std::__shared_weak_count *v4; // rbx
  std::__shared_weak_count *v5; // rbx
  _QWORD v6[6]; // [rsp+0h] [rbp-80h] BYREF
  __int128 v7; // [rsp+30h] [rbp-50h] BYREF
  std::__shared_weak_count *v8[2]; // [rsp+40h] [rbp-40h]
  __int128 v9; // [rsp+50h] [rbp-30h]

  if ( *((_QWORD *)this + 140) /* +1120 likely networkOwnershipUnitChanged..head.px -- UNVERIFIED */ == 0 ) /*0x104f841bb*/
  {
    v1 = *(RBX::EngineContext **)&FLog::MegaClusterInit; /*0x104f841d2*/
    if ( (unsigned __int8)FLog::MegaClusterInit >= 6u && BYTE1(FLog::MegaClusterInit) >= 3u ) /*0x104f841e4*/
      FLog::FastLog( /*0x104f841f8*/
        a1: *(_QWORD *)&FLog::MegaClusterInit,
        a2: qword_10D7F3C70,
        a3: "[FLog::MegaClusterInit] Terrain doesn't exist - creating terrain instance explicitly",
        0);
    v6[0] = RBX::EngineContext::getThreadLocal(this: v1); /*0x104f84206*/
    LODWORD(v6[1]) = 10700; /*0x104f84209*/
    RBX::Creatable::createImpl<RBX::MegaClusterInstance,RBX::ForceConstructionInCreatable &>(a1: &v7); /*0x104f84217*/
    *(_OWORD *)v8 = v7; /*0x104f84223*/
    v2 = (RBX::Instance *)v7; /*0x104f8421c*/
    PhysicalSize = RBX::BasePart::getPhysicalSize(this: (RBX::BasePart *)v7); /*0x104f8422a*/
    *(_OWORD *)v6 = 0x3F800000u; /*0x104f84247*/
    *(_OWORD *)&v6[2] = 0x3F800000u; /*0x104f8424a*/
    v6[4] = 0xC00000003F800000LL; /*0x104f84256*/
    *(float *)&v6[5] = _mm_movehdup_ps(PhysicalSize).f32[0] * 0.5; /*0x104f8425b*/
    HIDWORD(v6[5]) = -1073741824; /*0x104f84260*/
    (*(void (__fastcall **)(RBX::Instance *, _QWORD *))(*(_QWORD *)v2 + 1392LL))(a1: v2, a2: v6); /*0x104f8426d*/
    v9 = 0; /*0x104f8427a*/
    RBX::Instance::setAndLockParent(this: v2); /*0x104f84285*/
    v4 = *((std::__shared_weak_count **)&v9 + 1); /*0x104f8428a*/
    if ( *((_QWORD *)&v9 + 1) != 0 /*0x104f842a3*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v9 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(a1: v4); /*0x104f842ab*/
      std::__shared_weak_count::__release_weak(this: v4); /*0x104f842b1*/
    }
    v5 = v8[1]; /*0x104f842b6*/
    if ( v8[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v8[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f842d3*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x104f842df*/
      std::__shared_weak_count::__release_weak(this: v5); /*0x104f842e5*/
    }
  }
}

// Address: 0x104f84314 | Name: __ZN3RBX9Workspace12clearTerrainEv
__int64 __fastcall RBX::Workspace::clearTerrain(RBX::Workspace *this)
{
  RBX::Instance *v2; // rdi
  RBX::Instance **v3; // rbx
  __int64 result; // rax

  v2 = *((RBX::Instance **)this + 140); /*0x104f8431d*/
  if ( v2 != nullptr ) /*0x104f84327*/
  {
    v3 = (RBX::Instance **)((char *)this + 1120 /* +1120 = networkOwnershipUnitChanged..head.px (rbx::signals::slot_base *, 8B) -- SIZE CONFLICT, see --verify */); /*0x104f84329*/
    if ( (unsigned __int8)FLog::MegaClusterInit >= 6u && BYTE1(FLog::MegaClusterInit) >= 3u ) /*0x104f84348*/
    {
      FLog::FastLog( /*0x104f84360*/
        a1: *(_QWORD *)&FLog::MegaClusterInit,
        a2: qword_10D7F3C70,
        a3: "[FLog::MegaClusterInit] Clearing terrain (from client replicator?)",
        0);
      v2 = *v3; /*0x104f84365*/
    }
    *((_BYTE *)v2 + 170) &= 0x1Eu; /*0x104f84368*/
    RBX::Instance::setParent(this: v2, a2: nullptr); /*0x104f84371*/
    return std::shared_ptr<RBX::MegaClusterInstance>::reset[abi:ne200100](a1: v3); /*0x104f8437f*/
  }
  return result; /*0x104f8437d*/
}

// Address: 0x104f843d2 | Name: __ZN3RBX9Workspace13zoomToExtentsEv
__int64 __fastcall RBX::Workspace::zoomToExtents(RBX::Workspace *this)
{
  RBX::Camera *v2; // r14
  const RBX::IComputeExtentsPartFilter *v3; // rcx
  _BYTE v5[24]; // [rsp+8h] [rbp-48h] BYREF
  _BYTE v6[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = (RBX::Camera *)(*(__int64 (__fastcall **)(RBX::Workspace *))(*(_QWORD *)this + 928 /* +7424: NO 2022 FIELD */LL))(a1: this); /*0x104f843eb*/
  RBX::ModelInstance::computeExtentsWorldWithFilter(this: (RBX::ModelInstance *)v6, a2: this, a3: nullptr, a4: v3); /*0x104f843fa*/
  RBX::Extents::clampInsideOf( /*0x104f84410*/
    this: (RBX::Extents *)v5,
    a2: (const RBX::Extents *)v6,
    a3: (__int64)&RBX::Tolerance::maxExtents(void)::millionCube);
  qmemcpy(v6, v5, 24); /*0x104f84419*/
  return RBX::Camera::zoomExtents(this: v2, a2: (RBX::Extents *)v6, a3: 0); /*0x104f84431*/
}

// Address: 0x104f8443c | Name: __ZN3RBX9Workspace18setImageServerViewEbRKNS_7ExtentsE
char __fastcall RBX::Workspace::setImageServerView(RBX::Workspace *this, int a2, const RBX::Extents *a3)
{
  __int64 FirstChildByName; // rax
  __int64 v6; // rdi
  RBX::Camera *v7; // r15
  __int64 v8; // r12
  __int64 v9; // rax
  RBX::WorkspaceProp *v10; // rdi
  RBX::Camera *v11; // rsi
  __int64 v13; // rax
  __int64 *v14; // rcx
  __int64 v15; // r15
  __int64 v16; // rax
  __int64 v17; // rdi
  RBX::Camera *v18; // r12
  __int64 v19; // r13
  __int64 v20; // rax
  __int64 v21; // rax
  __int64 v22; // r15
  __int64 v23; // r12
  __int64 v24; // rax
  __int64 v25; // rax
  __int64 v26; // r12
  __int64 v27; // r13
  __int64 v28; // rax
  __int64 v29; // rax
  __int64 v30; // r15
  __int64 v31; // r13
  __int64 v32; // rax
  __int64 Value; // rax
  __int64 v34; // rdi
  __int64 v35; // rsi
  __int64 v36; // r13
  __int64 v37; // rax
  __int64 v38; // rbx
  __int128 v39; // xmm0
  __int128 v40; // xmm1
  __int64 v41; // rdx
  __int64 v42; // rcx
  __int64 v43; // rsi
  __int64 v44; // r8
  __int64 v45; // r9
  _QWORD v46[12]; // [rsp+30h] [rbp-C0h] BYREF
  void *v47[2]; // [rsp+98h] [rbp-58h] BYREF
  void *v48; // [rsp+A8h] [rbp-48h]
  __int64 v49; // [rsp+B0h] [rbp-40h]
  __int64 v50; // [rsp+B8h] [rbp-38h]
  __int64 v51; // [rsp+C0h] [rbp-30h]

  if ( a2 != 0 ) /*0x104f84452*/
    return 0; /*0x104f84452*/
  std::string::basic_string[abi:ne200100]<0>(a1: v47, a2: "ThumbnailCamera"); /*0x104f8446c*/
  FirstChildByName = RBX::Instance::findFirstChildByName(a1: this, a2: v47, a3: 0); /*0x104f84479*/
  v7 = (RBX::Camera *)FirstChildByName; /*0x104f8447e*/
  if ( FirstChildByName != 0 ) /*0x104f84484*/
  {
    v8 = *(_QWORD *)(FirstChildByName + 24); /*0x104f84486*/
    v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::Camera>(a1: v6); /*0x104f8448a*/
    if ( *(unsigned __int16 *)(v8 + 440) - (unsigned int)*(unsigned __int16 *)(v9 + 440) > *(unsigned __int16 *)(v9 + 442) ) /*0x104f844ac*/
      v7 = nullptr; /*0x104f844ac*/
  }
  else
  {
    v7 = nullptr; /*0x104f844b2*/
  }
  if ( ((__int64)v47[0] & 1) != 0 ) /*0x104f844b9*/
    operator delete(a1: v48); /*0x104f844bf*/
  if ( v7 != nullptr ) /*0x104f844c7*/
  {
    v10 = (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */); /*0x104f844d0*/
    v11 = v7; /*0x104f844d3*/
LABEL_11:
    RBX::WorkspaceProp::setCurrentCamera(this: v10, a2: v11); /*0x104f844d6*/
    return 0; /*0x104f844ee*/
  }
  v13 = *((_QWORD *)this + 15) /* +120: NO 2022 FIELD */; /*0x104f844ef*/
  if ( v13 != 0 ) /*0x104f844f6*/
  {
    v14 = *(__int64 **)v13; /*0x104f844fc*/
    if ( *(_QWORD *)(v13 + 8) != *(_QWORD *)v13 ) /*0x104f84503*/
    {
      v15 = *v14; /*0x104f84509*/
      if ( *v14 != 0 ) /*0x104f8450f*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: v47, a2: "ThumbnailCamera"); /*0x104f84523*/
        v16 = RBX::Instance::findFirstChildByName(a1: v15, a2: v47, a3: 0); /*0x104f84530*/
        v18 = (RBX::Camera *)v16; /*0x104f84535*/
        if ( v16 != 0 ) /*0x104f8453b*/
        {
          v19 = *(_QWORD *)(v16 + 24); /*0x104f8453d*/
          v20 = RBX::Reflection::Class_getDescriptorPtr<RBX::Camera>(a1: v17); /*0x104f84542*/
          if ( *(unsigned __int16 *)(v19 + 440) - (unsigned int)*(unsigned __int16 *)(v20 + 440) > *(unsigned __int16 *)(v20 + 442) ) /*0x104f84563*/
            v18 = nullptr; /*0x104f84563*/
        }
        else
        {
          v18 = nullptr; /*0x104f84569*/
        }
        if ( ((__int64)v47[0] & 1) != 0 ) /*0x104f84570*/
          operator delete(a1: v48); /*0x104f84576*/
        if ( v18 != nullptr ) /*0x104f8457e*/
        {
          v10 = (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */); /*0x104f84587*/
          v11 = v18; /*0x104f8458a*/
          goto LABEL_11; /*0x104f8458d*/
        }
        std::string::basic_string[abi:ne200100]<0>(a1: v47, a2: "ThumbnailConfiguration"); /*0x104f845a0*/
        v21 = RBX::Instance::findFirstChildByName(a1: v15, a2: v47, a3: 0); /*0x104f845ad*/
        v22 = v21; /*0x104f845b2*/
        if ( v21 != 0 ) /*0x104f845b8*/
        {
          v23 = *(_QWORD *)(v21 + 24); /*0x104f845ba*/
          v24 = RBX::Reflection::Class_getDescriptorPtr<RBX::Configuration>(); /*0x104f845be*/
          if ( *(unsigned __int16 *)(v23 + 440) - (unsigned int)*(unsigned __int16 *)(v24 + 440) > *(unsigned __int16 *)(v24 + 442) ) /*0x104f845e0*/
            v22 = 0; /*0x104f845e0*/
        }
        else
        {
          v22 = 0; /*0x104f845e6*/
        }
        if ( ((__int64)v47[0] & 1) != 0 ) /*0x104f845ed*/
          operator delete(a1: v48); /*0x104f845f3*/
        if ( v22 != 0 ) /*0x104f845fb*/
        {
          std::string::basic_string[abi:ne200100]<0>(a1: v47, a2: "ThumbnailCameraTarget"); /*0x104f8460f*/
          v25 = RBX::Instance::findFirstChildByName(a1: v22, a2: v47, a3: 0); /*0x104f8461c*/
          v26 = v25; /*0x104f84621*/
          if ( v25 != 0 ) /*0x104f84627*/
          {
            v27 = *(_QWORD *)(v25 + 24); /*0x104f84629*/
            v28 = RBX::Reflection::Class_getDescriptorPtr<RBX::ObjectValue>(); /*0x104f8462e*/
            if ( *(unsigned __int16 *)(v27 + 440) - (unsigned int)*(unsigned __int16 *)(v28 + 440) > *(unsigned __int16 *)(v28 + 442) ) /*0x104f8464f*/
              v26 = 0; /*0x104f8464f*/
          }
          else
          {
            v26 = 0; /*0x104f84655*/
          }
          if ( ((__int64)v47[0] & 1) != 0 ) /*0x104f8465c*/
            operator delete(a1: v48); /*0x104f84662*/
          std::string::basic_string[abi:ne200100]<0>(a1: v47, a2: "ThumbnailCameraValue"); /*0x104f84675*/
          v29 = RBX::Instance::findFirstChildByName(a1: v22, a2: v47, a3: 0); /*0x104f84682*/
          v30 = v29; /*0x104f84687*/
          if ( v29 != 0 ) /*0x104f8468d*/
          {
            v31 = *(_QWORD *)(v29 + 24); /*0x104f8468f*/
            v32 = RBX::Reflection::Class_getDescriptorPtr<RBX::CFrameValue>(); /*0x104f84693*/
            if ( *(unsigned __int16 *)(v31 + 440) - (unsigned int)*(unsigned __int16 *)(v32 + 440) > *(unsigned __int16 *)(v32 + 442) ) /*0x104f846b4*/
              v30 = 0; /*0x104f846b4*/
          }
          else
          {
            v30 = 0; /*0x104f846ba*/
          }
          if ( ((__int64)v47[0] & 1) != 0 ) /*0x104f846c1*/
            operator delete(a1: v48); /*0x104f846c7*/
          if ( v26 != 0 && v30 != 0 ) /*0x104f846d4*/
          {
            Value = RBX::ObjectValueProp::getValue(this: (RBX::ObjectValueProp *)(v26 + 176)); /*0x104f846e0*/
            if ( Value != 0 ) /*0x104f846e8*/
            {
              v36 = *(_QWORD *)(Value + 24); /*0x104f846ed*/
              v37 = RBX::Reflection::Class_getDescriptorPtr<RBX::BasePart>(a1: v34, a2: v35); /*0x104f846f1*/
              if ( *(unsigned __int16 *)(v36 + 440) - (unsigned int)*(unsigned __int16 *)(v37 + 440) <= *(unsigned __int16 *)(v37 + 442) ) /*0x104f84710*/
              {
                RBX::Workspace::replenishCamera(this); /*0x104f8472f*/
                v38 = (*(__int64 (__fastcall **)(RBX::Workspace *))(*(_QWORD *)this + 928 /* +7424: NO 2022 FIELD */LL))(a1: this) + 184; /*0x104f84745*/
                RBX::BasePartProp::getCoordinateFrame(this: (RBX::BasePartProp *)v46); /*0x104f84759*/
                v39 = *(_OWORD *)(v30 + 184); /*0x104f8475e*/
                v40 = *(_OWORD *)(v30 + 200); /*0x104f84766*/
                *(_OWORD *)&v46[10] = *(_OWORD *)(v30 + 216); /*0x104f8477d*/
                *(_OWORD *)&v46[8] = v40; /*0x104f84781*/
                *(_OWORD *)&v46[6] = v39; /*0x104f84785*/
                RBX::CoordinateFrame::operatorMul_SIMD( /*0x104f84792*/
                  this: (RBX::CoordinateFrame *)v47,
                  a2: (const RBX::CoordinateFrame *)v46);
                RBX::CameraProp::setCameraCoordinateFrame( /*0x104f847b6*/
                  a1: v38,
                  a2: v43,
                  a3: v41,
                  a4: v42,
                  a5: v44,
                  a6: v45,
                  a7: v47[0],
                  a8: v47[1],
                  a9: v48,
                  a10: v49,
                  a11: v50,
                  a12: v51);
                return 0; /*0x104f847bb*/
              }
            }
          }
        }
      }
    }
  }
  RBX::Workspace::replenishCamera(this); /*0x104f84715*/
  RBX::Workspace::focusOnRenderableChildren(this, a2: a3); /*0x104f84720*/
  return 1; /*0x104f844dd*/
}

// Address: 0x104f847e2 | Name: __ZN3RBX9Workspace25focusOnRenderableChildrenERKNS_7ExtentsE
bool __fastcall RBX::Workspace::focusOnRenderableChildren(RBX::Workspace *this, const RBX::Extents *a2)
{
  _QWORD *v2; // rdx
  __int64 v3; // r13
  bool result; // al
  __int64 v5; // r15
  __int64 i; // r13
  const void *v8; // r14
  _QWORD *v9; // r12
  void *v10; // rbx
  void *v11; // rax
  RBX::Camera *v12; // rax
  _BYTE v13[48]; // [rsp+8h] [rbp-68h] BYREF
  RBX::Extents *v14; // [rsp+38h] [rbp-38h]
  RBX::Workspace *v15; // [rsp+40h] [rbp-30h]

  v14 = a2; /*0x104f847f3*/
  v15 = this; /*0x104f847f7*/
  v2 = *((_QWORD **)this + 15); /*0x104f847fb*/
  if ( v2 != nullptr ) /*0x104f84802*/
    v3 = (__int64)(v2[1] - *v2) >> 4; /*0x104f8480b*/
  else
    v3 = 0; /*0x104f84811*/
  result = false; /*0x104f84814*/
  v5 = v3 + 1; /*0x104f8481e*/
  for ( i = (v3 << 32) - 0x100000000LL; v5-- > 1; i -= 0x100000000LL ) /*0x104f84826*/
  {
    v8 = *(const void **)(*v2 + (i >> 28)); /*0x104f8483c*/
    if ( v8 != nullptr ) /*0x104f84843*/
    {
      v9 = v2; /*0x104f8484f*/
      v10 = __dynamic_cast( /*0x104f84865*/
              lpsrc: *(const void **)(*v2 + (i >> 28)),
              lpstype: (const struct __class_type_info *)&`typeinfo for'RBX::Instance,
              lpdtype: (const struct __class_type_info *)&`typeinfo for'RBX::IHasLocation,
              s2d: -2);
      v11 = __dynamic_cast( /*0x104f84880*/
              lpsrc: v8,
              lpstype: (const struct __class_type_info *)&`typeinfo for'RBX::Instance,
              lpdtype: (const struct __class_type_info *)&`typeinfo for'RBX::IAdornable,
              s2d: -2);
      v2 = v9; /*0x104f84885*/
      result = v11 == nullptr; /*0x104f8488b*/
    }
    else
    {
      result = true; /*0x104f84890*/
      v10 = nullptr; /*0x104f84892*/
    }
    if ( v10 != nullptr && !result ) /*0x104f848a8*/
    {
      (**(void (__fastcall ***)(_BYTE *, void *, _QWORD *))v10)(a1: v13, a2: v10, a3: v2); /*0x104f848bb*/
      v12 = (RBX::Camera *)(*(__int64 (__fastcall **)(RBX::Workspace *))(*(_QWORD *)v15 + 928LL))(a1: v15); /*0x104f848c4*/
      return RBX::Camera::setImageServerViewNoLerp(this: v12, a2: (const RBX::CoordinateFrame *)v13, a3: v14, a4: 1); /*0x104f848d9*/
    }
  }
  return result; /*0x104f848de*/
}

// Address: 0x104f848ee | Name: __ZN3RBX9Workspace17processTouchEventEv
__int64 __fastcall RBX::Workspace::processTouchEvent(RBX::World **this)
{
  int v1; // eax
  bool v2; // r12
  __int64 v3; // rax
  RBX::World *v4; // r15
  unsigned __int8 *v5; // rbx
  RBX::World **v6; // r14
  RBX::World **v7; // rcx
  RBX::World *v8; // rax
  unsigned __int8 *v9; // r15
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // r8
  __int64 v13; // r9
  __int64 v14; // rax
  bool v15; // zf
  bool v16; // cc
  RBX::World *v18; // [rsp+0h] [rbp-90h] BYREF
  unsigned __int8 *v19; // [rsp+8h] [rbp-88h]
  RBX::World *v20; // [rsp+10h] [rbp-80h]
  RBX::World **v21; // [rsp+18h] [rbp-78h] BYREF
  __int64 v22; // [rsp+20h] [rbp-70h]
  RBX::World **v23; // [rsp+28h] [rbp-68h]
  _QWORD v24[4]; // [rsp+30h] [rbp-60h] BYREF
  _QWORD *v25; // [rsp+50h] [rbp-40h]

  v23 = this; /*0x104f8490d*/
  v1 = *(_DWORD *)RBX::World::getSimSendFilter(this: *(this + 118)); /*0x104f8491d*/
  if ( FFlag::SAuthWorkspacePropertyEnabled == 1 && FFlag::SAuthWorkspaceFlagged != 0 ) /*0x104f84932*/
    v2 = *((_DWORD *)v23 + 287) == 1 && (unsigned int)(v1 - 3) < 2; /*0x104f8494c*/
  else
    v2 = (unsigned int)(v1 - 3) < 2; /*0x104f84957*/
  v24[0] = off_10C9F1998; /*0x104f84971*/
  v24[1] = v23; /*0x104f84974*/
  v25 = v24; /*0x104f84978*/
  RBX::WorldTouchCollector::processCoalescedTouches(a1: v23 + 166, a2: v24); /*0x104f8497f*/
  if ( v25 == v24 ) /*0x104f8498b*/
  {
    v3 = 32; /*0x104f84999*/
    goto LABEL_9; /*0x104f84999*/
  }
  v3 = 40; /*0x104f8498d*/
  if ( v25 != nullptr ) /*0x104f84995*/
LABEL_9:
    (*(void (**)(void))(*v25 + v3))(); /*0x104f8499e*/
  v4 = v23[223]; /*0x104f849a4*/
  v5 = (unsigned __int8 *)v23[224]; /*0x104f849af*/
  if ( v4 != (RBX::World *)v5 ) /*0x104f849b9*/
  {
    v6 = v23 + 226; /*0x104f849c3*/
    v22 = 0; /*0x104f849ca*/
    do /*0x104f84aa4*/
    {
      v7 = v23; /*0x104f849d2*/
      v23[223] = nullptr; /*0x104f849d8*/
      v18 = v4; /*0x104f849df*/
      v7[224] = nullptr; /*0x104f849e6*/
      v19 = v5; /*0x104f849ed*/
      v8 = v7[225]; /*0x104f849f4*/
      v7[225] = nullptr; /*0x104f849fb*/
      v20 = v8; /*0x104f84a02*/
      v9 = (unsigned __int8 *)v4 + 16; /*0x104f84a06*/
      do /*0x104f84a69*/
      {
        RBX::BasePart::fireTouchSignals(this: *((RBX::PartComponentHelpers **)v9 - 2), a2: (RBX::BasePart *)v9); /*0x104f84a1b*/
        RBX::BasePart::fireTouchSignals(this: *(RBX::PartComponentHelpers **)v9, a2: (RBX::BasePart *)(v9 - 16)); /*0x104f84a34*/
        if ( v2 ) /*0x104f84a3c*/
        {
          v14 = RBX::DenseHashMap<RBX::SignalPair,RBX::TouchStateManager,RBX::Hash<RBX::SignalPair>,std::equal_to<RBX::SignalPair>>::operator[]( /*0x104f84a44*/
                  a1: v6,
                  a2: v9 - 16,
                  a3: v10,
                  a4: v11,
                  a5: v12,
                  a6: v13,
                  a7: v18,
                  a8: v19,
                  a9: v20);
          RBX::TouchStateManager::stepState(a1: v14, a2: v9[16], a3: v9[17]); /*0x104f84a56*/
        }
        v15 = v9 + 24 == v5; /*0x104f84a63*/
        v9 += 40; /*0x104f84a66*/
      }
      while ( !v15 ); /*0x104f84a69*/
      v21 = &v18; /*0x104f84a72*/
      std::vector<std::pair<RBX::SignalPair,std::pair<RBX::TouchEventType,bool>>>::__destroy_vector::operator()[abi:ne200100](a1: &v21); /*0x104f84a7a*/
      v4 = v23[223]; /*0x104f84a83*/
      v5 = (unsigned __int8 *)v23[224]; /*0x104f84a8a*/
      if ( v4 == (RBX::World *)v5 ) /*0x104f84a94*/
        break; /*0x104f84a94*/
      v16 = (unsigned int)v22 <= 2; /*0x104f84a9d*/
      v22 = (unsigned int)(v22 + 1); /*0x104f84aa0*/
    }
    while ( v16 ); /*0x104f84aa4*/
  }
  return __stack_chk_guard; /*0x104f84aba*/
}

// Address: 0x104f84b10 | Name: __ZNK3RBX9Workspace38isServerAuthorityPropertyEnabledUNSAFEEv
bool __fastcall RBX::Workspace::isServerAuthorityPropertyEnabledUNSAFE(RBX::Workspace *this)
{
  if ( FFlag::SAuthWorkspacePropertyEnabled != 1 ) /*0x104f84b17*/
    return false; /*0x104f84b35*/
  if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x104f84b27*/
    return *((_DWORD *)this + 287) /* +1148: NO 2022 FIELD */ != 1; /*0x104f84b30*/
  return false; /*0x104f84b37*/
}

// Address: 0x104f84bda | Name: __ZN3RBX9Workspace10makeJointsENSt3__110shared_ptrIKNS1_6vectorINS2_INS_8InstanceEEENS1_9allocatorIS5_EEEEEE
__int64 __fastcall RBX::Workspace::makeJoints(__int64 a1, __int64 **a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6)
{
  __int64 *v6; // rax
  __int64 v7; // rsi
  __int64 v8; // rdx
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  _BYTE v15[32]; // [rsp+0h] [rbp-110h] BYREF
  _QWORD v16[4]; // [rsp+20h] [rbp-F0h] BYREF
  _QWORD *v17; // [rsp+40h] [rbp-D0h]
  _BYTE v18[32]; // [rsp+50h] [rbp-C0h] BYREF
  _BYTE *v19; // [rsp+70h] [rbp-A0h]
  _QWORD v20[4]; // [rsp+80h] [rbp-90h] BYREF
  _QWORD *v21; // [rsp+A0h] [rbp-70h]
  __int128 v22; // [rsp+B0h] [rbp-60h] BYREF
  __int128 v23; // [rsp+C0h] [rbp-50h]
  __int128 v24; // [rsp+D0h] [rbp-40h]

  v24 = 0; /*0x104f84c01*/
  v23 = 0; /*0x104f84c05*/
  v22 = 0; /*0x104f84c09*/
  memset(v15, 0, 24); /*0x104f84c13*/
  v20[0] = off_10C9F1A28; /*0x104f84c2d*/
  v20[1] = v20; /*0x104f84c31*/
  v20[2] = &v22; /*0x104f84c36*/
  v20[3] = v15; /*0x104f84c3b*/
  v21 = v20; /*0x104f84c40*/
  v6 = *a2; /*0x104f84c45*/
  v7 = **a2; /*0x104f84c48*/
  v8 = v6[1]; /*0x104f84c4b*/
  v17 = v16; /*0x104f84c56*/
  v16[0] = off_10C9F1A28; /*0x104f84c5a*/
  v16[1] = v20; /*0x104f84c62*/
  v16[2] = &v22; /*0x104f84c6b*/
  v16[3] = v15; /*0x104f84c6f*/
  std::for_each[abi:ne200100]<std::__wrap_iter<std::shared_ptr<RBX::Instance> const*>,std::function<void ()(std::shared_ptr<RBX::Instance>)>>( /*0x104f84c80*/
    a1: v18,
    a2: v7,
    a3: v8,
    a4: v16,
    a5,
    a6,
    a7: 0,
    a8: 0,
    a9: 0);
  if ( v19 == v18 ) /*0x104f84c8f*/
  {
    v11 = 32; /*0x104f84c9d*/
    goto LABEL_5; /*0x104f84c9d*/
  }
  v11 = 40; /*0x104f84c91*/
  if ( v19 != nullptr ) /*0x104f84c99*/
LABEL_5:
    (*(void (**)(void))(*(_QWORD *)v19 + v11))(); /*0x104f84ca2*/
  if ( v17 == v16 ) /*0x104f84cb2*/
  {
    v12 = 32; /*0x104f84cc0*/
    goto LABEL_10; /*0x104f84cc0*/
  }
  v12 = 40; /*0x104f84cb4*/
  if ( v17 != nullptr ) /*0x104f84cbc*/
LABEL_10:
    (*(void (**)(void))(*v17 + v12))(); /*0x104f84cc5*/
  RBX::WorldRoot::parentDeferredJoints(a1: &v22, a2: v15, a3: v9, a4: v10); /*0x104f84ccb*/
  if ( v21 == v20 ) /*0x104f84ce5*/
  {
    v13 = 32; /*0x104f84cf3*/
    goto LABEL_15; /*0x104f84cf3*/
  }
  v13 = 40; /*0x104f84ce7*/
  if ( v21 != nullptr ) /*0x104f84cef*/
LABEL_15:
    (*(void (**)(void))(*v21 + v13))(); /*0x104f84cf8*/
  v20[0] = v15; /*0x104f84cfe*/
  std::vector<std::pair<std::shared_ptr<RBX::JointInstance>,std::shared_ptr<RBX::BasePart>>>::__destroy_vector::operator()[abi:ne200100](a1: v20); /*0x104f84d08*/
  if ( (_QWORD)v22 != 0 ) /*0x104f84d14*/
  {
    *((_QWORD *)&v22 + 1) = v22; /*0x104f84d16*/
    operator delete(a1: (void *)v22); /*0x104f84d1a*/
  }
  return __stack_chk_guard; /*0x104f84d2f*/
}

// Address: 0x104f84e78 | Name: __ZN3RBX9Workspace11breakJointsENSt3__110shared_ptrIKNS1_6vectorINS2_INS_8InstanceEEENS1_9allocatorIS5_EEEEEE
_QWORD *__fastcall RBX::Workspace::breakJoints(__int64 a1, _QWORD *a2)
{
  _QWORD *result; // rax
  _QWORD *v3; // r15
  _QWORD *v4; // r12
  volatile signed __int64 *v5; // r14
  _QWORD v6[6]; // [rsp+0h] [rbp-30h] BYREF

  result = (_QWORD *)*a2; /*0x104f84e87*/
  if ( DFFlag::SimWorkspaceBreakJointsFix != 1 ) /*0x104f84e91*/
    return (_QWORD *)std::for_each[abi:ne200100]<std::__wrap_iter<std::shared_ptr<RBX::Instance> const*>,void (*)(std::shared_ptr<RBX::Instance>)>( /*0x104f84f26*/
                       a1: *result,
                       a2: result[1],
                       a3: RBX::wrapper<false>);
  if ( result != nullptr ) /*0x104f84e96*/
  {
    v3 = (_QWORD *)*result; /*0x104f84e98*/
    v4 = (_QWORD *)result[1]; /*0x104f84e9b*/
    if ( (_QWORD *)*result != v4 ) /*0x104f84ea2*/
    {
      do /*0x104f84efd*/
      {
        result = (_QWORD *)*v3; /*0x104f84ea8*/
        if ( *v3 != 0 ) /*0x104f84eae*/
        {
          v6[0] = *v3; /*0x104f84eb0*/
          v5 = (volatile signed __int64 *)v3[1]; /*0x104f84eb4*/
          v6[1] = v5; /*0x104f84eb8*/
          if ( v5 != nullptr ) /*0x104f84ebf*/
            _InterlockedIncrement64(v5 + 1); /*0x104f84ec1*/
          result = (_QWORD *)RBX::wrapper<false>(a1: v6); /*0x104f84ec9*/
          if ( v5 != nullptr ) /*0x104f84ed1*/
          {
            result = (_QWORD *)_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x104f84eda*/
            if ( result == nullptr ) /*0x104f84ee3*/
            {
              (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(a1: v5); /*0x104f84eeb*/
              result = (_QWORD *)std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v5); /*0x104f84ef1*/
            }
          }
        }
        v3 += 2; /*0x104f84ef6*/
      }
      while ( v3 != v4 ); /*0x104f84efd*/
    }
  }
  return result; /*0x104f84eff*/
}

// Address: 0x104f8504e | Name: __ZN3RBX9Workspace5startEv
void __fastcall RBX::Workspace::start(RBX::Workspace *this)
{
  RBX::Constraints::GizmoManager::setShowConstraintDetails( /*0x104f85060*/
    this: *((RBX::Constraints::GizmoManager **)this + 272),
    a2: false);
  RBX::World::assemble(this: *((RBX::ContactManager ***)this + 118)); /*0x104f85072*/
}

// Address: 0x104f85078 | Name: __ZN3RBX9Workspace8assembleEv
void __fastcall RBX::Workspace::assemble(RBX::ContactManager ***this)
{
  RBX::World::assemble(this: *(this + 118)); /*0x104f85084*/
}

// Address: 0x104f8508a | Name: __ZN3RBX9Workspace4stopEv
__int64 __fastcall RBX::Workspace::stop(RBX::Workspace *this)
{
  return RBX::Workspace::updateDistributedGameTime(this); /*0x104f8508e*/
}

// Address: 0x104f85094 | Name: __ZN3RBX9Workspace25updateDistributedGameTimeEv
__int64 __fastcall RBX::Workspace::updateDistributedGameTime(RBX::Workspace *this, const RBX::Instance *a2)
{
  RBX::ServiceProvider *ServiceProvider; // rax
  const RBX::Instance *v4; // rsi
  __int64 v5; // r14

  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2); /*0x104f8509e*/
  if ( ServiceProvider != nullptr ) /*0x104f850a6*/
    v5 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::RunService>(this: ServiceProvider); /*0x104f850b0*/
  else
    v5 = 0; /*0x104f850b5*/
  if ( RBX::DataModel::serverIsPresent(this, a2: v4) != 0 ) /*0x104f850c2*/
    return RBX::WorkspaceProp::setDistributedGameTime( /*0x104f850db*/
             this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */),
             a2: *(double *)(v5 + 264));
  else
    return RBX::WorkspaceProp::setDistributedGameTimeSetOnly( /*0x104f850f7*/
             this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */),
             a2: *(double *)(v5 + 264));
}

// Address: 0x104f850fc | Name: __ZN3RBX9Workspace5resetEv
__int64 __fastcall RBX::Workspace::reset(RBX::Workspace *this, const RBX::Instance *a2)
{
  __int64 result; // rax

  RBX::Workspace::updateDistributedGameTime(this, a2); /*0x104f85105*/
  result = *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */; /*0x104f8510a*/
  *(_DWORD *)(result + 232) = 0; /*0x104f85111*/
  return result; /*0x104f8511f*/
}

// Address: 0x104f85122 | Name: __ZN3RBX9Workspace17handleFallenPartsEv
void __fastcall RBX::Workspace::handleFallenParts(RBX::Workspace *this)
{
  __int64 v2; // r14
  const RBX::Instance *v3; // rsi
  const RBX::Instance *v4; // rsi
  RBX::Primitive ***v5; // r14
  RBX::Primitive ***i; // r12
  __int64 v7; // r15
  __int64 j; // r14
  RBX::Primitive ***v9; // r14
  RBX::Primitive ***v10; // r15
  unsigned __int8 v11; // r8
  __int64 Token; // r14
  _QWORD v13[13]; // [rsp+0h] [rbp-B0h] BYREF
  _BYTE v14[8]; // [rsp+68h] [rbp-48h] BYREF
  __int128 v15; // [rsp+70h] [rbp-40h] BYREF
  __int64 v16; // [rsp+80h] [rbp-30h]
  __int128 *v17; // [rsp+88h] [rbp-28h] BYREF

  if ( DFFlag::FallHeightToggle != 1 || *((_BYTE *)this + 1297) /* +1297: NO 2022 FIELD */ == 1 ) /*0x104f85147*/
  {
    if ( (_BYTE)`guard variable for'RBX::Workspace::handleFallenParts(void)::proftoken1793 == 0 /*0x104f852ec*/
      && __cxa_guard_acquire(a1: &`guard variable for'RBX::Workspace::handleFallenParts(void)::proftoken1793) != 0 )
    {
      v13[0] = "etType {}"; /*0x104f85315*/
      Token = RBX::Profiler::getToken( /*0x104f85339*/
                this: (RBX::Profiler *)&aStatusremoved[-239529],
                a2: &aDflogLargerepl_36[-149508],
                a3: (const char *)0xFFFFFFFFLL,
                a4: 255,
                a5: v11);
      RBX::Profiler::PerFrameTelemetry::activateForTelemetry(a1: Token); /*0x104f8533f*/
      RBX::Workspace::handleFallenParts(void)::proftoken1793 = Token; /*0x104f85344*/
      __cxa_guard_release(a1: &`guard variable for'RBX::Workspace::handleFallenParts(void)::proftoken1793); /*0x104f85352*/
    }
    v2 = RBX::Workspace::handleFallenParts(void)::proftoken1793; /*0x104f8515b*/
    *(_OWORD *)v13 = 0; /*0x104f8516c*/
    v13[3] = -1; /*0x104f8516f*/
    memset(&v13[4], 0, 52); /*0x104f85177*/
    *(_OWORD *)&v13[11] = 0; /*0x104f8518a*/
    v13[2] = RBX::Workspace::handleFallenParts(void)::proftoken1793; /*0x104f8518e*/
    RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v13); /*0x104f85192*/
    v13[3] = RBX::Profiler::PerFrameTelemetry::enterTelemetryRegion(a1: v2, a2: v14, a3: 1); /*0x104f851ab*/
    RBX::World::gatherFallen(a1: *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */, a2: (__int64)this + 2152); /*0x104f851c0*/
    if ( (unsigned int)RBX::Players::getGameMode(this, a2: v3) == 1 ) /*0x104f851d0*/
    {
      if ( DFFlag::SimExecuteClientOnlyFallenParts == 1 ) /*0x104f851dd*/
      {
        v15 = 0; /*0x104f851e6*/
        v16 = 0; /*0x104f851ea*/
        v5 = *((RBX::Primitive ****)this + 269); /*0x104f851f2*/
        for ( i = *((RBX::Primitive ****)this + 270); v5 != i; v5 += 2 ) /*0x104f85203*/
        {
          if ( (unsigned __int8)RBX::NetworkUtil::isNonReplicatedClientLocalOnly(this: (RBX::NetworkUtil *)*v5, a2: v4) != 0 ) /*0x104f85213*/
          {
            std::vector<std::shared_ptr<RBX::BasePart>>::emplace_back<std::shared_ptr<RBX::BasePart> const&>( /*0x104f8521b*/
              a1: &v15,
              a2: v5);
          }
          else
          {
            RBX::BasePart::setReplicationRootPart(this: *v5, a2: nullptr); /*0x104f85227*/
            RBX::BasePart::setNetworkOwnerAndNotify(a1: (RBX::Object *)*v5, a2: 1); /*0x104f85234*/
          }
        }
        RBX::Workspace::destroyFallenParts(a1: this, a2: &v15); /*0x104f8524c*/
        v17 = &v15; /*0x104f85255*/
        std::vector<std::shared_ptr<RBX::BasePart>>::__destroy_vector::operator()[abi:ne200100](a1: &v17); /*0x104f85258*/
      }
      else
      {
        v9 = *((RBX::Primitive ****)this + 269); /*0x104f852ae*/
        v10 = *((RBX::Primitive ****)this + 270); /*0x104f852b5*/
        while ( v9 != v10 ) /*0x104f852bf*/
        {
          RBX::BasePart::setReplicationRootPart(this: *v9, a2: nullptr); /*0x104f852c6*/
          RBX::BasePart::setNetworkOwnerAndNotify(a1: (RBX::Object *)*v9, a2: 1); /*0x104f852d3*/
          v9 += 2; /*0x104f852d8*/
        }
      }
    }
    else
    {
      RBX::Workspace::destroyFallenParts(a1: this, a2: (char *)this + 2152 /* +2152: NO 2022 FIELD */); /*0x104f85265*/
    }
    v7 = *((_QWORD *)this + 269) /* +2152: NO 2022 FIELD */; /*0x104f8526a*/
    for ( j = *((_QWORD *)this + 270) /* +2160: NO 2022 FIELD */; j != v7; std::shared_ptr<RBX::BasePart>::~shared_ptr[abi:ne200100](a1: j) ) /*0x104f85271*/
      j -= 16; /*0x104f8527d*/
    *((_QWORD *)this + 270) /* +2160: NO 2022 FIELD */ = v7; /*0x104f8528b*/
    RBX::Profiler::TelemetryScope::~TelemetryScope(this: (RBX::Profiler::TelemetryScope *)v13); /*0x104f85299*/
  }
}

// Address: 0x104f8539e | Name: __ZN3RBX9Workspace18destroyFallenPartsERKNSt3__16vectorINS1_10shared_ptrINS_8BasePartEEENS1_9allocatorIS5_EEEE
__int64 __fastcall RBX::Workspace::destroyFallenParts(__int64 a1, RBX::Instance ***a2)
{
  RBX::Instance **v4; // rax
  RBX::Instance **v5; // rcx
  __int64 v6; // rdx
  std::__shared_weak_count *v7; // r15
  RBX::Instance **v8; // r14
  RBX::Instance **i; // r12
  std::__shared_weak_count *v10; // r13
  __int64 v11; // rax
  __int64 v12; // rcx
  __int64 v13; // rdx
  unsigned __int64 v14; // rdx
  __int64 *v15; // r15
  unsigned __int64 v16; // r12
  __int64 v17; // rax
  __int64 v18; // rcx
  unsigned __int64 v19; // rcx
  __int64 *v20; // rsi
  __int64 v21; // rdi
  std::__shared_weak_count *v22; // rbx
  __int128 v24; // [rsp+0h] [rbp-80h] BYREF
  __int64 v25; // [rsp+10h] [rbp-70h]
  _QWORD v26[5]; // [rsp+18h] [rbp-68h] BYREF
  std::__shared_weak_count *v27; // [rsp+40h] [rbp-40h]

  if ( FFlag::FixSpanningTreeBulkDestroyHang == 1 ) /*0x104f853cd*/
  {
    v4 = *a2; /*0x104f853cf*/
    v5 = a2[1]; /*0x104f853d3*/
    while ( v4 != v5 ) /*0x104f853db*/
    {
      v6 = *((_QWORD *)*v4 + 47); /*0x104f853e0*/
      if ( v6 != 0 ) /*0x104f853ea*/
        *(_BYTE *)(v6 + 613) |= 4u; /*0x104f853ec*/
      v4 += 2; /*0x104f853f3*/
    }
  }
  v24 = 0; /*0x104f85400*/
  RBX::detail::DenseHashTable<std::shared_ptr<RBX::Instance>,std::shared_ptr<RBX::Instance>,std::shared_ptr<RBX::Instance>,RBX::detail::ItemInterfaceSet<std::shared_ptr<RBX::Instance>>,RBX::Hash<std::shared_ptr<RBX::Instance>>,std::equal_to<std::shared_ptr<RBX::Instance>>>::DenseHashTable( /*0x104f85409*/
    a1: v26,
    a2: &v24,
    a3: 0);
  v7 = *((std::__shared_weak_count **)&v24 + 1); /*0x104f8540e*/
  if ( *((_QWORD *)&v24 + 1) != 0 /*0x104f85427*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v24 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x104f8542f*/
    std::__shared_weak_count::__release_weak(this: v7); /*0x104f85435*/
  }
  v8 = *a2; /*0x104f8543a*/
  v25 = (__int64)a2; /*0x104f8543e*/
  for ( i = a2[1]; v8 != i; v8 += 2 ) /*0x104f8544a*/
  {
    RBX::shared_from<RBX::Instance>(a1: &v24, a2: *((_QWORD *)*v8 + 13)); /*0x104f8545a*/
    RBX::DenseHashSet<std::shared_ptr<RBX::Instance>,RBX::Hash<std::shared_ptr<RBX::Instance>>,std::equal_to<std::shared_ptr<RBX::Instance>>>::insert( /*0x104f85466*/
      a1: v26,
      a2: &v24);
    v10 = *((std::__shared_weak_count **)&v24 + 1); /*0x104f8546b*/
    if ( *((_QWORD *)&v24 + 1) != 0 /*0x104f85484*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v24 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x104f8548d*/
      std::__shared_weak_count::__release_weak(this: v10); /*0x104f85493*/
    }
    RBX::Instance::setParent(this: *v8, a2: nullptr); /*0x104f8549d*/
  }
  if ( FFlag::FixSpanningTreeBulkDestroyHang != 0 ) /*0x104f854b5*/
  {
    v11 = *(_QWORD *)v25; /*0x104f854bb*/
    v12 = *(_QWORD *)(v25 + 8); /*0x104f854be*/
    while ( v11 != v12 ) /*0x104f854c5*/
    {
      v13 = *(_QWORD *)(*(_QWORD *)v11 + 376LL); /*0x104f854ca*/
      if ( v13 != 0 ) /*0x104f854d4*/
        *(_BYTE *)(v13 + 613) &= ~4u; /*0x104f854d6*/
      v11 += 16; /*0x104f854dd*/
    }
  }
  v15 = (__int64 *)RBX::detail::DenseHashTable<std::shared_ptr<RBX::Instance>,std::shared_ptr<RBX::Instance>,std::shared_ptr<RBX::Instance>,RBX::detail::ItemInterfaceSet<std::shared_ptr<RBX::Instance>>,RBX::Hash<std::shared_ptr<RBX::Instance>>,std::equal_to<std::shared_ptr<RBX::Instance>>>::begin(a1: v26); /*0x104f854ef*/
  v16 = v14; /*0x104f854f2*/
  v25 = (__int64)(v26[1] - v26[0]) >> 4; /*0x104f85501*/
  if ( v15 != v26 || v14 != v25 ) /*0x104f8550e*/
  {
    v17 = *v15; /*0x104f85510*/
    do /*0x104f85583*/
    {
      v18 = *(_QWORD *)(v17 + 16 * v16); /*0x104f8551e*/
      do /*0x104f8552e*/
        v18 = *(_QWORD *)(v18 + 104); /*0x104f85522*/
      while ( v18 != a1 && v18 != 0 ); /*0x104f8552e*/
      if ( v18 == a1 ) /*0x104f85533*/
      {
        RBX::removeEmptyModels(a1: v17 + 16 * v16); /*0x104f85535*/
        v17 = *v15; /*0x104f8553a*/
      }
      v19 = (v15[1] - v17) >> 4; /*0x104f85544*/
      if ( v19 <= v16 + 1 ) /*0x104f85550*/
        v19 = v16 + 1; /*0x104f85550*/
      v20 = (__int64 *)(v17 + 16 * v16 + 16); /*0x104f8555c*/
      while ( v19 - 1 != v16 ) /*0x104f85563*/
      {
        ++v16; /*0x104f85565*/
        v21 = *v20; /*0x104f85568*/
        v20 += 2; /*0x104f8556b*/
        if ( v21 != v15[4] ) /*0x104f85573*/
          goto LABEL_36; /*0x104f85573*/
      }
      v16 = v19; /*0x104f85577*/
LABEL_36:
      ; /*0x104f8557a*/
    }
    while ( v15 != v26 || v16 != v25 ); /*0x104f85583*/
  }
  v22 = v27; /*0x104f85585*/
  if ( v27 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v27 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8559e*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v22 + 16LL))(a1: v22); /*0x104f855a6*/
    std::__shared_weak_count::__release_weak(this: v22); /*0x104f855ac*/
  }
  *(_QWORD *)&v24 = v26; /*0x104f855b5*/
  std::vector<std::shared_ptr<RBX::Instance>>::__destroy_vector::operator()[abi:ne200100](a1: (void ***)&v24); /*0x104f855b8*/
  return __stack_chk_guard; /*0x104f855cd*/
}

// Address: 0x104f85780 | Name: __ZN3RBX9Workspace37allWorldsForceUpdateBroadPhaseIfDirtyEv
__int64 __fastcall RBX::Workspace::allWorldsForceUpdateBroadPhaseIfDirty(RBX::Workspace *this)
{
  __int64 result; // rax
  __int64 v3; // r14
  __int64 v4; // rbx

  result = RBX::ContactManager::forceUpdateBroadPhaseIfDirty(this: *(RBX::World ***)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 2056LL)); /*0x104f85798*/
  v3 = *((_QWORD *)this + 235) /* +1880 likely taskQueue.._Rep -- UNVERIFIED */; /*0x104f8579d*/
  v4 = *((_QWORD *)this + 236) /* +1888 likely stepTouch..head.px -- UNVERIFIED */; /*0x104f857a4*/
  while ( v3 != v4 ) /*0x104f857ae*/
  {
    result = RBX::ContactManager::forceUpdateBroadPhaseIfDirty(this: *(RBX::World ***)(*(_QWORD *)(*(_QWORD *)v3 + 944LL) /*0x104f857c1*/
                                                                                     + 2056LL));
    v3 += 8; /*0x104f857c6*/
  }
  return result; /*0x104f857cc*/
}

// Address: 0x104f857d2 | Name: __ZN3RBX9Workspace44updatePhysicsStepsRequiredForCyclicExecutiveEfb
__int64 __fastcall RBX::Workspace::updatePhysicsStepsRequiredForCyclicExecutive(RBX::World **this, float a2, char a3)
{
  return RBX::World::updateStepsRequiredForCyclicExecutive(this: *(this + 118), a2, a3); /*0x104f857dd*/
}

// Address: 0x104f857e4 | Name: __ZN3RBX9Workspace32setPhysicsStepsForManualSteppingEi
void __fastcall RBX::Workspace::setPhysicsStepsForManualStepping(RBX::World **this, int a2)
{
  RBX::World::setStepsForManualStepping(this: *(this + 118), a2); /*0x104f857f0*/
}

// Address: 0x104f857f6 | Name: __ZN3RBX9Workspace8addWorldEPNS_10WorldModelE
__int64 __fastcall RBX::Workspace::addWorld(RBX::Workspace *this, RBX::WorldModel *a2)
{
  __int64 v4; // rdi
  __int64 v5; // rax
  std::__shared_weak_count *v6; // r15
  __int128 v8; // [rsp+10h] [rbp-30h] BYREF

  v4 = *((_QWORD *)a2 + 118); /*0x104f85809*/
  v5 = *((_QWORD *)this + 298) /* +2384: NO 2022 FIELD */; /*0x104f85810*/
  v8 = *(_OWORD *)((char *)this + 2376 /* +2376: NO 2022 FIELD */); /*0x104f8581f*/
  if ( v5 != 0 ) /*0x104f85826*/
    _InterlockedIncrement64((volatile signed __int64 *)(v5 + 8)); /*0x104f85828*/
  std::shared_ptr<RBX::TaskQueue>::operator=[abi:ne200100](a1: v4 + 1008, a2: &v8); /*0x104f8583b*/
  v6 = *((std::__shared_weak_count **)&v8 + 1); /*0x104f85840*/
  if ( *((_QWORD *)&v8 + 1) != 0 /*0x104f85859*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v8 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x104f85861*/
    std::__shared_weak_count::__release_weak(this: v6); /*0x104f85867*/
  }
  *((_DWORD *)a2 + 265) = (*((_QWORD *)this + 236) /* +1888 likely stepTouch..head.px -- UNVERIFIED */ - *((_QWORD *)this + 235) /* +1880 likely taskQueue.._Rep -- UNVERIFIED */) >> 3; /*0x104f8588c*/
  return std::vector<RBX::WorldModel *,RSL::Detail::Allocator<RBX::WorldModel *>>::push_back[abi:ne200100](a1: (char *)this + 1880 /* +1880 = taskQueue.._Rep (std::_Ref_count_base *, 8B) -- SIZE CONFLICT, see --verify */); /*0x104f85897*/
}

// Address: 0x104f858a2 | Name: __ZN3RBX9Workspace11removeWorldEPNS_10WorldModelE
char __fastcall RBX::Workspace::removeWorld(RBX::Workspace *this, RBX::WorldModel *a2)
{
  int v2; // r8d
  char result; // al
  __int64 v4; // rcx
  __int64 v5; // rdx
  __int64 v6; // rdx

  v2 = *((_DWORD *)a2 + 265); /*0x104f858a2*/
  result = v2 < 0; /*0x104f858ac*/
  if ( ((v2 < 0) & (unsigned __int8)DFFlag::WorkspaceSkipUnregisteredWorldRemove) == 0 ) /*0x104f858b5*/
  {
    result = *((_DWORD *)a2 + 265); /*0x104f858bb*/
    v4 = *((_QWORD *)this + 235) /* +1880 likely taskQueue.._Rep -- UNVERIFIED */; /*0x104f858c5*/
    v5 = *((_QWORD *)this + 236) /* +1888 likely stepTouch..head.px -- UNVERIFIED */; /*0x104f858cc*/
    if ( FFlag::IndexArrayValidateItemSlot == 0 || v2 >= 0 && (v5 - v4) >> 3 > (unsigned __int64)v2 ) /*0x104f858eb*/
    {
      v6 = *(_QWORD *)(v5 - 8); /*0x104f858ed*/
      *(_QWORD *)(v4 + 8LL * v2) = v6; /*0x104f858f1*/
      *(_DWORD *)(v6 + 1060) = v2; /*0x104f858f5*/
      *((_QWORD *)this + 236) /* +1888 likely stepTouch..head.px -- UNVERIFIED */ -= 8LL; /*0x104f858fb*/
      *((_DWORD *)a2 + 265) = -1; /*0x104f85903*/
    }
  }
  return result; /*0x104f8590e*/
}

// Address: 0x104f85910 | Name: __ZN3RBX9Workspace11physicsStepEv
float __fastcall RBX::Workspace::physicsStep(RBX::Workspace *this, const RBX::Instance *a2)
{
  RBX::DataModel *v2; // r13
  RBX::AuroraService *v3; // rax
  RBX::Instance *v4; // rsi
  const RBX::Instance *v5; // rsi
  char v6; // al
  RBX::ServiceProvider *ServiceProvider; // rax
  __int64 v8; // rax
  __int64 v9; // rdi
  RBX::AuroraService *v10; // rdi
  RBX::Instance *v11; // rsi
  RBX::DataModel *v12; // rax
  RBX::Instance *v13; // rsi
  RBX::Players *v14; // rdi
  __int64 LocalPlayer; // rax
  __int64 v16; // r14
  __int64 v17; // rdi
  __int64 v18; // rdi
  RBX::WorldModel **v19; // rbx
  RBX::WorldModel **v20; // r14
  double v21; // xmm0_8
  const RBX::Instance *v22; // rsi
  __int64 v23; // r14
  __int64 v24; // rcx
  RBX::Instance *v25; // rsi
  __int64 v26; // rdx
  __int64 v27; // rax
  __int64 v28; // rax
  RBX::Assembly **v29; // rbx
  RBX::Assembly *v30; // r14
  unsigned int v31; // eax
  char v32; // r15
  __int64 v33; // rbx
  RBX::Assembly *v34; // r14
  RBX::BasePart *v35; // r14
  RBX::Primitive *v36; // rsi
  __int64 v37; // rax
  unsigned __int64 v38; // rax
  volatile signed __int64 *v39; // r13
  __int64 v40; // rax
  unsigned __int64 v41; // rax
  volatile signed __int64 *v42; // r14
  __int64 v43; // rax
  __int64 i; // r14
  __int64 v45; // rsi
  __int64 v46; // rbx
  __int64 v47; // r13
  RBX::DataModel *v48; // r15
  std::__shared_weak_count *v49; // rdi
  std::__shared_weak_count *v50; // rax
  volatile signed __int64 *v51; // r12
  std::__shared_weak_count *v52; // r14
  RBX::DataModel *v53; // rax
  unsigned __int64 v54; // rdx
  RBX::ServiceProvider *v55; // rax
  __int64 v56; // rbx
  __int64 v57; // r14
  unsigned __int8 v59; // r8
  __int64 Token; // r14
  unsigned __int8 v61; // r8
  __int64 v62; // r14
  unsigned __int8 v63; // r8
  __int64 v64; // r14
  double v65[13]; // [rsp+0h] [rbp-310h] BYREF
  _BYTE v66[8]; // [rsp+68h] [rbp-2A8h] BYREF
  __int64 AssemblyPrimitive; // [rsp+70h] [rbp-2A0h]
  RBX::Assembly **v68; // [rsp+78h] [rbp-298h]
  RBX::Assembly **v69; // [rsp+80h] [rbp-290h]
  __int64 v70; // [rsp+88h] [rbp-288h]
  __int64 v71; // [rsp+90h] [rbp-280h]
  char *v72; // [rsp+98h] [rbp-278h]
  float v73; // [rsp+A4h] [rbp-26Ch]
  double v74; // [rsp+A8h] [rbp-268h]
  std::__shared_weak_count *v75[2]; // [rsp+B0h] [rbp-260h] BYREF
  RBX::DataModel *v76; // [rsp+C0h] [rbp-250h]
  unsigned __int8 v77; // [rsp+CEh] [rbp-242h]
  char v78; // [rsp+CFh] [rbp-241h] BYREF
  __int128 v79; // [rsp+D0h] [rbp-240h] BYREF
  _QWORD v80[11]; // [rsp+E0h] [rbp-230h] BYREF
  _BYTE v81[424]; // [rsp+138h] [rbp-1D8h] BYREF

  v2 = this; /*0x104f85924*/
  if ( FFlag::DebugHashTableMetrics != 0 /*0x104f8595a*/
    || (FFlag::SAuthWorkspaceFlagged & 1) != 0
    || FFlag::NextGenReplicatorEnabledRead == 1 )
  {
    RBX::WorkspaceSynchHelper::processQueuedSynchData(this: (RBX::Workspace *)((char *)this + 2392 /* +2392: NO 2022 FIELD */)); /*0x104f85963*/
    if ( DFFlag::AuroraCheckServerViewInFixedStep == 0 ) /*0x104f8596f*/
    {
      RBX::World::getEngineNetConfiguration(this: (RBX::World *)&v79, a2: *((_QWORD *)v2 + 118)); /*0x104f8597f*/
      if ( FFlag::DebugHashTableMetrics == 1 || FFlag::SAuthWorkspaceFlagged != 0 && (v79 & 8) != 0 ) /*0x104f859af*/
      {
        v3 = (RBX::AuroraService *)RBX::ServiceProvider::find<RBX::AuroraService>(a1: v2); /*0x104f8598d*/
        if ( v3 != nullptr ) /*0x104f85995*/
          RBX::AuroraService::checkServerViewAndRollback(this: v3); /*0x104f8599a*/
      }
    }
  }
  RBX::Workspace::updateDistributedGameTime(this: v2, a2); /*0x104f859b4*/
  if ( FFlag::SimTurbulentFlow == 1 ) /*0x104f859c3*/
  {
    RBX::World::getEngineNetConfiguration(this: (RBX::World *)&v79, a2: *((_QWORD *)v2 + 118)); /*0x104f859d7*/
    if ( FFlag::DebugHashTableMetrics == 1 ) /*0x104f859e0*/
    {
      v6 = FFlag::SAuthWorkspaceFlagged; /*0x104f859e2*/
    }
    else
    {
      v6 = FFlag::SAuthWorkspaceFlagged; /*0x104f85a05*/
      if ( FFlag::SAuthWorkspaceFlagged == 0 || (v79 & 8) == 0 ) /*0x104f85a14*/
      {
        v9 = *((_QWORD *)v2 + 118); /*0x104f85a16*/
        *(float *)&v76 = (float)*(int *)(v9 + 232); /*0x104f85a25*/
        RBX::SteppingParameters::worldStepDt(this: (RBX::SteppingParameters *)(v9 + 1692)); /*0x104f85a34*/
        RBX::World::setAirModelTime<false>(a1: *((_QWORD *)v2 + 118)); /*0x104f85a4b*/
        goto LABEL_22; /*0x104f85a50*/
      }
    }
    if ( (v6 & 1) != 0 ) /*0x104f859e8*/
    {
      ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v2, a2: v5); /*0x104f859ed*/
      if ( ServiceProvider == nullptr ) /*0x104f859f5*/
      {
        v10 = nullptr; /*0x104f8618f*/
        goto LABEL_21; /*0x104f86191*/
      }
      v8 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::AuroraService>(this: ServiceProvider); /*0x104f859fe*/
    }
    else
    {
      v8 = RBX::ServiceProvider::find<RBX::AuroraService>(a1: v2); /*0x104f85a55*/
    }
    v10 = (RBX::AuroraService *)v8; /*0x104f85a5a*/
LABEL_21:
    RBX::AuroraService::getCurrentSimulationStepId(this: v10); /*0x104f85a5d*/
    RBX::World::setAirModelTime<true>(a1: *((_QWORD *)v2 + 118)); /*0x104f85a75*/
  }
LABEL_22:
  RBX::Workspace::applyDeferredTerrainChanges(this: v2, a2: v4); /*0x104f85a7a*/
  if ( FFlag::PGSSolverFileDump == 1 ) /*0x104f85a8c*/
  {
    v12 = RBX::DataModel::get(this: v2, a2: v11); /*0x104f85a91*/
    v14 = (RBX::DataModel *)((char *)v12 + 464); /*0x104f85a96*/
    if ( v12 == nullptr ) /*0x104f85aa0*/
      v14 = nullptr; /*0x104f85aa0*/
    LocalPlayer = RBX::Players::findLocalPlayer(this: v14, a2: v13); /*0x104f85aa4*/
    if ( LocalPlayer != 0 && FFlag::MigrateUserIdAccessors != 1 ) /*0x104f85ab8*/
      RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(LocalPlayer + 176)); /*0x104f85ad0*/
    RBX::World::setUserId(this: *((RBX::World **)v2 + 118)); /*0x104f85adf*/
  }
  v76 = v2; /*0x104f85aec*/
  if ( (_BYTE)`guard variable for'RBX::Workspace::physicsStep(void)::proftoken1996 == 0 /*0x104f862d1*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Workspace::physicsStep(void)::proftoken1996) != 0 )
  {
    *(_QWORD *)&v79 = "setAssetChecksumVerboseProb"; /*0x104f862fa*/
    Token = RBX::Profiler::getToken( /*0x104f8631e*/
              this: (RBX::Profiler *)&aQcomboboxPaddi[-672964],
              a2: &aNetassetassetc_0[-146722],
              a3: (const char *)0xFFFFFFFFLL,
              a4: 255,
              a5: v59);
    RBX::Profiler::PerFrameTelemetry::activateForTelemetry(a1: Token); /*0x104f86324*/
    RBX::Workspace::physicsStep(void)::proftoken1996 = Token; /*0x104f86329*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Workspace::physicsStep(void)::proftoken1996); /*0x104f86337*/
    v2 = v76; /*0x104f8633c*/
  }
  v16 = RBX::Workspace::physicsStep(void)::proftoken1996; /*0x104f85af9*/
  v79 = 0; /*0x104f85b0a*/
  v80[1] = -1; /*0x104f85b0d*/
  memset(&v80[2], 0, 52); /*0x104f85b15*/
  *(_OWORD *)&v80[9] = 0; /*0x104f85b28*/
  v80[0] = RBX::Workspace::physicsStep(void)::proftoken1996; /*0x104f85b2c*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)&v79); /*0x104f85b30*/
  v80[1] = RBX::Profiler::PerFrameTelemetry::enterTelemetryRegion(a1: v16, a2: v81, a3: 1); /*0x104f85b50*/
  v74 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v17); /*0x104f85b58*/
  v73 = RBX::World::step( /*0x104f85b88*/
          this: *((RBX::World **)v2 + 118),
          a2: 1,
          a3: *((double *)v2 + 142),
          a4: *((RBX::TaskQueue **)v2 + 297),
          a5: *((_QWORD *)v2 + 406));
  ++*((_QWORD *)v2 + 406); /*0x104f85b90*/
  v19 = *((RBX::WorldModel ***)v2 + 235); /*0x104f85b97*/
  v20 = *((RBX::WorldModel ***)v2 + 236); /*0x104f85b9e*/
  while ( v19 != v20 ) /*0x104f85ba8*/
    RBX::WorldModel::onStepped(this: *v19++, a2: *((double *)v2 + 142), a3: *((RBX::TaskQueue **)v2 + 297)); /*0x104f85bbd*/
  v21 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v18); /*0x104f85bc8*/
  RBX::RunningAverage<double,double>::sample(a1: (__int64)v2 + 2280, a2: v21 - v74); /*0x104f85bdc*/
  RBX::Profiler::TelemetryScope::~TelemetryScope(this: (RBX::Profiler::TelemetryScope *)&v79); /*0x104f85be8*/
  RBX::Workspace::handleFallenParts(this: v2); /*0x104f85bf0*/
  RBX::Workspace::processTouchEvent(this: (RBX::World **)v2); /*0x104f85bf8*/
  if ( DFFlag::CollisionSummaryCLI151929 == 1 ) /*0x104f85c04*/
    RBX::Workspace::dispatchCollisionSummaryCallbacks(this: v2); /*0x104f85c09*/
  RBX::World::getEngineNetConfiguration(this: (RBX::World *)&v79, a2: *((_QWORD *)v2 + 118)); /*0x104f85c1c*/
  if ( FFlag::DebugHashTableMetrics == 0 ) /*0x104f85c25*/
  {
    if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x104f86146*/
    {
      if ( (v79 & 8) == 0 && FFlag::NextGenReplicatorEnabledWrite == 0 && (v79 & 1) == 0 ) /*0x104f86169*/
        goto LABEL_111; /*0x104f86169*/
    }
    else if ( FFlag::NextGenReplicatorEnabledRead == 0 || FFlag::NextGenReplicatorEnabledWrite != 1 ) /*0x104f86187*/
    {
      goto LABEL_111; /*0x104f86187*/
    }
  }
  if ( (_BYTE)`guard variable for'RBX::Workspace::physicsStep(void)::proftoken2021 == 0 /*0x104f86356*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Workspace::physicsStep(void)::proftoken2021) != 0 )
  {
    *(_QWORD *)&v79 = "tion documentation object"; /*0x104f8637f*/
    v62 = RBX::Profiler::getToken( /*0x104f863a3*/
            this: (RBX::Profiler *)&aBadPbmIteratio[-847204],
            a2: &aOverloadsIsNot[-682222],
            a3: (const char *)0xFFFFFFFFLL,
            a4: 255,
            a5: v61);
    RBX::Profiler::PerFrameTelemetry::activateForTelemetry(a1: v62); /*0x104f863a9*/
    RBX::Workspace::physicsStep(void)::proftoken2021 = v62; /*0x104f863ae*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Workspace::physicsStep(void)::proftoken2021); /*0x104f863bc*/
    v2 = v76; /*0x104f863c1*/
  }
  v23 = RBX::Workspace::physicsStep(void)::proftoken2021; /*0x104f85c39*/
  *(_OWORD *)v65 = 0; /*0x104f85c4b*/
  v65[3] = NAN; /*0x104f85c4f*/
  memset(&v65[4], 0, 52); /*0x104f85c57*/
  *(_OWORD *)&v65[11] = 0; /*0x104f85c6d*/
  *(_QWORD *)&v65[2] = RBX::Workspace::physicsStep(void)::proftoken2021; /*0x104f85c72*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v65); /*0x104f85c76*/
  *(_QWORD *)&v65[3] = RBX::Profiler::PerFrameTelemetry::enterTelemetryRegion(a1: v23, a2: v66, a3: 1); /*0x104f85c96*/
  v24 = RBX::World::getSpatialFilter(this: *((RBX::World **)v2 + 118)) + 176; /*0x104f85cae*/
  v72 = (char *)v2 + 3216; /*0x104f85cbc*/
  LOBYTE(v26) = DFFlag::AlwaysSendRootMovingPrimitiveForChildPrimitive ^ 1; /*0x104f85cc3*/
  v77 = DFFlag::AlwaysSendRootMovingPrimitiveForChildPrimitive ^ 1; /*0x104f85cc6*/
  v27 = 0; /*0x104f85ccc*/
  v70 = v24; /*0x104f85cd5*/
  do /*0x104f85f9f*/
  {
    v71 = v27; /*0x104f85cdc*/
    v28 = 3 * v27; /*0x104f85ce3*/
    v29 = *(RBX::Assembly ***)(v24 + 8 * v28); /*0x104f85ce7*/
    v69 = *(RBX::Assembly ***)(v24 + 8 * v28 + 8); /*0x104f85cf0*/
    if ( v29 != v69 ) /*0x104f85cfa*/
    {
      LOBYTE(v74) = v71 != 2; /*0x104f85d08*/
      do /*0x104f85f84*/
      {
        v30 = *v29; /*0x104f85d0f*/
        AssemblyPrimitive = RBX::Assembly::getAssemblyPrimitive(this: *v29); /*0x104f85d1a*/
        v68 = v29; /*0x104f85d21*/
        *(_QWORD *)&v79 = v80; /*0x104f85d2f*/
        *((_QWORD *)&v79 + 1) = 0x4000000000LL; /*0x104f85d40*/
        RBX::SmallVectorTemplateBase<RBX::IndexedMesh *,true>::push_back(a1: &v79, a2: (char *)v30 + 16); /*0x104f85d51*/
        v31 = DWORD2(v79); /*0x104f85d56*/
        v32 = 0; /*0x104f85d5c*/
        do /*0x104f85f54*/
        {
          if ( ((unsigned __int64)v31 - 1) >> 32 != 0 ) /*0x104f85d6c*/
            RBXCRASH(a1: 0, a2: ""); /*0x104f8613a*/
          v33 = *(_QWORD *)(v79 + 8LL * v31 - 8); /*0x104f85d79*/
          DWORD2(v79) = v31 - 1; /*0x104f85d7e*/
          v34 = (RBX::Assembly *)(v33 - 16); /*0x104f85d84*/
          if ( v33 == 0 ) /*0x104f85d8b*/
            v34 = nullptr; /*0x104f85d8b*/
          if ( RBX::Assembly::checkShouldReplicatePV(this: v34) != 0 ) /*0x104f85d99*/
          {
            v35 = (RBX::BasePart *)RBX::Assembly::getAssemblyPrimitive(this: v34); /*0x104f85da7*/
            v37 = RBX::BasePart::fromPrimitive(this: v35, a2: v36); /*0x104f85dad*/
            RBX::shared_from<RBX::BasePart>(a1: v75, a2: v37); /*0x104f85dbc*/
            v78 = LOBYTE(v74); /*0x104f85dc7*/
            v38 = *((_QWORD *)v2 + 403); /*0x104f85dcd*/
            if ( v38 >= *((_QWORD *)v2 + 404) ) /*0x104f85ddb*/
            {
              v40 = std::vector<std::pair<std::weak_ptr<RBX::BasePart>,bool>,RSL::Detail::Allocator<std::pair<std::weak_ptr<RBX::BasePart>,bool>>>::__emplace_back_slow_path<std::shared_ptr<RBX::BasePart>,bool>( /*0x104f85e1e*/
                      a1: v72,
                      a2: v75,
                      a3: &v78);
              v39 = (volatile signed __int64 *)v75[1]; /*0x104f85e23*/
            }
            else
            {
              v39 = (volatile signed __int64 *)v75[1]; /*0x104f85ddd*/
              *(_OWORD *)v38 = *(_OWORD *)v75; /*0x104f85dec*/
              if ( v39 != nullptr ) /*0x104f85df3*/
                _InterlockedIncrement64(v39 + 2); /*0x104f85df5*/
              *(_BYTE *)(v38 + 16) = LOBYTE(v74); /*0x104f85e00*/
              v40 = v38 + 24; /*0x104f85e03*/
            }
            *((_QWORD *)v76 + 403) = v40; /*0x104f85e31*/
            if ( v39 != nullptr && _InterlockedExchangeAdd64(v39 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f85e4d*/
            {
              (*(void (__fastcall **)(volatile signed __int64 *))(*v39 + 16))(a1: v39); /*0x104f85e56*/
              std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v39); /*0x104f85e5c*/
            }
            v2 = v76; /*0x104f85e6c*/
            if ( ((v77 | (unsigned __int8)v32) & 1) == 0 ) /*0x104f85e73*/
            {
              v32 = 1; /*0x104f85e79*/
              if ( v35 != (RBX::BasePart *)AssemblyPrimitive ) /*0x104f85e86*/
              {
                RBX::shared_from<RBX::BasePart>(a1: v75, a2: *(_QWORD *)(AssemblyPrimitive + 528)); /*0x104f85e9a*/
                v78 = 0; /*0x104f85e9f*/
                v41 = *((_QWORD *)v2 + 403); /*0x104f85ea6*/
                if ( v41 >= *((_QWORD *)v2 + 404) ) /*0x104f85eb4*/
                {
                  v43 = std::vector<std::pair<std::weak_ptr<RBX::BasePart>,bool>,RSL::Detail::Allocator<std::pair<std::weak_ptr<RBX::BasePart>,bool>>>::__emplace_back_slow_path<std::shared_ptr<RBX::BasePart>,bool>( /*0x104f85ef2*/
                          a1: v72,
                          a2: v75,
                          a3: &v78);
                  v42 = (volatile signed __int64 *)v75[1]; /*0x104f85ef7*/
                }
                else
                {
                  v42 = (volatile signed __int64 *)v75[1]; /*0x104f85eb6*/
                  *(_OWORD *)v41 = *(_OWORD *)v75; /*0x104f85ec5*/
                  if ( v42 != nullptr ) /*0x104f85ecc*/
                    _InterlockedIncrement64(v42 + 2); /*0x104f85ece*/
                  *(_BYTE *)(v41 + 16) = 0; /*0x104f85ed3*/
                  v43 = v41 + 24; /*0x104f85ed7*/
                }
                *((_QWORD *)v2 + 403) = v43; /*0x104f85efe*/
                if ( v42 != nullptr && _InterlockedExchangeAdd64(v42 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f85f1a*/
                {
                  (*(void (__fastcall **)(volatile signed __int64 *))(*v42 + 16))(a1: v42); /*0x104f85f22*/
                  std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v42); /*0x104f85f28*/
                }
              }
            }
          }
          for ( i = *(unsigned int *)(v33 + 24); (int)i > 0; --i ) /*0x104f85f2d*/
          {
            v45 = *(_QWORD *)(*(_QWORD *)(v33 + 16) + 8 * i - 8); /*0x104f85f3a*/
            RBX::SmallVectorTemplateBase<RBX::IndexedMesh *,true>::push_back(a1: &v79, a2: v45); /*0x104f85f45*/
          }
          v31 = DWORD2(v79); /*0x104f85f4c*/
        }
        while ( DWORD2(v79) != 0 ); /*0x104f85f54*/
        if ( (_QWORD *)v79 != v80 ) /*0x104f85f6b*/
          operator delete(a1: (void *)v79); /*0x104f85f6d*/
        v29 = v68 + 1; /*0x104f85f79*/
      }
      while ( v68 + 1 != v69 ); /*0x104f85f84*/
    }
    v27 = v71 + 1; /*0x104f85f91*/
    v24 = v70; /*0x104f85f98*/
  }
  while ( v71 != 2 ); /*0x104f85f9f*/
  v46 = *((_QWORD *)v2 + 402); /*0x104f85fa5*/
  v47 = *((_QWORD *)v2 + 403); /*0x104f85fac*/
  if ( v46 != v47 ) /*0x104f85fb6*/
  {
    *(_QWORD *)&v74 = (char *)v76 + 3264; /*0x104f85fc9*/
    v48 = nullptr; /*0x104f85fd0*/
    while ( 1 ) /*0x104f85fd3*/
    {
      v49 = *(std::__shared_weak_count **)(v46 + 8); /*0x104f85fd3*/
      if ( v49 != nullptr ) /*0x104f85fda*/
      {
        v50 = (std::__shared_weak_count *)std::__shared_weak_count::lock(this: v49); /*0x104f85fe0*/
        v75[1] = v50; /*0x104f85fe5*/
        if ( v50 != nullptr ) /*0x104f85fef*/
        {
          v51 = (volatile signed __int64 *)v50; /*0x104f85ff5*/
          v52 = *(std::__shared_weak_count **)v46; /*0x104f85ff8*/
          v75[0] = v52; /*0x104f85ffb*/
          if ( v52 == nullptr ) /*0x104f86005*/
            goto LABEL_82; /*0x104f86005*/
          if ( DFFlag::UseLowerFrequencyForISRPhysicsOnlyMode != 1 /*0x104f86043*/
            || DFFlag::DeferTriggerReplicationPVDirtySignal != 1
            || (RBX::World::getEngineNetConfiguration(this: (RBX::World *)&v79, a2: *((_QWORD *)v76 + 118)),
                FFlag::DebugHashTableMetrics != 0) )
          {
LABEL_81:
            RBX::BasePart::triggerReplicationPVDirtySignals(this: v52); /*0x104f86045*/
            v48 = (RBX::DataModel *)((char *)v48 + *(unsigned __int8 *)(v46 + 16)); /*0x104f86051*/
LABEL_82:
            if ( _InterlockedExchangeAdd64(v51 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f86065*/
            {
              (*(void (__fastcall **)(volatile signed __int64 *))(*v51 + 16))(a1: v51); /*0x104f8606e*/
              std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v51); /*0x104f86074*/
            }
            goto LABEL_84; /*0x104f86074*/
          }
          if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x104f86095*/
          {
            if ( (v79 & 8) != 0 /*0x104f860c0*/
              || (v79 & 1) == 0 && FFlag::NextGenReplicatorEnabledWrite == 0
              || FFlag::DebugNextGenRepUsePropBlacklist != 0
              || (v79 & 4) != 0 )
            {
              goto LABEL_81; /*0x104f860c0*/
            }
          }
          else if ( FFlag::NextGenReplicatorEnabledRead == 0 /*0x104f860ee*/
                 || FFlag::NextGenReplicatorEnabledWrite == 0
                 || FFlag::DebugNextGenRepUsePropBlacklist != 0 )
          {
            goto LABEL_81; /*0x104f860ee*/
          }
          RBX::DenseMapBase<RBX::DenseMap<RBX::Guid,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<RBX::Guid,void>,RBX::detail::DenseSetPair<RBX::Guid>>,RBX::Guid,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<RBX::Guid,void>,RBX::detail::DenseSetPair<RBX::Guid>>::try_emplace<RBX::detail::DenseSetEmpty&>( /*0x104f86110*/
            a1: &v79,
            a2: *(_QWORD *)&v74,
            a3: (char *)v52 + 48,
            a4: &v78);
          v51 = (volatile signed __int64 *)v75[1]; /*0x104f86115*/
          v48 = (RBX::DataModel *)((char *)v48 + *(unsigned __int8 *)(v46 + 16)); /*0x104f86120*/
          if ( v75[1] != nullptr ) /*0x104f86126*/
            goto LABEL_82; /*0x104f86126*/
        }
      }
LABEL_84:
      v46 += 24; /*0x104f86079*/
      if ( v46 == v47 ) /*0x104f86080*/
      {
        if ( v48 != nullptr ) /*0x104f86199*/
        {
          v53 = RBX::DataModel::get(this: v76, a2: v25); /*0x104f861a2*/
          RBX::PhysicsStep::updateSimAssemblyCount(this: v53, a2: v48, a3: v54); /*0x104f861ad*/
        }
        break; /*0x104f861ad*/
      }
    }
  }
  std::vector<std::pair<std::weak_ptr<RBX::BasePart>,bool>,RSL::Detail::Allocator<std::pair<std::weak_ptr<RBX::BasePart>,bool>>>::clear[abi:ne200100]( /*0x104f861b2*/
    a1: v72,
    a2: v25,
    a3: v26,
    a4: v24);
  RBX::Profiler::TelemetryScope::~TelemetryScope(this: (RBX::Profiler::TelemetryScope *)v65); /*0x104f861c5*/
  v2 = v76; /*0x104f861ca*/
LABEL_111:
  v55 = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v2, a2: v22); /*0x104f861d1*/
  if ( v55 != nullptr ) /*0x104f861dc*/
  {
    v56 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::RunService>(this: v55); /*0x104f861ea*/
    if ( v56 != 0 ) /*0x104f861f0*/
    {
      if ( (_BYTE)`guard variable for'RBX::Workspace::physicsStep(void)::proftoken2101 == 0 /*0x104f863e0*/
        && __cxa_guard_acquire(a1: &`guard variable for'RBX::Workspace::physicsStep(void)::proftoken2101) != 0 )
      {
        *(_QWORD *)&v79 = "n InputActionType.ViewportPosition should be called with a Vector2 state"; /*0x104f86409*/
        v64 = RBX::Profiler::getToken( /*0x104f8642d*/
                this: (RBX::Profiler *)&aParameterForma[-255421],
                a2: &aActionFireOnIn_3[-630269],
                a3: (const char *)0xFFFFFFFFLL,
                a4: 255,
                a5: v63);
        RBX::Profiler::PerFrameTelemetry::activateForTelemetry(a1: v64); /*0x104f86433*/
        RBX::Workspace::physicsStep(void)::proftoken2101 = v64; /*0x104f86438*/
        __cxa_guard_release(a1: &`guard variable for'RBX::Workspace::physicsStep(void)::proftoken2101); /*0x104f86446*/
      }
      v57 = RBX::Workspace::physicsStep(void)::proftoken2101; /*0x104f86204*/
      v79 = 0; /*0x104f86216*/
      v80[1] = -1; /*0x104f8621a*/
      memset(&v80[2], 0, 52); /*0x104f86222*/
      *(_OWORD *)&v80[9] = 0; /*0x104f86238*/
      v80[0] = RBX::Workspace::physicsStep(void)::proftoken2101; /*0x104f8623d*/
      RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)&v79); /*0x104f86241*/
      v80[1] = RBX::Profiler::PerFrameTelemetry::enterTelemetryRegion(a1: v57, a2: v81, a3: 1); /*0x104f86261*/
      v65[0] = v73; /*0x104f8627d*/
      rbx::signal<void ()(double)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: v56 + 664); /*0x104f86284*/
      RBX::Profiler::TelemetryScope::~TelemetryScope(this: (RBX::Profiler::TelemetryScope *)&v79); /*0x104f86290*/
    }
  }
  return v73; /*0x104f862b1*/
}

// Address: 0x104f864f4 | Name: __ZNK3RBX9Workspace35getEngineNetConfigurationForRuntimeEv
RBX::Workspace *__fastcall RBX::Workspace::getEngineNetConfigurationForRuntime(RBX::Workspace *this, __int64 a2)
{
  RBX::World::getEngineNetConfiguration(this, a2: *(_QWORD *)(a2 + 944)); /*0x104f86504*/
  return this; /*0x104f86510*/
}

// Address: 0x104f86536 | Name: __ZN3RBX9Workspace33dispatchCollisionSummaryCallbacksEv
__int64 __fastcall RBX::Workspace::dispatchCollisionSummaryCallbacks(RBX::Workspace *this)
{
  RBX::Workspace::CollisionSummaryState *v2; // rdi
  RBX::World *v3; // rbx
  __int64 v4; // r12
  __int64 v5; // r8
  __int64 v6; // r9
  __int64 *v7; // rax
  unsigned int i; // ecx
  __int64 v9; // rax
  unsigned __int64 v10; // r14
  __int64 v11; // r15
  __int64 v12; // rax
  unsigned int v13; // edx
  __int64 v14; // rbx
  __int64 v15; // r14
  __int64 *v16; // r14
  __int64 v17; // rdx
  __int64 v18; // rcx
  __int64 v19; // r8
  __int64 v20; // rdi
  __int64 v21; // rbx
  std::__shared_weak_count *v22; // r14
  __m128 v23; // xmm0
  __int64 v24; // rax
  double v25; // xmm1_8
  double v26; // xmm2_8
  __int64 v27; // rdi
  __int64 *v28; // r12
  unsigned __int8 *v29; // rax
  __int64 v30; // rdi
  __int64 v31; // rsi
  __int64 v32; // rdi
  __int64 *v33; // r12
  unsigned __int8 *v34; // rax
  __int64 v35; // rdi
  __int64 v36; // rsi
  std::__shared_weak_count *v37; // r12
  __int64 v38; // rdi
  __int64 *v39; // r12
  unsigned __int8 *v40; // rax
  __int64 v41; // rdi
  __int64 v42; // rsi
  double v43; // xmm0_8
  double v44; // xmm1_8
  std::__shared_weak_count *v45; // r12
  __int64 v46; // rbx
  __int64 *v47; // r12
  unsigned __int8 *v48; // rax
  __int64 v49; // rdi
  __int64 v50; // rsi
  double v51; // xmm0_8
  double v52; // xmm1_8
  __int64 v53; // rbx
  __int64 *v54; // r12
  unsigned __int8 *v55; // rax
  __int64 v56; // rdi
  __int64 v57; // rsi
  double v58; // xmm0_8
  double v59; // xmm1_8
  __int64 v60; // rbx
  __int64 *v61; // r12
  unsigned __int8 *v62; // rax
  __int64 v63; // rdi
  __int64 v64; // rsi
  __int64 v65; // rdi
  __int64 v66; // rbx
  __int64 *v67; // r12
  unsigned __int8 *v68; // rax
  __int64 v69; // rdi
  __int64 v70; // rsi
  __int64 v71; // rdi
  __int64 v72; // rdx
  __int64 v73; // rcx
  __int64 v74; // r8
  unsigned __int64 v75; // r12
  __int64 v76; // r12
  std::__shared_weak_count *v77; // r14
  std::__shared_weak_count *v78; // rbx
  __int64 v79; // rbx
  __int64 v80; // r15
  unsigned __int64 v81; // rax
  unsigned __int64 v82; // rcx
  _QWORD *j; // r15
  std::__shared_weak_count *v84; // rbx
  __int64 v86; // [rsp+0h] [rbp-170h] BYREF
  __int64 k; // [rsp+8h] [rbp-168h]
  std::__shared_weak_count *v88[2]; // [rsp+10h] [rbp-160h] BYREF
  __int64 v89; // [rsp+20h] [rbp-150h]
  __int64 v90; // [rsp+28h] [rbp-148h]
  std::__shared_weak_count *v91[2]; // [rsp+30h] [rbp-140h] BYREF
  __int64 v92; // [rsp+48h] [rbp-128h] BYREF
  __int128 v93; // [rsp+50h] [rbp-120h] BYREF
  unsigned __int8 *v94; // [rsp+60h] [rbp-110h] BYREF
  unsigned __int8 *v95; // [rsp+68h] [rbp-108h] BYREF
  std::__shared_weak_count *v96; // [rsp+70h] [rbp-100h]
  unsigned __int8 v97[16]; // [rsp+78h] [rbp-F8h] BYREF
  void *v98; // [rsp+88h] [rbp-E8h]
  unsigned __int64 v99; // [rsp+90h] [rbp-E0h]
  char v100; // [rsp+9Fh] [rbp-D1h] BYREF
  std::__shared_weak_count *v101[2]; // [rsp+A0h] [rbp-D0h] BYREF
  _BYTE v102[64]; // [rsp+B0h] [rbp-C0h] BYREF
  __int64 *v103; // [rsp+F0h] [rbp-80h] BYREF
  __int64 v104; // [rsp+F8h] [rbp-78h] BYREF
  _BYTE v105[64]; // [rsp+100h] [rbp-70h] BYREF

  v2 = *((RBX::Workspace::CollisionSummaryState **)this + 421); /*0x104f8655b*/
  if ( v2 != nullptr && *((_QWORD *)v2 + 1) != *((_QWORD *)v2 + 2) ) /*0x104f86573*/
  {
    v3 = *((RBX::World **)this + 118); /*0x104f86579*/
    RBX::Workspace::CollisionSummaryState::cleanupDead(this: v2, a2: v3); /*0x104f86583*/
    v4 = *((_QWORD *)this + 421) /* +3368: NO 2022 FIELD */; /*0x104f86588*/
    if ( *(_QWORD *)(v4 + 8) != *(_QWORD *)(v4 + 16) ) /*0x104f86599*/
    {
      RBX::Workspace::CollisionSummaryState::ensureSorted(this: *((RBX::Workspace::CollisionSummaryState **)this + 421)); /*0x104f865a2*/
      v90 = *((_QWORD *)this + 421) /* +3368: NO 2022 FIELD */ + 32LL; /*0x104f865b6*/
      RBX::details::SplitHashTableIterator<std::pair<RBX::Primitive const*,std::vector<RBX::ContactSummary>>,RBX::details::SplitHashTable<RBX::Primitive const*,std::pair<RBX::Primitive const*,std::vector<RBX::ContactSummary>>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Primitive const*>,RBX::details::DefaultEqualTo<RBX::Primitive const*>,RBX::details::GetMapKey<RBX::Primitive const*,std::vector<RBX::ContactSummary>>>,true>::SplitHashTableIterator( /*0x104f865bf*/
        a1: &v103,
        a2: v90,
        a3: 0);
      v7 = v103; /*0x104f865c4*/
      for ( i = v104; v103 != nullptr || (_DWORD)v104 != 0; i = v104 ) /*0x104f865da*/
      {
        *(_QWORD *)(v7[2] + 32LL * i + 16) = *(_QWORD *)(v7[2] + 32LL * i + 8); /*0x104f865fa*/
        RBX::details::SplitHashTableIterator<std::pair<RBX::Primitive const*,std::vector<RBX::ContactSummary>>,RBX::details::SplitHashTable<RBX::Primitive const*,std::pair<RBX::Primitive const*,std::vector<RBX::ContactSummary>>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Primitive const*>,RBX::details::DefaultEqualTo<RBX::Primitive const*>,RBX::details::GetMapKey<RBX::Primitive const*,std::vector<RBX::ContactSummary>>>,true>::operator++(a1: &v103); /*0x104f86602*/
        v7 = v103; /*0x104f86607*/
      }
      v86 = v90; /*0x104f8662d*/
      v103 = &v86; /*0x104f86634*/
      RBX::World::forEachSummary( /*0x104f86641*/
        a1: (__int64)v3,
        a2: (__int64 (__fastcall *)(__int64, _QWORD, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))RBX::function_ref<void ()(RBX::ContactSummary)>::callback_fn<RBX::Workspace::dispatchCollisionSummaryCallbacks(void)::$_0>,
        a3: (__int64)&v103,
        a4: v90,
        a5: v5,
        a6: v6);
      v9 = *(_QWORD *)(v4 + 8); /*0x104f86646*/
      if ( *(_QWORD *)(v4 + 16) != v9 ) /*0x104f86650*/
      {
        v10 = 0; /*0x104f86656*/
        v89 = v4; /*0x104f86660*/
        do /*0x104f86ffa*/
        {
          v99 = v10; /*0x104f86667*/
          v11 = 88 * v10; /*0x104f8666e*/
          v92 = *(_QWORD *)(v9 + 88 * v10); /*0x104f86676*/
          v12 = RBX::details::SplitHashTable<RBX::Primitive const*,std::pair<RBX::Primitive const*,std::vector<RBX::ContactSummary>>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Primitive const*>,RBX::details::DefaultEqualTo<RBX::Primitive const*>,RBX::details::GetMapKey<RBX::Primitive const*,std::vector<RBX::ContactSummary>>>::find_as<RBX::Primitive const*>( /*0x104f8668b*/
                  a1: v90,
                  a2: &v92);
          if ( v13 == 0 && v12 == 0 /*0x104f866ba*/
            || (v14 = *(_QWORD *)(v12 + 16), v15 = 32LL * v13, *(_QWORD *)(v14 + v15 + 8) == *(_QWORD *)(v14 + v15 + 16)) )
          {
            v9 = *(_QWORD *)(v4 + 8); /*0x104f86f36*/
            v82 = 0x2E8BA2E8BA2E8BA3LL * ((*(_QWORD *)(v4 + 16) - v9) >> 3); /*0x104f86f51*/
            if ( v99 < v82 ) /*0x104f86f5c*/
            {
              for ( j = (_QWORD *)(v9 + v11); *j == v92; j += 11 ) /*0x104f86f65*/
              {
                if ( v82 == ++v99 ) /*0x104f86f85*/
                  return __stack_chk_guard; /*0x104f86f85*/
              }
            }
            v10 = v99; /*0x104f86f89*/
          }
          else
          {
            RBX::make_shared<std::vector<RBX::Reflection::Variant>>(a1: v91); /*0x104f866c7*/
            v16 = (__int64 *)(v14 + v15 + 8); /*0x104f866cf*/
            std::vector<RBX::Reflection::Variant>::reserve( /*0x104f866e5*/
              a1: (__int64 *)v91[0],
              a2: (v16[1] - *v16) >> 6,
              a3: v17,
              a4: v18,
              a5: v19);
            v21 = *v16; /*0x104f866ea*/
            for ( k = v16[1]; v21 != k; v21 = v66 + 4 ) /*0x104f866fb*/
            {
              v22 = v91[0]; /*0x104f86701*/
              RBX::make_shared<RBX::Reflection::ValueTable>(a1: (RSL::Arena *)&v93); /*0x104f8670f*/
              v23 = (__m128)0x40E00000u; /*0x104f8671b*/
              v23.f32[0] = 7.0 / *(float *)(v93 + 32); /*0x104f86723*/
              v23.i64[0] = _mm_round_ss(v23, v23, 10).u64[0]; /*0x104f86728*/
              v24 = (unsigned int)(int)v23.f32[0]; /*0x104f8672e*/
              v23.f32[0] = v23.f32[0] - 9.223372e18; /*0x104f8673a*/
              std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__rehash<true>( /*0x104f8674d*/
                a1: v93,
                a2: v24,
                a3: *(double *)v23.i64,
                a4: v25,
                a5: v26);
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<double>(a1: v27); /*0x104f86757*/
              v104 = 0; /*0x104f8675b*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<double>(a1: &v104, a2: v21); /*0x104f8676a*/
              v28 = (__int64 *)v93; /*0x104f8676f*/
              std::string::basic_string[abi:ne200100]<0>(a1: v97, a2: "Time"); /*0x104f86780*/
              v95 = v97; /*0x104f86785*/
              v29 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x104f867a7*/
                      a1: v28,
                      a2: v97,
                      a3: (__int64)std::piecewise_construct,
                      a4: (__int64)&v95,
                      a5: (__int64)&v94);
              *((_QWORD *)v29 + 5) = v103; /*0x104f867b0*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v29 + 48, a2: &v104); /*0x104f867bf*/
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<void>(a1: v30, a2: v31); /*0x104f867c9*/
              if ( v104 != 0 ) /*0x104f867d4*/
              {
                (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f867da*/
                v104 = 0; /*0x104f867dd*/
              }
              if ( (v97[0] & 1) != 0 ) /*0x104f867ec*/
              {
                operator delete(a1: v98); /*0x104f867f5*/
                if ( v104 != 0 ) /*0x104f86801*/
                  (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f86807*/
              }
              RBX::shared_from<RBX::Instance>(a1: &v95, a2: *(_QWORD *)(*(_QWORD *)(v21 + 8) + 528LL)); /*0x104f8681c*/
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Instance>>(a1: v32); /*0x104f86826*/
              v104 = 0; /*0x104f8682a*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::shared_ptr<RBX::Instance>,(std::shared_ptr<RBX::Instance>*)0>( /*0x104f8683d*/
                a1: &v104,
                a2: &v95);
              v33 = (__int64 *)v93; /*0x104f86842*/
              std::string::basic_string[abi:ne200100]<0>(a1: v97, a2: "Part0"); /*0x104f86853*/
              v94 = v97; /*0x104f86858*/
              v34 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x104f8687a*/
                      a1: v33,
                      a2: v97,
                      a3: (__int64)std::piecewise_construct,
                      a4: (__int64)&v94,
                      a5: (__int64)&v100);
              *((_QWORD *)v34 + 5) = v103; /*0x104f86883*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v34 + 48, a2: &v104); /*0x104f86892*/
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<void>(a1: v35, a2: v36); /*0x104f8689c*/
              if ( v104 != 0 ) /*0x104f868a7*/
              {
                (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f868ad*/
                v104 = 0; /*0x104f868b0*/
              }
              if ( (v97[0] & 1) != 0 ) /*0x104f868bf*/
              {
                operator delete(a1: v98); /*0x104f868c8*/
                if ( v104 != 0 ) /*0x104f868d4*/
                  (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f868da*/
              }
              v37 = v96; /*0x104f868dd*/
              if ( v96 != nullptr /*0x104f868fa*/
                && _InterlockedExchangeAdd64((volatile signed __int64 *)v96 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
              {
                (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v37 + 16LL))(a1: v37); /*0x104f86903*/
                std::__shared_weak_count::__release_weak(this: v37); /*0x104f86909*/
              }
              RBX::shared_from<RBX::Instance>(a1: &v95, a2: *(_QWORD *)(*(_QWORD *)(v21 + 16) + 528LL)); /*0x104f86920*/
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Instance>>(a1: v38); /*0x104f8692a*/
              v104 = 0; /*0x104f8692e*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::shared_ptr<RBX::Instance>,(std::shared_ptr<RBX::Instance>*)0>( /*0x104f86941*/
                a1: &v104,
                a2: &v95);
              v39 = (__int64 *)v93; /*0x104f86946*/
              std::string::basic_string[abi:ne200100]<0>(a1: v97, a2: "Part1"); /*0x104f86957*/
              v94 = v97; /*0x104f8695c*/
              v40 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x104f8697e*/
                      a1: v39,
                      a2: v97,
                      a3: (__int64)std::piecewise_construct,
                      a4: (__int64)&v94,
                      a5: (__int64)&v100);
              *((_QWORD *)v40 + 5) = v103; /*0x104f86987*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v40 + 48, a2: &v104); /*0x104f86996*/
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<void>(a1: v41, a2: v42); /*0x104f869a0*/
              if ( v104 != 0 ) /*0x104f869ab*/
              {
                (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f869b1*/
                v104 = 0; /*0x104f869b4*/
              }
              if ( (v97[0] & 1) != 0 ) /*0x104f869c3*/
              {
                operator delete(a1: v98); /*0x104f869cc*/
                if ( v104 != 0 ) /*0x104f869d8*/
                  (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f869de*/
              }
              v45 = v96; /*0x104f869e1*/
              if ( v96 != nullptr /*0x104f869fe*/
                && _InterlockedExchangeAdd64((volatile signed __int64 *)v96 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
              {
                (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v45 + 16LL))(a1: v45); /*0x104f86a07*/
                std::__shared_weak_count::__release_weak(this: v45); /*0x104f86a0d*/
              }
              v46 = v21 + 24; /*0x104f86a17*/
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<RBX::Vector3>(a1: v43, a2: v44); /*0x104f86a1b*/
              v104 = 0; /*0x104f86a1f*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<RBX::Vector3>(a1: &v104, a2: v46); /*0x104f86a2e*/
              v47 = (__int64 *)v93; /*0x104f86a33*/
              std::string::basic_string[abi:ne200100]<0>(a1: v97, a2: "Point"); /*0x104f86a44*/
              v95 = v97; /*0x104f86a49*/
              v48 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x104f86a6b*/
                      a1: v47,
                      a2: v97,
                      a3: (__int64)std::piecewise_construct,
                      a4: (__int64)&v95,
                      a5: (__int64)&v94);
              *((_QWORD *)v48 + 5) = v103; /*0x104f86a74*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v48 + 48, a2: &v104); /*0x104f86a83*/
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<void>(a1: v49, a2: v50); /*0x104f86a8d*/
              if ( v104 != 0 ) /*0x104f86a98*/
              {
                (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f86a9e*/
                v104 = 0; /*0x104f86aa1*/
              }
              if ( (v97[0] & 1) != 0 ) /*0x104f86ab0*/
              {
                operator delete(a1: v98); /*0x104f86ab9*/
                if ( v104 != 0 ) /*0x104f86ac5*/
                  v51 = (*(double (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f86acb*/
              }
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<RBX::Vector3>(a1: v51, a2: v52); /*0x104f86ad3*/
              v104 = 0; /*0x104f86ad7*/
              v53 = v46 + 12; /*0x104f86adf*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<RBX::Vector3>(a1: &v104, a2: v53); /*0x104f86aea*/
              v54 = (__int64 *)v93; /*0x104f86aef*/
              std::string::basic_string[abi:ne200100]<0>(a1: v97, a2: "Normal"); /*0x104f86b00*/
              v95 = v97; /*0x104f86b05*/
              v55 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x104f86b27*/
                      a1: v54,
                      a2: v97,
                      a3: (__int64)std::piecewise_construct,
                      a4: (__int64)&v95,
                      a5: (__int64)&v94);
              *((_QWORD *)v55 + 5) = v103; /*0x104f86b30*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v55 + 48, a2: &v104); /*0x104f86b3f*/
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<void>(a1: v56, a2: v57); /*0x104f86b49*/
              if ( v104 != 0 ) /*0x104f86b54*/
              {
                (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f86b5a*/
                v104 = 0; /*0x104f86b5d*/
              }
              if ( (v97[0] & 1) != 0 ) /*0x104f86b6c*/
              {
                operator delete(a1: v98); /*0x104f86b75*/
                if ( v104 != 0 ) /*0x104f86b81*/
                  v58 = (*(double (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f86b87*/
              }
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<RBX::Vector3>(a1: v58, a2: v59); /*0x104f86b8f*/
              v104 = 0; /*0x104f86b93*/
              v60 = v53 + 12; /*0x104f86b9b*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<RBX::Vector3>(a1: &v104, a2: v60); /*0x104f86ba6*/
              v61 = (__int64 *)v93; /*0x104f86bab*/
              std::string::basic_string[abi:ne200100]<0>(a1: v97, a2: "RelativeVelocity"); /*0x104f86bbc*/
              v95 = v97; /*0x104f86bc1*/
              v62 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x104f86be3*/
                      a1: v61,
                      a2: v97,
                      a3: (__int64)std::piecewise_construct,
                      a4: (__int64)&v95,
                      a5: (__int64)&v94);
              *((_QWORD *)v62 + 5) = v103; /*0x104f86bec*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v62 + 48, a2: &v104); /*0x104f86bfb*/
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<void>(a1: v63, a2: v64); /*0x104f86c05*/
              if ( v104 != 0 ) /*0x104f86c10*/
              {
                (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f86c16*/
                v104 = 0; /*0x104f86c19*/
              }
              if ( (v97[0] & 1) != 0 ) /*0x104f86c28*/
              {
                operator delete(a1: v98); /*0x104f86c31*/
                if ( v104 != 0 ) /*0x104f86c3d*/
                  (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f86c43*/
              }
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<float>(a1: v65); /*0x104f86c4b*/
              v104 = 0; /*0x104f86c4f*/
              v66 = v60 + 12; /*0x104f86c57*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<float>(a1: &v104, a2: v66); /*0x104f86c62*/
              v67 = (__int64 *)v93; /*0x104f86c67*/
              std::string::basic_string[abi:ne200100]<0>(a1: v97, a2: "Area"); /*0x104f86c78*/
              v95 = v97; /*0x104f86c7d*/
              v68 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x104f86c9f*/
                      a1: v67,
                      a2: v97,
                      a3: (__int64)std::piecewise_construct,
                      a4: (__int64)&v95,
                      a5: (__int64)&v94);
              *((_QWORD *)v68 + 5) = v103; /*0x104f86ca8*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v68 + 48, a2: &v104); /*0x104f86cb7*/
              v103 = (__int64 *)RBX::Reflection::Type::getSingleton<void>(a1: v69, a2: v70); /*0x104f86cc1*/
              if ( v104 != 0 ) /*0x104f86ccc*/
              {
                (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f86cd2*/
                v104 = 0; /*0x104f86cd5*/
              }
              if ( (v97[0] & 1) != 0 ) /*0x104f86ce4*/
              {
                operator delete(a1: v98); /*0x104f86ced*/
                if ( v104 != 0 ) /*0x104f86cf9*/
                  (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f86cff*/
              }
              *(_OWORD *)v88 = v93; /*0x104f86d09*/
              v101[0] = (std::__shared_weak_count *)RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::ValueTable const>>(a1: v71); /*0x104f86d15*/
              v101[1] = nullptr; /*0x104f86d1c*/
              RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::shared_ptr<RBX::Reflection::ValueTable const>,(std::shared_ptr<RBX::Reflection::ValueTable const>*)0>( /*0x104f86d35*/
                a1: (__int64 *)&v101[1],
                a2: v88);
              v75 = *((_QWORD *)v22 + 1); /*0x104f86d3a*/
              if ( v75 >= *((_QWORD *)v22 + 2) ) /*0x104f86d42*/
              {
                v76 = std::vector<RBX::Reflection::Variant>::__emplace_back_slow_path<RBX::Reflection::Variant>( /*0x104f86d70*/
                        a1: v22,
                        a2: (__int64)v101,
                        a3: v72,
                        a4: v73,
                        a5: v74);
              }
              else
              {
                std::allocator<RBX::Reflection::Variant>::construct[abi:ne200100]<RBX::Reflection::Variant,RBX::Reflection::Variant>( /*0x104f86d52*/
                  a1: (__int64)v22 + 16,
                  a2: *((_QWORD **)v22 + 1),
                  a3: v101);
                v76 = v75 + 80; /*0x104f86d57*/
                *((_QWORD *)v22 + 1) = v76; /*0x104f86d5b*/
              }
              *((_QWORD *)v22 + 1) = v76; /*0x104f86d73*/
              if ( v101[1] != nullptr ) /*0x104f86d81*/
                (*((void (__fastcall **)(_BYTE *))v101[1] + 2))(a1: v102); /*0x104f86d8a*/
              v77 = v88[1]; /*0x104f86d8d*/
              v4 = v89; /*0x104f86d97*/
              if ( v88[1] != nullptr /*0x104f86db0*/
                && _InterlockedExchangeAdd64((volatile signed __int64 *)v88[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
              {
                (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v77 + 16LL))(a1: v77); /*0x104f86db8*/
                std::__shared_weak_count::__release_weak(this: v77); /*0x104f86dbe*/
              }
            }
            *(_OWORD *)v101 = *(_OWORD *)v91; /*0x104f86de2*/
            if ( v91[1] != nullptr ) /*0x104f86dec*/
              _InterlockedIncrement64((volatile signed __int64 *)v91[1] + 1); /*0x104f86dee*/
            v103 = (__int64 *)RBX::Reflection::Type::getSingleton<std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>(a1: v20); /*0x104f86df8*/
            v104 = 0; /*0x104f86dfc*/
            RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::shared_ptr<std::vector<RBX::Reflection::Variant> const>,(std::shared_ptr<std::vector<RBX::Reflection::Variant> const>*)0>( /*0x104f86e0f*/
              a1: &v104,
              a2: v101);
            v78 = v101[1]; /*0x104f86e14*/
            if ( v101[1] != nullptr /*0x104f86e30*/
              && _InterlockedExchangeAdd64((volatile signed __int64 *)v101[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
            {
              (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v78 + 16LL))(a1: v78); /*0x104f86e38*/
              std::__shared_weak_count::__release_weak(this: v78); /*0x104f86e3e*/
            }
            v79 = *(_QWORD *)(v4 + 8); /*0x104f86e43*/
            if ( v99 < 0x2E8BA2E8BA2E8BA3LL * ((*(_QWORD *)(v4 + 16) - v79) >> 3) ) /*0x104f86e69*/
            {
              v80 = v11 + 40; /*0x104f86e6f*/
              do /*0x104f86f13*/
              {
                if ( *(_QWORD *)(v79 + v80 - 40) != v92 ) /*0x104f86e7f*/
                  break; /*0x104f86e7f*/
                if ( (unsigned __int8)rbx::signals::connection::connected(this: (rbx::signals::connection *)(v79 + v80 + 32)) != 0 /*0x104f86eab*/
                  && (unsigned __int8)RBX::Lua::WeakThreadRef::empty(this: (RBX::Lua::WeakThreadRef *)(v79 + v80 - 32)) == 0 )
                {
                  RBX::ScriptContext::callCallback( /*0x104f86ed0*/
                    a1: v79 + v80 - 32,
                    a2: &v103,
                    a3: 1,
                    a4: v80 + v79,
                    a5: "CollisionSummary.Callback");
                }
                else
                {
                  rbx::signals::connection::disconnect(this: (rbx::signals::connection *)(v79 + v80 + 32)); /*0x104f86eb0*/
                }
                v4 = v89; /*0x104f86edf*/
                v79 = *(_QWORD *)(v89 + 8); /*0x104f86ee6*/
                v81 = 0x2E8BA2E8BA2E8BA3LL * ((*(_QWORD *)(v89 + 16) - v79) >> 3); /*0x104f86f01*/
                v80 += 88; /*0x104f86f05*/
                ++v99; /*0x104f86f09*/
              }
              while ( v99 < v81 ); /*0x104f86f13*/
            }
            if ( v104 != 0 ) /*0x104f86f99*/
              (*(void (__fastcall **)(_BYTE *))(v104 + 16))(a1: v105); /*0x104f86f9f*/
            v84 = v91[1]; /*0x104f86fa2*/
            v10 = v99; /*0x104f86fac*/
            if ( v91[1] != nullptr /*0x104f86fc5*/
              && _InterlockedExchangeAdd64((volatile signed __int64 *)v91[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
            {
              (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v84 + 16LL))(a1: v84); /*0x104f86fcd*/
              std::__shared_weak_count::__release_weak(this: v84); /*0x104f86fd3*/
            }
            v9 = *(_QWORD *)(v4 + 8); /*0x104f86fd8*/
            v82 = 0x2E8BA2E8BA2E8BA3LL * ((*(_QWORD *)(v4 + 16) - v9) >> 3); /*0x104f86ff3*/
          }
        }
        while ( v10 < v82 ); /*0x104f86ffa*/
      }
    }
  }
  return __stack_chk_guard; /*0x104f87010*/
}

// Address: 0x104f873f8 | Name: __ZN3RBX9Workspace42addPendingReplicationPVDirtySignalPartGuidERKNS_4GuidE
__int64 __fastcall RBX::Workspace::addPendingReplicationPVDirtySignalPartGuid(
        RBX::Workspace *this,
        const RBX::Guid *a2)
{
  _BYTE v3[31]; // [rsp+0h] [rbp-20h] BYREF
  char v4; // [rsp+1Fh] [rbp-1h] BYREF

  return RBX::DenseMapBase<RBX::DenseMap<RBX::Guid,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<RBX::Guid,void>,RBX::detail::DenseSetPair<RBX::Guid>>,RBX::Guid,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<RBX::Guid,void>,RBX::detail::DenseSetPair<RBX::Guid>>::try_emplace<RBX::detail::DenseSetEmpty&>( /*0x104f87417*/
           a1: v3,
           a2: (char *)this + 3264 /* +3264: NO 2022 FIELD */,
           a3: a2,
           a4: &v4);
}

// Address: 0x104f8745a | Name: __ZN3RBX9Workspace16setWorldSteppingEb
__int64 __fastcall RBX::Workspace::setWorldStepping(RBX::World **this, int a2)
{
  unsigned __int8 v2; // bl
  __int64 result; // rax
  __int64 v5; // r15
  __int64 i; // r14

  v2 = a2; /*0x104f87464*/
  result = RBX::World::setIsWorldStepping(this: *(this + 118), a2); /*0x104f87470*/
  v5 = (__int64)*(this + 235); /*0x104f87475*/
  for ( i = (__int64)*(this + 236); v5 != i; v5 += 8 ) /*0x104f87486*/
    result = RBX::World::setIsWorldStepping(this: *(RBX::World **)(*(_QWORD *)v5 + 944LL), a2: v2); /*0x104f87497*/
  return result; /*0x104f874a9*/
}

// Address: 0x104f874b0 | Name: __ZNK3RBX9Workspace19hasPrimitiveInWorldEPNS_9PrimitiveE
bool __fastcall RBX::Workspace::hasPrimitiveInWorld(RBX::Workspace *this, RBX::Primitive *a2)
{
  __int64 v2; // rcx
  __int64 v3; // rsi
  __int64 v4; // rdx
  __int64 v5; // rsi
  bool result; // al
  bool v7; // zf

  v2 = *((_QWORD *)a2 + 63); /*0x104f874b0*/
  if ( v2 == *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ ) /*0x104f874be*/
    return true; /*0x104f874f9*/
  v3 = *((_QWORD *)this + 235) /* +1880 likely taskQueue.._Rep -- UNVERIFIED */; /*0x104f874c0*/
  v4 = *((_QWORD *)this + 236) /* +1888 likely stepTouch..head.px -- UNVERIFIED */; /*0x104f874c7*/
  if ( v3 == v4 ) /*0x104f874d1*/
    return false; /*0x104f874fc*/
  v5 = v3 + 8; /*0x104f874d7*/
  do /*0x104f874f5*/
  {
    result = v2 == *(_QWORD *)(*(_QWORD *)(v5 - 8) + 944LL); /*0x104f874e6*/
    if ( v2 == *(_QWORD *)(*(_QWORD *)(v5 - 8) + 944LL) ) /*0x104f874e9*/
      break; /*0x104f874e9*/
    v7 = v5 == v4; /*0x104f874ef*/
    v5 += 8; /*0x104f874f2*/
  }
  while ( !v7 ); /*0x104f874f5*/
  return result; /*0x104f874f8*/
}

// Address: 0x104f87500 | Name: __ZN3RBX9Workspace13doStepPhysicsEfNSt3__110shared_ptrIKNS_11WorldSubSetEEENS_17GameSteppedParamsE
void __fastcall RBX::Workspace::doStepPhysics(RBX::World **a1, _QWORD *a2, __int64 a3, float a4)
{
  __int64 *v6; // rbx
  __int64 v7; // rdi
  __int64 v8; // rax
  std::__shared_weak_count *v9; // r12
  __int64 v10; // r14
  __int64 i; // rbx
  __int64 v12; // rdi
  __int64 v13; // rax
  std::__shared_weak_count *v14; // r13
  RBX::RunService *v15; // rax
  __int64 v16; // rcx
  RBX::StepPhysicsAnalytics *v17; // r12
  RBX::RunService *v18; // rax
  __int64 v19; // rcx
  RBX::StepPhysicsAnalytics *v20; // r15
  char isEditModeDmInStudio; // al
  RBX::Instance *v22; // rsi
  char v23; // al
  RBX::World *v24; // r15
  RBX::DataModel *v25; // rax
  RBX::SteppingParameters *v26; // rdi
  int v27; // xmm0_4
  int WorldSteps; // eax
  __m128 v29; // xmm1
  RBX::SteppingParameters *v30; // rdi
  __m128 v31; // xmm0
  int v32; // xmm1_4
  RBX::SteppingParameters *v33; // rdi
  unsigned __int8 TargetStepsPerFrame; // al
  int v35; // r13d
  double v36[2]; // [rsp+0h] [rbp-B0h] BYREF
  _BYTE v37[16]; // [rsp+10h] [rbp-A0h] BYREF
  RBX::World *v38[2]; // [rsp+20h] [rbp-90h] BYREF
  int v39; // [rsp+30h] [rbp-80h]
  int v40; // [rsp+34h] [rbp-7Ch]
  _BYTE v41[8]; // [rsp+38h] [rbp-78h] BYREF
  std::__shared_weak_count *v42[2]; // [rsp+40h] [rbp-70h] BYREF
  __int128 v43; // [rsp+58h] [rbp-58h] BYREF
  __int64 v44; // [rsp+68h] [rbp-48h]
  RBX::Workspace *v45[2]; // [rsp+70h] [rbp-40h]
  float v46; // [rsp+84h] [rbp-2Ch]

  v46 = a4; /*0x104f8751a*/
  v6 = (__int64 *)a1; /*0x104f8751f*/
  RBX::Workspace::setWorldStepping(this: a1, a2: 1); /*0x104f87527*/
  if ( *a2 != 0 ) /*0x104f87532*/
  {
    v7 = v6[118]; /*0x104f87538*/
    *(_QWORD *)&v43 = *a2; /*0x104f8753f*/
    v8 = a2[1]; /*0x104f87543*/
    *((_QWORD *)&v43 + 1) = v8; /*0x104f87547*/
    if ( v8 != 0 ) /*0x104f8754e*/
      _InterlockedIncrement64((volatile signed __int64 *)(v8 + 8)); /*0x104f87550*/
    RBX::World::setWorldSubSet(a1: v7, a2: &v43); /*0x104f87559*/
    v44 = a3; /*0x104f8755e*/
    v9 = *((std::__shared_weak_count **)&v43 + 1); /*0x104f87562*/
    if ( *((_QWORD *)&v43 + 1) != 0 /*0x104f8757c*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v43 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x104f87585*/
      std::__shared_weak_count::__release_weak(this: v9); /*0x104f8758b*/
    }
    v10 = v6[235]; /*0x104f87590*/
    v45[0] = (RBX::Workspace *)v6; /*0x104f87597*/
    for ( i = v6[236]; v10 != i; v10 += 8 ) /*0x104f875a5*/
    {
      v12 = *(_QWORD *)(*(_QWORD *)v10 + 944LL); /*0x104f875ae*/
      v13 = a2[1]; /*0x104f875b5*/
      *(_OWORD *)v42 = *(_OWORD *)a2; /*0x104f875bd*/
      if ( v13 != 0 ) /*0x104f875c4*/
        _InterlockedIncrement64((volatile signed __int64 *)(v13 + 8)); /*0x104f875c6*/
      RBX::World::setWorldSubSet(a1: v12, a2: (__int128 *)v42); /*0x104f875ce*/
      v14 = v42[1]; /*0x104f875d3*/
      if ( v42[1] != nullptr /*0x104f875ec*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v42[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x104f875f5*/
        std::__shared_weak_count::__release_weak(this: v14); /*0x104f875fb*/
      }
    }
    v6 = (__int64 *)v45[0]; /*0x104f87609*/
    v15 = (RBX::RunService *)RBX::ServiceProvider::find<RBX::RunService>(a1: v45[0]); /*0x104f87610*/
    v16 = v6[130]; /*0x104f87615*/
    if ( v16 != 0 ) /*0x104f8761f*/
      v17 = *(RBX::StepPhysicsAnalytics **)(v16 + 24); /*0x104f87621*/
    else
      v17 = nullptr; /*0x104f87641*/
    isEditModeDmInStudio = RBX::RunService::isEditModeDmInStudio(this: v15); /*0x104f8764b*/
    RBX::StepPhysicsAnalytics::recordSelectiveWorkspaceStep( /*0x104f87662*/
      this: v17,
      a2: isEditModeDmInStudio,
      a3: v46,
      a4: *(_QWORD *)(*a2 + 32LL));
  }
  else
  {
    v18 = (RBX::RunService *)RBX::ServiceProvider::find<RBX::RunService>(a1: v6); /*0x104f8762a*/
    v19 = v6[130]; /*0x104f8762f*/
    if ( v19 != 0 ) /*0x104f87639*/
      v20 = *(RBX::StepPhysicsAnalytics **)(v19 + 24); /*0x104f8763b*/
    else
      v20 = nullptr; /*0x104f87669*/
    v23 = RBX::RunService::isEditModeDmInStudio(this: v18); /*0x104f8766f*/
    RBX::StepPhysicsAnalytics::recordGlobalWorkspaceStep(this: v20, a2: v23, a3: v46); /*0x104f8767f*/
  }
  v24 = (RBX::World *)v6[118]; /*0x104f87684*/
  v25 = RBX::DataModel::get(this: (RBX::DataModel *)v6, a2: v22); /*0x104f8768e*/
  RBX::SpatialFilterSimulationOverride::SpatialFilterSimulationOverride( /*0x104f876a9*/
    this: (RBX::SpatialFilterSimulationOverride *)v37,
    a2: v24,
    a3: *((_DWORD *)v25 + 566) == 1);
  RBX::SteppingParameters::getEngineUnitDt(this: v26); /*0x104f876ae*/
  LODWORD(v45[0]) = v27; /*0x104f876b3*/
  v38[0] = (RBX::World *)v6[118]; /*0x104f876bf*/
  v38[1] = *(RBX::World **)((char *)v38[0] + 1692); /*0x104f876cd*/
  v39 = *((_DWORD *)v38[0] + 425); /*0x104f876da*/
  WorldSteps = RBX::World::getWorldSteps(this: v38[0]); /*0x104f876dd*/
  v29 = (__m128)LODWORD(v46); /*0x104f876e7*/
  v29.f32[0] = v46 / *(float *)v45; /*0x104f876ea*/
  *(__m128 *)v45 = _mm_round_ss(v29, v29, 10); /*0x104f876f5*/
  v40 = WorldSteps; /*0x104f87704*/
  v46 = v46 / _mm_cvtepi32_ps(_mm_cvttps_epi32(*(__m128 *)v45)).f32[0]; /*0x104f87707*/
  RBX::SteppingParameters::CreateSteppingParametersForTimeStep(this: v30, a2: v46); /*0x104f8770c*/
  _mm_storel_ps(v36, v31); /*0x104f87718*/
  LODWORD(v36[1]) = v32; /*0x104f8771b*/
  RBX::SteppingParameters::operator=(a1: v6[118] + 1692); /*0x104f8772c*/
  TargetStepsPerFrame = 4; /*0x104f87738*/
  if ( DFFlag::SimUseWorldStepsPerFixedStep == 0 ) /*0x104f8773d*/
    TargetStepsPerFrame = RBX::SteppingParameters::getTargetStepsPerFrame(this: v33); /*0x104f8773f*/
  v35 = (int)*(float *)v45 / TargetStepsPerFrame; /*0x104f87753*/
  LODWORD(v45[0]) = (int)*(float *)v45 % TargetStepsPerFrame; /*0x104f87756*/
  RBX::World::getEngineNetConfiguration(this: (RBX::World *)v41, a2: v6[118]); /*0x104f87764*/
  if ( FFlag::DebugHashTableMetrics != 0 || FFlag::SAuthWorkspaceFlagged == 1 && (v41[0] & 8) != 0 ) /*0x104f877a4*/
  {
    if ( v35 > 0 ) /*0x104f87778*/
    {
      do /*0x104f87790*/
      {
        RBX::physicsSubStep(this: (RBX::Workspace *)v6); /*0x104f87788*/
        --v35; /*0x104f8778d*/
      }
      while ( v35 != 0 ); /*0x104f87790*/
    }
  }
  else if ( v35 > 0 ) /*0x104f877b3*/
  {
    do /*0x104f877d5*/
    {
      RBX::physicsSubStep(this: (RBX::Workspace *)v6); /*0x104f877cd*/
      --v35; /*0x104f877d2*/
    }
    while ( v35 != 0 ); /*0x104f877d5*/
  }
  RBX::physicsSubStep(this: (RBX::Workspace *)v6); /*0x104f877e5*/
  RBX::Workspace::setWorldStepping(this: (RBX::World **)v6, a2: 0); /*0x104f877ef*/
  RBX::WorldSteppingParamsCache::~WorldSteppingParamsCache(this: (RBX::WorldSteppingParamsCache *)v38); /*0x104f877fb*/
  RBX::SpatialFilterSimulationOverride::~SpatialFilterSimulationOverride(this: (RBX::SpatialFilterSimulationOverride *)v37); /*0x104f87807*/
}

// Address: 0x104f87900 | Name: __ZNK3RBX9Workspace30averagePhysicsSteppedTimeTotalEv
double __fastcall RBX::Workspace::averagePhysicsSteppedTimeTotal(RBX::Workspace *this)
{
  return *((double *)this + 287) /* +2296: NO 2022 FIELD */; /*0x104f8790c*/
}

// Address: 0x104f8790e | Name: __ZN3RBX9Workspace14onChildChangedEPNS_8InstanceERKNS_10Reflection18PropertyDescriptorE
__int64 __fastcall RBX::Workspace::onChildChanged(
        RBX::Workspace *this,
        RBX::Instance *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  return RBX::Instance::onChildChanged(this, a2, a3); /*0x104f87912*/
}

// Address: 0x104f87918 | Name: __ZNK3RBX9Workspace20isEnumHiddenInStudioEPKNS_10Reflection18PropertyDescriptorEi
char __fastcall RBX::Workspace::isEnumHiddenInStudio(
        RBX::Workspace *this,
        const RBX::Reflection::PropertyDescriptor *a2,
        int a3)
{
  char result; // al

  result = 1; /*0x104f8791c*/
  if ( (FFlag::DebugCLI122361Omega != 0 || RBX::WorkspaceProperties::prop_PrimalPhysicsSolver != (_UNKNOWN *)a2) /*0x104f87958*/
    && (DFFlag::ShowImprovedPhysicsReplicationInStudio != 1
     || DFFlag::ShowImprovedPhysicsReplicationDisabledInStudio != 0
     || a3 != 1
     || RBX::WorkspaceProperties::prop_ImprovedPhysicsReplication != (_UNKNOWN *)a2) )
  {
    return 0; /*0x104f87945*/
  }
  return result; /*0x104f87947*/
}

// Address: 0x104f8795c | Name: __ZN3RBX9Workspace16onWorldFixedStepEfi
char __fastcall RBX::Workspace::onWorldFixedStep(RBX::Workspace *this, float a2, int a3)
{
  RBX::AuroraService *v5; // rax
  RBX::AuroraService *v6; // r15
  RBX::RunService *v7; // rax
  __int64 v8; // rax
  RBX::Instance *v9; // rsi
  RBX::ContextActionService *v10; // r15
  RBX::DataModel *v11; // rax
  RBX::Instance *v12; // r15
  double v13; // xmm0_8
  _BYTE v15[8]; // [rsp+8h] [rbp-28h] BYREF
  double v16; // [rsp+10h] [rbp-20h]

  *(float *)&v16 = a2; /*0x104f8796b*/
  RBX::World::getEngineNetConfiguration(this: (RBX::World *)v15, a2: *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */); /*0x104f8797e*/
  if ( (FFlag::DebugHashTableMetrics == 1 || FFlag::SAuthWorkspaceFlagged != 0 && (v15[0] & 8) != 0) /*0x104f8799a*/
    && (v5 = (RBX::AuroraService *)RBX::ServiceProvider::find<RBX::AuroraService>(a1: this)) != nullptr )
  {
    v6 = v5; /*0x104f8799c*/
    if ( DFFlag::AuroraCheckServerViewInFixedStep == 1 ) /*0x104f879a6*/
      RBX::AuroraService::checkServerViewAndRollback(this: v5); /*0x104f879ab*/
    LOBYTE(v7) = RBX::AuroraService::onWorldFixedRateTick(this: v6, a2: *(float *)&v16, a3); /*0x104f879bd*/
  }
  else
  {
    if ( FFlag::InputReplicatorNonSAuth == 1 ) /*0x104f879e3*/
    {
      v8 = RBX::ServiceProvider::find<RBX::ContextActionService>(a1: this); /*0x104f879e8*/
      if ( v8 != 0 ) /*0x104f879f0*/
      {
        v10 = (RBX::ContextActionService *)v8; /*0x104f879f2*/
        v11 = RBX::DataModel::get(this, a2: v9); /*0x104f879f8*/
        if ( RBX::DataModel::isServerLaunchIntent(this: v11) ) /*0x104f87a00*/
        {
          RBX::ContextActionService::applyInput(this: v10, a2: *(_DWORD *)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 232LL), a3: 1); /*0x104f87a1e*/
        }
        else
        {
          RBX::ContextActionService::gatherInput(this: v10); /*0x104f87a28*/
          RBX::ContextActionService::sendInput(this: v10); /*0x104f87a30*/
          if ( FFlag::PlayerControlStateApplyInputOnClientNonSAuth == 1 ) /*0x104f87a3c*/
            RBX::ContextActionService::applyControlStatesForClient( /*0x104f87a53*/
              this: v10,
              a2: *(_DWORD *)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 232LL),
              a3: 1u);
        }
      }
    }
    v7 = (RBX::RunService *)RBX::ServiceProvider::find<RBX::RunService>(a1: this); /*0x104f87a5b*/
    if ( v7 != nullptr ) /*0x104f87a63*/
    {
      v12 = v7; /*0x104f87a65*/
      v13 = *(float *)&v16; /*0x104f87a6b*/
      v16 = *(float *)&v16; /*0x104f87a73*/
      RBX::RunService::fireSimulationFunctions(this: v7, a2: v13, a3); /*0x104f87a7a*/
      v7 = (RBX::RunService *)&FFlag::SimMoveHumanoidsToFixedStep; /*0x104f87a7f*/
      if ( FFlag::SimMoveHumanoidsToFixedStep == 1 ) /*0x104f87a89*/
      {
        LOBYTE(v7) = RBX::Workspace::getUseFixedSimulationEnabled(this); /*0x104f87a8e*/
        if ( (_BYTE)v7 != 0 ) /*0x104f87a95*/
          LOBYTE(v7) = RBX::RunService::gameFixedStepped(a1: v12); /*0x104f87aad*/
      }
    }
  }
  return (char)v7; /*0x104f87ab2*/
}

// Address: 0x104f87abe | Name: __ZN3RBX9Workspace17onPropertyChangedERKNS_10Reflection18PropertyDescriptorE
void __fastcall RBX::Workspace::onPropertyChanged(RBX::Workspace *this, const RBX::Reflection::PropertyDescriptor *a2)
{
  __int64 v2; // rax
  __int64 v5; // r15
  char *v6; // rdi
  int v7; // eax
  char v8; // al
  char v9[25]; // [rsp+7h] [rbp-19h] BYREF

  v9[0] = HIBYTE(v2); /*0x104f87ac7*/
  if ( DFFlag::DebugAuroraAllowAdaptiveTimestepping == 0 /*0x104f87b1b*/
    && FFlag::DebugSimForceAdaptiveTimeStepping == 0
    && FFlag::SAuthWorkspacePropertyEnabled == 1
    && FFlag::SAuthWorkspaceFlagged == 1
    && *((_DWORD *)this + 287) /* +1148: NO 2022 FIELD */ != 1
    && (RBX::WorkspaceProperties::prop_PhysicsSteppingMethod == (_UNKNOWN *)a2
     || RBX::WorkspaceProperties::prop_AuthorityMode == (_UNKNOWN *)a2) )
  {
    RBX::World::setPhysicsSteppingMethod(a1: *((RBX::World **)this + 118), a2: 1); /*0x104f87b29*/
  }
  if ( (FFlag::UseFixedSimulationThreePhaseRolloutProperty != 0 || FFlag::UseFixedSimulationDefaultEnabled == 1) /*0x104f87b4a*/
    && RBX::WorkspaceProperties::prop_UseFixedSimulation == (_UNKNOWN *)a2 )
  {
    v5 = *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */; /*0x104f87b4c*/
    *(_BYTE *)(v5 + 553) = RBX::Workspace::getUseFixedSimulationEnabled(this); /*0x104f87b5b*/
  }
  if ( RBX::WorkspaceProperties::prop_UseNewLuauTypeSolver == (_UNKNOWN *)a2 ) /*0x104f87b6c*/
    rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::Workspace *)((char *)this + 1456 /* +1456 = stickyCommand.._Rep (std::_Ref_count_base *, 8B) -- SIZE CONFLICT, see --verify */)); /*0x104f87b75*/
  if ( RBX::WorkspaceProperties::prop_LuauTypeCheckMode == (_UNKNOWN *)a2 ) /*0x104f87b84*/
    rbx::signal<void ()(RBX::Enums::LuauTypeCheckMode)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (char *)this + 1480 /* +1480 = verbContainer (std::unique_ptr<RBX::VerbContainer>, 8B) -- SIZE CONFLICT, see --verify */); /*0x104f87b9a*/
  if ( FFlag::SimTurbulentFlow == 1 && RBX::WorkspaceProperties::prop_AirTurbulenceIntensity == (_UNKNOWN *)a2 ) /*0x104f87bb5*/
    RBX::World::setAirTurbulenceIntensity( /*0x104f87bc7*/
      this: *((RBX::FluidModels::FixedProfileFluid ***)this + 118),
      a2: *((float *)this + 286) /* +1144 likely monotonicClock.newDifferentialUS -- UNVERIFIED */);
  if ( FFlag::SimImprovedAnimationConstraintRollout != 0 ) /*0x104f87bd3*/
  {
    if ( RBX::WorkspaceProperties::prop_ImprovedAnimationConstraint == (_UNKNOWN *)a2 ) /*0x104f87bdf*/
    {
      v6 = (char *)this + 1488 /* +1488 = flySteps (int, 4B) -- SIZE CONFLICT, see --verify */; /*0x104f87be1*/
      v7 = *((_DWORD *)this + 294) /* +1176 likely networkOwnershipUnitMovedWorldConnection.con.weak_slot.p_ -- UNVERIFIED */; /*0x104f87be8*/
      switch ( v7 ) /*0x104f87bf1*/
      {
        case 0: /*0x104f87bf1*/
          goto LABEL_29; /*0x104f87bf1*/
        case 1: /*0x104f87bf1*/
          v8 = 0; /*0x104f87c28*/
          break; /*0x104f87c28*/
        case 2: /*0x104f87bf1*/
          v8 = 1; /*0x104f87bfd*/
          break;
        default:
LABEL_29:
          v8 = FFlag::SimImprovedAnimationConstraintDefaultEnabled; /*0x104f87c20*/
          break;
      }
LABEL_31:
      v9[0] = v8; /*0x104f87c2a*/
      rbx::signal<void ()(bool)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: v6, a2: v9); /*0x104f87c30*/
    }
  }
  else
  {
    v8 = FFlag::SimImprovedAnimationConstraintDefaultEnabled; /*0x104f87c01*/
    if ( FFlag::SimImprovedAnimationConstraintDefaultEnabled == 1 /*0x104f87c15*/
      && RBX::WorkspaceProperties::prop_ImprovedAnimationConstraint == (_UNKNOWN *)a2 )
    {
      v6 = (char *)this + 1488 /* +1488 = flySteps (int, 4B) -- SIZE CONFLICT, see --verify */; /*0x104f87c17*/
      goto LABEL_31; /*0x104f87c1e*/
    }
  }
  RBX::ModelInstance::onPropertyChanged(this, a2); /*0x104f87c35*/
}

// Address: 0x104f87c4c | Name: __ZNK3RBX9Workspace37getImprovedAnimationConstraintEnabledEv
char __fastcall RBX::Workspace::getImprovedAnimationConstraintEnabled(RBX::Workspace *this)
{
  int v1; // eax

  if ( FFlag::SimImprovedAnimationConstraintRollout != 1 ) /*0x104f87c57*/
    return FFlag::SimImprovedAnimationConstraintDefaultEnabled; /*0x104f87c57*/
  v1 = *((_DWORD *)this + 294) /* +1176 likely networkOwnershipUnitMovedWorldConnection.con.weak_slot.p_ -- UNVERIFIED */; /*0x104f87c59*/
  if ( v1 == 2 ) /*0x104f87c62*/
    return 1; /*0x104f87c77*/
  if ( v1 != 1 ) /*0x104f87c67*/
    return FFlag::SimImprovedAnimationConstraintDefaultEnabled; /*0x104f87c72*/
  return 0; /*0x104f87c71*/
}

// Address: 0x104f87c7c | Name: __ZN3RBX9Workspace14getBoundingBoxEv
RBX::Workspace *__fastcall RBX::Workspace::getBoundingBox(RBX::Workspace *this, RBX::ModelInstance *a2)
{
  RBX::ModelInstance::setExtentsDirtyMe(this: a2); /*0x104f87c8c*/
  RBX::ModelInstance::getBoundingBox(this, a2); /*0x104f87c97*/
  return this; /*0x104f87c9f*/
}

// Address: 0x104f87ca4 | Name: __ZNK3RBX9Workspace8getPivotEv
RBX::Workspace *__fastcall RBX::Workspace::getPivot(RBX::Workspace *this, __int64 a2)
{
  __int128 *v3; // rax
  __int128 v4; // xmm0
  __int128 v5; // xmm1
  _BYTE v7[24]; // [rsp+8h] [rbp-18h] BYREF

  if ( FFlag::UnboxTheWorld == 1 ) /*0x104f87cb9*/
  {
    RBX::OptionalCoordinateFrame::OptionalCoordinateFrame( /*0x104f87cc9*/
      this: (RBX::OptionalCoordinateFrame *)v7,
      a2: (const RBX::OptionalCoordinateFrame *)(a2 + 240));
    if ( (unsigned __int8)RBX::OptionalCoordinateFrame::has_value(this: (RBX::OptionalCoordinateFrame *)v7) != 0 ) /*0x104f87cd8*/
    {
      v3 = (__int128 *)RBX::OptionalCoordinateFrame::get(this: (RBX::OptionalCoordinateFrame *)v7); /*0x104f87cde*/
      v4 = *v3; /*0x104f87ce3*/
      v5 = v3[1]; /*0x104f87ce6*/
      *((_OWORD *)this + 2) = v3[2]; /*0x104f87cee*/
      *((_OWORD *)this + 1) = v5; /*0x104f87cf2*/
      *(_OWORD *)this = v4; /*0x104f87cf6*/
    }
    else
    {
      *(_OWORD *)this = 0x3F800000u; /*0x104f87d0d*/
      *((_OWORD *)this + 1) = 0x3F800000u; /*0x104f87d10*/
      *((_DWORD *)this + 8) /* +32: NO 2022 FIELD */ = 1065353216; /*0x104f87d14*/
      *(_QWORD *)((char *)this + 36 /* +36: NO 2022 FIELD */) = 0; /*0x104f87d1b*/
      *((_DWORD *)this + 11) /* +44: NO 2022 FIELD */ = 0; /*0x104f87d23*/
    }
    RBX::OptionalCoordinateFrame::~OptionalCoordinateFrame(this: (RBX::OptionalCoordinateFrame *)v7); /*0x104f87d2e*/
  }
  else
  {
    RBX::ModelInstance::getPivot(this, a2); /*0x104f87cfe*/
  }
  return this; /*0x104f87d36*/
}

// Address: 0x104f87d54 | Name: __ZN3RBX9Workspace17onWorldTouchEventEPNS_9PrimitiveES2_NS_14TouchEventTypeEb
__int64 __fastcall RBX::Workspace::onWorldTouchEvent(
        _QWORD *a1,
        RBX::Primitive *a2,
        RBX::Primitive *a3,
        int a4,
        int a5)
{
  RBX::BasePart *v6; // r12
  RBX::World *v8; // r14
  const RBX::Guid *Guid; // r15
  const RBX::Guid *v10; // rax
  int v11; // eax
  RBX::Primitive *v12; // rsi
  RBX::BasePart *v13; // rdi
  __int64 v14; // r14
  RBX::Primitive *v15; // rsi
  __int64 v16; // r15
  __int64 result; // rax
  std::__shared_weak_count *v18; // rcx
  __int128 v19; // kr00_16
  __int16 v20; // di
  unsigned __int64 v21; // r8
  volatile signed __int64 *v22; // r14
  std::__shared_weak_count *v23; // rbx
  std::__shared_weak_count *v24; // rbx
  std::__shared_weak_count *v25; // rbx
  std::__shared_weak_count *v26[2]; // [rsp+0h] [rbp-80h] BYREF
  __int128 v27; // [rsp+10h] [rbp-70h]
  __int16 v28; // [rsp+20h] [rbp-60h]
  std::__shared_weak_count *v29; // [rsp+30h] [rbp-50h] BYREF
  std::__shared_weak_count *v30; // [rsp+38h] [rbp-48h]
  __int128 v31; // [rsp+40h] [rbp-40h] BYREF
  int v32; // [rsp+50h] [rbp-30h]
  int v33; // [rsp+54h] [rbp-2Ch]

  v33 = a5; /*0x104f87d65*/
  v32 = a4; /*0x104f87d69*/
  v6 = a2; /*0x104f87d6f*/
  v8 = (RBX::World *)a1[118]; /*0x104f87d75*/
  Guid = (const RBX::Guid *)RBX::Primitive::getGuid(this: a2); /*0x104f87d84*/
  v10 = (const RBX::Guid *)RBX::Primitive::getGuid(this: a3); /*0x104f87d8a*/
  v11 = RBX::World::compareGuids(this: v8, a2: Guid, a3: v10); /*0x104f87d98*/
  v13 = a3; /*0x104f87d9f*/
  if ( v11 <= 0 ) /*0x104f87da2*/
  {
    v13 = v6; /*0x104f87da2*/
    v6 = a3; /*0x104f87da6*/
  }
  v14 = RBX::BasePart::fromPrimitive(this: v13, a2: v12); /*0x104f87daf*/
  v16 = RBX::BasePart::fromPrimitive(this: v6, a2: v15); /*0x104f87dba*/
  RBX::shared_from<RBX::BasePart>(a1: &v29, a2: v14); /*0x104f87dc4*/
  RBX::shared_from<RBX::BasePart>(a1: &v31, a2: v16); /*0x104f87dd3*/
  result = (__int64)v29; /*0x104f87dd8*/
  v18 = v30; /*0x104f87ddc*/
  v26[0] = v29; /*0x104f87de0*/
  v26[1] = v30; /*0x104f87de4*/
  if ( v30 != nullptr ) /*0x104f87deb*/
    _InterlockedIncrement64((volatile signed __int64 *)v30 + 1); /*0x104f87ded*/
  v19 = v31; /*0x104f87df6*/
  v27 = v31; /*0x104f87dfa*/
  if ( *((_QWORD *)&v31 + 1) != 0 ) /*0x104f87e05*/
    _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v31 + 1) + 8LL)); /*0x104f87e07*/
  v20 = ((unsigned __int8)v33 << 8) | (unsigned __int8)v32; /*0x104f87e1d*/
  v28 = v20; /*0x104f87e20*/
  v21 = a1[224]; /*0x104f87e25*/
  if ( v21 >= a1[225] ) /*0x104f87e33*/
  {
    result = std::vector<std::pair<RBX::SignalPair,std::pair<RBX::TouchEventType,bool>>>::__emplace_back_slow_path<std::pair<RBX::SignalPair,std::pair<RBX::TouchEventType,bool>>>( /*0x104f87e6d*/
               a1: a1 + 223,
               a2: v26);
    v22 = *((volatile signed __int64 **)&v27 + 1); /*0x104f87e72*/
    a1[224] = result; /*0x104f87e76*/
    if ( v22 != nullptr ) /*0x104f87e80*/
    {
      result = _InterlockedExchangeAdd64(v22 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x104f87e89*/
      if ( result == 0 ) /*0x104f87e92*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v22 + 16))(a1: v22); /*0x104f87e9a*/
        result = std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v22); /*0x104f87ea0*/
      }
    }
  }
  else
  {
    *(_QWORD *)v21 = result; /*0x104f87e35*/
    *(_QWORD *)(v21 + 8) = v18; /*0x104f87e38*/
    *(_OWORD *)v26 = 0; /*0x104f87e3f*/
    *(_OWORD *)(v21 + 16) = v19; /*0x104f87e43*/
    v27 = 0; /*0x104f87e4b*/
    *(_WORD *)(v21 + 32) = v20; /*0x104f87e50*/
    a1[224] = v21 + 40; /*0x104f87e59*/
  }
  v23 = v26[1]; /*0x104f87ea5*/
  if ( v26[1] != nullptr ) /*0x104f87eac*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v26[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x104f87eb5*/
    if ( result == 0 ) /*0x104f87ebe*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v23 + 16LL))(a1: v23); /*0x104f87ec6*/
      result = std::__shared_weak_count::__release_weak(this: v23); /*0x104f87ecc*/
    }
  }
  v24 = *((std::__shared_weak_count **)&v31 + 1); /*0x104f87ed1*/
  if ( *((_QWORD *)&v31 + 1) != 0 ) /*0x104f87ed8*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v31 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL); /*0x104f87ee1*/
    if ( result == 0 ) /*0x104f87eea*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v24 + 16LL))(a1: v24); /*0x104f87ef2*/
      result = std::__shared_weak_count::__release_weak(this: v24); /*0x104f87ef8*/
    }
  }
  v25 = v30; /*0x104f87efd*/
  if ( v30 != nullptr ) /*0x104f87f04*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v30 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x104f87f0d*/
    if ( result == 0 ) /*0x104f87f16*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v25 + 16LL))(a1: v25); /*0x104f87f1e*/
      return std::__shared_weak_count::__release_weak(this: v25); /*0x104f87f24*/
    }
  }
  return result; /*0x104f87f29*/
}

// Address: 0x104f87f6a | Name: __ZThn1328_N3RBX9Workspace17onWorldTouchEventEPNS_9PrimitiveES2_NS_14TouchEventTypeEb
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::onWorldTouchEvent(
        __int64 a1,
        RBX::Primitive *a2,
        RBX::Primitive *a3,
        int a4,
        int a5)
{
  return RBX::Workspace::onWorldTouchEvent(a1: (_QWORD *)(a1 - 1328), a2, a3, a4, a5); /*0x104f87f75*/
}

// Address: 0x104f87f7c | Name: __ZN3RBX9Workspace18receiveRemoteTouchERKNSt3__14pairINS_10SignalPairENS_17TouchStateManagerEEE
__int64 __fastcall RBX::Workspace::receiveRemoteTouch(__int64 a1, __int64 a2)
{
  RBX::BasePart *v3; // r14
  RBX::PartComponentHelpers *v4; // rdi
  __int64 result; // rax

  v3 = (RBX::BasePart *)(a2 + 16); /*0x104f87f98*/
  switch ( *(_BYTE *)(a2 + 32) ) /*0x104f87faa*/
  {
    case 0: /*0x104f87faa*/
    case 3: /*0x104f87faa*/
      goto LABEL_7;
    case 1: /*0x104f87faa*/
      v4 = *(RBX::PartComponentHelpers **)a2; /*0x104f87fac*/
      goto LABEL_4; /*0x104f87fb2*/
    case 2: /*0x104f87faa*/
      RBX::BasePart::fireTouchSignals(this: *(RBX::PartComponentHelpers **)a2, a2: (RBX::BasePart *)(a2 + 16)); /*0x104f87fc1*/
      RBX::BasePart::fireTouchSignals(this: *(RBX::PartComponentHelpers **)(a2 + 16), (RBX::BasePart *)a2); /*0x104f87fd1*/
      v4 = *(RBX::PartComponentHelpers **)a2; /*0x104f87fd6*/
LABEL_4:
      RBX::BasePart::fireTouchSignals(this: v4, a2: v3); /*0x104f87fd9*/
      RBX::BasePart::fireTouchSignals(this: *(RBX::PartComponentHelpers **)(a2 + 16), (RBX::BasePart *)a2); /*0x104f87ff6*/
      goto LABEL_7; /*0x104f87ffb*/
    case 4: /*0x104f87faa*/
      goto LABEL_6;
    case 5: /*0x104f87faa*/
      RBX::BasePart::fireTouchSignals(this: *(RBX::PartComponentHelpers **)a2, a2: (RBX::BasePart *)(a2 + 16)); /*0x104f8800a*/
      RBX::BasePart::fireTouchSignals(this: *(RBX::PartComponentHelpers **)(a2 + 16), (RBX::BasePart *)a2); /*0x104f8801d*/
LABEL_6:
      RBX::BasePart::fireTouchSignals(this: *(RBX::PartComponentHelpers **)a2, a2: v3); /*0x104f88022*/
      RBX::BasePart::fireTouchSignals(this: *(RBX::PartComponentHelpers **)(a2 + 16), (RBX::BasePart *)a2); /*0x104f8803c*/
LABEL_7:
      RBX::BasePart::fireTouchSignals(this: *(RBX::PartComponentHelpers **)a2, a2: v3); /*0x104f88044*/
      result = RBX::BasePart::fireTouchSignals(this: *(RBX::PartComponentHelpers **)(a2 + 16), (RBX::BasePart *)a2); /*0x104f8806e*/
      break; /*0x104f8806e*/
    default:
      return result;
  }
  return result; /*0x104f88068*/
}

// Address: 0x104f88098 | Name: __ZN3RBX9Workspace30queueRemoteTouchForRebroadcastENSt3__14pairINS_10SignalPairENS_17TouchStateManagerEEE
unsigned __int8 *__fastcall RBX::Workspace::queueRemoteTouchForRebroadcast(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  unsigned __int8 *result; // rax
  _BYTE *v8; // r14

  result = (unsigned __int8 *)RBX::DenseHashMap<RBX::SignalPair,RBX::TouchStateManager,RBX::Hash<RBX::SignalPair>,std::equal_to<RBX::SignalPair>>::operator[]( /*0x104f880a9*/
                                a1: a1 + 1808,
                                a2,
                                a3,
                                a4,
                                a5,
                                a6);
  if ( *(_BYTE *)(a2 + 33) == 1 ) /*0x104f880b2*/
  {
    v8 = result; /*0x104f880b4*/
    if ( result[1] != 0 ) /*0x104f880bb*/
    {
      result = (unsigned __int8 *)RBX::TouchStateManager::concatStates(a1: *result, a2: *(unsigned __int8 *)(a2 + 32)); /*0x104f880c5*/
      *v8 = (_BYTE)result; /*0x104f880ca*/
    }
    else
    {
      result = *(unsigned __int8 **)(a2 + 32); /*0x104f880cf*/
      *(_QWORD *)v8 = result; /*0x104f880d3*/
    }
  }
  return result; /*0x104f880d6*/
}

// Address: 0x104f880dc | Name: __ZN3RBX9Workspace39handleNetworkOwnershipUnitChangedSignalEPNS_9PrimitiveEb
__int64 __fastcall RBX::Workspace::handleNetworkOwnershipUnitChangedSignal(
        RBX::Workspace *this,
        RBX::Primitive *a2,
        char a3)
{
  __int64 result; // rax
  __int64 v5; // [rsp+8h] [rbp-18h] BYREF
  _BYTE v6[9]; // [rsp+17h] [rbp-9h] BYREF

  v6[0] = a3; /*0x104f880e8*/
  result = RBX::BasePart::fromPrimitive(this: a2, a2); /*0x104f880ee*/
  v5 = result; /*0x104f880f3*/
  if ( result != 0 ) /*0x104f880fa*/
    return rbx::signal<void ()(RBX::BasePart *,bool)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x104f8810e*/
             a1: (char *)this + 1520 /* +1520 = currentCamera.._Ptr (RBX::Camera *, 8B) -- SIZE CONFLICT, see --verify */,
             a2: &v5,
             a3: v6);
  return result; /*0x104f88113*/
}

// Address: 0x104f8811a | Name: __ZN3RBX9Workspace32queueInstancePhysicsSynchPackageEPNS_8BasePartEONS_19PhysicsSynchPackageE
__int64 __fastcall RBX::Workspace::queueInstancePhysicsSynchPackage(__int64 a1)
{
  return RBX::WorkspaceSynchHelper::queueInstancePhysicsSynchPackage(a1: a1 + 2392); /*0x104f88125*/
}

// Address: 0x104f8812c | Name: __ZN3RBX9Workspace38blockStaleInstanceSynchDataAtTimestampEPNS_8BasePartEi
__int64 __fastcall RBX::Workspace::blockStaleInstanceSynchDataAtTimestamp(
        RBX::Workspace *this,
        RBX::BasePart *a2,
        int a3)
{
  return RBX::WorkspaceSynchHelper::blockStaleInstanceSynchDataAtTimestamp( /*0x104f88137*/
           this: (RBX::Workspace *)((char *)this + 2392 /* +2392: NO 2022 FIELD */),
           a2,
           a3);
}

// Address: 0x104f8813e | Name: __ZNK3RBX9Workspace20getDtFromTimestampIdEi
__int64 __fastcall RBX::Workspace::getDtFromTimestampId(RBX::Workspace *this, int a2)
{
  return RBX::WorkspaceSynchHelper::getDtFromTimestampId(this: (RBX::Workspace *)((char *)this + 2392 /* +2392: NO 2022 FIELD */), a2); /*0x104f88149*/
}

// Address: 0x104f88150 | Name: __ZN3RBX9Workspace30getNetworkOwnershipUnitExtentsEPNS_8BasePartE
RBX::Workspace *__fastcall RBX::Workspace::getNetworkOwnershipUnitExtents(RBX::Workspace *this, RBX::BasePart *a2)
{
  RBX::Primitive *v3; // rdi
  __int64 Assembly; // rax

  this->... /* +0 */= 0x7F7FFFFF7F7FFFFFLL; /*0x104f88161*/
  *((_DWORD *)this + 2) /* +8: NO 2022 FIELD */ = 2139095039; /*0x104f88165*/
  *(_QWORD *)((char *)this + 12 /* +12: NO 2022 FIELD */) = 0xFF7FFFFFFF7FFFFFLL; /*0x104f88174*/
  *((_DWORD *)this + 5) /* +20: NO 2022 FIELD */ = -8388609; /*0x104f88179*/
  if ( a2 != nullptr ) /*0x104f88183*/
  {
    v3 = *((RBX::Primitive **)a2 + 47); /*0x104f88185*/
    if ( v3 != nullptr ) /*0x104f8818f*/
    {
      Assembly = RBX::Primitive::getAssembly(this: v3, a2); /*0x104f88191*/
      if ( Assembly != 0 ) /*0x104f88199*/
        RBX::Assembly::getAssemblyExtentsIncludingChildAssembliesInNOU(this, a2: Assembly); /*0x104f881a1*/
    }
  }
  return this; /*0x104f881ad*/
}

// Address: 0x104f881b0 | Name: __ZN3RBX9Workspace50getNetworkOwnershipUnitPhysicsInstances_deprecatedEPNS_8BasePartERNSt3__16vectorIPNS_8InstanceENS3_9allocatorIS6_EEEE
__int64 __fastcall RBX::Workspace::getNetworkOwnershipUnitPhysicsInstances_deprecated(__int64 a1, RBX::Primitive *a2)
{
  __int64 v2; // r14
  RBX::Assembly *Assembly; // rax
  RBX::Assembly *v4; // rbx
  RBX::Primitive *AssemblyPrimitive; // rbx
  const RBX::Primitive *v6; // rsi
  __int64 ConstRootMovingPrimitive; // r12
  RBX::Primitive *v8; // rsi
  unsigned int v9; // eax
  __int64 v10; // r14
  RBX::Joint **v11; // rax
  RBX::Joint *NextJoint; // rax
  RBX::Primitive *v13; // rsi
  RBX::Primitive *v14; // r15
  RBX::Assembly *v15; // rax
  __int64 v16; // rax
  RBX::Primitive *v17; // rsi
  __int64 v18; // r13
  __int64 JointOwner; // r15
  const RBX::Joint *v20; // rsi
  const RBX::Joint *v21; // rsi
  const RBX::Joint *v22; // rsi
  RBX::Constraints::ConstraintProp *v23; // r15
  __int64 Attachment0; // rax
  RBX::Attachment *v25; // r13
  __int64 PartAncestor; // rax
  __int64 v27; // rax
  __int64 Attachment1; // rax
  RBX::Attachment *v29; // r15
  __int64 v30; // rax
  __int64 v31; // rax
  __int64 v32; // r13
  __int64 v33; // r13
  __int64 v34; // r15
  RBX::Primitive *v35; // r15
  bool v36; // cf
  __int64 v38; // [rsp+0h] [rbp-2C0h]
  RBX::Joint *v39; // [rsp+8h] [rbp-2B8h] BYREF
  RBX::Primitive *v40; // [rsp+10h] [rbp-2B0h]
  bool IsGrounded; // [rsp+1Fh] [rbp-2A1h]
  void *v42[2]; // [rsp+20h] [rbp-2A0h] BYREF
  __int128 v43; // [rsp+30h] [rbp-290h]
  __int64 v44; // [rsp+40h] [rbp-280h]
  void *v45; // [rsp+50h] [rbp-270h] BYREF
  __int64 v46; // [rsp+58h] [rbp-268h]
  _BYTE v47[512]; // [rsp+60h] [rbp-260h] BYREF
  __int64 (__fastcall **v48)(); // [rsp+260h] [rbp-60h] BYREF
  RBX::Primitive *v49; // [rsp+268h] [rbp-58h]
  __int64 (__fastcall ***v50)(); // [rsp+280h] [rbp-40h]

  v40 = a2; /*0x104f881c4*/
  if ( a1 == 0 ) /*0x104f881dc*/
    return __stack_chk_guard; /*0x104f881dc*/
  v2 = *(_QWORD *)(a1 + 376); /*0x104f881e2*/
  if ( v2 == 0 ) /*0x104f881ec*/
    return __stack_chk_guard; /*0x104f881ec*/
  Assembly = (RBX::Assembly *)RBX::Primitive::getAssembly(this: *(RBX::Primitive **)(a1 + 376), a2); /*0x104f881f5*/
  if ( Assembly == nullptr ) /*0x104f881fd*/
    return __stack_chk_guard; /*0x104f881fd*/
  v4 = Assembly; /*0x104f88203*/
  v43 = 0; /*0x104f88209*/
  *(_OWORD *)v42 = 0; /*0x104f88210*/
  v44 = 0; /*0x104f88217*/
  IsGrounded = RBX::Assembly::computeIsGrounded(this: Assembly); /*0x104f8822a*/
  AssemblyPrimitive = (RBX::Primitive *)RBX::Assembly::getAssemblyPrimitive(this: v4); /*0x104f88238*/
  ConstRootMovingPrimitive = RBX::Primitive::getConstRootMovingPrimitive(this: AssemblyPrimitive, a2: v6); /*0x104f88243*/
  v45 = v47; /*0x104f8824d*/
  v46 = 0x4000000000LL; /*0x104f8825b*/
  RBX::SmallVectorTemplateBase<RBX::Primitive *,true>::push_back(a1: (__int64)&v45, a2: (__int64)AssemblyPrimitive); /*0x104f88269*/
  v9 = v46; /*0x104f88275*/
  v38 = v2; /*0x104f88283*/
  do /*0x104f885bb*/
  {
    if ( ((unsigned __int64)v9 - 1) >> 32 != 0 ) /*0x104f88297*/
      RBXCRASH(a1: 0, a2: ""); /*0x104f8861c*/
    v10 = *((_QWORD *)v45 + v9 - 1); /*0x104f882a4*/
    LODWORD(v46) = v9 - 1; /*0x104f882a9*/
    v48 = (__int64 (__fastcall **)())RBX::BasePart::fromPrimitive(this: (RBX::BasePart *)v10, a2: v8); /*0x104f882b7*/
    std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: v40, a2: &v48); /*0x104f882c5*/
    v11 = *(RBX::Joint ***)(v10 + 384); /*0x104f882ca*/
    if ( *(RBX::Joint ***)(v10 + 392) != v11 ) /*0x104f882d8*/
    {
      NextJoint = *v11; /*0x104f882de*/
      while ( 2 ) /*0x104f882e1*/
      {
        v39 = NextJoint; /*0x104f882e1*/
        do /*0x104f8838f*/
        {
          if ( NextJoint == nullptr ) /*0x104f882eb*/
            goto LABEL_40; /*0x104f882eb*/
          if ( RBX::detail::DenseHashTable<RBX::Joint *,RBX::Joint *,RBX::Joint *,RBX::detail::ItemInterfaceSet<RBX::Joint *>,RBX::Hash<RBX::Joint *>,std::equal_to<RBX::Joint *>>::find( /*0x104f88303*/
                 a1: v42,
                 a2: &v39) != 0 )
            goto LABEL_39; /*0x104f88303*/
          RBX::DenseHashSet<RBX::Joint *,RBX::Hash<RBX::Joint *>,std::equal_to<RBX::Joint *>>::insert( /*0x104f88313*/
            a1: v42,
            a2: (__int64)&v39);
          v14 = *((RBX::Primitive **)v39 + 19); /*0x104f8831f*/
          if ( v14 == (RBX::Primitive *)v10 ) /*0x104f88329*/
            v14 = *((RBX::Primitive **)v39 + 20); /*0x104f8832b*/
          if ( IsGrounded ) /*0x104f88339*/
          {
            v15 = (RBX::Assembly *)RBX::Primitive::getAssembly(this: v14, a2: v13); /*0x104f8833e*/
            v16 = RBX::Assembly::getAssemblyPrimitive(this: v15); /*0x104f88346*/
          }
          else
          {
            v16 = RBX::Primitive::getConstRootMovingPrimitive(this: v14, a2: v13); /*0x104f88350*/
          }
          v18 = v16; /*0x104f88355*/
          if ( RBX::BasePart::fromPrimitive(this: v14, a2: v17) == 0 || v18 != v38 ) /*0x104f88370*/
            goto LABEL_39; /*0x104f88370*/
          JointOwner = RBX::Joint::getJointOwner(this: v39); /*0x104f88382*/
          NextJoint = v39; /*0x104f88385*/
        }
        while ( JointOwner == 0 ); /*0x104f8838f*/
        if ( RBX::Joint::isJointInstanceOwned(this: v39, a2: v8) /*0x104f883c8*/
          || RBX::Joint::isWeldConstraintOwned(this: v39, a2: v20) )
        {
          v48 = (__int64 (__fastcall **)())(JointOwner - 224); /*0x104f883a8*/
          std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: v40, a2: &v48); /*0x104f883b7*/
          goto LABEL_39; /*0x104f883bc*/
        }
        if ( RBX::Joint::isDragDetectorOwned(this: v39, a2: v21) ) /*0x104f883f8*/
        {
          v48 = (__int64 (__fastcall **)())(JointOwner - 400); /*0x104f88408*/
          std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: v40, a2: &v48); /*0x104f88417*/
          goto LABEL_39; /*0x104f8841c*/
        }
        if ( (unsigned __int8)RBX::Joint::isConstraintOwned(this: v39, a2: v22) == 0 ) /*0x104f8842f*/
          goto LABEL_39; /*0x104f8842f*/
        v48 = (__int64 (__fastcall **)())(JointOwner - 192); /*0x104f8843c*/
        std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: v40, a2: &v48); /*0x104f8844b*/
        v23 = (RBX::Constraints::ConstraintProp *)(JointOwner - 16); /*0x104f88450*/
        Attachment0 = RBX::Constraints::ConstraintProp::getAttachment0(this: v23); /*0x104f88457*/
        v25 = (RBX::Attachment *)Attachment0; /*0x104f8845c*/
        if ( Attachment0 != 0 ) /*0x104f88462*/
        {
          v48 = (__int64 (__fastcall **)())Attachment0; /*0x104f88464*/
          std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: v40, a2: &v48); /*0x104f88473*/
          PartAncestor = RBX::Attachment::findPartAncestor(this: v25); /*0x104f8847b*/
          if ( PartAncestor != 0 ) /*0x104f88483*/
          {
            v48 = off_10C9F1CA8; /*0x104f8848c*/
            v49 = v40; /*0x104f88497*/
            v50 = &v48; /*0x104f884a2*/
            RBX::NetworkUtil::forEachAttachmentBetweenAttachmentAndOwnerPart(a1: v25, a2: PartAncestor, a3: &v48, a4: 4); /*0x104f884b1*/
            if ( v50 == &v48 ) /*0x104f884bd*/
            {
              v27 = 4; /*0x104f884cb*/
            }
            else
            {
              v27 = 5; /*0x104f884bf*/
              if ( v50 == nullptr ) /*0x104f884c7*/
                goto LABEL_32; /*0x104f884c7*/
            }
            (*v50)[v27](); /*0x104f884d3*/
          }
        }
LABEL_32:
        Attachment1 = RBX::Constraints::ConstraintProp::getAttachment1(this: v23); /*0x104f884d6*/
        v29 = (RBX::Attachment *)Attachment1; /*0x104f884de*/
        if ( Attachment1 != 0 ) /*0x104f884e4*/
        {
          v48 = (__int64 (__fastcall **)())Attachment1; /*0x104f884e6*/
          std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: v40, a2: &v48); /*0x104f884f5*/
          v30 = RBX::Attachment::findPartAncestor(this: v29); /*0x104f884fd*/
          if ( v30 == 0 ) /*0x104f88505*/
            goto LABEL_39; /*0x104f88505*/
          v48 = off_10C9F1D38; /*0x104f8850e*/
          v49 = v40; /*0x104f88519*/
          v50 = &v48; /*0x104f88521*/
          RBX::NetworkUtil::forEachAttachmentBetweenAttachmentAndOwnerPart(a1: v29, a2: v30, a3: &v48, a4: 4); /*0x104f88533*/
          if ( v50 == &v48 ) /*0x104f8853f*/
          {
            v31 = 4; /*0x104f8854d*/
          }
          else
          {
            v31 = 5; /*0x104f88541*/
            if ( v50 == nullptr ) /*0x104f88549*/
              goto LABEL_39; /*0x104f88549*/
          }
          (*v50)[v31](); /*0x104f88555*/
        }
LABEL_39:
        NextJoint = (RBX::Joint *)RBX::Primitive::getNextJoint(this: (RBX::Primitive *)v10, a2: v39); /*0x104f88558*/
        continue; /*0x104f88567*/
      }
    }
LABEL_40:
    v32 = *(int *)(v10 + 40); /*0x104f8856c*/
    if ( v32 > 0 ) /*0x104f88573*/
    {
      v33 = v32 + 1; /*0x104f88575*/
      do /*0x104f885ad*/
      {
        v34 = *(_QWORD *)(*(_QWORD *)(v10 + 32) + 8 * v33 - 16); /*0x104f8857c*/
        if ( v34 != 0 ) /*0x104f88584*/
        {
          v35 = (RBX::Primitive *)(v34 - 16); /*0x104f88586*/
          if ( RBX::Primitive::getConstRootMovingPrimitive(this: v35, a2: v8) == ConstRootMovingPrimitive ) /*0x104f88595*/
            RBX::SmallVectorTemplateBase<RBX::Primitive *,true>::push_back(a1: (__int64)&v45, a2: (__int64)v35); /*0x104f885a1*/
        }
        v36 = v33-- == 1; /*0x104f885a9*/
      }
      while ( !v36 && v33 != 1 ); /*0x104f885ad*/
    }
    v9 = v46; /*0x104f885af*/
  }
  while ( (_DWORD)v46 != 0 ); /*0x104f885bb*/
  if ( v45 != v47 ) /*0x104f885d2*/
    operator delete(a1: v45); /*0x104f885d4*/
  if ( v42[0] != nullptr ) /*0x104f885e3*/
  {
    v42[1] = v42[0]; /*0x104f885e5*/
    operator delete(a1: v42[0]); /*0x104f885ec*/
  }
  return __stack_chk_guard; /*0x104f88601*/
}

// Address: 0x104f886a6 | Name: __ZN3RBX9Workspace63getNetworkOwnershipUnitCriticalFixedPhysicsInstances_deprecatedEPNS_8BasePartERNSt3__16vectorIPNS_8InstanceENS3_9allocatorIS6_EEEE
__int64 __fastcall RBX::Workspace::getNetworkOwnershipUnitCriticalFixedPhysicsInstances_deprecated(
        __int64 a1,
        RBX::Primitive *a2)
{
  RBX::Primitive *v2; // rdi
  RBX::Assembly *Assembly; // rax
  RBX::Assembly *v4; // rbx
  RBX::Primitive *AssemblyPrimitive; // rbx
  const RBX::Primitive *v6; // rsi
  __int64 ConstRootMovingPrimitive; // r14
  const RBX::Primitive *v8; // rsi
  unsigned int v9; // eax
  __int64 v10; // rbx
  RBX::Joint **v11; // rax
  RBX::Joint *NextJoint; // rax
  RBX::Primitive *v13; // rsi
  RBX::BasePart *v14; // r12
  const RBX::Primitive *v15; // rsi
  __int64 v16; // r13
  __int64 JointOwner; // r12
  const RBX::Joint *v18; // rsi
  const RBX::Joint *v19; // rsi
  const RBX::Joint *v20; // rsi
  const RBX::Joint *v21; // rsi
  RBX::Constraints::ConstraintProp *v22; // r12
  __int64 Attachment0; // rax
  RBX::Attachment *v24; // r13
  __int64 PartAncestor; // rax
  __int64 v26; // rax
  __int64 Attachment1; // rax
  RBX::Attachment *v28; // r12
  __int64 v29; // rax
  __int64 v30; // rax
  __int64 v31; // r13
  __int64 v32; // r13
  __int64 v33; // r12
  RBX::Primitive *v34; // r12
  bool v35; // cf
  RBX::Joint *i; // [rsp+8h] [rbp-2A8h] BYREF
  void *v39[2]; // [rsp+10h] [rbp-2A0h] BYREF
  __int128 v40; // [rsp+20h] [rbp-290h]
  __int64 v41; // [rsp+30h] [rbp-280h]
  void *v42; // [rsp+40h] [rbp-270h] BYREF
  __int64 v43; // [rsp+48h] [rbp-268h]
  _BYTE v44[512]; // [rsp+50h] [rbp-260h] BYREF
  __int64 (__fastcall **v45)(); // [rsp+250h] [rbp-60h] BYREF
  RBX::Primitive *v46; // [rsp+258h] [rbp-58h]
  __int64 (__fastcall ***v47)(); // [rsp+270h] [rbp-40h]

  if ( a1 == 0 ) /*0x104f886d2*/
    return __stack_chk_guard; /*0x104f886d2*/
  v2 = *(RBX::Primitive **)(a1 + 376); /*0x104f886d8*/
  if ( v2 == nullptr ) /*0x104f886e2*/
    return __stack_chk_guard; /*0x104f886e2*/
  Assembly = (RBX::Assembly *)RBX::Primitive::getAssembly(this: v2, a2); /*0x104f886e8*/
  if ( Assembly == nullptr ) /*0x104f886f0*/
    return __stack_chk_guard; /*0x104f886f0*/
  v4 = Assembly; /*0x104f886f6*/
  if ( RBX::Assembly::computeIsGrounded(this: Assembly) ) /*0x104f886fc*/
    return __stack_chk_guard; /*0x104f88703*/
  v40 = 0; /*0x104f8870c*/
  *(_OWORD *)v39 = 0; /*0x104f88713*/
  v41 = 0; /*0x104f8871a*/
  AssemblyPrimitive = (RBX::Primitive *)RBX::Assembly::getAssemblyPrimitive(this: v4); /*0x104f8872d*/
  ConstRootMovingPrimitive = RBX::Primitive::getConstRootMovingPrimitive(this: AssemblyPrimitive, a2: v6); /*0x104f88738*/
  v42 = v44; /*0x104f88742*/
  v43 = 0x4000000000LL; /*0x104f88750*/
  RBX::SmallVectorTemplateBase<RBX::Primitive *,true>::push_back(a1: (__int64)&v42, a2: (__int64)AssemblyPrimitive); /*0x104f8875e*/
  v9 = v43; /*0x104f8876a*/
  do /*0x104f88a89*/
  {
    if ( ((unsigned __int64)v9 - 1) >> 32 != 0 ) /*0x104f88781*/
      RBXCRASH(a1: 0, a2: ""); /*0x104f88aea*/
    v10 = *((_QWORD *)v42 + v9 - 1); /*0x104f8878e*/
    LODWORD(v43) = v9 - 1; /*0x104f88793*/
    v11 = *(RBX::Joint ***)(v10 + 384); /*0x104f88799*/
    if ( *(RBX::Joint ***)(v10 + 392) != v11 ) /*0x104f887a7*/
    {
      NextJoint = *v11; /*0x104f887ad*/
      while ( 2 ) /*0x104f887b0*/
      {
        for ( i = NextJoint; ; NextJoint = i ) /*0x104f887b0*/
        {
          if ( NextJoint == nullptr ) /*0x104f887ba*/
            goto LABEL_40; /*0x104f887ba*/
          if ( RBX::detail::DenseHashTable<RBX::Joint *,RBX::Joint *,RBX::Joint *,RBX::detail::ItemInterfaceSet<RBX::Joint *>,RBX::Hash<RBX::Joint *>,std::equal_to<RBX::Joint *>>::find( /*0x104f887d2*/
                 a1: v39,
                 a2: &i) != 0 )
            goto LABEL_39; /*0x104f887d2*/
          RBX::DenseHashSet<RBX::Joint *,RBX::Hash<RBX::Joint *>,std::equal_to<RBX::Joint *>>::insert( /*0x104f887e2*/
            a1: v39,
            a2: (__int64)&i);
          v14 = *((RBX::BasePart **)i + 19); /*0x104f887ee*/
          if ( v14 == (RBX::BasePart *)v10 ) /*0x104f887f8*/
            v14 = *((RBX::BasePart **)i + 20); /*0x104f887fa*/
          if ( v14 == nullptr ) /*0x104f88804*/
            goto LABEL_39; /*0x104f88804*/
          v16 = RBX::BasePart::fromPrimitive(this: v14, a2: v13); /*0x104f88812*/
          if ( v16 == 0 || !RBX::Primitive::computeIsGrounded(this: v14, a2: v15) ) /*0x104f88821*/
            goto LABEL_39; /*0x104f88828*/
          JointOwner = RBX::Joint::getJointOwner(this: i); /*0x104f8883a*/
          if ( JointOwner != 0 ) /*0x104f88840*/
            break; /*0x104f88840*/
        }
        v45 = (__int64 (__fastcall **)())v16; /*0x104f8884e*/
        std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: a2, a2: &v45); /*0x104f8885d*/
        if ( RBX::Joint::isJointInstanceOwned(this: i, a2: v18) || RBX::Joint::isWeldConstraintOwned(this: i, a2: v19) ) /*0x104f88899*/
        {
          v45 = (__int64 (__fastcall **)())(JointOwner - 224); /*0x104f88879*/
          std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: a2, a2: &v45); /*0x104f88888*/
          goto LABEL_39; /*0x104f8888d*/
        }
        if ( RBX::Joint::isDragDetectorOwned(this: i, a2: v20) ) /*0x104f888c9*/
        {
          v45 = (__int64 (__fastcall **)())(JointOwner - 400); /*0x104f888d9*/
          std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: a2, a2: &v45); /*0x104f888e8*/
          goto LABEL_39; /*0x104f888ed*/
        }
        if ( (unsigned __int8)RBX::Joint::isConstraintOwned(this: i, a2: v21) == 0 ) /*0x104f88900*/
          goto LABEL_39; /*0x104f88900*/
        v45 = (__int64 (__fastcall **)())(JointOwner - 192); /*0x104f8890e*/
        std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: a2, a2: &v45); /*0x104f8891d*/
        v22 = (RBX::Constraints::ConstraintProp *)(JointOwner - 16); /*0x104f88922*/
        Attachment0 = RBX::Constraints::ConstraintProp::getAttachment0(this: v22); /*0x104f88929*/
        v24 = (RBX::Attachment *)Attachment0; /*0x104f8892e*/
        if ( Attachment0 != 0 ) /*0x104f88934*/
        {
          v45 = (__int64 (__fastcall **)())Attachment0; /*0x104f88936*/
          std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: a2, a2: &v45); /*0x104f88945*/
          PartAncestor = RBX::Attachment::findPartAncestor(this: v24); /*0x104f8894d*/
          if ( PartAncestor != 0 ) /*0x104f88955*/
          {
            v45 = off_10C9F1DB8; /*0x104f8895e*/
            v46 = a2; /*0x104f88969*/
            v47 = &v45; /*0x104f88974*/
            RBX::NetworkUtil::forEachAttachmentBetweenAttachmentAndOwnerPart(a1: v24, a2: PartAncestor, a3: &v45, a4: 4); /*0x104f88983*/
            if ( v47 == &v45 ) /*0x104f8898f*/
            {
              v26 = 4; /*0x104f8899d*/
            }
            else
            {
              v26 = 5; /*0x104f88991*/
              if ( v47 == nullptr ) /*0x104f88999*/
                goto LABEL_32; /*0x104f88999*/
            }
            (*v47)[v26](); /*0x104f889a5*/
          }
        }
LABEL_32:
        Attachment1 = RBX::Constraints::ConstraintProp::getAttachment1(this: v22); /*0x104f889a8*/
        v28 = (RBX::Attachment *)Attachment1; /*0x104f889b0*/
        if ( Attachment1 != 0 ) /*0x104f889b6*/
        {
          v45 = (__int64 (__fastcall **)())Attachment1; /*0x104f889b8*/
          std::vector<RBX::Instance *>::push_back[abi:ne200100](a1: a2, a2: &v45); /*0x104f889c7*/
          v29 = RBX::Attachment::findPartAncestor(this: v28); /*0x104f889cf*/
          if ( v29 == 0 ) /*0x104f889d7*/
            goto LABEL_39; /*0x104f889d7*/
          v45 = off_10C9F1E38; /*0x104f889e0*/
          v46 = a2; /*0x104f889eb*/
          v47 = &v45; /*0x104f889f3*/
          RBX::NetworkUtil::forEachAttachmentBetweenAttachmentAndOwnerPart(a1: v28, a2: v29, a3: &v45, a4: 4); /*0x104f88a05*/
          if ( v47 == &v45 ) /*0x104f88a11*/
          {
            v30 = 4; /*0x104f88a1f*/
          }
          else
          {
            v30 = 5; /*0x104f88a13*/
            if ( v47 == nullptr ) /*0x104f88a1b*/
              goto LABEL_39; /*0x104f88a1b*/
          }
          (*v47)[v30](); /*0x104f88a27*/
        }
LABEL_39:
        NextJoint = (RBX::Joint *)RBX::Primitive::getNextJoint(this: (RBX::Primitive *)v10, a2: i); /*0x104f88a2a*/
        continue; /*0x104f88a39*/
      }
    }
LABEL_40:
    v31 = *(int *)(v10 + 40); /*0x104f88a3e*/
    if ( v31 > 0 ) /*0x104f88a45*/
    {
      v32 = v31 + 1; /*0x104f88a47*/
      do /*0x104f88a7f*/
      {
        v33 = *(_QWORD *)(*(_QWORD *)(v10 + 32) + 8 * v32 - 16); /*0x104f88a4e*/
        if ( v33 != 0 ) /*0x104f88a56*/
        {
          v34 = (RBX::Primitive *)(v33 - 16); /*0x104f88a58*/
          if ( RBX::Primitive::getConstRootMovingPrimitive(this: v34, a2: v8) == ConstRootMovingPrimitive ) /*0x104f88a67*/
            RBX::SmallVectorTemplateBase<RBX::Primitive *,true>::push_back(a1: (__int64)&v42, a2: (__int64)v34); /*0x104f88a73*/
        }
        v35 = v32-- == 1; /*0x104f88a7b*/
      }
      while ( !v35 && v32 != 1 ); /*0x104f88a7f*/
    }
    v9 = v43; /*0x104f88a81*/
  }
  while ( (_DWORD)v43 != 0 ); /*0x104f88a89*/
  if ( v42 != v44 ) /*0x104f88aa0*/
    operator delete(a1: v42); /*0x104f88aa2*/
  if ( v39[0] != nullptr ) /*0x104f88ab1*/
  {
    v39[1] = v39[0]; /*0x104f88ab3*/
    operator delete(a1: v39[0]); /*0x104f88aba*/
  }
  return __stack_chk_guard; /*0x104f88acf*/
}

// Address: 0x104f88b72 | Name: __ZN3RBX9Workspace23visitMovingNOUInstancesEPNS_8BasePartERKNSt3__18functionIFbPNS_8InstanceEEEERKNS4_IFbS2_S2_EEE
__int64 __fastcall RBX::Workspace::visitMovingNOUInstances(__int64 a1, RBX::Primitive *a2, __int64 a3)
{
  __int64 v4; // r13
  RBX::Assembly *Assembly; // rax
  RBX::Assembly *v8; // r12
  RBX::Primitive *v9; // rsi
  __int64 v10; // rax
  RBX::BasePart *v11; // rdi
  __int64 v12; // rax
  RBX::Primitive *AssemblyPrimitive; // r12
  const RBX::Primitive *v14; // rsi
  __int64 ConstRootMovingPrimitive; // rbx
  __int64 v16; // r8
  __int64 v17; // r9
  unsigned int v18; // eax
  unsigned __int64 v19; // rcx
  __int64 v20; // r12
  const RBX::Primitive *v21; // rsi
  __int64 v22; // r15
  __int64 v23; // r15
  __int64 v24; // r13
  RBX::Primitive *v25; // r13
  bool v26; // cf
  _QWORD v28[3]; // [rsp+0h] [rbp-260h] BYREF
  char v29; // [rsp+1Fh] [rbp-241h] BYREF
  void *v30; // [rsp+20h] [rbp-240h] BYREF
  __int64 v31; // [rsp+28h] [rbp-238h]
  _BYTE v32[512]; // [rsp+30h] [rbp-230h] BYREF

  if ( a1 != 0 ) /*0x104f88b97*/
  {
    v4 = *(_QWORD *)(a1 + 376); /*0x104f88ba0*/
    if ( v4 != 0 ) /*0x104f88baa*/
    {
      Assembly = (RBX::Assembly *)RBX::Primitive::getAssembly(this: *(RBX::Primitive **)(a1 + 376), a2); /*0x104f88bb9*/
      if ( Assembly != nullptr ) /*0x104f88bc1*/
      {
        v8 = Assembly; /*0x104f88bc7*/
        if ( !RBX::Assembly::computeIsGrounded(this: Assembly) ) /*0x104f88bcd*/
        {
          v29 = 1; /*0x104f88bda*/
          v10 = *(_QWORD *)(v4 + 24); /*0x104f88be1*/
          v11 = (RBX::BasePart *)(v10 - 16); /*0x104f88be5*/
          if ( v10 == 0 ) /*0x104f88bec*/
            v11 = nullptr; /*0x104f88bec*/
          v12 = RBX::BasePart::fromPrimitive(this: v11, a2: v9); /*0x104f88bf0*/
          if ( v12 != 0 ) /*0x104f88bf8*/
            v29 = std::function<bool ()(RBX::BasePart *,RBX::BasePart *)>::operator()(a1: a3, a2: a1, a3: v12); /*0x104f88c08*/
          AssemblyPrimitive = (RBX::Primitive *)RBX::Assembly::getAssemblyPrimitive(this: v8); /*0x104f88c16*/
          ConstRootMovingPrimitive = RBX::Primitive::getConstRootMovingPrimitive(this: AssemblyPrimitive, a2: v14); /*0x104f88c21*/
          v28[0] = a2; /*0x104f88c24*/
          v28[1] = a3; /*0x104f88c2b*/
          v28[2] = &v29; /*0x104f88c39*/
          v30 = v32; /*0x104f88c47*/
          v31 = 0x4000000000LL; /*0x104f88c55*/
          RBX::SmallVectorTemplateBase<RBX::Primitive *,true>::push_back( /*0x104f88c63*/
            a1: (__int64)&v30,
            a2: (__int64)AssemblyPrimitive);
          v18 = v31; /*0x104f88c6f*/
          do /*0x104f88d11*/
          {
            v19 = v18 - 1LL; /*0x104f88c75*/
            if ( HIDWORD(v19) != 0 ) /*0x104f88c80*/
              RBXCRASH(a1: 0, a2: ""); /*0x104f88d5a*/
            v20 = *((_QWORD *)v30 + v18 - 1); /*0x104f88c8d*/
            LODWORD(v31) = v19; /*0x104f88c92*/
            if ( FFlag::StreamingSkipLocalOnlyNOUs == 1 ) /*0x104f88ca2*/
            {
              if ( (unsigned __int8)((__int64 (__fastcall *)(_QWORD *, __int64, void *, unsigned __int64, __int64, __int64))RBX::Workspace::visitMovingNOUInstances(RBX::BasePart *,std::function<bool ()(RBX::Instance *)> const&,std::function<bool ()(RBX::BasePart *,RBX::BasePart *)> const&)::$_0::operator())( /*0x104f88cb5*/
                                      a1: v28,
                                      a2: v20,
                                      a3: v30,
                                      a4: v19,
                                      a5: v16,
                                      a6: v17) == 0 )
                break; /*0x104f88cb5*/
            }
            else
            {
              ((void (__fastcall *)(_QWORD *, __int64))RBX::Workspace::visitMovingNOUInstances(RBX::BasePart *,std::function<bool ()(RBX::Instance *)> const&,std::function<bool ()(RBX::BasePart *,RBX::BasePart *)> const&)::$_0::operator())( /*0x104f88cc3*/
                a1: v28,
                a2: v20);
            }
            v22 = *(int *)(v20 + 40); /*0x104f88cc8*/
            if ( v22 > 0 ) /*0x104f88cd0*/
            {
              v23 = v22 + 1; /*0x104f88cd2*/
              do /*0x104f88d07*/
              {
                v24 = *(_QWORD *)(*(_QWORD *)(v20 + 32) + 8 * v23 - 16); /*0x104f88cda*/
                if ( v24 != 0 ) /*0x104f88ce2*/
                {
                  v25 = (RBX::Primitive *)(v24 - 16); /*0x104f88ce4*/
                  if ( RBX::Primitive::getConstRootMovingPrimitive(this: v25, a2: v21) == ConstRootMovingPrimitive ) /*0x104f88cf3*/
                    RBX::SmallVectorTemplateBase<RBX::Primitive *,true>::push_back(a1: (__int64)&v30, a2: (__int64)v25); /*0x104f88cfb*/
                }
                v26 = v23-- == 1; /*0x104f88d03*/
              }
              while ( !v26 && v23 != 1 ); /*0x104f88d07*/
            }
            v18 = v31; /*0x104f88d09*/
          }
          while ( (_DWORD)v31 != 0 ); /*0x104f88d11*/
          if ( v30 != v32 ) /*0x104f88d28*/
            operator delete(a1: v30); /*0x104f88d2a*/
        }
      }
    }
  }
  return __stack_chk_guard; /*0x104f88d3f*/
}

// Address: 0x104f88dc2 | Name: __ZN3RBX9Workspace23visitFixedNOUComponentsEPNS_8BasePartERKNSt3__18functionIFbONS0_17FixedNOUComponentEEEE
__int64 __fastcall RBX::Workspace::visitFixedNOUComponents(__int64 a1, RBX::Primitive *a2)
{
  RBX::Primitive *v2; // rdi
  RBX::Assembly *Assembly; // rax
  RBX::Assembly *v5; // r14
  RBX::Primitive *AssemblyPrimitive; // r14
  const RBX::Primitive *v7; // rsi
  __int64 ConstRootMovingPrimitive; // rbx
  RBX::Primitive *v9; // rsi
  unsigned int v10; // eax
  __int64 v11; // r12
  __int64 v12; // rax
  char v13; // r15
  __int64 v14; // rax
  __int64 v15; // r15
  __int64 v16; // r15
  __int64 v17; // r13
  RBX::Primitive *v18; // r13
  bool v19; // cf
  RBX::Primitive *v21; // [rsp+8h] [rbp-258h] BYREF
  _QWORD v22[2]; // [rsp+10h] [rbp-250h] BYREF
  void *v23; // [rsp+20h] [rbp-240h] BYREF
  __int64 v24; // [rsp+28h] [rbp-238h]
  _BYTE v25[512]; // [rsp+30h] [rbp-230h] BYREF

  if ( a1 != 0 ) /*0x104f88de7*/
  {
    v2 = *(RBX::Primitive **)(a1 + 376); /*0x104f88ded*/
    v21 = v2; /*0x104f88df4*/
    if ( v2 != nullptr ) /*0x104f88dfe*/
    {
      Assembly = (RBX::Assembly *)RBX::Primitive::getAssembly(this: v2, a2); /*0x104f88e07*/
      if ( Assembly != nullptr ) /*0x104f88e0f*/
      {
        v5 = Assembly; /*0x104f88e15*/
        if ( RBX::Assembly::computeIsGrounded(this: Assembly) ) /*0x104f88e1b*/
        {
          v22[0] = &v21; /*0x104f88e2f*/
          v22[1] = a2; /*0x104f88e36*/
          AssemblyPrimitive = (RBX::Primitive *)RBX::Assembly::getAssemblyPrimitive(this: v5); /*0x104f88e45*/
          ConstRootMovingPrimitive = RBX::Primitive::getConstRootMovingPrimitive(this: AssemblyPrimitive, a2: v7); /*0x104f88e50*/
          v23 = v25; /*0x104f88e5a*/
          v24 = 0x4000000000LL; /*0x104f88e68*/
          RBX::SmallVectorTemplateBase<RBX::Primitive *,true>::push_back( /*0x104f88e76*/
            a1: (__int64)&v23,
            a2: (__int64)AssemblyPrimitive);
          v10 = v24; /*0x104f88e82*/
          do /*0x104f88f56*/
          {
            if ( ((unsigned __int64)v10 - 1) >> 32 != 0 ) /*0x104f88e93*/
              RBXCRASH(a1: 0, a2: ""); /*0x104f88f9f*/
            v11 = *((_QWORD *)v23 + v10 - 1); /*0x104f88ea0*/
            LODWORD(v24) = v10 - 1; /*0x104f88ea5*/
            if ( FFlag::StreamingSkipLocalOnlyNOUs == 1 ) /*0x104f88eb5*/
            {
              v12 = RBX::BasePart::fromPrimitive(this: (RBX::BasePart *)v11, a2: v9); /*0x104f88eba*/
              if ( v12 != 0 ) /*0x104f88ec2*/
              {
                v13 = FFlag::StreamingSkipLocalOnlyNOUs; /*0x104f88ecb*/
                if ( (RBX::Workspace::visitFixedNOUComponents(RBX::BasePart *,std::function<bool ()(RBX::Workspace::FixedNOUComponent &&)> const&)::$_0::operator()( /*0x104f88eea*/
                        a1: v22,
                        a2: v12,
                        a3: v11)
                    & 1
                    | ((v13 & 1) == 0)) == 0 )
                  break; /*0x104f88eea*/
              }
            }
            else
            {
              v14 = RBX::BasePart::fromPrimitive(this: (RBX::BasePart *)v11, a2: v9); /*0x104f88ef1*/
              if ( v14 != 0 ) /*0x104f88ef9*/
                RBX::Workspace::visitFixedNOUComponents(RBX::BasePart *,std::function<bool ()(RBX::Workspace::FixedNOUComponent &&)> const&)::$_0::operator()( /*0x104f88f08*/
                  a1: v22,
                  a2: v14,
                  a3: v11);
            }
            v15 = *(int *)(v11 + 40); /*0x104f88f0d*/
            if ( v15 > 0 ) /*0x104f88f15*/
            {
              v16 = v15 + 1; /*0x104f88f17*/
              do /*0x104f88f4c*/
              {
                v17 = *(_QWORD *)(*(_QWORD *)(v11 + 32) + 8 * v16 - 16); /*0x104f88f1f*/
                if ( v17 != 0 ) /*0x104f88f27*/
                {
                  v18 = (RBX::Primitive *)(v17 - 16); /*0x104f88f29*/
                  if ( RBX::Primitive::getConstRootMovingPrimitive(this: v18, a2: v9) == ConstRootMovingPrimitive ) /*0x104f88f38*/
                    RBX::SmallVectorTemplateBase<RBX::Primitive *,true>::push_back(a1: (__int64)&v23, a2: (__int64)v18); /*0x104f88f40*/
                }
                v19 = v16-- == 1; /*0x104f88f48*/
              }
              while ( !v19 && v16 != 1 ); /*0x104f88f4c*/
            }
            v10 = v24; /*0x104f88f4e*/
          }
          while ( (_DWORD)v24 != 0 ); /*0x104f88f56*/
          if ( v23 != v25 ) /*0x104f88f6d*/
            operator delete(a1: v23); /*0x104f88f6f*/
        }
      }
    }
  }
  return __stack_chk_guard; /*0x104f88f84*/
}

// Address: 0x104f88fda | Name: __ZNK3RBX9Workspace22visitWorkspaceNOURootsERKNSt3__18functionIFvPNS_8BasePartEbEEE
char __fastcall RBX::Workspace::visitWorkspaceNOURoots(__int64 a1, const RBX::Primitive *a2)
{
  __int64 Assembly; // rax
  RBX::Assembly **v3; // r13
  RBX::Assembly **v4; // rbx
  RBX::Primitive *v5; // r14
  RBX::Assembly *v6; // r15
  __int64 v7; // r14
  const RBX::Assembly *v8; // rsi
  bool IsGrounded; // r12

  Assembly = *(_QWORD *)(a1 + 944); /*0x104f88fec*/
  v3 = *(RBX::Assembly ***)(Assembly + 616); /*0x104f88ff3*/
  v4 = *(RBX::Assembly ***)(Assembly + 624); /*0x104f88ffa*/
  while ( v3 != v4 ) /*0x104f89004*/
  {
    v5 = *v3; /*0x104f89006*/
    LOBYTE(Assembly) = RBX::Assembly::isAssemblyRootPrimitive(this: *v3, a2); /*0x104f8900d*/
    if ( (_BYTE)Assembly != 0 ) /*0x104f89014*/
    {
      Assembly = RBX::Primitive::getAssembly(this: v5, a2); /*0x104f89019*/
      if ( Assembly != 0 ) /*0x104f89021*/
      {
        v6 = (RBX::Assembly *)Assembly; /*0x104f89023*/
        Assembly = RBX::BasePart::fromPrimitive(this: v5, a2); /*0x104f89029*/
        if ( Assembly != 0 ) /*0x104f89031*/
        {
          v7 = Assembly; /*0x104f89033*/
          IsGrounded = RBX::Assembly::computeIsGrounded(this: v6); /*0x104f8903e*/
          if ( IsGrounded /*0x104f8904f*/
            || (LOBYTE(Assembly) = RBX::Mechanism::isMovingAssemblyRoot(this: v6, a2: v8), (_BYTE)Assembly != 0) )
          {
            LOBYTE(Assembly) = std::function<void ()(RBX::BasePart *,bool)>::operator()(a1: a2, a2: v7, a3: IsGrounded); /*0x104f8905c*/
          }
        }
      }
    }
    ++v3; /*0x104f89061*/
  }
  return Assembly; /*0x104f8906b*/
}

// Address: 0x104f890a8 | Name: __ZN3RBX9Workspace41requestAssembleWorldFromOutOfFrameChangesEv
void __fastcall RBX::Workspace::requestAssembleWorldFromOutOfFrameChanges(RBX::Workspace *this)
{
  RBX::World *v2; // rdi
  const RBX::Instance *v3; // rsi
  bool v4; // al
  RBX::Instance *v5; // rsi
  __int64 v6; // rax
  RBX::ContactManager *v7; // rbx
  _BYTE v8[48]; // [rsp+0h] [rbp-30h] BYREF

  v2 = *((RBX::World **)this + 118); /*0x104f890b4*/
  if ( v2 != nullptr && RBX::World::isAssembled(this: v2) == 0 ) /*0x104f890c7*/
  {
    v4 = RBX::DataModel::currentThreadHasWriteLock(this, a2: v3); /*0x104f890cc*/
    v5 = nullptr; /*0x104f890d1*/
    if ( !v4 ) /*0x104f890d5*/
      v5 = this; /*0x104f890d5*/
    RBX::DataModel::scoped_write_request::scoped_write_request(this: (RBX::DataModel::scoped_write_request *)v8, a2: v5); /*0x104f890dd*/
    v6 = *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */; /*0x104f890e2*/
    v7 = *(RBX::ContactManager **)(v6 + 2056); /*0x104f890e9*/
    if ( v7 != nullptr ) /*0x104f890f3*/
    {
      RBX::ContactManager::forceUpdateBroadPhaseIfDirty(this: *(RBX::World ***)(v6 + 2056)); /*0x104f890f8*/
      RBX::ContactManager::forceUpdateMidPhaseIfDirty(this: v7); /*0x104f89100*/
    }
    RBX::DataModel::scoped_write_request::~scoped_write_request(this: (RBX::DataModel::scoped_write_request *)v8); /*0x104f89109*/
  }
}

// Address: 0x104f8912a | Name: __ZNK3RBX9Workspace31isImprovedModelStreamingEnabledEv
char __fastcall RBX::Workspace::isImprovedModelStreamingEnabled(RBX::Workspace *this, const RBX::Instance *a2)
{
  RBX::DataModel *v3; // rax
  const RBX::Instance *v4; // rsi

  if ( SFFlag::StudioOpenWithStreaming == 1 /*0x104f8914f*/
    && (v3 = RBX::DataModel::get(this, a2)) != nullptr
    && RBX::DataModel::isStudioStreamingEnabled(this: v3, a2: v4) )
  {
    return FFlag::StudioStreamingDisablesImprovedModel ^ 1; /*0x104f8915e*/
  }
  else
  {
    return *((_DWORD *)this + 301) /* +1204: NO 2022 FIELD */ == 2; /*0x104f89169*/
  }
}

// Address: 0x104f89174 | Name: __ZNK3RBX9Workspace15isLayersEnabledEv
__int64 __fastcall RBX::Workspace::isLayersEnabled(std::__shared_weak_count **this)
{
  RBX::Workspace *v1; // r14
  std::__shared_weak_count *v2; // rdi
  volatile signed __int64 *v3; // rax
  volatile signed __int64 *v4; // rbx
  __int64 v5; // rax

  v1 = (RBX::Workspace *)this; /*0x104f8917b*/
  v2 = *(this + 420); /*0x104f8917e*/
  if ( v2 != nullptr && (v3 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v2)) != nullptr ) /*0x104f89192*/
  {
    v4 = v3; /*0x104f89194*/
    v5 = *((_QWORD *)v1 + 419); /*0x104f89197*/
  }
  else
  {
    v5 = 0; /*0x104f891a0*/
    v4 = nullptr; /*0x104f891a2*/
  }
  if ( FFlag::DebugTagRuleArmed == 1 /*0x104f891da*/
    && FFlag::TagRuleCoreEnabled == 1
    && FFlag::TagRulePhysicsScopeEnabled == 1
    && ((unsigned __int8)FFlag::TagRuleReplicationPipelineEnabled & (v5 != 0)) == 1 )
  {
    LOBYTE(v1) = *(_DWORD *)(v5 + 2264) != 1; /*0x104f891e3*/
  }
  else
  {
    LODWORD(v1) = 0; /*0x104f891e9*/
  }
  if ( v4 != nullptr && _InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f89201*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(a1: v4); /*0x104f89209*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v4); /*0x104f8920f*/
  }
  return (unsigned int)v1; /*0x104f89217*/
}

// Address: 0x104f8921c | Name: __ZNK3RBX9Workspace34getStreamOutBehaviorStudioOverrideEv
__int64 __fastcall RBX::Workspace::getStreamOutBehaviorStudioOverride(RBX::Workspace *this, const RBX::Instance *a2)
{
  RBX::DataModel *v3; // rax
  const RBX::Instance *v4; // rsi
  bool isStudioStreamingEnabled; // cl
  __int64 result; // rax

  if ( SFFlag::StudioOpenWithStreaming != 1 ) /*0x104f8922f*/
    return *((unsigned int *)this + 315); /*0x104f8922f*/
  v3 = RBX::DataModel::get(this, a2); /*0x104f89234*/
  if ( v3 == nullptr ) /*0x104f8923c*/
    return *((unsigned int *)this + 315); /*0x104f8923c*/
  isStudioStreamingEnabled = RBX::DataModel::isStudioStreamingEnabled(this: v3, a2: v4); /*0x104f89246*/
  result = 2; /*0x104f89248*/
  if ( !isStudioStreamingEnabled ) /*0x104f8924f*/
    return *((unsigned int *)this + 315); /*0x104f89251*/
  return result; /*0x104f8925b*/
}

// Address: 0x104f8925e | Name: __ZN3RBX9Workspace40debugSetEngineNetConfigurationForTestingERKNS_22EngineNetConfigurationE
__int64 __fastcall RBX::Workspace::debugSetEngineNetConfigurationForTesting(__int64 a1, __int64 *a2)
{
  __int64 result; // rax

  result = *a2; /*0x104f89262*/
  *(_QWORD *)(a1 + 3256) = *a2; /*0x104f89265*/
  return result; /*0x104f8926c*/
}

// Address: 0x104f8926e | Name: __ZNK3RBX9Workspace33getEngineNetConfigurationFromPropEv
RBX::Workspace *__fastcall RBX::Workspace::getEngineNetConfigurationFromProp(RBX::Workspace *this, __int64 a2)
{
  RBX::Workspace *v3; // rbx
  bool v4; // al
  __int64 v5; // rsi
  __int64 v6; // r15
  const RBX::Instance *v7; // rsi
  RBX::DataModel *v8; // rax
  RBX::DataModel *v9; // rax

  v3 = this; /*0x104f8927c*/
  if ( FFlag::DebugUseEngineNetConfigurationTest == 1 ) /*0x104f89286*/
  {
    this->... /* +0 */= *(_QWORD *)(a2 + 3256); /*0x104f8928f*/
  }
  else
  {
    if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x104f892a3*/
    {
      if ( DFFlag::NextGenReplicatorEnabledWriteServerSynchronized == 1 ) /*0x104f892af*/
      {
        v4 = true; /*0x104f892b1*/
        if ( DFFlag::RespectImprovedPhysicsReplicationDisabledConfig == 1 ) /*0x104f892ba*/
          v4 = *(_DWORD *)(a2 + 1180) != 1; /*0x104f892c4*/
      }
      else
      {
        v4 = DFFlag::UseImprovedPhysicsReplicationConfig == 1 && *(_DWORD *)(a2 + 1180) == 2; /*0x104f892e4*/
      }
      v6 = v4; /*0x104f892eb*/
      if ( (unsigned __int8)RBX::Workspace::isNextGenerationReplicationEnabledProp(this: (RBX::Workspace *)a2) != 0 /*0x104f89318*/
        && (FFlag::NextGenReplicationDisableInCloudEdit != 1
         || (v8 = RBX::DataModel::get(this: (RBX::DataModel *)a2, a2: v7)) == nullptr
         || *((_DWORD *)v8 + 566) != 1) )
      {
        v6 = 7; /*0x104f8931a*/
      }
      if ( FFlag::SAuthWorkspacePropertyEnabled == 1 /*0x104f89357*/
        && FFlag::SAuthWorkspaceFlagged == 1
        && *(_DWORD *)(a2 + 1148) != 1
        && (FFlag::ServerAuthorityDisableInCloudEdit != 1
         || (v9 = RBX::DataModel::get(this: (RBX::DataModel *)a2, a2: v7)) == nullptr
         || *((_DWORD *)v9 + 566) != 1) )
      {
        v6 |= 8uLL; /*0x104f89359*/
      }
      this = v3; /*0x104f8935d*/
      v5 = v6; /*0x104f89360*/
    }
    else
    {
      v5 = 0; /*0x104f892cc*/
    }
    RBX::EngineNetConfiguration::EngineNetConfiguration(a1: this, a2: v5); /*0x104f89363*/
  }
  return v3; /*0x104f8936b*/
}

// Address: 0x104f89374 | Name: __ZNK3RBX9Workspace38isNextGenerationReplicationEnabledPropEv
bool __fastcall RBX::Workspace::isNextGenerationReplicationEnabledProp(RBX::Workspace *this)
{
  bool result; // al

  if ( FFlag::NextGenReplicationThreePhaseRolloutProperty == 0 && FFlag::SAuthWorkspacePropertyEnabled != 1 /*0x104f89390*/
    || FFlag::SAuthWorkspaceFlagged != 1 )
  {
    return false; /*0x104f893be*/
  }
  if ( FFlag::SAuthWorkspacePropertyEnabled != 1 ) /*0x104f89399*/
    return (unsigned int)RBX::WorkspaceProp::getNextGenerationReplication(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)) == 2; /*0x104f89399*/
  result = true; /*0x104f8939b*/
  if ( *((_DWORD *)this + 287) /* +1148: NO 2022 FIELD */ == 1 ) /*0x104f893a4*/
    return (unsigned int)RBX::WorkspaceProp::getNextGenerationReplication(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)) == 2; /*0x104f893b9*/
  return result; /*0x104f893bd*/
}

// Address: 0x104f893c2 | Name: __ZN3RBX9Workspace25setEngineNetConfigurationERKNS_22EngineNetConfigurationE
void __fastcall RBX::Workspace::setEngineNetConfiguration(RBX::ServiceProvider *this, char *a2)
{
  __int64 v4; // rax
  RBX::Instance *v5; // rsi
  volatile signed __int64 *v6; // r14
  RBX::DataModel *v7; // rax
  __int64 v8; // r14
  RBX::ServiceProvider *ServiceProvider; // rax
  unsigned int v10; // esi
  rbx::signals::slots_holder **v11; // r15
  unsigned int v12; // r14d
  unsigned __int64 v13; // rsi
  volatile signed __int32 *v14; // r12
  rbx::signals::slots_holder *v15; // rax
  unsigned __int64 v16; // rax
  volatile signed __int64 *v17; // r14
  RBX::DataModel *v18; // rax
  __int64 v19; // r14
  unsigned int v20; // esi
  void *v21; // rdi
  rbx::signals::slots_holder *v22; // rdi
  __int128 v23; // [rsp+0h] [rbp-90h] BYREF
  __int128 v24; // [rsp+10h] [rbp-80h] BYREF
  _BYTE v25[16]; // [rsp+28h] [rbp-68h] BYREF
  void *v26; // [rsp+38h] [rbp-58h]
  _BYTE v27[16]; // [rsp+40h] [rbp-50h] BYREF
  void *v28; // [rsp+50h] [rbp-40h]
  void *v29[2]; // [rsp+58h] [rbp-38h] BYREF
  void *v30; // [rsp+68h] [rbp-28h]

  RBX::World::setEngineNetConfiguration(a1: *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */, a2); /*0x104f893de*/
  if ( DFFlag::WorkspaceFlaggabilityCASFix == 1 ) /*0x104f893ed*/
  {
    v4 = RBX::ServiceProvider::find<RBX::ContextActionService>(a1: this); /*0x104f893f2*/
    if ( v4 != 0 ) /*0x104f893fa*/
      RBX::ContextActionService::configureUsingNetConfiguration(a1: v4, a2); /*0x104f89402*/
  }
  if ( DFFlag::AlwaysFireEngineNetConfigSetSignal == 1 ) /*0x104f8940e*/
    rbx::signal<void ()(RBX::EngineNetConfiguration const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x104f8941a*/
      a1: (char *)this + 1552 /* +1552 = fallenParts (std::vector<std::shared_ptr<RBX::BasePart>>, 24B) -- SIZE CONFLICT, see --verify */,
      a2);
  RBX::World::getEngineNetConfiguration(this: (RBX::World *)v29, a2: *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */); /*0x104f8942a*/
  if ( FFlag::DebugHashTableMetrics == 1 || FFlag::SAuthWorkspaceFlagged != 0 && ((__int64)v29[0] & 8) != 0 ) /*0x104f895c0*/
  {
    if ( DFFlag::AlwaysFireEngineNetConfigSetSignal == 0 ) /*0x104f89446*/
      rbx::signal<void ()(RBX::EngineNetConfiguration const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x104f89452*/
        a1: (char *)this + 1552 /* +1552 = fallenParts (std::vector<std::shared_ptr<RBX::BasePart>>, 24B) -- SIZE CONFLICT, see --verify */,
        a2);
    if ( DFFlag::SessionTrackingServerAuthorityMode == 1 ) /*0x104f8945e*/
    {
      v6 = (volatile signed __int64 *)unk_10D512940; /*0x104f89467*/
      v23 = RBX::ClientSessionTrackerKeys::ServerAuthorityMode; /*0x104f8946e*/
      if ( unk_10D512940 != 0 ) /*0x104f89478*/
        _InterlockedIncrement64((volatile signed __int64 *)(unk_10D512940 + 8LL)); /*0x104f8947a*/
      std::string::basic_string[abi:ne200100]<0>(a1: v25, a2: "Server"); /*0x104f8948a*/
      RBX::updateClientSessionMetric<std::string,false>(a1: &v23, a2: v25); /*0x104f8949a*/
      if ( (v25[0] & 1) != 0 ) /*0x104f894a3*/
        operator delete(a1: v26); /*0x104f894a9*/
      if ( v6 != nullptr && _InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f894c3*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(a1: v6); /*0x104f894cb*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v6); /*0x104f894d1*/
      }
    }
    if ( DFFlag::ReplicatorTelemetryServerAuthorityMode == 1 ) /*0x104f894e0*/
    {
      v7 = RBX::DataModel::get(this, a2: v5); /*0x104f894e5*/
      if ( v7 != nullptr ) /*0x104f894ed*/
      {
        v8 = (__int64)v7; /*0x104f894ef*/
        std::string::basic_string[abi:ne200100]<0>(a1: v29, a2: "Server"); /*0x104f89500*/
        RBX::DataModel::setContextAttribute(a1: v8, a2: 18, a3: (__int64)v29); /*0x104f89510*/
        if ( ((__int64)v29[0] & 1) != 0 ) /*0x104f89519*/
          operator delete(a1: v30); /*0x104f8951f*/
      }
    }
    ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2: v5); /*0x104f89527*/
    if ( ServiceProvider != nullptr ) /*0x104f8952f*/
      RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::AuroraService>(this: ServiceProvider); /*0x104f89534*/
    v11 = (rbx::signals::slots_holder **)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 96LL); /*0x104f89540*/
    v12 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v10); /*0x104f89552*/
    rbx::lazyInitSlotsHolder(a1: v11); /*0x104f89558*/
    v14 = (volatile signed __int32 *)rbx::signals::slot_base::operator new( /*0x104f89567*/
                                       this: (rbx::signals::slot_base *)0x30,
                                       a2: v13);
    *(_QWORD *)v14 = &_mh_execute_header; /*0x104f89574*/
    *((_QWORD *)v14 + 1) = rbx::signals::slot_with_functor<RBX::Workspace::setEngineNetConfiguration(RBX::EngineNetConfiguration const&)::$_0>::do_call; /*0x104f8957f*/
    *((_OWORD *)v14 + 1) = 0; /*0x104f89587*/
    v15 = *v11; /*0x104f8958d*/
    *((_QWORD *)v14 + 4) = *v11; /*0x104f89590*/
    if ( v15 != nullptr ) /*0x104f89598*/
    {
      _InterlockedIncrement((volatile signed __int32 *)v15 + 1); /*0x104f8959e*/
      v16 = *((_QWORD *)v14 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x104f895a7*/
    }
    else
    {
      v16 = 0; /*0x104f89697*/
    }
    *((_QWORD *)v14 + 3) = v16; /*0x104f89699*/
    *((_QWORD *)v14 + 5) = this; /*0x104f8969e*/
    rbx::signals::slots_holder::insert(this: *v11, a2: (unsigned __int64)v14); /*0x104f896a9*/
    v29[0] = (void *)v14; /*0x104f896ae*/
    _InterlockedIncrement(v14 + 1); /*0x104f896b2*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v12, a2: v20); /*0x104f896bb*/
    rbx::signals::scoped_connection::operator=(this: (RBX::ServiceProvider *)((char *)this + 1752 /* +1752 = statsJoinAllTime (long double, 8B) -- SIZE CONFLICT, see --verify */)); /*0x104f896cb*/
    v21 = v29[0]; /*0x104f896d0*/
    if ( v29[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v29[0] + 1) == 0 ) /*0x104f896dd*/
      rbx::signals::slot_base::operator delete(a1: v21); /*0x104f896df*/
    *(_BYTE *)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 553LL) = 1; /*0x104f896eb*/
  }
  else
  {
    if ( DFFlag::SessionTrackingServerAuthorityMode == 1 ) /*0x104f895cd*/
    {
      v17 = (volatile signed __int64 *)unk_10D512940; /*0x104f895d6*/
      v24 = RBX::ClientSessionTrackerKeys::ServerAuthorityMode; /*0x104f895dd*/
      if ( unk_10D512940 != 0 ) /*0x104f895e4*/
        _InterlockedIncrement64((volatile signed __int64 *)(unk_10D512940 + 8LL)); /*0x104f895e6*/
      std::string::basic_string[abi:ne200100]<0>(a1: v27, a2: "Automatic"); /*0x104f895f6*/
      RBX::updateClientSessionMetric<std::string,false>(a1: &v24, a2: v27); /*0x104f89603*/
      if ( (v27[0] & 1) != 0 ) /*0x104f8960c*/
        operator delete(a1: v28); /*0x104f89612*/
      if ( v17 != nullptr && _InterlockedExchangeAdd64(v17 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8962c*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v17 + 16))(a1: v17); /*0x104f89634*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v17); /*0x104f8963a*/
      }
    }
    if ( DFFlag::ReplicatorTelemetryServerAuthorityMode == 1 ) /*0x104f89649*/
    {
      v18 = RBX::DataModel::get(this, a2: v5); /*0x104f89652*/
      if ( v18 != nullptr ) /*0x104f8965a*/
      {
        v19 = (__int64)v18; /*0x104f89660*/
        std::string::basic_string[abi:ne200100]<0>(a1: v29, a2: "Automatic"); /*0x104f89671*/
        RBX::DataModel::setContextAttribute(a1: v19, a2: 18, a3: (__int64)v29); /*0x104f89681*/
        if ( ((__int64)v29[0] & 1) != 0 ) /*0x104f8968a*/
          operator delete(a1: v30); /*0x104f89690*/
      }
    }
  }
  v22 = *((rbx::signals::slots_holder **)this + 194); /*0x104f896f2*/
  if ( v22 != nullptr ) /*0x104f896fc*/
    rbx::signals::slots_holder::disconnectAll(this: v22); /*0x104f896fe*/
}

// Address: 0x104f89862 | Name: __ZNK3RBX9Workspace17getSimulationTimeEv
float __fastcall RBX::Workspace::getSimulationTime(RBX::Workspace *this)
{
  __int64 v1; // r14
  const RBX::Instance *v3; // rsi
  RBX::ServiceProvider *ServiceProvider; // rax
  RBX::AuroraService *v5; // rdi
  int CurrentSimulationStepId; // eax
  float v8; // xmm0_4
  __int64 v9; // [rsp+0h] [rbp-30h] BYREF
  int v10; // [rsp+8h] [rbp-28h]
  _BYTE v11[12]; // [rsp+10h] [rbp-20h] BYREF
  float v12; // [rsp+1Ch] [rbp-14h]

  v1 = *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */; /*0x104f8986d*/
  if ( v1 == 0 ) /*0x104f89877*/
    return 0.0; /*0x104f898c3*/
  v10 = *(_DWORD *)(v1 + 1700); /*0x104f89883*/
  v9 = *(_QWORD *)(v1 + 1692); /*0x104f8988d*/
  RBX::World::getEngineNetConfiguration(this: (RBX::World *)v11, a2: v1); /*0x104f89898*/
  if ( FFlag::DebugHashTableMetrics == 1 || FFlag::SAuthWorkspaceFlagged != 0 && (v11[0] & 8) != 0 ) /*0x104f898d8*/
  {
    ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2: v3); /*0x104f898ac*/
    if ( ServiceProvider != nullptr ) /*0x104f898b4*/
      v5 = (RBX::AuroraService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::AuroraService>(this: ServiceProvider); /*0x104f898be*/
    else
      v5 = nullptr; /*0x104f898e3*/
    CurrentSimulationStepId = RBX::AuroraService::getCurrentSimulationStepId(this: v5); /*0x104f898e5*/
  }
  else
  {
    CurrentSimulationStepId = *(_DWORD *)(v1 + 232); /*0x104f898da*/
  }
  v12 = (float)CurrentSimulationStepId; /*0x104f898ee*/
  RBX::SteppingParameters::worldStepDt(this: (RBX::SteppingParameters *)&v9); /*0x104f898f7*/
  return v8 * v12; /*0x104f89901*/
}

// Address: 0x104f8990a | Name: __ZNK3RBX9Workspace23getModifiedNOUInstancesEPNS_8BasePartERNS_23NOUChangedInstanceTypesE
__int64 __fastcall RBX::Workspace::getModifiedNOUInstances(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v4; // r14
  __int64 v5; // rax
  __int64 v6; // r15
  __int64 v7; // rax

  v4 = *(_QWORD *)(a1 + 944); /*0x104f89917*/
  if ( v4 != 0 ) /*0x104f89921*/
  {
    v5 = std::__hash_table<std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::__unordered_map_hasher<RBX::Primitive *,std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>,true>,std::__unordered_map_equal<RBX::Primitive *,std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::equal_to<RBX::Primitive *>,std::hash<RBX::Primitive *>,true>,std::allocator<std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>>>::find<RBX::Primitive *>(a1: v4 + 672); /*0x104f89941*/
    if ( v5 != 0 ) /*0x104f89949*/
    {
      v6 = v5; /*0x104f8994b*/
      *a3 = 1; /*0x104f8994e*/
      if ( std::__hash_table<std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::__unordered_map_hasher<RBX::Primitive *,std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>,true>,std::__unordered_map_equal<RBX::Primitive *,std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::equal_to<RBX::Primitive *>,std::hash<RBX::Primitive *>,true>,std::allocator<std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>>>::find<RBX::Primitive *>(a1: v4 + 712) != 0 ) /*0x104f89967*/
        *a3 = 3; /*0x104f89969*/
      return v6 + 24; /*0x104f8996c*/
    }
    v7 = std::__hash_table<std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::__unordered_map_hasher<RBX::Primitive *,std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>,true>,std::__unordered_map_equal<RBX::Primitive *,std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::equal_to<RBX::Primitive *>,std::hash<RBX::Primitive *>,true>,std::allocator<std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>>>::find<RBX::Primitive *>(a1: v4 + 712); /*0x104f8997c*/
    if ( v7 != 0 ) /*0x104f89984*/
    {
      v6 = v7; /*0x104f89986*/
      *a3 = 2; /*0x104f89989*/
      return v6 + 24; /*0x104f8999f*/
    }
  }
  *a3 = 0; /*0x104f89992*/
  return 0; /*0x104f89995*/
}

// Address: 0x104f899a6 | Name: __ZNK3RBX9Workspace27getModifiedNOUSkippedJointsEPNS_8BasePartE
__int64 __fastcall RBX::Workspace::getModifiedNOUSkippedJoints(RBX::Workspace *this, RBX::BasePart *a2)
{
  __int64 v2; // rdi
  __int64 v3; // rax

  v2 = *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */; /*0x104f899a6*/
  if ( v2 != 0 /*0x104f899e6*/
    && (v3 = std::__hash_table<std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::__unordered_map_hasher<RBX::Primitive *,std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>,true>,std::__unordered_map_equal<RBX::Primitive *,std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>,std::equal_to<RBX::Primitive *>,std::hash<RBX::Primitive *>,true>,std::allocator<std::__hash_value_type<RBX::Primitive *,RBX::DenseHashSet<RBX::Guid,RBX::Hash<RBX::Guid>,std::equal_to<RBX::Guid>>>>>::find<RBX::Primitive *>(a1: v2 + 712)) != 0 )
  {
    return v3 + 24; /*0x104f899e8*/
  }
  else
  {
    return 0; /*0x104f899ed*/
  }
}

// Address: 0x104f899f0 | Name: __ZNK3RBX9Workspace24getWorkspacePartFromGuidERKNS_4GuidE
__int64 __fastcall RBX::Workspace::getWorkspacePartFromGuid(RBX::World **this, const RBX::Guid *a2)
{
  RBX::BasePart *PrimitiveFromGuid; // rax
  RBX::Primitive *v3; // rsi

  PrimitiveFromGuid = (RBX::BasePart *)RBX::World::getPrimitiveFromGuid(this: *(this + 118), a2); /*0x104f899fb*/
  return RBX::BasePart::fromPrimitive(this: PrimitiveFromGuid, a2: v3); /*0x104f89a03*/
}

// Address: 0x104f89a0a | Name: __ZNK3RBX9Workspace21getJointPartsFromGuidERKNS_4GuidERPNS_8BasePartES6_
RBX::BasePart **__fastcall RBX::Workspace::getJointPartsFromGuid(
        RBX::World **this,
        const RBX::Guid *a2,
        RBX::BasePart **a3,
        RBX::BasePart ***a4)
{
  RBX::BasePart **result; // rax
  RBX::Primitive *v7; // rsi
  RBX::BasePart **v8; // r15
  RBX::Primitive *v9; // rsi

  result = (RBX::BasePart **)RBX::World::getJointFromGuid(this: *(this + 118), a2); /*0x104f89a21*/
  if ( result != nullptr ) /*0x104f89a29*/
  {
    v8 = result; /*0x104f89a2b*/
    *a3 = (RBX::BasePart *)RBX::BasePart::fromPrimitive(this: result[19], a2: v7); /*0x104f89a3a*/
    result = (RBX::BasePart **)RBX::BasePart::fromPrimitive(this: v8[20], a2: v9); /*0x104f89a44*/
    *a4 = result; /*0x104f89a49*/
  }
  return result; /*0x104f89a50*/
}

// Address: 0x104f89a58 | Name: __ZNK3RBX9Workspace39getBasePartIsPartOfNetworkOwnershipUnitEPNS_8BasePartES2_
bool __fastcall RBX::Workspace::getBasePartIsPartOfNetworkOwnershipUnit(
        RBX::Workspace *this,
        RBX::Primitive **a2,
        RBX::BasePart *a3)
{
  return RBX::Primitive::getConstRootMovingPrimitive(this: a2[47], (const RBX::Primitive *)a2) == *((_QWORD *)a3 + 47); /*0x104f89a7b*/
}

// Address: 0x104f89a7e | Name: __ZN3RBX9Workspace22setDefaultMouseCommandEv
void __fastcall RBX::Workspace::setDefaultMouseCommand(RBX::IPluginLegacyApi **this)
{
  std::__shared_weak_count *v2; // rbx
  _BYTE v3[16]; // [rsp+10h] [rbp-50h] BYREF
  __int128 v4; // [rsp+20h] [rbp-40h] BYREF
  void *v5[6]; // [rsp+30h] [rbp-30h] BYREF

  if ( (unsigned __int8)FLog::ChangeMouseCommand >= 6u && (FLog::ChangeMouseCommand & 0xFC00) != 0 ) /*0x104f89aa2*/
  {
    v5[0] = nullptr; /*0x104f89ab0*/
    v5[1] = v3; /*0x104f89abc*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x104f89ae0*/
      a1: FLog::ChangeMouseCommand,
      a2: qword_10D7E4810,
      a3: 4,
      a4: (unsigned int)"[FLog::ChangeMouseCommand] Setting mouse command to Default",
      a5: 59,
      a6: 1,
      0,
      v3);
  }
  std::shared_ptr<RBX::MouseCommand>::reset[abi:ne200100](a1: this + 259); /*0x104f89aec*/
  std::string::basic_string[abi:ne200100]<0>(a1: v5, a2: ""); /*0x104f89b06*/
  rbx::signal<void ()(std::string const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: this + 412, a2: v5); /*0x104f89b11*/
  if ( ((__int64)v5[0] & 1) != 0 ) /*0x104f89b1a*/
    operator delete(a1: v5[2]); /*0x104f89b20*/
  v4 = 0; /*0x104f89b2c*/
  RBX::Workspace::setMouseCommand(this, a2: (const RBX::Instance *)&v4, a3: 0); /*0x104f89b34*/
  v2 = *((std::__shared_weak_count **)&v4 + 1); /*0x104f89b39*/
  if ( *((_QWORD *)&v4 + 1) != 0 /*0x104f89b52*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v4 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v2 + 16LL))(a1: v2); /*0x104f89b5a*/
    std::__shared_weak_count::__release_weak(this: v2); /*0x104f89b60*/
  }
}

// Address: 0x104f89c00 | Name: __ZN3RBX9Workspace19setNullMouseCommandEv
__int64 __fastcall RBX::Workspace::setNullMouseCommand(RBX::Workspace *this)
{
  std::__shared_weak_count *v2; // r14
  __int64 v3; // rdi
  __int64 v4; // rax
  __int64 v5; // rdi
  std::__shared_weak_count *v6; // r15
  __int64 result; // rax
  std::__shared_weak_count *v8; // rbx
  std::__shared_weak_count *v9[2]; // [rsp+20h] [rbp-50h] BYREF
  std::__shared_weak_count *v10[2]; // [rsp+30h] [rbp-40h] BYREF
  std::__shared_weak_count *v11[2]; // [rsp+40h] [rbp-30h] BYREF
  void *v12; // [rsp+50h] [rbp-20h]

  if ( (unsigned __int8)FLog::ChangeMouseCommand >= 6u && (FLog::ChangeMouseCommand & 0xFC00) != 0 ) /*0x104f89c24*/
  {
    v11[0] = nullptr; /*0x104f89c32*/
    v11[1] = (std::__shared_weak_count *)v10; /*0x104f89c3e*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x104f89c62*/
      a1: FLog::ChangeMouseCommand,
      a2: qword_10D7E4810,
      a3: 4,
      a4: (unsigned int)"[FLog::ChangeMouseCommand] Setting mouse command to NullTool",
      a5: 60,
      a6: 1,
      0,
      v10);
  }
  std::shared_ptr<RBX::MouseCommand>::reset[abi:ne200100](a1: (char *)this + 2072 /* +2072: NO 2022 FIELD */); /*0x104f89c6e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v11, a2: ""); /*0x104f89c88*/
  rbx::signal<void ()(std::string const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (char *)this + 3296 /* +3296: NO 2022 FIELD */, a2: v11); /*0x104f89c93*/
  if ( ((__int64)v11[0] & 1) != 0 ) /*0x104f89c9c*/
    operator delete(a1: v12); /*0x104f89ca2*/
  RBX::Creatable::createImpl<RBX::NewNullTool,RBX::Workspace *&>(a1: v11); /*0x104f89cb5*/
  *(_OWORD *)v10 = *(_OWORD *)v11; /*0x104f89cc2*/
  if ( v11[1] != nullptr ) /*0x104f89cc9*/
  {
    _InterlockedIncrement64((volatile signed __int64 *)v11[1] + 1); /*0x104f89ccb*/
    v2 = v11[1]; /*0x104f89cd0*/
    if ( v11[1] != nullptr /*0x104f89ce9*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v11[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v2 + 16LL))(a1: v2); /*0x104f89cf1*/
      std::__shared_weak_count::__release_weak(this: v2); /*0x104f89cf7*/
    }
  }
  v3 = *((_QWORD *)this + 257) /* +2056: NO 2022 FIELD */; /*0x104f89d03*/
  if ( v3 != 0 ) /*0x104f89d0d*/
  {
    v4 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v3 + 240LL))(a1: v3); /*0x104f89d16*/
    if ( (*(_BYTE *)v4 & 1) != 0 ) /*0x104f89d1f*/
    {
      std::string::__init_copy_ctor_external(a1: v11, a2: *(_QWORD *)(v4 + 16), a3: *(_QWORD *)(v4 + 8)); /*0x104f89d3e*/
    }
    else
    {
      v12 = *(void **)(v4 + 16); /*0x104f89d25*/
      *(_OWORD *)v11 = *(_OWORD *)v4; /*0x104f89d2c*/
    }
    v5 = *((_QWORD *)this + 257) /* +2056: NO 2022 FIELD */; /*0x104f89d43*/
    *(_OWORD *)v9 = *(_OWORD *)v10; /*0x104f89d4e*/
    if ( v10[1] != nullptr ) /*0x104f89d55*/
      _InterlockedIncrement64((volatile signed __int64 *)v10[1] + 1); /*0x104f89d57*/
    (*(void (__fastcall **)(__int64, std::__shared_weak_count **))(*(_QWORD *)v5 + 96LL))(a1: v5, a2: v9); /*0x104f89d63*/
    v6 = v9[1]; /*0x104f89d66*/
    if ( v9[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v9[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f89d7f*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x104f89d87*/
      std::__shared_weak_count::__release_weak(this: v6); /*0x104f89d8d*/
    }
    if ( ((__int64)v11[0] & 1) != 0 ) /*0x104f89d96*/
      operator delete(a1: v12); /*0x104f89d9c*/
  }
  std::shared_ptr<RBX::MouseCommand>::operator=[abi:ne200100](a1: (char *)this + 2056 /* +2056: NO 2022 FIELD */, a2: v10); /*0x104f89da8*/
  result = RBX::Workspace::updatePlayerMouseCommand(this); /*0x104f89db0*/
  v8 = v10[1]; /*0x104f89db5*/
  if ( v10[1] != nullptr ) /*0x104f89dbc*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v10[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x104f89dc5*/
    if ( result == 0 ) /*0x104f89dce*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x104f89dd6*/
      return std::__shared_weak_count::__release_weak(this: v8); /*0x104f89ddc*/
    }
  }
  return result; /*0x104f89de1*/
}

// Address: 0x104f89e86 | Name: __ZN3RBX9Workspace24updatePlayerMouseCommandEv
__int64 __fastcall RBX::Workspace::updatePlayerMouseCommand(RBX::Workspace *this, RBX::Instance *a2)
{
  __int64 result; // rax
  RBX::Mouse *v4; // rdi
  volatile signed __int64 *v5; // rbx

  result = RBX::Players::findLocalPlayer(this, a2); /*0x104f89e94*/
  if ( result != 0 ) /*0x104f89e9c*/
  {
    v4 = *(RBX::Mouse **)(result + 4304); /*0x104f89e9e*/
    v5 = *(volatile signed __int64 **)(result + 4312); /*0x104f89ea9*/
    if ( v5 != nullptr ) /*0x104f89eb7*/
      _InterlockedIncrement64(v5 + 1); /*0x104f89eb9*/
    if ( v4 != nullptr ) /*0x104f89ec1*/
      result = RBX::Mouse::setWorkspace(this: v4, a2: this); /*0x104f89ec6*/
    if ( v5 != nullptr ) /*0x104f89ece*/
    {
      result = _InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x104f89ed7*/
      if ( result == 0 ) /*0x104f89ee0*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(a1: v5); /*0x104f89ee8*/
        return std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v5); /*0x104f89eee*/
      }
    }
  }
  return result; /*0x104f89ef3*/
}

// Address: 0x104f89f10 | Name: __ZN3RBX9Workspace19isActivePluginAToolEPNS_9DataModelE
__int64 __fastcall RBX::Workspace::isActivePluginATool(RBX::Workspace *this, RBX::DataModel *a2)
{
  __int64 v3; // rax

  if ( this != nullptr && (v3 = RBX::IPluginLegacyApi::get(this)) != 0 ) /*0x104f89f26*/
    return (*(__int64 (__fastcall **)(__int64, RBX::Workspace *))(*(_QWORD *)v3 + 144LL))(a1: v3, a2: this); /*0x104f89f3e*/
  else
    return 0; /*0x104f89f40*/
}

// Address: 0x104f89f4a | Name: __ZN3RBX9Workspace39isActivePluginOverridingUIDragDetectorsEPNS_9DataModelE
__int64 __fastcall RBX::Workspace::isActivePluginOverridingUIDragDetectors(RBX::Workspace *this, RBX::DataModel *a2)
{
  __int64 v3; // rax

  if ( this != nullptr && (v3 = RBX::IPluginLegacyApi::get(this)) != 0 ) /*0x104f89f60*/
    return (*(__int64 (__fastcall **)(__int64, RBX::Workspace *))(*(_QWORD *)v3 + 152LL))(a1: v3, a2: this); /*0x104f89f78*/
  else
    return 0; /*0x104f89f7a*/
}

// Address: 0x104f8a074 | Name: __ZN3RBX9Workspace8render2dEPNS_5AdornE
__int64 __fastcall RBX::Workspace::render2d(RBX::Workspace *this, RBX::Adorn *a2)
{
  (*(void (__fastcall **)(_QWORD))(**((_QWORD **)this + 257) + 40LL))(a1: *((_QWORD *)this + 257) /* +2056: NO 2022 FIELD */); /*0x104f8a08b*/
  return RBX::IAdornableCollector::render2dItems(this: *((RBX::IAdornableCollector **)this + 241), a2); /*0x104f8a098*/
}

// Address: 0x104f8a0a2 | Name: __ZThn320_N3RBX9Workspace8render2dEPNS_5AdornE
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::render2d(RBX::Workspace *this, RBX::Adorn *a2)
{
  (*(void (__fastcall **)(_QWORD))(**((_QWORD **)this + 217) + 40LL))(a1: *((_QWORD *)this + 217) /* +1736 likely statsSyncHttpGetTime -- UNVERIFIED */); /*0x104f8a0b9*/
  return RBX::IAdornableCollector::render2dItems(this: *((RBX::IAdornableCollector **)this + 201), a2); /*0x104f8a0c6*/
}

// Address: 0x104f8a0d0 | Name: __ZN3RBX9Workspace33getMouseCommandCursorIfInViewportEv
RBX::Workspace *__fastcall RBX::Workspace::getMouseCommandCursorIfInViewport(RBX::Workspace *this, __int64 a2)
{
  __int64 v4; // rax
  _QWORD v6[7]; // [rsp+8h] [rbp-38h] BYREF

  v4 = RBX::ServiceProvider::find<RBX::UserInputService>(a1: a2); /*0x104f8a0e6*/
  if ( v4 != 0 && *(_BYTE *)(v4 + 1281) != 0 ) /*0x104f8a0f7*/
  {
    if ( FFlag::ImprovedCursors == 1 ) /*0x104f8a107*/
      (*(void (__fastcall **)(_QWORD *))(**(_QWORD **)(a2 + 2056) + 288LL))(a1: v6); /*0x104f8a11a*/
    else
      (*(void (__fastcall **)(_QWORD *))(**(_QWORD **)(a2 + 2056) + 296LL))(a1: v6); /*0x104f8a149*/
    this->... /* +0 */= v6[0]; /*0x104f8a153*/
    *((_QWORD *)this + 3) /* +24: NO 2022 FIELD */ = v6[3]; /*0x104f8a15a*/
    *(_OWORD *)((char *)this + 8 /* +8: NO 2022 FIELD */) = *(_OWORD *)&v6[1]; /*0x104f8a163*/
  }
  else
  {
    this->... /* +0 */= 2; /*0x104f8a122*/
    *(_OWORD *)((char *)this + 8 /* +8: NO 2022 FIELD */) = 0; /*0x104f8a12a*/
    *((_QWORD *)this + 3) /* +24: NO 2022 FIELD */ = 0; /*0x104f8a12e*/
  }
  return this; /*0x104f8a16a*/
}

// Address: 0x104f8a176 | Name: __ZN3RBX9Workspace9getCursorEv
RBX::Workspace *__fastcall RBX::Workspace::getCursor(RBX::Workspace *this, __int64 a2)
{
  _QWORD *v4; // rax
  _QWORD v6[4]; // [rsp+8h] [rbp-58h] BYREF
  __int16 v7; // [rsp+28h] [rbp-38h] BYREF
  __int128 v8; // [rsp+30h] [rbp-30h]
  void *v9; // [rsp+40h] [rbp-20h]

  v4 = (_QWORD *)RBX::ServiceProvider::find<RBX::MouseService>(a1: a2); /*0x104f8a18c*/
  if ( v4 != nullptr ) /*0x104f8a194*/
  {
    RBX::MouseService::getCurrentMouseIcon(this: (RBX::MouseService *)v6, a2: v4); /*0x104f8a1a0*/
    v7 = v6[0]; /*0x104f8a1ad*/
    v8 = *(_OWORD *)&v6[1]; /*0x104f8a1b5*/
    v9 = (void *)v6[3]; /*0x104f8a1bd*/
    if ( (unsigned __int16)RBX::ContentId::getType(this: (RBX::ContentId *)&v7) == 2 ) /*0x104f8a1ca*/
    {
      RBX::Workspace::getMouseCommandCursorIfInViewport(this, a2); /*0x104f8a1d2*/
      if ( (v8 & 1) != 0 ) /*0x104f8a1db*/
        operator delete(a1: v9); /*0x104f8a1e1*/
    }
    else
    {
      this->... /* +0 */= v7; /*0x104f8a1fd*/
      *(_OWORD *)((char *)this + 8 /* +8: NO 2022 FIELD */) = v8; /*0x104f8a203*/
      *((_QWORD *)this + 3) /* +24: NO 2022 FIELD */ = v9; /*0x104f8a20b*/
    }
  }
  else
  {
    RBX::Workspace::getMouseCommandCursorIfInViewport(this, a2); /*0x104f8a1ee*/
  }
  return this; /*0x104f8a212*/
}

// Address: 0x104f8a238 | Name: __ZN3RBX9Workspace17getRealPhysicsFPSEv
double __fastcall RBX::Workspace::getRealPhysicsFPS(RBX::Workspace *this, const RBX::Instance *a2)
{
  RBX::ServiceProvider *ServiceProvider; // rax
  RBX::RunService *v4; // rdi
  double v5; // xmm0_8
  RBX::Instance *v6; // rsi
  double v7; // xmm1_8
  RBX::DataModel *v8; // rax
  RBX::DataModel *v9; // rbx
  double v10; // xmm1_8
  double result; // xmm0_8
  __int64 *v12; // rdi
  void (__fastcall *v13)(void *); // rdx
  __int64 *v14; // [rsp+8h] [rbp-28h] BYREF
  __int64 **v15; // [rsp+10h] [rbp-20h] BYREF
  __int64 v16; // [rsp+18h] [rbp-18h] BYREF
  double v17; // [rsp+20h] [rbp-10h]

  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2); /*0x104f8a244*/
  if ( ServiceProvider != nullptr ) /*0x104f8a24c*/
    v4 = (RBX::RunService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::RunService>(this: ServiceProvider); /*0x104f8a256*/
  else
    v4 = nullptr; /*0x104f8a25b*/
  RBX::RunService::smoothFps(this: v4); /*0x104f8a25d*/
  v7 = RBX::EThrottle::getEnvironmentSpeed(this: (RBX::EThrottle *)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 172LL)) * v5; /*0x104f8a27c*/
  if ( v7 <= (double)DFInt::ElevatedPhysicsFPSReportThresholdTenths / 10.0 ) /*0x104f8a298*/
    return v7; /*0x104f8a2ce*/
  v17 = v7; /*0x104f8a29a*/
  v8 = (RBX::DataModel *)RBX::DataModel::get(this, a2: v6); /*0x104f8a2a2*/
  if ( v8 != nullptr ) /*0x104f8a2aa*/
  {
    v9 = v8; /*0x104f8a2b0*/
    if ( (unsigned __int8)RBX::DataModel::isPlayClientLaunchIntent(this: v8) != 0 ) /*0x104f8a2bd*/
    {
      result = 60.0; /*0x104f8a2d3*/
      v10 = v17; /*0x104f8a2db*/
    }
    else
    {
      v10 = v17; /*0x104f8a2bf*/
      result = v17; /*0x104f8a2c4*/
    }
    if ( v10 <= 100.0 ) /*0x104f8a2ef*/
    {
      if ( v10 <= 90.0 ) /*0x104f8a333*/
      {
        if ( v10 <= 80.0 ) /*0x104f8a377*/
        {
          if ( v10 <= 70.0 ) /*0x104f8a3bb*/
          {
            if ( v10 <= 65.0 ) /*0x104f8a3fc*/
            {
              v16 = *((_QWORD *)v9 + 105); /*0x104f8a431*/
              if ( RBX::Workspace::getRealPhysicsFPS(void)::flag == -1 ) /*0x104f8a440*/
                return result; /*0x104f8a440*/
              v14 = &v16; /*0x104f8a44a*/
              v15 = &v14; /*0x104f8a451*/
              v12 = (__int64 *)&RBX::Workspace::getRealPhysicsFPS(void)::flag; /*0x104f8a454*/
              v13 = std::__call_once_proxy[abi:ne200100]<std::tuple<RBX::Workspace::getRealPhysicsFPS(void)::$_5 &&>>; /*0x104f8a45b*/
            }
            else
            {
              v16 = *((_QWORD *)v9 + 105); /*0x104f8a3fe*/
              if ( RBX::Workspace::getRealPhysicsFPS(void)::flag == -1 ) /*0x104f8a40d*/
                return result; /*0x104f8a40d*/
              v14 = &v16; /*0x104f8a417*/
              v15 = &v14; /*0x104f8a41e*/
              v12 = &RBX::Workspace::getRealPhysicsFPS(void)::flag; /*0x104f8a421*/
              v13 = (void (__fastcall *)(void *))std::__call_once_proxy[abi:ne200100]<std::tuple<RBX::Workspace::getRealPhysicsFPS(void)::$_4 &&>>; /*0x104f8a428*/
            }
          }
          else
          {
            v16 = *((_QWORD *)v9 + 105); /*0x104f8a3bd*/
            if ( RBX::Workspace::getRealPhysicsFPS(void)::flag == -1 ) /*0x104f8a3cc*/
              return result; /*0x104f8a3cc*/
            v14 = &v16; /*0x104f8a3da*/
            v15 = &v14; /*0x104f8a3e1*/
            v12 = &RBX::Workspace::getRealPhysicsFPS(void)::flag; /*0x104f8a3e4*/
            v13 = (void (__fastcall *)(void *))std::__call_once_proxy[abi:ne200100]<std::tuple<RBX::Workspace::getRealPhysicsFPS(void)::$_3 &&>>; /*0x104f8a3eb*/
          }
        }
        else
        {
          v16 = *((_QWORD *)v9 + 105); /*0x104f8a379*/
          if ( RBX::Workspace::getRealPhysicsFPS(void)::flag == -1 ) /*0x104f8a388*/
            return result; /*0x104f8a388*/
          v14 = &v16; /*0x104f8a396*/
          v15 = &v14; /*0x104f8a39d*/
          v12 = &RBX::Workspace::getRealPhysicsFPS(void)::flag; /*0x104f8a3a0*/
          v13 = (void (__fastcall *)(void *))std::__call_once_proxy[abi:ne200100]<std::tuple<RBX::Workspace::getRealPhysicsFPS(void)::$_2 &&>>; /*0x104f8a3a7*/
        }
      }
      else
      {
        v16 = *((_QWORD *)v9 + 105); /*0x104f8a335*/
        if ( RBX::Workspace::getRealPhysicsFPS(void)::flag == -1 ) /*0x104f8a344*/
          return result; /*0x104f8a344*/
        v14 = &v16; /*0x104f8a352*/
        v15 = &v14; /*0x104f8a359*/
        v12 = &RBX::Workspace::getRealPhysicsFPS(void)::flag; /*0x104f8a35c*/
        v13 = (void (__fastcall *)(void *))std::__call_once_proxy[abi:ne200100]<std::tuple<RBX::Workspace::getRealPhysicsFPS(void)::$_1 &&>>; /*0x104f8a363*/
      }
    }
    else
    {
      v16 = *((_QWORD *)v9 + 105); /*0x104f8a2f1*/
      if ( RBX::Workspace::getRealPhysicsFPS(void)::flag == -1 ) /*0x104f8a300*/
        return result; /*0x104f8a300*/
      v14 = &v16; /*0x104f8a30e*/
      v15 = &v14; /*0x104f8a315*/
      v12 = &RBX::Workspace::getRealPhysicsFPS(void)::flag; /*0x104f8a318*/
      v13 = (void (__fastcall *)(void *))std::__call_once_proxy[abi:ne200100]<std::tuple<RBX::Workspace::getRealPhysicsFPS(void)::$_0 &&>>; /*0x104f8a31f*/
    }
    v17 = result; /*0x104f8a462*/
    std::__call_once(a1: (volatile unsigned __int64 *)v12, a2: &v15, a3: v13); /*0x104f8a467*/
  }
  return v17; /*0x104f8a471*/
}

// Address: 0x104f8a478 | Name: __ZN3RBX9Workspace20getPhysicsThrottlingEv
__int64 __fastcall RBX::Workspace::getPhysicsThrottling(RBX::Workspace *this)
{
  float v1; // xmm0_4

  RBX::EThrottle::getEnvironmentSpeed(this: (RBX::EThrottle *)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 172LL)); /*0x104f8a48b*/
  return (unsigned int)(int)(float)(v1 * 100.0); /*0x104f8a49c*/
}

// Address: 0x104f8a49e | Name: __ZN3RBX9Workspace16getNumAwakePartsEv
__int64 __fastcall RBX::Workspace::getNumAwakeParts(RBX::Workspace *this)
{
  __int64 v1; // rax
  RBX::Assembly **v2; // r14
  RBX::Assembly **v3; // r15
  unsigned int v4; // ebx

  v1 = *(_QWORD *)(*(_QWORD *)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 2072LL) + 56LL); /*0x104f8a4b6*/
  v2 = *(RBX::Assembly ***)(v1 + 1912); /*0x104f8a4ba*/
  v3 = *(RBX::Assembly ***)(v1 + 1920); /*0x104f8a4c1*/
  v4 = 0; /*0x104f8a4c8*/
  while ( v2 != v3 ) /*0x104f8a4cd*/
    v4 += RBX::Assembly::getAssemblyPartCount(this: *v2++); /*0x104f8a4d7*/
  return v4; /*0x104f8a4e5*/
}

// Address: 0x104f8a4ec | Name: __ZNK3RBX9Workspace36getCollisionSummarySubscriptionCountEv
__int64 __fastcall RBX::Workspace::getCollisionSummarySubscriptionCount(RBX::Workspace *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 421) /* +3368: NO 2022 FIELD */; /*0x104f8a4ec*/
  if ( v1 != 0 ) /*0x104f8a4f6*/
    return -1171354717 * (unsigned int)((*(_QWORD *)(v1 + 16) - *(_QWORD *)(v1 + 8)) >> 3); /*0x104f8a508*/
  else
    return 0; /*0x104f8a510*/
}

// Address: 0x104f8a514 | Name: __ZN3RBX9Workspace25subscribeCollisionSummaryEPNS_8BasePartENS_3Lua13WeakObjectRefE
_QWORD *__fastcall RBX::Workspace::subscribeCollisionSummary(_QWORD *a1, __int64 a2, RBX::Primitive **a3)
{
  __int64 *v5; // r15
  __int64 v6; // r14
  RSL::Arena *v7; // rdi
  _QWORD *v8; // rsi
  rbx::signals::slots_holder **v9; // r15
  unsigned int v10; // ebx
  unsigned int v11; // esi
  unsigned int v12; // r13d
  unsigned __int64 v13; // rsi
  unsigned __int64 v14; // r14
  rbx::signals::slots_holder *v15; // rax
  unsigned __int64 v16; // rax
  rbx::signals::slots_holder *v17; // rdi
  unsigned int v18; // esi
  volatile signed __int32 *v19; // rdi
  RBX::World *v20; // r13
  RBX::Primitive *v21; // r14
  rbx::signals::slots_holder **DestroyingSignal; // r15
  unsigned int v23; // esi
  unsigned __int64 v24; // rsi
  unsigned __int64 v25; // rbx
  rbx::signals::slots_holder *v26; // rax
  unsigned __int64 v27; // rax
  unsigned int v28; // esi
  volatile signed __int32 *v29; // rdi
  __int64 *v30; // rdx
  __int64 v31; // rax
  _QWORD *v32; // rcx
  __int64 v33; // rbx
  __int64 v34; // rax
  __int64 *v35; // rbx
  void *v36; // rdi
  void *v37; // rdi
  RBX::Primitive *v39; // [rsp+0h] [rbp-A0h] BYREF
  _QWORD v40[4]; // [rsp+8h] [rbp-98h] BYREF
  _QWORD v41[4]; // [rsp+28h] [rbp-78h] BYREF
  __int128 v42; // [rsp+48h] [rbp-58h]
  RBX::Primitive *v43; // [rsp+58h] [rbp-48h] BYREF
  _QWORD *v44; // [rsp+60h] [rbp-40h]
  __int64 *v45; // [rsp+68h] [rbp-38h]
  RBX::Memory *v46; // [rsp+70h] [rbp-30h]

  v44 = a1; /*0x104f8a52e*/
  v5 = (__int64 *)(a2 + 3368); /*0x104f8a532*/
  if ( *(_QWORD *)(a2 + 3368) == 0 ) /*0x104f8a541*/
  {
    v6 = operator new(a1: 0x50u); /*0x104f8a54d*/
    *(_OWORD *)v6 = 0; /*0x104f8a553*/
    *(_OWORD *)(v6 + 16) = 0; /*0x104f8a556*/
    *(_OWORD *)(v6 + 32) = 0; /*0x104f8a55a*/
    *(_OWORD *)(v6 + 48) = 0; /*0x104f8a55e*/
    *(_OWORD *)(v6 + 64) = 0; /*0x104f8a562*/
    *(_QWORD *)(v6 + 64) = RSL::Arena::getDefaultArena(this: v7); /*0x104f8a56b*/
    *(_OWORD *)(v6 + 32) = 0; /*0x104f8a572*/
    *(_OWORD *)(v6 + 48) = 0; /*0x104f8a577*/
    *(_BYTE *)(v6 + 72) = 0; /*0x104f8a57c*/
    v8 = (_QWORD *)*v5; /*0x104f8a581*/
    *v5 = v6; /*0x104f8a584*/
    if ( v8 != nullptr ) /*0x104f8a58a*/
      std::default_delete<RBX::Workspace::CollisionSummaryState>::operator()[abi:ne200100](a1: v5); /*0x104f8a58f*/
  }
  v45 = v5; /*0x104f8a594*/
  LODWORD(v40[1]) = 0; /*0x104f8a5a1*/
  *(_OWORD *)&v40[2] = 0; /*0x104f8a5a7*/
  v40[0] = off_10C43E1A0; /*0x104f8a5b2*/
  LODWORD(v41[1]) = 0; /*0x104f8a5b5*/
  v41[0] = off_10C982570; /*0x104f8a5c3*/
  *(_OWORD *)&v41[2] = 0; /*0x104f8a5c7*/
  v42 = 0; /*0x104f8a5cb*/
  v46 = (RBX::Memory *)a3; /*0x104f8a5cf*/
  v39 = a3[47]; /*0x104f8a5da*/
  RBX::Lua::WeakThreadRef::operator=(this: (RBX::Lua::WeakThreadRef *)v40); /*0x104f8a5e1*/
  v9 = (rbx::signals::slots_holder **)*v45; /*0x104f8a5ea*/
  v10 = (unsigned int)RBX::Memory::InstanceSignal; /*0x104f8a5f4*/
  v12 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v11); /*0x104f8a5fd*/
  rbx::lazyInitSlotsHolder(a1: v9); /*0x104f8a603*/
  v14 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v13); /*0x104f8a612*/
  *(_QWORD *)v14 = &_mh_execute_header; /*0x104f8a61f*/
  *(_QWORD *)(v14 + 8) = rbx::signals::slot_with_functor<RBX::Workspace::subscribeCollisionSummary(RBX::BasePart *,RBX::Lua::WeakObjectRef)::$_0>::do_call; /*0x104f8a629*/
  *(_OWORD *)(v14 + 16) = 0; /*0x104f8a630*/
  v15 = *v9; /*0x104f8a635*/
  *(_QWORD *)(v14 + 32) = *v9; /*0x104f8a638*/
  if ( v15 != nullptr ) /*0x104f8a63f*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v15 + 1); /*0x104f8a641*/
    v16 = *(_QWORD *)(v14 + 24) & 0xFFFFFFFFFFFFFFFBLL; /*0x104f8a649*/
    v17 = *v9; /*0x104f8a64d*/
  }
  else
  {
    v17 = nullptr; /*0x104f8a652*/
    v16 = 0; /*0x104f8a654*/
  }
  *(_QWORD *)(v14 + 24) = v16; /*0x104f8a656*/
  rbx::signals::slots_holder::insert(this: v17, a2: v14); /*0x104f8a65d*/
  _InterlockedIncrement((volatile signed __int32 *)(v14 + 4)); /*0x104f8a662*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v12, a2: v18); /*0x104f8a66a*/
  v19 = (volatile signed __int32 *)v42; /*0x104f8a66f*/
  *(_QWORD *)&v42 = v14; /*0x104f8a673*/
  if ( v19 != nullptr && _InterlockedDecrement(v19 + 1) == 0 ) /*0x104f8a680*/
    rbx::signals::slot_base::operator delete(a1: (void *)v19); /*0x104f8a682*/
  v20 = *(RBX::World **)(a2 + 944); /*0x104f8a687*/
  v21 = v39; /*0x104f8a68f*/
  v43 = v39; /*0x104f8a696*/
  RBX::World::subscribeToSummaries(this: v20, a2: v39); /*0x104f8a6a0*/
  DestroyingSignal = (rbx::signals::slots_holder **)RBX::Instance::getOrCreateDestroyingSignal(this: v46, a2: true); /*0x104f8a6b3*/
  LODWORD(v46) = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v10, a2: v23); /*0x104f8a6bd*/
  rbx::lazyInitSlotsHolder(a1: DestroyingSignal); /*0x104f8a6c3*/
  v25 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x40, a2: v24); /*0x104f8a6d2*/
  *(_QWORD *)v25 = &_mh_execute_header; /*0x104f8a6df*/
  *(_QWORD *)(v25 + 8) = rbx::signals::slot_with_functor<RBX::Workspace::subscribeCollisionSummary(RBX::BasePart *,RBX::Lua::WeakObjectRef)::$_1>::do_call; /*0x104f8a6e9*/
  *(_OWORD *)(v25 + 16) = 0; /*0x104f8a6f0*/
  v26 = *DestroyingSignal; /*0x104f8a6f4*/
  *(_QWORD *)(v25 + 32) = *DestroyingSignal; /*0x104f8a6f7*/
  if ( v26 != nullptr ) /*0x104f8a6fe*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v26 + 1); /*0x104f8a700*/
    v27 = *(_QWORD *)(v25 + 24) & 0xFFFFFFFFFFFFFFFBLL; /*0x104f8a708*/
  }
  else
  {
    v27 = 0; /*0x104f8a70e*/
  }
  *(_QWORD *)(v25 + 24) = v27; /*0x104f8a710*/
  *(_QWORD *)(v25 + 40) = a2; /*0x104f8a714*/
  *(_QWORD *)(v25 + 48) = v21; /*0x104f8a718*/
  *(_QWORD *)(v25 + 56) = v20; /*0x104f8a71c*/
  rbx::signals::slots_holder::insert(this: *DestroyingSignal, a2: v25); /*0x104f8a726*/
  _InterlockedIncrement((volatile signed __int32 *)(v25 + 4)); /*0x104f8a72b*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)v46, a2: v28); /*0x104f8a732*/
  v29 = *((volatile signed __int32 **)&v42 + 1); /*0x104f8a737*/
  *((_QWORD *)&v42 + 1) = v25; /*0x104f8a73b*/
  if ( v29 != nullptr && _InterlockedDecrement(v29 + 1) == 0 ) /*0x104f8a748*/
    rbx::signals::slot_base::operator delete(a1: (void *)v29); /*0x104f8a74a*/
  if ( (_QWORD)v42 != 0 ) /*0x104f8a756*/
  {
    v30 = v45; /*0x104f8a75c*/
    if ( *(_DWORD *)v42 != 0 ) /*0x104f8a760*/
    {
      v31 = v42; /*0x104f8a762*/
      _InterlockedIncrement((volatile signed __int32 *)(v42 + 4)); /*0x104f8a766*/
    }
    else
    {
      v31 = 0; /*0x104f8a774*/
    }
  }
  else
  {
    v31 = 0; /*0x104f8a76c*/
    v30 = v45; /*0x104f8a76e*/
  }
  v32 = v44; /*0x104f8a776*/
  *v44 = v31; /*0x104f8a77a*/
  *(_OWORD *)(v32 + 1) = 0; /*0x104f8a780*/
  v33 = *v30; /*0x104f8a784*/
  v34 = RBX::details::SplitHashTable<RBX::Primitive const*,std::pair<RBX::Primitive const*,std::vector<RBX::ContactSummary>>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Primitive const*>,RBX::details::DefaultEqualTo<RBX::Primitive const*>,RBX::details::GetMapKey<RBX::Primitive const*,std::vector<RBX::ContactSummary>>>::emplace<RBX::Primitive const*>( /*0x104f8a78f*/
          a1: *v30 + 32,
          a2: &v43);
  if ( (v34 & 0x100000000LL) != 0 ) /*0x104f8a799*/
    *(_QWORD *)(*(_QWORD *)(v33 + 48) + 32LL * (unsigned int)v34) = v43; /*0x104f8a7a9*/
  v35 = v45; /*0x104f8a7ad*/
  std::vector<RBX::Workspace::CollisionSummaryState::Subscription>::push_back[abi:ne200100](a1: *v45 + 8, a2: &v39); /*0x104f8a7bf*/
  *(_BYTE *)(*v35 + 72) = 0; /*0x104f8a7c7*/
  v36 = *((void **)&v42 + 1); /*0x104f8a7cb*/
  if ( *((_QWORD *)&v42 + 1) != 0 /*0x104f8a7d8*/
    && _InterlockedDecrement((volatile signed __int32 *)(*((_QWORD *)&v42 + 1) + 4LL)) == 0 )
  {
    rbx::signals::slot_base::operator delete(a1: v36); /*0x104f8a7da*/
  }
  v37 = (void *)v42; /*0x104f8a7e3*/
  if ( (_QWORD)v42 != 0 && _InterlockedDecrement((volatile signed __int32 *)(v42 + 4)) == 0 ) /*0x104f8a7f0*/
    rbx::signals::slot_base::operator delete(a1: v37); /*0x104f8a7f2*/
  RBX::Lua::WeakThreadRef::~WeakThreadRef(this: (RBX::Lua::WeakThreadRef *)v41); /*0x104f8a7fa*/
  RBX::Lua::WeakThreadRef::~WeakThreadRef(this: (RBX::Lua::WeakThreadRef *)v40); /*0x104f8a806*/
  return v44; /*0x104f8a80f*/
}

// Address: 0x104f8aada | Name: __ZN3RBX9Workspace13render3dAdornEPNS_5AdornE
__int64 __fastcall RBX::Workspace::render3dAdorn(RBX::Workspace *this, RBX::Adorn *a2)
{
  RBX::Players *v2; // r13
  __int64 v3; // rbx
  RBX::Instance *v4; // rsi
  RBX::DataModel *v5; // rax
  const RBX::DataModel *v6; // rsi
  __int64 v7; // rbx
  double v8; // xmm0_8
  __int64 v9; // rbx
  RBX::Players *v10; // rax
  unsigned __int64 *v11; // r13
  unsigned __int64 *i; // r14
  __int64 v13; // xmm0_8
  __m128 v14; // xmm0
  float v15; // xmm1_4
  double v16; // xmm0_8
  __m128 v17; // xmm4
  float v18; // xmm2_4
  float v19; // xmm2_4
  const RBX::Color4 *v20; // r8
  __int64 v21; // rbx
  __int64 v22; // rdx
  RBX::Instance *v23; // rsi
  RBX::DataModel *v24; // rax
  RBX::World *v25; // rdi
  __int64 ContactManager; // rax
  RBX::CoordinateFrame *v27; // r14
  __int64 v28; // xmm0_8
  __m128 v29; // xmm0
  __m128d v30; // xmm0
  __int64 v31; // r13
  __int64 v32; // rbx
  float v33; // xmm1_4
  __m128 v34; // xmm2
  float v35; // xmm0_4
  const RBX::Color4 *v36; // r8
  float v37; // xmm0_4
  bool v38; // zf
  int v39; // xmm0_4
  float v40; // xmm0_4
  __int64 v41; // rax
  RBX::Color3 *v42; // rdi
  RBX::CoordinateFrame *v43; // rbx
  RBX::CoordinateFrame *v44; // r14
  RBX::Color3 *v45; // r12
  int v46; // eax
  __m128 v47; // xmm2
  float v48; // xmm0_4
  __m128 v49; // xmm2
  float v50; // xmm0_4
  unsigned __int64 *v51; // rax
  RBX::Color3 *v52; // rdi
  __m128 v53; // xmm2
  float v54; // xmm0_4
  float v55; // xmm0_4
  __int64 v56; // rax
  const RBX::Color4 *v57; // r8
  unsigned __int64 *v58; // rax
  const RBX::Color4 *v59; // r8
  float v60; // xmm0_4
  float v61; // xmm0_4
  const RBX::Color4 *v62; // r8
  char v63; // al
  __int64 v64; // rcx
  RBX::Primitive **v65; // r15
  RBX::Primitive **v66; // r12
  RBX::CoordinateFrame *v67; // rax
  signed __int64 v68; // r13
  RBX::Instance *v69; // r14
  __int64 v70; // r12
  __int64 v71; // xmm0_8
  __m128 v72; // xmm0
  const RBX::Color4 *v73; // r8
  __int64 v74; // rax
  float v75; // xmm1_4
  double v76; // xmm0_8
  float v77; // xmm2_4
  float v78; // xmm3_4
  __m128 v79; // xmm5
  __m128 v80; // xmm6
  unsigned __int64 v81; // rcx
  unsigned __int64 v82; // rdi
  __int64 v83; // rax
  double v84; // xmm1_8
  double v85; // xmm2_8
  double v86; // xmm0_8
  double v87; // xmm0_8
  RBX::Color3 *v88; // rdi
  __int64 v89; // rax
  RBX::Color3 *v90; // rdi
  __int64 v91; // rax
  RBX::Color3 *v92; // rdi
  __int64 v93; // rax
  RBX::Color3 *v94; // rdi
  __int64 v95; // rax
  RBX::Color3 *v96; // rdi
  __int64 v97; // rax
  RBX::Color3 *v98; // rdi
  __int64 v99; // rax
  RBX::Color3 *v100; // rdi
  __int64 v101; // rax
  RBX::Color3 *v102; // rdi
  __int64 v103; // rax
  RBX::Color3 *v104; // rdi
  __int64 v105; // rax
  RBX::Color3 *v106; // rdi
  __int64 v107; // rax
  RBX::Color3 *v108; // rdi
  __int64 v109; // rax
  RBX::Color3 *v110; // rdi
  __int64 v111; // rax
  RBX::Color3 *v112; // rdi
  __int64 v113; // rax
  RBX::Color3 *v114; // rdi
  __int64 v115; // rax
  RBX::Color3 *v116; // rdi
  __int64 v117; // rax
  RBX::Color3 *v118; // rdi
  __int64 v119; // rax
  RBX::Color3 *v120; // rdi
  __int64 v121; // rax
  RBX::Color3 *v122; // rdi
  __int64 v123; // rax
  RBX::Color3 *v124; // rdi
  __int64 v125; // rax
  RBX::Color3 *v126; // rdi
  __int64 v127; // rax
  const RBX::Color4 *v128; // r8
  RBX::CoordinateFrame *v129; // rax
  signed __int64 v130; // r12
  signed __int64 v131; // r13
  float v132; // xmm0_4
  __m128 v133; // xmm9
  __m128 v134; // xmm14
  __m128 v135; // xmm15
  __m128 v136; // xmm3
  __int64 v137; // r14
  __m128 v138; // xmm8
  __m128 v139; // xmm1
  __m128 v140; // xmm0
  unsigned __int32 v141; // xmm0_4
  __int64 v142; // rax
  float v143; // xmm1_4
  __m128 v144; // xmm2
  float v145; // xmm1_4
  __m128 v146; // xmm3
  float v147; // xmm4_4
  float v148; // xmm1_4
  __m128 v149; // xmm2
  __int64 v150; // rax
  float v151; // xmm3_4
  float v152; // xmm4_4
  __m128 v153; // xmm6
  __m128 v154; // xmm7
  __m128 v155; // xmm0
  __m128 v156; // xmm1
  unsigned __int64 v157; // rcx
  unsigned __int64 v158; // rsi
  RBX::DecompDebugVisualizer *v159; // rdi
  RBX::Physics::ConvexDecompVisualizer *v160; // rdi
  __int64 v161; // rax
  __int64 v162; // r14
  __int64 v163; // r15
  const RBX::TriangleMeshPart *v164; // rbx
  __int64 v165; // r12
  __int64 v166; // rax
  const RBX::BasePart *v167; // rsi
  _QWORD *v168; // rax
  RBX::Voxel2::Region *v169; // rbx
  RBX::Voxel2::Region *v170; // r15
  float v171; // xmm0_4
  float v172; // xmm1_4
  __m128 v173; // xmm3
  __m128 v174; // xmm4
  float v175; // xmm2_4
  RBX::Color3 *v176; // rdi
  __int64 v177; // rax
  const RBX::Color4 *v178; // r8
  RBX::Voxel2::Region *v179; // rbx
  RBX::Voxel2::Region *j; // r15
  float v181; // xmm0_4
  float v182; // xmm1_4
  __m128 v183; // xmm3
  __m128 v184; // xmm4
  float v185; // xmm2_4
  RBX::Color3 *v186; // rdi
  __int64 v187; // rax
  const RBX::Color4 *v188; // r8
  RBX::Players *v189; // r14
  RBX::World *v190; // rdi
  unsigned __int64 v191; // r8
  __int64 v192; // r9
  double v193; // rbx
  char v194; // al
  _QWORD *v195; // r14
  _QWORD *v196; // rax
  __int64 v197; // rdx
  unsigned int v198; // eax
  __int64 v199; // rdx
  __int64 v200; // rdx
  double v201; // r15
  __int64 v202; // rax
  __int64 v203; // rdx
  RBX::Assembly *v204; // rdi
  RBX::Primitive *v205; // rsi
  RBX::CoordinateFrame *v206; // rdi
  char v207; // r14
  unsigned __int64 v208; // rbx
  __int64 v209; // r15
  RBX::Camera *v210; // r14
  __int64 PV; // rax
  RBX::Camera *v212; // rax
  __int64 v213; // r14
  __int64 v214; // rax
  __int64 v215; // rdx
  float v216; // xmm1_4
  __m128 v217; // xmm2
  __m128 v218; // xmm2
  RBX::Color3 *v219; // rdi
  __int64 v220; // rax
  __int64 v221; // r14
  __int64 v222; // rax
  __int64 v223; // rcx
  unsigned __int64 v224; // rcx
  __int64 *v225; // rsi
  __int64 v226; // rdi
  RBX::Color3 *v227; // rdi
  __int64 v228; // rax
  RBX::Color3 *v229; // rdi
  __int64 v230; // rax
  RBX::Color3 *v231; // rdi
  __int64 v232; // rax
  RBX::Color3 *v233; // rbx
  __int64 LocalPlayer; // rax
  const RBX::Instance *v235; // rsi
  RBX::Adorn *v236; // rax
  const RBX::Camera *v237; // rdx
  RBX::RunService *v238; // rdi
  RBX::CorePhysicsSettings *v239; // rdi
  RBX::CorePhysicsSettings *v240; // rax
  char DrawTotalNetForce; // al
  RBX::Constraints::GizmoManager *v242; // rdi
  RBX::World *v243; // rdi
  RBX::Constraints::GizmoManager *v244; // rbx
  const RBX::FluidModels::FixedProfileFluid *AirModel; // rax
  unsigned __int8 v247; // r8
  unsigned __int8 v248; // r8
  unsigned __int8 v249; // r8
  long double v250; // [rsp+0h] [rbp-5A0h]
  long double v251; // [rsp+0h] [rbp-5A0h]
  long double v252; // [rsp+0h] [rbp-5A0h]
  long double v253; // [rsp+0h] [rbp-5A0h]
  long double v254; // [rsp+0h] [rbp-5A0h]
  long double v255; // [rsp+0h] [rbp-5A0h]
  long double v256; // [rsp+0h] [rbp-5A0h]
  __int64 v257; // [rsp+10h] [rbp-590h]
  __int64 v258; // [rsp+18h] [rbp-588h]
  __int128 v259; // [rsp+40h] [rbp-560h] BYREF
  __int128 v260; // [rsp+50h] [rbp-550h]
  double v261[9]; // [rsp+60h] [rbp-540h] BYREF
  unsigned __int64 v262; // [rsp+A8h] [rbp-4F8h] BYREF
  unsigned __int64 v263; // [rsp+B0h] [rbp-4F0h] BYREF
  double v264; // [rsp+B8h] [rbp-4E8h]
  double v265; // [rsp+C0h] [rbp-4E0h]
  double v266; // [rsp+C8h] [rbp-4D8h]
  double v267; // [rsp+D0h] [rbp-4D0h]
  double v268; // [rsp+D8h] [rbp-4C8h]
  double v269; // [rsp+E0h] [rbp-4C0h]
  double v270; // [rsp+E8h] [rbp-4B8h]
  double v271; // [rsp+F0h] [rbp-4B0h]
  double v272; // [rsp+F8h] [rbp-4A8h]
  __int128 v273; // [rsp+100h] [rbp-4A0h] BYREF
  double v274; // [rsp+110h] [rbp-490h]
  double v275; // [rsp+118h] [rbp-488h]
  __m128 v276; // [rsp+120h] [rbp-480h]
  double v277; // [rsp+130h] [rbp-470h]
  double v278; // [rsp+138h] [rbp-468h]
  unsigned __int64 v279; // [rsp+140h] [rbp-460h] BYREF
  float v280; // [rsp+148h] [rbp-458h]
  int v281; // [rsp+14Ch] [rbp-454h]
  __int128 v282; // [rsp+150h] [rbp-450h] BYREF
  __m128 v283; // [rsp+160h] [rbp-440h]
  __m128d v284; // [rsp+170h] [rbp-430h]
  __int64 AssemblyPrimitive; // [rsp+180h] [rbp-420h] BYREF
  RBX::Players *v286; // [rsp+188h] [rbp-418h]
  __int128 v287; // [rsp+190h] [rbp-410h] BYREF
  void *v288[2]; // [rsp+1A0h] [rbp-400h]
  int v289; // [rsp+1B0h] [rbp-3F0h]
  __int64 v290; // [rsp+1B4h] [rbp-3ECh] BYREF
  float v291; // [rsp+1BCh] [rbp-3E4h]
  __int64 v292; // [rsp+1C0h] [rbp-3E0h] BYREF
  unsigned __int64 v293; // [rsp+1C8h] [rbp-3D8h] BYREF
  int v294; // [rsp+1D0h] [rbp-3D0h]
  RBX::Color3 *v295; // [rsp+1D8h] [rbp-3C8h]
  double v296[2]; // [rsp+1E0h] [rbp-3C0h] BYREF
  double v297[2]; // [rsp+1F0h] [rbp-3B0h]
  int v298; // [rsp+200h] [rbp-3A0h]
  __int64 v299; // [rsp+204h] [rbp-39Ch] BYREF
  float v300; // [rsp+20Ch] [rbp-394h]
  int v301; // [rsp+210h] [rbp-390h]
  unsigned __int64 v302; // [rsp+214h] [rbp-38Ch]
  __int32 v303; // [rsp+21Ch] [rbp-384h]
  __m256i v304; // [rsp+220h] [rbp-380h] BYREF
  double v305[96]; // [rsp+240h] [rbp-360h] BYREF
  RBX::CoordinateFrame *v306[2]; // [rsp+540h] [rbp-60h] BYREF
  __int128 v307; // [rsp+550h] [rbp-50h]
  __int64 v308; // [rsp+560h] [rbp-40h]

  v295 = a2; /*0x104f8aaee*/
  v2 = this; /*0x104f8aaf5*/
  v38 = *(_BYTE *)(RBX::ServiceProvider::find<RBX::GuiService>(a1: this) + 715) == 1; /*0x104f8ab0b*/
  v286 = v2; /*0x104f8ab12*/
  if ( v38 ) /*0x104f8ab19*/
  {
    RBX::UIMetrics::UIMetricsPerfTimerScope::UIMetricsPerfTimerScope(a1: &v259, a2: 2, a3: 0); /*0x104f8ab2d*/
    if ( (_BYTE)`guard variable for'RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3936 == 0 /*0x104f8d30a*/
      && __cxa_guard_acquire(a1: &`guard variable for'RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3936) != 0 )
    {
      v304.i64[0] = (__int64)"eter version"; /*0x104f8d333*/
      RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3936 = RBX::Profiler::getToken( /*0x104f8d357*/
                                                                     this: (RBX::Profiler *)&aAacontrols[-880105],
                                                                     a2: &aFlogGlyphrende_0[-29495],
                                                                     a3: (const char *)0xFFFFFFFFLL,
                                                                     a4: 255,
                                                                     a5: v249);
      __cxa_guard_release(a1: &`guard variable for'RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3936); /*0x104f8d365*/
      v2 = v286; /*0x104f8d36a*/
    }
    v3 = RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3936; /*0x104f8ab40*/
    v304.i128[0] = 0; /*0x104f8ab52*/
    v304.i64[3] = -1; /*0x104f8ab56*/
    memset(v305, 0, 52); /*0x104f8ab5e*/
    *(_OWORD *)&v305[7] = 0; /*0x104f8ab74*/
    v304.i64[2] = RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3936; /*0x104f8ab79*/
    RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)&v304); /*0x104f8ab7d*/
    v304.i64[3] = RBX::Profiler::enterRegion(a1: v3, a2: -1, a3: 0); /*0x104f8ab93*/
    v5 = RBX::DataModel::get(this: v2, a2: v4); /*0x104f8ab9d*/
    if ( v5 != nullptr ) /*0x104f8aba5*/
    {
      v7 = *((_QWORD *)v2 + 118); /*0x104f8aba7*/
      if ( v7 != 0 ) /*0x104f8abb1*/
      {
        RBX::WorldStats::getGameTime(this: v5, a2: v6); /*0x104f8abb6*/
        RBX::World::HumanoidNameRaycastCache::performRaycasts( /*0x104f8abdf*/
          this: (RBX::World::HumanoidNameRaycastCache *)(v7 + 2120),
          a2: v8,
          a3: *(RBX::ContactManager **)(*((_QWORD *)v2 + 118) + 2056LL),
          a4: v295,
          a5: 64);
      }
    }
    RBX::IAdornableCollector::render3dAdornItems(this: *((RBX::IAdornableCollector **)v2 + 241), a2: v295); /*0x104f8abf2*/
    RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)&v304); /*0x104f8abfe*/
    if ( (_BYTE)v260 == 1 ) /*0x104f8ac0a*/
      RBX::UIMetrics::UIMetricsPerfTimerScopeImpl::~UIMetricsPerfTimerScopeImpl(this: (RBX::UIMetrics::UIMetricsPerfTimerScopeImpl *)&v259); /*0x104f8ac13*/
  }
  if ( (_BYTE)`guard variable for'RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3953 == 0 /*0x104f8d211*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3953) != 0 )
  {
    v304.i64[0] = (__int64)"teLegXMinClassic"; /*0x104f8d23a*/
    RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3953 = RBX::Profiler::getToken( /*0x104f8d25e*/
                                                                   this: (RBX::Profiler *)&aMemoryNavigati[-321839],
                                                                   a2: &aUgcvalidateleg[-487159],
                                                                   a3: (const char *)0xFFFFFFFFLL,
                                                                   a4: 255,
                                                                   a5: v247);
    __cxa_guard_release(a1: &`guard variable for'RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3953); /*0x104f8d26c*/
    v2 = v286; /*0x104f8d271*/
  }
  v9 = RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3953; /*0x104f8ac26*/
  v304.i128[0] = 0; /*0x104f8ac38*/
  v304.i64[3] = -1; /*0x104f8ac3c*/
  memset(v305, 0, 52); /*0x104f8ac44*/
  *(_OWORD *)&v305[7] = 0; /*0x104f8ac5a*/
  v304.i64[2] = RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3953; /*0x104f8ac5f*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)&v304); /*0x104f8ac63*/
  v304.i64[3] = RBX::Profiler::enterRegion(a1: v9, a2: -1, a3: 0); /*0x104f8ac80*/
  if ( DFFlag::DebugEnableStreamingSolverVisualization == 1 ) /*0x104f8ac8a*/
  {
    RBX::Random::Random(this: (RBX::Random *)&v287, a2: 42); /*0x104f8ac9c*/
    v10 = v2; /*0x104f8aca1*/
    v11 = *((unsigned __int64 **)v2 + 220); /*0x104f8aca4*/
    for ( i = *((unsigned __int64 **)v10 + 221); v11 != i; v11 += 3 ) /*0x104f8acb5*/
    {
      RBX::Random::nextNumber(this: (RBX::Random *)&v287, a2: v250); /*0x104f8acd2*/
      v283.i64[0] = v13; /*0x104f8acd7*/
      RBX::Random::nextNumber(this: (RBX::Random *)&v287, a2: v251); /*0x104f8ace2*/
      v284 = (__m128d)v14; /*0x104f8ace7*/
      RBX::Random::nextNumber(this: (RBX::Random *)&v287, a2: v252); /*0x104f8acf2*/
      v15 = *(double *)v283.i64; /*0x104f8acfa*/
      v16 = v284.f64[0]; /*0x104f8ad0e*/
      v17 = _mm_mul_ps( /*0x104f8ad2d*/
              _mm_add_ps((__m128)*(unsigned __int64 *)((char *)v11 + 12), (__m128)*v11),
              (__m128)xmmword_108F39940);
      v18 = (float)(*((float *)v11 + 2) + *((float *)v11 + 5)) * 0.5; /*0x104f8ad34*/
      v259 = 0x3F800000u; /*0x104f8ad44*/
      v260 = 0x3F800000u; /*0x104f8ad4b*/
      LODWORD(v261[0]) = 1065353216; /*0x104f8ad52*/
      _mm_storel_ps((double *)((char *)v261 + 4), v17); /*0x104f8ad59*/
      *((float *)&v261[1] + 1) = v18; /*0x104f8ad60*/
      v19 = *((float *)v11 + 5) - *((float *)v11 + 2); /*0x104f8ad7d*/
      _mm_storel_ps((double *)v306, _mm_sub_ps((__m128)*(unsigned __int64 *)((char *)v11 + 12), (__m128)*v11)); /*0x104f8ad83*/
      *(float *)&v306[1] = v19; /*0x104f8ad87*/
      *(float *)v296 = v15; /*0x104f8ad8c*/
      *(double *)((char *)v296 + 4) = v16; /*0x104f8ad94*/
      HIDWORD(v296[1]) = 1065353216; /*0x104f8ad9c*/
      RBX::Draw::selectionBox( /*0x104f8adc0*/
        this: (RBX::Draw *)&v259,
        a2: (const RBX::CoordinateFrame *)v306,
        a3: v295,
        a4: (RBX::Adorn *)v296,
        a5: v20,
        a6: 0.15000001);
    }
    v2 = v286; /*0x104f8add2*/
  }
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)&v304); /*0x104f8ade0*/
  if ( (_BYTE)`guard variable for'RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3968 == 0 /*0x104f8d28b*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3968) != 0 )
  {
    v304.i64[0] = (__int64)"ercentV2"; /*0x104f8d2b4*/
    RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3968 = RBX::Profiler::getToken( /*0x104f8d2d8*/
                                                                   this: (RBX::Profiler *)&aDflogRobuxtran_26[-369232],
                                                                   a2: &aAvatarchatsubs_4[-474881],
                                                                   a3: (const char *)0xFFFFFFFFLL,
                                                                   a4: 255,
                                                                   a5: v248);
    __cxa_guard_release(a1: &`guard variable for'RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3968); /*0x104f8d2e6*/
    v2 = v286; /*0x104f8d2eb*/
  }
  v21 = RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3968; /*0x104f8adf3*/
  v259 = 0; /*0x104f8ae05*/
  *((_QWORD *)&v260 + 1) = -1; /*0x104f8ae09*/
  memset(v261, 0, 52); /*0x104f8ae11*/
  *(_OWORD *)&v261[7] = 0; /*0x104f8ae27*/
  *(_QWORD *)&v260 = RBX::Workspace::render3dAdorn(RBX::Adorn *)::proftoken3968; /*0x104f8ae2c*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)&v259); /*0x104f8ae30*/
  *((_QWORD *)&v260 + 1) = RBX::Profiler::enterRegion(a1: v21, a2: -1, a3: 0); /*0x104f8ae4d*/
  if ( DFFlag::DebugDrawCollisionSummaries == 1 ) /*0x104f8ae57*/
  {
    v24 = RBX::DataModel::get(this: v2, a2: v23); /*0x104f8ae5c*/
    v25 = *((RBX::World **)v2 + 118); /*0x104f8ae61*/
    LOBYTE(v22) = v24 != nullptr && v25 != nullptr; /*0x104f8ae74*/
    if ( (_BYTE)v22 == 1 ) /*0x104f8ae79*/
      RBX::World::debugDrawAllContactSummaries(this: v25, a2: v24); /*0x104f8ae7e*/
  }
  if ( DFFlag::DebugDrawBvhNodes == 1 ) /*0x104f8ae8a*/
  {
    *(_OWORD *)v306 = 0; /*0x104f8ae94*/
    *(_QWORD *)&v307 = 0; /*0x104f8ae99*/
    ContactManager = RBX::CameraSubject::getContactManager(this: (RBX::Players *)((char *)v2 + 352)); /*0x104f8aea8*/
    RBX::ContactManager::debugGetMidPhaseBvhData(a1: ContactManager); /*0x104f8aeb4*/
    RBX::Random::Random(this: (RBX::Random *)&v279, a2: 42); /*0x104f8aec5*/
    v27 = v306[0]; /*0x104f8aeca*/
    for ( v276.i64[0] = (__int64)v306[1]; /*0x104f8aedc*/
          v27 != (RBX::CoordinateFrame *)v276.i64[0];
          v27 = (RBX::CoordinateFrame *)((char *)v27 + 72) )
    {
      RBX::Random::nextNumber(this: (RBX::Random *)&v279, a2: v250); /*0x104f8aefa*/
      v283.i64[0] = v28; /*0x104f8aeff*/
      RBX::Random::nextNumber(this: (RBX::Random *)&v279, a2: v253); /*0x104f8af0a*/
      v284 = (__m128d)v29; /*0x104f8af0f*/
      RBX::Random::nextNumber(this: (RBX::Random *)&v279, a2: v254); /*0x104f8af1a*/
      v31 = *((_QWORD *)v27 + 6); /*0x104f8af1f*/
      v32 = *((_QWORD *)v27 + 7); /*0x104f8af23*/
      if ( v31 != v32 ) /*0x104f8af2a*/
      {
        v33 = *(double *)v283.i64; /*0x104f8af33*/
        v283.f32[0] = v33; /*0x104f8af3b*/
        v284 = (__m128d)_mm_cvtpd_ps(_mm_unpacklo_pd(v284, v30)); /*0x104f8af53*/
        do /*0x104f8b05f*/
        {
          v34 = _mm_mul_ps( /*0x104f8af76*/
                  _mm_add_ps((__m128)*(unsigned __int64 *)(v31 + 16), (__m128)*(unsigned __int64 *)(v31 + 4)),
                  (__m128)xmmword_108F39940);
          v35 = (float)(*(float *)(v31 + 12) + *(float *)(v31 + 24)) * 0.5; /*0x104f8af7d*/
          v304.i128[0] = 0x3F800000u; /*0x104f8af8d*/
          v304.i128[1] = 0x3F800000u; /*0x104f8af94*/
          LODWORD(v305[0]) = 1065353216; /*0x104f8af9b*/
          _mm_storel_ps((double *)((char *)v305 + 4), v34); /*0x104f8afa5*/
          *((float *)&v305[1] + 1) = v35; /*0x104f8afac*/
          RBX::CoordinateFrame::operatorMul_SIMD(this: (RBX::CoordinateFrame *)v296, a2: v27); /*0x104f8afc1*/
          v37 = *(float *)(v31 + 24) - *(float *)(v31 + 12); /*0x104f8afdb*/
          _mm_storel_ps( /*0x104f8afe1*/
            (double *)&v292,
            _mm_sub_ps((__m128)*(unsigned __int64 *)(v31 + 16), (__m128)*(unsigned __int64 *)(v31 + 4)));
          *(float *)&v293 = v37; /*0x104f8afe8*/
          v38 = *(_BYTE *)v31 == 0; /*0x104f8aff0*/
          v39 = 1065353216; /*0x104f8aff5*/
          if ( *(_BYTE *)v31 == 0 ) /*0x104f8affd*/
            v39 = 1056964608; /*0x104f8afff*/
          LODWORD(v287) = v283.i32[0]; /*0x104f8b00f*/
          _mm_storel_ps((double *)((char *)&v287 + 4), (__m128)v284); /*0x104f8b01e*/
          HIDWORD(v287) = v39; /*0x104f8b025*/
          v40 = 0.1; /*0x104f8b02d*/
          if ( v38 ) /*0x104f8b035*/
            v40 = 0.050000001; /*0x104f8b037*/
          RBX::Draw::selectionBox( /*0x104f8b053*/
            this: (RBX::Draw *)v296,
            a2: (const RBX::CoordinateFrame *)&v292,
            a3: v295,
            a4: (RBX::Adorn *)&v287,
            a5: v36,
            a6: v40);
          v31 += 28; /*0x104f8b058*/
        }
        while ( v31 != v32 ); /*0x104f8b05f*/
      }
    }
    v304.i64[0] = (__int64)v306; /*0x104f8b088*/
    std::vector<RBX::Collision::DebugBvhData>::__destroy_vector::operator()[abi:ne200100](); /*0x104f8b08b*/
    v2 = v286; /*0x104f8b090*/
  }
  if ( (DFFlag::DebugDrawFlatMidPhase != 0 || DFFlag::DebugDrawFlatMidPhaseTerrain == 1) && FFlag::FlatMidPhase == 1 ) /*0x104f8b0b7*/
  {
    *(_OWORD *)v306 = 0; /*0x104f8b0c1*/
    *(_QWORD *)&v307 = 0; /*0x104f8b0c6*/
    v41 = RBX::CameraSubject::getContactManager(this: (RBX::Players *)((char *)v2 + 352)); /*0x104f8b0d5*/
    RBX::ContactManager::debugGetFlatMidPhaseOutputs(a1: v41); /*0x104f8b0e1*/
    v43 = v306[0]; /*0x104f8b0e6*/
    v44 = v306[1]; /*0x104f8b0ea*/
    if ( v306[0] != v306[1] ) /*0x104f8b0f1*/
    {
      v45 = v295; /*0x104f8b105*/
      do /*0x104f8b3e9*/
      {
        v46 = *((_DWORD *)v43 + 12); /*0x104f8b10c*/
        if ( v46 == 1 ) /*0x104f8b112*/
        {
          if ( DFFlag::DebugDrawFlatMidPhaseTerrain == 1 && FFlag::FlatMidPhaseTerrain == 1 ) /*0x104f8b1f5*/
          {
            v53 = _mm_mul_ps( /*0x104f8b211*/
                    _mm_add_ps((__m128)*(unsigned __int64 *)((char *)v43 + 12), (__m128)*(unsigned __int64 *)v43),
                    (__m128)xmmword_108F39940);
            v54 = (float)(*((float *)v43 + 2) + *((float *)v43 + 5)) * 0.5; /*0x104f8b218*/
            v304.i128[0] = 0x3F800000u; /*0x104f8b228*/
            v304.i128[1] = 0x3F800000u; /*0x104f8b22f*/
            LODWORD(v305[0]) = 1065353216; /*0x104f8b236*/
            _mm_storel_ps((double *)((char *)v305 + 4), v53); /*0x104f8b240*/
            *((float *)&v305[1] + 1) = v54; /*0x104f8b247*/
            v55 = *((float *)v43 + 5) - *((float *)v43 + 2); /*0x104f8b260*/
            _mm_storel_ps( /*0x104f8b265*/
              (double *)&v287,
              _mm_sub_ps((__m128)*(unsigned __int64 *)((char *)v43 + 12), (__m128)*(unsigned __int64 *)v43));
            *((float *)&v287 + 2) = v55; /*0x104f8b26c*/
            v56 = RBX::Color3::orange(this: v42); /*0x104f8b274*/
            v296[0] = *(double *)v56; /*0x104f8b27d*/
            LODWORD(v296[1]) = *(_DWORD *)(v56 + 8); /*0x104f8b28a*/
            HIDWORD(v296[1]) = 1065353216; /*0x104f8b292*/
            RBX::Draw::selectionBox( /*0x104f8b2bc*/
              this: (RBX::Draw *)&v304,
              a2: (const RBX::CoordinateFrame *)&v287,
              a3: v295,
              a4: (RBX::Adorn *)v296,
              a5: v57,
              a6: 0.1);
          }
        }
        else if ( v46 == 0 && DFFlag::DebugDrawFlatMidPhase == 1 ) /*0x104f8b127*/
        {
          v47 = _mm_mul_ps( /*0x104f8b14a*/
                  _mm_add_ps((__m128)*(unsigned __int64 *)((char *)v43 + 12), (__m128)*(unsigned __int64 *)v43),
                  (__m128)xmmword_108F39940);
          v48 = (float)(*((float *)v43 + 2) + *((float *)v43 + 5)) * 0.5; /*0x104f8b155*/
          v304.i128[0] = 0x3F800000u; /*0x104f8b161*/
          v304.i128[1] = 0x3F800000u; /*0x104f8b168*/
          LODWORD(v305[0]) = 1065353216; /*0x104f8b174*/
          _mm_storel_ps((double *)((char *)v305 + 4), v47); /*0x104f8b17a*/
          *((float *)&v305[1] + 1) = v48; /*0x104f8b181*/
          v49 = _mm_mul_ps( /*0x104f8b1a0*/
                  _mm_add_ps((__m128)*(unsigned __int64 *)((char *)v43 + 36), (__m128)*((unsigned __int64 *)v43 + 3)),
                  (__m128)xmmword_108F39940);
          v50 = (float)(*((float *)v43 + 8) + *((float *)v43 + 11)) * 0.5; /*0x104f8b1a3*/
          *(_OWORD *)v296 = 0x3F800000u; /*0x104f8b1a7*/
          *(_OWORD *)v297 = 0x3F800000u; /*0x104f8b1ae*/
          v298 = 1065353216; /*0x104f8b1b5*/
          _mm_storel_ps((double *)&v299, v49); /*0x104f8b1bb*/
          v300 = v50; /*0x104f8b1c2*/
          if ( *((_BYTE *)v43 + 52) == 1 ) /*0x104f8b1ce*/
            v51 = (unsigned __int64 *)RBX::Color3::green(this: v42); /*0x104f8b1d4*/
          else
            v51 = (unsigned __int64 *)RBX::Color3::blue(this: v42); /*0x104f8b2c6*/
          v283 = (__m128)*v51; /*0x104f8b2cf*/
          LODWORD(v284.f64[0]) = *((_DWORD *)v51 + 2); /*0x104f8b2db*/
          if ( *((_BYTE *)v43 + 52) == 1 ) /*0x104f8b2e7*/
            v58 = (unsigned __int64 *)RBX::Color3::yellow(this: v52); /*0x104f8b2e9*/
          else
            v58 = (unsigned __int64 *)RBX::Color3::red(this: v52); /*0x104f8b2f0*/
          v276 = (__m128)*v58; /*0x104f8b2f9*/
          LODWORD(v278) = *((_DWORD *)v58 + 2); /*0x104f8b305*/
          v60 = *((float *)v43 + 5) - *((float *)v43 + 2); /*0x104f8b31e*/
          _mm_storel_ps( /*0x104f8b323*/
            (double *)&v292,
            _mm_sub_ps((__m128)*(unsigned __int64 *)((char *)v43 + 12), (__m128)*(unsigned __int64 *)v43));
          *(float *)&v293 = v60; /*0x104f8b32a*/
          _mm_storel_ps((double *)&v287, v283); /*0x104f8b339*/
          *((_QWORD *)&v287 + 1) = LODWORD(v284.f64[0]) | 0x3F80000000000000LL; /*0x104f8b348*/
          RBX::Draw::selectionBox( /*0x104f8b372*/
            this: (RBX::Draw *)&v304,
            a2: (const RBX::CoordinateFrame *)&v292,
            a3: v45,
            a4: (RBX::Adorn *)&v287,
            a5: v59,
            a6: 0.1);
          v61 = *((float *)v43 + 11) - *((float *)v43 + 8); /*0x104f8b389*/
          _mm_storel_ps( /*0x104f8b38e*/
            (double *)&v292,
            _mm_sub_ps((__m128)*(unsigned __int64 *)((char *)v43 + 36), (__m128)*((unsigned __int64 *)v43 + 3)));
          *(float *)&v293 = v61; /*0x104f8b395*/
          _mm_storel_ps((double *)&v287, v276); /*0x104f8b3a4*/
          *((_QWORD *)&v287 + 1) = LODWORD(v278) | 0x3F80000000000000LL; /*0x104f8b3b3*/
          RBX::Draw::selectionBox( /*0x104f8b3dd*/
            this: (RBX::Draw *)v296,
            a2: (const RBX::CoordinateFrame *)&v292,
            a3: v45,
            a4: (RBX::Adorn *)&v287,
            a5: v62,
            a6: 0.1);
        }
        v43 = (RBX::CoordinateFrame *)((char *)v43 + 56); /*0x104f8b3e2*/
      }
      while ( v43 != v44 ); /*0x104f8b3e9*/
      v43 = v306[0]; /*0x104f8b3ef*/
      v2 = v286; /*0x104f8b3f3*/
    }
    if ( v43 != nullptr ) /*0x104f8b3fd*/
    {
      v306[1] = v43; /*0x104f8b3ff*/
      operator delete(a1: v43); /*0x104f8b406*/
    }
  }
  v63 = DFFlag::DebugDrawBroadPhaseAABBs; /*0x104f8b40b*/
  if ( DFFlag::DebugDrawBroadPhaseAABBs != 0 || RBX::Workspace::showCollisionCosts == 1 ) /*0x104f8b41c*/
  {
    v307 = 0; /*0x104f8b426*/
    *(_OWORD *)v306 = 0; /*0x104f8b42b*/
    v308 = 0; /*0x104f8b430*/
    v64 = *((_QWORD *)v2 + 118); /*0x104f8b438*/
    v65 = *(RBX::Primitive ***)(v64 + 616); /*0x104f8b43f*/
    v66 = *(RBX::Primitive ***)(v64 + 624); /*0x104f8b446*/
    if ( v65 != v66 ) /*0x104f8b450*/
    {
      do /*0x104f8b47e*/
      {
        v304.i64[0] = RBX::Primitive::getAssembly(this: *v65, a2: v23); /*0x104f8b465*/
        RBX::DenseHashSet<RBX::Assembly *,RBX::Hash<RBX::Assembly *>,std::equal_to<RBX::Assembly *>>::insert( /*0x104f8b472*/
          a1: v306,
          a2: (__int64)&v304);
        ++v65; /*0x104f8b477*/
      }
      while ( v65 != v66 ); /*0x104f8b47e*/
      v63 = DFFlag::DebugDrawBroadPhaseAABBs; /*0x104f8b480*/
    }
    if ( (v63 & 1) != 0 ) /*0x104f8b488*/
    {
      RBX::Random::Random(this: (RBX::Random *)&v292, a2: 42); /*0x104f8b49a*/
      v67 = v306[0]; /*0x104f8b49f*/
      v68 = (v306[1] - v306[0]) >> 3; /*0x104f8b4ad*/
      if ( v306[1] == v306[0] ) /*0x104f8b4b4*/
      {
        v69 = nullptr; /*0x104f8b4db*/
      }
      else
      {
        v22 = (v68 == 0) + v68; /*0x104f8b4c1*/
        v69 = nullptr; /*0x104f8b4c5*/
        while ( *((_QWORD *)v306[0] + (_QWORD)v69) == v308 ) /*0x104f8b4cc*/
        {
          v69 = (RBX::Instance *)((char *)v69 + 1); /*0x104f8b4ce*/
          if ( (RBX::Instance *)v22 == v69 ) /*0x104f8b4d4*/
          {
            v69 = (RBX::Instance *)((v68 == 0) + v68); /*0x104f8b4d6*/
            break; /*0x104f8b4d9*/
          }
        }
      }
      if ( v69 != (RBX::Instance *)v68 ) /*0x104f8b4e1*/
      {
        do /*0x104f8b648*/
        {
          v70 = *((_QWORD *)v67 + (_QWORD)v69); /*0x104f8b4f4*/
          RBX::Random::nextNumber(this: (RBX::Random *)&v292, a2: v250); /*0x104f8b4fb*/
          v283.i64[0] = v71; /*0x104f8b500*/
          RBX::Random::nextNumber(this: (RBX::Random *)&v292, a2: v255); /*0x104f8b50b*/
          v284 = (__m128d)v72; /*0x104f8b510*/
          RBX::Random::nextNumber(this: (RBX::Random *)&v292, a2: v256); /*0x104f8b51b*/
          v74 = *(_QWORD *)(v70 + 184); /*0x104f8b520*/
          if ( v74 != 0 && *(_BYTE *)(v74 + 75) == 1 ) /*0x104f8b535*/
          {
            v75 = *(double *)v283.i64; /*0x104f8b53b*/
            v76 = v284.f64[0]; /*0x104f8b54f*/
            v77 = *(float *)(v74 + 56); /*0x104f8b553*/
            v78 = *(float *)(v74 + 68); /*0x104f8b558*/
            v79 = (__m128)*(unsigned __int64 *)(v74 + 48); /*0x104f8b564*/
            v80 = (__m128)*(unsigned __int64 *)(v74 + 60); /*0x104f8b569*/
            v304.i128[0] = 0x3F800000u; /*0x104f8b58c*/
            v304.i128[1] = 0x3F800000u; /*0x104f8b594*/
            LODWORD(v305[0]) = 1065353216; /*0x104f8b59c*/
            _mm_storel_ps((double *)((char *)v305 + 4), _mm_mul_ps(_mm_add_ps(v79, v80), (__m128)xmmword_108F39940)); /*0x104f8b5a3*/
            *((float *)&v305[1] + 1) = (float)(v77 + v78) * 0.5; /*0x104f8b5aa*/
            _mm_storel_ps((double *)&v287, _mm_sub_ps(v80, v79)); /*0x104f8b5b9*/
            *((float *)&v287 + 2) = v78 - v77; /*0x104f8b5c0*/
            *(float *)v296 = v75; /*0x104f8b5c8*/
            *(double *)((char *)v296 + 4) = v76; /*0x104f8b5d0*/
            HIDWORD(v296[1]) = 1065353216; /*0x104f8b5d8*/
            RBX::Draw::selectionBox( /*0x104f8b603*/
              this: (RBX::Draw *)&v304,
              a2: (const RBX::CoordinateFrame *)&v287,
              a3: v295,
              a4: (RBX::Adorn *)v296,
              a5: v73,
              a6: 0.1);
          }
          v67 = v306[0]; /*0x104f8b608*/
          v81 = (v306[1] - v306[0]) >> 3; /*0x104f8b613*/
          if ( v81 <= (unsigned __int64)v69 + 1 ) /*0x104f8b61e*/
            v81 = (unsigned __int64)v69 + 1; /*0x104f8b61e*/
          v22 = v308; /*0x104f8b622*/
          v23 = (RBX::Instance *)(v81 - 1); /*0x104f8b626*/
          while ( v23 != v69 ) /*0x104f8b62d*/
          {
            v82 = (unsigned __int64)v69 + 1; /*0x104f8b62f*/
            v38 = *((_QWORD *)v306[0] + (_QWORD)v69 + 1) == v308; /*0x104f8b633*/
            v69 = (RBX::Instance *)((char *)v69 + 1); /*0x104f8b638*/
            if ( !v38 ) /*0x104f8b63b*/
              goto LABEL_73; /*0x104f8b63b*/
          }
          v82 = v81; /*0x104f8b63f*/
LABEL_73:
          v69 = (RBX::Instance *)v82; /*0x104f8b642*/
        }
        while ( v82 != v68 ); /*0x104f8b648*/
      }
      v2 = v286; /*0x104f8b64e*/
    }
    if ( RBX::Workspace::showCollisionCosts == 1 ) /*0x104f8b65c*/
    {
      v83 = *(_QWORD *)(*((_QWORD *)v2 + 118) + 2056LL); /*0x104f8b669*/
      v84 = *(double *)(v83 + 32); /*0x104f8b670*/
      v85 = *(double *)(v83 + 40); /*0x104f8b675*/
      v283.i64[0] = *(_QWORD *)(v83 + 112); /*0x104f8b67f*/
      v277 = *(double *)(v83 + 120); /*0x104f8b68c*/
      v284.f64[0] = *(double *)(v83 + 152); /*0x104f8b69c*/
      v267 = *(double *)(v83 + 160); /*0x104f8b6ac*/
      v276.i64[0] = *(_QWORD *)(v83 + 192); /*0x104f8b6bc*/
      v268 = *(double *)(v83 + 200); /*0x104f8b6cc*/
      v278 = *(double *)(v83 + 232); /*0x104f8b6dc*/
      v269 = *(double *)(v83 + 240); /*0x104f8b6ec*/
      v274 = *(double *)(v83 + 272); /*0x104f8b6fc*/
      v270 = *(double *)(v83 + 280); /*0x104f8b70c*/
      v275 = *(double *)(v83 + 312); /*0x104f8b71c*/
      v271 = *(double *)(v83 + 320); /*0x104f8b72c*/
      v86 = *(double *)(v83 + 72); /*0x104f8b734*/
      v272 = v84; /*0x104f8b739*/
      v265 = v86 + v84; /*0x104f8b745*/
      v87 = *(double *)(v83 + 80); /*0x104f8b74d*/
      v264 = v85; /*0x104f8b752*/
      v266 = v87 + v85; /*0x104f8b75e*/
      RBX::TextLayout::TextLayout(this: (RBX::TextLayout *)&v304, a2: (__int64)v23, a3: v22); /*0x104f8b76d*/
      v296[0] = v272; /*0x104f8b781*/
      v297[0] = v264; /*0x104f8b78d*/
      fmt::v8::vformat(a1: &v287, a2: "BallBall {:.1f} ms,{:.0f} count", 31, 170, v296); /*0x104f8b7ad*/
      *(_QWORD *)&v282 = 0x4376000041200000LL; /*0x104f8b7ba*/
      if ( v272 >= 5.0 ) /*0x104f8b7d2*/
        v89 = RBX::Color3::yellow(this: v88); /*0x104f8b7db*/
      else
        v89 = RBX::Color3::green(this: v88); /*0x104f8b7d4*/
      v292 = *(_QWORD *)v89; /*0x104f8b7e4*/
      LODWORD(v293) = *(_DWORD *)(v89 + 8); /*0x104f8b7f1*/
      HIDWORD(v293) = 1065353216; /*0x104f8b7f9*/
      v91 = RBX::Color3::black(this: v90); /*0x104f8b803*/
      v279 = *(_QWORD *)v91; /*0x104f8b813*/
      v280 = *(float *)(v91 + 8); /*0x104f8b81d*/
      v281 = 1065353216; /*0x104f8b823*/
      AssemblyPrimitive = 0; /*0x104f8b834*/
      v273 = xmmword_108F4A5E0; /*0x104f8b845*/
      v296[0] = 0.0; /*0x104f8b849*/
      _mm_storel_ps(&v296[1], (__m128)0x3F800000u); /*0x104f8b858*/
      LODWORD(v297[0]) = 0; /*0x104f8b85f*/
      RBX::TextLayout::setPropsForLegacyAdornDraw2DTextCall( /*0x104f8b8ac*/
        a1: (__int64)&v304,
        a2: (unsigned __int8 *)&v287,
        a3: (unsigned __int64 *)&v282,
        a4: 1,
        a5: (unsigned __int64 *)&v292,
        a6: &v279,
        a7: 8.0,
        a8: 0,
        a9: 1,
        a10: 0,
        a11: (unsigned __int64 *)&AssemblyPrimitive,
        a12: (__int64)&v273,
        a13: (__int64)v296,
        a14: 1);
      if ( (v287 & 1) != 0 ) /*0x104f8b8b8*/
        operator delete(a1: v288[0]); /*0x104f8b8c1*/
      RBX::Adorn::drawFont2D(this: v295, a2: (RBX::TextLayout *)&v304); /*0x104f8b8d4*/
      v296[0] = *(double *)v283.i64; /*0x104f8b8e1*/
      v297[0] = v277; /*0x104f8b8ed*/
      fmt::v8::vformat(a1: &v287, a2: "ballPoly {:.1f} ms,{:.0f} count", 31, 170, v296); /*0x104f8b90d*/
      *(_QWORD *)&v282 = 0x4385000041200000LL; /*0x104f8b91a*/
      if ( *(double *)v283.i64 >= 5.0 ) /*0x104f8b932*/
        v93 = RBX::Color3::yellow(this: v92); /*0x104f8b93b*/
      else
        v93 = RBX::Color3::green(this: v92); /*0x104f8b934*/
      v292 = *(_QWORD *)v93; /*0x104f8b944*/
      LODWORD(v293) = *(_DWORD *)(v93 + 8); /*0x104f8b951*/
      HIDWORD(v293) = 1065353216; /*0x104f8b959*/
      v95 = RBX::Color3::black(this: v94); /*0x104f8b963*/
      v279 = *(_QWORD *)v95; /*0x104f8b973*/
      v280 = *(float *)(v95 + 8); /*0x104f8b97d*/
      v281 = 1065353216; /*0x104f8b983*/
      AssemblyPrimitive = 0; /*0x104f8b98d*/
      v273 = xmmword_108F4A5E0; /*0x104f8b99b*/
      v296[0] = 0.0; /*0x104f8b9a2*/
      _mm_storel_ps(&v296[1], (__m128)0x3F800000u); /*0x104f8b9b1*/
      LODWORD(v297[0]) = 0; /*0x104f8b9b8*/
      RBX::TextLayout::setPropsForLegacyAdornDraw2DTextCall( /*0x104f8ba05*/
        a1: (__int64)&v304,
        a2: (unsigned __int8 *)&v287,
        a3: (unsigned __int64 *)&v282,
        a4: 1,
        a5: (unsigned __int64 *)&v292,
        a6: &v279,
        a7: 8.0,
        a8: 0,
        a9: 1,
        a10: 0,
        a11: (unsigned __int64 *)&AssemblyPrimitive,
        a12: (__int64)&v273,
        a13: (__int64)v296,
        a14: 1);
      if ( (v287 & 1) != 0 ) /*0x104f8ba11*/
        operator delete(a1: v288[0]); /*0x104f8ba1a*/
      RBX::Adorn::drawFont2D(this: v295, a2: (RBX::TextLayout *)&v304); /*0x104f8ba2d*/
      v296[0] = v284.f64[0]; /*0x104f8ba3a*/
      v297[0] = v267; /*0x104f8ba46*/
      fmt::v8::vformat(a1: &v287, a2: "bulletCell {:.1f} ms,{:.0f} count", 33, 170, v296); /*0x104f8ba66*/
      *(_QWORD *)&v282 = 0x438F000041200000LL; /*0x104f8ba73*/
      if ( v284.f64[0] >= 5.0 ) /*0x104f8ba8b*/
        v97 = RBX::Color3::yellow(this: v96); /*0x104f8ba94*/
      else
        v97 = RBX::Color3::green(this: v96); /*0x104f8ba8d*/
      v292 = *(_QWORD *)v97; /*0x104f8ba9d*/
      LODWORD(v293) = *(_DWORD *)(v97 + 8); /*0x104f8baaa*/
      HIDWORD(v293) = 1065353216; /*0x104f8bab2*/
      v99 = RBX::Color3::black(this: v98); /*0x104f8babc*/
      v279 = *(_QWORD *)v99; /*0x104f8bacc*/
      v280 = *(float *)(v99 + 8); /*0x104f8bad6*/
      v281 = 1065353216; /*0x104f8badc*/
      AssemblyPrimitive = 0; /*0x104f8bae6*/
      v273 = xmmword_108F4A5E0; /*0x104f8baf4*/
      v296[0] = 0.0; /*0x104f8bafb*/
      _mm_storel_ps(&v296[1], (__m128)0x3F800000u); /*0x104f8bb0a*/
      LODWORD(v297[0]) = 0; /*0x104f8bb11*/
      RBX::TextLayout::setPropsForLegacyAdornDraw2DTextCall( /*0x104f8bb5e*/
        a1: (__int64)&v304,
        a2: (unsigned __int8 *)&v287,
        a3: (unsigned __int64 *)&v282,
        a4: 1,
        a5: (unsigned __int64 *)&v292,
        a6: &v279,
        a7: 8.0,
        a8: 0,
        a9: 1,
        a10: 0,
        a11: (unsigned __int64 *)&AssemblyPrimitive,
        a12: (__int64)&v273,
        a13: (__int64)v296,
        a14: 1);
      if ( (v287 & 1) != 0 ) /*0x104f8bb6a*/
        operator delete(a1: v288[0]); /*0x104f8bb73*/
      RBX::Adorn::drawFont2D(this: v295, a2: (RBX::TextLayout *)&v304); /*0x104f8bb86*/
      v296[0] = *(double *)v276.i64; /*0x104f8bb93*/
      v297[0] = v268; /*0x104f8bb9f*/
      fmt::v8::vformat(a1: &v287, a2: "bullet {:.1f} ms,{:.0f} count", 29, 170, v296); /*0x104f8bbbf*/
      *(_QWORD *)&v282 = 0x4399000041200000LL; /*0x104f8bbcc*/
      if ( *(double *)v276.i64 >= 5.0 ) /*0x104f8bbe4*/
        v101 = RBX::Color3::yellow(this: v100); /*0x104f8bbed*/
      else
        v101 = RBX::Color3::green(this: v100); /*0x104f8bbe6*/
      v292 = *(_QWORD *)v101; /*0x104f8bbf6*/
      LODWORD(v293) = *(_DWORD *)(v101 + 8); /*0x104f8bc03*/
      HIDWORD(v293) = 1065353216; /*0x104f8bc0b*/
      v103 = RBX::Color3::black(this: v102); /*0x104f8bc15*/
      v279 = *(_QWORD *)v103; /*0x104f8bc25*/
      v280 = *(float *)(v103 + 8); /*0x104f8bc2f*/
      v281 = 1065353216; /*0x104f8bc35*/
      AssemblyPrimitive = 0; /*0x104f8bc3f*/
      v273 = xmmword_108F4A5E0; /*0x104f8bc4d*/
      v296[0] = 0.0; /*0x104f8bc54*/
      _mm_storel_ps(&v296[1], (__m128)0x3F800000u); /*0x104f8bc63*/
      LODWORD(v297[0]) = 0; /*0x104f8bc6a*/
      RBX::TextLayout::setPropsForLegacyAdornDraw2DTextCall( /*0x104f8bcb7*/
        a1: (__int64)&v304,
        a2: (unsigned __int8 *)&v287,
        a3: (unsigned __int64 *)&v282,
        a4: 1,
        a5: (unsigned __int64 *)&v292,
        a6: &v279,
        a7: 8.0,
        a8: 0,
        a9: 1,
        a10: 0,
        a11: (unsigned __int64 *)&AssemblyPrimitive,
        a12: (__int64)&v273,
        a13: (__int64)v296,
        a14: 1);
      if ( (v287 & 1) != 0 ) /*0x104f8bcc3*/
        operator delete(a1: v288[0]); /*0x104f8bccc*/
      RBX::Adorn::drawFont2D(this: v295, a2: (RBX::TextLayout *)&v304); /*0x104f8bcdf*/
      v296[0] = v278; /*0x104f8bcec*/
      v297[0] = v269; /*0x104f8bcf8*/
      fmt::v8::vformat(a1: &v287, a2: "buoyancy {:.1f} ms,{:.0f} count", 31, 170, v296); /*0x104f8bd18*/
      *(_QWORD *)&v282 = 0x43A3000041200000LL; /*0x104f8bd25*/
      if ( v278 >= 5.0 ) /*0x104f8bd3d*/
        v105 = RBX::Color3::yellow(this: v104); /*0x104f8bd46*/
      else
        v105 = RBX::Color3::green(this: v104); /*0x104f8bd3f*/
      v292 = *(_QWORD *)v105; /*0x104f8bd4f*/
      LODWORD(v293) = *(_DWORD *)(v105 + 8); /*0x104f8bd5c*/
      HIDWORD(v293) = 1065353216; /*0x104f8bd64*/
      v107 = RBX::Color3::black(this: v106); /*0x104f8bd6e*/
      v279 = *(_QWORD *)v107; /*0x104f8bd7e*/
      v280 = *(float *)(v107 + 8); /*0x104f8bd88*/
      v281 = 1065353216; /*0x104f8bd8e*/
      AssemblyPrimitive = 0; /*0x104f8bd98*/
      v273 = xmmword_108F4A5E0; /*0x104f8bda6*/
      v296[0] = 0.0; /*0x104f8bdad*/
      _mm_storel_ps(&v296[1], (__m128)0x3F800000u); /*0x104f8bdbc*/
      LODWORD(v297[0]) = 0; /*0x104f8bdc3*/
      RBX::TextLayout::setPropsForLegacyAdornDraw2DTextCall( /*0x104f8be10*/
        a1: (__int64)&v304,
        a2: (unsigned __int8 *)&v287,
        a3: (unsigned __int64 *)&v282,
        a4: 1,
        a5: (unsigned __int64 *)&v292,
        a6: &v279,
        a7: 8.0,
        a8: 0,
        a9: 1,
        a10: 0,
        a11: (unsigned __int64 *)&AssemblyPrimitive,
        a12: (__int64)&v273,
        a13: (__int64)v296,
        a14: 1);
      if ( (v287 & 1) != 0 ) /*0x104f8be1c*/
        operator delete(a1: v288[0]); /*0x104f8be25*/
      RBX::Adorn::drawFont2D(this: v295, a2: (RBX::TextLayout *)&v304); /*0x104f8be38*/
      v296[0] = v274; /*0x104f8be45*/
      v297[0] = v270; /*0x104f8be51*/
      fmt::v8::vformat(a1: &v287, a2: "blockBlock {:.1f} ms,{:.0f} count", 33, 170, v296); /*0x104f8be71*/
      *(_QWORD *)&v282 = 0x43AD000041200000LL; /*0x104f8be7e*/
      if ( v274 >= 5.0 ) /*0x104f8be96*/
        v109 = RBX::Color3::yellow(this: v108); /*0x104f8be9f*/
      else
        v109 = RBX::Color3::green(this: v108); /*0x104f8be98*/
      v292 = *(_QWORD *)v109; /*0x104f8bea8*/
      LODWORD(v293) = *(_DWORD *)(v109 + 8); /*0x104f8beb5*/
      HIDWORD(v293) = 1065353216; /*0x104f8bebd*/
      v111 = RBX::Color3::black(this: v110); /*0x104f8bec7*/
      v279 = *(_QWORD *)v111; /*0x104f8bed7*/
      v280 = *(float *)(v111 + 8); /*0x104f8bee1*/
      v281 = 1065353216; /*0x104f8bee7*/
      AssemblyPrimitive = 0; /*0x104f8bef1*/
      v273 = xmmword_108F4A5E0; /*0x104f8beff*/
      v296[0] = 0.0; /*0x104f8bf06*/
      _mm_storel_ps(&v296[1], (__m128)0x3F800000u); /*0x104f8bf15*/
      LODWORD(v297[0]) = 0; /*0x104f8bf1c*/
      RBX::TextLayout::setPropsForLegacyAdornDraw2DTextCall( /*0x104f8bf69*/
        a1: (__int64)&v304,
        a2: (unsigned __int8 *)&v287,
        a3: (unsigned __int64 *)&v282,
        a4: 1,
        a5: (unsigned __int64 *)&v292,
        a6: &v279,
        a7: 8.0,
        a8: 0,
        a9: 1,
        a10: 0,
        a11: (unsigned __int64 *)&AssemblyPrimitive,
        a12: (__int64)&v273,
        a13: (__int64)v296,
        a14: 1);
      if ( (v287 & 1) != 0 ) /*0x104f8bf75*/
        operator delete(a1: v288[0]); /*0x104f8bf7e*/
      RBX::Adorn::drawFont2D(this: v295, a2: (RBX::TextLayout *)&v304); /*0x104f8bf91*/
      v296[0] = v275; /*0x104f8bf9e*/
      v297[0] = v271; /*0x104f8bfaa*/
      fmt::v8::vformat(a1: &v287, a2: "polyPoly {:.1f} ms,{:.0f} count", 31, 170, v296); /*0x104f8bfca*/
      *(_QWORD *)&v282 = 0x43B7000041200000LL; /*0x104f8bfd7*/
      if ( v275 >= 5.0 ) /*0x104f8bfef*/
        v113 = RBX::Color3::yellow(this: v112); /*0x104f8bff8*/
      else
        v113 = RBX::Color3::green(this: v112); /*0x104f8bff1*/
      v292 = *(_QWORD *)v113; /*0x104f8c001*/
      LODWORD(v293) = *(_DWORD *)(v113 + 8); /*0x104f8c00e*/
      HIDWORD(v293) = 1065353216; /*0x104f8c016*/
      v115 = RBX::Color3::black(this: v114); /*0x104f8c020*/
      v279 = *(_QWORD *)v115; /*0x104f8c030*/
      v280 = *(float *)(v115 + 8); /*0x104f8c03a*/
      v281 = 1065353216; /*0x104f8c040*/
      AssemblyPrimitive = 0; /*0x104f8c04a*/
      v273 = xmmword_108F4A5E0; /*0x104f8c058*/
      v296[0] = 0.0; /*0x104f8c05f*/
      _mm_storel_ps(&v296[1], (__m128)0x3F800000u); /*0x104f8c06e*/
      LODWORD(v297[0]) = 0; /*0x104f8c075*/
      RBX::TextLayout::setPropsForLegacyAdornDraw2DTextCall( /*0x104f8c0c2*/
        a1: (__int64)&v304,
        a2: (unsigned __int8 *)&v287,
        a3: (unsigned __int64 *)&v282,
        a4: 1,
        a5: (unsigned __int64 *)&v292,
        a6: &v279,
        a7: 8.0,
        a8: 0,
        a9: 1,
        a10: 0,
        a11: (unsigned __int64 *)&AssemblyPrimitive,
        a12: (__int64)&v273,
        a13: (__int64)v296,
        a14: 1);
      if ( (v287 & 1) != 0 ) /*0x104f8c0ce*/
        operator delete(a1: v288[0]); /*0x104f8c0d7*/
      RBX::Adorn::drawFont2D(this: v295, a2: (RBX::TextLayout *)&v304); /*0x104f8c0ea*/
      v296[0] = v265 + *(double *)v283.i64 + v284.f64[0] + *(double *)v276.i64 + v278 + v274 + v275; /*0x104f8c15f*/
      v297[0] = v266 + v277 + v267 + v268 + v269 + v270 + v271; /*0x104f8c163*/
      fmt::v8::vformat(a1: &v287, a2: "All collisions {:.1f} ms, {:.0f} count", 38, 170, v296); /*0x104f8c183*/
      *(_QWORD *)&v282 = 0x4362000041200000LL; /*0x104f8c190*/
      v117 = RBX::Color3::green(this: v116); /*0x104f8c198*/
      v292 = *(_QWORD *)v117; /*0x104f8c1a1*/
      LODWORD(v293) = *(_DWORD *)(v117 + 8); /*0x104f8c1ae*/
      HIDWORD(v293) = 1065353216; /*0x104f8c1b6*/
      v119 = RBX::Color3::black(this: v118); /*0x104f8c1c0*/
      v279 = *(_QWORD *)v119; /*0x104f8c1d0*/
      v280 = *(float *)(v119 + 8); /*0x104f8c1da*/
      v281 = 1065353216; /*0x104f8c1e0*/
      AssemblyPrimitive = 0; /*0x104f8c1ea*/
      v273 = xmmword_108F4A5E0; /*0x104f8c1f8*/
      v296[0] = 0.0; /*0x104f8c1ff*/
      _mm_storel_ps(&v296[1], (__m128)0x3F800000u); /*0x104f8c20e*/
      LODWORD(v297[0]) = 0; /*0x104f8c215*/
      RBX::TextLayout::setPropsForLegacyAdornDraw2DTextCall( /*0x104f8c262*/
        a1: (__int64)&v304,
        a2: (unsigned __int8 *)&v287,
        a3: (unsigned __int64 *)&v282,
        a4: 1,
        a5: (unsigned __int64 *)&v292,
        a6: &v279,
        a7: 8.0,
        a8: 0,
        a9: 1,
        a10: 0,
        a11: (unsigned __int64 *)&AssemblyPrimitive,
        a12: (__int64)&v273,
        a13: (__int64)v296,
        a14: 1);
      if ( (v287 & 1) != 0 ) /*0x104f8c26e*/
        operator delete(a1: v288[0]); /*0x104f8c277*/
      RBX::Adorn::drawFont2D(this: v295, a2: (RBX::TextLayout *)&v304); /*0x104f8c28a*/
      RBX::Collision::Narrowphase::ContactStats::reset(this: (RBX::Collision::Narrowphase::ContactStats *)(*(_QWORD *)(*((_QWORD *)v2 + 118) + 2056LL) + 24LL)); /*0x104f8c2a1*/
      LODWORD(v296[0]) = 0; /*0x104f8c2a6*/
      v121 = RBX::Color3::green(this: v120); /*0x104f8c2b0*/
      HIDWORD(v296[1]) = *(_DWORD *)(v121 + 8); /*0x104f8c2b8*/
      *(double *)((char *)v296 + 4) = *(double *)v121; /*0x104f8c2c1*/
      LODWORD(v297[0]) = 1120403456; /*0x104f8c2c8*/
      v123 = RBX::Color3::green(this: v122); /*0x104f8c2d2*/
      HIDWORD(v297[1]) = *(_DWORD *)(v123 + 8); /*0x104f8c2da*/
      *(double *)((char *)v297 + 4) = *(double *)v123; /*0x104f8c2e3*/
      v298 = 1145569280; /*0x104f8c2ea*/
      v125 = RBX::Color3::yellow(this: v124); /*0x104f8c2f4*/
      v300 = *(float *)(v125 + 8); /*0x104f8c2fc*/
      v299 = *(_QWORD *)v125; /*0x104f8c305*/
      v301 = 1169915904; /*0x104f8c30c*/
      v127 = RBX::Color3::red(this: v126); /*0x104f8c316*/
      v303 = *(_DWORD *)(v127 + 8); /*0x104f8c325*/
      v302 = *(_QWORD *)v127; /*0x104f8c32b*/
      v129 = v306[0]; /*0x104f8c32e*/
      v130 = (v306[1] - v306[0]) >> 3; /*0x104f8c33c*/
      if ( v306[1] == v306[0] ) /*0x104f8c343*/
      {
        v131 = 0; /*0x104f8c36a*/
      }
      else
      {
        v131 = 0; /*0x104f8c354*/
        while ( *((_QWORD *)v306[0] + v131) == v308 ) /*0x104f8c35b*/
        {
          if ( (v130 == 0) + v130 == ++v131 ) /*0x104f8c363*/
          {
            v131 = (v130 == 0) + v130; /*0x104f8c365*/
            break; /*0x104f8c368*/
          }
        }
      }
      if ( v131 != v130 ) /*0x104f8c370*/
      {
        v284 = (__m128d)v302; /*0x104f8c37e*/
        v276.i32[0] = v303; /*0x104f8c38d*/
        v132 = *(float *)&RBX::Assembly::s_collisionCostQuantizer; /*0x104f8c39c*/
        v133 = (__m128)0x43FA0000u; /*0x104f8c3a8*/
        v134.i32[0] = 1128792064; /*0x104f8c3dc*/
        v135 = *(__m128 *)&xmmword_108F246C0; /*0x104f8c3e5*/
        v136 = (__m128)xmmword_108F51160; /*0x104f8c3ed*/
        do /*0x104f8c687*/
        {
          v137 = *((_QWORD *)v129 + v131); /*0x104f8c3f4*/
          v138 = 0; /*0x104f8c400*/
          v138.f32[0] = (float)((float)*(unsigned __int16 *)(v137 + 340) /*0x104f8c40f*/
                              * *((float *)&RBX::Assembly::s_collisionCostQuantizer + 1))
                      + v132;
          if ( v138.f32[0] > 40.0 ) /*0x104f8c418*/
          {
            v139 = v138; /*0x104f8c41e*/
            v139.f32[0] = v138.f32[0] / 1000.0; /*0x104f8c422*/
            v140 = _mm_cmplt_ss(v133, v138); /*0x104f8c42e*/
            v141 = _mm_andnot_ps(v140, v139).u32[0] | v140.i32[0] & 0x3F000000; /*0x104f8c43e*/
            v142 = 0; /*0x104f8c441*/
            while ( 1 ) /*0x104f8c443*/
            {
              v143 = *(float *)&v297[v142]; /*0x104f8c443*/
              if ( v143 > v138.f32[0] ) /*0x104f8c450*/
                break; /*0x104f8c450*/
              v142 += 2; /*0x104f8c452*/
              if ( v142 == 6 ) /*0x104f8c45a*/
              {
                v144 = (__m128)v284; /*0x104f8c45c*/
                v145 = v276.f32[0]; /*0x104f8c463*/
                goto LABEL_127; /*0x104f8c46b*/
              }
            }
            v146 = v138; /*0x104f8c476*/
            v146.f32[0] = (float)(v138.f32[0] - *(float *)&v296[v142]) / (float)(v143 - *(float *)&v296[v142]); /*0x104f8c482*/
            v147 = *((float *)&v296[v142 + 1] + 1); /*0x104f8c48f*/
            v148 = (float)(*((float *)&v297[v142 + 1] + 1) - v147) * v146.f32[0]; /*0x104f8c49c*/
            v149 = _mm_moveldup_ps(v146); /*0x104f8c4b5*/
            v136 = (__m128)xmmword_108F51160; /*0x104f8c4b9*/
            v144 = _mm_add_ps( /*0x104f8c4c3*/
                     _mm_mul_ps(
                       v149,
                       _mm_sub_ps(
                         (__m128)*(unsigned __int64 *)((char *)&v297[v142] + 4),
                         (__m128)*(unsigned __int64 *)((char *)&v296[v142] + 4))),
                     (__m128)*(unsigned __int64 *)((char *)&v296[v142] + 4));
            v145 = v148 + v147; /*0x104f8c4c6*/
LABEL_127:
            v150 = *(_QWORD *)(v137 + 184); /*0x104f8c4ca*/
            if ( v150 != 0 && *(_BYTE *)(v150 + 75) == 1 ) /*0x104f8c4de*/
            {
              v283 = v138; /*0x104f8c4e4*/
              v151 = *(float *)(v150 + 56); /*0x104f8c4ec*/
              v152 = *(float *)(v150 + 68); /*0x104f8c4f1*/
              v153 = (__m128)*(unsigned __int64 *)(v150 + 48); /*0x104f8c4fd*/
              v154 = (__m128)*(unsigned __int64 *)(v150 + 60); /*0x104f8c502*/
              v287 = 0x3F800000u; /*0x104f8c525*/
              *(_OWORD *)v288 = 0x3F800000u; /*0x104f8c52d*/
              v289 = 1065353216; /*0x104f8c535*/
              _mm_storel_ps((double *)&v290, _mm_mul_ps(_mm_add_ps(v153, v154), (__m128)xmmword_108F39940)); /*0x104f8c53f*/
              v291 = (float)(v151 + v152) * 0.5; /*0x104f8c547*/
              _mm_storel_ps((double *)&v279, _mm_sub_ps(v154, v153)); /*0x104f8c556*/
              v280 = v152 - v151; /*0x104f8c55d*/
              _mm_storel_ps((double *)&v292, v144); /*0x104f8c565*/
              v293 = __PAIR64__(v141, LODWORD(v145)); /*0x104f8c56c*/
              RBX::Draw::selectionBox( /*0x104f8c59c*/
                this: (RBX::Draw *)&v287,
                a2: (const RBX::CoordinateFrame *)&v279,
                a3: v295,
                a4: (RBX::Adorn *)&v292,
                a5: v128,
                a6: 0.30000001);
              v133 = (__m128)0x43FA0000u; /*0x104f8c5a9*/
              v134.i32[0] = 1128792064; /*0x104f8c5d6*/
              v135 = *(__m128 *)&xmmword_108F246C0; /*0x104f8c5df*/
              v136 = (__m128)xmmword_108F51160; /*0x104f8c5e7*/
              v138 = v283; /*0x104f8c5ee*/
            }
          }
          if ( v138.f32[0] >= 800.0 ) /*0x104f8c5fa*/
          {
            v138.f32[0] = v138.f32[0] * 0.5; /*0x104f8c611*/
          }
          else
          {
            v155 = v138; /*0x104f8c5fc*/
            v155.f32[0] = v138.f32[0] + -200.0; /*0x104f8c600*/
            v138 = _mm_andnot_ps(_mm_cmplt_ss(v138, v134), v155); /*0x104f8c60b*/
          }
          v132 = *(float *)&RBX::Assembly::s_collisionCostQuantizer; /*0x104f8c616*/
          v138.f32[0] = (float)(v138.f32[0] - *(float *)&RBX::Assembly::s_collisionCostQuantizer) /*0x104f8c61f*/
                      * *(float *)&dword_10D4FCFC8;
          v156 = _mm_or_ps(_mm_and_ps(v138, v135), v136); /*0x104f8c62d*/
          v156.f32[0] = v156.f32[0] + v138.f32[0]; /*0x104f8c630*/
          *(_WORD *)(v137 + 340) = (int)_mm_round_ss(v156, v156, 11).f32[0]; /*0x104f8c63f*/
          v129 = v306[0]; /*0x104f8c647*/
          v157 = (v306[1] - v306[0]) >> 3; /*0x104f8c652*/
          if ( v157 <= v131 + 1 ) /*0x104f8c65d*/
            v157 = v131 + 1; /*0x104f8c65d*/
          while ( v157 - 1 != v131 ) /*0x104f8c66c*/
          {
            v158 = v131 + 1; /*0x104f8c66e*/
            v38 = *((_QWORD *)v306[0] + ++v131) == v308; /*0x104f8c672*/
            if ( !v38 ) /*0x104f8c67a*/
              goto LABEL_139; /*0x104f8c67a*/
          }
          v158 = v157; /*0x104f8c67e*/
LABEL_139:
          v131 = v158; /*0x104f8c681*/
        }
        while ( v158 != v130 ); /*0x104f8c687*/
      }
      RBX::TextLayout::~TextLayout(this: (void **)&v304); /*0x104f8c694*/
      v2 = v286; /*0x104f8c699*/
    }
    if ( v306[0] != nullptr ) /*0x104f8c6a7*/
    {
      v306[1] = v306[0]; /*0x104f8c6a9*/
      operator delete(a1: v306[0]); /*0x104f8c6ad*/
    }
  }
  if ( DFFlag::DebugEnabledConvexDecompDebug == 1 ) /*0x104f8c6bc*/
  {
    v159 = *((RBX::DecompDebugVisualizer **)v2 + 239); /*0x104f8c6be*/
    if ( v159 != nullptr ) /*0x104f8c6c8*/
      RBX::DecompDebugVisualizer::renderCurrentDebugData(this: v159, a2: v295); /*0x104f8c6d1*/
  }
  if ( FFlag::UseAdornBasedCDDebugVis == 1 ) /*0x104f8c6dd*/
  {
    v160 = *((RBX::Physics::ConvexDecompVisualizer **)v2 + 240); /*0x104f8c6e3*/
    if ( v160 != nullptr ) /*0x104f8c6ed*/
    {
      RBX::Physics::ConvexDecompVisualizer::startFrame(this: v160, a2: v2); /*0x104f8c6f6*/
      if ( RBX::PartOperation::renderCollisionData == 1 ) /*0x104f8c705*/
      {
        v161 = *((_QWORD *)v2 + 118); /*0x104f8c707*/
        v162 = *(_QWORD *)(v161 + 616); /*0x104f8c70e*/
        v163 = *(_QWORD *)(v161 + 624); /*0x104f8c715*/
        while ( v162 != v163 ) /*0x104f8c71f*/
        {
          v164 = *(const RBX::TriangleMeshPart **)(*(_QWORD *)v162 + 528LL); /*0x104f8c724*/
          if ( v164 != nullptr ) /*0x104f8c72e*/
          {
            v165 = *((_QWORD *)v164 + 3); /*0x104f8c730*/
            v166 = RBX::Reflection::Class_getDescriptorPtr<RBX::TriangleMeshPart>(); /*0x104f8c734*/
            if ( *(unsigned __int16 *)(v165 + 440) - (unsigned int)*(unsigned __int16 *)(v166 + 440) <= *(unsigned __int16 *)(v166 + 442) /*0x104f8c760*/
              && (unsigned __int8)RBX::Physics::ConvexDecompVisualizer::shouldPartDecompBeShown(this: v164, a2: v167) != 0 )
            {
              RBX::Physics::ConvexDecompVisualizer::renderPartDecomposition( /*0x104f8c773*/
                this: *((RBX::Physics::ConvexDecompVisualizer **)v2 + 240),
                a2: v164,
                a3: v295);
            }
          }
          v162 += 8; /*0x104f8c778*/
        }
      }
      RBX::Physics::ConvexDecompVisualizer::finishFrame(this: *((RBX::Physics::ConvexDecompVisualizer **)v2 + 240)); /*0x104f8c785*/
    }
  }
  if ( RBX::Workspace::showTerrainPhysicsStreamOut == 1 ) /*0x104f8c791*/
  {
    v168 = *(_QWORD **)(*((_QWORD *)v286 + 118) + 2056LL); /*0x104f8c7a5*/
    v169 = (RBX::Voxel2::Region *)v168[71]; /*0x104f8c7ac*/
    v170 = (RBX::Voxel2::Region *)v168[72]; /*0x104f8c7b3*/
    if ( v169 != v170 ) /*0x104f8c7bd*/
    {
      do /*0x104f8c8d1*/
      {
        v306[0] = nullptr; /*0x104f8c7d4*/
        LODWORD(v306[1]) = 0; /*0x104f8c7d8*/
        *(_QWORD *)&v287 = 0; /*0x104f8c7dc*/
        DWORD2(v287) = 0; /*0x104f8c7e3*/
        RBX::Voxel2::Region::toExtents(this: v169, a2: (RBX::Vector3 *)v306, a3: (RBX::Vector3 *)&v287, a4: 4); /*0x104f8c7fd*/
        v171 = *(float *)&v306[1]; /*0x104f8c802*/
        v172 = *((float *)&v287 + 2); /*0x104f8c807*/
        v173 = (__m128)(unsigned __int64)v306[0]; /*0x104f8c816*/
        v174 = (__m128)(unsigned __int64)v287; /*0x104f8c81b*/
        v175 = (float)(*(float *)&v306[1] + *((float *)&v287 + 2)) * 0.5; /*0x104f8c838*/
        v304.i128[0] = 0x3F800000u; /*0x104f8c844*/
        v304.i128[1] = 0x3F800000u; /*0x104f8c84b*/
        LODWORD(v305[0]) = 1065353216; /*0x104f8c852*/
        _mm_storel_ps( /*0x104f8c85c*/
          (double *)((char *)v305 + 4),
          _mm_mul_ps(
            _mm_add_ps((__m128)(unsigned __int64)v306[0], (__m128)(unsigned __int64)v287),
            (__m128)xmmword_108F39940));
        *((float *)&v305[1] + 1) = v175; /*0x104f8c863*/
        _mm_storel_ps((double *)&v292, _mm_sub_ps(v174, v173)); /*0x104f8c872*/
        *(float *)&v293 = v172 - v171; /*0x104f8c879*/
        v177 = RBX::Color3::red(this: v176); /*0x104f8c881*/
        v296[0] = *(double *)v177; /*0x104f8c88a*/
        LODWORD(v296[1]) = *(_DWORD *)(v177 + 8); /*0x104f8c897*/
        HIDWORD(v296[1]) = 1065353216; /*0x104f8c89f*/
        RBX::Draw::selectionBox( /*0x104f8c8c5*/
          this: (RBX::Draw *)&v304,
          a2: (const RBX::CoordinateFrame *)&v292,
          a3: v295,
          a4: (RBX::Adorn *)v296,
          a5: v178,
          a6: 0.5);
        v169 = (RBX::Voxel2::Region *)((char *)v169 + 24); /*0x104f8c8ca*/
      }
      while ( v169 != v170 ); /*0x104f8c8d1*/
      v168 = *(_QWORD **)(*((_QWORD *)v286 + 118) + 2056LL); /*0x104f8c8e5*/
    }
    v179 = (RBX::Voxel2::Region *)v168[68]; /*0x104f8c8ec*/
    for ( j = (RBX::Voxel2::Region *)v168[69]; v179 != j; v179 = (RBX::Voxel2::Region *)((char *)v179 + 24) ) /*0x104f8c8fd*/
    {
      v306[0] = nullptr; /*0x104f8c914*/
      LODWORD(v306[1]) = 0; /*0x104f8c918*/
      *(_QWORD *)&v287 = 0; /*0x104f8c91c*/
      DWORD2(v287) = 0; /*0x104f8c923*/
      RBX::Voxel2::Region::toExtents(this: v179, a2: (RBX::Vector3 *)v306, a3: (RBX::Vector3 *)&v287, a4: 4); /*0x104f8c93d*/
      v181 = *(float *)&v306[1]; /*0x104f8c942*/
      v182 = *((float *)&v287 + 2); /*0x104f8c947*/
      v183 = (__m128)(unsigned __int64)v306[0]; /*0x104f8c956*/
      v184 = (__m128)(unsigned __int64)v287; /*0x104f8c95b*/
      v185 = (float)(*(float *)&v306[1] + *((float *)&v287 + 2)) * 0.5; /*0x104f8c978*/
      v304.i128[0] = 0x3F800000u; /*0x104f8c984*/
      v304.i128[1] = 0x3F800000u; /*0x104f8c98b*/
      LODWORD(v305[0]) = 1065353216; /*0x104f8c992*/
      _mm_storel_ps( /*0x104f8c99c*/
        (double *)((char *)v305 + 4),
        _mm_mul_ps(
          _mm_add_ps((__m128)(unsigned __int64)v306[0], (__m128)(unsigned __int64)v287),
          (__m128)xmmword_108F39940));
      *((float *)&v305[1] + 1) = v185; /*0x104f8c9a3*/
      _mm_storel_ps((double *)&v292, _mm_sub_ps(v184, v183)); /*0x104f8c9b2*/
      *(float *)&v293 = v182 - v181; /*0x104f8c9b9*/
      v187 = RBX::Color3::green(this: v186); /*0x104f8c9c1*/
      v296[0] = *(double *)v187; /*0x104f8c9ca*/
      LODWORD(v296[1]) = *(_DWORD *)(v187 + 8); /*0x104f8c9d7*/
      HIDWORD(v296[1]) = 1065353216; /*0x104f8c9df*/
      RBX::Draw::selectionBox( /*0x104f8ca05*/
        this: (RBX::Draw *)&v304,
        a2: (const RBX::CoordinateFrame *)&v292,
        a3: v295,
        a4: (RBX::Adorn *)v296,
        a5: v188,
        a6: 0.5);
    }
  }
  v189 = v286; /*0x104f8ca1e*/
  if ( RBX::Workspace::showContactIslands == 1 ) /*0x104f8ca25*/
  {
    v190 = *((RBX::World **)v286 + 118); /*0x104f8ca2b*/
    if ( v190 != nullptr && RBX::World::getSpatialFilter(this: v190) != 0 ) /*0x104f8ca43*/
    {
      std::unordered_set<RBX::AssemblyIsland *>::unordered_set( /*0x104f8ca63*/
        a1: v296,
        a2: *(_QWORD *)(*((_QWORD *)v189 + 118) + 2056LL) + 2832LL);
      v193 = v297[0]; /*0x104f8ca68*/
      if ( *(_QWORD *)&v297[0] != 0 ) /*0x104f8ca72*/
      {
        LODWORD(v277) = 1337; /*0x104f8ca78*/
        v194 = 0; /*0x104f8ca8d*/
        do /*0x104f8cedb*/
        {
          v195 = *(_QWORD **)(*(_QWORD *)&v193 + 16LL); /*0x104f8ca8f*/
          if ( v195[3] != 0 ) /*0x104f8ca98*/
          {
            if ( (v194 & 1) == 0 ) /*0x104f8caa0*/
            {
              v196 = (_QWORD *)RBX::detail::DenseHashTable<RBX::Assembly *,std::pair<RBX::Assembly *,int>,std::pair<RBX::Assembly * const,int>,RBX::detail::ItemInterfaceMap<RBX::Assembly *,int>,RBX::Hash<RBX::Assembly *>,std::equal_to<RBX::Assembly *>>::begin(a1: *(_QWORD *)(*(_QWORD *)&v193 + 16LL)); /*0x104f8caa5*/
              LODWORD(v277) = *(_DWORD *)(*v196 + 16 * v197); /*0x104f8cab4*/
            }
            v198 = ((unsigned int)(214013 * LODWORD(v277) + 2531011) >> 16) /*0x104f8cae1*/
                 + ((32897 * (((unsigned int)(214013 * LODWORD(v277) + 2531011) >> 16) & 0x7FFF)) >> 23);
            v199 = ((unsigned int)(-1443076087 * LODWORD(v277) + 505908858) >> 16) /*0x104f8caff*/
                 + ((32897 * (((unsigned int)(-1443076087 * LODWORD(v277) + 505908858) >> 16) & 0x7FFF)) >> 23);
            LODWORD(v277) = 1170746341 * LODWORD(v277) - 755606699; /*0x104f8cb0d*/
            v304.i8[0] = v198; /*0x104f8cb27*/
            v304.i8[1] = v199; /*0x104f8cb2d*/
            v304.i8[2] = BYTE2(v277) + ((32897 * (HIWORD(LODWORD(v277)) & 0x7FFFu)) >> 23); /*0x104f8cb33*/
            v304.i8[3] = -1; /*0x104f8cb3a*/
            RBX::Color4::Color4( /*0x104f8cb4b*/
              a1: &v279,
              a2: &v304,
              a3: v199,
              a4: HIWORD(LODWORD(v277)),
              a5: v191,
              a6: v192,
              a7: *(_QWORD *)&v250,
              a8: *((_QWORD *)&v250 + 1),
              a9: v257,
              a10: v258);
            v201 = COERCE_DOUBLE(RBX::detail::DenseHashTable<RBX::Assembly *,std::pair<RBX::Assembly *,int>,std::pair<RBX::Assembly * const,int>,RBX::detail::ItemInterfaceMap<RBX::Assembly *,int>,RBX::Hash<RBX::Assembly *>,std::equal_to<RBX::Assembly *>>::begin(a1: v195)); /*0x104f8cb58*/
            if ( *(_QWORD **)&v201 != v195 || v200 != (__int64)(v195[1] - *v195) >> 4 ) /*0x104f8cb6e*/
            {
              v202 = **(_QWORD **)&v201; /*0x104f8cb74*/
              v274 = v193; /*0x104f8cb77*/
              v275 = *(double *)&v195; /*0x104f8cb7e*/
              v272 = v201; /*0x104f8cb85*/
              do /*0x104f8cecd*/
              {
                v276.i64[0] = v200; /*0x104f8cb8c*/
                v203 = 16 * v200; /*0x104f8cb93*/
                v204 = *(RBX::Assembly **)(v202 + v203); /*0x104f8cb97*/
                v278 = *(double *)&v203; /*0x104f8cb9b*/
                *(_QWORD *)&v284.f64[0] = *(unsigned int *)(v202 + v203 + 8); /*0x104f8cba6*/
                AssemblyPrimitive = RBX::Assembly::getAssemblyPrimitive(this: v204); /*0x104f8cbb2*/
                *(_OWORD *)v306 = 0; /*0x104f8cbbd*/
                *(_QWORD *)&v307 = 0; /*0x104f8cbc2*/
                std::vector<RBX::Primitive *>::push_back[abi:ne200100](a1: v306, a2: &AssemblyPrimitive); /*0x104f8cbd4*/
                v206 = v306[0]; /*0x104f8cbd9*/
                v207 = 0; /*0x104f8cbdd*/
                v208 = 0; /*0x104f8cbe0*/
                do /*0x104f8ce41*/
                {
                  v209 = *((_QWORD *)v206 + v208); /*0x104f8cbe2*/
                  RBX::BasePart::fromPrimitive(this: (RBX::BasePart *)v209, a2: v205); /*0x104f8cbe9*/
                  RBX::BasePart::getPart(this: (RBX::BasePart *)&v304); /*0x104f8cbf4*/
                  RBX::Draw::selectionBox(a1: &v304, a2: v295, a3: 0.15000001); /*0x104f8cc12*/
                  if ( (v207 & 1) == 0 ) /*0x104f8cc1b*/
                  {
                    v210 = (RBX::Camera *)(**(__int64 (__fastcall ***)(RBX::Color3 *))v295)(a1: v295); /*0x104f8cc2d*/
                    PV = RBX::Primitive::getPV(this: (RBX::Primitive *)v209); /*0x104f8cc33*/
                    v283 = RBX::Camera::project(this: v210, a2: (const RBX::Vector3 *)(PV + 36)); /*0x104f8cc47*/
                    v212 = (RBX::Camera *)(**(__int64 (__fastcall ***)(RBX::Color3 *))v295)(a1: v295); /*0x104f8cc59*/
                    v213 = RBX::Camera::coordinateFrame(this: v212); /*0x104f8cc63*/
                    v214 = RBX::Primitive::getPV(this: (RBX::Primitive *)v209); /*0x104f8cc69*/
                    v216 = *(float *)(v213 + 40) - *(float *)(v214 + 40); /*0x104f8cc78*/
                    v217 = _mm_sub_ps( /*0x104f8cc96*/
                             _mm_insert_ps(
                               (__m128)*(unsigned int *)(v213 + 36),
                               (__m128)*(unsigned int *)(v213 + 44),
                               16),
                             _mm_insert_ps(*(__m128 *)(v214 + 36), (__m128)*(unsigned int *)(v214 + 44), 16));
                    v218 = _mm_mul_ps(v217, v217); /*0x104f8cc99*/
                    if ( (float)(_mm_movehdup_ps(v218).f32[0] + (float)((float)(v216 * v216) + v218.f32[0])) < 625.0 ) /*0x104f8ccb3*/
                    {
                      RBX::TextLayout::TextLayout(this: (RBX::TextLayout *)&v304, a2: (__int64)v205, a3: v215); /*0x104f8ccbc*/
                      v292 = *(_QWORD *)&v284.f64[0]; /*0x104f8ccc8*/
                      fmt::v8::vformat(a1: &v287, a2: "{}", 2, 1, &v292); /*0x104f8ccee*/
                      _mm_storel_ps((double *)&v262, v283); /*0x104f8ccfa*/
                      v220 = RBX::Color3::black(this: v219); /*0x104f8cd01*/
                      *(_QWORD *)&v273 = *(_QWORD *)v220; /*0x104f8cd0a*/
                      DWORD2(v273) = *(_DWORD *)(v220 + 8); /*0x104f8cd17*/
                      HIDWORD(v273) = 1065353216; /*0x104f8cd1f*/
                      v263 = 0; /*0x104f8cd2b*/
                      v282 = xmmword_108F4A5E0; /*0x104f8cd39*/
                      v292 = 0; /*0x104f8cd40*/
                      _mm_storel_ps((double *)&v293, (__m128)0x3F800000u); /*0x104f8cd4f*/
                      v294 = 0; /*0x104f8cd56*/
                      RBX::TextLayout::setPropsForLegacyAdornDraw2DTextCall( /*0x104f8cdbd*/
                        a1: (__int64)&v304,
                        a2: (unsigned __int8 *)&v287,
                        a3: &v262,
                        a4: 0,
                        a5: &v279,
                        a6: (unsigned __int64 *)&v273,
                        a7: 16.0,
                        a8: 0,
                        a9: 1,
                        a10: 0,
                        a11: &v263,
                        a12: (__int64)&v282,
                        a13: (__int64)&v292,
                        a14: 1);
                      if ( (v287 & 1) != 0 ) /*0x104f8cdc9*/
                        operator delete(a1: v288[0]); /*0x104f8cdd2*/
                      RBX::Adorn::drawFont2D(this: v295, a2: (RBX::TextLayout *)&v304); /*0x104f8cde1*/
                      RBX::TextLayout::~TextLayout(this: (void **)&v304); /*0x104f8cde9*/
                    }
                  }
                  if ( *(int *)(v209 + 40) > 0 ) /*0x104f8cdf3*/
                  {
                    v221 = 0; /*0x104f8cdf5*/
                    do /*0x104f8ce27*/
                    {
                      v222 = *(_QWORD *)(*(_QWORD *)(v209 + 32) + 8 * v221); /*0x104f8cdfc*/
                      v223 = v222 - 16; /*0x104f8ce00*/
                      if ( v222 == 0 ) /*0x104f8ce07*/
                        v223 = 0; /*0x104f8ce07*/
                      v304.i64[0] = v223; /*0x104f8ce0b*/
                      std::vector<RBX::Primitive *>::push_back[abi:ne200100](a1: v306, a2: &v304); /*0x104f8ce18*/
                      ++v221; /*0x104f8ce1d*/
                    }
                    while ( v221 < *(int *)(v209 + 40) ); /*0x104f8ce27*/
                  }
                  ++v208; /*0x104f8ce29*/
                  v206 = v306[0]; /*0x104f8ce2c*/
                  v207 = 1; /*0x104f8ce3b*/
                }
                while ( (v306[1] - v306[0]) >> 3 > v208 ); /*0x104f8ce41*/
                v193 = v274; /*0x104f8ce4a*/
                if ( v306[0] != nullptr ) /*0x104f8ce51*/
                {
                  v306[1] = v306[0]; /*0x104f8ce53*/
                  operator delete(a1: v306[0]); /*0x104f8ce57*/
                }
                v202 = **(_QWORD **)&v272; /*0x104f8ce63*/
                v224 = (__int64)(*(_QWORD *)(*(_QWORD *)&v272 + 8LL) - **(_QWORD **)&v272) >> 4; /*0x104f8ce6d*/
                v200 = v276.i64[0]; /*0x104f8ce71*/
                if ( v224 <= v276.i64[0] + 1 ) /*0x104f8ce7f*/
                  v224 = v276.i64[0] + 1; /*0x104f8ce7f*/
                v191 = v224 - 1; /*0x104f8ce83*/
                v225 = (__int64 *)(v202 + *(_QWORD *)&v278 + 16); /*0x104f8ce91*/
                while ( v191 != v200 ) /*0x104f8ce9f*/
                {
                  ++v200; /*0x104f8cea1*/
                  v226 = *v225; /*0x104f8cea4*/
                  v225 += 2; /*0x104f8cea7*/
                  if ( v226 != *(_QWORD *)(*(_QWORD *)&v272 + 32LL) ) /*0x104f8ceaf*/
                    goto LABEL_195; /*0x104f8ceaf*/
                }
                v200 = v224; /*0x104f8ceb3*/
LABEL_195:
                ; /*0x104f8ceb6*/
              }
              while ( *(_QWORD *)&v272 != *(_QWORD *)&v275 /*0x104f8cecd*/
                   || v200 != (__int64)(*(_QWORD *)(*(_QWORD *)&v275 + 8LL) - **(_QWORD **)&v275) >> 4 );
            }
            v194 = 1; /*0x104f8ced3*/
          }
          v193 = **(double **)&v193; /*0x104f8ced5*/
        }
        while ( v193 != 0.0 ); /*0x104f8cedb*/
      }
      std::__hash_table<RBX::AssemblyIsland *,std::hash<RBX::AssemblyIsland *>,std::equal_to<RBX::AssemblyIsland *>,std::allocator<RBX::AssemblyIsland *>>::~__hash_table(a1: v296); /*0x104f8cee8*/
      v189 = v286; /*0x104f8ceed*/
    }
  }
  if ( RBX::Workspace::showWorldCoordinateFrame == 1 ) /*0x104f8cefb*/
  {
    v304.i128[0] = 0x3F800000u; /*0x104f8cf10*/
    v304.i128[1] = 0x3F800000u; /*0x104f8cf14*/
    LODWORD(v305[0]) = 1065353216; /*0x104f8cf19*/
    *(double *)((char *)v305 + 4) = 0.0; /*0x104f8cf20*/
    HIDWORD(v305[1]) = 0; /*0x104f8cf28*/
    (*(void (__fastcall **)(RBX::Color3 *, __m256i *))(*(_QWORD *)v295 + 240LL))(a1: v295, a2: &v304); /*0x104f8cf39*/
    v228 = RBX::Color3::red(this: v227); /*0x104f8cf3f*/
    v304.i64[0] = *(_QWORD *)v228; /*0x104f8cf48*/
    v304.i32[2] = *(_DWORD *)(v228 + 8); /*0x104f8cf55*/
    v304.i32[3] = 1065353216; /*0x104f8cf5d*/
    v230 = RBX::Color3::green(this: v229); /*0x104f8cf67*/
    v296[0] = *(double *)v230; /*0x104f8cf70*/
    LODWORD(v296[1]) = *(_DWORD *)(v230 + 8); /*0x104f8cf7d*/
    HIDWORD(v296[1]) = 1065353216; /*0x104f8cf85*/
    v232 = RBX::Color3::blue(this: v231); /*0x104f8cf8f*/
    v306[0] = *(RBX::CoordinateFrame **)v232; /*0x104f8cf9c*/
    LODWORD(v306[1]) = *(_DWORD *)(v232 + 8); /*0x104f8cfa5*/
    HIDWORD(v306[1]) = 1065353216; /*0x104f8cfaa*/
    (*(void (__fastcall **)(RBX::Color3 *, __m256i *, double *, float))(*(_QWORD *)v295 + 352LL))( /*0x104f8cfd1*/
      a1: v295,
      a2: &v304,
      a3: v296,
      a4: 50.0);
  }
  if ( RBX::Workspace::showHashGrid == 1 ) /*0x104f8cfde*/
  {
    v304.i128[0] = 0x3F800000u; /*0x104f8cff3*/
    v304.i128[1] = 0x3F800000u; /*0x104f8cff7*/
    LODWORD(v305[0]) = 1065353216; /*0x104f8cffc*/
    *(double *)((char *)v305 + 4) = 0.0; /*0x104f8d003*/
    HIDWORD(v305[1]) = 0; /*0x104f8d00b*/
    v233 = v295; /*0x104f8d012*/
    (*(void (__fastcall **)(RBX::Color3 *, __m256i *))(*(_QWORD *)v295 + 240LL))(a1: v295, a2: &v304); /*0x104f8d01f*/
    v304.i64[0] = 0x4080000041E00000LL; /*0x104f8d034*/
    v304.i32[2] = 1094713344; /*0x104f8d038*/
    *(__int64 *)((char *)&v304.i64[1] + 4) = 0x4100000042000000LL; /*0x104f8d047*/
    v304.i32[5] = 1098907648; /*0x104f8d04c*/
    *(_OWORD *)v296 = xmmword_109762C40; /*0x104f8d062*/
    (*(void (__fastcall **)(RBX::Color3 *, __m256i *))(*(_QWORD *)v233 + 248LL))(a1: v233, a2: &v304); /*0x104f8d06c*/
  }
  LocalPlayer = RBX::Players::findLocalPlayer(this: v189, a2: v23); /*0x104f8d075*/
  if ( (*((_BYTE *)v189 + 2112) & 1) != 0 && (LocalPlayer == 0 || RBX::DataModel::isCloudEdit(this: v189, a2: v235)) ) /*0x104f8d08e*/
  {
    v236 = (RBX::Adorn *)(*(__int64 (__fastcall **)(RBX::Players *))(*(_QWORD *)v189 + 928LL))(a1: v189); /*0x104f8d09d*/
    v237 = (const RBX::Camera *)*((unsigned int *)v189 + 593); /*0x104f8d0a3*/
    v304.i128[0] = xmmword_109762C50; /*0x104f8d0b8*/
    *(_OWORD *)v296 = xmmword_109762C60; /*0x104f8d0cb*/
    RBX::DrawAdorn::zeroPlaneGrid( /*0x104f8d0dc*/
      this: v295,
      a2: v236,
      a3: v237,
      a4: 0,
      a5: (int)&v304,
      a6: (const RBX::Color4 *)v296,
      a7: *(const RBX::Color4 **)&v250);
  }
  RBX::Constraints::GizmoManager::render3dAdorn(this: *((RBX::Constraints::GizmoManager **)v189 + 272), a2: v295); /*0x104f8d0ef*/
  if ( (unsigned __int8)RBX::RunService::productIsStudio(this: v238) != 0 /*0x104f8d117*/
    && ((unsigned __int8)RBX::World::showSolverIslands | (RBX::World::solverConvergenceVisualizationMode != 0)) == 1 )
  {
    RBX::renderIslandsAndSolverConvergence( /*0x104f8d146*/
      a1: *(_QWORD *)(*((_QWORD *)v189 + 118) + 1200LL),
      a2: RBX::World::solverConvergenceMetricType,
      a3: (unsigned int)RBX::World::solverConvergenceVisualizationMode,
      a4: v295,
      a5: *(float *)(*((_QWORD *)v189 + 272) + 256LL));
  }
  v240 = (RBX::CorePhysicsSettings *)RBX::CorePhysicsSettings::singleton(this: v239); /*0x104f8d14b*/
  DrawTotalNetForce = RBX::CorePhysicsSettings::getDrawTotalNetForce(this: v240); /*0x104f8d153*/
  v242 = *((RBX::Constraints::GizmoManager **)v189 + 272); /*0x104f8d158*/
  if ( DrawTotalNetForce != 0 ) /*0x104f8d161*/
  {
    RBX::Constraints::GizmoManager::renderTotalNetForce(this: v242, a2: v295); /*0x104f8d16a*/
  }
  else
  {
    RBX::Constraints::GizmoManager::renderConstraintForces(this: v242, a2: v295); /*0x104f8d178*/
    RBX::Constraints::GizmoManager::renderContactForces( /*0x104f8d18b*/
      this: *((RBX::Constraints::GizmoManager **)v189 + 272),
      a2: v295);
    RBX::Constraints::GizmoManager::renderGravityForces( /*0x104f8d19e*/
      this: *((RBX::Constraints::GizmoManager **)v189 + 272),
      a2: v295);
  }
  v243 = *((RBX::World **)v189 + 118); /*0x104f8d1a3*/
  if ( *((_BYTE *)v243 + 525) == 1 ) /*0x104f8d1b1*/
  {
    v244 = *((RBX::Constraints::GizmoManager **)v189 + 272); /*0x104f8d1b3*/
    AirModel = (const RBX::FluidModels::FixedProfileFluid *)RBX::World::getAirModel(this: v243); /*0x104f8d1ba*/
    RBX::Constraints::GizmoManager::renderFluidForces(this: v244, a2: v295, a3: AirModel); /*0x104f8d1cc*/
  }
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)&v259); /*0x104f8d1d8*/
  return __stack_chk_guard; /*0x104f8d1f1*/
}

// Address: 0x104f8d5ec | Name: __ZNK3RBX9Workspace19getGridSizeModifierEv
__int64 __fastcall RBX::Workspace::getGridSizeModifier(RBX::Workspace *this)
{
  return *((unsigned int *)this + 593); /*0x104f8d5f6*/
}

// Address: 0x104f8d5f8 | Name: __ZThn320_N3RBX9Workspace13render3dAdornEPNS_5AdornE
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::render3dAdorn(RBX::Workspace *this, RBX::Adorn *a2)
{
  return RBX::Workspace::render3dAdorn(this: (RBX::Workspace *)((char *)this - 320), a2); /*0x104f8d603*/
}

// Address: 0x104f8d60a | Name: __ZN3RBX9Workspace28createConvexDecompVisualizerEv
__int64 __fastcall RBX::Workspace::createConvexDecompVisualizer(RBX::Workspace *this)
{
  RBX::DecompDebugVisualizer *v2; // r14
  __int64 result; // rax

  v2 = (RBX::DecompDebugVisualizer *)operator new(a1: 0x78u); /*0x104f8d61e*/
  result = RBX::DecompDebugVisualizer::DecompDebugVisualizer(this: v2); /*0x104f8d624*/
  this->currentCameraChangedSignal..head.px /* +1912 */ = v2; /*0x104f8d629*/
  return result; /*0x104f8d630*/
}

// Address: 0x104f8d648 | Name: __ZN3RBX9Workspace18hasModalGuiObjectsEv
__int64 __fastcall RBX::Workspace::hasModalGuiObjects(RBX::Workspace *this, RBX::Instance *a2)
{
  unsigned int ModalGuiObject; // ebx
  __int64 LocalPlayer; // rax
  RBX::BasePlayerGui *v5; // rax
  __int64 v6; // rax
  std::__shared_weak_count *v7; // r14
  RBX::BasePlayerGui *v9; // [rsp+0h] [rbp-20h] BYREF
  std::__shared_weak_count *v10; // [rsp+8h] [rbp-18h]

  LocalPlayer = RBX::Players::findLocalPlayer(this, a2); /*0x104f8d656*/
  if ( LocalPlayer == 0 /*0x104f8d679*/
    || (v5 = (RBX::BasePlayerGui *)RBX::Instance::findConstFirstChildOfType<RBX::PlayerGui>(a1: LocalPlayer)) == nullptr
    || (LOBYTE(ModalGuiObject) = 1, (unsigned __int8)RBX::BasePlayerGui::findModalGuiObject(this: v5) == 0) )
  {
    v6 = RBX::ServiceProvider::find<RBX::CoreGuiService>(a1: this); /*0x104f8d67e*/
    RBX::shared_from<RBX::CoreGuiService>(a1: &v9, a2: v6); /*0x104f8d68d*/
    if ( v9 != nullptr ) /*0x104f8d698*/
      ModalGuiObject = RBX::BasePlayerGui::findModalGuiObject(this: v9); /*0x104f8d69f*/
    else
      ModalGuiObject = 0; /*0x104f8d6a3*/
    v7 = v10; /*0x104f8d6a5*/
    if ( v10 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v10 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8d6be*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x104f8d6c6*/
      std::__shared_weak_count::__release_weak(this: v7); /*0x104f8d6cc*/
    }
  }
  return ModalGuiObject; /*0x104f8d6d3*/
}

// Address: 0x104f8d768 | Name: __ZN3RBX9Workspace16setRightMousePanEv
void __fastcall RBX::Workspace::setRightMousePan(RBX::Workspace *this)
{
  char v2; // r14
  RBX::Camera *v3; // rax
  const RBX::Instance *v4; // rsi
  int v5; // ecx
  RBX::MouseService *v6; // rax

  v2 = FFlag::NewCameraControls; /*0x104f8d779*/
  v3 = (RBX::Camera *)(*(__int64 (__fastcall **)(RBX::Workspace *))(*(_QWORD *)this + 936 /* +7488: NO 2022 FIELD */LL))(a1: this); /*0x104f8d77f*/
  v5 = *((_DWORD *)v3 + 76); /*0x104f8d785*/
  if ( v2 != 1 ) /*0x104f8d78f*/
  {
    if ( v5 == 6 ) /*0x104f8d7a7*/
      return; /*0x104f8d7a7*/
    goto LABEL_6; /*0x104f8d7a7*/
  }
  if ( v5 != 6 && !RBX::Camera::shouldBeControlledByStudioCameraService(this: v3, a2: v4) ) /*0x104f8d7a0*/
  {
LABEL_6:
    v6 = (RBX::MouseService *)RBX::ServiceProvider::find<RBX::MouseService>(a1: this); /*0x104f8d7a9*/
    if ( v6 != nullptr ) /*0x104f8d7b4*/
      RBX::MouseService::setMouseLockedForRightMousePan(this: v6, a2: 1); /*0x104f8d7c2*/
  }
}

// Address: 0x104f8d7cc | Name: __ZN3RBX9Workspace19cancelRightMousePanEv
void __fastcall RBX::Workspace::cancelRightMousePan(RBX::Workspace *this)
{
  RBX::MouseService *v1; // rax

  v1 = (RBX::MouseService *)RBX::ServiceProvider::find<RBX::MouseService>(a1: this); /*0x104f8d7d0*/
  if ( v1 != nullptr ) /*0x104f8d7d8*/
    RBX::MouseService::setMouseLockedForRightMousePan(this: v1, a2: 0); /*0x104f8d7e0*/
}

// Address: 0x104f8d7e8 | Name: __ZN3RBX9Workspace17tryFindSurfaceGuiENS_3RayEb
// local variable allocation has failed, the output may be wrong!
__int64 __fastcall RBX::Workspace::tryFindSurfaceGui(
        __int64 a1,
        RBX::Players *a2,
        int a3,
        double a4,
        double a5,
        __int64 a6,
        __int64 a7,
        __int64 a8,
        double a9,
        double a10,
        double a11,
        double a12,
        double a13,
        double a14,
        __m128 a15,
        double a16)
{
  __int64 v18; // r12
  __int64 v19; // rax
  RBX::Instance *v20; // rsi
  RBX::GuiServiceProp *v21; // r14
  __int64 CoreGuiFolder; // r15
  __int64 CoreEffectFolder; // r13
  RBX::Players *v24; // r15
  __int64 LocalPlayer; // rax
  RBX::Instance *v26; // rdi
  __int64 v27; // r14
  __int64 Character; // rax
  __int64 v29; // r12
  __int64 v30; // r15
  __int64 v31; // rbx
  __int64 v32; // rax
  __int64 v33; // rsi
  std::__shared_weak_count *v34; // r12
  __int64 v35; // r12
  __int64 v36; // rax
  std::__shared_weak_count *v37; // r12
  __int64 v38; // rsi
  char v39; // r13
  std::__shared_weak_count *v40; // r12
  RBX::PlayerProp *v41; // r14
  __int64 v42; // rax
  std::__shared_weak_count *v43; // r14
  std::__shared_weak_count *v44; // r14
  __m128 v45; // xmm0
  float v46; // xmm0_4
  __int128 v47; // xmm0
  int v48; // xmm1_4
  __int128 v49; // xmm0
  int v50; // xmm1_4
  __m128 v51; // xmm1
  RBX::SurfaceGuiBase *SurfaceGui; // r12
  __int64 v53; // rax
  __int64 v54; // r9
  __int64 v55; // rdx
  __int64 v56; // rcx
  __int64 v57; // rsi
  __int64 v58; // r8
  __int64 v59; // r9
  std::__shared_weak_count *v60; // r15
  __m128 v61; // xmm0
  __m128 v62; // xmm0
  std::__shared_weak_count *v63; // r14
  __m128 v65; // xmm0
  __m128 v66; // [rsp+0h] [rbp-170h]
  double v67; // [rsp+10h] [rbp-160h]
  float v68; // [rsp+30h] [rbp-140h]
  __int128 v69; // [rsp+40h] [rbp-130h] BYREF
  __int64 v70; // [rsp+50h] [rbp-120h]
  __int128 v71; // [rsp+60h] [rbp-110h] BYREF
  __int64 v72; // [rsp+70h] [rbp-100h]
  __int128 v73; // [rsp+80h] [rbp-F0h] BYREF
  __m128 v74; // [rsp+90h] [rbp-E0h]
  _BYTE v75[4]; // [rsp+A4h] [rbp-CCh] BYREF
  int v76; // [rsp+A8h] [rbp-C8h]
  __int64 v77; // [rsp+ACh] [rbp-C4h]
  float v78; // [rsp+B4h] [rbp-BCh]
  __int64 v79; // [rsp+B8h] [rbp-B8h] BYREF
  int v80; // [rsp+C0h] [rbp-B0h]
  unsigned __int64 v81; // [rsp+C8h] [rbp-A8h] BYREF
  RBX::Players *v82[2]; // [rsp+D0h] [rbp-A0h]
  __int64 v83; // [rsp+E0h] [rbp-90h] BYREF
  int v84; // [rsp+E8h] [rbp-88h]
  __int64 v85; // [rsp+F0h] [rbp-80h] BYREF
  int v86; // [rsp+F8h] [rbp-78h]
  __int64 v87; // [rsp+100h] [rbp-70h] BYREF
  unsigned int v88; // [rsp+108h] [rbp-68h]
  std::__shared_weak_count *v89[2]; // [rsp+110h] [rbp-60h] BYREF
  std::__shared_weak_count *v90[2]; // [rsp+120h] [rbp-50h] BYREF
  __int64 v91; // [rsp+138h] [rbp-38h]
  bool v92; // [rsp+147h] [rbp-29h]

  v76 = a3; /*0x104f8d7fc*/
  v18 = RBX::ServiceProvider::find<RBX::VRService>(a1: a2, a2: a4, a3: a5); /*0x104f8d810*/
  v82[0] = a2; /*0x104f8d813*/
  v19 = RBX::ServiceProvider::find<RBX::GuiService>(a1: a2); /*0x104f8d81d*/
  if ( v19 != 0 ) /*0x104f8d825*/
  {
    v21 = (RBX::GuiServiceProp *)(v19 + 192); /*0x104f8d82a*/
    CoreGuiFolder = RBX::GuiServiceProp::getCoreGuiFolder(this: (RBX::GuiServiceProp *)(v19 + 192)); /*0x104f8d839*/
    CoreEffectFolder = RBX::GuiServiceProp::getCoreEffectFolder(this: v21); /*0x104f8d844*/
  }
  else
  {
    CoreEffectFolder = 0; /*0x104f8d849*/
    CoreGuiFolder = 0; /*0x104f8d84c*/
  }
  v74.i64[0] = v18; /*0x104f8d84f*/
  v91 = CoreGuiFolder; /*0x104f8d856*/
  v24 = v82[0]; /*0x104f8d85a*/
  LocalPlayer = RBX::Players::findLocalPlayer(this: v82[0], a2: v20); /*0x104f8d864*/
  v27 = LocalPlayer; /*0x104f8d869*/
  v92 = true; /*0x104f8d86c*/
  if ( LocalPlayer != 0 && RBX::PlayerProp::getCharacter(this: (RBX::PlayerProp *)(LocalPlayer + 176)) != 0 ) /*0x104f8d887*/
  {
    Character = RBX::PlayerProp::getCharacter(this: (RBX::PlayerProp *)(v27 + 176)); /*0x104f8d88c*/
    v92 = RBX::Instance::findConstFirstChildOfType<RBX::Tool>(a1: Character) == 0; /*0x104f8d89c*/
  }
  v69 = 0; /*0x104f8d8a3*/
  v70 = 0; /*0x104f8d8ac*/
  v72 = 0; /*0x104f8d8b3*/
  v71 = 0; /*0x104f8d8ba*/
  v29 = v91; /*0x104f8d8c1*/
  if ( v91 != 0 ) /*0x104f8d8c8*/
  {
    v30 = a1; /*0x104f8d8ce*/
    v31 = *(_QWORD *)(v91 + 24); /*0x104f8d8d1*/
    v32 = RBX::Instance::classDescriptor(this: v26); /*0x104f8d8d6*/
    v33 = 0; /*0x104f8d8f2*/
    if ( *(unsigned __int16 *)(v31 + 440) - (unsigned int)*(unsigned __int16 *)(v32 + 440) <= *(unsigned __int16 *)(v32 + 442) ) /*0x104f8d8f6*/
      v33 = v91; /*0x104f8d8f6*/
    RBX::shared_from<RBX::Instance>(a1: v90, a2: v33); /*0x104f8d8fe*/
    std::vector<std::shared_ptr<RBX::Instance>>::push_back[abi:ne200100](a1: &v71, a2: v90); /*0x104f8d90e*/
    v34 = v90[1]; /*0x104f8d913*/
    a1 = v30; /*0x104f8d91a*/
    if ( v90[1] != nullptr /*0x104f8d930*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v34 + 16LL))(a1: v34); /*0x104f8d939*/
      std::__shared_weak_count::__release_weak(this: v34); /*0x104f8d93f*/
    }
    v29 = v91; /*0x104f8d944*/
    v24 = v82[0]; /*0x104f8d948*/
  }
  if ( CoreEffectFolder != 0 ) /*0x104f8d952*/
  {
    v35 = *(_QWORD *)(CoreEffectFolder + 24); /*0x104f8d954*/
    v36 = RBX::Instance::classDescriptor(this: v26); /*0x104f8d958*/
    if ( *(unsigned __int16 *)(v35 + 440) - (unsigned int)*(unsigned __int16 *)(v36 + 440) > *(unsigned __int16 *)(v36 + 442) ) /*0x104f8d97a*/
      CoreEffectFolder = 0; /*0x104f8d97a*/
    RBX::shared_from<RBX::Instance>(a1: v90, a2: CoreEffectFolder); /*0x104f8d985*/
    std::vector<std::shared_ptr<RBX::Instance>>::push_back[abi:ne200100](a1: &v69, a2: v90); /*0x104f8d995*/
    v37 = v90[1]; /*0x104f8d99a*/
    if ( v90[1] != nullptr /*0x104f8d9b4*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v37 + 16LL))(a1: v37); /*0x104f8d9bd*/
      std::__shared_weak_count::__release_weak(this: v37); /*0x104f8d9c3*/
    }
    v29 = v91; /*0x104f8d9c8*/
  }
  v38 = *((_QWORD *)v24 + 140); /*0x104f8d9cc*/
  v39 = v76; /*0x104f8d9d6*/
  if ( v38 != 0 ) /*0x104f8d9dd*/
  {
    RBX::shared_from<RBX::Instance>(a1: v90, a2: v38); /*0x104f8d9e3*/
    std::vector<std::shared_ptr<RBX::Instance>>::push_back[abi:ne200100](a1: &v69, a2: v90); /*0x104f8d9f3*/
    v40 = v90[1]; /*0x104f8d9f8*/
    if ( v90[1] != nullptr /*0x104f8da12*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v40 + 16LL))(a1: v40); /*0x104f8da1b*/
      std::__shared_weak_count::__release_weak(this: v40); /*0x104f8da21*/
    }
    v29 = v91; /*0x104f8da26*/
  }
  if ( v27 != 0 ) /*0x104f8da2d*/
  {
    v41 = (RBX::PlayerProp *)(v27 + 176); /*0x104f8da33*/
    if ( RBX::PlayerProp::getCharacter(this: v41) != 0 ) /*0x104f8da45*/
    {
      v42 = RBX::PlayerProp::getCharacter(this: v41); /*0x104f8da4e*/
      RBX::shared_from<RBX::ModelInstance>(a1: v89, a2: v42); /*0x104f8da5a*/
      *(_OWORD *)v90 = *(_OWORD *)v89; /*0x104f8da67*/
      *(_OWORD *)v89 = 0; /*0x104f8da6d*/
      std::vector<std::shared_ptr<RBX::Instance>>::push_back[abi:ne200100](a1: &v69, a2: v90); /*0x104f8da78*/
      v43 = v90[1]; /*0x104f8da7d*/
      if ( v90[1] != nullptr /*0x104f8da96*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v43 + 16LL))(a1: v43); /*0x104f8da9e*/
        std::__shared_weak_count::__release_weak(this: v43); /*0x104f8daa4*/
      }
      v44 = v89[1]; /*0x104f8daa9*/
      if ( v89[1] != nullptr /*0x104f8dac2*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v89[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v44 + 16LL))(a1: v44); /*0x104f8daca*/
        std::__shared_weak_count::__release_weak(this: v44); /*0x104f8dad0*/
      }
    }
  }
  if ( v74.i64[0] != 0 && *(_BYTE *)(v74.i64[0] + 301) == 1 ) /*0x104f8daec*/
  {
    RBX::VRServiceProp::getLaserDistance(this: (RBX::VRServiceProp *)(v74.i64[0] + 192)); /*0x104f8daf5*/
    _mm_storel_ps( /*0x104f8db07*/
      (double *)((char *)&a15.i64[1] + 4),
      _mm_mul_ps(_mm_moveldup_ps(v45), (__m128)*(unsigned __int64 *)((char *)&a15.u64[1] + 4)));
    v46 = v45.f32[0] * *((float *)&a16 + 1); /*0x104f8db0c*/
  }
  else
  {
    _mm_storel_ps( /*0x104f8db21*/
      (double *)((char *)&a15.i64[1] + 4),
      _mm_mul_ps((__m128)*(unsigned __int64 *)((char *)&a15.u64[1] + 4), (__m128)xmmword_108F52A90));
    v46 = *((float *)&a16 + 1) * 1000.0; /*0x104f8db2c*/
  }
  *((float *)&a16 + 1) = v46; /*0x104f8db34*/
  *(_OWORD *)v90 = 0; /*0x104f8db3d*/
  v83 = 0; /*0x104f8db43*/
  v84 = 0; /*0x104f8db4a*/
  v85 = 0; /*0x104f8db50*/
  v86 = 0; /*0x104f8db54*/
  if ( v39 == 0 ) /*0x104f8db5a*/
  {
    *(double *)&v49 = RBX::WorldRoot::getHitLocationPartFilterDescendents<std::vector<std::shared_ptr<RBX::Instance>> const>( /*0x104f8dbf0*/
                        a1: v24,
                        a2: &v69,
                        a3: v90,
                        a4: &v83,
                        a5: v75,
                        a6: 0,
                        a7: a15.i64[0],
                        a8: a15.i64[1],
                        a9: *(_QWORD *)&a16,
                        a10: 0,
                        a11: 0);
    *(_OWORD *)v82 = v49; /*0x104f8dbf5*/
    LODWORD(v91) = v50; /*0x104f8dbfc*/
    goto LABEL_42; /*0x104f8dbfc*/
  }
  if ( v29 != 0 ) /*0x104f8db5f*/
  {
    *(double *)&v47 = RBX::WorldRoot::getHitLocationPartFilterDescendents<std::vector<std::shared_ptr<RBX::Instance>> const>( /*0x104f8dba5*/
                        a1: v24,
                        a2: &v71,
                        a3: v90,
                        a4: &v83,
                        a5: v75,
                        a6: 0,
                        a7: a15.i64[0],
                        a8: a15.i64[1],
                        a9: *(_QWORD *)&a16,
                        a10: 0,
                        a11: 1);
    *(_OWORD *)v82 = v47; /*0x104f8dbaa*/
    LODWORD(v91) = v48; /*0x104f8dbb1*/
LABEL_42:
    v51 = *(__m128 *)v82; /*0x104f8dc01*/
    _mm_storel_ps((double *)&v85, *(__m128 *)v82); /*0x104f8dc08*/
    v86 = v91; /*0x104f8dc11*/
    v68 = _mm_movehdup_ps(v51).f32[0]; /*0x104f8dc1a*/
    goto LABEL_43; /*0x104f8dc1a*/
  }
  LODWORD(v91) = 0; /*0x104f8df3c*/
  v68 = 0.0; /*0x104f8df41*/
  *(_OWORD *)v82 = 0; /*0x104f8df48*/
LABEL_43:
  if ( v90[0] != nullptr ) /*0x104f8dc28*/
  {
    v77 = *(__int64 *)((char *)a15.i64 + 4); /*0x104f8dc41*/
    v78 = a15.f32[0]; /*0x104f8dc41*/
    LODWORD(v73) = 0; /*0x104f8dc5e*/
    (*(void (__fastcall **)(std::__shared_weak_count **, std::__shared_weak_count *, __m128 *, __int128 *))(*(_QWORD *)v90[0] + 1432LL))( /*0x104f8dc6e*/
      a1: v89,
      a2: v90[0],
      a3: &a15,
      a4: &v73);
    v74 = 0; /*0x104f8dc77*/
    if ( v89[0] != nullptr /*0x104f8dcac*/
      && (SurfaceGui = (RBX::SurfaceGuiBase *)RBX::SurfaceGuiBase::findSurfaceGui(a1: v90[0], a2: LODWORD(v89[1]))) != nullptr
      && (*(float (__fastcall **)(RBX::SurfaceGuiBase *))(*(_QWORD *)SurfaceGui + 1096LL))(a1: SurfaceGui) == 0.0 )
    {
      RBX::SurfaceGuiBase::getFlatScreenScreenCoordinatesFromWorldSpace( /*0x104f8df5b*/
        this: SurfaceGui,
        a2: (const RBX::Vector3 *)&v85);
      v74 = v65; /*0x104f8df60*/
    }
    else
    {
      SurfaceGui = nullptr; /*0x104f8dcb4*/
    }
    *(float *)&v91 = fsqrt( /*0x104f8dd07*/
                       (float)((float)(*((float *)&v77 + 1) - *(float *)&v91)
                             * (float)(*((float *)&v77 + 1) - *(float *)&v91))
                     + (float)((float)((float)(*(float *)&v77 - v68) * (float)(*(float *)&v77 - v68))
                             + (float)((float)(v78 - *(float *)v82) * (float)(v78 - *(float *)v82))))
                   + 0.001;
  }
  else
  {
    LODWORD(v91) = 981668463; /*0x104f8dd16*/
    v74 = 0; /*0x104f8dd1e*/
    SurfaceGui = nullptr; /*0x104f8dd25*/
  }
  v53 = RBX::ServiceProvider::find<RBX::GuiService>(a1: v24); /*0x104f8dd2b*/
  if ( v53 != 0 ) /*0x104f8dd33*/
  {
    v79 = 0; /*0x104f8dd3b*/
    v80 = 0; /*0x104f8dd42*/
    v87 = 0; /*0x104f8dd48*/
    v88 = 0; /*0x104f8dd4c*/
    v81 = 0; /*0x104f8dd4f*/
    *(_OWORD *)v89 = 0; /*0x104f8dd59*/
    v67 = a16; /*0x104f8dd66*/
    if ( v39 != 0 ) /*0x104f8dd60*/
    {
      v66.i64[1] = a15.i64[1]; /*0x104f8dd6f*/
      RBX::GuiService::raycastCoreCurvedSurfaceGuis( /*0x104f8dd8f*/
        a1: &v73,
        a2: v53,
        a3: (__int64)&v87,
        a4: (__int64)&v79,
        a5: (__int64)&v81,
        a6: v54,
        a7: a15.i8[0]);
    }
    else
    {
      v66 = a15; /*0x104f8dda3*/
      RBX::GuiService::raycastCurvedSurfaceGuis( /*0x104f8ddc3*/
        a1: &v73,
        a2: v53,
        a3: (__int64)&v87,
        a4: (__int64)&v79,
        a5: &v81,
        a6: v54,
        a7: a15);
    }
    v60 = *((std::__shared_weak_count **)&v73 + 1); /*0x104f8ddcf*/
    *(_OWORD *)v89 = v73; /*0x104f8ddd6*/
    if ( (_QWORD)v73 != 0 ) /*0x104f8dde1*/
    {
      if ( SurfaceGui == nullptr /*0x104f8de31*/
        || (v61 = _mm_sub_ps(
                    _mm_insert_ps(a15, (__m128)a15.u32[2], 16),
                    _mm_insert_ps((__m128)(unsigned int)v87, (__m128)v88, 16)),
            v62 = _mm_mul_ps(v61, v61),
            *(float *)&v91 > fsqrt(
                               _mm_movehdup_ps(v62).f32[0]
                             + (float)((float)((float)(a15.f32[1] - *((float *)&v87 + 1))
                                             * (float)(a15.f32[1] - *((float *)&v87 + 1)))
                                     + v62.f32[0]))) )
      {
        v74 = (__m128)v81; /*0x104f8de3b*/
        v83 = v79; /*0x104f8de49*/
        v84 = v80; /*0x104f8de56*/
        v85 = v87; /*0x104f8de60*/
        v56 = v88; /*0x104f8de64*/
        v86 = v88; /*0x104f8de67*/
        SurfaceGui = (RBX::SurfaceGuiBase *)v73; /*0x104f8de6a*/
      }
    }
    if ( *((_QWORD *)&v73 + 1) != 0 /*0x104f8de82*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v73 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *, __int64, __int64, __int64, __int64, __int64, __int64, __int64, double))(*(_QWORD *)v60 + 16LL))( /*0x104f8de8a*/
        a1: v60,
        a2: v57,
        a3: v55,
        a4: v56,
        a5: v58,
        a6: v59,
        a7: v66.i64[0],
        a8: v66.i64[1],
        a9: COERCE_DOUBLE(*(_QWORD *)&v67));
      std::__shared_weak_count::__release_weak(this: v60); /*0x104f8de90*/
    }
  }
  *(_DWORD *)(a1 + 16) = v86; /*0x104f8de98*/
  *(_QWORD *)(a1 + 8) = v85; /*0x104f8de9f*/
  *(_QWORD *)a1 = SurfaceGui; /*0x104f8dea3*/
  _mm_storel_ps((double *)(a1 + 20), v74); /*0x104f8dead*/
  *(_QWORD *)(a1 + 28) = v83; /*0x104f8deb8*/
  *(_DWORD *)(a1 + 36) = v84; /*0x104f8dec2*/
  *(_BYTE *)(a1 + 40) = v92; /*0x104f8dec8*/
  *(_BYTE *)(a1 + 48) = 1; /*0x104f8decb*/
  v63 = v90[1]; /*0x104f8decf*/
  if ( v90[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8dee8*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v63 + 16LL))(a1: v63); /*0x104f8def0*/
    std::__shared_weak_count::__release_weak(this: v63); /*0x104f8def6*/
  }
  v90[0] = (std::__shared_weak_count *)&v71; /*0x104f8df06*/
  std::vector<std::shared_ptr<RBX::Instance>>::__destroy_vector::operator()[abi:ne200100](a1: (void ***)v90); /*0x104f8df09*/
  *(_QWORD *)&v71 = &v69; /*0x104f8df15*/
  std::vector<std::shared_ptr<RBX::Instance>>::__destroy_vector::operator()[abi:ne200100](a1: (void ***)&v71); /*0x104f8df1f*/
  return a1; /*0x104f8df27*/
}

// Address: 0x104f8e04e | Name: __ZN3RBX9Workspace25tryFindSurfaceGuiForEventERKNSt3__110shared_ptrINS_11InputObjectEEEb
_BYTE *__fastcall RBX::Workspace::tryFindSurfaceGuiForEvent(
        _BYTE *a1,
        RBX::Players *a2,
        RBX::InputObject **a3,
        unsigned __int8 a4)
{
  RBX::InputObject *v8; // rsi
  unsigned int v9; // eax
  __int64 v10; // rcx
  __int64 v11; // r8
  __int64 v12; // r9
  double v13; // xmm1_8
  double v14; // xmm2_8
  double v15; // xmm3_8
  double v16; // xmm4_8
  double v17; // xmm5_8
  double v18; // xmm6_8
  double v19; // xmm7_8
  __m128 v21; // [rsp+18h] [rbp-38h] BYREF
  double v22; // [rsp+28h] [rbp-28h]

  if ( RBX::SurfaceGuiBase::s_numInstances != 0 ) /*0x104f8e06a*/
  {
    v8 = *a3; /*0x104f8e075*/
    v9 = *((_DWORD *)*a3 + 51); /*0x104f8e078*/
    if ( v9 < 5 || v9 == 7 ) /*0x104f8e0b6*/
      goto LABEL_3; /*0x104f8e0b6*/
    if ( RBX::InputObject::isGamepadEvent(this: *a3) ) /*0x104f8e0bb*/
    {
      v8 = *a3; /*0x104f8e0c4*/
LABEL_3:
      RBX::InputObject::getRay(this: (RBX::InputObject *)&v21, a2: v8); /*0x104f8e083*/
      RBX::Workspace::tryFindSurfaceGui( /*0x104f8e0ac*/
        (__int64)a1,
        a2,
        a3: a4,
        a4: *(double *)v21.i64,
        a5: v13,
        a6: v10,
        a7: v11,
        a8: v12,
        a9: v14,
        a10: v15,
        a11: v16,
        a12: v17,
        a13: v18,
        a14: v19,
        a15: v21,
        a16: v22);
      return a1; /*0x104f8e0d4*/
    }
  }
  *a1 = 0; /*0x104f8e0cc*/
  a1[48] = 0; /*0x104f8e0ce*/
  return a1; /*0x104f8e0ce*/
}

// Address: 0x104f8e0e2 | Name: __ZN3RBX9Workspace16handleSurfaceGuiERKNSt3__110shared_ptrINS_11InputObjectEEEb
RBX::VRService *__fastcall RBX::Workspace::handleSurfaceGui(
        RBX::VRService *a1,
        RBX::ServiceProvider *a2,
        RBX::InputObject **a3,
        unsigned __int8 a4)
{
  RBX::ServiceProvider *ServiceProvider; // rax
  __int64 v9; // r15
  std::__shared_weak_count *v10; // rdi
  __int64 v11; // r15
  volatile signed __int64 *v12; // rax
  RBX::Instance *v13; // rsi
  std::__shared_weak_count *v14; // r13
  RBX::InputObject **v15; // rbx
  RBX::EngineContext *v16; // r14
  bool v17; // zf
  RBX::EngineContext *v18; // r13
  double v19; // xmm1_8
  __int128 v20; // xmm0
  volatile signed __int64 *v21; // r13
  std::__shared_weak_count *v22; // rdi
  RBX::BasePart *v23; // r15
  RBX::VRService *v24; // r13
  __int64 v25; // r13
  RBX::BasePart *v26; // rcx
  std::__shared_weak_count *v27; // r13
  __int64 v28; // rax
  std::__shared_weak_count *v29; // r14
  __int128 v30; // xmm0
  std::__shared_weak_count *v32; // r13
  RBX::BasePart *v33; // rsi
  __int64 v34; // rax
  __int64 v35; // rdi
  __int64 v36; // rsi
  __int64 v37; // r12
  volatile signed __int64 *v38; // r14
  __int64 v39; // r15
  __int64 v40; // rax
  RBX::SurfaceGuiBaseProp *v41; // r14
  float v42; // xmm0_4
  __int64 v43; // rdi
  __int64 v44; // rsi
  RBX::BasePart *v45; // r14
  __int64 v46; // r15
  __int64 v47; // rax
  std::__shared_weak_count *v48; // r12
  RBX::EngineContext *v49; // [rsp+8h] [rbp-C8h] BYREF
  double v50; // [rsp+10h] [rbp-C0h]
  float v51; // [rsp+18h] [rbp-B8h]
  double v52; // [rsp+1Ch] [rbp-B4h]
  unsigned __int64 v53; // [rsp+24h] [rbp-ACh]
  float v54; // [rsp+2Ch] [rbp-A4h]
  unsigned __int8 v55; // [rsp+30h] [rbp-A0h]
  char v56; // [rsp+38h] [rbp-98h]
  __int128 v57; // [rsp+40h] [rbp-90h] BYREF
  __int128 v58; // [rsp+50h] [rbp-80h]
  int v59; // [rsp+60h] [rbp-70h]
  double v60; // [rsp+64h] [rbp-6Ch]
  float v61; // [rsp+6Ch] [rbp-64h]
  RBX::BasePart *v62; // [rsp+78h] [rbp-58h] BYREF
  std::__shared_weak_count *v63; // [rsp+80h] [rbp-50h]
  RBX::VRService *v64; // [rsp+88h] [rbp-48h]
  __int128 v65; // [rsp+90h] [rbp-40h]

  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: a2, a2); /*0x104f8e105*/
  if ( ServiceProvider != nullptr ) /*0x104f8e10d*/
    *(_QWORD *)&v65 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::UIDragDetectorService>(this: ServiceProvider); /*0x104f8e117*/
  else
    *(_QWORD *)&v65 = 0; /*0x104f8e11d*/
  RBX::Workspace::tryFindSurfaceGuiForEvent(a1: &v49, a2, a3, a4); /*0x104f8e13c*/
  if ( v56 != 0 ) /*0x104f8e146*/
  {
    v9 = 16 * (unsigned int)a4; /*0x104f8e14c*/
    v10 = *(std::__shared_weak_count **)((char *)a2 + v9 + 2344); /*0x104f8e150*/
    v11 = v9 | 0x920; /*0x104f8e158*/
    if ( v10 != nullptr ) /*0x104f8e162*/
    {
      v12 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v10); /*0x104f8e168*/
      if ( v12 != nullptr ) /*0x104f8e170*/
      {
        v14 = (std::__shared_weak_count *)v12; /*0x104f8e176*/
        v64 = a1; /*0x104f8e179*/
        v15 = a3; /*0x104f8e17d*/
        v16 = *(RBX::EngineContext **)((char *)a2 + v11); /*0x104f8e180*/
        if ( _InterlockedExchangeAdd64(v12 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8e194*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v12 + 16))(a1: v12); /*0x104f8e19d*/
          std::__shared_weak_count::__release_weak(this: v14); /*0x104f8e1a3*/
        }
        v17 = v16 == nullptr; /*0x104f8e1a8*/
        v18 = v16; /*0x104f8e1ab*/
        a3 = v15; /*0x104f8e1ae*/
        a1 = v64; /*0x104f8e1b1*/
        if ( !v17 && v49 != v18 && RBX::DataModel::get(this: v18, a2: v13) != nullptr ) /*0x104f8e1d3*/
        {
          if ( (_QWORD)v65 != 0 /*0x104f8e21f*/
            && (unsigned __int8)RBX::UIDragDetectorService::isDragging(a1: v65, a2: a3) != 0
            && (unsigned __int8)RBX::UIDragDetectorService::isDraggingInWorkspace(a1: v65, a2: a3) != 0
            && (*(_BYTE *)(v65 + 186) != 1
             || (unsigned __int8)RBX::UIButtonDrivenUtil::isButtonDrivenKeycode(a1: *((unsigned int *)*a3 + 49)) != 0) )
          {
            if ( (unsigned __int8)RBX::UIDragDetectorService::isDragEndingInputObject(a1: a3) != 0 ) /*0x104f8e22b*/
            {
              RBX::UIDragDetectorService::getDraggingGuiObject(a1: &v57, a2: v65, a3); /*0x104f8e242*/
              (*(void (__fastcall **)(RBX::VRService *, _QWORD, RBX::InputObject **))(*(_QWORD *)v57 + 616LL))( /*0x104f8e253*/
                a1,
                a2: v57,
                a3);
              std::shared_ptr<RBX::GuiObject>::~shared_ptr[abi:ne200100](a1: &v57); /*0x104f8e260*/
              return a1; /*0x104f8e265*/
            }
            *(_QWORD *)a1 = 1; /*0x104f8e6b9*/
            goto LABEL_38; /*0x104f8e6c0*/
          }
          RBX::SurfaceGuiBase::unProcess(this: v18); /*0x104f8e270*/
        }
      }
    }
    RBX::shared_from<RBX::SurfaceGuiBase>(a1: &v57, a2: v49); /*0x104f8e286*/
    v20 = v57; /*0x104f8e28b*/
    v21 = *((volatile signed __int64 **)&v57 + 1); /*0x104f8e290*/
    if ( *((_QWORD *)&v57 + 1) != 0 ) /*0x104f8e297*/
      _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v57 + 1) + 16LL)); /*0x104f8e299*/
    v22 = *(std::__shared_weak_count **)((char *)a2 + v11 + 8); /*0x104f8e29e*/
    *(_OWORD *)((char *)a2 + v11) = v20; /*0x104f8e2a3*/
    if ( v22 != nullptr ) /*0x104f8e2ab*/
    {
      std::__shared_weak_count::__release_weak(this: v22); /*0x104f8e2ad*/
      v21 = *((volatile signed __int64 **)&v57 + 1); /*0x104f8e2b2*/
    }
    if ( v21 != nullptr && _InterlockedExchangeAdd64(v21 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8e2ce*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v21 + 16))(a1: v21); /*0x104f8e2d7*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v21); /*0x104f8e2dd*/
    }
    v23 = v49; /*0x104f8e2e2*/
    if ( v49 != nullptr ) /*0x104f8e2ec*/
    {
      v24 = (RBX::VRService *)RBX::ServiceProvider::find<RBX::VRService>(a1: a2, a2: *(double *)&v20, a3: v19); /*0x104f8e2fa*/
      if ( (_QWORD)v65 != 0 && (unsigned __int8)RBX::UIDragDetectorService::isDragging(a1: v65, a2: a3) != 0 ) /*0x104f8e318*/
      {
        v64 = v24; /*0x104f8e31e*/
        v25 = v65; /*0x104f8e32c*/
        RBX::UIDragDetectorService::getDraggingGuiLayerCollector(a1: &v57, a2: v65, a3); /*0x104f8e32f*/
        RBX::UIDragDetectorService::getDraggingGuiLayerCollector(a1: &v62, a2: v25, a3); /*0x104f8e33e*/
        v26 = v62; /*0x104f8e343*/
        v27 = v63; /*0x104f8e347*/
        if ( v63 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v63 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8e360*/
        {
          v28 = *(_QWORD *)v27; /*0x104f8e362*/
          *(_QWORD *)&v65 = v26; /*0x104f8e369*/
          (*(void (__fastcall **)(std::__shared_weak_count *))(v28 + 16))(a1: v27); /*0x104f8e36d*/
          std::__shared_weak_count::__release_weak(this: v27); /*0x104f8e373*/
          v26 = (RBX::BasePart *)v65; /*0x104f8e378*/
        }
        if ( v26 != v23 ) /*0x104f8e37f*/
        {
          *(_QWORD *)a1 = 0; /*0x104f8e381*/
          *((_DWORD *)a1 + 2) = 0; /*0x104f8e388*/
          *((_OWORD *)a1 + 1) = 0; /*0x104f8e392*/
          v29 = *((std::__shared_weak_count **)&v57 + 1); /*0x104f8e396*/
          if ( *((_QWORD *)&v57 + 1) != 0 /*0x104f8e3b2*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v57 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v29 + 16LL))(a1: v29); /*0x104f8e3ba*/
            std::__shared_weak_count::__release_weak(this: v29); /*0x104f8e3c0*/
          }
          return a1; /*0x104f8e3c5*/
        }
        v32 = *((std::__shared_weak_count **)&v57 + 1); /*0x104f8e3f1*/
        if ( *((_QWORD *)&v57 + 1) != 0 /*0x104f8e40d*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v57 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v32 + 16LL))(a1: v32); /*0x104f8e416*/
          std::__shared_weak_count::__release_weak(this: v32); /*0x104f8e41c*/
        }
        v24 = v64; /*0x104f8e421*/
      }
      *(_QWORD *)a1 = 0; /*0x104f8e425*/
      *((_DWORD *)a1 + 2) = 0; /*0x104f8e42c*/
      *((_OWORD *)a1 + 1) = 0; /*0x104f8e436*/
      if ( v24 == nullptr ) /*0x104f8e43d*/
      {
        v33 = v49; /*0x104f8e51a*/
        goto LABEL_55; /*0x104f8e51a*/
      }
      v33 = v49; /*0x104f8e443*/
      if ( *((_BYTE *)v24 + 301) != 1 ) /*0x104f8e452*/
      {
LABEL_55:
        (*(void (__fastcall **)(__int128 *, RBX::BasePart *, RBX::InputObject **, _QWORD, double, float, double))(*(_QWORD *)v33 + 1168LL))( /*0x104f8e521*/
          a1: &v57,
          a2: v33,
          a3,
          a4: v55,
          a5: v50,
          a6: v51,
          a7: v52);
        *((_DWORD *)a1 + 2) = DWORD2(v57); /*0x104f8e55a*/
        *(_QWORD *)a1 = v57; /*0x104f8e560*/
        v30 = v58; /*0x104f8e563*/
        goto LABEL_39; /*0x104f8e568*/
      }
      (*(void (__fastcall **)(__int128 *, RBX::EngineContext *, RBX::InputObject **, _QWORD, double, float, double))(*(_QWORD *)v49 + 1168LL))( /*0x104f8e48a*/
        a1: &v57,
        a2: v49,
        a3,
        a4: v55,
        a5: v50,
        a6: v51,
        a7: v52);
      *((_DWORD *)a1 + 2) = DWORD2(v57); /*0x104f8e494*/
      *(_QWORD *)a1 = v57; /*0x104f8e49b*/
      v65 = v58; /*0x104f8e4a3*/
      *((_OWORD *)a1 + 1) = v58; /*0x104f8e4a7*/
      v34 = RBX::ServiceProvider::find<RBX::CoreGuiService>(a1: a2); /*0x104f8e4ae*/
      if ( v34 != 0 ) /*0x104f8e4b6*/
      {
        v37 = *(_QWORD *)(v34 + 440); /*0x104f8e4bc*/
        *(_QWORD *)&v57 = v37; /*0x104f8e4c3*/
        v38 = *(volatile signed __int64 **)(v34 + 448); /*0x104f8e4ca*/
        *((_QWORD *)&v57 + 1) = v38; /*0x104f8e4d1*/
        if ( v38 != nullptr ) /*0x104f8e4de*/
          _InterlockedIncrement64(v38 + 1); /*0x104f8e4e0*/
        if ( v37 != 0 ) /*0x104f8e4e8*/
        {
          v39 = *(_QWORD *)(v37 + 24); /*0x104f8e4ee*/
          v40 = RBX::Reflection::Class_getDescriptorPtr<RBX::BasePart>(a1: v35, a2: v36); /*0x104f8e4f3*/
          if ( *(unsigned __int16 *)(v39 + 440) - (unsigned int)*(unsigned __int16 *)(v40 + 440) > *(unsigned __int16 *)(v40 + 442) ) /*0x104f8e514*/
            v37 = 0; /*0x104f8e514*/
        }
        else
        {
          v37 = 0; /*0x104f8e575*/
        }
        if ( v38 != nullptr && _InterlockedExchangeAdd64(v38 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8e58d*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v38 + 16))(a1: v38); /*0x104f8e595*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v38); /*0x104f8e59b*/
        }
      }
      else
      {
        v37 = 0; /*0x104f8e56d*/
      }
      if ( *((_DWORD *)a1 + 2) == 1 /*0x104f8e5cf*/
        || (v41 = (RBX::EngineContext *)((char *)v49 + 1720),
            RBX::SurfaceGuiBaseProp::getAdornee(this: (RBX::EngineContext *)((char *)v49 + 1720)) != 0)
        && RBX::SurfaceGuiBaseProp::getAdornee(this: v41) != v37 )
      {
        v57 = 0x3F800000u; /*0x104f8e5eb*/
        v58 = 0x3F800000u; /*0x104f8e5ee*/
        v59 = 1065353216; /*0x104f8e5f2*/
        v60 = v50; /*0x104f8e5fc*/
        v42 = v54 + v51; /*0x104f8e614*/
        v61 = v51; /*0x104f8e619*/
        _mm_storel_ps((double *)&v62, _mm_add_ps((__m128)v53, (__m128)*(unsigned __int64 *)&v50)); /*0x104f8e620*/
        *(float *)&v63 = v42; /*0x104f8e623*/
        RBX::CoordinateFrame::lookAt(this: (RBX::CoordinateFrame *)&v57, a2: (const RBX::Vector3 *)&v62); /*0x104f8e628*/
        RBX::SurfaceGuiBase::getPart(this: (RBX::SurfaceGuiBase *)&v62); /*0x104f8e638*/
        v45 = v62; /*0x104f8e63d*/
        if ( v62 != nullptr ) /*0x104f8e644*/
        {
          v46 = *((_QWORD *)v62 + 3); /*0x104f8e646*/
          v47 = RBX::Reflection::Class_getDescriptorPtr<RBX::BasePart>(a1: v43, a2: v44); /*0x104f8e64a*/
          if ( *(unsigned __int16 *)(v46 + 440) - (unsigned int)*(unsigned __int16 *)(v47 + 440) > *(unsigned __int16 *)(v47 + 442) ) /*0x104f8e66b*/
            v45 = nullptr; /*0x104f8e66b*/
        }
        else
        {
          v45 = nullptr; /*0x104f8e671*/
        }
        v48 = v63; /*0x104f8e674*/
        if ( v63 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v63 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8e68e*/
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v48 + 16LL))(a1: v48); /*0x104f8e697*/
          std::__shared_weak_count::__release_weak(this: v48); /*0x104f8e69d*/
        }
        RBX::VRService::notifyPointerHit(this: v24, a2: (const RBX::CoordinateFrame *)&v57, a3: v45); /*0x104f8e6af*/
      }
      return a1; /*0x104f8e3df*/
    }
  }
  *(_QWORD *)a1 = 0; /*0x104f8e3c7*/
LABEL_38:
  *((_DWORD *)a1 + 2) = 0; /*0x104f8e3ce*/
  v30 = 0; /*0x104f8e3d5*/
LABEL_39:
  *((_OWORD *)a1 + 1) = v30; /*0x104f8e3d8*/
  return a1; /*0x104f8e3d8*/
}

// Address: 0x104f8e7ac | Name: __ZN3RBX9Workspace32processConvexDecompDebuggerEventERKNSt3__110shared_ptrINS_11InputObjectEEE
__int64 __fastcall RBX::Workspace::processConvexDecompDebuggerEvent(
        __int64 a1,
        RBX::DecompDebugVisualizer **a2,
        RBX::InputObject **a3)
{
  RBX::DecompDebugVisualizer *v6; // rax
  RBX::InputObject *v7; // rdi
  int v8; // eax
  int v9; // ecx
  float v10; // xmm1_4
  int v11; // r13d
  int v12; // r12d
  char ModCodes; // al
  RBX::DecompDebugVisualizer *v14; // rdi
  int v15; // r12d
  int v16; // eax
  int v18; // eax

  v6 = a2[239]; /*0x104f8e7c3*/
  v7 = *a3; /*0x104f8e7ca*/
  if ( v6 == nullptr ) /*0x104f8e7d0*/
  {
    if ( *((_DWORD *)v7 + 51) == 8 ) /*0x104f8e7d9*/
    {
      v8 = *((_DWORD *)v7 + 50); /*0x104f8e7db*/
      if ( v8 != 2 && v8 != 4 && *((_DWORD *)v7 + 49) == 289 && (RBX::InputObject::getModCodes(this: v7) & 0xCC0) != 0 ) /*0x104f8e801*/
        RBX::Workspace::createConvexDecompVisualizer(this: (RBX::Workspace *)a2); /*0x104f8e806*/
    }
    v6 = a2[239]; /*0x104f8e80b*/
    if ( v6 == nullptr ) /*0x104f8e815*/
    {
      v15 = 0; /*0x104f8e8c1*/
      goto LABEL_24; /*0x104f8e8c1*/
    }
    v7 = *a3; /*0x104f8e81b*/
  }
  v9 = *((_DWORD *)v7 + 51); /*0x104f8e81e*/
  if ( (*((_BYTE *)v6 + 64) & (v9 == 3)) == 1 ) /*0x104f8e830*/
  {
    RBX::InputObject::getRawPosition(this: v7); /*0x104f8e832*/
    v11 = (int)v10; /*0x104f8e837*/
    v12 = 10 * (int)v10; /*0x104f8e851*/
    if ( (RBX::InputObject::getModCodes(this: *a3) & 0xCC0) == 0 ) /*0x104f8e855*/
      v12 = v11; /*0x104f8e855*/
    ModCodes = RBX::InputObject::getModCodes(this: *a3); /*0x104f8e85c*/
    v14 = a2[239]; /*0x104f8e861*/
    if ( (ModCodes & 3) != 0 ) /*0x104f8e86d*/
      RBX::DecompDebugVisualizer::scrollEdges(this: v14, a2: v12); /*0x104f8e86f*/
    else
      RBX::DecompDebugVisualizer::scrollFrames(this: v14, a2: v12); /*0x104f8e8b4*/
    goto LABEL_22; /*0x104f8e874*/
  }
  v15 = 0; /*0x104f8e876*/
  if ( v9 == 8 ) /*0x104f8e87c*/
  {
    v16 = *((_DWORD *)v7 + 50); /*0x104f8e87e*/
    if ( v16 != 2 && v16 != 4 ) /*0x104f8e88c*/
    {
      if ( *((_DWORD *)v7 + 49) == 289 ) /*0x104f8e898*/
      {
        if ( (RBX::InputObject::getModCodes(this: v7) & 0xCC0) != 0 ) /*0x104f8e8a4*/
        {
          RBX::DecompDebugVisualizer::toggleVisible(this: a2[239]); /*0x104f8e8ad*/
LABEL_22:
          v15 = 1; /*0x104f8e8b9*/
          goto LABEL_24; /*0x104f8e8bf*/
        }
        v7 = *a3; /*0x104f8e8e8*/
        if ( *((_DWORD *)*a3 + 51) != 8 ) /*0x104f8e8f2*/
          goto LABEL_24; /*0x104f8e8f2*/
      }
      v18 = *((_DWORD *)v7 + 50); /*0x104f8e8f4*/
      if ( v18 != 2 && v18 != 4 && *((_DWORD *)v7 + 49) == 117 && (RBX::InputObject::getModCodes(this: v7) & 0xCC0) != 0 ) /*0x104f8e917*/
      {
        RBX::DecompDebugVisualizer::toggleMode(this: a2[239]); /*0x104f8e920*/
        goto LABEL_22; /*0x104f8e925*/
      }
    }
  }
LABEL_24:
  *(_DWORD *)a1 = v15; /*0x104f8e8c4*/
  *(_QWORD *)(a1 + 4) = 0; /*0x104f8e8c7*/
  *(_OWORD *)(a1 + 16) = 0; /*0x104f8e8d2*/
  return a1; /*0x104f8e8dd*/
}

// Address: 0x104f8e928 | Name: __ZN3RBX9Workspace11processCoreERKNSt3__110shared_ptrINS_11InputObjectEEE
__int64 __fastcall RBX::Workspace::processCore(__int64 a1, RBX::ServiceProvider *a2, RBX::InputObject **a3)
{
  __int64 v7; // [rsp+0h] [rbp-40h] BYREF
  int v8; // [rsp+8h] [rbp-38h]
  std::__shared_weak_count *v9[2]; // [rsp+10h] [rbp-30h]

  if ( (unsigned __int8)FLog::MouseCommand >= 6u && BYTE1(FLog::MouseCommand) >= 3u )
    FLog::FastLog(
      a1: *(_QWORD *)&FLog::MouseCommand,
      a2: qword_10D7F3CF8,
      a3: "[FLog::MouseCommand] Workspace::ProcessCore, eventType: %u",
      *((_DWORD *)*a3 + 51));
  RBX::Workspace::handleSurfaceGui(a1: (RBX::VRService *)&v7, a2, a3, a4: 1u); /*0x104f8e98c*/
  if ( (_DWORD)v7 == 1 ) /*0x104f8e996*/
  {
    *(_DWORD *)(a1 + 8) = v8; /*0x104f8e99b*/
    *(_QWORD *)a1 = v7; /*0x104f8e9a2*/
    *(_OWORD *)(a1 + 16) = *(_OWORD *)v9; /*0x104f8e9a9*/
  }
  else
  {
    *(_QWORD *)a1 = 0; /*0x104f8e9af*/
    *(_DWORD *)(a1 + 8) = 0; /*0x104f8e9b6*/
    *(_OWORD *)(a1 + 16) = 0; /*0x104f8e9c0*/
    if ( v9[1] != nullptr ) /*0x104f8e9cb*/
      std::__shared_weak_count::__release_weak(this: v9[1]); /*0x104f8e9cd*/
  }
  return a1; /*0x104f8e9d5*/
}

// Address: 0x104f8e9e2 | Name: __ZNK3RBX9Workspace16wantsToGrabEventENSt3__110shared_ptrIKNS_11InputObjectEEE
__int64 __fastcall RBX::Workspace::wantsToGrabEvent(RBX::ServiceProvider *a1, const RBX::Instance *a2)
{
  RBX::ServiceProvider *ServiceProvider; // rax
  __int64 v5; // rax
  __int64 v6; // rcx
  char v7; // r13
  std::__shared_weak_count *v8; // r15
  __int64 v9; // rdi
  __int64 v10; // rdi
  __int64 v11; // rax
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v14[2]; // [rsp+0h] [rbp-50h] BYREF
  std::__shared_weak_count *v15[2]; // [rsp+10h] [rbp-40h] BYREF

  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: a1, a2); /*0x104f8e9f9*/
  if ( ServiceProvider == nullptr ) /*0x104f8ea01*/
    goto LABEL_9; /*0x104f8ea01*/
  v5 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::UIDragDetectorService>(this: ServiceProvider); /*0x104f8ea06*/
  if ( v5 == 0 ) /*0x104f8ea0e*/
    goto LABEL_9; /*0x104f8ea0e*/
  v6 = *((_QWORD *)a2 + 1); /*0x104f8ea10*/
  *(_OWORD *)v14 = *(_OWORD *)a2; /*0x104f8ea17*/
  if ( v6 != 0 ) /*0x104f8ea1e*/
    _InterlockedIncrement64((volatile signed __int64 *)(v6 + 8)); /*0x104f8ea20*/
  v7 = RBX::UIDragDetectorService::wantsToGrabInWorkspace(a1: v5, a2: v14); /*0x104f8ea34*/
  v8 = v14[1]; /*0x104f8ea37*/
  if ( v14[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8ea50*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x104f8ea58*/
    std::__shared_weak_count::__release_weak(this: v8); /*0x104f8ea5e*/
  }
  LOBYTE(v8) = 1; /*0x104f8ea63*/
  if ( v7 == 0 ) /*0x104f8ea69*/
  {
LABEL_9:
    v9 = *((_QWORD *)a1 + 257); /*0x104f8ea6b*/
    if ( v9 != 0 && RBX::MouseCommand::captured(a1: v9, (__int64 *)a2) != 0 ) /*0x104f8ea81*/
    {
      v10 = *((_QWORD *)a1 + 257); /*0x104f8ea83*/
      v11 = *((_QWORD *)a2 + 1); /*0x104f8ea8a*/
      *(_OWORD *)v15 = *(_OWORD *)a2; /*0x104f8ea91*/
      if ( v11 != 0 ) /*0x104f8ea98*/
        _InterlockedIncrement64((volatile signed __int64 *)(v11 + 8)); /*0x104f8ea9a*/
      LODWORD(v8) = (*(__int64 (__fastcall **)(__int64, std::__shared_weak_count **))(*(_QWORD *)v10 + 248LL))( /*0x104f8eaaf*/
                      a1: v10,
                      a2: v15);
      v12 = v15[1]; /*0x104f8eab2*/
      if ( v15[1] != nullptr /*0x104f8eacb*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v15[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x104f8ead3*/
        std::__shared_weak_count::__release_weak(this: v12); /*0x104f8ead9*/
      }
    }
    else
    {
      LODWORD(v8) = 0; /*0x104f8eae0*/
    }
  }
  return (unsigned int)v8; /*0x104f8eae6*/
}

// Address: 0x104f8eb0a | Name: __ZNK3RBX9Workspace18getUnavailableKeysENSt3__110shared_ptrIKNS_11InputObjectEEE
_OWORD *__fastcall RBX::Workspace::getUnavailableKeys(_OWORD *a1, __int64 a2, __int64 *a3)
{
  __int64 v4; // rdi
  __int64 v7; // rsi
  __int64 v8; // rax
  std::__shared_weak_count *v9; // r14
  std::__shared_weak_count *v11[2]; // [rsp+0h] [rbp-30h] BYREF

  v4 = *(_QWORD *)(a2 + 2056); /*0x104f8eb1a*/
  if ( v4 != 0 && RBX::MouseCommand::captured(a1: v4, a2: a3) != 0 ) /*0x104f8eb36*/
  {
    v7 = *(_QWORD *)(a2 + 2056); /*0x104f8eb38*/
    v8 = a3[1]; /*0x104f8eb3f*/
    *(_OWORD *)v11 = *(_OWORD *)a3; /*0x104f8eb47*/
    if ( v8 != 0 ) /*0x104f8eb4e*/
      _InterlockedIncrement64((volatile signed __int64 *)(v8 + 8)); /*0x104f8eb50*/
    (*(void (__fastcall **)(_OWORD *, __int64, std::__shared_weak_count **))(*(_QWORD *)v7 + 272LL))( /*0x104f8eb5f*/
      a1,
      a2: v7,
      a3: v11);
    v9 = v11[1]; /*0x104f8eb65*/
    if ( v11[1] != nullptr /*0x104f8eb7e*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v11[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x104f8eb86*/
      std::__shared_weak_count::__release_weak(this: v9); /*0x104f8eb8c*/
    }
  }
  else
  {
    *a1 = 0; /*0x104f8eb96*/
  }
  return a1; /*0x104f8eb9c*/
}

// Address: 0x104f8ebbc | Name: __ZN3RBX9Workspace7processERKNSt3__110shared_ptrINS_11InputObjectEEE
__int64 __fastcall RBX::Workspace::process(__int64 a1, RBX::ServiceProvider *a2, RBX::InputObject **a3)
{
  __int64 ServiceProvider; // rax
  RBX::Workspace *v7; // rcx
  std::__shared_weak_count *v8; // rbx
  RBX::IPluginLegacyApi *v9; // rdi
  RBX::InputObject *v10; // rax
  int v11; // eax
  std::__shared_weak_count *v12; // r12
  std::__shared_weak_count *v13; // rax
  unsigned __int64 v14; // rdx
  RBX::InputObject *v15; // r14
  volatile signed __int64 *v16; // r13
  RBX::IPluginLegacyApi *Aligned; // rax
  void *v18; // rsi
  signed __int64 v19; // rax
  void *v20; // rsi
  std::__shared_weak_count *v21; // r12
  RBX::Workspace *v22; // rbx
  RBX::EngineContext *v23; // rdi
  __int64 v24; // rax
  RBX::InputObject *v25; // r13
  __int64 v26; // rax
  std::__shared_weak_count *v27; // r12
  int v28; // eax
  std::__shared_weak_count *v29; // r12
  volatile signed __int64 *v30; // rax
  char v31; // bl
  std::__shared_weak_count *v32; // rsi
  RBX::IPluginLegacyApi **v33; // rdi
  __int64 v34; // rdi
  std::__shared_weak_count *v35; // r13
  int v36; // ecx
  volatile signed __int64 *v37; // rax
  char v38; // bl
  RBX::IPluginLegacyApi **v39; // rdi
  __int128 *v40; // rdi
  int v41; // eax
  std::__shared_weak_count *v42; // r13
  RBX::InputObject *v43; // rax
  char v44; // bl
  std::__shared_weak_count **v45; // rdi
  int v46; // eax
  std::__shared_weak_count *v47; // r13
  RBX::InputObject *v48; // rax
  char v49; // bl
  float v50; // xmm0_4
  std::__shared_weak_count *v51; // rdi
  volatile signed __int64 *v52; // rax
  char v53; // bl
  std::__shared_weak_count *v54; // r12
  bool v55; // cl
  __int64 v56; // rbx
  std::__shared_weak_count *v57; // rdi
  volatile signed __int64 *v58; // rax
  char v59; // r12
  std::__shared_weak_count *v60; // r13
  RBX::Camera *v61; // r13
  std::__shared_weak_count *v62; // r12
  std::__shared_weak_count *v63; // r13
  RBX::InputObject *v64; // rax
  char v65; // bl
  _OWORD *v66; // rdi
  std::__shared_weak_count *v67; // r13
  RBX::IPluginLegacyApi **v68; // rdi
  volatile signed __int64 *v69; // rax
  char v70; // bl
  RBX::IPluginLegacyApi **v71; // rdi
  __int64 v72; // r13
  std::__shared_weak_count *v73; // rdi
  std::__shared_weak_count *v74; // rax
  __int64 v75; // r12
  volatile signed __int64 *v76; // rax
  RBX::Workspace *v77; // rbx
  unsigned __int8 v78; // al
  std::__shared_weak_count *v79; // r12
  volatile signed __int64 *v80; // rax
  char v81; // r15
  std::__shared_weak_count *v82; // r12
  std::__shared_weak_count *v83; // r14
  std::__shared_weak_count *v84; // r14
  _BYTE v86[16]; // [rsp+10h] [rbp-1C0h] BYREF
  _BYTE v87[16]; // [rsp+20h] [rbp-1B0h] BYREF
  _BYTE v88[16]; // [rsp+30h] [rbp-1A0h] BYREF
  _BYTE v89[16]; // [rsp+40h] [rbp-190h] BYREF
  __int128 v90; // [rsp+50h] [rbp-180h] BYREF
  _BYTE v91[16]; // [rsp+60h] [rbp-170h] BYREF
  _BYTE v92[16]; // [rsp+70h] [rbp-160h] BYREF
  _BYTE v93[16]; // [rsp+80h] [rbp-150h] BYREF
  _BYTE v94[16]; // [rsp+90h] [rbp-140h] BYREF
  __int128 v95; // [rsp+A0h] [rbp-130h] BYREF
  __int128 v96; // [rsp+B0h] [rbp-120h] BYREF
  __int128 v97; // [rsp+C0h] [rbp-110h] BYREF
  _QWORD v98[2]; // [rsp+D0h] [rbp-100h] BYREF
  std::__shared_weak_count *v99[2]; // [rsp+E0h] [rbp-F0h] BYREF
  _BYTE v100[32]; // [rsp+F0h] [rbp-E0h] BYREF
  char v101; // [rsp+110h] [rbp-C0h]
  __int64 v102; // [rsp+118h] [rbp-B8h]
  RBX::IPluginLegacyApi *v103[2]; // [rsp+120h] [rbp-B0h] BYREF
  std::__shared_weak_count *v104[2]; // [rsp+130h] [rbp-A0h]
  int v105; // [rsp+14Ch] [rbp-84h]
  std::__shared_weak_count *v106[2]; // [rsp+150h] [rbp-80h]
  RBX::InputObject *v107; // [rsp+160h] [rbp-70h]
  std::__shared_weak_count *v108; // [rsp+168h] [rbp-68h]
  RBX::Workspace *v109; // [rsp+178h] [rbp-58h]
  std::__shared_weak_count *v110[2]; // [rsp+180h] [rbp-50h] BYREF
  RBX::InputObject *v111; // [rsp+190h] [rbp-40h]
  volatile signed __int64 *v112; // [rsp+198h] [rbp-38h]

  if ( (unsigned __int8)FLog::MouseCommand >= 6u && BYTE1(FLog::MouseCommand) >= 3u )
    FLog::FastLog(
      a1: *(_QWORD *)&FLog::MouseCommand,
      a2: qword_10D7F3CF8,
      a3: "[FLog::MouseCommand] Workspace::Process, eventType: %u",
      *((_DWORD *)*a3 + 51));
  if ( *((_QWORD *)a2 + 257) != 0 )
  {
    ServiceProvider = RBX::ServiceProvider::findServiceProvider(this: a2, a2); /*0x104f8ec23*/
    v7 = a2; /*0x104f8ec28*/
    v8 = (std::__shared_weak_count *)(ServiceProvider - 464); /*0x104f8ec2b*/
    if ( ServiceProvider == 0 ) /*0x104f8ec35*/
      v8 = nullptr; /*0x104f8ec35*/
    *(_OWORD *)v99 = 0; /*0x104f8ec3c*/
    v100[0] = 0; /*0x104f8ec45*/
    v105 = 0; /*0x104f8ec4b*/
    v101 = 0; /*0x104f8ec55*/
    v109 = v7; /*0x104f8ec5b*/
    v9 = *((RBX::IPluginLegacyApi **)v7 + 257); /*0x104f8ec5f*/
    if ( v9 != nullptr ) /*0x104f8ec69*/
    {
      v10 = a3[1]; /*0x104f8ec6b*/
      *(_OWORD *)v103 = *(_OWORD *)a3; /*0x104f8ec73*/
      if ( v10 != nullptr ) /*0x104f8ec7d*/
        _InterlockedIncrement64((volatile signed __int64 *)v10 + 1); /*0x104f8ec7f*/
      LOBYTE(v11) = RBX::MouseCommand::captured(a1: (__int64)v9, a2: (__int64 *)v103); /*0x104f8ec8b*/
      v105 = v11; /*0x104f8ec90*/
      v12 = v103[1]; /*0x104f8ec96*/
      if ( v103[1] != nullptr /*0x104f8ecb3*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v103[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x104f8ecbc*/
        std::__shared_weak_count::__release_weak(this: v12); /*0x104f8ecc2*/
      }
    }
    v13 = (std::__shared_weak_count *)RBX::IPluginLegacyApi::get(this: v9); /*0x104f8ecc7*/
    v102 = a1; /*0x104f8eccf*/
    if ( v13 != nullptr ) /*0x104f8ecd6*/
    {
      v106[0] = v13; /*0x104f8ecdc*/
      v106[1] = v8; /*0x104f8ece0*/
      v15 = *a3; /*0x104f8ece4*/
      v107 = *a3; /*0x104f8ece7*/
      v16 = (volatile signed __int64 *)a3[1]; /*0x104f8eceb*/
      v108 = (std::__shared_weak_count *)v16; /*0x104f8ecef*/
      if ( v16 != nullptr ) /*0x104f8ecf6*/
        _InterlockedIncrement64(v16 + 1); /*0x104f8ecf8*/
      *(_OWORD *)v110 = *(_OWORD *)v106; /*0x104f8ed1d*/
      v111 = v15; /*0x104f8ed21*/
      v112 = v16; /*0x104f8ed25*/
      if ( v16 != nullptr ) /*0x104f8ed2c*/
        _InterlockedIncrement64(v16 + 1); /*0x104f8ed2e*/
      Aligned = (RBX::IPluginLegacyApi *)RBX::Memory::allocateAligned(this: (RBX::Memory *)0x20, a2: 8u, a3: v14); /*0x104f8ed45*/
      v103[0] = Aligned; /*0x104f8ed4a*/
      v103[1] = (RBX::IPluginLegacyApi *)32; /*0x104f8ed51*/
      v104[0] = (std::__shared_weak_count *)8; /*0x104f8ed5c*/
      *(_OWORD *)Aligned = *(_OWORD *)v110; /*0x104f8ed6b*/
      *((_QWORD *)Aligned + 2) = v15; /*0x104f8ed6e*/
      *((_QWORD *)Aligned + 3) = v16; /*0x104f8ed72*/
      if ( v16 != nullptr ) /*0x104f8ed80*/
      {
        _InterlockedIncrement64(v16 + 1); /*0x104f8ed86*/
        v104[1] = (std::__shared_weak_count *)((char *)RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<RBX::Workspace::process(std::shared_ptr<RBX::InputObject> const&)::$_0>(RBX::Workspace::process(std::shared_ptr<RBX::InputObject> const&)::$_0)::Callbacks /*0x104f8ed92*/
                                             + 4);
        RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<24ul,8ul>(a1: v100, a2: v103); /*0x104f8eda0*/
        RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v103, a2: v18); /*0x104f8eda8*/
        v19 = _InterlockedExchangeAdd64(v16 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x104f8edb4*/
        a1 = v102; /*0x104f8edbd*/
        if ( v19 == 0 ) /*0x104f8edc4*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v16 + 16))(a1: v16); /*0x104f8edd1*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v16); /*0x104f8edd7*/
        }
      }
      else
      {
        v104[1] = (std::__shared_weak_count *)((char *)RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<RBX::Workspace::process(std::shared_ptr<RBX::InputObject> const&)::$_0>(RBX::Workspace::process(std::shared_ptr<RBX::InputObject> const&)::$_0)::Callbacks /*0x104f8ee68*/
                                             + 4);
        RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<24ul,8ul>(a1: v100, a2: v103); /*0x104f8ee76*/
        RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v103, a2: v20); /*0x104f8ee7e*/
        a1 = v102; /*0x104f8ee83*/
      }
      v101 = 1; /*0x104f8ee8a*/
      v21 = v108; /*0x104f8ee91*/
      if ( v108 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v108 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8eeab*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(a1: v21); /*0x104f8eeb4*/
        std::__shared_weak_count::__release_weak(this: v21); /*0x104f8eeba*/
      }
    }
    v22 = v109; /*0x104f8eec6*/
    RBX::Workspace::handleSurfaceGui(a1: (RBX::VRService *)v103, a2: v109, a3, a4: 0); /*0x104f8eed2*/
    if ( LODWORD(v103[0]) == 1 ) /*0x104f8eede*/
    {
      *(_DWORD *)(a1 + 8) = v103[1]; /*0x104f8eee6*/
      *(RBX::IPluginLegacyApi **)a1 = v103[0]; /*0x104f8eef1*/
      *(_OWORD *)(a1 + 16) = *(_OWORD *)v104; /*0x104f8eefb*/
LABEL_167:
      if ( v101 == 1 ) /*0x104f8fac5*/
        RBX::ScopedExit::~ScopedExit(this: (RBX::ScopedExit *)v100); /*0x104f8face*/
      v84 = v99[1]; /*0x104f8fad3*/
      if ( v99[1] != nullptr /*0x104f8faef*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v99[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v84 + 16LL))(a1: v84); /*0x104f8faf7*/
        std::__shared_weak_count::__release_weak(this: v84); /*0x104f8fafd*/
      }
      return v102; /*0x104f8fb02*/
    }
    v24 = *((_QWORD *)v22 + 258); /*0x104f8ef05*/
    *(_OWORD *)v106 = *(_OWORD *)((char *)v22 + 2056); /*0x104f8ef13*/
    if ( v24 != 0 ) /*0x104f8ef1a*/
      _InterlockedIncrement64((volatile signed __int64 *)(v24 + 8)); /*0x104f8ef1c*/
    v25 = *a3; /*0x104f8ef21*/
    v26 = *((unsigned int *)*a3 + 51); /*0x104f8ef24*/
    if ( (unsigned int)v26 <= 4 ) /*0x104f8ef2e*/
    {
      v110[0] = (std::__shared_weak_count *)RBX::EngineContext::getThreadLocal(this: v23); /*0x104f8ef3d*/
      LODWORD(v110[1]) = 8018; /*0x104f8ef40*/
      RBX::Creatable::createImpl<RBX::InputObject,RBX::ForceConstructionInCreatable &,RBX::InputObject&>( /*0x104f8ef51*/
        a1: &v90,
        a2: v110,
        a3: v25);
      std::shared_ptr<RBX::InputObject>::operator=[abi:ne200100](a1: (char *)v22 + 2088, a2: &v90); /*0x104f8ef6a*/
      v27 = *((std::__shared_weak_count **)&v90 + 1); /*0x104f8ef6f*/
      if ( *((_QWORD *)&v90 + 1) != 0 /*0x104f8ef89*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v90 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v27 + 16LL))(a1: v27); /*0x104f8ef92*/
        std::__shared_weak_count::__release_weak(this: v27); /*0x104f8ef98*/
      }
      RBX::InputObject::setInputType(this: *((RBX::Object **)v22 + 261), a2: 5); /*0x104f8efa6*/
      v25 = *a3; /*0x104f8efab*/
      v26 = *((unsigned int *)*a3 + 51); /*0x104f8efae*/
      v22 = v109; /*0x104f8efb5*/
    }
    switch ( v26 )
    {
      case 0LL:
        v28 = *((_DWORD *)v25 + 50); /*0x104f8efd4*/
        if ( v28 == 2 )
        {
          v67 = v106[0]; /*0x104f8f72f*/
          if ( (unsigned __int8)FLog::UserInputProfile >= 6u && BYTE1(FLog::UserInputProfile) >= 3u )
            FLog::FastLog(
              a1: *(_QWORD *)&FLog::UserInputProfile,
              a2: qword_10D7F3AA0,
              a3: "[FLog::UserInputProfile] Passing left up to processing command: %p",
              v106[0]);
          if ( (unsigned __int8)FLog::MouseCommand >= 6u && BYTE1(FLog::MouseCommand) >= 3u ) /*0x104f8f762*/
            FLog::FastLog( /*0x104f8f77e*/
              a1: *(_QWORD *)&FLog::MouseCommand,
              a2: qword_10D7F3CF8,
              a3: "[FLog::MouseCommand] Processing Mouse up on %p:",
              v67);
          (*(void (__fastcall **)(std::__shared_weak_count **, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v67 + 168LL))( /*0x104f8f791*/
            a1: v110,
            a2: v67,
            a3);
          v95 = *(_OWORD *)v110; /*0x104f8f79f*/
          v68 = (RBX::IPluginLegacyApi **)v109; /*0x104f8f7a9*/
          if ( v110[1] != nullptr ) /*0x104f8f7ad*/
            _InterlockedIncrement64((volatile signed __int64 *)v110[1] + 1); /*0x104f8f7af*/
          RBX::Workspace::setMouseCommand(this: v68, a2: (const RBX::Instance *)&v95, a3: 0); /*0x104f8f7bd*/
          v40 = &v95; /*0x104f8f7c2*/
          goto LABEL_137; /*0x104f8f7c9*/
        }
        if ( v28 == 0 ) /*0x104f8efe6*/
        {
          v29 = v106[0]; /*0x104f8efec*/
          v110[0] = v25; /*0x104f8eff0*/
          v30 = (volatile signed __int64 *)a3[1]; /*0x104f8eff4*/
          v110[1] = (std::__shared_weak_count *)v30; /*0x104f8eff8*/
          if ( v30 != nullptr ) /*0x104f8efff*/
            _InterlockedIncrement64(v30 + 1); /*0x104f8f001*/
          v31 = RBX::MouseCommand::captured(a1: (__int64)v29, a2: (__int64 *)v110); /*0x104f8f012*/
          std::shared_ptr<RBX::InputObject const>::~shared_ptr[abi:ne200100](a1: v110); /*0x104f8f018*/
          if ( v31 == 0 ) /*0x104f8f01f*/
          {
            if ( (unsigned __int8)FLog::MouseCommand >= 6u && BYTE1(FLog::MouseCommand) >= 3u ) /*0x104f8f03d*/
              FLog::FastLog( /*0x104f8f059*/
                a1: *(_QWORD *)&FLog::MouseCommand,
                a2: qword_10D7F3CF8,
                a3: "[FLog::MouseCommand] Processing Mouse down on %p:",
                v29);
            (*(void (__fastcall **)(std::__shared_weak_count **, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v29 + 80LL))( /*0x104f8f06c*/
              a1: v110,
              a2: v29,
              a3);
            v32 = v110[0]; /*0x104f8f06f*/
            v33 = (RBX::IPluginLegacyApi **)v109; /*0x104f8f076*/
            if ( v110[0] != nullptr ) /*0x104f8f07a*/
            {
              if ( *((_DWORD *)*a3 + 52) == 7 ) /*0x104f8f08a*/
              {
                RBX::MouseCommand::getThenClearInstance(this: (RBX::MouseCommand *)&v90, a2: (__int64)v110[0]); /*0x104f8f097*/
                std::shared_ptr<RBX::Instance>::operator=[abi:ne200100](a1: (__int64)v99, a2: &v90); /*0x104f8f0ad*/
                std::shared_ptr<RBX::Instance>::~shared_ptr[abi:ne200100](a1: &v90); /*0x104f8f0b5*/
                v32 = v110[0]; /*0x104f8f0ba*/
                v33 = (RBX::IPluginLegacyApi **)v109; /*0x104f8f0be*/
              }
            }
            else
            {
              v32 = nullptr; /*0x104f8f8bf*/
            }
            v98[0] = v32; /*0x104f8f8c1*/
            v98[1] = v110[1]; /*0x104f8f8cc*/
            if ( v110[1] != nullptr ) /*0x104f8f8d6*/
              _InterlockedIncrement64((volatile signed __int64 *)v110[1] + 1); /*0x104f8f8d8*/
            RBX::Workspace::setMouseCommand(this: v33, a2: (const RBX::Instance *)v98, a3: 0); /*0x104f8f8e6*/
            v40 = (__int128 *)v98; /*0x104f8f8eb*/
            goto LABEL_137; /*0x104f8f8eb*/
          }
        }
        goto LABEL_139; /*0x104f8f01f*/
      case 1LL:
        v41 = *((_DWORD *)v25 + 50); /*0x104f8f1fa*/
        if ( v41 == 2 )
        {
          if ( (unsigned __int8)FLog::UserInputProfile >= 6u && BYTE1(FLog::UserInputProfile) >= 3u ) /*0x104f8f569*/
            FLog::FastLog( /*0x104f8f57d*/
              a1: *(_QWORD *)&FLog::UserInputProfile,
              a2: qword_10D7F3AA0,
              a3: "[FLog::UserInputProfile] Canceling Right Mouse pan",
              0);
          RBX::Workspace::cancelRightMousePan(this: v109); /*0x104f8f586*/
          v61 = (RBX::Camera *)(*(__int64 (__fastcall **)(RBX::Workspace *))(*(_QWORD *)v109 + 928LL))(a1: v109); /*0x104f8f598*/
          if ( v61 != nullptr ) /*0x104f8f59e*/
          {
            if ( (unsigned __int8)FLog::UserInputProfile >= 6u && BYTE1(FLog::UserInputProfile) >= 3u ) /*0x104f8f5b1*/
              FLog::FastLog( /*0x104f8f5c5*/
                a1: *(_QWORD *)&FLog::UserInputProfile,
                a2: qword_10D7F3AA0,
                a3: "[FLog::UserInputProfile] Pushing camera history",
                0);
            RBX::Camera::pushCameraHistoryStack(this: v61); /*0x104f8f5cd*/
          }
          v62 = v106[0]; /*0x104f8f5e6*/
          if ( (unsigned __int8)FLog::UserInputProfile >= 6u && BYTE1(FLog::UserInputProfile) >= 3u )
            FLog::FastLog(
              a1: *(_QWORD *)&FLog::UserInputProfile,
              a2: qword_10D7F3AA0,
              a3: "[FLog::UserInputProfile] Passing right up to processing command: %p",
              v106[0]);
          (*(void (__fastcall **)(_BYTE *, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v62 + 176LL))( /*0x104f8f612*/
            a1: v94,
            a2: v62,
            a3);
          RBX::Workspace::setMouseCommand(this: (RBX::IPluginLegacyApi **)v109, a2: (const RBX::Instance *)v94, a3: 0); /*0x104f8f625*/
          v45 = (std::__shared_weak_count **)v94; /*0x104f8f62a*/
          goto LABEL_138; /*0x104f8f631*/
        }
        if ( v41 == 0 ) /*0x104f8f20c*/
        {
          RBX::Workspace::setRightMousePan(this: v109); /*0x104f8f216*/
          v42 = v106[0]; /*0x104f8f21b*/
          v43 = a3[1]; /*0x104f8f21f*/
          *(_OWORD *)v110 = *(_OWORD *)a3; /*0x104f8f227*/
          if ( v43 != nullptr ) /*0x104f8f22e*/
            _InterlockedIncrement64((volatile signed __int64 *)v43 + 1); /*0x104f8f230*/
          v44 = RBX::MouseCommand::captured(a1: (__int64)v42, a2: (__int64 *)v110); /*0x104f8f241*/
          std::shared_ptr<RBX::InputObject const>::~shared_ptr[abi:ne200100](a1: v110); /*0x104f8f247*/
          if ( v44 == 0 ) /*0x104f8f24e*/
          {
            (*(void (__fastcall **)(_BYTE *, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v42 + 88LL))( /*0x104f8f265*/
              a1: v93,
              a2: v42,
              a3);
            RBX::Workspace::setMouseCommand(this: (RBX::IPluginLegacyApi **)v109, a2: (const RBX::Instance *)v93, a3: 0); /*0x104f8f275*/
            v45 = (std::__shared_weak_count **)v93; /*0x104f8f27a*/
            goto LABEL_138; /*0x104f8f281*/
          }
        }
        goto LABEL_139; /*0x104f8f24e*/
      case 3LL:
        v50 = *((float *)v25 + 55); /*0x104f8f372*/
        if ( v50 > 0.0 ) /*0x104f8f381*/
        {
          (*(void (__fastcall **)(_BYTE *, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v106[0] + 184LL))( /*0x104f8f398*/
            a1: v88,
            a2: v106[0],
            a3);
          v45 = (std::__shared_weak_count **)v88; /*0x104f8f39e*/
          goto LABEL_138; /*0x104f8f3a5*/
        }
        if ( v50 >= 0.0 ) /*0x104f8f4b9*/
          goto LABEL_139; /*0x104f8f4b9*/
        (*(void (__fastcall **)(_BYTE *, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v106[0] + 192LL))( /*0x104f8f4d0*/
          a1: v89,
          a2: v106[0],
          a3);
        v45 = (std::__shared_weak_count **)v89; /*0x104f8f4d6*/
        goto LABEL_138; /*0x104f8f4dd*/
      case 4LL:
        v51 = v106[0]; /*0x104f8f3aa*/
        v110[0] = v25; /*0x104f8f3ae*/
        v52 = (volatile signed __int64 *)a3[1]; /*0x104f8f3b2*/
        v110[1] = (std::__shared_weak_count *)v52; /*0x104f8f3b6*/
        if ( v52 != nullptr ) /*0x104f8f3bd*/
          _InterlockedIncrement64(v52 + 1); /*0x104f8f3bf*/
        v53 = RBX::MouseCommand::captured(a1: (__int64)v51, a2: (__int64 *)v110); /*0x104f8f3cd*/
        v54 = v110[1]; /*0x104f8f3cf*/
        if ( v110[1] != nullptr /*0x104f8f3e9*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v110[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v54 + 16LL))(a1: v54); /*0x104f8f3f2*/
          std::__shared_weak_count::__release_weak(this: v54); /*0x104f8f3f8*/
        }
        v55 = (unsigned __int8)FLog::UserInputProfile >= 6u && BYTE1(FLog::UserInputProfile) >= 3u; /*0x104f8f419*/
        v35 = v106[0]; /*0x104f8f41b*/
        if ( v53 != 0 )
        {
          v56 = 152; /*0x104f8f427*/
          if ( v55 )
            FLog::FastLog(
              a1: *(_QWORD *)&FLog::UserInputProfile,
              a2: qword_10D7F3AA0,
              a3: "[FLog::UserInputProfile] Passing mouse move to processing command: %p",
              v106[0]);
        }
        else
        {
          v56 = 112; /*0x104f8f523*/
          if ( v55 )
            FLog::FastLog(
              a1: *(_QWORD *)&FLog::UserInputProfile,
              a2: qword_10D7F3AA0,
              a3: "[FLog::UserInputProfile] Passing mouse hover to processing command: %p",
              v106[0]);
        }
        goto LABEL_99; /*0x104f8f447*/
      case 6LL:
        v57 = v106[0]; /*0x104f8f44c*/
        v110[0] = v25; /*0x104f8f450*/
        v58 = (volatile signed __int64 *)a3[1]; /*0x104f8f454*/
        v110[1] = (std::__shared_weak_count *)v58; /*0x104f8f458*/
        if ( v58 != nullptr ) /*0x104f8f45f*/
          _InterlockedIncrement64(v58 + 1); /*0x104f8f461*/
        v59 = RBX::MouseCommand::captured(a1: (__int64)v57, a2: (__int64 *)v110); /*0x104f8f46f*/
        v60 = v110[1]; /*0x104f8f472*/
        if ( v110[1] != nullptr /*0x104f8f48b*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v110[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v60 + 16LL))(a1: v60); /*0x104f8f494*/
          std::__shared_weak_count::__release_weak(this: v60); /*0x104f8f49a*/
        }
        if ( v59 == 0 ) /*0x104f8f4a2*/
          goto LABEL_139; /*0x104f8f4a2*/
        v56 = 160; /*0x104f8f4a8*/
        v35 = v106[0]; /*0x104f8f4ad*/
        goto LABEL_99; /*0x104f8f4b1*/
      case 7LL:
        v35 = v106[0]; /*0x104f8f108*/
        if ( (*(unsigned __int8 (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v106[0] + 256LL))(a1: v106[0]) != 0 )
        {
          v36 = *((_DWORD *)*a3 + 50); /*0x104f8f124*/
          switch ( v36 )
          {
            case 2:
              if ( (unsigned __int8)FLog::UserInputProfile >= 6u && BYTE1(FLog::UserInputProfile) >= 3u )
                FLog::FastLog(
                  a1: *(_QWORD *)&FLog::UserInputProfile,
                  a2: qword_10D7F3AA0,
                  a3: "[FLog::UserInputProfile] Passing touch end up to processing command: %p",
                  v35);
              (*(void (__fastcall **)(std::__shared_weak_count **, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v35 + 168LL))( /*0x104f8f885*/
                a1: v110,
                a2: v35,
                a3);
              v97 = *(_OWORD *)v110; /*0x104f8f893*/
              v71 = (RBX::IPluginLegacyApi **)v109; /*0x104f8f89d*/
              if ( v110[1] != nullptr ) /*0x104f8f8a1*/
                _InterlockedIncrement64((volatile signed __int64 *)v110[1] + 1); /*0x104f8f8a3*/
              RBX::Workspace::setMouseCommand(this: v71, a2: (const RBX::Instance *)&v97, a3: 0); /*0x104f8f8b1*/
              v40 = &v97; /*0x104f8f8b6*/
              goto LABEL_137; /*0x104f8f8bd*/
            case 1:
              v110[0] = *a3; /*0x104f8f7ce*/
              v69 = (volatile signed __int64 *)a3[1]; /*0x104f8f7d2*/
              v110[1] = (std::__shared_weak_count *)v69; /*0x104f8f7d6*/
              if ( v69 != nullptr ) /*0x104f8f7dd*/
                _InterlockedIncrement64(v69 + 1); /*0x104f8f7df*/
              v70 = RBX::MouseCommand::captured(a1: (__int64)v35, a2: (__int64 *)v110); /*0x104f8f7f0*/
              std::shared_ptr<RBX::InputObject const>::~shared_ptr[abi:ne200100](a1: v110); /*0x104f8f7f6*/
              if ( v70 != 0 )
              {
                v56 = 152; /*0x104f8f81f*/
                if ( (unsigned __int8)FLog::UserInputProfile >= 6u && BYTE1(FLog::UserInputProfile) >= 3u )
                  FLog::FastLog(
                    a1: *(_QWORD *)&FLog::UserInputProfile,
                    a2: qword_10D7F3AA0,
                    a3: "[FLog::UserInputProfile] Passing touch move to processing command: %p",
                    v35);
LABEL_99:
                (*(void (__fastcall **)(std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v35 + v56))( /*0x104f8f53f*/
                  a1: v35,
                  a2: a3);
              }
              break;
            case 0:
              v110[0] = *a3; /*0x104f8f144*/
              v37 = (volatile signed __int64 *)a3[1]; /*0x104f8f148*/
              v110[1] = (std::__shared_weak_count *)v37; /*0x104f8f14c*/
              if ( v37 != nullptr ) /*0x104f8f153*/
                _InterlockedIncrement64(v37 + 1); /*0x104f8f155*/
              v38 = RBX::MouseCommand::captured(a1: (__int64)v35, a2: (__int64 *)v110); /*0x104f8f166*/
              std::shared_ptr<RBX::InputObject const>::~shared_ptr[abi:ne200100](a1: v110); /*0x104f8f16c*/
              if ( v38 == 0 ) /*0x104f8f173*/
              {
                if ( (unsigned __int8)FLog::MouseCommand >= 6u && BYTE1(FLog::MouseCommand) >= 3u ) /*0x104f8f191*/
                  FLog::FastLog( /*0x104f8f1ad*/
                    a1: *(_QWORD *)&FLog::MouseCommand,
                    a2: qword_10D7F3CF8,
                    a3: "[FLog::MouseCommand] Processing Touch begin on %p:",
                    v35);
                (*(void (__fastcall **)(std::__shared_weak_count **, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v35 + 80LL))( /*0x104f8f1c0*/
                  a1: v110,
                  a2: v35,
                  a3);
                v96 = *(_OWORD *)v110; /*0x104f8f1cb*/
                v39 = (RBX::IPluginLegacyApi **)v109; /*0x104f8f1d5*/
                if ( v110[1] != nullptr ) /*0x104f8f1d9*/
                  _InterlockedIncrement64((volatile signed __int64 *)v110[1] + 1); /*0x104f8f1db*/
                RBX::Workspace::setMouseCommand(this: v39, a2: (const RBX::Instance *)&v96, a3: 0); /*0x104f8f1e9*/
                v40 = &v96; /*0x104f8f1ee*/
LABEL_137:
                std::shared_ptr<RBX::MouseCommand>::~shared_ptr[abi:ne200100](a1: v40); /*0x104f8f8f2*/
                v45 = v110; /*0x104f8f8f7*/
                goto LABEL_138; /*0x104f8f8f7*/
              }
              break;
            default:
              break; /*0x104f8f12d*/
          }
LABEL_139:
          if ( (unsigned __int8)FLog::UserInputProfile >= 6u && BYTE1(FLog::UserInputProfile) >= 3u ) /*0x104f8f919*/
            FLog::FastLog( /*0x104f8f92d*/
              a1: *(_QWORD *)&FLog::UserInputProfile,
              a2: qword_10D7F3AA0,
              a3: "[FLog::UserInputProfile] Done with workspace process",
              0);
          v72 = *(_QWORD *)&FLog::MouseCommand; /*0x104f8f939*/
          v73 = v106[0]; /*0x104f8f94e*/
          v74 = *a3; /*0x104f8f952*/
          if ( (unsigned __int8)FLog::MouseCommand < 6u || BYTE1(FLog::MouseCommand) < 3u )
          {
            v77 = v109; /*0x104f8f9cc*/
          }
          else
          {
            v75 = qword_10D7F3CF8; /*0x104f8f959*/
            v110[0] = *a3; /*0x104f8f95d*/
            v76 = (volatile signed __int64 *)a3[1]; /*0x104f8f961*/
            v110[1] = (std::__shared_weak_count *)v76; /*0x104f8f965*/
            v77 = v109; /*0x104f8f96c*/
            if ( v76 != nullptr ) /*0x104f8f970*/
              _InterlockedIncrement64(v76 + 1); /*0x104f8f972*/
            v78 = RBX::MouseCommand::captured(a1: (__int64)v73, a2: (__int64 *)v110); /*0x104f8f97b*/
            FLog::FastLog(a1: v72, a2: v75, a3: "[FLog::MouseCommand] Workspace::Process finish, captured: %u", v78);
            v79 = v110[1]; /*0x104f8f995*/
            if ( v110[1] != nullptr /*0x104f8f9af*/
              && _InterlockedExchangeAdd64((volatile signed __int64 *)v110[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
            {
              (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v79 + 16LL))(a1: v79); /*0x104f8f9b8*/
              std::__shared_weak_count::__release_weak(this: v79); /*0x104f8f9be*/
            }
            v73 = v106[0]; /*0x104f8f9c3*/
            v74 = *a3; /*0x104f8f9c7*/
          }
          v110[0] = v74; /*0x104f8f9d0*/
          v80 = (volatile signed __int64 *)a3[1]; /*0x104f8f9d4*/
          v110[1] = (std::__shared_weak_count *)v80; /*0x104f8f9d8*/
          if ( v80 != nullptr ) /*0x104f8f9df*/
            _InterlockedIncrement64(v80 + 1); /*0x104f8f9e1*/
          v81 = RBX::MouseCommand::captured(a1: (__int64)v73, a2: (__int64 *)v110); /*0x104f8f9ef*/
          v82 = v110[1]; /*0x104f8f9f2*/
          if ( v110[1] != nullptr /*0x104f8fa0c*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v110[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v82 + 16LL))(a1: v82); /*0x104f8fa15*/
            std::__shared_weak_count::__release_weak(this: v82); /*0x104f8fa1b*/
          }
          if ( v81 != 0 || (_BYTE)v105 != 0 ) /*0x104f8fa2c*/
          {
            *(_QWORD *)a1 = 1; /*0x104f8fa2e*/
            *(_DWORD *)(a1 + 8) = 0; /*0x104f8fa35*/
            v66 = (_OWORD *)(a1 + 16); /*0x104f8fa3d*/
LABEL_157:
            RBX::weak_from<RBX::Instance>(a1: v66, a2: v77); /*0x104f8fa41*/
            goto LABEL_162; /*0x104f8fa49*/
          }
          v77 = v99[0]; /*0x104f8fa4b*/
          v66 = (_OWORD *)(a1 + 16); /*0x104f8fa52*/
          if ( v99[0] != nullptr ) /*0x104f8fa59*/
          {
            *(_QWORD *)a1 = 1; /*0x104f8fa5b*/
            *(_DWORD *)(a1 + 8) = 0; /*0x104f8fa62*/
            goto LABEL_157; /*0x104f8fa6a*/
          }
          *(_QWORD *)a1 = 0; /*0x104f8fa6c*/
          *(_DWORD *)(a1 + 8) = 0; /*0x104f8fa73*/
LABEL_161:
          *v66 = 0; /*0x104f8fa7b*/
LABEL_162:
          v83 = v106[1]; /*0x104f8fa81*/
          if ( v106[1] != nullptr /*0x104f8fa9a*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v106[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v83 + 16LL))(a1: v83); /*0x104f8faa2*/
            std::__shared_weak_count::__release_weak(this: v83); /*0x104f8faa8*/
          }
          if ( v104[1] != nullptr ) /*0x104f8fab7*/
            std::__shared_weak_count::__release_weak(this: v104[1]); /*0x104f8fab9*/
          goto LABEL_167; /*0x104f8fab9*/
        }
        v34 = *(_QWORD *)&FLog::MouseCommand; /*0x104f8f4e9*/
        if ( (unsigned __int8)FLog::MouseCommand >= 6u && BYTE1(FLog::MouseCommand) >= 3u ) /*0x104f8f4fa*/
LABEL_48:
          FLog::FastLog(a1: v34, a2: qword_10D7F3CF8, a3: "[FLog::MouseCommand] Return GuiResponse::notSunk", 0); /*0x104f8f0ea*/
        goto LABEL_115; /*0x104f8f103*/
      case 8LL:
        v46 = *((_DWORD *)v25 + 50); /*0x104f8f286*/
        if ( v46 == 2 ) /*0x104f8f290*/
        {
          if ( (unsigned __int8)FLog::MouseCommand >= 6u && BYTE1(FLog::MouseCommand) >= 3u ) /*0x104f8f64e*/
            FLog::FastLog( /*0x104f8f669*/
              a1: *(_QWORD *)&FLog::MouseCommand,
              a2: qword_10D7F3CF8,
              a3: "[FLog::MouseCommand] Handling Key up",
              0);
          v63 = v106[0]; /*0x104f8f66e*/
          (*(void (__fastcall **)(_BYTE *, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v106[0] + 144LL))( /*0x104f8f683*/
            a1: v87,
            a2: v106[0],
            a3);
          std::shared_ptr<RBX::MouseCommand>::~shared_ptr[abi:ne200100](a1: v87); /*0x104f8f690*/
          v64 = a3[1]; /*0x104f8f695*/
          *(_OWORD *)v110 = *(_OWORD *)a3; /*0x104f8f69d*/
          if ( v64 != nullptr ) /*0x104f8f6a4*/
            _InterlockedIncrement64((volatile signed __int64 *)v64 + 1); /*0x104f8f6a6*/
          v65 = RBX::MouseCommand::captured(a1: (__int64)v63, a2: (__int64 *)v110); /*0x104f8f6b7*/
          std::shared_ptr<RBX::InputObject const>::~shared_ptr[abi:ne200100](a1: v110); /*0x104f8f6bd*/
          if ( v65 != 0 ) /*0x104f8f6c4*/
          {
            (*(void (__fastcall **)(_BYTE *, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v63 + 128LL))( /*0x104f8f6d7*/
              a1: v92,
              a2: v63,
              a3);
            RBX::Workspace::setMouseCommand(this: (RBX::IPluginLegacyApi **)v109, a2: (const RBX::Instance *)v92, a3: 0); /*0x104f8f6ea*/
            v45 = (std::__shared_weak_count **)v92; /*0x104f8f6ef*/
            goto LABEL_138; /*0x104f8f6f6*/
          }
        }
        else
        {
          if ( v46 == 4 ) /*0x104f8f299*/
            goto LABEL_139; /*0x104f8f299*/
          if ( (unsigned __int8)FLog::MouseCommand >= 6u && BYTE1(FLog::MouseCommand) >= 3u ) /*0x104f8f2b7*/
            FLog::FastLog( /*0x104f8f2d2*/
              a1: *(_QWORD *)&FLog::MouseCommand,
              a2: qword_10D7F3CF8,
              a3: "[FLog::MouseCommand] Handling Key down",
              0);
          v47 = v106[0]; /*0x104f8f2d7*/
          (*(void (__fastcall **)(_BYTE *, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v106[0] + 136LL))( /*0x104f8f2ec*/
            a1: v86,
            a2: v106[0],
            a3);
          std::shared_ptr<RBX::MouseCommand>::~shared_ptr[abi:ne200100](a1: v86); /*0x104f8f2f9*/
          v48 = a3[1]; /*0x104f8f2fe*/
          *(_OWORD *)v110 = *(_OWORD *)a3; /*0x104f8f306*/
          if ( v48 != nullptr ) /*0x104f8f30d*/
            _InterlockedIncrement64((volatile signed __int64 *)v48 + 1); /*0x104f8f30f*/
          v49 = RBX::MouseCommand::captured(a1: (__int64)v47, a2: (__int64 *)v110); /*0x104f8f320*/
          std::shared_ptr<RBX::InputObject const>::~shared_ptr[abi:ne200100](a1: v110); /*0x104f8f326*/
          if ( v49 != 0 ) /*0x104f8f32d*/
          {
            (*(void (__fastcall **)(_BYTE *, std::__shared_weak_count *, RBX::InputObject **))(*(_QWORD *)v47 + 120LL))( /*0x104f8f344*/
              a1: v91,
              a2: v47,
              a3);
            RBX::Workspace::setMouseCommand(this: (RBX::IPluginLegacyApi **)v109, a2: (const RBX::Instance *)v91, a3: 0); /*0x104f8f354*/
            v45 = (std::__shared_weak_count **)v91; /*0x104f8f359*/
LABEL_138:
            std::shared_ptr<RBX::MouseCommand>::~shared_ptr[abi:ne200100](a1: v45); /*0x104f8f8fb*/
            goto LABEL_139; /*0x104f8f8fb*/
          }
        }
LABEL_115:
        *(_QWORD *)a1 = 0; /*0x104f8f6fb*/
        *(_DWORD *)(a1 + 8) = 0; /*0x104f8f702*/
        v66 = (_OWORD *)(a1 + 16); /*0x104f8f70a*/
        goto LABEL_161; /*0x104f8f70e*/
      case 9LL:
        RBX::Workspace::cancelRightMousePan(this: v22); /*0x104f8f368*/
        goto LABEL_139; /*0x104f8f36d*/
      default:
        v34 = *(_QWORD *)&FLog::MouseCommand; /*0x104f8f0ce*/
        if ( (unsigned __int8)FLog::MouseCommand >= 6u && BYTE1(FLog::MouseCommand) >= 3u ) /*0x104f8f0df*/
          goto LABEL_48; /*0x104f8f0e4*/
        goto LABEL_115; /*0x104f8f0e4*/
    }
  }
  if ( (unsigned __int8)FLog::ChangeMouseCommand >= 6u && BYTE1(FLog::ChangeMouseCommand) >= 3u ) /*0x104f8edf6*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x104f8ee40*/
      a1: FLog::ChangeMouseCommand,
      a2: qword_10D7E4810,
      a3: 3,
      a4: (unsigned int)"[FLog::ChangeMouseCommand] Workspace process got nullptr currentCommand",
      a5: 71,
      a6: 1,
      0,
      v103);
  *(_QWORD *)a1 = 0; /*0x104f8ee45*/
  *(_DWORD *)(a1 + 8) = 0; /*0x104f8ee4c*/
  *(_OWORD *)(a1 + 16) = 0; /*0x104f8ee57*/
  return a1; /*0x104f8fb0c*/
}

// Address: 0x104f8fc60 | Name: __ZN3RBX9Workspace37deprecatedSetStreamingEnabledCallbackEb
char __fastcall RBX::Workspace::deprecatedSetStreamingEnabledCallback(RBX::Workspace *this, _BOOL4 a2)
{
  RBX::WorkspaceProp *v4; // r12
  __int64 v5; // r15
  volatile signed __int64 *v6; // r14
  unsigned __int8 v7; // r13
  RBX::ClientSessionTracker::ClientSessionTrackerContext *v8; // rdi
  __int64 Instance; // rax
  __int64 v10; // r8
  __int64 v11; // r9
  RBX::Instance *v12; // rsi
  std::__shared_weak_count *v13; // r13
  RBX::DataModel *v14; // rax
  RBX::DataModel *v15; // r13
  unsigned __int8 v16; // al
  char v17; // al
  const char *v18; // rsi
  char result; // al
  volatile signed __int64 *v20; // [rsp+10h] [rbp-50h]
  bool v21[8]; // [rsp+18h] [rbp-48h] BYREF
  std::__shared_weak_count *v22; // [rsp+20h] [rbp-40h]
  void *v23; // [rsp+28h] [rbp-38h]
  _BOOL4 v24; // [rsp+30h] [rbp-30h]
  char NetworkStreamingEnabled; // [rsp+37h] [rbp-29h]

  v4 = (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */); /*0x104f8fc77*/
  NetworkStreamingEnabled = RBX::WorkspaceProp::getNetworkStreamingEnabled(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f8fc86*/
  v24 = a2; /*0x104f8fc8c*/
  RBX::WorkspaceProp::setNetworkStreamingEnabledSetOnly(this: v4, a2); /*0x104f8fc93*/
  v5 = RBX::ClientSessionTrackerKeys::NetworkStreamingEnabled; /*0x104f8fc9f*/
  v6 = (volatile signed __int64 *)unk_10D512090; /*0x104f8fca2*/
  v20 = (volatile signed __int64 *)unk_10D512090; /*0x104f8fcaa*/
  if ( unk_10D512090 != 0 ) /*0x104f8fcb1*/
    _InterlockedIncrement64((volatile signed __int64 *)(unk_10D512090 + 8LL)); /*0x104f8fcb3*/
  v7 = RBX::WorkspaceProp::getNetworkStreamingEnabled(this: v4); /*0x104f8fcc0*/
  Instance = RBX::ClientSessionTracker::ClientSessionTrackerContext::getInstance(this: v8); /*0x104f8fcc3*/
  *(_QWORD *)v21 = v5; /*0x104f8fcc8*/
  v22 = (std::__shared_weak_count *)v6; /*0x104f8fccc*/
  if ( v6 != nullptr ) /*0x104f8fcd3*/
    _InterlockedIncrement64(v6 + 1); /*0x104f8fcd5*/
  RBX::ClientSessionTracker::ClientSessionTrackerContext::updateClientSessionMetric<bool,false>( /*0x104f8fce7*/
    a1: Instance,
    a2: v21,
    a3: v7,
    a4: 0,
    a5: v10,
    a6: v11);
  v13 = v22; /*0x104f8fcec*/
  if ( v22 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v22 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8fd05*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x104f8fd0e*/
    std::__shared_weak_count::__release_weak(this: v13); /*0x104f8fd14*/
  }
  if ( v20 != nullptr && _InterlockedExchangeAdd64(v20 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8fd32*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v20 + 16))(a1: v20); /*0x104f8fd3b*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v20); /*0x104f8fd41*/
  }
  v14 = RBX::DataModel::get(this, a2: v12); /*0x104f8fd49*/
  if ( v14 != nullptr ) /*0x104f8fd51*/
  {
    v15 = v14; /*0x104f8fd53*/
    if ( RBX::DataModel::isServerLaunchIntent(this: v14) ) /*0x104f8fd59*/
    {
      if ( RBX::DataModel::getShouldSetGlobalTelemetryInfo(this: v15) != 0 ) /*0x104f8fd6c*/
      {
        v16 = RBX::WorkspaceProp::getNetworkStreamingEnabled(this: v4); /*0x104f8fd71*/
        RBX::Analytics::setStreamingEnabled(this: (RBX::Analytics *)v16); /*0x104f8fd79*/
      }
      v17 = RBX::WorkspaceProp::getNetworkStreamingEnabled(this: v4); /*0x104f8fd81*/
      v18 = "disabled"; /*0x104f8fd8d*/
      if ( v17 != 0 ) /*0x104f8fd96*/
        v18 = "enabled"; /*0x104f8fd96*/
      std::string::basic_string[abi:ne200100]<0>(a1: v21, a2: v18); /*0x104f8fda1*/
      RBX::DataModel::setContextAttribute(a1: (__int64)v15, a2: 12, a3: (__int64)v21); /*0x104f8fdb1*/
      if ( v21[0] ) /*0x104f8fdb6*/
        operator delete(a1: v23); /*0x104f8fdc0*/
    }
  }
  result = v24 ^ NetworkStreamingEnabled; /*0x104f8fdc8*/
  if ( v24 != NetworkStreamingEnabled ) /*0x104f8fdc8*/
    return RBX::Object::raisePropertyChanged( /*0x104f8fdda*/
             this,
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_StreamingEnabled);
  return result; /*0x104f8fddf*/
}

// Address: 0x104f8fe24 | Name: __ZThn1056_N3RBX9Workspace37deprecatedSetStreamingEnabledCallbackEb
char __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetStreamingEnabledCallback(
        RBX::Workspace *this,
        _BOOL4 a2)
{
  return RBX::Workspace::deprecatedSetStreamingEnabledCallback(this: (RBX::Workspace *)((char *)this - 1056), a2); /*0x104f8fe2f*/
}

// Address: 0x104f8fe36 | Name: __ZN3RBX9Workspace42deprecatedSetStreamingTargetRadiusCallbackEi
__int64 __fastcall RBX::Workspace::deprecatedSetStreamingTargetRadiusCallback(RBX::Workspace *this, unsigned int a2)
{
  __int64 result; // rax
  int v3; // esi

  result = a2; /*0x104f8fe36*/
  v3 = 2097088; /*0x104f8fe3e*/
  if ( (int)result < 2097088 ) /*0x104f8fe45*/
    v3 = result; /*0x104f8fe45*/
  if ( *((_DWORD *)this + 317) /* +1268: NO 2022 FIELD */ >= (int)result ) /*0x104f8fe4a*/
    v3 = *((_DWORD *)this + 317) /* +1268: NO 2022 FIELD */; /*0x104f8fe4a*/
  if ( v3 != *((_DWORD *)this + 318) /* +1272: NO 2022 FIELD */ ) /*0x104f8fe53*/
  {
    RBX::WorkspaceProp::setStreamingTargetRadiusSetOnly(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */), a2: v3); /*0x104f8fe66*/
    return RBX::Object::raisePropertyChanged( /*0x104f8fe7e*/
             this,
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_StreamingTargetRadius);
  }
  return result; /*0x104f8fe55*/
}

// Address: 0x104f8fe84 | Name: __ZThn1056_N3RBX9Workspace42deprecatedSetStreamingTargetRadiusCallbackEi
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetStreamingTargetRadiusCallback(
        RBX::Workspace *this,
        unsigned int a2)
{
  return RBX::Workspace::deprecatedSetStreamingTargetRadiusCallback(this: (RBX::Workspace *)((char *)this - 1056), a2); /*0x104f8fe8f*/
}

// Address: 0x104f8fe96 | Name: __ZN3RBX9Workspace38transformStreamingTargetRadiusCallbackEi
__int64 __fastcall RBX::Workspace::transformStreamingTargetRadiusCallback(RBX::Workspace *this, int a2)
{
  int v2; // ecx
  __int64 result; // rax

  v2 = *((_DWORD *)this + 317) /* +1268: NO 2022 FIELD */; /*0x104f8fe9a*/
  result = 2097088; /*0x104f8fea0*/
  if ( a2 < 2097088 ) /*0x104f8fea7*/
    result = (unsigned int)a2; /*0x104f8fea7*/
  if ( v2 >= a2 ) /*0x104f8feac*/
    return (unsigned int)v2; /*0x104f8feac*/
  return result; /*0x104f8feaf*/
}

// Address: 0x104f8feb2 | Name: __ZThn1056_N3RBX9Workspace38transformStreamingTargetRadiusCallbackEi
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::transformStreamingTargetRadiusCallback(
        RBX::Workspace *this,
        int a2)
{
  int v2; // ecx
  __int64 result; // rax

  v2 = *((_DWORD *)this + 53) /* +212: NO 2022 FIELD */; /*0x104f8feb6*/
  result = 2097088; /*0x104f8febc*/
  if ( a2 < 2097088 ) /*0x104f8fec3*/
    result = (unsigned int)a2; /*0x104f8fec3*/
  if ( v2 >= a2 ) /*0x104f8fec8*/
    return (unsigned int)v2; /*0x104f8fec8*/
  return result; /*0x104f8fecb*/
}

// Address: 0x104f8fece | Name: __ZN3RBX9Workspace20firePersistentLoadedENSt3__110shared_ptrINS_6PlayerEEE
void __fastcall RBX::Workspace::firePersistentLoaded(__int64 a1, __int64 a2)
{
  __int64 *v4; // rdi
  __int64 v5; // rax
  std::__shared_weak_count *v6; // rbx
  std::__shared_weak_count *v7[2]; // [rsp+10h] [rbp-30h] BYREF
  int RemoteAddressAsRbxAddress; // [rsp+2Ch] [rbp-14h]

  if ( *(_QWORD *)a2 != 0 ) /*0x104f8fee2*/
  {
    RemoteAddressAsRbxAddress = RBX::Player::getRemoteAddressAsRbxAddress(this: *(RBX::Player **)a2); /*0x104f8feec*/
    v4 = RBX::WorkspaceEvents::event_PersistentLoaded; /*0x104f8fef6*/
    v5 = *(_QWORD *)(a2 + 8); /*0x104f8fef9*/
    *(_OWORD *)v7 = *(_OWORD *)a2; /*0x104f8ff01*/
    if ( v5 != 0 ) /*0x104f8ff08*/
      _InterlockedIncrement64((volatile signed __int64 *)(v5 + 8)); /*0x104f8ff0a*/
    ((void (__fastcall *)(__int64 *, __int64, std::__shared_weak_count **))RBX::Reflection::RemoteEventDesc<RBX::Workspace,void ()(std::shared_ptr<RBX::Player>),rbx::remote_signal<void ()(std::shared_ptr<RBX::Player>)>,rbx::remote_signal<void ()(std::shared_ptr<RBX::Player>)> RBX::Workspace::*>::fireAndReplicateEvent)( /*0x104f8ff28*/
      a1: v4,
      a2: a1,
      a3: v7);
    v6 = v7[1]; /*0x104f8ff2d*/
    if ( v7[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v7[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f8ff46*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x104f8ff4e*/
      std::__shared_weak_count::__release_weak(this: v6); /*0x104f8ff54*/
    }
  }
}

// Address: 0x104f90060 | Name: __ZN3RBX9Workspace39deprecatedSetStreamingMinRadiusCallbackEi
__int64 __fastcall RBX::Workspace::deprecatedSetStreamingMinRadiusCallback(RBX::Workspace *this, unsigned int a2)
{
  __int64 result; // rax
  bool v3; // cc
  int v4; // esi
  RBX::WorkspaceProp *v6; // r14
  int v7; // esi

  result = 2097088; /*0x104f90067*/
  if ( a2 < 0x1FFFC0 ) /*0x104f9006e*/
    result = a2; /*0x104f9006e*/
  v3 = (int)a2 < 65; /*0x104f90071*/
  v4 = 64; /*0x104f90074*/
  if ( !v3 ) /*0x104f90079*/
    v4 = result; /*0x104f90079*/
  if ( v4 != *((_DWORD *)this + 317) /* +1268: NO 2022 FIELD */ ) /*0x104f90082*/
  {
    v6 = (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */); /*0x104f90087*/
    RBX::WorkspaceProp::setStreamingMinRadiusSetOnly(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */), a2: v4); /*0x104f90091*/
    result = RBX::Object::raisePropertyChanged( /*0x104f900a3*/
               this,
               a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_StreamingMinRadius);
    v7 = *((_DWORD *)this + 317) /* +1268: NO 2022 FIELD */; /*0x104f900a8*/
    if ( *((_DWORD *)this + 318) /* +1272: NO 2022 FIELD */ < v7 ) /*0x104f900b4*/
    {
      RBX::WorkspaceProp::setStreamingTargetRadiusSetOnly(this: v6, a2: v7); /*0x104f900b9*/
      return RBX::Object::raisePropertyChanged( /*0x104f900cf*/
               this,
               a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_StreamingTargetRadius);
    }
  }
  return result; /*0x104f900cb*/
}

// Address: 0x104f900da | Name: __ZThn1056_N3RBX9Workspace39deprecatedSetStreamingMinRadiusCallbackEi
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetStreamingMinRadiusCallback(
        RBX::Workspace *this,
        unsigned int a2)
{
  return RBX::Workspace::deprecatedSetStreamingMinRadiusCallback(this: (RBX::Workspace *)((char *)this - 1056), a2); /*0x104f900e5*/
}

// Address: 0x104f900ec | Name: __ZN3RBX9Workspace35transformStreamingMinRadiusCallbackEi
__int64 __fastcall RBX::Workspace::transformStreamingMinRadiusCallback(RBX::Workspace *this, int a2)
{
  unsigned int v2; // ecx
  __int64 result; // rax

  v2 = 2097088; /*0x104f900f0*/
  if ( (unsigned int)a2 < 0x1FFFC0 ) /*0x104f900f7*/
    v2 = a2; /*0x104f900f7*/
  result = 64; /*0x104f900fd*/
  if ( a2 >= 65 ) /*0x104f90102*/
    return v2; /*0x104f90102*/
  return result; /*0x104f90105*/
}

// Address: 0x104f90108 | Name: __ZThn1056_N3RBX9Workspace35transformStreamingMinRadiusCallbackEi
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::transformStreamingMinRadiusCallback(
        RBX::Workspace *this,
        int a2)
{
  unsigned int v2; // ecx
  __int64 result; // rax

  v2 = 2097088; /*0x104f9010c*/
  if ( (unsigned int)a2 < 0x1FFFC0 ) /*0x104f90113*/
    v2 = a2; /*0x104f90113*/
  result = 64; /*0x104f90119*/
  if ( a2 >= 65 ) /*0x104f9011e*/
    return v2; /*0x104f9011e*/
  return result; /*0x104f90121*/
}

// Address: 0x104f90124 | Name: __ZN3RBX9Workspace40postPropSignalStreamingMinRadiusCallbackEv
__int64 __fastcall RBX::Workspace::postPropSignalStreamingMinRadiusCallback(RBX::Workspace *this)
{
  int v1; // esi
  __int64 result; // rax

  v1 = *((_DWORD *)this + 317) /* +1268: NO 2022 FIELD */; /*0x104f90124*/
  if ( *((_DWORD *)this + 318) /* +1272: NO 2022 FIELD */ < v1 ) /*0x104f90130*/
  {
    RBX::WorkspaceProp::setStreamingTargetRadiusSetOnly(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */), a2: v1); /*0x104f90142*/
    return RBX::Object::raisePropertyChanged( /*0x104f9015a*/
             this,
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_StreamingTargetRadius);
  }
  return result; /*0x104f9015f*/
}

// Address: 0x104f90160 | Name: __ZThn1056_N3RBX9Workspace40postPropSignalStreamingMinRadiusCallbackEv
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::postPropSignalStreamingMinRadiusCallback(RBX::Workspace *this)
{
  return RBX::Workspace::postPropSignalStreamingMinRadiusCallback(this: (RBX::Workspace *)((char *)this - 1056)); /*0x104f9016b*/
}

// Address: 0x104f90172 | Name: __ZN3RBX9Workspace39deprecatedSetStreamingPauseModeCallbackENS_5Enums18StreamingPauseModeE
__int64 __fastcall RBX::Workspace::deprecatedSetStreamingPauseModeCallback(__int64 a1)
{
  return RBX::WorkspaceProp::setStreamingIntegrityMode(a1: a1 + 1056); /*0x104f9017d*/
}

// Address: 0x104f90184 | Name: __ZThn1056_N3RBX9Workspace39deprecatedSetStreamingPauseModeCallbackENS_5Enums18StreamingPauseModeE
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetStreamingPauseModeCallback(__int64 a1)
{
  return RBX::WorkspaceProp::setStreamingIntegrityMode(a1); /*0x104f90188*/
}

// Address: 0x104f9018e | Name: __ZN3RBX9Workspace43deprecatedSetStreamingIntegrityModeCallbackENS_5Enums22StreamingIntegrityModeE
__int64 __fastcall RBX::Workspace::deprecatedSetStreamingIntegrityModeCallback(RBX::Object *a1, int a2)
{
  __int64 result; // rax

  if ( *((_DWORD *)a1 + 316) != a2 ) /*0x104f90198*/
  {
    if ( FFlag::DebugForceEnablePauseOutsideLoadedArea != 0 ) /*0x104f901a8*/
      a2 = 3; /*0x104f901a8*/
    *((_DWORD *)a1 + 316) = a2; /*0x104f901ab*/
    return RBX::Object::raisePropertyChanged( /*0x104f901bc*/
             this: a1,
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_StreamingIntegrityMode);
  }
  return result; /*0x104f9019a*/
}

// Address: 0x104f901c2 | Name: __ZThn1056_N3RBX9Workspace43deprecatedSetStreamingIntegrityModeCallbackENS_5Enums22StreamingIntegrityModeE
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetStreamingIntegrityModeCallback(
        __int64 a1,
        int a2)
{
  __int64 result; // rax

  if ( *(_DWORD *)(a1 + 208) != a2 ) /*0x104f901cc*/
  {
    if ( FFlag::DebugForceEnablePauseOutsideLoadedArea != 0 ) /*0x104f901e3*/
      a2 = 3; /*0x104f901e3*/
    *(_DWORD *)(a1 + 208) = a2; /*0x104f901e6*/
    return RBX::Object::raisePropertyChanged( /*0x104f901fa*/
             this: (RBX::Object *)(a1 - 1056),
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_StreamingIntegrityMode);
  }
  return result; /*0x104f901ce*/
}

// Address: 0x104f90200 | Name: __ZN3RBX9Workspace36postSetPhysicsSteppingMethodCallbackEv
__int64 __fastcall RBX::Workspace::postSetPhysicsSteppingMethodCallback(RBX::Workspace *this)
{
  if ( DFFlag::DebugAuroraAllowAdaptiveTimestepping != 0 /*0x104f90238*/
    || FFlag::DebugSimForceAdaptiveTimeStepping == 1
    || FFlag::SAuthWorkspacePropertyEnabled != 1
    || FFlag::SAuthWorkspaceFlagged != 1
    || *((_DWORD *)this + 287) /* +1148: NO 2022 FIELD */ == 1 )
  {
    return RBX::World::setPhysicsSteppingMethod(a1: *((RBX::World **)this + 118), a2: *((_DWORD *)this + 304) /* +1216: NO 2022 FIELD */); /*0x104f9024b*/
  }
  else
  {
    return RBX::World::setPhysicsSteppingMethod(a1: *((RBX::World **)this + 118), a2: 1); /*0x104f9025c*/
  }
}

// Address: 0x104f9025e | Name: __ZThn1056_N3RBX9Workspace36postSetPhysicsSteppingMethodCallbackEv
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::postSetPhysicsSteppingMethodCallback(RBX::Workspace *this)
{
  return RBX::Workspace::postSetPhysicsSteppingMethodCallback(this: (RBX::Workspace *)((char *)this - 1056)); /*0x104f90269*/
}

// Address: 0x104f90270 | Name: __ZNK3RBX9Workspace30isAvatarUnificationModeEnabledEv
bool __fastcall RBX::Workspace::isAvatarUnificationModeEnabled(RBX::Workspace *this)
{
  return *((_DWORD *)this + 288) /* +1152 likely monotonicClock.initialized -- UNVERIFIED */ == 2; /*0x104f9027e*/
}

// Address: 0x104f90280 | Name: __ZN3RBX9Workspace35preSetAvatarUnificationModeCallbackENS_5Enums21AvatarUnificationModeE
void __fastcall RBX::Workspace::preSetAvatarUnificationModeCallback(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5)
{
  int v5; // eax
  __int64 v6; // rax
  __int64 v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // rdi
  __int64 v10; // rsi
  __int64 v11; // r8
  __int64 v12; // r14
  int v13; // eax
  __int64 v14; // rax
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rsi
  __int64 v18; // r8
  __int64 v19; // r9
  __int64 v20; // rbx
  _QWORD v21[4]; // [rsp+0h] [rbp-90h] BYREF
  int v22; // [rsp+20h] [rbp-70h]
  void *v23[3]; // [rsp+30h] [rbp-60h] BYREF
  _BYTE v24[16]; // [rsp+48h] [rbp-48h] BYREF
  void *v25; // [rsp+58h] [rbp-38h]
  __int128 v26; // [rsp+60h] [rbp-30h] BYREF
  void *v27; // [rsp+70h] [rbp-20h]
  _BYTE v28[17]; // [rsp+7Fh] [rbp-11h] BYREF

  if ( DFFlag::AUMPAnalytics == 1 ) /*0x104f90295*/
  {
    memset(v21, 0, sizeof(v21)); /*0x104f902ab*/
    v22 = 1065353216; /*0x104f902b2*/
    v5 = RBX::Reflection::EnumDesc<RBX::Enums::AvatarUnificationMode>::singleton(a1, a2, a3, a4, a5); /*0x104f902b9*/
    RBX::Reflection::EnumDescriptor::_convertToString(this: (RBX::Reflection::EnumDescriptor *)&v26, a2: v5); /*0x104f902c8*/
    std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "OldAUM"); /*0x104f902db*/
    v23[0] = v24; /*0x104f902e4*/
    v6 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x104f902fc*/
           a1: v21,
           a2: v24,
           a3: std::piecewise_construct,
           a4: v23,
           a5: v28);
    v12 = v6 + 40; /*0x104f90304*/
    if ( (*(_BYTE *)(v6 + 40) & 1) != 0 ) /*0x104f9030c*/
      operator delete(a1: *(void **)(v6 + 56)); /*0x104f90312*/
    *(_QWORD *)(v12 + 16) = v27; /*0x104f9031b*/
    *(_OWORD *)v12 = v26; /*0x104f90323*/
    LOWORD(v26) = 0; /*0x104f90327*/
    if ( (v24[0] & 1) != 0 ) /*0x104f90331*/
    {
      operator delete(a1: v25); /*0x104f90337*/
      if ( (v26 & 1) != 0 ) /*0x104f90340*/
        operator delete(a1: v27); /*0x104f90346*/
    }
    v13 = RBX::Reflection::EnumDesc<RBX::Enums::AvatarUnificationMode>::singleton( /*0x104f9034b*/
            a1: v9,
            a2: v10,
            a3: v7,
            a4: v8,
            a5: v11);
    RBX::Reflection::EnumDescriptor::_convertToString(this: (RBX::Reflection::EnumDescriptor *)&v26, a2: v13); /*0x104f90359*/
    std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "NewAUM"); /*0x104f9036c*/
    v23[0] = v24; /*0x104f90375*/
    v14 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x104f9038d*/
            a1: v21,
            a2: v24,
            a3: std::piecewise_construct,
            a4: v23,
            a5: v28);
    v20 = v14 + 40; /*0x104f90395*/
    if ( (*(_BYTE *)(v14 + 40) & 1) != 0 ) /*0x104f9039d*/
      operator delete(a1: *(void **)(v14 + 56)); /*0x104f903a3*/
    *(_QWORD *)(v20 + 16) = v27; /*0x104f903ac*/
    *(_OWORD *)v20 = v26; /*0x104f903b4*/
    LOWORD(v26) = 0; /*0x104f903b7*/
    if ( (v24[0] & 1) != 0 ) /*0x104f903c1*/
    {
      operator delete(a1: v25); /*0x104f903c7*/
      if ( (v26 & 1) != 0 ) /*0x104f903d0*/
        operator delete(a1: v27); /*0x104f903d6*/
    }
    RBX::Analytics::EventIngest::appendAvailableStandardArgs(a1: v21, a2: v17, a3: v15, a4: v16, a5: v18, a6: v19); /*0x104f903e2*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v26, a2: "studio"); /*0x104f903f2*/
    std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "Avatar"); /*0x104f90402*/
    std::string::basic_string[abi:ne200100]<0>(a1: v23, a2: "AUMPAnalytics"); /*0x104f90412*/
    RBX::Analytics::EventIngest::sendEventDeferred(a1: &v26, a2: v24, a3: v23, a4: v21); /*0x104f9042a*/
    if ( ((__int64)v23[0] & 1) != 0 ) /*0x104f90433*/
      operator delete(a1: v23[2]); /*0x104f90439*/
    if ( (v24[0] & 1) != 0 ) /*0x104f90442*/
      operator delete(a1: v25); /*0x104f90448*/
    if ( (v26 & 1) != 0 ) /*0x104f90451*/
      operator delete(a1: v27); /*0x104f90457*/
    std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v21); /*0x104f90463*/
  }
}

// Address: 0x104f904d6 | Name: __ZThn1056_N3RBX9Workspace35preSetAvatarUnificationModeCallbackENS_5Enums21AvatarUnificationModeE
void __fastcall `non-virtual thunk to'RBX::Workspace::preSetAvatarUnificationModeCallback(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5)
{
  RBX::Workspace::preSetAvatarUnificationModeCallback(a1: a1 - 1056, a2, a3, a4, a5); /*0x104f904e2*/
}

// Address: 0x104f904e8 | Name: __ZN3RBX9Workspace27luaSetAvatarUnificationModeENS_5Enums21AvatarUnificationModeE
__int64 __fastcall RBX::Workspace::luaSetAvatarUnificationMode(__int64 a1, int a2)
{
  __int64 result; // rax

  if ( *(_DWORD *)(a1 + 1152) != a2 ) /*0x104f904f2*/
    return RBX::WorkspaceProp::setAvatarUnificationMode(this: (RolloutFlag *)(a1 + 1056)); /*0x104f904fe*/
  return result; /*0x104f904f4*/
}

// Address: 0x104f90504 | Name: __ZN3RBX9Workspace33applyRecommendedStreamingSettingsEv
__int64 __fastcall RBX::Workspace::applyRecommendedStreamingSettings(RBX::Workspace *this)
{
  RBX::WorkspaceProp *v2; // rbx
  unsigned int NetworkStreamingEnabled; // r15d

  v2 = (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */); /*0x104f90511*/
  NetworkStreamingEnabled = RBX::WorkspaceProp::getNetworkStreamingEnabled(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f90520*/
  if ( (_BYTE)NetworkStreamingEnabled == 0 ) /*0x104f90525*/
    RBX::WorkspaceProp::setNetworkStreamingEnabled(this: v2, a2: true); /*0x104f9052f*/
  if ( *((_DWORD *)this + 317) /* +1268: NO 2022 FIELD */ == 64 ) /*0x104f9053c*/
  {
    LOBYTE(NetworkStreamingEnabled) = NetworkStreamingEnabled ^ 1; /*0x104f9053e*/
  }
  else
  {
    RBX::WorkspaceProp::setStreamingMinRadius(this: v2, a2: 64); /*0x104f9054c*/
    LOBYTE(NetworkStreamingEnabled) = 1; /*0x104f90551*/
  }
  if ( *((_DWORD *)this + 318) /* +1272: NO 2022 FIELD */ != 1024 ) /*0x104f9055f*/
  {
    RBX::WorkspaceProp::setStreamingTargetRadius(this: v2, a2: 1024); /*0x104f90569*/
    LOBYTE(NetworkStreamingEnabled) = 1; /*0x104f9056e*/
  }
  if ( *((_DWORD *)this + 301) /* +1204: NO 2022 FIELD */ != 2 ) /*0x104f90579*/
  {
    RBX::WorkspaceProp::setModelStreamingBehavior(a1: v2, a2: 2); /*0x104f90583*/
    LOBYTE(NetworkStreamingEnabled) = 1; /*0x104f90588*/
  }
  if ( *((_DWORD *)this + 316) /* +1264: NO 2022 FIELD */ != 3 ) /*0x104f90593*/
  {
    RBX::WorkspaceProp::setStreamingIntegrityMode(a1: v2); /*0x104f9059d*/
    LOBYTE(NetworkStreamingEnabled) = 1; /*0x104f905a2*/
  }
  if ( *((_DWORD *)this + 315) /* +1260: NO 2022 FIELD */ != 2 ) /*0x104f905ad*/
  {
    RBX::WorkspaceProp::setStreamOutBehavior(a1: v2, a2: 2); /*0x104f905b7*/
    LOBYTE(NetworkStreamingEnabled) = 1; /*0x104f905bc*/
  }
  if ( *((_DWORD *)this + 290) /* +1160 likely monotonicClock.lastReceivedTimeUS -- UNVERIFIED */ != 2 ) /*0x104f905c7*/
  {
    RBX::WorkspaceProp::setEnableSLIMAvatars(a1: v2, a2: 2); /*0x104f905d1*/
    LOBYTE(NetworkStreamingEnabled) = 1; /*0x104f905d6*/
  }
  if ( DFFlag::PredictiveStreamingAnalytics == 1 && *((_DWORD *)this + 307) /* +1228: NO 2022 FIELD */ != 1 ) /*0x104f905ed*/
  {
    RBX::WorkspaceProp::setPredictiveStreamingMode(a1: v2, a2: 1); /*0x104f905f7*/
    LOBYTE(NetworkStreamingEnabled) = 1; /*0x104f905fc*/
  }
  return NetworkStreamingEnabled; /*0x104f90606*/
}

// Address: 0x104f9060e | Name: __ZNK3RBX9Workspace21useAnimatorThrottlingEv
char __fastcall RBX::Workspace::useAnimatorThrottling(RBX::Workspace *this)
{
  RBX::Workspace *v1; // rax
  unsigned int v3; // eax
  RBX::Workspace *v5; // [rsp+0h] [rbp-10h] BYREF

  v5 = v1; /*0x104f90613*/
  if ( (_BYTE)`guard variable for'RBX::Workspace::useAnimatorThrottling(void)::_ignore == 0 /*0x104f90658*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Workspace::useAnimatorThrottling(void)::_ignore) != 0 )
  {
    v5 = this; /*0x104f9065e*/
    RBX::CallOnce::detail::call_once_internal<RBX::Workspace::useAnimatorThrottling(void)::$_0>(a1: &v5); /*0x104f90661*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Workspace::useAnimatorThrottling(void)::_ignore); /*0x104f9066d*/
  }
  v3 = *((_DWORD *)this + 289) /* +1156: NO 2022 FIELD */; /*0x104f90628*/
  if ( DFFlag::AnimatorLodOptOutPhase == 1 ) /*0x104f90631*/
  {
    if ( v3 == 1 ) /*0x104f90636*/
      return 0; /*0x104f9063a*/
  }
  else if ( v3 < 2 ) /*0x104f9063f*/
  {
    return 0; /*0x104f9063f*/
  }
  return 1; /*0x104f90647*/
}

// Address: 0x104f90ab8 | Name: __ZNK3RBX9Workspace22useAnimatorRetargetingEv
char __fastcall RBX::Workspace::useAnimatorRetargeting(RBX::Workspace *this)
{
  RBX::Workspace *v1; // rax
  int v3; // ecx
  char result; // al
  RBX::Workspace *v5; // [rsp+0h] [rbp-10h] BYREF

  v5 = v1; /*0x104f90abd*/
  if ( DFFlag::ReportRetargetingStats == 1 /*0x104f90b01*/
    && (_BYTE)`guard variable for'RBX::Workspace::useAnimatorRetargeting(void)::_ignore == 0
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Workspace::useAnimatorRetargeting(void)::_ignore) != 0 )
  {
    v5 = this; /*0x104f90b07*/
    RBX::CallOnce::detail::call_once_internal<RBX::Workspace::useAnimatorRetargeting(void)::$_0>(a1: &v5); /*0x104f90b0a*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Workspace::useAnimatorRetargeting(void)::_ignore); /*0x104f90b16*/
  }
  v3 = *((_DWORD *)this + 312) /* +1248: NO 2022 FIELD */; /*0x104f90ad4*/
  result = 1; /*0x104f90ada*/
  if ( v3 != 2 ) /*0x104f90adf*/
    return DFFlag::WorkspaceAnimatorRetargetingEnabledDefault & (v3 == 0); /*0x104f90ae6*/
  return result; /*0x104f90af0*/
}

// Address: 0x104f90f48 | Name: __ZN3RBX9Workspace31workspaceUseAnimatorRetargetingEPKNS_8InstanceE
char __fastcall RBX::Workspace::workspaceUseAnimatorRetargeting(RBX::Workspace *this, const RBX::Instance *a2)
{
  RBX::DataModel *v2; // rax
  RBX::Workspace *v3; // rdi

  v2 = RBX::DataModel::get(this, a2); /*0x104f90f4c*/
  if ( v2 != nullptr /*0x104f90f6a*/
    && (v3 = *(RBX::Workspace **)RBX::ServiceProvider::refByClass<RBX::Workspace>(this: (RBX::DataModel *)((char *)v2 + 464))) != nullptr )
  {
    return RBX::Workspace::useAnimatorRetargeting(this: v3); /*0x104f90f6d*/
  }
  else
  {
    return 0; /*0x104f90f72*/
  }
}

// Address: 0x104f90f76 | Name: __ZN3RBX9Workspace47deprecatedSetIKControlConstraintSupportCallbackENS_5Enums26IkControlConstraintSupportE
__int64 __fastcall RBX::Workspace::deprecatedSetIKControlConstraintSupportCallback(RBX::Object *a1, int a2)
{
  __int64 result; // rax

  if ( DFFlag::IkControlConstraintSupportProperty == 1 && *((_DWORD *)a1 + 293) != a2 ) /*0x104f90f89*/
  {
    *((_DWORD *)a1 + 293) = a2; /*0x104f90f8d*/
    return RBX::Object::raisePropertyChanged( /*0x104f90f9e*/
             this: a1,
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_IKControlConstraintSupport);
  }
  return result; /*0x104f90f8b*/
}

// Address: 0x104f90fa4 | Name: __ZThn1056_N3RBX9Workspace47deprecatedSetIKControlConstraintSupportCallbackENS_5Enums26IkControlConstraintSupportE
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetIKControlConstraintSupportCallback(
        __int64 a1,
        int a2)
{
  __int64 result; // rax

  if ( DFFlag::IkControlConstraintSupportProperty == 1 && *(_DWORD *)(a1 + 116) != a2 ) /*0x104f90fb4*/
  {
    *(_DWORD *)(a1 + 116) = a2; /*0x104f90fb8*/
    return RBX::Object::raisePropertyChanged( /*0x104f90fcd*/
             this: (RBX::Object *)(a1 - 1056),
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_IKControlConstraintSupport);
  }
  return result; /*0x104f90fb6*/
}

// Address: 0x104f90fd2 | Name: __ZN3RBX9Workspace40filterIKControlConstraintSupportCallbackENS_5Enums26IkControlConstraintSupportE
char RBX::Workspace::filterIKControlConstraintSupportCallback()
{
  return DFFlag::IkControlConstraintSupportProperty ^ 1; /*0x104f90fde*/
}

// Address: 0x104f90fe0 | Name: __ZThn1056_N3RBX9Workspace40filterIKControlConstraintSupportCallbackENS_5Enums26IkControlConstraintSupportE
char `non-virtual thunk to'RBX::Workspace::filterIKControlConstraintSupportCallback()
{
  return DFFlag::IkControlConstraintSupportProperty ^ 1; /*0x104f90fec*/
}

// Address: 0x104f90fee | Name: __ZNK3RBX9Workspace36getIkControlConstraintSupportEnabledEv
char __fastcall RBX::Workspace::getIkControlConstraintSupportEnabled(RBX::Workspace *this)
{
  int v1; // eax

  if ( DFFlag::IkControlConstraintSupportProperty != 1 ) /*0x104f90ff9*/
    return DFFlag::IkControlConstraintSupportDefaultEnabled; /*0x104f90ff9*/
  v1 = *((_DWORD *)this + 293) /* +1172: NO 2022 FIELD */; /*0x104f90ffb*/
  if ( v1 == 2 ) /*0x104f91004*/
    return 1; /*0x104f91019*/
  if ( v1 != 1 ) /*0x104f91009*/
    return DFFlag::IkControlConstraintSupportDefaultEnabled; /*0x104f91014*/
  return 0; /*0x104f91013*/
}

// Address: 0x104f9101e | Name: __ZNK3RBX9Workspace40getPlayerCharacterDestroyBehaviorEnabledEv
char __fastcall RBX::Workspace::getPlayerCharacterDestroyBehaviorEnabled(RBX::Workspace *this)
{
  int v1; // eax

  if ( DFFlag::PlayerCharacterDestroyBehaviorProperty != 1 ) /*0x104f91029*/
    return DFFlag::PlayerCharacterDestroyBehaviorDefaultEnabled; /*0x104f91029*/
  v1 = *((_DWORD *)this + 305) /* +1220: NO 2022 FIELD */; /*0x104f9102b*/
  if ( v1 == 2 ) /*0x104f91034*/
    return 1; /*0x104f91049*/
  if ( v1 != 1 ) /*0x104f91039*/
    return DFFlag::PlayerCharacterDestroyBehaviorDefaultEnabled; /*0x104f91044*/
  return 0; /*0x104f91043*/
}

// Address: 0x104f9104e | Name: __ZNK3RBX9Workspace31getSandboxedInstanceModeEnabledEv
char __fastcall RBX::Workspace::getSandboxedInstanceModeEnabled(RBX::Workspace *this)
{
  if ( DFFlag::SandboxedInstanceModeProperty == 1 && *((_DWORD *)this + 313) /* +1252: NO 2022 FIELD */ == 1 ) /*0x104f91064*/
    return 1; /*0x104f91070*/
  else
    return DFFlag::SandboxedInstanceModeDefaultEnabled; /*0x104f91068*/
}

// Address: 0x104f91074 | Name: __ZNK3RBX9Workspace30getUseNewLuauTypeSolverEnabledEv
char __fastcall RBX::Workspace::getUseNewLuauTypeSolverEnabled(RBX::Workspace *this)
{
  int v1; // eax

  v1 = *((_DWORD *)this + 322) /* +1288 likely pendingSendTouches.impl.empty_key.first -- UNVERIFIED */; /*0x104f91078*/
  if ( v1 == 2 ) /*0x104f91081*/
    return 1; /*0x104f91096*/
  if ( v1 == 1 ) /*0x104f91086*/
    return 0; /*0x104f91092*/
  return DFFlag::UseNewLuauTypeSolverDefaultEnabled; /*0x104f91098*/
}

// Address: 0x104f9109a | Name: __ZNK3RBX9Workspace40getValidateEnabledProximityPromptEnabledEv
char __fastcall RBX::Workspace::getValidateEnabledProximityPromptEnabled(RBX::Workspace *this)
{
  int v1; // eax

  if ( DFFlag::ValidateEnabledProximityPromptThreePhaseRolloutProperty != 1 ) /*0x104f910a5*/
    return DFFlag::ValidateEnabledProximityPromptDefaultEnabled; /*0x104f910a5*/
  v1 = *((_DWORD *)this + 323) /* +1292: NO 2022 FIELD */; /*0x104f910a7*/
  if ( v1 == 2 ) /*0x104f910b0*/
    return 1; /*0x104f910c5*/
  if ( v1 != 1 ) /*0x104f910b5*/
    return DFFlag::ValidateEnabledProximityPromptDefaultEnabled; /*0x104f910c0*/
  return 0; /*0x104f910bf*/
}

// Address: 0x104f910ca | Name: __ZNK3RBX9Workspace29getUseFixedSimulationCallbackEv
__int64 __fastcall RBX::Workspace::getUseFixedSimulationCallback(RBX::Workspace *this)
{
  if ( FFlag::SAuthWorkspacePropertyEnabled == 1 && FFlag::SAuthWorkspaceFlagged == 1 && *((_DWORD *)this + 287) /* +1148: NO 2022 FIELD */ != 1 ) /*0x104f910ea*/
    return 2; /*0x104f910f9*/
  else
    return RBX::WorkspaceProp::getUseFixedSimulationGetOnly(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f910f4*/
}

// Address: 0x104f91100 | Name: __ZNK3RBX9Workspace44getPlayerScriptsUseInputActionSystemCallbackEv
__int64 __fastcall RBX::Workspace::getPlayerScriptsUseInputActionSystemCallback(RBX::Workspace *this)
{
  if ( FFlag::SAuthWorkspacePropertyEnabled == 1 && FFlag::SAuthWorkspaceFlagged == 1 && *((_DWORD *)this + 287) /* +1148: NO 2022 FIELD */ != 1 ) /*0x104f91120*/
    return 2; /*0x104f9112f*/
  else
    return RBX::WorkspaceProp::getPlayerScriptsUseInputActionSystemGetOnly(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f9112a*/
}

// Address: 0x104f91136 | Name: __ZNK3RBX9Workspace43getPlayerScriptsUseInputActionSystemEnabledEv
__int64 __fastcall RBX::Workspace::getPlayerScriptsUseInputActionSystemEnabled(RBX::Workspace *this)
{
  unsigned int v1; // ebx
  int PlayerScriptsUseInputActionSystem; // eax

  LOBYTE(v1) = 1; /*0x104f91143*/
  if ( FFlag::PlayerScripts2IAS == 0 ) /*0x104f91148*/
  {
    if ( FFlag::PlayerScriptsUseInputActionSystemThreePhaseRolloutProperty != 1 ) /*0x104f91151*/
    {
LABEL_5:
      LOBYTE(v1) = FFlag::PlayerScriptsUseInputActionSystemDefault; /*0x104f9116b*/
      return v1; /*0x104f9116b*/
    }
    PlayerScriptsUseInputActionSystem = RBX::WorkspaceProp::getPlayerScriptsUseInputActionSystem(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f9115a*/
    if ( PlayerScriptsUseInputActionSystem != 2 ) /*0x104f91162*/
    {
      if ( PlayerScriptsUseInputActionSystem == 1 ) /*0x104f91167*/
        return 0; /*0x104f9117c*/
      goto LABEL_5; /*0x104f91167*/
    }
  }
  return v1; /*0x104f91177*/
}

// Address: 0x104f9117e | Name: __ZNK3RBX9Workspace29getExplicitAutoJointsCallbackEv
char __fastcall RBX::Workspace::getExplicitAutoJointsCallback(RBX::Workspace *this)
{
  return *(_BYTE *)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 849LL); /*0x104f9118f*/
}

// Address: 0x104f91192 | Name: __ZN3RBX9Workspace39deprecatedSetExplicitAutoJointsCallbackEb
__int64 __fastcall RBX::Workspace::deprecatedSetExplicitAutoJointsCallback(RBX::Workspace *this, char a2)
{
  __int64 result; // rax

  result = RBX::WorkspaceProp::getExplicitAutoJoints(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f911a6*/
  if ( (_BYTE)result != a2 ) /*0x104f911ae*/
  {
    *(_BYTE *)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 849LL) = a2; /*0x104f911b7*/
    return RBX::Object::raisePropertyChanged( /*0x104f911cf*/
             this,
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_ExplicitAutoJoints);
  }
  return result; /*0x104f911cb*/
}

// Address: 0x104f911da | Name: __ZThn1056_N3RBX9Workspace39deprecatedSetExplicitAutoJointsCallbackEb
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetExplicitAutoJointsCallback(
        RBX::Workspace *this,
        char a2)
{
  return RBX::Workspace::deprecatedSetExplicitAutoJointsCallback(this: (RBX::Workspace *)((char *)this - 1056), a2); /*0x104f911e5*/
}

// Address: 0x104f911ec | Name: __ZN3RBX9Workspace38deprecatedSetTerrainWeldsFixedCallbackEb
__int64 __fastcall RBX::Workspace::deprecatedSetTerrainWeldsFixedCallback(RBX::Workspace *this, char a2)
{
  __int64 result; // rax

  result = RBX::WorkspaceProp::getTerrainWeldsFixed(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f91200*/
  if ( (_BYTE)result != a2 ) /*0x104f91208*/
  {
    *((_BYTE *)this + 952) /* +952: NO 2022 FIELD */ = a2; /*0x104f9120a*/
    return RBX::Object::raisePropertyChanged( /*0x104f91222*/
             this,
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_TerrainWeldsFixed);
  }
  return result; /*0x104f9121e*/
}

// Address: 0x104f9122c | Name: __ZThn1056_N3RBX9Workspace38deprecatedSetTerrainWeldsFixedCallbackEb
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetTerrainWeldsFixedCallback(
        RBX::Workspace *this,
        char a2)
{
  return RBX::Workspace::deprecatedSetTerrainWeldsFixedCallback(this: (RBX::Workspace *)((char *)this - 1056), a2); /*0x104f91237*/
}

// Address: 0x104f9123e | Name: __ZNK3RBX9Workspace38getPathfindingUseImprovedSearchEnabledEv
char __fastcall RBX::Workspace::getPathfindingUseImprovedSearchEnabled(RBX::Workspace *this)
{
  int v1; // eax
  char result; // al

  if ( FFlag::PathfindingUseImprovedSearch != 0 || FFlag::PathfindingUseImprovedSearchOneFlag == 1 ) /*0x104f91258*/
  {
    v1 = *((_DWORD *)this + 303) /* +1212: NO 2022 FIELD */; /*0x104f9125a*/
    if ( v1 == 2 ) /*0x104f91263*/
      return 1; /*0x104f91286*/
    if ( v1 == 1 ) /*0x104f91268*/
      return 0; /*0x104f91284*/
  }
  result = 1; /*0x104f9126c*/
  if ( FFlag::PathfindingUseImprovedSearchDefaultEnabled == 0 ) /*0x104f91275*/
    return FFlag::PathfindingUseImprovedSearchOneFlag; /*0x104f9127e*/
  return result; /*0x104f91288*/
}

// Address: 0x104f9128a | Name: __ZN3RBX9Workspace7joinAllEx
__int64 __fastcall RBX::Workspace::joinAll(RBX::Workspace *this, __int64 a2)
{
  RBX::Workspace *v3; // rbx
  RBX::WorkspaceProp *v4; // r15
  RBX::Instance *v5; // rsi
  bool v6; // zf
  RBX::Instance *v7; // rsi
  RBX::DataModel *v8; // r12
  RBX::DataModel *v9; // rdi
  RBX::DataModel *v10; // rax
  RBX::CSGDictionaryService *v11; // r13
  RBX::NonReplicatedCSGDictionaryService *v12; // r14
  const char *v13; // rdx
  RBX::Workspace *v14; // r15
  _QWORD *i; // rbx
  RBX::PartOperation *v16; // rdi
  volatile signed __int64 *v17; // r12
  __int64 v18; // rdx
  __int64 v19; // rcx
  __int64 v20; // rax
  __int64 v21; // r14
  __int64 v22; // r12
  __int64 v23; // r12
  __int64 v24; // r12
  __int64 v25; // rbx
  __int64 v26; // r13
  int v27; // r15d
  int SurfaceType; // eax
  RBX::Primitive *v29; // rsi
  int v30; // eax
  bool v31; // r9
  const char *v32; // rcx
  const char *v33; // rdx
  __int128 *v35; // [rsp+8h] [rbp-248h] BYREF
  RBX::WorkspaceProp *v36; // [rsp+10h] [rbp-240h]
  __int64 v37; // [rsp+18h] [rbp-238h]
  __int128 v38; // [rsp+20h] [rbp-230h] BYREF
  void *v39; // [rsp+30h] [rbp-220h]
  RBX::Workspace *v40; // [rsp+38h] [rbp-218h]
  void *v41[2]; // [rsp+40h] [rbp-210h] BYREF
  void *v42[2]; // [rsp+50h] [rbp-200h]
  __int128 v43; // [rsp+60h] [rbp-1F0h]

  v3 = this; /*0x104f912a1*/
  v4 = (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */); /*0x104f912b2*/
  LOBYTE(v40) = RBX::WorkspaceProp::getExplicitAutoJoints(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f912c1*/
  v36 = v4; /*0x104f912c7*/
  RBX::WorkspaceProp::setExplicitAutoJoints(this: v4, a2: true); /*0x104f912d6*/
  v6 = *((_QWORD *)v3 + 276) == 0; /*0x104f912db*/
  v37 = a2; /*0x104f912e3*/
  if ( !v6 ) /*0x104f912ea*/
  {
    v8 = RBX::DataModel::get(this: v3, a2: v5); /*0x104f912f8*/
    v9 = (RBX::DataModel *)((char *)v8 + 464); /*0x104f91305*/
    if ( v8 == nullptr ) /*0x104f91308*/
      v9 = nullptr; /*0x104f91308*/
    v10 = RBX::DataModel::get(this: v9, a2: v7); /*0x104f9130c*/
    if ( v10 != nullptr ) /*0x104f91314*/
      v11 = (RBX::CSGDictionaryService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::CSGDictionaryService>(this: (RBX::DataModel *)((char *)v10 + 464)); /*0x104f91324*/
    else
      v11 = nullptr; /*0x104f91329*/
    if ( v8 != nullptr ) /*0x104f9132f*/
      v12 = (RBX::NonReplicatedCSGDictionaryService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::NonReplicatedCSGDictionaryService>(this: (RBX::DataModel *)((char *)v8 + 464)); /*0x104f91339*/
    else
      v12 = nullptr; /*0x104f9133e*/
    RBX::Analytics::InfluxDb::Points::Points(a1: v41, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x104f91351*/
    if ( (RBX::Analytics::placeId & 1) != 0 ) /*0x104f91360*/
      v13 = (const char *)qword_10D510028; /*0x104f91362*/
    else
      v13 = (char *)&RBX::Analytics::placeId + 1; /*0x104f91368*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v41, a2: "PlaceId", a3: v13); /*0x104f91379*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x104f91393*/
      this: (RBX::Analytics::InfluxDb::Points *)v41,
      a2: "Count",
      a3: *((_QWORD *)v3 + 276));
    std::string::basic_string[abi:ne200100]<0>(a1: &v38, a2: "CSGPendingMigrationData"); /*0x104f913a6*/
    RBX::Analytics::InfluxDb::Points::report( /*0x104f913c1*/
      a1: v41,
      a2: &v38,
      a3: (unsigned int)DFInt::CSGPendingMigrationDataHundredthsPercent,
      a4: 0);
    if ( (v38 & 1) != 0 ) /*0x104f913cd*/
      operator delete(a1: v39); /*0x104f913d6*/
    v14 = v3; /*0x104f913db*/
    for ( i = *((_QWORD **)v3 + 275); i != nullptr; i = (_QWORD *)*i ) /*0x104f913de*/
    {
      v16 = (RBX::PartOperation *)i[2]; /*0x104f913ea*/
      *(_QWORD *)&v38 = v16; /*0x104f913ee*/
      v17 = (volatile signed __int64 *)i[3]; /*0x104f913f5*/
      *((_QWORD *)&v38 + 1) = v17; /*0x104f913f9*/
      if ( v17 != nullptr ) /*0x104f91403*/
        _InterlockedIncrement64(v17 + 1); /*0x104f91405*/
      RBX::PartOperation::migrateCSGData(this: v16, a2: v11, a3: v12); /*0x104f91411*/
      if ( v17 != nullptr && _InterlockedExchangeAdd64(v17 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f9142c*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v17 + 16))(a1: v17); /*0x104f91435*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v17); /*0x104f9143b*/
      }
    }
    v3 = v14; /*0x104f91445*/
    std::__hash_table<std::shared_ptr<RBX::PartOperation>,std::hash<std::shared_ptr<RBX::PartOperation>>,std::equal_to<std::shared_ptr<RBX::PartOperation>>,std::allocator<std::shared_ptr<RBX::PartOperation>>>::clear(a1: (char *)v14 + 2184); /*0x104f9144f*/
    RBX::Analytics::InfluxDb::Points::~Points(this: v41); /*0x104f9145b*/
    a2 = v37; /*0x104f91460*/
  }
  RBX::World::joinAll(this: *((RBX::ContactManager ***)v3 + 118)); /*0x104f9146e*/
  if ( (_BYTE)v40 == 0 ) /*0x104f9147a*/
  {
    v40 = v3; /*0x104f91480*/
    v20 = *((_QWORD *)v3 + 118); /*0x104f91487*/
    v21 = *(_QWORD *)(v20 + 616); /*0x104f9148e*/
    v22 = *(_QWORD *)(v20 + 624); /*0x104f91495*/
    v43 = 0; /*0x104f9149f*/
    *(_OWORD *)v42 = 0; /*0x104f914a6*/
    *(_OWORD *)v41 = 0; /*0x104f914ad*/
    v38 = 0; /*0x104f914b4*/
    v39 = nullptr; /*0x104f914bb*/
    v23 = v22 - v21; /*0x104f914c6*/
    if ( v23 != 0 ) /*0x104f914c9*/
    {
      v24 = (v23 >> 3 == 0) + (v23 >> 3); /*0x104f914d7*/
      v25 = 0; /*0x104f914db*/
      do /*0x104f9154d*/
      {
        v26 = *(_QWORD *)(v21 + 8 * v25); /*0x104f914dd*/
        if ( *(_QWORD *)(v26 + 520) == 0 || *(_BYTE *)(v26 + 439) != 5 ) /*0x104f914f3*/
        {
          v27 = 0; /*0x104f914f5*/
          while ( 1 ) /*0x104f914fe*/
          {
            SurfaceType = RBX::Primitive::getSurfaceType(a1: v26, a2: v27); /*0x104f914fe*/
            if ( SurfaceType != 10 && SurfaceType != 0 ) /*0x104f9150a*/
              break; /*0x104f9150a*/
            if ( ++v27 == 6 ) /*0x104f91513*/
              goto LABEL_35; /*0x104f91513*/
          }
          v30 = RBX::BasePart::fromPrimitive(this: (RBX::BasePart *)v26, a2: v29); /*0x104f9151a*/
          RBX::WorldRoot::createAutoJoints( /*0x104f91542*/
            a1: (_DWORD)v40,
            a2: v30,
            a3: 0,
            a4: 0,
            a5: (unsigned int)v41,
            a6: (unsigned int)&v38,
            a7: 0);
        }
LABEL_35:
        ++v25; /*0x104f91547*/
      }
      while ( v25 != v24 ); /*0x104f9154d*/
    }
    RBX::WorldRoot::parentDeferredJoints(a1: v41, a2: &v38, a3: v18, a4: v19); /*0x104f91560*/
    v35 = &v38; /*0x104f9156c*/
    std::vector<std::pair<std::shared_ptr<RBX::JointInstance>,std::shared_ptr<RBX::BasePart>>>::__destroy_vector::operator()[abi:ne200100](a1: &v35); /*0x104f9156f*/
    a2 = v37; /*0x104f9157e*/
    if ( v41[0] != nullptr ) /*0x104f91585*/
    {
      v41[1] = v41[0]; /*0x104f91587*/
      operator delete(a1: v41[0]); /*0x104f9158e*/
    }
    v3 = v40; /*0x104f91593*/
  }
  RBX::WorkspaceProp::setTerrainWeldsFixed(this: v36, a2: true); /*0x104f915a6*/
  if ( a2 > 0 ) /*0x104f915ae*/
  {
    std::to_string(a1: (__int64)v41); /*0x104f915ba*/
    v32 = (const char *)*(int *)(*((_QWORD *)v3 + 118) + 2096LL); /*0x104f915c6*/
    if ( (__int64)v32 > 0 ) /*0x104f915d0*/
    {
      if ( ((__int64)v41[0] & 1) != 0 ) /*0x104f915d9*/
        v33 = (const char *)v42[0]; /*0x104f915db*/
      else
        v33 = (char *)v41 + 1; /*0x104f915e4*/
      RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x104f915fc*/
        this: (RBX::Analytics::Event *)"Studio",
        a2: "AutoJoinJoinAll",
        a3: v33,
        a4: v32,
        a5: 0,
        a6: v31);
    }
    if ( ((__int64)v41[0] & 1) != 0 ) /*0x104f91608*/
      operator delete(a1: v42[0]); /*0x104f91611*/
  }
  return __stack_chk_guard; /*0x104f91626*/
}

// Address: 0x104f916d6 | Name: __ZNK3RBX9Workspace20reportAutoJoinCountsEx
void __fastcall RBX::Workspace::reportAutoJoinCounts(RBX::Workspace *this, __int64 a2)
{
  bool v3; // r9
  int *v4; // rax
  const char *v5; // rcx
  const char *v6; // rdx
  const char *v7; // rcx
  const char *v8; // rdx
  const char *v9; // rcx
  const char *v10; // rdx
  const char *v11; // rcx
  const char *v12; // rdx
  char v13[16]; // [rsp+0h] [rbp-20h] BYREF
  void *v14; // [rsp+10h] [rbp-10h]

  if ( a2 > 0 && *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ != 0 ) /*0x104f916f3*/
  {
    std::to_string(a1: (__int64)v13); /*0x104f916fd*/
    v4 = *((int **)this + 118); /*0x104f91702*/
    v5 = (const char *)v4[525]; /*0x104f91709*/
    if ( (__int64)v5 > 0 ) /*0x104f91713*/
    {
      if ( (v13[0] & 1) != 0 ) /*0x104f91719*/
        v6 = (const char *)v14; /*0x104f9171b*/
      else
        v6 = &v13[1]; /*0x104f91721*/
      RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x104f91736*/
        this: (RBX::Analytics::Event *)"Studio",
        a2: "AutoJoinExplicitApi",
        a3: v6,
        a4: v5,
        a5: 0,
        a6: v3);
      v4 = *((int **)this + 118); /*0x104f9173b*/
    }
    v7 = (const char *)v4[526]; /*0x104f91742*/
    if ( (__int64)v7 > 0 ) /*0x104f9174c*/
    {
      if ( (v13[0] & 1) != 0 ) /*0x104f91752*/
        v8 = (const char *)v14; /*0x104f91754*/
      else
        v8 = &v13[1]; /*0x104f9175a*/
      RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x104f9176f*/
        this: (RBX::Analytics::Event *)"Studio",
        a2: "AutoJoinPropertyChanged",
        a3: v8,
        a4: v7,
        a5: 0,
        a6: v3);
      v4 = *((int **)this + 118); /*0x104f91774*/
    }
    v9 = (const char *)v4[527]; /*0x104f9177b*/
    if ( (__int64)v9 > 0 ) /*0x104f91785*/
    {
      if ( (v13[0] & 1) != 0 ) /*0x104f9178b*/
        v10 = (const char *)v14; /*0x104f9178d*/
      else
        v10 = &v13[1]; /*0x104f91793*/
      RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x104f917a8*/
        this: (RBX::Analytics::Event *)"Studio",
        a2: "AutoJoinDragger",
        a3: v10,
        a4: v9,
        a5: 0,
        a6: v3);
      v4 = *((int **)this + 118); /*0x104f917ad*/
    }
    v11 = (const char *)v4[528]; /*0x104f917b4*/
    if ( (__int64)v11 > 0 ) /*0x104f917be*/
    {
      if ( (v13[0] & 1) != 0 ) /*0x104f917c4*/
        v12 = (const char *)v14; /*0x104f917c6*/
      else
        v12 = &v13[1]; /*0x104f917cc*/
      RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x104f917e1*/
        this: (RBX::Analytics::Event *)"Studio",
        a2: "AutoJoinInsert",
        a3: v12,
        a4: v11,
        a5: 0,
        a6: v3);
    }
    if ( (v13[0] & 1) != 0 ) /*0x104f917ea*/
      operator delete(a1: v14); /*0x104f917f0*/
  }
}

// Address: 0x104f91816 | Name: __ZN3RBX9Workspace17onServiceProviderEPNS_15ServiceProviderES2_
void __fastcall RBX::Workspace::onServiceProvider(
        RBX::Workspace *this,
        RBX::ServiceProvider *a2,
        RBX::ServiceProvider *a3)
{
  RBX::Instance *v6; // rdi
  RBX::Instance *v7; // rsi
  RBX::DataModel *v8; // rax
  std::__shared_weak_count *v9; // rdi
  RBX::Instance *v10; // rsi
  RBX::DataModel *v11; // rax
  __int128 v12; // xmm0
  std::__shared_weak_count *v13; // rdi
  RBX::DataModel *v14; // rax
  const RBX::RunService *v15; // r15
  RBX::DataModel *v16; // rdi
  __int64 v17; // rax
  RBX::Instance *v18; // rsi
  RBX::Instance *v19; // r14
  std::__shared_weak_count *v20; // r12
  RBX::DataModel *v21; // rax
  RBX::DataModel *v22; // r13
  unsigned int v23; // esi
  unsigned int v24; // r14d
  rbx::signals::slots_holder **v25; // r13
  unsigned __int64 v26; // rsi
  volatile signed __int32 *v27; // r12
  rbx::signals::slots_holder *v28; // rax
  __int64 v29; // rax
  rbx::signals::slots_holder *v30; // rdi
  unsigned int v31; // esi
  std::__shared_weak_count *v32; // r15
  std::__shared_weak_count *v33; // r15
  std::__shared_weak_count *v34; // r14
  int StudioGameStateType; // r14d
  RBX::DataModel *v36; // rdx
  std::__shared_weak_count *v37; // rbx
  std::__shared_weak_count *v38[2]; // [rsp+0h] [rbp-70h] BYREF
  std::__shared_weak_count *v39[4]; // [rsp+10h] [rbp-60h] BYREF
  RBX::DataModel *v40[2]; // [rsp+30h] [rbp-40h] BYREF

  if ( a2 != nullptr ) /*0x104f91833*/
  {
    rbx::signals::connection::disconnect(this: (RBX::Workspace *)((char *)this + 3312 /* +3312: NO 2022 FIELD */)); /*0x104f91840*/
    v6 = *((RBX::Instance **)this + 253); /*0x104f91845*/
    if ( v6 != nullptr ) /*0x104f9184f*/
    {
      RBX::Instance::setParent(this: v6, a2: nullptr); /*0x104f9185a*/
      std::shared_ptr<RBX::Instance>::reset[abi:ne200100](a1: (char *)this + 2024 /* +2024: NO 2022 FIELD */); /*0x104f91862*/
    }
    RBX::Workspace::stopModelMeshJob(this); /*0x104f9186a*/
    if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x104f91879*/
    {
      v8 = RBX::DataModel::get(this: a2, a2: v7); /*0x104f9187e*/
      if ( RBX::DataModel::isNonNetworkedLaunchIntent(this: v8) ) /*0x104f91886*/
        RBX::World::resetEngineNetConfigurationGuard(this: *((RBX::World **)this + 118)); /*0x104f91896*/
    }
    if ( FFlag::TagRuleCoreEnabled == 1 ) /*0x104f918a5*/
    {
      v9 = *((std::__shared_weak_count **)this + 420); /*0x104f918aa*/
      *(_OWORD *)((char *)this + 3352 /* +3352: NO 2022 FIELD */) = 0; /*0x104f918b1*/
      if ( v9 != nullptr ) /*0x104f918bb*/
        std::__shared_weak_count::__release_weak(this: v9); /*0x104f918bd*/
    }
  }
  RBX::ModelInstance::onServiceProvider(this, a2, a3); /*0x104f918cb*/
  if ( a3 != nullptr ) /*0x104f918d3*/
  {
    if ( FFlag::TagRuleCoreEnabled == 1 ) /*0x104f918e3*/
    {
      v11 = RBX::DataModel::get(this: a3, a2: v10); /*0x104f918e8*/
      if ( v11 != nullptr ) /*0x104f918f0*/
      {
        RBX::weak_from<RBX::DataModel>(a1: v39, a2: v11); /*0x104f918fc*/
        v12 = *(_OWORD *)v39; /*0x104f91901*/
        *(_OWORD *)v39 = 0; /*0x104f91908*/
        v13 = *((std::__shared_weak_count **)this + 420); /*0x104f9190c*/
        *(_OWORD *)((char *)this + 3352 /* +3352: NO 2022 FIELD */) = v12; /*0x104f91913*/
        if ( v13 != nullptr ) /*0x104f9191d*/
        {
          std::__shared_weak_count::__release_weak(this: v13); /*0x104f9191f*/
          if ( v39[1] != nullptr ) /*0x104f9192b*/
            std::__shared_weak_count::__release_weak(this: v39[1]); /*0x104f9192d*/
        }
      }
    }
    if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x104f9193c*/
    {
      v14 = RBX::DataModel::get(this: a3, a2: v10); /*0x104f91941*/
      if ( RBX::DataModel::isNonNetworkedLaunchIntent(this: v14) ) /*0x104f91949*/
      {
        RBX::Workspace::getEngineNetConfigurationFromProp(this: (RBX::Workspace *)v39, a2: (__int64)this); /*0x104f9195c*/
        RBX::Workspace::setEngineNetConfiguration(this, a2: (char *)v39); /*0x104f91967*/
      }
    }
    v15 = (const RBX::RunService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::RunService>(this: a3); /*0x104f91974*/
    v39[0] = (std::__shared_weak_count *)RBX::Workspace::onHeartbeat; /*0x104f91989*/
    v39[1] = nullptr; /*0x104f9198c*/
    v39[2] = this; /*0x104f91994*/
    rbx::signal<void ()(RBX::Heartbeat const&)>::connect<std::__bind<void (RBX::Workspace::*)(RBX::Heartbeat const&),RBX::Workspace*,std::placeholders::__ph<1> const&>>( /*0x104f9199f*/
      a1: v40,
      a2: (char *)v15 + 584);
    rbx::signals::scoped_connection::operator=(this: (RBX::Workspace *)((char *)this + 3312 /* +3312: NO 2022 FIELD */)); /*0x104f919ae*/
    v16 = v40[0]; /*0x104f919b3*/
    if ( v40[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v40[0] + 1) == 0 ) /*0x104f919c0*/
      rbx::signals::slot_base::operator delete(a1: v16); /*0x104f919c2*/
    v17 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::Stats::StatsService>(this: a3); /*0x104f919ca*/
    if ( v17 != 0 ) /*0x104f919d2*/
    {
      v19 = (RBX::Instance *)v17; /*0x104f919d4*/
      RBX::WorkspaceStatsItem::create( /*0x104f919eb*/
        this: (RBX::WorkspaceStatsItem *)v39,
        a2: this,
        a3: *((const RBX::World **)this + 118),
        a4: v15);
      std::shared_ptr<RBX::Instance>::operator=[abi:ne200100]<RBX::WorkspaceStatsItem,0>( /*0x104f919fd*/
        a1: (char *)this + 2024 /* +2024: NO 2022 FIELD */,
        a2: v39);
      v20 = v39[1]; /*0x104f91a02*/
      if ( v39[1] != nullptr /*0x104f91a1d*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v39[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(a1: v20); /*0x104f91a26*/
        std::__shared_weak_count::__release_weak(this: v20); /*0x104f91a2c*/
      }
      RBX::Instance::setParent(this: *((RBX::Instance **)this + 253), a2: v19); /*0x104f91a37*/
    }
    v21 = RBX::DataModel::get(this, a2: v18); /*0x104f91a3f*/
    RBX::shared_from<RBX::DataModel>(a1: v40, a2: v21); /*0x104f91a4e*/
    if ( (unsigned int)RBX::DataModel::getStudioGameStateType(this: v40[0]) != 3 ) /*0x104f91a5e*/
    {
      v22 = v40[0]; /*0x104f91a64*/
      v39[0] = this; /*0x104f91a6c*/
      RBX::weak_from<RBX::DataModel>(a1: &v39[1], a2: v40[0]); /*0x104f91a76*/
      v24 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v23); /*0x104f91a89*/
      v25 = (rbx::signals::slots_holder **)((char *)v22 + 976); /*0x104f91a8c*/
      rbx::lazyInitSlotsHolder(a1: v25); /*0x104f91a96*/
      v27 = (volatile signed __int32 *)rbx::signals::slot_base::operator new( /*0x104f91aa5*/
                                         this: (rbx::signals::slot_base *)0x48,
                                         a2: v26);
      *(_QWORD *)v27 = &_mh_execute_header; /*0x104f91ab2*/
      *((_QWORD *)v27 + 1) = rbx::signals::slot_with_functor<RBX::Workspace::onServiceProvider(RBX::ServiceProvider *,RBX::ServiceProvider *)::$_0>::do_call; /*0x104f91abd*/
      *((_OWORD *)v27 + 1) = 0; /*0x104f91ac5*/
      v28 = *v25; /*0x104f91acb*/
      *((_QWORD *)v27 + 4) = *v25; /*0x104f91acf*/
      if ( v28 != nullptr ) /*0x104f91ad7*/
      {
        _InterlockedIncrement((volatile signed __int32 *)v28 + 1); /*0x104f91ad9*/
        v29 = *((_QWORD *)v27 + 3) | 4LL; /*0x104f91ae2*/
        v30 = *v25; /*0x104f91ae6*/
      }
      else
      {
        v29 = 4; /*0x104f91aec*/
        v30 = nullptr; /*0x104f91af1*/
      }
      *((_QWORD *)v27 + 3) = v29; /*0x104f91af3*/
      *((_QWORD *)v27 + 5) = rbx::signals::slot_with_functor<RBX::Workspace::onServiceProvider(RBX::ServiceProvider *,RBX::ServiceProvider *)::$_0>::do_dtor; /*0x104f91aff*/
      qmemcpy((void *)(v27 + 12), v39, 24); /*0x104f91b08*/
      *(_OWORD *)&v39[1] = 0; /*0x104f91b17*/
      rbx::signals::slots_holder::insert(this: v30, a2: (unsigned __int64)v27); /*0x104f91b1e*/
      _InterlockedIncrement(v27 + 1); /*0x104f91b2a*/
      RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v24, a2: v31); /*0x104f91b31*/
      if ( _InterlockedDecrement(v27 + 1) == 0 ) /*0x104f91b3a*/
        rbx::signals::slot_base::operator delete(a1: (void *)v27); /*0x104f91b3f*/
      if ( v39[2] != nullptr ) /*0x104f91b4b*/
        std::__shared_weak_count::__release_weak(this: v39[2]); /*0x104f91b4d*/
      RBX::make_shared<RBX::CSG3::GeometryAnalytics,std::shared_ptr<RBX::DataModel> &>(a1: v39, a2: v40); /*0x104f91b5a*/
      std::shared_ptr<RBX::CSG3::GeometryAnalytics>::operator=[abi:ne200100](a1: (char *)this + 1960 /* +1960 = currentMouseCommandChanged (rbx::signal<void __cdecl(std::string const &)>, 24B) -- SIZE CONFLICT, see --verify */, a2: v39); /*0x104f91b70*/
      v32 = v39[1]; /*0x104f91b75*/
      if ( v39[1] != nullptr /*0x104f91b8e*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v39[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v32 + 16LL))(a1: v32); /*0x104f91b96*/
        std::__shared_weak_count::__release_weak(this: v32); /*0x104f91b9c*/
      }
      RBX::CSG3::GeometryAnalytics::initialize(this: *((RBX::CSG3::GeometryAnalytics **)this + 245)); /*0x104f91ba4*/
      RBX::make_shared<RBX::EditableAnalytics,std::shared_ptr<RBX::DataModel> &>(a1: v39, a2: v40); /*0x104f91bb1*/
      std::shared_ptr<RBX::EditableAnalytics>::operator=[abi:ne200100](a1: (char *)this + 1976 /* +1976: NO 2022 FIELD */, a2: v39); /*0x104f91bc7*/
      v33 = v39[1]; /*0x104f91bcc*/
      if ( v39[1] != nullptr /*0x104f91be5*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v39[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v33 + 16LL))(a1: v33); /*0x104f91bed*/
        std::__shared_weak_count::__release_weak(this: v33); /*0x104f91bf3*/
      }
      RBX::EditableAnalytics::initialize(this: *((RBX::EditableAnalytics **)this + 247)); /*0x104f91bfb*/
      *(_OWORD *)v38 = *(_OWORD *)v40; /*0x104f91c08*/
      if ( v40[1] != nullptr ) /*0x104f91c0f*/
        _InterlockedIncrement64((volatile signed __int64 *)v40[1] + 1); /*0x104f91c11*/
      RBX::AnimatorAnalytics::initialize(a1: v38); /*0x104f91c1a*/
      v34 = v38[1]; /*0x104f91c1f*/
      if ( v38[1] != nullptr /*0x104f91c38*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v38[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v34 + 16LL))(a1: v34); /*0x104f91c40*/
        std::__shared_weak_count::__release_weak(this: v34); /*0x104f91c46*/
      }
    }
    if ( FFlag::SimCsgEnableNewStudioButtons == 1 ) /*0x104f91c55*/
    {
      StudioGameStateType = RBX::DataModel::getStudioGameStateType(this: v40[0]); /*0x104f91c60*/
      if ( ((StudioGameStateType != 3) & RBX::DataModel::isInStudio(this: v40[0])) == 1 ) /*0x104f91c77*/
        RBX::Csg::Api::registerNegateCallback(this, a2: v40[0], a3: v36); /*0x104f91c80*/
    }
    v37 = v40[1]; /*0x104f91c85*/
    if ( v40[1] != nullptr /*0x104f91c9e*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v40[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v37 + 16LL))(a1: v37); /*0x104f91ca6*/
      std::__shared_weak_count::__release_weak(this: v37); /*0x104f91cac*/
    }
  }
}

// Address: 0x104f91d32 | Name: __ZN3RBX9Workspace16stopModelMeshJobEv
__int64 __fastcall RBX::Workspace::stopModelMeshJob(RBX::Workspace *this)
{
  __int64 result; // rax
  volatile signed __int64 *v3; // rax
  char *v4; // rbx
  std::__shared_weak_count *v5; // r14
  __int64 v6; // [rsp+0h] [rbp-20h] BYREF
  std::__shared_weak_count *v7; // [rsp+8h] [rbp-18h]

  result = *((_QWORD *)this + 290) /* +2320: NO 2022 FIELD */; /*0x104f91d3d*/
  if ( result != 0 ) /*0x104f91d47*/
  {
    v6 = *((_QWORD *)this + 290) /* +2320: NO 2022 FIELD */; /*0x104f91d4c*/
    v3 = *((volatile signed __int64 **)this + 291); /*0x104f91d50*/
    v7 = (std::__shared_weak_count *)v3; /*0x104f91d57*/
    if ( v3 != nullptr ) /*0x104f91d5e*/
      _InterlockedIncrement64(v3 + 1); /*0x104f91d60*/
    RBX::TaskScheduler::remove(a1: &v6); /*0x104f91d69*/
    v4 = (char *)this + 2320 /* +2320: NO 2022 FIELD */; /*0x104f91d6e*/
    v5 = v7; /*0x104f91d75*/
    if ( v7 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v7 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104f91d8e*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x104f91d96*/
      std::__shared_weak_count::__release_weak(this: v5); /*0x104f91d9c*/
    }
    return std::shared_ptr<RBX::DataModelJob>::reset[abi:ne200100](a1: v4); /*0x104f91da4*/
  }
  return result; /*0x104f91da9*/
}

// Address: 0x104f92e74 | Name: __ZN3RBX9Workspace15scriptShouldRunEPNS_10BaseScriptE
bool __fastcall RBX::Workspace::scriptShouldRun(RBX::Workspace *this, RBX::BaseScript *a2)
{
  __int64 v4; // r15
  __int64 v5; // rax
  const RBX::Instance *v6; // rsi
  RBX::BaseScript *LocalCharacter; // rax
  RBX::BaseScript *v8; // rcx
  RBX::Instance *v9; // rsi
  unsigned __int64 LocalCharacterPendingGuid; // rax
  RBX::Instance *v11; // rsi
  __int64 v12; // rcx
  RBX::DataModel *v14; // rax
  __int64 v15; // r14
  __int64 v16; // rax
  std::__shared_weak_count *v17[2]; // [rsp+0h] [rbp-60h] BYREF
  _QWORD v18[4]; // [rsp+10h] [rbp-50h] BYREF
  _QWORD *v19; // [rsp+30h] [rbp-30h]

  v4 = *((_QWORD *)a2 + 3); /*0x104f92e95*/
  v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::LocalScript>(a1: this); /*0x104f92e99*/
  if ( a2 == nullptr /*0x104f92ec1*/
    || *(unsigned __int16 *)(v4 + 440) - (unsigned int)*(unsigned __int16 *)(v5 + 440) > *(unsigned __int16 *)(v5 + 442) )
  {
    return RBX::DataModel::backendProcessing(this, a2: v6); /*0x104f92f5e*/
  }
  LocalCharacter = (RBX::BaseScript *)RBX::Players::findLocalCharacter(this, a2: v6); /*0x104f92ec6*/
  if ( LocalCharacter == nullptr ) /*0x104f92ece*/
    goto LABEL_11; /*0x104f92ece*/
  v8 = a2; /*0x104f92ed0*/
  do /*0x104f92edf*/
    v8 = *((RBX::BaseScript **)v8 + 13); /*0x104f92ed3*/
  while ( v8 != LocalCharacter && v8 != nullptr ); /*0x104f92edf*/
  if ( v8 != LocalCharacter ) /*0x104f92ee4*/
  {
    do /*0x104f92ef2*/
      LocalCharacter = *((RBX::BaseScript **)LocalCharacter + 13); /*0x104f92ee6*/
    while ( LocalCharacter != this && LocalCharacter != nullptr ); /*0x104f92ef2*/
    if ( LocalCharacter == this ) /*0x104f92ef7*/
      return false; /*0x104f92ef7*/
LABEL_11:
    if ( (unsigned __int8)RBX::WorkspaceProp::getNetworkStreamingEnabled(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)) == 0 ) /*0x104f92f07*/
      return false; /*0x104f92f07*/
    LocalCharacterPendingGuid = RBX::Players::findLocalCharacterPendingGuid(this, a2: v9); /*0x104f92f0c*/
    if ( (_DWORD)LocalCharacterPendingGuid == -1 ) /*0x104f92f14*/
      return false; /*0x104f92f14*/
    v12 = *((_QWORD *)a2 + 13); /*0x104f92f16*/
    if ( v12 == 0 ) /*0x104f92f1d*/
      return false; /*0x104f92f1d*/
    while ( *(_QWORD *)(v12 + 48) != LocalCharacterPendingGuid ) /*0x104f92f29*/
    {
      v12 = *(_QWORD *)(v12 + 104); /*0x104f92f30*/
      if ( v12 == 0 ) /*0x104f92f37*/
        return false; /*0x104f92f37*/
    }
    v14 = RBX::DataModel::get(this, a2: v11); /*0x104f92f87*/
    if ( v14 == nullptr ) /*0x104f92f8f*/
      return false; /*0x104f92f8f*/
    v15 = (__int64)v14; /*0x104f92f91*/
    RBX::weak_from<RBX::BaseScript>(a1: v17, a2); /*0x104f92f9b*/
    v18[0] = &off_10C9F2330; /*0x104f92fab*/
    *(_OWORD *)&v18[1] = *(_OWORD *)v17; /*0x104f92fb2*/
    *(_OWORD *)v17 = 0; /*0x104f92fba*/
    v19 = v18; /*0x104f92fbe*/
    RBX::DataModel::submitTask(a1: v15, a2: (__int64)v18, a3: 1); /*0x104f92fcd*/
    if ( v19 == v18 ) /*0x104f92fd9*/
    {
      v16 = 32; /*0x104f92fe7*/
    }
    else
    {
      v16 = 40; /*0x104f92fdb*/
      if ( v19 == nullptr ) /*0x104f92fe3*/
      {
LABEL_25:
        if ( v17[1] != nullptr ) /*0x104f92ff9*/
          std::__shared_weak_count::__release_weak(this: v17[1]); /*0x104f92fff*/
        return false; /*0x104f92f3b*/
      }
    }
    (*(void (**)(void))(*v19 + v16))(); /*0x104f92fef*/
    goto LABEL_25; /*0x104f92fef*/
  }
  return true; /*0x104f92f54*/
}

// Address: 0x104f930fa | Name: __ZThn1320_N3RBX9Workspace15scriptShouldRunEPNS_10BaseScriptE
bool __fastcall `non-virtual thunk to'RBX::Workspace::scriptShouldRun(RBX::Workspace *this, RBX::BaseScript *a2)
{
  return RBX::Workspace::scriptShouldRun(this: (RBX::Workspace *)((char *)this - 1320), a2); /*0x104f93105*/
}

// Address: 0x104f9310c | Name: __ZN3RBX9Workspace27experimentalSolverIsEnabledEv
char __fastcall RBX::Workspace::experimentalSolverIsEnabled(RBX::Workspace *this)
{
  return 1; /*0x104f93112*/
}

// Address: 0x104f93114 | Name: __ZN3RBX9Workspace19setGridSizeModifierEi
__int64 __fastcall RBX::Workspace::setGridSizeModifier(RBX::Workspace *this, __int32 a2)
{
  __int64 result; // rax

  result = *((unsigned int *)this + 593); /*0x104f93114*/
  if ( (_DWORD)result != a2 ) /*0x104f9311c*/
  {
    _InterlockedExchange((volatile __int32 *)this + 593, a2); /*0x104f93128*/
    rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::Workspace *)((char *)this + 1448 /* +1448 = stickyCommand.._Ptr (RBX::MouseCommand *, 8B) -- SIZE CONFLICT, see --verify */)); /*0x104f93135*/
    return rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::Workspace *)((char *)this + 1424 /* +1424 = arrowCameraControls (bool, 1B) -- SIZE CONFLICT, see --verify */)); /*0x104f9314a*/
  }
  return result; /*0x104f9311e*/
}

// Address: 0x104f93150 | Name: __ZNK3RBX9Workspace34getFallenPartDestroyHeightCallbackEv
float __fastcall RBX::Workspace::getFallenPartDestroyHeightCallback(RBX::Workspace *this)
{
  return *(float *)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 512LL); /*0x104f93163*/
}

// Address: 0x104f93166 | Name: __ZN3RBX9Workspace45deprecatedSetFallenPartsDestroyHeightCallbackEf
__int64 __fastcall RBX::Workspace::deprecatedSetFallenPartsDestroyHeightCallback(RBX::Workspace *this, float a2)
{
  float v2; // xmm0_4
  __int64 result; // rax

  v2 = fminf(50000.0, fmaxf(-50000.0, a2)); /*0x104f9317e*/
  result = *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */; /*0x104f93182*/
  if ( *(float *)(result + 512) != v2 ) /*0x104f93194*/
  {
    *(float *)(result + 512) = v2; /*0x104f93198*/
    return RBX::Object::raisePropertyChanged( /*0x104f931ab*/
             this,
             a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_FallenPartsDestroyHeight);
  }
  return result; /*0x104f931aa*/
}

// Address: 0x104f931b2 | Name: __ZThn1056_N3RBX9Workspace45deprecatedSetFallenPartsDestroyHeightCallbackEf
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetFallenPartsDestroyHeightCallback(
        RBX::Workspace *this,
        float a2)
{
  return RBX::Workspace::deprecatedSetFallenPartsDestroyHeightCallback( /*0x104f931bd*/
           this: (RBX::Workspace *)((char *)this - 1056),
           a2);
}

// Address: 0x104f931c4 | Name: __ZNK3RBX9Workspace18getGravityCallbackEv
float __fastcall RBX::Workspace::getGravityCallback(RBX::Workspace *this)
{
  return *(float *)(*((_QWORD *)this + 118) /* +944: NO 2022 FIELD */ + 520LL); /*0x104f931d7*/
}

// Address: 0x104f931da | Name: __ZN3RBX9Workspace28deprecatedSetGravityCallbackEf
__int64 __fastcall RBX::Workspace::deprecatedSetGravityCallback(RBX::Workspace *this, __m128i a2)
{
  float v2; // xmm1_4
  __int64 result; // rax
  float v5; // xmm0_4
  float *v6; // rdi

  v2 = fmaxf(0.0, *(float *)a2.i32); /*0x104f931ed*/
  result = _mm_cvtsi128_si32(a2) & 0x7FFFFFFF; /*0x104f931ff*/
  LOBYTE(result) = v2 > 1000.0 || *(float *)a2.i32 < 0.0 || (int)result < 2139095040; /*0x104f9320e*/
  if ( (_BYTE)result == 1 ) /*0x104f93212*/
  {
    v5 = fminf(1000.0, v2); /*0x104f93217*/
    v6 = *((float **)this + 118); /*0x104f9321b*/
    if ( v6[130] != v5 ) /*0x104f9322d*/
    {
      RBX::World::setGravity(this: (RBX::World *)v6, a2: v5); /*0x104f93231*/
      return RBX::Object::raisePropertyChanged( /*0x104f93249*/
               this,
               a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_Gravity);
    }
  }
  return result; /*0x104f93247*/
}

// Address: 0x104f93256 | Name: __ZThn1056_N3RBX9Workspace28deprecatedSetGravityCallbackEf
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetGravityCallback(RBX::Workspace *this, __m128i a2)
{
  return RBX::Workspace::deprecatedSetGravityCallback(this: (RBX::Workspace *)((char *)this - 1056), a2); /*0x104f93261*/
}

// Address: 0x104f93268 | Name: __ZN3RBX9Workspace26postSetFluidForcesCallbackEv
__int64 __fastcall RBX::Workspace::postSetFluidForcesCallback(RBX::Workspace *this)
{
  RBX::World *v2; // rdi
  char v3; // al
  char v4; // si
  int v5; // ecx

  if ( DFFlag::FluidForcesSwitchToThreePhaseRollout == 1 ) /*0x104f93276*/
  {
    v2 = *((RBX::World **)this + 118); /*0x104f93278*/
    if ( DFFlag::FluidForcesThreePhaseRolloutProperty == 1 && *((_DWORD *)this + 292) /* +1168 likely monotonicClock.lastComputedTimeUS -- UNVERIFIED */ == 1 ) /*0x104f93291*/
      v3 = 1; /*0x104f932cd*/
    else
      v3 = DFFlag::FluidForcesDefaultEnabled; /*0x104f93295*/
    v4 = v3; /*0x104f9329b*/
  }
  else
  {
    v5 = *((_DWORD *)this + 292) /* +1168 likely monotonicClock.lastComputedTimeUS -- UNVERIFIED */; /*0x104f932a0*/
    v2 = *((RBX::World **)this + 118); /*0x104f932a6*/
    if ( v5 != 0 ) /*0x104f932b1*/
      v4 = v5 == 1; /*0x104f932b6*/
    else
      v4 = FInt::SimDefaultFluidForceEnabled != 0; /*0x104f932c3*/
  }
  return RBX::World::setEnableFluidForces(this: v2, a2: v4); /*0x104f932c7*/
}

// Address: 0x104f932d2 | Name: __ZThn1056_N3RBX9Workspace26postSetFluidForcesCallbackEv
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::postSetFluidForcesCallback(RBX::Workspace *this)
{
  return RBX::Workspace::postSetFluidForcesCallback(this: (RBX::Workspace *)((char *)this - 1056)); /*0x104f932dd*/
}

// Address: 0x104f932e4 | Name: __ZN3RBX9Workspace36deprecatedSetCollisionGroupsCallbackERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall RBX::Workspace::deprecatedSetCollisionGroupsCallback(RBX::WorldRoot *this, unsigned __int8 *a2)
{
  unsigned int v3; // eax
  __int64 result; // rax
  __int64 v5; // r14
  RBX::CollisionGroups **v6; // r14
  std::__shared_weak_count *v7; // rbx
  __int64 v8; // [rsp+18h] [rbp-28h] BYREF
  std::__shared_weak_count *v9; // [rsp+20h] [rbp-20h]

  v3 = *a2; /*0x104f932f7*/
  if ( (v3 & 1) != 0 ) /*0x104f932fc*/
    result = *((_QWORD *)a2 + 1); /*0x104f932fe*/
  else
    result = v3 >> 1; /*0x104f93304*/
  if ( result != 0 ) /*0x104f93309*/
  {
    RBX::make_shared<RBX::CollisionGroups>(a1: &v8); /*0x104f93316*/
    RBX::CollisionGroups::decodeLegacyString(a1: &v8); /*0x104f93340*/
    v5 = *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */; /*0x104f93345*/
    result = RBX::CollisionGroups::operator==(a1: *(_QWORD *)(v5 + 920), a2: v8); /*0x104f93357*/
    if ( (_BYTE)result == 0 ) /*0x104f9335e*/
    {
      v6 = (RBX::CollisionGroups **)(v5 + 920); /*0x104f93360*/
      std::shared_ptr<RBX::CollisionGroups>::operator=[abi:ne200100](a1: v6, a2: &v8); /*0x104f9336e*/
      RBX::CollisionGroups::enforceUninitializedGroupsCollidable(this: *v6); /*0x104f93376*/
      result = RBX::WorldRoot::raiseCollisionGroupChanged(this, a2: true); /*0x104f93383*/
    }
    v7 = v9; /*0x104f93388*/
    if ( v9 != nullptr ) /*0x104f9338f*/
    {
      result = _InterlockedExchangeAdd64((volatile signed __int64 *)v9 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x104f93398*/
      if ( result == 0 ) /*0x104f933a1*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x104f933a9*/
        return std::__shared_weak_count::__release_weak(this: v7); /*0x104f933af*/
      }
    }
  }
  return result; /*0x104f933b4*/
}

// Address: 0x104f93428 | Name: __ZThn1056_N3RBX9Workspace36deprecatedSetCollisionGroupsCallbackERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetCollisionGroupsCallback(
        __int64 a1,
        unsigned __int8 *a2)
{
  return RBX::Workspace::deprecatedSetCollisionGroupsCallback(this: (RBX::WorldRoot *)(a1 - 1056), a2); /*0x104f93433*/
}

// Address: 0x104f9343a | Name: __ZN3RBX9Workspace34postSetPrimalPhysicsSolverCallbackEv
__int64 __fastcall RBX::Workspace::postSetPrimalPhysicsSolverCallback(RBX::Workspace *this)
{
  int v1; // ecx
  RBX::World *v2; // rdi
  char v3; // si

  v1 = *((_DWORD *)this + 308) /* +1232 likely pendingLocalTouches -- UNVERIFIED */; /*0x104f9343e*/
  v2 = *((RBX::World **)this + 118); /*0x104f9344c*/
  if ( v1 != 0 ) /*0x104f93455*/
    v3 = v1 == 1; /*0x104f9345f*/
  else
    v3 = FFlag::DebugCLI122361Alpha; /*0x104f93457*/
  return RBX::World::setEnablePrimalSolver(this: v2, a2: v3 & 1); /*0x104f93465*/
}

// Address: 0x104f9346c | Name: __ZThn1056_N3RBX9Workspace34postSetPrimalPhysicsSolverCallbackEv
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::postSetPrimalPhysicsSolverCallback(RBX::Workspace *this)
{
  int v1; // ecx
  RBX::World *v2; // rdi
  char v3; // si

  v1 = *((_DWORD *)this + 44) /* +176: NO 2022 FIELD */; /*0x104f93470*/
  v2 = *((RBX::World **)this - 14); /*0x104f9347e*/
  if ( v1 != 0 ) /*0x104f93484*/
    v3 = v1 == 1; /*0x104f9348e*/
  else
    v3 = FFlag::DebugCLI122361Alpha; /*0x104f93486*/
  return RBX::World::setEnablePrimalSolver(this: v2, a2: v3 & 1); /*0x104f93494*/
}

// Address: 0x104f9349a | Name: __ZN3RBX9Workspace29postSetSignalBehaviorCallbackEv
char *__fastcall RBX::Workspace::postSetSignalBehaviorCallback(RBX::Workspace *this)
{
  char v2; // al
  int v3; // ecx
  char *result; // rax
  RBX::WorkspaceProp *v5; // rbx

  v2 = RBX::Workspace::useDeferredSignals(this); /*0x104f934a3*/
  v3 = 1; /*0x104f934a8*/
  if ( v2 == 0 ) /*0x104f934af*/
    v3 = (unsigned __int8)RBX::Workspace::useAncestryDeferredSignals(this) ^ 3; /*0x104f934bc*/
  result = (char *)&RBX::RbxDbgInfo::s_instance; /*0x104f934bf*/
  unk_10D781754 = v3; /*0x104f934c6*/
  if ( FFlag::SAuthWorkspacePropertyEnabled == 1 ) /*0x104f934d3*/
  {
    result = &FFlag::SAuthWorkspaceFlagged; /*0x104f934d5*/
    if ( FFlag::SAuthWorkspaceFlagged == 1 && *((_DWORD *)this + 287) /* +1148: NO 2022 FIELD */ != 1 ) /*0x104f934e8*/
    {
      v5 = (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */); /*0x104f934ea*/
      result = (char *)RBX::WorkspaceProp::getSignalBehavior(this: v5); /*0x104f934f4*/
      if ( (_DWORD)result != 2 ) /*0x104f934fc*/
        return (char *)RBX::WorkspaceProp::setSignalBehavior(a1: v5, a2: 2); /*0x104f93513*/
    }
  }
  return result; /*0x104f93502*/
}

// Address: 0x104f93518 | Name: __ZThn1056_N3RBX9Workspace29postSetSignalBehaviorCallbackEv
char *__fastcall `non-virtual thunk to'RBX::Workspace::postSetSignalBehaviorCallback(RBX::Workspace *this)
{
  return RBX::Workspace::postSetSignalBehaviorCallback(this: (RBX::Workspace *)((char *)this - 1056)); /*0x104f93523*/
}

// Address: 0x104f9352a | Name: __ZNK3RBX9Workspace21getAirDensityCallbackEv
__int64 __fastcall RBX::Workspace::getAirDensityCallback(RBX::FluidModels::FixedProfileFluid ***this)
{
  return RBX::World::getAirDensity(this: *(this + 118)); /*0x104f93535*/
}

// Address: 0x104f9353c | Name: __ZN3RBX9Workspace31deprecatedSetAirDensityCallbackEf
__int64 __fastcall RBX::Workspace::deprecatedSetAirDensityCallback(
        RBX::FluidModels::FixedProfileFluid ***this,
        __m128i a2)
{
  float v2; // xmm1_4
  __int64 result; // rax
  float v5; // xmm0_4
  float v6; // [rsp+0h] [rbp-Ch]

  v2 = fmaxf(0.0, *(float *)a2.i32); /*0x104f9354f*/
  result = _mm_cvtsi128_si32(a2) & 0x7FFFFFFF; /*0x104f93561*/
  LOBYTE(result) = v2 > 10.0 || *(float *)a2.i32 < 0.0 || (int)result < 2139095040; /*0x104f93570*/
  if ( (_BYTE)result == 1 ) /*0x104f93574*/
  {
    v6 = fminf(10.0, v2); /*0x104f9357d*/
    result = RBX::World::getAirDensity(this: *(this + 118)); /*0x104f93589*/
    if ( v5 != v6 ) /*0x104f93597*/
    {
      RBX::World::setAirDensity(this: *(this + 118), a2: v6); /*0x104f935a2*/
      return RBX::Object::raisePropertyChanged( /*0x104f935ba*/
               (RBX::Object *)this,
               a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_AirDensity);
    }
  }
  return result; /*0x104f935b8*/
}

// Address: 0x104f935c6 | Name: __ZThn1056_N3RBX9Workspace31deprecatedSetAirDensityCallbackEf
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetAirDensityCallback(
        RBX::FluidModels::FixedProfileFluid ***this,
        __m128i a2)
{
  return RBX::Workspace::deprecatedSetAirDensityCallback(this: this - 132, a2); /*0x104f935d1*/
}

// Address: 0x104f935d8 | Name: __ZN3RBX9Workspace25getConstraintGizmoManagerEv
__int64 __fastcall RBX::Workspace::getConstraintGizmoManager(RBX::Workspace *this)
{
  return *((_QWORD *)this + 272) /* +2176: NO 2022 FIELD */; /*0x104f935e3*/
}

// Address: 0x104f935e6 | Name: __ZNK3RBX9Workspace21getGlobalWindCallbackEv
__int64 __fastcall RBX::Workspace::getGlobalWindCallback(RBX::FluidModels::FixedProfileFluid ***this)
{
  return RBX::World::getGlobalWind(this: *(this + 118)); /*0x104f935f1*/
}

// Address: 0x104f935f8 | Name: __ZN3RBX9Workspace31deprecatedSetGlobalWindCallbackERKNS_7Vector3E
char __fastcall RBX::Workspace::deprecatedSetGlobalWindCallback(
        RBX::FluidModels::FixedProfileFluid ***this,
        const RBX::Vector3 *a2)
{
  char result; // al
  __int64 v5; // rdx
  __int64 v6; // rcx
  float v7; // xmm1_4
  __m128 v8; // xmm2
  __m128 v9; // xmm0
  __m128 v10; // xmm0
  unsigned __int8 v11; // al
  float v12; // xmm0_4
  double v13[4]; // [rsp+0h] [rbp-20h] BYREF

  result = RBX::Math::isNan(this: a2, a2); /*0x104f9360c*/
  if ( result == 0 ) /*0x104f93613*/
  {
    RBX::World::getGlobalWind(this: *(this + 118)); /*0x104f93620*/
    v8 = (__m128)*(unsigned __int64 *)a2; /*0x104f93625*/
    v10 = _mm_cmpneq_ps(v9, v8); /*0x104f9362a*/
    v11 = _mm_movemask_pd((__m128d)_mm_unpacklo_ps(v10, v10)); /*0x104f93631*/
    v12 = *((float *)a2 + 2); /*0x104f93635*/
    if ( (v11 & 1) != 0 || (result = v11 >> 1) != 0 || v7 != v12 ) /*0x104f93646*/
    {
      _mm_storel_ps(v13, _mm_min_ps((__m128)xmmword_108F52A90, _mm_max_ps((__m128)xmmword_109762C70, v8))); /*0x104f9367a*/
      LODWORD(v13[1]) = fminf(1000.0, fmaxf(-1000.0, v12)); /*0x104f9367d*/
      RBX::World::setGlobalWind(this: *(this + 118), a2: (const RBX::Vector3 *)v13, a3: v5, a4: v6); /*0x104f93689*/
      return RBX::Object::raisePropertyChanged( /*0x104f9369b*/
               (RBX::Object *)this,
               a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_GlobalWind);
    }
  }
  return result; /*0x104f936a0*/
}

// Address: 0x104f936aa | Name: __ZThn1056_N3RBX9Workspace31deprecatedSetGlobalWindCallbackERKNS_7Vector3E
char __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetGlobalWindCallback(
        RBX::FluidModels::FixedProfileFluid ***this,
        const RBX::Vector3 *a2)
{
  return RBX::Workspace::deprecatedSetGlobalWindCallback(this: this - 132, a2); /*0x104f936b5*/
}

// Address: 0x104f936bc | Name: __ZN3RBX9Workspace19getShowGridMaterialEv
char __fastcall RBX::Workspace::getShowGridMaterial(RBX::Workspace *this)
{
  return *((_BYTE *)this + 2113) /* +2113: NO 2022 FIELD */ & 1; /*0x104f936c8*/
}

// Address: 0x104f936ca | Name: __ZN3RBX9Workspace19setShowGridMaterialEb
char __fastcall RBX::Workspace::setShowGridMaterial(RBX::Workspace *this, char a2)
{
  char result; // al

  result = *((_BYTE *)this + 2113) /* +2113: NO 2022 FIELD */ & 1; /*0x104f936d4*/
  if ( result != a2 ) /*0x104f936d9*/
  {
    *((_BYTE *)this + 2113) /* +2113: NO 2022 FIELD */ = a2; /*0x104f936db*/
    return rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::Workspace *)((char *)this + 1424 /* +1424 = arrowCameraControls (bool, 1B) -- SIZE CONFLICT, see --verify */)); /*0x104f936ea*/
  }
  return result; /*0x104f936e9*/
}

// Address: 0x104f936f2 | Name: __ZNK3RBX9Workspace25getShowWireframeRenderingEv
char __fastcall RBX::Workspace::getShowWireframeRendering(RBX::Workspace *this)
{
  return *((_BYTE *)this + 2114) /* +2114: NO 2022 FIELD */ & 1; /*0x104f936fe*/
}

// Address: 0x104f93700 | Name: __ZN3RBX9Workspace25setShowWireframeRenderingEb
char __fastcall RBX::Workspace::setShowWireframeRendering(RBX::Workspace *this, char a2)
{
  char result; // al

  if ( FFlag::StudioViewportVisualizationContext == 1 ) /*0x104f9370b*/
  {
    result = *((_BYTE *)this + 2114) /* +2114: NO 2022 FIELD */ & 1; /*0x104f93713*/
    if ( result != a2 ) /*0x104f93718*/
    {
      *((_BYTE *)this + 2114) /* +2114: NO 2022 FIELD */ = a2; /*0x104f9371a*/
      return rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::Workspace *)((char *)this + 1440 /* +1440 = currentCommand.._Rep (std::_Ref_count_base *, 8B) -- SIZE CONFLICT, see --verify */)); /*0x104f93729*/
    }
  }
  else
  {
    *((_BYTE *)this + 2114) /* +2114: NO 2022 FIELD */ = a2; /*0x104f9372e*/
  }
  return result; /*0x104f93728*/
}

// Address: 0x104f93738 | Name: __ZNK3RBX9Workspace24getShowConstraintDetailsEv
char __fastcall RBX::Workspace::getShowConstraintDetails(RBX::Workspace *this)
{
  return *(_BYTE *)(*((_QWORD *)this + 272) /* +2176: NO 2022 FIELD */ + 248LL); /*0x104f93749*/
}

// Address: 0x104f9374c | Name: __ZNK3RBX9Workspace22isConstraintGizmoDrawnERKNS_8InstanceE
__int64 __fastcall RBX::Workspace::isConstraintGizmoDrawn(
        RBX::Constraints::GizmoManager **this,
        const RBX::Instance *a2)
{
  return RBX::Constraints::GizmoManager::isConstraintGizmoDrawn(this: *(this + 272), a2); /*0x104f93757*/
}

// Address: 0x104f9375e | Name: __ZN3RBX9Workspace23onCollisionGroupChangedEv
__int64 __fastcall RBX::Workspace::onCollisionGroupChanged(RBX::Workspace *this)
{
  return RBX::Object::raisePropertyChanged( /*0x104f9376c*/
           this,
           a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_CollisionGroups);
}

// Address: 0x104f93772 | Name: __ZNK3RBX9Workspace51getTouchEventsUseCollisionGroups_DEPRECATEDCallbackEv
char __fastcall RBX::Workspace::getTouchEventsUseCollisionGroups_DEPRECATEDCallback(RBX::World **this)
{
  return RBX::World::getTouchEventsUseCollisionGroups(this: *(this + 118)); /*0x104f9377d*/
}

// Address: 0x104f93784 | Name: __ZN3RBX9Workspace46deprecatedSetTouchesUseCollisionGroupsCallbackEb
char __fastcall RBX::Workspace::deprecatedSetTouchesUseCollisionGroupsCallback(RBX::Workspace *this, char a2)
{
  RBX::World *v4; // r15
  char result; // al

  if ( DFFlag::TouchEventsUseCollisionGroupsDefaultEnabled == 0 ) /*0x104f93795*/
  {
    v4 = *((RBX::World **)this + 118); /*0x104f9379d*/
    if ( DFFlag::TouchEventsUseCollisionGroupsThreePhaseRollout == 1 ) /*0x104f937ab*/
    {
      if ( *((_DWORD *)this + 320) /* +1280 likely pendingSendTouches.impl.count -- UNVERIFIED */ != 0 ) /*0x104f937b4*/
        return result; /*0x104f937b4*/
      if ( a2 != 0 ) /*0x104f937b9*/
        RBX::WorkspaceProp::setTouchEventsUseCollisionGroups(a1: (char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */, a2: 2); /*0x104f937c7*/
    }
    result = RBX::World::getTouchEventsUseCollisionGroups(this: v4); /*0x104f937cf*/
    if ( result != a2 ) /*0x104f937d7*/
    {
      RBX::World::setTouchEventsUseCollisionGroups(this: v4, a2); /*0x104f937e0*/
      return RBX::Object::raisePropertyChanged( /*0x104f937fc*/
               this,
               a2: (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_TouchesUseCollisionGroups);
    }
  }
  return result; /*0x104f937f6*/
}

// Address: 0x104f9380c | Name: __ZThn1056_N3RBX9Workspace46deprecatedSetTouchesUseCollisionGroupsCallbackEb
char __fastcall `non-virtual thunk to'RBX::Workspace::deprecatedSetTouchesUseCollisionGroupsCallback(
        RBX::Workspace *this,
        char a2)
{
  return RBX::Workspace::deprecatedSetTouchesUseCollisionGroupsCallback( /*0x104f93817*/
           this: (RBX::Workspace *)((char *)this - 1056),
           a2);
}

// Address: 0x104f9381e | Name: __ZN3RBX9Workspace44postSetTouchEventsUseCollisionGroupsCallbackEv
void __fastcall RBX::Workspace::postSetTouchEventsUseCollisionGroupsCallback(RBX::Workspace *this)
{
  RBX::World *v2; // rdi
  int v3; // ecx
  char v4; // al

  v2 = *((RBX::World **)this + 118); /*0x104f93825*/
  v3 = *((_DWORD *)this + 320) /* +1280 likely pendingSendTouches.impl.count -- UNVERIFIED */; /*0x104f9382c*/
  if ( v3 != 0 ) /*0x104f93834*/
    v4 = v3 == 2; /*0x104f9383d*/
  else
    v4 = DFFlag::TouchEventsUseCollisionGroupsDefaultEnabled; /*0x104f93841*/
  RBX::World::setTouchEventsUseCollisionGroups(this: v2, a2: v4); /*0x104f9384b*/
}

// Address: 0x104f93850 | Name: __ZThn1056_N3RBX9Workspace44postSetTouchEventsUseCollisionGroupsCallbackEv
void __fastcall `non-virtual thunk to'RBX::Workspace::postSetTouchEventsUseCollisionGroupsCallback(
        RBX::Workspace *this)
{
  RBX::World *v2; // rdi
  int v3; // ecx
  char v4; // al

  v2 = *((RBX::World **)this - 14); /*0x104f93857*/
  v3 = *((_DWORD *)this + 56) /* +224: NO 2022 FIELD */; /*0x104f9385b*/
  if ( v3 != 0 ) /*0x104f93863*/
    v4 = v3 == 2; /*0x104f9386c*/
  else
    v4 = DFFlag::TouchEventsUseCollisionGroupsDefaultEnabled; /*0x104f93870*/
  RBX::World::setTouchEventsUseCollisionGroups(this: v2, a2: v4); /*0x104f9387a*/
}

// Address: 0x104f93880 | Name: __ZNK3RBX9Workspace26getUseLayeredClothingCacheEv
char __fastcall RBX::Workspace::getUseLayeredClothingCache(RBX::Workspace *this)
{
  int v1; // eax

  if ( DFFlag::LcCacheOptThreePhaseRolloutProperty != 1 ) /*0x104f9388b*/
    return DFFlag::LcCacheOptDefaultEnabled; /*0x104f9388b*/
  v1 = *((_DWORD *)this + 297) /* +1188: NO 2022 FIELD */; /*0x104f9388d*/
  if ( v1 == 2 ) /*0x104f93896*/
    return 1; /*0x104f938ab*/
  if ( v1 != 1 ) /*0x104f9389b*/
    return DFFlag::LcCacheOptDefaultEnabled; /*0x104f938a6*/
  return 0; /*0x104f938a5*/
}

// Address: 0x104f938b0 | Name: __ZN3RBX9Workspace34queuePartOperationForDataMigrationERKNSt3__110shared_ptrINS_13PartOperationEEE
__int64 __fastcall RBX::Workspace::queuePartOperationForDataMigration(__int64 a1, __int64 a2)
{
  return std::__hash_table<std::shared_ptr<RBX::PartOperation>,std::hash<std::shared_ptr<RBX::PartOperation>>,std::equal_to<std::shared_ptr<RBX::PartOperation>>,std::allocator<std::shared_ptr<RBX::PartOperation>>>::__emplace_unique_key_args<std::shared_ptr<RBX::PartOperation>,std::shared_ptr<RBX::PartOperation> const&>( /*0x104f938be*/
           a1: a1 + 2184,
           a2,
           a3: a2);
}

// Address: 0x104f938c4 | Name: __ZNK3RBX9Workspace24isPropertyHiddenInStudioEPKNS_10Reflection18PropertyDescriptorE
char __fastcall RBX::Workspace::isPropertyHiddenInStudio(
        RBX::Workspace *this,
        const RBX::Reflection::PropertyDescriptor *a2)
{
  const RBX::Reflection::PropertyDescriptor *v4; // r15
  char result; // al
  char v6; // al
  __int64 v7; // rdi
  int Avatar; // ebx
  __int128 v10; // [rsp+0h] [rbp-30h] BYREF
  _BYTE v11[32]; // [rsp+10h] [rbp-20h] BYREF

  v4 = (const RBX::Reflection::PropertyDescriptor *)RBX::WorkspaceProperties::prop_NextGenerationReplication; /*0x104f938de*/
  if ( RBX::WorkspaceProperties::prop_NextGenerationReplication == (_UNKNOWN *)a2 ) /*0x104f938e4*/
  {
    result = 1; /*0x104f938ed*/
    if ( FFlag::SAuthWorkspaceFlagged != 1 ) /*0x104f938f2*/
      return result; /*0x104f938f2*/
  }
  if ( RBX::WorkspaceProperties::prop_CollisionGroups == (_UNKNOWN *)a2 /*0x104f93922*/
    || RBX::WorldRootProperties::prop_CollisionGroupData == (_UNKNOWN *)a2
    || RBX::ModelProperties::prop_LevelOfDetail == (_UNKNOWN *)a2 )
  {
    return 1; /*0x104f93922*/
  }
  if ( (unsigned __int8)RBX::WorkspaceProp::getNetworkStreamingEnabled(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)) != 0 ) /*0x104f93936*/
  {
    if ( FFlag::EnableSlimAvatarsThreePhaseRolloutProperty != 0 ) /*0x104f93942*/
      goto LABEL_15; /*0x104f93942*/
  }
  else if ( RBX::WorkspaceProperties::prop_StreamingMinRadius == (_UNKNOWN *)a2 /*0x104f9398c*/
         || RBX::WorkspaceProperties::prop_StreamingTargetRadius == (_UNKNOWN *)a2
         || RBX::WorkspaceProperties::prop_StreamOutBehavior == (_UNKNOWN *)a2
         || RBX::WorkspaceProperties::prop_StreamingIntegrityMode == (_UNKNOWN *)a2
         || RBX::WorkspaceProperties::prop_ModelStreamingBehavior == (_UNKNOWN *)a2 )
  {
    return 1; /*0x104f9398c*/
  }
  if ( RBX::WorkspaceProperties::prop_EnableSLIMAvatars == (_UNKNOWN *)a2 ) /*0x104f93998*/
    return 1; /*0x104f93998*/
LABEL_15:
  if ( RBX::WorkspaceProperties::prop_StreamingPauseMode == (_UNKNOWN *)a2 ) /*0x104f939a4*/
    return 1; /*0x104f939a4*/
  result = 0; /*0x104f939ad*/
  if ( RBX::WorkspaceProperties::prop_StreamOutBehavior == (_UNKNOWN *)a2 /*0x104f939be*/
    || RBX::WorkspaceProperties::prop_SignalBehavior == (_UNKNOWN *)a2 )
  {
    return result; /*0x104f939be*/
  }
  if ( RBX::WorkspaceProperties::prop_ClientAnimatorThrottling == (_UNKNOWN *)a2 ) /*0x104f939ca*/
  {
    v6 = DFFlag::EnableClientAnimatorThrottlingMode; /*0x104f93a06*/
    return v6 ^ 1; /*0x104f93a3b*/
  }
  if ( RBX::WorkspaceProperties::prop_Retargeting == (_UNKNOWN *)a2 ) /*0x104f939d6*/
  {
    v6 = DFFlag::EnableAnimatorRetargetingMode; /*0x104f93a0e*/
    return v6 ^ 1; /*0x104f93a14*/
  }
  if ( RBX::WorkspaceProperties::prop_ReplicateInstanceDestroySetting == (_UNKNOWN *)a2 ) /*0x104f939e2*/
    return DFFlag::HideDestroySetting; /*0x104f93a1c*/
  if ( FFlag::DebugCLI122361Omega == 0 && RBX::WorkspaceProperties::prop_PrimalPhysicsSolver == (_UNKNOWN *)a2 ) /*0x104f939f7*/
    return 1; /*0x104f939f7*/
  if ( DFFlag::FluidForcesSwitchToThreePhaseRollout == 1 && RBX::WorkspaceProperties::prop_FluidForces == (_UNKNOWN *)a2 ) /*0x104f93a31*/
  {
    v6 = DFFlag::FluidForcesThreePhaseRolloutProperty; /*0x104f93a33*/
    return v6 ^ 1; /*0x104f93a33*/
  }
  if ( RBX::WorkspaceProperties::prop_AvatarUnificationMode != (_UNKNOWN *)a2 ) /*0x104f93a47*/
  {
    if ( RBX::WorkspaceProperties::prop_IKControlConstraintSupport == (_UNKNOWN *)a2 ) /*0x104f93a57*/
    {
      v6 = DFFlag::IkControlConstraintSupportProperty; /*0x104f93c23*/
      return v6 ^ 1; /*0x104f93c29*/
    }
    if ( RBX::WorkspaceProperties::prop_PlayerCharacterDestroyBehavior == (_UNKNOWN *)a2 ) /*0x104f93a67*/
    {
      v6 = DFFlag::PlayerCharacterDestroyBehaviorProperty; /*0x104f93c2e*/
      return v6 ^ 1; /*0x104f93c34*/
    }
    if ( RBX::WorkspaceProperties::prop_SandboxedInstanceMode == (_UNKNOWN *)a2 ) /*0x104f93a77*/
    {
      v6 = DFFlag::SandboxedInstanceModeProperty; /*0x104f93c39*/
      return v6 ^ 1; /*0x104f93c3f*/
    }
    if ( RBX::WorkspaceProperties::prop_ImprovedPhysicsReplication == (_UNKNOWN *)a2 ) /*0x104f93a87*/
    {
      v6 = DFFlag::ShowImprovedPhysicsReplicationInStudio; /*0x104f93c44*/
      return v6 ^ 1; /*0x104f93c4a*/
    }
    if ( RBX::WorkspaceProperties::prop_InterpolationThrottling != (_UNKNOWN *)a2 ) /*0x104f93a97*/
    {
      if ( RBX::WorkspaceProperties::prop_ImprovedAnimationConstraint == (_UNKNOWN *)a2 ) /*0x104f93aa7*/
      {
        v6 = FFlag::SimImprovedAnimationConstraintRollout; /*0x104f93c4f*/
        return v6 ^ 1; /*0x104f93c55*/
      }
      if ( RBX::WorkspaceProperties::prop_TouchEventsUseCollisionGroups == (_UNKNOWN *)a2 ) /*0x104f93ab7*/
      {
        v6 = DFFlag::TouchEventsUseCollisionGroupsThreePhaseRollout; /*0x104f93c5a*/
        return v6 ^ 1; /*0x104f93c60*/
      }
      if ( RBX::WorkspaceProperties::prop_TouchesUseCollisionGroups == (_UNKNOWN *)a2 ) /*0x104f93ac7*/
        return DFFlag::TouchEventsUseCollisionGroupsPhase3; /*0x104f93c6b*/
      if ( RBX::WorkspaceProperties::prop_UseNewLuauTypeSolver == (_UNKNOWN *)a2 ) /*0x104f93ad7*/
        return 0; /*0x104f93ad7*/
      if ( RBX::WorkspaceProperties::prop_UseFixedSimulation == (_UNKNOWN *)a2 ) /*0x104f93ae7*/
      {
        v6 = FFlag::UseFixedSimulationThreePhaseRolloutProperty; /*0x104f93c70*/
        return v6 ^ 1; /*0x104f93c76*/
      }
      if ( v4 == a2 ) /*0x104f93af0*/
      {
        v6 = FFlag::NextGenReplicationThreePhaseRolloutProperty; /*0x104f93c7b*/
        return v6 ^ 1; /*0x104f93c81*/
      }
      if ( RBX::WorkspaceProperties::prop_PlayerScriptsUseInputActionSystem == (_UNKNOWN *)a2 ) /*0x104f93b00*/
      {
        v6 = FFlag::PlayerScriptsUseInputActionSystemThreePhaseRolloutProperty; /*0x104f93c86*/
        return v6 ^ 1; /*0x104f93c8c*/
      }
      if ( RBX::WorkspaceProperties::prop_ExpandedTerrain == (_UNKNOWN *)a2 ) /*0x104f93b10*/
      {
        v6 = DFFlag::ExpandedTerrainThreePhaseRolloutProperty; /*0x104f93c91*/
        return v6 ^ 1; /*0x104f93c97*/
      }
      if ( RBX::WorkspaceProperties::prop_LuauTypeCheckMode == (_UNKNOWN *)a2 ) /*0x104f93b20*/
        return 0; /*0x104f93cd4*/
      if ( RBX::WorkspaceProperties::prop_AuthorityMode == (_UNKNOWN *)a2 /*0x104f93cb0*/
        && (FFlag::SAuthWorkspaceFlagged != 1 || FFlag::SAuthWorkspacePropertyEnabled == 0) )
      {
        RBX::World::getEngineNetConfiguration(this: (RBX::World *)v11, a2: *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */); /*0x104f93cc1*/
        if ( FFlag::DebugHashTableMetrics != 0 ) /*0x104f93cd0*/
          return 0; /*0x104f93cd0*/
        result = 1; /*0x104f93ce7*/
        if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x104f93ced*/
          return (v11[0] & 8) == 0; /*0x104f93cf7*/
        return result; /*0x104f93ced*/
      }
      if ( RBX::WorkspaceProperties::prop_AirTurbulenceIntensity == (_UNKNOWN *)a2 ) /*0x104f93b40*/
      {
        v6 = FFlag::SimTurbulentFlow; /*0x104f93ce0*/
        return v6 ^ 1; /*0x104f93ce2*/
      }
      if ( (FFlag::SunsetMPHA != 1 || RBX::WorkspaceProperties::prop_MeshPartHeadsAndAccessories != (_UNKNOWN *)a2) /*0x104f93bb2*/
        && (FFlag::WorkspaceAuthorityModeUX != 0
         || RBX::WorkspaceProperties::prop_NextGenerationReplicationAlias != (_UNKNOWN *)a2
         && RBX::WorkspaceProperties::prop_PlayerScriptsUseInputActionSystemAlias != (_UNKNOWN *)a2
         && RBX::WorkspaceProperties::prop_SignalBehaviorAlias != (_UNKNOWN *)a2
         && RBX::WorkspaceProperties::prop_UseFixedSimulationAlias != (_UNKNOWN *)a2
         && RBX::WorkspaceProperties::prop_StreamingEnabledAlias != (_UNKNOWN *)a2) )
      {
        if ( DFFlag::PredictiveStreamingModeAPIEnabled != 0 ) /*0x104f93bbf*/
          return RBX::ModelInstance::isPropertyHiddenInStudio(this, a2); /*0x104f93bbf*/
        result = 1; /*0x104f93bc8*/
        if ( RBX::WorkspaceProperties::prop_PredictiveStreamingMode != (_UNKNOWN *)a2 ) /*0x104f93bcd*/
          return RBX::ModelInstance::isPropertyHiddenInStudio(this, a2); /*0x104f93be3*/
        return result; /*0x104f93be3*/
      }
    }
    return 1; /*0x104f939f9*/
  }
  v7 = RBX::ServiceProvider::find<RBX::AvatarSettings>(a1: this); /*0x104f93bf0*/
  result = 1; /*0x104f93bf3*/
  if ( v7 != 0 ) /*0x104f93bf8*/
  {
    v10 = 0; /*0x104f93c05*/
    Avatar = RBX::AvatarSettings::getValue<RBX::AvatarRules,&(RBX::AvatarRulesProp::getAvatarType(void))>( /*0x104f93c0d*/
               a1: v7,
               a2: &v10);
    std::shared_ptr<RBX::AvatarRules>::~shared_ptr[abi:ne200100](a1: &v10); /*0x104f93c13*/
    return Avatar == 1; /*0x104f93c1b*/
  }
  return result; /*0x104f939fb*/
}

// Address: 0x104f93e4c | Name: __ZNK3RBX9Workspace12askSetParentEPKNS_8InstanceE
bool __fastcall RBX::Workspace::askSetParent(RBX::Workspace *this, const RBX::Instance *a2)
{
  return (unsigned __int8)RBX::Service::askSetParent2(this: a2, a2) != 0 && RBX::ModelInstance::askSetParent(this, a2); /*0x104f93e6b*/
}

// Address: 0x104f93e7c | Name: __ZNK3RBX9Workspace15verifySetParentEPKNS_8InstanceE
__int64 __fastcall RBX::Workspace::verifySetParent(
        RBX::Workspace *this,
        const RBX::Instance *a2,
        const RBX::Instance *a3)
{
  return RBX::Service::verifySetParent2(this, a2, a3); /*0x104f93e80*/
}

// Address: 0x104f93e88 | Name: __ZN3RBX9Workspace21luaCalculateJumpPowerEff
float __fastcall RBX::Workspace::luaCalculateJumpPower(RBX::Humanoid *this, float a2, float a3)
{
  return RBX::Humanoid::calculateJumpPower(this, a2, a3); /*0x104f93e8c*/
}

// Address: 0x104f93e92 | Name: __ZN3RBX9Workspace22luaCalculateJumpHeightEff
__m128i __fastcall RBX::Workspace::luaCalculateJumpHeight(RBX::Humanoid *this, __m128i a2, __m128i a3)
{
  return RBX::Humanoid::calculateJumpHeight(this, a2, a3); /*0x104f93e96*/
}

// Address: 0x104f93e9c | Name: __ZN3RBX9Workspace24luaCalculateJumpDistanceEfff
__m128i __fastcall RBX::Workspace::luaCalculateJumpDistance(RBX::Humanoid *this, float a2, __m128i a3, float a4)
{
  return RBX::Humanoid::calculateJumpDistance(this, a2, a3, a4); /*0x104f93ea0*/
}

// Address: 0x104f93ea6 | Name: __ZN3RBX9Workspace15setModelMeshJobENSt3__110shared_ptrINS_12DataModelJobEEE
__int64 __fastcall RBX::Workspace::setModelMeshJob(__int64 a1)
{
  return std::shared_ptr<RBX::DataModelJob>::operator=[abi:ne200100](a1: a1 + 2320); /*0x104f93eb1*/
}

// Address: 0x104f93f0c | Name: __ZN3RBX9Workspace10onTeardownEv
__int64 __fastcall RBX::Workspace::onTeardown(RBX::Workspace *this)
{
  __int64 v2; // rax
  RBX::ContactManager *v3; // rdi
  std::__shared_weak_count *v4; // r14
  __int64 v5; // rax
  double v6; // xmm0_8
  __int64 v7; // r14
  int v8; // r15d
  unsigned int v9; // eax
  int v10; // r12d
  unsigned int NumPoints; // r13d
  int v12; // r12d
  unsigned int NumContacts; // eax
  __int64 v14; // rdx
  int v15; // r14d
  int v16; // r15d
  unsigned int v17; // r12d
  unsigned int v18; // r13d
  unsigned int v19; // eax
  RBX::Time *v20; // rdi
  RBX::World *v21; // r14
  double v22; // xmm0_8
  _QWORD v24[6]; // [rsp+10h] [rbp-80h] BYREF
  __int128 v25; // [rsp+40h] [rbp-50h] BYREF
  double v26; // [rsp+50h] [rbp-40h]
  __int64 v27; // [rsp+58h] [rbp-38h]
  _QWORD *v28; // [rsp+60h] [rbp-30h]

  v2 = *((_QWORD *)this + 140) /* +1120 likely networkOwnershipUnitChanged..head.px -- UNVERIFIED */; /*0x104f93f20*/
  if ( v2 != 0 ) /*0x104f93f2a*/
    *(_BYTE *)(v2 + 170) &= 0x1Eu; /*0x104f93f2c*/
  v25 = 0; /*0x104f93f3b*/
  RBX::Workspace::setMouseCommand((RBX::IPluginLegacyApi **)this, a2: (const RBX::Instance *)&v25, a3: 0); /*0x104f93f44*/
  v4 = *((std::__shared_weak_count **)&v25 + 1); /*0x104f93f49*/
  if ( *((_QWORD *)&v25 + 1) != 0 /*0x104f93f62*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v25 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(a1: v4); /*0x104f93f6a*/
    std::__shared_weak_count::__release_weak(this: v4); /*0x104f93f70*/
  }
  v5 = *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */; /*0x104f93f75*/
  if ( v5 != 0 ) /*0x104f93f7f*/
  {
    v3 = *(RBX::ContactManager **)(v5 + 2056); /*0x104f93f81*/
    if ( v3 != nullptr ) /*0x104f93f8b*/
      RBX::ContactManager::fastClear(this: v3); /*0x104f93f8d*/
  }
  RBX::Time::nowFast(this: v3); /*0x104f93f92*/
  v26 = v6; /*0x104f93f97*/
  v7 = *((_QWORD *)this + 118) /* +944: NO 2022 FIELD */; /*0x104f93f9c*/
  if ( v7 != 0 ) /*0x104f93fa6*/
  {
    v8 = FLog::CloseDataModel; /*0x104f93fb3*/
    v9 = (unsigned int)FLog::CloseDataModel >> 8; /*0x104f93fb9*/
    if ( (unsigned __int8)FLog::CloseDataModel >= 6u && BYTE1(FLog::CloseDataModel) >= 3u ) /*0x104f93fc5*/
    {
      v10 = qword_10D7F3CC8; /*0x104f93fcc*/
      NumPoints = RBX::World::getNumPoints(this: *((RBX::World **)this + 118)); /*0x104f93fd8*/
      v24[2] = (unsigned int)RBX::World::getNumConstraints(this: (RBX::World *)v7); /*0x104f93fef*/
      v27 = 17; /*0x104f93ff3*/
      v28 = v24; /*0x104f93ffb*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x104f94027*/
        a1: v8,
        a2: v10,
        a3: 3,
        a4: (unsigned int)"[FLog::CloseDataModel] Clearing World -- {} Points, {} Constraints",
        a5: 66,
        a6: 1,
        17,
        v24,
        NumPoints);
      v8 = FLog::CloseDataModel; /*0x104f94033*/
      v9 = (unsigned int)FLog::CloseDataModel >> 8; /*0x104f94039*/
    }
    if ( (unsigned __int8)v8 >= 6u && (unsigned __int8)v9 >= 3u ) /*0x104f94045*/
    {
      v12 = qword_10D7F3CC8; /*0x104f9404c*/
      NumContacts = RBX::World::getNumContacts(this: (RBX::ContactManager **)v7); /*0x104f94053*/
      v14 = (*(_QWORD *)(v7 + 624) - *(_QWORD *)(v7 + 616)) >> 3; /*0x104f9406d*/
      v24[2] = *(unsigned int *)(v7 + 1812); /*0x104f9407c*/
      v24[4] = (unsigned int)v14; /*0x104f94080*/
      v27 = 273; /*0x104f94084*/
      v28 = v24; /*0x104f9408c*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x104f940b8*/
        a1: v8,
        a2: v12,
        a3: 3,
        a4: (unsigned int)"[FLog::CloseDataModel] Clearing World -- {} Contacts, {} Joints, {} Primitives",
        a5: 78,
        a6: 1,
        273,
        v24,
        NumContacts);
    }
    *(_BYTE *)(v7 + 853) = 1; /*0x104f940bd*/
    RBX::World::prepareJointsForTeardown(this: (RBX::World *)v7); /*0x104f940c8*/
  }
  v15 = FLog::CloseDataModel; /*0x104f940d4*/
  if ( (unsigned __int8)FLog::CloseDataModel >= 6u && BYTE1(FLog::CloseDataModel) >= 3u ) /*0x104f940e7*/
  {
    v16 = qword_10D7F3CC8; /*0x104f940ee*/
    v17 = RBX::Instance::countDescendantsOfType<RBX::Instance>(a1: this); /*0x104f940fa*/
    v18 = RBX::Instance::countDescendantsOfType<RBX::BasePart>(a1: this); /*0x104f94105*/
    v19 = RBX::Instance::countDescendantsOfType<RBX::BaseScript>(a1: this); /*0x104f9410b*/
    v24[2] = v18; /*0x104f9411f*/
    v24[4] = v19; /*0x104f94123*/
    v27 = 273; /*0x104f94127*/
    v28 = v24; /*0x104f9412f*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x104f9415b*/
      a1: v15,
      a2: v16,
      a3: 3,
      a4: (unsigned int)"[FLog::CloseDataModel] Clearing Workspace -- {} Instances, {} Parts, {} Scripts",
      a5: 79,
      a6: 1,
      273,
      v24,
      v17);
  }
  RBX::Instance::removeAllChildren(this); /*0x104f94163*/
  v21 = *((RBX::World **)this + 118); /*0x104f94168*/
  if ( v21 != nullptr ) /*0x104f94172*/
  {
    RBX::Time::nowFast(this: v20); /*0x104f94174*/
    RBX::World::sendWorkspaceRemoveAllChildrenAnalytics(this: v21, a2: (v22 - v26) * 1000.0); /*0x104f94189*/
  }
  RBX::WorkspaceProp::setCurrentCamera(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */), a2: nullptr); /*0x104f94197*/
  return RBX::Workspace::stopModelMeshJob(this); /*0x104f941a4*/
}

// Address: 0x104f94252 | Name: __ZThn1408_N3RBX9Workspace10onTeardownEv
__int64 __fastcall `non-virtual thunk to'RBX::Workspace::onTeardown(RBX::Workspace *this)
{
  return RBX::Workspace::onTeardown(this: (RBX::Workspace *)((char *)this - 1408)); /*0x104f9425d*/
}

// Address: 0x104f94264 | Name: __ZN3RBX9Workspace13getShow3DGridEv
char __fastcall RBX::Workspace::getShow3DGrid(RBX::Workspace *this)
{
  return *((_BYTE *)this + 2112) /* +2112: NO 2022 FIELD */ & 1; /*0x104f94270*/
}

// Address: 0x104f94272 | Name: __ZNK3RBX9Workspace36getNextGenerationReplicationCallbackEv
__int64 __fastcall RBX::Workspace::getNextGenerationReplicationCallback(RBX::Workspace *this)
{
  if ( *((_DWORD *)this + 287) /* +1148: NO 2022 FIELD */ != 0 ) /*0x104f9427d*/
    return RBX::WorkspaceProp::getNextGenerationReplicationGetOnly(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f94287*/
  else
    return 2; /*0x104f9428c*/
}

// Address: 0x104f94294 | Name: __ZNK3RBX9Workspace34getNetworkStreamingEnabledCallbackEv
char __fastcall RBX::Workspace::getNetworkStreamingEnabledCallback(RBX::Workspace *this)
{
  if ( *((_DWORD *)this + 287) /* +1148: NO 2022 FIELD */ != 0 ) /*0x104f9429f*/
    return RBX::WorkspaceProp::getNetworkStreamingEnabledGetOnly(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f942a9*/
  else
    return 1; /*0x104f942ae*/
}

// Address: 0x104f942b2 | Name: __ZNK3RBX9Workspace25getSignalBehaviorCallbackEv
__int64 __fastcall RBX::Workspace::getSignalBehaviorCallback(RBX::Workspace *this)
{
  if ( *((_DWORD *)this + 287) /* +1148: NO 2022 FIELD */ != 0 ) /*0x104f942bd*/
    return RBX::WorkspaceProp::getSignalBehaviorGetOnly(this: (RBX::Workspace *)((char *)this + 1056 /* +1056 = networkOwnershipUnitMovedSignal..slots (std::shared_ptr<std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> >, 16B) -- SIZE CONFLICT, see --verify */)); /*0x104f942c7*/
  else
    return 2; /*0x104f942cc*/
}

// Address: 0x104f942d4 | Name: __ZN3RBX9Workspace13setShow3DGridEb
char __fastcall RBX::Workspace::setShow3DGrid(RBX::Workspace *this, char a2)
{
  char result; // al

  result = *((_BYTE *)this + 2112) /* +2112: NO 2022 FIELD */ & 1; /*0x104f942de*/
  if ( result != a2 ) /*0x104f942e3*/
  {
    *((_BYTE *)this + 2112) /* +2112: NO 2022 FIELD */ = a2; /*0x104f942e5*/
    return rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::Workspace *)((char *)this + 1432 /* +1432 = currentCommand.._Ptr (RBX::MouseCommand *, 8B) -- SIZE CONFLICT, see --verify */)); /*0x104f942f4*/
  }
  return result; /*0x104f942f3*/
}

// Address: 0x104f942fc | Name: __ZNK3RBX9Workspace27getEnableSLIMAvatarsEnabledEv
char __fastcall RBX::Workspace::getEnableSLIMAvatarsEnabled(RBX::Workspace *this)
{
  int v1; // eax

  if ( FFlag::EnableSlimAvatarsThreePhaseRolloutProperty != 1 ) /*0x104f9430a*/
    return FFlag::EnableSlimAvatarsDefaultEnabled; /*0x104f9430a*/
  v1 = *((_DWORD *)this + 290) /* +1160 likely monotonicClock.lastReceivedTimeUS -- UNVERIFIED */; /*0x104f9430c*/
  if ( v1 == 2 ) /*0x104f94315*/
    return 1; /*0x104f9432d*/
  if ( v1 != 1 ) /*0x104f9431a*/
    return FFlag::EnableSlimAvatarsDefaultEnabled; /*0x104f94328*/
  return 0; /*0x104f94327*/
}

// Address: 0x104f94332 | Name: __ZNK3RBX9Workspace38getMeshStreamingAndImprovedLodsEnabledEv
char __fastcall RBX::Workspace::getMeshStreamingAndImprovedLodsEnabled(RBX::Workspace *this)
{
  int v1; // eax

  if ( DFFlag::MeshStreamingAndImprovedLodsThreePhaseRolloutProperty != 1 ) /*0x104f9433d*/
    return DFFlag::MeshStreamingAndImprovedLodsDefaultEnabled; /*0x104f9433d*/
  v1 = *((_DWORD *)this + 300) /* +1200 likely networkOwnershipUnitJointsChangedConnection.con.weak_slot.p_ -- UNVERIFIED */; /*0x104f9433f*/
  if ( v1 == 2 ) /*0x104f94348*/
    return 1; /*0x104f9435d*/
  if ( v1 != 1 ) /*0x104f9434d*/
    return DFFlag::MeshStreamingAndImprovedLodsDefaultEnabled; /*0x104f94358*/
  return 0; /*0x104f94357*/
}

// Address: 0x104f94362 | Name: __ZNK3RBX9Workspace25getExpandedTerrainEnabledEv
char __fastcall RBX::Workspace::getExpandedTerrainEnabled(RBX::Workspace *this)
{
  int v1; // eax

  if ( DFFlag::ExpandedTerrainThreePhaseRolloutProperty != 1 ) /*0x104f9436d*/
    return DFFlag::ExpandedTerrainDefaultEnabled; /*0x104f9436d*/
  v1 = *((_DWORD *)this + 291) /* +1164: NO 2022 FIELD */; /*0x104f9436f*/
  if ( v1 == 2 ) /*0x104f94378*/
    return 1; /*0x104f9438d*/
  if ( v1 != 1 ) /*0x104f9437d*/
    return DFFlag::ExpandedTerrainDefaultEnabled; /*0x104f94388*/
  return 0; /*0x104f94387*/
}

// Address: 0x104f94392 | Name: __ZN3RBX9Workspace40triggerDeferredReplicationPVDirtySignalsEv
__int64 __fastcall RBX::Workspace::triggerDeferredReplicationPVDirtySignals(RBX::Workspace *this)
{
  char *v2; // rbx
  __int64 v3; // rax
  const RBX::Guid *v4; // rdx
  __int64 v5; // r13
  const RBX::Guid *v6; // r15
  const RBX::Guid *v7; // r12
  RBX::BasePart *PrimitiveFromGuid; // rax
  RBX::Primitive *v9; // rsi
  RBX::BasePart *v10; // rax

  v2 = (char *)this + 3264 /* +3264: NO 2022 FIELD */; /*0x104f943a3*/
  v3 = RBX::detail::DenseSetImpl<RBX::Guid,RBX::DenseMap<RBX::Guid,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<RBX::Guid,void>,RBX::detail::DenseSetPair<RBX::Guid>>,RBX::DenseMapInfo<RBX::Guid,void>>::begin(a1: (char *)this + 3264 /* +3264: NO 2022 FIELD */); /*0x104f943ad*/
  v5 = *((_QWORD *)this + 408) /* +3264: NO 2022 FIELD */ + 8LL * *((unsigned int *)this + 820); /*0x104f943bd*/
  if ( v3 != v5 ) /*0x104f943c7*/
  {
    v6 = (const RBX::Guid *)v3; /*0x104f943c9*/
    v7 = v4; /*0x104f943cc*/
    do /*0x104f9440c*/
    {
      PrimitiveFromGuid = (RBX::BasePart *)RBX::World::getPrimitiveFromGuid(this: *((RBX::World **)this + 118), a2: v6); /*0x104f943d9*/
      v10 = (RBX::BasePart *)RBX::BasePart::fromPrimitive(this: PrimitiveFromGuid, a2: v9); /*0x104f943e1*/
      if ( v10 != nullptr ) /*0x104f943e9*/
        RBX::BasePart::triggerReplicationPVDirtySignals(this: v10); /*0x104f943ee*/
      do /*0x104f94407*/
        v6 = (const RBX::Guid *)((char *)v6 + 8); /*0x104f943f3*/
      while ( v6 != v7 && *((_DWORD *)v6 + 1) <= 1u && *(_DWORD *)v6 == -1 ); /*0x104f94407*/
    }
    while ( v6 != (const RBX::Guid *)v5 ); /*0x104f9440c*/
  }
  return RBX::DenseMapBase<RBX::DenseMap<RBX::Guid,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<RBX::Guid,void>,RBX::detail::DenseSetPair<RBX::Guid>>,RBX::Guid,RBX::detail::DenseSetEmpty,RBX::DenseMapInfo<RBX::Guid,void>,RBX::detail::DenseSetPair<RBX::Guid>>::clear( /*0x104f9441a*/
           a1: v2,
           a2: 1);
}

// Address: 0x104f9446e | Name: __ZNK3RBX9Workspace29getOverrideInstancePropertiesEPKNS_10Reflection18PropertyDescriptorE
RBX::Workspace *__fastcall RBX::Workspace::getOverrideInstanceProperties(
        RBX::Workspace *this,
        const RBX::Reflection::PropertyDescriptor *a2,
        void *a3)
{
  char v6; // r12
  __int64 v7; // r9
  __int64 v8; // rax
  __int64 v9; // r9
  __int64 v10; // rax
  __int64 v11; // r9
  __int64 v12; // rax
  __int64 v13; // r9
  __int64 v14; // rax
  __int64 v15; // r9
  __int64 v16; // rax
  __int64 v17; // rax
  const RBX::Reflection::PropertyDescriptor **v19; // [rsp+0h] [rbp-50h] BYREF
  const RBX::Reflection::PropertyDescriptor *v20; // [rsp+8h] [rbp-48h] BYREF
  char v21; // [rsp+17h] [rbp-39h] BYREF
  const RBX::Reflection::PropertyDescriptor ***v22; // [rsp+18h] [rbp-38h] BYREF
  int v23; // [rsp+20h] [rbp-30h]
  _QWORD v24[5]; // [rsp+28h] [rbp-28h] BYREF

  v6 = FFlag::WorkspaceAuthorityModeUX; /*0x104f94494*/
  RBX::Instance::getOverrideInstanceProperties(this, a2); /*0x104f9449b*/
  if ( v6 != 0 || FFlag::SAuthWorkspaceFlagged == 0 ) /*0x104f944b3*/
    return this; /*0x104f944b3*/
  if ( FFlag::SAuthRequirePropertyDependenciesToggled == 1 ) /*0x104f944c6*/
  {
    if ( (FFlag::SAuthWorkspacePropertyEnabled & 1) == 0 || *((_DWORD *)a2 + 287) == 1 ) /*0x104f944d8*/
    {
      if ( RBX::WorkspaceProperties::prop_AuthorityMode == a3 ) /*0x104f944e8*/
      {
        if ( (unsigned __int8)RBX::WorkspaceProp::getNetworkStreamingEnabled(this: (const RBX::Reflection::PropertyDescriptor *)((char *)a2 + 1056)) == 0 ) /*0x104f944fc*/
        {
          v19 = (const RBX::Reflection::PropertyDescriptor **)a2; /*0x104f94502*/
          v22 = &v19; /*0x104f94509*/
          v8 = ((__int64 (__fastcall *)(RBX::Workspace *, const RBX::Reflection::PropertyDescriptor ***, const char *, const RBX::Reflection::PropertyDescriptor ****, const RBX::Reflection::PropertyDescriptor **, __int64))std::__hash_table<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::__unordered_map_hasher<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,true>,std::__unordered_map_equal<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::equal_to<RBX::Instance *>,std::hash<RBX::Instance *>,true>,std::allocator<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>>>::__emplace_unique_key_args<RBX::Instance *,std::piecewise_construct_t const&,std::tuple<RBX::Instance *&&>,std::tuple<>>)( /*0x104f9451a*/
                 a1: this,
                 a2: &v19,
                 a3: std::piecewise_construct,
                 a4: &v22,
                 a5: &v20,
                 a6: v7);
          v22 = (const RBX::Reflection::PropertyDescriptor ***)RBX::WorkspaceProperties::prop_StreamingEnabled; /*0x104f94531*/
          v23 = 2; /*0x104f94534*/
          std::vector<RBX::OverridingProperty>::push_back[abi:ne200100](a1: v8 + 24); /*0x104f9453e*/
        }
        if ( !RBX::Workspace::isNextGenerationReplicationEnabledProp(this: a2) ) /*0x104f94546*/
        {
          v19 = (const RBX::Reflection::PropertyDescriptor **)a2; /*0x104f94553*/
          v22 = &v19; /*0x104f9455a*/
          v10 = ((__int64 (__fastcall *)(RBX::Workspace *, const RBX::Reflection::PropertyDescriptor ***, const char *, const RBX::Reflection::PropertyDescriptor ****, const RBX::Reflection::PropertyDescriptor **, __int64))std::__hash_table<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::__unordered_map_hasher<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,true>,std::__unordered_map_equal<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::equal_to<RBX::Instance *>,std::hash<RBX::Instance *>,true>,std::allocator<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>>>::__emplace_unique_key_args<RBX::Instance *,std::piecewise_construct_t const&,std::tuple<RBX::Instance *&&>,std::tuple<>>)( /*0x104f9456b*/
                  a1: this,
                  a2: &v19,
                  a3: std::piecewise_construct,
                  a4: &v22,
                  a5: &v20,
                  a6: v9);
          v22 = (const RBX::Reflection::PropertyDescriptor ***)RBX::WorkspaceProperties::prop_NextGenerationReplication; /*0x104f94582*/
          v23 = 2; /*0x104f94585*/
          std::vector<RBX::OverridingProperty>::push_back[abi:ne200100](a1: v10 + 24); /*0x104f9458f*/
        }
        if ( RBX::Workspace::useDeferredSignals(this: a2) == 0 ) /*0x104f9459e*/
        {
          v19 = (const RBX::Reflection::PropertyDescriptor **)a2; /*0x104f945a4*/
          v22 = &v19; /*0x104f945ab*/
          v12 = ((__int64 (__fastcall *)(RBX::Workspace *, const RBX::Reflection::PropertyDescriptor ***, const char *, const RBX::Reflection::PropertyDescriptor ****, const RBX::Reflection::PropertyDescriptor **, __int64))std::__hash_table<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::__unordered_map_hasher<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,true>,std::__unordered_map_equal<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::equal_to<RBX::Instance *>,std::hash<RBX::Instance *>,true>,std::allocator<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>>>::__emplace_unique_key_args<RBX::Instance *,std::piecewise_construct_t const&,std::tuple<RBX::Instance *&&>,std::tuple<>>)( /*0x104f945bc*/
                  a1: this,
                  a2: &v19,
                  a3: std::piecewise_construct,
                  a4: &v22,
                  a5: &v20,
                  a6: v11);
          v22 = (const RBX::Reflection::PropertyDescriptor ***)RBX::WorkspaceProperties::prop_SignalBehavior; /*0x104f945d3*/
          v23 = 2; /*0x104f945d6*/
          std::vector<RBX::OverridingProperty>::push_back[abi:ne200100](a1: v12 + 24); /*0x104f945e0*/
        }
        if ( RBX::Workspace::getUseFixedSimulationEnabled(this: a2) == 0 ) /*0x104f945ef*/
        {
          v19 = (const RBX::Reflection::PropertyDescriptor **)a2; /*0x104f945f5*/
          v22 = &v19; /*0x104f945fc*/
          v14 = ((__int64 (__fastcall *)(RBX::Workspace *, const RBX::Reflection::PropertyDescriptor ***, const char *, const RBX::Reflection::PropertyDescriptor ****, const RBX::Reflection::PropertyDescriptor **, __int64))std::__hash_table<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::__unordered_map_hasher<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,true>,std::__unordered_map_equal<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::equal_to<RBX::Instance *>,std::hash<RBX::Instance *>,true>,std::allocator<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>>>::__emplace_unique_key_args<RBX::Instance *,std::piecewise_construct_t const&,std::tuple<RBX::Instance *&&>,std::tuple<>>)( /*0x104f9460d*/
                  a1: this,
                  a2: &v19,
                  a3: std::piecewise_construct,
                  a4: &v22,
                  a5: &v20,
                  a6: v13);
          v22 = (const RBX::Reflection::PropertyDescriptor ***)RBX::WorkspaceProperties::prop_UseFixedSimulation; /*0x104f94624*/
          v23 = 2; /*0x104f94627*/
          std::vector<RBX::OverridingProperty>::push_back[abi:ne200100](a1: v14 + 24); /*0x104f94631*/
        }
        if ( (unsigned __int8)RBX::Workspace::getPlayerScriptsUseInputActionSystemEnabled(this: a2) == 0 ) /*0x104f94640*/
        {
          v19 = (const RBX::Reflection::PropertyDescriptor **)a2; /*0x104f9464a*/
          v22 = &v19; /*0x104f94651*/
          v16 = ((__int64 (__fastcall *)(RBX::Workspace *, const RBX::Reflection::PropertyDescriptor ***, const char *, const RBX::Reflection::PropertyDescriptor ****, const RBX::Reflection::PropertyDescriptor **, __int64))std::__hash_table<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::__unordered_map_hasher<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,true>,std::__unordered_map_equal<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::equal_to<RBX::Instance *>,std::hash<RBX::Instance *>,true>,std::allocator<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>>>::__emplace_unique_key_args<RBX::Instance *,std::piecewise_construct_t const&,std::tuple<RBX::Instance *&&>,std::tuple<>>)( /*0x104f94662*/
                  a1: this,
                  a2: &v19,
                  a3: std::piecewise_construct,
                  a4: &v22,
                  a5: &v20,
                  a6: v15);
          v22 = (const RBX::Reflection::PropertyDescriptor ***)RBX::WorkspaceProperties::prop_PlayerScriptsUseInputActionSystem; /*0x104f94679*/
          v23 = 2; /*0x104f9467c*/
          std::vector<RBX::OverridingProperty>::push_back[abi:ne200100](a1: v16 + 24); /*0x104f94686*/
        }
      }
      return this; /*0x104f9468b*/
    }
  }
  else if ( (FFlag::SAuthWorkspacePropertyEnabled & 1) == 0 ) /*0x104f94692*/
  {
    return this; /*0x104f94692*/
  }
  if ( *((_DWORD *)a2 + 287) != 1 /*0x104f946e0*/
    && (RBX::WorkspaceProperties::prop_SignalBehavior == a3
     || RBX::WorkspaceProperties::prop_StreamingEnabled == a3
     || RBX::WorkspaceProperties::prop_NextGenerationReplication == a3
     || RBX::WorkspaceProperties::prop_UseFixedSimulation == a3
     || RBX::WorkspaceProperties::prop_PlayerScriptsUseInputActionSystem == a3) )
  {
    v22 = (const RBX::Reflection::PropertyDescriptor ***)RBX::WorkspaceProperties::prop_AuthorityMode; /*0x104f946ec*/
    v23 = 2; /*0x104f946f0*/
    v20 = a2; /*0x104f946fb*/
    v19 = &v20; /*0x104f94702*/
    v17 = ((__int64 (__fastcall *)(RBX::Workspace *, const RBX::Reflection::PropertyDescriptor **, const char *, const RBX::Reflection::PropertyDescriptor ***, char *))std::__hash_table<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::__unordered_map_hasher<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,true>,std::__unordered_map_equal<RBX::Instance *,std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>,std::equal_to<RBX::Instance *>,std::hash<RBX::Instance *>,true>,std::allocator<std::__hash_value_type<RBX::Instance *,std::vector<RBX::OverridingProperty>>>>::__emplace_unique_key_args<RBX::Instance *,std::piecewise_construct_t const&,std::tuple<RBX::Instance *&&>,std::tuple<>>)( /*0x104f94713*/
            a1: this,
            a2: &v20,
            a3: std::piecewise_construct,
            a4: &v19,
            a5: &v21);
    std::vector<RBX::OverridingProperty>::__assign_with_size[abi:ne200100]<RBX::OverridingProperty const*,RBX::OverridingProperty const*>( /*0x104f9472c*/
      a1: v17 + 24,
      a2: &v22,
      a3: v24,
      a4: 1);
  }
  return this; /*0x104f94744*/
}

// Address: 0x104f9748c | Name: __ZNK3RBX9Workspace21getStatsFileTimeTotalEv
double __fastcall RBX::Workspace::getStatsFileTimeTotal(RBX::Workspace *this)
{
  return *((double *)this + 280) /* +2240: NO 2022 FIELD */ + *((double *)this + 281) /* +2248: NO 2022 FIELD */ + *((double *)this + 282) /* +2256: NO 2022 FIELD */ + *((double *)this + 283) /* +2264: NO 2022 FIELD */; /*0x104f974b0*/
}

// Address: 0x104f974b2 | Name: __ZNK3RBX9Workspace23getStatsSyncHttpGetTimeEv
double __fastcall RBX::Workspace::getStatsSyncHttpGetTime(RBX::Workspace *this)
{
  return *((double *)this + 280) /* +2240: NO 2022 FIELD */; /*0x104f974be*/
}

// Address: 0x104f974c0 | Name: __ZNK3RBX9Workspace19getStatsXMLLoadTimeEv
double __fastcall RBX::Workspace::getStatsXMLLoadTime(RBX::Workspace *this)
{
  return *((double *)this + 281) /* +2248: NO 2022 FIELD */; /*0x104f974cc*/
}

// Address: 0x104f974ce | Name: __ZNK3RBX9Workspace19getStatsJoinAllTimeEv
double __fastcall RBX::Workspace::getStatsJoinAllTime(RBX::Workspace *this)
{
  return *((double *)this + 283) /* +2264: NO 2022 FIELD */; /*0x104f974da*/
}

// Address: 0x104f9c73e | Name: __ZZN3RBX9Workspace23visitMovingNOUInstancesEPNS_8BasePartERKNSt3__18functionIFbPNS_8InstanceEEEERKNS4_IFbS2_S2_EEEENK3$_0clEPNS_9PrimitiveE
char __fastcall RBX::Workspace::visitMovingNOUInstances(RBX::BasePart *,std::function<bool ()(RBX::Instance *)> const&,std::function<bool ()(RBX::BasePart *,RBX::BasePart *)> const&)::$_0::operator()(
        __int64 *a1,
        RBX::Primitive *a2)
{
  RBX::Joint *v3; // rax
  __int64 v4; // rcx
  __int64 v5; // rdi
  const RBX::Joint **v6; // rax
  const RBX::Joint *i; // r13
  __int64 JointOwner; // rbx
  RBX::Primitive *v9; // rsi
  RBX::Primitive *v10; // r12
  const RBX::Joint *v11; // rsi
  __int64 v12; // r14
  const RBX::Primitive *v13; // rsi
  RBX::Attachment *Attachment0; // rax
  __int64 (__fastcall **v15)(); // r15
  RBX::Joint *PartAncestor; // rax
  __int64 v17; // rax
  __int64 v18; // rdi
  char v19; // al
  __int64 *v20; // rdx
  _BYTE *v21; // rcx
  __int64 v22; // rax
  __int64 v23; // rax
  RBX::Attachment *Attachment1; // rax
  __int64 (__fastcall **v25)(); // r15
  RBX::Joint *v26; // rax
  __int64 v27; // rax
  __int64 v28; // rdi
  char v29; // al
  __int64 *v30; // rdx
  _BYTE *v31; // rcx
  __int64 v32; // rax
  __int64 v33; // rax
  const RBX::Joint *v34; // rsi
  __int64 v35; // rax
  RBX::Primitive *v36; // rcx
  char v37; // al
  __int64 v38; // rax
  RBX::Primitive *v39; // rcx
  __int64 v40; // rax
  RBX::Primitive *v41; // rcx
  const RBX::Joint *v42; // rsi
  __int64 v43; // rax
  __int64 v44; // rdi
  const RBX::Joint *v45; // rsi
  __int64 v46; // rax
  __int64 v47; // r9
  __int64 v48; // rcx
  char *v49; // rax
  char *v50; // rsi
  __int64 v51; // rdx
  __int64 v52; // rax
  __int64 v53; // rax
  char v54; // al
  _QWORD v56[2]; // [rsp+0h] [rbp-B0h] BYREF
  RBX::Constraints::ConstraintProp *v57; // [rsp+10h] [rbp-A0h]
  unsigned __int8 v58; // [rsp+18h] [rbp-98h] BYREF
  char v59; // [rsp+19h] [rbp-97h] BYREF
  __int64 v60; // [rsp+20h] [rbp-90h]
  void *v61; // [rsp+28h] [rbp-88h]
  RBX::Joint *v62; // [rsp+30h] [rbp-80h]
  RBX::Primitive *v63; // [rsp+38h] [rbp-78h]
  __int64 *v64; // [rsp+40h] [rbp-70h]
  char v65; // [rsp+4Fh] [rbp-61h]
  __int64 (__fastcall **v66)(); // [rsp+50h] [rbp-60h] BYREF
  __int64 v67; // [rsp+58h] [rbp-58h]
  void *v68; // [rsp+60h] [rbp-50h]
  __int64 (__fastcall ***v69)(); // [rsp+70h] [rbp-40h]

  v63 = a2; /*0x104f9c763*/
  v3 = (RBX::Joint *)RBX::BasePart::fromPrimitive(this: a2, a2); /*0x104f9c76a*/
  v65 = 1; /*0x104f9c76f*/
  if ( v3 != nullptr )
  {
    v64 = a1; /*0x104f9c77c*/
    v4 = *a1; /*0x104f9c780*/
    v62 = v3; /*0x104f9c783*/
    v66 = (__int64 (__fastcall **)())v3; /*0x104f9c787*/
    v5 = *(_QWORD *)(v4 + 32); /*0x104f9c78b*/
    if ( v5 == 0 ) /*0x104f9c792*/
      std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x104f9cc58*/
    *(_BYTE *)v64[2] &= (*(__int64 (__fastcall **)(__int64, __int64 (__fastcall ***)()))(*(_QWORD *)v5 + 48LL))( /*0x104f9c7aa*/
                          a1: v5,
                          a2: &v66);
    v6 = *((const RBX::Joint ***)v63 + 48); /*0x104f9c7b0*/
    if ( *((const RBX::Joint ***)v63 + 49) != v6 )
    {
      for ( i = *v6; i != nullptr; i = (const RBX::Joint *)RBX::Primitive::getNextJoint(this: v63, a2: i) )
      {
        JointOwner = RBX::Joint::getJointOwner(this: i); /*0x104f9c7d8*/
        if ( JointOwner == 0 ) /*0x104f9c7de*/
          continue; /*0x104f9c7de*/
        v10 = *((RBX::Primitive **)i + 19); /*0x104f9c7e4*/
        if ( v10 == v63 ) /*0x104f9c7ef*/
          v10 = *((RBX::Primitive **)i + 20); /*0x104f9c7f1*/
        if ( v10 == nullptr ) /*0x104f9c7fb*/
          continue; /*0x104f9c7fb*/
        v12 = RBX::BasePart::fromPrimitive(this: v10, a2: v9); /*0x104f9c809*/
        if ( v12 == 0 ) /*0x104f9c80f*/
          continue; /*0x104f9c80f*/
        if ( (unsigned __int8)RBX::Joint::isConstraintOwned(this: i, a2: v11) == 0 ) /*0x104f9c81f*/
          goto LABEL_30; /*0x104f9c81f*/
        v57 = (RBX::Constraints::ConstraintProp *)(JointOwner - 16); /*0x104f9c829*/
        Attachment0 = (RBX::Attachment *)RBX::Constraints::ConstraintProp::getAttachment0(this: (RBX::Constraints::ConstraintProp *)(JointOwner - 16)); /*0x104f9c830*/
        v15 = (__int64 (__fastcall **)())Attachment0; /*0x104f9c835*/
        if ( Attachment0 != nullptr ) /*0x104f9c83b*/
        {
          PartAncestor = (RBX::Joint *)RBX::Attachment::findPartAncestor(this: Attachment0); /*0x104f9c844*/
          if ( PartAncestor == v62 ) /*0x104f9c84d*/
          {
            v17 = *v64; /*0x104f9c857*/
            v66 = v15; /*0x104f9c85a*/
            v18 = *(_QWORD *)(v17 + 32); /*0x104f9c85e*/
            if ( v18 == 0 ) /*0x104f9c865*/
              std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x104f9cc6b*/
            v19 = (*(__int64 (__fastcall **)(__int64, __int64 (__fastcall ***)()))(*(_QWORD *)v18 + 48LL))( /*0x104f9c872*/
                    a1: v18,
                    a2: &v66);
            v20 = v64; /*0x104f9c875*/
            v21 = (_BYTE *)v64[2]; /*0x104f9c879*/
            *v21 &= v19; /*0x104f9c87d*/
            v22 = *v20; /*0x104f9c87f*/
            v66 = off_10C9F1EB8; /*0x104f9c889*/
            v67 = v22; /*0x104f9c88d*/
            v68 = v21; /*0x104f9c891*/
            v69 = &v66; /*0x104f9c899*/
            RBX::NetworkUtil::forEachAttachmentBetweenAttachmentAndOwnerPart(a1: v15, a2: v62, a3: &v66, a4: 4); /*0x104f9c8af*/
            if ( v69 == &v66 ) /*0x104f9c8bb*/
            {
              v23 = 4; /*0x104f9c8eb*/
LABEL_21:
              (*v69)[v23](); /*0x104f9c8f0*/
              goto LABEL_22; /*0x104f9c8f3*/
            }
            v23 = 5; /*0x104f9c8bd*/
            if ( v69 != nullptr ) /*0x104f9c8c5*/
              goto LABEL_21; /*0x104f9c8c5*/
          }
        }
LABEL_22:
        Attachment1 = (RBX::Attachment *)RBX::Constraints::ConstraintProp::getAttachment1(this: v57); /*0x104f9c8f6*/
        v25 = (__int64 (__fastcall **)())Attachment1; /*0x104f9c902*/
        if ( Attachment1 == nullptr ) /*0x104f9c908*/
          goto LABEL_30; /*0x104f9c908*/
        v26 = (RBX::Joint *)RBX::Attachment::findPartAncestor(this: Attachment1); /*0x104f9c911*/
        if ( v26 != v62 ) /*0x104f9c91a*/
          goto LABEL_30; /*0x104f9c91a*/
        v27 = *v64; /*0x104f9c924*/
        v66 = v25; /*0x104f9c927*/
        v28 = *(_QWORD *)(v27 + 32); /*0x104f9c92b*/
        if ( v28 == 0 ) /*0x104f9c932*/
          std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x104f9cc72*/
        v29 = (*(__int64 (__fastcall **)(__int64, __int64 (__fastcall ***)()))(*(_QWORD *)v28 + 48LL))( /*0x104f9c93f*/
                a1: v28,
                a2: &v66);
        v30 = v64; /*0x104f9c942*/
        v31 = (_BYTE *)v64[2]; /*0x104f9c946*/
        *v31 &= v29; /*0x104f9c94a*/
        v32 = *v30; /*0x104f9c94c*/
        v66 = off_10C9F1F38; /*0x104f9c956*/
        v67 = v32; /*0x104f9c95a*/
        v68 = v31; /*0x104f9c95e*/
        v69 = &v66; /*0x104f9c966*/
        RBX::NetworkUtil::forEachAttachmentBetweenAttachmentAndOwnerPart(a1: v25, a2: v62, a3: &v66, a4: 4); /*0x104f9c97c*/
        if ( v69 == &v66 ) /*0x104f9c988*/
        {
          v33 = 4; /*0x104f9c996*/
        }
        else
        {
          v33 = 5; /*0x104f9c98a*/
          if ( v69 == nullptr ) /*0x104f9c992*/
            goto LABEL_30; /*0x104f9c992*/
        }
        (*v69)[v33](); /*0x104f9c99e*/
LABEL_30:
        if ( RBX::Primitive::computeIsGrounded(this: v10, a2: v13) ) /*0x104f9c9a4*/
        {
          v35 = *((_QWORD *)v63 + 3); /*0x104f9c9b1*/
          v36 = (RBX::Primitive *)(v35 - 16); /*0x104f9c9b5*/
          if ( v35 == 0 ) /*0x104f9c9bc*/
            v36 = nullptr; /*0x104f9c9bc*/
          if ( v10 == v36 ) /*0x104f9c9c3*/
          {
            v37 = std::function<bool ()(RBX::BasePart *,RBX::BasePart *)>::operator()(a1: v64[1], a2: v62, a3: v12); /*0x104f9c9d4*/
            *(_BYTE *)v64[2] &= v37; /*0x104f9c9e1*/
          }
        }
        else
        {
          v38 = *((_QWORD *)v10 + 3); /*0x104f9c9e5*/
          v39 = (RBX::Primitive *)(v38 - 16); /*0x104f9c9ea*/
          if ( v38 == 0 ) /*0x104f9c9f1*/
            v39 = nullptr; /*0x104f9c9f1*/
          if ( v39 == v63 ) /*0x104f9c9fc*/
            continue; /*0x104f9c9fc*/
          v40 = *((_QWORD *)v63 + 3); /*0x104f9ca02*/
          v41 = (RBX::Primitive *)(v40 - 16); /*0x104f9ca06*/
          if ( v40 == 0 ) /*0x104f9ca0d*/
            v41 = nullptr; /*0x104f9ca0d*/
          if ( v10 != v41 ) /*0x104f9ca14*/
            continue; /*0x104f9ca14*/
        }
        if ( RBX::Joint::isJointInstanceOwned(this: i, a2: v34) )
        {
          v43 = *v64; /*0x104f9ca37*/
          v66 = (__int64 (__fastcall **)())(JointOwner - 224); /*0x104f9ca41*/
          v44 = *(_QWORD *)(v43 + 32); /*0x104f9ca45*/
          if ( v44 == 0 ) /*0x104f9ca4c*/
            std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x104f9cc5d*/
        }
        else if ( RBX::Joint::isWeldConstraintOwned(this: i, a2: v42) )
        {
          v46 = *v64; /*0x104f9ca71*/
          v66 = (__int64 (__fastcall **)())(JointOwner - 224); /*0x104f9ca7b*/
          v44 = *(_QWORD *)(v46 + 32); /*0x104f9ca7f*/
          if ( v44 == 0 ) /*0x104f9ca8a*/
            std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x104f9cc64*/
        }
        else if ( FFlag::NoDragDetectorInSpanningTree != 0 || !RBX::Joint::isDragDetectorOwned(this: i, a2: v45) )
        {
          if ( (unsigned __int8)RBX::Joint::isConstraintOwned(this: i, a2: v45) == 0 ) /*0x104f9cb67*/
            continue; /*0x104f9cb67*/
          v52 = *v64; /*0x104f9cb78*/
          v66 = (__int64 (__fastcall **)())(JointOwner - 192); /*0x104f9cb7b*/
          v44 = *(_QWORD *)(v52 + 32); /*0x104f9cb7f*/
          if ( v44 == 0 ) /*0x104f9cb86*/
            std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x104f9cc79*/
        }
        else
        {
          if ( (unsigned __int8)RBX::UnexpectedEvents::UnexpectedEvent::canReport(this: (RBX::UnexpectedEvents::UnexpectedEvent *)&RBX::UnexpectedEvents::drag_detector_in_spanning_tree) != 0 )
          {
            (*(void (__fastcall **)(unsigned __int8 *, __int64))(*(_QWORD *)(JointOwner - 400) + 184LL))( /*0x104f9caee*/
              a1: &v58,
              a2: JointOwner - 400);
            v48 = v58 >> 1; /*0x104f9cafd*/
            v49 = (char *)v61; /*0x104f9cb01*/
            if ( (v58 & 1) != 0 ) /*0x104f9cb08*/
              v48 = v60; /*0x104f9cb08*/
            else
              v49 = &v59; /*0x104f9cb17*/
            v56[0] = v49; /*0x104f9cb1b*/
            v56[1] = v48; /*0x104f9cb22*/
            fmt::v8::vformat(a1: &v66, a2: "Site=WS::MovingNou, instance: {}", 32, 13, v56, v47);
            if ( ((unsigned __int8)v66 & 1) != 0 ) /*0x104f9cb51*/
            {
              v50 = (char *)v68; /*0x104f9cb53*/
              v51 = v67; /*0x104f9cb57*/
            }
            else
            {
              v51 = (unsigned __int8)v66 >> 1; /*0x104f9cb98*/
              v50 = (char *)&v66 + 1; /*0x104f9cb9a*/
            }
            RBX::UnexpectedEvents::UnexpectedEvent::report( /*0x104f9cba5*/
              a1: &RBX::UnexpectedEvents::drag_detector_in_spanning_tree,
              a2: v50,
              a3: v51);
            if ( ((unsigned __int8)v66 & 1) != 0 ) /*0x104f9cbae*/
              operator delete(a1: v68); /*0x104f9cbb4*/
            if ( (v58 & 1) != 0 ) /*0x104f9cbc0*/
              operator delete(a1: v61); /*0x104f9cbc9*/
          }
          v53 = *v64; /*0x104f9cbd2*/
          v66 = (__int64 (__fastcall **)())(JointOwner - 400); /*0x104f9cbdc*/
          v44 = *(_QWORD *)(v53 + 32); /*0x104f9cbe0*/
          if ( v44 == 0 ) /*0x104f9cbeb*/
            std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x104f9cc80*/
        }
        v54 = (*(__int64 (__fastcall **)(__int64, __int64 (__fastcall ***)()))(*(_QWORD *)v44 + 48LL))( /*0x104f9cbf4*/
                a1: v44,
                a2: &v66);
        *(_BYTE *)v64[2] &= v54; /*0x104f9cbff*/
      }
    }
    if ( FFlag::StreamingSkipLocalOnlyNOUs == 1 ) /*0x104f9cc1f*/
      return *(_BYTE *)v64[2]; /*0x104f9cc2b*/
  }
  return v65; /*0x104f9cc41*/
}

// Address: 0x104f9ce76 | Name: __ZZN3RBX9Workspace23visitFixedNOUComponentsEPNS_8BasePartERKNSt3__18functionIFbONS0_17FixedNOUComponentEEEEENK3$_0clEPNS_8InstanceEPNS_9PrimitiveE
__int64 __fastcall RBX::Workspace::visitFixedNOUComponents(RBX::BasePart *,std::function<bool ()(RBX::Workspace::FixedNOUComponent &&)> const&)::$_0::operator()(
        __int64 a1,
        RBX::Primitive *a2,
        RBX::Primitive *a3)
{
  __int64 v4; // rax
  RBX::BasePart *v5; // rdi
  RBX::Joint **v6; // rax
  RBX::Joint *i; // r13
  RBX::Primitive *v8; // rsi
  __int64 JointOwner; // r12
  RBX::Primitive *v10; // r14
  const RBX::Joint *v11; // rsi
  RBX::Primitive *v12; // rsi
  RBX::Attachment *Attachment0; // rax
  RBX::Attachment *v14; // rbx
  __int64 PartAncestor; // rax
  __int64 v16; // rax
  __int64 v17; // rax
  RBX::Attachment *Attachment1; // rax
  RBX::Attachment *v19; // rbx
  __int64 v20; // rax
  __int64 v21; // rax
  __int64 v22; // rax
  RBX::Assembly *Assembly; // rax
  __int64 AssemblyPrimitive; // rax
  const RBX::Joint *v25; // rsi
  __int64 NextJoint; // rax
  __int64 v27; // rax
  RBX::Primitive *v28; // rcx
  RBX::Primitive *v29; // rbx
  __int64 v30; // rax
  RBX::Primitive *v31; // rcx
  const RBX::Joint *v32; // rsi
  const RBX::Joint *v33; // rsi
  __int64 v34; // rax
  __int64 v35; // rax
  char isConstraintOwned; // al
  RBX::Primitive **v37; // rdx
  __int64 (__fastcall **v38)(); // rcx
  char *v39; // rsi
  __int64 v40; // rdx
  __int64 v41; // rdi
  unsigned int v42; // ebx
  char v43; // r14
  unsigned __int8 v45; // [rsp+8h] [rbp-D8h] BYREF
  char v46; // [rsp+9h] [rbp-D7h] BYREF
  __int64 v47; // [rsp+10h] [rbp-D0h]
  void *v48; // [rsp+18h] [rbp-C8h]
  unsigned __int8 v49; // [rsp+20h] [rbp-C0h] BYREF
  char v50; // [rsp+21h] [rbp-BFh] BYREF
  RBX::Primitive **v51; // [rsp+28h] [rbp-B8h]
  void *v52; // [rsp+30h] [rbp-B0h]
  __int64 v53; // [rsp+38h] [rbp-A8h]
  RBX::Primitive *v54; // [rsp+40h] [rbp-A0h]
  RBX::Primitive *v55; // [rsp+48h] [rbp-98h]
  __int64 (__fastcall **v56)(); // [rsp+50h] [rbp-90h] BYREF
  RBX::Primitive **v57; // [rsp+58h] [rbp-88h]
  __int64 v58; // [rsp+60h] [rbp-80h]
  __int64 (__fastcall ***v59)(); // [rsp+70h] [rbp-70h]
  RBX::Primitive *v60; // [rsp+88h] [rbp-58h] BYREF
  __int64 v61; // [rsp+90h] [rbp-50h]
  void *v62[2]; // [rsp+98h] [rbp-48h] BYREF
  char v63; // [rsp+A8h] [rbp-38h] BYREF

  v53 = a1; /*0x104f9ce8d*/
  v61 = 0; /*0x104f9cea6*/
  v62[0] = &v63; /*0x104f9ceae*/
  v62[1] = (void *)&_mh_execute_header; /*0x104f9cebc*/
  v54 = a2; /*0x104f9cec0*/
  v60 = a2; /*0x104f9cec7*/
  v4 = *((_QWORD *)a3 + 3); /*0x104f9cecb*/
  v5 = (RBX::BasePart *)(v4 - 16); /*0x104f9cecf*/
  if ( v4 == 0 ) /*0x104f9ced6*/
    v5 = nullptr; /*0x104f9ced6*/
  v61 = RBX::BasePart::fromPrimitive(this: v5, a2); /*0x104f9cedf*/
  v6 = *((RBX::Joint ***)a3 + 48); /*0x104f9cee3*/
  v55 = a3; /*0x104f9ceea*/
  if ( *((RBX::Joint ***)a3 + 49) != v6 )
  {
    for ( i = *v6; i != nullptr; i = (RBX::Joint *)NextJoint )
    {
      JointOwner = RBX::Joint::getJointOwner(this: i); /*0x104f9cf12*/
      if ( JointOwner == 0 ) /*0x104f9cf18*/
        goto LABEL_29; /*0x104f9cf18*/
      v10 = *((RBX::Primitive **)i + 19); /*0x104f9cf1e*/
      if ( v10 == v55 ) /*0x104f9cf2c*/
        v10 = *((RBX::Primitive **)i + 20); /*0x104f9cf2e*/
      if ( RBX::BasePart::fromPrimitive(this: v10, a2: v8) == 0 ) /*0x104f9cf40*/
      {
LABEL_29:
        NextJoint = RBX::Primitive::getNextJoint(this: v55, a2: i); /*0x104f9d0c7*/
        continue; /*0x104f9d0d1*/
      }
      if ( (unsigned __int8)RBX::Joint::isConstraintOwned(this: i, a2: v11) == 0 ) /*0x104f9cf50*/
        goto LABEL_27; /*0x104f9cf50*/
      Attachment0 = (RBX::Attachment *)RBX::Constraints::ConstraintProp::getAttachment0(this: (RBX::Constraints::ConstraintProp *)(JointOwner - 16)); /*0x104f9cf5e*/
      v14 = Attachment0; /*0x104f9cf63*/
      if ( Attachment0 != nullptr ) /*0x104f9cf69*/
      {
        PartAncestor = RBX::Attachment::findPartAncestor(this: Attachment0); /*0x104f9cf72*/
        if ( (RBX::Primitive *)PartAncestor == v54 ) /*0x104f9cf7e*/
        {
          RBX::SmallVectorTemplateBase<RBX::Instance *,true>::push_back(a1: v62, a2: v14); /*0x104f9cf8b*/
          v16 = RBX::Attachment::findPartAncestor(this: v14); /*0x104f9cf93*/
          v56 = off_10C9F1FB8; /*0x104f9cf9f*/
          v57 = &v60; /*0x104f9cfaa*/
          v59 = &v56; /*0x104f9cfb8*/
          RBX::NetworkUtil::forEachAttachmentBetweenAttachmentAndOwnerPart(a1: v14, a2: v16, a3: &v56, a4: 4); /*0x104f9cfca*/
          if ( v59 == &v56 ) /*0x104f9cfd6*/
          {
            v17 = 4; /*0x104f9d00c*/
LABEL_19:
            (*v59)[v17](); /*0x104f9d011*/
            goto LABEL_20; /*0x104f9d014*/
          }
          v17 = 5; /*0x104f9cfd8*/
          if ( v59 != nullptr ) /*0x104f9cfe0*/
            goto LABEL_19; /*0x104f9cfe0*/
        }
      }
LABEL_20:
      Attachment1 = (RBX::Attachment *)RBX::Constraints::ConstraintProp::getAttachment1(this: (RBX::Constraints::ConstraintProp *)(JointOwner - 16)); /*0x104f9d017*/
      v19 = Attachment1; /*0x104f9d01f*/
      if ( Attachment1 == nullptr ) /*0x104f9d025*/
        goto LABEL_27; /*0x104f9d025*/
      v20 = RBX::Attachment::findPartAncestor(this: Attachment1); /*0x104f9d02a*/
      if ( (RBX::Primitive *)v20 == v54 ) /*0x104f9d036*/
      {
        RBX::SmallVectorTemplateBase<RBX::Instance *,true>::push_back(a1: v62, a2: v19); /*0x104f9d03f*/
        v21 = RBX::Attachment::findPartAncestor(this: v19); /*0x104f9d047*/
        v56 = off_10C9F2038; /*0x104f9d053*/
        v57 = &v60; /*0x104f9d05e*/
        v59 = &v56; /*0x104f9d06c*/
        RBX::NetworkUtil::forEachAttachmentBetweenAttachmentAndOwnerPart(a1: v19, a2: v21, a3: &v56, a4: 4); /*0x104f9d07e*/
        if ( v59 == &v56 ) /*0x104f9d08a*/
        {
          v22 = 4; /*0x104f9d098*/
LABEL_26:
          (*v59)[v22](); /*0x104f9d09d*/
          goto LABEL_27; /*0x104f9d0a0*/
        }
        v22 = 5; /*0x104f9d08c*/
        if ( v59 != nullptr ) /*0x104f9d094*/
          goto LABEL_26; /*0x104f9d094*/
      }
LABEL_27:
      Assembly = (RBX::Assembly *)RBX::Primitive::getAssembly(this: v10, a2: v12); /*0x104f9d0a3*/
      if ( Assembly == nullptr ) /*0x104f9d0ae*/
        goto LABEL_29; /*0x104f9d0ae*/
      AssemblyPrimitive = RBX::Assembly::getAssemblyPrimitive(this: Assembly); /*0x104f9d0b3*/
      if ( AssemblyPrimitive != **(_QWORD **)v53 ) /*0x104f9d0c5*/
        goto LABEL_29; /*0x104f9d0c5*/
      v27 = *((_QWORD *)v10 + 3); /*0x104f9d0de*/
      v28 = (RBX::Primitive *)(v27 - 16); /*0x104f9d0e2*/
      if ( v27 == 0 ) /*0x104f9d0e9*/
        v28 = nullptr; /*0x104f9d0e9*/
      if ( v28 == v55 ) /*0x104f9d0f4*/
        goto LABEL_29; /*0x104f9d0f4*/
      v29 = v55; /*0x104f9d0f6*/
      v30 = *((_QWORD *)v55 + 3); /*0x104f9d0fd*/
      v31 = (RBX::Primitive *)(v30 - 16); /*0x104f9d101*/
      if ( v30 == 0 ) /*0x104f9d108*/
        v31 = nullptr; /*0x104f9d108*/
      if ( v10 == v31 )
      {
        if ( RBX::Joint::isJointInstanceOwned(this: i, a2: v25) || RBX::Joint::isWeldConstraintOwned(this: i, a2: v32) )
        {
          RBX::SmallVectorTemplateBase<RBX::Instance *,true>::push_back(a1: v62, a2: JointOwner - 224); /*0x104f9d12f*/
          v29 = v55; /*0x104f9d134*/
        }
        else if ( FFlag::NoDragDetectorInSpanningTree != 0 || !RBX::Joint::isDragDetectorOwned(this: i, a2: v33) )
        {
          isConstraintOwned = RBX::Joint::isConstraintOwned(this: i, a2: v33); /*0x104f9d1c8*/
          v29 = v55; /*0x104f9d1cf*/
          if ( isConstraintOwned != 0 ) /*0x104f9d1d6*/
            RBX::SmallVectorTemplateBase<RBX::Instance *,true>::push_back(a1: v62, a2: JointOwner - 192); /*0x104f9d1ea*/
        }
        else
        {
          if ( (unsigned __int8)RBX::UnexpectedEvents::UnexpectedEvent::canReport(this: (RBX::UnexpectedEvents::UnexpectedEvent *)&RBX::UnexpectedEvents::drag_detector_in_spanning_tree) != 0 )
          {
            (*(void (__fastcall **)(unsigned __int8 *, __int64))(*(_QWORD *)(JointOwner - 400) + 184LL))( /*0x104f9d1a9*/
              a1: &v49,
              a2: JointOwner - 400);
            v34 = *(_QWORD *)(*(_QWORD *)(JointOwner - 376) + 8LL); /*0x104f9d1b7*/
            if ( (*(_BYTE *)v34 & 1) != 0 ) /*0x104f9d1be*/
              v35 = *(_QWORD *)(v34 + 16); /*0x104f9d1f4*/
            else
              v35 = v34 + 1; /*0x104f9d1c0*/
            v37 = (RBX::Primitive **)(v49 >> 1); /*0x104f9d201*/
            v38 = (__int64 (__fastcall **)())v52; /*0x104f9d206*/
            if ( (v49 & 1) != 0 ) /*0x104f9d214*/
              v37 = v51; /*0x104f9d218*/
            else
              v38 = (__int64 (__fastcall **)())&v50; /*0x104f9d214*/
            v56 = v38; /*0x104f9d220*/
            v57 = v37; /*0x104f9d227*/
            v58 = v35; /*0x104f9d22e*/
            fmt::v8::vformat(a1: &v45, a2: "Site=WS::FixedNou, instance: {}, type: {}", 41, 205, &v56);
            if ( (v45 & 1) != 0 ) /*0x104f9d260*/
            {
              v39 = (char *)v48; /*0x104f9d262*/
              v40 = v47; /*0x104f9d269*/
            }
            else
            {
              v40 = v45 >> 1; /*0x104f9d272*/
              v39 = &v46; /*0x104f9d274*/
            }
            RBX::UnexpectedEvents::UnexpectedEvent::report( /*0x104f9d282*/
              a1: &RBX::UnexpectedEvents::drag_detector_in_spanning_tree,
              a2: v39,
              a3: v40);
            if ( (v45 & 1) != 0 ) /*0x104f9d28e*/
              operator delete(a1: v48); /*0x104f9d297*/
            if ( (v49 & 1) != 0 ) /*0x104f9d2a3*/
              operator delete(a1: v52); /*0x104f9d2ac*/
          }
          RBX::SmallVectorTemplateBase<RBX::Instance *,true>::push_back(a1: v62, a2: JointOwner - 400); /*0x104f9d2b8*/
          v29 = v55; /*0x104f9d2bd*/
        }
      }
      NextJoint = RBX::Primitive::getNextJoint(this: v29, a2: i); /*0x104f9d2ca*/
    }
  }
  v41 = *(_QWORD *)(*(_QWORD *)(v53 + 8) + 32LL); /*0x104f9d2d4*/
  if ( v41 == 0 ) /*0x104f9d2e6*/
    std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x104f9d33d*/
  v42 = (*(__int64 (__fastcall **)(__int64, RBX::Primitive **))(*(_QWORD *)v41 + 48LL))(a1: v41, a2: &v60); /*0x104f9d2f2*/
  v43 = FFlag::StreamingSkipLocalOnlyNOUs; /*0x104f9d2fb*/
  if ( v62[0] != &v63 ) /*0x104f9d309*/
    operator delete(a1: v62[0]); /*0x104f9d30b*/
  LOBYTE(v42) = ((v43 & 1) == 0) | v42 & 1; /*0x104f9d326*/
  return v42; /*0x104f9d32b*/
}

// END Workspace part 1/1, 307 functions
