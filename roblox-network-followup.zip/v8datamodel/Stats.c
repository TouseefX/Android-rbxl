// Stats -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 46 functions


// Address: 0x100a4b5ee | Name: __ZN3RBX5StatsL47rbxImplDynInit_registerStatsItemMembers_DefaultEv
__int64 __fastcall RBX::Stats::rbxImplDynInit_registerStatsItemMembers_Default(RBX::Stats *this)
{
  void *v1; // rsi
  _QWORD v3[5]; // [rsp+8h] [rbp-28h] BYREF

  v3[0] = RBX::Stats::registerStatsItemMembers; /*0x100a4b602*/
  v3[3] = (char *)&RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<void (*)(void)>(void (*)(void))::Callback /*0x100a4b60c*/
        + 2;
  RBX::Reflection::addReflectionInitializer(); /*0x100a4b610*/
  return RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v3, a2: v1); /*0x100a4b61e*/
}

// Address: 0x100a4b866 | Name: __ZN3RBX5StatsL24registerStatsItemMembersEv
__int64 __fastcall RBX::Stats::registerStatsItemMembers(RBX::Stats *this)
{
  __int64 v1; // rbx

  v1 = RBX::Reflection::Class_getDescriptorPtr<RBX::Stats::Item>(a1: this); /*0x100a4b871*/
  RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::PropertyDescriptor>::addDescriptors( /*0x100a4b884*/
    a1: v1 + 40,
    a2: &RBX::Stats::kStatsItemPropertiesDescriptors,
    a3: 1);
  return RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::FunctionDescriptor>::addDescriptors( /*0x100a4b8a3*/
           a1: v1 + 184,
           a2: &RBX::Stats::kStatsItemFunctionDescriptors,
           a3: 2);
}

// Address: 0x100a4c78e | Name: __ZN3RBX5StatsL43rbxImplDynInit_registerStatsMembers_DefaultEv
__int64 __fastcall RBX::Stats::rbxImplDynInit_registerStatsMembers_Default(RBX::Stats *this)
{
  void *v1; // rsi
  _QWORD v3[5]; // [rsp+8h] [rbp-28h] BYREF

  v3[0] = RBX::Stats::registerStatsMembers; /*0x100a4c7a2*/
  v3[3] = (char *)&RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<void (*)(void)>(void (*)(void))::Callback /*0x100a4c7ac*/
        + 2;
  RBX::Reflection::addReflectionInitializer(); /*0x100a4c7b0*/
  return RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v3, a2: v1); /*0x100a4c7be*/
}

// Address: 0x100a4da75 | Name: __ZN3RBX5StatsL20registerStatsMembersEv
__int64 __fastcall RBX::Stats::registerStatsMembers(RBX::Stats *this)
{
  __int64 v1; // rbx

  v1 = RBX::Reflection::Class_getDescriptorPtr<RBX::Stats::StatsService>(a1: this); /*0x100a4da80*/
  RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::PropertyDescriptor>::addDescriptors( /*0x100a4da93*/
    a1: v1 + 40,
    a2: &RBX::Stats::kStatsPropertiesDescriptors,
    a3: 24);
  RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::FunctionDescriptor>::addDescriptors( /*0x100a4daab*/
    a1: v1 + 184,
    a2: &RBX::Stats::kStatsFunctionDescriptors,
    a3: 8);
  return RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::YieldFunctionDescriptor>::addDescriptors( /*0x100a4daca*/
           a1: v1 + 256,
           a2: &RBX::Stats::kStatsYieldDescriptors,
           a3: 1);
}

// Address: 0x102bc487e | Name: __ZN3RBX13TaskScheduler3Job5StatsC2ERS1_NS_4TimeE
__int64 __fastcall RBX::TaskScheduler::Job::Stats::Stats(__int64 a1, __int64 a2, double a3)
{
  __m128d v3; // xmm1
  __int64 result; // rax

  *(_OWORD *)(a1 + 8) = 0; /*0x102bc4885*/
  *(double *)a1 = a3; /*0x102bc4889*/
  v3.f64[0] = *(double *)(a2 + 96); /*0x102bc488d*/
  *(_QWORD *)(a1 + 8) = ~(unsigned __int64)_mm_cmpeq_sd((__m128d)0LL, v3) & COERCE_UNSIGNED_INT64(a3 - v3.f64[0]); /*0x102bc48a3*/
  result = *(_QWORD *)(a2 + 104); /*0x102bc48a8*/
  *(_QWORD *)(a1 + 16) = result; /*0x102bc48ac*/
  return result; /*0x102bc48b0*/
}

// Address: 0x102bc48b2 | Name: __ZN3RBX13TaskScheduler3Job5StatsC1ERS1_NS_4TimeE
__int64 __fastcall RBX::TaskScheduler::Job::Stats::Stats(__int64 a1, __int64 a2, double a3)
{
  __m128d v3; // xmm1
  __int64 result; // rax

  *(_OWORD *)(a1 + 8) = 0; /*0x102bc48b9*/
  *(double *)a1 = a3; /*0x102bc48bd*/
  v3.f64[0] = *(double *)(a2 + 96); /*0x102bc48c1*/
  *(_QWORD *)(a1 + 8) = ~(unsigned __int64)_mm_cmpeq_sd((__m128d)0LL, v3) & COERCE_UNSIGNED_INT64(a3 - v3.f64[0]); /*0x102bc48d7*/
  result = *(_QWORD *)(a2 + 104); /*0x102bc48dc*/
  *(_QWORD *)(a1 + 16) = result; /*0x102bc48e0*/
  return result; /*0x102bc48e4*/
}

// Address: 0x103c00cb0 | Name: __ZN6webrtc27AudioReceiveStreamInterface5StatsC2Ev
__int64 __fastcall webrtc::AudioReceiveStreamInterface::Stats::Stats(webrtc::AudioReceiveStreamInterface::Stats *this)
{
  *(_DWORD *)this = 0; /*0x103c00cb6*/
  *((_QWORD *)this + 9) = 0; /*0x103c00cb8*/
  *((_DWORD *)this + 20) = 0; /*0x103c00cbc*/
  *((_BYTE *)this + 116) = 0; /*0x103c00cbf*/
  *(_OWORD *)((char *)this + 8) = 0; /*0x103c00cc5*/
  *((_DWORD *)this + 6) = 0; /*0x103c00cc9*/
  *((_OWORD *)this + 2) = 0; /*0x103c00ccc*/
  *((_OWORD *)this + 3) = 0; /*0x103c00cd0*/
  *((_DWORD *)this + 16) = 0; /*0x103c00cd4*/
  *(_OWORD *)((char *)this + 88) = 0; /*0x103c00cd7*/
  *(_OWORD *)((char *)this + 97) = 0; /*0x103c00cdb*/
  *(_OWORD *)((char *)this + 120) = 0; /*0x103c00cdf*/
  *((_DWORD *)this + 34) = -1; /*0x103c00ce3*/
  *((_BYTE *)this + 328) = 0; /*0x103c00ced*/
  *((_BYTE *)this + 368) = 0; /*0x103c00cf3*/
  *((_BYTE *)this + 376) = 0; /*0x103c00cf9*/
  *((_BYTE *)this + 384) = 0; /*0x103c00cff*/
  *((_BYTE *)this + 392) = 0; /*0x103c00d05*/
  *((_BYTE *)this + 400) = 0; /*0x103c00d0b*/
  *((_BYTE *)this + 408) = 0; /*0x103c00d11*/
  *((_BYTE *)this + 416) = 0; /*0x103c00d17*/
  *((_BYTE *)this + 456) = 0; /*0x103c00d1d*/
  *((_QWORD *)this + 58) = 0; /*0x103c00d23*/
  *((_DWORD *)this + 118) = 0; /*0x103c00d2a*/
  *((_BYTE *)this + 320) = 0; /*0x103c00d30*/
  *((_OWORD *)this + 19) = 0; /*0x103c00d36*/
  *((_OWORD *)this + 18) = 0; /*0x103c00d3d*/
  *((_OWORD *)this + 17) = 0; /*0x103c00d44*/
  *((_OWORD *)this + 16) = 0; /*0x103c00d4b*/
  *((_OWORD *)this + 15) = 0; /*0x103c00d52*/
  *((_OWORD *)this + 14) = 0; /*0x103c00d59*/
  *((_OWORD *)this + 13) = 0; /*0x103c00d60*/
  *((_OWORD *)this + 12) = 0; /*0x103c00d67*/
  *((_OWORD *)this + 11) = 0; /*0x103c00d6e*/
  *((_OWORD *)this + 10) = 0; /*0x103c00d75*/
  *((_OWORD *)this + 9) = 0; /*0x103c00d7c*/
  *(_OWORD *)((char *)this + 345) = 0; /*0x103c00d83*/
  *((_OWORD *)this + 21) = 0; /*0x103c00d8a*/
  *(_OWORD *)((char *)this + 433) = 0; /*0x103c00d91*/
  *(_OWORD *)((char *)this + 424) = 0; /*0x103c00d98*/
  return 0; /*0x103c00d9f*/
}

// Address: 0x103c00da2 | Name: __ZN6webrtc27AudioReceiveStreamInterface5StatsC1Ev
__int64 __fastcall webrtc::AudioReceiveStreamInterface::Stats::Stats(webrtc::AudioReceiveStreamInterface::Stats *this)
{
  return webrtc::AudioReceiveStreamInterface::Stats::Stats(this); /*0x103c00da6*/
}

// Address: 0x103c00dac | Name: __ZN6webrtc27AudioReceiveStreamInterface5StatsD2Ev
void __fastcall webrtc::AudioReceiveStreamInterface::Stats::~Stats(void **this)
{
  if ( (*(_BYTE *)(this + 11) & 1) != 0 ) /*0x103c00db4*/
    operator delete(a1: *(this + 13)); /*0x103c00dbd*/
}

// Address: 0x103c00dc2 | Name: __ZN6webrtc27AudioReceiveStreamInterface5StatsD1Ev
void __fastcall webrtc::AudioReceiveStreamInterface::Stats::~Stats(void **this)
{
  if ( (*(_BYTE *)(this + 11) & 1) != 0 ) /*0x103c00dca*/
    operator delete(a1: *(this + 13)); /*0x103c00dd3*/
}

// Address: 0x103c00fec | Name: __ZN6webrtc15AudioSendStream5StatsC2Ev
__int64 __fastcall webrtc::AudioSendStream::Stats::Stats(webrtc::AudioSendStream::Stats *this)
{
  __int64 result; // rax

  *(_DWORD *)this = 0; /*0x103c00ff9*/
  *(_OWORD *)((char *)this + 8) = 0; /*0x103c01002*/
  *(_OWORD *)((char *)this + 24) = 0; /*0x103c01006*/
  *(_OWORD *)((char *)this + 40) = 0; /*0x103c0100a*/
  *((_QWORD *)this + 7) = 0xBF800000FFFFFFFFLL; /*0x103c01018*/
  *((_BYTE *)this + 92) = 0; /*0x103c0101c*/
  *((_OWORD *)this + 4) = 0; /*0x103c01020*/
  *(_OWORD *)((char *)this + 73) = 0; /*0x103c01024*/
  *((_DWORD *)this + 24) = -1; /*0x103c01028*/
  *((_QWORD *)this + 13) = -1; /*0x103c0102f*/
  *((_WORD *)this + 56) = 0; /*0x103c01037*/
  *(_OWORD *)((char *)this + 120) = 0; /*0x103c01044*/
  webrtc::ANAStats::ANAStats(this: (webrtc::AudioSendStream::Stats *)((char *)this + 136)); /*0x103c0104b*/
  result = webrtc::AudioProcessingStats::AudioProcessingStats(this: (webrtc::AudioSendStream::Stats *)((char *)this + 192)); /*0x103c01057*/
  *((_OWORD *)this + 20) = 0; /*0x103c0105f*/
  *((_OWORD *)this + 19) = 0; /*0x103c01066*/
  *((_DWORD *)this + 84) = 0; /*0x103c0106d*/
  return result; /*0x103c0107b*/
}

// Address: 0x103c010ac | Name: __ZN6webrtc15AudioSendStream5StatsC1Ev
__int64 __fastcall webrtc::AudioSendStream::Stats::Stats(webrtc::AudioSendStream::Stats *this)
{
  return webrtc::AudioSendStream::Stats::Stats(this); /*0x103c010b0*/
}

// Address: 0x103c010b6 | Name: __ZN6webrtc15AudioSendStream5StatsD2Ev
void __fastcall webrtc::AudioSendStream::Stats::~Stats(webrtc::AudioSendStream::Stats *this)
{
  void *v2; // rdi

  v2 = *((void **)this + 39); /*0x103c010bf*/
  if ( v2 != nullptr ) /*0x103c010c9*/
  {
    *((_QWORD *)this + 40) = v2; /*0x103c010cb*/
    operator delete(a1: v2); /*0x103c010d2*/
  }
  webrtc::AudioProcessingStats::~AudioProcessingStats(this: (webrtc::AudioSendStream::Stats *)((char *)this + 192)); /*0x103c010de*/
  webrtc::ANAStats::~ANAStats(this: (webrtc::AudioSendStream::Stats *)((char *)this + 136)); /*0x103c010ea*/
  if ( (*((_BYTE *)this + 64) & 1) != 0 ) /*0x103c010f3*/
    operator delete(a1: *((void **)this + 10)); /*0x103c01106*/
}

// Address: 0x103c0110c | Name: __ZN6webrtc15AudioSendStream5StatsD1Ev
void __fastcall webrtc::AudioSendStream::Stats::~Stats(webrtc::AudioSendStream::Stats *this)
{
  webrtc::AudioSendStream::Stats::~Stats(this); /*0x103c01111*/
}

// Address: 0x103c06476 | Name: __ZNK6webrtc4Call5Stats8ToStringEx
webrtc::Call::Stats *__fastcall webrtc::Call::Stats::ToString(webrtc::Call::Stats *this, unsigned int *a2, __int64 a3)
{
  __int64 v6; // rax
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  __int64 v14; // rax
  __int64 v15; // rax
  __int64 v16; // rax
  const char *v18[3]; // [rsp+8h] [rbp-448h] BYREF
  _BYTE v19[1032]; // [rsp+20h] [rbp-430h] BYREF

  webrtc::SimpleStringBuilder::SimpleStringBuilder(a1: v18, a2: v19, a3: 1024); /*0x103c064b5*/
  v6 = webrtc::SimpleStringBuilder::operator<<(a1: v18, a2: "Call stats: ", a3: 12);
  v7 = webrtc::SimpleStringBuilder::operator<<(a1: v6, a2: a3); /*0x103c064d4*/
  webrtc::SimpleStringBuilder::operator<<(a1: v7, a2: ", {", a3: 3); /*0x103c064e8*/
  v8 = webrtc::SimpleStringBuilder::operator<<(a1: v18, a2: "send_bw_bps: ", a3: 13);
  v9 = webrtc::SimpleStringBuilder::operator<<(a1: v8, a2: *a2); /*0x103c06507*/
  webrtc::SimpleStringBuilder::operator<<(a1: v9, a2: ", ", a3: 2); /*0x103c0651e*/
  v10 = webrtc::SimpleStringBuilder::operator<<(a1: v18, a2: "recv_bw_bps: ", a3: 13);
  v11 = webrtc::SimpleStringBuilder::operator<<(a1: v10, a2: a2[2]); /*0x103c0653e*/
  webrtc::SimpleStringBuilder::operator<<(a1: v11, a2: ", ", a3: 2); /*0x103c0654e*/
  v12 = webrtc::SimpleStringBuilder::operator<<(a1: v18, a2: "max_pad_bps: ", a3: 13);
  v13 = webrtc::SimpleStringBuilder::operator<<(a1: v12, a2: a2[1]); /*0x103c0656e*/
  webrtc::SimpleStringBuilder::operator<<(a1: v13, a2: ", ", a3: 2); /*0x103c0657e*/
  v14 = webrtc::SimpleStringBuilder::operator<<(a1: v18, a2: "pacer_delay_ms: ", a3: 16);
  v15 = webrtc::SimpleStringBuilder::operator<<(a1: v14, a2: *((_QWORD *)a2 + 2)); /*0x103c0659e*/
  webrtc::SimpleStringBuilder::operator<<(a1: v15, a2: ", ", a3: 2); /*0x103c065ae*/
  v16 = webrtc::SimpleStringBuilder::operator<<(a1: v18, a2: "rtt_ms: ", a3: 8);
  webrtc::SimpleStringBuilder::operator<<(a1: v16, a2: *((_QWORD *)a2 + 3)); /*0x103c065ce*/
  webrtc::SimpleStringBuilder::operator<<(a1: v18, a2: 125); /*0x103c065db*/
  std::string::basic_string[abi:ne200100]<0>(a1: this, a2: v18[0]); /*0x103c065e6*/
  return this; /*0x103c065fe*/
}

// Address: 0x103c22246 | Name: __ZN6webrtc27VideoReceiveStreamInterface5StatsC2Ev
__int64 __fastcall webrtc::VideoReceiveStreamInterface::Stats::Stats(webrtc::VideoReceiveStreamInterface::Stats *this)
{
  *((_BYTE *)this + 40) = 0; /*0x103c2224c*/
  *((_WORD *)this + 24) = 0; /*0x103c2224f*/
  *(_OWORD *)this = 0; /*0x103c22258*/
  *((_BYTE *)this + 16) = 0; /*0x103c2225b*/
  *(_OWORD *)((char *)this + 52) = 0; /*0x103c2225e*/
  *(_OWORD *)((char *)this + 68) = 0; /*0x103c22262*/
  *(_OWORD *)((char *)this + 84) = 0; /*0x103c22266*/
  *(_OWORD *)((char *)this + 100) = 0; /*0x103c2226a*/
  *((_DWORD *)this + 29) = 10; /*0x103c2226e*/
  *((_QWORD *)this + 15) = -1; /*0x103c2227c*/
  *((_OWORD *)this + 8) = 0; /*0x103c22280*/
  *((_OWORD *)this + 9) = 0; /*0x103c22287*/
  *((_DWORD *)this + 40) = 0; /*0x103c2228e*/
  *(_OWORD *)((char *)this + 168) = 0; /*0x103c22294*/
  *((_QWORD *)this + 23) = -1; /*0x103c2229b*/
  *((_BYTE *)this + 192) = 0; /*0x103c222a2*/
  *((_BYTE *)this + 200) = 0; /*0x103c222a8*/
  *((_BYTE *)this + 208) = 0; /*0x103c222ae*/
  *((_BYTE *)this + 216) = 0; /*0x103c222b4*/
  *((_BYTE *)this + 224) = 0; /*0x103c222ba*/
  *((_BYTE *)this + 232) = 0; /*0x103c222c0*/
  *((_QWORD *)this + 30) = 0xFFFFFFFF00000000LL; /*0x103c222d0*/
  *((_BYTE *)this + 280) = 0; /*0x103c222d7*/
  *((_BYTE *)this + 288) = 0; /*0x103c222dd*/
  *(_OWORD *)((char *)this + 261) = 0; /*0x103c222e3*/
  *(_OWORD *)((char *)this + 248) = 0; /*0x103c222ea*/
  *((_DWORD *)this + 74) = 0x7FFFFFFF; /*0x103c222f1*/
  *((_BYTE *)this + 352) = 0; /*0x103c222fb*/
  *((_BYTE *)this + 440) = 0; /*0x103c22301*/
  *((_BYTE *)this + 528) = 0; /*0x103c22307*/
  *((_BYTE *)this + 536) = 0; /*0x103c2230d*/
  *((_BYTE *)this + 648) = 0; /*0x103c22313*/
  *((_BYTE *)this + 656) = 0; /*0x103c22319*/
  *((_BYTE *)this + 664) = 0; /*0x103c2231f*/
  *((_BYTE *)this + 672) = 0; /*0x103c22325*/
  *((_BYTE *)this + 680) = 0; /*0x103c2232b*/
  *((_BYTE *)this + 688) = 0; /*0x103c22331*/
  *((_BYTE *)this + 696) = 0; /*0x103c22337*/
  *((_DWORD *)this + 176) = 0; /*0x103c2233d*/
  *(_OWORD *)((char *)this + 300) = 0; /*0x103c22343*/
  *(_OWORD *)((char *)this + 316) = 0; /*0x103c2234a*/
  *(_OWORD *)((char *)this + 329) = 0; /*0x103c22351*/
  *(_OWORD *)((char *)this + 420) = 0; /*0x103c22358*/
  *(_OWORD *)((char *)this + 408) = 0; /*0x103c2235f*/
  *(_OWORD *)((char *)this + 392) = 0; /*0x103c22366*/
  *(_OWORD *)((char *)this + 376) = 0; /*0x103c2236d*/
  *(_OWORD *)((char *)this + 360) = 0; /*0x103c22374*/
  *(_OWORD *)((char *)this + 712) = 0; /*0x103c2237b*/
  return 0; /*0x103c22382*/
}

// Address: 0x103c22384 | Name: __ZN6webrtc27VideoReceiveStreamInterface5StatsC1Ev
__int64 __fastcall webrtc::VideoReceiveStreamInterface::Stats::Stats(webrtc::VideoReceiveStreamInterface::Stats *this)
{
  return webrtc::VideoReceiveStreamInterface::Stats::Stats(this); /*0x103c22388*/
}

// Address: 0x103c2238e | Name: __ZN6webrtc27VideoReceiveStreamInterface5StatsD2Ev
void __fastcall webrtc::VideoReceiveStreamInterface::Stats::~Stats(void **this)
{
  if ( (*(_BYTE *)(this + 38) & 1) != 0 ) /*0x103c2239e*/
    operator delete(a1: *(this + 40)); /*0x103c223a7*/
  if ( *((_BYTE *)this + 40) == 1 && (*(_BYTE *)(this + 2) & 1) != 0 ) /*0x103c223b6*/
    operator delete(a1: *(this + 4)); /*0x103c223c9*/
}

// Address: 0x103c223ce | Name: __ZN6webrtc27VideoReceiveStreamInterface5StatsD1Ev
void __fastcall webrtc::VideoReceiveStreamInterface::Stats::~Stats(void **this)
{
  webrtc::VideoReceiveStreamInterface::Stats::~Stats(this); /*0x103c223d3*/
}

// Address: 0x103c223d8 | Name: __ZNK6webrtc27VideoReceiveStreamInterface5Stats8ToStringEx
webrtc::VideoReceiveStreamInterface::Stats *__fastcall webrtc::VideoReceiveStreamInterface::Stats::ToString(
        webrtc::VideoReceiveStreamInterface::Stats *this,
        unsigned int *a2,
        __int64 a3)
{
  __int64 v6; // r15
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  __int64 v14; // rax
  __int64 v15; // rax
  __int64 v16; // rax
  __int64 v17; // rax
  __int64 v18; // rax
  __int64 v19; // rax
  __int64 v20; // rax
  __int64 v21; // rax
  __int64 v22; // rax
  __int64 v23; // rax
  __int64 v24; // rax
  __int64 v25; // rdx
  __int64 v26; // rsi
  __int64 v27; // rax
  double v28; // xmm0_8
  __int64 v29; // rax
  __int64 v30; // rdx
  __int64 v31; // rsi
  __int64 v32; // rax
  double v33; // xmm0_8
  __int64 v34; // rax
  __int64 v35; // rdx
  __int64 v36; // rsi
  __int64 v37; // rax
  double v38; // xmm0_8
  __int64 v39; // rax
  __int64 v40; // rax
  __int64 v41; // rdx
  __int64 v42; // rsi
  __int64 v43; // rax
  double v44; // xmm0_8
  __int64 v45; // rax
  __int64 v46; // rdx
  __int64 v47; // rsi
  __int64 v48; // rax
  double v49; // xmm0_8
  __int64 v50; // rax
  __int64 v51; // rdx
  __int64 v52; // rsi
  __int64 v53; // rax
  double v54; // xmm0_8
  __int64 v55; // rax
  __int64 v56; // rax
  __int64 v57; // rax
  __int64 v58; // rax
  __int64 v59; // rax
  __int64 v60; // rax
  __int128 v62; // [rsp+0h] [rbp-30h] BYREF
  void *v63; // [rsp+10h] [rbp-20h]

  v62 = 0; /*0x103c223f6*/
  v63 = nullptr; /*0x103c223fa*/
  std::string::append(a1: &v62, a2: "VideoReceiveStreamInterface stats: ", a3: 35);
  v6 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a3); /*0x103c2241f*/
  std::string::append(a1: v6, a2: ", {ssrc: ", a3: 9);
  v7 = webrtc::StringBuilder::operator<<(a1: v6, a2: a2[75]); /*0x103c22440*/
  std::string::append(a1: v7, a2: ", ", a3: 2); /*0x103c22454*/
  std::string::append(a1: &v62, a2: "total_bps: ", a3: 11);
  v8 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[62]); /*0x103c22479*/
  std::string::append(a1: v8, a2: ", ", a3: 2); /*0x103c2248d*/
  std::string::append(a1: &v62, a2: "frameWidth: ", a3: 12);
  v9 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[63]); /*0x103c224b2*/
  std::string::append(a1: v9, a2: ", ", a3: 2); /*0x103c224c6*/
  std::string::append(a1: &v62, a2: "frameHeight: ", a3: 13);
  v10 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[64]); /*0x103c224eb*/
  std::string::append(a1: v10, a2: ", ", a3: 2); /*0x103c224ff*/
  std::string::append(a1: &v62, a2: "key: ", a3: 5);
  v11 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[13]); /*0x103c22521*/
  std::string::append(a1: v11, a2: ", ", a3: 2); /*0x103c22535*/
  std::string::append(a1: &v62, a2: "delta: ", a3: 7);
  v12 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[14]); /*0x103c22557*/
  std::string::append(a1: v12, a2: ", ", a3: 2); /*0x103c2256b*/
  std::string::append(a1: &v62, a2: "framesAssembledFromMultiplePackets: ", a3: 36);
  v13 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[40]); /*0x103c22590*/
  std::string::append(a1: v13, a2: ", ", a3: 2); /*0x103c225a4*/
  std::string::append(a1: &v62, a2: "framesDecoded: ", a3: 15);
  v14 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[33]); /*0x103c225c9*/
  std::string::append(a1: v14, a2: ", ", a3: 2); /*0x103c225dd*/
  std::string::append(a1: &v62, a2: "framesDropped: ", a3: 15);
  v15 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[32]); /*0x103c22602*/
  std::string::append(a1: v15, a2: ", ", a3: 2); /*0x103c22616*/
  std::string::append(a1: &v62, a2: "network_fps: ", a3: 13);
  v16 = webrtc::StringBuilder::operator<<(a1: &v62, a2: *a2); /*0x103c22637*/
  std::string::append(a1: v16, a2: ", ", a3: 2); /*0x103c2264b*/
  std::string::append(a1: &v62, a2: "decode_fps: ", a3: 12);
  v17 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[1]); /*0x103c2266d*/
  std::string::append(a1: v17, a2: ", ", a3: 2); /*0x103c22681*/
  std::string::append(a1: &v62, a2: "render_fps: ", a3: 12);
  v18 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[2]); /*0x103c226a3*/
  std::string::append(a1: v18, a2: ", ", a3: 2); /*0x103c226b7*/
  std::string::append(a1: &v62, a2: "decode_ms: ", a3: 11);
  v19 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[15]); /*0x103c226d9*/
  std::string::append(a1: v19, a2: ", ", a3: 2); /*0x103c226ed*/
  std::string::append(a1: &v62, a2: "max_decode_ms: ", a3: 15);
  v20 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[16]); /*0x103c2270f*/
  std::string::append(a1: v20, a2: ", ", a3: 2); /*0x103c22723*/
  std::string::append(a1: &v62, a2: "first_frame_received_to_decoded_ms: ", a3: 36);
  v21 = webrtc::StringBuilder::operator<<(a1: &v62, a2: *((_QWORD *)a2 + 23)); /*0x103c22748*/
  std::string::append(a1: v21, a2: ", ", a3: 2); /*0x103c2275c*/
  std::string::append(a1: &v62, a2: "current_delay_ms: ", a3: 18);
  v22 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[17]); /*0x103c2277e*/
  std::string::append(a1: v22, a2: ", ", a3: 2); /*0x103c22792*/
  std::string::append(a1: &v62, a2: "target_delay_ms: ", a3: 17);
  v23 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[18]); /*0x103c227b4*/
  std::string::append(a1: v23, a2: ", ", a3: 2); /*0x103c227c8*/
  std::string::append(a1: &v62, a2: "jitter_delay_ms: ", a3: 17);
  v24 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[19]); /*0x103c227ea*/
  std::string::append(a1: v24, a2: ", ", a3: 2); /*0x103c227fe*/
  std::string::append(a1: &v62, a2: "totalAssemblyTime: ", a3: 19);
  v27 = *((_QWORD *)a2 + 19); /*0x103c22818*/
  if ( __OFSUB__(-v27, 1) ) /*0x103c2282f*/
  {
    v28 = -INFINITY; /*0x103c22840*/
  }
  else if ( v27 == 0x7FFFFFFFFFFFFFFFLL ) /*0x103c22834*/
  {
    v28 = INFINITY; /*0x103c22836*/
  }
  else
  {
    v28 = (double)(int)v27 * 0.000001; /*0x103c2284f*/
  }
  v29 = webrtc::StringBuilder::operator<<(a1: &v62, a2: v26, a3: v25, a4: -*((_QWORD *)a2 + 19), a5: v28); /*0x103c2285b*/
  std::string::append(a1: v29, a2: ", ", a3: 2); /*0x103c2286f*/
  std::string::append(a1: &v62, a2: "jitterBufferDelay: ", a3: 19);
  v32 = *((_QWORD *)a2 + 10); /*0x103c22889*/
  if ( __OFSUB__(-v32, 1) ) /*0x103c22893*/
  {
    v33 = -INFINITY; /*0x103c228a4*/
  }
  else if ( v32 == 0x7FFFFFFFFFFFFFFFLL ) /*0x103c22898*/
  {
    v33 = INFINITY; /*0x103c2289a*/
  }
  else
  {
    v33 = (double)(int)v32 * 0.000001; /*0x103c228b6*/
  }
  v34 = webrtc::StringBuilder::operator<<(a1: &v62, a2: v31, a3: v30, a4: -*((_QWORD *)a2 + 10), a5: v33); /*0x103c228c2*/
  std::string::append(a1: v34, a2: ", ", a3: 2); /*0x103c228d6*/
  std::string::append(a1: &v62, a2: "jitterBufferTargetDelay: ", a3: 25);
  v37 = *((_QWORD *)a2 + 11); /*0x103c228f0*/
  if ( __OFSUB__(-v37, 1) ) /*0x103c228fa*/
  {
    v38 = -INFINITY; /*0x103c2290b*/
  }
  else if ( v37 == 0x7FFFFFFFFFFFFFFFLL ) /*0x103c228ff*/
  {
    v38 = INFINITY; /*0x103c22901*/
  }
  else
  {
    v38 = (double)(int)v37 * 0.000001; /*0x103c2291d*/
  }
  v39 = webrtc::StringBuilder::operator<<(a1: &v62, a2: v36, a3: v35, a4: -*((_QWORD *)a2 + 11), a5: v38); /*0x103c22929*/
  std::string::append(a1: v39, a2: ", ", a3: 2); /*0x103c2293d*/
  std::string::append(a1: &v62, a2: "jitterBufferEmittedCount: ", a3: 26);
  v40 = webrtc::StringBuilder::operator<<(a1: &v62, a2: *((_QWORD *)a2 + 12)); /*0x103c2295f*/
  std::string::append(a1: v40, a2: ", ", a3: 2); /*0x103c22973*/
  std::string::append(a1: &v62, a2: "jitterBufferMinimumDelay: ", a3: 26);
  v43 = *((_QWORD *)a2 + 13); /*0x103c2298d*/
  if ( __OFSUB__(-v43, 1) ) /*0x103c22997*/
  {
    v44 = -INFINITY; /*0x103c229a8*/
  }
  else if ( v43 == 0x7FFFFFFFFFFFFFFFLL ) /*0x103c2299c*/
  {
    v44 = INFINITY; /*0x103c2299e*/
  }
  else
  {
    v44 = (double)(int)v43 * 0.000001; /*0x103c229ba*/
  }
  v45 = webrtc::StringBuilder::operator<<(a1: &v62, a2: v42, a3: v41, a4: -*((_QWORD *)a2 + 13), a5: v44); /*0x103c229c6*/
  std::string::append(a1: v45, a2: ", ", a3: 2); /*0x103c229da*/
  std::string::append(a1: &v62, a2: "totalDecodeTime: ", a3: 17);
  v48 = *((_QWORD *)a2 + 17); /*0x103c229f4*/
  if ( __OFSUB__(-v48, 1) ) /*0x103c22a01*/
  {
    v49 = -INFINITY; /*0x103c22a12*/
  }
  else if ( v48 == 0x7FFFFFFFFFFFFFFFLL ) /*0x103c22a06*/
  {
    v49 = INFINITY; /*0x103c22a08*/
  }
  else
  {
    v49 = (double)(int)v48 * 0.000001; /*0x103c22a24*/
  }
  v50 = webrtc::StringBuilder::operator<<(a1: &v62, a2: v47, a3: v46, a4: -*((_QWORD *)a2 + 17), a5: v49); /*0x103c22a30*/
  std::string::append(a1: v50, a2: ", ", a3: 2); /*0x103c22a44*/
  std::string::append(a1: &v62, a2: "totalProcessingDelay: ", a3: 22);
  v53 = *((_QWORD *)a2 + 18); /*0x103c22a5e*/
  if ( __OFSUB__(-v53, 1) ) /*0x103c22a6b*/
  {
    v54 = -INFINITY; /*0x103c22a7c*/
  }
  else if ( v53 == 0x7FFFFFFFFFFFFFFFLL ) /*0x103c22a70*/
  {
    v54 = INFINITY; /*0x103c22a72*/
  }
  else
  {
    v54 = (double)(int)v53 * 0.000001; /*0x103c22a8e*/
  }
  v55 = webrtc::StringBuilder::operator<<(a1: &v62, a2: v52, a3: v51, a4: -*((_QWORD *)a2 + 18), a5: v54); /*0x103c22a9a*/
  std::string::append(a1: v55, a2: ", ", a3: 2); /*0x103c22aae*/
  std::string::append(a1: &v62, a2: "min_playout_delay_ms: ", a3: 22);
  v56 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[28]); /*0x103c22ad0*/
  std::string::append(a1: v56, a2: ", ", a3: 2); /*0x103c22ae4*/
  std::string::append(a1: &v62, a2: "sync_offset_ms: ", a3: 16);
  v57 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[74]); /*0x103c22b09*/
  std::string::append(a1: v57, a2: ", ", a3: 2); /*0x103c22b1d*/
  std::string::append(a1: &v62, a2: "cum_loss: ", a3: 10);
  v58 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[82]); /*0x103c22b42*/
  std::string::append(a1: v58, a2: ", ", a3: 2); /*0x103c22b56*/
  std::string::append(a1: &v62, a2: "nackCount: ", a3: 11);
  v59 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[104]); /*0x103c22b7b*/
  std::string::append(a1: v59, a2: ", ", a3: 2); /*0x103c22b8f*/
  std::string::append(a1: &v62, a2: "firCount: ", a3: 10);
  v60 = webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[105]); /*0x103c22bb4*/
  std::string::append(a1: v60, a2: ", ", a3: 2); /*0x103c22bc8*/
  std::string::append(a1: &v62, a2: "pliCount: ", a3: 10);
  webrtc::StringBuilder::operator<<(a1: &v62, a2: a2[106]); /*0x103c22bed*/
  std::string::append(a1: &v62, a2: "}", a3: 1); /*0x103c22c02*/
  if ( (v62 & 1) != 0 ) /*0x103c22c0b*/
  {
    std::string::__init_copy_ctor_external(a1: this, a2: v63, a3: *((_QWORD *)&v62 + 1)); /*0x103c22c2b*/
    if ( (v62 & 1) != 0 ) /*0x103c22c34*/
      operator delete(a1: v63); /*0x103c22c3a*/
  }
  else
  {
    *((_QWORD *)this + 2) = v63; /*0x103c22c11*/
    *(_OWORD *)this = v62; /*0x103c22c1a*/
  }
  return this; /*0x103c22c42*/
}

// Address: 0x103c241d2 | Name: __ZN6webrtc15VideoSendStream5StatsC2Ev
__int64 __fastcall webrtc::VideoSendStream::Stats::Stats(webrtc::VideoSendStream::Stats *this)
{
  *(_BYTE *)this = 0; /*0x103c241d8*/
  *((_BYTE *)this + 24) = 0; /*0x103c241da*/
  *((_DWORD *)this + 29) = 0; /*0x103c241dd*/
  *((_OWORD *)this + 8) = 0; /*0x103c241ee*/
  *((_OWORD *)this + 2) = 0; /*0x103c241f5*/
  *((_OWORD *)this + 3) = 0; /*0x103c241f9*/
  *((_OWORD *)this + 4) = 0; /*0x103c241fd*/
  *((_OWORD *)this + 5) = 0; /*0x103c24201*/
  *((_OWORD *)this + 6) = 0; /*0x103c24205*/
  *((_BYTE *)this + 112) = 0; /*0x103c24209*/
  *((_QWORD *)this + 15) = (char *)this + 128; /*0x103c2420c*/
  *(_OWORD *)((char *)this + 168) = 0; /*0x103c24217*/
  *((_QWORD *)this + 18) = 0; /*0x103c2421e*/
  *(_QWORD *)((char *)this + 149) = 0; /*0x103c24225*/
  *((_QWORD *)this + 20) = (char *)this + 168; /*0x103c2422c*/
  *((_BYTE *)this + 184) = 0; /*0x103c24233*/
  *(_QWORD *)((char *)this + 188) = 0; /*0x103c24239*/
  *((_WORD *)this + 98) = 0; /*0x103c24240*/
  return 0; /*0x103c24249*/
}

// Address: 0x103c2424c | Name: __ZN6webrtc15VideoSendStream5StatsC1Ev
__int64 __fastcall webrtc::VideoSendStream::Stats::Stats(webrtc::VideoSendStream::Stats *this)
{
  *(_BYTE *)this = 0; /*0x103c24252*/
  *((_BYTE *)this + 24) = 0; /*0x103c24254*/
  *((_DWORD *)this + 29) = 0; /*0x103c24257*/
  *((_OWORD *)this + 8) = 0; /*0x103c24268*/
  *((_OWORD *)this + 2) = 0; /*0x103c2426f*/
  *((_OWORD *)this + 3) = 0; /*0x103c24273*/
  *((_OWORD *)this + 4) = 0; /*0x103c24277*/
  *((_OWORD *)this + 5) = 0; /*0x103c2427b*/
  *((_OWORD *)this + 6) = 0; /*0x103c2427f*/
  *((_BYTE *)this + 112) = 0; /*0x103c24283*/
  *((_QWORD *)this + 15) = (char *)this + 128; /*0x103c24286*/
  *(_OWORD *)((char *)this + 168) = 0; /*0x103c24291*/
  *((_QWORD *)this + 18) = 0; /*0x103c24298*/
  *(_QWORD *)((char *)this + 149) = 0; /*0x103c2429f*/
  *((_QWORD *)this + 20) = (char *)this + 168; /*0x103c242a6*/
  *((_BYTE *)this + 184) = 0; /*0x103c242ad*/
  *(_QWORD *)((char *)this + 188) = 0; /*0x103c242b3*/
  *((_WORD *)this + 98) = 0; /*0x103c242ba*/
  return 0; /*0x103c242c3*/
}

// Address: 0x103c242c6 | Name: __ZN6webrtc15VideoSendStream5StatsD2Ev
void __fastcall webrtc::VideoSendStream::Stats::~Stats(webrtc::VideoSendStream::Stats *this)
{
  std::__tree<std::__value_type<unsigned int,webrtc::VideoSendStream::StreamStats>,std::__map_value_compare<unsigned int,std::__value_type<unsigned int,webrtc::VideoSendStream::StreamStats>,std::less<unsigned int>,true>,std::allocator<std::__value_type<unsigned int,webrtc::VideoSendStream::StreamStats>>>::destroy( /*0x103c242dd*/
    a1: (char *)this + 160,
    a2: *((_QWORD *)this + 21));
  std::__tree<std::__value_type<webrtc::QualityLimitationReason,long long>,std::__map_value_compare<webrtc::QualityLimitationReason,std::__value_type<webrtc::QualityLimitationReason,long long>,std::less<webrtc::QualityLimitationReason>,true>,std::allocator<std::__value_type<webrtc::QualityLimitationReason,long long>>>::destroy( /*0x103c242ed*/
    a1: (char *)this + 120,
    a2: *((_QWORD *)this + 16));
  if ( *((_BYTE *)this + 24) == 1 && (*(_BYTE *)this & 1) != 0 ) /*0x103c242fb*/
    operator delete(a1: *((void **)this + 2)); /*0x103c2430e*/
}

// Address: 0x103c24314 | Name: __ZN6webrtc15VideoSendStream5StatsD1Ev
void __fastcall webrtc::VideoSendStream::Stats::~Stats(webrtc::VideoSendStream::Stats *this)
{
  webrtc::VideoSendStream::Stats::~Stats(this); /*0x103c24319*/
}

// Address: 0x103c2431e | Name: __ZNK6webrtc15VideoSendStream5Stats8ToStringEx
webrtc::VideoSendStream::Stats *__fastcall webrtc::VideoSendStream::Stats::ToString(
        webrtc::VideoSendStream::Stats *this,
        __int64 a2,
        __int64 a3)
{
  __int64 v6; // rax
  _BYTE *v7; // rsi
  __int64 v8; // rdx
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  const char *v14; // r15
  const char *v15; // rsi
  const char *v16; // rsi
  const char *v17; // rsi
  const char *v18; // rsi
  __int64 v19; // rax
  _QWORD *v20; // r13
  _QWORD *v21; // r14
  __int64 v22; // rax
  _BYTE *v23; // rsi
  __int64 v24; // rdx
  _QWORD *v25; // rcx
  _QWORD *v26; // rax
  bool v27; // zf
  webrtc::VideoSendStream::Stats *v28; // rbx
  unsigned __int8 v30; // [rsp+8h] [rbp-58h] BYREF
  _BYTE v31[7]; // [rsp+9h] [rbp-57h] BYREF
  __int64 v32; // [rsp+10h] [rbp-50h]
  void *v33; // [rsp+18h] [rbp-48h]
  __int128 v34; // [rsp+20h] [rbp-40h] BYREF
  void *v35; // [rsp+30h] [rbp-30h]

  v34 = 0; /*0x103c2433f*/
  v35 = nullptr; /*0x103c24342*/
  std::string::append(a1: &v34, a2: "VideoSendStream stats: ", a3: 23);
  v6 = webrtc::StringBuilder::operator<<(a1: &v34, a2: a3); /*0x103c24362*/
  std::string::append(a1: v6, a2: ", {", a3: 3); /*0x103c24376*/
  std::string::append(a1: &v34, a2: "input_fps: ", a3: 11);
  webrtc::StringFormat(this: (webrtc *)&v30, a2: "%.1f", *(double *)(a2 + 32)); /*0x103c243a3*/
  if ( (v30 & 1) != 0 ) /*0x103c243af*/
  {
    v7 = v33; /*0x103c243b1*/
    v8 = v32; /*0x103c243b5*/
  }
  else
  {
    v8 = v30 >> 1; /*0x103c243bb*/
    v7 = v31; /*0x103c243bd*/
  }
  std::string::append(a1: &v34, a2: v7, a3: v8); /*0x103c243c5*/
  std::string::append(a1: &v34, a2: ", ", a3: 2); /*0x103c243da*/
  if ( (v30 & 1) != 0 ) /*0x103c243e3*/
    operator delete(a1: v33); /*0x103c243e9*/
  std::string::append(a1: &v34, a2: "encode_fps: ", a3: 12);
  v9 = webrtc::StringBuilder::operator<<(a1: &v34, a2: *(unsigned int *)(a2 + 40)); /*0x103c2440b*/
  std::string::append(a1: v9, a2: ", ", a3: 2); /*0x103c2441f*/
  std::string::append(a1: &v34, a2: "encode_ms: ", a3: 11);
  v10 = webrtc::StringBuilder::operator<<(a1: &v34, a2: *(unsigned int *)(a2 + 44)); /*0x103c24441*/
  std::string::append(a1: v10, a2: ", ", a3: 2); /*0x103c24455*/
  std::string::append(a1: &v34, a2: "encode_usage_perc: ", a3: 19);
  v11 = webrtc::StringBuilder::operator<<(a1: &v34, a2: *(unsigned int *)(a2 + 48)); /*0x103c24477*/
  std::string::append(a1: v11, a2: ", ", a3: 2); /*0x103c2448b*/
  std::string::append(a1: &v34, a2: "target_bps: ", a3: 12);
  v12 = webrtc::StringBuilder::operator<<(a1: &v34, a2: *(unsigned int *)(a2 + 100)); /*0x103c244ad*/
  std::string::append(a1: v12, a2: ", ", a3: 2); /*0x103c244c1*/
  std::string::append(a1: &v34, a2: "media_bps: ", a3: 11);
  v13 = webrtc::StringBuilder::operator<<(a1: &v34, a2: *(unsigned int *)(a2 + 104)); /*0x103c244e3*/
  std::string::append(a1: v13, a2: ", ", a3: 2); /*0x103c244f7*/
  std::string::append(a1: &v34, a2: "suspended: ", a3: 11);
  v14 = "false"; /*0x103c2451d*/
  v15 = "false"; /*0x103c24527*/
  if ( *(_BYTE *)(a2 + 108) != 0 ) /*0x103c2452a*/
    v15 = "true"; /*0x103c2452a*/
  std::string::append(a1: &v34, a2: v15, a3: *(unsigned __int8 *)(a2 + 108) ^ 5LL); /*0x103c24536*/
  std::string::append(a1: &v34, a2: ", ", a3: 2); /*0x103c2454b*/
  std::string::append(a1: &v34, a2: "bw_adapted_res: ", a3: 16);
  v16 = "false"; /*0x103c2456d*/
  if ( *(_BYTE *)(a2 + 109) != 0 ) /*0x103c24570*/
    v16 = "true"; /*0x103c24570*/
  std::string::append(a1: &v34, a2: v16, a3: *(unsigned __int8 *)(a2 + 109) ^ 5LL); /*0x103c2457c*/
  std::string::append(a1: &v34, a2: ", ", a3: 2); /*0x103c24591*/
  std::string::append(a1: &v34, a2: "cpu_adapted_res: ", a3: 17);
  v17 = "false"; /*0x103c245b3*/
  if ( *(_BYTE *)(a2 + 110) != 0 ) /*0x103c245b6*/
    v17 = "true"; /*0x103c245b6*/
  std::string::append(a1: &v34, a2: v17, a3: *(unsigned __int8 *)(a2 + 110) ^ 5LL); /*0x103c245c2*/
  std::string::append(a1: &v34, a2: ", ", a3: 2); /*0x103c245d7*/
  std::string::append(a1: &v34, a2: "bw_adapted_fps: ", a3: 16);
  v18 = "false"; /*0x103c245f9*/
  if ( *(_BYTE *)(a2 + 111) != 0 ) /*0x103c245fc*/
    v18 = "true"; /*0x103c245fc*/
  std::string::append(a1: &v34, a2: v18, a3: *(unsigned __int8 *)(a2 + 111) ^ 5LL); /*0x103c24608*/
  std::string::append(a1: &v34, a2: ", ", a3: 2); /*0x103c2461d*/
  std::string::append(a1: &v34, a2: "cpu_adapted_fps: ", a3: 17);
  if ( *(_BYTE *)(a2 + 112) != 0 ) /*0x103c2463f*/
    v14 = "true"; /*0x103c2463f*/
  std::string::append(a1: &v34, a2: v14, a3: *(unsigned __int8 *)(a2 + 112) ^ 5LL); /*0x103c2464e*/
  std::string::append(a1: &v34, a2: ", ", a3: 2); /*0x103c24663*/
  std::string::append(a1: &v34, a2: "#cpu_adaptations: ", a3: 18);
  v19 = webrtc::StringBuilder::operator<<(a1: &v34, a2: *(unsigned int *)(a2 + 148)); /*0x103c24688*/
  std::string::append(a1: v19, a2: ", ", a3: 2); /*0x103c2469c*/
  std::string::append(a1: &v34, a2: "#quality_adaptations: ", a3: 22);
  webrtc::StringBuilder::operator<<(a1: &v34, a2: *(unsigned int *)(a2 + 152)); /*0x103c246c1*/
  std::string::append(a1: &v34, a2: "}", a3: 1); /*0x103c246d6*/
  v20 = *(_QWORD **)(a2 + 160); /*0x103c246df*/
  v21 = (_QWORD *)(a2 + 168); /*0x103c246e6*/
  if ( v20 != v21 )
  {
    do
    {
      if ( *((_DWORD *)v20 + 10) == 0 )
      {
        std::string::append(a1: &v34, a2: " {ssrc: ", a3: 8);
        v22 = webrtc::StringBuilder::operator<<(a1: &v34, a2: *((unsigned int *)v20 + 8)); /*0x103c2472b*/
        std::string::append(a1: v22, a2: ", ", a3: 2); /*0x103c2473f*/
        webrtc::VideoSendStream::StreamStats::ToString(this: (webrtc::VideoSendStream::StreamStats *)&v30); /*0x103c2474b*/
        if ( (v30 & 1) != 0 ) /*0x103c24757*/
        {
          v23 = v33; /*0x103c24759*/
          v24 = v32; /*0x103c2475d*/
        }
        else
        {
          v24 = v30 >> 1; /*0x103c24763*/
          v23 = v31; /*0x103c24765*/
        }
        std::string::append(a1: &v34, a2: v23, a3: v24); /*0x103c2476c*/
        if ( (v30 & 1) != 0 ) /*0x103c24775*/
          operator delete(a1: v33); /*0x103c2477b*/
        std::string::append(a1: &v34, a2: "}", a3: 1); /*0x103c2478b*/
      }
      v25 = (_QWORD *)v20[1]; /*0x103c24790*/
      if ( v25 != nullptr ) /*0x103c24797*/
      {
        do /*0x103c247a2*/
        {
          v26 = v25; /*0x103c24799*/
          v25 = (_QWORD *)*v25; /*0x103c2479c*/
        }
        while ( v25 != nullptr ); /*0x103c247a2*/
      }
      else
      {
        do /*0x103c247b0*/
        {
          v26 = (_QWORD *)v20[2]; /*0x103c247a6*/
          v27 = *v26 == (_QWORD)v20; /*0x103c247aa*/
          v20 = v26; /*0x103c247ad*/
        }
        while ( !v27 ); /*0x103c247b0*/
      }
      v20 = v26; /*0x103c247b2*/
    }
    while ( v26 != v21 );
  }
  if ( (v34 & 1) != 0 ) /*0x103c247c2*/
  {
    v28 = this; /*0x103c247e1*/
    std::string::__init_copy_ctor_external(a1: this, a2: v35, a3: *((_QWORD *)&v34 + 1)); /*0x103c247e8*/
    if ( (v34 & 1) != 0 ) /*0x103c247f1*/
      operator delete(a1: v35); /*0x103c247f7*/
  }
  else
  {
    v28 = this; /*0x103c247c8*/
    *((_QWORD *)this + 2) = v35; /*0x103c247cc*/
    *(_OWORD *)this = v34; /*0x103c247d4*/
  }
  return v28; /*0x103c247ff*/
}

// Address: 0x104c936a0 | Name: __ZN3RBX5Stats9formatMemEj
RBX::Stats *__fastcall RBX::Stats::formatMem(RBX::Stats *this, unsigned int a2)
{
  const char *v3; // rsi

  if ( a2 > 0x3E7 ) /*0x104c936b2*/
  {
    if ( a2 > 0x1869F ) /*0x104c936d9*/
    {
      if ( a2 > 0xF423F ) /*0x104c93702*/
      {
        if ( a2 > 0x5F5E0FF ) /*0x104c93728*/
        {
          if ( a2 > 0x3B9AC9FF ) /*0x104c93755*/
            v3 = "{:.0f}GB"; /*0x104c93782*/
          else
            v3 = "{:.0f}MB"; /*0x104c93768*/
        }
        else
        {
          v3 = "{:.1f}MB"; /*0x104c9373f*/
        }
      }
      else
      {
        v3 = "{:.0f}KB"; /*0x104c93719*/
      }
    }
    else
    {
      v3 = "{:.1f}KB"; /*0x104c936f0*/
    }
    fmt::v8::vformat(a1: this, a2: v3, 8, 10); /*0x104c93796*/
  }
  else
  {
    fmt::v8::vformat(a1: this, a2: "{}", 2, 2); /*0x104c936ce*/
  }
  return this; /*0x104c9379e*/
}

// Address: 0x104c937a5 | Name: __ZN3RBX5Stats11formatMemMbEd
RBX::Stats *__fastcall RBX::Stats::formatMemMb(RBX::Stats *this, double a2)
{
  if ( a2 >= 1000.0 ) /*0x104c937bd*/
  {
    if ( a2 >= 1000000.0 ) /*0x104c937e9*/
      fmt::v8::vformat(a1: this, a2: "{:.0f}GB", 8, 10); /*0x104c93812*/
    else
      fmt::v8::vformat(a1: this, a2: "{:.1f}GB", 8, 10); /*0x104c937f7*/
  }
  else
  {
    fmt::v8::vformat(a1: this, a2: "{:.0f}MB", 8, 10); /*0x104c937cf*/
  }
  return this; /*0x104c9381a*/
}

// Address: 0x104c93821 | Name: __ZN3RBX5Stats19setBrowserTrackerIdERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall RBX::Stats::setBrowserTrackerId(__int64 a1)
{
  std::string::assign(a1: &RBX::Stats::browserTrackerType, a2: "browserTrackerId"); /*0x104c93838*/
  return std::string::operator=(a1: &RBX::Stats::browserTrackerValue, a2: a1); /*0x104c9384b*/
}

// Address: 0x104c93852 | Name: __ZN3RBX5Stats16reportGameStatusERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEb
__int64 __fastcall RBX::Stats::reportGameStatus(unsigned __int8 *a1, char a2)
{
  __int64 v3; // rax
  unsigned int v4; // esi
  void *v5; // rcx
  char *v6; // rdx
  __int64 (__fastcall **v7)(); // rdi
  _BYTE *v8; // r14
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  unsigned __int8 v12; // bl
  _QWORD *v13; // r15
  _OWORD *v14; // rdi
  _BYTE *v15; // rdx
  std::__shared_weak_count *v16; // rbx
  __int64 v17; // rax
  _QWORD v19[2]; // [rsp+10h] [rbp-220h] BYREF
  __int64 (__fastcall **v20)(); // [rsp+20h] [rbp-210h]
  void *v21[2]; // [rsp+28h] [rbp-208h] BYREF
  _BYTE v22[40]; // [rsp+38h] [rbp-1F8h] BYREF
  char v23; // [rsp+60h] [rbp-1D0h]
  void *v24; // [rsp+70h] [rbp-1C0h]
  __int64 (__fastcall **v25)(); // [rsp+88h] [rbp-1A8h] BYREF
  __int128 v26; // [rsp+120h] [rbp-110h] BYREF
  void *v27; // [rsp+130h] [rbp-100h]
  _BYTE v28[8]; // [rsp+138h] [rbp-F8h] BYREF
  __int64 v29; // [rsp+140h] [rbp-F0h]
  void *v30; // [rsp+148h] [rbp-E8h]
  __int128 v31; // [rsp+150h] [rbp-E0h] BYREF
  void *v32; // [rsp+160h] [rbp-D0h]
  __int128 v33; // [rsp+168h] [rbp-C8h] BYREF
  void *v34; // [rsp+178h] [rbp-B8h]
  std::__shared_weak_count *v35[2]; // [rsp+180h] [rbp-B0h] BYREF
  void *v36; // [rsp+190h] [rbp-A0h]
  _BYTE v37[32]; // [rsp+1A0h] [rbp-90h] BYREF
  void *v38; // [rsp+1C0h] [rbp-70h]
  _BYTE v39[56]; // [rsp+1C8h] [rbp-68h] BYREF
  void *v40; // [rsp+200h] [rbp-30h]

  if ( (RBX::Stats::browserTrackerValue & 1) != 0 ) /*0x104c9387e*/
    v3 = *((_QWORD *)&RBX::Stats::browserTrackerValue + 1); /*0x104c93880*/
  else
    v3 = (unsigned __int8)RBX::Stats::browserTrackerValue >> 1; /*0x104c9388b*/
  if ( v3 == 0 ) /*0x104c93890*/
    return __stack_chk_guard; /*0x104c93890*/
  v4 = *a1; /*0x104c93896*/
  v5 = (v4 & 1) != 0 ? *((void **)a1 + 1) : (void *)(v4 >> 1);
  if ( v5 == nullptr ) /*0x104c938ac*/
    return __stack_chk_guard; /*0x104c938ac*/
  if ( (RBX::Stats::browserTrackerValue & 1) != 0 ) /*0x104c938b5*/
    v6 = (char *)qword_10D7D0AD0; /*0x104c938b7*/
  else
    v6 = (char *)&RBX::Stats::browserTrackerValue + 1; /*0x104c938c0*/
  if ( (v4 & 1) != 0 ) /*0x104c938cb*/
    v7 = *((__int64 (__fastcall ***)())a1 + 2); /*0x104c938cd*/
  else
    v7 = (__int64 (__fastcall **)())(a1 + 1); /*0x104c938d3*/
  v19[0] = v6; /*0x104c938dd*/
  v19[1] = v3; /*0x104c938e0*/
  v20 = v7; /*0x104c938e4*/
  v21[0] = v5; /*0x104c938e8*/
  fmt::v8::vformat(a1: &v26, a2: "{{\"browserTrackerId\":{},\"status\":\"{}\"}}", 39, 221); /*0x104c93904*/
  ApiUsersUrlConstruction::constructReportGameStatusUrl(this: (ApiUsersUrlConstruction *)&v33); /*0x104c93910*/
  if ( (v26 & 1) != 0 ) /*0x104c9391c*/
  {
    std::string::__init_copy_ctor_external(a1: &v31, a2: v27, a3: *((_QWORD *)&v26 + 1)); /*0x104c93951*/
  }
  else
  {
    v32 = v27; /*0x104c93925*/
    v31 = v26; /*0x104c93933*/
  }
  v8 = v28; /*0x104c9395d*/
  std::string::basic_string[abi:ne200100]<0>(a1: v28, a2: "application/json"); /*0x104c93967*/
  if ( a2 == 0 ) /*0x104c9396e*/
  {
    RBX::Http::Http(a1: v19, a2: &v33, a3: 0, a4: 0); /*0x104c939eb*/
    if ( (v28[0] & 1) != 0 ) /*0x104c939f9*/
      v11 = v29; /*0x104c939fb*/
    else
      v11 = v28[0] >> 1; /*0x104c93a04*/
    if ( v11 == 0 ) /*0x104c93a09*/
      v8 = &RBX::Http::kContentTypeUrlEncoded; /*0x104c93a0b*/
    v12 = v31 & (*((_QWORD *)&v31 + 1) >= 0x101u); /*0x104c93a20*/
    if ( (v33 & 1) != 0 ) /*0x104c93a2d*/
    {
      std::string::__init_copy_ctor_external(a1: v35, a2: v34, a3: *((_QWORD *)&v33 + 1)); /*0x104c93a62*/
    }
    else
    {
      v36 = v34; /*0x104c93a36*/
      *(_OWORD *)v35 = v33; /*0x104c93a44*/
    }
    v38 = nullptr; /*0x104c93a67*/
    v13 = (_QWORD *)operator new(a1: 0x20u); /*0x104c93a79*/
    *v13 = &off_10C9AD658; /*0x104c93a83*/
    v14 = v13 + 1; /*0x104c93a89*/
    if ( ((__int64)v35[0] & 1) != 0 ) /*0x104c93a94*/
    {
      std::string::__init_copy_ctor_external(a1: v14, a2: v36, a3: v35[1]); /*0x104c93bfa*/
    }
    else
    {
      v13[3] = v36; /*0x104c93aa1*/
      *v14 = *(_OWORD *)v35; /*0x104c93aac*/
    }
    v38 = v13; /*0x104c93c06*/
    RBX::Http::post( /*0x104c93c2c*/
      a1: (unsigned int)v19,
      a2: (unsigned int)&v31,
      a3: (_DWORD)v8,
      a4: v12,
      a5: (unsigned int)v37,
      a6: 0,
      a7: 1);
    if ( v38 == v37 ) /*0x104c93c38*/
    {
      v17 = 32; /*0x104c93c46*/
    }
    else
    {
      v17 = 40; /*0x104c93c3a*/
      if ( v38 == nullptr ) /*0x104c93c42*/
        goto LABEL_52; /*0x104c93c42*/
    }
    (*(void (**)(void))(*(_QWORD *)v38 + v17))(); /*0x104c93c4e*/
LABEL_52:
    if ( ((__int64)v35[0] & 1) != 0 ) /*0x104c93c58*/
      operator delete(a1: v36); /*0x104c93c61*/
    if ( (v23 & 1) != 0 ) /*0x104c93c6d*/
      operator delete(a1: v24); /*0x104c93c76*/
    std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v22); /*0x104c93c85*/
    if ( ((unsigned __int8)v20 & 1) != 0 ) /*0x104c93c8e*/
      operator delete(a1: v21[1]); /*0x104c93c97*/
    goto LABEL_58; /*0x104c93c97*/
  }
  v9 = *((_QWORD *)&RBX::ReadOnlySharedBuffer::empty_buffer_ + 1); /*0x104c93977*/
  *(_OWORD *)v35 = *(_OWORD *)&RBX::ReadOnlySharedBuffer::empty_buffer_; /*0x104c9397e*/
  if ( v9 != 0 ) /*0x104c93988*/
    _InterlockedIncrement64((volatile signed __int64 *)(v9 + 8)); /*0x104c9398a*/
  std::istringstream::basic_istringstream[abi:ne200100](a1: v19, a2: &v31, a3: 8); /*0x104c939a2*/
  RBX::Http::Http(a1: v37, a2: &v33, a3: 0, a4: 0); /*0x104c939b9*/
  if ( (v28[0] & 1) != 0 ) /*0x104c939c7*/
    v10 = v29; /*0x104c939cd*/
  else
    v10 = v28[0] >> 1; /*0x104c93ab4*/
  if ( v10 != 0 ) /*0x104c93ab9*/
    v15 = v28; /*0x104c93ac4*/
  else
    v15 = &RBX::Http::kContentTypeUrlEncoded; /*0x104c93abb*/
  RBX::Http::postSync( /*0x104c93b09*/
    a1: (unsigned int)v37,
    a2: (unsigned int)v19,
    a3: (_DWORD)v15,
    a4: (unsigned __int8)v31 & (*((_QWORD *)&v31 + 1) >= 0x101u),
    a5: (unsigned int)v35,
    a6: 0,
    a7: 0,
    a8: 1);
  if ( (v39[40] & 1) != 0 ) /*0x104c93b12*/
    operator delete(a1: v40); /*0x104c93b18*/
  std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v39); /*0x104c93b24*/
  if ( (v37[16] & 1) != 0 ) /*0x104c93b2d*/
    operator delete(a1: v38); /*0x104c93b33*/
  v19[0] = &off_10C8B6848; /*0x104c93b4a*/
  v25 = off_10C8B6870; /*0x104c93b52*/
  v20 = &off_10C799250; /*0x104c93b60*/
  if ( (v23 & 1) != 0 ) /*0x104c93b68*/
    operator delete(a1: v24); /*0x104c93b71*/
  v20 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x104c93b88*/
  std::locale::~locale(this: (std::locale *)v21); /*0x104c93b8c*/
  std::istream::~istream(a1: v19, a2: off_10C8B6888); /*0x104c93ba3*/
  std::ios::~ios(a1: &v25); /*0x104c93bab*/
  v16 = v35[1]; /*0x104c93bb0*/
  if ( v35[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v35[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104c93bd0*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x104c93bdc*/
    std::__shared_weak_count::__release_weak(this: v16); /*0x104c93be2*/
  }
LABEL_58:
  if ( (v28[0] & 1) != 0 ) /*0x104c93ca3*/
    operator delete(a1: v30); /*0x104c93cac*/
  if ( (v31 & 1) != 0 ) /*0x104c93cb8*/
    operator delete(a1: v32); /*0x104c93cc1*/
  if ( (v33 & 1) != 0 ) /*0x104c93ccd*/
    operator delete(a1: v34); /*0x104c93cd6*/
  if ( (v26 & 1) != 0 ) /*0x104c93ce2*/
    operator delete(a1: v27); /*0x104c93ceb*/
  return __stack_chk_guard; /*0x104c93d00*/
}

// Address: 0x104c954a4 | Name: __ZN3RBX5Stats25GetNetworkStatItemAverageEPKNS0_12StatsServiceENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEE
double __fastcall RBX::Stats::GetNetworkStatItemAverage(__int64 a1, __int64 a2)
{
  __int64 FirstChildByName; // rax
  __int64 v5; // rsi
  char v6; // r14
  _QWORD *v7; // rcx
  __int64 v8; // rdi
  __int64 v9; // rax
  __int64 v10; // rdi
  double *v11; // rbx
  __int64 v12; // r14
  __int64 v13; // rax
  float v14; // xmm0_4
  std::__shared_weak_count *v15; // rbx
  double result; // xmm0_8
  float v17; // xmm0_4
  __int64 v18; // rbx
  __int64 v19; // r14
  __int64 v20; // rdi
  __int64 v21; // rax
  float v22; // xmm1_4
  __int64 v23; // [rsp+8h] [rbp-48h] BYREF
  std::__shared_weak_count *v24; // [rsp+10h] [rbp-40h]
  _BYTE v25[16]; // [rsp+18h] [rbp-38h] BYREF
  void *v26; // [rsp+28h] [rbp-28h]
  float v27; // [rsp+30h] [rbp-20h]
  float v28; // [rsp+34h] [rbp-1Ch]

  if ( a1 == 0 ) /*0x104c954b4*/
    return 0.0; /*0x104c954b4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v25, a2: "Network"); /*0x104c954ce*/
  FirstChildByName = RBX::Instance::findFirstChildByName(a1, a2: v25, a3: 0); /*0x104c954db*/
  v5 = FirstChildByName + 8; /*0x104c954e0*/
  if ( FirstChildByName == 0 ) /*0x104c954e7*/
    v5 = 0; /*0x104c954e7*/
  RBX::shared_from_polymorphic_downcast<RBX::Stats::Item,RBX::Reflection::DescribedBase>(a1: &v23, a2: v5); /*0x104c954ef*/
  if ( (v25[0] & 1) != 0 ) /*0x104c954f8*/
    operator delete(a1: v26); /*0x104c954fe*/
  v6 = 1; /*0x104c95507*/
  if ( v23 != 0 ) /*0x104c9550d*/
  {
    v7 = *(_QWORD **)(v23 + 120); /*0x104c9550f*/
    if ( v7 != nullptr && v7[1] - *v7 >= 0x11u ) /*0x104c95526*/
    {
      v8 = *(_QWORD *)(*v7 + 16LL); /*0x104c95528*/
      if ( v8 != 0 ) /*0x104c9552f*/
      {
        v9 = RBX::Instance::findFirstChildByName(a1: v8, a2, a3: 0); /*0x104c95536*/
        v11 = (double *)v9; /*0x104c9553b*/
        if ( v9 != 0 ) /*0x104c95541*/
        {
          v12 = *(_QWORD *)(v9 + 24); /*0x104c95543*/
          v13 = RBX::Reflection::Class_getDescriptorPtr<RBX::Stats::Item>(a1: v10); /*0x104c95547*/
          if ( *(unsigned __int16 *)(v12 + 440) - (unsigned int)*(unsigned __int16 *)(v13 + 440) <= *(unsigned __int16 *)(v13 + 442) ) /*0x104c95566*/
          {
            (*(void (__fastcall **)(double *))(*(_QWORD *)v11 + 616LL))(a1: v11); /*0x104c955ba*/
            v17 = v11[22]; /*0x104c955c0*/
            v28 = v17; /*0x104c955c8*/
            std::string::basic_string[abi:ne200100]<0>(a1: v25, a2: "Size"); /*0x104c955d8*/
            v18 = RBX::Instance::findFirstChildByName(a1: v11, a2: v25, a3: 0); /*0x104c955eb*/
            v19 = *(_QWORD *)(v18 + 24); /*0x104c955ee*/
            v21 = RBX::Reflection::Class_getDescriptorPtr<RBX::Stats::Item>(a1: v20); /*0x104c955f2*/
            if ( *(unsigned __int16 *)(v19 + 440) - (unsigned int)*(unsigned __int16 *)(v21 + 440) > *(unsigned __int16 *)(v21 + 442) ) /*0x104c95613*/
              v18 = 0; /*0x104c95613*/
            (*(void (__fastcall **)(__int64))(*(_QWORD *)v18 + 616LL))(a1: v18); /*0x104c9561d*/
            v22 = *(double *)(v18 + 176); /*0x104c95623*/
            if ( (v25[0] & 1) != 0 ) /*0x104c9562f*/
            {
              v27 = *(double *)(v18 + 176); /*0x104c95635*/
              operator delete(a1: v26); /*0x104c9563a*/
              v22 = v27; /*0x104c9563f*/
            }
            v14 = (float)(v28 * v22) / 1000.0; /*0x104c9564d*/
          }
          else
          {
            v14 = 0.0; /*0x104c95568*/
          }
          v28 = v14; /*0x104c95655*/
          v6 = 0; /*0x104c9565a*/
        }
      }
    }
  }
  v15 = v24; /*0x104c95570*/
  if ( v24 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v24 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104c95589*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x104c95591*/
    std::__shared_weak_count::__release_weak(this: v15); /*0x104c95597*/
  }
  *(_QWORD *)&result = LODWORD(v28); /*0x104c9559f*/
  if ( v6 != 0 ) /*0x104c955a4*/
    return 0.0; /*0x104c955a6*/
  return result; /*0x104c955a9*/
}

// Address: 0x104c95957 | Name: __ZN3RBX5StatsL27checkMemoryTrackingDisabledEv
char __fastcall RBX::Stats::checkMemoryTrackingDisabled(RBX::Stats *this)
{
  _QWORD *v1; // rbx
  RBX::Time *v2; // rdi
  __int64 v3; // rax
  __int64 (__fastcall *v4)(__int64, _QWORD); // rcx
  double v5; // xmm0_8
  volatile signed __int64 *v6; // rbx
  _BYTE v8[16]; // [rsp+0h] [rbp-60h] BYREF
  void *v9; // [rsp+10h] [rbp-50h]
  _BYTE v10[16]; // [rsp+18h] [rbp-48h] BYREF
  void *v11; // [rsp+28h] [rbp-38h]
  std::__shared_weak_count *v12[2]; // [rsp+30h] [rbp-30h] BYREF
  __int128 v13; // [rsp+40h] [rbp-20h] BYREF

  if ( (GlobalDisableMemoryTrackingRequested & 1) != 0 ) /*0x104c9596d*/
  {
    v1 = (_QWORD *)RBX::Security::Context::current(this); /*0x104c95978*/
    v3 = v1[5]; /*0x104c9597b*/
    v4 = (__int64 (__fastcall *)(__int64, _QWORD))v1[6]; /*0x104c9597f*/
    if ( v4 != nullptr ) /*0x104c95986*/
    {
      v3 = v4(a1: v3, a2: v1[3]); /*0x104c9598f*/
      v1[5] = v3; /*0x104c95991*/
      v1[6] = 0; /*0x104c95995*/
    }
    if ( (v3 & 8) == 0 ) /*0x104c9599f*/
    {
      if ( DFFlag::MemoryDisabledLogWarningThrottle == 1 ) /*0x104c959ac*/
      {
        RBX::Time::nowFastSec(this: v2); /*0x104c959b2*/
        if ( DFInt::MemoryDisabledLogWarningFrequencyMs > (int)((v5 /*0x104c959d5*/
                                                               - *(double *)&RBX::Stats::checkMemoryTrackingDisabled(void)::statsLastReportedTime)
                                                              * 1000.0) )
          return GlobalDisableMemoryTracking & 1; /*0x104c959d5*/
        RBX::Stats::checkMemoryTrackingDisabled(void)::statsLastReportedTime = *(_QWORD *)&v5; /*0x104c959db*/
        *(_OWORD *)v12 = 0; /*0x104c959e7*/
        std::string::basic_string[abi:ne200100]<0>(a1: v8, a2: ""); /*0x104c959f7*/
        RBX::CreatorLog::print( /*0x104c95a18*/
          a1: 2,
          a2: "Memory tracking is currently disabled. Please use Stats.MemoryTrackingEnabled to check before calling this function.",
          a3: 4,
          a4: v12,
          a5: v8);
        if ( (v8[0] & 1) != 0 ) /*0x104c95a21*/
          operator delete(a1: v9); /*0x104c95a27*/
        v6 = (volatile signed __int64 *)v12[1]; /*0x104c95a2c*/
      }
      else
      {
        v13 = 0; /*0x104c95a36*/
        std::string::basic_string[abi:ne200100]<0>(a1: v10, a2: ""); /*0x104c95a46*/
        RBX::CreatorLog::print( /*0x104c95a67*/
          a1: 2,
          a2: "Memory tracking is currently disabled. Please use Stats.MemoryTrackingEnabled to check before calling this function.",
          a3: 4,
          a4: &v13,
          a5: v10);
        if ( (v10[0] & 1) != 0 ) /*0x104c95a70*/
          operator delete(a1: v11); /*0x104c95a76*/
        v6 = *((volatile signed __int64 **)&v13 + 1); /*0x104c95a7b*/
      }
      if ( v6 != nullptr && _InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104c95a94*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(a1: v6); /*0x104c95a9c*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v6); /*0x104c95aa2*/
      }
    }
  }
  return GlobalDisableMemoryTracking & 1; /*0x104c95ab2*/
}

// Address: 0x105b2de84 | Name: __ZN3RBX7details5Stats5resetEv
__int64 __fastcall RBX::details::Stats::reset(RBX::details::Stats *this)
{
  std::chrono::system_clock *v2; // rdi
  __int64 v3; // rsi
  __int64 v4; // rsi

  *(_BYTE *)this = 0; /*0x105b2de91*/
  *((_BYTE *)this + 1) = 0; /*0x105b2de95*/
  *((_BYTE *)this + 2) = 0; /*0x105b2de98*/
  *(_WORD *)((char *)this + 3) = 0; /*0x105b2de9b*/
  *((double *)this + 1) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: this); /*0x105b2dea6*/
  *((_QWORD *)this + 2) = std::chrono::system_clock::now(this: v2); /*0x105b2deb0*/
  *((_QWORD *)this + 3) = std::chrono::system_clock::from_time_t(this: nullptr, a2: v3); /*0x105b2debb*/
  *((_QWORD *)this + 4) = std::chrono::system_clock::from_time_t(this: nullptr, a2: v4); /*0x105b2dec6*/
  return std::vector<std::pair<RBX::details::StatTimer,RBX::details::StatFlags>>::__base_destruct_at_end[abi:ne200100]( /*0x105b2ded9*/
           a1: (char *)this + 40,
           a2: *((_QWORD *)this + 5));
}

// Address: 0x105b2e0e0 | Name: __ZN3RBX7details5StatsD1Ev
void __fastcall RBX::details::Stats::~Stats(void **this)
{
  void *v2; // rdi
  _QWORD v3[3]; // [rsp+8h] [rbp-18h] BYREF

  if ( (*(_BYTE *)(this + 27) & 1) != 0 ) /*0x105b2e0f5*/
    operator delete(a1: *(this + 29)); /*0x105b2e0fe*/
  if ( (*(_BYTE *)(this + 21) & 1) != 0 ) /*0x105b2e10a*/
    operator delete(a1: *(this + 23)); /*0x105b2e113*/
  v2 = *(this + 11); /*0x105b2e118*/
  if ( v2 != nullptr ) /*0x105b2e11f*/
  {
    *(this + 12) = v2; /*0x105b2e121*/
    operator delete(a1: v2); /*0x105b2e125*/
  }
  v3[0] = this + 8; /*0x105b2e132*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: v3); /*0x105b2e138*/
  v3[0] = this + 5; /*0x105b2e141*/
  std::vector<std::pair<RBX::details::StatTimer,RBX::details::StatFlags>>::__destroy_vector::operator()[abi:ne200100](a1: v3); /*0x105b2e148*/
}

// Address: 0x105b2fefa | Name: __ZN3RBX7details5StatsC2Ev
__int64 __fastcall RBX::details::Stats::Stats(RBX::details::Stats *this)
{
  __int64 v2; // rdi
  __int64 v3; // rdi

  *((_BYTE *)this + 4) = 0; /*0x105b2ff07*/
  *(_DWORD *)this = 0; /*0x105b2ff0b*/
  *((double *)this + 1) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: this); /*0x105b2ff16*/
  *((_QWORD *)this + 16) = 0; /*0x105b2ff1b*/
  *((_OWORD *)this + 1) = 0; /*0x105b2ff29*/
  *((_OWORD *)this + 2) = 0; /*0x105b2ff2d*/
  *((_OWORD *)this + 3) = 0; /*0x105b2ff31*/
  *((_OWORD *)this + 4) = 0; /*0x105b2ff35*/
  *((_OWORD *)this + 5) = 0; /*0x105b2ff39*/
  *((_OWORD *)this + 6) = 0; /*0x105b2ff3d*/
  *(_OWORD *)((char *)this + 105) = 0; /*0x105b2ff41*/
  *((_DWORD *)this + 34) = -1; /*0x105b2ff45*/
  *((double *)this + 18) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v2); /*0x105b2ff54*/
  *((_QWORD *)this + 19) = 0; /*0x105b2ff5c*/
  *((_BYTE *)this + 160) = 0; /*0x105b2ff67*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 168, a2: ""); /*0x105b2ff7f*/
  *((double *)this + 24) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v3); /*0x105b2ff89*/
  *((_QWORD *)this + 25) = 0; /*0x105b2ff91*/
  *((_BYTE *)this + 208) = 0; /*0x105b2ff9c*/
  return std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 216, a2: ""); /*0x105b2ffba*/
}

// Address: 0x106718006 | Name: __ZN3RBX7Network15ReplicatorItems5StatsD2Ev
void __fastcall RBX::Network::ReplicatorItems::Stats::~Stats(RBX::Network::ReplicatorItems::Stats *this)
{
  std::__shared_weak_count *v2; // rdi

  *(_QWORD *)this = off_10CAAD340; /*0x10671801b*/
  v2 = *((std::__shared_weak_count **)this + 249); /*0x10671801e*/
  if ( v2 != nullptr ) /*0x106718028*/
    std::__shared_weak_count::__release_weak(this: v2); /*0x10671802a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1968); /*0x106718036*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1952); /*0x106718042*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1936); /*0x10671804e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1920); /*0x10671805a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1904); /*0x106718066*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1888); /*0x106718072*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1872); /*0x10671807e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1856); /*0x10671808a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1840); /*0x106718096*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1824); /*0x1067180a2*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1808); /*0x1067180ae*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1792); /*0x1067180ba*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1776); /*0x1067180cd*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1760); /*0x1067180d9*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1744); /*0x1067180e5*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1728); /*0x1067180f1*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1712); /*0x1067180fd*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1696); /*0x106718109*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1680); /*0x106718115*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1664); /*0x106718121*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1648); /*0x10671812d*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1632); /*0x106718135*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1616); /*0x106718141*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1600); /*0x106718154*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1584); /*0x106718160*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1568); /*0x10671816c*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1552); /*0x106718178*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1536); /*0x106718184*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1520); /*0x106718190*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1504); /*0x10671819c*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1488); /*0x1067181a8*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1472); /*0x1067181b4*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1456); /*0x1067181bc*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1440); /*0x1067181c8*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1424); /*0x1067181db*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1408); /*0x1067181e7*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1392); /*0x1067181f3*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1376); /*0x1067181ff*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1360); /*0x10671820b*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1344); /*0x106718217*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1328); /*0x106718223*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1312); /*0x10671822f*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1296); /*0x10671823b*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1280); /*0x106718247*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1264); /*0x106718253*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1248); /*0x10671825f*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1232); /*0x106718267*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1216); /*0x10671827a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1200); /*0x106718286*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1184); /*0x106718292*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1168); /*0x10671829e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1152); /*0x1067182aa*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1136); /*0x1067182b6*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1120); /*0x1067182c2*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1104); /*0x1067182ce*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1088); /*0x1067182da*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1072); /*0x1067182e6*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1056); /*0x1067182f2*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1040); /*0x1067182fe*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1024); /*0x106718306*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 1008); /*0x106718312*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 992); /*0x10671831e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 976); /*0x10671832a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 960); /*0x106718336*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 944); /*0x106718342*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 928); /*0x10671834e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 912); /*0x10671835a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 896); /*0x106718366*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 880); /*0x106718372*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 864); /*0x10671837e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 848); /*0x10671838a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 832); /*0x106718396*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 816); /*0x1067183a2*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 800); /*0x1067183ae*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 784); /*0x1067183ba*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 768); /*0x1067183c6*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 752); /*0x1067183d2*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 736); /*0x1067183de*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 720); /*0x1067183ea*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 704); /*0x1067183f6*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 688); /*0x106718402*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 672); /*0x10671840e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 656); /*0x10671841a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 640); /*0x106718426*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 624); /*0x106718432*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 608); /*0x10671843e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 592); /*0x10671844a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 576); /*0x106718456*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 560); /*0x106718462*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 544); /*0x10671846e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 528); /*0x10671847a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 512); /*0x106718486*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 496); /*0x106718492*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 480); /*0x10671849e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 464); /*0x1067184aa*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 448); /*0x1067184b6*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 432); /*0x1067184c2*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 416); /*0x1067184ce*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 400); /*0x1067184da*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 384); /*0x1067184e6*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 368); /*0x1067184f2*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 352); /*0x1067184fe*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 336); /*0x10671850a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 320); /*0x106718516*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 304); /*0x106718522*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 288); /*0x10671852e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 272); /*0x10671853a*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 256); /*0x106718546*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 240); /*0x106718552*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 224); /*0x10671855e*/
  std::shared_ptr<RBX::Stats::Item>::~shared_ptr[abi:ne200100](a1: (char *)this + 208); /*0x10671856a*/
  *(_QWORD *)this = off_10C5BE438; /*0x10671857a*/
  if ( (*((_BYTE *)this + 184) & 1) != 0 ) /*0x106718584*/
    operator delete(a1: *((void **)this + 25)); /*0x10671858d*/
  RBX::Stats::StatsItemProp::~StatsItemProp(this); /*0x106718595*/
  RBX::Instance::~Instance(this); /*0x1067185a1*/
}

// Address: 0x106803dc0 | Name: __ZN3RBX7Network15ReplicatorItems5Stats7addStatERKNS0_15ReplicatorStatsEPKcNS3_10PacketTypeE
__int64 __fastcall RBX::Network::ReplicatorItems::Stats::addStat(__int64 a1, __int64 a2, __int64 a3, unsigned int a4)
{
  __int64 v6; // rsi
  __int64 v7; // r13
  __int64 v8; // r14
  __int64 v9; // r13
  std::__shared_weak_count *v10; // r12
  __int64 result; // rax
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13; // rbx
  std::__shared_weak_count *v14; // rbx
  _BYTE v15[8]; // [rsp+0h] [rbp-70h] BYREF
  std::__shared_weak_count *v16; // [rsp+8h] [rbp-68h]
  _BYTE v17[8]; // [rsp+10h] [rbp-60h] BYREF
  std::__shared_weak_count *v18; // [rsp+18h] [rbp-58h]
  __int64 v19; // [rsp+20h] [rbp-50h] BYREF
  std::__shared_weak_count *v20; // [rsp+28h] [rbp-48h]
  __int64 v21; // [rsp+30h] [rbp-40h] BYREF
  std::__shared_weak_count *v22; // [rsp+38h] [rbp-38h]
  __int64 v23; // [rsp+40h] [rbp-30h]

  v6 = *(_QWORD *)(a1 + 400); /*0x106803dd7*/
  v7 = a4; /*0x106803dde*/
  v8 = 3LL * a4; /*0x106803de1*/
  v23 = a3; /*0x106803df1*/
  RBX::Stats::Item::createBoundChildItem<int,(RBX::Time::SampleMethod)1>(a1: &v19, a2: v6, a3, a4: a2 + 24LL * a4); /*0x106803df5*/
  v9 = 5 * v7; /*0x106803dfe*/
  RBX::Stats::Item::createBoundChildItem<int,double>(a1: v15, a2: v19, a3: "Size", a4: a2 + 8 * v9 + 576); /*0x106803e19*/
  v10 = v16; /*0x106803e1e*/
  if ( v16 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v16 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106803e38*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x106803e41*/
    std::__shared_weak_count::__release_weak(this: v10); /*0x106803e47*/
  }
  RBX::Stats::Item::createBoundChildItem<int,(RBX::Time::SampleMethod)1>( /*0x106803e66*/
    a1: &v21,
    a2: *(_QWORD *)(a1 + 464),
    a3: v23,
    a4: a2 + 8 * v8 + 288);
  result = RBX::Stats::Item::createBoundChildItem<int,double>(a1: v17, a2: v21, a3: "Size", a4: a2 + 8 * v9 + 1056); /*0x106803e85*/
  v12 = v18; /*0x106803e8a*/
  if ( v18 != nullptr ) /*0x106803e91*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v18 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x106803e9a*/
    if ( result == 0 ) /*0x106803ea3*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x106803eab*/
      result = std::__shared_weak_count::__release_weak(this: v12); /*0x106803eb1*/
    }
  }
  v13 = v22; /*0x106803eb6*/
  if ( v22 != nullptr ) /*0x106803ebd*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v22 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x106803ec6*/
    if ( result == 0 ) /*0x106803ecf*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x106803ed7*/
      result = std::__shared_weak_count::__release_weak(this: v13); /*0x106803edd*/
    }
  }
  v14 = v20; /*0x106803ee2*/
  if ( v20 != nullptr ) /*0x106803ee9*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v20 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x106803ef2*/
    if ( result == 0 ) /*0x106803efb*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x106803f03*/
      return std::__shared_weak_count::__release_weak(this: v14); /*0x106803f09*/
    }
  }
  return result; /*0x106803f0e*/
}

// Address: 0x106803f42 | Name: __ZN3RBX7Network15ReplicatorItems5StatsC2ERNS_28ForceConstructionInCreatableERKNSt3__110shared_ptrIKNS0_10ReplicatorEEE
__int64 __fastcall RBX::Network::ReplicatorItems::Stats::Stats(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax

  RBX::Described<RBX::Stats::Item,RBX::Instance>::Described<RBX::ForceConstructionInCreatable &>(); /*0x106803f4f*/
  *(_OWORD *)(a1 + 192) = 0; /*0x106803f57*/
  *(_OWORD *)(a1 + 176) = 0; /*0x106803f5e*/
  *(_QWORD *)a1 = off_10CAAD340; /*0x106803f6c*/
  __bzero(a1: a1 + 208, a2: 1776); /*0x106803f7b*/
  result = *(_QWORD *)(a3 + 8); /*0x106803f80*/
  *(_OWORD *)(a1 + 1984) = *(_OWORD *)a3; /*0x106803f88*/
  if ( result != 0 ) /*0x106803f92*/
    _InterlockedIncrement64((volatile signed __int64 *)(result + 16)); /*0x106803f94*/
  *(_OWORD *)(a1 + 2000) = 0; /*0x106803f9c*/
  return result; /*0x106803fa3*/
}

// Address: 0x106803fa8 | Name: __ZN3RBX7Network15ReplicatorItems5StatsC1ERNS_28ForceConstructionInCreatableERKNSt3__110shared_ptrIKNS0_10ReplicatorEEE
__int64 __fastcall RBX::Network::ReplicatorItems::Stats::Stats(__int64 a1, __int64 a2, __int64 a3)
{
  return RBX::Network::ReplicatorItems::Stats::Stats(a1, a2, a3); /*0x106803fac*/
}

// Address: 0x106803fb2 | Name: __ZN3RBX7Network15ReplicatorItems5Stats4initERKNSt3__110shared_ptrIKNS0_10ReplicatorEEE
__int64 __fastcall RBX::Network::ReplicatorItems::Stats::init(char *a1, __int64 *a2)
{
  __int64 v4; // r15
  std::__shared_weak_count *v5; // r12
  std::__shared_weak_count *v6; // r12
  RBX::EngineContext *v7; // rdi
  std::__shared_weak_count *v8; // r12
  std::__shared_weak_count *v9; // r14
  std::__shared_weak_count *v10; // r14
  std::__shared_weak_count *v11; // r12
  std::__shared_weak_count *v12; // r12
  std::__shared_weak_count *v13; // r12
  std::__shared_weak_count *v14; // r12
  std::__shared_weak_count *v15; // r12
  const char **v16; // r12
  std::__shared_weak_count *v17; // r13
  std::__shared_weak_count *v18; // r13
  std::__shared_weak_count *v19; // r13
  std::__shared_weak_count *v20; // r13
  std::__shared_weak_count *v21; // r13
  std::__shared_weak_count *v22; // r13
  std::__shared_weak_count *v23; // r12
  std::__shared_weak_count *v24; // r13
  std::__shared_weak_count *v25; // r13
  std::__shared_weak_count *v26; // r12
  std::__shared_weak_count *v27; // r13
  const char **v28; // r12
  std::__shared_weak_count *v29; // r13
  std::__shared_weak_count *v30; // r13
  std::__shared_weak_count *v31; // r13
  std::__shared_weak_count *v32; // r13
  std::__shared_weak_count *v33; // r12
  char *v34; // r12
  std::__shared_weak_count *v35; // r13
  std::__shared_weak_count *v36; // r13
  std::__shared_weak_count *v37; // r12
  std::__shared_weak_count *v38; // r12
  const char **v39; // r12
  std::__shared_weak_count *v40; // r13
  std::__shared_weak_count *v41; // r14
  std::__shared_weak_count *v42; // r14
  std::__shared_weak_count *v43; // r14
  std::__shared_weak_count *v44; // r14
  std::__shared_weak_count *v45; // r14
  std::__shared_weak_count *v46; // r14
  std::__shared_weak_count *v47; // r14
  std::__shared_weak_count *v48; // r14
  const char **v49; // r12
  std::__shared_weak_count *v50; // r14
  std::__shared_weak_count *v51; // r14
  std::__shared_weak_count *v52; // r14
  std::__shared_weak_count *v53; // r14
  std::__shared_weak_count *v54; // r14
  std::__shared_weak_count *v55; // r14
  std::__shared_weak_count *v56; // r14
  std::__shared_weak_count *v57; // r14
  const char **v58; // r12
  std::__shared_weak_count *v59; // r14
  std::__shared_weak_count *v60; // r14
  std::__shared_weak_count *v61; // r14
  std::__shared_weak_count *v62; // r14
  std::__shared_weak_count *v63; // r14
  std::__shared_weak_count *v64; // r14
  std::__shared_weak_count *v65; // r14
  std::__shared_weak_count *v66; // r14
  std::__shared_weak_count *v67; // r14
  std::__shared_weak_count *v68; // r14
  std::__shared_weak_count *v69; // r14
  const char **v70; // r12
  std::__shared_weak_count *v71; // r14
  std::__shared_weak_count *v72; // r14
  std::__shared_weak_count *v73; // r14
  std::__shared_weak_count *v74; // r14
  std::__shared_weak_count *v75; // r14
  std::__shared_weak_count *v76; // r14
  std::__shared_weak_count *v77; // r14
  std::__shared_weak_count *v78; // r14
  std::__shared_weak_count *v79; // r14
  std::__shared_weak_count *v80; // r14
  std::__shared_weak_count *v81; // r14
  std::__shared_weak_count *v82; // r14
  std::__shared_weak_count *v83; // r14
  std::__shared_weak_count *v84; // r14
  std::__shared_weak_count *v85; // r14
  std::__shared_weak_count *v86; // r14
  std::__shared_weak_count *v87; // r14
  std::__shared_weak_count *v88; // r14
  std::__shared_weak_count *v89; // r14
  std::__shared_weak_count *v90; // r14
  std::__shared_weak_count *v91; // r14
  std::__shared_weak_count *v92; // r14
  std::__shared_weak_count *v93; // r14
  std::__shared_weak_count *v94; // r14
  __int64 result; // rax
  std::__shared_weak_count *v96; // rbx
  std::__shared_weak_count *v97; // rbx
  std::__shared_weak_count *v98; // rbx
  _QWORD v99[2]; // [rsp+8h] [rbp-108h] BYREF
  _QWORD v100[2]; // [rsp+18h] [rbp-F8h] BYREF
  _QWORD v101[2]; // [rsp+28h] [rbp-E8h] BYREF
  _BYTE v102[8]; // [rsp+38h] [rbp-D8h] BYREF
  std::__shared_weak_count *v103; // [rsp+40h] [rbp-D0h]
  _BYTE v104[8]; // [rsp+48h] [rbp-C8h] BYREF
  std::__shared_weak_count *v105; // [rsp+50h] [rbp-C0h]
  _BYTE v106[8]; // [rsp+58h] [rbp-B8h] BYREF
  std::__shared_weak_count *v107; // [rsp+60h] [rbp-B0h]
  _BYTE v108[8]; // [rsp+68h] [rbp-A8h] BYREF
  std::__shared_weak_count *v109; // [rsp+70h] [rbp-A0h]
  _BYTE v110[8]; // [rsp+78h] [rbp-98h] BYREF
  std::__shared_weak_count *v111; // [rsp+80h] [rbp-90h]
  _BYTE v112[8]; // [rsp+88h] [rbp-88h] BYREF
  std::__shared_weak_count *v113; // [rsp+90h] [rbp-80h]
  _BYTE v114[8]; // [rsp+98h] [rbp-78h] BYREF
  std::__shared_weak_count *v115; // [rsp+A0h] [rbp-70h]
  __int64 v116; // [rsp+A8h] [rbp-68h]
  __int64 v117; // [rsp+B0h] [rbp-60h] BYREF
  std::__shared_weak_count *v118; // [rsp+B8h] [rbp-58h]
  char *v119; // [rsp+C0h] [rbp-50h] BYREF
  std::__shared_weak_count *v120; // [rsp+C8h] [rbp-48h]
  __int64 ThreadLocal; // [rsp+D0h] [rbp-40h] BYREF
  volatile signed __int64 *v122; // [rsp+D8h] [rbp-38h]
  void *v123; // [rsp+E0h] [rbp-30h]

  v4 = *a2; /*0x106803fcc*/
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106803fe0*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 256, a2: &ThreadLocal); /*0x106803fef*/
  v5 = (std::__shared_weak_count *)v122; /*0x106803ff4*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680400f*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x106804018*/
    std::__shared_weak_count::__release_weak(this: v5); /*0x10680401e*/
  }
  RBX::Stats::Item::createBoundChildItem<int,double>(a1: v99, a2: a1, a3: "Data Ping", a4: v4 + 4080); /*0x10680403e*/
  v6 = (std::__shared_weak_count *)v99[1]; /*0x106804043*/
  if ( v99[1] != 0 && _InterlockedExchangeAdd64((volatile signed __int64 *)(v99[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680405e*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x106804067*/
    std::__shared_weak_count::__release_weak(this: v6); /*0x10680406d*/
  }
  RBX::Stats::Item::createBoundChildItem<bool>(a1: v100, a2: a1, a3: "StreamingEnabled", a4: *a2 + 15544); /*0x10680408e*/
  v8 = (std::__shared_weak_count *)v100[1]; /*0x106804093*/
  if ( v100[1] != 0 && _InterlockedExchangeAdd64((volatile signed __int64 *)(v100[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068040ae*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x1068040b7*/
    std::__shared_weak_count::__release_weak(this: v8); /*0x1068040bd*/
  }
  if ( DFFlag::AddCompressionToImgui == 1 ) /*0x1068040c9*/
  {
    RBX::Stats::Item::createBoundChildItem<bool>(a1: v101, a2: a1, a3: "Compression", a4: *a2 + 11776); /*0x1068040e7*/
    v9 = (std::__shared_weak_count *)v101[1]; /*0x1068040ec*/
    if ( v101[1] != 0 /*0x106804105*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(v101[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x10680410d*/
      std::__shared_weak_count::__release_weak(this: v9); /*0x106804113*/
    }
  }
  v117 = v4 + 6216; /*0x106804123*/
  ThreadLocal = RBX::EngineContext::getThreadLocal(this: v7); /*0x10680412f*/
  LODWORD(v122) = 13115; /*0x106804132*/
  RBX::Creatable::createImpl<RBX::Network::RakStatsItem,RBX::ForceConstructionInCreatable &,RakNet::RakNetStatistics const*>( /*0x106804143*/
    a1: &v119,
    a2: &ThreadLocal,
    a3: &v117);
  RBX::Instance::setParent(this: (RBX::Instance *)v119, a2: (RBX::Instance *)a1); /*0x10680414f*/
  v10 = v120; /*0x106804154*/
  if ( v120 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v120 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680416d*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x106804175*/
    std::__shared_weak_count::__release_weak(this: v10); /*0x10680417b*/
  }
  RBX::Stats::Item::createBoundChildItem<double>(a1: &v119, a2: a1, a3: "Send kBps", a4: v4 + 3688); /*0x106804195*/
  v116 = v4 + 3696; /*0x1068041af*/
  RBX::Stats::Item::createBoundChildItem<double>(a1: &ThreadLocal, a2: a1, a3: "Send Buffer Health", a4: v4 + 3696); /*0x1068041b3*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 304, a2: &ThreadLocal); /*0x1068041c6*/
  v11 = (std::__shared_weak_count *)v122; /*0x1068041cb*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068041e5*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(a1: v11); /*0x1068041ee*/
    std::__shared_weak_count::__release_weak(this: v11); /*0x1068041f4*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106804207*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 320, a2: &ThreadLocal); /*0x106804216*/
  v12 = (std::__shared_weak_count *)v122; /*0x10680421b*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804235*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x10680423e*/
    std::__shared_weak_count::__release_weak(this: v12); /*0x106804244*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106804257*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 336, a2: &ThreadLocal); /*0x106804266*/
  v13 = (std::__shared_weak_count *)v122; /*0x10680426b*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804285*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x10680428e*/
    std::__shared_weak_count::__release_weak(this: v13); /*0x106804294*/
  }
  RBX::Stats::Item::createBoundChildItem<double>(a1: v102, a2: a1, a3: "Receive kBps", a4: v4 + 2992); /*0x1068042b1*/
  v14 = v103; /*0x1068042b6*/
  if ( v103 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v103 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068042d3*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x1068042dc*/
    std::__shared_weak_count::__release_weak(this: v14); /*0x1068042e2*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x1068042f5*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 208, a2: &ThreadLocal); /*0x106804304*/
  v15 = (std::__shared_weak_count *)v122; /*0x106804309*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804323*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x10680432c*/
    std::__shared_weak_count::__release_weak(this: v15); /*0x106804332*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106804345*/
  v16 = (const char **)(a1 + 384); /*0x10680434a*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 384, a2: &ThreadLocal); /*0x106804357*/
  v17 = (std::__shared_weak_count *)v122; /*0x10680435c*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804375*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x10680437e*/
    std::__shared_weak_count::__release_weak(this: v17); /*0x106804384*/
  }
  RBX::Stats::Item::createBoundChildItem<int,double>(a1: v104, a2: *v16, a3: "Size", a4: v4 + 3808); /*0x1068043a2*/
  v18 = v105; /*0x1068043a7*/
  if ( v105 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v105 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068043c3*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(a1: v18); /*0x1068043cc*/
    std::__shared_weak_count::__release_weak(this: v18); /*0x1068043d2*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v16); /*0x1068043e6*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 416, a2: &ThreadLocal); /*0x1068043f5*/
  v19 = (std::__shared_weak_count *)v122; /*0x1068043fa*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804413*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v19 + 16LL))(a1: v19); /*0x10680441c*/
    std::__shared_weak_count::__release_weak(this: v19); /*0x106804422*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v16); /*0x106804436*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 240, a2: &ThreadLocal); /*0x106804445*/
  v20 = (std::__shared_weak_count *)v122; /*0x10680444a*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804463*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(a1: v20); /*0x10680446c*/
    std::__shared_weak_count::__release_weak(this: v20); /*0x106804472*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v16); /*0x106804486*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 544, a2: &ThreadLocal); /*0x106804495*/
  v21 = (std::__shared_weak_count *)v122; /*0x10680449a*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068044b3*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(a1: v21); /*0x1068044bc*/
    std::__shared_weak_count::__release_weak(this: v21); /*0x1068044c2*/
  }
  RBX::Stats::Item::createBoundChildItem<int,(RBX::Time::SampleMethod)1>( /*0x1068044dd*/
    a1: &ThreadLocal,
    a2: *v16,
    a3: "New Items Per Sec",
    a4: v4 + 3928);
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 560, a2: &ThreadLocal); /*0x1068044ec*/
  v22 = (std::__shared_weak_count *)v122; /*0x1068044f1*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680450a*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v22 + 16LL))(a1: v22); /*0x106804513*/
    std::__shared_weak_count::__release_weak(this: v22); /*0x106804519*/
  }
  RBX::Stats::Item::createBoundChildItem<int,(RBX::Time::SampleMethod)1>( /*0x106804534*/
    a1: &ThreadLocal,
    a2: *v16,
    a3: "Items Sent Per Sec",
    a4: v4 + 3952);
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 576, a2: &ThreadLocal); /*0x106804543*/
  v23 = (std::__shared_weak_count *)v122; /*0x106804548*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804562*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v23 + 16LL))(a1: v23); /*0x10680456b*/
    std::__shared_weak_count::__release_weak(this: v23); /*0x106804571*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106804584*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 864, a2: &ThreadLocal); /*0x106804596*/
  v24 = (std::__shared_weak_count *)v122; /*0x10680459b*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068045b4*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v24 + 16LL))(a1: v24); /*0x1068045bd*/
    std::__shared_weak_count::__release_weak(this: v24); /*0x1068045c3*/
  }
  RBX::Network::ReplicatorStats::PhysicsPacketDetailedStats::CreateStatsItems( /*0x1068045d3*/
    this: (RBX::Network::ReplicatorStats::PhysicsPacketDetailedStats *)(v4 + 4584),
    a2: *((RBX::Stats::Item **)a1 + 108));
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x1068045e6*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 880, a2: &ThreadLocal); /*0x1068045f8*/
  v25 = (std::__shared_weak_count *)v122; /*0x1068045fd*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804616*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v25 + 16LL))(a1: v25); /*0x10680461f*/
    std::__shared_weak_count::__release_weak(this: v25); /*0x106804625*/
  }
  RBX::Network::ReplicatorStats::PhysicsPacketDetailedStats::CreateStatsItems( /*0x106804635*/
    this: (RBX::Network::ReplicatorStats::PhysicsPacketDetailedStats *)(v4 + 5104),
    a2: *((RBX::Stats::Item **)a1 + 110));
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&v117, a2: a1); /*0x106804648*/
  std::string::basic_string[abi:ne200100]<0>(a1: &ThreadLocal, a2: ""); /*0x106804658*/
  RBX::Network::ReplicatorItems::Stats::DataPingComponents::createChildrenItems( /*0x10680466c*/
    a1: a1 + 1024,
    a2: &v117,
    a3: &ThreadLocal);
  if ( (ThreadLocal & 1) != 0 ) /*0x106804675*/
    operator delete(a1: v123); /*0x10680467b*/
  std::string::basic_string[abi:ne200100]<0>(a1: &ThreadLocal, a2: "unrel"); /*0x10680468b*/
  RBX::Network::ReplicatorItems::Stats::DataPingComponents::createChildrenItems( /*0x10680469f*/
    a1: a1 + 1232,
    a2: &v117,
    a3: &ThreadLocal);
  if ( (ThreadLocal & 1) != 0 ) /*0x1068046a8*/
    operator delete(a1: v123); /*0x1068046ae*/
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x1068046c1*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 400, a2: &ThreadLocal); /*0x1068046d0*/
  v26 = (std::__shared_weak_count *)v122; /*0x1068046d5*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068046ef*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v26 + 16LL))(a1: v26); /*0x1068046f8*/
    std::__shared_weak_count::__release_weak(this: v26); /*0x1068046fe*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106804711*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 464, a2: &ThreadLocal); /*0x106804727*/
  v27 = (std::__shared_weak_count *)v122; /*0x10680472c*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804745*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v27 + 16LL))(a1: v27); /*0x10680474e*/
    std::__shared_weak_count::__release_weak(this: v27); /*0x106804754*/
  }
  RBX::Network::ReplicatorItems::Stats::addStat( /*0x10680476b*/
    (__int64)a1,
    a2: v4 + 1456,
    a3: (__int64)RBX::Network::ReplicatorStats::kPacketTypeNames[0],
    a4: 0);
  RBX::Network::ReplicatorItems::Stats::addStat((__int64)a1, a2: v4 + 1456, a3: (__int64)off_10CDD9B08[0], a4: 1u); /*0x10680477f*/
  RBX::Network::ReplicatorItems::Stats::addStat((__int64)a1, a2: v4 + 1456, a3: (__int64)off_10CDD9B10[0], a4: 2u); /*0x106804793*/
  RBX::Network::ReplicatorItems::Stats::addStat((__int64)a1, a2: v4 + 1456, a3: (__int64)off_10CDD9B18[0], a4: 3u); /*0x1068047a7*/
  RBX::Network::ReplicatorItems::Stats::addStat((__int64)a1, a2: v4 + 1456, a3: (__int64)off_10CDD9B20[0], a4: 4u); /*0x1068047bb*/
  RBX::Network::ReplicatorItems::Stats::addStat((__int64)a1, a2: v4 + 1456, a3: (__int64)off_10CDD9B28[0], a4: 5u); /*0x1068047cf*/
  RBX::Network::ReplicatorItems::Stats::addStat((__int64)a1, a2: v4 + 1456, a3: (__int64)off_10CDD9B30[0], a4: 6u); /*0x1068047e3*/
  RBX::Network::ReplicatorItems::Stats::addStat((__int64)a1, a2: v4 + 1456, a3: (__int64)off_10CDD9B38[0], a4: 7u); /*0x1068047f7*/
  RBX::Network::ReplicatorItems::Stats::addStat((__int64)a1, a2: v4 + 1456, a3: (__int64)off_10CDD9B40[0], a4: 8u); /*0x10680480b*/
  RBX::Network::ReplicatorItems::Stats::addStat((__int64)a1, a2: v4 + 1456, a3: (__int64)off_10CDD9B48[0], a4: 9u); /*0x10680481f*/
  RBX::Network::ReplicatorItems::Stats::addStat((__int64)a1, a2: v4 + 1456, a3: (__int64)off_10CDD9B50[0], a4: 0xAu); /*0x106804833*/
  RBX::Network::ReplicatorItems::Stats::addStat((__int64)a1, a2: v4 + 1456, a3: (__int64)off_10CDD9B58, a4: 0xBu); /*0x106804847*/
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x10680485a*/
  v28 = (const char **)(a1 + 688); /*0x10680485f*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 688, a2: &ThreadLocal); /*0x106804870*/
  v29 = (std::__shared_weak_count *)v122; /*0x106804875*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680488e*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v29 + 16LL))(a1: v29); /*0x106804897*/
    std::__shared_weak_count::__release_weak(this: v29); /*0x10680489d*/
  }
  RBX::Stats::Item::createBoundChildItem<int,double>(a1: v106, a2: *v28, a3: "Size", a4: v4 + 4360); /*0x1068048bb*/
  v30 = v107; /*0x1068048c0*/
  if ( v107 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v107 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068048dc*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v30 + 16LL))(a1: v30); /*0x1068048e5*/
    std::__shared_weak_count::__release_weak(this: v30); /*0x1068048eb*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v28); /*0x1068048ff*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 704, a2: &ThreadLocal); /*0x10680490e*/
  v31 = (std::__shared_weak_count *)v122; /*0x106804913*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680492c*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v31 + 16LL))(a1: v31); /*0x106804935*/
    std::__shared_weak_count::__release_weak(this: v31); /*0x10680493b*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v28); /*0x10680494f*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 720, a2: &ThreadLocal); /*0x10680495e*/
  v32 = (std::__shared_weak_count *)v122; /*0x106804963*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680497c*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v32 + 16LL))(a1: v32); /*0x106804985*/
    std::__shared_weak_count::__release_weak(this: v32); /*0x10680498b*/
  }
  RBX::Stats::Item::createBoundChildItem<int,double>(a1: &ThreadLocal, a2: *v28, a3: "Items Per Packet", a4: v4 + 4400); /*0x1068049a6*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 736, a2: &ThreadLocal); /*0x1068049b5*/
  v33 = (std::__shared_weak_count *)v122; /*0x1068049ba*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068049d4*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v33 + 16LL))(a1: v33); /*0x1068049dd*/
    std::__shared_weak_count::__release_weak(this: v33); /*0x1068049e3*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x1068049f6*/
  v34 = a1 + 640; /*0x1068049fb*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 640, a2: &ThreadLocal); /*0x106804a08*/
  v35 = (std::__shared_weak_count *)v122; /*0x106804a0d*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804a26*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v35 + 16LL))(a1: v35); /*0x106804a2f*/
    std::__shared_weak_count::__release_weak(this: v35); /*0x106804a35*/
  }
  RBX::Stats::Item::createBoundChildItem<int,double>(a1: v108, a2: *(_QWORD *)v34, a3: "Size", a4: v4 + 4504); /*0x106804a53*/
  v36 = v109; /*0x106804a58*/
  if ( v109 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v109 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804a74*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v36 + 16LL))(a1: v36); /*0x106804a7d*/
    std::__shared_weak_count::__release_weak(this: v36); /*0x106804a83*/
  }
  RBX::Stats::Item::createBoundChildItem<int,double>(a1: v110, a2: *(_QWORD *)v34, a3: "WaitingTouches", a4: v4 + 4544); /*0x106804aa1*/
  v37 = v111; /*0x106804aa6*/
  if ( v111 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v111 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804ac3*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v37 + 16LL))(a1: v37); /*0x106804acc*/
    std::__shared_weak_count::__release_weak(this: v37); /*0x106804ad2*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106804ae5*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 848, a2: &ThreadLocal); /*0x106804af4*/
  v38 = (std::__shared_weak_count *)v122; /*0x106804af9*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804b13*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v38 + 16LL))(a1: v38); /*0x106804b1c*/
    std::__shared_weak_count::__release_weak(this: v38); /*0x106804b22*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106804b35*/
  v39 = (const char **)(a1 + 432); /*0x106804b3a*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 432, a2: &ThreadLocal); /*0x106804b47*/
  v40 = (std::__shared_weak_count *)v122; /*0x106804b4c*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804b65*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v40 + 16LL))(a1: v40); /*0x106804b6e*/
    std::__shared_weak_count::__release_weak(this: v40); /*0x106804b74*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106804b87*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 480, a2: &ThreadLocal); /*0x106804b99*/
  v41 = (std::__shared_weak_count *)v122; /*0x106804b9e*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804bb7*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v41 + 16LL))(a1: v41); /*0x106804bbf*/
    std::__shared_weak_count::__release_weak(this: v41); /*0x106804bc5*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 60)); /*0x106804bd9*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 496, a2: &ThreadLocal); /*0x106804bec*/
  v42 = (std::__shared_weak_count *)v122; /*0x106804bf1*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804c0a*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v42 + 16LL))(a1: v42); /*0x106804c12*/
    std::__shared_weak_count::__release_weak(this: v42); /*0x106804c18*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106804c2b*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 512, a2: &ThreadLocal); /*0x106804c41*/
  v43 = (std::__shared_weak_count *)v122; /*0x106804c46*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804c5f*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v43 + 16LL))(a1: v43); /*0x106804c67*/
    std::__shared_weak_count::__release_weak(this: v43); /*0x106804c6d*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 64)); /*0x106804c81*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 528, a2: &ThreadLocal); /*0x106804c94*/
  v44 = (std::__shared_weak_count *)v122; /*0x106804c99*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804cb2*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v44 + 16LL))(a1: v44); /*0x106804cba*/
    std::__shared_weak_count::__release_weak(this: v44); /*0x106804cc0*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v39); /*0x106804cd4*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 368, a2: &ThreadLocal); /*0x106804ce7*/
  v45 = (std::__shared_weak_count *)v122; /*0x106804cec*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804d05*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v45 + 16LL))(a1: v45); /*0x106804d0d*/
    std::__shared_weak_count::__release_weak(this: v45); /*0x106804d13*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v39); /*0x106804d27*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 352, a2: &ThreadLocal); /*0x106804d3a*/
  v46 = (std::__shared_weak_count *)v122; /*0x106804d3f*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804d58*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v46 + 16LL))(a1: v46); /*0x106804d60*/
    std::__shared_weak_count::__release_weak(this: v46); /*0x106804d66*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v39); /*0x106804d7a*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 224, a2: &ThreadLocal); /*0x106804d8d*/
  v47 = (std::__shared_weak_count *)v122; /*0x106804d92*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804dab*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v47 + 16LL))(a1: v47); /*0x106804db3*/
    std::__shared_weak_count::__release_weak(this: v47); /*0x106804db9*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v39); /*0x106804dcd*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 448, a2: &ThreadLocal); /*0x106804de0*/
  v48 = (std::__shared_weak_count *)v122; /*0x106804de5*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804dfe*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v48 + 16LL))(a1: v48); /*0x106804e06*/
    std::__shared_weak_count::__release_weak(this: v48); /*0x106804e0c*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106804e1f*/
  v49 = (const char **)(a1 + 752); /*0x106804e24*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 752, a2: &ThreadLocal); /*0x106804e35*/
  v50 = (std::__shared_weak_count *)v122; /*0x106804e3a*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804e53*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v50 + 16LL))(a1: v50); /*0x106804e5b*/
    std::__shared_weak_count::__release_weak(this: v50); /*0x106804e61*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v49); /*0x106804e75*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 816, a2: &ThreadLocal); /*0x106804e88*/
  v51 = (std::__shared_weak_count *)v122; /*0x106804e8d*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804ea6*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v51 + 16LL))(a1: v51); /*0x106804eae*/
    std::__shared_weak_count::__release_weak(this: v51); /*0x106804eb4*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v49); /*0x106804ec8*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 800, a2: &ThreadLocal); /*0x106804edb*/
  v52 = (std::__shared_weak_count *)v122; /*0x106804ee0*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804ef9*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v52 + 16LL))(a1: v52); /*0x106804f01*/
    std::__shared_weak_count::__release_weak(this: v52); /*0x106804f07*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v49); /*0x106804f1b*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 784, a2: &ThreadLocal); /*0x106804f2e*/
  v53 = (std::__shared_weak_count *)v122; /*0x106804f33*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804f4c*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v53 + 16LL))(a1: v53); /*0x106804f54*/
    std::__shared_weak_count::__release_weak(this: v53); /*0x106804f5a*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v49); /*0x106804f6e*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 832, a2: &ThreadLocal); /*0x106804f81*/
  v54 = (std::__shared_weak_count *)v122; /*0x106804f86*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804f9f*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v54 + 16LL))(a1: v54); /*0x106804fa7*/
    std::__shared_weak_count::__release_weak(this: v54); /*0x106804fad*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v49); /*0x106804fc1*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 768, a2: &ThreadLocal); /*0x106804fd4*/
  v55 = (std::__shared_weak_count *)v122; /*0x106804fd9*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106804ff2*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v55 + 16LL))(a1: v55); /*0x106804ffa*/
    std::__shared_weak_count::__release_weak(this: v55); /*0x106805000*/
  }
  if ( FFlag::OutIsrMetricsInNetworkStats == 1 ) /*0x10680500f*/
  {
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106805023*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 896, a2: &ThreadLocal); /*0x106805039*/
    v56 = (std::__shared_weak_count *)v122; /*0x10680503e*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805057*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v56 + 16LL))(a1: v56); /*0x10680505f*/
      std::__shared_weak_count::__release_weak(this: v56); /*0x106805065*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 112)); /*0x106805079*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 912, a2: &ThreadLocal); /*0x10680508c*/
    v57 = (std::__shared_weak_count *)v122; /*0x106805091*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068050aa*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v57 + 16LL))(a1: v57); /*0x1068050b2*/
      std::__shared_weak_count::__release_weak(this: v57); /*0x1068050b8*/
    }
  }
  if ( FFlag::CollectISRPhysicsBandwidthUsage == 1 ) /*0x1068050c7*/
  {
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x1068050db*/
    v58 = (const char **)(a1 + 1440); /*0x1068050e0*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1440, a2: &ThreadLocal); /*0x1068050f1*/
    v59 = (std::__shared_weak_count *)v122; /*0x1068050f6*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680510f*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v59 + 16LL))(a1: v59); /*0x106805117*/
      std::__shared_weak_count::__release_weak(this: v59); /*0x10680511d*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v58); /*0x106805131*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1456, a2: &ThreadLocal); /*0x106805147*/
    v60 = (std::__shared_weak_count *)v122; /*0x10680514c*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805165*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v60 + 16LL))(a1: v60); /*0x10680516d*/
      std::__shared_weak_count::__release_weak(this: v60); /*0x106805173*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 182)); /*0x106805187*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1472, a2: &ThreadLocal); /*0x10680519a*/
    v61 = (std::__shared_weak_count *)v122; /*0x10680519f*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068051b8*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v61 + 16LL))(a1: v61); /*0x1068051c0*/
      std::__shared_weak_count::__release_weak(this: v61); /*0x1068051c6*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v58); /*0x1068051da*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1488, a2: &ThreadLocal); /*0x1068051f0*/
    v62 = (std::__shared_weak_count *)v122; /*0x1068051f5*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680520e*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v62 + 16LL))(a1: v62); /*0x106805216*/
      std::__shared_weak_count::__release_weak(this: v62); /*0x10680521c*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 186)); /*0x106805230*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1504, a2: &ThreadLocal); /*0x106805243*/
    v63 = (std::__shared_weak_count *)v122; /*0x106805248*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805261*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v63 + 16LL))(a1: v63); /*0x106805269*/
      std::__shared_weak_count::__release_weak(this: v63); /*0x10680526f*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v58); /*0x106805283*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1520, a2: &ThreadLocal); /*0x106805299*/
    v64 = (std::__shared_weak_count *)v122; /*0x10680529e*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068052b7*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v64 + 16LL))(a1: v64); /*0x1068052bf*/
      std::__shared_weak_count::__release_weak(this: v64); /*0x1068052c5*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 190)); /*0x1068052d9*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1536, a2: &ThreadLocal); /*0x1068052ec*/
    v65 = (std::__shared_weak_count *)v122; /*0x1068052f1*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680530a*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v65 + 16LL))(a1: v65); /*0x106805312*/
      std::__shared_weak_count::__release_weak(this: v65); /*0x106805318*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v58); /*0x10680532c*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1552, a2: &ThreadLocal); /*0x106805342*/
    v66 = (std::__shared_weak_count *)v122; /*0x106805347*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805360*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v66 + 16LL))(a1: v66); /*0x106805368*/
      std::__shared_weak_count::__release_weak(this: v66); /*0x10680536e*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 194)); /*0x106805382*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1568, a2: &ThreadLocal); /*0x106805395*/
    v67 = (std::__shared_weak_count *)v122; /*0x10680539a*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068053b3*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v67 + 16LL))(a1: v67); /*0x1068053bb*/
      std::__shared_weak_count::__release_weak(this: v67); /*0x1068053c1*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v58); /*0x1068053d5*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1584, a2: &ThreadLocal); /*0x1068053eb*/
    v68 = (std::__shared_weak_count *)v122; /*0x1068053f0*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805409*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v68 + 16LL))(a1: v68); /*0x106805411*/
      std::__shared_weak_count::__release_weak(this: v68); /*0x106805417*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 198)); /*0x10680542b*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1600, a2: &ThreadLocal); /*0x10680543e*/
    v69 = (std::__shared_weak_count *)v122; /*0x106805443*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680545c*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v69 + 16LL))(a1: v69); /*0x106805464*/
      std::__shared_weak_count::__release_weak(this: v69); /*0x10680546a*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x10680547d*/
    v70 = (const char **)(a1 + 1616); /*0x106805482*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1616, a2: &ThreadLocal); /*0x106805493*/
    v71 = (std::__shared_weak_count *)v122; /*0x106805498*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068054b1*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v71 + 16LL))(a1: v71); /*0x1068054b9*/
      std::__shared_weak_count::__release_weak(this: v71); /*0x1068054bf*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v70); /*0x1068054d3*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1632, a2: &ThreadLocal); /*0x1068054e9*/
    v72 = (std::__shared_weak_count *)v122; /*0x1068054ee*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805507*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v72 + 16LL))(a1: v72); /*0x10680550f*/
      std::__shared_weak_count::__release_weak(this: v72); /*0x106805515*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 204)); /*0x106805529*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1648, a2: &ThreadLocal); /*0x10680553c*/
    v73 = (std::__shared_weak_count *)v122; /*0x106805541*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680555a*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v73 + 16LL))(a1: v73); /*0x106805562*/
      std::__shared_weak_count::__release_weak(this: v73); /*0x106805568*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v70); /*0x10680557c*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1664, a2: &ThreadLocal); /*0x106805592*/
    v74 = (std::__shared_weak_count *)v122; /*0x106805597*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068055b0*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v74 + 16LL))(a1: v74); /*0x1068055b8*/
      std::__shared_weak_count::__release_weak(this: v74); /*0x1068055be*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 208)); /*0x1068055d2*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1680, a2: &ThreadLocal); /*0x1068055e5*/
    v75 = (std::__shared_weak_count *)v122; /*0x1068055ea*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805603*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v75 + 16LL))(a1: v75); /*0x10680560b*/
      std::__shared_weak_count::__release_weak(this: v75); /*0x106805611*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v70); /*0x106805625*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1696, a2: &ThreadLocal); /*0x10680563b*/
    v76 = (std::__shared_weak_count *)v122; /*0x106805640*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805659*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v76 + 16LL))(a1: v76); /*0x106805661*/
      std::__shared_weak_count::__release_weak(this: v76); /*0x106805667*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 212)); /*0x10680567b*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1712, a2: &ThreadLocal); /*0x10680568e*/
    v77 = (std::__shared_weak_count *)v122; /*0x106805693*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068056ac*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v77 + 16LL))(a1: v77); /*0x1068056b4*/
      std::__shared_weak_count::__release_weak(this: v77); /*0x1068056ba*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v70); /*0x1068056ce*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1728, a2: &ThreadLocal); /*0x1068056e4*/
    v78 = (std::__shared_weak_count *)v122; /*0x1068056e9*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805702*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v78 + 16LL))(a1: v78); /*0x10680570a*/
      std::__shared_weak_count::__release_weak(this: v78); /*0x106805710*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 216)); /*0x106805724*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1744, a2: &ThreadLocal); /*0x106805737*/
    v79 = (std::__shared_weak_count *)v122; /*0x10680573c*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805755*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v79 + 16LL))(a1: v79); /*0x10680575d*/
      std::__shared_weak_count::__release_weak(this: v79); /*0x106805763*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *v70); /*0x106805777*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1760, a2: &ThreadLocal); /*0x10680578d*/
    v80 = (std::__shared_weak_count *)v122; /*0x106805792*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068057ab*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v80 + 16LL))(a1: v80); /*0x1068057b3*/
      std::__shared_weak_count::__release_weak(this: v80); /*0x1068057b9*/
    }
    RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 220)); /*0x1068057cd*/
    std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1776, a2: &ThreadLocal); /*0x1068057e0*/
    v81 = (std::__shared_weak_count *)v122; /*0x1068057e5*/
    if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068057fe*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v81 + 16LL))(a1: v81); /*0x106805806*/
      std::__shared_weak_count::__release_weak(this: v81); /*0x10680580c*/
    }
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x10680581f*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 592, a2: &ThreadLocal); /*0x106805835*/
  v82 = (std::__shared_weak_count *)v122; /*0x10680583a*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805853*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v82 + 16LL))(a1: v82); /*0x10680585b*/
    std::__shared_weak_count::__release_weak(this: v82); /*0x106805861*/
  }
  RBX::Stats::Item::createBoundChildItem<int,double>(a1: v112, a2: *((_QWORD *)a1 + 74), a3: "Size", a4: v4 + 4040); /*0x106805882*/
  v83 = v113; /*0x106805887*/
  if ( v113 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v113 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068058a0*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v83 + 16LL))(a1: v83); /*0x1068058a8*/
    std::__shared_weak_count::__release_weak(this: v83); /*0x1068058ae*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x1068058c1*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 608, a2: &ThreadLocal); /*0x1068058d7*/
  v84 = (std::__shared_weak_count *)v122; /*0x1068058dc*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068058f5*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v84 + 16LL))(a1: v84); /*0x1068058fd*/
    std::__shared_weak_count::__release_weak(this: v84); /*0x106805903*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 76)); /*0x106805916*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 624, a2: &ThreadLocal); /*0x106805929*/
  v85 = (std::__shared_weak_count *)v122; /*0x10680592e*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805947*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v85 + 16LL))(a1: v85); /*0x10680594f*/
    std::__shared_weak_count::__release_weak(this: v85); /*0x106805955*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106805968*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 656, a2: &ThreadLocal); /*0x10680597e*/
  v86 = (std::__shared_weak_count *)v122; /*0x106805983*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680599c*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v86 + 16LL))(a1: v86); /*0x1068059a4*/
    std::__shared_weak_count::__release_weak(this: v86); /*0x1068059aa*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: *((const char **)a1 + 82)); /*0x1068059bd*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 672, a2: &ThreadLocal); /*0x1068059d0*/
  v87 = (std::__shared_weak_count *)v122; /*0x1068059d5*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068059ee*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v87 + 16LL))(a1: v87); /*0x1068059f6*/
    std::__shared_weak_count::__release_weak(this: v87); /*0x1068059fc*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: v119); /*0x106805a10*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 288, a2: &ThreadLocal); /*0x106805a23*/
  v88 = (std::__shared_weak_count *)v122; /*0x106805a28*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805a41*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v88 + 16LL))(a1: v88); /*0x106805a49*/
    std::__shared_weak_count::__release_weak(this: v88); /*0x106805a4f*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106805a62*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 272, a2: &ThreadLocal); /*0x106805a75*/
  v89 = (std::__shared_weak_count *)v122; /*0x106805a7a*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805a93*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v89 + 16LL))(a1: v89); /*0x106805a9b*/
    std::__shared_weak_count::__release_weak(this: v89); /*0x106805aa1*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106805ab4*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 928, a2: &ThreadLocal); /*0x106805ac7*/
  v90 = (std::__shared_weak_count *)v122; /*0x106805acc*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805ae5*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v90 + 16LL))(a1: v90); /*0x106805aed*/
    std::__shared_weak_count::__release_weak(this: v90); /*0x106805af3*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106805b06*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 944, a2: &ThreadLocal); /*0x106805b19*/
  v91 = (std::__shared_weak_count *)v122; /*0x106805b1e*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805b37*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v91 + 16LL))(a1: v91); /*0x106805b3f*/
    std::__shared_weak_count::__release_weak(this: v91); /*0x106805b45*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106805b58*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 960, a2: &ThreadLocal); /*0x106805b6b*/
  v92 = (std::__shared_weak_count *)v122; /*0x106805b70*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805b89*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v92 + 16LL))(a1: v92); /*0x106805b91*/
    std::__shared_weak_count::__release_weak(this: v92); /*0x106805b97*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106805baa*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 992, a2: &ThreadLocal); /*0x106805bbd*/
  v93 = (std::__shared_weak_count *)v122; /*0x106805bc2*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805bdb*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v93 + 16LL))(a1: v93); /*0x106805be3*/
    std::__shared_weak_count::__release_weak(this: v93); /*0x106805be9*/
  }
  RBX::Stats::Item::createChildItem(this: (RBX::Stats::Item *)&ThreadLocal, a2: a1); /*0x106805bfc*/
  std::shared_ptr<RBX::Stats::Item>::operator=[abi:ne200100](a1: a1 + 1008, a2: &ThreadLocal); /*0x106805c0f*/
  v94 = (std::__shared_weak_count *)v122; /*0x106805c14*/
  if ( v122 != nullptr && _InterlockedExchangeAdd64(v122 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106805c2d*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v94 + 16LL))(a1: v94); /*0x106805c35*/
    std::__shared_weak_count::__release_weak(this: v94); /*0x106805c3b*/
  }
  result = RBX::Stats::Item::createBoundChildItem<double>(a1: v114, a2: a1, a3: "OutBufferHealth", a4: v116); /*0x106805c52*/
  v96 = v115; /*0x106805c57*/
  if ( v115 != nullptr ) /*0x106805c5e*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v115 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x106805c67*/
    if ( result == 0 ) /*0x106805c70*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v96 + 16LL))(a1: v96); /*0x106805c78*/
      result = std::__shared_weak_count::__release_weak(this: v96); /*0x106805c7e*/
    }
  }
  v97 = v118; /*0x106805c83*/
  if ( v118 != nullptr ) /*0x106805c8a*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v118 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x106805c93*/
    if ( result == 0 ) /*0x106805c9c*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v97 + 16LL))(a1: v97); /*0x106805ca4*/
      result = std::__shared_weak_count::__release_weak(this: v97); /*0x106805caa*/
    }
  }
  v98 = v120; /*0x106805caf*/
  if ( v120 != nullptr ) /*0x106805cb6*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v120 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x106805cbf*/
    if ( result == 0 ) /*0x106805cc8*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v98 + 16LL))(a1: v98); /*0x106805cd0*/
      return std::__shared_weak_count::__release_weak(this: v98); /*0x106805cd6*/
    }
  }
  return result; /*0x106805cdb*/
}

// Address: 0x1068069c4 | Name: __ZN3RBX7Network15ReplicatorItems5Stats6updateEv
void __fastcall RBX::Network::ReplicatorItems::Stats::update(std::__shared_weak_count **this)
{
  RBX::Network::ReplicatorItems::Stats *v1; // r13
  std::__shared_weak_count *v2; // rdi
  volatile signed __int64 *v3; // rax
  __int64 v4; // r14
  __int64 v5; // rdi
  __int64 v6; // rdi
  __int64 v7; // rdi
  __int64 v8; // rdi
  __int64 *v9; // rax
  volatile signed __int64 *v10; // r15
  __int64 v11; // r14
  __int64 v12; // rbx
  volatile signed __int64 *v13; // r13
  __int64 v14; // rdi
  __int64 *v15; // rax
  volatile signed __int64 *v16; // r15
  __int64 v17; // r14
  __int64 v18; // rbx
  volatile signed __int64 *v19; // r13
  __int64 v20; // rdi
  __int64 v21; // rdi
  __int64 v22; // rdi
  __int64 InstanceStateReplicator; // r15
  __int64 v24; // rdi
  _QWORD *v25; // r15
  __int64 v26; // rdi
  __int64 v27; // rdi
  __int64 v28; // rdi
  __int64 v29; // rdi
  __int64 v30; // rdi
  __int64 v31; // rdi
  __int64 v32; // rdi
  __int64 v33; // rdi
  __int64 v34; // rdi
  __int64 v35; // rdi
  __int64 v36; // rdi
  __int64 v37; // rdx
  __int64 v38; // rcx
  __int64 v39; // rsi
  __int64 v40; // rdi
  RBX::Stats::Item *v41; // r15
  double BandwidthExceeded; // xmm0_8
  RBX::Stats::Item *v43; // r15
  __int64 v44; // rdx
  __int64 v45; // rcx
  __int64 v46; // rsi
  __int64 v47; // r8
  __int64 v48; // r9
  double CongestionControlExceeded; // xmm0_8
  __int64 v50; // r15
  bool v51; // si
  __int64 v52; // rax
  float v53; // xmm0_4
  volatile signed __int64 *v54; // r15
  __int64 v55; // r12
  __int64 v56; // r12
  __int64 v57; // rdi
  __int64 v58; // rdi
  int v59; // eax
  int v60; // edx
  char v61; // si
  int v62; // eax
  int v63; // edx
  char v64; // si
  __int64 v65; // rax
  __int64 v66; // rax
  __int64 v67; // rcx
  unsigned __int64 v68; // rsi
  __int64 v69; // [rsp+28h] [rbp-78h]
  RBX::Network::Replicator *v70; // [rsp+40h] [rbp-60h]
  volatile signed __int64 *v71; // [rsp+48h] [rbp-58h]
  RBX::Network::ReplicatorItems::Stats *v72; // [rsp+50h] [rbp-50h]
  RBX::Network::ReplicatorItems::Stats *v73; // [rsp+50h] [rbp-50h]
  __int64 v74; // [rsp+58h] [rbp-48h] BYREF
  float v75[16]; // [rsp+60h] [rbp-40h] BYREF

  v1 = (RBX::Network::ReplicatorItems::Stats *)this; /*0x1068069d5*/
  v2 = *(this + 249); /*0x1068069d8*/
  if ( v2 == nullptr ) /*0x1068069e2*/
    return; /*0x1068069e2*/
  v3 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v2); /*0x1068069e8*/
  v71 = v3; /*0x1068069ed*/
  if ( v3 == nullptr ) /*0x1068069f4*/
    return; /*0x1068069f4*/
  v4 = *((_QWORD *)v1 + 248); /*0x1068069fa*/
  v70 = (RBX::Network::Replicator *)v4; /*0x106806a01*/
  if ( v4 == 0 ) /*0x106806a08*/
  {
    v54 = v3; /*0x10680712b*/
LABEL_68:
    if ( _InterlockedExchangeAdd64(v54 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106807350*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v54 + 16))(a1: v54); /*0x106807358*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v54); /*0x10680735e*/
    }
    return; /*0x10680735e*/
  }
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 106)); /*0x106806a1c*/
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 48)); /*0x106806a2f*/
  RBX::Stats::Item::formatValue( /*0x106806a59*/
    this: *((RBX::Stats::Item **)v1 + 52),
    a2: *(double *)(v4 + 3784),
    a3: "%.1f%%",
    100.0 * *(double *)(v4 + 3784));
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 54)); /*0x106806a6c*/
  v5 = *((_QWORD *)v1 + 56); /*0x106806a71*/
  *(_QWORD *)v75 = *(_QWORD *)(v4 + 3144); /*0x106806a85*/
  RBX::Stats::Item::formatValue<double>(a1: v5); /*0x106806a89*/
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 60)); /*0x106806a9c*/
  v6 = *((_QWORD *)v1 + 62); /*0x106806aa1*/
  *(_QWORD *)v75 = *(_QWORD *)(v4 + 3248); /*0x106806ab5*/
  RBX::Stats::Item::formatValue<double>(a1: v6); /*0x106806ab9*/
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 64)); /*0x106806acc*/
  v7 = *((_QWORD *)v1 + 66); /*0x106806ad1*/
  *(_QWORD *)v75 = *(_QWORD *)(v4 + 3352); /*0x106806ae5*/
  RBX::Stats::Item::formatValue<double>(a1: v7); /*0x106806ae9*/
  v74 = 0; /*0x106806aee*/
  v8 = *((_QWORD *)v1 + 50); /*0x106806af6*/
  v9 = *(__int64 **)(v8 + 120); /*0x106806afd*/
  v69 = v4; /*0x106806b04*/
  if ( v9 != nullptr ) /*0x106806b08*/
  {
    v10 = *(volatile signed __int64 **)(v8 + 128); /*0x106806b12*/
    if ( v10 != nullptr ) /*0x106806b20*/
      _InterlockedIncrement64(v10 + 1); /*0x106806b22*/
    v11 = *v9; /*0x106806b27*/
    v12 = v9[1]; /*0x106806b2a*/
    if ( *v9 != v12 ) /*0x106806b31*/
    {
      v72 = v1; /*0x106806b33*/
      do /*0x106806b92*/
      {
        v13 = *(volatile signed __int64 **)(v11 + 8); /*0x106806b3f*/
        *(_OWORD *)v75 = *(_OWORD *)v11; /*0x106806b48*/
        if ( v13 != nullptr ) /*0x106806b50*/
          _InterlockedIncrement64(v13 + 1); /*0x106806b52*/
        RBX::Network::ReplicatorItems::accumulateValue(a1: v75, a2: &v74); /*0x106806b5d*/
        if ( v13 != nullptr && _InterlockedExchangeAdd64(v13 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106806b77*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v13 + 16))(a1: v13); /*0x106806b80*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v13); /*0x106806b86*/
        }
        v11 += 16; /*0x106806b8b*/
      }
      while ( v11 != v12 ); /*0x106806b92*/
      v1 = v72; /*0x106806b98*/
    }
    v4 = v69; /*0x106806b9f*/
    if ( v10 != nullptr && _InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106806bb5*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v10 + 16))(a1: v10); /*0x106806bbd*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v10); /*0x106806bc3*/
    }
    v8 = *((_QWORD *)v1 + 50); /*0x106806bc8*/
  }
  RBX::Stats::Item::formatValue<double>(a1: v8); /*0x106806bd3*/
  v74 = 0; /*0x106806bd8*/
  v14 = *((_QWORD *)v1 + 58); /*0x106806be0*/
  v15 = *(__int64 **)(v14 + 120); /*0x106806be7*/
  if ( v15 != nullptr ) /*0x106806bee*/
  {
    v16 = *(volatile signed __int64 **)(v14 + 128); /*0x106806bf8*/
    if ( v16 != nullptr ) /*0x106806c06*/
      _InterlockedIncrement64(v16 + 1); /*0x106806c08*/
    v17 = *v15; /*0x106806c0d*/
    v18 = v15[1]; /*0x106806c10*/
    if ( *v15 != v18 ) /*0x106806c17*/
    {
      v73 = v1; /*0x106806c19*/
      do /*0x106806c78*/
      {
        v19 = *(volatile signed __int64 **)(v17 + 8); /*0x106806c25*/
        *(_OWORD *)v75 = *(_OWORD *)v17; /*0x106806c2e*/
        if ( v19 != nullptr ) /*0x106806c36*/
          _InterlockedIncrement64(v19 + 1); /*0x106806c38*/
        RBX::Network::ReplicatorItems::accumulateValue(a1: v75, a2: &v74); /*0x106806c43*/
        if ( v19 != nullptr && _InterlockedExchangeAdd64(v19 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106806c5d*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v19 + 16))(a1: v19); /*0x106806c66*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v19); /*0x106806c6c*/
        }
        v17 += 16; /*0x106806c71*/
      }
      while ( v17 != v18 ); /*0x106806c78*/
      v1 = v73; /*0x106806c7e*/
    }
    v4 = v69; /*0x106806c85*/
    if ( v16 != nullptr && _InterlockedExchangeAdd64(v16 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106806c9b*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v16 + 16))(a1: v16); /*0x106806ca3*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v16); /*0x106806ca9*/
    }
    v14 = *((_QWORD *)v1 + 58); /*0x106806cae*/
  }
  RBX::Stats::Item::formatValue<double>(a1: v14); /*0x106806cb9*/
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 74)); /*0x106806ccc*/
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 76)); /*0x106806cdf*/
  v20 = *((_QWORD *)v1 + 78); /*0x106806ce4*/
  *(_QWORD *)v75 = *(_QWORD *)(v4 + 3560); /*0x106806cf8*/
  RBX::Stats::Item::formatValue<double>(a1: v20); /*0x106806cfc*/
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 86)); /*0x106806d0f*/
  RBX::Stats::Item::formatValue( /*0x106806d39*/
    this: *((RBX::Stats::Item **)v1 + 88),
    a2: *(double *)(v4 + 4336),
    a3: "%.1f%%",
    100.0 * *(double *)(v4 + 4336));
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 90)); /*0x106806d4c*/
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 94)); /*0x106806d5f*/
  v21 = *((_QWORD *)v1 + 96); /*0x106806d64*/
  *(_QWORD *)v75 = *(_QWORD *)(v4 + 3456); /*0x106806d78*/
  RBX::Stats::Item::formatValue<double>(a1: v21); /*0x106806d7c*/
  v22 = *((_QWORD *)v1 + 102); /*0x106806d81*/
  *(_QWORD *)v75 = *(_QWORD *)(v4 + 5040); /*0x106806d95*/
  RBX::Stats::Item::formatValue<double>(a1: v22); /*0x106806d99*/
  if ( FFlag::OutIsrMetricsInNetworkStats == 1 ) /*0x106806da8*/
  {
    InstanceStateReplicator = RBX::Network::Replicator::getInstanceStateReplicator(this: v70); /*0x106806db3*/
    if ( InstanceStateReplicator != 0 ) /*0x106806db9*/
    {
      RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 112)); /*0x106806dc6*/
      v24 = *((_QWORD *)v1 + 114); /*0x106806dcb*/
      *(_QWORD *)v75 = *(_QWORD *)(InstanceStateReplicator + 120); /*0x106806ddc*/
      RBX::Stats::Item::formatValue<double>(a1: v24); /*0x106806de0*/
    }
  }
  if ( FFlag::CollectISRPhysicsBandwidthUsage == 1 ) /*0x106806def*/
  {
    v25 = *((_QWORD **)v70 + 35); /*0x106806df9*/
    RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 204)); /*0x106806e0e*/
    v26 = *((_QWORD *)v1 + 206); /*0x106806e13*/
    *(_QWORD *)v75 = v25[40]; /*0x106806e27*/
    RBX::Stats::Item::formatValue<double>(a1: v26); /*0x106806e2b*/
    RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 208)); /*0x106806e3e*/
    v27 = *((_QWORD *)v1 + 210); /*0x106806e43*/
    *(_QWORD *)v75 = v25[53]; /*0x106806e57*/
    RBX::Stats::Item::formatValue<double>(a1: v27); /*0x106806e5b*/
    RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 212)); /*0x106806e6e*/
    v28 = *((_QWORD *)v1 + 214); /*0x106806e73*/
    *(_QWORD *)v75 = v25[66]; /*0x106806e87*/
    RBX::Stats::Item::formatValue<double>(a1: v28); /*0x106806e8b*/
    RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 216)); /*0x106806e9e*/
    v29 = *((_QWORD *)v1 + 218); /*0x106806ea3*/
    *(_QWORD *)v75 = v25[79]; /*0x106806eb7*/
    RBX::Stats::Item::formatValue<double>(a1: v29); /*0x106806ebb*/
    RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 220)); /*0x106806ece*/
    v30 = *((_QWORD *)v1 + 222); /*0x106806ed3*/
    *(_QWORD *)v75 = v25[92]; /*0x106806ee7*/
    RBX::Stats::Item::formatValue<double>(a1: v30); /*0x106806eeb*/
    RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 182)); /*0x106806efe*/
    v31 = *((_QWORD *)v1 + 184); /*0x106806f03*/
    *(_QWORD *)v75 = v25[107]; /*0x106806f17*/
    RBX::Stats::Item::formatValue<double>(a1: v31); /*0x106806f1b*/
    RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 186)); /*0x106806f2e*/
    v32 = *((_QWORD *)v1 + 188); /*0x106806f33*/
    *(_QWORD *)v75 = v25[120]; /*0x106806f47*/
    RBX::Stats::Item::formatValue<double>(a1: v32); /*0x106806f4b*/
    RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 190)); /*0x106806f5e*/
    v33 = *((_QWORD *)v1 + 192); /*0x106806f63*/
    *(_QWORD *)v75 = v25[133]; /*0x106806f77*/
    RBX::Stats::Item::formatValue<double>(a1: v33); /*0x106806f7b*/
    RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 194)); /*0x106806f8e*/
    v34 = *((_QWORD *)v1 + 196); /*0x106806f93*/
    *(_QWORD *)v75 = v25[146]; /*0x106806fa7*/
    RBX::Stats::Item::formatValue<double>(a1: v34); /*0x106806fab*/
    RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 198)); /*0x106806fbe*/
    v35 = *((_QWORD *)v1 + 200); /*0x106806fc3*/
    *(_QWORD *)v75 = v25[159]; /*0x106806fd7*/
    RBX::Stats::Item::formatValue<double>(a1: v35); /*0x106806fdb*/
  }
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 80)); /*0x106806fee*/
  RBX::Stats::Item::formatRate(this: *((RBX::Stats::Item **)v1 + 82)); /*0x106807001*/
  v36 = *((_QWORD *)v1 + 84); /*0x106807006*/
  *(_QWORD *)v75 = *(_QWORD *)(v4 + 3664); /*0x10680701a*/
  RBX::Stats::Item::formatValue<double>(a1: v36); /*0x10680701e*/
  v40 = *((_QWORD *)v70 + 28); /*0x106807027*/
  if ( v40 != 0 ) /*0x106807031*/
  {
    v41 = *((RBX::Stats::Item **)v1 + 40); /*0x106807037*/
    BandwidthExceeded = RBX::Network::ConcurrentRakPeer::GetBandwidthExceeded(a1: v40, a2: v39, a3: v37, a4: v38); /*0x106807059*/
    RBX::Stats::Item::formatValue(this: v41, a2: BandwidthExceeded, a3: "%.1f%%", BandwidthExceeded * 100.0); /*0x106807076*/
    v43 = *((RBX::Stats::Item **)v1 + 42); /*0x10680707b*/
    CongestionControlExceeded = RBX::Network::ConcurrentRakPeer::GetCongestionControlExceeded( /*0x1068070a4*/
                                  a1: *((_QWORD *)v70 + 28),
                                  a2: v46,
                                  a3: v44,
                                  a4: v45,
                                  a5: v47,
                                  a6: v48,
                                  a7: *((_QWORD *)v70 + 30),
                                  a8: *((_QWORD *)v70 + 31),
                                  a9: *((_QWORD *)v70 + 32),
                                  a10: *((_QWORD *)v70 + 33));
    RBX::Stats::Item::formatValue( /*0x1068070c1*/
      this: v43,
      a2: CongestionControlExceeded,
      a3: "%.1f%%",
      CongestionControlExceeded * 100.0);
    RBX::Stats::Item::formatValue( /*0x1068070f2*/
      this: *((RBX::Stats::Item **)v1 + 32),
      a2: (double)*(int *)(v4 + 5992),
      a3: "%d avg:%d best:%d",
      *(_DWORD *)(v4 + 5992),
      *(_DWORD *)(v4 + 5988),
      *(_DWORD *)(v4 + 5996));
    RBX::Stats::Item::formatValue<int>(a1: *((_QWORD *)v1 + 36), a2: v4 + 5984); /*0x106807105*/
    v50 = *((_QWORD *)v1 + 34); /*0x10680710a*/
    v52 = RakNet::GetTimeUS(this: nullptr, a2: v51) - *(_QWORD *)(v4 + 6536); /*0x106807118*/
    if ( v52 < 0 ) /*0x10680711f*/
      v53 = (float)(int)(((unsigned __int64)v52 >> 1) | v52 & 1) + (float)(int)(((unsigned __int64)v52 >> 1) | v52 & 1); /*0x106807147*/
    else
      v53 = (float)(int)v52; /*0x106807124*/
    v75[0] = v53 / 1000000.0; /*0x106807157*/
    RBX::Stats::Item::formatValue<float>(a1: v50); /*0x10680715e*/
    v55 = *((_QWORD *)v1 + 26); /*0x106807163*/
    *(_QWORD *)v75 = RBX::Network::Replicator::incomingPacketsCount(this: v70); /*0x10680717a*/
    RBX::Stats::Item::formatValue<unsigned long>(a1: v55); /*0x106807180*/
    v56 = *((_QWORD *)v1 + 30); /*0x106807185*/
    *(_QWORD *)v75 = RBX::Network::ItemQueue::size(this: (RBX::Network::Replicator *)((char *)v70 + 14536)); /*0x10680719c*/
    RBX::Stats::Item::formatValue<unsigned long>(a1: v56); /*0x1068071a2*/
    v57 = *((_QWORD *)v1 + 68); /*0x1068071a7*/
    *(_QWORD *)v75 = *(_QWORD *)(v4 + 3864); /*0x1068071bb*/
    RBX::Stats::Item::formatValue<double>(a1: v57); /*0x1068071bf*/
    v58 = *((_QWORD *)v1 + 46); /*0x1068071cb*/
    if ( FFlag::RefactorIngressFlow == 1 ) /*0x1068071d5*/
    {
      v59 = 1; /*0x1068071e3*/
      if ( DFInt::SpinMutexAttemptsBeforeYield >= 2 ) /*0x1068071e8*/
        v59 = DFInt::SpinMutexAttemptsBeforeYield; /*0x1068071e8*/
      v60 = 0; /*0x1068071ed*/
      while ( 1 ) /*0x1068071f2*/
      {
        v61 = *((_BYTE *)v70 + 18880); /*0x1068071f2*/
        *((_BYTE *)v70 + 18880) = 1; /*0x1068071f2*/
        if ( (v61 & 1) == 0 ) /*0x1068071fd*/
          break; /*0x1068071fd*/
        if ( ++v60 == v59 ) /*0x106807203*/
          v60 = 0; /*0x106807203*/
      }
      v65 = *((_QWORD *)v70 + 2359); /*0x10680723d*/
      *((_BYTE *)v70 + 18880) = 0; /*0x106807244*/
      *(_QWORD *)v75 = v65; /*0x106807250*/
      RBX::Stats::Item::formatValue<unsigned long>(a1: v58); /*0x106807253*/
    }
    else
    {
      v62 = 1; /*0x10680721b*/
      if ( DFInt::SpinMutexAttemptsBeforeYield >= 2 ) /*0x106807220*/
        v62 = DFInt::SpinMutexAttemptsBeforeYield; /*0x106807220*/
      v63 = 0; /*0x106807225*/
      while ( 1 ) /*0x10680722a*/
      {
        v64 = *((_BYTE *)v70 + 18832); /*0x10680722a*/
        *((_BYTE *)v70 + 18832) = 1; /*0x10680722a*/
        if ( (v64 & 1) == 0 ) /*0x106807232*/
          break; /*0x106807232*/
        if ( ++v63 == v62 ) /*0x106807238*/
          v63 = 0; /*0x106807238*/
      }
      v66 = *((_QWORD *)v70 + 2353); /*0x10680725a*/
      *((_BYTE *)v70 + 18832) = 0; /*0x10680725e*/
      *(_QWORD *)v75 = v66; /*0x106807267*/
      RBX::Stats::Item::formatValue<unsigned long>(a1: v58); /*0x10680726a*/
    }
    v67 = *((_QWORD *)v1 + 250); /*0x106807276*/
    if ( v67 != 0 ) /*0x106807280*/
      v68 = *((_QWORD *)v1 + 251) / (unsigned __int64)(8 * v67); /*0x106807292*/
    else
      v68 = 0; /*0x106807297*/
    RBX::Stats::Item::formatMem(this: *((RBX::Stats::Item **)v1 + 44), a2: v68); /*0x106807299*/
    RBX::Stats::Item::formatValue<float>(a1: *((_QWORD *)v1 + 116)); /*0x1068072ac*/
    RBX::Stats::Item::formatValue<unsigned long long>(a1: *((_QWORD *)v1 + 118), a2: v4 + 6456); /*0x1068072bf*/
    RBX::Stats::Item::formatValue<unsigned long long>(a1: *((_QWORD *)v1 + 120), a2: v4 + 6448); /*0x1068072d2*/
    RBX::Stats::Item::formatValue<unsigned long long>(a1: *((_QWORD *)v1 + 124), a2: v4 + 6520); /*0x1068072e5*/
    RBX::Stats::Item::formatValue<unsigned long long>(a1: *((_QWORD *)v1 + 126), a2: v4 + 6512); /*0x1068072f8*/
  }
  RBX::Network::ReplicatorItems::Stats::DataPingComponents::formatChildrenValues( /*0x106807312*/
    a1: (char *)v1 + 1024,
    a2: v4 + 5544,
    a3: *(unsigned int *)(v4 + 5992));
  RBX::Network::ReplicatorItems::Stats::DataPingComponents::formatChildrenValues( /*0x106807332*/
    a1: (char *)v1 + 1232,
    a2: v4 + 5592,
    a3: *(unsigned int *)(v4 + 5992));
  v54 = v71; /*0x106807337*/
  if ( v71 != nullptr ) /*0x10680733e*/
    goto LABEL_68; /*0x10680733e*/
}

// Address: 0x1068074e2 | Name: __ZN3RBX7Network15ReplicatorItems5Stats17onServiceProviderEPNS_15ServiceProviderES4_
volatile signed __int64 *__fastcall RBX::Network::ReplicatorItems::Stats::onServiceProvider(
        std::__shared_weak_count **this,
        RBX::ServiceProvider *a2,
        RBX::ServiceProvider *a3)
{
  volatile signed __int64 *result; // rax
  std::__shared_weak_count *v6; // rdi
  volatile signed __int64 *v7; // rbx
  __int64 v8[4]; // [rsp+0h] [rbp-20h] BYREF

  result = (volatile signed __int64 *)RBX::Instance::onServiceProvider((RBX::Instance *)this, a2, a3); /*0x1068074f3*/
  if ( a3 != nullptr ) /*0x1068074fb*/
  {
    v6 = *(this + 249); /*0x1068074fd*/
    if ( v6 != nullptr ) /*0x106807507*/
    {
      result = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v6); /*0x106807509*/
      v8[1] = (__int64)result; /*0x10680750e*/
      if ( result != nullptr ) /*0x106807515*/
      {
        v7 = result; /*0x106807517*/
        v8[0] = (__int64)*(this + 248); /*0x106807521*/
        if ( v8[0] != 0 ) /*0x106807528*/
          RBX::Network::ReplicatorItems::Stats::init(a1: (char *)this, a2: v8); /*0x106807531*/
        result = (volatile signed __int64 *)_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x10680753d*/
        if ( result == nullptr ) /*0x106807546*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(a1: v7); /*0x10680754e*/
          return (volatile signed __int64 *)std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v7); /*0x106807554*/
        }
      }
    }
  }
  return result; /*0x106807559*/
}

// Address: 0x106807660 | Name: __ZN3RBX7Network15ReplicatorItems5StatsD1Ev
void __fastcall RBX::Network::ReplicatorItems::Stats::~Stats(RBX::Network::ReplicatorItems::Stats *this)
{
  RBX::Network::ReplicatorItems::Stats::~Stats(this); /*0x106807665*/
}

// Address: 0x10680766a | Name: __ZN3RBX7Network15ReplicatorItems5StatsD0Ev
void __fastcall RBX::Network::ReplicatorItems::Stats::~Stats(RBX::Network::ReplicatorItems::Stats *this)
{
  RBX::Network::ReplicatorItems::Stats::~Stats(this); /*0x106807673*/
  operator delete(a1: this); /*0x106807681*/
}

// Address: 0x106ab8184 | Name: __ZNK9grpc_core6chttp220TransportFlowControl5Stats8ToStringEv
grpc_core::chttp2::TransportFlowControl::Stats *__fastcall grpc_core::chttp2::TransportFlowControl::Stats::ToString(
        grpc_core::chttp2::TransportFlowControl::Stats *this,
        __int64 a2,
        char *a3)
{
  __int64 v5; // rax
  char *v6; // rdx
  __int64 v7; // rax
  __int128 v9; // [rsp+20h] [rbp-120h] BYREF
  __int128 v10; // [rsp+50h] [rbp-F0h] BYREF
  __int64 v11[4]; // [rsp+60h] [rbp-E0h] BYREF
  int v12[12]; // [rsp+80h] [rbp-C0h] BYREF
  int v13[4]; // [rsp+B0h] [rbp-90h] BYREF
  __int64 v14[4]; // [rsp+C0h] [rbp-80h] BYREF
  __int128 v15; // [rsp+E0h] [rbp-60h] BYREF

  *(_QWORD *)&v15 = "target_window: ";
  *((_QWORD *)&v15 + 1) = 15; /*0x106ab81ba*/
  v5 = absl::lts_20240116::numbers_internal::FastIntToBuffer(this: *(_QWORD *)a2, a2: (__int64)v14, a3); /*0x106ab81cc*/
  *(_QWORD *)v13 = v14; /*0x106ab81d4*/
  *(_QWORD *)&v13[2] = v5 - (_QWORD)v14; /*0x106ab81d9*/
  *(_QWORD *)v12 = " target_frame_size: ";
  *(_QWORD *)&v12[2] = 20; /*0x106ab81ef*/
  v7 = absl::lts_20240116::numbers_internal::FastIntToBuffer(this: *(_QWORD *)(a2 + 8), a2: (__int64)v11, a3: v6); /*0x106ab8205*/
  *(_QWORD *)&v10 = v11; /*0x106ab820d*/
  *((_QWORD *)&v10 + 1) = v7 - (_QWORD)v11; /*0x106ab8211*/
  *(_QWORD *)&v9 = " target_preferred_rx_crypto_frame_size: ";
  *((_QWORD *)&v9 + 1) = 40; /*0x106ab8226*/
  absl::lts_20240116::StrCat<long long,char [21],unsigned int,char [22],unsigned int,char [20],unsigned int,char [17],long long,char [20],long long,char [47],long long,char [19],long long,char [16],long long,char [14],double>(
    a1: (__int64)this,
    a2: &v15,
    a3: (char *)v13,
    a4: v12,
    a5: &v10,
    a6: &v9,
    a7: (absl::lts_20240116::numbers_internal **)(a2 + 16),
    __s: " acked_init_window: ",
    a9: (unsigned int *)(a2 + 24),
    a10: " queued_init_window: ",
    a11: (unsigned int *)(a2 + 28),
    a12: " sent_init_window: ",
    a13: (unsigned int *)(a2 + 32),
    a14: " remote_window: ",
    a15: (absl::lts_20240116::numbers_internal **)(a2 + 40),
    a16: " announced_window: ",
    a17: (absl::lts_20240116::numbers_internal **)(a2 + 48),
    a18: " announced_stream_total_over_incoming_window: ",
    a19: (absl::lts_20240116::numbers_internal **)(a2 + 56),
    a20: " bdp_accumulator: ",
    a21: (absl::lts_20240116::numbers_internal **)(a2 + 64),
    a22: " bdp_estimate: ",
    a23: (absl::lts_20240116::numbers_internal **)(a2 + 72),
    a24: " bdp_bw_est: ",
    a25: (double *)(a2 + 80));
  return this; /*0x106ab8313*/
}

// Address: 0x106ab886a | Name: __ZNK9grpc_core6chttp217StreamFlowControl5Stats8ToStringEv
grpc_core::chttp2::StreamFlowControl::Stats *__fastcall grpc_core::chttp2::StreamFlowControl::Stats::ToString(
        grpc_core::chttp2::StreamFlowControl::Stats *this,
        __int64 a2,
        char *a3)
{
  __int64 v5; // rax
  char *v6; // rdx
  __int64 v7; // rax
  char *v8; // rdx
  __int64 v9; // r12
  __int64 v10; // rax
  char *v11; // rdx
  __int64 v12; // rax
  __int64 v14[4]; // [rsp+10h] [rbp-150h] BYREF
  __int128 v15; // [rsp+30h] [rbp-130h]
  _QWORD v16[6]; // [rsp+40h] [rbp-120h] BYREF
  _QWORD v17[6]; // [rsp+70h] [rbp-F0h] BYREF
  _BYTE v18[32]; // [rsp+A0h] [rbp-C0h] BYREF
  _QWORD v19[14]; // [rsp+C0h] [rbp-A0h] BYREF

  v5 = absl::lts_20240116::numbers_internal::FastIntToBuffer(this: *(_QWORD *)a2, a2: (__int64)v16, a3); /*0x106ab889f*/
  *(_QWORD *)&v15 = v16; /*0x106ab88a7*/
  *((_QWORD *)&v15 + 1) = v5 - (_QWORD)v16; /*0x106ab88ab*/
  v7 = absl::lts_20240116::numbers_internal::FastIntToBuffer(this: *(_QWORD *)(a2 + 8), a2: (__int64)v14, a3: v6) /*0x106ab88c2*/
     - (_QWORD)v14;
  v9 = -1; /*0x106ab88cd*/
  if ( *(_BYTE *)(a2 + 32) == 1 ) /*0x106ab88d9*/
    v9 = *(_QWORD *)(a2 + 24); /*0x106ab88db*/
  v19[0] = "min_progress_size: ";
  v19[1] = 19; /*0x106ab88f0*/
  *(_OWORD *)&v19[2] = v15; /*0x106ab88ff*/
  v19[4] = " remote_window_delta: ";
  v19[5] = 22; /*0x106ab890f*/
  v19[6] = v14; /*0x106ab8917*/
  v19[7] = v7; /*0x106ab891b*/
  v19[8] = " announced_window_delta: ";
  v19[9] = 25; /*0x106ab892a*/
  v10 = absl::lts_20240116::numbers_internal::FastIntToBuffer(this: *(_QWORD *)(a2 + 16), a2: (__int64)v18, a3: v8); /*0x106ab8940*/
  v17[4] = v18; /*0x106ab8948*/
  v17[5] = v10 - (_QWORD)v18; /*0x106ab894c*/
  v19[10] = v18; /*0x106ab8950*/
  v19[11] = v10 - (_QWORD)v18; /*0x106ab8954*/
  v12 = absl::lts_20240116::numbers_internal::FastIntToBuffer(this: v9, a2: (__int64)v17, a3: v11); /*0x106ab8965*/
  v16[4] = v17; /*0x106ab896d*/
  v16[5] = v12 - (_QWORD)v17; /*0x106ab8971*/
  v19[12] = v17; /*0x106ab8975*/
  v19[13] = v12 - (_QWORD)v17; /*0x106ab8979*/
  absl::lts_20240116::strings_internal::CatPieces(a1: (__int64 *)this, a2: (__int64)v19, a3: 7); /*0x106ab8988*/
  return this; /*0x106ab89a0*/
}

// Address: 0x106cec4cc | Name: __ZN9grpc_core23XdsClusterLocalityStats5StatsD1Ev
void __fastcall grpc_core::XdsClusterLocalityStats::Stats::~Stats(grpc_core::XdsClusterLocalityStats::Stats *this)
{
  std::__tree<std::__value_type<std::string,grpc_core::XdsClusterLocalityStats::BackendMetric>,std::__map_value_compare<std::string,std::__value_type<std::string,grpc_core::XdsClusterLocalityStats::BackendMetric>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,grpc_core::XdsClusterLocalityStats::BackendMetric>>>::destroy( /*0x106cec4dd*/
    a1: (char *)this + 96,
    a2: *((_QWORD *)this + 13));
  gpr_mu_destroy(a1: (char *)this + 32); /*0x106cec4e9*/
}

// END Stats part 1/1, 46 functions
