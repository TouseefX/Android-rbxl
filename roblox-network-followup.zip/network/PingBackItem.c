// PingBackItem -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 7 functions


// Address: 0x1067fb940 | Name: __ZN3RBX7Network10Replicator12PingBackItemC2EPS1_yjjjNS_8SendModeEy
char __fastcall RBX::Network::Replicator::PingBackItem::PingBackItem(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        int a4,
        int a5,
        int a6,
        char a7,
        __int64 a8)
{
  RakNet *v13; // rdi
  RBX::Network *v14; // rdi
  unsigned __int64 v15; // rax
  __int64 v16; // rdi
  RBX::Time *v17; // r12
  unsigned __int8 TracerPeerId; // al

  RBX::Network::Item::Item(this: (RBX::Network::Item *)a1, (RBX::Network::Replicator *)a2); /*0x1067fb961*/
  *(_QWORD *)a1 = off_10CAACE90; /*0x1067fb96d*/
  *(_QWORD *)(a1 + 64) = a3; /*0x1067fb970*/
  *(_DWORD *)(a1 + 72) = a4; /*0x1067fb977*/
  *(_DWORD *)(a1 + 76) = a5; /*0x1067fb97b*/
  *(_DWORD *)(a1 + 96) = a6; /*0x1067fb982*/
  *(_BYTE *)(a1 + 100) = a7; /*0x1067fb988*/
  *(_DWORD *)(a1 + 80) = RakNet::GetTimeMS(this: v13); /*0x1067fb990*/
  *(_DWORD *)(a1 + 84) = *(_DWORD *)(a2 + 6004); /*0x1067fb99a*/
  *(_QWORD *)(a1 + 88) = *(_QWORD *)(a2 + 9368); /*0x1067fb9a4*/
  v15 = (unsigned __int64)&DFFlag::DataPingTrace; /*0x1067fb9a8*/
  if ( DFFlag::DataPingTrace == 1 ) /*0x1067fb9b2*/
  {
    v15 = (unsigned __int64)&DFFlag::RbxTransportNetworkTracing; /*0x1067fb9b4*/
    if ( DFFlag::RbxTransportNetworkTracing == 1 ) /*0x1067fb9be*/
    {
      LOBYTE(v15) = RBX::Network::flagsSendsGoThroughConnection(this: v14); /*0x1067fb9c0*/
      if ( (_BYTE)v15 != 0 ) /*0x1067fb9c7*/
      {
        v16 = *(_QWORD *)(a2 + 280); /*0x1067fb9c9*/
        if ( v16 != 0 ) /*0x1067fb9d3*/
        {
          v15 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v16 + 56LL))(a1: v16); /*0x1067fb9dc*/
          if ( a8 != 0 ) /*0x1067fb9e2*/
          {
            v15 &= 0x2000000000000uLL; /*0x1067fb9ee*/
            if ( v15 != 0 ) /*0x1067fb9f1*/
            {
              if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1067fb9fd*/
                v17 = *(RBX::Time **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1067fb9ff*/
              else
                v17 = nullptr; /*0x1067fba05*/
              TracerPeerId = RBX::NetworkBase::ConnectionInternal::getTracerPeerId(this: *(RBX::NetworkBase::ConnectionInternal **)(a2 + 280)); /*0x1067fba0f*/
              LOBYTE(v15) = RBX::Network::NetworkTracer::addCheckpointToTracer(a1: v17, a2: a8, a3: TracerPeerId, a4: 0); /*0x1067fba1f*/
              *(_QWORD *)(a1 + 56) = a8; /*0x1067fba24*/
            }
          }
        }
      }
    }
  }
  return v15; /*0x1067fba2c*/
}

// Address: 0x1067fba38 | Name: __ZN3RBX7Network10Replicator12PingBackItemC1EPS1_yjjjNS_8SendModeEy
char __fastcall RBX::Network::Replicator::PingBackItem::PingBackItem(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        int a4,
        int a5,
        int a6,
        char a7,
        __int64 a8)
{
  return RBX::Network::Replicator::PingBackItem::PingBackItem(a1, a2, a3, a4, a5, a6, a7, a8); /*0x1067fba3c*/
}

// Address: 0x1067fba42 | Name: __ZN3RBX7Network10Replicator12PingBackItem5writeERNS0_13NetworkStreamE
char __fastcall RBX::Network::Replicator::PingBackItem::write(
        RBX::Network::Replicator::PingBackItem *this,
        RBX::Network::NetworkStream *a2)
{
  RBX::Network *v4; // rdi
  bool v5; // r13
  __int64 v6; // rcx
  char v7; // al
  __int64 v8; // rdx
  __int64 v9; // rsi
  __int64 v10; // rax
  RakNet *v11; // rdi
  int v12; // r14d
  RBX::Instance *v13; // rsi
  RBX::DataModel *Dangerous_DEPRECATED; // rax
  bool v15; // dl
  RBX::CoreNetworkSettings *v16; // rdi
  __int64 v17; // r12
  int v18; // eax
  int v20; // [rsp+Ch] [rbp-34h]
  _QWORD v21[6]; // [rsp+10h] [rbp-30h] BYREF

  v20 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1067fba62*/
  RBX::Network::Item::writeItemType(a1: (__int64)this, a2, a3: 6u); /*0x1067fba70*/
  v5 = true; /*0x1067fba7c*/
  LOBYTE(v6) = 1; /*0x1067fba82*/
  if ( DFFlag::RbxTransportNetworkTracing == 1 ) /*0x1067fba84*/
  {
    v7 = RBX::Network::flagsSendsGoThroughConnection(this: v4); /*0x1067fba86*/
    LOBYTE(v6) = 1; /*0x1067fba8b*/
    if ( v7 != 0 ) /*0x1067fba8f*/
    {
      v10 = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, __int64))(**(_QWORD **)(*((_QWORD *)this + 3) + 280LL) /*0x1067fba9f*/
                                                                         + 56LL))(
              a1: *(_QWORD *)(*((_QWORD *)this + 3) + 280LL),
              a2: v9,
              a3: v8,
              a4: v6);
      LOBYTE(v6) = 1; /*0x1067fbaa7*/
      if ( (v10 & 0x2000000000000LL) != 0 ) /*0x1067fbaa9*/
      {
        v5 = *((_QWORD *)this + 7) == 0; /*0x1067fbab0*/
        LOBYTE(v6) = 8 * (*((_QWORD *)this + 7) != 0) + 1; /*0x1067fbaba*/
      }
    }
  }
  LOBYTE(v21[0]) = v6; /*0x1067fbac0*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 1u); /*0x1067fbacf*/
  v21[0] = *((_QWORD *)this + 8); /*0x1067fbad8*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 8u); /*0x1067fbae7*/
  LODWORD(v21[0]) = *((_DWORD *)this + 18); /*0x1067fbaf0*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 4u); /*0x1067fbaff*/
  LODWORD(v21[0]) = *((_DWORD *)this + 19); /*0x1067fbb08*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 4u); /*0x1067fbb17*/
  LODWORD(v21[0]) = *((_DWORD *)this + 20); /*0x1067fbb20*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 4u); /*0x1067fbb2f*/
  LODWORD(v21[0]) = RakNet::GetTimeMS(this: v11); /*0x1067fbb39*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 4u); /*0x1067fbb48*/
  LODWORD(v21[0]) = *((_DWORD *)this + 21); /*0x1067fbb51*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 4u); /*0x1067fbb60*/
  LODWORD(v21[0]) = *((_DWORD *)this + 22); /*0x1067fbb69*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 4u); /*0x1067fbb78*/
  LODWORD(v21[0]) = *((_DWORD *)this + 23); /*0x1067fbb81*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 4u); /*0x1067fbb90*/
  v12 = RBX::DataModel::sendStats; /*0x1067fbb9c*/
  Dangerous_DEPRECATED = (RBX::DataModel *)RBX::DataModel::getDangerous_DEPRECATED( /*0x1067fbba3*/
                                             this: *((RBX::DataModel **)this + 3),
                                             a2: v13);
  LODWORD(v21[0]) = v12 | RBX::DataModel::allHackFlagsOredTogether(this: Dangerous_DEPRECATED); /*0x1067fbbb3*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 4u); /*0x1067fbbc2*/
  LODWORD(v21[0]) = *((_DWORD *)this + 24); /*0x1067fbbcb*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 4u); /*0x1067fbbda*/
  LOBYTE(v21[0]) = *((_BYTE *)this + 100); /*0x1067fbbe3*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v21, a3: 1u); /*0x1067fbbf3*/
  if ( !v5 ) /*0x1067fbbfb*/
    RBX::Network::writeTracerFlag(this: a2, a2: (RBX::Network::NetworkStream *)(*((_QWORD *)this + 7) != 0), a3: v15); /*0x1067fbc0b*/
  if ( *(_BYTE *)(RBX::CoreNetworkSettings::singleton(this: v16) + 8) == 1 ) /*0x1067fbc19*/
  {
    RBX::Network::ReplicatorStats::incrementPacketsSent(a1: *((_QWORD *)this + 3) + 1456LL, a2: 2); /*0x1067fbc2d*/
    v17 = *((_QWORD *)this + 3) + 1456LL; /*0x1067fbc32*/
    v18 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1067fbc3c*/
    RBX::Network::ReplicatorStats::samplePacketsSent(a1: v17, a2: 2, a3: (unsigned int)(v18 - v20)); /*0x1067fbc4c*/
  }
  return 1; /*0x1067fbc53*/
}

// Address: 0x1067fbc62 | Name: __ZNK3RBX7Network10Replicator12PingBackItem11getSendModeEv
__int64 __fastcall RBX::Network::Replicator::PingBackItem::getSendMode(RBX::Network::Replicator::PingBackItem *this)
{
  return *((unsigned __int8 *)this + 100); /*0x1067fbc6a*/
}

// Address: 0x1067fbc6c | Name: __ZN3RBX7Network10Replicator12PingBackItemD1Ev
void __fastcall RBX::Network::Replicator::PingBackItem::~PingBackItem(RBX::Network::Replicator::PingBackItem *this)
{
  ; /*0x1067fbc6c*/
}

// Address: 0x1067fbc72 | Name: __ZN3RBX7Network10Replicator12PingBackItemD0Ev
void __fastcall RBX::Network::Replicator::PingBackItem::~PingBackItem(RBX::Network::Replicator::PingBackItem *this)
{
  _QWORD *v1; // rcx

  v1 = **((_QWORD ***)this - 1); /*0x1067fbc7e*/
  *((_QWORD *)this - 1) = *v1; /*0x1067fbc84*/
  *v1 = (char *)this - 8; /*0x1067fbc88*/
}

// Address: 0x1067fbc8e | Name: __ZNK3RBX7Network10Replicator12PingBackItem7getTypeEv
__int64 __fastcall RBX::Network::Replicator::PingBackItem::getType(RBX::Network::Replicator::PingBackItem *this)
{
  return 6; /*0x1067fbc97*/
}

// END PingBackItem part 1/1, 7 functions
