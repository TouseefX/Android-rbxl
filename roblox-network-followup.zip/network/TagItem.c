// TagItem -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 9 functions


// Address: 0x106809434 | Name: __ZN3RBX7Network10Replicator7TagItemC2EPS1_NS0_11TagItemTypeENSt3__18functionIFbvEEE
__int64 __fastcall RBX::Network::Replicator::TagItem::TagItem(
        RBX::Network::Item *a1,
        RBX::Network::Replicator *a2,
        int a3,
        __int64 a4)
{
  RBX::Network::Item::Item(this: a1, a2); /*0x106809447*/
  *(_QWORD *)a1 = off_10CAADA38; /*0x106809453*/
  *((_DWORD *)a1 + 16) = a3; /*0x106809456*/
  return std::__function::__value_func<bool ()(void)>::__value_func[abi:ne200100](a1: (char *)a1 + 80, a2: a4); /*0x106809468*/
}

// Address: 0x106809474 | Name: __ZN3RBX7Network10Replicator7TagItemC1EPS1_NS0_11TagItemTypeENSt3__18functionIFbvEEE
__int64 __fastcall RBX::Network::Replicator::TagItem::TagItem(
        RBX::Network::Item *a1,
        RBX::Network::Replicator *a2,
        int a3,
        __int64 a4)
{
  RBX::Network::Item::Item(this: a1, a2); /*0x106809487*/
  *(_QWORD *)a1 = off_10CAADA38; /*0x106809493*/
  *((_DWORD *)a1 + 16) = a3; /*0x106809496*/
  return std::__function::__value_func<bool ()(void)>::__value_func[abi:ne200100](a1: (char *)a1 + 80, a2: a4); /*0x1068094a8*/
}

// Address: 0x1068094b4 | Name: __ZNK3RBX7Network10Replicator7TagItem19shouldAskforReceiptEv
bool __fastcall RBX::Network::Replicator::TagItem::shouldAskforReceipt(RBX::Network::Replicator::TagItem *this)
{
  return *(_BYTE *)(*((_QWORD *)this + 3) + 10391LL) == 0 /*0x1068094dc*/
      && DFFlag::GameLoadDataStatistics == 1
      && *((_DWORD *)this + 16) == 13;
}

// Address: 0x1068094de | Name: __ZNK3RBX7Network10Replicator7TagItem11getSendModeEv
__int64 __fastcall RBX::Network::Replicator::TagItem::getSendMode(RBX::Network::Replicator::TagItem *this)
{
  return 0; /*0x1068094e4*/
}

// Address: 0x1068094e6 | Name: __ZN3RBX7Network10Replicator7TagItem5writeERNS0_13NetworkStreamE
char __fastcall RBX::Network::Replicator::TagItem::write(
        RBX::Network::Replicator::TagItem *this,
        RBX::Network::NetworkStream *a2)
{
  __int64 v4; // rdi
  int v5; // esi
  _QWORD *v6; // rdi
  int v7; // eax
  int v9[5]; // [rsp+Ch] [rbp-14h] BYREF

  v4 = *((_QWORD *)this + 14); /*0x1068094f7*/
  if ( v4 != 0 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v4 + 48LL))(a1: v4) == 0 ) /*0x106809508*/
    return 0; /*0x106809547*/
  v5 = *((_DWORD *)this + 16); /*0x10680950a*/
  v6 = *((_QWORD **)this + 3); /*0x10680950d*/
  if ( v5 != 14 && (v5 != 15 || v6[1815] == 0) ) /*0x106809523*/
  {
    RBX::Network::Item::writeItemType(a1: (__int64)this, a2, a3: 0x10u); /*0x106809530*/
    if ( *(_BYTE *)(*((_QWORD *)this + 3) + 10391LL) == 1 ) /*0x106809540*/
    {
      v7 = *((_DWORD *)this + 16); /*0x106809542*/
    }
    else
    {
      v7 = *((_DWORD *)this + 16); /*0x106809552*/
      if ( ((unsigned __int8)DFFlag::GameLoadDataStatistics & (v7 == 13)) == 1 ) /*0x106809560*/
      {
        *((_BYTE *)this + 40) = 1; /*0x106809562*/
        v7 = 13; /*0x106809566*/
      }
    }
    v9[0] = v7; /*0x10680956f*/
    RBX::Network::NetworkStream::writeBytes(this: a2, a2: v9, a3: 4u); /*0x106809579*/
    v6 = *((_QWORD **)this + 3); /*0x10680957e*/
  }
  (*(void (__fastcall **)(_QWORD *))(*v6 + 1264LL))(a1: v6); /*0x106809588*/
  return 1; /*0x106809590*/
}

// Address: 0x10680959a | Name: __ZNK3RBX7Network10Replicator7TagItem7getTypeEv
__int64 __fastcall RBX::Network::Replicator::TagItem::getType(RBX::Network::Replicator::TagItem *this)
{
  return 16; /*0x1068095a3*/
}

// Address: 0x1068095a6 | Name: __ZN3RBX7Network10Replicator7TagItem4readERS1_RNS0_13NetworkStreamE
RBX::Network::Replicator::TagItem *__fastcall RBX::Network::Replicator::TagItem::read(
        RBX::Network::Replicator::TagItem *this,
        RBX::Network::Replicator *a2,
        RBX::Network::NetworkStream *a3)
{
  __int64 v6; // rbx
  RakNet *v7; // r12
  RBX::TaskScheduler *v8; // rdi
  RakNet *v9; // rdi
  unsigned __int8 v11; // r8
  _QWORD v12[3]; // [rsp+0h] [rbp-90h] BYREF
  __int64 v13; // [rsp+18h] [rbp-78h]
  __int128 v14; // [rsp+20h] [rbp-70h]
  __int128 v15; // [rsp+30h] [rbp-60h]
  __int128 v16; // [rsp+40h] [rbp-50h]
  int v17; // [rsp+50h] [rbp-40h]
  __int128 v18; // [rsp+58h] [rbp-38h]

  v6 = operator new(a1: 0x28u); /*0x1068095c8*/
  *(_QWORD *)(v6 + 8) = &dword_100000010; /*0x1068095d5*/
  *(_DWORD *)(v6 + 16) = 0; /*0x1068095d9*/
  *(_QWORD *)(v6 + 24) = 0; /*0x1068095e0*/
  *(_QWORD *)v6 = off_10CAADA08; /*0x1068095ef*/
  *(_DWORD *)(v6 + 32) = RBX::Network::NetworkStream::readInt32(this: a3); /*0x1068095fa*/
  if ( (_BYTE)`guard variable for'RBX::Network::Replicator::TagItem::read(RBX::Network::Replicator&,RBX::Network::NetworkStream &)::proftoken87 == 0 /*0x1068096e2*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::Replicator::TagItem::read(RBX::Network::Replicator&,RBX::Network::NetworkStream &)::proftoken87) != 0 )
  {
    v12[0] = "xceptionPorts::ExceptionHandlerVector::Deallocate()"; /*0x10680970b*/
    RBX::Network::Replicator::TagItem::read(RBX::Network::Replicator&,RBX::Network::NetworkStream &)::proftoken87 = (RakNet *)RBX::Profiler::getToken(this: (RBX::Profiler *)&aSystemCreateso_0[-268209], a2: &aVoidCrashpadEx[-689308], a3: (const char *)0xFFFFFFFFLL, a4: 255, a5: v11); /*0x10680972f*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::Replicator::TagItem::read(RBX::Network::Replicator&,RBX::Network::NetworkStream &)::proftoken87); /*0x10680973d*/
  }
  v7 = RBX::Network::Replicator::TagItem::read(RBX::Network::Replicator&,RBX::Network::NetworkStream &)::proftoken87; /*0x10680960b*/
  *(_OWORD *)v12 = 0; /*0x10680961c*/
  v13 = -1; /*0x10680961f*/
  v14 = 0; /*0x106809627*/
  v15 = 0; /*0x10680962b*/
  v16 = 0; /*0x10680962f*/
  v17 = 0; /*0x106809633*/
  v18 = 0; /*0x10680963a*/
  v12[2] = RBX::Network::Replicator::TagItem::read(RBX::Network::Replicator&,RBX::Network::NetworkStream &)::proftoken87; /*0x10680963e*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v12); /*0x106809642*/
  v13 = RBX::Profiler::enterRegion(a1: v7, a2: -1, a3: 0); /*0x106809658*/
  if ( *(_DWORD *)(v6 + 32) == 13 ) /*0x106809660*/
  {
    *((_QWORD *)a2 + 1993) = *((_QWORD *)a2 + 2299); /*0x106809669*/
    *((_DWORD *)a2 + 3988) = *((_DWORD *)a2 + 4600); /*0x106809677*/
    *((_QWORD *)a2 + 1995) = RBX::TaskScheduler::cycle(this: v8); /*0x106809683*/
    *((_DWORD *)a2 + 3992) = RakNet::GetTimeMS(this: v9); /*0x10680968f*/
    RBX::Network::TwoWayBandwidthMetrics::onJoin(a1: (char *)a2 + 288, a2: 1); /*0x1068096a2*/
    if ( *(_DWORD *)(v6 + 32) == 13 ) /*0x1068096ab*/
      *((_BYTE *)a2 + 18701) = 1; /*0x1068096ad*/
  }
  *(_QWORD *)this = v6; /*0x1068096b5*/
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v12); /*0x1068096bf*/
  return this; /*0x1068096c7*/
}

// Address: 0x106809790 | Name: __ZN3RBX7Network10Replicator7TagItemD1Ev
void __fastcall RBX::Network::Replicator::TagItem::~TagItem(RBX::Network::Replicator::TagItem *this)
{
  RBX::Network::Replicator::TagItem *v2; // rdi
  __int64 v3; // rax

  *(_QWORD *)this = off_10CAADA38; /*0x10680979e*/
  v2 = *((RBX::Network::Replicator::TagItem **)this + 14); /*0x1068097a1*/
  if ( v2 == (RBX::Network::Replicator::TagItem *)((char *)this + 80) ) /*0x1068097ac*/
  {
    v3 = 32; /*0x1068097ba*/
    goto LABEL_5; /*0x1068097ba*/
  }
  v3 = 40; /*0x1068097ae*/
  if ( v2 != nullptr ) /*0x1068097b6*/
LABEL_5:
    (*(void (**)(void))(*(_QWORD *)v2 + v3))(); /*0x1068097bf*/
}

// Address: 0x1068097c6 | Name: __ZN3RBX7Network10Replicator7TagItemD0Ev
void __fastcall RBX::Network::Replicator::TagItem::~TagItem(RBX::Network::Replicator::TagItem *this)
{
  char *v2; // rax
  char *v3; // rdi
  __int64 v4; // rax

  *(_QWORD *)this = off_10CAADA38; /*0x1068097d6*/
  v2 = (char *)this + 80; /*0x1068097d9*/
  v3 = *((char **)this + 14); /*0x1068097dd*/
  if ( v3 == v2 ) /*0x1068097e4*/
  {
    v4 = 32; /*0x1068097f2*/
  }
  else
  {
    v4 = 40; /*0x1068097e6*/
    if ( v3 == nullptr ) /*0x1068097ee*/
      goto LABEL_6; /*0x1068097ee*/
  }
  (*(void (__fastcall **)(char *))(*(_QWORD *)v3 + v4))(a1: v3); /*0x1068097fa*/
LABEL_6:
  operator delete(a1: this); /*0x1068097fd*/
}

// END TagItem part 1/1, 9 functions
