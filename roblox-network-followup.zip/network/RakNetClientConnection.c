// RakNetClientConnection -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 9 functions


// Address: 0x10672491c | Name: __ZN3RBX7Network22RakNetClientConnectionC2ENS_6PeerIdERN6RakNet16RakPeerInterfaceE
void (__fastcall **__fastcall RBX::Network::RakNetClientConnection::RakNetClientConnection(
        __int64 a1))(RBX::Network::RakNetClientConnection *__hidden this)
{
  RBX::Network::RakNetConnection::RakNetConnection(a1); /*0x106724925*/
  *(_QWORD *)a1 = off_10CAA8FE0; /*0x106724931*/
  *(_OWORD *)(a1 + 1952) = 0; /*0x106724937*/
  *(_OWORD *)(a1 + 1962) = 0; /*0x10672493e*/
  return off_10CAA8FE0; /*0x106724949*/
}

// Address: 0x10672494c | Name: __ZN3RBX7Network22RakNetClientConnectionC1ENS_6PeerIdERN6RakNet16RakPeerInterfaceE
void (__fastcall **__fastcall RBX::Network::RakNetClientConnection::RakNetClientConnection(
        __int64 a1))(RBX::Network::RakNetClientConnection *__hidden this)
{
  RBX::Network::RakNetConnection::RakNetConnection(a1); /*0x106724955*/
  *(_QWORD *)a1 = off_10CAA8FE0; /*0x106724961*/
  *(_OWORD *)(a1 + 1952) = 0; /*0x106724967*/
  *(_OWORD *)(a1 + 1962) = 0; /*0x10672496e*/
  return off_10CAA8FE0; /*0x106724979*/
}

// Address: 0x10672497c | Name: __ZN3RBX7Network22RakNetClientConnectionD2Ev
void __fastcall RBX::Network::RakNetClientConnection::~RakNetClientConnection(RBX::Memory **this, void *a2)
{
  *this = (RBX::Memory *)off_10CAA8FE0; /*0x10672498c*/
  if ( (*(_BYTE *)(this + 244) & 1) != 0 ) /*0x106724996*/
    operator delete(a1: *(this + 246), a2); /*0x10672499f*/
  RBX::NetworkBase::ConnectionInternal::~ConnectionInternal((RBX::NetworkBase::ConnectionInternal *)this); /*0x1067249ad*/
}

// Address: 0x1067249b2 | Name: __ZN3RBX7Network22RakNetClientConnectionD1Ev
void __fastcall RBX::Network::RakNetClientConnection::~RakNetClientConnection(RBX::Memory **this, void *a2)
{
  RBX::Network::RakNetClientConnection::~RakNetClientConnection(this, a2); /*0x1067249b7*/
}

// Address: 0x1067249bc | Name: __ZN3RBX7Network22RakNetClientConnectionD0Ev
void __fastcall RBX::Network::RakNetClientConnection::~RakNetClientConnection(RBX::Memory **this, void *a2)
{
  void *v3; // rsi

  RBX::Network::RakNetClientConnection::~RakNetClientConnection(this, a2); /*0x1067249c5*/
  operator delete(a1: (RBX::Memory *)this, a2: v3); /*0x1067249d3*/
}

// Address: 0x1067249d8 | Name: __ZN3RBX7Network22RakNetClientConnection18initRuppForAddressEbRNS_4Rupp8TokenTlv5TokenERKNS0_14ConnectionInfoE
bool __fastcall RBX::Network::RakNetClientConnection::initRuppForAddress(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  __int64 v6; // rdi
  __int64 v7; // rcx
  unsigned int v8; // ebx
  int v9; // r14d
  int v10; // r15d
  _QWORD v12[3]; // [rsp+10h] [rbp-40h] BYREF
  __int64 v13; // [rsp+28h] [rbp-28h]
  _QWORD *v14; // [rsp+30h] [rbp-20h]

  v6 = *(_QWORD *)(a1 + 1896); /*0x1067249eb*/
  if ( (*(_BYTE *)a4 & 1) != 0 ) /*0x1067249f5*/
    v7 = *(_QWORD *)(a4 + 16); /*0x1067249f7*/
  else
    v7 = a4 + 1; /*0x1067249fd*/
  v8 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, __int64, _QWORD))(*(_QWORD *)v6 + 768LL))( /*0x106724a0f*/
         a1: v6,
         a2,
         a3,
         a4: v7,
         a5: *(unsigned __int16 *)(a4 + 24));
  if ( v8 != 0 )
  {
    v9 = DFLog::Rupp; /*0x106724a1c*/
    if ( (unsigned __int8)DFLog::Rupp >= 6u && (DFLog::Rupp & 0xFE00) != 0 )
    {
      v10 = qword_10D7BB258; /*0x106724a38*/
      v12[0] = RBX::Rupp::RuppError::toString(a1: v8); /*0x106724a47*/
      v13 = 12; /*0x106724a4a*/
      v14 = v12; /*0x106724a52*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: v9,
        a2: v10,
        a3: 2,
        a4: (unsigned int)"[DFLog::Rupp] Client failed Rupp setup: {}",
        a5: 42,
        a6: 1,
        12,
        v12,
        v12[0]);
    }
  }
  else
  {
    *(_BYTE *)(a1 + 1944) = 1; /*0x106724a78*/
    std::string::operator=(a1: a1 + 1952, a2: a4); /*0x106724a8a*/
    *(_WORD *)(a1 + 1976) = *(_WORD *)(a4 + 24); /*0x106724a94*/
    if ( (unsigned __int8)DFLog::Rupp >= 6u && BYTE1(DFLog::Rupp) >= 5u ) /*0x106724ab5*/
    {
      v12[0] = *(unsigned __int8 *)(a1 + 1944); /*0x106724acc*/
      v13 = 1; /*0x106724acf*/
      v14 = v12; /*0x106724ad7*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x106724afb*/
        a1: DFLog::Rupp,
        a2: qword_10D7BB258,
        a3: 5,
        a4: (unsigned int)"[DFLog::Rupp] ruppEnabled is {}",
        a5: 31,
        a6: 1,
        1,
        v12,
        v12[0]);
    }
  }
  return v8 == 0; /*0x106724b05*/
}

// Address: 0x106724b10 | Name: __ZN3RBX7Network22RakNetClientConnection8initRuppEbRNS_4Rupp8TokenTlv5TokenERKNS0_14ConnectionInfoES8_
bool __fastcall RBX::Network::RakNetClientConnection::initRupp(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  bool result; // al
  std::runtime_error *exception; // rbx

  result = RBX::Network::RakNetClientConnection::initRuppForAddress(a1, a2, a3, a4); /*0x106724b17*/
  if ( !result ) /*0x106724b1e*/
  {
    exception = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x18u); /*0x106724b2f*/
    RBX::Network::ConnectionFailureError::ConnectionFailureError( /*0x106724b3e*/
      a1: exception,
      a2: "Failed to start setup client Rupp",
      a3: 0);
    __cxa_throw( /*0x106724b54*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::Network::ConnectionFailureError,
      a3: (void (__fastcall *)(void *))RBX::Network::ConnectionFailureError::~ConnectionFailureError);
  }
  return result; /*0x106724b20*/
}

// Address: 0x106724b76 | Name: __ZN3RBX7Network22RakNetClientConnection5startERKNS_11NetworkBase19ConnectionStartArgsE
void __fastcall RBX::Network::RakNetClientConnection::start(
        RBX::Network::RakNetClientConnection *this,
        const RBX::NetworkBase::ConnectionStartArgs *a2)
{
  bool v4; // al
  const RBX::Network::ConnectionInfo *v5; // rsi
  const char *v6; // rdx
  RakNet::RakPeer *v7; // r12
  RakNet::SocketDescriptor *v8; // r15
  RakNet::SocketDescriptor *v9; // rsi
  unsigned int v10; // eax
  double v11; // xmm0_8
  RakNet::SocketDescriptor *v12; // rcx
  int v13; // eax
  int v14; // eax
  __int64 v15; // rdx
  __int64 v16; // rcx
  RakNet::SocketDescriptor *v17; // rsi
  __int64 v18; // r8
  unsigned __int8 *v19; // rcx
  unsigned int v20; // eax
  RBX::Time *v21; // rdi
  int v22; // r12d
  int v23; // r13d
  __m128i v24; // xmm0
  bool v25; // cl
  RakNet::SocketDescriptor *v26; // rcx
  char *v27; // rax
  RakNet::SocketDescriptor *v28; // rax
  __int64 v29; // rdx
  __int64 v30; // rdx
  __int64 v31; // rcx
  void *v32; // rsi
  __int64 v33; // r8
  __int64 v34; // r9
  __int64 v35; // rdi
  __int64 v36; // rsi
  __int8 *v37; // rax
  __int8 *v38; // rax
  std::runtime_error *exception; // rax
  std::runtime_error *v40; // r14
  const char *v41; // rsi
  std::runtime_error *v42; // rax
  std::runtime_error *v43; // r14
  const char *v44; // rsi
  char v45; // [rsp+20h] [rbp-180h]
  RakNet::SocketDescriptor *v46; // [rsp+30h] [rbp-170h]
  char v47; // [rsp+48h] [rbp-158h]
  RBX::Memory *v48; // [rsp+58h] [rbp-148h]
  char v49; // [rsp+60h] [rbp-140h]
  RBX::Memory *v50; // [rsp+70h] [rbp-130h]
  _QWORD v51[3]; // [rsp+80h] [rbp-120h] BYREF
  RakNet::RakPeer *v52[3]; // [rsp+98h] [rbp-108h] BYREF
  __int128 v53; // [rsp+B0h] [rbp-F0h] BYREF
  RakNet::SocketDescriptor *v54; // [rsp+C0h] [rbp-E0h]
  unsigned int v55; // [rsp+C8h] [rbp-D8h]
  int v56; // [rsp+D0h] [rbp-D0h]
  __int128 v57; // [rsp+D8h] [rbp-C8h]
  void *v58; // [rsp+E8h] [rbp-B8h]
  __int128 v59; // [rsp+F0h] [rbp-B0h]
  void *v60; // [rsp+100h] [rbp-A0h]
  __m256i v61; // [rsp+110h] [rbp-90h] BYREF
  unsigned __int64 v62; // [rsp+130h] [rbp-70h]
  __int64 v63; // [rsp+140h] [rbp-60h]
  __m256i v64[2]; // [rsp+150h] [rbp-50h] BYREF

  if ( !RBX::Network::ConnectionInfo::empty(this: a2) ) /*0x106724b93*/
    RBX::Network::RakNetClientConnection::initRupp( /*0x106724bb1*/
      a1: (__int64)this,
      a2: *((unsigned __int8 *)a2 + 299),
      a3: *((_QWORD *)a2 + 36),
      a4: (__int64)a2 + 88);
  v4 = RBX::Network::ConnectionInfo::empty(this: a2); /*0x106724bb9*/
  v5 = (const RBX::NetworkBase::ConnectionStartArgs *)((char *)a2 + 88); /*0x106724bbe*/
  if ( !v4 ) /*0x106724bc4*/
    v5 = a2; /*0x106724bc4*/
  RBX::Network::ConnectionInfo::ConnectionInfo(this: (RBX::Network::ConnectionInfo *)&v53, a2: v5); /*0x106724bcf*/
  std::vector<RakNet::SocketDescriptor>::vector[abi:ne200100](a1: v52); /*0x106724be0*/
  v7 = v52[0]; /*0x106724be5*/
  v8 = (RakNet::SocketDescriptor *)((char *)&v53 + 1); /*0x106724bec*/
  v9 = (RakNet::SocketDescriptor *)((char *)&v53 + 1); /*0x106724bf8*/
  if ( (v53 & 1) != 0 ) /*0x106724bfb*/
    v9 = v54; /*0x106724bfd*/
  v10 = RakNet::RakPeer::resolveSocketFamily(this: v52[0], a2: v9, a3: v6); /*0x106724c07*/
  if ( v10 != 0 && (unsigned __int8)FLog::Output >= 6u && (FLog::Output & 0xFE00) != 0 )
  {
    v12 = (RakNet::SocketDescriptor *)((char *)&v53 + 1); /*0x106724c3f*/
    if ( (v53 & 1) != 0 ) /*0x106724c42*/
      v12 = v54; /*0x106724c44*/
    v61.i64[0] = (__int64)v12; /*0x106724c5a*/
    v61.i64[2] = v55; /*0x106724c5d*/
    v62 = v10; /*0x106724c61*/
    v64[0].i64[0] = 284; /*0x106724c65*/
    v64[0].i64[1] = (__int64)&v61; /*0x106724c6d*/
    v11 = FLog::detail::FastLogSafeFormattedInternal(
            a1: FLog::Output,
            a2: qword_10D7BE938,
            a3: 2,
            a4: (unsigned int)"[FLog::Output] potentialConnections({}|{}) couldn't be resolved : {}",
            a5: 68,
            a6: 1,
            284,
            &v61);
  }
  *(_WORD *)v7 = *((_WORD *)a2 + 102); /*0x106724c9d*/
  v13 = *((unsigned __int16 *)v7 + 24); /*0x106724ca2*/
  if ( *((_WORD *)v7 + 24) != 0 ) /*0x106724caa*/
  {
    if ( v13 == 30 ) /*0x106724caf*/
    {
      v14 = 0; /*0x106724cbd*/
    }
    else if ( v13 == 2 ) /*0x106724cb4*/
    {
      v14 = 1; /*0x106724cb6*/
    }
    else
    {
      v14 = 3; /*0x106724cc8*/
    }
  }
  else
  {
    v14 = 2; /*0x106724cc1*/
  }
  v56 = v14; /*0x106724ccd*/
  if ( (*(unsigned int (__fastcall **)(_QWORD, __int64, _QWORD, RakNet::RakPeer *, __int64, _QWORD, double, _DWORD, int))(**((_QWORD **)this + 237) + 16LL))( /*0x106724d10*/
         a1: *((_QWORD *)this + 237),
         a2: 1,
         a3: *((_QWORD *)a2 + 26),
         a4: v52[0],
         a5: 1,
         a6: 0,
         a7: v11,
         a8: 0,
         a9: -99999) != 0 )
  {
    if ( *((_DWORD *)a2 + 51) != 0 ) /*0x10672511c*/
    {
      v64[0].i64[0] = *((unsigned int *)a2 + 51); /*0x10672519c*/
      fmt::v8::vformat(a1: &v61, a2: "Failed to start network client on port %d", 41); /*0x1067251b7*/
    }
    else
    {
      std::string::basic_string[abi:ne200100]<0>(a1: &v61, a2: "Failed to start network client", a3: v15, a4: v16); /*0x10672512c*/
    }
    if ( (unsigned __int8)FLog::Output >= 6u && (FLog::Output & 0xFE00) != 0 ) /*0x1067251d3*/
    {
      if ( (v61.i8[0] & 1) != 0 ) /*0x1067251e5*/
        v38 = (__int8 *)v61.i64[2]; /*0x1067251e7*/
      else
        v38 = &v61.i8[1]; /*0x1067251ed*/
      v51[0] = v38; /*0x1067251fb*/
      v64[0].i64[0] = 12; /*0x1067251fe*/
      v64[0].i64[1] = (__int64)v51; /*0x106725206*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x10672522a*/
        a1: FLog::Output,
        a2: qword_10D7BE938,
        a3: 2,
        a4: (unsigned int)"[FLog::Output] {}",
        a5: 17,
        a6: 1,
        12,
        v51);
    }
    exception = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x18u); /*0x106725234*/
    v40 = exception; /*0x106725239*/
    if ( (v61.i8[0] & 1) != 0 ) /*0x106725243*/
      v41 = (const char *)v61.i64[2]; /*0x106725245*/
    else
      v41 = &v61.i8[1]; /*0x10672524b*/
    RBX::Network::ConnectionFailureError::ConnectionFailureError(a1: exception, a2: v41, a3: 2); /*0x10672525a*/
    __cxa_throw( /*0x106725270*/
      a1: v40,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::Network::ConnectionFailureError,
      a3: (void (__fastcall *)(void *))RBX::Network::ConnectionFailureError::~ConnectionFailureError);
  }
  (*(void (__fastcall **)(_QWORD, _QWORD))(**((_QWORD **)this + 237) + 728LL))( /*0x106724d27*/
    a1: *((_QWORD *)this + 237),
    a2: *((unsigned __int8 *)a2 + 297));
  if ( *((_BYTE *)a2 + 298) == 1 && *((_BYTE *)a2 + 297) == 1 ) /*0x106724d3d*/
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)this + 237) + 736LL))(a1: *((_QWORD *)this + 237)); /*0x106724d49*/
  v17 = (RakNet::SocketDescriptor *)((char *)&v53 + 1); /*0x106724d56*/
  if ( (v53 & 1) != 0 ) /*0x106724d59*/
    v17 = v54; /*0x106724d5b*/
  if ( (RBX::Network::versionB[0] & 1) != 0 ) /*0x106724d7f*/
  {
    v18 = *(unsigned int *)&RBX::Network::versionB[8]; /*0x106724d81*/
    v19 = *(unsigned __int8 **)&RBX::Network::versionB[16]; /*0x106724d85*/
  }
  else
  {
    v18 = RBX::Network::versionB[0] >> 1; /*0x106724d8b*/
    v19 = &RBX::Network::versionB[1]; /*0x106724d8e*/
  }
  v20 = (*(__int64 (__fastcall **)(_QWORD, RakNet::SocketDescriptor *, _QWORD, unsigned __int8 *, __int64, _QWORD, _DWORD, int, int, _DWORD))(**((_QWORD **)this + 237) + 112LL))( /*0x106724dc3*/
          a1: *((_QWORD *)this + 237),
          a2: v17,
          a3: (unsigned __int16)v55,
          a4: v19,
          a5: v18,
          a6: 0,
          a7: 0,
          a8: DFInt::SendConnectionAttemptCount,
          a9: DFInt::TimeBetweenSendConnectionAttemptsMS,
          a10: 0);
  if ( v20 != 0 ) /*0x106724dc8*/
  {
    v64[0].i64[0] = v20; /*0x10672513c*/
    fmt::v8::vformat(a1: &v61, a2: "Failed to connect to server, id %d", 34); /*0x106725157*/
    if ( (unsigned __int8)FLog::Output >= 6u && (FLog::Output & 0xFE00) != 0 ) /*0x106725173*/
    {
      if ( (v61.i8[0] & 1) != 0 ) /*0x106725189*/
        v37 = (__int8 *)v61.i64[2]; /*0x10672518f*/
      else
        v37 = &v61.i8[1]; /*0x10672527a*/
      v51[0] = v37; /*0x106725288*/
      v64[0].i64[0] = 12; /*0x10672528b*/
      v64[0].i64[1] = (__int64)v51; /*0x106725293*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x1067252b7*/
        a1: FLog::Output,
        a2: qword_10D7BE938,
        a3: 2,
        a4: (unsigned int)"[FLog::Output] {}",
        a5: 17,
        a6: 1,
        12,
        v51);
    }
    v42 = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x18u); /*0x1067252c1*/
    v43 = v42; /*0x1067252c6*/
    if ( (v61.i8[0] & 1) != 0 ) /*0x1067252d0*/
      v44 = (const char *)v61.i64[2]; /*0x1067252d2*/
    else
      v44 = &v61.i8[1]; /*0x1067252d8*/
    RBX::Network::ConnectionFailureError::ConnectionFailureError(a1: v42, a2: v44, a3: 3); /*0x1067252e7*/
    __cxa_throw( /*0x1067252fd*/
      a1: v43,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::Network::ConnectionFailureError,
      a3: (void (__fastcall *)(void *))RBX::Network::ConnectionFailureError::~ConnectionFailureError);
  }
  v22 = DFLog::NetworkJoin; /*0x106724dd5*/
  if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && (DFLog::NetworkJoin & 0xFC00) != 0 ) /*0x106724de6*/
  {
    v23 = qword_10D7F3E08; /*0x106724ded*/
    RBX::Time::nowFastSec(this: v21); /*0x106724df1*/
    *(float *)v24.i32 = *(double *)v24.i64; /*0x106724df6*/
    v64[0].i64[0] = (unsigned int)_mm_cvtsi128_si32(v24); /*0x106724e02*/
    v61.i64[0] = 9; /*0x106724e05*/
    v61.i64[1] = (__int64)v64; /*0x106724e10*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x106724e40*/
      a1: v22,
      a2: v23,
      a3: 4,
      a4: (unsigned int)"[DFLog::NetworkJoin] playerConnect connecting to server @ {} s",
      a5: 62,
      a6: 1,
      9,
      v64);
  }
  v25 = (unsigned __int8)FLog::Output >= 6u && (FLog::Output & 0xFC00) != 0; /*0x106724e5f*/
  if ( *((_BYTE *)a2 + 296) == 1 ) /*0x106724e68*/
  {
    if ( v25 ) /*0x106724e6c*/
    {
      v26 = (RakNet::SocketDescriptor *)((char *)&v53 + 1); /*0x106724e79*/
      if ( (v53 & 1) != 0 ) /*0x106724e7c*/
        v26 = v54; /*0x106724e7e*/
      if ( (*((_BYTE *)this + 1952) & 1) != 0 ) /*0x106724e91*/
        v27 = *((char **)this + 246); /*0x106724f02*/
      else
        v27 = (char *)this + 1953; /*0x106724e93*/
      v29 = *((unsigned __int16 *)this + 988); /*0x106724f09*/
      v61.i64[0] = (__int64)v26; /*0x106724f1f*/
      v61.i64[2] = v55; /*0x106724f22*/
      v62 = (unsigned __int64)v27; /*0x106724f26*/
      v63 = v29; /*0x106724f2a*/
      v64[0].i64[0] = 11292; /*0x106724f2e*/
      v64[0].i64[1] = (__int64)&v61; /*0x106724f36*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x106724f5a*/
        a1: FLog::Output,
        a2: qword_10D7BE938,
        a3: 4,
        a4: (unsigned int)"[FLog::Output] Connecting to UDMUX server {}:{}, and RCC server {}:{}",
        a5: 69,
        a6: 1,
        11292,
        &v61);
    }
  }
  else if ( v25 ) /*0x106724e9e*/
  {
    v28 = (RakNet::SocketDescriptor *)((char *)&v53 + 1); /*0x106724eaf*/
    if ( (v53 & 1) != 0 ) /*0x106724eb2*/
      v28 = v54; /*0x106724eb4*/
    v61.i64[0] = (__int64)v28; /*0x106724ec8*/
    v61.i64[2] = v55; /*0x106724ecb*/
    v64[0].i64[0] = 28; /*0x106724ecf*/
    v64[0].i64[1] = (__int64)&v61; /*0x106724ed7*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x106724efb*/
      a1: FLog::Output,
      a2: qword_10D7BE938,
      a3: 4,
      a4: (unsigned int)"[FLog::Output] Connecting to {}:{}",
      a5: 34,
      a6: 1,
      28,
      &v61);
  }
  if ( (v53 & 1) != 0 ) /*0x106724f66*/
    v8 = v54; /*0x106724f68*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v64, a2: (const char *)v8, a3: v55); /*0x106724f7d*/
  v61 = v64[0]; /*0x106724f91*/
  RakNet::SystemAddress::operator=(a1: (char *)this + 1912, a2: &v61); /*0x106724f9f*/
  v45 = v53; /*0x106724fb6*/
  v46 = v54; /*0x106724fbd*/
  v53 = 0; /*0x106724fc4*/
  v54 = nullptr; /*0x106724fca*/
  v47 = v57; /*0x106724fd9*/
  v48 = (RBX::Memory *)v58; /*0x106724fe1*/
  v57 = 0; /*0x106724fe5*/
  v58 = nullptr; /*0x106724fe9*/
  v49 = v59; /*0x106724ff1*/
  v50 = (RBX::Memory *)v60; /*0x106724ff9*/
  v59 = 0; /*0x106724ffd*/
  v60 = nullptr; /*0x106725001*/
  RBX::NetworkBase::ConnectionInternal::setConnectionInfo(a1: this); /*0x106725008*/
  if ( (v49 & 1) != 0 ) /*0x106725014*/
    operator delete(a1: v50, a2: v32); /*0x10672501d*/
  if ( (v47 & 1) != 0 ) /*0x106725029*/
    operator delete(a1: v48, a2: v32); /*0x106725032*/
  if ( (v45 & 1) != 0 ) /*0x10672503e*/
    operator delete(a1: v46, a2: v32); /*0x106725047*/
  if ( *((_BYTE *)a2 + 184) == 1 ) /*0x106725053*/
  {
    v35 = *((_QWORD *)this + 237); /*0x106725055*/
    v36 = (unsigned int)(int)(*((double *)a2 + 22) * 1000.0); /*0x10672506c*/
    v61 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x106725078*/
    (*(void (__fastcall **)(__int64, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v35 + 448LL))( /*0x1067250a8*/
      a1: v35,
      a2: v36,
      a3: v30,
      a4: v31,
      a5: v33,
      a6: v34,
      a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
      a8: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
      a9: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
      a10: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3));
  }
  if ( v52[0] != nullptr ) /*0x1067250b4*/
  {
    v52[1] = v52[0]; /*0x1067250b6*/
    operator delete(a1: v52[0], a2: v32); /*0x1067250bd*/
  }
  if ( (v59 & 1) != 0 ) /*0x1067250c9*/
    operator delete(a1: (RBX::Memory *)v60, a2: v32); /*0x1067250d2*/
  if ( (v57 & 1) != 0 ) /*0x1067250de*/
    operator delete(a1: (RBX::Memory *)v58, a2: v32); /*0x1067250e7*/
  if ( (v53 & 1) != 0 ) /*0x1067250f3*/
    operator delete(a1: v54, a2: v32); /*0x1067250fc*/
}

// Address: 0x106725654 | Name: __ZNK3RBX7Network22RakNetClientConnection8isServerEv
__int64 __fastcall RBX::Network::RakNetClientConnection::isServer(RBX::Network::RakNetClientConnection *this)
{
  return 0; /*0x10672565a*/
}

// END RakNetClientConnection part 1/1, 9 functions
