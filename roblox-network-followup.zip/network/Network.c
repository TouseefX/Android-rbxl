// Network -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 257 functions


// Address: 0x100158204 | Name: __ZN3RBX7Network11getFileNameERKNS0_13TreeVizConfigE
__int64 __fastcall RBX::Network::getFileName(__int64 a1, _BYTE *a2)
{
  tm *v4; // rax
  void *v5; // rsi
  int v6; // eax
  const char *v7; // rsi
  const char *v8; // rsi
  void *v9; // rsi
  unsigned __int8 *Integer; // [rsp+8h] [rbp-118h] BYREF
  __int128 v12; // [rsp+10h] [rbp-110h] BYREF
  void *v13; // [rsp+20h] [rbp-100h]
  time_t v14; // [rsp+70h] [rbp-B0h] BYREF
  unsigned __int8 v15[16]; // [rsp+78h] [rbp-A8h] BYREF
  void *v16; // [rsp+88h] [rbp-98h]
  unsigned __int8 v17[16]; // [rsp+90h] [rbp-90h] BYREF
  void *v18; // [rsp+A0h] [rbp-80h]
  _BYTE v19[8]; // [rsp+A8h] [rbp-78h] BYREF
  __int128 v20; // [rsp+B0h] [rbp-70h] BYREF
  void *v21; // [rsp+C0h] [rbp-60h]
  __int128 v22; // [rsp+D0h] [rbp-50h] BYREF
  void *v23; // [rsp+E0h] [rbp-40h]
  char v24[24]; // [rsp+F0h] [rbp-30h] BYREF

  time(a1: &v14); /*0x10015822d*/
  v4 = gmtime(a1: &v14); /*0x100158239*/
  strftime(a1: v24, a2: 0x11u, a3: "%Y%m%dT%H%M%SZ", a4: v4); /*0x100158251*/
  RBX::FileSystem::getUserDirectory(a1: &v12, a2: 1, a3: 0, a4: "TreeViz"); /*0x10015826b*/
  if ( (v12 & 1) != 0 ) /*0x100158277*/
  {
    std::string::__init_copy_ctor_external(a1: &v20, a2: v13, a3: *((_QWORD *)&v12 + 1)); /*0x1001582a3*/
    if ( (v12 & 1) != 0 ) /*0x1001582af*/
      operator delete(a1: (RBX::Memory *)v13, a2: v5); /*0x1001582b8*/
  }
  else
  {
    v21 = v13; /*0x100158280*/
    v20 = v12; /*0x10015828b*/
  }
  v22 = 0; /*0x1001582c0*/
  v23 = nullptr; /*0x1001582c4*/
  v6 = (unsigned __int8)a2[1]; /*0x1001582cc*/
  if ( v6 == 3 ) /*0x1001582d4*/
  {
    v7 = "dot"; /*0x1001582f1*/
  }
  else if ( v6 == 2 ) /*0x1001582d9*/
  {
    v7 = "svg"; /*0x1001582e8*/
  }
  else
  {
    if ( a2[1] != 0 ) /*0x1001582dd*/
      goto LABEL_12; /*0x1001582dd*/
    v7 = "html"; /*0x1001582df*/
  }
  std::string::assign(a1: &v22, a2: v7); /*0x1001582fc*/
LABEL_12:
  v8 = "SpanningTree"; /*0x100158301*/
  if ( *a2 == 0 ) /*0x10015831d*/
    v8 = "DataModel"; /*0x10015831d*/
  std::string::basic_string[abi:ne200100](a1: v15, a2: v8, a3: 3LL * (*a2 != 0) + 9); /*0x100158328*/
  std::string::basic_string[abi:ne200100]( /*0x100158352*/
    a1: v17,
    a2: (char *)dword_108F398C8 + dword_108F398C8[(char)a2[1]],
    a3: *(_QWORD *)&asc_108F398A8[8 * (char)a2[1]]);
  RBX::Random::Random(this: (RBX::Random *)v19, a2: 0xAu); /*0x100158360*/
  Integer = (unsigned __int8 *)RBX::Random::nextInteger(this: (RBX::Random *)v19, a2: 10, a3: 1024); /*0x10015837f*/
  fmt::v8::make_format_args<fmt::v8::basic_format_context<fmt::v8::appender,char>,std::string &,std::string &,std::string &,char (&)[17],long long &,std::string &>( /*0x1001583a7*/
    a1: (unsigned __int8 **)&v12,
    a2: (unsigned __int8 *)&v20,
    a3: v15,
    a4: v17,
    a5: (unsigned __int8 *)v24,
    a6: &Integer,
    a7: (unsigned __int8 *)&v22);
  fmt::v8::vformat(a1, a2: "{}/{}_{}_{}_{}.{}", 17, 13880797, &v12); /*0x1001583c7*/
  if ( (v17[0] & 1) != 0 ) /*0x1001583d3*/
    operator delete(a1: (RBX::Memory *)v18, a2: v9); /*0x1001583d9*/
  if ( (v15[0] & 1) != 0 ) /*0x1001583e5*/
    operator delete(a1: (RBX::Memory *)v16, a2: v9); /*0x1001583ee*/
  if ( (v22 & 1) != 0 ) /*0x1001583f7*/
    operator delete(a1: (RBX::Memory *)v23, a2: v9); /*0x1001583fd*/
  if ( (v20 & 1) != 0 ) /*0x100158406*/
    operator delete(a1: (RBX::Memory *)v21, a2: v9); /*0x10015840c*/
  return a1; /*0x100158424*/
}

// Address: 0x1001584ab | Name: __ZN3RBX7Network13datamodelJsonEPNS_8InstanceERN8nlohmann16json_abi_v3_11_210basic_jsonINSt3__13mapENS6_6vectorENS6_12basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEbxydSC_NS4_14adl_serializerENS8_IhNSC_IhEEEEEERKNS6_8functionIFSE_S2_EEE
__int64 __fastcall RBX::Network::datamodelJson(_anonymous_namespace_ *a1, _BYTE *a2, __int64 a3)
{
  unsigned __int64 v4; // rsi
  __int64 v5; // rax
  __int64 v6; // rdi
  RBX::Instance *v7; // rsi
  int NodeType; // eax
  __int64 v9; // rdx
  unsigned __int64 v10; // rsi
  __int64 v11; // rax
  __int64 v12; // rdx
  __int64 v13; // rcx
  __int64 v14; // rsi
  unsigned __int64 v15; // rsi
  __int64 v16; // rax
  _BYTE *v17; // rdx
  char v18; // al
  __int64 v19; // rax
  __int64 v20; // rsi
  __int64 v21; // rsi
  __int64 i; // rbx
  __int64 j; // rbx
  void *v24; // rsi
  __int64 k; // rbx
  __int64 m; // rbx
  __int64 n; // rbx
  __int64 ii; // rbx
  __int64 **v29; // rax
  volatile signed __int64 *v30; // rcx
  __int64 *v31; // rbx
  __int64 *v32; // r15
  __int64 v33; // rax
  __int64 v34; // rsi
  __int64 v35; // r14
  __int64 v36; // rax
  __int64 v37; // rax
  std::__shared_weak_count *v38; // rbx
  _BYTE v40[8]; // [rsp+0h] [rbp-230h] BYREF
  __int64 v41; // [rsp+8h] [rbp-228h]
  std::__shared_weak_count *v42; // [rsp+10h] [rbp-220h]
  __int64 v43; // [rsp+18h] [rbp-218h]
  __int128 v44; // [rsp+20h] [rbp-210h] BYREF
  void *v45; // [rsp+30h] [rbp-200h]
  __int128 v46; // [rsp+40h] [rbp-1F0h] BYREF
  void *v47; // [rsp+50h] [rbp-1E0h]
  __int128 v48; // [rsp+60h] [rbp-1D0h] BYREF
  void *v49; // [rsp+70h] [rbp-1C0h]
  _BYTE v50[8]; // [rsp+80h] [rbp-1B0h] BYREF
  __int64 v51; // [rsp+88h] [rbp-1A8h]
  _BYTE *v52; // [rsp+90h] [rbp-1A0h]
  _anonymous_namespace_ *v53; // [rsp+98h] [rbp-198h] BYREF
  __int64 v54; // [rsp+A0h] [rbp-190h]
  __int64 v55; // [rsp+A8h] [rbp-188h]
  char v56; // [rsp+B0h] [rbp-180h]
  __int64 v57; // [rsp+B8h] [rbp-178h]
  __int64 v58; // [rsp+C0h] [rbp-170h]
  _BYTE v59[8]; // [rsp+C8h] [rbp-168h] BYREF
  __int64 v60; // [rsp+D0h] [rbp-160h]
  __int64 v61; // [rsp+D8h] [rbp-158h]
  char v62; // [rsp+E0h] [rbp-150h]
  __int64 v63; // [rsp+E8h] [rbp-148h]
  __int64 v64; // [rsp+F0h] [rbp-140h]
  _BYTE v65[8]; // [rsp+F8h] [rbp-138h] BYREF
  __int64 v66; // [rsp+100h] [rbp-130h]
  __int64 v67; // [rsp+108h] [rbp-128h]
  char v68; // [rsp+110h] [rbp-120h]
  __int64 v69; // [rsp+118h] [rbp-118h]
  __int64 v70; // [rsp+120h] [rbp-110h]
  _BYTE v71[8]; // [rsp+128h] [rbp-108h] BYREF
  __int64 v72; // [rsp+130h] [rbp-100h]
  __int64 v73; // [rsp+138h] [rbp-F8h]
  char v74; // [rsp+140h] [rbp-F0h]
  __int64 v75; // [rsp+148h] [rbp-E8h]
  __int64 v76; // [rsp+150h] [rbp-E0h]
  __int64 v77; // [rsp+158h] [rbp-D8h] BYREF
  __int64 v78; // [rsp+160h] [rbp-D0h]
  __int64 v79; // [rsp+168h] [rbp-C8h]
  char v80; // [rsp+170h] [rbp-C0h]
  __int64 v81; // [rsp+178h] [rbp-B8h]
  __int64 v82; // [rsp+180h] [rbp-B0h]
  _BYTE v83[8]; // [rsp+188h] [rbp-A8h] BYREF
  __int64 v84; // [rsp+190h] [rbp-A0h]
  __int64 v85; // [rsp+198h] [rbp-98h]
  _QWORD v86[3]; // [rsp+1A0h] [rbp-90h] BYREF
  _QWORD v87[3]; // [rsp+1B8h] [rbp-78h] BYREF
  _QWORD v88[3]; // [rsp+1D0h] [rbp-60h] BYREF
  _QWORD v89[3]; // [rsp+1E8h] [rbp-48h] BYREF

  v43 = a3; /*0x1001584bf*/
  v52 = a2; /*0x1001584c6*/
  LOBYTE(v77) = 3; /*0x1001584de*/
  v78 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[3]>(a1: "id"); /*0x1001584f1*/
  v79 = 0; /*0x1001584f8*/
  RBX::Guid::toString(this: (RBX::Guid *)&v44); /*0x10015850f*/
  v81 = 0; /*0x100158514*/
  v80 = 3; /*0x10015851f*/
  v5 = operator new(a1: (RBX::Memory *)0x18, a2: v4); /*0x10015852b*/
  *(_QWORD *)(v5 + 16) = v45; /*0x100158537*/
  *(_OWORD *)v5 = v44; /*0x100158542*/
  v44 = 0; /*0x100158548*/
  v45 = nullptr; /*0x100158551*/
  v81 = v5; /*0x10015855f*/
  v82 = 0; /*0x100158563*/
  nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x100158581*/
    a1: v83,
    a2: &v77,
    a3: 2,
    a4: 1,
    a5: 2);
  v85 = 0; /*0x10015858f*/
  v72 = 0; /*0x100158593*/
  v71[0] = 3; /*0x10015859a*/
  v72 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[5]>(a1: "name"); /*0x1001585ad*/
  v73 = 0; /*0x1001585b6*/
  v6 = *((_QWORD *)a1 + 14) + 8LL; /*0x1001585c2*/
  v75 = 0; /*0x1001585c6*/
  v74 = 3; /*0x1001585cd*/
  v75 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,std::string const&>(a1: v6); /*0x1001585e0*/
  v76 = 0; /*0x1001585e4*/
  nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x1001585ff*/
    a1: v86,
    a2: v71,
    a3: 2,
    a4: 1,
    a5: 2);
  v86[2] = 0; /*0x10015860a*/
  v66 = 0; /*0x10015860e*/
  v65[0] = 3; /*0x100158615*/
  v66 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[5]>(a1: "type"); /*0x100158628*/
  v67 = 0; /*0x10015862f*/
  NodeType = `anonymous namespace'::getNodeType(this: a1, a2: v7); /*0x10015863d*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v46, a2: off_10C44FDC0[NodeType], a3: v9, a4: off_10C44FDC0); /*0x100158656*/
  v69 = 0; /*0x10015865b*/
  v68 = 3; /*0x100158666*/
  v11 = operator new(a1: (RBX::Memory *)0x18, a2: v10); /*0x100158672*/
  *(_QWORD *)(v11 + 16) = v47; /*0x10015867e*/
  *(_OWORD *)v11 = v46; /*0x100158689*/
  v46 = 0; /*0x10015868f*/
  v47 = nullptr; /*0x100158698*/
  v69 = v11; /*0x1001586a6*/
  v70 = 0; /*0x1001586aa*/
  nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x1001586c1*/
    a1: v87,
    a2: v65,
    a3: 2,
    a4: 1,
    a5: 2);
  v87[2] = 0; /*0x1001586cc*/
  v60 = 0; /*0x1001586d0*/
  v59[0] = 3; /*0x1001586d7*/
  v60 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[6]>(a1: "label"); /*0x1001586ea*/
  v61 = 0; /*0x1001586f1*/
  v14 = *(_QWORD *)(v43 + 32); /*0x100158703*/
  if ( v14 != 0 ) /*0x10015870a*/
  {
    v53 = a1; /*0x100158713*/
    (*(void (__fastcall **)(__int128 *))(*(_QWORD *)v14 + 48LL))(a1: &v48); /*0x100158720*/
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v48, a2: "", a3: v12, a4: v13); /*0x100158733*/
  }
  v63 = 0; /*0x100158738*/
  v62 = 3; /*0x100158743*/
  v16 = operator new(a1: (RBX::Memory *)0x18, a2: v15); /*0x10015874f*/
  *(_QWORD *)(v16 + 16) = v49; /*0x10015875b*/
  *(_OWORD *)v16 = v48; /*0x100158766*/
  v48 = 0; /*0x10015876c*/
  v49 = nullptr; /*0x100158775*/
  v63 = v16; /*0x100158783*/
  v64 = 0; /*0x100158787*/
  nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x10015879e*/
    a1: v88,
    a2: v59,
    a3: 2,
    a4: 1,
    a5: 2);
  v88[2] = 0; /*0x1001587a9*/
  v54 = 0; /*0x1001587ad*/
  LOBYTE(v53) = 3; /*0x1001587b4*/
  v54 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[9]>(a1: "children"); /*0x1001587c7*/
  v55 = 0; /*0x1001587ce*/
  nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x1001587ec*/
    a1: v50,
    a2: 0,
    a3: 0,
    a4: 0,
    a5: 2);
  v56 = v50[0]; /*0x1001587fe*/
  v57 = v51; /*0x100158808*/
  v50[0] = 0; /*0x10015880c*/
  v51 = 0; /*0x100158815*/
  v58 = 0; /*0x10015881c*/
  nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x100158833*/
    a1: v89,
    a2: &v53,
    a3: 2,
    a4: 1,
    a5: 2);
  v89[2] = 0; /*0x10015883f*/
  nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x10015885e*/
    a1: v40,
    a2: v83,
    a3: 5,
    a4: 1,
    a5: 2);
  v17 = v52; /*0x100158863*/
  v18 = *v52; /*0x10015886a*/
  *v52 = v40[0]; /*0x100158875*/
  v40[0] = v18; /*0x100158877*/
  v19 = *((_QWORD *)v17 + 1); /*0x100158879*/
  *((_QWORD *)v17 + 1) = v41; /*0x100158881*/
  v41 = v19; /*0x100158885*/
  nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x100158889*/
    a1: v40,
    a2: v20);
  for ( i = 96; i != -24; i -= 24 ) /*0x10015888e*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x10015889e*/
      a1: &v83[i],
      a2: v21);
  for ( j = 24; j != -24; j -= 24 ) /*0x1001588ad*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x1001588bd*/
      a1: (char *)&v53 + j,
      a2: v21);
  nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x1001588d3*/
    a1: v50,
    a2: v21);
  for ( k = 24; k != -24; k -= 24 ) /*0x1001588d8*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x1001588e8*/
      a1: &v59[k],
      a2: v24);
  if ( (v48 & 1) != 0 ) /*0x1001588fe*/
    operator delete(a1: (RBX::Memory *)v49, a2: v24); /*0x100158907*/
  for ( m = 24; m != -24; m -= 24 ) /*0x10015890c*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x10015891c*/
      a1: &v65[m],
      a2: v24);
  if ( (v46 & 1) != 0 ) /*0x100158932*/
    operator delete(a1: (RBX::Memory *)v47, a2: v24); /*0x10015893b*/
  for ( n = 24; n != -24; n -= 24 ) /*0x100158940*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x100158950*/
      a1: &v71[n],
      a2: v24);
  for ( ii = 24; ii != -24; ii -= 24 ) /*0x10015895f*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x10015896f*/
      a1: (char *)&v77 + ii,
      a2: v24);
  if ( (v44 & 1) != 0 ) /*0x100158985*/
    operator delete(a1: (RBX::Memory *)v45, a2: v24); /*0x10015898e*/
  v29 = *((__int64 ***)a1 + 15); /*0x100158993*/
  if ( v29 != nullptr ) /*0x10015899b*/
  {
    v77 = *((_QWORD *)a1 + 15); /*0x1001589a1*/
    v30 = *((volatile signed __int64 **)a1 + 16); /*0x1001589a8*/
    v78 = (__int64)v30; /*0x1001589b0*/
    if ( v30 != nullptr ) /*0x1001589ba*/
      _InterlockedIncrement64(v30 + 1); /*0x1001589bc*/
    v42 = (std::__shared_weak_count *)v30; /*0x1001589c1*/
    v31 = *v29; /*0x1001589c8*/
    v32 = v29[1]; /*0x1001589cb*/
    if ( *v29 != v32 ) /*0x1001589d2*/
    {
      do /*0x100158a49*/
      {
        v33 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::operator[]<char const>( /*0x1001589ec*/
                a1: v52,
                a2: "children");
        v83[0] = 0; /*0x1001589f1*/
        v84 = 0; /*0x1001589f8*/
        nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::push_back( /*0x100158a09*/
          a1: v33,
          a2: v83);
        nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x100158a11*/
          a1: v83,
          a2: v34);
        v35 = *v31; /*0x100158a16*/
        v36 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::operator[]<char const>( /*0x100158a23*/
                a1: v52,
                a2: "children");
        v37 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::back(a1: v36); /*0x100158a2b*/
        RBX::Network::datamodelJson(a1: v35, a2: v37, a3: v43); /*0x100158a3d*/
        v31 += 2; /*0x100158a42*/
      }
      while ( v31 != v32 ); /*0x100158a49*/
    }
    v38 = v42; /*0x100158a4b*/
    if ( v42 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v42 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x100158a67*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v38 + 16LL))(a1: v38); /*0x100158a6f*/
      std::__shared_weak_count::__release_weak(this: v38); /*0x100158a75*/
    }
  }
  return __stack_chk_guard; /*0x100158a8a*/
}

// Address: 0x100158dc1 | Name: __ZN3RBX7Network12spanningJsonEPNS_8BasePartERN8nlohmann16json_abi_v3_11_210basic_jsonINSt3__13mapENS6_6vectorENS6_12basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEbxydSC_NS4_14adl_serializerENS8_IhNSC_IhEEEEEERNS_17SmallSplitHashMapISE_PSI_Lj0ELNS_15SplitHashPolicyE10ENS_7details11DefaultHashISE_EENSN_14DefaultEqualToISE_EEEERKNS6_8functionIFSE_PNS_8InstanceEEEE
__int64 __fastcall RBX::Network::spanningJson(_QWORD *a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v5; // rax
  void *v6; // rsi
  int v7; // edx
  bool v8; // r14
  RBX::Primitive *v9; // rax
  __int64 v10; // rax
  RBX::BasePart *v11; // rdi
  __int64 v12; // r13
  __int64 v13; // rax
  void *v14; // rsi
  int v15; // edx
  bool v16; // r14
  void *v17; // rsi
  __int64 v18; // r13
  unsigned __int64 v19; // rsi
  __int64 v20; // rax
  __int64 v21; // rdi
  RBX::Instance *v22; // rsi
  int NodeType; // eax
  __int64 v24; // rdx
  unsigned __int64 v25; // rsi
  __int64 v26; // rax
  __int64 v27; // rdx
  __int64 v28; // rcx
  __int64 v29; // rsi
  unsigned __int64 v30; // rsi
  __int64 v31; // rax
  unsigned __int8 Anchored; // al
  char *v33; // rcx
  char *v34; // rax
  const RBX::Primitive *v35; // rsi
  __int64 ConstRootMovingPrimitive; // rax
  __int64 v37; // rsi
  __int64 i; // rbx
  __int64 j; // rbx
  void *v40; // rsi
  __int64 k; // rbx
  __int64 m; // rbx
  __int64 n; // rbx
  __int64 ii; // rbx
  __int64 jj; // rbx
  __int64 kk; // rbx
  __int64 mm; // rbx
  __int64 v48; // rax
  __int64 v49; // rbx
  void *v50; // rsi
  unsigned __int8 *v51; // rax
  int v52; // edx
  __int64 v53; // r14
  __int64 v54; // rax
  void *v55; // rsi
  RBX::Primitive *v57; // [rsp+8h] [rbp-308h]
  __int128 v59; // [rsp+20h] [rbp-2F0h] BYREF
  void *v60; // [rsp+30h] [rbp-2E0h]
  __int128 v61; // [rsp+40h] [rbp-2D0h] BYREF
  void *v62; // [rsp+50h] [rbp-2C0h]
  __int128 v63; // [rsp+60h] [rbp-2B0h] BYREF
  void *v64; // [rsp+70h] [rbp-2A0h]
  char v65[8]; // [rsp+80h] [rbp-290h] BYREF
  __int64 v66; // [rsp+88h] [rbp-288h]
  __int64 v67; // [rsp+90h] [rbp-280h]
  __int64 v68; // [rsp+98h] [rbp-278h]
  _BYTE v69[8]; // [rsp+A0h] [rbp-270h] BYREF
  __int64 v70; // [rsp+A8h] [rbp-268h]
  __int64 v71; // [rsp+B0h] [rbp-260h]
  char v72; // [rsp+B8h] [rbp-258h]
  __int64 v73; // [rsp+C0h] [rbp-250h]
  __int64 v74; // [rsp+C8h] [rbp-248h]
  _BYTE v75[8]; // [rsp+D0h] [rbp-240h] BYREF
  __int64 v76; // [rsp+D8h] [rbp-238h]
  __int64 v77; // [rsp+E0h] [rbp-230h]
  _QWORD v78[3]; // [rsp+E8h] [rbp-228h] BYREF
  _BYTE v79[8]; // [rsp+100h] [rbp-210h] BYREF
  __int64 v80; // [rsp+108h] [rbp-208h]
  __int64 v81; // [rsp+110h] [rbp-200h]
  _QWORD v82[3]; // [rsp+118h] [rbp-1F8h] BYREF
  _QWORD *v83; // [rsp+130h] [rbp-1E0h] BYREF
  __int64 v84; // [rsp+138h] [rbp-1D8h]
  __int64 v85; // [rsp+140h] [rbp-1D0h]
  _QWORD v86[3]; // [rsp+148h] [rbp-1C8h] BYREF
  _BYTE v87[8]; // [rsp+160h] [rbp-1B0h] BYREF
  __int64 v88; // [rsp+168h] [rbp-1A8h]
  __int64 v89; // [rsp+170h] [rbp-1A0h]
  char v90; // [rsp+178h] [rbp-198h]
  __int64 v91; // [rsp+180h] [rbp-190h]
  __int64 v92; // [rsp+188h] [rbp-188h]
  _BYTE v93[8]; // [rsp+190h] [rbp-180h] BYREF
  __int64 v94; // [rsp+198h] [rbp-178h]
  __int64 v95; // [rsp+1A0h] [rbp-170h]
  char v96; // [rsp+1A8h] [rbp-168h]
  __int64 v97; // [rsp+1B0h] [rbp-160h]
  __int64 v98; // [rsp+1B8h] [rbp-158h]
  _BYTE v99[8]; // [rsp+1C0h] [rbp-150h] BYREF
  __int64 v100; // [rsp+1C8h] [rbp-148h]
  void *v101; // [rsp+1D0h] [rbp-140h]
  char v102; // [rsp+1D8h] [rbp-138h]
  __int64 v103; // [rsp+1E0h] [rbp-130h]
  __int64 v104; // [rsp+1E8h] [rbp-128h]
  unsigned __int8 *v105; // [rsp+1F0h] [rbp-120h] BYREF
  __int128 v106; // [rsp+1F8h] [rbp-118h]
  unsigned __int64 v107; // [rsp+208h] [rbp-108h]
  __int64 v108; // [rsp+210h] [rbp-100h]
  __int64 v109; // [rsp+218h] [rbp-F8h]
  unsigned __int8 *v110; // [rsp+220h] [rbp-F0h] BYREF
  __int128 v111; // [rsp+228h] [rbp-E8h]
  _QWORD v112[3]; // [rsp+238h] [rbp-D8h] BYREF
  _QWORD v113[3]; // [rsp+250h] [rbp-C0h] BYREF
  _QWORD v114[3]; // [rsp+268h] [rbp-A8h] BYREF
  _QWORD v115[3]; // [rsp+280h] [rbp-90h] BYREF
  _QWORD v116[3]; // [rsp+298h] [rbp-78h] BYREF
  _QWORD v117[3]; // [rsp+2B0h] [rbp-60h] BYREF
  _QWORD v118[3]; // [rsp+2C8h] [rbp-48h] BYREF

  v68 = a3; /*0x100158ddc*/
  v67 = a2; /*0x100158de3*/
  RBX::Guid::toString(this: (RBX::Guid *)&v110); /*0x100158e0d*/
  v5 = RBX::details::SplitHashTable<std::string,std::pair<std::string,nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> *>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> *>>::find_as<std::string>( /*0x100158e23*/
         a1: v68,
         a2: &v110);
  v8 = v5 != 0 || v7 != 0; /*0x100158e34*/
  if ( ((unsigned __int8)v110 & 1) != 0 ) /*0x100158e3e*/
    operator delete(a1: *((RBX::Memory **)&v111 + 1), a2: v6); /*0x100158e47*/
  if ( !v8 ) /*0x100158e4f*/
  {
    if ( a1 != nullptr ) /*0x100158e58*/
      v9 = (RBX::Primitive *)a1[47]; /*0x100158e5a*/
    else
      v9 = nullptr; /*0x100158e63*/
    v57 = v9; /*0x100158e65*/
    v10 = *((_QWORD *)v9 + 3); /*0x100158e6c*/
    v11 = (RBX::BasePart *)(v10 - 16); /*0x100158e70*/
    if ( v10 == 0 ) /*0x100158e77*/
      v11 = nullptr; /*0x100158e77*/
    v12 = RBX::BasePart::fromPrimitive(this: v11, a2: (RBX::Primitive *)v6); /*0x100158e80*/
    if ( v12 != 0 ) /*0x100158e86*/
    {
      RBX::Guid::toString(this: (RBX::Guid *)&v110); /*0x100158e9a*/
      v13 = RBX::details::SplitHashTable<std::string,std::pair<std::string,nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> *>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> *>>::find_as<std::string>( /*0x100158ead*/
              a1: v68,
              a2: &v110);
      v16 = v13 == 0 && v15 == 0; /*0x100158ebe*/
      if ( ((unsigned __int8)v110 & 1) != 0 ) /*0x100158ec8*/
        operator delete(a1: *((RBX::Memory **)&v111 + 1), a2: v14); /*0x100158ed1*/
      if ( v16 ) /*0x100158ed9*/
        RBX::Network::spanningJson(a1: v12, a2: v67, a3: v68, a4); /*0x100158ef3*/
      RBX::Guid::toString(this: (RBX::Guid *)&v110); /*0x100158f02*/
      v67 = *(_QWORD *)RBX::SmallSplitHashMap<std::string,nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> *,0u,(RBX::SplitHashPolicy)10,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>>::operator[]( /*0x100158f1d*/
                         a1: v68,
                         a2: (__int64)&v110);
      if ( ((unsigned __int8)v110 & 1) != 0 ) /*0x100158f2b*/
        operator delete(a1: *((RBX::Memory **)&v111 + 1), a2: v17); /*0x100158f34*/
    }
    v18 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::operator[]<char const>( /*0x100158f4c*/
            a1: v67,
            a2: "children");
    LOBYTE(v105) = 3; /*0x100158f5a*/
    v106 = (unsigned __int64)nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[3]>(a1: "id"); /*0x100158f6d*/
    RBX::Guid::toString(this: (RBX::Guid *)&v59); /*0x100158f8d*/
    v108 = 0; /*0x100158f99*/
    LOBYTE(v107) = 3; /*0x100158fa4*/
    v20 = operator new(a1: (RBX::Memory *)0x18, a2: v19); /*0x100158fb0*/
    *(_QWORD *)(v20 + 16) = v60; /*0x100158fbc*/
    *(_OWORD *)v20 = v59; /*0x100158fc7*/
    v59 = 0; /*0x100158fcd*/
    v60 = nullptr; /*0x100158fd6*/
    v108 = v20; /*0x100158fe4*/
    v109 = 0; /*0x100158fe8*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x100158fff*/
      a1: &v110,
      a2: &v105,
      a3: 2,
      a4: 1,
      a5: 2);
    *((_QWORD *)&v111 + 1) = 0; /*0x10015900d*/
    v100 = 0; /*0x100159011*/
    v99[0] = 3; /*0x100159018*/
    v100 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[5]>(a1: "name"); /*0x10015902b*/
    v101 = nullptr; /*0x100159034*/
    v21 = a1[14] + 8LL; /*0x10015903f*/
    v103 = 0; /*0x100159043*/
    v102 = 3; /*0x10015904a*/
    v103 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,std::string const&>(a1: v21); /*0x10015905d*/
    v104 = 0; /*0x100159061*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x10015907c*/
      a1: v112,
      a2: v99,
      a3: 2,
      a4: 1,
      a5: 2);
    v112[2] = 0; /*0x10015908a*/
    v94 = 0; /*0x10015908e*/
    v93[0] = 3; /*0x100159095*/
    v94 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[5]>(a1: "type"); /*0x1001590a8*/
    v95 = 0; /*0x1001590af*/
    NodeType = `anonymous namespace'::getNodeType(this: (_anonymous_namespace_ *)a1, a2: v22); /*0x1001590bd*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v61, a2: off_10C44FDC0[NodeType], a3: v24, a4: off_10C44FDC0); /*0x1001590d6*/
    v97 = 0; /*0x1001590db*/
    v96 = 3; /*0x1001590e6*/
    v26 = operator new(a1: (RBX::Memory *)0x18, a2: v25); /*0x1001590f2*/
    *(_QWORD *)(v26 + 16) = v62; /*0x1001590fe*/
    *(_OWORD *)v26 = v61; /*0x100159109*/
    v61 = 0; /*0x10015910f*/
    v62 = nullptr; /*0x100159118*/
    v97 = v26; /*0x100159126*/
    v98 = 0; /*0x10015912a*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x100159141*/
      a1: v113,
      a2: v93,
      a3: 2,
      a4: 1,
      a5: 2);
    v113[2] = 0; /*0x10015914f*/
    v88 = 0; /*0x100159153*/
    v87[0] = 3; /*0x10015915a*/
    v88 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[6]>(a1: "label"); /*0x10015916d*/
    v89 = 0; /*0x100159174*/
    v29 = *(_QWORD *)(a4 + 32); /*0x100159186*/
    if ( v29 != 0 ) /*0x10015918d*/
    {
      v83 = a1; /*0x100159196*/
      (*(void (__fastcall **)(__int128 *))(*(_QWORD *)v29 + 48LL))(a1: &v63); /*0x1001591a3*/
    }
    else
    {
      std::string::basic_string[abi:ne200100]<0>(a1: &v63, a2: "", a3: v27, a4: v28); /*0x1001591b6*/
    }
    v91 = 0; /*0x1001591bb*/
    v90 = 3; /*0x1001591c6*/
    v31 = operator new(a1: (RBX::Memory *)0x18, a2: v30); /*0x1001591d2*/
    *(_QWORD *)(v31 + 16) = v64; /*0x1001591de*/
    *(_OWORD *)v31 = v63; /*0x1001591e9*/
    v63 = 0; /*0x1001591ef*/
    v64 = nullptr; /*0x1001591f8*/
    v91 = v31; /*0x100159206*/
    v92 = 0; /*0x10015920a*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x100159221*/
      a1: v114,
      a2: v87,
      a3: 2,
      a4: 1,
      a5: 2);
    v114[2] = 0; /*0x10015922f*/
    v84 = 0; /*0x100159233*/
    LOBYTE(v83) = 3; /*0x10015923a*/
    v84 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[11]>(a1: "isAnchored"); /*0x10015924d*/
    v85 = 0; /*0x100159254*/
    Anchored = RBX::BasePartProp::getAnchored(this: (RBX::BasePartProp *)(a1 + 23)); /*0x100159269*/
    LOBYTE(v86[0]) = 0; /*0x100159275*/
    v86[1] = 0; /*0x10015927c*/
    nlohmann::json_abi_v3_11_2::detail::external_constructor<(nlohmann::json_abi_v3_11_2::detail::value_t)4>::construct<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>>( /*0x100159286*/
      a1: v86,
      a2: Anchored);
    v86[2] = 0; /*0x10015928b*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x1001592a9*/
      a1: v115,
      a2: &v83,
      a3: 2,
      a4: 1,
      a5: 2);
    v115[2] = 0; /*0x1001592b4*/
    v80 = 0; /*0x1001592b8*/
    v79[0] = 3; /*0x1001592bf*/
    v80 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[7]>(a1: "isRoot"); /*0x1001592d2*/
    v81 = 0; /*0x1001592d9*/
    v33 = (char *)v57 + 16; /*0x1001592e4*/
    do /*0x1001592f3*/
    {
      v34 = v33; /*0x1001592e9*/
      v33 = *((char **)v33 + 1); /*0x1001592ec*/
    }
    while ( v33 != nullptr ); /*0x1001592f3*/
    LOBYTE(v82[0]) = 0; /*0x100159309*/
    v82[1] = 0; /*0x100159310*/
    nlohmann::json_abi_v3_11_2::detail::external_constructor<(nlohmann::json_abi_v3_11_2::detail::value_t)4>::construct<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>>( /*0x100159317*/
      a1: v82,
      a2: v34 - 16 == (char *)v57);
    v82[2] = 0; /*0x10015931c*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x10015933a*/
      a1: v116,
      a2: v79,
      a3: 2,
      a4: 1,
      a5: 2);
    v116[2] = 0; /*0x100159345*/
    v76 = 0; /*0x100159349*/
    v75[0] = 3; /*0x100159350*/
    v76 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[22]>(a1: "isRootMovingPrimitive"); /*0x100159363*/
    v77 = 0; /*0x10015936a*/
    ConstRootMovingPrimitive = RBX::Primitive::getConstRootMovingPrimitive(this: v57, a2: v35); /*0x100159378*/
    LOBYTE(v78[0]) = 0; /*0x10015938d*/
    v78[1] = 0; /*0x100159394*/
    nlohmann::json_abi_v3_11_2::detail::external_constructor<(nlohmann::json_abi_v3_11_2::detail::value_t)4>::construct<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>>( /*0x10015939b*/
      a1: v78,
      a2: ConstRootMovingPrimitive == (_QWORD)v57);
    v78[2] = 0; /*0x1001593a0*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x1001593be*/
      a1: v117,
      a2: v75,
      a3: 2,
      a4: 1,
      a5: 2);
    v117[2] = 0; /*0x1001593c9*/
    v70 = 0; /*0x1001593cd*/
    v69[0] = 3; /*0x1001593d4*/
    v70 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[9]>(a1: "children"); /*0x1001593e7*/
    v71 = 0; /*0x1001593ee*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x10015940c*/
      a1: v65,
      a2: 0,
      a3: 0,
      a4: 0,
      a5: 2);
    v72 = v65[0]; /*0x10015941e*/
    v73 = v66; /*0x100159428*/
    v65[0] = 0; /*0x10015942c*/
    v66 = 0; /*0x100159435*/
    v74 = 0; /*0x10015943c*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x100159453*/
      a1: v118,
      a2: v69,
      a3: 2,
      a4: 1,
      a5: 2);
    v118[2] = 0; /*0x10015945f*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::push_back( /*0x100159472*/
      a1: v18,
      a2: &v110,
      a3: 8);
    for ( i = 21; i != -3; i -= 3 ) /*0x100159477*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x100159487*/
        a1: &(&v110)[i],
        a2: v37);
    for ( j = 24; j != -24; j -= 24 ) /*0x100159496*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x1001594a6*/
        a1: &v69[j],
        a2: v37);
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x1001594bc*/
      a1: v65,
      a2: v37);
    for ( k = 24; k != -24; k -= 24 ) /*0x1001594c1*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x1001594d1*/
        a1: &v75[k],
        a2: v40);
    for ( m = 24; m != -24; m -= 24 ) /*0x1001594e0*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x1001594f0*/
        a1: &v79[m],
        a2: v40);
    for ( n = 3; n != -3; n -= 3 ) /*0x1001594ff*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x10015950f*/
        a1: &(&v83)[n],
        a2: v40);
    for ( ii = 24; ii != -24; ii -= 24 ) /*0x10015951e*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x10015952e*/
        a1: &v87[ii],
        a2: v40);
    if ( (v63 & 1) != 0 ) /*0x100159544*/
      operator delete(a1: (RBX::Memory *)v64, a2: v40); /*0x10015954d*/
    for ( jj = 24; jj != -24; jj -= 24 ) /*0x100159552*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x100159562*/
        a1: &v93[jj],
        a2: v40);
    if ( (v61 & 1) != 0 ) /*0x100159578*/
      operator delete(a1: (RBX::Memory *)v62, a2: v40); /*0x100159581*/
    for ( kk = 24; kk != -24; kk -= 24 ) /*0x100159586*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x100159596*/
        a1: &v99[kk],
        a2: v40);
    for ( mm = 3; mm != -3; mm -= 3 ) /*0x1001595a5*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x1001595b5*/
        a1: &(&v105)[mm],
        a2: v40);
    if ( (v59 & 1) != 0 ) /*0x1001595cb*/
      operator delete(a1: (RBX::Memory *)v60, a2: v40); /*0x1001595d4*/
    v48 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::operator[]<char const>( /*0x1001595e7*/
            a1: v67,
            a2: "children");
    v49 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::back(a1: v48); /*0x1001595f4*/
    RBX::Guid::toString(this: (RBX::Guid *)&v110); /*0x100159605*/
    *(_QWORD *)RBX::SmallSplitHashMap<std::string,nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> *,0u,(RBX::SplitHashPolicy)10,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>>::operator[]( /*0x10015961d*/
                 a1: v68,
                 a2: (__int64)&v110) = v49;
    if ( ((unsigned __int8)v110 & 1) != 0 ) /*0x100159627*/
      operator delete(a1: *((RBX::Memory **)&v111 + 1), a2: v50); /*0x100159630*/
    v51 = (unsigned __int8 *)nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::operator[]<char const>( /*0x100159643*/
                               a1: v67,
                               a2: "children");
    v110 = v51; /*0x100159652*/
    v111 = 0; /*0x10015965c*/
    v112[0] = 0x8000000000000000LL; /*0x100159663*/
    v52 = *v51; /*0x10015966a*/
    if ( *v51 != 0 ) /*0x10015966f*/
    {
      if ( v52 == 2 ) /*0x100159674*/
      {
        *((_QWORD *)&v111 + 1) = **((_QWORD **)v51 + 1); /*0x1001596ba*/
        v105 = v51; /*0x1001596c1*/
        *(_QWORD *)&v106 = 0; /*0x1001596c8*/
        v107 = 0x8000000000000000LL; /*0x1001596d3*/
        *((_QWORD *)&v106 + 1) = *(_QWORD *)(*((_QWORD *)v51 + 1) + 8LL); /*0x1001596e2*/
        goto LABEL_55; /*0x1001596e9*/
      }
      if ( v52 == 1 ) /*0x100159679*/
      {
        *(_QWORD *)&v111 = **((_QWORD **)v51 + 1); /*0x100159682*/
        v105 = v51; /*0x100159689*/
        v107 = 0x8000000000000000LL; /*0x10015969b*/
        v106 = (unsigned __int64)(*((_QWORD *)v51 + 1) + 8LL); /*0x1001596aa*/
        goto LABEL_55; /*0x1001596b1*/
      }
      v112[0] = 0; /*0x1001596f8*/
    }
    else
    {
      v112[0] = 1; /*0x1001596eb*/
    }
    v105 = v51; /*0x100159703*/
    v106 = 0; /*0x10015970a*/
    v107 = 1; /*0x100159711*/
LABEL_55:
    while ( (unsigned __int8)nlohmann::json_abi_v3_11_2::detail::iter_impl<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>>::operator==<nlohmann::json_abi_v3_11_2::detail::iter_impl<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>>,(decltype(nullptr))0>( /*0x100159731*/
                               a1: &v110,
                               a2: &v105) == 0 )
    {
      v53 = nlohmann::json_abi_v3_11_2::detail::iter_impl<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>>::operator*(a1: &v110); /*0x100159757*/
      v54 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::at<char const(&)[3],0>( /*0x100159760*/
              a1: v53,
              a2: "id");
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::get_impl<std::string,0>( /*0x10015976b*/
        a1: v99,
        a2: v54);
      *(_QWORD *)RBX::SmallSplitHashMap<std::string,nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> *,0u,(RBX::SplitHashPolicy)10,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>>::operator[]( /*0x10015977f*/
                   a1: v68,
                   a2: (__int64)v99) = v53;
      if ( (v99[0] & 1) != 0 ) /*0x100159789*/
        operator delete(a1: (RBX::Memory *)v101, a2: v55); /*0x100159792*/
      nlohmann::json_abi_v3_11_2::detail::iter_impl<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>>::operator++(a1: &v110); /*0x10015979a*/
    }
  }
  return __stack_chk_guard; /*0x1001597be*/
}

// Address: 0x100159fa8 | Name: __ZN3RBX7Network11consoleTreeERKN8nlohmann16json_abi_v3_11_210basic_jsonINSt3__13mapENS4_6vectorENS4_12basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEbxydSA_NS2_14adl_serializerENS6_IhNSA_IhEEEEEERKNS0_13TreeVizConfigEiSC_b
__int64 __fastcall RBX::Network::consoleTree(__int64 a1, char *a2, __int64 a3, unsigned __int8 *a4, char a5)
{
  unsigned __int8 *v6; // r15
  char v7; // bl
  const char *v8; // rsi
  __int64 v9; // rsi
  const char *v10; // rcx
  _BYTE *v11; // rsi
  __int64 v12; // rdx
  void *v13; // rsi
  __int64 v14; // rax
  const char *v15; // r13
  __int64 v16; // rax
  __int64 v17; // rax
  void *v18; // rsi
  char v19; // bl
  char v20; // r14
  void *v21; // r15
  unsigned __int8 *v22; // rax
  char *v23; // rdx
  char **v24; // rcx
  signed int *v25; // rbx
  const char *v26; // rax
  char v27; // r14
  unsigned int v28; // edx
  unsigned __int8 *v29; // rsi
  __int64 v30; // rdx
  char *v31; // rsi
  __int64 v32; // rdx
  __int64 v33; // rax
  const char *v34; // rsi
  __int64 v35; // rax
  char *v36; // rsi
  __int64 v37; // rdx
  __int64 v38; // rax
  _BYTE *v39; // rsi
  __int64 v40; // rdx
  __int64 v41; // rax
  char *v42; // rsi
  __int64 v43; // rdx
  __int64 v44; // rax
  char *v45; // rsi
  __int64 v46; // rdx
  __int64 v47; // rax
  void *v48; // rsi
  unsigned __int8 *v50; // rax
  int v51; // edx
  const char *v52; // r13
  __int64 v53; // rbx
  __int64 v54; // rax
  __int64 v55; // rax
  unsigned __int8 v56; // r12
  void *v57; // rsi
  __int128 v58; // [rsp+0h] [rbp-150h] BYREF
  void *v59; // [rsp+10h] [rbp-140h]
  unsigned __int8 *v60; // [rsp+20h] [rbp-130h] BYREF
  __int128 v61; // [rsp+28h] [rbp-128h]
  unsigned __int64 v62; // [rsp+38h] [rbp-118h]
  unsigned __int8 v63; // [rsp+60h] [rbp-F0h] BYREF
  char v64; // [rsp+61h] [rbp-EFh] BYREF
  __int64 v65; // [rsp+68h] [rbp-E8h]
  void *v66; // [rsp+70h] [rbp-E0h]
  unsigned __int8 *v67; // [rsp+78h] [rbp-D8h]
  __int128 v68; // [rsp+80h] [rbp-D0h] BYREF
  void *v69; // [rsp+90h] [rbp-C0h]
  __int64 v70; // [rsp+A0h] [rbp-B0h] BYREF
  __int64 v71; // [rsp+A8h] [rbp-A8h]
  void *v72; // [rsp+B0h] [rbp-A0h]
  __int128 v73; // [rsp+B8h] [rbp-98h] BYREF
  void *v74; // [rsp+C8h] [rbp-88h]
  char *v75; // [rsp+D0h] [rbp-80h]
  unsigned __int8 v76; // [rsp+D8h] [rbp-78h] BYREF
  _BYTE v77[7]; // [rsp+D9h] [rbp-77h] BYREF
  __int64 v78; // [rsp+E0h] [rbp-70h]
  void *v79; // [rsp+E8h] [rbp-68h]
  __int64 v80; // [rsp+F0h] [rbp-60h]
  signed int v81; // [rsp+FCh] [rbp-54h]
  _BYTE v82[24]; // [rsp+100h] [rbp-50h] BYREF
  unsigned __int64 v83; // [rsp+118h] [rbp-38h]

  v6 = a4; /*0x100159fbf*/
  v75 = a2; /*0x100159fc2*/
  v80 = a1; /*0x100159fc6*/
  v81 = a3; /*0x100159fd8*/
  if ( (_DWORD)a3 == 0 ) /*0x100159fdd*/
  {
    v7 = *v75; /*0x100159fe7*/
    v8 = "SPANNING TREE"; /*0x100159ff2*/
    if ( *v75 == 0 ) /*0x100159ff9*/
      v8 = "DATA-MODEL TREE"; /*0x100159ff9*/
    std::string::basic_string[abi:ne200100]<0>(a1: v82, a2: v8, a3, a4); /*0x10015a001*/
    if ( (v82[0] & 1) != 0 ) /*0x10015a00e*/
      v9 = *(_QWORD *)&v82[8]; /*0x10015a010*/
    else
      v9 = v82[0] >> 1; /*0x10015a016*/
    std::string::basic_string[abi:ne200100](a1: &v70, a2: v9 + 10, a3: 0x3Du); /*0x10015a028*/
    v10 = "🕸️"; /*0x10015a036*/
    if ( v7 == 0 ) /*0x10015a03d*/
      v10 = "📊"; /*0x10015a03d*/
    *(_QWORD *)&v73 = v10; /*0x10015a048*/
    fmt::v8::make_format_args<fmt::v8::basic_format_context<fmt::v8::appender,char>,std::string &,char const*&,std::string &,std::string &>( /*0x10015a060*/
      a1: &v60,
      a2: (unsigned __int8 *)&v70,
      a3: (unsigned __int8 **)&v73,
      a4: v82,
      a5: (unsigned __int8 *)&v70);
    fmt::v8::vformat(a1: &v76, a2: "\n╔{}╗\n║    {} {}   ║\n╚{}╝\n", 38, 56781, &v60); /*0x10015a081*/
    if ( (v76 & 1) != 0 ) /*0x10015a08d*/
    {
      v11 = v79; /*0x10015a08f*/
      v12 = v78; /*0x10015a093*/
    }
    else
    {
      v12 = v76 >> 1; /*0x10015a099*/
      v11 = v77; /*0x10015a09b*/
    }
    std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &std::cout, a2: v11, a3: v12); /*0x10015a0a6*/
    if ( (v76 & 1) != 0 ) /*0x10015a0af*/
      operator delete(a1: (RBX::Memory *)v79, a2: v13); /*0x10015a0b5*/
    if ( (v70 & 1) != 0 ) /*0x10015a0c1*/
      operator delete(a1: (RBX::Memory *)v72, a2: v13); /*0x10015a0ca*/
    if ( (v82[0] & 1) != 0 ) /*0x10015a0d3*/
      operator delete(a1: *(RBX::Memory **)&v82[16], a2: v13); /*0x10015a0d9*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v70, a2: "", a3, a4); /*0x10015a0ec*/
  LOBYTE(v60) = 0; /*0x10015a0f8*/
  if ( (unsigned __int8)nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::value<bool,char const(&)[11],bool,0>( /*0x10015a10d*/
                          a1: v80,
                          a2: "isAnchored",
                          a3: &v60) != 0 )
  {
    std::string::append(a1: &v70, a2: "⚓ "); /*0x10015a116*/
  }
  else
  {
    LOBYTE(v60) = 0; /*0x10015a11f*/
    if ( (unsigned __int8)nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::value<bool,char const(&)[22],bool,0>( /*0x10015a134*/
                            a1: v80,
                            a2: "isRootMovingPrimitive",
                            a3: &v60) != 0 )
    {
      std::string::append(a1: &v70, a2: "⚑ "); /*0x10015a13d*/
    }
    else
    {
      LOBYTE(v60) = 0; /*0x10015a146*/
      if ( (unsigned __int8)nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::value<bool,char const(&)[7],bool,0>( /*0x10015a15b*/
                              a1: v80,
                              a2: "isRoot",
                              a3: &v60) != 0 )
        std::string::append(a1: &v70, a2: "⚐ "); /*0x10015a16b*/
    }
  }
  v14 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::at<char const(&)[5],0>( /*0x10015a17b*/
          a1: v80,
          a2: "name");
  nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::get_impl<std::string,0>( /*0x10015a187*/
    a1: &v76,
    a2: v14);
  v15 = ""; /*0x10015a193*/
  nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::value<char const(&)[1],char const(&)[6],std::string,0>( /*0x10015a1a8*/
    a1: &v73,
    a2: v80,
    a3: "label",
    a4: "");
  if ( (v73 & 1) != 0 ) /*0x10015a1b6*/
    v16 = *((_QWORD *)&v73 + 1); /*0x10015a1b8*/
  else
    v16 = (unsigned __int8)v73 >> 1; /*0x10015a1c1*/
  v67 = v6; /*0x10015a1c6*/
  if ( v16 != 0 ) /*0x10015a1cd*/
  {
    std::operator+<char>(a1: &v60, a2: " (", &v73); /*0x10015a1e8*/
    v17 = std::string::append(a1: &v60, a2: ")"); /*0x10015a1fb*/
    v19 = *(_BYTE *)v17; /*0x10015a200*/
    v20 = *(_BYTE *)(v17 + 1); /*0x10015a202*/
    *(_QWORD *)&v82[6] = *(_QWORD *)(v17 + 8); /*0x10015a20a*/
    *(_QWORD *)v82 = *(_QWORD *)(v17 + 2); /*0x10015a212*/
    v21 = *(void **)(v17 + 16); /*0x10015a216*/
    *(_OWORD *)v17 = 0; /*0x10015a21d*/
    *(_QWORD *)(v17 + 16) = 0; /*0x10015a220*/
    if ( (v73 & 1) != 0 ) /*0x10015a22f*/
      operator delete(a1: (RBX::Memory *)v74, a2: v18); /*0x10015a238*/
    LOBYTE(v73) = v19; /*0x10015a23d*/
    BYTE1(v73) = v20; /*0x10015a243*/
    *(_QWORD *)((char *)&v73 + 2) = *(_QWORD *)v82; /*0x10015a252*/
    *((_QWORD *)&v73 + 1) = *(_QWORD *)&v82[6]; /*0x10015a259*/
    v74 = v21; /*0x10015a260*/
    if ( ((unsigned __int8)v60 & 1) != 0 ) /*0x10015a26e*/
      operator delete(a1: *((RBX::Memory **)&v61 + 1), a2: v18); /*0x10015a277*/
    v6 = v67; /*0x10015a27c*/
  }
  v22 = (unsigned __int8 *)nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::at<char const(&)[9],0>( /*0x10015a28e*/
                             a1: v80,
                             a2: "children");
  v24 = (char **)*v22; /*0x10015a293*/
  if ( (_DWORD)v24 == 2 ) /*0x10015a299*/
  {
    v24 = *((char ***)v22 + 1); /*0x10015a2da*/
    v23 = v24[1]; /*0x10015a2de*/
    v25 = (signed int *)(v75 + 4); /*0x10015a2e6*/
    v26 = " ▶"; /*0x10015a2f7*/
    if ( *((_DWORD *)v75 + 1) > v81 ) /*0x10015a2fe*/
      v26 = ""; /*0x10015a2fe*/
    if ( *v24 == v23 ) /*0x10015a305*/
      goto LABEL_44; /*0x10015a305*/
    goto LABEL_40; /*0x10015a305*/
  }
  if ( (_DWORD)v24 == 1 ) /*0x10015a29e*/
  {
    v24 = *((char ***)v22 + 1); /*0x10015a2ae*/
    v23 = v75; /*0x10015a2b2*/
    v25 = (signed int *)(v75 + 4); /*0x10015a2b6*/
    v26 = " ▶"; /*0x10015a2c0*/
    if ( *((_DWORD *)v75 + 1) > v81 ) /*0x10015a2c7*/
      v26 = ""; /*0x10015a2c7*/
    if ( v24[2] == nullptr ) /*0x10015a2d0*/
      goto LABEL_44; /*0x10015a2d0*/
LABEL_40:
    v27 = 0; /*0x10015a2d2*/
    v15 = v26; /*0x10015a2d5*/
    goto LABEL_48; /*0x10015a2d8*/
  }
  if ( *v22 == 0 ) /*0x10015a2a2*/
  {
    v25 = (signed int *)(v75 + 4); /*0x10015a2a8*/
LABEL_44:
    v27 = 1; /*0x10015a307*/
    goto LABEL_48; /*0x10015a30a*/
  }
  v24 = (char **)v75; /*0x10015a30c*/
  v25 = (signed int *)(v75 + 4); /*0x10015a310*/
  if ( *((_DWORD *)v75 + 1) <= v81 ) /*0x10015a321*/
    v15 = " ▶"; /*0x10015a321*/
  v27 = 0; /*0x10015a325*/
LABEL_48:
  std::string::basic_string[abi:ne200100]<0>(a1: &v63, a2: v15, a3: v23, a4: v24); /*0x10015a328*/
  if ( v81 != 0 ) /*0x10015a33b*/
  {
    v28 = *v6; /*0x10015a33d*/
    if ( (v28 & 1) != 0 ) /*0x10015a344*/
    {
      v29 = *((unsigned __int8 **)v6 + 2); /*0x10015a346*/
      v30 = *((_QWORD *)v6 + 1); /*0x10015a34a*/
    }
    else
    {
      v29 = v6 + 1; /*0x10015a373*/
      v30 = v28 >> 1; /*0x10015a377*/
    }
    v33 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &std::cout, a2: v29, a3: v30); /*0x10015a380*/
    v34 = "├── "; /*0x10015a38c*/
    if ( a5 != 0 ) /*0x10015a396*/
      v34 = "└── "; /*0x10015a396*/
    v35 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v33, a2: v34, a3: 10); /*0x10015a3a2*/
    if ( (v70 & 1) != 0 ) /*0x10015a3b1*/
    {
      v36 = (char *)v72; /*0x10015a3b3*/
      v37 = v71; /*0x10015a3ba*/
    }
    else
    {
      v37 = (unsigned __int8)v70 >> 1; /*0x10015a3c3*/
      v36 = (char *)&v70 + 1; /*0x10015a3c5*/
    }
    v38 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v35, a2: v36, a3: v37); /*0x10015a3cf*/
    if ( (v76 & 1) != 0 ) /*0x10015a3db*/
    {
      v39 = v79; /*0x10015a3dd*/
      v40 = v78; /*0x10015a3e1*/
    }
    else
    {
      v40 = v76 >> 1; /*0x10015a3e7*/
      v39 = v77; /*0x10015a3e9*/
    }
  }
  else
  {
    if ( (v70 & 1) != 0 ) /*0x10015a35a*/
    {
      v31 = (char *)v72; /*0x10015a360*/
      v32 = v71; /*0x10015a367*/
    }
    else
    {
      v32 = (unsigned __int8)v70 >> 1; /*0x10015a3f7*/
      v31 = (char *)&v70 + 1; /*0x10015a3f9*/
    }
    v38 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &std::cout, a2: v31, a3: v32); /*0x10015a407*/
    if ( (v76 & 1) != 0 ) /*0x10015a413*/
    {
      v39 = v79; /*0x10015a415*/
      v40 = v78; /*0x10015a419*/
    }
    else
    {
      v40 = v76 >> 1; /*0x10015a41f*/
      v39 = v77; /*0x10015a421*/
    }
  }
  v41 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v38, a2: v39, a3: v40); /*0x10015a428*/
  if ( (v73 & 1) != 0 ) /*0x10015a437*/
  {
    v42 = (char *)v74; /*0x10015a439*/
    v43 = *((_QWORD *)&v73 + 1); /*0x10015a440*/
  }
  else
  {
    v43 = (unsigned __int8)v73 >> 1; /*0x10015a449*/
    v42 = (char *)&v73 + 1; /*0x10015a44b*/
  }
  v44 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v41, a2: v42, a3: v43); /*0x10015a455*/
  if ( (v63 & 1) != 0 ) /*0x10015a464*/
  {
    v45 = (char *)v66; /*0x10015a466*/
    v46 = v65; /*0x10015a46d*/
  }
  else
  {
    v46 = v63 >> 1; /*0x10015a476*/
    v45 = &v64; /*0x10015a478*/
  }
  v47 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v44, a2: v45, a3: v46); /*0x10015a482*/
  std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v47, a2: "\n", a3: 1); /*0x10015a496*/
  if ( ((*v25 <= v81) | (unsigned __int8)v27) == 0 ) /*0x10015a4a6*/
  {
    v50 = (unsigned __int8 *)nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::at<char const(&)[9],0>( /*0x10015a527*/
                               a1: v80,
                               a2: "children");
    v60 = v50; /*0x10015a536*/
    v61 = 0; /*0x10015a540*/
    v62 = 0x8000000000000000LL; /*0x10015a547*/
    v51 = *v50; /*0x10015a54e*/
    if ( *v50 != 0 ) /*0x10015a553*/
    {
      if ( v51 == 2 ) /*0x10015a558*/
      {
        *((_QWORD *)&v61 + 1) = **((_QWORD **)v50 + 1); /*0x10015a58e*/
        *(_QWORD *)v82 = v50; /*0x10015a595*/
        *(_OWORD *)&v82[8] = 0; /*0x10015a599*/
        v83 = 0x8000000000000000LL; /*0x10015a59d*/
        *(_QWORD *)&v82[16] = *(_QWORD *)(*((_QWORD *)v50 + 1) + 8LL); /*0x10015a5a9*/
        goto LABEL_90; /*0x10015a5ad*/
      }
      if ( v51 == 1 ) /*0x10015a55d*/
      {
        *(_QWORD *)&v61 = **((_QWORD **)v50 + 1); /*0x10015a566*/
        *(_QWORD *)v82 = v50; /*0x10015a56d*/
        *(_OWORD *)&v82[8] = 0; /*0x10015a571*/
        v83 = 0x8000000000000000LL; /*0x10015a575*/
        *(_QWORD *)&v82[8] = *((_QWORD *)v50 + 1) + 8LL; /*0x10015a581*/
LABEL_90:
        v52 = "│   "; /*0x10015a5d7*/
        if ( a5 != 0 ) /*0x10015a5e8*/
          v52 = "    "; /*0x10015a5e8*/
        ++v81; /*0x10015a5ec*/
        while ( (unsigned __int8)nlohmann::json_abi_v3_11_2::detail::iter_impl<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> const>::operator==<nlohmann::json_abi_v3_11_2::detail::iter_impl<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> const>,(decltype(nullptr))0>( /*0x10015a60b*/
                                   a1: &v60,
                                   a2: v82) == 0 )
        {
          v53 = nlohmann::json_abi_v3_11_2::detail::iter_impl<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> const>::operator*(a1: &v60); /*0x10015a619*/
          if ( (*v67 & 1) != 0 ) /*0x10015a626*/
          {
            std::string::__init_copy_ctor_external(a1: &v68, a2: *((_QWORD *)v67 + 2), a3: *((_QWORD *)v67 + 1)); /*0x10015a658*/
          }
          else
          {
            v69 = *((void **)v67 + 2); /*0x10015a62c*/
            v68 = *(_OWORD *)v67; /*0x10015a636*/
          }
          std::string::append(a1: &v68, a2: v52); /*0x10015a663*/
          v54 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::at<char const(&)[9],0>( /*0x10015a673*/
                  a1: v80,
                  a2: "children");
          v55 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::back(a1: v54); /*0x10015a67b*/
          v56 = nlohmann::json_abi_v3_11_2::operator==(a1: v55, a2: v53); /*0x10015a68b*/
          if ( (v68 & 1) != 0 ) /*0x10015a695*/
          {
            std::string::__init_copy_ctor_external(a1: &v58, a2: v69, a3: *((_QWORD *)&v68 + 1)); /*0x10015a6c6*/
          }
          else
          {
            v59 = v69; /*0x10015a69e*/
            v58 = v68; /*0x10015a6ac*/
          }
          RBX::Network::consoleTree(a1: v53, a2: v75, a3: (unsigned int)v81, a4: &v58, a5: v56); /*0x10015a6dc*/
          if ( (v58 & 1) != 0 ) /*0x10015a6e8*/
            operator delete(a1: (RBX::Memory *)v59, a2: v57); /*0x10015a6f1*/
          if ( (v68 & 1) != 0 ) /*0x10015a6fd*/
            operator delete(a1: (RBX::Memory *)v69, a2: v57); /*0x10015a706*/
          nlohmann::json_abi_v3_11_2::detail::iter_impl<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> const>::operator++(a1: &v60); /*0x10015a70e*/
        }
        goto LABEL_73; /*0x10015a60b*/
      }
      v62 = 0; /*0x10015a5bc*/
    }
    else
    {
      v62 = 1; /*0x10015a5af*/
    }
    *(_QWORD *)v82 = v50; /*0x10015a5c7*/
    *(_OWORD *)&v82[8] = 0; /*0x10015a5cb*/
    v83 = 1; /*0x10015a5cf*/
    goto LABEL_90; /*0x10015a5cf*/
  }
LABEL_73:
  if ( (v63 & 1) != 0 ) /*0x10015a4af*/
    operator delete(a1: (RBX::Memory *)v66, a2: v48); /*0x10015a4b8*/
  if ( (v73 & 1) != 0 ) /*0x10015a4c4*/
    operator delete(a1: (RBX::Memory *)v74, a2: v48); /*0x10015a4cd*/
  if ( (v76 & 1) != 0 ) /*0x10015a4d6*/
    operator delete(a1: (RBX::Memory *)v79, a2: v48); /*0x10015a4dc*/
  if ( (v70 & 1) != 0 ) /*0x10015a4e8*/
    operator delete(a1: (RBX::Memory *)v72, a2: v48); /*0x10015a4f1*/
  return __stack_chk_guard; /*0x10015a50a*/
}

// Address: 0x10015b3e4 | Name: __ZN3RBX7Network7dotTreeERKN8nlohmann16json_abi_v3_11_210basic_jsonINSt3__13mapENS4_6vectorENS4_12basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEbxydSA_NS2_14adl_serializerENS6_IhNSA_IhEEEEEERKNS0_13TreeVizConfigE
__int64 __fastcall RBX::Network::dotTree(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v5; // rax
  _QWORD v7[4]; // [rsp+0h] [rbp-290h] BYREF
  _QWORD *v8; // [rsp+20h] [rbp-270h]
  __int64 (__fastcall **v9)(); // [rsp+30h] [rbp-260h] BYREF
  _QWORD v10[51]; // [rsp+38h] [rbp-258h] BYREF
  __int64 (__fastcall **v11)(); // [rsp+1D0h] [rbp-C0h] BYREF

  RBX::Network::getFileName(a1, a2: a3); /*0x10015b40d*/
  std::ofstream::basic_ofstream(a1: &v9, a2: a1, a3: 16); /*0x10015b421*/
  std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &v9, a2: "digraph tree {\n", a3: 15); /*0x10015b439*/
  std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>( /*0x10015b451*/
    a1: &v9,
    a2: "\n"
    "        rankdir=LR;\n"
    "        bgcolor=\"#f7f7f7\";\n"
    "        node [\n"
    "            fontname=\"Courier\",\n"
    "            fontsize=10,\n"
    "            penwidth=1.5,\n"
    "            color=\"#ffffff\",\n"
    "            style=\"filled\"\n"
    "        ];\n"
    "        edge [\n"
    "            color=\"#e0e0e0\",\n"
    "            penwidth=1.5\n"
    "        ];\n"
    "        graph [\n"
    "            nodesep=0.5,\n"
    "            ranksep=1.0\n"
    "        ];\n"
    "    ",
    a3: 373);
  std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &v9, a2: "\n", a3: 1); /*0x10015b46c*/
  v7[0] = off_10C44FC18; /*0x10015b47f*/
  v7[1] = v7; /*0x10015b482*/
  v7[2] = &v9; /*0x10015b486*/
  v8 = v7; /*0x10015b48a*/
  ((void (__fastcall *)(_QWORD *, __int64))std::__function::__func<RBX::Network::dotTree(nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> const&,RBX::Network::TreeVizConfig const&)::$_0,std::allocator<RBX::Network::dotTree(nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> const&,RBX::Network::TreeVizConfig const&)::$_0>,void ()(nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> const&)>::operator())( /*0x10015b494*/
    a1: v7,
    a2);
  std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &v9, a2: "}\n", a3: 2); /*0x10015b4ac*/
  if ( std::filebuf::close(a1: v10) == nullptr ) /*0x10015b4c3*/
    std::ios_base::clear( /*0x10015b4e1*/
      this: (std::ios_base *)((char *)&v10[-1] + (_QWORD)*(v9 - 3)),
      a2: *(_DWORD *)((char *)&v10[3] + (_QWORD)*(v9 - 3)) | 4);
  if ( v8 == v7 ) /*0x10015b4f0*/
  {
    v5 = 32; /*0x10015b4fe*/
  }
  else
  {
    v5 = 40; /*0x10015b4f2*/
    if ( v8 == nullptr ) /*0x10015b4fa*/
      goto LABEL_8; /*0x10015b4fa*/
  }
  (*(void (**)(void))(*v8 + v5))(); /*0x10015b506*/
LABEL_8:
  v9 = &off_10C447C38; /*0x10015b509*/
  v11 = off_10C447C60; /*0x10015b526*/
  std::filebuf::~filebuf(a1: (__int64)v10); /*0x10015b52c*/
  std::ostream::~ostream(a1: &v9, a2: off_10C447C78); /*0x10015b543*/
  std::ios::~ios(a1: &v11); /*0x10015b54b*/
  return a1; /*0x10015b563*/
}

// Address: 0x10015b6d8 | Name: __ZN3RBX7Network7svgTreeERKN8nlohmann16json_abi_v3_11_210basic_jsonINSt3__13mapENS4_6vectorENS4_12basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEbxydSA_NS2_14adl_serializerENS6_IhNSA_IhEEEEEERKNS0_13TreeVizConfigE
void __fastcall RBX::Network::svgTree(__int64 a1, _BYTE *a2)
{
  void *v2; // rsi
  _BYTE v3[16]; // [rsp+8h] [rbp-28h] BYREF
  void *v4; // [rsp+18h] [rbp-18h]
  _DWORD v5[4]; // [rsp+20h] [rbp-10h] BYREF

  LOBYTE(v5[0]) = *a2; /*0x10015b6ea*/
  BYTE1(v5[0]) = 3; /*0x10015b6ec*/
  v5[1] = 3; /*0x10015b6f0*/
  RBX::Network::dotTree(a1: (__int64)v3, a2: a1, a3: v5); /*0x10015b701*/
  if ( (v3[0] & 1) != 0 ) /*0x10015b709*/
    operator delete(a1: (RBX::Memory *)v4, a2: v2); /*0x10015b70f*/
}

// Address: 0x10015b71b | Name: __ZN3RBX7Network15interactiveTreeERKN8nlohmann16json_abi_v3_11_210basic_jsonINSt3__13mapENS4_6vectorENS4_12basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEbxydSA_NS2_14adl_serializerENS6_IhNSA_IhEEEEEERKNS0_13TreeVizConfigE
__int64 __fastcall RBX::Network::interactiveTree(__int64 a1, _BYTE *a2)
{
  __int64 v4; // rdx
  __int64 v5; // rcx
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // rdx
  __int64 v9; // rcx
  const char *v10; // rsi
  __int64 v11; // rdx
  __int64 v12; // rcx
  void *v13; // rsi
  __int64 v14; // rdx
  __int64 v15; // rcx
  __int64 v16; // rdx
  __int64 v17; // rcx
  void *v18; // rsi
  __int64 v19; // rdx
  __int64 v20; // rcx
  void *v21; // rsi
  __int64 v22; // rdx
  __int64 v23; // rcx
  void *v24; // rsi
  char *v25; // rsi
  __int64 v26; // rdx
  __int64 v27; // rax
  char *v28; // rsi
  __int64 v29; // rdx
  const char *v30; // rdi
  void *v31; // rsi
  __int64 v32; // rax
  void *v33; // rsi
  unsigned __int8 v35; // [rsp+0h] [rbp-2B0h] BYREF
  char v36; // [rsp+1h] [rbp-2AFh] BYREF
  __int64 v37; // [rsp+8h] [rbp-2A8h]
  void *v38; // [rsp+10h] [rbp-2A0h]
  unsigned __int8 v39; // [rsp+18h] [rbp-298h] BYREF
  char v40; // [rsp+19h] [rbp-297h] BYREF
  __int64 v41; // [rsp+20h] [rbp-290h]
  void *v42; // [rsp+28h] [rbp-288h]
  unsigned __int8 v43[16]; // [rsp+30h] [rbp-280h] BYREF
  void *v44; // [rsp+40h] [rbp-270h]
  unsigned __int8 v45; // [rsp+48h] [rbp-268h] BYREF
  char v46; // [rsp+49h] [rbp-267h] BYREF
  void *v47; // [rsp+58h] [rbp-258h]
  __int64 (__fastcall **v48)(); // [rsp+60h] [rbp-250h] BYREF
  _QWORD v49[51]; // [rsp+68h] [rbp-248h] BYREF
  __int64 (__fastcall **v50)(); // [rsp+200h] [rbp-B0h] BYREF

  RBX::Network::getFileName(a1: (__int64)&v35, a2); /*0x10015b744*/
  std::ofstream::basic_ofstream(a1: &v48, a2: &v35, a3: 16); /*0x10015b75c*/
  if ( v49[15] != 0 )
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v39, a2: &kHtmlContent, a3: v4, a4: v5); /*0x10015b77d*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v45, a2: "{{TREE_TYPE}}", a3: v6, a4: v7); /*0x10015b790*/
    v10 = "spanning"; /*0x10015b7a0*/
    if ( *a2 == 0 ) /*0x10015b7a7*/
      v10 = "datamodel"; /*0x10015b7a7*/
    std::string::basic_string[abi:ne200100]<0>(a1: v43, a2: v10, a3: v8, a4: v9); /*0x10015b7b2*/
    `anonymous namespace'::replace(a1: &v39, a2: &v45, a3: v43); /*0x10015b7cc*/
    if ( (v43[0] & 1) != 0 ) /*0x10015b7d8*/
      operator delete(a1: (RBX::Memory *)v44, a2: v13); /*0x10015b7e1*/
    if ( (v45 & 1) != 0 ) /*0x10015b7ed*/
      operator delete(a1: (RBX::Memory *)v47, a2: v13); /*0x10015b7f6*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v45, a2: "{{CSS_PLACEHOLDER}}", a3: v11, a4: v12); /*0x10015b809*/
    std::string::basic_string[abi:ne200100]<0>(a1: v43, a2: kStyleContent, a3: v14, a4: v15); /*0x10015b81c*/
    `anonymous namespace'::replace(a1: &v39, a2: &v45, a3: v43); /*0x10015b836*/
    if ( (v43[0] & 1) != 0 ) /*0x10015b842*/
      operator delete(a1: (RBX::Memory *)v44, a2: v18); /*0x10015b84b*/
    if ( (v45 & 1) != 0 ) /*0x10015b857*/
      operator delete(a1: (RBX::Memory *)v47, a2: v18); /*0x10015b860*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v45, a2: "{{JSON_PLACEHOLDER}}", a3: v16, a4: v17); /*0x10015b873*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::dump( /*0x10015b892*/
      a1: v43,
      a2: a1,
      a3: 4,
      a4: 32,
      a5: 0,
      a6: 0);
    `anonymous namespace'::replace(a1: &v39, a2: &v45, a3: v43); /*0x10015b8ac*/
    if ( (v43[0] & 1) != 0 ) /*0x10015b8b8*/
      operator delete(a1: (RBX::Memory *)v44, a2: v21); /*0x10015b8c1*/
    if ( (v45 & 1) != 0 ) /*0x10015b8cd*/
      operator delete(a1: (RBX::Memory *)v47, a2: v21); /*0x10015b8d6*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v45, a2: "{{JS_PLACEHOLDER}}", a3: v19, a4: v20); /*0x10015b8e9*/
    std::string::basic_string[abi:ne200100]<0>(a1: v43, a2: &kScriptContent, a3: v22, a4: v23); /*0x10015b8fc*/
    `anonymous namespace'::replace(a1: &v39, a2: &v45, a3: v43); /*0x10015b916*/
    if ( (v43[0] & 1) != 0 ) /*0x10015b922*/
      operator delete(a1: (RBX::Memory *)v44, a2: v24); /*0x10015b92b*/
    if ( (v45 & 1) != 0 ) /*0x10015b937*/
      operator delete(a1: (RBX::Memory *)v47, a2: v24); /*0x10015b940*/
    if ( (v39 & 1) != 0 ) /*0x10015b94f*/
    {
      v25 = (char *)v42; /*0x10015b951*/
      v26 = v41; /*0x10015b958*/
    }
    else
    {
      v26 = v39 >> 1; /*0x10015b99c*/
      v25 = &v40; /*0x10015b99e*/
    }
    std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &v48, a2: v25, a3: v26); /*0x10015b9ac*/
    if ( std::filebuf::close(a1: v49) == nullptr ) /*0x10015b9c0*/
      std::ios_base::clear( /*0x10015b9de*/
        this: (std::ios_base *)((char *)&v49[-1] + (_QWORD)*(v48 - 3)),
        a2: *(_DWORD *)((char *)&v49[3] + (_QWORD)*(v48 - 3)) | 4);
    std::operator+<char>(a1: &v45, a2: "open ", &v35); /*0x10015b9f8*/
    if ( (v45 & 1) != 0 ) /*0x10015ba04*/
      v30 = (const char *)v47; /*0x10015ba06*/
    else
      v30 = &v46; /*0x10015ba0f*/
    if ( system(a1: v30) != 0 ) /*0x10015ba1d*/
      std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>( /*0x10015ba32*/
        a1: &std::cout,
        a2: "Command execution failed...\n",
        a3: 28);
    if ( (v45 & 1) != 0 ) /*0x10015ba3e*/
      operator delete(a1: (RBX::Memory *)v47, a2: v31); /*0x10015ba47*/
    if ( (v39 & 1) != 0 ) /*0x10015ba53*/
      operator delete(a1: (RBX::Memory *)v42, a2: v31); /*0x10015ba5c*/
  }
  else
  {
    v27 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(
            a1: &std::cerr,
            a2: "ERROR: Could not create output HTML file: ",
            a3: 42);
    if ( (v35 & 1) != 0 ) /*0x10015b983*/
    {
      v28 = (char *)v38; /*0x10015b989*/
      v29 = v37; /*0x10015b990*/
    }
    else
    {
      v29 = v35 >> 1; /*0x10015ba63*/
      v28 = &v36; /*0x10015ba65*/
    }
    v32 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v27, a2: v28, a3: v29); /*0x10015ba6f*/
    std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v32, a2: "\n", a3: 1); /*0x10015ba83*/
  }
  v48 = &off_10C447C38; /*0x10015ba9a*/
  v50 = off_10C447C60; /*0x10015baa5*/
  std::filebuf::~filebuf(a1: (__int64)v49); /*0x10015baaf*/
  std::ostream::~ostream(a1: &v48, a2: off_10C447C78); /*0x10015bac6*/
  std::ios::~ios(a1: &v50); /*0x10015bace*/
  if ( (v35 & 1) != 0 ) /*0x10015bada*/
    operator delete(a1: (RBX::Memory *)v38, a2: v33); /*0x10015bae3*/
  return __stack_chk_guard; /*0x10015baf8*/
}

// Address: 0x10015bea9 | Name: __ZN3RBX7Network12generateJsonEPNS_8InstanceERN8nlohmann16json_abi_v3_11_210basic_jsonINSt3__13mapENS6_6vectorENS6_12basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEbxydSC_NS4_14adl_serializerENS8_IhNSC_IhEEEEEERKNS0_13TreeVizConfigERKNS6_8functionIFSE_S2_EEE
__int64 __fastcall RBX::Network::generateJson(_anonymous_namespace_ *a1, char *a2, _BYTE *a3, __int64 a4)
{
  __int64 v7; // rax
  RSL::Arena *v8; // rdi
  __int64 v9; // r12
  unsigned __int64 v10; // rsi
  __int64 v11; // rax
  __int64 v12; // rdi
  char v13; // al
  __int64 v14; // rax
  __int64 v15; // rsi
  __int64 v16; // rsi
  __int64 i; // rbx
  __int64 j; // rbx
  void *v19; // rsi
  __int64 k; // rbx
  __int64 m; // rbx
  __int64 v22; // rax
  _BYTE v23[8]; // [rsp+0h] [rbp-180h] BYREF
  __int64 v24; // [rsp+8h] [rbp-178h]
  _QWORD v25[4]; // [rsp+10h] [rbp-170h] BYREF
  __int64 DefaultArena; // [rsp+30h] [rbp-150h]
  __int128 v27; // [rsp+40h] [rbp-140h] BYREF
  void *v28; // [rsp+50h] [rbp-130h]
  _BYTE v29[8]; // [rsp+60h] [rbp-120h] BYREF
  __int64 v30; // [rsp+68h] [rbp-118h]
  _BYTE v31[8]; // [rsp+70h] [rbp-110h] BYREF
  __int64 v32; // [rsp+78h] [rbp-108h]
  __int64 v33; // [rsp+80h] [rbp-100h]
  char v34; // [rsp+88h] [rbp-F8h]
  __int64 v35; // [rsp+90h] [rbp-F0h]
  __int64 v36; // [rsp+98h] [rbp-E8h]
  _BYTE v37[8]; // [rsp+A0h] [rbp-E0h] BYREF
  __int64 v38; // [rsp+A8h] [rbp-D8h]
  __int64 v39; // [rsp+B0h] [rbp-D0h]
  char v40; // [rsp+B8h] [rbp-C8h]
  __int64 v41; // [rsp+C0h] [rbp-C0h]
  __int64 v42; // [rsp+C8h] [rbp-B8h]
  _BYTE v43[8]; // [rsp+D0h] [rbp-B0h] BYREF
  __int64 v44; // [rsp+D8h] [rbp-A8h]
  __int64 v45; // [rsp+E0h] [rbp-A0h]
  char v46; // [rsp+E8h] [rbp-98h]
  __int64 v47; // [rsp+F0h] [rbp-90h]
  __int64 v48; // [rsp+F8h] [rbp-88h]
  _QWORD v49[2]; // [rsp+100h] [rbp-80h] BYREF
  char *v50; // [rsp+110h] [rbp-70h]
  __int64 v51; // [rsp+118h] [rbp-68h] BYREF
  _QWORD *v52; // [rsp+120h] [rbp-60h]
  __int64 v53; // [rsp+128h] [rbp-58h]
  _QWORD v54[4]; // [rsp+130h] [rbp-50h] BYREF

  if ( *a3 == 1 ) /*0x10015bed7*/
  {
    v7 = RBX::Instance::findSelfOrFirstAncestorOfType<RBX::WorldRoot>(); /*0x10015bf11*/
    if ( v7 == 0 ) /*0x10015bf19*/
      return __stack_chk_guard; /*0x10015bf19*/
    v9 = v7; /*0x10015bf1f*/
    DefaultArena = RSL::Arena::getDefaultArena(this: v8); /*0x10015bf27*/
    memset(v25, 0, sizeof(v25)); /*0x10015bf31*/
    v43[0] = 3; /*0x10015bf4a*/
    v44 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[3]>(a1: "id"); /*0x10015bf5d*/
    v45 = 0; /*0x10015bf64*/
    RBX::Guid::toString(this: (RBX::Guid *)&v27); /*0x10015bf7b*/
    v47 = 0; /*0x10015bf80*/
    v46 = 3; /*0x10015bf8b*/
    v11 = operator new(a1: (RBX::Memory *)0x18, a2: v10); /*0x10015bf97*/
    *(_QWORD *)(v11 + 16) = v28; /*0x10015bfa3*/
    *(_OWORD *)v11 = v27; /*0x10015bfae*/
    v27 = 0; /*0x10015bfb4*/
    v28 = nullptr; /*0x10015bfbd*/
    v47 = v11; /*0x10015bfcb*/
    v48 = 0; /*0x10015bfcf*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x10015bfea*/
      a1: v49,
      a2: v43,
      a3: 2,
      a4: 1,
      a5: 2);
    v50 = nullptr; /*0x10015bff5*/
    v38 = 0; /*0x10015bff9*/
    v37[0] = 3; /*0x10015c000*/
    v38 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[5]>(a1: "name"); /*0x10015c013*/
    v39 = 0; /*0x10015c01c*/
    v12 = *(_QWORD *)(v9 + 112) + 8LL; /*0x10015c028*/
    v41 = 0; /*0x10015c02c*/
    v40 = 3; /*0x10015c033*/
    v41 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,std::string const&>(a1: v12); /*0x10015c046*/
    v42 = 0; /*0x10015c04a*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x10015c065*/
      a1: &v51,
      a2: v37,
      a3: 2,
      a4: 1,
      a5: 2);
    v53 = 0; /*0x10015c070*/
    v32 = 0; /*0x10015c074*/
    v31[0] = 3; /*0x10015c07b*/
    v32 = nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::create<std::string,char const(&)[9]>(a1: "children"); /*0x10015c08e*/
    v33 = 0; /*0x10015c095*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x10015c0b3*/
      a1: v29,
      a2: 0,
      a3: 0,
      a4: 0,
      a5: 2);
    v34 = v29[0]; /*0x10015c0c5*/
    v35 = v30; /*0x10015c0cf*/
    v29[0] = 0; /*0x10015c0d3*/
    v30 = 0; /*0x10015c0dc*/
    v36 = 0; /*0x10015c0e3*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x10015c0fa*/
      a1: v54,
      a2: v31,
      a3: 2,
      a4: 1,
      a5: 2);
    v54[2] = 0; /*0x10015c103*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::basic_json( /*0x10015c125*/
      a1: v23,
      a2: v49,
      a3: 3,
      a4: 1,
      a5: 2);
    v13 = *a2; /*0x10015c12a*/
    *a2 = v23[0]; /*0x10015c136*/
    v23[0] = v13; /*0x10015c139*/
    v14 = *((_QWORD *)a2 + 1); /*0x10015c13b*/
    *((_QWORD *)a2 + 1) = v24; /*0x10015c143*/
    v24 = v14; /*0x10015c147*/
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x10015c14b*/
      a1: v23,
      a2: v15);
    for ( i = 6; i != -3; i -= 3 ) /*0x10015c150*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x10015c15d*/
        a1: &v49[i],
        a2: v16);
    for ( j = 24; j != -24; j -= 24 ) /*0x10015c16c*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x10015c17c*/
        a1: &v31[j],
        a2: v16);
    nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x10015c192*/
      a1: v29,
      a2: v16);
    for ( k = 24; k != -24; k -= 24 ) /*0x10015c197*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x10015c1a7*/
        a1: &v37[k],
        a2: v19);
    for ( m = 24; m != -24; m -= 24 ) /*0x10015c1b6*/
      nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>>::~basic_json( /*0x10015c1c6*/
        a1: &v43[m],
        a2: v19);
    if ( (v27 & 1) != 0 ) /*0x10015c1dc*/
      operator delete(a1: (RBX::Memory *)v28, a2: v19); /*0x10015c1e5*/
    v49[0] = off_10C44FD50; /*0x10015c1f1*/
    v49[1] = v25; /*0x10015c1fc*/
    v50 = a2; /*0x10015c200*/
    v51 = a4; /*0x10015c204*/
    v52 = v49; /*0x10015c208*/
    RBX::Instance::visitDescendantsIf(a1: v9, a2: v49); /*0x10015c212*/
    if ( v52 == v49 ) /*0x10015c21e*/
    {
      v22 = 32; /*0x10015c22c*/
    }
    else
    {
      v22 = 40; /*0x10015c220*/
      if ( v52 == nullptr ) /*0x10015c228*/
        goto LABEL_20; /*0x10015c228*/
    }
    (*(void (**)(void))(*v52 + v22))(); /*0x10015c234*/
LABEL_20:
    RBX::details::SplitHashTable<std::string,std::pair<std::string,nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> *>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long long,unsigned long long,double,std::allocator,nlohmann::json_abi_v3_11_2::adl_serializer,std::vector<unsigned char>> *>>::freeInternalMemoryAndLeaveUninitialized(a1: v25); /*0x10015c237*/
    return __stack_chk_guard; /*0x10015c23e*/
  }
  if ( *a3 == 0 ) /*0x10015bedb*/
    return RBX::Network::datamodelJson(a1, a2, a3: a4); /*0x10015bf0c*/
  return __stack_chk_guard; /*0x10015befb*/
}

// Address: 0x100c08a1c | Name: __ZNK3RBX7Network11NetAssetRefeqERKS1_
bool __fastcall RBX::Network::NetAssetRef::operator==(__int64 a1, __int64 a2)
{
  __int64 v2; // rax
  __int64 v3; // rcx

  v2 = *(_QWORD *)(a1 + 16); /*0x100c08a27*/
  v3 = *(_QWORD *)(a2 + 16); /*0x100c08a2b*/
  if ( FFlag::NetAssetClonePendingFix == 1 ) /*0x100c08a32*/
  {
    if ( v2 == v3 && *(_DWORD *)(a1 + 24) == *(_DWORD *)(a2 + 24) && *(_WORD *)(a1 + 32) == *(_WORD *)(a2 + 32) ) /*0x100c08a49*/
      return *(_BYTE *)(a1 + 40) == *(_BYTE *)(a2 + 40); /*0x100c08a6b*/
  }
  else if ( v2 == v3 && *(_DWORD *)(a1 + 24) == *(_DWORD *)(a2 + 24) ) /*0x100c08a5e*/
  {
    return *(_WORD *)(a1 + 32) == *(_WORD *)(a2 + 32); /*0x100c08a64*/
  }
  return false; /*0x100c08a6f*/
}

// Address: 0x100c09284 | Name: __ZNK3RBX7Network17NetAssetProxyTypeINS_20SolidMeshHolderDeltaEEeqERKNS0_13NetAssetProxyE
__int64 __fastcall RBX::Network::NetAssetProxyType<RBX::SolidMeshHolderDelta>::operator==(__int64 a1, __int64 a2)
{
  __int64 v2; // rdi

  (*(void (__fastcall **)(__int64))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x100c0928e*/
  RBX::Network::getNetAssetType<RBX::SolidMeshHolderDelta>(a1: v2); /*0x100c09291*/
  return 0; /*0x100c09298*/
}

// Address: 0x100c24ba4 | Name: __ZNK3RBX7Network15NetAssetTypeRefINS_15SolidMeshHolderEEeqERKS3_
bool __fastcall RBX::Network::NetAssetTypeRef<RBX::SolidMeshHolder>::operator==(__int64 a1, __int64 a2)
{
  __int64 v2; // rax
  __int64 v3; // rcx

  v2 = *(_QWORD *)(a1 + 16); /*0x100c24baf*/
  v3 = *(_QWORD *)(a2 + 16); /*0x100c24bb3*/
  if ( FFlag::NetAssetClonePendingFix == 1 ) /*0x100c24bba*/
  {
    if ( v2 == v3 && *(_DWORD *)(a1 + 24) == *(_DWORD *)(a2 + 24) && *(_WORD *)(a1 + 32) == *(_WORD *)(a2 + 32) ) /*0x100c24bd1*/
      return (*(_QWORD *)(a1 + 48) != 0) ^ (*(_QWORD *)(a2 + 48) == 0); /*0x100c24be5*/
  }
  else if ( v2 == v3 && *(_DWORD *)(a1 + 24) == *(_DWORD *)(a2 + 24) ) /*0x100c24bf2*/
  {
    return *(_WORD *)(a1 + 32) == *(_WORD *)(a2 + 32); /*0x100c24bff*/
  }
  return false; /*0x100c24c03*/
}

// Address: 0x100c2583c | Name: __ZNK3RBX7Network17NetAssetProxyTypeINS_15SolidMeshHolderEEeqERKNS0_13NetAssetProxyE
__int64 __fastcall RBX::Network::NetAssetProxyType<RBX::SolidMeshHolder>::operator==(__int64 a1, __int64 a2)
{
  __int64 v2; // rdi

  (*(void (__fastcall **)(__int64))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x100c25846*/
  RBX::Network::getNetAssetType<RBX::SolidMeshHolder>(a1: v2); /*0x100c25849*/
  return 0; /*0x100c25850*/
}

// Address: 0x100c61b8a | Name: __ZNK3RBX7Network15NetAssetTypeRefINS_18ConvexDecompHolderEEeqERKS3_
bool __fastcall RBX::Network::NetAssetTypeRef<RBX::ConvexDecompHolder>::operator==(__int64 a1, __int64 a2)
{
  __int64 v2; // rax
  __int64 v3; // rcx

  v2 = *(_QWORD *)(a1 + 16); /*0x100c61b95*/
  v3 = *(_QWORD *)(a2 + 16); /*0x100c61b99*/
  if ( FFlag::NetAssetClonePendingFix == 1 ) /*0x100c61ba0*/
  {
    if ( v2 == v3 && *(_DWORD *)(a1 + 24) == *(_DWORD *)(a2 + 24) && *(_WORD *)(a1 + 32) == *(_WORD *)(a2 + 32) ) /*0x100c61bb7*/
      return (*(_QWORD *)(a1 + 48) != 0) ^ (*(_QWORD *)(a2 + 48) == 0); /*0x100c61bcb*/
  }
  else if ( v2 == v3 && *(_DWORD *)(a1 + 24) == *(_DWORD *)(a2 + 24) ) /*0x100c61bd8*/
  {
    return *(_WORD *)(a1 + 32) == *(_WORD *)(a2 + 32); /*0x100c61be5*/
  }
  return false; /*0x100c61be9*/
}

// Address: 0x100c62c38 | Name: __ZNK3RBX7Network17NetAssetProxyTypeINS_18ConvexDecompHolderEEeqERKNS0_13NetAssetProxyE
bool __fastcall RBX::Network::NetAssetProxyType<RBX::ConvexDecompHolder>::operator==(__int64 a1, _QWORD *a2)
{
  __int16 v4; // r15
  __int64 v5; // rdx
  __int64 v6; // rdi
  __int64 v7; // rsi
  _QWORD *v8; // rdi
  _QWORD *v9; // rsi

  v4 = (*(__int64 (__fastcall **)(_QWORD *))(*a2 + 16LL))(a1: a2); /*0x100c62c51*/
  return v4 == (unsigned __int16)RBX::Network::getNetAssetType<RBX::ConvexDecompHolder>(a1: v6, a2: v7, a3: v5) /*0x100c62c75*/
      && (v8 = *(_QWORD **)(a1 + 8)) != nullptr
      && (v9 = (_QWORD *)a2[1]) != nullptr
      && RBX::SharedString::operator==(a1: v8, a2: v9);
}

// Address: 0x102a02da3 | Name: __ZN3RBX7Network29flagsSendsGoThroughConnectionEv
char __fastcall RBX::Network::flagsSendsGoThroughConnection(RBX::Network *this)
{
  return FFlag::SendsGoThroughConnection & FFlag::ConnectViaConnectionInternal; /*0x102a02db3*/
}

// Address: 0x102a04aca | Name: __ZN3RBX7Network25netAssetTypeValueToStringENS0_18NetAssetTypeValuesE
const char *__fastcall RBX::Network::netAssetTypeValueToString(unsigned __int16 a1)
{
  if ( a1 <= 0xBu ) /*0x102a04ad2*/
    return (&RBX::Network::netAssetTypeStrings)[2 * (unsigned int)a1]; /*0x102a04aea*/
  else
    return "Unknown"; /*0x102a04ad4*/
}

// Address: 0x102a04af0 | Name: __ZN3RBX7Network15getNetAssetTypeINS0_9TestAssetEEEtv
__int64 RBX::Network::getNetAssetType<RBX::Network::TestAsset>()
{
  return 1; /*0x102a04af9*/
}

// Address: 0x102a04afb | Name: __ZN3RBX7Network15getNetAssetTypeINS0_14TestAssetDeltaEEEtv
__int64 RBX::Network::getNetAssetType<RBX::Network::TestAssetDelta>()
{
  return 2; /*0x102a04b04*/
}

// Address: 0x102a04b06 | Name: __ZN3RBX7Network15getNetAssetTypeINS_15SolidMeshHolderEEEtv
__int64 RBX::Network::getNetAssetType<RBX::SolidMeshHolder>()
{
  return 3; /*0x102a04b0f*/
}

// Address: 0x102a04b11 | Name: __ZN3RBX7Network15getNetAssetTypeINS_20SolidMeshHolderDeltaEEEtv
__int64 RBX::Network::getNetAssetType<RBX::SolidMeshHolderDelta>()
{
  return 4; /*0x102a04b1a*/
}

// Address: 0x102a04b1c | Name: __ZN3RBX7Network15getNetAssetTypeINS_18ConvexDecompHolderEEEtv
__int64 RBX::Network::getNetAssetType<RBX::ConvexDecompHolder>()
{
  return 5; /*0x102a04b25*/
}

// Address: 0x102a04b27 | Name: __ZN3RBX7Network15getNetAssetTypeINS_23DeltaConvexDecompHolderEEEtv
__int64 RBX::Network::getNetAssetType<RBX::DeltaConvexDecompHolder>()
{
  return 6; /*0x102a04b30*/
}

// Address: 0x102a04b32 | Name: __ZN3RBX7Network15getNetAssetTypeINS_22RuntimeContentNetAssetEEEtv
__int64 RBX::Network::getNetAssetType<RBX::RuntimeContentNetAsset>()
{
  return 7; /*0x102a04b3b*/
}

// Address: 0x102a04b3d | Name: __ZN3RBX7Network15getNetAssetTypeINS_11ImageHolderEEEtv
__int64 RBX::Network::getNetAssetType<RBX::ImageHolder>()
{
  return 8; /*0x102a04b46*/
}

// Address: 0x102a04b48 | Name: __ZN3RBX7Network15getNetAssetTypeINS_16DeltaImageHolderEEEtv
__int64 RBX::Network::getNetAssetType<RBX::DeltaImageHolder>()
{
  return 9; /*0x102a04b51*/
}

// Address: 0x102a04b53 | Name: __ZN3RBX7Network15getNetAssetTypeINS_22EditableMeshDataHolderEEEtv
__int64 RBX::Network::getNetAssetType<RBX::EditableMeshDataHolder>()
{
  return 10; /*0x102a04b5c*/
}

// Address: 0x102a04b5e | Name: __ZN3RBX7Network15getNetAssetTypeINS_27DeltaEditableMeshDataHolderEEEtv
__int64 RBX::Network::getNetAssetType<RBX::DeltaEditableMeshDataHolder>()
{
  return 11; /*0x102a04b67*/
}

// Address: 0x102a04b9c | Name: __ZN3RBX7Network9isVerboseEt
bool __fastcall RBX::Network::isVerbose(RBX::Network *this)
{
  return DFInt::NetAssetVerifiedTypes > (int)this; /*0x102a04ba9*/
}

// Address: 0x102a04bab | Name: __ZN3RBX7Network11isValidHashERKNSt3__15arrayIhLm16EEE
bool __fastcall RBX::Network::isValidHash(_BYTE *a1)
{
  bool result; // al
  unsigned __int64 v2; // rcx
  unsigned __int64 v3; // rax

  result = true; /*0x102a04baf*/
  if ( *a1 == 0 ) /*0x102a04bb4*/
  {
    v2 = 0; /*0x102a04bb6*/
    do /*0x102a04bca*/
    {
      v3 = v2; /*0x102a04bb8*/
      if ( v2 == 15 ) /*0x102a04bbf*/
        break; /*0x102a04bbf*/
      ++v2; /*0x102a04bc1*/
    }
    while ( a1[v3 + 1] == 0 ); /*0x102a04bca*/
    return v3 < 0xF; /*0x102a04bd0*/
  }
  return result; /*0x102a04bd3*/
}

// Address: 0x102a04bd5 | Name: __ZN3RBX7Network20generateNetAssetHashENS_9ArrayViewIhEERNSt3__15arrayIhLm16EEE
__int64 __fastcall RBX::Network::generateNetAssetHash(__int64 a1, __int64 a2, __int64 a3)
{
  return RBX::Network::generateNetAssetHash(a1, a2, a3, a4: 1); /*0x102a04bde*/
}

// Address: 0x102a04be4 | Name: __ZN3RBX7Network20generateNetAssetHashENS_9ArrayViewIhEERNSt3__15arrayIhLm16EEENS_6Crypto12HashFunctionE
void __fastcall RBX::Network::generateNetAssetHash(__int64 a1, __int64 a2, _OWORD *a3, int a4)
{
  void *v5; // rsi
  RBX::Memory *v6; // rdi
  char v7; // [rsp+8h] [rbp-28h] BYREF
  _QWORD v8[4]; // [rsp+9h] [rbp-27h]

  if ( a4 != 0 ) /*0x102a04bfa*/
  {
    if ( a4 != 1 ) /*0x102a04bff*/
      RBXCRASH(a1: "Invalid NetAssetHash", a2: "Invalid hashing function selected. Use blake2b or blake3."); /*0x102a04c5a*/
    RBX::Crypto::blake3(a1: &v7, a2: a1, a3: a2, a4: 16); /*0x102a04c0d*/
  }
  else
  {
    RBX::Crypto::blake2b(a1: &v7, a2: a1, a3: a2, a4: 16); /*0x102a04c20*/
  }
  if ( (v7 & 1) != 0 ) /*0x102a04c29*/
  {
    v6 = *(RBX::Memory **)((char *)&v8[1] + 7); /*0x102a04c34*/
    *a3 = **(_OWORD **)((char *)&v8[1] + 7); /*0x102a04c3b*/
    operator delete(a1: v6, a2: v5); /*0x102a04c3e*/
  }
  else
  {
    *a3 = *(_OWORD *)v8; /*0x102a04c2f*/
  }
}

// Address: 0x102a04c5f | Name: __ZN3RBX7Network17getPeerIdFromGuidEy
__int64 __fastcall RBX::Network::getPeerIdFromGuid(unsigned __int64 this)
{
  unsigned __int64 v1; // rdi
  int v2; // eax

  v1 = HIDWORD(this); /*0x102a04c6a*/
  v2 = 0xFFFFFF; /*0x102a04c76*/
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04c7b*/
    v2 = 0xFFFFF; /*0x102a04c7b*/
  return (unsigned int)v1 & v2; /*0x102a04c80*/
}

// Address: 0x102a04c82 | Name: __ZN3RBX7Network23getServerPeerIdFromGuidEy
__int64 __fastcall RBX::Network::getServerPeerIdFromGuid(unsigned __int64 this)
{
  return (unsigned __int8)(this >> 52); /*0x102a04c8e*/
}

// Address: 0x102a04c90 | Name: __ZN3RBX7Network16getFlagsFromGuidEy
unsigned __int64 __fastcall RBX::Network::getFlagsFromGuid(unsigned __int64 this)
{
  return this >> 60; /*0x102a04c9b*/
}

// Address: 0x102a04c9d | Name: __ZN3RBX7Network9setPeerIdEyNS_6PeerIdE
unsigned __int64 __fastcall RBX::Network::setPeerId(__int64 a1, __int64 a2)
{
  __int64 v2; // rsi
  __int64 v3; // rcx
  unsigned __int64 v4; // rax

  v2 = a2 << 32; /*0x102a04ca8*/
  v3 = 0xFFFFFF00000000LL; /*0x102a04cb9*/
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04cc3*/
    v3 = 0xFFFFF00000000LL; /*0x102a04cc3*/
  v4 = 0xFF000000FFFFFFFFLL; /*0x102a04cd1*/
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04cdb*/
    v4 = 0xFFF00000FFFFFFFFLL; /*0x102a04cdb*/
  return (a1 | v3) & (v2 | v4); /*0x102a04ce8*/
}

// Address: 0x102a04cea | Name: __ZN3RBX7Network15setServerPeerIdEyNS_6PeerIdE
unsigned __int64 __fastcall RBX::Network::setServerPeerId(__int64 a1, __int64 a2)
{
  return (a1 | 0xFF0000000000000LL) & ((a2 << 52) | 0xF00FFFFFFFFFFFFFLL); /*0x102a04d0f*/
}

// Address: 0x102a04d11 | Name: __ZN3RBX7Network22localToNetwork_contextEyNS_6PeerIdE
unsigned __int64 __fastcall RBX::Network::localToNetwork_context(unsigned __int64 a1, __int64 a2)
{
  unsigned __int64 result; // rax
  int v3; // r8d
  __int64 v4; // rsi
  __int64 v5; // rdx
  unsigned __int64 v6; // rdi

  result = a1; /*0x102a04d15*/
  v3 = 0xFFFFFF; /*0x102a04d2f*/
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04d35*/
    v3 = 0xFFFFF; /*0x102a04d35*/
  if ( (HIDWORD(a1) & v3) == 0 ) /*0x102a04d3c*/
  {
    v4 = a2 << 32; /*0x102a04d3e*/
    v5 = 0xFFFFFF00000000LL; /*0x102a04d4e*/
    if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04d58*/
      v5 = 0xFFFFF00000000LL; /*0x102a04d58*/
    v6 = 0xFF000000FFFFFFFFLL; /*0x102a04d66*/
    if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04d70*/
      v6 = 0xFFF00000FFFFFFFFLL; /*0x102a04d70*/
    return (result | v5) & (v4 | v6); /*0x102a04d7d*/
  }
  return result; /*0x102a04d80*/
}

// Address: 0x102a04d82 | Name: __ZN3RBX7Network24localToNetwork_subsystemEyNS_6PeerIdES1_
unsigned __int64 __fastcall RBX::Network::localToNetwork_subsystem(unsigned __int64 a1, __int64 a2, int a3)
{
  unsigned __int64 result; // rax
  unsigned __int64 v4; // rdi
  int v5; // r9d
  __int64 v6; // r9
  unsigned __int64 v7; // r10
  unsigned __int64 v8; // rdi

  result = a1; /*0x102a04d86*/
  v4 = HIDWORD(a1); /*0x102a04d92*/
  v5 = 0xFFFFFF; /*0x102a04d9e*/
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04da4*/
    v5 = 0xFFFFF; /*0x102a04da4*/
  if ( ((unsigned int)v4 & v5) == 0 ) /*0x102a04dab*/
  {
    v6 = 0xFFFFFF00000000LL; /*0x102a04dc0*/
    if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04dca*/
      v6 = 0xFFFFF00000000LL; /*0x102a04dca*/
    v7 = 0xFF000000FFFFFFFFLL; /*0x102a04dd8*/
    if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04de2*/
      v7 = 0xFFF00000FFFFFFFFLL; /*0x102a04de2*/
    result = (result | v6) & ((a2 << 32) | v7); /*0x102a04def*/
  }
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04df4*/
  {
    v8 = result & 0xF00FFFFFFFFFFFFFLL; /*0x102a04e0a*/
    if ( (unsigned __int8)(result >> 52) != a3 ) /*0x102a04e0f*/
      v8 = result; /*0x102a04e0f*/
    if ( (_DWORD)a2 != 1 ) /*0x102a04e16*/
      return v8; /*0x102a04e16*/
  }
  return result; /*0x102a04e1a*/
}

// Address: 0x102a04e1c | Name: __ZN3RBX7Network22networkToLocal_contextEyNS_6PeerIdE
unsigned __int64 __fastcall RBX::Network::networkToLocal_context(__int64 a1, int a2)
{
  unsigned __int64 v2; // rdx
  int v3; // r8d
  __int64 v4; // rax
  unsigned __int64 result; // rax

  v2 = 0xFF000000FFFFFFFFLL; /*0x102a04e37*/
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04e41*/
    v2 = 0xFFF00000FFFFFFFFLL; /*0x102a04e41*/
  v3 = 0xFFFFFF; /*0x102a04e4a*/
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04e50*/
    v3 = 0xFFFFF; /*0x102a04e50*/
  v4 = 0xF0000000000000LL; /*0x102a04e54*/
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04e5e*/
    v4 = 0; /*0x102a04e5e*/
  result = v2 & (a1 | v4); /*0x102a04e6f*/
  if ( (v3 & HIDWORD(a1)) != a2 ) /*0x102a04e74*/
    return a1; /*0x102a04e74*/
  return result; /*0x102a04e78*/
}

// Address: 0x102a04e7a | Name: __ZN3RBX7Network24networkToLocal_subsystemEyNS_6PeerIdES1_
unsigned __int64 __fastcall RBX::Network::networkToLocal_subsystem(unsigned __int64 a1, int a2, __int64 a3)
{
  unsigned __int64 v3; // r9
  int v4; // r10d
  __int64 v5; // r8
  unsigned __int64 v6; // r8
  unsigned __int64 result; // rax

  v3 = 0xFF000000FFFFFFFFLL; /*0x102a04e95*/
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04e9f*/
    v3 = 0xFFF00000FFFFFFFFLL; /*0x102a04e9f*/
  v4 = 0xFFFFFF; /*0x102a04ea9*/
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04eaf*/
    v4 = 0xFFFFF; /*0x102a04eaf*/
  v5 = 0xF0000000000000LL; /*0x102a04eb3*/
  if ( FFlag::NetAssetSubsystem != 0 ) /*0x102a04ebd*/
    v5 = 0; /*0x102a04ebd*/
  v6 = v3 & (a1 | v5); /*0x102a04ece*/
  if ( (v4 & HIDWORD(a1)) != a2 ) /*0x102a04ed3*/
    v6 = a1; /*0x102a04ed3*/
  result = (v6 | 0xFF0000000000000LL) & ((a3 << 52) | 0xF00FFFFFFFFFFFFFLL); /*0x102a04ef5*/
  if ( a2 == 1 ) /*0x102a04efb*/
    result = v6; /*0x102a04efb*/
  if ( FFlag::NetAssetSubsystem == 0 ) /*0x102a04f01*/
    return v6; /*0x102a04f01*/
  return result; /*0x102a04f05*/
}

// Address: 0x102a04f07 | Name: __ZN3RBX7Network20isHashedNetAssetGuidEy
bool __fastcall RBX::Network::isHashedNetAssetGuid(unsigned __int64 this)
{
  return this >> 60 == 1; /*0x102a04f15*/
}

// Address: 0x102a06826 | Name: __ZNK3RBX7Network10NetAssetIdltERKS1_
bool __fastcall RBX::Network::NetAssetId::operator<(__int64 a1, __int64 a2)
{
  bool v2; // cf

  v2 = *(_QWORD *)a1 < *(_QWORD *)a2; /*0x102a0682d*/
  if ( *(_QWORD *)a1 == *(_QWORD *)a2 ) /*0x102a06830*/
    return *(_DWORD *)(a1 + 8) < *(_DWORD *)(a2 + 8); /*0x102a06835*/
  return v2; /*0x102a0683b*/
}

// Address: 0x102a0683e | Name: __ZNK3RBX7Network14NetAssetHandleltERKS1_
bool __fastcall RBX::Network::NetAssetHandle::operator<(__int64 a1, __int64 a2)
{
  unsigned __int16 v2; // ax
  bool v3; // cf

  v2 = *(_WORD *)(a2 + 16); /*0x102a06842*/
  v3 = *(_WORD *)(a1 + 16) < v2; /*0x102a06846*/
  if ( *(_WORD *)(a1 + 16) == v2 ) /*0x102a0684a*/
  {
    v3 = *(_QWORD *)a1 < *(_QWORD *)a2; /*0x102a0684f*/
    if ( *(_QWORD *)a1 == *(_QWORD *)a2 ) /*0x102a06852*/
      return *(_DWORD *)(a1 + 8) < *(_DWORD *)(a2 + 8); /*0x102a06857*/
  }
  return v3; /*0x102a0685d*/
}

// Address: 0x102a0685f | Name: __ZN3RBX7Network22localToNetwork_contextERKNS0_10NetAssetIdENS_6PeerIdE
unsigned __int64 __fastcall RBX::Network::localToNetwork_context(unsigned __int64 *a1, __int64 a2)
{
  return RBX::Network::localToNetwork_context(a1: *a1, a2); /*0x102a06877*/
}

// Address: 0x102a0687a | Name: __ZN3RBX7Network24localToNetwork_subsystemERKNS0_10NetAssetIdENS_6PeerIdES4_
unsigned __int64 __fastcall RBX::Network::localToNetwork_subsystem(unsigned __int64 *a1, __int64 a2, int a3)
{
  return RBX::Network::localToNetwork_subsystem(a1: *a1, a2, a3); /*0x102a06892*/
}

// Address: 0x102a06895 | Name: __ZN3RBX7Network22networkToLocal_contextERKNS0_10NetAssetIdENS_6PeerIdE
unsigned __int64 __fastcall RBX::Network::networkToLocal_context(__int64 *a1, int a2)
{
  return RBX::Network::networkToLocal_context(a1: *a1, a2); /*0x102a068ad*/
}

// Address: 0x102a068b0 | Name: __ZN3RBX7Network24networkToLocal_subsystemERKNS0_10NetAssetIdENS_6PeerIdES4_
unsigned __int64 __fastcall RBX::Network::networkToLocal_subsystem(unsigned __int64 *a1, int a2, __int64 a3)
{
  return RBX::Network::networkToLocal_subsystem(a1: *a1, a2, a3); /*0x102a068c8*/
}

// Address: 0x102a068cb | Name: __ZN3RBX7Network22localToNetwork_contextERKNS0_14NetAssetHandleENS_6PeerIdE
__int64 __fastcall RBX::Network::localToNetwork_context(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned __int64 v5; // rax
  int v6; // ecx

  v5 = RBX::Network::localToNetwork_context(a1: *(_QWORD *)a2, a2: a3); /*0x102a068dd*/
  v6 = *(_DWORD *)(a2 + 8); /*0x102a068e2*/
  *(_QWORD *)a1 = v5; /*0x102a068e5*/
  *(_DWORD *)(a1 + 8) = v6; /*0x102a068e8*/
  *(_WORD *)(a1 + 16) = *(_WORD *)(a2 + 16); /*0x102a068f0*/
  return a1; /*0x102a068f8*/
}

// Address: 0x102a068fd | Name: __ZN3RBX7Network24localToNetwork_subsystemERKNS0_14NetAssetHandleENS_6PeerIdES4_
__int64 __fastcall RBX::Network::localToNetwork_subsystem(__int64 a1, __int64 a2, unsigned int a3, int a4)
{
  unsigned __int64 v6; // rax
  int v7; // ecx

  v6 = RBX::Network::localToNetwork_subsystem(a1: *(_QWORD *)a2, a2: a3, a3: a4); /*0x102a06911*/
  v7 = *(_DWORD *)(a2 + 8); /*0x102a06916*/
  *(_QWORD *)a1 = v6; /*0x102a06919*/
  *(_DWORD *)(a1 + 8) = v7; /*0x102a0691c*/
  *(_WORD *)(a1 + 16) = *(_WORD *)(a2 + 16); /*0x102a06924*/
  return a1; /*0x102a0692c*/
}

// Address: 0x102a06931 | Name: __ZN3RBX7Network22networkToLocal_contextERKNS0_14NetAssetHandleENS_6PeerIdE
__int64 __fastcall RBX::Network::networkToLocal_context(__int64 a1, __int64 a2, int a3)
{
  unsigned __int64 v5; // rax
  int v6; // ecx

  v5 = RBX::Network::networkToLocal_context(a1: *(_QWORD *)a2, a2: a3); /*0x102a06943*/
  v6 = *(_DWORD *)(a2 + 8); /*0x102a06948*/
  *(_QWORD *)a1 = v5; /*0x102a0694b*/
  *(_DWORD *)(a1 + 8) = v6; /*0x102a0694e*/
  *(_WORD *)(a1 + 16) = *(_WORD *)(a2 + 16); /*0x102a06956*/
  return a1; /*0x102a0695e*/
}

// Address: 0x102a06963 | Name: __ZN3RBX7Network24networkToLocal_subsystemERKNS0_14NetAssetHandleENS_6PeerIdES4_
__int64 __fastcall RBX::Network::networkToLocal_subsystem(__int64 a1, __int64 a2, int a3, unsigned int a4)
{
  unsigned __int64 v6; // rax
  int v7; // ecx

  v6 = RBX::Network::networkToLocal_subsystem(a1: *(_QWORD *)a2, a2: a3, a3: a4); /*0x102a06977*/
  v7 = *(_DWORD *)(a2 + 8); /*0x102a0697c*/
  *(_QWORD *)a1 = v6; /*0x102a0697f*/
  *(_DWORD *)(a1 + 8) = v7; /*0x102a06982*/
  *(_WORD *)(a1 + 16) = *(_WORD *)(a2 + 16); /*0x102a0698a*/
  return a1; /*0x102a06992*/
}

// Address: 0x102a06997 | Name: __ZN3RBX7Network22createHashedNetAssetIdEy
__int64 __fastcall RBX::Network::createHashedNetAssetId(RBX::Network *this)
{
  return (unsigned int)this | 0x1000000000000000LL; /*0x102a069a8*/
}

// Address: 0x102a069aa | Name: __ZN3RBX7Network18isHashedNetAssetIdERKNS0_10NetAssetIdE
bool __fastcall RBX::Network::isHashedNetAssetId(_QWORD *a1)
{
  return *a1 >> 60 == 1; /*0x102a069bb*/
}

// Address: 0x102a069bd | Name: __ZN3RBX7Network21getHashFromNetAssetIdERKNS0_10NetAssetIdE
unsigned __int64 __fastcall RBX::Network::getHashFromNetAssetId(unsigned int *a1)
{
  return *a1 | ((unsigned __int64)a1[2] << 32); /*0x102a069cd*/
}

// Address: 0x102a06a48 | Name: __ZN3RBX7Network23NetAssetHandleGeneratoraSEOS1_
__int64 __fastcall RBX::Network::NetAssetHandleGenerator::operator=(__int64 a1, __int64 a2)
{
  *(_WORD *)(a1 + 16) = *(_WORD *)(a2 + 16); /*0x102a06a53*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x102a06a5a*/
  *(_QWORD *)a2 = 0; /*0x102a06a5d*/
  *(_DWORD *)(a2 + 8) = 0; /*0x102a06a64*/
  *(_WORD *)(a2 + 16) = 0; /*0x102a06a6b*/
  return a1; /*0x102a06a71*/
}

// Address: 0x102a06ac0 | Name: __ZN3RBX7Network10hash_valueERKNS0_10NetAssetIdE
unsigned __int64 __fastcall RBX::Network::hash_value(__int64 a1)
{
  return (*(_QWORD *)a1 + 2654435769LL) /*0x102a06aec*/
       ^ (*(unsigned int *)(a1 + 8)
        + ((*(_QWORD *)a1 + 2654435769LL) << 6)
        + ((unsigned __int64)(*(_QWORD *)a1 + 2654435769LL) >> 2)
        + 2654435769u);
}

// Address: 0x102a06aee | Name: __ZN3RBX7Network10hash_valueERKNS0_14NetAssetHandleE
unsigned __int64 __fastcall RBX::Network::hash_value(__int64 a1)
{
  return (((*(_QWORD *)a1 + 2654435769LL) /*0x102a06b3b*/
         ^ (*(unsigned int *)(a1 + 8)
          + ((*(_QWORD *)a1 + 2654435769LL) << 6)
          + ((unsigned __int64)(*(_QWORD *)a1 + 2654435769LL) >> 2)
          + 2654435769u))
        + 2654435769u)
       ^ (*(unsigned __int16 *)(a1 + 16)
        + ((((*(_QWORD *)a1 + 2654435769LL)
           ^ (*(unsigned int *)(a1 + 8)
            + ((*(_QWORD *)a1 + 2654435769LL) << 6)
            + ((unsigned __int64)(*(_QWORD *)a1 + 2654435769LL) >> 2)
            + 2654435769u))
          + 2654435769u) << 6)
        + ((((*(_QWORD *)a1 + 2654435769LL)
           ^ (*(unsigned int *)(a1 + 8)
            + ((*(_QWORD *)a1 + 2654435769LL) << 6)
            + ((unsigned __int64)(*(_QWORD *)a1 + 2654435769LL) >> 2)
            + 2654435769u))
          + 2654435769u) >> 2)
        + 2654435769u);
}

// Address: 0x102a06b3d | Name: __ZN3RBX7Network10hash_valueERKNS0_11NetAssetRefE
__int64 __fastcall RBX::Network::hash_value(RBX::Network *this, const RBX::Network::NetAssetRef *a2)
{
  unsigned __int64 v2; // r8

  v2 = ((*((_QWORD *)this + 2) + 2654435769LL) /*0x102a06b6e*/
      ^ (*((unsigned int *)this + 6)
       + ((*((_QWORD *)this + 2) + 2654435769LL) << 6)
       + ((unsigned __int64)(*((_QWORD *)this + 2) + 2654435769LL) >> 2)
       + 2654435769u))
     + 2654435769u;
  return v2 ^ (*((unsigned __int16 *)this + 16) + (v2 << 6) + (v2 >> 2) + 2654435769u); /*0x102a06b8b*/
}

// Address: 0x102a06b8d | Name: __ZN3RBX7Network8toStringERNS0_10NetAssetIdE
__int64 __fastcall RBX::Network::toString(__int64 a1)
{
  fmt::v8::vformat(a1, a2: "g{}|v{}", 7, 36); /*0x102a06bbb*/
  return a1; /*0x102a06bc3*/
}

// Address: 0x102a06bca | Name: __ZN3RBX7Network8toStringERNS0_14NetAssetHandleE
__int64 __fastcall RBX::Network::toString(__int64 a1)
{
  fmt::v8::vformat(a1, a2: "g{}|v{}t{}", 10, 548); /*0x102a06c00*/
  return a1; /*0x102a06c08*/
}

// Address: 0x102a0a822 | Name: __ZN3RBX7Network11NetAssetRefaSEOS1_
RBX::Network::NetAssetRef *__fastcall RBX::Network::NetAssetRef::operator=(
        RBX::Network::NetAssetRef *this,
        __int128 *a2)
{
  std::__shared_weak_count *v4; // rdi
  volatile signed __int64 *v5; // r14
  std::__shared_weak_count *v6; // rdi
  volatile signed __int64 *v7; // r12
  __int128 v8; // xmm0
  __int64 v9; // rax
  std::__shared_weak_count *v10; // rdi
  std::__shared_weak_count *v11; // rdi

  v4 = *((std::__shared_weak_count **)this + 1); /*0x102a0a833*/
  if ( v4 != nullptr ) /*0x102a0a83a*/
    v5 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v4); /*0x102a0a841*/
  else
    v5 = nullptr; /*0x102a0a846*/
  v6 = *((std::__shared_weak_count **)a2 + 1); /*0x102a0a849*/
  if ( v6 != nullptr ) /*0x102a0a850*/
    v7 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v6); /*0x102a0a857*/
  else
    v7 = nullptr; /*0x102a0a85c*/
  RBX::Network::NetAssetRef::detach(this); /*0x102a0a862*/
  v8 = *a2; /*0x102a0a867*/
  v9 = *((_QWORD *)a2 + 1); /*0x102a0a86b*/
  if ( v9 != 0 ) /*0x102a0a872*/
    _InterlockedIncrement64((volatile signed __int64 *)(v9 + 16)); /*0x102a0a874*/
  v10 = *((std::__shared_weak_count **)this + 1); /*0x102a0a879*/
  *(_OWORD *)this = v8; /*0x102a0a87d*/
  if ( v10 != nullptr ) /*0x102a0a883*/
    std::__shared_weak_count::__release_weak(this: v10); /*0x102a0a885*/
  *((_WORD *)this + 16) = *((_WORD *)a2 + 16); /*0x102a0a88f*/
  *((_OWORD *)this + 1) = a2[1]; /*0x102a0a898*/
  *((_BYTE *)this + 40) = *((_BYTE *)a2 + 40); /*0x102a0a8a0*/
  v11 = *((std::__shared_weak_count **)a2 + 1); /*0x102a0a8a6*/
  *a2 = 0; /*0x102a0a8aa*/
  if ( v11 != nullptr ) /*0x102a0a8b1*/
    std::__shared_weak_count::__release_weak(this: v11); /*0x102a0a8b3*/
  *((_QWORD *)a2 + 2) = 0; /*0x102a0a8b8*/
  *((_DWORD *)a2 + 6) = 0; /*0x102a0a8c0*/
  *((_WORD *)a2 + 16) = 0; /*0x102a0a8c8*/
  *((_BYTE *)a2 + 40) = 0; /*0x102a0a8cf*/
  if ( v7 != nullptr && _InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x102a0a8ea*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(a1: v7); /*0x102a0a8f3*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v7); /*0x102a0a8f9*/
  }
  if ( v5 != nullptr && _InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x102a0a913*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(a1: v5); /*0x102a0a91b*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v5); /*0x102a0a921*/
  }
  return this; /*0x102a0a929*/
}

// Address: 0x102a0a93a | Name: __ZN3RBX7Network11NetAssetRefaSERKS1_
RBX::Network::NetAssetRef *__fastcall RBX::Network::NetAssetRef::operator=(
        std::__shared_weak_count **this,
        __int128 *a2)
{
  __int128 v4; // xmm0
  __int64 v5; // rax
  std::__shared_weak_count *v6; // rdi

  RBX::Network::NetAssetRef::detach((RBX::Network::NetAssetRef *)this); /*0x102a0a947*/
  v4 = *a2; /*0x102a0a94c*/
  v5 = *((_QWORD *)a2 + 1); /*0x102a0a950*/
  if ( v5 != 0 ) /*0x102a0a957*/
    _InterlockedIncrement64((volatile signed __int64 *)(v5 + 16)); /*0x102a0a959*/
  v6 = *(this + 1); /*0x102a0a95e*/
  *(_OWORD *)this = v4; /*0x102a0a962*/
  if ( v6 != nullptr ) /*0x102a0a968*/
    std::__shared_weak_count::__release_weak(this: v6); /*0x102a0a96a*/
  *((_WORD *)this + 16) = *((_WORD *)a2 + 16); /*0x102a0a974*/
  *((_OWORD *)this + 1) = a2[1]; /*0x102a0a97d*/
  *((_BYTE *)this + 40) = *((_BYTE *)a2 + 40); /*0x102a0a985*/
  RBX::Network::NetAssetRef::attach((RBX::Network::NetAssetRef *)this); /*0x102a0a98b*/
  return (RBX::Network::NetAssetRef *)this; /*0x102a0a993*/
}

// Address: 0x102a0aab9 | Name: __ZN3RBX7Network14toArrayViewAllERKNS0_20NetworkStreamContentE
__int64 __fastcall RBX::Network::toArrayViewAll(RBX::Network *this, const RBX::Network::NetworkStreamContent *a2)
{
  return *(_QWORD *)this; /*0x102a0aac3*/
}

// Address: 0x102a0aac5 | Name: __ZN3RBX7Network24toArrayViewRemainingReadERKNS0_20NetworkStreamContentE
__int64 __fastcall RBX::Network::toArrayViewRemainingRead(
        RBX::Network *this,
        const RBX::Network::NetworkStreamContent *a2)
{
  __int64 v2; // rbx

  v2 = *(_QWORD *)this + *((unsigned int *)this + 10); /*0x102a0aace*/
  RBX::Network::NetworkStreamContent::GetNumberOfUnreadBytes(this); /*0x102a0aad1*/
  return v2; /*0x102a0aadf*/
}

// Address: 0x102a0aae2 | Name: __ZN3RBX7Network21toMutableArrayViewAllERNS0_20NetworkStreamContentE
__int64 __fastcall RBX::Network::toMutableArrayViewAll(RBX::Network *this, RBX::Network::NetworkStreamContent *a2)
{
  return *(_QWORD *)this; /*0x102a0aaec*/
}

// Address: 0x102a0aaee | Name: __ZN3RBX7Network31toMutableArrayViewRemainingReadERNS0_20NetworkStreamContentE
__int64 __fastcall RBX::Network::toMutableArrayViewRemainingRead(
        RBX::Network *this,
        RBX::Network::NetworkStreamContent *a2)
{
  __int64 v2; // rbx

  v2 = *(_QWORD *)this + *((unsigned int *)this + 10); /*0x102a0aaf7*/
  RBX::Network::NetworkStreamContent::GetNumberOfUnreadBytes(this); /*0x102a0aafa*/
  return v2; /*0x102a0ab08*/
}

// Address: 0x102a0c0da | Name: __ZN3RBX7Network13NetworkStreamaSEOS1_
RBX::Network::NetworkStream *__fastcall RBX::Network::NetworkStream::operator=(
        RBX::Network::NetworkStream *a1,
        RBX::Network::NetworkStream *a2)
{
  RBX::Network::NetworkStream::swap(this: a1, a2); /*0x102a0c0e3*/
  return a1; /*0x102a0c0ef*/
}

// Address: 0x102a0ca4a | Name: __ZN3RBX7Network23serializeUnsignedVarintEjRNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::serializeUnsignedVarint(
        RBX::Network *this,
        unsigned __int64 a2,
        RBX::Network::NetworkStream *a3)
{
  return RBX::Network::serializeUInt64Varint((RBX::Network *)(unsigned int)this, a2, a3); /*0x102a0ca50*/
}

// Address: 0x102a0cb2b | Name: __ZN3RBX7Network23serializeSignedVarint64ExRNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::serializeSignedVarint64(
        __int64 this,
        unsigned __int64 a2,
        RBX::Network::NetworkStream *a3)
{
  return RBX::Network::serializeUInt64Varint(this: (RBX::Network *)((2 * this) ^ (this >> 63)), a2, a3); /*0x102a0cb3a*/
}

// Address: 0x102a0cb40 | Name: __ZN3RBX7NetworkL21serializeUInt64VarintEyRNS0_13NetworkStreamE
unsigned __int64 __fastcall RBX::Network::serializeUInt64Varint(
        unsigned __int64 this,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3)
{
  unsigned int v5; // r12d
  unsigned __int64 result; // rax
  bool v7; // cf
  bool v8; // zf
  _BYTE v9[33]; // [rsp+Fh] [rbp-21h] BYREF

  v5 = 0; /*0x102a0cb55*/
  do /*0x102a0cb98*/
  {
    v9[0] = this & 0x7F | ((this > 0x7F) << 7); /*0x102a0cb6e*/
    result = RBX::Network::NetworkStream::writeBytes(this: a2, a2: v9, a3: 1u); /*0x102a0cb7c*/
    if ( v5 > 8 ) /*0x102a0cb85*/
      break; /*0x102a0cb85*/
    result = this >> 7; /*0x102a0cb8a*/
    ++v5; /*0x102a0cb8e*/
    v7 = this < 0x7F; /*0x102a0cb91*/
    v8 = this == 127; /*0x102a0cb91*/
    this >>= 7; /*0x102a0cb95*/
  }
  while ( !v7 && !v8 ); /*0x102a0cb98*/
  return result; /*0x102a0cb9a*/
}

// Address: 0x102a0cba7 | Name: __ZN3RBX7Network25deserializeUnsignedVarintERjRNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::deserializeUnsignedVarint(
        RBX::Network *this,
        unsigned int *a2,
        RBX::Network::NetworkStream *a3)
{
  __int64 result; // rax
  _QWORD v5[3]; // [rsp+8h] [rbp-18h] BYREF

  v5[0] = *(unsigned int *)this; /*0x102a0cbbb*/
  RBX::Network::deserializeUInt64Varint(this: (RBX::Network *)v5, (unsigned __int64 *)a2, a3); /*0x102a0cbc1*/
  result = LODWORD(v5[0]); /*0x102a0cbc6*/
  *(_DWORD *)this = v5[0]; /*0x102a0cbc9*/
  return result; /*0x102a0cbcb*/
}

// Address: 0x102a0cbd4 | Name: __ZN3RBX7NetworkL23deserializeUInt64VarintERyRNS0_13NetworkStreamE
RBX::Network *__fastcall RBX::Network::deserializeUInt64Varint(
        RBX::Network *this,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3)
{
  unsigned int NumberOfUnreadBytes; // eax
  __int64 v5; // r13
  char v6; // r15
  unsigned __int64 v7; // r12
  __int64 v8; // rbx
  char *exception; // r14
  __int64 v11; // rdx
  __int64 v12; // rcx
  char *v13; // r14
  __int64 v14; // rdx
  __int64 v15; // rcx
  __int128 v17; // [rsp+10h] [rbp-70h] BYREF
  __int64 v18; // [rsp+20h] [rbp-60h]
  __int128 v19; // [rsp+30h] [rbp-50h] BYREF
  __int64 v20; // [rsp+40h] [rbp-40h]
  char v21[41]; // [rsp+57h] [rbp-29h] BYREF

  if ( DFFlag::NetworkStreamUnderflowProtection == 1 ) /*0x102a0cbf3*/
    NumberOfUnreadBytes = RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: a2); /*0x102a0cbf8*/
  else
    NumberOfUnreadBytes = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *, RBX::Network::NetworkStream *, RBX::Network::NetworkStream *))(*(_QWORD *)a2 + 24LL))( /*0x102a0cc08*/
                            a1: a2,
                            a2,
                            a3)
                        - *((_DWORD *)a2 + 14);
  v5 = NumberOfUnreadBytes; /*0x102a0cc0c*/
  v6 = 0; /*0x102a0cc0f*/
  v7 = 0; /*0x102a0cc12*/
  v8 = 0; /*0x102a0cc15*/
  do /*0x102a0cc4d*/
  {
    v21[0] = 0; /*0x102a0cc17*/
    if ( v5 == v7 ) /*0x102a0cc1e*/
    {
      exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0cc73*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v17, a2: "varint decode read past end", a3: v11, a4: v12); /*0x102a0cc81*/
      *(_QWORD *)exception = off_10CAA98E0; /*0x102a0cc8d*/
      *((_QWORD *)exception + 3) = v18; /*0x102a0cc94*/
      *(_OWORD *)(exception + 8) = v17; /*0x102a0cc9c*/
      v17 = 0; /*0x102a0cca4*/
      v18 = 0; /*0x102a0cca8*/
      __cxa_throw( /*0x102a0ccc1*/
        a1: exception,
        lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
        a3: RBX::network_stream_exception::~network_stream_exception);
    }
    `anonymous namespace'::deserializeNumber<unsigned char,unsigned char>(a1: a2, a2: v21); /*0x102a0cc27*/
    v8 |= (unsigned __int64)(v21[0] & 0x7F) << v6; /*0x102a0cc3b*/
    if ( v7 > 8 ) /*0x102a0cc42*/
      break; /*0x102a0cc42*/
    ++v7; /*0x102a0cc44*/
    v6 += 7; /*0x102a0cc47*/
  }
  while ( v21[0] < 0 ); /*0x102a0cc4d*/
  if ( v21[0] < 0 ) /*0x102a0cc51*/
  {
    v13 = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0ccd2*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v19, a2: "varint decode larger than maximum size", a3: v14, a4: v15); /*0x102a0cce0*/
    *(_QWORD *)v13 = off_10CAA98E0; /*0x102a0ccec*/
    *((_QWORD *)v13 + 3) = v20; /*0x102a0ccf3*/
    *(_OWORD *)(v13 + 8) = v19; /*0x102a0ccfb*/
    v19 = 0; /*0x102a0cd03*/
    v20 = 0; /*0x102a0cd07*/
    __cxa_throw( /*0x102a0cd20*/
      a1: v13,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  *(_QWORD *)this = v8; /*0x102a0cc57*/
  return this; /*0x102a0cc5a*/
}

// Address: 0x102a0cd5f | Name: __ZN3RBX7Network21serializeSignedVarintEiRNS0_13NetworkStreamE
unsigned __int64 __fastcall RBX::Network::serializeSignedVarint(
        RBX::Network *this,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3)
{
  return RBX::Network::serializeUInt64Varint(this: (2 * (_DWORD)this) ^ (unsigned int)((int)this >> 31), a2, a3); /*0x102a0cd6b*/
}

// Address: 0x102a0cd71 | Name: __ZN3RBX7Network23deserializeSignedVarintERiRNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::deserializeSignedVarint(
        RBX::Network *this,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3)
{
  __int64 result; // rax
  _QWORD v5[3]; // [rsp+8h] [rbp-18h] BYREF

  v5[0] = 0; /*0x102a0cd83*/
  RBX::Network::deserializeUInt64Varint(this: (RBX::Network *)v5, a2, a3); /*0x102a0cd8d*/
  result = (LODWORD(v5[0]) >> 1) ^ -(v5[0] & 1); /*0x102a0cd9e*/
  *(_DWORD *)this = result; /*0x102a0cda0*/
  return result; /*0x102a0cda2*/
}

// Address: 0x102a0cdab | Name: __ZN3RBX7Network25deserializeSignedVarint64ERxRNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::deserializeSignedVarint64(
        RBX::Network *this,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3)
{
  __int64 result; // rax
  _QWORD v5[3]; // [rsp+8h] [rbp-18h] BYREF

  RBX::Network::deserializeUInt64Varint(this: (RBX::Network *)v5, a2, a3); /*0x102a0cdc0*/
  result = (v5[0] >> 1) ^ -(__int64)(v5[0] & 1); /*0x102a0cdd4*/
  *(_QWORD *)this = result; /*0x102a0cdd7*/
  return result; /*0x102a0cdda*/
}

// Address: 0x102a0cde3 | Name: __ZN3RBX7Network15serializeStringERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERNS0_13NetworkStreamEi
__int64 __fastcall RBX::Network::serializeString(
        unsigned __int8 *a1,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3)
{
  unsigned int v5; // r15d
  __int64 v6; // r15
  unsigned int v7; // edx
  unsigned int v8; // edx
  const void *v9; // r14
  char *exception; // rbx
  __int64 v12; // rcx
  __int64 v13; // r8
  __int64 v14; // r9
  __m128 v15; // xmm0
  __m128 v16; // xmm1
  __m128 v17; // xmm2
  __m128 v18; // xmm3
  __m128 v19; // xmm4
  __m128 v20; // xmm5
  __m128 v21; // xmm6
  __m128 v22; // xmm7
  __int128 v23; // [rsp+0h] [rbp-30h] BYREF
  __int64 v24; // [rsp+10h] [rbp-20h]

  v5 = *a1; /*0x102a0cdf6*/
  if ( (v5 & 1) != 0 ) /*0x102a0cdfe*/
    v6 = *((_QWORD *)a1 + 1); /*0x102a0ce00*/
  else
    LODWORD(v6) = v5 >> 1; /*0x102a0ce06*/
  if ( (unsigned int)v6 > (unsigned int)a3 )
  {
    exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0ce50*/
    RBX::format(
      this: (RBX *)&v23,
      a2: "BitStream string write: String too long: %u",
      a3: (unsigned int)v6,
      a4: v12,
      a5: v13,
      a6: v14,
      a7: v15,
      a8: v16,
      a9: v17,
      a10: v18,
      a11: v19,
      a12: v20,
      a13: v21,
      a14: v22,
      a15: v23);
    *(_QWORD *)exception = off_10CAA98E0; /*0x102a0ce6f*/
    *((_QWORD *)exception + 3) = v24; /*0x102a0ce76*/
    *(_OWORD *)(exception + 8) = v23; /*0x102a0ce7e*/
    v23 = 0; /*0x102a0ce85*/
    v24 = 0; /*0x102a0ce89*/
    __cxa_throw( /*0x102a0cea2*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  RBX::Network::serializeUInt64Varint(this: (unsigned int)v6, a2, a3); /*0x102a0ce14*/
  v7 = *a1; /*0x102a0ce19*/
  if ( (v7 & 1) != 0 ) /*0x102a0ce20*/
  {
    v8 = *((_DWORD *)a1 + 2); /*0x102a0ce22*/
    v9 = *((const void **)a1 + 2); /*0x102a0ce26*/
  }
  else
  {
    v9 = a1 + 1; /*0x102a0ce2c*/
    v8 = v7 >> 1; /*0x102a0ce2f*/
  }
  return RBX::Network::NetworkStream::writeBytes(this: a2, a2: v9, a3: v8); /*0x102a0ce37*/
}

// Address: 0x102a0ced0 | Name: __ZN3RBX7Network17deserializeStringERNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERNS0_13NetworkStreamEi
__int64 __fastcall RBX::Network::deserializeString(
        __int64 a1,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3)
{
  unsigned int v3; // r12d
  unsigned int v6; // r15d
  unsigned int NumberOfUnreadBytes; // eax
  unsigned int v8; // r12d
  __int64 result; // rax
  void *v10; // rbx
  char *exception; // r14
  char *v12; // r14
  __int64 v13; // rcx
  __int64 v14; // r8
  __int64 v15; // r9
  __m128 v16; // xmm0
  __m128 v17; // xmm1
  __m128 v18; // xmm2
  __m128 v19; // xmm3
  __m128 v20; // xmm4
  __m128 v21; // xmm5
  __m128 v22; // xmm6
  __m128 v23; // xmm7
  __int64 v24; // [rsp+0h] [rbp-70h] BYREF
  __int128 v25; // [rsp+10h] [rbp-60h] BYREF
  __int64 v26; // [rsp+20h] [rbp-50h]
  __int128 v27; // [rsp+30h] [rbp-40h] BYREF
  __int64 v28; // [rsp+40h] [rbp-30h]

  v3 = (unsigned int)a3; /*0x102a0cee1*/
  v24 = 0; /*0x102a0ceee*/
  RBX::Network::deserializeUInt64Varint(this: (RBX::Network *)&v24, a2, a3); /*0x102a0cef8*/
  v6 = v24; /*0x102a0cefd*/
  if ( ((unsigned __int8)DFFlag::FixStringCheckInNS & ((unsigned int)v24 > v3)) == 1 )
  {
    exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0cf7c*/
    v24 = v6 - v3; /*0x102a0cf83*/
    fmt::v8::vformat(a1: &v25, a2: "BitStream string read: String too long by {}", 44, 2);
    *(_QWORD *)exception = off_10CAA98E0; /*0x102a0cfa7*/
    *((_QWORD *)exception + 3) = v26; /*0x102a0cfae*/
    *(_OWORD *)(exception + 8) = v25; /*0x102a0cfb6*/
    v25 = 0; /*0x102a0cfbe*/
    v26 = 0; /*0x102a0cfc2*/
    __cxa_throw( /*0x102a0cfdb*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  NumberOfUnreadBytes = RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: a2); /*0x102a0cf16*/
  v8 = v6 - NumberOfUnreadBytes; /*0x102a0cf1e*/
  if ( v6 > NumberOfUnreadBytes )
  {
    v12 = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0cfec*/
    RBX::format(
      this: (RBX *)&v27,
      a2: "BitStream string read: String too long by: %u",
      a3: v8,
      a4: v13,
      a5: v14,
      a6: v15,
      a7: v16,
      a8: v17,
      a9: v18,
      a10: v19,
      a11: v20,
      a12: v21,
      a13: v22,
      a14: v23,
      a15: v24);
    *(_QWORD *)v12 = off_10CAA98E0; /*0x102a0d00b*/
    *((_QWORD *)v12 + 3) = v28; /*0x102a0d012*/
    *(_OWORD *)(v12 + 8) = v27; /*0x102a0d01a*/
    v27 = 0; /*0x102a0d022*/
    v28 = 0; /*0x102a0d026*/
    __cxa_throw( /*0x102a0d03f*/
      a1: v12,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  result = std::string::resize(a1, a2: v6, a3: 0); /*0x102a0cf2f*/
  if ( v6 != 0 ) /*0x102a0cf37*/
  {
    if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x102a0cf3c*/
      v10 = *(void **)(a1 + 16); /*0x102a0cf3e*/
    else
      v10 = (void *)(a1 + 1); /*0x102a0cf53*/
    return RBX::Network::NetworkStream::readBytes(this: a2, a2: v10, a3: v6); /*0x102a0cf6d*/
  }
  return result; /*0x102a0cf44*/
}

// Address: 0x102a0d07e | Name: __ZN3RBX7Network30deserializeStringPrependPrefixERNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERKS7_RNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::deserializeStringPrependPrefix(
        __int64 a1,
        unsigned __int8 *a2,
        RBX::Network::NetworkStream *a3)
{
  unsigned int v6; // r14d
  unsigned int NumberOfUnreadBytes; // eax
  unsigned int v8; // r13d
  unsigned int v9; // ebx
  __int64 v10; // rbx
  __int64 v11; // r13
  __int64 v12; // rsi
  unsigned int v13; // edx
  __int64 v14; // rdx
  __int64 result; // rax
  char *exception; // rbx
  __int64 v17; // rcx
  __int64 v18; // r8
  __int64 v19; // r9
  __m128 v20; // xmm0
  __m128 v21; // xmm1
  __m128 v22; // xmm2
  __m128 v23; // xmm3
  __m128 v24; // xmm4
  __m128 v25; // xmm5
  __m128 v26; // xmm6
  __m128 v27; // xmm7
  __int64 v28; // [rsp+0h] [rbp-50h] BYREF
  RBX::Network::NetworkStream *v29; // [rsp+8h] [rbp-48h]
  __int128 v30; // [rsp+10h] [rbp-40h] BYREF
  __int64 v31; // [rsp+20h] [rbp-30h]

  v28 = 0; /*0x102a0d09c*/
  RBX::Network::deserializeUInt64Varint(this: (RBX::Network *)&v28, a2: a3, a3); /*0x102a0d0a9*/
  v6 = v28; /*0x102a0d0ae*/
  v29 = a3; /*0x102a0d0b1*/
  NumberOfUnreadBytes = RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: a3); /*0x102a0d0b8*/
  v8 = v6 - NumberOfUnreadBytes; /*0x102a0d0c0*/
  if ( v6 > NumberOfUnreadBytes )
  {
    exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0d163*/
    RBX::format(
      this: (RBX *)&v30,
      a2: "BitStream string read: String too long by: %u",
      a3: v8,
      a4: v17,
      a5: v18,
      a6: v19,
      a7: v20,
      a8: v21,
      a9: v22,
      a10: v23,
      a11: v24,
      a12: v25,
      a13: v26,
      a14: v27,
      a15: v28);
    *(_QWORD *)exception = off_10CAA98E0; /*0x102a0d182*/
    *((_QWORD *)exception + 3) = v31; /*0x102a0d189*/
    *(_OWORD *)(exception + 8) = v30; /*0x102a0d191*/
    v30 = 0; /*0x102a0d198*/
    v31 = 0; /*0x102a0d19c*/
    __cxa_throw( /*0x102a0d1b5*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  v9 = *a2; /*0x102a0d0c9*/
  if ( (v9 & 1) != 0 ) /*0x102a0d0d1*/
    v10 = *((_QWORD *)a2 + 1); /*0x102a0d0d3*/
  else
    LODWORD(v10) = v9 >> 1; /*0x102a0d0da*/
  std::string::resize(a1, a2: (unsigned int)v10 + v6, a3: 0); /*0x102a0d0e6*/
  v11 = a1 + 1; /*0x102a0d0eb*/
  v12 = a1 + 1; /*0x102a0d0f3*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x102a0d0f6*/
    v12 = *(_QWORD *)(a1 + 16); /*0x102a0d0f8*/
  v13 = *a2; /*0x102a0d0fc*/
  if ( (v13 & 1) != 0 ) /*0x102a0d104*/
    v14 = *((_QWORD *)a2 + 1); /*0x102a0d106*/
  else
    v14 = v13 >> 1; /*0x102a0d10d*/
  result = std::string::copy(a1: a2, a2: v12, a3: v14, a4: 0); /*0x102a0d114*/
  if ( v6 != 0 ) /*0x102a0d11c*/
  {
    if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x102a0d124*/
      v11 = *(_QWORD *)(a1 + 16); /*0x102a0d126*/
    return RBX::Network::NetworkStream::readBytes(this: v29, a2: (void *)((unsigned int)v10 + v11), a3: v6); /*0x102a0d145*/
  }
  return result; /*0x102a0d137*/
}

// Address: 0x102a0d1e3 | Name: __ZN3RBX7Network22serializeRbxStringViewERKNS_10StringViewERNS0_13NetworkStreamEi
__int64 __fastcall RBX::Network::serializeRbxStringView(
        __int64 a1,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3)
{
  __int64 v3; // r14
  char *exception; // rbx
  __int64 v8; // rcx
  __int64 v9; // r8
  __int64 v10; // r9
  __m128 v11; // xmm0
  __m128 v12; // xmm1
  __m128 v13; // xmm2
  __m128 v14; // xmm3
  __m128 v15; // xmm4
  __m128 v16; // xmm5
  __m128 v17; // xmm6
  __m128 v18; // xmm7
  __int128 v19; // [rsp+0h] [rbp-30h] BYREF
  __int64 v20; // [rsp+10h] [rbp-20h]

  v3 = *(_QWORD *)(a1 + 8); /*0x102a0d1f0*/
  if ( (unsigned int)v3 > (unsigned int)a3 )
  {
    exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0d22a*/
    RBX::format(
      this: (RBX *)&v19,
      a2: "BitStream string write: String too long: %u",
      a3: (unsigned int)v3,
      a4: v8,
      a5: v9,
      a6: v10,
      a7: v11,
      a8: v12,
      a9: v13,
      a10: v14,
      a11: v15,
      a12: v16,
      a13: v17,
      a14: v18,
      a15: v19);
    *(_QWORD *)exception = off_10CAA98E0; /*0x102a0d249*/
    *((_QWORD *)exception + 3) = v20; /*0x102a0d250*/
    *(_OWORD *)(exception + 8) = v19; /*0x102a0d258*/
    v19 = 0; /*0x102a0d25f*/
    v20 = 0; /*0x102a0d263*/
    __cxa_throw( /*0x102a0d27c*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  RBX::Network::serializeUInt64Varint(this: (unsigned int)v3, a2, a3); /*0x102a0d202*/
  return RBX::Network::NetworkStream::writeBytes(this: a2, a2: *(const void **)a1, a3: *(_DWORD *)(a1 + 8)); /*0x102a0d211*/
}

// Address: 0x102a0e822 | Name: __ZN3RBX7Network23serializeUnsignedVarintEjRNS0_20NetworkStreamContentE
__int64 __fastcall RBX::Network::serializeUnsignedVarint(
        RBX::Network *this,
        unsigned __int64 a2,
        RBX::Network::NetworkStreamContent *a3)
{
  return RBX::Network::serializeUInt64Varint((RBX::Network *)(unsigned int)this, a2, a3); /*0x102a0e828*/
}

// Address: 0x102a0e82e | Name: __ZN3RBX7NetworkL21serializeUInt64VarintEyRNS0_20NetworkStreamContentE
unsigned __int64 __fastcall RBX::Network::serializeUInt64Varint(
        unsigned __int64 this,
        RBX::Network::NetworkStreamContent *a2,
        RBX::Network::NetworkStreamContent *a3)
{
  unsigned int v5; // r15d
  unsigned __int64 result; // rax
  bool v7; // cc

  v5 = 0; /*0x102a0e83f*/
  do /*0x102a0e887*/
  {
    RBX::Network::NetworkStreamContent::AddBytesAndReallocate(this: a2, a2: 1u); /*0x102a0e85e*/
    result = *(_QWORD *)a2; /*0x102a0e863*/
    *(_BYTE *)(*(_QWORD *)a2 + (unsigned int)(*((_DWORD *)a2 + 8))++) = this & 0x7F | ((this > 0x7F) << 7); /*0x102a0e869*/
    if ( v5 > 8 ) /*0x102a0e874*/
      break; /*0x102a0e874*/
    result = this >> 7; /*0x102a0e879*/
    ++v5; /*0x102a0e87d*/
    v7 = this <= 0x7F; /*0x102a0e880*/
    this >>= 7; /*0x102a0e884*/
  }
  while ( !v7 ); /*0x102a0e887*/
  return result; /*0x102a0e889*/
}

// Address: 0x102a0e892 | Name: __ZN3RBX7Network25deserializeUnsignedVarintERjRNS0_20NetworkStreamContentE
__int64 __fastcall RBX::Network::deserializeUnsignedVarint(
        RBX::Network *this,
        unsigned int *a2,
        RBX::Network::NetworkStreamContent *a3)
{
  __int64 result; // rax
  _QWORD v5[3]; // [rsp+8h] [rbp-18h] BYREF

  v5[0] = *(unsigned int *)this; /*0x102a0e8a6*/
  RBX::Network::deserializeUInt64Varint(this: (RBX::Network *)v5, (unsigned __int64 *)a2, a3); /*0x102a0e8ac*/
  result = LODWORD(v5[0]); /*0x102a0e8b1*/
  *(_DWORD *)this = v5[0]; /*0x102a0e8b4*/
  return result; /*0x102a0e8b6*/
}

// Address: 0x102a0e8bf | Name: __ZN3RBX7NetworkL23deserializeUInt64VarintERyRNS0_20NetworkStreamContentE
RBX::Network *__fastcall RBX::Network::deserializeUInt64Varint(
        RBX::Network *this,
        RBX::Network::NetworkStreamContent *a2,
        RBX::Network::NetworkStreamContent *a3)
{
  unsigned int NumberOfUnreadBytes; // eax
  __int64 v5; // r13
  char v6; // r15
  unsigned __int64 v7; // r12
  __int64 v8; // rbx
  char *exception; // r14
  __int64 v11; // rdx
  __int64 v12; // rcx
  char *v13; // r14
  __int64 v14; // rdx
  __int64 v15; // rcx
  __int128 v17; // [rsp+10h] [rbp-70h] BYREF
  __int64 v18; // [rsp+20h] [rbp-60h]
  __int128 v19; // [rsp+30h] [rbp-50h] BYREF
  __int64 v20; // [rsp+40h] [rbp-40h]
  char v21[41]; // [rsp+57h] [rbp-29h] BYREF

  if ( DFFlag::NetworkStreamUnderflowProtection == 1 ) /*0x102a0e8e1*/
    NumberOfUnreadBytes = RBX::Network::NetworkStreamContent::GetNumberOfUnreadBytes(this: a2); /*0x102a0e8e6*/
  else
    NumberOfUnreadBytes = *((_DWORD *)a2 + 8) - *((_DWORD *)a2 + 10); /*0x102a0e8f1*/
  v5 = NumberOfUnreadBytes; /*0x102a0e8f5*/
  v6 = 0; /*0x102a0e8f8*/
  v7 = 0; /*0x102a0e8fb*/
  v8 = 0; /*0x102a0e8fe*/
  do /*0x102a0e936*/
  {
    v21[0] = 0; /*0x102a0e900*/
    if ( v5 == v7 ) /*0x102a0e907*/
    {
      exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0e95c*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v17, a2: "varint decode read past end", a3: v11, a4: v12); /*0x102a0e96a*/
      *(_QWORD *)exception = off_10CAA98E0; /*0x102a0e976*/
      *((_QWORD *)exception + 3) = v18; /*0x102a0e97d*/
      *(_OWORD *)(exception + 8) = v17; /*0x102a0e985*/
      v17 = 0; /*0x102a0e98d*/
      v18 = 0; /*0x102a0e991*/
      __cxa_throw( /*0x102a0e9aa*/
        a1: exception,
        lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
        a3: RBX::network_stream_exception::~network_stream_exception);
    }
    `anonymous namespace'::deserializeNumber<unsigned char,unsigned char>(a1: a2, a2: v21); /*0x102a0e910*/
    v8 |= (unsigned __int64)(v21[0] & 0x7F) << v6; /*0x102a0e924*/
    if ( v7 > 8 ) /*0x102a0e92b*/
      break; /*0x102a0e92b*/
    ++v7; /*0x102a0e92d*/
    v6 += 7; /*0x102a0e930*/
  }
  while ( v21[0] < 0 ); /*0x102a0e936*/
  if ( v21[0] < 0 ) /*0x102a0e93a*/
  {
    v13 = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0e9bb*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v19, a2: "varint decode larger than maximum size", a3: v14, a4: v15); /*0x102a0e9c9*/
    *(_QWORD *)v13 = off_10CAA98E0; /*0x102a0e9d5*/
    *((_QWORD *)v13 + 3) = v20; /*0x102a0e9dc*/
    *(_OWORD *)(v13 + 8) = v19; /*0x102a0e9e4*/
    v19 = 0; /*0x102a0e9ec*/
    v20 = 0; /*0x102a0e9f0*/
    __cxa_throw( /*0x102a0ea09*/
      a1: v13,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  *(_QWORD *)this = v8; /*0x102a0e940*/
  return this; /*0x102a0e943*/
}

// Address: 0x102a0ea48 | Name: __ZN3RBX7Network21serializeSignedVarintEiRNS0_20NetworkStreamContentE
unsigned __int64 __fastcall RBX::Network::serializeSignedVarint(
        RBX::Network *this,
        RBX::Network::NetworkStreamContent *a2,
        RBX::Network::NetworkStreamContent *a3)
{
  return RBX::Network::serializeUInt64Varint(this: (2 * (_DWORD)this) ^ (unsigned int)((int)this >> 31), a2, a3); /*0x102a0ea54*/
}

// Address: 0x102a0ea5a | Name: __ZN3RBX7Network23deserializeSignedVarintERiRNS0_20NetworkStreamContentE
__int64 __fastcall RBX::Network::deserializeSignedVarint(
        RBX::Network *this,
        RBX::Network::NetworkStreamContent *a2,
        RBX::Network::NetworkStreamContent *a3)
{
  __int64 result; // rax
  _QWORD v5[3]; // [rsp+8h] [rbp-18h] BYREF

  v5[0] = 0; /*0x102a0ea6c*/
  RBX::Network::deserializeUInt64Varint(this: (RBX::Network *)v5, a2, a3); /*0x102a0ea76*/
  result = (LODWORD(v5[0]) >> 1) ^ -(v5[0] & 1); /*0x102a0ea87*/
  *(_DWORD *)this = result; /*0x102a0ea89*/
  return result; /*0x102a0ea8b*/
}

// Address: 0x102a0ea94 | Name: __ZN3RBX7Network23serializeSignedVarint64ExRNS0_20NetworkStreamContentE
unsigned __int64 __fastcall RBX::Network::serializeSignedVarint64(
        __int64 this,
        RBX::Network::NetworkStreamContent *a2,
        RBX::Network::NetworkStreamContent *a3)
{
  return RBX::Network::serializeUInt64Varint(this: (2 * this) ^ (this >> 63), a2, a3); /*0x102a0eaa3*/
}

// Address: 0x102a0eaa9 | Name: __ZN3RBX7Network25deserializeSignedVarint64ERxRNS0_20NetworkStreamContentE
__int64 __fastcall RBX::Network::deserializeSignedVarint64(
        RBX::Network *this,
        RBX::Network::NetworkStreamContent *a2,
        RBX::Network::NetworkStreamContent *a3)
{
  __int64 result; // rax
  _QWORD v5[3]; // [rsp+8h] [rbp-18h] BYREF

  RBX::Network::deserializeUInt64Varint(this: (RBX::Network *)v5, a2, a3); /*0x102a0eabe*/
  result = (v5[0] >> 1) ^ -(__int64)(v5[0] & 1); /*0x102a0ead2*/
  *(_QWORD *)this = result; /*0x102a0ead5*/
  return result; /*0x102a0ead8*/
}

// Address: 0x102a0eae1 | Name: __ZN3RBX7Network15serializeStringERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERNS0_20NetworkStreamContentEi
void *__fastcall RBX::Network::serializeString(
        unsigned __int8 *a1,
        unsigned int *a2,
        RBX::Network::NetworkStreamContent *a3)
{
  unsigned int v5; // r15d
  __int64 v6; // r15
  void *result; // rax
  __int64 v8; // r15
  const void *v9; // r14
  char *exception; // rbx
  __int64 v11; // rcx
  __int64 v12; // r8
  __int64 v13; // r9
  __m128 v14; // xmm0
  __m128 v15; // xmm1
  __m128 v16; // xmm2
  __m128 v17; // xmm3
  __m128 v18; // xmm4
  __m128 v19; // xmm5
  __m128 v20; // xmm6
  __m128 v21; // xmm7
  __int128 v22; // [rsp+0h] [rbp-30h] BYREF
  __int64 v23; // [rsp+10h] [rbp-20h]

  v5 = *a1; /*0x102a0eaf4*/
  if ( (v5 & 1) != 0 ) /*0x102a0eafc*/
    v6 = *((_QWORD *)a1 + 1); /*0x102a0eafe*/
  else
    LODWORD(v6) = v5 >> 1; /*0x102a0eb04*/
  if ( (unsigned int)v6 > (unsigned int)a3 )
  {
    exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0eb72*/
    RBX::format(
      this: (RBX *)&v22,
      a2: "BitStream string write: String too long: %u",
      a3: (unsigned int)v6,
      a4: v11,
      a5: v12,
      a6: v13,
      a7: v14,
      a8: v15,
      a9: v16,
      a10: v17,
      a11: v18,
      a12: v19,
      a13: v20,
      a14: v21,
      a15: v22);
    *(_QWORD *)exception = off_10CAA98E0; /*0x102a0eb91*/
    *((_QWORD *)exception + 3) = v23; /*0x102a0eb98*/
    *(_OWORD *)(exception + 8) = v22; /*0x102a0eba0*/
    v22 = 0; /*0x102a0eba7*/
    v23 = 0; /*0x102a0ebab*/
    __cxa_throw( /*0x102a0ebc4*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  RBX::Network::serializeUInt64Varint(this: (unsigned int)v6, (RBX::Network::NetworkStreamContent *)a2, a3); /*0x102a0eb12*/
  result = (void *)*a1; /*0x102a0eb17*/
  if ( ((unsigned __int8)result & 1) != 0 ) /*0x102a0eb1d*/
    v8 = *((_QWORD *)a1 + 1); /*0x102a0eb1f*/
  else
    LODWORD(v8) = (unsigned int)result >> 1; /*0x102a0eb28*/
  if ( (_DWORD)v8 != 0 ) /*0x102a0eb2e*/
  {
    if ( ((unsigned __int8)result & 1) != 0 ) /*0x102a0eb32*/
      v9 = *((const void **)a1 + 2); /*0x102a0eb34*/
    else
      v9 = a1 + 1; /*0x102a0eb3a*/
    RBX::Network::NetworkStreamContent::AddBytesAndReallocate(this: (RBX::Network::NetworkStreamContent *)a2, a2: v8); /*0x102a0eb43*/
    result = memcpy(__dst: (void *)(*(_QWORD *)a2 + a2[8]), __src: v9, __n: (unsigned int)v8); /*0x102a0eb54*/
    a2[8] += v8; /*0x102a0eb59*/
  }
  return result; /*0x102a0eb5d*/
}

// Address: 0x102a0ebf2 | Name: __ZN3RBX7Network17deserializeStringERNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERNS0_20NetworkStreamContentEi
__int64 __fastcall RBX::Network::deserializeString(
        __int64 a1,
        RBX::Network::NetworkStreamContent *a2,
        RBX::Network::NetworkStreamContent *a3)
{
  unsigned int v3; // r12d
  unsigned int v6; // r15d
  unsigned int NumberOfUnreadBytes; // eax
  unsigned int v8; // r12d
  __int64 result; // rax
  void *v10; // rbx
  char *exception; // r14
  char *v12; // r14
  __int64 v13; // rcx
  __int64 v14; // r8
  __int64 v15; // r9
  __m128 v16; // xmm0
  __m128 v17; // xmm1
  __m128 v18; // xmm2
  __m128 v19; // xmm3
  __m128 v20; // xmm4
  __m128 v21; // xmm5
  __m128 v22; // xmm6
  __m128 v23; // xmm7
  __int64 v24; // [rsp+0h] [rbp-70h] BYREF
  __int128 v25; // [rsp+10h] [rbp-60h] BYREF
  __int64 v26; // [rsp+20h] [rbp-50h]
  __int128 v27; // [rsp+30h] [rbp-40h] BYREF
  __int64 v28; // [rsp+40h] [rbp-30h]

  v3 = (unsigned int)a3; /*0x102a0ec03*/
  v24 = 0; /*0x102a0ec10*/
  RBX::Network::deserializeUInt64Varint(this: (RBX::Network *)&v24, a2, a3); /*0x102a0ec1a*/
  v6 = v24; /*0x102a0ec1f*/
  if ( ((unsigned __int8)DFFlag::FixStringCheckInNS & ((unsigned int)v24 > v3)) == 1 )
  {
    exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0eca1*/
    v24 = v6 - v3; /*0x102a0eca8*/
    fmt::v8::vformat(a1: &v25, a2: "BitStream string read: String too long by {}", 44, 2);
    *(_QWORD *)exception = off_10CAA98E0; /*0x102a0eccc*/
    *((_QWORD *)exception + 3) = v26; /*0x102a0ecd3*/
    *(_OWORD *)(exception + 8) = v25; /*0x102a0ecdb*/
    v25 = 0; /*0x102a0ece3*/
    v26 = 0; /*0x102a0ece7*/
    __cxa_throw( /*0x102a0ed00*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  NumberOfUnreadBytes = RBX::Network::NetworkStreamContent::GetNumberOfUnreadBytes(this: a2); /*0x102a0ec3b*/
  v8 = v6 - NumberOfUnreadBytes; /*0x102a0ec43*/
  if ( v6 > NumberOfUnreadBytes )
  {
    v12 = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0ed11*/
    RBX::format(
      this: (RBX *)&v27,
      a2: "BitStream string read: String too long by: %u",
      a3: v8,
      a4: v13,
      a5: v14,
      a6: v15,
      a7: v16,
      a8: v17,
      a9: v18,
      a10: v19,
      a11: v20,
      a12: v21,
      a13: v22,
      a14: v23,
      a15: v24);
    *(_QWORD *)v12 = off_10CAA98E0; /*0x102a0ed30*/
    *((_QWORD *)v12 + 3) = v28; /*0x102a0ed37*/
    *(_OWORD *)(v12 + 8) = v27; /*0x102a0ed3f*/
    v27 = 0; /*0x102a0ed47*/
    v28 = 0; /*0x102a0ed4b*/
    __cxa_throw( /*0x102a0ed64*/
      a1: v12,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  result = std::string::resize(a1, a2: v6, a3: 0); /*0x102a0ec54*/
  if ( v6 != 0 ) /*0x102a0ec5c*/
  {
    if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x102a0ec61*/
      v10 = *(void **)(a1 + 16); /*0x102a0ec63*/
    else
      v10 = (void *)(a1 + 1); /*0x102a0ec78*/
    return RBX::Network::NetworkStreamContent::readBytes(this: a2, a2: v10, a3: v6); /*0x102a0ec92*/
  }
  return result; /*0x102a0ec69*/
}

// Address: 0x102a0eda3 | Name: __ZN3RBX7Network30deserializeStringPrependPrefixERNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERKS7_RNS0_20NetworkStreamContentE
__int64 __fastcall RBX::Network::deserializeStringPrependPrefix(
        __int64 a1,
        unsigned __int8 *a2,
        RBX::Network::NetworkStreamContent *a3)
{
  unsigned int v6; // r14d
  unsigned int NumberOfUnreadBytes; // eax
  unsigned int v8; // r13d
  unsigned int v9; // ebx
  __int64 v10; // rbx
  __int64 v11; // r13
  __int64 v12; // rsi
  unsigned int v13; // edx
  __int64 v14; // rdx
  __int64 result; // rax
  char *exception; // rbx
  __int64 v17; // rcx
  __int64 v18; // r8
  __int64 v19; // r9
  __m128 v20; // xmm0
  __m128 v21; // xmm1
  __m128 v22; // xmm2
  __m128 v23; // xmm3
  __m128 v24; // xmm4
  __m128 v25; // xmm5
  __m128 v26; // xmm6
  __m128 v27; // xmm7
  __int64 v28; // [rsp+0h] [rbp-50h] BYREF
  RBX::Network::NetworkStreamContent *v29; // [rsp+8h] [rbp-48h]
  __int128 v30; // [rsp+10h] [rbp-40h] BYREF
  __int64 v31; // [rsp+20h] [rbp-30h]

  v28 = 0; /*0x102a0edc1*/
  RBX::Network::deserializeUInt64Varint(this: (RBX::Network *)&v28, a2: a3, a3); /*0x102a0edce*/
  v6 = v28; /*0x102a0edd3*/
  v29 = a3; /*0x102a0edd6*/
  NumberOfUnreadBytes = RBX::Network::NetworkStreamContent::GetNumberOfUnreadBytes(this: a3); /*0x102a0eddd*/
  v8 = v6 - NumberOfUnreadBytes; /*0x102a0ede5*/
  if ( v6 > NumberOfUnreadBytes )
  {
    exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0ee88*/
    RBX::format(
      this: (RBX *)&v30,
      a2: "BitStream string read: String too long by: %u",
      a3: v8,
      a4: v17,
      a5: v18,
      a6: v19,
      a7: v20,
      a8: v21,
      a9: v22,
      a10: v23,
      a11: v24,
      a12: v25,
      a13: v26,
      a14: v27,
      a15: v28);
    *(_QWORD *)exception = off_10CAA98E0; /*0x102a0eea7*/
    *((_QWORD *)exception + 3) = v31; /*0x102a0eeae*/
    *(_OWORD *)(exception + 8) = v30; /*0x102a0eeb6*/
    v30 = 0; /*0x102a0eebd*/
    v31 = 0; /*0x102a0eec1*/
    __cxa_throw( /*0x102a0eeda*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  v9 = *a2; /*0x102a0edee*/
  if ( (v9 & 1) != 0 ) /*0x102a0edf6*/
    v10 = *((_QWORD *)a2 + 1); /*0x102a0edf8*/
  else
    LODWORD(v10) = v9 >> 1; /*0x102a0edff*/
  std::string::resize(a1, a2: (unsigned int)v10 + v6, a3: 0); /*0x102a0ee0b*/
  v11 = a1 + 1; /*0x102a0ee10*/
  v12 = a1 + 1; /*0x102a0ee18*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x102a0ee1b*/
    v12 = *(_QWORD *)(a1 + 16); /*0x102a0ee1d*/
  v13 = *a2; /*0x102a0ee21*/
  if ( (v13 & 1) != 0 ) /*0x102a0ee29*/
    v14 = *((_QWORD *)a2 + 1); /*0x102a0ee2b*/
  else
    v14 = v13 >> 1; /*0x102a0ee32*/
  result = std::string::copy(a1: a2, a2: v12, a3: v14, a4: 0); /*0x102a0ee39*/
  if ( v6 != 0 ) /*0x102a0ee41*/
  {
    if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x102a0ee49*/
      v11 = *(_QWORD *)(a1 + 16); /*0x102a0ee4b*/
    return RBX::Network::NetworkStreamContent::readBytes(this: v29, a2: (void *)((unsigned int)v10 + v11), a3: v6); /*0x102a0ee6a*/
  }
  return result; /*0x102a0ee5c*/
}

// Address: 0x102a0ef08 | Name: __ZN3RBX7Network22serializeRbxStringViewERKNS_10StringViewERNS0_20NetworkStreamContentEi
unsigned __int64 __fastcall RBX::Network::serializeRbxStringView(
        __int64 a1,
        unsigned int *a2,
        RBX::Network::NetworkStreamContent *a3)
{
  __int64 v3; // r14
  unsigned __int64 result; // rax
  __int64 v7; // r14
  const void *v8; // r15
  char *exception; // rbx
  __int64 v10; // rcx
  __int64 v11; // r8
  __int64 v12; // r9
  __m128 v13; // xmm0
  __m128 v14; // xmm1
  __m128 v15; // xmm2
  __m128 v16; // xmm3
  __m128 v17; // xmm4
  __m128 v18; // xmm5
  __m128 v19; // xmm6
  __m128 v20; // xmm7
  __int128 v21; // [rsp+0h] [rbp-40h] BYREF
  __int64 v22; // [rsp+10h] [rbp-30h]

  v3 = *(_QWORD *)(a1 + 8); /*0x102a0ef17*/
  if ( (unsigned int)v3 > (unsigned int)a3 )
  {
    exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x102a0ef74*/
    RBX::format(
      this: (RBX *)&v21,
      a2: "BitStream string write: String too long: %u",
      a3: (unsigned int)v3,
      a4: v10,
      a5: v11,
      a6: v12,
      a7: v13,
      a8: v14,
      a9: v15,
      a10: v16,
      a11: v17,
      a12: v18,
      a13: v19,
      a14: v20,
      a15: v21);
    *(_QWORD *)exception = off_10CAA98E0; /*0x102a0ef93*/
    *((_QWORD *)exception + 3) = v22; /*0x102a0ef9a*/
    *(_OWORD *)(exception + 8) = v21; /*0x102a0efa2*/
    v21 = 0; /*0x102a0efa9*/
    v22 = 0; /*0x102a0efad*/
    __cxa_throw( /*0x102a0efc6*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
      a3: RBX::network_stream_exception::~network_stream_exception);
  }
  result = RBX::Network::serializeUInt64Varint(this: (unsigned int)v3, (RBX::Network::NetworkStreamContent *)a2, a3); /*0x102a0ef29*/
  v7 = *(_QWORD *)(a1 + 8); /*0x102a0ef2e*/
  if ( (_DWORD)v7 != 0 ) /*0x102a0ef35*/
  {
    v8 = *(const void **)a1; /*0x102a0ef3a*/
    RBX::Network::NetworkStreamContent::AddBytesAndReallocate(this: (RBX::Network::NetworkStreamContent *)a2, a2: v7); /*0x102a0ef43*/
    result = (unsigned __int64)memcpy(__dst: (void *)(*(_QWORD *)a2 + a2[8]), __src: v8, __n: (unsigned int)v7); /*0x102a0ef54*/
    a2[8] += v7; /*0x102a0ef59*/
  }
  return result; /*0x102a0ef5d*/
}

// Address: 0x102a0fbb3 | Name: __ZN3RBX7Network22deserializeStateReasonEy
RBX::Network *__fastcall RBX::Network::deserializeStateReason(RBX::Network *this, __int64 a2, __int64 a3, __int64 a4)
{
  _BYTE v7[48]; // [rsp+0h] [rbp-30h] BYREF

  std::string::basic_string[abi:ne200100]<0>(a1: v7, a2: "", a3, a4); /*0x102a0fbd4*/
  *(_QWORD *)this = __ROR8__(a2, 32); /*0x102a0fbdd*/
  qmemcpy((char *)this + 8, v7, 24); /*0x102a0fbe4*/
  return this; /*0x102a0fbf4*/
}

// Address: 0x102a0fbff | Name: __ZN3RBX7Network28connectionErrorToStateReasonENS_15ConnectionErrorE
int *__fastcall RBX::Network::connectionErrorToStateReason(int *a1, int a2, __int64 a3, __int64 a4)
{
  int v6; // r12d
  unsigned __int64 v7; // rax
  _BYTE v9[56]; // [rsp+8h] [rbp-38h] BYREF

  if ( a2 > 511 ) /*0x102a0fc1a*/
  {
    if ( a2 > 600 ) /*0x102a0fc50*/
    {
      if ( (unsigned int)(a2 - 768) < 8 ) /*0x102a0fc80*/
      {
LABEL_9:
        v6 = 264; /*0x102a0fc82*/
        goto LABEL_23; /*0x102a0fc88*/
      }
      if ( (unsigned int)(a2 - 610) >= 2 ) /*0x102a0fcbc*/
      {
        if ( a2 == 601 ) /*0x102a0fcc5*/
        {
LABEL_3:
          v6 = 259; /*0x102a0fc3e*/
          goto LABEL_23; /*0x102a0fc44*/
        }
LABEL_21:
        v6 = 0; /*0x102a0fcde*/
        goto LABEL_23; /*0x102a0fce1*/
      }
    }
    else
    {
      v7 = (unsigned int)(a2 - 512); /*0x102a0fc52*/
      if ( (unsigned int)v7 > 0x21 || (a4 = 0x3E023FC79LL, !_bittest64(&a4, v7)) ) /*0x102a0fc68*/
      {
        if ( a2 != 600 ) /*0x102a0fcdc*/
          goto LABEL_21; /*0x102a0fcdc*/
      }
    }
    v6 = 263; /*0x102a0fc6e*/
    goto LABEL_23; /*0x102a0fc74*/
  }
  v6 = 64; /*0x102a0fc1c*/
  switch ( a2 ) /*0x102a0fc3c*/
  {
    case 256: /*0x102a0fc3c*/
    case 277: /*0x102a0fc3c*/
    case 296: /*0x102a0fc3c*/
    case 297: /*0x102a0fc3c*/
    case 298: /*0x102a0fc3c*/
    case 299: /*0x102a0fc3c*/
    case 300: /*0x102a0fc3c*/
    case 303: /*0x102a0fc3c*/
    case 308: /*0x102a0fc3c*/
      break;
    case 257: /*0x102a0fc3c*/
    case 258: /*0x102a0fc3c*/
    case 259: /*0x102a0fc3c*/
    case 265: /*0x102a0fc3c*/
    case 266: /*0x102a0fc3c*/
    case 268: /*0x102a0fc3c*/
    case 269: /*0x102a0fc3c*/
    case 271: /*0x102a0fc3c*/
    case 272: /*0x102a0fc3c*/
    case 273: /*0x102a0fc3c*/
    case 280: /*0x102a0fc3c*/
    case 281: /*0x102a0fc3c*/
    case 282: /*0x102a0fc3c*/
    case 304: /*0x102a0fc3c*/
    case 305: /*0x102a0fc3c*/
    case 306: /*0x102a0fc3c*/
    case 317: /*0x102a0fc3c*/
    case 318: /*0x102a0fc3c*/
    case 319: /*0x102a0fc3c*/
    case 320: /*0x102a0fc3c*/
    case 321: /*0x102a0fc3c*/
      goto LABEL_3;
    case 260: /*0x102a0fc3c*/
    case 261: /*0x102a0fc3c*/
    case 262: /*0x102a0fc3c*/
    case 276: /*0x102a0fc3c*/
    case 290: /*0x102a0fc3c*/
      v6 = 262; /*0x102a0fcaa*/
      break; /*0x102a0fcb0*/
    case 263: /*0x102a0fc3c*/
      goto LABEL_9;
    case 264: /*0x102a0fc3c*/
    case 278: /*0x102a0fc3c*/
    case 284: /*0x102a0fc3c*/
    case 285: /*0x102a0fc3c*/
    case 291: /*0x102a0fc3c*/
    case 292: /*0x102a0fc3c*/
      v6 = 256; /*0x102a0fca2*/
      break; /*0x102a0fca8*/
    case 267: /*0x102a0fc3c*/
    case 274: /*0x102a0fc3c*/
    case 275: /*0x102a0fc3c*/
    case 286: /*0x102a0fc3c*/
    case 287: /*0x102a0fc3c*/
    case 288: /*0x102a0fc3c*/
    case 301: /*0x102a0fc3c*/
    case 302: /*0x102a0fc3c*/
    case 307: /*0x102a0fc3c*/
    case 309: /*0x102a0fc3c*/
      v6 = 257; /*0x102a0fc9a*/
      break; /*0x102a0fca0*/
    case 270: /*0x102a0fc3c*/
    case 294: /*0x102a0fc3c*/
    case 295: /*0x102a0fc3c*/
    case 310: /*0x102a0fc3c*/
    case 311: /*0x102a0fc3c*/
    case 312: /*0x102a0fc3c*/
    case 313: /*0x102a0fc3c*/
    case 314: /*0x102a0fc3c*/
    case 315: /*0x102a0fc3c*/
    case 316: /*0x102a0fc3c*/
      v6 = 258; /*0x102a0fc92*/
      break; /*0x102a0fc98*/
    case 279: /*0x102a0fc3c*/
      v6 = 68; /*0x102a0fce3*/
      break; /*0x102a0fce3*/
    case 283: /*0x102a0fc3c*/
    case 293: /*0x102a0fc3c*/
      v6 = 261; /*0x102a0fccd*/
      break; /*0x102a0fcd3*/
    case 289: /*0x102a0fc3c*/
      goto LABEL_21;
    default:
      if ( (unsigned int)a2 >= 0xB ) /*0x102a0fc8e*/
        goto LABEL_21; /*0x102a0fc8e*/
      break; /*0x102a0fc8e*/
  }
LABEL_23:
  std::string::basic_string[abi:ne200100]<0>(a1: v9, a2: "", a3, a4); /*0x102a0fce9*/
  *a1 = v6; /*0x102a0fcfc*/
  a1[1] = a2; /*0x102a0fcff*/
  qmemcpy(a1 + 2, v9, 24); /*0x102a0fd07*/
  return a1; /*0x102a0fd16*/
}

// Address: 0x103e3d2fe | Name: __ZN6webrtc7Network6SetIPsERKNSt3__16vectorINS_16InterfaceAddressENS1_9allocatorIS3_EEEEb
__int64 __fastcall webrtc::Network::SetIPs(__int64 a1, _QWORD *a2, int a3)
{
  __int64 v3; // r12
  __int64 v6; // r15
  __int64 v7; // rdx
  __int64 v8; // r13
  _QWORD *v9; // rbx
  __int64 v11; // [rsp+0h] [rbp-30h]

  if ( a3 != 0 || (v6 = *a2, (v7 = a2[1]) - *a2 != *(_QWORD *)(a1 + 248) - *(_QWORD *)(a1 + 240)) ) /*0x103e3d334*/
  {
LABEL_13:
    LOBYTE(v3) = 1; /*0x103e3d388*/
  }
  else if ( v6 == v7 ) /*0x103e3d339*/
  {
    LODWORD(v3) = 0; /*0x103e3d3c2*/
  }
  else
  {
    v11 = a2[1]; /*0x103e3d33f*/
    do /*0x103e3d384*/
    {
      v3 = *(_QWORD *)(a1 + 240); /*0x103e3d343*/
      v8 = *(_QWORD *)(a1 + 248); /*0x103e3d34a*/
      if ( v3 != v8 ) /*0x103e3d354*/
      {
        while ( (unsigned __int8)webrtc::InterfaceAddress::operator==(a1: v3, a2: v6) == 0 ) /*0x103e3d363*/
        {
          v3 += 32; /*0x103e3d365*/
          if ( v3 == v8 ) /*0x103e3d36c*/
            goto LABEL_13; /*0x103e3d36c*/
        }
        v7 = v11; /*0x103e3d370*/
      }
      LOBYTE(v3) = v3 == v8; /*0x103e3d377*/
      if ( (_BYTE)v3 ) /*0x103e3d37b*/
        break; /*0x103e3d37b*/
      v6 += 32; /*0x103e3d37d*/
    }
    while ( v6 != v7 ); /*0x103e3d384*/
  }
  v9 = (_QWORD *)(a1 + 240); /*0x103e3d38b*/
  if ( v9 != a2 ) /*0x103e3d395*/
    std::vector<webrtc::InterfaceAddress>::__assign_with_size[abi:ne200100]<webrtc::InterfaceAddress*,webrtc::InterfaceAddress*>( /*0x103e3d3ab*/
      a1: v9,
      a2: *a2,
      a3: a2[1],
      a4: (__int64)(a2[1] - *a2) >> 5);
  return (unsigned int)v3; /*0x103e3d3b7*/
}

// Address: 0x103e3d598 | Name: __ZN6webrtc7Network8set_typeENS_11AdapterTypeE
void __fastcall webrtc::Network::set_type(__int64 a1, int a2)
{
  __int64 v3; // r14
  __int64 v4; // rax

  if ( *(_DWORD *)(a1 + 272) != a2 ) /*0x103e3d59e*/
  {
    *(_DWORD *)(a1 + 272) = a2; /*0x103e3d5aa*/
    if ( a2 != 8 ) /*0x103e3d5b3*/
      *(_DWORD *)(a1 + 276) = 0; /*0x103e3d5b5*/
    v3 = a1 + 16; /*0x103e3d5bf*/
    v4 = *(_QWORD *)(a1 + 24); /*0x103e3d5c3*/
    *(_QWORD *)(a1 + 40) = v4; /*0x103e3d5c7*/
    while ( v4 != v3 ) /*0x103e3d5ce*/
    {
      *(_QWORD *)(a1 + 40) = *(_QWORD *)(v4 + 8); /*0x103e3d5d8*/
      (*(void (__fastcall **)(__int64, __int64))(v4 + 16))(a1: v4 + 16, a2: a1); /*0x103e3d5df*/
      v4 = *(_QWORD *)(a1 + 40); /*0x103e3d5e2*/
    }
  }
}

// Address: 0x103e3d92e | Name: __ZNK6webrtc7Network9GetBestIPEv
webrtc::Network *__fastcall webrtc::Network::GetBestIP(webrtc::Network *this, __int64 a2)
{
  __int64 v3; // r14
  __int64 v4; // r12
  __int128 v5; // xmm0
  char v6; // al
  const webrtc::IPAddress *v7; // rsi
  _QWORD *v8; // rdi
  char v9; // al
  const webrtc::IPAddress *v10; // rsi
  _QWORD *v11; // r14
  const webrtc::IPAddress *v12; // rsi
  _QWORD v14[4]; // [rsp+8h] [rbp-88h] BYREF
  _QWORD v15[4]; // [rsp+28h] [rbp-68h] BYREF
  _QWORD v16[9]; // [rsp+48h] [rbp-48h] BYREF

  v3 = *(_QWORD *)(a2 + 240); /*0x103e3d942*/
  v4 = *(_QWORD *)(a2 + 248); /*0x103e3d949*/
  if ( v3 == v4 ) /*0x103e3d953*/
  {
    *(_QWORD *)this = off_10C910720; /*0x103e3d980*/
    *(_OWORD *)((char *)this + 8) = 0; /*0x103e3d986*/
    *((_DWORD *)this + 6) = 0; /*0x103e3d98a*/
  }
  else
  {
    if ( *(_DWORD *)(a2 + 184) == 2 ) /*0x103e3d95c*/
    {
      *(_QWORD *)this = off_10C910720; /*0x103e3d965*/
      *((_DWORD *)this + 2) = *(_DWORD *)(v3 + 8); /*0x103e3d96c*/
      v5 = *(_OWORD *)(v3 + 12); /*0x103e3d96f*/
    }
    else
    {
      memset(&v16[1], 0, 24); /*0x103e3d99d*/
      v16[0] = off_10C9272E0; /*0x103e3d9ae*/
      memset(&v14[1], 0, 24); /*0x103e3d9b8*/
      v14[0] = off_10C9272E0; /*0x103e3d9c1*/
      memset(&v15[1], 0, 24); /*0x103e3d9c9*/
      v15[0] = off_10C9272E0; /*0x103e3d9d2*/
      do /*0x103e3da1e*/
      {
        if ( (*(_BYTE *)(v3 + 28) & 2) == 0 ) /*0x103e3d9da*/
        {
          v6 = webrtc::IPIsLinkLocal(this: (webrtc *)v3, (const webrtc::IPAddress *)a2); /*0x103e3d9df*/
          v8 = v14; /*0x103e3d9e4*/
          if ( v6 != 0 || (v9 = webrtc::IPIsULA(this: (webrtc *)v3, a2: v7), v8 = v15, v9 != 0) ) /*0x103e3d9f8*/
          {
            webrtc::InterfaceAddress::operator=(a1: v8, a2: v3); /*0x103e3d9fd*/
          }
          else
          {
            webrtc::InterfaceAddress::operator=(a1: v16, a2: v3); /*0x103e3da0b*/
            if ( (*(_BYTE *)(v3 + 28) & 1) != 0 ) /*0x103e3da15*/
              break; /*0x103e3da15*/
          }
        }
        v3 += 32; /*0x103e3da17*/
      }
      while ( v3 != v4 ); /*0x103e3da1e*/
      if ( (unsigned __int8)webrtc::IPIsUnspec(this: (webrtc *)v16, (const webrtc::IPAddress *)a2) != 0 ) /*0x103e3da2b*/
      {
        v11 = v14; /*0x103e3da2d*/
        if ( (unsigned __int8)webrtc::IPIsUnspec(this: (webrtc *)v14, a2: v10) == 0 /*0x103e3da4e*/
          || (v11 = v15, (unsigned __int8)webrtc::IPIsUnspec(this: (webrtc *)v15, a2: v12) == 0) )
        {
          webrtc::InterfaceAddress::operator=(a1: v16, a2: v11); /*0x103e3da57*/
        }
      }
      *(_QWORD *)this = off_10C910720; /*0x103e3da63*/
      *((_DWORD *)this + 2) = v16[1]; /*0x103e3da69*/
      v5 = *(_OWORD *)((char *)&v16[1] + 4); /*0x103e3da6c*/
    }
    *(_OWORD *)((char *)this + 12) = v5; /*0x103e3da70*/
  }
  return this; /*0x103e3da77*/
}

// Address: 0x103e3f5f6 | Name: __ZNK6webrtc7Network8ToStringEv
webrtc::Network *__fastcall webrtc::Network::ToString(webrtc::Network *this, __int64 a2)
{
  __int64 v4; // rax
  _BYTE *v5; // rsi
  __int64 v6; // rdx
  char *v7; // rsi
  __int64 v8; // rdx
  __int64 v9; // r15
  char *v10; // rsi
  __int64 v11; // rdx
  void *v12; // rsi
  _BYTE *v13; // rsi
  __int64 v14; // rdx
  void *v15; // rsi
  __int64 v16; // rax
  unsigned __int8 v18; // [rsp+0h] [rbp-80h] BYREF
  char v19; // [rsp+1h] [rbp-7Fh] BYREF
  __int64 v20; // [rsp+8h] [rbp-78h]
  void *v21; // [rsp+10h] [rbp-70h]
  unsigned __int8 v22; // [rsp+18h] [rbp-68h] BYREF
  char v23; // [rsp+19h] [rbp-67h] BYREF
  __int64 v24; // [rsp+20h] [rbp-60h]
  void *v25; // [rsp+28h] [rbp-58h]
  __int128 v26; // [rsp+30h] [rbp-50h] BYREF
  __int64 v27; // [rsp+40h] [rbp-40h]
  unsigned __int8 v28; // [rsp+50h] [rbp-30h] BYREF
  _BYTE v29[7]; // [rsp+51h] [rbp-2Fh] BYREF
  __int64 v30; // [rsp+58h] [rbp-28h]
  void *v31; // [rsp+60h] [rbp-20h]

  v26 = 0; /*0x103e3f610*/
  v27 = 0; /*0x103e3f613*/
  std::string::append(a1: &v26, a2: "Net[", a3: 4); /*0x103e3f627*/
  v4 = std::string::find(a1: a2 + 152, a2: 32, a3: 0); /*0x103e3f63d*/
  std::string::basic_string(a1: &v28, a2: a2 + 152, a3: 0, a4: v4, a5: &v22); /*0x103e3f652*/
  if ( (v28 & 1) != 0 ) /*0x103e3f65e*/
  {
    v5 = v31; /*0x103e3f660*/
    v6 = v30; /*0x103e3f664*/
  }
  else
  {
    v6 = v28 >> 1; /*0x103e3f66a*/
    v5 = v29; /*0x103e3f66c*/
  }
  std::string::append(a1: &v26, a2: v5, a3: v6); /*0x103e3f674*/
  std::string::append(a1: &v26, a2: ":", a3: 1); /*0x103e3f689*/
  webrtc::IPAddress::ToSensitiveString(this: (webrtc::IPAddress *)&v22); /*0x103e3f699*/
  if ( (v22 & 1) != 0 ) /*0x103e3f6a5*/
  {
    v7 = (char *)v25; /*0x103e3f6a7*/
    v8 = v24; /*0x103e3f6ab*/
  }
  else
  {
    v8 = v22 >> 1; /*0x103e3f6b1*/
    v7 = &v23; /*0x103e3f6b3*/
  }
  std::string::append(a1: &v26, a2: v7, a3: v8); /*0x103e3f6bb*/
  std::string::append(a1: &v26, a2: "/", a3: 1); /*0x103e3f6d0*/
  v9 = webrtc::StringBuilder::operator<<(a1: &v26, a2: *(unsigned int *)(a2 + 208)); /*0x103e3f6e5*/
  std::string::append(a1: v9, a2: ":", a3: 1); /*0x103e3f6f7*/
  webrtc::AdapterTypeToString(a1: &v18, a2: *(unsigned int *)(a2 + 272)); /*0x103e3f707*/
  if ( (v18 & 1) != 0 ) /*0x103e3f713*/
  {
    v10 = (char *)v21; /*0x103e3f715*/
    v11 = v20; /*0x103e3f719*/
  }
  else
  {
    v11 = v18 >> 1; /*0x103e3f71f*/
    v10 = &v19; /*0x103e3f721*/
  }
  std::string::append(a1: v9, a2: v10, a3: v11); /*0x103e3f728*/
  if ( (v18 & 1) != 0 ) /*0x103e3f731*/
    operator delete(a1: (RBX::Memory *)v21, a2: v12); /*0x103e3f737*/
  if ( (v22 & 1) != 0 ) /*0x103e3f740*/
    operator delete(a1: (RBX::Memory *)v25, a2: v12); /*0x103e3f746*/
  if ( (v28 & 1) != 0 ) /*0x103e3f74f*/
    operator delete(a1: (RBX::Memory *)v31, a2: v12); /*0x103e3f755*/
  if ( *(_DWORD *)(a2 + 272) == 8 ) /*0x103e3f762*/
  {
    std::string::append(a1: &v26, a2: "/", a3: 1); /*0x103e3f774*/
    webrtc::AdapterTypeToString(a1: &v28, a2: *(unsigned int *)(a2 + 276)); /*0x103e3f784*/
    if ( (v28 & 1) != 0 ) /*0x103e3f790*/
    {
      v13 = v31; /*0x103e3f792*/
      v14 = v30; /*0x103e3f796*/
    }
    else
    {
      v14 = v28 >> 1; /*0x103e3f79c*/
      v13 = v29; /*0x103e3f79e*/
    }
    std::string::append(a1: &v26, a2: v13, a3: v14); /*0x103e3f7a6*/
    if ( (v28 & 1) != 0 ) /*0x103e3f7af*/
      operator delete(a1: (RBX::Memory *)v31, a2: v15); /*0x103e3f7b5*/
  }
  std::string::append(a1: &v26, a2: ":id=", a3: 4); /*0x103e3f7ca*/
  v16 = webrtc::StringBuilder::operator<<(a1: &v26, a2: *(unsigned __int16 *)(a2 + 286)); /*0x103e3f7db*/
  std::string::append(a1: v16, a2: "]", a3: 1); /*0x103e3f7ef*/
  *((_QWORD *)this + 2) = v27; /*0x103e3f7f8*/
  *(_OWORD *)this = v26; /*0x103e3f800*/
  return this; /*0x103e3f806*/
}

// Address: 0x103e3f93c | Name: __ZN6webrtc7NetworkC2ENSt3__117basic_string_viewIcNS1_11char_traitsIcEEEES5_RKNS_9IPAddressEiNS_11AdapterTypeE
__int64 __fastcall webrtc::Network::Network(
        __int64 a1,
        const void *a2,
        size_t a3,
        const void *a4,
        size_t a5,
        __int64 a6,
        int a7,
        unsigned int a8)
{
  __int64 (__fastcall *v10)(); // rdi
  unsigned __int64 v11; // rsi
  __int64 v12; // r14
  void *v14; // r12
  __int64 v15; // r14
  void *v16; // r12
  __int64 v17; // r14

  *(_QWORD *)a1 = sigslot::_signal_base<sigslot::single_threaded>::do_slot_disconnect; /*0x103e3f95e*/
  v10 = sigslot::_signal_base<sigslot::single_threaded>::do_slot_duplicate; /*0x103e3f961*/
  *(_QWORD *)(a1 + 8) = sigslot::_signal_base<sigslot::single_threaded>::do_slot_duplicate; /*0x103e3f968*/
  *(_QWORD *)(a1 + 16) = a1 + 16; /*0x103e3f970*/
  *(_QWORD *)(a1 + 24) = a1 + 16; /*0x103e3f974*/
  v11 = 0; /*0x103e3f978*/
  *(_QWORD *)(a1 + 32) = 0; /*0x103e3f97a*/
  *(_QWORD *)(a1 + 40) = a1 + 16; /*0x103e3f97e*/
  *(_BYTE *)(a1 + 48) = 0; /*0x103e3f982*/
  *(_QWORD *)(a1 + 56) = sigslot::_signal_base<sigslot::single_threaded>::do_slot_disconnect; /*0x103e3f986*/
  *(_QWORD *)(a1 + 64) = sigslot::_signal_base<sigslot::single_threaded>::do_slot_duplicate; /*0x103e3f98a*/
  *(_QWORD *)(a1 + 72) = a1 + 72; /*0x103e3f992*/
  *(_QWORD *)(a1 + 80) = a1 + 72; /*0x103e3f996*/
  *(_QWORD *)(a1 + 88) = 0; /*0x103e3f99a*/
  *(_QWORD *)(a1 + 96) = a1 + 72; /*0x103e3f99e*/
  *(_BYTE *)(a1 + 104) = 0; /*0x103e3f9a2*/
  *(_OWORD *)(a1 + 112) = 0; /*0x103e3f9a9*/
  if ( a3 >= 0xFFFFFFFFFFFFFFF8LL ) /*0x103e3f9b1*/
    std::string::__throw_length_error[abi:ne200100](a1: sigslot::_signal_base<sigslot::single_threaded>::do_slot_duplicate); /*0x103e3fb4c*/
  v12 = a6; /*0x103e3f9b7*/
  if ( a3 >= 0x17 ) /*0x103e3f9c9*/
  {
    v15 = 26; /*0x103e3f9f2*/
    if ( (a3 | 7) != 0x17 ) /*0x103e3f9f8*/
      v15 = (a3 | 7) + 1; /*0x103e3f9f8*/
    v14 = (void *)operator new(a1: (RBX::Memory *)v15, a2: 0); /*0x103e3fa04*/
    *(_QWORD *)(a1 + 144) = v14; /*0x103e3fa07*/
    *(_QWORD *)(a1 + 128) = v15 | 1; /*0x103e3fa12*/
    *(_QWORD *)(a1 + 136) = a3; /*0x103e3fa19*/
    v12 = a6; /*0x103e3fa20*/
    goto LABEL_8; /*0x103e3fa20*/
  }
  *(_BYTE *)(a1 + 128) = 2 * a3; /*0x103e3f9cf*/
  v14 = (void *)(a1 + 129); /*0x103e3f9d5*/
  if ( a3 != 0 ) /*0x103e3f9df*/
LABEL_8:
    memmove(__dst: v14, __src: a2, __len: a3); /*0x103e3fa24*/
  *((_BYTE *)v14 + a3) = 0; /*0x103e3fa33*/
  if ( a5 >= 0xFFFFFFFFFFFFFFF8LL ) /*0x103e3fa3c*/
    std::string::__throw_length_error[abi:ne200100](a1: v10); /*0x103e3fb53*/
  if ( a5 >= 0x17 ) /*0x103e3fa46*/
  {
    v17 = 26; /*0x103e3fa73*/
    if ( (a5 | 7) != 0x17 ) /*0x103e3fa79*/
      v17 = (a5 | 7) + 1; /*0x103e3fa79*/
    v16 = (void *)operator new(a1: (RBX::Memory *)v17, a2: v11); /*0x103e3fa85*/
    *(_QWORD *)(a1 + 168) = v16; /*0x103e3fa88*/
    *(_QWORD *)(a1 + 152) = v17 | 1; /*0x103e3fa93*/
    *(_QWORD *)(a1 + 160) = a5; /*0x103e3fa9a*/
    v12 = a6; /*0x103e3faa1*/
  }
  else
  {
    *(_BYTE *)(a1 + 152) = 2 * a5; /*0x103e3fa50*/
    v16 = (void *)(a1 + 153); /*0x103e3fa56*/
    if ( a5 == 0 ) /*0x103e3fa60*/
      goto LABEL_17; /*0x103e3fa60*/
  }
  memmove(__dst: v16, __src: a4, __len: a5); /*0x103e3faaf*/
LABEL_17:
  *((_BYTE *)v16 + a5) = 0; /*0x103e3fab4*/
  *(_QWORD *)(a1 + 176) = off_10C910720; /*0x103e3fac4*/
  *(_DWORD *)(a1 + 184) = *(_DWORD *)(v12 + 8); /*0x103e3facf*/
  *(_OWORD *)(a1 + 188) = *(_OWORD *)(v12 + 12); /*0x103e3fada*/
  *(_DWORD *)(a1 + 208) = a7; /*0x103e3fae1*/
  webrtc::MakeNetworkKey(a1: a1 + 216, a2, a3, a4: v12); /*0x103e3faf9*/
  *(_OWORD *)(a1 + 253) = 0; /*0x103e3fb04*/
  *(_OWORD *)(a1 + 240) = 0; /*0x103e3fb0b*/
  *(_DWORD *)(a1 + 272) = a8; /*0x103e3fb12*/
  *(_QWORD *)(a1 + 276) = 0; /*0x103e3fb18*/
  *(_BYTE *)(a1 + 284) = 1; /*0x103e3fb23*/
  *(_WORD *)(a1 + 286) = 0; /*0x103e3fb2a*/
  *(_DWORD *)(a1 + 288) = 0; /*0x103e3fb33*/
  return a8; /*0x103e3fb3d*/
}

// Address: 0x103e3fbaa | Name: __ZN6webrtc7NetworkC1ENSt3__117basic_string_viewIcNS1_11char_traitsIcEEEES5_RKNS_9IPAddressEiNS_11AdapterTypeE
__int64 __fastcall webrtc::Network::Network(
        __int64 a1,
        const void *a2,
        size_t a3,
        const void *a4,
        size_t a5,
        __int64 a6,
        int a7,
        unsigned int a8)
{
  return webrtc::Network::Network(a1, a2, a3, a4, a5, a6, a7, a8); /*0x103e3fbae*/
}

// Address: 0x103e3fbb4 | Name: __ZN6webrtc7NetworkC2ERKS0_
__int64 __fastcall webrtc::Network::Network(webrtc::Network *this, const webrtc::Network *a2)
{
  int v4; // r8d
  int v5; // r9d
  __int64 result; // rax

  *(_QWORD *)this = sigslot::_signal_base<sigslot::single_threaded>::do_slot_disconnect; /*0x103e3fbd2*/
  *((_QWORD *)this + 1) = sigslot::_signal_base<sigslot::single_threaded>::do_slot_duplicate; /*0x103e3fbdc*/
  *((_QWORD *)this + 2) = (char *)this + 16; /*0x103e3fbe4*/
  *((_QWORD *)this + 3) = (char *)this + 16; /*0x103e3fbe8*/
  *((_QWORD *)this + 4) = 0; /*0x103e3fbee*/
  *((_QWORD *)this + 5) = (char *)this + 16; /*0x103e3fbf2*/
  *((_BYTE *)this + 48) = 0; /*0x103e3fbf6*/
  *((_QWORD *)this + 7) = sigslot::_signal_base<sigslot::single_threaded>::do_slot_disconnect; /*0x103e3fbfa*/
  *((_QWORD *)this + 8) = sigslot::_signal_base<sigslot::single_threaded>::do_slot_duplicate; /*0x103e3fbfe*/
  *((_QWORD *)this + 9) = (char *)this + 72; /*0x103e3fc06*/
  *((_QWORD *)this + 10) = (char *)this + 72; /*0x103e3fc0a*/
  *((_QWORD *)this + 11) = 0; /*0x103e3fc0e*/
  *((_QWORD *)this + 12) = (char *)this + 72; /*0x103e3fc12*/
  *((_BYTE *)this + 104) = 0; /*0x103e3fc16*/
  *((_OWORD *)this + 7) = *((_OWORD *)a2 + 7); /*0x103e3fc20*/
  if ( (*((_BYTE *)a2 + 128) & 1) != 0 ) /*0x103e3fc36*/
  {
    std::string::__init_copy_ctor_external(a1: (char *)this + 128, a2: *((_QWORD *)a2 + 18), a3: *((_QWORD *)a2 + 17)); /*0x103e3fc5f*/
  }
  else
  {
    *((_QWORD *)this + 18) = *((_QWORD *)a2 + 18); /*0x103e3fc3f*/
    *((_OWORD *)this + 8) = *((_OWORD *)a2 + 8); /*0x103e3fc46*/
  }
  if ( (*((_BYTE *)a2 + 152) & 1) != 0 ) /*0x103e3fc7a*/
  {
    std::string::__init_copy_ctor_external(a1: (char *)this + 152, a2: *((_QWORD *)a2 + 21), a3: *((_QWORD *)a2 + 20)); /*0x103e3fca3*/
  }
  else
  {
    *((_QWORD *)this + 21) = *((_QWORD *)a2 + 21); /*0x103e3fc83*/
    *(_OWORD *)((char *)this + 152) = *(_OWORD *)((char *)a2 + 152); /*0x103e3fc8a*/
  }
  *((_QWORD *)this + 22) = off_10C910720; /*0x103e3fcaf*/
  *((_DWORD *)this + 46) = *((_DWORD *)a2 + 46); /*0x103e3fcbe*/
  *(_OWORD *)((char *)this + 188) = *(_OWORD *)((char *)a2 + 188); /*0x103e3fccd*/
  *((_DWORD *)this + 52) = *((_DWORD *)a2 + 52); /*0x103e3fcdc*/
  if ( (*((_BYTE *)a2 + 216) & 1) != 0 ) /*0x103e3fcf4*/
  {
    std::string::__init_copy_ctor_external(a1: (char *)this + 216, a2: *((_QWORD *)a2 + 29), a3: *((_QWORD *)a2 + 28)); /*0x103e3fd1e*/
  }
  else
  {
    *((_QWORD *)this + 29) = *((_QWORD *)a2 + 29); /*0x103e3fcfd*/
    *(_OWORD *)((char *)this + 216) = *(_OWORD *)((char *)a2 + 216); /*0x103e3fd04*/
  }
  *((_OWORD *)this + 15) = 0; /*0x103e3fd2d*/
  *((_QWORD *)this + 32) = 0; /*0x103e3fd34*/
  std::vector<webrtc::InterfaceAddress>::__init_with_size[abi:ne200100]<webrtc::InterfaceAddress*,webrtc::InterfaceAddress*>( /*0x103e3fd5c*/
    a1: (char *)this + 240,
    a2: *((_QWORD *)a2 + 30),
    a3: *((_QWORD *)a2 + 31),
    a4: (__int64)(*((_QWORD *)a2 + 31) - *((_QWORD *)a2 + 30)) >> 5);
  *((_DWORD *)this + 66) = *((_DWORD *)a2 + 66); /*0x103e3fd69*/
  *((_BYTE *)this + 268) = *((_BYTE *)a2 + 268); /*0x103e3fd77*/
  *((_QWORD *)this + 34) = *((_QWORD *)a2 + 34); /*0x103e3fd85*/
  *((_DWORD *)this + 70) = *((_DWORD *)a2 + 70); /*0x103e3fd94*/
  *((_BYTE *)this + 284) = *((_BYTE *)a2 + 284); /*0x103e3fda2*/
  *((_WORD *)this + 143) = *((_WORD *)a2 + 143); /*0x103e3fdb1*/
  result = *((unsigned int *)a2 + 72); /*0x103e3fdb8*/
  *((_DWORD *)this + 72) = result; /*0x103e3fdc0*/
  if ( *((_QWORD *)this + 4) != 0 ) /*0x103e3fdcb*/
    webrtc::webrtc_checks_impl::FatalLog( /*0x103e3fdff*/
      a1: (unsigned int)"network.cc",
      a2: 1233,
      a3: (unsigned int)"SignalTypeChanged.is_empty()",
      a4: (unsigned int)&_ZZN6webrtc18webrtc_checks_impl11LogStreamerIJEE4CallIJEEEvPKciS5_DpRKT_E1t,
      a5: v4,
      a6: v5);
  if ( *((_QWORD *)this + 11) != 0 ) /*0x103e3fdd2*/
    webrtc::webrtc_checks_impl::FatalLog( /*0x103e3fe22*/
      a1: (unsigned int)"network.cc",
      a2: 1234,
      a3: (unsigned int)"SignalNetworkPreferenceChanged.is_empty()",
      a4: (unsigned int)&_ZZN6webrtc18webrtc_checks_impl11LogStreamerIJEE4CallIJEEEvPKciS5_DpRKT_E1t,
      a5: v4,
      a6: v5);
  return result; /*0x103e3fdd4*/
}

// Address: 0x103e3fea2 | Name: __ZN6webrtc7NetworkC1ERKS0_
__int64 __fastcall webrtc::Network::Network(webrtc::Network *this, const webrtc::Network *a2)
{
  return webrtc::Network::Network(this, a2); /*0x103e3fea6*/
}

// Address: 0x103e3feac | Name: __ZN6webrtc7NetworkD2Ev
void __fastcall webrtc::Network::~Network(RBX::Memory **this)
{
  void *v2; // rsi
  char *v3; // [rsp+0h] [rbp-10h] BYREF

  v3 = (char *)(this + 30); /*0x103e3fec0*/
  std::vector<webrtc::InterfaceAddress>::__destroy_vector::operator()[abi:ne200100](a1: &v3); /*0x103e3fec3*/
  if ( (*(_BYTE *)(this + 27) & 1) != 0 ) /*0x103e3fecf*/
    operator delete(a1: *(this + 29), a2: v2); /*0x103e3fed8*/
  if ( (*(_BYTE *)(this + 19) & 1) != 0 ) /*0x103e3fee4*/
    operator delete(a1: *(this + 21), a2: v2); /*0x103e3feed*/
  if ( (*(_BYTE *)(this + 16) & 1) != 0 ) /*0x103e3fef9*/
    operator delete(a1: *(this + 18), a2: v2); /*0x103e3ff02*/
  sigslot::_signal_base<sigslot::single_threaded>::~_signal_base(a1: this + 7); /*0x103e3ff0b*/
  sigslot::_signal_base<sigslot::single_threaded>::~_signal_base(a1: this); /*0x103e3ff13*/
}

// Address: 0x103e3ff20 | Name: __ZN6webrtc7NetworkD1Ev
void __fastcall webrtc::Network::~Network(RBX::Memory **this)
{
  webrtc::Network::~Network(this); /*0x103e3ff25*/
}

// Address: 0x103e3ff2a | Name: __ZNK6webrtc7Network16GetMdnsResponderEv
__int64 __fastcall webrtc::Network::GetMdnsResponder(webrtc::Network *this)
{
  __int64 v1; // rdi

  v1 = *((_QWORD *)this + 15); /*0x103e3ff2e*/
  if ( v1 != 0 ) /*0x103e3ff35*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 16LL))(a1: v1); /*0x103e3ff3b*/
  else
    return 0; /*0x103e3ff3e*/
}

// Address: 0x103e3ff42 | Name: __ZNK6webrtc7Network7GetCostERKNS_15FieldTrialsViewE
__int64 __fastcall webrtc::Network::GetCost(webrtc::Network *this, const webrtc::FieldTrialsView *a2)
{
  int v4; // r12d
  char IsEnabled; // bl
  __int64 result; // rax
  bool v7; // zf
  __int16 v8; // cx
  __int16 v9; // dx

  v4 = *((_DWORD *)this + (*((_DWORD *)this + 68) == 8) + 68); /*0x103e3ff5f*/
  IsEnabled = webrtc::FieldTrialsView::IsEnabled(a1: a2, a2: "WebRTC-UseDifferentiatedCellularCosts", a3: 37); /*0x103e3ff7b*/
  LOWORD(result) = (unsigned __int8)webrtc::FieldTrialsView::IsEnabled(a1: a2, a2: "WebRTC-AddNetworkCostToVpn", a3: 26) /*0x103e3ff9e*/
                 & (*((_DWORD *)this + 68) == 8);
  if ( v4 <= 31 ) /*0x103e3ffa5*/
  {
    switch ( v4 ) /*0x103e3ffbf*/
    {
      case 1: /*0x103e3ffbf*/
        return (unsigned __int16)result;
      case 2: /*0x103e3ffbf*/
        LOWORD(result) = result | 0xA; /*0x103e3ffc1*/
        break; /*0x103e3ffc4*/
      case 3: /*0x103e3ffbf*/
      case 5: /*0x103e3ffbf*/
      case 6: /*0x103e3ffbf*/
      case 7: /*0x103e3ffbf*/
        goto LABEL_13;
      case 4: /*0x103e3ffbf*/
        LOWORD(result) = result | 0x384; /*0x103e40010*/
        break; /*0x103e40015*/
      case 8: /*0x103e3ffbf*/
        LOWORD(result) = 50; /*0x103e40017*/
        break; /*0x103e4001b*/
      default:
        if ( v4 != 16 ) /*0x103e40009*/
          goto LABEL_13; /*0x103e40009*/
        break; /*0x103e40009*/
    }
    return (unsigned __int16)result; /*0x103e40009*/
  }
  if ( v4 <= 127 ) /*0x103e3ffca*/
  {
    if ( v4 == 32 ) /*0x103e3fff4*/
    {
      LOWORD(result) = result + 999; /*0x103e4001d*/
      return (unsigned __int16)result; /*0x103e40022*/
    }
    if ( v4 == 64 ) /*0x103e3fffa*/
    {
      v7 = IsEnabled == 0; /*0x103e3fffc*/
      v8 = 980; /*0x103e3fffe*/
      goto LABEL_19; /*0x103e40003*/
    }
LABEL_13:
    LOWORD(result) = result | 0x32; /*0x103e4000b*/
    return (unsigned __int16)result; /*0x103e4000e*/
  }
  if ( v4 == 128 ) /*0x103e3ffd3*/
  {
    v7 = IsEnabled == 0; /*0x103e40024*/
    v8 = 910; /*0x103e40026*/
    goto LABEL_19; /*0x103e4002b*/
  }
  if ( v4 == 256 ) /*0x103e3ffdc*/
  {
    v7 = IsEnabled == 0; /*0x103e4002d*/
    v8 = 500; /*0x103e4002f*/
    goto LABEL_19; /*0x103e4002f*/
  }
  if ( v4 != 512 ) /*0x103e3ffe5*/
    goto LABEL_13; /*0x103e3ffe5*/
  v7 = IsEnabled == 0; /*0x103e3ffe7*/
  v8 = 250; /*0x103e3ffe9*/
LABEL_19:
  v9 = 900; /*0x103e40034*/
  if ( !v7 ) /*0x103e40039*/
    v9 = v8; /*0x103e40039*/
  LOWORD(result) = result | v9; /*0x103e4003e*/
  return (unsigned __int16)result; /*0x103e40043*/
}

// Address: 0x103e4006c | Name: __ZN6webrtc7Network27GuessAdapterFromNetworkCostEi
unsigned __int64 __fastcall webrtc::Network::GuessAdapterFromNetworkCost(webrtc::Network *this)
{
  int v1; // r14d
  __int64 v2; // rbx
  const mach_header_64 *v3; // rax
  int v4; // r9d

  v1 = (int)this; /*0x103e40073*/
  if ( (int)this > 500 ) /*0x103e4007c*/
  {
    if ( (int)this <= 910 ) /*0x103e400cd*/
    {
      if ( (int)this > 900 ) /*0x103e40137*/
      {
        if ( (_DWORD)this != 901 ) /*0x103e4017e*/
        {
          if ( (_DWORD)this == 910 ) /*0x103e40187*/
          {
            v2 = 128; /*0x103e4018d*/
            goto LABEL_47; /*0x103e40192*/
          }
          goto LABEL_44; /*0x103e40187*/
        }
        v2 = 4; /*0x103e401e4*/
      }
      else
      {
        if ( (_DWORD)this != 501 ) /*0x103e40140*/
        {
          if ( (_DWORD)this == 900 ) /*0x103e4014d*/
          {
            v2 = 4; /*0x103e40153*/
            goto LABEL_47; /*0x103e40158*/
          }
          goto LABEL_44; /*0x103e4014d*/
        }
        v2 = 256; /*0x103e401d6*/
      }
    }
    else if ( (int)this <= 980 ) /*0x103e400d6*/
    {
      if ( (_DWORD)this != 911 ) /*0x103e401bf*/
      {
        if ( (_DWORD)this == 980 ) /*0x103e401c8*/
        {
          v2 = 64; /*0x103e401ca*/
          goto LABEL_47; /*0x103e401cf*/
        }
        goto LABEL_44; /*0x103e401c8*/
      }
      v2 = 128; /*0x103e40207*/
    }
    else
    {
      switch ( (_DWORD)this ) /*0x103e400e3*/
      {
        case 0x3D5: /*0x103e400e3*/
          v2 = 64; /*0x103e40200*/
          break;
        case 0x3E7: /*0x103e400e3*/
          v2 = 32; /*0x103e401f2*/
          goto LABEL_47; /*0x103e401f7*/
        case 0x3E8: /*0x103e400e3*/
          v2 = 32; /*0x103e40103*/
          break;
        default:
          goto LABEL_44; /*0x103e400fd*/
      }
    }
    goto LABEL_43; /*0x103e40108*/
  }
  if ( (int)this <= 49 )
  {
    if ( (int)this > 9 )
    {
      if ( (_DWORD)this == 10 ) /*0x103e40161*/
      {
        v2 = 2; /*0x103e401dd*/
        goto LABEL_47; /*0x103e401e2*/
      }
      if ( (_DWORD)this != 11 ) /*0x103e40167*/
        goto LABEL_44; /*0x103e40167*/
      v2 = 2; /*0x103e4016d*/
    }
    else
    {
      v2 = 1; /*0x103e40113*/
      if ( (_DWORD)this == 0 ) /*0x103e4011b*/
      {
        v3 = nullptr; /*0x103e401d1*/
        return (unsigned __int64)v3 | v2; /*0x103e401d4*/
      }
      if ( (_DWORD)this != 1 )
      {
LABEL_44:
        if ( (unsigned __int8)webrtc::LogMessage::IsNoop<(webrtc::LoggingSeverity)0>() == 0 )
        {
          v2 = 0; /*0x103e4023a*/
          webrtc::webrtc_logging_impl::Log(
            a1: (unsigned int)&webrtc::webrtc_logging_impl::LogStreamer<>::Call<webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)13,webrtc::webrtc_logging_impl::LogMetadata>,webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)9,char const*>,webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)1,int>>(webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)13,webrtc::webrtc_logging_impl::LogMetadata>,webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)9,char const*>,webrtc::webrtc_logging_impl::Val<(webrtc::webrtc_logging_impl::LogArgType)1,int> const&)::t,
            a2: (unsigned int)"network.cc",
            a3: 10920,
            a4: (unsigned int)"Unknown network cost: ",
            a5: v1,
            a6: v4);
          goto LABEL_47; /*0x103e40246*/
        }
        goto LABEL_45; /*0x103e4021f*/
      }
    }
LABEL_43:
    v3 = &_mh_execute_header; /*0x103e4020c*/
    return (unsigned __int64)v3 | v2; /*0x103e40216*/
  }
  if ( (int)this > 249 ) /*0x103e4008f*/
  {
    if ( (_DWORD)this == 250 ) /*0x103e4009c*/
    {
      v2 = 512; /*0x103e401f9*/
      goto LABEL_47; /*0x103e401fe*/
    }
    if ( (_DWORD)this != 251 ) /*0x103e400a9*/
    {
      if ( (_DWORD)this == 500 ) /*0x103e400b6*/
      {
        v2 = 256; /*0x103e400bc*/
LABEL_47:
        v3 = nullptr; /*0x103e4024b*/
        return (unsigned __int64)v3 | v2; /*0x103e4024b*/
      }
      goto LABEL_44; /*0x103e400b6*/
    }
    v2 = 512; /*0x103e401eb*/
    goto LABEL_43; /*0x103e401f0*/
  }
  if ( (_DWORD)this == 50 ) /*0x103e4019b*/
  {
LABEL_45:
    v2 = 0; /*0x103e40221*/
    goto LABEL_47; /*0x103e40223*/
  }
  if ( (_DWORD)this != 51 ) /*0x103e401a5*/
    goto LABEL_44; /*0x103e401a5*/
  v3 = &_mh_execute_header; /*0x103e401a7*/
  v2 = 0; /*0x103e401b1*/
  return (unsigned __int64)v3 | v2; /*0x103e40253*/
}

// Address: 0x104eec136 | Name: __ZNK3RBX7Network17NetAssetProxyTypeINS_22RuntimeContentNetAssetEEeqERKNS0_13NetAssetProxyE
__int64 __fastcall RBX::Network::NetAssetProxyType<RBX::RuntimeContentNetAsset>::operator==(__int64 a1, __int64 a2)
{
  (*(void (__fastcall **)(__int64))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x104eec140*/
  RBX::Network::getNetAssetType<RBX::RuntimeContentNetAsset>(); /*0x104eec143*/
  return 0; /*0x104eec14a*/
}

// Address: 0x105412858 | Name: __ZN3RBX7Network24convertToIpVersionNumberENS0_9IpVersionE
__int64 __fastcall RBX::Network::convertToIpVersionNumber(int a1)
{
  return dword_10979372C[a1]; /*0x105412869*/
}

// Address: 0x105412c41 | Name: __ZN3RBX7Network15useRbxTransportEb
char __fastcall RBX::Network::useRbxTransport(RBX::Network *this)
{
  LOBYTE(this) = FFlag::UseRbxTransportServer & (unsigned __int8)this; /*0x105412c45*/
  if ( ((_BYTE)this == 1 || FFlag::UseRbxTransportClient == 1) && RBX::Network::flagsSendsGoThroughConnection(this) != 0 ) /*0x105412c62*/
    return FFlag::RefactorIngressFlow; /*0x105412c64*/
  else
    return 0; /*0x105412c6c*/
}

// Address: 0x105425877 | Name: __ZN3RBX7Network7sendAckERNS_11NetworkBase18ConnectionInternalENS1_7ChannelEj
char __fastcall RBX::Network::sendAck(__int64 a1, char a2, unsigned int a3)
{
  std::__shared_weak_count *v6; // rbx
  std::__shared_weak_count *v7; // rbx
  __int128 v9; // [rsp+0h] [rbp-50h] BYREF
  std::__shared_weak_count *v10[2]; // [rsp+10h] [rbp-40h] BYREF
  _BYTE v11[45]; // [rsp+23h] [rbp-2Dh] BYREF

  *(_DWORD *)&v11[1] = 4; /*0x105425895*/
  std::allocate_shared[abi:ne200100]<RBX::Network::NetworkStream,std::allocator<RBX::Network::NetworkStream>,int,0>( /*0x1054258ab*/
    a1: v10,
    a2: v11,
    a3: &v11[1]);
  v11[1] = -91; /*0x1054258b4*/
  RBX::Network::NetworkStream::writeBytes(this: v10[0], a2: &v11[1], a3: 1u); /*0x1054258c2*/
  v11[1] = 7; /*0x1054258cf*/
  RBX::Network::NetworkStream::writeBytes(this: v10[0], a2: &v11[1], a3: 1u); /*0x1054258d7*/
  v11[1] = a2; /*0x1054258e4*/
  RBX::Network::NetworkStream::writeBytes(this: v10[0], a2: &v11[1], a3: 1u); /*0x1054258ec*/
  RBX::Network::NetworkStream::writeUInt32VarInt(this: v10[0], a2: a3); /*0x1054258f8*/
  v9 = *(_OWORD *)v10; /*0x105425905*/
  *(_OWORD *)v10 = 0; /*0x10542590b*/
  (*(void (__fastcall **)(__int64, __int64, __int128 *, _QWORD, _QWORD))(*(_QWORD *)a1 + 48LL))( /*0x10542591f*/
    a1,
    a2: 12,
    a3: &v9,
    a4: 0,
    a5: 0);
  v6 = *((std::__shared_weak_count **)&v9 + 1); /*0x105425922*/
  if ( *((_QWORD *)&v9 + 1) != 0 /*0x10542593b*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v9 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x105425943*/
    std::__shared_weak_count::__release_weak(this: v6); /*0x105425949*/
  }
  v7 = v10[1]; /*0x10542594e*/
  if ( v10[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v10[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x105425967*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x10542596f*/
    std::__shared_weak_count::__release_weak(this: v7); /*0x105425975*/
  }
  return 1; /*0x10542597c*/
}

// Address: 0x105429319 | Name: __ZN3RBX7Network35reportFailedNetAssetChecksumAndKickEPKcNS0_14NetChunksFlagsEtNS0_10NetAssetIdES4_RKNSt3__15arrayIhLm16EEES9_mmm
void __fastcall RBX::Network::reportFailedNetAssetChecksumAndKick(
        __int64 a1,
        unsigned __int8 a2,
        unsigned __int16 a3,
        __int64 a4,
        int a5,
        __int64 a6,
        int a7,
        int a8,
        __int64 a9,
        __int64 a10,
        __int64 a11,
        __int64 a12)
{
  __int64 v15; // r13
  int v16; // esi
  __int64 v17; // rdx
  __int64 v18; // rcx
  char *v19; // rsi
  __int64 v20; // r8
  __int64 v21; // r9
  __m128 v22; // xmm0
  __m128 v23; // xmm1
  __m128 v24; // xmm2
  __m128 v25; // xmm3
  __m128 v26; // xmm4
  __m128 v27; // xmm5
  __m128 v28; // xmm6
  __m128 v29; // xmm7
  char *v30; // rcx
  __int64 v31; // r8
  char *v32; // rcx
  __int64 v33; // r8
  char *v34; // rcx
  __int64 v35; // r8
  char *v36; // rcx
  __int64 v37; // r8
  int v38; // r14d
  int v39; // r15d
  char v40; // [rsp+0h] [rbp-350h]
  _QWORD v41[9]; // [rsp+30h] [rbp-320h] BYREF
  _BYTE v42[528]; // [rsp+78h] [rbp-2D8h] BYREF
  __int64 v43; // [rsp+288h] [rbp-C8h]
  _QWORD *v44; // [rsp+290h] [rbp-C0h]
  __int64 v45; // [rsp+298h] [rbp-B8h]
  int v46; // [rsp+2A0h] [rbp-B0h]
  __int64 v47; // [rsp+2A8h] [rbp-A8h] BYREF
  __int64 v48; // [rsp+2B0h] [rbp-A0h]
  __int64 v49; // [rsp+2B8h] [rbp-98h]
  unsigned __int8 v50; // [rsp+2C0h] [rbp-90h] BYREF
  char v51; // [rsp+2C1h] [rbp-8Fh] BYREF
  __int64 v52; // [rsp+2C8h] [rbp-88h]
  void *v53; // [rsp+2D0h] [rbp-80h]
  unsigned __int8 v54; // [rsp+2D8h] [rbp-78h] BYREF
  char v55; // [rsp+2D9h] [rbp-77h] BYREF
  __int64 v56; // [rsp+2E0h] [rbp-70h]
  void *v57; // [rsp+2E8h] [rbp-68h]
  unsigned __int8 v58; // [rsp+2F0h] [rbp-60h] BYREF
  char v59; // [rsp+2F1h] [rbp-5Fh] BYREF
  __int64 v60; // [rsp+2F8h] [rbp-58h]
  void *v61; // [rsp+300h] [rbp-50h]
  unsigned __int8 v62; // [rsp+308h] [rbp-48h] BYREF
  char v63; // [rsp+309h] [rbp-47h] BYREF
  __int64 v64; // [rsp+310h] [rbp-40h]
  void *v65; // [rsp+318h] [rbp-38h]
  unsigned __int8 v66; // [rsp+325h] [rbp-2Bh] BYREF
  unsigned __int16 v67[21]; // [rsp+326h] [rbp-2Ah] BYREF

  v49 = a12; /*0x105429339*/
  v48 = a11; /*0x105429344*/
  v15 = a10; /*0x10542934b*/
  v45 = a4; /*0x105429353*/
  v46 = a5; /*0x10542935a*/
  v47 = a1; /*0x105429361*/
  v67[0] = a3; /*0x105429368*/
  RBX::Crypto::convertToHex(a1: &v50, a2: a6, a3: 16, a4: 1); /*0x105429381*/
  RBX::Crypto::convertToHex(a1: &v54, a2: a9, a3: 16, a4: 1); /*0x105429397*/
  RBX::Network::toString(a1: (__int64)&v58); /*0x1054293a7*/
  RBX::Network::toString(a1: (__int64)&v62); /*0x1054293b4*/
  if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x1054293c6*/
                          this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::NetAssetChecksumReportThrottle,
                          a2: v16) != 0 )
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1054293da*/
      a1: (__int64)v41,
      a2: (__int64)&RBX::Telemetry::kNetAssetChecksumReport);
    RBX::Telemetry::FieldsContainer::addPlaceInstanceId(this: (RBX::Telemetry::FieldsContainer *)v42); /*0x1054293e9*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "Message", a3: 7, a4: a1, a5: 1); /*0x105429406*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "Type", a3: 4, a4: a3, a5: 1); /*0x105429424*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "Flags", a3: 5, a4: a2, a5: 1); /*0x105429441*/
    if ( (v50 & 1) != 0 ) /*0x105429452*/
    {
      v30 = (char *)v53; /*0x105429454*/
      v31 = v52; /*0x105429458*/
    }
    else
    {
      v31 = v50 >> 1; /*0x105429461*/
      v30 = &v51; /*0x105429464*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "Expected Checksum", a3: 17, a4: v30, a5: v31, a6: 1); /*0x105429480*/
    if ( (v54 & 1) != 0 ) /*0x10542948e*/
    {
      v32 = (char *)v57; /*0x105429490*/
      v33 = v56; /*0x105429494*/
    }
    else
    {
      v33 = v54 >> 1; /*0x10542949a*/
      v32 = &v55; /*0x10542949d*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "Generated Checksum", a3: 18, a4: v32, a5: v33, a6: 1); /*0x1054294b6*/
    if ( (v58 & 1) != 0 ) /*0x1054294c4*/
    {
      v34 = (char *)v61; /*0x1054294c6*/
      v35 = v60; /*0x1054294ca*/
    }
    else
    {
      v35 = v58 >> 1; /*0x1054294d0*/
      v34 = &v59; /*0x1054294d3*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "Source Asset", a3: 12, a4: v34, a5: v35, a6: 1); /*0x1054294ec*/
    if ( (v62 & 1) != 0 ) /*0x1054294fa*/
    {
      v36 = (char *)v65; /*0x1054294fc*/
      v37 = v64; /*0x105429500*/
    }
    else
    {
      v37 = v62 >> 1; /*0x105429506*/
      v36 = &v63; /*0x105429509*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "Target Asset", a3: 12, a4: v36, a5: v37, a6: 1); /*0x105429522*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "Result Size", a3: 11, a4: v15, a5: 1); /*0x10542953f*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "Num Delta", a3: 9, a4: v48, a5: 1); /*0x105429560*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "Delta Progress", a3: 14, a4: v49, a5: 1); /*0x105429581*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v41); /*0x10542958d*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v41); /*0x1054295a0*/
  }
  v38 = DFLog::LargeReplicatorTrace; /*0x1054295ac*/
  LOBYTE(v18) = (unsigned __int8)DFLog::LargeReplicatorTrace < 6u; /*0x1054295b3*/
  LOBYTE(v17) = (unsigned __int8)DFLog::LargeReplicatorTrace < 6u || (DFLog::LargeReplicatorTrace & 0xFE00) == 0; /*0x1054295c0*/
  if ( (_BYTE)v17 == 0 )
  {
    v39 = qword_10D7F1EA0; /*0x1054295c8*/
    v66 = a2; /*0x1054295d0*/
    fmt::v8::make_format_args<fmt::v8::basic_format_context<fmt::v8::appender,char>,unsigned short &,unsigned char &,std::string &,std::string &,std::string &,std::string &,unsigned long &,unsigned long &,unsigned long &,char const*&>( /*0x10542961e*/
      a1: v41,
      a2: v67,
      a3: &v66,
      a4: &v50,
      a5: &v54,
      a6: &v58,
      a7: &v62,
      a8: &a10,
      a9: &a11,
      a10: &a12,
      a11: &v47);
    v43 = 0xC444DDDD22LL; /*0x10542962d*/
    v44 = v41; /*0x105429634*/
    v40 = 34; /*0x105429642*/
    *(double *)v22.i64 = FLog::detail::FastLogSafeFormattedInternal(
                           a1: v38,
                           a2: v39,
                           a3: 2,
                           a4: (unsigned int)"[DFLog::LargeReplicatorTrace] Failed Asset Checksum Compare Type {} Flags {} Ex"
                                         "pected Hash {} Generated Hash {} Source {} Target {} Result Size {} Num Deltas "
                                         "{} Progress {}: {}",
                           a5: 176,
                           a6: 1);
  }
  if ( DFFlag::DebugNetAssetChecksumForceDisconnect == 1 ) /*0x105429670*/
    RBX::throw_runtime_error( /*0x1054296cc*/
      this: (RBX *)"Failed NetAsset checksum compare",
      a2: v19,
      a3: v17,
      a4: v18,
      a5: v20,
      a6: v21,
      a7: v22,
      a8: v23,
      a9: v24,
      a10: v25,
      a11: v26,
      a12: v27,
      a13: v28,
      a14: v29,
      a15: v40);
  if ( (v62 & 1) != 0 ) /*0x105429676*/
    operator delete(a1: (RBX::Memory *)v65, a2: v19); /*0x10542967c*/
  if ( (v58 & 1) != 0 ) /*0x105429685*/
    operator delete(a1: (RBX::Memory *)v61, a2: v19); /*0x10542968b*/
  if ( (v54 & 1) != 0 ) /*0x105429694*/
    operator delete(a1: (RBX::Memory *)v57, a2: v19); /*0x10542969a*/
  if ( (v50 & 1) != 0 ) /*0x1054296a6*/
    operator delete(a1: (RBX::Memory *)v53, a2: v19); /*0x1054296ac*/
}

// Address: 0x10542d772 | Name: __ZN3RBX7Network8toStringENS0_24NetAssetReplicationStateE
char *__fastcall RBX::Network::toString(int a1)
{
  return (char *)RBX::Network::netAssetReplicatorStateEnumToString /*0x10542d787*/
       + RBX::Network::netAssetReplicatorStateEnumToString[a1];
}

// Address: 0x10542d789 | Name: __ZN3RBX7Network23lrReportMultiFireForgetEt
unsigned __int64 __fastcall RBX::Network::lrReportMultiFireForget(RBX::Network *this)
{
  unsigned __int64 result; // rax
  __int16 *v2; // [rsp-20h] [rbp-20h] BYREF
  __int16 **v3; // [rsp-18h] [rbp-18h] BYREF
  __int16 v4; // [rsp-Ah] [rbp-Ah] BYREF

  if ( DFFlag::DebugDisableLrFireForgetUnexpect == 0 ) /*0x10542d790*/
  {
    v4 = (__int16)this; /*0x10542d79a*/
    result = RBX::Network::lrReportMultiFireForget(unsigned short)::onceFlag; /*0x10542d79e*/
    if ( RBX::Network::lrReportMultiFireForget(unsigned short)::onceFlag != -1 ) /*0x10542d7a9*/
    {
      v2 = &v4; /*0x10542d7b3*/
      v3 = &v2; /*0x10542d7ba*/
      return std::__call_once( /*0x10542d7cb*/
               a1: &RBX::Network::lrReportMultiFireForget(unsigned short)::onceFlag,
               a2: &v3,
               a3: std::__call_once_proxy[abi:ne200100]<std::tuple<RBX::Network::lrReportMultiFireForget(unsigned short)::$_0 &&>>);
    }
  }
  return result; /*0x10542d7d5*/
}

// Address: 0x10542d7d6 | Name: __ZN3RBX7Network24getInitialLastAckedValueEv
__int64 __fastcall RBX::Network::getInitialLastAckedValue(RBX::Network *this)
{
  RBX::Network *v1; // rdi

  if ( (unsigned int)RBX::Network::getCurrentFrameId(this) != 0 ) /*0x10542d7e1*/
    return (unsigned int)RBX::Network::getCurrentFrameId(this: v1) - 1; /*0x10542d7e8*/
  else
    return 0; /*0x10542d7ec*/
}

// Address: 0x1054334a2 | Name: __ZN3RBX7Network9NetChunksaSEOS1_
__int64 __fastcall RBX::Network::NetChunks::operator=(__int64 a1, __int64 a2)
{
  __int128 v4; // xmm0
  __int128 v5; // xmm1
  __int64 v6; // rcx
  __int64 v7; // rax
  _QWORD v9[6]; // [rsp+0h] [rbp-30h] BYREF

  *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1054334b7*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1054334be*/
  v4 = *(_OWORD *)(a2 + 24); /*0x1054334c1*/
  *(_QWORD *)(a2 + 32) = 0; /*0x1054334c7*/
  v5 = *(_OWORD *)(a1 + 24); /*0x1054334cb*/
  *(_OWORD *)(a1 + 24) = v4; /*0x1054334cf*/
  *(_OWORD *)v9 = v5; /*0x1054334d7*/
  v6 = *(_QWORD *)(a2 + 40); /*0x1054334da*/
  *(_QWORD *)(a2 + 40) = 0; /*0x1054334de*/
  v7 = *(_QWORD *)(a1 + 40); /*0x1054334e2*/
  *(_QWORD *)(a1 + 40) = v6; /*0x1054334e6*/
  v9[2] = v7; /*0x1054334ea*/
  RBX::dynamic_bitset::change_capacity(this: (RBX::dynamic_bitset *)v9, a2: 0); /*0x1054334f0*/
  *(_BYTE *)(a1 + 64) = *(_BYTE *)(a2 + 64); /*0x1054334f9*/
  *(_OWORD *)(a1 + 48) = *(_OWORD *)(a2 + 48); /*0x105433501*/
  return a1; /*0x105433508*/
}

// Address: 0x105437c96 | Name: __ZN3RBX7Network14TDigestCaptureINS_13TDigestNoLockEEaSERKS3_
__int64 __fastcall RBX::Network::TDigestCapture<RBX::TDigestNoLock>::operator=(__int64 a1, __int64 a2)
{
  *(_OWORD *)(a1 + 8) = *(_OWORD *)(a2 + 8); /*0x105437ca3*/
  *(_OWORD *)(a1 + 24) = *(_OWORD *)(a2 + 24); /*0x105437cab*/
  RBX::TDigestNoLock::reset(this: (RBX::TDigestNoLock *)a1); /*0x105437caf*/
  return a1; /*0x105437cbb*/
}

// Address: 0x10543ab06 | Name: __ZN3RBX7Network8toStringENS0_16LargeSenderStateE
char *__fastcall RBX::Network::toString(int a1)
{
  return (char *)RBX::Network::largeSenderStateEnumToString + RBX::Network::largeSenderStateEnumToString[a1]; /*0x10543ab1b*/
}

// Address: 0x10543ab1d | Name: __ZN3RBX7Network15sendStartPacketERNS0_20NetworkStreamContextERNS_11NetworkBase18ConnectionInternalERNS0_11LargeSenderENS3_7ChannelE
__int64 __fastcall RBX::Network::sendStartPacket(__int64 a1, __int64 a2, __int64 a3, unsigned int a4)
{
  __int64 v7; // rdx
  char hasFlags; // r13
  __int64 v9; // rdx
  unsigned int v10; // r14d
  double v11; // xmm0_8
  std::__shared_weak_count *v12; // r15
  const char *v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // r8
  __int64 v16; // r9
  __int64 v17; // r10
  std::__shared_weak_count *v18; // rbx
  _QWORD v20[14]; // [rsp+10h] [rbp-D0h] BYREF
  __int128 v21; // [rsp+80h] [rbp-60h] BYREF
  unsigned int v22; // [rsp+9Ch] [rbp-44h]
  std::__shared_weak_count *v23[2]; // [rsp+A0h] [rbp-40h] BYREF

  v22 = a4; /*0x10543ab31*/
  _ZNSt3__115allocate_sharedB8ne200100IN3RBX7Network13NetworkStreamENS_9allocatorIS3_EEJELi0EEENS_10shared_ptrIT_EERKT0_DpOT1_( /*0x10543ab4e*/
    a1: v23,
    a2: v20);
  LOBYTE(v20[0]) = -91; /*0x10543ab57*/
  RBX::Network::NetworkStream::writeBytes(this: v23[0], a2: v20, a3: 1u); /*0x10543ab67*/
  LOBYTE(v20[0]) = 2; /*0x10543ab77*/
  RBX::Network::NetworkStream::writeBytes(this: v23[0], a2: v20, a3: 1u); /*0x10543ab7f*/
  LOBYTE(v20[0]) = *(_BYTE *)(a3 + 121); /*0x10543ab92*/
  RBX::Network::NetworkStream::writeBytes(this: v23[0], a2: v20, a3: 1u); /*0x10543ab99*/
  LOBYTE(v20[0]) = *(_BYTE *)(a3 + 120); /*0x10543abac*/
  RBX::Network::NetworkStream::writeBytes(this: v23[0], a2: v20, a3: 1u); /*0x10543abb3*/
  hasFlags = RBX::Network::hasFlags(a1: *(unsigned __int8 *)(a3 + 120), a2: 1, a3: v7); /*0x10543abc6*/
  if ( hasFlags != 0 ) /*0x10543abcb*/
  {
    v20[0] = *(unsigned __int16 *)(a3 + 144); /*0x10543abdf*/
    RBX::Network::NetworkStream::writeBytes(this: v23[0], a2: v20, a3: 8u); /*0x10543abe7*/
    RBX::Network::Serializer<RBX::Network::NetAssetId>::serialize(a1, a2: v23[0], a3: a3 + 128); /*0x10543abfa*/
    RBX::Network::NetworkStream::writeUInt32VarInt(this: v23[0], a2: *(_DWORD *)(a3 + 148)); /*0x10543ac09*/
  }
  RBX::Network::Serializer<RBX::Network::NetAssetId>::serialize(a1, a2: v23[0], a3: a3 + 80); /*0x10543ac19*/
  RBX::Network::NetworkStream::writeUInt32VarInt(this: v23[0], a2: *(unsigned __int16 *)(a3 + 104)); /*0x10543ac26*/
  RBX::Network::NetworkStream::writeUInt32VarInt(this: v23[0], a2: *(_DWORD *)(a3 + 16)); /*0x10543ac32*/
  if ( (unsigned __int8)RBX::Network::hasFlags(a1: *(unsigned __int8 *)(a3 + 120), a2: 2, a3: v9) != 0 ) /*0x10543ac47*/
    RBX::Network::NetworkStream::writeBytes(this: v23[0], a2: (const void *)(a3 + 56), a3: 0x10u); /*0x10543ac56*/
  v10 = *((_DWORD *)v23[0] + 12); /*0x10543ac63*/
  v21 = *(_OWORD *)v23; /*0x10543ac6b*/
  *(_OWORD *)v23 = 0; /*0x10543ac71*/
  (*(void (__fastcall **)(__int64, _QWORD, __int128 *, _QWORD, _QWORD))(*(_QWORD *)a2 + 48LL))( /*0x10543ac84*/
    a1: a2,
    a2: v22,
    a3: &v21,
    a4: 0,
    a5: 0);
  v12 = *((std::__shared_weak_count **)&v21 + 1); /*0x10543ac87*/
  if ( *((_QWORD *)&v21 + 1) != 0 /*0x10543aca0*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v21 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x10543aca8*/
    std::__shared_weak_count::__release_weak(this: v12); /*0x10543acae*/
  }
  if ( (unsigned __int8)DFLog::LargeReplicatorTrace >= 6u && BYTE1(DFLog::LargeReplicatorTrace) >= 5u ) /*0x10543accc*/
  {
    v13 = "Asset"; /*0x10543ace6*/
    if ( hasFlags != 0 ) /*0x10543acf0*/
      v13 = "Delta"; /*0x10543acf0*/
    v14 = *(unsigned int *)(a3 + 148); /*0x10543acf4*/
    v15 = *(_QWORD *)(a3 + 80); /*0x10543acfa*/
    v16 = *(unsigned int *)(a3 + 88); /*0x10543acfe*/
    v17 = *(unsigned __int16 *)(a3 + 96); /*0x10543ad02*/
    v20[0] = *(unsigned __int8 *)(a3 + 121); /*0x10543ad07*/
    v20[2] = v13; /*0x10543ad0e*/
    v20[4] = v14; /*0x10543ad15*/
    v20[6] = v15; /*0x10543ad1c*/
    v20[8] = v16; /*0x10543ad23*/
    v20[10] = v17; /*0x10543ad2a*/
    v20[12] = 2245314; /*0x10543ad2e*/
    v20[13] = v20; /*0x10543ad3d*/
    v11 = FLog::detail::FastLogSafeFormattedInternal( /*0x10543ad61*/
            a1: DFLog::LargeReplicatorTrace,
            a2: qword_10D7F1EA0,
            a3: 5,
            a4: (unsigned int)"[DFLog::LargeReplicatorTrace] Sending Header for {} of type {} additional {} guid {} and versi"
                          "on {} and assetType {}",
            a5: 116,
            a6: 1,
            2245314,
            v20,
            v20[0]);
  }
  v18 = v23[1]; /*0x10543ad66*/
  if ( v23[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v23[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10543ad7f*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, double))(*(_QWORD *)v18 + 16LL))(a1: v18, a2: v11); /*0x10543ad87*/
    std::__shared_weak_count::__release_weak(this: v18); /*0x10543ad8d*/
  }
  return v10; /*0x10543ad95*/
}

// Address: 0x10543add1 | Name: __ZN3RBX7Network16sendCancelPacketERNS_11NetworkBase18ConnectionInternalERNS0_11LargeSenderENS1_7ChannelE
__int64 __fastcall RBX::Network::sendCancelPacket(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned int v6; // ebx
  double v7; // xmm0_8
  std::__shared_weak_count *v8; // r12
  __int64 v9; // rcx
  __int64 v10; // rdx
  __int64 v11; // r8
  std::__shared_weak_count *v12; // r14
  _QWORD v14[10]; // [rsp+10h] [rbp-A0h] BYREF
  __int128 v15; // [rsp+60h] [rbp-50h] BYREF
  std::__shared_weak_count *v16[2]; // [rsp+70h] [rbp-40h] BYREF

  _ZNSt3__115allocate_sharedB8ne200100IN3RBX7Network13NetworkStreamENS_9allocatorIS3_EEJELi0EEENS_10shared_ptrIT_EERKT0_DpOT1_( /*0x10543adff*/
    a1: v16,
    a2: v14);
  LOBYTE(v14[0]) = -91; /*0x10543ae07*/
  RBX::Network::NetworkStream::writeBytes(this: v16[0], a2: v14, a3: 1u); /*0x10543ae17*/
  LOBYTE(v14[0]) = 4; /*0x10543ae27*/
  RBX::Network::NetworkStream::writeBytes(this: v16[0], a2: v14, a3: 1u); /*0x10543ae2f*/
  LOBYTE(v14[0]) = *(_BYTE *)(a2 + 121); /*0x10543ae3c*/
  RBX::Network::NetworkStream::writeBytes(this: v16[0], a2: v14, a3: 1u); /*0x10543ae47*/
  v6 = *((_DWORD *)v16[0] + 12); /*0x10543ae54*/
  v15 = *(_OWORD *)v16; /*0x10543ae5b*/
  *(_OWORD *)v16 = 0; /*0x10543ae61*/
  (*(void (__fastcall **)(__int64, _QWORD, __int128 *, _QWORD, _QWORD))(*(_QWORD *)a1 + 48LL))( /*0x10543ae74*/
    a1,
    a2: a3,
    a3: &v15,
    a4: 0,
    a5: 0);
  v8 = *((std::__shared_weak_count **)&v15 + 1); /*0x10543ae77*/
  if ( *((_QWORD *)&v15 + 1) != 0 /*0x10543ae91*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v15 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x10543ae9a*/
    std::__shared_weak_count::__release_weak(this: v8); /*0x10543aea0*/
  }
  if ( (unsigned __int8)DFLog::LargeReplicatorTrace >= 6u && BYTE1(DFLog::LargeReplicatorTrace) >= 5u ) /*0x10543aebe*/
  {
    v9 = *(_QWORD *)(a2 + 80); /*0x10543aece*/
    v10 = *(unsigned int *)(a2 + 88); /*0x10543aed2*/
    v11 = *(unsigned __int16 *)(a2 + 96); /*0x10543aed6*/
    v14[0] = *(unsigned __int8 *)(a2 + 121); /*0x10543aedb*/
    v14[2] = v9; /*0x10543aee2*/
    v14[4] = v10; /*0x10543aee9*/
    v14[6] = v11; /*0x10543aeed*/
    v14[8] = 8770; /*0x10543aef1*/
    v14[9] = v14; /*0x10543aef9*/
    v7 = FLog::detail::FastLogSafeFormattedInternal( /*0x10543af1d*/
           a1: DFLog::LargeReplicatorTrace,
           a2: qword_10D7F1EA0,
           a3: 5,
           a4: (unsigned int)"[DFLog::LargeReplicatorTrace] Sending Cancel for {} guid {} and version {} and assetType {}",
           a5: 91,
           a6: 1,
           8770,
           v14,
           v14[0]);
  }
  v12 = v16[1]; /*0x10543af22*/
  if ( v16[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v16[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10543af3b*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, double))(*(_QWORD *)v12 + 16LL))(a1: v12, a2: v7); /*0x10543af43*/
    std::__shared_weak_count::__release_weak(this: v12); /*0x10543af49*/
  }
  return v6; /*0x10543af50*/
}

// Address: 0x10543af86 | Name: __ZN3RBX7Network13sendEndPacketERNS_11NetworkBase18ConnectionInternalERNS0_11LargeSenderENS1_7ChannelE
__int64 __fastcall RBX::Network::sendEndPacket(__int64 a1, __int64 a2, unsigned int a3)
{
  RBX::Network::NetworkStream *v6; // r14
  RBX::TaskScheduler *v7; // rdi
  unsigned int v8; // eax
  unsigned int v9; // r14d
  RBX::TaskScheduler *v10; // rdi
  double v11; // xmm0_8
  std::__shared_weak_count *v12; // r12
  int v13; // r12d
  int v14; // r13d
  unsigned int v15; // eax
  __int64 v16; // rdx
  __int64 v17; // rsi
  __int64 v18; // rdi
  std::__shared_weak_count *v19; // rbx
  _QWORD v21[12]; // [rsp+10h] [rbp-B0h] BYREF
  __int128 v22; // [rsp+70h] [rbp-50h] BYREF
  std::__shared_weak_count *v23[2]; // [rsp+80h] [rbp-40h] BYREF

  _ZNSt3__115allocate_sharedB8ne200100IN3RBX7Network13NetworkStreamENS_9allocatorIS3_EEJELi0EEENS_10shared_ptrIT_EERKT0_DpOT1_( /*0x10543afb4*/
    a1: v23,
    a2: v21);
  LOBYTE(v21[0]) = -91; /*0x10543afbc*/
  RBX::Network::NetworkStream::writeBytes(this: v23[0], a2: v21, a3: 1u); /*0x10543afcc*/
  LOBYTE(v21[0]) = 3; /*0x10543afdc*/
  RBX::Network::NetworkStream::writeBytes(this: v23[0], a2: v21, a3: 1u); /*0x10543afe4*/
  LOBYTE(v21[0]) = *(_BYTE *)(a2 + 121); /*0x10543aff0*/
  RBX::Network::NetworkStream::writeBytes(this: v23[0], a2: v21, a3: 1u); /*0x10543affb*/
  v6 = v23[0]; /*0x10543b000*/
  v8 = RBX::TaskScheduler::cycle(this: v7); /*0x10543b004*/
  RBX::Network::NetworkStream::writeUInt32VarInt(this: v6, a2: v8); /*0x10543b00e*/
  v9 = *((_DWORD *)v23[0] + 12); /*0x10543b01b*/
  v22 = *(_OWORD *)v23; /*0x10543b023*/
  *(_OWORD *)v23 = 0; /*0x10543b029*/
  (*(void (__fastcall **)(__int64, _QWORD, __int128 *, _QWORD, _QWORD))(*(_QWORD *)a1 + 48LL))( /*0x10543b03c*/
    a1,
    a2: a3,
    a3: &v22,
    a4: 0,
    a5: 0);
  v12 = *((std::__shared_weak_count **)&v22 + 1); /*0x10543b03f*/
  if ( *((_QWORD *)&v22 + 1) != 0 /*0x10543b059*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v22 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x10543b062*/
    std::__shared_weak_count::__release_weak(this: v12); /*0x10543b068*/
  }
  v13 = DFLog::LargeReplicatorTrace; /*0x10543b074*/
  if ( (unsigned __int8)DFLog::LargeReplicatorTrace >= 6u && BYTE1(DFLog::LargeReplicatorTrace) >= 5u ) /*0x10543b087*/
  {
    v14 = qword_10D7F1EA0; /*0x10543b08e*/
    v15 = RBX::TaskScheduler::cycle(this: v10); /*0x10543b092*/
    v16 = *(_QWORD *)(a2 + 80); /*0x10543b09b*/
    v17 = *(unsigned int *)(a2 + 88); /*0x10543b09f*/
    v18 = *(unsigned __int16 *)(a2 + 96); /*0x10543b0a2*/
    v21[0] = *(unsigned __int8 *)(a2 + 121); /*0x10543b0a8*/
    v21[2] = v16; /*0x10543b0af*/
    v21[4] = v17; /*0x10543b0b6*/
    v21[6] = v18; /*0x10543b0bd*/
    v21[8] = v15; /*0x10543b0c1*/
    v21[10] = 139842; /*0x10543b0c5*/
    v21[11] = v21; /*0x10543b0cd*/
    v11 = FLog::detail::FastLogSafeFormattedInternal( /*0x10543b0f7*/
            a1: v13,
            a2: v14,
            a3: 5,
            a4: (unsigned int)"[DFLog::LargeReplicatorTrace] Sending End for {} guid {} version {} type {} frame {}",
            a5: 84,
            a6: 1,
            139842,
            v21,
            v21[0]);
  }
  v19 = v23[1]; /*0x10543b0fc*/
  if ( v23[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v23[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10543b115*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, double))(*(_QWORD *)v19 + 16LL))(a1: v19, a2: v11); /*0x10543b11d*/
    std::__shared_weak_count::__release_weak(this: v19); /*0x10543b123*/
  }
  return v9; /*0x10543b12b*/
}

// Address: 0x10543b161 | Name: __ZN3RBX7Network17getCurrentFrameIdEv
__int64 __fastcall RBX::Network::getCurrentFrameId(RBX::Network *this)
{
  return RBX::TaskScheduler::cycle(this); /*0x10543b165*/
}

// Address: 0x10543b16b | Name: __ZN3RBX7Network9sendChunkERNS_11NetworkBase18ConnectionInternalERNS0_11LargeSenderEmNS1_7ChannelE
__int64 __fastcall RBX::Network::sendChunk(__int64 a1, __int64 a2, __int64 a3, unsigned int a4)
{
  __int64 v7; // rsi
  unsigned int v8; // edx
  unsigned int v9; // r13d
  std::__shared_weak_count *v10; // r15
  std::__shared_weak_count *v11; // rbx
  __int128 v13; // [rsp+0h] [rbp-60h] BYREF
  unsigned int v14; // [rsp+1Ch] [rbp-44h]
  std::__shared_weak_count *v15[2]; // [rsp+20h] [rbp-40h] BYREF
  _BYTE v16[45]; // [rsp+33h] [rbp-2Dh] BYREF

  v14 = a4; /*0x10543b17c*/
  *(_DWORD *)&v16[1] = *(_DWORD *)(a2 + 24) + 5; /*0x10543b192*/
  std::allocate_shared[abi:ne200100]<RBX::Network::NetworkStream,std::allocator<RBX::Network::NetworkStream>,unsigned int,0>( /*0x10543b1a4*/
    a1: v15,
    a2: v16);
  v16[1] = -91; /*0x10543b1ac*/
  RBX::Network::NetworkStream::writeBytes(this: v15[0], a2: &v16[1], a3: 1u); /*0x10543b1ba*/
  v16[1] = 1; /*0x10543b1c7*/
  RBX::Network::NetworkStream::writeBytes(this: v15[0], a2: &v16[1], a3: 1u); /*0x10543b1cf*/
  v16[1] = *(_BYTE *)(a2 + 121); /*0x10543b1e0*/
  RBX::Network::NetworkStream::writeBytes(this: v15[0], a2: &v16[1], a3: 1u); /*0x10543b1e7*/
  *(_WORD *)&v16[1] = a3; /*0x10543b1f4*/
  RBX::Network::NetworkStream::writeBytes(this: v15[0], a2: &v16[1], a3: 2u); /*0x10543b1fc*/
  v7 = a3 * *(unsigned int *)(a2 + 24); /*0x10543b20c*/
  v8 = *(_DWORD *)(a2 + 16) - v7; /*0x10543b210*/
  if ( *(_DWORD *)(a2 + 24) < v8 ) /*0x10543b214*/
    v8 = *(_DWORD *)(a2 + 24); /*0x10543b214*/
  RBX::Network::NetworkStream::writeBytes(this: v15[0], a2: (const void *)(*(_QWORD *)(a2 + 8) + v7), a3: v8); /*0x10543b21f*/
  v9 = *((_DWORD *)v15[0] + 12); /*0x10543b22c*/
  v13 = *(_OWORD *)v15; /*0x10543b234*/
  *(_OWORD *)v15 = 0; /*0x10543b23a*/
  (*(void (__fastcall **)(__int64, _QWORD, __int128 *, _QWORD, _QWORD))(*(_QWORD *)a1 + 48LL))( /*0x10543b24d*/
    a1,
    a2: v14,
    a3: &v13,
    a4: 0,
    a5: 0);
  v10 = *((std::__shared_weak_count **)&v13 + 1); /*0x10543b250*/
  if ( *((_QWORD *)&v13 + 1) != 0 /*0x10543b269*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v13 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x10543b271*/
    std::__shared_weak_count::__release_weak(this: v10); /*0x10543b277*/
  }
  *(_QWORD *)(*(_QWORD *)(a2 + 40) + 8LL * ((unsigned int)a3 >> 6)) |= 1LL << a3; /*0x10543b28f*/
  v11 = v15[1]; /*0x10543b293*/
  if ( v15[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v15[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10543b2ac*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(a1: v11); /*0x10543b2b4*/
    std::__shared_weak_count::__release_weak(this: v11); /*0x10543b2ba*/
  }
  return v9; /*0x10543b2c2*/
}

// Address: 0x10543b2f5 | Name: __ZN3RBX7Network15sendRemoveAssetERNS0_25LargeReplicatorTotalStatsEPNS0_20LargeReplicatorStatsERNS0_20NetworkStreamContextERNS_11NetworkBase18ConnectionInternalENS0_10NetAssetIdEtjNS7_7ChannelE
__int64 __fastcall RBX::Network::sendRemoveAsset(
        __m128i *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        unsigned int a6,
        unsigned __int16 a7,
        int a8,
        unsigned int a9)
{
  RBX::Network::NetworkStream *v12; // r12
  RBX::TaskScheduler *v13; // rdi
  unsigned int v14; // eax
  unsigned int v15; // r12d
  std::__shared_weak_count *v16; // rbx
  __m128i v17; // xmm0
  __int64 v18; // rax
  std::__shared_weak_count *v19; // rbx
  _QWORD v21[6]; // [rsp+10h] [rbp-B0h] BYREF
  __m128i v22; // [rsp+40h] [rbp-80h] BYREF
  __m128i si128; // [rsp+50h] [rbp-70h] BYREF
  __int64 v24; // [rsp+68h] [rbp-58h]
  __int64 v25; // [rsp+70h] [rbp-50h] BYREF
  unsigned int v26; // [rsp+78h] [rbp-48h]
  std::__shared_weak_count *v27[2]; // [rsp+80h] [rbp-40h] BYREF

  v24 = a2; /*0x10543b30f*/
  v25 = a5; /*0x10543b316*/
  v26 = a6; /*0x10543b31a*/
  _ZNSt3__115allocate_sharedB8ne200100IN3RBX7Network13NetworkStreamENS_9allocatorIS3_EEJELi0EEENS_10shared_ptrIT_EERKT0_DpOT1_( /*0x10543b32f*/
    a1: v27,
    a2: v21);
  LOBYTE(v21[0]) = -91; /*0x10543b338*/
  RBX::Network::NetworkStream::writeBytes(this: v27[0], a2: v21, a3: 1u); /*0x10543b348*/
  LOBYTE(v21[0]) = 5; /*0x10543b358*/
  RBX::Network::NetworkStream::writeBytes(this: v27[0], a2: v21, a3: 1u); /*0x10543b360*/
  RBX::Network::Serializer<RBX::Network::NetAssetId>::serialize(a1: a3, a2: v27[0], a3: &v25); /*0x10543b370*/
  RBX::Network::NetworkStream::writeUInt32VarInt(this: v27[0], a2: a7); /*0x10543b381*/
  v12 = v27[0]; /*0x10543b386*/
  v14 = RBX::TaskScheduler::cycle(this: v13); /*0x10543b38a*/
  RBX::Network::NetworkStream::writeUInt32VarInt(this: v12, a2: v14); /*0x10543b394*/
  v15 = *((_DWORD *)v27[0] + 12); /*0x10543b3a5*/
  si128 = _mm_load_si128((const __m128i *)v27); /*0x10543b3ad*/
  *(_OWORD *)v27 = 0; /*0x10543b3b5*/
  (*(void (__fastcall **)(__int64, _QWORD, __m128i *, _QWORD, _QWORD))(*(_QWORD *)a4 + 48LL))( /*0x10543b3c5*/
    a1: a4,
    a2: a9,
    a3: &si128,
    a4: 0,
    a5: 0);
  v16 = (std::__shared_weak_count *)si128.i64[1]; /*0x10543b3cc*/
  if ( si128.i64[1] != 0 /*0x10543b3e5*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(si128.i64[1] + 8), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x10543b3ed*/
    std::__shared_weak_count::__release_weak(this: v16); /*0x10543b3f3*/
  }
  ++a1[14].i32[1]; /*0x10543b3f8*/
  v17 = _mm_loadl_epi64(a1); /*0x10543b3ff*/
  a1->i64[0] = _mm_add_epi32(_mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v15, 0), v17).u64[0]; /*0x10543b418*/
  a1[40].i32[2] -= a8; /*0x10543b41d*/
  --a1[40].i32[0]; /*0x10543b424*/
  v18 = v24; /*0x10543b42b*/
  ++*(_DWORD *)(v24 + 36); /*0x10543b42f*/
  *(_DWORD *)(v18 + 456) -= a8; /*0x10543b432*/
  --*(_DWORD *)(v18 + 448); /*0x10543b439*/
  if ( (unsigned __int8)DFLog::LargeReplicatorTrace >= 6u && BYTE1(DFLog::LargeReplicatorTrace) >= 5u ) /*0x10543b458*/
  {
    v21[0] = v25; /*0x10543b46a*/
    v21[2] = v26; /*0x10543b471*/
    v21[4] = a7; /*0x10543b478*/
    v22.i64[0] = 548; /*0x10543b47f*/
    v22.i64[1] = (__int64)v21; /*0x10543b48e*/
    *(double *)v17.i64 = FLog::detail::FastLogSafeFormattedInternal( /*0x10543b4b4*/
                           a1: DFLog::LargeReplicatorTrace,
                           a2: qword_10D7F1EA0,
                           a3: 5,
                           a4: (unsigned int)"[DFLog::LargeReplicatorTrace] Sending Remove for guid {} and version {} and netAssetType {}",
                           a5: 91,
                           a6: 1,
                           _mm_loadu_si128(&v22),
                           v25);
  }
  v19 = v27[1]; /*0x10543b4b9*/
  if ( v27[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v27[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10543b4d2*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, double))(*(_QWORD *)v19 + 16LL))( /*0x10543b4da*/
      a1: v19,
      a2: *(double *)v17.i64);
    std::__shared_weak_count::__release_weak(this: v19); /*0x10543b4e0*/
  }
  return v15; /*0x10543b4e8*/
}

// Address: 0x10543b934 | Name: __ZN3RBX7Network24sendUpdatesEndedForFrameERNS0_25LargeReplicatorTotalStatsERNS_11NetworkBase18ConnectionInternalENS3_7ChannelE
__int64 __fastcall RBX::Network::sendUpdatesEndedForFrame(__m128i *a1, __int64 a2, unsigned int a3)
{
  RBX::Network::NetworkStream *v6; // r12
  RBX::TaskScheduler *v7; // rdi
  unsigned int v8; // eax
  unsigned int v9; // r12d
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  __int128 v13; // [rsp+0h] [rbp-50h] BYREF
  std::__shared_weak_count *v14[2]; // [rsp+10h] [rbp-40h] BYREF
  _BYTE v15[45]; // [rsp+23h] [rbp-2Dh] BYREF

  *(_DWORD *)&v15[1] = 8; /*0x10543b951*/
  std::allocate_shared[abi:ne200100]<RBX::Network::NetworkStream,std::allocator<RBX::Network::NetworkStream>,int,0>( /*0x10543b967*/
    a1: v14,
    a2: v15,
    a3: &v15[1]);
  v15[1] = -91; /*0x10543b970*/
  RBX::Network::NetworkStream::writeBytes(this: v14[0], a2: &v15[1], a3: 1u); /*0x10543b97e*/
  v15[1] = 6; /*0x10543b98b*/
  RBX::Network::NetworkStream::writeBytes(this: v14[0], a2: &v15[1], a3: 1u); /*0x10543b993*/
  v15[1] = a3; /*0x10543b9a0*/
  RBX::Network::NetworkStream::writeBytes(this: v14[0], a2: &v15[1], a3: 1u); /*0x10543b9a7*/
  v6 = v14[0]; /*0x10543b9ac*/
  v8 = RBX::TaskScheduler::cycle(this: v7); /*0x10543b9b0*/
  RBX::Network::NetworkStream::writeUInt32VarInt(this: v6, a2: v8); /*0x10543b9ba*/
  v9 = (*(__int64 (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14[0] + 24LL))(a1: v14[0]); /*0x10543b9c9*/
  a1->i64[0] = _mm_add_epi32(_mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v9, 0), _mm_loadl_epi64(a1)).u64[0]; /*0x10543b9e4*/
  v13 = *(_OWORD *)v14; /*0x10543b9f1*/
  *(_OWORD *)v14 = 0; /*0x10543b9f7*/
  (*(void (__fastcall **)(__int64, _QWORD, __int128 *, _QWORD, _QWORD))(*(_QWORD *)a2 + 48LL))( /*0x10543ba08*/
    a1: a2,
    a2: a3,
    a3: &v13,
    a4: 0,
    a5: 0);
  v10 = *((std::__shared_weak_count **)&v13 + 1); /*0x10543ba0b*/
  if ( *((_QWORD *)&v13 + 1) != 0 /*0x10543ba24*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v13 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x10543ba2c*/
    std::__shared_weak_count::__release_weak(this: v10); /*0x10543ba32*/
  }
  v11 = v14[1]; /*0x10543ba37*/
  if ( v14[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10543ba50*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(a1: v11); /*0x10543ba58*/
    std::__shared_weak_count::__release_weak(this: v11); /*0x10543ba5e*/
  }
  return v9; /*0x10543ba66*/
}

// Address: 0x10543be0e | Name: __ZN3RBX7Network8hasFlagsENS0_14NetChunksFlagsES1_
bool __fastcall RBX::Network::hasFlags(char a1, unsigned __int8 a2)
{
  return ((unsigned __int8)~a1 & a2) == 0; /*0x10543be1b*/
}

// Address: 0x10543be1d | Name: __ZN3RBX7Network12combineFlagsENS0_14NetChunksFlagsES1_
__int64 __fastcall RBX::Network::combineFlags(unsigned int a1, int a2)
{
  return a2 | a1; /*0x10543be25*/
}

// Address: 0x10543c140 | Name: __ZN3RBX7Network15isServerRemapIdENS_6PeerIdE
bool __fastcall RBX::Network::isServerRemapId(int a1)
{
  return (unsigned int)(a1 - 1) < 0xFF; /*0x10543c14f*/
}

// Address: 0x10543c151 | Name: __ZN3RBX7Network23isValidPeerId_subsystemERNS0_20NetworkStreamContextERKNS0_10NetAssetIdE
bool __fastcall RBX::Network::isValidPeerId_subsystem(__int64 a1, unsigned __int64 *a2)
{
  bool result; // al
  int ServerPeerIdFromGuid; // eax

  result = true; /*0x10543c158*/
  if ( FFlag::NetAssetSubsystem == 1 ) /*0x10543c15d*/
  {
    ServerPeerIdFromGuid = RBX::Network::getServerPeerIdFromGuid(this: *a2); /*0x10543c16b*/
    return (unsigned int)(ServerPeerIdFromGuid - 256) < 0xFFFFFF01 || *(_DWORD *)(a1 + 16) == ServerPeerIdFromGuid; /*0x10543c185*/
  }
  return result; /*0x10543c18d*/
}

// Address: 0x10543c18e | Name: __ZN3RBX7Network14toArrayViewAllERKNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::toArrayViewAll(RBX::Network *this, const RBX::Network::NetworkStream *a2)
{
  __int64 v3; // r14

  v3 = (*(__int64 (__fastcall **)(RBX::Network *, const RBX::Network::NetworkStream *))(*(_QWORD *)this + 16LL))( /*0x10543c19e*/
         a1: this,
         a2);
  (*(void (__fastcall **)(RBX::Network *))(*(_QWORD *)this + 24LL))(a1: this); /*0x10543c1a7*/
  return v3; /*0x10543c1af*/
}

// Address: 0x10543c1b4 | Name: __ZN3RBX7Network24toArrayViewRemainingReadERKNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::toArrayViewRemainingRead(RBX::Network *this, const RBX::Network::NetworkStream *a2)
{
  __int64 v3; // r14

  v3 = *((unsigned int *)this + 14) /*0x10543c1ca*/
     + (*(__int64 (__fastcall **)(RBX::Network *, const RBX::Network::NetworkStream *))(*(_QWORD *)this + 16LL))(
         a1: this,
         a2);
  RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this); /*0x10543c1d0*/
  return v3; /*0x10543c1da*/
}

// Address: 0x1054464f2 | Name: __ZN3RBX7Network18setVersionInternalEPKc
__int64 __fastcall RBX::Network::setVersionInternal(RBX::Network *this, const char *a2)
{
  __int64 result; // rax

  if ( this != nullptr ) /*0x1054464f9*/
    return std::string::assign(a1: RBX::Network::versionB, a2: this); /*0x105446506*/
  return result; /*0x105446505*/
}

// Address: 0x105446580 | Name: __ZN3RBX7Network29buildRbxTransportCapabilitiesENS0_8PeerTypeE
volatile signed __int64 *__fastcall RBX::Network::buildRbxTransportCapabilities(volatile signed __int64 *a1, int a2)
{
  volatile signed __int64 *result; // rax
  char v3; // cl

  result = a1; /*0x105446584*/
  *a1 = 0; /*0x105446587*/
  _InterlockedOr64(a1, 2u); /*0x10544658e*/
  _InterlockedOr64(a1, 0x40u); /*0x105446593*/
  _InterlockedOr64(a1, 0x80u); /*0x105446598*/
  if ( DFFlag::DebugForceStreamingEnabled == 1 ) /*0x1054465aa*/
    _InterlockedOr64(a1, 0x100u); /*0x1054465ac*/
  _InterlockedOr64(a1, 0x20000000000uLL); /*0x1054465be*/
  _InterlockedOr64(a1, 0x800u); /*0x1054465c2*/
  _InterlockedOr64(a1, 0x100000u); /*0x1054465ca*/
  _InterlockedOr64(a1, 0x20u); /*0x1054465d2*/
  _InterlockedOr64(a1, 0x10000u); /*0x1054465d7*/
  _InterlockedOr64(a1, 0x200000u); /*0x1054465df*/
  _InterlockedOr64(a1, 0x800000u); /*0x1054465e7*/
  if ( FFlag::AvatarChatProtocolV1 == 1 ) /*0x1054465f9*/
    _InterlockedOr64(a1, 0x4000000000uLL); /*0x105446605*/
  if ( FFlag::VoxelGridLeanDM == 1 ) /*0x105446613*/
    _InterlockedOr64(a1, 4u); /*0x105446615*/
  _InterlockedOr64(a1, 0x200u); /*0x10544661a*/
  _InterlockedOr64(a1, 0x10u); /*0x105446622*/
  if ( DFFlag::CLI139085 == 1 ) /*0x105446631*/
    _InterlockedOr64(a1, 0x400u); /*0x105446633*/
  _InterlockedOr64(a1, 0x2000u); /*0x10544663b*/
  _InterlockedOr64(a1, 0x4000u); /*0x105446643*/
  _InterlockedOr64(a1, 0x8000u); /*0x10544664b*/
  v3 = 0; /*0x105446653*/
  if ( a2 != 0 ) /*0x105446657*/
  {
    if ( a2 != 1 ) /*0x10544665c*/
      goto LABEL_13; /*0x10544665c*/
    v3 = 1; /*0x10544665e*/
  }
  _InterlockedOr64(a1, 8u); /*0x105446660*/
LABEL_13:
  if ( DFFlag::RaknetPacketTracing == 1 ) /*0x10544666f*/
    _InterlockedOr64(a1, 0x80000u); /*0x105446671*/
  if ( DFFlag::RbxTransportNetworkTracing == 1 ) /*0x105446683*/
    _InterlockedOr64(a1, 0x2000000000000uLL); /*0x10544668f*/
  _InterlockedOr64(a1, 0x20000u); /*0x105446693*/
  if ( FFlag::DebugEnableStreamOutToDisk == 1 ) /*0x1054466a5*/
    _InterlockedOr64(a1, 0x40000000000uLL); /*0x1054466b1*/
  if ( FFlag::EnableStreamingBitStreamStateFlags == 1 ) /*0x1054466bf*/
    _InterlockedOr64(a1, 0x80000000000uLL); /*0x1054466cb*/
  if ( FFlag::EnableSharedStringCaching == 1 ) /*0x1054466d9*/
    _InterlockedOr64(a1, 0x100000000000uLL); /*0x1054466e5*/
  _InterlockedOr64(a1, 0x40000u); /*0x1054466e9*/
  if ( FFlag::DebugAddTestStreamingFrustum != 0 /*0x10544673b*/
    || FFlag::StreamingObserverUsesOctree == 1
    && FFlag::UseExpandedSpatialQueryShapes == 1
    && FFlag::UseCoreSpatialQueryShapesForGC == 1
    && FFlag::EnableFrustumAutomation == 1 )
  {
    _InterlockedOr64(a1, 0x400000000000uLL); /*0x105446707*/
  }
  if ( FFlag::SupportGcRegionQuotaSource == 1 ) /*0x105446747*/
    _InterlockedOr64(a1, 0x2000000000uLL); /*0x105446753*/
  if ( FFlag::ServerTimeItem == 1 ) /*0x105446761*/
    _InterlockedOr64(a1, 0x4000000u); /*0x105446763*/
  if ( FFlag::AddCompressionInConnectionInternalSend == 1 /*0x10544678a*/
    && FFlag::DebugDisableCompressionInConnectionInternalSend == 0
    && FFlag::DebugDisableCompressionInRbxTransportOnly == 0 )
  {
    _InterlockedOr64(a1, 0x400000u); /*0x10544678c*/
    if ( DFFlag::PartiallyCompressPhysicsPackets == 1 ) /*0x10544679e*/
      _InterlockedOr64(a1, 0x2000000u); /*0x1054467a0*/
    if ( DFFlag::AddHashToCompressedPayload == 1 ) /*0x1054467b2*/
      _InterlockedOr64(a1, 0x800000000uLL); /*0x1054467be*/
  }
  _InterlockedOr64(a1, 0x8000000u); /*0x1054467c2*/
  _InterlockedOr64(a1, 0x10000000u); /*0x1054467ca*/
  if ( FFlag::BugfixCLI184305 == 1 && FFlag::EnableNetAssetProxiesCache == 1 ) /*0x1054467e8*/
    _InterlockedOr64(a1, 0x20000000u); /*0x1054467ea*/
  if ( DFFlag::BatchNetAssetJoinBlob == 1 ) /*0x1054467fc*/
    _InterlockedOr64(a1, 0x80000000); /*0x105446803*/
  if ( DFFlag::ServerAuthorityEnableInputLatency == 1 ) /*0x105446811*/
    _InterlockedOr64(a1, 0x400000000uLL); /*0x10544681d*/
  if ( DFFlag::ReplicateCameraStateForSA == 1 ) /*0x10544682b*/
    _InterlockedOr64(a1, 0x1000000000000uLL); /*0x105446837*/
  if ( FFlag::PlayerControlStateEnabled == 1 ) /*0x105446845*/
    _InterlockedOr64(a1, 0x40000000000000uLL); /*0x105446851*/
  _InterlockedOr64(a1, 0x40000000u); /*0x105446855*/
  if ( ((unsigned __int8)v3 & (unsigned __int8)DFFlag::DebugNetworkProfiler) != 0 /*0x105446872*/
    || DFFlag::DebugNetworkProfilerForce == 1 )
  {
    _InterlockedOr64(a1, 0x2000000000000000uLL); /*0x10544687e*/
  }
  _InterlockedOr64(a1, (unsigned __int64)&_mh_execute_header); /*0x10544688c*/
  _InterlockedOr64(a1, 0x200000000uLL); /*0x10544689a*/
  if ( FFlag::ReplicateFocusTargetRadius == 1 ) /*0x1054468a8*/
    _InterlockedOr64(a1, 0x8000000000uLL); /*0x1054468b4*/
  if ( DFFlag::AndroidSurfaceCompositor == 1 ) /*0x1054468c2*/
    _InterlockedOr64(a1, 0x800000000000uLL); /*0x1054468ce*/
  if ( DFFlag::PingItemReportClientMemory == 1 ) /*0x1054468dc*/
    _InterlockedOr64(a1, 0x8000000000000uLL); /*0x1054468e8*/
  if ( DFFlag::EvictDynamicMetadata == 1 ) /*0x1054468f6*/
    _InterlockedOr64(a1, 0x4000000000000uLL); /*0x105446902*/
  if ( FFlag::TagRuleReplicationPipelineEnabled == 1 && (FFlag::TagRuleCoreEnabled & 1) != 0 ) /*0x10544691c*/
    _InterlockedOr64(a1, 0x10000000000000uLL); /*0x105446928*/
  if ( DFFlag::UseCompressedPVSerialization == 1 ) /*0x105446936*/
    _InterlockedOr64(a1, 0x20000000000000uLL); /*0x105446942*/
  return result; /*0x105446946*/
}

// Address: 0x105449666 | Name: __ZN3RBX7Network21writeCompressedCFrameERNS0_13NetworkStreamERKNS_16CompressedCFrameE
__int64 __fastcall RBX::Network::writeCompressedCFrame(
        RBX::Network *this,
        RBX::Network::NetworkStream *a2,
        const RBX::CompressedCFrame *a3)
{
  __int64 v3; // rax
  __int64 result; // rax
  RBX::Network::NetworkStream *v7; // rdi
  unsigned int v8; // edx
  _DWORD v9[7]; // [rsp+0h] [rbp-1Ch] BYREF

  v9[0] = HIDWORD(v3); /*0x10544966f*/
  LOBYTE(v9[0]) = *(_BYTE *)a2 | (*((_BYTE *)a2 + 1) >> 3) & 6 | (8 * *((_BYTE *)a2 + 32)) & 0x18; /*0x10544968f*/
  RBX::Network::NetworkStream::writeBytes(this, a2: v9, a3: 1u); /*0x105449696*/
  if ( *(_BYTE *)a2 == 0 ) /*0x10544969f*/
  {
    RBX::Network::NetworkStream::writeBits(this, a2: *((_BYTE *)a2 + 1) & 0xF, a3: 4u); /*0x1054496b1*/
    RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 1), a3: *((_BYTE *)a2 + 2)); /*0x1054496c2*/
    RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 2), a3: *((_BYTE *)a2 + 2)); /*0x1054496d3*/
    RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 3), a3: *((_BYTE *)a2 + 2)); /*0x1054496e4*/
  }
  result = *((unsigned __int8 *)a2 + 32); /*0x1054496e9*/
  switch ( (_DWORD)result ) /*0x1054496f1*/
  {
    case 3: /*0x1054496f1*/
      v9[0] = *((_DWORD *)a2 + 10); /*0x105449749*/
      RBX::Network::NetworkStream::writeBytes(this, a2: v9, a3: 4u); /*0x105449757*/
      LOWORD(v9[0]) = *((_WORD *)a2 + 22); /*0x105449761*/
      v7 = this; /*0x105449769*/
      v8 = 2; /*0x10544976c*/
      break;
    case 2: /*0x1054496f1*/
      v9[0] = *((_DWORD *)a2 + 10); /*0x105449719*/
      RBX::Network::NetworkStream::writeBytes(this, a2: v9, a3: 4u); /*0x105449727*/
      LOBYTE(v9[0]) = *((_BYTE *)a2 + 44); /*0x105449730*/
      v7 = this; /*0x105449737*/
      v8 = 1; /*0x10544973a*/
      break;
    case 1: /*0x1054496f1*/
      v9[0] = *((_DWORD *)a2 + 10); /*0x105449705*/
      v7 = this; /*0x105449707*/
      v8 = 4; /*0x10544970a*/
      break;
    default:
      return result; /*0x1054496fb*/
  }
  return RBX::Network::NetworkStream::writeBytes(this: v7, a2: v9, a3: v8); /*0x10544977a*/
}

// Address: 0x105449781 | Name: __ZN3RBX7Network20readCompressedCFrameERNS0_13NetworkStreamE
RBX::Network *__fastcall RBX::Network::readCompressedCFrame(RBX::Network *this, RBX::Network::NetworkStream *a2)
{
  unsigned __int8 Byte; // r15
  char v5; // al
  __m128d v6; // xmm0
  unsigned __int8 v7; // r15
  __int64 Bits; // rax
  unsigned __int8 v9; // r13
  char v10; // r12
  __int64 v11; // rdx
  __int64 v12; // rax
  __int64 v13; // rdx
  __int64 v14; // rax
  __int64 v15; // rdx
  __int64 v16; // rax
  __int64 UInt32; // r15
  __int64 UInt16; // rax

  *(_WORD *)((char *)this + 1) = 0; /*0x105449795*/
  *(_OWORD *)((char *)this + 8) = 0; /*0x10544979e*/
  *((_QWORD *)this + 3) = 0; /*0x1054497a5*/
  Byte = RBX::Network::NetworkStream::readByte(this: a2); /*0x1054497b1*/
  *(_BYTE *)this = Byte & 1; /*0x1054497b9*/
  v5 = (Byte >> 3) & 3; /*0x1054497be*/
  *((_BYTE *)this + 32) = v5; /*0x1054497c0*/
  *((_QWORD *)this + 5) = 0; /*0x1054497c3*/
  if ( (Byte & 1) == 0 ) /*0x1054497c9*/
  {
    *((_BYTE *)this + 1) = (8 * Byte) & 0x30 | RBX::Network::NetworkStream::readBits(this: a2, a2: 4u); /*0x1054497e7*/
    RBX::PackedVector::calculateMantissaBits(this, a2: v6); /*0x1054497ed*/
    v7 = *((_BYTE *)this + 2); /*0x1054497f2*/
    Bits = RBX::Network::NetworkStream::readBits(this: a2, a2: v7); /*0x1054497fd*/
    v9 = v7 - 64; /*0x105449802*/
    v10 = -v7; /*0x105449809*/
    v11 = Bits << -v7 >> -v7; /*0x105449815*/
    if ( (unsigned __int8)(v7 - 64) < 0xC1u ) /*0x10544981c*/
      v11 = Bits; /*0x10544981c*/
    *((_QWORD *)this + 1) = v11; /*0x105449820*/
    v12 = RBX::Network::NetworkStream::readBits(this: a2, a2: v7); /*0x10544982a*/
    v13 = v12 << v10 >> v10; /*0x105449838*/
    if ( v9 < 0xC1u ) /*0x10544983f*/
      v13 = v12; /*0x10544983f*/
    *((_QWORD *)this + 2) = v13; /*0x105449843*/
    v14 = RBX::Network::NetworkStream::readBits(this: a2, a2: v7); /*0x10544984d*/
    v15 = v14 << v10 >> v10; /*0x10544985b*/
    if ( v9 < 0xC1u ) /*0x105449862*/
      v15 = v14; /*0x105449862*/
    *((_QWORD *)this + 3) = v15; /*0x105449866*/
    v5 = *((_BYTE *)this + 32); /*0x10544986a*/
  }
  switch ( v5 ) /*0x10544986f*/
  {
    case 3: /*0x10544986f*/
      UInt32 = (unsigned int)RBX::Network::NetworkStream::readUInt32(this: a2); /*0x1054498aa*/
      UInt16 = (unsigned __int16)RBX::Network::NetworkStream::readUInt16(this: a2); /*0x1054498b5*/
      goto LABEL_15; /*0x1054498b5*/
    case 2: /*0x10544986f*/
      UInt32 = (unsigned int)RBX::Network::NetworkStream::readUInt32(this: a2); /*0x105449892*/
      UInt16 = (unsigned __int8)RBX::Network::NetworkStream::readByte(this: a2); /*0x10544989d*/
LABEL_15:
      v16 = UInt32 | (UInt16 << 32); /*0x1054498b8*/
      goto LABEL_16; /*0x1054498bc*/
    case 1: /*0x10544986f*/
      v16 = (unsigned int)RBX::Network::NetworkStream::readUInt32(this: a2); /*0x105449886*/
LABEL_16:
      *((_QWORD *)this + 5) = v16; /*0x1054498bf*/
      break;
    default:
      break; /*0x10544986f*/
  }
  return this; /*0x1054498ca*/
}

// Address: 0x1054498d5 | Name: __ZN3RBX7Network17writePackedVectorERNS0_13NetworkStreamERKNS_12PackedVectorE
__int64 __fastcall RBX::Network::writePackedVector(
        RBX::Network *this,
        RBX::Network::NetworkStream *a2,
        const RBX::PackedVector *a3)
{
  RBX::Network::NetworkStream::writeBits(this, a2: *((unsigned __int8 *)a2 + 1), a3: 4u); /*0x1054498eb*/
  RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 1), a3: *((_BYTE *)a2 + 2)); /*0x1054498fb*/
  RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 2), a3: *((_BYTE *)a2 + 2)); /*0x10544990b*/
  return RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 3), a3: *((_BYTE *)a2 + 2)); /*0x10544991b*/
}

// Address: 0x105449924 | Name: __ZN3RBX7Network16readPackedVectorERNS0_13NetworkStreamE
RBX::Network *__fastcall RBX::Network::readPackedVector(RBX::Network *this, RBX::Network::NetworkStream *a2)
{
  __m128d v4; // xmm0
  unsigned __int8 v5; // r15
  __int64 Bits; // rax
  unsigned __int8 v7; // r13
  char v8; // r12
  __int64 v9; // rdx
  __int64 v10; // rax
  __int64 v11; // rdx
  __int64 v12; // rax
  __int64 v13; // rdx

  *((_BYTE *)this + 2) = 0; /*0x10544993a*/
  *(_OWORD *)((char *)this + 8) = 0; /*0x105449940*/
  *((_QWORD *)this + 3) = 0; /*0x105449944*/
  *(_BYTE *)this = 0; /*0x10544994c*/
  *((_BYTE *)this + 1) = RBX::Network::NetworkStream::readBits(this: a2, a2: 4u); /*0x10544995b*/
  RBX::PackedVector::calculateMantissaBits(this, a2: v4); /*0x105449961*/
  v5 = *((_BYTE *)this + 2); /*0x105449966*/
  Bits = RBX::Network::NetworkStream::readBits(this: a2, a2: v5); /*0x105449971*/
  v7 = v5 - 64; /*0x105449976*/
  v8 = -v5; /*0x10544997d*/
  v9 = Bits << -v5 >> -v5; /*0x105449989*/
  if ( (unsigned __int8)(v5 - 64) < 0xC1u ) /*0x105449990*/
    v9 = Bits; /*0x105449990*/
  *((_QWORD *)this + 1) = v9; /*0x105449994*/
  v10 = RBX::Network::NetworkStream::readBits(this: a2, a2: v5); /*0x10544999e*/
  v11 = v10 << v8 >> v8; /*0x1054499ac*/
  if ( v7 < 0xC1u ) /*0x1054499b3*/
    v11 = v10; /*0x1054499b3*/
  *((_QWORD *)this + 2) = v11; /*0x1054499b7*/
  v12 = RBX::Network::NetworkStream::readBits(this: a2, a2: v5); /*0x1054499c1*/
  v13 = v12 << v8 >> v8; /*0x1054499cf*/
  if ( v7 < 0xC1u ) /*0x1054499d6*/
    v13 = v12; /*0x1054499d6*/
  *((_QWORD *)this + 3) = v13; /*0x1054499da*/
  return this; /*0x1054499e5*/
}

// Address: 0x1054499f0 | Name: __ZN3RBX7Network17writeCompressedPVERNS0_13NetworkStreamERKNS_12CompressedPVE
__int64 __fastcall RBX::Network::writeCompressedPV(
        RBX::Network *this,
        RBX::Network::NetworkStream *a2,
        const RBX::CompressedPV *a3)
{
  RBX::Network::NetworkStream *v5; // r15
  const RBX::PackedVector *v6; // rdx
  __int64 result; // rax
  RBX::Network::NetworkStream *v8; // rdi
  unsigned int v9; // edx
  _DWORD v10[9]; // [rsp+Ch] [rbp-24h] BYREF

  v5 = (RBX::Network::NetworkStream *)((char *)a2 + 48); /*0x105449a1a*/
  LOBYTE(v10[0]) = *(_BYTE *)a2 /*0x105449a32*/
                 | (*((_BYTE *)a2 + 1) >> 3) & 6
                 | (8 * *((_BYTE *)a2 + 32)) & 0x18
                 | (32 * *((_BYTE *)a2 + 48))
                 | (*((_BYTE *)a2 + 80) << 6);
  RBX::Network::NetworkStream::writeBytes(this, a2: v10, a3: 1u); /*0x105449a39*/
  if ( *(_BYTE *)a2 == 0 ) /*0x105449a42*/
  {
    RBX::Network::NetworkStream::writeBits(this, a2: *((_BYTE *)a2 + 1) & 0xF, a3: 4u); /*0x105449a54*/
    RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 1), a3: *((_BYTE *)a2 + 2)); /*0x105449a65*/
    RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 2), a3: *((_BYTE *)a2 + 2)); /*0x105449a76*/
    RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 3), a3: *((_BYTE *)a2 + 2)); /*0x105449a87*/
  }
  if ( *(_BYTE *)v5 == 0 ) /*0x105449a94*/
  {
    if ( DFFlag::CompressedPVUsePackedVector == 1 ) /*0x105449a9d*/
    {
      RBX::Network::writePackedVector(this, a2: v5, a3: v6); /*0x105449aa5*/
    }
    else
    {
      RBX::Network::NetworkStream::writeBits(this, a2: *((unsigned __int8 *)a2 + 49), a3: 4u); /*0x105449ab9*/
      RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 7), a3: *((_BYTE *)a2 + 50)); /*0x105449aca*/
      RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 8), a3: *((_BYTE *)a2 + 50)); /*0x105449adb*/
      RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 9), a3: *((_BYTE *)a2 + 50)); /*0x105449aec*/
    }
  }
  if ( *((_BYTE *)a2 + 80) == 0 ) /*0x105449af6*/
  {
    if ( DFFlag::CompressedPVUsePackedVector == 1 ) /*0x105449aff*/
    {
      RBX::Network::writePackedVector(this, a2: (RBX::Network::NetworkStream *)((char *)a2 + 80), a3: v6); /*0x105449b07*/
    }
    else
    {
      RBX::Network::NetworkStream::writeBits(this, a2: *((unsigned __int8 *)a2 + 81), a3: 4u); /*0x105449b1b*/
      RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 11), a3: *((_BYTE *)a2 + 82)); /*0x105449b2c*/
      RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 12), a3: *((_BYTE *)a2 + 82)); /*0x105449b3d*/
      RBX::Network::NetworkStream::writeBits(this, a2: *((_QWORD *)a2 + 13), a3: *((_BYTE *)a2 + 82)); /*0x105449b4e*/
    }
  }
  result = *((unsigned __int8 *)a2 + 32); /*0x105449b53*/
  switch ( (_DWORD)result ) /*0x105449b5b*/
  {
    case 3: /*0x105449b5b*/
      v10[0] = *((_DWORD *)a2 + 10); /*0x105449bb3*/
      RBX::Network::NetworkStream::writeBytes(this, a2: v10, a3: 4u); /*0x105449bc1*/
      LOWORD(v10[0]) = *((_WORD *)a2 + 22); /*0x105449bcb*/
      v8 = this; /*0x105449bd3*/
      v9 = 2; /*0x105449bd6*/
      break;
    case 2: /*0x105449b5b*/
      v10[0] = *((_DWORD *)a2 + 10); /*0x105449b83*/
      RBX::Network::NetworkStream::writeBytes(this, a2: v10, a3: 4u); /*0x105449b91*/
      LOBYTE(v10[0]) = *((_BYTE *)a2 + 44); /*0x105449b9a*/
      v8 = this; /*0x105449ba1*/
      v9 = 1; /*0x105449ba4*/
      break;
    case 1: /*0x105449b5b*/
      v10[0] = *((_DWORD *)a2 + 10); /*0x105449b6f*/
      v8 = this; /*0x105449b71*/
      v9 = 4; /*0x105449b74*/
      break;
    default:
      return result; /*0x105449b65*/
  }
  return RBX::Network::NetworkStream::writeBytes(this: v8, a2: v10, a3: v9); /*0x105449be0*/
}

// Address: 0x105449bed | Name: __ZN3RBX7Network16readCompressedPVERNS0_13NetworkStreamE
RBX::Network *__fastcall RBX::Network::readCompressedPV(RBX::Network *this, RBX::Network::NetworkStream *a2)
{
  unsigned __int8 Byte; // r15
  char v5; // al
  unsigned __int8 v6; // r15
  __int64 Bits; // rax
  unsigned __int8 v8; // r13
  char v9; // r12
  __int64 v10; // rdx
  __int64 v11; // rax
  __int64 v12; // rdx
  __int64 v13; // rax
  __int64 v14; // rdx
  _OWORD *v15; // r15
  __int128 v16; // xmm0
  int v17; // r12d
  __int64 v18; // rax
  char v19; // r13
  __int64 v20; // rdx
  __int64 v21; // rax
  __int64 v22; // rdx
  __int64 v23; // rax
  __int64 v24; // rdx
  __int128 v25; // xmm0
  unsigned __int8 v26; // r15
  __int64 v27; // rax
  unsigned __int8 v28; // r13
  char v29; // r12
  __int64 v30; // rdx
  __int64 v31; // rax
  __int64 v32; // rdx
  __int64 v33; // rax
  __int64 v34; // rdx
  int v35; // eax
  __int64 v36; // rax
  __int64 UInt32; // r15
  __int64 UInt16; // rax
  _QWORD v40[4]; // [rsp+0h] [rbp-50h] BYREF
  int v41; // [rsp+24h] [rbp-2Ch]

  *(_WORD *)((char *)this + 1) = 0; /*0x105449c07*/
  *(_OWORD *)((char *)this + 8) = 0; /*0x105449c0f*/
  *((_QWORD *)this + 3) = 0; /*0x105449c13*/
  *(_WORD *)((char *)this + 49) = 0; /*0x105449c17*/
  *(_OWORD *)((char *)this + 56) = 0; /*0x105449c1c*/
  *((_QWORD *)this + 9) = 0; /*0x105449c20*/
  *(_WORD *)((char *)this + 81) = 0; /*0x105449c24*/
  *(_OWORD *)((char *)this + 88) = 0; /*0x105449c29*/
  *((_QWORD *)this + 13) = 0; /*0x105449c2d*/
  Byte = RBX::Network::NetworkStream::readByte(this: a2); /*0x105449c39*/
  *(_BYTE *)this = Byte & 1; /*0x105449c41*/
  v5 = (Byte & 0x20) != 0; /*0x105449c46*/
  *((_BYTE *)this + 48) = v5; /*0x105449c48*/
  *((_BYTE *)this + 80) = (Byte & 0x40) != 0; /*0x105449c54*/
  *((_BYTE *)this + 32) = (Byte >> 3) & 3; /*0x105449c60*/
  *((_QWORD *)this + 5) = 0; /*0x105449c63*/
  if ( (Byte & 1) == 0 ) /*0x105449c69*/
  {
    *((_BYTE *)this + 1) = (8 * Byte) & 0x30 | RBX::Network::NetworkStream::readBits(this: a2, a2: 4u); /*0x105449c87*/
    RBX::PackedVector::calculateMantissaBits(this); /*0x105449c8d*/
    v6 = *((_BYTE *)this + 2); /*0x105449c92*/
    Bits = RBX::Network::NetworkStream::readBits(this: a2, a2: v6); /*0x105449c9d*/
    v8 = v6 - 64; /*0x105449ca2*/
    v9 = -v6; /*0x105449ca9*/
    v10 = Bits << -v6 >> -v6; /*0x105449cb5*/
    if ( (unsigned __int8)(v6 - 64) < 0xC1u ) /*0x105449cbc*/
      v10 = Bits; /*0x105449cbc*/
    *((_QWORD *)this + 1) = v10; /*0x105449cc0*/
    v11 = RBX::Network::NetworkStream::readBits(this: a2, a2: v6); /*0x105449cca*/
    v12 = v11 << v9 >> v9; /*0x105449cd8*/
    if ( v8 < 0xC1u ) /*0x105449cdf*/
      v12 = v11; /*0x105449cdf*/
    *((_QWORD *)this + 2) = v12; /*0x105449ce3*/
    v13 = RBX::Network::NetworkStream::readBits(this: a2, a2: v6); /*0x105449ced*/
    v14 = v13 << v9 >> v9; /*0x105449cfb*/
    if ( v8 < 0xC1u ) /*0x105449d02*/
      v14 = v13; /*0x105449d02*/
    *((_QWORD *)this + 3) = v14; /*0x105449d06*/
    v5 = *((_BYTE *)this + 48); /*0x105449d0a*/
  }
  v15 = (_OWORD *)((char *)this + 80); /*0x105449d0d*/
  if ( (v5 & 1) == 0 ) /*0x105449d13*/
  {
    if ( DFFlag::CompressedPVUsePackedVector == 1 ) /*0x105449d24*/
    {
      RBX::Network::readPackedVector(this: (RBX::Network *)v40, a2); /*0x105449d30*/
      v16 = *(_OWORD *)v40; /*0x105449d35*/
      *((_OWORD *)this + 4) = *(_OWORD *)&v40[2]; /*0x105449d3f*/
      *((_OWORD *)this + 3) = v16; /*0x105449d45*/
    }
    else
    {
      *((_BYTE *)this + 49) = RBX::Network::NetworkStream::readBits(this: a2, a2: 4u); /*0x105449d5c*/
      RBX::PackedVector::calculateMantissaBits(this: (RBX::Network *)((char *)this + 48)); /*0x105449d62*/
      v17 = *((unsigned __int8 *)this + 50); /*0x105449d67*/
      v18 = RBX::Network::NetworkStream::readBits(this: a2, a2: *((_BYTE *)this + 50)); /*0x105449d72*/
      v41 = v17 - 64; /*0x105449d7c*/
      v19 = -(char)v17; /*0x105449d82*/
      v20 = v18 << -(char)v17 >> -(char)v17; /*0x105449d8e*/
      if ( (unsigned __int8)(v17 - 64) < 0xC1u ) /*0x105449d95*/
        v20 = v18; /*0x105449d95*/
      *((_QWORD *)this + 7) = v20; /*0x105449d99*/
      v21 = RBX::Network::NetworkStream::readBits(this: a2, a2: v17); /*0x105449da3*/
      v22 = v21 << v19 >> v19; /*0x105449db1*/
      if ( (unsigned __int8)v41 < 0xC1u ) /*0x105449db8*/
        v22 = v21; /*0x105449db8*/
      *((_QWORD *)this + 8) = v22; /*0x105449dbc*/
      v23 = RBX::Network::NetworkStream::readBits(this: a2, a2: v17); /*0x105449dc6*/
      v24 = v23 << v19 >> v19; /*0x105449dd4*/
      if ( (unsigned __int8)v41 < 0xC1u ) /*0x105449ddb*/
        v24 = v23; /*0x105449ddb*/
      *((_QWORD *)this + 9) = v24; /*0x105449ddf*/
    }
  }
  if ( *(_BYTE *)v15 == 0 ) /*0x105449de7*/
  {
    if ( DFFlag::CompressedPVUsePackedVector == 1 ) /*0x105449df4*/
    {
      RBX::Network::readPackedVector(this: (RBX::Network *)v40, a2); /*0x105449e00*/
      v25 = *(_OWORD *)v40; /*0x105449e05*/
      *((_OWORD *)this + 6) = *(_OWORD *)&v40[2]; /*0x105449e10*/
      *v15 = v25; /*0x105449e15*/
    }
    else
    {
      *((_BYTE *)this + 81) = RBX::Network::NetworkStream::readBits(this: a2, a2: 4u); /*0x105449e2b*/
      RBX::PackedVector::calculateMantissaBits(this: (RBX::Network *)((char *)this + 80)); /*0x105449e31*/
      v26 = *((_BYTE *)this + 82); /*0x105449e36*/
      v27 = RBX::Network::NetworkStream::readBits(this: a2, a2: v26); /*0x105449e41*/
      v28 = v26 - 64; /*0x105449e46*/
      v29 = -v26; /*0x105449e4d*/
      v30 = v27 << -v26 >> -v26; /*0x105449e59*/
      if ( (unsigned __int8)(v26 - 64) < 0xC1u ) /*0x105449e60*/
        v30 = v27; /*0x105449e60*/
      *((_QWORD *)this + 11) = v30; /*0x105449e64*/
      v31 = RBX::Network::NetworkStream::readBits(this: a2, a2: v26); /*0x105449e6e*/
      v32 = v31 << v29 >> v29; /*0x105449e7c*/
      if ( v28 < 0xC1u ) /*0x105449e83*/
        v32 = v31; /*0x105449e83*/
      *((_QWORD *)this + 12) = v32; /*0x105449e87*/
      v33 = RBX::Network::NetworkStream::readBits(this: a2, a2: v26); /*0x105449e91*/
      v34 = v33 << v29 >> v29; /*0x105449e9f*/
      if ( v28 < 0xC1u ) /*0x105449ea6*/
        v34 = v33; /*0x105449ea6*/
      *((_QWORD *)this + 13) = v34; /*0x105449eaa*/
    }
  }
  v35 = *((unsigned __int8 *)this + 32); /*0x105449eae*/
  switch ( v35 ) /*0x105449eb5*/
  {
    case 3: /*0x105449eb5*/
      UInt32 = (unsigned int)RBX::Network::NetworkStream::readUInt32(this: a2); /*0x105449eed*/
      UInt16 = (unsigned __int16)RBX::Network::NetworkStream::readUInt16(this: a2); /*0x105449ef8*/
      goto LABEL_35; /*0x105449ef8*/
    case 2: /*0x105449eb5*/
      UInt32 = (unsigned int)RBX::Network::NetworkStream::readUInt32(this: a2); /*0x105449ed5*/
      UInt16 = (unsigned __int8)RBX::Network::NetworkStream::readByte(this: a2); /*0x105449ee0*/
LABEL_35:
      v36 = UInt32 | (UInt16 << 32); /*0x105449efb*/
      goto LABEL_36; /*0x105449eff*/
    case 1: /*0x105449eb5*/
      v36 = (unsigned int)RBX::Network::NetworkStream::readUInt32(this: a2); /*0x105449ec9*/
LABEL_36:
      *((_QWORD *)this + 5) = v36; /*0x105449f02*/
      break;
    default:
      break; /*0x105449eb5*/
  }
  return this; /*0x105449f09*/
}

// Address: 0x10544be72 | Name: __ZN3RBX7Network30networkTracerComponentToStringERKNS0_22NetworkTracerComponentE
__int64 __fastcall RBX::Network::networkTracerComponentToString(__int64 a1, _BYTE *a2, __int64 a3)
{
  __int64 v4; // rcx
  const char *v5; // rsi

  v4 = (unsigned int)(unsigned __int8)*a2 - 32; /*0x10544be7e*/
  switch ( *a2 ) /*0x10544be94*/
  {
    case ' ': /*0x10544be94*/
      v5 = "REPLICATION_HB_CREATED"; /*0x10544be96*/
      break; /*0x10544be9d*/
    case '!': /*0x10544be94*/
      v5 = "REPLICATION_HB_PROCESS_START"; /*0x10544bf79*/
      break; /*0x10544bf80*/
    case '"': /*0x10544be94*/
      v5 = "REPLICATION_HB_PROCESS_QUEUE_TASK"; /*0x10544bf25*/
      break; /*0x10544bf2c*/
    case '#': /*0x10544be94*/
      v5 = "REPLICATION_HB_PROCESS_IN_TASK"; /*0x10544bf0d*/
      break; /*0x10544bf14*/
    case '$': /*0x10544be94*/
      v5 = "REPLICATION_HB_PROCESS_END"; /*0x10544bf91*/
      break; /*0x10544bf98*/
    case '%': /*0x10544be94*/
    case '&': /*0x10544be94*/
    case '\'': /*0x10544be94*/
    case '(': /*0x10544be94*/
    case ')': /*0x10544be94*/
    case '*': /*0x10544be94*/
    case '+': /*0x10544be94*/
    case ',': /*0x10544be94*/
    case '-': /*0x10544be94*/
    case '.': /*0x10544be94*/
    case '/': /*0x10544be94*/
    case '0': /*0x10544be94*/
    case '1': /*0x10544be94*/
    case '2': /*0x10544be94*/
    case '3': /*0x10544be94*/
    case '4': /*0x10544be94*/
    case '5': /*0x10544be94*/
    case '6': /*0x10544be94*/
    case '7': /*0x10544be94*/
    case '8': /*0x10544be94*/
    case '9': /*0x10544be94*/
    case ':': /*0x10544be94*/
    case ';': /*0x10544be94*/
    case '<': /*0x10544be94*/
    case '=': /*0x10544be94*/
    case '>': /*0x10544be94*/
    case '?': /*0x10544be94*/
    case 'M': /*0x10544be94*/
    case 'N': /*0x10544be94*/
    case 'O': /*0x10544be94*/
    case ']': /*0x10544be94*/
    case '^': /*0x10544be94*/
    case '_': /*0x10544be94*/
LABEL_5:
      v5 = "UNKNOWN_NETWORK_TRACER_COMPONENT"; /*0x10544bec5*/
      break; /*0x10544becc*/
    case '@': /*0x10544be94*/
      v5 = "RAKNET_SEND"; /*0x10544bf31*/
      break; /*0x10544bf38*/
    case 'A': /*0x10544be94*/
      v5 = "RAKNET_MSG_IN_BCS"; /*0x10544bfe2*/
      break; /*0x10544bfe9*/
    case 'B': /*0x10544be94*/
      v5 = "RAKNET_STREAM_SERIALIZE_AND_SEND_INITIAL"; /*0x10544bf61*/
      break; /*0x10544bf68*/
    case 'C': /*0x10544be94*/
      v5 = "RAKNET_STREAM_SERIALIZE_AND_SEND_LAST"; /*0x10544bfa9*/
      break; /*0x10544bfb0*/
    case 'D': /*0x10544be94*/
      v5 = "RAKNET_SOCKET_DATA_DESERIALIZE_TO_INTERNAL_PACKET"; /*0x10544bf01*/
      break; /*0x10544bf08*/
    case 'E': /*0x10544be94*/
      v5 = "RAKNET_INTERNAL_PACKET_FORMED"; /*0x10544bf6d*/
      break; /*0x10544bf74*/
    case 'F': /*0x10544be94*/
      v5 = "RAKNET_INTERNAL_PACKET_PUSH_TO_QUEUE"; /*0x10544bfd9*/
      break; /*0x10544bfe0*/
    case 'G': /*0x10544be94*/
      v5 = "RAKNET_PACKET_PUSH_TO_RECEIVE_QUEUE"; /*0x10544bfb5*/
      break; /*0x10544bfbc*/
    case 'H': /*0x10544be94*/
      v5 = "RAKNET_PACKET_RECEIVED_POPPED"; /*0x10544bf85*/
      break; /*0x10544bf8c*/
    case 'I': /*0x10544be94*/
      v5 = "RAKNET_RAKPING_SENDIMMEDIATE"; /*0x10544bfcd*/
      break; /*0x10544bfd4*/
    case 'J': /*0x10544be94*/
      v5 = "RAKNET_RAKPING_RCV_RAKPONG_SENT"; /*0x10544bf3d*/
      break; /*0x10544bf44*/
    case 'K': /*0x10544be94*/
      v5 = "RAKNET_RAKPONG_RCV"; /*0x10544bffd*/
      break; /*0x10544c004*/
    case 'L': /*0x10544be94*/
      v5 = "RAKNET_SOCKET_RECEIVE"; /*0x10544bff4*/
      break; /*0x10544bffb*/
    case 'P': /*0x10544be94*/
      v5 = "CLIENT_RECEIVED"; /*0x10544bf19*/
      break; /*0x10544bf20*/
    case 'Q': /*0x10544be94*/
      v5 = "CLIENT_PROCESS_START"; /*0x10544c00f*/
      break; /*0x10544c016*/
    case 'R': /*0x10544be94*/
      v5 = "CLIENT_TASK_SUBMITTED"; /*0x10544bfc1*/
      break; /*0x10544bfc8*/
    case 'S': /*0x10544be94*/
      v5 = "CLIENT_TASK_ENTERED"; /*0x10544bedd*/
      break; /*0x10544bee4*/
    case 'T': /*0x10544be94*/
      v5 = "CLIENT_ORCHESTRATOR_START"; /*0x10544c006*/
      break; /*0x10544c00d*/
    case 'U': /*0x10544be94*/
      v5 = "CLIENT_ORCHESTRATOR_FINISH"; /*0x10544c021*/
      break; /*0x10544c028*/
    case 'V': /*0x10544be94*/
      v5 = "CLIENT_DM_TASK_SUBMITTED"; /*0x10544bf9d*/
      break; /*0x10544bfa4*/
    case 'W': /*0x10544be94*/
      v5 = "CLIENT_DM_TASK_ENTERED"; /*0x10544bfeb*/
      break; /*0x10544bff2*/
    case 'X': /*0x10544be94*/
      v5 = "SERVER_SEND_START"; /*0x10544bed1*/
      break; /*0x10544bed8*/
    case 'Y': /*0x10544be94*/
      v5 = "SERVER_SEND_QUEUED"; /*0x10544bf55*/
      break; /*0x10544bf5c*/
    case 'Z': /*0x10544be94*/
      v5 = "SERVER_RECEIVED"; /*0x10544c018*/
      break; /*0x10544c01f*/
    case '[': /*0x10544be94*/
      v5 = "SERVER_PROCESS_START"; /*0x10544c02a*/
      break; /*0x10544c031*/
    case '\\': /*0x10544be94*/
      v5 = "SERVER_PROCESS_FINISH"; /*0x10544bef5*/
      break; /*0x10544befc*/
    case '`': /*0x10544be94*/
      v5 = "RBXTRANSPORT_PRE_SEND"; /*0x10544bee9*/
      break; /*0x10544bef0*/
    case 'a': /*0x10544be94*/
      v5 = "RBXTRANSPORT_POST_RECEIVE"; /*0x10544bf49*/
      break; /*0x10544bf50*/
    default:
      switch ( *a2 ) /*0x10544beb7*/
      {
        case 0: /*0x10544beb7*/
          v5 = "REPLICATION_ITEM_CREATE_AND_QUEUE"; /*0x10544beb9*/
          break; /*0x10544bec0*/
        case 1: /*0x10544beb7*/
          v5 = "REPLICATION_ITEM_SERIALIZE"; /*0x10544c04e*/
          break; /*0x10544c055*/
        case 2: /*0x10544beb7*/
          v5 = "REPLICATION_ITEM_TO_TRANSPORT"; /*0x10544c03c*/
          break; /*0x10544c043*/
        case 3: /*0x10544beb7*/
          v5 = "REPLICATION_PACKET_START_DESERIALIZING"; /*0x10544c045*/
          break; /*0x10544c04c*/
        case 4: /*0x10544beb7*/
          v5 = "REPLICATION_ITEM_DESERIALIZED"; /*0x10544c033*/
          break; /*0x10544c03a*/
        case 5: /*0x10544beb7*/
          v5 = "REPLICATION_ITEM_TRACKED_PROCESS_START"; /*0x10544c057*/
          break; /*0x10544c057*/
        default:
          goto LABEL_5;
      }
      break; /*0x10544c057*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1, a2: v5, a3, a4: v4); /*0x10544c061*/
  return a1; /*0x10544c06d*/
}

// Address: 0x10544c39b | Name: __ZN3RBX7Network15writeTracerFlagERNS0_13NetworkStreamEb
__int64 __fastcall RBX::Network::writeTracerFlag(RBX::Network *this, RBX::Network::NetworkStream *a2)
{
  char v3; // [rsp+Fh] [rbp-1h] BYREF

  v3 = (char)a2; /*0x10544c3a7*/
  return RBX::Network::NetworkStream::writeBytes(this, a2: &v3, a3: 1u); /*0x10544c3b7*/
}

// Address: 0x10544c3bd | Name: __ZN3RBX7Network15writeTracerDataERNS0_13NetworkStreamEyh
char __fastcall RBX::Network::writeTracerData(RBX::Network *this, RBX::Network::NetworkStream *a2, unsigned __int8 a3)
{
  RBX::Network::NetworkTracer *v4; // r14
  __int64 TracerObject; // rax
  RBX::Network::NetworkTracerObject *v8; // r13
  unsigned int SerializedSize; // r12d

  if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle == 0 ) /*0x10544c3c7*/
    return 0; /*0x10544c48b*/
  v4 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x10544c3de*/
  if ( a2 == nullptr || v4 == nullptr ) /*0x10544c3eb*/
    return 0; /*0x10544c3f3*/
  TracerObject = RBX::Network::NetworkTracer::getTracerObject(this: v4, (unsigned __int64)a2); /*0x10544c405*/
  if ( TracerObject == 0 ) /*0x10544c40d*/
    return 0; /*0x10544c47a*/
  v8 = (RBX::Network::NetworkTracerObject *)TracerObject; /*0x10544c40f*/
  RBX::Network::NetworkTracerObject::addCheckpoint(a1: TracerObject, a2: a3, a3: 96); /*0x10544c41e*/
  SerializedSize = RBX::Network::NetworkTracerObject::getSerializedSize(this: v8, a2: 0); /*0x10544c42d*/
  RBX::Network::NetworkStream::AddBytesAndReallocate(this, a2: SerializedSize); /*0x10544c435*/
  LODWORD(v8) = *((_DWORD *)this + 12); /*0x10544c43a*/
  (*(void (__fastcall **)(RBX::Network *))(*(_QWORD *)this + 16LL))(a1: this); /*0x10544c444*/
  RBX::Network::NetworkTracer::serializeTracerObject(this: v4, (unsigned __int64)a2); /*0x10544c456*/
  RBX::Network::NetworkStream::SetWriteOffsetBytes(this, a2: (_DWORD)v8 + SerializedSize, a3: false); /*0x10544c466*/
  RBX::Network::NetworkTracer::removeTracerObject(this: v4, (unsigned __int64)a2); /*0x10544c471*/
  return 1; /*0x10544c48a*/
}

// Address: 0x10544c48e | Name: __ZN3RBX7Network20readTracerFromStreamERNS0_13NetworkStreamEhy
__int64 __fastcall RBX::Network::readTracerFromStream(RBX::Network *this, RBX::Network::NetworkStream *a2, __int64 a3)
{
  unsigned __int8 v4; // r14
  RBX::Network::NetworkStream *v6; // rsi
  RBX::Network::NetworkTracerStream *v7; // r12
  unsigned int NumberOfUnreadBytes; // eax
  unsigned int v9; // r13d
  __int64 v10; // rax
  __int64 v11; // r12
  _BYTE v13[64]; // [rsp+0h] [rbp-80h] BYREF
  __int64 v14; // [rsp+40h] [rbp-40h] BYREF
  __int64 v15; // [rsp+48h] [rbp-38h]
  int v16; // [rsp+50h] [rbp-30h]

  v4 = (unsigned __int8)a2; /*0x10544c4a2*/
  if ( (unsigned __int8)RBX::Network::NetworkStream::readByte(this) != 1 ) /*0x10544c4af*/
    return 0; /*0x10544c4af*/
  if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle == 0 /*0x10544c4ed*/
    || (v7 = *(RBX::Network::NetworkTracerStream **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24)) == nullptr
    || DFInt::RbxTransportMaxTracerObjects > 0
    && RBX::Network::NetworkTracer::getTracerObjectCount(this: *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle
                                                                                               + 24)) >= (unsigned __int64)DFInt::RbxTransportMaxTracerObjects )
  {
    RBX::Network::skipTracerDataInStream(this, a2: v6); /*0x10544c578*/
    return 0; /*0x10544c578*/
  }
  NumberOfUnreadBytes = RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this); /*0x10544c4f6*/
  if ( NumberOfUnreadBytes < 8 ) /*0x10544c4fe*/
    return 0; /*0x10544c57d*/
  v9 = NumberOfUnreadBytes; /*0x10544c500*/
  v10 = (*(__int64 (__fastcall **)(RBX::Network *))(*(_QWORD *)this + 16LL))(a1: this); /*0x10544c509*/
  RBX::Network::NetworkStream::NetworkStream( /*0x10544c51f*/
    this: (RBX::Network::NetworkStream *)v13,
    a2: (unsigned __int8 *)(v10 + *((unsigned int *)this + 14)),
    a3: v9,
    a4: true);
  RBX::Network::NetworkTracer::createTracerObjectFromStream(this: (RBX::Network::NetworkTracer *)&v14, a2: v7); /*0x10544c52f*/
  v11 = 0; /*0x10544c537*/
  if ( v16 != 0 && v15 != 0 ) /*0x10544c543*/
  {
    RBX::Network::NetworkStream::SetReadOffsetBytes(this, a2: *((_DWORD *)this + 14) + v16); /*0x10544c54c*/
    RBX::Network::NetworkTracerObject::addCheckpoint_deprecated(a1: v15, a2: v4, a3: 97, a4: a3); /*0x10544c561*/
    v11 = v14; /*0x10544c566*/
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v13); /*0x10544c56e*/
  return v11; /*0x10544c583*/
}

// Address: 0x10544c5a8 | Name: __ZN3RBX7NetworkL22skipTracerDataInStreamERNS0_13NetworkStreamE
void __fastcall RBX::Network::skipTracerDataInStream(RBX::Network *this, RBX::Network::NetworkStream *a2)
{
  unsigned int NumberOfUnreadBytes; // eax
  unsigned int v4; // r14d
  __int64 v5; // rax
  unsigned int v6; // esi
  _BYTE v7[68]; // [rsp+0h] [rbp-60h] BYREF
  unsigned int v8[7]; // [rsp+44h] [rbp-1Ch] BYREF

  NumberOfUnreadBytes = RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this); /*0x10544c5b8*/
  if ( NumberOfUnreadBytes >= 4 ) /*0x10544c5c0*/
  {
    v4 = NumberOfUnreadBytes; /*0x10544c5c2*/
    v5 = (*(__int64 (__fastcall **)(RBX::Network *))(*(_QWORD *)this + 16LL))(a1: this); /*0x10544c5cb*/
    RBX::Network::NetworkStream::NetworkStream( /*0x10544c5e3*/
      this: (RBX::Network::NetworkStream *)v7,
      a2: (unsigned __int8 *)(v5 + *((unsigned int *)this + 14)),
      a3: v4,
      a4: true);
    v8[0] = 0; /*0x10544c5ec*/
    if ( (unsigned __int8)RBX::Network::NetworkStream::readBytesNoThrow( /*0x10544c601*/
                            this: (RBX::Network::NetworkStream *)v7,
                            a2: v8,
                            a3: 4u) != 0 )
    {
      v6 = v8[0]; /*0x10544c603*/
      if ( v8[0] > v4 ) /*0x10544c609*/
      {
        v8[0] = v4; /*0x10544c60b*/
        v6 = v4; /*0x10544c60f*/
      }
      RBX::Network::NetworkStream::SetReadOffsetBytes(this, a2: *((_DWORD *)this + 14) + v6); /*0x10544c618*/
    }
    RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v7); /*0x10544c621*/
  }
}

// Address: 0x1055399b0 | Name: __ZNK3RBX7Network17NetAssetProxyTypeINS_23DeltaConvexDecompHolderEEeqERKNS0_13NetAssetProxyE
__int64 __fastcall RBX::Network::NetAssetProxyType<RBX::DeltaConvexDecompHolder>::operator==(__int64 a1, __int64 a2)
{
  (*(void (__fastcall **)(__int64))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1055399ba*/
  RBX::Network::getNetAssetType<RBX::DeltaConvexDecompHolder>(); /*0x1055399bd*/
  return 0; /*0x1055399c4*/
}

// Address: 0x1066da1d9 | Name: __ZN3RBX7Network8toStringENS0_9DirectionE
const char *__fastcall RBX::Network::toString(int a1)
{
  const char *result; // rax

  result = "Send"; /*0x1066da1e7*/
  if ( a1 == 1 ) /*0x1066da1ee*/
    return "Recv"; /*0x1066da1ee*/
  return result; /*0x1066da1f2*/
}

// Address: 0x1066dd63a | Name: __ZN3RBX7Network16BandwidthMetricsaSERKS1_
__int128 *__fastcall RBX::Network::BandwidthMetrics::operator=(__int128 *a1, __int128 *a2)
{
  __int128 v4; // xmm0

  v4 = *a2; /*0x1066dd64a*/
  a1[1] = a2[1]; /*0x1066dd651*/
  *a1 = v4; /*0x1066dd655*/
  if ( a1 != a2 ) /*0x1066dd65b*/
  {
    std::vector<RBX::Network::PerClassDesc>::__assign_with_size[abi:ne200100]<RBX::Network::PerClassDesc*,RBX::Network::PerClassDesc*>( /*0x1066dd681*/
      a1: a1 + 2,
      a2: *((_QWORD *)a2 + 4),
      a3: *((_QWORD *)a2 + 5),
      a4: 0x8E38E38E38E38E39LL * ((__int64)(*((_QWORD *)a2 + 5) - *((_QWORD *)a2 + 4)) >> 5));
    std::vector<RBX::Network::PerPropertyDesc>::__assign_with_size[abi:ne200100]<RBX::Network::PerPropertyDesc*,RBX::Network::PerPropertyDesc*>( /*0x1066dd6a0*/
      a1: (char *)a1 + 56,
      a2: *((_QWORD *)a2 + 7),
      a3: *((_QWORD *)a2 + 8),
      a4: 0x8E38E38E38E38E39LL * ((__int64)(*((_QWORD *)a2 + 8) - *((_QWORD *)a2 + 7)) >> 4));
  }
  RBX::details::SplitHashTable<RBX::Guid,std::pair<RBX::Guid,RBX::Network::PerInstanceDetailed>,(RBX::SplitHashPolicy)9,0u,RBX::details::DefaultHash<RBX::Guid>,RBX::details::DefaultEqualTo<RBX::Guid>,RBX::details::GetMapKey<RBX::Guid,RBX::Network::PerInstanceDetailed>>::copy_from<RBX::details::SplitHashTable<RBX::Guid,std::pair<RBX::Guid,RBX::Network::PerInstanceDetailed>,(RBX::SplitHashPolicy)9,0u,RBX::details::DefaultHash<RBX::Guid>,RBX::details::DefaultEqualTo<RBX::Guid>,RBX::details::GetMapKey<RBX::Guid,RBX::Network::PerInstanceDetailed>>>( /*0x1066dd6ad*/
    a1: a1 + 5,
    a2: a2 + 5);
  *(__int128 *)((char *)a1 + 120) = *(__int128 *)((char *)a2 + 120); /*0x1066dd6b7*/
  return a1; /*0x1066dd6c2*/
}

// Address: 0x10670defd | Name: __ZN3RBX7NetworkL8drawInfoEPNS_5AdornEPKNS_6ObjectEyRKNS_6Color3Efh
__int64 __fastcall RBX::Network::drawInfo(
        RBX::Network *this,
        RBX::Adorn *a2,
        const RBX::Object *a3,
        __int64 a4,
        const RBX::Color3 *a5,
        __m128 a6)
{
  unsigned __int8 v6; // r12
  RBX::Adorn *v8; // r13
  __int64 v10; // r14
  __int64 v11; // rax
  __int64 v12; // rdi
  __int64 v13; // rsi
  __int64 v14; // r14
  __int64 v15; // rax
  RBX::Camera *v16; // r14
  __m128 v17; // xmm0
  RBX::Camera *v18; // rax
  __int64 v19; // r14
  __m128 v20; // xmm1
  __m128 v21; // xmm1
  __m128 v22; // xmm1
  __m128i v23; // xmm0
  RBX::Color3 *v24; // rdi
  __int64 v25; // rax
  void *v26; // rsi
  __m128 v27; // xmm1
  __m128 inserted; // xmm0
  __m128 v29; // xmm1
  __m128 v30; // xmm1
  __m128 v31; // xmm0
  __int64 v33; // [rsp+38h] [rbp-418h] BYREF
  int v34; // [rsp+40h] [rbp-410h]
  int v35; // [rsp+44h] [rbp-40Ch]
  __int128 v36; // [rsp+48h] [rbp-408h] BYREF
  __int64 v37; // [rsp+58h] [rbp-3F8h] BYREF
  __m128 v38; // [rsp+60h] [rbp-3F0h]
  const RBX::Object *v39; // [rsp+70h] [rbp-3E0h] BYREF
  double v40[3]; // [rsp+78h] [rbp-3D8h] BYREF
  __m128 v41; // [rsp+90h] [rbp-3C0h]
  _BYTE v42[16]; // [rsp+A8h] [rbp-3A8h] BYREF
  void *v43; // [rsp+B8h] [rbp-398h]
  const RBX::Object *v44; // [rsp+C0h] [rbp-390h] BYREF
  int v45; // [rsp+C8h] [rbp-388h]
  int v46; // [rsp+CCh] [rbp-384h]
  __m128 v47; // [rsp+D0h] [rbp-380h]
  __m128 v48; // [rsp+E0h] [rbp-370h]
  _DWORD v49[2]; // [rsp+F0h] [rbp-360h] BYREF
  __int64 v50; // [rsp+F8h] [rbp-358h]
  __m128 v51[2]; // [rsp+100h] [rbp-350h] BYREF
  unsigned int v52; // [rsp+124h] [rbp-32Ch] BYREF
  float v53; // [rsp+128h] [rbp-328h]
  unsigned int v54; // [rsp+12Ch] [rbp-324h]

  v41 = a6; /*0x10670df11*/
  v50 = a4; /*0x10670df18*/
  if ( this != nullptr && a2 != nullptr ) /*0x10670df36*/
  {
    v6 = (unsigned __int8)a5; /*0x10670df41*/
    v8 = a2; /*0x10670df47*/
    v10 = *((_QWORD *)a2 + 3); /*0x10670df4d*/
    v11 = RBX::Instance::classDescriptor(this); /*0x10670df51*/
    if ( *(unsigned __int16 *)(v10 + 440) - (unsigned int)*(unsigned __int16 *)(v11 + 440) <= *(unsigned __int16 *)(v11 + 442) ) /*0x10670df70*/
    {
      while ( 1 ) /*0x10670df76*/
      {
        v8 = *((RBX::Adorn **)v8 + 13); /*0x10670df76*/
        if ( v8 == nullptr ) /*0x10670df7d*/
          break; /*0x10670df7d*/
        v14 = *((_QWORD *)v8 + 3); /*0x10670df83*/
        v15 = RBX::Reflection::Class_getDescriptorPtr<RBX::BasePart>(a1: v12, a2: v13); /*0x10670df87*/
        if ( *(unsigned __int16 *)(v14 + 440) - (unsigned int)*(unsigned __int16 *)(v15 + 440) <= *(unsigned __int16 *)(v15 + 442) ) /*0x10670dfa6*/
        {
          v16 = (RBX::Camera *)(**(__int64 (__fastcall ***)(RBX::Network *))this)(a1: this); /*0x10670dfb0*/
          RBX::BasePartProp::getCoordinateFrame(this: (RBX::BasePartProp *)v51); /*0x10670dfc4*/
          RBX::Camera::project(this: v16, a2: (const RBX::Vector3 *)&v52); /*0x10670dfd3*/
          v47 = v17; /*0x10670dfd8*/
          v18 = (RBX::Camera *)(**(__int64 (__fastcall ***)(RBX::Network *))this)(a1: this); /*0x10670dfe5*/
          v19 = RBX::Camera::coordinateFrame(this: v18); /*0x10670dfef*/
          RBX::BasePartProp::getCoordinateFrame(this: (RBX::BasePartProp *)v51); /*0x10670dffc*/
          v20 = _mm_movehdup_ps(v47); /*0x10670e018*/
          v20.f32[0] = v20.f32[0] + (float)((float)((float)v6 * 10.0) + (float)((float)v6 * 10.0)); /*0x10670e020*/
          v48 = v20; /*0x10670e024*/
          v21 = _mm_sub_ps( /*0x10670e05e*/
                  _mm_insert_ps((__m128)*(unsigned int *)(v19 + 36), (__m128)*(unsigned int *)(v19 + 44), 16),
                  _mm_insert_ps((__m128)v52, (__m128)v54, 16));
          v22 = _mm_mul_ps(v21, v21); /*0x10670e065*/
          if ( (float)(_mm_movehdup_ps(v22).f32[0] /*0x10670e07f*/
                     + (float)((float)((float)(*(float *)(v19 + 40) - v53) * (float)(*(float *)(v19 + 40) - v53))
                             + v22.f32[0])) < 150000.0 )
          {
            RBX::TextLayout::TextLayout(this: (RBX::TextLayout *)v51); /*0x10670e08c*/
            v23 = (__m128i)0x42C80000u; /*0x10670e091*/
            *(float *)v23.i32 = 100.0 * v41.f32[0]; /*0x10670e099*/
            v39 = a3; /*0x10670e0ac*/
            *(_QWORD *)&v40[1] = (unsigned int)_mm_cvtsi128_si32(v23); /*0x10670e0b0*/
            fmt::v8::vformat(a1: v42, a2: "{}:{:.2f}%", 10, 148, &v39); /*0x10670e0d0*/
            v49[0] = v47.i32[0]; /*0x10670e0dc*/
            v49[1] = v48.i32[0]; /*0x10670e0eb*/
            v44 = *(const RBX::Object **)v50; /*0x10670e0fe*/
            v45 = *(_DWORD *)(v50 + 8); /*0x10670e10b*/
            v46 = 1065353216; /*0x10670e113*/
            v25 = RBX::Color3::black(this: v24); /*0x10670e11d*/
            v33 = *(_QWORD *)v25; /*0x10670e12d*/
            v34 = *(_DWORD *)(v25 + 8); /*0x10670e137*/
            v35 = 1065353216; /*0x10670e13d*/
            v37 = 0; /*0x10670e14e*/
            v36 = xmmword_108F4A5E0; /*0x10670e15f*/
            v39 = nullptr; /*0x10670e162*/
            _mm_storel_ps(v40, (__m128)0x3F800000u); /*0x10670e171*/
            LODWORD(v40[1]) = 0; /*0x10670e178*/
            RBX::TextLayout::setPropsForLegacyAdornDraw2DTextCall( /*0x10670e1c7*/
              a1: (unsigned int)v51,
              a2: (unsigned int)v42,
              a3: (unsigned int)v49,
              a4: 0,
              a5: (unsigned int)&v44,
              a6: (unsigned int)&v33,
              a7: 0,
              a8: 1,
              a9: 0,
              a10: (__int64)&v37,
              a11: (__int64)&v36,
              a12: (__int64)&v39,
              a13: 1);
            if ( (v42[0] & 1) != 0 ) /*0x10670e1d3*/
              operator delete(a1: (RBX::Memory *)v43, a2: v26); /*0x10670e1dc*/
            RBX::Adorn::drawFont2D(this, a2: (RBX::TextLayout *)v51); /*0x10670e1eb*/
            RBX::TextLayout::~TextLayout(this: (RBX::TextLayout *)v51); /*0x10670e1f7*/
          }
          v27 = v48; /*0x10670e1fc*/
          v27.f32[0] = v48.f32[0] + 10.0; /*0x10670e203*/
          inserted = _mm_insert_ps(v47, v27, 16); /*0x10670e212*/
          v29 = _mm_add_ps((__m128)0x4120000042960000uLL, inserted); /*0x10670e220*/
          v38 = _mm_min_ps(v29, inserted); /*0x10670e22c*/
          v48 = _mm_max_ps(v29, inserted); /*0x10670e236*/
          v51[0] = _mm_movelh_ps(v38, v48); /*0x10670e247*/
          v39 = *(const RBX::Object **)v50; /*0x10670e25c*/
          LODWORD(v40[0]) = *(_DWORD *)(v50 + 8); /*0x10670e265*/
          HIDWORD(v40[0]) = 1065353216; /*0x10670e26a*/
          RBX::Adorn::outlineRect2d(this, a2: (const RBX::Rect2D *)v51, a3: 1.0, a4: (const RBX::Color4 *)&v39); /*0x10670e27c*/
          v30 = v41; /*0x10670e281*/
          v30.f32[0] = (float)(v41.f32[0] * 75.0) + v47.f32[0]; /*0x10670e297*/
          v31 = v30; /*0x10670e29b*/
          v31.f32[0] = fminf(v30.f32[0], v47.f32[0]); /*0x10670e29e*/
          v30.f32[0] = fmaxf(v30.f32[0], v47.f32[0]); /*0x10670e2ac*/
          v51[0] = _mm_movelh_ps(_mm_blend_ps(v31, v38, 2), _mm_blend_ps(v30, v48, 2)); /*0x10670e2c4*/
          v39 = *(const RBX::Object **)v50; /*0x10670e2dd*/
          LODWORD(v40[0]) = *(_DWORD *)(v50 + 8); /*0x10670e2e5*/
          HIDWORD(v40[0]) = 1065353216; /*0x10670e2ea*/
          RBX::Adorn::rect2d(this, a2: (const RBX::Rect2D *)v51, a3: (const RBX::Color4 *)&v39); /*0x10670e2f4*/
          return __stack_chk_guard; /*0x10670e2f4*/
        }
      }
    }
  }
  return __stack_chk_guard; /*0x10670e309*/
}

// Address: 0x106712964 | Name: __ZN3RBX7Network16unregisterHelperEPNS_8GuidItemINS_6ObjectEE8RegistryERKNSt3__110shared_ptrINS_8InstanceEEE
__int64 __fastcall RBX::Network::unregisterHelper(__int64 a1, __int64 *a2)
{
  __int64 result; // rax
  _QWORD *v3; // rsi

  result = *a2; /*0x106712968*/
  v3 = (_QWORD *)(*a2 + 40); /*0x10671296b*/
  if ( result == 0 ) /*0x106712972*/
    v3 = nullptr; /*0x106712972*/
  if ( *v3 != 0 ) /*0x10671297a*/
    return RBX::GuidItem<RBX::Object>::Registry::unregister(a1, a2: v3); /*0x10671297d*/
  return result; /*0x10671297c*/
}

// Address: 0x106726205 | Name: __ZN3RBX7Network15getNetworkDebugEPNS_9DataModelE
__int64 __fastcall RBX::Network::getNetworkDebug(RBX::Network *this, RBX::DataModel *a2)
{
  if ( (unsigned __int8)RBX::DataModel::isPlayClientLaunchIntent(this) == 0 ) /*0x106726215*/
    RBX::DataModel::isServerLaunchIntent(this); /*0x10672621a*/
  return 0; /*0x106726225*/
}

// Address: 0x106734efe | Name: __ZN3RBX7NetworkL22writeControlFieldValueERNS0_13NetworkStreamERNS0_10ReplicatorENS_16ControlFieldTypeERKNS_10Reflection7VariantE
__int64 __fastcall RBX::Network::writeControlFieldValue(
        RBX::Network::NetworkStream *a1,
        RBX::Network::IdSerializer *this,
        int a3,
        __int64 *a4)
{
  __int64 result; // rax
  __m128 v7; // xmm0
  float v8; // xmm1_4
  __m128d v9; // xmm0
  const RBX::PackedVector *v10; // rdx
  float v11; // xmm0_4
  __int64 v13; // r12
  RBX::Instance *v14; // rdi
  __int64 v15; // r12
  __int64 v16; // r12
  __int64 v17; // rax
  __int64 v18; // r12
  __int64 v19; // rax
  __m128 v20; // xmm0
  RBX::Network::NetworkStream *v21; // rdi
  unsigned int v22; // edx
  __m128d v23; // xmm0
  double v24; // xmm1_8
  const RBX::CompressedCFrame *v25; // rdx
  std::__shared_weak_count *v26; // rbx
  double v27[6]; // [rsp+0h] [rbp-80h] BYREF
  std::__shared_weak_count *v28[2]; // [rsp+30h] [rbp-50h] BYREF

  switch ( a3 ) /*0x106734f2c*/
  {
    case 0: /*0x106734f2c*/
      LOBYTE(v28[0]) = RBX::Reflection::Variant::get<bool>(a1: a4); /*0x106735023*/
      v21 = a1; /*0x106735025*/
      v22 = 1; /*0x106735028*/
      return RBX::Network::NetworkStream::writeBytes(this: v21, a2: v28, a3: v22); /*0x10673502d*/
    case 1: /*0x106734f2c*/
      v23.f64[0] = RBX::Reflection::Variant::get<double>(a1: a4); /*0x106735032*/
      v24 = fmin(2147483647.0, v23.f64[0]); /*0x106735049*/
      v23.f64[0] = _mm_cmplt_sd(v23, (__m128d)0xC1E0000000000000LL).f64[0]; /*0x106735055*/
      LODWORD(v28[0]) = (int)COERCE_DOUBLE(*(_QWORD *)&v23.f64[0] & 0xC1E0000000000000LL | ~*(_QWORD *)&v23.f64[0] /*0x106735072*/
                                                                                         & *(_QWORD *)&v24);
      goto LABEL_13; /*0x106735072*/
    case 2: /*0x106734f2c*/
      v11 = RBX::Reflection::Variant::get<double>(a1: a4); /*0x106734f7d*/
      *(float *)v28 = v11; /*0x106734f85*/
LABEL_13:
      v21 = a1; /*0x106735074*/
      v22 = 4; /*0x106735077*/
      return RBX::Network::NetworkStream::writeBytes(this: v21, a2: v28, a3: v22); /*0x106735081*/
    case 3: /*0x106734f2c*/
      *(double *)v20.i64 = RBX::Reflection::Variant::get<RBX::Vector2>(a1: a4); /*0x106734ffe*/
      _mm_storel_ps((double *)v28, v20); /*0x106735007*/
      return RBX::Network::Serializer<RBX::Vector2>::serialize(this: a1); /*0x106735012*/
    case 4: /*0x106734f2c*/
    case 5: /*0x106734f2c*/
      *(double *)v7.i64 = RBX::Reflection::Variant::get<RBX::Vector3>(a1: a4); /*0x106734f31*/
      *(__m128d *)v27 = _mm_cvtps_pd(v7); /*0x106734f3d*/
      v27[2] = v8; /*0x106734f47*/
      RBX::PackedVector::encode(this: (RBX::PackedVector *)v28, a2: (const RBX::Vector3d *)v27, a3: 4); /*0x106734f58*/
      RBX::PackedVector::calculateMantissaBits(this: (RBX::PackedVector *)v28, a2: v9); /*0x106734f60*/
      return RBX::Network::writePackedVector(this: a1, a2: (RBX::Network::NetworkStream *)v28, a3: v10); /*0x106734f70*/
    case 6: /*0x106734f2c*/
      RBX::Reflection::Variant::get<RBX::CoordinateFrame>(a1: v27, a2: a4); /*0x106735090*/
      RBX::CompressedCFrame::fromCFrame( /*0x1067350a7*/
        this: (RBX::CompressedCFrame *)v28,
        a2: (const RBX::CoordinateFrame *)v27,
        a3: 10.0);
      return RBX::Network::writeCompressedCFrame(this: a1, a2: (RBX::Network::NetworkStream *)v28, a3: v25); /*0x1067350b7*/
    case 7: /*0x106734f2c*/
      v13 = *a4; /*0x106734f91*/
      if ( (RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Instance>>(a1) == v13 /*0x106734fe9*/
         || (v15 = *a4, RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Object>>(a1: v14) == v15)
         || (v16 = *a4,
             RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::DescribedBase>>(a1: v14) == v16))
        && ((v17 = a4[2]) == 0
         || (v18 = *(_QWORD *)(v17 + 24),
             v19 = RBX::Instance::classDescriptor(this: v14),
             *(unsigned __int16 *)(v18 + 440) - (unsigned int)*(unsigned __int16 *)(v19 + 440) <= *(unsigned __int16 *)(v19 + 442))) )
      {
        RBX::Reflection::Variant::get<std::shared_ptr<RBX::Instance>>(a1: v28, a2: a4); /*0x1067350c3*/
        if ( v28[0] != nullptr && *((_DWORD *)v28[0] + 12) == 1 ) /*0x1067350d5*/
        {
          result = RBX::Network::IdSerializer::serializeServerCreatedId( /*0x1067350e1*/
                     this,
                     a2: a1,
                     a3: (std::__shared_weak_count *)((char *)v28[0] + 48));
          goto LABEL_20; /*0x1067350e6*/
        }
      }
      else
      {
        *(_OWORD *)v28 = 0; /*0x106734ff2*/
      }
      LODWORD(v27[0]) = 0; /*0x1067350ec*/
      result = RBX::Network::NetworkStream::writeBytes(this: a1, a2: v27, a3: 4u); /*0x1067350fa*/
LABEL_20:
      v26 = v28[1]; /*0x1067350ff*/
      if ( v28[1] != nullptr ) /*0x106735106*/
      {
        result = _InterlockedExchangeAdd64((volatile signed __int64 *)v28[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x10673510f*/
        if ( result == 0 ) /*0x106735118*/
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v26 + 16LL))(a1: v26); /*0x106735120*/
          return std::__shared_weak_count::__release_weak(this: v26); /*0x106735126*/
        }
      }
      return result; /*0x10673512b*/
    default:
      return result;
  }
}

// Address: 0x106735178 | Name: __ZN3RBX7NetworkL15writeInputStateERNS0_13NetworkStreamENS_5Enums15InputActionTypeENS_10Reflection7VariantE
__int64 __fastcall RBX::Network::writeInputState(RBX::Network::NetworkStream *this, int a2, _QWORD *a3)
{
  double v3; // rbx
  double v4; // rbp
  __m128 v6; // xmm0
  __int64 result; // rax
  __m128 v8; // xmm0
  int v9; // xmm1_4
  RBX::Network::NetworkStream *v10; // rdi
  unsigned int v11; // edx
  double v12[4]; // [rsp-20h] [rbp-20h] BYREF

  v12[3] = v4; /*0x106735181*/
  v12[2] = v3; /*0x106735185*/
  switch ( a2 ) /*0x10673519d*/
  {
    case 0: /*0x10673519d*/
      LOBYTE(v12[0]) = RBX::Reflection::Variant::get<bool>(a1: a3); /*0x1067351e2*/
      v10 = this; /*0x1067351e4*/
      v11 = 1; /*0x1067351e7*/
      goto LABEL_6; /*0x1067351ec*/
    case 1: /*0x10673519d*/
      LODWORD(v12[0]) = RBX::Reflection::Variant::get<float>(a1: a3); /*0x1067351fa*/
      v10 = this; /*0x1067351fe*/
      v11 = 4; /*0x106735201*/
LABEL_6:
      result = RBX::Network::NetworkStream::writeBytes(this: v10, a2: v12, a3: v11); /*0x106735206*/
      break; /*0x106735206*/
    case 2: /*0x10673519d*/
    case 4: /*0x10673519d*/
      *(double *)v6.i64 = RBX::Reflection::Variant::get<RBX::Vector2>(a1: a3); /*0x1067351a2*/
      _mm_storel_ps(v12, v6); /*0x1067351ab*/
      result = RBX::Network::Serializer<RBX::Vector2>::serialize(this); /*0x1067351b1*/
      break; /*0x1067351b6*/
    case 3: /*0x10673519d*/
      *(double *)v8.i64 = RBX::Reflection::Variant::get<RBX::Vector3>(a1: a3); /*0x1067351bb*/
      _mm_storel_ps(v12, v8); /*0x1067351c4*/
      LODWORD(v12[1]) = v9; /*0x1067351c7*/
      result = RBX::Network::Serializer<RBX::Vector3>::serialize(this); /*0x1067351cf*/
      break; /*0x1067351d4*/
    default:
      return result;
  }
  return result; /*0x106735211*/
}

// Address: 0x106736713 | Name: __ZN3RBX7NetworkL17writeScratchSpaceERNS0_13NetworkStreamERNS0_10ReplicatorERKNS_15CoordinateFrameERKNSt3__110shared_ptrINS_8InstanceEEESD_
__int64 __fastcall RBX::Network::writeScratchSpace(
        RBX::Network::NetworkStream *a1,
        RBX::Network::IdSerializer *a2,
        RBX::CoordinateFrame *a3,
        __int64 a4,
        __int64 a5)
{
  char v8; // r13
  RBX::Network::IdSerializer *v9; // r14
  const RBX::CompressedCFrame *v10; // rdx
  __int64 result; // rax
  _BYTE v12[48]; // [rsp+8h] [rbp-68h] BYREF
  RBX::Network::IdSerializer *v13; // [rsp+38h] [rbp-38h]
  RBX::CoordinateFrame *v14; // [rsp+40h] [rbp-30h]

  v14 = a3; /*0x10673672a*/
  v13 = a2; /*0x10673672e*/
  v8 = (*(_QWORD *)a4 != 0) + 2; /*0x106736745*/
  if ( *(_QWORD *)a5 == 0 ) /*0x106736749*/
    v8 = *(_QWORD *)a4 != 0; /*0x106736749*/
  v12[0] = 1; /*0x106736751*/
  RBX::Network::NetworkStream::writeBytes(this: a1, a2: v12, a3: 1u); /*0x10673675d*/
  v12[0] = v8; /*0x106736762*/
  RBX::Network::NetworkStream::writeBytes(this: a1, a2: v12, a3: 1u); /*0x106736771*/
  RBX::CompressedCFrame::fromCFrame(this: (RBX::CompressedCFrame *)v12, a2: v14, a3: 10.0); /*0x106736785*/
  v9 = v13; /*0x106736790*/
  result = RBX::Network::writeCompressedCFrame(this: a1, a2: (RBX::Network::NetworkStream *)v12, a3: v10); /*0x106736794*/
  if ( *(_QWORD *)a4 != 0 ) /*0x1067367a0*/
    result = RBX::Network::IdSerializer::serializeServerCreatedId( /*0x1067367ac*/
               this: v9,
               a2: a1,
               a3: (const RBX::Guid *)(*(_QWORD *)a4 + 48LL));
  if ( *(_QWORD *)a5 != 0 ) /*0x1067367b7*/
    return RBX::Network::IdSerializer::serializeServerCreatedId( /*0x1067367c3*/
             this: v9,
             a2: a1,
             a3: (const RBX::Guid *)(*(_QWORD *)a5 + 48LL));
  return result; /*0x1067367c8*/
}

// Address: 0x106737059 | Name: __ZN3RBX7NetworkL14readInputStateERNS0_13NetworkStreamENS_5Enums15InputActionTypeERNS_10Reflection7VariantE
char __fastcall RBX::Network::readInputState(RBX::Network::NetworkStream *a1, int a2, __int64 a3)
{
  __int64 v3; // rbx
  __int64 v4; // rbp
  __int64 v6; // rdi
  __int64 v7; // rsi
  __int64 v8; // rdi
  __int64 v9; // rsi
  char Bool; // r14
  __int64 v11; // rdi
  __int64 *v12; // r15
  __int64 v13; // rax
  int v14; // xmm0_4
  __int64 v15; // rdi
  __int64 v16; // rsi
  __int64 v17; // r14
  __int64 v18; // rax
  char result; // al
  _BYTE v20[12]; // [rsp-30h] [rbp-30h] BYREF
  int v21; // [rsp-24h] [rbp-24h]
  __int64 v22; // [rsp-20h] [rbp-20h]
  __int64 v23; // [rsp-8h] [rbp-8h]

  v23 = v4; /*0x106737062*/
  v22 = v3; /*0x10673706a*/
  switch ( a2 ) /*0x106737082*/
  {
    case 0: /*0x106737082*/
      Bool = RBX::Network::NetworkStream::readBool(this: a1); /*0x1067370ef*/
      *(_QWORD *)a3 = RBX::Reflection::Type::getSingleton<bool>(a1: v11); /*0x1067370f7*/
      v12 = RBX::Reflection::detail::typed_holder<bool>::singleton(); /*0x1067370ff*/
      v13 = *(_QWORD *)(a3 + 8); /*0x106737102*/
      if ( (__int64 *)v13 == v12 ) /*0x106737109*/
      {
        *(_BYTE *)(a3 + 16) = Bool; /*0x106737163*/
      }
      else
      {
        if ( v13 != 0 ) /*0x10673710e*/
          (*(void (__fastcall **)(__int64))(v13 + 16))(a1: a3 + 16); /*0x106737114*/
        *(_BYTE *)(a3 + 16) = Bool; /*0x106737117*/
        *(_QWORD *)(a3 + 8) = v12; /*0x10673711b*/
      }
      goto LABEL_14; /*0x10673711f*/
    case 1: /*0x106737082*/
      RBX::Network::NetworkStream::readFloat(this: a1); /*0x106737121*/
      v21 = v14; /*0x106737126*/
      *(_QWORD *)a3 = RBX::Reflection::Type::getSingleton<float>(a1: v15, a2: v16); /*0x106737130*/
      v17 = RBX::Reflection::detail::typed_holder<float>::singleton(); /*0x106737138*/
      v18 = *(_QWORD *)(a3 + 8); /*0x10673713b*/
      if ( v18 == v17 ) /*0x106737142*/
      {
        *(_DWORD *)(a3 + 16) = v21; /*0x10673716e*/
      }
      else
      {
        if ( v18 != 0 ) /*0x106737147*/
          (*(void (__fastcall **)(__int64))(v18 + 16))(a1: a3 + 16); /*0x10673714d*/
        *(_DWORD *)(a3 + 16) = v21; /*0x106737155*/
        *(_QWORD *)(a3 + 8) = v17; /*0x10673715a*/
      }
      goto LABEL_14; /*0x10673715e*/
    case 2: /*0x106737082*/
    case 4: /*0x106737082*/
      *(_QWORD *)v20 = 0; /*0x106737088*/
      RBX::Network::Serializer<RBX::Vector2>::deserialize(this: a1); /*0x106737092*/
      *(_QWORD *)a3 = RBX::Reflection::Type::getSingleton<RBX::Vector2>(a1: v6, a2: v7); /*0x10673709c*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<RBX::Vector2>(a1: a3 + 8, a2: v20); /*0x1067370a9*/
      goto LABEL_14; /*0x1067370ae*/
    case 3: /*0x106737082*/
      memset(v20, 0, sizeof(v20)); /*0x1067370b7*/
      RBX::Network::Serializer<RBX::Vector3>::deserialize(this: a1); /*0x1067370c9*/
      *(_QWORD *)a3 = RBX::Reflection::Type::getSingleton<RBX::Vector3>(a1: v8, a2: v9); /*0x1067370d3*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<RBX::Vector3>(a1: a3 + 8, a2: v20); /*0x1067370e0*/
LABEL_14:
      result = 1; /*0x106737173*/
      break; /*0x10673717f*/
    default:
      result = 0; /*0x106737160*/
      break; /*0x106737160*/
  }
  return result; /*0x106737162*/
}

// Address: 0x10674a5a0 | Name: __ZN3RBX7NetworkL30getAttributeWithOffsetWithNameEPKNS_8InstanceERKNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEE
__int64 __fastcall RBX::Network::getAttributeWithOffsetWithName(__int64 a1, RBX::Instance *a2, unsigned __int8 *a3)
{
  __int64 AttributeStorage_NEW; // rax
  unsigned int v6; // ecx
  __int64 v7; // rcx
  unsigned __int8 *v8; // r14
  __int64 AttributeMap_DEPRECATED; // rax
  __int64 v10; // rax
  unsigned int v11; // edx
  __int64 v12; // rdi
  __int64 v13; // rsi
  __int64 v14; // rax
  __int64 v15; // rdx
  void (__fastcall **v16)(__int64, __int64); // rcx
  __int64 v17; // r14
  __int64 v18; // rax
  int v19; // ecx
  bool v20; // r14
  __int64 v21; // r15
  void (__fastcall **v22)(__int64, __int64); // rax
  __int64 v23; // rax
  int *v25; // [rsp+0h] [rbp-60h] BYREF
  int v26; // [rsp+8h] [rbp-58h] BYREF
  _BYTE v27[16]; // [rsp+10h] [rbp-50h] BYREF
  int v28; // [rsp+20h] [rbp-40h] BYREF
  _QWORD v29[2]; // [rsp+28h] [rbp-38h] BYREF

  if ( FFlag::NewAttributeStorage == 1 ) /*0x10674a5cd*/
  {
    AttributeStorage_NEW = RBX::Instance::getAttributeStorage_NEW(this: a2); /*0x10674a5d2*/
    v6 = *a3; /*0x10674a5da*/
    if ( (v6 & 1) != 0 ) /*0x10674a5e1*/
    {
      v7 = *((_QWORD *)a3 + 1); /*0x10674a5e3*/
      v8 = *((unsigned __int8 **)a3 + 2); /*0x10674a5e7*/
    }
    else
    {
      v8 = a3 + 1; /*0x10674a65c*/
      v7 = v6 >> 1; /*0x10674a65f*/
    }
    RBX::AttributeStorage::find(a1: &v28, a2: AttributeStorage_NEW, a3: v8, a4: v7); /*0x10674a66b*/
    RBX::AttributeStorage::end(this: (RBX::AttributeStorage *)&v26); /*0x10674a67a*/
    v19 = v26; /*0x10674a683*/
    v20 = true; /*0x10674a686*/
    if ( v28 == v26 ) /*0x10674a68b*/
    {
      v25 = &v26; /*0x10674a691*/
      v20 = !((bool (__fastcall *)(__int64, _QWORD *))_ZZN3RSL5visitIZNK3RBX6detail29AttributeStorageConstIteratorINS1_11SmallVectorINS1_20AttributeVariantItemELj0EEENS1_22SmallKeyedSplitHashMapINS1_10StringViewES5_Lj0ELNS1_15SplitHashPolicyE10ENS1_4HashIS8_EENSt3__18equal_toIS8_EENS1_29AttributeVariantItemKeyGetterEEEEeqERKSH_EUlRKT_E_JPKS5_NS1_7details22SplitHashTableIteratorIS5_NSQ_14SplitHashTableIS8_S5_LS9_10ELj0ESB_SE_SF_EELb1EEEEEEDcOSK_RKNS_7VariantIJDpT0_EEEE10tableVisit[v28])( /*0x10674a6a5*/
               a1: (__int64)&v25,
               a2: v29);
      v19 = v26; /*0x10674a6a9*/
    }
    ((void (__fastcall *)(_BYTE *))RSL::Variant<RBX::AttributeVariantItem const*,RBX::details::SplitHashTableIterator<RBX::AttributeVariantItem,RBX::details::SplitHashTable<RBX::StringView,RBX::AttributeVariantItem,(RBX::SplitHashPolicy)10,0u,RBX::Hash<RBX::StringView>,std::equal_to<RBX::StringView>,RBX::AttributeVariantItemKeyGetter>,true>>::tableDtor[v19])(a1: v27); /*0x10674a6ba*/
    if ( v20 ) /*0x10674a6c1*/
    {
      v21 = ((__int64 (__fastcall *)(__int64, __int64))_ZZN3RSL5visitIZNK3RBX6detail29AttributeStorageConstIteratorINS1_11SmallVectorINS1_20AttributeVariantItemELj0EEENS1_22SmallKeyedSplitHashMapINS1_10StringViewES5_Lj0ELNS1_15SplitHashPolicyE10ENS1_4HashIS8_EENSt3__18equal_toIS8_EENS1_29AttributeVariantItemKeyGetterEEEEdeEvEUlRKT_E_JPKS5_NS1_7details22SplitHashTableIteratorIS5_NSO_14SplitHashTableIS8_S5_LS9_10ELj0ESB_SE_SF_EELb1EEEEEEDcOSI_RKNS_7VariantIJDpT0_EEEE10tableVisit[v28])( /*0x10674a6d9*/
              a1: (__int64)&v26,
              a2: (__int64)v29);
      *(_QWORD *)a1 = *(_QWORD *)(v21 + 8); /*0x10674a6e0*/
      *(_QWORD *)(a1 + 8) = 0; /*0x10674a6e3*/
      v22 = *(void (__fastcall ***)(__int64, __int64))(v21 + 16); /*0x10674a6eb*/
      if ( v22 != nullptr ) /*0x10674a6f2*/
      {
        (*v22)(a1: v21 + 24, a2: a1 + 16); /*0x10674a6ff*/
        v23 = *(_QWORD *)(v21 + 16); /*0x10674a701*/
      }
      else
      {
        v23 = 0; /*0x10674a70f*/
      }
      *(_QWORD *)(a1 + 8) = v23; /*0x10674a711*/
    }
    ((void (__fastcall *)(_QWORD *))RSL::Variant<RBX::AttributeVariantItem const*,RBX::details::SplitHashTableIterator<RBX::AttributeVariantItem,RBX::details::SplitHashTable<RBX::StringView,RBX::AttributeVariantItem,(RBX::SplitHashPolicy)10,0u,RBX::Hash<RBX::StringView>,std::equal_to<RBX::StringView>,RBX::AttributeVariantItemKeyGetter>,true>>::tableDtor[v28])(a1: v29); /*0x10674a71d*/
    if ( !v20 ) /*0x10674a724*/
      goto LABEL_18; /*0x10674a724*/
  }
  else
  {
    AttributeMap_DEPRECATED = RBX::Instance::getAttributeMap_DEPRECATED(this: a2); /*0x10674a5f0*/
    v10 = RBX::details::SplitHashTable<RBX::StringView,RBX::AttributeVariantItem,(RBX::SplitHashPolicy)10,0u,RBX::Hash<RBX::StringView>,std::equal_to<RBX::StringView>,RBX::AttributeVariantItemKeyGetter>::find_as<std::string>( /*0x10674a5fb*/
            a1: AttributeMap_DEPRECATED,
            a2: a3);
    LOBYTE(v13) = v10 != 0 || v11 != 0; /*0x10674a60c*/
    if ( (_BYTE)v13 != 1 ) /*0x10674a613*/
    {
LABEL_18:
      *(_QWORD *)a1 = RBX::Reflection::Type::getSingleton<void>(a1: v12, a2: v13); /*0x10674a726*/
      *(_OWORD *)(a1 + 8) = 0; /*0x10674a731*/
      *(_OWORD *)(a1 + 24) = 0; /*0x10674a735*/
      *(_OWORD *)(a1 + 40) = 0; /*0x10674a739*/
      *(_OWORD *)(a1 + 56) = 0; /*0x10674a73d*/
      *(_QWORD *)(a1 + 72) = 0; /*0x10674a741*/
      return a1; /*0x10674a741*/
    }
    v14 = *(_QWORD *)(v10 + 16); /*0x10674a619*/
    v15 = 88LL * v11; /*0x10674a61f*/
    *(_QWORD *)a1 = *(_QWORD *)(v14 + v15 + 8); /*0x10674a628*/
    *(_QWORD *)(a1 + 8) = 0; /*0x10674a62b*/
    v16 = *(void (__fastcall ***)(__int64, __int64))(v14 + v15 + 16); /*0x10674a633*/
    if ( v16 != nullptr ) /*0x10674a63b*/
    {
      v17 = v14 + v15 + 8; /*0x10674a645*/
      (*v16)(a1: v14 + v15 + 24, a2: a1 + 16); /*0x10674a651*/
      v18 = *(_QWORD *)(v17 + 8); /*0x10674a653*/
    }
    else
    {
      v18 = 0; /*0x10674a707*/
    }
    *(_QWORD *)(a1 + 8) = v18; /*0x10674a709*/
  }
  return a1; /*0x10674a75c*/
}

// Address: 0x106755a9e | Name: __ZN3RBX7Network40convertExtendedAnalyticsItemTypeToStringENS0_25ExtendedAnalyticsItemTypeE
const char *__fastcall RBX::Network::convertExtendedAnalyticsItemTypeToString(signed int a1)
{
  unsigned int v2; // edi

  if ( a1 <= 42 ) /*0x106755aa5*/
    return RBX::Network::Item::convertItemEnumToString(a1); /*0x106755aa8*/
  v2 = a1 - 43; /*0x106755aad*/
  if ( v2 > 2 ) /*0x106755ab3*/
    return "Unknown"; /*0x106755ac7*/
  else
    return (char *)dword_1099FE51C + dword_1099FE51C[v2]; /*0x106755ac2*/
}

// Address: 0x106758781 | Name: __ZN3RBX7Network20createBridgeListenerERNS0_10ReplicatorE
RBX::Network *__fastcall RBX::Network::createBridgeListener(RBX::Network *this, RBX::Network::Replicator *a2)
{
  _QWORD *v4; // rax

  v4 = (_QWORD *)operator new(a1: (RBX::Memory *)0x10, (unsigned __int64)a2); /*0x106758793*/
  *v4 = off_10CAA9B58; /*0x10675879f*/
  v4[1] = a2; /*0x1067587a2*/
  *(_QWORD *)this = v4; /*0x1067587a6*/
  return this; /*0x1067587ac*/
}

// Address: 0x1067587b1 | Name: __ZN3RBX7Network34registerLargeAssetManagerFactoriesERNS0_24NetAssetManagerFactoriesE
void __fastcall RBX::Network::registerLargeAssetManagerFactories(
        RBX::Network *this,
        RBX::Network::NetAssetManagerFactories *a2)
{
  __int64 v3; // rdx
  __int64 v4; // rsi

  RBX::Network::NetAssetManagerFactories::registerDefaultLoader<RBX::SolidMeshHolder>(a1: (__int64)this, a2: 1, a3: 0); /*0x1067587c1*/
  RBX::Network::NetAssetManagerFactories::registerDefaultLoader<RBX::ConvexDecompHolder>( /*0x1067587d0*/
    a1: (__int64)this,
    a2: 1,
    a3: 0);
  RBX::Network::NetAssetManagerFactories::registerDefaultLoader<RBX::RuntimeContentNetAsset>( /*0x1067587df*/
    a1: (__int64)this,
    a2: 1,
    a3: 0);
  RBX::Network::NetAssetManagerFactories::registerDefaultDeltaLoader<RBX::SolidMeshHolder,RBX::SolidMeshHolderDelta>(a1: (__int64)this); /*0x1067587e7*/
  RBX::Network::NetAssetManagerFactories::registerDefaultDeltaLoader<RBX::ConvexDecompHolder,RBX::DeltaConvexDecompHolder>( /*0x1067587ef*/
    a1: (__int64)this,
    a2: v4,
    a3: v3);
  RBX::Network::NetAssetManagerFactories::setFilter( /*0x1067587fe*/
    this,
    a2: (bool (__fastcall *)(unsigned __int16))RBX::Network::canNetAssetTypeReplicate);
  RBX::Network::NetAssetManagerFactories::setVersionOverride( /*0x106758813*/
    a1: (__int64)this,
    a2: (__int64)RBX::Network::overrideDefaultVersions);
}

// Address: 0x106758bfd | Name: __ZN3RBX7Network24canNetAssetTypeReplicateEt
char __fastcall RBX::Network::canNetAssetTypeReplicate(RBX::Network *this)
{
  return DFFlag::DebugDisableLargeFactoryRegistration ^ 1 | ((unsigned __int16)((_WORD)this - 1) >= 2u); /*0x106758c15*/
}

// Address: 0x106758c17 | Name: __ZN3RBX7Network23overrideDefaultVersionsEv
RBX::Network *__fastcall RBX::Network::overrideDefaultVersions(RBX::Network *this)
{
  __int64 v2; // r12
  const void *v3; // rsi
  size_t v4; // rax
  __int64 v5; // rdx
  unsigned __int64 v6; // r14
  unsigned __int64 v7; // r15
  size_t v8; // r13
  void *v9; // rsi
  RBX::Memory *v10; // rdi
  unsigned __int64 v11; // r14
  const void *v12; // rsi
  signed __int64 v13; // r15
  __int64 v14; // r13
  __int64 v15; // r14
  __int64 v16; // rax
  __int64 v17; // rax
  __int64 v18; // rdx
  __int64 v19; // rcx
  __int64 v20; // r12
  void *v21; // r12
  void *v22; // rsi
  RBX::Memory *v23; // rdi
  unsigned __int64 v24; // rcx
  __int64 v25; // r12
  const void *v26; // rsi
  signed __int64 v27; // r14
  __int64 v28; // r12
  __int64 v29; // rcx
  __int64 v30; // rax
  __int64 v31; // rax
  __int64 v32; // rdx
  __int64 v33; // rcx
  __int64 v34; // r15
  __int64 v35; // r13
  void *v36; // r15
  void *v37; // rsi
  RBX::Memory *v38; // rdi
  unsigned __int64 *v40; // [rsp+0h] [rbp-30h]
  __int64 v41; // [rsp+0h] [rbp-30h]

  *(_OWORD *)this = 0; /*0x106758c2b*/
  *((_QWORD *)this + 2) = 0; /*0x106758c2e*/
  if ( DFFlag::DebugTestVersionOverride == 1 ) /*0x106758c3d*/
  {
    v40 = (unsigned __int64 *)((char *)this + 16); /*0x106758c4c*/
    v2 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<unsigned short,unsigned int>>>( /*0x106758c55*/
           a1: (char *)this + 16,
           a2: 1);
    v3 = *(const void **)this; /*0x106758c58*/
    v4 = *((_QWORD *)this + 1) - *(_QWORD *)this; /*0x106758c5f*/
    v6 = v2 + 8 * v5; /*0x106758c62*/
    *(_WORD *)v2 = 1; /*0x106758c66*/
    *(_DWORD *)(v2 + 4) = 2; /*0x106758c6d*/
    v7 = v2 + 8; /*0x106758c76*/
    v8 = v2 - v4; /*0x106758c7e*/
    memcpy(__dst: (void *)(v2 - v4), __src: v3, __n: v4); /*0x106758c87*/
    v10 = *(RBX::Memory **)this; /*0x106758c8c*/
    *(_QWORD *)this = v8; /*0x106758c8f*/
    *((_QWORD *)this + 1) = v2 + 8; /*0x106758c92*/
    *((_QWORD *)this + 2) = v6; /*0x106758c96*/
    if ( v10 != nullptr ) /*0x106758c9d*/
    {
      operator delete(a1: v10, a2: v9); /*0x106758c9f*/
      v6 = *v40; /*0x106758ca8*/
    }
    *((_QWORD *)this + 1) = v7; /*0x106758cab*/
    if ( v7 >= v6 ) /*0x106758cb2*/
    {
      v12 = *(const void **)this; /*0x106758cd7*/
      v13 = v7 - *(_QWORD *)this; /*0x106758cda*/
      v14 = v13 >> 3; /*0x106758ce0*/
      if ( (unsigned __int64)((v13 >> 3) + 1) >> 61 != 0 ) /*0x106758cef*/
        std::vector<std::pair<unsigned short,unsigned int>>::__throw_length_error[abi:ne200100](); /*0x106758ead*/
      v15 = v6 - (_QWORD)v12; /*0x106758cff*/
      v16 = v15 >> 2; /*0x106758d05*/
      if ( v15 >> 2 <= (unsigned __int64)((v13 >> 3) + 1) ) /*0x106758d0c*/
        v16 = (v13 >> 3) + 1; /*0x106758d0c*/
      if ( (unsigned __int64)v15 >= 0x7FFFFFFFFFFFFFF8LL ) /*0x106758d1d*/
        v16 = 0x1FFFFFFFFFFFFFFFLL; /*0x106758d1d*/
      if ( v16 != 0 ) /*0x106758d24*/
      {
        v17 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<unsigned short,unsigned int>>>( /*0x106758d2d*/
                a1: v40,
                a2: v16);
        v12 = *(const void **)this; /*0x106758d32*/
        v13 = *((_QWORD *)this + 1) - *(_QWORD *)this; /*0x106758d39*/
        v19 = v13 >> 3; /*0x106758d3f*/
      }
      else
      {
        v17 = 0; /*0x106758d45*/
        v19 = v13 >> 3; /*0x106758d47*/
        v18 = 0; /*0x106758d4a*/
      }
      v20 = v17 + 8 * v14; /*0x106758d4c*/
      v41 = v17 + 8 * v18; /*0x106758d54*/
      *(_WORD *)v20 = 2; /*0x106758d58*/
      *(_DWORD *)(v20 + 4) = 3; /*0x106758d5f*/
      v11 = v20 + 8; /*0x106758d6c*/
      v21 = (void *)(v20 - 8 * v19); /*0x106758d74*/
      memcpy(__dst: v21, __src: v12, __n: v13); /*0x106758d7d*/
      v23 = *(RBX::Memory **)this; /*0x106758d82*/
      *(_QWORD *)this = v21; /*0x106758d85*/
      *((_QWORD *)this + 1) = v11; /*0x106758d88*/
      *((_QWORD *)this + 2) = v41; /*0x106758d90*/
      if ( v23 != nullptr ) /*0x106758d97*/
        operator delete(a1: v23, a2: v22); /*0x106758d99*/
    }
    else
    {
      *(_WORD *)(v2 + 8) = 2; /*0x106758cb4*/
      *(_DWORD *)(v2 + 12) = 3; /*0x106758cbc*/
      v11 = v2 + 16; /*0x106758cc5*/
    }
    *((_QWORD *)this + 1) = v11; /*0x106758d9e*/
  }
  else
  {
    v11 = 0; /*0x106758ccf*/
  }
  if ( FFlag::SimRuntimeContentMetadataVersionBump == 1 ) /*0x106758da9*/
  {
    v24 = *((_QWORD *)this + 2); /*0x106758daf*/
    if ( v11 >= v24 ) /*0x106758db6*/
    {
      v26 = *(const void **)this; /*0x106758dd2*/
      v27 = v11 - *(_QWORD *)this; /*0x106758dd5*/
      v28 = v27 >> 3; /*0x106758ddb*/
      if ( (unsigned __int64)((v27 >> 3) + 1) >> 61 != 0 ) /*0x106758deb*/
        std::vector<std::pair<unsigned short,unsigned int>>::__throw_length_error[abi:ne200100](); /*0x106758ea6*/
      v29 = v24 - (_QWORD)v26; /*0x106758dfb*/
      v30 = v29 >> 2; /*0x106758e01*/
      if ( v29 >> 2 <= (unsigned __int64)((v27 >> 3) + 1) ) /*0x106758e08*/
        v30 = (v27 >> 3) + 1; /*0x106758e08*/
      if ( (unsigned __int64)v29 >= 0x7FFFFFFFFFFFFFF8LL ) /*0x106758e19*/
        v30 = 0x1FFFFFFFFFFFFFFFLL; /*0x106758e19*/
      if ( v30 != 0 ) /*0x106758e20*/
      {
        v31 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<unsigned short,unsigned int>>>( /*0x106758e29*/
                a1: (char *)this + 16,
                a2: v30);
        v26 = *(const void **)this; /*0x106758e2e*/
        v27 = *((_QWORD *)this + 1) - *(_QWORD *)this; /*0x106758e35*/
        v33 = v27 >> 3; /*0x106758e3b*/
      }
      else
      {
        v31 = 0; /*0x106758e41*/
        v33 = v27 >> 3; /*0x106758e43*/
        v32 = 0; /*0x106758e46*/
      }
      v34 = v31 + 8 * v28; /*0x106758e48*/
      v35 = v31 + 8 * v32; /*0x106758e4c*/
      *(_WORD *)v34 = 7; /*0x106758e50*/
      *(_DWORD *)(v34 + 4) = 2; /*0x106758e56*/
      v25 = v34 + 8; /*0x106758e62*/
      v36 = (void *)(v34 - 8 * v33); /*0x106758e6a*/
      memcpy(__dst: v36, __src: v26, __n: v27); /*0x106758e73*/
      v38 = *(RBX::Memory **)this; /*0x106758e78*/
      *(_QWORD *)this = v36; /*0x106758e7b*/
      *((_QWORD *)this + 1) = v25; /*0x106758e7e*/
      *((_QWORD *)this + 2) = v35; /*0x106758e82*/
      if ( v38 != nullptr ) /*0x106758e89*/
        operator delete(a1: v38, a2: v37); /*0x106758e8b*/
    }
    else
    {
      *(_WORD *)v11 = 7; /*0x106758db8*/
      *(_DWORD *)(v11 + 4) = 2; /*0x106758dbe*/
      v25 = v11 + 8; /*0x106758dca*/
    }
    *((_QWORD *)this + 1) = v25; /*0x106758e90*/
  }
  return this; /*0x106758e9b*/
}

// Address: 0x106758ed4 | Name: __ZN3RBX7Network28hasLargeReplicatorPropertiesERKNS_6ObjectE
char __fastcall RBX::Network::hasLargeReplicatorProperties(RBX::Network *this, const RBX::Object *a2)
{
  return *(_BYTE *)(*((_QWORD *)this + 3) + 444LL) >> 7; /*0x106758ee5*/
}

// Address: 0x106758ee7 | Name: __ZN3RBX7Network23getTypeForLargePropertyERKNS_10Reflection18PropertyDescriptorE
__int64 __fastcall RBX::Network::getTypeForLargeProperty(
        RBX::Network *this,
        const RBX::Reflection::PropertyDescriptor *a2)
{
  if ( (*((_BYTE *)this + 139) & 0x40) != 0 ) /*0x106758ef2*/
    return (*(__int64 (__fastcall **)(RBX::Network *, const RBX::Reflection::PropertyDescriptor *))(*(_QWORD *)this /*0x106758efc*/
                                                                                                  + 80LL))(
             a1: this,
             a2);
  else
    return 0; /*0x106758ef4*/
}

// Address: 0x106758eff | Name: __ZN3RBX7Network14addObjectPropsERNS0_26LargeReplicatorBridgeStateERNS0_15LargeReplicatorERNS_6ObjectEPKNS0_18NetworkSchemaTypes9ClassInfoE
void __fastcall RBX::Network::addObjectProps(
        RBX::Network::LargeReplicatorBridgeState *this,
        RBX::Network::LargeReplicator *a2,
        RBX::Object *a3,
        __int64 a4)
{
  const RBX::Reflection::PropertyDescriptor **v8; // r13
  const RBX::Reflection::PropertyDescriptor **v9; // r12

  if ( ((unsigned __int8)RBX::Network::LargeReplicator::allowSend(this: a2) ^ 1 | (a4 == 0)) == 0 ) /*0x106758f2b*/
  {
    v8 = *(const RBX::Reflection::PropertyDescriptor ***)(a4 + 160); /*0x106758f2d*/
    v9 = *(const RBX::Reflection::PropertyDescriptor ***)(a4 + 168); /*0x106758f35*/
    while ( v8 != v9 ) /*0x106758f40*/
      RBX::Network::LargeReplicatorBridgeState::update(this, a2, a3, a4: *v8++); /*0x106758f4f*/
  }
}

// Address: 0x106758f69 | Name: __ZN3RBX7Network17removeObjectPropsERNS0_26LargeReplicatorBridgeStateERNS0_15LargeReplicatorERNS_6ObjectEPKNS0_18NetworkSchemaTypes9ClassInfoE
void __fastcall RBX::Network::removeObjectProps(
        __m128i *this,
        RBX::Network::LargeReplicator *a2,
        RBX::Object *a3,
        __int64 a4)
{
  const RBX::Reflection::PropertyDescriptor **v4; // r12
  const RBX::Reflection::PropertyDescriptor **i; // r13

  if ( a4 != 0 ) /*0x106758f6c*/
  {
    v4 = *(const RBX::Reflection::PropertyDescriptor ***)(a4 + 160); /*0x106758f7c*/
    for ( i = *(const RBX::Reflection::PropertyDescriptor ***)(a4 + 168); v4 != i; ++v4 ) /*0x106758f8d*/
      RBX::Network::LargeReplicatorBridgeState::remove(this, a2, a3, a4: *v4); /*0x106758fa5*/
  }
}

// Address: 0x10675a742 | Name: __ZN3RBX7Network24pullHandleStatusToStringENS0_16PullHandleStatusE
char *__fastcall RBX::Network::pullHandleStatusToString(int a1)
{
  return (char *)dword_1099FE8D0 + dword_1099FE8D0[a1]; /*0x10675a757*/
}

// Address: 0x10675a759 | Name: __ZN3RBX7Network10hash_valueERKNS0_15NetAssetGroupIdE
__int64 __fastcall RBX::Network::hash_value(__int64 a1)
{
  return (*(_DWORD *)a1 - 1640531527) /*0x10675a780*/
       ^ (*(unsigned __int16 *)(a1 + 8)
        - 1640531527
        + ((*(_DWORD *)a1 - 1640531527) << 6)
        + (unsigned int)((unsigned __int64)(*(_QWORD *)a1 + 2654435769LL) >> 2));
}

// Address: 0x10675dddc | Name: __ZN3RBX7Network21SlotStoragePersistentINS0_23MrdModeItemizedInstanceELj12EE8addEntryEv
__int64 __fastcall RBX::Network::SlotStoragePersistent<RBX::Network::MrdModeItemizedInstance,12u>::addEntry(
        __int64 *a1,
        unsigned __int64 a2)
{
  __int64 v2; // rax
  __int64 v4; // rbx
  int v5; // eax
  __int64 v6; // r15
  _QWORD *v7; // rax
  __int64 i; // rcx
  __int64 v9; // rsi
  __int64 v10; // rcx
  __int64 v11; // rax
  _QWORD v13[4]; // [rsp+0h] [rbp-20h] BYREF

  v13[0] = v2; /*0x10675dde5*/
  v4 = *((unsigned int *)a1 + 7); /*0x10675dde9*/
  if ( v4 == 0x1FFFFFF ) /*0x10675ddf3*/
  {
    LODWORD(v4) = *((_DWORD *)a1 + 6); /*0x10675ddf9*/
    v5 = v4; /*0x10675de00*/
    v6 = v4 & 0xFFF; /*0x10675de02*/
    if ( (v4 & 0xFFF) == 0 ) /*0x10675de09*/
    {
      v7 = (_QWORD *)operator new[](a1: (RBX::Memory *)0x28008, a2); /*0x10675de10*/
      *v7 = 4096; /*0x10675de15*/
      for ( i = 3; i != 20483; i += 5 ) /*0x10675de1c*/
      {
        v7[i - 1] = 0; /*0x10675de31*/
        v7[i - 2] = &off_10CAAA0C8; /*0x10675de36*/
        *(_OWORD *)&v7[i] = 0; /*0x10675de3b*/
        v7[i + 2] = 0; /*0x10675de3f*/
      }
      v13[0] = v7 + 1; /*0x10675de59*/
      std::vector<std::unique_ptr<RBX::Network::MrdModeItemizedInstance []>>::push_back[abi:ne200100]( /*0x10675de5f*/
        a1,
        a2: v13,
        a3: 0,
        a4: 0.0);
      v9 = v13[0]; /*0x10675de64*/
      v13[0] = 0; /*0x10675de68*/
      if ( v9 != 0 ) /*0x10675de73*/
        std::default_delete<RBX::Network::MrdModeItemizedInstance []>::operator()[abi:ne200100]<RBX::Network::MrdModeItemizedInstance>(a1: v13); /*0x10675de79*/
      v5 = *((_DWORD *)a1 + 6); /*0x10675de7e*/
    }
    *((_DWORD *)a1 + 6) = v5 + 1; /*0x10675de84*/
    v10 = *a1; /*0x10675de88*/
    v11 = (unsigned int)v4 >> 12; /*0x10675de8d*/
  }
  else
  {
    v11 = (unsigned int)v4 >> 12; /*0x10675de94*/
    v10 = *a1; /*0x10675de97*/
    v6 = v4 & 0xFFF; /*0x10675de9d*/
    *((_DWORD *)a1 + 7) = *(_DWORD *)(*(_QWORD *)(*a1 + 8 * v11) + 40 * v6 + 8); /*0x10675deb0*/
  }
  *(_DWORD *)(*(_QWORD *)(v10 + 8 * v11) + 40 * v6 + 8) = 0; /*0x10675debc*/
  return (unsigned int)v4; /*0x10675deca*/
}

// Address: 0x10675e026 | Name: __ZN3RBX7Network21SlotStoragePersistentINS0_21MrdModeItemizedObjectELj12EE8addEntryEv
__int64 __fastcall RBX::Network::SlotStoragePersistent<RBX::Network::MrdModeItemizedObject,12u>::addEntry(
        __int64 *a1,
        unsigned __int64 a2)
{
  __int64 v2; // rax
  __int64 v4; // rbx
  int v5; // eax
  __int64 v6; // r15
  _QWORD *v7; // rax
  __int64 i; // rcx
  __int64 v9; // rsi
  __int64 v10; // rcx
  __int64 v11; // rax
  _QWORD v13[4]; // [rsp+0h] [rbp-20h] BYREF

  v13[0] = v2; /*0x10675e02f*/
  v4 = *((unsigned int *)a1 + 7); /*0x10675e033*/
  if ( v4 == 0x1FFFFFF ) /*0x10675e03d*/
  {
    LODWORD(v4) = *((_DWORD *)a1 + 6); /*0x10675e043*/
    v5 = v4; /*0x10675e04a*/
    v6 = v4 & 0xFFF; /*0x10675e04c*/
    if ( (v4 & 0xFFF) == 0 ) /*0x10675e053*/
    {
      v7 = (_QWORD *)operator new[](a1: (RBX::Memory *)0x28008, a2); /*0x10675e05a*/
      *v7 = 4096; /*0x10675e05f*/
      for ( i = 3; i != 20483; i += 5 ) /*0x10675e066*/
      {
        v7[i - 1] = 0; /*0x10675e07b*/
        v7[i - 2] = &off_10CAAA170; /*0x10675e080*/
        *(_OWORD *)&v7[i] = 0; /*0x10675e085*/
        v7[i + 2] = 0; /*0x10675e089*/
      }
      v13[0] = v7 + 1; /*0x10675e0a3*/
      std::vector<std::unique_ptr<RBX::Network::MrdModeItemizedObject []>>::push_back[abi:ne200100]( /*0x10675e0a9*/
        a1,
        a2: v13,
        a3: 0,
        a4: 0.0);
      v9 = v13[0]; /*0x10675e0ae*/
      v13[0] = 0; /*0x10675e0b2*/
      if ( v9 != 0 ) /*0x10675e0bd*/
        std::default_delete<RBX::Network::MrdModeItemizedObject []>::operator()[abi:ne200100]<RBX::Network::MrdModeItemizedObject>(a1: v13); /*0x10675e0c3*/
      v5 = *((_DWORD *)a1 + 6); /*0x10675e0c8*/
    }
    *((_DWORD *)a1 + 6) = v5 + 1; /*0x10675e0ce*/
    v10 = *a1; /*0x10675e0d2*/
    v11 = (unsigned int)v4 >> 12; /*0x10675e0d7*/
  }
  else
  {
    v11 = (unsigned int)v4 >> 12; /*0x10675e0de*/
    v10 = *a1; /*0x10675e0e1*/
    v6 = v4 & 0xFFF; /*0x10675e0e7*/
    *((_DWORD *)a1 + 7) = *(_DWORD *)(*(_QWORD *)(*a1 + 8 * v11) + 40 * v6 + 8); /*0x10675e0fa*/
  }
  *(_DWORD *)(*(_QWORD *)(v10 + 8 * v11) + 40 * v6 + 8) = 0; /*0x10675e106*/
  return (unsigned int)v4; /*0x10675e114*/
}

// Address: 0x10679c00a | Name: __ZN3RBX7Network14binaryToBitsetERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void **__fastcall RBX::Network::binaryToBitset(void **this, unsigned __int8 *a2)
{
  unsigned int v4; // r15d
  unsigned int v5; // r15d
  unsigned int v6; // edx
  size_t v7; // rdx
  const void *v8; // r14

  v4 = *a2; /*0x10679c01a*/
  if ( (v4 & 1) != 0 ) /*0x10679c022*/
    v5 = *((_DWORD *)a2 + 2); /*0x10679c024*/
  else
    v5 = v4 >> 1; /*0x10679c02a*/
  *this = (void *)RSL::Arena::getDefaultArena((RSL::Arena *)this); /*0x10679c036*/
  *(_OWORD *)(this + 1) = 0; /*0x10679c03c*/
  RBX::dynamic_bitset::resize((RBX::dynamic_bitset *)this, a2: 8 * v5); /*0x10679c046*/
  v6 = *a2; /*0x10679c055*/
  if ( (v6 & 1) != 0 ) /*0x10679c05c*/
  {
    v7 = *((_QWORD *)a2 + 1); /*0x10679c05e*/
    v8 = *((const void **)a2 + 2); /*0x10679c062*/
  }
  else
  {
    v8 = a2 + 1; /*0x10679c068*/
    v7 = v6 >> 1; /*0x10679c06b*/
  }
  memcpy(__dst: *(this + 1), __src: v8, __n: v7); /*0x10679c070*/
  return this; /*0x10679c07c*/
}

// Address: 0x10679efdd | Name: __ZN3RBX7Network43isNetworkValueFormatCompatibleWithLocalTypeERKNS_10Reflection4TypeENS0_18NetworkValueFormatEtRNS_12DenseHashMapIPS3_NS0_18NetworkSchemaTypes4TypeENS_4HashIS7_EENSt3__18equal_toIS7_EEEEPNS8_16LocalConformanceE
char __fastcall RBX::Network::isNetworkValueFormatCompatibleWithLocalType(
        __int64 a1,
        int a2,
        unsigned __int16 a3,
        __int64 a4,
        _DWORD *a5)
{
  __int64 v5; // rax
  __int64 v7; // rdx
  char result; // al
  bool v9; // zf
  bool v10; // cl
  bool v11; // zf
  unsigned __int64 v12; // rcx
  __int64 v13; // rsi
  __int64 v14; // rax
  __int64 v15; // [rsp+0h] [rbp-10h] BYREF

  v15 = v5; /*0x10679efe2*/
  v7 = *(unsigned int *)(a1 + 48); /*0x10679efe5*/
  *a5 = 0; /*0x10679efe8*/
  result = 0; /*0x10679efef*/
  switch ( a2 ) /*0x10679f00b*/
  {
    case 2: /*0x10679f00b*/
    case 49: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 6; /*0x10679f025*/
      goto LABEL_75; /*0x10679f028*/
    case 3: /*0x10679f00b*/
    case 6: /*0x10679f00b*/
    case 47: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 7; /*0x10679f00d*/
      goto LABEL_75; /*0x10679f010*/
    case 7: /*0x10679f00b*/
      v15 = a1; /*0x10679f19b*/
      v14 = RBX::detail::DenseHashTable<RBX::Reflection::Type const*,std::pair<RBX::Reflection::Type const*,RBX::Network::NetworkSchemaTypes::Type>,std::pair<RBX::Reflection::Type const* const,RBX::Network::NetworkSchemaTypes::Type>,RBX::detail::ItemInterfaceMap<RBX::Reflection::Type const*,RBX::Network::NetworkSchemaTypes::Type>,RBX::Hash<RBX::Reflection::Type const*>,std::equal_to<RBX::Reflection::Type const*>>::find( /*0x10679f1a1*/
              a1: a4,
              a2: &v15,
              a3: v7);
      if ( v14 == 0 || *(_BYTE *)(v14 + 9) != 7 ) /*0x10679f1b3*/
        return 0; /*0x10679f1b3*/
      v9 = *(_WORD *)(v14 + 10) == a3; /*0x10679f1b9*/
      goto LABEL_75; /*0x10679f1bd*/
    case 8: /*0x10679f00b*/
      if ( (_DWORD)v7 == 63 ) /*0x10679f123*/
        *a5 = 3; /*0x10679f125*/
      v10 = (_DWORD)v7 == 63; /*0x10679f12f*/
      v11 = (_DWORD)v7 == 30; /*0x10679f132*/
      return v10 || v11; /*0x10679f132*/
    case 9: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 1; /*0x10679f0e3*/
      goto LABEL_75; /*0x10679f0e6*/
    case 10: /*0x10679f00b*/
      if ( (_DWORD)v7 == 3 ) /*0x10679f106*/
        *a5 = 1; /*0x10679f10c*/
      goto LABEL_60; /*0x10679f113*/
    case 11: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 4; /*0x10679f1ce*/
      goto LABEL_75; /*0x10679f1d1*/
    case 12: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 5; /*0x10679f118*/
      goto LABEL_75; /*0x10679f11b*/
    case 13: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 19; /*0x10679f16f*/
      goto LABEL_75; /*0x10679f172*/
    case 14: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 20; /*0x10679f15f*/
      goto LABEL_75; /*0x10679f162*/
    case 15: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 10; /*0x10679f0db*/
      goto LABEL_75; /*0x10679f0de*/
    case 16: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 21; /*0x10679f1bf*/
      goto LABEL_75; /*0x10679f1c2*/
    case 17: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 22; /*0x10679f1c4*/
      goto LABEL_75; /*0x10679f1c7*/
    case 18: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 28; /*0x10679f1f1*/
      goto LABEL_75; /*0x10679f1f4*/
    case 19: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 17; /*0x10679f1d3*/
      goto LABEL_75; /*0x10679f1d6*/
    case 20: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 18; /*0x10679f0cb*/
      goto LABEL_75; /*0x10679f0ce*/
    case 21: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 11; /*0x10679f167*/
      goto LABEL_75; /*0x10679f16a*/
    case 22: /*0x10679f00b*/
    case 23: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 12; /*0x10679f015*/
      goto LABEL_75; /*0x10679f018*/
    case 24: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 13; /*0x10679f14f*/
      goto LABEL_75; /*0x10679f152*/
    case 25: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 14; /*0x10679f0f3*/
      goto LABEL_75; /*0x10679f0f6*/
    case 26: /*0x10679f00b*/
    case 27: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 16; /*0x10679f01d*/
      goto LABEL_75; /*0x10679f020*/
    case 28: /*0x10679f00b*/
      result = 1; /*0x10679f08f*/
      v12 = (unsigned int)(v7 - 50); /*0x10679f091*/
      if ( (unsigned int)v12 > 0x2D || (v13 = 0x200000000003LL, !_bittest64(&v13, v12)) ) /*0x10679f0a7*/
      {
        if ( (_DWORD)v7 != 8 ) /*0x10679f0b0*/
          return 0; /*0x10679f248*/
      }
      return result; /*0x10679f248*/
    case 29: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 35; /*0x10679f218*/
      goto LABEL_75; /*0x10679f21b*/
    case 30: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 36; /*0x10679f0fb*/
      goto LABEL_75; /*0x10679f0fe*/
    case 31: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 37; /*0x10679f13f*/
      goto LABEL_75; /*0x10679f142*/
    case 32: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 38; /*0x10679f18f*/
      goto LABEL_75; /*0x10679f192*/
    case 33: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 49; /*0x10679f147*/
      goto LABEL_75; /*0x10679f14a*/
    case 34: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 29; /*0x10679f06f*/
      goto LABEL_75; /*0x10679f072*/
    case 35: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 45; /*0x10679f0d3*/
      goto LABEL_75; /*0x10679f0d6*/
    case 36: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 46; /*0x10679f1c9*/
      goto LABEL_75; /*0x10679f1cc*/
    case 37: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 44; /*0x10679f222*/
      goto LABEL_75; /*0x10679f225*/
    case 38: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 42; /*0x10679f087*/
      goto LABEL_75; /*0x10679f08a*/
    case 39: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 43; /*0x10679f17f*/
      goto LABEL_75; /*0x10679f182*/
    case 40: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 15; /*0x10679f07f*/
      goto LABEL_75; /*0x10679f082*/
    case 41: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 27; /*0x10679f077*/
      goto LABEL_75; /*0x10679f07a*/
    case 42: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 23; /*0x10679f0eb*/
      goto LABEL_75; /*0x10679f0ee*/
    case 43: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 24; /*0x10679f157*/
      goto LABEL_75; /*0x10679f15a*/
    case 44: /*0x10679f00b*/
      if ( (_DWORD)v7 == 2 ) /*0x10679f1e0*/
        *a5 = 2; /*0x10679f1e2*/
LABEL_60:
      v9 = (v7 & 0xFFFFFFFE) == 2; /*0x10679f1e9*/
      goto LABEL_75; /*0x10679f1ef*/
    case 46: /*0x10679f00b*/
      if ( (_DWORD)v7 == 30 ) /*0x10679f038*/
        *a5 = 4; /*0x10679f03a*/
      v10 = (_DWORD)v7 == 30; /*0x10679f044*/
      v11 = (_DWORD)v7 == 63; /*0x10679f047*/
      return v10 || v11; /*0x10679f13a*/
    case 48: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 64; /*0x10679f0bb*/
      goto LABEL_75; /*0x10679f0be*/
    case 50: /*0x10679f00b*/
    case 51: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 71; /*0x10679f02d*/
      goto LABEL_75; /*0x10679f030*/
    case 52: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 73; /*0x10679f227*/
      goto LABEL_75; /*0x10679f22a*/
    case 53: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 59; /*0x10679f177*/
      goto LABEL_75; /*0x10679f17a*/
    case 54: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 74; /*0x10679f067*/
      goto LABEL_75; /*0x10679f06a*/
    case 55: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 82; /*0x10679f04f*/
      goto LABEL_75; /*0x10679f052*/
    case 56: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 86; /*0x10679f231*/
      goto LABEL_75; /*0x10679f234*/
    case 57: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 89; /*0x10679f21d*/
      goto LABEL_75; /*0x10679f220*/
    case 58: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 90; /*0x10679f05f*/
      goto LABEL_75; /*0x10679f062*/
    case 59: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 93; /*0x10679f187*/
      goto LABEL_75; /*0x10679f18a*/
    case 60: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 94; /*0x10679f1d8*/
      goto LABEL_75; /*0x10679f1db*/
    case 61: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 92; /*0x10679f057*/
      goto LABEL_75; /*0x10679f05a*/
    case 62: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 58; /*0x10679f205*/
      goto LABEL_75; /*0x10679f208*/
    case 63: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 98; /*0x10679f1f6*/
      goto LABEL_75; /*0x10679f1f9*/
    case 64: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 87; /*0x10679f23b*/
      goto LABEL_75; /*0x10679f23b*/
    case 65: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 101; /*0x10679f22c*/
      goto LABEL_75; /*0x10679f22f*/
    case 66: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 102; /*0x10679f236*/
      goto LABEL_75; /*0x10679f239*/
    case 67: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 103; /*0x10679f1fb*/
      goto LABEL_75; /*0x10679f1fe*/
    case 68: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 99; /*0x10679f200*/
      goto LABEL_75; /*0x10679f203*/
    case 69: /*0x10679f00b*/
      v9 = (_DWORD)v7 == 81; /*0x10679f0c3*/
LABEL_75:
      result = v9; /*0x10679f23e*/
      break; /*0x10679f23e*/
    case 70: /*0x10679f00b*/
      result = FFlag::TweenInfoNetworkSchema & ((_DWORD)v7 == 55); /*0x10679f210*/
      break; /*0x10679f216*/
    default:
      return result;
  }
  return result; /*0x10679f245*/
}

// Address: 0x10679f360 | Name: __ZN3RBX7Network24deserializeIsrPropertiesERNS0_13NetworkStreamERNS0_18NetworkSchemaTypes9ClassInfoERNSt3__16vectorINS3_13ClassPropertyENS6_9allocatorIS8_EEEE
__int64 __fastcall RBX::Network::deserializeIsrProperties(RBX::Network::NetworkStream *a1, __int64 a2, _QWORD *a3)
{
  __int64 UInt32; // r15
  __int64 result; // rax
  __int64 v7; // rbx
  int v8; // r13d
  __int64 v9; // rcx
  unsigned __int64 v10; // rsi
  __int64 v11; // r8
  __int64 v12; // r9
  __m128 v13; // xmm0
  __m128 v14; // xmm1
  __m128 v15; // xmm2
  __m128 v16; // xmm3
  __m128 v17; // xmm4
  __m128 v18; // xmm5
  __m128 v19; // xmm6
  __m128 v20; // xmm7
  __int64 v21; // r12
  __int64 v22; // rdx
  __int64 v23; // rdx
  __int64 v25; // [rsp+8h] [rbp-48h]
  __int64 v26; // [rsp+10h] [rbp-40h] BYREF
  __int64 v27; // [rsp+18h] [rbp-38h]
  unsigned int v28; // [rsp+24h] [rbp-2Ch]

  UInt32 = (unsigned int)RBX::Network::NetworkStream::readUInt32(this: a1); /*0x10679f380*/
  v27 = a2; /*0x10679f383*/
  v25 = a2 + 136; /*0x10679f390*/
  result = std::vector<RBX::Network::NetworkSchemaTypes::ClassProperty const*>::reserve(a1: a2 + 136, a2: UInt32); /*0x10679f394*/
  v28 = UInt32; /*0x10679f399*/
  if ( (_DWORD)UInt32 != 0 ) /*0x10679f3a0*/
  {
    v7 = v27 + 112; /*0x10679f3a6*/
    v8 = 0; /*0x10679f3aa*/
    do /*0x10679f404*/
    {
      v10 = (unsigned int)RBX::Network::NetworkStream::readUInt32(this: a1); /*0x10679f3ba*/
      if ( (__int64)(a3[1] - *a3) >> 5 <= v10 ) /*0x10679f3cd*/
      {
        v22 = *(_QWORD *)(*(_QWORD *)(v27 + 8) + 8LL); /*0x10679f41d*/
        if ( (*(_BYTE *)v22 & 1) != 0 ) /*0x10679f424*/
          v23 = *(_QWORD *)(v22 + 16); /*0x10679f42b*/
        else
          v23 = v22 + 1; /*0x10679f426*/
        RBX::throw_runtime_error( /*0x10679f438*/
          this: (RBX *)"ISR property id %u out of range for class %s",
          a2: (const char *)v10,
          a3: v23,
          a4: v9,
          a5: v11,
          a6: v12,
          a7: v13,
          a8: v14,
          a9: v15,
          a10: v16,
          a11: v17,
          a12: v18,
          a13: v19,
          a14: v20,
          a15: (char)a1);
      }
      v26 = 32 * v10 + *a3; /*0x10679f3d6*/
      v21 = v26; /*0x10679f3d3*/
      *(_WORD *)(RBX::DenseMapBase<RBX::DenseMap<RBX::Network::NetworkSchemaTypes::ClassProperty const*,unsigned short,RBX::DenseMapInfo<RBX::Network::NetworkSchemaTypes::ClassProperty const*,void>,RBX::detail::DenseMapPair<RBX::Network::NetworkSchemaTypes::ClassProperty const*,unsigned short>>,RBX::Network::NetworkSchemaTypes::ClassProperty const*,unsigned short,RBX::DenseMapInfo<RBX::Network::NetworkSchemaTypes::ClassProperty const*,void>,RBX::detail::DenseMapPair<RBX::Network::NetworkSchemaTypes::ClassProperty const*,unsigned short>>::FindAndConstruct( /*0x10679f3e5*/
                   a1: v7,
                   a2: &v26)
               + 8) = v8;
      v26 = v21; /*0x10679f3ea*/
      std::vector<RBX::Network::NetworkSchemaTypes::ClassProperty const*>::push_back[abi:ne200100](a1: v25, a2: &v26); /*0x10679f3f5*/
      result = (unsigned __int16)++v8; /*0x10679f3fd*/
    }
    while ( v28 > (unsigned __int16)v8 ); /*0x10679f404*/
  }
  return result; /*0x10679f406*/
}

// Address: 0x1067a7483 | Name: __ZN3RBX7Network33ReportDebugConnectionIssueMetricsERKNS0_27DebugConnectionIssueMetricsE
__int64 __fastcall RBX::Network::ReportDebugConnectionIssueMetrics(unsigned __int8 *a1)
{
  unsigned int v2; // esi
  char *v3; // rdi
  __int64 v4; // rsi
  __int64 v5; // rdx
  __int64 v6; // rcx
  void *v7; // rsi
  _BYTE v9[16]; // [rsp+0h] [rbp-200h] BYREF
  void *v10; // [rsp+10h] [rbp-1F0h]
  void *v11[59]; // [rsp+18h] [rbp-1E8h] BYREF

  v2 = *a1; /*0x1067a74a0*/
  if ( (v2 & 1) != 0 ) /*0x1067a74a7*/
  {
    v4 = *((_QWORD *)a1 + 1); /*0x1067a74ba*/
    if ( v4 == 0 ) /*0x1067a74c1*/
      return __stack_chk_guard; /*0x1067a74c1*/
    v3 = *((char **)a1 + 2); /*0x1067a74c7*/
  }
  else
  {
    if ( *a1 == 0 ) /*0x1067a74ac*/
      return __stack_chk_guard; /*0x1067a74ac*/
    v3 = (char *)(a1 + 1); /*0x1067a74b2*/
    LODWORD(v4) = v2 >> 1; /*0x1067a74b6*/
  }
  if ( (unsigned int)XXH32(a1: v3, a2: v4, a3: 1u) % 0x2710 < DFInt::ReportLuauConnIssuePermyriad ) /*0x1067a74f2*/
  {
    RBX::Analytics::InfluxDb::Points::Points(a1: v11, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1067a7508*/
    RBX::Analytics::InfluxDb::Points::addPoint(a1: v11, a2: "gameid", a3: a1); /*0x1067a751e*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067a7535*/
      this: (RBX::Analytics::InfluxDb::Points *)v11,
      a2: "postEnLength",
      a3: *((_QWORD *)a1 + 4));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067a754b*/
      this: (RBX::Analytics::InfluxDb::Points *)v11,
      a2: "postHash",
      a3: *((_DWORD *)a1 + 11));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067a7562*/
      this: (RBX::Analytics::InfluxDb::Points *)v11,
      a2: "postEnLength",
      a3: *((_QWORD *)a1 + 4));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067a7579*/
      this: (RBX::Analytics::InfluxDb::Points *)v11,
      a2: "preEnLength",
      a3: *((_QWORD *)a1 + 3));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067a758f*/
      this: (RBX::Analytics::InfluxDb::Points *)v11,
      a2: "preHash",
      a3: *((_DWORD *)a1 + 10));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067a75a6*/
      this: (RBX::Analytics::InfluxDb::Points *)v11,
      a2: "cap",
      a3: *((_QWORD *)a1 + 6));
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v11, a2: "verMin", a3: a1[56]); /*0x1067a75bd*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v11, a2: "verMax", a3: a1[57]); /*0x1067a75d4*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067a75eb*/
      this: (RBX::Analytics::InfluxDb::Points *)v11,
      a2: "numSff",
      a3: *((unsigned __int16 *)a1 + 29));
    std::string::basic_string[abi:ne200100]<0>(a1: v9, a2: "debugLuaConnIssue", a3: v5, a4: v6); /*0x1067a75fe*/
    RBX::Analytics::InfluxDb::Points::report(a1: v11, a2: v9, a3: 10000, a4: 0); /*0x1067a7618*/
    if ( (v9[0] & 1) != 0 ) /*0x1067a7624*/
      operator delete(a1: (RBX::Memory *)v10, a2: v7); /*0x1067a762d*/
    RBX::Analytics::InfluxDb::Points::~Points(this: v11); /*0x1067a7639*/
  }
  return __stack_chk_guard; /*0x1067a764e*/
}

// Address: 0x1067db360 | Name: __ZN3RBX7Network20NetworkRegisterImGuiEv
void __fastcall RBX::Network::NetworkRegisterImGui(RBX::Network *this)
{
  ; /*0x1067db360*/
}

// Address: 0x1067db366 | Name: __ZN3RBX7Network19ImGuiRegisterClientEPNS0_6ClientE
void __fastcall RBX::Network::ImGuiRegisterClient(RBX::Network *this, RBX::Network::Client *a2)
{
  ; /*0x1067db366*/
}

// Address: 0x1067db36c | Name: __ZN3RBX7Network19ImGuiRegisterServerEPNS0_6ServerE
void __fastcall RBX::Network::ImGuiRegisterServer(RBX::Network *this, RBX::Network::Server *a2)
{
  ; /*0x1067db36c*/
}

// Address: 0x1067dbb11 | Name: __ZN3RBX7Network45shouldCaptureExpensiveJoinBandwidthUsageStatsEv
__int64 __fastcall RBX::Network::shouldCaptureExpensiveJoinBandwidthUsageStats(RBX::Network *this, int a2)
{
  if ( FFlag::EnableBandwidthSendTrackingForJoinBlob == 1 ) /*0x1067dbb1c*/
    return RBX::Analytics::InfluxDb::canSend( /*0x1067dbb28*/
             this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::JoinBandwidthMetricsThrottlePoints,
             a2);
  else
    return 0; /*0x1067dbb2d*/
}

// Address: 0x1067ddb2f | Name: __ZN3RBX7Network17shuffleNonGuiMRDsERNSt3__16vectorIPNS0_19MegaReplicationDataENS1_9allocatorIS4_EEEENS_16random_generatorE
void __fastcall RBX::Network::shuffleNonGuiMRDs(_QWORD *a1, __int64 a2)
{
  __int64 v3; // rdi
  __int64 v4; // rsi
  _QWORD *v5; // rax
  unsigned __int64 v6; // rcx
  __int64 v7; // rax
  __int64 v8; // r14
  __int64 v9; // rax
  __int64 v10; // r14
  __int64 v11; // rax
  _QWORD *v12; // rsi
  int *v13; // rdi
  unsigned __int64 v14; // rax
  __int64 v15; // [rsp+0h] [rbp-80h] BYREF
  __int64 v16; // [rsp+8h] [rbp-78h] BYREF
  void *v17[2]; // [rsp+10h] [rbp-70h] BYREF
  __int64 v18; // [rsp+20h] [rbp-60h]
  void *v19[4]; // [rsp+30h] [rbp-50h] BYREF
  int v20[11]; // [rsp+54h] [rbp-2Ch] BYREF

  v15 = a2; /*0x1067ddb43*/
  memset(v19, 0, 24); /*0x1067ddb54*/
  v18 = 0; /*0x1067ddb57*/
  *(_OWORD *)v17 = 0; /*0x1067ddb5b*/
  std::vector<int>::reserve(a1: v19, a2: (__int64)(a1[1] - *a1) >> 3); /*0x1067ddb6a*/
  std::vector<RBX::Network::MegaReplicationData *>::reserve(a1: v17, a2: (__int64)(a1[1] - *a1) >> 3); /*0x1067ddb7e*/
  v20[0] = 0; /*0x1067ddb83*/
  v5 = (_QWORD *)*a1; /*0x1067ddb8a*/
  if ( a1[1] != *a1 ) /*0x1067ddb91*/
  {
    v6 = 0; /*0x1067ddb97*/
    do /*0x1067ddc3a*/
    {
      v7 = v5[v6]; /*0x1067ddba5*/
      v16 = v7; /*0x1067ddba9*/
      if ( v7 != 0 ) /*0x1067ddbb0*/
      {
        v8 = *(_QWORD *)(*(_QWORD *)(v7 + 8) + 24LL); /*0x1067ddbb6*/
        v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::GuiBase2d>(a1: v3, a2: v4); /*0x1067ddbba*/
        if ( *(unsigned __int16 *)(v8 + 440) - (unsigned int)*(unsigned __int16 *)(v9 + 440) > *(unsigned __int16 *)(v9 + 442) ) /*0x1067ddbd9*/
        {
          v10 = *(_QWORD *)(*(_QWORD *)(v16 + 8) + 24LL); /*0x1067ddbe3*/
          v11 = RBX::Reflection::Class_getDescriptorPtr<RBX::Folder>(a1: v3); /*0x1067ddbe7*/
          if ( *(unsigned __int16 *)(v10 + 440) - (unsigned int)*(unsigned __int16 *)(v11 + 440) > *(unsigned __int16 *)(v11 + 442) ) /*0x1067ddc06*/
          {
            std::vector<int>::push_back[abi:ne200100](a1: v19, a2: v20); /*0x1067ddc0f*/
            std::vector<RBX::Network::MegaReplicationData *>::push_back[abi:ne200100](a1: v17, a2: &v16); /*0x1067ddc1a*/
          }
        }
      }
      v6 = ++v20[0]; /*0x1067ddc23*/
      v5 = (_QWORD *)*a1; /*0x1067ddc29*/
    }
    while ( (__int64)(a1[1] - *a1) >> 3 > v6 ); /*0x1067ddc3a*/
  }
  std::__shuffle[abi:ne200100]<std::_ClassicAlgPolicy,std::__wrap_iter<int *>,std::__wrap_iter<int *>,RBX::random_generator &>( /*0x1067ddc4c*/
    a1: v19[0],
    a2: v19[1],
    a3: &v15);
  v13 = (int *)v19[0]; /*0x1067ddc51*/
  if ( v19[1] != v19[0] ) /*0x1067ddc59*/
  {
    v14 = 0; /*0x1067ddc5b*/
    do /*0x1067ddc85*/
    {
      v12 = (_QWORD *)*a1; /*0x1067ddc69*/
      *(_QWORD *)(*a1 + 8LL * v13[v14]) = *((_QWORD *)v17[0] + v14); /*0x1067ddc6c*/
      ++v14; /*0x1067ddc70*/
      v13 = (int *)v19[0]; /*0x1067ddc73*/
    }
    while ( ((char *)v19[1] - (char *)v19[0]) >> 2 > v14 ); /*0x1067ddc85*/
  }
  if ( v17[0] != nullptr ) /*0x1067ddc8e*/
  {
    v17[1] = v17[0]; /*0x1067ddc90*/
    operator delete(a1: (RBX::Memory *)v17[0], a2: v12); /*0x1067ddc97*/
    v13 = (int *)v19[0]; /*0x1067ddc9c*/
  }
  if ( v13 != nullptr ) /*0x1067ddca3*/
  {
    v19[1] = v13; /*0x1067ddca5*/
    operator delete(a1: (RBX::Memory *)v13, a2: v12); /*0x1067ddca9*/
  }
}

// Address: 0x1067defd4 | Name: __ZN3RBX7Network16BandwidthMetricsaSEOS1_
_OWORD *__fastcall RBX::Network::BandwidthMetrics::operator=(_OWORD *a1, _OWORD *a2)
{
  __int128 v4; // xmm0

  v4 = *a2; /*0x1067defe1*/
  a1[1] = a2[1]; /*0x1067defe8*/
  *a1 = v4; /*0x1067defec*/
  std::vector<RBX::Network::PerClassDesc>::__move_assign(a1: a1 + 2, a2: a2 + 2); /*0x1067deff7*/
  std::vector<RBX::Network::PerPropertyDesc>::__move_assign(a1: (char *)a1 + 56, a2: (char *)a2 + 56); /*0x1067df004*/
  RBX::details::SplitHashTable<RBX::Guid,std::pair<RBX::Guid,RBX::Network::PerInstanceDetailed>,(RBX::SplitHashPolicy)9,0u,RBX::details::DefaultHash<RBX::Guid>,RBX::details::DefaultEqualTo<RBX::Guid>,RBX::details::GetMapKey<RBX::Guid,RBX::Network::PerInstanceDetailed>>::operator=<9,void>( /*0x1067df011*/
    a1: a1 + 5,
    a2: a2 + 5);
  *(_OWORD *)((char *)a1 + 120) = *(_OWORD *)((char *)a2 + 120); /*0x1067df01a*/
  return a1; /*0x1067df022*/
}

// Address: 0x1067e2b06 | Name: __ZN3RBX7Network30DeserializedChangePropertyItemnwEm
__int64 __fastcall RBX::Network::DeserializedChangePropertyItem::operator new(
        RBX::Network::DeserializedChangePropertyItem *this)
{
  __int64 result; // rax
  unsigned __int64 v3; // rsi

  RBX::Network::propertyChangePool(this); /*0x1067e2b0f*/
  result = RBX::AtomicPoolBase<RBX::AtomicPool<200ul,8ul>,200ul,8ul>::allocate(a1: (__int64)&RBX::Network::propertyChangePool(void)::pool); /*0x1067e2b1b*/
  if ( result == 0 ) /*0x1067e2b23*/
    return operator new(a1: this, a2: v3); /*0x1067e2b35*/
  return result; /*0x1067e2b29*/
}

// Address: 0x1067e2b3a | Name: __ZN3RBX7NetworkL18propertyChangePoolEv
void __fastcall RBX::Network::propertyChangePool(RBX::Network *this)
{
  unsigned __int64 v1; // rdx
  int v2; // ebx

  if ( (_BYTE)`guard variable for'RBX::Network::propertyChangePool(void)::pool == 0 /*0x1067e2b5f*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::propertyChangePool(void)::pool) != 0 )
  {
    v2 = FInt::InlinePropertyChangeItems; /*0x1067e2b61*/
    RBX::Network::propertyChangePool(void)::pool = 0; /*0x1067e2b67*/
    qword_10D47E190 = 0xFFFFFFFFLL; /*0x1067e2b76*/
    qword_10D47E198 = RBX::Memory::allocateAligned( /*0x1067e2b8e*/
                        this: (RBX::Memory *)(200LL * (unsigned int)FInt::InlinePropertyChangeItems),
                        a2: 8u,
                        a3: v1);
    dword_10D47E1A0 = v2; /*0x1067e2b9c*/
    __cxa_atexit( /*0x1067e2bb0*/
      lpfunc: (void (__fastcall *)(void *))RBX::AtomicPool<200ul,8ul>::~AtomicPool,
      obj: &RBX::Network::propertyChangePool(void)::pool,
      lpdso_handle: (void *)&_mh_execute_header);
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::propertyChangePool(void)::pool); /*0x1067e2bc2*/
  }
}

// Address: 0x1067e2c2a | Name: __ZN3RBX7Network30DeserializedChangePropertyItemdlEPv
void __fastcall RBX::Network::DeserializedChangePropertyItem::operator delete(RBX::Network *a1)
{
  RBX::Network *v2; // rdi
  void *v3; // rsi

  RBX::Network::propertyChangePool(this: a1); /*0x1067e2c33*/
  if ( qword_10D47E198 > (unsigned __int64)a1 /*0x1067e2c7a*/
    || (RBX::Network *)((char *)a1 - qword_10D47E198) == (RBX::Network *)0xC7FFFFFF38LL
    || 200 * (unsigned __int64)(unsigned int)dword_10D47E1A0 + qword_10D47E198 <= (unsigned __int64)a1 )
  {
    operator delete(a1, a2: v3); /*0x1067e2c4d*/
  }
  else
  {
    RBX::Network::propertyChangePool(this: v2); /*0x1067e2c7c*/
    RBX::AtomicPoolBase<RBX::AtomicPool<200ul,8ul>,200ul,8ul>::freeListPush( /*0x1067e2c91*/
      a1: (__int64)&RBX::Network::propertyChangePool(void)::pool,
      a2: (__int64 *)a1);
  }
}

// Address: 0x1067e424d | Name: __ZN3RBX7Network14writeWithMasksEPNS_6Voxel24GridERKNS1_6RegionERKNS1_3BoxERKNSt3__16vectorIS4_NSA_9allocatorIS4_EEEEb
__int64 __fastcall RBX::Network::writeWithMasks(
        __int64 a1,
        __int64 a2,
        RBX::Voxel2::Region *a3,
        const RBX::Vector3int32 **a4,
        unsigned __int8 a5)
{
  const RBX::Vector3int32 *v6; // r12
  unsigned int v7; // r14d
  void *v8; // rsi
  _BYTE v10[24]; // [rsp+8h] [rbp-B8h] BYREF
  const RBX::Vector3int32 *v11; // [rsp+20h] [rbp-A0h]
  __int64 v12; // [rsp+28h] [rbp-98h]
  RBX::Voxel2::Region *v13; // [rsp+30h] [rbp-90h]
  _BYTE v14[16]; // [rsp+38h] [rbp-88h] BYREF
  void *v15; // [rsp+48h] [rbp-78h]
  char v16; // [rsp+58h] [rbp-68h] BYREF

  v13 = a3; /*0x1067e4261*/
  v12 = a2; /*0x1067e4268*/
  v6 = *a4; /*0x1067e4280*/
  v11 = a4[1]; /*0x1067e4287*/
  if ( v6 == v11 ) /*0x1067e4291*/
    return (*(__int64 (__fastcall **)(__int64, __int64, RBX::Voxel2::Region *, _QWORD, _QWORD, __int64))(*(_QWORD *)a1 + 136LL))( /*0x1067e4373*/
             a1,
             a2: v12,
             a3: v13,
             a4: 0,
             a5,
             a6: 2);
  v7 = a5; /*0x1067e42a5*/
  do /*0x1067e4307*/
  {
    RBX::Voxel2::Region::offset(this: (RBX::Voxel2::Region *)v10, a2: v6); /*0x1067e42b6*/
    RBX::Voxel2::Box::getSubBox(this: (RBX::Voxel2::Box *)v14, a2: v13); /*0x1067e42c8*/
    (*(void (__fastcall **)(__int64, _BYTE *, _BYTE *, _QWORD, _QWORD, __int64))(*(_QWORD *)a1 + 136LL))( /*0x1067e42e4*/
      a1,
      a2: v10,
      a3: v14,
      a4: 0,
      a5: v7,
      a6: 2);
    if ( v15 != &v16 ) /*0x1067e42f5*/
      operator delete(a1: (RBX::Memory *)v15, a2: v8); /*0x1067e42f7*/
    v6 = (const RBX::Vector3int32 *)((char *)v6 + 24); /*0x1067e42fc*/
  }
  while ( v6 != v11 ); /*0x1067e4307*/
  return __stack_chk_guard; /*0x1067e4319*/
}

// Address: 0x1067e439c | Name: __ZN3RBX7Network10writeChunkERNS0_10ReplicatorERKNS0_23DeserializedClusterItem5ChunkERNS1_22ClusterReplicationDataEPNS_6Voxel24GridEbj
__int64 __fastcall RBX::Network::writeChunk(
        RBX::Network::Replicator *this,
        unsigned __int8 *a2,
        RBX::DataModel *a3,
        RBX::Voxel2::Grid_NEW *a4,
        unsigned __int8 a5,
        int a6)
{
  RBX::Instance *v10; // rsi
  int v11; // ecx
  __int64 v12; // r12
  __int64 v13; // r14
  int v14; // r13d
  int v15; // r15d
  __int64 v16; // rcx
  __int64 v17; // rbx
  int v18; // r15d
  void *v19; // rsi
  unsigned int v20; // edx
  const char *v21; // rsi
  unsigned __int64 v22; // rdx
  int v23; // ecx
  __int64 v24; // rax
  unsigned int v25; // edx
  int v26; // esi
  __int64 v27; // rax
  __int64 v28; // r12
  void *v29; // rsi
  unsigned int v30; // edx
  const char *v31; // rsi
  unsigned __int64 v32; // rdx
  void *v33; // rsi
  __int64 v34; // rcx
  __int64 v36; // rax
  __int64 v37; // rdx
  __int64 v38; // rcx
  const char *v39; // rsi
  __int64 v40; // r8
  __int64 v41; // r9
  __m128 v42; // xmm0
  __m128 v43; // xmm1
  __m128 v44; // xmm2
  __m128 v45; // xmm3
  __m128 v46; // xmm4
  __m128 v47; // xmm5
  __m128 v48; // xmm6
  __m128 v49; // xmm7
  char v50; // cl
  RBX::Instance *v51; // rbx
  char v52; // r14
  __int64 v53; // rcx
  __int64 v54; // rdx
  __int64 v55; // r8
  char CanStreamTerrainLod; // al
  __int64 v57; // rax
  __int64 v58; // r14
  unsigned __int8 *v59; // rax
  __int128 *v60; // r15
  __int128 *v61; // r13
  const RBX::Voxel2::Region *v62; // r12
  RBX::Voxel2::Region *v63; // rbx
  _BOOL4 v64; // [rsp+0h] [rbp-160h]
  int v65; // [rsp+8h] [rbp-158h]
  __int64 v66; // [rsp+20h] [rbp-140h] BYREF
  std::__shared_weak_count *v67; // [rsp+28h] [rbp-138h]
  __int64 v68; // [rsp+30h] [rbp-130h]
  __int64 v69; // [rsp+38h] [rbp-128h] BYREF
  int v70; // [rsp+40h] [rbp-120h]
  unsigned __int64 v71; // [rsp+44h] [rbp-11Ch]
  int v72; // [rsp+4Ch] [rbp-114h]
  RBX::Voxel2::Grid_NEW *v73; // [rsp+50h] [rbp-110h]
  RBX::Instance *v74; // [rsp+58h] [rbp-108h]
  RBX::DataModel *v75; // [rsp+60h] [rbp-100h]
  char v76; // [rsp+6Fh] [rbp-F1h] BYREF
  RBX::Voxel2::Region *v77[2]; // [rsp+70h] [rbp-F0h] BYREF
  RBX::Memory *v78[2]; // [rsp+80h] [rbp-E0h] BYREF
  _BYTE v79[48]; // [rsp+90h] [rbp-D0h] BYREF
  int v80; // [rsp+C0h] [rbp-A0h]
  _BYTE v81[24]; // [rsp+D0h] [rbp-90h] BYREF
  int v82; // [rsp+E8h] [rbp-78h]
  _QWORD v83[6]; // [rsp+F0h] [rbp-70h] BYREF
  int v84; // [rsp+120h] [rbp-40h]

  v73 = a4; /*0x1067e43b6*/
  v75 = a3; /*0x1067e43bd*/
  if ( (unsigned __int8)RBX::Network::Replicator::getIsHLODTerrainGridEnabled(this) == 0 ) /*0x1067e43df*/
  {
    v23 = *(_DWORD *)a2 + a2[1]; /*0x1067e44ef*/
    v24 = (unsigned int)(*((_DWORD *)a2 + 1) << v23); /*0x1067e44fa*/
    v25 = *((_DWORD *)a2 + 2) << v23; /*0x1067e44fc*/
    v26 = *((_DWORD *)a2 + 3) << v23; /*0x1067e4506*/
    v69 = v24 + ((unsigned __int64)v25 << 32); /*0x1067e4519*/
    v70 = v26; /*0x1067e4520*/
    v71 = ((unsigned __int64)((1 << v23) + v25) << 32) | (unsigned int)((1 << v23) + v24); /*0x1067e4533*/
    v72 = v26 + (1 << v23); /*0x1067e453a*/
    v74 = (RBX::Instance *)(a2 + 4); /*0x1067e454a*/
    if ( (unsigned __int8)RBX::Network::Replicator::getCanStreamTerrainLod(this) != 0 ) /*0x1067e4551*/
      v27 = std::__hash_table<std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>,std::__unordered_map_hasher<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>,std::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32>,true>,std::__unordered_map_equal<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>,std::equal_to<RBX::Vector3int32>,std::hash<RBX::Vector3int32>,true>,std::allocator<std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>>>::find<RBX::Vector3int32>( /*0x1067e4561*/
              a1: (char *)v75 + 72,
              a2: a2 + 4);
    else
      v27 = std::__hash_table<std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>,std::__unordered_map_hasher<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>,std::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32>,true>,std::__unordered_map_equal<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>,std::equal_to<RBX::Vector3int32>,std::hash<RBX::Vector3int32>,true>,std::allocator<std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>>>::find<RBX::Vector3int32>( /*0x1067e4576*/
              a1: (char *)v75 + 32,
              a2: a2 + 4);
    v28 = v27; /*0x1067e457b*/
    RBX::Voxel2::Box::Box(this: (RBX::Voxel2::Box *)v81); /*0x1067e4585*/
    RBX::Voxel2::Box::Box(a1: v77, a2: (unsigned int)(1 << *a2), a3: 2); /*0x1067e45a0*/
    *(_OWORD *)v81 = *(_OWORD *)v77; /*0x1067e45b4*/
    RBX::SmallVectorImpl<RBX::Voxel2::Cell>::operator=(a1: (__int64)&v81[16], a2: (__int64)v78); /*0x1067e45b8*/
    v84 = v80; /*0x1067e45c7*/
    if ( (_BYTE *)v78[0] != v79 ) /*0x1067e45d1*/
      operator delete(a1: v78[0], a2: v29); /*0x1067e45d3*/
    v30 = a2[16]; /*0x1067e45d8*/
    if ( (v30 & 1) != 0 ) /*0x1067e45e0*/
    {
      v31 = *((const char **)a2 + 4); /*0x1067e45e2*/
      v32 = *((_QWORD *)a2 + 3); /*0x1067e45e6*/
    }
    else
    {
      v31 = (const char *)(a2 + 17); /*0x1067e45ec*/
      v32 = v30 >> 1; /*0x1067e45f0*/
    }
    RBX::Voxel2::Box::deserialize(this: (RBX::Voxel2::Box *)v81, a2: v31, a3: v32); /*0x1067e45f9*/
    v34 = a2[1]; /*0x1067e45fe*/
    if ( a2[1] != 0 ) /*0x1067e4605*/
    {
      if ( a5 != 0 && v28 != 0 && (_DWORD)v34 + *a2 == a6 ) /*0x1067e461f*/
      {
        LOBYTE(v33) = (unsigned __int8)DFLog::NetworkCluster < 6u; /*0x1067e4639*/
        if ( (unsigned __int8)DFLog::NetworkCluster >= 6u && BYTE1(DFLog::NetworkCluster) >= 3u ) /*0x1067e4640*/
          FLog::FastLogFormatted( /*0x1067e467b*/
            a1: DFLog::NetworkCluster,
            a2: qword_10D80D258,
            a3: (unsigned int)"[DFLog::NetworkCluster] Skipping cluster chunk (%d, %d, %d) debounce=%d size=%d hasOutgoing=%d lod=%d",
            a4: *((_DWORD *)a2 + 1),
            a5: *((_DWORD *)a2 + 2),
            a6: *((_DWORD *)a2 + 3));
      }
      else
      {
        if ( (unsigned __int8)DFLog::NetworkCluster >= 6u && BYTE1(DFLog::NetworkCluster) >= 3u ) /*0x1067e469f*/
        {
          v65 = a2[1]; /*0x1067e46c0*/
          v64 = v82 == 0; /*0x1067e46c4*/
          FLog::FastLogFormatted( /*0x1067e46d2*/
            a1: DFLog::NetworkCluster,
            a2: qword_10D80D258,
            a3: (unsigned int)"[DFLog::NetworkCluster] Applying cluster chunk (%d, %d, %d) isEmpty=%d lod=%d",
            a4: *((_DWORD *)a2 + 1),
            a5: *((_DWORD *)a2 + 2),
            a6: *((_DWORD *)a2 + 3));
          v34 = a2[1]; /*0x1067e46d7*/
        }
        (*(void (__fastcall **)(RBX::Voxel2::Grid_NEW *, __int64 *, _BYTE *, __int64, _QWORD, __int64, _BOOL4, int))(*(_QWORD *)v73 + 136LL))( /*0x1067e4702*/
          a1: v73,
          a2: &v69,
          a3: v81,
          a4: v34,
          a5: *((unsigned __int8 *)this + 15544),
          a6: 2,
          a7: v64,
          a8: v65);
      }
    }
    else
    {
      if ( (unsigned __int8)RBX::Network::Replicator::getCanStreamTerrainLod(this) != 0 ) /*0x1067e47f5*/
      {
        if ( v28 != 0 ) /*0x1067e47fe*/
        {
          v77[0] = v74; /*0x1067e481d*/
          std::__hash_table<std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>,std::__unordered_map_hasher<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>,std::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32>,true>,std::__unordered_map_equal<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>,std::equal_to<RBX::Vector3int32>,std::hash<RBX::Vector3int32>,true>,std::allocator<std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>>>::__emplace_unique_key_args<RBX::Vector3int32,std::piecewise_construct_t const&,std::tuple<RBX::Vector3int32 const&>,std::tuple<>>( /*0x1067e482e*/
            a1: (char *)v75 + 72,
            a2: v74,
            a3: std::piecewise_construct,
            a4: v77,
            a5: &v76);
        }
      }
      else if ( v28 != 0 ) /*0x1067e498d*/
      {
        v77[0] = v74; /*0x1067e49a8*/
        std::__hash_table<std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>,std::__unordered_map_hasher<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>,std::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32>,true>,std::__unordered_map_equal<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>,std::equal_to<RBX::Vector3int32>,std::hash<RBX::Vector3int32>,true>,std::allocator<std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>>>::__emplace_unique_key_args<RBX::Vector3int32,std::piecewise_construct_t const&,std::tuple<RBX::Vector3int32 const&>,std::tuple<>>( /*0x1067e49b9*/
          a1: (char *)v75 + 32,
          a2: v74,
          a3: std::piecewise_construct,
          a4: v77,
          a5: &v76);
      }
      if ( (unsigned __int8)DFLog::NetworkCluster >= 6u && BYTE1(DFLog::NetworkCluster) >= 3u ) /*0x1067e49f6*/
        FLog::FastLogFormatted( /*0x1067e4a55*/
          a1: DFLog::NetworkCluster,
          a2: qword_10D80D258,
          a3: (unsigned int)"[DFLog::NetworkCluster] Applying cluster chunk (%d, %d, %d) applying debounceEnabled=%d hasOutgo"
                        "ing=%d incomingMaskCount=%zd outgoingMaskCount=%zd",
          a4: *((_DWORD *)a2 + 1),
          a5: *((_DWORD *)a2 + 2),
          a6: *((_DWORD *)a2 + 3));
      RBX::Network::writeWithMasks( /*0x1067e4a7b*/
        a1: (__int64)v73,
        a2: (__int64)&v69,
        a3: (RBX::Voxel2::Region *)v81,
        a4: (const RBX::Vector3int32 **)a2 + 5,
        a5: *((_BYTE *)this + 15544));
      if ( ((v28 != 0) & a5) == 1 ) /*0x1067e4a8d*/
      {
        CanStreamTerrainLod = RBX::Network::Replicator::getCanStreamTerrainLod(this); /*0x1067e4a96*/
        v77[0] = v74; /*0x1067e4ab8*/
        if ( CanStreamTerrainLod != 0 ) /*0x1067e4aa4*/
          v57 = std::__hash_table<std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>,std::__unordered_map_hasher<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>,std::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32>,true>,std::__unordered_map_equal<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>,std::equal_to<RBX::Vector3int32>,std::hash<RBX::Vector3int32>,true>,std::allocator<std::__hash_value_type<RBX::Vector3int32,RBX::Network::Replicator::QueuedClusterData>>>::__emplace_unique_key_args<RBX::Vector3int32,std::piecewise_construct_t const&,std::tuple<RBX::Vector3int32 const&>,std::tuple<>>( /*0x1067e4ac9*/
                  a1: (char *)v75 + 72,
                  a2: v74,
                  a3: std::piecewise_construct,
                  a4: v77,
                  a5: &v76);
        else
          v57 = std::__hash_table<std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>,std::__unordered_map_hasher<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>,std::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32>,true>,std::__unordered_map_equal<RBX::Vector3int32,std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>,std::equal_to<RBX::Vector3int32>,std::hash<RBX::Vector3int32>,true>,std::allocator<std::__hash_value_type<RBX::Vector3int32,std::vector<RBX::Voxel2::Region>>>>::__emplace_unique_key_args<RBX::Vector3int32,std::piecewise_construct_t const&,std::tuple<RBX::Vector3int32 const&>,std::tuple<>>( /*0x1067e4af3*/
                  a1: (char *)v75 + 32,
                  a2: v74,
                  a3: std::piecewise_construct,
                  a4: v77,
                  a5: &v76);
        v58 = v57; /*0x1067e4af8*/
        if ( *((_QWORD *)a2 + 5) == *((_QWORD *)a2 + 6) ) /*0x1067e4b03*/
        {
          *(_QWORD *)(v57 + 40) = *(_QWORD *)(v57 + 32); /*0x1067e4bd0*/
        }
        else
        {
          *(_OWORD *)v77 = 0; /*0x1067e4b13*/
          v78[0] = nullptr; /*0x1067e4b16*/
          std::vector<RBX::Voxel2::Region>::__init_with_size[abi:ne200100]<RBX::Voxel2::Region*,RBX::Voxel2::Region*>( /*0x1067e4b3e*/
            a1: v77,
            a2: *(_QWORD *)(v57 + 32),
            a3: *(_QWORD *)(v57 + 40),
            a4: 0xAAAAAAAAAAAAAAABLL * ((__int64)(*(_QWORD *)(v57 + 40) - *(_QWORD *)(v57 + 32)) >> 3));
          v59 = a2; /*0x1067e4b43*/
          v60 = *((__int128 **)a2 + 5); /*0x1067e4b46*/
          v61 = *((__int128 **)v59 + 6); /*0x1067e4b4a*/
          if ( v60 != v61 ) /*0x1067e4b51*/
          {
            v73 = (RBX::Voxel2::Grid_NEW *)(v58 + 32); /*0x1067e4b5a*/
            do /*0x1067e4ba9*/
            {
              if ( *(_QWORD *)(v58 + 32) == *(_QWORD *)(v58 + 40) ) /*0x1067e4b69*/
                break; /*0x1067e4b69*/
              v62 = v77[0]; /*0x1067e4b6b*/
              v63 = v77[1]; /*0x1067e4b72*/
              while ( v62 != v63 ) /*0x1067e4b7c*/
              {
                if ( (unsigned __int8)RBX::Voxel2::Region::intersects(this: (RBX::Voxel2::Region *)v60, a2: v62) != 0 ) /*0x1067e4b8b*/
                {
                  RBX::Network::Replicator::ClusterReplicationData::handleInsertingMask(a1: v73, a2: v60); /*0x1067e4b9d*/
                  break; /*0x1067e4b9d*/
                }
                v62 = (const RBX::Voxel2::Region *)((char *)v62 + 24); /*0x1067e4b8d*/
              }
              v60 = (__int128 *)((char *)v60 + 24); /*0x1067e4ba2*/
            }
            while ( v60 != v61 ); /*0x1067e4ba9*/
          }
          if ( v77[0] != nullptr ) /*0x1067e4bb5*/
          {
            v77[1] = v77[0]; /*0x1067e4bbb*/
            operator delete(a1: v77[0], a2: v33); /*0x1067e4bc2*/
          }
        }
      }
    }
    goto LABEL_28; /*0x1067e4680*/
  }
  v75 = this; /*0x1067e43e5*/
  v11 = *(_DWORD *)a2 + a2[1]; /*0x1067e43f1*/
  v12 = (unsigned int)(*((_DWORD *)a2 + 1) << v11); /*0x1067e43fc*/
  v13 = (unsigned int)(*((_DWORD *)a2 + 2) << v11); /*0x1067e43ff*/
  v74 = (RBX::Instance *)a2; /*0x1067e4402*/
  v14 = *((_DWORD *)a2 + 3) << v11; /*0x1067e440d*/
  v15 = 1 << v11; /*0x1067e4416*/
  v69 = v12 + (v13 << 32); /*0x1067e4423*/
  v70 = v14; /*0x1067e442a*/
  v16 = (unsigned int)(v12 + (1 << v11)); /*0x1067e4431*/
  v17 = (unsigned int)(v13 + v15); /*0x1067e4435*/
  v18 = v14 + v15; /*0x1067e4439*/
  v71 = v16 + (v17 << 32); /*0x1067e4446*/
  v72 = v18; /*0x1067e444d*/
  if ( FFlag::VoxelGridLeanDM != 1 || FFlag::DebugDisableVoxelGridPaletteCompression != 0 ) /*0x1067e446a*/
  {
    RBX::Voxel2::Box::Box(this: (RBX::Voxel2::Box *)v81); /*0x1067e4477*/
    RBX::Voxel2::Box::Box(a1: v77, a2: (unsigned int)(1 << *(_BYTE *)v74), a3: 2); /*0x1067e4498*/
    *(_OWORD *)v81 = *(_OWORD *)v77; /*0x1067e44ac*/
    RBX::SmallVectorImpl<RBX::Voxel2::Cell>::operator=(a1: (__int64)&v81[16], a2: (__int64)v78); /*0x1067e44b0*/
    v84 = v80; /*0x1067e44bf*/
    if ( (_BYTE *)v78[0] != v79 ) /*0x1067e44c9*/
      operator delete(a1: v78[0], a2: v19); /*0x1067e44cb*/
    v20 = *((unsigned __int8 *)v74 + 16); /*0x1067e44d0*/
    if ( (v20 & 1) != 0 ) /*0x1067e44d7*/
    {
      v21 = *((const char **)v74 + 4); /*0x1067e44dd*/
      v22 = *((_QWORD *)v74 + 3); /*0x1067e44e1*/
    }
    else
    {
      v21 = (char *)v74 + 17; /*0x1067e470d*/
      v22 = v20 >> 1; /*0x1067e4711*/
    }
    RBX::Voxel2::Box::deserialize(this: (RBX::Voxel2::Box *)v81, a2: v21, a3: v22); /*0x1067e471a*/
    if ( (unsigned __int8)DFLog::NetworkCluster >= 6u && BYTE1(DFLog::NetworkCluster) >= 3u ) /*0x1067e4738*/
    {
      v65 = *((unsigned __int8 *)v74 + 1); /*0x1067e475b*/
      v64 = v82 == 0; /*0x1067e475f*/
      FLog::FastLogFormatted( /*0x1067e476b*/
        a1: DFLog::NetworkCluster,
        a2: qword_10D80D258,
        a3: (unsigned int)"[DFLog::NetworkCluster] Applying cluster chunk (%d, %d, %d) isEmpty=%d lod=%d",
        a4: *((_DWORD *)v74 + 1),
        a5: *((_DWORD *)v74 + 2),
        a6: *((_DWORD *)v74 + 3));
    }
    (*(void (__fastcall **)(RBX::Voxel2::Grid_NEW *, __int64 *, _BYTE *, _QWORD, _QWORD, _QWORD, _BOOL4, int))(*(_QWORD *)v73 + 136LL))( /*0x1067e47ad*/
      a1: v73,
      a2: &v69,
      a3: v81,
      a4: *((unsigned __int8 *)v74 + 1),
      a5: ((unsigned __int8)FFlag::VoxelGridNewSendAuthoredLODs | *((_BYTE *)v75 + 15544)) & 1,
      a6: 0,
      a7: v64,
      a8: v65);
LABEL_28:
    if ( *(_QWORD **)&v81[16] != v83 ) /*0x1067e47be*/
      operator delete(a1: *(RBX::Memory **)&v81[16], a2: v33); /*0x1067e47c0*/
    return __stack_chk_guard; /*0x1067e47c0*/
  }
  v68 = v16; /*0x1067e4838*/
  v36 = RBX::DataModel::get(this: v75, a2: v10); /*0x1067e4846*/
  if ( v36 == 0 ) /*0x1067e484e*/
    RBX::throw_runtime_error( /*0x1067e4be7*/
      this: (RBX *)"Unable to acquire datamodel when writing terrain chunks",
      a2: v39,
      a3: v37,
      a4: v38,
      a5: v40,
      a6: v41,
      a7: v42,
      a8: v43,
      a9: v44,
      a10: v45,
      a11: v46,
      a12: v47,
      a13: v48,
      a14: v49,
      a15: v64);
  v50 = 0; /*0x1067e4854*/
  if ( FFlag::VoxelGridLeanDM != 0 ) /*0x1067e4860*/
    v50 = FInt::TerrainFinestWriteLevel; /*0x1067e4869*/
  *(_QWORD *)v81 = ((unsigned __int64)(unsigned int)((_DWORD)v13 << v50) << 32) | (unsigned int)((_DWORD)v12 << v50); /*0x1067e4890*/
  *(_DWORD *)&v81[8] = v14 << v50; /*0x1067e4897*/
  *(_QWORD *)&v81[12] = ((unsigned __int64)(unsigned int)((_DWORD)v17 << v50) << 32) /*0x1067e489e*/
                      | (unsigned int)((_DWORD)v68 << v50);
  *(_DWORD *)&v81[20] = v18 << v50; /*0x1067e48a5*/
  v51 = v74; /*0x1067e48a9*/
  v52 = *((_BYTE *)v74 + 1) + v50; /*0x1067e48b3*/
  RBX::weak_from<RBX::DataModel>(a1: &v66, a2: v36); /*0x1067e48c0*/
  RBX::Network::ClusterSerializer::decodePBCChunk( /*0x1067e48ec*/
    a1: (__int64)v75,
    a2: v73,
    a3: (__int64)v81,
    a4: (RBX::ContentId *)(unsigned int)v52,
    a5: (unsigned __int8 *)v51 + 16,
    a6: &v66);
  if ( v67 != nullptr ) /*0x1067e48fb*/
    std::__shared_weak_count::__release_weak(this: v67); /*0x1067e48fd*/
  if ( (unsigned __int8)DFLog::NetworkCluster >= 6u && BYTE1(DFLog::NetworkCluster) >= 5u ) /*0x1067e491b*/
  {
    v53 = *((unsigned int *)v51 + 2); /*0x1067e492d*/
    v54 = *((unsigned int *)v51 + 3); /*0x1067e4930*/
    v55 = *((unsigned __int8 *)v51 + 1); /*0x1067e4933*/
    *(_QWORD *)v81 = *((unsigned int *)v51 + 1); /*0x1067e4938*/
    *(_QWORD *)&v81[16] = v53; /*0x1067e493f*/
    v83[0] = v54; /*0x1067e4943*/
    v83[2] = v55; /*0x1067e4947*/
    v77[0] = (RBX::Voxel2::Region *)8465; /*0x1067e494b*/
    v77[1] = (RBX::Voxel2::Region *)v81; /*0x1067e4956*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x1067e4980*/
      a1: DFLog::NetworkCluster,
      a2: qword_10D80D258,
      a3: 5,
      a4: (unsigned int)"[DFLog::NetworkCluster] Applying cluster chunk ({}, {}, {}) lod={}",
      a5: 66,
      a6: 1,
      8465,
      v81);
  }
  return __stack_chk_guard; /*0x1067e47d9*/
}

// Address: 0x1067f6e6d | Name: __ZN3RBX7NetworkL16getPropertyGroupERKNS0_18NetworkSchemaTypes4TypeE
__int64 __fastcall RBX::Network::getPropertyGroup(__int64 a1)
{
  int v1; // ecx
  __int64 result; // rax
  unsigned __int64 v3; // rdx
  unsigned __int64 v4; // rsi

  v1 = *(unsigned __int8 *)(a1 + 1); /*0x1067f6e71*/
  result = 2; /*0x1067f6e75*/
  v3 = (unsigned int)(v1 - 6); /*0x1067f6e7a*/
  if ( (unsigned int)v3 > 0x3F || (v4 = 0x8000020018400001LL, !_bittest64((const __int64 *)&v4, v3)) ) /*0x1067f6e8c*/
  {
    if ( v1 != 3 ) /*0x1067f6e97*/
      return 1; /*0x1067f6e99*/
  }
  return result; /*0x1067f6e92*/
}

// Address: 0x1067fd0e4 | Name: __ZN3RBX7Network14IncomingPacketixEm
__int64 __fastcall RBX::Network::IncomingPacket::operator[](__int64 a1, __int64 a2)
{
  return *(unsigned __int8 *)(*(_QWORD *)(a1 + 8) + a2); /*0x1067fd0f0*/
}

// Address: 0x1067fd0fc | Name: __ZNK3RBX7Network14IncomingPacketixEm
__int64 __fastcall RBX::Network::IncomingPacket::operator[](__int64 a1, __int64 a2)
{
  return *(_QWORD *)(a1 + 8) + a2; /*0x1067fd107*/
}

// Address: 0x10680f056 | Name: __ZN3RBX7Network27TableAndMapSchemaReadHelperINS0_17ObjectValueSetterENSt3__13mapINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_10Reflection7VariantENS3_4lessISA_EENS8_INS3_4pairIKSA_SC_EEEEEEE4readERNS0_13NetworkStreamEbRS2_mRN5boost9unordered13unordered_mapISA_NS3_6vectorINS0_26DeferredSharedStringSetterENS8_ISS_EEEENSO_4hashISA_EENS3_8equal_toISA_EENS8_INSF_ISG_SU_EEEEEERNS0_36ReplicationVariantSizeLimitsMetaDataERNS0_10ReplicatorE
void __fastcall RBX::Network::TableAndMapSchemaReadHelper<RBX::Network::ObjectValueSetter,std::map<std::string,RBX::Reflection::Variant>>::read(
        unsigned int *a1,
        unsigned __int8 a2,
        RBX::Network::NetworkStream *a3,
        unsigned __int64 a4,
        _QWORD *a5,
        __int32 *a6,
        RBX::Network::IdSerializer *a7)
{
  const char *v9; // rdx
  unsigned __int64 v10; // rsi
  __int64 v11; // rax
  unsigned int v12; // r13d
  int v13; // r12d
  char v14; // al
  int *v15; // rcx
  int *v16; // rdx
  __int64 v17; // rax
  void *v18; // rsi
  volatile signed __int64 *v19; // rbx
  __int64 v20; // rax
  std::__shared_weak_count *v21; // rbx
  __int128 v26; // [rsp+30h] [rbp-80h] BYREF
  void *v27; // [rsp+40h] [rbp-70h]
  __int128 v28; // [rsp+50h] [rbp-60h] BYREF
  std::__shared_weak_count *v29[2]; // [rsp+60h] [rbp-50h] BYREF
  unsigned int v30; // [rsp+7Ch] [rbp-34h] BYREF
  int v31; // [rsp+80h] [rbp-30h]
  _BYTE v32[41]; // [rsp+87h] [rbp-29h] BYREF

  RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v30, a2: a1, a3); /*0x10680f09a*/
  RBX::Network::Replicator::checkVariantContainerCountLimit( /*0x10680f0a9*/
    this: (RBX::Network::Replicator *)v30,
    a2: "ValueMap (read)",
    a3: v9);
  v11 = operator new(a1: (RBX::Memory *)0x18, a2: v10); /*0x10680f0b3*/
  *(_OWORD *)(v11 + 8) = 0; /*0x10680f0bf*/
  *(_QWORD *)v11 = v11 + 8; /*0x10680f0c3*/
  std::shared_ptr<std::map<std::string,RBX::Reflection::Variant>>::shared_ptr[abi:ne200100]<std::map<std::string,RBX::Reflection::Variant>,0>( /*0x10680f0cd*/
    a1: v29,
    a2: v11);
  v26 = 0; /*0x10680f0d5*/
  v27 = nullptr; /*0x10680f0d9*/
  if ( v30 != 0 ) /*0x10680f0e5*/
  {
    v12 = 0; /*0x10680f0eb*/
    v31 = a2; /*0x10680f0f6*/
    do /*0x10680f195*/
    {
      v13 = *((_DWORD *)a7 + 69); /*0x10680f0f9*/
      v14 = (*(__int64 (__fastcall **)(RBX::Network::IdSerializer *))(*(_QWORD *)a7 + 1032LL))(a1: a7); /*0x10680f106*/
      v15 = &DFInt::CliTcMaxPayloadRcv; /*0x10680f110*/
      if ( v13 == 1 ) /*0x10680f117*/
        v15 = &DFInt::RccTcMaxPayloadRcv; /*0x10680f117*/
      v16 = &DFInt::CliMaxPayloadRcv; /*0x10680f11f*/
      if ( v13 == 1 ) /*0x10680f126*/
        v16 = &DFInt::RccMaxPayloadRcv; /*0x10680f126*/
      if ( v14 != 0 ) /*0x10680f130*/
        v16 = v15; /*0x10680f130*/
      RBX::Network::deserializeString( /*0x10680f13c*/
        a1: (__int64)&v26,
        a2: (RBX::Network::NetworkStream *)a1,
        a3: (RBX::Network::NetworkStream *)(unsigned int)*v16);
      *(_QWORD *)&v28 = &v26; /*0x10680f145*/
      v17 = std::__tree<std::__value_type<std::string,RBX::Reflection::Variant>,std::__map_value_compare<std::string,std::__value_type<std::string,RBX::Reflection::Variant>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>( /*0x10680f15b*/
              a1: v29[0],
              a2: &v26,
              a3: std::piecewise_construct,
              a4: &v28,
              a5: v32);
      RBX::Network::Replicator::schemaReadVariant( /*0x10680f189*/
        a1: a7,
        a2: (RBX::Network::NetworkStream *)a1,
        a3: v31,
        a4: v17 + 56,
        a5: a4,
        a6: a5,
        a7: a6);
      ++v12; /*0x10680f18e*/
    }
    while ( v12 < v30 ); /*0x10680f195*/
  }
  (*(void (__fastcall **)(RBX::Network::IdSerializer *, std::__shared_weak_count **))(*(_QWORD *)a7 + 1552LL))( /*0x10680f1a5*/
    a1: a7,
    a2: v29);
  v19 = (volatile signed __int64 *)v29[1]; /*0x10680f1ab*/
  v28 = *(_OWORD *)v29; /*0x10680f1b3*/
  if ( v29[1] != nullptr ) /*0x10680f1c1*/
    _InterlockedIncrement64((volatile signed __int64 *)v29[1] + 1); /*0x10680f1c3*/
  v20 = *((_QWORD *)a3 + 1); /*0x10680f1c8*/
  if ( v20 != 0 ) /*0x10680f1cf*/
  {
    (*(void (__fastcall **)(_QWORD, _QWORD, __int128 *))(**(_QWORD **)(v20 + 144) + 40LL))( /*0x10680f1e2*/
      a1: *(_QWORD *)(v20 + 144),
      a2: *(_QWORD *)a3,
      a3: &v28);
    v19 = *((volatile signed __int64 **)&v28 + 1); /*0x10680f1e5*/
  }
  if ( v19 != nullptr && _InterlockedExchangeAdd64(v19 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680f1fe*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v19 + 16))(a1: v19); /*0x10680f206*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v19); /*0x10680f20c*/
  }
  if ( (v26 & 1) != 0 ) /*0x10680f215*/
    operator delete(a1: (RBX::Memory *)v27, a2: v18); /*0x10680f21b*/
  v21 = v29[1]; /*0x10680f220*/
  if ( v29[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v29[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10680f239*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(a1: v21); /*0x10680f241*/
    std::__shared_weak_count::__release_weak(this: v21); /*0x10680f247*/
  }
}

// Address: 0x106813196 | Name: __ZN3RBX7Network27TableAndMapSchemaReadHelperINS0_18VariantValueSetterENSt3__13mapINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_10Reflection7VariantENS3_4lessISA_EENS8_INS3_4pairIKSA_SC_EEEEEEE4readERNS0_13NetworkStreamEbRS2_mRN5boost9unordered13unordered_mapISA_NS3_6vectorINS0_26DeferredSharedStringSetterENS8_ISS_EEEENSO_4hashISA_EENS3_8equal_toISA_EENS8_INSF_ISG_SU_EEEEEERNS0_36ReplicationVariantSizeLimitsMetaDataERNS0_10ReplicatorE
void __fastcall RBX::Network::TableAndMapSchemaReadHelper<RBX::Network::VariantValueSetter,std::map<std::string,RBX::Reflection::Variant>>::read(
        unsigned int *a1,
        unsigned __int8 a2,
        RBX::Network::NetworkStream *a3,
        unsigned __int64 a4,
        _QWORD *a5,
        __int32 *a6,
        RBX::Network::IdSerializer *a7)
{
  const char *v9; // rdx
  unsigned __int64 v10; // rsi
  __int64 v11; // rax
  unsigned int v12; // r13d
  int v13; // r12d
  char v14; // al
  int *v15; // rcx
  int *v16; // rdx
  __int64 v17; // rax
  _QWORD *v18; // rbx
  void *v19; // rsi
  std::__shared_weak_count *v20; // rbx
  std::__shared_weak_count *v21; // rbx
  __int128 v26; // [rsp+30h] [rbp-80h] BYREF
  void *v27; // [rsp+40h] [rbp-70h]
  std::__shared_weak_count *v28[2]; // [rsp+50h] [rbp-60h] BYREF
  std::__shared_weak_count *v29[2]; // [rsp+60h] [rbp-50h] BYREF
  unsigned int v30; // [rsp+7Ch] [rbp-34h] BYREF
  int v31; // [rsp+80h] [rbp-30h]
  _BYTE v32[41]; // [rsp+87h] [rbp-29h] BYREF

  RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v30, a2: a1, a3); /*0x1068131da*/
  RBX::Network::Replicator::checkVariantContainerCountLimit( /*0x1068131e9*/
    this: (RBX::Network::Replicator *)v30,
    a2: "ValueMap (read)",
    a3: v9);
  v11 = operator new(a1: (RBX::Memory *)0x18, a2: v10); /*0x1068131f3*/
  *(_OWORD *)(v11 + 8) = 0; /*0x1068131ff*/
  *(_QWORD *)v11 = v11 + 8; /*0x106813203*/
  std::shared_ptr<std::map<std::string,RBX::Reflection::Variant>>::shared_ptr[abi:ne200100]<std::map<std::string,RBX::Reflection::Variant>,0>( /*0x10681320d*/
    a1: v29,
    a2: v11);
  v26 = 0; /*0x106813215*/
  v27 = nullptr; /*0x106813219*/
  if ( v30 != 0 ) /*0x106813225*/
  {
    v12 = 0; /*0x10681322b*/
    v31 = a2; /*0x106813236*/
    do /*0x1068132d5*/
    {
      v13 = *((_DWORD *)a7 + 69); /*0x106813239*/
      v14 = (*(__int64 (__fastcall **)(RBX::Network::IdSerializer *))(*(_QWORD *)a7 + 1032LL))(a1: a7); /*0x106813246*/
      v15 = &DFInt::CliTcMaxPayloadRcv; /*0x106813250*/
      if ( v13 == 1 ) /*0x106813257*/
        v15 = &DFInt::RccTcMaxPayloadRcv; /*0x106813257*/
      v16 = &DFInt::CliMaxPayloadRcv; /*0x10681325f*/
      if ( v13 == 1 ) /*0x106813266*/
        v16 = &DFInt::RccMaxPayloadRcv; /*0x106813266*/
      if ( v14 != 0 ) /*0x106813270*/
        v16 = v15; /*0x106813270*/
      RBX::Network::deserializeString( /*0x10681327c*/
        a1: (__int64)&v26,
        a2: (RBX::Network::NetworkStream *)a1,
        a3: (RBX::Network::NetworkStream *)(unsigned int)*v16);
      v28[0] = (std::__shared_weak_count *)&v26; /*0x106813285*/
      v17 = std::__tree<std::__value_type<std::string,RBX::Reflection::Variant>,std::__map_value_compare<std::string,std::__value_type<std::string,RBX::Reflection::Variant>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>( /*0x10681329b*/
              a1: v29[0],
              a2: &v26,
              a3: std::piecewise_construct,
              a4: v28,
              a5: v32);
      RBX::Network::Replicator::schemaReadVariant( /*0x1068132c9*/
        a1: a7,
        a2: (RBX::Network::NetworkStream *)a1,
        a3: v31,
        a4: v17 + 56,
        a5: a4,
        a6: a5,
        a7: a6);
      ++v12; /*0x1068132ce*/
    }
    while ( v12 < v30 ); /*0x1068132d5*/
  }
  (*(void (__fastcall **)(RBX::Network::IdSerializer *, std::__shared_weak_count **))(*(_QWORD *)a7 + 1552LL))( /*0x1068132e5*/
    a1: a7,
    a2: v29);
  *(_OWORD *)v28 = *(_OWORD *)v29; /*0x1068132f3*/
  if ( v29[1] != nullptr ) /*0x1068132fa*/
    _InterlockedIncrement64((volatile signed __int64 *)v29[1] + 1); /*0x1068132fc*/
  v18 = *((_QWORD **)a3 + 1); /*0x106813308*/
  *v18 = RBX::Reflection::Type::getSingleton<std::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>>(); /*0x106813311*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>>( /*0x10681331f*/
    a1: v18 + 1,
    a2: v28);
  v20 = v28[1]; /*0x106813324*/
  if ( v28[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v28[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10681333d*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(a1: v20); /*0x106813345*/
    std::__shared_weak_count::__release_weak(this: v20); /*0x10681334b*/
  }
  if ( (v26 & 1) != 0 ) /*0x106813354*/
    operator delete(a1: (RBX::Memory *)v27, a2: v19); /*0x10681335a*/
  v21 = v29[1]; /*0x10681335f*/
  if ( v29[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v29[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106813378*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(a1: v21); /*0x106813380*/
    std::__shared_weak_count::__release_weak(this: v21); /*0x106813386*/
  }
}

// Address: 0x106819360 | Name: __ZN3RBX7Network20addToReplicatorStateENS0_16ReplicatorStatesES1_
__int64 __fastcall RBX::Network::addToReplicatorState(unsigned int a1, int a2)
{
  return a2 | a1; /*0x106819368*/
}

// Address: 0x10681d58e | Name: __ZN3RBX7Network18ProcessingPacketV2aSEOS1_
__int64 __fastcall RBX::Network::ProcessingPacketV2::operator=(__int64 a1, __int128 *a2)
{
  __int128 v4; // xmm0

  *(_QWORD *)(a1 + 32) = *((_QWORD *)a2 + 4); /*0x10681d59f*/
  v4 = *a2; /*0x10681d5a3*/
  *(_OWORD *)(a1 + 16) = a2[1]; /*0x10681d5aa*/
  *(_OWORD *)a1 = v4; /*0x10681d5ae*/
  std::__optional_storage_base<RBX::RbxTransport::NetStream,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::RbxTransport::NetStream,false>>( /*0x10681d5b9*/
    a1: a1 + 40,
    a2: (char *)a2 + 40);
  *(_QWORD *)(a1 + 144) = *((_QWORD *)a2 + 18); /*0x10681d5c5*/
  RBX::Network::NetworkStream::operator=( /*0x10681d5d8*/
    a1: (RBX::Network::NetworkStream *)(a1 + 152),
    a2: (RBX::Network::NetworkStream *)((char *)a2 + 152));
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::operator=( /*0x10681d5e9*/
    a1: a1 + 216,
    a2: (__int64 *)a2 + 27);
  *(_DWORD *)(a1 + 248) = *((_DWORD *)a2 + 62); /*0x10681d5f5*/
  *(_WORD *)(a1 + 252) = *((_WORD *)a2 + 126); /*0x10681d603*/
  return a1; /*0x10681d60d*/
}

// Address: 0x106820398 | Name: __ZN3RBX7NetworkL26forEachMapsBandwidthReportIjEEvPKcRKNS_12DenseHashMapIPKNS_10Reflection10DescriptorET_NS_4HashIS8_EENSt3__18equal_toIS8_EEEESH_jjRKNS0_25BandwidthInfluxSharedDataE
unsigned __int64 __fastcall RBX::Network::forEachMapsBandwidthReport<unsigned int>(
        char *a1,
        __int64 *a2,
        __int64 *a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  unsigned __int64 v7; // rdx
  __int64 *v8; // r14
  unsigned __int64 v9; // r15
  __int64 v10; // rbx
  __int64 v11; // rcx
  char *v12; // rsi
  __int64 v13; // rsi
  unsigned __int64 v14; // rax
  __int64 *v15; // rdx
  __int64 v16; // rsi
  unsigned __int64 v17; // rdx
  __int64 *v18; // r14
  unsigned __int64 v19; // r15
  unsigned __int64 result; // rax
  __int64 v21; // rbx
  __int64 v22; // rbx
  char *v23; // rsi
  __int64 v24; // rsi
  __int64 *v25; // rdx
  __int64 v26; // rsi
  __int64 v30; // [rsp+30h] [rbp-30h]
  unsigned __int64 v31; // [rsp+30h] [rbp-30h]

  v8 = (__int64 *)RBX::detail::DenseHashTable<RBX::Reflection::Descriptor const*,std::pair<RBX::Reflection::Descriptor const*,unsigned int>,std::pair<RBX::Reflection::Descriptor const* const,unsigned int>,RBX::detail::ItemInterfaceMap<RBX::Reflection::Descriptor const*,unsigned int>,RBX::Hash<RBX::Reflection::Descriptor const*>,std::equal_to<RBX::Reflection::Descriptor const*>>::begin(a1: a2); /*0x1068203c7*/
  v9 = v7; /*0x1068203ca*/
  v30 = (a2[1] - *a2) >> 4; /*0x1068203d9*/
  if ( v8 != a2 || v7 != v30 ) /*0x1068203e6*/
  {
    v10 = *v8; /*0x1068203ec*/
    do /*0x1068204a0*/
    {
      RBX::detail::DenseHashTable<RBX::Reflection::Descriptor const*,std::pair<RBX::Reflection::Descriptor const*,unsigned int>,std::pair<RBX::Reflection::Descriptor const* const,unsigned int>,RBX::detail::ItemInterfaceMap<RBX::Reflection::Descriptor const*,unsigned int>,RBX::Hash<RBX::Reflection::Descriptor const*>,std::equal_to<RBX::Reflection::Descriptor const*>>::find( /*0x1068203fe*/
        a1: a3,
        a2: v10 + 16 * v9);
      v11 = *(_QWORD *)(v10 + 16 * v9); /*0x10682040e*/
      v12 = "Unknown"; /*0x106820412*/
      if ( v11 != 0 ) /*0x10682041c*/
      {
        v13 = *(_QWORD *)(v11 + 8); /*0x10682041e*/
        if ( (*(_BYTE *)v13 & 1) != 0 ) /*0x106820425*/
          v12 = *(char **)(v13 + 16); /*0x10682042c*/
        else
          v12 = (char *)(v13 + 1); /*0x106820427*/
      }
      RBX::Network::sendBandwidthInfluxEntry<unsigned int>(a1, a2: v12, a3: a6); /*0x10682044f*/
      v10 = *v8; /*0x106820454*/
      v14 = (v8[1] - *v8) >> 4; /*0x10682045e*/
      if ( v14 <= v9 + 1 ) /*0x106820469*/
        v14 = v9 + 1; /*0x106820469*/
      v15 = (__int64 *)(v10 + 16 * v9 + 16); /*0x106820475*/
      while ( v14 - 1 != v9 ) /*0x10682047c*/
      {
        ++v9; /*0x10682047e*/
        v16 = *v15; /*0x106820481*/
        v15 += 2; /*0x106820484*/
        if ( v16 != v8[4] ) /*0x10682048c*/
          goto LABEL_15; /*0x10682048c*/
      }
      v9 = v14; /*0x106820490*/
LABEL_15:
      ; /*0x106820493*/
    }
    while ( v8 != a2 || v9 != v30 ); /*0x1068204a0*/
  }
  v18 = (__int64 *)RBX::detail::DenseHashTable<RBX::Reflection::Descriptor const*,std::pair<RBX::Reflection::Descriptor const*,unsigned int>,std::pair<RBX::Reflection::Descriptor const* const,unsigned int>,RBX::detail::ItemInterfaceMap<RBX::Reflection::Descriptor const*,unsigned int>,RBX::Hash<RBX::Reflection::Descriptor const*>,std::equal_to<RBX::Reflection::Descriptor const*>>::begin(a1: a3); /*0x1068204b2*/
  v19 = v17; /*0x1068204b5*/
  result = (a3[1] - *a3) >> 4; /*0x1068204bf*/
  v31 = result; /*0x1068204c3*/
  if ( v18 != a3 || v17 != result ) /*0x1068204d0*/
  {
    v21 = *v18; /*0x1068204d6*/
    do /*0x106820583*/
    {
      v22 = 16 * v19 + v21; /*0x1068204e0*/
      if ( RBX::detail::DenseHashTable<RBX::Reflection::Descriptor const*,std::pair<RBX::Reflection::Descriptor const*,unsigned int>,std::pair<RBX::Reflection::Descriptor const* const,unsigned int>,RBX::detail::ItemInterfaceMap<RBX::Reflection::Descriptor const*,unsigned int>,RBX::Hash<RBX::Reflection::Descriptor const*>,std::equal_to<RBX::Reflection::Descriptor const*>>::find( /*0x1068204f1*/
             a1: a2,
             a2: v22) == 0 )
      {
        v23 = "Unknown"; /*0x1068204f6*/
        if ( *(_QWORD *)v22 != 0 ) /*0x106820500*/
        {
          v24 = *(_QWORD *)(*(_QWORD *)v22 + 8LL); /*0x106820502*/
          if ( (*(_BYTE *)v24 & 1) != 0 ) /*0x106820509*/
            v23 = *(char **)(v24 + 16); /*0x106820510*/
          else
            v23 = (char *)(v24 + 1); /*0x10682050b*/
        }
        RBX::Network::sendBandwidthInfluxEntry<unsigned int>(a1, a2: v23, a3: a6); /*0x106820531*/
      }
      v21 = *v18; /*0x106820536*/
      result = (v18[1] - *v18) >> 4; /*0x106820540*/
      if ( result <= v19 + 1 ) /*0x10682054b*/
        result = v19 + 1; /*0x10682054b*/
      v25 = (__int64 *)(v21 + 16 * v19 + 16); /*0x106820557*/
      while ( result - 1 != v19 ) /*0x10682055e*/
      {
        ++v19; /*0x106820560*/
        v26 = *v25; /*0x106820563*/
        v25 += 2; /*0x106820566*/
        if ( v26 != v18[4] ) /*0x10682056e*/
          goto LABEL_33; /*0x10682056e*/
      }
      v19 = result; /*0x106820572*/
LABEL_33:
      ; /*0x106820575*/
    }
    while ( v18 != a3 || v19 != v31 ); /*0x106820583*/
  }
  return result; /*0x106820589*/
}

// Address: 0x106820598 | Name: __ZN3RBX7NetworkL24sendBandwidthInfluxEntryIjEEvPKcS3_PKT_S6_jjRKNS0_25BandwidthInfluxSharedDataE
__int64 __fastcall RBX::Network::sendBandwidthInfluxEntry<unsigned int>(
        char *a1,
        char *a2,
        int *a3,
        int *a4,
        unsigned int a5,
        unsigned int a6,
        __int64 a7)
{
  int v11; // edx
  int v12; // edx
  __int64 v13; // rdx
  __int64 v14; // rcx
  void *v15; // rsi
  _BYTE v17[16]; // [rsp+8h] [rbp-228h] BYREF
  void *v18; // [rsp+18h] [rbp-218h]
  unsigned int v19; // [rsp+20h] [rbp-210h]
  unsigned int v20; // [rsp+24h] [rbp-20Ch]
  void *v21[59]; // [rsp+28h] [rbp-208h] BYREF

  v20 = a6; /*0x1068205ac*/
  v19 = a5; /*0x1068205b3*/
  RBX::Analytics::InfluxDb::Points::Points(a1: v21, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1068205e4*/
  RBX::Analytics::InfluxDb::Points::addPoint(a1: v21, a2: "Guid", a3: a7); /*0x1068205fe*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v21, a2: "Type", a3: a1); /*0x106820614*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v21, a2: "Subtype", a3: a2); /*0x10682062a*/
  if ( a3 != nullptr ) /*0x106820632*/
    v11 = *a3; /*0x106820634*/
  else
    v11 = 0; /*0x10682063a*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10682064a*/
    this: (RBX::Analytics::InfluxDb::Points *)v21,
    a2: "SubtypeInbound",
    a3: v11);
  if ( a4 != nullptr ) /*0x106820652*/
    v12 = *a4; /*0x106820654*/
  else
    v12 = 0; /*0x10682065a*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10682066a*/
    this: (RBX::Analytics::InfluxDb::Points *)v21,
    a2: "SubtypeOutbound",
    a3: v12);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106820683*/
    this: (RBX::Analytics::InfluxDb::Points *)v21,
    a2: "TypeInboundSubtotal",
    a3: v19);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10682069c*/
    this: (RBX::Analytics::InfluxDb::Points *)v21,
    a2: "TypeOutboundSubtotal",
    a3: v20);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068206b2*/
    this: (RBX::Analytics::InfluxDb::Points *)v21,
    a2: "InboundTotal",
    a3: *(_DWORD *)(a7 + 28));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068206c8*/
    this: (RBX::Analytics::InfluxDb::Points *)v21,
    a2: "OutboundTotal",
    a3: *(_DWORD *)(a7 + 32));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068206e0*/
    this: (RBX::Analytics::InfluxDb::Points *)v21,
    a2: "ElapsedSeconds",
    a3: *(float *)(a7 + 24));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068206f7*/
    this: (RBX::Analytics::InfluxDb::Points *)v21,
    a2: "IncludesJoin",
    a3: *(_BYTE *)(a7 + 36));
  std::string::basic_string[abi:ne200100]<0>(a1: v17, a2: "DetailedBandwidth", a3: v13, a4: v14); /*0x10682070a*/
  RBX::Analytics::InfluxDb::Points::report( /*0x106820725*/
    a1: v21,
    a2: v17,
    a3: (unsigned int)DFInt::DetailedBandwidthStatsInfluxHundrethsPercentage,
    a4: 0);
  if ( (v17[0] & 1) != 0 ) /*0x106820731*/
    operator delete(a1: (RBX::Memory *)v18, a2: v15); /*0x10682073a*/
  RBX::Analytics::InfluxDb::Points::~Points(this: v21); /*0x106820746*/
  return __stack_chk_guard; /*0x10682075b*/
}

// Address: 0x10682643b | Name: __ZN3RBX7Network23resolveTerrainGridIsNewEPKNS_19MegaClusterInstanceE
char __fastcall RBX::Network::resolveTerrainGridIsNew(RBX::Network *this, const RBX::MegaClusterInstance *a2)
{
  if ( DFFlag::ChangeFlagGuardsForNewTerrain == 0 ) /*0x106826449*/
    return FFlag::VoxelGridLeanDM; /*0x106826468*/
  if ( this != nullptr ) /*0x10682644e*/
    return (*(__int64 (__fastcall **)(_QWORD, const RBX::MegaClusterInstance *))(**((_QWORD **)this + 71) + 272LL))( /*0x10682645b*/
             a1: *((_QWORD *)this + 71),
             a2);
  return 0; /*0x10682646e*/
}

// Address: 0x106828a36 | Name: __ZN3RBX7Network12unionRegionsERKNS_6Voxel26RegionES4_
RBX::Network *__fastcall RBX::Network::unionRegions(
        RBX::Network *this,
        const RBX::Voxel2::Region *a2,
        const RBX::Voxel2::Region *a3)
{
  int v3; // r8d
  __int64 v4; // rcx
  __int64 v5; // r9
  int v6; // r8d
  __int64 v7; // rcx
  int v8; // eax
  __int64 v9; // r9
  int v10; // eax
  __int64 v11; // r10
  int v12; // eax
  int v13; // edx

  v3 = *((_DWORD *)a2 + 1); /*0x106828a3c*/
  v4 = *(unsigned int *)a3; /*0x106828a40*/
  v5 = *((unsigned int *)a3 + 1); /*0x106828a42*/
  if ( *(_DWORD *)a2 < (int)v4 ) /*0x106828a48*/
    v4 = *(unsigned int *)a2; /*0x106828a48*/
  if ( v3 < (int)v5 ) /*0x106828a4e*/
    v5 = (unsigned int)v3; /*0x106828a4e*/
  v6 = *((_DWORD *)a3 + 2); /*0x106828a55*/
  if ( *((_DWORD *)a2 + 2) < v6 ) /*0x106828a5c*/
    v6 = *((_DWORD *)a2 + 2); /*0x106828a5c*/
  v7 = (v5 << 32) | v4; /*0x106828a64*/
  v8 = *((_DWORD *)a3 + 3); /*0x106828a67*/
  v9 = *((unsigned int *)a2 + 3); /*0x106828a6a*/
  if ( v8 > (int)v9 ) /*0x106828a71*/
    v9 = (unsigned int)v8; /*0x106828a71*/
  v10 = *((_DWORD *)a3 + 4); /*0x106828a75*/
  v11 = *((unsigned int *)a2 + 4); /*0x106828a78*/
  if ( v10 > (int)v11 ) /*0x106828a7f*/
    v11 = (unsigned int)v10; /*0x106828a7f*/
  v12 = *((_DWORD *)a3 + 5); /*0x106828a83*/
  v13 = *((_DWORD *)a2 + 5); /*0x106828a86*/
  if ( v12 > v13 ) /*0x106828a8b*/
    v13 = v12; /*0x106828a8b*/
  *(_QWORD *)this = v7; /*0x106828a98*/
  *((_DWORD *)this + 2) = v6; /*0x106828a9b*/
  *(_QWORD *)((char *)this + 12) = (v11 << 32) | v9; /*0x106828a9f*/
  *((_DWORD *)this + 5) = v13; /*0x106828aa3*/
  return this; /*0x106828aa6*/
}

// Address: 0x106828aa8 | Name: __ZN3RBX7Network21unionRegionsWithErrorERKNS_6Voxel26RegionES4_Rx
RBX::Network *__fastcall RBX::Network::unionRegionsWithError(
        RBX::Network *this,
        const RBX::Voxel2::Region *a2,
        const RBX::Voxel2::Region *a3,
        __int64 *a4)
{
  __int64 CellCount; // r12
  __int64 v8; // rbx
  __int64 v9; // rax
  _BYTE v11[24]; // [rsp+0h] [rbp-50h] BYREF
  __int64 *v12; // [rsp+18h] [rbp-38h]
  __int64 v13; // [rsp+20h] [rbp-30h]

  v12 = a4; /*0x106828ab9*/
  RBX::Network::unionRegions(this, a2, a3); /*0x106828ac6*/
  CellCount = RBX::Voxel2::Region::getCellCount(this); /*0x106828ad3*/
  v13 = RBX::Voxel2::Region::getCellCount(this: a2); /*0x106828ade*/
  v8 = RBX::Voxel2::Region::getCellCount(this: a3); /*0x106828aea*/
  RBX::Voxel2::Region::intersect(this: (RBX::Voxel2::Region *)v11, a2); /*0x106828af7*/
  v9 = RBX::Voxel2::Region::getCellCount(this: (RBX::Voxel2::Region *)v11); /*0x106828b00*/
  *v12 = v9 + CellCount - (v13 + v8); /*0x106828b13*/
  return this; /*0x106828b19*/
}

// Address: 0x10683855f | Name: __ZN3RBX7NetworkL32analyzeDataPingTraceRbxTransportEPNS0_19NetworkTracerObjectEhRNS_9Telemetry20RobloxTelemetryEventE
__int64 __fastcall RBX::Network::analyzeDataPingTraceRbxTransport(
        RBX::Network *this,
        RBX::Network::NetworkTracerObject *a2,
        __int64 a3,
        RBX::Telemetry::RobloxTelemetryEvent *a4)
{
  _QWORD *v4; // r9
  _QWORD *v5; // r8
  __int64 v6; // rdi
  __int64 v7; // r13
  __int64 v8; // rcx
  __int64 v9; // r12
  __int64 v10; // r14
  __int64 v11; // rdx
  __int64 v12; // rax
  __int64 v13; // r15
  __int64 v14; // r10
  char v15; // r11
  unsigned int v16; // ebx
  __int64 v17; // rbx
  _QWORD *v18; // r11
  __int64 v19; // r12
  __int64 v20; // rbx
  __int64 v21; // r13
  __int64 v22; // rbx
  __int64 v23; // rsi
  __int64 v24; // r13
  __int64 v25; // rdx
  __int64 v26; // rax
  __int64 result; // rax
  __int64 v28; // r13
  __int64 v30; // [rsp+10h] [rbp-70h]
  __int64 v31; // [rsp+18h] [rbp-68h]
  __int64 v32; // [rsp+28h] [rbp-58h]
  __int64 v33; // [rsp+30h] [rbp-50h]
  __int64 v34; // [rsp+38h] [rbp-48h]
  _QWORD v35[2]; // [rsp+40h] [rbp-40h] BYREF
  __int64 v36; // [rsp+50h] [rbp-30h]

  v4 = *((_QWORD **)this + 1); /*0x106838577*/
  if ( *(_QWORD **)this == v4 ) /*0x10683857e*/
  {
    v14 = 0; /*0x106838641*/
    v13 = 0; /*0x106838644*/
    v12 = 0; /*0x106838647*/
    v11 = 0; /*0x106838649*/
    v10 = 0; /*0x10683864b*/
    v7 = 0; /*0x10683864e*/
    v20 = 0; /*0x106838651*/
    v6 = 0; /*0x106838653*/
    v19 = 0; /*0x106838655*/
  }
  else
  {
    v5 = (_QWORD *)(*(_QWORD *)this + 8LL); /*0x106838584*/
    v6 = 0; /*0x106838588*/
    v36 = 0; /*0x10683858a*/
    v7 = 0; /*0x106838592*/
    v8 = 0; /*0x106838595*/
    v9 = 0; /*0x106838597*/
    v10 = 0; /*0x10683859a*/
    v11 = 0; /*0x10683859d*/
    v12 = 0; /*0x10683859f*/
    v13 = 0; /*0x1068385a1*/
    v14 = 0; /*0x1068385a4*/
    do /*0x106838632*/
    {
      v15 = *((_BYTE *)v5 - 8); /*0x1068385a7*/
      v16 = *((unsigned __int8 *)v5 - 7); /*0x1068385ab*/
      if ( v16 <= 4 ) /*0x1068385b3*/
      {
        if ( *((_BYTE *)v5 - 7) != 0 ) /*0x1068385d6*/
        {
          if ( v16 == 2 ) /*0x1068385db*/
          {
            if ( v15 != (_BYTE)a2 ) /*0x1068385e3*/
              v13 = *v5; /*0x1068385e3*/
            v17 = v36; /*0x1068385e7*/
            if ( v15 == (_BYTE)a2 ) /*0x1068385eb*/
              v17 = *v5; /*0x1068385eb*/
            v36 = v17; /*0x1068385ef*/
          }
        }
        else if ( v15 == (_BYTE)a2 ) /*0x10683861b*/
        {
          v6 = *v5; /*0x10683861f*/
        }
        else
        {
          v14 = *v5; /*0x10683861b*/
        }
      }
      else
      {
        switch ( v16 ) /*0x1068385b8*/
        {
          case 5u: /*0x1068385b8*/
            if ( v15 == (_BYTE)a2 ) /*0x1068385fb*/
              v10 = *v5; /*0x1068385fb*/
            else
              v9 = *v5; /*0x1068385ff*/
            break;
          case 0x60u: /*0x1068385b8*/
            if ( v15 == (_BYTE)a2 ) /*0x10683860b*/
              v7 = *v5; /*0x10683860f*/
            else
              v12 = *v5; /*0x10683860b*/
            break;
          case 0x61u: /*0x1068385b8*/
            if ( v15 == (_BYTE)a2 ) /*0x1068385ca*/
              v11 = *v5; /*0x1068385ca*/
            else
              v8 = *v5; /*0x1068385ce*/
            break;
          default:
            break; /*0x1068385b8*/
        }
      }
      v18 = v5 - 1; /*0x106838623*/
      v5 += 2; /*0x106838627*/
    }
    while ( v18 + 2 != v4 ); /*0x106838632*/
    v19 = v9 - v8; /*0x106838638*/
    v20 = v36; /*0x10683863b*/
  }
  v21 = v7 - v20; /*0x10683865e*/
  v22 = v20 - v6; /*0x106838661*/
  v23 = v21; /*0x106838664*/
  v36 = v21; /*0x106838667*/
  v24 = v12 - v13; /*0x10683866e*/
  v34 = v13 - v14; /*0x106838674*/
  v33 = v10 - v11; /*0x10683867b*/
  v25 = -v6 - (v22 + v23 + v19 + v12 - v14 - v11); /*0x106838691*/
  v26 = 0; /*0x106838694*/
  if ( v25 > 0 ) /*0x106838699*/
    v26 = v25; /*0x106838699*/
  v30 = v26; /*0x10683869d*/
  v32 = v10 - v6; /*0x1068386bc*/
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x1068386c6*/
    a1: a3 + 72,
    a2: "DataPingTimeMs",
    a3: 14,
    a4: v10 - v6,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x1068386e4*/
    a1: a3 + 72,
    a2: "PingReplicationQueueTimeMs",
    a3: 26,
    a4: v22,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838703*/
    a1: a3 + 72,
    a2: "PingTransportSendTimeMs",
    a3: 23,
    a4: v36,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838725*/
    a1: a3 + 72,
    a2: "PingReplicationRecvTimeMs",
    a3: 25,
    a4: v19,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838744*/
    a1: a3 + 72,
    a2: "PingBackReplicationQueueTimeMs",
    a3: 30,
    a4: v34,
    a5: 1);
  v31 = v24; /*0x106838759*/
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838766*/
    a1: a3 + 72,
    a2: "PingBackTransportSendTimeMs",
    a3: 27,
    a4: v24,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838785*/
    a1: a3 + 72,
    a2: "PingBackReplicationRecvTimeMs",
    a3: 29,
    a4: v33,
    a5: 1);
  result = (**(__int64 (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x1068387a7*/
             a1: a3 + 72,
             a2: "NetworkTimeMs",
             a3: 13,
             a4: v30,
             a5: 1);
  v28 = v36; /*0x1068387b0*/
  if ( DFFlag::DebugPrintDataPingBreakDown != 0 )
  {
    RBX::CreatorLog::detail::safeFormatPrintInternal( /*0x1068387dd*/
      a1: 1,
      a2: "============= DATA PING TRACE (RbxTransport) ============",
      a3: 57,
      a4: 0,
      a5: v35,
      a6: 4);
    v35[0] = v32; /*0x1068387e6*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(a1: 1, a2: "Ping: {} ms (total)", a3: 19, a4: 3, a5: v35, a6: 4);
    v35[0] = v30; /*0x106838811*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "Ping Network Time: {} ms",
      a3: 24,
      a4: 3,
      a5: v35,
      a6: 4);
    v35[0] = v22; /*0x106838838*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "Ping Replication Queue: {} ms",
      a3: 29,
      a4: 3,
      a5: v35,
      a6: 4);
    v35[0] = v28; /*0x10683885f*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "Ping Transport Send: {} ms",
      a3: 26,
      a4: 3,
      a5: v35,
      a6: 4);
    v35[0] = v19; /*0x10683888a*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "Ping Replication Recv: {} ms",
      a3: 28,
      a4: 3,
      a5: v35,
      a6: 4);
    v35[0] = v34; /*0x1068388b5*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "PingBack Replication Queue: {} ms",
      a3: 33,
      a4: 3,
      a5: v35,
      a6: 4);
    v35[0] = v31; /*0x1068388e0*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "PingBack Transport Send: {} ms",
      a3: 30,
      a4: 3,
      a5: v35,
      a6: 4);
    v35[0] = v33; /*0x10683890b*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "PingBack Replication Recv: {} ms",
      a3: 32,
      a4: 3,
      a5: v35,
      a6: 4);
    return RBX::CreatorLog::detail::safeFormatPrintInternal( /*0x106838950*/
             a1: 1,
             a2: "=========================================================",
             a3: 57,
             a4: 0,
             a5: v35,
             a6: 4);
  }
  return result; /*0x106838955*/
}

// Address: 0x106838964 | Name: __ZN3RBX7NetworkL26analyzeDataPingTraceRakNetEPNS0_19NetworkTracerObjectEhRNS_9Telemetry20RobloxTelemetryEventE
__int64 __fastcall RBX::Network::analyzeDataPingTraceRakNet(
        RBX::Network *this,
        RBX::Network::NetworkTracerObject *a2,
        __int64 a3,
        RBX::Telemetry::RobloxTelemetryEvent *a4)
{
  _QWORD *v4; // rbx
  _QWORD *v5; // r11
  __int64 v6; // r8
  __int64 v7; // rcx
  __int64 v8; // r13
  __int64 v9; // r10
  __int64 v10; // r9
  __int64 v11; // rax
  __int64 v12; // rdx
  __int64 v13; // rdi
  char v14; // r12
  unsigned int v15; // r13d
  bool v16; // zf
  __int64 v17; // r12
  __int64 v18; // r13
  bool v19; // zf
  __int64 v20; // r12
  __int64 v21; // r13
  bool v22; // zf
  __int64 v23; // r12
  __int64 v24; // r13
  __int64 v25; // r13
  __int64 v26; // r13
  bool v27; // zf
  __int64 v28; // r12
  __int64 v29; // r13
  __int64 v30; // r13
  _QWORD *v31; // r12
  __int64 v32; // rsi
  __int64 v33; // rcx
  __int64 v34; // r14
  __int64 v35; // r12
  __int64 v36; // r13
  __int64 v37; // rax
  __int64 v38; // rdx
  __int64 result; // rax
  __int64 v41; // [rsp+10h] [rbp-90h]
  __int64 v42; // [rsp+18h] [rbp-88h]
  __int64 v43; // [rsp+20h] [rbp-80h]
  __int64 v44; // [rsp+28h] [rbp-78h]
  __int64 v45; // [rsp+28h] [rbp-78h]
  __int64 v46; // [rsp+30h] [rbp-70h]
  __int64 v47; // [rsp+38h] [rbp-68h]
  __int64 v48; // [rsp+38h] [rbp-68h]
  _QWORD v49[3]; // [rsp+40h] [rbp-60h] BYREF
  __int64 v50; // [rsp+58h] [rbp-48h]
  __int64 v51; // [rsp+60h] [rbp-40h]
  __int64 v52; // [rsp+68h] [rbp-38h]
  __int64 v53; // [rsp+70h] [rbp-30h]

  v4 = *((_QWORD **)this + 1); /*0x10683897f*/
  if ( *(_QWORD **)this != v4 ) /*0x106838986*/
  {
    v5 = (_QWORD *)(*(_QWORD *)this + 8LL); /*0x10683898c*/
    v6 = 0; /*0x106838990*/
    v46 = 0; /*0x10683899a*/
    v7 = 0; /*0x1068389a2*/
    v8 = 0; /*0x1068389a4*/
    v44 = 0; /*0x1068389a7*/
    v9 = 0; /*0x1068389af*/
    v10 = 0; /*0x1068389b2*/
    v53 = 0; /*0x1068389b5*/
    v51 = 0; /*0x1068389bd*/
    v47 = 0; /*0x1068389c5*/
    v52 = 0; /*0x1068389cd*/
    v50 = 0; /*0x1068389d5*/
    v11 = 0; /*0x1068389dd*/
    v12 = 0; /*0x1068389df*/
    while ( 1 ) /*0x1068389e1*/
    {
      v13 = v8; /*0x1068389e1*/
      v14 = *((_BYTE *)v5 - 8); /*0x1068389e4*/
      v15 = *((unsigned __int8 *)v5 - 7); /*0x1068389e8*/
      if ( v15 <= 0x41 ) /*0x1068389f1*/
      {
        if ( *((_BYTE *)v5 - 7) != 0 ) /*0x106838a29*/
        {
          if ( v15 == 2 ) /*0x106838a2f*/
          {
            v27 = v14 == (char)a2; /*0x106838aae*/
            v28 = *v5; /*0x106838ab1*/
            v29 = v51; /*0x106838ab4*/
            if ( !v27 ) /*0x106838ab8*/
              v29 = *v5; /*0x106838ab8*/
            v51 = v29; /*0x106838abc*/
            v30 = v46; /*0x106838ac0*/
            if ( v27 ) /*0x106838ac4*/
              v30 = v28; /*0x106838ac4*/
            v46 = v30; /*0x106838ac8*/
          }
          else if ( v15 == 5 ) /*0x106838a35*/
          {
            v19 = v14 == (char)a2; /*0x106838a3b*/
            v20 = *v5; /*0x106838a3e*/
            v21 = v52; /*0x106838a41*/
            if ( !v19 ) /*0x106838a45*/
              v21 = *v5; /*0x106838a45*/
            v52 = v21; /*0x106838a49*/
            v8 = v13; /*0x106838a4d*/
            if ( v19 ) /*0x106838a50*/
              v8 = v20; /*0x106838a50*/
            goto LABEL_40; /*0x106838a50*/
          }
        }
        else
        {
          v26 = v47; /*0x106838a9c*/
          if ( v14 != (_BYTE)a2 ) /*0x106838aa0*/
            v26 = *v5; /*0x106838aa0*/
          v47 = v26; /*0x106838aa4*/
          if ( v14 == (_BYTE)a2 ) /*0x106838aa8*/
            v6 = *v5; /*0x106838aa8*/
        }
      }
      else
      {
        switch ( *((_BYTE *)v5 - 7) ) /*0x106838a08*/
        {
          case 'B': /*0x106838a08*/
            v16 = v14 == (char)a2; /*0x106838a0b*/
            v17 = *v5; /*0x106838a0e*/
            v18 = v53; /*0x106838a11*/
            if ( !v16 ) /*0x106838a15*/
              v18 = *v5; /*0x106838a15*/
            v53 = v18; /*0x106838a19*/
            if ( v16 ) /*0x106838a1d*/
              v7 = v17; /*0x106838a1d*/
            break; /*0x106838a1d*/
          case 'C': /*0x106838a08*/
            if ( v14 == (_BYTE)a2 ) /*0x106838a8c*/
              v12 = *v5; /*0x106838a8c*/
            else
              v10 = *v5; /*0x106838a90*/
            break; /*0x106838a90*/
          case 'D': /*0x106838a08*/
            if ( v14 == (_BYTE)a2 ) /*0x106838a5c*/
              v9 = *v5; /*0x106838a60*/
            else
              v11 = *v5; /*0x106838a5c*/
            break; /*0x106838a60*/
          case 'H': /*0x106838a08*/
            v22 = v14 == (char)a2; /*0x106838a66*/
            v23 = *v5; /*0x106838a69*/
            v24 = v50; /*0x106838a6c*/
            if ( !v22 ) /*0x106838a70*/
              v24 = *v5; /*0x106838a70*/
            v50 = v24; /*0x106838a74*/
            v25 = v44; /*0x106838a78*/
            if ( v22 ) /*0x106838a7c*/
              v25 = v23; /*0x106838a7c*/
            v44 = v25; /*0x106838a80*/
            break; /*0x106838a84*/
          default:
            break;
        }
      }
      v8 = v13; /*0x106838acc*/
LABEL_40:
      v31 = v5 - 1; /*0x106838acf*/
      v5 += 2; /*0x106838ad3*/
      if ( v31 + 2 == v4 ) /*0x106838ade*/
        goto LABEL_43; /*0x106838ade*/
    }
  }
  v12 = 0; /*0x106838ae6*/
  v11 = 0; /*0x106838ae8*/
  v50 = 0; /*0x106838aea*/
  v52 = 0; /*0x106838af2*/
  v47 = 0; /*0x106838afa*/
  v51 = 0; /*0x106838b02*/
  v53 = 0; /*0x106838b0a*/
  v10 = 0; /*0x106838b12*/
  v9 = 0; /*0x106838b15*/
  v44 = 0; /*0x106838b18*/
  v8 = 0; /*0x106838b20*/
  v7 = 0; /*0x106838b23*/
  v46 = 0; /*0x106838b25*/
  v6 = 0; /*0x106838b2d*/
LABEL_43:
  v32 = v7; /*0x106838b30*/
  v33 = v8 - v6; /*0x106838b36*/
  v34 = v12 - v32; /*0x106838b3c*/
  v53 = v10 - v53; /*0x106838b46*/
  v43 = v12 - v46; /*0x106838b54*/
  v35 = v46 - v6; /*0x106838b58*/
  v42 = v10 - v51; /*0x106838b65*/
  v51 -= v47; /*0x106838b70*/
  v52 -= v50; /*0x106838b7f*/
  v50 -= v11; /*0x106838b86*/
  v36 = v8 - v44; /*0x106838b8e*/
  v45 = v44 - v9; /*0x106838b94*/
  v37 = v9 + v11 - (v10 + v12); /*0x106838b9b*/
  v38 = 0; /*0x106838b9e*/
  if ( v37 > 0 ) /*0x106838ba3*/
    v38 = v37; /*0x106838ba3*/
  v48 = v38; /*0x106838ba7*/
  v41 = v33; /*0x106838bc9*/
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838bd6*/
    a1: a3 + 72,
    a2: "DataPingTimeMs",
    a3: 14,
    a4: v33,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838bfb*/
    a1: a3 + 72,
    a2: "PingResendTimeMs",
    a3: 16,
    a4: v34,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838c1d*/
    a1: a3 + 72,
    a2: "PingReplicationSendTimeMs",
    a3: 25,
    a4: v35,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838c3c*/
    a1: a3 + 72,
    a2: "PingRakNetSendTimeMs",
    a3: 20,
    a4: v43,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838c5b*/
    a1: a3 + 72,
    a2: "PingReplicationRecvTimeMs",
    a3: 25,
    a4: v52,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838c7a*/
    a1: a3 + 72,
    a2: "PingRakNetRecvTimeMs",
    a3: 20,
    a4: v50,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838c9d*/
    a1: a3 + 72,
    a2: "PingBackResendMs",
    a3: 16,
    a4: v53,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838cbc*/
    a1: a3 + 72,
    a2: "PingBackReplicationSentTimeMs",
    a3: 29,
    a4: v51,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838cde*/
    a1: a3 + 72,
    a2: "PingBackRakNetSendTimeMs",
    a3: 24,
    a4: v42,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838cfc*/
    a1: a3 + 72,
    a2: "PingBackReplicationRecvTimeMs",
    a3: 29,
    a4: v36,
    a5: 1);
  (**(void (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838d1d*/
    a1: a3 + 72,
    a2: "PingBackRakNetTimeMs",
    a3: 20,
    a4: v45,
    a5: 1);
  result = (**(__int64 (__fastcall ***)(__int64, const char *, __int64, __int64, __int64))(a3 + 72))( /*0x106838d3f*/
             a1: a3 + 72,
             a2: "NetworkTimeMs",
             a3: 13,
             a4: v48,
             a5: 1);
  if ( DFFlag::DebugPrintDataPingBreakDown != 0 )
  {
    RBX::CreatorLog::detail::safeFormatPrintInternal( /*0x106838d6e*/
      a1: 1,
      a2: "============= DATA PING TRACE (RakNet) ============",
      a3: 51,
      a4: 0,
      a5: v49,
      a6: 4);
    v49[0] = v41; /*0x106838d7a*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(a1: 1, a2: "Ping: {} ms", a3: 11, a4: 3, a5: v49, a6: 4);
    v49[0] = v48; /*0x106838da1*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "Ping Network Time: {} ms",
      a3: 24,
      a4: 3,
      a5: v49,
      a6: 4);
    v49[0] = v35; /*0x106838dcc*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "Ping Send Replication: {} ms",
      a3: 28,
      a4: 3,
      a5: v49,
      a6: 4);
    v49[0] = v43; /*0x106838dfb*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "Ping Send RakNet: {} ms",
      a3: 23,
      a4: 3,
      a5: v49,
      a6: 4);
    v49[0] = v34; /*0x106838e29*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(a1: 1, a2: "Ping Resend: {} ms", a3: 18, a4: 3, a5: v49, a6: 4);
    v49[0] = v50; /*0x106838e54*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "Ping Receive RakNet: {} ms",
      a3: 26,
      a4: 3,
      a5: v49,
      a6: 4);
    v49[0] = v52; /*0x106838e7f*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "Ping Receive Replication: {} ms",
      a3: 31,
      a4: 3,
      a5: v49,
      a6: 4);
    v49[0] = v51; /*0x106838eaa*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "PingBack Send Replication: {} ms",
      a3: 32,
      a4: 3,
      a5: v49,
      a6: 4);
    v49[0] = v42; /*0x106838ed8*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "PingBack Send RakNet: {} ms",
      a3: 27,
      a4: 3,
      a5: v49,
      a6: 4);
    v49[0] = v53; /*0x106838f03*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(a1: 1, a2: "PingBack Resend: {} ms", a3: 22, a4: 3, a5: v49, a6: 4);
    v49[0] = v45; /*0x106838f2a*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "PingBack Receive RakNet: {} ms",
      a3: 30,
      a4: 3,
      a5: v49,
      a6: 4);
    v49[0] = v36; /*0x106838f51*/
    RBX::CreatorLog::detail::safeFormatPrintInternal(
      a1: 1,
      a2: "PingBack Receive Replication: {} ms",
      a3: 35,
      a4: 3,
      a5: v49,
      a6: 4);
    return RBX::CreatorLog::detail::safeFormatPrintInternal( /*0x106838f96*/
             a1: 1,
             a2: "=====================================================",
             a3: 53,
             a4: 0,
             a5: v49,
             a6: 4);
  }
  return result; /*0x106838f9b*/
}

// Address: 0x10684ba43 | Name: __ZN3RBX7NetworkL19addKllSketchToEventERNS_9Telemetry20RobloxTelemetryEventERKNS_9KllSketchE
__int64 __fastcall RBX::Network::addKllSketchToEvent(
        RBX::Network *this,
        RBX::Telemetry::RobloxTelemetryEvent *a2,
        const RBX::KllSketch *a3)
{
  __int64 result; // rax
  char *v6; // rdi
  __int64 v7; // rsi
  __int64 v8; // r15
  float v9; // xmm0_4
  float v10; // xmm0_4
  __int64 v11; // rax
  char *v12; // rbx
  unsigned __int16 v13; // ax
  char *v14; // rcx
  __int64 v15; // r8
  void *v16; // rsi
  __m512 v17; // [rsp+0h] [rbp-1C0h] BYREF
  __int64 v18; // [rsp+40h] [rbp-180h]
  __int64 (__fastcall **v19)(); // [rsp+50h] [rbp-170h] BYREF
  __int64 (__fastcall **v20)(); // [rsp+58h] [rbp-168h] BYREF
  _BYTE v21[72]; // [rsp+60h] [rbp-160h] BYREF
  void *v22; // [rsp+A8h] [rbp-118h]
  __int64 (__fastcall **v23)(); // [rsp+C0h] [rbp-100h] BYREF
  unsigned __int8 v24; // [rsp+158h] [rbp-68h] BYREF
  char v25; // [rsp+159h] [rbp-67h] BYREF
  __int64 v26; // [rsp+160h] [rbp-60h]
  void *v27; // [rsp+168h] [rbp-58h]
  __int128 v28; // [rsp+170h] [rbp-50h] BYREF
  void *v29; // [rsp+180h] [rbp-40h]
  float v30; // [rsp+188h] [rbp-38h]
  float v31; // [rsp+18Ch] [rbp-34h]
  void *v32[6]; // [rsp+190h] [rbp-30h] BYREF

  result = RBX::KllSketch::isEmpty(this: a2); /*0x10684ba5c*/
  if ( (_BYTE)result == 0 ) /*0x10684ba63*/
  {
    std::ostringstream::basic_ostringstream[abi:ne200100](a1: &v19); /*0x10684ba73*/
    RBX::KllSketch::serialize(a1: a2, a2: &v19); /*0x10684ba7e*/
    std::stringbuf::str(a1: &v24, a2: &v20); /*0x10684ba8e*/
    v28 = 0; /*0x10684ba96*/
    v29 = nullptr; /*0x10684ba9a*/
    if ( (v24 & 1) != 0 ) /*0x10684baaa*/
    {
      v6 = (char *)v27; /*0x10684baac*/
      v7 = v26; /*0x10684bab0*/
    }
    else
    {
      v7 = v24 >> 1; /*0x10684bab6*/
      v6 = &v25; /*0x10684bab8*/
    }
    base64<char,std::char_traits<char>>::encode<base64<char,std::char_traits<char>>::noline>( /*0x10684bac0*/
      a1: (__int64)v6,
      a2: v7,
      a3: (__int64)&v28);
    v8 = RBX::KllSketch::getN(this: a2); /*0x10684bacd*/
    v17 = zmmword_109A02688; /*0x10684bade*/
    v18 = 0x3FEFAE147AE147AELL; /*0x10684bb0c*/
    RBX::KllSketch::getQuantiles(a1: v32, a2, a3: &v17, a4: 9, a5: 1); /*0x10684bb22*/
    RBX::KllSketch::getMinItem(this: a2); /*0x10684bb2a*/
    v30 = v9; /*0x10684bb2f*/
    RBX::KllSketch::getMaxItem(this: a2); /*0x10684bb37*/
    v31 = v10; /*0x10684bb3c*/
    v11 = *((_QWORD *)this + 9); /*0x10684bb41*/
    v12 = (char *)this + 72; /*0x10684bb45*/
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, __int64))(v11 + 8))( /*0x10684bb61*/
      a1: v12,
      a2: "samples",
      a3: 7,
      a4: v8,
      a5: 1);
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*(_QWORD *)v12 + 16LL))( /*0x10684bb83*/
      a1: v12,
      a2: "min",
      a3: 3,
      a4: 1,
      a5: v30);
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*(_QWORD *)v12 + 16LL))( /*0x10684bba8*/
      a1: v12,
      a2: "p01",
      a3: 3,
      a4: 1,
      a5: *(float *)v32[0]);
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*(_QWORD *)v12 + 16LL))( /*0x10684bbce*/
      a1: v12,
      a2: "p05",
      a3: 3,
      a4: 1,
      a5: *((float *)v32[0] + 1));
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*(_QWORD *)v12 + 16LL))( /*0x10684bbf4*/
      a1: v12,
      a2: "p10",
      a3: 3,
      a4: 1,
      a5: *((float *)v32[0] + 2));
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*(_QWORD *)v12 + 16LL))( /*0x10684bc1a*/
      a1: v12,
      a2: "p25",
      a3: 3,
      a4: 1,
      a5: *((float *)v32[0] + 3));
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*(_QWORD *)v12 + 16LL))( /*0x10684bc40*/
      a1: v12,
      a2: "p50",
      a3: 3,
      a4: 1,
      a5: *((float *)v32[0] + 4));
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*(_QWORD *)v12 + 16LL))( /*0x10684bc66*/
      a1: v12,
      a2: "p75",
      a3: 3,
      a4: 1,
      a5: *((float *)v32[0] + 5));
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*(_QWORD *)v12 + 16LL))( /*0x10684bc8c*/
      a1: v12,
      a2: "p90",
      a3: 3,
      a4: 1,
      a5: *((float *)v32[0] + 6));
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*(_QWORD *)v12 + 16LL))( /*0x10684bcb2*/
      a1: v12,
      a2: "p95",
      a3: 3,
      a4: 1,
      a5: *((float *)v32[0] + 7));
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*(_QWORD *)v12 + 16LL))( /*0x10684bcd8*/
      a1: v12,
      a2: "p99",
      a3: 3,
      a4: 1,
      a5: *((float *)v32[0] + 8));
    (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*(_QWORD *)v12 + 16LL))( /*0x10684bcfa*/
      a1: v12,
      a2: "max",
      a3: 3,
      a4: 1,
      a5: v31);
    v13 = RBX::KllSketch::getK(this: a2); /*0x10684bd00*/
    (*(void (__fastcall **)(char *, const char *, __int64, _QWORD, __int64))(*(_QWORD *)v12 + 8LL))( /*0x10684bd20*/
      a1: v12,
      a2: "k",
      a3: 1,
      a4: v13,
      a5: 1);
    if ( (v28 & 1) != 0 ) /*0x10684bd2c*/
    {
      v14 = (char *)v29; /*0x10684bd2e*/
      v15 = *((_QWORD *)&v28 + 1); /*0x10684bd32*/
    }
    else
    {
      v15 = (unsigned __int8)v28 >> 1; /*0x10684bd38*/
      v14 = (char *)&v28 + 1; /*0x10684bd3b*/
    }
    (*(void (__fastcall **)(char *, const char *, __int64, char *, __int64, __int64))(*(_QWORD *)v12 + 24LL))( /*0x10684bd57*/
      a1: v12,
      a2: "base64EncodedKllSketch",
      a3: 22,
      a4: v14,
      a5: v15,
      a6: 1);
    if ( v32[0] != nullptr ) /*0x10684bd61*/
    {
      v32[1] = v32[0]; /*0x10684bd63*/
      operator delete(a1: (RBX::Memory *)v32[0], a2: v16); /*0x10684bd67*/
    }
    if ( (v28 & 1) != 0 ) /*0x10684bd70*/
      operator delete(a1: (RBX::Memory *)v29, a2: v16); /*0x10684bd76*/
    if ( (v24 & 1) != 0 ) /*0x10684bd7f*/
      operator delete(a1: (RBX::Memory *)v27, a2: v16); /*0x10684bd85*/
    v19 = &off_10C449768; /*0x10684bd9c*/
    v23 = off_10C449790; /*0x10684bda4*/
    v20 = &off_10C799250; /*0x10684bdb2*/
    if ( (v21[56] & 1) != 0 ) /*0x10684bdba*/
      operator delete(a1: (RBX::Memory *)v22, a2: v16); /*0x10684bdc3*/
    v20 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x10684bdda*/
    std::locale::~locale(this: (std::locale *)v21); /*0x10684bdde*/
    std::ostream::~ostream(a1: &v19, a2: off_10C4497A8); /*0x10684bdf5*/
    return std::ios::~ios(a1: &v23); /*0x10684bdfd*/
  }
  return result; /*0x10684be02*/
}

// Address: 0x10685958d | Name: __ZN3RBX7Network20shouldInlineNetAssetERKNS_10Reflection18PropertyDescriptorERKNS_6ObjectEbb
RBX::Network *__fastcall RBX::Network::shouldInlineNetAsset(
        RBX::Network *this,
        const RBX::Reflection::PropertyDescriptor *a2,
        const RBX::Object *a3,
        char a4,
        char a5)
{
  __int16 v8; // ax
  std::__shared_weak_count *v9; // rdx
  std::__shared_weak_count *v11[11]; // [rsp+8h] [rbp-58h] BYREF

  if ( (*((_BYTE *)a2 + 139) & 0x40) == 0 /*0x1068595d2*/
    || (((*(unsigned __int8 (__fastcall **)(const RBX::Reflection::PropertyDescriptor *))(*(_QWORD *)a2 + 88LL))(a1: a2) == 2)
      | (unsigned __int8)(a5 | a4)) != 1 )
  {
    goto LABEL_6; /*0x1068595d2*/
  }
  (*(void (__fastcall **)(std::__shared_weak_count **, _QWORD, const RBX::Object *))(**((_QWORD **)a2 + 18) + 32LL))( /*0x1068595e8*/
    a1: v11,
    a2: *((_QWORD *)a2 + 18),
    a3);
  v8 = (__int16)v11[4]; /*0x1068595ef*/
  if ( LOWORD(v11[4]) == 0 || v11[2] == nullptr ) /*0x1068595f7*/
  {
    RBX::Network::NetAssetRef::~NetAssetRef(this: v11); /*0x106859632*/
LABEL_6:
    *(_BYTE *)this = 0; /*0x106859637*/
    *((_BYTE *)this + 24) = 0; /*0x10685963b*/
    return this; /*0x10685963b*/
  }
  v9 = v11[3]; /*0x10685960a*/
  *(std::__shared_weak_count **)this = v11[2]; /*0x10685960e*/
  *((_QWORD *)this + 1) = v9; /*0x106859611*/
  *((_WORD *)this + 8) = v8; /*0x106859615*/
  *(_DWORD *)((char *)this + 18) = *(_DWORD *)((char *)&v11[4] + 2); /*0x10685961c*/
  *((_WORD *)this + 11) = HIWORD(v11[4]); /*0x106859623*/
  *((_BYTE *)this + 24) = 1; /*0x106859627*/
  RBX::Network::NetAssetRef::~NetAssetRef(this: v11); /*0x10685962b*/
  return this; /*0x106859641*/
}

// Address: 0x106859650 | Name: __ZN3RBX7Network26shouldAttemptDecompressionEPNS0_10ReplicatorEPhi
char __fastcall RBX::Network::shouldAttemptDecompression(
        RBX::Network *this,
        RBX::Network::Replicator *a2,
        unsigned __int8 *a3)
{
  __int64 v3; // rcx
  char result; // al

  v3 = *((_QWORD *)this + 1945); /*0x106859654*/
  if ( (v3 & 0x400000) == 0 ) /*0x10685965f*/
    return 0; /*0x10685965f*/
  result = 1; /*0x106859665*/
  if ( *(_BYTE *)a2 != 0xA9 ) /*0x10685966a*/
  {
    if ( (v3 & 0x2000000) == 0 ) /*0x106859672*/
      return 0; /*0x106859663*/
    return RBX::NetworkBase::isPartiallyCompressedPhysicsPacket( /*0x10685967a*/
             this: a2,
             a2: (unsigned __int8 *)(unsigned int)a3,
             (int)a3);
  }
  return result; /*0x10685966c*/
}

// Address: 0x106861130 | Name: __ZZN3RBX7NetworkL26forEachMapsBandwidthReportIfEEvPKcRKNS_12DenseHashMapIPKNS_10Reflection10DescriptorET_NS_4HashIS8_EENSt3__18equal_toIS8_EEEESH_jjRKNS0_25BandwidthInfluxSharedDataEENKUlS8_PKfSM_E_clES8_SM_SM_
__int64 __fastcall RBX::Network::forEachMapsBandwidthReport<float>(char const*,RBX::DenseHashMap<RBX::Reflection::Descriptor const*,float,RBX::Hash<RBX::Reflection::Descriptor const*>,std::equal_to<RBX::Reflection::Descriptor const*>> const&,RBX::DenseHashMap<RBX::Reflection::Descriptor const*,float,RBX::Hash<RBX::Reflection::Descriptor const*>,std::equal_to<RBX::Reflection::Descriptor const*>> const&,unsigned int,unsigned int,RBX::Network::BandwidthInfluxSharedData const&)::{lambda(RBX::Reflection::Descriptor const*,float const*,float const*)#1}::operator()(
        __int64 a1,
        __int64 a2,
        float *a3,
        float *a4)
{
  __int64 v6; // r14
  const char *v7; // r14
  const char *v8; // r12
  __int64 v9; // rbx
  int v10; // edx
  int v11; // edx
  __int64 v12; // rdx
  __int64 v13; // rcx
  void *v14; // rsi
  _BYTE v16[16]; // [rsp+8h] [rbp-228h] BYREF
  void *v17; // [rsp+18h] [rbp-218h]
  unsigned int v18; // [rsp+20h] [rbp-210h]
  unsigned int v19; // [rsp+24h] [rbp-20Ch]
  void *v20[59]; // [rsp+28h] [rbp-208h] BYREF

  if ( a2 != 0 ) /*0x10686115b*/
  {
    v6 = *(_QWORD *)(a2 + 8); /*0x10686115d*/
    if ( (*(_BYTE *)v6 & 1) != 0 ) /*0x106861165*/
      v7 = *(const char **)(v6 + 16); /*0x106861175*/
    else
      v7 = (const char *)(v6 + 1); /*0x106861167*/
  }
  else
  {
    v7 = "Unknown"; /*0x10686116c*/
  }
  v8 = **(const char ***)a1; /*0x106861180*/
  v18 = **(_DWORD **)(a1 + 8); /*0x106861185*/
  v19 = **(_DWORD **)(a1 + 16); /*0x106861191*/
  v9 = *(_QWORD *)(a1 + 24); /*0x106861197*/
  RBX::Analytics::InfluxDb::Points::Points(a1: v20, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1068611ab*/
  RBX::Analytics::InfluxDb::Points::addPoint(a1: v20, a2: "Guid", a3: v9); /*0x1068611c1*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v20, a2: "Type", a3: v8); /*0x1068611d7*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v20, a2: "Subtype", a3: v7); /*0x1068611ed*/
  if ( a3 != nullptr ) /*0x1068611f5*/
    v10 = (int)*a3; /*0x1068611f7*/
  else
    v10 = 0; /*0x1068611ff*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10686120f*/
    this: (RBX::Analytics::InfluxDb::Points *)v20,
    a2: "SubtypeInbound",
    a3: v10);
  if ( a4 != nullptr ) /*0x106861217*/
    v11 = (int)*a4; /*0x106861219*/
  else
    v11 = 0; /*0x106861220*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106861230*/
    this: (RBX::Analytics::InfluxDb::Points *)v20,
    a2: "SubtypeOutbound",
    a3: v11);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106861249*/
    this: (RBX::Analytics::InfluxDb::Points *)v20,
    a2: "TypeInboundSubtotal",
    a3: v18);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106861262*/
    this: (RBX::Analytics::InfluxDb::Points *)v20,
    a2: "TypeOutboundSubtotal",
    a3: v19);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x106861278*/
    this: (RBX::Analytics::InfluxDb::Points *)v20,
    a2: "InboundTotal",
    a3: *(_DWORD *)(v9 + 28));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x10686128e*/
    this: (RBX::Analytics::InfluxDb::Points *)v20,
    a2: "OutboundTotal",
    a3: *(_DWORD *)(v9 + 32));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068612a6*/
    this: (RBX::Analytics::InfluxDb::Points *)v20,
    a2: "ElapsedSeconds",
    a3: *(float *)(v9 + 24));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068612bd*/
    this: (RBX::Analytics::InfluxDb::Points *)v20,
    a2: "IncludesJoin",
    a3: *(_BYTE *)(v9 + 36));
  std::string::basic_string[abi:ne200100]<0>(a1: v16, a2: "DetailedBandwidth", a3: v12, a4: v13); /*0x1068612d0*/
  RBX::Analytics::InfluxDb::Points::report( /*0x1068612eb*/
    a1: v20,
    a2: v16,
    a3: (unsigned int)DFInt::DetailedBandwidthStatsInfluxHundrethsPercentage,
    a4: 0);
  if ( (v16[0] & 1) != 0 ) /*0x1068612f7*/
    operator delete(a1: (RBX::Memory *)v17, a2: v14); /*0x106861300*/
  RBX::Analytics::InfluxDb::Points::~Points(this: v20); /*0x10686130c*/
  return __stack_chk_guard; /*0x106861321*/
}

// Address: 0x10689a08e | Name: __ZN3RBX7Network26getMechanismRootMovingPartEPNS_8BasePartE
__int64 __fastcall RBX::Network::getMechanismRootMovingPart(RBX::Mechanism **this, RBX::BasePart *a2)
{
  RBX::BasePart *RootMovingPrimitive; // rax
  RBX::Primitive *v3; // rsi

  RootMovingPrimitive = (RBX::BasePart *)RBX::Mechanism::getRootMovingPrimitive(this: *(this + 47), a2); /*0x10689a099*/
  return RBX::BasePart::fromPrimitive(this: RootMovingPrimitive, a2: v3); /*0x10689a0a1*/
}

// Address: 0x10689a0a7 | Name: __ZN3RBX7Network31getConstMechanismRootMovingPartEPKNS_8BasePartE
__int64 __fastcall RBX::Network::getConstMechanismRootMovingPart(RBX::Mechanism **this, const RBX::BasePart *a2)
{
  RBX::BasePart *ConstRootMovingPrimitive; // rax
  const RBX::Primitive *v3; // rsi

  ConstRootMovingPrimitive = (RBX::BasePart *)RBX::Mechanism::getConstRootMovingPrimitive(this: *(this + 47), a2); /*0x10689a0b2*/
  return RBX::BasePart::fromConstPrimitive(this: ConstRootMovingPrimitive, a2: v3); /*0x10689a0ba*/
}

// Address: 0x10689b031 | Name: __ZN3RBX7NetworkL12profilerDumpENSt3__18weak_ptrINS_9DataModelEEENS2_INS0_16ServerReplicatorEEEi14PacketPriorityi
__int64 __fastcall RBX::Network::profilerDump(__int64 *a1, __int64 *a2, unsigned int a3, unsigned int a4, int a5)
{
  std::__shared_weak_count *v9; // rdi
  volatile signed __int64 *v10; // rax
  volatile signed __int64 *v11; // r13
  __int64 v12; // rax
  RBX::Profiler *v13; // rdi
  RBX::Network::NetworkStream *v14; // r13
  int v15; // eax
  unsigned __int8 v16; // cl
  std::__shared_weak_count *v17; // rdi
  volatile signed __int64 *v18; // rax
  unsigned __int64 v19; // rsi
  volatile signed __int64 *v20; // r13
  __int64 v21; // rax
  __int64 v22; // r15
  std::__shared_weak_count *v23; // r12
  _QWORD *v24; // rax
  __int64 v25; // rax
  void *v26; // rsi
  std::__shared_weak_count *v27; // rbx
  __int64 v29[3]; // [rsp+8h] [rbp-248h] BYREF
  __int64 (__fastcall **v30)(); // [rsp+20h] [rbp-230h] BYREF
  _BYTE v31[72]; // [rsp+28h] [rbp-228h] BYREF
  void *v32; // [rsp+70h] [rbp-1E0h]
  __int64 (__fastcall **v33)(); // [rsp+88h] [rbp-1C8h] BYREF
  _QWORD v34[12]; // [rsp+120h] [rbp-130h] BYREF
  unsigned __int64 v35; // [rsp+180h] [rbp-D0h]
  __int64 v36; // [rsp+190h] [rbp-C0h]
  volatile signed __int64 *v37; // [rsp+198h] [rbp-B8h]
  __int64 v38; // [rsp+1A0h] [rbp-B0h]
  __int64 v39; // [rsp+1A8h] [rbp-A8h]
  RBX::Network::NetworkStream *v40; // [rsp+1B0h] [rbp-A0h]
  unsigned __int8 v41[8]; // [rsp+1B8h] [rbp-98h] BYREF
  int v42; // [rsp+1C0h] [rbp-90h]
  void *v43; // [rsp+1C8h] [rbp-88h]
  RBX::Network::NetworkStream *v44; // [rsp+1D0h] [rbp-80h] BYREF
  std::__shared_weak_count *v45; // [rsp+1D8h] [rbp-78h]
  _QWORD v46[2]; // [rsp+1E0h] [rbp-70h] BYREF
  _BYTE v47[32]; // [rsp+1F0h] [rbp-60h] BYREF
  _BYTE *v48; // [rsp+210h] [rbp-40h]

  v29[0] = 1000000LL * a5; /*0x10689b06f*/
  RBX::BoostThisThread::sleep(a1: v29); /*0x10689b072*/
  v9 = (std::__shared_weak_count *)a2[1]; /*0x10689b077*/
  if ( v9 == nullptr ) /*0x10689b07e*/
    return __stack_chk_guard; /*0x10689b07e*/
  v10 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v9); /*0x10689b084*/
  v37 = v10; /*0x10689b089*/
  if ( v10 == nullptr ) /*0x10689b093*/
    return __stack_chk_guard; /*0x10689b093*/
  v11 = v10; /*0x10689b099*/
  v12 = *a2; /*0x10689b09c*/
  v36 = v12; /*0x10689b09f*/
  if ( v12 == 0 || *(_BYTE *)(v12 + 18384) != 1 ) /*0x10689b0b6*/
    goto LABEL_37; /*0x10689b0b6*/
  std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::basic_stringstream[abi:ne200100](a1: v29); /*0x10689b0c3*/
  if ( DFFlag::MicroprofilerOutputServerReplRaw == 1 ) /*0x10689b0cf*/
    RBX::Profiler::dumpProfilerRawToStringStream(a1: v29, a2: a3); /*0x10689b0da*/
  else
    RBX::Profiler::dumpProfilerDataToStringStream(a1: v29, a2: a3); /*0x10689b0ea*/
  RBX::Profiler::notifyCaptureComplete(this: v13); /*0x10689b0ef*/
  std::stringbuf::str(a1: v41, a2: &v30); /*0x10689b102*/
  RBX::make_shared<RBX::Network::NetworkStream>(a1: (RSL::Arena *)&v44); /*0x10689b10b*/
  v14 = v44; /*0x10689b110*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v34); /*0x10689b11b*/
  LOBYTE(v46[0]) = -102; /*0x10689b124*/
  RBX::Network::NetworkStream::writeBytes(this: v14, a2: v46, a3: 1u); /*0x10689b12f*/
  if ( DFFlag::DebugMicroprofilerOutputRaw != 0 || DFFlag::MicroprofilerOutputServerReplRaw == 1 ) /*0x10689b147*/
  {
    LODWORD(v46[0]) = 5; /*0x10689b14d*/
    RBX::Network::NetworkStream::writeBytes(this: v14, a2: v46, a3: 4u); /*0x10689b15b*/
  }
  else
  {
    LODWORD(v46[0]) = 1; /*0x10689b166*/
    RBX::Network::NetworkStream::writeBytes(this: v14, a2: v46, a3: 4u); /*0x10689b174*/
  }
  if ( (v41[0] & 1) != 0 ) /*0x10689b182*/
    v15 = v42; /*0x10689b184*/
  else
    v15 = v41[0] >> 1; /*0x10689b18c*/
  LODWORD(v46[0]) = v15; /*0x10689b192*/
  RBX::Network::NetworkStream::writeBytes(this: v14, a2: v46, a3: 4u); /*0x10689b19c*/
  RBX::Network::serializeString( /*0x10689b1b8*/
    a1: v41,
    a2: (RBX::Network::NetworkStream *)v34,
    a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
  RBX::Network::Replicator::compressBitStream( /*0x10689b1d1*/
    this: (RBX::Network::Replicator *)v34,
    a2: v14,
    a3: (RBX::Network::NetworkStream *)(unsigned __int8)DFInt::JoinDataCompressionLevel,
    a4: v16);
  v17 = (std::__shared_weak_count *)a1[1]; /*0x10689b1d6*/
  if ( v17 == nullptr ) /*0x10689b1de*/
    goto LABEL_29; /*0x10689b1de*/
  v18 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v17); /*0x10689b1e4*/
  v46[1] = v18; /*0x10689b1e9*/
  if ( v18 == nullptr ) /*0x10689b1f0*/
    goto LABEL_29; /*0x10689b1f0*/
  v20 = v18; /*0x10689b1f6*/
  v21 = *a1; /*0x10689b1f9*/
  v46[0] = v21; /*0x10689b1fd*/
  if ( v21 != 0 ) /*0x10689b204*/
  {
    v39 = *a2; /*0x10689b20d*/
    v34[8] = v39; /*0x10689b214*/
    v22 = a2[1]; /*0x10689b21b*/
    v34[9] = v22; /*0x10689b21f*/
    if ( v22 != 0 ) /*0x10689b229*/
      _InterlockedIncrement64((volatile signed __int64 *)(v22 + 16)); /*0x10689b22b*/
    v38 = v21; /*0x10689b230*/
    v23 = v45; /*0x10689b23b*/
    v40 = v44; /*0x10689b23f*/
    v34[10] = v44; /*0x10689b246*/
    v34[11] = v45; /*0x10689b24d*/
    if ( v45 != nullptr ) /*0x10689b257*/
      _InterlockedIncrement64((volatile signed __int64 *)v45 + 1); /*0x10689b259*/
    v35 = __PAIR64__(a3, a4); /*0x10689b25f*/
    v48 = nullptr; /*0x10689b26c*/
    v24 = (_QWORD *)operator new(a1: (RBX::Memory *)0x30, a2: v19); /*0x10689b279*/
    *v24 = &off_10CAAF320; /*0x10689b28c*/
    v24[1] = v39; /*0x10689b296*/
    v24[2] = v22; /*0x10689b29a*/
    *(_OWORD *)&v34[8] = 0; /*0x10689b2a1*/
    v24[3] = v40; /*0x10689b2ac*/
    v24[4] = v23; /*0x10689b2b0*/
    *(_OWORD *)&v34[10] = 0; /*0x10689b2b4*/
    v24[5] = v35; /*0x10689b2bb*/
    v48 = v24; /*0x10689b2c3*/
    RBX::DataModel::submitTask(a1: v38, a2: v47, a3: 1); /*0x10689b2d6*/
    if ( v48 == v47 ) /*0x10689b2e2*/
    {
      v25 = 32; /*0x10689b2f0*/
    }
    else
    {
      v25 = 40; /*0x10689b2e4*/
      if ( v48 == nullptr ) /*0x10689b2ec*/
        goto LABEL_27; /*0x10689b2ec*/
    }
    (*(void (**)(void))(*(_QWORD *)v48 + v25))(); /*0x10689b2f8*/
  }
LABEL_27:
  if ( _InterlockedExchangeAdd64(v20 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689b30b*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v20 + 16))(a1: v20); /*0x10689b314*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v20); /*0x10689b31a*/
  }
LABEL_29:
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v34); /*0x10689b31f*/
  v27 = v45; /*0x10689b32b*/
  if ( v45 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v45 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689b344*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v27 + 16LL))(a1: v27); /*0x10689b34c*/
    std::__shared_weak_count::__release_weak(this: v27); /*0x10689b352*/
  }
  if ( (v41[0] & 1) != 0 ) /*0x10689b35e*/
    operator delete(a1: (RBX::Memory *)v43, a2: v26); /*0x10689b367*/
  v29[0] = (__int64)&off_10C798D68; /*0x10689b37e*/
  v33 = off_10C798DB8; /*0x10689b386*/
  v29[2] = (__int64)off_10C798D90; /*0x10689b38d*/
  v30 = &off_10C799250; /*0x10689b39c*/
  if ( (v31[56] & 1) != 0 ) /*0x10689b3a4*/
    operator delete(a1: (RBX::Memory *)v32, a2: v26); /*0x10689b3ad*/
  v30 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x10689b3c4*/
  std::locale::~locale(this: (std::locale *)v31); /*0x10689b3c8*/
  std::iostream::~iostream(a1: v29, a2: off_10C799178); /*0x10689b3df*/
  std::ios::~ios(a1: &v33); /*0x10689b3e7*/
  v11 = v37; /*0x10689b3ec*/
  if ( v37 != nullptr ) /*0x10689b3f6*/
  {
LABEL_37:
    if ( _InterlockedExchangeAdd64(v11 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689b408*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v11 + 16))(a1: v11); /*0x10689b411*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v11); /*0x10689b417*/
    }
  }
  return __stack_chk_guard; /*0x10689b42c*/
}

// Address: 0x10689f7b6 | Name: __ZN3RBX7NetworkL15addGameLoadStatERNSt3__16vectorINS1_4pairINS1_12basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEdEENS7_ISA_EEEEPKcdxb
void __fastcall RBX::Network::addGameLoadStat(__int64 a1, __int64 a2, __int64 a3, __int64 a4, double a5)
{
  char v5; // r14
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // r8
  __int64 v11; // r9
  __m128 v12; // xmm1
  __m128 v13; // xmm2
  __m128 v14; // xmm3
  __m128 v15; // xmm4
  __m128 v16; // xmm5
  __m128 v17; // xmm6
  __m128 v18; // xmm7
  void *v19; // rsi
  void *v20; // rsi
  __int64 v21; // rax
  __int64 v22; // rdx
  __int64 v23; // rcx
  __int64 v24; // r8
  __int64 v25; // r9
  void *v26; // rsi
  const char *v27; // rsi
  __int64 v28; // rdx
  __int64 v29; // rcx
  __int64 v30; // r8
  __int64 v31; // r9
  void *v32; // rsi
  char v33; // al
  __int64 v34; // rcx
  __int64 v35; // rdx
  __int64 v36; // rcx
  __int64 v37; // r8
  __int64 v38; // r9
  char v39; // [rsp+0h] [rbp-A0h]
  __int128 v41; // [rsp+10h] [rbp-90h] BYREF
  void *v42; // [rsp+20h] [rbp-80h]
  __int128 v43; // [rsp+28h] [rbp-78h] BYREF
  void *v44; // [rsp+38h] [rbp-68h]
  __int128 v45; // [rsp+40h] [rbp-60h] BYREF
  void *v46; // [rsp+50h] [rbp-50h]
  __int128 v47; // [rsp+60h] [rbp-40h] BYREF
  void *v48; // [rsp+70h] [rbp-30h]
  double v49; // [rsp+78h] [rbp-28h]

  v5 = a4; /*0x10689f7c6*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v43, a2, a3, a4); /*0x10689f7db*/
  v41 = 0; /*0x10689f7e3*/
  v42 = nullptr; /*0x10689f7ea*/
  if ( DFFlag::DebugGameLoadDataStatisticsPerPlace == 1 ) /*0x10689f7f9*/
  {
    RBX::format( /*0x10689f80b*/
      this: (RBX *)&v47,
      a2: "_PlaceId_%lld",
      a3,
      a4: v9,
      a5: v10,
      a6: v11,
      a7: (__m128)0LL,
      a8: v12,
      a9: v13,
      a10: v14,
      a11: v15,
      a12: v16,
      a13: v17,
      a14: v18,
      a15: v39);
    if ( (v41 & 1) != 0 ) /*0x10689f817*/
      operator delete(a1: (RBX::Memory *)v42, a2: v19); /*0x10689f81d*/
    v42 = v48; /*0x10689f826*/
    v41 = v47; /*0x10689f82e*/
  }
  if ( (v43 & 1) != 0 ) /*0x10689f839*/
  {
    std::string::__init_copy_ctor_external(a1: &v47, a2: v44, a3: *((_QWORD *)&v43 + 1)); /*0x10689f859*/
  }
  else
  {
    v48 = v44; /*0x10689f83f*/
    v47 = v43; /*0x10689f847*/
  }
  v49 = a5; /*0x10689f86a*/
  std::vector<std::pair<std::string,double>>::push_back[abi:ne200100](a1, a2: &v47, a3: v8, a4: v9, a5: v10, a6: v11); /*0x10689f872*/
  if ( (v47 & 1) != 0 ) /*0x10689f87b*/
    operator delete(a1: (RBX::Memory *)v48, a2: v20); /*0x10689f881*/
  if ( (v41 & 1) != 0 ) /*0x10689f88f*/
    v21 = *((_QWORD *)&v41 + 1); /*0x10689f891*/
  else
    v21 = (unsigned __int8)v41 >> 1; /*0x10689f89a*/
  if ( v21 != 0 ) /*0x10689f89f*/
  {
    std::operator+[abi:ne200100]<char,std::char_traits<char>,std::allocator<char>>(a1: &v45, a2: &v43, a3: &v41); /*0x10689f8b0*/
    v48 = v46; /*0x10689f8bd*/
    v47 = v45; /*0x10689f8c5*/
    v45 = 0; /*0x10689f8cb*/
    v46 = nullptr; /*0x10689f8cf*/
    v49 = a5; /*0x10689f8df*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10689f8e7*/
      a1,
      a2: &v47,
      a3: v22,
      a4: v23,
      a5: v24,
      a6: v25);
    if ( (v47 & 1) != 0 ) /*0x10689f8f0*/
      operator delete(a1: (RBX::Memory *)v48, a2: v26); /*0x10689f8f6*/
    if ( (v45 & 1) != 0 ) /*0x10689f8ff*/
      operator delete(a1: (RBX::Memory *)v46, a2: v26); /*0x10689f905*/
  }
  v27 = "_Success"; /*0x10689f911*/
  if ( v5 != 0 ) /*0x10689f91b*/
    v27 = "_Fail"; /*0x10689f91b*/
  std::string::append(a1: &v43, a2: v27); /*0x10689f923*/
  if ( (v43 & 1) != 0 ) /*0x10689f92c*/
  {
    std::string::__init_copy_ctor_external(a1: &v47, a2: v44, a3: *((_QWORD *)&v43 + 1)); /*0x10689f94c*/
  }
  else
  {
    v48 = v44; /*0x10689f932*/
    v47 = v43; /*0x10689f93a*/
  }
  v49 = a5; /*0x10689f95d*/
  std::vector<std::pair<std::string,double>>::push_back[abi:ne200100](a1, a2: &v47, a3: v28, a4: v29, a5: v30, a6: v31); /*0x10689f965*/
  if ( (v47 & 1) != 0 ) /*0x10689f96e*/
    operator delete(a1: (RBX::Memory *)v48, a2: v32); /*0x10689f974*/
  v33 = v41 & 1; /*0x10689f982*/
  if ( (v41 & 1) != 0 ) /*0x10689f984*/
    v34 = *((_QWORD *)&v41 + 1); /*0x10689f986*/
  else
    v34 = (unsigned __int8)v41 >> 1; /*0x10689f98f*/
  if ( v34 != 0 ) /*0x10689f994*/
  {
    std::operator+[abi:ne200100]<char,std::char_traits<char>,std::allocator<char>>(a1: &v45, a2: &v43, a3: &v41); /*0x10689f9a5*/
    v48 = v46; /*0x10689f9b2*/
    v47 = v45; /*0x10689f9ba*/
    v45 = 0; /*0x10689f9c0*/
    v46 = nullptr; /*0x10689f9c4*/
    v49 = a5; /*0x10689f9d4*/
    std::vector<std::pair<std::string,double>>::push_back[abi:ne200100]( /*0x10689f9dc*/
      a1,
      a2: &v47,
      a3: v35,
      a4: v36,
      a5: v37,
      a6: v38);
    if ( (v47 & 1) != 0 ) /*0x10689f9e5*/
      operator delete(a1: (RBX::Memory *)v48, a2: v32); /*0x10689f9eb*/
    if ( (v45 & 1) != 0 ) /*0x10689f9f4*/
      operator delete(a1: (RBX::Memory *)v46, a2: v32); /*0x10689f9fa*/
    v33 = v41 & 1; /*0x10689fa05*/
  }
  if ( v33 != 0 ) /*0x10689fa09*/
    operator delete(a1: (RBX::Memory *)v42, a2: v32); /*0x10689fa0f*/
  if ( (v43 & 1) != 0 ) /*0x10689fa18*/
    operator delete(a1: (RBX::Memory *)v44, a2: v32); /*0x10689fa1e*/
}

// Address: 0x1068a54d5 | Name: __ZN3RBX7NetworkL15serializeSFFlagERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_RKNS1_6vectorIS7_NS5_IS7_EEEESE_SE_Pv
void __fastcall RBX::Network::serializeSFFlag(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        RBX::Network::NetworkStream *a6)
{
  _BYTE v9[8]; // [rsp+8h] [rbp-28h] BYREF
  _BYTE v10[32]; // [rsp+10h] [rbp-20h] BYREF

  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1068a54ee*/
    RakNet::RakString::RakString(this: (RakNet::RakString *)v9, a2: *(const char **)(a1 + 16)); /*0x1068a54f4*/
  else
    RakNet::RakString::RakString(this: (RakNet::RakString *)v9, a2: (const char *)(a1 + 1)); /*0x1068a5500*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1068a5508*/
    RakNet::RakString::RakString(this: (RakNet::RakString *)v10, a2: *(const char **)(a2 + 16)); /*0x1068a550e*/
  else
    RakNet::RakString::RakString(this: (RakNet::RakString *)v10, a2: (const char *)(a2 + 1)); /*0x1068a551a*/
  RBX::Network::Serializer<RakNet::RakString>::serialize(this: a6, a2: (RakNet::RakString *)v9); /*0x1068a5526*/
  RBX::Network::Serializer<RakNet::RakString>::serialize(this: a6, a2: (RakNet::RakString *)v10); /*0x1068a5532*/
  FLog::SetValueFromServer((__m128 *)a1, (const __m128 *)a2); /*0x1068a553d*/
  RakNet::RakString::~RakString(this: (RakNet::RakString *)v10); /*0x1068a5546*/
  RakNet::RakString::~RakString(this: (RakNet::RakString *)v9); /*0x1068a554f*/
}

// Address: 0x1068a5581 | Name: __ZN3RBX7NetworkL26DEPRECATED_serializeSFFlagERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_RKNS1_6vectorIS7_NS5_IS7_EEEESE_Pv
void __fastcall RBX::Network::DEPRECATED_serializeSFFlag(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        RBX::Network::NetworkStream *a5)
{
  _BYTE v8[8]; // [rsp+8h] [rbp-28h] BYREF
  _BYTE v9[32]; // [rsp+10h] [rbp-20h] BYREF

  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1068a559a*/
    RakNet::RakString::RakString(this: (RakNet::RakString *)v8, a2: *(const char **)(a1 + 16)); /*0x1068a55a0*/
  else
    RakNet::RakString::RakString(this: (RakNet::RakString *)v8, a2: (const char *)(a1 + 1)); /*0x1068a55ac*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1068a55b4*/
    RakNet::RakString::RakString(this: (RakNet::RakString *)v9, a2: *(const char **)(a2 + 16)); /*0x1068a55ba*/
  else
    RakNet::RakString::RakString(this: (RakNet::RakString *)v9, a2: (const char *)(a2 + 1)); /*0x1068a55c6*/
  RBX::Network::Serializer<RakNet::RakString>::serialize(this: a5, a2: (RakNet::RakString *)v8); /*0x1068a55d2*/
  RBX::Network::Serializer<RakNet::RakString>::serialize(this: a5, a2: (RakNet::RakString *)v9); /*0x1068a55de*/
  FLog::SetValueFromServer((__m128 *)a1, (const __m128 *)a2); /*0x1068a55e9*/
  RakNet::RakString::~RakString(this: (RakNet::RakString *)v9); /*0x1068a55f2*/
  RakNet::RakString::~RakString(this: (RakNet::RakString *)v8); /*0x1068a55fb*/
}

// Address: 0x1068a632c | Name: __ZZN3RBX7NetworkL12profilerDumpENSt3__18weak_ptrINS_9DataModelEEENS2_INS0_16ServerReplicatorEEEi14PacketPriorityiEN3$_0D1Ev
__int64 __fastcall RBX::Network::profilerDump(std::weak_ptr<RBX::DataModel>,std::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int)::$_0::~$_0(
        __int64 a1)
{
  __int64 result; // rax
  std::__shared_weak_count *v3; // rdi

  result = std::shared_ptr<RBX::Network::NetworkStream>::~shared_ptr[abi:ne200100](a1: a1 + 16); /*0x1068a6339*/
  v3 = *(std::__shared_weak_count **)(a1 + 8); /*0x1068a633e*/
  if ( v3 != nullptr ) /*0x1068a6349*/
    return std::__shared_weak_count::__release_weak(this: v3); /*0x1068a634d*/
  return result; /*0x1068a634b*/
}

// Address: 0x1068bef93 | Name: __ZN3RBX7Network20isConstraintInstanceEPKNS_8InstanceE
__int64 __fastcall RBX::Network::isConstraintInstance(
        RBX::Network *this,
        const RBX::Instance *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  __int64 v7; // rax
  __int64 v8; // rdi
  unsigned int v9; // ecx
  __int64 v10; // rbx
  __int64 v11; // r15
  __int64 v12; // rax
  __int64 v13; // rdi
  __int64 v14; // rsi
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // r15
  __int64 v18; // rax
  __int64 v19; // rdi
  __int64 v20; // rsi
  __int64 v21; // r15
  __int64 v22; // rax
  __int64 v23; // rdi
  __int64 v24; // rax

  v10 = *((_QWORD *)this + 3); /*0x1068befa0*/
  v7 = RBX::Reflection::Class_getDescriptorPtr<RBX::Attachment>(a1: this, a2, a3, a4, a5, a6); /*0x1068befa4*/
  v9 = *(unsigned __int16 *)(v10 + 440) - *(unsigned __int16 *)(v7 + 440); /*0x1068befb7*/
  LOBYTE(v10) = 1; /*0x1068befc0*/
  if ( v9 > *(unsigned __int16 *)(v7 + 442) ) /*0x1068befc4*/
  {
    v11 = *((_QWORD *)this + 3); /*0x1068befca*/
    v12 = RBX::Reflection::Class_getDescriptorPtr<RBX::DragDetector>(a1: v8); /*0x1068befce*/
    v15 = *(unsigned __int16 *)(v12 + 440); /*0x1068befdb*/
    v16 = *(unsigned __int16 *)(v11 + 440) - (unsigned int)v15; /*0x1068befe2*/
    if ( (unsigned int)v16 > *(unsigned __int16 *)(v12 + 442) ) /*0x1068befed*/
    {
      v17 = *((_QWORD *)this + 3); /*0x1068befef*/
      v18 = RBX::Reflection::Class_getDescriptorPtr<RBX::JointInstance>(a1: v13, a2: v14, a3: v15, a4: v16); /*0x1068beff3*/
      if ( *(unsigned __int16 *)(v17 + 440) - (unsigned int)*(unsigned __int16 *)(v18 + 440) > *(unsigned __int16 *)(v18 + 442) ) /*0x1068bf012*/
      {
        v21 = *((_QWORD *)this + 3); /*0x1068bf014*/
        v22 = RBX::Reflection::Class_getDescriptorPtr<RBX::Constraints::Constraint>(a1: v19, a2: v20); /*0x1068bf018*/
        if ( *(unsigned __int16 *)(v21 + 440) - (unsigned int)*(unsigned __int16 *)(v22 + 440) > *(unsigned __int16 *)(v22 + 442) ) /*0x1068bf037*/
        {
          v10 = *((_QWORD *)this + 3); /*0x1068bf039*/
          v24 = RBX::Reflection::Class_getDescriptorPtr<RBX::Constraints::WeldConstraint>(a1: v23); /*0x1068bf03d*/
          LOBYTE(v10) = *(unsigned __int16 *)(v10 + 440) - (unsigned int)*(unsigned __int16 *)(v24 + 440) <= *(unsigned __int16 *)(v24 + 442); /*0x1068bf05b*/
        }
      }
    }
  }
  return (unsigned int)v10; /*0x1068bf064*/
}

// Address: 0x1068d3ade | Name: __ZN3RBX7Network27pathPrefetchMeetsMinDensityEfi
bool __fastcall RBX::Network::pathPrefetchMeetsMinDensity(RBX::Network *this, float a2)
{
  int v2; // eax
  int v3; // ecx

  v2 = 10000; /*0x1068d3ae2*/
  if ( (unsigned int)this < 0x2710 ) /*0x1068d3ae9*/
    v2 = (int)this; /*0x1068d3ae9*/
  v3 = 0; /*0x1068d3aec*/
  if ( (int)this > 0 ) /*0x1068d3af0*/
    v3 = v2; /*0x1068d3af0*/
  return (float)(a2 * 10000.0) >= (float)v3; /*0x1068d3b05*/
}

// Address: 0x1068d3b07 | Name: __ZN3RBX7Network27pathPrefetchColumnMaxWeightERKNS_19HeatmapQueryServiceERKNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEESC_NS_12Vector3int32Eii
void __fastcall RBX::Network::pathPrefetchColumnMaxWeight(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        unsigned int a5,
        unsigned int a6,
        int a7)
{
  int v9; // edx
  __int64 v10; // r14
  int v11; // r15d
  __int64 v12; // rbx
  float v13; // xmm0_4

  v9 = 0; /*0x1068d3b34*/
  if ( a7 > 0 ) /*0x1068d3b38*/
    v9 = a7; /*0x1068d3b38*/
  v10 = (unsigned int)a4; /*0x1068d3b3b*/
  v11 = 2 * v9 + 1; /*0x1068d3b3e*/
  v12 = (unsigned int)(HIDWORD(a4) - v9); /*0x1068d3b46*/
  v13 = 0.0; /*0x1068d3b48*/
  do /*0x1068d3b7b*/
  {
    v13 = fmaxf(RBX::HeatmapQueryService::getRegionWeightSum(a1, a2, a3, a4: v10 | (v12 << 32), a5, a6), v13); /*0x1068d3b71*/
    v12 = (unsigned int)(v12 + 1); /*0x1068d3b76*/
    --v11; /*0x1068d3b78*/
  }
  while ( v11 != 0 ); /*0x1068d3b7b*/
}

// Address: 0x1068d3b8c | Name: __ZN3RBX7Network22pathPrefetchGreedyWalkENS_7Vector3ERKS1_fNSt3__18functionIFfNS_12Vector3int32EiEEEiNS0_8WalkRankENS0_25PathPrefetchWalkOverridesE
RBX::Math *__fastcall RBX::Network::pathPrefetchGreedyWalk(
        RBX::Math *a1,
        unsigned int *a2,
        __int64 a3,
        int a4,
        char a5,
        __m128 a6,
        float a7,
        float a8,
        __int64 a9,
        __int64 a10,
        __int64 a11,
        __int64 a12,
        __int64 a13,
        char a14)
{
  unsigned int *v16; // r13
  __m128 v17; // xmm4
  __m128 v18; // xmm0
  __m128 v19; // xmm1
  __m128 v20; // xmm1
  float v21; // xmm1_4
  __m128 v22; // xmm2
  float v23; // xmm3_4
  __m128 v24; // xmm2
  __m128 v25; // xmm5
  float v26; // xmm3_4
  __int64 DefaultArena; // rax
  __m128 v29; // xmm0
  __m128 v30; // xmm2
  __m128 v31; // xmm1
  int v32; // ecx
  int v33; // edx
  int v34; // ecx
  __m128 v35; // xmm2
  __m128 v36; // xmm1
  int v37; // ecx
  int v38; // edx
  int v39; // ecx
  int *v40; // rax
  __int64 v41; // rax
  float v42; // xmm4_4
  __m128 v43; // xmm5
  __m128 v44; // xmm0
  __m128 v45; // xmm1
  __m128 v46; // xmm2
  __m128 v47; // xmm1
  unsigned __int64 v48; // r12
  int v49; // ecx
  float v50; // xmm2_4
  float v51; // xmm8_4
  __m128 v52; // xmm1
  __m128 v53; // xmm0
  __m128 v54; // xmm2
  __m128 inserted; // xmm2
  __int64 i; // r15
  __int64 v57; // rsi
  __int64 v58; // rax
  __int64 v59; // rdx
  float *v60; // rax
  __int64 j; // rcx
  __m128 v62; // xmm0
  int v63; // edx
  __int64 m; // rax
  int v65; // ecx
  __int64 v66; // rsi
  int v67; // eax
  __m128 v68; // xmm0
  float v69; // xmm1_4
  __m128 v70; // xmm1
  int v71; // edx
  __int64 k; // rcx
  float v73; // xmm0_4
  int v74; // edx
  char v75; // dl
  __m128 v76; // xmm0
  unsigned int v77; // xmm1_4
  int v78; // ecx
  __m128 v79; // xmm3
  float v80; // xmm3_4
  __m128 v81; // [rsp+20h] [rbp-190h]
  float v82; // [rsp+30h] [rbp-180h]
  __m128 v83; // [rsp+40h] [rbp-170h]
  __m128 v84; // [rsp+50h] [rbp-160h]
  float v86; // [rsp+70h] [rbp-140h]
  __m128 v87; // [rsp+70h] [rbp-140h]
  float v88; // [rsp+80h] [rbp-130h]
  __m128 v89; // [rsp+80h] [rbp-130h]
  __m128 v90; // [rsp+90h] [rbp-120h]
  float v91; // [rsp+90h] [rbp-120h]
  __m128 v92; // [rsp+A0h] [rbp-110h]
  float v94; // [rsp+B0h] [rbp-100h]
  __m128 v95; // [rsp+B0h] [rbp-100h]
  int v96; // [rsp+C8h] [rbp-E8h]
  int v97; // [rsp+D8h] [rbp-D8h]
  float v98; // [rsp+E4h] [rbp-CCh]
  int v100; // [rsp+F4h] [rbp-BCh]
  int v101; // [rsp+F8h] [rbp-B8h]
  char v103; // [rsp+FCh] [rbp-B4h]
  int v104; // [rsp+100h] [rbp-B0h]
  int v106; // [rsp+108h] [rbp-A8h]
  float v107; // [rsp+108h] [rbp-A8h]
  float v108; // [rsp+10Ch] [rbp-A4h]
  char v109; // [rsp+113h] [rbp-9Dh]
  float v110[3]; // [rsp+114h] [rbp-9Ch]
  double v111; // [rsp+120h] [rbp-90h] BYREF
  float v112; // [rsp+128h] [rbp-88h]
  __int64 v113; // [rsp+12Ch] [rbp-84h] BYREF
  float v114; // [rsp+134h] [rbp-7Ch]
  __int64 v115; // [rsp+138h] [rbp-78h] BYREF
  float v116; // [rsp+140h] [rbp-70h]
  double v117; // [rsp+150h] [rbp-60h] BYREF
  float v118; // [rsp+158h] [rbp-58h] BYREF
  float v119; // [rsp+15Ch] [rbp-54h]
  float v120; // [rsp+160h] [rbp-50h]
  float v121; // [rsp+164h] [rbp-4Ch]
  __int64 v122; // [rsp+168h] [rbp-48h] BYREF
  unsigned int v123; // [rsp+170h] [rbp-40h]

  v16 = a2; /*0x1068d3bb4*/
  if ( DFFlag::PathPrefetchGuardNonFiniteInput != 0 ) /*0x1068d3be2*/
  {
    if ( (unsigned __int8)RBX::Math::isFinite(this: a1, a2: a6.f32[0]) == 0 ) /*0x1068d3bef*/
      goto LABEL_10; /*0x1068d3bef*/
    if ( (unsigned __int8)RBX::Math::isFinite(this: a1, a2: _mm_movehdup_ps(a6).f32[0]) == 0 ) /*0x1068d3c04*/
      goto LABEL_10; /*0x1068d3c04*/
    if ( (unsigned __int8)RBX::Math::isFinite(this: a1, a2: a7) == 0 ) /*0x1068d3c19*/
      goto LABEL_10; /*0x1068d3c19*/
    v17 = (__m128)*v16; /*0x1068d3c1f*/
    v18 = v17; /*0x1068d3c25*/
    v18.f32[0] = v17.f32[0] * v17.f32[0]; /*0x1068d3c28*/
    v19 = (__m128)*(unsigned __int64 *)(v16 + 1); /*0x1068d3c2c*/
    v90 = _mm_movehdup_ps(v19); /*0x1068d3c36*/
    v20 = _mm_mul_ps(v19, v19); /*0x1068d3c3d*/
    v22 = v18; /*0x1068d3c40*/
    v22.f32[0] = (float)(v17.f32[0] * v17.f32[0]) + v20.f32[0]; /*0x1068d3c43*/
    v21 = _mm_movehdup_ps(v20).f32[0]; /*0x1068d3c47*/
    v22.f32[0] = v22.f32[0] + v21; /*0x1068d3c4b*/
    if ( v22.f32[0] != 1.0 ) /*0x1068d3c56*/
    {
      v23 = fabs(v22.f32[0] + -1.0); /*0x1068d3c70*/
      v24 = _mm_and_ps(v22, (__m128)xmmword_108F46760); /*0x1068d3c73*/
      v24.f32[0] = v24.f32[0] + 1.0; /*0x1068d3c76*/
      v25 = _mm_cmple_ss((__m128)0x7F800000u, v24); /*0x1068d3c8e*/
      v24.f32[0] = v24.f32[0] * 0.0000099999997; /*0x1068d3c93*/
      if ( COERCE_FLOAT(v25.i32[0] & 0x3727C5AC | _mm_andnot_ps(v25, v24).u32[0]) < v23 ) /*0x1068d3ca9*/
        goto LABEL_10; /*0x1068d3ca9*/
    }
  }
  else
  {
    v17.i32[0] = *a2; /*0x1068d3cad*/
    v18.f32[0] = v17.f32[0] * v17.f32[0]; /*0x1068d3cbc*/
    v90 = (__m128)a2[2]; /*0x1068d3cc0*/
    v21 = v90.f32[0] * v90.f32[0]; /*0x1068d3cc7*/
  }
  v26 = fsqrt(v21 + v18.f32[0]); /*0x1068d3cd2*/
  if ( v26 < 0.000099999997 ) /*0x1068d3ce1*/
  {
LABEL_10:
    DefaultArena = RSL::Arena::getDefaultArena(this: a1); /*0x1068d3ce3*/
    *(_OWORD *)a1 = 0; /*0x1068d3cf2*/
    *((_QWORD *)a1 + 2) = 0; /*0x1068d3cf5*/
    *((_QWORD *)a1 + 3) = DefaultArena; /*0x1068d3cfd*/
    return a1; /*0x1068d3cfd*/
  }
  if ( BYTE4(a10) != 0 ) /*0x1068d3d36*/
    v29 = (__m128)(unsigned int)a10; /*0x1068d3d42*/
  else
    v29 = (__m128)0x42800000u; /*0x1068d3d38*/
  v29.f32[0] = fmaxf(v29.f32[0], a8); /*0x1068d3d46*/
  v86 = v17.f32[0]; /*0x1068d3d55*/
  v88 = v26; /*0x1068d3d5c*/
  if ( DFFlag::PathPrefetchUnifiedWalk == 1 ) /*0x1068d3d64*/
  {
    v30 = v29; /*0x1068d3d6d*/
    if ( DFInt::PathPrefetchSymmetricWalkMode != 0 ) /*0x1068d3d70*/
      v30 = (__m128)0x42800000u; /*0x1068d3d72*/
    if ( a14 != 0 ) /*0x1068d3d7e*/
      v30 = (__m128)HIDWORD(a13); /*0x1068d3d80*/
    v30.f32[0] = fmaxf(fminf(v30.f32[0], v29.f32[0]), 1.0); /*0x1068d3d89*/
    if ( BYTE4(a11) != 0 ) /*0x1068d3d95*/
      v108 = *(float *)&a11; /*0x1068d3dcd*/
    else
      v108 = v30.f32[0]; /*0x1068d3d97*/
    v92 = v30; /*0x1068d3ddd*/
    v29.f32[0] = (float)(v29.f32[0] * 4.0) / v30.f32[0]; /*0x1068d3de4*/
    v31 = _mm_or_ps(_mm_and_ps(*(__m128 *)&xmmword_108F246C0, v29), (__m128)xmmword_108F51160); /*0x1068d3df2*/
    v31.f32[0] = v31.f32[0] + v29.f32[0]; /*0x1068d3df9*/
    v32 = (int)_mm_round_ss((__m128)0LL, v31, 11).f32[0]; /*0x1068d3e06*/
    v33 = 32; /*0x1068d3e0d*/
    if ( v32 < 32 ) /*0x1068d3e12*/
      v33 = v32; /*0x1068d3e12*/
    v34 = 1; /*0x1068d3e18*/
    if ( v33 >= 2 ) /*0x1068d3e1d*/
      v34 = v33; /*0x1068d3e1d*/
    v104 = v34; /*0x1068d3e20*/
    goto LABEL_45; /*0x1068d3e26*/
  }
  if ( BYTE1(a13) == 1 ) /*0x1068d3da5*/
  {
    if ( BYTE4(a11) != 0 ) /*0x1068d3db5*/
      v108 = *(float *)&a11; /*0x1068d3e40*/
    else
      v108 = v29.f32[0]; /*0x1068d3dbb*/
    v104 = 4; /*0x1068d3e48*/
    if ( (_BYTE)a13 != 1 ) /*0x1068d3e55*/
      goto LABEL_44; /*0x1068d3e55*/
  }
  else
  {
    if ( BYTE4(a11) != 0 ) /*0x1068d3e2f*/
      v108 = *(float *)&a11; /*0x1068d3e61*/
    else
      v108 = v29.f32[0]; /*0x1068d3e31*/
    if ( DFInt::PathPrefetchSymmetricWalkMode == 0 ) /*0x1068d3e70*/
    {
      v104 = 4; /*0x1068d3ee1*/
LABEL_44:
      v92 = v29; /*0x1068d3eeb*/
      goto LABEL_45; /*0x1068d3eeb*/
    }
  }
  v35 = (__m128)0x42800000u; /*0x1068d3e72*/
  v35.f32[0] = fmaxf(fminf(64.0, v29.f32[0]), 1.0); /*0x1068d3e7e*/
  v29.f32[0] = (float)(v29.f32[0] * 4.0) / v35.f32[0]; /*0x1068d3e8e*/
  v36 = _mm_or_ps(_mm_and_ps(*(__m128 *)&xmmword_108F246C0, v29), (__m128)xmmword_108F51160); /*0x1068d3e9c*/
  v36.f32[0] = v36.f32[0] + v29.f32[0]; /*0x1068d3ea3*/
  v37 = (int)_mm_round_ss((__m128)0LL, v36, 11).f32[0]; /*0x1068d3eb0*/
  v38 = 32; /*0x1068d3eb7*/
  if ( v37 < 32 ) /*0x1068d3ebc*/
    v38 = v37; /*0x1068d3ebc*/
  v39 = 1; /*0x1068d3ec2*/
  if ( v38 >= 2 ) /*0x1068d3ec7*/
    v39 = v38; /*0x1068d3ec7*/
  v104 = v39; /*0x1068d3eca*/
  v108 = v35.f32[0]; /*0x1068d3ed0*/
  v92 = v35; /*0x1068d3ed8*/
LABEL_45:
  v109 = DFFlag::DebugPathPrefetchDisableForwardHemisphereGate; /*0x1068d3ef2*/
  v40 = &DFInt::PathPrefetchTurnConfidenceThresholdHundredths; /*0x1068d3f06*/
  if ( BYTE4(a12) != 0 ) /*0x1068d3f0d*/
    v40 = (int *)&a12; /*0x1068d3f0d*/
  v100 = *v40; /*0x1068d3f13*/
  v41 = RSL::Arena::getDefaultArena(this: a1); /*0x1068d3f19*/
  *(_OWORD *)a1 = 0; /*0x1068d3f28*/
  *((_QWORD *)a1 + 2) = 0; /*0x1068d3f2b*/
  *((_QWORD *)a1 + 3) = v41; /*0x1068d3f33*/
  std::vector<RBX::Network::PathPrefetchWalkResult,RSL::Detail::Allocator<RBX::Network::PathPrefetchWalkResult>>::reserve( /*0x1068d3f3a*/
    a1,
    a2: a4);
  v42 = a7; /*0x1068d3f41*/
  v43 = a6; /*0x1068d3f49*/
  if ( a4 > 0 ) /*0x1068d3f50*/
  {
    v44 = (__m128)0x3F800000u; /*0x1068d3f56*/
    v44.f32[0] = 1.0 / v88; /*0x1068d3f5e*/
    v45 = 0; /*0x1068d3f66*/
    v45.f32[0] = v86; /*0x1068d3f70*/
    v46 = _mm_mul_ps(_mm_moveldup_ps(v44), v45); /*0x1068d3f78*/
    v82 = -v46.f32[0]; /*0x1068d3f85*/
    v47 = v90; /*0x1068d3f8c*/
    v81 = _mm_moveldup_ps(v92); /*0x1068d3ff5*/
    v97 = 0; /*0x1068d3ffc*/
    v87 = v46; /*0x1068d4007*/
    v83 = v46; /*0x1068d400e*/
    v98 = v90.f32[0] * (float)(1.0 / v88); /*0x1068d4015*/
    v48 = 0; /*0x1068d401d*/
    v103 = 0; /*0x1068d4020*/
    v91 = v98; /*0x1068d402a*/
    v47.f32[0] = v98; /*0x1068d3f93*/
    v84 = v47; /*0x1068d4031*/
    do /*0x1068d403e*/
    {
      v49 = 0; /*0x1068d403e*/
      v50 = 0.0; /*0x1068d4043*/
      LOBYTE(v101) = 0; /*0x1068d4046*/
      do /*0x1068d4526*/
      {
        v94 = v50; /*0x1068d4050*/
        v51 = v42; /*0x1068d405b*/
        _mm_storel_ps(&v117, v83); /*0x1068d4066*/
        v118 = v98; /*0x1068d4072*/
        v119 = v84.f32[0]; /*0x1068d407e*/
        v120 = 0.0; /*0x1068d4083*/
        v121 = v82; /*0x1068d4091*/
        _mm_storel_ps( /*0x1068d40b3*/
          (double *)&v122,
          _mm_blend_ps(_mm_xor_ps(v84, *(__m128 *)&xmmword_108F246C0), (__m128)xmmword_108F47210, 14));
        *(float *)&v123 = -v82; /*0x1068d40b7*/
        v53 = v92; /*0x1068d40bc*/
        v52 = _mm_add_ps(_mm_mul_ps(v81, v83), v43); /*0x1068d40d1*/
        v53.f32[0] = (float)(v92.f32[0] * v98) + v42; /*0x1068d40d4*/
        _mm_storel_ps(&v111, v52); /*0x1068d40d9*/
        v112 = v53.f32[0]; /*0x1068d40e0*/
        v54 = (__m128)LODWORD(v108); /*0x1068d40f0*/
        v54.f32[0] = v108 * v84.f32[0]; /*0x1068d40f3*/
        inserted = _mm_insert_ps(v54, (__m128)COERCE_UNSIGNED_INT(v108 * 0.0), 16); /*0x1068d40f7*/
        v89 = v43; /*0x1068d410b*/
        _mm_storel_ps((double *)&v113, _mm_add_ps(inserted, v43)); /*0x1068d4115*/
        v114 = v42 + (float)(v108 * v82); /*0x1068d4124*/
        _mm_storel_ps((double *)&v115, _mm_sub_ps(v43, inserted)); /*0x1068d413a*/
        v116 = v42 - (float)(v108 * v82); /*0x1068d413e*/
        v106 = v49; /*0x1068d4143*/
        v96 = v97 | v49; /*0x1068d414f*/
        for ( i = 0; ; v53 = (__m128)*((unsigned int *)&v112 + 3 * i) ) /*0x1068d415c*/
        {
          v57 = (unsigned int)((int)_mm_round_ss(v52, v52, 9).f32[0] >> 6); /*0x1068d4189*/
          v58 = (unsigned int)((int)_mm_round_ss((__m128)0LL, (__m128)*((unsigned int *)&v111 + 3 * i + 1), 9).f32[0] >> 6); /*0x1068d418c*/
          v59 = (unsigned int)((int)_mm_round_ss(v53, v53, 9).f32[0] >> 6); /*0x1068d418f*/
          if ( a5 != 0 || (v103 & 1) == 0 || __PAIR64__(v58, v57) != v48 || (_DWORD)v59 != (_DWORD)v16 ) /*0x1068d41ef*/
            break; /*0x1068d41ef*/
          v110[i++] = -2.0; /*0x1068d41f1*/
          if ( i == 3 ) /*0x1068d4204*/
          {
            if ( v109 != 0 ) /*0x1068d420d*/
              goto LABEL_79; /*0x1068d420d*/
            goto LABEL_61; /*0x1068d420d*/
          }
LABEL_53:
          v52 = (__m128)*((unsigned int *)&v111 + 3 * i); /*0x1068d41c2*/
        }
        v110[i++] = std::function<float ()(RBX::Vector3int32,int)>::operator()( /*0x1068d41af*/
                      a1: a3,
                      a2: (v58 << 32) | v57,
                      a3: v59,
                      a4: 64);
        if ( i != 3 ) /*0x1068d41c0*/
          goto LABEL_53; /*0x1068d41c0*/
        if ( (v109 & 1 | (a5 != 0)) == 0 ) /*0x1068d421b*/
        {
LABEL_61:
          v60 = &v118; /*0x1068d421d*/
          for ( j = 0; j != 3; ++j ) /*0x1068d4221*/
          {
            if ( v110[j] > -2.0 ) /*0x1068d4233*/
            {
              v62 = _mm_mul_ps((__m128)*((unsigned __int64 *)v60 - 1), v87); /*0x1068d423a*/
              if ( (float)((float)(*v60 * v91) + _mm_hadd_ps(v62, v62).f32[0]) < -0.5 ) /*0x1068d4260*/
                v110[j] = -2.0; /*0x1068d4262*/
            }
            v60 += 3; /*0x1068d4270*/
          }
        }
        if ( v96 != 0 || a5 != 1 ) /*0x1068d4288*/
        {
LABEL_79:
          v71 = 0; /*0x1068d4350*/
          for ( k = 1; k != 3; ++k ) /*0x1068d4352*/
          {
            v67 = k; /*0x1068d436b*/
            if ( v110[k] <= v110[v71] ) /*0x1068d436d*/
              v67 = v71; /*0x1068d436f*/
            v71 = v67; /*0x1068d4374*/
          }
          if ( a5 == 0 && v67 != 0 ) /*0x1068d4387*/
          {
            v73 = fmaxf(v110[0], 0.0); /*0x1068d4395*/
            if ( DFFlag::PathPrefetchColdTurnFloor == 1 && v73 <= 0.0 && v100 > 0 ) /*0x1068d43b5*/
            {
              v74 = 10000; /*0x1068d43bd*/
              if ( (unsigned int)DFInt::PathPrefetchColdTurnMinDensityHundredths < 0x2710 ) /*0x1068d43c4*/
                v74 = DFInt::PathPrefetchColdTurnMinDensityHundredths; /*0x1068d43c4*/
              if ( DFInt::PathPrefetchColdTurnMinDensityHundredths <= 0 ) /*0x1068d43ce*/
                v74 = 0; /*0x1068d43ce*/
              if ( (float)(fmaxf(v110[v67], 0.0) * 10000.0) >= (float)v74 ) /*0x1068d43f4*/
                goto LABEL_99; /*0x1068d43f4*/
            }
            else if ( v100 <= 0 || v73 <= 0.0 || (float)((float)(v110[v67] - v73) / v73) >= (float)((float)v100 / 100.0) ) /*0x1068d4430*/
            {
              goto LABEL_99; /*0x1068d4430*/
            }
            v67 = 0; /*0x1068d4432*/
          }
        }
        else
        {
          v63 = 0; /*0x1068d4293*/
          for ( m = 1; m != 3; ++m ) /*0x1068d4295*/
          {
            v65 = m; /*0x1068d42ae*/
            if ( v110[m] <= v110[v63] ) /*0x1068d42b0*/
              v65 = v63; /*0x1068d42b2*/
            v63 = v65; /*0x1068d42b7*/
          }
          v66 = 0; /*0x1068d42c1*/
          v67 = 0; /*0x1068d42c3*/
          v68 = (__m128)0xC0000000; /*0x1068d42c5*/
          do /*0x1068d42ec*/
          {
            if ( v65 != v66 && v110[v66] > v68.f32[0] ) /*0x1068d42de*/
            {
              v68 = (__m128)LODWORD(v110[v66]); /*0x1068d42e0*/
              v67 = v66; /*0x1068d42e3*/
            }
            ++v66; /*0x1068d42e5*/
          }
          while ( v66 != 3 ); /*0x1068d42ec*/
          v69 = v110[v65]; /*0x1068d42f1*/
          if ( v69 <= 0.0 || v68.f32[0] <= 0.0 ) /*0x1068d4309*/
          {
            LOBYTE(v101) = 0; /*0x1068d43f8*/
          }
          else
          {
            v68.f32[0] = (float)(v68.f32[0] / v69) * 100.0; /*0x1068d431b*/
            v70 = _mm_or_ps(_mm_and_ps(v68, *(__m128 *)&xmmword_108F246C0), (__m128)xmmword_108F51160); /*0x1068d4329*/
            v70.f32[0] = v70.f32[0] + v68.f32[0]; /*0x1068d4330*/
            v101 = (int)fminf(_mm_round_ss((__m128)0LL, v70, 11).f32[0], 100.0); /*0x1068d4345*/
          }
        }
LABEL_99:
        v75 = v103; /*0x1068d4434*/
        if ( (v103 & 1) == 0 ) /*0x1068d4447*/
          v75 = 1; /*0x1068d4447*/
        v103 = v75; /*0x1068d444a*/
        v43 = (__m128)*(unsigned __int64 *)((char *)&v111 + 12 * v67); /*0x1068d4468*/
        v42 = *(&v112 + 3 * v67); /*0x1068d4471*/
        v76 = (__m128)*(unsigned __int64 *)((char *)&v117 + 12 * v67); /*0x1068d447a*/
        v77 = *((_DWORD *)&v118 + 3 * v67); /*0x1068d4480*/
        if ( a5 != 0 ) /*0x1068d4489*/
        {
          v78 = v106; /*0x1068d44be*/
        }
        else
        {
          v78 = v106; /*0x1068d448d*/
          if ( v67 != 0 ) /*0x1068d4493*/
          {
            v82 = -v76.f32[0]; /*0x1068d449f*/
            v84 = (__m128)*((unsigned int *)&v118 + 3 * v67); /*0x1068d44a6*/
            v98 = *(&v118 + 3 * v67); /*0x1068d44ad*/
            v83 = (__m128)*(unsigned __int64 *)((char *)&v117 + 12 * v67); /*0x1068d44b5*/
          }
        }
        v79 = _mm_movehdup_ps(v89); /*0x1068d44d9*/
        LODWORD(v16) = (int)_mm_round_ss((__m128)0LL, (__m128)LODWORD(v51), 9).f32[0] >> 6; /*0x1068d4500*/
        v48 = ((unsigned __int64)(unsigned int)((int)_mm_round_ss(v79, v79, 9).f32[0] >> 6) << 32) /*0x1068d4508*/
            | (unsigned int)((int)_mm_round_ss((__m128)0LL, v89, 9).f32[0] >> 6);
        v80 = fmaxf(0.0, v110[v67]); /*0x1068d450e*/
        v50 = v94 + v80; /*0x1068d451a*/
        v49 = v78 + 1; /*0x1068d451e*/
      }
      while ( v49 != v104 ); /*0x1068d4526*/
      v95 = (__m128)*(unsigned __int64 *)((char *)&v111 + 12 * v67); /*0x1068d452c*/
      _mm_storel_ps(&v117, v43); /*0x1068d4533*/
      v107 = v42; /*0x1068d4537*/
      v118 = v42; /*0x1068d453f*/
      v119 = v50 / (float)v104; /*0x1068d454c*/
      v120 = v80; /*0x1068d4551*/
      LOBYTE(v121) = v101; /*0x1068d455c*/
      _mm_storel_ps((double *)&v122, v76); /*0x1068d455f*/
      v123 = v77; /*0x1068d4563*/
      std::vector<RBX::Network::PathPrefetchWalkResult,RSL::Detail::Allocator<RBX::Network::PathPrefetchWalkResult>>::push_back[abi:ne200100]( /*0x1068d4573*/
        a1,
        a2: &v117);
      ++v97; /*0x1068d4587*/
      v42 = v107; /*0x1068d4590*/
      v43 = v95; /*0x1068d4598*/
    }
    while ( v97 != a4 ); /*0x1068d403e*/
  }
  return a1; /*0x1068d3d1c*/
}

// Address: 0x1068d482b | Name: __ZN3RBX7Network22pathPrefetchGreedyWalkENS_7Vector3ERKS1_fRKNS_19HeatmapQueryServiceEiNS0_8WalkRankENS0_25PathPrefetchWalkOverridesEi
RBX::Math *__fastcall RBX::Network::pathPrefetchGreedyWalk(
        RBX::Math *a1,
        unsigned int *a2,
        __int64 a3,
        int a4,
        char a5,
        __int64 a6,
        __m128 a7,
        float a8,
        float a9,
        __int128 a10,
        __int128 a11,
        char a12)
{
  __int64 v13; // rax
  int v15; // [rsp+2Ch] [rbp-54h] BYREF
  _QWORD v16[4]; // [rsp+30h] [rbp-50h] BYREF
  _QWORD *v17; // [rsp+50h] [rbp-30h]

  v15 = a6; /*0x1068d484b*/
  v16[0] = off_10CAB18B8; /*0x1068d4859*/
  v16[1] = a3; /*0x1068d485c*/
  v16[2] = &v15; /*0x1068d4860*/
  v17 = v16; /*0x1068d4864*/
  RBX::Network::pathPrefetchGreedyWalk( /*0x1068d4886*/
    a1,
    a2,
    a3: (__int64)v16,
    a4,
    a5,
    a6: a7,
    a7: a8,
    a8: a9,
    a9: a6,
    a10,
    a11: *((__int64 *)&a10 + 1),
    a12: a11,
    a13: *((__int64 *)&a11 + 1),
    a14: a12);
  if ( v17 == v16 ) /*0x1068d4892*/
  {
    v13 = 32; /*0x1068d48a0*/
  }
  else
  {
    v13 = 40; /*0x1068d4894*/
    if ( v17 == nullptr ) /*0x1068d489c*/
      return a1; /*0x1068d489c*/
  }
  (*(void (**)(void))(*v17 + v13))(); /*0x1068d48a8*/
  return a1; /*0x1068d48be*/
}

// Address: 0x1068d48f5 | Name: __ZN3RBX7Network26pathPrefetchResolveYWindowENSt3__18optionalIiEE
__int64 __fastcall RBX::Network::pathPrefetchResolveYWindow(__int64 a1)
{
  __int64 result; // rax

  result = a1; /*0x1068d48f9*/
  if ( (a1 & 0x100000000LL) == 0 ) /*0x1068d4901*/
  {
    result = (unsigned int)DFInt::PathPrefetchHeatmapYWindowRegions; /*0x1068d4903*/
    if ( DFInt::PathPrefetchHeatmapYWindowRegions < 0 ) /*0x1068d490b*/
      return (unsigned int)(DFInt::PathPrefetchDistanceStuds / 64); /*0x1068d491b*/
  }
  return result; /*0x1068d491e*/
}

// Address: 0x106934c73 | Name: __ZN3RBX7Network29getPredictiveStreamingEnabledEPKNS_9WorkspaceE
bool __fastcall RBX::Network::getPredictiveStreamingEnabled(RBX::Network *this, const RBX::Workspace *a2)
{
  bool result; // al

  result = true; /*0x106934c73*/
  if ( DFFlag::DebugForcePredictiveStreamingEnabled == 0 ) /*0x106934c7c*/
  {
    result = false; /*0x106934c7e*/
    if ( this != nullptr && DFFlag::PredictiveStreamingModeAPIEnabled != 0 ) /*0x106934c93*/
      return *((_DWORD *)this + 307) == 1; /*0x106934c9c*/
  }
  return result; /*0x106934ca0*/
}

// Address: 0x106934ca1 | Name: __ZN3RBX7Network29getPredictiveStreamingEnabledEPKNS0_10ReplicatorE
bool __fastcall RBX::Network::getPredictiveStreamingEnabled(RBX::Network *this, const RBX::Network::Replicator *a2)
{
  __int64 v2; // rcx
  bool result; // al

  v2 = RBX::ServiceProvider::find<RBX::Workspace>(a1: this); /*0x106934caa*/
  result = true; /*0x106934cad*/
  if ( DFFlag::DebugForcePredictiveStreamingEnabled == 0 ) /*0x106934cb6*/
  {
    result = false; /*0x106934cb8*/
    if ( v2 != 0 && DFFlag::PredictiveStreamingModeAPIEnabled != 0 ) /*0x106934cc9*/
      return *(_DWORD *)(v2 + 1228) == 1; /*0x106934cd2*/
  }
  return result; /*0x106934cd5*/
}

// Address: 0x1069354da | Name: __ZN3RBX7Network14getFingerprintERKNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::getFingerprint(RBX::Network *this, const RBX::Network::NetworkStream *a2)
{
  __int64 v3; // r14
  unsigned int v4; // eax
  char *v5; // rsi
  __int64 v6; // rdx
  void *v7; // rsi
  RBX::Memory *v8; // rbx
  void *v9; // rsi
  unsigned __int8 v11; // [rsp+0h] [rbp-60h] BYREF
  _BYTE __src[7]; // [rsp+1h] [rbp-5Fh] BYREF
  size_t __n; // [rsp+8h] [rbp-58h]
  void *v14; // [rsp+10h] [rbp-50h]
  unsigned __int8 v15; // [rsp+18h] [rbp-48h] BYREF
  char v16; // [rsp+19h] [rbp-47h] BYREF
  __int64 v17; // [rsp+20h] [rbp-40h]
  void *v18; // [rsp+28h] [rbp-38h]
  _QWORD __dst[2]; // [rsp+30h] [rbp-30h] BYREF

  *(_OWORD *)__dst = RBX::Network::EmptyFingerprintData; /*0x1069354fd*/
  v3 = (*(__int64 (__fastcall **)(RBX::Network *, const RBX::Network::NetworkStream *))(*(_QWORD *)this + 16LL))( /*0x106935507*/
         a1: this,
         a2);
  v4 = (*(__int64 (__fastcall **)(RBX::Network *))(*(_QWORD *)this + 24LL))(a1: this); /*0x106935510*/
  std::string::basic_string[abi:ne200100](a1: &v15, a2: v3, a3: v4); /*0x10693551c*/
  if ( (v15 & 1) != 0 ) /*0x106935528*/
  {
    v5 = (char *)v18; /*0x10693552a*/
    v6 = v17; /*0x10693552e*/
  }
  else
  {
    v6 = v15 >> 1; /*0x106935534*/
    v5 = &v16; /*0x106935536*/
  }
  RBX::Crypto::blake3(a1: &v11, a2: v5, a3: v6, a4: 16); /*0x106935543*/
  if ( (v11 & 1) != 0 ) /*0x10693554f*/
  {
    v8 = (RBX::Memory *)v14; /*0x106935566*/
    memcpy(__dst, __src: v14, __n); /*0x106935571*/
    operator delete(a1: v8, a2: v9); /*0x106935579*/
  }
  else
  {
    memcpy(__dst, __src, __n: v11 >> 1); /*0x10693555b*/
  }
  if ( (v15 & 1) != 0 ) /*0x106935582*/
    operator delete(a1: (RBX::Memory *)v18, a2: v7); /*0x106935588*/
  return __dst[0]; /*0x1069355a5*/
}

// Address: 0x1069381ec | Name: __ZN3RBX7Network20StreamingMetric_NameENS0_20StreamingMetricFieldE
char *__fastcall RBX::Network::StreamingMetric_Name(char a1)
{
  return (char *)dword_109A09F94 + dword_109A09F94[a1]; /*0x106938202*/
}

// Address: 0x106957d86 | Name: __ZN3RBX7Network13joinContainerINS_13SmallDenseSetIjLj4ENS_12DenseMapInfoIjvEEEEEENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEERKT_
__int64 __fastcall RBX::Network::joinContainer<RBX::SmallDenseSet<unsigned int,4u,RBX::DenseMapInfo<unsigned int,void>>>(
        __int64 a1,
        __int64 a2)
{
  _DWORD *v3; // rdx
  _DWORD *v4; // r15
  __int64 v5; // rax
  _DWORD *v6; // r12
  __int64 v7; // rax
  const char *v8; // rsi
  __int64 v9; // rax
  __int64 v10; // rax
  void *v11; // rsi
  __int64 (__fastcall **v13)(); // [rsp+8h] [rbp-138h] BYREF
  __int64 (__fastcall **v14)(); // [rsp+10h] [rbp-130h] BYREF
  _BYTE v15[72]; // [rsp+18h] [rbp-128h] BYREF
  void *v16; // [rsp+60h] [rbp-E0h]
  __int64 (__fastcall **v17)(); // [rsp+78h] [rbp-C8h] BYREF
  __int64 v18; // [rsp+110h] [rbp-30h]

  v18 = a1; /*0x106957d9d*/
  std::ostringstream::basic_ostringstream[abi:ne200100](a1: &v13); /*0x106957da8*/
  v4 = (_DWORD *)RBX::detail::DenseSetImpl<unsigned int,RBX::SmallDenseMap<unsigned int,RBX::detail::DenseSetEmpty,4u,RBX::DenseMapInfo<unsigned int,void>,RBX::detail::DenseSetPair<unsigned int>>,RBX::DenseMapInfo<unsigned int,void>>::begin(a1: a2); /*0x106957db5*/
  v5 = *(_QWORD *)(a2 + 8) + 4LL * *(unsigned int *)(a2 + 16); /*0x106957dc0*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x106957dcc*/
    v5 = a2 + 24; /*0x106957dcc*/
  if ( v4 != (_DWORD *)v5 ) /*0x106957dd3*/
  {
    v6 = v3; /*0x106957dd5*/
    do /*0x106957e3a*/
    {
      v7 = RBX::detail::DenseSetImpl<unsigned int,RBX::SmallDenseMap<unsigned int,RBX::detail::DenseSetEmpty,4u,RBX::DenseMapInfo<unsigned int,void>,RBX::detail::DenseSetPair<unsigned int>>,RBX::DenseMapInfo<unsigned int,void>>::begin(a1: a2); /*0x106957de2*/
      v8 = ""; /*0x106957def*/
      if ( v4 != (_DWORD *)v7 ) /*0x106957dfd*/
        v8 = ","; /*0x106957dfd*/
      v9 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>( /*0x106957e04*/
             a1: &v13,
             a2: v8,
             a3: v4 != (_DWORD *)v7);
      std::ostream::operator<<(a1: v9, a2: (unsigned int)*v4); /*0x106957e0f*/
      do /*0x106957e21*/
        ++v4; /*0x106957e14*/
      while ( v4 != v6 && *v4 >= 0xFFFFFFFE ); /*0x106957e21*/
      v10 = *(_QWORD *)(a2 + 8) + 4LL * *(unsigned int *)(a2 + 16); /*0x106957e2b*/
      if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x106957e33*/
        v10 = a2 + 24; /*0x106957e33*/
    }
    while ( v4 != (_DWORD *)v10 ); /*0x106957e3a*/
  }
  std::stringbuf::str(a1: v18, a2: &v14); /*0x106957e47*/
  v13 = &off_10C449768; /*0x106957e5e*/
  v17 = off_10C449790; /*0x106957e66*/
  v14 = &off_10C799250; /*0x106957e74*/
  if ( (v15[56] & 1) != 0 ) /*0x106957e7d*/
    operator delete(a1: (RBX::Memory *)v16, a2: v11); /*0x106957e86*/
  v14 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x106957e9d*/
  std::locale::~locale(this: (std::locale *)v15); /*0x106957ea1*/
  std::ostream::~ostream(a1: &v13, a2: off_10C4497A8); /*0x106957eb8*/
  std::ios::~ios(a1: &v17); /*0x106957ec0*/
  return v18; /*0x106957ec9*/
}

// Address: 0x106957ef6 | Name: __ZN3RBX7Network13joinContainerIN3RSL9ArrayViewIPNS0_14NetworkObjects5GroupEEEEENSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEERKT_
__int64 __fastcall RBX::Network::joinContainer<RSL::ArrayView<RBX::Network::NetworkObjects::Group *>>(
        __int64 a1,
        RBX::Network::NetworkObjects::Group ***a2)
{
  RBX::Network::NetworkObjects::Group **v3; // rax
  RBX::Network::NetworkObjects::Group **v4; // rbx
  const char *v5; // rsi
  __int64 v6; // rax
  __int64 v7; // rbx
  void *v8; // rsi
  __int64 (__fastcall **v10)(); // [rsp+8h] [rbp-138h] BYREF
  __int64 (__fastcall **v11)(); // [rsp+10h] [rbp-130h] BYREF
  _BYTE v12[72]; // [rsp+18h] [rbp-128h] BYREF
  void *v13; // [rsp+60h] [rbp-E0h]
  __int64 (__fastcall **v14)(); // [rsp+78h] [rbp-C8h] BYREF
  __int64 v15; // [rsp+110h] [rbp-30h]

  v15 = a1; /*0x106957f0d*/
  std::ostringstream::basic_ostringstream[abi:ne200100](a1: &v10); /*0x106957f18*/
  if ( a2[1] != nullptr ) /*0x106957f22*/
  {
    v3 = *a2; /*0x106957f24*/
    v4 = *a2; /*0x106957f3c*/
    do /*0x106957f73*/
    {
      v5 = ""; /*0x106957f47*/
      if ( v4 != v3 ) /*0x106957f4a*/
        v5 = ","; /*0x106957f4a*/
      v6 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &v10, a2: v5, a3: v4 != v3); /*0x106957f51*/
      RBX::Network::operator<<(a1: v6, a2: *v4++); /*0x106957f5c*/
      v3 = *a2; /*0x106957f65*/
    }
    while ( v4 != &(*a2)[(_QWORD)a2[1]] ); /*0x106957f73*/
  }
  v7 = v15; /*0x106957f7c*/
  std::stringbuf::str(a1: v15, a2: &v11); /*0x106957f83*/
  v10 = &off_10C449768; /*0x106957f9a*/
  v14 = off_10C449790; /*0x106957fa2*/
  v11 = &off_10C799250; /*0x106957fb0*/
  if ( (v12[56] & 1) != 0 ) /*0x106957fb9*/
    operator delete(a1: (RBX::Memory *)v13, a2: v8); /*0x106957fc2*/
  v11 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x106957fd9*/
  std::locale::~locale(this: (std::locale *)v12); /*0x106957fdd*/
  std::ostream::~ostream(a1: &v10, a2: off_10C4497A8); /*0x106957ff4*/
  std::ios::~ios(a1: &v14); /*0x106957ffc*/
  return v7; /*0x106958004*/
}

// Address: 0x10695802f | Name: __ZN3RBX7Network13joinContainerINS_11SmallVectorIPNS0_13NetworkObjectELj1EEEEENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEERKT_
__int64 __fastcall RBX::Network::joinContainer<RBX::SmallVector<RBX::Network::NetworkObject *,1u>>(
        __int64 a1,
        __int64 a2)
{
  _QWORD *v3; // rax
  _QWORD *v4; // rbx
  const char *v5; // rsi
  __int64 v6; // rax
  __int64 v7; // rbx
  void *v8; // rsi
  __int64 (__fastcall **v10)(); // [rsp+8h] [rbp-138h] BYREF
  __int64 (__fastcall **v11)(); // [rsp+10h] [rbp-130h] BYREF
  _BYTE v12[72]; // [rsp+18h] [rbp-128h] BYREF
  void *v13; // [rsp+60h] [rbp-E0h]
  __int64 (__fastcall **v14)(); // [rsp+78h] [rbp-C8h] BYREF
  __int64 v15; // [rsp+110h] [rbp-30h]

  v15 = a1; /*0x106958046*/
  std::ostringstream::basic_ostringstream[abi:ne200100](a1: &v10); /*0x106958051*/
  if ( *(_DWORD *)(a2 + 8) != 0 ) /*0x10695805b*/
  {
    v3 = *(_QWORD **)a2; /*0x10695805d*/
    v4 = *(_QWORD **)a2; /*0x106958075*/
    do /*0x1069580ac*/
    {
      v5 = ""; /*0x106958080*/
      if ( v4 != v3 ) /*0x106958083*/
        v5 = ","; /*0x106958083*/
      v6 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &v10, a2: v5, a3: v4 != v3); /*0x10695808a*/
      std::ostream::operator<<(a1: v6, a2: *v4++); /*0x106958095*/
      v3 = *(_QWORD **)a2; /*0x10695809e*/
    }
    while ( v4 != (_QWORD *)(*(_QWORD *)a2 + 8LL * *(unsigned int *)(a2 + 8)) ); /*0x1069580ac*/
  }
  v7 = v15; /*0x1069580b5*/
  std::stringbuf::str(a1: v15, a2: &v11); /*0x1069580bc*/
  v10 = &off_10C449768; /*0x1069580d3*/
  v14 = off_10C449790; /*0x1069580db*/
  v11 = &off_10C799250; /*0x1069580e9*/
  if ( (v12[56] & 1) != 0 ) /*0x1069580f2*/
    operator delete(a1: (RBX::Memory *)v13, a2: v8); /*0x1069580fb*/
  v11 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x106958112*/
  std::locale::~locale(this: (std::locale *)v12); /*0x106958116*/
  std::ostream::~ostream(a1: &v10, a2: off_10C4497A8); /*0x10695812d*/
  std::ios::~ios(a1: &v14); /*0x106958135*/
  return v7; /*0x10695813d*/
}

// Address: 0x1069583d4 | Name: __ZNK3RBX7Network10SetExtentseqERKS1_
char __fastcall RBX::Network::SetExtents::operator==(__int64 a1, __int64 a2)
{
  __int64 v4; // rbx
  __int64 v5; // r12
  __int64 v6; // r14
  char result; // al

  if ( (unsigned __int8)((__int64 (*)(void))RBX::StreamRegion::IdExtents::operator==)() == 0 ) /*0x1069583ec*/
    return 0; /*0x1069583ec*/
  v4 = *(_QWORD *)(a1 + 24); /*0x1069583ee*/
  v5 = *(_QWORD *)(a1 + 32); /*0x1069583f2*/
  v6 = *(_QWORD *)(a2 + 24); /*0x1069583fc*/
  if ( v5 - v4 != *(_QWORD *)(a2 + 32) - v6 ) /*0x10695840a*/
    return 0; /*0x10695842f*/
  if ( v4 == v5 ) /*0x10695840f*/
    return 1; /*0x10695843a*/
  do /*0x10695842b*/
  {
    result = RBX::StreamRegion::IdExtents::operator==(a1: v4, a2: v6); /*0x106958417*/
    if ( result == 0 ) /*0x10695841e*/
      break; /*0x10695841e*/
    v4 += 24; /*0x106958420*/
    v6 += 24; /*0x106958424*/
  }
  while ( v4 != v5 ); /*0x10695842b*/
  return result; /*0x106958431*/
}

// Address: 0x10695e56b | Name: __ZN3RBX7Network17SetStateFlagsNameENS0_13SetStateFlagsE
const char *__fastcall RBX::Network::SetStateFlagsName(int a1)
{
  const char *result; // rax

  if ( a1 <= 15 ) /*0x10695e577*/
  {
    switch ( a1 ) /*0x10695e5a9*/
    {
      case 0: /*0x10695e5a9*/
        result = "None"; /*0x10695e5ab*/
        break; /*0x10695e5b2*/
      case 1: /*0x10695e5a9*/
        result = "FullyNonReplicable"; /*0x10695e612*/
        break; /*0x10695e61e*/
      case 2: /*0x10695e5a9*/
        result = "Persistent"; /*0x10695e5e8*/
        break; /*0x10695e5e8*/
      case 3: /*0x10695e5a9*/
      case 5: /*0x10695e5a9*/
      case 6: /*0x10695e5a9*/
      case 7: /*0x10695e5a9*/
        BUG(); /*0x10695e62e*/
      case 4: /*0x10695e5a9*/
        result = "NonSpatial"; /*0x10695e5cd*/
        break; /*0x10695e5d4*/
      case 8: /*0x10695e5a9*/
        result = "Required"; /*0x10695e620*/
        break; /*0x10695e620*/
    }
  }
  else if ( a1 > 127 ) /*0x10695e57c*/
  {
    if ( a1 == 128 ) /*0x10695e5ba*/
    {
      return "SentInJoin"; /*0x10695e5df*/
    }
    else if ( a1 == 256 ) /*0x10695e5c2*/
    {
      return "Excluded"; /*0x10695e5c4*/
    }
    else
    {
      return "UnderReplicatedStorage"; /*0x10695e604*/
    }
  }
  else if ( a1 == 16 ) /*0x10695e581*/
  {
    return "GCed"; /*0x10695e5d6*/
  }
  else if ( a1 == 32 ) /*0x10695e586*/
  {
    return "Pinned"; /*0x10695e588*/
  }
  else
  {
    return "FakePersistent"; /*0x10695e5f6*/
  }
  return result; /*0x10695e62c*/
}

// Address: 0x106969e57 | Name: __ZN3RBX7NetworkL27filterAddTopContainerConfigERKNS0_13NetworkSchemaERNSt3__16vectorINS0_29TopReplicationContainerConfigENS4_9allocatorIS6_EEEEPNS_8InstanceEbb
void __fastcall RBX::Network::filterAddTopContainerConfig(__int64 a1, __int64 a2, __int64 a3, char a4, char a5)
{
  __int64 v9; // rax
  int v10; // r8d
  int v11; // r9d
  __int64 v12; // r13
  unsigned __int64 v13; // rdx
  unsigned __int64 v14; // rcx
  unsigned __int64 v15; // r14
  __int64 v16; // rcx
  __int64 v17; // rax
  RBX::Memory *v18; // rsi
  signed __int64 v19; // rdx
  unsigned __int64 v20; // r15
  unsigned __int64 v21; // rdi
  unsigned __int64 v22; // rcx
  __int64 v23; // rax
  __int64 v24; // rdx
  __int64 v25; // rcx
  unsigned __int64 v26; // r15
  void *v27; // r15
  void *v28; // rsi
  RBX::Memory *v29; // rdi
  __int64 v30; // [rsp+8h] [rbp-38h]
  char v31; // [rsp+14h] [rbp-2Ch]

  if ( a3 != 0 )
  {
    v9 = RBX::detail::DenseHashTable<RBX::Reflection::ClassDescriptor const*,std::pair<RBX::Reflection::ClassDescriptor const*,unsigned short>,std::pair<RBX::Reflection::ClassDescriptor const* const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::ClassDescriptor const*,unsigned short>,RBX::Hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>::find(a1: a1 + 64); /*0x106969e8c*/
    if ( v9 != 0 )
    {
      v12 = v9; /*0x106969e96*/
      v13 = *(_QWORD *)(a2 + 8); /*0x106969e99*/
      v14 = *(_QWORD *)(a2 + 16); /*0x106969e9d*/
      if ( v13 >= v14 ) /*0x106969ea4*/
      {
        v31 = a5; /*0x106969f07*/
        v17 = 0xAAAAAAAAAAAAAAALL; /*0x106969f0b*/
        v18 = *(RBX::Memory **)a2; /*0x106969f15*/
        v19 = v13 - *(_QWORD *)a2; /*0x106969f18*/
        v20 = 0xAAAAAAAAAAAAAAABLL * (v19 >> 3); /*0x106969f2c*/
        v21 = v20 + 1; /*0x106969f30*/
        if ( v20 + 1 > 0xAAAAAAAAAAAAAAALL ) /*0x106969f37*/
          std::vector<RBX::Network::TopReplicationContainerConfig>::__throw_length_error[abi:ne200100](a1: v21); /*0x10696a00a*/
        v22 = 0xAAAAAAAAAAAAAAABLL * ((__int64)(v14 - (_QWORD)v18) >> 3); /*0x106969f44*/
        if ( 2 * v22 > v21 ) /*0x106969f4f*/
          v21 = 2 * v22; /*0x106969f4f*/
        if ( v22 < 0x555555555555555LL ) /*0x106969f60*/
          v17 = v21; /*0x106969f60*/
        if ( v17 != 0 ) /*0x106969f67*/
        {
          v23 = std::__allocate_at_least[abi:ne200100]<std::allocator<RBX::Network::TopReplicationContainerConfig>>( /*0x106969f70*/
                  a1: a2 + 16,
                  a2: v17);
          v25 = v24; /*0x106969f75*/
          v18 = *(RBX::Memory **)a2; /*0x106969f78*/
          v19 = *(_QWORD *)(a2 + 8) - *(_QWORD *)a2; /*0x106969f7f*/
        }
        else
        {
          v23 = 0; /*0x106969f84*/
          v25 = 0; /*0x106969f86*/
        }
        v26 = v23 + 24 * v20; /*0x106969f8c*/
        v30 = v23 + 24 * v25; /*0x106969f98*/
        *(_WORD *)v26 = *(_WORD *)(v12 + 8); /*0x106969fa1*/
        *(_QWORD *)(v26 + 8) = a3; /*0x106969fa5*/
        *(_BYTE *)(v26 + 16) = a4; /*0x106969fa9*/
        *(_BYTE *)(v26 + 17) = v31; /*0x106969fb0*/
        v15 = v26 + 24; /*0x106969fb8*/
        v27 = (void *)(v26 - v19); /*0x106969fbc*/
        memcpy(__dst: v27, __src: v18, __n: v19); /*0x106969fc2*/
        v29 = *(RBX::Memory **)a2; /*0x106969fc7*/
        *(_QWORD *)a2 = v27; /*0x106969fca*/
        *(_QWORD *)(a2 + 8) = v15; /*0x106969fcd*/
        *(_QWORD *)(a2 + 16) = v30; /*0x106969fd5*/
        if ( v29 != nullptr ) /*0x106969fdc*/
          operator delete(a1: v29, a2: v28); /*0x106969fde*/
      }
      else
      {
        *(_WORD *)v13 = *(_WORD *)(v9 + 8); /*0x106969eab*/
        *(_QWORD *)(v13 + 8) = a3; /*0x106969eae*/
        *(_BYTE *)(v13 + 16) = a4; /*0x106969eb2*/
        *(_BYTE *)(v13 + 17) = a5; /*0x106969eb6*/
        v15 = v13 + 24; /*0x106969ebe*/
      }
      *(_QWORD *)(a2 + 8) = v15; /*0x106969fe3*/
    }
    else if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
    {
      v16 = *(_QWORD *)(*(_QWORD *)(a3 + 24) + 8LL); /*0x106969ef2*/
      if ( (*(_BYTE *)v16 & 1) != 0 ) /*0x106969ef9*/
        v16 = *(_QWORD *)(v16 + 16); /*0x106969fe9*/
      else
        LODWORD(v16) = v16 + 1; /*0x106969eff*/
      FLog::FastLogFormatted(
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: (unsigned int)"[FLog::Network] WARNING: Skipping top replication container '%s' because it is not in the network schema",
        a4: v16,
        a5: v10,
        a6: v11);
    }
  }
}

// Address: 0x10696efa2 | Name: __ZN3RBX7Network21RakNetAddressToStringERKN6RakNet13SystemAddressEbc
RBX::Network *__fastcall RBX::Network::RakNetAddressToString(
        RBX::Network *this,
        const RakNet::SystemAddress *a2,
        bool a3,
        char a4)
{
  __int64 v5; // rdx
  __int64 v6; // rcx
  char v8[1032]; // [rsp+0h] [rbp-420h] BYREF

  RakNet::SystemAddress::ToStringN(this: a2, a2: a3, a3: v8, a4: 1025, a5: a4); /*0x10696efd8*/
  std::string::basic_string[abi:ne200100]<0>(a1: this, a2: v8, a3: v5, a4: v6); /*0x10696efe3*/
  return this; /*0x10696effb*/
}

// Address: 0x10696f00c | Name: __ZN3RBX7Network15getPairIntValueERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_S9_
__int64 __fastcall RBX::Network::getPairIntValue(unsigned __int8 *a1, unsigned __int8 *a2, __int64 a3)
{
  unsigned int v5; // eax
  __int64 v6; // rax
  unsigned int v7; // r14d
  unsigned int v8; // eax
  __int64 v9; // rax
  const char *v10; // r15
  void *v11; // rsi
  __int64 v12; // r15
  unsigned int v13; // r13d
  size_t v14; // r13
  const void *v15; // rbx
  __int64 v16; // r12
  unsigned int v17; // eax
  __int64 v18; // rcx
  const void *v19; // rdi
  __int64 v20; // rax
  _QWORD v22[2]; // [rsp+10h] [rbp-70h] BYREF
  __int128 v23; // [rsp+20h] [rbp-60h] BYREF
  __int64 v24; // [rsp+30h] [rbp-50h]
  RBX::Memory *__dst[3]; // [rsp+38h] [rbp-48h] BYREF

  v5 = *a1; /*0x10696f034*/
  if ( (v5 & 1) != 0 ) /*0x10696f039*/
    v6 = *((_QWORD *)a1 + 1); /*0x10696f03b*/
  else
    v6 = v5 >> 1; /*0x10696f041*/
  v7 = -1; /*0x10696f043*/
  if ( v6 != 0 )
  {
    v8 = *a2; /*0x10696f052*/
    v9 = (v8 & 1) != 0 ? *((_QWORD *)a2 + 1) : v8 >> 1;
    if ( v9 != 0 )
    {
      if ( (*(_BYTE *)a3 & 1) != 0 ) /*0x10696f072*/
      {
        if ( *(_QWORD *)(a3 + 8) == 0 ) /*0x10696f095*/
          return v7; /*0x10696f095*/
        v23 = 0; /*0x10696f09e*/
        v24 = 0; /*0x10696f0a2*/
        v10 = *(const char **)(a3 + 16); /*0x10696f0aa*/
      }
      else
      {
        if ( *(_BYTE *)a3 == 0 ) /*0x10696f076*/
          return v7; /*0x10696f076*/
        v23 = 0; /*0x10696f07f*/
        v24 = 0; /*0x10696f083*/
        v10 = (const char *)(a3 + 1); /*0x10696f08b*/
      }
      v22[0] = v10; /*0x10696f0bd*/
      v22[1] = &v10[strlen(__s: v10)]; /*0x10696f0c0*/
      boost::algorithm::detail::is_any_ofF<char>::is_any_ofF<boost::iterator_range<char const*>>( /*0x10696f0c8*/
        (char *)__dst,
        a2: (__int64)v22);
      boost::algorithm::split<std::vector<std::string>,std::string const,boost::algorithm::detail::is_any_ofF<char>>( /*0x10696f0e0*/
        a1: (__int64)&v23,
        (__int64)a2,
        a3: __dst,
        a4: 1);
      if ( __dst[2] >= (RBX::Memory *)0x11 && __dst[0] != nullptr ) /*0x10696f0f3*/
        operator delete[](a1: __dst[0], a2: v11); /*0x10696f0f5*/
      v12 = *((_QWORD *)&v23 + 1); /*0x10696f0fe*/
      if ( ((BYTE8(v23) - (_BYTE)v23) & 8) == 0 && (_QWORD)v23 != *((_QWORD *)&v23 + 1) )
      {
        v13 = *a1; /*0x10696f11b*/
        if ( (v13 & 1) != 0 ) /*0x10696f123*/
        {
          v14 = *((_QWORD *)a1 + 1); /*0x10696f125*/
          v15 = *((const void **)a1 + 2); /*0x10696f129*/
        }
        else
        {
          v14 = v13 >> 1; /*0x10696f12f*/
          v15 = a1 + 1; /*0x10696f132*/
        }
        v16 = v23 + 25; /*0x10696f135*/
        while ( 1 )
        {
          v17 = *(unsigned __int8 *)(v16 - 25); /*0x10696f139*/
          v18 = (v17 & 1) != 0 ? *(_QWORD *)(v16 - 17) : v17 >> 1;
          if ( v18 == v14 )
          {
            v19 = (v17 & 1) != 0 ? *(const void **)(v16 - 9) : (const void *)(v16 - 24);
            if ( memcmp(__s1: v19, __s2: v15, __n: v14) == 0 ) /*0x10696f170*/
              break; /*0x10696f170*/
          }
          v20 = v16 - 25; /*0x10696f172*/
          v16 += 48; /*0x10696f177*/
          if ( v20 + 48 == v12 ) /*0x10696f182*/
            goto LABEL_36; /*0x10696f182*/
        }
        if ( (*(_BYTE *)(v16 - 1) & 1) != 0 ) /*0x10696f190*/
          v16 = *(_QWORD *)(v16 + 15); /*0x10696f192*/
        v7 = atoi(a1: (const char *)v16); /*0x10696f1a3*/
      }
LABEL_36:
      v22[0] = &v23; /*0x10696f1a6*/
      std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: v22); /*0x10696f1ad*/
    }
  }
  return v7; /*0x10696f1c5*/
}

// Address: 0x10696f211 | Name: __ZN3RBX7Network15getPairIntValueEiNS_10StringViewERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
__int64 __fastcall RBX::Network::getPairIntValue(int a1, void *a2, size_t a3, unsigned __int8 *a4)
{
  char v5; // al
  int v6; // r12d
  unsigned int v7; // r13d
  const void *v8; // rsi
  size_t v9; // r13
  size_t v10; // r14
  char *v11; // r15
  __int64 result; // rax
  unsigned int v13; // r13d
  const void *v14; // rsi
  size_t v15; // r13
  size_t v16; // r12
  char *v17; // r15
  void *__s2; // [rsp+0h] [rbp-50h]
  __int64 v20; // [rsp+10h] [rbp-40h] BYREF
  void *__s1; // [rsp+18h] [rbp-38h] BYREF
  size_t v22; // [rsp+20h] [rbp-30h]

  __s1 = a2; /*0x10696f225*/
  v22 = a3; /*0x10696f229*/
  if ( a3 != 0 )
  {
    __s2 = a4 + 1; /*0x10696f23d*/
    while ( 1 )
    {
      v5 = RBX::consumeSignedInteger(a1: (__int64)&__s1, a2: 0xAu, a3: &v20); /*0x10696f251*/
      v6 = (unsigned __int64)(v20 + 0x80000000LL) >> 32 != 0 ? -1 : v20;
      if ( v5 == 0 ) /*0x10696f27e*/
        v6 = -1; /*0x10696f27e*/
      v7 = *a4; /*0x10696f282*/
      if ( (v7 & 1) != 0 ) /*0x10696f28a*/
      {
        v8 = *((const void **)a4 + 2); /*0x10696f28c*/
        v9 = *((_QWORD *)a4 + 1); /*0x10696f290*/
      }
      else
      {
        v9 = v7 >> 1; /*0x10696f296*/
        v8 = __s2; /*0x10696f299*/
      }
      v10 = v22 - v9; /*0x10696f2a1*/
      if ( v22 >= v9 ) /*0x10696f2a4*/
      {
        v11 = (char *)__s1; /*0x10696f2a6*/
        if ( v9 == 0 || memcmp(__s1, __s2: v8, __n: v9) == 0 ) /*0x10696f2bc*/
        {
          __s1 = &v11[v9]; /*0x10696f2c1*/
          v22 = v10; /*0x10696f2c5*/
        }
      }
      if ( RBX::consumeSignedInteger(a1: (__int64)&__s1, a2: 0xAu, a3: &v20) == 0 ) /*0x10696f2e0*/
        break; /*0x10696f2e0*/
      result = v20; /*0x10696f2e2*/
      if ( (int)v20 != v20 || v6 == -1 || (_DWORD)v20 == -1 ) /*0x10696f2f7*/
        break; /*0x10696f2f7*/
      if ( v6 == a1 ) /*0x10696f2fd*/
        return result; /*0x10696f2fd*/
      v13 = *a4; /*0x10696f2ff*/
      if ( (v13 & 1) != 0 ) /*0x10696f307*/
      {
        v14 = *((const void **)a4 + 2); /*0x10696f309*/
        v15 = *((_QWORD *)a4 + 1); /*0x10696f30d*/
      }
      else
      {
        v15 = v13 >> 1; /*0x10696f313*/
        v14 = __s2; /*0x10696f316*/
      }
      v16 = v22; /*0x10696f31a*/
      if ( v22 < v15 ) /*0x10696f321*/
        break; /*0x10696f321*/
      v17 = (char *)__s1; /*0x10696f323*/
      if ( v15 != 0 && memcmp(__s1, __s2: v14, __n: v15) != 0 ) /*0x10696f339*/
        break; /*0x10696f339*/
      __s1 = &v17[v15]; /*0x10696f33e*/
      result = 0xFFFFFFFFLL; /*0x10696f342*/
      v22 = v16 - v15; /*0x10696f34a*/
      if ( v16 == v15 ) /*0x10696f34a*/
        return result; /*0x10696f34e*/
    }
  }
  return 0xFFFFFFFFLL; /*0x10696f35b*/
}

// Address: 0x10696f36a | Name: __ZN3RBX7Network18isIntExistInStringERKiRKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEESB_
__int64 __fastcall RBX::Network::isIntExistInString(int *a1, unsigned __int8 *a2, __int64 a3)
{
  unsigned int v5; // eax
  __int64 v6; // rax
  const char *v7; // r14
  void *v8; // rsi
  __int64 v9; // r14
  __int64 v10; // r15
  char *v11; // r13
  int v12; // r14d
  int v13; // r12d
  void *v14; // rsi
  bool v15; // zf
  __int64 v17; // [rsp+8h] [rbp-88h]
  char v18[16]; // [rsp+10h] [rbp-80h] BYREF
  char *v19; // [rsp+20h] [rbp-70h]
  __int128 v20; // [rsp+30h] [rbp-60h] BYREF
  __int64 v21; // [rsp+40h] [rbp-50h]
  RBX::Memory *__dst[3]; // [rsp+48h] [rbp-48h] BYREF

  v5 = *a2; /*0x10696f392*/
  if ( (v5 & 1) != 0 ) /*0x10696f397*/
    v6 = *((_QWORD *)a2 + 1); /*0x10696f399*/
  else
    v6 = v5 >> 1; /*0x10696f39f*/
  if ( v6 == 0 ) /*0x10696f3a4*/
    goto LABEL_24; /*0x10696f3a4*/
  if ( (*(_BYTE *)a3 & 1) == 0 ) /*0x10696f3af*/
  {
    if ( *(_BYTE *)a3 != 0 ) /*0x10696f3b3*/
    {
      v20 = 0; /*0x10696f3bc*/
      v21 = 0; /*0x10696f3c0*/
      v7 = (const char *)(a3 + 1); /*0x10696f3c8*/
      goto LABEL_10; /*0x10696f3cb*/
    }
LABEL_24:
    LODWORD(a1) = 0; /*0x10696f4b9*/
    return (unsigned int)a1; /*0x10696f4bb*/
  }
  if ( *(_QWORD *)(a3 + 8) == 0 ) /*0x10696f3d2*/
    goto LABEL_24; /*0x10696f3d2*/
  v20 = 0; /*0x10696f3db*/
  v21 = 0; /*0x10696f3df*/
  v7 = *(const char **)(a3 + 16); /*0x10696f3e7*/
LABEL_10:
  *(_QWORD *)v18 = v7; /*0x10696f3eb*/
  *(_QWORD *)&v18[8] = &v7[strlen(__s: v7)]; /*0x10696f3fd*/
  boost::algorithm::detail::is_any_ofF<char>::is_any_ofF<boost::iterator_range<char const*>>( /*0x10696f405*/
    (char *)__dst,
    a2: (__int64)v18);
  boost::algorithm::split<std::vector<std::string>,std::string const,boost::algorithm::detail::is_any_ofF<char>>( /*0x10696f41a*/
    a1: (__int64)&v20,
    (__int64)a2,
    a3: __dst,
    a4: 1);
  if ( __dst[2] >= (RBX::Memory *)0x11 && __dst[0] != nullptr ) /*0x10696f42d*/
    operator delete[](a1: __dst[0], a2: v8); /*0x10696f42f*/
  v9 = *((_QWORD *)&v20 + 1); /*0x10696f438*/
  v10 = v20; /*0x10696f438*/
  if ( (_QWORD)v20 == *((_QWORD *)&v20 + 1) ) /*0x10696f43f*/
  {
LABEL_23:
    LODWORD(a1) = 0; /*0x10696f4b5*/
    goto LABEL_26; /*0x10696f4b7*/
  }
  v17 = *((_QWORD *)&v20 + 1); /*0x10696f441*/
  while ( 1 ) /*0x10696f44c*/
  {
    if ( (*(_BYTE *)v10 & 1) != 0 ) /*0x10696f44c*/
    {
      std::string::__init_copy_ctor_external(a1: v18, a2: *(_QWORD *)(v10 + 16), a3: *(_QWORD *)(v10 + 8)); /*0x10696f46c*/
    }
    else
    {
      v19 = *(char **)(v10 + 16); /*0x10696f452*/
      *(_OWORD *)v18 = *(_OWORD *)v10; /*0x10696f45a*/
    }
    if ( (v18[0] & 1) != 0 ) /*0x10696f475*/
      break; /*0x10696f475*/
    if ( atoi(a1: &v18[1]) == *a1 ) /*0x10696f482*/
      goto LABEL_25; /*0x10696f482*/
LABEL_22:
    v10 += 24; /*0x10696f4ac*/
    if ( v10 == v9 ) /*0x10696f4b3*/
      goto LABEL_23; /*0x10696f4b3*/
  }
  v11 = v19; /*0x10696f486*/
  v12 = atoi(a1: v19); /*0x10696f492*/
  v13 = *a1; /*0x10696f495*/
  operator delete(a1: (RBX::Memory *)v11, a2: v14); /*0x10696f49b*/
  v15 = v12 == v13; /*0x10696f4a0*/
  v9 = v17; /*0x10696f4a3*/
  if ( !v15 ) /*0x10696f4aa*/
    goto LABEL_22; /*0x10696f4aa*/
LABEL_25:
  LOBYTE(a1) = 1; /*0x10696f4bd*/
LABEL_26:
  *(_QWORD *)v18 = &v20; /*0x10696f4bf*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: v18); /*0x10696f4ca*/
  return (unsigned int)a1; /*0x10696f4e1*/
}

// Address: 0x10696f52f | Name: __ZN3RBX7Network31getSystemAddressFromPlayerOnRccEPKNS_6PlayerE
RBX::Network *__fastcall RBX::Network::getSystemAddressFromPlayerOnRcc(RBX::Network *this, const RBX::Player *a2)
{
  __int64 v4; // rax
  __int64 v5; // r14
  __int128 v6; // xmm0
  std::__shared_weak_count *v7; // r14
  std::__shared_weak_count *v8; // r14
  __int64 v10; // [rsp+8h] [rbp-28h] BYREF
  std::__shared_weak_count *v11; // [rsp+10h] [rbp-20h]

  v4 = RBX::ServiceProvider::find<RBX::Network::Server>(a1: a2); /*0x10696f545*/
  if ( v4 == 0 ) /*0x10696f54d*/
  {
LABEL_11:
    RakNet::SystemAddress::SystemAddress(this); /*0x10696f603*/
    return this; /*0x10696f606*/
  }
  v5 = v4; /*0x10696f553*/
  if ( FFlag::MigrateUserIdAccessors != 1 ) /*0x10696f560*/
    RBX::PlayerProp::getUserID(this: (const RBX::Player *)((char *)a2 + 176)); /*0x10696f575*/
  RBX::Network::Server::getServerReplicatorForPlayerId(this: (RBX::Network::Server *)&v10, a2: v5); /*0x10696f587*/
  if ( v10 == 0 ) /*0x10696f592*/
  {
    v8 = v11; /*0x10696f5d7*/
    if ( v11 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v11 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10696f5f0*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x10696f5f8*/
      std::__shared_weak_count::__release_weak(this: v8); /*0x10696f5fe*/
    }
    goto LABEL_11; /*0x10696f5fe*/
  }
  v6 = *(_OWORD *)(v10 + 240); /*0x10696f594*/
  *((_OWORD *)this + 1) = *(_OWORD *)(v10 + 256); /*0x10696f5a2*/
  *(_OWORD *)this = v6; /*0x10696f5a6*/
  v7 = v11; /*0x10696f5a9*/
  if ( v11 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v11 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10696f5c2*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x10696f5ca*/
    std::__shared_weak_count::__release_weak(this: v7); /*0x10696f5d0*/
  }
  return this; /*0x10696f60e*/
}

// Address: 0x106d6bd68 | Name: __ZN3RBX7NetworkL54rbxImplDynInit_registerClientReplicatorMembers_DefaultEv
__int64 __fastcall RBX::Network::rbxImplDynInit_registerClientReplicatorMembers_Default(RBX::Network *this)
{
  void *v1; // rsi
  _QWORD v3[5]; // [rsp+8h] [rbp-28h] BYREF

  v3[0] = RBX::Network::registerClientReplicatorMembers; /*0x106d6bd7c*/
  v3[3] = (char *)&RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<void (*)(void)>(void (*)(void))::Callback /*0x106d6bd86*/
        + 2;
  RBX::Reflection::addReflectionInitializer(); /*0x106d6bd8a*/
  return RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v3, a2: v1); /*0x106d6bd98*/
}

// Address: 0x106d6c3b3 | Name: __ZN3RBX7NetworkL31registerClientReplicatorMembersEv
__int64 __fastcall RBX::Network::registerClientReplicatorMembers(RBX::Network *this)
{
  __int64 v1; // rbx

  v1 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(a1: this); /*0x106d6c3be*/
  RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::EventDescriptor>::addDescriptors( /*0x106d6c3d1*/
    a1: v1 + 112,
    a2: &RBX::Network::kClientReplicatorEventsDescriptors,
    a3: 2);
  return RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::FunctionDescriptor>::addDescriptors( /*0x106d6c3f0*/
           a1: v1 + 184,
           a2: &RBX::Network::kClientReplicatorFunctionDescriptors,
           a3: 3);
}

// Address: 0x106d6eebc | Name: __ZN3RBX7NetworkL51rbxImplDynInit_registerNetworkClientMembers_DefaultEv
__int64 __fastcall RBX::Network::rbxImplDynInit_registerNetworkClientMembers_Default(RBX::Network *this)
{
  void *v1; // rsi
  _QWORD v3[5]; // [rsp+8h] [rbp-28h] BYREF

  v3[0] = RBX::Network::registerNetworkClientMembers; /*0x106d6eed0*/
  v3[3] = (char *)&RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<void (*)(void)>(void (*)(void))::Callback /*0x106d6eeda*/
        + 2;
  RBX::Reflection::addReflectionInitializer(); /*0x106d6eede*/
  return RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v3, a2: v1); /*0x106d6eeec*/
}

// Address: 0x106d6f0e5 | Name: __ZN3RBX7NetworkL28registerNetworkClientMembersEv
__int64 __fastcall RBX::Network::registerNetworkClientMembers(RBX::Network *this)
{
  __int64 v1; // rbx

  v1 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: this); /*0x106d6f0f0*/
  RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::EventDescriptor>::addDescriptors( /*0x106d6f103*/
    a1: v1 + 112,
    a2: &RBX::Network::kNetworkClientEventsDescriptors,
    a3: 2);
  return RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::FunctionDescriptor>::addDescriptors( /*0x106d6f11a*/
           a1: v1 + 184,
           a2: 0,
           a3: 0);
}

// Address: 0x106d70bee | Name: __ZN3RBX7NetworkL51rbxImplDynInit_registerNetworkMarkerMembers_DefaultEv
__int64 __fastcall RBX::Network::rbxImplDynInit_registerNetworkMarkerMembers_Default(RBX::Network *this)
{
  void *v1; // rsi
  _QWORD v3[5]; // [rsp+8h] [rbp-28h] BYREF

  v3[0] = RBX::Network::registerNetworkMarkerMembers; /*0x106d70c02*/
  v3[3] = (char *)&RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<void (*)(void)>(void (*)(void))::Callback /*0x106d70c0c*/
        + 2;
  RBX::Reflection::addReflectionInitializer(); /*0x106d70c10*/
  return RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v3, a2: v1); /*0x106d70c1e*/
}

// Address: 0x106d70e1d | Name: __ZN3RBX7NetworkL28registerNetworkMarkerMembersEv
__int64 __fastcall RBX::Network::registerNetworkMarkerMembers(RBX::Network *this)
{
  __int64 v1; // rax

  v1 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Marker>(a1: this); /*0x106d70e21*/
  return RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::EventDescriptor>::addDescriptors( /*0x106d70e36*/
           a1: v1 + 112,
           a2: &RBX::Network::kNetworkMarkerEventsDescriptors,
           a3: 1);
}

// Address: 0x106d714a6 | Name: __ZN3RBX7NetworkL49rbxImplDynInit_registerNetworkPeerMembers_DefaultEv
__int64 __fastcall RBX::Network::rbxImplDynInit_registerNetworkPeerMembers_Default(RBX::Network *this)
{
  void *v1; // rsi
  _QWORD v3[5]; // [rsp+8h] [rbp-28h] BYREF

  v3[0] = RBX::Network::registerNetworkPeerMembers; /*0x106d714ba*/
  v3[3] = (char *)&RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<void (*)(void)>(void (*)(void))::Callback /*0x106d714c4*/
        + 2;
  RBX::Reflection::addReflectionInitializer(); /*0x106d714c8*/
  return RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v3, a2: v1); /*0x106d714d6*/
}

// Address: 0x106d71954 | Name: __ZN3RBX7NetworkL26registerNetworkPeerMembersEv
__int64 __fastcall RBX::Network::registerNetworkPeerMembers(RBX::Network *this)
{
  __int64 v1; // rax

  v1 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Peer>(a1: this); /*0x106d71958*/
  return RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::FunctionDescriptor>::addDescriptors( /*0x106d71970*/
           a1: v1 + 184,
           a2: &RBX::Network::kNetworkPeerFunctionDescriptors,
           a3: 2);
}

// Address: 0x106d722fe | Name: __ZN3RBX7NetworkL55rbxImplDynInit_registerNetworkReplicatorMembers_DefaultEv
__int64 __fastcall RBX::Network::rbxImplDynInit_registerNetworkReplicatorMembers_Default(RBX::Network *this)
{
  void *v1; // rsi
  _QWORD v3[5]; // [rsp+8h] [rbp-28h] BYREF

  v3[0] = RBX::Network::registerNetworkReplicatorMembers; /*0x106d72312*/
  v3[3] = (char *)&RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<void (*)(void)>(void (*)(void))::Callback /*0x106d7231c*/
        + 2;
  RBX::Reflection::addReflectionInitializer(); /*0x106d72320*/
  return RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v3, a2: v1); /*0x106d7232e*/
}

// Address: 0x106d724db | Name: __ZN3RBX7NetworkL32registerNetworkReplicatorMembersEv
__int64 __fastcall RBX::Network::registerNetworkReplicatorMembers(RBX::Network *this)
{
  __int64 v1; // rax

  v1 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(a1: this); /*0x106d724df*/
  return RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::FunctionDescriptor>::addDescriptors( /*0x106d724f7*/
           a1: v1 + 184,
           a2: &RBX::Network::kNetworkReplicatorFunctionDescriptors,
           a3: 1);
}

// Address: 0x106d72d5a | Name: __ZN3RBX7NetworkL51rbxImplDynInit_registerNetworkServerMembers_DefaultEv
__int64 __fastcall RBX::Network::rbxImplDynInit_registerNetworkServerMembers_Default(RBX::Network *this)
{
  void *v1; // rsi
  _QWORD v3[5]; // [rsp+8h] [rbp-28h] BYREF

  v3[0] = RBX::Network::registerNetworkServerMembers; /*0x106d72d6e*/
  v3[3] = (char *)&RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<void (*)(void)>(void (*)(void))::Callback /*0x106d72d78*/
        + 2;
  RBX::Reflection::addReflectionInitializer(); /*0x106d72d7c*/
  return RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v3, a2: v1); /*0x106d72d8a*/
}

// Address: 0x106d731ae | Name: __ZN3RBX7NetworkL28registerNetworkServerMembersEv
__int64 __fastcall RBX::Network::registerNetworkServerMembers(RBX::Network *this)
{
  __int64 v1; // rax

  v1 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Server>(a1: this); /*0x106d731b2*/
  return RBX::Reflection::MemberDescriptorContainerV2<RBX::Reflection::FunctionDescriptor>::addDescriptors( /*0x106d731ca*/
           a1: v1 + 184,
           a2: &RBX::Network::kNetworkServerFunctionDescriptors,
           a3: 1);
}

// Address: 0x106d74fbd | Name: __ZN3RBX7Network29isPlayerAuthenticationEnabledEv
__int64 __fastcall RBX::Network::isPlayerAuthenticationEnabled(RBX::Network *this)
{
  return 0; /*0x106d74fc3*/
}

// Address: 0x106d74fc5 | Name: __ZN3RBX7Network22initWithServerSecurityEv
__int64 __fastcall RBX::Network::initWithServerSecurity(RBX::Network *this)
{
  RBX::Network *v1; // rdi

  std::string::assign(a1: RBX::Network::versionB, a2: "7"); /*0x106d74fdc*/
  std::string::push_back(a1: RBX::Network::versionB, a2: 79); /*0x106d74fe9*/
  RBX::Network::initWithoutSecurity(this: v1); /*0x106d74fee*/
  std::string::append(a1: RBX::Network::versionB, a2: "l"); /*0x106d74ffd*/
  return std::string::push_back(a1: RBX::Network::versionB, a2: 69); /*0x106d7500e*/
}

// Address: 0x106d75015 | Name: __ZN3RBX7Network19initWithoutSecurityEv
__int64 __fastcall RBX::Network::initWithoutSecurity(RBX::Network *this)
{
  __int64 v1; // rdi
  __int64 v2; // rdi
  __int64 v3; // rdi
  __int64 v4; // rdi
  __int64 v5; // rdi

  RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(a1: this); /*0x106d7501b*/
  RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Server>(a1: v1); /*0x106d75020*/
  std::string::append(a1: RBX::Network::versionB, a2: "^"); /*0x106d75036*/
  RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(a1: v2); /*0x106d7503b*/
  RBX::Reflection::Class_getDescriptorPtr<RBX::Players>(a1: v3); /*0x106d75040*/
  RBX::Reflection::Class_getDescriptorPtr<RBX::GlobalAdvancedSettings>(a1: v4); /*0x106d75045*/
  RBX::Reflection::Class_getDescriptorPtr<RBX::NetworkSettings>(a1: v5); /*0x106d7504a*/
  return std::string::push_back(a1: RBX::Network::versionB, a2: 17); /*0x106d7505b*/
}

// Address: 0x106d75062 | Name: __ZN3RBX7Network22initWithPlayerSecurityEv
__int64 __fastcall RBX::Network::initWithPlayerSecurity(RBX::Network *this)
{
  RBX::Network *v1; // rdi

  std::string::assign(a1: RBX::Network::versionB, a2: "7"); /*0x106d75079*/
  std::string::push_back(a1: RBX::Network::versionB, a2: 79); /*0x106d75086*/
  RBX::Network::initWithoutSecurity(this: v1); /*0x106d7508b*/
  std::string::append(a1: RBX::Network::versionB, a2: "l"); /*0x106d7509a*/
  return std::string::push_back(a1: RBX::Network::versionB, a2: 69); /*0x106d750ab*/
}

// Address: 0x106d750b2 | Name: __ZN3RBX7Network25initWithCloudEditSecurityEv
__int64 __fastcall RBX::Network::initWithCloudEditSecurity(RBX::Network *this)
{
  std::string::assign(a1: RBX::Network::versionB, a2: ""); /*0x106d750c9*/
  std::string::append(a1: RBX::Network::versionB, a2: "^"); /*0x106d750d8*/
  return std::string::push_back(a1: RBX::Network::versionB, a2: 17); /*0x106d750e9*/
}

// Address: 0x106d750f0 | Name: __ZN3RBX7Network10setVersionEPKc
__int64 __fastcall RBX::Network::setVersion(RBX::Network *this, const char *a2)
{
  return RBX::Network::setVersionInternal(this, a2); /*0x106d750f4*/
}

// Address: 0x106d76e2d | Name: __ZN3RBX7Network48isGameplayAllowedNewObjectPropertyClientToServerERKNS_10Reflection18PropertyDescriptorE
__int64 *__fastcall RBX::Network::isGameplayAllowedNewObjectPropertyClientToServer(
        RBX::Network *this,
        const RBX::Reflection::PropertyDescriptor *a2)
{
  __int64 v3; // r14
  bool v4; // cl
  __int64 *result; // rax

  v3 = *((_QWORD *)this + 6); /*0x106d76e37*/
  v4 = v3 != RBX::Instance::classDescriptor(this); /*0x106d76e43*/
  result = &RBX::Instance::desc_Name; /*0x106d76e46*/
  LOBYTE(result) = v4 || RBX::Instance::desc_Name == (_QWORD)this; /*0x106d76e53*/
  return result; /*0x106d76e55*/
}

// Address: 0x106d77239 | Name: __ZN3RBX7Network30insertIntoWhitelistForUnitTestERNS0_22NetworkFilterWhiteListEPKNS_10Reflection16MemberDescriptorENS0_26NetworkFilterWhiteListItemE
__int64 __fastcall RBX::Network::insertIntoWhitelistForUnitTest(__int64 a1, __int64 a2, int a3)
{
  __int64 result; // rax
  __int64 *v5; // [rsp+0h] [rbp-20h] BYREF
  __int64 v6; // [rsp+8h] [rbp-18h] BYREF
  _BYTE v7[9]; // [rsp+17h] [rbp-9h] BYREF

  v6 = a2; /*0x106d77248*/
  v5 = &v6; /*0x106d7724f*/
  result = ((__int64 (__fastcall *)(__int64, __int64 *, const char *, __int64 **, _BYTE *))std::__hash_table<std::__hash_value_type<RBX::Reflection::MemberDescriptor const*,RBX::Network::NetworkFilterWhiteListItem>,std::__unordered_map_hasher<RBX::Reflection::MemberDescriptor const*,std::__hash_value_type<RBX::Reflection::MemberDescriptor const*,RBX::Network::NetworkFilterWhiteListItem>,std::hash<RBX::Reflection::MemberDescriptor const*>,std::equal_to<RBX::Reflection::MemberDescriptor const*>,true>,std::__unordered_map_equal<RBX::Reflection::MemberDescriptor const*,std::__hash_value_type<RBX::Reflection::MemberDescriptor const*,RBX::Network::NetworkFilterWhiteListItem>,std::equal_to<RBX::Reflection::MemberDescriptor const*>,std::hash<RBX::Reflection::MemberDescriptor const*>,true>,std::allocator<std::__hash_value_type<RBX::Reflection::MemberDescriptor const*,RBX::Network::NetworkFilterWhiteListItem>>>::__emplace_unique_key_args<RBX::Reflection::MemberDescriptor const*,std::piecewise_construct_t const&,std::tuple<RBX::Reflection::MemberDescriptor const* const&>,std::tuple<>>)( /*0x106d77260*/
             a1,
             a2: &v6,
             a3: std::piecewise_construct,
             a4: &v5,
             a5: v7);
  *(_DWORD *)(result + 24) = a3; /*0x106d77265*/
  return result; /*0x106d77268*/
}

// Address: 0x106d7c298 | Name: __ZN3RBX7NetworkL20reportFilteringGroupENS_10StringViewERNS0_24FilterGroupResultTrackerE
void __fastcall RBX::Network::reportFilteringGroup(__int64 a1, __int64 a2, int *a3)
{
  int v6; // r13d
  int v7; // r13d
  int v8; // r13d
  int v9; // r13d
  void *v10[9]; // [rsp+8h] [rbp-248h] BYREF
  double v11[64]; // [rsp+50h] [rbp-200h] BYREF

  v6 = a3[1]; /*0x106d7c2b5*/
  if ( v6 != 0 ) /*0x106d7c2bc*/
  {
    RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x106d7c2cc*/
      a1: v10,
      a2: (__int64)&RBX::Telemetry::kNetworkFilterAcceptedEvent);
    RBX::Telemetry::FieldsContainer::addField(a1: v11, a2: "group", a3: 5, a4: a1, a5: a2, a6: 1); /*0x106d7c2f3*/
    v11[57] = (double)v6; /*0x106d7c307*/
    RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v10); /*0x106d7c30f*/
    RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v11); /*0x106d7c322*/
    RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v10, a2: (void **)off_10C8C7EB0); /*0x106d7c335*/
  }
  v7 = *a3; /*0x106d7c33a*/
  if ( *a3 != 0 ) /*0x106d7c340*/
  {
    RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x106d7c350*/
      a1: v10,
      a2: (__int64)&RBX::Telemetry::kNetworkFilterAcceptedProperty);
    RBX::Telemetry::FieldsContainer::addField(a1: v11, a2: "group", a3: 5, a4: a1, a5: a2, a6: 1); /*0x106d7c377*/
    v11[57] = (double)v7; /*0x106d7c38e*/
    RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v10); /*0x106d7c396*/
    RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v11); /*0x106d7c3a9*/
    RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v10, a2: (void **)off_10C8C7EB0); /*0x106d7c3bc*/
  }
  v8 = a3[3]; /*0x106d7c3c1*/
  if ( v8 != 0 ) /*0x106d7c3c8*/
  {
    RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x106d7c3d8*/
      a1: v10,
      a2: (__int64)&RBX::Telemetry::kNetworkFilterRejectedEvent);
    RBX::Telemetry::FieldsContainer::addField(a1: v11, a2: "group", a3: 5, a4: a1, a5: a2, a6: 1); /*0x106d7c3ff*/
    v11[57] = (double)v8; /*0x106d7c416*/
    RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v10); /*0x106d7c41e*/
    RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v11); /*0x106d7c431*/
    RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v10, a2: (void **)off_10C8C7EB0); /*0x106d7c444*/
  }
  v9 = a3[2]; /*0x106d7c449*/
  if ( v9 != 0 ) /*0x106d7c450*/
  {
    RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x106d7c460*/
      a1: v10,
      a2: (__int64)&RBX::Telemetry::kNetworkFilterRejectedProperty);
    RBX::Telemetry::FieldsContainer::addField(a1: v11, a2: "group", a3: 5, a4: a1, a5: a2, a6: 1); /*0x106d7c487*/
    v11[57] = (double)v9; /*0x106d7c49e*/
    RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v10); /*0x106d7c4a6*/
    RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v11); /*0x106d7c4b9*/
    RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v10, a2: (void **)off_10C8C7EB0); /*0x106d7c4cc*/
  }
  *(_OWORD *)a3 = 0; /*0x106d7c4d5*/
}

// Address: 0x106d894be | Name: __ZN3RBX7Network11getOrientIdERKNS_14Matrix3PartialEf
__int64 __fastcall RBX::Network::getOrientId(RBX::Network *this, const RBX::Matrix3Partial *a2, float a3)
{
  __m128 v4; // xmm1
  int v5; // ebx
  const RBX::Vector3 *v6; // rsi
  __int64 result; // rax
  __m128 v8; // xmm0
  bool v9; // zf
  char v10; // cl
  _DWORD v11[3]; // [rsp+0h] [rbp-20h] BYREF
  float v12; // [rsp+Ch] [rbp-14h]

  v4 = *(__m128 *)this; /*0x106d894cc*/
  _mm_storel_ps((double *)v11, *(__m128 *)this); /*0x106d894d3*/
  v11[2] = _mm_extract_ps(v4, 2); /*0x106d894d6*/
  v12 = a3; /*0x106d894dd*/
  v5 = RBX::Vector3ToNormalId(this: (RBX *)v11, a2, a3); /*0x106d894e7*/
  LOBYTE(result) = -1; /*0x106d894e9*/
  if ( v5 != 6 ) /*0x106d894ee*/
  {
    v8 = *(__m128 *)((char *)this + 12); /*0x106d894f0*/
    _mm_storel_ps((double *)v11, v8); /*0x106d894f9*/
    v11[2] = _mm_extract_ps(v8, 2); /*0x106d894fc*/
    LODWORD(result) = RBX::Vector3ToNormalId(this: (RBX *)v11, a2: v6, a3: v12); /*0x106d89508*/
    v9 = (_DWORD)result == 6; /*0x106d8950d*/
    v10 = result + 6 * v5; /*0x106d89513*/
    LOBYTE(result) = -1; /*0x106d89516*/
    if ( !v9 ) /*0x106d8951b*/
      LOBYTE(result) = v10; /*0x106d8951b*/
  }
  return (unsigned __int8)result; /*0x106d89521*/
}

// Address: 0x106d8952a | Name: __ZN3RBX7Network11getPvHeaderERKNS_13ReplicationPVEi
__int64 __fastcall RBX::Network::getPvHeader(RBX::Network *this, const RBX::ReplicationPV *a2)
{
  int v2; // r14d
  __m128i si128; // xmm1
  __m128i v5; // xmm0
  int v6; // eax
  float v7; // xmm0_4
  unsigned __int8 v8; // r15
  __m128i v9; // xmm1
  __m128i v10; // xmm0
  unsigned int v11; // r12d
  __m128i v12; // xmm1
  __m128i v13; // xmm0
  float v14; // xmm2_4
  unsigned int v15; // r15d
  float v16; // xmm0_4
  const RBX::Matrix3Partial *v17; // rsi
  unsigned __int8 OrientId; // al
  float v20; // [rsp+0h] [rbp-30h]
  float v21; // [rsp+0h] [rbp-30h]

  v2 = (int)a2; /*0x106d89539*/
  si128 = _mm_load_si128((const __m128i *)&xmmword_108F46760); /*0x106d89543*/
  v5 = _mm_and_si128(_mm_loadl_epi64((const __m128i *)this), si128); /*0x106d8954b*/
  v20 = fmaxf( /*0x106d89565*/
          *(float *)_mm_and_si128(_mm_cvtsi32_si128(*((_DWORD *)this + 2)), si128).i32,
          fmaxf(*(float *)_mm_shuffle_epi32(v5, 245).i32, *(float *)v5.i32));
  v6 = -10; /*0x106d8957c*/
  if ( (DFInt::GameNetPVHeaderTranslationZeroCutoffExponent & (DFInt::GameNetPVHeaderTranslationZeroCutoffExponent >> 31)) >= -9 ) /*0x106d89581*/
    v6 = DFInt::GameNetPVHeaderTranslationZeroCutoffExponent /*0x106d89581*/
       & (DFInt::GameNetPVHeaderTranslationZeroCutoffExponent >> 31);
  v7 = __exp10(a1: (double)v6); /*0x106d89590*/
  v8 = (v7 > v20) << 7; /*0x106d8959c*/
  v9 = _mm_load_si128((const __m128i *)&xmmword_108F46760); /*0x106d895a5*/
  v10 = _mm_and_si128(_mm_loadl_epi64((const __m128i *)((char *)this + 40)), v9); /*0x106d895ad*/
  v21 = fmaxf( /*0x106d895c7*/
          *(float *)_mm_and_si128(_mm_cvtsi32_si128(*((_DWORD *)this + 12)), v9).i32,
          fmaxf(*(float *)_mm_shuffle_epi32(v10, 245).i32, *(float *)v10.i32));
  v11 = (unsigned __int8)(v8 + 64); /*0x106d895ea*/
  if ( __exp10f(a1: (float)DFInt::GameNetPVHeaderLinearVelocityZeroCutoffExponent) <= v21 ) /*0x106d895ee*/
    v11 = v8; /*0x106d895ee*/
  v12 = _mm_load_si128((const __m128i *)&xmmword_108F46760); /*0x106d895f7*/
  v13 = _mm_and_si128(_mm_loadl_epi64((const __m128i *)((char *)this + 52)), v12); /*0x106d895ff*/
  v14 = fmaxf( /*0x106d89615*/
          *(float *)_mm_and_si128(_mm_cvtsi32_si128(*((_DWORD *)this + 15)), v12).i32,
          fmaxf(*(float *)_mm_shuffle_epi32(v13, 245).i32, *(float *)v13.i32));
  v15 = (unsigned __int8)(v11 + 32); /*0x106d89639*/
  if ( __exp10f(a1: (float)DFInt::GameNetPVHeaderRotationalVelocityZeroCutoffExponent) <= v14 ) /*0x106d8963d*/
    v15 = v11; /*0x106d8963d*/
  if ( v2 != 0 || DFFlag::DebugPVLOD0SerializeFullMatrix == 0 ) /*0x106d8964d*/
  {
    v16 = __exp10f(a1: (float)DFInt::GameNetPVHeaderRotationOrientIdToleranceExponent); /*0x106d89667*/
    OrientId = RBX::Network::getOrientId(this: (RBX::Network *)((char *)this + 12), a2: v17, a3: v16); /*0x106d8966f*/
    if ( OrientId <= 0x23u ) /*0x106d89676*/
      LOBYTE(v15) = RBX::Network::PVHeader::kCompressOrientId[OrientId] | v15; /*0x106d89682*/
  }
  else
  {
    LOBYTE(v15) = v15 | 0x1F; /*0x106d8964f*/
  }
  return v15; /*0x106d89689*/
}

// Address: 0x106d89696 | Name: __ZN3RBX7Network23serializeMatrix3PartialERNS0_13NetworkStreamERKNS_14Matrix3PartialE
__int64 __fastcall RBX::Network::serializeMatrix3Partial(
        RBX::Network *this,
        RBX::Network::NetworkStream *a2,
        const RBX::Matrix3Partial *a3)
{
  __int64 v3; // rax
  _DWORD v7[7]; // [rsp+0h] [rbp-1Ch] BYREF

  v7[0] = HIDWORD(v3); /*0x106d8969f*/
  v7[0] = *(_DWORD *)a2; /*0x106d896ae*/
  RBX::Network::NetworkStream::writeBytes(this, a2: v7, a3: 4u); /*0x106d896bb*/
  v7[0] = *((_DWORD *)a2 + 1); /*0x106d896c6*/
  RBX::Network::NetworkStream::writeBytes(this, a2: v7, a3: 4u); /*0x106d896d6*/
  v7[0] = *((_DWORD *)a2 + 2); /*0x106d896e1*/
  RBX::Network::NetworkStream::writeBytes(this, a2: v7, a3: 4u); /*0x106d896f1*/
  v7[0] = *((_DWORD *)a2 + 3); /*0x106d896fc*/
  RBX::Network::NetworkStream::writeBytes(this, a2: v7, a3: 4u); /*0x106d8970c*/
  v7[0] = *((_DWORD *)a2 + 4); /*0x106d89717*/
  RBX::Network::NetworkStream::writeBytes(this, a2: v7, a3: 4u); /*0x106d89727*/
  v7[0] = *((_DWORD *)a2 + 5); /*0x106d89732*/
  RBX::Network::NetworkStream::writeBytes(this, a2: v7, a3: 4u); /*0x106d89742*/
  v7[0] = *((_DWORD *)a2 + 6); /*0x106d8974d*/
  return RBX::Network::NetworkStream::writeBytes(this, a2: v7, a3: 4u); /*0x106d89767*/
}

// Address: 0x106d8976e | Name: __ZN3RBX7Network25deserializeMatrix3PartialERNS0_13NetworkStreamERNS_14Matrix3PartialE
__int64 __fastcall RBX::Network::deserializeMatrix3Partial(
        RBX::Network *this,
        RBX::Network::NetworkStream *a2,
        RBX::Matrix3Partial *a3)
{
  int v5; // xmm0_4
  int v6; // xmm0_4
  int v7; // xmm0_4
  int v8; // xmm0_4
  int v9; // xmm0_4
  int v10; // xmm0_4
  __int64 result; // rax
  int v12; // xmm0_4

  RBX::Network::NetworkStream::readFloat(this); /*0x106d8977b*/
  *(_DWORD *)a2 = v5; /*0x106d89780*/
  RBX::Network::NetworkStream::readFloat(this); /*0x106d89787*/
  *((_DWORD *)a2 + 1) = v6; /*0x106d8978c*/
  RBX::Network::NetworkStream::readFloat(this); /*0x106d89794*/
  *((_DWORD *)a2 + 2) = v7; /*0x106d89799*/
  RBX::Network::NetworkStream::readFloat(this); /*0x106d897a1*/
  *((_DWORD *)a2 + 3) = v8; /*0x106d897a6*/
  RBX::Network::NetworkStream::readFloat(this); /*0x106d897ae*/
  *((_DWORD *)a2 + 4) = v9; /*0x106d897b3*/
  RBX::Network::NetworkStream::readFloat(this); /*0x106d897bb*/
  *((_DWORD *)a2 + 5) = v10; /*0x106d897c0*/
  result = RBX::Network::NetworkStream::readFloat(this); /*0x106d897c8*/
  *((_DWORD *)a2 + 6) = v12; /*0x106d897cd*/
  return result; /*0x106d897d2*/
}

// Address: 0x106d8af86 | Name: __ZN3RBX7Network20serializeForLodLevelERNS0_13NetworkStreamERKNS_19FacsReplicationDataENS_5Enums11FACSDataLodE
void __fastcall RBX::Network::serializeForLodLevel(RBX::Network::NetworkStream *this, __int64 a2, unsigned int a3)
{
  unsigned int v6; // r13d
  unsigned __int8 v7; // cl
  int v8; // eax
  int v9; // ecx
  int v10; // eax
  __m128 v11; // xmm2
  float v12; // xmm0_4
  __m128 v13; // xmm1
  char v14; // al
  unsigned int v15; // xmm2_4
  float v16; // xmm1_4
  int v17; // ebx
  RBX::Network::NetworkStream *v18; // r14
  int v19; // ebx
  __m128 v20; // xmm2
  __m128 v21; // xmm0
  int v22; // ebx
  unsigned __int64 ControlsNamesSizeByLod; // r14
  __int64 v24; // rdx
  __int64 v25; // rcx
  const char *v26; // rsi
  __int64 v27; // r8
  __int64 v28; // r9
  __m128 v29; // xmm0
  __m128 v30; // xmm1
  __m128 v31; // xmm2
  __m128 v32; // xmm3
  __m128 v33; // xmm4
  __m128 v34; // xmm5
  __m128 v35; // xmm6
  __m128 v36; // xmm7
  __int64 i; // rbx
  RBX::Network::NetworkStream *v38; // rbx
  unsigned int v39; // r15d
  __int64 v40; // rdi
  void **v41; // r12
  std::__shared_weak_count *v42; // r14
  std::__shared_weak_count *v43; // r14
  _BYTE *v44; // rax
  _BYTE *v45; // r13
  _BYTE *v46; // r15
  char v47; // r15
  unsigned __int64 v48; // rbx
  char v49; // r13
  unsigned int v50; // r14d
  void **v51; // rcx
  void *v52; // rsi
  __m128 v53; // [rsp+0h] [rbp-C0h]
  unsigned int v54; // [rsp+0h] [rbp-C0h]
  __int64 v55; // [rsp+18h] [rbp-A8h] BYREF
  volatile signed __int64 *v56; // [rsp+20h] [rbp-A0h]
  __int64 v57; // [rsp+28h] [rbp-98h]
  std::__shared_weak_count *v58; // [rsp+30h] [rbp-90h]
  float v59; // [rsp+3Ch] [rbp-84h]
  void *v60[2]; // [rsp+40h] [rbp-80h] BYREF
  __int64 v61; // [rsp+50h] [rbp-70h]
  RBX::Network::NetworkStream *v62; // [rsp+58h] [rbp-68h]
  __int64 v63; // [rsp+60h] [rbp-60h] BYREF
  std::__shared_weak_count *v64; // [rsp+68h] [rbp-58h]
  void *v65[2]; // [rsp+70h] [rbp-50h] BYREF
  __int64 v66; // [rsp+80h] [rbp-40h]
  unsigned int v67; // [rsp+90h] [rbp-30h]
  int v68; // [rsp+94h] [rbp-2Ch]

  RBX::Network::FacsHuffmanCodecLease::FacsHuffmanCodecLease(this: (RBX::Network::FacsHuffmanCodecLease *)&v55); /*0x106d8afaa*/
  *(_OWORD *)v60 = 0; /*0x106d8afb2*/
  v61 = 0; /*0x106d8afb6*/
  RBX::Network::NetworkStream::reserve(this, a2: 0x3Fu); /*0x106d8afc6*/
  v6 = *((_DWORD *)this + 12); /*0x106d8afcb*/
  LOBYTE(v65[0]) = 0; /*0x106d8afd3*/
  RBX::Network::NetworkStream::writeBytes(this, a2: v65, a3: 1u); /*0x106d8afde*/
  v62 = this; /*0x106d8afe3*/
  v7 = 4 * (((*(_DWORD *)a2 - 1) & 0xFFFFFFFD) == 0); /*0x106d8aff6*/
  v8 = v7; /*0x106d8b002*/
  v9 = (unsigned __int8)(v7 + 8); /*0x106d8b005*/
  if ( (*(_DWORD *)a2 & 0xFFFFFFFE) != 2 ) /*0x106d8b008*/
    v9 = v8; /*0x106d8b008*/
  v10 = (unsigned __int8)(v9 + 16); /*0x106d8b012*/
  if ( a3 != 1 ) /*0x106d8b015*/
    v10 = v9; /*0x106d8b015*/
  v68 = v10; /*0x106d8b018*/
  v11 = _mm_div_ps((__m128)*(unsigned __int64 *)(a2 + 4), (__m128)xmmword_10971A180); /*0x106d8b021*/
  v12 = v11.f32[0] * 32767.0; /*0x106d8b02b*/
  v53 = v11; /*0x106d8b036*/
  v13 = _mm_cmplt_ps((__m128)0LL, v11); /*0x106d8b03d*/
  v14 = _mm_movemask_pd((__m128d)_mm_unpacklo_ps(v13, v13)); /*0x106d8b044*/
  v15 = 1056964608; /*0x106d8b048*/
  v16 = 0.5; /*0x106d8b058*/
  if ( (v14 & 1) == 0 ) /*0x106d8b05d*/
    v16 = -0.5; /*0x106d8b05f*/
  v17 = (int)(float)(v12 + v16); /*0x106d8b066*/
  if ( (v14 & 2) == 0 ) /*0x106d8b06c*/
    v15 = -1090519040; /*0x106d8b06e*/
  v67 = v15; /*0x106d8b071*/
  v59 = *(float *)(a2 + 12); /*0x106d8b07c*/
  LOBYTE(v65[0]) = (unsigned __int16)(int)(float)(v12 + v16) >> 8; /*0x106d8b084*/
  v18 = v62; /*0x106d8b08b*/
  RBX::Network::NetworkStream::writeBytes(this: v62, a2: v65, a3: 1u); /*0x106d8b097*/
  LOBYTE(v65[0]) = v17; /*0x106d8b0a0*/
  RBX::Network::NetworkStream::writeBytes(this: v18, a2: v65, a3: 1u); /*0x106d8b0aa*/
  v19 = (int)(float)((float)(_mm_movehdup_ps(v53).f32[0] * 32767.0) + *(float *)&v67); /*0x106d8b0c4*/
  LOBYTE(v65[0]) = BYTE1(v19); /*0x106d8b0c8*/
  RBX::Network::NetworkStream::writeBytes(this: v18, a2: v65, a3: 1u); /*0x106d8b0d7*/
  LOBYTE(v65[0]) = v19; /*0x106d8b0e0*/
  RBX::Network::NetworkStream::writeBytes(this: v18, a2: v65, a3: 1u); /*0x106d8b0ea*/
  v20.f32[0] = v59 / 90.0; /*0x106d8b0f7*/
  v21 = _mm_cmplt_ss((__m128)0LL, v20); /*0x106d8b10e*/
  v22 = (int)(float)(COERCE_FLOAT(COERCE_UNSIGNED_INT(_mm_andnot_ps(v21, (__m128)0xBF000000).f32[0]) | v21.i32[0] & 0x3F000000) /*0x106d8b130*/
                   + (float)(32767.0 * (float)(v59 / 90.0)));
  LOBYTE(v65[0]) = BYTE1(v22); /*0x106d8b134*/
  RBX::Network::NetworkStream::writeBytes(this: v18, a2: v65, a3: 1u); /*0x106d8b143*/
  LOBYTE(v65[0]) = v22; /*0x106d8b14c*/
  RBX::Network::NetworkStream::writeBytes(this: v18, a2: v65, a3: 1u); /*0x106d8b156*/
  *(_OWORD *)v65 = 0; /*0x106d8b15e*/
  v66 = 0; /*0x106d8b162*/
  ControlsNamesSizeByLod = RBX::TrackerData::getControlsNamesSizeByLod(a1: a3); /*0x106d8b172*/
  std::vector<unsigned char>::reserve(a1: v65, a2: ControlsNamesSizeByLod); /*0x106d8b17c*/
  v54 = v6; /*0x106d8b181*/
  if ( (__int64)(*(_QWORD *)(a2 + 40) - *(_QWORD *)(a2 + 32)) >> 2 < ControlsNamesSizeByLod ) /*0x106d8b197*/
    RBX::throw_runtime_error( /*0x106d8b41f*/
      this: (RBX *)"Serialize Facs Payload - too few control values",
      a2: v26,
      a3: v24,
      a4: v25,
      a5: v27,
      a6: v28,
      a7: v29,
      a8: v30,
      a9: v31,
      a10: v32,
      a11: v33,
      a12: v34,
      a13: v35,
      a14: v36,
      a15: v6);
  if ( ControlsNamesSizeByLod != 0 ) /*0x106d8b1a0*/
  {
    for ( i = 0; i != ControlsNamesSizeByLod; ++i ) /*0x106d8b1a2*/
    {
      LOBYTE(v63) = (int)(float)((float)(*(float *)(*(_QWORD *)(a2 + 32) + 4 * i) * 255.0) + 0.5); /*0x106d8b1c9*/
      std::vector<unsigned char>::push_back[abi:ne200100](a1: v65); /*0x106d8b1d2*/
    }
  }
  v38 = v62; /*0x106d8b1df*/
  v39 = *((_DWORD *)v62 + 12); /*0x106d8b1e3*/
  LOBYTE(v63) = 0; /*0x106d8b1eb*/
  RBX::Network::NetworkStream::writeBytes(this: v62, a2: &v63, a3: 1u); /*0x106d8b1f6*/
  v40 = v55; /*0x106d8b1fb*/
  v63 = v55; /*0x106d8b209*/
  v64 = (std::__shared_weak_count *)v56; /*0x106d8b20d*/
  if ( v56 != nullptr ) /*0x106d8b214*/
  {
    _InterlockedIncrement64(v56 + 1); /*0x106d8b216*/
    v57 = v40; /*0x106d8b222*/
    v58 = (std::__shared_weak_count *)v56; /*0x106d8b229*/
    if ( v56 != nullptr ) /*0x106d8b233*/
      _InterlockedIncrement64(v56 + 1); /*0x106d8b235*/
  }
  else
  {
    v57 = v55; /*0x106d8b23c*/
    v58 = nullptr; /*0x106d8b243*/
  }
  v41 = v65; /*0x106d8b252*/
  RBX::HuffmanEncoder::encode<std::vector<unsigned char>>(a1: v40, a2: v65, a3: v60, a4: v40 + 16); /*0x106d8b25d*/
  v42 = v58; /*0x106d8b262*/
  if ( v58 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v58 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106d8b27e*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v42 + 16LL))(a1: v42); /*0x106d8b286*/
    std::__shared_weak_count::__release_weak(this: v42); /*0x106d8b28c*/
  }
  v43 = v64; /*0x106d8b291*/
  if ( v64 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v64 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106d8b2aa*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v43 + 16LL))(a1: v43); /*0x106d8b2b2*/
    std::__shared_weak_count::__release_weak(this: v43); /*0x106d8b2b8*/
  }
  v67 = v39; /*0x106d8b2bd*/
  v44 = v60[0]; /*0x106d8b2c1*/
  v45 = v65[0]; /*0x106d8b2c9*/
  if ( v60[1] == v60[0] ) /*0x106d8b2d0*/
  {
    v46 = v65[1]; /*0x106d8b322*/
  }
  else
  {
    v46 = v65[1]; /*0x106d8b2d2*/
    if ( (void *)((char *)v60[1] - (char *)v60[0]) < (void *)((char *)v65[1] - (char *)v65[0]) ) /*0x106d8b2df*/
    {
      v47 = v68 | 1; /*0x106d8b2e5*/
      v48 = 0; /*0x106d8b2e9*/
      do /*0x106d8b317*/
      {
        LOBYTE(v63) = v44[v48]; /*0x106d8b2f2*/
        RBX::Network::NetworkStream::writeBytes(this: v62, a2: &v63, a3: 1u); /*0x106d8b301*/
        ++v48; /*0x106d8b306*/
        v44 = v60[0]; /*0x106d8b309*/
      }
      while ( (char *)v60[1] - (char *)v60[0] > v48 ); /*0x106d8b317*/
      v49 = 1; /*0x106d8b319*/
      v38 = v62; /*0x106d8b31c*/
      goto LABEL_32; /*0x106d8b320*/
    }
  }
  if ( v65[0] != v46 ) /*0x106d8b329*/
  {
    do /*0x106d8b34c*/
    {
      LOBYTE(v63) = *v45; /*0x106d8b333*/
      RBX::Network::NetworkStream::writeBytes(this: v38, a2: &v63, a3: 1u); /*0x106d8b341*/
      ++v45; /*0x106d8b346*/
    }
    while ( v45 != v46 ); /*0x106d8b34c*/
  }
  v49 = 0; /*0x106d8b34e*/
  v47 = v68; /*0x106d8b351*/
LABEL_32:
  v50 = *((_DWORD *)v38 + 12); /*0x106d8b355*/
  RBX::Network::NetworkStream::SetWriteOffsetBytes(this: v38, a2: v54, a3: false); /*0x106d8b364*/
  LOBYTE(v63) = v47; /*0x106d8b36d*/
  RBX::Network::NetworkStream::writeBytes(this: v38, a2: &v63, a3: 1u); /*0x106d8b378*/
  RBX::Network::NetworkStream::SetWriteOffsetBytes(this: v38, a2: v50, a3: false); /*0x106d8b385*/
  RBX::Network::NetworkStream::SetWriteOffsetBytes(this: v38, a2: v67, a3: false); /*0x106d8b392*/
  if ( v49 != 0 ) /*0x106d8b3a2*/
    v41 = v60; /*0x106d8b3a2*/
  v51 = &v60[1]; /*0x106d8b3a6*/
  if ( v49 == 0 ) /*0x106d8b3aa*/
    v51 = &v65[1]; /*0x106d8b3aa*/
  LOBYTE(v63) = *(_BYTE *)v51 - *(_BYTE *)v41; /*0x106d8b3b8*/
  RBX::Network::NetworkStream::writeBytes(this: v38, a2: &v63, a3: 1u); /*0x106d8b3c2*/
  RBX::Network::NetworkStream::SetWriteOffsetBytes(this: v38, a2: v50, a3: false); /*0x106d8b3cf*/
  if ( v65[0] != nullptr ) /*0x106d8b3db*/
  {
    v65[1] = v65[0]; /*0x106d8b3dd*/
    operator delete(a1: (RBX::Memory *)v65[0], a2: v52); /*0x106d8b3e1*/
  }
  if ( v60[0] != nullptr ) /*0x106d8b3ed*/
  {
    v60[1] = v60[0]; /*0x106d8b3ef*/
    operator delete(a1: (RBX::Memory *)v60[0], a2: v52); /*0x106d8b3f3*/
  }
  RBX::Network::FacsHuffmanCodecLease::~FacsHuffmanCodecLease(this: (RBX::Network::FacsHuffmanCodecLease *)&v55); /*0x106d8b3ff*/
}

// Address: 0x106d8b493 | Name: __ZN3RBX7Network18trackerModeValueOfEj
__int64 __fastcall RBX::Network::trackerModeValueOf(RBX::Network *this)
{
  if ( ((unsigned __int8)this & 4) != 0 ) /*0x106d8b49b*/
    return ((unsigned __int8)((unsigned __int8)this & 8) >> 2) + 1; /*0x106d8b4ab*/
  else
    return ((unsigned int)this >> 2) & 2; /*0x106d8b4a0*/
}

// Address: 0x106d8b4af | Name: __ZN3RBX7Network18facsDataLodValueOfEj
_BOOL8 __fastcall RBX::Network::facsDataLodValueOf(RBX::Network *this)
{
  return ((unsigned __int8)this & 0x10) != 0; /*0x106d8b4bb*/
}

// Address: 0x106d8b4bd | Name: __ZN3RBX7Network22deserializeForLodLevelERNS0_13NetworkStreamERNS_19FacsReplicationDataENS_5Enums11FACSDataLodE
void __fastcall RBX::Network::deserializeForLodLevel(RBX::Network::NetworkStream *this, __int64 a2, unsigned int a3)
{
  unsigned __int8 Byte; // al
  int v5; // edx
  unsigned __int8 v6; // r14
  unsigned __int8 v7; // bl
  unsigned __int8 v8; // r13
  unsigned __int8 v9; // r12
  unsigned __int8 v10; // al
  __int64 v11; // rdx
  unsigned __int8 v12; // bl
  __int64 v13; // r13
  char *v14; // r15
  char *v15; // rbx
  __int64 v16; // rdx
  __int64 v17; // rcx
  const char *v18; // rsi
  __int64 v19; // r8
  __int64 v20; // r9
  __m128 v21; // xmm0
  __m128 v22; // xmm1
  __m128 v23; // xmm2
  __m128 v24; // xmm3
  __m128 v25; // xmm4
  __m128 v26; // xmm5
  __m128 v27; // xmm6
  __m128 v28; // xmm7
  char *v29; // rdi
  __int64 v30; // rdi
  volatile signed __int64 *v31; // r12
  _BYTE *v32; // rbx
  __int64 v33; // rdx
  __int64 v34; // rcx
  const char *v35; // rsi
  __int64 v36; // r8
  __int64 v37; // r9
  int ControlsNamesSizeByLod; // r14d
  __m128 v39; // xmm0
  __m128 v40; // xmm1
  __m128 v41; // xmm2
  __m128 v42; // xmm3
  __m128 v43; // xmm4
  __m128 v44; // xmm5
  __m128 v45; // xmm6
  __m128 v46; // xmm7
  __int64 *v47; // rbx
  void *v48; // rsi
  __int64 v49; // rax
  __int64 v50; // r14
  __int64 v51; // rcx
  char v52; // [rsp+0h] [rbp-90h]
  __int64 v53; // [rsp+10h] [rbp-80h] BYREF
  std::__shared_weak_count *v54; // [rsp+18h] [rbp-78h]
  char *v55[4]; // [rsp+20h] [rbp-70h] BYREF
  void *v56[2]; // [rsp+40h] [rbp-50h] BYREF
  __int64 v57; // [rsp+50h] [rbp-40h]
  __int64 v58; // [rsp+58h] [rbp-38h]
  unsigned int v59; // [rsp+60h] [rbp-30h]
  unsigned __int8 v60; // [rsp+66h] [rbp-2Ah]
  unsigned __int8 v61; // [rsp+67h] [rbp-29h]

  v59 = a3; /*0x106d8b4ce*/
  v58 = a2; /*0x106d8b4d1*/
  RBX::Network::FacsHuffmanCodecLease::FacsHuffmanCodecLease(this: (RBX::Network::FacsHuffmanCodecLease *)&v53); /*0x106d8b4dc*/
  Byte = RBX::Network::NetworkStream::readByte(this); /*0x106d8b4e4*/
  v61 = Byte; /*0x106d8b4ec*/
  if ( (Byte & 4) != 0 ) /*0x106d8b4f1*/
    v5 = ((unsigned __int8)(Byte & 8) >> 2) + 1; /*0x106d8b501*/
  else
    v5 = (Byte >> 2) & 2; /*0x106d8b4f6*/
  *(_DWORD *)v58 = v5; /*0x106d8b507*/
  v60 = RBX::Network::NetworkStream::readByte(this); /*0x106d8b511*/
  v6 = RBX::Network::NetworkStream::readByte(this); /*0x106d8b51c*/
  v7 = RBX::Network::NetworkStream::readByte(this); /*0x106d8b527*/
  v8 = RBX::Network::NetworkStream::readByte(this); /*0x106d8b531*/
  v9 = RBX::Network::NetworkStream::readByte(this); /*0x106d8b53c*/
  v10 = RBX::Network::NetworkStream::readByte(this); /*0x106d8b542*/
  v11 = v58; /*0x106d8b594*/
  _mm_storel_ps( /*0x106d8b598*/
    (double *)(v58 + 4),
    _mm_min_ps(
      (__m128)xmmword_1097E5590,
      _mm_max_ps(
        (__m128)xmmword_109A02540,
        _mm_mul_ps(
          _mm_div_ps(
            _mm_cvtepi32_ps(
              _mm_cvtepi16_epi32(
                _mm_unpacklo_epi8(
                  _mm_insert_epi8(_mm_cvtsi32_si128(v6), v8, 1),
                  _mm_insert_epi8(_mm_cvtsi32_si128(v60), v7, 1)))),
            (__m128)xmmword_1097E5590),
          (__m128)xmmword_10971A180))));
  *(float *)(v11 + 12) = fminf(32767.0, fmaxf(-32767.0, (float)((float)(__int16)((v9 << 8) | v10) / 32767.0) * 90.0)); /*0x106d8b5d4*/
  v12 = RBX::Network::NetworkStream::readByte(this); /*0x106d8b5e1*/
  v13 = v12; /*0x106d8b5e3*/
  memset(v55, 0, 24); /*0x106d8b5ee*/
  std::vector<unsigned char>::reserve(a1: v55, a2: v12); /*0x106d8b5fc*/
  if ( v12 != 0 ) /*0x106d8b603*/
  {
    do /*0x106d8b626*/
    {
      LOBYTE(v56[0]) = RBX::Network::NetworkStream::readByte(this); /*0x106d8b615*/
      std::vector<unsigned char>::push_back[abi:ne200100](a1: v55); /*0x106d8b61e*/
      --v13; /*0x106d8b623*/
    }
    while ( v13 != 0 ); /*0x106d8b626*/
  }
  v14 = v55[0]; /*0x106d8b628*/
  *(_OWORD *)v56 = 0; /*0x106d8b62f*/
  v57 = 0; /*0x106d8b633*/
  if ( (v61 & 1) != 0 ) /*0x106d8b63f*/
  {
    v30 = v53; /*0x106d8b665*/
    v31 = (volatile signed __int64 *)v54; /*0x106d8b669*/
    v52 = v53; /*0x106d8b66d*/
    if ( v54 != nullptr ) /*0x106d8b67e*/
      _InterlockedIncrement64((volatile signed __int64 *)v54 + 1); /*0x106d8b680*/
    RBX::HuffmanDecoder::decode(a1: v30 + 8, a2: v14, a3: v55[1] - v14, a4: v56, a5: 256); /*0x106d8b69e*/
    if ( v31 != nullptr && _InterlockedExchangeAdd64(v31 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106d8b6b9*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v31 + 16))(a1: v31); /*0x106d8b6c2*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v31); /*0x106d8b6c8*/
    }
    v14 = (char *)v56[0]; /*0x106d8b6cd*/
    v32 = v56[1]; /*0x106d8b6d1*/
    if ( v32 - v14 < (unsigned __int64)RBX::TrackerData::getControlsNamesSizeByLod(a1: v59) ) /*0x106d8b6e3*/
    {
      v29 = "Deserialize FACS Payload failed - Huffman decompression failed"; /*0x106d8b7ab*/
LABEL_28:
      RBX::throw_runtime_error( /*0x106d8b7b2*/
        this: (RBX *)v29,
        a2: v18,
        a3: v16,
        a4: v17,
        a5: v19,
        a6: v20,
        a7: v21,
        a8: v22,
        a9: v23,
        a10: v24,
        a11: v25,
        a12: v26,
        a13: v27,
        a14: v28,
        a15: v52);
    }
  }
  else
  {
    v15 = v55[1]; /*0x106d8b641*/
    if ( v15 - v14 != RBX::TrackerData::getControlsNamesSizeByLod(a1: v59) ) /*0x106d8b653*/
    {
      v29 = "Deserialize FACS Payload failed - wrong number of control values"; /*0x106d8b659*/
      goto LABEL_28; /*0x106d8b660*/
    }
  }
  ControlsNamesSizeByLod = RBX::TrackerData::getControlsNamesSizeByLod(a1: v59); /*0x106d8b6f1*/
  if ( ControlsNamesSizeByLod >= 51 ) /*0x106d8b6f8*/
    RBX::throw_runtime_error( /*0x106d8b7a4*/
      this: (RBX *)"Deserialize FACS Payload failed - too many control values",
      a2: v35,
      a3: v33,
      a4: v34,
      a5: v36,
      a6: v37,
      a7: v39,
      a8: v40,
      a9: v41,
      a10: v42,
      a11: v43,
      a12: v44,
      a13: v45,
      a14: v46,
      a15: v52);
  v47 = (__int64 *)(v58 + 32); /*0x106d8b70a*/
  v48 = (void *)ControlsNamesSizeByLod; /*0x106d8b712*/
  if ( (__int64)(*(_QWORD *)(v58 + 40) - *(_QWORD *)(v58 + 32)) >> 2 < (unsigned __int64)ControlsNamesSizeByLod ) /*0x106d8b718*/
    std::vector<float>::resize(a1: v58 + 32, a2: ControlsNamesSizeByLod); /*0x106d8b71d*/
  if ( ControlsNamesSizeByLod > 0 ) /*0x106d8b725*/
  {
    v49 = *v47; /*0x106d8b727*/
    v50 = ControlsNamesSizeByLod & 0x7FFFFFFF; /*0x106d8b72a*/
    v51 = 0; /*0x106d8b731*/
    do /*0x106d8b75d*/
    {
      *(float *)(v49 + 4 * v51) = fminf(255.0, (float)(unsigned __int8)v14[v51] / 255.0); /*0x106d8b752*/
      ++v51; /*0x106d8b757*/
    }
    while ( v50 != v51 ); /*0x106d8b75d*/
  }
  if ( v56[0] != nullptr ) /*0x106d8b766*/
  {
    v56[1] = v56[0]; /*0x106d8b768*/
    operator delete(a1: (RBX::Memory *)v56[0], a2: v48); /*0x106d8b76c*/
  }
  if ( v55[0] != nullptr ) /*0x106d8b778*/
  {
    v55[1] = v55[0]; /*0x106d8b77a*/
    operator delete(a1: (RBX::Memory *)v55[0], a2: v48); /*0x106d8b77e*/
  }
  RBX::Network::FacsHuffmanCodecLease::~FacsHuffmanCodecLease(this: (RBX::Network::FacsHuffmanCodecLease *)&v53); /*0x106d8b787*/
}

// END Network part 1/1, 257 functions
