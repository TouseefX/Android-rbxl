// SecurityChannel -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 19 functions


// Address: 0x106d82854 | Name: __ZN3RBX7Network15SecurityChannelC2ENS1_11ChannelTypeE
__int64 __fastcall RBX::Network::SecurityChannel::SecurityChannel(__int64 a1, char a2)
{
  __int64 result; // rax

  *(_BYTE *)a1 = a2; /*0x106d8285d*/
  RSL::Mutex::Mutex(this: (RSL::Mutex *)(a1 + 8), a2: "SecurityChannelMutex"); /*0x106d8286b*/
  result = RSL::Mutex::Mutex(this: (RSL::Mutex *)(a1 + 16), a2: "SecurityChannelSequenceNumberMutex"); /*0x106d8287b*/
  *(_DWORD *)(a1 + 24) = 1; /*0x106d82880*/
  *(_OWORD *)(a1 + 32) = 0; /*0x106d8288a*/
  *(_OWORD *)(a1 + 44) = 0; /*0x106d8288e*/
  *(_OWORD *)(a1 + 64) = 0; /*0x106d82892*/
  *(_OWORD *)(a1 + 76) = 0; /*0x106d82896*/
  return result; /*0x106d8289e*/
}

// Address: 0x106d828a2 | Name: __ZN3RBX7Network15SecurityChannelC1ENS1_11ChannelTypeE
__int64 __fastcall RBX::Network::SecurityChannel::SecurityChannel(__int64 a1, char a2)
{
  __int64 result; // rax

  *(_BYTE *)a1 = a2; /*0x106d828ab*/
  RSL::Mutex::Mutex(this: (RSL::Mutex *)(a1 + 8), a2: "SecurityChannelMutex"); /*0x106d828b9*/
  result = RSL::Mutex::Mutex(this: (RSL::Mutex *)(a1 + 16), a2: "SecurityChannelSequenceNumberMutex"); /*0x106d828c9*/
  *(_DWORD *)(a1 + 24) = 1; /*0x106d828ce*/
  *(_OWORD *)(a1 + 32) = 0; /*0x106d828d8*/
  *(_OWORD *)(a1 + 44) = 0; /*0x106d828dc*/
  *(_OWORD *)(a1 + 64) = 0; /*0x106d828e0*/
  *(_OWORD *)(a1 + 76) = 0; /*0x106d828e4*/
  return result; /*0x106d828ec*/
}

// Address: 0x106d828f0 | Name: __ZN3RBX7Network15SecurityChannelD2Ev
void __fastcall RBX::Network::SecurityChannel::~SecurityChannel(void **this)
{
  operator delete(a1: *(this + 9)); /*0x106d828fd*/
  RSL::Mutex::~Mutex(a1: this + 2); /*0x106d82906*/
  RSL::Mutex::~Mutex(a1: this + 1); /*0x106d82918*/
}

// Address: 0x106d8291e | Name: __ZN3RBX7Network15SecurityChannelD1Ev
void __fastcall RBX::Network::SecurityChannel::~SecurityChannel(void **this)
{
  RBX::Network::SecurityChannel::~SecurityChannel(this); /*0x106d82923*/
}

// Address: 0x106d82928 | Name: __ZN3RBX7Network15SecurityChannel6onSentEj
__int64 __fastcall RBX::Network::SecurityChannel::onSent(RBX::Network::SecurityChannel *this, int a2)
{
  __int64 v4; // r15
  __int64 v5; // rax
  _DWORD v7[7]; // [rsp+0h] [rbp-1Ch] BYREF

  v7[0] = a2; /*0x106d82935*/
  ++*((_DWORD *)this + 8); /*0x106d82938*/
  if ( a2 != 0 ) /*0x106d8293d*/
  {
    v4 = RBX::Time::epochTimeMs(this); /*0x106d82947*/
    ++*((_DWORD *)this + 9); /*0x106d8294a*/
    v5 = RBX::DenseMapBase<RBX::DenseMap<unsigned int,RBX::Network::SecurityChannel::UnAckedItem,RBX::DenseMapInfo<unsigned int,void>,RBX::detail::DenseMapPair<unsigned int,RBX::Network::SecurityChannel::UnAckedItem>>,unsigned int,RBX::Network::SecurityChannel::UnAckedItem,RBX::DenseMapInfo<unsigned int,void>,RBX::detail::DenseMapPair<unsigned int,RBX::Network::SecurityChannel::UnAckedItem>>::FindAndConstruct( /*0x106d82955*/
           a1: (char *)this + 72,
           a2: v7);
    *(_DWORD *)(v5 + 8) = a2; /*0x106d8295a*/
    *(_QWORD *)(v5 + 16) = v4; /*0x106d8295e*/
  }
  return RBX::Network::SecurityChannel::sendCounter(this, a2: "f3571816"); /*0x106d82975*/
}

// Address: 0x106d8297c | Name: __ZN3RBX7Network15SecurityChannel11sendCounterEPKc
void __fastcall RBX::Network::SecurityChannel::sendCounter(RBX::Network::SecurityChannel *this, const char *a2)
{
  __int64 *v3; // rsi
  __int64 v4; // r8
  char *v5; // rcx
  RBX *v6; // rdi
  unsigned __int8 *RobloxChannelName; // rax
  unsigned int v8; // r8d
  __int64 v9; // r8
  unsigned __int8 *v10; // rax
  void *v11[9]; // [rsp+0h] [rbp-230h] BYREF
  _BYTE v12[488]; // [rsp+48h] [rbp-1E8h] BYREF

  v3 = &RBX::Telemetry::kSecurityChannelClientCounter; /*0x106d82997*/
  if ( *(_BYTE *)this == 87 ) /*0x106d8299e*/
    v3 = &RBX::Telemetry::kSecurityChannelServerCounter; /*0x106d8299e*/
  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter(a1: v11, a2: (__int64)v3); /*0x106d829a9*/
  RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v12); /*0x106d829b8*/
  RBX::Telemetry::FieldsContainer::addArchitectureInfo(this: (RBX::Telemetry::FieldsContainer *)v12); /*0x106d829c0*/
  if ( (RBX::Analytics::appVersion & 1) != 0 ) /*0x106d829d4*/
  {
    v4 = *((_QWORD *)&RBX::Analytics::appVersion + 1); /*0x106d829d6*/
    v5 = (char *)qword_10D50FFC8; /*0x106d829da*/
  }
  else
  {
    v4 = (unsigned __int8)RBX::Analytics::appVersion >> 1; /*0x106d829e0*/
    v5 = (char *)&RBX::Analytics::appVersion + 1; /*0x106d829e3*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "appVersion", a3: 10, a4: v5, a5: v4, a6: 1); /*0x106d829fb*/
  RobloxChannelName = (unsigned __int8 *)RBX::GetRobloxChannelName(this: v6); /*0x106d82a00*/
  v8 = *RobloxChannelName; /*0x106d82a05*/
  if ( (v8 & 1) != 0 ) /*0x106d82a0d*/
  {
    v9 = *((_QWORD *)RobloxChannelName + 1); /*0x106d82a0f*/
    v10 = *((unsigned __int8 **)RobloxChannelName + 2); /*0x106d82a13*/
  }
  else
  {
    v10 = RobloxChannelName + 1; /*0x106d82a19*/
    v9 = v8 >> 1; /*0x106d82a1c*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "channel", a3: 7, a4: v10, a5: v9, a6: 1); /*0x106d82a37*/
  RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "eventCode", a3: 9, a4: a2, a5: 1); /*0x106d82a54*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v11); /*0x106d82a60*/
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v12); /*0x106d82a73*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v11, a2: (void **)off_10C8C7EB0); /*0x106d82a86*/
}

// Address: 0x106d82aae | Name: __ZN3RBX7Network15SecurityChannel5onAckEj
__int64 __fastcall RBX::Network::SecurityChannel::onAck(__m128i *this, unsigned int a2)
{
  unsigned __int64 v3; // r15
  unsigned __int8 v4; // al
  _DWORD *v5; // rcx
  unsigned __int64 v6; // rdx
  unsigned int v7; // eax
  unsigned int v8; // edx
  unsigned int v9; // esi
  unsigned int v10; // r15d
  __int64 v12; // [rsp+0h] [rbp-30h] BYREF
  unsigned int v13[9]; // [rsp+Ch] [rbp-24h] BYREF

  v13[0] = a2; /*0x106d82ac4*/
  v3 = RBX::Time::epochTimeMs((RBX::Time *)this); /*0x106d82acd*/
  RSL::Mutex::lock(this: (RSL::Mutex *)&this->u64[1]); /*0x106d82ad7*/
  v4 = RBX::DenseMapBase<RBX::DenseMap<unsigned int,RBX::Network::SecurityChannel::UnAckedItem,RBX::DenseMapInfo<unsigned int,void>,RBX::detail::DenseMapPair<unsigned int,RBX::Network::SecurityChannel::UnAckedItem>>,unsigned int,RBX::Network::SecurityChannel::UnAckedItem,RBX::DenseMapInfo<unsigned int,void>,RBX::detail::DenseMapPair<unsigned int,RBX::Network::SecurityChannel::UnAckedItem>>::LookupBucketFor<unsigned int>( /*0x106d82ae7*/
         a1: (char *)this + 72,
         a2: v13,
         a3: &v12);
  v5 = (_DWORD *)v12; /*0x106d82aec*/
  if ( ((v12 != *((_QWORD *)this + 9) + 24LL * *((unsigned int *)this + 22)) & v4) == 1 ) /*0x106d82b0a*/
  {
    v6 = *(_QWORD *)(v12 + 16); /*0x106d82b0c*/
    v7 = 0; /*0x106d82b15*/
    if ( v3 > v6 ) /*0x106d82b1a*/
      v7 = v3 - v6; /*0x106d82b1a*/
    v8 = *((_DWORD *)this + 13); /*0x106d82b1d*/
    v9 = v8; /*0x106d82b23*/
    if ( v7 < v8 ) /*0x106d82b25*/
      v9 = v7; /*0x106d82b25*/
    if ( v8 == 0 ) /*0x106d82b2a*/
      v9 = v7; /*0x106d82b2a*/
    *((_DWORD *)this + 13) = v9; /*0x106d82b2d*/
    if ( v9 != 0 && v7 <= *((_DWORD *)this + 14) ) /*0x106d82b3b*/
      v7 = *((_DWORD *)this + 14); /*0x106d82b3b*/
    *((_DWORD *)this + 14) = v7; /*0x106d82b3e*/
    ++*((_DWORD *)this + 10); /*0x106d82b42*/
    *v5 = -2; /*0x106d82b46*/
    *((_QWORD *)this + 10) = _mm_add_epi32(_mm_loadl_epi64(this + 5), (__m128i)xmmword_108F21470).u64[0]; /*0x106d82b5a*/
    RBX::Network::SecurityChannel::sendCounter((RBX::Network::SecurityChannel *)this, a2: "d10ba29c"); /*0x106d82b6a*/
  }
  else
  {
    v10 = v13[0]; /*0x106d82b71*/
    if ( v10 < (unsigned int)RBX::Network::SecurityChannel::getNextSequenceNumber( /*0x106d82b82*/
                               (RBX::Network::SecurityChannel *)this,
                               a2: false) )
      ++*((_DWORD *)this + 12); /*0x106d82b84*/
    RBX::Network::SecurityChannel::sendCounter((RBX::Network::SecurityChannel *)this, a2: "b00bd23c"); /*0x106d82b92*/
  }
  return RSL::Mutex::unlock(this: (RSL::Mutex *)&this->u64[1]); /*0x106d82b9f*/
}

// Address: 0x106d82bcc | Name: __ZN3RBX7Network15SecurityChannel21getNextSequenceNumberEb
__int64 __fastcall RBX::Network::SecurityChannel::getNextSequenceNumber(
        RBX::Network::SecurityChannel *this,
        unsigned __int8 a2)
{
  unsigned __int8 v4; // r13
  RSL::Mutex *v5; // r14
  int v6; // ebx
  bool v7; // al
  unsigned int v8; // ebx

  v4 = a2 ^ 1; /*0x106d82be3*/
  v5 = (RBX::Network::SecurityChannel *)((char *)this + 16); /*0x106d82be7*/
  RSL::Mutex::lock(this: (RBX::Network::SecurityChannel *)((char *)this + 16)); /*0x106d82bee*/
  v6 = *((_DWORD *)this + 6); /*0x106d82bf3*/
  v7 = v6 != 0; /*0x106d82bf9*/
  v8 = (v6 == 0) + v6; /*0x106d82bff*/
  if ( (v4 & v7) == 0 ) /*0x106d82c05*/
    *((_DWORD *)this + 6) = v8 + a2; /*0x106d82c0d*/
  RSL::Mutex::unlock(this: v5); /*0x106d82c14*/
  return v8; /*0x106d82c1f*/
}

// Address: 0x106d82c32 | Name: __ZN3RBX7Network15SecurityChannel14sendDelayStatsENS1_11MessageTypeEy
void __fastcall RBX::Network::SecurityChannel::sendDelayStats(__int64 a1, unsigned __int8 a2, unsigned __int64 a3)
{
  __m128d v5; // xmm0
  _BYTE v6[72]; // [rsp+0h] [rbp-250h] BYREF
  _BYTE v7[520]; // [rsp+48h] [rbp-208h] BYREF

  RBX::Telemetry::RobloxTelemetryStat::RobloxTelemetryStat( /*0x106d82c58*/
    a1: (__int64)v6,
    a2: (__int64)&RBX::Telemetry::kSecurityChannelDelayStats);
  v5 = _mm_sub_pd((__m128d)_mm_unpacklo_epi32((__m128i)a3, (__m128i)xmmword_108F2F9A0), (__m128d)xmmword_108F2F9B0); /*0x106d82c6a*/
  RBX::Telemetry::RobloxTelemetryStat::setValue( /*0x106d82c79*/
    this: (RBX::Telemetry::RobloxTelemetryStat *)v6,
    a2: _mm_hadd_pd(v5, v5).f64[0]);
  RBX::Telemetry::FieldsContainer::addField(a1: v7, a2: "msgType", a3: 7, a4: a2, a5: 1); /*0x106d82c9a*/
  RBX::Telemetry::RobloxTelemetryStat::send(this: (RBX::Telemetry::RobloxTelemetryStat *)v6); /*0x106d82ca6*/
  RBX::Telemetry::RobloxTelemetryStat::~RobloxTelemetryStat(this: (RBX::Telemetry::RobloxTelemetryStat *)v6); /*0x106d82cb9*/
}

// Address: 0x106d82cea | Name: __ZN3RBX7Network15SecurityChannel8getStatsEv
RBX::Network::SecurityChannel *__fastcall RBX::Network::SecurityChannel::getStats(
        RBX::Network::SecurityChannel *this,
        __int64 a2)
{
  RSL::Mutex *v4; // r15
  __int128 v5; // xmm0

  v4 = (RSL::Mutex *)(a2 + 8); /*0x106d82cfa*/
  RSL::Mutex::lock(this: (RSL::Mutex *)(a2 + 8)); /*0x106d82d01*/
  *((_QWORD *)this + 4) = *(_QWORD *)(a2 + 64); /*0x106d82d0a*/
  v5 = *(_OWORD *)(a2 + 32); /*0x106d82d0e*/
  *((_OWORD *)this + 1) = *(_OWORD *)(a2 + 48); /*0x106d82d18*/
  *(_OWORD *)this = v5; /*0x106d82d1c*/
  RSL::Mutex::unlock(this: v4); /*0x106d82d22*/
  return this; /*0x106d82d2e*/
}

// Address: 0x106d82d3e | Name: __ZN3RBX7Network15SecurityChannel17clearExpiredItemsEv
__int64 __fastcall RBX::Network::SecurityChannel::clearExpiredItems(__m128i *this)
{
  __int64 v2; // rax
  __int64 v3; // rcx
  _DWORD *v4; // rdx
  __int64 v5; // rdi
  _DWORD *v6; // r11
  __int64 v7; // rsi
  _DWORD *v8; // rsi
  int v9; // r10d
  __m128i v10; // xmm0
  unsigned int v11; // r9d
  _DWORD *v12; // r8
  __m128i v13; // xmm1
  __int64 result; // rax

  v2 = RBX::Time::epochTimeMs((RBX::Time *)this); /*0x106d82d48*/
  v3 = *((unsigned int *)this + 20); /*0x106d82d4d*/
  if ( *((_DWORD *)this + 20) != 0 ) /*0x106d82d53*/
  {
    v4 = *((_DWORD **)this + 9); /*0x106d82d59*/
    v5 = *((unsigned int *)this + 22); /*0x106d82d5d*/
    v6 = v4; /*0x106d82d60*/
    if ( (_DWORD)v5 != 0 ) /*0x106d82d65*/
    {
      v7 = 24 * v5; /*0x106d82d6f*/
      v6 = *((_DWORD **)this + 9); /*0x106d82d73*/
      while ( *v6 >= 0xFFFFFFFE ) /*0x106d82d7a*/
      {
        v6 += 6; /*0x106d82d7c*/
        v7 -= 24; /*0x106d82d80*/
        if ( v7 == 0 ) /*0x106d82d84*/
          goto LABEL_20; /*0x106d82d84*/
      }
    }
    v8 = &v4[6 * v5]; /*0x106d82d8f*/
    if ( v6 == v8 ) /*0x106d82d96*/
    {
LABEL_20:
      v11 = *((_DWORD *)this + 20); /*0x106d82e26*/
    }
    else
    {
      v9 = DFInt::NetworkQualityResponderMaxWaitTime; /*0x106d82d9c*/
      v10 = _mm_cvtepi8_epi32(511); /*0x106d82da3*/
      v11 = *((_DWORD *)this + 20); /*0x106d82dac*/
      do /*0x106d82e1d*/
      {
        v12 = v6 + 6; /*0x106d82dbd*/
        if ( *((_QWORD *)v6 + 2) + 1000 * v9 <= v2 ) /*0x106d82dc4*/
        {
          while ( v12 != v8 && *v12 >= 0xFFFFFFFE ) /*0x106d82de0*/
            v12 += 6; /*0x106d82de2*/
          *v6 = -2; /*0x106d82de8*/
          v13 = _mm_add_epi32(_mm_loadl_epi64(this + 5), v10); /*0x106d82df4*/
          *((_QWORD *)this + 10) = v13.i64[0]; /*0x106d82df8*/
          v9 = DFInt::NetworkQualityResponderMaxWaitTime; /*0x106d82dfd*/
          LODWORD(v5) = *((_DWORD *)this + 22); /*0x106d82e04*/
          v11 = _mm_cvtsi128_si32(v13); /*0x106d82e07*/
        }
        else
        {
          while ( v12 != v8 && *v12 >= 0xFFFFFFFE ) /*0x106d82dcf*/
            v12 += 6; /*0x106d82dd1*/
        }
        v6 = v12; /*0x106d82e17*/
      }
      while ( v12 != &v4[6 * (unsigned int)v5] ); /*0x106d82e1d*/
    }
  }
  else
  {
    v11 = 0; /*0x106d82e21*/
  }
  result = v11 - v3; /*0x106d82e2c*/
  *((_DWORD *)this + 11) += result; /*0x106d82e2f*/
  return result; /*0x106d82e32*/
}

// Address: 0x106d82e38 | Name: __ZN3RBX7Network15SecurityChannel11readMessageENS_16MutableArrayViewIhEEPNS0_20SecurityChannelStatsE
__int64 __fastcall RBX::Network::SecurityChannel::readMessage(
        __int64 a1,
        RBX::Network::SecurityChannel *a2,
        unsigned __int8 *a3,
        unsigned int a4,
        __int64 a5)
{
  int Byte; // r14d
  int UInt32; // r13d
  char v9; // r15
  int v10; // eax
  int v11; // r12d
  unsigned int v12; // r13d
  char v13; // r15
  unsigned int v14; // r14d
  char v15; // al
  int v16; // r15d
  int v17; // eax
  int v18; // esi
  int v19; // edi
  int v20; // r8d
  int v21; // r9d
  int v22; // r10d
  char v23; // r12
  int v24; // r15d
  int v25; // eax
  int v26; // edx
  unsigned int v27; // r14d
  __int64 v29; // rax
  __int64 v30; // r12
  __int64 v31; // [rsp+8h] [rbp-98h]
  _QWORD v32[8]; // [rsp+10h] [rbp-90h] BYREF
  int v33; // [rsp+54h] [rbp-4Ch]
  int v34; // [rsp+58h] [rbp-48h]
  int v35; // [rsp+5Ch] [rbp-44h]
  int v36; // [rsp+60h] [rbp-40h]
  int v37; // [rsp+64h] [rbp-3Ch]
  RBX::Network::SecurityChannel *v38; // [rsp+68h] [rbp-38h]
  unsigned int v39; // [rsp+70h] [rbp-30h]
  int v40; // [rsp+74h] [rbp-2Ch]

  v38 = a2; /*0x106d82e4c*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v32, a2: a3, a3: a4, a4: false); /*0x106d82e64*/
  Byte = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v32); /*0x106d82e71*/
  if ( (unsigned __int8)(Byte + 91) <= 0xFCu ) /*0x106d82e7a*/
  {
    *(_OWORD *)(a1 + 16) = 0; /*0x106d82e7f*/
    *(_DWORD *)a1 = 2; /*0x106d82e83*/
    goto LABEL_20; /*0x106d82e89*/
  }
  v31 = a5; /*0x106d82e92*/
  if ( (_BYTE)Byte == 0xA3 ) /*0x106d82e99*/
  {
    v9 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v32); /*0x106d82eea*/
    RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d82ef4*/
    UInt32 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d82f05*/
    v10 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d82f0f*/
    goto LABEL_7; /*0x106d82f0f*/
  }
  if ( (unsigned __int8)Byte == 162 ) /*0x106d82ea4*/
  {
    RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d82ead*/
    UInt32 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d82ebe*/
    v9 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v32); /*0x106d82ecd*/
    v10 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d82ed7*/
LABEL_7:
    v11 = v10; /*0x106d82f14*/
    goto LABEL_9; /*0x106d82f17*/
  }
  v9 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v32); /*0x106d82f25*/
  v11 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d82f34*/
  RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d82f3e*/
  UInt32 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d82f4f*/
LABEL_9:
  v12 = __ROR4__(~UInt32, Byte + 11); /*0x106d82f52*/
  v13 = __ROR1__(~v9, Byte + 1); /*0x106d82f65*/
  v39 = __ROL4__(~v11, Byte + 9); /*0x106d82f76*/
  if ( v13 == 72 ) /*0x106d82f7d*/
  {
    v15 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v32); /*0x106d82fc0*/
    LODWORD(v38) = Byte + 11; /*0x106d82fe0*/
    if ( v15 == v12 % 0x86 + 121 ) /*0x106d82fe4*/
    {
      v16 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d82ff6*/
      v33 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d83005*/
      v34 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d83014*/
      v35 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d83023*/
      v36 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d83032*/
      v37 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d83041*/
      v17 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d8304b*/
      if ( v31 != 0 ) /*0x106d83058*/
      {
        v40 = __ROL4__(v12, Byte + 20); /*0x106d83073*/
        v40 ^= __ROL4__(~v16, Byte | 8); /*0x106d830d3*/
        v18 = __ROL4__(~v33, Byte + 9) ^ __ROL4__(v12, Byte + 21); /*0x106d830e5*/
        v19 = __ROL4__(~v34, Byte + 10) ^ __ROL4__(v12, Byte + 22); /*0x106d830e8*/
        v20 = __ROL4__(~v35, (char)v38) ^ __ROL4__(v12, Byte + 23); /*0x106d830f5*/
        v21 = __ROL4__(~v36, Byte + 12) ^ __ROL4__(v12, Byte | 0x18); /*0x106d830f8*/
        v22 = __ROL4__(~v37, Byte + 13) ^ __ROL4__(v12, Byte + 25); /*0x106d83103*/
        *(_DWORD *)v31 = v40; /*0x106d8311d*/
        *(_DWORD *)(v31 + 4) = v18; /*0x106d8311f*/
        *(_DWORD *)(v31 + 8) = v19; /*0x106d83122*/
        *(_DWORD *)(v31 + 12) = v20; /*0x106d83125*/
        *(_DWORD *)(v31 + 16) = v21; /*0x106d83129*/
        *(_DWORD *)(v31 + 20) = v22; /*0x106d8312d*/
        *(_DWORD *)(v31 + 24) = __ROL4__(~v17, Byte + 14) ^ __ROL4__(v12, Byte + 26); /*0x106d83131*/
        *(_QWORD *)(v31 + 32) = 0; /*0x106d83135*/
      }
    }
    v23 = Byte + 101; /*0x106d8314f*/
    v24 = __ROR4__( /*0x106d83156*/
            ~(unsigned int)RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32),
            Byte + 101);
    v25 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v32); /*0x106d83160*/
    v26 = __ROL4__(v12, Byte + 21); /*0x106d83176*/
    v27 = v12 ^ v24; /*0x106d8317b*/
    if ( (v12 ^ v24) == (__ROL4__(~v25, v23) ^ v26) ) /*0x106d83183*/
    {
      if ( v27 < 0x1000001 ) /*0x106d8318c*/
      {
        v29 = 0; /*0x106d831e2*/
        v30 = 0; /*0x106d831e4*/
        if ( v24 != v12 ) /*0x106d831ed*/
        {
          v30 = v32[2] + LODWORD(v32[7]); /*0x106d831fa*/
          if ( (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: (RBX::Network::NetworkStream *)v32) < v27 ) /*0x106d83206*/
          {
            *(_OWORD *)(a1 + 16) = 0; /*0x106d8320b*/
            *(_DWORD *)a1 = 6; /*0x106d8320f*/
            goto LABEL_20; /*0x106d83215*/
          }
          RBX::Network::NetworkStream::SetReadOffsetBytes( /*0x106d83224*/
            this: (RBX::Network::NetworkStream *)v32,
            a2: v27 + LODWORD(v32[7]));
          v29 = v27; /*0x106d83229*/
        }
        *(_DWORD *)a1 = 0; /*0x106d8322c*/
        *(_BYTE *)(a1 + 4) = 72; /*0x106d83232*/
        *(_DWORD *)(a1 + 8) = v39; /*0x106d83239*/
        *(_QWORD *)(a1 + 16) = v30; /*0x106d8323c*/
        *(_QWORD *)(a1 + 24) = v29; /*0x106d83240*/
        goto LABEL_21; /*0x106d83244*/
      }
      *(_OWORD *)(a1 + 16) = 0; /*0x106d83191*/
      *(_DWORD *)a1 = 5; /*0x106d83195*/
    }
    else
    {
      *(_OWORD *)(a1 + 16) = 0; /*0x106d831af*/
      *(_DWORD *)a1 = 4; /*0x106d831b3*/
    }
LABEL_20:
    *(_BYTE *)(a1 + 4) = 117; /*0x106d831b9*/
    *(_DWORD *)(a1 + 8) = 0; /*0x106d831bd*/
    goto LABEL_21; /*0x106d831bd*/
  }
  if ( v13 != 98 ) /*0x106d82f86*/
  {
    *(_OWORD *)(a1 + 16) = 0; /*0x106d831a0*/
    *(_DWORD *)a1 = 3; /*0x106d831a4*/
    goto LABEL_20; /*0x106d831aa*/
  }
  v14 = v39; /*0x106d82f90*/
  RBX::Network::SecurityChannel::onAck(this: (__m128i *)v38, a2: v39); /*0x106d82f97*/
  *(_OWORD *)(a1 + 16) = 0; /*0x106d82f9f*/
  *(_DWORD *)a1 = 0; /*0x106d82fa3*/
  *(_BYTE *)(a1 + 4) = 98; /*0x106d82fa9*/
  *(_DWORD *)(a1 + 8) = v14; /*0x106d82fad*/
LABEL_21:
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v32); /*0x106d831c4*/
  return a1; /*0x106d831d3*/
}

// Address: 0x106d83270 | Name: __ZN3RBX7Network15SecurityChannel22readMessage_deprecatedEPN6RakNet6PacketEPNS0_20SecurityChannelStatsE
__int64 __fastcall RBX::Network::SecurityChannel::readMessage_deprecated(
        __int64 a1,
        RBX::Network::SecurityChannel *a2,
        __int64 a3,
        __int64 a4)
{
  int Byte; // r14d
  int UInt32; // r13d
  char v8; // r15
  int v9; // eax
  int v10; // r12d
  unsigned int v11; // r13d
  char v12; // r15
  unsigned int v13; // r14d
  char v14; // al
  int v15; // r15d
  int v16; // eax
  int v17; // esi
  int v18; // edi
  int v19; // r8d
  int v20; // r9d
  int v21; // r10d
  char v22; // r12
  int v23; // r15d
  int v24; // eax
  int v25; // edx
  unsigned int v26; // r14d
  __int64 v28; // rax
  __int64 v29; // r12
  __int64 v30; // [rsp+8h] [rbp-98h]
  _QWORD v31[8]; // [rsp+10h] [rbp-90h] BYREF
  int v32; // [rsp+54h] [rbp-4Ch]
  int v33; // [rsp+58h] [rbp-48h]
  int v34; // [rsp+5Ch] [rbp-44h]
  int v35; // [rsp+60h] [rbp-40h]
  int v36; // [rsp+64h] [rbp-3Ch]
  RBX::Network::SecurityChannel *v37; // [rsp+68h] [rbp-38h]
  unsigned int v38; // [rsp+70h] [rbp-30h]
  int v39; // [rsp+74h] [rbp-2Ch]

  v37 = a2; /*0x106d83284*/
  RBX::Network::NetworkStream::NetworkStream( /*0x106d8329e*/
    this: (RBX::Network::NetworkStream *)v31,
    a2: *(unsigned __int8 **)(a3 + 56),
    a3: *(_DWORD *)(a3 + 48),
    a4: false);
  Byte = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v31); /*0x106d832ab*/
  if ( (unsigned __int8)(Byte + 91) <= 0xFCu ) /*0x106d832b4*/
  {
    *(_OWORD *)(a1 + 16) = 0; /*0x106d832b9*/
    *(_DWORD *)a1 = 2; /*0x106d832bd*/
    goto LABEL_20; /*0x106d832c3*/
  }
  v30 = a4; /*0x106d832cc*/
  if ( (_BYTE)Byte == 0xA3 ) /*0x106d832d3*/
  {
    v8 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v31); /*0x106d83324*/
    RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d8332e*/
    UInt32 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d8333f*/
    v9 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d83349*/
    goto LABEL_7; /*0x106d83349*/
  }
  if ( (unsigned __int8)Byte == 162 ) /*0x106d832de*/
  {
    RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d832e7*/
    UInt32 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d832f8*/
    v8 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v31); /*0x106d83307*/
    v9 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d83311*/
LABEL_7:
    v10 = v9; /*0x106d8334e*/
    goto LABEL_9; /*0x106d83351*/
  }
  v8 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v31); /*0x106d8335f*/
  v10 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d8336e*/
  RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d83378*/
  UInt32 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d83389*/
LABEL_9:
  v11 = __ROR4__(~UInt32, Byte + 11); /*0x106d8338c*/
  v12 = __ROR1__(~v8, Byte + 1); /*0x106d8339f*/
  v38 = __ROL4__(~v10, Byte + 9); /*0x106d833b0*/
  if ( v12 == 72 ) /*0x106d833b7*/
  {
    v14 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v31); /*0x106d833fa*/
    LODWORD(v37) = Byte + 11; /*0x106d8341a*/
    if ( v14 == v11 % 0x86 + 121 ) /*0x106d8341e*/
    {
      v15 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d83430*/
      v32 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d8343f*/
      v33 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d8344e*/
      v34 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d8345d*/
      v35 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d8346c*/
      v36 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d8347b*/
      v16 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d83485*/
      if ( v30 != 0 ) /*0x106d83492*/
      {
        v39 = __ROL4__(v11, Byte + 20); /*0x106d834ad*/
        v39 ^= __ROL4__(~v15, Byte | 8); /*0x106d8350d*/
        v17 = __ROL4__(~v32, Byte + 9) ^ __ROL4__(v11, Byte + 21); /*0x106d8351f*/
        v18 = __ROL4__(~v33, Byte + 10) ^ __ROL4__(v11, Byte + 22); /*0x106d83522*/
        v19 = __ROL4__(~v34, (char)v37) ^ __ROL4__(v11, Byte + 23); /*0x106d8352f*/
        v20 = __ROL4__(~v35, Byte + 12) ^ __ROL4__(v11, Byte | 0x18); /*0x106d83532*/
        v21 = __ROL4__(~v36, Byte + 13) ^ __ROL4__(v11, Byte + 25); /*0x106d8353d*/
        *(_DWORD *)v30 = v39; /*0x106d83557*/
        *(_DWORD *)(v30 + 4) = v17; /*0x106d83559*/
        *(_DWORD *)(v30 + 8) = v18; /*0x106d8355c*/
        *(_DWORD *)(v30 + 12) = v19; /*0x106d8355f*/
        *(_DWORD *)(v30 + 16) = v20; /*0x106d83563*/
        *(_DWORD *)(v30 + 20) = v21; /*0x106d83567*/
        *(_DWORD *)(v30 + 24) = __ROL4__(~v16, Byte + 14) ^ __ROL4__(v11, Byte + 26); /*0x106d8356b*/
        *(_QWORD *)(v30 + 32) = 0; /*0x106d8356f*/
      }
    }
    v22 = Byte + 101; /*0x106d83589*/
    v23 = __ROR4__( /*0x106d83590*/
            ~(unsigned int)RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31),
            Byte + 101);
    v24 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v31); /*0x106d8359a*/
    v25 = __ROL4__(v11, Byte + 21); /*0x106d835b0*/
    v26 = v11 ^ v23; /*0x106d835b5*/
    if ( (v11 ^ v23) == (__ROL4__(~v24, v22) ^ v25) ) /*0x106d835bd*/
    {
      if ( v26 < 0x1000001 ) /*0x106d835c6*/
      {
        v28 = 0; /*0x106d8361c*/
        v29 = 0; /*0x106d8361e*/
        if ( v23 != v11 ) /*0x106d83627*/
        {
          v29 = v31[2] + LODWORD(v31[7]); /*0x106d83634*/
          if ( (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: (RBX::Network::NetworkStream *)v31) < v26 ) /*0x106d83640*/
          {
            *(_OWORD *)(a1 + 16) = 0; /*0x106d83645*/
            *(_DWORD *)a1 = 6; /*0x106d83649*/
            goto LABEL_20; /*0x106d8364f*/
          }
          RBX::Network::NetworkStream::SetReadOffsetBytes( /*0x106d8365e*/
            this: (RBX::Network::NetworkStream *)v31,
            a2: v26 + LODWORD(v31[7]));
          v28 = v26; /*0x106d83663*/
        }
        *(_DWORD *)a1 = 0; /*0x106d83666*/
        *(_BYTE *)(a1 + 4) = 72; /*0x106d8366c*/
        *(_DWORD *)(a1 + 8) = v38; /*0x106d83673*/
        *(_QWORD *)(a1 + 16) = v29; /*0x106d83676*/
        *(_QWORD *)(a1 + 24) = v28; /*0x106d8367a*/
        goto LABEL_21; /*0x106d8367e*/
      }
      *(_OWORD *)(a1 + 16) = 0; /*0x106d835cb*/
      *(_DWORD *)a1 = 5; /*0x106d835cf*/
    }
    else
    {
      *(_OWORD *)(a1 + 16) = 0; /*0x106d835e9*/
      *(_DWORD *)a1 = 4; /*0x106d835ed*/
    }
LABEL_20:
    *(_BYTE *)(a1 + 4) = 117; /*0x106d835f3*/
    *(_DWORD *)(a1 + 8) = 0; /*0x106d835f7*/
    goto LABEL_21; /*0x106d835f7*/
  }
  if ( v12 != 98 ) /*0x106d833c0*/
  {
    *(_OWORD *)(a1 + 16) = 0; /*0x106d835da*/
    *(_DWORD *)a1 = 3; /*0x106d835de*/
    goto LABEL_20; /*0x106d835e4*/
  }
  v13 = v38; /*0x106d833ca*/
  RBX::Network::SecurityChannel::onAck(this: (__m128i *)v37, a2: v38); /*0x106d833d1*/
  *(_OWORD *)(a1 + 16) = 0; /*0x106d833d9*/
  *(_DWORD *)a1 = 0; /*0x106d833dd*/
  *(_BYTE *)(a1 + 4) = 98; /*0x106d833e3*/
  *(_DWORD *)(a1 + 8) = v13; /*0x106d833e7*/
LABEL_21:
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v31); /*0x106d835fe*/
  return a1; /*0x106d8360d*/
}

// Address: 0x106d836aa | Name: __ZN3RBX7Network15SecurityChannel13sendMessageV2ERNS_11NetworkBase18ConnectionInternalEhNS_9ArrayViewIhEEjby
__int64 __fastcall RBX::Network::SecurityChannel::sendMessageV2(
        RBX::Network::SecurityChannel *a1,
        RBX::NetworkBase::ConnectionInternal *a2,
        int a3,
        void *a4,
        __int64 a5,
        unsigned int a6,
        unsigned __int8 a7,
        unsigned __int64 a8)
{
  int v10; // r13d
  RBX *v11; // rdi
  unsigned int v12; // ebx
  RBX *v13; // rdi
  unsigned int v14; // r15d
  RBX *v15; // rdi
  unsigned int v16; // r14d
  RBX *v17; // rdi
  unsigned int v18; // eax
  int v19; // r12d
  unsigned __int64 v20; // r14
  int v21; // r12d
  int v22; // ebx
  int v23; // r15d
  char v24; // r13
  __int64 v25; // rbx
  unsigned __int8 TracerPeerId; // al
  __int64 v27; // rbx
  int v28; // ebx
  std::__shared_weak_count *v29; // r15
  unsigned int v30; // ebx
  RBX::Network::NetworkTracer *v31; // rdi
  RBX *v33; // rdi
  __int64 v34; // [rsp+0h] [rbp-F0h] BYREF
  std::__shared_weak_count *v35; // [rsp+8h] [rbp-E8h]
  void *v36; // [rsp+10h] [rbp-E0h]
  RBX::NetworkBase::ConnectionInternal *v37; // [rsp+18h] [rbp-D8h]
  _BYTE v38[64]; // [rsp+20h] [rbp-D0h] BYREF
  int v39; // [rsp+60h] [rbp-90h]
  unsigned int v40; // [rsp+64h] [rbp-8Ch]
  int v41; // [rsp+68h] [rbp-88h]
  int v42; // [rsp+6Ch] [rbp-84h]
  int v43; // [rsp+70h] [rbp-80h]
  int v44; // [rsp+74h] [rbp-7Ch]
  int v45; // [rsp+78h] [rbp-78h]
  int v46; // [rsp+7Ch] [rbp-74h]
  RBX::Network::SecurityChannel *v47; // [rsp+80h] [rbp-70h]
  unsigned int v48[3]; // [rsp+88h] [rbp-68h]
  unsigned int v49; // [rsp+94h] [rbp-5Ch]
  _DWORD v50[10]; // [rsp+98h] [rbp-58h] BYREF
  int v51; // [rsp+C0h] [rbp-30h]
  char v52; // [rsp+C7h] [rbp-29h]

  *(_QWORD *)v48 = a5; /*0x106d836c1*/
  v36 = a4; /*0x106d836c5*/
  v37 = a2; /*0x106d836cf*/
  v47 = a1; /*0x106d836d6*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v38); /*0x106d836e1*/
  if ( (_BYTE)`guard variable for'`anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset == 0 /*0x106d83d0f*/
    && __cxa_guard_acquire(a1: &`guard variable for'`anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset) != 0 )
  {
    `anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset = (unsigned int)RBX::globalRand(this: v33) /*0x106d83d31*/
                                                                                  % 0xF;
    __cxa_guard_release(a1: &`guard variable for'`anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset); /*0x106d83d3e*/
  }
  v10 = 164; /*0x106d83714*/
  if ( __ROR4__(-858993459 * (a6 + `anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset), 1) >= 0x1999999Au ) /*0x106d8371a*/
    v10 = ((((_BYTE)a6 + (_BYTE)`anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset) & 7) == 0) /*0x106d8371a*/
        | 0xA2;
  LOBYTE(v50[0]) = v10; /*0x106d83722*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 1u); /*0x106d83731*/
  v49 = a6; /*0x106d83736*/
  v12 = RBX::globalRand(this: v11); /*0x106d8373e*/
  v14 = RBX::globalRand(this: v13); /*0x106d83745*/
  v16 = RBX::globalRand(this: v15); /*0x106d8374d*/
  v18 = RBX::globalRand(this: v17); /*0x106d83750*/
  v39 = a3; /*0x106d837c3*/
  v52 = __ROL1__(a3, v10 + 1); /*0x106d837d0*/
  v19 = __ROR4__(v49, v10 + 9); /*0x106d837e6*/
  v40 = v18 % 0x85 + 122; /*0x106d837e9*/
  v20 = (((((v12 % 0x85) << 8) + 31232) | (v14 % 0x85 + 122)) << 16) | v40 | (((v16 % 0x85) << 8) + 31232); /*0x106d837f2*/
  v51 = v10 + 11; /*0x106d837fc*/
  RBX::Network::SecurityChannel::getStats(this: (RBX::Network::SecurityChannel *)v50, a2: (__int64)v47); /*0x106d83809*/
  v42 = __ROR4__(v50[0] ^ __ROL4__(v20, v10 + 20), v10 | 8); /*0x106d83822*/
  v41 = __ROL4__(v20, v10 + 21); /*0x106d83834*/
  v43 = __ROR4__(v41 ^ v50[1], v10 + 9); /*0x106d83841*/
  v44 = __ROR4__(v50[2] ^ __ROL4__(v20, v10 + 22), v10 + 10); /*0x106d83856*/
  v51 = __ROR4__(v50[3] ^ __ROL4__(v20, v10 + 23), v51); /*0x106d8386a*/
  v45 = __ROR4__(v50[4] ^ __ROL4__(v20, v10 | 0x18), v10 + 12); /*0x106d83881*/
  v46 = __ROR4__(v50[5] ^ __ROL4__(v20, v10 + 25), v10 + 13); /*0x106d8389b*/
  v21 = ~v19; /*0x106d8389e*/
  v22 = ~__ROL4__(v20, v10 + 11); /*0x106d838a1*/
  v23 = __ROR4__(v50[6] ^ __ROL4__(v20, v10 + 26), v10 + 14); /*0x106d838b5*/
  if ( (_BYTE)v10 == 0xA3 ) /*0x106d838be*/
  {
    LOBYTE(v50[0]) = ~v52; /*0x106d8394d*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 1u); /*0x106d8395b*/
    v50[0] = ~__ROL4__(__ROL4__(v20, 22) ^ 1, 22); /*0x106d83972*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83980*/
    v50[0] = v22; /*0x106d83989*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83997*/
    v50[0] = v21; /*0x106d839a0*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d839af*/
  }
  else
  {
    if ( (unsigned __int8)v10 == 162 ) /*0x106d838cd*/
    {
      v52 = ~v52; /*0x106d838d3*/
      v50[0] = ~__ROL4__(__ROL4__(v20, 21) ^ 1, 23); /*0x106d838e8*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d838f6*/
      v50[0] = v22; /*0x106d838ff*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d8390d*/
      LOBYTE(v50[0]) = v52; /*0x106d83919*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 1u); /*0x106d83927*/
      v50[0] = v21; /*0x106d83930*/
    }
    else
    {
      LOBYTE(v50[0]) = ~v52; /*0x106d839ba*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 1u); /*0x106d839c8*/
      v50[0] = v21; /*0x106d839d1*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d839e0*/
      v50[0] = ~__ROR4__(__ROL4__(v20, v10 + 19) ^ 1, v10 + 7); /*0x106d839fd*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83a0b*/
      v50[0] = v22; /*0x106d83a14*/
    }
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d8393f*/
  }
  if ( (_BYTE)v39 == 72 ) /*0x106d83a2e*/
  {
    if ( *(_BYTE *)v47 == 70 ) /*0x106d83a54*/
    {
      LOBYTE(v50[0]) = v40 - -122 * (v20 / 0x86) + 121; /*0x106d83a61*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 1u); /*0x106d83a6f*/
      v50[0] = ~v42; /*0x106d83a80*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83a8e*/
      v50[0] = ~v43; /*0x106d83a9c*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83aaa*/
      v50[0] = ~v44; /*0x106d83ab8*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83ac6*/
      v50[0] = ~v51; /*0x106d83ad4*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83ae2*/
      v50[0] = ~v45; /*0x106d83af0*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83afe*/
      v50[0] = ~v46; /*0x106d83b0c*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83b1a*/
      v50[0] = ~v23; /*0x106d83b26*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83b35*/
    }
    else
    {
      LOBYTE(v50[0]) = -122 - (v40 - -122 * (v20 / 0x86)); /*0x106d83b44*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 1u); /*0x106d83b52*/
    }
    v24 = v10 + 101; /*0x106d83b57*/
    v50[0] = ~__ROL4__(v48[0] ^ v20, v24); /*0x106d83b6c*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83b7b*/
    v50[0] = ~__ROR4__(v48[0] ^ v41, v24); /*0x106d83b94*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v50, a3: 4u); /*0x106d83ba2*/
    if ( *(_QWORD *)v48 != 0 ) /*0x106d83bac*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v38, a2: v36, a3: v48[0]); /*0x106d83bc0*/
  }
  if ( a8 != 0 && DFFlag::EnablePingPongPerformanceTraceCLI != 0 ) /*0x106d83bda*/
  {
    if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x106d83be6*/
      v25 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x106d83be8*/
    else
      v25 = 0; /*0x106d83bee*/
    TracerPeerId = RBX::NetworkBase::ConnectionInternal::getTracerPeerId(this: v37); /*0x106d83bf7*/
    RBX::Network::NetworkTracer::addCheckpointToTracer(a1: v25, a2: a8, a3: TracerPeerId, a4: 2); /*0x106d83c0a*/
  }
  v27 = operator new(a1: 0x58u); /*0x106d83c19*/
  *(_OWORD *)(v27 + 8) = 0; /*0x106d83c23*/
  *(_QWORD *)v27 = &off_10CAAE190; /*0x106d83c2e*/
  RBX::Network::NetworkStream::NetworkStream(a1: v27 + 24, a2: v38); /*0x106d83c42*/
  v34 = v27 + 24; /*0x106d83c4e*/
  v35 = (std::__shared_weak_count *)v27; /*0x106d83c51*/
  v28 = (*(__int64 (__fastcall **)(RBX::NetworkBase::ConnectionInternal *, _QWORD, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v37 + 48LL))( /*0x106d83c6f*/
          a1: v37,
          a2: 2 * (unsigned int)a7 + 8,
          a3: &v34,
          a4: 0,
          a5: 0);
  v29 = v35; /*0x106d83c71*/
  if ( v35 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v35 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106d83c8d*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v29 + 16LL))(a1: v29); /*0x106d83c95*/
    std::__shared_weak_count::__release_weak(this: v29); /*0x106d83c9b*/
  }
  if ( v28 != 0 ) /*0x106d83ca2*/
  {
    v30 = 0; /*0x106d83ca4*/
    RBX::Network::SecurityChannel::onSent(this: v47, a2: v49); /*0x106d83cad*/
  }
  else
  {
    v30 = 7; /*0x106d83cb4*/
    if ( a8 != 0 && DFFlag::EnablePingPongPerformanceTraceCLI != 0 ) /*0x106d83cc3*/
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x106d83ccf*/
        v31 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x106d83cd1*/
      else
        v31 = nullptr; /*0x106d83cd7*/
      RBX::Network::NetworkTracer::removeTracerObject(this: v31, a2: a8); /*0x106d83cdc*/
    }
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v38); /*0x106d83ce8*/
  return v30; /*0x106d83cef*/
}

// Address: 0x106d83d88 | Name: __ZN3RBX7Network15SecurityChannel22sendMessage_deprecatedEPN6RakNet16RakPeerInterfaceERKNS2_13SystemAddressEhNS_9ArrayViewIhEEjby
__int64 __fastcall RBX::Network::SecurityChannel::sendMessage_deprecated(
        RBX::Network::SecurityChannel *a1,
        __int64 a2,
        const RakNet::SystemAddress *a3,
        int a4,
        const void *a5,
        __int64 a6,
        unsigned int a7,
        unsigned __int8 a8,
        unsigned __int64 a9)
{
  int v10; // r12d
  RBX *v11; // rdi
  unsigned int v12; // r13d
  RBX *v13; // rdi
  unsigned int v14; // r14d
  RBX *v15; // rdi
  unsigned int v16; // r15d
  RBX *v17; // rdi
  unsigned int v18; // eax
  unsigned __int64 v19; // r15
  int v20; // ebx
  int v21; // r13d
  int v22; // r14d
  char v23; // r12
  __int64 v24; // r14
  unsigned __int8 v25; // r15
  RakNet *v26; // rdi
  unsigned int TimeMS; // eax
  unsigned int v28; // r14d
  RBX::Network::NetworkTracer *v29; // rdi
  RBX *v31; // rdi
  _BYTE v35[64]; // [rsp+30h] [rbp-D0h] BYREF
  int v36; // [rsp+70h] [rbp-90h]
  unsigned int v37; // [rsp+74h] [rbp-8Ch]
  int v38; // [rsp+78h] [rbp-88h]
  int v39; // [rsp+7Ch] [rbp-84h]
  int v40; // [rsp+80h] [rbp-80h]
  int v41; // [rsp+84h] [rbp-7Ch]
  int v42; // [rsp+88h] [rbp-78h]
  int v43; // [rsp+8Ch] [rbp-74h]
  RBX::Network::SecurityChannel *v44; // [rsp+90h] [rbp-70h]
  unsigned int v45[2]; // [rsp+98h] [rbp-68h]
  _DWORD v46[12]; // [rsp+A0h] [rbp-60h] BYREF
  int v47; // [rsp+D0h] [rbp-30h]
  char v48; // [rsp+D7h] [rbp-29h]

  *(_QWORD *)v45 = a6; /*0x106d83d9c*/
  v44 = a1; /*0x106d83db7*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v35); /*0x106d83dc2*/
  if ( (_BYTE)`guard variable for'`anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset == 0 /*0x106d843d4*/
    && __cxa_guard_acquire(a1: &`guard variable for'`anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset) != 0 )
  {
    `anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset = (unsigned int)RBX::globalRand(this: v31) /*0x106d843f6*/
                                                                                  % 0xF;
    __cxa_guard_release(a1: &`guard variable for'`anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset); /*0x106d84403*/
  }
  v10 = 164; /*0x106d83df6*/
  if ( __ROR4__(-858993459 * (a7 + `anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset), 1) >= 0x1999999Au ) /*0x106d83dfc*/
    v10 = ((((_BYTE)a7 + (_BYTE)`anonymous namespace'::selectSecurityMessageId(unsigned int)::kSequenceOffset) & 7) == 0) /*0x106d83dfc*/
        | 0xA2;
  LOBYTE(v46[0]) = v10; /*0x106d83e04*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 1u); /*0x106d83e13*/
  v12 = RBX::globalRand(this: v11); /*0x106d83e1d*/
  v14 = RBX::globalRand(this: v13); /*0x106d83e25*/
  v16 = RBX::globalRand(this: v15); /*0x106d83e2d*/
  v18 = RBX::globalRand(this: v17); /*0x106d83e30*/
  v36 = a4; /*0x106d83ea9*/
  v48 = __ROL1__(a4, v10 + 1); /*0x106d83eb4*/
  v37 = v18 % 0x85 + 122; /*0x106d83ecc*/
  v19 = (((((v12 % 0x85) << 8) + 31232) | (v14 % 0x85 + 122)) << 16) | v37 | (((v16 % 0x85) << 8) + 31232); /*0x106d83ed5*/
  v47 = v10 + 11; /*0x106d83ee0*/
  RBX::Network::SecurityChannel::getStats(this: (RBX::Network::SecurityChannel *)v46, a2: (__int64)v44); /*0x106d83eee*/
  v39 = __ROR4__(v46[0] ^ __ROL4__(v19, v10 + 20), v10 | 8); /*0x106d83f08*/
  v38 = __ROL4__(v19, v10 + 21); /*0x106d83f1b*/
  v40 = __ROR4__(v38 ^ v46[1], v10 + 9); /*0x106d83f28*/
  v41 = __ROR4__(v46[2] ^ __ROL4__(v19, v10 + 22), v10 + 10); /*0x106d83f3f*/
  v47 = __ROR4__(v46[3] ^ __ROL4__(v19, v10 + 23), v47); /*0x106d83f54*/
  v42 = __ROR4__(v46[4] ^ __ROL4__(v19, v10 | 0x18), v10 + 12); /*0x106d83f6c*/
  v43 = __ROR4__(v46[5] ^ __ROL4__(v19, v10 + 25), v10 + 13); /*0x106d83f88*/
  v20 = ~__ROR4__(a7, v10 + 9); /*0x106d83f8b*/
  v21 = ~__ROL4__(v19, v10 + 11); /*0x106d83f8d*/
  v22 = __ROR4__(v46[6] ^ __ROL4__(v19, v10 + 26), v10 + 14); /*0x106d83fa4*/
  if ( (_BYTE)v10 == 0xA3 ) /*0x106d83fad*/
  {
    LOBYTE(v46[0]) = ~v48; /*0x106d8403c*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 1u); /*0x106d8404a*/
    v46[0] = ~__ROL4__(__ROL4__(v19, 22) ^ 1, 22); /*0x106d84061*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d8406f*/
    v46[0] = v21; /*0x106d84078*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d84087*/
    v46[0] = v20; /*0x106d84090*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d8409e*/
  }
  else
  {
    if ( (unsigned __int8)v10 == 162 ) /*0x106d83fbc*/
    {
      v48 = ~v48; /*0x106d83fc2*/
      v46[0] = ~__ROL4__(__ROL4__(v19, 21) ^ 1, 23); /*0x106d83fd7*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d83fe5*/
      v46[0] = v21; /*0x106d83fee*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d83ffd*/
      LOBYTE(v46[0]) = v48; /*0x106d84009*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 1u); /*0x106d84017*/
      v46[0] = v20; /*0x106d84020*/
    }
    else
    {
      LOBYTE(v46[0]) = ~v48; /*0x106d840a9*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 1u); /*0x106d840b7*/
      v46[0] = v20; /*0x106d840c0*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d840ce*/
      v46[0] = ~__ROR4__(__ROL4__(v19, v10 + 19) ^ 1, v10 + 7); /*0x106d840ed*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d840fb*/
      v46[0] = v21; /*0x106d84104*/
    }
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d8402e*/
  }
  if ( (_BYTE)v36 == 72 ) /*0x106d8411f*/
  {
    if ( *(_BYTE *)v44 == 70 ) /*0x106d84145*/
    {
      LOBYTE(v46[0]) = v37 - -122 * (v19 / 0x86) + 121; /*0x106d84152*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 1u); /*0x106d84160*/
      v46[0] = ~v39; /*0x106d84171*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d8417f*/
      v46[0] = ~v40; /*0x106d8418d*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d8419b*/
      v46[0] = ~v41; /*0x106d841a9*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d841b7*/
      v46[0] = ~v47; /*0x106d841c5*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d841d3*/
      v46[0] = ~v42; /*0x106d841e1*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d841ef*/
      v46[0] = ~v43; /*0x106d841fd*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d8420b*/
      v46[0] = ~v22; /*0x106d84217*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d84226*/
    }
    else
    {
      LOBYTE(v46[0]) = -122 - (v37 - -122 * (v19 / 0x86)); /*0x106d84235*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 1u); /*0x106d84243*/
    }
    v23 = v10 + 101; /*0x106d84248*/
    v46[0] = ~__ROL4__(v45[0] ^ v19, v23); /*0x106d8425d*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d8426c*/
    v46[0] = ~__ROR4__(v45[0] ^ v38, v23); /*0x106d84285*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v46, a3: 4u); /*0x106d84293*/
    if ( *(_QWORD *)v45 != 0 ) /*0x106d8429d*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: a5, a3: v45[0]); /*0x106d842b1*/
  }
  if ( a9 != 0 && DFFlag::EnablePingPongPerformanceTraceCLI != 0 ) /*0x106d842cb*/
  {
    if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x106d842d7*/
      v24 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x106d842d9*/
    else
      v24 = 0; /*0x106d842df*/
    v25 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a2 + 200LL))(a1: a2); /*0x106d842f2*/
    TimeMS = RakNet::GetTimeMS(this: v26); /*0x106d842f5*/
    RBX::Network::NetworkTracer::addCheckpointToTracer_deprecated(a1: v24, a2: a9, a3: v25, a4: 2, a5: TimeMS); /*0x106d8430c*/
  }
  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v46, a2: a3); /*0x106d8431c*/
  if ( (*(unsigned int (__fastcall **)(__int64, _BYTE *, _QWORD, __int64, __int64, _DWORD *, _DWORD, _DWORD, unsigned __int64))(*(_QWORD *)a2 + 184LL))( /*0x106d84364*/
         a1: a2,
         a2: v35,
         a3: 2 * (a8 ^ 1u),
         a4: 3,
         a5: 1,
         a6: v46,
         a7: 0,
         a8: 0,
         a9) != 0 )
  {
    v28 = 0; /*0x106d84366*/
    RBX::Network::SecurityChannel::onSent(this: v44, a2: a7); /*0x106d84370*/
  }
  else
  {
    v28 = 7; /*0x106d84377*/
    if ( a9 != 0 && DFFlag::EnablePingPongPerformanceTraceCLI != 0 ) /*0x106d84387*/
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x106d84393*/
        v29 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x106d84395*/
      else
        v29 = nullptr; /*0x106d8439b*/
      RBX::Network::NetworkTracer::removeTracerObject(this: v29, a2: a9); /*0x106d843a0*/
    }
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v35); /*0x106d843ac*/
  return v28; /*0x106d843b4*/
}

// Address: 0x106d8443c | Name: __ZN3RBX7Network15SecurityChannel16sendMessageReqV2ERNS_11NetworkBase18ConnectionInternalENS_9ArrayViewIhEEbby
__int64 __fastcall RBX::Network::SecurityChannel::sendMessageReqV2(
        RBX::Network::SecurityChannel *a1,
        RBX::NetworkBase::ConnectionInternal *a2,
        void *a3,
        __int64 a4,
        __int64 a5,
        unsigned __int8 a6,
        unsigned __int64 a7)
{
  return RBX::Network::SecurityChannel::sendMessageV2(a1, a2, a3: 72, a4: a3, a5: a4, a6: 0, a7: a6, a8: a7); /*0x106d8446a*/
}

// Address: 0x106d844ce | Name: __ZN3RBX7Network15SecurityChannel25sendMessageReq_deprecatedEPN6RakNet16RakPeerInterfaceERKNS2_13SystemAddressENS_9ArrayViewIhEEbby
__int64 __fastcall RBX::Network::SecurityChannel::sendMessageReq_deprecated(
        RBX::Network::SecurityChannel *a1,
        __int64 a2,
        const RakNet::SystemAddress *a3,
        const void *a4,
        __int64 a5,
        __int64 a6,
        unsigned __int8 a7,
        unsigned __int64 a8)
{
  unsigned int v8; // ebx

  v8 = 7; /*0x106d844db*/
  if ( a2 != 0 ) /*0x106d844e3*/
    return (unsigned int)RBX::Network::SecurityChannel::sendMessage_deprecated( /*0x106d84512*/
                           a1,
                           a2,
                           a3,
                           a4: 72,
                           a5: a4,
                           a6: a5,
                           a7: 0,
                           a8: a7,
                           a9: a8);
  return v8; /*0x106d84516*/
}

// Address: 0x106d84578 | Name: __ZN3RBX7Network15SecurityChannel25sendMessageAck_deprecatedEPN6RakNet16RakPeerInterfaceERKNS2_13SystemAddressEj
__int64 __fastcall RBX::Network::SecurityChannel::sendMessageAck_deprecated(
        RBX::Network::SecurityChannel *this,
        RakNet::RakPeerInterface *a2,
        const RakNet::SystemAddress *a3,
        unsigned int a4)
{
  return RBX::Network::SecurityChannel::sendMessage_deprecated( /*0x106d845aa*/
           a1: this,
           (__int64)a2,
           a3,
           a4: 98,
           a5: nullptr,
           a6: 0,
           a7: a4,
           a8: 1u,
           a9: 0);
}

// Address: 0x106d8460e | Name: __ZN3RBX7Network15SecurityChannel16sendMessageAckV2ERNS_11NetworkBase18ConnectionInternalEj
__int64 __fastcall RBX::Network::SecurityChannel::sendMessageAckV2(
        RBX::Network::SecurityChannel *this,
        RBX::NetworkBase::ConnectionInternal *a2,
        unsigned int a3)
{
  return RBX::Network::SecurityChannel::sendMessageV2(a1: this, a2, a3: 98, a4: nullptr, a5: 0, a6: a3, a7: 1u, a8: 0); /*0x106d8463e*/
}

// END SecurityChannel part 1/1, 19 functions
