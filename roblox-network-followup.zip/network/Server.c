// Server -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 88 functions


// Address: 0x106879238 | Name: __ZN3RBX7Network6ServerC2ERNS_28ForceConstructionInCreatableE
__int64 *__fastcall RBX::Network::Server::Server(RBX::Network::Server *a1)
{
  unsigned __int64 v2; // rcx
  char *v3; // rax
  unsigned __int64 v4; // rdx
  unsigned __int64 v5; // rsi
  __int64 v6; // rcx
  char *v7; // rcx
  RSL::Arena *v8; // rdi
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // r8
  __int64 v12; // r9
  RBX::Security::Context *v13; // rdi
  __int64 v14; // rax
  __int64 v15; // rdx
  __int64 v16; // rcx
  RBX::InstanceStitchingHandler *v17; // rdi
  __int64 *result; // rax
  _BYTE v19[16]; // [rsp+A8h] [rbp-48h] BYREF
  void *v20; // [rsp+B8h] [rbp-38h]

  RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer>::DescribedCreatable<RBX::ForceConstructionInCreatable &>(); /*0x10687924f*/
  *((_BYTE *)a1 + 472) = 1; /*0x106879254*/
  *(_QWORD *)a1 = off_10CAF2AC8; /*0x106879266*/
  *((_QWORD *)a1 + 22) = off_10CAF2D70; /*0x106879270*/
  *((_QWORD *)a1 + 58) = &off_10CAF2DD8; /*0x10687927d*/
  *(_QWORD *)((char *)a1 + 476) = 0; /*0x106879284*/
  *(_OWORD *)((char *)a1 + 488) = 0; /*0x106879299*/
  *(_OWORD *)((char *)a1 + 504) = 0; /*0x1068792a0*/
  *(_OWORD *)((char *)a1 + 520) = 0; /*0x1068792a7*/
  *((_DWORD *)a1 + 134) = 0; /*0x1068792ae*/
  RBX::Network::MegaReplicator::MegaReplicator(this: (RBX::Network::Server *)((char *)a1 + 544), a2: true, a3: a1); /*0x1068792c4*/
  *((_DWORD *)a1 + 1125) = 0; /*0x10687930f*/
  *(_OWORD *)((char *)a1 + 4440) = 0; /*0x10687931c*/
  *(_OWORD *)((char *)a1 + 4456) = 0; /*0x106879323*/
  *(_OWORD *)((char *)a1 + 4472) = 0; /*0x10687932a*/
  *(_OWORD *)((char *)a1 + 4482) = 0; /*0x106879331*/
  *((_QWORD *)a1 + 563) = 0xBFF0000000000000LL; /*0x106879342*/
  *((_OWORD *)a1 + 282) = 0; /*0x106879365*/
  *(_OWORD *)((char *)a1 + 4521) = 0; /*0x10687936c*/
  *((_QWORD *)a1 + 568) = 16; /*0x106879378*/
  *((_QWORD *)a1 + 569) = 0; /*0x106879381*/
  *((_DWORD *)a1 + 1140) = 1065353216; /*0x10687938d*/
  *(_OWORD *)((char *)a1 + 4568) = 0; /*0x10687939e*/
  *((_BYTE *)a1 + 4584) = 0; /*0x1068793a5*/
  *((_QWORD *)a1 + 574) = 16; /*0x1068793ab*/
  *((_QWORD *)a1 + 575) = 0; /*0x1068793b2*/
  *((_DWORD *)a1 + 1152) = 1065353216; /*0x1068793b9*/
  *(_OWORD *)((char *)a1 + 4628) = 0; /*0x1068793cd*/
  *(_OWORD *)((char *)a1 + 4616) = 0; /*0x1068793d4*/
  *(_OWORD *)((char *)a1 + 4664) = 0; /*0x1068793db*/
  *(_OWORD *)((char *)a1 + 4648) = 0; /*0x1068793e2*/
  *((_DWORD *)a1 + 1170) = 1065353216; /*0x1068793e9*/
  *((_OWORD *)a1 + 293) = 0; /*0x1068793fd*/
  *((_OWORD *)a1 + 294) = 0; /*0x106879404*/
  *((_DWORD *)a1 + 1180) = 1065353216; /*0x10687940b*/
  *((_BYTE *)a1 + 4728) = 0; /*0x10687941f*/
  v2 = 38; /*0x106879425*/
  v3 = (char *)&boost::unordered::detail::prime_list_template<unsigned long>::value; /*0x10687942a*/
  do /*0x10687945b*/
  {
    v4 = v2 >> 1; /*0x106879434*/
    v5 = v2 + ~(v2 >> 1); /*0x10687943d*/
    v6 = (__int64)&v3[8 * (v2 >> 1) + 8]; /*0x106879444*/
    if ( *(_QWORD *)(v6 - 8) < 0xBu ) /*0x10687944d*/
      v3 = (char *)v6; /*0x106879451*/
    else
      v5 = v4; /*0x10687944d*/
    v2 = v5; /*0x106879455*/
  }
  while ( v5 != 0 ); /*0x10687945b*/
  v7 = (char *)&unk_10A48E948; /*0x106879467*/
  if ( v3 != "NSt3__110__function6__funcIZNK18PlayersDataManager13getPlayerNameExP7QObjectPKcE3$_0NS_9allocatorIS7_EEFvRK" /*0x10687946e*/
             "NS_6vectorI7QStringNS8_ISB_EEEEEEE" )
    v7 = v3; /*0x10687946e*/
  *((_QWORD *)a1 + 592) = *(_QWORD *)v7; /*0x106879475*/
  *((_QWORD *)a1 + 593) = 0; /*0x10687947c*/
  *((_DWORD *)a1 + 1188) = 1065353216; /*0x106879487*/
  *(_OWORD *)((char *)a1 + 4792) = 0; /*0x106879494*/
  *(_OWORD *)((char *)a1 + 4760) = 0; /*0x1068794a2*/
  *(_OWORD *)((char *)a1 + 4772) = 0; /*0x1068794a9*/
  RBX::ProtectedString::ProtectedString(this: (RBX::Network::Server *)((char *)a1 + 4808)); /*0x1068794b3*/
  *((_DWORD *)a1 + 1208) = -1; /*0x1068794bf*/
  boost::mutex::mutex(this: (pthread_mutex_t *)((char *)a1 + 4840)); /*0x1068794d7*/
  *((_DWORD *)a1 + 1226) = 3; /*0x1068794dc*/
  *((_OWORD *)a1 + 307) = 0; /*0x1068794f0*/
  *((_OWORD *)a1 + 308) = 0; /*0x1068794f7*/
  *((_OWORD *)a1 + 309) = 0; /*0x1068794fe*/
  *((_QWORD *)a1 + 620) = 0; /*0x106879508*/
  RSL::Mutex::Mutex(this: (RBX::Network::Server *)((char *)a1 + 4968), a2: "rbxTransportListenConfigMutex"); /*0x10687951d*/
  *((_BYTE *)a1 + 5000) = 0; /*0x106879522*/
  *((_QWORD *)a1 + 626) = 0; /*0x106879529*/
  *((_OWORD *)a1 + 314) = 0; /*0x10687953a*/
  *((_OWORD *)a1 + 311) = 0; /*0x106879541*/
  *((_BYTE *)a1 + 4992) = 0; /*0x106879548*/
  *((_QWORD *)a1 + 627) = (char *)a1 + 5024; /*0x10687954f*/
  *(_OWORD *)((char *)a1 + 5048) = 0; /*0x10687955d*/
  *((_QWORD *)a1 + 630) = (char *)a1 + 5048; /*0x106879564*/
  *((_WORD *)a1 + 2532) = 0; /*0x10687956b*/
  *(_OWORD *)((char *)a1 + 5068) = 0; /*0x106879574*/
  *(_OWORD *)((char *)a1 + 5084) = 0; /*0x10687957b*/
  *(_QWORD *)((char *)a1 + 5100) = 0x3F80000000000000LL; /*0x10687958c*/
  *((_QWORD *)a1 + 639) = 0; /*0x106879593*/
  *((_QWORD *)a1 + 644) = RSL::Arena::getDefaultArena(this: v8); /*0x10687959f*/
  *((_OWORD *)a1 + 320) = 0; /*0x1068795a9*/
  *((_OWORD *)a1 + 321) = 0; /*0x1068795b0*/
  *(_OWORD *)((char *)a1 + 5160) = 0; /*0x1068795be*/
  *(_OWORD *)((char *)a1 + 5176) = 0; /*0x1068795c5*/
  *(_OWORD *)((char *)a1 + 5192) = 0; /*0x1068795cc*/
  *(_OWORD *)((char *)a1 + 5208) = 0; /*0x1068795d3*/
  *(_OWORD *)((char *)a1 + 5224) = 0; /*0x1068795da*/
  *(_OWORD *)((char *)a1 + 5240) = 0; /*0x1068795e1*/
  *(_OWORD *)((char *)a1 + 5256) = 0; /*0x1068795e8*/
  *(_OWORD *)((char *)a1 + 5272) = 0; /*0x1068795ef*/
  *(_OWORD *)((char *)a1 + 5288) = 0; /*0x1068795f6*/
  *((_BYTE *)a1 + 5304) = 0; /*0x1068795fd*/
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::RbxTransport::Connection>>::UnboundedCircularBuffer( /*0x10687960c*/
    a1: (char *)a1 + 5312,
    a2: 8,
    a3: v9,
    a4: v10,
    a5: v11,
    a6: v12,
    a7: (char *)a1 + 4728,
    a8: (char *)a1 + 4808,
    a9: (char *)a1 + 4840,
    a10: (char *)a1 + 4648,
    a11: (char *)a1 + 4688,
    a12: (char *)a1 + 4968,
    a13: (char *)a1 + 4536,
    a14: (char *)a1 + 4440,
    a15: (char *)a1 + 4448,
    a16: (char *)a1 + 4456,
    a17: (char *)a1 + 4464,
    a18: (char *)a1 + 4472,
    a19: (char *)a1 + 4512);
  RBX::UnboundedCircularBuffer<RBX::Network::Server::PendingAuthConnection>::UnboundedCircularBuffer( /*0x106879620*/
    a1: (char *)a1 + 5344,
    a2: 8);
  v14 = RBX::Security::Context::current(this: v13); /*0x106879625*/
  RBX::Security::Context::requireCapabilities(a1: v14, a2: 16, a3: "create", a4: "NetworkServer"); /*0x106879640*/
  RBX::Network::MegaReplicator::init(this: (RBX::Network::Server *)((char *)a1 + 544)); /*0x106879649*/
  std::string::basic_string[abi:ne200100]<0>(a1: v19, a2: "NetworkServer", a3: v15, a4: v16); /*0x106879659*/
  RBX::Instance::setName(a1, a2: v19); /*0x106879665*/
  if ( (v19[0] & 1) != 0 ) /*0x10687966e*/
    operator delete(a1: v20); /*0x106879674*/
  RBX::SharedString::SharedString(this: (RBX::SharedString *)v19); /*0x10687967d*/
  RBX::Network::Server::registerLegalSharedScript(this: a1, a2: (const RBX::SharedString *)v19); /*0x106879689*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v19); /*0x106879692*/
  RBX::SharedString::SharedString(this: (RBX::SharedString *)v19); /*0x10687969b*/
  *((_DWORD *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,int>>,RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::operator[]( /*0x1068796ad*/
                a1: (_QWORD *)a1 + 573,
                a2: (RBX *)v19)
  + 2) = 0;
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v19); /*0x1068796b8*/
  *((_DWORD *)a1 + 121) = (unsigned __int8)FFlag::DebugEnableStreamOutToDisk | 4; /*0x1068796ca*/
  if ( (unsigned __int8)RBX::InstanceStitchingHandler::isInstanceStitchingEnabled(this: v17) != 0 ) /*0x1068796d7*/
    ++*((_DWORD *)a1 + 121); /*0x1068796d9*/
  result = &FLog::Network; /*0x1068796df*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1068796f8*/
    return (__int64 *)FLog::FastLog( /*0x10687970c*/
                        a1: FLog::Network,
                        a2: qword_10D7BBAA8,
                        a3: "[FLog::Network] NetworkServer:Create",
                        0);
  return result; /*0x106879711*/
}

// Address: 0x106879a62 | Name: __ZN3RBX7Network6Server25registerLegalSharedScriptERKNS_12SharedStringE
__int64 __fastcall RBX::Network::Server::registerLegalSharedScript(
        RBX::Network::Server *this,
        const RBX::SharedString *a2)
{
  char *v4; // r13
  __int64 node; // rax
  unsigned __int64 v6; // r14
  unsigned __int64 v7; // r14
  __int64 v8; // r13
  __int64 v9; // rdi
  int v10; // eax
  FLog *v11; // r15
  __int64 Contents; // rax
  const char *v13; // rax
  __int64 v14; // rax
  __int64 v15; // rdi
  _QWORD *v16; // r15
  __int64 v17; // rax
  _QWORD *v18; // rax
  _QWORD *v20; // [rsp+8h] [rbp-68h]
  int v21; // [rsp+14h] [rbp-5Ch]
  __int64 v22; // [rsp+18h] [rbp-58h]
  double v23; // [rsp+18h] [rbp-58h]
  __int128 v24; // [rsp+20h] [rbp-50h] BYREF
  void *v25; // [rsp+30h] [rbp-40h]
  unsigned int v26; // [rsp+44h] [rbp-2Ch]

  v4 = (char *)this + 4536; /*0x106879a79*/
  node = boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,std::pair<int,int>>>,RBX::SharedString,std::pair<int,int>,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::find_node( /*0x106879a83*/
           a1: (unsigned __int8 *)this + 4536,
           a2);
  if ( node != 0 )
  {
    LODWORD(v6) = *(_DWORD *)(node + 24); /*0x106879a8d*/
  }
  else
  {
    v7 = *((_QWORD *)this + 565) - *((_QWORD *)this + 564); /*0x106879a9e*/
    v24 = 0; /*0x106879aae*/
    RBX::SharedString::SharedString(this: (RBX::SharedString *)&v24); /*0x106879ab2*/
    RBX::SharedString::SharedString(this: (RBX::SharedString *)((char *)&v24 + 8)); /*0x106879abe*/
    v20 = v4; /*0x106879ac3*/
    std::vector<RBX::Network::Server::LegalScript>::push_back[abi:ne200100](a1: (char *)this + 4512, a2: &v24); /*0x106879ad3*/
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: (char *)&v24 + 8); /*0x106879adb*/
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: &v24); /*0x106879ae4*/
    v8 = *((_QWORD *)this + 565); /*0x106879ae9*/
    RBX::Flyweight<RBX::SharedString::Data,void,true>::operator=(a1: v8 - 16, a2); /*0x106879af8*/
    v10 = *((_DWORD *)this + 134); /*0x106879afd*/
    v26 = 0; /*0x106879b05*/
    v21 = v10; /*0x106879b0c*/
    if ( v10 == 1 )
    {
      v11 = (FLog *)DFLog::TeamTest; /*0x106879b14*/
      v26 = 2; /*0x106879b2d*/
      if ( (unsigned __int8)DFLog::TeamTest >= 6u && BYTE1(DFLog::TeamTest) >= 3u )
      {
        v22 = qword_10D80F648; /*0x106879b3f*/
        Contents = RBX::SharedString::getContents(this: a2); /*0x106879b46*/
        if ( (*(_BYTE *)Contents & 1) != 0 ) /*0x106879b4e*/
          v13 = *(const char **)(Contents + 16); /*0x106879b50*/
        else
          v13 = (const char *)(Contents + 1); /*0x106879b56*/
        FLog::FastLogS(this: v11, a2: v22, a3: (unsigned __int64)"[DFLog::TeamTest] Compiling script: %s", a4: v13);
      }
    }
    if ( DFFlag::AddClientBytecodeCompileTimeToRCCInstanceTracking == 1 ) /*0x106879b76*/
    {
      v23 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v9); /*0x106879b81*/
      v14 = RBX::SharedString::getContents(this: a2); /*0x106879b8d*/
      LuaVM::compile(a1: &v24, a2: v14, a3: v26, a4: 8); /*0x106879ba4*/
      RBX::SharedString::setContents(a1: v8 - 8, a2: &v24); /*0x106879baf*/
      v16 = v20; /*0x106879bb8*/
      if ( (v24 & 1) != 0 ) /*0x106879bbc*/
        operator delete(a1: v25); /*0x106879bc2*/
      if ( v21 != 1 ) /*0x106879bcb*/
      {
        *((double *)this + 579) = (RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v15) - v23) * 1000.0 /*0x106879be9*/
                                + *((double *)this + 579);
        ++*((_DWORD *)this + 1160); /*0x106879bf3*/
      }
    }
    else
    {
      v17 = RBX::SharedString::getContents(this: a2); /*0x106879c04*/
      LuaVM::compile(a1: &v24, a2: v17, a3: v26, a4: 8); /*0x106879c1b*/
      RBX::SharedString::setContents(a1: v8 - 8, a2: &v24); /*0x106879c26*/
      v16 = v20; /*0x106879c2f*/
      if ( (v24 & 1) != 0 ) /*0x106879c33*/
        operator delete(a1: v25); /*0x106879c39*/
    }
    v6 = v7 >> 4; /*0x106879c3e*/
    v18 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,std::pair<int,int>>>,RBX::SharedString,std::pair<int,int>,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::operator[]( /*0x106879c48*/
            a1: v16,
            a2);
    *((_DWORD *)v18 + 2) = v6; /*0x106879c4d*/
    *((_DWORD *)v18 + 3) = v26; /*0x106879c54*/
  }
  return (unsigned int)v6; /*0x106879c5a*/
}

// Address: 0x106879cec | Name: __ZN3RBX7Network6ServerC1ERNS_28ForceConstructionInCreatableE
__int64 *__fastcall RBX::Network::Server::Server(RBX::Network::Server *a1)
{
  return RBX::Network::Server::Server(a1); /*0x106879cf0*/
}

// Address: 0x106879cf6 | Name: __ZN3RBX7Network6ServerD2Ev
void __fastcall RBX::Network::Server::~Server(RBX::Network::Server *this)
{
  __int64 v2; // rdi
  _QWORD v3[3]; // [rsp+8h] [rbp-18h] BYREF

  *(_QWORD *)this = off_10CAF2AC8; /*0x106879d0f*/
  *((_QWORD *)this + 22) = off_10CAF2D70; /*0x106879d19*/
  *((_QWORD *)this + 58) = &off_10CAF2DD8; /*0x106879d26*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x106879d46*/
    FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] NetworkServer:Destroy", 0); /*0x106879d5a*/
  RBX::UnboundedCircularBuffer<RBX::Network::Server::PendingAuthConnection>::~UnboundedCircularBuffer(a1: (char *)this + 5344); /*0x106879d66*/
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::RbxTransport::Connection>>::~UnboundedCircularBuffer(a1: (char *)this + 5312); /*0x106879d72*/
  if ( (*((_BYTE *)this + 5280) & 1) != 0 ) /*0x106879d7e*/
    operator delete(a1: *((void **)this + 662)); /*0x106879d87*/
  if ( (*((_BYTE *)this + 5256) & 1) != 0 ) /*0x106879d93*/
    operator delete(a1: *((void **)this + 659)); /*0x106879d9c*/
  if ( (*((_BYTE *)this + 5232) & 1) != 0 ) /*0x106879da8*/
    operator delete(a1: *((void **)this + 656)); /*0x106879db1*/
  if ( (*((_BYTE *)this + 5208) & 1) != 0 ) /*0x106879dbd*/
    operator delete(a1: *((void **)this + 653)); /*0x106879dc6*/
  if ( (*((_BYTE *)this + 5184) & 1) != 0 ) /*0x106879dd2*/
    operator delete(a1: *((void **)this + 650)); /*0x106879ddb*/
  if ( (*((_BYTE *)this + 5160) & 1) != 0 ) /*0x106879de7*/
    operator delete(a1: *((void **)this + 647)); /*0x106879df0*/
  RBX::details::SplitHashTable<std::string,std::string,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetSelfKey<std::string>>::freeInternalMemoryAndLeaveUninitialized(a1: (char *)this + 5120); /*0x106879dfc*/
  v2 = *((_QWORD *)this + 639); /*0x106879e01*/
  *((_QWORD *)this + 639) = 0; /*0x106879e08*/
  if ( v2 != 0 ) /*0x106879e16*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 72LL))(a1: v2); /*0x106879e1b*/
  std::__hash_table<std::__hash_value_type<RBX::Reflection::EventDescriptor const*,unsigned long>,std::__unordered_map_hasher<RBX::Reflection::EventDescriptor const*,std::__hash_value_type<RBX::Reflection::EventDescriptor const*,unsigned long>,std::hash<RBX::Reflection::EventDescriptor const*>,std::equal_to<RBX::Reflection::EventDescriptor const*>,true>,std::__unordered_map_equal<RBX::Reflection::EventDescriptor const*,std::__hash_value_type<RBX::Reflection::EventDescriptor const*,unsigned long>,std::equal_to<RBX::Reflection::EventDescriptor const*>,std::hash<RBX::Reflection::EventDescriptor const*>,true>,std::allocator<std::__hash_value_type<RBX::Reflection::EventDescriptor const*,unsigned long>>>::~__hash_table(a1: (char *)this + 5072); /*0x106879e25*/
  std::__tree<std::string>::destroy(a1: (__int64)this + 5040, a2: *((_QWORD **)this + 631)); /*0x106879e38*/
  std::__tree<std::string>::destroy(a1: (__int64)this + 5016, a2: *((_QWORD **)this + 628)); /*0x106879e4b*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 626); /*0x106879e57*/
  std::shared_ptr<RBX::RbxTransport::ListenConfiguration>::~shared_ptr[abi:ne200100](a1: (char *)this + 4976); /*0x106879e63*/
  RSL::Mutex::~Mutex(a1: (char *)this + 4968); /*0x106879e6f*/
  std::unique_ptr<RBX::RbxTransport::DummyService::DummyServer>::reset[abi:ne200100](a1: (char *)this + 4960, a2: 0); /*0x106879e7d*/
  std::shared_ptr<RBX::Network::NetworkLatencyScopeMetrics>::~shared_ptr[abi:ne200100](a1: (char *)this + 4944); /*0x106879e89*/
  v3[0] = (char *)this + 4920; /*0x106879e99*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: v3); /*0x106879e9c*/
  boost::mutex::~mutex(this: (pthread_mutex_t *)((char *)this + 4840)); /*0x106879ea8*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: (char *)this + 4816); /*0x106879ebb*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: (char *)this + 4808); /*0x106879ec3*/
  std::shared_ptr<RBX::Network::ServerSchemaInfo const>::~shared_ptr[abi:ne200100](a1: (char *)this + 4792); /*0x106879ecf*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<long long const,std::weak_ptr<RBX::Network::ServerReplicator>>>,long long,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<long long>,std::equal_to<long long>>>::delete_buckets(a1: (__int64)this + 4728); /*0x106879edb*/
  std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::~__hash_table(a1: (char *)this + 4688); /*0x106879ee7*/
  std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::~__hash_table(a1: (char *)this + 4648); /*0x106879ef3*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,int>>,RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::delete_buckets(a1: (__int64)this + 4584); /*0x106879eff*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,std::pair<int,int>>>,RBX::SharedString,std::pair<int,int>,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::delete_buckets(a1: (__int64)this + 4536); /*0x106879f0b*/
  v3[0] = (char *)this + 4512; /*0x106879f1b*/
  std::vector<RBX::Network::Server::LegalScript>::__destroy_vector::operator()[abi:ne200100](a1: v3); /*0x106879f21*/
  v3[0] = (char *)this + 4472; /*0x106879f2d*/
  std::vector<RBX::Network::SecurityJoinInfo>::__destroy_vector::operator()[abi:ne200100](a1: v3); /*0x106879f34*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Network::Server *)((char *)this + 4464)); /*0x106879f40*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Network::Server *)((char *)this + 4456)); /*0x106879f4c*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Network::Server *)((char *)this + 4448)); /*0x106879f58*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Network::Server *)((char *)this + 4440)); /*0x106879f64*/
  RBX::Network::MegaReplicator::~MegaReplicator(this: (RBX::Network::Server *)((char *)this + 544)); /*0x106879f70*/
  std::shared_ptr<RBX::TaskScheduler::Job>::~shared_ptr[abi:ne200100](a1: (char *)this + 520); /*0x106879f7c*/
  std::shared_ptr<RBX::TaskScheduler::Job>::~shared_ptr[abi:ne200100](a1: (char *)this + 504); /*0x106879f88*/
  std::shared_ptr<RBX::Players>::~shared_ptr[abi:ne200100](a1: (char *)this + 488); /*0x106879f94*/
  RBX::Network::NetworkServerProp::~NetworkServerProp(this); /*0x106879f9c*/
  RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer>::~DescribedCreatable(this); /*0x106879fa4*/
}

// Address: 0x106879fc2 | Name: __ZN3RBX7Network6ServerD1Ev
void __fastcall RBX::Network::Server::~Server(RBX::Network::Server *this)
{
  RBX::Network::Server::~Server(this); /*0x106879fc7*/
}

// Address: 0x106879fcc | Name: __ZThn176_N3RBX7Network6ServerD1Ev
void __fastcall `non-virtual thunk to'RBX::Network::Server::~Server(RBX::Network::Server *this)
{
  RBX::Network::Server::~Server(this: (RBX::Network::Server *)((char *)this - 176)); /*0x106879fd8*/
}

// Address: 0x106879fde | Name: __ZN3RBX7Network6ServerD0Ev
void __fastcall RBX::Network::Server::~Server(RBX::Network::Server *this)
{
  RBX::Network::Server::~Server(this); /*0x106879fe7*/
  operator delete(a1: this); /*0x106879ff5*/
}

// Address: 0x106879ffa | Name: __ZThn176_N3RBX7Network6ServerD0Ev
void __fastcall `non-virtual thunk to'RBX::Network::Server::~Server(RBX::Network::Server *this)
{
  char *v1; // rbx

  v1 = (char *)this - 176; /*0x10687a003*/
  RBX::Network::Server::~Server(this: (RBX::Network::Server *)((char *)this - 176)); /*0x10687a00d*/
  operator delete(a1: v1); /*0x10687a01b*/
}

// Address: 0x10687a020 | Name: __ZNK3RBX7Network6Server15getGameplayPortEv
__int64 __fastcall RBX::Network::Server::getGameplayPort(RBX::Network::Server *this, bool a2)
{
  return *((unsigned int *)this + (unsigned __int8)RBX::Network::useRbxTransport(this: nullptr, a2) + 119); /*0x10687a03e*/
}

// Address: 0x10687a042 | Name: __ZNK3RBX7Network6Server11isCloudEditEv
bool __fastcall RBX::Network::Server::isCloudEdit(RBX::Network::Server *this)
{
  return *((_DWORD *)this + 134) == 2; /*0x10687a050*/
}

// Address: 0x10687a052 | Name: __ZNK3RBX7Network6Server11isCloudTestEv
char __fastcall RBX::Network::Server::isCloudTest(RBX::Network::Server *this)
{
  bool v1; // cl

  v1 = *((_DWORD *)this + 134) == 1; /*0x10687a063*/
  if ( v1 || (FFlag::RCCShouldUseObfuscatedByteCodeInTeamTestSignal & 1) == 0 ) /*0x10687a06c*/
    return v1 | FFlag::RCCShouldUseObfuscatedByteCodeInTeamTestSignal; /*0x10687a071*/
  else
    return *((_BYTE *)this + 5304); /*0x10687a075*/
}

// Address: 0x10687a07e | Name: __ZN3RBX7Network6Server24encryptStringForPlayerIdERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEx
__int64 __fastcall RBX::Network::Server::encryptStringForPlayerId(__int64 a1, __int64 a2)
{
  std::__shared_weak_count *v3; // r14
  __int64 v5; // [rsp+8h] [rbp-28h] BYREF
  std::__shared_weak_count *v6; // [rsp+10h] [rbp-20h]

  if ( DFFlag::EnableLuaApiToRegisterEncryptedAssets != 0 ) /*0x10687a098*/
  {
    RBX::Network::Server::getServerReplicatorForPlayerId(this: (RBX::Network::Server *)&v5, a2); /*0x10687a0a7*/
    if ( v5 != 0 ) /*0x10687a0b2*/
    {
      RBX::Network::Replicator::sessionEncryptString(a1, a2: v5); /*0x10687a0ba*/
    }
    else
    {
      *(_OWORD *)a1 = 0; /*0x10687a0d4*/
      *(_QWORD *)(a1 + 16) = 0; /*0x10687a0d7*/
    }
    v3 = v6; /*0x10687a0df*/
    if ( v6 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v6 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10687a0f8*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(a1: v3); /*0x10687a100*/
      std::__shared_weak_count::__release_weak(this: v3); /*0x10687a106*/
    }
  }
  else
  {
    *(_OWORD *)a1 = 0; /*0x10687a0c4*/
    *(_QWORD *)(a1 + 16) = 0; /*0x10687a0c7*/
  }
  return a1; /*0x10687a10e*/
}

// Address: 0x10687a12e | Name: __ZN3RBX7Network6Server30getServerReplicatorForPlayerIdEx
RBX::Network::Server *__fastcall RBX::Network::Server::getServerReplicatorForPlayerId(
        RBX::Network::Server *this,
        __int64 a2,
        unsigned __int64 a3)
{
  _QWORD *v4; // rax
  _QWORD *v5; // r14
  std::__shared_weak_count *v6; // rdi
  __int64 v7; // rax
  unsigned __int64 v9[3]; // [rsp+8h] [rbp-18h] BYREF

  v9[0] = a3; /*0x10687a140*/
  v4 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<long long const,std::weak_ptr<RBX::Network::ServerReplicator>>>,long long,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<long long>,std::equal_to<long long>>>::find_node_impl<long long,std::equal_to<long long>>( /*0x10687a161*/
         a1: (_QWORD *)(a2 + 4728),
         a2: a3,
         a3: v9);
  if ( v4 != nullptr ) /*0x10687a169*/
  {
    v5 = v4; /*0x10687a16b*/
    *(_OWORD *)this = 0; /*0x10687a171*/
    v6 = (std::__shared_weak_count *)v4[4]; /*0x10687a174*/
    if ( v6 != nullptr ) /*0x10687a17b*/
    {
      v7 = std::__shared_weak_count::lock(this: v6); /*0x10687a17d*/
      *((_QWORD *)this + 1) = v7; /*0x10687a182*/
      if ( v7 != 0 ) /*0x10687a189*/
        *(_QWORD *)this = v5[3]; /*0x10687a18f*/
    }
  }
  else
  {
    *(_OWORD *)this = 0; /*0x10687a197*/
  }
  return this; /*0x10687a19d*/
}

// Address: 0x10687a1a6 | Name: __ZN3RBX7Network6Server5startEiiiNS0_9IpVersionEbRKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEERKN6RakNet13SystemAddressE
__int64 __fastcall RBX::Network::Server::start(
        RBX::DataModel *this,
        unsigned int a2,
        unsigned int a3,
        int a4,
        int a5,
        int a6,
        unsigned __int8 *a7,
        sockaddr *a8)
{
  const RBX::Instance *v11; // rsi
  __int64 v12; // r13
  __int64 v13; // rax
  __int128 *v14; // rax
  __int64 v15; // rax
  char v16; // al
  __int64 v17; // rcx
  const char *v18; // r8
  bool v19; // si
  const char *v20; // rcx
  unsigned __int8 *v21; // rax
  _BYTE *v22; // rsi
  int v23; // r12d
  __int64 v24; // rax
  std::__shared_weak_count *v25; // r15
  unsigned __int16 v26; // ax
  RBX::Instance *v27; // rsi
  __int16 v28; // ax
  int *v29; // rbx
  __int64 v30; // r13
  __int64 v31; // rax
  int v32; // eax
  unsigned int v33; // r15d
  __int64 v34; // rax
  __int64 v35; // rax
  RBX::Time *v36; // rdi
  int v37; // r15d
  int v38; // r12d
  __int64 v39; // rax
  double v40; // xmm0_8
  bool v41; // r9
  __int64 v42; // rax
  __int64 v43; // rdx
  __int64 v44; // r8
  __int64 v45; // r9
  __int64 v46; // rax
  __int64 v47; // rdx
  __int64 v48; // r8
  __int64 v49; // r9
  __int64 v50; // r15
  char v51; // r15
  __int64 v52; // rax
  __int64 v53; // rax
  const RBX::DataModel *v54; // rsi
  bool v55; // si
  unsigned int v56; // eax
  __int64 v57; // rax
  bool v58; // cl
  char isLocalTest; // al
  const char *v60; // rbx
  char *v61; // rcx
  int *v62; // rdx
  int v63; // r12d
  std::__shared_weak_count *v64; // rax
  __int64 v65; // rdx
  __int64 v66; // rcx
  __int128 v67; // xmm0
  void *v68; // rax
  char v69; // cl
  __int128 v70; // xmm1
  void *v71; // rdx
  __int64 v72; // rax
  __int64 v73; // rdi
  __int64 v74; // rdi
  int v75; // ebx
  int v76; // r15d
  char v77; // al
  __int64 v78; // rbx
  RBX::Network::ISRProfilingStatsProvider *v79; // r12
  __int64 v80; // rdx
  __int64 v81; // rcx
  __int64 v82; // rdi
  unsigned int v83; // esi
  RBX *exception; // r14
  void *v86; // r14
  int v87; // ebx
  int v88; // r14d
  int v89; // ebx
  int v90; // r14d
  _QWORD v91[2]; // [rsp+20h] [rbp-390h] BYREF
  std::__shared_weak_count *v92[2]; // [rsp+30h] [rbp-380h] BYREF
  __int128 v93; // [rsp+40h] [rbp-370h] BYREF
  void *v94; // [rsp+50h] [rbp-360h]
  __int64 v95; // [rsp+60h] [rbp-350h]
  std::__shared_weak_count *v96; // [rsp+68h] [rbp-348h]
  int v97; // [rsp+74h] [rbp-33Ch]
  unsigned int v98; // [rsp+78h] [rbp-338h]
  unsigned int v99; // [rsp+7Ch] [rbp-334h]
  int v100; // [rsp+80h] [rbp-330h]
  int v101; // [rsp+84h] [rbp-32Ch]
  __int64 v102; // [rsp+88h] [rbp-328h] BYREF
  void *v103[2]; // [rsp+90h] [rbp-320h]
  void *v104; // [rsp+A0h] [rbp-310h]
  int v105[2]; // [rsp+A8h] [rbp-308h]
  __int128 v106; // [rsp+B0h] [rbp-300h] BYREF
  void *v107; // [rsp+C0h] [rbp-2F0h]
  void *v108; // [rsp+C8h] [rbp-2E8h]
  int v109; // [rsp+D0h] [rbp-2E0h]
  __int128 v110; // [rsp+D8h] [rbp-2D8h]
  void *v111; // [rsp+E8h] [rbp-2C8h]
  bool v112; // [rsp+F0h] [rbp-2C0h]
  _BYTE v113[24]; // [rsp+F8h] [rbp-2B8h] BYREF
  _BYTE v114[48]; // [rsp+110h] [rbp-2A0h] BYREF
  __int128 v115; // [rsp+140h] [rbp-270h]
  void *v116; // [rsp+150h] [rbp-260h]
  void *v117[2]; // [rsp+158h] [rbp-258h]
  void *v118; // [rsp+168h] [rbp-248h]
  void *v119[2]; // [rsp+170h] [rbp-240h]
  void *v120; // [rsp+180h] [rbp-230h]
  __int64 v121; // [rsp+188h] [rbp-228h] BYREF
  char v122; // [rsp+190h] [rbp-220h]
  std::__shared_weak_count *v123[2]; // [rsp+1A0h] [rbp-210h] BYREF
  void *v124[2]; // [rsp+1B0h] [rbp-200h]
  int v125; // [rsp+1C0h] [rbp-1F0h] BYREF
  __int128 v126; // [rsp+1C8h] [rbp-1E8h] BYREF
  void *v127; // [rsp+1D8h] [rbp-1D8h]
  bool v128; // [rsp+1E0h] [rbp-1D0h]
  _BYTE v129[24]; // [rsp+1E8h] [rbp-1C8h] BYREF
  _BYTE v130[32]; // [rsp+200h] [rbp-1B0h] BYREF
  char v131; // [rsp+220h] [rbp-190h]
  char v132; // [rsp+228h] [rbp-188h]
  __int128 v133; // [rsp+230h] [rbp-180h] BYREF
  void *v134; // [rsp+240h] [rbp-170h]
  __int128 v135; // [rsp+248h] [rbp-168h]
  void *v136; // [rsp+258h] [rbp-158h]
  void *v137[3]; // [rsp+260h] [rbp-150h] BYREF
  __int64 v138; // [rsp+278h] [rbp-138h] BYREF
  char v139; // [rsp+280h] [rbp-130h]
  void *v140[2]; // [rsp+290h] [rbp-120h] BYREF
  void *v141; // [rsp+2A0h] [rbp-110h]
  void *v142[5]; // [rsp+2A8h] [rbp-108h] BYREF
  __int128 v143; // [rsp+2D0h] [rbp-E0h] BYREF
  RBX::Time *v144; // [rsp+2E0h] [rbp-D0h]
  char v145; // [rsp+308h] [rbp-A8h]
  _QWORD v146[4]; // [rsp+310h] [rbp-A0h] BYREF
  _QWORD *v147; // [rsp+330h] [rbp-80h]
  _BYTE v148[48]; // [rsp+34Eh] [rbp-62h] BYREF
  __int16 v149; // [rsp+37Eh] [rbp-32h]

  v97 = a4; /*0x10687a1c0*/
  v98 = a3; /*0x10687a1c6*/
  v105[0] = a2; /*0x10687a1cc*/
  v99 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkServer, a2); /*0x10687a1ee*/
  if ( (unsigned __int8)RBX::DataModel::clientIsPresent(this, a2: v11) != 0 ) /*0x10687a1fe*/
  {
    exception = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10687b259*/
    RBX::runtime_error(this: exception, a2: "Can not call server, client is present."); /*0x10687b268*/
    __cxa_throw( /*0x10687b27e*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x10687a21d*/
    FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] NetworkServer:Start", 0); /*0x10687a231*/
  v12 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x10687a242*/
  v13 = *((_QWORD *)this + 61); /*0x10687a245*/
  if ( v13 != 0 ) /*0x10687a24f*/
  {
    if ( (*(_BYTE *)(v13 + 216) & 1) != 0 ) /*0x10687a258*/
    {
      std::string::__init_copy_ctor_external(a1: &v93, a2: *(_QWORD *)(v13 + 232), a3: *(_QWORD *)(v13 + 224)); /*0x10687a28e*/
    }
    else
    {
      v14 = (__int128 *)(v13 + 216); /*0x10687a25a*/
      v94 = *((void **)v14 + 2); /*0x10687a264*/
      v93 = *v14; /*0x10687a26f*/
    }
    (*(void (__fastcall **)(__int64, __int128 *))(*(_QWORD *)v12 + 920LL))(a1: v12, a2: &v93); /*0x10687a2a1*/
    if ( (v93 & 1) != 0 ) /*0x10687a2ae*/
      operator delete(a1: v94); /*0x10687a2b7*/
  }
  v15 = *(_QWORD *)v12; /*0x10687a2bc*/
  v100 = (unsigned __int8)a6; /*0x10687a2c7*/
  (*(void (__fastcall **)(__int64))(v15 + 776))(a1: v12); /*0x10687a2cd*/
  (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v12 + 984LL))(a1: v12, a2: 1); /*0x10687a2df*/
  if ( (_BYTE)a6 != 0 ) /*0x10687a2ec*/
  {
    v16 = *a7 & 1; /*0x10687a2f3*/
    if ( v16 != 0 ) /*0x10687a2f5*/
      v17 = *((_QWORD *)a7 + 1); /*0x10687a2f7*/
    else
      v17 = *a7 >> 1; /*0x10687a348*/
    v19 = (unsigned __int8)DFLog::RuppTokenLog >= 6u && BYTE1(DFLog::RuppTokenLog) >= 3u; /*0x10687a369*/
    if ( v17 != 0 ) /*0x10687a36f*/
    {
      if ( v19 ) /*0x10687a374*/
      {
        if ( v16 != 0 ) /*0x10687a37c*/
          v20 = *((const char **)a7 + 2); /*0x10687a382*/
        else
          v20 = (const char *)(a7 + 1); /*0x10687a3dd*/
        FLog::FastLog( /*0x10687a3e8*/
          a1: *(_QWORD *)&DFLog::RuppTokenLog,
          a2: qword_10D7B48E0,
          a3: "[DFLog::RuppTokenLog] Server::start RuppTokenStemma = %s",
          v20);
        v16 = *a7 & 1; /*0x10687a3f3*/
      }
      if ( v16 != 0 ) /*0x10687a3f7*/
      {
        v21 = a7; /*0x10687a3f9*/
LABEL_37:
        v22 = *((_BYTE **)v21 + 2); /*0x10687a3fd*/
        goto LABEL_39; /*0x10687a401*/
      }
      v22 = a7 + 1; /*0x10687a407*/
    }
    else
    {
      if ( v19 ) /*0x10687a38b*/
        FLog::FastLog( /*0x10687a39a*/
          a1: *(_QWORD *)&DFLog::RuppTokenLog,
          a2: qword_10D7B48E0,
          a3: "[DFLog::RuppTokenLog] Server::start RuppTokenStemma = Default",
          0);
      v21 = FString::RuppTokEnPath; /*0x10687a39f*/
      if ( (FString::RuppTokEnPath[0] & 1) == 0 ) /*0x10687a3ab*/
      {
        v22 = nullptr; /*0x10687a3b0*/
        if ( FString::RuppTokEnPath[0] != 0 ) /*0x10687a3b4*/
          v22 = &FString::RuppTokEnPath[1]; /*0x10687a3b4*/
        goto LABEL_39; /*0x10687a3b4*/
      }
      v22 = *(_BYTE **)&FString::RuppTokEnPath[8]; /*0x10687a3ce*/
      if ( *(_QWORD *)&FString::RuppTokEnPath[8] != 0 ) /*0x10687a3d5*/
        goto LABEL_37; /*0x10687a3d5*/
    }
LABEL_39:
    (*(void (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v12 + 816LL))(a1: v12, a2: v22); /*0x10687a40b*/
    (*(void (__fastcall **)(__int64, sockaddr *))(*(_QWORD *)v12 + 824LL))(a1: v12, a2: a8); /*0x10687a423*/
    (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v12 + 792LL))(a1: v12, a2: 1); /*0x10687a435*/
    RBX::make_shared<RBX::Rupp::Rupp>(a1: v123); /*0x10687a442*/
    v23 = a6; /*0x10687a447*/
    v24 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x10687a451*/
    (*(void (__fastcall **)(__int64, std::__shared_weak_count **))(*(_QWORD *)v24 + 104LL))(a1: v24, a2: v123); /*0x10687a463*/
    v25 = v123[1]; /*0x10687a466*/
    if ( v123[1] != nullptr /*0x10687a482*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v123[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v25 + 16LL))(a1: v25); /*0x10687a48a*/
      std::__shared_weak_count::__release_weak(this: v25); /*0x10687a490*/
    }
    a6 = v23; /*0x10687a495*/
    goto LABEL_45; /*0x10687a498*/
  }
  if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && BYTE1(DFLog::RuppTokenLog) >= 3u ) /*0x10687a316*/
  {
    if ( (*a7 & 1) != 0 ) /*0x10687a32d*/
    {
      if ( *((_QWORD *)a7 + 1) != 0 ) /*0x10687a3bf*/
        v18 = *((const char **)a7 + 2); /*0x10687a3c5*/
      else
        v18 = "empty"; /*0x10687a49a*/
    }
    else
    {
      v18 = "empty"; /*0x10687a338*/
      if ( *a7 != 0 ) /*0x10687a33f*/
        v18 = (const char *)(a7 + 1); /*0x10687a33f*/
    }
    FLog::FastLog( /*0x10687a4b2*/
      a1: *(_QWORD *)&DFLog::RuppTokenLog,
      a2: qword_10D7B48E0,
      a3: "[DFLog::RuppTokenLog] Server::start RuppAware = %s, TokeEn = t, Stemma = %s",
      "f",
      v18);
  }
LABEL_45:
  v26 = v105[0]; /*0x10687a4b7*/
  if ( FFlag::DebugEnableServerCustomPortForRbxTransportRomarkTesting != 0 ) /*0x10687a4c4*/
    v26 = FInt::DebugLocalRccServerConnectionPort; /*0x10687a4c6*/
  RakNet::SocketDescriptor::SocketDescriptor(this: (RakNet::SocketDescriptor *)v148, a2: v26, a3: nullptr); /*0x10687a4d5*/
  if ( a5 != 0 ) /*0x10687a4dc*/
  {
    if ( a5 != 1 ) /*0x10687a4e1*/
      goto LABEL_52; /*0x10687a4e1*/
    v28 = 2; /*0x10687a4e3*/
  }
  else
  {
    v28 = 30; /*0x10687a4e9*/
  }
  v149 = v28; /*0x10687a4ed*/
LABEL_52:
  v101 = a6; /*0x10687a4f1*/
  v29 = &DFInt::RccMaxPayloadRcv; /*0x10687a507*/
  if ( *((_DWORD *)this + 134) == 2 ) /*0x10687a50e*/
    v29 = &DFInt::RccTcMaxPayloadRcv; /*0x10687a50e*/
  v30 = RBX::DataModel::get(this, a2: v27); /*0x10687a51a*/
  v31 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x10687a524*/
  v32 = (*(__int64 (__fastcall **)(__int64, _QWORD, int *, _BYTE *, __int64, _QWORD, _DWORD, int))(*(_QWORD *)v31 + 16LL))( /*0x10687a568*/
          a1: v31,
          a2: (unsigned __int16)FInt::MaxClients,
          a3: v29,
          a4: v148,
          a5: 1,
          a6: (unsigned __int16)v98,
          a7: (unsigned __int16)v97,
          a8: -99999);
  v33 = v32; /*0x10687a56b*/
  if ( v32 != 0 && FFlag::DebugAllowRakNetPortBindFailForRomarkTest == 0 ) /*0x10687a57c*/
  {
    reportServerStartupFailure(a1: v32, a2: v105[0], a3: v100, a4: *(_DWORD *)(v30 + 2184)); /*0x10687b2a2*/
    v86 = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10687b2b1*/
    RBX::format( /*0x10687b2db*/
      this: (RBX *)v123,
      a2: "Failed to start network server, port:%d, error:%s",
      v105[0],
      (const char *)&RakNet::StartupResultStrings + *((int *)&RakNet::StartupResultStrings + v33));
    std::runtime_error::runtime_error(a1: v86, a2: v123); /*0x10687b2ed*/
    __cxa_throw( /*0x10687b306*/
      a1: v86,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  v34 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x10687a589*/
  (*(void (__fastcall **)(std::__shared_weak_count **, __int64, _QWORD))(*(_QWORD *)v34 + 416LL))( /*0x10687a59d*/
    a1: v123,
    a2: v34,
    a3: 0);
  *((_DWORD *)this + 119) = (unsigned __int16)RakNet::SystemAddress::GetPort(this: (RakNet::SystemAddress *)v123); /*0x10687a5b2*/
  v35 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x10687a5c0*/
  (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v35 + 832LL))(a1: v35, a2: *((unsigned __int16 *)this + 238)); /*0x10687a5d3*/
  v37 = DFLog::NetworkServer; /*0x10687a5d9*/
  if ( (unsigned __int8)DFLog::NetworkServer >= 6u && (DFLog::NetworkServer & 0xFC00) != 0 ) /*0x10687a5ee*/
  {
    v38 = qword_10D80F5C0; /*0x10687a5f5*/
    v39 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x10687a603*/
    (*(void (__fastcall **)(std::__shared_weak_count **, __int64, _QWORD))(*(_QWORD *)v39 + 416LL))( /*0x10687a617*/
      a1: v123,
      a2: v39,
      a3: 0);
    RBX::Network::RakNetAddressToString( /*0x10687a635*/
      this: (RBX::Network *)&v143,
      a2: (const RakNet::SystemAddress *)v123,
      a3: true,
      a4: 124);
    FLog::FastLogSafeFormatted<std::string>( /*0x10687a659*/
      a1: v37,
      a2: v38,
      a3: 4,
      a4: (int)"[DFLog::NetworkServer] Started Raknet network server {}",
      a5: 55,
      a6: (unsigned __int8 *)&v143);
    if ( (v143 & 1) != 0 ) /*0x10687a665*/
      operator delete(a1: v144); /*0x10687a66e*/
  }
  RBX::Time::nowFast(this: v36); /*0x10687a673*/
  RBX::Analytics::Event::DEPRECATED_trackUserTiming( /*0x10687a6a4*/
    this: (RBX::Analytics::Event *)"Game",
    a2: "ServerStartTime",
    a3: (const char *)(unsigned int)(int)((v40 - *(double *)(v30 + 1472)) * 1000.0),
    a4: (int)"none",
    a5: nullptr,
    a6: v41);
  if ( DFFlag::DebugDisableTimeoutDisconnect == 1 ) /*0x10687a6b3*/
  {
    v42 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x10687a6bc*/
    *(_OWORD *)v124 = *(__int128 *)((char *)&xmmword_10CDB0CBC + 4); /*0x10687a6c8*/
    *(_OWORD *)v123 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x10687a6d6*/
    (*(void (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v42 + 448LL))( /*0x10687a708*/
      a1: v42,
      a2: 600000,
      a3: v43,
      a4: *(_QWORD *)(*(_QWORD *)v42 + 448LL),
      a5: v44,
      a6: v45,
      a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
      a8: unk_10CDB0CB8,
      a9: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 4),
      a10: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 12));
  }
  if ( *((_DWORD *)this + 134) == 2 ) /*0x10687a712*/
  {
    v46 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x10687a71b*/
    *(_OWORD *)v124 = *(__int128 *)((char *)&xmmword_10CDB0CBC + 4); /*0x10687a734*/
    *(_OWORD *)v123 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x10687a742*/
    (*(void (__fastcall **)(__int64, _QWORD, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v46 + 448LL))( /*0x10687a76f*/
      a1: v46,
      a2: (unsigned int)(1000 * DFInt::TeamCreateTimeOutInSec),
      a3: v47,
      a4: *(_QWORD *)(*(_QWORD *)v46 + 448LL),
      a5: v48,
      a6: v49,
      a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
      a8: unk_10CDB0CB8,
      a9: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 4),
      a10: *(_QWORD *)((char *)&xmmword_10CDB0CBC + 12));
  }
  v95 = v30 + 464; /*0x10687a778*/
  v50 = RBX::ServiceProvider::create<RBX::TimerService>(a1: v30 + 464, a2: 0); /*0x10687a789*/
  RBX::weak_from<RBX::Network::Server>(a1: v92, a2: this); /*0x10687a796*/
  v146[0] = &off_10CAAEB70; /*0x10687a7a9*/
  *(_OWORD *)&v146[1] = *(_OWORD *)v92; /*0x10687a7b4*/
  *(_OWORD *)v92 = 0; /*0x10687a7bd*/
  v147 = v146; /*0x10687a7c4*/
  RBX::TimerService::delay(a1: v50, a2: v146, a3: 300.0); /*0x10687a7d7*/
  v51 = v101; /*0x10687a7e7*/
  if ( v147 == v146 ) /*0x10687a7ee*/
  {
    v52 = 32; /*0x10687a7fc*/
    goto LABEL_67; /*0x10687a7fc*/
  }
  v52 = 40; /*0x10687a7f0*/
  if ( v147 != nullptr ) /*0x10687a7f8*/
LABEL_67:
    (*(void (**)(void))(*v147 + v52))(); /*0x10687a801*/
  if ( v92[1] != nullptr ) /*0x10687a811*/
    std::__shared_weak_count::__release_weak(this: v92[1]); /*0x10687a813*/
  v53 = RBX::ServiceProvider::find<RBX::RunService>(a1: v95, a2: 0); /*0x10687a821*/
  if ( v53 != 0 ) /*0x10687a829*/
    *((_QWORD *)this + 563) = *(_QWORD *)(v53 + 280); /*0x10687a833*/
  *((_DWORD *)this + 1125) = RBX::WorldStats::getCurrentUnthrottledWorldStepId(this: (RBX::WorldStats *)v30, a2: v54); /*0x10687a844*/
  if ( (unsigned __int8)RBX::Network::useRbxTransport(this: (RBX::Network *)1, a2: v55) != 0 )
  {
    LOBYTE(v143) = 0; /*0x10687a85f*/
    v145 = 0; /*0x10687a865*/
    if ( v51 == 0 ) /*0x10687a86e*/
    {
      if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && (DFLog::RuppTokenLog & 0xFC00) != 0 ) /*0x10687a896*/
        FLog::FastLogSafeFormatted<char const(&)[2],std::string const&>( /*0x10687a8c2*/
          a1: DFLog::RuppTokenLog,
          a2: qword_10D7B48E0,
          a3: 4,
          a4: (int)"[DFLog::RuppTokenLog] RbxTransport Server RuppAware = {}, Token = t, Stemma = {}",
          a5: 80,
          a6: (__int64)"f",
          a7);
      goto LABEL_97; /*0x10687a8c7*/
    }
    v56 = *a7; /*0x10687a870*/
    if ( (v56 & 1) != 0 ) /*0x10687a877*/
      v57 = *((_QWORD *)a7 + 1); /*0x10687a879*/
    else
      v57 = v56 >> 1; /*0x10687a8cc*/
    v58 = (unsigned __int8)DFLog::RuppTokenLog >= 6u && (DFLog::RuppTokenLog & 0xFC00) != 0; /*0x10687a8e9*/
    if ( v57 != 0 )
    {
      if ( v58 ) /*0x10687a8f6*/
        FLog::FastLogSafeFormatted<std::string const&>( /*0x10687a912*/
          a1: DFLog::RuppTokenLog,
          a2: qword_10D7B48E0,
          a3: 4,
          a4: (int)"[DFLog::RuppTokenLog] RbxTransport Server RuppTokenStemma = {}",
          a5: 62,
          a6: a7);
      *(_OWORD *)v140 = 0; /*0x10687a922*/
      v141 = nullptr; /*0x10687a927*/
      RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v142); /*0x10687a932*/
      std::string::operator=(a1: v140, a2: a7); /*0x10687a941*/
      LODWORD(v102) = 0; /*0x10687a946*/
      *(_OWORD *)v103 = 0; /*0x10687a954*/
      v104 = nullptr; /*0x10687a95c*/
      RBX::RbxTransport::Io::EndpointAddr::fromSockaddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v123, a2: a8); /*0x10687a972*/
      v91[0] = &v102; /*0x10687a985*/
      v91[1] = v142; /*0x10687a988*/
      std::__memberwise_forward_assign[abi:ne200100]<std::tuple<RBX::RbxTransport::Io::Error &,RBX::RbxTransport::Io::EndpointAddr &>,std::tuple<RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr>,RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr,0ul,1ul>( /*0x10687a993*/
        a1: v91,
        a2: v123);
      RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)&v125); /*0x10687a9a2*/
      if ( ((__int64)v123[1] & 1) != 0 ) /*0x10687a9ac*/
        operator delete(a1: v124[1]); /*0x10687a9b5*/
      if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v102) == 0 )
      {
        v87 = DFLog::RuppTokenLog; /*0x10687b310*/
        if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && (DFLog::RuppTokenLog & 0xFC00) != 0 )
        {
          v88 = qword_10D7B48E0; /*0x10687b327*/
          RBX::RbxTransport::Io::Error::toString(this: (RBX::RbxTransport::Io::Error *)v123); /*0x10687b33a*/
          FLog::FastLogSafeFormatted<std::string>(
            a1: v87,
            a2: v88,
            a3: 4,
            a4: (int)"[DFLog::RuppTokenLog] RbxTransport Server RuppTokenStemma = Error: {}",
            a5: 69,
            a6: (unsigned __int8 *)v123);
          if ( ((__int64)v123[0] & 1) != 0 ) /*0x10687b36a*/
            operator delete(a1: v124[0]); /*0x10687b373*/
        }
        RBX::RbxTransport::Io::Error::toString(this: (RBX::RbxTransport::Io::Error *)v123); /*0x10687b386*/
        if ( ((__int64)v123[0] & 1) != 0 )
          RBX::throw_runtime_error(
            this: (RBX *)"Server could not read Rupp config (error: %s), RbxTransport Server cannot start. Abort",
            a2: (const char *)v124[0]);
        RBX::throw_runtime_error(
          this: (RBX *)"Server could not read Rupp config (error: %s), RbxTransport Server cannot start. Abort",
          a2: (const char *)v123 + 1);
      }
      if ( DFFlag::RbxTransportServerRuppStemmaFix != 1 ) /*0x10687a9d5*/
        goto LABEL_93; /*0x10687a9d5*/
    }
    else
    {
      if ( v58 ) /*0x10687a9f5*/
      {
        v123[0] = nullptr; /*0x10687a9fc*/
        v123[1] = (std::__shared_weak_count *)v140; /*0x10687aa0e*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x10687aa3a*/
          a1: DFLog::RuppTokenLog,
          a2: qword_10D7B48E0,
          a3: 4,
          a4: (unsigned int)"[DFLog::RuppTokenLog] RbxTransport Server RuppTokenStemma = Default",
          a5: 67,
          a6: 1,
          0,
          v140);
      }
      *(_OWORD *)v140 = 0; /*0x10687aa4a*/
      v141 = nullptr; /*0x10687aa4f*/
      RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v142); /*0x10687aa5a*/
      std::string::operator=(a1: v140, a2: FString::RuppTokEnPath); /*0x10687aa6d*/
      LODWORD(v102) = 0; /*0x10687aa72*/
      *(_OWORD *)v103 = 0; /*0x10687aa80*/
      v104 = nullptr; /*0x10687aa88*/
      RBX::RbxTransport::Io::EndpointAddr::fromSockaddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v123, a2: a8); /*0x10687aa9e*/
      v91[0] = &v102; /*0x10687aab1*/
      v91[1] = v142; /*0x10687aab4*/
      std::__memberwise_forward_assign[abi:ne200100]<std::tuple<RBX::RbxTransport::Io::Error &,RBX::RbxTransport::Io::EndpointAddr &>,std::tuple<RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr>,RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr,0ul,1ul>( /*0x10687aabf*/
        a1: v91,
        a2: v123);
      RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)&v125); /*0x10687aace*/
      if ( ((__int64)v123[1] & 1) != 0 ) /*0x10687aad8*/
        operator delete(a1: v124[1]); /*0x10687aae1*/
      if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v102) == 0 )
      {
        v89 = DFLog::RuppTokenLog; /*0x10687b3a4*/
        if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && (DFLog::RuppTokenLog & 0xFC00) != 0 )
        {
          v90 = qword_10D7B48E0; /*0x10687b3bb*/
          RBX::RbxTransport::Io::Error::toString(this: (RBX::RbxTransport::Io::Error *)v123); /*0x10687b3ce*/
          FLog::FastLogSafeFormatted<std::string>(
            a1: v89,
            a2: v90,
            a3: 4,
            a4: (int)"[DFLog::RuppTokenLog] RbxTransport Server RuppTokenStemma = Error: {}",
            a5: 69,
            a6: (unsigned __int8 *)v123);
          if ( ((__int64)v123[0] & 1) != 0 ) /*0x10687b3fe*/
            operator delete(a1: v124[0]); /*0x10687b407*/
        }
        RBX::RbxTransport::Io::Error::toString(this: (RBX::RbxTransport::Io::Error *)v123); /*0x10687b41a*/
        if ( ((__int64)v123[0] & 1) != 0 )
          RBX::throw_runtime_error(
            this: (RBX *)"Server could not read Rupp config (error: %s), RbxTransport Server cannot start. Abort",
            a2: (const char *)v124[0]);
        RBX::throw_runtime_error(
          this: (RBX *)"Server could not read Rupp config (error: %s), RbxTransport Server cannot start. Abort",
          a2: (const char *)v123 + 1);
      }
    }
    std::optional<RBX::Rupp::ServerRuppConfiguration>::operator=[abi:ne200100]<RBX::Rupp::ServerRuppConfiguration&,void>( /*0x10687ab08*/
      a1: &v143,
      a2: v140);
LABEL_93:
    if ( ((__int64)v103[0] & 1) != 0 ) /*0x10687ab14*/
      operator delete(a1: v104); /*0x10687ab1d*/
    RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v142); /*0x10687ab25*/
    if ( ((__int64)v140[0] & 1) != 0 ) /*0x10687ab31*/
      operator delete(a1: v141); /*0x10687ab3a*/
LABEL_97:
    isLocalTest = RBX::Network::Peer::isLocalTest(this); /*0x10687ab3f*/
    RBX::Security::RakPeerCrypto::getRbxTransportServerKeyInfo( /*0x10687ab5d*/
      this: (RBX::Security::RakPeerCrypto *)v140,
      a2: (DFFlag::DebugRbxTransportUseTestKey | isLocalTest) & 1);
    v60 = "*"; /*0x10687ab71*/
    if ( (unsigned __int8)RBX::Network::Peer::isLocalTest(this) != 0 ) /*0x10687ab7a*/
      v60 = "0.0.0.0"; /*0x10687ab7a*/
    v61 = &FFlag::DebugLocalRccServerConnection; /*0x10687ab84*/
    v62 = &FInt::DebugLocalRbxTransportOffset; /*0x10687ab8b*/
    v63 = FInt::DebugLocalRbxTransportOffset + v105[0]; /*0x10687ab99*/
    if ( FInt::RbxTransportServerPort != 0 ) /*0x10687ab9e*/
      v63 = FInt::RbxTransportServerPort; /*0x10687ab9e*/
    if ( FFlag::DebugLocalRccServerConnection == 0 ) /*0x10687aba5*/
      v63 = FInt::RbxTransportServerPort; /*0x10687aba5*/
    LOBYTE(v101) = DFFlag::RccReportCapabilitiesInNetStackConfig; /*0x10687abaf*/
    if ( DFFlag::RccReportCapabilitiesInNetStackConfig != 0 ) /*0x10687abb7*/
    {
      RBX::Network::buildRbxTransportCapabilities( /*0x10687abc5*/
        a1: v123,
        a2: 1,
        a3: &FInt::DebugLocalRbxTransportOffset,
        a4: &FFlag::DebugLocalRccServerConnection);
      v64 = v123[0]; /*0x10687abca*/
      v96 = v123[0]; /*0x10687abd1*/
      LOBYTE(v64) = 1; /*0x10687abd8*/
      *(_QWORD *)v105 = v64; /*0x10687abda*/
    }
    else
    {
      v96 = nullptr; /*0x10687abe3*/
      *(_QWORD *)v105 = 0; /*0x10687abee*/
    }
    std::string::basic_string[abi:ne200100]<0>(a1: v123, a2: v60, a3: v62, a4: v61); /*0x10687ac03*/
    v124[1] = (void *)__PAIR64__(v98, v63); /*0x10687ac0f*/
    v125 = v97; /*0x10687ac23*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v126, a2: "", a3: v65, a4: v66); /*0x10687ac31*/
    v128 = *((_DWORD *)this + 134) == 2; /*0x10687ac45*/
    v129[0] = 0; /*0x10687ac4b*/
    v131 = 0; /*0x10687ac4d*/
    if ( v145 == 1 ) /*0x10687ac57*/
    {
      *(_QWORD *)&v129[16] = v144; /*0x10687ac64*/
      *(_OWORD *)v129 = v143; /*0x10687ac6d*/
      v143 = 0; /*0x10687ac75*/
      v144 = nullptr; /*0x10687ac7a*/
      RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(a1: v130); /*0x10687ac8c*/
      v131 = 1; /*0x10687ac91*/
    }
    v132 = 1; /*0x10687ac9c*/
    if ( (*a7 & 1) != 0 ) /*0x10687aca5*/
    {
      std::string::__init_copy_ctor_external(a1: &v133, a2: *((_QWORD *)a7 + 2), a3: *((_QWORD *)a7 + 1)); /*0x10687acc3*/
    }
    else
    {
      v134 = *((void **)a7 + 2); /*0x10687acab*/
      v133 = *(_OWORD *)a7; /*0x10687acb5*/
    }
    v67 = *(_OWORD *)v140; /*0x10687accf*/
    v135 = *(_OWORD *)v140; /*0x10687acd7*/
    v68 = v141; /*0x10687acdf*/
    v136 = v141; /*0x10687ace6*/
    *(_OWORD *)v140 = 0; /*0x10687acf0*/
    v69 = 0; /*0x10687acf7*/
    v141 = nullptr; /*0x10687acf9*/
    v70 = *(_OWORD *)v142; /*0x10687ad00*/
    qmemcpy(v137, v142, sizeof(v137)); /*0x10687ad07*/
    v71 = v142[2]; /*0x10687ad0e*/
    memset(v142, 0, 24); /*0x10687ad1c*/
    LOBYTE(v138) = 0; /*0x10687ad2a*/
    v139 = 0; /*0x10687ad30*/
    if ( LOBYTE(v105[0]) != 0 ) /*0x10687ad3d*/
    {
      v138 = 0; /*0x10687ad3f*/
      _InterlockedExchange64(&v138, (__int64)v96); /*0x10687ad51*/
      v139 = 1; /*0x10687ad58*/
      v69 = 1; /*0x10687ad5f*/
    }
    v106 = *(_OWORD *)v123; /*0x10687ad78*/
    v107 = v124[0]; /*0x10687ad84*/
    *(_OWORD *)v123 = 0; /*0x10687ad88*/
    v124[0] = nullptr; /*0x10687ad93*/
    v108 = v124[1]; /*0x10687ad9e*/
    v109 = v125; /*0x10687ada5*/
    v110 = v126; /*0x10687adac*/
    v111 = v127; /*0x10687adb4*/
    v127 = nullptr; /*0x10687adb8*/
    v126 = 0; /*0x10687adbc*/
    v112 = v128; /*0x10687adca*/
    v113[0] = 0; /*0x10687adce*/
    v114[32] = 0; /*0x10687add1*/
    if ( v131 == 1 ) /*0x10687add9*/
    {
      qmemcpy(v113, v129, sizeof(v113)); /*0x10687ade6*/
      memset(v129, 0, sizeof(v129)); /*0x10687adf3*/
      RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(a1: v114); /*0x10687ae12*/
      v114[32] = 1; /*0x10687ae17*/
      v67 = v135; /*0x10687ae1c*/
      v68 = v136; /*0x10687ae22*/
      v70 = *(_OWORD *)v137; /*0x10687ae26*/
      v71 = v137[2]; /*0x10687ae2b*/
      v69 = v139; /*0x10687ae2f*/
    }
    v114[40] = v132; /*0x10687ae41*/
    v116 = v134; /*0x10687ae53*/
    v115 = v133; /*0x10687ae5d*/
    v134 = nullptr; /*0x10687ae66*/
    v133 = 0; /*0x10687ae6d*/
    *(_OWORD *)v117 = v67; /*0x10687ae70*/
    v118 = v68; /*0x10687ae78*/
    v136 = nullptr; /*0x10687ae7f*/
    v135 = 0; /*0x10687ae84*/
    *(_OWORD *)v119 = v70; /*0x10687ae89*/
    v120 = v71; /*0x10687ae90*/
    memset(v137, 0, sizeof(v137)); /*0x10687ae9c*/
    LOBYTE(v121) = 0; /*0x10687aea2*/
    v122 = 0; /*0x10687aea9*/
    if ( (v69 & 1) != 0 ) /*0x10687aeb3*/
    {
      v121 = 0; /*0x10687aeb5*/
      _InterlockedExchange64(&v121, v138); /*0x10687aec7*/
      v122 = 1; /*0x10687aece*/
    }
    RBX::NetworkBase::ListenerInternal::createAndStartListener(a1: &v102, a2: 1, a3: &v106); /*0x10687aee8*/
    v72 = v102; /*0x10687aeed*/
    v102 = 0; /*0x10687aef4*/
    v73 = *((_QWORD *)this + 639); /*0x10687aeff*/
    *((_QWORD *)this + 639) = v72; /*0x10687af06*/
    if ( v73 != 0 ) /*0x10687af10*/
    {
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v73 + 72LL))(a1: v73); /*0x10687af15*/
      v74 = v102; /*0x10687af18*/
      v102 = 0; /*0x10687af1f*/
      if ( v74 != 0 ) /*0x10687af2d*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v74 + 72LL))(a1: v74); /*0x10687af32*/
    }
    if ( v119[0] != nullptr ) /*0x10687af3f*/
    {
      v119[1] = v119[0]; /*0x10687af41*/
      operator delete(a1: v119[0]); /*0x10687af48*/
    }
    if ( v117[0] != nullptr ) /*0x10687af57*/
    {
      v117[1] = v117[0]; /*0x10687af59*/
      operator delete(a1: v117[0]); /*0x10687af60*/
    }
    if ( (v115 & 1) != 0 ) /*0x10687af6c*/
      operator delete(a1: v116); /*0x10687af75*/
    std::__optional_destruct_base<RBX::Rupp::ServerRuppConfiguration,false>::~__optional_destruct_base[abi:ne200100](a1: v113); /*0x10687af7d*/
    if ( (v110 & 1) != 0 ) /*0x10687af89*/
      operator delete(a1: v111); /*0x10687af92*/
    if ( (v106 & 1) != 0 ) /*0x10687af9e*/
      operator delete(a1: v107); /*0x10687afa7*/
    *((_DWORD *)this + 120) = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 639) + 16LL))(a1: *((_QWORD *)this + 639)); /*0x10687afb9*/
    v75 = DFLog::NetworkServer; /*0x10687afc0*/
    if ( (unsigned __int8)DFLog::NetworkServer >= 6u && (DFLog::NetworkServer & 0xFC00) != 0 ) /*0x10687afd3*/
    {
      v76 = qword_10D80F5C0; /*0x10687afda*/
      (*(void (__fastcall **)(__int64 *))(**((_QWORD **)this + 639) + 8LL))(a1: &v102); /*0x10687aff2*/
      FLog::FastLogSafeFormatted<std::string,int &>( /*0x10687b01f*/
        a1: v75,
        a2: v76,
        a3: 4,
        a4: (int)"[DFLog::NetworkServer] Started RbxTransport network server {}|{}",
        a5: 64,
        a6: (unsigned __int8 *)&v102,
        a7: (unsigned int *)this + 120);
      if ( (v102 & 1) != 0 ) /*0x10687b02b*/
        operator delete(a1: v103[1]); /*0x10687b034*/
    }
    if ( (_BYTE)v101 != 0 ) /*0x10687b040*/
    {
      RSL::Mutex::lock(this: (RBX::DataModel *)((char *)this + 4968)); /*0x10687b04c*/
      v77 = *((_BYTE *)this + 5000); /*0x10687b051*/
      if ( v77 == LOBYTE(v105[0]) ) /*0x10687b05e*/
      {
        if ( v77 != 0 ) /*0x10687b062*/
          _InterlockedExchange64((volatile __int64 *)this + 624, (__int64)v96); /*0x10687b06b*/
      }
      else if ( v77 != 0 ) /*0x10687b076*/
      {
        *((_BYTE *)this + 5000) = 0; /*0x10687b078*/
      }
      else
      {
        *((_QWORD *)this + 624) = 0; /*0x10687b082*/
        _InterlockedExchange64((volatile __int64 *)this + 624, (__int64)v96); /*0x10687b094*/
        *((_BYTE *)this + 5000) = 1; /*0x10687b09b*/
      }
      RSL::Mutex::unlock(this: (RBX::DataModel *)((char *)this + 4968)); /*0x10687b0a6*/
    }
    if ( v137[0] != nullptr ) /*0x10687b0b5*/
    {
      v137[1] = v137[0]; /*0x10687b0b7*/
      operator delete(a1: v137[0]); /*0x10687b0be*/
    }
    if ( (_QWORD)v135 != 0 ) /*0x10687b0cd*/
    {
      *((_QWORD *)&v135 + 1) = v135; /*0x10687b0cf*/
      operator delete(a1: (void *)v135); /*0x10687b0d6*/
    }
    if ( (v133 & 1) != 0 ) /*0x10687b0e2*/
      operator delete(a1: v134); /*0x10687b0eb*/
    std::__optional_destruct_base<RBX::Rupp::ServerRuppConfiguration,false>::~__optional_destruct_base[abi:ne200100](a1: v129); /*0x10687b0f7*/
    if ( (v126 & 1) != 0 ) /*0x10687b103*/
      operator delete(a1: v127); /*0x10687b10c*/
    if ( ((__int64)v123[0] & 1) != 0 ) /*0x10687b118*/
      operator delete(a1: v124[0]); /*0x10687b121*/
    if ( v142[0] != nullptr ) /*0x10687b130*/
    {
      v142[1] = v142[0]; /*0x10687b132*/
      operator delete(a1: v142[0]); /*0x10687b139*/
    }
    if ( v140[0] != nullptr ) /*0x10687b148*/
    {
      v140[1] = v140[0]; /*0x10687b14a*/
      operator delete(a1: v140[0]); /*0x10687b151*/
    }
    std::__optional_destruct_base<RBX::Rupp::ServerRuppConfiguration,false>::~__optional_destruct_base[abi:ne200100](a1: &v143); /*0x10687b15d*/
  }
  RBX::Network::MegaReplicator::initializeForServerStart(this: (RBX::DataModel *)((char *)this + 544)); /*0x10687b162*/
  if ( DFFlag::ISRParallelWorkProfiling == 1 ) /*0x10687b17b*/
  {
    v78 = RBX::ServiceProvider::find<RBX::TestService>(a1: v95, a2: 0); /*0x10687b18f*/
    if ( v78 != 0 ) /*0x10687b195*/
    {
      v79 = (RBX::Network::ISRProfilingStatsProvider *)operator new(a1: 0xC8u); /*0x10687b1a1*/
      RBX::Network::ISRProfilingStatsProvider::ISRProfilingStatsProvider( /*0x10687b1aa*/
        this: v79,
        a2: (RBX::DataModel *)((char *)this + 544));
      std::string::basic_string[abi:ne200100]<0>(a1: v123, a2: "ISRProfiling", a3: v80, a4: v81); /*0x10687b1bd*/
      *(_QWORD *)&v143 = v79; /*0x10687b1c9*/
      RBX::TestService::registerTestSessionStatsProvider(a1: v78, a2: v123); /*0x10687b1d6*/
      v82 = v143; /*0x10687b1db*/
      *(_QWORD *)&v143 = 0; /*0x10687b1e2*/
      if ( v82 != 0 ) /*0x10687b1f0*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v82 + 8LL))(a1: v82); /*0x10687b1f5*/
      if ( ((__int64)v123[0] & 1) != 0 ) /*0x10687b1ff*/
        operator delete(a1: v124[0]); /*0x10687b208*/
    }
  }
  RBX::Network::Server::initializeRbxTransportDummyServer(this); /*0x10687b21d*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v99, a2: v83); /*0x10687b228*/
  return __stack_chk_guard; /*0x10687b23d*/
}

// Address: 0x10687bc90 | Name: __ZN3RBX7Network6Server33initializeRbxTransportDummyServerEbRKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEERKN6RakNet13SystemAddressEPNS_9DataModelE
__int64 __fastcall RBX::Network::Server::initializeRbxTransportDummyServer(
        RBX::Network::Peer *this,
        int a2,
        unsigned __int8 *a3,
        const sockaddr *a4)
{
  unsigned int v7; // eax
  __int64 v8; // rax
  bool v9; // cl
  int v10; // r14d
  int v11; // r12d
  int v12; // r14d
  int v13; // r12d
  char isLocalTest; // al
  int v15; // r12d
  _QWORD *v16; // r14
  RBX::RbxTransport::DummyService::DummyServer *v17; // rsi
  RBX::RbxTransport::DummyService::DummyServer *v18; // r15
  RSL::Mutex *v19; // r14
  __int64 v20; // rdx
  __int64 v21; // rcx
  unsigned __int16 v22; // r13
  std::__shared_weak_count *v23; // rbx
  _QWORD v25[2]; // [rsp+10h] [rbp-2B0h] BYREF
  void *v26[4]; // [rsp+20h] [rbp-2A0h] BYREF
  void *v27[3]; // [rsp+40h] [rbp-280h] BYREF
  _BYTE v28[16]; // [rsp+58h] [rbp-268h] BYREF
  void *v29; // [rsp+68h] [rbp-258h]
  __int128 v30; // [rsp+70h] [rbp-250h] BYREF
  void *v31; // [rsp+80h] [rbp-240h]
  __int128 v32; // [rsp+90h] [rbp-230h] BYREF
  void *v33; // [rsp+A0h] [rbp-220h]
  __int64 v34; // [rsp+B0h] [rbp-210h] BYREF
  __int128 v35; // [rsp+B8h] [rbp-208h]
  void *v36; // [rsp+C8h] [rbp-1F8h]
  _BYTE v37[24]; // [rsp+D0h] [rbp-1F0h] BYREF
  _BYTE v38[32]; // [rsp+E8h] [rbp-1D8h] BYREF
  char v39; // [rsp+108h] [rbp-1B8h]
  RBX::RbxTransport::DummyService::DummyServer *v40[2]; // [rsp+118h] [rbp-1A8h] BYREF
  void *v41; // [rsp+128h] [rbp-198h]
  void *v42; // [rsp+130h] [rbp-190h]
  _BYTE v43[216]; // [rsp+138h] [rbp-188h] BYREF
  __int128 v44; // [rsp+210h] [rbp-B0h] BYREF
  void *v45; // [rsp+220h] [rbp-A0h]
  void *v46; // [rsp+228h] [rbp-98h] BYREF
  _BYTE *v47; // [rsp+230h] [rbp-90h]
  _BYTE v48[24]; // [rsp+250h] [rbp-70h] BYREF
  char v49; // [rsp+288h] [rbp-38h]

  v48[0] = 0; /*0x10687bcba*/
  v49 = 0; /*0x10687bcbd*/
  if ( a2 != 0 )
  {
    v7 = *a3; /*0x10687bcc7*/
    if ( (v7 & 1) != 0 ) /*0x10687bcce*/
      v8 = *((_QWORD *)a3 + 1); /*0x10687bcd0*/
    else
      v8 = v7 >> 1; /*0x10687bd24*/
    v9 = (unsigned __int8)DFLog::RuppTokenLog >= 6u && (DFLog::RuppTokenLog & 0xFC00) != 0; /*0x10687bd41*/
    if ( v8 != 0 )
    {
      if ( v9 ) /*0x10687bd4e*/
        FLog::FastLogSafeFormatted<std::string const&>( /*0x10687bd69*/
          a1: DFLog::RuppTokenLog,
          a2: qword_10D7B48E0,
          a3: 4,
          a4: (int)"[DFLog::RuppTokenLog] RbxTransport DummyServer RuppTokenStemma = {}",
          a5: 67,
          a6: a3);
      v44 = 0; /*0x10687bd78*/
      v45 = nullptr; /*0x10687bd7d*/
      RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)&v46); /*0x10687bd88*/
      std::string::operator=(a1: &v44, a2: a3); /*0x10687bd97*/
      LODWORD(v34) = 0; /*0x10687bd9c*/
      v35 = 0; /*0x10687bda9*/
      v36 = nullptr; /*0x10687bdb0*/
      RBX::RbxTransport::Io::EndpointAddr::fromSockaddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v40, a2: a4); /*0x10687bdc5*/
      v25[0] = &v34; /*0x10687bdd8*/
      v25[1] = &v46; /*0x10687bddb*/
      std::__memberwise_forward_assign[abi:ne200100]<std::tuple<RBX::RbxTransport::Io::Error &,RBX::RbxTransport::Io::EndpointAddr &>,std::tuple<RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr>,RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr,0ul,1ul>( /*0x10687bde6*/
        a1: v25,
        a2: v40);
      RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v43); /*0x10687bdf5*/
      if ( ((__int64)v40[1] & 1) != 0 ) /*0x10687bdff*/
        operator delete(a1: v42); /*0x10687be08*/
      if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v34) == 0 )
      {
        v10 = DFLog::RuppTokenLog; /*0x10687be1d*/
        if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && (DFLog::RuppTokenLog & 0xFC00) != 0 )
        {
          v11 = qword_10D7B48E0; /*0x10687be36*/
          RBX::RbxTransport::Io::Error::toString(this: (RBX::RbxTransport::Io::Error *)v40); /*0x10687be48*/
          FLog::FastLogSafeFormatted<std::string>(
            a1: v10,
            a2: v11,
            a3: 4,
            a4: (int)"[DFLog::RuppTokenLog] RbxTransport DummyServer RuppTokenStemma = Error: {}",
            a5: 74,
            a6: (unsigned __int8 *)v40);
          if ( ((__int64)v40[0] & 1) != 0 ) /*0x10687be78*/
            operator delete(a1: v41); /*0x10687be81*/
        }
      }
    }
    else
    {
      if ( v9 ) /*0x10687be9d*/
      {
        v40[0] = nullptr; /*0x10687bea3*/
        v40[1] = (RBX::RbxTransport::DummyService::DummyServer *)&v44; /*0x10687beb5*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x10687bedf*/
          a1: DFLog::RuppTokenLog,
          a2: qword_10D7B48E0,
          a3: 4,
          a4: (unsigned int)"[DFLog::RuppTokenLog] RbxTransport DummyServer RuppTokenStemma = Default",
          a5: 72,
          a6: 1,
          0,
          &v44);
      }
      v44 = 0; /*0x10687beee*/
      v45 = nullptr; /*0x10687bef3*/
      RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)&v46); /*0x10687befe*/
      std::string::operator=(a1: &v44, a2: FString::RuppTokEnPath); /*0x10687bf11*/
      LODWORD(v34) = 0; /*0x10687bf16*/
      v35 = 0; /*0x10687bf23*/
      v36 = nullptr; /*0x10687bf2a*/
      RBX::RbxTransport::Io::EndpointAddr::fromSockaddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v40, a2: a4); /*0x10687bf3f*/
      v25[0] = &v34; /*0x10687bf52*/
      v25[1] = &v46; /*0x10687bf55*/
      std::__memberwise_forward_assign[abi:ne200100]<std::tuple<RBX::RbxTransport::Io::Error &,RBX::RbxTransport::Io::EndpointAddr &>,std::tuple<RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr>,RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr,0ul,1ul>( /*0x10687bf60*/
        a1: v25,
        a2: v40);
      RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v43); /*0x10687bf6f*/
      if ( ((__int64)v40[1] & 1) != 0 ) /*0x10687bf79*/
        operator delete(a1: v42); /*0x10687bf82*/
      if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v34) == 0 )
      {
        v12 = DFLog::RuppTokenLog; /*0x10687bf97*/
        if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && (DFLog::RuppTokenLog & 0xFC00) != 0 )
        {
          v13 = qword_10D7B48E0; /*0x10687bfb0*/
          RBX::RbxTransport::Io::Error::toString(this: (RBX::RbxTransport::Io::Error *)v40); /*0x10687bfc2*/
          FLog::FastLogSafeFormatted<std::string>(
            a1: v12,
            a2: v13,
            a3: 4,
            a4: (int)"[DFLog::RuppTokenLog] RbxTransport DummyServer RuppTokenStemma = Error: {}",
            a5: 74,
            a6: (unsigned __int8 *)v40);
          if ( ((__int64)v40[0] & 1) != 0 ) /*0x10687bff2*/
            operator delete(a1: v41); /*0x10687bffb*/
        }
      }
    }
    std::optional<RBX::Rupp::ServerRuppConfiguration>::operator=[abi:ne200100]<RBX::Rupp::ServerRuppConfiguration&,void>( /*0x10687c00b*/
      a1: v48,
      a2: &v44);
    if ( (v35 & 1) != 0 ) /*0x10687c017*/
      operator delete(a1: v36); /*0x10687c020*/
    RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)&v46); /*0x10687c028*/
    if ( (v44 & 1) != 0 ) /*0x10687c034*/
      operator delete(a1: v45); /*0x10687c03d*/
  }
  else if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && (DFLog::RuppTokenLog & 0xFC00) != 0 ) /*0x10687bcee*/
  {
    FLog::FastLogSafeFormatted<char const(&)[2],std::string const&>( /*0x10687bd1a*/
      a1: DFLog::RuppTokenLog,
      a2: qword_10D7B48E0,
      a3: 4,
      a4: (int)"[DFLog::RuppTokenLog] RbxTransport DummyServer RuppAware = {}, Token = t, Stemma = {}",
      a5: 85,
      a6: (__int64)"f",
      a7: a3);
  }
  isLocalTest = RBX::Network::Peer::isLocalTest(this); /*0x10687c045*/
  RBX::Security::RakPeerCrypto::getRbxTransportServerKeyInfo( /*0x10687c060*/
    this: (RBX::Security::RakPeerCrypto *)&v44,
    a2: (DFFlag::DebugRbxTransportUseTestKey | isLocalTest) & 1);
  if ( DFFlag::DebugDisableRbxTransportDummyServer != 0 ) /*0x10687c06c*/
  {
    if ( (unsigned __int8)DFLog::NetworkServer >= 6u && BYTE1(DFLog::NetworkServer) >= 3u ) /*0x10687c083*/
    {
      v40[0] = nullptr; /*0x10687c095*/
      v40[1] = (RBX::RbxTransport::DummyService::DummyServer *)&v34; /*0x10687c0a7*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x10687c0d1*/
        a1: DFLog::NetworkServer,
        a2: qword_10D80F5C0,
        a3: 3,
        a4: (unsigned int)"[DFLog::NetworkServer] RbxTransport Dummy Server is disabled by DebugDisableRbxTransportDummyServer flag.",
        a5: 105,
        a6: 1,
        0,
        &v34);
    }
  }
  else
  {
    v15 = *((_DWORD *)this + 120); /*0x10687c0db*/
    std::make_unique[abi:ne200100]<RBX::RbxTransport::DummyService::DummyServer,std::vector<unsigned char> &,std::vector<unsigned char> &,std::optional<RBX::Rupp::ServerRuppConfiguration> &,0>( /*0x10687c0fb*/
      a1: v40,
      a2: &v44,
      a3: &v46,
      a4: v48);
    v16 = (_QWORD *)((char *)this + 4960); /*0x10687c100*/
    v17 = v40[0]; /*0x10687c107*/
    v40[0] = nullptr; /*0x10687c111*/
    std::unique_ptr<RBX::RbxTransport::DummyService::DummyServer>::reset[abi:ne200100](a1: (char *)this + 4960, a2: v17); /*0x10687c11b*/
    v18 = v40[0]; /*0x10687c120*/
    v40[0] = nullptr; /*0x10687c127*/
    if ( v18 != nullptr ) /*0x10687c131*/
    {
      RBX::RbxTransport::DummyService::DummyServer::~DummyServer(this: v18); /*0x10687c136*/
      operator delete(a1: v18); /*0x10687c13e*/
    }
    if ( DFInt::RbxTransportDummyServerPortOverride != 0 ) /*0x10687c14b*/
      LOWORD(v15) = DFInt::RbxTransportDummyServerPortOverride; /*0x10687c14b*/
    if ( (unsigned __int8)RBX::RbxTransport::DummyService::DummyServer::start( /*0x10687c170*/
                            a1: *v16,
                            a2: "*",
                            a3: 1,
                            a4: (unsigned __int16)v15) != 0 )
    {
      if ( (unsigned __int8)DFLog::NetworkServer >= 6u && (DFLog::NetworkServer & 0xFC00) != 0 ) /*0x10687c17f*/
      {
        v34 = *(unsigned __int16 *)(*v16 + 178LL); /*0x10687c1a2*/
        v40[0] = (RBX::RbxTransport::DummyService::DummyServer *)2; /*0x10687c1a5*/
        v40[1] = (RBX::RbxTransport::DummyService::DummyServer *)&v34; /*0x10687c1b0*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x10687c1da*/
          a1: DFLog::NetworkServer,
          a2: qword_10D80F5C0,
          a3: 4,
          a4: (unsigned int)"[DFLog::NetworkServer] RbxTransport Dummy Server started successfully on port {}",
          a5: 80,
          a6: 1,
          2,
          &v34);
      }
    }
    else if ( (unsigned __int8)DFLog::NetworkServer >= 6u && BYTE1(DFLog::NetworkServer) >= 3u ) /*0x10687c1ef*/
    {
      v40[0] = nullptr; /*0x10687c1fd*/
      v40[1] = (RBX::RbxTransport::DummyService::DummyServer *)&v34; /*0x10687c20f*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x10687c239*/
        a1: DFLog::NetworkServer,
        a2: qword_10D80F5C0,
        a3: 3,
        a4: (unsigned int)"[DFLog::NetworkServer] Failed to start RbxTransport Dummy Server",
        a5: 64,
        a6: 1,
        0,
        &v34);
    }
  }
  v19 = (RBX::Network::Peer *)((char *)this + 4968); /*0x10687c23e*/
  RSL::Mutex::lock(this: (RBX::Network::Peer *)((char *)this + 4968)); /*0x10687c248*/
  std::string::basic_string[abi:ne200100]<0>(a1: v28, a2: "*", a3: v20, a4: v21); /*0x10687c25b*/
  v22 = *((_WORD *)this + 240); /*0x10687c260*/
  v37[0] = 0; /*0x10687c26a*/
  v39 = 0; /*0x10687c270*/
  if ( v49 == 1 ) /*0x10687c27a*/
  {
    qmemcpy(v37, v48, sizeof(v37)); /*0x10687c28b*/
    memset(v48, 0, sizeof(v48)); /*0x10687c29b*/
    RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(a1: v38); /*0x10687c2aa*/
    v39 = 1; /*0x10687c2af*/
  }
  v30 = 0; /*0x10687c2b7*/
  v31 = nullptr; /*0x10687c2c0*/
  v32 = 0; /*0x10687c2c7*/
  v33 = nullptr; /*0x10687c2ce*/
  memset(v26, 0, 24); /*0x10687c2dc*/
  std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x10687c2fb*/
    a1: v26,
    a2: v44,
    a3: *((_QWORD *)&v44 + 1),
    a4: *((_QWORD *)&v44 + 1) - v44);
  memset(v27, 0, sizeof(v27)); /*0x10687c30a*/
  std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x10687c32f*/
    a1: v27,
    a2: v46,
    a3: v47,
    a4: v47 - (_BYTE *)v46);
  RBX::RbxTransport::ListenConfiguration::configForQuic( /*0x10687c364*/
    a1: (unsigned int)v40,
    a2: (unsigned int)v28,
    a3: v22,
    a4: (unsigned int)v37,
    a5: (unsigned int)&v30,
    a6: (unsigned int)&v32,
    a7: (__int64)v26,
    a8: (__int64)v27);
  std::allocate_shared[abi:ne200100]<RBX::RbxTransport::ListenConfiguration,std::allocator<RBX::RbxTransport::ListenConfiguration>,RBX::RbxTransport::ListenConfiguration,0>( /*0x10687c37e*/
    a1: &v34,
    a2: v25,
    a3: v40);
  std::shared_ptr<RBX::RbxTransport::ListenConfiguration>::operator=[abi:ne200100](a1: (char *)this + 4976, a2: &v34); /*0x10687c397*/
  v23 = (std::__shared_weak_count *)v35; /*0x10687c39c*/
  if ( (_QWORD)v35 != 0 && _InterlockedExchangeAdd64((volatile signed __int64 *)(v35 + 8), 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10687c3b5*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v23 + 16LL))(a1: v23); /*0x10687c3bd*/
    std::__shared_weak_count::__release_weak(this: v23); /*0x10687c3c3*/
  }
  RBX::RbxTransport::ListenConfiguration::~ListenConfiguration(this: (RBX::RbxTransport::ListenConfiguration *)v40); /*0x10687c3cf*/
  if ( v27[0] != nullptr ) /*0x10687c3de*/
  {
    v27[1] = v27[0]; /*0x10687c3e0*/
    operator delete(a1: v27[0]); /*0x10687c3e7*/
  }
  if ( v26[0] != nullptr ) /*0x10687c3f6*/
  {
    v26[1] = v26[0]; /*0x10687c3f8*/
    operator delete(a1: v26[0]); /*0x10687c3ff*/
  }
  if ( (v32 & 1) != 0 ) /*0x10687c40b*/
    operator delete(a1: v33); /*0x10687c414*/
  if ( (v30 & 1) != 0 ) /*0x10687c420*/
    operator delete(a1: v31); /*0x10687c429*/
  std::__optional_destruct_base<RBX::Rupp::ServerRuppConfiguration,false>::~__optional_destruct_base[abi:ne200100](a1: v37); /*0x10687c435*/
  if ( (v28[0] & 1) != 0 ) /*0x10687c441*/
    operator delete(a1: v29); /*0x10687c44a*/
  RSL::Mutex::unlock(this: v19); /*0x10687c452*/
  if ( v46 != nullptr ) /*0x10687c461*/
  {
    v47 = v46; /*0x10687c463*/
    operator delete(a1: v46); /*0x10687c46a*/
  }
  if ( (_QWORD)v44 != 0 ) /*0x10687c479*/
  {
    *((_QWORD *)&v44 + 1) = v44; /*0x10687c47b*/
    operator delete(a1: (void *)v44); /*0x10687c482*/
  }
  std::__optional_destruct_base<RBX::Rupp::ServerRuppConfiguration,false>::~__optional_destruct_base[abi:ne200100](a1: v48); /*0x10687c48b*/
  return __stack_chk_guard; /*0x10687c4a0*/
}

// Address: 0x10687c628 | Name: __ZN3RBX7Network6Server14getClientCountEv
__int64 __fastcall RBX::Network::Server::getClientCount(__int64 **this, const RBX::Instance *a2)
{
  __int64 *v3; // rax
  __int64 v4; // rdi
  __int64 v5; // rsi
  RBX *exception; // rbx
  __int64 (__fastcall *v8)(); // [rsp+0h] [rbp-20h] BYREF
  _BYTE v9[17]; // [rsp+Fh] [rbp-11h] BYREF

  if ( (unsigned __int8)RBX::DataModel::clientIsPresent((RBX::DataModel *)this, a2) != 0 ) /*0x10687c63d*/
  {
    exception = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10687c67d*/
    RBX::runtime_error(this: exception, a2: "Can not call server, client is present."); /*0x10687c68c*/
    __cxa_throw( /*0x10687c6a2*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  v3 = *(this + 15); /*0x10687c63f*/
  if ( v3 == nullptr ) /*0x10687c646*/
    return 0; /*0x10687c668*/
  v4 = *v3; /*0x10687c648*/
  v5 = v3[1]; /*0x10687c64b*/
  v8 = isReplicator; /*0x10687c65a*/
  return std::__count_if[abi:ne200100]<std::_ClassicAlgPolicy,std::__wrap_iter<std::shared_ptr<RBX::Instance> const*>,std::__wrap_iter<std::shared_ptr<RBX::Instance> const*>,std::__identity,bool (*)(std::shared_ptr<RBX::Instance>)>( /*0x10687c66a*/
           a1: v4,
           a2: v5,
           a3: &v8,
           a4: v9);
}

// Address: 0x10687c6f8 | Name: __ZN3RBX7Network6Server19getPossibleBotCountEv
__int64 __fastcall RBX::Network::Server::getPossibleBotCount(__int64 **this, const RBX::Instance *a2)
{
  __int64 *v3; // rax
  __int64 v4; // rdi
  __int64 v5; // rsi
  RBX *exception; // rbx
  __int64 (__fastcall *v8)(); // [rsp+0h] [rbp-20h] BYREF
  _BYTE v9[17]; // [rsp+Fh] [rbp-11h] BYREF

  if ( (unsigned __int8)RBX::DataModel::clientIsPresent((RBX::DataModel *)this, a2) != 0 ) /*0x10687c70d*/
  {
    exception = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10687c74d*/
    RBX::runtime_error(this: exception, a2: "Can not call server, client is present."); /*0x10687c75c*/
    __cxa_throw( /*0x10687c772*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  v3 = *(this + 15); /*0x10687c70f*/
  if ( v3 == nullptr ) /*0x10687c716*/
    return 0; /*0x10687c738*/
  v4 = *v3; /*0x10687c718*/
  v5 = v3[1]; /*0x10687c71b*/
  v8 = isPossibleBot; /*0x10687c72a*/
  return std::__count_if[abi:ne200100]<std::_ClassicAlgPolicy,std::__wrap_iter<std::shared_ptr<RBX::Instance> const*>,std::__wrap_iter<std::shared_ptr<RBX::Instance> const*>,std::__identity,bool (*)(std::shared_ptr<RBX::Instance>)>( /*0x10687c73a*/
           a1: v4,
           a2: v5,
           a3: &v8,
           a4: v9);
}

// Address: 0x10687c7d8 | Name: __ZN3RBX7Network6Server4stopEv
__int64 __fastcall RBX::Network::Server::stop(RBX::Network::ConcurrentRakPeer **this, const RBX::Instance *a2)
{
  RBX::NetworkBase::ConnectionInternal ****v3; // rax
  volatile signed __int64 *v4; // rcx
  RBX::NetworkBase::ConnectionInternal ***v5; // r12
  RBX::NetworkBase::ConnectionInternal ***v6; // r13
  RBX::NetworkBase::ConnectionInternal **v7; // r15
  RBX::NetworkBase::ConnectionInternal *v8; // r14
  __int64 v9; // rax
  unsigned int v10; // ecx
  __int64 v11; // rax
  __int64 result; // rax
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // rax
  RBX::RbxTransport::DummyService::DummyServer *v16; // r14
  char *v17; // rbx
  RBX *exception; // r14
  _BYTE v19[16]; // [rsp+8h] [rbp-68h] BYREF
  void *v20; // [rsp+18h] [rbp-58h]
  std::__shared_weak_count *v21; // [rsp+20h] [rbp-50h]
  __int64 v22; // [rsp+28h] [rbp-48h] BYREF
  volatile signed __int64 *v23; // [rsp+30h] [rbp-40h]
  void *v24; // [rsp+40h] [rbp-30h]

  if ( (unsigned __int8)RBX::DataModel::clientIsPresent((RBX::DataModel *)this, a2) != 0 ) /*0x10687c7f3*/
  {
    exception = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10687c987*/
    RBX::runtime_error(this: exception, a2: "Can not call server, client is present."); /*0x10687c996*/
    __cxa_throw( /*0x10687c9ac*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  v3 = (RBX::NetworkBase::ConnectionInternal ****)*(this + 15); /*0x10687c7f9*/
  if ( v3 != nullptr ) /*0x10687c800*/
  {
    v22 = (__int64)*(this + 15); /*0x10687c806*/
    v4 = (volatile signed __int64 *)*(this + 16); /*0x10687c80a*/
    v23 = v4; /*0x10687c811*/
    if ( v4 != nullptr ) /*0x10687c818*/
      _InterlockedIncrement64(v4 + 1); /*0x10687c81a*/
    v21 = (std::__shared_weak_count *)v4; /*0x10687c81f*/
    v5 = *v3; /*0x10687c823*/
    v6 = v3[1]; /*0x10687c826*/
    while ( v5 != v6 ) /*0x10687c82d*/
    {
      v7 = *v5; /*0x10687c82f*/
      v8 = (*v5)[3]; /*0x10687c833*/
      v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(); /*0x10687c837*/
      v10 = *((unsigned __int16 *)v8 + 220) - *(unsigned __int16 *)(v9 + 440); /*0x10687c84b*/
      LODWORD(v9) = *(unsigned __int16 *)(v9 + 442); /*0x10687c84d*/
      *((_BYTE *)*v5 + 170) &= 0x1Eu; /*0x10687c858*/
      if ( v10 <= (unsigned int)v9 ) /*0x10687c861*/
      {
        if ( DFFlag::FixOverwriteDisconnectReasonInServerStop != 1 /*0x10687c877*/
          || (unsigned int)RBX::Network::Replicator::getDisconnectReason(this: v7) == 1 )
        {
          RBX::Network::Replicator::safeSetDisconnectReason(this: v7, a2: 0x120u); /*0x10687c881*/
        }
        (*((void (__fastcall **)(RBX::NetworkBase::ConnectionInternal **))**v5 + 35))(a1: *v5); /*0x10687c88d*/
      }
      v5 += 2; /*0x10687c893*/
    }
    if ( v21 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v21 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10687c8b2*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(a1: v21); /*0x10687c8ba*/
      std::__shared_weak_count::__release_weak(this: v21); /*0x10687c8c0*/
    }
  }
  RBX::Instance::removeAllChildren((RBX::Instance *)this); /*0x10687c8c8*/
  v11 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x10687c8d4*/
  result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v11 + 128LL))(a1: v11); /*0x10687c8df*/
  if ( (_BYTE)result != 0 ) /*0x10687c8e7*/
  {
    v15 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x10687c8f0*/
    result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v15 + 120LL))(a1: v15); /*0x10687c8fb*/
  }
  v16 = *(this + 620); /*0x10687c8fe*/
  if ( v16 != nullptr ) /*0x10687c908*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v19, a2: "", a3: v13, a4: v14); /*0x10687c918*/
    RBX::Network::StateReason::StateReason(a1: &v22, a2: 257, a3: 288, a4: v19); /*0x10687c92e*/
    RBX::RbxTransport::DummyService::DummyServer::stop(this: v16, a2: (const RBX::Network::StateReason *)&v22); /*0x10687c93a*/
    if ( ((unsigned __int8)v23 & 1) != 0 ) /*0x10687c943*/
      operator delete(a1: v24); /*0x10687c949*/
    v17 = (char *)(this + 620); /*0x10687c94e*/
    if ( (v19[0] & 1) != 0 ) /*0x10687c959*/
      operator delete(a1: v20); /*0x10687c95f*/
    return std::unique_ptr<RBX::RbxTransport::DummyService::DummyServer>::reset[abi:ne200100](a1: v17, a2: 0); /*0x10687c969*/
  }
  return result; /*0x10687c96e*/
}

// Address: 0x10687ca28 | Name: __ZN3RBX7Network6Server10disconnectEv
__int64 __fastcall RBX::Network::Server::disconnect(RBX::Network::Server *this, const RBX::Instance *a2)
{
  RBX::Players *v3; // rdi
  __int64 result; // rax

  v3 = *((RBX::Players **)this + 61); /*0x10687ca32*/
  if ( v3 != nullptr ) /*0x10687ca3c*/
  {
    if ( FFlag::RemoveLegacyChatCodeInNetwork == 0 ) /*0x10687ca4f*/
      RBX::Players::endChatSenderConnection(this: v3); /*0x10687ca51*/
    RBX::Network::Server::stop((RBX::Network::ConcurrentRakPeer **)this, a2); /*0x10687ca59*/
    return std::shared_ptr<RBX::Players>::reset[abi:ne200100](a1: (char *)this + 488); /*0x10687ca65*/
  }
  return result; /*0x10687ca61*/
}

// Address: 0x10687cc72 | Name: __ZN3RBX7Network6Server26configureAsCloudEditServerEv
void __fastcall RBX::Network::Server::configureAsCloudEditServer(RBX::Network::Server *this, const RBX::Instance *a2)
{
  RBX::Instance *v3; // rsi
  RBX::DataModel *v4; // rax
  bool v5; // r9
  RBX::Analytics::Event *v6; // rdi
  __int64 CurrentReporter; // rax
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // rbx
  __int64 v11; // rdx
  __int64 v12; // rcx
  RBX *exception; // r14
  _BYTE v14[16]; // [rsp+0h] [rbp-40h] BYREF
  void *v15; // [rsp+10h] [rbp-30h]
  _BYTE v16[16]; // [rsp+18h] [rbp-28h] BYREF
  void *v17; // [rsp+28h] [rbp-18h]

  if ( (unsigned __int8)RBX::DataModel::clientIsPresent(this, a2) != 0 ) /*0x10687cc87*/
  {
    exception = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10687cd50*/
    RBX::runtime_error(this: exception, a2: "Can not call server, client is present."); /*0x10687cd5f*/
    __cxa_throw( /*0x10687cd75*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  v4 = (RBX::DataModel *)RBX::DataModel::get(this, a2: v3); /*0x10687cc90*/
  if ( v4 != nullptr ) /*0x10687cc98*/
    RBX::DataModel::setCloudEdit(this: v4); /*0x10687cc9d*/
  RBX::Network::Server::setupToReceiveStudioClients(this); /*0x10687cca5*/
  *((_DWORD *)this + 134) = 2; /*0x10687ccaa*/
  RBX::Network::MegaReplicator::setIsCloudEdit(this: (RBX::Network::Server *)((char *)this + 544)); /*0x10687ccbe*/
  RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x10687ccdd*/
    this: (RBX::Analytics::Event *)"Game",
    a2: "Team Create",
    a3: "Server Start",
    a4: nullptr,
    a5: 0,
    a6: v5);
  CurrentReporter = RBX::Analytics::Event::getCurrentReporter(this: v6); /*0x10687cce2*/
  if ( CurrentReporter != 0 ) /*0x10687ccea*/
  {
    v10 = CurrentReporter; /*0x10687ccec*/
    std::string::basic_string[abi:ne200100]<0>(a1: v14, a2: "rcc_tc_config", a3: v8, a4: v9); /*0x10687ccfa*/
    std::string::basic_string[abi:ne200100]<0>(a1: v16, a2: "edit", a3: v11, a4: v12); /*0x10687cd0a*/
    RBX::Analytics::Event::GAReporter::addParameter(a1: v10, a2: v14, a3: v16); /*0x10687cd1a*/
    if ( (v16[0] & 1) != 0 ) /*0x10687cd23*/
      operator delete(a1: v17); /*0x10687cd29*/
    if ( (v14[0] & 1) != 0 ) /*0x10687cd32*/
      operator delete(a1: v15); /*0x10687cd38*/
  }
}

// Address: 0x10687cdb6 | Name: __ZN3RBX7Network6Server27setupToReceiveStudioClientsEv
__int64 __fastcall RBX::Network::Server::setupToReceiveStudioClients(RBX::Network::ConcurrentRakPeer **this)
{
  __int64 v2; // rax
  __int64 v3; // rdx
  unsigned __int8 *v4; // rsi

  if ( FFlag::DebugLocalRccServerConnection == 0 ) /*0x10687cdc9*/
    RBX::Network::initWithCloudEditSecurity((RBX::Network *)this); /*0x10687cdcb*/
  v2 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x10687cdd7*/
  if ( (RBX::Network::versionB[0] & 1) != 0 ) /*0x10687cde9*/
  {
    v3 = *(unsigned int *)&RBX::Network::versionB[8]; /*0x10687cdeb*/
    v4 = *(unsigned __int8 **)&RBX::Network::versionB[16]; /*0x10687cdee*/
  }
  else
  {
    v3 = RBX::Network::versionB[0] >> 1; /*0x10687cdf4*/
    v4 = &RBX::Network::versionB[1]; /*0x10687cdf6*/
  }
  return (*(__int64 (__fastcall **)(__int64, unsigned __int8 *, __int64))(*(_QWORD *)v2 + 88LL))(a1: v2, a2: v4, a3: v3); /*0x10687ce08*/
}

// Address: 0x10687ce0c | Name: __ZN3RBX7Network6Server25configureAsTeamTestServerEb
__int64 __fastcall RBX::Network::Server::configureAsTeamTestServer(RBX::Network::Server *this, const RBX::Instance *a2)
{
  unsigned __int8 v2; // r14
  __int64 v4; // rax
  bool v5; // r9
  RBX::Analytics::Event *v6; // rdi
  __int64 CurrentReporter; // rax
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // rbx
  __int64 v11; // rdx
  __int64 v12; // rcx
  __int64 result; // rax
  RBX *exception; // r14
  _BYTE v15[16]; // [rsp+0h] [rbp-40h] BYREF
  void *v16; // [rsp+10h] [rbp-30h]
  _BYTE v17[16]; // [rsp+18h] [rbp-28h] BYREF
  void *v18; // [rsp+28h] [rbp-18h]

  v2 = (unsigned __int8)a2; /*0x10687ce17*/
  if ( ((unsigned __int8)a2 & (unsigned __int8)FFlag::RCCShouldUseObfuscatedByteCodeInTeamTestSignal) == 0 /*0x10687ce30*/
    && (unsigned __int8)RBX::DataModel::clientIsPresent(this, a2) != 0 )
  {
    exception = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10687cf33*/
    RBX::runtime_error(this: exception, a2: "Cannot call configureAsTeamTestServer() from clients"); /*0x10687cf42*/
    __cxa_throw( /*0x10687cf58*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  v4 = RBX::DataModel::get(this, a2); /*0x10687ce39*/
  if ( v4 != 0 ) /*0x10687ce41*/
    *(_DWORD *)(v4 + 2264) = 2; /*0x10687ce43*/
  if ( ((unsigned __int8)FFlag::RCCShouldUseObfuscatedByteCodeInTeamTestSignal & v2) == 1 ) /*0x10687ce58*/
  {
    *((_BYTE *)this + 5304) = 1; /*0x10687ce5a*/
  }
  else
  {
    RBX::Network::Server::setupToReceiveStudioClients((RBX::Network::ConcurrentRakPeer **)this); /*0x10687ce66*/
    *((_DWORD *)this + 134) = 1; /*0x10687ce6b*/
  }
  RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x10687ce8f*/
    this: (RBX::Analytics::Event *)"Game",
    a2: "Team Create",
    a3: "Test Server Start",
    a4: nullptr,
    a5: 0,
    a6: v5);
  CurrentReporter = RBX::Analytics::Event::getCurrentReporter(this: v6); /*0x10687ce94*/
  if ( CurrentReporter != 0 ) /*0x10687ce9c*/
  {
    v10 = CurrentReporter; /*0x10687ce9e*/
    std::string::basic_string[abi:ne200100]<0>(a1: v15, a2: "rcc_tc_config", a3: v8, a4: v9); /*0x10687ceac*/
    std::string::basic_string[abi:ne200100]<0>(a1: v17, a2: "team_test", a3: v11, a4: v12); /*0x10687cebc*/
    RBX::Analytics::Event::GAReporter::addParameter(a1: v10, a2: v15, a3: v17); /*0x10687cecc*/
    if ( (v17[0] & 1) != 0 ) /*0x10687ced5*/
      operator delete(a1: v18); /*0x10687cedb*/
    if ( (v15[0] & 1) != 0 ) /*0x10687cee4*/
      operator delete(a1: v16); /*0x10687ceea*/
  }
  result = (unsigned int)DFLog::TeamTest >> 8; /*0x10687cef8*/
  LOBYTE(result) = (unsigned __int8)DFLog::TeamTest < 6u || BYTE1(DFLog::TeamTest) < 3u; /*0x10687cf07*/
  if ( (_BYTE)result == 0 ) /*0x10687cf09*/
    return FLog::FastLog( /*0x10687cf1b*/
             a1: DFLog::TeamTest,
             a2: qword_10D80F648,
             a3: "[DFLog::TeamTest] Finished configuring as team test server",
             0);
  return result; /*0x10687cf20*/
}

// Address: 0x10687cf98 | Name: __ZN3RBX7Network6Server42configureAsCloudSessionTaskExecutionServerEv
__int64 __fastcall RBX::Network::Server::configureAsCloudSessionTaskExecutionServer(
        RBX::Network::Server *this,
        RBX::Instance *a2)
{
  __int64 result; // rax

  result = RBX::DataModel::get(this, a2); /*0x10687cf9c*/
  if ( result != 0 ) /*0x10687cfa4*/
    *(_DWORD *)(result + 2264) = 3; /*0x10687cfa6*/
  return result; /*0x10687cfb0*/
}

// Address: 0x10687cfb2 | Name: __ZNK3RBX7Network6Server33getIsPlayerAuthenticationRequiredEv
char __fastcall RBX::Network::Server::getIsPlayerAuthenticationRequired(RBX::Network::Server *this)
{
  if ( FFlag::DebugLocalRccServerConnection != 0 /*0x10687cfce*/
    || (unsigned __int8)RBX::Network::isPlayerAuthenticationEnabled(this) == 0 )
  {
    return 0; /*0x10687cfd8*/
  }
  else
  {
    return *((_BYTE *)this + 4496); /*0x10687cfd0*/
  }
}

// Address: 0x10687cfe2 | Name: __ZN3RBX7Network6Server15onCreateRakPeerEv
__int64 __fastcall RBX::Network::Server::onCreateRakPeer(RBX::Network::ConcurrentRakPeer **this)
{
  __int64 v2; // rax
  __int64 v3; // rax
  __int64 v4; // rdx
  unsigned __int8 *v5; // rsi
  const RBX::Instance *v6; // rsi
  RBX::ServiceProvider *ServiceProvider; // rax
  RBX::RunService *v8; // rax
  unsigned __int8 v9; // r14
  __int64 v10; // rax

  RBX::Network::Peer::onCreateRakPeer((RBX::Network::Peer *)this); /*0x10687cfec*/
  v2 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x10687cff8*/
  (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v2 + 64LL))(a1: v2, a2: (unsigned __int16)FInt::MaxClients); /*0x10687d00a*/
  if ( FFlag::DebugLocalRccServerConnection == 1 ) /*0x10687d018*/
    std::string::assign(a1: RBX::Network::versionB, a2: "test"); /*0x10687d028*/
  v3 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x10687d034*/
  if ( (RBX::Network::versionB[0] & 1) != 0 ) /*0x10687d046*/
  {
    v4 = *(unsigned int *)&RBX::Network::versionB[8]; /*0x10687d048*/
    v5 = *(unsigned __int8 **)&RBX::Network::versionB[16]; /*0x10687d04b*/
  }
  else
  {
    v4 = RBX::Network::versionB[0] >> 1; /*0x10687d051*/
    v5 = &RBX::Network::versionB[1]; /*0x10687d053*/
  }
  (*(void (__fastcall **)(__int64, unsigned __int8 *, __int64))(*(_QWORD *)v3 + 88LL))(a1: v3, a2: v5, a3: v4); /*0x10687d05c*/
  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider( /*0x10687d062*/
                                              (RBX::ServiceProvider *)this,
                                              a2: v6);
  if ( ServiceProvider != nullptr ) /*0x10687d06a*/
    v8 = (RBX::RunService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::RunService>(this: ServiceProvider); /*0x10687d06f*/
  else
    v8 = nullptr; /*0x10687d076*/
  if ( FFlag::DebugLocalRccServerConnection == 1 ) /*0x10687d07c*/
    v9 = FFlag::DebugLocalRccTicketTesting; /*0x10687d085*/
  else
    v9 = RBX::RunService::isStudio(this: v8) ^ 1; /*0x10687d095*/
  v10 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x10687d0a0*/
  return (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v10 + 728LL))(a1: v10, a2: v9); /*0x10687d0b7*/
}

// Address: 0x10687d0bc | Name: __ZN3RBX7Network6Server17onServiceProviderEPNS_15ServiceProviderES3_
__int64 __fastcall RBX::Network::Server::onServiceProvider(
        RBX::Network::ConcurrentRakPeer **this,
        RBX::ServiceProvider *a2,
        RBX::ServiceProvider *a3)
{
  RBX::Players **v5; // r13
  const RBX::Instance *v6; // rsi
  __int64 v7; // rcx
  _QWORD *v8; // rdi
  __int64 v9; // rax
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // rbx
  __int64 v13; // rbx
  __int64 v14; // rdi
  __int64 v15; // rax
  RBX::Network::Server *v16; // rsi
  unsigned int v17; // esi
  unsigned int v18; // r12d
  rbx::signals::slots_holder **v19; // r15
  unsigned __int64 v20; // rsi
  unsigned __int64 v21; // r13
  rbx::signals::slots_holder *v22; // rax
  unsigned __int64 v23; // rax
  unsigned int v24; // esi
  std::__shared_weak_count *v25; // rdi
  __int64 v26; // rax
  _QWORD *v27; // r12
  RBX::Network *v28; // rdi
  unsigned int v29; // esi
  std::__shared_weak_count *v30; // rbx
  char v31; // al
  __int64 v32; // rbx
  __int64 v33; // r15
  __int64 v34; // r13
  __int64 v35; // rdi
  rbx::signals::slots_holder **v36; // r15
  unsigned int v37; // r13d
  unsigned __int64 v38; // rsi
  unsigned __int64 v39; // rbx
  rbx::signals::slots_holder *v40; // rax
  unsigned __int64 v41; // rax
  unsigned int v42; // esi
  std::__shared_weak_count *v43; // rdi
  __int64 v44; // rsi
  __int64 v45; // rax
  RBX::ServiceProvider *v46; // rbx
  __int64 v47; // r15
  __int64 v48; // r12
  std::__shared_weak_count *v49; // rbx
  std::__shared_weak_count *v50; // rbx
  __int64 v51; // r15
  std::__shared_weak_count *v52; // rbx
  std::__shared_weak_count *v53; // rbx
  std::__shared_weak_count *v54; // rbx
  __int64 v55; // rbx
  __int64 v56; // rax
  __int64 v57; // rax
  bool v58; // r9
  const char *v59; // rdx
  unsigned int v60; // esi
  unsigned int v61; // r15d
  rbx::signals::slots_holder **v62; // r13
  unsigned __int64 v63; // rsi
  unsigned __int64 v64; // rbx
  rbx::signals::slots_holder *v65; // rax
  unsigned __int64 v66; // rax
  unsigned int v67; // esi
  std::__shared_weak_count *v68; // rdi
  __int64 v69; // rax
  std::__shared_weak_count *v70; // rbx
  std::__shared_weak_count *v71; // rbx
  RBX *exception; // r14
  _QWORD v74[3]; // [rsp+8h] [rbp-F8h] BYREF
  __int128 v75; // [rsp+20h] [rbp-E0h] BYREF
  char *v76; // [rsp+38h] [rbp-C8h]
  _BYTE v77[8]; // [rsp+40h] [rbp-C0h] BYREF
  std::__shared_weak_count *v78; // [rsp+48h] [rbp-B8h]
  _BYTE v79[8]; // [rsp+50h] [rbp-B0h] BYREF
  std::__shared_weak_count *v80; // [rsp+58h] [rbp-A8h]
  char v81[16]; // [rsp+60h] [rbp-A0h] BYREF
  void *v82; // [rsp+70h] [rbp-90h]
  _DWORD v83[3]; // [rsp+84h] [rbp-7Ch]
  std::__shared_weak_count *v84[2]; // [rsp+90h] [rbp-70h] BYREF
  void *v85; // [rsp+A0h] [rbp-60h]
  std::__shared_weak_count **v86; // [rsp+B0h] [rbp-50h]
  char *v87; // [rsp+B8h] [rbp-48h] BYREF
  char **v88; // [rsp+C0h] [rbp-40h]

  *(_QWORD *)&v83[1] = a3; /*0x10687d0e7*/
  if ( a2 == nullptr ) /*0x10687d0eb*/
    goto LABEL_20; /*0x10687d0eb*/
  RBX::Network::ImGuiRegisterServer(this: nullptr, a2); /*0x10687d0f3*/
  rbx::signals::connection::disconnect(this: (rbx::signals::connection *)(this + 555)); /*0x10687d0ff*/
  RBX::TaskScheduler::remove(a1: this + 63); /*0x10687d10e*/
  std::shared_ptr<RBX::TaskScheduler::Job>::reset[abi:ne200100](a1: this + 63); /*0x10687d116*/
  if ( DFFlag::DebugEnablePhaseTracking == 1 ) /*0x10687d125*/
  {
    RBX::TaskScheduler::remove(a1: this + 65); /*0x10687d131*/
    std::shared_ptr<RBX::TaskScheduler::Job>::reset[abi:ne200100](a1: this + 65); /*0x10687d139*/
  }
  RBX::Network::MegaReplicator::removeMegaJobs(this: (RBX::Network::MegaReplicator *)(this + 68)); /*0x10687d148*/
  if ( *(this + 61) != nullptr ) /*0x10687d155*/
  {
    v5 = this + 61; /*0x10687d157*/
    rbx::signals::connection::disconnect(this: (rbx::signals::connection *)(this + 558)); /*0x10687d165*/
    if ( FFlag::RemoveLegacyChatCodeInNetwork == 0 ) /*0x10687d174*/
      RBX::Players::endChatSenderConnection(this: *v5); /*0x10687d17a*/
    v7 = (__int64)*v5 + 2080; /*0x10687d183*/
    v8 = *((_QWORD **)*v5 + 264); /*0x10687d18a*/
    *((_QWORD *)*v5 + 264) = 0; /*0x10687d191*/
    if ( v8 == (_QWORD *)v7 ) /*0x10687d19f*/
    {
      v9 = 32; /*0x10687d1ad*/
    }
    else
    {
      v9 = 40; /*0x10687d1a1*/
      if ( v8 == nullptr ) /*0x10687d1a9*/
        goto LABEL_12; /*0x10687d1a9*/
    }
    (*(void (**)(void))(*v8 + v9))(); /*0x10687d1b5*/
LABEL_12:
    RBX::Network::Server::stop(this, a2: v6); /*0x10687d1b8*/
    std::shared_ptr<RBX::Players>::reset[abi:ne200100](a1: this + 61); /*0x10687d1c3*/
  }
  rbx::signals::connection::disconnect(this: (rbx::signals::connection *)(this + 556)); /*0x10687d1c8*/
  rbx::signals::connection::disconnect(this: (rbx::signals::connection *)(this + 557)); /*0x10687d1db*/
  if ( DFFlag::ISRParallelWorkProfiling == 1 ) /*0x10687d1ea*/
  {
    v12 = *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::TestService>(this: a2); /*0x10687d1f4*/
    if ( v12 != 0 ) /*0x10687d1fa*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v84, a2: "ISRProfiling", a3: v10, a4: v11); /*0x10687d207*/
      RBX::TestService::unregisterTestSessionStatsProvider(a1: v12, a2: v84); /*0x10687d213*/
      if ( ((__int64)v84[0] & 1) != 0 ) /*0x10687d21c*/
        operator delete(a1: v85); /*0x10687d222*/
    }
  }
  RBX::Network::MegaReplicator::stopStreamingObserver(this: (RBX::Network::MegaReplicator *)(this + 68)); /*0x10687d22a*/
  RBX::Network::MegaReplicator::stopStreamingSolver(this: (RBX::Network::MegaReplicator *)(this + 68)); /*0x10687d232*/
  v13 = *((_QWORD *)a2 + 3); /*0x10687d237*/
  v15 = RBX::Reflection::Class_getDescriptorPtr<RBX::DataModel>(a1: v14); /*0x10687d23b*/
  if ( *(unsigned __int16 *)(v13 + 440) - (unsigned int)*(unsigned __int16 *)(v15 + 440) <= *(unsigned __int16 *)(v15 + 442) ) /*0x10687d259*/
    *((_BYTE *)a2 + 1805) = 0; /*0x10687d25b*/
  RBX::Network::Server::reportMaybeUnusedRemoteEvent((RBX::Network::Server *)this); /*0x10687d266*/
  a3 = *(RBX::ServiceProvider **)&v83[1]; /*0x10687d26b*/
LABEL_20:
  if ( a3 == nullptr ) /*0x10687d272*/
  {
    RBX::Network::Peer::onServiceProvider((RBX::Network::Peer *)this, a2, a3: nullptr); /*0x10687d316*/
    return __stack_chk_guard; /*0x10687d31b*/
  }
  if ( (unsigned __int8)RBX::DataModel::clientIsPresent(this: a3, a2) != 0 ) /*0x10687d282*/
  {
    exception = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10687da0e*/
    RBX::runtime_error(this: exception, a2: "Can not create server, client is present."); /*0x10687da1d*/
    __cxa_throw( /*0x10687da33*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  RBX::Network::Peer::onServiceProvider((RBX::Network::Peer *)this, a2, a3: *(RBX::ServiceProvider **)&v83[1]); /*0x10687d292*/
  RBX::Network::ImGuiRegisterServer((RBX::Network *)this, a2: v16); /*0x10687d29a*/
  v83[0] = (_DWORD)RBX::Memory::InstanceSignal; /*0x10687d2a8*/
  v18 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v17); /*0x10687d2b0*/
  v19 = (rbx::signals::slots_holder **)(*(_QWORD *)&v83[1] + 224LL); /*0x10687d2b7*/
  rbx::lazyInitSlotsHolder(a1: *(_QWORD *)&v83[1] + 224LL); /*0x10687d2c1*/
  v21 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v20); /*0x10687d2d0*/
  *(_QWORD *)v21 = &_mh_execute_header; /*0x10687d2dd*/
  *(_QWORD *)(v21 + 8) = rbx::signals::slot_with_functor<RBX::Network::Server::onServiceProvider(RBX::ServiceProvider *,RBX::ServiceProvider *)::$_1>::do_call; /*0x10687d2e8*/
  *(_OWORD *)(v21 + 16) = 0; /*0x10687d2ef*/
  v22 = *v19; /*0x10687d2f4*/
  *(_QWORD *)(v21 + 32) = *v19; /*0x10687d2f7*/
  if ( v22 != nullptr ) /*0x10687d2fe*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v22 + 1); /*0x10687d300*/
    v23 = *(_QWORD *)(v21 + 24) & 0xFFFFFFFFFFFFFFFBLL; /*0x10687d308*/
  }
  else
  {
    v23 = 0; /*0x10687d320*/
  }
  *(_QWORD *)(v21 + 24) = v23; /*0x10687d322*/
  *(_QWORD *)(v21 + 40) = this; /*0x10687d326*/
  rbx::signals::slots_holder::insert(this: *v19, a2: v21); /*0x10687d330*/
  v84[0] = (std::__shared_weak_count *)v21; /*0x10687d335*/
  _InterlockedIncrement((volatile signed __int32 *)(v21 + 4)); /*0x10687d339*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v18, a2: v24); /*0x10687d341*/
  rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(this + 555)); /*0x10687d351*/
  v25 = v84[0]; /*0x10687d35a*/
  if ( v84[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v84[0] + 1) == 0 ) /*0x10687d367*/
    rbx::signals::slot_base::operator delete(a1: v25); /*0x10687d369*/
  v26 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::Players>(this: *(RBX::ServiceProvider **)&v83[1]); /*0x10687d371*/
  RBX::shared_from<RBX::Players>(a1: v84, a2: v26); /*0x10687d37d*/
  v27 = this + 61; /*0x10687d382*/
  std::shared_ptr<RBX::Players>::operator=[abi:ne200100](a1: this + 61, a2: v84); /*0x10687d393*/
  v30 = v84[1]; /*0x10687d398*/
  if ( v84[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v84[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10687d3b1*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v30 + 16LL))(a1: v30); /*0x10687d3b9*/
    std::__shared_weak_count::__release_weak(this: v30); /*0x10687d3bf*/
  }
  if ( FFlag::RemoveLegacyChatCodeInNetwork == 0 ) /*0x10687d3ce*/
  {
    v31 = RBX::Network::flagsSendsGoThroughConnection(this: v28); /*0x10687d3d4*/
    v32 = *v27; /*0x10687d3d9*/
    if ( v31 != 0 ) /*0x10687d3df*/
    {
      v33 = operator new(a1: 0x88u); /*0x10687d3eb*/
      *(_QWORD *)v33 = &off_10CAA7128; /*0x10687d3f9*/
      *(_OWORD *)(v33 + 8) = 0; /*0x10687d3ff*/
      *(_QWORD *)(v33 + 24) = this; /*0x10687d404*/
    }
    else
    {
      v34 = (__int64)*(this + 36); /*0x10687d40f*/
      v33 = operator new(a1: 0x88u); /*0x10687d420*/
      *(_QWORD *)v33 = &off_10CAA7128; /*0x10687d42e*/
      *(_QWORD *)(v33 + 8) = v34; /*0x10687d431*/
      *(_OWORD *)(v33 + 16) = 0; /*0x10687d438*/
    }
    *(double *)(v33 + 32) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: 0.0); /*0x10687d442*/
    *(_BYTE *)(v33 + 40) = 1; /*0x10687d44a*/
    *(_QWORD *)(v33 + 48) = 0x3FA999999999999ALL; /*0x10687d458*/
    *(_OWORD *)(v33 + 56) = 0; /*0x10687d45f*/
    *(_QWORD *)(v33 + 72) = 0; /*0x10687d466*/
    *(_BYTE *)(v33 + 80) = 1; /*0x10687d46a*/
    *(_QWORD *)(v33 + 88) = 0; /*0x10687d46e*/
    *(_QWORD *)(v33 + 96) = 0x3FA999999999999ALL; /*0x10687d472*/
    *(_DWORD *)(v33 + 104) = 0; /*0x10687d476*/
    *(_OWORD *)(v33 + 112) = 0; /*0x10687d47e*/
    *(_BYTE *)(v33 + 128) = 1; /*0x10687d483*/
    v35 = *(_QWORD *)(v32 + 520); /*0x10687d48a*/
    *(_QWORD *)(v32 + 520) = v33; /*0x10687d491*/
    if ( v35 != 0 ) /*0x10687d49b*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v35 + 48LL))(a1: v35); /*0x10687d4a0*/
  }
  v36 = (rbx::signals::slots_holder **)(*v27 + 1968LL); /*0x10687d4a9*/
  v37 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v83[0], a2: v29); /*0x10687d4b5*/
  rbx::lazyInitSlotsHolder(a1: v36); /*0x10687d4bb*/
  v39 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v38); /*0x10687d4ca*/
  *(_QWORD *)v39 = &_mh_execute_header; /*0x10687d4d7*/
  *(_QWORD *)(v39 + 8) = rbx::signals::slot_with_functor<RBX::Network::Server::onServiceProvider(RBX::ServiceProvider *,RBX::ServiceProvider *)::$_2>::do_call; /*0x10687d4e1*/
  *(_OWORD *)(v39 + 16) = 0; /*0x10687d4e8*/
  v40 = *v36; /*0x10687d4ec*/
  *(_QWORD *)(v39 + 32) = *v36; /*0x10687d4ef*/
  if ( v40 != nullptr ) /*0x10687d4f6*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v40 + 1); /*0x10687d4f8*/
    v41 = *(_QWORD *)(v39 + 24) & 0xFFFFFFFFFFFFFFFBLL; /*0x10687d500*/
  }
  else
  {
    v41 = 0; /*0x10687d506*/
  }
  *(_QWORD *)(v39 + 24) = v41; /*0x10687d508*/
  *(_QWORD *)(v39 + 40) = this; /*0x10687d50c*/
  rbx::signals::slots_holder::insert(this: *v36, a2: v39); /*0x10687d516*/
  v84[0] = (std::__shared_weak_count *)v39; /*0x10687d51b*/
  _InterlockedIncrement((volatile signed __int32 *)(v39 + 4)); /*0x10687d51f*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v37, a2: v42); /*0x10687d526*/
  rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(this + 558)); /*0x10687d539*/
  v43 = v84[0]; /*0x10687d53e*/
  if ( v84[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v84[0] + 1) == 0 ) /*0x10687d54b*/
    rbx::signals::slot_base::operator delete(a1: v43); /*0x10687d54d*/
  v44 = *v27 + 2080LL; /*0x10687d557*/
  v84[0] = (std::__shared_weak_count *)off_10CAAECC0; /*0x10687d562*/
  v86 = v84; /*0x10687d566*/
  std::__function::__value_func<bool ()(std::shared_ptr<RBX::Player>)>::swap[abi:ne200100](a1: v84, a2: v44); /*0x10687d56d*/
  if ( v86 == v84 ) /*0x10687d579*/
  {
    v45 = 32; /*0x10687d58b*/
    v46 = *(RBX::ServiceProvider **)&v83[1]; /*0x10687d590*/
    goto LABEL_48; /*0x10687d590*/
  }
  v45 = 40; /*0x10687d57b*/
  v46 = *(RBX::ServiceProvider **)&v83[1]; /*0x10687d583*/
  if ( v86 != nullptr ) /*0x10687d587*/
LABEL_48:
    (*(void (**)(void))((char *)*v86 + v45))(); /*0x10687d594*/
  RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::Network::ClusterPacketCache>(this: v46); /*0x10687d59a*/
  v47 = operator new(a1: 0x1E8u); /*0x10687d5ac*/
  v48 = *(_QWORD *)&v83[1] - 464LL; /*0x10687d5b3*/
  RBX::shared_from<RBX::DataModel>(a1: v77, a2: *(_QWORD *)&v83[1] - 464LL); /*0x10687d5c4*/
  RBX::Network::NetworkOwnerJob::NetworkOwnerJob(a1: v47, a2: v77); /*0x10687d5d3*/
  std::shared_ptr<RBX::Network::NetworkOwnerJob>::shared_ptr[abi:ne200100]<RBX::Network::NetworkOwnerJob,0>( /*0x10687d5df*/
    a1: v84,
    a2: v47);
  std::shared_ptr<RBX::TaskScheduler::Job>::operator=[abi:ne200100]<RBX::Network::NetworkOwnerJob,0>( /*0x10687d5f5*/
    a1: this + 63,
    a2: v84);
  v49 = v84[1]; /*0x10687d5fa*/
  if ( v84[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v84[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10687d613*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v49 + 16LL))(a1: v49); /*0x10687d61b*/
    std::__shared_weak_count::__release_weak(this: v49); /*0x10687d621*/
  }
  v50 = v78; /*0x10687d626*/
  if ( v78 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v78 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10687d642*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v50 + 16LL))(a1: v50); /*0x10687d64a*/
    std::__shared_weak_count::__release_weak(this: v50); /*0x10687d650*/
  }
  RBX::TaskScheduler::add(a1: this + 63); /*0x10687d658*/
  if ( DFFlag::DebugEnablePhaseTracking == 1 ) /*0x10687d667*/
  {
    v51 = operator new(a1: 0x1F0u); /*0x10687d677*/
    RBX::shared_from<RBX::DataModel>(a1: v79, a2: v48); /*0x10687d684*/
    RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob(a1: v51, a2: (__int64)v79, a3: (__int64)(this + 68)); /*0x10687d69a*/
    std::shared_ptr<RBX::Network::RomarkPhaseTrackingJob>::shared_ptr[abi:ne200100]<RBX::Network::RomarkPhaseTrackingJob,0>( /*0x10687d6a6*/
      a1: v84,
      a2: v51);
    std::shared_ptr<RBX::TaskScheduler::Job>::operator=[abi:ne200100]<RBX::Network::RomarkPhaseTrackingJob,0>( /*0x10687d6bc*/
      a1: this + 65,
      a2: v84);
    v52 = v84[1]; /*0x10687d6c1*/
    if ( v84[1] != nullptr /*0x10687d6da*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v84[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v52 + 16LL))(a1: v52); /*0x10687d6e2*/
      std::__shared_weak_count::__release_weak(this: v52); /*0x10687d6e8*/
    }
    v53 = v80; /*0x10687d6ed*/
    if ( v80 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v80 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10687d709*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v53 + 16LL))(a1: v53); /*0x10687d711*/
      std::__shared_weak_count::__release_weak(this: v53); /*0x10687d717*/
    }
    RBX::TaskScheduler::add(a1: this + 65); /*0x10687d71f*/
  }
  RBX::shared_from<RBX::DataModel>(a1: v84, a2: v48); /*0x10687d72b*/
  v76 = (char *)(this + 68); /*0x10687d73b*/
  RBX::Network::MegaReplicator::startMegaJobs(a1: this + 68, a2: v84); /*0x10687d742*/
  v54 = v84[1]; /*0x10687d747*/
  if ( v84[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v84[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10687d760*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v54 + 16LL))(a1: v54); /*0x10687d768*/
    std::__shared_weak_count::__release_weak(this: v54); /*0x10687d76e*/
  }
  v55 = *(_QWORD *)(*(_QWORD *)&v83[1] + 376LL); /*0x10687d777*/
  *(_OWORD *)v81 = 0; /*0x10687d781*/
  v82 = nullptr; /*0x10687d788*/
  v87 = (char *)v84 + 1; /*0x10687d79b*/
  v88 = &v87; /*0x10687d79f*/
  v56 = -v55; /*0x10687d7a6*/
  if ( v55 > 0 ) /*0x10687d7a9*/
    v56 = v55; /*0x10687d7a9*/
  v74[0] = v56; /*0x10687d7b4*/
  v74[1] = &v87; /*0x10687d7b7*/
  LOBYTE(v74[2]) = 48; /*0x10687d7bb*/
  HIDWORD(v74[2]) = 48; /*0x10687d7bf*/
  v57 = boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned long long,char>::convert(a1: (__int64)v74); /*0x10687d7c6*/
  if ( v55 < 0 ) /*0x10687d7ce*/
    *(_BYTE *)--v57 = 45; /*0x10687d7d0*/
  v87 = (char *)v57; /*0x10687d7d7*/
  v88 = &v87; /*0x10687d7db*/
  std::string::__assign_trivial[abi:ne200100]<char const*,char const*>( /*0x10687d7f2*/
    a1: v81,
    a2: v57,
    a3: &v87,
    a4: (char *)&v87 - v57);
  if ( (v81[0] & 1) != 0 ) /*0x10687d7fe*/
    v59 = (const char *)v82; /*0x10687d800*/
  else
    v59 = &v81[1]; /*0x10687d809*/
  RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x10687d823*/
    this: (RBX::Analytics::Event *)"Game",
    a2: "PlaceID",
    a3: v59,
    a4: nullptr,
    a5: 0,
    a6: v58);
  if ( (v81[0] & 1) != 0 ) /*0x10687d82f*/
    operator delete(a1: v82); /*0x10687d838*/
  if ( *(_QWORD *)(*(_QWORD *)&v83[1] + 376LL) != 0 ) /*0x10687d849*/
  {
    v61 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v83[0], a2: v60); /*0x10687d853*/
    v62 = (rbx::signals::slots_holder **)(*(_QWORD *)&v83[1] + 520LL); /*0x10687d85a*/
    rbx::lazyInitSlotsHolder(a1: *(_QWORD *)&v83[1] + 520LL); /*0x10687d864*/
    v64 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v63); /*0x10687d873*/
    *(_QWORD *)v64 = &_mh_execute_header; /*0x10687d880*/
    *(_QWORD *)(v64 + 8) = rbx::signals::slot_with_functor<RBX::Network::Server::onServiceProvider(RBX::ServiceProvider *,RBX::ServiceProvider *)::$_3>::do_call; /*0x10687d88a*/
    *(_OWORD *)(v64 + 16) = 0; /*0x10687d891*/
    v65 = *v62; /*0x10687d895*/
    *(_QWORD *)(v64 + 32) = *v62; /*0x10687d899*/
    if ( v65 != nullptr ) /*0x10687d8a0*/
    {
      _InterlockedIncrement((volatile signed __int32 *)v65 + 1); /*0x10687d8a2*/
      v66 = *(_QWORD *)(v64 + 24) & 0xFFFFFFFFFFFFFFFBLL; /*0x10687d8aa*/
    }
    else
    {
      v66 = 0; /*0x10687d8ba*/
    }
    *(_QWORD *)(v64 + 24) = v66; /*0x10687d8bc*/
    *(_QWORD *)(v64 + 40) = this; /*0x10687d8c0*/
    rbx::signals::slots_holder::insert(this: *v62, a2: v64); /*0x10687d8cb*/
    v84[0] = (std::__shared_weak_count *)v64; /*0x10687d8d0*/
    _InterlockedIncrement((volatile signed __int32 *)(v64 + 4)); /*0x10687d8d4*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v61, a2: v67); /*0x10687d8db*/
    rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(this + 557)); /*0x10687d8ee*/
    v68 = v84[0]; /*0x10687d8f3*/
    if ( v84[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v84[0] + 1) == 0 ) /*0x10687d900*/
      rbx::signals::slot_base::operator delete(a1: v68); /*0x10687d902*/
  }
  else
  {
    RBX::Network::Server::onWorkspaceLoaded((RBX::Network::Server *)this); /*0x10687d8b3*/
  }
  *(_BYTE *)(*(_QWORD *)&v83[1] + 1805LL) = 1; /*0x10687d90b*/
  if ( FFlag::LrPullSystem == 1 ) /*0x10687d91c*/
  {
    std::allocate_shared[abi:ne200100]<RBX::Network::LargeReplicatorPullManager,std::allocator<RBX::Network::LargeReplicatorPullManager>,RBX::DataModel &,0>( /*0x10687d930*/
      a1: v84,
      a2: v74,
      a3: v48);
    v69 = RBX::EngineContext::getModule<RBX::Network::NetAssetManagerEngineModule>(a1: *(_QWORD *)(*(_QWORD *)&v83[1] /*0x10687d941*/
                                                                                                 + 88LL) & 0xFFFFFFFFFFFFFFF8LL);
    v75 = *(_OWORD *)v84; /*0x10687d94e*/
    if ( v84[1] != nullptr ) /*0x10687d958*/
      _InterlockedIncrement64((volatile signed __int64 *)v84[1] + 1); /*0x10687d95a*/
    std::shared_ptr<RBX::Network::PullManagerInterface>::operator=[abi:ne200100](a1: v69 + 24, a2: &v75); /*0x10687d970*/
    v70 = *((std::__shared_weak_count **)&v75 + 1); /*0x10687d975*/
    if ( *((_QWORD *)&v75 + 1) != 0 /*0x10687d98e*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v75 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v70 + 16LL))(a1: v70); /*0x10687d996*/
      std::__shared_weak_count::__release_weak(this: v70); /*0x10687d99c*/
    }
    RBX::Network::MegaReplicator::setLargeReplicatorPullManager(a1: v76, a2: v84); /*0x10687d9ac*/
    v71 = v84[1]; /*0x10687d9b1*/
    if ( v84[1] != nullptr /*0x10687d9ca*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v84[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v71 + 16LL))(a1: v71); /*0x10687d9d2*/
      std::__shared_weak_count::__release_weak(this: v71); /*0x10687d9d8*/
    }
  }
  return __stack_chk_guard; /*0x10687d9ed*/
}

// Address: 0x10687db5a | Name: __ZNK3RBX7Network6Server28reportMaybeUnusedRemoteEventEv
__int64 __fastcall RBX::Network::Server::reportMaybeUnusedRemoteEvent(RBX::Network::Server *this)
{
  _QWORD *i; // r13
  __int64 v3; // rdx
  const char *v4; // rdx
  __int64 v5; // rdx
  __int64 v6; // rcx
  _QWORD v8[3]; // [rsp+8h] [rbp-238h] BYREF
  _BYTE v9[16]; // [rsp+20h] [rbp-220h] BYREF
  void *v10; // [rsp+30h] [rbp-210h]
  void *v11[59]; // [rsp+38h] [rbp-208h] BYREF

  std::vector<std::string>::vector[abi:ne200100](a1: v8, a2: *((_QWORD *)this + 637)); /*0x10687db90*/
  for ( i = *((_QWORD **)this + 636); i != nullptr; i = (_QWORD *)*i ) /*0x10687db9f*/
  {
    v3 = *(_QWORD *)(i[2] + 8LL); /*0x10687dbba*/
    if ( (*(_BYTE *)v3 & 1) != 0 ) /*0x10687dbc1*/
      v4 = *(const char **)(v3 + 16); /*0x10687dbc8*/
    else
      v4 = (const char *)(v3 + 1); /*0x10687dbc3*/
    RBX::format(this: (RBX *)v11, a2: "%s=%llu", v4, i[3]); /*0x10687dbd8*/
    std::vector<std::string>::push_back[abi:ne200100](a1: (__int64)v8, a2: (__int64)v11); /*0x10687dbe3*/
    if ( ((__int64)v11[0] & 1) != 0 ) /*0x10687dbef*/
      operator delete(a1: v11[2]); /*0x10687dbf8*/
  }
  RBX::Analytics::InfluxDb::Points::Points(a1: v11, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x10687dc16*/
  RBX::StringUtil::detail::join_impl<std::string,std::__wrap_iter<std::string*>>( /*0x10687dc3d*/
    a1: v9,
    a2: v8[0],
    a3: v8[1],
    a4: " ",
    a5: 1);
  RBX::Analytics::InfluxDb::Points::addPoint(a1: v11, a2: "Events", a3: v9); /*0x10687dc57*/
  if ( (v9[0] & 1) != 0 ) /*0x10687dc63*/
    operator delete(a1: v10); /*0x10687dc6c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v9, a2: "NfwlTracking", a3: v5, a4: v6); /*0x10687dc7f*/
  RBX::Analytics::InfluxDb::Points::report(a1: v11, a2: v9, a3: (unsigned int)DFInt::NfwlTrackingPermyriad, a4: 0); /*0x10687dc9a*/
  if ( (v9[0] & 1) != 0 ) /*0x10687dca6*/
    operator delete(a1: v10); /*0x10687dcaf*/
  RBX::Analytics::InfluxDb::Points::~Points(this: v11); /*0x10687dcbe*/
  v11[0] = v8; /*0x10687dcc3*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: v11); /*0x10687dccd*/
  return __stack_chk_guard; /*0x10687dce2*/
}

// Address: 0x10687de72 | Name: __ZN3RBX7Network6Server17onWorkspaceLoadedEv
__int64 __fastcall RBX::Network::Server::onWorkspaceLoaded(RBX::Network::Server *this, unsigned int a2)
{
  unsigned int v3; // ebx
  __int64 v4; // r12
  const RBX::Instance *v5; // rsi
  RBX::ServiceProvider *ServiceProvider; // rax
  RBX::Instance *v7; // rsi
  RBX::StarterPlayerService *v8; // rax
  unsigned int v9; // esi
  __int64 v10; // r15
  bool v11; // r9
  RBX::InstanceComponentHelpers *v12; // r15
  RBX::Instance *v13; // rsi
  rbx::signals::slots_holder **DescendantAddedSignal; // r12
  unsigned int v15; // esi
  unsigned int v16; // r15d
  unsigned __int64 v17; // rsi
  volatile signed __int32 *v18; // r13
  rbx::signals::slots_holder *v19; // rax
  unsigned __int64 v20; // rax
  unsigned int v21; // esi

  v3 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkServer, a2); /*0x10687de8e*/
  v4 = RBX::ServiceProvider::find<RBX::Workspace>(a1: this); /*0x10687de98*/
  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2: v5); /*0x10687de9e*/
  if ( ServiceProvider != nullptr ) /*0x10687dea6*/
  {
    v8 = (RBX::StarterPlayerService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::StarterPlayerService>(this: ServiceProvider); /*0x10687deab*/
    if ( v8 != nullptr ) /*0x10687deb3*/
      RBX::StarterPlayerService::recordSettingsInGA(this: v8); /*0x10687deb8*/
  }
  v10 = RBX::DataModel::get(this, a2: v7); /*0x10687dec5*/
  if ( v10 != 0 ) /*0x10687decb*/
  {
    if ( (unsigned __int8)RBX::WorkspaceProp::getNetworkStreamingEnabled(this: (RBX::WorkspaceProp *)(v4 + 1056)) != 0 /*0x10687deec*/
      && *(_DWORD *)(v10 + 2264) != 1 )
    {
      RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x10687df08*/
        this: (RBX::Analytics::Event *)"Game",
        a2: "NetworkStreamingEnabled",
        a3: "none",
        a4: nullptr,
        a5: 0,
        a6: v11);
    }
    v12 = (RBX::InstanceComponentHelpers *)(v10 + 464); /*0x10687df0d*/
    RBX::Instance::visitDescendants<RBX::Network::Server::onWorkspaceLoaded(void)::$_0>(a1: v12); /*0x10687df1e*/
    DescendantAddedSignal = (rbx::signals::slots_holder **)RBX::InstanceComponentHelpers::getOrCreateDescendantAddedSignal( /*0x10687df2b*/
                                                             this: v12,
                                                             a2: v13);
    v16 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v15); /*0x10687df3c*/
    rbx::lazyInitSlotsHolder(a1: DescendantAddedSignal); /*0x10687df42*/
    v18 = (volatile signed __int32 *)rbx::signals::slot_base::operator new( /*0x10687df51*/
                                       this: (rbx::signals::slot_base *)0x30,
                                       a2: v17);
    *(_QWORD *)v18 = &_mh_execute_header; /*0x10687df5e*/
    *((_QWORD *)v18 + 1) = rbx::signals::slot_with_functor<RBX::Network::Server::onWorkspaceLoaded(void)::$_1,std::shared_ptr<RBX::Instance>>::do_call; /*0x10687df69*/
    *((_OWORD *)v18 + 1) = 0; /*0x10687df70*/
    v19 = *DescendantAddedSignal; /*0x10687df75*/
    *((_QWORD *)v18 + 4) = *DescendantAddedSignal; /*0x10687df79*/
    if ( v19 != nullptr ) /*0x10687df80*/
    {
      _InterlockedIncrement((volatile signed __int32 *)v19 + 1); /*0x10687df82*/
      v20 = *((_QWORD *)v18 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x10687df8a*/
    }
    else
    {
      v20 = 0; /*0x10687df90*/
    }
    *((_QWORD *)v18 + 3) = v20; /*0x10687df92*/
    *((_QWORD *)v18 + 5) = this; /*0x10687df96*/
    rbx::signals::slots_holder::insert(this: *DescendantAddedSignal, a2: (unsigned __int64)v18); /*0x10687dfa1*/
    _InterlockedIncrement(v18 + 1); /*0x10687dfaa*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v16, a2: v21); /*0x10687dfb2*/
    rbx::signals::scoped_connection::operator=(this: (RBX::Network::Server *)((char *)this + 4448)); /*0x10687dfc5*/
    if ( v18 != nullptr && _InterlockedDecrement(v18 + 1) == 0 ) /*0x10687dfd7*/
      rbx::signals::slot_base::operator delete(a1: (void *)v18); /*0x10687dfd9*/
  }
  return RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v3, a2: v9); /*0x10687dfe9*/
}

// Address: 0x10687e14e | Name: __ZN3RBX7Network6Server11onItemAddedENSt3__110shared_ptrINS_8InstanceEEE
__int64 __fastcall RBX::Network::Server::onItemAdded(RBX::Network::Server *this, _QWORD **a2)
{
  unsigned int v4; // ebx
  unsigned int v5; // esi
  _QWORD *v6; // r15
  __int64 v7; // r12
  __int64 v8; // rax
  __int64 v9; // rdi
  __int64 v10; // rsi
  __int64 v11; // r12
  __int64 v12; // rax
  __int64 v13; // r12
  __int64 v14; // rax
  RBX::ContentId *ScriptId; // rax
  bool v16; // zf
  __int64 v17; // rax
  RBX::ContentId *v18; // rax
  __int64 v19; // rcx
  RBX::ContentId *v21; // rax
  __int16 Type; // ax
  _BYTE v23[8]; // [rsp+8h] [rbp-58h] BYREF
  _BYTE v24[16]; // [rsp+10h] [rbp-50h] BYREF
  unsigned int v25; // [rsp+20h] [rbp-40h] BYREF
  _BYTE v26[16]; // [rsp+28h] [rbp-38h] BYREF
  char v27; // [rsp+38h] [rbp-28h]

  v4 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkServer, (unsigned int)a2); /*0x10687e16e*/
  v6 = *a2; /*0x10687e170*/
  if ( v6 == nullptr ) /*0x10687e176*/
    goto LABEL_5; /*0x10687e176*/
  v7 = v6[3]; /*0x10687e178*/
  v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::Script>(); /*0x10687e17c*/
  if ( *(unsigned __int16 *)(v7 + 440) - (unsigned int)*(unsigned __int16 *)(v8 + 440) <= *(unsigned __int16 *)(v8 + 442) ) /*0x10687e19c*/
  {
    ScriptId = (RBX::ContentId *)RBX::LuaSourceContainer::getScriptId(this: (RBX::LuaSourceContainer *)v6); /*0x10687e1fb*/
    v16 = (unsigned __int16)RBX::ContentId::getType(this: ScriptId) == 2; /*0x10687e208*/
    v17 = 376; /*0x10687e20c*/
    goto LABEL_8; /*0x10687e211*/
  }
  v11 = v6[3]; /*0x10687e19e*/
  v12 = RBX::Reflection::Class_getDescriptorPtr<RBX::ModuleScript>(a1: v9, a2: v10); /*0x10687e1a2*/
  if ( *(unsigned __int16 *)(v11 + 440) - (unsigned int)*(unsigned __int16 *)(v12 + 440) <= *(unsigned __int16 *)(v12 + 442) ) /*0x10687e1c2*/
  {
    v18 = (RBX::ContentId *)RBX::LuaSourceContainer::getScriptId(this: (RBX::LuaSourceContainer *)v6); /*0x10687e216*/
    v16 = (unsigned __int16)RBX::ContentId::getType(this: v18) == 2; /*0x10687e223*/
    v17 = 288; /*0x10687e227*/
LABEL_8:
    v19 = 184; /*0x10687e22c*/
    if ( v16 ) /*0x10687e231*/
      v19 = v17; /*0x10687e231*/
LABEL_10:
    RBX::ProtectedString::ProtectedString( /*0x10687e235*/
      this: (RBX::ProtectedString *)&v25,
      a2: (const RBX::ProtectedString *)((char *)v6 + v19));
    v27 = 1; /*0x10687e244*/
LABEL_11:
    RBX::Network::Server::registerLegalSharedScript(this, a2: (const RBX::SharedString *)&v25); /*0x10687e248*/
    goto LABEL_12; /*0x10687e24f*/
  }
  v13 = v6[3]; /*0x10687e1c4*/
  v14 = RBX::Reflection::Class_getDescriptorPtr<RBX::AuroraScript>(); /*0x10687e1c8*/
  if ( *(unsigned __int16 *)(v13 + 440) - (unsigned int)*(unsigned __int16 *)(v14 + 440) > *(unsigned __int16 *)(v14 + 442) ) /*0x10687e1e8*/
  {
LABEL_5:
    LOBYTE(v25) = 0; /*0x10687e1ee*/
    v27 = 0; /*0x10687e1f3*/
    goto LABEL_12; /*0x10687e1f6*/
  }
  v21 = (RBX::ContentId *)RBX::LuaSourceContainer::getScriptId(this: (RBX::LuaSourceContainer *)v6); /*0x10687e283*/
  Type = RBX::ContentId::getType(this: v21); /*0x10687e28b*/
  v19 = 184; /*0x10687e290*/
  if ( Type != 2 ) /*0x10687e299*/
    goto LABEL_10; /*0x10687e299*/
  RBX::ProtectedString::ProtectedString(this: (RBX::ProtectedString *)v23, a2: (const RBX::ProtectedString *)(v6 + 32)); /*0x10687e2a9*/
  RBX::ProtectedString::ProtectedString(a1: &v25, a2: v23); /*0x10687e2b6*/
  v27 = 1; /*0x10687e2bb*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v24); /*0x10687e2c3*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v23); /*0x10687e2cc*/
  if ( (v27 & 1) != 0 ) /*0x10687e2d5*/
    goto LABEL_11; /*0x10687e2d5*/
LABEL_12:
  if ( v27 == 1 ) /*0x10687e258*/
  {
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v26); /*0x10687e25e*/
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: &v25); /*0x10687e267*/
  }
  return RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v4, a2: v5); /*0x10687e273*/
}

// Address: 0x10687e322 | Name: __ZNK3RBX7Network6Server11askAddChildEPKNS_8InstanceE
bool __fastcall RBX::Network::Server::askAddChild(RBX::Network::Server *this, const RBX::Instance *a2)
{
  __int64 v2; // rbx
  __int64 v3; // rax

  if ( a2 == nullptr ) /*0x10687e325*/
    return false; /*0x10687e359*/
  v2 = *((_QWORD *)a2 + 3); /*0x10687e32d*/
  v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ServerReplicator>(a1: this); /*0x10687e331*/
  return *(unsigned __int16 *)(v2 + 440) - (unsigned int)*(unsigned __int16 *)(v3 + 440) <= *(unsigned __int16 *)(v3 + 442); /*0x10687e358*/
}

// Address: 0x10687e35c | Name: __ZN3RBX7Network6Server32OnReliabilityLayerDeadConnectionERKN6RakNet13SystemAddressE
void __fastcall RBX::Network::Server::OnReliabilityLayerDeadConnection(
        RBX::Network::Server *this,
        const RakNet::SystemAddress *a2)
{
  ; /*0x10687e35c*/
}

// Address: 0x10687e362 | Name: __ZThn176_N3RBX7Network6Server32OnReliabilityLayerDeadConnectionERKN6RakNet13SystemAddressE
void __fastcall `non-virtual thunk to'RBX::Network::Server::OnReliabilityLayerDeadConnection(
        RBX::Network::Server *this,
        const RakNet::SystemAddress *a2)
{
  ; /*0x10687e362*/
}

// Address: 0x10687e368 | Name: __ZN3RBX7Network6Server23onNewConnectionAcceptedENSt3__110unique_ptrINS_12RbxTransport10ConnectionENS2_14default_deleteIS5_EEEENS2_8optionalINS_8Security13EarlyAuthDataEEE
__int64 __fastcall RBX::Network::Server::onNewConnectionAccepted(__int64 a1, RBX::RunService **a2, __int128 *a3)
{
  RBX::RunService *v5; // rax
  RBX::RunService *v6; // rdi
  RBX::Network::ConnectionInfo *ConnectionInfo; // rax
  unsigned __int64 v8; // rdx
  unsigned __int64 v9; // rax
  __int64 v10; // rsi
  unsigned __int64 v11; // rdx
  unsigned __int64 v12; // rax
  unsigned __int64 v13; // r12
  unsigned __int64 v14; // r15
  const char *v15; // r13
  unsigned __int16 v16; // ax
  RBX::Time *v17; // rdi
  __int64 v18; // r15
  __int64 v19; // r12
  double v20; // xmm0_8
  int v21; // r15d
  int v22; // r12d
  int v23; // eax
  int v24; // r8d
  int v25; // r9d
  int v26; // r15d
  int v27; // r12d
  int v28; // eax
  int v29; // r8d
  int v30; // r9d
  int v31; // ecx
  std::__shared_weak_count *v32; // rax
  __int64 v33; // rdi
  RBX::NetworkBase::ConnectionInternal *v34; // rax
  __int128 v35; // xmm0
  RBX::NetworkBase::ConnectionInternal *v36; // rdi
  std::__shared_weak_count *v37; // r12
  std::__shared_weak_count *v38; // r12
  std::__shared_weak_count *v39; // r12
  std::__shared_weak_count *v40; // r12
  std::__shared_weak_count *v41; // rbx
  std::__shared_weak_count *v42; // rbx
  RBX::NetworkBase::ConnectionInternal *v43; // rdi
  std::__shared_weak_count *v44; // rbx
  _QWORD v46[4]; // [rsp+10h] [rbp-230h] BYREF
  __int128 v47; // [rsp+30h] [rbp-210h]
  void *v48; // [rsp+40h] [rbp-200h]
  __int128 v49; // [rsp+48h] [rbp-1F8h]
  void *v50; // [rsp+58h] [rbp-1E8h]
  char v51; // [rsp+60h] [rbp-1E0h]
  _QWORD v52[4]; // [rsp+70h] [rbp-1D0h] BYREF
  int v53; // [rsp+90h] [rbp-1B0h]
  std::__shared_weak_count *v54[2]; // [rsp+98h] [rbp-1A8h]
  std::__shared_weak_count *v55; // [rsp+A8h] [rbp-198h]
  _QWORD v56[4]; // [rsp+B0h] [rbp-190h] BYREF
  __int128 v57; // [rsp+D0h] [rbp-170h]
  __int128 v58; // [rsp+E0h] [rbp-160h]
  __int128 v59; // [rsp+F0h] [rbp-150h] BYREF
  void *v60[2]; // [rsp+100h] [rbp-140h]
  int v61; // [rsp+110h] [rbp-130h]
  std::__shared_weak_count *v62[2]; // [rsp+118h] [rbp-128h]
  std::__shared_weak_count *v63; // [rsp+128h] [rbp-118h]
  __int64 v64; // [rsp+130h] [rbp-110h] BYREF
  unsigned __int64 v65; // [rsp+138h] [rbp-108h]
  std::__shared_weak_count *v66[2]; // [rsp+140h] [rbp-100h]
  RBX::RunService *v67; // [rsp+158h] [rbp-E8h]
  RBX::NetworkBase::ConnectionInternal *v68; // [rsp+160h] [rbp-E0h] BYREF
  RBX::NetworkBase::ConnectionInternal *v69; // [rsp+168h] [rbp-D8h] BYREF
  std::__shared_weak_count *v70[2]; // [rsp+170h] [rbp-D0h] BYREF
  void *v71[2]; // [rsp+180h] [rbp-C0h]
  _QWORD v72[6]; // [rsp+190h] [rbp-B0h]
  _QWORD v73[4]; // [rsp+1C0h] [rbp-80h] BYREF
  _QWORD v74[6]; // [rsp+1E0h] [rbp-60h] BYREF

  *(_OWORD *)v66 = 0; /*0x10687e393*/
  v5 = *a2; /*0x10687e39a*/
  *a2 = nullptr; /*0x10687e39d*/
  v67 = v5; /*0x10687e3ab*/
  ++*(_DWORD *)(a1 + 484); /*0x10687e3b7*/
  RBX::NetworkBase::ConnectionInternal::createRbxTransportConnectionServer(a1: &v69); /*0x10687e3c4*/
  v6 = v67; /*0x10687e3c9*/
  v67 = nullptr; /*0x10687e3d0*/
  if ( v6 != nullptr ) /*0x10687e3de*/
    (*(void (__fastcall **)(RBX::RunService *))(*(_QWORD *)v6 + 8LL))(a1: v6); /*0x10687e3e3*/
  if ( DFFlag::StudioAuthGate == 1 && (unsigned __int8)RBX::RunService::productIsStudio(this: v6) != 0 ) /*0x10687e3f6*/
    (*(void (__fastcall **)(RBX::NetworkBase::ConnectionInternal *, __int64))(*(_QWORD *)v69 + 64LL))(a1: v69, a2: 1); /*0x10687e407*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v46, a2: "77.77.77.77", a3: *((_WORD *)v69 + 704)); /*0x10687e426*/
  qmemcpy(v56, v46, sizeof(v56)); /*0x10687e439*/
  if ( FFlag::UseRealAddressForRbxTransportConnections == 1 && FFlag::ConnectViaConnectionInternal == 1 ) /*0x10687e461*/
  {
    ConnectionInfo = (RBX::Network::ConnectionInfo *)RBX::NetworkBase::ConnectionInternal::getConnectionInfo(this: v69); /*0x10687e46e*/
    v64 = RBX::Network::ConnectionInfo::toString(this: ConnectionInfo, a2: true); /*0x10687e487*/
    v65 = v8; /*0x10687e48a*/
    LOBYTE(v73[0]) = 124; /*0x10687e492*/
    v9 = RBX::detail::StringViewBase::find(a1: &v64, a2: v73, a3: 1, a4: 0); /*0x10687e49c*/
    if ( v9 == -1 ) /*0x10687e4a5*/
    {
      v10 = v64; /*0x10687e4d2*/
      v11 = v65; /*0x10687e4d9*/
      v14 = 0; /*0x10687e4e0*/
      v13 = 0; /*0x10687e4e3*/
    }
    else
    {
      v10 = v64; /*0x10687e4a7*/
      v11 = v9; /*0x10687e4b8*/
      if ( v65 < v9 ) /*0x10687e4bb*/
        v11 = v65; /*0x10687e4bb*/
      v12 = v9 + 1; /*0x10687e4bf*/
      if ( v65 < v12 ) /*0x10687e4c5*/
        v12 = v65; /*0x10687e4c5*/
      v13 = v64 + v12; /*0x10687e4c9*/
      v14 = v65 - v12; /*0x10687e4cd*/
    }
    if ( v10 != 0 ) /*0x10687e4e9*/
    {
      std::string::basic_string[abi:ne200100](a1: v70, a2: v10, a3: v11); /*0x10687e4f2*/
      if ( ((__int64)v70[0] & 1) != 0 ) /*0x10687e4fe*/
        v15 = (const char *)v71[0]; /*0x10687e522*/
      else
        v15 = (char *)v70 + 1; /*0x10687e500*/
    }
    else
    {
      v15 = (char *)v70 + 1; /*0x10687e50c*/
      *(_OWORD *)v70 = 0; /*0x10687e513*/
      v71[0] = nullptr; /*0x10687e518*/
    }
    if ( v13 != 0 ) /*0x10687e52c*/
    {
      std::string::basic_string[abi:ne200100](a1: &v59, a2: v13, a3: v14); /*0x10687e53b*/
    }
    else
    {
      v59 = 0; /*0x10687e545*/
      v60[0] = nullptr; /*0x10687e54c*/
    }
    v16 = std::stoi(a1: &v59, a2: 0, a3: 10); /*0x10687e565*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v73, a2: v15, a3: v16); /*0x10687e574*/
    RakNet::SystemAddress::operator=(a1: v56, a2: v73); /*0x10687e584*/
    if ( (v59 & 1) != 0 ) /*0x10687e590*/
      operator delete(a1: v60[0]); /*0x10687e599*/
    if ( ((__int64)v70[0] & 1) != 0 ) /*0x10687e5a5*/
      operator delete(a1: v71[0]); /*0x10687e5ae*/
  }
  v17 = (RBX::Time *)FLog::Network; /*0x10687e5ba*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x10687e5cc*/
    FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] NetworkServer:NewIncomingConnection", 0); /*0x10687e5e0*/
  v18 = *(_QWORD *)&DFLog::NetworkJoin; /*0x10687e5ec*/
  if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && BYTE1(DFLog::NetworkJoin) >= 3u ) /*0x10687e5ff*/
  {
    v19 = qword_10D7F3E08; /*0x10687e606*/
    RBX::Time::nowFastSec(this: v17); /*0x10687e60a*/
    *(float *)&v20 = v20; /*0x10687e60f*/
    FLog::FastLogF( /*0x10687e629*/
      a1: v18,
      a2: v19,
      a3: "[DFLog::NetworkJoin] Server::OnReceive new connection @ %f s",
      v20,
      0.0,
      0.0,
      0.0);
  }
  v21 = FLog::Output; /*0x10687e635*/
  if ( (unsigned __int8)FLog::Output >= 6u && BYTE1(FLog::Output) >= 3u ) /*0x10687e648*/
  {
    v22 = qword_10D7BE938; /*0x10687e64f*/
    v23 = RakNet::SystemAddress::ToString_deprecated(this: (RakNet::SystemAddress *)v56, a2: true, a3: 124); /*0x10687e664*/
    FLog::FastLogFormatted( /*0x10687e67b*/
      a1: v21,
      a2: v22,
      a3: (unsigned int)"[FLog::Output] New connection from %s",
      a4: v23,
      a5: v24,
      a6: v25);
  }
  v26 = DFLog::NetworkAudit; /*0x10687e687*/
  if ( (unsigned __int8)DFLog::NetworkAudit >= 6u && BYTE1(DFLog::NetworkAudit) >= 3u )
  {
    v27 = qword_10D783528; /*0x10687e6a1*/
    v28 = RakNet::SystemAddress::ToString_deprecated(this: (RakNet::SystemAddress *)v56, a2: true, a3: 124); /*0x10687e6b6*/
    FLog::FastLogFormatted(
      a1: v26,
      a2: v27,
      a3: (unsigned int)"[DFLog::NetworkAudit] RbxTransport Connect: New connection from %s",
      a4: v28,
      a5: v29,
      a6: v30);
  }
  LODWORD(v59) = -1; /*0x10687e6d9*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)((char *)&v59 + 4)); /*0x10687e6e4*/
  *(_OWORD *)v62 = 0; /*0x10687e6ec*/
  v31 = *((_DWORD *)v69 + 352); /*0x10687e6fa*/
  LODWORD(v59) = v31; /*0x10687e700*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x10687e718*/
    FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] assigning peer id = %d", v31); /*0x10687e72a*/
  RakNet::SystemAddress::operator=(a1: (char *)&v59 + 4, a2: v56); /*0x10687e739*/
  v32 = (std::__shared_weak_count *)(*(__int64 (__fastcall **)(RBX::NetworkBase::ConnectionInternal *))(*(_QWORD *)v69 + 56LL))(a1: v69); /*0x10687e748*/
  v63 = v32; /*0x10687e74b*/
  if ( (unsigned __int8)DFLog::RbxTransportIntegration >= 6u && BYTE1(DFLog::RbxTransportIntegration) >= 6u ) /*0x10687e76c*/
  {
    v70[0] = v32; /*0x10687e77f*/
    v73[0] = 4; /*0x10687e782*/
    v73[1] = v70; /*0x10687e78a*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x10687e7ae*/
      a1: DFLog::RbxTransportIntegration,
      a2: qword_10D7F15F8,
      a3: 6,
      a4: (unsigned int)"[DFLog::RbxTransportIntegration] Assigning capabilities {} to Replicator",
      a5: 72,
      a6: 1,
      4,
      v70);
  }
  (*(void (__fastcall **)(RBX::NetworkBase::ConnectionInternal *))(*(_QWORD *)v69 + 120LL))(a1: v69); /*0x10687e7bd*/
  LOBYTE(v73[0]) = 0; /*0x10687e7c2*/
  LOBYTE(v74[4]) = 0; /*0x10687e7c5*/
  if ( DFFlag::RbxTransportSessionCrypto == 1 ) /*0x10687e7d4*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count **))(*(_QWORD *)v69 + 184LL))(a1: v70); /*0x10687e7e7*/
    qmemcpy(v74, v72, 33); /*0x10687e7f3*/
    *(_OWORD *)&v73[2] = *(_OWORD *)v71; /*0x10687e81a*/
    *(_OWORD *)v73 = *(_OWORD *)v70; /*0x10687e81e*/
  }
  *(_OWORD *)v52 = v59; /*0x10687e830*/
  *(_OWORD *)&v52[2] = *(_OWORD *)v60; /*0x10687e837*/
  v53 = v61; /*0x10687e844*/
  *(_OWORD *)v54 = *(_OWORD *)v62; /*0x10687e858*/
  if ( v62[1] != nullptr ) /*0x10687e862*/
    _InterlockedIncrement64((volatile signed __int64 *)v62[1] + 1); /*0x10687e864*/
  v55 = v63; /*0x10687e877*/
  v34 = v69; /*0x10687e87c*/
  v69 = nullptr; /*0x10687e883*/
  v68 = v34; /*0x10687e88e*/
  v64 = a1; /*0x10687e895*/
  if ( qword_10D80FB70 == 0 ) /*0x10687e8a6*/
    std::__throw_bad_function_call[abi:ne200100](a1: v33); /*0x10687ebb2*/
  (*(void (__fastcall **)(std::__shared_weak_count **, __int64, _QWORD *, __int64 *, RBX::NetworkBase::ConnectionInternal **))(*(_QWORD *)qword_10D80FB70 + 48LL))( /*0x10687e8cb*/
    a1: v70,
    a2: qword_10D80FB70,
    a3: v52,
    a4: &v64,
    a5: &v68);
  v35 = *(_OWORD *)v70; /*0x10687e8ce*/
  *(_OWORD *)v70 = 0; /*0x10687e8d8*/
  *(_OWORD *)v66 = v35; /*0x10687e8df*/
  v36 = v68; /*0x10687e8e6*/
  v68 = nullptr; /*0x10687e8ed*/
  if ( v36 != nullptr ) /*0x10687e8fb*/
    (*(void (__fastcall **)(RBX::NetworkBase::ConnectionInternal *))(*(_QWORD *)v36 + 8LL))(a1: v36); /*0x10687e900*/
  v37 = v54[1]; /*0x10687e903*/
  if ( v54[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v54[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10687e920*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v37 + 16LL))(a1: v37); /*0x10687e929*/
    std::__shared_weak_count::__release_weak(this: v37); /*0x10687e92f*/
  }
  if ( DFFlag::RbxTransportSessionCrypto == 1 && LOBYTE(v74[4]) == 1 ) /*0x10687e943*/
  {
    RBX::Security::QuicSessionCrypto::create(a1: v70, a2: v73, a3: v74, a4: 1); /*0x10687e95d*/
    v57 = *(_OWORD *)v70; /*0x10687e977*/
    *(_OWORD *)v70 = 0; /*0x10687e97d*/
    RBX::Network::Replicator::setSessionCrypto(a1: (__int64)v66[0]); /*0x10687e984*/
    v38 = *((std::__shared_weak_count **)&v57 + 1); /*0x10687e989*/
    if ( *((_QWORD *)&v57 + 1) != 0 /*0x10687e9a6*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v57 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v38 + 16LL))(a1: v38); /*0x10687e9af*/
      std::__shared_weak_count::__release_weak(this: v38); /*0x10687e9b5*/
    }
    v39 = v70[1]; /*0x10687e9ba*/
    if ( v70[1] != nullptr /*0x10687e9d7*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v70[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v39 + 16LL))(a1: v39); /*0x10687e9e0*/
      std::__shared_weak_count::__release_weak(this: v39); /*0x10687e9e6*/
    }
  }
  v40 = v66[0]; /*0x10687e9eb*/
  if ( *((_BYTE *)a3 + 56) == 1 ) /*0x10687e9f7*/
  {
    v48 = *((void **)a3 + 2); /*0x10687ea04*/
    v47 = *a3; /*0x10687ea0c*/
    *a3 = 0; /*0x10687ea12*/
    *((_QWORD *)a3 + 2) = 0; /*0x10687ea18*/
    v50 = *((void **)a3 + 5); /*0x10687ea20*/
    v49 = *(__int128 *)((char *)a3 + 24); /*0x10687ea29*/
    *(__int128 *)((char *)a3 + 24) = 0; /*0x10687ea2d*/
    *((_QWORD *)a3 + 5) = 0; /*0x10687ea32*/
    v51 = *((_BYTE *)a3 + 48); /*0x10687ea3a*/
    std::optional<RBX::Security::EarlyAuthData>::operator=[abi:ne200100]<RBX::Security::EarlyAuthData,void>(a1: (char *)v40 + 22904); /*0x10687ea45*/
    if ( (v49 & 1) != 0 ) /*0x10687ea51*/
      operator delete(a1: v50); /*0x10687ea5a*/
    if ( (v47 & 1) != 0 ) /*0x10687ea66*/
      operator delete(a1: v48); /*0x10687ea6f*/
  }
  if ( FFlag::SeparateRakNetAndRbxTransportRouting == 0 ) /*0x10687ea7b*/
  {
    v70[0] = (std::__shared_weak_count *)((char *)&v59 + 4); /*0x10687ea8b*/
    *(_QWORD *)(std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::__emplace_unique_key_args<RakNet::SystemAddress,std::piecewise_construct_t const&,std::tuple<RakNet::SystemAddress const&>,std::tuple<>>( /*0x10687eaa4*/
                  a1: a1 + 4648,
                  a2: (char *)&v59 + 4,
                  a3: std::piecewise_construct,
                  a4: v70,
                  a5: &v64)
              + 48) = v40;
  }
  if ( *((_BYTE *)v40 + 18600) == 1 ) /*0x10687eab1*/
    RBX::Network::ServerReplicator::updateConnectionAcceptedTime(this: v40); /*0x10687eab6*/
  v58 = 0; /*0x10687eac5*/
  RBX::Instance::setAndLockParent(this: v40); /*0x10687ead0*/
  v41 = *((std::__shared_weak_count **)&v58 + 1); /*0x10687ead5*/
  if ( *((_QWORD *)&v58 + 1) != 0 /*0x10687eaf1*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v58 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v41 + 16LL))(a1: v41); /*0x10687eaf9*/
    std::__shared_weak_count::__release_weak(this: v41); /*0x10687eaff*/
  }
  RBX::Network::ServerReplicator::sendSFFlags(this: v66[0]); /*0x10687eb0b*/
  v42 = v62[1]; /*0x10687eb10*/
  if ( v62[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v62[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10687eb2c*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v42 + 16LL))(a1: v42); /*0x10687eb34*/
    std::__shared_weak_count::__release_weak(this: v42); /*0x10687eb3a*/
  }
  v43 = v69; /*0x10687eb3f*/
  v69 = nullptr; /*0x10687eb46*/
  if ( v43 != nullptr ) /*0x10687eb54*/
    (*(void (__fastcall **)(RBX::NetworkBase::ConnectionInternal *))(*(_QWORD *)v43 + 8LL))(a1: v43); /*0x10687eb59*/
  v44 = v66[1]; /*0x10687eb5c*/
  if ( v66[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v66[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10687eb78*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v44 + 16LL))(a1: v44); /*0x10687eb80*/
    std::__shared_weak_count::__release_weak(this: v44); /*0x10687eb86*/
  }
  return __stack_chk_guard; /*0x10687eb9b*/
}

// Address: 0x10687ede4 | Name: __ZN3RBX7Network6Server26getAndHandleListenerEventsEv
__int64 __fastcall RBX::Network::Server::getAndHandleListenerEvents(RBX::Network::Server *this)
{
  RBX::Network::Server *v1; // rbx
  const RBX::Instance *v2; // rsi
  __int64 v3; // rax
  __int64 v4; // rcx
  __int64 v5; // rdx
  __int64 v6; // rdi
  __int64 v7; // r15
  __int64 v8; // rdi
  unsigned __int64 v9; // r8
  unsigned __int64 v10; // rtt
  RBX::RunService *v11; // r15
  char v12; // r14
  char v13; // bl
  __int64 v14; // r15
  RBX::RunService *v15; // rdi
  __int128 v17[3]; // [rsp+10h] [rbp-1B0h] BYREF
  char v18; // [rsp+48h] [rbp-178h]
  _BYTE v19[48]; // [rsp+50h] [rbp-170h] BYREF
  _QWORD v20[3]; // [rsp+80h] [rbp-140h] BYREF
  __int64 v21; // [rsp+98h] [rbp-128h]
  char *v22; // [rsp+A0h] [rbp-120h]
  __int64 v23; // [rsp+A8h] [rbp-118h]
  _QWORD *v24; // [rsp+B0h] [rbp-110h]
  __int64 v25; // [rsp+B8h] [rbp-108h]
  RBX::Network::Server *v26; // [rsp+C0h] [rbp-100h]
  __int64 v27; // [rsp+C8h] [rbp-F8h] BYREF
  RBX::RunService *v28; // [rsp+D0h] [rbp-F0h] BYREF
  RBX::RunService *v29; // [rsp+D8h] [rbp-E8h] BYREF
  _BYTE v30[8]; // [rsp+E0h] [rbp-E0h] BYREF
  __int64 v31; // [rsp+E8h] [rbp-D8h]
  unsigned __int64 v32; // [rsp+100h] [rbp-C0h]
  __int64 v33; // [rsp+108h] [rbp-B8h]
  unsigned __int8 v34; // [rsp+130h] [rbp-90h]
  char v35; // [rsp+138h] [rbp-88h]
  unsigned __int8 v36; // [rsp+180h] [rbp-40h]
  char v37; // [rsp+188h] [rbp-38h]

  v1 = this; /*0x10687edf8*/
  (*(void (__fastcall **)(_BYTE *))(**((_QWORD **)this + 639) + 80LL))(a1: v19); /*0x10687ee1a*/
  while ( 1 ) /*0x10687ee43*/
  {
    RBX::RbxTransport::EventsQueue<RBX::RbxTransport::Listener::ListenerEvent>::getNextEvent(a1: v30, a2: v19); /*0x10687ee43*/
    if ( v35 == 0 ) /*0x10687ee4f*/
      break; /*0x10687ee4f*/
    if ( (unsigned __int8)DFLog::RbxTransportIntegration >= 6u && BYTE1(DFLog::RbxTransportIntegration) >= 6u ) /*0x10687ee6d*/
    {
      v20[0] = v34; /*0x10687ee86*/
      v23 = 3; /*0x10687ee8d*/
      v24 = v20; /*0x10687ee9f*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x10687eec9*/
        a1: DFLog::RbxTransportIntegration,
        a2: qword_10D7F15F8,
        a3: 6,
        a4: (unsigned int)"[DFLog::RbxTransportIntegration] Processing RbxTransport Listener event of type {}",
        a5: 82,
        a6: 1,
        3,
        v20);
    }
    switch ( v34 ) /*0x10687eeed*/
    {
      case 0u: /*0x10687eeed*/
        if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x10687ef07*/
          FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] Listener opened!", 0); /*0x10687ef26*/
        break; /*0x10687ef2b*/
      case 1u: /*0x10687eeed*/
        if ( (unsigned __int8)DFLog::RbxTransportIntegration >= 6u && BYTE1(DFLog::RbxTransportIntegration) >= 6u ) /*0x10687efbc*/
        {
          v23 = 0; /*0x10687efce*/
          v24 = v20; /*0x10687efe0*/
          FLog::detail::FastLogSafeFormattedInternal( /*0x10687f00a*/
            a1: DFLog::RbxTransportIntegration,
            a2: qword_10D7F15F8,
            a3: 6,
            a4: (unsigned int)"[DFLog::RbxTransportIntegration] New RbxTransport connection accepted!",
            a5: 70,
            a6: 1,
            0,
            v20);
        }
        while ( v33 != 0 ) /*0x10687f017*/
        {
          v3 = *(_QWORD *)(v31 + 8 * (v32 >> 9)); /*0x10687f032*/
          v4 = v32 & 0x1FF; /*0x10687f036*/
          v5 = *(_QWORD *)(v3 + 8 * v4); /*0x10687f03c*/
          *(_QWORD *)(v3 + 8 * v4) = 0; /*0x10687f040*/
          v27 = v5; /*0x10687f048*/
          RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::RbxTransport::Connection>>::push_back<std::move_iterator<std::unique_ptr<RBX::RbxTransport::Connection>*>>( /*0x10687f058*/
            a1: (char *)v1 + 5312,
            a2: &v27,
            a3: &v28);
          v6 = v27; /*0x10687f05d*/
          v27 = 0; /*0x10687f064*/
          if ( v6 != 0 ) /*0x10687f072*/
            (*(void (__fastcall **)(__int64))(*(_QWORD *)v6 + 8LL))(a1: v6); /*0x10687f077*/
          std::deque<std::unique_ptr<RBX::RbxTransport::Connection>>::pop_front(a1: v30); /*0x10687f07d*/
        }
        break; /*0x10687f082*/
      case 2u: /*0x10687eeed*/
        if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x10687ef45*/
          FLog::FastLog( /*0x10687ef60*/
            a1: FLog::Network,
            a2: qword_10D7BBAA8,
            a3: "[FLog::Network] Listener closed! Server shutting down",
            0);
        RBX::Network::Server::stop(this: (RBX::Network::ConcurrentRakPeer **)v1, a2: v2); /*0x10687ef68*/
        break; /*0x10687ef6d*/
      case 3u: /*0x10687eeed*/
        if ( (unsigned __int8)RBX::UnexpectedEvents::UnexpectedEvent::canReport(this: (RBX::UnexpectedEvents::UnexpectedEvent *)&RBX::UnexpectedEvents::server_unexpected_rbxtransport_event) != 0 ) /*0x10687ef7d*/
          RBX::UnexpectedEvents::UnexpectedEvent::report( /*0x10687ef92*/
            a1: &RBX::UnexpectedEvents::server_unexpected_rbxtransport_event,
            a2: "Received RbxTransport::ConnectionEventType::NumConnectionEventTypes",
            a3: 67);
        break; /*0x10687ef92*/
      default:
        break;
    }
    std::__optional_destruct_base<RBX::RbxTransport::Listener::ListenerEvent,false>::~__optional_destruct_base[abi:ne200100](a1: v30); /*0x10687ef97*/
  }
  std::__optional_destruct_base<RBX::RbxTransport::Listener::ListenerEvent,false>::~__optional_destruct_base[abi:ne200100](a1: v30); /*0x10687f08b*/
  std::deque<RBX::RbxTransport::Listener::ListenerEvent>::~deque[abi:ne200100](a1: v19); /*0x10687f097*/
  v21 = *((_QWORD *)v1 + 667); /*0x10687f0a3*/
  if ( v21 != 0 ) /*0x10687f0ad*/
  {
    v7 = 0; /*0x10687f0c1*/
    v26 = v1; /*0x10687f0c4*/
    v22 = (char *)v1 + 5312; /*0x10687f0cb*/
    do /*0x10687f247*/
    {
      v25 = v7; /*0x10687f0d2*/
      v8 = *((_QWORD *)v1 + 664); /*0x10687f0e0*/
      v9 = *((_QWORD *)v1 + 665); /*0x10687f0e7*/
      v10 = *((_QWORD *)v1 + 666); /*0x10687f0f3*/
      *((_QWORD *)v1 + 666) = (v10 + 1) % v9; /*0x10687f104*/
      v11 = *(RBX::RunService **)(v8 + 8 * (v10 % v9)); /*0x10687f10b*/
      *(_QWORD *)(v8 + 8 * (v10 % v9)) = 0; /*0x10687f10f*/
      --*((_QWORD *)v1 + 667); /*0x10687f117*/
      (*(void (__fastcall **)(_BYTE *, RBX::RunService *))(*(_QWORD *)v11 + 24LL))(a1: v19, a2: v11); /*0x10687f127*/
      v12 = 0; /*0x10687f12a*/
      v13 = 0; /*0x10687f12d*/
      while ( 1 ) /*0x10687f135*/
      {
        RBX::RbxTransport::EventsQueue<RBX::RbxTransport::ConnectionEvent>::getNextEvent(a1: v30, a2: v19); /*0x10687f135*/
        if ( v37 == 0 ) /*0x10687f13e*/
          break; /*0x10687f13e*/
        if ( (unsigned int)v36 - 5 >= 4 ) /*0x10687f14a*/
        {
          if ( v36 == 0 ) /*0x10687f152*/
            v12 = 1; /*0x10687f154*/
        }
        else
        {
          v13 = 1; /*0x10687f14c*/
        }
        std::__optional_destruct_base<RBX::RbxTransport::ConnectionEvent,false>::~__optional_destruct_base[abi:ne200100](a1: v30); /*0x10687f15a*/
      }
      std::__optional_destruct_base<RBX::RbxTransport::ConnectionEvent,false>::~__optional_destruct_base[abi:ne200100](a1: v30); /*0x10687f164*/
      if ( (v13 & 1) != 0 ) /*0x10687f16c*/
      {
        std::deque<RBX::RbxTransport::ConnectionEvent>::~deque[abi:ne200100](a1: v19); /*0x10687f171*/
        (*(void (__fastcall **)(RBX::RunService *))(*(_QWORD *)v11 + 8LL))(a1: v11); /*0x10687f17c*/
        v1 = v26; /*0x10687f17f*/
        v14 = v25; /*0x10687f186*/
      }
      else
      {
        if ( (v12 & 1) != 0 ) /*0x10687f196*/
        {
          v29 = v11; /*0x10687f198*/
          LOBYTE(v17[0]) = 0; /*0x10687f1a1*/
          v18 = 0; /*0x10687f1a7*/
          v1 = v26; /*0x10687f1ad*/
          RBX::Network::Server::onNewConnectionAccepted(a1: (__int64)v26, a2: &v29, a3: v17); /*0x10687f1c8*/
          std::__optional_destruct_base<RBX::Security::EarlyAuthData,false>::~__optional_destruct_base[abi:ne200100](a1: v17); /*0x10687f1d0*/
          v15 = v29; /*0x10687f1d5*/
          v29 = nullptr; /*0x10687f1dc*/
        }
        else
        {
          v28 = v11; /*0x10687f1e9*/
          RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::RbxTransport::Connection>>::push_back<std::move_iterator<std::unique_ptr<RBX::RbxTransport::Connection>*>>( /*0x10687f205*/
            a1: v22,
            a2: &v28,
            a3: &v29);
          v1 = v26; /*0x10687f20a*/
          v15 = v28; /*0x10687f211*/
          v28 = nullptr; /*0x10687f218*/
        }
        v14 = v25; /*0x10687f226*/
        if ( v15 != nullptr ) /*0x10687f22d*/
          (*(void (__fastcall **)(RBX::RunService *))(*(_QWORD *)v15 + 8LL))(a1: v15); /*0x10687f232*/
        std::deque<RBX::RbxTransport::ConnectionEvent>::~deque[abi:ne200100](a1: v19); /*0x10687f238*/
      }
      v7 = v14 + 1; /*0x10687f23d*/
    }
    while ( v7 != v21 ); /*0x10687f247*/
  }
  return __stack_chk_guard; /*0x10687f25d*/
}

// Address: 0x10687f4b4 | Name: __ZN3RBX7Network6Server13doReceiveLoopEv
__int64 __fastcall RBX::Network::Server::doReceiveLoop(RBX::Network::Server *this)
{
  RBX::Network::ServerReplicator **v2; // r15
  RBX::Network::ServerReplicator *v3; // r14
  RBX::Time *v4; // rdi
  __int64 v5; // xmm0_8
  __int64 v6; // rbx
  __int64 v7; // r13
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // r8
  __int64 v11; // r9
  _QWORD v13[3]; // [rsp+0h] [rbp-1F0h] BYREF
  RBX::Network::ServerReplicator **v14; // [rsp+18h] [rbp-1D8h]
  void *v15[3]; // [rsp+20h] [rbp-1D0h] BYREF
  __int64 v16; // [rsp+38h] [rbp-1B8h]
  _QWORD v17[5]; // [rsp+40h] [rbp-1B0h] BYREF
  _BYTE v18[8]; // [rsp+68h] [rbp-188h] BYREF
  _BYTE v19[96]; // [rsp+70h] [rbp-180h] BYREF
  _BYTE v20[8]; // [rsp+D0h] [rbp-120h] BYREF
  _QWORD v21[11]; // [rsp+D8h] [rbp-118h] BYREF
  _QWORD v22[5]; // [rsp+130h] [rbp-C0h] BYREF
  _BYTE v23[8]; // [rsp+158h] [rbp-98h] BYREF
  _BYTE v24[96]; // [rsp+160h] [rbp-90h] BYREF

  if ( *((_QWORD *)this + 639) != 0 ) /*0x10687f4de*/
  {
    RBX::Network::Server::getAndHandleListenerEvents(this); /*0x10687f4e7*/
    memset(v15, 0, sizeof(v15)); /*0x10687f4f6*/
    std::vector<RBX::Network::Replicator *>::__init_with_size[abi:ne200100]<RBX::Network::Replicator **,RBX::Network::Replicator **>( /*0x10687f519*/
      a1: v15,
      a2: *((_QWORD *)this + 353),
      a3: *((_QWORD *)this + 354),
      a4: (__int64)(*((_QWORD *)this + 354) - *((_QWORD *)this + 353)) >> 3);
    v2 = (RBX::Network::ServerReplicator **)v15[0]; /*0x10687f51e*/
    v14 = (RBX::Network::ServerReplicator **)v15[1]; /*0x10687f52c*/
    if ( v15[0] != v15[1] ) /*0x10687f536*/
    {
      do /*0x10687f689*/
      {
        v3 = *v2; /*0x10687f543*/
        if ( *((_QWORD *)*v2 + 35) != 0 ) /*0x10687f54e*/
        {
          RBX::Network::ServerReplicator::getAndHandleConnectionEvents(this: *v2); /*0x10687f557*/
          (*(void (__fastcall **)(_QWORD *))(**((_QWORD **)v3 + 35) + 160LL))(a1: v13); /*0x10687f56d*/
          v16 = 0; /*0x10687f576*/
          if ( DFFlag::RbxTransportNetworkTracing == 1 ) /*0x10687f588*/
          {
            RBX::Time::nowFast(this: v4); /*0x10687f58a*/
            v16 = v5; /*0x10687f58f*/
          }
          v6 = v13[0]; /*0x10687f597*/
          v7 = v13[1]; /*0x10687f59e*/
          while ( v6 != v7 ) /*0x10687f5a8*/
          {
            RBX::RbxTransport::NetStream::NetStream(a1: v20, a2: v6); /*0x10687f5b4*/
            RBX::Network::IncomingPacket::IncomingPacket(a1: v22, a2: v20); /*0x10687f5c3*/
            RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v21); /*0x10687f5cf*/
            v22[4] = v16; /*0x10687f5dc*/
            qmemcpy(v17, v22, sizeof(v17)); /*0x10687f5f2*/
            std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x10687f61c*/
              a1: v18,
              a2: v23,
              a3: v8,
              a4: v9,
              a5: v10,
              a6: v11);
            (*(void (__fastcall **)(RBX::Network::ServerReplicator *, _QWORD *))(*(_QWORD *)v3 + 712LL))( /*0x10687f62e*/
              a1: v3,
              a2: v17);
            if ( v19[88] == 1 ) /*0x10687f63b*/
              RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v19); /*0x10687f644*/
            if ( v24[88] == 1 ) /*0x10687f64d*/
              RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v24); /*0x10687f656*/
            v6 += 96; /*0x10687f65b*/
          }
          v22[0] = v13; /*0x10687f66b*/
          std::vector<RBX::RbxTransport::NetStream>::__destroy_vector::operator()[abi:ne200100](a1: v22); /*0x10687f679*/
        }
        ++v2; /*0x10687f67e*/
      }
      while ( v2 != v14 ); /*0x10687f689*/
      v2 = (RBX::Network::ServerReplicator **)v15[0]; /*0x10687f68f*/
    }
    if ( v2 != nullptr ) /*0x10687f699*/
    {
      v15[1] = v2; /*0x10687f69b*/
      operator delete(a1: v2); /*0x10687f6a5*/
    }
  }
  return __stack_chk_guard; /*0x10687f6ba*/
}

// Address: 0x10687f756 | Name: __ZN3RBX7Network6Server37getRbxTransportListenConnectionConfigEv
RBX::Network::Server *__fastcall RBX::Network::Server::getRbxTransportListenConnectionConfig(
        RBX::Network::Server *this,
        __int64 a2)
{
  RSL::Mutex *v4; // r14
  __int64 v5; // rax

  v4 = (RSL::Mutex *)(a2 + 4968); /*0x10687f766*/
  RSL::Mutex::lock(this: (RSL::Mutex *)(a2 + 4968)); /*0x10687f770*/
  v5 = *(_QWORD *)(a2 + 4984); /*0x10687f775*/
  *(_OWORD *)this = *(_OWORD *)(a2 + 4976); /*0x10687f784*/
  if ( v5 != 0 ) /*0x10687f78a*/
    _InterlockedIncrement64((volatile signed __int64 *)(v5 + 8)); /*0x10687f78c*/
  RSL::Mutex::unlock(this: v4); /*0x10687f794*/
  return this; /*0x10687f7a0*/
}

// Address: 0x10687f7b0 | Name: __ZN3RBX7Network6Server35getRbxTransportListenerCapabilitiesEv
RBX::Network::Server *__fastcall RBX::Network::Server::getRbxTransportListenerCapabilities(
        RBX::Network::Server *this,
        __int64 a2)
{
  RSL::Mutex *v4; // r14

  v4 = (RSL::Mutex *)(a2 + 4968); /*0x10687f7c0*/
  RSL::Mutex::lock(this: (RSL::Mutex *)(a2 + 4968)); /*0x10687f7ca*/
  *(_BYTE *)this = 0; /*0x10687f7d1*/
  *((_BYTE *)this + 8) = 0; /*0x10687f7d3*/
  if ( *(_BYTE *)(a2 + 5000) == 1 ) /*0x10687f7de*/
  {
    *(_QWORD *)this = 0; /*0x10687f7e0*/
    _InterlockedExchange64((volatile __int64 *)this, *(_QWORD *)(a2 + 4992)); /*0x10687f7ee*/
    *((_BYTE *)this + 8) = 1; /*0x10687f7f1*/
  }
  RSL::Mutex::unlock(this: v4); /*0x10687f7f8*/
  return this; /*0x10687f804*/
}

// Address: 0x10687f814 | Name: __ZN3RBX7Network6Server17readEarlyAuthDataERNS0_13NetworkStreamE
RBX::Network::Server *__fastcall RBX::Network::Server::readEarlyAuthData(
        RBX::Network::Server *this,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3)
{
  unsigned __int8 v6; // al
  unsigned int v7; // ebx
  char *v8; // rsi
  __int64 v9; // rbx
  char *v10; // rsi
  void *v11; // rcx
  char *v12; // rsi
  void *v13; // rcx
  __int128 v14; // xmm0
  unsigned int v15; // edx
  char *v16; // rsi
  __int64 v17; // rdx
  __int64 v18; // rax
  __int64 v19; // rdx
  void *v20; // rcx
  char *v21; // rsi
  __int64 v22; // rdx
  __int64 v23; // r13
  char *v24; // rbx
  unsigned int v25; // r12d
  void *v26; // r15
  char *v27; // r14
  char *v28; // rcx
  void *v29; // r8
  unsigned __int64 v30; // rax
  char v31; // al
  char v32; // bl
  char *v33; // r15
  __int64 v34; // rax
  int v35; // edx
  _BYTE v37[16]; // [rsp+8h] [rbp-F8h] BYREF
  void *v38; // [rsp+18h] [rbp-E8h]
  __int64 v39; // [rsp+20h] [rbp-E0h]
  RBX::Network::NetworkStream *v40; // [rsp+28h] [rbp-D8h]
  __int128 v41; // [rsp+30h] [rbp-D0h] BYREF
  void *v42; // [rsp+40h] [rbp-C0h]
  __int128 v43; // [rsp+50h] [rbp-B0h] BYREF
  void *v44; // [rsp+60h] [rbp-A0h]
  void *v45[6]; // [rsp+70h] [rbp-90h] BYREF
  char Byte; // [rsp+A0h] [rbp-60h]
  __int128 v47; // [rsp+B0h] [rbp-50h] BYREF
  void *v48; // [rsp+C0h] [rbp-40h]
  RBX::Network::Server *v49; // [rsp+D0h] [rbp-30h]

  RBX::Network::NetworkStream::IgnoreBytes(this: a3, a2: 1u); /*0x10687f839*/
  memset(v45, 0, sizeof(v45)); /*0x10687f849*/
  Byte = RBX::Network::NetworkStream::readByte(this: a3); /*0x10687f85c*/
  v6 = RBX::Network::NetworkStream::readByte(this: a3); /*0x10687f862*/
  v7 = v6; /*0x10687f867*/
  std::string::resize(a1: v45, a2: v6, a3: 0); /*0x10687f876*/
  v8 = (char *)v45 + 1; /*0x10687f87b*/
  if ( ((__int64)v45[0] & 1) != 0 ) /*0x10687f886*/
    v8 = (char *)v45[2]; /*0x10687f888*/
  RBX::Network::NetworkStream::readBytes(this: a3, a2: v8, a3: v7); /*0x10687f891*/
  v9 = (unsigned __int8)RBX::Network::NetworkStream::readByte(this: a3); /*0x10687f8a2*/
  std::string::resize(a1: &v45[3], a2: v9, a3: 0); /*0x10687f8ad*/
  if ( ((__int64)v45[3] & 1) != 0 ) /*0x10687f8b6*/
    v10 = (char *)v45[5]; /*0x10687f8b8*/
  else
    v10 = (char *)&v45[3] + 1; /*0x10687f8be*/
  RBX::Network::NetworkStream::readBytes(this: a3, a2: v10, a3: v9); /*0x10687f8c7*/
  if ( DFFlag::ForceNewPaBlob2 != 0
    || (((__int64)v45[0] & 1) == 0 ? (v11 = (void *)(LOBYTE(v45[0]) >> 1)) : (v11 = v45[1]), v11 != (void *)32) )
  {
    if ( ((__int64)v45[0] & 1) != 0 ) /*0x10687f8f8*/
    {
      v13 = v45[1]; /*0x10687f917*/
      if ( v45[1] == (void *)33 ) /*0x10687f922*/
      {
        v14 = 0; /*0x10687f924*/
        v47 = 0; /*0x10687f927*/
        v48 = nullptr; /*0x10687f92b*/
        goto LABEL_19; /*0x10687f933*/
      }
    }
    else
    {
      if ( LOBYTE(v45[0]) == 66 ) /*0x10687f8fd*/
      {
        v47 = 0; /*0x10687f902*/
        v48 = nullptr; /*0x10687f906*/
        v12 = (char *)v45 + 1; /*0x10687f90e*/
LABEL_20:
        std::string::basic_string[abi:ne200100](a1: &v41, a2: v12, a3: 16); /*0x10687f96a*/
        goto LABEL_21; /*0x10687f976*/
      }
      v13 = (void *)(LOBYTE(v45[0]) >> 1); /*0x10687f937*/
    }
    if ( v13 != (void *)50 ) /*0x10687f93d*/
    {
      v32 = 0; /*0x10687fc60*/
      *(_BYTE *)this = 0; /*0x10687fc62*/
      *((_BYTE *)this + 56) = 0; /*0x10687fc65*/
      goto LABEL_56; /*0x10687fc65*/
    }
  }
  v14 = 0; /*0x10687f943*/
  v47 = 0; /*0x10687f946*/
  v48 = nullptr; /*0x10687f94a*/
  v12 = (char *)v45 + 1; /*0x10687f952*/
  if ( ((__int64)v45[0] & 1) == 0 ) /*0x10687f95b*/
    goto LABEL_20; /*0x10687f95b*/
LABEL_19:
  v12 = (char *)v45[2]; /*0x10687f95d*/
  if ( v45[2] != nullptr ) /*0x10687f964*/
    goto LABEL_20; /*0x10687f964*/
  v41 = v14; /*0x10687fcac*/
  v42 = nullptr; /*0x10687fcb3*/
LABEL_21:
  v15 = *((unsigned __int8 *)a2 + 5160); /*0x10687f97b*/
  if ( (v15 & 1) != 0 ) /*0x10687f986*/
  {
    v16 = *((char **)a2 + 647); /*0x10687f988*/
    v17 = *((_QWORD *)a2 + 646); /*0x10687f98f*/
  }
  else
  {
    v16 = (char *)a2 + 5161; /*0x10687f998*/
    v17 = v15 >> 1; /*0x10687f99f*/
  }
  v18 = std::string::append(a1: &v41, a2: v16, a3: v17); /*0x10687f9a8*/
  v20 = *(void **)(v18 + 16); /*0x10687f9ad*/
  v44 = v20; /*0x10687f9b1*/
  v43 = *(_OWORD *)v18; /*0x10687f9bb*/
  *(_OWORD *)v18 = 0; /*0x10687f9c5*/
  *(_QWORD *)(v18 + 16) = 0; /*0x10687f9c8*/
  if ( (v41 & 1) != 0 ) /*0x10687f9d7*/
    operator delete(a1: v42); /*0x10687f9e0*/
  if ( FFlag::FixPreauthKeyRingJobIdDerivation == 1 ) /*0x10687f9ef*/
  {
    if ( (v43 & 1) != 0 ) /*0x10687f9fb*/
    {
      v21 = (char *)v44; /*0x10687fa01*/
      v22 = *((_QWORD *)&v43 + 1); /*0x10687fa08*/
    }
    else
    {
      v22 = (unsigned __int8)v43 >> 1; /*0x10687fafa*/
      v21 = (char *)&v43 + 1; /*0x10687fafc*/
    }
    if ( ((__int64)v45[0] & 1) != 0 ) /*0x10687fb16*/
    {
      v28 = (char *)v45[2]; /*0x10687fb18*/
      v29 = v45[1]; /*0x10687fb1c*/
    }
    else
    {
      v29 = (void *)(LOBYTE(v45[0]) >> 1); /*0x10687fb25*/
      v28 = (char *)v45 + 1; /*0x10687fb28*/
    }
    RBX::Security::SessionCrypto::verifyPreauthMac(a1: &v41, a2: v21, a3: v22, a4: v28, a5: v29, a6: (char *)a2 + 5160); /*0x10687fb36*/
    v48 = v42; /*0x10687fb42*/
    v47 = v41; /*0x10687fb4d*/
  }
  else
  {
    v40 = a2; /*0x10687fa14*/
    v49 = this; /*0x10687fa1b*/
    v39 = (unsigned __int8)v43; /*0x10687fa26*/
    v23 = *((_QWORD *)&v43 + 1); /*0x10687fa2d*/
    v24 = (char *)v44; /*0x10687fa34*/
    v25 = LOBYTE(v45[0]); /*0x10687fa3b*/
    v26 = v45[1]; /*0x10687fa43*/
    v27 = (char *)v45[2]; /*0x10687fa4a*/
    std::string::basic_string[abi:ne200100]<0>(a1: v37, a2: "", a3: v19, a4: v20); /*0x10687fa5c*/
    if ( (v25 & 1) == 0 ) /*0x10687fa6a*/
    {
      v26 = (void *)(v25 >> 1); /*0x10687fa6a*/
      v27 = (char *)v45 + 1; /*0x10687fa75*/
    }
    if ( (v39 & 1) == 0 ) /*0x10687fa87*/
    {
      v23 = (unsigned int)v39 >> 1; /*0x10687fa87*/
      v24 = (char *)&v43 + 1; /*0x10687fa92*/
    }
    RBX::Security::SessionCrypto::verifyPreauthMac(a1: &v41, a2: v24, a3: v23, a4: v27, a5: v26, a6: v37); /*0x10687fab0*/
    v47 = v41; /*0x10687fabc*/
    v48 = v42; /*0x10687fac7*/
    LOWORD(v41) = 0; /*0x10687facb*/
    this = v49; /*0x10687fadb*/
    a2 = v40; /*0x10687fadf*/
    if ( (v37[0] & 1) != 0 ) /*0x10687faea*/
      operator delete(a1: v38); /*0x10687faf3*/
  }
  if ( (v47 & 1) == 0 ) /*0x10687fb57*/
  {
    if ( (_BYTE)v47 != 0 ) /*0x10687fb5c*/
    {
      v30 = (unsigned __int8)v47 >> 1; /*0x10687fb5e*/
      goto LABEL_44; /*0x10687fb60*/
    }
LABEL_45:
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x10687fb8a*/
      FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] Verifying EarlyAuthData failed", 0); /*0x10687fb9e*/
    *(_BYTE *)this = 0; /*0x10687fba3*/
    v31 = 0; /*0x10687fba7*/
    goto LABEL_48; /*0x10687fba7*/
  }
  v30 = *((_QWORD *)&v47 + 1); /*0x10687fb62*/
  if ( *((_QWORD *)&v47 + 1) == 0 ) /*0x10687fb69*/
    goto LABEL_45; /*0x10687fb69*/
LABEL_44:
  if ( v30 >= 0x11 ) /*0x10687fb6f*/
    goto LABEL_45; /*0x10687fb6f*/
  v33 = (char *)a2 + 5120; /*0x10687fbdc*/
  v34 = RBX::details::SplitHashTable<std::string,std::string,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetSelfKey<std::string>>::find_as<std::string>( /*0x10687fbea*/
          a1: v33,
          a2: &v47);
  v32 = 1; /*0x10687fbfc*/
  if ( v34 == 0 && v35 == 0 ) /*0x10687fbf7*/
  {
    RBX::details::SplitHashTable<std::string,std::string,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetSelfKey<std::string>>::emplace<std::string,std::string const&>( /*0x10687fc0d*/
      a1: v33,
      a2: &v47,
      a3: &v47);
    *((void **)this + 2) = v45[2]; /*0x10687fc16*/
    *(_OWORD *)this = *(_OWORD *)v45; /*0x10687fc21*/
    memset(v45, 0, 24); /*0x10687fc28*/
    v31 = 1; /*0x10687fc2f*/
    *((void **)this + 5) = v45[5]; /*0x10687fc3a*/
    *(_OWORD *)((char *)this + 24) = *(_OWORD *)&v45[3]; /*0x10687fc43*/
    memset(&v45[3], 0, 24); /*0x10687fc48*/
    *((_BYTE *)this + 48) = Byte; /*0x10687fc55*/
LABEL_48:
    *((_BYTE *)this + 56) = v31; /*0x10687fba9*/
    v32 = 0; /*0x10687fbad*/
  }
  if ( (v43 & 1) != 0 ) /*0x10687fbb6*/
    operator delete(a1: v44); /*0x10687fbbf*/
  if ( (v47 & 1) != 0 ) /*0x10687fbc8*/
    operator delete(a1: v48); /*0x10687fbd2*/
LABEL_56:
  if ( ((__int64)v45[3] & 1) != 0 ) /*0x10687fc6d*/
    operator delete(a1: v45[5]); /*0x10687fc73*/
  if ( ((__int64)v45[0] & 1) != 0 ) /*0x10687fc7f*/
    operator delete(a1: v45[2]); /*0x10687fc85*/
  if ( v32 != 0 ) /*0x10687fc8c*/
  {
    *(_BYTE *)this = 0; /*0x10687fc90*/
    *((_BYTE *)this + 56) = 0; /*0x10687fc93*/
  }
  return this; /*0x10687fc9a*/
}

// Address: 0x10687fdde | Name: __ZN3RBX7Network6Server11OnReceiveV2ENS0_14IncomingPacketENSt3__18optionalIN6RakNet13SystemAddressEEE
__int64 __fastcall RBX::Network::Server::OnReceiveV2(
        RBX::Network::Server *this,
        __int128 *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int64 a7,
        __int64 a8,
        __int64 a9,
        __int64 a10)
{
  RBX::Time *v12; // rdi
  __int64 v13; // rbx
  __int64 v14; // r12
  double v15; // xmm0_8
  int v16; // ebx
  int v17; // r12d
  int v18; // r8d
  int v19; // r9d
  _BYTE *v20; // rcx
  int v21; // ebx
  int v22; // r12d
  int v23; // r8d
  int v24; // r9d
  _BYTE *v25; // rcx
  int v26; // ecx
  RBX::Network::ConcurrentRakPeer **v27; // r13
  __int64 v28; // rax
  __int64 v29; // rdx
  __int64 v30; // rsi
  __int64 v31; // r8
  __int64 v32; // r9
  __int64 v33; // rax
  __int64 v34; // rdx
  __int64 v35; // r8
  __int64 v36; // r9
  RBX::RunService *v37; // rdi
  __int64 v38; // r12
  __int128 v39; // xmm0
  __int64 v40; // rdi
  std::__shared_weak_count *v41; // rbx
  std::__shared_weak_count *v42; // rbx
  std::__shared_weak_count *v43; // rbx
  std::__shared_weak_count *v44; // r12
  __int64 v45; // rax
  __int64 v46; // rsi
  __int64 v47; // r8
  __int64 v48; // r9
  __int64 v49; // rax
  __int64 v50; // rax
  __int64 v51; // rsi
  __int64 v52; // r8
  __int64 v53; // r9
  std::__shared_weak_count *v54; // rbx
  std::__shared_weak_count *v55; // rbx
  std::__shared_weak_count *v56; // rbx
  __int64 v57; // rax
  __int64 v58; // rsi
  __int64 v59; // r8
  __int64 v60; // r9
  __int64 v61; // rax
  __int64 v62; // rax
  __int64 v63; // rsi
  __int64 v64; // r8
  __int64 v65; // r9
  std::__shared_weak_count *v66; // rbx
  std::__shared_weak_count *v67; // rbx
  std::__shared_weak_count *v68; // rbx
  std::__shared_weak_count *v69; // rbx
  __int64 v70; // rax
  unsigned int v71; // esi
  __int64 v72; // rbx
  __int64 v73; // rdx
  __int64 v74; // rcx
  __int64 v75; // r8
  __int64 v76; // r9
  __int64 v77; // rbx
  __int128 v78; // xmm0
  unsigned int v79; // ebx
  RBX::RbxTransport::NetStreamBuffer *v80; // rdi
  __int64 v81; // rax
  __int64 v82; // rdx
  __int64 v83; // rcx
  __int64 v84; // r8
  __int64 v85; // r9
  __int64 v86; // rbx
  __int128 v87; // xmm0
  _DWORD v89[10]; // [rsp+20h] [rbp-290h] BYREF
  std::__shared_weak_count *v90[2]; // [rsp+48h] [rbp-268h]
  __int64 v91; // [rsp+58h] [rbp-258h]
  _QWORD v92[6]; // [rsp+60h] [rbp-250h] BYREF
  __int128 v93; // [rsp+90h] [rbp-220h]
  __int128 v94; // [rsp+A0h] [rbp-210h]
  __int128 v95; // [rsp+B0h] [rbp-200h]
  __int128 v96; // [rsp+C0h] [rbp-1F0h]
  _QWORD v97[2]; // [rsp+D0h] [rbp-1E0h] BYREF
  _BYTE v98[40]; // [rsp+E0h] [rbp-1D0h] BYREF
  std::__shared_weak_count *v99[2]; // [rsp+108h] [rbp-1A8h] BYREF
  __int64 v100; // [rsp+118h] [rbp-198h]
  std::__shared_weak_count *v101[2]; // [rsp+120h] [rbp-190h] BYREF
  std::__shared_weak_count *v102[2]; // [rsp+130h] [rbp-180h]
  __int64 v103; // [rsp+148h] [rbp-168h] BYREF
  RBX::Memory *v104; // [rsp+154h] [rbp-15Ch]
  _QWORD v105[5]; // [rsp+160h] [rbp-150h] BYREF
  _BYTE v106[8]; // [rsp+188h] [rbp-128h] BYREF
  _BYTE v107[96]; // [rsp+190h] [rbp-120h] BYREF
  _QWORD v108[5]; // [rsp+1F0h] [rbp-C0h] BYREF
  _BYTE v109[8]; // [rsp+218h] [rbp-98h] BYREF
  _BYTE v110[96]; // [rsp+220h] [rbp-90h] BYREF

  LODWORD(v104) = RBX::Memory::setCurrentCategory( /*0x10687fe14*/
                    this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkReplicator,
                    (unsigned int)a2);
  if ( (unsigned __int8)RBX::Network::IncomingPacket::operator[](a1: a2, a2: 0) == 19 )
  {
    *(_OWORD *)v102 = 0; /*0x10687fe33*/
    v12 = (RBX::Time *)FLog::Network; /*0x10687fe41*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x10687fe53*/
      FLog::FastLog( /*0x10687fe67*/
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: "[FLog::Network] NetworkServer:NewIncomingConnection",
        0);
    v13 = *(_QWORD *)&DFLog::NetworkJoin; /*0x10687fe73*/
    if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && BYTE1(DFLog::NetworkJoin) >= 3u ) /*0x10687fe84*/
    {
      v14 = qword_10D7F3E08; /*0x10687fe8b*/
      RBX::Time::nowFastSec(this: v12); /*0x10687fe8f*/
      *(float *)&v15 = v15; /*0x10687fe94*/
      FLog::FastLogF( /*0x10687feae*/
        a1: v13,
        a2: v14,
        a3: "[DFLog::NetworkJoin] Server::OnReceive new connection @ %f s",
        v15,
        0.0,
        0.0,
        0.0);
    }
    v16 = FLog::Output; /*0x10687feba*/
    if ( (unsigned __int8)FLog::Output >= 6u && BYTE1(FLog::Output) >= 3u ) /*0x10687fecb*/
    {
      v17 = qword_10D7BE938; /*0x10687fed2*/
      RBX::Network::RakNetAddressToString( /*0x10687feeb*/
        this: (RBX::Network *)v98,
        a2: (const RakNet::SystemAddress *)&a7,
        a3: true,
        a4: 124);
      if ( (v98[0] & 1) != 0 ) /*0x10687fef7*/
        LODWORD(v20) = *(_DWORD *)&v98[16]; /*0x10687fef9*/
      else
        v20 = &v98[1]; /*0x10687ff02*/
      FLog::FastLogFormatted( /*0x10687ff18*/
        a1: v16,
        a2: v17,
        a3: (unsigned int)"[FLog::Output] New connection from %s",
        a4: (_DWORD)v20,
        a5: v18,
        a6: v19);
      if ( (v98[0] & 1) != 0 ) /*0x10687ff24*/
        operator delete(a1: *(void **)&v98[16]); /*0x10687ff2d*/
    }
    v21 = DFLog::NetworkAudit; /*0x10687ff39*/
    if ( (unsigned __int8)DFLog::NetworkAudit >= 6u && BYTE1(DFLog::NetworkAudit) >= 3u )
    {
      v22 = qword_10D783528; /*0x10687ff51*/
      RBX::Network::RakNetAddressToString( /*0x10687ff6a*/
        this: (RBX::Network *)v98,
        a2: (const RakNet::SystemAddress *)&a7,
        a3: true,
        a4: 124);
      if ( (v98[0] & 1) != 0 ) /*0x10687ff76*/
        LODWORD(v25) = *(_DWORD *)&v98[16]; /*0x10687ff78*/
      else
        v25 = &v98[1]; /*0x10687ff81*/
      FLog::FastLogFormatted(
        a1: v21,
        a2: v22,
        a3: (unsigned int)"[DFLog::NetworkAudit] RakNet Connect: New connection from %s",
        a4: (_DWORD)v25,
        a5: v23,
        a6: v24);
      if ( (v98[0] & 1) != 0 ) /*0x10687ffa3*/
        operator delete(a1: *(void **)&v98[16]); /*0x10687ffac*/
    }
    *(_DWORD *)v98 = -1; /*0x10687ffb8*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)&v98[4]); /*0x10687ffc4*/
    *(_OWORD *)v99 = 0; /*0x10687ffd3*/
    v26 = *((_DWORD *)this + 121); /*0x10687ffd6*/
    *((_DWORD *)this + 121) = v26 + 1; /*0x10687ffe0*/
    *(_DWORD *)v98 = v26; /*0x10687ffe7*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x10687fffc*/
      FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] assigning peer id = %d", v26); /*0x106880019*/
    RakNet::SystemAddress::operator=(a1: &v98[4], a2: &a7); /*0x106880024*/
    v27 = (RBX::Network::ConcurrentRakPeer **)((char *)this + 288); /*0x106880029*/
    std::shared_ptr<RBX::Network::ConcurrentRakPeer>::operator=[abi:ne200100](a1: v99, a2: (char *)this + 288); /*0x10688003a*/
    v28 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x106880046*/
    v100 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, __int64, __int64, __int64, __int64))(*(_QWORD *)v28 + 688LL))( /*0x10688006a*/
             a1: v28,
             a2: v30,
             a3: v29,
             a4: *(_QWORD *)(*(_QWORD *)v28 + 688LL),
             a5: v31,
             a6: v32,
             a7,
             a8,
             a9,
             a10);
    v33 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x106880075*/
    (*(void (__fastcall **)(std::__shared_weak_count **, __int64, __int64, _QWORD, __int64, __int64, __int64, __int64, __int64, __int64))(*(_QWORD *)v33 + 704LL))( /*0x10688009e*/
      a1: v101,
      a2: v33,
      a3: v34,
      a4: *(_QWORD *)(*(_QWORD *)v33 + 704LL),
      a5: v35,
      a6: v36,
      a7,
      a8,
      a9,
      a10);
    if ( v101[0] != nullptr )
    {
      LODWORD(v92[0]) = *(_DWORD *)v98; /*0x1068800bb*/
      v92[1] = v99[0]; /*0x1068800c4*/
      *(_OWORD *)&v92[2] = *(_OWORD *)&v98[4]; /*0x1068800d3*/
      *(_OWORD *)&v92[4] = *(_OWORD *)&v98[20]; /*0x1068800d7*/
      RBX::NetworkBase::IFactory::createConnection_Legacy(a1: v97, a2: 0); /*0x1068800e4*/
      v38 = v97[0]; /*0x1068800e9*/
      if ( DFFlag::StudioAuthGate == 1 && (unsigned __int8)RBX::RunService::productIsStudio(this: v37) != 0 ) /*0x106880100*/
        (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v38 + 64LL))(a1: v38, a2: 1); /*0x10688010e*/
      qmemcpy(v89, v98, 36); /*0x10688011f*/
      *(_OWORD *)v90 = *(_OWORD *)v99; /*0x106880147*/
      if ( v99[1] != nullptr ) /*0x106880151*/
        _InterlockedIncrement64((volatile signed __int64 *)v99[1] + 1); /*0x106880153*/
      v91 = v100; /*0x106880166*/
      v103 = v38; /*0x10688016a*/
      v97[0] = this; /*0x106880171*/
      if ( qword_10D80FB70 == 0 ) /*0x106880182*/
        std::__throw_bad_function_call[abi:ne200100](a1: v37); /*0x106880719*/
      (*(void (__fastcall **)(_QWORD *, __int64, _DWORD *, _QWORD *, __int64 *))(*(_QWORD *)qword_10D80FB70 + 48LL))( /*0x1068801a7*/
        a1: v92,
        a2: qword_10D80FB70,
        a3: v89,
        a4: v97,
        a5: &v103);
      v39 = *(_OWORD *)v92; /*0x1068801b1*/
      *(_OWORD *)v92 = 0; /*0x1068801bb*/
      *(_OWORD *)v102 = v39; /*0x1068801c2*/
      v40 = v103; /*0x1068801c9*/
      v103 = 0; /*0x1068801d0*/
      if ( v40 != 0 ) /*0x1068801de*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v40 + 8LL))(a1: v40); /*0x1068801e3*/
      v41 = v90[1]; /*0x1068801e6*/
      if ( v90[1] != nullptr /*0x106880202*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v90[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v41 + 16LL))(a1: v41); /*0x10688020a*/
        std::__shared_weak_count::__release_weak(this: v41); /*0x106880210*/
      }
      v42 = v102[0]; /*0x106880215*/
      if ( FFlag::SeparateRakNetAndRbxTransportRouting == 1 ) /*0x106880223*/
      {
        v93 = *(_OWORD *)v101; /*0x106880237*/
        *(_OWORD *)v101 = 0; /*0x10688023d*/
        RBX::Network::Replicator::setSessionCrypto(a1: (__int64)v102[0]); /*0x106880247*/
        v43 = *((std::__shared_weak_count **)&v93 + 1); /*0x10688024c*/
        if ( *((_QWORD *)&v93 + 1) != 0 /*0x106880268*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v93 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v43 + 16LL))(a1: v43); /*0x106880270*/
          std::__shared_weak_count::__release_weak(this: v43); /*0x106880276*/
        }
        v44 = v102[0]; /*0x10688027b*/
        v45 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *v27); /*0x106880286*/
        v49 = (*(__int64 (__fastcall **)(__int64, __int64, __int64 *, _QWORD, __int64, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD, _DWORD, std::__shared_weak_count *))(*(_QWORD *)v45 + 712LL))( /*0x1068802ac*/
                a1: v45,
                a2: v46,
                a3: &a7,
                a4: *(_QWORD *)(*(_QWORD *)v45 + 712LL),
                a5: v47,
                a6: v48,
                a7,
                a8,
                a9,
                a10,
                a11: *(_QWORD *)v89,
                a12: *(_QWORD *)&v89[2],
                a13: *(_QWORD *)&v89[4],
                a14: *(_QWORD *)&v89[6],
                a15: v89[8],
                a16: v90[0]);
        *((_DWORD *)v44 + 5510) = v49; /*0x1068802ae*/
        *((_BYTE *)v44 + 22044) = BYTE4(v49); /*0x1068802ba*/
        if ( DFFlag::RuppTokenOneBeeRcc == 1 ) /*0x1068802cc*/
        {
          v50 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *v27); /*0x1068802d2*/
          *((_BYTE *)v44 + 22048) = (*(__int64 (__fastcall **)(__int64, __int64, __int64 *, _QWORD, __int64, __int64, __int64, __int64, __int64, __int64))(*(_QWORD *)v50 + 720LL))( /*0x1068802fa*/
                                      a1: v50,
                                      a2: v51,
                                      a3: &a7,
                                      a4: *(_QWORD *)(*(_QWORD *)v50 + 720LL),
                                      a5: v52,
                                      a6: v53,
                                      a7,
                                      a8,
                                      a9,
                                      a10);
        }
        if ( *((_BYTE *)v44 + 18600) == 1 ) /*0x10688030b*/
          RBX::Network::ServerReplicator::updateConnectionAcceptedTime(this: v44); /*0x106880310*/
        v94 = 0; /*0x10688031f*/
        RBX::Instance::setAndLockParent(this: v44); /*0x10688032a*/
        v54 = *((std::__shared_weak_count **)&v94 + 1); /*0x10688032f*/
        if ( *((_QWORD *)&v94 + 1) != 0 /*0x106880352*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v94 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v54 + 16LL))(a1: v54); /*0x10688035a*/
          std::__shared_weak_count::__release_weak(this: v54); /*0x106880360*/
        }
        RBX::Network::Server::registerRakNetReplicator(this, a2: (const RakNet::SystemAddress *)&v98[4], a3: v102[0]); /*0x106880372*/
      }
      else
      {
        v92[0] = &v98[4]; /*0x1068803f7*/
        *(_QWORD *)(std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::__emplace_unique_key_args<RakNet::SystemAddress,std::piecewise_construct_t const&,std::tuple<RakNet::SystemAddress const&>,std::tuple<>>( /*0x106880410*/
                      a1: (char *)this + 4648,
                      a2: &v98[4],
                      a3: std::piecewise_construct,
                      a4: v92,
                      a5: v97)
                  + 48) = v42;
        v95 = *(_OWORD *)v101; /*0x106880422*/
        *(_OWORD *)v101 = 0; /*0x106880428*/
        RBX::Network::Replicator::setSessionCrypto(a1: (__int64)v42); /*0x106880432*/
        v55 = *((std::__shared_weak_count **)&v95 + 1); /*0x106880437*/
        if ( *((_QWORD *)&v95 + 1) != 0 /*0x106880453*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v95 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v55 + 16LL))(a1: v55); /*0x10688045b*/
          std::__shared_weak_count::__release_weak(this: v55); /*0x106880461*/
        }
        v56 = v102[0]; /*0x106880466*/
        v57 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *v27); /*0x106880471*/
        v61 = (*(__int64 (__fastcall **)(__int64, __int64, __int64 *, _QWORD, __int64, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD, _DWORD, std::__shared_weak_count *))(*(_QWORD *)v57 + 712LL))( /*0x106880497*/
                a1: v57,
                a2: v58,
                a3: &a7,
                a4: *(_QWORD *)(*(_QWORD *)v57 + 712LL),
                a5: v59,
                a6: v60,
                a7,
                a8,
                a9,
                a10,
                a11: *(_QWORD *)v89,
                a12: *(_QWORD *)&v89[2],
                a13: *(_QWORD *)&v89[4],
                a14: *(_QWORD *)&v89[6],
                a15: v89[8],
                a16: v90[0]);
        *((_DWORD *)v56 + 5510) = v61; /*0x106880499*/
        *((_BYTE *)v56 + 22044) = BYTE4(v61); /*0x1068804a3*/
        if ( DFFlag::RuppTokenOneBeeRcc == 1 ) /*0x1068804b3*/
        {
          v62 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *v27); /*0x1068804b9*/
          *((_BYTE *)v56 + 22048) = (*(__int64 (__fastcall **)(__int64, __int64, __int64 *, _QWORD, __int64, __int64, __int64, __int64, __int64, __int64))(*(_QWORD *)v62 + 720LL))( /*0x1068804e1*/
                                      a1: v62,
                                      a2: v63,
                                      a3: &a7,
                                      a4: *(_QWORD *)(*(_QWORD *)v62 + 720LL),
                                      a5: v64,
                                      a6: v65,
                                      a7,
                                      a8,
                                      a9,
                                      a10);
        }
        if ( *((_BYTE *)v56 + 18600) == 1 ) /*0x1068804ee*/
          RBX::Network::ServerReplicator::updateConnectionAcceptedTime(this: v56); /*0x1068804f3*/
        v96 = 0; /*0x106880502*/
        RBX::Instance::setAndLockParent(this: v56); /*0x10688050d*/
        v66 = *((std::__shared_weak_count **)&v96 + 1); /*0x106880512*/
        if ( *((_QWORD *)&v96 + 1) != 0 /*0x10688052e*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v96 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v66 + 16LL))(a1: v66); /*0x106880536*/
          std::__shared_weak_count::__release_weak(this: v66); /*0x10688053c*/
        }
      }
    }
    else if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 6u )
    {
      v92[0] = 0; /*0x1068803a3*/
      v92[1] = v97; /*0x1068803b5*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: 6,
        a4: (unsigned int)"[FLog::Network] Server::OnReceive: ID_NEW_INCOMING_CONNECTION: SessionCrypto not found, new connec"
                      "tion closed by RakNet before we could create a replicator",
        a5: 155,
        a6: 1,
        0,
        v97);
    }
    v67 = v101[1]; /*0x106880541*/
    if ( v101[1] != nullptr /*0x10688055d*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v101[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v67 + 16LL))(a1: v67); /*0x106880565*/
      std::__shared_weak_count::__release_weak(this: v67); /*0x10688056b*/
    }
    v68 = v99[1]; /*0x106880570*/
    if ( v99[1] != nullptr /*0x106880590*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v99[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v68 + 16LL))(a1: v68); /*0x106880598*/
      std::__shared_weak_count::__release_weak(this: v68); /*0x10688059e*/
    }
    v69 = v102[1]; /*0x1068805a3*/
    if ( v102[1] != nullptr /*0x1068805bf*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v102[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v69 + 16LL))(a1: v69); /*0x1068805c7*/
      std::__shared_weak_count::__release_weak(this: v69); /*0x1068805cd*/
    }
  }
  if ( FFlag::SeparateRakNetAndRbxTransportRouting == 1 ) /*0x1068805d9*/
  {
    v70 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::find<RakNet::SystemAddress>( /*0x1068805e9*/
            a1: (char *)this + 4688,
            a2: &a7);
    v72 = v70; /*0x1068805ee*/
    if ( v70 != 0 ) /*0x1068805f4*/
    {
      if ( (unsigned __int8)RBX::Network::Server::acceptRakNetIngressRoute( /*0x10688060b*/
                              this,
                              a2: *(const RBX::Network::Replicator **)(v70 + 48),
                              a3: (const RakNet::SystemAddress *)&a7) == 0 )
      {
        v79 = 0; /*0x106880710*/
        goto LABEL_75; /*0x106880712*/
      }
      v77 = *(_QWORD *)(v72 + 48); /*0x106880611*/
      v108[4] = *((_QWORD *)a2 + 4); /*0x106880620*/
      v78 = *a2; /*0x106880624*/
      *(_OWORD *)&v108[2] = a2[1]; /*0x10688062d*/
      *(_OWORD *)v108 = v78; /*0x106880631*/
      std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x10688063c*/
        a1: v109,
        a2: (char *)a2 + 40,
        a3: v73,
        a4: v74,
        a5: v75,
        a6: v76);
      v79 = (*(__int64 (__fastcall **)(__int64, _QWORD *))(*(_QWORD *)v77 + 712LL))(a1: v77, a2: v108); /*0x106880654*/
      if ( v110[88] != 0 ) /*0x10688065a*/
      {
        v80 = (RBX::RbxTransport::NetStreamBuffer *)v110; /*0x106880660*/
LABEL_73:
        RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: v80); /*0x1068806d5*/
        goto LABEL_75; /*0x1068806da*/
      }
      goto LABEL_75; /*0x10688065a*/
    }
LABEL_74:
    v79 = 1; /*0x1068806dc*/
    goto LABEL_75; /*0x1068806dc*/
  }
  v81 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::find<RakNet::SystemAddress>( /*0x106880676*/
          a1: (char *)this + 4648,
          a2: &a7);
  if ( v81 == 0 ) /*0x10688067e*/
    goto LABEL_74; /*0x10688067e*/
  v86 = *(_QWORD *)(v81 + 48); /*0x106880680*/
  v105[4] = *((_QWORD *)a2 + 4); /*0x10688068f*/
  v87 = *a2; /*0x106880693*/
  *(_OWORD *)&v105[2] = a2[1]; /*0x10688069c*/
  *(_OWORD *)v105 = v87; /*0x1068806a0*/
  std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1068806ab*/
    a1: v106,
    a2: (char *)a2 + 40,
    a3: v82,
    a4: v83,
    a5: v84,
    a6: v85);
  v79 = (*(__int64 (__fastcall **)(__int64, _QWORD *))(*(_QWORD *)v86 + 712LL))(a1: v86, a2: v105); /*0x1068806c3*/
  if ( v107[88] != 0 ) /*0x1068806cc*/
  {
    v80 = (RBX::RbxTransport::NetStreamBuffer *)v107; /*0x1068806ce*/
    goto LABEL_73; /*0x1068806ce*/
  }
LABEL_75:
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)v104, a2: v71); /*0x1068806e1*/
  return v79; /*0x1068806fe*/
}

// Address: 0x1068809da | Name: __ZN3RBX7Network6Server24registerRakNetReplicatorERKN6RakNet13SystemAddressEPNS0_10ReplicatorE
char __fastcall RBX::Network::Server::registerRakNetReplicator(
        RBX::Network::Server *this,
        const RakNet::SystemAddress *a2,
        RBX::Network::Replicator *a3)
{
  __int64 v3; // rcx
  char result; // al
  char v5; // dl
  RBX::Network::Replicator *v6; // [rsp+8h] [rbp-8h] BYREF

  v6 = a3; /*0x1068809e2*/
  if ( a3 != nullptr && *((_QWORD *)a3 + 28) != 0 ) /*0x1068809f3*/
  {
    v3 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::__emplace_unique_key_args<RakNet::SystemAddress,RakNet::SystemAddress const&,RBX::Network::Replicator *&>( /*0x106880a08*/
           a1: (char *)this + 4688,
           a2,
           a3: a2,
           a4: &v6);
    result = 1; /*0x106880a0b*/
    if ( (v5 & 1) != 0 ) /*0x106880a10*/
      return result; /*0x106880a10*/
    *(_QWORD *)(v3 + 48) = v6; /*0x106880a16*/
  }
  return 0; /*0x106880a1c*/
}

// Address: 0x106880a22 | Name: __ZN3RBX7Network6Server24acceptRakNetIngressRouteEPKNS0_10ReplicatorERKN6RakNet13SystemAddressE
char __fastcall RBX::Network::Server::acceptRakNetIngressRoute(
        RBX::Network::Server *this,
        const RBX::Network::Replicator *a2,
        const RakNet::SystemAddress *a3)
{
  char result; // al
  int v5; // r14d
  int v6; // r15d
  void *v7[9]; // [rsp+0h] [rbp-240h] BYREF
  _BYTE v8[504]; // [rsp+48h] [rbp-1F8h] BYREF

  if ( a2 == nullptr || (result = 1, *((_QWORD *)a2 + 28) == 0) )
  {
    std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::__erase_unique<RakNet::SystemAddress>( /*0x106880a56*/
      a1: (char *)this + 4688,
      a2: a3);
    v5 = FLog::Network; /*0x106880a62*/
    if ( (unsigned __int8)FLog::Network >= 6u && (FLog::Network & 0xFE00) != 0 )
    {
      v6 = qword_10D7BBAA8; /*0x106880a7a*/
      RBX::Network::RakNetAddressToString(this: (RBX::Network *)v7, a2: a3, a3: true, a4: 124); /*0x106880a95*/
      FLog::FastLogSafeFormatted<std::string>(
        a1: v5,
        a2: v6,
        a3: 2,
        a4: (int)"[FLog::Network] Server: dropped RakNet route for {} with no RakNet peer",
        a5: 71,
        a6: (unsigned __int8 *)v7);
      if ( ((__int64)v7[0] & 1) != 0 ) /*0x106880ac1*/
        operator delete(a1: v7[2]); /*0x106880aca*/
    }
    RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x106880ae0*/
      a1: v7,
      a2: (__int64)&RBX::Telemetry::kRakNetRouteWithoutPeer);
    RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v7); /*0x106880ae8*/
    RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v8); /*0x106880aff*/
    RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v7, a2: (void **)off_10C8C7EB0); /*0x106880b12*/
    return 0; /*0x106880b17*/
  }
  return result; /*0x106880b19*/
}

// Address: 0x106880b5a | Name: __ZN3RBX7Network6Server9OnReceiveEPN6RakNet6PacketE
__int64 __fastcall RBX::Network::Server::OnReceive(RBX::Network::Server *this, RBX::Network::Replicator **a2)
{
  unsigned int v4; // r13d
  RBX::Time *v5; // rdi
  __int64 v6; // rbx
  __int64 v7; // r12
  double v8; // xmm0_8
  int v9; // ebx
  int v10; // r12d
  int v11; // r8d
  int v12; // r9d
  char *v13; // rcx
  int v14; // ebx
  int v15; // r12d
  int v16; // r8d
  int v17; // r9d
  char *v18; // rcx
  unsigned int v19; // ecx
  RBX::Network::ConcurrentRakPeer **v20; // rbx
  __int64 v21; // rax
  __int64 v22; // rdx
  __int64 v23; // rsi
  __int64 v24; // r8
  __int64 v25; // r9
  __int64 v26; // rax
  __int64 v27; // rdx
  __int64 v28; // r8
  __int64 v29; // r9
  RBX::RunService *v30; // rdi
  __int64 v31; // r12
  __int128 v32; // xmm0
  __int64 v33; // rdi
  std::__shared_weak_count *v34; // r12
  std::__shared_weak_count *v35; // r12
  std::__shared_weak_count *v36; // r12
  std::__shared_weak_count *v37; // r12
  __int64 v38; // rax
  __int64 v39; // rdx
  __int64 v40; // rsi
  __int64 v41; // r8
  __int64 v42; // r9
  __int64 v43; // rax
  __int64 v44; // rax
  __int64 v45; // rdx
  __int64 v46; // rsi
  __int64 v47; // r8
  __int64 v48; // r9
  std::__shared_weak_count *v49; // rbx
  std::__shared_weak_count *v50; // r12
  std::__shared_weak_count *v51; // r12
  __int64 v52; // rax
  __int64 v53; // rdx
  __int64 v54; // rsi
  __int64 v55; // r8
  __int64 v56; // r9
  __int64 v57; // rax
  __int64 v58; // rax
  __int64 v59; // rdx
  __int64 v60; // rsi
  __int64 v61; // r8
  __int64 v62; // r9
  std::__shared_weak_count *v63; // rbx
  std::__shared_weak_count *v64; // rbx
  std::__shared_weak_count *v65; // rbx
  std::__shared_weak_count *v66; // rbx
  __int64 v67; // rax
  unsigned int v68; // esi
  __int64 v69; // rbx
  int v70; // ecx
  unsigned __int8 v71; // al
  unsigned int v72; // r15d
  __int64 v73; // rax
  __int64 v74; // rdx
  __int64 v75; // rcx
  int v76; // ecx
  int v77; // r8d
  int v78; // r9d
  char *v79; // rdx
  __int64 v80; // rax
  int v81; // ecx
  unsigned __int8 v82; // al
  unsigned int v83; // r15d
  __int64 v84; // rax
  __int64 v85; // rdx
  __int64 v86; // rcx
  int v87; // ecx
  int v88; // r8d
  int v89; // r9d
  char *v90; // rdx
  unsigned int v91; // ebx
  __int64 v92; // rbx
  __int64 v93; // rdx
  __int64 v94; // rcx
  __int64 v95; // r8
  __int64 v96; // r9
  RBX::RbxTransport::NetStreamBuffer *v97; // rdi
  __int64 v98; // rbx
  __int64 v99; // rdx
  __int64 v100; // rcx
  __int64 v101; // r8
  __int64 v102; // r9
  _QWORD *v103; // r12
  __int64 v104; // rax
  __int64 v105; // rdx
  __int64 v106; // rcx
  __int64 v107; // rdi
  _QWORD *v108; // r12
  __int64 v109; // rax
  __int64 v110; // rdx
  __int64 v111; // rcx
  __int64 v112; // rdi
  __int128 v114[3]; // [rsp+20h] [rbp-3F0h] BYREF
  _BYTE v115[8]; // [rsp+58h] [rbp-3B8h] BYREF
  __int128 v116[3]; // [rsp+60h] [rbp-3B0h] BYREF
  _BYTE v117[136]; // [rsp+98h] [rbp-378h] BYREF
  _DWORD v118[10]; // [rsp+120h] [rbp-2F0h] BYREF
  std::__shared_weak_count *v119[2]; // [rsp+148h] [rbp-2C8h]
  __int64 v120; // [rsp+158h] [rbp-2B8h]
  _BYTE v121[16]; // [rsp+160h] [rbp-2B0h] BYREF
  __int128 v122; // [rsp+170h] [rbp-2A0h]
  __int128 v123; // [rsp+180h] [rbp-290h]
  std::__shared_weak_count *v124[2]; // [rsp+190h] [rbp-280h]
  std::__shared_weak_count *v125[2]; // [rsp+1A0h] [rbp-270h]
  _QWORD v126[2]; // [rsp+1B0h] [rbp-260h] BYREF
  std::__shared_weak_count *v127[2]; // [rsp+1C0h] [rbp-250h] BYREF
  std::__shared_weak_count *v128[2]; // [rsp+1D0h] [rbp-240h]
  __int128 v129; // [rsp+1E0h] [rbp-230h] BYREF
  __int128 v130; // [rsp+1F0h] [rbp-220h]
  __int128 v131; // [rsp+200h] [rbp-210h]
  __int64 v132; // [rsp+218h] [rbp-1F8h] BYREF
  unsigned int v133; // [rsp+224h] [rbp-1ECh]
  _BYTE v134[40]; // [rsp+230h] [rbp-1E0h] BYREF
  _BYTE v135[8]; // [rsp+258h] [rbp-1B8h] BYREF
  _BYTE v136[96]; // [rsp+260h] [rbp-1B0h] BYREF
  _BYTE v137[40]; // [rsp+2C0h] [rbp-150h] BYREF
  _BYTE v138[8]; // [rsp+2E8h] [rbp-128h] BYREF
  _BYTE v139[96]; // [rsp+2F0h] [rbp-120h] BYREF
  unsigned int v140[10]; // [rsp+350h] [rbp-C0h] BYREF
  std::__shared_weak_count *v141[2]; // [rsp+378h] [rbp-98h] BYREF
  __int64 v142; // [rsp+388h] [rbp-88h]
  char v143; // [rsp+3D8h] [rbp-38h]

  v4 = RBX::Memory::setCurrentCategory( /*0x106880b90*/
         this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkReplicator,
         (unsigned int)a2);
  if ( *(_BYTE *)a2[7] == 19 )
  {
    v133 = v4; /*0x106880ba0*/
    *(_OWORD *)v128 = 0; /*0x106880baa*/
    v5 = (RBX::Time *)FLog::Network; /*0x106880bb8*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x106880bca*/
      FLog::FastLog( /*0x106880bde*/
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: "[FLog::Network] NetworkServer:NewIncomingConnection",
        0);
    v6 = *(_QWORD *)&DFLog::NetworkJoin; /*0x106880bea*/
    if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && BYTE1(DFLog::NetworkJoin) >= 3u ) /*0x106880bfb*/
    {
      v7 = qword_10D7F3E08; /*0x106880c02*/
      RBX::Time::nowFastSec(this: v5); /*0x106880c06*/
      *(float *)&v8 = v8; /*0x106880c0b*/
      FLog::FastLogF( /*0x106880c25*/
        a1: v6,
        a2: v7,
        a3: "[DFLog::NetworkJoin] Server::OnReceive new connection @ %f s",
        v8,
        0.0,
        0.0,
        0.0);
    }
    v9 = FLog::Output; /*0x106880c31*/
    if ( (unsigned __int8)FLog::Output >= 6u && BYTE1(FLog::Output) >= 3u ) /*0x106880c42*/
    {
      v10 = qword_10D7BE938; /*0x106880c49*/
      RBX::Network::RakNetAddressToString( /*0x106880c61*/
        this: (RBX::Network *)v140,
        (const RakNet::SystemAddress *)a2,
        a3: true,
        a4: 124);
      if ( (v140[0] & 1) != 0 ) /*0x106880c6d*/
        LODWORD(v13) = v140[4]; /*0x106880c6f*/
      else
        v13 = (char *)v140 + 1; /*0x106880c78*/
      FLog::FastLogFormatted( /*0x106880c8e*/
        a1: v9,
        a2: v10,
        a3: (unsigned int)"[FLog::Output] New connection from %s",
        a4: (_DWORD)v13,
        a5: v11,
        a6: v12);
      if ( (v140[0] & 1) != 0 ) /*0x106880c9a*/
        operator delete(a1: *(void **)&v140[4]); /*0x106880ca3*/
    }
    v14 = DFLog::NetworkAudit; /*0x106880caf*/
    if ( (unsigned __int8)DFLog::NetworkAudit >= 6u && BYTE1(DFLog::NetworkAudit) >= 3u )
    {
      v15 = qword_10D783528; /*0x106880cc7*/
      RBX::Network::RakNetAddressToString( /*0x106880cdf*/
        this: (RBX::Network *)v140,
        (const RakNet::SystemAddress *)a2,
        a3: true,
        a4: 124);
      if ( (v140[0] & 1) != 0 ) /*0x106880ceb*/
        LODWORD(v18) = v140[4]; /*0x106880ced*/
      else
        v18 = (char *)v140 + 1; /*0x106880cf6*/
      FLog::FastLogFormatted(
        a1: v14,
        a2: v15,
        a3: (unsigned int)"[DFLog::NetworkAudit] RakNet Connect: New connection from %s",
        a4: (_DWORD)v18,
        a5: v16,
        a6: v17);
      if ( (v140[0] & 1) != 0 ) /*0x106880d18*/
        operator delete(a1: *(void **)&v140[4]); /*0x106880d21*/
    }
    v140[0] = -1; /*0x106880d2d*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)&v140[1]); /*0x106880d39*/
    *(_OWORD *)v141 = 0; /*0x106880d48*/
    v19 = *((_DWORD *)this + 121); /*0x106880d4b*/
    *((_DWORD *)this + 121) = v19 + 1; /*0x106880d55*/
    v140[0] = v19; /*0x106880d5c*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x106880d71*/
      FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] assigning peer id = %d", v19); /*0x106880d83*/
    RakNet::SystemAddress::operator=(a1: &v140[1], a2); /*0x106880d8e*/
    v20 = (RBX::Network::ConcurrentRakPeer **)((char *)this + 288); /*0x106880d93*/
    std::shared_ptr<RBX::Network::ConcurrentRakPeer>::operator=[abi:ne200100](a1: v141, a2: (char *)this + 288); /*0x106880da4*/
    v21 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x106880db0*/
    v142 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *))(*(_QWORD *)v21 + 688LL))( /*0x106880dd6*/
             a1: v21,
             a2: v23,
             a3: v22,
             a4: *(_QWORD *)(*(_QWORD *)v21 + 688LL),
             a5: v24,
             a6: v25,
             a7: *a2,
             a8: a2[1],
             a9: a2[2],
             a10: a2[3]);
    v26 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x106880de0*/
    (*(void (__fastcall **)(std::__shared_weak_count **, __int64, __int64, _QWORD, __int64, __int64, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *))(*(_QWORD *)v26 + 704LL))( /*0x106880e0b*/
      a1: v127,
      a2: v26,
      a3: v27,
      a4: *(_QWORD *)(*(_QWORD *)v26 + 704LL),
      a5: v28,
      a6: v29,
      a7: *a2,
      a8: a2[1],
      a9: a2[2],
      a10: a2[3]);
    if ( v127[0] != nullptr )
    {
      LODWORD(v129) = v140[0]; /*0x106880e28*/
      *((std::__shared_weak_count **)&v129 + 1) = v141[0]; /*0x106880e31*/
      v130 = *(_OWORD *)&v140[1]; /*0x106880e40*/
      v131 = *(_OWORD *)&v140[5]; /*0x106880e44*/
      RBX::NetworkBase::IFactory::createConnection_Legacy(a1: v126, a2: 0); /*0x106880e51*/
      v31 = v126[0]; /*0x106880e56*/
      _InterlockedExchange((volatile __int32 *)(v126[0] + 1412LL), 2); /*0x106880e62*/
      if ( DFFlag::StudioAuthGate == 1 && (unsigned __int8)RBX::RunService::productIsStudio(this: v30) != 0 ) /*0x106880e7a*/
        (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v31 + 64LL))(a1: v31, a2: 1); /*0x106880e88*/
      qmemcpy(v118, v140, 36); /*0x106880e99*/
      *(_OWORD *)v119 = *(_OWORD *)v141; /*0x106880ec1*/
      if ( v141[1] != nullptr ) /*0x106880ecb*/
        _InterlockedIncrement64((volatile signed __int64 *)v141[1] + 1); /*0x106880ecd*/
      v120 = v142; /*0x106880ee0*/
      v132 = v31; /*0x106880ee4*/
      v126[0] = this; /*0x106880eeb*/
      if ( qword_10D80FB70 == 0 ) /*0x106880efc*/
        std::__throw_bad_function_call[abi:ne200100](a1: v30); /*0x1068817f4*/
      (*(void (__fastcall **)(__int128 *, __int64, _DWORD *, _QWORD *, __int64 *))(*(_QWORD *)qword_10D80FB70 + 48LL))( /*0x106880f21*/
        a1: &v129,
        a2: qword_10D80FB70,
        a3: v118,
        a4: v126,
        a5: &v132);
      v32 = v129; /*0x106880f24*/
      v129 = 0; /*0x106880f2e*/
      *(_OWORD *)v128 = v32; /*0x106880f35*/
      v33 = v132; /*0x106880f3c*/
      v132 = 0; /*0x106880f43*/
      if ( v33 != 0 ) /*0x106880f51*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v33 + 8LL))(a1: v33); /*0x106880f56*/
      v34 = v119[1]; /*0x106880f59*/
      if ( v119[1] != nullptr /*0x106880f76*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v119[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v34 + 16LL))(a1: v34); /*0x106880f7f*/
        std::__shared_weak_count::__release_weak(this: v34); /*0x106880f85*/
      }
      v35 = v128[0]; /*0x106880f8a*/
      if ( FFlag::SeparateRakNetAndRbxTransportRouting == 1 ) /*0x106880f98*/
      {
        *(_OWORD *)v124 = *(_OWORD *)v127; /*0x106880fac*/
        if ( v127[1] != nullptr ) /*0x106880fb6*/
          _InterlockedIncrement64((volatile signed __int64 *)v127[1] + 1); /*0x106880fb8*/
        RBX::Network::Replicator::setSessionCrypto(a1: (__int64)v35); /*0x106880fc7*/
        v36 = v124[1]; /*0x106880fcc*/
        if ( v124[1] != nullptr /*0x106880fe9*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v124[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v36 + 16LL))(a1: v36); /*0x106880ff2*/
          std::__shared_weak_count::__release_weak(this: v36); /*0x106880ff8*/
        }
        v37 = v128[0]; /*0x106880ffd*/
        v38 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *v20); /*0x106881007*/
        v43 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *))(*(_QWORD *)v38 + 712LL))( /*0x10688102b*/
                a1: v38,
                a2: v40,
                a3: v39,
                a4: *(_QWORD *)(*(_QWORD *)v38 + 712LL),
                a5: v41,
                a6: v42,
                a7: *a2,
                a8: a2[1],
                a9: a2[2],
                a10: a2[3]);
        *((_DWORD *)v37 + 5510) = v43; /*0x10688102d*/
        *((_BYTE *)v37 + 22044) = BYTE4(v43); /*0x106881039*/
        if ( DFFlag::RuppTokenOneBeeRcc == 1 ) /*0x10688104b*/
        {
          v44 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *v20); /*0x106881050*/
          *((_BYTE *)v37 + 22048) = (*(__int64 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *))(*(_QWORD *)v44 + 720LL))( /*0x106881076*/
                                      a1: v44,
                                      a2: v46,
                                      a3: v45,
                                      a4: *(_QWORD *)(*(_QWORD *)v44 + 720LL),
                                      a5: v47,
                                      a6: v48,
                                      a7: *a2,
                                      a8: a2[1],
                                      a9: a2[2],
                                      a10: a2[3]);
        }
        if ( *((_BYTE *)v37 + 18600) == 1 ) /*0x106881087*/
          RBX::Network::ServerReplicator::updateConnectionAcceptedTime(this: v37); /*0x10688108c*/
        v122 = 0; /*0x10688109b*/
        RBX::Instance::setAndLockParent(this: v37); /*0x1068810a6*/
        v49 = *((std::__shared_weak_count **)&v122 + 1); /*0x1068810ab*/
        if ( *((_QWORD *)&v122 + 1) != 0 /*0x1068810ce*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v122 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v49 + 16LL))(a1: v49); /*0x1068810d6*/
          std::__shared_weak_count::__release_weak(this: v49); /*0x1068810dc*/
        }
        RBX::Network::Server::registerRakNetReplicator(this, a2: (const RakNet::SystemAddress *)&v140[1], a3: v128[0]); /*0x1068810ee*/
      }
      else
      {
        v126[0] = &v140[1]; /*0x106881174*/
        *(_QWORD *)(std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::__emplace_unique_key_args<RakNet::SystemAddress,std::piecewise_construct_t const&,std::tuple<RakNet::SystemAddress const&>,std::tuple<>>( /*0x10688118a*/
                      a1: (char *)this + 4648,
                      a2: &v140[1],
                      a3: std::piecewise_construct,
                      a4: v126,
                      a5: v121)
                  + 48) = v35;
        *(_OWORD *)v125 = *(_OWORD *)v127; /*0x10688119c*/
        if ( v127[1] != nullptr ) /*0x1068811a6*/
          _InterlockedIncrement64((volatile signed __int64 *)v127[1] + 1); /*0x1068811a8*/
        RBX::Network::Replicator::setSessionCrypto(a1: (__int64)v35); /*0x1068811b7*/
        v50 = v125[1]; /*0x1068811bc*/
        if ( v125[1] != nullptr /*0x1068811d9*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v125[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v50 + 16LL))(a1: v50); /*0x1068811e2*/
          std::__shared_weak_count::__release_weak(this: v50); /*0x1068811e8*/
        }
        v51 = v128[0]; /*0x1068811ed*/
        v52 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *v20); /*0x1068811f7*/
        v57 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *))(*(_QWORD *)v52 + 712LL))( /*0x10688121b*/
                a1: v52,
                a2: v54,
                a3: v53,
                a4: *(_QWORD *)(*(_QWORD *)v52 + 712LL),
                a5: v55,
                a6: v56,
                a7: *a2,
                a8: a2[1],
                a9: a2[2],
                a10: a2[3]);
        *((_DWORD *)v51 + 5510) = v57; /*0x10688121d*/
        *((_BYTE *)v51 + 22044) = BYTE4(v57); /*0x106881229*/
        if ( DFFlag::RuppTokenOneBeeRcc == 1 ) /*0x10688123b*/
        {
          v58 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *v20); /*0x106881240*/
          *((_BYTE *)v51 + 22048) = (*(__int64 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *, RBX::Network::Replicator *))(*(_QWORD *)v58 + 720LL))( /*0x106881266*/
                                      a1: v58,
                                      a2: v60,
                                      a3: v59,
                                      a4: *(_QWORD *)(*(_QWORD *)v58 + 720LL),
                                      a5: v61,
                                      a6: v62,
                                      a7: *a2,
                                      a8: a2[1],
                                      a9: a2[2],
                                      a10: a2[3]);
        }
        if ( *((_BYTE *)v51 + 18600) == 1 ) /*0x106881277*/
          RBX::Network::ServerReplicator::updateConnectionAcceptedTime(this: v51); /*0x10688127c*/
        v123 = 0; /*0x10688128b*/
        RBX::Instance::setAndLockParent(this: v51); /*0x106881296*/
        v63 = *((std::__shared_weak_count **)&v123 + 1); /*0x10688129b*/
        if ( *((_QWORD *)&v123 + 1) != 0 /*0x1068812b7*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v123 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v63 + 16LL))(a1: v63); /*0x1068812bf*/
          std::__shared_weak_count::__release_weak(this: v63); /*0x1068812c5*/
        }
      }
    }
    else if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 6u )
    {
      v126[0] = 0; /*0x106881119*/
      v126[1] = v121; /*0x10688112b*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: 6,
        a4: (unsigned int)"[FLog::Network] Server::OnReceive: ID_NEW_INCOMING_CONNECTION: SessionCrypto not found, new connec"
                      "tion closed by RakNet before we could create a replicator",
        a5: 155,
        a6: 1,
        0,
        v121);
    }
    v64 = v127[1]; /*0x1068812ca*/
    if ( v127[1] != nullptr /*0x1068812e6*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v127[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v64 + 16LL))(a1: v64); /*0x1068812ee*/
      std::__shared_weak_count::__release_weak(this: v64); /*0x1068812f4*/
    }
    v65 = v141[1]; /*0x1068812f9*/
    v4 = v133; /*0x106881303*/
    if ( v141[1] != nullptr /*0x10688131c*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v141[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v65 + 16LL))(a1: v65); /*0x106881324*/
      std::__shared_weak_count::__release_weak(this: v65); /*0x10688132a*/
    }
    v66 = v128[1]; /*0x10688132f*/
    if ( v128[1] != nullptr /*0x10688134b*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v128[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v66 + 16LL))(a1: v66); /*0x106881353*/
      std::__shared_weak_count::__release_weak(this: v66); /*0x106881359*/
    }
  }
  if ( FFlag::SeparateRakNetAndRbxTransportRouting != 1 )
  {
    v80 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::find<RakNet::SystemAddress>( /*0x106881422*/
            a1: (char *)this + 4648,
            a2);
    v69 = v80; /*0x106881427*/
    if ( v80 != 0 )
    {
      if ( (unsigned __int8)RBX::Network::shouldAttemptDecompression(
                              this: *(RBX::Network **)(v80 + 48),
                              a2: a2[7],
                              a3: (unsigned __int8 *)*((unsigned int *)a2 + 12),
                              a4: v81) != 0 )
      {
        if ( FFlag::AddHashToCompressionFlaggedCheck == 1 )
        {
          v82 = RBX::NetworkBase::ConnectionInternal::decompressPacket( /*0x10688145e*/
                  a1: *(_QWORD *)(*(_QWORD *)(v69 + 48) + 280LL),
                  a2);
          if ( v82 != 0 )
          {
            v83 = v82; /*0x106881467*/
            v84 = RBX::NetworkBase::decompressionResultToErrorMessage(a1: v82); /*0x10688146e*/
            std::string::basic_string[abi:ne200100]<0>(a1: v140, a2: v84, a3: v85, a4: v86); /*0x10688147d*/
            if ( (v140[0] & 1) != 0 ) /*0x106881489*/
              LODWORD(v90) = v140[4]; /*0x10688148f*/
            else
              v90 = (char *)v140 + 1; /*0x1068815ec*/
            RBX::CreatorLog::printf(
              a1: 3,
              a2: (unsigned int)"Server::OnReceive error while trying to decompress packet: %s",
              a3: (_DWORD)v90,
              a4: v87,
              a5: v88,
              a6: v89);
            if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
              FLog::FastLogSafeFormatted<std::string &>(
                a1: FLog::Network,
                a2: qword_10D7BBAA8,
                a3: 3,
                a4: (int)"[FLog::Network] Error decompressing packet in Server::OnReceive: {}",
                a5: 67,
                a6: (unsigned __int8 *)v140);
            v103 = *(_QWORD **)(v69 + 48); /*0x106881648*/
            v104 = RBX::NetworkBase::decompressionResultToErrorType(a1: v83); /*0x10688164f*/
            std::string::basic_string[abi:ne200100]<0>(a1: &v129, a2: v104, a3: v105, a4: v106); /*0x10688165e*/
            RBX::Network::Replicator::logPacketError( /*0x10688167d*/
              a1: v103,
              (__int64)a2,
              a3: (unsigned __int8 *)&v129,
              a4: (__int64)v140,
              a5: -1);
            if ( (v129 & 1) != 0 ) /*0x106881689*/
              operator delete(a1: (void *)v130); /*0x106881692*/
            v107 = *(_QWORD *)(v69 + 48); /*0x106881697*/
            LOBYTE(v116[0]) = 0; /*0x1068816a4*/
            v117[0] = 0; /*0x1068816a6*/
            RBX::Network::Replicator::requestDisconnectWithSignal(a1: v107, a2: 0x104u, a3: v116); /*0x1068816ae*/
            RBX::Network::Server::OnReceive(a1: v117, a2: v140, a3: v116, a4: &v140[4]); /*0x1068816cf*/
            goto LABEL_109; /*0x1068816d4*/
          }
        }
        else
        {
          RBX::NetworkBase::ConnectionInternal::decompressPacket_deprecated(a1: a2); /*0x1068814a8*/
        }
      }
      if ( FFlag::RefactorIngressFlow == 1 ) /*0x1068814b7*/
      {
        RBX::Network::IncomingPacket::IncomingPacket(a1: v140, a2); /*0x1068814c3*/
        v92 = *(_QWORD *)(v69 + 48); /*0x1068814c8*/
        qmemcpy(v134, v140, sizeof(v134)); /*0x1068814de*/
        std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1068814f2*/
          a1: v135,
          a2: v141,
          a3: v93,
          a4: v94,
          a5: v95,
          a6: v96);
        v91 = (*(__int64 (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v92 + 712LL))(a1: v92, a2: v134); /*0x10688150a*/
        if ( v136[88] != 1 ) /*0x106881513*/
          goto LABEL_94; /*0x106881513*/
        v97 = (RBX::RbxTransport::NetStreamBuffer *)v136; /*0x106881519*/
        goto LABEL_93; /*0x106881520*/
      }
LABEL_96:
      v91 = (*(__int64 (__fastcall **)(_QWORD, RBX::Network::Replicator **))(**(_QWORD **)(v69 + 48) + 704LL))( /*0x1068815d5*/
              a1: *(_QWORD *)(v69 + 48),
              a2);
      goto LABEL_110; /*0x1068815e7*/
    }
LABEL_83:
    v91 = 1; /*0x10688149b*/
    goto LABEL_110; /*0x1068814a0*/
  }
  v67 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::find<RakNet::SystemAddress>( /*0x106881375*/
          a1: (char *)this + 4688,
          a2);
  v69 = v67; /*0x10688137a*/
  if ( v67 == 0 ) /*0x106881380*/
    goto LABEL_83; /*0x106881380*/
  if ( RBX::Network::Server::acceptRakNetIngressRoute( /*0x106881397*/
         this,
         a2: *(const RBX::Network::Replicator **)(v67 + 48),
         a3: (const RakNet::SystemAddress *)a2) == 0 )
  {
LABEL_109:
    v91 = 0; /*0x1068817c1*/
    goto LABEL_110; /*0x1068817c1*/
  }
  if ( (unsigned __int8)RBX::Network::shouldAttemptDecompression(
                          this: *(RBX::Network **)(v69 + 48),
                          a2: a2[7],
                          a3: (unsigned __int8 *)*((unsigned int *)a2 + 12),
                          a4: v70) != 0 )
  {
    if ( FFlag::AddHashToCompressionFlaggedCheck == 1 )
    {
      v71 = RBX::NetworkBase::ConnectionInternal::decompressPacket(a1: *(_QWORD *)(*(_QWORD *)(v69 + 48) + 280LL), a2); /*0x1068813d4*/
      if ( v71 != 0 )
      {
        v72 = v71; /*0x1068813e1*/
        v73 = RBX::NetworkBase::decompressionResultToErrorMessage(a1: v71); /*0x1068813e8*/
        std::string::basic_string[abi:ne200100]<0>(a1: v140, a2: v73, a3: v74, a4: v75); /*0x1068813f7*/
        if ( (v140[0] & 1) != 0 ) /*0x106881403*/
          LODWORD(v79) = v140[4]; /*0x106881409*/
        else
          v79 = (char *)v140 + 1; /*0x1068816d9*/
        RBX::CreatorLog::printf(
          a1: 3,
          a2: (unsigned int)"Server::OnReceive error while trying to decompress packet: %s",
          a3: (_DWORD)v79,
          a4: v76,
          a5: v77,
          a6: v78);
        if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
          FLog::FastLogSafeFormatted<std::string &>(
            a1: FLog::Network,
            a2: qword_10D7BBAA8,
            a3: 3,
            a4: (int)"[FLog::Network] Error decompressing packet in Server::OnReceive: {}",
            a5: 67,
            a6: (unsigned __int8 *)v140);
        v108 = *(_QWORD **)(v69 + 48); /*0x106881735*/
        v109 = RBX::NetworkBase::decompressionResultToErrorType(a1: v72); /*0x10688173c*/
        std::string::basic_string[abi:ne200100]<0>(a1: &v129, a2: v109, a3: v110, a4: v111); /*0x10688174b*/
        RBX::Network::Replicator::logPacketError( /*0x10688176a*/
          a1: v108,
          (__int64)a2,
          a3: (unsigned __int8 *)&v129,
          a4: (__int64)v140,
          a5: -1);
        if ( (v129 & 1) != 0 ) /*0x106881776*/
          operator delete(a1: (void *)v130); /*0x10688177f*/
        v112 = *(_QWORD *)(v69 + 48); /*0x106881784*/
        LOBYTE(v114[0]) = 0; /*0x106881791*/
        v115[0] = 0; /*0x106881793*/
        RBX::Network::Replicator::requestDisconnectWithSignal(a1: v112, a2: 0x104u, a3: v114); /*0x10688179b*/
        RBX::Network::Server::OnReceive(a1: v115, a2: v140, a3: v114, a4: &v140[4]); /*0x1068817bc*/
        goto LABEL_109; /*0x1068817bc*/
      }
    }
    else
    {
      RBX::NetworkBase::ConnectionInternal::decompressPacket_deprecated(a1: a2); /*0x10688153d*/
    }
  }
  if ( FFlag::RefactorIngressFlow != 1 ) /*0x10688154c*/
    goto LABEL_96; /*0x10688154c*/
  RBX::Network::IncomingPacket::IncomingPacket(a1: v140, a2); /*0x10688155c*/
  v98 = *(_QWORD *)(v69 + 48); /*0x106881561*/
  qmemcpy(v137, v140, sizeof(v137)); /*0x106881577*/
  std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x10688158b*/
    a1: v138,
    a2: v141,
    a3: v99,
    a4: v100,
    a5: v101,
    a6: v102);
  v91 = (*(__int64 (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v98 + 712LL))(a1: v98, a2: v137); /*0x1068815a3*/
  if ( v139[88] == 1 ) /*0x1068815ac*/
  {
    v97 = (RBX::RbxTransport::NetStreamBuffer *)v139; /*0x1068815ae*/
LABEL_93:
    RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: v97); /*0x1068815b5*/
  }
LABEL_94:
  if ( v143 == 1 ) /*0x1068815be*/
    RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)&v141[1]); /*0x1068815cb*/
LABEL_110:
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v4, a2: v68); /*0x1068817c3*/
  return v91; /*0x1068817dd*/
}

// Address: 0x106881f98 | Name: __ZThn176_N3RBX7Network6Server9OnReceiveEPN6RakNet6PacketE
__int64 __fastcall `non-virtual thunk to'RBX::Network::Server::OnReceive(__int64 a1, RBX::Network::Replicator **a2)
{
  return RBX::Network::Server::OnReceive(this: (RBX::Network::Server *)(a1 - 176), a2); /*0x106881fa3*/
}

// Address: 0x106881faa | Name: __ZN3RBX7Network6Server20handleExtAntiCheatV2EPNS_11NetworkBase18ConnectionInternalERNS0_14IncomingPacketENSt3__110shared_ptrINS_8Security21ExternalAntiCheatDataEEExPKcSD_
void __fastcall RBX::Network::Server::handleExtAntiCheatV2(
        RBX::Network::Peer *this,
        RBX::NetworkBase::ConnectionInternal *a2,
        RBX::Network::IncomingPacket *a3,
        int a4,
        __int64 a5,
        __int64 a6,
        __int64 a7)
{
  __int64 v11; // r13
  __int64 v12; // rdx
  __int64 v13; // rcx
  int v14; // r13d
  RakNet::SystemAddress *RakNetPacket; // rax
  __int64 v16; // [rsp+8h] [rbp-78h] BYREF
  void *v17[4]; // [rsp+10h] [rbp-70h] BYREF
  void *v18[3]; // [rsp+30h] [rbp-50h] BYREF
  __int64 v19; // [rsp+48h] [rbp-38h] BYREF
  unsigned int v20; // [rsp+50h] [rbp-30h] BYREF
  _BYTE v21[41]; // [rsp+57h] [rbp-29h] BYREF

  v11 = a7; /*0x106881fc7*/
  v19 = a5; /*0x106881fcb*/
  v16 = a6; /*0x106881fcf*/
  memset(v17, 0, 24); /*0x106881fda*/
  RBX::Network::Peer::recvExtAntiCheatHelperV2(a1: this, a2: a3, a3: v21, a4: &v20, a5: v17); /*0x106881ff1*/
  if ( v21[0] == 0 ) /*0x106881ffa*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v18, a2: v11, a3: v12, a4: v13); /*0x106882007*/
    rbx::signal<void ()(std::vector<unsigned char>,long long,std::string const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x10688201f*/
      a1: (char *)this + 5008,
      a2: v17,
      a3: &v19,
      a4: v18);
    if ( ((__int64)v18[0] & 1) != 0 ) /*0x106882028*/
      operator delete(a1: v18[2]); /*0x10688202e*/
    if ( RBX::serverExtAntiCheatSignal != 0 && RBX::Network::IncomingPacket::getRakNetPacket(this: a3) != 0 ) /*0x10688204c*/
    {
      v14 = RBX::serverExtAntiCheatSignal; /*0x10688204e*/
      RakNetPacket = (RakNet::SystemAddress *)RBX::Network::IncomingPacket::getRakNetPacket(this: a3); /*0x106882055*/
      v18[0] = (void *)RakNet::SystemAddress::GetBinaryAddress(this: RakNetPacket); /*0x106882062*/
      rbx::signal<void ()(std::vector<unsigned char> const&,std::shared_ptr<RBX::Security::ExternalAntiCheatData>,long long,char const*,char const*,unsigned long)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x106882084*/
        a1: v14,
        a2: (unsigned int)v17,
        a3: a4,
        a4: (unsigned int)&v19,
        a5: (unsigned int)&v16,
        a6: (unsigned int)&a7,
        a7: (__int64)v18);
    }
    RBX::Network::Peer::sendExtAntiCheatAckHelperV2(this, a2, a3: v20); /*0x106882092*/
  }
  if ( v17[0] != nullptr ) /*0x10688209e*/
  {
    v17[1] = v17[0]; /*0x1068820a0*/
    operator delete(a1: v17[0]); /*0x1068820a4*/
  }
}

// Address: 0x1068820ee | Name: __ZN3RBX7Network6Server29handleExtAntiCheat_deprecatedEPN6RakNet6PacketENSt3__110shared_ptrINS_8Security21ExternalAntiCheatDataEEExPKcSB_RKNS2_13SystemAddressE
void __fastcall RBX::Network::Server::handleExtAntiCheat_deprecated(
        __int64 a1,
        __int64 a2,
        int a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        RakNet::SystemAddress *a7)
{
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // rdx
  __int64 v13; // rcx
  __int64 v14; // r8
  __int64 v15; // r9
  int v16; // r13d
  __int128 v17; // xmm0
  __int64 v18; // [rsp+20h] [rbp-90h] BYREF
  __int64 v19; // [rsp+28h] [rbp-88h] BYREF
  void *v20[4]; // [rsp+30h] [rbp-80h] BYREF
  __int128 v21; // [rsp+50h] [rbp-60h] BYREF
  void *v22[2]; // [rsp+60h] [rbp-50h]
  __int64 v23; // [rsp+78h] [rbp-38h] BYREF
  unsigned int v24; // [rsp+80h] [rbp-30h] BYREF
  _BYTE v25[41]; // [rsp+87h] [rbp-29h] BYREF

  v23 = a4; /*0x10688210b*/
  v18 = a5; /*0x10688210f*/
  v19 = a6; /*0x106882116*/
  memset(v20, 0, 24); /*0x106882124*/
  RBX::Network::Peer::recvExtAntiCheatHelper_deprecated(a1, a2, a3: v25, a4: &v24, a5: v20); /*0x106882138*/
  if ( v25[0] == 0 ) /*0x106882141*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v21, a2: a6, a3: v10, a4: v11); /*0x10688214e*/
    rbx::signal<void ()(std::vector<unsigned char>,long long,std::string const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x106882169*/
      a1: a1 + 5008,
      a2: v20,
      a3: &v23,
      a4: &v21);
    if ( (v21 & 1) != 0 ) /*0x106882172*/
      operator delete(a1: v22[0]); /*0x106882178*/
    v16 = RBX::serverExtAntiCheatSignal; /*0x106882188*/
    if ( RBX::serverExtAntiCheatSignal != 0 ) /*0x10688218e*/
    {
      *(_QWORD *)&v21 = RakNet::SystemAddress::GetBinaryAddress(this: a7); /*0x106882198*/
      rbx::signal<void ()(std::vector<unsigned char> const&,std::shared_ptr<RBX::Security::ExternalAntiCheatData>,long long,char const*,char const*,unsigned long)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x1068821bc*/
        a1: v16,
        a2: (unsigned int)v20,
        a3,
        a4: (unsigned int)&v23,
        a5: (unsigned int)&v18,
        a6: (unsigned int)&v19,
        a7: (__int64)&v21);
    }
    v17 = *(_OWORD *)a7; /*0x1068821c1*/
    *(_OWORD *)v22 = *((_OWORD *)a7 + 1); /*0x1068821cc*/
    v21 = v17; /*0x1068821d0*/
    RBX::Network::Peer::sendExtAntiCheatAckHelper( /*0x1068821eb*/
      a1,
      a2: v24,
      a3: v12,
      a4: v13,
      a5: v14,
      a6: v15,
      a7: v17,
      a8: *((_QWORD *)&v17 + 1),
      a9: v22[0],
      a10: v22[1]);
  }
  if ( v20[0] != nullptr ) /*0x1068821f7*/
  {
    v20[1] = v20[0]; /*0x1068821f9*/
    operator delete(a1: v20[0]); /*0x1068821fd*/
  }
}

// Address: 0x10688224a | Name: __ZN3RBX7Network6Server16sendExtAntiCheatENSt3__18weak_ptrINS_9DataModelEEExRKNS2_6vectorIhNS2_9allocatorIhEEEE
__int64 __fastcall RBX::Network::Server::sendExtAntiCheat(__int64 *a1, __int64 a2, _QWORD *a3)
{
  std::__shared_weak_count *v4; // rdi
  volatile signed __int64 *v7; // rax
  volatile signed __int64 *v8; // rbx
  __int64 v9; // r14
  __int64 v10; // r15
  __int64 v11; // rsi
  __int64 v12; // rax
  void *v14[3]; // [rsp+18h] [rbp-78h] BYREF
  _BYTE v15[32]; // [rsp+30h] [rbp-60h] BYREF
  _BYTE *v16; // [rsp+50h] [rbp-40h]

  v4 = (std::__shared_weak_count *)a1[1]; /*0x10688226a*/
  if ( v4 == nullptr ) /*0x106882271*/
    return __stack_chk_guard; /*0x106882271*/
  v7 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v4); /*0x10688227d*/
  if ( v7 == nullptr ) /*0x10688228c*/
    return __stack_chk_guard; /*0x10688228c*/
  v8 = v7; /*0x106882292*/
  v9 = *a1; /*0x106882295*/
  if ( v9 != 0 ) /*0x1068822a2*/
  {
    memset(v14, 0, sizeof(v14)); /*0x1068822b3*/
    std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1068822cb*/
      a1: v14,
      a2: *a3,
      a3: a3[1],
      a4: a3[1] - *a3);
    v16 = nullptr; /*0x1068822d0*/
    v10 = operator new(a1: 0x28u); /*0x1068822e2*/
    *(_QWORD *)v10 = &off_10CAAEEF0; /*0x1068822ec*/
    *(_QWORD *)(v10 + 8) = a2; /*0x1068822f3*/
    *(_OWORD *)(v10 + 16) = 0; /*0x106882301*/
    *(_QWORD *)(v10 + 32) = 0; /*0x106882306*/
    std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x10688231c*/
      a1: v10 + 16,
      a2: v14[0],
      a3: v14[1],
      a4: (char *)v14[1] - (char *)v14[0]);
    v16 = (_BYTE *)v10; /*0x106882325*/
    RBX::DataModel::submitTask(a1: v9, a2: v15, a3: 1); /*0x106882335*/
    if ( v16 == v15 ) /*0x106882341*/
    {
      v12 = 32; /*0x10688234f*/
    }
    else
    {
      v12 = 40; /*0x106882343*/
      if ( v16 == nullptr ) /*0x10688234b*/
      {
LABEL_9:
        if ( v14[0] != nullptr ) /*0x106882361*/
        {
          v14[1] = v14[0]; /*0x106882363*/
          operator delete(a1: v14[0]); /*0x106882367*/
        }
        goto LABEL_11; /*0x106882367*/
      }
    }
    (*(void (__fastcall **)(_BYTE *, __int64))(*(_QWORD *)v16 + v12))(a1: v16, a2: v11); /*0x106882357*/
    goto LABEL_9; /*0x106882357*/
  }
LABEL_11:
  if ( _InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10688237c*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v8 + 16))(a1: v8); /*0x106882384*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v8); /*0x10688238a*/
  }
  return __stack_chk_guard; /*0x10688239f*/
}

// Address: 0x106882410 | Name: __ZN3RBX7Network6Server16sendExtAntiCheatExRKNSt3__16vectorIhNS2_9allocatorIhEEEE
_QWORD *__fastcall RBX::Network::Server::sendExtAntiCheat(__int64 a1, unsigned __int64 a2, int a3)
{
  int v4; // r14d
  int v5; // ecx
  int v6; // r8d
  int v7; // r9d
  _QWORD *result; // rax
  std::__shared_weak_count *v9; // rbx
  _QWORD *v10; // [rsp+28h] [rbp-28h] BYREF
  std::__shared_weak_count *v11; // [rsp+30h] [rbp-20h]

  v4 = a1; /*0x106882423*/
  RBX::Network::Server::getServerReplicatorForPlayerId(this: (RBX::Network::Server *)&v10, a2: a1, a3: a2); /*0x106882430*/
  result = v10; /*0x106882435*/
  if ( v10 != nullptr ) /*0x10688243b*/
    result = (_QWORD *)RBX::Network::Peer::sendExtAntiCheatHelper( /*0x10688245c*/
                         a1: v4,
                         a2: a3,
                         a3: 0,
                         a4: v5,
                         a5: v6,
                         a6: v7,
                         v10[30],
                         v10[31],
                         v10[32],
                         v10[33]);
  v9 = v11; /*0x106882461*/
  if ( v11 != nullptr ) /*0x106882468*/
  {
    result = (_QWORD *)_InterlockedExchangeAdd64((volatile signed __int64 *)v11 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x106882471*/
    if ( result == nullptr ) /*0x10688247a*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x10688248d*/
      return (_QWORD *)std::__shared_weak_count::__release_weak(this: v9); /*0x10688249d*/
    }
  }
  return result; /*0x10688247c*/
}

// Address: 0x1068824b6 | Name: __ZN3RBX7Network6Server21decrementDynIpScalingEv
void __fastcall RBX::Network::Server::decrementDynIpScaling(RBX::Network::Server *this)
{
  ; /*0x1068824b6*/
}

// Address: 0x1068824bc | Name: __ZN3RBX7Network6Server16getDynIpRangeMaxEv
__int64 __fastcall RBX::Network::Server::getDynIpRangeMax(RBX::Network::Server *this)
{
  return 0; /*0x1068824c2*/
}

// Address: 0x1068824c4 | Name: __ZNK3RBX7Network6Server20isLegalReceiveObjectEPKNS_6ObjectE
__int64 __fastcall RBX::Network::Server::isLegalReceiveObject(RBX::Network::Server *this, const RBX::Object *a2)
{
  return RBX::Network::Server::isScriptLegal(this, a2); /*0x1068824c8*/
}

// Address: 0x1068824ce | Name: __ZNK3RBX7Network6Server13isScriptLegalEPKNS_6ObjectE
__int64 __fastcall RBX::Network::Server::isScriptLegal(RBX::Network::Server *this, const RBX::Object *a2)
{
  const RBX::Object *v2; // r14
  __int64 v4; // r15
  __int64 v5; // rax
  __int64 v6; // rdi
  __int64 v7; // rsi
  __int64 v8; // r15
  __int64 v9; // rax
  __int64 v10; // r15
  __int64 v11; // rax
  RBX::ContentId *ScriptId; // rax
  RBX::ContentId *v13; // rax
  RBX::ContentId *v14; // rax
  _BYTE v16[8]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v17[16]; // [rsp+8h] [rbp-48h] BYREF
  _BYTE v18[8]; // [rsp+18h] [rbp-38h] BYREF
  _BYTE v19[16]; // [rsp+20h] [rbp-30h] BYREF
  char v20; // [rsp+30h] [rbp-20h]

  if ( a2 == nullptr ) /*0x1068824de*/
    goto LABEL_5; /*0x1068824de*/
  v2 = a2; /*0x1068824e0*/
  v4 = *((_QWORD *)a2 + 3); /*0x1068824e6*/
  v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::Script>(); /*0x1068824ea*/
  if ( *(unsigned __int16 *)(v4 + 440) - (unsigned int)*(unsigned __int16 *)(v5 + 440) <= *(unsigned __int16 *)(v5 + 442) ) /*0x106882509*/
  {
    ScriptId = (RBX::ContentId *)RBX::LuaSourceContainer::getScriptId(this: v2); /*0x106882568*/
    if ( (unsigned __int16)RBX::ContentId::getType(this: ScriptId) == 2 ) /*0x106882579*/
    {
      v2 = (const RBX::Object *)((char *)v2 + 376); /*0x10688257f*/
LABEL_14:
      RBX::ProtectedString::ProtectedString(this: (RBX::ProtectedString *)v18, a2: v2); /*0x106882607*/
      v20 = 1; /*0x106882613*/
      goto LABEL_15; /*0x106882613*/
    }
LABEL_13:
    v2 = (const RBX::Object *)((char *)v2 + 184); /*0x106882600*/
    goto LABEL_14; /*0x106882600*/
  }
  v8 = *((_QWORD *)v2 + 3); /*0x10688250b*/
  v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::ModuleScript>(a1: v6, a2: v7); /*0x10688250f*/
  if ( *(unsigned __int16 *)(v8 + 440) - (unsigned int)*(unsigned __int16 *)(v9 + 440) <= *(unsigned __int16 *)(v9 + 442) ) /*0x10688252e*/
  {
    v13 = (RBX::ContentId *)RBX::LuaSourceContainer::getScriptId(this: v2); /*0x10688258b*/
    if ( (unsigned __int16)RBX::ContentId::getType(this: v13) == 2 ) /*0x10688259c*/
    {
      v2 = (const RBX::Object *)((char *)v2 + 288); /*0x10688259e*/
      goto LABEL_14; /*0x1068825a5*/
    }
    goto LABEL_13; /*0x10688259c*/
  }
  v10 = *((_QWORD *)v2 + 3); /*0x106882530*/
  v11 = RBX::Reflection::Class_getDescriptorPtr<RBX::AuroraScript>(); /*0x106882534*/
  if ( *(unsigned __int16 *)(v10 + 440) - (unsigned int)*(unsigned __int16 *)(v11 + 440) > *(unsigned __int16 *)(v11 + 442) ) /*0x106882553*/
  {
LABEL_5:
    v18[0] = 0; /*0x106882555*/
    v20 = 0; /*0x10688255a*/
    LOBYTE(v2) = 1; /*0x10688255d*/
    goto LABEL_16; /*0x106882560*/
  }
  v14 = (RBX::ContentId *)RBX::LuaSourceContainer::getScriptId(this: v2); /*0x1068825aa*/
  if ( (unsigned __int16)RBX::ContentId::getType(this: v14) != 2 ) /*0x1068825bb*/
    goto LABEL_13; /*0x1068825bb*/
  v2 = (const RBX::Object *)((char *)v2 + 256); /*0x1068825bd*/
  RBX::ProtectedString::ProtectedString(this: (RBX::ProtectedString *)v16, a2: v2); /*0x1068825ce*/
  RBX::ProtectedString::ProtectedString(a1: v18, a2: v16); /*0x1068825da*/
  v20 = 1; /*0x1068825df*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v17); /*0x1068825e7*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v16); /*0x1068825f0*/
  LOBYTE(v2) = 1; /*0x1068825f5*/
  if ( (v20 & 1) != 0 ) /*0x1068825fc*/
LABEL_15:
    LOBYTE(v2) = boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,std::pair<int,int>>>,RBX::SharedString,std::pair<int,int>,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::find_node( /*0x106882617*/
                   a1: (unsigned __int8 *)this + 4536,
                   a2: (RBX *)v18) != 0;
LABEL_16:
  if ( v20 == 1 ) /*0x106882635*/
  {
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v19); /*0x10688263b*/
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v18); /*0x106882644*/
  }
  return (unsigned int)v2; /*0x10688264c*/
}

// Address: 0x106882682 | Name: __ZNK3RBX7Network6Server29getScriptIndexForSharedSourceERKNS_12SharedStringE
__int64 __fastcall RBX::Network::Server::getScriptIndexForSharedSource(
        RBX::Network::Server *this,
        const RBX::SharedString *a2)
{
  __int64 node; // rax

  node = boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,std::pair<int,int>>>,RBX::SharedString,std::pair<int,int>,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::find_node( /*0x10688268d*/
           a1: (unsigned __int8 *)this + 4536,
           a2);
  if ( node != 0 ) /*0x106882695*/
    return *(unsigned int *)(node + 24) | 0x100000000LL; /*0x10688269a*/
  else
    return 0; /*0x1068826a1*/
}

// Address: 0x1068826a6 | Name: __ZNK3RBX7Network6Server31getScriptCompileTargetForSourceERKNS_12SharedStringE
__int64 __fastcall RBX::Network::Server::getScriptCompileTargetForSource(
        RBX::Network::Server *this,
        const RBX::SharedString *a2)
{
  __int64 node; // rax

  node = boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,std::pair<int,int>>>,RBX::SharedString,std::pair<int,int>,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::find_node( /*0x1068826b1*/
           a1: (unsigned __int8 *)this + 4536,
           a2);
  if ( node != 0 ) /*0x1068826b9*/
    return *(unsigned int *)(node + 28) | 0x100000000LL; /*0x1068826be*/
  else
    return 0; /*0x1068826c5*/
}

// Address: 0x1068826ca | Name: __ZNK3RBX7Network6Server23getScriptSourceForIndexEi
RBX::Network::Server *__fastcall RBX::Network::Server::getScriptSourceForIndex(
        RBX::Network::Server *this,
        __int64 a2,
        int a3)
{
  __int64 v5; // rsi
  _BYTE v7[8]; // [rsp+8h] [rbp-28h] BYREF
  _BYTE v8[32]; // [rsp+10h] [rbp-20h] BYREF

  v5 = *(_QWORD *)(a2 + 4512); /*0x1068826de*/
  if ( (*(_QWORD *)(a2 + 4520) - v5) >> 4 <= (unsigned __int64)a3 ) /*0x1068826f6*/
  {
    *(_BYTE *)this = 0; /*0x106882730*/
    *((_BYTE *)this + 24) = 0; /*0x106882732*/
  }
  else
  {
    RBX::ProtectedString::fromTrustedSharedSource( /*0x106882706*/
      this: (RBX::ProtectedString *)v7,
      a2: (const RBX::SharedString *)(16LL * a3 + v5));
    RBX::ProtectedString::ProtectedString(a1: this, a2: v7); /*0x106882711*/
    *((_BYTE *)this + 24) = 1; /*0x106882716*/
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v8); /*0x10688271e*/
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v7); /*0x106882727*/
  }
  return this; /*0x106882738*/
}

// Address: 0x10688275e | Name: __ZNK3RBX7Network6Server25getScriptBytecodeForIndexEi
RBX::Network::Server *__fastcall RBX::Network::Server::getScriptBytecodeForIndex(
        RBX::Network::Server *this,
        __int64 a2,
        int a3)
{
  __int64 v4; // rcx
  __int64 Contents; // rax
  char v6; // al

  v4 = *(_QWORD *)(a2 + 4512); /*0x10688276a*/
  if ( (*(_QWORD *)(a2 + 4520) - v4) >> 4 <= (unsigned __int64)a3 ) /*0x106882782*/
  {
    *(_BYTE *)this = 0; /*0x1068827aa*/
    v6 = 0; /*0x1068827ad*/
  }
  else
  {
    Contents = RBX::SharedString::getContents(this: (RBX::SharedString *)(v4 + 16LL * a3 + 8)); /*0x106882790*/
    if ( (*(_BYTE *)Contents & 1) != 0 ) /*0x106882798*/
    {
      std::string::__init_copy_ctor_external(a1: this, a2: *(_QWORD *)(Contents + 16), a3: *(_QWORD *)(Contents + 8)); /*0x1068827bc*/
    }
    else
    {
      *((_QWORD *)this + 2) = *(_QWORD *)(Contents + 16); /*0x10688279e*/
      *(_OWORD *)this = *(_OWORD *)Contents; /*0x1068827a5*/
    }
    v6 = 1; /*0x1068827c1*/
  }
  *((_BYTE *)this + 24) = v6; /*0x1068827c3*/
  return this; /*0x1068827cd*/
}

// Address: 0x1068827d0 | Name: __ZNK3RBX7Network6Server31getSharedScriptBytecodeForIndexEi
RBX::Network::Server *__fastcall RBX::Network::Server::getSharedScriptBytecodeForIndex(
        RBX::Network::Server *this,
        __int64 a2,
        int a3)
{
  __int64 v4; // rcx
  char v5; // al

  v4 = *(_QWORD *)(a2 + 4512); /*0x1068827dc*/
  if ( (*(_QWORD *)(a2 + 4520) - v4) >> 4 <= (unsigned __int64)a3 ) /*0x1068827f4*/
  {
    *(_BYTE *)this = 0; /*0x10688280e*/
    v5 = 0; /*0x106882811*/
  }
  else
  {
    RBX::Flyweight<RBX::SharedString::Data,void,true>::Flyweight(a1: this, a2: v4 + 16LL * a3 + 8); /*0x106882805*/
    v5 = 1; /*0x10688280a*/
  }
  *((_BYTE *)this + 8) = v5; /*0x106882813*/
  return this; /*0x10688281d*/
}

// Address: 0x106882878 | Name: __ZN3RBX7Network6Server18getDynLuaChallengeERNSt3__18optionalINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEE
void __fastcall RBX::Network::Server::getDynLuaChallenge(__int64 a1, __int64 a2)
{
  int v2; // edx
  _BYTE v4[16]; // [rsp+0h] [rbp-30h] BYREF
  void *v5; // [rsp+10h] [rbp-20h]
  char v6; // [rsp+18h] [rbp-18h]

  v2 = *(_DWORD *)(a1 + 4832); /*0x106882883*/
  if ( v2 >= 0 ) /*0x10688288b*/
  {
    RBX::Network::Server::getScriptBytecodeForIndex(this: (RBX::Network::Server *)v4, a2: a1, a3: v2); /*0x10688289a*/
    std::optional<std::string>::operator=[abi:ne200100]<std::string,void>(a1: a2, a2: v4); /*0x1068828a5*/
    if ( v6 == 1 && (v4[0] & 1) != 0 ) /*0x1068828b4*/
      operator delete(a1: v5); /*0x1068828ba*/
  }
}

// Address: 0x1068828e4 | Name: __ZN3RBX7Network6Server34emergencyUnregisterDynLuaChallengeEv
void __fastcall RBX::Network::Server::emergencyUnregisterDynLuaChallenge(RBX::Network::Server *this)
{
  *((_DWORD *)this + 1208) = -1; /*0x1068828e8*/
}

// Address: 0x1068828f4 | Name: __ZN3RBX7Network6Server35registerServerReplicatorForPlayerIdExONSt3__18weak_ptrINS0_16ServerReplicatorEEE
_QWORD *__fastcall RBX::Network::Server::registerServerReplicatorForPlayerId(__int64 a1, __int64 a2, __int128 *a3)
{
  _QWORD *result; // rax
  __int128 v5; // xmm0
  __int64 v6; // rcx
  std::__shared_weak_count *v7; // rdi
  __int64 v8; // [rsp+0h] [rbp-10h] BYREF

  v8 = a2; /*0x106882901*/
  result = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<long long const,std::weak_ptr<RBX::Network::ServerReplicator>>>,long long,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<long long>,std::equal_to<long long>>>::operator[]( /*0x10688290e*/
             a1: (_QWORD *)(a1 + 4728),
             a2: &v8);
  v5 = *a3; /*0x106882913*/
  v6 = *((_QWORD *)a3 + 1); /*0x106882916*/
  if ( v6 != 0 ) /*0x10688291d*/
    _InterlockedIncrement64((volatile signed __int64 *)(v6 + 16)); /*0x10688291f*/
  v7 = (std::__shared_weak_count *)result[2]; /*0x106882924*/
  *(_OWORD *)(result + 1) = v5; /*0x106882928*/
  if ( v7 != nullptr ) /*0x10688292f*/
    return (_QWORD *)std::__shared_weak_count::__release_weak(this: v7); /*0x106882931*/
  return result; /*0x10688293a*/
}

// Address: 0x10688293e | Name: __ZN3RBX7Network6Server37unregisterServerReplicatorForPlayerIdExRKNSt3__110shared_ptrINS0_16ServerReplicatorEEE
_QWORD *__fastcall RBX::Network::Server::unregisterServerReplicatorForPlayerId(
        __int64 a1,
        unsigned __int64 a2,
        _QWORD *a3)
{
  __int64 v4; // rbx
  _QWORD *result; // rax
  _QWORD **v6; // r14
  std::__shared_weak_count *v7; // rdi
  std::__shared_weak_count *v8; // r12
  _QWORD *v9; // r13
  _QWORD *v10; // r15
  unsigned __int64 v11[6]; // [rsp+0h] [rbp-30h] BYREF

  v11[0] = a2; /*0x106882953*/
  v4 = a1 + 4728; /*0x106882956*/
  result = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<long long const,std::weak_ptr<RBX::Network::ServerReplicator>>>,long long,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<long long>,std::equal_to<long long>>>::find_node_impl<long long,std::equal_to<long long>>( /*0x106882972*/
             a1: (_QWORD *)(a1 + 4728),
             a2,
             a3: v11);
  if ( result != nullptr ) /*0x10688297a*/
  {
    v6 = (_QWORD **)result; /*0x10688297c*/
    v7 = (std::__shared_weak_count *)result[4]; /*0x10688297f*/
    if ( v7 == nullptr || (result = (_QWORD *)std::__shared_weak_count::lock(this: v7)) == nullptr ) /*0x106882990*/
    {
      if ( *a3 != 0 ) /*0x1068829cc*/
        return result; /*0x1068829cc*/
      return (_QWORD *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<long long const,std::weak_ptr<RBX::Network::ServerReplicator>>>,long long,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<long long>,std::equal_to<long long>>>::erase_nodes( /*0x1068829cc*/
                         a1: v4,
                         a2: v6,
                         a3: *v6);
    }
    v8 = (std::__shared_weak_count *)result; /*0x106882992*/
    v9 = v6[3]; /*0x106882995*/
    v10 = (_QWORD *)*a3; /*0x106882999*/
    result = (_QWORD *)_InterlockedExchangeAdd64(result + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x1068829a3*/
    if ( result == nullptr ) /*0x1068829ad*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x1068829b6*/
      result = (_QWORD *)std::__shared_weak_count::__release_weak(this: v8); /*0x1068829bc*/
    }
    if ( v9 == v10 ) /*0x1068829c4*/
      return (_QWORD *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<long long const,std::weak_ptr<RBX::Network::ServerReplicator>>>,long long,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<long long>,std::equal_to<long long>>>::erase_nodes( /*0x1068829ce*/
                         a1: v4,
                         a2: v6,
                         a3: *v6);
  }
  return result; /*0x1068829e0*/
}

// Address: 0x1068829ec | Name: __ZN3RBX7Network6Server22protocolVersionMatchesEi
bool __fastcall RBX::Network::Server::protocolVersionMatches(RBX::Network::Server *this, int a2)
{
  return (unsigned int)(a2 - 24) < 0xD; /*0x1068829f9*/
}

// Address: 0x1068829fc | Name: __ZN3RBX7Network6Server18getNetworkOwnerJobEv
__int64 __fastcall RBX::Network::Server::getNetworkOwnerJob(RBX::Network::Server *this)
{
  return *((_QWORD *)this + 63); /*0x106882a07*/
}

// Address: 0x106882a0a | Name: __ZN3RBX7Network6Server20getNetworkSchemaInfoENS_22EngineNetConfigurationE
_QWORD *__fastcall RBX::Network::Server::getNetworkSchemaInfo(_QWORD *a1, __int64 a2)
{
  __int64 v4; // rax
  __int64 v5; // rax
  __int64 v6; // r14
  std::__shared_weak_count *v7; // r15
  __int64 v8; // rax
  std::__shared_weak_count *v9; // r14
  __int128 v11; // [rsp+0h] [rbp-40h] BYREF
  std::__shared_weak_count *v12[2]; // [rsp+10h] [rbp-30h] BYREF

  v4 = *(_QWORD *)(a2 + 4792); /*0x106882a1f*/
  if ( v4 != 0 ) /*0x106882a29*/
  {
    *a1 = v4; /*0x106882a2b*/
    v5 = *(_QWORD *)(a2 + 4800); /*0x106882a2e*/
    a1[1] = v5; /*0x106882a35*/
    if ( v5 != 0 ) /*0x106882a3c*/
      _InterlockedIncrement64((volatile signed __int64 *)(v5 + 8)); /*0x106882a42*/
  }
  else
  {
    RBX::make_shared<RBX::Network::ServerSchemaInfo>(a1: v12); /*0x106882a56*/
    RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(a1: *(_DWORD *)(a2 + 536) == 2, a2: v12[0]); /*0x106882a77*/
    v6 = a2 + 4792; /*0x106882a7c*/
    v11 = *(_OWORD *)v12; /*0x106882a8b*/
    if ( v12[1] != nullptr ) /*0x106882a92*/
      _InterlockedIncrement64((volatile signed __int64 *)v12[1] + 1); /*0x106882a94*/
    std::shared_ptr<RBX::Network::ServerSchemaInfo const>::operator=[abi:ne200100](a1: v6, a2: &v11); /*0x106882aa3*/
    v7 = *((std::__shared_weak_count **)&v11 + 1); /*0x106882aa8*/
    if ( *((_QWORD *)&v11 + 1) != 0 /*0x106882ac1*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v11 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x106882ac9*/
      std::__shared_weak_count::__release_weak(this: v7); /*0x106882acf*/
    }
    v8 = *(_QWORD *)(v6 + 8); /*0x106882ad4*/
    *(_OWORD *)a1 = *(_OWORD *)v6; /*0x106882adc*/
    if ( v8 != 0 ) /*0x106882ae2*/
      _InterlockedIncrement64((volatile signed __int64 *)(v8 + 8)); /*0x106882ae4*/
    v9 = v12[1]; /*0x106882ae9*/
    if ( v12[1] != nullptr /*0x106882b02*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v12[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x106882b0a*/
      std::__shared_weak_count::__release_weak(this: v9); /*0x106882b10*/
    }
  }
  return a1; /*0x106882b18*/
}

// Address: 0x106882b80 | Name: __ZN3RBX7Network6Server17getMegaReplicatorEv
__int64 __fastcall RBX::Network::Server::getMegaReplicator(RBX::Network::Server *this)
{
  return (__int64)this + 544; /*0x106882b8b*/
}

// Address: 0x106882b8e | Name: __ZNK3RBX7Network6Server12askSetParentEPKNS_8InstanceE
__int64 __fastcall RBX::Network::Server::askSetParent(RBX::Network::Server *this, const RBX::Instance *a2)
{
  if ( (unsigned __int8)RBX::Service::askSetParent2(this: a2, a2) != 0 ) /*0x106882ba5*/
    return RBX::Instance::askSetParent(this, a2); /*0x106882bb1*/
  else
    return 0; /*0x106882bb6*/
}

// Address: 0x106882bbe | Name: __ZNK3RBX7Network6Server15verifySetParentEPKNS_8InstanceE
__int64 __fastcall RBX::Network::Server::verifySetParent(
        RBX::Network::Server *this,
        const RBX::Instance *a2,
        const RBX::Instance *a3)
{
  return RBX::Service::verifySetParent2(this, a2, a3); /*0x106882bc2*/
}

// Address: 0x106882bca | Name: __ZN3RBX7Network6Server46getDeltaAndUpdatePhysicsUnthrottledWorldStepIdEPNS_9DataModelE
__int64 __fastcall RBX::Network::Server::getDeltaAndUpdatePhysicsUnthrottledWorldStepId(
        RBX::Network::Server *this,
        RBX::DataModel *a2)
{
  int CurrentUnthrottledWorldStepId; // eax
  unsigned int v4; // ecx

  CurrentUnthrottledWorldStepId = RBX::WorldStats::getCurrentUnthrottledWorldStepId(this: a2, a2); /*0x106882bd6*/
  v4 = CurrentUnthrottledWorldStepId - *((_DWORD *)this + 1125); /*0x106882bdd*/
  *((_DWORD *)this + 1125) = CurrentUnthrottledWorldStepId; /*0x106882be3*/
  return v4; /*0x106882bef*/
}

// Address: 0x106882bf2 | Name: __ZN3RBX7Network6Server38getDeltaAndUpdatePhysicsReportWallTimeEPNS_9DataModelE
__int64 __fastcall RBX::Network::Server::getDeltaAndUpdatePhysicsReportWallTime(
        RBX::Network::Server *this,
        RBX::DataModel *a2)
{
  __int64 result; // rax

  result = RBX::ServiceProvider::find<RBX::RunService>(a1: (char *)a2 + 464, a2: 0); /*0x106882c04*/
  *((_QWORD *)this + 563) = *(_QWORD *)(result + 280); /*0x106882c1d*/
  return result; /*0x106882c29*/
}

// Address: 0x106882c2c | Name: __ZN3RBX7Network6Server17doDynLuaChallengeERdjj
__int64 __fastcall RBX::Network::Server::doDynLuaChallenge(RBX::Network::Server *this, double *a2, int a3, int a4)
{
  __int64 v7; // r12
  _QWORD *v8; // rbx
  __int64 v9; // rdi
  __int64 v10; // rbx
  __int64 v11; // rdi
  __int64 v12; // rdi
  volatile signed __int64 *v13; // r15
  double *v14; // rbx
  double v15; // r12
  _QWORD v17[5]; // [rsp+0h] [rbp-80h] BYREF
  __int64 v18; // [rsp+28h] [rbp-58h] BYREF
  std::__shared_weak_count *v19; // [rsp+30h] [rbp-50h]
  double *v20; // [rsp+38h] [rbp-48h]
  void **v21[8]; // [rsp+40h] [rbp-40h] BYREF

  if ( *((int *)this + 1208) < 0 ) /*0x106882c44*/
  {
    LODWORD(v14) = 0; /*0x106882d5b*/
  }
  else
  {
    v20 = a2; /*0x106882c52*/
    v7 = RBX::ServiceProvider::find<RBX::ScriptContext>(); /*0x106882c5b*/
    std::vector<RBX::Reflection::Variant>::vector[abi:ne200100](a1: v17, a2: 2); /*0x106882c6a*/
    *(double *)v21 = (double)a3; /*0x106882c76*/
    v8 = (_QWORD *)v17[0]; /*0x106882c7b*/
    *v8 = RBX::Reflection::Type::getSingleton<double>(a1: v9); /*0x106882c83*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<double,(double *)0>(a1: v8 + 1, a2: v21); /*0x106882c91*/
    *(double *)v21 = (double)a4; /*0x106882ca1*/
    v10 = v17[0]; /*0x106882ca6*/
    *(_QWORD *)(v10 + 80) = RBX::Reflection::Type::getSingleton<double>(a1: v11); /*0x106882caf*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<double,(double *)0>(a1: v10 + 88, a2: v21); /*0x106882cbe*/
    RBX::Security::Identity::Identity(a1: v21, a2: 2, a3: 0, a4: 0); /*0x106882cd0*/
    RBX::ScriptContext::callCallbackFromSource( /*0x106882cf8*/
      a1: &v18,
      a2: v7,
      a3: v21,
      a4: (char *)this + 4808,
      a5: "Script",
      a6: v17);
    v13 = (volatile signed __int64 *)v19; /*0x106882d01*/
    v17[3] = v18; /*0x106882d05*/
    v17[4] = v19; /*0x106882d09*/
    v14 = *(double **)v18; /*0x106882d0d*/
    if ( *(_QWORD *)v18 != *(_QWORD *)(v18 + 8) /*0x106882d73*/
      && (v15 = *v14, RBX::Reflection::Type::getSingleton<double>(a1: v12) == *(_QWORD *)&v15)
      && *((_QWORD *)v14 + 1) != 0 )
    {
      *v20 = v14[2]; /*0x106882d7e*/
      LOBYTE(v14) = 1; /*0x106882d82*/
    }
    else
    {
      LODWORD(v14) = 0; /*0x106882d23*/
    }
    if ( v13 != nullptr && _InterlockedExchangeAdd64(v13 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106882d3a*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v13 + 16))(a1: v13); /*0x106882d42*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v13); /*0x106882d48*/
    }
    v21[0] = (void **)v17; /*0x106882d51*/
    std::vector<RBX::Reflection::Variant>::__destroy_vector::operator()[abi:ne200100](a1: v21); /*0x106882d54*/
  }
  return (unsigned int)v14; /*0x106882d5f*/
}

// Address: 0x106882db4 | Name: __ZN3RBX7Network6Server23registerDynLuaChallengeENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEx
void __fastcall RBX::Network::Server::registerDynLuaChallenge(RBX::Network::Server *this, __int128 *a2, int a3)
{
  __int64 v6; // rdx
  __int64 v7; // rcx
  const char *v8; // rsi
  double v9[3]; // [rsp+8h] [rbp-58h] BYREF
  __int128 v10; // [rsp+20h] [rbp-40h] BYREF
  void *v11; // [rsp+30h] [rbp-30h]
  _BYTE v12[40]; // [rsp+38h] [rbp-28h] BYREF

  if ( *((int *)this + 1208) < 0 ) /*0x106882dca*/
  {
    RBX::ProtectedString::fromTrustedSource(a1: &v10, a2); /*0x106882de0*/
    RBX::ProtectedString::operator=(a1: (char *)this + 4808, a2: &v10); /*0x106882def*/
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: (char *)&v10 + 8); /*0x106882df8*/
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: &v10); /*0x106882e01*/
    RBX::SharedString::SharedString(this: (RBX::SharedString *)v12); /*0x106882e0a*/
    if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x106882e13*/
    {
      std::string::__init_copy_ctor_external(a1: &v10, a2: *((_QWORD *)a2 + 2), a3: *((_QWORD *)a2 + 1)); /*0x106882e33*/
    }
    else
    {
      v11 = *((void **)a2 + 2); /*0x106882e19*/
      v10 = *a2; /*0x106882e21*/
    }
    RBX::SharedString::setContents(a1: v12, a2: &v10); /*0x106882e40*/
    *((_DWORD *)this + 1208) = RBX::Network::Server::registerLegalSharedScript(this, a2: (const RBX::SharedString *)v12); /*0x106882e51*/
    *((_DWORD *)this + 1209) = a3; /*0x106882e57*/
    RBX::Network::Server::doDynLuaChallenge(this, a2: v9, a3: -1, a4: -1); /*0x106882e6f*/
    v8 = "DynLua-InitPass"; /*0x106882e82*/
    if ( *((_DWORD *)this + 1208) == -1 ) /*0x106882e89*/
      v8 = "DynLua-InitFail"; /*0x106882e89*/
    std::string::basic_string[abi:ne200100]<0>(a1: v9, a2: v8, a3: v6, a4: v7); /*0x106882e91*/
    RBX::Analytics::EphemeralCounter::reportCounter(a1: v9, a2: 1, a3: 0); /*0x106882ea1*/
    if ( (LOBYTE(v9[0]) & 1) != 0 ) /*0x106882eaa*/
      operator delete(a1: *(void **)&v9[2]); /*0x106882eb0*/
    if ( (v10 & 1) != 0 ) /*0x106882eb9*/
      operator delete(a1: v11); /*0x106882ebf*/
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v12); /*0x106882ec8*/
  }
}

// Address: 0x106882f46 | Name: __ZN3RBX7Network6Server30detachRakNetReplicatorFromPeerERKN6RakNet13SystemAddressEPKNS0_10ReplicatorE
char __fastcall RBX::Network::Server::detachRakNetReplicatorFromPeer(
        RBX::Network::Server *this,
        const RakNet::SystemAddress *a2,
        const RBX::Network::Replicator *a3)
{
  char *v4; // rbx
  __int64 v5; // rax

  v4 = (char *)this + 4688; /*0x106882f53*/
  v5 = std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::find<RakNet::SystemAddress>( /*0x106882f5d*/
         a1: (char *)this + 4688,
         a2);
  if ( v5 == 0 || *(const RBX::Network::Replicator **)(v5 + 48) != a3 ) /*0x106882f6b*/
    return 0; /*0x106882f6d*/
  std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::erase( /*0x106882f77*/
    a1: v4,
    a2: v5);
  return 1; /*0x106882f7e*/
}

// Address: 0x106882f84 | Name: __ZN3RBX7Network6Server24detachReplicatorFromPeerERKN6RakNet13SystemAddressE
__int64 __fastcall RBX::Network::Server::detachReplicatorFromPeer(
        RBX::Network::Server *this,
        const RakNet::SystemAddress *a2)
{
  return std::__hash_table<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::__unordered_map_hasher<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,true>,std::__unordered_map_equal<RakNet::SystemAddress,std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>,std::equal_to<RakNet::SystemAddress>,RakNet::SystemAddressHasher,true>,std::allocator<std::__hash_value_type<RakNet::SystemAddress,RBX::Network::Replicator *>>>::__erase_unique<RakNet::SystemAddress>( /*0x106882f8f*/
           a1: (char *)this + 4648,
           a2);
}

// Address: 0x106882f98 | Name: __ZN3RBX7Network6Server13setPreauthKeyERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
__int64 __fastcall RBX::Network::Server::setPreauthKey(__int64 a1, __int64 a2)
{
  __int64 v3; // rax

  v3 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(RBX::Network::ConcurrentRakPeer **)(a1 + 288)); /*0x106882fa8*/
  return (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v3 + 880LL))(a1: v3, a2); /*0x106882fc2*/
}

// Address: 0x106882fc6 | Name: __ZN3RBX7Network6Server8setJobIdERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
__int64 __fastcall RBX::Network::Server::setJobId(__int64 a1, __int64 a2)
{
  __int64 v4; // rax
  bool v5; // si
  __int64 result; // rax

  v4 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(RBX::Network::ConcurrentRakPeer **)(a1 + 288)); /*0x106882fda*/
  (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v4 + 872LL))(a1: v4, a2); /*0x106882fe8*/
  result = RBX::Network::useRbxTransport(this: (RBX::Network *)1, a2: v5); /*0x106882ff3*/
  if ( (_BYTE)result != 0 ) /*0x106882ffa*/
    return std::string::operator=(a1: a1 + 5160, a2); /*0x10688300d*/
  return result; /*0x106883009*/
}

// Address: 0x106883018 | Name: __ZN3RBX7Network6Server26setUserScoreDecryptionKeysERKNSt3__16vectorINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS7_IS9_EEEE
void __fastcall RBX::Network::Server::setUserScoreDecryptionKeys(__int64 a1, __int64 *a2)
{
  __int64 *v2; // rdi

  v2 = (__int64 *)(a1 + 4920); /*0x10688301c*/
  if ( v2 != a2 ) /*0x106883026*/
    std::vector<std::string>::__assign_with_size[abi:ne200100]<std::string*,std::string*>( /*0x10688304b*/
      a1: v2,
      a2: *a2,
      a3: a2[1],
      a4: 0xAAAAAAAAAAAAAAABLL * ((a2[1] - *a2) >> 3));
}

// Address: 0x106883052 | Name: __ZN3RBX7Network6Server26getUserScoreDecryptionKeysEv
RBX::Network::Server *__fastcall RBX::Network::Server::getUserScoreDecryptionKeys(
        RBX::Network::Server *this,
        __int64 a2)
{
  *(_OWORD *)this = 0; /*0x10688305e*/
  *((_QWORD *)this + 2) = 0; /*0x106883061*/
  std::vector<std::string>::__init_with_size[abi:ne200100]<std::string*,std::string*>( /*0x106883092*/
    a1: this,
    a2: *(_QWORD *)(a2 + 4920),
    a3: *(_QWORD *)(a2 + 4928),
    a4: 0xAAAAAAAAAAAAAAABLL * ((__int64)(*(_QWORD *)(a2 + 4928) - *(_QWORD *)(a2 + 4920)) >> 3));
  return this; /*0x10688309e*/
}

// Address: 0x1068830a2 | Name: __ZN3RBX7Network6Server17setLatencyMetricsENSt3__110shared_ptrINS0_26NetworkLatencyScopeMetricsEEE
__int64 __fastcall RBX::Network::Server::setLatencyMetrics(__int64 a1)
{
  __int64 result; // rax

  if ( *(_BYTE *)(a1 + 5064) == 0 ) /*0x1068830a9*/
  {
    result = std::shared_ptr<RBX::Network::NetworkLatencyScopeMetrics>::operator=[abi:ne200100](a1: a1 + 4944); /*0x1068830bb*/
    *(_BYTE *)(a1 + 5064) = 1; /*0x1068830c0*/
  }
  return result; /*0x1068830cd*/
}

// Address: 0x106883120 | Name: __ZN3RBX7Network6Server17getLatencyMetricsEv
__int64 __fastcall RBX::Network::Server::getLatencyMetrics(RBX::Network::Server *this)
{
  return *((_QWORD *)this + 618); /*0x10688312b*/
}

// Address: 0x10688312e | Name: __ZN3RBX7Network6Server13setMaxPlayersEj
void __fastcall RBX::Network::Server::setMaxPlayers(RBX::Network::Server *this, int a2)
{
  *((_DWORD *)this + 1267) = a2; /*0x106883132*/
}

// Address: 0x10688313a | Name: __ZNK3RBX7Network6Server13getMaxPlayersEv
__int64 __fastcall RBX::Network::Server::getMaxPlayers(RBX::Network::Server *this)
{
  return *((unsigned int *)this + 1267); /*0x106883144*/
}

// Address: 0x106883146 | Name: __ZN3RBX7Network6Server27trackMaybeUnusedRemoteEventERKNS_10Reflection15EventDescriptorE
__int64 __fastcall RBX::Network::Server::trackMaybeUnusedRemoteEvent(
        RBX::Network::Server *this,
        const RBX::Reflection::EventDescriptor *a2)
{
  __int64 result; // rax
  const RBX::Reflection::EventDescriptor **v3; // [rsp+8h] [rbp-18h] BYREF
  const RBX::Reflection::EventDescriptor *v4; // [rsp+10h] [rbp-10h] BYREF
  char v5; // [rsp+1Fh] [rbp-1h] BYREF

  v4 = a2; /*0x106883159*/
  v3 = &v4; /*0x106883160*/
  result = std::__hash_table<std::__hash_value_type<RBX::Reflection::EventDescriptor const*,unsigned long>,std::__unordered_map_hasher<RBX::Reflection::EventDescriptor const*,std::__hash_value_type<RBX::Reflection::EventDescriptor const*,unsigned long>,std::hash<RBX::Reflection::EventDescriptor const*>,std::equal_to<RBX::Reflection::EventDescriptor const*>,true>,std::__unordered_map_equal<RBX::Reflection::EventDescriptor const*,std::__hash_value_type<RBX::Reflection::EventDescriptor const*,unsigned long>,std::equal_to<RBX::Reflection::EventDescriptor const*>,std::hash<RBX::Reflection::EventDescriptor const*>,true>,std::allocator<std::__hash_value_type<RBX::Reflection::EventDescriptor const*,unsigned long>>>::__emplace_unique_key_args<RBX::Reflection::EventDescriptor const*,std::piecewise_construct_t const&,std::tuple<RBX::Reflection::EventDescriptor const*&&>,std::tuple<>>( /*0x106883171*/
             a1: (char *)this + 5072,
             a2: &v4,
             a3: std::piecewise_construct,
             a4: &v3,
             a5: &v5);
  ++*(_QWORD *)(result + 24); /*0x106883176*/
  return result; /*0x10688317a*/
}

// Address: 0x106883180 | Name: __ZNK3RBX7Network6Server25getExpectsFacsReplicationEv
__int64 __fastcall RBX::Network::Server::getExpectsFacsReplication(RBX::Network::Server *this, const RBX::Instance *a2)
{
  RBX::ServiceProvider *ServiceProvider; // rax
  RBX::AvatarChatService *v3; // rax

  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2); /*0x106883184*/
  if ( ServiceProvider != nullptr /*0x106883199*/
    && (v3 = (RBX::AvatarChatService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::AvatarChatService>(this: ServiceProvider)) != nullptr )
  {
    return RBX::AvatarChatService::isPlaceEnabled(this: v3); /*0x10688319f*/
  }
  else
  {
    return 0; /*0x1068831a4*/
  }
}

// Address: 0x1068831a8 | Name: __ZN3RBX7Network6Server9broadcastENS0_13NetworkStreamE
char __fastcall RBX::Network::Server::broadcast(__int64 a1, __int64 a2)
{
  __int64 v2; // r13
  __int64 v3; // rax
  RBX::Network::Replicator **v4; // r15
  RBX::Network::Replicator *v6; // r14
  __int64 v7; // rbx
  unsigned int v8; // ecx
  __int64 v9; // rdi
  std::__shared_weak_count *v10; // r14
  std::__shared_weak_count *v11; // r14
  RBX::Network::Replicator **i; // [rsp+8h] [rbp-58h]
  std::__shared_weak_count *v14[2]; // [rsp+10h] [rbp-50h] BYREF
  std::__shared_weak_count *v15[2]; // [rsp+20h] [rbp-40h] BYREF
  char v16[41]; // [rsp+37h] [rbp-29h] BYREF

  v3 = *(_QWORD *)(a1 + 120); /*0x1068831b9*/
  if ( v3 != 0 ) /*0x1068831c0*/
  {
    v4 = *(RBX::Network::Replicator ***)v3; /*0x1068831c6*/
    v3 = *(_QWORD *)(v3 + 8); /*0x1068831c9*/
    for ( i = (RBX::Network::Replicator **)v3; v4 != i; v4 += 2 ) /*0x1068831d4*/
    {
      v6 = *v4; /*0x1068831dd*/
      if ( *v4 != nullptr ) /*0x1068831e3*/
      {
        v7 = *((_QWORD *)v6 + 3); /*0x1068831e9*/
        v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(); /*0x1068831ed*/
        v8 = *(unsigned __int16 *)(v7 + 440) - *(unsigned __int16 *)(v3 + 440); /*0x106883200*/
        LODWORD(v3) = *(unsigned __int16 *)(v3 + 442); /*0x106883202*/
        if ( v8 <= (unsigned int)v3 ) /*0x10688320b*/
        {
          LOBYTE(v3) = RBX::Network::Replicator::shouldActivelyReplicate(this: v6); /*0x106883214*/
          if ( (_BYTE)v3 != 0 ) /*0x10688321b*/
          {
            _ZNSt3__115allocate_sharedB8ne200100IN3RBX7Network13NetworkStreamENS_9allocatorIS3_EEJELi0EEENS_10shared_ptrIT_EERKT0_DpOT1_( /*0x106883229*/
              a1: v15,
              a2: v16);
            RBX::Network::NetworkStream::reserve(this: v15[0], a2: *(_DWORD *)(a2 + 48)); /*0x106883237*/
            RBX::Network::NetworkStream::writeBytes( /*0x10688324a*/
              this: v15[0],
              a2: *(const void **)(a2 + 16),
              a3: *(_DWORD *)(a2 + 48));
            v9 = *((_QWORD *)v6 + 35); /*0x10688324f*/
            *(_OWORD *)v14 = *(_OWORD *)v15; /*0x10688325a*/
            *(_OWORD *)v15 = 0; /*0x106883261*/
            v2 &= 0xFFFFFFFFFFFFFF00LL; /*0x106883265*/
            LOBYTE(v3) = (*(__int64 (__fastcall **)(__int64, _QWORD, std::__shared_weak_count **, __int64, _QWORD))(*(_QWORD *)v9 + 48LL))( /*0x10688327b*/
                           a1: v9,
                           a2: 0,
                           a3: v14,
                           a4: v2,
                           a5: 0);
            v10 = v14[1]; /*0x10688327e*/
            if ( v14[1] != nullptr ) /*0x106883285*/
            {
              v3 = _InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x10688328e*/
              if ( v3 == 0 ) /*0x106883297*/
              {
                (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x10688329f*/
                LOBYTE(v3) = std::__shared_weak_count::__release_weak(this: v10); /*0x1068832a5*/
              }
            }
            v11 = v15[1]; /*0x1068832aa*/
            if ( v15[1] != nullptr ) /*0x1068832b1*/
            {
              v3 = _InterlockedExchangeAdd64((volatile signed __int64 *)v15[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x1068832ba*/
              if ( v3 == 0 ) /*0x1068832c3*/
              {
                (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(a1: v11); /*0x1068832cb*/
                LOBYTE(v3) = std::__shared_weak_count::__release_weak(this: v11); /*0x1068832d1*/
              }
            }
          }
        }
      }
    }
  }
  return v3; /*0x1068832e4*/
}

// Address: 0x106d72d38 | Name: __ZNK3RBX7Network6Server13getAsInternalENS_10Reflection11InterfaceIdE
__int64 __fastcall RBX::Network::Server::getAsInternal(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  result = 0; /*0x106d72d43*/
  if ( a2 == 1 ) /*0x106d72d49*/
    return a1 + 464; /*0x106d72d49*/
  return result; /*0x106d72d4d*/
}

// Address: 0x106d72d50 | Name: __ZN3RBX7Network6Server35writeAllPropertiesForChangeTrackingEPNS_23DataModelChangeTracking13ChangeTrackerENS2_12DeltaTypeTagE
__int64 RBX::Network::Server::writeAllPropertiesForChangeTracking()
{
  return RBX::Network::Peer::writeAllPropertiesForChangeTracking(); /*0x106d72d54*/
}

// Address: 0x1087692d7 | Name: __ZN3RBX7Network6Server9OnReceiveEPN6RakNet6PacketE.cold.1
void __fastcall RBX::Network::Server::OnReceive(_BYTE *a1, _BYTE *a2, __int64 a3, void **a4)
{
  if ( *a1 != 0 && (*(_BYTE *)(a3 + 16) & 1) != 0 ) /*0x1087692ed*/
    operator delete(a1: *(void **)(a3 + 32)); /*0x1087692f3*/
  if ( (*a2 & 1) != 0 ) /*0x1087692fc*/
    operator delete(a1: *a4); /*0x108769301*/
}

// Address: 0x10876930b | Name: __ZN3RBX7Network6Server9OnReceiveEPN6RakNet6PacketE.cold.2
void __fastcall RBX::Network::Server::OnReceive(_BYTE *a1, _BYTE *a2, __int64 a3, void **a4)
{
  if ( *a1 != 0 && (*(_BYTE *)(a3 + 16) & 1) != 0 ) /*0x108769321*/
    operator delete(a1: *(void **)(a3 + 32)); /*0x108769327*/
  if ( (*a2 & 1) != 0 ) /*0x108769330*/
    operator delete(a1: *a4); /*0x108769335*/
}

// Address: 0x10876933f | Name: __ZN3RBX7Network6Server18getDynLuaChallengeERNSt3__18optionalINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEE.cold.1
void __fastcall RBX::Network::Server::getDynLuaChallenge(__int64 a1)
{
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x108769342*/
    operator delete(a1: *(void **)(a1 + 16)); /*0x10876934c*/
}

// END Server part 1/1, 88 functions
