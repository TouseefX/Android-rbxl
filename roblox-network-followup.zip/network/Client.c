// Client -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 110 functions


// Address: 0x1066e67c8 | Name: __ZN3RBX7Network6ClientC2ERNS_28ForceConstructionInCreatableE
char *__fastcall RBX::Network::Client::Client(__int64 a1)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  RBX::Time *v4; // rdi
  __int64 v5; // xmm0_8
  __int64 v6; // rdx
  __int64 v7; // rcx
  void *v8; // rsi
  unsigned __int64 v9; // rsi
  __int64 v10; // rax
  RBX::Security::Context *v11; // rdi
  __int64 v12; // rax
  __int64 v13; // rdx
  __int64 v14; // rcx
  void *v15; // rsi
  RBX::Profiler::RomarkMarkers *v16; // rdi
  __int64 v17; // rax
  RBX::Profiler::RomarkConnectionMonitor *v18; // rdi
  char *result; // rax
  __int64 v20; // rax
  __int64 v21; // r15
  __int64 v22; // rdi
  _BYTE v23[16]; // [rsp+8h] [rbp-98h] BYREF
  void *v24; // [rsp+18h] [rbp-88h]
  __int64 v25; // [rsp+20h] [rbp-80h]
  __int64 v26; // [rsp+28h] [rbp-78h]
  _BYTE v27[16]; // [rsp+40h] [rbp-60h] BYREF
  void *v28; // [rsp+50h] [rbp-50h]
  RBX::Network::MegaReplicator *v29; // [rsp+58h] [rbp-48h]

  RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer>::DescribedCreatable<RBX::ForceConstructionInCreatable &>(); /*0x1066e67dc*/
  *(_BYTE *)(a1 + 472) = 1; /*0x1066e67e1*/
  *(_QWORD *)a1 = off_10CAF1608; /*0x1066e67f3*/
  *(_QWORD *)(a1 + 176) = off_10CAF18E8; /*0x1066e67fd*/
  *(_QWORD *)(a1 + 464) = &off_10CAF1950; /*0x1066e680a*/
  *(_OWORD *)(a1 + 480) = 0; /*0x1066e681b*/
  *(_QWORD *)(a1 + 496) = 0; /*0x1066e6822*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)(a1 + 504)); /*0x1066e682d*/
  *(_QWORD *)(a1 + 536) = -1; /*0x1066e6839*/
  *(_OWORD *)(a1 + 544) = 0; /*0x1066e6843*/
  *(_OWORD *)(a1 + 560) = 0; /*0x1066e684a*/
  *(_OWORD *)(a1 + 576) = 0; /*0x1066e6851*/
  *(_QWORD *)(a1 + 592) = -1; /*0x1066e6858*/
  *(_DWORD *)(a1 + 600) = 0; /*0x1066e6866*/
  *(_WORD *)(a1 + 604) = 0; /*0x1066e6870*/
  std::string::basic_string[abi:ne200100]<0>(a1: a1 + 608, a2: "Unknown", a3: v2, a4: v3); /*0x1066e6883*/
  *(_DWORD *)(a1 + 632) = 0; /*0x1066e6888*/
  *(_OWORD *)(a1 + 640) = 0; /*0x1066e6895*/
  *(_QWORD *)(a1 + 656) = 0; /*0x1066e689c*/
  v25 = a1 + 608; /*0x1066e68a7*/
  RBX::Time::nowFast(this: v4); /*0x1066e68ab*/
  *(_QWORD *)(a1 + 664) = v5; /*0x1066e68b0*/
  *(_OWORD *)(a1 + 672) = 0; /*0x1066e68bb*/
  *(_QWORD *)(a1 + 688) = 0; /*0x1066e68c2*/
  v29 = (RBX::Network::MegaReplicator *)(a1 + 696); /*0x1066e68d4*/
  RBX::Network::MegaReplicator::MegaReplicator(this: (RBX::Network::MegaReplicator *)(a1 + 696), a2: false, a3: nullptr); /*0x1066e68dc*/
  *(_OWORD *)(a1 + 4592) = 0; /*0x1066e68eb*/
  v26 = a1 + 4608; /*0x1066e68f9*/
  RSL::Mutex::Mutex(this: (RSL::Mutex *)(a1 + 4608), a2: "connectionStateAndJoinDataMutex"); /*0x1066e68fd*/
  *(_QWORD *)(a1 + 4704) = 0; /*0x1066e6904*/
  *(_WORD *)(a1 + 4720) = 0; /*0x1066e690b*/
  *(_BYTE *)(a1 + 4722) = 0; /*0x1066e6914*/
  *(_OWORD *)(a1 + 4616) = 0; /*0x1066e691e*/
  *(_OWORD *)(a1 + 4632) = 0; /*0x1066e6925*/
  *(_OWORD *)(a1 + 4648) = 0; /*0x1066e692c*/
  *(_QWORD *)(a1 + 4664) = 0; /*0x1066e6933*/
  std::string::basic_string[abi:ne200100]<0>(a1: v23, a2: "", a3: v6, a4: v7); /*0x1066e6948*/
  RBX::Network::StateReason::StateReason(a1: a1 + 4728, a2: 0, a3: 0, a4: v23); /*0x1066e695f*/
  if ( (v23[0] & 1) != 0 ) /*0x1066e696b*/
    operator delete(a1: (RBX::Memory *)v24, a2: v8); /*0x1066e6974*/
  *(_QWORD *)(a1 + 4800) = 0; /*0x1066e697b*/
  *(_WORD *)(a1 + 4816) = 0; /*0x1066e6982*/
  *(_QWORD *)(a1 + 4936) = 0; /*0x1066e698b*/
  *(_DWORD *)(a1 + 4944) = 0; /*0x1066e6992*/
  *(_OWORD *)(a1 + 4820) = 0; /*0x1066e69a6*/
  *(_OWORD *)(a1 + 4836) = 0; /*0x1066e69ad*/
  *(_OWORD *)(a1 + 4852) = 0; /*0x1066e69b4*/
  *(_OWORD *)(a1 + 4868) = 0; /*0x1066e69bb*/
  *(_OWORD *)(a1 + 4884) = 0; /*0x1066e69c2*/
  *(_OWORD *)(a1 + 4900) = 0; /*0x1066e69c9*/
  *(_OWORD *)(a1 + 4916) = 0; /*0x1066e69d0*/
  *(_OWORD *)(a1 + 4952) = 0; /*0x1066e69d7*/
  *(_OWORD *)(a1 + 4961) = 0; /*0x1066e69de*/
  RBX::SimpleTimer::SimpleTimer(this: (RBX::SimpleTimer *)(a1 + 4984)); /*0x1066e69e8*/
  RSL::Mutex::Mutex(this: (RSL::Mutex *)(a1 + 5000), a2: "rbxTransportConfigCallbackMutex"); /*0x1066e69fe*/
  *(_BYTE *)(a1 + 5080) = 0; /*0x1066e6a06*/
  *(_OWORD *)(a1 + 5088) = 0; /*0x1066e6a10*/
  *(_OWORD *)(a1 + 5008) = 0; /*0x1066e6a1e*/
  *(_BYTE *)(a1 + 5024) = 0; /*0x1066e6a25*/
  RSL::Mutex::Mutex(this: (RSL::Mutex *)(a1 + 5104), a2: "setLatencyMutex"); /*0x1066e6a36*/
  *(_BYTE *)(a1 + 5112) = 0; /*0x1066e6a3b*/
  *(_QWORD *)(a1 + 5120) = 0; /*0x1066e6a42*/
  *(_BYTE *)(a1 + 5128) = 0; /*0x1066e6a4d*/
  v10 = operator new(a1: (RBX::Memory *)0x78, a2: v9); /*0x1066e6a59*/
  *(_OWORD *)(v10 + 96) = 0; /*0x1066e6a61*/
  *(_OWORD *)(v10 + 80) = 0; /*0x1066e6a65*/
  *(_OWORD *)(v10 + 64) = 0; /*0x1066e6a69*/
  *(_OWORD *)(v10 + 48) = 0; /*0x1066e6a6d*/
  *(_OWORD *)(v10 + 32) = 0; /*0x1066e6a71*/
  *(_OWORD *)(v10 + 16) = 0; /*0x1066e6a75*/
  *(_OWORD *)v10 = 0; /*0x1066e6a79*/
  *(_QWORD *)(v10 + 112) = 0; /*0x1066e6a7e*/
  *(_QWORD *)(a1 + 5136) = v10; /*0x1066e6a82*/
  *(_QWORD *)(a1 + 5144) = 0; /*0x1066e6a89*/
  v12 = RBX::Security::Context::current(this: v11); /*0x1066e6a90*/
  RBX::Security::Context::requireCapabilities(a1: v12, a2: 1, a3: "create", a4: "NetworkClient"); /*0x1066e6aab*/
  RBX::Network::MegaReplicator::init(this: v29); /*0x1066e6ab4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v27, a2: "NetworkClient", a3: v13, a4: v14); /*0x1066e6ac4*/
  RBX::Instance::setName(a1, a2: v27); /*0x1066e6ad0*/
  if ( (v27[0] & 1) != 0 ) /*0x1066e6ad9*/
    operator delete(a1: (RBX::Memory *)v28, a2: v15); /*0x1066e6adf*/
  v16 = (RBX::Profiler::RomarkMarkers *)FLog::Network; /*0x1066e6aeb*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1066e6afd*/
    FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] NetworkClient:Create", 0); /*0x1066e6b11*/
  if ( DFFlag::DebugPerfMode == 1 ) /*0x1066e6b20*/
  {
    v17 = RBX::Profiler::RomarkMarkers::instance(this: v16); /*0x1066e6b22*/
    RBX::Profiler::RomarkMarkers::startSpan(a1: v17, a2: "join", a3: 4); /*0x1066e6b36*/
    if ( DFFlag::DebugEnableRomarkMicroprofilerTelemetry == 1 ) /*0x1066e6b42*/
      RBX::Profiler::RomarkConnectionMonitor::registerProfileTelemetry(this: v18); /*0x1066e6b44*/
  }
  if ( DFFlag::DebugEnablePhaseTracking != 0 /*0x1066e6b5f*/
    || (result = &DFFlag::DebugEnableClientPhaseTracking, DFFlag::DebugEnableClientPhaseTracking == 1) )
  {
    v20 = RBX::Subsystem<RBX::RomarkClientPhaseTracker,false>::startup<RBX::SubsystemDefaultFactory<RBX::RomarkClientPhaseTracker>>(); /*0x1066e6b61*/
    v21 = v20; /*0x1066e6b66*/
    if ( v20 != 0 ) /*0x1066e6b6c*/
      v22 = *(_QWORD *)(v20 + 24); /*0x1066e6b6e*/
    else
      v22 = 0; /*0x1066e6b74*/
    result = (char *)RBX::RomarkClientPhaseTracker::changeRomarkClientPhase(a1: v22, a2: 1); /*0x1066e6b7b*/
    if ( v21 != 0 ) /*0x1066e6b83*/
      return (char *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v21 + 16LL))(a1: v21); /*0x1066e6b8b*/
  }
  return result; /*0x1066e6b8e*/
}

// Address: 0x1066e6f7c | Name: __ZN3RBX7Network6ClientC1ERNS_28ForceConstructionInCreatableE
char *__fastcall RBX::Network::Client::Client(__int64 a1)
{
  return RBX::Network::Client::Client(a1); /*0x1066e6f80*/
}

// Address: 0x1066e6f86 | Name: __ZN3RBX7Network6Client23stopTraceRouteTelemetryEv
RBX::TraceRouteService *__fastcall RBX::Network::Client::stopTraceRouteTelemetry(RBX::Network::Client *this)
{
  RBX::TraceRouteService *result; // rax
  RBX::SimpleTimer *v2; // rbx

  result = (RBX::TraceRouteService *)&DFFlag::EnableTraceRouteService; /*0x1066e6f8c*/
  if ( DFFlag::EnableTraceRouteService == 1 ) /*0x1066e6f96*/
  {
    if ( DFFlag::EnableTraceRouteSessionSummaryStats == 1 ) /*0x1066e6fa5*/
    {
      result = (RBX::TraceRouteService *)RBX::ServiceProvider::find<RBX::TraceRouteService>(a1: this); /*0x1066e6faa*/
      if ( result != nullptr ) /*0x1066e6fb2*/
        return (RBX::TraceRouteService *)RBX::TraceRouteService::disconnectFromReplicator(this: result); /*0x1066e6fbd*/
    }
    else
    {
      v2 = (RBX::Network::Client *)((char *)this + 4984); /*0x1066e6fc2*/
      result = (RBX::TraceRouteService *)RBX::SimpleTimer::isValid(this: (RBX::Network::Client *)((char *)this + 4984)); /*0x1066e6fcc*/
      if ( (_BYTE)result != 0 ) /*0x1066e6fd3*/
        return (RBX::TraceRouteService *)RBX::SimpleTimer::stop(this: v2); /*0x1066e6fde*/
    }
  }
  return result; /*0x1066e6fbb*/
}

// Address: 0x1066e700a | Name: __ZN3RBX7Network6Client27finalizeTraceRouteTelemetryEv
RBX::TraceRouteService *__fastcall RBX::Network::Client::finalizeTraceRouteTelemetry(RBX::Network::Client *this)
{
  RBX::TraceRouteService *result; // rax
  RBX::TraceRouteService *v2; // rbx
  RBX::SimpleTimer *v3; // rbx

  result = (RBX::TraceRouteService *)&DFFlag::EnableTraceRouteService; /*0x1066e7010*/
  if ( DFFlag::EnableTraceRouteService == 1 ) /*0x1066e701a*/
  {
    if ( DFFlag::EnableTraceRouteSessionSummaryStats == 1 ) /*0x1066e7029*/
    {
      result = (RBX::TraceRouteService *)RBX::ServiceProvider::find<RBX::TraceRouteService>(a1: this); /*0x1066e702e*/
      if ( result != nullptr ) /*0x1066e7036*/
      {
        v2 = result; /*0x1066e7038*/
        RBX::TraceRouteService::sendSessionSummaryStats(this: result); /*0x1066e703e*/
        return (RBX::TraceRouteService *)RBX::TraceRouteService::disconnectFromReplicator(this: v2); /*0x1066e704c*/
      }
    }
    else
    {
      v3 = (RBX::Network::Client *)((char *)this + 4984); /*0x1066e7051*/
      result = (RBX::TraceRouteService *)RBX::SimpleTimer::isValid(this: (RBX::Network::Client *)((char *)this + 4984)); /*0x1066e705b*/
      if ( (_BYTE)result != 0 ) /*0x1066e7062*/
        return (RBX::TraceRouteService *)RBX::SimpleTimer::stop(this: v3); /*0x1066e706d*/
    }
  }
  return result; /*0x1066e704a*/
}

// Address: 0x1066e707a | Name: __ZN3RBX7Network6ClientD2Ev
void __fastcall RBX::Network::Client::~Client(RBX::Network::Client *this)
{
  RBX::Ixp::IxpController *v2; // rdi
  __int64 v3; // rax
  __int64 v4; // rcx
  void *v5; // rsi
  void *v6; // rsi
  RBX::Network::Client *v7; // rdi
  __int64 v8; // rax
  RBX::Network::Client *v9; // rdi
  __int64 v10; // rax
  void *v11; // rsi
  __int64 v12; // rdi
  void *v13; // rsi
  std::__shared_weak_count *v14[2]; // [rsp+10h] [rbp-20h] BYREF

  *(_QWORD *)this = off_10CAF1608; /*0x1066e7093*/
  *((_QWORD *)this + 22) = off_10CAF18E8; /*0x1066e709d*/
  *((_QWORD *)this + 58) = &off_10CAF1950; /*0x1066e70aa*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1066e70ca*/
    FLog::FastLog(a1: FLog::Network, a2: qword_10D7BBAA8, a3: "[FLog::Network] NetworkClient:Remove", 0); /*0x1066e70de*/
  RBX::Network::Client::stopTraceRouteTelemetry(this); /*0x1066e70e6*/
  if ( *((_QWORD *)this + 636) != 0 ) /*0x1066e70fa*/
  {
    v3 = RBX::Ixp::IxpController::instance(this: v2); /*0x1066e70fc*/
    v4 = *((_QWORD *)this + 637); /*0x1066e7101*/
    *(_OWORD *)v14 = *((_OWORD *)this + 318); /*0x1066e7109*/
    if ( v4 != 0 ) /*0x1066e7110*/
      _InterlockedIncrement64((volatile signed __int64 *)(v4 + 16)); /*0x1066e7112*/
    (*(void (__fastcall **)(__int64, std::__shared_weak_count **))(*(_QWORD *)v3 + 360LL))(a1: v3, a2: v14); /*0x1066e7121*/
    if ( v14[1] != nullptr ) /*0x1066e712e*/
      std::__shared_weak_count::__release_weak(this: v14[1]); /*0x1066e7130*/
  }
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Network::Client *)((char *)this + 5144)); /*0x1066e713c*/
  std::unique_ptr<RBX::Network::NetworkEmulationUpdater>::reset[abi:ne200100](a1: (char *)this + 5136, a2: 0); /*0x1066e714a*/
  RSL::Mutex::~Mutex(a1: (char *)this + 5104); /*0x1066e7156*/
  std::shared_ptr<RBX::Network::Client::IxpChangedListener>::~shared_ptr[abi:ne200100](a1: (char *)this + 5088); /*0x1066e715e*/
  std::__optional_destruct_base<RBX::Security::EarlyAuthData,false>::~__optional_destruct_base[abi:ne200100](a1: (char *)this + 5024); /*0x1066e716a*/
  std::shared_ptr<RBX::RbxTransport::ConnectConfiguration>::~shared_ptr[abi:ne200100](a1: (char *)this + 5008); /*0x1066e7176*/
  RSL::Mutex::~Mutex(a1: (char *)this + 5000); /*0x1066e7182*/
  std::shared_ptr<RBX::TimerData>::~shared_ptr[abi:ne200100](a1: (char *)this + 4984); /*0x1066e718e*/
  std::vector<RBX::Network::ConnectionInfo>::__destroy_vector::operator()[abi:ne200100](); /*0x1066e71a1*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 617); /*0x1066e71ad*/
  if ( (*((_BYTE *)this + 4872) & 1) != 0 ) /*0x1066e71b9*/
    operator delete(a1: *((RBX::Memory **)this + 611), a2: v5); /*0x1066e71c2*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 608); /*0x1066e71ce*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 607); /*0x1066e71da*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 606); /*0x1066e71e6*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 605); /*0x1066e71f2*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 604); /*0x1066e71fe*/
  boost::intrusive_ptr<rbx::signals::slots_holder>::~intrusive_ptr(a1: (void **)this + 603); /*0x1066e720a*/
  v7 = *((RBX::Network::Client **)this + 600); /*0x1066e7216*/
  if ( v7 == (RBX::Network::Client *)((char *)this + 4768) ) /*0x1066e7220*/
  {
    v8 = 32; /*0x1066e722e*/
    goto LABEL_14; /*0x1066e722e*/
  }
  v8 = 40; /*0x1066e7222*/
  if ( v7 != nullptr ) /*0x1066e722a*/
LABEL_14:
    (*(void (**)(void))(*(_QWORD *)v7 + v8))(); /*0x1066e7233*/
  if ( (*((_BYTE *)this + 4736) & 1) != 0 ) /*0x1066e7240*/
    operator delete(a1: *((RBX::Memory **)this + 594), a2: v6); /*0x1066e7249*/
  v9 = *((RBX::Network::Client **)this + 588); /*0x1066e7255*/
  if ( v9 == (RBX::Network::Client *)((char *)this + 4672) ) /*0x1066e725f*/
  {
    v10 = 32; /*0x1066e726d*/
    goto LABEL_21; /*0x1066e726d*/
  }
  v10 = 40; /*0x1066e7261*/
  if ( v9 != nullptr ) /*0x1066e7269*/
LABEL_21:
    (*(void (**)(void))(*(_QWORD *)v9 + v10))(); /*0x1066e7272*/
  std::unique_ptr<RBX::RbxTransport::DummyService::DummyClient>::reset[abi:ne200100](a1: (char *)this + 4664, a2: 0); /*0x1066e7278*/
  if ( (*((_BYTE *)this + 4640) & 1) != 0 ) /*0x1066e728d*/
    operator delete(a1: *((RBX::Memory **)this + 582), a2: v11); /*0x1066e7296*/
  if ( (*((_BYTE *)this + 4616) & 1) != 0 ) /*0x1066e72a2*/
    operator delete(a1: *((RBX::Memory **)this + 579), a2: v11); /*0x1066e72ab*/
  RSL::Mutex::~Mutex(a1: (char *)this + 4608); /*0x1066e72b7*/
  v12 = *((_QWORD *)this + 575); /*0x1066e72bc*/
  *((_QWORD *)this + 575) = 0; /*0x1066e72c3*/
  if ( v12 != 0 ) /*0x1066e72d1*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v12 + 8LL))(a1: v12); /*0x1066e72d6*/
  RBX::Network::MegaReplicator::~MegaReplicator(this: (RBX::Network::Client *)((char *)this + 696)); /*0x1066e72e0*/
  if ( (*((_BYTE *)this + 672) & 1) != 0 ) /*0x1066e72ec*/
    operator delete(a1: *((RBX::Memory **)this + 86), a2: v13); /*0x1066e72f5*/
  if ( (*((_BYTE *)this + 640) & 1) != 0 ) /*0x1066e7301*/
    operator delete(a1: *((RBX::Memory **)this + 82), a2: v13); /*0x1066e730a*/
  if ( (*((_BYTE *)this + 608) & 1) != 0 ) /*0x1066e7316*/
    operator delete(a1: *((RBX::Memory **)this + 78), a2: v13); /*0x1066e731f*/
  if ( (*((_BYTE *)this + 568) & 1) != 0 ) /*0x1066e732b*/
    operator delete(a1: *((RBX::Memory **)this + 73), a2: v13); /*0x1066e7334*/
  if ( (*((_BYTE *)this + 544) & 1) != 0 ) /*0x1066e7340*/
    operator delete(a1: *((RBX::Memory **)this + 70), a2: v13); /*0x1066e7349*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Network::Client *)((char *)this + 496)); /*0x1066e7355*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Network::Client *)((char *)this + 488)); /*0x1066e7361*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Network::Client *)((char *)this + 480)); /*0x1066e736d*/
  RBX::Network::NetworkClientProp::~NetworkClientProp(this); /*0x1066e7375*/
  RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer>::~DescribedCreatable(this); /*0x1066e737d*/
}

// Address: 0x1066e7394 | Name: __ZN3RBX7Network6ClientD1Ev
void __fastcall RBX::Network::Client::~Client(RBX::Network::Client *this)
{
  RBX::Network::Client::~Client(this); /*0x1066e7399*/
}

// Address: 0x1066e739e | Name: __ZThn176_N3RBX7Network6ClientD1Ev
void __fastcall `non-virtual thunk to'RBX::Network::Client::~Client(RBX::Network::Client *this)
{
  RBX::Network::Client::~Client(this: (RBX::Network::Client *)((char *)this - 176)); /*0x1066e73aa*/
}

// Address: 0x1066e73b0 | Name: __ZN3RBX7Network6ClientD0Ev
void __fastcall RBX::Network::Client::~Client(RBX::Network::Client *this)
{
  void *v2; // rsi

  RBX::Network::Client::~Client(this); /*0x1066e73b9*/
  operator delete(a1: this, a2: v2); /*0x1066e73c7*/
}

// Address: 0x1066e73cc | Name: __ZThn176_N3RBX7Network6ClientD0Ev
void __fastcall `non-virtual thunk to'RBX::Network::Client::~Client(RBX::Network::Client *this)
{
  RBX::Memory *v1; // rbx
  void *v2; // rsi

  v1 = (RBX::Network::Client *)((char *)this - 176); /*0x1066e73d5*/
  RBX::Network::Client::~Client(this: (RBX::Network::Client *)((char *)this - 176)); /*0x1066e73df*/
  operator delete(a1: v1, a2: v2); /*0x1066e73ed*/
}

// Address: 0x1066e73f2 | Name: __ZN3RBX7Network6Client13getConnectionEv
__int64 __fastcall RBX::Network::Client::getConnection(RBX::Network::Client *this)
{
  __int64 v1; // rax
  char *v2; // rdi

  v1 = *((_QWORD *)this + 574); /*0x1066e73f6*/
  v2 = (char *)this + 4600; /*0x1066e7404*/
  if ( v1 != 0 ) /*0x1066e740e*/
    v2 = (char *)(v1 + 280); /*0x1066e740e*/
  return *(_QWORD *)v2; /*0x1066e7415*/
}

// Address: 0x1066e7418 | Name: __ZNK3RBX7Network6Client13getConnectionEv
__int64 __fastcall RBX::Network::Client::getConnection(RBX::Network::Client *this)
{
  __int64 v1; // rax
  char *v2; // rdi

  v1 = *((_QWORD *)this + 574); /*0x1066e741c*/
  v2 = (char *)this + 4600; /*0x1066e742a*/
  if ( v1 != 0 ) /*0x1066e7434*/
    v2 = (char *)(v1 + 280); /*0x1066e7434*/
  return *(_QWORD *)v2; /*0x1066e743b*/
}

// Address: 0x1066e743e | Name: __ZN3RBX7Network6Client10findClientEPKNS_8InstanceEb
__int64 __fastcall RBX::Network::Client::findClient(RBX::Network::Client *this, const RBX::Instance *a2)
{
  RBX::ServiceProvider *ServiceProvider; // rax

  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2); /*0x1066e7442*/
  if ( ServiceProvider != nullptr ) /*0x1066e744a*/
    return *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::Network::Client>(this: ServiceProvider); /*0x1066e7454*/
  else
    return 0; /*0x1066e7459*/
}

// Address: 0x1066e745e | Name: __ZN3RBX7Network6Client39handleConnectionStateAndMetricReportingEPKcbS3_NS0_15ConnectionStateEb
void __fastcall RBX::Network::Client::handleConnectionStateAndMetricReporting(
        RBX::Network::ConcurrentRakPeer **this,
        const char *a2,
        unsigned __int8 a3,
        char *a4,
        int a5,
        char a6)
{
  __int64 v11; // rdx
  __int64 v12; // rcx
  RBX::Time *v13; // rdi
  void *v14; // rsi
  unsigned __int8 v15; // al
  RBX::Time *v16; // rdi
  bool v17; // r12
  double v18; // xmm0_8
  unsigned __int64 v19; // rax
  unsigned __int64 v20; // r13
  const char *v21; // rdx
  __int64 *v22; // rsi
  char *v23; // rcx
  __int64 v24; // r8
  void *v25; // rsi
  __int64 v26; // r8
  char *v27; // rcx
  RBX *v28; // rdi
  __int128 *RobloxChannelName; // rax
  unsigned int v30; // r8d
  __int64 v31; // r8
  char *v32; // rax
  __int64 v33; // r8
  char *v34; // rcx
  __int64 v35; // r8
  unsigned __int8 *v36; // rcx
  __m128d v37; // xmm0
  const char *v38; // rdx
  RBX::Time *v39; // rdi
  RBX::Network::ConcurrentRakPeer *v40; // xmm0_8
  __int64 v41; // rax
  _BYTE v42[72]; // [rsp+8h] [rbp-298h] BYREF
  _BYTE v43[496]; // [rsp+50h] [rbp-250h] BYREF
  _BYTE v44[16]; // [rsp+240h] [rbp-60h] BYREF
  void *v45; // [rsp+250h] [rbp-50h]
  unsigned __int8 v46; // [rsp+258h] [rbp-48h] BYREF
  char v47; // [rsp+259h] [rbp-47h] BYREF
  __int64 v48; // [rsp+260h] [rbp-40h]
  void *v49; // [rsp+268h] [rbp-38h]
  bool v50[44]; // [rsp+274h] [rbp-2Ch]

  if ( a5 != 0 ) /*0x1066e7481*/
  {
    RBX::Network::Client::updateServerConnectionState((RBX::DataModel *)this, __s1: a4); /*0x1066e7496*/
    LOBYTE(v12) = (*((_DWORD *)this + 158) < 3) & a3 & (a5 == 3); /*0x1066e74af*/
    if ( (_BYTE)v12 == 1 ) /*0x1066e74b4*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v44, a2, a3: v11, a4: v12); /*0x1066e74bd*/
      RBX::Time::nowFastSec(this: v13); /*0x1066e74c2*/
      RBX::Network::Client::reportJoinFailure(a1: this, a2: v44); /*0x1066e74ce*/
      if ( (v44[0] & 1) != 0 ) /*0x1066e74d7*/
        operator delete(a1: (RBX::Memory *)v45, a2: v14); /*0x1066e74dd*/
    }
  }
  if ( *((_DWORD *)this + 1236) != 0 )
  {
    if ( a6 != 0 ) /*0x1066e74f2*/
      RSL::Mutex::lock(this: (RSL::Mutex *)(this + 576)); /*0x1066e74fb*/
    v15 = RBX::Network::Client::noViableConnectionsLeft((RBX::Network::Client *)this); /*0x1066e7503*/
    if ( (v15 | a3 ^ 1) == 1 )
    {
      v17 = v15; /*0x1066e7519*/
      RBX::Time::nowFast(this: v16); /*0x1066e751c*/
      v19 = (unsigned int)(int)((v18 - *((double *)this + 83)) * 1000.0); /*0x1066e7531*/
      v20 = v19; /*0x1066e754d*/
      if ( v17 && *((_BYTE *)this + 603) != 1 ) /*0x1066e755c*/
        v21 = "ConnectionFailure"; /*0x1066e7563*/
      else
        v21 = a2; /*0x1066e755e*/
      *(_DWORD *)v50 = v17; /*0x1066e7578*/
      RBX::Network::Client::reportNetworkMetricToDiag( /*0x1066e757e*/
        (RBX::Network::Client *)this,
        a2: "StudioNetwork",
        a3: v21,
        a4: v17,
        a5: v19);
      if ( DFFlag::EnableV2POCStat == 1 )
      {
        v22 = &RBX::Telemetry::kFinishedReceivingInitialGameData; /*0x1066e7597*/
        if ( *((_BYTE *)this + 602) != 0 ) /*0x1066e75a5*/
          v22 = &RBX::Telemetry::kEventAfterEndOfSession; /*0x1066e75a5*/
        RBX::Telemetry::RobloxTelemetryStat::RobloxTelemetryStat(a1: (__int64)v42, a2: (__int64)v22); /*0x1066e75b0*/
        RBX::Telemetry::FieldsContainer::addField(a1: v43, a2: "Prefix", a3: 6, a4: "StudioNetwork", a5: 1); /*0x1066e75d5*/
        RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)&v46); /*0x1066e75de*/
        if ( (v46 & 1) != 0 ) /*0x1066e75ec*/
        {
          v23 = (char *)v49; /*0x1066e75ee*/
          v24 = v48; /*0x1066e75f2*/
        }
        else
        {
          v24 = v46 >> 1; /*0x1066e75f8*/
          v23 = &v47; /*0x1066e75fb*/
        }
        RBX::Telemetry::FieldsContainer::addField(a1: v43, a2: "Platform", a3: 8, a4: v23, a5: v24, a6: 1); /*0x1066e7618*/
        if ( (v46 & 1) != 0 ) /*0x1066e7621*/
          operator delete(a1: (RBX::Memory *)v49, a2: v25); /*0x1066e7627*/
        RBX::Telemetry::FieldsContainer::addField(a1: v43, a2: "DatacenterId", a3: 12, a4: *((int *)this + 148), a5: 1); /*0x1066e764c*/
        if ( (RBX::Analytics::location & 1) != 0 ) /*0x1066e7660*/
        {
          v26 = *((_QWORD *)&RBX::Analytics::location + 1); /*0x1066e7662*/
          v27 = (char *)qword_10D50FFF8; /*0x1066e7666*/
        }
        else
        {
          v26 = (unsigned __int8)RBX::Analytics::location >> 1; /*0x1066e766c*/
          v27 = (char *)&RBX::Analytics::location + 1; /*0x1066e766f*/
        }
        RBX::Telemetry::FieldsContainer::addField(a1: v43, a2: "Country", a3: 7, a4: v27, a5: v26, a6: 1); /*0x1066e768b*/
        RobloxChannelName = RBX::GetRobloxChannelName(this: v28); /*0x1066e7690*/
        v30 = *(unsigned __int8 *)RobloxChannelName; /*0x1066e7695*/
        if ( (v30 & 1) != 0 ) /*0x1066e769d*/
        {
          v31 = *((_QWORD *)RobloxChannelName + 1); /*0x1066e769f*/
          v32 = *((char **)RobloxChannelName + 2); /*0x1066e76a3*/
        }
        else
        {
          v32 = (char *)RobloxChannelName + 1; /*0x1066e76a9*/
          v31 = v30 >> 1; /*0x1066e76ac*/
        }
        RBX::Telemetry::FieldsContainer::addField(a1: v43, a2: "channel", a3: 7, a4: v32, a5: v31, a6: 1); /*0x1066e76cb*/
        if ( DFFlag::AddAppVersionIntoV2POCStat == 1 ) /*0x1066e76d7*/
        {
          if ( (RBX::Analytics::appVersion & 1) != 0 ) /*0x1066e76e8*/
          {
            v33 = *((_QWORD *)&RBX::Analytics::appVersion + 1); /*0x1066e76ea*/
            v34 = (char *)qword_10D50FFC8; /*0x1066e76ee*/
          }
          else
          {
            v33 = (unsigned __int8)RBX::Analytics::appVersion >> 1; /*0x1066e76f4*/
            v34 = (char *)&RBX::Analytics::appVersion + 1; /*0x1066e76f7*/
          }
          RBX::Telemetry::FieldsContainer::addField(a1: v43, a2: "appVersion", a3: 10, a4: v34, a5: v33, a6: 1); /*0x1066e7713*/
        }
        if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
        {
          v35 = (SFString::RCCChannelName[0] & 1) != 0
              ? *(_QWORD *)&SFString::RCCChannelName[8]
              : SFString::RCCChannelName[0] >> 1;
          if ( v35 != 0 ) /*0x1066e7741*/
          {
            if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1066e7745*/
              v36 = *(unsigned __int8 **)&SFString::RCCChannelName[16]; /*0x1066e7747*/
            else
              v36 = &SFString::RCCChannelName[1]; /*0x1066e774d*/
            RBX::Telemetry::FieldsContainer::addField(a1: v43, a2: "rccChannelName", a3: 14, a4: v36, a5: v35, a6: 1); /*0x1066e7769*/
          }
        }
        v37 = _mm_sub_pd( /*0x1066e777b*/
                (__m128d)_mm_unpacklo_epi32((__m128i)v20, (__m128i)xmmword_108F2F9A0),
                (__m128d)xmmword_108F2F9B0);
        RBX::Telemetry::RobloxTelemetryStat::setValue( /*0x1066e778e*/
          this: (RBX::Telemetry::RobloxTelemetryStat *)v42,
          a2: _mm_hadd_pd(v37, v37).f64[0]);
        RBX::Telemetry::RobloxTelemetryStat::send(this: (RBX::Telemetry::RobloxTelemetryStat *)v42); /*0x1066e779a*/
        RBX::Telemetry::RobloxTelemetryStat::~RobloxTelemetryStat(this: (RBX::Telemetry::RobloxTelemetryStat *)v42); /*0x1066e77ad*/
      }
      if ( DFInt::ClientNetworkInfluxHundredthsPercentage != 0 ) /*0x1066e77b9*/
      {
        if ( v17 && *((_BYTE *)this + 603) != 1 ) /*0x1066e77c7*/
          v38 = "ConnectionFailure"; /*0x1066e77ce*/
        else
          v38 = a2; /*0x1066e77c9*/
        RBX::Network::Client::reportClientLevelNetworkMetricToInflux( /*0x1066e77e5*/
          (RBX::Network::Client *)this,
          a2: "StudioNetwork",
          a3: v38,
          a4: v50[0],
          a5: v20);
      }
      *((_BYTE *)this + 602) |= v17; /*0x1066e77ea*/
      std::string::assign(a1: this + 80, a2); /*0x1066e77fb*/
      RBX::Time::nowFast(this: v39); /*0x1066e7800*/
      *(this + 83) = v40; /*0x1066e7805*/
      v41 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x1066e7814*/
      (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v41 + 960LL))(a1: v41, a2: 0); /*0x1066e7821*/
    }
    if ( DFInt::ClientNetworkInfluxHundredthsPercentage != 0 /*0x1066e783a*/
      && (unsigned __int8)RBX::Network::Client::reportPerServerMetric((RBX::Network::Client *)this) != 0 )
    {
      RBX::Network::Client::reportConnectionLevelNetworkMetricToInflux( /*0x1066e7846*/
        (RBX::Network::Client *)this,
        a2: "StudioNetworkDetailed");
      *((_BYTE *)this + 4976) = 1; /*0x1066e784b*/
    }
    if ( a6 != 0 ) /*0x1066e7855*/
      RSL::Mutex::unlock(this: (RSL::Mutex *)(this + 576)); /*0x1066e7861*/
  }
}

// Address: 0x1066e78c0 | Name: __ZN3RBX7Network6Client27updateServerConnectionStateEPKcNS0_15ConnectionStateES3_b
__int64 __fastcall RBX::Network::Client::updateServerConnectionState(
        RBX::DataModel *this,
        char *__s1,
        __int32 a3,
        __int64 a4,
        char a5)
{
  __int64 v8; // rax
  __int64 v9; // rdi
  unsigned int v10; // r14d
  unsigned __int64 v11; // rax
  __int64 v12; // r12
  __int64 v13; // rdi
  RBX::Instance *v14; // rsi
  RBX::DataModel *v15; // rax
  const char *v16; // rsi
  __int64 v17; // rdi
  RBX::RbxDbgInfo *v18; // rdi
  __int32 v22; // [rsp+Ch] [rbp-444h]
  char __s2[1040]; // [rsp+10h] [rbp-440h] BYREF

  if ( FFlag::ConnectViaConnectionInternal == 1 ) /*0x1066e78fc*/
  {
    v8 = *((_QWORD *)this + 575); /*0x1066e78fe*/
    if ( v8 != 0 ) /*0x1066e7908*/
      _InterlockedExchange((volatile __int32 *)(v8 + 1412), a3); /*0x1066e790d*/
  }
  if ( a5 != 0 ) /*0x1066e791d*/
    RSL::Mutex::lock(this: (RBX::DataModel *)((char *)this + 4608)); /*0x1066e7926*/
  v22 = a3; /*0x1066e792b*/
  v9 = *((_QWORD *)this + 619); /*0x1066e7932*/
  if ( *((_QWORD *)this + 620) != v9 )
  {
    v10 = 1; /*0x1066e7946*/
    v11 = 0; /*0x1066e794c*/
    while ( 1 ) /*0x1066e7955*/
    {
      v12 = 88 * v11; /*0x1066e7955*/
      RBX::Network::ConnectionInfo::ToStringN( /*0x1066e796f*/
        this: (RBX::Network::ConnectionInfo *)(88 * v11 + v9),
        a2: true,
        a3: __s2,
        a4: 1025,
        a5: 124);
      if ( strcmp(__s1, __s2) == 0 ) /*0x1066e7981*/
        break; /*0x1066e7981*/
      v11 = v10; /*0x1066e7983*/
      v9 = *((_QWORD *)this + 619); /*0x1066e7986*/
      ++v10; /*0x1066e79a9*/
      if ( 0x2E8BA2E8BA2E8BA3LL * ((*((_QWORD *)this + 620) - v9) >> 3) <= v11 ) /*0x1066e79af*/
        goto LABEL_21; /*0x1066e79af*/
    }
    if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
      FLog::FastLogFormatted(
        a1: DFLog::NetworkTrace,
        a2: qword_10D7BB068,
        a3: (unsigned int)"[DFLog::NetworkTrace] updateServerConnectionState::: sc(%s).old_state = %d -> new_state = %d :: returning false",
        a4: (unsigned int)__s2,
        a5: *(_DWORD *)(*((_QWORD *)this + 619) + v12 + 36),
        a6: v22);
    v13 = *((_QWORD *)this + 619) + v12 + 40; /*0x1066e7a10*/
    *(_DWORD *)(v13 - 4) = v22; /*0x1066e7a14*/
    std::string::assign(a1: v13, a2: a4); /*0x1066e7a1f*/
    if ( *(_DWORD *)(*((_QWORD *)this + 619) + v12 + 36) == 2 ) /*0x1066e7a31*/
    {
      v15 = (RBX::DataModel *)RBX::DataModel::get(this, a2: v14); /*0x1066e7a36*/
      if ( v15 != nullptr && (unsigned __int8)RBX::DataModel::getShouldSetGlobalTelemetryInfo(this: v15) != 0 ) /*0x1066e7a4a*/
      {
        v17 = *((_QWORD *)this + 619) + v12; /*0x1066e7a53*/
        if ( (*(_BYTE *)v17 & 1) != 0 ) /*0x1066e7a5c*/
          v18 = *(RBX::RbxDbgInfo **)(v17 + 16); /*0x1066e7a63*/
        else
          v18 = (RBX::RbxDbgInfo *)(v17 + 1); /*0x1066e7a5e*/
        RBX::RbxDbgInfo::SetServerIP(this: v18, a2: v16); /*0x1066e7a67*/
      }
      *((_BYTE *)this + 603) = 1; /*0x1066e7a6c*/
    }
  }
LABEL_21:
  if ( a5 != 0 ) /*0x1066e7a7a*/
    RSL::Mutex::unlock(this: (RBX::DataModel *)((char *)this + 4608)); /*0x1066e7a86*/
  return __stack_chk_guard; /*0x1066e7a9b*/
}

// Address: 0x1066e7ab2 | Name: __ZN3RBX7Network6Client17reportJoinFailureENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEd
__int64 __fastcall RBX::Network::Client::reportJoinFailure(RBX::DataModel *a1, void **a2, double a3)
{
  __int64 Dangerous_DEPRECATED; // rax
  unsigned __int64 v5; // rsi
  __int64 v6; // rbx
  __int64 v7; // rax
  void *v8; // rsi
  __int64 v9; // rax
  __int128 v11; // [rsp+0h] [rbp-80h] BYREF
  void *v12; // [rsp+10h] [rbp-70h]
  double v13; // [rsp+18h] [rbp-68h]
  double v14; // [rsp+28h] [rbp-58h]
  _BYTE v15[32]; // [rsp+30h] [rbp-50h] BYREF
  _BYTE *v16; // [rsp+50h] [rbp-30h]

  v14 = a3; /*0x1066e7abd*/
  Dangerous_DEPRECATED = RBX::DataModel::getDangerous_DEPRECATED(this: a1, (RBX::Instance *)a2); /*0x1066e7ad3*/
  if ( Dangerous_DEPRECATED == 0 ) /*0x1066e7adb*/
    return __stack_chk_guard; /*0x1066e7adb*/
  v6 = Dangerous_DEPRECATED; /*0x1066e7ae1*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1066e7ae8*/
  {
    std::string::__init_copy_ctor_external(a1: &v11, a2: a2[2], a3: a2[1]); /*0x1066e7b08*/
  }
  else
  {
    v12 = a2[2]; /*0x1066e7aee*/
    v11 = *(_OWORD *)a2; /*0x1066e7af6*/
  }
  v13 = v14; /*0x1066e7b12*/
  v16 = nullptr; /*0x1066e7b17*/
  v7 = operator new(a1: (RBX::Memory *)0x28, a2: v5); /*0x1066e7b24*/
  *(_QWORD *)v7 = &off_10CAA7BE8; /*0x1066e7b30*/
  *(_QWORD *)(v7 + 24) = v12; /*0x1066e7b37*/
  *(_OWORD *)(v7 + 8) = v11; /*0x1066e7b3f*/
  v11 = 0; /*0x1066e7b46*/
  v12 = nullptr; /*0x1066e7b4a*/
  *(double *)(v7 + 32) = v14; /*0x1066e7b57*/
  v16 = (_BYTE *)v7; /*0x1066e7b60*/
  RBX::DataModel::submitTask(a1: v6, a2: v15, a3: 1); /*0x1066e7b6f*/
  if ( v16 == v15 ) /*0x1066e7b7b*/
  {
    v9 = 32; /*0x1066e7b89*/
    goto LABEL_9; /*0x1066e7b89*/
  }
  v9 = 40; /*0x1066e7b7d*/
  if ( v16 != nullptr ) /*0x1066e7b85*/
LABEL_9:
    (*(void (**)(void))(*(_QWORD *)v16 + v9))(); /*0x1066e7b8e*/
  if ( (v11 & 1) != 0 ) /*0x1066e7b98*/
    operator delete(a1: (RBX::Memory *)v12, a2: v8); /*0x1066e7b9e*/
  return __stack_chk_guard; /*0x1066e7bb3*/
}

// Address: 0x1066e7c04 | Name: __ZNK3RBX7Network6Client16isStandardPlayerEv
bool __fastcall RBX::Network::Client::isStandardPlayer(RBX::Network::Client *this)
{
  return *((_DWORD *)this + 1236) == 0; /*0x1066e7c12*/
}

// Address: 0x1066e7c14 | Name: __ZN3RBX7Network6Client23noViableConnectionsLeftEv
__int64 __fastcall RBX::Network::Client::noViableConnectionsLeft(RBX::Network::Client *this)
{
  unsigned int v1; // ebx
  __int64 v2; // rax
  unsigned int v3; // r9d
  __int64 v4; // rcx

  v2 = *((_QWORD *)this + 619); /*0x1066e7c1a*/
  LOBYTE(v1) = 1; /*0x1066e7c28*/
  while ( v2 != *((_QWORD *)this + 620) )
  {
    v3 = *(_DWORD *)(v2 + 36); /*0x1066e7c2f*/
    if ( v3 <= 2 )
    {
      if ( (unsigned __int8)DFLog::NetworkTrace < 6u || BYTE1(DFLog::NetworkTrace) < 3u )
      {
        return 0; /*0x1066e7c70*/
      }
      else
      {
        if ( (*(_BYTE *)v2 & 1) != 0 ) /*0x1066e7c68*/
          v4 = *(_QWORD *)(v2 + 16); /*0x1066e7c74*/
        else
          LODWORD(v4) = v2 + 1; /*0x1066e7c6a*/
        v1 = 0; /*0x1066e7c83*/
        FLog::FastLogFormatted(
          a1: DFLog::NetworkTrace,
          a2: qword_10D7BB068,
          a3: (unsigned int)"[DFLog::NetworkTrace] noViableConnectionsLeft::: sc(%s:%d).state = %d :: returning false",
          a4: v4,
          a5: *(_DWORD *)(v2 + 24),
          a6: v3);
      }
      return v1; /*0x1066e7c87*/
    }
    v2 += 88; /*0x1066e7c39*/
  }
  return v1; /*0x1066e7c92*/
}

// Address: 0x1066e7c96 | Name: __ZN3RBX7Network6Client25reportNetworkMetricToDiagEPKcS3_by
__int64 __fastcall RBX::Network::Client::reportNetworkMetricToDiag(
        RBX::Network::Client *this,
        const char *a2,
        const char *a3,
        int a4,
        __int64 a5,
        __int64 a6,
        double a7,
        __m128 a8,
        __m128 a9,
        __m128 a10,
        __m128 a11,
        __m128 a12,
        __m128 a13,
        __m128 a14)
{
  const char *v15; // rbx
  __int64 v18; // rdi
  __int64 v19; // rsi
  __m128d v20; // xmm1
  __int64 v21; // r15
  __m128 v22; // xmm1
  __m128 *v23; // r13
  signed __int64 v24; // r13
  unsigned __int64 v25; // rsi
  __int64 v26; // rax
  __int64 v27; // rdx
  __int64 v28; // r12
  __int64 v29; // r14
  __int64 v30; // r12
  void *v31; // r13
  void *v32; // r14
  void *v33; // rax
  __int64 v34; // rcx
  void *v35; // rsi
  __int64 v36; // r9
  __m128 v37; // xmm0
  __m128 v38; // xmm1
  __m128 v39; // xmm2
  __m128 v40; // xmm3
  __m128 v41; // xmm4
  __m128 v42; // xmm5
  __m128 v43; // xmm6
  __m128 v44; // xmm7
  char *v45; // r8
  __int64 v46; // rdi
  void *v47; // rsi
  __int64 v48; // r9
  __m128 v49; // xmm1
  __m128 v50; // xmm2
  __m128 v51; // xmm3
  __m128 v52; // xmm4
  __m128 v53; // xmm5
  __m128 v54; // xmm6
  __m128 v55; // xmm7
  __m128 *v56; // r13
  __m128 v57; // xmm0
  signed __int64 v58; // r13
  unsigned __int64 v59; // rsi
  __int64 v60; // rax
  __int64 v61; // rdx
  __int64 v62; // r12
  __int64 v63; // r14
  __int64 v64; // r12
  void *v65; // r13
  void *v66; // r14
  void *v67; // rax
  __int64 v68; // rcx
  RBX::DataModel *v69; // r13
  __int64 v70; // rdi
  __int64 v71; // rsi
  __int64 v72; // r9
  __m128 v73; // xmm1
  __m128 v74; // xmm2
  __m128 v75; // xmm3
  __m128 v76; // xmm4
  __m128 v77; // xmm5
  __m128 v78; // xmm6
  __m128 v79; // xmm7
  __m128 *v80; // r13
  __m128 v81; // xmm0
  signed __int64 v82; // r13
  unsigned __int64 v83; // rsi
  __int64 v84; // rax
  __int64 v85; // rdx
  __int64 v86; // r12
  __int64 v87; // r14
  __int64 v88; // r12
  void *v89; // r13
  void *v90; // r14
  void *v91; // rax
  __int64 v92; // rcx
  void *v93; // rsi
  char *v94; // r8
  __int64 v95; // rdi
  void *v96; // rsi
  __m128 *v97; // r13
  signed __int64 v98; // r13
  unsigned __int64 v99; // rsi
  __int64 v100; // rax
  __int64 v101; // rdx
  __int64 v102; // r12
  __int64 v103; // r14
  __int64 v104; // r12
  void *v105; // r13
  void *v106; // r14
  void *v107; // rax
  __int64 v108; // rcx
  RBX::DataModel *v109; // r13
  __int64 Dangerous_DEPRECATED; // rax
  __int64 v111; // r8
  __int64 v112; // r9
  __m128 v113; // xmm0
  __m128 v114; // xmm1
  __m128 v115; // xmm2
  __m128 v116; // xmm3
  __m128 v117; // xmm4
  __m128 v118; // xmm5
  __m128 v119; // xmm6
  __m128 v120; // xmm7
  __int64 v121; // rdi
  __int64 v122; // rsi
  __m128 *v123; // r13
  signed __int64 v124; // r13
  unsigned __int64 v125; // rsi
  __int64 v126; // rax
  __int64 v127; // rdx
  __int64 v128; // r12
  __int64 v129; // r14
  __int64 v130; // r12
  void *v131; // r13
  void *v132; // r14
  void *v133; // rax
  __int64 v134; // rcx
  void *v135; // rsi
  __int64 v136; // rax
  const char *v137; // rdx
  unsigned __int64 v138; // r14
  __int64 v139; // rdi
  __int64 v140; // rsi
  __int64 v141; // r9
  __m128 v142; // xmm2
  __m128 v143; // xmm3
  __m128 v144; // xmm4
  __m128 v145; // xmm5
  __m128 v146; // xmm6
  __m128 v147; // xmm7
  __m128d v148; // xmm1
  __m128 v149; // xmm1
  __m128 *v150; // r13
  __m128 v151; // xmm0
  __int64 v152; // r14
  signed __int64 v153; // r13
  unsigned __int64 v154; // rsi
  __int64 v155; // rax
  __int64 v156; // rdx
  __int64 v157; // r12
  __int64 v158; // r14
  __int64 v159; // r12
  void *v160; // r13
  void *v161; // r14
  void *v162; // rax
  __int64 v163; // rcx
  void *v164; // rsi
  __int64 v165; // rdi
  __int64 v166; // rsi
  __m128 *v167; // r12
  signed __int64 v168; // r12
  unsigned __int64 v169; // rcx
  __int64 v170; // rax
  __int64 v171; // rdx
  __int64 v172; // rbx
  __int64 v173; // r12
  __int64 v174; // rbx
  __m128 *v175; // r15
  void *v176; // r14
  void *v177; // rax
  __int64 v178; // rcx
  void *v179; // rsi
  char v181; // [rsp+0h] [rbp-E0h]
  char v182; // [rsp+0h] [rbp-E0h]
  char v183; // [rsp+0h] [rbp-E0h]
  char v184; // [rsp+0h] [rbp-E0h]
  char v185; // [rsp+0h] [rbp-E0h]
  char v186; // [rsp+0h] [rbp-E0h]
  char v187; // [rsp+8h] [rbp-D8h] BYREF
  char v188; // [rsp+9h] [rbp-D7h] BYREF
  void *v189; // [rsp+18h] [rbp-C8h]
  _QWORD v190[4]; // [rsp+20h] [rbp-C0h] BYREF
  _QWORD *v191; // [rsp+40h] [rbp-A0h]
  int v192; // [rsp+4Ch] [rbp-94h]
  RBX::DataModel *v193; // [rsp+50h] [rbp-90h]
  __int64 v194; // [rsp+58h] [rbp-88h]
  __m128 v195; // [rsp+60h] [rbp-80h]
  const char *v196; // [rsp+78h] [rbp-68h]
  __m128 v197; // [rsp+80h] [rbp-60h] BYREF
  void *v198; // [rsp+90h] [rbp-50h]
  void *__src[2]; // [rsp+A0h] [rbp-40h] BYREF
  _QWORD v200[6]; // [rsp+B0h] [rbp-30h] BYREF

  v192 = a4; /*0x1066e7cad*/
  v15 = a3; /*0x1066e7cb3*/
  if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
    FLog::FastLogFormatted(
      a1: DFLog::NetworkTrace,
      a2: qword_10D7BB068,
      a3: (unsigned int)"[DFLog::NetworkTrace] Reporting network metric: %s to diag. Time since last metric = %u",
      a4: (_DWORD)a3,
      a5,
      a6);
  *(_OWORD *)__src = 0; /*0x1066e7cf7*/
  v200[0] = 0; /*0x1066e7cfb*/
  v193 = this; /*0x1066e7d0a*/
  if ( *((_BYTE *)this + 602) != 0 ) /*0x1066e7d1a*/
    v15 = "EventAfterEndOfSession"; /*0x1066e7d1a*/
  RBX::format( /*0x1066e7d31*/
    this: (RBX *)&v197,
    a2: "%s_%s",
    a3: (__int64)a2,
    a4: (__int64)v15,
    a5,
    a6,
    a7: (__m128)0LL,
    a8,
    a9,
    a10,
    a11,
    a12,
    a13,
    a14,
    a15: v181);
  v20 = _mm_sub_pd( /*0x1066e7d43*/
          (__m128d)_mm_unpacklo_epi32((__m128i)(unsigned __int64)a5, (__m128i)xmmword_108F2F9A0),
          (__m128d)xmmword_108F2F9B0);
  v21 = 0x7FFFFFFFFFFFFFFLL; /*0x1066e7d4b*/
  v22 = (__m128)_mm_hadd_pd(v20, v20); /*0x1066e7d55*/
  v23 = (__m128 *)__src[1]; /*0x1066e7d5d*/
  v196 = a2; /*0x1066e7d69*/
  v195 = v22; /*0x1066e7d6d*/
  if ( __src[1] >= (void *)v200[0] ) /*0x1066e7d72*/
  {
    v24 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1066e7d9f*/
    if ( (unsigned __int64)(v24 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1066e7daa*/
      std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v18, a2: v19); /*0x1066e8767*/
    v25 = (__int64)(v200[0] - (unsigned __int64)__src[0]) >> 4; /*0x1066e7db6*/
    if ( v25 <= v24 + 1 ) /*0x1066e7dbd*/
      v25 = v24 + 1; /*0x1066e7dbd*/
    if ( v200[0] - (unsigned __int64)__src[0] >= 0x7FFFFFFFFFFFFFE0LL ) /*0x1066e7dce*/
      v25 = 0x7FFFFFFFFFFFFFFLL; /*0x1066e7dce*/
    v191 = v200; /*0x1066e7dd2*/
    if ( v25 != 0 ) /*0x1066e7ddc*/
    {
      v26 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>(a1: v200); /*0x1066e7de1*/
      v28 = v27; /*0x1066e7de6*/
    }
    else
    {
      v26 = 0; /*0x1066e7deb*/
      v28 = 0; /*0x1066e7ded*/
    }
    v29 = v26 + 32 * v24; /*0x1066e7df4*/
    v30 = v26 + 32 * v28; /*0x1066e7dfc*/
    v31 = (void *)(v29 + 32); /*0x1066e7e06*/
    *(_QWORD *)(v29 + 16) = v198; /*0x1066e7e0a*/
    *(__m128 *)v29 = v197; /*0x1066e7e12*/
    v197 = 0; /*0x1066e7e1a*/
    v198 = nullptr; /*0x1066e7e1e*/
    *(_QWORD *)(v29 + 24) = v195.i64[0]; /*0x1066e7e2a*/
    v32 = (void *)(v29 - ((char *)__src[1] - (char *)__src[0])); /*0x1066e7e3b*/
    memcpy(__dst: v32, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1066e7e41*/
    v33 = __src[0]; /*0x1066e7e46*/
    v34 = v200[0]; /*0x1066e7e4a*/
    __src[0] = v32; /*0x1066e7e4e*/
    v190[1] = v33; /*0x1066e7e59*/
    __src[1] = v31; /*0x1066e7e5d*/
    v190[2] = v33; /*0x1066e7e61*/
    v200[0] = v30; /*0x1066e7e65*/
    v190[3] = v34; /*0x1066e7e69*/
    v190[0] = v33; /*0x1066e7e6d*/
    std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1066e7e70*/
    __src[1] = v31; /*0x1066e7e79*/
    a2 = v196; /*0x1066e7e7d*/
    if ( (v197.i8[0] & 1) != 0 ) /*0x1066e7e85*/
      operator delete(a1: (RBX::Memory *)v198, a2: v35); /*0x1066e7e8b*/
  }
  else
  {
    *((_QWORD *)__src[1] + 2) = v198; /*0x1066e7d78*/
    *v23 = v197; /*0x1066e7d80*/
    v23[1].i64[1] = v22.i64[0]; /*0x1066e7d85*/
    __src[1] = &v23[2]; /*0x1066e7d8f*/
  }
  RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)&v187); /*0x1066e7e97*/
  if ( (v187 & 1) != 0 ) /*0x1066e7ea3*/
    v45 = (char *)v189; /*0x1066e7ea5*/
  else
    v45 = &v188; /*0x1066e7eae*/
  RBX::format( /*0x1066e7ec8*/
    this: (RBX *)&v197,
    a2: "%s_%s_Platform_%s",
    a3: (__int64)a2,
    a4: (__int64)v15,
    a5: (__int64)v45,
    a6: v36,
    a7: v37,
    a8: v38,
    a9: v39,
    a10: v40,
    a11: v41,
    a12: v42,
    a13: v43,
    a14: v44,
    a15: v182);
  v56 = (__m128 *)__src[1]; /*0x1066e7ecd*/
  if ( __src[1] >= (void *)v200[0] ) /*0x1066e7ed8*/
  {
    v58 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1066e7f18*/
    if ( (unsigned __int64)(v58 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1066e7f23*/
      std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v46, a2: v47); /*0x1066e876e*/
    v59 = (__int64)(v200[0] - (unsigned __int64)__src[0]) >> 4; /*0x1066e7f2f*/
    if ( v59 <= v58 + 1 ) /*0x1066e7f36*/
      v59 = v58 + 1; /*0x1066e7f36*/
    if ( v200[0] - (unsigned __int64)__src[0] >= 0x7FFFFFFFFFFFFFE0LL ) /*0x1066e7f47*/
      v59 = 0x7FFFFFFFFFFFFFFLL; /*0x1066e7f47*/
    v191 = v200; /*0x1066e7f4b*/
    if ( v59 != 0 ) /*0x1066e7f55*/
    {
      v60 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>(a1: v200); /*0x1066e7f5a*/
      v62 = v61; /*0x1066e7f5f*/
    }
    else
    {
      v60 = 0; /*0x1066e7f64*/
      v62 = 0; /*0x1066e7f66*/
    }
    v63 = v60 + 32 * v58; /*0x1066e7f6d*/
    v64 = v60 + 32 * v62; /*0x1066e7f75*/
    v65 = (void *)(v63 + 32); /*0x1066e7f7f*/
    *(_QWORD *)(v63 + 16) = v198; /*0x1066e7f83*/
    *(__m128 *)v63 = v197; /*0x1066e7f8b*/
    v197 = 0; /*0x1066e7f93*/
    v198 = nullptr; /*0x1066e7f97*/
    *(_QWORD *)(v63 + 24) = v195.i64[0]; /*0x1066e7fa3*/
    v66 = (void *)(v63 - ((char *)__src[1] - (char *)__src[0])); /*0x1066e7fb4*/
    memcpy(__dst: v66, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1066e7fba*/
    v67 = __src[0]; /*0x1066e7fbf*/
    v68 = v200[0]; /*0x1066e7fc3*/
    __src[0] = v66; /*0x1066e7fc7*/
    v190[1] = v67; /*0x1066e7fd2*/
    __src[1] = v65; /*0x1066e7fd6*/
    v190[2] = v67; /*0x1066e7fda*/
    v200[0] = v64; /*0x1066e7fde*/
    v190[3] = v68; /*0x1066e7fe2*/
    v190[0] = v67; /*0x1066e7fe6*/
    std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1066e7fe9*/
    __src[1] = v65; /*0x1066e7ff2*/
    a2 = v196; /*0x1066e7ff6*/
    if ( (v197.i8[0] & 1) != 0 ) /*0x1066e7ffe*/
      operator delete(a1: (RBX::Memory *)v198, a2: v47); /*0x1066e8004*/
  }
  else
  {
    *((_QWORD *)__src[1] + 2) = v198; /*0x1066e7ede*/
    *v56 = v197; /*0x1066e7ee6*/
    v197 = 0; /*0x1066e7eee*/
    v198 = nullptr; /*0x1066e7ef2*/
    v57 = v195; /*0x1066e7efa*/
    v56[1].i64[1] = v195.i64[0]; /*0x1066e7efe*/
    __src[1] = &v56[2]; /*0x1066e7f08*/
  }
  v69 = v193; /*0x1066e8010*/
  if ( (v187 & 1) != 0 ) /*0x1066e8017*/
    operator delete(a1: (RBX::Memory *)v189, a2: v47); /*0x1066e8020*/
  RBX::format( /*0x1066e803f*/
    this: (RBX *)&v197,
    a2: "%s_%s_DatacenterId_%d",
    a3: (__int64)a2,
    a4: (__int64)v15,
    a5: *((unsigned int *)v69 + 148),
    a6: v48,
    a7: v57,
    a8: v49,
    a9: v50,
    a10: v51,
    a11: v52,
    a12: v53,
    a13: v54,
    a14: v55,
    a15: v183);
  v80 = (__m128 *)__src[1]; /*0x1066e8044*/
  if ( __src[1] >= (void *)v200[0] ) /*0x1066e804f*/
  {
    v82 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1066e8080*/
    if ( (unsigned __int64)(v82 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1066e808b*/
      std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v70, a2: v71); /*0x1066e8775*/
    v83 = (__int64)(v200[0] - (unsigned __int64)__src[0]) >> 4; /*0x1066e8097*/
    if ( v83 <= v82 + 1 ) /*0x1066e809e*/
      v83 = v82 + 1; /*0x1066e809e*/
    if ( v200[0] - (unsigned __int64)__src[0] >= 0x7FFFFFFFFFFFFFE0LL ) /*0x1066e80af*/
      v83 = 0x7FFFFFFFFFFFFFFLL; /*0x1066e80af*/
    v191 = v200; /*0x1066e80b3*/
    if ( v83 != 0 ) /*0x1066e80bd*/
    {
      v84 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>(a1: v200); /*0x1066e80c2*/
      v86 = v85; /*0x1066e80c7*/
    }
    else
    {
      v84 = 0; /*0x1066e80cc*/
      v86 = 0; /*0x1066e80ce*/
    }
    v87 = v84 + 32 * v82; /*0x1066e80d5*/
    v88 = v84 + 32 * v86; /*0x1066e80dd*/
    v89 = (void *)(v87 + 32); /*0x1066e80e7*/
    *(_QWORD *)(v87 + 16) = v198; /*0x1066e80eb*/
    *(__m128 *)v87 = v197; /*0x1066e80f3*/
    v197 = 0; /*0x1066e80fb*/
    v198 = nullptr; /*0x1066e80ff*/
    *(_QWORD *)(v87 + 24) = v195.i64[0]; /*0x1066e810b*/
    v90 = (void *)(v87 - ((char *)__src[1] - (char *)__src[0])); /*0x1066e811c*/
    memcpy(__dst: v90, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1066e8122*/
    v91 = __src[0]; /*0x1066e8127*/
    v92 = v200[0]; /*0x1066e812b*/
    __src[0] = v90; /*0x1066e812f*/
    v190[1] = v91; /*0x1066e813a*/
    __src[1] = v89; /*0x1066e813e*/
    v190[2] = v91; /*0x1066e8142*/
    v200[0] = v88; /*0x1066e8146*/
    v190[3] = v92; /*0x1066e814a*/
    v190[0] = v91; /*0x1066e814e*/
    std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1066e8151*/
    __src[1] = v89; /*0x1066e815a*/
    a2 = v196; /*0x1066e815e*/
    if ( (v197.i8[0] & 1) != 0 ) /*0x1066e8166*/
      operator delete(a1: (RBX::Memory *)v198, a2: v93); /*0x1066e816c*/
  }
  else
  {
    *((_QWORD *)__src[1] + 2) = v198; /*0x1066e8055*/
    *v80 = v197; /*0x1066e805d*/
    v81 = v195; /*0x1066e8062*/
    v80[1].i64[1] = v195.i64[0]; /*0x1066e8066*/
    __src[1] = &v80[2]; /*0x1066e8070*/
  }
  if ( (RBX::Analytics::location & 1) != 0 ) /*0x1066e817c*/
    v94 = (char *)qword_10D50FFF8; /*0x1066e817e*/
  else
    v94 = (char *)&RBX::Analytics::location + 1; /*0x1066e8184*/
  RBX::format( /*0x1066e819a*/
    this: (RBX *)&v197,
    a2: "%s_%s_Country_%s",
    a3: (__int64)a2,
    a4: (__int64)v15,
    a5: (__int64)v94,
    a6: v72,
    a7: v81,
    a8: v73,
    a9: v74,
    a10: v75,
    a11: v76,
    a12: v77,
    a13: v78,
    a14: v79,
    a15: v184);
  v97 = (__m128 *)__src[1]; /*0x1066e819f*/
  if ( __src[1] >= (void *)v200[0] ) /*0x1066e81aa*/
  {
    v98 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1066e81db*/
    if ( (unsigned __int64)(v98 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1066e81e6*/
      std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v95, a2: v96); /*0x1066e877c*/
    v99 = (__int64)(v200[0] - (unsigned __int64)__src[0]) >> 4; /*0x1066e81f2*/
    if ( v99 <= v98 + 1 ) /*0x1066e81f9*/
      v99 = v98 + 1; /*0x1066e81f9*/
    if ( v200[0] - (unsigned __int64)__src[0] >= 0x7FFFFFFFFFFFFFE0LL ) /*0x1066e820a*/
      v99 = 0x7FFFFFFFFFFFFFFLL; /*0x1066e820a*/
    v191 = v200; /*0x1066e820e*/
    if ( v99 != 0 ) /*0x1066e8218*/
    {
      v100 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>(a1: v200); /*0x1066e821d*/
      v102 = v101; /*0x1066e8222*/
    }
    else
    {
      v100 = 0; /*0x1066e8227*/
      v102 = 0; /*0x1066e8229*/
    }
    v103 = v100 + 32 * v98; /*0x1066e8230*/
    v104 = v100 + 32 * v102; /*0x1066e8238*/
    v105 = (void *)(v103 + 32); /*0x1066e8242*/
    *(_QWORD *)(v103 + 16) = v198; /*0x1066e8246*/
    *(__m128 *)v103 = v197; /*0x1066e824e*/
    v197 = 0; /*0x1066e8256*/
    v198 = nullptr; /*0x1066e825a*/
    *(_QWORD *)(v103 + 24) = v195.i64[0]; /*0x1066e8266*/
    v106 = (void *)(v103 - ((char *)__src[1] - (char *)__src[0])); /*0x1066e8277*/
    memcpy(__dst: v106, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1066e827d*/
    v107 = __src[0]; /*0x1066e8282*/
    v108 = v200[0]; /*0x1066e8286*/
    __src[0] = v106; /*0x1066e828a*/
    v190[1] = v107; /*0x1066e8295*/
    __src[1] = v105; /*0x1066e8299*/
    v190[2] = v107; /*0x1066e829d*/
    v200[0] = v104; /*0x1066e82a1*/
    v190[3] = v108; /*0x1066e82a5*/
    v190[0] = v107; /*0x1066e82a9*/
    std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1066e82ac*/
    __src[1] = v105; /*0x1066e82b5*/
    a2 = v196; /*0x1066e82b9*/
    if ( (v197.i8[0] & 1) != 0 ) /*0x1066e82c1*/
      operator delete(a1: (RBX::Memory *)v198, a2: v96); /*0x1066e82c7*/
  }
  else
  {
    *((_QWORD *)__src[1] + 2) = v198; /*0x1066e81b0*/
    *v97 = v197; /*0x1066e81b8*/
    v97[1].i64[1] = v195.i64[0]; /*0x1066e81c1*/
    __src[1] = &v97[2]; /*0x1066e81cb*/
  }
  v109 = v193; /*0x1066e82cc*/
  Dangerous_DEPRECATED = RBX::DataModel::getDangerous_DEPRECATED(this: v193, a2: (RBX::Instance *)v96); /*0x1066e82d6*/
  if ( Dangerous_DEPRECATED != 0 ) /*0x1066e82de*/
    v194 = *(_QWORD *)(Dangerous_DEPRECATED + 840); /*0x1066e82e7*/
  else
    v194 = 0; /*0x1066e82f0*/
  if ( FFlag::DebugClientNetworkPerPlaceMetrics == 1 ) /*0x1066e8302*/
  {
    RBX::format( /*0x1066e8322*/
      this: (RBX *)&v197,
      a2: "%s_%s_PlaceId_%lld",
      a3: (__int64)a2,
      a4: (__int64)v15,
      a5: v194,
      a6: v112,
      a7: v113,
      a8: v114,
      a9: v115,
      a10: v116,
      a11: v117,
      a12: v118,
      a13: v119,
      a14: v120,
      a15: v185);
    v123 = (__m128 *)__src[1]; /*0x1066e8327*/
    if ( __src[1] >= (void *)v200[0] ) /*0x1066e8332*/
    {
      v124 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1066e8363*/
      if ( (unsigned __int64)(v124 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1066e836e*/
        std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v121, a2: v122); /*0x1066e8783*/
      v125 = (__int64)(v200[0] - (unsigned __int64)__src[0]) >> 4; /*0x1066e837a*/
      if ( v125 <= v124 + 1 ) /*0x1066e8381*/
        v125 = v124 + 1; /*0x1066e8381*/
      if ( v200[0] - (unsigned __int64)__src[0] >= 0x7FFFFFFFFFFFFFE0LL ) /*0x1066e8392*/
        v125 = 0x7FFFFFFFFFFFFFFLL; /*0x1066e8392*/
      v191 = v200; /*0x1066e8396*/
      if ( v125 != 0 ) /*0x1066e83a0*/
      {
        v126 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>(a1: v200); /*0x1066e83a5*/
        v128 = v127; /*0x1066e83aa*/
      }
      else
      {
        v126 = 0; /*0x1066e83af*/
        v128 = 0; /*0x1066e83b1*/
      }
      v129 = v126 + 32 * v124; /*0x1066e83b8*/
      v130 = v126 + 32 * v128; /*0x1066e83c0*/
      v131 = (void *)(v129 + 32); /*0x1066e83ca*/
      *(_QWORD *)(v129 + 16) = v198; /*0x1066e83ce*/
      *(__m128 *)v129 = v197; /*0x1066e83d6*/
      v197 = 0; /*0x1066e83de*/
      v198 = nullptr; /*0x1066e83e2*/
      *(_QWORD *)(v129 + 24) = v195.i64[0]; /*0x1066e83ee*/
      v132 = (void *)(v129 - ((char *)__src[1] - (char *)__src[0])); /*0x1066e83ff*/
      memcpy(__dst: v132, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1066e8405*/
      v133 = __src[0]; /*0x1066e840a*/
      v134 = v200[0]; /*0x1066e840e*/
      __src[0] = v132; /*0x1066e8412*/
      v190[1] = v133; /*0x1066e841d*/
      __src[1] = v131; /*0x1066e8421*/
      v190[2] = v133; /*0x1066e8425*/
      v200[0] = v130; /*0x1066e8429*/
      v190[3] = v134; /*0x1066e842d*/
      v190[0] = v133; /*0x1066e8431*/
      std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1066e8434*/
      __src[1] = v131; /*0x1066e843d*/
      a2 = v196; /*0x1066e8441*/
      if ( (v197.i8[0] & 1) != 0 ) /*0x1066e8449*/
        operator delete(a1: (RBX::Memory *)v198, a2: v135); /*0x1066e844f*/
    }
    else
    {
      *((_QWORD *)__src[1] + 2) = v198; /*0x1066e8338*/
      *v123 = v197; /*0x1066e8340*/
      v113 = v195; /*0x1066e8345*/
      v123[1].i64[1] = v195.i64[0]; /*0x1066e8349*/
      __src[1] = &v123[2]; /*0x1066e8353*/
    }
    v109 = v193; /*0x1066e8454*/
  }
  if ( ((*((_DWORD *)v109 + 158) != 2) | (unsigned __int8)v192 ^ 1) == 0 ) /*0x1066e8471*/
  {
    v136 = *((_QWORD *)v109 + 574); /*0x1066e8477*/
    if ( v136 != 0 ) /*0x1066e8481*/
    {
      v137 = a2; /*0x1066e8487*/
      v138 = *(_QWORD *)(v136 + 6520); /*0x1066e848a*/
      RBX::format( /*0x1066e84a1*/
        this: (RBX *)&v197,
        a2: "%s_%s_RakRecvBeforeFail",
        a3: (__int64)v137,
        a4: (__int64)v15,
        a5: v111,
        a6: v112,
        a7: v113,
        a8: v114,
        a9: v115,
        a10: v116,
        a11: v117,
        a12: v118,
        a13: v119,
        a14: v120,
        a15: v185);
      v148 = _mm_sub_pd( /*0x1066e84b3*/
               (__m128d)_mm_unpacklo_epi32((__m128i)v138, (__m128i)xmmword_108F2F9A0),
               (__m128d)xmmword_108F2F9B0);
      v149 = (__m128)_mm_hadd_pd(v148, v148); /*0x1066e84bb*/
      v150 = (__m128 *)__src[1]; /*0x1066e84bf*/
      v195 = v149; /*0x1066e84ca*/
      if ( __src[1] >= (void *)v200[0] ) /*0x1066e84cf*/
      {
        v153 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1066e8500*/
        if ( (unsigned __int64)(v153 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1066e850b*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v139, a2: v140); /*0x1066e878a*/
        v154 = (__int64)(v200[0] - (unsigned __int64)__src[0]) >> 4; /*0x1066e8517*/
        if ( v154 <= v153 + 1 ) /*0x1066e851e*/
          v154 = v153 + 1; /*0x1066e851e*/
        if ( v200[0] - (unsigned __int64)__src[0] >= 0x7FFFFFFFFFFFFFE0LL ) /*0x1066e852f*/
          v154 = 0x7FFFFFFFFFFFFFFLL; /*0x1066e852f*/
        v191 = v200; /*0x1066e8533*/
        if ( v154 != 0 ) /*0x1066e853d*/
        {
          v155 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>(a1: v200); /*0x1066e8542*/
          v157 = v156; /*0x1066e8547*/
        }
        else
        {
          v155 = 0; /*0x1066e854c*/
          v157 = 0; /*0x1066e854e*/
        }
        v158 = v155 + 32 * v153; /*0x1066e8555*/
        v159 = v155 + 32 * v157; /*0x1066e855d*/
        v160 = (void *)(v158 + 32); /*0x1066e8567*/
        *(_QWORD *)(v158 + 16) = v198; /*0x1066e856b*/
        *(__m128 *)v158 = v197; /*0x1066e8573*/
        v197 = 0; /*0x1066e857b*/
        v198 = nullptr; /*0x1066e857f*/
        *(_QWORD *)(v158 + 24) = v195.i64[0]; /*0x1066e858b*/
        v161 = (void *)(v158 - ((char *)__src[1] - (char *)__src[0])); /*0x1066e859c*/
        memcpy(__dst: v161, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1066e85a2*/
        v162 = __src[0]; /*0x1066e85a7*/
        v163 = v200[0]; /*0x1066e85ab*/
        __src[0] = v161; /*0x1066e85af*/
        v190[1] = v162; /*0x1066e85ba*/
        __src[1] = v160; /*0x1066e85be*/
        v190[2] = v162; /*0x1066e85c2*/
        v200[0] = v159; /*0x1066e85c6*/
        v190[3] = v163; /*0x1066e85ca*/
        v190[0] = v162; /*0x1066e85ce*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1066e85d1*/
        __src[1] = v160; /*0x1066e85da*/
        v152 = (__int64)v196; /*0x1066e85de*/
        if ( (v197.i8[0] & 1) != 0 ) /*0x1066e85e2*/
          operator delete(a1: (RBX::Memory *)v198, a2: v164); /*0x1066e85e8*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v198; /*0x1066e84d5*/
        v151 = v197; /*0x1066e84d9*/
        *v150 = v197; /*0x1066e84dd*/
        v150[1].i64[1] = v149.i64[0]; /*0x1066e84e2*/
        __src[1] = &v150[2]; /*0x1066e84ec*/
        v152 = (__int64)v196; /*0x1066e84f0*/
      }
      RBX::format( /*0x1066e8607*/
        this: (RBX *)&v197,
        a2: "%s_%s_RakRecvBeforeFailWithPlace_%lld",
        a3: v152,
        a4: (__int64)v15,
        a5: v194,
        a6: v141,
        a7: v151,
        a8: v149,
        a9: v142,
        a10: v143,
        a11: v144,
        a12: v145,
        a13: v146,
        a14: v147,
        a15: v186);
      v167 = (__m128 *)__src[1]; /*0x1066e860c*/
      if ( __src[1] >= (void *)v200[0] ) /*0x1066e8617*/
      {
        v168 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1066e864a*/
        if ( (unsigned __int64)(v168 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1066e8656*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v165, a2: v166); /*0x1066e8791*/
        v169 = (__int64)(v200[0] - (unsigned __int64)__src[0]) >> 4; /*0x1066e8662*/
        if ( v169 <= v168 + 1 ) /*0x1066e8669*/
          v169 = v168 + 1; /*0x1066e8669*/
        if ( v200[0] - (unsigned __int64)__src[0] < 0x7FFFFFFFFFFFFFE0LL ) /*0x1066e867a*/
          v21 = v169; /*0x1066e867a*/
        v191 = v200; /*0x1066e8682*/
        if ( v21 != 0 ) /*0x1066e868c*/
        {
          v170 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>(a1: v200); /*0x1066e8691*/
          v172 = v171; /*0x1066e8696*/
        }
        else
        {
          v170 = 0; /*0x1066e869b*/
          v172 = 0; /*0x1066e869d*/
        }
        v173 = 32 * v168; /*0x1066e869f*/
        v174 = v170 + 32 * v172; /*0x1066e86ab*/
        v175 = (__m128 *)(v170 + v173 + 32); /*0x1066e86b6*/
        v175[-1].i64[0] = (__int64)v198; /*0x1066e86ba*/
        v175[-2] = v197; /*0x1066e86c2*/
        v197 = 0; /*0x1066e86ca*/
        v198 = nullptr; /*0x1066e86ce*/
        v175[-1].i64[1] = v195.i64[0]; /*0x1066e86da*/
        v176 = (void *)(v170 + v173 - ((char *)__src[1] - (char *)__src[0])); /*0x1066e86eb*/
        memcpy(__dst: v176, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1066e86f1*/
        v177 = __src[0]; /*0x1066e86f6*/
        v178 = v200[0]; /*0x1066e86fa*/
        __src[0] = v176; /*0x1066e86fe*/
        v190[1] = v177; /*0x1066e8709*/
        __src[1] = v175; /*0x1066e870d*/
        v190[2] = v177; /*0x1066e8711*/
        v200[0] = v174; /*0x1066e8715*/
        v190[3] = v178; /*0x1066e8719*/
        v190[0] = v177; /*0x1066e871d*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1066e8720*/
        __src[1] = v175; /*0x1066e8729*/
        if ( (v197.i8[0] & 1) != 0 ) /*0x1066e872d*/
          operator delete(a1: (RBX::Memory *)v198, a2: v179); /*0x1066e8733*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v198; /*0x1066e861d*/
        *v167 = v197; /*0x1066e8626*/
        v167[1].i64[1] = v195.i64[0]; /*0x1066e862f*/
        __src[1] = &v167[2]; /*0x1066e863a*/
      }
    }
  }
  RBX::Analytics::EphemeralCounter::bulkReportStats(a1: __src, a2: 0); /*0x1066e8741*/
  v190[0] = __src; /*0x1066e874d*/
  return std::vector<std::pair<std::string,double>>::__destroy_vector::operator()[abi:ne200100](a1: v190); /*0x1066e8755*/
}

// Address: 0x1066e880a | Name: __ZN3RBX7Network6Client38reportClientLevelNetworkMetricToInfluxEPKcS3_by
__int64 __fastcall RBX::Network::Client::reportClientLevelNetworkMetricToInflux(
        RBX::Network::Client *this,
        const char *a2,
        const char *a3,
        bool a4,
        unsigned __int64 a5)
{
  const char *v10; // rdx
  __int64 v11; // rdx
  unsigned int v12; // eax
  __int64 v13; // rax
  unsigned __int8 *v14; // rcx
  __int64 v15; // rdx
  const char *v16; // rdx
  __int64 v17; // rax
  void *v18; // rsi
  char *v19; // rcx
  char *v20; // rcx
  __int64 v21; // r8
  unsigned int v22; // eax
  __int64 v23; // rcx
  char *v24; // rcx
  __int64 v25; // r8
  __int64 v26; // rcx
  __int64 v27; // rcx
  __int64 v28; // r8
  unsigned __int8 *v29; // rcx
  _BYTE v31[16]; // [rsp+0h] [rbp-480h] BYREF
  void *v32; // [rsp+10h] [rbp-470h]
  _BYTE v33[528]; // [rsp+48h] [rbp-438h] BYREF
  unsigned __int8 *v34; // [rsp+258h] [rbp-228h]
  unsigned __int8 v35; // [rsp+260h] [rbp-220h] BYREF
  char v36; // [rsp+261h] [rbp-21Fh] BYREF
  __int64 v37; // [rsp+268h] [rbp-218h]
  void *v38; // [rsp+270h] [rbp-210h]
  void *v39[59]; // [rsp+278h] [rbp-208h] BYREF

  RBX::Analytics::InfluxDb::Points::Points( /*0x1066e884c*/
    a1: v39,
    a2: (unsigned int)DFInt::ClientNetworkInfluxHundredthsPercentage,
    a3: 0,
    a4: 0);
  RBX::ContextInfoManager::getAttribute(a1: &v35, a2: 5); /*0x1066e885d*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v39, a2: "Metric", a3); /*0x1066e8873*/
  if ( (*((_BYTE *)this + 640) & 1) != 0 ) /*0x1066e887f*/
    v10 = *((const char **)this + 82); /*0x1066e888a*/
  else
    v10 = (char *)this + 641; /*0x1066e8881*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e889f*/
    this: (RBX::Analytics::InfluxDb::Points *)v39,
    a2: "PreviousMetric",
    a3: v10);
  RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v39, a2: "TimeDeltaMs", a3: a5); /*0x1066e88b5*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v39, a2: "EndsSession", a3: a4); /*0x1066e88cf*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e88e9*/
    this: (RBX::Analytics::InfluxDb::Points *)v39,
    a2: "SessionAlreadyOver",
    a3: *((_BYTE *)this + 602));
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e8902*/
    this: (RBX::Analytics::InfluxDb::Points *)v39,
    a2: "DatacenterId",
    a3: *((_DWORD *)this + 148));
  RBX::Analytics::InfluxDb::Points::addPoint(a1: v39, a2: "GameInstanceId", a3: &v35); /*0x1066e891c*/
  v12 = *((unsigned __int8 *)this + 568); /*0x1066e8921*/
  if ( (v12 & 1) != 0 ) /*0x1066e892a*/
    v13 = *((_QWORD *)this + 72); /*0x1066e8930*/
  else
    v13 = v12 >> 1; /*0x1066e892c*/
  v14 = (unsigned __int8 *)this + 568; /*0x1066e8937*/
  v34 = (unsigned __int8 *)this + 568; /*0x1066e893e*/
  if ( v13 != 0 ) /*0x1066e8948*/
    RBX::Analytics::InfluxDb::Points::addPoint(a1: v39, a2: "PlaySessionId", a3: v34); /*0x1066e895f*/
  if ( *((_BYTE *)this + 604) == 1 ) /*0x1066e896b*/
  {
    v15 = *((_QWORD *)this + 619); /*0x1066e896d*/
    if ( (*(_BYTE *)v15 & 1) != 0 ) /*0x1066e8977*/
      v16 = *(const char **)(v15 + 16); /*0x1066e897e*/
    else
      v16 = (const char *)(v15 + 1); /*0x1066e8979*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)v39, a2: "UdMuxIp", a3: v16); /*0x1066e8990*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e89ad*/
      this: (RBX::Analytics::InfluxDb::Points *)v39,
      a2: "UdMuxPort",
      a3: *(_DWORD *)(*((_QWORD *)this + 619) + 24LL));
  }
  if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
  {
    v14 = SFString::RCCChannelName; /*0x1066e89be*/
    v17 = (SFString::RCCChannelName[0] & 1) != 0
        ? *(_QWORD *)&SFString::RCCChannelName[8]
        : SFString::RCCChannelName[0] >> 1;
    if ( v17 != 0 ) /*0x1066e89d7*/
      RBX::Analytics::InfluxDb::Points::addPoint(a1: v39, a2: "rccChannelName", a3: SFString::RCCChannelName); /*0x1066e89ee*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v31, a2, a3: v11, a4: v14); /*0x1066e89fd*/
  RBX::Analytics::InfluxDb::Points::report( /*0x1066e8a18*/
    a1: v39,
    a2: v31,
    a3: (unsigned int)DFInt::ClientNetworkInfluxHundredthsPercentage,
    a4: 0);
  if ( (v31[0] & 1) != 0 ) /*0x1066e8a24*/
    operator delete(a1: (RBX::Memory *)v32, a2: v18); /*0x1066e8a2d*/
  if ( FFlag::g_flagsLoaded == 1 && DFFlag::DualWriteClientNetworkParquetPoint == 1 )
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)3,std::enable_if<true,void>>( /*0x1066e8a5d*/
      a1: v31,
      a2: &RBX::Telemetry::kClientNetworkV2);
    RBX::Telemetry::FieldsContainer::addField(a1: v33, a2: "Metric", a3: 6, a4: a3, a5: 1); /*0x1066e8a81*/
    if ( (*((_BYTE *)this + 640) & 1) != 0 ) /*0x1066e8a8d*/
      v19 = *((char **)this + 82); /*0x1066e8a98*/
    else
      v19 = (char *)this + 641; /*0x1066e8a8f*/
    RBX::Telemetry::FieldsContainer::addField(a1: v33, a2: "PreviousMetric", a3: 14, a4: v19, a5: 1); /*0x1066e8ab4*/
    RBX::Telemetry::FieldsContainer::addField(a1: v33, a2: "TimeDeltaMs", a3: 11, a4: a5, a5: 1); /*0x1066e8ad1*/
    RBX::Telemetry::FieldsContainer::addField(a1: v33, a2: "EndsSession", a3: 11, a4, a5: 1); /*0x1066e8aee*/
    RBX::Telemetry::FieldsContainer::addField( /*0x1066e8b0f*/
      a1: v33,
      a2: "SessionAlreadyOver",
      a3: 18,
      a4: *((unsigned __int8 *)this + 602),
      a5: 1);
    RBX::Telemetry::FieldsContainer::addField(a1: v33, a2: "DatacenterId", a3: 12, a4: *((int *)this + 148), a5: 1); /*0x1066e8b30*/
    if ( (v35 & 1) != 0 ) /*0x1066e8b41*/
    {
      v20 = (char *)v38; /*0x1066e8b43*/
      v21 = v37; /*0x1066e8b4a*/
    }
    else
    {
      v21 = v35 >> 1; /*0x1066e8b53*/
      v20 = &v36; /*0x1066e8b56*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v33, a2: "GameInstanceId", a3: 14, a4: v20, a5: v21, a6: 1); /*0x1066e8b72*/
    v22 = *v34; /*0x1066e8b7e*/
    if ( (v22 & 1) != 0 ) /*0x1066e8b83*/
      v23 = *((_QWORD *)this + 72); /*0x1066e8b8b*/
    else
      v23 = v22 >> 1; /*0x1066e8b87*/
    if ( v23 != 0 ) /*0x1066e8b95*/
    {
      if ( (v22 & 1) != 0 ) /*0x1066e8b99*/
      {
        v24 = *((char **)this + 73); /*0x1066e8b9b*/
        v25 = *((_QWORD *)this + 72); /*0x1066e8ba2*/
      }
      else
      {
        v24 = (char *)this + 569; /*0x1066e8bab*/
        v25 = (unsigned __int8)v22 >> 1; /*0x1066e8bb4*/
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v33, a2: "PlaySessionId", a3: 13, a4: v24, a5: v25, a6: 1); /*0x1066e8bcd*/
    }
    if ( *((_BYTE *)this + 604) == 1 ) /*0x1066e8bd9*/
    {
      v26 = *((_QWORD *)this + 619); /*0x1066e8bdb*/
      if ( (*(_BYTE *)v26 & 1) != 0 ) /*0x1066e8be5*/
        v27 = *(_QWORD *)(v26 + 16); /*0x1066e8bec*/
      else
        v27 = v26 + 1; /*0x1066e8be7*/
      RBX::Telemetry::FieldsContainer::addField(a1: v33, a2: "UdMuxIp", a3: 7, a4: v27, a5: 1); /*0x1066e8c05*/
      RBX::Telemetry::FieldsContainer::addField( /*0x1066e8c2a*/
        a1: v33,
        a2: "UdMuxPort",
        a3: 9,
        a4: *(int *)(*((_QWORD *)this + 619) + 24LL),
        a5: 1);
    }
    if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
    {
      v28 = (SFString::RCCChannelName[0] & 1) != 0
          ? *(_QWORD *)&SFString::RCCChannelName[8]
          : SFString::RCCChannelName[0] >> 1;
      if ( v28 != 0 ) /*0x1066e8c58*/
      {
        if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1066e8c5c*/
          v29 = *(unsigned __int8 **)&SFString::RCCChannelName[16]; /*0x1066e8c5e*/
        else
          v29 = &SFString::RCCChannelName[1]; /*0x1066e8c64*/
        RBX::Telemetry::FieldsContainer::addField(a1: v33, a2: "rccChannelName", a3: 14, a4: v29, a5: v28, a6: 1); /*0x1066e8c7c*/
      }
    }
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v31); /*0x1066e8c88*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v31); /*0x1066e8c9b*/
  }
  if ( (v35 & 1) != 0 ) /*0x1066e8ca7*/
    operator delete(a1: (RBX::Memory *)v38, a2: v18); /*0x1066e8cb0*/
  RBX::Analytics::InfluxDb::Points::~Points(this: v39); /*0x1066e8cbc*/
  return __stack_chk_guard; /*0x1066e8cd1*/
}

// Address: 0x1066e8d54 | Name: __ZN3RBX7Network6Client21reportPerServerMetricEv
__int64 __fastcall RBX::Network::Client::reportPerServerMetric(RBX::Network::Client *this)
{
  unsigned int v1; // ebx
  __int64 v3; // rax
  unsigned int v4; // r9d
  __int64 v5; // rcx

  if ( *((_BYTE *)this + 4976) != 0 )
  {
    return 0; /*0x1066e8d63*/
  }
  else
  {
    v3 = *((_QWORD *)this + 619); /*0x1066e8d6e*/
    LOBYTE(v1) = 1; /*0x1066e8d7c*/
    while ( v3 != *((_QWORD *)this + 620) )
    {
      v4 = *(_DWORD *)(v3 + 36); /*0x1066e8d83*/
      if ( v4 <= 1 )
      {
        if ( (unsigned __int8)DFLog::NetworkTrace < 6u || BYTE1(DFLog::NetworkTrace) < 3u ) /*0x1066e8dad*/
          return 0; /*0x1066e8db3*/
        if ( (*(_BYTE *)v3 & 1) != 0 ) /*0x1066e8dbc*/
          v5 = *(_QWORD *)(v3 + 16); /*0x1066e8dc4*/
        else
          LODWORD(v5) = v3 + 1; /*0x1066e8dbe*/
        v1 = 0; /*0x1066e8dd3*/
        FLog::FastLogFormatted(
          a1: DFLog::NetworkTrace,
          a2: qword_10D7BB068,
          a3: (unsigned int)"[DFLog::NetworkTrace] reportPerServerMetric::: sc(%s:%d).state = %d :: returning false",
          a4: v5,
          a5: *(_DWORD *)(v3 + 24),
          a6: v4);
        return v1; /*0x1066e8ddc*/
      }
      v3 += 88; /*0x1066e8d8d*/
    }
  }
  return v1; /*0x1066e8d6b*/
}

// Address: 0x1066e8dde | Name: __ZN3RBX7Network6Client42reportConnectionLevelNetworkMetricToInfluxEPKc
__int64 __fastcall RBX::Network::Client::reportConnectionLevelNetworkMetricToInflux(
        RBX::Network::Client *this,
        const char *a2)
{
  void *v3; // rsi
  unsigned __int8 *v4; // r15
  unsigned __int8 *v5; // r12
  unsigned __int8 *v6; // r15
  const char *v7; // rdx
  int v8; // eax
  int v9; // eax
  __int64 v10; // rdx
  unsigned __int8 *v11; // rcx
  __int64 v12; // rdx
  const char *v13; // rdx
  __int64 v14; // rax
  void *v15; // rsi
  __int64 v16; // rcx
  __int64 v17; // r9
  unsigned int v18; // r8d
  unsigned __int8 *v19; // rcx
  __int64 v20; // r8
  unsigned __int8 *v21; // rcx
  __int64 v22; // rcx
  int v23; // eax
  char *v24; // rcx
  __int64 v25; // r8
  __int64 v26; // rcx
  __int64 v27; // rcx
  __int64 v28; // r8
  unsigned __int8 *v29; // rcx
  bool v30; // zf
  _BYTE v32[16]; // [rsp+0h] [rbp-480h] BYREF
  void *v33; // [rsp+10h] [rbp-470h]
  _BYTE v34[528]; // [rsp+48h] [rbp-438h] BYREF
  const char *v35; // [rsp+258h] [rbp-228h]
  unsigned __int8 v36; // [rsp+260h] [rbp-220h] BYREF
  char v37; // [rsp+261h] [rbp-21Fh] BYREF
  __int64 v38; // [rsp+268h] [rbp-218h]
  void *v39; // [rsp+270h] [rbp-210h]
  void *v40[59]; // [rsp+278h] [rbp-208h] BYREF

  v35 = a2; /*0x1066e8df2*/
  RBX::ContextInfoManager::getAttribute(a1: &v36, a2: 5); /*0x1066e8e16*/
  v4 = *((unsigned __int8 **)this + 619); /*0x1066e8e1b*/
  v5 = *((unsigned __int8 **)this + 620); /*0x1066e8e22*/
  if ( v4 != v5 )
  {
    v6 = v4 + 40; /*0x1066e8e32*/
    do
    {
      if ( (*((_DWORD *)v6 - 1) & 0xFFFFFFFE) == 2 )
      {
        RBX::Analytics::InfluxDb::Points::Points( /*0x1066e8e61*/
          a1: v40,
          a2: (unsigned int)DFInt::ClientNetworkInfluxHundredthsPercentage,
          a3: 0,
          a4: 0);
        RBX::Analytics::InfluxDb::Points::addPoint(a1: v40, a2: "Metric", a3: v6); /*0x1066e8e73*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e8e89*/
          this: (RBX::Analytics::InfluxDb::Points *)v40,
          a2: "DatacenterId",
          a3: *((_DWORD *)this + 148));
        if ( (*(v6 - 40) & 1) != 0 ) /*0x1066e8e93*/
          v7 = *((const char **)v6 - 3); /*0x1066e8e9b*/
        else
          v7 = (const char *)(v6 - 39); /*0x1066e8e95*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e8ea9*/
          this: (RBX::Analytics::InfluxDb::Points *)v40,
          a2: "ServerIp",
          a3: v7);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e8ebc*/
          this: (RBX::Analytics::InfluxDb::Points *)v40,
          a2: "ServerPort",
          a3: *((_DWORD *)v6 - 4));
        if ( FFlag::ConnectViaConnectionInternal == 1 ) /*0x1066e8ecb*/
        {
          v8 = RBX::Network::convertToIpVersionNumber(a1: *((unsigned int *)v6 - 2)); /*0x1066e8ed1*/
        }
        else
        {
          v9 = *((unsigned __int16 *)v6 - 6); /*0x1066e8ed8*/
          if ( *((_WORD *)v6 - 6) != 0 ) /*0x1066e8edf*/
          {
            if ( v9 == 30 ) /*0x1066e8ee4*/
            {
              v8 = 6; /*0x1066e8ef2*/
            }
            else if ( v9 == 2 ) /*0x1066e8ee9*/
            {
              v8 = 4; /*0x1066e8eeb*/
            }
            else
            {
              v8 = -1; /*0x1066e8efd*/
            }
          }
          else
          {
            v8 = 0; /*0x1066e8ef9*/
          }
        }
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e8f0e*/
          this: (RBX::Analytics::InfluxDb::Points *)v40,
          a2: "ClientSocketIPVersion",
          a3: v8);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e8f21*/
          this: (RBX::Analytics::InfluxDb::Points *)v40,
          a2: "ServerConnectionState",
          a3: *((_DWORD *)v6 - 1));
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e8f37*/
          this: (RBX::Analytics::InfluxDb::Points *)v40,
          a2: "ClientJoinState",
          a3: *((_DWORD *)this + 158));
        RBX::Analytics::InfluxDb::Points::addPoint(a1: v40, a2: "GameInstanceId", a3: &v36); /*0x1066e8f4d*/
        if ( *((_BYTE *)this + 604) == 1 ) /*0x1066e8f5a*/
        {
          v12 = *((_QWORD *)this + 619); /*0x1066e8f5c*/
          if ( (*(_BYTE *)v12 & 1) != 0 ) /*0x1066e8f66*/
            v13 = *(const char **)(v12 + 16); /*0x1066e8f6d*/
          else
            v13 = (const char *)(v12 + 1); /*0x1066e8f68*/
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e8f7b*/
            this: (RBX::Analytics::InfluxDb::Points *)v40,
            a2: "UdMuxIp",
            a3: v13);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066e8f94*/
            this: (RBX::Analytics::InfluxDb::Points *)v40,
            a2: "UdMuxPort",
            a3: *(_DWORD *)(*((_QWORD *)this + 619) + 24LL));
        }
        if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
        {
          v11 = SFString::RCCChannelName; /*0x1066e8fa5*/
          v14 = (SFString::RCCChannelName[0] & 1) != 0
              ? *(_QWORD *)&SFString::RCCChannelName[8]
              : SFString::RCCChannelName[0] >> 1;
          if ( v14 != 0 ) /*0x1066e8fbe*/
            RBX::Analytics::InfluxDb::Points::addPoint(a1: v40, a2: "rccChannelName", a3: SFString::RCCChannelName); /*0x1066e8fd1*/
        }
        std::string::basic_string[abi:ne200100]<0>(a1: v32, a2: v35, a3: v10, a4: v11); /*0x1066e8fe0*/
        RBX::Analytics::InfluxDb::Points::report( /*0x1066e8ff3*/
          a1: v40,
          a2: v32,
          a3: (unsigned int)DFInt::ClientNetworkInfluxHundredthsPercentage,
          a4: 0);
        if ( (v32[0] & 1) != 0 ) /*0x1066e8fff*/
          operator delete(a1: (RBX::Memory *)v33, a2: v15); /*0x1066e9008*/
        if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
        {
          if ( (*(v6 - 40) & 1) != 0 ) /*0x1066e9031*/
            v16 = *((_QWORD *)v6 - 3); /*0x1066e9039*/
          else
            LODWORD(v16) = (_DWORD)v6 - 39; /*0x1066e9033*/
          if ( (*v6 & 1) != 0 ) /*0x1066e9041*/
            v17 = *((_QWORD *)v6 + 2); /*0x1066e9049*/
          else
            LODWORD(v17) = (_DWORD)v6 + 1; /*0x1066e9043*/
          FLog::FastLogFormatted(
            a1: DFLog::NetworkTrace,
            a2: qword_10D7BB068,
            a3: (unsigned int)"[DFLog::NetworkTrace] Reporting per server(%s:%d) metric to influx: %s.",
            a4: v16,
            a5: *((_DWORD *)v6 - 4),
            a6: v17);
        }
        if ( FFlag::g_flagsLoaded == 1 && DFFlag::DualWriteClientNetworkParquetPoint == 1 )
        {
          RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)3,std::enable_if<true,void>>( /*0x1066e9091*/
            a1: v32,
            a2: &RBX::Telemetry::kClientNetworkV2);
          v18 = *v6; /*0x1066e9096*/
          if ( (v18 & 1) != 0 ) /*0x1066e909e*/
          {
            v19 = *((unsigned __int8 **)v6 + 2); /*0x1066e90a0*/
            v20 = *((_QWORD *)v6 + 1); /*0x1066e90a4*/
          }
          else
          {
            v19 = v6 + 1; /*0x1066e90aa*/
            v20 = v18 >> 1; /*0x1066e90ae*/
          }
          RBX::Telemetry::FieldsContainer::addField(a1: v34, a2: "Metric", a3: 6, a4: v19, a5: v20, a6: 1); /*0x1066e90ca*/
          RBX::Telemetry::FieldsContainer::addField( /*0x1066e90ef*/
            a1: v34,
            a2: "DatacenterId",
            a3: 12,
            a4: *((int *)this + 148),
            a5: 1);
          if ( (*(v6 - 40) & 1) != 0 ) /*0x1066e90f9*/
            v21 = *((unsigned __int8 **)v6 - 3); /*0x1066e9101*/
          else
            v21 = v6 - 39; /*0x1066e90fb*/
          RBX::Telemetry::FieldsContainer::addField(a1: v34, a2: "ServerIp", a3: 8, a4: v21, a5: 1); /*0x1066e911e*/
          RBX::Telemetry::FieldsContainer::addField(a1: v34, a2: "ServerPort", a3: 10, a4: *((int *)v6 - 4), a5: 1); /*0x1066e9140*/
          if ( FFlag::ConnectViaConnectionInternal == 1 ) /*0x1066e914f*/
          {
            v22 = (int)RBX::Network::convertToIpVersionNumber(a1: *((unsigned int *)v6 - 2)); /*0x1066e915a*/
          }
          else
          {
            v23 = *((unsigned __int16 *)v6 - 6); /*0x1066e915f*/
            if ( *((_WORD *)v6 - 6) != 0 ) /*0x1066e9166*/
            {
              if ( v23 == 30 ) /*0x1066e916b*/
              {
                v22 = 6; /*0x1066e9179*/
              }
              else if ( v23 == 2 ) /*0x1066e9170*/
              {
                v22 = 4; /*0x1066e9172*/
              }
              else
              {
                v22 = -1; /*0x1066e9184*/
              }
            }
            else
            {
              v22 = 0; /*0x1066e9180*/
            }
          }
          RBX::Telemetry::FieldsContainer::addField(a1: v34, a2: "ClientSocketIPVersion", a3: 21, a4: v22, a5: 1); /*0x1066e91a4*/
          RBX::Telemetry::FieldsContainer::addField( /*0x1066e91c6*/
            a1: v34,
            a2: "ServerConnectionState",
            a3: 21,
            a4: *((int *)v6 - 1),
            a5: 1);
          RBX::Telemetry::FieldsContainer::addField( /*0x1066e91eb*/
            a1: v34,
            a2: "ClientJoinState",
            a3: 15,
            a4: *((unsigned int *)this + 158),
            a5: 1);
          if ( (v36 & 1) != 0 ) /*0x1066e91fc*/
          {
            v24 = (char *)v39; /*0x1066e91fe*/
            v25 = v38; /*0x1066e9205*/
          }
          else
          {
            v25 = v36 >> 1; /*0x1066e920e*/
            v24 = &v37; /*0x1066e9211*/
          }
          RBX::Telemetry::FieldsContainer::addField(a1: v34, a2: "GameInstanceId", a3: 14, a4: v24, a5: v25, a6: 1); /*0x1066e9231*/
          if ( *((_BYTE *)this + 604) == 1 ) /*0x1066e923e*/
          {
            v26 = *((_QWORD *)this + 619); /*0x1066e9240*/
            if ( (*(_BYTE *)v26 & 1) != 0 ) /*0x1066e924a*/
              v27 = *(_QWORD *)(v26 + 16); /*0x1066e9251*/
            else
              v27 = v26 + 1; /*0x1066e924c*/
            RBX::Telemetry::FieldsContainer::addField(a1: v34, a2: "UdMuxIp", a3: 7, a4: v27, a5: 1); /*0x1066e926e*/
            RBX::Telemetry::FieldsContainer::addField( /*0x1066e9297*/
              a1: v34,
              a2: "UdMuxPort",
              a3: 9,
              a4: *(int *)(*((_QWORD *)this + 619) + 24LL),
              a5: 1);
          }
          if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
          {
            v28 = (SFString::RCCChannelName[0] & 1) != 0
                ? *(_QWORD *)&SFString::RCCChannelName[8]
                : SFString::RCCChannelName[0] >> 1;
            if ( v28 != 0 ) /*0x1066e92c5*/
            {
              if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1066e92c9*/
                v29 = *(unsigned __int8 **)&SFString::RCCChannelName[16]; /*0x1066e92d2*/
              else
                v29 = &SFString::RCCChannelName[1]; /*0x1066e92df*/
              RBX::Telemetry::FieldsContainer::addField(a1: v34, a2: "rccChannelName", a3: 14, a4: v29, a5: v28, a6: 1); /*0x1066e92fc*/
            }
          }
          RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v32); /*0x1066e9304*/
          RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v32); /*0x1066e9313*/
        }
        RBX::Analytics::InfluxDb::Points::~Points(this: v40); /*0x1066e931b*/
      }
      v30 = v6 + 48 == v5; /*0x1066e9328*/
      v6 += 88; /*0x1066e932b*/
    }
    while ( !v30 );
  }
  if ( (v36 & 1) != 0 ) /*0x1066e933b*/
    operator delete(a1: (RBX::Memory *)v39, a2: v3); /*0x1066e9344*/
  return __stack_chk_guard; /*0x1066e9359*/
}

// Address: 0x1066e93de | Name: __ZN3RBX7Network6Client23reportGameBasicSettingsEv
__int64 __fastcall RBX::Network::Client::reportGameBasicSettings(RBX::Network::Client *this)
{
  __int64 result; // rax
  RBX::CoreUserGameSettings *v2; // rdi
  char TouchEnabled; // bl
  RBX::CoreUserGameSettings *v4; // rax

  result = RBX::ServiceProvider::find<RBX::UserInputService>(a1: this); /*0x1066e93e4*/
  if ( result != 0 ) /*0x1066e93ec*/
  {
    if ( FFlag::ReplaceTouchEnabled == 1 ) /*0x1066e93f8*/
      TouchEnabled = *(_DWORD *)(result + 232) == 2; /*0x1066e9401*/
    else
      TouchEnabled = RBX::UserInputServiceProp::getTouchEnabled(this: (RBX::UserInputServiceProp *)(result + 192)); /*0x1066e941b*/
    v4 = (RBX::CoreUserGameSettings *)RBX::CoreUserGameSettings::singleton(this: v2); /*0x1066e941d*/
    return RBX::CoreUserGameSettings::recordSettingsInGA(this: v4, a2: TouchEnabled); /*0x1066e942e*/
  }
  return result; /*0x1066e940a*/
}

// Address: 0x1066e9434 | Name: __ZN3RBX7Network6Client22checkArtificialLatencyEx
__int64 *__fastcall RBX::Network::Client::checkArtificialLatency(RBX::Network::Client *this, __int64 a2)
{
  RBX::Time *v3; // rdi
  void *v4; // r14
  void *v5; // rax
  volatile signed __int64 *v6; // r14
  std::__shared_weak_count *v7; // r14
  __int64 v8; // xmm0_8
  RBX::Instance *v9; // rsi
  __int64 v10; // rax
  RBX::Ixp::IxpController *v11; // rdi
  __int64 v12; // r14
  volatile signed __int64 *v13; // rax
  std::__shared_weak_count *v14; // r12
  __int64 v15; // rax
  __int64 v16; // rax
  __int64 *result; // rax
  __int64 v18; // rdx
  std::__shared_weak_count *v19; // r15
  std::__shared_weak_count *v20; // rbx
  _BYTE v21[8]; // [rsp+10h] [rbp-E0h] BYREF
  std::__shared_weak_count *v22; // [rsp+18h] [rbp-D8h]
  _BYTE v23[16]; // [rsp+20h] [rbp-D0h] BYREF
  std::__shared_weak_count *v24[2]; // [rsp+30h] [rbp-C0h] BYREF
  __int128 v25; // [rsp+40h] [rbp-B0h] BYREF
  __int64 v26; // [rsp+58h] [rbp-98h] BYREF
  std::__shared_weak_count *v27[2]; // [rsp+60h] [rbp-90h] BYREF
  __int64 v28; // [rsp+70h] [rbp-80h] BYREF
  std::__shared_weak_count *v29; // [rsp+78h] [rbp-78h]
  std::__shared_weak_count *v30[2]; // [rsp+80h] [rbp-70h] BYREF
  std::__shared_weak_count *v31[2]; // [rsp+90h] [rbp-60h] BYREF
  void *v32; // [rsp+A8h] [rbp-48h] BYREF
  std::__shared_weak_count *v33; // [rsp+B0h] [rbp-40h]
  __int64 v34; // [rsp+B8h] [rbp-38h] BYREF
  std::__shared_weak_count *v35[2]; // [rsp+C0h] [rbp-30h] BYREF

  v34 = a2; /*0x1066e9449*/
  std::shared_ptr<RBX::Reflection::DescribedBase>::shared_ptr[abi:ne200100]<RBX::Reflection::DescribedBase,0>( /*0x1066e9458*/
    a1: v35,
    a2: (char *)this + 8);
  v3 = v35[0]; /*0x1066e945d*/
  if ( v35[0] == nullptr ) /*0x1066e9463*/
  {
    v4 = nullptr; /*0x1066e94c2*/
    goto LABEL_8; /*0x1066e94c5*/
  }
  v4 = nullptr; /*0x1066e9473*/
  v5 = __dynamic_cast( /*0x1066e9478*/
         lpsrc: v35[0],
         lpstype: (const struct __class_type_info *)&`typeinfo for'RBX::Reflection::DescribedBase,
         lpdtype: (const struct __class_type_info *)&`typeinfo for'RBX::Network::Client,
         s2d: 0);
  if ( v5 == nullptr ) /*0x1066e9480*/
  {
LABEL_8:
    v32 = v4; /*0x1066e94ca*/
    v33 = nullptr; /*0x1066e94ce*/
    goto LABEL_9; /*0x1066e94ce*/
  }
  v6 = (volatile signed __int64 *)v35[1]; /*0x1066e9482*/
  if ( v35[1] == nullptr ) /*0x1066e9489*/
  {
    v4 = v5; /*0x1066e94c7*/
    goto LABEL_8; /*0x1066e94c7*/
  }
  _InterlockedIncrement64((volatile signed __int64 *)v35[1] + 1); /*0x1066e948b*/
  v32 = v5; /*0x1066e9490*/
  v33 = (std::__shared_weak_count *)v6; /*0x1066e9494*/
  _InterlockedIncrement64(v6 + 2); /*0x1066e9498*/
  if ( _InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066e94ad*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(a1: v6); /*0x1066e94b5*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v6); /*0x1066e94bb*/
  }
LABEL_9:
  v7 = v35[1]; /*0x1066e94d6*/
  if ( v35[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v35[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066e94ef*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x1066e94f7*/
    std::__shared_weak_count::__release_weak(this: v7); /*0x1066e94fd*/
  }
  RBX::Time::nowFast(this: v3); /*0x1066e9502*/
  *((_QWORD *)this + 640) = v8; /*0x1066e9507*/
  v10 = RBX::DataModel::get(this, a2: v9); /*0x1066e9512*/
  if ( v10 != 0 ) /*0x1066e951a*/
  {
    RBX::weak_from<RBX::DataModel>(a1: v31, a2: v10); /*0x1066e9527*/
    v12 = RBX::Ixp::IxpController::instance(this: v11); /*0x1066e9531*/
    if ( *((_QWORD *)this + 636) != 0 ) /*0x1066e953e*/
    {
      v28 = *((_QWORD *)this + 636); /*0x1066e9540*/
      v13 = *((volatile signed __int64 **)this + 637); /*0x1066e9544*/
      v29 = (std::__shared_weak_count *)v13; /*0x1066e954b*/
      if ( v13 != nullptr ) /*0x1066e9552*/
        _InterlockedIncrement64(v13 + 2); /*0x1066e9554*/
      (*(void (__fastcall **)(__int64, __int64 *))(*(_QWORD *)v12 + 360LL))(a1: v12, a2: &v28); /*0x1066e9563*/
      if ( v29 != nullptr ) /*0x1066e9570*/
        std::__shared_weak_count::__release_weak(this: v29); /*0x1066e9572*/
    }
    RBX::make_shared<RBX::Network::Client::IxpChangedListener,std::weak_ptr<RBX::Network::Client> &,std::weak_ptr<RBX::DataModel> &,long long &>( /*0x1066e9587*/
      a1: (RSL::Arena *)v35,
      a2: (__int64)&v32,
      a3: (__int64)v31,
      a4: (__int64)&v34);
    std::shared_ptr<RBX::Network::Client::IxpChangedListener>::operator=[abi:ne200100](a1: (char *)this + 5088, a2: v35); /*0x1066e959d*/
    v14 = v35[1]; /*0x1066e95a2*/
    if ( v35[1] != nullptr /*0x1066e95bd*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v35[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x1066e95c6*/
      std::__shared_weak_count::__release_weak(this: v14); /*0x1066e95cc*/
    }
    v15 = *((_QWORD *)this + 637); /*0x1066e95d1*/
    *(_OWORD *)v27 = *((_OWORD *)this + 318); /*0x1066e95d9*/
    if ( v15 != 0 ) /*0x1066e95e3*/
      _InterlockedIncrement64((volatile signed __int64 *)(v15 + 16)); /*0x1066e95e5*/
    (*(void (__fastcall **)(__int64, std::__shared_weak_count **))(*(_QWORD *)v12 + 320LL))(a1: v12, a2: v27); /*0x1066e95f7*/
    if ( v27[1] != nullptr ) /*0x1066e9607*/
      std::__shared_weak_count::__release_weak(this: v27[1]); /*0x1066e9609*/
    (*(void (__fastcall **)(__int64, __int64 *))(*(_QWORD *)v12 + 392LL))(a1: v12, a2: &v26); /*0x1066e961b*/
    v16 = (*(__int64 (__fastcall **)(__int64, char *))(*(_QWORD *)v12 + 168LL))(a1: v12, a2: &FString::CLI52064IxpLayer); /*0x1066e962e*/
    if ( v26 == v34 && (v16 & 0x1FFFFFFFFLL) == 0x100000002LL ) /*0x1066e965f*/
    {
      *(_OWORD *)v30 = 0; /*0x1066e966c*/
      result = (__int64 *)(*(__int64 (__fastcall **)(__int64, char *, std::__shared_weak_count **))(*(_QWORD *)v12 /*0x1066e967c*/
                                                                                                  + 112LL))(
                            a1: v12,
                            a2: &FString::CLI52064IxpLayer,
                            a3: v30);
      if ( (_BYTE)result != 0 ) /*0x1066e9681*/
      {
        LOBYTE(v18) = (unsigned __int8)DFLog::NetworkIxp < 6u; /*0x1066e969a*/
        if ( (unsigned __int8)DFLog::NetworkIxp >= 6u && BYTE1(DFLog::NetworkIxp) >= 3u ) /*0x1066e96a0*/
        {
          v35[0] = nullptr; /*0x1066e96ab*/
          v35[1] = (std::__shared_weak_count *)v23; /*0x1066e96ba*/
          FLog::detail::FastLogSafeFormattedInternal( /*0x1066e96db*/
            a1: DFLog::NetworkIxp,
            a2: qword_10D7BB110,
            a3: 3,
            a4: (unsigned int)"[DFLog::NetworkIxp] Set IXP params directly",
            a5: 43,
            a6: 0,
            0,
            v23);
        }
        *(_OWORD *)v24 = *(_OWORD *)v31; /*0x1066e96e8*/
        if ( v31[1] != nullptr ) /*0x1066e96f2*/
          _InterlockedIncrement64((volatile signed __int64 *)v31[1] + 2); /*0x1066e96f4*/
        v19 = v30[1]; /*0x1066e96f9*/
        v25 = *(_OWORD *)v30; /*0x1066e9701*/
        if ( v30[1] != nullptr ) /*0x1066e970b*/
          _InterlockedIncrement64((volatile signed __int64 *)v30[1] + 1); /*0x1066e970d*/
        result = (__int64 *)RBX::Network::Client::setArtificialLatencyFromIxp(a1: this, a2: v24, a3: v18, a4: &v25); /*0x1066e9723*/
        if ( v19 != nullptr ) /*0x1066e972b*/
        {
          result = (__int64 *)_InterlockedExchangeAdd64((volatile signed __int64 *)v19 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x1066e9734*/
          if ( result == nullptr ) /*0x1066e973d*/
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v19 + 16LL))(a1: v19); /*0x1066e9745*/
            result = (__int64 *)std::__shared_weak_count::__release_weak(this: v19); /*0x1066e974b*/
          }
        }
        if ( v24[1] != nullptr ) /*0x1066e975a*/
          result = (__int64 *)std::__shared_weak_count::__release_weak(this: v24[1]); /*0x1066e975c*/
      }
      v20 = v30[1]; /*0x1066e9761*/
    }
    else
    {
      if ( (unsigned __int8)DFLog::NetworkIxp >= 6u && BYTE1(DFLog::NetworkIxp) >= 3u ) /*0x1066e97bf*/
      {
        v35[0] = nullptr; /*0x1066e97cb*/
        v35[1] = (std::__shared_weak_count *)v23; /*0x1066e97da*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x1066e97fb*/
          a1: DFLog::NetworkIxp,
          a2: qword_10D7BB110,
          a3: 3,
          a4: (unsigned int)"[DFLog::NetworkIxp] IXP params unavailable, deferring",
          a5: 53,
          a6: 0,
          0,
          v23);
      }
      result = (__int64 *)(*(__int64 (__fastcall **)(_BYTE *, __int64))(*(_QWORD *)v12 + 72LL))(a1: v21, a2: v12); /*0x1066e9811*/
      v20 = v22; /*0x1066e9814*/
    }
    if ( v20 != nullptr ) /*0x1066e981e*/
    {
      result = (__int64 *)_InterlockedExchangeAdd64((volatile signed __int64 *)v20 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x1066e9827*/
      if ( result == nullptr ) /*0x1066e9830*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(a1: v20); /*0x1066e9838*/
        result = (__int64 *)std::__shared_weak_count::__release_weak(this: v20); /*0x1066e983e*/
      }
    }
    if ( v31[1] != nullptr ) /*0x1066e984a*/
      result = (__int64 *)std::__shared_weak_count::__release_weak(this: v31[1]); /*0x1066e984c*/
  }
  else
  {
    result = &FLog::Network; /*0x1066e976a*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1066e9783*/
      result = (__int64 *)FLog::FastLog( /*0x1066e979b*/
                            a1: FLog::Network,
                            a2: qword_10D7BBAA8,
                            a3: "[FLog::Network] Unable to access DataModel when checking IXP",
                            0);
  }
  if ( v33 != nullptr ) /*0x1066e9858*/
    return (__int64 *)std::__shared_weak_count::__release_weak(this: v33); /*0x1066e985a*/
  return result; /*0x1066e985f*/
}

// Address: 0x1066e99a6 | Name: __ZN3RBX7Network6Client27setArtificialLatencyFromIxpENSt3__18weak_ptrINS_9DataModelEEExNS2_10shared_ptrIKNS_10Reflection10ValueTableEEE
void __fastcall RBX::Network::Client::setArtificialLatencyFromIxp(__int64 a1, __int128 *a2, __int64 a3, _QWORD *a4)
{
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rdi
  char v10; // bl
  volatile signed __int64 *v11; // r14
  __int64 v12; // r12
  RBX::Time *v13; // rdi
  double v14; // xmm0_8
  __int64 v15; // rax
  void *v16; // rsi
  __int64 v17; // rax
  void *v18; // rsi
  __int128 v19; // [rsp+10h] [rbp-90h] BYREF
  double v20; // [rsp+28h] [rbp-78h]
  double v21[2]; // [rsp+30h] [rbp-70h] BYREF
  void *v22; // [rsp+40h] [rbp-60h]
  __int64 v23; // [rsp+50h] [rbp-50h]
  __int64 v24; // [rsp+58h] [rbp-48h]
  __int128 v25; // [rsp+60h] [rbp-40h] BYREF
  void *v26; // [rsp+70h] [rbp-30h]

  if ( FFlag::SAuthWorkspaceFlagged != 0 /*0x1066e9a28*/
    || (RBX::EngineNetConfiguration::EngineNetConfiguration(a1: &v25, a2: 0), FFlag::DebugHashTableMetrics != 1)
    && (FFlag::SAuthWorkspaceFlagged == 0 || (v25 & 8) == 0) )
  {
    v7 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::find<std::string>( /*0x1066e99d6*/
           a1: *a4,
           a2: &FString::CLI52064IxpTxParam);
    if ( v7 != 0 && *(_BYTE *)(*(_QWORD *)(v7 + 40) + 53LL) == 1 ) /*0x1066e99e8*/
      v23 = (int)(1000 * RBX::Reflection::Variant::get<int>(a1: v7 + 40)); /*0x1066e99fe*/
    else
      v23 = 0; /*0x1066e9a2f*/
    v8 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::find<std::string>( /*0x1066e9a41*/
           a1: *a4,
           a2: &FString::CLI52064IxpRxParam);
    if ( v8 != 0 && *(_BYTE *)(*(_QWORD *)(v8 + 40) + 53LL) == 1 ) /*0x1066e9a53*/
      v24 = (int)(1000 * RBX::Reflection::Variant::get<int>(a1: v8 + 40)); /*0x1066e9a69*/
    else
      v24 = 0; /*0x1066e9a6f*/
    RSL::Mutex::lock(this: (RSL::Mutex *)(a1 + 5104)); /*0x1066e9a81*/
    v10 = *(_BYTE *)(a1 + 5112); /*0x1066e9a86*/
    *(_BYTE *)(a1 + 5112) = 1; /*0x1066e9a8d*/
    v11 = *((volatile signed __int64 **)a2 + 1); /*0x1066e9a95*/
    v19 = *a2; /*0x1066e9aa0*/
    if ( v11 != nullptr ) /*0x1066e9aab*/
      _InterlockedIncrement64(v11 + 2); /*0x1066e9aad*/
    v12 = v23; /*0x1066e9ab9*/
    RBX::Network::Client::setArtificialLatencyDmWriteLock(a1: v9, a2: &v19, a3: v23, a4: v24); /*0x1066e9ac4*/
    if ( v11 != nullptr ) /*0x1066e9acc*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v11); /*0x1066e9ad1*/
    RSL::Mutex::unlock(this: (RSL::Mutex *)(a1 + 5104)); /*0x1066e9ad9*/
    if ( v10 == 0 ) /*0x1066e9ae0*/
    {
      RBX::Time::nowFast(this: v13); /*0x1066e9ae6*/
      v20 = v14 - *(double *)(a1 + 5120); /*0x1066e9af4*/
      if ( (unsigned __int8)DFLog::NetworkIxp >= 6u && BYTE1(DFLog::NetworkIxp) >= 3u ) /*0x1066e9b12*/
      {
        v21[0] = 1000.0 * v20; /*0x1066e9b2e*/
        *(_QWORD *)&v25 = 10; /*0x1066e9b32*/
        *((_QWORD *)&v25 + 1) = v21; /*0x1066e9b3a*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x1066e9b5d*/
          a1: DFLog::NetworkIxp,
          a2: qword_10D7BB110,
          a3: 3,
          a4: (unsigned int)"[DFLog::NetworkIxp] Set latency from Ixp live response after {} ms",
          a5: 66,
          a6: 0,
          10,
          v21,
          v19);
      }
      RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)v21); /*0x1066e9b69*/
      v15 = std::string::insert(a1: v21, a2: 0, a3: "ArtificialLatencyIxpBackendMs-"); /*0x1066e9b7a*/
      v26 = *(void **)(v15 + 16); /*0x1066e9b87*/
      v25 = *(_OWORD *)v15; /*0x1066e9b8e*/
      *(_OWORD *)v15 = 0; /*0x1066e9b94*/
      *(_QWORD *)(v15 + 16) = 0; /*0x1066e9b97*/
      RBX::Analytics::EphemeralCounter::reportStats(a1: &v25, a2: 0, a3: v20 * 1000.0); /*0x1066e9bae*/
      if ( (v25 & 1) != 0 ) /*0x1066e9bb7*/
        operator delete(a1: (RBX::Memory *)v26, a2: v16); /*0x1066e9bbd*/
      if ( (LOBYTE(v21[0]) & 1) != 0 ) /*0x1066e9bc6*/
        operator delete(a1: (RBX::Memory *)v22, a2: v16); /*0x1066e9bcc*/
      if ( (v24 | v12) != 0 ) /*0x1066e9bd5*/
      {
        RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)v21); /*0x1066e9bde*/
        v17 = std::string::insert(a1: v21, a2: 0, a3: "RakNetLatencySetLive-"); /*0x1066e9bef*/
        v26 = *(void **)(v17 + 16); /*0x1066e9bfc*/
        v25 = *(_OWORD *)v17; /*0x1066e9c04*/
        *(_OWORD *)v17 = 0; /*0x1066e9c0c*/
        *(_QWORD *)(v17 + 16) = 0; /*0x1066e9c10*/
        RBX::Analytics::EphemeralCounter::reportCounter(a1: &v25, a2: 1, a3: 0); /*0x1066e9c1f*/
        if ( (v25 & 1) != 0 ) /*0x1066e9c28*/
          operator delete(a1: (RBX::Memory *)v26, a2: v18); /*0x1066e9c2e*/
        if ( (LOBYTE(v21[0]) & 1) != 0 ) /*0x1066e9c37*/
          operator delete(a1: (RBX::Memory *)v22, a2: v18); /*0x1066e9c3d*/
      }
    }
  }
}

// Address: 0x1066e9caa | Name: __ZN3RBX7Network6Client31setArtificialLatencyDmWriteLockENSt3__18weak_ptrINS_9DataModelEEEyy
__int64 __fastcall RBX::Network::Client::setArtificialLatencyDmWriteLock(
        __int64 a1,
        __int64 *a2,
        __int64 a3,
        __int64 a4)
{
  std::__shared_weak_count *v4; // rdi
  volatile signed __int64 *v8; // rax
  volatile signed __int64 *v9; // rbx
  __int64 v10; // rdi
  __int64 v11; // rsi
  __int64 v12; // rax
  _QWORD v14[4]; // [rsp+10h] [rbp-60h] BYREF
  _QWORD *v15; // [rsp+30h] [rbp-40h]

  v4 = (std::__shared_weak_count *)a2[1]; /*0x1066e9cc7*/
  if ( v4 == nullptr ) /*0x1066e9cce*/
    return __stack_chk_guard; /*0x1066e9cce*/
  v8 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v4); /*0x1066e9cdd*/
  if ( v8 == nullptr ) /*0x1066e9ce9*/
    return __stack_chk_guard; /*0x1066e9ce9*/
  v9 = v8; /*0x1066e9ceb*/
  v10 = *a2; /*0x1066e9cee*/
  if ( *a2 != 0 ) /*0x1066e9cf9*/
  {
    v14[0] = off_10CAA75A8; /*0x1066e9d06*/
    v14[1] = a3; /*0x1066e9d0a*/
    v14[2] = a4; /*0x1066e9d0f*/
    v15 = v14; /*0x1066e9d14*/
    RBX::DataModel::submitTask(a1: v10, a2: v14, a3: 1); /*0x1066e9d21*/
    if ( v15 == v14 ) /*0x1066e9d2d*/
    {
      v12 = 32; /*0x1066e9d3b*/
    }
    else
    {
      v12 = 40; /*0x1066e9d2f*/
      if ( v15 == nullptr ) /*0x1066e9d37*/
        goto LABEL_9; /*0x1066e9d37*/
    }
    (*(void (__fastcall **)(_QWORD *, __int64))(*v15 + v12))(a1: v15, a2: v11); /*0x1066e9d43*/
  }
LABEL_9:
  if ( _InterlockedExchangeAdd64(v9 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066e9d56*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v9 + 16))(a1: v9); /*0x1066e9d5e*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v9); /*0x1066e9d64*/
  }
  return __stack_chk_guard; /*0x1066e9d79*/
}

// Address: 0x1066e9dbe | Name: __ZN3RBX7Network6Client18getLoadStateSuffixEv
const char *__fastcall RBX::Network::Client::getLoadStateSuffix(RBX::Network::Client *this)
{
  unsigned __int64 v1; // rax

  v1 = *((unsigned int *)this + 158); /*0x1066e9dc2*/
  if ( v1 > 3 ) /*0x1066e9dcc*/
    return ""; /*0x1066e9ddb*/
  else
    return off_10CAA7E78[v1]; /*0x1066e9dd5*/
}

// Address: 0x1066e9de4 | Name: __ZN3RBX7Network6Client44setJoinStateFinishedReceivingInitialGameDataEv
void __fastcall RBX::Network::Client::setJoinStateFinishedReceivingInitialGameData(RBX::Network::Client *this)
{
  __int64 v2; // rax
  __int64 v3; // r14
  __int64 v4; // rbx
  __int64 v5; // r14
  void *v6; // rsi
  __int128 v7; // [rsp+0h] [rbp-30h] BYREF
  void *v8; // [rsp+10h] [rbp-20h]

  *((_DWORD *)this + 158) = 3; /*0x1066e9df2*/
  v2 = RBX::ServiceProvider::find<RBX::Players>(a1: this); /*0x1066e9dfc*/
  if ( v2 != 0 ) /*0x1066e9e04*/
  {
    v3 = v2; /*0x1066e9e06*/
    v4 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x1066e9e15*/
    if ( (*(_BYTE *)(v3 + 216) & 1) != 0 ) /*0x1066e9e20*/
    {
      std::string::__init_copy_ctor_external(a1: &v7, a2: *(_QWORD *)(v3 + 232), a3: *(_QWORD *)(v3 + 224)); /*0x1066e9e4d*/
    }
    else
    {
      v5 = v3 + 216; /*0x1066e9e22*/
      v8 = *(void **)(v5 + 16); /*0x1066e9e2d*/
      v7 = *(_OWORD *)v5; /*0x1066e9e35*/
    }
    (*(void (__fastcall **)(__int64, __int128 *))(*(_QWORD *)v4 + 920LL))(a1: v4, a2: &v7); /*0x1066e9e5c*/
    if ( (v7 & 1) != 0 ) /*0x1066e9e66*/
      operator delete(a1: (RBX::Memory *)v8, a2: v6); /*0x1066e9e6c*/
  }
}

// Address: 0x1066e9e94 | Name: __ZN3RBX7Network6Client17parseEndpointArgsEiRKNSt3__16vectorINS0_14ConnectionInfoENS2_9allocatorIS4_EEEES9_bbNS2_8optionalIiEE
RBX::Network::ConnectionInfo *__fastcall RBX::Network::Client::parseEndpointArgs(
        RBX::Network::ConnectionInfo *this,
        unsigned int a2,
        _QWORD *a3,
        _QWORD *a4,
        __int64 a5,
        int a6,
        unsigned __int64 a7)
{
  __int64 v10; // r13
  int v11; // ecx
  __int64 v12; // r13
  __int64 v13; // rax
  __int64 v14; // rdx
  void *v15; // rsi
  int v16; // ecx
  void *v17; // rsi
  _OWORD *v18; // r14
  bool v19; // zf
  __int128 v21; // [rsp+0h] [rbp-B0h] BYREF
  void *v22; // [rsp+10h] [rbp-A0h]
  __int128 v23; // [rsp+18h] [rbp-98h]
  __int128 v24; // [rsp+28h] [rbp-88h]
  void *v25; // [rsp+38h] [rbp-78h]
  __int128 v26; // [rsp+40h] [rbp-70h]
  __int64 v27; // [rsp+50h] [rbp-60h]
  _BYTE v28[16]; // [rsp+58h] [rbp-58h] BYREF
  void *v29; // [rsp+68h] [rbp-48h]
  unsigned int v30; // [rsp+74h] [rbp-3Ch]
  unsigned __int64 v31; // [rsp+78h] [rbp-38h]
  int v32; // [rsp+84h] [rbp-2Ch]

  v32 = a6; /*0x1066e9ea8*/
  v30 = a2; /*0x1066e9eb2*/
  RBX::Network::ConnectionInfo::ConnectionInfo(this); /*0x1066e9eb8*/
  RBX::Network::ConnectionInfo::ConnectionInfo(this: (RBX::Network::ConnectionInfo *)((char *)this + 88)); /*0x1066e9ec4*/
  v31 = HIDWORD(a7); /*0x1066e9ed1*/
  v10 = *a4; /*0x1066e9ed5*/
  if ( *a4 != a4[1] ) /*0x1066e9edc*/
  {
    std::string::operator=(a1: (char *)this + 88, a2: *a4); /*0x1066e9ee4*/
    *((_OWORD *)this + 7) = *(_OWORD *)(v10 + 24); /*0x1066e9eee*/
    std::string::operator=(a1: (char *)this + 128, a2: v10 + 40); /*0x1066e9efd*/
    std::string::operator=(a1: (char *)this + 152, a2: v10 + 64); /*0x1066e9f10*/
    if ( (_BYTE)v32 != 0 ) /*0x1066e9f19*/
    {
      v11 = 0; /*0x1066e9f1f*/
      if ( (v31 & 1) != 0 ) /*0x1066e9f29*/
        v11 = a7; /*0x1066e9f29*/
      *((_DWORD *)this + 28) = v11; /*0x1066e9f2c*/
    }
  }
  v12 = *a3; /*0x1066e9f2e*/
  if ( *a3 == a3[1] ) /*0x1066e9f37*/
  {
    std::string::basic_string[abi:ne200100](a1: v28, a2: "127.0.0.1", a3: 9); /*0x1066ea005*/
    RBX::Network::ConnectionInfo::ConnectionInfo(a1: &v21, a2: v28, a3: v30); /*0x1066ea018*/
    if ( (*(_BYTE *)this & 1) != 0 ) /*0x1066ea020*/
      operator delete(a1: *((RBX::Memory **)this + 2), a2: v17); /*0x1066ea026*/
    *((_QWORD *)this + 2) = v22; /*0x1066ea036*/
    *(_OWORD *)this = v21; /*0x1066ea03f*/
    LOWORD(v21) = 0; /*0x1066ea042*/
    *(_OWORD *)((char *)this + 24) = v23; /*0x1066ea04e*/
    if ( (*((_BYTE *)this + 40) & 1) != 0 ) /*0x1066ea05a*/
      operator delete(a1: *((RBX::Memory **)this + 7), a2: v17); /*0x1066ea060*/
    *((_QWORD *)this + 7) = v25; /*0x1066ea069*/
    *(_OWORD *)((char *)this + 40) = v24; /*0x1066ea071*/
    LOWORD(v24) = 0; /*0x1066ea075*/
    v18 = (_OWORD *)((char *)this + 64); /*0x1066ea07e*/
    if ( (*((_BYTE *)this + 64) & 1) != 0 ) /*0x1066ea086*/
    {
      operator delete(a1: *((RBX::Memory **)this + 10), a2: v17); /*0x1066ea0a4*/
      v19 = (v24 & 1) == 0; /*0x1066ea0a9*/
      *((_QWORD *)this + 10) = v27; /*0x1066ea0b4*/
      *v18 = v26; /*0x1066ea0bc*/
      LOWORD(v26) = 0; /*0x1066ea0c0*/
      if ( !v19 ) /*0x1066ea0c6*/
        operator delete(a1: (RBX::Memory *)v25, a2: v17); /*0x1066ea0cc*/
    }
    else
    {
      *((_QWORD *)this + 10) = v27; /*0x1066ea08c*/
      *v18 = v26; /*0x1066ea094*/
      LOWORD(v26) = 0; /*0x1066ea098*/
    }
    if ( (v21 & 1) != 0 ) /*0x1066ea0d8*/
      operator delete(a1: (RBX::Memory *)v22, a2: v17); /*0x1066ea0e1*/
    if ( (v28[0] & 1) != 0 ) /*0x1066ea0ea*/
      operator delete(a1: (RBX::Memory *)v29, a2: v17); /*0x1066ea0f0*/
    if ( (_BYTE)v32 != 0 && (v31 & 1) != 0 ) /*0x1066ea0ff*/
      *((_DWORD *)this + 6) = a7; /*0x1066ea109*/
  }
  else
  {
    std::string::operator=(a1: this, a2: *a3); /*0x1066e9f43*/
    *(_OWORD *)((char *)this + 24) = *(_OWORD *)(v12 + 24); /*0x1066e9f4d*/
    std::string::operator=(a1: (char *)this + 40, a2: v12 + 40); /*0x1066e9f59*/
    std::string::operator=(a1: (char *)this + 64, a2: v12 + 64); /*0x1066e9f69*/
    v13 = RBX::Network::ConnectionInfo::toString(this, a2: false); /*0x1066e9f73*/
    if ( v14 == 9 && (*(_QWORD *)v13 ^ 0x736F686C61636F6CLL | *(unsigned __int8 *)(v13 + 8) ^ 0x74LL) == 0 ) /*0x1066e9f96*/
    {
      std::string::basic_string[abi:ne200100](a1: &v21, a2: "127.0.0.1", a3: 9); /*0x1066e9fab*/
      if ( (*(_BYTE *)this & 1) != 0 ) /*0x1066e9fb3*/
        operator delete(a1: *((RBX::Memory **)this + 2), a2: v15); /*0x1066e9fb9*/
      *((_QWORD *)this + 2) = v22; /*0x1066e9fc5*/
      *(_OWORD *)this = v21; /*0x1066e9fd0*/
    }
    if ( (_BYTE)v32 != 0 ) /*0x1066e9fd7*/
    {
      v16 = 0; /*0x1066e9fe1*/
      if ( (v31 & 1) != 0 ) /*0x1066e9feb*/
        v16 = a7; /*0x1066e9feb*/
      *((_DWORD *)this + 6) = v16; /*0x1066e9fee*/
    }
  }
  return this; /*0x1066ea10e*/
}

// Address: 0x1066ea19a | Name: __ZN3RBX7Network6Client18hookToSAuthSignalsEv
void __fastcall RBX::Network::Client::hookToSAuthSignals(RBX::Network::Client *this, RBX::Instance *a2)
{
  __int64 v3; // rax
  __int64 v4; // r14
  _BYTE *EngineNetConfiguration; // rax
  __int64 v6; // r12
  volatile signed __int64 *v7; // rbx
  unsigned int v8; // esi
  __int128 v9; // xmm1
  volatile signed __int64 *v10; // r14
  rbx::signals::slots_holder **v11; // r12
  unsigned __int64 v12; // rsi
  volatile signed __int32 *v13; // r13
  rbx::signals::slots_holder *v14; // rcx
  __int64 v15; // rcx
  __int128 v16; // xmm1
  __int128 v17; // xmm2
  rbx::signals::slots_holder *v18; // rdi
  unsigned int v19; // esi
  void *v20; // rdi
  __int128 v21; // [rsp+0h] [rbp-80h]
  __int128 v22; // [rsp+10h] [rbp-70h]
  std::__shared_weak_count *v23[2]; // [rsp+20h] [rbp-60h] BYREF
  std::__shared_weak_count *v24[2]; // [rsp+30h] [rbp-50h]
  void *v25; // [rsp+48h] [rbp-38h]
  RBX::Memory *v26; // [rsp+54h] [rbp-2Ch]

  v3 = RBX::DataModel::get(this, a2); /*0x1066ea1ae*/
  if ( v3 != 0 ) /*0x1066ea1b6*/
  {
    v4 = v3; /*0x1066ea1bc*/
    EngineNetConfiguration = (_BYTE *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::Client *)((char *)this + 2304)); /*0x1066ea1c6*/
    if ( FFlag::DebugHashTableMetrics != 0 || FFlag::SAuthWorkspaceFlagged == 1 && (*EngineNetConfiguration & 8) != 0 ) /*0x1066ea32f*/
    {
      v6 = *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::AuroraService>(this: (RBX::ServiceProvider *)(v4 + 464)); /*0x1066ea1e7*/
      if ( v6 != 0 ) /*0x1066ea1ed*/
      {
        RBX::shared_from<RBX::Network::Client>(a1: v23, a2: (__int64)this); /*0x1066ea1fd*/
        v21 = *(_OWORD *)v23; /*0x1066ea205*/
        v7 = (volatile signed __int64 *)v23[1]; /*0x1066ea209*/
        if ( v23[1] != nullptr ) /*0x1066ea210*/
        {
          _InterlockedIncrement64((volatile signed __int64 *)v23[1] + 2); /*0x1066ea212*/
          if ( _InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066ea227*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(a1: v7); /*0x1066ea22f*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v7); /*0x1066ea235*/
          }
        }
        RBX::shared_from<RBX::DataModel>(a1: v23, a2: v4); /*0x1066ea241*/
        v9 = *(_OWORD *)v23; /*0x1066ea246*/
        v10 = (volatile signed __int64 *)v23[1]; /*0x1066ea24a*/
        v22 = *(_OWORD *)v23; /*0x1066ea251*/
        if ( v23[1] != nullptr ) /*0x1066ea255*/
        {
          _InterlockedIncrement64((volatile signed __int64 *)v23[1] + 2); /*0x1066ea257*/
          if ( _InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066ea26c*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v10 + 16))(a1: v10); /*0x1066ea274*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v10); /*0x1066ea27a*/
            v9 = v22; /*0x1066ea27f*/
          }
        }
        *(_OWORD *)v23 = v21; /*0x1066ea287*/
        if ( v7 != nullptr ) /*0x1066ea28e*/
          _InterlockedIncrement64(v7 + 2); /*0x1066ea290*/
        *(_OWORD *)v24 = v9; /*0x1066ea295*/
        if ( v10 != nullptr ) /*0x1066ea29c*/
          _InterlockedIncrement64(v10 + 2); /*0x1066ea29e*/
        LODWORD(v26) = RBX::Memory::setCurrentCategory( /*0x1066ea2b1*/
                         this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal,
                         a2: v8);
        v11 = (rbx::signals::slots_holder **)(v6 + 272); /*0x1066ea2b4*/
        rbx::lazyInitSlotsHolder(a1: v11); /*0x1066ea2be*/
        v13 = (volatile signed __int32 *)rbx::signals::slot_base::operator new( /*0x1066ea2cd*/
                                           this: (rbx::signals::slot_base *)0x50,
                                           a2: v12);
        *(_QWORD *)v13 = &_mh_execute_header; /*0x1066ea2de*/
        *((_QWORD *)v13 + 1) = rbx::signals::slot_with_functor<RBX::Network::Client::hookToSAuthSignals(void)::$_0,int,int>::do_call; /*0x1066ea2e9*/
        *((_OWORD *)v13 + 1) = 0; /*0x1066ea2f0*/
        v14 = *v11; /*0x1066ea2f5*/
        *((_QWORD *)v13 + 4) = *v11; /*0x1066ea2f9*/
        if ( v14 != nullptr ) /*0x1066ea300*/
        {
          _InterlockedIncrement((volatile signed __int32 *)v14 + 1); /*0x1066ea302*/
          v15 = *((_QWORD *)v13 + 3) | 4LL; /*0x1066ea30a*/
          v16 = *(_OWORD *)v23; /*0x1066ea30e*/
          v17 = *(_OWORD *)v24; /*0x1066ea312*/
          v18 = *v11; /*0x1066ea316*/
        }
        else
        {
          v15 = 4; /*0x1066ea33a*/
          v18 = nullptr; /*0x1066ea33f*/
          v16 = v21; /*0x1066ea341*/
          v17 = v22; /*0x1066ea345*/
        }
        *((_QWORD *)v13 + 3) = v15; /*0x1066ea349*/
        *((_QWORD *)v13 + 5) = rbx::signals::slot_with_functor<RBX::Network::Client::hookToSAuthSignals(void)::$_0,int,int>::do_dtor; /*0x1066ea354*/
        *((_OWORD *)v13 + 3) = v16; /*0x1066ea358*/
        *(_OWORD *)v23 = 0; /*0x1066ea35d*/
        *((_OWORD *)v13 + 4) = v17; /*0x1066ea361*/
        *(_OWORD *)v24 = 0; /*0x1066ea366*/
        rbx::signals::slots_holder::insert(this: v18, a2: (unsigned __int64)v13); /*0x1066ea36c*/
        v25 = (void *)v13; /*0x1066ea371*/
        _InterlockedIncrement(v13 + 1); /*0x1066ea375*/
        RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)v26, a2: v19); /*0x1066ea37d*/
        rbx::signals::scoped_connection::operator=(this: (RBX::Network::Client *)((char *)this + 496)); /*0x1066ea390*/
        v20 = v25; /*0x1066ea395*/
        if ( v25 != nullptr && _InterlockedDecrement((volatile signed __int32 *)v25 + 1) == 0 ) /*0x1066ea3a2*/
          rbx::signals::slot_base::operator delete(a1: v20); /*0x1066ea3a4*/
        if ( v24[1] != nullptr ) /*0x1066ea3b0*/
          std::__shared_weak_count::__release_weak(this: v24[1]); /*0x1066ea3b2*/
        if ( v23[1] != nullptr ) /*0x1066ea3be*/
          std::__shared_weak_count::__release_weak(this: v23[1]); /*0x1066ea3c0*/
        if ( v10 != nullptr ) /*0x1066ea3c8*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v10); /*0x1066ea3cd*/
        if ( v7 != nullptr ) /*0x1066ea3d5*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v7); /*0x1066ea3da*/
      }
    }
  }
}

// Address: 0x1066ea4ce | Name: __ZZN3RBX7Network6Client18hookToSAuthSignalsEvEN3$_0D1Ev
__int64 __fastcall RBX::Network::Client::hookToSAuthSignals(void)::$_0::~$_0(__int64 a1)
{
  std::__shared_weak_count *v2; // rdi
  __int64 result; // rax
  std::__shared_weak_count *v4; // rdi

  v2 = *(std::__shared_weak_count **)(a1 + 24); /*0x1066ea4d7*/
  if ( v2 != nullptr ) /*0x1066ea4de*/
    result = std::__shared_weak_count::__release_weak(this: v2); /*0x1066ea4e0*/
  v4 = *(std::__shared_weak_count **)(a1 + 8); /*0x1066ea4e5*/
  if ( v4 != nullptr ) /*0x1066ea4f0*/
    return std::__shared_weak_count::__release_weak(this: v4); /*0x1066ea4f4*/
  return result; /*0x1066ea4f2*/
}

// Address: 0x1066ea4fc | Name: __ZN3RBX7Network6Client35playerConnectWithConnectionInternalExRKNS0_19FinalConnectionArgsES4_iiiNSt3__110shared_ptrIKNS_10Reflection10ValueTableEEERNS_4Rupp8TokenTlv5TokenEbNS5_8optionalISD_EENSF_INS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEEENSF_INS_12RbxTransport12CapabilitiesEEE
__int64 __fastcall RBX::Network::Client::playerConnectWithConnectionInternal(
        __int64 a1,
        __int64 a2,
        RBX::Network::ConnectionInfo *a3,
        RBX::Network::ConnectionInfo *a4,
        _BOOL4 a5,
        __int64 a6,
        unsigned int a7,
        RBX::Reflection::ValueTable **a8,
        __int128 *a9,
        char a10,
        __int128 a11,
        __int16 a12,
        __int64 a13,
        __int64 a14)
{
  __int64 v17; // rax
  void *v18; // rsi
  __int64 v19; // rdx
  __int64 v20; // rcx
  __int64 v21; // rdx
  __int64 v22; // rcx
  RBX::Time *v23; // rdi
  const RBX::Instance *v24; // rsi
  double v25; // xmm0_8
  RBX::Instance *v26; // rsi
  __int64 v27; // rax
  float v28; // xmm0_4
  RBX::Network *v29; // rcx
  RBX::ServiceProvider *ServiceProvider; // rax
  __int64 v31; // rax
  __int64 v32; // rdi
  __int64 v33; // rbx
  const RBX::Instance *v34; // rsi
  int *v35; // r15
  RBX::ServiceProvider *v36; // rax
  RBX::RunService *v37; // rdi
  __int64 v38; // rax
  unsigned __int64 v39; // rbx
  int v40; // ecx
  char v41; // r14
  double v42; // xmm0_8
  __int64 v43; // r12
  char isLocalTest; // al
  RBX::Network::ConnectionInfo *v45; // r13
  unsigned __int64 v46; // rbx
  RBX::Network::ConnectionInfo *v47; // r12
  bool v48; // si
  int v49; // edx
  bool v50; // si
  int v51; // r15d
  unsigned int v52; // r13d
  __int64 v53; // r13
  _BYTE *v54; // rbx
  _BYTE *v55; // r12
  _BOOL4 v56; // ecx
  int v57; // eax
  unsigned __int8 v58; // al
  _BYTE *EngineNetConfiguration; // rax
  __int64 v60; // r13
  unsigned int v61; // r14d
  rbx::signals::slots_holder **v62; // r13
  unsigned __int64 v63; // rsi
  volatile signed __int32 *v64; // r15
  rbx::signals::slots_holder *v65; // rax
  unsigned __int64 v66; // rax
  char *v67; // r14
  __int64 v68; // r9
  __int64 v69; // r10
  __int64 v70; // rcx
  bool v71; // al
  unsigned __int64 v72; // rsi
  __int64 v73; // rax
  __int128 v74; // xmm1
  __int128 v75; // xmm2
  __int128 v76; // xmm3
  char *v77; // rsi
  void *v78; // rsi
  __int64 v79; // rax
  unsigned __int64 v80; // rsi
  __int64 v81; // rax
  char *v82; // rsi
  __int128 v83; // xmm0
  __int128 v84; // xmm1
  __int128 v85; // xmm2
  __int64 v86; // rax
  __int64 v87; // r8
  unsigned __int8 *v88; // rcx
  RBX::DataModel *v89; // rdi
  RBX::Network::ConnectionInfo *ConnectionInfo; // rax
  char isIpV6; // al
  unsigned __int64 v92; // rsi
  __int64 v93; // rbx
  __int64 v94; // rax
  __int64 *v95; // rdx
  __int64 v96; // r15
  __int64 v97; // r14
  __int64 v98; // rdi
  __int64 v99; // rdi
  void *v100; // rsi
  unsigned int v102; // esi
  RBX *exception; // r14
  __int64 v104; // rdx
  __int64 v105; // rcx
  __int64 v106; // r8
  __int64 v107; // r9
  __m128 v108; // xmm0
  __m128 v109; // xmm1
  __m128 v110; // xmm2
  __m128 v111; // xmm3
  __m128 v112; // xmm4
  __m128 v113; // xmm5
  __m128 v114; // xmm6
  __m128 v115; // xmm7
  std::runtime_error *v116; // r14
  char v117; // [rsp+0h] [rbp-7B0h]
  void *v118[9]; // [rsp+18h] [rbp-798h] BYREF
  _BYTE v119[528]; // [rsp+60h] [rbp-750h] BYREF
  _DWORD v120[12]; // [rsp+270h] [rbp-540h] BYREF
  _BYTE v121[16]; // [rsp+2A0h] [rbp-510h] BYREF
  void *v122; // [rsp+2B0h] [rbp-500h]
  _BYTE v123[16]; // [rsp+2B8h] [rbp-4F8h] BYREF
  void *v124; // [rsp+2C8h] [rbp-4E8h]
  _BYTE v125[16]; // [rsp+2D0h] [rbp-4E0h] BYREF
  void *v126; // [rsp+2E0h] [rbp-4D0h]
  __int64 v127; // [rsp+2E8h] [rbp-4C8h]
  void *v128; // [rsp+2F0h] [rbp-4C0h] BYREF
  _BYTE *v129; // [rsp+2F8h] [rbp-4B8h]
  int v130; // [rsp+308h] [rbp-4A8h]
  char v131; // [rsp+30Ch] [rbp-4A4h]
  RBX::Network::ConnectionInfo *v132; // [rsp+310h] [rbp-4A0h]
  RBX::Network::ConnectionInfo *v133; // [rsp+318h] [rbp-498h]
  RBX::Network *v134; // [rsp+320h] [rbp-490h]
  int v135; // [rsp+32Ch] [rbp-484h]
  double v136; // [rsp+330h] [rbp-480h]
  unsigned __int64 v137; // [rsp+338h] [rbp-478h]
  _BOOL4 v138; // [rsp+344h] [rbp-46Ch]
  RBX::Network::Peer *v139; // [rsp+348h] [rbp-468h]
  RBX::Network::Peer *v140; // [rsp+350h] [rbp-460h] BYREF
  __int128 v141; // [rsp+358h] [rbp-458h] BYREF
  void *v142; // [rsp+368h] [rbp-448h]
  __int128 v143; // [rsp+370h] [rbp-440h]
  __int128 v144; // [rsp+380h] [rbp-430h]
  void *v145; // [rsp+390h] [rbp-420h]
  __int128 v146; // [rsp+398h] [rbp-418h]
  void *v147; // [rsp+3A8h] [rbp-408h]
  _BYTE v148[16]; // [rsp+3B0h] [rbp-400h] BYREF
  void *v149; // [rsp+3C0h] [rbp-3F0h]
  char v150; // [rsp+3D8h] [rbp-3D8h]
  void *v151; // [rsp+3E8h] [rbp-3C8h]
  char v152; // [rsp+3F0h] [rbp-3C0h]
  void *v153; // [rsp+400h] [rbp-3B0h]
  __int128 v154; // [rsp+408h] [rbp-3A8h]
  __int128 v155; // [rsp+418h] [rbp-398h]
  _QWORD v156[4]; // [rsp+428h] [rbp-388h]
  RBX::Network::Peer *v157; // [rsp+448h] [rbp-368h] BYREF
  char v158[16]; // [rsp+450h] [rbp-360h] BYREF
  void *v159; // [rsp+460h] [rbp-350h]
  char v160; // [rsp+478h] [rbp-338h]
  void *v161; // [rsp+488h] [rbp-328h]
  char v162; // [rsp+490h] [rbp-320h]
  void *v163; // [rsp+4A0h] [rbp-310h]
  char v164[16]; // [rsp+4A8h] [rbp-308h] BYREF
  void *v165; // [rsp+4B8h] [rbp-2F8h]
  char v166; // [rsp+4D0h] [rbp-2E0h]
  void *v167; // [rsp+4E0h] [rbp-2D0h]
  char v168; // [rsp+4E8h] [rbp-2C8h]
  void *v169; // [rsp+4F8h] [rbp-2B8h]
  unsigned __int64 v170; // [rsp+500h] [rbp-2B0h]
  char v171; // [rsp+508h] [rbp-2A8h]
  unsigned __int64 v172; // [rsp+510h] [rbp-2A0h]
  unsigned int v173; // [rsp+518h] [rbp-298h]
  _BOOL4 v174; // [rsp+51Ch] [rbp-294h]
  int *v175; // [rsp+520h] [rbp-290h]
  __int128 v176; // [rsp+528h] [rbp-288h]
  char v177; // [rsp+538h] [rbp-278h]
  char v178; // [rsp+539h] [rbp-277h]
  char v179; // [rsp+53Ah] [rbp-276h]
  __int128 v180; // [rsp+53Bh] [rbp-275h]
  __int16 v181; // [rsp+54Bh] [rbp-265h]
  char v182[16]; // [rsp+550h] [rbp-260h] BYREF
  void *v183; // [rsp+560h] [rbp-250h]
  char v184; // [rsp+568h] [rbp-248h]
  __int64 v185; // [rsp+570h] [rbp-240h] BYREF
  char v186; // [rsp+578h] [rbp-238h]
  void *v187[3]; // [rsp+580h] [rbp-230h] BYREF
  int v188; // [rsp+598h] [rbp-218h]
  char v189; // [rsp+59Ch] [rbp-214h]
  __int64 v190; // [rsp+5A0h] [rbp-210h] BYREF
  __int64 v191; // [rsp+5A8h] [rbp-208h] BYREF
  char v192[64]; // [rsp+5B0h] [rbp-200h] BYREF
  _QWORD v193[3]; // [rsp+5F0h] [rbp-1C0h] BYREF
  void *v194; // [rsp+608h] [rbp-1A8h]
  __int128 v195; // [rsp+610h] [rbp-1A0h]
  __int128 v196; // [rsp+620h] [rbp-190h] BYREF
  void *v197; // [rsp+630h] [rbp-180h]
  __int128 v198; // [rsp+638h] [rbp-178h] BYREF
  void *v199; // [rsp+648h] [rbp-168h]
  __int128 v200; // [rsp+650h] [rbp-160h] BYREF
  void *v201; // [rsp+660h] [rbp-150h]
  __int128 v202; // [rsp+668h] [rbp-148h]
  __int128 v203; // [rsp+678h] [rbp-138h]
  void *v204; // [rsp+688h] [rbp-128h]
  __int128 v205; // [rsp+690h] [rbp-120h]
  void *v206; // [rsp+6A0h] [rbp-110h]
  __int128 v207; // [rsp+6A8h] [rbp-108h]
  __int128 v208; // [rsp+6B8h] [rbp-F8h]
  _BYTE v209[45]; // [rsp+6C8h] [rbp-E8h]
  __int128 v210; // [rsp+6F8h] [rbp-B8h]
  void *v211; // [rsp+708h] [rbp-A8h]
  char v212; // [rsp+710h] [rbp-A0h]
  __int64 v213; // [rsp+718h] [rbp-98h]
  char v214; // [rsp+720h] [rbp-90h]
  void *v215[3]; // [rsp+728h] [rbp-88h] BYREF
  int v216; // [rsp+740h] [rbp-70h]
  char v217; // [rsp+744h] [rbp-6Ch]
  _QWORD v218[4]; // [rsp+750h] [rbp-60h] BYREF
  _QWORD *v219; // [rsp+770h] [rbp-40h]

  v138 = a5; /*0x1066ea510*/
  v132 = a4; /*0x1066ea517*/
  *(_DWORD *)(a1 + 592) = a7; /*0x1066ea53c*/
  v17 = RBX::Reflection::ValueTable::find(this: *a8, a2: "UserId"); /*0x1066ea54c*/
  v139 = (RBX::Network::Peer *)a1; /*0x1066ea55a*/
  *(_QWORD *)(a1 + 536) = RBX::Reflection::Variant::get<long long>(a1: v17 + 40); /*0x1066ea561*/
  v137 = a2; /*0x1066ea568*/
  if ( a2 > 0 ) /*0x1066ea572*/
  {
    v18 = (void *)v137; /*0x1066ea578*/
    if ( (__int64)(v137 % 0x3E8) < DFInt::ClientJoinProcessPositiveSamplesThousandths ) /*0x1066ea5b1*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v121, a2: "client", a3: v137 / 0x3E8, a4: v137 % 0x3E8); /*0x1066ea5c5*/
      std::string::basic_string[abi:ne200100]<0>(a1: v123, a2: "report", a3: v19, a4: v20); /*0x1066ea5d8*/
      std::string::basic_string[abi:ne200100]<0>(a1: v125, a2: "GameServerConnectStarted", a3: v21, a4: v22); /*0x1066ea5eb*/
      memset(v120, 0, 32); /*0x1066ea5fe*/
      v120[8] = 1065353216; /*0x1066ea601*/
      RBX::Analytics::EventIngest::setRBXEvent(a1: v121, a2: v123, a3: v125, a4: v120); /*0x1066ea61d*/
      std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v120); /*0x1066ea629*/
      if ( (v125[0] & 1) != 0 ) /*0x1066ea635*/
        operator delete(a1: (RBX::Memory *)v126, a2: v18); /*0x1066ea63e*/
      if ( (v123[0] & 1) != 0 ) /*0x1066ea64a*/
        operator delete(a1: (RBX::Memory *)v124, a2: v18); /*0x1066ea653*/
      if ( (v121[0] & 1) != 0 ) /*0x1066ea65f*/
        operator delete(a1: (RBX::Memory *)v122, a2: v18); /*0x1066ea668*/
    }
  }
  v134 = (RBX::Network *)RBX::DataModel::get(this: v139, a2: (RBX::Instance *)v18); /*0x1066ea679*/
  if ( v134 != nullptr ) /*0x1066ea688*/
  {
    RBX::Time::nowFast(this: v23); /*0x1066ea68a*/
    v136 = v25; /*0x1066ea68f*/
    v27 = RBX::DataModel::get(this: v139, a2: v26); /*0x1066ea69e*/
    v28 = v136 - *(double *)(v27 + 1776); /*0x1066ea6b3*/
    v29 = v134; /*0x1066ea6b7*/
    *((float *)v134 + 446) = v28; /*0x1066ea6be*/
    *((_DWORD *)v29 + 449) = a7; /*0x1066ea6c9*/
    if ( FFlag::SAuthWorkspaceFlagged == 0 ) /*0x1066ea6d9*/
    {
      EngineNetConfiguration = (_BYTE *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::Peer *)((char *)v139 + 2304)); /*0x1066eab74*/
      if ( FFlag::DebugHashTableMetrics != 0 || FFlag::SAuthWorkspaceFlagged == 1 && (*EngineNetConfiguration & 8) != 0 ) /*0x1066eb19e*/
      {
        v60 = *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::AuroraService>(this: (RBX::Network *)((char *)v134 + 464)); /*0x1066eab9c*/
        if ( v60 != 0 ) /*0x1066eaba2*/
        {
          v61 = RBX::Memory::setCurrentCategory( /*0x1066eabb6*/
                  this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal,
                  a2: (unsigned int)v24);
          v62 = (rbx::signals::slots_holder **)(v60 + 272); /*0x1066eabb9*/
          rbx::lazyInitSlotsHolder(a1: v62); /*0x1066eabc3*/
          v64 = (volatile signed __int32 *)rbx::signals::slot_base::operator new( /*0x1066eabd2*/
                                             this: (rbx::signals::slot_base *)0x38,
                                             a2: v63);
          *(_QWORD *)v64 = &_mh_execute_header; /*0x1066eabdf*/
          *((_QWORD *)v64 + 1) = rbx::signals::slot_with_functor<RBX::Network::Client::playerConnectWithConnectionInternal(long long,RBX::Network::FinalConnectionArgs const&,RBX::Network::FinalConnectionArgs const&,int,int,int,std::shared_ptr<RBX::Reflection::ValueTable const>,RBX::Rupp::TokenTlv::Token &,bool,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_2,int,int>::do_call; /*0x1066eabe9*/
          *((_OWORD *)v64 + 1) = 0; /*0x1066eabf0*/
          v65 = *v62; /*0x1066eabf5*/
          *((_QWORD *)v64 + 4) = *v62; /*0x1066eabf9*/
          if ( v65 != nullptr ) /*0x1066eac00*/
          {
            _InterlockedIncrement((volatile signed __int32 *)v65 + 1); /*0x1066eac06*/
            v66 = *((_QWORD *)v64 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x1066eac0e*/
          }
          else
          {
            v66 = 0; /*0x1066eb873*/
          }
          *((_QWORD *)v64 + 3) = v66; /*0x1066eb875*/
          *((_QWORD *)v64 + 5) = v139; /*0x1066eb880*/
          *((_QWORD *)v64 + 6) = v134; /*0x1066eb88b*/
          rbx::signals::slots_holder::insert(this: *v62, a2: (unsigned __int64)v64); /*0x1066eb896*/
          v118[0] = (void *)v64; /*0x1066eb89b*/
          _InterlockedIncrement(v64 + 1); /*0x1066eb8a2*/
          RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v61, a2: v102); /*0x1066eb8aa*/
          rbx::signals::scoped_connection::operator=(this: (RBX::Network::Peer *)((char *)v139 + 496)); /*0x1066eb8c4*/
          if ( v64 != nullptr && _InterlockedDecrement((volatile signed __int32 *)v118[0] + 1) == 0 ) /*0x1066eb8dd*/
            rbx::signals::slot_base::operator delete(a1: (void *)v64); /*0x1066eb8e3*/
        }
      }
    }
  }
  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v139, a2: v24); /*0x1066ea6e6*/
  if ( ServiceProvider == nullptr /*0x1066ea702*/
    || (v31 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::Players>(this: ServiceProvider), v33 = v31, v31 == 0) )
  {
    exception = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x1066eb8f7*/
    RBX::runtime_error( /*0x1066eb906*/
      this: exception,
      a2: "Cannot get players",
      a3: v104,
      a4: v105,
      a5: v106,
      a6: v107,
      a7: v108,
      a8: v109,
      a9: v110,
      a10: v111,
      a11: v112,
      a12: v113,
      a13: v114,
      a14: v115,
      a15: v117);
    __cxa_throw( /*0x1066eb91c*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  if ( *(_QWORD *)(v31 + 288) != 0 ) /*0x1066ea710*/
    RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066ea732*/
      this: (RBX::Network::ConcurrentRakPeer **)v139,
      a2: "ReJoinFromSameDataModel",
      a3: 0,
      a4: "",
      a5: 0,
      a6: 1);
  v190 = RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::ValueTable const>>(a1: v32); /*0x1066ea743*/
  v191 = 0; /*0x1066ea747*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::shared_ptr<RBX::Reflection::ValueTable const>>( /*0x1066ea752*/
    a1: &v191,
    a2: (__int64)a8);
  if ( (unsigned __int8)RBX::WebParser::writeJSON(a1: &v190, a2: (char *)v139 + 672, a3: 1, a4: 0) == 0 ) /*0x1066ea77a*/
  {
    v116 = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x1066eb92d*/
    std::runtime_error::runtime_error(this: v116, a2: "Cannot construct player information to send to server"); /*0x1066eb93a*/
    __cxa_throw( /*0x1066eb950*/
      a1: v116,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  v35 = &DFInt::CliMaxPayloadRcv; /*0x1066ea795*/
  if ( *((_DWORD *)v139 + 1236) == 2 ) /*0x1066ea79c*/
    v35 = &DFInt::CliTcMaxPayloadRcv; /*0x1066ea79c*/
  v36 = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v139, a2: v34); /*0x1066ea7a0*/
  if ( v36 != nullptr ) /*0x1066ea7a8*/
    v37 = (RBX::RunService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::RunService>(this: v36); /*0x1066ea7b2*/
  else
    v37 = nullptr; /*0x1066ea7b7*/
  v127 = v33; /*0x1066ea7b9*/
  *(double *)&v38 = COERCE_DOUBLE(RBX::RunService::isStudio(this: v37)); /*0x1066ea7c0*/
  v39 = 0x4082C00000000000LL; /*0x1066ea7c5*/
  v40 = *((_DWORD *)v139 + 1236); /*0x1066ea7d6*/
  v41 = DFFlag::DebugDisableTimeoutDisconnect; /*0x1066ea7ec*/
  v133 = a3; /*0x1066ea7f1*/
  if ( (((unsigned int)(v40 - 3) < 0xFFFFFFFE) & (unsigned __int8)v38) != 0 ) /*0x1066ea7f8*/
  {
    v136 = 0.0; /*0x1066ea7fa*/
LABEL_27:
    v43 = 0; /*0x1066ea83f*/
    goto LABEL_28; /*0x1066ea83f*/
  }
  LOBYTE(v38) = 1; /*0x1066ea807*/
  v136 = *(double *)&v38; /*0x1066ea809*/
  if ( v40 != 2 ) /*0x1066ea813*/
    goto LABEL_27; /*0x1066ea813*/
  v42 = (double)DFInt::TeamCreateTimeOutInSec; /*0x1066ea815*/
  v41 = 1; /*0x1066ea823*/
  if ( DFFlag::DebugDisableTimeoutDisconnect != 0 ) /*0x1066ea829*/
    v41 = DFFlag::DebugDisableTimeoutDisconnect; /*0x1066ea829*/
  v43 = LOBYTE(v42); /*0x1066ea832*/
  v39 = *(_QWORD *)&v42 & 0xFFFFFFFFFFFFFF00LL; /*0x1066ea836*/
LABEL_28:
  isLocalTest = RBX::Network::Peer::isLocalTest(this: v139); /*0x1066ea842*/
  RBX::Security::RakPeerCrypto::getRbxTransportClientKeyInfo( /*0x1066ea861*/
    this: (RBX::Security::RakPeerCrypto *)&v128,
    a2: (DFFlag::DebugRbxTransportUseTestKey | isLocalTest) & 1);
  v157 = v139; /*0x1066ea874*/
  v45 = v133; /*0x1066ea878*/
  RBX::Network::ConnectionInfo::ConnectionInfo(this: (RBX::Network::ConnectionInfo *)v158, a2: v133); /*0x1066ea882*/
  RBX::Network::ConnectionInfo::ConnectionInfo( /*0x1066ea892*/
    this: (RBX::Network::ConnectionInfo *)v164,
    a2: (RBX::Network::ConnectionInfo *)((char *)v45 + 88));
  v46 = v43 | v39; /*0x1066ea8a6*/
  v170 = v46; /*0x1066ea8b0*/
  v171 = v41; /*0x1066ea8b4*/
  v172 = v137; /*0x1066ea8bf*/
  v173 = a7; /*0x1066ea8c6*/
  v174 = v138; /*0x1066ea8cf*/
  v175 = v35; /*0x1066ea8d2*/
  v176 = *a9; /*0x1066ea8db*/
  v177 = *((_BYTE *)a9 + 16); /*0x1066ea8e3*/
  v178 = LOBYTE(v136); /*0x1066ea8ed*/
  v179 = a10; /*0x1066ea8f0*/
  v180 = a11; /*0x1066ea8f7*/
  v181 = a12; /*0x1066ea900*/
  std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: v182, a2: a13); /*0x1066ea904*/
  LOBYTE(v185) = 0; /*0x1066ea90f*/
  v186 = 0; /*0x1066ea915*/
  if ( *(_BYTE *)(a14 + 8) == 1 ) /*0x1066ea91f*/
  {
    v185 = 0; /*0x1066ea921*/
    _InterlockedExchange64(&v185, *(_QWORD *)a14); /*0x1066ea92f*/
    v186 = 1; /*0x1066ea936*/
  }
  memset(v187, 0, sizeof(v187)); /*0x1066ea948*/
  std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1066ea968*/
    a1: v187,
    a2: v128,
    a3: v129,
    a4: v129 - (_BYTE *)v128);
  v189 = v131; /*0x1066ea973*/
  v188 = v130; /*0x1066ea97f*/
  v140 = v139; /*0x1066ea993*/
  v47 = v132; /*0x1066ea997*/
  RBX::Network::ConnectionInfo::ConnectionInfo(this: (RBX::Network::ConnectionInfo *)&v141, a2: v132); /*0x1066ea9a1*/
  RBX::Network::ConnectionInfo::ConnectionInfo( /*0x1066ea9b2*/
    this: (RBX::Network::ConnectionInfo *)v148,
    a2: (RBX::Network::ConnectionInfo *)((char *)v47 + 88));
  *(_QWORD *)&v154 = v46; /*0x1066ea9b7*/
  BYTE8(v154) = v41; /*0x1066ea9be*/
  *(_QWORD *)&v155 = v137; /*0x1066ea9cc*/
  *((_QWORD *)&v155 + 1) = __PAIR64__(v138, a7); /*0x1066ea9d6*/
  v156[0] = v35; /*0x1066ea9e8*/
  *(_OWORD *)&v156[1] = *a9; /*0x1066ea9f5*/
  LOBYTE(v156[3]) = *((_BYTE *)a9 + 16); /*0x1066eaa01*/
  BYTE1(v156[3]) = LOBYTE(v136); /*0x1066eaa0e*/
  BYTE2(v156[3]) = a10; /*0x1066eaa17*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1066eaa2b*/
    a1: (__int64)v118,
    a2: (__int64)&RBX::Telemetry::kConnectionTransportBranchSelection);
  if ( (unsigned __int8)RBX::Network::useRbxTransport(this: nullptr, a2: v48) != 0 /*0x1066eaa42*/
    || FFlag::RakNetConnectionFailureFallbackToRbxTransport == 1 )
  {
    v51 = *((_DWORD *)v133 + 6); /*0x1066eaa4f*/
    v52 = *(unsigned __int8 *)v133; /*0x1066eaa53*/
    if ( (v52 & 1) != 0 ) /*0x1066eaa5b*/
      v53 = *((_QWORD *)v133 + 1); /*0x1066eaa5d*/
    else
      v53 = v52 >> 1; /*0x1066eaa63*/
    LOBYTE(v49) = v53 != 0; /*0x1066eaa69*/
    v54 = v128; /*0x1066eaa6c*/
    v55 = v129; /*0x1066eaa73*/
    v56 = v128 != v129; /*0x1066eaa7f*/
    v57 = 0; /*0x1066eaa82*/
    LODWORD(v136) = v49; /*0x1066eaa84*/
    v138 = v56; /*0x1066eaa8d*/
    if ( v53 == 0 ) /*0x1066eaa93*/
      v56 = false; /*0x1066eaa93*/
    LOBYTE(v57) = v51 != 0; /*0x1066eaa99*/
    v135 = v57; /*0x1066eaa9c*/
    if ( v51 == 0 ) /*0x1066eaaa2*/
      v56 = false; /*0x1066eaaa2*/
    LODWORD(v137) = v56; /*0x1066eaaa6*/
    v58 = RBX::Network::useRbxTransport(this: nullptr, a2: v50); /*0x1066eaaae*/
    RBX::Telemetry::FieldsContainer::addField(a1: v119, a2: "useRbxTransportEnabled", a3: 22, a4: v58, a5: 1); /*0x1066eaad2*/
    RBX::Telemetry::FieldsContainer::addField(a1: v119, a2: "rbxTransportHasValidPort", a3: 24, a4: v51 != 0, a5: 1); /*0x1066eaaf4*/
    RBX::Telemetry::FieldsContainer::addField(a1: v119, a2: "rbxTransportHasValidAddress", a3: 27, a4: v53 != 0, a5: 1); /*0x1066eab16*/
    RBX::Telemetry::FieldsContainer::addField(a1: v119, a2: "rbxTransportHasValidPubKey", a3: 26, a4: v54 != v55, a5: 1); /*0x1066eab38*/
    RBX::Telemetry::FieldsContainer::addField(a1: v119, a2: "canUseRbxTransport", a3: 18, a4: v137 & 1, a5: 1); /*0x1066eab5c*/
  }
  else
  {
    LODWORD(v137) = 0; /*0x1066eac17*/
    v138 = false; /*0x1066eac21*/
    LODWORD(v136) = 0; /*0x1066eac2b*/
    v135 = 0; /*0x1066eac35*/
  }
  if ( (unsigned __int8)RBX::Network::useRbxTransport(this: nullptr, a2: v50) == 0 )
  {
    RBX::Telemetry::FieldsContainer::addField(a1: v119, a2: "useRbxTransportEnabled", a3: 22, a4: 0, a5: 1); /*0x1066eadb5*/
    RBX::Telemetry::FieldsContainer::addField(a1: v119, a2: "selectedTransport", a3: 17, a4: "RakNet", a5: 1); /*0x1066eadd6*/
    if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 )
    {
      v70 = *((unsigned int *)v139 + 148); /*0x1066eae0e*/
      v193[0] = *((unsigned int *)v132 + 6); /*0x1066eae1b*/
      v193[2] = v70; /*0x1066eae1e*/
      v218[0] = 17; /*0x1066eae22*/
      v218[1] = v193; /*0x1066eae2a*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: (_DWORD)DFLog::NetworkClient,
        a2: qword_10D809380,
        a3: 4,
        a4: (unsigned int)"[DFLog::NetworkClient] Transport selection: useRbxTransportEnabled=false, selectedTransport=RakNet"
                      ", rccPort={}, DatacenterId={}",
        a5: 127,
        a6: 1,
        17,
        v193);
    }
    RBX::Network::Client::playerConnectWithConnectionInternal(long long,RBX::Network::FinalConnectionArgs const&,RBX::Network::FinalConnectionArgs const&,int,int,int,std::shared_ptr<RBX::Reflection::ValueTable const>,RBX::Rupp::TokenTlv::Token &,bool,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_0::operator()(a1: &v140); /*0x1066eae5c*/
    RBX::Telemetry::FieldsContainer::addField( /*0x1066eae7d*/
      a1: v119,
      a2: "failureFallbackToRbxTransport",
      a3: 29,
      a4: (unsigned __int8)FFlag::RakNetConnectionFailureFallbackToRbxTransport,
      a5: 1);
    if ( FFlag::RakNetConnectionFailureFallbackToRbxTransport != 1 ) /*0x1066eae89*/
      goto LABEL_104; /*0x1066eae89*/
    v71 = (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0; /*0x1066eaea6*/
    if ( (v137 & 1) == 0 ) /*0x1066eaeaf*/
    {
      if ( v71 ) /*0x1066eb1ab*/
      {
        v193[0] = (unsigned __int8)v135; /*0x1066eb1dc*/
        v193[2] = LOBYTE(v136); /*0x1066eb1df*/
        *(_QWORD *)&v195 = v138; /*0x1066eb1e3*/
        *(_QWORD *)&v196 = (unsigned __int8)v137; /*0x1066eb1e7*/
        v218[0] = 30583; /*0x1066eb1eb*/
        v218[1] = v193; /*0x1066eb1f3*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x1066eb219*/
          a1: (_DWORD)DFLog::NetworkClient,
          a2: qword_10D809380,
          a3: 4,
          a4: (unsigned int)"[DFLog::NetworkClient] RakNet connection selected. RbxTransport cannot be used as fallback becau"
                        "se rbxTransportHasValidPort={}, rbxTransportHasValidAddress={}, rbxTransportHasValidPubKey={}, c"
                        "anUseRbxTransport={}",
          a5: 212,
          a6: 1,
          30583,
          v193);
      }
      goto LABEL_104; /*0x1066eb21e*/
    }
    if ( v71 ) /*0x1066eaebb*/
    {
      v193[0] = 0; /*0x1066eaec4*/
      v193[1] = v218; /*0x1066eaecf*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x1066eaefb*/
        a1: (_DWORD)DFLog::NetworkClient,
        a2: qword_10D809380,
        a3: 4,
        a4: (unsigned int)"[DFLog::NetworkClient] RakNet connection selected. Setting up fallback to RbxTransport if connection fails. ",
        a5: 108,
        a6: 1,
        0,
        v218);
    }
    RBX::Network::Client::playerConnectWithConnectionInternal(long long,RBX::Network::FinalConnectionArgs const&,RBX::Network::FinalConnectionArgs const&,int,int,int,std::shared_ptr<RBX::Reflection::ValueTable const>,RBX::Rupp::TokenTlv::Token &,bool,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_1::$_1( /*0x1066eaf0e*/
      a1: v193,
      a2: &v157);
    v219 = nullptr; /*0x1066eaf13*/
    v73 = operator new(a1: (RBX::Memory *)0x160, a2: v72); /*0x1066eaf20*/
    *(_QWORD *)v73 = &off_10CAA76A8; /*0x1066eaf2c*/
    *(_QWORD *)(v73 + 8) = v193[0]; /*0x1066eaf36*/
    *(_QWORD *)(v73 + 32) = v194; /*0x1066eaf41*/
    *(_OWORD *)(v73 + 16) = *(_OWORD *)&v193[1]; /*0x1066eaf4c*/
    v194 = nullptr; /*0x1066eaf52*/
    *(_OWORD *)&v193[1] = 0; /*0x1066eaf5c*/
    *(_OWORD *)(v73 + 40) = v195; /*0x1066eaf6a*/
    *(_QWORD *)(v73 + 72) = v197; /*0x1066eaf75*/
    *(_OWORD *)(v73 + 56) = v196; /*0x1066eaf80*/
    v196 = 0; /*0x1066eaf84*/
    v197 = nullptr; /*0x1066eaf8b*/
    *(_QWORD *)(v73 + 96) = v199; /*0x1066eaf99*/
    *(_OWORD *)(v73 + 80) = v198; /*0x1066eafa4*/
    v198 = 0; /*0x1066eafa8*/
    v199 = nullptr; /*0x1066eafaf*/
    *(_QWORD *)(v73 + 120) = v201; /*0x1066eafbd*/
    *(_OWORD *)(v73 + 104) = v200; /*0x1066eafc8*/
    v201 = nullptr; /*0x1066eafcc*/
    v200 = 0; /*0x1066eafd3*/
    *(_OWORD *)(v73 + 128) = v202; /*0x1066eafe1*/
    *(_OWORD *)(v73 + 144) = v203; /*0x1066eafef*/
    *(_QWORD *)(v73 + 160) = v204; /*0x1066eaffd*/
    v204 = nullptr; /*0x1066eb004*/
    v203 = 0; /*0x1066eb00b*/
    *(_QWORD *)(v73 + 184) = v206; /*0x1066eb019*/
    *(_OWORD *)(v73 + 168) = v205; /*0x1066eb027*/
    v206 = nullptr; /*0x1066eb02e*/
    v205 = 0; /*0x1066eb035*/
    *(_OWORD *)(v73 + 253) = *(_OWORD *)&v209[29]; /*0x1066eb043*/
    v74 = v207; /*0x1066eb04a*/
    v75 = v208; /*0x1066eb051*/
    v76 = *(_OWORD *)v209; /*0x1066eb058*/
    *(_OWORD *)(v73 + 240) = *(_OWORD *)&v209[16]; /*0x1066eb066*/
    *(_OWORD *)(v73 + 224) = v76; /*0x1066eb06d*/
    *(_OWORD *)(v73 + 208) = v75; /*0x1066eb074*/
    *(_OWORD *)(v73 + 192) = v74; /*0x1066eb07b*/
    *(_BYTE *)(v73 + 272) = 0; /*0x1066eb082*/
    *(_BYTE *)(v73 + 296) = 0; /*0x1066eb088*/
    if ( v212 == 1 ) /*0x1066eb095*/
    {
      *(_QWORD *)(v73 + 288) = v211; /*0x1066eb0a8*/
      *(_OWORD *)(v73 + 272) = v210; /*0x1066eb0b3*/
      v210 = 0; /*0x1066eb0b6*/
      v211 = nullptr; /*0x1066eb0bd*/
      *(_BYTE *)(v73 + 296) = 1; /*0x1066eb0c8*/
    }
    v77 = (char *)v139 + 4768; /*0x1066eb0d6*/
    *(_BYTE *)(v73 + 304) = 0; /*0x1066eb0df*/
    *(_BYTE *)(v73 + 312) = 0; /*0x1066eb0e5*/
    if ( v214 == 1 ) /*0x1066eb0f2*/
    {
      *(_QWORD *)(v73 + 304) = 0; /*0x1066eb0f4*/
      _InterlockedExchange64((volatile __int64 *)(v73 + 304), v213); /*0x1066eb106*/
      *(_BYTE *)(v73 + 312) = 1; /*0x1066eb10d*/
    }
    qmemcpy((void *)(v73 + 320), v215, 24); /*0x1066eb11c*/
    memset(v215, 0, sizeof(v215)); /*0x1066eb133*/
    *(_BYTE *)(v73 + 348) = v217; /*0x1066eb146*/
    *(_DWORD *)(v73 + 344) = v216; /*0x1066eb14f*/
    v219 = (_QWORD *)v73; /*0x1066eb155*/
    std::__function::__value_func<void ()(void)>::swap[abi:ne200100](a1: (__int64)v218, a2: (__int64)v77); /*0x1066eb15c*/
    if ( v219 == v218 ) /*0x1066eb168*/
    {
      v79 = 32; /*0x1066eb487*/
    }
    else
    {
      v79 = 40; /*0x1066eb16e*/
      if ( v219 == nullptr ) /*0x1066eb176*/
        goto LABEL_87; /*0x1066eb176*/
    }
    (*(void (**)(void))(*v219 + v79))(); /*0x1066eb48f*/
LABEL_87:
    if ( v215[0] != nullptr ) /*0x1066eb49c*/
    {
      v215[1] = v215[0]; /*0x1066eb49e*/
      operator delete(a1: (RBX::Memory *)v215[0], a2: v78); /*0x1066eb4a2*/
    }
    if ( v212 == 1 && (v210 & 1) != 0 ) /*0x1066eb4b7*/
      operator delete(a1: (RBX::Memory *)v211, a2: v78); /*0x1066eb4c0*/
    goto LABEL_92; /*0x1066eb4c0*/
  }
  v67 = "RakNet"; /*0x1066eac5c*/
  if ( (v137 & 1) != 0 ) /*0x1066eac6a*/
    v67 = "RbxTransport"; /*0x1066eac6a*/
  RBX::Telemetry::FieldsContainer::addField(a1: v119, a2: "selectedTransport", a3: 17, a4: v67, a5: 1); /*0x1066eac86*/
  if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 )
  {
    v68 = *((unsigned int *)v133 + 6); /*0x1066eacd5*/
    v69 = *((unsigned int *)v139 + 148); /*0x1066eace0*/
    v193[0] = (unsigned __int8)v135; /*0x1066eacee*/
    v193[2] = LOBYTE(v136); /*0x1066eacf1*/
    *(_QWORD *)&v195 = v138; /*0x1066eacf5*/
    *(_QWORD *)&v196 = (unsigned __int8)v137; /*0x1066eacf9*/
    v197 = v67; /*0x1066eacfd*/
    *((_QWORD *)&v198 + 1) = v68; /*0x1066ead01*/
    *(_QWORD *)&v200 = v69; /*0x1066ead05*/
    v218[0] = 18642807; /*0x1066ead09*/
    v218[1] = v193; /*0x1066ead11*/
    FLog::detail::FastLogSafeFormattedInternal(
      a1: (_DWORD)DFLog::NetworkClient,
      a2: qword_10D809380,
      a3: 4,
      a4: (unsigned int)"[DFLog::NetworkClient] Transport selection: useRbxTransportEnabled=true, rbxTransportHasValidPort={}"
                    ", rbxTransportHasValidAddress={}, rbxTransportHasValidPubKey={}, canUseRbxTransport={}, selectedTran"
                    "sport={}, rccPort={}, DatacenterId={}",
      a5: 237,
      a6: 1,
      18642807,
      v193);
  }
  if ( (v137 & 1) == 0 ) /*0x1066ead43*/
  {
    RBX::Network::Client::playerConnectWithConnectionInternal(long long,RBX::Network::FinalConnectionArgs const&,RBX::Network::FinalConnectionArgs const&,int,int,int,std::shared_ptr<RBX::Reflection::ValueTable const>,RBX::Rupp::TokenTlv::Token &,bool,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_0::operator()(a1: &v140); /*0x1066eb188*/
    goto LABEL_104; /*0x1066eb18d*/
  }
  RBX::Network::Client::playerConnectWithConnectionInternal(long long,RBX::Network::FinalConnectionArgs const&,RBX::Network::FinalConnectionArgs const&,int,int,int,std::shared_ptr<RBX::Reflection::ValueTable const>,RBX::Rupp::TokenTlv::Token &,bool,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_1::operator()(a1: &v157); /*0x1066ead50*/
  if ( FFlag::RbxTransportConnectionFailureFallbackToRakNet == 1 ) /*0x1066ead5c*/
  {
    v193[0] = v140; /*0x1066ead70*/
    if ( (v141 & 1) != 0 ) /*0x1066ead7b*/
    {
      std::string::__init_copy_ctor_external(a1: &v193[1], a2: v142, a3: *((_QWORD *)&v141 + 1)); /*0x1066eb234*/
    }
    else
    {
      v194 = v142; /*0x1066ead8c*/
      *(_OWORD *)&v193[1] = v141; /*0x1066ead94*/
    }
    v195 = v143; /*0x1066eb248*/
    if ( (v144 & 1) != 0 ) /*0x1066eb255*/
    {
      std::string::__init_copy_ctor_external(a1: &v196, a2: v145, a3: *((_QWORD *)&v144 + 1)); /*0x1066eb282*/
    }
    else
    {
      v197 = v145; /*0x1066eb262*/
      v196 = v144; /*0x1066eb26a*/
    }
    if ( (v146 & 1) != 0 ) /*0x1066eb295*/
    {
      std::string::__init_copy_ctor_external(a1: &v198, a2: v147, a3: *((_QWORD *)&v146 + 1)); /*0x1066eb2c4*/
    }
    else
    {
      v199 = v147; /*0x1066eb2a2*/
      v198 = v146; /*0x1066eb2ab*/
    }
    RBX::Network::ConnectionInfo::ConnectionInfo( /*0x1066eb2da*/
      this: (RBX::Network::ConnectionInfo *)&v200,
      a2: (const RBX::Network::ConnectionInfo *)v148);
    qmemcpy(v209, v156, 27); /*0x1066eb2f6*/
    v208 = v155; /*0x1066eb304*/
    v207 = v154; /*0x1066eb30b*/
    v81 = operator new(a1: (RBX::Memory *)0x100, a2: v80); /*0x1066eb318*/
    v82 = (char *)v139 + 4672; /*0x1066eb324*/
    *(_QWORD *)v81 = &off_10CAA7628; /*0x1066eb339*/
    *(_QWORD *)(v81 + 8) = v193[0]; /*0x1066eb340*/
    *(_QWORD *)(v81 + 32) = v194; /*0x1066eb348*/
    *(_OWORD *)(v81 + 16) = *(_OWORD *)&v193[1]; /*0x1066eb350*/
    *(_OWORD *)&v193[1] = 0; /*0x1066eb357*/
    v194 = nullptr; /*0x1066eb35d*/
    *(_OWORD *)(v81 + 40) = v195; /*0x1066eb364*/
    *(_QWORD *)(v81 + 72) = v197; /*0x1066eb36c*/
    *(_OWORD *)(v81 + 56) = v196; /*0x1066eb374*/
    v196 = 0; /*0x1066eb378*/
    v197 = nullptr; /*0x1066eb37c*/
    *(_QWORD *)(v81 + 96) = v199; /*0x1066eb385*/
    *(_OWORD *)(v81 + 80) = v198; /*0x1066eb38e*/
    v198 = 0; /*0x1066eb392*/
    v199 = nullptr; /*0x1066eb397*/
    *(_QWORD *)(v81 + 120) = v201; /*0x1066eb3a0*/
    *(_OWORD *)(v81 + 104) = v200; /*0x1066eb3a9*/
    v200 = 0; /*0x1066eb3ad*/
    v201 = nullptr; /*0x1066eb3b2*/
    *(_OWORD *)(v81 + 128) = v202; /*0x1066eb3ba*/
    *(_QWORD *)(v81 + 160) = v204; /*0x1066eb3c5*/
    *(_OWORD *)(v81 + 144) = v203; /*0x1066eb3d0*/
    v204 = nullptr; /*0x1066eb3d7*/
    v203 = 0; /*0x1066eb3db*/
    *(_QWORD *)(v81 + 184) = v206; /*0x1066eb3e6*/
    *(_OWORD *)(v81 + 168) = v205; /*0x1066eb3f4*/
    v206 = nullptr; /*0x1066eb3fb*/
    v205 = 0; /*0x1066eb402*/
    v83 = v154; /*0x1066eb409*/
    v84 = v155; /*0x1066eb40d*/
    v85 = *(_OWORD *)v156; /*0x1066eb411*/
    *(_OWORD *)(v81 + 235) = *(_OWORD *)((char *)&v156[1] + 3); /*0x1066eb419*/
    *(_OWORD *)(v81 + 224) = v85; /*0x1066eb420*/
    *(_OWORD *)(v81 + 208) = v84; /*0x1066eb427*/
    *(_OWORD *)(v81 + 192) = v83; /*0x1066eb42e*/
    *(_DWORD *)(v81 + 251) = 0; /*0x1066eb436*/
    *(_BYTE *)(v81 + 255) = 0; /*0x1066eb440*/
    v219 = (_QWORD *)v81; /*0x1066eb44b*/
    std::__function::__value_func<void ()(void)>::swap[abi:ne200100](a1: (__int64)v218, a2: (__int64)v82); /*0x1066eb452*/
    if ( v219 == v218 ) /*0x1066eb45e*/
    {
      v86 = 32; /*0x1066eb473*/
    }
    else
    {
      v86 = 40; /*0x1066eb460*/
      if ( v219 == nullptr ) /*0x1066eb46f*/
        goto LABEL_92; /*0x1066eb46f*/
    }
    (*(void (**)(void))(*v219 + v86))(); /*0x1066eb482*/
LABEL_92:
    if ( (v205 & 1) != 0 ) /*0x1066eb4cc*/
      operator delete(a1: (RBX::Memory *)v206, a2: v78); /*0x1066eb4d5*/
    if ( (v203 & 1) != 0 ) /*0x1066eb4e1*/
      operator delete(a1: (RBX::Memory *)v204, a2: v78); /*0x1066eb4ea*/
    if ( (v200 & 1) != 0 ) /*0x1066eb4f6*/
      operator delete(a1: (RBX::Memory *)v201, a2: v78); /*0x1066eb4ff*/
    if ( (v198 & 1) != 0 ) /*0x1066eb50b*/
      operator delete(a1: (RBX::Memory *)v199, a2: v78); /*0x1066eb514*/
    if ( (v196 & 1) != 0 ) /*0x1066eb520*/
      operator delete(a1: (RBX::Memory *)v197, a2: v78); /*0x1066eb529*/
    if ( (v193[1] & 1) != 0 ) /*0x1066eb535*/
      operator delete(a1: (RBX::Memory *)v194, a2: v78); /*0x1066eb53e*/
  }
LABEL_104:
  if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
  {
    v87 = (SFString::RCCChannelName[0] & 1) != 0
        ? *(_QWORD *)&SFString::RCCChannelName[8]
        : SFString::RCCChannelName[0] >> 1;
    if ( v87 != 0 ) /*0x1066eb56c*/
    {
      if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1066eb570*/
        v88 = *(unsigned __int8 **)&SFString::RCCChannelName[16]; /*0x1066eb572*/
      else
        v88 = &SFString::RCCChannelName[1]; /*0x1066eb578*/
      RBX::Telemetry::FieldsContainer::addField(a1: v119, a2: "rccChannelName", a3: 14, a4: v88, a5: v87, a6: 1); /*0x1066eb590*/
    }
  }
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v118); /*0x1066eb59c*/
  if ( v134 != nullptr ) /*0x1066eb5a9*/
  {
    ConnectionInfo = (RBX::Network::ConnectionInfo *)RBX::NetworkBase::ConnectionInternal::getConnectionInfo(this: *((RBX::NetworkBase::ConnectionInternal **)v139 + 575)); /*0x1066eb5b9*/
    isIpV6 = RBX::Network::ConnectionInfo::isIpV6(this: ConnectionInfo); /*0x1066eb5c1*/
    v89 = v134; /*0x1066eb5c6*/
    *((_BYTE *)v134 + 2270) = isIpV6; /*0x1066eb5cd*/
    if ( DFFlag::FixDatacenterIdInConnectionInternal == 1 /*0x1066eb5e3*/
      && (unsigned __int8)RBX::DataModel::getShouldSetGlobalTelemetryInfo(this: v89) != 0 )
    {
      unk_10D77E5F8 = a7; /*0x1066eb5ef*/
    }
  }
  if ( FFlag::RemoveLegacyChatCodeInNetwork == 0 /*0x1066eb60c*/
    && (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v89) != 0 )
  {
    v93 = *((_QWORD *)v139 + 36); /*0x1066eb619*/
    v94 = *((_QWORD *)v139 + 574); /*0x1066eb620*/
    v95 = (__int64 *)((char *)v139 + 4600); /*0x1066eb62e*/
    if ( v94 != 0 ) /*0x1066eb638*/
      v95 = (__int64 *)(v94 + 280); /*0x1066eb638*/
    v96 = *v95; /*0x1066eb63c*/
    v97 = operator new(a1: (RBX::Memory *)0x88, a2: v92); /*0x1066eb649*/
    *(_QWORD *)v97 = &off_10CAA7128; /*0x1066eb657*/
    *(_QWORD *)(v97 + 8) = v93; /*0x1066eb65a*/
    *(_QWORD *)(v97 + 16) = v96; /*0x1066eb65e*/
    *(_QWORD *)(v97 + 24) = 0; /*0x1066eb662*/
    *(double *)(v97 + 32) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v98); /*0x1066eb66f*/
    *(_BYTE *)(v97 + 40) = 1; /*0x1066eb677*/
    *(_QWORD *)(v97 + 48) = 0x3FA999999999999ALL; /*0x1066eb685*/
    *(_OWORD *)(v97 + 56) = 0; /*0x1066eb68d*/
    *(_QWORD *)(v97 + 72) = 0; /*0x1066eb695*/
    *(_BYTE *)(v97 + 80) = 1; /*0x1066eb699*/
    *(_QWORD *)(v97 + 88) = 0; /*0x1066eb69d*/
    *(_QWORD *)(v97 + 96) = 0x3FA999999999999ALL; /*0x1066eb6a1*/
    *(_DWORD *)(v97 + 104) = 0; /*0x1066eb6a5*/
    *(_OWORD *)(v97 + 112) = 0; /*0x1066eb6ad*/
    *(_BYTE *)(v97 + 128) = 1; /*0x1066eb6b3*/
    v99 = *(_QWORD *)(v127 + 520); /*0x1066eb6c1*/
    *(_QWORD *)(v127 + 520) = v97; /*0x1066eb6c8*/
    if ( v99 != 0 ) /*0x1066eb6d2*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v99 + 48LL))(a1: v99); /*0x1066eb6d7*/
  }
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v118); /*0x1066eb6e8*/
  if ( (v152 & 1) != 0 ) /*0x1066eb6f4*/
    operator delete(a1: (RBX::Memory *)v153, a2: v100); /*0x1066eb6fd*/
  if ( (v150 & 1) != 0 ) /*0x1066eb709*/
    operator delete(a1: (RBX::Memory *)v151, a2: v100); /*0x1066eb712*/
  if ( (v148[0] & 1) != 0 ) /*0x1066eb71e*/
    operator delete(a1: (RBX::Memory *)v149, a2: v100); /*0x1066eb727*/
  if ( (v146 & 1) != 0 ) /*0x1066eb733*/
    operator delete(a1: (RBX::Memory *)v147, a2: v100); /*0x1066eb73c*/
  if ( (v144 & 1) != 0 ) /*0x1066eb748*/
    operator delete(a1: (RBX::Memory *)v145, a2: v100); /*0x1066eb751*/
  if ( (v141 & 1) != 0 ) /*0x1066eb75d*/
    operator delete(a1: (RBX::Memory *)v142, a2: v100); /*0x1066eb766*/
  if ( v187[0] != nullptr ) /*0x1066eb775*/
  {
    v187[1] = v187[0]; /*0x1066eb777*/
    operator delete(a1: (RBX::Memory *)v187[0], a2: v100); /*0x1066eb77e*/
  }
  if ( v184 == 1 && (v182[0] & 1) != 0 ) /*0x1066eb793*/
    operator delete(a1: (RBX::Memory *)v183, a2: v100); /*0x1066eb79c*/
  if ( (v168 & 1) != 0 ) /*0x1066eb7a8*/
    operator delete(a1: (RBX::Memory *)v169, a2: v100); /*0x1066eb7b1*/
  if ( (v166 & 1) != 0 ) /*0x1066eb7bd*/
    operator delete(a1: (RBX::Memory *)v167, a2: v100); /*0x1066eb7c6*/
  if ( (v164[0] & 1) != 0 ) /*0x1066eb7d2*/
    operator delete(a1: (RBX::Memory *)v165, a2: v100); /*0x1066eb7db*/
  if ( (v162 & 1) != 0 ) /*0x1066eb7e7*/
    operator delete(a1: (RBX::Memory *)v163, a2: v100); /*0x1066eb7f0*/
  if ( (v160 & 1) != 0 ) /*0x1066eb7fc*/
    operator delete(a1: (RBX::Memory *)v161, a2: v100); /*0x1066eb805*/
  if ( (v158[0] & 1) != 0 ) /*0x1066eb811*/
    operator delete(a1: (RBX::Memory *)v159, a2: v100); /*0x1066eb81a*/
  if ( v128 != nullptr ) /*0x1066eb829*/
  {
    v129 = v128; /*0x1066eb82b*/
    operator delete(a1: (RBX::Memory *)v128, a2: v100); /*0x1066eb832*/
  }
  if ( v191 != 0 ) /*0x1066eb841*/
    (*(void (__fastcall **)(char *))(v191 + 16))(a1: v192); /*0x1066eb84a*/
  return __stack_chk_guard; /*0x1066eb861*/
}

// Address: 0x1066ebbc2 | Name: __ZNK3RBX7Network6Client11isCloudEditEv
bool __fastcall RBX::Network::Client::isCloudEdit(RBX::Network::Client *this)
{
  return *((_DWORD *)this + 1236) == 2; /*0x1066ebbd0*/
}

// Address: 0x1066ebbd2 | Name: __ZNK3RBX7Network6Client11isCloudTestEv
bool __fastcall RBX::Network::Client::isCloudTest(RBX::Network::Client *this)
{
  return *((_DWORD *)this + 1236) == 1; /*0x1066ebbe0*/
}

// Address: 0x1066ebbe4 | Name: __ZZN3RBX7Network6Client35playerConnectWithConnectionInternalExRKNS0_19FinalConnectionArgsES4_iiiNSt3__110shared_ptrIKNS_10Reflection10ValueTableEEERNS_4Rupp8TokenTlv5TokenEbNS5_8optionalISD_EENSF_INS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEEENSF_INS_12RbxTransport12CapabilitiesEEEEN3$_1clEv
__int64 __fastcall RBX::Network::Client::playerConnectWithConnectionInternal(long long,RBX::Network::FinalConnectionArgs const&,RBX::Network::FinalConnectionArgs const&,int,int,int,std::shared_ptr<RBX::Reflection::ValueTable const>,RBX::Rupp::TokenTlv::Token &,bool,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_1::operator()(
        __int64 *a1)
{
  __int64 v2; // rbx
  const RBX::Network::FinalConnectionArgs *v3; // r12
  const RBX::Network::ConnectionInfo *v4; // r14
  char v5; // r13
  char *v6; // rsi
  __int64 v7; // rdx
  int v8; // r12d
  unsigned __int8 v9; // al
  __int64 v10; // rcx
  void *v11; // rsi
  void *v12; // rsi
  int v13; // r14d
  const char *v14; // rdx
  void *v15; // rsi
  __int64 v16; // rax
  __int64 v17; // rdi
  __int64 v18; // rdi
  __int64 v20; // rdx
  __int64 v21; // rcx
  __int64 v22; // r8
  __int64 v23; // r9
  __m128 v24; // xmm0
  __m128 v25; // xmm1
  __m128 v26; // xmm2
  __m128 v27; // xmm3
  __m128 v28; // xmm4
  __m128 v29; // xmm5
  __m128 v30; // xmm6
  __m128 v31; // xmm7
  const char *v32; // rsi
  char v33; // [rsp+0h] [rbp-2F0h]
  _QWORD v34[4]; // [rsp+18h] [rbp-2D8h] BYREF
  _QWORD v35[2]; // [rsp+38h] [rbp-2B8h] BYREF
  unsigned int Port; // [rsp+48h] [rbp-2A8h] BYREF
  unsigned int v37; // [rsp+4Ch] [rbp-2A4h] BYREF
  int v38; // [rsp+50h] [rbp-2A0h] BYREF
  __int128 v39; // [rsp+58h] [rbp-298h]
  void *v40; // [rsp+68h] [rbp-288h]
  __int64 v41; // [rsp+70h] [rbp-280h]
  char v42; // [rsp+7Fh] [rbp-271h]
  __int128 v43; // [rsp+80h] [rbp-270h] BYREF
  __int128 v44; // [rsp+90h] [rbp-260h]
  _WORD v45[25]; // [rsp+A0h] [rbp-250h] BYREF
  _BYTE v46[31]; // [rsp+D2h] [rbp-21Eh] BYREF
  _BYTE v47[18]; // [rsp+F1h] [rbp-1FFh] BYREF
  _BYTE v48[28]; // [rsp+103h] [rbp-1EDh] BYREF
  char v49; // [rsp+11Fh] [rbp-1D1h]
  unsigned __int8 v50[24]; // [rsp+120h] [rbp-1D0h] BYREF
  unsigned int v51[16]; // [rsp+138h] [rbp-1B8h] BYREF
  unsigned __int8 v52; // [rsp+178h] [rbp-178h] BYREF
  char v53; // [rsp+179h] [rbp-177h] BYREF
  __int64 v54; // [rsp+180h] [rbp-170h]
  char *v55; // [rsp+188h] [rbp-168h]
  unsigned int v56[16]; // [rsp+190h] [rbp-160h] BYREF
  __int64 v57; // [rsp+1D0h] [rbp-120h]
  char v58; // [rsp+1D8h] [rbp-118h]
  __int64 v59; // [rsp+1E0h] [rbp-110h]
  __int64 v60; // [rsp+1E8h] [rbp-108h]
  __int64 v61; // [rsp+1F0h] [rbp-100h]
  __int128 v62; // [rsp+1F8h] [rbp-F8h]
  __int128 v63; // [rsp+208h] [rbp-E8h]
  __int128 v64; // [rsp+218h] [rbp-D8h]
  char v65; // [rsp+228h] [rbp-C8h]
  __int64 v66; // [rsp+230h] [rbp-C0h] BYREF
  char v67; // [rsp+238h] [rbp-B8h]
  __int64 *v68; // [rsp+240h] [rbp-B0h]
  char v69; // [rsp+248h] [rbp-A8h]
  char v70; // [rsp+249h] [rbp-A7h]
  bool v71; // [rsp+24Ah] [rbp-A6h]
  char v72; // [rsp+24Bh] [rbp-A5h]
  _DWORD v73[8]; // [rsp+250h] [rbp-A0h] BYREF
  _BYTE v74[48]; // [rsp+270h] [rbp-80h] BYREF
  _BYTE v75[32]; // [rsp+2A0h] [rbp-50h] BYREF

  v2 = *a1; /*0x1066ebc09*/
  v3 = (const RBX::Network::FinalConnectionArgs *)(a1 + 1); /*0x1066ebc0c*/
  v4 = (const RBX::Network::ConnectionInfo *)(a1 + 12); /*0x1066ebc10*/
  v5 = RBX::Network::ConnectionInfo::empty(this: (RBX::Network::ConnectionInfo *)(a1 + 12)); /*0x1066ebc1c*/
  RBX::Network::Client::setupServerConnectionAndLogging(this: (RBX::Network::Client *)v2, a2: v3); /*0x1066ebc25*/
  RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066ebc46*/
    this: (RBX::Network::ConcurrentRakPeer **)v2,
    a2: "JoinStart",
    a3: 0,
    a4: "",
    a5: 0,
    a6: 1);
  *(_DWORD *)(v2 + 632) = 1; /*0x1066ebc4b*/
  RBX::Network::ConnectionInfo::ConnectionInfo(this: (RBX::Network::ConnectionInfo *)v50, a2: v4); /*0x1066ebc5f*/
  RBX::Network::ConnectionInfo::ConnectionInfo(this: (RBX::Network::ConnectionInfo *)&v52, a2: v3); /*0x1066ebc6e*/
  v58 = *((_BYTE *)a1 + 192); /*0x1066ebc88*/
  v57 = a1[23]; /*0x1066ebc93*/
  v59 = a1[25]; /*0x1066ebc9e*/
  v60 = a1[26]; /*0x1066ebca9*/
  v61 = a1[27]; /*0x1066ebcb4*/
  LOBYTE(v62) = 0; /*0x1066ebcba*/
  v65 = 0; /*0x1066ebcbe*/
  LOBYTE(v66) = 0; /*0x1066ebcc2*/
  v67 = 0; /*0x1066ebcc6*/
  v68 = a1 + 28; /*0x1066ebcd1*/
  v42 = v5 ^ 1; /*0x1066ebcd5*/
  v69 = v5 ^ 1; /*0x1066ebcdb*/
  v70 = *((_BYTE *)a1 + 241); /*0x1066ebce6*/
  v71 = *(_DWORD *)(v2 + 4944) == 0; /*0x1066ebcf1*/
  v72 = *((_BYTE *)a1 + 242); /*0x1066ebcfd*/
  memset(v73, 0, 24); /*0x1066ebd04*/
  std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1066ebd1a*/
    a1: v73,
    a2: 0,
    a3: 0,
    a4: 0);
  v73[6] = 0; /*0x1066ebd26*/
  LOBYTE(v73[7]) = 0; /*0x1066ebd32*/
  v74[0] = 0; /*0x1066ebd38*/
  v74[46] = 0; /*0x1066ebd3e*/
  v75[0] = 0; /*0x1066ebd44*/
  v75[24] = 0; /*0x1066ebd4a*/
  v47[0] = 0; /*0x1066ebd50*/
  v49 = 0; /*0x1066ebd56*/
  if ( (unsigned __int8)RBX::Network::ConnectionInfo::empty(this: (RBX::Network::ConnectionInfo *)v50) != 0
    || *((_BYTE *)a1 + 260) != 1 )
  {
    v8 = (int)DFLog::NetworkClient; /*0x1066ebddc*/
    if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 )
    {
      v41 = qword_10D809380; /*0x1066ebe03*/
      v9 = RBX::Network::ConnectionInfo::empty(this: v4); /*0x1066ebe0d*/
      v10 = *((unsigned __int8 *)a1 + 260); /*0x1066ebe14*/
      *(_QWORD *)&v43 = v9 ^ 1u; /*0x1066ebe26*/
      *(_QWORD *)&v44 = v10; /*0x1066ebe29*/
      *(_QWORD *)&v45[16] = 119; /*0x1066ebe2d*/
      *(_QWORD *)&v45[20] = &v43; /*0x1066ebe38*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: v8,
        a2: v41,
        a3: 4,
        a4: (unsigned int)"[DFLog::NetworkClient] RbxTransport Client will connect without RuppConfig. udmuxEndpoint exists: "
                      "{}, rbxTransportToken exists: {}",
        a5: 130,
        a6: 1,
        119,
        &v43);
    }
  }
  else
  {
    memset(&v45[16], 0, 18); /*0x1066ebd79*/
    RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v46); /*0x1066ebd88*/
    LOBYTE(v45[16]) = *((_BYTE *)a1 + 242); /*0x1066ebd94*/
    v38 = 0; /*0x1066ebd9a*/
    v39 = 0; /*0x1066ebda7*/
    v40 = nullptr; /*0x1066ebdae*/
    if ( (v52 & 1) != 0 ) /*0x1066ebdc3*/
    {
      v6 = v55; /*0x1066ebdc9*/
      v7 = v54; /*0x1066ebdd0*/
    }
    else
    {
      v7 = v52 >> 1; /*0x1066ebe76*/
      v6 = &v53; /*0x1066ebe78*/
    }
    RBX::RbxTransport::Io::EndpointAddr::fromIpAddrStr(a1: &v43, a2: v6, a3: v7, a4: LOWORD(v56[0])); /*0x1066ebe8d*/
    v35[0] = &v38; /*0x1066ebea0*/
    v35[1] = v46; /*0x1066ebea3*/
    std::__memberwise_forward_assign[abi:ne200100]<std::tuple<RBX::RbxTransport::Io::Error &,RBX::RbxTransport::Io::EndpointAddr &>,std::tuple<RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr>,RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr,0ul,1ul>( /*0x1066ebeae*/
      a1: v35,
      a2: &v43);
    RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v45); /*0x1066ebebd*/
    if ( (BYTE8(v43) & 1) != 0 ) /*0x1066ebec7*/
      operator delete(a1: *((RBX::Memory **)&v44 + 1), a2: v11); /*0x1066ebed0*/
    if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v38) == 0 )
    {
      RBX::RbxTransport::Io::Error::toString(this: (RBX::RbxTransport::Io::Error *)&v43); /*0x1066ec24f*/
      if ( (v43 & 1) != 0 ) /*0x1066ec25b*/
        v32 = (const char *)v44; /*0x1066ec25d*/
      else
        v32 = (char *)&v43 + 1; /*0x1066ec266*/
      RBX::throw_runtime_error(
        this: (RBX *)"RbxTransport Client rccAddr parse error: %s",
        a2: v32,
        a3: v20,
        a4: v21,
        a5: v22,
        a6: v23,
        a7: v24,
        a8: v25,
        a9: v26,
        a10: v27,
        a11: v28,
        a12: v29,
        a13: v30,
        a14: v31,
        a15: v33);
    }
    HIBYTE(v45[24]) = *((_BYTE *)a1 + 259); /*0x1066ebefa*/
    *(_OWORD *)((char *)&v45[16] + 1) = *(_OWORD *)((char *)a1 + 243); /*0x1066ebf00*/
    std::optional<RBX::Rupp::ClientRuppConfiguration>::operator=[abi:ne200100]<RBX::Rupp::ClientRuppConfiguration&,void>(a1: v47); /*0x1066ebf0b*/
    v13 = (int)DFLog::NetworkClient; /*0x1066ebf10*/
    if ( (unsigned __int8)DFLog::NetworkClient >= 6u && BYTE1(DFLog::NetworkClient) >= 5u ) /*0x1066ebf26*/
    {
      v41 = qword_10D809380; /*0x1066ebf38*/
      RBX::RbxTransport::Io::EndpointAddr::toString(this: (RBX::RbxTransport::Io::EndpointAddr *)&v43); /*0x1066ebf50*/
      Port = RBX::RbxTransport::Io::EndpointAddr::getPort(this: (RBX::RbxTransport::Io::EndpointAddr *)v46); /*0x1066ebf64*/
      v14 = "false"; /*0x1066ebf6d*/
      if ( LOBYTE(v45[16]) != 0 ) /*0x1066ebf7b*/
        v14 = "true"; /*0x1066ebf7b*/
      v35[0] = v14; /*0x1066ebf7f*/
      v37 = HIBYTE(v45[16]); /*0x1066ebf94*/
      FLog::FastLogSafeFormatted<std::string,int,char const*,int>( /*0x1066ebfce*/
        a1: v13,
        a2: v41,
        a3: 5,
        a4: (int)"[DFLog::NetworkClient] RbxTransport Client RuppConfig = RCC {}:{}, DSR {}, Token type {}",
        a5: 88,
        a6: (unsigned __int8 *)&v43,
        a7: &Port,
        a8: v35,
        a9: &v37);
      if ( (v43 & 1) != 0 ) /*0x1066ebfda*/
        operator delete(a1: (RBX::Memory *)v44, a2: v12); /*0x1066ebfe3*/
    }
    if ( (v39 & 1) != 0 ) /*0x1066ebfef*/
      operator delete(a1: (RBX::Memory *)v40, a2: v12); /*0x1066ebff8*/
    RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v46); /*0x1066ec004*/
  }
  if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 ) /*0x1066ec01d*/
    FLog::FastLogSafeFormatted<std::string &,int &,std::string &,int &>( /*0x1066ec067*/
      a1: (int)DFLog::NetworkClient,
      a2: qword_10D809380,
      a3: 4,
      a4: (int)"[DFLog::NetworkClient] RbxTransport Client will connect to server {}|{}, udmux {}|{}",
      a5: 84,
      a6: &v52,
      a7: v56,
      a8: v50,
      a9: v51);
  if ( v73 != (_DWORD *)(a1 + 39) ) /*0x1066ec076*/
    std::vector<unsigned char>::__assign_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1066ec08f*/
      a1: v73,
      a2: a1[39],
      a3: a1[40],
      a4: a1[40] - a1[39]);
  LOBYTE(v73[7]) = *((_BYTE *)a1 + 340); /*0x1066ec0a6*/
  v73[6] = *((_DWORD *)a1 + 84); /*0x1066ec0b0*/
  std::__optional_storage_base<RBX::Rupp::ClientRuppConfiguration,false>::__assign_from[abi:ne200100]<std::__optional_copy_assign_base<RBX::Rupp::ClientRuppConfiguration,false> const&>(a1: v74); /*0x1066ec0b9*/
  std::__optional_storage_base<std::string,false>::__assign_from[abi:ne200100]<std::__optional_copy_assign_base<std::string,false> const&>( /*0x1066ec0c9*/
    a1: v75,
    a2: a1 + 33);
  if ( v67 == *((_BYTE *)a1 + 304) ) /*0x1066ec0db*/
  {
    if ( v67 != 0 ) /*0x1066ec0df*/
      _InterlockedExchange64(&v66, a1[37]); /*0x1066ec0e8*/
  }
  else if ( v67 != 0 ) /*0x1066ec0f3*/
  {
    v67 = 0; /*0x1066ec0f5*/
  }
  else
  {
    v66 = 0; /*0x1066ec0fe*/
    _InterlockedExchange64(&v66, a1[37]); /*0x1066ec110*/
    v67 = 1; /*0x1066ec117*/
  }
  RBX::Network::Peer::isLocalTest(this: (RBX::Network::Peer *)v2); /*0x1066ec121*/
  v34[0] = v2; /*0x1066ec144*/
  v34[3] = (char *)&RBX::unique_function<void ()(RBX::RbxTransport::Io::NetworkEmulationConfiguration),24ul,8ul,true>::unique_function<RBX::Network::Client::playerConnectWithConnectionInternal(long long,RBX::Network::FinalConnectionArgs const&,RBX::Network::FinalConnectionArgs const&,int,int,int,std::shared_ptr<RBX::Reflection::ValueTable const>,RBX::Rupp::TokenTlv::Token &,bool,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_1::operator()(void)::{lambda(RBX::RbxTransport::Io::NetworkEmulationConfiguration)#1}>(RBX::Network::Client::playerConnectWithConnectionInternal(long long,RBX::Network::FinalConnectionArgs const&,RBX::Network::FinalConnectionArgs const&,int,int,int,std::shared_ptr<RBX::Reflection::ValueTable const>,RBX::Rupp::TokenTlv::Token &,bool,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_1::operator()(void)::{lambda(RBX::RbxTransport::Io::NetworkEmulationConfiguration)#1})::Callback /*0x1066ec14e*/
         + 2;
  RBX::Network::NetworkEmulationUpdater::createNetworkEmulationConfigWithUpdateCb(this: (RBX::Network::NetworkEmulationUpdater *)&v43); /*0x1066ec15c*/
  v65 = v45[8]; /*0x1066ec173*/
  v64 = *(_OWORD *)v45; /*0x1066ec184*/
  v63 = v44; /*0x1066ec188*/
  v62 = v43; /*0x1066ec18c*/
  RBX::unique_function<void ()(RBX::RbxTransport::Io::NetworkEmulationConfiguration),24ul,8ul,true>::~unique_function( /*0x1066ec196*/
    a1: (__int64)v34,
    a2: v15);
  *(_BYTE *)(v2 + 4720) = 1; /*0x1066ec19b*/
  RBX::NetworkBase::ConnectionInternal::createAndStartRbxTransportConnectionClient( /*0x1066ec1ac*/
    this: (RBX::NetworkBase::ConnectionInternal *)&v43,
    a2: (const RBX::NetworkBase::ConnectionStartArgs *)v50);
  v16 = v43; /*0x1066ec1b1*/
  *(_QWORD *)&v43 = 0; /*0x1066ec1b8*/
  v17 = *(_QWORD *)(v2 + 4600); /*0x1066ec1c3*/
  *(_QWORD *)(v2 + 4600) = v16; /*0x1066ec1ca*/
  if ( v17 != 0 ) /*0x1066ec1d4*/
  {
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v17 + 8LL))(a1: v17); /*0x1066ec1d9*/
    v18 = v43; /*0x1066ec1dc*/
    *(_QWORD *)&v43 = 0; /*0x1066ec1e3*/
    if ( v18 != 0 ) /*0x1066ec1f1*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v18 + 8LL))(a1: v18); /*0x1066ec1f6*/
  }
  if ( v49 == 1 ) /*0x1066ec200*/
    RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v48); /*0x1066ec209*/
  RBX::NetworkBase::ConnectionStartArgs::~ConnectionStartArgs(this: (RBX::NetworkBase::ConnectionStartArgs *)v50); /*0x1066ec215*/
  return __stack_chk_guard; /*0x1066ec22a*/
}

// Address: 0x1066ec384 | Name: __ZZN3RBX7Network6Client35playerConnectWithConnectionInternalExRKNS0_19FinalConnectionArgsES4_iiiNSt3__110shared_ptrIKNS_10Reflection10ValueTableEEERNS_4Rupp8TokenTlv5TokenEbNS5_8optionalISD_EENSF_INS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEEENSF_INS_12RbxTransport12CapabilitiesEEEEN3$_0clEv
__int64 __fastcall RBX::Network::Client::playerConnectWithConnectionInternal(long long,RBX::Network::FinalConnectionArgs const&,RBX::Network::FinalConnectionArgs const&,int,int,int,std::shared_ptr<RBX::Reflection::ValueTable const>,RBX::Rupp::TokenTlv::Token &,bool,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_0::operator()(
        __int64 *a1)
{
  __int64 v2; // rbx
  const RBX::Network::FinalConnectionArgs *v3; // r13
  const RBX::Network::ConnectionInfo *v4; // r12
  char v5; // r14
  __int64 v6; // rax
  __int64 v7; // rdi
  __int64 v8; // rdi
  __int64 v10; // [rsp+8h] [rbp-1D8h] BYREF
  _BYTE v11[88]; // [rsp+10h] [rbp-1D0h] BYREF
  _QWORD v12[27]; // [rsp+68h] [rbp-178h] BYREF
  _DWORD v13[28]; // [rsp+140h] [rbp-A0h] BYREF

  v2 = *a1; /*0x1066ec3a9*/
  v3 = (const RBX::Network::FinalConnectionArgs *)(a1 + 1); /*0x1066ec3ac*/
  v4 = (const RBX::Network::ConnectionInfo *)(a1 + 12); /*0x1066ec3b0*/
  v5 = RBX::Network::ConnectionInfo::empty(this: (RBX::Network::ConnectionInfo *)(a1 + 12)); /*0x1066ec3bc*/
  RBX::Network::Client::setupServerConnectionAndLogging(this: (RBX::Network::Client *)v2, a2: v3); /*0x1066ec3c5*/
  RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066ec3e6*/
    this: (RBX::Network::ConcurrentRakPeer **)v2,
    a2: "JoinStart",
    a3: 0,
    a4: "",
    a5: 0,
    a6: 1);
  *(_DWORD *)(v2 + 632) = 1; /*0x1066ec3eb*/
  RBX::Network::ConnectionInfo::ConnectionInfo(this: (RBX::Network::ConnectionInfo *)v11, a2: v4); /*0x1066ec3ff*/
  RBX::Network::ConnectionInfo::ConnectionInfo(this: (RBX::Network::ConnectionInfo *)v12, a2: v3); /*0x1066ec411*/
  LOBYTE(v12[12]) = *((_BYTE *)a1 + 192); /*0x1066ec428*/
  v12[11] = a1[23]; /*0x1066ec432*/
  v12[13] = a1[25]; /*0x1066ec43d*/
  v12[14] = a1[26]; /*0x1066ec448*/
  v12[15] = a1[27]; /*0x1066ec453*/
  LOBYTE(v12[16]) = 0; /*0x1066ec459*/
  LOBYTE(v12[22]) = 0; /*0x1066ec45c*/
  LOBYTE(v12[23]) = 0; /*0x1066ec45f*/
  LOBYTE(v12[24]) = 0; /*0x1066ec462*/
  v12[25] = a1 + 28; /*0x1066ec46c*/
  LOBYTE(v12[26]) = v5 ^ 1; /*0x1066ec470*/
  BYTE1(v12[26]) = *((_BYTE *)a1 + 241); /*0x1066ec47b*/
  BYTE2(v12[26]) = *(_DWORD *)(v2 + 4944) == 0; /*0x1066ec485*/
  BYTE3(v12[26]) = *((_BYTE *)a1 + 242); /*0x1066ec490*/
  memset(v13, 0, 24); /*0x1066ec496*/
  std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1066ec4a7*/
    a1: v13,
    a2: 0,
    a3: 0,
    a4: 0);
  v13[6] = 0; /*0x1066ec4b3*/
  LOBYTE(v13[7]) = 0; /*0x1066ec4bf*/
  LOBYTE(v13[8]) = 0; /*0x1066ec4c5*/
  BYTE2(v13[19]) = 0; /*0x1066ec4cb*/
  LOBYTE(v13[20]) = 0; /*0x1066ec4d1*/
  LOBYTE(v13[26]) = 0; /*0x1066ec4d7*/
  (*(void (__fastcall **)(__int64 *, _QWORD, _BYTE *, __int64, _QWORD))(**(_QWORD **)(v2 + 344) + 16LL))( /*0x1066ec4fa*/
    a1: &v10,
    a2: *(_QWORD *)(v2 + 344),
    a3: v11,
    a4: 1,
    a5: *(_QWORD *)(v2 + 288));
  v6 = v10; /*0x1066ec4fd*/
  v10 = 0; /*0x1066ec504*/
  v7 = *(_QWORD *)(v2 + 4600); /*0x1066ec50f*/
  *(_QWORD *)(v2 + 4600) = v6; /*0x1066ec516*/
  if ( v7 != 0 ) /*0x1066ec520*/
  {
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v7 + 8LL))(a1: v7); /*0x1066ec525*/
    v8 = v10; /*0x1066ec528*/
    v10 = 0; /*0x1066ec52f*/
    if ( v8 != 0 ) /*0x1066ec53d*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 8LL))(a1: v8); /*0x1066ec542*/
  }
  RBX::NetworkBase::ConnectionStartArgs::~ConnectionStartArgs(this: (RBX::NetworkBase::ConnectionStartArgs *)v11); /*0x1066ec54c*/
  return __stack_chk_guard; /*0x1066ec561*/
}

// Address: 0x1066ec5f0 | Name: __ZZN3RBX7Network6Client35playerConnectWithConnectionInternalExRKNS0_19FinalConnectionArgsES4_iiiNSt3__110shared_ptrIKNS_10Reflection10ValueTableEEERNS_4Rupp8TokenTlv5TokenEbNS5_8optionalISD_EENSF_INS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEEENSF_INS_12RbxTransport12CapabilitiesEEEEN3$_1D1Ev
void __fastcall RBX::Network::Client::playerConnectWithConnectionInternal(long long,RBX::Network::FinalConnectionArgs const&,RBX::Network::FinalConnectionArgs const&,int,int,int,std::shared_ptr<RBX::Reflection::ValueTable const>,RBX::Rupp::TokenTlv::Token &,bool,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_1::~$_1(
        __int64 a1,
        void *a2)
{
  RBX::Memory *v3; // rdi

  v3 = *(RBX::Memory **)(a1 + 312); /*0x1066ec5f9*/
  if ( v3 != nullptr ) /*0x1066ec603*/
  {
    *(_QWORD *)(a1 + 320) = v3; /*0x1066ec605*/
    operator delete(a1: v3, a2); /*0x1066ec60c*/
  }
  if ( *(_BYTE *)(a1 + 288) == 1 && (*(_BYTE *)(a1 + 264) & 1) != 0 ) /*0x1066ec621*/
    operator delete(a1: *(RBX::Memory **)(a1 + 280), a2); /*0x1066ec62a*/
  RBX::Network::FinalConnectionArgs::~FinalConnectionArgs(this: (RBX::Network::FinalConnectionArgs *)(a1 + 8)); /*0x1066ec63c*/
}

// Address: 0x1066ec642 | Name: __ZN3RBX7Network6Client31getRbxTransportConnectionConfigEv
RBX::Network::Client *__fastcall RBX::Network::Client::getRbxTransportConnectionConfig(
        RBX::Network::Client *this,
        __int64 a2)
{
  RSL::Mutex *v4; // r14
  __int64 v5; // rax

  v4 = (RSL::Mutex *)(a2 + 5000); /*0x1066ec652*/
  RSL::Mutex::lock(this: (RSL::Mutex *)(a2 + 5000)); /*0x1066ec65c*/
  v5 = *(_QWORD *)(a2 + 5016); /*0x1066ec661*/
  *(_OWORD *)this = *(_OWORD *)(a2 + 5008); /*0x1066ec670*/
  if ( v5 != 0 ) /*0x1066ec676*/
    _InterlockedIncrement64((volatile signed __int64 *)(v5 + 8)); /*0x1066ec678*/
  RSL::Mutex::unlock(this: v4); /*0x1066ec680*/
  return this; /*0x1066ec68c*/
}

// Address: 0x1066ec69c | Name: __ZN3RBX7Network6Client13playerConnectExNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEiiiiS8_bNS2_10shared_ptrIKNS_10Reflection10ValueTableEEERKNS2_6vectorINS0_14ConnectionInfoENS6_ISF_EEEESJ_RNS_4Rupp8TokenTlv5TokenEbNS2_8optionalIiEENSO_ISM_EENSO_IS8_EENSO_INS_12RbxTransport12CapabilitiesEEE
__int64 __fastcall RBX::Network::Client::playerConnect(
        RBX::Network::Peer *a1,
        unsigned __int8 *a2,
        _QWORD *a3,
        unsigned int a4,
        int a5,
        int a6,
        unsigned int a7,
        int a8,
        int a9,
        RBX::Reflection::ValueTable **a10,
        __int64 *a11,
        unsigned __int8 **a12,
        __int128 *a13,
        unsigned __int8 a14,
        unsigned __int64 a15,
        __int128 a16,
        __int16 a17,
        __int64 a18,
        __int64 a19)
{
  RBX::TraceRouteService *v22; // rdi
  __int64 v23; // rax
  RBX::Instance *v24; // rsi
  unsigned __int8 *v25; // rbx
  __int64 v26; // rax
  RBX::TraceRouteService *v27; // r12
  unsigned int v28; // edx
  unsigned __int8 *v29; // rsi
  __int64 v30; // rdx
  RBX::SimpleTimer *v31; // r13
  __int64 v32; // rax
  void *v33; // rsi
  void *v34; // rsi
  __int64 v35; // r9
  void *v36; // rsi
  std::__shared_weak_count *v37; // r14
  RBX::Memory *v38; // rdi
  _QWORD *v39; // r13
  char *v40; // rax
  unsigned __int8 *v41; // rax
  unsigned int v42; // r15d
  __int64 v43; // rbx
  __int64 v44; // r14
  __int64 v45; // rax
  __int64 v46; // rcx
  unsigned int v47; // eax
  FLog *v48; // r14
  __int64 v49; // r15
  const char *v50; // rax
  unsigned __int8 *v51; // rcx
  char *v52; // rcx
  __int64 v53; // rsi
  __int64 *v54; // rcx
  __int64 v55; // rax
  char *v56; // rcx
  __int64 v57; // r8
  __int64 v58; // rcx
  _QWORD *v59; // rbx
  int v60; // r8d
  int v61; // r9d
  void *v62; // rsi
  bool v63; // al
  __int64 v64; // r14
  __int64 v65; // r12
  __int64 v66; // rcx
  char *v67; // r9
  __int64 v68; // rcx
  __int64 v69; // rax
  unsigned __int64 v70; // rbx
  __int64 v71; // rax
  RBX::Network::ConcurrentRakPeer **v72; // rdi
  void *v73; // rsi
  __int64 v74; // rdx
  __int64 v75; // rcx
  __int64 v76; // rdx
  __int64 v77; // rcx
  RBX::Time *v78; // rdi
  const RBX::Instance *v79; // rsi
  __int64 v80; // r14
  double v81; // xmm0_8
  RBX::Instance *v82; // rsi
  __int64 v83; // rax
  float v84; // xmm0_4
  RBX::ServiceProvider *ServiceProvider; // rax
  __int64 v86; // rax
  __int64 v87; // rdi
  __int64 v88; // rbx
  const char *v89; // rdx
  char *v90; // rdi
  __int64 v91; // rsi
  __int64 v92; // rbx
  __int64 v93; // r12
  __int64 v94; // r14
  __int64 v95; // r13
  RakNet::SocketDescriptor *v96; // rsi
  int v97; // eax
  RBX::Instance *v98; // rsi
  __int64 v99; // rdx
  __int64 v100; // rcx
  __int64 v101; // rax
  __int16 v102; // cx
  __int64 v103; // rax
  int v104; // ebx
  __int64 v105; // rax
  RBX::DataModel *v106; // r12
  int v107; // r15d
  int *v108; // rdx
  const RBX::Instance *v109; // rsi
  RBX::ServiceProvider *v110; // rax
  RBX::RunService *v111; // rdi
  bool v112; // bl
  _BYTE *EngineNetConfiguration; // rax
  __int64 v114; // r13
  unsigned int v115; // r12d
  rbx::signals::slots_holder **v116; // r13
  unsigned __int64 v117; // rsi
  unsigned __int64 v118; // r15
  rbx::signals::slots_holder *v119; // rax
  unsigned __int64 v120; // rax
  __int64 v121; // rax
  __int64 v122; // rax
  RSL::Mutex *v123; // r14
  unsigned __int8 **v124; // rbx
  __int64 v125; // rbx
  char v126; // r12
  __int64 v127; // rax
  __int64 v128; // rdx
  __int64 v129; // rsi
  unsigned __int8 *v130; // rcx
  __int64 v131; // r8
  RBX::Time *v132; // rdi
  int v133; // r9d
  __int64 v134; // r13
  __int64 v135; // r15
  double v136; // xmm0_8
  bool v137; // al
  __int64 v138; // rax
  __int64 v139; // rcx
  __int64 v140; // rax
  __int64 v141; // rcx
  char *v142; // r9
  __int64 v143; // rax
  __int64 v144; // rdx
  __int64 v145; // rcx
  __int64 v146; // r13
  __int64 v147; // r8
  __int64 v148; // r9
  __m128 v149; // xmm0
  __m128 v150; // xmm1
  __m128 v151; // xmm2
  __m128 v152; // xmm3
  __m128 v153; // xmm4
  __m128 v154; // xmm5
  __m128 v155; // xmm6
  __m128 v156; // xmm7
  __int64 v157; // rax
  __int64 v158; // rdx
  __int64 v159; // rdx
  __int64 v160; // rcx
  void *v161; // rsi
  RBX::Network::Client *v162; // rdi
  __int64 v163; // rax
  __int64 v164; // rdx
  __int64 v165; // r8
  __int64 v166; // r9
  __int64 v167; // rax
  __int64 v168; // rdx
  __int64 v169; // r8
  __int64 v170; // r9
  unsigned __int8 v171; // al
  __int64 v172; // rcx
  char v173; // al
  __int64 v174; // rdx
  char *v175; // rsi
  __int64 v176; // rdx
  unsigned int v177; // esi
  RBX::RbxTransport::DummyService::DummyClient *v178; // rdi
  int v179; // r12d
  int v180; // r13d
  void *v181; // rsi
  int v182; // r12d
  int v183; // r13d
  const char *v184; // rdx
  void *v185; // rsi
  void *v186; // rsi
  int v187; // r14d
  int v188; // r15d
  void *v189; // rsi
  char isLocalTest; // al
  __int64 *v191; // r14
  RBX::RbxTransport::DummyService::DummyClient *v192; // rsi
  RBX::RbxTransport::DummyService::DummyClient *v193; // r15
  void *v194; // rsi
  __int64 v195; // r14
  void *v196; // rsi
  __int64 v197; // rax
  RSL::Mutex *v198; // r14
  __int128 v199; // xmm0
  unsigned __int16 v200; // bx
  void *v201; // rsi
  std::__shared_weak_count *v202; // rbx
  RBX *exception; // r14
  __int64 v205; // rdx
  __int64 v206; // rcx
  __int64 v207; // r8
  __int64 v208; // r9
  __m128 v209; // xmm0
  __m128 v210; // xmm1
  __m128 v211; // xmm2
  __m128 v212; // xmm3
  __m128 v213; // xmm4
  __m128 v214; // xmm5
  __m128 v215; // xmm6
  __m128 v216; // xmm7
  RBX *v217; // r14
  __int64 v218; // rdx
  __int64 v219; // rcx
  __int64 v220; // r8
  __int64 v221; // r9
  __m128 v222; // xmm0
  __m128 v223; // xmm1
  __m128 v224; // xmm2
  __m128 v225; // xmm3
  __m128 v226; // xmm4
  __m128 v227; // xmm5
  __m128 v228; // xmm6
  __m128 v229; // xmm7
  std::runtime_error *v230; // r14
  _QWORD *v231; // r12
  __int64 v232; // rbx
  __int64 v233; // r14
  RBX *v234; // rax
  __int64 v235; // rdx
  __int64 v236; // rcx
  __int64 v237; // r8
  __int64 v238; // r9
  __m128 v239; // xmm0
  __m128 v240; // xmm1
  __m128 v241; // xmm2
  __m128 v242; // xmm3
  __m128 v243; // xmm4
  __m128 v244; // xmm5
  __m128 v245; // xmm6
  __m128 v246; // xmm7
  RBX *v247; // r15
  RBX *v248; // r15
  __int64 v249; // rcx
  __int64 v250; // r8
  __int64 v251; // r9
  __m128 v252; // xmm0
  __m128 v253; // xmm1
  __m128 v254; // xmm2
  __m128 v255; // xmm3
  __m128 v256; // xmm4
  __m128 v257; // xmm5
  __m128 v258; // xmm6
  __m128 v259; // xmm7
  char v260; // [rsp+0h] [rbp-8F0h]
  char v261; // [rsp+0h] [rbp-8F0h]
  _DWORD v262[10]; // [rsp+50h] [rbp-8A0h] BYREF
  _QWORD v263[2]; // [rsp+78h] [rbp-878h] BYREF
  _BYTE v264[16]; // [rsp+88h] [rbp-868h] BYREF
  void *v265; // [rsp+98h] [rbp-858h]
  _BYTE v266[16]; // [rsp+A0h] [rbp-850h] BYREF
  void *v267; // [rsp+B0h] [rbp-840h]
  char v268; // [rsp+B8h] [rbp-838h]
  _BYTE v269[16]; // [rsp+C0h] [rbp-830h] BYREF
  void *v270; // [rsp+D0h] [rbp-820h]
  char v271; // [rsp+D8h] [rbp-818h]
  unsigned int Port; // [rsp+E0h] [rbp-810h] BYREF
  unsigned int v273; // [rsp+E4h] [rbp-80Ch] BYREF
  char v274[16]; // [rsp+E8h] [rbp-808h] BYREF
  void *v275; // [rsp+F8h] [rbp-7F8h]
  char v276; // [rsp+100h] [rbp-7F0h]
  char v277[16]; // [rsp+108h] [rbp-7E8h] BYREF
  void *v278; // [rsp+118h] [rbp-7D8h]
  char v279; // [rsp+120h] [rbp-7D0h]
  _BYTE v280[16]; // [rsp+128h] [rbp-7C8h] BYREF
  void *v281; // [rsp+138h] [rbp-7B8h]
  _BYTE v282[16]; // [rsp+140h] [rbp-7B0h] BYREF
  void *v283; // [rsp+150h] [rbp-7A0h]
  _BYTE v284[16]; // [rsp+158h] [rbp-798h] BYREF
  void *v285; // [rsp+168h] [rbp-788h]
  _BYTE v286[16]; // [rsp+170h] [rbp-780h] BYREF
  void *v287; // [rsp+180h] [rbp-770h]
  _BYTE v288[16]; // [rsp+188h] [rbp-768h] BYREF
  void *v289; // [rsp+198h] [rbp-758h]
  __int64 v290; // [rsp+1A0h] [rbp-750h]
  RSL::Mutex *v291; // [rsp+1A8h] [rbp-748h]
  std::__shared_weak_count *v292[2]; // [rsp+1B0h] [rbp-740h] BYREF
  void *v293[4]; // [rsp+1C0h] [rbp-730h] BYREF
  __int128 v294; // [rsp+1E0h] [rbp-710h] BYREF
  void *v295; // [rsp+1F0h] [rbp-700h]
  __int128 v296; // [rsp+200h] [rbp-6F0h] BYREF
  void *v297; // [rsp+210h] [rbp-6E0h]
  void *v298[3]; // [rsp+218h] [rbp-6D8h] BYREF
  __int128 v299; // [rsp+230h] [rbp-6C0h] BYREF
  void *v300; // [rsp+240h] [rbp-6B0h]
  __int128 v301; // [rsp+250h] [rbp-6A0h] BYREF
  void *v302; // [rsp+260h] [rbp-690h]
  __int64 v303; // [rsp+270h] [rbp-680h] BYREF
  __int128 v304; // [rsp+278h] [rbp-678h]
  void *v305; // [rsp+288h] [rbp-668h]
  RBX::DataModel *v306; // [rsp+298h] [rbp-658h]
  __int128 v307; // [rsp+2A0h] [rbp-650h] BYREF
  void *v308; // [rsp+2B0h] [rbp-640h]
  unsigned __int8 *v309; // [rsp+2B8h] [rbp-638h]
  int v310; // [rsp+2C4h] [rbp-62Ch]
  __int64 v311; // [rsp+2C8h] [rbp-628h]
  __int128 v312; // [rsp+2D0h] [rbp-620h] BYREF
  void *v313; // [rsp+2E0h] [rbp-610h]
  unsigned int v314; // [rsp+2F4h] [rbp-5FCh] BYREF
  double v315; // [rsp+2F8h] [rbp-5F8h]
  _QWORD *v316; // [rsp+300h] [rbp-5F0h]
  RBX::Network::Peer *v317; // [rsp+308h] [rbp-5E8h]
  __int128 v318; // [rsp+310h] [rbp-5E0h] BYREF
  __int16 v319; // [rsp+320h] [rbp-5D0h]
  _BYTE v320[28]; // [rsp+322h] [rbp-5CEh] BYREF
  char v321; // [rsp+33Eh] [rbp-5B2h]
  _QWORD v322[4]; // [rsp+340h] [rbp-5B0h] BYREF
  _QWORD *v323; // [rsp+360h] [rbp-590h]
  _BYTE v324[18]; // [rsp+370h] [rbp-580h] BYREF
  _BYTE v325[30]; // [rsp+382h] [rbp-56Eh] BYREF
  __int128 v326; // [rsp+3A0h] [rbp-550h] BYREF
  __int16 v327; // [rsp+3B0h] [rbp-540h]
  _BYTE v328[28]; // [rsp+3B2h] [rbp-53Eh] BYREF
  char v329; // [rsp+3CEh] [rbp-522h]
  RBX::RbxTransport::DummyService::DummyClient *v330[2]; // [rsp+3D0h] [rbp-520h] BYREF
  void *v331[2]; // [rsp+3E0h] [rbp-510h]
  char v332[8]; // [rsp+3F0h] [rbp-500h] BYREF
  char v333; // [rsp+3F8h] [rbp-4F8h]
  void *v334; // [rsp+408h] [rbp-4E8h]
  void *v335; // [rsp+410h] [rbp-4E0h]
  void *v336; // [rsp+418h] [rbp-4D8h]
  void *v337; // [rsp+420h] [rbp-4D0h]
  char v338; // [rsp+428h] [rbp-4C8h]
  void *v339; // [rsp+438h] [rbp-4B8h]
  _BYTE v340[26]; // [rsp+446h] [rbp-4AAh] BYREF
  void *v341; // [rsp+460h] [rbp-490h]
  char v342; // [rsp+468h] [rbp-488h]
  void *v343; // [rsp+478h] [rbp-478h]
  char v344; // [rsp+480h] [rbp-470h]
  __int64 v345; // [rsp+7E0h] [rbp-110h] BYREF
  __int64 v346; // [rsp+7E8h] [rbp-108h] BYREF
  void *v347; // [rsp+7F0h] [rbp-100h] BYREF
  __int64 *v348; // [rsp+800h] [rbp-F0h]
  char v349; // [rsp+808h] [rbp-E8h]
  void *v350; // [rsp+818h] [rbp-D8h]
  char v351; // [rsp+820h] [rbp-D0h]
  void *v352; // [rsp+830h] [rbp-C0h]
  char v353; // [rsp+838h] [rbp-B8h]
  void *v354; // [rsp+848h] [rbp-A8h]
  char v355; // [rsp+860h] [rbp-90h]
  void *v356; // [rsp+870h] [rbp-80h]
  char v357; // [rsp+878h] [rbp-78h]
  void *v358; // [rsp+888h] [rbp-68h]
  _QWORD v359[2]; // [rsp+890h] [rbp-60h] BYREF
  char v360[32]; // [rsp+8A0h] [rbp-50h] BYREF

  LODWORD(v311) = a5; /*0x1066ec6b3*/
  v317 = a1; /*0x1066ec6c0*/
  v309 = (unsigned __int8 *)a2; /*0x1066ec6dc*/
  if ( DFInt::DebugCLI52064TransmitUS > 0 || DFInt::DebugCLI52064ReceiveUS > 0 ) /*0x1066ec6ec*/
  {
    v23 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v317 + 36)); /*0x1066ec70a*/
    (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v23 + 896LL))( /*0x1066ec723*/
      a1: v23,
      a2: DFInt::DebugCLI52064TransmitUS,
      a3: DFInt::DebugCLI52064ReceiveUS);
  }
  else
  {
    RBX::Network::Client::checkArtificialLatency(this: v317, (__int64)a2); /*0x1066ec6f5*/
  }
  v316 = a3; /*0x1066ec729*/
  if ( DFFlag::EnableTraceRouteService != 1 ) /*0x1066ec73a*/
    goto LABEL_24; /*0x1066ec73a*/
  if ( (unsigned __int8)RBX::TraceRouteService::shouldRunTelemetry(this: v22) == 0 ) /*0x1066ec747*/
    goto LABEL_24; /*0x1066ec747*/
  v25 = *a12; /*0x1066ec751*/
  if ( *a12 == a12[1] ) /*0x1066ec758*/
    goto LABEL_24; /*0x1066ec758*/
  v26 = RBX::DataModel::get(this: v317, a2: v24); /*0x1066ec765*/
  if ( v26 == 0 ) /*0x1066ec76d*/
    goto LABEL_24; /*0x1066ec76d*/
  v27 = (RBX::TraceRouteService *)RBX::ServiceProvider::create<RBX::TraceRouteService>(this: (RBX::ServiceProvider *)(v26 + 464)); /*0x1066ec783*/
  v28 = *v25; /*0x1066ec786*/
  if ( (v28 & 1) != 0 ) /*0x1066ec78c*/
  {
    v29 = *((unsigned __int8 **)v25 + 2); /*0x1066ec78e*/
    v30 = *((_QWORD *)v25 + 1); /*0x1066ec792*/
  }
  else
  {
    v29 = v25 + 1; /*0x1066ec798*/
    v30 = v28 >> 1; /*0x1066ec79c*/
  }
  RBX::RbxTransport::Io::EndpointAddr::fromIpAddrStr(a1: v330, a2: v29, a3: v30, a4: *((unsigned __int16 *)v25 + 12)); /*0x1066ec7a9*/
  if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)v330) != 0 ) /*0x1066ec7c3*/
  {
    if ( DFFlag::EnableTraceRouteSessionSummaryStats == 1 ) /*0x1066ec7d3*/
    {
      RBX::TraceRouteService::setEndpoint(this: v27, a2: (const RBX::RbxTransport::Io::EndpointAddr *)v332); /*0x1066ec7db*/
      goto LABEL_22; /*0x1066ec7e0*/
    }
    v31 = (RBX::Network::Peer *)((char *)v317 + 4984); /*0x1066ec7ec*/
    if ( (unsigned __int8)RBX::SimpleTimer::isValid(this: (RBX::Network::Peer *)((char *)v317 + 4984)) != 0 ) /*0x1066ec7fd*/
      RBX::SimpleTimer::stop(this: v31); /*0x1066ec802*/
    RBX::weak_from<RBX::TraceRouteService>(a1: v359, a2: (__int64)v27); /*0x1066ec80e*/
    RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(a1: v360, a2: v332); /*0x1066ec81a*/
    std::function<void ()(RBX::SimpleTimer &)>::function<RBX::Network::Client::playerConnect(long long,std::string,int,int,int,int,std::string,bool,std::shared_ptr<RBX::Reflection::ValueTable const>,std::vector<RBX::Network::ConnectionInfo> const&,std::vector<RBX::Network::ConnectionInfo> const&,RBX::Rupp::TokenTlv::Token &,bool,std::optional<int>,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_0,void>( /*0x1066ec82a*/
      a1: &v345,
      a2: v359);
    RBX::Network::Client::playerConnect(long long,std::string,int,int,int,int,std::string,bool,std::shared_ptr<RBX::Reflection::ValueTable const>,std::vector<RBX::Network::ConnectionInfo> const&,std::vector<RBX::Network::ConnectionInfo> const&,RBX::Rupp::TokenTlv::Token &,bool,std::optional<int>,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_0::~$_0(a1: v359); /*0x1066ec836*/
    RBX::SimpleTimer::callEvery(a1: &v326, a2: &v345, a3: 1, a4: (double)DFInt::TraceRouteIntervalSeconds); /*0x1066ec856*/
    std::shared_ptr<RBX::TimerData>::operator=[abi:ne200100](a1: v31, a2: &v326); /*0x1066ec868*/
    std::shared_ptr<RBX::TimerData>::~shared_ptr[abi:ne200100](a1: &v326); /*0x1066ec870*/
    if ( v348 == &v345 ) /*0x1066ec886*/
    {
      v32 = 32; /*0x1066ec894*/
    }
    else
    {
      v32 = 40; /*0x1066ec888*/
      if ( v348 == nullptr ) /*0x1066ec890*/
        goto LABEL_22; /*0x1066ec890*/
    }
    (*(void (**)(void))(*v348 + v32))(); /*0x1066ec89c*/
  }
LABEL_22:
  RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v332); /*0x1066ec89f*/
  if ( ((__int64)v330[1] & 1) != 0 ) /*0x1066ec8ae*/
    operator delete(a1: (RBX::Memory *)v331[1], a2: v33); /*0x1066ec8b7*/
LABEL_24:
  if ( FFlag::ConnectViaConnectionInternal == 1 ) /*0x1066ec8d2*/
  {
    RBX::Network::Client::parseEndpointArgs( /*0x1066ec8fd*/
      this: (RBX::Network::ConnectionInfo *)v330,
      a2: a4,
      a3: a11,
      a4: a12,
      a5: 0,
      a6: 0,
      a7: 0);
    RBX::Network::Client::parseEndpointArgs( /*0x1066ec923*/
      this: (RBX::Network::ConnectionInfo *)&v345,
      a2: a4,
      a3: a11,
      a4: a12,
      a5: 0,
      a6: 1,
      a7: a15);
    if ( DFFlag::ConnectDummyServiceClientEarly == 1 ) /*0x1066ec92f*/
    {
      std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: v274, a2: a18); /*0x1066ec93b*/
      RBX::Network::Client::connectDummyServiceClient(this: v317, a2: a16); /*0x1066ec96f*/
      if ( v276 == 1 && (v274[0] & 1) != 0 ) /*0x1066ec984*/
        operator delete(a1: (RBX::Memory *)v275, a2: v34); /*0x1066ec98d*/
    }
    *(_OWORD *)v292 = *(_OWORD *)a10; /*0x1066ec999*/
    *(_OWORD *)a10 = 0; /*0x1066ec9a3*/
    v327 = a17; /*0x1066ec9ae*/
    v326 = a16; /*0x1066ec9b9*/
    std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: v266, a2: a18); /*0x1066ec9ce*/
    v324[0] = 0; /*0x1066ec9d9*/
    v324[8] = 0; /*0x1066ec9df*/
    if ( *(_BYTE *)(a19 + 8) == 1 ) /*0x1066ec9e9*/
    {
      *(_QWORD *)v324 = 0; /*0x1066ec9eb*/
      _InterlockedExchange64((volatile __int64 *)v324, *(_QWORD *)a19); /*0x1066ec9f9*/
      v324[8] = 1; /*0x1066eca00*/
    }
    RBX::Network::Client::playerConnectWithConnectionInternal( /*0x1066eca76*/
      a1: (__int64)v317,
      a2: (__int64)v309,
      a3: (RBX::Network::ConnectionInfo *)&v345,
      a4: (RBX::Network::ConnectionInfo *)v330,
      a5: v311,
      a6: v35,
      a7,
      a8: v292,
      a9: a13,
      a10: a14,
      a11: v326,
      a12: v327,
      a13: (__int64)v266,
      a14: (__int64)v324);
    if ( v268 == 1 && (v266[0] & 1) != 0 ) /*0x1066eca8b*/
      operator delete(a1: (RBX::Memory *)v267, a2: v36); /*0x1066eca94*/
    v37 = v292[1]; /*0x1066eca99*/
    if ( v292[1] != nullptr /*0x1066ecab5*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v292[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v37 + 16LL))(a1: v37); /*0x1066ecabd*/
      std::__shared_weak_count::__release_weak(this: v37); /*0x1066ecac3*/
    }
    if ( DFFlag::ConnectDummyServiceClientEarly == 0 ) /*0x1066ecacf*/
    {
      std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: v277, a2: a18); /*0x1066ecadb*/
      RBX::Network::Client::connectDummyServiceClient(this: v317, a2: a16); /*0x1066ecb0e*/
      if ( v279 == 1 && (v277[0] & 1) != 0 ) /*0x1066ecb23*/
        operator delete(a1: (RBX::Memory *)v278, a2: v36); /*0x1066ecb2c*/
    }
    if ( (v357 & 1) != 0 ) /*0x1066ecb35*/
      operator delete(a1: (RBX::Memory *)v358, a2: v36); /*0x1066ecb3b*/
    if ( (v355 & 1) != 0 ) /*0x1066ecb47*/
      operator delete(a1: (RBX::Memory *)v356, a2: v36); /*0x1066ecb4d*/
    if ( (v353 & 1) != 0 ) /*0x1066ecb59*/
      operator delete(a1: (RBX::Memory *)v354, a2: v36); /*0x1066ecb62*/
    if ( (v351 & 1) != 0 ) /*0x1066ecb6e*/
      operator delete(a1: (RBX::Memory *)v352, a2: v36); /*0x1066ecb77*/
    if ( (v349 & 1) != 0 ) /*0x1066ecb83*/
      operator delete(a1: (RBX::Memory *)v350, a2: v36); /*0x1066ecb8c*/
    if ( (v345 & 1) != 0 ) /*0x1066ecb98*/
      operator delete(a1: (RBX::Memory *)v347, a2: v36); /*0x1066ecba1*/
    if ( (v342 & 1) != 0 ) /*0x1066ecbad*/
      operator delete(a1: (RBX::Memory *)v343, a2: v36); /*0x1066ecbb6*/
    if ( (v340[10] & 1) != 0 ) /*0x1066ecbc2*/
      operator delete(a1: (RBX::Memory *)v341, a2: v36); /*0x1066ecbcb*/
    if ( (v338 & 1) != 0 ) /*0x1066ecbd7*/
      operator delete(a1: (RBX::Memory *)v339, a2: v36); /*0x1066ecbe0*/
    if ( ((unsigned __int8)v335 & 1) != 0 ) /*0x1066ecbec*/
      operator delete(a1: (RBX::Memory *)v337, a2: v36); /*0x1066ecbf5*/
    if ( (v333 & 1) != 0 ) /*0x1066ecc01*/
      operator delete(a1: (RBX::Memory *)v334, a2: v36); /*0x1066ecc0a*/
    if ( ((__int64)v330[0] & 1) != 0 ) /*0x1066ecc16*/
    {
      v38 = (RBX::Memory *)v331[0]; /*0x1066ecc1c*/
LABEL_320:
      operator delete(a1: v38, a2: v36); /*0x1066ee4d7*/
      return __stack_chk_guard; /*0x1066ee4d7*/
    }
    return __stack_chk_guard; /*0x1066ecc16*/
  }
  v307 = 0; /*0x1066ecc2c*/
  v308 = nullptr; /*0x1066ecc34*/
  v39 = v316; /*0x1066ecc3f*/
  if ( (*(_BYTE *)v316 & 1) != 0 ) /*0x1066ecc4c*/
  {
    if ( v316[1] != 9 ) /*0x1066ecc5d*/
      goto LABEL_72; /*0x1066ecc5d*/
    v40 = (char *)v316[2]; /*0x1066ecc5f*/
  }
  else
  {
    if ( *(_BYTE *)v316 != 18 ) /*0x1066ecc50*/
      goto LABEL_72; /*0x1066ecc50*/
    v40 = (char *)v316 + 1; /*0x1066ecc52*/
  }
  if ( (*(_QWORD *)v40 ^ 0x736F686C61636F6CLL | (unsigned __int8)v40[8] ^ 0x74LL) == 0 ) /*0x1066ecc7b*/
    std::string::assign(a1: v316, a2: "127.0.0.1"); /*0x1066ecc87*/
LABEL_72:
  v41 = *a12; /*0x1066ecc8c*/
  v310 = 0; /*0x1066ecc93*/
  if ( v41 == a12[1] )
  {
    v54 = a11; /*0x1066ecd85*/
  }
  else
  {
    LODWORD(v315) = a6; /*0x1066ecca7*/
    v42 = a4; /*0x1066eccae*/
    v43 = *a11; /*0x1066eccb5*/
    v44 = a11[1]; /*0x1066eccb8*/
    if ( *a11 == v44 )
    {
      v55 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v317 + 36)); /*0x1066ecd9c*/
      a4 = v42; /*0x1066ecda5*/
      a6 = LODWORD(v315); /*0x1066ecda8*/
      if ( (*(_BYTE *)v316 & 1) != 0 ) /*0x1066ecdb4*/
        v56 = (char *)v316[2]; /*0x1066ecdec*/
      else
        v56 = (char *)v316 + 1; /*0x1066ecdb6*/
      v47 = (*(__int64 (__fastcall **)(__int64, _QWORD, __int128 *, char *, _QWORD))(*(_QWORD *)v55 + 768LL))( /*0x1066ece01*/
              a1: v55,
              a2: a14,
              a3: a13,
              a4: v56,
              a5: (unsigned __int16)a4);
      v54 = (__int64 *)a12; /*0x1066ece08*/
      if ( v47 != 0 )
      {
LABEL_79:
        v48 = (FLog *)DFLog::Rupp; /*0x1066ecd11*/
        if ( (unsigned __int8)DFLog::Rupp >= 6u && BYTE1(DFLog::Rupp) >= 3u )
        {
          v49 = qword_10D7BB258; /*0x1066ecd38*/
          v50 = (const char *)RBX::Rupp::RuppError::toString(a1: v47); /*0x1066ecd3e*/
          FLog::FastLogS(
            this: v48,
            a2: v49,
            a3: (unsigned __int64)"[DFLog::Rupp] Client failed Rupp setup: %s",
            a4: v50);
        }
        v51 = *a12; /*0x1066ecd58*/
        if ( (**a12 & 1) != 0 ) /*0x1066ecd5e*/
          v52 = *((char **)v51 + 2); /*0x1066ee502*/
        else
          v52 = (char *)(v51 + 1); /*0x1066ecd64*/
        RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066ee51f*/
          this: (RBX::Network::ConcurrentRakPeer **)v317,
          a2: "RuppSetupFailed",
          a3: 0,
          a4: v52,
          a5: 0,
          a6: 1);
        exception = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x1066ee52e*/
        RBX::runtime_error( /*0x1066ee53d*/
          this: exception,
          a2: "Failed to start setup client Rupp",
          a3: v205,
          a4: v206,
          a5: v207,
          a6: v208,
          a7: v209,
          a8: v210,
          a9: v211,
          a10: v212,
          a11: v213,
          a12: v214,
          a13: v215,
          a14: v216,
          a15: v260);
        __cxa_throw( /*0x1066ee553*/
          a1: exception,
          lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
          a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
      }
    }
    else
    {
      while ( 1 )
      {
        v45 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v317 + 36)); /*0x1066eccd8*/
        v46 = (*(_BYTE *)v43 & 1) != 0 ? *(_QWORD *)(v43 + 16) : v43 + 1;
        v47 = (*(__int64 (__fastcall **)(__int64, _QWORD, __int128 *, __int64, _QWORD))(*(_QWORD *)v45 + 768LL))( /*0x1066eccfd*/
                a1: v45,
                a2: a14,
                a3: a13,
                a4: v46,
                a5: *(unsigned __int16 *)(v43 + 24));
        if ( v47 == 0 ) /*0x1066ecd06*/
          break; /*0x1066ecd06*/
        v43 += 88; /*0x1066ecd08*/
        if ( v43 == v44 ) /*0x1066ecd0f*/
          goto LABEL_79; /*0x1066ecd0f*/
      }
      *((_BYTE *)v317 + 604) = 1; /*0x1066ecd73*/
      if ( (*(_BYTE *)v43 & 1) != 0 ) /*0x1066ecd7d*/
        v53 = *(_QWORD *)(v43 + 16); /*0x1066ecdbc*/
      else
        v53 = v43 + 1; /*0x1066ecd7f*/
      a4 = v42; /*0x1066ecdc0*/
      v39 = v316; /*0x1066ecdc3*/
      std::string::assign(a1: &v307, a2: v53); /*0x1066ecdd1*/
      a6 = LODWORD(v315); /*0x1066ecdd6*/
      v310 = *(_DWORD *)(v43 + 24); /*0x1066ecde0*/
      v54 = (__int64 *)a12; /*0x1066ecde6*/
    }
  }
  v57 = *v54; /*0x1066ece13*/
  v58 = v54[1]; /*0x1066ece16*/
  v59 = (_QWORD *)((char *)v317 + 4952); /*0x1066ece21*/
  if ( v57 == v58 ) /*0x1066ece35*/
  {
    if ( (*(_BYTE *)v39 & 1) != 0 ) /*0x1066ece64*/
    {
      std::string::__init_copy_ctor_external(a1: &v299, a2: v39[2], a3: v39[1]); /*0x1066ece90*/
    }
    else
    {
      v300 = (void *)v39[2]; /*0x1066ece6a*/
      v299 = *(_OWORD *)v39; /*0x1066ece77*/
    }
    RBX::Network::ConnectionInfo::ConnectionInfo(a1: v330, a2: &v299, a3: a4); /*0x1066ecea6*/
    std::vector<RBX::Network::ConnectionInfo>::push_back[abi:ne200100](a1: v59, a2: v330); /*0x1066eceb5*/
    if ( ((unsigned __int8)v335 & 1) != 0 ) /*0x1066ecec1*/
      operator delete(a1: (RBX::Memory *)v337, a2: v62); /*0x1066ececa*/
    if ( (v333 & 1) != 0 ) /*0x1066eced6*/
      operator delete(a1: (RBX::Memory *)v334, a2: v62); /*0x1066ecedf*/
    if ( ((__int64)v330[0] & 1) != 0 ) /*0x1066eceeb*/
      operator delete(a1: (RBX::Memory *)v331[0], a2: v62); /*0x1066ecef4*/
    if ( (v299 & 1) != 0 ) /*0x1066ecf00*/
      operator delete(a1: (RBX::Memory *)v300, a2: v62); /*0x1066ecf09*/
  }
  else
  {
    std::vector<RBX::Network::ConnectionInfo>::__insert_with_size[abi:ne200100]<std::reverse_iterator<std::__wrap_iter<RBX::Network::ConnectionInfo const*>>,std::reverse_iterator<std::__wrap_iter<RBX::Network::ConnectionInfo const*>>>( /*0x1066ece55*/
      a1: (_DWORD)v317 + 4952,
      a2: *v59,
      a3: v58,
      a4: v58,
      a5: v57,
      a6: v57,
      a7: 0x2E8BA2E8BA2E8BA3LL * ((v58 - v57) >> 3));
  }
  v316 = v59; /*0x1066ecf0e*/
  v63 = (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u; /*0x1066ecf30*/
  if ( (_BYTE)FLog::Network != 0 ) /*0x1066ecf35*/
  {
    if ( v63 ) /*0x1066ecf3d*/
      FLog::FastLogFormatted( /*0x1066ecf4f*/
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: (unsigned int)"[FLog::Network] Client will attempt to connect following server endpoints with threadSleepTime(%d)",
        a4: a6,
        a5: v60,
        a6: v61);
    v64 = *((_QWORD *)v317 + 619); /*0x1066ecf5b*/
    v65 = *((_QWORD *)v317 + 620); /*0x1066ecf62*/
    if ( *((_BYTE *)v317 + 604) == 1 ) /*0x1066ecf70*/
    {
      for ( ; v64 != v65; v64 += 88 ) /*0x1066ecf79*/
      {
        if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1066ecf9e*/
        {
          if ( (*(_BYTE *)v64 & 1) != 0 ) /*0x1066ecfa9*/
            v66 = *(_QWORD *)(v64 + 16); /*0x1066ecfb1*/
          else
            LODWORD(v66) = v64 + 1; /*0x1066ecfab*/
          v67 = (char *)&v307 + 1; /*0x1066ecfbc*/
          if ( (v307 & 1) != 0 ) /*0x1066ecfbf*/
            LODWORD(v67) = (_DWORD)v308; /*0x1066ecfc1*/
          v260 = v310; /*0x1066ecfd6*/
          FLog::FastLogFormatted( /*0x1066ecfde*/
            a1: FLog::Network,
            a2: qword_10D7BBAA8,
            a3: (unsigned int)"[FLog::Network] UDMUX Address = %s, Port = %d | RCC Server Address = %s, Port = %d",
            a4: v66,
            a5: *(_DWORD *)(v64 + 24),
            a6: (_DWORD)v67);
        }
      }
    }
    else
    {
      for ( ; v64 != v65; v64 += 88 ) /*0x1066ed014*/
      {
        if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1066ed02e*/
        {
          if ( (*(_BYTE *)v64 & 1) != 0 ) /*0x1066ed039*/
            v68 = *(_QWORD *)(v64 + 16); /*0x1066ed041*/
          else
            LODWORD(v68) = v64 + 1; /*0x1066ed03b*/
          FLog::FastLogFormatted( /*0x1066ed052*/
            a1: FLog::Network,
            a2: qword_10D7BBAA8,
            a3: (unsigned int)"[FLog::Network] Server Address = %s, Port = %d",
            a4: v68,
            a5: *(_DWORD *)(v64 + 24),
            a6: v61);
        }
      }
    }
  }
  else if ( v63 ) /*0x1066ecff0*/
  {
    FLog::FastLog( /*0x1066ed00a*/
      a1: FLog::Network,
      a2: qword_10D7BBAA8,
      a3: "[FLog::Network] Client:Connect serverPort(%d) clientPort(%d) threadSleepTime(%d)",
      a4,
      v311,
      a6);
  }
  *((_DWORD *)v317 + 148) = a7; /*0x1066ed06a*/
  v69 = RBX::Reflection::ValueTable::find(this: *a10, a2: "UserId"); /*0x1066ed07e*/
  v70 = (unsigned __int64)v309; /*0x1066ed083*/
  v71 = RBX::Reflection::Variant::get<long long>(a1: v69 + 40); /*0x1066ed091*/
  v72 = (RBX::Network::ConcurrentRakPeer **)v317; /*0x1066ed096*/
  *((_QWORD *)v317 + 67) = v71; /*0x1066ed09d*/
  RBX::Network::Client::handleConnectionStateAndMetricReporting(this: v72, a2: "JoinStart", a3: 0, a4: "", a5: 0, a6: 1); /*0x1066ed0bd*/
  *((_DWORD *)v317 + 158) = 1; /*0x1066ed0c9*/
  if ( (__int64)v70 > 0 && (__int64)(v70 % 0x3E8) < DFInt::ClientJoinProcessPositiveSamplesThousandths ) /*0x1066ed10e*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v280, a2: "client", a3: v70 / 0x3E8, a4: v70 % 0x3E8); /*0x1066ed122*/
    std::string::basic_string[abi:ne200100]<0>(a1: v282, a2: "report", a3: v74, a4: v75); /*0x1066ed135*/
    std::string::basic_string[abi:ne200100]<0>(a1: v284, a2: "GameServerConnectStarted", a3: v76, a4: v77); /*0x1066ed148*/
    memset(v262, 0, 32); /*0x1066ed15d*/
    v262[8] = 1065353216; /*0x1066ed161*/
    RBX::Analytics::EventIngest::setRBXEvent(a1: v280, a2: v282, a3: v284, a4: v262); /*0x1066ed17d*/
    std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v262); /*0x1066ed189*/
    if ( (v284[0] & 1) != 0 ) /*0x1066ed195*/
      operator delete(a1: (RBX::Memory *)v285, a2: v73); /*0x1066ed19e*/
    if ( (v282[0] & 1) != 0 ) /*0x1066ed1aa*/
      operator delete(a1: (RBX::Memory *)v283, a2: v73); /*0x1066ed1b3*/
    if ( (v280[0] & 1) != 0 ) /*0x1066ed1bf*/
      operator delete(a1: (RBX::Memory *)v281, a2: v73); /*0x1066ed1c8*/
  }
  v80 = RBX::DataModel::get(this: v317, a2: (RBX::Instance *)v73); /*0x1066ed1d9*/
  if ( v80 != 0 ) /*0x1066ed1df*/
  {
    RBX::Time::nowFast(this: v78); /*0x1066ed1e1*/
    v315 = v81; /*0x1066ed1e6*/
    v83 = RBX::DataModel::get(this: v317, a2: v82); /*0x1066ed1f5*/
    v84 = v315 - *(double *)(v83 + 1776); /*0x1066ed20a*/
    *(float *)(v80 + 1784) = v84; /*0x1066ed20e*/
    *(_DWORD *)(v80 + 1796) = a7; /*0x1066ed21a*/
    if ( FFlag::SAuthWorkspaceFlagged == 0 ) /*0x1066ed22b*/
    {
      EngineNetConfiguration = (_BYTE *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::Peer *)((char *)v317 + 2304)); /*0x1066ed509*/
      if ( FFlag::DebugHashTableMetrics != 0 || FFlag::SAuthWorkspaceFlagged == 1 && (*EngineNetConfiguration & 8) != 0 ) /*0x1066edb84*/
      {
        v114 = *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::AuroraService>(this: (RBX::ServiceProvider *)(v80 + 464)); /*0x1066ed52d*/
        if ( v114 != 0 ) /*0x1066ed533*/
        {
          v115 = RBX::Memory::setCurrentCategory( /*0x1066ed547*/
                   this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal,
                   a2: (unsigned int)v79);
          v116 = (rbx::signals::slots_holder **)(v114 + 272); /*0x1066ed54a*/
          rbx::lazyInitSlotsHolder(a1: v116); /*0x1066ed554*/
          v118 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x38, a2: v117); /*0x1066ed563*/
          *(_QWORD *)v118 = &_mh_execute_header; /*0x1066ed570*/
          *(_QWORD *)(v118 + 8) = rbx::signals::slot_with_functor<RBX::Network::Client::playerConnect(long long,std::string,int,int,int,int,std::string,bool,std::shared_ptr<RBX::Reflection::ValueTable const>,std::vector<RBX::Network::ConnectionInfo> const&,std::vector<RBX::Network::ConnectionInfo> const&,RBX::Rupp::TokenTlv::Token &,bool,std::optional<int>,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_2,int,int>::do_call; /*0x1066ed57a*/
          *(_OWORD *)(v118 + 16) = 0; /*0x1066ed581*/
          v119 = *v116; /*0x1066ed586*/
          *(_QWORD *)(v118 + 32) = *v116; /*0x1066ed58a*/
          if ( v119 != nullptr ) /*0x1066ed591*/
          {
            _InterlockedIncrement((volatile signed __int32 *)v119 + 1); /*0x1066ed597*/
            v120 = *(_QWORD *)(v118 + 24) & 0xFFFFFFFFFFFFFFFBLL; /*0x1066ed59f*/
          }
          else
          {
            v120 = 0; /*0x1066edcb8*/
          }
          *(_QWORD *)(v118 + 24) = v120; /*0x1066edcba*/
          *(_QWORD *)(v118 + 40) = v317; /*0x1066edcc5*/
          *(_QWORD *)(v118 + 48) = v80; /*0x1066edcc9*/
          rbx::signals::slots_holder::insert(this: *v116, a2: v118); /*0x1066edcd4*/
          v330[0] = (RBX::RbxTransport::DummyService::DummyClient *)v118; /*0x1066edcd9*/
          _InterlockedIncrement((volatile signed __int32 *)(v118 + 4)); /*0x1066edce0*/
          RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v115, a2: v177); /*0x1066edce8*/
          rbx::signals::scoped_connection::operator=(this: (RBX::Network::Peer *)((char *)v317 + 496)); /*0x1066edd02*/
          v178 = v330[0]; /*0x1066edd07*/
          if ( v330[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v330[0] + 1) == 0 ) /*0x1066edd1b*/
            rbx::signals::slot_base::operator delete(a1: v178); /*0x1066edd21*/
        }
      }
    }
  }
  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v317, a2: v79); /*0x1066ed238*/
  if ( ServiceProvider == nullptr /*0x1066ed251*/
    || (v86 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::Players>(this: ServiceProvider)) == 0 )
  {
    v217 = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x1066ee567*/
    RBX::runtime_error( /*0x1066ee576*/
      this: v217,
      a2: "Cannot get players",
      a3: v218,
      a4: v219,
      a5: v220,
      a6: v221,
      a7: v222,
      a8: v223,
      a9: v224,
      a10: v225,
      a11: v226,
      a12: v227,
      a13: v228,
      a14: v229,
      a15: v260);
    __cxa_throw( /*0x1066ee58c*/
      a1: v217,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  if ( *(_QWORD *)(v86 + 288) != 0 ) /*0x1066ed25f*/
    RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066ed281*/
      this: (RBX::Network::ConcurrentRakPeer **)v317,
      a2: "ReJoinFromSameDataModel",
      a3: 0,
      a4: "",
      a5: 0,
      a6: 1);
  v345 = RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::ValueTable const>>(a1: v87); /*0x1066ed292*/
  v346 = 0; /*0x1066ed296*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::shared_ptr<RBX::Reflection::ValueTable const>>( /*0x1066ed2a1*/
    a1: &v346,
    a2: (__int64)a10);
  if ( (unsigned __int8)RBX::WebParser::writeJSON(a1: &v345, a2: (char *)v317 + 672, a3: 1, a4: 0) == 0 ) /*0x1066ed2c9*/
  {
    v230 = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x1066ee5a5*/
    std::runtime_error::runtime_error(this: v230, a2: "Cannot construct player information to send to server"); /*0x1066ee5b2*/
    __cxa_throw( /*0x1066ee5c8*/
      a1: v230,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  v306 = (RBX::DataModel *)v80; /*0x1066ed2cf*/
  v88 = 0x2E8BA2E8BA2E8BA3LL * ((__int64)(*((_QWORD *)v317 + 620) - *((_QWORD *)v317 + 619)) >> 3); /*0x1066ed2f9*/
  *(_QWORD *)&v315 = -1171354717 * (unsigned int)((__int64)(*((_QWORD *)v317 + 620) - *((_QWORD *)v317 + 619)) >> 3); /*0x1066ed306*/
  std::vector<RakNet::SocketDescriptor>::vector[abi:ne200100](a1: v298); /*0x1066ed30d*/
  v290 = v88; /*0x1066ed312*/
  if ( (_DWORD)v88 != 0 )
  {
    v90 = (char *)v298[0]; /*0x1066ed321*/
    v91 = *v316; /*0x1066ed32f*/
    v92 = 50LL * *(_QWORD *)&v315; /*0x1066ed332*/
    v93 = 1; /*0x1066ed33a*/
    v94 = 16; /*0x1066ed340*/
    v95 = 0; /*0x1066ed34d*/
    do
    {
      if ( (*(_BYTE *)(v91 + v94 - 16) & 1) != 0 ) /*0x1066ed356*/
        v96 = *(RakNet::SocketDescriptor **)(v91 + v94); /*0x1066ed35d*/
      else
        v96 = (RakNet::SocketDescriptor *)(v93 + v91); /*0x1066ed358*/
      v97 = RakNet::RakPeer::resolveSocketFamily(this: (RakNet::RakPeer *)&v90[v95], a2: v96, a3: v89); /*0x1066ed364*/
      if ( v97 != 0 && (unsigned __int8)FLog::Output >= 6u && BYTE1(FLog::Output) >= 3u )
      {
        v99 = *v316; /*0x1066ed38d*/
        if ( (*(_BYTE *)(*v316 + v94 - 16) & 1) != 0 ) /*0x1066ed396*/
          v100 = *(_QWORD *)(v99 + v94); /*0x1066ed39e*/
        else
          LODWORD(v100) = v99 + v93; /*0x1066ed398*/
        FLog::FastLogFormatted(
          a1: FLog::Output,
          a2: qword_10D7BE938,
          a3: (unsigned int)"[FLog::Output] serverConnection(%s|%d) couldn't be resolved : %d",
          a4: v100,
          a5: *(_DWORD *)(v99 + v94 + 8),
          a6: v97);
      }
      v101 = RBX::DataModel::get(this: v317, a2: v98); /*0x1066ed3c3*/
      v90 = (char *)v298[0]; /*0x1066ed3c8*/
      v102 = *(_WORD *)((char *)v298[0] + v95 + 48); /*0x1066ed3cf*/
      if ( v101 != 0 && v102 == 30 ) /*0x1066ed3de*/
      {
        *(_BYTE *)(v101 + 2270) = 1; /*0x1066ed3e0*/
        v102 = 30; /*0x1066ed3e7*/
      }
      *(_WORD *)&v90[v95] = v311; /*0x1066ed3f1*/
      v91 = *v316; /*0x1066ed3fd*/
      *(_WORD *)(*v316 + v94 + 12) = v102; /*0x1066ed400*/
      v95 += 50; /*0x1066ed406*/
      v93 += 88; /*0x1066ed40a*/
      v94 += 88; /*0x1066ed40e*/
    }
    while ( v92 != v95 );
  }
  v103 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v317 + 36)); /*0x1066ed429*/
  (*(void (__fastcall **)(__int64, unsigned __int8 *))(*(_QWORD *)v103 + 928LL))(a1: v103, a2: v309); /*0x1066ed43b*/
  v104 = *((_DWORD *)v317 + 1236); /*0x1066ed448*/
  v105 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v317 + 36)); /*0x1066ed455*/
  v106 = v306; /*0x1066ed45a*/
  v107 = v290; /*0x1066ed461*/
  v108 = &DFInt::CliMaxPayloadRcv; /*0x1066ed472*/
  if ( v104 == 2 ) /*0x1066ed479*/
    v108 = &DFInt::CliTcMaxPayloadRcv; /*0x1066ed479*/
  v261 = 0; /*0x1066ed493*/
  if ( (*(unsigned int (__fastcall **)(__int64, __int64, int *, void *, _QWORD, _QWORD))(*(_QWORD *)v105 + 16LL))( /*0x1066ed4ad*/
         a1: v105,
         a2: 1,
         a3: v108,
         a4: v298[0],
         a5: (unsigned int)v290,
         a6: 0) != 0 )
  {
    v231 = v316; /*0x1066ee5d5*/
    if ( v107 != 0 ) /*0x1066ee5dc*/
    {
      v232 = 88LL * *(_QWORD *)&v315; /*0x1066ee5de*/
      v233 = 0; /*0x1066ee5e6*/
      do /*0x1066ee640*/
      {
        RBX::Network::ConnectionInfo::ToStringN( /*0x1066ee611*/
          this: (RBX::Network::ConnectionInfo *)(v233 + *v231),
          a2: true,
          a3: (char *)v330,
          a4: 1025,
          a5: 124);
        RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066ee634*/
          this: (RBX::Network::ConcurrentRakPeer **)v317,
          a2: "RakNetStartupFailed",
          a3: 1u,
          a4: (char *)v330,
          a5: 3,
          a6: 1);
        v233 += 88; /*0x1066ee639*/
      }
      while ( v232 != v233 ); /*0x1066ee640*/
    }
    v234 = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x1066ee647*/
    v247 = v234; /*0x1066ee64c*/
    if ( (_DWORD)v311 != 0 ) /*0x1066ee656*/
      RBX::runtime_error( /*0x1066ee6b6*/
        this: v234,
        a2: "Failed to start network client on port %d",
        a3: (unsigned int)v311,
        a4: v236,
        a5: v237,
        a6: v238,
        a7: v239,
        a8: v240,
        a9: v241,
        a10: v242,
        a11: v243,
        a12: v244,
        a13: v245,
        a14: v246,
        a15: 0);
    else
      RBX::runtime_error( /*0x1066ee664*/
        this: v234,
        a2: "Failed to start network client",
        a3: v235,
        a4: v236,
        a5: v237,
        a6: v238,
        a7: v239,
        a8: v240,
        a9: v241,
        a10: v242,
        a11: v243,
        a12: v244,
        a13: v245,
        a14: v246,
        a15: 0);
    __cxa_throw( /*0x1066ee6cc*/
      a1: v247,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  v110 = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v317, a2: v109); /*0x1066ed4ba*/
  if ( v110 != nullptr ) /*0x1066ed4c2*/
    v111 = (RBX::RunService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::RunService>(this: v110); /*0x1066ed4cc*/
  else
    v111 = nullptr; /*0x1066ed4d1*/
  v112 = (unsigned __int8)RBX::RunService::isStudio(this: v111) == 0 || (unsigned int)(*((_DWORD *)v317 + 1236) - 1) < 2; /*0x1066ed5a8*/
  v121 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v317 + 36)); /*0x1066ed5b8*/
  (*(void (__fastcall **)(__int64, bool))(*(_QWORD *)v121 + 728LL))(a1: v121, a2: v112); /*0x1066ed5c6*/
  if ( v112 && *((_DWORD *)v317 + 1236) == 0 ) /*0x1066ed5de*/
  {
    v122 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v317 + 36)); /*0x1066ed5ee*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v122 + 736LL))(a1: v122); /*0x1066ed5f9*/
  }
  v123 = (RBX::Network::Peer *)((char *)v317 + 4608); /*0x1066ed606*/
  RSL::Mutex::lock(this: (RBX::Network::Peer *)((char *)v317 + 4608)); /*0x1066ed610*/
  v124 = a12; /*0x1066ed615*/
  v291 = v123; /*0x1066ed619*/
  if ( v107 != 0 ) /*0x1066ed623*/
  {
    v311 = 88LL * *(_QWORD *)&v315; /*0x1066ed631*/
    v309 = &RBX::Network::versionB[1]; /*0x1066ed642*/
    v125 = 0; /*0x1066ed649*/
    v126 = 0; /*0x1066ed64b*/
    v315 = 0.0; /*0x1066ed64e*/
    do /*0x1066ed74b*/
    {
      v127 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v317 + 36)); /*0x1066ed667*/
      v128 = *v316; /*0x1066ed673*/
      if ( (*(_BYTE *)(*v316 + v125) & 1) != 0 ) /*0x1066ed67a*/
        v129 = *(_QWORD *)(v128 + v125 + 16); /*0x1066ed685*/
      else
        v129 = v128 + v125 + 1; /*0x1066ed680*/
      if ( (RBX::Network::versionB[0] & 1) != 0 ) /*0x1066ed699*/
      {
        v130 = *(void **)&RBX::Network::versionB[16]; /*0x1066ed69b*/
        v131 = *(unsigned int *)&RBX::Network::versionB[8]; /*0x1066ed69f*/
      }
      else
      {
        v131 = RBX::Network::versionB[0] >> 1; /*0x1066ed6a5*/
        v130 = v309; /*0x1066ed6a8*/
      }
      v261 = v126; /*0x1066ed6d1*/
      LODWORD(v123) = (*(__int64 (__fastcall **)(__int64, __int64, _QWORD, unsigned __int8 *, __int64, _QWORD))(*(_QWORD *)v127 + 112LL))( /*0x1066ed6e6*/
                        a1: v127,
                        a2: v129,
                        a3: *(unsigned __int16 *)(v128 + v125 + 24),
                        a4: (unsigned __int8 *)v130,
                        a5: v131,
                        a6: 0);
      if ( (_DWORD)v123 != 0 ) /*0x1066ed6eb*/
      {
        RBX::Network::ConnectionInfo::ToStringN( /*0x1066ed714*/
          this: (RBX::Network::ConnectionInfo *)(v125 + *v316),
          a2: true,
          a3: (char *)v330,
          a4: 1025,
          a5: 124);
        RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066ed738*/
          this: (RBX::Network::ConcurrentRakPeer **)v317,
          a2: "RakNetDidNotStartConnectAttempt",
          a3: 1u,
          a4: (char *)v330,
          a5: 3,
          a6: 0);
      }
      else
      {
        *(_DWORD *)(*v316 + v125 + 36) = 1; /*0x1066ed760*/
        v134 = *(_QWORD *)&DFLog::NetworkJoin; /*0x1066ed76f*/
        if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && BYTE1(DFLog::NetworkJoin) >= 3u ) /*0x1066ed781*/
        {
          v135 = qword_10D7F3E08; /*0x1066ed78f*/
          RBX::Time::nowFastSec(this: v132); /*0x1066ed793*/
          *(float *)&v136 = v136; /*0x1066ed798*/
          FLog::FastLogF( /*0x1066ed7b2*/
            a1: v134,
            a2: v135,
            a3: "[DFLog::NetworkJoin] playerConnect connecting to server @ %f s",
            v136,
            0.0,
            0.0,
            0.0);
        }
        v137 = (unsigned __int8)FLog::Output >= 6u && BYTE1(FLog::Output) >= 3u; /*0x1066ed7d2*/
        if ( *((_BYTE *)v317 + 604) == 1 ) /*0x1066ed7e2*/
        {
          if ( v137 ) /*0x1066ed7e6*/
          {
            v138 = *v316; /*0x1066ed7f3*/
            if ( (*(_BYTE *)(*v316 + v125) & 1) != 0 ) /*0x1066ed7fa*/
              v139 = *(_QWORD *)(v138 + v125 + 16); /*0x1066ed826*/
            else
              LODWORD(v139) = v138 + v125 + 1; /*0x1066ed800*/
            v142 = (char *)&v307 + 1; /*0x1066ed832*/
            if ( (v307 & 1) != 0 ) /*0x1066ed839*/
              LODWORD(v142) = (_DWORD)v308; /*0x1066ed83b*/
            v261 = v310; /*0x1066ed858*/
            FLog::FastLogFormatted( /*0x1066ed864*/
              a1: FLog::Output,
              a2: qword_10D7BE938,
              a3: (unsigned int)"[FLog::Output] Connecting to UDMUX server %s:%d, and RCC server %s:%d",
              a4: v139,
              a5: *(_DWORD *)(v138 + v125 + 24),
              a6: (_DWORD)v142);
          }
        }
        else if ( v137 ) /*0x1066ed807*/
        {
          v140 = *v316; /*0x1066ed814*/
          if ( (*(_BYTE *)(*v316 + v125) & 1) != 0 ) /*0x1066ed81b*/
            v141 = *(_QWORD *)(v140 + v125 + 16); /*0x1066ed86b*/
          else
            LODWORD(v141) = v140 + v125 + 1; /*0x1066ed821*/
          FLog::FastLogFormatted( /*0x1066ed889*/
            a1: FLog::Output,
            a2: qword_10D7BE938,
            a3: (unsigned int)"[FLog::Output] Connecting to %s:%d",
            a4: v141,
            a5: *(_DWORD *)(v140 + v125 + 24),
            a6: v133);
        }
        *(double *)&v143 = COERCE_DOUBLE(RBX::ServiceProvider::find<RBX::TeleportService>(a1: v317)); /*0x1066ed895*/
        v146 = v143; /*0x1066ed89a*/
        LOBYTE(v143) = 1; /*0x1066ed89d*/
        v315 = *(double *)&v143; /*0x1066ed89f*/
        if ( v146 != 0 ) /*0x1066ed8a9*/
        {
          std::string::basic_string[abi:ne200100]<0>(a1: v286, a2: "ClientConnecting", a3: v144, a4: v145); /*0x1066ed8bd*/
          v157 = *v316; /*0x1066ed8c9*/
          if ( (*(_BYTE *)(*v316 + v125) & 1) != 0 ) /*0x1066ed8d0*/
            v158 = *(_QWORD *)(v157 + v125 + 16); /*0x1066ed8db*/
          else
            v158 = v157 + v125 + 1; /*0x1066ed8d6*/
          RBX::format( /*0x1066ed8f4*/
            this: (RBX *)v288,
            a2: "IP=%s,Port=%d",
            a3: v158,
            a4: *(unsigned int *)(v157 + v125 + 24),
            a5: v147,
            a6: v148,
            a7: v149,
            a8: v150,
            a9: v151,
            a10: v152,
            a11: v153,
            a12: v154,
            a13: v155,
            a14: v156,
            a15: v261);
          std::string::basic_string[abi:ne200100]<0>(a1: v264, a2: "", a3: v159, a4: v160); /*0x1066ed90a*/
          RBX::TeleportService::logClientGroupTeleportInfluxDB(a1: v146, a2: v286, a3: v288, a4: v264); /*0x1066ed923*/
          if ( (v264[0] & 1) != 0 ) /*0x1066ed92f*/
            operator delete(a1: (RBX::Memory *)v265, a2: v161); /*0x1066ed938*/
          if ( (v288[0] & 1) != 0 ) /*0x1066ed944*/
            operator delete(a1: (RBX::Memory *)v289, a2: v161); /*0x1066ed94d*/
          if ( (v286[0] & 1) != 0 ) /*0x1066ed959*/
            operator delete(a1: (RBX::Memory *)v287, a2: v161); /*0x1066ed966*/
        }
      }
      ++v126; /*0x1066ed73d*/
      v125 += 88; /*0x1066ed740*/
    }
    while ( v311 != v125 ); /*0x1066ed74b*/
    v124 = a12; /*0x1066ed970*/
    v106 = v306; /*0x1066ed974*/
  }
  else
  {
    v315 = 0.0; /*0x1066ed97d*/
  }
  RSL::Mutex::unlock(this: v291); /*0x1066ed98f*/
  if ( (LOBYTE(v315) & 1) == 0 ) /*0x1066ed99b*/
  {
    v248 = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x1066ee675*/
    RBX::runtime_error( /*0x1066ee687*/
      this: v248,
      a2: "Failed to connect to server, id %d",
      a3: (unsigned int)v123,
      a4: v249,
      a5: v250,
      a6: v251,
      a7: v252,
      a8: v253,
      a9: v254,
      a10: v255,
      a11: v256,
      a12: v257,
      a13: v258,
      a14: v259,
      a15: v261);
    __cxa_throw( /*0x1066ee69d*/
      a1: v248,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  if ( (unsigned __int8)RBX::DataModel::getShouldSetGlobalTelemetryInfo(this: v106) != 0 ) /*0x1066ed9ab*/
    unk_10D77E5F8 = a7; /*0x1066ed9b7*/
  if ( DFFlag::DebugDisableTimeoutDisconnect == 1 ) /*0x1066ed9c7*/
  {
    v163 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v317 + 36)); /*0x1066ed9d7*/
    *(_OWORD *)v331 = *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1); /*0x1066ed9e3*/
    *(_OWORD *)v330 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1066ed9f1*/
    (*(void (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v163 + 448LL))( /*0x1066eda21*/
      a1: v163,
      a2: 600000,
      a3: v164,
      a4: *(_QWORD *)(*(_QWORD *)v163 + 448LL),
      a5: v165,
      a6: v166,
      a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
      a8: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
      a9: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
      a10: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3));
  }
  if ( *((_DWORD *)v317 + 1236) == 2 ) /*0x1066eda31*/
  {
    v167 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)v317 + 36)); /*0x1066eda41*/
    *(_OWORD *)v331 = *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1); /*0x1066eda57*/
    *(_OWORD *)v330 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1066eda65*/
    (*(void (__fastcall **)(__int64, _QWORD, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v167 + 448LL))( /*0x1066eda90*/
      a1: v167,
      a2: (unsigned int)(1000 * DFInt::TeamCreateTimeOutInSec),
      a3: v168,
      a4: *(_QWORD *)(*(_QWORD *)v167 + 448LL),
      a5: v169,
      a6: v170,
      a7: RakNet::UNASSIGNED_SYSTEM_ADDRESS,
      a8: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1),
      a9: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 2),
      a10: *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 3));
  }
  if ( DFFlag::ReportClientLocalDNSInfo == 1 ) /*0x1066eda99*/
    RBX::Network::Client::reportDnsLocalityConfig(this: v162); /*0x1066eda9b*/
  if ( (a15 & 0x100000000LL) != 0 && HIBYTE(a17) != 0 )
  {
    v312 = 0; /*0x1066edab9*/
    v313 = nullptr; /*0x1066edac0*/
    if ( *a11 == a11[1] ) /*0x1066edad6*/
    {
      v172 = 0; /*0x1066edb8f*/
      v171 = 0; /*0x1066edb91*/
    }
    else
    {
      std::string::operator=(a1: &v312, a2: *a11); /*0x1066edae3*/
      v171 = v312; /*0x1066edae8*/
      v172 = *((_QWORD *)&v312 + 1); /*0x1066edaee*/
    }
    v36 = (void *)a15; /*0x1066edb93*/
    v314 = a15; /*0x1066edb97*/
    LOBYTE(v174) = v171 >> 1; /*0x1066edb9f*/
    v173 = v171 & 1; /*0x1066edba1*/
    v174 = (unsigned __int8)v174; /*0x1066edba3*/
    if ( v173 != 0 ) /*0x1066edba6*/
      v174 = v172; /*0x1066edba6*/
    LOBYTE(v174) = v174 == 0 || (_DWORD)a15 == 0; /*0x1066edbb5*/
    if ( (_BYTE)v174 != 0 ) /*0x1066edbb7*/
      goto LABEL_312; /*0x1066edbb7*/
    LOBYTE(v326) = 0; /*0x1066edbbf*/
    v329 = 0; /*0x1066edbc5*/
    if ( *v124 == v124[1] )
    {
      if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 )
      {
        v330[0] = nullptr; /*0x1066edc6a*/
        v331[0] = (void *)1; /*0x1066edc71*/
        *(_QWORD *)v324 = 119; /*0x1066edc79*/
        *(_QWORD *)&v324[8] = v330; /*0x1066edc84*/
        FLog::detail::FastLogSafeFormattedInternal(
          a1: (_DWORD)DFLog::NetworkClient,
          a2: qword_10D809380,
          a3: 4,
          a4: (unsigned int)"[DFLog::NetworkClient] RbxTransport DummyClient will connect without RuppConfig. udmuxEndpointsA"
                        "rg exists: {}, rbxTransportToken exists: {}",
          a5: 139,
          a6: 1,
          119,
          v330);
      }
    }
    else
    {
      memset(v324, 0, sizeof(v324)); /*0x1066edbde*/
      RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v325); /*0x1066edbed*/
      v324[0] = a14; /*0x1066edbf5*/
      LODWORD(v303) = 0; /*0x1066edbfb*/
      v304 = 0; /*0x1066edc08*/
      v305 = nullptr; /*0x1066edc0f*/
      if ( (v312 & 1) != 0 ) /*0x1066edc24*/
      {
        v175 = (char *)v313; /*0x1066edc2a*/
        v176 = *((_QWORD *)&v312 + 1); /*0x1066edc31*/
      }
      else
      {
        v176 = (unsigned __int8)v312 >> 1; /*0x1066edd2b*/
        v175 = (char *)&v312 + 1; /*0x1066edd2d*/
      }
      RBX::RbxTransport::Io::EndpointAddr::fromIpAddrStr(a1: v330, a2: v175, a3: v176, a4: (unsigned __int16)v314); /*0x1066edd42*/
      v263[0] = &v303; /*0x1066edd55*/
      v263[1] = v325; /*0x1066edd58*/
      std::__memberwise_forward_assign[abi:ne200100]<std::tuple<RBX::RbxTransport::Io::Error &,RBX::RbxTransport::Io::EndpointAddr &>,std::tuple<RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr>,RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr,0ul,1ul>( /*0x1066edd69*/
        a1: v263,
        a2: v330);
      std::tuple<RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr>::~tuple(a1: v330); /*0x1066edd71*/
      if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v303) == 0 )
      {
        v179 = (int)DFLog::NetworkClient; /*0x1066edd82*/
        if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFE00) != 0 )
        {
          v180 = qword_10D809380; /*0x1066edd9e*/
          RBX::RbxTransport::Io::Error::toString(this: (RBX::RbxTransport::Io::Error *)v330); /*0x1066eddb3*/
          FLog::FastLogSafeFormatted<std::string>(
            a1: v179,
            a2: v180,
            a3: 2,
            a4: (int)"[DFLog::NetworkClient] RbxTransport DummyClient rccAddr parse error: {}",
            a5: 71,
            a6: (unsigned __int8 *)v330);
          if ( ((__int64)v330[0] & 1) != 0 ) /*0x1066edde3*/
            operator delete(a1: (RBX::Memory *)v331[0], a2: v181); /*0x1066eddec*/
        }
      }
      v324[17] = a17; /*0x1066eddff*/
      *(_OWORD *)&v324[1] = a16; /*0x1066ede05*/
      std::optional<RBX::Rupp::ClientRuppConfiguration>::operator=[abi:ne200100]<RBX::Rupp::ClientRuppConfiguration&,void>(a1: &v326); /*0x1066ede10*/
      v182 = (int)DFLog::NetworkClient; /*0x1066ede15*/
      if ( (unsigned __int8)DFLog::NetworkClient >= 6u && BYTE1(DFLog::NetworkClient) >= 5u ) /*0x1066ede2b*/
      {
        v183 = qword_10D809380; /*0x1066ede36*/
        RBX::RbxTransport::Io::EndpointAddr::toString(this: (RBX::RbxTransport::Io::EndpointAddr *)v330); /*0x1066ede47*/
        Port = RBX::RbxTransport::Io::EndpointAddr::getPort(this: (RBX::RbxTransport::Io::EndpointAddr *)v325); /*0x1066ede5b*/
        v184 = "false"; /*0x1066ede64*/
        if ( v324[0] != 0 ) /*0x1066ede72*/
          v184 = "true"; /*0x1066ede72*/
        v263[0] = v184; /*0x1066ede76*/
        v273 = v324[1]; /*0x1066ede8b*/
        FLog::FastLogSafeFormatted<std::string,int,char const*,int>( /*0x1066edeba*/
          a1: v182,
          a2: v183,
          a3: 5,
          a4: (int)"[DFLog::NetworkClient] RbxTransport DummyClient RuppConfig = RCC {}:{}, DSR {}, Token type {}",
          a5: 93,
          a6: (unsigned __int8 *)v330,
          a7: &Port,
          a8: v263,
          a9: &v273);
        if ( ((__int64)v330[0] & 1) != 0 ) /*0x1066edec6*/
          operator delete(a1: (RBX::Memory *)v331[0], a2: v185); /*0x1066edecf*/
      }
      std::string::operator=(a1: &v312, a2: *v124); /*0x1066edede*/
      LODWORD(v106) = (_DWORD)v306; /*0x1066edeea*/
      if ( (v304 & 1) != 0 ) /*0x1066edef1*/
        operator delete(a1: (RBX::Memory *)v305, a2: v186); /*0x1066edefa*/
      RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v325); /*0x1066edf02*/
    }
    v187 = (int)DFLog::NetworkClient; /*0x1066edf07*/
    if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 ) /*0x1066edf1c*/
    {
      v188 = qword_10D809380; /*0x1066edf27*/
      if ( v329 == 1 ) /*0x1066edf35*/
      {
        RBX::Rupp::ClientRuppConfiguration::toString(this: (RBX::Rupp::ClientRuppConfiguration *)v330); /*0x1066edf45*/
      }
      else
      {
        LOBYTE(v172) = (unsigned __int8)DFLog::NetworkClient < 6u /*0x1066edf1f*/
                    || ((unsigned __int16)DFLog::NetworkClient & 0xFC00) == 0;
        std::string::basic_string[abi:ne200100]<0>(a1: v330, a2: "none", a3: v174, a4: v172); /*0x1066edf5a*/
      }
      FLog::FastLogSafeFormatted<std::string &,int &,std::string>( /*0x1066edf95*/
        a1: v187,
        a2: v188,
        a3: 4,
        a4: (int)"[DFLog::NetworkClient] RbxTransport DummyClient will connect to server {}:{}, ruppConfig {}",
        a5: 91,
        a6: (unsigned __int8 *)&v312,
        a7: &v314,
        a8: (unsigned __int8 *)v330);
      if ( ((__int64)v330[0] & 1) != 0 ) /*0x1066edfa1*/
        operator delete(a1: (RBX::Memory *)v331[0], a2: v189); /*0x1066edfaa*/
    }
    isLocalTest = RBX::Network::Peer::isLocalTest(this: v317); /*0x1066edfb6*/
    RBX::Security::RakPeerCrypto::getRbxTransportClientKeyInfo( /*0x1066edfce*/
      this: (RBX::Security::RakPeerCrypto *)v324,
      a2: (DFFlag::DebugRbxTransportUseTestKey | isLocalTest) & 1);
    if ( (unsigned __int8)DFLog::NetworkClient >= 6u && BYTE1(DFLog::NetworkClient) >= 5u )
    {
      v303 = *(_QWORD *)&v324[8] - *(_QWORD *)v324; /*0x1066ee00b*/
      v330[0] = (RBX::RbxTransport::DummyService::DummyClient *)4; /*0x1066ee00e*/
      v330[1] = (RBX::RbxTransport::DummyService::DummyClient *)&v303; /*0x1066ee019*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: (_DWORD)DFLog::NetworkClient,
        a2: qword_10D809380,
        a3: 5,
        a4: (unsigned int)"[DFLog::NetworkClient] RbxTransport DummyClient will use public key size: {}",
        a5: 76,
        a6: 1,
        4,
        &v303);
    }
    if ( DFFlag::DebugDisableRbxTransportDummyClient != 0 ) /*0x1066ee04f*/
    {
      if ( (unsigned __int8)DFLog::NetworkClient >= 6u && BYTE1(DFLog::NetworkClient) >= 3u ) /*0x1066ee066*/
      {
        v330[0] = nullptr; /*0x1066ee078*/
        v330[1] = (RBX::RbxTransport::DummyService::DummyClient *)&v303; /*0x1066ee08a*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x1066ee0b4*/
          a1: (_DWORD)DFLog::NetworkClient,
          a2: qword_10D809380,
          a3: 3,
          a4: (unsigned int)"[DFLog::NetworkClient] RbxTransport DummyClient is disabled by DebugDisableRbxTransportDummyClient flag.",
          a5: 104,
          a6: 1,
          0,
          &v303);
      }
LABEL_280:
      v198 = (RBX::Network::Peer *)((char *)v317 + 5000); /*0x1066ee1f1*/
      RSL::Mutex::lock(this: (RBX::Network::Peer *)((char *)v317 + 5000)); /*0x1066ee202*/
      v294 = v312; /*0x1066ee20e*/
      v295 = v313; /*0x1066ee21c*/
      v199 = 0; /*0x1066ee223*/
      v312 = 0; /*0x1066ee226*/
      v313 = nullptr; /*0x1066ee22d*/
      v200 = v314; /*0x1066ee238*/
      LOBYTE(v318) = 0; /*0x1066ee241*/
      v321 = 0; /*0x1066ee247*/
      if ( v329 == 1 ) /*0x1066ee254*/
      {
        v319 = v327; /*0x1066ee268*/
        v318 = v326; /*0x1066ee271*/
        RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(a1: v320, a2: v328); /*0x1066ee279*/
        v199 = 0; /*0x1066ee27e*/
        v321 = 1; /*0x1066ee281*/
      }
      v296 = v199; /*0x1066ee286*/
      v297 = nullptr; /*0x1066ee28f*/
      *(_OWORD *)v293 = v199; /*0x1066ee29d*/
      v293[2] = nullptr; /*0x1066ee2a0*/
      std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1066ee2b8*/
        a1: v293,
        a2: *(_QWORD *)v324,
        a3: *(_QWORD *)&v324[8],
        a4: *(_QWORD *)&v324[8] - *(_QWORD *)v324);
      std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: v269, a2: a18); /*0x1066ee2cb*/
      RBX::RbxTransport::ConnectConfiguration::configForQuic( /*0x1066ee2fa*/
        a1: (unsigned int)v330,
        a2: (unsigned int)&v294,
        a3: v200,
        a4: (unsigned int)&v318,
        a5: (unsigned int)&v296,
        a6: (unsigned int)v293,
        a7: (__int64)v269);
      std::allocate_shared[abi:ne200100]<RBX::RbxTransport::ConnectConfiguration,std::allocator<RBX::RbxTransport::ConnectConfiguration>,RBX::RbxTransport::ConnectConfiguration,0>( /*0x1066ee314*/
        a1: &v303,
        a2: v263,
        a3: v330);
      std::shared_ptr<RBX::RbxTransport::ConnectConfiguration>::operator=[abi:ne200100]( /*0x1066ee331*/
        a1: (char *)v317 + 5008,
        a2: &v303);
      v202 = (std::__shared_weak_count *)v304; /*0x1066ee336*/
      if ( (_QWORD)v304 != 0 /*0x1066ee34f*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)(v304 + 8), 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v202 + 16LL))(a1: v202); /*0x1066ee357*/
        std::__shared_weak_count::__release_weak(this: v202); /*0x1066ee35d*/
      }
      if ( v344 == 1 && (v342 & 1) != 0 ) /*0x1066ee372*/
        operator delete(a1: (RBX::Memory *)v343, a2: v201); /*0x1066ee37b*/
      if ( BYTE2(v341) == 1 ) /*0x1066ee387*/
        RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v340); /*0x1066ee390*/
      if ( v335 != nullptr ) /*0x1066ee39f*/
      {
        v336 = v335; /*0x1066ee3a1*/
        operator delete(a1: (RBX::Memory *)v335, a2: v201); /*0x1066ee3a8*/
      }
      if ( (v333 & 1) != 0 ) /*0x1066ee3b4*/
        operator delete(a1: (RBX::Memory *)v334, a2: v201); /*0x1066ee3bd*/
      if ( ((__int64)v330[1] & 1) != 0 ) /*0x1066ee3c9*/
        operator delete(a1: (RBX::Memory *)v331[1], a2: v201); /*0x1066ee3d2*/
      if ( v271 == 1 && (v269[0] & 1) != 0 ) /*0x1066ee3e7*/
        operator delete(a1: (RBX::Memory *)v270, a2: v201); /*0x1066ee3f0*/
      if ( v293[0] != nullptr ) /*0x1066ee3ff*/
      {
        v293[1] = v293[0]; /*0x1066ee401*/
        operator delete(a1: (RBX::Memory *)v293[0], a2: v201); /*0x1066ee408*/
      }
      if ( (v296 & 1) != 0 ) /*0x1066ee414*/
        operator delete(a1: (RBX::Memory *)v297, a2: v201); /*0x1066ee41d*/
      if ( v321 == 1 ) /*0x1066ee429*/
        RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v320); /*0x1066ee432*/
      if ( (v294 & 1) != 0 ) /*0x1066ee43e*/
        operator delete(a1: (RBX::Memory *)v295, a2: v201); /*0x1066ee447*/
      RSL::Mutex::unlock(this: v198); /*0x1066ee44f*/
      if ( *(_QWORD *)v324 != 0 ) /*0x1066ee45e*/
      {
        *(_QWORD *)&v324[8] = *(_QWORD *)v324; /*0x1066ee460*/
        operator delete(a1: *(RBX::Memory **)v324, a2: v36); /*0x1066ee467*/
      }
      if ( v329 == 1 ) /*0x1066ee473*/
        RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v328); /*0x1066ee47c*/
      v173 = v312 & 1; /*0x1066ee487*/
LABEL_312:
      if ( v173 != 0 ) /*0x1066ee48b*/
        operator delete(a1: (RBX::Memory *)v313, a2: v36); /*0x1066ee494*/
      goto LABEL_314; /*0x1066ee494*/
    }
    std::make_unique[abi:ne200100]<RBX::RbxTransport::DummyService::DummyClient,std::vector<unsigned char> &,std::optional<RBX::Rupp::ClientRuppConfiguration> &,0>( /*0x1066ee0d3*/
      a1: v330,
      a2: v324,
      a3: &v326);
    v191 = (__int64 *)((char *)v317 + 4664); /*0x1066ee0df*/
    v192 = v330[0]; /*0x1066ee0e6*/
    v330[0] = nullptr; /*0x1066ee0ef*/
    std::unique_ptr<RBX::RbxTransport::DummyService::DummyClient>::reset[abi:ne200100]( /*0x1066ee0f9*/
      a1: (char *)v317 + 4664,
      a2: v192);
    v193 = v330[0]; /*0x1066ee0fe*/
    v330[0] = nullptr; /*0x1066ee105*/
    if ( v193 != nullptr ) /*0x1066ee10f*/
    {
      RBX::RbxTransport::DummyService::DummyClient::~DummyClient(this: v193); /*0x1066ee114*/
      operator delete(a1: v193, a2: v194); /*0x1066ee11c*/
    }
    v195 = *v191; /*0x1066ee121*/
    if ( (v312 & 1) != 0 ) /*0x1066ee12b*/
    {
      std::string::__init_copy_ctor_external(a1: &v301, a2: v313, a3: *((_QWORD *)&v312 + 1)); /*0x1066ee160*/
    }
    else
    {
      v302 = v313; /*0x1066ee134*/
      v301 = v312; /*0x1066ee142*/
    }
    v322[0] = off_10CAA77A8; /*0x1066ee184*/
    v322[1] = v317; /*0x1066ee18e*/
    v323 = v322; /*0x1066ee192*/
    RBX::RbxTransport::DummyService::DummyClient::connectAsync( /*0x1066ee1b4*/
      a1: v195,
      a2: (_DWORD)v106,
      a3: (unsigned int)&v301,
      a4: (unsigned __int16)v314,
      a5: 1,
      a6: 0,
      a7: FFlag::RbxTransportDummyClientEnableTimeSync,
      a8: (__int64)v322);
    if ( v323 == v322 ) /*0x1066ee1c3*/
    {
      v197 = 32; /*0x1066ee1d1*/
    }
    else
    {
      v197 = 40; /*0x1066ee1c5*/
      if ( v323 == nullptr ) /*0x1066ee1cd*/
      {
LABEL_278:
        if ( (v301 & 1) != 0 ) /*0x1066ee1e3*/
          operator delete(a1: (RBX::Memory *)v302, a2: v196); /*0x1066ee1ec*/
        goto LABEL_280; /*0x1066ee1ec*/
      }
    }
    (*(void (**)(void))(*v323 + v197))(); /*0x1066ee1d9*/
    goto LABEL_278; /*0x1066ee1d9*/
  }
  if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 )
  {
    v330[0] = (RBX::RbxTransport::DummyService::DummyClient *)(BYTE4(a15) & 1); /*0x1066edb32*/
    v331[0] = (void *)HIBYTE(a17); /*0x1066edb35*/
    *(_QWORD *)&v326 = 119; /*0x1066edb39*/
    *((_QWORD *)&v326 + 1) = v330; /*0x1066edb44*/
    FLog::detail::FastLogSafeFormattedInternal(
      a1: (_DWORD)DFLog::NetworkClient,
      a2: qword_10D809380,
      a3: 4,
      a4: (unsigned int)"[DFLog::NetworkClient] RbxTransport DummyClient is disabled by missing port or token. Port exists: {"
                    "}, token exists: {}",
      a5: 119,
      a6: 1,
      119,
      v330);
  }
LABEL_314:
  if ( v298[0] != nullptr ) /*0x1066ee4a3*/
  {
    v298[1] = v298[0]; /*0x1066ee4a5*/
    operator delete(a1: (RBX::Memory *)v298[0], a2: v36); /*0x1066ee4ac*/
  }
  if ( v346 != 0 ) /*0x1066ee4bb*/
    (*(void (__fastcall **)(void **))(v346 + 16))(a1: &v347); /*0x1066ee4c4*/
  if ( (v307 & 1) != 0 ) /*0x1066ee4ce*/
  {
    v38 = (RBX::Memory *)v308; /*0x1066ee4d0*/
    goto LABEL_320; /*0x1066ee4d0*/
  }
  return __stack_chk_guard; /*0x1066ee4f0*/
}

// Address: 0x1066eed98 | Name: __ZZN3RBX7Network6Client13playerConnectExNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEiiiiS8_bNS2_10shared_ptrIKNS_10Reflection10ValueTableEEERKNS2_6vectorINS0_14ConnectionInfoENS6_ISF_EEEESJ_RNS_4Rupp8TokenTlv5TokenEbNS2_8optionalIiEENSO_ISM_EENSO_IS8_EENSO_INS_12RbxTransport12CapabilitiesEEEEN3$_0D1Ev
void __fastcall RBX::Network::Client::playerConnect(long long,std::string,int,int,int,int,std::string,bool,std::shared_ptr<RBX::Reflection::ValueTable const>,std::vector<RBX::Network::ConnectionInfo> const&,std::vector<RBX::Network::ConnectionInfo> const&,RBX::Rupp::TokenTlv::Token &,bool,std::optional<int>,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_0::~$_0(
        __int64 a1)
{
  std::__shared_weak_count *v2; // rdi

  RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)(a1 + 16)); /*0x1066eeda5*/
  v2 = *(std::__shared_weak_count **)(a1 + 8); /*0x1066eedaa*/
  if ( v2 != nullptr ) /*0x1066eedb5*/
    std::__shared_weak_count::__release_weak(this: v2); /*0x1066eedb9*/
}

// Address: 0x1066eedc4 | Name: __ZN3RBX7Network6Client25connectDummyServiceClientERKNS0_19FinalConnectionArgsEbNSt3__18optionalINS_4Rupp8TokenTlv5TokenEEENS6_INS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEEE
__int64 __fastcall RBX::Network::Client::connectDummyServiceClient(
        RBX::Network::Peer *this,
        unsigned int *a2,
        char a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int128 a7,
        __int16 a8)
{
  __int64 v12; // rax
  char v13; // al
  unsigned int v14; // ecx
  __int64 v15; // rcx
  unsigned int *v16; // r15
  void *v17; // rsi
  unsigned int v18; // ecx
  char v19; // al
  __int64 v20; // rdx
  __int64 v21; // rcx
  unsigned int v22; // eax
  __int64 v23; // rax
  char *v24; // rsi
  __int64 v25; // rdx
  void *v26; // rsi
  int v27; // r13d
  void *v28; // rsi
  int v29; // r13d
  const char *v30; // rdx
  void *v31; // rsi
  void *v32; // rsi
  int v33; // r12d
  int v34; // r13d
  void *v35; // rsi
  char isLocalTest; // al
  RBX::RbxTransport::DummyService::DummyClient *v37; // rsi
  RBX::RbxTransport::DummyService::DummyClient *v38; // r13
  void *v39; // rsi
  char v40; // al
  __int64 v41; // r12
  int v42; // edx
  int v43; // esi
  void *v44; // rsi
  __int64 v45; // rax
  RSL::Mutex *v46; // r15
  __int128 v47; // xmm0
  unsigned __int16 v48; // r14
  void *v49; // rsi
  std::__shared_weak_count *v50; // rbx
  _QWORD v52[2]; // [rsp+18h] [rbp-2D8h] BYREF
  _BYTE v53[16]; // [rsp+28h] [rbp-2C8h] BYREF
  void *v54; // [rsp+38h] [rbp-2B8h]
  char v55; // [rsp+40h] [rbp-2B0h]
  unsigned int Port; // [rsp+48h] [rbp-2A8h] BYREF
  unsigned int v57; // [rsp+4Ch] [rbp-2A4h] BYREF
  __int64 v58; // [rsp+50h] [rbp-2A0h]
  __int64 v59; // [rsp+58h] [rbp-298h]
  void *v60[4]; // [rsp+60h] [rbp-290h] BYREF
  __int128 v61; // [rsp+80h] [rbp-270h] BYREF
  void *v62; // [rsp+90h] [rbp-260h]
  __int128 v63; // [rsp+A0h] [rbp-250h] BYREF
  void *v64; // [rsp+B0h] [rbp-240h]
  __int128 v65; // [rsp+C0h] [rbp-230h] BYREF
  void *v66; // [rsp+D0h] [rbp-220h]
  __int64 v67; // [rsp+E0h] [rbp-210h] BYREF
  __int128 v68; // [rsp+E8h] [rbp-208h]
  void *v69; // [rsp+F8h] [rbp-1F8h]
  __int64 v70; // [rsp+108h] [rbp-1E8h]
  __int128 v71; // [rsp+110h] [rbp-1E0h] BYREF
  void *v72; // [rsp+120h] [rbp-1D0h]
  unsigned int v73; // [rsp+12Ch] [rbp-1C4h] BYREF
  __int128 v74; // [rsp+130h] [rbp-1C0h] BYREF
  __int16 v75; // [rsp+140h] [rbp-1B0h]
  _BYTE v76[28]; // [rsp+142h] [rbp-1AEh] BYREF
  char v77; // [rsp+15Eh] [rbp-192h]
  RBX::RbxTransport::DummyService::DummyClient *v78[2]; // [rsp+160h] [rbp-190h] BYREF
  void *v79; // [rsp+170h] [rbp-180h]
  void *v80; // [rsp+178h] [rbp-178h]
  _BYTE v81[24]; // [rsp+180h] [rbp-170h] BYREF
  void *v82; // [rsp+198h] [rbp-158h]
  void *v83; // [rsp+1A0h] [rbp-150h]
  void *v84; // [rsp+1A8h] [rbp-148h]
  _BYTE v85[50]; // [rsp+1D6h] [rbp-11Ah] BYREF
  void *v86; // [rsp+208h] [rbp-E8h]
  char v87; // [rsp+210h] [rbp-E0h]
  _QWORD v88[4]; // [rsp+230h] [rbp-C0h] BYREF
  _QWORD *v89; // [rsp+250h] [rbp-A0h]
  _BYTE v90[18]; // [rsp+260h] [rbp-90h] BYREF
  _BYTE v91[30]; // [rsp+272h] [rbp-7Eh] BYREF
  __int128 v92; // [rsp+290h] [rbp-60h] BYREF
  __int16 v93; // [rsp+2A0h] [rbp-50h]
  _BYTE v94[28]; // [rsp+2A2h] [rbp-4Eh] BYREF
  char v95; // [rsp+2BEh] [rbp-32h]

  v12 = RBX::DataModel::get(this, (RBX::Instance *)a2); /*0x1066eedf2*/
  if ( v12 != 0 )
  {
    v59 = v12; /*0x1066eedfc*/
    v58 = a4; /*0x1066eee03*/
    LOBYTE(a4) = HIBYTE(a8); /*0x1066eee0e*/
    if ( HIBYTE(a8) != 0 ) /*0x1066eee15*/
      v13 = 0; /*0x1066eee17*/
    else
      v13 = RBX::Network::Peer::isLocalTest(this) ^ 1; /*0x1066eee8c*/
    v14 = *(unsigned __int8 *)a2; /*0x1066eee8e*/
    if ( (v14 & 1) != 0 ) /*0x1066eee96*/
      v15 = *((_QWORD *)a2 + 1); /*0x1066eee98*/
    else
      v15 = v14 >> 1; /*0x1066eee9f*/
    v16 = a2 + 6; /*0x1066eeea1*/
    if ( v15 != 0 && a2[6] != 0 && v13 == 0 )
    {
      v71 = 0; /*0x1066eeec1*/
      v72 = nullptr; /*0x1066eeec4*/
      std::string::operator=(a1: &v71, a2); /*0x1066eeecf*/
      v18 = *v16; /*0x1066eeed4*/
      v73 = *v16; /*0x1066eeed7*/
      v19 = v71 & 1; /*0x1066eeee6*/
      if ( (v71 & 1) != 0 ) /*0x1066eeee8*/
        v20 = *((_QWORD *)&v71 + 1); /*0x1066eeeea*/
      else
        v20 = (unsigned __int8)v71 >> 1; /*0x1066eef4b*/
      if ( v20 == 0 || v18 == 0 ) /*0x1066eef55*/
      {
LABEL_99:
        if ( v19 != 0 ) /*0x1066ef81e*/
          operator delete(a1: (RBX::Memory *)v72, a2: v17); /*0x1066ef827*/
        return __stack_chk_guard; /*0x1066ef827*/
      }
      v21 = (unsigned int)a4; /*0x1066eef60*/
      LOBYTE(v92) = 0; /*0x1066eef68*/
      v95 = 0; /*0x1066eef6b*/
      v22 = *((unsigned __int8 *)a2 + 88); /*0x1066eef6e*/
      if ( (v22 & 1) != 0 ) /*0x1066eef76*/
        v23 = *((_QWORD *)a2 + 12); /*0x1066eef78*/
      else
        v23 = v22 >> 1; /*0x1066eef7f*/
      if ( (HIBYTE(a8) ^ 1 | (v23 == 0)) != 0 )
      {
        LOBYTE(v20) = (unsigned __int8)DFLog::NetworkClient < 6u /*0x1066ef006*/
                   || ((unsigned __int16)DFLog::NetworkClient & 0xFC00) == 0;
        if ( (_BYTE)v20 == 0 )
        {
          v78[0] = (RBX::RbxTransport::DummyService::DummyClient *)(v23 != 0); /*0x1066ef028*/
          v79 = (void *)HIBYTE(a8); /*0x1066ef02b*/
          *(_QWORD *)v90 = 119; /*0x1066ef02f*/
          *(_QWORD *)&v90[8] = v78; /*0x1066ef03a*/
          FLog::detail::FastLogSafeFormattedInternal(
            a1: (_DWORD)DFLog::NetworkClient,
            a2: qword_10D809380,
            a3: 4,
            a4: (unsigned int)"[DFLog::NetworkClient] RbxTransport DummyClient will connect without RuppConfig. udmuxEndpoint"
                          " exists: {}, rbxTransportToken exists: {}",
            a5: 135,
            a6: 1,
            119,
            v78);
        }
      }
      else
      {
        memset(v90, 0, sizeof(v90)); /*0x1066eef92*/
        RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v91); /*0x1066eefa1*/
        v90[0] = a3; /*0x1066eefa6*/
        LODWORD(v67) = 0; /*0x1066eefad*/
        v68 = 0; /*0x1066eefba*/
        v69 = nullptr; /*0x1066eefc1*/
        if ( (v71 & 1) != 0 ) /*0x1066eefd6*/
        {
          v24 = (char *)v72; /*0x1066eefdc*/
          v25 = *((_QWORD *)&v71 + 1); /*0x1066eefe3*/
        }
        else
        {
          v25 = (unsigned __int8)v71 >> 1; /*0x1066ef06e*/
          v24 = (char *)&v71 + 1; /*0x1066ef070*/
        }
        RBX::RbxTransport::Io::EndpointAddr::fromIpAddrStr(a1: v78, a2: v24, a3: v25, a4: (unsigned __int16)v73); /*0x1066ef085*/
        v52[0] = &v67; /*0x1066ef098*/
        v52[1] = v91; /*0x1066ef09b*/
        std::__memberwise_forward_assign[abi:ne200100]<std::tuple<RBX::RbxTransport::Io::Error &,RBX::RbxTransport::Io::EndpointAddr &>,std::tuple<RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr>,RBX::RbxTransport::Io::Error,RBX::RbxTransport::Io::EndpointAddr,0ul,1ul>( /*0x1066ef0a9*/
          a1: v52,
          a2: v78);
        RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v81); /*0x1066ef0b8*/
        if ( ((__int64)v78[1] & 1) != 0 ) /*0x1066ef0c2*/
          operator delete(a1: (RBX::Memory *)v80, a2: v26); /*0x1066ef0cb*/
        if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v67) == 0 )
        {
          v27 = (int)DFLog::NetworkClient; /*0x1066ef0e0*/
          if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFE00) != 0 )
          {
            v70 = qword_10D809380; /*0x1066ef103*/
            RBX::RbxTransport::Io::Error::toString(this: (RBX::RbxTransport::Io::Error *)v78); /*0x1066ef118*/
            FLog::FastLogSafeFormatted<std::string>(
              a1: v27,
              a2: v70,
              a3: 2,
              a4: (int)"[DFLog::NetworkClient] RbxTransport DummyClient rccAddr parse error: {}",
              a5: 71,
              a6: (unsigned __int8 *)v78);
            if ( ((__int64)v78[0] & 1) != 0 ) /*0x1066ef14c*/
              operator delete(a1: (RBX::Memory *)v79, a2: v28); /*0x1066ef155*/
          }
        }
        v90[17] = a8; /*0x1066ef168*/
        *(_OWORD *)&v90[1] = a7; /*0x1066ef16e*/
        std::optional<RBX::Rupp::ClientRuppConfiguration>::operator=[abi:ne200100]<RBX::Rupp::ClientRuppConfiguration&,void>(a1: &v92); /*0x1066ef176*/
        v29 = (int)DFLog::NetworkClient; /*0x1066ef17b*/
        if ( (unsigned __int8)DFLog::NetworkClient >= 6u && BYTE1(DFLog::NetworkClient) >= 5u ) /*0x1066ef191*/
        {
          v70 = qword_10D809380; /*0x1066ef1a3*/
          RBX::RbxTransport::Io::EndpointAddr::toString(this: (RBX::RbxTransport::Io::EndpointAddr *)v78); /*0x1066ef1b4*/
          Port = RBX::RbxTransport::Io::EndpointAddr::getPort(this: (RBX::RbxTransport::Io::EndpointAddr *)v91); /*0x1066ef1c8*/
          v30 = "false"; /*0x1066ef1d1*/
          if ( v90[0] != 0 ) /*0x1066ef1df*/
            v30 = "true"; /*0x1066ef1df*/
          v52[0] = v30; /*0x1066ef1e3*/
          v57 = v90[1]; /*0x1066ef1f8*/
          FLog::FastLogSafeFormatted<std::string,int,char const*,int>( /*0x1066ef22b*/
            a1: v29,
            a2: v70,
            a3: 5,
            a4: (int)"[DFLog::NetworkClient] RbxTransport DummyClient RuppConfig = RCC {}:{}, DSR {}, Token type {}",
            a5: 93,
            a6: (unsigned __int8 *)v78,
            a7: &Port,
            a8: v52,
            a9: &v57);
          if ( ((__int64)v78[0] & 1) != 0 ) /*0x1066ef237*/
            operator delete(a1: (RBX::Memory *)v79, a2: v31); /*0x1066ef240*/
        }
        std::string::operator=(a1: &v71, a2: a2 + 22); /*0x1066ef251*/
        v73 = a2[28]; /*0x1066ef25b*/
        if ( (v68 & 1) != 0 ) /*0x1066ef268*/
          operator delete(a1: (RBX::Memory *)v69, a2: v32); /*0x1066ef271*/
        RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v91); /*0x1066ef279*/
      }
      v33 = (int)DFLog::NetworkClient; /*0x1066ef27e*/
      if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 ) /*0x1066ef293*/
      {
        v34 = qword_10D809380; /*0x1066ef29e*/
        if ( v95 == 1 ) /*0x1066ef2a9*/
        {
          RBX::Rupp::ClientRuppConfiguration::toString(this: (RBX::Rupp::ClientRuppConfiguration *)v78); /*0x1066ef2b6*/
        }
        else
        {
          LOBYTE(v21) = (unsigned __int8)DFLog::NetworkClient < 6u /*0x1066ef296*/
                     || ((unsigned __int16)DFLog::NetworkClient & 0xFC00) == 0;
          std::string::basic_string[abi:ne200100]<0>(a1: v78, a2: "none", a3: v20, a4: v21); /*0x1066ef2cb*/
        }
        FLog::FastLogSafeFormatted<std::string &,int &,std::string>( /*0x1066ef306*/
          a1: v33,
          a2: v34,
          a3: 4,
          a4: (int)"[DFLog::NetworkClient] RbxTransport DummyClient will connect to server {}:{}, ruppConfig {}",
          a5: 91,
          a6: (unsigned __int8 *)&v71,
          a7: &v73,
          a8: (unsigned __int8 *)v78);
        if ( ((__int64)v78[0] & 1) != 0 ) /*0x1066ef312*/
          operator delete(a1: (RBX::Memory *)v79, a2: v35); /*0x1066ef31b*/
      }
      isLocalTest = RBX::Network::Peer::isLocalTest(this); /*0x1066ef323*/
      RBX::Security::RakPeerCrypto::getRbxTransportClientKeyInfo( /*0x1066ef33b*/
        this: (RBX::Security::RakPeerCrypto *)v90,
        a2: (DFFlag::DebugRbxTransportUseTestKey | isLocalTest) & 1);
      if ( (unsigned __int8)DFLog::NetworkClient >= 6u && BYTE1(DFLog::NetworkClient) >= 5u )
      {
        v67 = *(_QWORD *)&v90[8] - *(_QWORD *)v90; /*0x1066ef378*/
        v78[0] = (RBX::RbxTransport::DummyService::DummyClient *)4; /*0x1066ef37b*/
        v78[1] = (RBX::RbxTransport::DummyService::DummyClient *)&v67; /*0x1066ef386*/
        FLog::detail::FastLogSafeFormattedInternal(
          a1: (_DWORD)DFLog::NetworkClient,
          a2: qword_10D809380,
          a3: 5,
          a4: (unsigned int)"[DFLog::NetworkClient] RbxTransport DummyClient will use public key size: {}",
          a5: 76,
          a6: 1,
          4,
          &v67);
      }
      if ( DFFlag::DebugDisableRbxTransportDummyClient != 0 ) /*0x1066ef3bc*/
      {
        if ( (unsigned __int8)DFLog::NetworkClient >= 6u && BYTE1(DFLog::NetworkClient) >= 3u ) /*0x1066ef3d3*/
        {
          v78[0] = nullptr; /*0x1066ef3e5*/
          v78[1] = (RBX::RbxTransport::DummyService::DummyClient *)&v67; /*0x1066ef3f7*/
          FLog::detail::FastLogSafeFormattedInternal( /*0x1066ef421*/
            a1: (_DWORD)DFLog::NetworkClient,
            a2: qword_10D809380,
            a3: 3,
            a4: (unsigned int)"[DFLog::NetworkClient] RbxTransport DummyClient is disabled by DebugDisableRbxTransportDummyClient flag.",
            a5: 104,
            a6: 1,
            0,
            &v67);
        }
LABEL_67:
        v46 = (RBX::Network::Peer *)((char *)this + 5000); /*0x1066ef593*/
        RSL::Mutex::lock(this: (RBX::Network::Peer *)((char *)this + 5000)); /*0x1066ef59d*/
        v61 = v71; /*0x1066ef5a9*/
        v62 = v72; /*0x1066ef5b7*/
        v47 = 0; /*0x1066ef5be*/
        v71 = 0; /*0x1066ef5c1*/
        v72 = nullptr; /*0x1066ef5c8*/
        v48 = v73; /*0x1066ef5d3*/
        LOBYTE(v74) = 0; /*0x1066ef5dd*/
        v77 = 0; /*0x1066ef5e3*/
        if ( v95 == 1 ) /*0x1066ef5ed*/
        {
          v75 = v93; /*0x1066ef5fe*/
          v74 = v92; /*0x1066ef608*/
          RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(a1: v76, a2: v94); /*0x1066ef611*/
          v47 = 0; /*0x1066ef616*/
          v77 = 1; /*0x1066ef619*/
        }
        v63 = v47; /*0x1066ef61f*/
        v64 = nullptr; /*0x1066ef628*/
        *(_OWORD *)v60 = v47; /*0x1066ef636*/
        v60[2] = nullptr; /*0x1066ef639*/
        std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1066ef651*/
          a1: v60,
          a2: *(_QWORD *)v90,
          a3: *(_QWORD *)&v90[8],
          a4: *(_QWORD *)&v90[8] - *(_QWORD *)v90);
        std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: v53, a2: v58); /*0x1066ef667*/
        RBX::RbxTransport::ConnectConfiguration::configForQuic( /*0x1066ef697*/
          a1: (unsigned int)v78,
          a2: (unsigned int)&v61,
          a3: v48,
          a4: (unsigned int)&v74,
          a5: (unsigned int)&v63,
          a6: (unsigned int)v60,
          a7: (__int64)v53);
        std::allocate_shared[abi:ne200100]<RBX::RbxTransport::ConnectConfiguration,std::allocator<RBX::RbxTransport::ConnectConfiguration>,RBX::RbxTransport::ConnectConfiguration,0>( /*0x1066ef6b1*/
          a1: &v67,
          a2: v52,
          a3: v78);
        std::shared_ptr<RBX::RbxTransport::ConnectConfiguration>::operator=[abi:ne200100]( /*0x1066ef6ca*/
          a1: (char *)this + 5008,
          a2: &v67);
        v50 = (std::__shared_weak_count *)v68; /*0x1066ef6cf*/
        if ( (_QWORD)v68 != 0 /*0x1066ef6e8*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(v68 + 8), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v50 + 16LL))(a1: v50); /*0x1066ef6f0*/
          std::__shared_weak_count::__release_weak(this: v50); /*0x1066ef6f6*/
        }
        if ( v87 == 1 && (v85[34] & 1) != 0 ) /*0x1066ef70b*/
          operator delete(a1: (RBX::Memory *)v86, a2: v49); /*0x1066ef714*/
        if ( v85[28] == 1 ) /*0x1066ef720*/
          RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v85); /*0x1066ef729*/
        if ( v83 != nullptr ) /*0x1066ef738*/
        {
          v84 = v83; /*0x1066ef73a*/
          operator delete(a1: (RBX::Memory *)v83, a2: v49); /*0x1066ef741*/
        }
        if ( (v81[8] & 1) != 0 ) /*0x1066ef74d*/
          operator delete(a1: (RBX::Memory *)v82, a2: v49); /*0x1066ef756*/
        if ( ((__int64)v78[1] & 1) != 0 ) /*0x1066ef762*/
          operator delete(a1: (RBX::Memory *)v80, a2: v49); /*0x1066ef76b*/
        if ( v55 == 1 && (v53[0] & 1) != 0 ) /*0x1066ef780*/
          operator delete(a1: (RBX::Memory *)v54, a2: v49); /*0x1066ef789*/
        if ( v60[0] != nullptr ) /*0x1066ef798*/
        {
          v60[1] = v60[0]; /*0x1066ef79a*/
          operator delete(a1: (RBX::Memory *)v60[0], a2: v49); /*0x1066ef7a1*/
        }
        if ( (v63 & 1) != 0 ) /*0x1066ef7ad*/
          operator delete(a1: (RBX::Memory *)v64, a2: v49); /*0x1066ef7b6*/
        if ( v77 == 1 ) /*0x1066ef7c2*/
          RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v76); /*0x1066ef7cb*/
        if ( (v61 & 1) != 0 ) /*0x1066ef7d7*/
          operator delete(a1: (RBX::Memory *)v62, a2: v49); /*0x1066ef7e0*/
        RSL::Mutex::unlock(this: v46); /*0x1066ef7e8*/
        if ( *(_QWORD *)v90 != 0 ) /*0x1066ef7f7*/
        {
          *(_QWORD *)&v90[8] = *(_QWORD *)v90; /*0x1066ef7f9*/
          operator delete(a1: *(RBX::Memory **)v90, a2: v17); /*0x1066ef800*/
        }
        if ( v95 == 1 ) /*0x1066ef809*/
          RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v94); /*0x1066ef80f*/
        v19 = v71 & 1; /*0x1066ef81a*/
        goto LABEL_99; /*0x1066ef81a*/
      }
      std::make_unique[abi:ne200100]<RBX::RbxTransport::DummyService::DummyClient,std::vector<unsigned char> &,std::optional<RBX::Rupp::ClientRuppConfiguration> &,0>( /*0x1066ef43d*/
        a1: v78,
        a2: v90,
        a3: &v92);
      v37 = v78[0]; /*0x1066ef449*/
      v78[0] = nullptr; /*0x1066ef453*/
      std::unique_ptr<RBX::RbxTransport::DummyService::DummyClient>::reset[abi:ne200100]( /*0x1066ef45d*/
        a1: (char *)this + 4664,
        a2: v37);
      v38 = v78[0]; /*0x1066ef462*/
      v78[0] = nullptr; /*0x1066ef469*/
      if ( v38 != nullptr ) /*0x1066ef473*/
      {
        RBX::RbxTransport::DummyService::DummyClient::~DummyClient(this: v38); /*0x1066ef478*/
        operator delete(a1: v38, a2: v39); /*0x1066ef480*/
      }
      v40 = FFlag::RbxTransportDummyClientEnableTimeSync; /*0x1066ef48c*/
      v41 = *((_QWORD *)this + 583); /*0x1066ef48f*/
      if ( FFlag::RbxTransportDummyClientEnableTimeSync == 1 ) /*0x1066ef495*/
      {
        v42 = DFInt::RbxTransportDummyClientTimeSyncFastRetryIntervalMs; /*0x1066ef49d*/
        v43 = DFInt::RbxTransportDummyClientTimeSyncMaxFastRetries; /*0x1066ef4a3*/
        *(_DWORD *)(v41 + 356) = DFInt::RbxTransportDummyClientTimeSyncIntervalMs; /*0x1066ef4a9*/
        *(_DWORD *)(v41 + 360) = v42; /*0x1066ef4b1*/
        *(_DWORD *)(v41 + 364) = v43; /*0x1066ef4b9*/
        *(_BYTE *)(v41 + 368) = 1; /*0x1066ef4c1*/
      }
      if ( (v71 & 1) != 0 ) /*0x1066ef4d1*/
      {
        std::string::__init_copy_ctor_external(a1: &v65, a2: v72, a3: *((_QWORD *)&v71 + 1)); /*0x1066ef506*/
        v40 = FFlag::RbxTransportDummyClientEnableTimeSync; /*0x1066ef50b*/
      }
      else
      {
        v66 = v72; /*0x1066ef4da*/
        v65 = v71; /*0x1066ef4e8*/
      }
      v88[0] = off_10CAA7888; /*0x1066ef523*/
      v88[1] = this; /*0x1066ef526*/
      v89 = v88; /*0x1066ef52a*/
      RBX::RbxTransport::DummyService::DummyClient::connectAsync( /*0x1066ef556*/
        a1: v41,
        a2: v59,
        a3: (unsigned int)&v65,
        a4: (unsigned __int16)v73,
        a5: 1,
        a6: 0,
        a7: v40 & 1,
        a8: (__int64)v88);
      if ( v89 == v88 ) /*0x1066ef565*/
      {
        v45 = 32; /*0x1066ef573*/
      }
      else
      {
        v45 = 40; /*0x1066ef567*/
        if ( v89 == nullptr ) /*0x1066ef56f*/
        {
LABEL_65:
          if ( (v65 & 1) != 0 ) /*0x1066ef585*/
            operator delete(a1: (RBX::Memory *)v66, a2: v44); /*0x1066ef58e*/
          goto LABEL_67; /*0x1066ef58e*/
        }
      }
      (*(void (**)(void))(*v89 + v45))(); /*0x1066ef57b*/
      goto LABEL_65; /*0x1066ef57b*/
    }
    if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 )
    {
      LOBYTE(v78[0]) = HIBYTE(a8); /*0x1066eef20*/
      FLog::FastLogSafeFormatted<std::string const&,int const&,bool>(
        a1: (int)DFLog::NetworkClient,
        a2: qword_10D809380,
        a3: 4,
        a4: (int)"[DFLog::NetworkClient] RbxTransport DummyClient is disabled by missing address, port or token. Address: {},"
             " Port: {}, token exists: {}",
        a5: 134,
        a6: (unsigned __int8 *)a2,
        a7: a2 + 6,
        a8: (unsigned __int8 *)v78);
    }
  }
  else if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFE00) != 0 )
  {
    FLog::detail::FastLogSafeFormattedInternal(
      a1: (_DWORD)DFLog::NetworkClient,
      a2: qword_10D809380,
      a3: 2,
      a4: (unsigned int)"[DFLog::NetworkClient] NetStack DummyClient cannot connect: DataModel not found",
      a5: 79,
      a6: 1,
      0,
      &v92);
  }
  return __stack_chk_guard; /*0x1066ef83c*/
}

// Address: 0x1066efa30 | Name: __ZN3RBX7Network6Client23reportDnsLocalityConfigEv
void __fastcall RBX::Network::Client::reportDnsLocalityConfig(RBX::Network::Client *this)
{
  void *v1[9]; // [rsp+8h] [rbp-238h] BYREF
  _BYTE v2[477]; // [rsp+50h] [rbp-1F0h] BYREF
  __int16 v3; // [rsp+22Dh] [rbp-13h] BYREF
  char v4; // [rsp+22Fh] [rbp-11h]

  v3 = 0; /*0x1066efa42*/
  v4 = 0; /*0x1066efa47*/
  if ( (unsigned __int8)RBX::NetworkUtils::GetDnsServerLocality(a1: &v3) != 0 ) /*0x1066efa52*/
  {
    if ( (_BYTE)v3 == 1 ) /*0x1066efa5c*/
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1066efa6c*/
        a1: v1,
        a2: (__int64)&RBX::Telemetry::kClientLocalDnsServerConfigured);
    else
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1066efa9c*/
        a1: v1,
        a2: (__int64)&RBX::Telemetry::kClientNoLocalDnsServerConfigured);
    RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v2); /*0x1066efa7b*/
    RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v1); /*0x1066efa87*/
    RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v2); /*0x1066efaca*/
    RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v1, a2: (void **)off_10C8C7EB0); /*0x1066efadd*/
    if ( HIBYTE(v3) == 1 ) /*0x1066efae6*/
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1066efaf6*/
        a1: v1,
        a2: (__int64)&RBX::Telemetry::kClientNonLocalDnsServerConfigured);
    else
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1066efb1f*/
        a1: v1,
        a2: (__int64)&RBX::Telemetry::kClientNoNonLocalDnsServerConfigured);
    RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v2); /*0x1066efafe*/
    RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v1); /*0x1066efb0a*/
    RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v2); /*0x1066efb46*/
    RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v1, a2: (void **)off_10C8C7EB0); /*0x1066efb59*/
    if ( v4 == 1 ) /*0x1066efb62*/
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1066efb72*/
        a1: v1,
        a2: (__int64)&RBX::Telemetry::kClientPrimaryLocalDnsServerConfigured);
    else
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1066efb9b*/
        a1: v1,
        a2: (__int64)&RBX::Telemetry::kClientPrimaryNonLocalDnsServerConfigured);
    RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v2); /*0x1066efb7a*/
    RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v1); /*0x1066efb86*/
    RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v2); /*0x1066efbc2*/
    RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v1, a2: (void **)off_10C8C7EB0); /*0x1066efbd5*/
  }
}

// Address: 0x1066eff0c | Name: __ZN3RBX7Network6Client10disconnectENS_15ConnectionErrorE
__int64 __fastcall RBX::Network::Client::disconnect(RBX::Network::ConcurrentRakPeer **this, unsigned int a2)
{
  __int64 v3; // rax
  volatile signed __int64 *v4; // rcx
  _QWORD *v5; // r12
  _QWORD *v6; // r15
  __int64 v7; // r13
  __int64 v8; // r14
  __int64 v9; // rax
  std::__shared_weak_count *v10; // r14
  __int64 result; // rax
  RBX::Network::ConcurrentRakPeer *v12; // rdi
  __int64 v13; // r14
  __int64 v14; // rax
  RBX::RbxTransport::DummyService::DummyClient *v15; // rdi
  RBX::RbxTransport::DummyService::DummyClient **v16; // rbx
  RBX::RbxTransport::DummyService::DummyClient *v17; // r14
  __int64 v18; // rdx
  __int64 v19; // rcx
  void *v20; // rsi
  __int64 v21; // [rsp+10h] [rbp-B0h]
  volatile signed __int64 *v22; // [rsp+18h] [rbp-A8h]
  _QWORD v23[3]; // [rsp+20h] [rbp-A0h] BYREF
  _BYTE v24[16]; // [rsp+38h] [rbp-88h] BYREF
  void *v25; // [rsp+48h] [rbp-78h]
  __int64 v26; // [rsp+50h] [rbp-70h]
  std::__shared_weak_count *v27; // [rsp+58h] [rbp-68h]
  __int64 v28; // [rsp+60h] [rbp-60h] BYREF
  _QWORD *v29; // [rsp+68h] [rbp-58h]
  void *v30; // [rsp+78h] [rbp-48h]
  unsigned int v31; // [rsp+94h] [rbp-2Ch]

  v31 = a2; /*0x1066eff20*/
  if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 ) /*0x1066eff3a*/
  {
    v28 = 0; /*0x1066eff48*/
    v29 = v23; /*0x1066eff57*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x1066eff7b*/
      a1: (_DWORD)DFLog::NetworkClient,
      a2: qword_10D809380,
      a3: 4,
      a4: (unsigned int)"[DFLog::NetworkClient] Client:Disconnect",
      a5: 40,
      a6: 1,
      0,
      v23);
  }
  RBX::Network::Client::finalizeTraceRouteTelemetry((RBX::Network::Client *)this); /*0x1066eff83*/
  v3 = (__int64)*(this + 15); /*0x1066eff88*/
  if ( v3 != 0 ) /*0x1066eff8f*/
  {
    v21 = (__int64)*(this + 15); /*0x1066eff95*/
    v4 = (volatile signed __int64 *)*(this + 16); /*0x1066eff9c*/
    v22 = v4; /*0x1066effa3*/
    if ( v4 != nullptr ) /*0x1066effad*/
      _InterlockedIncrement64(v4 + 1); /*0x1066effaf*/
    v27 = (std::__shared_weak_count *)v4; /*0x1066effb4*/
    v5 = *(_QWORD **)v3; /*0x1066effb8*/
    v6 = *(_QWORD **)(v3 + 8); /*0x1066effbb*/
    if ( *(_QWORD **)v3 != v6 ) /*0x1066effc2*/
    {
      v26 = v31; /*0x1066effcb*/
      do /*0x1066f0095*/
      {
        v7 = *v5; /*0x1066effcf*/
        *(_BYTE *)(v7 + 170) &= 0x1Eu; /*0x1066effd3*/
        v8 = *(_QWORD *)(v7 + 24); /*0x1066effdb*/
        v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(); /*0x1066effdf*/
        if ( *(unsigned __int16 *)(v8 + 440) - (unsigned int)*(unsigned __int16 *)(v9 + 440) <= *(unsigned __int16 *)(v9 + 442) ) /*0x1066efffe*/
        {
          if ( (unsigned int)RBX::Network::Replicator::getDisconnectReason(this: (RBX::Network::Replicator *)v7) == 1 ) /*0x1066f000f*/
          {
            if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 ) /*0x1066f0025*/
            {
              v28 = 1; /*0x1066f003e*/
              v29 = v23; /*0x1066f004d*/
              FLog::detail::FastLogSafeFormattedInternal( /*0x1066f0071*/
                a1: (_DWORD)DFLog::NetworkClient,
                a2: qword_10D809380,
                a3: 4,
                a4: (unsigned int)"[DFLog::NetworkClient] Client:Disconnect setting replicator disconnect reason to {}",
                a5: 83,
                a6: 1,
                1,
                v23,
                v21,
                v22,
                v26);
            }
            RBX::Network::Replicator::safeSetDisconnectReason(this: (RBX::Network::Replicator *)v7, a2: v31); /*0x1066f007c*/
          }
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v5 + 280LL))(a1: *v5); /*0x1066f0088*/
        }
        v5 += 2; /*0x1066f008e*/
      }
      while ( v5 != v6 ); /*0x1066f0095*/
    }
    v10 = v27; /*0x1066f009b*/
    if ( v27 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v27 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f00b4*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x1066f00bc*/
      std::__shared_weak_count::__release_weak(this: v10); /*0x1066f00c2*/
    }
  }
  result = RBX::Instance::removeAllChildren((RBX::Instance *)this); /*0x1066f00ca*/
  v12 = *(this + 36); /*0x1066f00cf*/
  if ( v12 != nullptr ) /*0x1066f00d9*/
  {
    v13 = RBX::Network::ConcurrentRakPeer::rawPeer(this: v12); /*0x1066f00e0*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x1066f00f1*/
      this: (RakNet::AddressOrGUID *)&v28,
      a2: (const RakNet::SystemAddress *)(this + 63));
    (*(void (__fastcall **)(__int64, __int64 *, __int64, _QWORD, _QWORD, __int64))(*(_QWORD *)v13 + 256LL))( /*0x1066f010f*/
      a1: v13,
      a2: &v28,
      a3: 1,
      a4: 0,
      a5: 0,
      a6: 3);
    v14 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x1066f011c*/
    result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v14 + 120LL))(a1: v14); /*0x1066f0127*/
  }
  v15 = *(this + 583); /*0x1066f012a*/
  if ( v15 != nullptr ) /*0x1066f0134*/
  {
    v16 = this + 583; /*0x1066f0136*/
    RBX::RbxTransport::DummyService::DummyClient::stopPinging(this: v15); /*0x1066f013d*/
    v17 = *v16; /*0x1066f0142*/
    std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "", a3: v18, a4: v19); /*0x1066f0156*/
    RBX::Network::StateReason::StateReason(a1: &v28, a2: 256, a3: 285, a4: v24); /*0x1066f016c*/
    RBX::RbxTransport::DummyService::DummyClient::disconnect(this: v17, a2: (const RBX::Network::StateReason *)&v28); /*0x1066f0178*/
    if ( ((unsigned __int8)v29 & 1) != 0 ) /*0x1066f0181*/
      operator delete(a1: (RBX::Memory *)v30, a2: v20); /*0x1066f0187*/
    if ( (v24[0] & 1) != 0 ) /*0x1066f0193*/
      operator delete(a1: (RBX::Memory *)v25, a2: v20); /*0x1066f0199*/
    return std::unique_ptr<RBX::RbxTransport::DummyService::DummyClient>::reset[abi:ne200100](a1: v16, a2: 0); /*0x1066f01a3*/
  }
  return result; /*0x1066f01a8*/
}

// Address: 0x1066f022a | Name: __ZN3RBX7Network6Client16setGameSessionIDENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
int __fastcall RBX::Network::Client::setGameSessionID(RBX::DataModel *this, RBX::Instance *a2)
{
  unsigned int v4; // eax
  size_t v5; // rdx
  unsigned int v6; // ecx
  __int64 v7; // rsi
  char *v8; // rdi
  char *v9; // rsi
  RBX::DataModel *v10; // rax
  RBX::Instance *v11; // rsi

  v4 = *(unsigned __int8 *)a2; /*0x1066f0237*/
  if ( (v4 & 1) != 0 ) /*0x1066f023c*/
    v5 = *((_QWORD *)a2 + 1); /*0x1066f023e*/
  else
    v5 = v4 >> 1; /*0x1066f0246*/
  v6 = *((unsigned __int8 *)this + 4616); /*0x1066f0248*/
  if ( (v6 & 1) != 0 ) /*0x1066f0253*/
    v7 = *((_QWORD *)this + 578); /*0x1066f0255*/
  else
    v7 = v6 >> 1; /*0x1066f0260*/
  if ( v5 != v7
    || ((v4 & 1) == 0 ? (v8 = (char *)a2 + 1) : (v8 = *((char **)a2 + 2)),
        (v6 & 1) == 0 ? (v9 = (char *)this + 4617) : (v9 = *((char **)this + 579)),
        LODWORD(v10) = memcmp(__s1: v8, __s2: v9, __n: v5),
        (_DWORD)v10 != 0) )
  {
    std::string::operator=(a1: (char *)this + 4616, a2); /*0x1066f029d*/
    v10 = (RBX::DataModel *)RBX::DataModel::get(this, a2: v11); /*0x1066f02a5*/
    if ( v10 != nullptr ) /*0x1066f02ad*/
    {
      LODWORD(v10) = RBX::DataModel::getShouldSetGlobalTelemetryInfo(this: v10); /*0x1066f02b2*/
      if ( (_BYTE)v10 != 0 ) /*0x1066f02b9*/
        LODWORD(v10) = std::string::operator=(a1: &RBX::Http::gameSessionID, a2); /*0x1066f02c9*/
    }
  }
  return (int)v10; /*0x1066f02c5*/
}

// Address: 0x1066f02d4 | Name: __ZN3RBX7Network6Client16setPlaySessionIdERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
__int64 __fastcall RBX::Network::Client::setPlaySessionId(__int64 a1, __int64 a2)
{
  return std::string::operator=(a1: a1 + 568, a2); /*0x1066f02df*/
}

// Address: 0x1066f02e6 | Name: __ZN3RBX7Network6Client26configureAsCloudEditClientEv
__int64 __fastcall RBX::Network::Client::configureAsCloudEditClient(RBX::Network::Client *this, RBX::Instance *a2)
{
  RBX::DataModel *v3; // rax

  v3 = (RBX::DataModel *)RBX::DataModel::get(this, a2); /*0x1066f02ef*/
  if ( v3 != nullptr ) /*0x1066f02f7*/
    RBX::DataModel::setCloudEdit(this: v3); /*0x1066f02fc*/
  *((_DWORD *)this + 1236) = 2; /*0x1066f0301*/
  return RBX::Network::MegaReplicator::setIsCloudEdit(this: (RBX::Network::Client *)((char *)this + 696)); /*0x1066f0319*/
}

// Address: 0x1066f0320 | Name: __ZN3RBX7Network6Client26configureAsCloudTestClientEv
__int64 __fastcall RBX::Network::Client::configureAsCloudTestClient(RBX::Network::Client *this, RBX::Instance *a2)
{
  __int64 result; // rax

  result = RBX::DataModel::get(this, a2); /*0x1066f0329*/
  if ( result != 0 ) /*0x1066f0331*/
    *(_DWORD *)(result + 2264) = 2; /*0x1066f0333*/
  *((_DWORD *)this + 1236) = 1; /*0x1066f033d*/
  return result; /*0x1066f034b*/
}

// Address: 0x1066f034e | Name: __ZN3RBX7Network6Client17getMegaReplicatorEv
__int64 __fastcall RBX::Network::Client::getMegaReplicator(RBX::Network::Client *this)
{
  return (__int64)this + 696; /*0x1066f0359*/
}

// Address: 0x1066f035c | Name: __ZN3RBX7Network6Client19setClientReplicatorEPNS0_16ClientReplicatorE
char *__fastcall RBX::Network::Client::setClientReplicator(
        RBX::Network::Client *this,
        RBX::Network::ClientReplicator *a2)
{
  unsigned int v4; // esi
  unsigned __int64 v5; // rsi
  volatile signed __int32 *v6; // r13
  __int64 v7; // rax
  __int64 v8; // rax
  rbx::signals::slots_holder *v9; // rdi
  unsigned int v10; // esi
  void *v11; // rdi
  __int64 v12; // rax
  __int64 v13; // r15
  __int64 v14; // rax
  __int64 v15; // rcx
  __int64 v16; // rdx
  char *result; // rax
  __m128i v18; // [rsp+0h] [rbp-60h] BYREF
  __m128i v19; // [rsp+10h] [rbp-50h] BYREF
  void *v20; // [rsp+28h] [rbp-38h]
  RBX::Memory *v21; // [rsp+34h] [rbp-2Ch]

  *((_QWORD *)this + 574) = a2; /*0x1066f0373*/
  if ( a2 != nullptr && FFlag::NetworkTestControlProvider != 0 && *((_DWORD *)this + 1236) != 2 ) /*0x1066f0398*/
  {
    RBX::weak_from<RBX::Network::Client>(a1: &v18, a2: (__int64)this); /*0x1066f03a8*/
    v19 = v18; /*0x1066f03b1*/
    v18 = 0; /*0x1066f03b8*/
    LODWORD(v21) = RBX::Memory::setCurrentCategory( /*0x1066f03ca*/
                     this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal,
                     a2: v4);
    rbx::lazyInitSlotsHolder(a1: (char *)a2 + 24432); /*0x1066f03d7*/
    v6 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x40, a2: v5); /*0x1066f03f2*/
    *(_QWORD *)v6 = &_mh_execute_header; /*0x1066f03ff*/
    *((_QWORD *)v6 + 1) = rbx::signals::slot_with_functor<RBX::Network::Client::setClientReplicator(RBX::Network::ClientReplicator *)::$_0>::do_call; /*0x1066f040a*/
    *((_OWORD *)v6 + 1) = 0; /*0x1066f0412*/
    v7 = *((_QWORD *)a2 + 3054); /*0x1066f0418*/
    *((_QWORD *)v6 + 4) = v7; /*0x1066f041b*/
    if ( v7 != 0 ) /*0x1066f0422*/
    {
      _InterlockedIncrement((volatile signed __int32 *)(v7 + 4)); /*0x1066f0424*/
      v8 = *((_QWORD *)v6 + 3) | 4LL; /*0x1066f042c*/
      v9 = *((rbx::signals::slots_holder **)a2 + 3054); /*0x1066f0430*/
    }
    else
    {
      v8 = 4; /*0x1066f0435*/
      v9 = nullptr; /*0x1066f043a*/
    }
    *((_QWORD *)v6 + 3) = v8; /*0x1066f043c*/
    *((_QWORD *)v6 + 5) = rbx::signals::slot_with_functor<RBX::Network::Client::setClientReplicator(RBX::Network::ClientReplicator *)::$_0>::do_dtor; /*0x1066f0447*/
    *((__m128i *)v6 + 3) = _mm_load_si128(&v19); /*0x1066f0450*/
    rbx::signals::slots_holder::insert(this: v9, a2: (unsigned __int64)v6); /*0x1066f045c*/
    v20 = (void *)v6; /*0x1066f0461*/
    _InterlockedIncrement(v6 + 1); /*0x1066f0465*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)v21, a2: v10); /*0x1066f046d*/
    rbx::signals::scoped_connection::operator=(this: (RBX::Network::Client *)((char *)this + 5144)); /*0x1066f047d*/
    v11 = v20; /*0x1066f0482*/
    if ( v20 != nullptr && _InterlockedDecrement((volatile signed __int32 *)v20 + 1) == 0 ) /*0x1066f048f*/
      rbx::signals::slot_base::operator delete(a1: v11); /*0x1066f0491*/
    if ( v18.i64[1] != 0 ) /*0x1066f049d*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v18.i64[1]); /*0x1066f049f*/
  }
  v12 = RBX::DataModel::get(this, a2); /*0x1066f04a7*/
  if ( v12 != 0 ) /*0x1066f04af*/
  {
    v13 = v12; /*0x1066f04b1*/
    if ( FFlag::NetAssetClonePendingFix == 1 ) /*0x1066f04be*/
    {
      v14 = RBX::EngineContext::getModule<RBX::Network::NetAssetManagerEngineModule>(a1: *(_QWORD *)(v12 + 552) & 0xFFFFFFFFFFFFFFF8LL); /*0x1066f04cb*/
      v15 = *((_QWORD *)this + 574); /*0x1066f04d0*/
      v16 = v15 + 216; /*0x1066f04d7*/
      if ( v15 == 0 ) /*0x1066f04e1*/
        v16 = 0; /*0x1066f04e1*/
      *(_QWORD *)(v14 + 16) = v16; /*0x1066f04e5*/
    }
    RBX::DataModel::setClientState(a1: v13, a2: 1 - ((unsigned int)(a2 == nullptr) - 1)); /*0x1066f04f8*/
  }
  result = &DFFlag::EnableTraceRouteService; /*0x1066f04fd*/
  if ( DFFlag::EnableTraceRouteService == 1 ) /*0x1066f0507*/
  {
    result = &DFFlag::EnableTraceRouteSessionSummaryStats; /*0x1066f0509*/
    if ( DFFlag::EnableTraceRouteSessionSummaryStats == 1 ) /*0x1066f0513*/
    {
      result = (char *)RBX::ServiceProvider::find<RBX::TraceRouteService>(a1: this); /*0x1066f0518*/
      if ( result != nullptr ) /*0x1066f0520*/
      {
        if ( a2 != nullptr ) /*0x1066f0525*/
          return (char *)RBX::TraceRouteService::connectToReplicator(a1: (unsigned __int64)result); /*0x1066f053b*/
        else
          return (char *)RBX::TraceRouteService::disconnectFromReplicator(this: (RBX::TraceRouteService *)result); /*0x1066f0545*/
      }
    }
  }
  return result; /*0x1066f054a*/
}

// Address: 0x1066f067c | Name: __ZN3RBX7Network6Client34registerNetworkTestControlProviderEv
__int64 __fastcall RBX::Network::Client::registerNetworkTestControlProvider(RBX::Network::Client *this)
{
  __int64 v2; // rax
  __int64 v3; // rbx
  __int64 v4; // rdx
  __int64 v5; // rcx
  unsigned __int64 v6; // rsi
  __int64 v7; // r15
  std::__shared_weak_count *v8; // r12
  __int64 v9; // rax
  __int64 v10; // r15
  __int64 v11; // rax
  __int64 v12; // rbx
  __int64 v13; // rax
  void *v14; // rsi
  __int64 v15; // rdi
  _BYTE v17[16]; // [rsp+8h] [rbp-C8h] BYREF
  void *v18; // [rsp+18h] [rbp-B8h]
  __int64 v19; // [rsp+20h] [rbp-B0h] BYREF
  std::__shared_weak_count *v20; // [rsp+28h] [rbp-A8h]
  __int64 v21; // [rsp+30h] [rbp-A0h]
  __int64 v22; // [rsp+38h] [rbp-98h]
  _QWORD v23[4]; // [rsp+40h] [rbp-90h] BYREF
  _QWORD *v24; // [rsp+60h] [rbp-70h]
  _QWORD v25[4]; // [rsp+70h] [rbp-60h] BYREF
  _QWORD *v26; // [rsp+90h] [rbp-40h]

  v2 = RBX::ServiceProvider::find<RBX::TestService>(); /*0x1066f06a1*/
  if ( v2 == 0 ) /*0x1066f06a9*/
    return __stack_chk_guard; /*0x1066f06a9*/
  v3 = v2; /*0x1066f06af*/
  RBX::weak_from<RBX::Network::Client>(a1: &v19, a2: (__int64)this); /*0x1066f06bc*/
  std::string::basic_string[abi:ne200100]<0>(a1: v17, a2: "Network", a3: v4, a4: v5); /*0x1066f06cf*/
  v7 = v19; /*0x1066f06d4*/
  v8 = v20; /*0x1066f06db*/
  if ( v20 != nullptr ) /*0x1066f06e5*/
  {
    _InterlockedIncrement64((volatile signed __int64 *)v20 + 2); /*0x1066f06e7*/
    _InterlockedIncrement64((volatile signed __int64 *)v8 + 2); /*0x1066f06ed*/
  }
  v21 = v3; /*0x1066f06f3*/
  v9 = operator new(a1: (RBX::Memory *)0xA0, a2: v6); /*0x1066f06ff*/
  v25[0] = &off_10CAA7908; /*0x1066f070f*/
  v25[1] = v7; /*0x1066f0713*/
  v25[2] = v8; /*0x1066f0717*/
  v26 = v25; /*0x1066f071f*/
  v23[0] = &off_10CAA7998; /*0x1066f0731*/
  v23[1] = v7; /*0x1066f0734*/
  v23[2] = v8; /*0x1066f0738*/
  v24 = v23; /*0x1066f073c*/
  v10 = v9; /*0x1066f0740*/
  RBX::NetworkTestControlProvider::NetworkTestControlProvider(a1: v9, a2: v25, a3: v23); /*0x1066f074c*/
  if ( v24 == v23 ) /*0x1066f0758*/
  {
    v11 = 32; /*0x1066f076d*/
    v12 = v21; /*0x1066f0772*/
    goto LABEL_8; /*0x1066f0772*/
  }
  v11 = 40; /*0x1066f075a*/
  v12 = v21; /*0x1066f0762*/
  if ( v24 != nullptr ) /*0x1066f0769*/
LABEL_8:
    (*(void (**)(void))(*v24 + v11))(); /*0x1066f0779*/
  if ( v26 == v25 ) /*0x1066f0786*/
  {
    v13 = 32; /*0x1066f0794*/
  }
  else
  {
    v13 = 40; /*0x1066f0788*/
    if ( v26 == nullptr ) /*0x1066f0790*/
      goto LABEL_14; /*0x1066f0790*/
  }
  (*(void (**)(void))(*v26 + v13))(); /*0x1066f079c*/
LABEL_14:
  v22 = v10; /*0x1066f079f*/
  RBX::TestService::registerTestControlProvider(a1: v12, a2: v17); /*0x1066f07b3*/
  v15 = v22; /*0x1066f07b8*/
  v22 = 0; /*0x1066f07bf*/
  if ( v15 != 0 ) /*0x1066f07cd*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 8LL))(a1: v15); /*0x1066f07d2*/
  if ( (v17[0] & 1) != 0 ) /*0x1066f07dc*/
    operator delete(a1: (RBX::Memory *)v18, a2: v14); /*0x1066f07e5*/
  if ( v20 != nullptr ) /*0x1066f07f4*/
    std::__shared_weak_count::__release_weak(this: v20); /*0x1066f07f6*/
  return __stack_chk_guard; /*0x1066f080b*/
}

// Address: 0x1066f08ca | Name: __ZN3RBX7Network6Client17onServiceProviderEPNS_15ServiceProviderES3_
__int64 __fastcall RBX::Network::Client::onServiceProvider(
        RBX::Network::Client *this,
        RBX::ServiceProvider *a2,
        RBX::ServiceProvider *a3)
{
  __int64 v6; // rdi
  RBX::Players **v7; // rax
  __int64 v8; // r12
  __int64 v9; // rax
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // r12
  void *v13; // rsi
  RBX::Network::Client *v14; // rsi
  unsigned __int64 v15; // rsi
  __int64 v16; // r15
  RBX::Network *v17; // rdi
  __int64 v18; // r13
  __int64 v19; // r12
  __int64 v20; // rdi
  __int64 v21; // rdi
  rbx::signals::slots_holder **v22; // r14
  unsigned int v23; // r15d
  unsigned int v24; // r12d
  unsigned __int64 v25; // rsi
  unsigned __int64 v26; // r13
  rbx::signals::slots_holder *v27; // rax
  unsigned __int64 v28; // rax
  unsigned int v30; // esi
  RBX::Instance *v31; // rsi
  std::__shared_weak_count *v32; // rdi
  __int64 v33; // rax
  RBX::Instance *v34; // rsi
  rbx::signals::slots_holder **v35; // r12
  unsigned int v36; // r14d
  unsigned __int64 v37; // rsi
  unsigned __int64 v38; // r15
  rbx::signals::slots_holder *v39; // rax
  unsigned __int64 v40; // rax
  unsigned int v41; // esi
  std::__shared_weak_count *v42; // rdi
  __int64 v43; // rax
  __int64 v44; // r14
  __int64 v45; // rax
  std::__shared_weak_count *v46; // r14
  std::__shared_weak_count *v47; // r14
  __int128 v48; // [rsp+0h] [rbp-60h] BYREF
  std::__shared_weak_count *v49[2]; // [rsp+10h] [rbp-50h] BYREF
  void *v50; // [rsp+20h] [rbp-40h]
  _BYTE v51[41]; // [rsp+37h] [rbp-29h] BYREF

  if ( a2 != nullptr ) /*0x1066f08e7*/
  {
    RBX::Network::ImGuiRegisterClient(this: nullptr, a2); /*0x1066f08ef*/
    rbx::signals::connection::disconnect(this: (RBX::Network::Client *)((char *)this + 480)); /*0x1066f08fb*/
    rbx::signals::connection::disconnect(this: (RBX::Network::Client *)((char *)this + 488)); /*0x1066f0907*/
    RBX::Network::Client::onClosing(this); /*0x1066f090f*/
    if ( FFlag::RemoveLegacyChatCodeInNetwork == 0 ) /*0x1066f091e*/
    {
      v7 = (RBX::Players **)RBX::ServiceProvider::refByClass<RBX::Players>(this: a2); /*0x1066f0923*/
      RBX::Players::endChatSenderConnection(this: *v7); /*0x1066f092b*/
    }
    v8 = *((_QWORD *)a2 + 3); /*0x1066f0930*/
    v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::DataModel>(a1: v6); /*0x1066f0934*/
    if ( *(unsigned __int16 *)(v8 + 440) - (unsigned int)*(unsigned __int16 *)(v9 + 440) <= *(unsigned __int16 *)(v9 + 442) ) /*0x1066f0954*/
    {
      RBX::DataModel::setClientState(a1: (char *)a2 - 464, a2: 0); /*0x1066f095f*/
      if ( FFlag::NetworkTestControlProvider == 1 ) /*0x1066f096b*/
      {
        v12 = *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::TestService>(this: a2); /*0x1066f0975*/
        if ( v12 != 0 ) /*0x1066f097b*/
        {
          std::string::basic_string[abi:ne200100]<0>(a1: v49, a2: "Network", a3: v10, a4: v11); /*0x1066f098b*/
          RBX::TestService::unregisterTestControlProvider(a1: v12, a2: v49); /*0x1066f0996*/
          if ( ((__int64)v49[0] & 1) != 0 ) /*0x1066f099f*/
            operator delete(a1: (RBX::Memory *)v50, a2: v13); /*0x1066f09a5*/
        }
      }
    }
  }
  RBX::Network::Peer::onServiceProvider(this, a2, a3); /*0x1066f09b3*/
  if ( a3 != nullptr ) /*0x1066f09be*/
  {
    RBX::Network::ImGuiRegisterClient(this, a2: v14); /*0x1066f09c4*/
    if ( FFlag::RemoveLegacyChatCodeInNetwork == 0 ) /*0x1066f09d3*/
    {
      v16 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::Players>(this: a3); /*0x1066f09e1*/
      if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v17) == 0 ) /*0x1066f09eb*/
      {
        v18 = *((_QWORD *)this + 36); /*0x1066f09f1*/
        v19 = operator new(a1: (RBX::Memory *)0x88, a2: v15); /*0x1066f0a02*/
        *(_QWORD *)v19 = &off_10CAA7128; /*0x1066f0a10*/
        *(_QWORD *)(v19 + 8) = v18; /*0x1066f0a14*/
        *(_OWORD *)(v19 + 16) = 0; /*0x1066f0a1c*/
        *(double *)(v19 + 32) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v20); /*0x1066f0a27*/
        *(_BYTE *)(v19 + 40) = 1; /*0x1066f0a30*/
        *(_QWORD *)(v19 + 48) = 0x3FA999999999999ALL; /*0x1066f0a3f*/
        *(_OWORD *)(v19 + 56) = 0; /*0x1066f0a47*/
        *(_QWORD *)(v19 + 72) = 0; /*0x1066f0a4f*/
        *(_BYTE *)(v19 + 80) = 1; /*0x1066f0a54*/
        *(_QWORD *)(v19 + 88) = 0; /*0x1066f0a59*/
        *(_QWORD *)(v19 + 96) = 0x3FA999999999999ALL; /*0x1066f0a5e*/
        *(_DWORD *)(v19 + 104) = 0; /*0x1066f0a63*/
        *(_OWORD *)(v19 + 112) = 0; /*0x1066f0a6c*/
        *(_BYTE *)(v19 + 128) = 1; /*0x1066f0a72*/
        v21 = *(_QWORD *)(v16 + 520); /*0x1066f0a7a*/
        *(_QWORD *)(v16 + 520) = v19; /*0x1066f0a81*/
        if ( v21 != 0 ) /*0x1066f0a8b*/
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v21 + 48LL))(a1: v21); /*0x1066f0a90*/
      }
    }
    v22 = (rbx::signals::slots_holder **)((char *)a3 + 224); /*0x1066f0a93*/
    v23 = (unsigned int)RBX::Memory::InstanceSignal; /*0x1066f0aa1*/
    v24 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v15); /*0x1066f0aac*/
    rbx::lazyInitSlotsHolder(a1: v22); /*0x1066f0ab2*/
    v26 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v25); /*0x1066f0ac1*/
    *(_QWORD *)v26 = &_mh_execute_header; /*0x1066f0ace*/
    *(_QWORD *)(v26 + 8) = rbx::signals::slot_with_functor<RBX::Network::Client::onServiceProvider(RBX::ServiceProvider *,RBX::ServiceProvider *)::$_0>::do_call; /*0x1066f0ad9*/
    *(_OWORD *)(v26 + 16) = 0; /*0x1066f0ae0*/
    v27 = *v22; /*0x1066f0ae5*/
    *(_QWORD *)(v26 + 32) = *v22; /*0x1066f0ae8*/
    if ( v27 != nullptr ) /*0x1066f0aef*/
    {
      _InterlockedIncrement((volatile signed __int32 *)v27 + 1); /*0x1066f0af1*/
      v28 = *(_QWORD *)(v26 + 24) & 0xFFFFFFFFFFFFFFFBLL; /*0x1066f0af9*/
    }
    else
    {
      v28 = 0; /*0x1066f0b18*/
    }
    *(_QWORD *)(v26 + 24) = v28; /*0x1066f0b1a*/
    *(_QWORD *)(v26 + 40) = this; /*0x1066f0b1e*/
    rbx::signals::slots_holder::insert(this: *v22, a2: v26); /*0x1066f0b28*/
    v49[0] = (std::__shared_weak_count *)v26; /*0x1066f0b2d*/
    _InterlockedIncrement((volatile signed __int32 *)(v26 + 4)); /*0x1066f0b31*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v24, a2: v30); /*0x1066f0b39*/
    rbx::signals::scoped_connection::operator=(this: (RBX::Network::Client *)((char *)this + 480)); /*0x1066f0b49*/
    v32 = v49[0]; /*0x1066f0b4e*/
    if ( v49[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v49[0] + 1) == 0 ) /*0x1066f0b5b*/
      rbx::signals::slot_base::operator delete(a1: v32); /*0x1066f0b5d*/
    v33 = RBX::DataModel::get(this, a2: v31); /*0x1066f0b65*/
    if ( v33 != 0 ) /*0x1066f0b6d*/
    {
      v35 = (rbx::signals::slots_holder **)(v33 + 1168); /*0x1066f0b76*/
      v36 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v23, a2: (unsigned int)v34); /*0x1066f0b85*/
      rbx::lazyInitSlotsHolder(a1: v35); /*0x1066f0b8b*/
      v38 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v37); /*0x1066f0b9a*/
      *(_QWORD *)v38 = &_mh_execute_header; /*0x1066f0ba7*/
      *(_QWORD *)(v38 + 8) = rbx::signals::slot_with_functor<RBX::Network::Client::onServiceProvider(RBX::ServiceProvider *,RBX::ServiceProvider *)::$_1>::do_call; /*0x1066f0bb1*/
      *(_OWORD *)(v38 + 16) = 0; /*0x1066f0bb8*/
      v39 = *v35; /*0x1066f0bbd*/
      *(_QWORD *)(v38 + 32) = *v35; /*0x1066f0bc1*/
      if ( v39 != nullptr ) /*0x1066f0bc8*/
      {
        _InterlockedIncrement((volatile signed __int32 *)v39 + 1); /*0x1066f0bca*/
        v40 = *(_QWORD *)(v38 + 24) & 0xFFFFFFFFFFFFFFFBLL; /*0x1066f0bd2*/
      }
      else
      {
        v40 = 0; /*0x1066f0bd8*/
      }
      *(_QWORD *)(v38 + 24) = v40; /*0x1066f0bda*/
      *(_QWORD *)(v38 + 40) = this; /*0x1066f0bde*/
      rbx::signals::slots_holder::insert(this: *v35, a2: v38); /*0x1066f0be9*/
      v49[0] = (std::__shared_weak_count *)v38; /*0x1066f0bee*/
      _InterlockedIncrement((volatile signed __int32 *)(v38 + 4)); /*0x1066f0bf2*/
      RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v36, a2: v41); /*0x1066f0bfa*/
      rbx::signals::scoped_connection::operator=(this: (RBX::Network::Client *)((char *)this + 488)); /*0x1066f0c0a*/
      v42 = v49[0]; /*0x1066f0c0f*/
      if ( v49[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v49[0] + 1) == 0 ) /*0x1066f0c1c*/
        rbx::signals::slot_base::operator delete(a1: v42); /*0x1066f0c1e*/
    }
    v43 = RBX::DataModel::get(this, a2: v34); /*0x1066f0c26*/
    if ( v43 != 0 ) /*0x1066f0c2e*/
    {
      v44 = v43; /*0x1066f0c34*/
      RBX::DataModel::setClientState(a1: v43, a2: 1); /*0x1066f0c3f*/
      if ( FFlag::LrPullSystem == 1 ) /*0x1066f0c4e*/
      {
        std::allocate_shared[abi:ne200100]<RBX::Network::LargeReplicatorPullManager,std::allocator<RBX::Network::LargeReplicatorPullManager>,RBX::DataModel &,0>( /*0x1066f0c5f*/
          a1: v49,
          a2: v51,
          a3: v44);
        v45 = RBX::EngineContext::getModule<RBX::Network::NetAssetManagerEngineModule>(a1: *(_QWORD *)(v44 + 552) & 0xFFFFFFFFFFFFFFF8LL); /*0x1066f0c6f*/
        v48 = *(_OWORD *)v49; /*0x1066f0c7c*/
        if ( v49[1] != nullptr ) /*0x1066f0c83*/
          _InterlockedIncrement64((volatile signed __int64 *)v49[1] + 1); /*0x1066f0c85*/
        std::shared_ptr<RBX::Network::PullManagerInterface>::operator=[abi:ne200100](a1: v45 + 24, a2: &v48); /*0x1066f0c98*/
        v46 = *((std::__shared_weak_count **)&v48 + 1); /*0x1066f0c9d*/
        if ( *((_QWORD *)&v48 + 1) != 0 /*0x1066f0cb6*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v48 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v46 + 16LL))(a1: v46); /*0x1066f0cbe*/
          std::__shared_weak_count::__release_weak(this: v46); /*0x1066f0cc4*/
        }
        RBX::Network::MegaReplicator::setLargeReplicatorPullManager(a1: (char *)this + 696, a2: v49); /*0x1066f0cd4*/
        v47 = v49[1]; /*0x1066f0cd9*/
        if ( v49[1] != nullptr /*0x1066f0cf2*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v49[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v47 + 16LL))(a1: v47); /*0x1066f0cfa*/
          std::__shared_weak_count::__release_weak(this: v47); /*0x1066f0d00*/
        }
      }
    }
    return RBX::Network::Client::reportGameBasicSettings(this); /*0x1066f0d08*/
  }
  else
  {
    RBX::Network::Client::stopTraceRouteTelemetry(this); /*0x1066f0aff*/
    return rbx::signals::connection::disconnect(this: (RBX::Network::Client *)((char *)this + 5144)); /*0x1066f0b0e*/
  }
}

// Address: 0x1066f0d94 | Name: __ZN3RBX7Network6Client9onClosingEv
__int64 __fastcall RBX::Network::Client::onClosing(RBX::Network::Client *this, __int64 a2, __int64 a3, __int64 a4)
{
  RBX::Network::Replicator *v5; // rdi
  unsigned __int64 v6; // rax
  const char *v7; // rsi
  char *v8; // rcx
  void *v9; // rsi
  char v11; // [rsp+8h] [rbp-38h] BYREF
  char v12; // [rsp+9h] [rbp-37h] BYREF
  void *v13; // [rsp+18h] [rbp-28h]
  char v14; // [rsp+20h] [rbp-20h] BYREF
  char v15; // [rsp+21h] [rbp-1Fh] BYREF
  void *v16; // [rsp+30h] [rbp-10h]

  v5 = *((RBX::Network::Replicator **)this + 574); /*0x1066f0da0*/
  if ( v5 != nullptr ) /*0x1066f0daa*/
    RBX::Network::Replicator::safeSetDisconnectReason(this: v5, a2: 0x11Du); /*0x1066f0db1*/
  if ( *((_BYTE *)this + 602) == 0 ) /*0x1066f0dbd*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v14, a2: "OtherDisconnect", a3, a4); /*0x1066f0dce*/
    RBX::Network::Client::getConnectedServer(this: (RBX::Network::Client *)&v11); /*0x1066f0dda*/
    v6 = *((unsigned int *)this + 158); /*0x1066f0ddf*/
    if ( v6 > 3 ) /*0x1066f0de9*/
      std::string::append(a1: &v14, a2: ""); /*0x1066f0e03*/
    else
      std::string::append(a1: &v14, a2: off_10CAA7E78[v6]); /*0x1066f0df6*/
    if ( (v14 & 1) != 0 ) /*0x1066f0e0c*/
      v7 = (const char *)v16; /*0x1066f0e0e*/
    else
      v7 = &v15; /*0x1066f0e14*/
    if ( (v11 & 1) != 0 ) /*0x1066f0e1c*/
      v8 = (char *)v13; /*0x1066f0e1e*/
    else
      v8 = &v12; /*0x1066f0e24*/
    RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066f0e3c*/
      (RBX::Network::ConcurrentRakPeer **)this,
      a2: v7,
      a3: 1u,
      a4: v8,
      a5: 4,
      a6: 1);
    if ( (v11 & 1) != 0 ) /*0x1066f0e45*/
      operator delete(a1: (RBX::Memory *)v13, a2: v9); /*0x1066f0e4b*/
    if ( (v14 & 1) != 0 ) /*0x1066f0e54*/
      operator delete(a1: (RBX::Memory *)v16, a2: v9); /*0x1066f0e5a*/
  }
  return RBX::Network::Client::disconnect((RBX::Network::ConcurrentRakPeer **)this, a2: 0x11Du); /*0x1066f0e6c*/
}

// Address: 0x1066f0ea2 | Name: __ZN3RBX7Network6Client16sendExtAntiCheatENSt3__18weak_ptrINS_9DataModelEEERKNS2_6vectorIhNS2_9allocatorIhEEEEj
__int64 __fastcall RBX::Network::Client::sendExtAntiCheat(__int64 *a1, _QWORD *a2, unsigned int a3)
{
  std::__shared_weak_count *v4; // rdi
  volatile signed __int64 *v7; // rax
  volatile signed __int64 *v8; // rbx
  __int64 v9; // r14
  unsigned __int64 v10; // rsi
  __int64 v11; // r15
  void *v12; // rsi
  __int64 v13; // rax
  void *v15[3]; // [rsp+10h] [rbp-80h] BYREF
  unsigned int v16; // [rsp+28h] [rbp-68h]
  _BYTE v17[32]; // [rsp+30h] [rbp-60h] BYREF
  _BYTE *v18; // [rsp+50h] [rbp-40h]

  v4 = (std::__shared_weak_count *)a1[1]; /*0x1066f0ec2*/
  if ( v4 == nullptr ) /*0x1066f0ec9*/
    return __stack_chk_guard; /*0x1066f0ec9*/
  v7 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v4); /*0x1066f0ed5*/
  if ( v7 == nullptr ) /*0x1066f0ee4*/
    return __stack_chk_guard; /*0x1066f0ee4*/
  v8 = v7; /*0x1066f0eea*/
  v9 = *a1; /*0x1066f0eed*/
  if ( v9 != 0 ) /*0x1066f0efa*/
  {
    memset(v15, 0, sizeof(v15)); /*0x1066f0f07*/
    std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1066f0f21*/
      a1: v15,
      a2: *a2,
      a3: a2[1],
      a4: a2[1] - *a2);
    v16 = a3; /*0x1066f0f26*/
    v18 = nullptr; /*0x1066f0f2a*/
    v11 = operator new(a1: (RBX::Memory *)0x28, a2: v10); /*0x1066f0f3c*/
    *(_QWORD *)v11 = &off_10CAA7A68; /*0x1066f0f46*/
    *(_OWORD *)(v11 + 8) = 0; /*0x1066f0f53*/
    *(_QWORD *)(v11 + 24) = 0; /*0x1066f0f58*/
    std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1066f0f6e*/
      a1: v11 + 8,
      a2: v15[0],
      a3: v15[1],
      a4: (char *)v15[1] - (char *)v15[0]);
    *(_QWORD *)(v11 + 32) = v16; /*0x1066f0f76*/
    v18 = (_BYTE *)v11; /*0x1066f0f86*/
    RBX::DataModel::submitTask(a1: v9, a2: v17, a3: 1); /*0x1066f0f96*/
    if ( v18 == v17 ) /*0x1066f0fa2*/
    {
      v13 = 32; /*0x1066f0fb0*/
    }
    else
    {
      v13 = 40; /*0x1066f0fa4*/
      if ( v18 == nullptr ) /*0x1066f0fac*/
      {
LABEL_9:
        if ( v15[0] != nullptr ) /*0x1066f0fc2*/
        {
          v15[1] = v15[0]; /*0x1066f0fc4*/
          operator delete(a1: (RBX::Memory *)v15[0], a2: v12); /*0x1066f0fc8*/
        }
        goto LABEL_11; /*0x1066f0fc8*/
      }
    }
    (*(void (__fastcall **)(_BYTE *, void *))(*(_QWORD *)v18 + v13))(a1: v18, a2: v12); /*0x1066f0fb8*/
    goto LABEL_9; /*0x1066f0fb8*/
  }
LABEL_11:
  if ( _InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f0fdd*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v8 + 16))(a1: v8); /*0x1066f0fe5*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v8); /*0x1066f0feb*/
  }
  return __stack_chk_guard; /*0x1066f1000*/
}

// Address: 0x1066f1070 | Name: __ZN3RBX7Network6Client16sendExtAntiCheatERKNSt3__16vectorIhNS2_9allocatorIhEEEEj
__int64 __fastcall RBX::Network::Client::sendExtAntiCheat(_QWORD *a1, int a2, int a3, int a4, int a5, int a6)
{
  return RBX::Network::Peer::sendExtAntiCheatHelper((_DWORD)a1, a2, a3, a4, a5, a6, a1[63], a1[64], a1[65], a1[66]); /*0x1066f1094*/
}

// Address: 0x1066f109a | Name: __ZN3RBX7Network6Client20handleExtAntiCheatV2ERNS0_14IncomingPacketE
void __fastcall RBX::Network::Client::handleExtAntiCheatV2(
        RBX::Network::Client *this,
        RBX::Network::IncomingPacket *a2)
{
  void *v3; // rsi
  int v4; // [rsp+Ch] [rbp-34h] BYREF
  void *v5[4]; // [rsp+10h] [rbp-30h] BYREF
  _BYTE v6[9]; // [rsp+37h] [rbp-9h] BYREF

  memset(v5, 0, 24); /*0x1066f10ad*/
  RBX::Network::Peer::recvExtAntiCheatHelperV2(a1: this, a2, a3: v6, a4: &v4, a5: v5); /*0x1066f10c1*/
  if ( v6[0] == 0 ) /*0x1066f10ca*/
  {
    rbx::signal<void ()(std::vector<unsigned char> const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x1066f10da*/
      a1: (char *)this + 4840,
      a2: v5);
    if ( RBX::clientExtAntiCheatSignal != 0 ) /*0x1066f10ec*/
      rbx::signal<void ()(std::vector<unsigned char> const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x1066f10f2*/
        a1: RBX::clientExtAntiCheatSignal,
        a2: v5);
  }
  if ( v5[0] != nullptr ) /*0x1066f10fe*/
  {
    v5[1] = v5[0]; /*0x1066f1100*/
    operator delete(a1: (RBX::Memory *)v5[0], a2: v3); /*0x1066f1104*/
  }
}

// Address: 0x1066f1134 | Name: __ZN3RBX7Network6Client29handleExtAntiCheat_deprecatedEPN6RakNet6PacketE
void __fastcall RBX::Network::Client::handleExtAntiCheat_deprecated(__int64 a1, __int64 a2)
{
  void *v3; // rsi
  int v4; // [rsp+Ch] [rbp-34h] BYREF
  void *v5[4]; // [rsp+10h] [rbp-30h] BYREF
  _BYTE v6[9]; // [rsp+37h] [rbp-9h] BYREF

  memset(v5, 0, 24); /*0x1066f1147*/
  RBX::Network::Peer::recvExtAntiCheatHelper_deprecated(a1, a2, a3: v6, a4: &v4, a5: v5); /*0x1066f115b*/
  if ( v6[0] == 0 ) /*0x1066f1164*/
  {
    rbx::signal<void ()(std::vector<unsigned char> const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x1066f1174*/
      a1: a1 + 4840,
      a2: v5);
    if ( RBX::clientExtAntiCheatSignal != 0 ) /*0x1066f1186*/
      rbx::signal<void ()(std::vector<unsigned char> const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x1066f118c*/
        a1: RBX::clientExtAntiCheatSignal,
        a2: v5);
  }
  if ( v5[0] != nullptr ) /*0x1066f1198*/
  {
    v5[1] = v5[0]; /*0x1066f119a*/
    operator delete(a1: (RBX::Memory *)v5[0], a2: v3); /*0x1066f119e*/
  }
}

// Address: 0x1066f11c8 | Name: __ZN3RBX7Network6Client15sendVersionInfoEv
void __fastcall RBX::Network::Client::sendVersionInfo(RBX::Network::Client *this)
{
  __int64 v2; // rax
  _QWORD *v3; // rcx
  __int64 v4; // rax
  _QWORD *v5; // rcx
  FLog *v6; // rdi
  __int64 v7; // rax
  __int64 v8; // rdx
  __int64 v9; // r8
  __int64 v10; // r9
  __int64 v11; // rax
  __int64 v12; // r8
  __int64 v13; // r9
  RBX::Security *v14; // rdi
  RBX::Security *v15; // rdi
  FLog *v16; // rdi
  __int64 v17; // rax
  __int64 v18; // rdx
  __int64 v19; // rsi
  __int64 v20; // r8
  __int64 v21; // r9
  int v22; // esi
  RBX::Network *v23; // rdi
  void *v24; // rsi
  unsigned __int64 v25; // rsi
  volatile signed __int64 *v26; // r14
  __int64 v27; // rax
  __int64 *v28; // rcx
  __int64 v29; // rdi
  std::__shared_weak_count *v30; // r14
  std::__shared_weak_count *v31; // r14
  __int64 v32; // r14
  volatile signed __int64 *v33; // [rsp+28h] [rbp-98h] BYREF
  std::__shared_weak_count *v34; // [rsp+30h] [rbp-90h]
  _BYTE v35[16]; // [rsp+38h] [rbp-88h] BYREF
  char *v36; // [rsp+48h] [rbp-78h]
  unsigned int v37; // [rsp+68h] [rbp-58h]
  std::__shared_weak_count *v38[9]; // [rsp+78h] [rbp-48h] BYREF

  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v35); /*0x1066f11e5*/
  LOBYTE(v38[0]) = -112; /*0x1066f11ee*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 1u); /*0x1066f11f9*/
  LOBYTE(v38[0]) = 1; /*0x1066f1202*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 1u); /*0x1066f1211*/
  LODWORD(v38[0]) = *((_DWORD *)this + 84); /*0x1066f1220*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 4u); /*0x1066f122e*/
  if ( (unsigned __int8)RBX::Network::Client::usingRbxTransport(this) == 0 ) /*0x1066f123d*/
  {
    v7 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x1066f12ba*/
    if ( (*(unsigned __int8 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v7 + 696LL))( /*0x1066f12ec*/
           a1: v7,
           a2: 0x100000,
           a3: v8,
           a4: *(_QWORD *)(*(_QWORD *)v7 + 696LL),
           a5: v9,
           a6: v10,
           a7: *((_QWORD *)this + 63),
           a8: *((_QWORD *)this + 64),
           a9: *((_QWORD *)this + 65),
           a10: *((_QWORD *)this + 66)) == 0 )
    {
      v11 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x1066f135c*/
      if ( (*(unsigned __int8 (__fastcall **)(__int64, __int64, _QWORD, char *, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v11 + 696LL))( /*0x1066f138e*/
             a1: v11,
             a2: 2048,
             a3: *(_QWORD *)(*(_QWORD *)v11 + 696LL),
             a4: (char *)this + 504,
             a5: v12,
             a6: v13,
             a7: *((_QWORD *)this + 63),
             a8: *((_QWORD *)this + 64),
             a9: *((_QWORD *)this + 65),
             a10: *((_QWORD *)this + 66)) == 0 )
        goto LABEL_14; /*0x1066f138e*/
      goto LABEL_13; /*0x1066f138e*/
    }
LABEL_10:
    LOBYTE(v38[0]) = 3; /*0x1066f12ee*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 1u); /*0x1066f1301*/
    LOBYTE(v38[0]) = 14; /*0x1066f130a*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 1u); /*0x1066f1319*/
    goto LABEL_14; /*0x1066f131e*/
  }
  v2 = *((_QWORD *)this + 574); /*0x1066f123f*/
  v3 = (_QWORD *)(v2 + 280); /*0x1066f1246*/
  if ( v2 == 0 ) /*0x1066f1257*/
    v3 = (_QWORD *)((char *)this + 4600); /*0x1066f1257*/
  if ( ((*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 56LL))(a1: *v3) & 0x100000) != 0 ) /*0x1066f1268*/
    goto LABEL_10; /*0x1066f1268*/
  v4 = *((_QWORD *)this + 574); /*0x1066f126e*/
  v5 = (_QWORD *)(v4 + 280); /*0x1066f1275*/
  if ( v4 == 0 ) /*0x1066f127f*/
    v5 = (_QWORD *)((char *)this + 4600); /*0x1066f127f*/
  if ( ((*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v5 + 56LL))(a1: *v5) & 0x800) != 0 ) /*0x1066f1290*/
  {
LABEL_13:
    LOBYTE(v38[0]) = 3; /*0x1066f1390*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 1u); /*0x1066f13a3*/
  }
LABEL_14:
  LOWORD(v38[0]) = FLog::GetNumSynchronizedVariable(this: v6); /*0x1066f13a8*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 2u); /*0x1066f13c0*/
  if ( FFlag::UniverseFilters == 1 ) /*0x1066f13cf*/
    FLog::ForEachVariable( /*0x1066f13e4*/
      a1: (void (__fastcall *)(__int64, __int64, __int64, __int64, __int64, __int64))clientSFFlagVisitor,
      a2: (__int64)v35,
      a3: 4);
  else
    FLog::DEPRECATED_ForEachVariable( /*0x1066f13fe*/
      a1: (void (__fastcall *)(__int64, __int64, __int64, __int64, __int64))DEPRECATED_clientSFFlagVisitor,
      a2: (__int64)v35,
      a3: 4);
  RBX::Network::serializeString(a1: (char *)this + 672, a2: v35, a3: (unsigned int)DFInt::CliMaxPayloadSnd); /*0x1066f1417*/
  LODWORD(v38[0]) = -1585457290; /*0x1066f142a*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 4u); /*0x1066f1439*/
  LODWORD(v38[0]) = -640017005; /*0x1066f1469*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 4u); /*0x1066f1477*/
  LODWORD(v38[0]) = RBX::Security::getPlatformKey(this: v14); /*0x1066f14a3*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 4u); /*0x1066f14b1*/
  LODWORD(v38[0]) = RBX::Security::getChecksumKey2(this: v15); /*0x1066f14dd*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 4u); /*0x1066f14eb*/
  LODWORD(v38[0]) = -1672856842; /*0x1066f151e*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v35, a2: v38, a3: 4u); /*0x1066f152c*/
  if ( DFFlag::ReportLuauConnIssue == 1 ) /*0x1066f153c*/
  {
    *((_WORD *)this + 2464) = 3587; /*0x1066f153e*/
    *((_WORD *)this + 2465) = FLog::GetNumSynchronizedVariable(this: v16); /*0x1066f154c*/
    *((_QWORD *)this + 612) = v37; /*0x1066f1556*/
    v17 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x1066f1564*/
    *((_QWORD *)this + 615) = (*(__int64 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v17 + 688LL))( /*0x1066f158f*/
                                a1: v17,
                                a2: v19,
                                a3: v18,
                                a4: *(_QWORD *)(*(_QWORD *)v17 + 688LL),
                                a5: v20,
                                a6: v21,
                                a7: *((_QWORD *)this + 63),
                                a8: *((_QWORD *)this + 64),
                                a9: *((_QWORD *)this + 65),
                                a10: *((_QWORD *)this + 66));
    v22 = 100; /*0x1066f15a0*/
    if ( v37 < 0x64 ) /*0x1066f15a5*/
      v22 = v37; /*0x1066f15a5*/
    *((_DWORD *)this + 1228) = XXH32(a1: v36, a2: v22, a3: 1u); /*0x1066f15b2*/
  }
  if ( (unsigned __int8)RBX::Network::Client::usingRbxTransport(this) == 0 ) /*0x1066f15c2*/
    RBX::Network::Peer::encryptDataPart(this, a2: (RBX::Network::NetworkStream *)v35); /*0x1066f15ce*/
  if ( DFFlag::ReportLuauConnIssue == 1 ) /*0x1066f15d7*/
  {
    *((_DWORD *)this + 1229) = XXH32(a1: v36, a2: v37, a3: 1u); /*0x1066f15ea*/
    *((_QWORD *)this + 613) = v37; /*0x1066f15f3*/
    RBX::ContextInfoManager::getAttribute(a1: v38, a2: 5); /*0x1066f1603*/
    if ( (*((_BYTE *)this + 4872) & 1) != 0 ) /*0x1066f1616*/
      operator delete(a1: *((RBX::Memory **)this + 611), a2: v24); /*0x1066f161f*/
    qmemcpy((char *)this + 4872, v38, 24); /*0x1066f1628*/
  }
  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v23) != 0 ) /*0x1066f163b*/
  {
    v26 = (volatile signed __int64 *)operator new(a1: (RBX::Memory *)0x58, a2: v25); /*0x1066f164b*/
    *(_OWORD *)(v26 + 1) = 0; /*0x1066f1651*/
    *v26 = (volatile signed __int64)&off_10CAAE190; /*0x1066f165c*/
    RBX::Network::NetworkStream::NetworkStream(a1: v26 + 3, a2: v35); /*0x1066f1670*/
    v38[0] = (std::__shared_weak_count *)(v26 + 3); /*0x1066f1675*/
    v38[1] = (std::__shared_weak_count *)v26; /*0x1066f1679*/
    v27 = *((_QWORD *)this + 574); /*0x1066f167d*/
    v28 = (__int64 *)(v27 + 280); /*0x1066f1684*/
    if ( v27 == 0 ) /*0x1066f1695*/
      v28 = (__int64 *)((char *)this + 4600); /*0x1066f1695*/
    v29 = *v28; /*0x1066f1699*/
    v33 = v26 + 3; /*0x1066f16a3*/
    v34 = (std::__shared_weak_count *)v26; /*0x1066f16a6*/
    _InterlockedIncrement64(v26 + 1); /*0x1066f16aa*/
    (*(void (__fastcall **)(__int64, __int64, volatile signed __int64 **, _QWORD, _QWORD))(*(_QWORD *)v29 + 48LL))( /*0x1066f16bc*/
      a1: v29,
      a2: 1,
      a3: &v33,
      a4: 0,
      a5: 0);
    v30 = v34; /*0x1066f16bf*/
    if ( v34 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v34 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f16db*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v30 + 16LL))(a1: v30); /*0x1066f16e3*/
      std::__shared_weak_count::__release_weak(this: v30); /*0x1066f16e9*/
    }
    v31 = v38[1]; /*0x1066f16ee*/
    if ( v38[1] != nullptr /*0x1066f1707*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v38[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v31 + 16LL))(a1: v31); /*0x1066f170f*/
      std::__shared_weak_count::__release_weak(this: v31); /*0x1066f1715*/
    }
  }
  else
  {
    v32 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x1066f1728*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x1066f1736*/
      this: (RakNet::AddressOrGUID *)v38,
      a2: (RBX::Network::Client *)((char *)this + 504));
    (*(void (__fastcall **)(__int64, _BYTE *, __int64, __int64, _QWORD, std::__shared_weak_count **, _DWORD, _DWORD, _QWORD))(*(_QWORD *)v32 + 184LL))( /*0x1066f1772*/
      a1: v32,
      a2: v35,
      a3: 2,
      a4: 3,
      a5: 0,
      a6: v38,
      a7: 0,
      a8: 0,
      a9: 0);
  }
  rbx::signal<void ()(RBX::StringLiteral const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x1066f1785*/
    a1: (char *)this + 4864,
    a2: &RBX::Analytics::kSendVersionInfo);
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v35); /*0x1066f1791*/
}

// Address: 0x1066f17e2 | Name: __ZNK3RBX7Network6Client17usingRbxTransportEv
bool __fastcall RBX::Network::Client::usingRbxTransport(RBX::Network::Client *this, bool a2)
{
  __int64 v3; // rax
  _QWORD *v4; // rbx

  if ( (unsigned __int8)RBX::Network::useRbxTransport(this: nullptr, a2) == 0 /*0x1066f17fd*/
    && FFlag::RakNetConnectionFailureFallbackToRbxTransport != 1 )
  {
    return false; /*0x1066f17fd*/
  }
  v3 = *((_QWORD *)this + 574); /*0x1066f17ff*/
  v4 = (_QWORD *)((char *)this + 4600); /*0x1066f180d*/
  if ( v3 != 0 ) /*0x1066f1817*/
    v4 = (_QWORD *)(v3 + 280); /*0x1066f1817*/
  return *v4 != 0 && (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v4 + 136LL))(a1: *v4) == 1; /*0x1066f182e*/
}

// Address: 0x1066f1862 | Name: __ZN3RBX7Network6Client10sendTicketEv
void __fastcall RBX::Network::Client::sendTicket(RBX::Network **this)
{
  RBX::Network::NetworkStream *v2; // rdx
  __int64 v3; // rdx
  __int64 v4; // rcx
  void *v5; // rsi
  void *v6; // rsi
  RBX::Instance *v7; // rsi
  __int64 v8; // r14
  RBX::Security *v9; // rdi
  unsigned int PlatformKey; // eax
  __m128 v11; // xmm0
  __m128 v12; // xmm1
  __m128 v13; // xmm2
  __m128 v14; // xmm3
  __m128 v15; // xmm4
  __m128 v16; // xmm5
  __m128 v17; // xmm6
  __m128 v18; // xmm7
  bool v19; // si
  RBX::Network *v20; // rdi
  const unsigned __int8 *v21; // rdx
  unsigned __int64 v22; // rsi
  __int64 v23; // r14
  __int64 v24; // rax
  __int64 *v25; // rbx
  __int64 v26; // rdi
  void *v27; // rsi
  std::__shared_weak_count *v28; // rbx
  std::__shared_weak_count *v29; // rbx
  __int64 v30; // r14
  char v31; // [rsp+0h] [rbp-F0h]
  __int64 v32; // [rsp+20h] [rbp-D0h] BYREF
  std::__shared_weak_count *v33; // [rsp+28h] [rbp-C8h]
  __int64 v34[8]; // [rsp+30h] [rbp-C0h] BYREF
  _BYTE v35[16]; // [rsp+70h] [rbp-80h] BYREF
  void *v36; // [rsp+80h] [rbp-70h]
  char v37; // [rsp+88h] [rbp-68h] BYREF
  unsigned __int8 v38; // [rsp+89h] [rbp-67h] BYREF
  void *v39; // [rsp+98h] [rbp-58h]
  std::__shared_weak_count *v40[2]; // [rsp+A0h] [rbp-50h] BYREF
  void *v41; // [rsp+B0h] [rbp-40h]

  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v34); /*0x1066f187f*/
  LOBYTE(v40[0]) = -118; /*0x1066f1888*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v34, a2: v40, a3: 1u); /*0x1066f1893*/
  RBX::Network::serializeSignedVarint64(this: *(this + 67), a2: (__int64)v34, a3: v2); /*0x1066f18a6*/
  RBX::Network::serializeString(a1: this + 68, a2: v34, a3: (unsigned int)DFInt::CliMaxPayloadSnd); /*0x1066f18bf*/
  LODWORD(v40[0]) = *((_DWORD *)this + 84); /*0x1066f18ce*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v34, a2: v40, a3: 4u); /*0x1066f18dc*/
  RBX::Security::encodeVersionKey(a1: v35, a2: &RBX::Network::securityKey, a3: 46); /*0x1066f18f1*/
  RBX::Network::serializeString(a1: v35, a2: v34, a3: (unsigned int)DFInt::CliMaxPayloadSnd); /*0x1066f1907*/
  RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)v40); /*0x1066f1910*/
  RBX::Network::serializeString(a1: v40, a2: v34, a3: (unsigned int)DFInt::CliMaxPayloadSnd); /*0x1066f1926*/
  if ( ((__int64)v40[0] & 1) != 0 ) /*0x1066f192f*/
    operator delete(a1: (RBX::Memory *)v41, a2: v5); /*0x1066f1935*/
  std::string::basic_string[abi:ne200100]<0>(a1: v40, a2: "?", a3: v3, a4: v4); /*0x1066f1945*/
  RBX::Network::serializeString(a1: v40, a2: v34, a3: (unsigned int)DFInt::CliMaxPayloadSnd); /*0x1066f195b*/
  if ( ((__int64)v40[0] & 1) != 0 ) /*0x1066f1964*/
    operator delete(a1: (RBX::Memory *)v41, a2: v6); /*0x1066f196a*/
  RBX::Network::serializeString(a1: this + 577, a2: v34, a3: (unsigned int)DFInt::CliMaxPayloadSnd); /*0x1066f1983*/
  LODWORD(v40[0]) = -1073624322; /*0x1066f198c*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v34, a2: v40, a3: 4u); /*0x1066f199e*/
  v8 = *(_QWORD *)(RBX::DataModel::get((RBX::DataModel *)this, a2: v7) + 840); /*0x1066f19ab*/
  PlatformKey = RBX::Security::getPlatformKey(this: v9); /*0x1066f19b2*/
  RBX::format( /*0x1066f19dd*/
    this: (RBX *)&v37,
    a2: "%d%d%d%d",
    a3: (unsigned int)v8,
    a4: 2709510006LL,
    a5: PlatformKey,
    a6: 3654950291LL,
    a7: v11,
    a8: v12,
    a9: v13,
    a10: v14,
    a11: v15,
    a12: v16,
    a13: v17,
    a14: v18,
    a15: v31);
  std::string::resize(a1: &v37, a2: 16, a3: 0); /*0x1066f19ed*/
  if ( !RBX::Network::Client::usingRbxTransport((RBX::Network::Client *)this, a2: v19) ) /*0x1066f19f5*/
  {
    if ( (v37 & 1) != 0 ) /*0x1066f1a02*/
      v21 = (const unsigned __int8 *)v39; /*0x1066f1a04*/
    else
      v21 = &v38; /*0x1066f1a0a*/
    RBX::Network::Peer::encryptDataPartWithKey( /*0x1066f1a18*/
      (RBX::Network::Peer *)this,
      a2: (RBX::Network::NetworkStream *)v34,
      a3: v21);
  }
  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v20) != 0 ) /*0x1066f1a24*/
  {
    v23 = operator new(a1: (RBX::Memory *)0x58, a2: v22); /*0x1066f1a34*/
    *(_OWORD *)(v23 + 8) = 0; /*0x1066f1a3a*/
    *(_QWORD *)v23 = &off_10CAAE190; /*0x1066f1a45*/
    RBX::Network::NetworkStream::NetworkStream(a1: v23 + 24, a2: v34); /*0x1066f1a59*/
    v24 = (__int64)*(this + 574); /*0x1066f1a5e*/
    v25 = (__int64 *)(this + 575); /*0x1066f1a6c*/
    if ( v24 != 0 ) /*0x1066f1a76*/
      v25 = (__int64 *)(v24 + 280); /*0x1066f1a76*/
    v26 = *v25; /*0x1066f1a7a*/
    v32 = v23 + 24; /*0x1066f1a84*/
    v33 = (std::__shared_weak_count *)v23; /*0x1066f1a87*/
    *(_OWORD *)v40 = 0; /*0x1066f1a8e*/
    (*(void (__fastcall **)(__int64, __int64, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v26 + 48LL))( /*0x1066f1a9f*/
      a1: v26,
      a2: 1,
      a3: &v32,
      a4: 0,
      a5: 0);
    v28 = v33; /*0x1066f1aa2*/
    if ( v33 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v33 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f1abe*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v28 + 16LL))(a1: v28); /*0x1066f1ac6*/
      std::__shared_weak_count::__release_weak(this: v28); /*0x1066f1acc*/
    }
    v29 = v40[1]; /*0x1066f1ad1*/
    if ( v40[1] != nullptr /*0x1066f1aee*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v40[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v29 + 16LL))(a1: v29); /*0x1066f1af6*/
      std::__shared_weak_count::__release_weak(this: v29); /*0x1066f1afc*/
    }
  }
  else
  {
    v30 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x1066f1b0f*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x1066f1b20*/
      this: (RakNet::AddressOrGUID *)v40,
      a2: (const RakNet::SystemAddress *)(this + 63));
    (*(void (__fastcall **)(__int64, __int64 *, __int64, __int64, _QWORD, std::__shared_weak_count **, _DWORD, _DWORD, _QWORD))(*(_QWORD *)v30 + 184LL))( /*0x1066f1b5c*/
      a1: v30,
      a2: v34,
      a3: 2,
      a4: 3,
      a5: 0,
      a6: v40,
      a7: 0,
      a8: 0,
      a9: 0);
  }
  if ( (v37 & 1) != 0 ) /*0x1066f1b62*/
    operator delete(a1: (RBX::Memory *)v39, a2: v27); /*0x1066f1b68*/
  if ( (v35[0] & 1) != 0 ) /*0x1066f1b71*/
    operator delete(a1: (RBX::Memory *)v36, a2: v27); /*0x1066f1b77*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v34); /*0x1066f1b83*/
}

// Address: 0x1066f1c0e | Name: __ZN3RBX7Network6Client20getMetricForRakNetIDEh
const char *__fastcall RBX::Network::Client::getMetricForRakNetID(RBX::Network::Client *this)
{
  unsigned __int8 v1; // di

  v1 = (_BYTE)this - 10; /*0x1066f1c12*/
  if ( v1 > 0x10u ) /*0x1066f1c1a*/
    return "Error_Unknown"; /*0x1066f1c30*/
  else
    return (char *)dword_1099FCFE4 + dword_1099FCFE4[v1]; /*0x1066f1c2b*/
}

// Address: 0x1066f1c3a | Name: __ZN3RBX7Network6Client29getConnectionErrorForRakNetIDEh
__int64 __fastcall RBX::Network::Client::getConnectionErrorForRakNetID(RBX::Network::Client *this, int a2)
{
  __int64 result; // rax

  switch ( a2 ) /*0x1066f1c54*/
  {
    case 11: /*0x1066f1c54*/
      result = 9; /*0x1066f1c56*/
      break; /*0x1066f1c5b*/
    case 12: /*0x1066f1c54*/
    case 14: /*0x1066f1c54*/
    case 15: /*0x1066f1c54*/
    case 16: /*0x1066f1c54*/
    case 17: /*0x1066f1c54*/
    case 19: /*0x1066f1c54*/
      goto LABEL_5;
    case 13: /*0x1066f1c54*/
      result = 279; /*0x1066f1c73*/
      break; /*0x1066f1c78*/
    case 18: /*0x1066f1c54*/
      result = 3; /*0x1066f1c88*/
      break; /*0x1066f1c8d*/
    case 20: /*0x1066f1c54*/
      result = 4; /*0x1066f1c96*/
      break; /*0x1066f1c9b*/
    case 21: /*0x1066f1c54*/
      result = 308; /*0x1066f1c7a*/
      break; /*0x1066f1c7f*/
    case 22: /*0x1066f1c54*/
      result = 277; /*0x1066f1c8f*/
      break; /*0x1066f1c94*/
    case 23: /*0x1066f1c54*/
      result = 5; /*0x1066f1c9d*/
      break; /*0x1066f1ca2*/
    case 24: /*0x1066f1c54*/
      result = 6; /*0x1066f1ca4*/
      break; /*0x1066f1ca9*/
    case 25: /*0x1066f1c54*/
      result = 7; /*0x1066f1cab*/
      break; /*0x1066f1cab*/
    case 26: /*0x1066f1c54*/
      result = 8; /*0x1066f1c81*/
      break; /*0x1066f1c86*/
    default:
      if ( a2 == 149 ) /*0x1066f1c63*/
        result = 10; /*0x1066f1c65*/
      else
LABEL_5:
        result = 2; /*0x1066f1c6c*/
      break; /*0x1066f1c6a*/
  }
  return result; /*0x1066f1cb0*/
}

// Address: 0x1066f1cf4 | Name: __ZN3RBX7Network6Client25OnFailedConnectionAttemptEPN6RakNet6PacketE
__int64 __fastcall RBX::Network::Client::OnFailedConnectionAttempt(
        RBX::Network::Client *this,
        RakNet::SystemAddress *a2)
{
  unsigned __int8 v4; // r15
  const char *MetricForRakNetID; // rax
  RBX::Network::Client *v6; // rdi
  unsigned int ConnectionErrorForRakNetID; // r12d
  void *v8; // rsi
  __int128 v10; // [rsp+10h] [rbp-460h] BYREF
  _QWORD v11[2]; // [rsp+20h] [rbp-450h] BYREF
  void *v12; // [rsp+30h] [rbp-440h]
  char __s1[1032]; // [rsp+40h] [rbp-430h] BYREF

  v4 = **((_BYTE **)a2 + 7); /*0x1066f1d1e*/
  RakNet::SystemAddress::ToStringN(this: a2, a2: true, a3: __s1, a4: 1025, a5: 124); /*0x1066f1d3b*/
  MetricForRakNetID = RBX::Network::Client::getMetricForRakNetID(this: (RBX::Network::Client *)v4); /*0x1066f1d47*/
  RBX::Network::Client::updateServerConnectionState(this, __s1, a3: 3, a4: (__int64)MetricForRakNetID, a5: 1); /*0x1066f1d67*/
  if ( (unsigned __int8)RBX::Network::Client::noViableConnectionsLeft(this) != 0 ) /*0x1066f1d76*/
  {
    if ( *((_BYTE *)this + 600) == 1 ) /*0x1066f1d83*/
    {
      ConnectionErrorForRakNetID = RBX::Network::Client::getConnectionErrorForRakNetID(this: v6, a2: v4); /*0x1066f1d91*/
      if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFE00) != 0 ) /*0x1066f1da8*/
      {
        v11[0] = __s1; /*0x1066f1dc0*/
        v12 = (void *)ConnectionErrorForRakNetID; /*0x1066f1dc3*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x1066f1dfc*/
          a1: (_DWORD)DFLog::NetworkClient,
          a2: qword_10D809380,
          a3: 2,
          a4: (unsigned int)"[DFLog::NetworkClient] Server reached at {}, but handshake failed. Connection error {}",
          a5: 86,
          a6: 1,
          28,
          v11,
          28,
          v11);
      }
      RBX::Network::RakNetAddressToString(this: (RBX::Network *)v11, a2, a3: true, a4: 124); /*0x1066f1e15*/
      RBX::Network::Client::requestDisconnectOnTransportFailure(a1: this, a2: v11, a3: ConnectionErrorForRakNetID); /*0x1066f1e27*/
    }
    else
    {
      if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFE00) != 0 ) /*0x1066f1e45*/
      {
        v11[0] = 12; /*0x1066f1e5d*/
        v11[1] = &v10; /*0x1066f1e68*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x1066f1e92*/
          a1: (_DWORD)DFLog::NetworkClient,
          a2: qword_10D809380,
          a3: 2,
          a4: (unsigned int)"[DFLog::NetworkClient] Failed to connect to server at {}, no response.",
          a5: 70,
          a6: 1,
          12,
          &v10,
          __s1);
      }
      RBX::Network::RakNetAddressToString(this: (RBX::Network *)v11, a2, a3: true, a4: 124); /*0x1066f1eab*/
      RBX::Network::Client::requestDisconnectOnTransportFailure(a1: this, a2: v11, a3: 279); /*0x1066f1ebf*/
    }
    if ( (v11[0] & 1) != 0 ) /*0x1066f1ecb*/
      operator delete(a1: (RBX::Memory *)v12, a2: v8); /*0x1066f1ed4*/
  }
  return __stack_chk_guard; /*0x1066f1ee9*/
}

// Address: 0x1066f1f26 | Name: __ZN3RBX7Network6Client35requestDisconnectOnTransportFailureERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEi
void __fastcall RBX::Network::Client::requestDisconnectOnTransportFailure(__int64 a1, __int64 a2, unsigned int a3)
{
  int *v6; // r15
  char *v7; // rcx
  _QWORD *v8; // r8
  __int64 v9; // r13
  __int64 v10; // r8
  void *v11; // rsi
  int v12; // eax
  __int64 v13; // r8
  const char *v14; // rcx
  unsigned __int8 *v15; // rcx
  bool v16; // al
  __int64 v17; // rdi
  __int64 ReasonCodeEnumString; // rax
  __int64 v19; // rdx
  unsigned int v20; // r12d
  __int64 v21; // r8
  unsigned __int8 *v22; // rcx
  __int64 v23; // rdi
  void *v24; // rsi
  _BYTE v25[72]; // [rsp+18h] [rbp-2F8h] BYREF
  _BYTE v26[528]; // [rsp+60h] [rbp-2B0h] BYREF
  _BYTE v27[32]; // [rsp+270h] [rbp-A0h] BYREF
  void *v28; // [rsp+290h] [rbp-80h]
  char v29; // [rsp+2A8h] [rbp-68h]
  _QWORD v30[2]; // [rsp+2B0h] [rbp-60h] BYREF
  __int64 v31; // [rsp+2C0h] [rbp-50h] BYREF
  _QWORD *v32; // [rsp+2C8h] [rbp-48h]
  void *v33; // [rsp+2D0h] [rbp-40h]
  _QWORD *(__fastcall *v34)(unsigned int *, __int64, _QWORD **); // [rsp+2D8h] [rbp-38h]
  _DWORD v35[11]; // [rsp+2E4h] [rbp-2Ch] BYREF

  v35[0] = a3; /*0x1066f1f43*/
  if ( FFlag::RbxTransportConnectionFailureFallbackToRakNet == 1 && *(_BYTE *)(a1 + 4722) == 1 )
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1066f1f6e*/
      a1: (__int64)v25,
      a2: (__int64)&RBX::Telemetry::kRbxTransportFallbackToRakNetStatus);
    RBX::Telemetry::FieldsContainer::addField(a1: v26, a2: "success", a3: 7, a4: 0, a5: 1); /*0x1066f1f91*/
    v6 = (int *)(a1 + 4728); /*0x1066f1f96*/
    v30[0] = a1 + 4728; /*0x1066f1fa1*/
    v30[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Network::StateReason,fmt::v8::formatter<RBX::Network::StateReason,char,void>>; /*0x1066f1fab*/
    fmt::v8::vformat(a1: &v31, a2: "{}", 2, 15); /*0x1066f1fc4*/
    if ( (v31 & 1) != 0 ) /*0x1066f1fd2*/
    {
      v7 = (char *)v33; /*0x1066f1fd8*/
      v8 = v32; /*0x1066f1fdc*/
    }
    else
    {
      v8 = (_QWORD *)((unsigned __int8)v31 >> 1); /*0x1066f2097*/
      v7 = (char *)&v31 + 1; /*0x1066f209a*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v26, a2: "originalRbxTransportError", a3: 25, a4: v7, a5: v8, a6: 1); /*0x1066f20b3*/
    if ( (v31 & 1) != 0 ) /*0x1066f20bc*/
      operator delete(a1: (RBX::Memory *)v33, a2: v11); /*0x1066f20c2*/
    v12 = *v6; /*0x1066f20c7*/
    if ( *v6 > 127 ) /*0x1066f20cd*/
    {
      switch ( v12 ) /*0x1066f2112*/
      {
        case 256: /*0x1066f2112*/
          v14 = "Player"; /*0x1066f2114*/
          goto LABEL_52; /*0x1066f211b*/
        case 257: /*0x1066f2112*/
          v14 = "RCC"; /*0x1066f2310*/
          goto LABEL_50; /*0x1066f2310*/
        case 258: /*0x1066f2112*/
          v14 = "Studio"; /*0x1066f22f5*/
          goto LABEL_52; /*0x1066f22fc*/
        case 259: /*0x1066f2112*/
          v14 = "Security"; /*0x1066f22fe*/
          goto LABEL_56; /*0x1066f2305*/
        case 260: /*0x1066f2112*/
          v14 = "Matchmaking"; /*0x1066f22e3*/
          goto LABEL_54; /*0x1066f22ea*/
        case 261: /*0x1066f2112*/
          v14 = "RoMark"; /*0x1066f231f*/
          goto LABEL_52; /*0x1066f231f*/
        case 262: /*0x1066f2112*/
          v14 = "Replication"; /*0x1066f232e*/
          goto LABEL_54; /*0x1066f232e*/
        case 263: /*0x1066f2112*/
          v14 = "PlaceLaunch"; /*0x1066f2307*/
LABEL_54:
          v13 = 11; /*0x1066f2335*/
          break; /*0x1066f233b*/
        case 264: /*0x1066f2112*/
          v14 = "Teleport"; /*0x1066f233d*/
LABEL_56:
          v13 = 8; /*0x1066f2344*/
          break; /*0x1066f2344*/
        default:
          if ( v12 == 128 ) /*0x1066f2144*/
          {
            v14 = "System"; /*0x1066f22ec*/
LABEL_52:
            v13 = 6; /*0x1066f2326*/
          }
          else if ( v12 == 192 ) /*0x1066f214f*/
          {
            v14 = "RNA"; /*0x1066f2155*/
LABEL_50:
            v13 = 3; /*0x1066f2317*/
          }
          else
          {
LABEL_43:
            v14 = "InvalidReasonClass"; /*0x1066f22d4*/
            v13 = 18; /*0x1066f22db*/
          }
          break; /*0x1066f231d*/
      }
    }
    else
    {
      v13 = 4; /*0x1066f20cf*/
      switch ( v12 ) /*0x1066f20eb*/
      {
        case '@': /*0x1066f20eb*/
          v14 = "Protocol"; /*0x1066f20ed*/
          goto LABEL_56; /*0x1066f20f4*/
        case 'A': /*0x1066f20eb*/
          v14 = "Ngtcp2"; /*0x1066f21ac*/
          goto LABEL_52; /*0x1066f21b3*/
        case 'B': /*0x1066f20eb*/
          v14 = "QUIC"; /*0x1066f2194*/
          break; /*0x1066f219b*/
        case 'C': /*0x1066f20eb*/
          v14 = "Port"; /*0x1066f21a0*/
          break; /*0x1066f21a7*/
        case 'D': /*0x1066f20eb*/
          v14 = "NoResponse"; /*0x1066f2176*/
          v13 = 10; /*0x1066f217d*/
          break; /*0x1066f2183*/
        default:
          if ( v12 != 0 ) /*0x1066f2122*/
          {
            if ( v12 != 1 ) /*0x1066f2127*/
              goto LABEL_43; /*0x1066f2127*/
            v14 = "IO"; /*0x1066f212d*/
            v13 = 2; /*0x1066f2134*/
          }
          else
          {
            v14 = "None"; /*0x1066f2188*/
          }
          break; /*0x1066f213a*/
      }
    }
    RBX::Telemetry::FieldsContainer::addField( /*0x1066f234a*/
      a1: v26,
      a2: "originalRbxTransportErrorReasonClass",
      a3: 36,
      a4: v14,
      a5: v13,
      a6: 1);
    ReasonCodeEnumString = RBX::Network::StateReason::getReasonCodeEnumString(this: (RBX::Network::StateReason *)(a1 + 4728)); /*0x1066f2367*/
    RBX::Telemetry::FieldsContainer::addField( /*0x1066f2387*/
      a1: v26,
      a2: "originalRbxTransportErrorReasonCode",
      a3: 35,
      a4: ReasonCodeEnumString,
      a5: v19,
      a6: 1);
    v20 = v35[0]; /*0x1066f238c*/
    RBX::Telemetry::FieldsContainer::addField(a1: v26, a2: "rakNetDisconnectCode", a3: 20, a4: v35[0], a5: 1); /*0x1066f23a8*/
    if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
    {
      v21 = (SFString::RCCChannelName[0] & 1) != 0
          ? *(_QWORD *)&SFString::RCCChannelName[8]
          : SFString::RCCChannelName[0] >> 1;
      if ( v21 != 0 ) /*0x1066f23d6*/
      {
        if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1066f23da*/
          v22 = *(unsigned __int8 **)&SFString::RCCChannelName[16]; /*0x1066f23dc*/
        else
          v22 = &SFString::RCCChannelName[1]; /*0x1066f23e2*/
        RBX::Telemetry::FieldsContainer::addField(a1: v26, a2: "rccChannelName", a3: 14, a4: v22, a5: v21, a6: 1); /*0x1066f23fa*/
      }
    }
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v25); /*0x1066f2406*/
    if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 )
    {
      v31 = v20; /*0x1066f2430*/
      v33 = (void *)(a1 + 4728); /*0x1066f2434*/
      v34 = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Network::StateReason,fmt::v8::formatter<RBX::Network::StateReason,char,void>>; /*0x1066f243f*/
      v30[0] = 241; /*0x1066f2443*/
      v30[1] = &v31; /*0x1066f244f*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: (_DWORD)DFLog::NetworkClient,
        a2: qword_10D809380,
        a3: 4,
        a4: (unsigned int)"[DFLog::NetworkClient] Failed to connect to server after falling back from RbxTransport to RakNet."
                      " Disconnect code: {}. Original connection failure reason: {}",
        a5: 158,
        a6: 1,
        241,
        &v31);
    }
LABEL_68:
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v25); /*0x1066f2478*/
    goto LABEL_69; /*0x1066f2486*/
  }
  if ( FFlag::RakNetConnectionFailureFallbackToRbxTransport != 1 /*0x1066f2006*/
    || *(_BYTE *)(a1 + 4816) != 0
    || *(_BYTE *)(a1 + 4720) != 0 )
  {
LABEL_69:
    rbx::signal<void ()(std::string,int)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: a1 + 4832, a2, a3: v35); /*0x1066f248b*/
    v23 = *(_QWORD *)(a1 + 4592); /*0x1066f249e*/
    if ( v23 != 0 ) /*0x1066f24a8*/
    {
      v27[0] = 0; /*0x1066f24b6*/
      v29 = 0; /*0x1066f24b8*/
      RBX::Network::Replicator::requestDisconnect(a1: v23, a2: v35[0], a3: v27); /*0x1066f24bb*/
      if ( v29 == 1 && (v27[16] & 1) != 0 ) /*0x1066f24cd*/
        operator delete(a1: (RBX::Memory *)v28, a2: v24); /*0x1066f24d3*/
    }
    return; /*0x1066f24d3*/
  }
  v9 = *(_QWORD *)(a1 + 4800); /*0x1066f200c*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1066f2021*/
    a1: (__int64)v25,
    a2: (__int64)&RBX::Telemetry::kRakNetFallbackToRbxTransportEvent);
  RBX::Telemetry::FieldsContainer::addField(a1: v26, a2: "disconnectCode", a3: 14, a4: (int)a3, a5: 1); /*0x1066f2045*/
  RBX::Telemetry::FieldsContainer::addField(a1: v26, a2: "fallbackToRbxTransportAvailable", a3: 31, a4: v9 != 0, a5: 1); /*0x1066f2067*/
  if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
  {
    v10 = (SFString::RCCChannelName[0] & 1) != 0
        ? *(_QWORD *)&SFString::RCCChannelName[8]
        : SFString::RCCChannelName[0] >> 1;
    if ( v10 != 0 ) /*0x1066f216a*/
    {
      if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1066f216e*/
        v15 = *(unsigned __int8 **)&SFString::RCCChannelName[16]; /*0x1066f2170*/
      else
        v15 = &SFString::RCCChannelName[1]; /*0x1066f21b8*/
      RBX::Telemetry::FieldsContainer::addField(a1: v26, a2: "rccChannelName", a3: 14, a4: v15, a5: v10, a6: 1); /*0x1066f21d0*/
    }
  }
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v25); /*0x1066f21dc*/
  v16 = (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0; /*0x1066f21f8*/
  if ( v9 == 0 )
  {
    if ( v16 )
    {
      v30[0] = a3; /*0x1066f229b*/
      v31 = 1; /*0x1066f229e*/
      v32 = v30; /*0x1066f22a6*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: (_DWORD)DFLog::NetworkClient,
        a2: qword_10D809380,
        a3: 4,
        a4: (unsigned int)"[DFLog::NetworkClient] Failed to connect to server with RakNet, but fallback to RbxTransport is no"
                      "t available. Disconnect code: {}",
        a5: 130,
        a6: 1,
        1,
        v30);
    }
    goto LABEL_68; /*0x1066f22cf*/
  }
  if ( v16 )
  {
    v30[0] = a3; /*0x1066f2215*/
    v31 = 1; /*0x1066f2218*/
    v32 = v30; /*0x1066f2220*/
    FLog::detail::FastLogSafeFormattedInternal(
      a1: (_DWORD)DFLog::NetworkClient,
      a2: qword_10D809380,
      a3: 4,
      a4: (unsigned int)"[DFLog::NetworkClient] Failed to connect to server with RakNet, falling back to RbxTransport. Disconnect code: {}",
      a5: 113,
      a6: 1,
      1,
      v30);
  }
  *(_DWORD *)(a1 + 4820) = a3; /*0x1066f2249*/
  *(_BYTE *)(a1 + 4817) = 1; /*0x1066f2250*/
  v17 = *(_QWORD *)(a1 + 4800); /*0x1066f2257*/
  if ( v17 == 0 ) /*0x1066f2261*/
    std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x1066f24ea*/
  (*(void (__fastcall **)(__int64))(*(_QWORD *)v17 + 48LL))(a1: v17); /*0x1066f226a*/
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v25); /*0x1066f227b*/
}

// Address: 0x1066f2580 | Name: __ZN3RBX7Network6Client15OnNewConnectionEPN6RakNet6PacketERKNS2_13SystemAddressE
__int64 __fastcall RBX::Network::Client::OnNewConnection(
        RBX::Network::ConcurrentRakPeer **this,
        RakNet::SystemAddress *a2)
{
  RBX::Time *v4; // rdi
  __int64 v5; // rcx
  unsigned __int64 v6; // rdx
  signed __int64 v7; // rcx
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // rdx
  __int64 v11; // rcx
  void *v12; // rsi
  double v13; // xmm0_8
  RBX::Instance *v14; // rsi
  __int64 v15; // rax
  RBX::Instance *v16; // rsi
  __int64 v17; // rax
  float v18; // xmm0_4
  __int64 v19; // rax
  __int64 v20; // rdx
  __int64 v21; // r8
  __int64 v22; // r9
  unsigned __int64 v23; // rsi
  RBX::Network::SharedStringSynchronizer *v24; // r15
  RBX::Instance *v25; // rsi
  __int64 v26; // rax
  RBX::Network::SharedStringSynchronizer *v27; // r14
  void *v28; // rsi
  RBX::Network::StateReason *v29; // rbx
  char *v30; // rcx
  RBX::Network::StateReason **v31; // r8
  void *v32; // rsi
  int v33; // eax
  __int64 v34; // r8
  const char *v35; // rcx
  __int64 ReasonCodeEnumString; // rax
  __int64 v37; // rdx
  __int64 v38; // r8
  unsigned __int8 *v39; // rcx
  RBX::Network::SharedStringSynchronizer *v41[2]; // [rsp+28h] [rbp-738h] BYREF
  _BYTE v42[528]; // [rsp+70h] [rbp-6F0h] BYREF
  _DWORD v43[12]; // [rsp+280h] [rbp-4E0h] BYREF
  RBX::Network::StateReason *v44; // [rsp+2B0h] [rbp-4B0h] BYREF
  _QWORD *(__fastcall *v45)(unsigned int *, __int64, _QWORD **); // [rsp+2B8h] [rbp-4A8h]
  _BYTE v46[16]; // [rsp+2C0h] [rbp-4A0h] BYREF
  RBX::Time *v47; // [rsp+2D0h] [rbp-490h]
  _BYTE v48[16]; // [rsp+2D8h] [rbp-488h] BYREF
  void *v49; // [rsp+2E8h] [rbp-478h]
  _BYTE v50[16]; // [rsp+2F0h] [rbp-470h] BYREF
  void *v51; // [rsp+300h] [rbp-460h]
  double v52; // [rsp+308h] [rbp-458h]
  __int64 v53; // [rsp+310h] [rbp-450h] BYREF
  RBX::Network::StateReason **v54; // [rsp+318h] [rbp-448h]
  void *v55; // [rsp+320h] [rbp-440h]
  char v56[1032]; // [rsp+330h] [rbp-430h] BYREF

  RakNet::SystemAddress::ToStringN(this: a2, a2: true, a3: v56, a4: 1025, a5: 124); /*0x1066f25c3*/
  if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 ) /*0x1066f25dc*/
  {
    v53 = (__int64)v56; /*0x1066f25f1*/
    v41[0] = (RBX::Network::SharedStringSynchronizer *)12; /*0x1066f25f4*/
    v41[1] = (RBX::Network::SharedStringSynchronizer *)&v53; /*0x1066f25ff*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x1066f2629*/
      a1: (_DWORD)DFLog::NetworkClient,
      a2: qword_10D809380,
      a3: 4,
      a4: (unsigned int)"[DFLog::NetworkClient] Connection accepted from {}",
      a5: 50,
      a6: 1,
      12,
      &v53);
  }
  RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066f264d*/
    this,
    a2: "RakNetPasswordAccepted",
    a3: 0,
    a4: v56,
    a5: 2,
    a6: 1);
  *((_DWORD *)this + 158) = 2; /*0x1066f2652*/
  v5 = (__int64)*(this + 67); /*0x1066f265c*/
  if ( v5 > 0 ) /*0x1066f2666*/
  {
    v6 = v5 / 0x3E8uLL; /*0x1066f2680*/
    v7 = v5 % 0x3E8uLL; /*0x1066f268b*/
    if ( v7 < DFInt::ClientJoinProcessPositiveSamplesThousandths ) /*0x1066f269b*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v46, a2: "client", a3: v6, a4: v7); /*0x1066f26af*/
      std::string::basic_string[abi:ne200100]<0>(a1: v48, a2: "report", a3: v8, a4: v9); /*0x1066f26c2*/
      std::string::basic_string[abi:ne200100]<0>(a1: v50, a2: "GameServerConnectSuccess", a3: v10, a4: v11); /*0x1066f26d5*/
      memset(v43, 0, 32); /*0x1066f26e8*/
      v43[8] = 1065353216; /*0x1066f26eb*/
      RBX::Analytics::EventIngest::setRBXEvent(a1: v46, a2: v48, a3: v50, a4: v43); /*0x1066f2707*/
      std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v43); /*0x1066f2713*/
      if ( (v50[0] & 1) != 0 ) /*0x1066f271f*/
        operator delete(a1: (RBX::Memory *)v51, a2: v12); /*0x1066f2728*/
      if ( (v48[0] & 1) != 0 ) /*0x1066f2734*/
        operator delete(a1: (RBX::Memory *)v49, a2: v12); /*0x1066f273d*/
      if ( (v46[0] & 1) != 0 ) /*0x1066f2749*/
        operator delete(a1: v47, a2: v12); /*0x1066f2752*/
    }
  }
  RBX::Time::nowFast(this: v4); /*0x1066f2757*/
  v52 = v13; /*0x1066f275c*/
  v15 = RBX::DataModel::get((RBX::DataModel *)this, a2: v14); /*0x1066f2767*/
  v52 = v52 - *(double *)(v15 + 1776); /*0x1066f277c*/
  v17 = RBX::DataModel::get((RBX::DataModel *)this, a2: v16); /*0x1066f2787*/
  v18 = v52; /*0x1066f278f*/
  *(float *)(v17 + 1788) = v18; /*0x1066f2797*/
  RakNet::SystemAddress::operator=(a1: this + 63, a2); /*0x1066f27ac*/
  if ( FFlag::EnableSharedStringCaching == 1 /*0x1066f27fa*/
    && (v19 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)),
        (*(unsigned __int8 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v19 + 696LL))(
          a1: v19,
          a2: 0x100000000000LL,
          a3: v20,
          a4: *(_QWORD *)(*(_QWORD *)v19 + 696LL),
          a5: v21,
          a6: v22,
          a7: *(this + 63),
          a8: *(this + 64),
          a9: *(this + 65),
          a10: *(this + 66)) != 0) )
  {
    v24 = (RBX::Network::SharedStringSynchronizer *)operator new(a1: (RBX::Memory *)0x210, a2: v23); /*0x1066f280a*/
    __bzero(a1: v24, a2: 528); /*0x1066f2815*/
    RBX::Network::SharedStringSynchronizer::SharedStringSynchronizer(this: v24); /*0x1066f281d*/
    v41[0] = v24; /*0x1066f2822*/
    v26 = RBX::DataModel::get((RBX::DataModel *)this, a2: v25); /*0x1066f282c*/
    RBX::Network::SharedStringSynchronizer::loadHashesFromPlaceIdTable(this: v24, a2: *(_QWORD *)(v26 + 840)); /*0x1066f283b*/
    RBX::Network::Client::sendSharedStringHashes((RBX::Network::Client *)this, a2: v24); /*0x1066f284a*/
    RBX::Network::Client::sendVersionInfo((RBX::Network::Client *)this); /*0x1066f2852*/
    RBX::Network::Client::HandleConnection((RBX::Network::Client *)this, a2); /*0x1066f285d*/
    RBX::Network::ClientReplicator::setSharedStringSynchronizer(a1: *(this + 574), a2: v41); /*0x1066f2870*/
    v27 = v41[0]; /*0x1066f2875*/
    v41[0] = nullptr; /*0x1066f287c*/
    if ( v27 != nullptr ) /*0x1066f288a*/
    {
      RBX::Network::SharedStringSynchronizer::~SharedStringSynchronizer(this: v27); /*0x1066f288f*/
      operator delete(a1: v27, a2: v28); /*0x1066f2897*/
    }
  }
  else
  {
    RBX::Network::Client::sendVersionInfo((RBX::Network::Client *)this); /*0x1066f28a1*/
    RBX::Network::Client::HandleConnection((RBX::Network::Client *)this, a2); /*0x1066f28ac*/
  }
  if ( FFlag::RakNetConnectionFailureFallbackToRbxTransport == 1 ) /*0x1066f28b8*/
    *((_BYTE *)this + 4816) = 1; /*0x1066f28ba*/
  if ( FFlag::RbxTransportConnectionFailureFallbackToRakNet == 1 && *((_BYTE *)this + 4722) == 1 )
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1066f28e9*/
      a1: (__int64)v41,
      a2: (__int64)&RBX::Telemetry::kRbxTransportFallbackToRakNetStatus);
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "success", a3: 7, a4: 1, a5: 1); /*0x1066f290f*/
    v29 = (RBX::Network::StateReason *)(this + 591); /*0x1066f2914*/
    v44 = v29; /*0x1066f2922*/
    v45 = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Network::StateReason,fmt::v8::formatter<RBX::Network::StateReason,char,void>>; /*0x1066f292c*/
    fmt::v8::vformat(a1: &v53, a2: "{}", 2, 15, &v44); /*0x1066f294b*/
    if ( (v53 & 1) != 0 ) /*0x1066f295c*/
    {
      v30 = (char *)v55; /*0x1066f295e*/
      v31 = v54; /*0x1066f2965*/
    }
    else
    {
      v31 = (RBX::Network::StateReason **)((unsigned __int8)v53 >> 1); /*0x1066f296e*/
      v30 = (char *)&v53 + 1; /*0x1066f2971*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "originalRbxTransportError", a3: 25, a4: v30, a5: v31, a6: 1); /*0x1066f298d*/
    if ( (v53 & 1) != 0 ) /*0x1066f2999*/
      operator delete(a1: (RBX::Memory *)v55, a2: v32); /*0x1066f29a2*/
    v33 = *(_DWORD *)v29; /*0x1066f29a7*/
    if ( *(int *)v29 > 127 ) /*0x1066f29ac*/
    {
      switch ( v33 ) /*0x1066f29f1*/
      {
        case 256: /*0x1066f29f1*/
          v35 = "Player"; /*0x1066f29f3*/
          goto LABEL_50; /*0x1066f29fa*/
        case 257: /*0x1066f29f1*/
          v35 = "RCC"; /*0x1066f2aa9*/
          goto LABEL_48; /*0x1066f2aa9*/
        case 258: /*0x1066f29f1*/
          v35 = "Studio"; /*0x1066f2a8e*/
          goto LABEL_50; /*0x1066f2a95*/
        case 259: /*0x1066f29f1*/
          v35 = "Security"; /*0x1066f2a97*/
          goto LABEL_54; /*0x1066f2a9e*/
        case 260: /*0x1066f29f1*/
          v35 = "Matchmaking"; /*0x1066f2a7c*/
          goto LABEL_52; /*0x1066f2a83*/
        case 261: /*0x1066f29f1*/
          v35 = "RoMark"; /*0x1066f2ab8*/
          goto LABEL_50; /*0x1066f2ab8*/
        case 262: /*0x1066f29f1*/
          v35 = "Replication"; /*0x1066f2ac7*/
          goto LABEL_52; /*0x1066f2ac7*/
        case 263: /*0x1066f29f1*/
          v35 = "PlaceLaunch"; /*0x1066f2aa0*/
LABEL_52:
          v34 = 11; /*0x1066f2ace*/
          break; /*0x1066f2ad4*/
        case 264: /*0x1066f29f1*/
          v35 = "Teleport"; /*0x1066f2ad6*/
LABEL_54:
          v34 = 8; /*0x1066f2add*/
          break; /*0x1066f2add*/
        default:
          if ( v33 == 128 ) /*0x1066f2a1f*/
          {
            v35 = "System"; /*0x1066f2a85*/
LABEL_50:
            v34 = 6; /*0x1066f2abf*/
          }
          else if ( v33 == 192 ) /*0x1066f2a26*/
          {
            v35 = "RNA"; /*0x1066f2a28*/
LABEL_48:
            v34 = 3; /*0x1066f2ab0*/
          }
          else
          {
LABEL_41:
            v35 = "InvalidReasonClass"; /*0x1066f2a6d*/
            v34 = 18; /*0x1066f2a74*/
          }
          break; /*0x1066f2ab6*/
      }
    }
    else
    {
      v34 = 4; /*0x1066f29ae*/
      switch ( v33 ) /*0x1066f29ca*/
      {
        case '@': /*0x1066f29ca*/
          v35 = "Protocol"; /*0x1066f29cc*/
          goto LABEL_54; /*0x1066f29d3*/
        case 'A': /*0x1066f29ca*/
          v35 = "Ngtcp2"; /*0x1066f2a64*/
          goto LABEL_50; /*0x1066f2a6b*/
        case 'B': /*0x1066f29ca*/
          v35 = "QUIC"; /*0x1066f2a4f*/
          break; /*0x1066f2a56*/
        case 'C': /*0x1066f29ca*/
          v35 = "Port"; /*0x1066f2a5b*/
          break; /*0x1066f2a62*/
        case 'D': /*0x1066f29ca*/
          v35 = "NoResponse"; /*0x1066f2a31*/
          v34 = 10; /*0x1066f2a38*/
          break; /*0x1066f2a3e*/
        default:
          if ( v33 != 0 ) /*0x1066f2a01*/
          {
            if ( v33 != 1 ) /*0x1066f2a06*/
              goto LABEL_41; /*0x1066f2a06*/
            v35 = "IO"; /*0x1066f2a08*/
            v34 = 2; /*0x1066f2a0f*/
          }
          else
          {
            v35 = "None"; /*0x1066f2a43*/
          }
          break; /*0x1066f2a15*/
      }
    }
    RBX::Telemetry::FieldsContainer::addField( /*0x1066f2ae3*/
      a1: v42,
      a2: "originalRbxTransportErrorReasonClass",
      a3: 36,
      a4: v35,
      a5: v34,
      a6: 1);
    ReasonCodeEnumString = RBX::Network::StateReason::getReasonCodeEnumString(this: v29); /*0x1066f2b00*/
    RBX::Telemetry::FieldsContainer::addField( /*0x1066f2b20*/
      a1: v42,
      a2: "originalRbxTransportErrorReasonCode",
      a3: 35,
      a4: ReasonCodeEnumString,
      a5: v37,
      a6: 1);
    if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
    {
      v38 = (SFString::RCCChannelName[0] & 1) != 0
          ? *(_QWORD *)&SFString::RCCChannelName[8]
          : SFString::RCCChannelName[0] >> 1;
      if ( v38 != 0 ) /*0x1066f2b4e*/
      {
        if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1066f2b52*/
          v39 = *(unsigned __int8 **)&SFString::RCCChannelName[16]; /*0x1066f2b54*/
        else
          v39 = &SFString::RCCChannelName[1]; /*0x1066f2b5a*/
        RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "rccChannelName", a3: 14, a4: v39, a5: v38, a6: 1); /*0x1066f2b72*/
      }
    }
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v41); /*0x1066f2b7e*/
    if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 )
    {
      v44 = v29; /*0x1066f2ba5*/
      v45 = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Network::StateReason,fmt::v8::formatter<RBX::Network::StateReason,char,void>>; /*0x1066f2bac*/
      v53 = 15; /*0x1066f2bb3*/
      v54 = &v44; /*0x1066f2bbe*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: (_DWORD)DFLog::NetworkClient,
        a2: qword_10D809380,
        a3: 4,
        a4: (unsigned int)"[DFLog::NetworkClient] Successfully connected to server after falling back from RbxTransport to Ra"
                      "kNet. Original connection failure reason: {}",
        a5: 142,
        a6: 1,
        15,
        &v44);
    }
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v41); /*0x1066f2bfb*/
  }
  return __stack_chk_guard; /*0x1066f2c10*/
}

// Address: 0x1066f2d2c | Name: __ZN3RBX7Network6Client22sendSharedStringHashesERNS0_24SharedStringSynchronizerE
void __fastcall RBX::Network::Client::sendSharedStringHashes(
        RBX::Network::Client *this,
        RBX::Network::SharedStringSynchronizer *a2)
{
  RBX::Network *v4; // rdi
  __int64 v5; // rax
  _QWORD *v6; // rcx
  RBX::Network *v7; // rdi
  __int64 v8; // rax
  __int64 v9; // rdx
  __int64 v10; // r8
  __int64 v11; // r9
  unsigned __int64 v12; // rsi
  __int64 v13; // rax
  __int64 *v14; // rbx
  __int64 v15; // rbx
  __int64 v16; // r14
  std::__shared_weak_count *v17; // rbx
  __int64 v18; // r14
  _BYTE v19[48]; // [rsp+28h] [rbp-98h] BYREF
  _BYTE v20[48]; // [rsp+58h] [rbp-68h] BYREF
  int v21; // [rsp+88h] [rbp-38h]
  __int64 v22; // [rsp+98h] [rbp-28h] BYREF
  std::__shared_weak_count *v23; // [rsp+A0h] [rbp-20h]

  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v20); /*0x1066f2d46*/
  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v4) != 0 ) /*0x1066f2d52*/
  {
    v5 = *((_QWORD *)this + 574); /*0x1066f2d54*/
    v6 = (_QWORD *)(v5 + 280); /*0x1066f2d5b*/
    if ( v5 == 0 ) /*0x1066f2d6c*/
      v6 = (_QWORD *)((char *)this + 4600); /*0x1066f2d6c*/
    if ( ((*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v6 + 56LL))(a1: *v6) & 0x20000000) == 0 ) /*0x1066f2d7d*/
      goto LABEL_5; /*0x1066f2d7d*/
  }
  else
  {
    v8 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x1066f2d94*/
    if ( (*(unsigned __int8 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v8 + 696LL))( /*0x1066f2dc6*/
           a1: v8,
           a2: 0x20000000,
           a3: v9,
           a4: *(_QWORD *)(*(_QWORD *)v8 + 696LL),
           a5: v10,
           a6: v11,
           a7: *((_QWORD *)this + 63),
           a8: *((_QWORD *)this + 64),
           a9: *((_QWORD *)this + 65),
           a10: *((_QWORD *)this + 66)) == 0 )
    {
LABEL_5:
      RBX::Network::SharedStringSynchronizer::generateSharedStringHashPacket( /*0x1066f2d7f*/
        this: a2,
        a2: (RBX::Network::NetworkStream *)v20);
      goto LABEL_8; /*0x1066f2d8b*/
    }
  }
  RBX::Network::SharedStringSynchronizer::generateMixedHashPacket(this: a2, a2: (RBX::Network::NetworkStream *)v20); /*0x1066f2dcf*/
LABEL_8:
  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v7) != 0 ) /*0x1066f2ddb*/
  {
    if ( v21 != 0 ) /*0x1066f2de5*/
    {
      v13 = *((_QWORD *)this + 574); /*0x1066f2deb*/
      v14 = (__int64 *)((char *)this + 4600); /*0x1066f2df9*/
      if ( v13 != 0 ) /*0x1066f2e03*/
        v14 = (__int64 *)(v13 + 280); /*0x1066f2e03*/
      v15 = *v14; /*0x1066f2e07*/
      v16 = operator new(a1: (RBX::Memory *)0x58, a2: v12); /*0x1066f2e14*/
      *(_OWORD *)(v16 + 8) = 0; /*0x1066f2e1a*/
      *(_QWORD *)v16 = &off_10CAAE190; /*0x1066f2e25*/
      RBX::Network::NetworkStream::NetworkStream(a1: v16 + 24, a2: v20); /*0x1066f2e36*/
      v22 = v16 + 24; /*0x1066f2e3f*/
      v23 = (std::__shared_weak_count *)v16; /*0x1066f2e42*/
      (*(void (__fastcall **)(__int64, __int64, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v15 + 48LL))( /*0x1066f2e56*/
        a1: v15,
        a2: 1,
        a3: &v22,
        a4: 0,
        a5: 0);
      v17 = v23; /*0x1066f2e59*/
      if ( v23 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v23 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f2e76*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x1066f2e7e*/
        std::__shared_weak_count::__release_weak(this: v17); /*0x1066f2e84*/
      }
    }
  }
  else
  {
    v18 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x1066f2e97*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x1066f2eab*/
      this: (RakNet::AddressOrGUID *)v19,
      a2: (RBX::Network::Client *)((char *)this + 504));
    (*(void (__fastcall **)(__int64, _BYTE *, __int64, __int64, _QWORD, _BYTE *, _DWORD, _DWORD, _QWORD))(*(_QWORD *)v18 + 184LL))( /*0x1066f2ee7*/
      a1: v18,
      a2: v20,
      a3: 2,
      a4: 3,
      a5: 0,
      a6: v19,
      a7: 0,
      a8: 0,
      a9: 0);
  }
  RBX::Network::NetworkStream::Reset(this: (RBX::Network::NetworkStream *)v20); /*0x1066f2eed*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v20); /*0x1066f2ef6*/
}

// Address: 0x1066f2f2c | Name: __ZN3RBX7Network6Client16HandleConnectionEPN6RakNet6PacketE
void __fastcall RBX::Network::Client::HandleConnection(RBX::Network::Client *this, RakNet::SystemAddress *a2)
{
  RBX *v4; // rdi
  __int64 v5; // r15
  RBX::Security *v6; // rdi
  int VersionKey2; // eax
  RBX::Network::NetworkStream *v8; // rdx
  RBX::Network *v9; // rdi
  unsigned __int64 v10; // rsi
  __int64 v11; // r15
  __int64 v12; // rax
  __int64 *v13; // rcx
  __int64 v14; // rdi
  std::__shared_weak_count *v15; // r15
  std::__shared_weak_count *v16; // r15
  __int64 v17; // r15
  RBX::Workspace *v18; // rax
  __int64 v19; // rax
  __int64 v20; // rdx
  __int64 v21; // rsi
  __int64 v22; // r8
  __int64 v23; // r9
  RBX::EngineContext *v24; // rdi
  __int64 *v25; // r13
  __int128 v26; // xmm0
  volatile signed __int64 *v27; // r15
  std::__shared_weak_count *v28; // r15
  __int64 v29; // rdi
  __int128 v30; // xmm0
  volatile signed __int64 *v31; // r15
  std::__shared_weak_count *v32; // r15
  RBX::Network::Replicator *v33; // r13
  __int64 v34; // rax
  __int64 v35; // rdx
  __int64 v36; // r8
  __int64 v37; // r9
  std::__shared_weak_count *v38; // r15
  __int64 v39; // rax
  __int128 v40; // xmm0
  volatile signed __int64 *v41; // r12
  std::__shared_weak_count *v42; // rdi
  std::__shared_weak_count *v43; // r15
  RBX::Instance *v44; // r15
  RBX::Instance *v45; // rsi
  std::__shared_weak_count *v46; // r15
  __int64 v47; // r12
  __int64 v48; // rdx
  __int64 v49; // rcx
  void *v50; // rsi
  char *v51; // rbx
  void *v52; // rsi
  std::__shared_weak_count *v53; // rbx
  std::__shared_weak_count *v54; // rbx
  std::__shared_weak_count *v55; // rbx
  __int64 v56[8]; // [rsp+20h] [rbp-140h] BYREF
  __int64 v57; // [rsp+60h] [rbp-100h] BYREF
  std::__shared_weak_count *v58; // [rsp+68h] [rbp-F8h]
  __int128 v59; // [rsp+70h] [rbp-F0h]
  std::__shared_weak_count *v60[2]; // [rsp+80h] [rbp-E0h] BYREF
  __int128 v61; // [rsp+A8h] [rbp-B8h] BYREF
  __int64 v62; // [rsp+B8h] [rbp-A8h]
  _BYTE v63[16]; // [rsp+C0h] [rbp-A0h] BYREF
  void *v64; // [rsp+D0h] [rbp-90h]
  std::__shared_weak_count *v65; // [rsp+D8h] [rbp-88h] BYREF
  std::__shared_weak_count *v66; // [rsp+E0h] [rbp-80h]
  char *v67; // [rsp+E8h] [rbp-78h] BYREF
  std::__shared_weak_count *v68[2]; // [rsp+F0h] [rbp-70h] BYREF
  void *v69; // [rsp+100h] [rbp-60h]
  __int64 v70; // [rsp+108h] [rbp-58h] BYREF
  RBX::Network::Replicator *v71[2]; // [rsp+110h] [rbp-50h]
  std::__shared_weak_count *v72[2]; // [rsp+120h] [rbp-40h] BYREF

  *(_OWORD *)v71 = 0; /*0x1066f2f49*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v56); /*0x1066f2f54*/
  LOBYTE(v60[0]) = -110; /*0x1066f2f60*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v56, a2: v60, a3: 1u); /*0x1066f2f6f*/
  v5 = (unsigned int)RBX::globalRand(this: v4); /*0x1066f2f79*/
  VersionKey2 = RBX::Security::getVersionKey2(this: v6); /*0x1066f2f7c*/
  RBX::Network::serializeSignedVarint64( /*0x1066f2f95*/
    this: (RBX::Network *)((v5 << 32) | (unsigned int)v5 ^ VersionKey2),
    a2: (__int64)v56,
    a3: v8);
  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v9) != 0 ) /*0x1066f2fa1*/
  {
    v11 = operator new(a1: (RBX::Memory *)0x58, a2: v10); /*0x1066f2fb1*/
    *(_OWORD *)(v11 + 8) = 0; /*0x1066f2fb7*/
    *(_QWORD *)v11 = &off_10CAAE190; /*0x1066f2fc2*/
    RBX::Network::NetworkStream::NetworkStream(a1: v11 + 24, a2: v56); /*0x1066f2fd6*/
    v12 = *((_QWORD *)this + 574); /*0x1066f2fdb*/
    v13 = (__int64 *)(v12 + 280); /*0x1066f2fe2*/
    if ( v12 == 0 ) /*0x1066f2ff3*/
      v13 = (__int64 *)((char *)this + 4600); /*0x1066f2ff3*/
    v14 = *v13; /*0x1066f2ff7*/
    v57 = v11 + 24; /*0x1066f3001*/
    v58 = (std::__shared_weak_count *)v11; /*0x1066f3004*/
    *(_OWORD *)v60 = 0; /*0x1066f300b*/
    (*(void (__fastcall **)(__int64, __int64, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v14 + 48LL))( /*0x1066f301f*/
      a1: v14,
      a2: 1,
      a3: &v57,
      a4: 0,
      a5: 0);
    v15 = v58; /*0x1066f3022*/
    if ( v58 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v58 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f303e*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x1066f3046*/
      std::__shared_weak_count::__release_weak(this: v15); /*0x1066f304c*/
    }
    v16 = v60[1]; /*0x1066f3051*/
    if ( v60[1] != nullptr /*0x1066f3071*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v60[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x1066f3079*/
      std::__shared_weak_count::__release_weak(this: v16); /*0x1066f307f*/
    }
  }
  else
  {
    v17 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x1066f3092*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x1066f30a3*/
      this: (RakNet::AddressOrGUID *)v60,
      a2: (RBX::Network::Client *)((char *)this + 504));
    (*(void (__fastcall **)(__int64, __int64 *, __int64, __int64, _QWORD, std::__shared_weak_count **, _DWORD, _DWORD, _QWORD))(*(_QWORD *)v17 + 184LL))( /*0x1066f30e2*/
      a1: v17,
      a2: v56,
      a3: 2,
      a4: 3,
      a5: 0,
      a6: v60,
      a7: 0,
      a8: 0,
      a9: 0);
  }
  RBX::Network::Client::sendTicket((RBX::Network **)this); /*0x1066f30e7*/
  RBX::Network::Client::sendPreferredSpawnName(this); /*0x1066f30ef*/
  v18 = (RBX::Workspace *)RBX::ServiceProvider::find<RBX::Workspace>(a1: this); /*0x1066f30f7*/
  RBX::Workspace::clearTerrain(this: v18); /*0x1066f30ff*/
  LODWORD(v60[0]) = -1; /*0x1066f310b*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)((char *)v60 + 4)); /*0x1066f3116*/
  v61 = 0; /*0x1066f3125*/
  RakNet::SystemAddress::operator=(a1: (char *)v60 + 4, a2); /*0x1066f312e*/
  std::shared_ptr<RBX::Network::ConcurrentRakPeer>::operator=[abi:ne200100](a1: &v61, a2: (char *)this + 288); /*0x1066f3144*/
  LODWORD(v60[0]) = 1; /*0x1066f3149*/
  v19 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x1066f315a*/
  v62 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v19 + 688LL))( /*0x1066f3180*/
          a1: v19,
          a2: v21,
          a3: v20,
          a4: *(_QWORD *)(*(_QWORD *)v19 + 688LL),
          a5: v22,
          a6: v23,
          a7: *(_QWORD *)a2,
          a8: *((_QWORD *)a2 + 1),
          a9: *((_QWORD *)a2 + 2),
          a10: *((_QWORD *)a2 + 3));
  if ( FFlag::ConnectViaConnectionInternal == 1 ) /*0x1066f3198*/
  {
    v67 = (char *)this + 696; /*0x1066f319e*/
    v25 = (__int64 *)((char *)this + 4600); /*0x1066f31a7*/
    v68[0] = (std::__shared_weak_count *)RBX::EngineContext::getThreadLocal(this: v24); /*0x1066f31b2*/
    LODWORD(v68[1]) = 10074; /*0x1066f31b5*/
    RBX::Creatable::createImpl<RBX::Network::ClientReplicator,RBX::ForceConstructionInCreatable &,RBX::Network::Replicator::ReplicatorPeerInfo &,RBX::Network::MegaReplicator *,std::unique_ptr<RBX::NetworkBase::ConnectionInternal>>( /*0x1066f31ce*/
      a1: v72,
      a2: v68,
      a3: v60,
      a4: &v67,
      a5: (char *)this + 4600);
    v26 = *(_OWORD *)v72; /*0x1066f31d3*/
    *(_OWORD *)v72 = 0; /*0x1066f31da*/
    v27 = (volatile signed __int64 *)v71[1]; /*0x1066f31de*/
    *(_OWORD *)v71 = v26; /*0x1066f31e2*/
    if ( v27 != nullptr && _InterlockedExchangeAdd64(v27 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f31fb*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v27 + 16))(a1: v27); /*0x1066f3203*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v27); /*0x1066f3209*/
    }
    v28 = v72[1]; /*0x1066f320e*/
    if ( v72[1] != nullptr /*0x1066f3227*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v72[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v28 + 16LL))(a1: v28); /*0x1066f322f*/
      std::__shared_weak_count::__release_weak(this: v28); /*0x1066f3235*/
    }
    v29 = *v25; /*0x1066f323a*/
    *v25 = 0; /*0x1066f323e*/
  }
  else
  {
    v67 = (char *)this + 696; /*0x1066f324b*/
    v70 = 0; /*0x1066f324f*/
    v68[0] = (std::__shared_weak_count *)RBX::EngineContext::getThreadLocal(this: v24); /*0x1066f3260*/
    LODWORD(v68[1]) = 10074; /*0x1066f3263*/
    RBX::Creatable::createImpl<RBX::Network::ClientReplicator,RBX::ForceConstructionInCreatable &,RBX::Network::Replicator::ReplicatorPeerInfo &,RBX::Network::MegaReplicator *,std::unique_ptr<RBX::NetworkBase::ConnectionInternal>>( /*0x1066f327d*/
      a1: v72,
      a2: v68,
      a3: v60,
      a4: &v67,
      a5: &v70);
    v30 = *(_OWORD *)v72; /*0x1066f3282*/
    *(_OWORD *)v72 = 0; /*0x1066f3289*/
    v31 = (volatile signed __int64 *)v71[1]; /*0x1066f328d*/
    *(_OWORD *)v71 = v30; /*0x1066f3291*/
    if ( v31 != nullptr && _InterlockedExchangeAdd64(v31 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f32aa*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v31 + 16))(a1: v31); /*0x1066f32b2*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v31); /*0x1066f32b8*/
    }
    v32 = v72[1]; /*0x1066f32bd*/
    if ( v72[1] != nullptr /*0x1066f32d6*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v72[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v32 + 16LL))(a1: v32); /*0x1066f32de*/
      std::__shared_weak_count::__release_weak(this: v32); /*0x1066f32e4*/
    }
    v29 = v70; /*0x1066f32e9*/
    v70 = 0; /*0x1066f32ed*/
  }
  if ( v29 != 0 ) /*0x1066f32f8*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v29 + 8LL))(a1: v29); /*0x1066f32fd*/
  v33 = v71[0]; /*0x1066f3300*/
  RBX::Network::Client::setClientReplicator(this, a2: v71[0]); /*0x1066f330a*/
  v34 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 36)); /*0x1066f3313*/
  (*(void (__fastcall **)(std::__shared_weak_count **, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)v34 + 704LL))( /*0x1066f333b*/
    a1: v68,
    a2: v34,
    a3: v35,
    a4: *(_QWORD *)(*(_QWORD *)v34 + 704LL),
    a5: v36,
    a6: v37,
    a7: *(_QWORD *)a2,
    a8: *((_QWORD *)a2 + 1),
    a9: *((_QWORD *)a2 + 2),
    a10: *((_QWORD *)a2 + 3));
  if ( v68[0] != nullptr ) /*0x1066f3344*/
  {
    v65 = v68[0]; /*0x1066f334a*/
    v66 = v68[1]; /*0x1066f3355*/
    if ( v68[1] != nullptr ) /*0x1066f335c*/
      _InterlockedIncrement64((volatile signed __int64 *)v68[1] + 1); /*0x1066f335e*/
    RBX::Network::Replicator::setSessionCrypto(a1: v33, a2: &v65); /*0x1066f336d*/
    v38 = v66; /*0x1066f3372*/
    if ( v66 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v66 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f338b*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v38 + 16LL))(a1: v38); /*0x1066f3393*/
      std::__shared_weak_count::__release_weak(this: v38); /*0x1066f3399*/
    }
    v39 = RBX::ServiceProvider::find<RBX::ContentProvider>(a1: this); /*0x1066f33a1*/
    if ( v39 != 0 ) /*0x1066f33a9*/
    {
      v40 = *(_OWORD *)v68; /*0x1066f33ab*/
      v41 = (volatile signed __int64 *)v68[1]; /*0x1066f33af*/
      if ( v68[1] != nullptr ) /*0x1066f33b6*/
      {
        _InterlockedIncrement64((volatile signed __int64 *)v68[1] + 2); /*0x1066f33b8*/
        _InterlockedIncrement64(v41 + 2); /*0x1066f33be*/
      }
      v42 = *(std::__shared_weak_count **)(v39 + 696); /*0x1066f33c4*/
      *(_OWORD *)(v39 + 688) = v40; /*0x1066f33cb*/
      if ( v42 != nullptr ) /*0x1066f33d5*/
        std::__shared_weak_count::__release_weak(this: v42); /*0x1066f33d7*/
      if ( v41 != nullptr ) /*0x1066f33df*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v41); /*0x1066f33e4*/
    }
  }
  v43 = v68[1]; /*0x1066f33e9*/
  if ( v68[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v68[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f3402*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v43 + 16LL))(a1: v43); /*0x1066f340a*/
    std::__shared_weak_count::__release_weak(this: v43); /*0x1066f3410*/
  }
  v44 = v71[0]; /*0x1066f3415*/
  RBX::Network::Replicator::setExpectedUserId(this: v71[0], a2: *((_QWORD *)this + 67)); /*0x1066f3423*/
  v59 = 0; /*0x1066f3432*/
  RBX::Instance::setAndLockParent(this: v44); /*0x1066f343d*/
  v46 = *((std::__shared_weak_count **)&v59 + 1); /*0x1066f3442*/
  if ( *((_QWORD *)&v59 + 1) != 0 /*0x1066f345e*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v59 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v46 + 16LL))(a1: v46); /*0x1066f3466*/
    std::__shared_weak_count::__release_weak(this: v46); /*0x1066f346c*/
  }
  v47 = RBX::DataModel::get(this, a2: v45); /*0x1066f3479*/
  std::string::basic_string[abi:ne200100]<0>(a1: v63, a2: "Connected to Server", a3: v48, a4: v49); /*0x1066f348a*/
  std::string::operator=(a1: v47 + 2280, a2: v63); /*0x1066f34a0*/
  if ( (v63[0] & 1) != 0 ) /*0x1066f34ac*/
    operator delete(a1: (RBX::Memory *)v64, a2: v50); /*0x1066f34b5*/
  RBX::Network::RakNetAddressToString(this: (RBX::Network *)v68, a2, a3: true, a4: 124); /*0x1066f34cb*/
  v51 = (char *)this + 4824; /*0x1066f34d0*/
  *(_OWORD *)v72 = *(_OWORD *)v71; /*0x1066f34df*/
  if ( v71[1] != nullptr ) /*0x1066f34e6*/
    _InterlockedIncrement64((volatile signed __int64 *)v71[1] + 1); /*0x1066f34e8*/
  rbx::signal<void ()(std::string,std::shared_ptr<RBX::Instance>)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x1066f34f8*/
    a1: v51,
    a2: v68,
    a3: v72);
  v53 = v72[1]; /*0x1066f34fd*/
  if ( v72[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v72[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f3516*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v53 + 16LL))(a1: v53); /*0x1066f351e*/
    std::__shared_weak_count::__release_weak(this: v53); /*0x1066f3524*/
  }
  if ( ((__int64)v68[0] & 1) != 0 ) /*0x1066f352d*/
    operator delete(a1: (RBX::Memory *)v69, a2: v52); /*0x1066f3533*/
  v54 = *((std::__shared_weak_count **)&v61 + 1); /*0x1066f3538*/
  if ( *((_QWORD *)&v61 + 1) != 0 /*0x1066f3554*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v61 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v54 + 16LL))(a1: v54); /*0x1066f355c*/
    std::__shared_weak_count::__release_weak(this: v54); /*0x1066f3562*/
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v56); /*0x1066f356e*/
  v55 = v71[1]; /*0x1066f3573*/
  if ( v71[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v71[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f358c*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v55 + 16LL))(a1: v55); /*0x1066f3594*/
    std::__shared_weak_count::__release_weak(this: v55); /*0x1066f359a*/
  }
}

// Address: 0x1066f371e | Name: __ZN3RBX7Network6Client18OnClosedConnectionERKN6RakNet13SystemAddressE
__int64 __fastcall RBX::Network::Client::OnClosedConnection(
        RBX::Network::Client *this,
        const RakNet::SystemAddress *a2)
{
  char __s1[1032]; // [rsp+0h] [rbp-420h] BYREF

  RakNet::SystemAddress::ToStringN(this: a2, a2: true, a3: __s1, a4: 1025, a5: 124); /*0x1066f375a*/
  RBX::Network::Client::updateServerConnectionState(this, __s1, a3: 4, a4: (__int64)"", a5: 1); /*0x1066f3777*/
  return __stack_chk_guard; /*0x1066f378c*/
}

// Address: 0x1066f379e | Name: __ZN3RBX7Network6Client29OnReceiveOpenConnectionReply1Ev
void __fastcall RBX::Network::Client::OnReceiveOpenConnectionReply1(RBX::Network::Client *this)
{
  *((_BYTE *)this + 600) = 1; /*0x1066f37a2*/
}

// Address: 0x1066f37ac | Name: __ZThn176_N3RBX7Network6Client29OnReceiveOpenConnectionReply1Ev
void __fastcall `non-virtual thunk to'RBX::Network::Client::OnReceiveOpenConnectionReply1(RBX::Network::Client *this)
{
  *((_BYTE *)this + 424) = 1; /*0x1066f37b0*/
}

// Address: 0x1066f37ba | Name: __ZN3RBX7Network6Client29OnReceiveOpenConnectionReply2Ev
void __fastcall RBX::Network::Client::OnReceiveOpenConnectionReply2(RBX::Network::Client *this)
{
  *((_BYTE *)this + 601) = 1; /*0x1066f37be*/
}

// Address: 0x1066f37c8 | Name: __ZThn176_N3RBX7Network6Client29OnReceiveOpenConnectionReply2Ev
void __fastcall `non-virtual thunk to'RBX::Network::Client::OnReceiveOpenConnectionReply2(RBX::Network::Client *this)
{
  *((_BYTE *)this + 425) = 1; /*0x1066f37cc*/
}

// Address: 0x1066f37d6 | Name: __ZN3RBX7Network6Client26OnConnectFirstStageTimeoutERKN6RakNet13SystemAddressE
__int64 __fastcall RBX::Network::Client::OnConnectFirstStageTimeout(
        RBX::Network::Client *this,
        const RakNet::SystemAddress *a2)
{
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // rax
  __int64 v6; // rdx
  __int64 v7; // rcx
  void *v8; // rsi
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // rdx
  __int64 v12; // rcx
  void *v13; // rsi
  const char *v14; // rcx
  const char *v15; // rsi
  _BYTE v17[40]; // [rsp+0h] [rbp-4E0h] BYREF
  _BYTE *v18; // [rsp+28h] [rbp-4B8h] BYREF
  _QWORD v19[4]; // [rsp+30h] [rbp-4B0h] BYREF
  int v20; // [rsp+50h] [rbp-490h]
  _BYTE v21[16]; // [rsp+58h] [rbp-488h] BYREF
  void *v22; // [rsp+68h] [rbp-478h]
  _BYTE v23[16]; // [rsp+70h] [rbp-470h] BYREF
  void *v24; // [rsp+80h] [rbp-460h]
  _BYTE v25[16]; // [rsp+88h] [rbp-458h] BYREF
  void *v26; // [rsp+98h] [rbp-448h]
  _BYTE v27[16]; // [rsp+A0h] [rbp-440h] BYREF
  void *v28; // [rsp+B0h] [rbp-430h]
  char v29; // [rsp+BFh] [rbp-421h] BYREF
  char v30[1032]; // [rsp+C0h] [rbp-420h] BYREF

  RakNet::SystemAddress::ToStringN(this: a2, a2: true, a3: v30, a4: 1025, a5: 124); /*0x1066f380f*/
  memset(v19, 0, sizeof(v19)); /*0x1066f381e*/
  v20 = 1065353216; /*0x1066f3825*/
  std::string::basic_string[abi:ne200100]<0>(a1: v21, a2: "gameJoinFailureReason", a3: v3, a4: v4); /*0x1066f3840*/
  v18 = v21; /*0x1066f384c*/
  v5 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1066f3867*/
         a1: v19,
         a2: v21,
         a3: std::piecewise_construct,
         a4: &v18,
         a5: &v29);
  std::string::assign(a1: v5 + 40, a2: "ConnectTimeOut"); /*0x1066f387a*/
  if ( (v21[0] & 1) != 0 ) /*0x1066f3886*/
    operator delete(a1: (RBX::Memory *)v22, a2: v8); /*0x1066f388f*/
  std::string::basic_string[abi:ne200100]<0>(a1: v23, a2: "client", a3: v6, a4: v7); /*0x1066f38a2*/
  std::string::basic_string[abi:ne200100]<0>(a1: v25, a2: "report", a3: v9, a4: v10); /*0x1066f38b5*/
  std::string::basic_string[abi:ne200100]<0>(a1: v27, a2: "GameJoinFailure", a3: v11, a4: v12); /*0x1066f38c8*/
  std::unordered_map<std::string,std::string>::unordered_map(a1: v17, a2: v19); /*0x1066f38db*/
  RBX::Analytics::EventIngest::setRBXEvent(a1: v23, a2: v25, a3: v27, a4: v17); /*0x1066f38fc*/
  std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v17); /*0x1066f3908*/
  if ( (v27[0] & 1) != 0 ) /*0x1066f3914*/
    operator delete(a1: (RBX::Memory *)v28, a2: v13); /*0x1066f391d*/
  if ( (v25[0] & 1) != 0 ) /*0x1066f3929*/
    operator delete(a1: (RBX::Memory *)v26, a2: v13); /*0x1066f3932*/
  if ( (v23[0] & 1) != 0 ) /*0x1066f393e*/
    operator delete(a1: (RBX::Memory *)v24, a2: v13); /*0x1066f3947*/
  v14 = "ConnectFailed_Timeout_FirstReplyOnly"; /*0x1066f3953*/
  if ( *((_BYTE *)this + 601) != 0 ) /*0x1066f3961*/
    v14 = "ConnectFailed_Timeout_FirstAndSecondReplied"; /*0x1066f3961*/
  v15 = "ConnectFailed_Timeout_NoReplies"; /*0x1066f396c*/
  if ( *((_BYTE *)this + 601) != 0 ) /*0x1066f3973*/
    v15 = "ConnectFailed_Timeout_SecondReplyOnly"; /*0x1066f3973*/
  if ( *((_BYTE *)this + 600) != 0 ) /*0x1066f397e*/
    v15 = v14; /*0x1066f397e*/
  RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066f399d*/
    (RBX::Network::ConcurrentRakPeer **)this,
    a2: v15,
    a3: 1u,
    a4: v30,
    a5: 3,
    a6: 1);
  std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v19); /*0x1066f39a9*/
  return __stack_chk_guard; /*0x1066f39be*/
}

// Address: 0x1066f3a62 | Name: __ZThn176_N3RBX7Network6Client26OnConnectFirstStageTimeoutERKN6RakNet13SystemAddressE
__int64 __fastcall `non-virtual thunk to'RBX::Network::Client::OnConnectFirstStageTimeout(
        RBX::Network::Client *this,
        const RakNet::SystemAddress *a2)
{
  return RBX::Network::Client::OnConnectFirstStageTimeout(this: (RBX::Network::Client *)((char *)this - 176), a2); /*0x1066f3a6d*/
}

// Address: 0x1066f3a74 | Name: __ZN3RBX7Network6Client47OnFailedToIncludeRemoteSystemInRemoteSystemListERKN6RakNet13SystemAddressE
__int64 __fastcall RBX::Network::Client::OnFailedToIncludeRemoteSystemInRemoteSystemList(
        RBX::Network::ConcurrentRakPeer **this,
        const RakNet::SystemAddress *a2)
{
  char v4[1032]; // [rsp+0h] [rbp-420h] BYREF

  RakNet::SystemAddress::ToStringN(this: a2, a2: true, a3: v4, a4: 1025, a5: 124); /*0x1066f3ab0*/
  RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066f3ad3*/
    this,
    a2: "ConnectFailed_InternalRakNet",
    a3: 1u,
    a4: v4,
    a5: 3,
    a6: 1);
  return __stack_chk_guard; /*0x1066f3ae8*/
}

// Address: 0x1066f3afa | Name: __ZThn176_N3RBX7Network6Client47OnFailedToIncludeRemoteSystemInRemoteSystemListERKN6RakNet13SystemAddressE
__int64 __fastcall `non-virtual thunk to'RBX::Network::Client::OnFailedToIncludeRemoteSystemInRemoteSystemList(
        RBX::Network::ConcurrentRakPeer **this,
        const RakNet::SystemAddress *a2)
{
  return RBX::Network::Client::OnFailedToIncludeRemoteSystemInRemoteSystemList(this: this - 22, a2); /*0x1066f3b05*/
}

// Address: 0x1066f3b0c | Name: __ZN3RBX7Network6Client35OnTimeoutWaitingForPasswordAcceptedERKN6RakNet13SystemAddressE
__int64 __fastcall RBX::Network::Client::OnTimeoutWaitingForPasswordAccepted(
        RBX::Network::ConcurrentRakPeer **this,
        const RakNet::SystemAddress *a2)
{
  char v4[1032]; // [rsp+0h] [rbp-420h] BYREF

  RakNet::SystemAddress::ToStringN(this: a2, a2: true, a3: v4, a4: 1025, a5: 124); /*0x1066f3b48*/
  RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066f3b6b*/
    this,
    a2: "TimeoutRakNetPassword",
    a3: 1u,
    a4: v4,
    a5: 3,
    a6: 1);
  return __stack_chk_guard; /*0x1066f3b80*/
}

// Address: 0x1066f3b92 | Name: __ZThn176_N3RBX7Network6Client35OnTimeoutWaitingForPasswordAcceptedERKN6RakNet13SystemAddressE
__int64 __fastcall `non-virtual thunk to'RBX::Network::Client::OnTimeoutWaitingForPasswordAccepted(
        RBX::Network::ConcurrentRakPeer **this,
        const RakNet::SystemAddress *a2)
{
  return RBX::Network::Client::OnTimeoutWaitingForPasswordAccepted(this: this - 22, a2); /*0x1066f3b9d*/
}

// Address: 0x1066f3ba4 | Name: __ZN3RBX7Network6Client32OnReliabilityLayerDeadConnectionERKN6RakNet13SystemAddressE
__int64 __fastcall RBX::Network::Client::OnReliabilityLayerDeadConnection(
        RBX::Network::ConcurrentRakPeer **this,
        const RakNet::SystemAddress *a2,
        __int64 a3,
        __int64 a4)
{
  unsigned __int64 v6; // rax
  const char *v7; // rsi
  void *v8; // rsi
  RBX::Network::Replicator *v9; // rdi
  char v11; // [rsp+8h] [rbp-438h] BYREF
  char v12; // [rsp+9h] [rbp-437h] BYREF
  void *v13; // [rsp+18h] [rbp-428h]
  char v14[1032]; // [rsp+20h] [rbp-420h] BYREF

  std::string::basic_string[abi:ne200100]<0>(a1: &v11, a2: "LostReliableConnection", a3, a4); /*0x1066f3bd4*/
  RakNet::SystemAddress::ToStringN(this: a2, a2: true, a3: v14, a4: 1025, a5: 124); /*0x1066f3bf3*/
  v6 = *((unsigned int *)this + 158); /*0x1066f3bf8*/
  if ( v6 > 3 ) /*0x1066f3c02*/
    std::string::append(a1: &v11, a2: ""); /*0x1066f3c1f*/
  else
    std::string::append(a1: &v11, a2: off_10CAA7E78[v6]); /*0x1066f3c0f*/
  if ( (v11 & 1) != 0 ) /*0x1066f3c2b*/
    v7 = (const char *)v13; /*0x1066f3c2d*/
  else
    v7 = &v12; /*0x1066f3c36*/
  RBX::Network::Client::handleConnectionStateAndMetricReporting(this, a2: v7, a3: 1u, a4: v14, a5: 3, a6: 1); /*0x1066f3c58*/
  v9 = *(this + 574); /*0x1066f3c5d*/
  if ( v9 != nullptr ) /*0x1066f3c67*/
    RBX::Network::Replicator::safeSetDisconnectReason(this: v9, a2: 0x115u); /*0x1066f3c6e*/
  if ( (v11 & 1) != 0 ) /*0x1066f3c7a*/
    operator delete(a1: (RBX::Memory *)v13, a2: v8); /*0x1066f3c83*/
  return __stack_chk_guard; /*0x1066f3c98*/
}

// Address: 0x1066f3cce | Name: __ZThn176_N3RBX7Network6Client32OnReliabilityLayerDeadConnectionERKN6RakNet13SystemAddressE
__int64 __fastcall `non-virtual thunk to'RBX::Network::Client::OnReliabilityLayerDeadConnection(
        RBX::Network::ConcurrentRakPeer **this,
        const RakNet::SystemAddress *a2,
        __int64 a3,
        __int64 a4)
{
  return RBX::Network::Client::OnReliabilityLayerDeadConnection(this: this - 22, a2, a3, a4); /*0x1066f3cd9*/
}

// Address: 0x1066f3ce0 | Name: __ZN3RBX7Network6Client24OnRemoteActiveDisconnectERKN6RakNet13SystemAddressE
__int64 __fastcall RBX::Network::Client::OnRemoteActiveDisconnect(
        RBX::Network::ConcurrentRakPeer **this,
        const RakNet::SystemAddress *a2,
        __int64 a3,
        __int64 a4)
{
  unsigned __int64 v6; // rax
  const char *v7; // rsi
  void *v8; // rsi
  char v10; // [rsp+8h] [rbp-438h] BYREF
  char v11; // [rsp+9h] [rbp-437h] BYREF
  void *v12; // [rsp+18h] [rbp-428h]
  char v13[1032]; // [rsp+20h] [rbp-420h] BYREF

  std::string::basic_string[abi:ne200100]<0>(a1: &v10, a2: "RemoteActiveDisconnect", a3, a4); /*0x1066f3d10*/
  RakNet::SystemAddress::ToStringN(this: a2, a2: true, a3: v13, a4: 1025, a5: 124); /*0x1066f3d2f*/
  v6 = *((unsigned int *)this + 158); /*0x1066f3d34*/
  if ( v6 > 3 ) /*0x1066f3d3e*/
    std::string::append(a1: &v10, a2: ""); /*0x1066f3d5b*/
  else
    std::string::append(a1: &v10, a2: off_10CAA7E78[v6]); /*0x1066f3d4b*/
  if ( (v10 & 1) != 0 ) /*0x1066f3d67*/
    v7 = (const char *)v12; /*0x1066f3d69*/
  else
    v7 = &v11; /*0x1066f3d72*/
  RBX::Network::Client::handleConnectionStateAndMetricReporting(this, a2: v7, a3: 1u, a4: v13, a5: 3, a6: 1); /*0x1066f3d94*/
  if ( (v10 & 1) != 0 ) /*0x1066f3da0*/
    operator delete(a1: (RBX::Memory *)v12, a2: v8); /*0x1066f3da9*/
  return __stack_chk_guard; /*0x1066f3dbe*/
}

// Address: 0x1066f3df4 | Name: __ZThn176_N3RBX7Network6Client24OnRemoteActiveDisconnectERKN6RakNet13SystemAddressE
__int64 __fastcall `non-virtual thunk to'RBX::Network::Client::OnRemoteActiveDisconnect(
        RBX::Network::ConcurrentRakPeer **this,
        const RakNet::SystemAddress *a2,
        __int64 a3,
        __int64 a4)
{
  return RBX::Network::Client::OnRemoteActiveDisconnect(this: this - 22, a2, a3, a4); /*0x1066f3dff*/
}

// Address: 0x1066f3e06 | Name: __ZN3RBX7Network6Client22sendPreferredSpawnNameEv
void __fastcall RBX::Network::Client::sendPreferredSpawnName(RBX::Network::ConcurrentRakPeer **this)
{
  RBX::TeleportService *v2; // rax
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 SpawnName; // rax
  RBX::Network *v6; // rdi
  void *v7; // rsi
  FLog *v8; // r14
  __int64 v9; // r15
  const char *v10; // rcx
  void *v11; // rsi
  unsigned __int64 v12; // rsi
  __int64 v13; // r14
  __int64 v14; // rax
  __int64 *v15; // rbx
  __int64 v16; // rdi
  std::__shared_weak_count *v17; // rbx
  std::__shared_weak_count *v18; // rbx
  __int64 v19; // r14
  _BYTE v20[64]; // [rsp+20h] [rbp-A0h] BYREF
  __int64 v21; // [rsp+60h] [rbp-60h] BYREF
  std::__shared_weak_count *v22; // [rsp+68h] [rbp-58h]
  std::__shared_weak_count *v23[2]; // [rsp+70h] [rbp-50h] BYREF
  RBX::Network *v24; // [rsp+80h] [rbp-40h]

  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v20); /*0x1066f3e23*/
  LOBYTE(v23[0]) = -113; /*0x1066f3e2c*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v20, a2: v23, a3: 1u); /*0x1066f3e37*/
  v2 = (RBX::TeleportService *)RBX::ServiceProvider::find<RBX::TeleportService>(a1: this); /*0x1066f3e3f*/
  if ( v2 != nullptr ) /*0x1066f3e47*/
  {
    SpawnName = RBX::TeleportService::getSpawnName(this: v2); /*0x1066f3e4c*/
    if ( (*(_BYTE *)SpawnName & 1) != 0 ) /*0x1066f3e54*/
    {
      std::string::__init_copy_ctor_external(a1: v23, a2: *(_QWORD *)(SpawnName + 16), a3: *(_QWORD *)(SpawnName + 8)); /*0x1066f3e85*/
    }
    else
    {
      v24 = *(RBX::Network **)(SpawnName + 16); /*0x1066f3e5a*/
      *(_OWORD *)v23 = *(_OWORD *)SpawnName; /*0x1066f3e61*/
    }
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v23, a2: "", a3: v3, a4: v4); /*0x1066f3e72*/
  }
  RBX::Network::serializeString(a1: v23, a2: v20, a3: (unsigned int)DFInt::CliMaxPayloadSnd); /*0x1066f3e9b*/
  if ( ((__int64)v23[0] & 1) != 0 ) /*0x1066f3ea4*/
    operator delete(a1: v24, a2: v7); /*0x1066f3eaa*/
  v8 = (FLog *)FLog::Network; /*0x1066f3eb6*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
  {
    v9 = qword_10D7BBAA8; /*0x1066f3ed0*/
    RBX::Network::RakNetAddressToString( /*0x1066f3ee9*/
      this: (RBX::Network *)v23,
      a2: (const RakNet::SystemAddress *)(this + 63),
      a3: true,
      a4: 124);
    v10 = ((__int64)v23[0] & 1) != 0 ? (const char *)v24 : (char *)v23 + 1;
    FLog::FastLogS(this: v8, a2: v9, a3: (unsigned __int64)"[FLog::Network] serverId: %s", a4: v10);
    if ( ((__int64)v23[0] & 1) != 0 ) /*0x1066f3f14*/
      operator delete(a1: v24, a2: v11); /*0x1066f3f1a*/
  }
  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v6) != 0 ) /*0x1066f3f26*/
  {
    v13 = operator new(a1: (RBX::Memory *)0x58, a2: v12); /*0x1066f3f36*/
    *(_OWORD *)(v13 + 8) = 0; /*0x1066f3f3c*/
    *(_QWORD *)v13 = &off_10CAAE190; /*0x1066f3f47*/
    RBX::Network::NetworkStream::NetworkStream(a1: v13 + 24, a2: v20); /*0x1066f3f5b*/
    v14 = (__int64)*(this + 574); /*0x1066f3f60*/
    v15 = (__int64 *)(this + 575); /*0x1066f3f6e*/
    if ( v14 != 0 ) /*0x1066f3f78*/
      v15 = (__int64 *)(v14 + 280); /*0x1066f3f78*/
    v16 = *v15; /*0x1066f3f7c*/
    v21 = v13 + 24; /*0x1066f3f83*/
    v22 = (std::__shared_weak_count *)v13; /*0x1066f3f86*/
    *(_OWORD *)v23 = 0; /*0x1066f3f8d*/
    (*(void (__fastcall **)(__int64, __int64, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v16 + 48LL))( /*0x1066f3f9e*/
      a1: v16,
      a2: 1,
      a3: &v21,
      a4: 0,
      a5: 0);
    v17 = v22; /*0x1066f3fa1*/
    if ( v22 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v22 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f3fba*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x1066f3fc2*/
      std::__shared_weak_count::__release_weak(this: v17); /*0x1066f3fc8*/
    }
    v18 = v23[1]; /*0x1066f3fcd*/
    if ( v23[1] != nullptr /*0x1066f3fea*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v23[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(a1: v18); /*0x1066f3ff2*/
      std::__shared_weak_count::__release_weak(this: v18); /*0x1066f3ff8*/
    }
  }
  else
  {
    v19 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(this + 36)); /*0x1066f400b*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x1066f401c*/
      this: (RakNet::AddressOrGUID *)v23,
      a2: (const RakNet::SystemAddress *)(this + 63));
    (*(void (__fastcall **)(__int64, _BYTE *, __int64, __int64, _QWORD, std::__shared_weak_count **, _DWORD, _DWORD, _QWORD))(*(_QWORD *)v19 + 184LL))( /*0x1066f4058*/
      a1: v19,
      a2: v20,
      a3: 2,
      a4: 3,
      a5: 0,
      a6: v23,
      a7: 0,
      a8: 0,
      a9: 0);
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v20); /*0x1066f4061*/
}

// Address: 0x1066f4112 | Name: __ZN3RBX7Network6Client16HandleConnectionEv
__int64 __fastcall RBX::Network::Client::HandleConnection(RBX::Network::Client *this)
{
  RBX *v2; // rdi
  __int64 v3; // r14
  RBX::Security *v4; // rdi
  int VersionKey2; // eax
  RBX::Network::NetworkStream *v6; // rdx
  unsigned __int64 v7; // rsi
  __int64 v8; // r15
  __int64 v9; // rax
  __int64 *v10; // rcx
  __int64 v11; // rdi
  std::__shared_weak_count *v12; // r15
  std::__shared_weak_count *v13; // r15
  RBX::Network::ConnectionInfo *ConnectionInfo; // rax
  unsigned __int64 v15; // rdx
  unsigned __int64 v16; // rax
  char *v17; // rsi
  unsigned __int64 v18; // rdx
  unsigned __int64 v19; // rax
  char *v20; // r12
  unsigned __int64 v21; // r15
  const char *v22; // r13
  unsigned __int16 v23; // ax
  void *v24; // rsi
  RBX::Workspace *v25; // rax
  __int128 *v26; // rsi
  __int64 v27; // rdx
  __int64 v28; // rsi
  __int64 v29; // r8
  __int64 v30; // r9
  __int64 v31; // rax
  _QWORD *v32; // rcx
  RBX::EngineContext *v33; // rdi
  __int128 v34; // xmm0
  volatile signed __int64 *v35; // r15
  std::__shared_weak_count *v36; // r15
  RBX::Network::Replicator *v37; // r15
  __int64 v38; // rax
  char *v39; // rcx
  std::__shared_weak_count *v40; // r15
  __int64 v41; // rax
  __int128 v42; // xmm0
  volatile signed __int64 *v43; // r15
  std::__shared_weak_count *v44; // rdi
  std::__shared_weak_count *v45; // r15
  RBX::Instance *v46; // rsi
  std::__shared_weak_count *v47; // r15
  __int64 v48; // r15
  __int64 v49; // rdx
  __int64 v50; // rcx
  void *v51; // rsi
  __int64 v52; // rax
  RBX::NetworkBase::ConnectionInternal **v53; // rcx
  RBX::Network::ConnectionInfo *v54; // rax
  __int64 v55; // rax
  __int64 v56; // rdx
  char *v57; // rbx
  void *v58; // rsi
  std::__shared_weak_count *v59; // rbx
  std::__shared_weak_count *v60; // rbx
  std::__shared_weak_count *v61; // rbx
  __int128 v63; // [rsp+0h] [rbp-170h] BYREF
  __int128 v64; // [rsp+10h] [rbp-160h]
  __int64 v65; // [rsp+20h] [rbp-150h] BYREF
  std::__shared_weak_count *v66; // [rsp+28h] [rbp-148h]
  __int128 v67; // [rsp+30h] [rbp-140h]
  _BYTE v68[16]; // [rsp+48h] [rbp-128h] BYREF
  void *v69; // [rsp+58h] [rbp-118h]
  std::__shared_weak_count *v70[2]; // [rsp+60h] [rbp-110h] BYREF
  std::__shared_weak_count *v71[2]; // [rsp+70h] [rbp-100h] BYREF
  void *v72; // [rsp+80h] [rbp-F0h]
  std::__shared_weak_count *v73[2]; // [rsp+98h] [rbp-D8h]
  __int64 v74; // [rsp+A8h] [rbp-C8h]
  char *v75; // [rsp+B0h] [rbp-C0h] BYREF
  unsigned __int64 v76; // [rsp+B8h] [rbp-B8h]
  RBX::Network::Replicator *v77[2]; // [rsp+C0h] [rbp-B0h]
  std::__shared_weak_count *v78[2]; // [rsp+D0h] [rbp-A0h] BYREF
  void *v79; // [rsp+E0h] [rbp-90h]
  __int64 v80[2]; // [rsp+F0h] [rbp-80h] BYREF
  void *v81; // [rsp+100h] [rbp-70h]
  _BYTE v82[48]; // [rsp+110h] [rbp-60h] BYREF

  *(_OWORD *)v77 = 0; /*0x1066f413a*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v80); /*0x1066f4145*/
  LOBYTE(v71[0]) = -110; /*0x1066f4151*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v80, a2: v71, a3: 1u); /*0x1066f415d*/
  v3 = (unsigned int)RBX::globalRand(this: v2); /*0x1066f4167*/
  VersionKey2 = RBX::Security::getVersionKey2(this: v4); /*0x1066f416a*/
  RBX::Network::serializeSignedVarint64( /*0x1066f4180*/
    this: (RBX::Network *)((v3 << 32) | (unsigned int)v3 ^ VersionKey2),
    a2: (__int64)v80,
    a3: v6);
  v8 = operator new(a1: (RBX::Memory *)0x58, a2: v7); /*0x1066f418f*/
  *(_OWORD *)(v8 + 8) = 0; /*0x1066f4195*/
  *(_QWORD *)v8 = &off_10CAAE190; /*0x1066f41a0*/
  RBX::Network::NetworkStream::NetworkStream(a1: v8 + 24, a2: v80); /*0x1066f41b1*/
  v9 = *((_QWORD *)this + 574); /*0x1066f41b6*/
  v10 = (__int64 *)(v9 + 280); /*0x1066f41bd*/
  if ( v9 == 0 ) /*0x1066f41ce*/
    v10 = (__int64 *)((char *)this + 4600); /*0x1066f41ce*/
  v11 = *v10; /*0x1066f41d2*/
  v65 = v8 + 24; /*0x1066f41dc*/
  v66 = (std::__shared_weak_count *)v8; /*0x1066f41df*/
  *(_OWORD *)v71 = 0; /*0x1066f41e6*/
  (*(void (__fastcall **)(__int64, __int64, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v11 + 48LL))( /*0x1066f41fa*/
    a1: v11,
    a2: 1,
    a3: &v65,
    a4: 0,
    a5: 0);
  v12 = v66; /*0x1066f41fd*/
  if ( v66 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v66 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f4219*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x1066f4221*/
    std::__shared_weak_count::__release_weak(this: v12); /*0x1066f4227*/
  }
  v13 = v71[1]; /*0x1066f422c*/
  if ( v71[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v71[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f4248*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x1066f4250*/
    std::__shared_weak_count::__release_weak(this: v13); /*0x1066f4256*/
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v80); /*0x1066f425f*/
  RBX::Network::Client::sendTicket((RBX::Network **)this); /*0x1066f4267*/
  v64 = *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1); /*0x1066f4273*/
  v63 = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1066f4281*/
  if ( DFFlag::RemoveUnassignedSystemAddress == 1 ) /*0x1066f428f*/
  {
    ConnectionInfo = (RBX::Network::ConnectionInfo *)RBX::NetworkBase::ConnectionInternal::getConnectionInfo(this: *((RBX::NetworkBase::ConnectionInternal **)this + 575)); /*0x1066f4298*/
    v75 = (char *)RBX::Network::ConnectionInfo::toString(this: ConnectionInfo, a2: true); /*0x1066f42b1*/
    v76 = v15; /*0x1066f42b4*/
    LOBYTE(v80[0]) = 124; /*0x1066f42bc*/
    v16 = RBX::detail::StringViewBase::find(a1: &v75, a2: v80, a3: 1, a4: 0); /*0x1066f42c6*/
    if ( v16 == -1 ) /*0x1066f42cf*/
    {
      v17 = v75; /*0x1066f42fc*/
      v18 = v76; /*0x1066f4303*/
      v21 = 0; /*0x1066f430a*/
      v20 = nullptr; /*0x1066f430d*/
    }
    else
    {
      v17 = v75; /*0x1066f42d1*/
      v18 = v16; /*0x1066f42e2*/
      if ( v76 < v16 ) /*0x1066f42e5*/
        v18 = v76; /*0x1066f42e5*/
      v19 = v16 + 1; /*0x1066f42e9*/
      if ( v76 < v19 ) /*0x1066f42ef*/
        v19 = v76; /*0x1066f42ef*/
      v20 = &v75[v19]; /*0x1066f42f3*/
      v21 = v76 - v19; /*0x1066f42f7*/
    }
    if ( v17 != nullptr ) /*0x1066f4313*/
    {
      std::string::basic_string[abi:ne200100](a1: v71, a2: v17, a3: v18); /*0x1066f431c*/
      if ( ((__int64)v71[0] & 1) != 0 ) /*0x1066f4328*/
        v22 = (const char *)v72; /*0x1066f434c*/
      else
        v22 = (char *)v71 + 1; /*0x1066f432a*/
    }
    else
    {
      v22 = (char *)v71 + 1; /*0x1066f4336*/
      *(_OWORD *)v71 = 0; /*0x1066f433d*/
      v72 = nullptr; /*0x1066f4342*/
    }
    if ( v20 != nullptr ) /*0x1066f4356*/
    {
      std::string::basic_string[abi:ne200100](a1: v78, a2: v20, a3: v21); /*0x1066f4365*/
    }
    else
    {
      *(_OWORD *)v78 = 0; /*0x1066f436f*/
      v79 = nullptr; /*0x1066f4376*/
    }
    v23 = std::stoi(a1: v78, a2: 0, a3: 10); /*0x1066f438f*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v80, a2: v22, a3: v23); /*0x1066f439e*/
    RakNet::SystemAddress::operator=(a1: &v63, a2: v80); /*0x1066f43ae*/
    if ( ((__int64)v78[0] & 1) != 0 ) /*0x1066f43ba*/
      operator delete(a1: (RBX::Memory *)v79, a2: v24); /*0x1066f43c3*/
    if ( ((__int64)v71[0] & 1) != 0 ) /*0x1066f43cf*/
      operator delete(a1: (RBX::Memory *)v72, a2: v24); /*0x1066f43d8*/
    RakNet::SystemAddress::operator=(a1: (char *)this + 504, a2: &v63); /*0x1066f43eb*/
  }
  RBX::Network::Client::sendPreferredSpawnName((RBX::Network::ConcurrentRakPeer **)this); /*0x1066f43f3*/
  v25 = (RBX::Workspace *)RBX::ServiceProvider::find<RBX::Workspace>(a1: this); /*0x1066f43fb*/
  RBX::Workspace::clearTerrain(this: v25); /*0x1066f4403*/
  LODWORD(v71[0]) = -1; /*0x1066f440f*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)((char *)v71 + 4)); /*0x1066f441a*/
  *(_OWORD *)v73 = 0; /*0x1066f4422*/
  v26 = &v63; /*0x1066f4437*/
  if ( DFFlag::RemoveUnassignedSystemAddress == 0 ) /*0x1066f443e*/
    v26 = (__int128 *)&RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1066f443e*/
  RakNet::SystemAddress::operator=(a1: (char *)v71 + 4, a2: v26); /*0x1066f4445*/
  LODWORD(v71[0]) = 1; /*0x1066f444a*/
  v31 = *((_QWORD *)this + 574); /*0x1066f4454*/
  v32 = (_QWORD *)(v31 + 280); /*0x1066f445b*/
  if ( v31 == 0 ) /*0x1066f4465*/
    v32 = (_QWORD *)((char *)this + 4600); /*0x1066f4465*/
  v74 = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, _QWORD *, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)*v32 + 56LL))( /*0x1066f4472*/
          a1: *v32,
          a2: v28,
          a3: v27,
          a4: v32,
          a5: v29,
          a6: v30,
          a7: v63,
          a8: *((_QWORD *)&v63 + 1),
          a9: v64,
          a10: *((_QWORD *)&v64 + 1));
  v75 = (char *)this + 696; /*0x1066f4480*/
  v80[0] = RBX::EngineContext::getThreadLocal(this: v33); /*0x1066f4490*/
  LODWORD(v80[1]) = 10074; /*0x1066f4493*/
  RBX::Creatable::createImpl<RBX::Network::ClientReplicator,RBX::ForceConstructionInCreatable &,RBX::Network::Replicator::ReplicatorPeerInfo,RBX::Network::MegaReplicator *,std::unique_ptr<RBX::NetworkBase::ConnectionInternal>>( /*0x1066f44b2*/
    a1: v78,
    a2: v80,
    a3: v71,
    a4: &v75,
    a5: (char *)this + 4600);
  v34 = *(_OWORD *)v78; /*0x1066f44b7*/
  *(_OWORD *)v78 = 0; /*0x1066f44c1*/
  v35 = (volatile signed __int64 *)v77[1]; /*0x1066f44c8*/
  *(_OWORD *)v77 = v34; /*0x1066f44cf*/
  if ( v35 != nullptr && _InterlockedExchangeAdd64(v35 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f44eb*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v35 + 16))(a1: v35); /*0x1066f44f3*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v35); /*0x1066f44f9*/
  }
  v36 = v78[1]; /*0x1066f44fe*/
  if ( v78[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v78[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f451a*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v36 + 16LL))(a1: v36); /*0x1066f4522*/
    std::__shared_weak_count::__release_weak(this: v36); /*0x1066f4528*/
  }
  v37 = v77[0]; /*0x1066f452d*/
  RBX::Network::Client::setClientReplicator(this, a2: v77[0]); /*0x1066f453a*/
  if ( DFFlag::RbxTransportSessionCrypto == 1 ) /*0x1066f4546*/
  {
    v38 = *((_QWORD *)this + 574); /*0x1066f454c*/
    v39 = (char *)(v38 + 280); /*0x1066f4553*/
    if ( v38 == 0 ) /*0x1066f455d*/
      v39 = (char *)this + 4600; /*0x1066f455d*/
    (*(void (__fastcall **)(__int64 *))(**(_QWORD **)v39 + 184LL))(a1: v80); /*0x1066f456b*/
    if ( v82[32] == 1 ) /*0x1066f4575*/
    {
      RBX::Security::QuicSessionCrypto::create(a1: v78, a2: v80, a3: v82, a4: 0); /*0x1066f458c*/
      *(_OWORD *)v70 = *(_OWORD *)v78; /*0x1066f459f*/
      if ( v78[1] != nullptr ) /*0x1066f45a9*/
        _InterlockedIncrement64((volatile signed __int64 *)v78[1] + 1); /*0x1066f45ab*/
      RBX::Network::Replicator::setSessionCrypto(a1: v37, a2: v70); /*0x1066f45ba*/
      v40 = v70[1]; /*0x1066f45bf*/
      if ( v70[1] != nullptr /*0x1066f45db*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v70[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v40 + 16LL))(a1: v40); /*0x1066f45e3*/
        std::__shared_weak_count::__release_weak(this: v40); /*0x1066f45e9*/
      }
      v41 = RBX::ServiceProvider::find<RBX::ContentProvider>(a1: this); /*0x1066f45f1*/
      if ( v41 != 0 ) /*0x1066f45f9*/
      {
        v42 = *(_OWORD *)v78; /*0x1066f45fb*/
        v43 = (volatile signed __int64 *)v78[1]; /*0x1066f4602*/
        if ( v78[1] != nullptr ) /*0x1066f460c*/
        {
          _InterlockedIncrement64((volatile signed __int64 *)v78[1] + 2); /*0x1066f460e*/
          _InterlockedIncrement64(v43 + 2); /*0x1066f4613*/
        }
        v44 = *(std::__shared_weak_count **)(v41 + 696); /*0x1066f4618*/
        *(_OWORD *)(v41 + 688) = v42; /*0x1066f461f*/
        if ( v44 != nullptr ) /*0x1066f4629*/
          std::__shared_weak_count::__release_weak(this: v44); /*0x1066f462b*/
        if ( v43 != nullptr ) /*0x1066f4633*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v43); /*0x1066f4638*/
      }
      v45 = v78[1]; /*0x1066f463d*/
      if ( v78[1] != nullptr /*0x1066f4659*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v78[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v45 + 16LL))(a1: v45); /*0x1066f4661*/
        std::__shared_weak_count::__release_weak(this: v45); /*0x1066f4667*/
      }
      v37 = v77[0]; /*0x1066f466c*/
    }
  }
  RBX::Network::Replicator::setExpectedUserId(this: v37, a2: *((_QWORD *)this + 67)); /*0x1066f467d*/
  v67 = 0; /*0x1066f468c*/
  RBX::Instance::setAndLockParent(this: v37); /*0x1066f4697*/
  v47 = *((std::__shared_weak_count **)&v67 + 1); /*0x1066f469c*/
  if ( *((_QWORD *)&v67 + 1) != 0 /*0x1066f46b8*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v67 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v47 + 16LL))(a1: v47); /*0x1066f46c0*/
    std::__shared_weak_count::__release_weak(this: v47); /*0x1066f46c6*/
  }
  v48 = RBX::DataModel::get(this, a2: v46); /*0x1066f46d3*/
  std::string::basic_string[abi:ne200100]<0>(a1: v68, a2: "Connected to Server", a3: v49, a4: v50); /*0x1066f46e4*/
  std::string::operator=(a1: v48 + 2280, a2: v68); /*0x1066f46fa*/
  if ( (v68[0] & 1) != 0 ) /*0x1066f4706*/
    operator delete(a1: (RBX::Memory *)v69, a2: v51); /*0x1066f470f*/
  v52 = *((_QWORD *)this + 574); /*0x1066f4714*/
  v53 = (RBX::NetworkBase::ConnectionInternal **)(v52 + 280); /*0x1066f471b*/
  if ( v52 == 0 ) /*0x1066f4725*/
    v53 = (RBX::NetworkBase::ConnectionInternal **)((char *)this + 4600); /*0x1066f4725*/
  v54 = (RBX::Network::ConnectionInfo *)RBX::NetworkBase::ConnectionInternal::getConnectionInfo(this: *v53); /*0x1066f472c*/
  v55 = RBX::Network::ConnectionInfo::toString(this: v54, a2: true); /*0x1066f4739*/
  if ( v55 != 0 ) /*0x1066f4741*/
  {
    std::string::basic_string[abi:ne200100](a1: v80, a2: v55, a3: v56); /*0x1066f474a*/
  }
  else
  {
    *(_OWORD *)v80 = 0; /*0x1066f4754*/
    v81 = nullptr; /*0x1066f4758*/
  }
  v57 = (char *)this + 4824; /*0x1066f4760*/
  *(_OWORD *)v78 = *(_OWORD *)v77; /*0x1066f4775*/
  if ( v77[1] != nullptr ) /*0x1066f477f*/
    _InterlockedIncrement64((volatile signed __int64 *)v77[1] + 1); /*0x1066f4781*/
  rbx::signal<void ()(std::string,std::shared_ptr<RBX::Instance>)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x1066f4794*/
    a1: v57,
    a2: v80,
    a3: v78);
  v59 = v78[1]; /*0x1066f4799*/
  if ( v78[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v78[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f47b5*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v59 + 16LL))(a1: v59); /*0x1066f47bd*/
    std::__shared_weak_count::__release_weak(this: v59); /*0x1066f47c3*/
  }
  if ( (v80[0] & 1) != 0 ) /*0x1066f47cc*/
    operator delete(a1: (RBX::Memory *)v81, a2: v58); /*0x1066f47d2*/
  v60 = v73[1]; /*0x1066f47d7*/
  if ( v73[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v73[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f47f3*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v60 + 16LL))(a1: v60); /*0x1066f47fb*/
    std::__shared_weak_count::__release_weak(this: v60); /*0x1066f4801*/
  }
  v61 = v77[1]; /*0x1066f4806*/
  if ( v77[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v77[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f4822*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v61 + 16LL))(a1: v61); /*0x1066f482a*/
    std::__shared_weak_count::__release_weak(this: v61); /*0x1066f4830*/
  }
  return __stack_chk_guard; /*0x1066f4845*/
}

// Address: 0x1066f4a14 | Name: __ZN3RBX7Network6Client27setUtProductPlatformVersionENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
__int64 __fastcall RBX::Network::Client::setUtProductPlatformVersion(__int64 a1, _QWORD *a2)
{
  __int64 v3; // r14
  __int64 result; // rax

  v3 = a1 + 4640; /*0x1066f4a1e*/
  if ( (*(_BYTE *)(a1 + 4640) & 1) != 0 ) /*0x1066f4a2c*/
    operator delete(a1: *(RBX::Memory **)(a1 + 4656), a2); /*0x1066f4a35*/
  result = a2[2]; /*0x1066f4a3a*/
  *(_QWORD *)(v3 + 16) = result; /*0x1066f4a3e*/
  *(_OWORD *)v3 = *(_OWORD *)a2; /*0x1066f4a45*/
  *(_WORD *)a2 = 0; /*0x1066f4a49*/
  return result; /*0x1066f4a4e*/
}

// Address: 0x1066f4a54 | Name: __ZNK3RBX7Network6Client24getConnectionNetworkPathEv
__int64 __fastcall RBX::Network::Client::getConnectionNetworkPath(RBX::Network::Client *this)
{
  __int64 result; // rax

  LOBYTE(result) = 2; /*0x1066f4a58*/
  if ( *((_BYTE *)this + 4722) == 0 ) /*0x1066f4a61*/
  {
    LOBYTE(result) = 3; /*0x1066f4a63*/
    if ( *((_BYTE *)this + 4817) == 0 ) /*0x1066f4a6c*/
      LOBYTE(result) = *((_BYTE *)this + 4720); /*0x1066f4a6e*/
  }
  return (unsigned __int8)result; /*0x1066f4a77*/
}

// Address: 0x1066f4a7a | Name: __ZN3RBX7Network6Client17sendEarlyAuthDataEv
void __fastcall RBX::Network::Client::sendEarlyAuthData(RBX::Network::Client *this)
{
  __int64 v2; // rax
  _QWORD *v3; // rcx
  char *v4; // r12
  unsigned __int8 v5; // al
  char v6; // al
  unsigned int v7; // edx
  char *v8; // rsi
  __int64 v9; // rdx
  unsigned __int8 v10; // al
  char v11; // al
  unsigned int v12; // edx
  char *v13; // rsi
  __int64 v14; // rdx
  unsigned __int64 v15; // rsi
  __int64 v16; // r14
  __int64 v17; // rax
  __int64 *v18; // rcx
  __int64 v19; // rdi
  std::__shared_weak_count *v20; // rbx
  std::__shared_weak_count *v21; // rbx
  __int64 v22; // [rsp+10h] [rbp-80h] BYREF
  std::__shared_weak_count *v23; // [rsp+18h] [rbp-78h]
  _QWORD v24[8]; // [rsp+20h] [rbp-70h] BYREF
  std::__shared_weak_count *v25[2]; // [rsp+60h] [rbp-30h] BYREF

  if ( *((_BYTE *)this + 5080) != 0 ) /*0x1066f4a90*/
  {
    v2 = *((_QWORD *)this + 574); /*0x1066f4a95*/
    v3 = (_QWORD *)(v2 + 280); /*0x1066f4a9c*/
    v4 = (char *)this + 4600; /*0x1066f4aa3*/
    if ( v2 == 0 ) /*0x1066f4aad*/
      v3 = (_QWORD *)((char *)this + 4600); /*0x1066f4aad*/
    if ( *v3 != 0 ) /*0x1066f4ab5*/
    {
      RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v24); /*0x1066f4ac2*/
      LOBYTE(v25[0]) = -88; /*0x1066f4acb*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v24, a2: v25, a3: 1u); /*0x1066f4ad6*/
      LOBYTE(v25[0]) = *((_BYTE *)this + 5072); /*0x1066f4ae5*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v24, a2: v25, a3: 1u); /*0x1066f4af0*/
      v5 = *((_BYTE *)this + 5024); /*0x1066f4af5*/
      if ( (v5 & 1) != 0 ) /*0x1066f4afd*/
        v6 = *((_BYTE *)this + 5032); /*0x1066f4bb7*/
      else
        v6 = v5 >> 1; /*0x1066f4b03*/
      LOBYTE(v25[0]) = v6; /*0x1066f4bc1*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v24, a2: v25, a3: 1u); /*0x1066f4bcc*/
      v7 = *((unsigned __int8 *)this + 5024); /*0x1066f4bd1*/
      if ( (v7 & 1) != 0 ) /*0x1066f4bdb*/
      {
        v9 = *((_QWORD *)this + 629); /*0x1066f4be8*/
        v8 = *((char **)this + 630); /*0x1066f4bef*/
      }
      else
      {
        v8 = (char *)this + 5025; /*0x1066f4bdd*/
        LODWORD(v9) = v7 >> 1; /*0x1066f4be4*/
      }
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v24, a2: v8, a3: v9); /*0x1066f4bfa*/
      v10 = *((_BYTE *)this + 5048); /*0x1066f4bff*/
      if ( (v10 & 1) != 0 ) /*0x1066f4c07*/
        v11 = *((_BYTE *)this + 5056); /*0x1066f4c0d*/
      else
        v11 = v10 >> 1; /*0x1066f4c09*/
      LOBYTE(v25[0]) = v11; /*0x1066f4c17*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v24, a2: v25, a3: 1u); /*0x1066f4c22*/
      v12 = *((unsigned __int8 *)this + 5048); /*0x1066f4c27*/
      if ( (v12 & 1) != 0 ) /*0x1066f4c31*/
      {
        v14 = *((_QWORD *)this + 632); /*0x1066f4c3e*/
        v13 = *((char **)this + 633); /*0x1066f4c45*/
      }
      else
      {
        v13 = (char *)this + 5049; /*0x1066f4c33*/
        LODWORD(v14) = v12 >> 1; /*0x1066f4c3a*/
      }
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v24, a2: v13, a3: v14); /*0x1066f4c50*/
      v16 = operator new(a1: (RBX::Memory *)0x58, a2: v15); /*0x1066f4c5f*/
      *(_OWORD *)(v16 + 8) = 0; /*0x1066f4c65*/
      *(_QWORD *)v16 = &off_10CAAE190; /*0x1066f4c70*/
      RBX::Network::NetworkStream::NetworkStream(a1: v16 + 24, a2: v24); /*0x1066f4c81*/
      v17 = *((_QWORD *)this + 574); /*0x1066f4c86*/
      v18 = (__int64 *)(v17 + 280); /*0x1066f4c8d*/
      if ( v17 == 0 ) /*0x1066f4c97*/
        v18 = (__int64 *)v4; /*0x1066f4c97*/
      v19 = *v18; /*0x1066f4c9b*/
      v22 = v16 + 24; /*0x1066f4ca2*/
      v23 = (std::__shared_weak_count *)v16; /*0x1066f4ca5*/
      *(_OWORD *)v25 = 0; /*0x1066f4cac*/
      (*(void (__fastcall **)(__int64, __int64, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v19 + 48LL))( /*0x1066f4cbd*/
        a1: v19,
        a2: 1,
        a3: &v22,
        a4: 0,
        a5: 0);
      v20 = v23; /*0x1066f4cc0*/
      if ( v23 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v23 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1066f4cd9*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(a1: v20); /*0x1066f4ce1*/
        std::__shared_weak_count::__release_weak(this: v20); /*0x1066f4ce7*/
      }
      v21 = v25[1]; /*0x1066f4cec*/
      if ( v25[1] != nullptr /*0x1066f4d05*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v25[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(a1: v21); /*0x1066f4d0d*/
        std::__shared_weak_count::__release_weak(this: v21); /*0x1066f4d13*/
      }
      RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v24); /*0x1066f4d1c*/
    }
    else if ( (unsigned __int8)DFLog::RbxTransportIntegration >= 6u && (DFLog::RbxTransportIntegration & 0xFC00) != 0 ) /*0x1066f4b6e*/
    {
      FLog::detail::FastLogSafeFormattedInternal( /*0x1066f4bad*/
        a1: DFLog::RbxTransportIntegration,
        a2: qword_10D7F15F8,
        a3: 4,
        a4: (unsigned int)"[DFLog::RbxTransportIntegration] sendEarlyAuthData failed because no connection!",
        a5: 80,
        a6: 1,
        0,
        v25);
    }
  }
  else if ( (unsigned __int8)DFLog::RbxTransportIntegration >= 6u && (DFLog::RbxTransportIntegration & 0xFC00) != 0 ) /*0x1066f4b21*/
  {
    FLog::detail::FastLogSafeFormattedInternal( /*0x1066f4b55*/
      a1: DFLog::RbxTransportIntegration,
      a2: qword_10D7F15F8,
      a3: 4,
      a4: (unsigned int)"[DFLog::RbxTransportIntegration] sendEarlyAuthData failed because no early auth data!",
      a5: 85,
      a6: 1,
      0,
      v25);
  }
}

// Address: 0x1066f4d60 | Name: __ZN3RBX7Network6Client28getAndHandleConnectionEventsEv
__int64 __fastcall RBX::Network::Client::getAndHandleConnectionEvents(RBX::Network::Client *this)
{
  RBX::Network::Client *i; // rbx
  __int64 v2; // rax
  char *v3; // rcx
  __int64 v4; // rax
  RBX::NetworkBase::ConnectionInternal **v5; // rcx
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // rax
  RBX::NetworkBase::ConnectionInternal **v9; // rcx
  RBX::Network::Replicator *v10; // rdi
  RBX::Network::ConnectionInfo *v11; // rax
  __int64 v12; // rax
  __int64 v13; // rdx
  __int64 v14; // rax
  RBX::NetworkBase::ConnectionInternal **v15; // rcx
  RBX::Network::ConnectionInfo *ConnectionInfo; // r15
  int v17; // r14d
  int v18; // r12d
  __int128 v19; // rax
  __int64 v20; // rax
  __int64 v21; // rdx
  char *v22; // rcx
  __int64 v23; // rdi
  _DWORD *v24; // r15
  __int64 v25; // rdx
  char *v26; // rcx
  __int64 (__fastcall *v27)(); // r8
  RBX::RunService *v28; // rdi
  void *v29; // rsi
  RBX::Time *v30; // rdi
  __int64 v31; // rcx
  unsigned __int64 v32; // rdx
  signed __int64 v33; // rcx
  __int64 v34; // rdx
  __int64 v35; // rcx
  __int64 v36; // rdx
  __int64 v37; // rcx
  void *v38; // rsi
  double v39; // xmm0_8
  RBX::Instance *v40; // rsi
  RBX::Instance *v41; // rsi
  __int64 v42; // rax
  float v43; // xmm0_4
  __int64 v44; // rax
  RBX::NetworkBase::ConnectionInternal **v45; // rcx
  unsigned __int64 v46; // rsi
  __int64 v47; // r8
  RBX::Network::SharedStringSynchronizer *v48; // r14
  RBX::Instance *v49; // rsi
  __int64 v50; // rax
  RBX::Network::SharedStringSynchronizer *v51; // r14
  void *v52; // rsi
  __int64 v53; // rax
  RBX::NetworkBase::ConnectionInternal **v54; // rcx
  unsigned int ConnectionErrorForDisconnect; // eax
  void *v56; // rsi
  _DWORD *v57; // r12
  __int64 v58; // rax
  RBX::NetworkBase::ConnectionInternal **v59; // rcx
  __int64 v60; // r14
  void *v61; // rsi
  __int64 v62; // r8
  const char *v63; // rcx
  unsigned __int8 *v64; // rcx
  __int64 ReasonCodeEnumString; // rax
  __int64 v66; // rdx
  __int64 v67; // r8
  unsigned __int8 *v68; // rcx
  void *v69; // rax
  char *v70; // rcx
  __int64 (__fastcall *v71)(); // r8
  void *v72; // rsi
  __int64 v73; // r8
  const char *v74; // rcx
  __int64 v75; // rax
  __int64 v76; // rdx
  __int64 v77; // r8
  unsigned __int8 *v78; // r12
  RBX::RunService *v79; // rdi
  int v80; // ecx
  int v81; // r8d
  int v82; // r9d
  void *v83; // rdx
  __int64 v84; // rdi
  _BYTE v86[48]; // [rsp+10h] [rbp-460h] BYREF
  _QWORD v87[4]; // [rsp+40h] [rbp-430h] BYREF
  int v88; // [rsp+60h] [rbp-410h]
  _BYTE v89[16]; // [rsp+70h] [rbp-400h] BYREF
  void *v90; // [rsp+80h] [rbp-3F0h]
  _BYTE v91[16]; // [rsp+88h] [rbp-3E8h] BYREF
  RBX::Time *v92; // [rsp+98h] [rbp-3D8h]
  _BYTE v93[16]; // [rsp+A0h] [rbp-3D0h] BYREF
  void *v94; // [rsp+B0h] [rbp-3C0h]
  RBX::Network::Client *v95; // [rsp+B8h] [rbp-3B8h]
  double v96; // [rsp+C0h] [rbp-3B0h]
  double v97; // [rsp+C8h] [rbp-3A8h]
  __int128 v98; // [rsp+D0h] [rbp-3A0h] BYREF
  __int64 v99; // [rsp+E0h] [rbp-390h] BYREF
  __int64 (__fastcall *v100)(); // [rsp+E8h] [rbp-388h]
  void *v101; // [rsp+F0h] [rbp-380h]
  RBX::NetworkBase::ConnectionInternal **v102; // [rsp+108h] [rbp-368h]
  _BYTE v103[32]; // [rsp+110h] [rbp-360h] BYREF
  RBX::Network::SharedStringSynchronizer *v104[2]; // [rsp+130h] [rbp-340h] BYREF
  RBX::RunService *v105; // [rsp+140h] [rbp-330h]
  _BYTE v106[536]; // [rsp+178h] [rbp-2F8h] BYREF
  _DWORD *v107; // [rsp+390h] [rbp-E0h] BYREF
  int v108; // [rsp+398h] [rbp-D8h]
  unsigned int v109; // [rsp+3A0h] [rbp-D0h]
  __int64 v110; // [rsp+3A8h] [rbp-C8h] BYREF
  _BYTE v111[144]; // [rsp+3B0h] [rbp-C0h] BYREF

  i = this; /*0x1066f4d74*/
  v2 = *((_QWORD *)this + 574); /*0x1066f4d85*/
  v3 = (char *)(v2 + 280); /*0x1066f4d8c*/
  v102 = (RBX::NetworkBase::ConnectionInternal **)((char *)this + 4600); /*0x1066f4d9d*/
  if ( v2 == 0 ) /*0x1066f4da4*/
    v3 = (char *)this + 4600; /*0x1066f4da4*/
  (*(void (__fastcall **)(_BYTE *))(**(_QWORD **)v3 + 152LL))(a1: v86); /*0x1066f4db5*/
  while ( 2 )
  {
    RBX::RbxTransport::EventsQueue<RBX::RbxTransport::ConnectionEvent>::getNextEvent(a1: &v107, a2: v86); /*0x1066f4dc2*/
    if ( v111[136] == 0 ) /*0x1066f4dd5*/
      goto LABEL_190; /*0x1066f4dd5*/
    switch ( v111[128] )
    {
      case 0:
        v14 = *((_QWORD *)i + 574); /*0x1066f4ef3*/
        v15 = (RBX::NetworkBase::ConnectionInternal **)(v14 + 280); /*0x1066f4efa*/
        if ( v14 == 0 ) /*0x1066f4f04*/
          v15 = v102; /*0x1066f4f04*/
        ConnectionInfo = (RBX::Network::ConnectionInfo *)RBX::NetworkBase::ConnectionInternal::getConnectionInfo(this: *v15); /*0x1066f4f14*/
        v17 = (int)DFLog::NetworkClient; /*0x1066f4f17*/
        if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 ) /*0x1066f4f2c*/
        {
          v18 = qword_10D809380; /*0x1066f4f37*/
          *(_QWORD *)&v19 = RBX::Network::ConnectionInfo::toString(this: ConnectionInfo, a2: true); /*0x1066f4f46*/
          v98 = v19; /*0x1066f4f4b*/
          v99 = (__int64)&v98; /*0x1066f4f60*/
          v100 = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1066f4f6e*/
          v104[0] = (RBX::Network::SharedStringSynchronizer *)15; /*0x1066f4f75*/
          v104[1] = (RBX::Network::SharedStringSynchronizer *)&v99; /*0x1066f4f87*/
          FLog::detail::FastLogSafeFormattedInternal( /*0x1066f4fb7*/
            a1: v17,
            a2: v18,
            a3: 4,
            a4: (unsigned int)"[DFLog::NetworkClient] Connection accepted from {}",
            a5: 50,
            a6: 1,
            15,
            &v99);
        }
        v20 = RBX::Network::ConnectionInfo::toString(this: ConnectionInfo, a2: true); /*0x1066f4fc4*/
        if ( v20 != 0 ) /*0x1066f4fe1*/
        {
          std::string::basic_string[abi:ne200100](a1: v104, a2: v20, a3: v21); /*0x1066f4fed*/
          v22 = (char *)v104 + 1; /*0x1066f4ff9*/
          if ( ((__int64)v104[0] & 1) != 0 ) /*0x1066f5000*/
            v22 = (char *)v105; /*0x1066f5006*/
        }
        else
        {
          *(_OWORD *)v104 = 0; /*0x1066f519b*/
          v105 = nullptr; /*0x1066f51a2*/
          v22 = (char *)v104 + 1; /*0x1066f51ad*/
        }
        RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066f51cc*/
          this: (RBX::Network::ConcurrentRakPeer **)i,
          a2: "RakNetPasswordAccepted",
          a3: 0,
          a4: v22,
          a5: 2,
          a6: 1);
        if ( ((__int64)v104[0] & 1) != 0 ) /*0x1066f51d8*/
          operator delete(a1: v105, a2: v29); /*0x1066f51e1*/
        if ( (unsigned __int8)RBX::RunService::productIsStudio(this: v28) == 0 /*0x1066f51fb*/
          || (unsigned int)(*((_DWORD *)i + 1236) - 3) >= 0xFFFFFFFE )
        {
          RBX::Network::Client::sendEarlyAuthData(this: i); /*0x1066f5200*/
        }
        *((_DWORD *)i + 158) = 2; /*0x1066f5205*/
        v31 = *((_QWORD *)i + 67); /*0x1066f520f*/
        if ( v31 > 0 ) /*0x1066f5219*/
        {
          v32 = v31 / 0x3E8uLL; /*0x1066f5233*/
          v33 = v31 % 0x3E8uLL; /*0x1066f523e*/
          if ( v33 < DFInt::ClientJoinProcessPositiveSamplesThousandths ) /*0x1066f524e*/
          {
            std::string::basic_string[abi:ne200100]<0>(a1: v91, a2: "client", a3: v32, a4: v33); /*0x1066f5262*/
            std::string::basic_string[abi:ne200100]<0>(a1: v93, a2: "report", a3: v34, a4: v35); /*0x1066f5275*/
            std::string::basic_string[abi:ne200100]<0>(a1: v89, a2: "GameServerConnectSuccess", a3: v36, a4: v37); /*0x1066f5284*/
            memset(v87, 0, sizeof(v87)); /*0x1066f5293*/
            v88 = 1065353216; /*0x1066f529a*/
            RBX::Analytics::EventIngest::setRBXEvent(a1: v91, a2: v93, a3: v89, a4: v87); /*0x1066f52b8*/
            std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v87); /*0x1066f52c0*/
            if ( (v89[0] & 1) != 0 ) /*0x1066f52cc*/
              operator delete(a1: (RBX::Memory *)v90, a2: v38); /*0x1066f52d5*/
            if ( (v93[0] & 1) != 0 ) /*0x1066f52e1*/
              operator delete(a1: (RBX::Memory *)v94, a2: v38); /*0x1066f52ea*/
            if ( (v91[0] & 1) != 0 ) /*0x1066f52f6*/
              operator delete(a1: v92, a2: v38); /*0x1066f52ff*/
          }
        }
        RBX::Time::nowFast(this: v30); /*0x1066f5304*/
        v96 = v39; /*0x1066f5309*/
        v97 = *(double *)(RBX::DataModel::get(this: i, a2: v40) + 1776); /*0x1066f5321*/
        v42 = RBX::DataModel::get(this: i, a2: v41); /*0x1066f532c*/
        v43 = v96 - v97; /*0x1066f5341*/
        *(float *)(v42 + 1788) = v43; /*0x1066f5345*/
        if ( FFlag::EnableSharedStringCaching != 1 ) /*0x1066f5357*/
          goto LABEL_61; /*0x1066f5357*/
        v44 = *((_QWORD *)i + 574); /*0x1066f5359*/
        v45 = (RBX::NetworkBase::ConnectionInternal **)(v44 + 280); /*0x1066f5360*/
        if ( v44 == 0 ) /*0x1066f536a*/
          v45 = v102; /*0x1066f536a*/
        if ( ((*(__int64 (__fastcall **)(RBX::NetworkBase::ConnectionInternal *))(*(_QWORD *)*v45 + 56LL))(a1: *v45) /*0x1066f5380*/
            & 0x100000000000LL) != 0 )
        {
          v48 = (RBX::Network::SharedStringSynchronizer *)operator new(a1: (RBX::Memory *)0x210, a2: v46); /*0x1066f5460*/
          __bzero(a1: v48, a2: 528); /*0x1066f546b*/
          RBX::Network::SharedStringSynchronizer::SharedStringSynchronizer(this: v48); /*0x1066f5473*/
          v104[0] = v48; /*0x1066f5478*/
          v50 = RBX::DataModel::get(this: i, a2: v49); /*0x1066f5482*/
          RBX::Network::SharedStringSynchronizer::loadHashesFromPlaceIdTable(this: v48, a2: *(_QWORD *)(v50 + 840)); /*0x1066f5491*/
          RBX::Network::Client::sendSharedStringHashes(this: i, a2: v104[0]); /*0x1066f54a0*/
          RBX::Network::Client::sendVersionInfo(this: i); /*0x1066f54a8*/
          RBX::Network::Client::HandleConnection(this: i); /*0x1066f54b0*/
          RBX::Network::ClientReplicator::setSharedStringSynchronizer(a1: *((_QWORD *)i + 574), a2: v104); /*0x1066f54bf*/
          v51 = v104[0]; /*0x1066f54c4*/
          v104[0] = nullptr; /*0x1066f54cb*/
          if ( v51 != nullptr ) /*0x1066f54d9*/
          {
            RBX::Network::SharedStringSynchronizer::~SharedStringSynchronizer(this: v51); /*0x1066f54e2*/
            operator delete(a1: v51, a2: v52); /*0x1066f54ea*/
          }
        }
        else
        {
LABEL_61:
          RBX::Network::Client::sendVersionInfo(this: i); /*0x1066f5389*/
          RBX::Network::Client::HandleConnection(this: i); /*0x1066f5391*/
        }
        RBX::Network::ClientReplicator::onNewConnectionCallback(this: *((RBX::Network::ClientReplicator **)i + 574)); /*0x1066f539d*/
        if ( FFlag::RbxTransportConnectionFailureFallbackToRakNet == 1 ) /*0x1066f53a9*/
          *((_BYTE *)i + 4721) = 1; /*0x1066f53ab*/
        if ( FFlag::RakNetConnectionFailureFallbackToRbxTransport == 1 && *((_BYTE *)i + 4817) == 1 )
        {
          RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1066f53dd*/
            a1: (__int64)v104,
            a2: (__int64)&RBX::Telemetry::kRakNetFallbackToRbxTransportStatus);
          RBX::Telemetry::FieldsContainer::addField(a1: v106, a2: "success", a3: 7, a4: 1, a5: 1); /*0x1066f5400*/
          RBX::Telemetry::FieldsContainer::addField( /*0x1066f542c*/
            a1: v106,
            a2: "originalRaknetError",
            a3: 19,
            a4: *((int *)i + 1205),
            a5: 1);
          if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
          {
            v47 = (SFString::RCCChannelName[0] & 1) != 0
                ? *(_QWORD *)&SFString::RCCChannelName[8]
                : SFString::RCCChannelName[0] >> 1;
            if ( v47 != 0 ) /*0x1066f56b5*/
            {
              if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1066f56b9*/
                v64 = *(unsigned __int8 **)&SFString::RCCChannelName[16]; /*0x1066f56bb*/
              else
                v64 = &SFString::RCCChannelName[1]; /*0x1066f56eb*/
              RBX::Telemetry::FieldsContainer::addField(a1: v106, a2: "rccChannelName", a3: 14, a4: v64, a5: v47, a6: 1); /*0x1066f5708*/
            }
          }
          RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v104); /*0x1066f5710*/
          if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 )
          {
            *(_QWORD *)&v98 = *((unsigned int *)i + 1205); /*0x1066f573d*/
            v99 = 1; /*0x1066f5744*/
            v100 = (__int64 (__fastcall *)())&v98; /*0x1066f5756*/
            FLog::detail::FastLogSafeFormattedInternal(
              a1: (_DWORD)DFLog::NetworkClient,
              a2: qword_10D809380,
              a3: 4,
              a4: (unsigned int)"[DFLog::NetworkClient] Successfully connected to server after falling back from RakNet to Rb"
                            "xTransport. Original connection failure reason code: {}",
              a5: 147,
              a6: 1,
              1,
              &v98);
          }
          RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v104); /*0x1066f578f*/
        }
        goto LABEL_105; /*0x1066f578f*/
      case 4:
        v23 = *((_QWORD *)i + 574); /*0x1066f5012*/
        if ( v23 == 0 /*0x1066f503a*/
          || (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v23 + 856LL))(a1: v23) == 0
          || v108 == 0 )
        {
          goto LABEL_105; /*0x1066f503a*/
        }
        v24 = v107; /*0x1066f504d*/
        if ( v109 != 0 ) /*0x1066f5053*/
        {
          v25 = 4LL * v109; /*0x1066f5059*/
          v24 = v107; /*0x1066f5061*/
          while ( *v24 >= 0xFFFFFFFE ) /*0x1066f5068*/
          {
            ++v24; /*0x1066f506e*/
            v25 -= 4; /*0x1066f5072*/
            if ( v25 == 0 ) /*0x1066f5076*/
              goto LABEL_105; /*0x1066f5076*/
          }
        }
        v57 = &v107[v109]; /*0x1066f5555*/
        if ( v24 != v57 ) /*0x1066f555c*/
        {
          v95 = i; /*0x1066f5562*/
          do /*0x1066f55f8*/
          {
            v58 = *((_QWORD *)i + 574); /*0x1066f556c*/
            v59 = (RBX::NetworkBase::ConnectionInternal **)(v58 + 280); /*0x1066f5573*/
            if ( v58 == 0 ) /*0x1066f557d*/
              v59 = v102; /*0x1066f557d*/
            (*(void (__fastcall **)(RBX::Network::SharedStringSynchronizer **, RBX::NetworkBase::ConnectionInternal *, _QWORD))(*(_QWORD *)*v59 + 168LL))( /*0x1066f5598*/
              a1: v104,
              a2: *v59,
              a3: (unsigned int)*v24);
            v60 = *((_QWORD *)i + 574); /*0x1066f559e*/
            RBX::RangeList<unsigned long long>::RangeList(a1: v103, a2: v104); /*0x1066f55b2*/
            RBX::Network::Replicator::processAckRanges(a1: v60, a2: v103); /*0x1066f55bd*/
            RBX::RangeList<unsigned long long>::~RangeList(a1: v103); /*0x1066f55c5*/
            RBX::RangeList<unsigned long long>::~RangeList(a1: v104); /*0x1066f55d1*/
            ++v24; /*0x1066f55d6*/
            for ( i = v95; v24 != v57; ++v24 ) /*0x1066f55e4*/
            {
              if ( *v24 < 0xFFFFFFFE ) /*0x1066f55ea*/
                break; /*0x1066f55ea*/
            }
          }
          while ( v24 != v57 ); /*0x1066f55f8*/
        }
        goto LABEL_105; /*0x1066f55f8*/
      case 5:
      case 6:
        goto LABEL_6;
      case 7:
        if ( FFlag::RakNetConnectionFailureFallbackToRbxTransport == 1 && *((_BYTE *)i + 4817) == 1 )
        {
          RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1066f50a8*/
            a1: (__int64)v104,
            a2: (__int64)&RBX::Telemetry::kRakNetFallbackToRbxTransportStatus);
          RBX::Telemetry::FieldsContainer::addField(a1: v106, a2: "success", a3: 7, a4: 0, a5: 1); /*0x1066f50c8*/
          RBX::Telemetry::FieldsContainer::addField( /*0x1066f50f4*/
            a1: v106,
            a2: "originalRaknetError",
            a3: 19,
            a4: *((int *)i + 1205),
            a5: 1);
          *(_QWORD *)&v98 = &v110; /*0x1066f5100*/
          *((_QWORD *)&v98 + 1) = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Network::StateReason,fmt::v8::formatter<RBX::Network::StateReason,char,void>>; /*0x1066f510e*/
          fmt::v8::vformat(a1: &v99, a2: "{}", 2, 15, &v98); /*0x1066f5134*/
          if ( (v99 & 1) != 0 ) /*0x1066f5145*/
          {
            v26 = (char *)v101; /*0x1066f514b*/
            v27 = v100; /*0x1066f5152*/
          }
          else
          {
            v27 = (__int64 (__fastcall *)())((unsigned __int8)v99 >> 1); /*0x1066f5603*/
            v26 = (char *)&v99 + 1; /*0x1066f5606*/
          }
          RBX::Telemetry::FieldsContainer::addField(a1: v106, a2: "rbxTransportReason", a3: 18, a4: v26, a5: v27, a6: 1); /*0x1066f5626*/
          if ( (v99 & 1) != 0 ) /*0x1066f5632*/
            operator delete(a1: (RBX::Memory *)v101, a2: v61); /*0x1066f563b*/
          if ( (int)v110 > 127 ) /*0x1066f5649*/
          {
            switch ( (int)v110 ) /*0x1066f5698*/
            {
              case 256: /*0x1066f5698*/
                v62 = 6; /*0x1066f569a*/
                v63 = "Player"; /*0x1066f56a0*/
                break; /*0x1066f56a7*/
              case 257: /*0x1066f5698*/
                v62 = 3; /*0x1066f5861*/
                v63 = "RCC"; /*0x1066f5867*/
                break; /*0x1066f586e*/
              case 258: /*0x1066f5698*/
                v62 = 6; /*0x1066f5834*/
                v63 = "Studio"; /*0x1066f583a*/
                break; /*0x1066f5841*/
              case 259: /*0x1066f5698*/
                v62 = 8; /*0x1066f5843*/
                v63 = "Security"; /*0x1066f5849*/
                break; /*0x1066f5850*/
              case 260: /*0x1066f5698*/
                v62 = 11; /*0x1066f5816*/
                v63 = "Matchmaking"; /*0x1066f581c*/
                break; /*0x1066f5823*/
              case 261: /*0x1066f5698*/
                v62 = 6; /*0x1066f5870*/
                v63 = "RoMark"; /*0x1066f5876*/
                break; /*0x1066f587d*/
              case 262: /*0x1066f5698*/
                v62 = 11; /*0x1066f587f*/
                v63 = "Replication"; /*0x1066f5885*/
                break; /*0x1066f588c*/
              case 263: /*0x1066f5698*/
                v62 = 11; /*0x1066f5852*/
                v63 = "PlaceLaunch"; /*0x1066f5858*/
                break; /*0x1066f585f*/
              case 264: /*0x1066f5698*/
                v62 = 8; /*0x1066f588e*/
                v63 = "Teleport"; /*0x1066f5894*/
                break; /*0x1066f5894*/
              default:
                if ( (_DWORD)v110 == 128 ) /*0x1066f57ad*/
                {
                  v62 = 6; /*0x1066f5825*/
                  v63 = "System"; /*0x1066f582b*/
                }
                else if ( (_DWORD)v110 == 192 ) /*0x1066f57b4*/
                {
                  v62 = 3; /*0x1066f57b6*/
                  v63 = "RNA"; /*0x1066f57bc*/
                }
                else
                {
LABEL_113:
                  v62 = 18; /*0x1066f5804*/
                  v63 = "InvalidReasonClass"; /*0x1066f580a*/
                }
                break; /*0x1066f57c3*/
            }
          }
          else
          {
            v62 = 4; /*0x1066f564b*/
            switch ( (int)v110 ) /*0x1066f5667*/
            {
              case '@': /*0x1066f5667*/
                v62 = 8; /*0x1066f5669*/
                v63 = "Protocol"; /*0x1066f566f*/
                break; /*0x1066f5676*/
              case 'A': /*0x1066f5667*/
                v62 = 6; /*0x1066f57f2*/
                v63 = "Ngtcp2"; /*0x1066f57f8*/
                break; /*0x1066f57ff*/
              case 'B': /*0x1066f5667*/
                v63 = "QUIC"; /*0x1066f57da*/
                break; /*0x1066f57e1*/
              case 'C': /*0x1066f5667*/
                v63 = "Port"; /*0x1066f57e6*/
                break; /*0x1066f57ed*/
              case 'D': /*0x1066f5667*/
                v62 = 10; /*0x1066f57c8*/
                v63 = "NoResponse"; /*0x1066f57ce*/
                break; /*0x1066f57d5*/
              default:
                v63 = "None"; /*0x1066f56c1*/
                if ( (_DWORD)v110 != 0 ) /*0x1066f56ca*/
                {
                  if ( (_DWORD)v110 != 1 ) /*0x1066f56d3*/
                    goto LABEL_113; /*0x1066f56d3*/
                  v62 = 2; /*0x1066f56d9*/
                  v63 = "IO"; /*0x1066f56df*/
                }
                break; /*0x1066f56e6*/
            }
          }
          RBX::Telemetry::FieldsContainer::addField( /*0x1066f58b4*/
            a1: v106,
            a2: "rbxTransportReasonClass",
            a3: 23,
            a4: v63,
            a5: v62,
            a6: 1);
          ReasonCodeEnumString = RBX::Network::StateReason::getReasonCodeEnumString(this: (RBX::Network::StateReason *)&v110); /*0x1066f58c0*/
          RBX::Telemetry::FieldsContainer::addField( /*0x1066f58e4*/
            a1: v106,
            a2: "rbxTransportReasonCode",
            a3: 22,
            a4: ReasonCodeEnumString,
            a5: v66,
            a6: 1);
          if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
          {
            v67 = (SFString::RCCChannelName[0] & 1) != 0
                ? *(_QWORD *)&SFString::RCCChannelName[8]
                : SFString::RCCChannelName[0] >> 1;
            if ( v67 != 0 ) /*0x1066f590c*/
            {
              if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1066f5910*/
                v68 = *(unsigned __int8 **)&SFString::RCCChannelName[16]; /*0x1066f5912*/
              else
                v68 = &SFString::RCCChannelName[1]; /*0x1066f5918*/
              RBX::Telemetry::FieldsContainer::addField(a1: v106, a2: "rccChannelName", a3: 14, a4: v68, a5: v67, a6: 1); /*0x1066f5935*/
            }
          }
          RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v104); /*0x1066f593d*/
          if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 )
          {
            v69 = (void *)*((unsigned int *)i + 1205); /*0x1066f5964*/
            v99 = (__int64)&v110; /*0x1066f5971*/
            v100 = (__int64 (__fastcall *)())fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Network::StateReason,fmt::v8::formatter<RBX::Network::StateReason,char,void>>; /*0x1066f597f*/
            v101 = v69; /*0x1066f5986*/
            *(_QWORD *)&v98 = 31; /*0x1066f598d*/
            *((_QWORD *)&v98 + 1) = &v99; /*0x1066f599f*/
            FLog::detail::FastLogSafeFormattedInternal(
              a1: (_DWORD)DFLog::NetworkClient,
              a2: qword_10D809380,
              a3: 4,
              a4: (unsigned int)"[DFLog::NetworkClient] RakNet connection closed, attempted fallback to RbxTransport, but it "
                            "also failed. Reason: {}. Original RakNet error: {}",
              a5: 142,
              a6: 1,
              31,
              &v99);
          }
          RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v104); /*0x1066f59d8*/
          goto LABEL_6; /*0x1066f59dd*/
        }
        if ( FFlag::RbxTransportConnectionFailureFallbackToRakNet != 1 || *((_BYTE *)i + 4721) != 0 ) /*0x1066f5172*/
        {
LABEL_6:
          v4 = *((_QWORD *)i + 574); /*0x1066f4df9*/
          v5 = (RBX::NetworkBase::ConnectionInternal **)(v4 + 280); /*0x1066f4e00*/
          if ( v4 == 0 ) /*0x1066f4e0a*/
            v5 = v102; /*0x1066f4e0a*/
          RBX::NetworkBase::ConnectionInternal::setDisconnectReason( /*0x1066f4e1c*/
            this: *v5,
            a2: (const RBX::Network::StateReason *)&v110);
          if ( DFFlag::UpdateConnectionStateWhenSettingDisconnectReason == 0 /*0x1066f4e37*/
            && DFFlag::FixOverwriteDisconnectReasonInServerStop == 1 )
          {
            v8 = *((_QWORD *)i + 574); /*0x1066f4e39*/
            v9 = (RBX::NetworkBase::ConnectionInternal **)(v8 + 280); /*0x1066f4e40*/
            if ( v8 == 0 ) /*0x1066f4e4a*/
              v9 = v102; /*0x1066f4e4a*/
            v7 = (unsigned int)_InterlockedExchange((volatile __int32 *)*v9 + 353, 4); /*0x1066f4e5a*/
          }
          v10 = *((RBX::Network::Replicator **)i + 574); /*0x1066f4e60*/
          if ( v10 != nullptr ) /*0x1066f4e6a*/
          {
            RBX::Network::Replicator::onRemoteDisconnect(this: v10); /*0x1066f4e6c*/
          }
          else
          {
            if ( FFlag::UseRealAddressForRbxTransportConnections == 1 ) /*0x1066f4e80*/
            {
              v11 = (RBX::Network::ConnectionInfo *)RBX::NetworkBase::ConnectionInternal::getConnectionInfo(this: *v102); /*0x1066f4e90*/
              v12 = RBX::Network::ConnectionInfo::toString(this: v11, a2: true); /*0x1066f4ea4*/
              if ( v12 != 0 ) /*0x1066f4eac*/
              {
                std::string::basic_string[abi:ne200100](a1: v104, a2: v12, a3: v13); /*0x1066f4eb8*/
              }
              else
              {
                *(_OWORD *)v104 = 0; /*0x1066f54f7*/
                v105 = nullptr; /*0x1066f54fe*/
              }
            }
            else
            {
              std::string::basic_string[abi:ne200100]<0>( /*0x1066f518e*/
                a1: v104,
                a2: "TODO (RbxTransportIntegration) RbxTransport gives address",
                a3: v6,
                a4: v7);
            }
            v53 = *((_QWORD *)i + 574); /*0x1066f5509*/
            v54 = (RBX::NetworkBase::ConnectionInternal **)(v53 + 280); /*0x1066f5510*/
            if ( v53 == 0 ) /*0x1066f551a*/
              v54 = v102; /*0x1066f551a*/
            ConnectionErrorForDisconnect = RBX::NetworkBase::ConnectionInternal::getConnectionErrorForDisconnect(this: *v54); /*0x1066f5525*/
            RBX::Network::Client::requestDisconnectOnTransportFailure( /*0x1066f5532*/
              a1: (__int64)i,
              a2: (__int64)v104,
              a3: ConnectionErrorForDisconnect);
            if ( ((__int64)v104[0] & 1) != 0 ) /*0x1066f553e*/
              operator delete(a1: v105, a2: v56); /*0x1066f554b*/
          }
LABEL_105:
          std::__optional_destruct_base<RBX::RbxTransport::ConnectionEvent,false>::~__optional_destruct_base[abi:ne200100](a1: &v107); /*0x1066f5794*/
          continue; /*0x1066f57a3*/
        }
        RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1066f59f0*/
          a1: (__int64)v104,
          a2: (__int64)&RBX::Telemetry::kRbxTransportFallbackToRakNetEvent);
        *(_QWORD *)&v98 = &v110; /*0x1066f5a03*/
        *((_QWORD *)&v98 + 1) = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Network::StateReason,fmt::v8::formatter<RBX::Network::StateReason,char,void>>; /*0x1066f5a0d*/
        fmt::v8::vformat(a1: &v99, a2: "{}", 2, 15, &v98); /*0x1066f5a2c*/
        if ( (v99 & 1) != 0 ) /*0x1066f5a44*/
        {
          v70 = (char *)v101; /*0x1066f5a46*/
          v71 = v100; /*0x1066f5a4d*/
        }
        else
        {
          v71 = (__int64 (__fastcall *)())((unsigned __int8)v99 >> 1); /*0x1066f5a56*/
          v70 = (char *)&v99 + 1; /*0x1066f5a59*/
        }
        RBX::Telemetry::FieldsContainer::addField(a1: v106, a2: "reason", a3: 6, a4: v70, a5: v71, a6: 1); /*0x1066f5a7c*/
        if ( (v99 & 1) != 0 ) /*0x1066f5a88*/
          operator delete(a1: (RBX::Memory *)v101, a2: v72); /*0x1066f5a91*/
        if ( (int)v110 > 127 ) /*0x1066f5a9f*/
        {
          switch ( (int)v110 ) /*0x1066f5ae4*/
          {
            case 256: /*0x1066f5ae4*/
              v74 = "Player"; /*0x1066f5ae6*/
              goto LABEL_165; /*0x1066f5aed*/
            case 257: /*0x1066f5ae4*/
              v74 = "RCC"; /*0x1066f5b9c*/
              goto LABEL_163; /*0x1066f5b9c*/
            case 258: /*0x1066f5ae4*/
              v74 = "Studio"; /*0x1066f5b81*/
              goto LABEL_165; /*0x1066f5b88*/
            case 259: /*0x1066f5ae4*/
              v74 = "Security"; /*0x1066f5b8a*/
              goto LABEL_169; /*0x1066f5b91*/
            case 260: /*0x1066f5ae4*/
              v74 = "Matchmaking"; /*0x1066f5b6f*/
              goto LABEL_167; /*0x1066f5b76*/
            case 261: /*0x1066f5ae4*/
              v74 = "RoMark"; /*0x1066f5bab*/
              goto LABEL_165; /*0x1066f5bab*/
            case 262: /*0x1066f5ae4*/
              v74 = "Replication"; /*0x1066f5bba*/
              goto LABEL_167; /*0x1066f5bba*/
            case 263: /*0x1066f5ae4*/
              v74 = "PlaceLaunch"; /*0x1066f5b93*/
LABEL_167:
              v73 = 11; /*0x1066f5bc1*/
              break; /*0x1066f5bc7*/
            case 264: /*0x1066f5ae4*/
              v74 = "Teleport"; /*0x1066f5bc9*/
LABEL_169:
              v73 = 8; /*0x1066f5bd0*/
              break; /*0x1066f5bd0*/
            default:
              if ( (_DWORD)v110 == 128 ) /*0x1066f5b12*/
              {
                v74 = "System"; /*0x1066f5b78*/
LABEL_165:
                v73 = 6; /*0x1066f5bb2*/
              }
              else if ( (_DWORD)v110 == 192 ) /*0x1066f5b19*/
              {
                v74 = "RNA"; /*0x1066f5b1b*/
LABEL_163:
                v73 = 3; /*0x1066f5ba3*/
              }
              else
              {
LABEL_156:
                v74 = "InvalidReasonClass"; /*0x1066f5b60*/
                v73 = 18; /*0x1066f5b67*/
              }
              break; /*0x1066f5ba9*/
          }
        }
        else
        {
          v73 = 4; /*0x1066f5aa1*/
          switch ( (int)v110 ) /*0x1066f5abd*/
          {
            case '@': /*0x1066f5abd*/
              v74 = "Protocol"; /*0x1066f5abf*/
              goto LABEL_169; /*0x1066f5ac6*/
            case 'A': /*0x1066f5abd*/
              v74 = "Ngtcp2"; /*0x1066f5b57*/
              goto LABEL_165; /*0x1066f5b5e*/
            case 'B': /*0x1066f5abd*/
              v74 = "QUIC"; /*0x1066f5b42*/
              break; /*0x1066f5b49*/
            case 'C': /*0x1066f5abd*/
              v74 = "Port"; /*0x1066f5b4e*/
              break; /*0x1066f5b55*/
            case 'D': /*0x1066f5abd*/
              v74 = "NoResponse"; /*0x1066f5b24*/
              v73 = 10; /*0x1066f5b2b*/
              break; /*0x1066f5b31*/
            default:
              if ( (_DWORD)v110 != 0 ) /*0x1066f5af4*/
              {
                if ( (_DWORD)v110 != 1 ) /*0x1066f5af9*/
                  goto LABEL_156; /*0x1066f5af9*/
                v74 = "IO"; /*0x1066f5afb*/
                v73 = 2; /*0x1066f5b02*/
              }
              else
              {
                v74 = "None"; /*0x1066f5b36*/
              }
              break; /*0x1066f5b08*/
          }
        }
        RBX::Telemetry::FieldsContainer::addField(a1: v106, a2: "reasonClass", a3: 11, a4: v74, a5: v73, a6: 1); /*0x1066f5bd6*/
        v75 = RBX::Network::StateReason::getReasonCodeEnumString(this: (RBX::Network::StateReason *)&v110); /*0x1066f5bf7*/
        RBX::Telemetry::FieldsContainer::addField(a1: v106, a2: "reasonCode", a3: 10, a4: v75, a5: v76, a6: 1); /*0x1066f5c17*/
        if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
        {
          v77 = (SFString::RCCChannelName[0] & 1) != 0
              ? *(_QWORD *)&SFString::RCCChannelName[8]
              : SFString::RCCChannelName[0] >> 1;
          if ( v77 != 0 ) /*0x1066f5c41*/
          {
            if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1066f5c45*/
              v78 = *(unsigned __int8 **)&SFString::RCCChannelName[16]; /*0x1066f5c47*/
            else
              v78 = &SFString::RCCChannelName[1]; /*0x1066f5c4e*/
            RBX::Telemetry::FieldsContainer::addField(a1: v106, a2: "rccChannelName", a3: 14, a4: v78, a5: v77, a6: 1); /*0x1066f5c69*/
          }
        }
        RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v104); /*0x1066f5c75*/
        v79 = DFLog::NetworkClient; /*0x1066f5c7a*/
        if ( (unsigned __int8)DFLog::NetworkClient >= 6u && ((unsigned __int16)DFLog::NetworkClient & 0xFC00) != 0 )
        {
          *(_QWORD *)&v98 = &v110; /*0x1066f5ca3*/
          *((_QWORD *)&v98 + 1) = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Network::StateReason,fmt::v8::formatter<RBX::Network::StateReason,char,void>>; /*0x1066f5cb1*/
          v99 = 15; /*0x1066f5cb8*/
          v100 = (__int64 (__fastcall *)())&v98; /*0x1066f5cc3*/
          FLog::detail::FastLogSafeFormattedInternal(
            a1: (_DWORD)DFLog::NetworkClient,
            a2: qword_10D809380,
            a3: 4,
            a4: (unsigned int)"[DFLog::NetworkClient] RbxTransport connection closed, falling back to RakNet. Reason: {}",
            a5: 89,
            a6: 1,
            15,
            &v98);
        }
        if ( (unsigned __int8)RBX::RunService::productIsStudio(this: v79) != 0 ) /*0x1066f5cf9*/
        {
          if ( (DFString::RbxTransportFallbackStudioMessage & 1) != 0 ) /*0x1066f5d03*/
          {
            if ( qword_10D809368 != 0 ) /*0x1066f5d1a*/
            {
              LODWORD(v83) = qword_10D809370; /*0x1066f5d1c*/
LABEL_187:
              RBX::CreatorLog::printf(a1: 2, a2: (unsigned int)"%s", a3: (_DWORD)v83, a4: v80, a5: v81, a6: v82); /*0x1066f5d23*/
            }
          }
          else if ( DFString::RbxTransportFallbackStudioMessage != 0 ) /*0x1066f5d07*/
          {
            v83 = &unk_10D809361; /*0x1066f5d09*/
            goto LABEL_187; /*0x1066f5d10*/
          }
        }
        *((_QWORD *)i + 591) = v110; /*0x1066f5d41*/
        std::string::operator=(a1: (char *)i + 4736, a2: v111); /*0x1066f5d4f*/
        *((_BYTE *)i + 4722) = 1; /*0x1066f5d54*/
        v84 = *((_QWORD *)i + 588); /*0x1066f5d5b*/
        if ( v84 == 0 ) /*0x1066f5d65*/
          std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x1066f5dbf*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v84 + 48LL))(a1: v84); /*0x1066f5d6a*/
        RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v104); /*0x1066f5d7b*/
LABEL_190:
        std::__optional_destruct_base<RBX::RbxTransport::ConnectionEvent,false>::~__optional_destruct_base[abi:ne200100](a1: &v107); /*0x1066f5d80*/
        std::deque<RBX::RbxTransport::ConnectionEvent>::~deque[abi:ne200100](a1: v86); /*0x1066f5d93*/
        return __stack_chk_guard; /*0x1066f5da8*/
      case 8:
        if ( (unsigned __int8)RBX::UnexpectedEvents::UnexpectedEvent::canReport(this: (RBX::UnexpectedEvents::UnexpectedEvent *)&RBX::UnexpectedEvents::client_unexpected_rbxtransport_event) != 0 ) /*0x1066f4ed0*/
          RBX::UnexpectedEvents::UnexpectedEvent::report( /*0x1066f4ee9*/
            a1: &RBX::UnexpectedEvents::client_unexpected_rbxtransport_event,
            a2: "Received RbxTransport::ConnectionEventType::NumConnectionEventTypes",
            a3: 67);
        goto LABEL_105; /*0x1066f4eee*/
      default:
        goto LABEL_105;
    }
  }
}

// Address: 0x1066f5fc4 | Name: __ZN3RBX7Network6Client13doReceiveLoopEv
__int64 __fastcall RBX::Network::Client::doReceiveLoop(RBX::Network::Client *this)
{
  __int64 v1; // rax
  _QWORD *v2; // rcx
  char *v3; // rbx
  __int64 v5; // rax
  char *v6; // rcx
  RBX::Time *v7; // rdi
  __int64 v8; // xmm0_8
  __int64 v9; // r12
  __int64 i; // r15
  __int64 v12; // [rsp+0h] [rbp-1D0h] BYREF
  __int64 v13; // [rsp+8h] [rbp-1C8h]
  __int64 v14; // [rsp+18h] [rbp-1B8h]
  _QWORD v15[5]; // [rsp+20h] [rbp-1B0h] BYREF
  _BYTE v16[8]; // [rsp+48h] [rbp-188h] BYREF
  _BYTE v17[96]; // [rsp+50h] [rbp-180h] BYREF
  _BYTE v18[8]; // [rsp+B0h] [rbp-120h] BYREF
  _QWORD v19[11]; // [rsp+B8h] [rbp-118h] BYREF
  _QWORD v20[5]; // [rsp+110h] [rbp-C0h] BYREF
  _BYTE v21[8]; // [rsp+138h] [rbp-98h] BYREF
  _BYTE v22[96]; // [rsp+140h] [rbp-90h] BYREF

  v1 = *((_QWORD *)this + 574); /*0x1066f5fe6*/
  v2 = (_QWORD *)(v1 + 280); /*0x1066f5fed*/
  v3 = (char *)this + 4600; /*0x1066f5ff4*/
  if ( v1 == 0 ) /*0x1066f5ffe*/
    v2 = (_QWORD *)((char *)this + 4600); /*0x1066f5ffe*/
  if ( *v2 != 0 ) /*0x1066f6006*/
  {
    RBX::Network::Client::getAndHandleConnectionEvents(this); /*0x1066f600f*/
    v5 = *((_QWORD *)this + 574); /*0x1066f6014*/
    v6 = (char *)(v5 + 280); /*0x1066f601b*/
    if ( v5 == 0 ) /*0x1066f6025*/
      v6 = v3; /*0x1066f6025*/
    (*(void (__fastcall **)(__int64 *))(**(_QWORD **)v6 + 160LL))(a1: &v12); /*0x1066f6036*/
    v14 = 0; /*0x1066f6046*/
    if ( DFFlag::RbxTransportNetworkTracing == 1 ) /*0x1066f6051*/
    {
      RBX::Time::nowFast(this: v7); /*0x1066f6053*/
      v14 = v8; /*0x1066f6058*/
    }
    v9 = v12; /*0x1066f6060*/
    for ( i = v13; v9 != i; v9 += 96 ) /*0x1066f6071*/
    {
      RBX::RbxTransport::NetStream::NetStream(a1: v18); /*0x1066f608b*/
      RBX::Network::IncomingPacket::IncomingPacket(a1: v20, a2: v18); /*0x1066f609a*/
      RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v19); /*0x1066f60a6*/
      v20[4] = v14; /*0x1066f60b3*/
      qmemcpy(v15, v20, sizeof(v15)); /*0x1066f60c9*/
      std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1066f60f3*/
        a1: v16,
        a2: v21);
      RBX::Network::Client::OnReceiveV2(a1: this, a2: v15); /*0x1066f60fe*/
      if ( v17[88] == 1 ) /*0x1066f610a*/
        RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v17); /*0x1066f6113*/
      if ( v22[88] == 1 ) /*0x1066f611c*/
        RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v22); /*0x1066f6125*/
    }
    v20[0] = &v12; /*0x1066f6145*/
    std::vector<RBX::RbxTransport::NetStream>::__destroy_vector::operator()[abi:ne200100](); /*0x1066f6148*/
  }
  return __stack_chk_guard; /*0x1066f615d*/
}

// Address: 0x1066f61da | Name: __ZN3RBX7Network6Client11OnReceiveV2ENS0_14IncomingPacketE
__int64 __fastcall RBX::Network::Client::OnReceiveV2(RBX::Network::Client *a1, RBX::Network::IncomingPacket *a2)
{
  __int64 v4; // r14
  __int128 v5; // xmm0
  _QWORD v7[5]; // [rsp+0h] [rbp-B0h] BYREF
  _BYTE v8[8]; // [rsp+28h] [rbp-88h] BYREF
  _BYTE v9[104]; // [rsp+30h] [rbp-80h] BYREF

  if ( (unsigned __int8)RBX::Network::IncomingPacket::operator[](a1: a2, a2: 0) == 0x9C ) /*0x1066f6208*/
    RBX::Network::Client::handleExtAntiCheatV2(this: a1, a2); /*0x1066f6210*/
  v4 = *((_QWORD *)a1 + 574); /*0x1066f6215*/
  if ( v4 != 0 ) /*0x1066f621f*/
  {
    v7[4] = *((_QWORD *)a2 + 4); /*0x1066f622c*/
    v5 = *(_OWORD *)a2; /*0x1066f6230*/
    *(_OWORD *)&v7[2] = *((_OWORD *)a2 + 1); /*0x1066f6237*/
    *(_OWORD *)v7 = v5; /*0x1066f623b*/
    std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1066f6246*/
      a1: v8,
      a2: (char *)a2 + 40);
    ((void (__fastcall *)(__int64, _QWORD *))RBX::Network::ClientReplicator::OnReceiveV2)(a1: v4, a2: v7); /*0x1066f6255*/
    if ( v9[88] == 1 ) /*0x1066f625e*/
      RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v9); /*0x1066f6264*/
  }
  return __stack_chk_guard; /*0x1066f6279*/
}

// Address: 0x1066f62aa | Name: __ZN3RBX7Network6Client9OnReceiveEPN6RakNet6PacketE
__int64 __fastcall RBX::Network::Client::OnReceive(RBX::Network **this, RBX::Network::Replicator **a2)
{
  unsigned int v4; // ebx
  int v5; // ecx
  void *v6; // rsi
  unsigned int v7; // eax
  RBX::Network::Client *v8; // rdi
  unsigned int ConnectionErrorForRakNetID; // eax
  int v10; // ecx
  int v11; // r8d
  int v12; // r9d
  unsigned int *v13; // rdx
  RBX::Network *v14; // rdi
  unsigned __int8 v15; // al
  unsigned int v16; // r12d
  __int64 v17; // rax
  __int64 v18; // rdx
  __int64 v19; // rcx
  int v20; // ecx
  int v21; // r8d
  int v22; // r9d
  char *v23; // rdx
  unsigned int v24; // r14d
  __int64 v25; // r14
  __int64 v26; // rdx
  __int64 v27; // rcx
  __int64 v28; // r8
  __int64 v29; // r9
  void *v30; // rsi
  RBX::Memory *v31; // rdi
  __int64 v33; // r13
  __int64 v34; // rax
  __int64 v35; // rdx
  __int64 v36; // rcx
  void *v37; // rsi
  __int64 v38; // rdi
  _BYTE v39[32]; // [rsp+10h] [rbp-570h] BYREF
  void *v40; // [rsp+30h] [rbp-550h]
  char v41; // [rsp+48h] [rbp-538h]
  char v42; // [rsp+90h] [rbp-4F0h] BYREF
  unsigned int v43; // [rsp+91h] [rbp-4EFh] BYREF
  void *v44; // [rsp+A0h] [rbp-4E0h]
  _BYTE v45[40]; // [rsp+B0h] [rbp-4D0h] BYREF
  _BYTE v46[8]; // [rsp+D8h] [rbp-4A8h] BYREF
  _BYTE v47[96]; // [rsp+E0h] [rbp-4A0h] BYREF
  char v48[40]; // [rsp+140h] [rbp-440h] BYREF
  _BYTE v49[8]; // [rsp+168h] [rbp-418h] BYREF
  _BYTE v50[992]; // [rsp+170h] [rbp-410h] BYREF

  v4 = RBX::Memory::setCurrentCategory( /*0x1066f62e0*/
         this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkReplicator,
         (unsigned int)a2);
  RBX::Network::Client::HandlePacketCallback((RBX::Network::Client *)this, (RakNet::SystemAddress *)a2); /*0x1066f62e8*/
  v7 = *(unsigned __int8 *)a2[7]; /*0x1066f62f1*/
  if ( v7 <= 0x94 ) /*0x1066f62f9*/
  {
    v5 = v7 - 21; /*0x1066f62ff*/
    if ( v7 - 21 < 2 ) /*0x1066f6305*/
    {
      RakNet::SystemAddress::operator=(a1: this + 63, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS); /*0x1066f6319*/
      if ( DFFlag::DebugSignalOnIdConnectionLost == 1 ) /*0x1066f6325*/
      {
        RBX::Network::RakNetAddressToString( /*0x1066f633f*/
          this: (RBX::Network *)v48,
          (const RakNet::SystemAddress *)a2,
          a3: true,
          a4: 124);
        ConnectionErrorForRakNetID = RBX::Network::Client::getConnectionErrorForRakNetID( /*0x1066f634b*/
                                       this: v8,
                                       a2: *(unsigned __int8 *)a2[7]);
        RBX::Network::Client::requestDisconnectOnTransportFailure( /*0x1066f635c*/
          a1: (__int64)this,
          a2: (__int64)v48,
          a3: ConnectionErrorForRakNetID);
        if ( (v48[0] & 1) != 0 ) /*0x1066f6368*/
          operator delete(a1: *(RBX::Memory **)&v48[16], a2: v6); /*0x1066f6375*/
      }
      goto LABEL_12; /*0x1066f637a*/
    }
    if ( v7 != 24 ) /*0x1066f63a5*/
      goto LABEL_12; /*0x1066f63a5*/
    RakNet::SystemAddress::ToStringN(this: (RakNet::SystemAddress *)a2, a2: true, a3: v48, a4: 1025, a5: 124); /*0x1066f63c1*/
    RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066f63e8*/
      this,
      a2: "RakNetPasswordRejected",
      a3: 1u,
      a4: v48,
      a5: 3,
      a6: 1);
    RBX::Network::RakNetAddressToString( /*0x1066f6401*/
      this: (RBX::Network *)&v42,
      (const RakNet::SystemAddress *)a2,
      a3: true,
      a4: 124);
    if ( (v42 & 1) != 0 ) /*0x1066f640d*/
      LODWORD(v13) = (_DWORD)v44; /*0x1066f6413*/
    else
      v13 = &v43; /*0x1066f65db*/
    RBX::CreatorLog::printf( /*0x1066f65f0*/
      a1: 4,
      a2: (unsigned int)"Invalid password from %s",
      a3: (_DWORD)v13,
      a4: v10,
      a5: v11,
      a6: v12);
    if ( (v42 & 1) != 0 ) /*0x1066f65fc*/
      operator delete(a1: (RBX::Memory *)v44, a2: v30); /*0x1066f6605*/
    RBX::Network::RakNetAddressToString( /*0x1066f661e*/
      this: (RBX::Network *)&v42,
      (const RakNet::SystemAddress *)a2,
      a3: true,
      a4: 124);
    RBX::Network::Client::requestDisconnectOnTransportFailure(a1: (__int64)this, a2: (__int64)&v42, a3: 6u); /*0x1066f6632*/
LABEL_31:
    if ( (v42 & 1) == 0 ) /*0x1066f663e*/
    {
LABEL_34:
      v24 = 0; /*0x1066f664c*/
      goto LABEL_35; /*0x1066f664c*/
    }
    v31 = (RBX::Memory *)v44; /*0x1066f6640*/
LABEL_33:
    operator delete(a1: v31, a2: v6); /*0x1066f6647*/
    goto LABEL_34; /*0x1066f6647*/
  }
  if ( v7 == 149 ) /*0x1066f6384*/
  {
    RakNet::SystemAddress::ToStringN(this: (RakNet::SystemAddress *)a2, a2: true, a3: v48, a4: 1025, a5: 124); /*0x1066f64c7*/
    RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066f64ee*/
      this,
      a2: "SecurityKeyRejected",
      a3: 1u,
      a4: v48,
      a5: 3,
      a6: 1);
    RBX::Network::RakNetAddressToString( /*0x1066f6507*/
      this: (RBX::Network *)&v42,
      (const RakNet::SystemAddress *)a2,
      a3: true,
      a4: 124);
    RBX::Network::Client::requestDisconnectOnTransportFailure(a1: (__int64)this, a2: (__int64)&v42, a3: 0xAu); /*0x1066f651b*/
    goto LABEL_31; /*0x1066f6520*/
  }
  if ( v7 == 156 ) /*0x1066f638f*/
    RBX::Network::Client::handleExtAntiCheat_deprecated(a1: (__int64)this, (__int64)a2); /*0x1066f639b*/
LABEL_12:
  v14 = *(this + 574); /*0x1066f641f*/
  if ( v14 != nullptr )
  {
    if ( (unsigned __int8)RBX::Network::shouldAttemptDecompression(
                            this: v14,
                            a2: a2[7],
                            a3: (unsigned __int8 *)*((unsigned int *)a2 + 12),
                            a4: v5) != 0 )
    {
      if ( FFlag::AddHashToCompressionFlaggedCheck == 1 )
      {
        v15 = RBX::NetworkBase::ConnectionInternal::decompressPacket(a1: *((_QWORD *)*(this + 574) + 35), a2); /*0x1066f6461*/
        if ( v15 != 0 )
        {
          v16 = v15; /*0x1066f646e*/
          v17 = RBX::NetworkBase::decompressionResultToErrorMessage(a1: v15); /*0x1066f6475*/
          std::string::basic_string[abi:ne200100]<0>(a1: v48, a2: v17, a3: v18, a4: v19); /*0x1066f6484*/
          if ( (v48[0] & 1) != 0 ) /*0x1066f6490*/
            LODWORD(v23) = *(_DWORD *)&v48[16]; /*0x1066f6496*/
          else
            v23 = &v48[1]; /*0x1066f667f*/
          RBX::CreatorLog::printf(
            a1: 3,
            a2: (unsigned int)"Client::OnReceive error while trying to decompress packet: %s",
            a3: (_DWORD)v23,
            a4: v20,
            a5: v21,
            a6: v22);
          if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
            FLog::FastLogSafeFormatted<std::string &>(
              a1: FLog::Network,
              a2: qword_10D7BBAA8,
              a3: 3,
              a4: (int)"[FLog::Network] Error decompressing packet in Client::OnReceive: {}",
              a5: 67,
              a6: (unsigned __int8 *)v48);
          v33 = (__int64)*(this + 574); /*0x1066f66db*/
          v34 = RBX::NetworkBase::decompressionResultToErrorType(a1: v16); /*0x1066f66e5*/
          std::string::basic_string[abi:ne200100]<0>(a1: &v42, a2: v34, a3: v35, a4: v36); /*0x1066f66f4*/
          RBX::Network::Replicator::logPacketError(a1: v33, a2, a3: &v42, a4: v48, a5: 0xFFFFFFFFLL); /*0x1066f6713*/
          if ( (v42 & 1) != 0 ) /*0x1066f671f*/
            operator delete(a1: (RBX::Memory *)v44, a2: v37); /*0x1066f6728*/
          v38 = (__int64)*(this + 574); /*0x1066f672d*/
          v39[0] = 0; /*0x1066f673d*/
          v41 = 0; /*0x1066f673f*/
          RBX::Network::Replicator::requestDisconnectWithSignal(a1: v38, a2: 260, a3: v39); /*0x1066f6747*/
          if ( v41 == 1 && (v39[16] & 1) != 0 ) /*0x1066f675c*/
            operator delete(a1: (RBX::Memory *)v40, a2: v6); /*0x1066f6765*/
          if ( (v48[0] & 1) == 0 ) /*0x1066f6771*/
            goto LABEL_34; /*0x1066f6771*/
          v31 = *(RBX::Memory **)&v48[16]; /*0x1066f6777*/
          goto LABEL_33; /*0x1066f677e*/
        }
      }
      else
      {
        RBX::NetworkBase::ConnectionInternal::decompressPacket_deprecated(a1: a2); /*0x1066f6528*/
      }
    }
    if ( FFlag::RefactorIngressFlow == 1 ) /*0x1066f6537*/
    {
      RBX::Network::IncomingPacket::IncomingPacket(a1: v48, a2); /*0x1066f6547*/
      v25 = (__int64)*(this + 574); /*0x1066f654c*/
      qmemcpy(v45, v48, sizeof(v45)); /*0x1066f6565*/
      std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1066f6579*/
        a1: v46,
        a2: v49);
      v24 = RBX::Network::ClientReplicator::OnReceiveV2(a1: v25, a2: v45, a3: v26, a4: v27, a5: v28, a6: v29); /*0x1066f658d*/
      if ( v47[88] == 1 ) /*0x1066f6597*/
        RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v47); /*0x1066f65a0*/
      if ( v50[88] == 1 ) /*0x1066f65ac*/
        RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v50); /*0x1066f65b9*/
    }
    else
    {
      v24 = (*(__int64 (__fastcall **)(_QWORD, RBX::Network::Replicator **))(*(_QWORD *)*(this + 574) + 704LL))( /*0x1066f65d6*/
              a1: *(this + 574),
              a2);
    }
  }
  else
  {
    v24 = 1; /*0x1066f64a2*/
  }
LABEL_35:
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v4, a2: (unsigned int)v6); /*0x1066f664f*/
  return v24; /*0x1066f666d*/
}

// Address: 0x1066f6a44 | Name: __ZN3RBX7Network6Client20HandlePacketCallbackEPN6RakNet6PacketE
__int64 __fastcall RBX::Network::Client::HandlePacketCallback(RBX::Network::Client *this, RakNet::SystemAddress *a2)
{
  __int64 result; // rax
  int v5; // ecx
  int v6; // ecx
  _BYTE v7[16]; // [rsp+10h] [rbp-30h] BYREF
  __int64 v8; // [rsp+20h] [rbp-20h]
  _BYTE *v9; // [rsp+28h] [rbp-18h]

  result = **((unsigned __int8 **)a2 + 7); /*0x1066f6a53*/
  if ( (unsigned int)result <= 0x1A ) /*0x1066f6a59*/
  {
    v5 = 127281152; /*0x1066f6a65*/
    if ( _bittest(&v5, result) ) /*0x1066f6a6a*/
    {
      return RBX::Network::Client::OnFailedConnectionAttempt(this, a2); /*0x1066f6a7d*/
    }
    else
    {
      v6 = 6291456; /*0x1066f6a82*/
      if ( _bittest(&v6, result) ) /*0x1066f6a87*/
      {
        return RBX::Network::Client::OnClosedConnection(this, a2); /*0x1066f6a9a*/
      }
      else if ( (_DWORD)result == 16 ) /*0x1066f6aa2*/
      {
        if ( (unsigned __int8)DFLog::NetworkClient >= 6u && BYTE1(DFLog::NetworkClient) >= 5u ) /*0x1066f6ab9*/
        {
          v8 = 0; /*0x1066f6ac7*/
          v9 = v7; /*0x1066f6ad3*/
          FLog::detail::FastLogSafeFormattedInternal( /*0x1066f6af7*/
            a1: (_DWORD)DFLog::NetworkClient,
            a2: qword_10D809380,
            a3: 5,
            a4: (unsigned int)"[DFLog::NetworkClient] RakPeer received ID_CONNECTION_REQUEST_ACCEPTED packet, calling OnNewCo"
                          "nnection callback of plugin",
            a5: 121,
            a6: 1,
            0,
            v7);
        }
        return RBX::Network::Client::OnNewConnection((RBX::Network::ConcurrentRakPeer **)this, a2); /*0x1066f6b02*/
      }
    }
  }
  return result; /*0x1066f6a75*/
}

// Address: 0x1066f6b12 | Name: __ZThn176_N3RBX7Network6Client9OnReceiveEPN6RakNet6PacketE
__int64 __fastcall `non-virtual thunk to'RBX::Network::Client::OnReceive(__int64 a1, RBX::Network::Replicator **a2)
{
  return RBX::Network::Client::OnReceive(this: (RBX::Network **)(a1 - 176), a2); /*0x1066f6b1d*/
}

// Address: 0x1066f6b24 | Name: __ZN3RBX7Network6Client18getConnectedServerEv
RBX::Network::Client *__fastcall RBX::Network::Client::getConnectedServer(
        RBX::Network::Client *this,
        __int64 a2,
        unsigned __int64 a3)
{
  __int64 v4; // rdi
  __int64 v5; // rcx
  unsigned __int64 v6; // rax
  __int64 v7; // rdx
  char *v8; // rsi
  int v9; // r8d
  int v10; // r9d
  char v12[1040]; // [rsp+0h] [rbp-420h] BYREF

  v4 = *(_QWORD *)(a2 + 4952); /*0x1066f6b41*/
  v5 = *(_QWORD *)(a2 + 4960) - v4; /*0x1066f6b4f*/
  if ( v5 != 0 )
  {
    v6 = 0x2E8BA2E8BA2E8BA3LL * (v5 >> 3); /*0x1066f6b62*/
    LODWORD(v5) = 1; /*0x1066f6b66*/
    a3 = 0; /*0x1066f6b6b*/
    while ( 1 ) /*0x1066f6b6d*/
    {
      v7 = 88 * a3; /*0x1066f6b6d*/
      if ( *(_DWORD *)(v4 + v7 + 36) == 2 ) /*0x1066f6b76*/
        break; /*0x1066f6b76*/
      a3 = (unsigned int)v5; /*0x1066f6b78*/
      v5 = (unsigned int)(v5 + 1); /*0x1066f6b7a*/
      if ( v6 <= a3 ) /*0x1066f6b7f*/
        goto LABEL_5; /*0x1066f6b7f*/
    }
    RBX::Network::ConnectionInfo::ToStringN( /*0x1066f6ba4*/
      this: (RBX::Network::ConnectionInfo *)(v7 + v4),
      a2: true,
      a3: v12,
      a4: 1025,
      a5: 124);
    v5 = (unsigned int)DFLog::NetworkTrace >> 8; /*0x1066f6bb5*/
    LOBYTE(a3) = (unsigned __int8)DFLog::NetworkTrace < 6u; /*0x1066f6bbc*/
    LOBYTE(v5) = (unsigned __int8)DFLog::NetworkTrace < 6u || BYTE1(DFLog::NetworkTrace) < 3u; /*0x1066f6bc5*/
    if ( (_BYTE)v5 == 0 )
      FLog::FastLogFormatted(
        a1: DFLog::NetworkTrace,
        a2: qword_10D7BB068,
        a3: (unsigned int)"[DFLog::NetworkTrace] getConnectedServer::: returning %s",
        a4: (unsigned int)v12,
        a5: v9,
        a6: v10);
    v8 = v12; /*0x1066f6be2*/
  }
  else
  {
LABEL_5:
    v8 = ""; /*0x1066f6b81*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: this, a2: v8, a3, a4: v5); /*0x1066f6bec*/
  return this; /*0x1066f6c04*/
}

// Address: 0x1066f6c14 | Name: __ZNK3RBX7Network6Client12askSetParentEPKNS_8InstanceE
__int64 __fastcall RBX::Network::Client::askSetParent(RBX::Network::Client *this, const RBX::Instance *a2)
{
  if ( (unsigned __int8)RBX::Service::askSetParent2(this: a2, a2) != 0 ) /*0x1066f6c2b*/
    return RBX::Instance::askSetParent(this, a2); /*0x1066f6c37*/
  else
    return 0; /*0x1066f6c3c*/
}

// Address: 0x1066f6c44 | Name: __ZNK3RBX7Network6Client15verifySetParentEPKNS_8InstanceE
__int64 __fastcall RBX::Network::Client::verifySetParent(
        RBX::Network::Client *this,
        const RBX::Instance *a2,
        const RBX::Instance *a3)
{
  return RBX::Service::verifySetParent2(this, a2, a3); /*0x1066f6c48*/
}

// Address: 0x1066f6c50 | Name: __ZN3RBX7Network6Client30luaGetConnectionAcceptedSignalEb
__int64 __fastcall RBX::Network::Client::luaGetConnectionAcceptedSignal(RBX::Network::Client *this)
{
  __int64 v2; // rdx
  unsigned __int8 *v3; // rcx
  __int64 v4; // rax
  void *v5; // rsi
  _BYTE v7[16]; // [rsp+0h] [rbp-200h] BYREF
  void *v8; // [rsp+10h] [rbp-1F0h]
  void *v9[59]; // [rsp+18h] [rbp-1E8h] BYREF

  if ( DFInt::ClientReportLuaConnectionSignalsInfluxHundrethsPercentage != 0
    && RBX::Network::Client::luaGetConnectionAcceptedSignal(bool)::reported == 0 )
  {
    RBX::Network::Client::luaGetConnectionAcceptedSignal(bool)::reported = 1; /*0x1066f6c87*/
    RBX::Analytics::InfluxDb::Points::Points(a1: v9, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1066f6c9e*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066f6cb8*/
      this: (RBX::Analytics::InfluxDb::Points *)v9,
      a2: "Signal",
      a3: "ConnectionAccepted");
    if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
    {
      v3 = SFString::RCCChannelName; /*0x1066f6cc9*/
      v4 = (SFString::RCCChannelName[0] & 1) != 0
         ? *(_QWORD *)&SFString::RCCChannelName[8]
         : SFString::RCCChannelName[0] >> 1;
      if ( v4 != 0 ) /*0x1066f6ce2*/
        RBX::Analytics::InfluxDb::Points::addPoint(a1: v9, a2: "rccChannelName", a3: SFString::RCCChannelName); /*0x1066f6cf9*/
    }
    std::string::basic_string[abi:ne200100]<0>(a1: v7, a2: "ClientConnectionSignals", a3: v2, a4: v3); /*0x1066f6d0c*/
    RBX::Analytics::InfluxDb::Points::report( /*0x1066f6d27*/
      a1: v9,
      a2: v7,
      a3: (unsigned int)DFInt::ClientReportLuaConnectionSignalsInfluxHundrethsPercentage,
      a4: 0);
    if ( (v7[0] & 1) != 0 ) /*0x1066f6d33*/
      operator delete(a1: (RBX::Memory *)v8, a2: v5); /*0x1066f6d3c*/
    RBX::Analytics::InfluxDb::Points::~Points(this: v9); /*0x1066f6d48*/
  }
  return (__int64)this + 4824; /*0x1066f6d67*/
}

// Address: 0x1066f6dae | Name: __ZN3RBX7Network6Client28luaGetConnectionFailedSignalEb
__int64 __fastcall RBX::Network::Client::luaGetConnectionFailedSignal(RBX::Network::Client *this)
{
  __int64 v2; // rdx
  unsigned __int8 *v3; // rcx
  __int64 v4; // rax
  void *v5; // rsi
  _BYTE v7[16]; // [rsp+0h] [rbp-200h] BYREF
  void *v8; // [rsp+10h] [rbp-1F0h]
  void *v9[59]; // [rsp+18h] [rbp-1E8h] BYREF

  if ( DFInt::ClientReportLuaConnectionSignalsInfluxHundrethsPercentage != 0
    && RBX::Network::Client::luaGetConnectionFailedSignal(bool)::reported == 0 )
  {
    RBX::Network::Client::luaGetConnectionFailedSignal(bool)::reported = 1; /*0x1066f6de5*/
    RBX::Analytics::InfluxDb::Points::Points(a1: v9, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1066f6dfc*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1066f6e16*/
      this: (RBX::Analytics::InfluxDb::Points *)v9,
      a2: "Signal",
      a3: "ConnectionFailed");
    if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
    {
      v3 = SFString::RCCChannelName; /*0x1066f6e27*/
      v4 = (SFString::RCCChannelName[0] & 1) != 0
         ? *(_QWORD *)&SFString::RCCChannelName[8]
         : SFString::RCCChannelName[0] >> 1;
      if ( v4 != 0 ) /*0x1066f6e40*/
        RBX::Analytics::InfluxDb::Points::addPoint(a1: v9, a2: "rccChannelName", a3: SFString::RCCChannelName); /*0x1066f6e57*/
    }
    std::string::basic_string[abi:ne200100]<0>(a1: v7, a2: "ClientConnectionSignals", a3: v2, a4: v3); /*0x1066f6e6a*/
    RBX::Analytics::InfluxDb::Points::report( /*0x1066f6e85*/
      a1: v9,
      a2: v7,
      a3: (unsigned int)DFInt::ClientReportLuaConnectionSignalsInfluxHundrethsPercentage,
      a4: 0);
    if ( (v7[0] & 1) != 0 ) /*0x1066f6e91*/
      operator delete(a1: (RBX::Memory *)v8, a2: v5); /*0x1066f6e9a*/
    RBX::Analytics::InfluxDb::Points::~Points(this: v9); /*0x1066f6ea6*/
  }
  return (__int64)this + 4832; /*0x1066f6ec5*/
}

// Address: 0x1066f6f0c | Name: __ZN3RBX7Network6Client13hasReplicatorEv
bool __fastcall RBX::Network::Client::hasReplicator(RBX::Network::Client *this)
{
  return *((_QWORD *)this + 574) != 0; /*0x1066f6f1b*/
}

// Address: 0x1066f6f1e | Name: __ZN3RBX7Network6Client19hasServerConnectionEv
bool __fastcall RBX::Network::Client::hasServerConnection(RBX::Network::Client *this)
{
  __int64 v1; // rdx
  __int64 v2; // rcx
  __int64 v3; // rdx
  bool result; // al
  bool v5; // zf

  v1 = *((_QWORD *)this + 619); /*0x1066f6f1e*/
  v2 = *((_QWORD *)this + 620); /*0x1066f6f25*/
  if ( v1 == v2 ) /*0x1066f6f2f*/
    return false; /*0x1066f6f50*/
  v3 = v1 + 88; /*0x1066f6f35*/
  do /*0x1066f6f4c*/
  {
    result = *(_DWORD *)(v3 - 52) == 2; /*0x1066f6f3d*/
    if ( *(_DWORD *)(v3 - 52) == 2 ) /*0x1066f6f40*/
      break; /*0x1066f6f40*/
    v5 = v3 == v2; /*0x1066f6f46*/
    v3 += 88; /*0x1066f6f49*/
  }
  while ( !v5 ); /*0x1066f6f4c*/
  return result; /*0x1066f6f4f*/
}

// Address: 0x1066f6f54 | Name: __ZN3RBX7Network6Client27handleClientServerTimeEventEx
void __fastcall RBX::Network::Client::handleClientServerTimeEvent(RBX::Network::Client *this)
{
  ; /*0x1066f6f54*/
}

// Address: 0x1066f6f5a | Name: __ZN3RBX7Network6Client43updateMonotonicClockDifferential_deprecatedEyx
__int64 __fastcall RBX::Network::Client::updateMonotonicClockDifferential_deprecated(
        RBX::Network::Client *this,
        RBX::Instance *a2,
        __int64 a3)
{
  __int64 Dangerous_DEPRECATED; // rax
  __int64 v6; // rax
  _QWORD v8[4]; // [rsp+0h] [rbp-50h] BYREF
  _QWORD *v9; // [rsp+20h] [rbp-30h]

  Dangerous_DEPRECATED = RBX::DataModel::getDangerous_DEPRECATED(this, a2); /*0x1066f6f7b*/
  if ( Dangerous_DEPRECATED != 0 ) /*0x1066f6f83*/
  {
    v8[0] = off_10CAA7CE8; /*0x1066f6f90*/
    v8[1] = a2; /*0x1066f6f93*/
    v8[2] = a3; /*0x1066f6f97*/
    v9 = v8; /*0x1066f6f9b*/
    RBX::DataModel::submitTask(a1: Dangerous_DEPRECATED, a2: v8, a3: 1); /*0x1066f6faa*/
    if ( v9 == v8 ) /*0x1066f6fb6*/
    {
      v6 = 32; /*0x1066f6fc4*/
    }
    else
    {
      v6 = 40; /*0x1066f6fb8*/
      if ( v9 == nullptr ) /*0x1066f6fc0*/
        return __stack_chk_guard; /*0x1066f6fc0*/
    }
    (*(void (**)(void))(*v9 + v6))(); /*0x1066f6fcc*/
  }
  return __stack_chk_guard; /*0x1066f6fdf*/
}

// Address: 0x1066f7018 | Name: __ZThn176_N3RBX7Network6Client43updateMonotonicClockDifferential_deprecatedEyx
__int64 __fastcall `non-virtual thunk to'RBX::Network::Client::updateMonotonicClockDifferential_deprecated(
        RBX::Network::Client *this,
        RBX::Instance *a2,
        __int64 a3)
{
  return RBX::Network::Client::updateMonotonicClockDifferential_deprecated( /*0x1066f7023*/
           this: (RBX::Network::Client *)((char *)this - 176),
           a2,
           a3);
}

// Address: 0x1066f702a | Name: __ZN3RBX7Network6Client44updateRbxTransportMonotonicClockDifferentialEyx
__int64 __fastcall RBX::Network::Client::updateRbxTransportMonotonicClockDifferential(
        RBX::Network::Client *this,
        RBX::Instance *a2,
        __int64 a3)
{
  RBX::PeerMonotonicClockManager *v6; // rdi
  __int64 Dangerous_DEPRECATED; // rax
  __int64 v8; // rax
  _QWORD v10[4]; // [rsp+0h] [rbp-50h] BYREF
  _QWORD *v11; // [rsp+20h] [rbp-30h]

  if ( DFFlag::OpenTelemetryUsePeerMonotonicClock == 1 /*0x1066f7064*/
    && RBX::Subsystem<RBX::PeerMonotonicClockManager,true>::defaultHandle != 0 )
  {
    v6 = *(RBX::PeerMonotonicClockManager **)(RBX::Subsystem<RBX::PeerMonotonicClockManager,true>::defaultHandle + 24); /*0x1066f7066*/
    if ( v6 != nullptr ) /*0x1066f706d*/
      RBX::PeerMonotonicClockManager::setDifferential(this: v6, (unsigned __int64)a2, a3); /*0x1066f7075*/
  }
  Dangerous_DEPRECATED = RBX::DataModel::getDangerous_DEPRECATED(this, a2); /*0x1066f707d*/
  if ( Dangerous_DEPRECATED != 0 ) /*0x1066f7085*/
  {
    v10[0] = off_10CAA7D68; /*0x1066f7092*/
    v10[1] = a2; /*0x1066f7095*/
    v10[2] = a3; /*0x1066f7099*/
    v11 = v10; /*0x1066f709d*/
    RBX::DataModel::submitTask(a1: Dangerous_DEPRECATED, a2: v10, a3: 1); /*0x1066f70ac*/
    if ( v11 == v10 ) /*0x1066f70b8*/
    {
      v8 = 32; /*0x1066f70c6*/
    }
    else
    {
      v8 = 40; /*0x1066f70ba*/
      if ( v11 == nullptr ) /*0x1066f70c2*/
        return __stack_chk_guard; /*0x1066f70c2*/
    }
    (*(void (**)(void))(*v11 + v8))(); /*0x1066f70ce*/
  }
  return __stack_chk_guard; /*0x1066f70e1*/
}

// Address: 0x1066f711a | Name: __ZN3RBX7Network6Client9setTicketERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall RBX::Network::Client::setTicket(__int64 a1, __int64 a2)
{
  unsigned int v3; // eax
  __int64 v4; // rcx
  __int64 v5; // rax
  void *v6; // rsi
  void *v7; // rdi
  std::__shared_weak_count *v8; // r14
  bool v9; // si
  __int64 v10; // rax
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v12; // rbx
  _QWORD v13[2]; // [rsp+8h] [rbp-68h] BYREF
  unsigned __int64 v14; // [rsp+18h] [rbp-58h] BYREF
  std::__shared_weak_count *v15[2]; // [rsp+20h] [rbp-50h] BYREF
  void *v16[4]; // [rsp+30h] [rbp-40h] BYREF
  std::__shared_weak_count *v17[2]; // [rsp+50h] [rbp-20h] BYREF

  std::string::operator=(a1: a1 + 544, a2); /*0x1066f712f*/
  v3 = *(unsigned __int8 *)(a1 + 544); /*0x1066f7134*/
  if ( (v3 & 1) != 0 ) /*0x1066f713d*/
  {
    v4 = *(_QWORD *)(a1 + 560); /*0x1066f713f*/
    v5 = *(_QWORD *)(a1 + 552); /*0x1066f7146*/
  }
  else
  {
    v4 = a1 + 545; /*0x1066f714f*/
    v5 = v3 >> 1; /*0x1066f7156*/
  }
  v13[0] = v4; /*0x1066f715c*/
  v13[1] = v5; /*0x1066f715f*/
  memset(v16, 0, 24); /*0x1066f716a*/
  RBX::detail::StringViewBase::split(a1: v13, a2: v16, a3: 59, a4: 0xFFFFFFFFLL, a5: 1); /*0x1066f7185*/
  v7 = v16[0]; /*0x1066f718a*/
  if ( (void *)((char *)v16[1] - (char *)v16[0]) >= (void *)0x41 ) /*0x1066f7199*/
  {
    RBX::make_shared<RBX::Security::EarlyAuthData>(a1: (RSL::Arena *)v17, a2: (unsigned __int64)v6); /*0x1066f71a3*/
    v8 = v17[0]; /*0x1066f71ac*/
    if ( RBX::getAsUnsignedInteger(a1: *((char **)v16[1] - 2), a2: *((_QWORD *)v16[1] - 1), a3: 0xAu, a4: &v14) != 0 /*0x1066f71d4*/
      && v14 <= 0xFF )
    {
      *((_BYTE *)v8 + 48) = v14; /*0x1066f71d6*/
    }
    base64<char,std::char_traits<char>>::decode( /*0x1066f71ea*/
      a1: *((_QWORD *)v16[0] + 4),
      a2: *((_QWORD *)v16[0] + 5),
      a3: (__int64)v17[0]);
    base64<char,std::char_traits<char>>::decode( /*0x1066f7203*/
      a1: *((_QWORD *)v16[0] + 6),
      a2: *((_QWORD *)v16[0] + 7),
      a3: (__int64)v17[0] + 24);
    if ( (unsigned __int8)RBX::Network::useRbxTransport(this: nullptr, a2: v9) != 0 /*0x1066f721a*/
      || FFlag::RakNetConnectionFailureFallbackToRbxTransport == 1 )
    {
      std::optional<RBX::Security::EarlyAuthData>::operator=[abi:ne200100]<RBX::Security::EarlyAuthData&,void>( /*0x1066f7227*/
        a1: a1 + 5024,
        a2: v17[0]);
    }
    v10 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *(RBX::Network::ConcurrentRakPeer **)(a1 + 288)); /*0x1066f7233*/
    *(_OWORD *)v15 = *(_OWORD *)v17; /*0x1066f7240*/
    if ( v17[1] != nullptr ) /*0x1066f7247*/
      _InterlockedIncrement64((volatile signed __int64 *)v17[1] + 1); /*0x1066f7249*/
    (*(void (__fastcall **)(__int64, std::__shared_weak_count **))(*(_QWORD *)v10 + 864LL))(a1: v10, a2: v15); /*0x1066f7258*/
    v11 = v15[1]; /*0x1066f725e*/
    if ( v15[1] != nullptr /*0x1066f7277*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v15[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(a1: v11); /*0x1066f727f*/
      std::__shared_weak_count::__release_weak(this: v11); /*0x1066f7285*/
    }
    v12 = v17[1]; /*0x1066f728a*/
    if ( v17[1] != nullptr /*0x1066f72a3*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v17[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x1066f72ab*/
      std::__shared_weak_count::__release_weak(this: v12); /*0x1066f72b1*/
    }
    v7 = v16[0]; /*0x1066f72b6*/
  }
  if ( v7 != nullptr ) /*0x1066f72bd*/
  {
    v16[1] = v7; /*0x1066f72bf*/
    operator delete(a1: (RBX::Memory *)v7, a2: v6); /*0x1066f72c3*/
  }
}

// Address: 0x1066f7644 | Name: __ZNK3RBX7Network6Client20reportRuppInitResultENS_4Rupp9RuppError9ErrorCodeE
void __fastcall RBX::Network::Client::reportRuppInitResult(__int64 a1, unsigned int a2)
{
  __int64 v3; // rax
  __int64 v4; // r8
  unsigned __int8 *v5; // rcx
  _BYTE v6[72]; // [rsp+8h] [rbp-268h] BYREF
  _BYTE v7[544]; // [rsp+50h] [rbp-220h] BYREF

  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)4,std::enable_if<false,void>>( /*0x1066f7663*/
    a1: v6,
    a2: &RBX::Telemetry::kRuppInitResult);
  RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v7); /*0x1066f7672*/
  RBX::Telemetry::FieldsContainer::addField(a1: v7, a2: "errorCode", a3: 9, a4: (int)a2, a5: 1); /*0x1066f768f*/
  v3 = RBX::Rupp::RuppError::toString(a1: a2); /*0x1066f7697*/
  RBX::Telemetry::FieldsContainer::addField(a1: v7, a2: "errorMessage", a3: 12, a4: v3, a5: 1); /*0x1066f76b4*/
  if ( DFFlag::ClientNetworkTelemetryRCCChannelName == 1 )
  {
    v4 = (SFString::RCCChannelName[0] & 1) != 0
       ? *(_QWORD *)&SFString::RCCChannelName[8]
       : SFString::RCCChannelName[0] >> 1;
    if ( v4 != 0 ) /*0x1066f76e2*/
    {
      if ( (SFString::RCCChannelName[0] & 1) != 0 ) /*0x1066f76e6*/
        v5 = *(unsigned __int8 **)&SFString::RCCChannelName[16]; /*0x1066f76e8*/
      else
        v5 = &SFString::RCCChannelName[1]; /*0x1066f76ee*/
      RBX::Telemetry::FieldsContainer::addField(a1: v7, a2: "rccChannelName", a3: 14, a4: v5, a5: v4, a6: 1); /*0x1066f7706*/
    }
  }
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v6); /*0x1066f7712*/
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v6); /*0x1066f7725*/
}

// Address: 0x1066f7844 | Name: __ZN3RBX7Network6Client31setupServerConnectionAndLoggingERKNS0_19FinalConnectionArgsE
void __fastcall RBX::Network::Client::setupServerConnectionAndLogging(
        RBX::Network::Client *this,
        const RBX::Network::FinalConnectionArgs *a2)
{
  __int64 v4; // r13
  __int64 i; // r15
  char v6; // al
  char *v7; // rdi
  int v8; // r9d
  __int64 v9; // rcx
  __int64 v10; // rcx
  int v11; // r8d

  if ( FFlag::RbxTransportConnectionFailureFallbackToRakNet != 0 /*0x1066f7868*/
    || FFlag::RakNetConnectionFailureFallbackToRbxTransport == 1 )
  {
    v4 = *((_QWORD *)this + 619); /*0x1066f786a*/
    for ( i = *((_QWORD *)this + 620); /*0x1066f7871*/
          i != v4;
          std::allocator<RBX::Network::ConnectionInfo>::destroy[abi:ne200100](a1: (char *)this + 4968, a2: i) )
    {
      i -= 88; /*0x1066f7884*/
    }
    *((_QWORD *)this + 620) = v4; /*0x1066f7898*/
  }
  v6 = RBX::Network::ConnectionInfo::empty(this: (const RBX::Network::FinalConnectionArgs *)((char *)a2 + 88)); /*0x1066f78a6*/
  v7 = (char *)this + 4952; /*0x1066f78b2*/
  if ( v6 != 0 ) /*0x1066f78b7*/
  {
    std::vector<RBX::Network::ConnectionInfo>::push_back[abi:ne200100](a1: v7, a2); /*0x1066f78bc*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1066f78da*/
    {
      if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1066f78ec*/
        v9 = *((_QWORD *)a2 + 2); /*0x1066f78ee*/
      else
        LODWORD(v9) = (_DWORD)a2 + 1; /*0x1066f7928*/
      FLog::FastLogFormatted( /*0x1066f7947*/
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: (unsigned int)"[FLog::Network] Server Address = %s, Port = %d",
        a4: v9,
        a5: *((_DWORD *)a2 + 6),
        a6: v8);
    }
  }
  else
  {
    std::vector<RBX::Network::ConnectionInfo>::push_back[abi:ne200100](a1: v7, a2: (char *)a2 + 88); /*0x1066f78f7*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1066f7915*/
    {
      if ( (*((_BYTE *)a2 + 88) & 1) != 0 ) /*0x1066f7920*/
        v10 = *((_QWORD *)a2 + 13); /*0x1066f7922*/
      else
        LODWORD(v10) = (_DWORD)a2 + 89; /*0x1066f794c*/
      v11 = *((_DWORD *)a2 + 28); /*0x1066f7957*/
      if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1066f795e*/
        a2 = *((const RBX::Network::FinalConnectionArgs **)a2 + 2); /*0x1066f7960*/
      else
        LODWORD(a2) = (_DWORD)a2 + 1; /*0x1066f7966*/
      FLog::FastLogFormatted( /*0x1066f7978*/
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: (unsigned int)"[FLog::Network] UDMUX Address = %s, Port = %d | RCC Server Address = %s, Port = %d",
        a4: v10,
        a5: v11,
        a6: (_DWORD)a2);
    }
  }
}

// Address: 0x1066f79d2 | Name: __ZN3RBX7Network6Client23handleConnectionFailureERKNS0_22ConnectionFailureErrorEbRKNS_11NetworkBase19ConnectionStartArgsE
void __fastcall __noreturn RBX::Network::Client::handleConnectionFailure(
        RBX::Network::Client *this,
        const RBX::Network::ConnectionFailureError *a2,
        __int64 a3,
        const RBX::NetworkBase::ConnectionStartArgs *a4)
{
  char v4; // al
  int v6; // r15d
  const char *v7; // r12
  char v8; // r13
  unsigned __int8 v9; // r14
  RBX::Network::ConnectionInfo *v10; // rdi
  char *v11; // rax
  const char *v12; // rax
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // r8
  __int64 v16; // r9
  __m128 v17; // xmm0
  __m128 v18; // xmm1
  __m128 v19; // xmm2
  __m128 v20; // xmm3
  __m128 v21; // xmm4
  __m128 v22; // xmm5
  __m128 v23; // xmm6
  __m128 v24; // xmm7
  RBX::Time *v25; // [rsp+0h] [rbp-30h]

  LOBYTE(v25) = v4; /*0x1066f79df*/
  v6 = *((_DWORD *)a2 + 4); /*0x1066f79e3*/
  if ( v6 != 0 ) /*0x1066f79ea*/
  {
    if ( v6 == 3 ) /*0x1066f79f0*/
    {
      v25 = this; /*0x1066f7a11*/
      v7 = "RakNetDidNotStartConnectAttempt"; /*0x1066f7a15*/
      v9 = 1; /*0x1066f7a1c*/
      v8 = 0; /*0x1066f7a1f*/
    }
    else
    {
      if ( v6 != 2 ) /*0x1066f79f6*/
        goto LABEL_10; /*0x1066f79f6*/
      v25 = this; /*0x1066f79f8*/
      v7 = "RakNetStartupFailed"; /*0x1066f79fc*/
      v6 = 3; /*0x1066f7a03*/
      v8 = 1; /*0x1066f7a09*/
      v9 = 1; /*0x1066f7a0c*/
    }
  }
  else
  {
    v25 = this; /*0x1066f7a24*/
    v7 = "RuppSetupFailed"; /*0x1066f7a28*/
    v8 = 1; /*0x1066f7a2f*/
    v9 = 0; /*0x1066f7a32*/
  }
  v10 = (const RBX::NetworkBase::ConnectionStartArgs *)((char *)a4 + 88); /*0x1066f7a35*/
  if ( (_BYTE)a3 != 0 ) /*0x1066f7a3b*/
    v10 = a4; /*0x1066f7a3b*/
  v11 = (char *)RBX::Network::ConnectionInfo::toString(this: v10, a2: true); /*0x1066f7a44*/
  RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1066f7a5e*/
    this: (RBX::Network::ConcurrentRakPeer **)v25,
    a2: v7,
    a3: v9,
    a4: v11,
    a5: v6,
    a6: v8);
LABEL_10:
  v12 = (const char *)(*(__int64 (__fastcall **)(const RBX::Network::ConnectionFailureError *, const RBX::Network::ConnectionFailureError *, __int64, const RBX::NetworkBase::ConnectionStartArgs *))(*(_QWORD *)a2 + 16LL))( /*0x1066f7a63*/
                        a1: a2,
                        a2,
                        a3,
                        a4);
  RBX::throw_runtime_error( /*0x1066f7a78*/
    this: (RBX *)"%s",
    a2: v12,
    a3: v13,
    a4: v14,
    a5: v15,
    a6: v16,
    a7: v17,
    a8: v18,
    a9: v19,
    a10: v20,
    a11: v21,
    a12: v22,
    a13: v23,
    a14: v24,
    a15: (char)v25);
}

// Address: 0x1066f8c3c | Name: __ZZN3RBX7Network6Client35playerConnectWithConnectionInternalExRKNS0_19FinalConnectionArgsES4_iiiNSt3__110shared_ptrIKNS_10Reflection10ValueTableEEERNS_4Rupp8TokenTlv5TokenEbNS5_8optionalISD_EENSF_INS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEEENSF_INS_12RbxTransport12CapabilitiesEEEEN3$_1C1ERKSR_
__int64 __fastcall RBX::Network::Client::playerConnectWithConnectionInternal(long long,RBX::Network::FinalConnectionArgs const&,RBX::Network::FinalConnectionArgs const&,int,int,int,std::shared_ptr<RBX::Reflection::ValueTable const>,RBX::Rupp::TokenTlv::Token &,bool,std::optional<RBX::Rupp::TokenTlv::Token>,std::optional<std::string>,std::optional<RBX::RbxTransport::Capabilities>)::$_1::$_1(
        __int64 a1,
        __int64 a2)
{
  __int128 v4; // xmm0
  __int128 v5; // xmm1
  __int128 v6; // xmm2
  __int64 result; // rax

  *(_QWORD *)a1 = *(_QWORD *)a2; /*0x1066f8c50*/
  RBX::Network::ConnectionInfo::ConnectionInfo( /*0x1066f8c5e*/
    this: (RBX::Network::ConnectionInfo *)(a1 + 8),
    a2: (const RBX::Network::ConnectionInfo *)(a2 + 8));
  RBX::Network::ConnectionInfo::ConnectionInfo( /*0x1066f8c6b*/
    this: (RBX::Network::ConnectionInfo *)(a1 + 96),
    a2: (const RBX::Network::ConnectionInfo *)(a2 + 96));
  *(_OWORD *)(a1 + 245) = *(_OWORD *)(a2 + 245); /*0x1066f8c78*/
  v4 = *(_OWORD *)(a2 + 184); /*0x1066f8c80*/
  v5 = *(_OWORD *)(a2 + 200); /*0x1066f8c88*/
  v6 = *(_OWORD *)(a2 + 216); /*0x1066f8c90*/
  *(_OWORD *)(a1 + 232) = *(_OWORD *)(a2 + 232); /*0x1066f8ca0*/
  *(_OWORD *)(a1 + 216) = v6; /*0x1066f8ca8*/
  *(_OWORD *)(a1 + 200) = v5; /*0x1066f8cb0*/
  *(_OWORD *)(a1 + 184) = v4; /*0x1066f8cb8*/
  std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: a1 + 264, a2: a2 + 264); /*0x1066f8ccf*/
  *(_BYTE *)(a1 + 296) = 0; /*0x1066f8cd6*/
  *(_BYTE *)(a1 + 304) = 0; /*0x1066f8cdd*/
  if ( *(_BYTE *)(a2 + 304) == 1 ) /*0x1066f8cec*/
  {
    *(_QWORD *)(a1 + 296) = 0; /*0x1066f8cee*/
    _InterlockedExchange64((volatile __int64 *)(a1 + 296), *(_QWORD *)(a2 + 296)); /*0x1066f8d00*/
    *(_BYTE *)(a1 + 304) = 1; /*0x1066f8d07*/
  }
  *(_OWORD *)(a1 + 312) = 0; /*0x1066f8d19*/
  *(_QWORD *)(a1 + 328) = 0; /*0x1066f8d21*/
  std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1066f8d40*/
    a1: a1 + 312,
    a2: *(_QWORD *)(a2 + 312),
    a3: *(_QWORD *)(a2 + 320),
    a4: *(_QWORD *)(a2 + 320) - *(_QWORD *)(a2 + 312));
  *(_BYTE *)(a1 + 340) = *(_BYTE *)(a2 + 340); /*0x1066f8d4c*/
  result = *(unsigned int *)(a2 + 336); /*0x1066f8d53*/
  *(_DWORD *)(a1 + 336) = result; /*0x1066f8d5a*/
  return result; /*0x1066f8d61*/
}

// Address: 0x106d6ee9a | Name: __ZNK3RBX7Network6Client13getAsInternalENS_10Reflection11InterfaceIdE
__int64 __fastcall RBX::Network::Client::getAsInternal(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  result = 0; /*0x106d6eea5*/
  if ( a2 == 1 ) /*0x106d6eeab*/
    return a1 + 464; /*0x106d6eeab*/
  return result; /*0x106d6eeaf*/
}

// Address: 0x106d6eeb2 | Name: __ZN3RBX7Network6Client35writeAllPropertiesForChangeTrackingEPNS_23DataModelChangeTracking13ChangeTrackerENS2_12DeltaTypeTagE
__int64 RBX::Network::Client::writeAllPropertiesForChangeTracking()
{
  return RBX::Network::Peer::writeAllPropertiesForChangeTracking(); /*0x106d6eeb6*/
}

// Address: 0x10876000f | Name: __ZN3RBX7Network6Client34registerNetworkTestControlProviderEv.cold.1
void __fastcall RBX::Network::Client::registerNetworkTestControlProvider(
        RBX::Network::Client *this,
        _QWORD *a2,
        RBX::Memory *a3)
{
  _QWORD *v4; // rdi
  __int64 v5; // [rsp-10h] [rbp-18h]

  v4 = *(_QWORD **)this; /*0x108760018*/
  if ( v4 == a2 ) /*0x10876001e*/
  {
    v5 = 32; /*0x108760029*/
    goto LABEL_5; /*0x108760029*/
  }
  if ( v4 != nullptr ) /*0x108760023*/
  {
    v5 = 40; /*0x108760025*/
LABEL_5:
    (*(void (__fastcall **)(_QWORD *))(*v4 + v5))(a1: v4); /*0x10876002b*/
  }
  operator delete(a1: a3, a2); /*0x108760032*/
}

// END Client part 1/1, 110 functions
