// PingItem -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 8 functions


// Address: 0x1067fc298 | Name: __ZN3RBX7Network10Replicator8PingItemC2EPS1_yjNS_8SendModeE
void __fastcall RBX::Network::Replicator::PingItem::PingItem(__int64 a1, __int64 a2, __int64 a3, int a4, char a5)
{
  __int64 v10; // r15
  __int64 v11; // rdi
  __int64 v12; // rax
  RBX::Network *v13; // rdi
  RBX::Instance *v14; // rsi
  RBX::ServiceProvider *v15; // r15
  __int64 v16; // rax
  __int64 v17; // rdx
  __int64 v18; // rcx
  __int64 v19; // r12
  __int64 FirstChildByName; // rax
  __int64 v21; // rdx
  __int64 v22; // rcx
  void *v23; // rsi
  double v24; // xmm0_8
  __int64 v25; // r12
  __int64 v26; // r13
  __int64 v27; // rax
  __int64 v28; // rax
  void *v29; // rsi
  double v30; // xmm0_8
  double *v31; // r12
  __int64 v32; // r13
  __int64 v33; // rax
  float v34; // xmm0_4
  RBX::RunService *v35; // rax
  RBX::MemoryStats *v36; // rdi
  RBX::RunService *v37; // r12
  double v38; // xmm0_8
  double v39; // xmm0_8
  float v40; // xmm0_4
  __int64 v41; // rax
  float v42; // xmm0_4
  RBX::ScriptContext *v43; // rax
  __int64 v44; // rdi
  RBX::Network::NetworkTracer *v45; // rdi
  unsigned __int64 TracerObject; // r15
  RBX::Time *v47; // rdx
  RBX::Time *v48; // r12
  char TracerPeerId; // al
  _BYTE v50[16]; // [rsp+8h] [rbp-48h] BYREF
  void *v51; // [rsp+18h] [rbp-38h]
  float v52; // [rsp+24h] [rbp-2Ch]

  RBX::Network::Item::Item(this: (RBX::Network::Item *)a1, (RBX::Network::Replicator *)a2); /*0x1067fc2b8*/
  *(_QWORD *)a1 = off_10CAACF38; /*0x1067fc2c4*/
  *(_QWORD *)(a1 + 64) = a3; /*0x1067fc2c7*/
  *(_DWORD *)(a1 + 84) = 0; /*0x1067fc2cd*/
  *(_DWORD *)(a1 + 88) = a4; /*0x1067fc2d0*/
  *(_BYTE *)(a1 + 92) = a5; /*0x1067fc2d4*/
  *(_DWORD *)(a1 + 96) = 0; /*0x1067fc2d8*/
  v10 = *(_QWORD *)(a2 + 24); /*0x1067fc2db*/
  v12 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(a1: v11); /*0x1067fc2df*/
  if ( *(unsigned __int16 *)(v10 + 440) - (unsigned int)*(unsigned __int16 *)(v12 + 440) <= *(unsigned __int16 *)(v12 + 442) ) /*0x1067fc2fe*/
  {
    v15 = (RBX::ServiceProvider *)(RBX::DataModel::get(this: (RBX::DataModel *)a2, a2: v14) + 464); /*0x1067fc30f*/
    v16 = RBX::ServiceProvider::create<RBX::Stats::StatsService>(this: v15); /*0x1067fc31b*/
    v52 = 0.0; /*0x1067fc323*/
    if ( v16 != 0 ) /*0x1067fc32b*/
    {
      v19 = v16; /*0x1067fc331*/
      std::string::basic_string[abi:ne200100]<0>(a1: v50, a2: "FrameRateManager", a3: v17, a4: v18); /*0x1067fc33f*/
      FirstChildByName = RBX::Instance::findFirstChildByName(a1: v19, a2: v50, a3: 0); /*0x1067fc34d*/
      v25 = FirstChildByName; /*0x1067fc352*/
      if ( FirstChildByName != 0 ) /*0x1067fc358*/
      {
        v26 = *(_QWORD *)(FirstChildByName + 24); /*0x1067fc35a*/
        v27 = RBX::Reflection::Class_getDescriptorPtr<RBX::Stats::Item>(a1: v24); /*0x1067fc35f*/
        v22 = *(unsigned __int16 *)(v26 + 440) - (unsigned int)*(unsigned __int16 *)(v27 + 440); /*0x1067fc373*/
        v21 = 0; /*0x1067fc37c*/
        if ( (unsigned int)v22 > *(unsigned __int16 *)(v27 + 442) ) /*0x1067fc380*/
          v25 = 0; /*0x1067fc380*/
      }
      else
      {
        v25 = 0; /*0x1067fc386*/
      }
      if ( (v50[0] & 1) != 0 ) /*0x1067fc38d*/
        operator delete(a1: (RBX::Memory *)v51, a2: v23); /*0x1067fc393*/
      if ( v25 != 0 ) /*0x1067fc39b*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: v50, a2: "AverageFPS", a3: v21, a4: v22); /*0x1067fc3ac*/
        v28 = RBX::Instance::findFirstChildByName(a1: v25, a2: v50, a3: 0); /*0x1067fc3ba*/
        v31 = (double *)v28; /*0x1067fc3bf*/
        if ( v28 != 0 ) /*0x1067fc3c5*/
        {
          v32 = *(_QWORD *)(v28 + 24); /*0x1067fc3c7*/
          v33 = RBX::Reflection::Class_getDescriptorPtr<RBX::Stats::Item>(a1: v30); /*0x1067fc3cc*/
          if ( *(unsigned __int16 *)(v32 + 440) - (unsigned int)*(unsigned __int16 *)(v33 + 440) > *(unsigned __int16 *)(v33 + 442) ) /*0x1067fc3ed*/
            v31 = nullptr; /*0x1067fc3ed*/
        }
        else
        {
          v31 = nullptr; /*0x1067fc3f3*/
        }
        if ( (v50[0] & 1) != 0 ) /*0x1067fc3fa*/
          operator delete(a1: (RBX::Memory *)v51, a2: v29); /*0x1067fc400*/
        if ( v31 != nullptr ) /*0x1067fc408*/
        {
          (*(void (__fastcall **)(double *))(*(_QWORD *)v31 + 616LL))(a1: v31); /*0x1067fc411*/
          v34 = v31[22]; /*0x1067fc41a*/
          v52 = v34; /*0x1067fc424*/
        }
      }
    }
    *(float *)(a1 + 72) = v52; /*0x1067fc42e*/
    v35 = (RBX::RunService *)RBX::ServiceProvider::find<RBX::RunService>(a1: a2); /*0x1067fc436*/
    if ( v35 != nullptr ) /*0x1067fc43e*/
    {
      v37 = v35; /*0x1067fc440*/
      RBX::RunService::smoothFps(this: v35); /*0x1067fc446*/
      *(float *)&v38 = v38; /*0x1067fc44b*/
      *(_DWORD *)(a1 + 76) = LODWORD(v38); /*0x1067fc44f*/
      RBX::RunService::smoothHeartbeatFps(this: v37); /*0x1067fc457*/
      v40 = v39; /*0x1067fc45c*/
    }
    else
    {
      *(_DWORD *)(a1 + 76) = 0; /*0x1067fc462*/
      v40 = 0.0; /*0x1067fc469*/
    }
    *(float *)(a1 + 80) = v40; /*0x1067fc46c*/
    if ( DFFlag::PingItemReportClientMemory == 1 ) /*0x1067fc47b*/
    {
      v41 = RBX::MemoryStats::usedMemoryBytes(this: v36); /*0x1067fc47d*/
      if ( v41 < 0 ) /*0x1067fc485*/
        v42 = (float)(int)(((unsigned __int64)v41 >> 1) | v41 & 1) /*0x1067fc4a5*/
            + (float)(int)(((unsigned __int64)v41 >> 1) | v41 & 1);
      else
        v42 = (float)(int)v41; /*0x1067fc48a*/
      *(float *)(a1 + 84) = v42 * 0.00000095367432; /*0x1067fc4b1*/
    }
    v43 = (RBX::ScriptContext *)RBX::ServiceProvider::find<RBX::ScriptContext>(a1: v15, a2: 0); /*0x1067fc4bb*/
    if ( v43 != nullptr ) /*0x1067fc4c3*/
      *(_DWORD *)(a1 + 96) = RBX::ScriptContext::getLuauSecurityFlags(this: v43); /*0x1067fc4cd*/
  }
  if ( DFFlag::DataPingTrace == 1 /*0x1067fc4ef*/
    && DFFlag::RbxTransportNetworkTracing == 1
    && RBX::Network::flagsSendsGoThroughConnection(this: v13) != 0 )
  {
    v44 = *(_QWORD *)(a2 + 280); /*0x1067fc4f1*/
    if ( v44 != 0 /*0x1067fc518*/
      && ((*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v44 + 56LL))(a1: v44) & 0x2000000000000LL) != 0
      && *(_DWORD *)(a2 + 276) == 1
      && *(_BYTE *)(a1 + 92) == 0 )
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1067fc524*/
        v45 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1067fc526*/
      else
        v45 = nullptr; /*0x1067fc52c*/
      TracerObject = RBX::Network::NetworkTracer::createTracerObject(this: v45); /*0x1067fc533*/
      v48 = v47; /*0x1067fc536*/
      TracerPeerId = RBX::NetworkBase::ConnectionInternal::getTracerPeerId(this: *(RBX::NetworkBase::ConnectionInternal **)(a2 + 280)); /*0x1067fc540*/
      RBX::Network::NetworkTracerObject::addCheckpoint(a1: v48, a2: TracerPeerId, a3: 0); /*0x1067fc54d*/
      *(_QWORD *)(a1 + 56) = TracerObject; /*0x1067fc552*/
    }
  }
}

// Address: 0x1067fc588 | Name: __ZN3RBX7Network10Replicator8PingItemC1EPS1_yjNS_8SendModeE
void __fastcall RBX::Network::Replicator::PingItem::PingItem(__int64 a1, __int64 a2, __int64 a3, int a4, char a5)
{
  RBX::Network::Replicator::PingItem::PingItem(a1, a2, a3, a4, a5); /*0x1067fc58d*/
}

// Address: 0x1067fc592 | Name: __ZN3RBX7Network10Replicator8PingItem5writeERNS0_13NetworkStreamE
char __fastcall RBX::Network::Replicator::PingItem::write(
        RBX::Network::Replicator::PingItem *this,
        RBX::Network::NetworkStream *a2)
{
  __int64 v4; // r14
  __int64 v5; // rax
  RBX::Network *v6; // rdi
  unsigned int v7; // r14d
  char v8; // r12
  char v9; // cl
  char PingWithClientMemoryFlag; // al
  char v11; // cl
  RakNet *v12; // rdi
  bool v13; // dl
  RBX::CoreNetworkSettings *v14; // rdi
  __int64 v15; // r12
  int v16; // eax
  unsigned int v18; // [rsp+8h] [rbp-38h]
  int v19; // [rsp+Ch] [rbp-34h]
  _QWORD v20[6]; // [rsp+10h] [rbp-30h] BYREF

  v19 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1067fc5b2*/
  RBX::Network::Item::writeItemType(a1: (__int64)this, a2, a3: 5u); /*0x1067fc5c0*/
  v4 = *(_QWORD *)(*((_QWORD *)this + 3) + 24LL); /*0x1067fc5c9*/
  v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ServerReplicator>(); /*0x1067fc5cd*/
  v7 = *(unsigned __int16 *)(v4 + 440) - *(unsigned __int16 *)(v5 + 440); /*0x1067fc5e1*/
  v18 = *(unsigned __int16 *)(v5 + 442); /*0x1067fc5eb*/
  if ( v7 <= v18 ) /*0x1067fc5f1*/
    v8 = 0; /*0x1067fc609*/
  else
    v8 = (4 * RBX::Network::Replicator::getPingWithLuauSecurityFlag(this: *((RBX::Network::Replicator **)this + 3))) | 2; /*0x1067fc603*/
  if ( DFFlag::RbxTransportNetworkTracing == 1 /*0x1067fc637*/
    && (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v6) != 0
    && ((*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(*((_QWORD *)this + 3) + 280LL) + 56LL))(a1: *(_QWORD *)(*((_QWORD *)this + 3) + 280LL))
      & 0x2000000000000LL) != 0 )
  {
    v9 = v8; /*0x1067fc643*/
    v8 += 8; /*0x1067fc647*/
    if ( *((_QWORD *)this + 7) == 0 ) /*0x1067fc64b*/
      v8 = v9; /*0x1067fc64b*/
  }
  if ( DFFlag::PingItemReportClientMemory == 1 ) /*0x1067fc659*/
  {
    PingWithClientMemoryFlag = RBX::Network::Replicator::getPingWithClientMemoryFlag(this: *((RBX::Network::Replicator **)this /*0x1067fc65f*/
                                                                                           + 3));
    v11 = v8; /*0x1067fc664*/
    v8 |= 0x10u; /*0x1067fc66c*/
    if ( PingWithClientMemoryFlag == 0 ) /*0x1067fc672*/
      v8 = v11; /*0x1067fc672*/
  }
  LOBYTE(v20[0]) = v8; /*0x1067fc67a*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v20, a3: 1u); /*0x1067fc689*/
  v20[0] = *((_QWORD *)this + 8); /*0x1067fc692*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v20, a3: 8u); /*0x1067fc6a1*/
  LODWORD(v20[0]) = RakNet::GetTimeMS(this: v12); /*0x1067fc6ab*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v20, a3: 4u); /*0x1067fc6bb*/
  if ( v7 > v18 ) /*0x1067fc6c4*/
  {
    LODWORD(v20[0]) = *((_DWORD *)this + 18); /*0x1067fc6cc*/
    RBX::Network::NetworkStream::writeBytes(this: a2, a2: v20, a3: 4u); /*0x1067fc6dd*/
    LODWORD(v20[0]) = *((_DWORD *)this + 19); /*0x1067fc6e8*/
    RBX::Network::NetworkStream::writeBytes(this: a2, a2: v20, a3: 4u); /*0x1067fc6f9*/
    LODWORD(v20[0]) = *((_DWORD *)this + 20); /*0x1067fc704*/
    RBX::Network::NetworkStream::writeBytes(this: a2, a2: v20, a3: 4u); /*0x1067fc716*/
  }
  LODWORD(v20[0]) = 0; /*0x1067fc71b*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v20, a3: 4u); /*0x1067fc72e*/
  LODWORD(v20[0]) = *((_DWORD *)this + 22); /*0x1067fc737*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v20, a3: 4u); /*0x1067fc746*/
  LOBYTE(v20[0]) = *((_BYTE *)this + 92); /*0x1067fc74f*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v20, a3: 1u); /*0x1067fc75f*/
  if ( (v8 & 4) != 0 ) /*0x1067fc768*/
  {
    LODWORD(v20[0]) = *((_DWORD *)this + 16) ^ *((_DWORD *)this + 24); /*0x1067fc776*/
    RBX::Network::NetworkStream::writeBytes(this: a2, a2: v20, a3: 4u); /*0x1067fc780*/
  }
  if ( (v8 & 0x10) != 0 ) /*0x1067fc789*/
  {
    LODWORD(v20[0]) = *((_DWORD *)this + 21); /*0x1067fc795*/
    RBX::Network::NetworkStream::writeBytes(this: a2, a2: v20, a3: 4u); /*0x1067fc7a1*/
  }
  if ( (v8 & 8) != 0 ) /*0x1067fc7aa*/
    RBX::Network::writeTracerFlag(this: a2, a2: (RBX::Network::NetworkStream *)(*((_QWORD *)this + 7) != 0), a3: v13); /*0x1067fc7ba*/
  if ( *(_BYTE *)(RBX::CoreNetworkSettings::singleton(this: v14) + 8) == 1 ) /*0x1067fc7c8*/
  {
    RBX::Network::ReplicatorStats::incrementPacketsSent(a1: *((_QWORD *)this + 3) + 1456LL, a2: 2); /*0x1067fc7dc*/
    v15 = *((_QWORD *)this + 3) + 1456LL; /*0x1067fc7e1*/
    v16 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1067fc7eb*/
    RBX::Network::ReplicatorStats::samplePacketsSent(a1: v15, a2: 2, a3: (unsigned int)(v16 - v19)); /*0x1067fc7fb*/
  }
  return 1; /*0x1067fc802*/
}

// Address: 0x1067fc812 | Name: __ZN3RBX7Network10Replicator8PingItem4readERS1_RNS0_13NetworkStreamE
RBX::Network::Replicator::PingItem *__fastcall RBX::Network::Replicator::PingItem::read(
        RBX::Network::Replicator::PingItem *this,
        RBX::Network::Replicator *a2,
        RBX::Network::NetworkStream *a3)
{
  __int64 v5; // rbx
  char Byte; // r13
  __int64 v7; // r15
  __int64 v8; // rax
  bool v9; // r15
  RakNet *v10; // rdi
  int v11; // xmm0_4
  int v12; // xmm0_4
  int v13; // xmm0_4
  unsigned __int8 v14; // al
  unsigned __int8 PingWithClientMemoryFlag; // al
  RBX::Network *v16; // rdi
  char v17; // cl
  int v18; // xmm0_4
  unsigned __int64 v19; // rcx
  unsigned __int8 TracerPeerId; // al
  int v23; // [rsp+14h] [rbp-2Ch]

  v5 = operator new(a1: 0x70u); /*0x1067fc837*/
  *(_QWORD *)(v5 + 8) = 0x100000005LL; /*0x1067fc844*/
  *(_DWORD *)(v5 + 16) = 0; /*0x1067fc84a*/
  *(_QWORD *)(v5 + 24) = 0; /*0x1067fc84d*/
  *(_QWORD *)v5 = off_10CAACF08; /*0x1067fc85c*/
  *(_DWORD *)(v5 + 100) = 0; /*0x1067fc85f*/
  *(_BYTE *)(v5 + 104) = 0; /*0x1067fc862*/
  *(_DWORD *)(v5 + 108) = 0; /*0x1067fc866*/
  *(_OWORD *)(v5 + 80) = 0; /*0x1067fc86c*/
  v23 = *((_DWORD *)a3 + 14); /*0x1067fc875*/
  Byte = RBX::Network::NetworkStream::readByte(this: a3); /*0x1067fc880*/
  v7 = *((_QWORD *)a2 + 3); /*0x1067fc887*/
  v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ServerReplicator>(); /*0x1067fc88b*/
  v9 = *(unsigned __int16 *)(v7 + 440) - (unsigned int)*(unsigned __int16 *)(v8 + 440) <= *(unsigned __int16 *)(v8 + 442); /*0x1067fc8b2*/
  *(_BYTE *)(v5 + 32) = Byte; /*0x1067fc8b6*/
  *(_QWORD *)(v5 + 40) = RBX::Network::NetworkStream::readUInt64(this: a3); /*0x1067fc8c2*/
  *(_DWORD *)(v5 + 48) = RBX::Network::NetworkStream::readUInt32(this: a3); /*0x1067fc8ce*/
  *(_DWORD *)(v5 + 52) = RakNet::GetTimeMS(this: v10); /*0x1067fc8d6*/
  if ( (Byte & 1) != 0 ) /*0x1067fc8dd*/
  {
    *(_DWORD *)(v5 + 56) = RBX::Network::NetworkStream::readUInt32(this: a3); /*0x1067fc8e7*/
    *(_DWORD *)(v5 + 60) = RBX::Network::NetworkStream::readUInt32(this: a3); /*0x1067fc8f2*/
    *(_DWORD *)(v5 + 64) = RBX::Network::NetworkStream::readUInt32(this: a3); /*0x1067fc8fd*/
    *(_DWORD *)(v5 + 68) = RBX::Network::NetworkStream::readInt32(this: a3); /*0x1067fc908*/
    *(_DWORD *)(v5 + 72) = RBX::Network::NetworkStream::readInt32(this: a3); /*0x1067fc913*/
    *(_DWORD *)(v5 + 76) = RBX::Network::NetworkStream::readInt32(this: a3); /*0x1067fc91e*/
  }
  if ( (Byte & 1) == 0 && v9 ) /*0x1067fc921*/
  {
    RBX::Network::NetworkStream::readFloat(this: a3); /*0x1067fc929*/
    *(_DWORD *)(v5 + 80) = v11; /*0x1067fc935*/
    RBX::Network::NetworkStream::readFloat(this: a3); /*0x1067fc93c*/
    *(_DWORD *)(v5 + 84) = v12; /*0x1067fc941*/
    RBX::Network::NetworkStream::readFloat(this: a3); /*0x1067fc949*/
    *(_DWORD *)(v5 + 88) = v13; /*0x1067fc94e*/
  }
  *(_DWORD *)(v5 + 96) = RBX::Network::NetworkStream::readUInt32(this: a3); /*0x1067fc95b*/
  *(_DWORD *)(v5 + 100) = RBX::Network::NetworkStream::readUInt32(this: a3); /*0x1067fc966*/
  v14 = RBX::Network::NetworkStream::readByte(this: a3); /*0x1067fc96c*/
  if ( v14 > 1u ) /*0x1067fc977*/
  {
    *(_QWORD *)this = 0; /*0x1067fc9e5*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(a1: v5); /*0x1067fc9f2*/
    return this; /*0x1067fc9f5*/
  }
  else
  {
    *(_BYTE *)(v5 + 104) = v14; /*0x1067fc979*/
    if ( (unsigned __int8)RBX::Network::Replicator::getPingWithLuauSecurityFlag(this: a2) != 0 /*0x1067fc98c*/
      && (*(_BYTE *)(v5 + 32) & 4) != 0 )
    {
      *(_DWORD *)(v5 + 108) = *(_DWORD *)(v5 + 40) ^ RBX::Network::NetworkStream::readUInt32(this: a3); /*0x1067fc999*/
    }
    PingWithClientMemoryFlag = RBX::Network::Replicator::getPingWithClientMemoryFlag(this: a2); /*0x1067fc99f*/
    v17 = *(_BYTE *)(v5 + 32); /*0x1067fc9a4*/
    if ( (((v17 & 0x10) != 0) & PingWithClientMemoryFlag) == 1 ) /*0x1067fc9b3*/
    {
      RBX::Network::NetworkStream::readFloat(this: a3); /*0x1067fc9b8*/
      *(_DWORD *)(v5 + 92) = v18; /*0x1067fc9bd*/
      v17 = *(_BYTE *)(v5 + 32); /*0x1067fc9c2*/
    }
    if ( (v17 & 8) != 0 ) /*0x1067fc9c8*/
    {
      if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v16) != 0 ) /*0x1067fc9d1*/
        TracerPeerId = RBX::NetworkBase::ConnectionInternal::getTracerPeerId(this: *((RBX::NetworkBase::ConnectionInternal **)a2 /*0x1067fc9da*/
                                                                                   + 35));
      else
        TracerPeerId = 0; /*0x1067fc9fa*/
      *(_QWORD *)(v5 + 24) = RBX::Network::readTracerFromStream( /*0x1067fca0a*/
                               this: a3,
                               a2: (RBX::Network::NetworkStream *)TracerPeerId,
                               a3: *(_DWORD *)(v5 + 52),
                               a4: v19);
    }
    if ( *(_BYTE *)(RBX::CoreNetworkSettings::singleton(this: v16) + 8) == 1 ) /*0x1067fca17*/
    {
      RBX::Network::ReplicatorStats::incrementPacketsReceived(a1: (char *)a2 + 1456, a2: 2); /*0x1067fca28*/
      RBX::Network::ReplicatorStats::samplePacketsReceived( /*0x1067fca3d*/
        a1: (char *)a2 + 1456,
        a2: 2,
        a3: (unsigned int)(*((_DWORD *)a3 + 14) - v23));
    }
    *(_QWORD *)this = v5; /*0x1067fca46*/
    return this; /*0x1067fca42*/
  }
}

// Address: 0x1067fca74 | Name: __ZNK3RBX7Network10Replicator8PingItem11getSendModeEv
__int64 __fastcall RBX::Network::Replicator::PingItem::getSendMode(RBX::Network::Replicator::PingItem *this)
{
  return *((unsigned __int8 *)this + 92); /*0x1067fca7c*/
}

// Address: 0x1067fca8e | Name: __ZN3RBX7Network10Replicator8PingItemD1Ev
void __fastcall RBX::Network::Replicator::PingItem::~PingItem(RBX::Network::Replicator::PingItem *this)
{
  ; /*0x1067fca8e*/
}

// Address: 0x1067fca94 | Name: __ZN3RBX7Network10Replicator8PingItemD0Ev
void __fastcall RBX::Network::Replicator::PingItem::~PingItem(RBX::Network::Replicator::PingItem *this)
{
  _QWORD *v1; // rcx

  v1 = **((_QWORD ***)this - 1); /*0x1067fcaa0*/
  *((_QWORD *)this - 1) = *v1; /*0x1067fcaa6*/
  *v1 = (char *)this - 8; /*0x1067fcaaa*/
}

// Address: 0x1067fcab0 | Name: __ZNK3RBX7Network10Replicator8PingItem7getTypeEv
__int64 __fastcall RBX::Network::Replicator::PingItem::getType(RBX::Network::Replicator::PingItem *this)
{
  return 5; /*0x1067fcab9*/
}

// END PingItem part 1/1, 8 functions
