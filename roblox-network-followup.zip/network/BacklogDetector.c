// BacklogDetector -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 6 functions


// Address: 0x106d75d82 | Name: __ZN3RBX7Network15BacklogDetectorC2Ev
__int64 __fastcall RBX::Network::BacklogDetector::BacklogDetector(RBX::Network::BacklogDetector *this)
{
  RakNet *v2; // rdi
  __int64 result; // rax

  *((_OWORD *)this + 3) = 0; /*0x106d75d8f*/
  *((_OWORD *)this + 2) = 0; /*0x106d75d93*/
  *((_OWORD *)this + 1) = 0; /*0x106d75d97*/
  *(_OWORD *)this = 0; /*0x106d75d9b*/
  *((double *)this + 8) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: this); /*0x106d75da3*/
  *((_BYTE *)this + 72) = 1; /*0x106d75da8*/
  result = (unsigned int)RakNet::GetTimeMS(this: v2); /*0x106d75db1*/
  *((_QWORD *)this + 10) = (unsigned int)result; /*0x106d75db3*/
  return result; /*0x106d75db7*/
}

// Address: 0x106d75dd4 | Name: __ZN3RBX7Network15BacklogDetectorC1Ev
__int64 __fastcall RBX::Network::BacklogDetector::BacklogDetector(RBX::Network::BacklogDetector *this)
{
  return RBX::Network::BacklogDetector::BacklogDetector(this); /*0x106d75dd8*/
}

// Address: 0x106d75dde | Name: __ZN3RBX7Network15BacklogDetector9addSampleEiy
void __fastcall RBX::Network::BacklogDetector::addSample(__m128i *this, int a2, __int64 a3)
{
  unsigned __int64 v6; // rcx
  unsigned __int64 v7; // rax
  __int64 v8; // rdx
  double v9; // xmm0_8
  __m128i v10; // xmm0
  unsigned __int16 epi16; // ax

  if ( a2 >= 0 && a3 - *((_QWORD *)this + 10) >= (unsigned __int64)DFInt::BacklogDetectorMinSampleGapMs ) /*0x106d75e0c*/
  {
    this->i32[1] += a2; /*0x106d75e15*/
    std::deque<unsigned int>::push_back(a1: &this->u64[1]); /*0x106d75e27*/
    v6 = *((_QWORD *)this + 6); /*0x106d75e2c*/
    if ( v6 > DFInt::BacklogDetectorWindowSize ) /*0x106d75e3a*/
    {
      v7 = *((_QWORD *)this + 5); /*0x106d75e40*/
      v8 = *(_QWORD *)(*((_QWORD *)this + 2) + 8 * (v7 >> 10)); /*0x106d75e4b*/
      this->i32[1] -= *(_DWORD *)(v8 + 4 * (v7 & 0x3FF)); /*0x106d75e5a*/
      if ( *(_DWORD *)(v8 + 4 * (v7 & 0x3FF)) >= (unsigned int)DFInt::BacklogDetectorLatencyThresholdMs ) /*0x106d75e67*/
        --this->i16[1]; /*0x106d75e69*/
      *((_QWORD *)this + 6) = v6 - 1; /*0x106d75e71*/
      *((_QWORD *)this + 5) = v7 + 1; /*0x106d75e78*/
      std::deque<unsigned int>::__maybe_remove_front_spare[abi:ne200100](a1: &this->u64[1], a2: 1); /*0x106d75e84*/
      v6 = *((_QWORD *)this + 6); /*0x106d75e89*/
    }
    v9 = (double)(int)(this->u32[1] / v6); /*0x106d75e96*/
    *((double *)this + 7) = v9; /*0x106d75e9b*/
    if ( v9 >= (double)DFInt::BacklogDetectorMovingAvgThresholdMs ) /*0x106d75ead*/
      RBX::Network::BacklogDetector::report((RBX::Network::BacklogDetector *)this); /*0x106d75eb2*/
    if ( DFInt::BacklogDetectorLatencyThresholdMs <= a2 ) /*0x106d75ebe*/
    {
      v10 = _mm_sub_epi16(_mm_loadl_epi64(this), (__m128i)-1LL); /*0x106d75ed1*/
      this->i32[0] = _mm_cvtsi128_si32(v10); /*0x106d75ed5*/
      if ( DFInt::BacklogDetectorSamplesThreshold <= _mm_extract_epi16(v10, 0) ) /*0x106d75ee5*/
      {
        RBX::Network::BacklogDetector::report((RBX::Network::BacklogDetector *)this); /*0x106d75ef1*/
        epi16 = this->u16[1]; /*0x106d75ef6*/
      }
      else
      {
        epi16 = _mm_extract_epi16(v10, 1); /*0x106d75ee7*/
      }
      if ( DFInt::BacklogDetectorSamplesInWindowThreshold <= epi16 ) /*0x106d75f04*/
        RBX::Network::BacklogDetector::report((RBX::Network::BacklogDetector *)this); /*0x106d75f09*/
    }
    else
    {
      this->i16[0] = 0; /*0x106d75ec0*/
    }
    *((_QWORD *)this + 10) = a3; /*0x106d75f0e*/
  }
}

// Address: 0x106d75f20 | Name: __ZN3RBX7Network15BacklogDetector6reportEv
void __fastcall RBX::Network::BacklogDetector::report(RBX::Network::BacklogDetector *this)
{
  __int64 v2; // rdi
  _BYTE v3[616]; // [rsp+8h] [rbp-268h] BYREF

  if ( RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: this) - *((double *)this + 8) >= (double)DFInt::BacklogDetectorReportThrottleSeconds /*0x106d75f4d*/
    || *((_BYTE *)this + 72) == 1 )
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)3,std::enable_if<true,void>>( /*0x106d75f60*/
      a1: v3,
      a2: &RBX::Telemetry::kReplicatorBacklog);
    RBX::Network::BacklogDetector::populateReport(this, a2: (RBX::Telemetry::RobloxTelemetryEvent *)v3); /*0x106d75f6b*/
    *((_BYTE *)this + 72) = 0; /*0x106d75f70*/
    *((double *)this + 8) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v2); /*0x106d75f79*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v3); /*0x106d75f8c*/
  }
}

// Address: 0x106d75fbc | Name: __ZN3RBX7Network15BacklogDetector14populateReportERNS_9Telemetry20RobloxTelemetryEventE
__int64 __fastcall RBX::Network::BacklogDetector::populateReport(
        RBX::Network::BacklogDetector *this,
        RBX::Telemetry::RobloxTelemetryEvent *a2)
{
  char *v4; // r14
  char *v5; // rcx
  __int64 v6; // r8
  void *v7; // rsi
  unsigned __int8 v9; // [rsp+8h] [rbp-38h] BYREF
  char v10; // [rsp+9h] [rbp-37h] BYREF
  __int64 v11; // [rsp+10h] [rbp-30h]
  void *v12; // [rsp+18h] [rbp-28h]

  v4 = (char *)a2 + 72; /*0x106d75fd1*/
  (*(void (__fastcall **)(char *, const char *, __int64, _QWORD, __int64))(*((_QWORD *)a2 + 9) + 8LL))( /*0x106d75ff1*/
    a1: (char *)a2 + 72,
    a2: "numOver",
    a3: 7,
    a4: *(unsigned __int16 *)this,
    a5: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, _QWORD, __int64))(*((_QWORD *)a2 + 9) + 8LL))( /*0x106d76012*/
    a1: v4,
    a2: "numNonConsecutiveOver",
    a3: 21,
    a4: *((unsigned __int16 *)this + 1),
    a5: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x106d76033*/
    a1: v4,
    a2: "average",
    a3: 7,
    a4: 1,
    a5: *((double *)this + 7));
  RBX::Network::BacklogDetector::windowSamples(this: (RBX::Network::BacklogDetector *)&v9); /*0x106d76040*/
  if ( (v9 & 1) != 0 ) /*0x106d7604e*/
  {
    v5 = (char *)v12; /*0x106d76050*/
    v6 = v11; /*0x106d76054*/
  }
  else
  {
    v6 = v9 >> 1; /*0x106d7605a*/
    v5 = &v10; /*0x106d7605d*/
  }
  (*(void (__fastcall **)(char *, const char *, __int64, char *, __int64, __int64))(*((_QWORD *)a2 + 9) + 24LL))( /*0x106d7607a*/
    a1: v4,
    a2: "windowSamples",
    a3: 13,
    a4: v5,
    a5: v6,
    a6: 1);
  if ( (v9 & 1) != 0 ) /*0x106d76081*/
    operator delete(a1: (RBX::Memory *)v12, a2: v7); /*0x106d76087*/
  (*(void (__fastcall **)(char *, const char *, __int64, _QWORD, __int64))(*((_QWORD *)a2 + 9) + 8LL))( /*0x106d760a9*/
    a1: v4,
    a2: "numWindowSamples",
    a3: 16,
    a4: *((_QWORD *)this + 6),
    a5: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, _QWORD, __int64))(*((_QWORD *)a2 + 9) + 8LL))( /*0x106d760cc*/
    a1: v4,
    a2: "samplesThreshold",
    a3: 16,
    a4: DFInt::BacklogDetectorSamplesThreshold,
    a5: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, _QWORD, __int64))(*((_QWORD *)a2 + 9) + 8LL))( /*0x106d760ef*/
    a1: v4,
    a2: "samplesInWindowThreshold",
    a3: 24,
    a4: DFInt::BacklogDetectorSamplesInWindowThreshold,
    a5: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, _QWORD, __int64))(*((_QWORD *)a2 + 9) + 8LL))( /*0x106d76112*/
    a1: v4,
    a2: "samplesThresholdMs",
    a3: 18,
    a4: DFInt::BacklogDetectorLatencyThresholdMs,
    a5: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, _QWORD, __int64))(*((_QWORD *)a2 + 9) + 8LL))( /*0x106d76135*/
    a1: v4,
    a2: "windowSize",
    a3: 10,
    a4: DFInt::BacklogDetectorWindowSize,
    a5: 1);
  (*(void (__fastcall **)(char *, const char *, __int64, _QWORD, __int64))(*((_QWORD *)a2 + 9) + 8LL))( /*0x106d76158*/
    a1: v4,
    a2: "averageThresholdMs",
    a3: 18,
    a4: DFInt::BacklogDetectorMovingAvgThresholdMs,
    a5: 1);
  (*(void (__fastcall **)(char *))(*((_QWORD *)a2 + 9) + 248LL))(a1: v4); /*0x106d76162*/
  (*(void (__fastcall **)(char *))(*((_QWORD *)a2 + 9) + 240LL))(a1: v4); /*0x106d7616f*/
  return (*(__int64 (__fastcall **)(RBX::Telemetry::RobloxTelemetryEvent *))(*(_QWORD *)a2 + 48LL))(a1: a2); /*0x106d7617e*/
}

// Address: 0x106d761a6 | Name: __ZN3RBX7Network15BacklogDetector13windowSamplesEv
RBX::Network::BacklogDetector *__fastcall RBX::Network::BacklogDetector::windowSamples(
        RBX::Network::BacklogDetector *this,
        _QWORD *a2)
{
  unsigned __int64 v4; // r13
  void *v5; // rsi
  __int64 (__fastcall **v7)(); // [rsp+0h] [rbp-130h] BYREF
  __int64 (__fastcall **v8)(); // [rsp+8h] [rbp-128h] BYREF
  _BYTE v9[72]; // [rsp+10h] [rbp-120h] BYREF
  void *v10; // [rsp+58h] [rbp-D8h]
  __int64 (__fastcall **v11)(); // [rsp+70h] [rbp-C0h] BYREF

  std::ostringstream::basic_ostringstream[abi:ne200100](a1: &v7); /*0x106d761c7*/
  if ( a2[6] != 0 ) /*0x106d761d1*/
  {
    v4 = 0; /*0x106d761d3*/
    do /*0x106d76226*/
    {
      if ( v4 != 0 ) /*0x106d761e7*/
        std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &v7, a2: ",", a3: 1); /*0x106d761f4*/
      std::ostream::operator<<( /*0x106d7621a*/
        a1: &v7,
        a2: *(unsigned int *)(*(_QWORD *)(a2[2] + 8 * ((v4 + a2[5]) >> 10))
                        + 4LL * (((_DWORD)v4 + *((_DWORD *)a2 + 10)) & 0x3FF)));
      ++v4; /*0x106d7621f*/
    }
    while ( a2[6] > v4 ); /*0x106d76226*/
  }
  std::stringbuf::str(a1: this, a2: &v8); /*0x106d76232*/
  v7 = &off_10C449768; /*0x106d76249*/
  v11 = off_10C449790; /*0x106d76251*/
  v8 = &off_10C799250; /*0x106d7625f*/
  if ( (v9[56] & 1) != 0 ) /*0x106d76268*/
    operator delete(a1: (RBX::Memory *)v10, a2: v5); /*0x106d76271*/
  v8 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x106d76288*/
  std::locale::~locale(this: (std::locale *)v9); /*0x106d7628c*/
  std::ostream::~ostream(a1: &v7, a2: off_10C4497A8); /*0x106d762a3*/
  std::ios::~ios(a1: &v11); /*0x106d762ab*/
  return this; /*0x106d762b3*/
}

// END BacklogDetector part 1/1, 6 functions
