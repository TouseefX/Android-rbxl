// DateTimeBridge -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 12 functions


// Address: 0x10464c3fa | Name: __ZN3RBX3Lua14DateTimeBridge3nowEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::now(RBX::DateTime *a1)
{
  __int64 v2; // r14
  __int64 v3; // rdx
  __int64 v4; // r15
  __int64 *v5; // rax

  v2 = RBX::DateTime::now(this: a1); /*0x10464c40c*/
  v4 = v3; /*0x10464c40f*/
  v5 = (__int64 *)RBX::Lua::allocUserData( /*0x10464c427*/
                    a1,
                    a2: RBX::Lua::Bridge<RBX::DateTime>::className[0],
                    a3: 16,
                    a4: (unsigned int)RBX::Lua::Bridge<RBX::DateTime>::typeId);
  *v5 = v2; /*0x10464c42c*/
  v5[1] = v4; /*0x10464c42f*/
  return 1; /*0x10464c43c*/
}

// Address: 0x10464c444 | Name: __ZN3RBX3Lua14DateTimeBridge17fromUnixTimestampEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::fromUnixTimestamp(__int64 a1)
{
  __int64 v2; // rsi
  float v3; // xmm0_4
  RBX::DateTime *v4; // rdi
  __int64 v5; // r14
  __int64 v6; // rdx
  __int64 v7; // r15
  __int64 *v8; // rax

  if ( (int)lua_gettop(a1) <= 0 ) /*0x10464c458*/
    v4 = nullptr; /*0x10464c46e*/
  else
    v4 = (RBX::DateTime *)(unsigned int)(int)luaL_checknumber(a1, a2: 1, a3: v3); /*0x10464c467*/
  v5 = RBX::DateTime::fromUnixTimestamp(this: v4, a2: v2); /*0x10464c475*/
  v7 = v6; /*0x10464c478*/
  v8 = (__int64 *)RBX::Lua::allocUserData( /*0x10464c490*/
                    a1,
                    a2: RBX::Lua::Bridge<RBX::DateTime>::className[0],
                    a3: 16,
                    a4: (unsigned int)RBX::Lua::Bridge<RBX::DateTime>::typeId);
  *v8 = v5; /*0x10464c495*/
  v8[1] = v7; /*0x10464c498*/
  return 1; /*0x10464c4a5*/
}

// Address: 0x10464c4ac | Name: __ZN3RBX3Lua14DateTimeBridge23fromUnixTimestampMillisEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::fromUnixTimestampMillis(__int64 a1)
{
  __int64 v2; // rsi
  float v3; // xmm0_4
  RBX::DateTime *v4; // rdi
  __int64 v5; // r14
  __int64 v6; // rdx
  __int64 v7; // r15
  __int64 *v8; // rax

  if ( (int)lua_gettop(a1) <= 0 ) /*0x10464c4c0*/
    v4 = nullptr; /*0x10464c4d6*/
  else
    v4 = (RBX::DateTime *)(unsigned int)(int)luaL_checknumber(a1, a2: 1, a3: v3); /*0x10464c4cf*/
  v5 = RBX::DateTime::fromUnixTimestampMillis(this: v4, a2: v2); /*0x10464c4dd*/
  v7 = v6; /*0x10464c4e0*/
  v8 = (__int64 *)RBX::Lua::allocUserData( /*0x10464c4f8*/
                    a1,
                    a2: RBX::Lua::Bridge<RBX::DateTime>::className[0],
                    a3: 16,
                    a4: (unsigned int)RBX::Lua::Bridge<RBX::DateTime>::typeId);
  *v8 = v5; /*0x10464c4fd*/
  v8[1] = v7; /*0x10464c500*/
  return 1; /*0x10464c50d*/
}

// Address: 0x10464c514 | Name: __ZN3RBX3Lua14DateTimeBridge17fromUniversalTimeEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::fromUniversalTime(__int64 a1)
{
  int v2; // eax
  __int64 v3; // r15
  int v4; // r12d
  int v5; // eax
  int v6; // edi
  int v7; // r14d
  int v8; // ebx
  int v9; // edx
  int v10; // esi
  int v11; // ebx
  int v12; // r14d
  int v13; // edi
  int v14; // r8d
  int v15; // r9d
  int v16; // eax
  __int64 v17; // r14
  __int64 v18; // rdx
  __int64 v19; // r15
  __int64 *v20; // rax
  int v22; // [rsp+8h] [rbp-38h]
  int v23; // [rsp+10h] [rbp-30h]
  int v24; // [rsp+14h] [rbp-2Ch]
  int v25; // [rsp+14h] [rbp-2Ch]

  v2 = lua_gettop(a1); /*0x10464c528*/
  v3 = 8; /*0x10464c530*/
  if ( v2 < 8 ) /*0x10464c536*/
    v3 = (unsigned int)v2; /*0x10464c536*/
  v4 = 1; /*0x10464c544*/
  v5 = 0; /*0x10464c54a*/
  v6 = 0; /*0x10464c55a*/
  v24 = 0; /*0x10464c55c*/
  v7 = 0; /*0x10464c563*/
  v8 = 0; /*0x10464c566*/
  v9 = 0; /*0x10464c568*/
  v10 = 0; /*0x10464c56a*/
  switch ( v3 ) /*0x10464c56c*/
  {
    case 0LL: /*0x10464c56c*/
      v13 = 1970; /*0x10464c671*/
      v12 = 1; /*0x10464c676*/
      v14 = v3; /*0x10464c67c*/
      v15 = v3; /*0x10464c67f*/
      v16 = v3; /*0x10464c682*/
      goto LABEL_11; /*0x10464c685*/
    case 1LL: /*0x10464c56c*/
      v25 = 0; /*0x10464c68a*/
      v4 = v3; /*0x10464c691*/
      v8 = 0; /*0x10464c694*/
      v23 = 0; /*0x10464c696*/
      v22 = 0; /*0x10464c69d*/
      goto LABEL_10; /*0x10464c6a5*/
    case 2LL: /*0x10464c56c*/
      v25 = 0; /*0x10464c654*/
      v8 = 0; /*0x10464c65b*/
      v23 = 0; /*0x10464c65d*/
      v22 = 0; /*0x10464c664*/
      goto LABEL_9; /*0x10464c66c*/
    case 3LL: /*0x10464c56c*/
      goto LABEL_8;
    case 4LL: /*0x10464c56c*/
      goto LABEL_7;
    case 5LL: /*0x10464c56c*/
      goto LABEL_6;
    case 6LL: /*0x10464c56c*/
      goto LABEL_5;
    case 7LL: /*0x10464c56c*/
    case 8LL: /*0x10464c56c*/
      v5 = luaL_checkinteger(a1, a2: 7); /*0x10464c576*/
LABEL_5:
      v11 = v5; /*0x10464c57b*/
      v5 = luaL_checkinteger(a1, a2: 6); /*0x10464c585*/
      v6 = v11; /*0x10464c58a*/
LABEL_6:
      v24 = v5; /*0x10464c58c*/
      v7 = v6; /*0x10464c58f*/
      v5 = luaL_checkinteger(a1, a2: 5); /*0x10464c59a*/
LABEL_7:
      v8 = v5; /*0x10464c59f*/
      v5 = luaL_checkinteger(a1, a2: 4); /*0x10464c5a9*/
      v9 = v24; /*0x10464c5ae*/
      v10 = v7; /*0x10464c5b1*/
LABEL_8:
      v22 = v10; /*0x10464c5b4*/
      v23 = v9; /*0x10464c5b8*/
      v25 = v5; /*0x10464c5bb*/
      v4 = luaL_checkinteger(a1, a2: 3); /*0x10464c5cb*/
LABEL_9:
      LODWORD(v3) = luaL_checkinteger(a1, a2: 2); /*0x10464c5ce*/
LABEL_10:
      v12 = v4; /*0x10464c5de*/
      v13 = luaL_checkinteger(a1, a2: 1); /*0x10464c5ee*/
      v4 = v3; /*0x10464c5f0*/
      LODWORD(v3) = v25; /*0x10464c5f6*/
      v14 = v8; /*0x10464c5f9*/
      v15 = v23; /*0x10464c5fc*/
      v16 = v22; /*0x10464c600*/
LABEL_11:
      v17 = RBX::DateTime::fromComponents(a1: v13, a2: v4, a3: v12, a4: v3, a5: v14, a6: v15, a7: v16, a8: 0); /*0x10464c604*/
      v19 = v18; /*0x10464c61c*/
      v20 = (__int64 *)RBX::Lua::allocUserData( /*0x10464c634*/
                         a1,
                         a2: RBX::Lua::Bridge<RBX::DateTime>::className[0],
                         a3: 16,
                         a4: (unsigned int)RBX::Lua::Bridge<RBX::DateTime>::typeId);
      *v20 = v17; /*0x10464c639*/
      v20[1] = v19; /*0x10464c63c*/
      break; /*0x10464c63c*/
    default:
      return 1;
  }
  return 1; /*0x10464c645*/
}

// Address: 0x10464c6d0 | Name: __ZN3RBX3Lua14DateTimeBridge13fromLocalTimeEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::fromLocalTime(__int64 a1)
{
  int v2; // eax
  __int64 v3; // r15
  int v4; // r12d
  int v5; // eax
  int v6; // edi
  int v7; // r14d
  int v8; // ebx
  int v9; // edx
  int v10; // esi
  int v11; // ebx
  int v12; // r14d
  int v13; // edi
  int v14; // r8d
  int v15; // r9d
  int v16; // eax
  __int64 v17; // r14
  __int64 v18; // rdx
  __int64 v19; // r15
  __int64 *v20; // rax
  int v22; // [rsp+8h] [rbp-38h]
  int v23; // [rsp+10h] [rbp-30h]
  int v24; // [rsp+14h] [rbp-2Ch]
  int v25; // [rsp+14h] [rbp-2Ch]

  v2 = lua_gettop(a1); /*0x10464c6e4*/
  v3 = 8; /*0x10464c6ec*/
  if ( v2 < 8 ) /*0x10464c6f2*/
    v3 = (unsigned int)v2; /*0x10464c6f2*/
  v4 = 1; /*0x10464c700*/
  v5 = 0; /*0x10464c706*/
  v6 = 0; /*0x10464c716*/
  v24 = 0; /*0x10464c718*/
  v7 = 0; /*0x10464c71f*/
  v8 = 0; /*0x10464c722*/
  v9 = 0; /*0x10464c724*/
  v10 = 0; /*0x10464c726*/
  switch ( v3 ) /*0x10464c728*/
  {
    case 0LL: /*0x10464c728*/
      v13 = 1970; /*0x10464c82d*/
      v12 = 1; /*0x10464c832*/
      v14 = v3; /*0x10464c838*/
      v15 = v3; /*0x10464c83b*/
      v16 = v3; /*0x10464c83e*/
      goto LABEL_11; /*0x10464c841*/
    case 1LL: /*0x10464c728*/
      v25 = 0; /*0x10464c846*/
      v4 = v3; /*0x10464c84d*/
      v8 = 0; /*0x10464c850*/
      v23 = 0; /*0x10464c852*/
      v22 = 0; /*0x10464c859*/
      goto LABEL_10; /*0x10464c861*/
    case 2LL: /*0x10464c728*/
      v25 = 0; /*0x10464c810*/
      v8 = 0; /*0x10464c817*/
      v23 = 0; /*0x10464c819*/
      v22 = 0; /*0x10464c820*/
      goto LABEL_9; /*0x10464c828*/
    case 3LL: /*0x10464c728*/
      goto LABEL_8;
    case 4LL: /*0x10464c728*/
      goto LABEL_7;
    case 5LL: /*0x10464c728*/
      goto LABEL_6;
    case 6LL: /*0x10464c728*/
      goto LABEL_5;
    case 7LL: /*0x10464c728*/
    case 8LL: /*0x10464c728*/
      v5 = luaL_checkinteger(a1, a2: 7); /*0x10464c732*/
LABEL_5:
      v11 = v5; /*0x10464c737*/
      v5 = luaL_checkinteger(a1, a2: 6); /*0x10464c741*/
      v6 = v11; /*0x10464c746*/
LABEL_6:
      v24 = v5; /*0x10464c748*/
      v7 = v6; /*0x10464c74b*/
      v5 = luaL_checkinteger(a1, a2: 5); /*0x10464c756*/
LABEL_7:
      v8 = v5; /*0x10464c75b*/
      v5 = luaL_checkinteger(a1, a2: 4); /*0x10464c765*/
      v9 = v24; /*0x10464c76a*/
      v10 = v7; /*0x10464c76d*/
LABEL_8:
      v22 = v10; /*0x10464c770*/
      v23 = v9; /*0x10464c774*/
      v25 = v5; /*0x10464c777*/
      v4 = luaL_checkinteger(a1, a2: 3); /*0x10464c787*/
LABEL_9:
      LODWORD(v3) = luaL_checkinteger(a1, a2: 2); /*0x10464c78a*/
LABEL_10:
      v12 = v4; /*0x10464c79a*/
      v13 = luaL_checkinteger(a1, a2: 1); /*0x10464c7aa*/
      v4 = v3; /*0x10464c7ac*/
      LODWORD(v3) = v25; /*0x10464c7b2*/
      v14 = v8; /*0x10464c7b5*/
      v15 = v23; /*0x10464c7b8*/
      v16 = v22; /*0x10464c7bc*/
LABEL_11:
      v17 = RBX::DateTime::fromComponents(a1: v13, a2: v4, a3: v12, a4: v3, a5: v14, a6: v15, a7: v16, a8: 1); /*0x10464c7c0*/
      v19 = v18; /*0x10464c7d8*/
      v20 = (__int64 *)RBX::Lua::allocUserData( /*0x10464c7f0*/
                         a1,
                         a2: RBX::Lua::Bridge<RBX::DateTime>::className[0],
                         a3: 16,
                         a4: (unsigned int)RBX::Lua::Bridge<RBX::DateTime>::typeId);
      *v20 = v17; /*0x10464c7f5*/
      v20[1] = v19; /*0x10464c7f8*/
      break; /*0x10464c7f8*/
    default:
      return 1;
  }
  return 1; /*0x10464c801*/
}

// Address: 0x10464c88c | Name: __ZN3RBX3Lua14DateTimeBridge11fromIsoDateEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::fromIsoDate(__int64 a1)
{
  int v2; // r14d
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // rax
  __int64 v6; // r14
  __int64 v7; // rdx
  __int64 v8; // r15
  __int64 *v9; // rax
  _BYTE v11[16]; // [rsp+0h] [rbp-30h] BYREF
  void *v12; // [rsp+10h] [rbp-20h]

  v2 = lua_gettop(a1); /*0x10464c8a1*/
  std::string::basic_string[abi:ne200100]<0>(a1: v11, a2: "", a3: v3, a4: v4); /*0x10464c8af*/
  if ( v2 > 0 ) /*0x10464c8b7*/
  {
    v5 = luaL_checklstring(a1, a2: 1, a3: 0); /*0x10464c8c3*/
    std::string::assign(a1: v11, a2: v5); /*0x10464c8cf*/
  }
  v6 = RBX::DateTime::fromIsoDate(a1: v11); /*0x10464c8dd*/
  v8 = v7; /*0x10464c8e0*/
  v9 = (__int64 *)RBX::Lua::allocUserData( /*0x10464c8f8*/
                    a1,
                    a2: RBX::Lua::Bridge<RBX::DateTime>::className[0],
                    a3: 16,
                    a4: (unsigned int)RBX::Lua::Bridge<RBX::DateTime>::typeId);
  *v9 = v6; /*0x10464c8fd*/
  v9[1] = v8; /*0x10464c900*/
  if ( (v11[0] & 1) != 0 ) /*0x10464c908*/
    operator delete(a1: v12); /*0x10464c90e*/
  return 1; /*0x10464c918*/
}

// Address: 0x10464cabe | Name: __ZN3RBX3Lua14DateTimeBridge19formatUniversalTimeEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::formatUniversalTime(__int64 a1)
{
  __int64 Object; // r14
  __int64 v3; // r15
  __int64 v4; // r12
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // rdx
  __int64 v8; // rcx
  _BYTE v10[16]; // [rsp+8h] [rbp-68h] BYREF
  void *v11; // [rsp+18h] [rbp-58h]
  _BYTE v12[16]; // [rsp+20h] [rbp-50h] BYREF
  void *v13; // [rsp+30h] [rbp-40h]
  _BYTE v14[16]; // [rsp+38h] [rbp-38h] BYREF
  void *v15; // [rsp+48h] [rbp-28h]

  Object = RBX::Lua::Bridge<RBX::DateTime>::getObject(a1, a2: 1); /*0x10464cada*/
  v3 = luaL_checklstring(a1, a2: 2, a3: 0); /*0x10464caec*/
  v4 = luaL_checklstring(a1, a2: 3, a3: 0); /*0x10464cafe*/
  std::string::basic_string[abi:ne200100]<0>(a1: v12, a2: v3, a3: v5, a4: v6); /*0x10464cb08*/
  std::string::basic_string[abi:ne200100]<0>(a1: v14, a2: v4, a3: v7, a4: v8); /*0x10464cb14*/
  RBX::formatDateTime(a1: v10, a2: Object, a3: v12, a4: v14, a5: 0); /*0x10464cb2b*/
  RBX::Lua::lua_pushstring(a1, a2: v10); /*0x10464cb37*/
  if ( (v10[0] & 1) != 0 ) /*0x10464cb40*/
    operator delete(a1: v11); /*0x10464cb46*/
  if ( (v14[0] & 1) != 0 ) /*0x10464cb4f*/
    operator delete(a1: v15); /*0x10464cb55*/
  if ( (v12[0] & 1) != 0 ) /*0x10464cb5e*/
    operator delete(a1: v13); /*0x10464cb64*/
  return 1; /*0x10464cb6e*/
}

// Address: 0x10464cbbe | Name: __ZN3RBX3Lua14DateTimeBridge15formatLocalTimeEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::formatLocalTime(__int64 a1)
{
  __int64 Object; // r14
  __int64 v3; // r15
  __int64 v4; // r12
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // rdx
  __int64 v8; // rcx
  _BYTE v10[16]; // [rsp+8h] [rbp-68h] BYREF
  void *v11; // [rsp+18h] [rbp-58h]
  _BYTE v12[16]; // [rsp+20h] [rbp-50h] BYREF
  void *v13; // [rsp+30h] [rbp-40h]
  _BYTE v14[16]; // [rsp+38h] [rbp-38h] BYREF
  void *v15; // [rsp+48h] [rbp-28h]

  Object = RBX::Lua::Bridge<RBX::DateTime>::getObject(a1, a2: 1); /*0x10464cbda*/
  v3 = luaL_checklstring(a1, a2: 2, a3: 0); /*0x10464cbec*/
  v4 = luaL_checklstring(a1, a2: 3, a3: 0); /*0x10464cbfe*/
  std::string::basic_string[abi:ne200100]<0>(a1: v12, a2: v3, a3: v5, a4: v6); /*0x10464cc08*/
  std::string::basic_string[abi:ne200100]<0>(a1: v14, a2: v4, a3: v7, a4: v8); /*0x10464cc14*/
  RBX::formatDateTime(a1: v10, a2: Object, a3: v12, a4: v14, a5: 1); /*0x10464cc2e*/
  RBX::Lua::lua_pushstring(a1, a2: v10); /*0x10464cc3a*/
  if ( (v10[0] & 1) != 0 ) /*0x10464cc43*/
    operator delete(a1: v11); /*0x10464cc49*/
  if ( (v14[0] & 1) != 0 ) /*0x10464cc52*/
    operator delete(a1: v15); /*0x10464cc58*/
  if ( (v12[0] & 1) != 0 ) /*0x10464cc61*/
    operator delete(a1: v13); /*0x10464cc67*/
  return 1; /*0x10464cc71*/
}

// Address: 0x10464ccc0 | Name: __ZN3RBX3Lua14DateTimeBridge16getUnixTimestampEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::getUnixTimestamp(__int64 a1)
{
  RBX::DateTime *Object; // rax
  int UnixTimestamp; // eax

  Object = (RBX::DateTime *)RBX::Lua::Bridge<RBX::DateTime>::getObject(a1, a2: 1); /*0x10464ccce*/
  UnixTimestamp = RBX::DateTime::getUnixTimestamp(this: Object); /*0x10464ccd6*/
  lua_pushnumber(a1, a2: (double)UnixTimestamp); /*0x10464cce3*/
  return 1; /*0x10464ccf1*/
}

// Address: 0x10464ccf4 | Name: __ZN3RBX3Lua14DateTimeBridge22getUnixTimestampMillisEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::getUnixTimestampMillis(__int64 a1)
{
  RBX::DateTime *Object; // rax
  int UnixTimestampMillis; // eax

  Object = (RBX::DateTime *)RBX::Lua::Bridge<RBX::DateTime>::getObject(a1, a2: 1); /*0x10464cd02*/
  UnixTimestampMillis = RBX::DateTime::getUnixTimestampMillis(this: Object); /*0x10464cd0a*/
  lua_pushnumber(a1, a2: (double)UnixTimestampMillis); /*0x10464cd17*/
  return 1; /*0x10464cd25*/
}

// Address: 0x10464cd28 | Name: __ZN3RBX3Lua14DateTimeBridge20registerClassLibraryEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::registerClassLibrary(__int64 a1)
{
  luaL_register(a1, a2: RBX::Lua::Bridge<RBX::DateTime>::className[0], a3: &RBX::Lua::DateTimeBridge::classLibrary); /*0x10464cd3f*/
  lua_setreadonly(a1, a2: 0xFFFFFFFFLL, a3: 1); /*0x10464cd51*/
  return lua_settop(a1, a2: 4294967294LL); /*0x10464cd62*/
}

// Address: 0x10464cd6a | Name: __ZN3RBX3Lua14DateTimeBridge13registerClassEP9lua_State
__int64 __fastcall RBX::Lua::DateTimeBridge::registerClass(__int64 a1)
{
  _QWORD v2[13]; // [rsp+8h] [rbp-68h] BYREF

  memset(&v2[4], 0, 72); /*0x10464cd85*/
  v2[0] = RBX::Lua::Bridge<RBX::DateTime>::on_index; /*0x10464cd98*/
  v2[1] = RBX::Lua::Bridge<RBX::DateTime>::on_newindex; /*0x10464cda2*/
  v2[2] = RBX::Lua::Bridge<RBX::DateTime>::on_eq; /*0x10464cdad*/
  v2[3] = RBX::Lua::Bridge<RBX::DateTime>::on_tostring; /*0x10464cdb8*/
  return RBX::Lua::NamecallAtomicBridge<RBX::DateTime>::registerClassAndExportFunctions( /*0x10464cdc8*/
           a1,
           a2: v2,
           a3: &RBX::Lua::DateTimeBridge::exportedFunctions);
}

// END DateTimeBridge part 1/1, 12 functions
