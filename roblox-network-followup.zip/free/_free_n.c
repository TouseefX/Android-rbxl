// _free_n -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 48 functions


// Address: 0x10024c581 | Name: __ZN3RBX28notifyAssemblyPrimitiveMovedEPNS_9PrimitiveE
__int64 __fastcall RBX::notifyAssemblyPrimitiveMoved(RBX *this, RBX::Primitive *a2)
{
  __int64 result; // rax
  __int64 v4; // r14
  __int64 v5; // r15

  RBX::Primitive::notifyVisuallyMoved(this); /*0x10024c58e*/
  result = *((_QWORD *)this + 45); /*0x10024c593*/
  if ( (int)((unsigned __int64)(*((_QWORD *)this + 46) - result) >> 3) > 0 ) /*0x10024c5aa*/
  {
    v4 = *((_QWORD *)this + 63); /*0x10024c5ac*/
    v5 = 0; /*0x10024c5b3*/
    do /*0x10024c5e6*/
    {
      RBX::ContactManager::requestUpdateContactSleepState( /*0x10024c5c3*/
        this: *(RBX::ContactManager **)(v4 + 2056),
        a2: *(RBX::Collision::Contact **)(result + 8 * v5++),
        a3: 0);
      result = *((_QWORD *)this + 45); /*0x10024c5cb*/
    }
    while ( v5 < (int)((unsigned __int64)(*((_QWORD *)this + 46) - result) >> 3) ); /*0x10024c5e6*/
  }
  return result; /*0x10024c5ec*/
}

// Address: 0x10046cc34 | Name: __ZNK3RBX4NameeqEPKc
bool __fastcall RBX::Name::operator==(unsigned __int8 *a1, const char *a2)
{
  size_t v4; // rax
  unsigned int v5; // ecx
  const void *v6; // r14

  v4 = strlen(__s: a2); /*0x10046cc44*/
  v5 = *a1; /*0x10046cc49*/
  if ( (v5 & 1) != 0 ) /*0x10046cc50*/
  {
    if ( v4 == *((_QWORD *)a1 + 1) ) /*0x10046cc62*/
    {
      if ( v4 == -1 ) /*0x10046cc68*/
        std::string::__throw_out_of_range[abi:ne200100](); /*0x10046cc8a*/
      v6 = *((const void **)a1 + 2); /*0x10046cc6a*/
      return memcmp(__s1: v6, __s2: a2, __n: v4) == 0; /*0x10046cc6a*/
    }
  }
  else if ( v4 == v5 >> 1 ) /*0x10046cc57*/
  {
    v6 = a1 + 1; /*0x10046cc59*/
    return memcmp(__s1: v6, __s2: a2, __n: v4) == 0; /*0x10046cc81*/
  }
  return false; /*0x10046cc85*/
}

// Address: 0x1004765d6 | Name: __ZN3RBXL8newChildINS_6FolderEEENSt3__110shared_ptrIT_EENS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEPNS_8InstanceE
RBX::EngineContext *__fastcall RBX::newChild<RBX::Folder>(RBX::EngineContext *a1, __int64 a2, RBX::Instance *a3)
{
  RBX::EngineContext::getThreadLocal(this: a1); /*0x1004765ec*/
  RBX::Creatable::createImpl<RBX::Folder,RBX::ForceConstructionInCreatable &>(a1); /*0x100476602*/
  RBX::Instance::setName(a1: *(_QWORD *)a1, a2); /*0x10047660d*/
  RBX::Instance::setParent(this: *(RBX::Instance **)a1, a2: a3); /*0x100476618*/
  return a1; /*0x100476620*/
}

// Address: 0x100481947 | Name: __ZN3RBXL8newChildINS_11StringValueEEENSt3__110shared_ptrIT_EENS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEPNS_8InstanceE
RBX::EngineContext *__fastcall RBX::newChild<RBX::StringValue>(RBX::EngineContext *a1, __int64 a2, RBX::Instance *a3)
{
  RBX::EngineContext::getThreadLocal(this: a1); /*0x10048195d*/
  RBX::Creatable::createImpl<RBX::StringValue,RBX::ForceConstructionInCreatable &>(a1); /*0x100481973*/
  RBX::Instance::setName(a1: *(_QWORD *)a1, a2); /*0x10048197e*/
  RBX::Instance::setParent(this: *(RBX::Instance **)a1, a2: a3); /*0x100481989*/
  return a1; /*0x100481991*/
}

// Address: 0x1010b9c98 | Name: __ZNK3RBX4NameneEPKc
__int64 __fastcall RBX::Name::operator!=(unsigned __int8 *a1, const char *a2)
{
  size_t v4; // rax
  unsigned int v5; // ecx
  unsigned int v6; // edx
  const void *v7; // r14

  v4 = strlen(__s: a2); /*0x1010b9ca8*/
  v6 = *a1; /*0x1010b9cad*/
  if ( (v6 & 1) != 0 ) /*0x1010b9cb4*/
  {
    LOBYTE(v5) = 1; /*0x1010b9cc4*/
    if ( v4 == *((_QWORD *)a1 + 1) ) /*0x1010b9cca*/
    {
      if ( v4 == -1 ) /*0x1010b9cd0*/
        std::string::__throw_out_of_range[abi:ne200100](); /*0x1010b9cf0*/
      v7 = *((const void **)a1 + 2); /*0x1010b9cd2*/
      goto LABEL_7; /*0x1010b9cd2*/
    }
  }
  else
  {
    LOBYTE(v5) = 1; /*0x1010b9cb8*/
    if ( v4 == v6 >> 1 ) /*0x1010b9cbd*/
    {
      v7 = a1 + 1; /*0x1010b9cbf*/
LABEL_7:
      LOBYTE(v5) = memcmp(__s1: v7, __s2: a2, __n: v4) != 0; /*0x1010b9cd6*/
    }
  }
  return v5; /*0x1010b9ceb*/
}

// Address: 0x102133dd0 | Name: __ZNK3RBX4NameeqERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
bool __fastcall RBX::Name::operator==(unsigned __int8 *a1, unsigned __int8 *a2)
{
  unsigned int v2; // eax
  size_t v3; // rdx
  unsigned int v4; // ecx
  __int64 v5; // r8
  const void *v6; // rdi
  const void *v8; // rsi

  v2 = *a1; /*0x102133dd0*/
  if ( (v2 & 1) != 0 ) /*0x102133dd5*/
    v3 = *((_QWORD *)a1 + 1); /*0x102133dd7*/
  else
    v3 = v2 >> 1; /*0x102133ddf*/
  v4 = *a2; /*0x102133de1*/
  if ( (v4 & 1) != 0 ) /*0x102133de7*/
    v5 = *((_QWORD *)a2 + 1); /*0x102133de9*/
  else
    v5 = v4 >> 1; /*0x102133df2*/
  if ( v3 != v5 ) /*0x102133df8*/
    return false; /*0x102133e04*/
  if ( (v2 & 1) != 0 ) /*0x102133dfc*/
    v6 = *((const void **)a1 + 2); /*0x102133dfe*/
  else
    v6 = a1 + 1; /*0x102133e07*/
  if ( (v4 & 1) != 0 ) /*0x102133e0d*/
    v8 = *((const void **)a2 + 2); /*0x102133e0f*/
  else
    v8 = a2 + 1; /*0x102133e15*/
  return memcmp(__s1: v6, __s2: v8, __n: v3) == 0; /*0x102133e06*/
}

// Address: 0x10285f062 | Name: __ZN3RBX16nVertsInFirstLODERKNS_12FileMeshDataE
__int64 __fastcall RBX::nVertsInFirstLOD(RBX *this, const RBX::FileMeshData *a2)
{
  unsigned __int64 v2; // rax
  __int64 v3; // rcx
  __int64 v5; // rdx
  __int64 v6; // rsi
  unsigned int v7; // eax
  unsigned int v8; // edi

  if ( *((_DWORD *)this + 200) < 3u ) /*0x10285f069*/
    return -858993459 * (unsigned int)((*((_QWORD *)this + 1) - *(_QWORD *)this) >> 3); /*0x10285f069*/
  v2 = *(unsigned int *)(*((_QWORD *)this + 99) + 4LL); /*0x10285f072*/
  if ( *(_DWORD *)(*((_QWORD *)this + 99) + 4LL) == 0 ) /*0x10285f078*/
    return -858993459 * (unsigned int)((*((_QWORD *)this + 1) - *(_QWORD *)this) >> 3); /*0x10285f078*/
  v3 = *((_QWORD *)this + 6); /*0x10285f07a*/
  if ( 0xAAAAAAAAAAAAAAABLL * ((*((_QWORD *)this + 7) - v3) >> 2) < v2 ) /*0x10285f09a*/
    return -858993459 * (unsigned int)((*((_QWORD *)this + 1) - *(_QWORD *)this) >> 3); /*0x10285f0a7*/
  v5 = 12 * v2; /*0x10285f0b6*/
  v6 = 0; /*0x10285f0ba*/
  v7 = 0; /*0x10285f0bc*/
  do /*0x10285f0e4*/
  {
    v8 = *(_DWORD *)(v3 + v6 + 4); /*0x10285f0c2*/
    if ( *(_DWORD *)(v3 + v6) > v7 ) /*0x10285f0c9*/
      v7 = *(_DWORD *)(v3 + v6); /*0x10285f0c9*/
    if ( v8 <= v7 ) /*0x10285f0cf*/
      v8 = v7; /*0x10285f0d1*/
    v7 = *(_DWORD *)(v3 + v6 + 8); /*0x10285f0d3*/
    if ( v7 <= v8 ) /*0x10285f0d9*/
      v7 = v8; /*0x10285f0db*/
    v6 += 12; /*0x10285f0dd*/
  }
  while ( v5 != v6 ); /*0x10285f0e4*/
  return v7 + 1; /*0x10285f0ad*/
}

// Address: 0x102a0ab1c | Name: __ZN3RBX7NetworkmiERKNS0_24NetAssetStatsMemoryFieldES3_
unsigned __int64 __fastcall RBX::Network::operator-(_DWORD *a1, _DWORD *a2)
{
  return ((unsigned __int64)(unsigned int)(a1[1] - a2[1]) << 32) | (unsigned int)(*a1 - *a2); /*0x102a0ab44*/
}

// Address: 0x102a0ab56 | Name: __ZN3RBX7NetworkmiERKNS0_19NetAssetStatsMemoryES3_
__int64 __fastcall RBX::Network::operator-(__int64 a1, _DWORD *a2, _DWORD *a3)
{
  __int64 result; // rax
  unsigned __int64 v4; // rdi

  result = a1; /*0x102a0ab66*/
  v4 = ((unsigned __int64)(unsigned int)(a2[3] - a3[3]) << 32) | (unsigned int)(a2[2] - a3[2]); /*0x102a0ab80*/
  *(_QWORD *)result = ((unsigned __int64)(unsigned int)(a2[1] - a3[1]) << 32) | (unsigned int)(*a2 - *a3); /*0x102a0ab83*/
  *(_QWORD *)(result + 8) = v4; /*0x102a0ab86*/
  *(_OWORD *)(result + 16) = 0; /*0x102a0ab8d*/
  return result; /*0x102a0ab91*/
}

// Address: 0x102a42156 | Name: __ZN3RBX31notifyAttributeChangedComponentEPNS_6ObjectERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
__int64 __fastcall RBX::notifyAttributeChangedComponent(__int64 a1, __int64 a2)
{
  __int64 v4; // rax
  unsigned int v5; // esi
  __int64 result; // rax
  unsigned int v7; // edx

  v4 = RBX::getDataModelComponentRaw<RBX::AttributeChangedSignalComponent>(Slot: a1, a2); /*0x102a42163*/
  if ( v4 != 0 ) /*0x102a4216b*/
    rbx::signal<void ()(std::string)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: v4, a2); /*0x102a42173*/
  result = RBX::getDataModelComponentRaw<RBX::AttributeNamedSignalsComponent>(a1, a2: v5); /*0x102a4217b*/
  if ( result != 0 ) /*0x102a42183*/
  {
    result = RBX::details::SplitHashTable<RBX::StringView,RBX::details::AttributeNameSignal,(RBX::SplitHashPolicy)10,0u,RBX::Hash<RBX::StringView>,std::equal_to<RBX::StringView>,RBX::details::AttributeNameSignalKeyGetter>::find_as<std::string>( /*0x102a4218b*/
               a1: result,
               a2);
    if ( result != 0 || v7 != 0 ) /*0x102a42198*/
      return rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: *(rbx::signals **)(*(_QWORD *)(result + 16) + 24LL * v7 + 8)); /*0x102a421b8*/
  }
  return result; /*0x102a421b4*/
}

// Address: 0x102a8fe30 | Name: __ZNK3RBX22NumberSequenceKeypointeqERKS0_
bool __fastcall RBX::NumberSequenceKeypoint::operator==(__int64 a1, __int64 a2)
{
  return (*(_QWORD *)a2 ^ *(_QWORD *)a1 | (unsigned int)(*(_DWORD *)(a2 + 8) ^ *(_DWORD *)(a1 + 8))) == 0; /*0x102a8fe46*/
}

// Address: 0x102a8fe48 | Name: __ZNK3RBX14NumberSequenceeqERKS0_
__int64 RBX::NumberSequence::operator==()
{
  return RBX::SmallVectorImpl<RBX::NumberSequenceKeypoint>::operator==(); /*0x102a8fe4c*/
}

// Address: 0x102a8fea6 | Name: __ZNK3RBX14NumberSequenceneERKS0_
char RBX::NumberSequence::operator!=()
{
  return RBX::SmallVectorImpl<RBX::NumberSequenceKeypoint>::operator==() ^ 1; /*0x102a8feb1*/
}

// Address: 0x102bd8129 | Name: __ZN3RBX19NSStringToStdStringEP8NSString
RBX *__fastcall RBX::NSStringToStdString(RBX *this, NSString *a2)
{
  NSString *v3; // rax
  NSString *v4; // r14
  id v5; // r15
  id v6; // rax
  id v7; // rax
  __int64 v8; // rdx
  __int64 v9; // rcx

  v3 = objc_retain(a1: a2); /*0x102bd813a*/
  v4 = v3; /*0x102bd8140*/
  if ( v3 != nullptr && (v5 = objc_retainAutorelease(a1: v3), objc_msgSend(a1: v5, a2: "UTF8String") != nullptr) ) /*0x102bd8169*/
  {
    v6 = objc_retainAutorelease(a1: v5); /*0x102bd816e*/
    v7 = objc_msgSend(a1: v6, a2: "UTF8String"); /*0x102bd8179*/
    std::string::basic_string[abi:ne200100]<0>(a1: this, a2: v7, a3: v8, a4: v9); /*0x102bd8185*/
  }
  else
  {
    *(_OWORD *)this = 0; /*0x102bd818f*/
    *((_QWORD *)this + 2) = 0; /*0x102bd8192*/
  }
  objc_release(a1: v4); /*0x102bd819d*/
  return this; /*0x102bd81a6*/
}

// Address: 0x102fb6b9f | Name: __ZN3RBXL7newCurlENS_11HttpContextE
_QWORD *__fastcall RBX::newCurl(_QWORD *a1, unsigned int a2)
{
  __int64 CurlShareHandle; // r15
  CURL *v4; // r14
  unsigned __int64 v5; // rsi
  __int64 v6; // rax
  const char *v7; // rsi
  CURLcode v8; // eax

  CurlShareHandle = RBX::HttpClient::getCurlShareHandle(a1: a2); /*0x102fb6bb3*/
  v4 = curl_easy_init(); /*0x102fb6bbb*/
  *a1 = v4; /*0x102fb6bbe*/
  v6 = operator new(a1: (RBX::Memory *)0x20, a2: v5); /*0x102fb6bc6*/
  *(_OWORD *)(v6 + 8) = 0; /*0x102fb6bce*/
  *(_QWORD *)v6 = &off_10C8BA1D0; /*0x102fb6bd9*/
  *(_QWORD *)(v6 + 24) = v4; /*0x102fb6bdc*/
  a1[1] = v6; /*0x102fb6be0*/
  if ( v4 == nullptr ) /*0x102fb6be7*/
    RBX::throw_runtime_error(this: (RBX *)"Error initializing CURL handle.", a2: v7); /*0x102fb6c25*/
  v8 = curl_easy_setopt(curl: v4, option: CURLOPT_SHARE, CurlShareHandle); /*0x102fb6bf6*/
  RBX::RbxCurl::logError<CURLcode>(a1: "CURLOPT_SHARE", a2: v8, a3: 1); /*0x102fb6c09*/
  return a1; /*0x102fb6c15*/
}

// Address: 0x1030ccbd7 | Name: __ZN3RBX25netscapeStringToCookieMapERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEERNS_17SmallSplitHashMapIS6_NS0_10shared_ptrINS_6CookieEEELj0ELNS_15SplitHashPolicyE10ENS_7details11DefaultHashIS6_EENSE_14DefaultEqualToIS6_EEEE
unsigned __int64 __fastcall RBX::netscapeStringToCookieMap(unsigned __int8 *a1, __int64 a2)
{
  unsigned int v2; // eax
  unsigned __int8 *v3; // rcx
  unsigned __int64 result; // rax
  unsigned __int8 *v5; // rsi
  unsigned __int64 v6; // rdx
  unsigned __int8 *v7; // rbx
  unsigned __int64 v8; // r13
  __int128 v9; // xmm0
  volatile signed __int64 *v10; // r14
  std::__shared_weak_count *v11; // r14
  unsigned int v12; // eax
  __int64 v13; // rax
  __int64 v14; // rax
  std::__shared_weak_count *v15; // r14
  std::__shared_weak_count *v18[2]; // [rsp+10h] [rbp-70h] BYREF
  std::__shared_weak_count *v19[2]; // [rsp+30h] [rbp-50h] BYREF
  unsigned __int8 *v20; // [rsp+48h] [rbp-38h] BYREF
  unsigned __int64 v21; // [rsp+50h] [rbp-30h]

  v2 = *a1; /*0x1030ccbec*/
  if ( (v2 & 1) != 0 ) /*0x1030ccbf5*/
  {
    v3 = *((unsigned __int8 **)a1 + 2); /*0x1030ccbf7*/
    result = *((_QWORD *)a1 + 1); /*0x1030ccbfb*/
  }
  else
  {
    v3 = a1 + 1; /*0x1030ccc01*/
    result = v2 >> 1; /*0x1030ccc05*/
  }
  v20 = v3; /*0x1030ccc07*/
  v21 = result; /*0x1030ccc0b*/
  if ( result != 0 )
  {
    do
    {
      result = RBX::detail::StringViewBase::find(a1: &v20, a2: "; ", a3: 2, a4: 0); /*0x1030ccc30*/
      if ( result == -1 ) /*0x1030ccc39*/
      {
        v5 = v20; /*0x1030ccc61*/
        v6 = v21; /*0x1030ccc65*/
        v8 = 0; /*0x1030ccc69*/
        v7 = nullptr; /*0x1030ccc6c*/
      }
      else
      {
        v5 = v20; /*0x1030ccc3b*/
        v6 = result; /*0x1030ccc46*/
        if ( v21 < result ) /*0x1030ccc49*/
          v6 = v21; /*0x1030ccc49*/
        result += 2LL; /*0x1030ccc4d*/
        if ( v21 < result ) /*0x1030ccc54*/
          result = v21; /*0x1030ccc54*/
        v7 = &v20[result]; /*0x1030ccc58*/
        v8 = v21 - result; /*0x1030ccc5c*/
      }
      if ( v6 != 0 )
      {
        *(_OWORD *)v19 = 0; /*0x1030ccc7a*/
        RBX::Cookie::createFromNetscapeFormat(a1: v18, a2: v5); /*0x1030ccc82*/
        v9 = *(_OWORD *)v18; /*0x1030ccc87*/
        *(_OWORD *)v18 = 0; /*0x1030ccc8e*/
        v10 = (volatile signed __int64 *)v19[1]; /*0x1030ccc92*/
        *(_OWORD *)v19 = v9; /*0x1030ccc96*/
        if ( v10 != nullptr && _InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1030cccaf*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v10 + 16))(a1: v10); /*0x1030cccb7*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v10); /*0x1030cccbd*/
        }
        v11 = v18[1]; /*0x1030cccc2*/
        if ( v18[1] != nullptr /*0x1030cccdb*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v18[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(a1: v11); /*0x1030ccce3*/
          std::__shared_weak_count::__release_weak(this: v11); /*0x1030ccce9*/
        }
        v12 = *(unsigned __int8 *)v19[0]; /*0x1030cccf2*/
        if ( (v12 & 1) != 0 ) /*0x1030cccf7*/
          v13 = *((_QWORD *)v19[0] + 1); /*0x1030ccd0a*/
        else
          v13 = v12 >> 1; /*0x1030cccf9*/
        if ( v13 != 0 )
        {
          v14 = RBX::SmallSplitHashMap<std::string,std::shared_ptr<RBX::Cookie>,0u,(RBX::SplitHashPolicy)10,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>>::operator[](a1: a2); /*0x1030ccd17*/
          result = std::shared_ptr<RBX::Cookie>::operator=[abi:ne200100](a1: v14, a2: v19); /*0x1030ccd23*/
        }
        else
        {
          result = (unsigned __int8)FLog::Cookie < 6u; /*0x1030ccd35*/
          if ( (unsigned __int8)FLog::Cookie >= 6u && (FLog::Cookie & 0xFE00) != 0 )
            result = FLog::FastLogSafeFormatted<std::string const&>(
                       a1: FLog::Cookie,
                       a2: qword_10D7854D0,
                       a3: 2,
                       a4: (int)"[FLog::Cookie] Malformed netscape cookie string: {}",
                       a5: 51,
                       a6: a1);
        }
        v20 = v7; /*0x1030ccd67*/
        v21 = v8; /*0x1030ccd6b*/
        v15 = v19[1]; /*0x1030ccd6f*/
        if ( v19[1] != nullptr ) /*0x1030ccd76*/
        {
          result = _InterlockedExchangeAdd64((volatile signed __int64 *)v19[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x1030ccd7f*/
          if ( result == 0 ) /*0x1030ccd88*/
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x1030ccd90*/
            result = std::__shared_weak_count::__release_weak(this: v15); /*0x1030ccd96*/
          }
        }
        v8 = v21; /*0x1030ccd9b*/
      }
      else
      {
        v20 = v7; /*0x1030cccfd*/
        v21 = v8; /*0x1030ccd01*/
      }
    }
    while ( v8 != 0 );
  }
  return result; /*0x1030cce34*/
}

// Address: 0x1030d2649 | Name: __ZN3RBXL19nsurlFromStringViewENS_10StringViewE
id __fastcall RBX::nsurlFromStringView(__int64 a1, __int64 a2)
{
  void *v2; // rax
  id v3; // rbx
  NSURL *v4; // rax
  NSURL *v5; // r14
  _BYTE v7[16]; // [rsp+10h] [rbp-40h] BYREF
  __int128 v8; // [rsp+20h] [rbp-30h]
  _QWORD v9[4]; // [rsp+30h] [rbp-20h] BYREF

  v9[0] = a1; /*0x1030d2654*/
  v9[1] = a2; /*0x1030d2658*/
  v2 = (void *)RBX::stringFromStringView(a1, a2); /*0x1030d265c*/
  v3 = objc_retainAutoreleasedReturnValue(a1: v2); /*0x1030d2669*/
  v4 = +[NSURL URLWithString:](a1: &OBJC_CLASS___NSURL, a2: "URLWithString:", v3); /*0x1030d267d*/
  v5 = objc_retainAutoreleasedReturnValue(a1: v4); /*0x1030d268b*/
  if ( v5 == nullptr && (unsigned __int8)FLog::Error >= 6u && BYTE1(FLog::Error) >= 3u )
  {
    *((_QWORD *)&v8 + 1) = v7; /*0x1030d26d5*/
    FLog::detail::FastLogSafeFormattedInternal(
      a1: FLog::Error,
      a2: qword_10D7BE948,
      a3: 3,
      a4: (unsigned int)"[FLog::Error] NSURL creation failed on url: {}",
      a5: 46,
      a6: 0,
      15,
      v7,
      v9,
      fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>,
      15);
  }
  objc_release(a1: v3); /*0x1030d26fe*/
  return objc_autoreleaseReturnValue(a1: v5); /*0x1030d2707*/
}

// Address: 0x103216678 | Name: __ZN3RBX14normalIdToMaskENS_8NormalIdE
__int64 __fastcall RBX::normalIdToMask(unsigned int a1)
{
  __int64 result; // rax

  result = 0; /*0x10321667c*/
  if ( a1 <= 5 ) /*0x103216681*/
    return dword_1094D2160[a1]; /*0x10321668c*/
  return result; /*0x10321668f*/
}

// Address: 0x10321669d | Name: __ZN3RBX16normalIdOppositeENS_8NormalIdE
__int64 __fastcall RBX::normalIdOpposite(int a1)
{
  return (unsigned int)((a1 + 3) % 6); /*0x1032166c2*/
}

// Address: 0x1032166c4 | Name: __ZN3RBX11normalIdToUENS_8NormalIdE
__int64 __fastcall RBX::normalIdToU(unsigned int a1)
{
  __int64 result; // rax

  result = 1; /*0x1032166c8*/
  if ( a1 <= 5 ) /*0x1032166d0*/
    return dword_1094D2178[a1]; /*0x1032166db*/
  return result; /*0x1032166de*/
}

// Address: 0x1032166e0 | Name: __ZN3RBX11normalIdToVENS_8NormalIdE
__int64 __fastcall RBX::normalIdToV(int a1)
{
  unsigned int v1; // edi
  __int64 result; // rax

  v1 = a1 - 1; /*0x1032166e4*/
  result = 1; /*0x1032166e6*/
  if ( v1 <= 4 ) /*0x1032166ee*/
    return dword_1094D2190[v1]; /*0x1032166f9*/
  return result; /*0x1032166fc*/
}

// Address: 0x103216894 | Name: __ZN3RBX17normalIdToVector3ENS_8NormalIdE
char *__fastcall RBX::normalIdToVector3(__int64 a1)
{
  int v1; // ebx
  __int64 v2; // rax

  v1 = a1; /*0x10321689a*/
  if ( (_BYTE)`guard variable for'RBX::normalIdToVector3(RBX::NormalId)::vector3map == 0 ) /*0x1032168a4*/
    RBX::normalIdToVector3(a1); /*0x1032168d2*/
  v2 = 72; /*0x1032168bf*/
  if ( v1 < 6 ) /*0x1032168c4*/
    v2 = 12LL * v1; /*0x1032168c4*/
  return (char *)&RBX::normalIdToVector3(RBX::NormalId)::vector3map + v2; /*0x1032168cf*/
}

// Address: 0x1032168d9 | Name: __ZN3RBX17normalIdToMatrix3ENS_8NormalIdE
char *__fastcall RBX::normalIdToMatrix3(__int64 a1)
{
  int v1; // ebx
  __int64 v2; // rax

  v1 = a1; /*0x1032168df*/
  if ( (_BYTE)`guard variable for'RBX::normalIdToMatrix3(RBX::NormalId)::matrix3map == 0 ) /*0x1032168e9*/
    RBX::normalIdToMatrix3(a1); /*0x103216917*/
  v2 = 216; /*0x103216904*/
  if ( v1 < 6 ) /*0x103216909*/
    v2 = 36LL * v1; /*0x103216909*/
  return (char *)&RBX::normalIdToMatrix3(RBX::NormalId)::matrix3map + v2; /*0x103216914*/
}

// Address: 0x1041b678a | Name: __ZN3RBXL10nowPreciseEv
double __fastcall RBX::nowPrecise(RBX *this)
{
  uint64_t v1; // rax
  RBX *v2; // rdi
  double v3; // xmm0_8
  int v5; // ebx
  RBX::Time *v6; // rdi
  int Start; // r14d
  RBX *v8; // rdi
  __int64 v9; // xmm0_8
  double v10; // [rsp+8h] [rbp-18h]

  if ( FFlag::g_flagsLoaded == 1 && FFlag::FasterPreciseTime == 1 ) /*0x1041b67a8*/
  {
    v1 = mach_absolute_time(); /*0x1041b67aa*/
    if ( RBX::startTimeInited == 0 ) /*0x1041b67b6*/
    {
      RBX::startTime = v1; /*0x1041b680b*/
      RBX::startTimeInited = 1; /*0x1041b6812*/
    }
    v10 = (double)((int)v1 - (int)RBX::startTime); /*0x1041b67c4*/
    RBX::tick_resolution(this: v2); /*0x1041b67c9*/
    return v3 * v10; /*0x1041b67ce*/
  }
  else
  {
    v5 = mach_absolute_time(); /*0x1041b67da*/
    Start = RBX::Time::getStart(this: v6); /*0x1041b67e2*/
    if ( (_BYTE)`guard variable for'RBX::tick_resolution_old(void)::tick_res == 0 /*0x1041b6829*/
      && __cxa_guard_acquire(a1: &`guard variable for'RBX::tick_resolution_old(void)::tick_res) != 0 )
    {
      RBX::tick_frequency_helper(this: v8); /*0x1041b682b*/
      RBX::tick_resolution_old(void)::tick_res = v9; /*0x1041b6830*/
      __cxa_guard_release(a1: &`guard variable for'RBX::tick_resolution_old(void)::tick_res); /*0x1041b683f*/
    }
    return (double)(v5 - Start) * *(double *)&RBX::tick_resolution_old(void)::tick_res; /*0x1041b67fa*/
  }
}

// Address: 0x1045817b0 | Name: __ZN3RBX16normalizeContextERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
void *__fastcall RBX::normalizeContext(_QWORD *a1)
{
  void *result; // rax

  result = a1; /*0x1045817b4*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1045817bc*/
  {
    if ( a1[1] != 0 ) /*0x1045817c9*/
      return result; /*0x1045817c9*/
  }
  else if ( *(_BYTE *)a1 != 0 ) /*0x1045817c0*/
  {
    return result; /*0x1045817c0*/
  }
  return &RBX::kDefaultContext; /*0x1045817d2*/
}

// Address: 0x1048f9364 | Name: __ZN3RBXL32notifyAliveIfDataModelClosedImplEPNS_8InstanceE
__int64 __fastcall RBX::notifyAliveIfDataModelClosedImpl(RBX *this, RBX::Instance *a2)
{
  __int64 result; // rax

  result = RBX::DataModel::get(this, a2); /*0x1048f9368*/
  if ( result != 0 && *(_BYTE *)(result + 1297) == 0 && RBX::ICrashReporter::reporterInstance != 0 ) /*0x1048f9385*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)RBX::ICrashReporter::reporterInstance + 40LL))(a1: RBX::ICrashReporter::reporterInstance); /*0x1048f938b*/
  return result; /*0x1048f938e*/
}

// Address: 0x10493c9b8 | Name: __ZNK3RBX4NameltERKS0_
_BOOL8 __fastcall RBX::Name::operator<(unsigned __int8 *a1, unsigned __int8 *a2)
{
  unsigned int v2; // ebx
  unsigned int v3; // r14d
  size_t v4; // r14
  const void *v5; // rdi
  _BOOL8 result; // rax
  size_t v7; // rbx
  const void *v8; // rsi
  size_t v9; // rdx
  int v10; // ecx

  if ( a1 == a2 ) /*0x10493c9bb*/
    return false; /*0x10493c9db*/
  v2 = *a2; /*0x10493c9c4*/
  v3 = *a1; /*0x10493c9c7*/
  if ( (v3 & 1) != 0 ) /*0x10493c9cf*/
  {
    v4 = *((_QWORD *)a1 + 1); /*0x10493c9d1*/
    v5 = *((const void **)a1 + 2); /*0x10493c9d5*/
  }
  else
  {
    v4 = v3 >> 1; /*0x10493c9de*/
    v5 = a1 + 1; /*0x10493c9e1*/
  }
  if ( (v2 & 1) != 0 ) /*0x10493c9e7*/
  {
    v7 = *((_QWORD *)a2 + 1); /*0x10493c9e9*/
    v8 = *((const void **)a2 + 2); /*0x10493c9ed*/
  }
  else
  {
    v7 = v2 >> 1; /*0x10493c9f3*/
    v8 = a2 + 1; /*0x10493c9f5*/
  }
  v9 = v4; /*0x10493c9fb*/
  if ( v7 < v4 ) /*0x10493c9fe*/
    v9 = v7; /*0x10493c9fe*/
  v10 = memcmp(__s1: v5, __s2: v8, __n: v9); /*0x10493ca07*/
  result = v10 < 0; /*0x10493ca15*/
  if ( v10 == 0 ) /*0x10493ca18*/
    return v4 < v7; /*0x10493ca18*/
  return result; /*0x10493c9dd*/
}

// Address: 0x104b1de66 | Name: __ZN3RBXL15nearestMatColorEhhhf
__int64 __fastcall RBX::nearestMatColor(RBX *this, int a2, int a3, __m128 a4)
{
  float v4; // xmm1_4
  int v5; // ecx
  __int64 v6; // r8
  unsigned __int64 v7; // rbx
  bool v8; // r14
  __int64 result; // rax
  int v10; // r13d
  int v11; // r12d
  int v12; // r15d
  int v13; // r14d
  float v14; // xmm4_4
  unsigned int v15; // edx

  v4 = _mm_andnot_ps(_mm_cmplt_ss((__m128)0LL, a4), (__m128)0x4F000000u).f32[0]; /*0x104b1de86*/
  v5 = 0xFFFF; /*0x104b1de89*/
  v6 = 0; /*0x104b1de8e*/
  v7 = 0; /*0x104b1dead*/
  v8 = false; /*0x104b1deaf*/
  do /*0x104b1df49*/
  {
    result = *(unsigned int *)((char *)&RBX::kMaterialColorMap + v6); /*0x104b1deb2*/
    v10 = (unsigned __int8)BYTE2(*(_DWORD *)((char *)&RBX::kMaterialColorMap + v6)) - (_DWORD)this; /*0x104b1dec7*/
    v11 = (unsigned __int8)BYTE1(*(_DWORD *)((char *)&RBX::kMaterialColorMap + v6)) - a2; /*0x104b1decd*/
    v12 = v10 * v10 /*0x104b1dee8*/
        + v11 * v11
        + ((unsigned __int8)*(_DWORD *)((char *)&RBX::kMaterialColorMap + v6) - a3)
        * ((unsigned __int8)*(_DWORD *)((char *)&RBX::kMaterialColorMap + v6) - a3);
    if ( a4.f32[0] <= 0.0 ) /*0x104b1deee*/
    {
      if ( v12 == 0 ) /*0x104b1df1e*/
        break; /*0x104b1df1e*/
      v14 = (float)v12; /*0x104b1df23*/
      if ( v4 > (float)v12 ) /*0x104b1df2b*/
      {
LABEL_8:
        v4 = v14; /*0x104b1df2d*/
        v5 = *(_DWORD *)((char *)&RBX::kMaterialColorMap + v6); /*0x104b1df30*/
      }
    }
    else
    {
      v13 = *(_DWORD *)((char *)&RBX::minMaterialDist + v6); /*0x104b1def0*/
      if ( v12 <= v13 ) /*0x104b1def7*/
      {
        v14 = 1.0 - (float)((float)v12 / (float)v13); /*0x104b1df10*/
        if ( v14 > v4 ) /*0x104b1df17*/
          goto LABEL_8; /*0x104b1df17*/
      }
    }
    v8 = v7 >= 0x16; /*0x104b1df32*/
    v6 += 4; /*0x104b1df3e*/
    ++v7; /*0x104b1df42*/
  }
  while ( v7 != 23 ); /*0x104b1df49*/
  v15 = 0; /*0x104b1df4f*/
  if ( v4 > a4.f32[0] ) /*0x104b1df54*/
    v15 = v5; /*0x104b1df54*/
  if ( v8 ) /*0x104b1df57*/
    return v15; /*0x104b1df5b*/
  return result; /*0x104b1df5e*/
}

// Address: 0x104d72168 | Name: __ZN3RBXL18normalizeJobStatusENSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
__int64 __fastcall RBX::normalizeJobStatus(__int64 a1, unsigned __int8 *a2)
{
  unsigned __int8 v4; // al
  unsigned __int8 *v5; // rcx
  unsigned __int64 v6; // rsi
  __int64 v7; // rdx
  unsigned __int8 *v8; // rdx
  unsigned __int8 *v9; // r8
  unsigned __int8 *v10; // rsi
  __int64 v11; // r9
  bool v12; // zf
  void *v13; // rsi
  unsigned __int8 *v14; // rdi
  __int64 v15; // rsi
  __int64 v16; // rax
  unsigned int v17; // edx
  unsigned __int8 *v18; // rcx
  __int64 v19; // rdx
  unsigned int v20; // r15d
  unsigned __int8 *v21; // r12
  __int64 v22; // r15
  __int64 i; // r13
  __int128 v25; // [rsp+8h] [rbp-48h] BYREF
  __int64 v26; // [rsp+18h] [rbp-38h]
  char v27[41]; // [rsp+27h] [rbp-29h] BYREF

  v4 = *a2; /*0x104d7217f*/
  if ( (*a2 & 1) != 0 ) /*0x104d72183*/
  {
    v6 = *((_QWORD *)a2 + 1); /*0x104d72190*/
    v5 = *((unsigned __int8 **)a2 + 2); /*0x104d72194*/
  }
  else
  {
    v5 = a2 + 1; /*0x104d72188*/
    v6 = v4 >> 1; /*0x104d7218c*/
  }
  v7 = 11; /*0x104d7219c*/
  if ( v6 < 0xB ) /*0x104d721a1*/
    v7 = v6; /*0x104d721a1*/
  if ( v6 != 0 ) /*0x104d721a8*/
  {
    v8 = &v5[v7]; /*0x104d721ae*/
    v9 = v5; /*0x104d721b8*/
    v10 = v8; /*0x104d721bb*/
    do /*0x104d721ca*/
    {
      if ( *v9 == 74 ) /*0x104d721c2*/
      {
        v11 = 1; /*0x104d721ce*/
        while ( v11 != 11 ) /*0x104d721d8*/
        {
          if ( &v9[v11] == v8 ) /*0x104d721e1*/
            goto LABEL_17; /*0x104d721e1*/
          v12 = v9[v11] == (unsigned __int8)aJobStatus_0[v11]; /*0x104d721ea*/
          ++v11; /*0x104d721ee*/
          if ( !v12 ) /*0x104d721f1*/
            goto LABEL_9; /*0x104d721f1*/
        }
        v10 = v9; /*0x104d721f5*/
      }
LABEL_9:
      ++v9; /*0x104d721c4*/
    }
    while ( v9 != v8 ); /*0x104d721ca*/
LABEL_17:
    LOBYTE(v5) = v10 == v8 || v10 != v5; /*0x104d721fa*/
    if ( (_BYTE)v5 == 0 ) /*0x104d72208*/
    {
      std::string::basic_string(a1: &v25, a2, a3: 11, a4: -1, a5: v27); /*0x104d72221*/
      if ( (*a2 & 1) != 0 ) /*0x104d72229*/
        operator delete(a1: *((RBX::Memory **)a2 + 2), a2: v13); /*0x104d7222f*/
      *((_QWORD *)a2 + 2) = v26; /*0x104d72238*/
      *(_OWORD *)a2 = v25; /*0x104d72240*/
      v4 = *a2; /*0x104d72243*/
    }
  }
  if ( (v4 & 1) != 0 ) /*0x104d72247*/
  {
    v15 = *((_QWORD *)a2 + 1); /*0x104d72254*/
    v14 = *((unsigned __int8 **)a2 + 2); /*0x104d72258*/
  }
  else
  {
    v14 = a2 + 1; /*0x104d72249*/
    v15 = v4 >> 1; /*0x104d7224f*/
  }
  LOBYTE(v25) = 95; /*0x104d72263*/
  v16 = std::remove[abi:ne200100]<std::__wrap_iter<char *>,char>(a1: v14, a2: &v14[v15], a3: &v25, a4: v5); /*0x104d72266*/
  v17 = *a2; /*0x104d7226b*/
  if ( (v17 & 1) != 0 ) /*0x104d72271*/
  {
    v18 = *((unsigned __int8 **)a2 + 2); /*0x104d72281*/
    v19 = (__int64)&v18[*((_QWORD *)a2 + 1)]; /*0x104d72289*/
  }
  else
  {
    v18 = a2 + 1; /*0x104d72273*/
    v19 = (__int64)&a2[(v17 >> 1) + 1]; /*0x104d7227c*/
  }
  std::string::erase(a1: a2, a2: v16 - (_QWORD)v18, a3: v19 - v16); /*0x104d72298*/
  v20 = *a2; /*0x104d7229d*/
  if ( (v20 & 1) != 0 ) /*0x104d722a5*/
  {
    v22 = *((_QWORD *)a2 + 1); /*0x104d722b0*/
    v21 = *((unsigned __int8 **)a2 + 2); /*0x104d722b4*/
  }
  else
  {
    v21 = a2 + 1; /*0x104d722a7*/
    v22 = v20 >> 1; /*0x104d722ab*/
  }
  if ( v22 != 0 ) /*0x104d722bb*/
  {
    for ( i = 0; i != v22; ++i ) /*0x104d722bd*/
      v21[i] = __toupper(a1: v21[i]); /*0x104d722ca*/
  }
  *(_QWORD *)(a1 + 16) = *((_QWORD *)a2 + 2); /*0x104d722da*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x104d722e1*/
  *(_OWORD *)a2 = 0; /*0x104d722e8*/
  *((_QWORD *)a2 + 2) = 0; /*0x104d722eb*/
  return a1; /*0x104d722f6*/
}

// Address: 0x104f89bdd | Name: __ZN3RBX11newNullToolEPNS_9WorkspaceE
RBX *__fastcall RBX::newNullTool(RBX *this, RBX::Workspace *a2)
{
  RBX::Workspace *v4; // [rsp+0h] [rbp-10h] BYREF

  v4 = a2; /*0x104f89bea*/
  RBX::Creatable::createImpl<RBX::NewNullTool,RBX::Workspace *&>(a1: this, a2: &v4); /*0x104f89bf0*/
  return this; /*0x104f89bfc*/
}

// Address: 0x105437b54 | Name: __ZN3RBX7NetworkmiERKNS0_27LargeReplicatorNetworkStatsES3_
__int64 __fastcall RBX::Network::operator-(__int64 a1, __int64 a2, const __m128i *a3)
{
  RBX::TDigestNoLock *v6; // rbx
  __m128i v7; // xmm1
  __m128i v8; // xmm1
  _BYTE v10[8]; // [rsp+0h] [rbp-50h] BYREF
  __m128i v11; // [rsp+8h] [rbp-48h]
  __m128i v12; // [rsp+18h] [rbp-38h]

  *(_QWORD *)a1 = 0; /*0x105437b6e*/
  *(_DWORD *)(a1 + 8) = 0; /*0x105437b75*/
  v6 = (RBX::TDigestNoLock *)(a1 + 16); /*0x105437b7c*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 16)); /*0x105437b83*/
  *(_OWORD *)(a1 + 40) = 0; /*0x105437b90*/
  *(_OWORD *)(a1 + 24) = 0; /*0x105437b96*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 56)); /*0x105437b9f*/
  *(_OWORD *)(a1 + 80) = 0; /*0x105437ba8*/
  *(_OWORD *)(a1 + 64) = 0; /*0x105437bae*/
  *(_QWORD *)a1 = _mm_sub_epi32(_mm_loadl_epi64((const __m128i *)a2), _mm_loadl_epi64(a3)).u64[0]; /*0x105437bc4*/
  *(_DWORD *)(a1 + 8) = *(_DWORD *)(a2 + 8) - a3->i32[2]; /*0x105437bd2*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)v10); /*0x105437bda*/
  v11 = _mm_loadu_si128((const __m128i *)(a2 + 24)); /*0x105437be6*/
  v7 = _mm_loadu_si128((const __m128i *)(a2 + 40)); /*0x105437beb*/
  v12 = v7; /*0x105437bf2*/
  *(__m128i *)(a1 + 24) = v11; /*0x105437bf7*/
  *(__m128i *)(a1 + 40) = v7; /*0x105437bfd*/
  RBX::TDigestNoLock::reset(this: v6); /*0x105437c06*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v10); /*0x105437c0f*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)v10); /*0x105437c18*/
  v11 = _mm_loadu_si128((const __m128i *)(a2 + 64)); /*0x105437c24*/
  v8 = _mm_loadu_si128((const __m128i *)(a2 + 80)); /*0x105437c29*/
  v12 = v8; /*0x105437c30*/
  *(__m128i *)(a1 + 64) = v11; /*0x105437c35*/
  *(__m128i *)(a1 + 80) = v8; /*0x105437c3b*/
  RBX::TDigestNoLock::reset(this: (RBX::TDigestNoLock *)(a1 + 56)); /*0x105437c44*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v10); /*0x105437c4d*/
  return a1; /*0x105437c55*/
}

// Address: 0x10543829a | Name: __ZN3RBX7NetworkmiERKNS0_25LargeReplicatorAssetStatsES3_
__int64 __fastcall RBX::Network::operator-(__int64 a1, __int64 a2, __int64 a3)
{
  RBX::TDigestNoLock *v6; // r13
  __m128i v7; // xmm1
  __m128i v8; // xmm1
  __m128i v9; // xmm1
  _BYTE v11[8]; // [rsp+10h] [rbp-50h] BYREF
  __m128i v12; // [rsp+18h] [rbp-48h]
  __m128i v13; // [rsp+28h] [rbp-38h]

  v6 = (RBX::TDigestNoLock *)(a1 + 88); /*0x1054382b4*/
  *(_OWORD *)(a1 + 64) = 0; /*0x1054382bc*/
  *(_OWORD *)(a1 + 48) = 0; /*0x1054382c1*/
  *(_OWORD *)(a1 + 32) = 0; /*0x1054382c6*/
  *(_OWORD *)(a1 + 16) = 0; /*0x1054382cb*/
  *(_OWORD *)a1 = 0; /*0x1054382d0*/
  *(_DWORD *)(a1 + 80) = 0; /*0x1054382d4*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 88)); /*0x1054382de*/
  *(_OWORD *)(a1 + 112) = 0; /*0x1054382ee*/
  *(_OWORD *)(a1 + 96) = 0; /*0x1054382f3*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 128)); /*0x1054382fb*/
  *(_OWORD *)(a1 + 152) = 0; /*0x10543830b*/
  *(_OWORD *)(a1 + 136) = 0; /*0x105438313*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 168)); /*0x10543831f*/
  *(_OWORD *)(a1 + 192) = 0; /*0x105438328*/
  *(_OWORD *)(a1 + 176) = 0; /*0x105438330*/
  *(__m128i *)a1 = _mm_sub_epi32(_mm_loadu_si128((const __m128i *)a2), _mm_loadu_si128((const __m128i *)a3)); /*0x105438346*/
  *(__m128i *)(a1 + 16) = _mm_sub_epi32( /*0x10543835a*/
                            _mm_loadu_si128((const __m128i *)(a2 + 16)),
                            _mm_loadu_si128((const __m128i *)(a3 + 16)));
  *(_QWORD *)(a1 + 32) = _mm_sub_epi32( /*0x10543836f*/
                           _mm_loadl_epi64((const __m128i *)(a2 + 32)),
                           _mm_loadl_epi64((const __m128i *)(a3 + 32))).u64[0];
  if ( FFlag::LrResetStaleDeltaState == 1 ) /*0x10543837e*/
    *(_DWORD *)(a1 + 40) = *(_DWORD *)(a2 + 40) - *(_DWORD *)(a3 + 40); /*0x105438388*/
  *(_QWORD *)(a1 + 44) = _mm_sub_epi32( /*0x10543839b*/
                           _mm_loadl_epi64((const __m128i *)(a2 + 44)),
                           _mm_loadl_epi64((const __m128i *)(a3 + 44))).u64[0];
  if ( FFlag::LrRegisterCachedAssetInReceiver == 1 ) /*0x1054383aa*/
    *(_DWORD *)(a1 + 52) = *(_DWORD *)(a2 + 52) - *(_DWORD *)(a3 + 52); /*0x1054383b4*/
  *(_DWORD *)(a1 + 56) = *(_DWORD *)(a2 + 56) - *(_DWORD *)(a3 + 56); /*0x1054383bf*/
  if ( DFFlag::LrSkipInlineMissingNetAsset == 1 ) /*0x1054383cc*/
    *(_DWORD *)(a1 + 60) = *(_DWORD *)(a2 + 60) - *(_DWORD *)(a3 + 60); /*0x1054383d6*/
  *(_QWORD *)(a1 + 64) = _mm_sub_epi32( /*0x1054383e9*/
                           _mm_loadl_epi64((const __m128i *)(a2 + 64)),
                           _mm_loadl_epi64((const __m128i *)(a3 + 64))).u64[0];
  *(_DWORD *)(a1 + 72) = *(_DWORD *)(a2 + 72) - *(_DWORD *)(a3 + 72); /*0x1054383f6*/
  *(_DWORD *)(a1 + 80) = *(_DWORD *)(a2 + 80) - *(_DWORD *)(a3 + 80); /*0x105438401*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)v11); /*0x105438408*/
  v12 = _mm_loadu_si128((const __m128i *)(a2 + 96)); /*0x105438413*/
  v7 = _mm_loadu_si128((const __m128i *)(a2 + 112)); /*0x105438418*/
  v13 = v7; /*0x10543841e*/
  *(__m128i *)(a1 + 96) = v12; /*0x105438423*/
  *(__m128i *)(a1 + 112) = v7; /*0x105438428*/
  RBX::TDigestNoLock::reset(this: v6); /*0x105438430*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v11); /*0x105438439*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)v11); /*0x105438442*/
  v12 = _mm_loadu_si128((const __m128i *)(a2 + 136)); /*0x105438450*/
  v8 = _mm_loadu_si128((const __m128i *)(a2 + 152)); /*0x105438455*/
  v13 = v8; /*0x10543845e*/
  *(__m128i *)(a1 + 136) = v12; /*0x105438463*/
  *(__m128i *)(a1 + 152) = v8; /*0x10543846b*/
  RBX::TDigestNoLock::reset(this: (RBX::TDigestNoLock *)(a1 + 128)); /*0x105438476*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v11); /*0x10543847f*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)v11); /*0x105438488*/
  v12 = _mm_loadu_si128((const __m128i *)(a2 + 176)); /*0x105438496*/
  v9 = _mm_loadu_si128((const __m128i *)(a2 + 192)); /*0x10543849b*/
  v13 = v9; /*0x1054384a4*/
  *(__m128i *)(a1 + 176) = v12; /*0x1054384a9*/
  *(__m128i *)(a1 + 192) = v9; /*0x1054384b1*/
  RBX::TDigestNoLock::reset(this: (RBX::TDigestNoLock *)(a1 + 168)); /*0x1054384bd*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v11); /*0x1054384c6*/
  return a1; /*0x1054384ce*/
}

// Address: 0x105439261 | Name: __ZN3RBX7NetworkmiERKNS0_20LargeReplicatorStatsES3_
__int64 __fastcall RBX::Network::operator-(__int64 a1, __int64 a2, __int64 a3)
{
  __int128 v6; // xmm0
  __int128 v7; // xmm1
  __int128 v8; // xmm2
  __int128 v9; // xmm0
  __int128 v10; // xmm1
  __int128 v11; // xmm2
  __int128 v12; // xmm0
  __int128 v13; // xmm0
  __int128 v15; // [rsp+8h] [rbp-118h] BYREF
  __int128 v16; // [rsp+18h] [rbp-108h]
  __int128 v17; // [rsp+28h] [rbp-F8h]
  __int128 v18; // [rsp+38h] [rbp-E8h]
  __int128 v19; // [rsp+48h] [rbp-D8h]
  int v20; // [rsp+58h] [rbp-C8h]
  _BYTE v21[8]; // [rsp+60h] [rbp-C0h] BYREF
  __int128 v22; // [rsp+68h] [rbp-B8h]
  __int128 v23; // [rsp+78h] [rbp-A8h]
  _BYTE v24[8]; // [rsp+88h] [rbp-98h] BYREF
  __int128 v25; // [rsp+90h] [rbp-90h]
  __int128 v26; // [rsp+A0h] [rbp-80h]
  _BYTE v27[8]; // [rsp+B0h] [rbp-70h] BYREF
  __int128 v28; // [rsp+B8h] [rbp-68h]
  __int128 v29; // [rsp+C8h] [rbp-58h]
  RBX::TDigestNoLock *v30; // [rsp+D8h] [rbp-48h]
  RBX::TDigestNoLock *v31; // [rsp+E0h] [rbp-40h]
  RBX::TDigestNoLock *v32; // [rsp+E8h] [rbp-38h]
  RBX::TDigestNoLock *v33; // [rsp+F0h] [rbp-30h]

  *(_OWORD *)(a1 + 64) = 0; /*0x105439285*/
  *(_OWORD *)(a1 + 48) = 0; /*0x105439289*/
  *(_OWORD *)(a1 + 32) = 0; /*0x10543928d*/
  *(_OWORD *)(a1 + 16) = 0; /*0x105439291*/
  *(_OWORD *)a1 = 0; /*0x105439295*/
  *(_DWORD *)(a1 + 80) = 0; /*0x105439298*/
  v31 = (RBX::TDigestNoLock *)(a1 + 88); /*0x10543929f*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 88)); /*0x1054392a3*/
  *(_OWORD *)(a1 + 112) = 0; /*0x1054392b2*/
  *(_OWORD *)(a1 + 96) = 0; /*0x1054392b6*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 128)); /*0x1054392bd*/
  *(_OWORD *)(a1 + 152) = 0; /*0x1054392cc*/
  *(_OWORD *)(a1 + 136) = 0; /*0x1054392d3*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 168)); /*0x1054392dd*/
  *(_OWORD *)(a1 + 272) = 0; /*0x1054392ec*/
  *(_OWORD *)(a1 + 256) = 0; /*0x1054392f3*/
  *(_OWORD *)(a1 + 240) = 0; /*0x1054392fa*/
  *(_OWORD *)(a1 + 224) = 0; /*0x105439301*/
  *(_OWORD *)(a1 + 208) = 0; /*0x105439308*/
  *(_OWORD *)(a1 + 192) = 0; /*0x10543930f*/
  *(_OWORD *)(a1 + 176) = 0; /*0x105439316*/
  *(_DWORD *)(a1 + 288) = 0; /*0x10543931d*/
  v32 = (RBX::TDigestNoLock *)(a1 + 296); /*0x105439327*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 296)); /*0x10543932b*/
  *(_OWORD *)(a1 + 320) = 0; /*0x10543933a*/
  *(_OWORD *)(a1 + 304) = 0; /*0x105439341*/
  v33 = (RBX::TDigestNoLock *)(a1 + 336); /*0x105439348*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 336)); /*0x10543934c*/
  *(_OWORD *)(a1 + 360) = 0; /*0x10543935b*/
  *(_OWORD *)(a1 + 344) = 0; /*0x105439362*/
  v30 = (RBX::TDigestNoLock *)(a1 + 376); /*0x105439369*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 376)); /*0x10543936d*/
  *(_OWORD *)(a1 + 464) = 0; /*0x105439375*/
  *(_OWORD *)(a1 + 448) = 0; /*0x10543937c*/
  *(_OWORD *)(a1 + 432) = 0; /*0x105439383*/
  *(_OWORD *)(a1 + 416) = 0; /*0x10543938a*/
  *(_OWORD *)(a1 + 400) = 0; /*0x105439391*/
  *(_OWORD *)(a1 + 384) = 0; /*0x105439398*/
  RBX::Network::operator-(a1: (__int64)&v15, a2, a3); /*0x1054393ac*/
  *(_DWORD *)(a1 + 80) = v20; /*0x1054393b7*/
  *(_OWORD *)(a1 + 64) = v19; /*0x1054393c1*/
  v6 = v15; /*0x1054393c5*/
  v7 = v16; /*0x1054393cc*/
  v8 = v17; /*0x1054393d3*/
  *(_OWORD *)(a1 + 48) = v18; /*0x1054393e1*/
  *(_OWORD *)(a1 + 32) = v8; /*0x1054393e5*/
  *(_OWORD *)(a1 + 16) = v7; /*0x1054393e9*/
  *(_OWORD *)a1 = v6; /*0x1054393ed*/
  *(_OWORD *)(a1 + 96) = v22; /*0x1054393f7*/
  *(_OWORD *)(a1 + 112) = v23; /*0x105439402*/
  RBX::TDigestNoLock::reset(this: v31); /*0x10543940a*/
  *(_OWORD *)(a1 + 136) = v25; /*0x105439416*/
  *(_OWORD *)(a1 + 152) = v26; /*0x105439421*/
  RBX::TDigestNoLock::reset(this: (RBX::TDigestNoLock *)(a1 + 128)); /*0x10543942b*/
  *(_OWORD *)(a1 + 176) = v28; /*0x105439434*/
  *(_OWORD *)(a1 + 192) = v29; /*0x10543943f*/
  RBX::TDigestNoLock::reset(this: (RBX::TDigestNoLock *)(a1 + 168)); /*0x105439449*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v27); /*0x105439452*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v24); /*0x10543945e*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v21); /*0x10543946a*/
  RBX::Network::operator-(a1: (__int64)&v15, a2: a2 + 208, a3: a3 + 208); /*0x105439482*/
  *(_DWORD *)(a1 + 288) = v20; /*0x105439494*/
  *(_OWORD *)(a1 + 272) = v19; /*0x10543949e*/
  v9 = v15; /*0x1054394a2*/
  v10 = v16; /*0x1054394a9*/
  v11 = v17; /*0x1054394b0*/
  *(_OWORD *)(a1 + 256) = v18; /*0x1054394be*/
  *(_OWORD *)(a1 + 240) = v11; /*0x1054394c2*/
  *(_OWORD *)(a1 + 224) = v10; /*0x1054394c6*/
  *(_OWORD *)(a1 + 208) = v9; /*0x1054394ca*/
  *(_OWORD *)(a1 + 304) = v22; /*0x1054394d4*/
  *(_OWORD *)(a1 + 320) = v23; /*0x1054394e2*/
  RBX::TDigestNoLock::reset(this: v32); /*0x1054394ed*/
  *(_OWORD *)(a1 + 344) = v25; /*0x1054394f9*/
  *(_OWORD *)(a1 + 360) = v26; /*0x105439504*/
  RBX::TDigestNoLock::reset(this: v33); /*0x10543950f*/
  *(_OWORD *)(a1 + 384) = v28; /*0x105439518*/
  *(_OWORD *)(a1 + 400) = v29; /*0x105439523*/
  RBX::TDigestNoLock::reset(this: v30); /*0x10543952e*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v27); /*0x105439537*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v24); /*0x105439543*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v21); /*0x10543954f*/
  RBX::Network::operator-(a1: (__int64)&v15, a2: (_DWORD *)(a2 + 448), a3: (_DWORD *)(a3 + 448)); /*0x105439567*/
  v12 = v15; /*0x10543957a*/
  *(_OWORD *)(a1 + 464) = v16; /*0x105439581*/
  *(_OWORD *)(a1 + 448) = v12; /*0x105439585*/
  RBX::Network::operator-(a1: (__int64)&v15, a2: (_DWORD *)(a2 + 416), a3: (_DWORD *)(a3 + 416)); /*0x105439599*/
  v13 = v15; /*0x10543959e*/
  *(_OWORD *)(a1 + 432) = v16; /*0x1054395ac*/
  *(_OWORD *)(a1 + 416) = v13; /*0x1054395b3*/
  return a1; /*0x1054395bd*/
}

// Address: 0x10543976a | Name: __ZN3RBX7NetworkmiERKNS0_25LargeReplicatorTotalStatsES3_
__int64 __fastcall RBX::Network::operator-(__int64 a1, __int64 a2, const __m128i *a3)
{
  RBX::TDigestNoLock *v6; // r13
  __int128 v7; // xmm0
  __int128 v8; // xmm1
  __int128 v9; // xmm2
  __int128 v10; // xmm0
  __int128 v11; // xmm1
  __int128 v12; // xmm2
  __int128 v13; // xmm0
  __int128 v14; // xmm1
  __int128 v15; // xmm2
  __int128 v17; // [rsp+0h] [rbp-250h] BYREF
  _BYTE v18[48]; // [rsp+10h] [rbp-240h] BYREF
  __int128 v19; // [rsp+40h] [rbp-210h]
  _QWORD v20[6]; // [rsp+50h] [rbp-200h] BYREF
  _BYTE v21[8]; // [rsp+80h] [rbp-1D0h] BYREF
  __int128 v22; // [rsp+88h] [rbp-1C8h]
  __int128 v23; // [rsp+98h] [rbp-1B8h]
  _BYTE v24[8]; // [rsp+A8h] [rbp-1A8h] BYREF
  __int128 v25; // [rsp+B0h] [rbp-1A0h]
  __int128 v26; // [rsp+C0h] [rbp-190h]
  __int128 v27; // [rsp+D0h] [rbp-180h]
  __int128 v28; // [rsp+E0h] [rbp-170h]
  __int128 v29; // [rsp+F0h] [rbp-160h]
  __int128 v30; // [rsp+100h] [rbp-150h]
  __int128 v31; // [rsp+110h] [rbp-140h]
  int v32; // [rsp+120h] [rbp-130h]
  _BYTE v33[8]; // [rsp+128h] [rbp-128h] BYREF
  __int128 v34; // [rsp+130h] [rbp-120h]
  __int128 v35; // [rsp+140h] [rbp-110h]
  _BYTE v36[8]; // [rsp+150h] [rbp-100h] BYREF
  __int128 v37; // [rsp+158h] [rbp-F8h]
  __int128 v38; // [rsp+168h] [rbp-E8h]
  _BYTE v39[8]; // [rsp+178h] [rbp-D8h] BYREF
  __int128 v40; // [rsp+180h] [rbp-D0h]
  __int128 v41; // [rsp+190h] [rbp-C0h]
  __int128 v42; // [rsp+1A0h] [rbp-B0h]
  __int128 v43; // [rsp+1B0h] [rbp-A0h]
  __int128 v44; // [rsp+1C0h] [rbp-90h]
  __int128 v45; // [rsp+1D0h] [rbp-80h]
  RBX::TDigestNoLock *v46; // [rsp+1E0h] [rbp-70h]
  RBX::TDigestNoLock *v47; // [rsp+1E8h] [rbp-68h]
  RBX::TDigestNoLock *v48; // [rsp+1F0h] [rbp-60h]
  RBX::TDigestNoLock *v49; // [rsp+1F8h] [rbp-58h]
  RBX::TDigestNoLock *v50; // [rsp+200h] [rbp-50h]
  RBX::TDigestNoLock *v51; // [rsp+208h] [rbp-48h]
  RBX::TDigestNoLock *v52; // [rsp+210h] [rbp-40h]
  RBX::TDigestNoLock *v53; // [rsp+218h] [rbp-38h]
  RBX::TDigestNoLock *v54; // [rsp+220h] [rbp-30h]

  *(_QWORD *)a1 = 0; /*0x105439787*/
  *(_DWORD *)(a1 + 8) = 0; /*0x10543978e*/
  v6 = (RBX::TDigestNoLock *)(a1 + 16); /*0x105439795*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 16)); /*0x10543979c*/
  *(_OWORD *)(a1 + 40) = 0; /*0x1054397a8*/
  *(_OWORD *)(a1 + 24) = 0; /*0x1054397ac*/
  v48 = (RBX::TDigestNoLock *)(a1 + 56); /*0x1054397b0*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 56)); /*0x1054397b4*/
  *(_OWORD *)(a1 + 92) = 0; /*0x1054397c0*/
  *(_OWORD *)(a1 + 80) = 0; /*0x1054397c4*/
  *(_OWORD *)(a1 + 64) = 0; /*0x1054397c8*/
  v47 = v6; /*0x1054397cf*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 112)); /*0x1054397d3*/
  *(_OWORD *)(a1 + 136) = 0; /*0x1054397e2*/
  *(_OWORD *)(a1 + 120) = 0; /*0x1054397e9*/
  v50 = (RBX::TDigestNoLock *)(a1 + 152); /*0x1054397ed*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 152)); /*0x1054397f1*/
  *(_OWORD *)(a1 + 256) = 0; /*0x105439800*/
  *(_OWORD *)(a1 + 240) = 0; /*0x105439807*/
  *(_OWORD *)(a1 + 224) = 0; /*0x10543980e*/
  *(_OWORD *)(a1 + 208) = 0; /*0x105439815*/
  *(_OWORD *)(a1 + 192) = 0; /*0x10543981c*/
  *(_OWORD *)(a1 + 176) = 0; /*0x105439823*/
  *(_OWORD *)(a1 + 160) = 0; /*0x10543982a*/
  *(_DWORD *)(a1 + 272) = 0; /*0x105439831*/
  v51 = (RBX::TDigestNoLock *)(a1 + 280); /*0x10543983b*/
  v49 = (RBX::TDigestNoLock *)(a1 + 112); /*0x10543983f*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 280)); /*0x105439843*/
  *(_OWORD *)(a1 + 304) = 0; /*0x105439852*/
  *(_OWORD *)(a1 + 288) = 0; /*0x105439859*/
  v52 = (RBX::TDigestNoLock *)(a1 + 320); /*0x105439860*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 320)); /*0x105439864*/
  *(_OWORD *)(a1 + 344) = 0; /*0x105439873*/
  *(_OWORD *)(a1 + 328) = 0; /*0x10543987a*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 360)); /*0x105439884*/
  *(_OWORD *)(a1 + 464) = 0; /*0x10543989a*/
  *(_OWORD *)(a1 + 448) = 0; /*0x1054398a1*/
  *(_OWORD *)(a1 + 432) = 0; /*0x1054398a8*/
  *(_OWORD *)(a1 + 416) = 0; /*0x1054398af*/
  *(_OWORD *)(a1 + 400) = 0; /*0x1054398b6*/
  *(_OWORD *)(a1 + 384) = 0; /*0x1054398bd*/
  *(_OWORD *)(a1 + 368) = 0; /*0x1054398c4*/
  *(_DWORD *)(a1 + 480) = 0; /*0x1054398cb*/
  v53 = (RBX::TDigestNoLock *)(a1 + 488); /*0x1054398d5*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 488)); /*0x1054398d9*/
  *(_OWORD *)(a1 + 512) = 0; /*0x1054398e8*/
  *(_OWORD *)(a1 + 496) = 0; /*0x1054398ef*/
  v54 = (RBX::TDigestNoLock *)(a1 + 528); /*0x1054398f6*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 528)); /*0x1054398fa*/
  *(_OWORD *)(a1 + 552) = 0; /*0x105439909*/
  *(_OWORD *)(a1 + 536) = 0; /*0x105439910*/
  v46 = (RBX::TDigestNoLock *)(a1 + 568); /*0x105439917*/
  RBX::TDigestNoLock::TDigestNoLock(this: (RBX::TDigestNoLock *)(a1 + 568)); /*0x10543991b*/
  *(_OWORD *)(a1 + 656) = 0; /*0x105439923*/
  *(_OWORD *)(a1 + 640) = 0; /*0x10543992a*/
  *(_OWORD *)(a1 + 624) = 0; /*0x105439931*/
  *(_OWORD *)(a1 + 608) = 0; /*0x105439938*/
  *(_OWORD *)(a1 + 592) = 0; /*0x10543993f*/
  *(_OWORD *)(a1 + 576) = 0; /*0x105439946*/
  RBX::Network::operator-(a1: (__int64)&v17, a2, a3); /*0x10543995a*/
  *(_DWORD *)(a1 + 8) = DWORD2(v17); /*0x105439965*/
  *(_QWORD *)a1 = v17; /*0x10543996f*/
  *(_OWORD *)(a1 + 24) = *(_OWORD *)&v18[8]; /*0x105439979*/
  *(_OWORD *)(a1 + 40) = *(_OWORD *)&v18[24]; /*0x105439984*/
  RBX::TDigestNoLock::reset(this: v47); /*0x10543998c*/
  *(_OWORD *)(a1 + 64) = v19; /*0x105439998*/
  *(_OWORD *)(a1 + 80) = *(_OWORD *)v20; /*0x1054399a3*/
  RBX::TDigestNoLock::reset(this: v48); /*0x1054399ab*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)&v18[40]); /*0x1054399b7*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v18); /*0x1054399c3*/
  RBX::Network::operator-(a1: (__int64)&v17, a2: a2 + 96, a3: a3 + 6); /*0x1054399d8*/
  *(_DWORD *)(a1 + 104) = DWORD2(v17); /*0x1054399e7*/
  *(_QWORD *)(a1 + 96) = v17; /*0x1054399f1*/
  *(_OWORD *)(a1 + 120) = *(_OWORD *)&v18[8]; /*0x1054399fb*/
  *(_OWORD *)(a1 + 136) = *(_OWORD *)&v18[24]; /*0x105439a06*/
  RBX::TDigestNoLock::reset(this: v49); /*0x105439a11*/
  *(_OWORD *)(a1 + 160) = v19; /*0x105439a1d*/
  *(_OWORD *)(a1 + 176) = *(_OWORD *)v20; /*0x105439a2b*/
  RBX::TDigestNoLock::reset(this: v50); /*0x105439a36*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)&v18[40]); /*0x105439a42*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v18); /*0x105439a4e*/
  RBX::Network::operator-(a1: (__int64)&v17, a2: a2 + 192, a3: (__int64)a3[12].i64); /*0x105439a6b*/
  *(_DWORD *)(a1 + 272) = v20[0]; /*0x105439a76*/
  *(_OWORD *)(a1 + 256) = v19; /*0x105439a81*/
  v7 = v17; /*0x105439a86*/
  v8 = *(_OWORD *)v18; /*0x105439a8d*/
  v9 = *(_OWORD *)&v18[16]; /*0x105439a94*/
  *(_OWORD *)(a1 + 240) = *(_OWORD *)&v18[32]; /*0x105439aa2*/
  *(_OWORD *)(a1 + 224) = v9; /*0x105439aa7*/
  *(_OWORD *)(a1 + 208) = v8; /*0x105439aac*/
  *(_OWORD *)(a1 + 192) = v7; /*0x105439ab1*/
  *(_OWORD *)(a1 + 288) = *(_OWORD *)&v20[2]; /*0x105439abc*/
  *(_OWORD *)(a1 + 304) = *(_OWORD *)&v20[4]; /*0x105439aca*/
  RBX::TDigestNoLock::reset(this: v51); /*0x105439ad5*/
  *(_OWORD *)(a1 + 328) = v22; /*0x105439ae1*/
  *(_OWORD *)(a1 + 344) = v23; /*0x105439aef*/
  RBX::TDigestNoLock::reset(this: v52); /*0x105439afa*/
  *(_OWORD *)(a1 + 368) = v25; /*0x105439b06*/
  *(_OWORD *)(a1 + 384) = v26; /*0x105439b14*/
  RBX::TDigestNoLock::reset(this: (RBX::TDigestNoLock *)(a1 + 360)); /*0x105439b1e*/
  *(_DWORD *)(a1 + 480) = v32; /*0x105439b30*/
  *(_OWORD *)(a1 + 464) = v31; /*0x105439b3a*/
  v10 = v27; /*0x105439b3e*/
  v11 = v28; /*0x105439b45*/
  v12 = v29; /*0x105439b4c*/
  *(_OWORD *)(a1 + 448) = v30; /*0x105439b5a*/
  *(_OWORD *)(a1 + 432) = v12; /*0x105439b5e*/
  *(_OWORD *)(a1 + 416) = v11; /*0x105439b62*/
  *(_OWORD *)(a1 + 400) = v10; /*0x105439b66*/
  *(_OWORD *)(a1 + 496) = v34; /*0x105439b70*/
  *(_OWORD *)(a1 + 512) = v35; /*0x105439b7e*/
  RBX::TDigestNoLock::reset(this: v53); /*0x105439b89*/
  *(_OWORD *)(a1 + 536) = v37; /*0x105439b95*/
  *(_OWORD *)(a1 + 552) = v38; /*0x105439ba3*/
  RBX::TDigestNoLock::reset(this: v54); /*0x105439bae*/
  *(_OWORD *)(a1 + 576) = v40; /*0x105439bba*/
  *(_OWORD *)(a1 + 592) = v41; /*0x105439bc8*/
  RBX::TDigestNoLock::reset(this: v46); /*0x105439bd3*/
  v13 = v42; /*0x105439bdf*/
  v14 = v43; /*0x105439be3*/
  v15 = v44; /*0x105439be7*/
  *(_OWORD *)(a1 + 656) = v45; /*0x105439bef*/
  *(_OWORD *)(a1 + 640) = v15; /*0x105439bf6*/
  *(_OWORD *)(a1 + 624) = v14; /*0x105439bfd*/
  *(_OWORD *)(a1 + 608) = v13; /*0x105439c04*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v39); /*0x105439c0b*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v36); /*0x105439c17*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v33); /*0x105439c23*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v24); /*0x105439c2f*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)v21); /*0x105439c3b*/
  RBX::TDigestNoLock::~TDigestNoLock(this: (RBX::TDigestNoLock *)&v20[1]); /*0x105439c47*/
  return a1; /*0x105439c4f*/
}

// Address: 0x105439e07 | Name: __ZN3RBX7NetworkmiERKNS0_42LargeReplicatorNetworkStatsVictoriaMetricsES3_
__int64 __fastcall RBX::Network::operator-(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax

  result = a1; /*0x105439e0b*/
  *(_DWORD *)(a1 + 16) = 0; /*0x105439e0e*/
  *(__m128i *)a1 = _mm_sub_epi32(_mm_loadu_si128((const __m128i *)a2), _mm_loadu_si128((const __m128i *)a3)); /*0x105439e21*/
  if ( FFlag::LrRegisterCachedAssetInReceiver == 1 ) /*0x105439e2f*/
    *(_DWORD *)(a1 + 16) = *(_DWORD *)(a2 + 16) - *(_DWORD *)(a3 + 16); /*0x105439e37*/
  *(__m128i *)(a1 + 20) = _mm_sub_epi32( /*0x105439e48*/
                            _mm_loadu_si128((const __m128i *)(a2 + 20)),
                            _mm_loadu_si128((const __m128i *)(a3 + 20)));
  return result; /*0x105439e4d*/
}

// Address: 0x105ab1f00 | Name: __ZN3RBXL10newMotor6DEv
RBX *__fastcall RBX::newMotor6D(RBX *this)
{
  __int64 v2; // r14
  __int64 v3; // r15
  _QWORD v5[7]; // [rsp+18h] [rbp-38h] BYREF

  RBX::EngineContext::getThreadLocal(this); /*0x105ab1f10*/
  RBX::Creatable::createImpl<RBX::Motor6D,RBX::ForceConstructionInCreatable &>(a1: v5); /*0x105ab1f2a*/
  v2 = v5[0]; /*0x105ab1f2f*/
  v3 = v5[1]; /*0x105ab1f32*/
  v5[2] = v5[0]; /*0x105ab1f36*/
  v5[3] = v5[1]; /*0x105ab1f3a*/
  (*(void (__fastcall **)(_QWORD, float))(*(_QWORD *)v5[0] + 696LL))(a1: v5[0], a2: 0.1); /*0x105ab1f4c*/
  *(_QWORD *)this = v2; /*0x105ab1f52*/
  *((_QWORD *)this + 1) = v3; /*0x105ab1f55*/
  return this; /*0x105ab1f5c*/
}

// Address: 0x105c474ee | Name: __ZN3RBX9neatFloatEf
RBX *__fastcall RBX::neatFloat(
        RBX *this,
        __m128 a2,
        __m128 a3,
        __m128 a4,
        __m128 a5,
        __m128 a6,
        __m128 a7,
        __m128 a8,
        __m128 a9,
        __int64 a10,
        __int64 a11,
        __int64 a12,
        __int64 a13,
        __int64 a14)
{
  char v14; // al

  *(double *)a2.i64 = a2.f32[0]; /*0x105c474f7*/
  RBX::format( /*0x105c47504*/
    this,
    a2: "%.4f",
    a3: a11,
    a4: a12,
    a5: a13,
    a6: a14,
    a7: a2,
    a8: a3,
    a9: a4,
    a10: a5,
    a11: a6,
    a12: a7,
    a13: a8,
    a14: a9,
    a15: v14);
  return this; /*0x105c47510*/
}

// Address: 0x105f2e3ce | Name: __ZN3RBX19networkStatsVisibleEPNS_9DataModelE
char __fastcall RBX::networkStatsVisible(RBX *this, RBX::DataModel *a2)
{
  RBX::GuiItem *v2; // rbx
  __int64 FirstChildByName; // rax
  __int64 v4; // rax
  char v5; // r14
  __int64 v6; // rax
  __int64 v7; // rax

  v2 = (RBX::GuiItem *)(*(__int64 (__fastcall **)(_QWORD, RBX::DataModel *))(**((_QWORD **)this + 275) + 40LL))( /*0x105f2e3e2*/
                         a1: *((_QWORD *)this + 275),
                         a2);
  FirstChildByName = RBX::GuiItem::findFirstChildByName(this: v2, a2: "NetworkStats"); /*0x105f2e3ef*/
  v4 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)FirstChildByName + 96LL))(a1: FirstChildByName); /*0x105f2e3fa*/
  v5 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 40LL))(a1: v4); /*0x105f2e406*/
  v6 = RBX::GuiItem::findFirstChildByName(this: v2, a2: "NetworkStats2"); /*0x105f2e413*/
  v7 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v6 + 96LL))(a1: v6); /*0x105f2e41e*/
  return v5 & (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v7 + 40LL))(a1: v7); /*0x105f2e42d*/
}

// Address: 0x1062be5a2 | Name: __ZN3RBXL14newSealedTableERN4Luau9TypeArenaENSt3__18optionalIPKcEE
Luau *__fastcall RBX::newSealedTable(__int64 a1, __int64 a2, char a3)
{
  Luau *v5; // rbx
  const Luau::Type *v6; // rsi
  _DWORD *v7; // rax
  _DWORD *v8; // r14
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // rax
  const Luau::Type *v12; // rsi
  __int64 v13; // rax
  void *v14; // rsi
  _BYTE v16[280]; // [rsp+8h] [rbp-178h] BYREF
  __int64 v17; // [rsp+120h] [rbp-60h] BYREF
  char v18; // [rsp+128h] [rbp-58h]
  __int128 v19; // [rsp+130h] [rbp-50h] BYREF
  void *v20; // [rsp+140h] [rbp-40h]
  char v21; // [rsp+148h] [rbp-38h]
  __int128 *v22; // [rsp+150h] [rbp-30h] BYREF
  __int128 v23; // [rsp+158h] [rbp-28h] BYREF

  v17 = a2; /*0x1062be5b8*/
  v18 = a3; /*0x1062be5bc*/
  v23 = 0; /*0x1062be5c7*/
  v22 = &v23; /*0x1062be5ca*/
  LOBYTE(v19) = 0; /*0x1062be5d4*/
  v21 = 0; /*0x1062be5d6*/
  Luau::TableType::TableType(a1: v16, a2: &v22, a3: &v19, a4: 0, a5: 0); /*0x1062be5e9*/
  v5 = (Luau *)Luau::TypeArena::addType<Luau::TableType>(a1, a2: v16); /*0x1062be5fd*/
  Luau::TableType::~TableType(this: (Luau::TableType *)v16); /*0x1062be607*/
  std::__tree<std::__value_type<std::string,Luau::Property>,std::__map_value_compare<std::string,std::__value_type<std::string,Luau::Property>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,Luau::Property>>>::destroy( /*0x1062be614*/
    a1: &v22,
    a2: v23);
  v7 = (_DWORD *)Luau::asMutable(this: v5, a2: v6); /*0x1062be61c*/
  if ( v7 != nullptr ) /*0x1062be624*/
  {
    v8 = nullptr; /*0x1062be62d*/
    if ( *v7 == 9 ) /*0x1062be633*/
      v8 = v7 + 4; /*0x1062be633*/
  }
  else
  {
    v8 = nullptr; /*0x1062be639*/
  }
  if ( (a3 & 1) != 0 ) /*0x1062be640*/
  {
    std::optional<std::string>::operator=[abi:ne200100]<char const*&,void>(a1: v8 + 20, a2: &v17); /*0x1062be651*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v22, a2: v17, a3: v9, a4: v10); /*0x1062be660*/
    v11 = std::string::insert(a1: &v22, a2: 0, a3: "@roblox/globaltype/"); /*0x1062be671*/
    v20 = *(void **)(v11 + 16); /*0x1062be67a*/
    v19 = *(_OWORD *)v11; /*0x1062be681*/
    *(_OWORD *)v11 = 0; /*0x1062be688*/
    *(_QWORD *)(v11 + 16) = 0; /*0x1062be68b*/
    v13 = Luau::asMutable(this: v5, a2: v12); /*0x1062be696*/
    std::optional<std::string>::operator=[abi:ne200100]<std::string,void>(a1: v13 + 312, a2: &v19); /*0x1062be6a8*/
    if ( (v19 & 1) != 0 ) /*0x1062be6b1*/
      operator delete(a1: (RBX::Memory *)v20, a2: v14); /*0x1062be6b7*/
    if ( ((unsigned __int8)v22 & 1) != 0 ) /*0x1062be6c0*/
      operator delete(a1: *((RBX::Memory **)&v23 + 1), a2: v14); /*0x1062be6c6*/
  }
  return v5; /*0x1062be6d1*/
}

// Address: 0x1062bf9c1 | Name: __ZN3RBXL8newClassERN4Luau9TypeArenaERNS0_12BuiltinTypesERKNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS5_8optionalIPKNS0_4TypeEEESI_NSE_INS0_12TableIndexerEEE
Luau *__fastcall RBX::newClass(
        __int64 a1,
        __int64 a2,
        __int128 *a3,
        __int64 a4,
        char a5,
        _DWORD a6,
        __int128 a7,
        __int128 a8,
        __int128 a9)
{
  __int64 v9; // r15
  char v12; // r12
  void *v13; // rsi
  Luau *v14; // r14
  std::__shared_weak_count *v15; // r12
  void *v16; // rsi
  void *v17; // rsi
  const Luau::Type *v18; // rsi
  __int64 v19; // rax
  void *v20; // rsi
  __int128 *v22; // [rsp+18h] [rbp-198h] BYREF
  __int128 v23; // [rsp+20h] [rbp-190h] BYREF
  _QWORD v24[3]; // [rsp+30h] [rbp-180h] BYREF
  void *v25[3]; // [rsp+48h] [rbp-168h] BYREF
  __int128 v26; // [rsp+60h] [rbp-150h] BYREF
  void *v27; // [rsp+70h] [rbp-140h]
  __int128 v28; // [rsp+80h] [rbp-130h] BYREF
  void *v29; // [rsp+90h] [rbp-120h]
  __int128 v30; // [rsp+A0h] [rbp-110h]
  void *v31; // [rsp+B0h] [rbp-100h]
  __int128 *v32; // [rsp+B8h] [rbp-F8h] BYREF
  __int128 v33; // [rsp+C0h] [rbp-F0h] BYREF
  __int64 v34; // [rsp+D0h] [rbp-E0h]
  char v35; // [rsp+D8h] [rbp-D8h]
  __int128 v36; // [rsp+E0h] [rbp-D0h]
  _BYTE v37[24]; // [rsp+F0h] [rbp-C0h] BYREF
  __int128 v38; // [rsp+108h] [rbp-A8h]
  __int128 v39; // [rsp+118h] [rbp-98h]
  void *v40; // [rsp+128h] [rbp-88h]
  char v41; // [rsp+130h] [rbp-80h]
  char v42; // [rsp+140h] [rbp-70h]
  __int128 v43; // [rsp+148h] [rbp-68h]
  __int128 v44; // [rsp+158h] [rbp-58h]
  int v45; // [rsp+168h] [rbp-48h]
  char v46; // [rsp+178h] [rbp-38h]

  v9 = a4; /*0x1062bf9d5*/
  if ( (a5 & 1) == 0 ) /*0x1062bf9f0*/
    v9 = *(_QWORD *)(a2 + 88); /*0x1062bf9f0*/
  v12 = 1; /*0x1062bf9f5*/
  if ( (a5 & 1) != 0 ) /*0x1062bf9fb*/
    v12 = a5; /*0x1062bf9fb*/
  if ( (*(_BYTE *)a3 & 1) != 0 ) /*0x1062bfa02*/
  {
    std::string::__init_copy_ctor_external(a1: &v28, a2: *((_QWORD *)a3 + 2), a3: *((_QWORD *)a3 + 1)); /*0x1062bfa2a*/
  }
  else
  {
    v29 = *((void **)a3 + 2); /*0x1062bfa08*/
    v28 = *a3; /*0x1062bfa12*/
  }
  v23 = 0; /*0x1062bfa39*/
  v22 = &v23; /*0x1062bfa3e*/
  memset(v24, 0, sizeof(v24)); /*0x1062bfa42*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v26, a2: "Roblox", a3, a4); /*0x1062bfa69*/
  v31 = v29; /*0x1062bfa84*/
  v30 = v28; /*0x1062bfa8f*/
  v28 = 0; /*0x1062bfa96*/
  v29 = nullptr; /*0x1062bfa9d*/
  v32 = &v23; /*0x1062bfab6*/
  v33 = v23; /*0x1062bfaba*/
  if ( *((_QWORD *)&v23 + 1) != 0 ) /*0x1062bfacb*/
  {
    *(_QWORD *)(v23 + 16) = &v33; /*0x1062bfacd*/
    v22 = &v23; /*0x1062bfad1*/
    v23 = 0; /*0x1062bfad8*/
  }
  else
  {
    v32 = &v33; /*0x1062bfadf*/
  }
  v34 = v9; /*0x1062bfaed*/
  v35 = v12; /*0x1062bfaf1*/
  v36 = a7; /*0x1062bfaf8*/
  qmemcpy(v37, v24, sizeof(v37)); /*0x1062bfb03*/
  memset(v24, 0, sizeof(v24)); /*0x1062bfb15*/
  v38 = 0; /*0x1062bfb25*/
  v39 = v26; /*0x1062bfb37*/
  v40 = v27; /*0x1062bfb42*/
  v26 = 0; /*0x1062bfb49*/
  v27 = nullptr; /*0x1062bfb50*/
  v41 = 0; /*0x1062bfb57*/
  v42 = 0; /*0x1062bfb5d*/
  v44 = a9; /*0x1062bfb6a*/
  v43 = a8; /*0x1062bfb71*/
  LOBYTE(v45) = 0; /*0x1062bfb78*/
  v46 = 0; /*0x1062bfb7e*/
  v14 = (Luau *)Luau::TypeArena::addType<Luau::ExternType>(a1); /*0x1062bfb8c*/
  if ( v46 == 1 ) /*0x1062bfb93*/
    Luau::Variant<Luau::Obj,Luau::Klass>::tableDtor[v45](); /*0x1062bfba4*/
  if ( (v39 & 1) != 0 ) /*0x1062bfbae*/
    operator delete(a1: (RBX::Memory *)v40, a2: v13); /*0x1062bfbb7*/
  v15 = *((std::__shared_weak_count **)&v38 + 1); /*0x1062bfbca*/
  if ( *((_QWORD *)&v38 + 1) != 0 /*0x1062bfbe4*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v38 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x1062bfbed*/
    std::__shared_weak_count::__release_weak(this: v15); /*0x1062bfbf3*/
  }
  v25[0] = v37; /*0x1062bfbff*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: v25); /*0x1062bfc02*/
  std::__tree<std::__value_type<std::string,Luau::Property>,std::__map_value_compare<std::string,std::__value_type<std::string,Luau::Property>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,Luau::Property>>>::destroy( /*0x1062bfc11*/
    a1: &v32,
    a2: v33);
  if ( (v30 & 1) != 0 ) /*0x1062bfc1d*/
    operator delete(a1: (RBX::Memory *)v31, a2: v16); /*0x1062bfc26*/
  if ( (v26 & 1) != 0 ) /*0x1062bfc32*/
    operator delete(a1: (RBX::Memory *)v27, a2: v16); /*0x1062bfc3b*/
  v25[0] = v24; /*0x1062bfc7d*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: v25); /*0x1062bfc80*/
  std::__tree<std::__value_type<std::string,Luau::Property>,std::__map_value_compare<std::string,std::__value_type<std::string,Luau::Property>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,Luau::Property>>>::destroy( /*0x1062bfc90*/
    a1: &v22,
    a2: v23);
  if ( (v28 & 1) != 0 ) /*0x1062bfc9c*/
    operator delete(a1: (RBX::Memory *)v29, a2: v17); /*0x1062bfca5*/
  Luau::asMutable(this: v14, a2: (const Luau::Type *)v17); /*0x1062bfcad*/
  std::operator+<char>(a1: v25, a2: "@roblox/globaltype/", a3); /*0x1062bfcde*/
  v19 = Luau::asMutable(this: v14, a2: v18); /*0x1062bfce6*/
  std::optional<std::string>::operator=[abi:ne200100]<std::string,void>(a1: v19 + 312, a2: v25); /*0x1062bfcfb*/
  if ( ((__int64)v25[0] & 1) != 0 ) /*0x1062bfd07*/
    operator delete(a1: (RBX::Memory *)v25[2], a2: v20); /*0x1062bfd10*/
  return v14; /*0x1062bfd2f*/
}

// Address: 0x10695e654 | Name: __ZN3RBX7NetworklsERNSt3__113basic_ostreamIcNS1_11char_traitsIcEEEERKNS0_14NetworkObjects5GroupE
__int64 __fastcall RBX::Network::operator<<(__int64 a1, RBX::Network::NetworkObjects::Group *a2)
{
  RBX::Network::InstanceObjectManager *Root; // rax
  const RBX::Network::NetworkObject *v5; // rsi
  __int64 Instance; // rax
  __int64 v7; // rax
  __int64 v8; // rsi
  _BYTE *v9; // rdx
  __int64 v10; // r9
  _BYTE *v11; // rdi
  char *v12; // rsi
  __int64 v13; // rdx
  __int64 v14; // rbx
  void *v15; // rsi
  _QWORD v17[6]; // [rsp+0h] [rbp-90h] BYREF
  unsigned __int8 v18; // [rsp+30h] [rbp-60h] BYREF
  _BYTE v19[15]; // [rsp+31h] [rbp-5Fh] BYREF
  void *v20; // [rsp+40h] [rbp-50h]
  unsigned __int8 v21; // [rsp+48h] [rbp-48h] BYREF
  _BYTE v22[15]; // [rsp+49h] [rbp-47h] BYREF
  void *v23; // [rsp+58h] [rbp-38h]
  unsigned __int8 v24; // [rsp+60h] [rbp-30h] BYREF
  char v25; // [rsp+61h] [rbp-2Fh] BYREF
  __int64 v26; // [rsp+68h] [rbp-28h]
  void *v27; // [rsp+70h] [rbp-20h]
  __int16 GroupType; // [rsp+7Eh] [rbp-12h]

  Root = (RBX::Network::InstanceObjectManager *)RBX::Network::NetworkObjects::Group::getRoot(this: a2); /*0x10695e66b*/
  Instance = RBX::Network::InstanceObjectManager::getInstance(this: Root, a2: v5); /*0x10695e673*/
  (*(void (__fastcall **)(unsigned __int8 *, __int64))(*(_QWORD *)Instance + 184LL))(a1: &v18, a2: Instance); /*0x10695e682*/
  GroupType = RBX::Network::NetworkObjects::Group::getGroupType(this: a2); /*0x10695e694*/
  RBX::Network::NetworkObjects::toString<RBX::Network::NetworkObjects::TypeBits>(a1: &v21); /*0x10695e69b*/
  v7 = (int)((*((_QWORD *)a2 + 5) - *((_QWORD *)a2 + 4)) >> 3); /*0x10695e6ac*/
  v8 = v18 >> 1; /*0x10695e6b8*/
  v9 = v20; /*0x10695e6bd*/
  if ( (v18 & 1) != 0 ) /*0x10695e6c1*/
    v8 = *(_QWORD *)&v19[7]; /*0x10695e6c5*/
  else
    v9 = v19; /*0x10695e6c1*/
  v10 = v21 >> 1; /*0x10695e6d5*/
  v11 = v23; /*0x10695e6dc*/
  if ( (v21 & 1) != 0 ) /*0x10695e6e0*/
    v10 = *(_QWORD *)&v22[7]; /*0x10695e6e0*/
  else
    v11 = v22; /*0x10695e6e5*/
  v17[0] = v9; /*0x10695e6f0*/
  v17[1] = v8; /*0x10695e6f3*/
  v17[2] = v11; /*0x10695e6f7*/
  v17[3] = v10; /*0x10695e6fb*/
  v17[4] = v7; /*0x10695e6ff*/
  fmt::v8::vformat(a1: &v24, a2: "(root={}, type={}, size={})", 27, 1245, v17, v10); /*0x10695e718*/
  if ( (v24 & 1) != 0 ) /*0x10695e724*/
  {
    v12 = (char *)v27; /*0x10695e726*/
    v13 = v26; /*0x10695e72a*/
  }
  else
  {
    v13 = v24 >> 1; /*0x10695e730*/
    v12 = &v25; /*0x10695e732*/
  }
  v14 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1, a2: v12, a3: v13); /*0x10695e73e*/
  if ( (v24 & 1) != 0 ) /*0x10695e745*/
    operator delete(a1: (RBX::Memory *)v27, a2: v15); /*0x10695e74b*/
  if ( (v21 & 1) != 0 ) /*0x10695e754*/
    operator delete(a1: (RBX::Memory *)v23, a2: v15); /*0x10695e75a*/
  if ( (v18 & 1) != 0 ) /*0x10695e763*/
    operator delete(a1: (RBX::Memory *)v20, a2: v15); /*0x10695e769*/
  return v14; /*0x10695e771*/
}

// Address: 0x107385730 | Name: __ZN3RBXL20notTooMuchWhitespaceERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
unsigned __int8 *__fastcall RBX::notTooMuchWhitespace(unsigned __int8 *a1, __int64 a2)
{
  unsigned int v3; // edx
  unsigned __int8 *v4; // r14
  unsigned __int8 *v5; // rsi
  __int64 v6; // rdx
  void *v7; // rsi
  unsigned int v8; // edx
  unsigned __int8 *v9; // rsi
  __int64 v10; // rdx
  void *v11; // rsi
  unsigned int v12; // edx
  __int64 v13; // rdx
  void *v14; // rsi
  std::__shared_weak_count *v15; // r14
  std::__shared_weak_count *v16; // r14
  std::__shared_weak_count *v17; // r14
  _BYTE v19[48]; // [rsp+0h] [rbp-F0h] BYREF
  std::__shared_weak_count *v20; // [rsp+30h] [rbp-C0h]
  __int128 v21; // [rsp+40h] [rbp-B0h] BYREF
  __int64 v22; // [rsp+50h] [rbp-A0h]
  std::__shared_weak_count *v23; // [rsp+70h] [rbp-80h]
  __int128 v24; // [rsp+80h] [rbp-70h] BYREF
  __int64 v25; // [rsp+90h] [rbp-60h]
  std::__shared_weak_count *v26; // [rsp+B0h] [rbp-40h]
  __int128 v27; // [rsp+C0h] [rbp-30h] BYREF
  __int64 v28; // [rsp+D0h] [rbp-20h]

  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x107385744*/
  {
    std::string::__init_copy_ctor_external(a1, a2: *(_QWORD *)(a2 + 16), a3: *(_QWORD *)(a2 + 8)); /*0x107385761*/
  }
  else
  {
    *((_QWORD *)a1 + 2) = *(_QWORD *)(a2 + 16); /*0x10738574a*/
    *(_OWORD *)a1 = *(_OWORD *)a2; /*0x107385751*/
  }
  std::basic_regex<char,std::regex_traits<char>>::basic_regex[abi:ne200100](a1: v19, a2: "\t", a3: 0); /*0x107385776*/
  v21 = 0; /*0x10738577e*/
  v22 = 0; /*0x107385785*/
  v3 = *a1; /*0x107385790*/
  v4 = a1 + 1; /*0x107385793*/
  if ( (v3 & 1) != 0 ) /*0x10738579a*/
  {
    v5 = *((unsigned __int8 **)a1 + 2); /*0x10738579c*/
    v6 = *((_QWORD *)a1 + 1); /*0x1073857a0*/
  }
  else
  {
    v6 = v3 >> 1; /*0x1073857a6*/
    v5 = a1 + 1; /*0x1073857a8*/
  }
  std::regex_replace[abi:ne200100]<std::back_insert_iterator<std::string>,std::__wrap_iter<char const*>,std::regex_traits<char>,char>( /*0x1073857c6*/
    a1: &v21,
    a2: v5,
    a3: &v5[v6],
    a4: v19,
    a5: "   ",
    a6: 0);
  if ( (*a1 & 1) != 0 ) /*0x1073857ce*/
    operator delete(a1: *((RBX::Memory **)a1 + 2), a2: v7); /*0x1073857d4*/
  *((_QWORD *)a1 + 2) = v22; /*0x1073857e4*/
  *(_OWORD *)a1 = v21; /*0x1073857eb*/
  std::basic_regex<char,std::regex_traits<char>>::basic_regex[abi:ne200100](a1: &v21, a2: " {3,}", a3: 0); /*0x1073857f7*/
  v24 = 0; /*0x1073857ff*/
  v25 = 0; /*0x107385803*/
  v8 = *a1; /*0x10738580b*/
  if ( (v8 & 1) != 0 ) /*0x107385811*/
  {
    v9 = *((unsigned __int8 **)a1 + 2); /*0x107385813*/
    v10 = *((_QWORD *)a1 + 1); /*0x107385817*/
  }
  else
  {
    v10 = v8 >> 1; /*0x10738581d*/
    v9 = a1 + 1; /*0x10738581f*/
  }
  std::regex_replace[abi:ne200100]<std::back_insert_iterator<std::string>,std::__wrap_iter<char const*>,std::regex_traits<char>,char>( /*0x10738583a*/
    a1: &v24,
    a2: v9,
    a3: &v9[v10],
    a4: &v21,
    a5: "   ",
    a6: 0);
  if ( (*a1 & 1) != 0 ) /*0x107385842*/
    operator delete(a1: *((RBX::Memory **)a1 + 2), a2: v11); /*0x107385848*/
  *((_QWORD *)a1 + 2) = v25; /*0x107385855*/
  *(_OWORD *)a1 = v24; /*0x10738585c*/
  std::basic_regex<char,std::regex_traits<char>>::basic_regex[abi:ne200100](a1: &v24, a2: "\n{3,}", a3: 0); /*0x107385868*/
  v27 = 0; /*0x107385870*/
  v28 = 0; /*0x107385874*/
  v12 = *a1; /*0x10738587c*/
  if ( (v12 & 1) != 0 ) /*0x107385882*/
  {
    v4 = *((unsigned __int8 **)a1 + 2); /*0x107385884*/
    v13 = *((_QWORD *)a1 + 1); /*0x107385888*/
  }
  else
  {
    v13 = v12 >> 1; /*0x10738588e*/
  }
  std::regex_replace[abi:ne200100]<std::back_insert_iterator<std::string>,std::__wrap_iter<char const*>,std::regex_traits<char>,char>( /*0x1073858a8*/
    a1: &v27,
    a2: v4,
    a3: &v4[v13],
    a4: &v24,
    a5: "\n\n\n",
    a6: 0);
  if ( (*a1 & 1) != 0 ) /*0x1073858b0*/
    operator delete(a1: *((RBX::Memory **)a1 + 2), a2: v14); /*0x1073858b6*/
  *((_QWORD *)a1 + 2) = v28; /*0x1073858bf*/
  *(_OWORD *)a1 = v27; /*0x1073858c7*/
  v15 = v26; /*0x1073858ca*/
  if ( v26 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v26 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1073858e3*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x1073858eb*/
    std::__shared_weak_count::__release_weak(this: v15); /*0x1073858f1*/
  }
  std::locale::~locale(this: (std::locale *)&v24); /*0x1073858fa*/
  v16 = v23; /*0x1073858ff*/
  if ( v23 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v23 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107385918*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x107385920*/
    std::__shared_weak_count::__release_weak(this: v16); /*0x107385926*/
  }
  std::locale::~locale(this: (std::locale *)&v21); /*0x107385932*/
  v17 = v20; /*0x107385937*/
  if ( v20 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v20 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107385953*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x10738595b*/
    std::__shared_weak_count::__release_weak(this: v17); /*0x107385961*/
  }
  std::locale::~locale(this: (std::locale *)v19); /*0x10738596d*/
  return a1; /*0x107385975*/
}

// Address: 0x107385a28 | Name: __ZN3RBXL10noNewLinesERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
unsigned __int8 *__fastcall RBX::noNewLines(unsigned __int8 *a1, __int64 a2)
{
  __int64 v2; // rax
  __int64 v4; // r12
  char *v5; // r13
  char v6; // al
  char v8[41]; // [rsp+1h] [rbp-29h] BYREF

  v8[0] = HIBYTE(v2); /*0x107385a35*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x107385a3c*/
  {
    std::string::__init_copy_ctor_external(a1, a2: *(_QWORD *)(a2 + 16), a3: *(_QWORD *)(a2 + 8)); /*0x107385a59*/
  }
  else
  {
    *((_QWORD *)a1 + 2) = *(_QWORD *)(a2 + 16); /*0x107385a42*/
    *(_OWORD *)a1 = *(_OWORD *)a2; /*0x107385a49*/
  }
  v4 = (__int64)&a1[(*a1 >> 1) + 1]; /*0x107385a72*/
  if ( (*a1 & 1) != 0 ) /*0x107385a77*/
    v4 = *((_QWORD *)a1 + 2) + *((_QWORD *)a1 + 1); /*0x107385a77*/
  v5 = (char *)(a1 + 1); /*0x107385a7b*/
  if ( (*a1 & 1) != 0 ) /*0x107385a7f*/
    v5 = *((char **)a1 + 2); /*0x107385a7f*/
  for ( ; v5 != (char *)v4; ++v5 ) /*0x107385a86*/
  {
    v8[0] = *v5; /*0x107385a97*/
    if ( std::__hash_table<char,std::hash<char>,std::equal_to<char>,std::allocator<char>>::find<char>( /*0x107385aa8*/
           a1: &RBX::kWhitespaceChars,
           a2: v8) != 0 )
      v6 = 32; /*0x107385aaa*/
    else
      v6 = v8[0]; /*0x107385ab1*/
    *v5 = v6; /*0x107385ab5*/
  }
  return a1; /*0x107385ac8*/
}

// Address: 0x107391b5e | Name: __ZN3RBXL20notTooMuchWhitespaceERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE_0
unsigned __int8 *__fastcall RBX::notTooMuchWhitespace(unsigned __int8 *a1, __int64 a2)
{
  unsigned int v3; // edx
  unsigned __int8 *v4; // r14
  unsigned __int8 *v5; // rsi
  __int64 v6; // rdx
  void *v7; // rsi
  unsigned int v8; // edx
  unsigned __int8 *v9; // rsi
  __int64 v10; // rdx
  void *v11; // rsi
  unsigned int v12; // edx
  __int64 v13; // rdx
  void *v14; // rsi
  std::__shared_weak_count *v15; // r14
  std::__shared_weak_count *v16; // r14
  std::__shared_weak_count *v17; // r14
  _BYTE v19[48]; // [rsp+0h] [rbp-F0h] BYREF
  std::__shared_weak_count *v20; // [rsp+30h] [rbp-C0h]
  __int128 v21; // [rsp+40h] [rbp-B0h] BYREF
  __int64 v22; // [rsp+50h] [rbp-A0h]
  std::__shared_weak_count *v23; // [rsp+70h] [rbp-80h]
  __int128 v24; // [rsp+80h] [rbp-70h] BYREF
  __int64 v25; // [rsp+90h] [rbp-60h]
  std::__shared_weak_count *v26; // [rsp+B0h] [rbp-40h]
  __int128 v27; // [rsp+C0h] [rbp-30h] BYREF
  __int64 v28; // [rsp+D0h] [rbp-20h]

  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x107391b72*/
  {
    std::string::__init_copy_ctor_external(a1, a2: *(_QWORD *)(a2 + 16), a3: *(_QWORD *)(a2 + 8)); /*0x107391b8f*/
  }
  else
  {
    *((_QWORD *)a1 + 2) = *(_QWORD *)(a2 + 16); /*0x107391b78*/
    *(_OWORD *)a1 = *(_OWORD *)a2; /*0x107391b7f*/
  }
  std::basic_regex<char,std::regex_traits<char>>::basic_regex[abi:ne200100](a1: v19, a2: "\t", a3: 0); /*0x107391ba4*/
  v21 = 0; /*0x107391bac*/
  v22 = 0; /*0x107391bb3*/
  v3 = *a1; /*0x107391bbe*/
  v4 = a1 + 1; /*0x107391bc1*/
  if ( (v3 & 1) != 0 ) /*0x107391bc8*/
  {
    v5 = *((unsigned __int8 **)a1 + 2); /*0x107391bca*/
    v6 = *((_QWORD *)a1 + 1); /*0x107391bce*/
  }
  else
  {
    v6 = v3 >> 1; /*0x107391bd4*/
    v5 = a1 + 1; /*0x107391bd6*/
  }
  std::regex_replace[abi:ne200100]<std::back_insert_iterator<std::string>,std::__wrap_iter<char const*>,std::regex_traits<char>,char>( /*0x107391bf4*/
    a1: &v21,
    a2: v5,
    a3: &v5[v6],
    a4: v19,
    a5: "   ",
    a6: 0);
  if ( (*a1 & 1) != 0 ) /*0x107391bfc*/
    operator delete(a1: *((RBX::Memory **)a1 + 2), a2: v7); /*0x107391c02*/
  *((_QWORD *)a1 + 2) = v22; /*0x107391c12*/
  *(_OWORD *)a1 = v21; /*0x107391c19*/
  std::basic_regex<char,std::regex_traits<char>>::basic_regex[abi:ne200100](a1: &v21, a2: " {3,}", a3: 0); /*0x107391c25*/
  v24 = 0; /*0x107391c2d*/
  v25 = 0; /*0x107391c31*/
  v8 = *a1; /*0x107391c39*/
  if ( (v8 & 1) != 0 ) /*0x107391c3f*/
  {
    v9 = *((unsigned __int8 **)a1 + 2); /*0x107391c41*/
    v10 = *((_QWORD *)a1 + 1); /*0x107391c45*/
  }
  else
  {
    v10 = v8 >> 1; /*0x107391c4b*/
    v9 = a1 + 1; /*0x107391c4d*/
  }
  std::regex_replace[abi:ne200100]<std::back_insert_iterator<std::string>,std::__wrap_iter<char const*>,std::regex_traits<char>,char>( /*0x107391c68*/
    a1: &v24,
    a2: v9,
    a3: &v9[v10],
    a4: &v21,
    a5: "   ",
    a6: 0);
  if ( (*a1 & 1) != 0 ) /*0x107391c70*/
    operator delete(a1: *((RBX::Memory **)a1 + 2), a2: v11); /*0x107391c76*/
  *((_QWORD *)a1 + 2) = v25; /*0x107391c83*/
  *(_OWORD *)a1 = v24; /*0x107391c8a*/
  std::basic_regex<char,std::regex_traits<char>>::basic_regex[abi:ne200100](a1: &v24, a2: "\n{3,}", a3: 0); /*0x107391c96*/
  v27 = 0; /*0x107391c9e*/
  v28 = 0; /*0x107391ca2*/
  v12 = *a1; /*0x107391caa*/
  if ( (v12 & 1) != 0 ) /*0x107391cb0*/
  {
    v4 = *((unsigned __int8 **)a1 + 2); /*0x107391cb2*/
    v13 = *((_QWORD *)a1 + 1); /*0x107391cb6*/
  }
  else
  {
    v13 = v12 >> 1; /*0x107391cbc*/
  }
  std::regex_replace[abi:ne200100]<std::back_insert_iterator<std::string>,std::__wrap_iter<char const*>,std::regex_traits<char>,char>( /*0x107391cd6*/
    a1: &v27,
    a2: v4,
    a3: &v4[v13],
    a4: &v24,
    a5: "\n\n\n",
    a6: 0);
  if ( (*a1 & 1) != 0 ) /*0x107391cde*/
    operator delete(a1: *((RBX::Memory **)a1 + 2), a2: v14); /*0x107391ce4*/
  *((_QWORD *)a1 + 2) = v28; /*0x107391ced*/
  *(_OWORD *)a1 = v27; /*0x107391cf5*/
  v15 = v26; /*0x107391cf8*/
  if ( v26 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v26 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107391d11*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x107391d19*/
    std::__shared_weak_count::__release_weak(this: v15); /*0x107391d1f*/
  }
  std::locale::~locale(this: (std::locale *)&v24); /*0x107391d28*/
  v16 = v23; /*0x107391d2d*/
  if ( v23 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v23 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107391d46*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x107391d4e*/
    std::__shared_weak_count::__release_weak(this: v16); /*0x107391d54*/
  }
  std::locale::~locale(this: (std::locale *)&v21); /*0x107391d60*/
  v17 = v20; /*0x107391d65*/
  if ( v20 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v20 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107391d81*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x107391d89*/
    std::__shared_weak_count::__release_weak(this: v17); /*0x107391d8f*/
  }
  std::locale::~locale(this: (std::locale *)v19); /*0x107391d9b*/
  return a1; /*0x107391da3*/
}

// Address: 0x107391e56 | Name: __ZN3RBXL10noNewLinesERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE_0
unsigned __int8 *__fastcall RBX::noNewLines(unsigned __int8 *a1, __int64 a2)
{
  __int64 v2; // rax
  __int64 v4; // r12
  char *v5; // r13
  char v6; // al
  char v8[41]; // [rsp+1h] [rbp-29h] BYREF

  v8[0] = HIBYTE(v2); /*0x107391e63*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x107391e6a*/
  {
    std::string::__init_copy_ctor_external(a1, a2: *(_QWORD *)(a2 + 16), a3: *(_QWORD *)(a2 + 8)); /*0x107391e87*/
  }
  else
  {
    *((_QWORD *)a1 + 2) = *(_QWORD *)(a2 + 16); /*0x107391e70*/
    *(_OWORD *)a1 = *(_OWORD *)a2; /*0x107391e77*/
  }
  v4 = (__int64)&a1[(*a1 >> 1) + 1]; /*0x107391ea0*/
  if ( (*a1 & 1) != 0 ) /*0x107391ea5*/
    v4 = *((_QWORD *)a1 + 2) + *((_QWORD *)a1 + 1); /*0x107391ea5*/
  v5 = (char *)(a1 + 1); /*0x107391ea9*/
  if ( (*a1 & 1) != 0 ) /*0x107391ead*/
    v5 = *((char **)a1 + 2); /*0x107391ead*/
  for ( ; v5 != (char *)v4; ++v5 ) /*0x107391eb4*/
  {
    v8[0] = *v5; /*0x107391ec5*/
    if ( std::__hash_table<char,std::hash<char>,std::equal_to<char>,std::allocator<char>>::find<char>( /*0x107391ed6*/
           a1: &RBX::kWhitespaceChars,
           a2: v8) != 0 )
      v6 = 32; /*0x107391ed8*/
    else
      v6 = v8[0]; /*0x107391edf*/
    *v5 = v6; /*0x107391ee3*/
  }
  return a1; /*0x107391ef6*/
}

// Address: 0x1075965a6 | Name: __ZNK3RBX14NetworkPathKeyeqERKS0_
bool __fastcall RBX::NetworkPathKey::operator==(__int64 a1, __int64 a2)
{
  const void *v4; // rdi
  size_t v5; // rdx
  const void *v6; // rsi
  const void *v7; // rdi
  size_t v8; // rdx
  const void *v9; // rsi
  bool result; // al

  if ( *(_DWORD *)a1 != *(_DWORD *)a2 ) /*0x1075965aa*/
    return false; /*0x107596604*/
  v4 = *(const void **)(a1 + 8); /*0x1075965b9*/
  v5 = *(_QWORD *)(a1 + 16) - (_QWORD)v4; /*0x1075965c1*/
  v6 = *(const void **)(a2 + 8); /*0x1075965c4*/
  result = v5 == *(_QWORD *)(a2 + 16) - (_QWORD)v6 /*0x1075965ff*/
        && memcmp(__s1: v4, __s2: v6, __n: v5) == 0
        && (v7 = *(const void **)(a1 + 32),
            v8 = *(_QWORD *)(a1 + 40) - (_QWORD)v7,
            v9 = *(const void **)(a2 + 32),
            v8 == *(_QWORD *)(a2 + 40) - (_QWORD)v9)
        && memcmp(__s1: v7, __s2: v9, __n: v8) == 0;
  return result; /*0x107596606*/
}

// Address: 0x108629ee0 | Name: __ZN3RBX17normalIdToVector3ENS_8NormalIdE.cold.1
void RBX::normalIdToVector3()
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RBX::normalIdToVector3(RBX::NormalId)::vector3map) != 0 ) /*0x108629ef2*/
  {
    _mm_storel_ps((double *)&RBX::normalIdToVector3(RBX::NormalId)::vector3map, (__m128)0x3F800000u); /*0x108629f00*/
    dword_10D2FAE68 = 0; /*0x108629f07*/
    qword_10D2FAE6C = 0x3F80000000000000LL; /*0x108629f16*/
    dword_10D2FAE74 = 0; /*0x108629f1e*/
    qword_10D2FAE78 = 0; /*0x108629f25*/
    dword_10D2FAE80 = 1065353216; /*0x108629f2d*/
    _mm_storel_ps((double *)&qword_10D2FAE84, (__m128)0xBF800000); /*0x108629f3f*/
    dword_10D2FAE8C = 0; /*0x108629f46*/
    qword_10D2FAE90 = 0xBF80000000000000LL; /*0x108629f55*/
    dword_10D2FAE98 = 0; /*0x108629f5d*/
    qword_10D2FAE9C = 0; /*0x108629f64*/
    dword_10D2FAEA4 = -1082130432; /*0x108629f6c*/
    qword_10D2FAEA8 = 0; /*0x108629f76*/
    dword_10D2FAEB0 = 0; /*0x108629f7e*/
    __cxa_guard_release(a1: &`guard variable for'RBX::normalIdToVector3(RBX::NormalId)::vector3map); /*0x108629f8d*/
  }
}

// Address: 0x108629f94 | Name: __ZN3RBX17normalIdToMatrix3ENS_8NormalIdE.cold.1
void RBX::normalIdToMatrix3()
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RBX::normalIdToMatrix3(RBX::NormalId)::matrix3map) != 0 ) /*0x108629fa6*/
  {
    RBX::normalIdToMatrix3(RBX::NormalId)::matrix3map = xmmword_108F33240; /*0x108629fb3*/
    xmmword_10D2FAED0 = xmmword_1094D20E0; /*0x108629fc1*/
    xmmword_10D2FAEE0 = xmmword_1094D20F0; /*0x108629fcf*/
    xmmword_10D2FAEF0 = xmmword_108F33240; /*0x108629fd6*/
    xmmword_10D2FAF00 = xmmword_108F8EEF0; /*0x108629fe4*/
    xmmword_10D2FAF10 = xmmword_108F33240; /*0x108629feb*/
    xmmword_10D2FAF20 = xmmword_1094D2100; /*0x108629ff9*/
    xmmword_10D2FAF30 = xmmword_1094D2110; /*0x10862a007*/
    xmmword_10D2FAF40 = 0x3F80000000000000uLL; /*0x10862a016*/
    xmmword_10D2FAF50 = xmmword_1094D2120; /*0x10862a024*/
    xmmword_10D2FAF60 = xmmword_1094D2110; /*0x10862a02b*/
    xmmword_10D2FAF70 = xmmword_1094D2130; /*0x10862a039*/
    xmmword_10D2FAF80 = xmmword_1094D2140; /*0x10862a047*/
    xmmword_10D2FAF90 = xmmword_1094D2150; /*0x10862a055*/
    xmmword_10D2FAFA0 = xmmword_108F33240; /*0x10862a05c*/
    qword_10D2FAFB0 = 0; /*0x10862a063*/
    dword_10D2FAFB8 = 1065353216; /*0x10862a06b*/
    __cxa_guard_release(a1: &`guard variable for'RBX::normalIdToMatrix3(RBX::NormalId)::matrix3map); /*0x10862a07d*/
  }
}

// END _free_n part 1/1, 48 functions
