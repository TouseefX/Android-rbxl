// _free_t -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 215 functions


// Address: 0x100029a0e | Name: __ZN3RBX31testApiDumpForCrashesAndAssertsEv
void __fastcall RBX::testApiDumpForCrashesAndAsserts(
        RBX *this,
        bool (__fastcall *a2)(const char *, const char *, int, const char *))
{
  RBX *v2; // rdi
  _BYTE v3[16]; // [rsp+0h] [rbp-20h] BYREF
  void *v4; // [rsp+10h] [rbp-10h]

  RBX::setAssertionHook(this: (RBX *)RBX::assertHookNoLog, a2); /*0x100029a1e*/
  RBX::grantInternalPermission(this: v2); /*0x100029a23*/
  RBX::dumpApiJson(a1: (__int64)v3, a2: 0, a3: 1u); /*0x100029a36*/
  if ( (v3[0] & 1) != 0 ) /*0x100029a3e*/
    operator delete(a1: v4); /*0x100029a44*/
}

// Address: 0x1000828ae | Name: __ZN3RBXL25texturePackPreloadEnabledEv
char __fastcall RBX::texturePackPreloadEnabled(RBX *this)
{
  return DFFlag::PreloadAsyncSupportTexturePack; /*0x1000828b8*/
}

// Address: 0x1001638b1 | Name: __ZN3RBXL18tryParseUniverseIdEv
__int64 __fastcall RBX::tryParseUniverseId(RBX *this)
{
  return RBX::parseUniverseId(a1: (unsigned __int8 *)&RBX::Http::universeID); /*0x1001638c9*/
}

// Address: 0x100295e1b | Name: __ZN3RBXL37tallyPrimitivesWithFluidForcesEnabledEPNS_8AssemblyE
__int64 __fastcall RBX::tallyPrimitivesWithFluidForcesEnabled(RBX *this, RBX::Assembly *a2)
{
  __int64 AssemblyPrimitive; // rax
  const RBX::Primitive *v3; // rsi
  unsigned int v4; // edx
  __int64 i; // rbx
  __int64 v6; // r13
  __int64 v7; // rdx
  __int64 v8; // rbx
  unsigned __int64 v9; // rdx
  __int64 j; // r14
  __int64 v11; // rax
  RBX::Assembly *v12; // r12
  __int64 v14; // [rsp+8h] [rbp-848h]
  void *v15; // [rsp+10h] [rbp-840h] BYREF
  __int64 v16; // [rsp+18h] [rbp-838h]
  _BYTE v17[2048]; // [rsp+20h] [rbp-830h] BYREF

  AssemblyPrimitive = RBX::Assembly::getAssemblyPrimitive(this); /*0x100295e3d*/
  v15 = v17; /*0x100295e49*/
  v16 = 0x10000000000LL; /*0x100295e57*/
  RBX::SmallVectorTemplateBase<RBX::Primitive *,true>::push_back(a1: (__int64)&v15, a2: AssemblyPrimitive); /*0x100295e65*/
  v4 = v16; /*0x100295e6a*/
  for ( i = 0; (_DWORD)v16 != 0; i = v14 ) /*0x100295e74*/
  {
    v6 = *((_QWORD *)v15 + v4 - 1); /*0x100295e8a*/
    v7 = v4 - 1; /*0x100295e8f*/
    LODWORD(v16) = v7; /*0x100295e91*/
    v14 = ((*(_WORD *)(v6 + 613) & 0x20) != 0) + i; /*0x100295ea7*/
    v8 = *(int *)(v6 + 40); /*0x100295eae*/
    v9 = v8 + v7; /*0x100295eb2*/
    if ( v9 > HIDWORD(v16) ) /*0x100295ebe*/
      RBX::SmallVectorBase<unsigned int>::grow_pod(a1: &v15, a2: v17, a3: v9, a4: 8); /*0x100295ecf*/
    if ( (int)v8 > 0 ) /*0x100295ed6*/
    {
      for ( j = 0; j != v8; ++j ) /*0x100295ed8*/
      {
        v11 = *(_QWORD *)(*(_QWORD *)(v6 + 32) + 8 * j); /*0x100295edf*/
        v12 = (RBX::Assembly *)(v11 - 16); /*0x100295ee3*/
        if ( v11 == 0 ) /*0x100295eea*/
          v12 = nullptr; /*0x100295eea*/
        if ( !RBX::Assembly::isAssemblyRootPrimitive(this: v12, a2: v3) ) /*0x100295ef1*/
          RBX::SmallVectorTemplateBase<RBX::Primitive *,true>::push_back(a1: (__int64)&v15, a2: (__int64)v12); /*0x100295f00*/
      }
    }
    v4 = v16; /*0x100295f0d*/
  }
  if ( v15 != v17 ) /*0x100295f33*/
    operator delete(a1: (RBX::Memory *)v15, a2: v3); /*0x100295f35*/
  return i; /*0x100295f4d*/
}

// Address: 0x100296212 | Name: __ZN3RBX29traverseAndAddMovedPrimitivesEPNS_9PrimitiveERNSt3__16vectorIS1_NS2_9allocatorIS1_EEEEPNS_8AssemblyE
void __fastcall RBX::traverseAndAddMovedPrimitives(__int64 a1, __int64 a2, __int64 a3)
{
  RBX::Primitive *v5; // rsi
  __int64 v6; // rax
  __int64 v7; // r12
  __int64 i; // r13
  __int64 v9; // rax
  RBX::Primitive *v10; // r15
  _QWORD v11[6]; // [rsp+0h] [rbp-30h] BYREF

  v11[0] = a1; /*0x100296220*/
  if ( (*(_BYTE *)(a1 + 613) & 1) == 0 ) /*0x10029622b*/
  {
    std::vector<RBX::Primitive *>::push_back[abi:ne200100](a1: a2, a2: v11); /*0x10029623d*/
    v6 = v11[0]; /*0x100296242*/
    *(_WORD *)(v11[0] + 613LL) |= 1u; /*0x100296245*/
    v7 = *(int *)(v6 + 40); /*0x10029624d*/
    if ( v7 > 0 ) /*0x100296254*/
    {
      for ( i = 0; i != v7; ++i ) /*0x100296256*/
      {
        v9 = *(_QWORD *)(*(_QWORD *)(v11[0] + 32LL) + 8 * i); /*0x100296261*/
        v10 = (RBX::Primitive *)(v9 - 16); /*0x100296265*/
        if ( v9 == 0 ) /*0x10029626c*/
          v10 = nullptr; /*0x10029626c*/
        if ( RBX::Primitive::getAssembly(this: v10, a2: v5) == a3 ) /*0x10029627b*/
          RBX::traverseAndAddMovedPrimitives(a1: (__int64)v10, a2, a3); /*0x100296286*/
      }
    }
  }
}

// Address: 0x1002e7f04 | Name: __ZZN3RBXL26togglePredictionInAssemblyEPNS_8AssemblyEPNS_13AuroraServiceEbENK3$_1clEPNS_5JointE
__int64 __fastcall RBX::togglePredictionInAssembly(RBX::Assembly *,RBX::AuroraService *,bool)::$_1::operator()(
        __int64 *a1,
        RBX::Joint *a2)
{
  const RBX::Joint *v4; // rsi
  __int64 v5; // r14
  __int64 JointOwner; // rax
  __int64 v7; // rsi
  __int64 result; // rax
  __int64 v9; // r14
  __int64 v10; // rax
  __int64 v11; // rsi
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13[4]; // [rsp+0h] [rbp-20h] BYREF

  if ( RBX::Joint::isJointInstanceOwned(this: a2, a2) ) /*0x1002e7f18*/
  {
    v5 = *a1; /*0x1002e7f21*/
    JointOwner = RBX::Joint::getJointOwner(this: a2); /*0x1002e7f27*/
    v7 = JointOwner - 224; /*0x1002e7f2c*/
    if ( JointOwner == 0 ) /*0x1002e7f36*/
      v7 = 0; /*0x1002e7f36*/
    RBX::shared_from<RBX::JointInstance>(a1: v13, a2: v7); /*0x1002e7f41*/
    result = RBX::SmallVectorImpl<std::shared_ptr<RBX::Instance>>::emplace_back<std::shared_ptr<RBX::JointInstance>>( /*0x1002e7f4c*/
               a1: v5,
               a2: v13);
  }
  else
  {
    result = RBX::Joint::isConstraintOwned(this: a2, a2: v4); /*0x1002e7f56*/
    if ( (_BYTE)result == 0 ) /*0x1002e7f5d*/
      return result; /*0x1002e7f5d*/
    v9 = *a1; /*0x1002e7f5f*/
    v10 = RBX::Joint::getJointOwner(this: a2); /*0x1002e7f65*/
    v11 = v10 - 192; /*0x1002e7f6a*/
    if ( v10 == 0 ) /*0x1002e7f74*/
      v11 = 0; /*0x1002e7f74*/
    RBX::shared_from<RBX::Constraints::Constraint>(a1: v13, a2: v11); /*0x1002e7f7f*/
    result = RBX::SmallVectorImpl<std::shared_ptr<RBX::Instance>>::emplace_back<std::shared_ptr<RBX::Constraints::Constraint>>( /*0x1002e7f8a*/
               a1: v9,
               a2: v13);
  }
  v12 = v13[1]; /*0x1002e7f8f*/
  if ( v13[1] != nullptr ) /*0x1002e7f96*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v13[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x1002e7f9f*/
    if ( result == 0 ) /*0x1002e7fa8*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x1002e7fb0*/
      return std::__shared_weak_count::__release_weak(this: v12); /*0x1002e7fb6*/
    }
  }
  return result; /*0x1002e7fbb*/
}

// Address: 0x1002e83c8 | Name: __ZZN3RBXL27togglePredictionOnInstancesERKNS_11SmallVectorINSt3__110shared_ptrINS_8InstanceEEELj16EEEPNS_13AuroraServiceEbENK3$_1clERKS4_
__int64 __fastcall RBX::togglePredictionOnInstances(RBX::SmallVector<std::shared_ptr<RBX::Instance>,16u> const&,RBX::AuroraService *,bool)::$_1::operator()(
        __int64 *a1,
        __int128 *a2)
{
  __int64 result; // rax
  RBX::Instance *v5; // rsi
  char v6; // cl
  RBX::DataModel *v7; // r15
  __int64 v8; // rdi
  __int64 v9; // rax
  std::__shared_weak_count *v10; // rbx
  __int64 v11; // rdi
  __int64 v12; // rax
  std::__shared_weak_count *v13[2]; // [rsp+0h] [rbp-40h] BYREF
  __int128 v14; // [rsp+10h] [rbp-30h] BYREF

  result = RBX::AuroraUtils::isPredicted(a1: a2); /*0x1002e83de*/
  v6 = *((_BYTE *)a1 + 8); /*0x1002e83e3*/
  if ( v6 == (_BYTE)result ) /*0x1002e83e9*/
    return result; /*0x1002e83e9*/
  if ( v6 == 0 ) /*0x1002e83f1*/
  {
    v11 = *a1; /*0x1002e845e*/
    v12 = *((_QWORD *)a2 + 1); /*0x1002e8461*/
    v14 = *a2; /*0x1002e8468*/
    if ( v12 != 0 ) /*0x1002e846f*/
      _InterlockedIncrement64((volatile signed __int64 *)(v12 + 8)); /*0x1002e8471*/
    result = RBX::AuroraService::stopPrediction(a1: v11, a2: &v14); /*0x1002e847d*/
    v10 = *((std::__shared_weak_count **)&v14 + 1); /*0x1002e8482*/
    goto LABEL_15; /*0x1002e8482*/
  }
  if ( FFlag::SAToolEquip == 1 ) /*0x1002e83fd*/
  {
    result = RBX::DataModel::get(this: *(RBX::DataModel **)a2, a2: v5); /*0x1002e8402*/
    if ( result == 0 ) /*0x1002e840a*/
      return result; /*0x1002e840a*/
    v7 = *(RBX::DataModel **)a2; /*0x1002e8410*/
    result = RBX::DataModelProp::getWorkspace(this: (RBX::DataModelProp *)(result + 720)); /*0x1002e841c*/
    do /*0x1002e842d*/
      v7 = *((RBX::DataModel **)v7 + 13); /*0x1002e8421*/
    while ( v7 != (RBX::DataModel *)result && v7 != nullptr ); /*0x1002e842d*/
    if ( v7 != (RBX::DataModel *)result ) /*0x1002e8432*/
      return result; /*0x1002e84ae*/
  }
  v8 = *a1; /*0x1002e8434*/
  v9 = *((_QWORD *)a2 + 1); /*0x1002e8437*/
  *(_OWORD *)v13 = *a2; /*0x1002e843e*/
  if ( v9 != 0 ) /*0x1002e8445*/
    _InterlockedIncrement64((volatile signed __int64 *)(v9 + 8)); /*0x1002e8447*/
  result = RBX::AuroraService::startPrediction(a1: v8, a2: v13); /*0x1002e8453*/
  v10 = v13[1]; /*0x1002e8458*/
LABEL_15:
  if ( v10 != nullptr ) /*0x1002e8489*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v10 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x1002e8492*/
    if ( result == 0 ) /*0x1002e849b*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x1002e84a3*/
      return std::__shared_weak_count::__release_weak(this: v10); /*0x1002e84a9*/
    }
  }
  return result; /*0x1002e84a9*/
}

// Address: 0x10030136f | Name: __ZN3RBXL27tickleAerodynamicAssembliesERNS_5WorldE
__int64 __fastcall RBX::tickleAerodynamicAssemblies(RBX *this, RBX::World *a2)
{
  RBX::World *v2; // r13
  RBX::SteppingParameters *v3; // r14
  __int32 v4; // xmm0_4
  float v5; // xmm0_4
  __int64 v6; // rcx
  __int64 result; // rax
  __int64 v8; // rcx
  int v9; // ebx
  RBX::Assembly *v10; // r12
  __int64 AeroForceModel; // rax
  __int64 v12; // r15
  RBX::Solver::SolverRigidBody *v13; // rbx
  __int128 v14; // xmm0
  __int128 v15; // xmm1
  __int64 v16; // r14
  float v17; // xmm0_4
  float v18; // xmm0_4
  __m128 v19; // xmm0
  float v20; // xmm1_4
  __m128 v21; // xmm2
  __int64 v22; // r13
  __int64 EntityID; // r14
  __int64 v24; // rax
  double *v25; // rcx
  __int128 v26; // xmm0
  __int64 v27; // rax
  double *v28; // rcx
  void *v29; // rsi
  __m128 v30; // xmm0
  float v31; // xmm2_4
  float v32; // xmm9_4
  __m128 v33; // xmm2
  __m128 v34; // xmm8
  __m128 v35; // xmm11
  __m128 inserted; // xmm10
  __m128 v37; // xmm5
  __m128 v38; // xmm6
  __m128 v39; // xmm7
  float v40; // xmm3_4
  float v41; // xmm4_4
  __int64 v42; // r14
  unsigned int v43; // r15d
  __int64 v44; // rax
  double v45; // xmm0_8
  double v46; // xmm1_8
  __int64 v47; // r15
  __int64 v48; // rax
  unsigned int v49; // edx
  __int64 v50; // rsi
  __int64 BuoyancyForceModel; // rax
  float v52; // xmm0_4
  float v53; // xmm9_4
  __m128 v54; // xmm0
  __m128 v55; // xmm0
  __m128 v56; // xmm0
  __m128 v57; // xmm2
  __m128 v58; // xmm5
  __m128 v59; // xmm5
  __m128 v60; // xmm6
  __m128 v61; // xmm6
  __m128 v62; // xmm2
  __m128 v63; // xmm2
  float v64; // xmm0_4
  float v65; // xmm1_4
  float v66; // xmm1_4
  float v67; // xmm0_4
  __m128 v68; // [rsp+10h] [rbp-230h]
  __m128 v69; // [rsp+20h] [rbp-220h]
  __m128 v70; // [rsp+30h] [rbp-210h]
  __m128 v71; // [rsp+40h] [rbp-200h]
  __m128 v72; // [rsp+60h] [rbp-1E0h]
  _QWORD v73[4]; // [rsp+70h] [rbp-1D0h] BYREF
  __int128 v74; // [rsp+90h] [rbp-1B0h]
  double v75[13]; // [rsp+A8h] [rbp-198h] BYREF
  __int128 v76; // [rsp+110h] [rbp-130h]
  __int128 v77; // [rsp+120h] [rbp-120h]
  __int128 v78; // [rsp+130h] [rbp-110h]
  __int128 v79; // [rsp+140h] [rbp-100h]
  __m128 v80; // [rsp+150h] [rbp-F0h]
  __m128 v81; // [rsp+160h] [rbp-E0h]
  __int64 v82; // [rsp+170h] [rbp-D0h]
  RBX::World *v83; // [rsp+178h] [rbp-C8h]
  __m128 v84; // [rsp+180h] [rbp-C0h]
  __int64 v85; // [rsp+198h] [rbp-A8h] BYREF
  int v86; // [rsp+1A0h] [rbp-A0h]
  unsigned __int64 v87; // [rsp+1A8h] [rbp-98h] BYREF
  float v88; // [rsp+1B0h] [rbp-90h]
  unsigned int v89; // [rsp+1B8h] [rbp-88h] BYREF
  float v90; // [rsp+1BCh] [rbp-84h]
  unsigned __int64 v91; // [rsp+1C0h] [rbp-80h] BYREF
  unsigned int v92; // [rsp+1C8h] [rbp-78h]
  __m128 v93; // [rsp+1D0h] [rbp-70h]
  __int64 v94; // [rsp+1E0h] [rbp-60h] BYREF
  unsigned int v95; // [rsp+1E8h] [rbp-58h]
  float v96; // [rsp+1F0h] [rbp-50h] BYREF
  unsigned int v97; // [rsp+1F4h] [rbp-4Ch] BYREF
  float v98; // [rsp+1F8h] [rbp-48h] BYREF
  int v99; // [rsp+1FCh] [rbp-44h]
  float v100; // [rsp+200h] [rbp-40h]
  float v101; // [rsp+204h] [rbp-3Ch]
  RBX::Solver::SolverRigidBody *v102; // [rsp+208h] [rbp-38h] BYREF
  char v103; // [rsp+217h] [rbp-29h] BYREF

  v2 = this; /*0x100301383*/
  v3 = (RBX *)((char *)this + 1692); /*0x100301386*/
  RBX::SteppingParameters::worldStepDt(this: (RBX *)((char *)this + 1692)); /*0x100301390*/
  v93.i32[0] = v4; /*0x100301395*/
  RBX::SteppingParameters::worldStepDt(this: v3); /*0x10030139d*/
  v96 = 0.0000010000001 / (float)(v5 * v93.f32[0]); /*0x1003013b3*/
  v6 = *(_QWORD *)(*((_QWORD *)v2 + 259) + 56LL); /*0x1003013bf*/
  result = *(_QWORD *)(v6 + 1960); /*0x1003013c3*/
  v82 = v6; /*0x1003013ca*/
  if ( *(_QWORD *)(v6 + 1968) != result ) /*0x1003013d8*/
  {
    v8 = 0; /*0x1003013de*/
    v9 = 0; /*0x1003013e0*/
    v83 = v2; /*0x1003013e2*/
    while ( 1 ) /*0x1003013e9*/
    {
      v10 = *(RBX::Assembly **)(result + 8 * v8); /*0x1003013e9*/
      v102 = *(RBX::Solver::SolverRigidBody **)(*(_QWORD *)(RBX::Assembly::getAssemblyPrimitive(this: v10) + 152) + 64LL); /*0x100301400*/
      AeroForceModel = RBX::Solver::SolverRigidBody::getAeroForceModel(this: v102); /*0x100301404*/
      if ( AeroForceModel == 0 ) /*0x10030140c*/
      {
        if ( !RBX::Solver::SolverRigidBody::hasAeroStateMachine(this: v102) ) /*0x1003016f2*/
          goto LABEL_41; /*0x1003016f2*/
        RBX::World::tickleAssembly(this: v2, a2: v10, a3: 0); /*0x100301700*/
        goto LABEL_42; /*0x100301705*/
      }
      v12 = AeroForceModel; /*0x100301412*/
      v99 = v9; /*0x100301415*/
      v13 = v102; /*0x100301418*/
      v14 = *(_OWORD *)((char *)v102 + 116); /*0x10030141c*/
      v15 = *(_OWORD *)((char *)v102 + 132); /*0x100301420*/
      v74 = *(_OWORD *)((char *)v102 + 148); /*0x10030142e*/
      *(_OWORD *)v73 = v14; /*0x100301435*/
      *(_OWORD *)&v73[2] = v15; /*0x10030143c*/
      v97 = *((_DWORD *)v102 + 129); /*0x10030144b*/
      v98 = *((float *)v102 + 14); /*0x100301455*/
      v16 = *((_QWORD *)v2 + 67); /*0x10030145a*/
      v17 = *((float *)&v74 + 2) - *(float *)(v16 + 12); /*0x100301469*/
      v93.i32[0] = *(_DWORD *)(v16 + 16); /*0x10030147c*/
      if ( v17 >= 0.0 ) /*0x100301481*/
      {
        v18 = expf(a1: v17 * *(float *)(v16 + 24)); /*0x100301489*/
        v93.f32[0] = v93.f32[0] * v18; /*0x100301497*/
      }
      RBX::FluidModels::FixedProfileFluid::getReferenceVelocity(this: (RBX::FluidModels::FixedProfileFluid *)v16); /*0x10030149f*/
      v21 = v19; /*0x1003014a4*/
      if ( FFlag::SimUsingDataRegistry == 1 /*0x1003014d1*/
        && FFlag::SimFluidsUsingDataRegistry == 1
        && FFlag::SimRefactorFieldsToDataRegistry == 1 )
      {
        v84 = v19; /*0x1003014d7*/
        v101 = v20; /*0x1003014de*/
        v22 = *((_QWORD *)v2 + 68); /*0x1003014e3*/
        EntityID = (unsigned int)RBX::Solver::SolverRigidBody::getEntityID(this: v102); /*0x1003014f3*/
        v75[0] = 0.0; /*0x1003014f6*/
        v24 = RBX::Ecs::DataRegistry::getComponent<RBX::Vector3>( /*0x100301517*/
                a1: v22,
                a2: EntityID,
                a3: "aeroLastForce",
                a4: 0x3CEE7F948D8FA9BFLL);
        v25 = (double *)v24; /*0x10030151c*/
        v26 = 0; /*0x10030151f*/
        v100 = 0.0; /*0x100301522*/
        if ( v24 != 0 ) /*0x100301531*/
          v26 = *(unsigned int *)(v24 + 8); /*0x100301537*/
        else
          v25 = v75; /*0x100301531*/
        v79 = v26; /*0x10030153c*/
        v80 = (__m128)*(unsigned __int64 *)v25; /*0x100301547*/
        v75[0] = 0.0; /*0x10030154e*/
        v27 = RBX::Ecs::DataRegistry::getComponent<RBX::Vector3>( /*0x100301570*/
                a1: v22,
                a2: (unsigned int)EntityID,
                a3: "aeroLastTorque",
                a4: 0x473B0C35DCFDF7FALL);
        v28 = (double *)v27; /*0x100301575*/
        if ( v27 != 0 ) /*0x100301582*/
          v100 = *(float *)(v27 + 8); /*0x10030158d*/
        else
          v28 = v75; /*0x100301582*/
        v81 = (__m128)*(unsigned __int64 *)v28; /*0x100301596*/
        v2 = v83; /*0x10030159d*/
        v20 = v101; /*0x1003015a4*/
        v21 = v84; /*0x1003015a9*/
      }
      else
      {
        v80 = (__m128)*(unsigned __int64 *)(v12 + 8); /*0x1003015b8*/
        v79 = *(unsigned int *)(v12 + 16); /*0x1003015c5*/
        v81 = (__m128)*(unsigned __int64 *)(v12 + 20); /*0x1003015d2*/
        v100 = *(float *)(v12 + 28); /*0x1003015df*/
      }
      v94 = 0; /*0x1003015e6*/
      v95 = 0; /*0x1003015ea*/
      v91 = 0; /*0x1003015ed*/
      v92 = 0; /*0x1003015f1*/
      v87 = *(_QWORD *)((char *)v102 + 164); /*0x1003015ff*/
      v88 = *((float *)v102 + 43); /*0x10030160c*/
      v86 = *((_DWORD *)v102 + 46); /*0x100301618*/
      v85 = *((_QWORD *)v102 + 22); /*0x100301625*/
      if ( DFFlag::QuadratureVariableFluidDensity == 1 ) /*0x100301636*/
      {
        memset(&v75[1], 0, 89); /*0x10030165a*/
        v78 = 0; /*0x10030165e*/
        v77 = 0; /*0x100301662*/
        v76 = 0; /*0x100301666*/
        _mm_storel_ps(v75, v21); /*0x100301669*/
        *(float *)&v75[1] = v20; /*0x100301670*/
        (*(void (__fastcall **)(__int64, __int64 *, unsigned __int64 *, _QWORD *, unsigned __int64 *, __int64 *, float, double *))(*(_QWORD *)v12 + 56LL))( /*0x1003016af*/
          a1: v12,
          a2: &v94,
          a3: &v91,
          a4: v73,
          a5: &v87,
          a6: &v85,
          a7: v93.f32[0],
          a8: v75);
        if ( *((_QWORD *)&v77 + 1) != 0 ) /*0x1003016bb*/
        {
          *(_QWORD *)&v78 = *((_QWORD *)&v77 + 1); /*0x1003016bd*/
          operator delete(a1: *((RBX::Memory **)&v77 + 1), a2: v29); /*0x1003016c4*/
        }
        if ( (_QWORD)v76 != 0 ) /*0x1003016d3*/
        {
          *((_QWORD *)&v76 + 1) = v76; /*0x1003016d9*/
          operator delete(a1: (RBX::Memory *)v76, a2: v29); /*0x1003016e0*/
        }
      }
      else
      {
        v30 = _mm_sub_ps((__m128)v87, v21); /*0x100301712*/
        v31 = v88 - v20; /*0x10030171d*/
        _mm_storel_ps(v75, v30); /*0x100301721*/
        *(float *)&v75[1] = v31; /*0x100301728*/
        (*(void (__fastcall **)(__int64, __int64 *, unsigned __int64 *, _QWORD *, double *, __int64 *, float))(*(_QWORD *)v12 + 24LL))( /*0x100301758*/
          a1: v12,
          a2: &v94,
          a3: &v91,
          a4: v73,
          a5: v75,
          a6: &v85,
          a7: v93.f32[0]);
      }
      v32 = *((float *)&v94 + 1); /*0x10030175b*/
      v33 = (__m128)v91; /*0x100301761*/
      v34 = (__m128)v92; /*0x100301766*/
      v35 = (__m128)v97; /*0x10030176c*/
      inserted = _mm_insert_ps((__m128)v95, (__m128)(unsigned int)v94, 16); /*0x100301778*/
      v37 = *((__m128 *)v13 + 30); /*0x100301780*/
      v38 = *(__m128 *)((char *)v13 + 492); /*0x100301787*/
      v39 = _mm_insert_ps((__m128)*((unsigned __int64 *)v13 + 63), (__m128)*((unsigned int *)v13 + 128), 40); /*0x100301796*/
      v40 = v96; /*0x1003017a0*/
      v41 = v98; /*0x1003017a5*/
      v103 = 0; /*0x1003017aa*/
      if ( DFFlag::SimWakeBodiesOnAirDensityBuoyancyChange == 1 ) /*0x1003017b5*/
        break; /*0x1003017b5*/
LABEL_36:
      v52 = _mm_movehdup_ps(v80).f32[0]; /*0x100301984*/
      v53 = (float)((float)(v32 - v52) * v35.f32[0]) * (float)((float)(v32 - v52) * v35.f32[0]); /*0x100301999*/
      v54 = _mm_moveldup_ps(v80); /*0x10030199e*/
      v54.f32[0] = *(float *)&v79; /*0x1003019a9*/
      v55 = _mm_mul_ps(_mm_moveldup_ps(v35), _mm_sub_ps(inserted, v54)); /*0x1003019b6*/
      v56 = _mm_mul_ps(v55, v55); /*0x1003019ba*/
      if ( (float)((float)(_mm_movehdup_ps(v56).f32[0] + v53) + v56.f32[0]) <= v40 ) /*0x1003019cd*/
      {
        v34.f32[0] = v34.f32[0] - v100; /*0x1003019d6*/
        v57 = _mm_insert_ps(_mm_sub_ps(v33, v81), v34, 40); /*0x1003019dc*/
        v58 = _mm_mul_ps(v37, v57); /*0x1003019e3*/
        v59 = _mm_hadd_ps(v58, v58); /*0x1003019e6*/
        v60 = _mm_mul_ps(v38, v57); /*0x1003019ea*/
        v61 = _mm_hadd_ps(v60, v60); /*0x1003019ed*/
        v62 = _mm_mul_ps(v57, v39); /*0x1003019f1*/
        v63 = _mm_hadd_ps(v62, v62); /*0x1003019f4*/
        v64 = _mm_movehdup_ps(v61).f32[0]; /*0x1003019f8*/
        v65 = _mm_movehdup_ps(v59).f32[0]; /*0x100301a04*/
        v66 = (float)((float)(v65 + v59.f32[0]) * (float)(v65 + v59.f32[0])) /*0x100301a10*/
            + (float)((float)(v64 + v61.f32[0]) * (float)(v64 + v61.f32[0]));
        v67 = _mm_movehdup_ps(v63).f32[0]; /*0x100301a14*/
        if ( (float)((float)((float)((float)((float)(v67 + v63.f32[0]) * (float)(v67 + v63.f32[0])) + v66) * v41) * v41) <= v40 /*0x100301a35*/
          && v103 != 1 )
        {
          v9 = v99; /*0x100301a49*/
LABEL_41:
          ++v9; /*0x100301a4c*/
          goto LABEL_42; /*0x100301a4c*/
        }
      }
      RBX::World::tickleAssembly(this: v2, a2: v10, a3: 0); /*0x100301a3f*/
      v9 = v99; /*0x100301a44*/
LABEL_42:
      v8 = v9; /*0x100301a4e*/
      result = *(_QWORD *)(v82 + 1960); /*0x100301a58*/
      if ( (*(_QWORD *)(v82 + 1968) - result) >> 3 <= (unsigned __int64)v9 ) /*0x100301a70*/
        return result; /*0x100301a70*/
    }
    v72 = (__m128)v97; /*0x1003017bb*/
    v90 = *((float *)&v94 + 1); /*0x1003017cb*/
    v71 = (__m128)v92; /*0x1003017d4*/
    v70 = v39; /*0x1003017dc*/
    v69 = v38; /*0x1003017e3*/
    v68 = v37; /*0x1003017ea*/
    v84.f32[0] = v98; /*0x1003017f1*/
    v101 = v96; /*0x1003017f9*/
    v93 = (__m128)v91; /*0x1003017fe*/
    *(_QWORD *)&v75[0] = v73; /*0x100301810*/
    *(_QWORD *)&v75[1] = v2; /*0x100301817*/
    *(_QWORD *)&v75[2] = &v102; /*0x100301822*/
    *(_QWORD *)&v75[3] = &v97; /*0x10030182d*/
    *(_QWORD *)&v75[4] = (char *)v13 + 480; /*0x100301834*/
    *(_QWORD *)&v75[5] = &v103; /*0x10030183f*/
    *(_QWORD *)&v75[6] = &v96; /*0x10030184a*/
    *(_QWORD *)&v75[7] = &v98; /*0x100301855*/
    if ( FFlag::SimUsingDataRegistry == 1 && FFlag::SimFluidsUsingDataRegistry == 1 ) /*0x100301876*/
    {
      v42 = *((_QWORD *)v2 + 68); /*0x10030187c*/
      v43 = RBX::Solver::SolverRigidBody::getEntityID(this: v102); /*0x10030188c*/
      if ( RBX::Ecs::DataRegistry::getComponent<RBX::Solver::BuoyancyForceModel>( /*0x1003018ad*/
             a1: v42,
             a2: v43,
             a3: "buoyancyForceModel",
             a4: 0x71C98222FFAF0A0BLL) == 0 )
        goto LABEL_35; /*0x1003018ad*/
      v89 = v43; /*0x1003018b3*/
      v44 = RBX::Ecs::DataRegistry::getStorage<RBX::Solver::BuoyancyForceModel const>( /*0x1003018ce*/
              a1: v42,
              a2: "buoyancyForceModel",
              a3: 0x71C98222FFAF0A0BLL);
      if ( v44 == 0 ) /*0x1003018d6*/
        goto LABEL_35; /*0x1003018d6*/
      v47 = v44; /*0x1003018d8*/
      v48 = RBX::details::SplitHashTable<unsigned int,std::pair<unsigned int,unsigned long>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<unsigned int>,RBX::details::DefaultEqualTo<unsigned int>,RBX::details::GetMapKey<unsigned int,unsigned long>>::find_as<unsigned int>( /*0x1003018e6*/
              a1: v44 + 40,
              a2: &v89,
              a3: v45,
              a4: v46);
      if ( v49 == 0 && v48 == 0 ) /*0x1003018ee*/
        goto LABEL_35; /*0x1003018fa*/
      v50 = *(_QWORD *)(v47 + 88) + 80LL * *(_QWORD *)(*(_QWORD *)(v48 + 16) + 16LL * v49 + 8); /*0x100301913*/
    }
    else
    {
      BuoyancyForceModel = RBX::Solver::SolverRigidBody::getBuoyancyForceModel(this: v102); /*0x100301924*/
      if ( BuoyancyForceModel == 0 ) /*0x10030192c*/
      {
LABEL_35:
        v33 = v93; /*0x10030193d*/
        v40 = v101; /*0x100301941*/
        v41 = v84.f32[0]; /*0x100301946*/
        v37 = v68; /*0x10030194e*/
        v38 = v69; /*0x100301955*/
        v39 = v70; /*0x10030195c*/
        v34 = v71; /*0x100301963*/
        v32 = v90; /*0x10030196b*/
        v35 = v72; /*0x10030197c*/
        goto LABEL_36; /*0x10030197c*/
      }
      v50 = BuoyancyForceModel; /*0x100301935*/
    }
    RBX::tickleAerodynamicAssemblies(RBX::World &)::$_1::operator()(a1: v75, a2: v50); /*0x100301938*/
    goto LABEL_35; /*0x100301938*/
  }
  return result; /*0x100301a76*/
}

// Address: 0x1003102d8 | Name: __ZZN3RBXL27tickleAerodynamicAssembliesERNS_5WorldEENK3$_1clERKNS_6Solver18BuoyancyForceModelE
bool __fastcall RBX::tickleAerodynamicAssemblies(RBX::World &)::$_1::operator()(__int64 a1, __int64 a2)
{
  const RBX::CoordinateFrame *v4; // r15
  __m128 v5; // xmm2
  __m128 v6; // xmm2
  __int64 v7; // r12
  __int64 v8; // rax
  float v9; // xmm0_4
  __m128i v10; // xmm3
  float v11; // xmm0_4
  float v12; // xmm0_4
  int v13; // eax
  float v14; // xmm0_4
  float v15; // xmm1_4
  __int64 v16; // r14
  unsigned int EntityID; // r15d
  unsigned __int64 *v18; // r12
  __int64 v19; // rax
  unsigned __int64 *v20; // rcx
  __int128 v21; // xmm0
  __int64 v22; // rax
  float v23; // xmm5_4
  __m128 v24; // xmm1
  float v25; // xmm6_4
  __m128 v26; // xmm4
  float v27; // xmm0_4
  __m128 v28; // xmm2
  float v29; // xmm0_4
  __m128 v30; // xmm4
  __m128 v31; // xmm2
  __m128 v32; // xmm2
  float v33; // xmm3_4
  float v34; // xmm0_4
  bool result; // al
  __m128 v36; // xmm2
  __m128 v37; // xmm1
  __m128 inserted; // xmm2
  __int64 v39; // rax
  __m128 v40; // xmm1
  __m128 v41; // xmm1
  __m128 v42; // xmm3
  __m128 v43; // xmm3
  __m128 v44; // xmm4
  __m128 v45; // xmm4
  float v46[3]; // [rsp+4h] [rbp-7Ch] BYREF
  __m128 v47; // [rsp+10h] [rbp-70h]
  unsigned __int64 v48; // [rsp+28h] [rbp-58h] BYREF
  float v49; // [rsp+30h] [rbp-50h]
  __int64 v50; // [rsp+38h] [rbp-48h] BYREF
  __int128 v51; // [rsp+40h] [rbp-40h]
  __int64 v52; // [rsp+50h] [rbp-30h] BYREF
  unsigned int v53; // [rsp+58h] [rbp-28h]

  v4 = *(const RBX::CoordinateFrame **)a1; /*0x1003102ed*/
  v5 = _mm_mul_ps(*(__m128 *)(*(_QWORD *)a1 + 12LL), _mm_blend_ps((__m128)0LL, *(__m128 *)(a2 + 56), 7)); /*0x100310302*/
  v6 = _mm_hadd_ps(v5, v5); /*0x100310305*/
  v7 = *(_QWORD *)(a1 + 8); /*0x100310317*/
  v8 = *(_QWORD *)(v7 + 536); /*0x10031031b*/
  v9 = (float)((float)(_mm_movehdup_ps(v6).f32[0] + v6.f32[0]) + *(float *)(*(_QWORD *)a1 + 40LL)) - *(float *)(v8 + 12); /*0x100310323*/
  v10 = (__m128i)*(unsigned int *)(v8 + 16); /*0x10031032e*/
  if ( v9 >= 0.0 ) /*0x100310333*/
  {
    v11 = v9 * *(float *)(v8 + 24); /*0x100310335*/
    LODWORD(v51) = *(_DWORD *)(v8 + 16); /*0x10031033a*/
    v12 = expf(a1: v11); /*0x10031033f*/
    v10 = (__m128i)(unsigned int)v51; /*0x100310344*/
    *(float *)v10.i32 = *(float *)&v51 * v12; /*0x100310349*/
  }
  v13 = *(_DWORD *)(a2 + 76); /*0x10031034d*/
  v14 = 1.0; /*0x100310351*/
  if ( v13 != 0 ) /*0x10031035b*/
    v14 = 1.0 - (float)(*(float *)(a2 + 72) / (float)v13); /*0x10031036e*/
  v15 = -*(float *)(v7 + 520); /*0x10031037c*/
  *(float *)v10.i32 = *(float *)v10.i32 * v14; /*0x100310383*/
  v46[0] = 0.0; /*0x10031038d*/
  v46[1] = v15; /*0x10031038f*/
  v46[2] = 0.0; /*0x100310394*/
  v52 = 0; /*0x10031039b*/
  v53 = 0; /*0x10031039e*/
  v48 = 0; /*0x1003103a5*/
  v49 = 0.0; /*0x1003103a8*/
  RBX::Solver::BuoyancyForceModel::compute( /*0x1003103b4*/
    this: (RBX::Solver::BuoyancyForceModel *)a2,
    a2: (RBX::Vector3 *)&v52,
    a3: (RBX::Vector3 *)&v48,
    a4: v10,
    a5: (const RBX::Vector3 *)v46,
    a6: v4);
  if ( FFlag::SimUsingDataRegistry == 1 /*0x1003103e3*/
    && FFlag::SimFluidsUsingDataRegistry == 1
    && FFlag::SimRefactorFieldsToDataRegistry == 1 )
  {
    v16 = *(_QWORD *)(*(_QWORD *)(a1 + 8) + 544LL); /*0x1003103f1*/
    EntityID = RBX::Solver::SolverRigidBody::getEntityID(this: **(RBX::Solver::SolverRigidBody ***)(a1 + 16)); /*0x100310400*/
    v18 = (unsigned __int64 *)&v50; /*0x100310403*/
    v50 = 0; /*0x100310407*/
    v19 = RBX::Ecs::DataRegistry::getComponent<RBX::Vector3>( /*0x100310425*/
            a1: v16,
            a2: EntityID,
            a3: "buoyancyLastForce",
            a4: 0x3E4B81CED894387ELL);
    v20 = (unsigned __int64 *)v19; /*0x10031042a*/
    v21 = 0; /*0x10031042d*/
    if ( v19 != 0 ) /*0x100310433*/
      v21 = *(unsigned int *)(v19 + 8); /*0x100310439*/
    else
      v20 = (unsigned __int64 *)&v50; /*0x100310433*/
    v51 = v21; /*0x10031043e*/
    v47 = (__m128)*v20; /*0x100310446*/
    v50 = 0; /*0x10031044a*/
    v22 = RBX::Ecs::DataRegistry::getComponent<RBX::Vector3>( /*0x100310469*/
            a1: v16,
            a2: EntityID,
            a3: "buoyancyLastTorque",
            a4: 0xD19DDA001E0D4B71LL);
    if ( v22 != 0 ) /*0x100310471*/
      v18 = (unsigned __int64 *)v22; /*0x100310471*/
    v23 = 0.0; /*0x100310475*/
    if ( v22 != 0 ) /*0x100310478*/
      v23 = *(float *)(v22 + 8); /*0x10031047a*/
    v24 = (__m128)*v18; /*0x10031047f*/
    v25 = *(float *)&v51; /*0x100310485*/
    v26 = v47; /*0x100310489*/
  }
  else
  {
    v26 = (__m128)*(unsigned __int64 *)(a2 + 8); /*0x10031048f*/
    v25 = *(float *)(a2 + 16); /*0x100310495*/
    v24 = (__m128)*(unsigned __int64 *)(a2 + 20); /*0x10031049b*/
    v23 = *(float *)(a2 + 28); /*0x1003104a1*/
  }
  v27 = *((float *)&v52 + 1) - _mm_movehdup_ps(v26).f32[0]; /*0x1003104b0*/
  v28 = (__m128)**(unsigned int **)(a1 + 24); /*0x1003104bc*/
  v29 = (float)(v27 * v28.f32[0]) * (float)(v27 * v28.f32[0]); /*0x1003104c4*/
  v30 = _mm_moveldup_ps(v26); /*0x1003104d4*/
  v30.f32[0] = v25; /*0x1003104d8*/
  v31 = _mm_mul_ps(_mm_moveldup_ps(v28), _mm_sub_ps(_mm_insert_ps((__m128)v53, (__m128)(unsigned int)v52, 16), v30)); /*0x1003104e3*/
  v32 = _mm_mul_ps(v31, v31); /*0x1003104e6*/
  v33 = (float)(_mm_movehdup_ps(v32).f32[0] + v29) + v32.f32[0]; /*0x1003104f1*/
  v34 = **(float **)(a1 + 48); /*0x1003104f5*/
  result = true; /*0x1003104f9*/
  if ( v33 <= v34 ) /*0x1003104fe*/
  {
    v36 = _mm_sub_ps((__m128)v48, v24); /*0x100310509*/
    v37 = (__m128)LODWORD(v49); /*0x10031050c*/
    v37.f32[0] = v49 - v23; /*0x100310511*/
    inserted = _mm_insert_ps(v36, v37, 40); /*0x100310515*/
    v39 = *(_QWORD *)(a1 + 32); /*0x10031051b*/
    v40 = _mm_mul_ps(*(__m128 *)v39, inserted); /*0x100310526*/
    v41 = _mm_hadd_ps(v40, v40); /*0x100310529*/
    v42 = _mm_mul_ps(*(__m128 *)(v39 + 12), inserted); /*0x10031052d*/
    v43 = _mm_hadd_ps(v42, v42); /*0x100310530*/
    v44 = _mm_mul_ps( /*0x100310540*/
            _mm_insert_ps((__m128)*(unsigned __int64 *)(v39 + 24), (__m128)*(unsigned int *)(v39 + 32), 40),
            inserted);
    v45 = _mm_hadd_ps(v44, v44); /*0x100310543*/
    inserted.f32[0] = _mm_movehdup_ps(v43).f32[0]; /*0x10031054b*/
    inserted.f32[0] = (float)(inserted.f32[0] + v43.f32[0]) * (float)(inserted.f32[0] + v43.f32[0]); /*0x100310553*/
    v43.f32[0] = _mm_movehdup_ps(v41).f32[0]; /*0x100310557*/
    v43.f32[0] = (float)((float)(v43.f32[0] + v41.f32[0]) * (float)(v43.f32[0] + v41.f32[0])) + inserted.f32[0]; /*0x100310563*/
    v41.f32[0] = _mm_movehdup_ps(v45).f32[0]; /*0x100310567*/
    result = (float)((float)((float)((float)((float)(v41.f32[0] + v45.f32[0]) * (float)(v41.f32[0] + v45.f32[0])) /*0x100310586*/
                                   + v43.f32[0])
                           * **(float **)(a1 + 56))
                   * **(float **)(a1 + 56)) > v34;
  }
  **(_BYTE **)(a1 + 40) = result; /*0x10031058d*/
  return result; /*0x10031058f*/
}

// Address: 0x1003b15e8 | Name: __ZN3RBX10TextLayoutaSEOS0_
__int64 *__fastcall RBX::TextLayout::operator=(__int64 *a1, __int64 *a2)
{
  __int64 v4; // rax
  __int64 v5; // rdi
  __int64 v6; // rsi
  void *v7; // rsi
  __int128 v8; // xmm0
  __int128 v9; // xmm1
  __int128 v10; // xmm2
  __int128 v11; // xmm0
  __int128 v12; // xmm2
  __int128 v13; // xmm3

  v4 = *a2; /*0x1003b15f9*/
  *a2 = 0; /*0x1003b15fc*/
  v5 = *a1; /*0x1003b1603*/
  *a1 = v4; /*0x1003b1606*/
  if ( v5 != 0 ) /*0x1003b160c*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(a1: v5); /*0x1003b1611*/
  v6 = a2[1]; /*0x1003b1618*/
  a2[1] = 0; /*0x1003b161c*/
  std::unique_ptr<RBX::DefinitiveText::Paragraph>::reset[abi:ne200100](a1: a1 + 1, a2: v6); /*0x1003b1624*/
  RBX::SmallVectorImpl<unsigned int>::operator=(a1: (__int64)(a1 + 2), a2: (__int64)(a2 + 2)); /*0x1003b1631*/
  RBX::SmallVectorImpl<unsigned int>::operator=(a1: (__int64)(a1 + 10), a2: (__int64)(a2 + 10)); /*0x1003b163e*/
  RBX::SmallVectorImpl<unsigned int>::operator=(a1: (__int64)(a1 + 18), a2: (__int64)(a2 + 18)); /*0x1003b164f*/
  RBX::SmallVectorImpl<RBX::GlyphLine>::operator=(a1: (__int64)(a1 + 26), a2: (__int64)(a2 + 26)); /*0x1003b1660*/
  if ( (a1[34] & 1) != 0 ) /*0x1003b1679*/
    operator delete(a1: (RBX::Memory *)a1[36], a2: v7); /*0x1003b1682*/
  a1[36] = a2[36]; /*0x1003b168c*/
  *((_OWORD *)a1 + 17) = *((_OWORD *)a2 + 17); /*0x1003b1695*/
  *((_WORD *)a2 + 136) = 0; /*0x1003b1699*/
  if ( (a1[37] & 1) != 0 ) /*0x1003b16b7*/
    operator delete(a1: (RBX::Memory *)a1[39], a2: v7); /*0x1003b16c0*/
  a1[39] = a2[39]; /*0x1003b16ca*/
  *(_OWORD *)(a1 + 37) = *(_OWORD *)(a2 + 37); /*0x1003b16d3*/
  *((_WORD *)a2 + 148) = 0; /*0x1003b16d7*/
  std::__optional_storage_base<RBX::TextStrokeInfo,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::TextStrokeInfo,false>>( /*0x1003b16ed*/
    a1: a1 + 40,
    a2: a2 + 40);
  RSL::Vector<RBX::UI::TextShadowInfo>::operator=(a1: a1 + 46, a2: a2 + 46); /*0x1003b16fe*/
  std::vector<RBX::ShapedGlyph>::__move_assign(a1: a1 + 50, a2: a2 + 50); /*0x1003b170f*/
  std::vector<RBX::Segment>::__move_assign(a1: a1 + 53, a2: a2 + 53); /*0x1003b1720*/
  std::vector<RBX::TextStyleModifier>::__vdeallocate(a1: a1 + 56); /*0x1003b172c*/
  *((_OWORD *)a1 + 28) = *((_OWORD *)a2 + 28); /*0x1003b1739*/
  a1[58] = a2[58]; /*0x1003b1747*/
  *((_OWORD *)a2 + 28) = 0; /*0x1003b1751*/
  a2[58] = 0; /*0x1003b1759*/
  std::vector<RBX::StyleModifierParams>::__move_assign(a1: a1 + 59, a2: a2 + 59); /*0x1003b1770*/
  std::__optional_storage_base<std::string,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<std::string,false>>( /*0x1003b1781*/
    a1: (__int64)(a1 + 62),
    a2: (__int64)(a2 + 62));
  *(_OWORD *)((char *)a1 + 620) = *(_OWORD *)((char *)a2 + 620); /*0x1003b178e*/
  *((_OWORD *)a1 + 38) = *((_OWORD *)a2 + 38); /*0x1003b179d*/
  *((_OWORD *)a1 + 37) = *((_OWORD *)a2 + 37); /*0x1003b17ac*/
  v8 = *((_OWORD *)a2 + 33); /*0x1003b17b3*/
  v9 = *((_OWORD *)a2 + 34); /*0x1003b17bb*/
  v10 = *((_OWORD *)a2 + 35); /*0x1003b17c3*/
  *((_OWORD *)a1 + 36) = *((_OWORD *)a2 + 36); /*0x1003b17d3*/
  *((_OWORD *)a1 + 35) = v10; /*0x1003b17da*/
  *((_OWORD *)a1 + 34) = v9; /*0x1003b17e1*/
  *((_OWORD *)a1 + 33) = v8; /*0x1003b17e8*/
  *(_OWORD *)((char *)a1 + 636) = *(_OWORD *)((char *)a2 + 636); /*0x1003b17f7*/
  *(_OWORD *)((char *)a1 + 652) = *(_OWORD *)((char *)a2 + 652); /*0x1003b1806*/
  *(_OWORD *)((char *)a1 + 668) = *(_OWORD *)((char *)a2 + 668); /*0x1003b1815*/
  v11 = *(_OWORD *)((char *)a2 + 684); /*0x1003b181c*/
  v12 = *(_OWORD *)((char *)a2 + 716); /*0x1003b182c*/
  v13 = *(_OWORD *)((char *)a2 + 732); /*0x1003b1834*/
  *(_OWORD *)((char *)a1 + 700) = *(_OWORD *)((char *)a2 + 700); /*0x1003b183c*/
  *(_OWORD *)((char *)a1 + 716) = v12; /*0x1003b1843*/
  *(_OWORD *)((char *)a1 + 732) = v13; /*0x1003b184a*/
  *(_OWORD *)((char *)a1 + 748) = *(_OWORD *)((char *)a2 + 748); /*0x1003b1859*/
  *(_OWORD *)((char *)a1 + 764) = *(_OWORD *)((char *)a2 + 764); /*0x1003b1868*/
  *(_OWORD *)((char *)a1 + 778) = *(_OWORD *)((char *)a2 + 778); /*0x1003b1877*/
  *(_OWORD *)((char *)a1 + 684) = v11; /*0x1003b187e*/
  return a1; /*0x1003b1888*/
}

// Address: 0x1003ce4b6 | Name: __ZN3RBXL28tryFindGuiObjectForInstancesENS_9ArrayViewINSt3__110shared_ptrINS_8InstanceEEEEE
std::__shared_weak_count **__fastcall RBX::tryFindGuiObjectForInstances(
        std::__shared_weak_count **a1,
        __int64 a2,
        __int64 a3)
{
  std::__shared_weak_count **v3; // r14
  __int64 v4; // r13
  __int64 v5; // r12
  const RBX::GuiObject *v6; // rsi
  RBX *v7; // rdi
  __int64 v8; // rdx
  __int64 v9; // rdi
  __int64 v10; // rsi
  std::__shared_weak_count *i; // rbx
  __int64 v12; // rax
  char v13; // cl
  _QWORD *v14; // rax
  __int64 v15; // r14
  __int64 v16; // rax
  __int64 v17; // rax
  __int64 v18; // r14
  __int64 v19; // rax
  char *v20; // r14
  std::__shared_weak_count *v21; // rax
  void *v22; // r14
  signed __int64 v23; // r14
  unsigned __int64 v24; // rsi
  __int64 v25; // rdx
  __int64 v26; // rbx
  __int64 v27; // r14
  std::__shared_weak_count *v28; // rax
  __int64 v29; // rbx
  void *v30; // rbx
  std::__shared_weak_count *v31; // rax
  void *v32; // rcx
  std::__shared_weak_count *v33; // rbx
  char *v34; // rbx
  char *v35; // r15
  __m128 v36; // xmm0
  __int64 v37; // r14
  __int64 v38; // r13
  __int64 v39; // rdi
  __int64 v40; // rax
  __int64 v41; // rdi
  float v42; // xmm1_4
  __int64 v43; // r13
  __int64 v44; // rax
  __int64 v45; // rdi
  __int64 v46; // r14
  __int64 v47; // rax
  std::__shared_weak_count **v48; // rdi
  float v49; // xmm0_4
  std::__shared_weak_count *v50; // rsi
  std::__shared_weak_count *v51; // rax
  std::__shared_weak_count *v52; // rdx
  std::__shared_weak_count *v53; // rcx
  std::__shared_weak_count *v54; // rbx
  std::__shared_weak_count *v55; // rbx
  __m128 v58; // [rsp+10h] [rbp-A0h]
  float v59; // [rsp+10h] [rbp-A0h]
  float v60; // [rsp+10h] [rbp-A0h]
  std::__shared_weak_count *v61[2]; // [rsp+20h] [rbp-90h] BYREF
  std::__shared_weak_count *v62; // [rsp+30h] [rbp-80h]
  void *v63; // [rsp+38h] [rbp-78h]
  void **v64; // [rsp+40h] [rbp-70h]
  void *__src[2]; // [rsp+50h] [rbp-60h] BYREF
  void *v66; // [rsp+60h] [rbp-50h] BYREF
  float v67; // [rsp+68h] [rbp-48h]
  float v68; // [rsp+6Ch] [rbp-44h]
  std::__shared_weak_count *v69[2]; // [rsp+70h] [rbp-40h] BYREF

  v3 = a1; /*0x1003ce4ca*/
  *(_OWORD *)__src = 0; /*0x1003ce4d0*/
  v66 = nullptr; /*0x1003ce4d4*/
  if ( a3 != 0 ) /*0x1003ce4df*/
  {
    v4 = a2; /*0x1003ce4e8*/
    v5 = a2 + 16 * a3; /*0x1003ce4f6*/
    do /*0x1003ce72b*/
    {
      RBX::Reflection::DescribedBase::fastSharedDynamicCast<RBX::GuiObject,RBX::Instance>(a1: v69, a2: v4); /*0x1003ce504*/
      v7 = v69[0]; /*0x1003ce509*/
      if ( v69[0] == nullptr ) /*0x1003ce510*/
        goto LABEL_37; /*0x1003ce510*/
      if ( DFFlag::EnableCaptureModeNonTextGuiSelection == 0 ) /*0x1003ce51d*/
      {
        if ( (*(__int64 (**)(void))(*(_QWORD *)v69[0] + 1056LL))() == 0 ) /*0x1003ce52b*/
          goto LABEL_37; /*0x1003ce52b*/
        v7 = v69[0]; /*0x1003ce531*/
      }
      if ( !RBX::containsVisibleTextOrImage(this: v7, a2: v6) ) /*0x1003ce53c*/
        goto LABEL_37; /*0x1003ce53c*/
      for ( i = v69[0]; /*0x1003ce542*/
            i != nullptr && DFFlag::DisableCaptureModeTouchGuiCantSelect == 0;
            i = *((std::__shared_weak_count **)i + 13) )
      {
        v12 = *((_QWORD *)i + 14); /*0x1003ce55c*/
        v13 = *(_BYTE *)(v12 + 8); /*0x1003ce560*/
        if ( (v13 & 1) != 0 ) /*0x1003ce566*/
        {
          if ( *(_QWORD *)(v12 + 16) != 8 ) /*0x1003ce578*/
            continue; /*0x1003ce578*/
          v14 = *(_QWORD **)(v12 + 24); /*0x1003ce57a*/
        }
        else
        {
          if ( v13 != 16 ) /*0x1003ce56b*/
            continue; /*0x1003ce56b*/
          v14 = (_QWORD *)(v12 + 9); /*0x1003ce56d*/
        }
        if ( *v14 == 0x6975476863756F54LL ) /*0x1003ce58b*/
        {
          v15 = *((_QWORD *)i + 3); /*0x1003ce58d*/
          v16 = RBX::Reflection::Class_getDescriptorPtr<RBX::ScreenGui>(a1: v9, a2: v10, a3: v8); /*0x1003ce591*/
          v8 = *(unsigned __int16 *)(v16 + 440); /*0x1003ce59e*/
          if ( *(unsigned __int16 *)(v15 + 440) - (unsigned int)v8 <= *(unsigned __int16 *)(v16 + 442) ) /*0x1003ce5b0*/
          {
            v17 = *((_QWORD *)i + 13); /*0x1003ce5b2*/
            if ( v17 != 0 ) /*0x1003ce5b9*/
            {
              v18 = *(_QWORD *)(v17 + 24); /*0x1003ce5bb*/
              v19 = RBX::Reflection::Class_getDescriptorPtr<RBX::PlayerGui>(a1: v9); /*0x1003ce5bf*/
              v8 = *(unsigned __int16 *)(v19 + 440); /*0x1003ce5cc*/
              if ( *(unsigned __int16 *)(v18 + 440) - (unsigned int)v8 <= *(unsigned __int16 *)(v19 + 442) ) /*0x1003ce5de*/
                goto LABEL_37; /*0x1003ce5de*/
            }
          }
        }
      }
      v20 = (char *)__src[1]; /*0x1003ce5ed*/
      if ( __src[1] >= v66 ) /*0x1003ce5f8*/
      {
        v23 = ((char *)__src[1] - (char *)__src[0]) >> 4; /*0x1003ce620*/
        if ( (unsigned __int64)(v23 + 1) > 0xFFFFFFFFFFFFFFFLL ) /*0x1003ce635*/
          std::vector<std::shared_ptr<RBX::GuiObject>>::__throw_length_error[abi:ne200100](); /*0x1003ce970*/
        v24 = (signed __int64)((__int64)v66 - (unsigned __int64)__src[0]) >> 3; /*0x1003ce644*/
        if ( v24 <= v23 + 1 ) /*0x1003ce64b*/
          v24 = v23 + 1; /*0x1003ce64b*/
        if ( (unsigned __int64)v66 - (unsigned __int64)__src[0] >= 0x7FFFFFFFFFFFFFF0LL ) /*0x1003ce65c*/
          v24 = 0xFFFFFFFFFFFFFFFLL; /*0x1003ce65c*/
        v64 = &v66; /*0x1003ce660*/
        if ( v24 != 0 ) /*0x1003ce667*/
        {
          v26 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::shared_ptr<RBX::GuiObject>>>(a1: &v66); /*0x1003ce66e*/
        }
        else
        {
          v26 = 0; /*0x1003ce673*/
          v25 = 0; /*0x1003ce675*/
        }
        v27 = 16 * v23; /*0x1003ce677*/
        v63 = (void *)(v26 + 16 * v25); /*0x1003ce682*/
        v28 = v69[1]; /*0x1003ce686*/
        *(_OWORD *)(v26 + v27) = *(_OWORD *)v69; /*0x1003ce68e*/
        if ( v28 != nullptr ) /*0x1003ce696*/
          _InterlockedIncrement64((volatile signed __int64 *)v28 + 1); /*0x1003ce698*/
        v29 = v27 + v26; /*0x1003ce69d*/
        v22 = (void *)(v29 + 16); /*0x1003ce6a0*/
        v30 = (void *)(v29 - ((char *)__src[1] - (char *)__src[0])); /*0x1003ce6af*/
        memcpy(__dst: v30, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1003ce6b5*/
        v31 = (std::__shared_weak_count *)__src[0]; /*0x1003ce6ba*/
        v32 = v66; /*0x1003ce6be*/
        __src[0] = v30; /*0x1003ce6c2*/
        v61[1] = v31; /*0x1003ce6c6*/
        __src[1] = v22; /*0x1003ce6cd*/
        v62 = v31; /*0x1003ce6d1*/
        v66 = v63; /*0x1003ce6d9*/
        v63 = v32; /*0x1003ce6dd*/
        v61[0] = v31; /*0x1003ce6e1*/
        std::__split_buffer<std::shared_ptr<RBX::GuiObject>>::~__split_buffer(a1: v61); /*0x1003ce6ef*/
      }
      else
      {
        v21 = v69[1]; /*0x1003ce5fa*/
        *(_OWORD *)__src[1] = *(_OWORD *)v69; /*0x1003ce602*/
        if ( v21 != nullptr ) /*0x1003ce609*/
          _InterlockedIncrement64((volatile signed __int64 *)v21 + 1); /*0x1003ce60b*/
        v22 = v20 + 16; /*0x1003ce610*/
      }
      __src[1] = v22; /*0x1003ce6f4*/
LABEL_37:
      v33 = v69[1]; /*0x1003ce6f8*/
      if ( v69[1] != nullptr /*0x1003ce711*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v69[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v33 + 16LL))(a1: v33); /*0x1003ce719*/
        std::__shared_weak_count::__release_weak(this: v33); /*0x1003ce71f*/
      }
      v4 += 16; /*0x1003ce724*/
    }
    while ( v4 != v5 ); /*0x1003ce72b*/
    v34 = (char *)__src[0]; /*0x1003ce731*/
    v35 = (char *)__src[1]; /*0x1003ce735*/
    *(_OWORD *)v61 = 0; /*0x1003ce73c*/
    *(_OWORD *)v69 = 0; /*0x1003ce743*/
    if ( __src[0] != __src[1] ) /*0x1003ce74a*/
    {
      v68 = 0.0; /*0x1003ce753*/
      v67 = 0.0; /*0x1003ce75e*/
      while ( 1 ) /*0x1003ce769*/
      {
        RBX::GuiBase2dProp::getAbsoluteSize(this: (RBX::GuiBase2dProp *)(*(_QWORD *)v34 + 208LL)); /*0x1003ce769*/
        v58 = v36; /*0x1003ce76e*/
        v37 = *(_QWORD *)v34; /*0x1003ce775*/
        v38 = *(_QWORD *)(*(_QWORD *)v34 + 24LL); /*0x1003ce778*/
        v40 = RBX::Reflection::Class_getDescriptorPtr<RBX::TextLabel>(a1: v39); /*0x1003ce77c*/
        v42 = _mm_movehdup_ps(v58).f32[0] * v58.f32[0]; /*0x1003ce78c*/
        if ( *(unsigned __int16 *)(v38 + 440) - (unsigned int)*(unsigned __int16 *)(v40 + 440) <= *(unsigned __int16 *)(v40 + 442) /*0x1003ce809*/
          || (v59 = v42,
              v43 = *(_QWORD *)(v37 + 24),
              v44 = RBX::Reflection::Class_getDescriptorPtr<RBX::TextBox>(a1: v41),
              v42 = v59,
              *(unsigned __int16 *)(v43 + 440) - (unsigned int)*(unsigned __int16 *)(v44 + 440) <= *(unsigned __int16 *)(v44 + 442))
          || (v46 = *(_QWORD *)(v37 + 24),
              v47 = RBX::Reflection::Class_getDescriptorPtr<RBX::GuiTextButton>(a1: v45),
              v42 = v59,
              *(unsigned __int16 *)(v46 + 440) - (unsigned int)*(unsigned __int16 *)(v47 + 440) <= *(unsigned __int16 *)(v47 + 442)) )
        {
          if ( v61[0] == nullptr ) /*0x1003ce832*/
          {
            v48 = v61; /*0x1003ce84c*/
            v49 = v67; /*0x1003ce853*/
LABEL_53:
            v67 = v49; /*0x1003ce858*/
            v60 = v42; /*0x1003ce85d*/
            std::shared_ptr<RBX::GuiObject>::operator=[abi:ne200100](a1: v48, a2: v34); /*0x1003ce867*/
            v68 = v60; /*0x1003ce873*/
            goto LABEL_54; /*0x1003ce873*/
          }
          v48 = v61; /*0x1003ce83c*/
          v49 = v67; /*0x1003ce843*/
          if ( v68 > v42 ) /*0x1003ce848*/
            goto LABEL_53; /*0x1003ce848*/
        }
        else
        {
          if ( v69[0] == nullptr ) /*0x1003ce810*/
          {
            v48 = v69; /*0x1003ce887*/
            v49 = v59; /*0x1003ce88b*/
            v42 = v68; /*0x1003ce88e*/
            goto LABEL_53; /*0x1003ce893*/
          }
          v48 = v69; /*0x1003ce81a*/
          v49 = v59; /*0x1003ce81e*/
          v42 = v68; /*0x1003ce821*/
          if ( v67 > v59 ) /*0x1003ce826*/
            goto LABEL_53; /*0x1003ce826*/
        }
LABEL_54:
        v34 += 16; /*0x1003ce878*/
        if ( v34 == v35 ) /*0x1003ce87f*/
        {
          v50 = v61[0]; /*0x1003ce895*/
          v51 = v61[1]; /*0x1003ce89c*/
          v52 = v69[0]; /*0x1003ce8a3*/
          v53 = v69[1]; /*0x1003ce8a7*/
          goto LABEL_59; /*0x1003ce8ab*/
        }
      }
    }
    v51 = nullptr; /*0x1003ce8c2*/
    v53 = nullptr; /*0x1003ce8c4*/
    v52 = nullptr; /*0x1003ce8c6*/
    v50 = nullptr; /*0x1003ce8c8*/
LABEL_59:
    v3 = a1; /*0x1003ce8ca*/
  }
  else
  {
    *(_OWORD *)v61 = 0; /*0x1003ce8ad*/
    *(_OWORD *)v69 = 0; /*0x1003ce8b4*/
    v51 = nullptr; /*0x1003ce8b8*/
    v53 = nullptr; /*0x1003ce8ba*/
    v52 = nullptr; /*0x1003ce8bc*/
    v50 = nullptr; /*0x1003ce8be*/
  }
  if ( v50 != nullptr ) /*0x1003ce8d4*/
    v52 = v50; /*0x1003ce8d4*/
  *v3 = v52; /*0x1003ce8d8*/
  if ( v50 == nullptr ) /*0x1003ce8db*/
    v51 = v53; /*0x1003ce8db*/
  v3[1] = v51; /*0x1003ce8df*/
  if ( v51 != nullptr ) /*0x1003ce8e6*/
    _InterlockedIncrement64((volatile signed __int64 *)v51 + 1); /*0x1003ce8e8*/
  v54 = v69[1]; /*0x1003ce8ed*/
  if ( v69[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v69[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1003ce906*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, std::__shared_weak_count *, std::__shared_weak_count *, std::__shared_weak_count *))(*(_QWORD *)v54 + 16LL))( /*0x1003ce90e*/
      a1: v54,
      a2: v50,
      a3: v52,
      a4: v53);
    std::__shared_weak_count::__release_weak(this: v54); /*0x1003ce914*/
  }
  v55 = v61[1]; /*0x1003ce919*/
  if ( v61[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v61[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1003ce935*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, std::__shared_weak_count *, std::__shared_weak_count *, std::__shared_weak_count *))(*(_QWORD *)v55 + 16LL))( /*0x1003ce93d*/
      a1: v55,
      a2: v50,
      a3: v52,
      a4: v53);
    std::__shared_weak_count::__release_weak(this: v55); /*0x1003ce943*/
  }
  v61[0] = (std::__shared_weak_count *)__src; /*0x1003ce953*/
  std::vector<std::shared_ptr<RBX::GuiObject>>::__destroy_vector::operator()[abi:ne200100]( /*0x1003ce956*/
    a1: v61,
    a2: v50,
    a3: v52,
    a4: v53);
  return v3; /*0x1003ce95e*/
}

// Address: 0x10044c465 | Name: __ZN3RBX19throwIfMissingQueryERNS_19HttpIncomingMessageENS_13StringLiteralE
__int64 __fastcall RBX::throwIfMissingQuery(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v6; // rax
  __int64 v7; // rdx
  _QWORD *exception; // rbx
  __int64 v10; // rcx
  __int64 v11; // r8
  __int64 v12; // r9
  __m128 v13; // xmm0
  __m128 v14; // xmm1
  __m128 v15; // xmm2
  __m128 v16; // xmm3
  __m128 v17; // xmm4
  __m128 v18; // xmm5
  __m128 v19; // xmm6
  __m128 v20; // xmm7
  char v21[48]; // [rsp+0h] [rbp-30h] BYREF

  v6 = RBX::HttpIncomingMessage::query(a1: a2, a2: a3, a3: a4); /*0x10044c481*/
  if ( v7 == 0 )
  {
    exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10044c4c3*/
    RBX::format(
      this: (RBX *)v21,
      a2: "Missing query parameter: %s",
      a3,
      a4: v10,
      a5: v11,
      a6: v12,
      a7: v13,
      a8: v14,
      a9: v15,
      a10: v16,
      a11: v17,
      a12: v18,
      a13: v19,
      a14: v20,
      a15: v21[0]);
    std::logic_error::logic_error(a1: exception, a2: v21); /*0x10044c4e5*/
    *exception = (char *)&`vtable for'std::invalid_argument + 16; /*0x10044c4f5*/
    __cxa_throw( /*0x10044c50c*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::invalid_argument,
      a3: (void (__fastcall *)(void *))&std::invalid_argument::~invalid_argument);
  }
  if ( v6 != 0 ) /*0x10044c48e*/
  {
    std::string::basic_string[abi:ne200100](a1, a2: v6, a3: v7); /*0x10044c496*/
  }
  else
  {
    *(_OWORD *)a1 = 0; /*0x10044c4a0*/
    *(_QWORD *)(a1 + 16) = 0; /*0x10044c4a3*/
  }
  return a1; /*0x10044c4ae*/
}

// Address: 0x10044fbf5 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEjEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,unsigned int>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned int *a3)
{
  size_t v6; // rax
  __int64 v7; // r9
  unsigned __int8 *v8; // rdx
  __int64 v9; // rsi
  __int64 v10; // rcx
  void *exception; // r15
  _QWORD v12[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v13[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x10044fc0b*/
  v8 = a2 + 1; /*0x10044fc14*/
  v9 = *a2 >> 1; /*0x10044fc1a*/
  if ( (*a2 & 1) != 0 ) /*0x10044fc1f*/
  {
    v8 = *((unsigned __int8 **)a2 + 2); /*0x10044fc1f*/
    v9 = *((_QWORD *)a2 + 1); /*0x10044fc24*/
  }
  v10 = *a3; /*0x10044fc29*/
  v12[0] = v8; /*0x10044fc30*/
  v12[1] = v9; /*0x10044fc33*/
  v12[2] = v10; /*0x10044fc37*/
  fmt::v8::vformat(a1: v13, a2: a1, v6, 45, v12, v7); /*0x10044fc4a*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10044fc59*/
  std::runtime_error::runtime_error(a1: exception, a2: v13); /*0x10044fc63*/
  __cxa_throw( /*0x10044fc79*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x100a94890 | Name: __ZNK3RBX9TweenInfoeqERKS0_
bool __fastcall RBX::TweenInfo::operator==(__int64 a1, __int64 a2)
{
  return *(float *)a1 == *(float *)a2 /*0x100a948de*/
      && *(float *)(a1 + 4) == *(float *)(a2 + 4)
      && *(_DWORD *)(a1 + 8) == *(_DWORD *)(a2 + 8)
      && *(_BYTE *)(a1 + 12) == *(_BYTE *)(a2 + 12)
      && *(float *)(a1 + 16) == *(float *)(a2 + 16)
      && *(_DWORD *)(a1 + 20) == *(_DWORD *)(a2 + 20)
      && *(_DWORD *)(a1 + 24) == *(_DWORD *)(a2 + 24);
}

// Address: 0x100c955c0 | Name: __ZN3RBX24TouchedSignalTouchedSlotclENSt3__110shared_ptrINS_8BasePartEEE
__int64 __fastcall RBX::TouchedSignalTouchedSlot::operator()(__int64 a1, __int64 a2)
{
  __int64 v2; // rax
  __int64 v3; // rdi
  __int64 result; // rax
  std::__shared_weak_count *v5; // rbx
  std::__shared_weak_count *v6[2]; // [rsp+0h] [rbp-20h] BYREF

  v2 = *(_QWORD *)(a2 + 8); /*0x100c955c9*/
  *(_OWORD *)v6 = *(_OWORD *)a2; /*0x100c955d0*/
  if ( v2 != 0 ) /*0x100c955d7*/
    _InterlockedIncrement64((volatile signed __int64 *)(v2 + 8)); /*0x100c955d9*/
  v3 = *(_QWORD *)(a1 + 32); /*0x100c955de*/
  if ( v3 == 0 ) /*0x100c955e5*/
    std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x100c95624*/
  result = (*(__int64 (__fastcall **)(__int64, std::__shared_weak_count **))(*(_QWORD *)v3 + 48LL))(a1: v3, a2: v6); /*0x100c955ee*/
  v5 = v6[1]; /*0x100c955f1*/
  if ( v6[1] != nullptr ) /*0x100c955f8*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v6[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x100c95601*/
    if ( result == 0 ) /*0x100c9560a*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x100c95612*/
      return std::__shared_weak_count::__release_weak(this: v5); /*0x100c95618*/
    }
  }
  return result; /*0x100c9561d*/
}

// Address: 0x100c9582e | Name: __ZN3RBX13TouchedSignalclENSt3__110shared_ptrINS_8BasePartEEE
__int64 RBX::TouchedSignal::operator()()
{
  return rbx::signal<void ()(std::shared_ptr<RBX::BasePart>)>::invokeImpl<(rbx::SignalInvokePolicy)0>(); /*0x100c95832*/
}

// Address: 0x100d20b9d | Name: __ZN3RBX30throwExceptionsBeforeParentingERKNSt3__16vectorINS0_10shared_ptrINS_8InstanceEEENS0_9allocatorIS4_EEEEPS3_
__int64 __fastcall RBX::throwExceptionsBeforeParenting(__int64 a1, __int64 a2)
{
  _QWORD *v2; // r14
  _QWORD *v3; // r15
  __int64 result; // rax

  v2 = *(_QWORD **)a1; /*0x100d20ba7*/
  v3 = *(_QWORD **)(a1 + 8); /*0x100d20baa*/
  if ( *(_QWORD **)a1 != v3 ) /*0x100d20bb1*/
  {
    do /*0x100d20bcc*/
    {
      result = (*(__int64 (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v2 + 376LL))(a1: *v2, a2); /*0x100d20bbf*/
      v2 += 2; /*0x100d20bc5*/
    }
    while ( v2 != v3 ); /*0x100d20bcc*/
  }
  return result; /*0x100d20bd2*/
}

// Address: 0x10128580e | Name: __ZN3RBX19transferKeyIfExistsERKNSt3__110shared_ptrIKNS_10Reflection10ValueTableEEERS3_RKNS0_12basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEESG_
__int64 __fastcall RBX::transferKeyIfExists(_QWORD *a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 result; // rax
  __int64 v7; // rbx
  __int64 v8; // rax
  __int64 v9; // [rsp+8h] [rbp-28h] BYREF
  _BYTE v10[25]; // [rsp+17h] [rbp-19h] BYREF

  result = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::find<std::string>( /*0x101285827*/
             a1: *a1,
             a2: a3);
  if ( result != 0 ) /*0x10128582f*/
  {
    v7 = result; /*0x101285831*/
    v9 = a4; /*0x101285838*/
    v8 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>( /*0x10128584c*/
           a1: a2,
           a2: a4,
           a3: std::piecewise_construct,
           a4: &v9,
           a5: v10);
    *(_QWORD *)(v8 + 40) = *(_QWORD *)(v7 + 40); /*0x101285855*/
    return RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v8 + 48, a2: v7 + 48); /*0x101285864*/
  }
  return result; /*0x101285869*/
}

// Address: 0x101eaf434 | Name: __ZN3RBX14trimBrokenUTF8ERNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
void __fastcall RBX::trimBrokenUTF8(unsigned __int8 *a1)
{
  char v1; // cl
  __int64 v2; // rsi
  unsigned __int8 *v3; // r8
  unsigned __int64 v4; // r9
  __int64 v5; // rax
  unsigned __int64 v6; // rax

  v1 = *a1; /*0x101eaf438*/
  v2 = *a1 >> 1; /*0x101eaf43d*/
  v3 = a1 + 1; /*0x101eaf43f*/
  if ( (*a1 & 1) != 0 ) /*0x101eaf446*/
    v2 = *((_QWORD *)a1 + 1); /*0x101eaf446*/
  if ( (v1 & 1) != 0 ) /*0x101eaf44f*/
    v3 = *((unsigned __int8 **)a1 + 2); /*0x101eaf44f*/
  v4 = 0; /*0x101eaf453*/
  do /*0x101eaf476*/
  {
    if ( v2 <= 0 ) /*0x101eaf460*/
    {
      if ( (v1 & 1) != 0 ) /*0x101eaf490*/
      {
        **((_BYTE **)a1 + 2) = 0; /*0x101eaf499*/
        *((_QWORD *)a1 + 1) = 0; /*0x101eaf49c*/
      }
      else
      {
        *(_WORD *)a1 = 0; /*0x101eaf492*/
      }
      return; /*0x101eaf497*/
    }
    v5 = v3[--v2]; /*0x101eaf462*/
    v6 = RBX::utf8CodepointSize(char)::LUT[v5]; /*0x101eaf46b*/
    ++v4; /*0x101eaf470*/
  }
  while ( v6 == 0 ); /*0x101eaf476*/
  if ( (__int64)v4 >= (__int64)v6 ) /*0x101eaf47b*/
  {
    if ( v4 <= v6 ) /*0x101eaf47d*/
      return; /*0x101eaf47d*/
    v2 += v6; /*0x101eaf482*/
  }
  std::string::resize(a1, a2: v2, a3: 0); /*0x101eaf488*/
}

// Address: 0x1028760fc | Name: __ZN3RBX31throw_runtime_error_safe_formatIJiEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<int>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x10287610f*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 1); /*0x10287612c*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10287613b*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x102876145*/
  __cxa_throw( /*0x10287615b*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x102a378b9 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRPKcS3_S3_EEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*&,char const*&,char const*&>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[56]; // [rsp+38h] [rbp-38h] BYREF

  v2 = strlen(__s: a1); /*0x102a378d4*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 3276); /*0x102a37900*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x102a3790f*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x102a37919*/
  __cxa_throw( /*0x102a3792f*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x102a3797d | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRPKcS2_iEEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*&,char const*,int>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[56]; // [rsp+38h] [rbp-38h] BYREF

  v2 = strlen(__s: a1); /*0x102a37998*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 460); /*0x102a379c3*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x102a379d2*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x102a379dc*/
  __cxa_throw( /*0x102a379f2*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x102a37a3e | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRPKcS3_S2_EEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*&,char const*&,char const*>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[56]; // [rsp+38h] [rbp-38h] BYREF

  v2 = strlen(__s: a1); /*0x102a37a59*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 3276); /*0x102a37a85*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x102a37a94*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x102a37a9e*/
  __cxa_throw( /*0x102a37ab4*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x102a37b00 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRPKcS2_EEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*&,char const*>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x102a37b16*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 204); /*0x102a37b3b*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x102a37b4a*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x102a37b54*/
  __cxa_throw( /*0x102a37b6a*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x102a37bb6 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRPKcS3_EEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*&,char const*&>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x102a37bcc*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 204); /*0x102a37bf1*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x102a37c00*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x102a37c0a*/
  __cxa_throw( /*0x102a37c20*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x102a37c6c | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRPKcS3_S3_S2_EEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*&,char const*&,char const*&,char const*>(
        const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[64]; // [rsp+40h] [rbp-40h] BYREF

  v2 = strlen(__s: a1); /*0x102a37c8c*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 52428); /*0x102a37cc0*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x102a37ccf*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x102a37cd9*/
  __cxa_throw( /*0x102a37cef*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x102a4ece2 | Name: __ZN3RBXL5tostrERKNS_13ColorSequenceE
RBX *__fastcall RBX::tostr(RBX *this, const RBX::ColorSequence *a2)
{
  __int64 v2; // r12
  __int64 v3; // rbx
  __int64 v4; // r13
  __int64 v5; // rbx
  __int64 v6; // rax
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  __int64 v14; // rax
  RBX *v15; // rbx
  void *v16; // rsi
  __int64 (__fastcall **v18)(); // [rsp+8h] [rbp-138h] BYREF
  __int64 (__fastcall **v19)(); // [rsp+10h] [rbp-130h] BYREF
  _BYTE v20[72]; // [rsp+18h] [rbp-128h] BYREF
  void *v21; // [rsp+60h] [rbp-E0h]
  __int64 (__fastcall **v22)(); // [rsp+78h] [rbp-C8h] BYREF
  RBX *v23; // [rsp+110h] [rbp-30h]

  v23 = this; /*0x102a4ecf6*/
  v2 = *(_QWORD *)a2; /*0x102a4ecfa*/
  v3 = *((int *)a2 + 2); /*0x102a4ecfd*/
  std::ostringstream::basic_ostringstream[abi:ne200100](a1: &v18); /*0x102a4ed08*/
  if ( v3 > 0 ) /*0x102a4ed10*/
  {
    v4 = 20 * v3; /*0x102a4ed1a*/
    v5 = 0; /*0x102a4ed1e*/
    do /*0x102a4edcf*/
    {
      v6 = std::ostream::operator<<(a1: &v18, a2: *(float *)(v2 + v5)); /*0x102a4ed37*/
      v7 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v6, a2: " ", a3: 1); /*0x102a4ed47*/
      v8 = std::ostream::operator<<(a1: v7, a2: *(float *)(v2 + v5 + 4)); /*0x102a4ed56*/
      v9 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v8, a2: " ", a3: 1); /*0x102a4ed66*/
      v10 = std::ostream::operator<<(a1: v9, a2: *(float *)(v2 + v5 + 8)); /*0x102a4ed75*/
      v11 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v10, a2: " ", a3: 1); /*0x102a4ed85*/
      v12 = std::ostream::operator<<(a1: v11, a2: *(float *)(v2 + v5 + 12)); /*0x102a4ed94*/
      v13 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v12, a2: " ", a3: 1); /*0x102a4eda4*/
      v14 = std::ostream::operator<<(a1: v13, a2: *(float *)(v2 + v5 + 16)); /*0x102a4edb3*/
      std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v14, a2: " ", a3: 1); /*0x102a4edc3*/
      v5 += 20; /*0x102a4edc8*/
    }
    while ( v4 != v5 ); /*0x102a4edcf*/
  }
  v15 = v23; /*0x102a4eddc*/
  std::stringbuf::str(a1: v23, a2: &v19); /*0x102a4ede3*/
  v18 = &off_10C449768; /*0x102a4edfa*/
  v22 = off_10C449790; /*0x102a4ee02*/
  v19 = &off_10C799250; /*0x102a4ee10*/
  if ( (v20[56] & 1) != 0 ) /*0x102a4ee19*/
    operator delete(a1: (RBX::Memory *)v21, a2: v16); /*0x102a4ee22*/
  v19 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x102a4ee39*/
  std::locale::~locale(this: (std::locale *)v20); /*0x102a4ee3d*/
  std::ostream::~ostream(a1: &v18, a2: off_10C4497A8); /*0x102a4ee54*/
  std::ios::~ios(a1: &v22); /*0x102a4ee5c*/
  return v15; /*0x102a4ee64*/
}

// Address: 0x102a8e3a8 | Name: __ZN3RBX27throwIfNoInternalPermissionEv
void __fastcall RBX::throwIfNoInternalPermission(RBX *this)
{
  std::runtime_error *exception; // rbx

  if ( RBX::hasPermission != 1 || (RBX::studioSettingEnableInternalPermission & 1) == 0 ) /*0x102a8e3bf*/
  {
    exception = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x102a8e3d0*/
    std::runtime_error::runtime_error(this: exception, a2: "Internal Permission is required for this feature."); /*0x102a8e3dd*/
    __cxa_throw( /*0x102a8e3f3*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
}

// Address: 0x102a8f08f | Name: __ZN3RBXL5tostrERKNS_11NumberRangeE
RBX *__fastcall RBX::tostr(RBX *this, const RBX::NumberRange *a2)
{
  __int64 v4; // rax
  __int64 v5; // rax
  __int64 v6; // rax
  void *v7; // rsi
  __int64 (__fastcall **v9)(); // [rsp+0h] [rbp-120h] BYREF
  __int64 (__fastcall **v10)(); // [rsp+8h] [rbp-118h] BYREF
  _BYTE v11[72]; // [rsp+10h] [rbp-110h] BYREF
  void *v12; // [rsp+58h] [rbp-C8h]
  __int64 (__fastcall **v13)(); // [rsp+70h] [rbp-B0h] BYREF

  std::ostringstream::basic_ostringstream[abi:ne200100](a1: &v9); /*0x102a8f0af*/
  v4 = std::ostream::operator<<(a1: &v9, a2: *(float *)a2); /*0x102a8f0bc*/
  v5 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v4, a2: " ", a3: 1); /*0x102a8f0d0*/
  v6 = std::ostream::operator<<(a1: v5, a2: *((float *)a2 + 1)); /*0x102a8f0de*/
  std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v6, a2: " ", a3: 1); /*0x102a8f0f2*/
  std::stringbuf::str(a1: this, a2: &v10); /*0x102a8f101*/
  v9 = &off_10C449768; /*0x102a8f118*/
  v13 = off_10C449790; /*0x102a8f120*/
  v10 = &off_10C799250; /*0x102a8f12e*/
  if ( (v11[56] & 1) != 0 ) /*0x102a8f137*/
    operator delete(a1: (RBX::Memory *)v12, a2: v7); /*0x102a8f140*/
  v10 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x102a8f157*/
  std::locale::~locale(this: (std::locale *)v11); /*0x102a8f15b*/
  std::ostream::~ostream(a1: &v9, a2: off_10C4497A8); /*0x102a8f172*/
  std::ios::~ios(a1: &v13); /*0x102a8f17a*/
  return this; /*0x102a8f182*/
}

// Address: 0x102a9081c | Name: __ZN3RBXL5tostrERKNS_14NumberSequenceE
RBX *__fastcall RBX::tostr(RBX *this, const RBX::NumberSequence *a2)
{
  __int64 v2; // r12
  __int64 v3; // rbx
  __int64 v4; // r13
  __int64 v5; // rbx
  __int64 v6; // rax
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rax
  __int64 v10; // rax
  RBX *v11; // rbx
  void *v12; // rsi
  __int64 (__fastcall **v14)(); // [rsp+8h] [rbp-138h] BYREF
  __int64 (__fastcall **v15)(); // [rsp+10h] [rbp-130h] BYREF
  _BYTE v16[72]; // [rsp+18h] [rbp-128h] BYREF
  void *v17; // [rsp+60h] [rbp-E0h]
  __int64 (__fastcall **v18)(); // [rsp+78h] [rbp-C8h] BYREF
  RBX *v19; // [rsp+110h] [rbp-30h]

  v19 = this; /*0x102a90830*/
  v2 = *(_QWORD *)a2; /*0x102a90834*/
  v3 = *((int *)a2 + 2); /*0x102a90837*/
  std::ostringstream::basic_ostringstream[abi:ne200100](a1: &v14); /*0x102a90842*/
  if ( v3 > 0 ) /*0x102a9084a*/
  {
    v4 = 12 * v3; /*0x102a90850*/
    v5 = 0; /*0x102a90854*/
    do /*0x102a908c7*/
    {
      v6 = std::ostream::operator<<(a1: &v14, a2: *(float *)(v2 + v5)); /*0x102a9086d*/
      v7 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v6, a2: " ", a3: 1); /*0x102a9087d*/
      v8 = std::ostream::operator<<(a1: v7, a2: *(float *)(v2 + v5 + 4)); /*0x102a9088c*/
      v9 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v8, a2: " ", a3: 1); /*0x102a9089c*/
      v10 = std::ostream::operator<<(a1: v9, a2: *(float *)(v2 + v5 + 8)); /*0x102a908ab*/
      std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v10, a2: " ", a3: 1); /*0x102a908bb*/
      v5 += 12; /*0x102a908c0*/
    }
    while ( v4 != v5 ); /*0x102a908c7*/
  }
  v11 = v19; /*0x102a908d0*/
  std::stringbuf::str(a1: v19, a2: &v15); /*0x102a908d7*/
  v14 = &off_10C449768; /*0x102a908ee*/
  v18 = off_10C449790; /*0x102a908f6*/
  v15 = &off_10C799250; /*0x102a90904*/
  if ( (v16[56] & 1) != 0 ) /*0x102a9090d*/
    operator delete(a1: (RBX::Memory *)v17, a2: v12); /*0x102a90916*/
  v15 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x102a9092d*/
  std::locale::~locale(this: (std::locale *)v16); /*0x102a90931*/
  std::ostream::~ostream(a1: &v14, a2: off_10C4497A8); /*0x102a90948*/
  std::ios::~ios(a1: &v18); /*0x102a90950*/
  return v11; /*0x102a90958*/
}

// Address: 0x102a93ab9 | Name: __ZN3RBXL5tostrERKNS_9TweenInfoE
__int64 __fastcall RBX::tostr(__int64 a1, __int64 a2)
{
  int v4; // r14d
  int v5; // r12d
  __int64 v6; // rax
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  const char *v13; // rsi
  __int64 v14; // rax
  __int64 v15; // r13
  char *v16; // rsi
  __int64 v17; // rdx
  __int64 v18; // rax
  __int64 v19; // r12
  char *v20; // rsi
  __int64 v21; // rdx
  void *v22; // rsi
  void *v23; // rsi
  __int64 (__fastcall **v25)(); // [rsp+0h] [rbp-160h] BYREF
  __int64 (__fastcall **v26)(); // [rsp+8h] [rbp-158h] BYREF
  _BYTE v27[72]; // [rsp+10h] [rbp-150h] BYREF
  void *v28; // [rsp+58h] [rbp-108h]
  __int64 (__fastcall **v29)(); // [rsp+70h] [rbp-F0h] BYREF
  unsigned __int8 v30; // [rsp+108h] [rbp-58h] BYREF
  char v31; // [rsp+109h] [rbp-57h] BYREF
  __int64 v32; // [rsp+110h] [rbp-50h]
  void *v33; // [rsp+118h] [rbp-48h]
  unsigned __int8 v34; // [rsp+120h] [rbp-40h] BYREF
  char v35; // [rsp+121h] [rbp-3Fh] BYREF
  __int64 v36; // [rsp+128h] [rbp-38h]
  void *v37; // [rsp+130h] [rbp-30h]

  v4 = RBX::Reflection::EnumDesc<RBX::Enums::EasingStyle>::singleton(); /*0x102a93ad8*/
  v5 = RBX::Reflection::EnumDesc<RBX::Enums::EasingDirection>::singleton(); /*0x102a93ae0*/
  std::ostringstream::basic_ostringstream[abi:ne200100](a1: &v25); /*0x102a93aed*/
  v6 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &v25, a2: "Time:", a3: 5); /*0x102a93b01*/
  v7 = std::ostream::operator<<(a1: v6, a2: *(float *)a2); /*0x102a93b0e*/
  v8 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v7, a2: " DelayTime:", a3: 11); /*0x102a93b22*/
  v9 = std::ostream::operator<<(a1: v8, a2: *(float *)(a2 + 4)); /*0x102a93b30*/
  v10 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v9, a2: " RepeatCount:", a3: 13); /*0x102a93b44*/
  v11 = std::ostream::operator<<(a1: v10, a2: *(unsigned int *)(a2 + 8)); /*0x102a93b50*/
  v12 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v11, a2: " Reverses:", a3: 10); /*0x102a93b64*/
  v13 = "False"; /*0x102a93b75*/
  if ( *(_BYTE *)(a2 + 12) != 0 ) /*0x102a93b7f*/
    v13 = "True"; /*0x102a93b7f*/
  v14 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>( /*0x102a93b8a*/
          a1: v12,
          a2: v13,
          a3: *(unsigned __int8 *)(a2 + 12) ^ 5LL);
  v15 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>( /*0x102a93ba3*/
          a1: v14,
          a2: " EasingDirection:",
          a3: 17);
  RBX::Reflection::EnumDescriptor::_convertToString(this: (RBX::Reflection::EnumDescriptor *)&v30, a2: v5); /*0x102a93bb1*/
  if ( (v30 & 1) != 0 ) /*0x102a93bbd*/
  {
    v16 = (char *)v33; /*0x102a93bbf*/
    v17 = v32; /*0x102a93bc3*/
  }
  else
  {
    v17 = v30 >> 1; /*0x102a93bc9*/
    v16 = &v31; /*0x102a93bcb*/
  }
  v18 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v15, a2: v16, a3: v17); /*0x102a93bd2*/
  v19 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v18, a2: " EasingStyle:", a3: 13); /*0x102a93beb*/
  RBX::Reflection::EnumDescriptor::_convertToString(this: (RBX::Reflection::EnumDescriptor *)&v34, a2: v4); /*0x102a93bf9*/
  if ( (v34 & 1) != 0 ) /*0x102a93c05*/
  {
    v20 = (char *)v37; /*0x102a93c07*/
    v21 = v36; /*0x102a93c0b*/
  }
  else
  {
    v21 = v34 >> 1; /*0x102a93c11*/
    v20 = &v35; /*0x102a93c13*/
  }
  std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v19, a2: v20, a3: v21); /*0x102a93c1a*/
  if ( (v34 & 1) != 0 ) /*0x102a93c23*/
    operator delete(a1: (RBX::Memory *)v37, a2: v22); /*0x102a93c29*/
  if ( (v30 & 1) != 0 ) /*0x102a93c32*/
    operator delete(a1: (RBX::Memory *)v33, a2: v22); /*0x102a93c38*/
  std::stringbuf::str(a1, a2: &v26); /*0x102a93c47*/
  v25 = &off_10C449768; /*0x102a93c5e*/
  v29 = off_10C449790; /*0x102a93c66*/
  v26 = &off_10C799250; /*0x102a93c74*/
  if ( (v27[56] & 1) != 0 ) /*0x102a93c7d*/
    operator delete(a1: (RBX::Memory *)v28, a2: v23); /*0x102a93c86*/
  v26 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x102a93c9d*/
  std::locale::~locale(this: (std::locale *)v27); /*0x102a93ca1*/
  std::ostream::~ostream(a1: &v25, a2: off_10C4497A8); /*0x102a93cb8*/
  std::ios::~ios(a1: &v29); /*0x102a93cc0*/
  return a1; /*0x102a93cc8*/
}

// Address: 0x102a96dc3 | Name: __ZN3RBX8toStringERKNS_8UniqueIdE
RBX *__fastcall RBX::toString(RBX *this, const RBX::UniqueId *a2)
{
  int v3; // edx
  int v4; // ecx
  _BYTE v6[8]; // [rsp+0h] [rbp-20h] BYREF
  unsigned __int32 v7; // [rsp+8h] [rbp-18h]
  unsigned __int32 v8; // [rsp+Ch] [rbp-14h]

  v3 = *(_DWORD *)a2; /*0x102a96ddd*/
  v4 = *((_DWORD *)a2 + 1); /*0x102a96ddf*/
  v6[0] = HIBYTE(*(_DWORD *)a2); /*0x102a96deb*/
  v6[1] = BYTE2(v3); /*0x102a96df3*/
  v6[2] = BYTE1(v3); /*0x102a96df7*/
  v6[3] = v3; /*0x102a96dfa*/
  v6[4] = HIBYTE(v4); /*0x102a96e02*/
  v6[5] = BYTE2(v4); /*0x102a96e0a*/
  v6[6] = BYTE1(v4); /*0x102a96e0d*/
  v6[7] = v4; /*0x102a96e10*/
  v7 = _byteswap_ulong(*((_DWORD *)a2 + 2)); /*0x102a96e18*/
  v8 = _byteswap_ulong(*((_DWORD *)a2 + 3)); /*0x102a96e20*/
  RBX::Crypto::convertToHex(a1: this, a2: v6, a3: 16, a4: 1); /*0x102a96e33*/
  return this; /*0x102a96e4b*/
}

// Address: 0x102ad1bcc | Name: __ZN3RBX31throw_runtime_error_safe_formatIJPKcEEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x102ad1bdf*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 12); /*0x102ad1bfd*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x102ad1c0c*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x102ad1c16*/
  __cxa_throw( /*0x102ad1c2c*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x102ad6302 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEPKcS9_EEEvS9_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string,char const*,char const*>(
        const char *a1,
        unsigned __int8 *a2,
        __int64 *a3,
        __int64 *a4)
{
  size_t v8; // rax
  __int64 v9; // r9
  unsigned __int8 *v10; // rdx
  __int64 v11; // rsi
  __int64 v12; // rcx
  __int64 v13; // rdi
  void *exception; // r15
  _QWORD v15[7]; // [rsp+0h] [rbp-70h] BYREF
  _BYTE v16[56]; // [rsp+38h] [rbp-38h] BYREF

  v8 = strlen(__s: a1); /*0x102ad631d*/
  v10 = a2 + 1; /*0x102ad6327*/
  v11 = *a2 >> 1; /*0x102ad632e*/
  if ( (*a2 & 1) != 0 ) /*0x102ad6333*/
  {
    v10 = *((unsigned __int8 **)a2 + 2); /*0x102ad6333*/
    v11 = *((_QWORD *)a2 + 1); /*0x102ad6339*/
  }
  v12 = *a3; /*0x102ad633f*/
  v13 = *a4; /*0x102ad6342*/
  v15[0] = v10; /*0x102ad6349*/
  v15[1] = v11; /*0x102ad634c*/
  v15[2] = v12; /*0x102ad6350*/
  v15[4] = v13; /*0x102ad6354*/
  fmt::v8::vformat(a1: v16, a2: a1, v8, 3277, v15, v9); /*0x102ad6367*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x102ad6376*/
  std::runtime_error::runtime_error(a1: exception, a2: v16); /*0x102ad6380*/
  __cxa_throw( /*0x102ad6396*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x102ad63e4 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string,std::string>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3)
{
  size_t v6; // rax
  unsigned __int8 *v7; // rdx
  __int64 v8; // rsi
  unsigned __int8 *v9; // rdi
  __int64 v10; // r9
  void *exception; // r15
  _QWORD v12[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v13[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x102ad63fa*/
  v7 = a2 + 1; /*0x102ad6403*/
  v8 = *a2 >> 1; /*0x102ad6409*/
  if ( (*a2 & 1) != 0 ) /*0x102ad640e*/
  {
    v7 = *((unsigned __int8 **)a2 + 2); /*0x102ad640e*/
    v8 = *((_QWORD *)a2 + 1); /*0x102ad6413*/
  }
  v9 = a3 + 1; /*0x102ad641c*/
  v10 = *a3 >> 1; /*0x102ad6423*/
  if ( (*a3 & 1) != 0 ) /*0x102ad6429*/
  {
    v9 = *((unsigned __int8 **)a3 + 2); /*0x102ad6429*/
    v10 = *((_QWORD *)a3 + 1); /*0x102ad642e*/
  }
  v12[0] = v7; /*0x102ad6437*/
  v12[1] = v8; /*0x102ad643a*/
  v12[2] = v9; /*0x102ad643e*/
  v12[3] = v10; /*0x102ad6442*/
  fmt::v8::vformat(a1: v13, a2: a1, v6, 221, v12, v10); /*0x102ad6455*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x102ad6464*/
  std::runtime_error::runtime_error(a1: exception, a2: v13); /*0x102ad646e*/
  __cxa_throw( /*0x102ad6484*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x102b3adf0 | Name: __ZN3RBX22TokenBucketRateLimiterINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEENS_4HashIS7_EEE7consumeES7_f
__int64 __fastcall RBX::TokenBucketRateLimiter<std::string,RBX::Hash<std::string>>::consume(
        float *a1,
        __int128 *a2,
        float a3)
{
  float *v5; // r14
  void *v6; // rsi
  __int64 v7; // rax
  __int128 v9; // [rsp+0h] [rbp-40h] BYREF
  void *v10; // [rsp+10h] [rbp-30h]
  float v11; // [rsp+24h] [rbp-1Ch]

  v11 = a3; /*0x102b3adfd*/
  v5 = a1 + 4; /*0x102b3ae08*/
  if ( std::__hash_table<std::__hash_value_type<std::string,RBX::TokenBucket>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::TokenBucket>,RBX::Hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::TokenBucket>,std::equal_to<std::string>,RBX::Hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::TokenBucket>>>::find<std::string>(a1: a1 + 4) == 0 ) /*0x102b3ae17*/
  {
    if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x102b3ae1c*/
    {
      std::string::__init_copy_ctor_external(a1: &v9, a2: *((_QWORD *)a2 + 2), a3: *((_QWORD *)a2 + 1)); /*0x102b3ae3b*/
    }
    else
    {
      v10 = *((void **)a2 + 2); /*0x102b3ae22*/
      v9 = *a2; /*0x102b3ae29*/
    }
    RBX::TokenBucketRateLimiter<std::string,RBX::Hash<std::string>>::constructBucket( /*0x102b3ae58*/
      a1,
      a2: &v9,
      a3: *a1,
      a4: a1[1],
      a5: a1[2]);
    if ( (v9 & 1) != 0 ) /*0x102b3ae61*/
      operator delete(a1: (RBX::Memory *)v10, a2: v6); /*0x102b3ae67*/
  }
  v7 = std::__hash_table<std::__hash_value_type<std::string,RBX::TokenBucket>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::TokenBucket>,RBX::Hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::TokenBucket>,std::equal_to<std::string>,RBX::Hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::TokenBucket>>>::find<std::string>(a1: v5); /*0x102b3ae72*/
  return RBX::TokenBucket::consume(this: (RBX::TokenBucket *)(v7 + 40), a2: v11); /*0x102b3ae85*/
}

// Address: 0x102b3b6ee | Name: __ZN3RBX22TokenBucketRateLimiterINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEENS_4HashIS7_EEE15constructBucketES7_fff
void __fastcall RBX::TokenBucketRateLimiter<std::string,RBX::Hash<std::string>>::constructBucket(
        __int64 a1,
        __int128 *a2,
        float a3,
        float a4,
        float a5)
{
  __int64 v7; // rbx
  float v8; // xmm1_4
  float v9; // xmm2_4
  __int64 v10; // rdx
  __int64 v11; // rsi
  void *v12; // rsi
  __int128 v13; // [rsp+0h] [rbp-60h] BYREF
  void *v14; // [rsp+10h] [rbp-50h]
  float v15; // [rsp+18h] [rbp-48h]
  float v16; // [rsp+1Ch] [rbp-44h]
  float v17; // [rsp+20h] [rbp-40h]
  double v18; // [rsp+28h] [rbp-38h]
  double v19; // [rsp+38h] [rbp-28h]
  float v20; // [rsp+44h] [rbp-1Ch]
  float v21; // [rsp+48h] [rbp-18h]
  float v22; // [rsp+4Ch] [rbp-14h]

  v22 = a5; /*0x102b3b6f9*/
  v21 = a4; /*0x102b3b6fe*/
  v20 = a3; /*0x102b3b703*/
  v19 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1); /*0x102b3b713*/
  v7 = a1 + 16; /*0x102b3b718*/
  if ( std::__hash_table<std::__hash_value_type<std::string,RBX::TokenBucket>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::TokenBucket>,RBX::Hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::TokenBucket>,std::equal_to<std::string>,RBX::Hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::TokenBucket>>>::find<std::string>(a1: v7) == 0 ) /*0x102b3b72a*/
  {
    v8 = fminf(v22, v20); /*0x102b3b73a*/
    if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x102b3b742*/
    {
      v10 = *((_QWORD *)a2 + 1); /*0x102b3b759*/
      v11 = *((_QWORD *)a2 + 2); /*0x102b3b75d*/
      v22 = v8; /*0x102b3b765*/
      std::string::__init_copy_ctor_external(a1: &v13, a2: v11, a3: v10); /*0x102b3b76a*/
      v9 = v20; /*0x102b3b76f*/
      v8 = v22; /*0x102b3b774*/
    }
    else
    {
      v9 = v20; /*0x102b3b744*/
      v14 = *((void **)a2 + 2); /*0x102b3b74b*/
      v13 = *a2; /*0x102b3b753*/
    }
    v15 = v9; /*0x102b3b787*/
    v16 = v21; /*0x102b3b78c*/
    v17 = v8; /*0x102b3b791*/
    v18 = v19; /*0x102b3b796*/
    std::__hash_table<std::__hash_value_type<std::string,RBX::TokenBucket>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::TokenBucket>,RBX::Hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::TokenBucket>,std::equal_to<std::string>,RBX::Hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::TokenBucket>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,RBX::TokenBucket>>( /*0x102b3b7a1*/
      a1: v7,
      a2: &v13);
    if ( (v13 & 1) != 0 ) /*0x102b3b7aa*/
      operator delete(a1: (RBX::Memory *)v14, a2: v12); /*0x102b3b7b0*/
  }
}

// Address: 0x102b3d63a | Name: __ZN3RBX22TokenBucketRateLimiterINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEENS_4HashIS7_EEE26setDefaultBucketParametersEfffb
void __fastcall RBX::TokenBucketRateLimiter<std::string,RBX::Hash<std::string>>::setDefaultBucketParameters(
        __int64 a1,
        void *a2,
        float a3,
        float a4,
        float a5)
{
  float *i; // rax
  float v6; // xmm0_4
  __int64 *j; // r14
  __int128 v8; // [rsp+0h] [rbp-50h] BYREF
  void *v9; // [rsp+10h] [rbp-40h]
  __int128 v10; // [rsp+18h] [rbp-38h]
  __int64 v11; // [rsp+28h] [rbp-28h]
  float v12; // [rsp+30h] [rbp-20h]
  float v13; // [rsp+34h] [rbp-1Ch]

  v13 = a3; /*0x102b3d647*/
  *(float *)a1 = a3; /*0x102b3d64c*/
  v12 = a4; /*0x102b3d650*/
  *(float *)(a1 + 4) = a4; /*0x102b3d655*/
  *(float *)(a1 + 8) = a5; /*0x102b3d65a*/
  if ( (_DWORD)a2 != 0 ) /*0x102b3d661*/
  {
    if ( FFlag::g_flagsLoaded == 1 && DFFlag::FixRateLimiterSetExistingBucketsByValue == 1 ) /*0x102b3d67d*/
    {
      for ( i = *(float **)(a1 + 32); i != nullptr; i = *(float **)i ) /*0x102b3d67f*/
      {
        v6 = v13; /*0x102b3d68c*/
        i[10] = v13; /*0x102b3d691*/
        i[12] = fminf(v6, i[12]); /*0x102b3d69b*/
        i[11] = v12; /*0x102b3d6a5*/
      }
    }
    else
    {
      for ( j = *(__int64 **)(a1 + 32); j != nullptr; j = (__int64 *)*j ) /*0x102b3d6b6*/
      {
        if ( (j[2] & 1) != 0 ) /*0x102b3d6c5*/
        {
          std::string::__init_copy_ctor_external(a1: &v8, a2: j[4], a3: j[3]); /*0x102b3d6e7*/
        }
        else
        {
          v9 = (void *)j[4]; /*0x102b3d6cf*/
          v8 = *((_OWORD *)j + 1); /*0x102b3d6d6*/
        }
        v11 = j[7]; /*0x102b3d6f0*/
        v10 = *(_OWORD *)(j + 5); /*0x102b3d6f9*/
        *(float *)&v10 = v13; /*0x102b3d702*/
        *(_QWORD *)((char *)&v10 + 4) = __PAIR64__(COERCE_UNSIGNED_INT(fminf(v13, *((float *)&v10 + 2))), LODWORD(v12)); /*0x102b3d716*/
        if ( (v8 & 1) != 0 ) /*0x102b3d71f*/
          operator delete(a1: (RBX::Memory *)v9, a2); /*0x102b3d725*/
      }
    }
  }
}

// Address: 0x102b3e66c | Name: __ZN3RBX22TokenBucketRateLimiterIN3RSL6StringENS_4HashIS2_EEE26setDefaultBucketParametersEfffb
void __fastcall RBX::TokenBucketRateLimiter<RSL::String,RBX::Hash<RSL::String>>::setDefaultBucketParameters(
        __int64 a1,
        int a2,
        float a3,
        float a4,
        float a5)
{
  float *i; // rax
  __int64 *v6; // r14
  _BYTE v7[32]; // [rsp-60h] [rbp-60h] BYREF
  __int128 v8; // [rsp-40h] [rbp-40h]
  __int64 v9; // [rsp-30h] [rbp-30h]
  float v10; // [rsp-28h] [rbp-28h]
  float j; // [rsp-24h] [rbp-24h]

  *(float *)a1 = a3; /*0x102b3e66c*/
  *(float *)(a1 + 4) = a4; /*0x102b3e670*/
  *(float *)(a1 + 8) = a5; /*0x102b3e675*/
  if ( a2 != 0 ) /*0x102b3e67c*/
  {
    if ( FFlag::g_flagsLoaded == 1 && DFFlag::FixRateLimiterSetExistingBucketsByValue == 1 ) /*0x102b3e6a5*/
    {
      for ( i = *(float **)(a1 + 32); i != nullptr; i = *(float **)i ) /*0x102b3e6ae*/
      {
        i[12] = a3; /*0x102b3e6b7*/
        i[14] = fminf(a3, i[14]); /*0x102b3e6c4*/
        i[13] = a4; /*0x102b3e6c9*/
      }
    }
    else
    {
      v6 = *(__int64 **)(a1 + 32); /*0x102b3e6d8*/
      v10 = a4; /*0x102b3e6df*/
      for ( j = a3; v6 != nullptr; v6 = (__int64 *)*v6 ) /*0x102b3e6e9*/
      {
        std::basic_string<char,std::char_traits<char>,RSL::Detail::Allocator<char>>::basic_string(a1: v7, a2: v6 + 2); /*0x102b3e6fa*/
        v9 = v6[8]; /*0x102b3e703*/
        v8 = *((_OWORD *)v6 + 3); /*0x102b3e70c*/
        *(float *)&v8 = j; /*0x102b3e715*/
        *(_QWORD *)((char *)&v8 + 4) = __PAIR64__(COERCE_UNSIGNED_INT(fminf(j, *((float *)&v8 + 2))), LODWORD(v10)); /*0x102b3e729*/
        RSL::String::~String(this: (RSL::String *)v7); /*0x102b3e731*/
      }
    }
  }
}

// Address: 0x102b3e74a | Name: __ZN3RBX22TokenBucketRateLimiterIN3RSL6StringENS_4HashIS2_EEE7consumeES2_f
__int64 __fastcall RBX::TokenBucketRateLimiter<RSL::String,RBX::Hash<RSL::String>>::consume(
        float *a1,
        __int64 a2,
        float a3)
{
  float *v5; // r14
  __int64 v6; // rax
  _BYTE v8[36]; // [rsp+8h] [rbp-48h] BYREF
  float v9; // [rsp+2Ch] [rbp-24h]

  v9 = a3; /*0x102b3e759*/
  v5 = a1 + 4; /*0x102b3e764*/
  if ( std::__hash_table<std::__hash_value_type<RSL::String,RBX::TokenBucket>,std::__unordered_map_hasher<RSL::String,std::__hash_value_type<RSL::String,RBX::TokenBucket>,RBX::Hash<RSL::String>,std::equal_to<RSL::String>,true>,std::__unordered_map_equal<RSL::String,std::__hash_value_type<RSL::String,RBX::TokenBucket>,std::equal_to<RSL::String>,RBX::Hash<RSL::String>,true>,std::allocator<std::__hash_value_type<RSL::String,RBX::TokenBucket>>>::find<RSL::String>( /*0x102b3e773*/
         a1: a1 + 4,
         a2) == 0 )
  {
    std::basic_string<char,std::char_traits<char>,RSL::Detail::Allocator<char>>::basic_string(a1: v8, a2); /*0x102b3e77f*/
    RBX::TokenBucketRateLimiter<RSL::String,RBX::Hash<RSL::String>>::constructBucket( /*0x102b3e79b*/
      a1,
      a2: v8,
      a3: *a1,
      a4: a1[1],
      a5: a1[2]);
    RSL::String::~String(this: (RSL::String *)v8); /*0x102b3e7a4*/
  }
  v6 = std::__hash_table<std::__hash_value_type<RSL::String,RBX::TokenBucket>,std::__unordered_map_hasher<RSL::String,std::__hash_value_type<RSL::String,RBX::TokenBucket>,RBX::Hash<RSL::String>,std::equal_to<RSL::String>,true>,std::__unordered_map_equal<RSL::String,std::__hash_value_type<RSL::String,RBX::TokenBucket>,std::equal_to<RSL::String>,RBX::Hash<RSL::String>,true>,std::allocator<std::__hash_value_type<RSL::String,RBX::TokenBucket>>>::find<RSL::String>( /*0x102b3e7af*/
         a1: v5,
         a2);
  return RBX::TokenBucket::consume(this: (RBX::TokenBucket *)(v6 + 48), a2: v9); /*0x102b3e7c2*/
}

// Address: 0x102b3eaa4 | Name: __ZN3RBX22TokenBucketRateLimiterIN3RSL6StringENS_4HashIS2_EEE15constructBucketES2_fff
void __fastcall RBX::TokenBucketRateLimiter<RSL::String,RBX::Hash<RSL::String>>::constructBucket(
        __int64 a1,
        __int64 a2,
        float a3,
        float a4,
        float a5)
{
  __int64 v7; // rbx
  _BYTE v8[32]; // [rsp+8h] [rbp-68h] BYREF
  unsigned __int64 v9; // [rsp+28h] [rbp-48h]
  float v10; // [rsp+30h] [rbp-40h]
  double v11; // [rsp+38h] [rbp-38h]
  double v12; // [rsp+40h] [rbp-30h]
  float v13; // [rsp+4Ch] [rbp-24h]
  float v14; // [rsp+50h] [rbp-20h]
  float v15; // [rsp+54h] [rbp-1Ch]

  v15 = a5; /*0x102b3eab1*/
  v13 = a4; /*0x102b3eab6*/
  v14 = a3; /*0x102b3eabb*/
  v12 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1); /*0x102b3eacb*/
  v7 = a1 + 16; /*0x102b3ead0*/
  if ( std::__hash_table<std::__hash_value_type<RSL::String,RBX::TokenBucket>,std::__unordered_map_hasher<RSL::String,std::__hash_value_type<RSL::String,RBX::TokenBucket>,RBX::Hash<RSL::String>,std::equal_to<RSL::String>,true>,std::__unordered_map_equal<RSL::String,std::__hash_value_type<RSL::String,RBX::TokenBucket>,std::equal_to<RSL::String>,RBX::Hash<RSL::String>,true>,std::allocator<std::__hash_value_type<RSL::String,RBX::TokenBucket>>>::find<RSL::String>( /*0x102b3eae2*/
         a1: v7,
         a2) == 0 )
  {
    v15 = fminf(v15, v14); /*0x102b3eaee*/
    std::basic_string<char,std::char_traits<char>,RSL::Detail::Allocator<char>>::basic_string(a1: v8, a2); /*0x102b3eafd*/
    v9 = __PAIR64__(LODWORD(v13), LODWORD(v14)); /*0x102b3eb07*/
    v10 = v15; /*0x102b3eb1d*/
    v11 = v12; /*0x102b3eb28*/
    std::__hash_table<std::__hash_value_type<RSL::String,RBX::TokenBucket>,std::__unordered_map_hasher<RSL::String,std::__hash_value_type<RSL::String,RBX::TokenBucket>,RBX::Hash<RSL::String>,std::equal_to<RSL::String>,true>,std::__unordered_map_equal<RSL::String,std::__hash_value_type<RSL::String,RBX::TokenBucket>,std::equal_to<RSL::String>,RBX::Hash<RSL::String>,true>,std::allocator<std::__hash_value_type<RSL::String,RBX::TokenBucket>>>::__emplace_unique_key_args<RSL::String,std::pair<RSL::String const,RBX::TokenBucket>>( /*0x102b3eb37*/
      a1: v7,
      a2: v8,
      a3: v8);
    RSL::String::~String(this: (RSL::String *)v8); /*0x102b3eb40*/
  }
}

// Address: 0x102bc7ea0 | Name: __ZN3RBX11TDigestImplaSERKS0_
__int64 __fastcall RBX::TDigestImpl::operator=(__int64 a1, __int64 a2)
{
  __int64 v4; // rdx

  if ( a1 != a2 ) /*0x102bc7ead*/
  {
    *(_QWORD *)a1 = *(_QWORD *)a2; /*0x102bc7eb6*/
    *(_DWORD *)(a1 + 8) = *(_DWORD *)(a2 + 8); /*0x102bc7ebd*/
    *(_OWORD *)(a1 + 16) = *(_OWORD *)(a2 + 16); /*0x102bc7ec4*/
    *(_QWORD *)(a1 + 32) = *(_QWORD *)(a2 + 32); /*0x102bc7ecd*/
    v4 = *(int *)(a2 + 40); /*0x102bc7ed2*/
    *(_DWORD *)(a1 + 40) = v4; /*0x102bc7ed6*/
    *(_BYTE *)(a1 + 44) = *(_BYTE *)(a2 + 44); /*0x102bc7edc*/
    memcpy(__dst: *(void **)(a1 + 48), __src: *(const void **)(a2 + 48), __n: 8 * v4); /*0x102bc7eeb*/
    memcpy(__dst: *(void **)(a1 + 56), __src: *(const void **)(a2 + 56), __n: 8LL * *(int *)(a1 + 40)); /*0x102bc7f00*/
  }
  return a1; /*0x102bc7f08*/
}

// Address: 0x102bc9c04 | Name: __ZN3RBX14thread_wrapperERKNSt3__18functionIFvvEEEPKc
__int64 __fastcall RBX::thread_wrapper(__int64 a1, __int64 a2, __int64 a3)
{
  unsigned int v6; // ebx
  __int64 v7; // rdx
  __int64 v8; // rcx
  unsigned __int64 v9; // rsi
  unsigned int v10; // esi
  __int64 v11; // r13
  _BYTE *v12; // rdi
  _BYTE *v13; // rdi
  __int64 v14; // rax
  _BYTE v16[32]; // [rsp+0h] [rbp-80h] BYREF
  _BYTE *v17; // [rsp+20h] [rbp-60h]
  __int128 v18; // [rsp+30h] [rbp-50h] BYREF
  __int64 v19; // [rsp+40h] [rbp-40h]

  v6 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::RbxThread, a2); /*0x102bc9c37*/
  std::__function::__value_func<void ()(void)>::__value_func[abi:ne200100](a1: (__int64)v16, a2); /*0x102bc9c43*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v18, a2: a3, a3: v7, a4: v8); /*0x102bc9c52*/
  *(_QWORD *)(a1 + 32) = 0; /*0x102bc9c57*/
  v11 = operator new(a1: (RBX::Memory *)0x60, a2: v9); /*0x102bc9c69*/
  *(_QWORD *)v11 = &off_10C820648; /*0x102bc9c73*/
  v12 = v17; /*0x102bc9c77*/
  if ( v17 != nullptr ) /*0x102bc9c7e*/
  {
    if ( v17 == v16 ) /*0x102bc9c83*/
    {
      *(_QWORD *)(v11 + 48) = v11 + 16; /*0x102bc9ca4*/
      (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v12 + 24LL))(a1: v12); /*0x102bc9cab*/
    }
    else
    {
      *(_QWORD *)(v11 + 48) = (*(__int64 (**)(void))(*(_QWORD *)v17 + 16LL))(); /*0x102bc9c8b*/
    }
    v13 = v17; /*0x102bc9cae*/
  }
  else
  {
    *(_QWORD *)(v11 + 48) = 0; /*0x102bc9c91*/
    v13 = nullptr; /*0x102bc9c99*/
  }
  *(_QWORD *)(v11 + 80) = v19; /*0x102bc9cb7*/
  *(_OWORD *)(v11 + 64) = v18; /*0x102bc9cc0*/
  v18 = 0; /*0x102bc9cc8*/
  v19 = 0; /*0x102bc9ccf*/
  *(_QWORD *)(v11 + 88) = 0; /*0x102bc9cd4*/
  *(_QWORD *)(a1 + 32) = v11; /*0x102bc9cd8*/
  if ( v13 == v16 ) /*0x102bc9cdf*/
  {
    v14 = 32; /*0x102bc9ced*/
  }
  else
  {
    v14 = 40; /*0x102bc9ce1*/
    if ( v13 == nullptr ) /*0x102bc9ce9*/
      goto LABEL_12; /*0x102bc9ce9*/
  }
  (*(void (**)(void))(*(_QWORD *)v13 + v14))(); /*0x102bc9cf5*/
LABEL_12:
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v6, a2: v10); /*0x102bc9cf8*/
  return a1; /*0x102bc9d12*/
}

// Address: 0x102bc9d8a | Name: __ZZN3RBX14thread_wrapperERKNSt3__18functionIFvvEEEPKcEN3$_0D1Ev
__int64 __fastcall RBX::thread_wrapper(std::function<void ()(void)> const&,char const*)::$_0::~$_0(
        __int64 a1,
        void *a2)
{
  _QWORD *v3; // rdi
  __int64 result; // rax

  if ( (*(_BYTE *)(a1 + 48) & 1) != 0 ) /*0x102bc9d97*/
    operator delete(a1: *(RBX::Memory **)(a1 + 64), a2); /*0x102bc9d9d*/
  v3 = *(_QWORD **)(a1 + 32); /*0x102bc9da2*/
  if ( v3 == (_QWORD *)a1 ) /*0x102bc9da9*/
  {
    result = 32; /*0x102bc9dbc*/
    return (*(__int64 (**)(void))(*v3 + result))(); /*0x102bc9dbc*/
  }
  result = 40; /*0x102bc9dab*/
  if ( v3 != nullptr ) /*0x102bc9db3*/
    return (*(__int64 (**)(void))(*v3 + result))(); /*0x102bc9dc1*/
  return result; /*0x102bc9db9*/
}

// Address: 0x102f87ba9 | Name: __ZN3RBXL23trimUrlQueryAndFragmentENS_10StringViewE
RBX::Url *__fastcall RBX::trimUrlQueryAndFragment(RBX::Url *this)
{
  char *v2; // rdi
  __int64 v3; // rax
  void *v4; // rsi
  _BYTE v6[16]; // [rsp+30h] [rbp-140h] BYREF
  void *v7; // [rsp+40h] [rbp-130h]
  char v8; // [rsp+48h] [rbp-128h]
  void *v9; // [rsp+58h] [rbp-118h]
  char v10; // [rsp+60h] [rbp-110h]
  void *v11; // [rsp+70h] [rbp-100h]
  char v12; // [rsp+78h] [rbp-F8h]
  void *v13; // [rsp+88h] [rbp-E8h]
  char v14; // [rsp+90h] [rbp-E0h]
  void *v15; // [rsp+A0h] [rbp-D0h]
  char v16; // [rsp+B0h] [rbp-C0h] BYREF
  void *v17; // [rsp+C0h] [rbp-B0h]
  char v18; // [rsp+C8h] [rbp-A8h]
  void *v19; // [rsp+D8h] [rbp-98h]
  unsigned __int8 v20; // [rsp+E0h] [rbp-90h]
  char v21; // [rsp+E1h] [rbp-8Fh] BYREF
  __int64 v22; // [rsp+E8h] [rbp-88h]
  void *v23; // [rsp+F0h] [rbp-80h]
  char v24; // [rsp+F8h] [rbp-78h]
  void *v25; // [rsp+108h] [rbp-68h]
  char v26; // [rsp+110h] [rbp-60h]
  void *v27; // [rsp+120h] [rbp-50h]
  char v28[16]; // [rsp+130h] [rbp-40h]
  char v29[16]; // [rsp+140h] [rbp-30h]
  char v30[16]; // [rsp+150h] [rbp-20h]

  RBX::Url::fromString(this: (RBX::Url *)&v16); /*0x102f87bc4*/
  if ( (v20 & 1) != 0 ) /*0x102f87c1c*/
  {
    v2 = (char *)v23; /*0x102f87c1e*/
    v3 = v22; /*0x102f87c22*/
  }
  else
  {
    v3 = v20 >> 1; /*0x102f87c2b*/
    v2 = &v21; /*0x102f87c2d*/
  }
  *(_QWORD *)v28 = v2; /*0x102f87c34*/
  *(_QWORD *)&v28[8] = v3; /*0x102f87c38*/
  *(_QWORD *)v29 = ""; /*0x102f87c43*/
  *(_QWORD *)&v29[8] = 0; /*0x102f87c49*/
  *(_QWORD *)v30 = ""; /*0x102f87c4d*/
  *(_QWORD *)&v30[8] = 0; /*0x102f87c51*/
  RBX::Url::fromComponents(this: (RBX::Url *)v6, a2: (char)v2, a3: v3, a4: (char)"", a5: 0, a6: (char)""); /*0x102f87c76*/
  RBX::Url::asString(this); /*0x102f87c85*/
  if ( (v14 & 1) != 0 ) /*0x102f87c91*/
    operator delete(a1: (RBX::Memory *)v15, a2: v4); /*0x102f87c9a*/
  if ( (v12 & 1) != 0 ) /*0x102f87ca6*/
    operator delete(a1: (RBX::Memory *)v13, a2: v4); /*0x102f87caf*/
  if ( (v10 & 1) != 0 ) /*0x102f87cbb*/
    operator delete(a1: (RBX::Memory *)v11, a2: v4); /*0x102f87cc4*/
  if ( (v8 & 1) != 0 ) /*0x102f87cd0*/
    operator delete(a1: (RBX::Memory *)v9, a2: v4); /*0x102f87cd9*/
  if ( (v6[0] & 1) != 0 ) /*0x102f87ce5*/
    operator delete(a1: (RBX::Memory *)v7, a2: v4); /*0x102f87cee*/
  if ( (v26 & 1) != 0 ) /*0x102f87cf7*/
    operator delete(a1: (RBX::Memory *)v27, a2: v4); /*0x102f87cfd*/
  if ( (v24 & 1) != 0 ) /*0x102f87d06*/
    operator delete(a1: (RBX::Memory *)v25, a2: v4); /*0x102f87d0c*/
  if ( (v20 & 1) != 0 ) /*0x102f87d18*/
    operator delete(a1: (RBX::Memory *)v23, a2: v4); /*0x102f87d1e*/
  if ( (v18 & 1) != 0 ) /*0x102f87d2a*/
    operator delete(a1: (RBX::Memory *)v19, a2: v4); /*0x102f87d33*/
  if ( (v16 & 1) != 0 ) /*0x102f87d3f*/
    operator delete(a1: (RBX::Memory *)v17, a2: v4); /*0x102f87d48*/
  return this; /*0x102f87d50*/
}

// Address: 0x102f90bbf | Name: __ZN3RBX16trimCookieDomainERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
unsigned __int8 *__fastcall RBX::trimCookieDomain(unsigned __int8 *a1, unsigned __int8 *a2)
{
  unsigned int v3; // ecx
  _DWORD *v4; // rax
  unsigned __int64 v5; // rcx
  char *v6; // rsi
  unsigned int v7; // eax
  char *v8; // rdx
  unsigned __int8 *v9; // rdi
  __int64 v10; // rdx
  char *v11; // rcx
  bool v12; // r8
  char *v14; // rcx
  __int128 v16; // [rsp+0h] [rbp-30h] BYREF
  __int64 v17; // [rsp+10h] [rbp-20h]
  _BYTE v18[17]; // [rsp+1Fh] [rbp-11h] BYREF

  *(_OWORD *)a1 = 0; /*0x102f90bd0*/
  *((_QWORD *)a1 + 2) = 0; /*0x102f90bd3*/
  v3 = *a2; /*0x102f90bdb*/
  if ( (v3 & 1) != 0 ) /*0x102f90be1*/
  {
    v4 = *((_DWORD **)a2 + 2); /*0x102f90be3*/
    v5 = *((_QWORD *)a2 + 1); /*0x102f90be7*/
  }
  else
  {
    v4 = a2 + 1; /*0x102f90bed*/
    v5 = v3 >> 1; /*0x102f90bf1*/
  }
  if ( v5 < 2 ) /*0x102f90bf7*/
    goto LABEL_8; /*0x102f90bf7*/
  if ( *(_WORD *)v4 == 11885 ) /*0x102f90bfe*/
  {
    std::string::basic_string(a1: &v16, a2, a3: 2, a4: -1, a5: v18); /*0x102f90c2c*/
  }
  else
  {
    if ( v5 < 4 || *v4 != 779581303 ) /*0x102f90c0c*/
    {
LABEL_8:
      std::string::operator=(a1, a2); /*0x102f90c0e*/
      goto LABEL_14; /*0x102f90c16*/
    }
    std::string::basic_string(a1: &v16, a2, a3: 4, a4: -1, a5: v18); /*0x102f90c47*/
  }
  if ( (*a1 & 1) != 0 ) /*0x102f90c4f*/
    operator delete(a1: *((RBX::Memory **)a1 + 2), a2: v6); /*0x102f90c55*/
  *((_QWORD *)a1 + 2) = v17; /*0x102f90c5e*/
  *(_OWORD *)a1 = v16; /*0x102f90c66*/
LABEL_14:
  v7 = *a1; /*0x102f90c69*/
  if ( (v7 & 1) != 0 ) /*0x102f90c6e*/
  {
    v6 = *((char **)a1 + 1); /*0x102f90c7f*/
    if ( v6 == nullptr ) /*0x102f90c86*/
    {
      v10 = 0; /*0x102f90cab*/
      goto LABEL_35; /*0x102f90cad*/
    }
  }
  else
  {
    if ( *a1 == 0 ) /*0x102f90c73*/
    {
LABEL_33:
      v17 = *((_QWORD *)a1 + 2); /*0x102f90d12*/
      v16 = *(_OWORD *)a1; /*0x102f90d1d*/
      goto LABEL_36; /*0x102f90d21*/
    }
    v6 = (char *)(v7 >> 1); /*0x102f90c7b*/
  }
  v8 = v6 - 1; /*0x102f90c8b*/
  if ( v6 != (char *)1 && v6 + 4 > v6 - 1 )
  {
    v9 = (v7 & 1) != 0 ? *((unsigned __int8 **)a1 + 2) : a1 + 1;
    v6 += 3; /*0x102f90cb3*/
    while ( (unsigned __int8)(v6[(_QWORD)v9 - 4] - 48) <= 9u ) /*0x102f90cc1*/
    {
      v11 = v6 - 1; /*0x102f90cc3*/
      v12 = v6 == (char *)5; /*0x102f90ccb*/
      if ( v6 != (char *)5 && v6-- > v8 ) /*0x102f90cd1*/
        continue; /*0x102f90cd7*/
      v14 = v11 - 4; /*0x102f90cd9*/
      goto LABEL_29; /*0x102f90cdd*/
    }
    v6 -= 4; /*0x102f90cdf*/
    v12 = false; /*0x102f90ce3*/
    v14 = v6; /*0x102f90ce6*/
LABEL_29:
    if ( !v12 && v14 != v8 && v14[(_QWORD)v9] == 58 ) /*0x102f90cf8*/
    {
      std::string::basic_string(a1: &v16, a2: a1, a3: 0, a4: v14, a5: v18); /*0x102f90d07*/
      goto LABEL_36; /*0x102f90d0c*/
    }
  }
  if ( (v7 & 1) == 0 ) /*0x102f90d10*/
    goto LABEL_33; /*0x102f90d10*/
  v10 = *((_QWORD *)a1 + 1); /*0x102f90d23*/
LABEL_35:
  std::string::__init_copy_ctor_external(a1: &v16, a2: *((_QWORD *)a1 + 2), a3: v10); /*0x102f90d27*/
LABEL_36:
  if ( (*a1 & 1) != 0 ) /*0x102f90d37*/
    operator delete(a1: *((RBX::Memory **)a1 + 2), a2: v6); /*0x102f90d3d*/
  *((_QWORD *)a1 + 2) = v17; /*0x102f90d46*/
  *(_OWORD *)a1 = v16; /*0x102f90d4e*/
  return a1; /*0x102f90d54*/
}

// Address: 0x103688cd0 | Name: __ZN3RBX22TokenBucketRateLimiterINS_18PerformanceControl9EventTypeENS_4HashIS2_EEE7consumeES2_f
__int64 __fastcall RBX::TokenBucketRateLimiter<RBX::PerformanceControl::EventType,RBX::Hash<RBX::PerformanceControl::EventType>>::consume(
        float *a1,
        int a2,
        float a3)
{
  float *v4; // rbx
  __int64 v5; // rax
  _DWORD v8[5]; // [rsp+Ch] [rbp-14h] BYREF

  v8[0] = a2; /*0x103688ce7*/
  v4 = a1 + 4; /*0x103688ce9*/
  if ( std::__hash_table<std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,std::__unordered_map_hasher<RBX::PerformanceControl::EventType,std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,RBX::Hash<RBX::PerformanceControl::EventType>,std::equal_to<RBX::PerformanceControl::EventType>,true>,std::__unordered_map_equal<RBX::PerformanceControl::EventType,std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,std::equal_to<RBX::PerformanceControl::EventType>,RBX::Hash<RBX::PerformanceControl::EventType>,true>,std::allocator<std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>>>::find<RBX::PerformanceControl::EventType>( /*0x103688cfb*/
         a1: a1 + 4,
         a2: v8) == 0 )
    RBX::TokenBucketRateLimiter<RBX::PerformanceControl::EventType,RBX::Hash<RBX::PerformanceControl::EventType>>::constructBucket( /*0x103688d14*/
      a1,
      a2: v8[0],
      a3: *a1,
      a4: a1[1],
      a5: a1[2]);
  v5 = std::__hash_table<std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,std::__unordered_map_hasher<RBX::PerformanceControl::EventType,std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,RBX::Hash<RBX::PerformanceControl::EventType>,std::equal_to<RBX::PerformanceControl::EventType>,true>,std::__unordered_map_equal<RBX::PerformanceControl::EventType,std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,std::equal_to<RBX::PerformanceControl::EventType>,RBX::Hash<RBX::PerformanceControl::EventType>,true>,std::allocator<std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>>>::find<RBX::PerformanceControl::EventType>( /*0x103688d20*/
         a1: v4,
         a2: v8);
  return RBX::TokenBucket::consume(this: (RBX::TokenBucket *)(v5 + 24), a2: a3); /*0x103688d33*/
}

// Address: 0x103688eaa | Name: __ZN3RBX22TokenBucketRateLimiterINS_18PerformanceControl9EventTypeENS_4HashIS2_EEE15constructBucketES2_fff
__int64 __fastcall RBX::TokenBucketRateLimiter<RBX::PerformanceControl::EventType,RBX::Hash<RBX::PerformanceControl::EventType>>::constructBucket(
        __int64 a1,
        int a2,
        float a3,
        float a4,
        float a5)
{
  __int64 v6; // rbx
  __int64 result; // rax
  int v8; // [rsp+8h] [rbp-48h] BYREF
  unsigned __int64 v9; // [rsp+10h] [rbp-40h]
  float v10; // [rsp+18h] [rbp-38h]
  double v11; // [rsp+20h] [rbp-30h]
  double v12; // [rsp+28h] [rbp-28h]
  int v13; // [rsp+30h] [rbp-20h] BYREF
  float v14; // [rsp+34h] [rbp-1Ch]
  float v15; // [rsp+38h] [rbp-18h]
  float v16; // [rsp+3Ch] [rbp-14h]

  v14 = a5; /*0x103688eb5*/
  v15 = a4; /*0x103688eba*/
  v16 = a3; /*0x103688ebf*/
  v13 = a2; /*0x103688ecb*/
  v12 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1); /*0x103688ed3*/
  v6 = a1 + 16; /*0x103688ed8*/
  result = std::__hash_table<std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,std::__unordered_map_hasher<RBX::PerformanceControl::EventType,std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,RBX::Hash<RBX::PerformanceControl::EventType>,std::equal_to<RBX::PerformanceControl::EventType>,true>,std::__unordered_map_equal<RBX::PerformanceControl::EventType,std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,std::equal_to<RBX::PerformanceControl::EventType>,RBX::Hash<RBX::PerformanceControl::EventType>,true>,std::allocator<std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>>>::find<RBX::PerformanceControl::EventType>( /*0x103688ee2*/
             a1: v6,
             a2: &v13);
  if ( result == 0 ) /*0x103688eea*/
  {
    v8 = v13; /*0x103688f01*/
    v9 = __PAIR64__(LODWORD(v15), LODWORD(v16)); /*0x103688f03*/
    v10 = fminf(v14, v16); /*0x103688f12*/
    v11 = v12; /*0x103688f1c*/
    return std::__hash_table<std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,std::__unordered_map_hasher<RBX::PerformanceControl::EventType,std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,RBX::Hash<RBX::PerformanceControl::EventType>,std::equal_to<RBX::PerformanceControl::EventType>,true>,std::__unordered_map_equal<RBX::PerformanceControl::EventType,std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>,std::equal_to<RBX::PerformanceControl::EventType>,RBX::Hash<RBX::PerformanceControl::EventType>,true>,std::allocator<std::__hash_value_type<RBX::PerformanceControl::EventType,RBX::TokenBucket>>>::__emplace_unique_key_args<RBX::PerformanceControl::EventType,std::pair<RBX::PerformanceControl::EventType const,RBX::TokenBucket>>( /*0x103688f27*/
             a1: v6,
             a2: &v8);
  }
  return result; /*0x103688f2c*/
}

// Address: 0x103f9f5d0 | Name: __ZN3RBXL24term_destination_chunkedEP20jpeg_compress_struct
_DWORD *__fastcall RBX::term_destination_chunked(__int64 a1)
{
  _DWORD *result; // rax

  result = *(_DWORD **)(a1 + 40); /*0x103f9f5d4*/
  result[13] = *result - result[10]; /*0x103f9f5dd*/
  return result; /*0x103f9f5e0*/
}

// Address: 0x103f9f620 | Name: __ZN3RBXL27term_destination_DEPRECATEDEP20jpeg_compress_struct
_DWORD *__fastcall RBX::term_destination_DEPRECATED(__int64 a1)
{
  _DWORD *result; // rax

  result = *(_DWORD **)(a1 + 40); /*0x103f9f624*/
  result[13] = result[12] - result[2]; /*0x103f9f62e*/
  return result; /*0x103f9f631*/
}

// Address: 0x103f9f72c | Name: __ZN3RBXL11term_sourceEP22jpeg_decompress_struct
void RBX::term_source()
{
  ; /*0x103f9f72c*/
}

// Address: 0x103fa1e70 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRiEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<int &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x103fa1e83*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 1); /*0x103fa1ea0*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x103fa1eaf*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x103fa1eb9*/
  __cxa_throw( /*0x103fa1ecf*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x103fafc04 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRjS1_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<unsigned int &,unsigned int &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x103fafc1a*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 34); /*0x103fafc3e*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x103fafc4d*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x103fafc57*/
  __cxa_throw( /*0x103fafc6d*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1040ac51e | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNS_20ReadOnlySharedBufferEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::ReadOnlySharedBuffer const&>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1040ac531*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 15); /*0x1040ac557*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1040ac566*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1040ac570*/
  __cxa_throw( /*0x1040ac586*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1041ac28e | Name: __ZN3RBX19throw_runtime_errorEPKcz
void __fastcall __noreturn RBX::throw_runtime_error(
        RBX *this,
        const char *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __m128 a7,
        __m128 a8,
        __m128 a9,
        __m128 a10,
        __m128 a11,
        __m128 a12,
        __m128 a13,
        __m128 a14,
        char a15)
{
  void *exception; // r14
  _QWORD v16[22]; // [rsp+0h] [rbp-100h] BYREF
  unsigned __int8 v17[32]; // [rsp+B0h] [rbp-50h] BYREF
  __va_list_tag v18; // [rsp+D0h] [rbp-30h] BYREF

  *(__m128 *)&v16[6] = a7; /*0x1041ac28e*/
  *(__m128 *)&v16[8] = a8; /*0x1041ac28e*/
  *(__m128 *)&v16[10] = a9; /*0x1041ac28e*/
  *(__m128 *)&v16[12] = a10; /*0x1041ac28e*/
  *(__m128 *)&v16[14] = a11; /*0x1041ac28e*/
  *(__m128 *)&v16[16] = a12; /*0x1041ac28e*/
  *(__m128 *)&v16[18] = a13; /*0x1041ac28e*/
  *(__m128 *)&v16[20] = a14; /*0x1041ac28e*/
  v16[1] = a2; /*0x1041ac2a6*/
  v16[2] = a3; /*0x1041ac2aa*/
  v16[3] = a4; /*0x1041ac2ae*/
  v16[4] = a5; /*0x1041ac2b2*/
  v16[5] = a6; /*0x1041ac2b6*/
  memset(v17, 0, 24); /*0x1041ac302*/
  v18.reg_save_area = v16; /*0x1041ac311*/
  v18.overflow_arg_area = &a15; /*0x1041ac319*/
  *(_QWORD *)&v18.gp_offset = 0x3000000008LL; /*0x1041ac327*/
  RBX::append_vformat(a1: v17, a2: (const char *)this, a3: &v18); /*0x1041ac32d*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1041ac33c*/
  std::runtime_error::runtime_error(a1: exception, a2: v17); /*0x1041ac346*/
  __cxa_throw( /*0x1041ac35c*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1041b68e8 | Name: __ZN3RBXL15tick_resolutionEv
void __fastcall RBX::tick_resolution(RBX *this)
{
  double v1; // xmm0_8
  mach_timebase_info v2; // [rsp-10h] [rbp-10h] BYREF

  if ( *(double *)&RBX::tick_resolution(void)::tick_res == 0.0 ) /*0x1041b68f8*/
  {
    if ( mach_timebase_info(info: &v2) != 0 ) /*0x1041b690f*/
      v1 = 0.000000001; /*0x1041b6911*/
    else
      v1 = (double)(int)v2.numer / (double)(int)v2.denom * 0.000000001; /*0x1041b6935*/
    RBX::tick_resolution(void)::tick_res = *(_QWORD *)&v1; /*0x1041b693d*/
  }
}

// Address: 0x1041b6e3d | Name: __ZN3RBXL21tick_frequency_helperEv
double __fastcall RBX::tick_frequency_helper(RBX *this)
{
  mach_timebase_info info; // [rsp+8h] [rbp-8h] BYREF

  if ( mach_timebase_info(&info) != 0 ) /*0x1041b6e50*/
    return 0.000000001; /*0x1041b6e52*/
  else
    return (double)(int)info.numer / (double)(int)info.denom * 0.000000001; /*0x1041b6e70*/
}

// Address: 0x1042bf604 | Name: __ZN3RBX24testRayAABBWithBackfacesERKNS_4simd3vecILi4EfEES4_S4_
bool __fastcall RBX::testRayAABBWithBackfaces(__m128i *a1, const __m128i *a2, __m128 *a3)
{
  __m128i si128; // xmm1
  __m128i v4; // xmm0
  __m128i v5; // xmm1
  __m128 v6; // xmm2
  __m128 v7; // xmm4

  si128 = _mm_load_si128(a2); /*0x1042bf608*/
  v4 = _mm_xor_si128(_mm_and_si128(_mm_load_si128((const __m128i *)&xmmword_108F246C0), si128), *a1); /*0x1042bf618*/
  v5 = _mm_and_si128(si128, (__m128i)xmmword_108F46760); /*0x1042bf61c*/
  v6 = _mm_mul_ps(*a3, (__m128)xmmword_108F49A20); /*0x1042bf627*/
  v7 = (__m128)_mm_shuffle_epi32(v5, 201); /*0x1042bf633*/
  return (~(unsigned __int8)_mm_movemask_ps( /*0x1042bf66e*/
                              _mm_and_ps(
                                _mm_cmple_ps(
                                  _mm_and_ps(
                                    _mm_sub_ps(
                                      _mm_mul_ps((__m128)_mm_shuffle_epi32(v4, 201), (__m128)v5),
                                      _mm_mul_ps(v7, (__m128)v4)),
                                    (__m128)xmmword_108F46760),
                                  _mm_add_ps(_mm_mul_ps(v7, v6), _mm_mul_ps(_mm_shuffle_ps(v6, v6, 201), (__m128)v5))),
                                _mm_cmple_ps((__m128)v4, v6)))
        & 7) == 0;
}

// Address: 0x1042bf6d1 | Name: __ZN3RBX19testDistanceRayAABBERKNS_4simd3vecILi4EfEES4_S4_S4_
bool __fastcall RBX::testDistanceRayAABB(__m128i *a1, const __m128i *a2, __m128 *a3, __m128 *a4)
{
  __m128i si128; // xmm0
  __m128i v5; // xmm1
  __m128i v6; // xmm0
  __m128 v7; // xmm2
  __m128 v8; // xmm4
  __m128 v9; // xmm3
  __m128 v10; // xmm0

  si128 = _mm_load_si128(a2); /*0x1042bf6d5*/
  v5 = _mm_xor_si128(_mm_and_si128(_mm_load_si128((const __m128i *)&xmmword_108F246C0), si128), *a1); /*0x1042bf6e5*/
  v6 = _mm_and_si128(si128, (__m128i)xmmword_108F46760); /*0x1042bf6e9*/
  v7 = _mm_mul_ps(*a3, (__m128)xmmword_108F49A20); /*0x1042bf6f4*/
  v8 = (__m128)_mm_shuffle_epi32(v6, 201); /*0x1042bf700*/
  if ( (~(unsigned __int8)_mm_movemask_ps( /*0x1042bf73e*/
                            _mm_and_ps(
                              _mm_cmple_ps(
                                _mm_and_ps(
                                  _mm_sub_ps(
                                    _mm_mul_ps((__m128)_mm_shuffle_epi32(v5, 201), (__m128)v6),
                                    _mm_mul_ps(v8, (__m128)v5)),
                                  (__m128)xmmword_108F46760),
                                _mm_add_ps(_mm_mul_ps(v8, v7), _mm_mul_ps(_mm_shuffle_ps(v7, v7, 201), (__m128)v6))),
                              _mm_cmple_ps((__m128)v5, v7)))
      & 7) != 0 )
    return false; /*0x1042bf78b*/
  v9 = _mm_div_ps(_mm_sub_ps(_mm_sub_ps((__m128)0LL, v7), (__m128)v5), (__m128)v6); /*0x1042bf749*/
  v10 = _mm_cmpeq_ps(_mm_and_ps((__m128)xmmword_108F4B9C0, v9), (__m128)xmmword_108F4B9C0); /*0x1042bf756*/
  return (~(unsigned __int8)_mm_movemask_ps( /*0x1042bf78d*/
                              _mm_cmple_ps(
                                _mm_and_ps(
                                  _mm_blendv_ps((__m128)-1LL, (__m128)xmmword_108F4B9B0, v10),
                                  _mm_or_ps(_mm_and_ps(*(__m128 *)&xmmword_108F246C0, v10), v9)),
                                *a4))
        & 7) == 0;
}

// Address: 0x1042bf85f | Name: __ZN3RBX14testSpherecastERKNS_10SimdSphereES2_RKNS_4simd3vecILi4EfEES7_
bool __fastcall RBX::testSpherecast(__m128 *a1, __m128 *a2, __m128 *a3, __m128 *a4)
{
  __m128 v4; // xmm0
  __m128 v5; // xmm2
  __m128 v6; // xmm1
  __m128 v7; // xmm1
  bool result; // al
  __m128 v9; // xmm0
  __m128 v10; // xmm0
  __m128 v11; // xmm3

  v4 = _mm_sub_ps(*a2, *a1); /*0x1042bf866*/
  v5 = _mm_add_ps(a1[1], a2[1]); /*0x1042bf86d*/
  v6 = _mm_mul_ps(v4, v4); /*0x1042bf877*/
  v7 = _mm_sub_ps(_mm_add_ps(_mm_shuffle_ps(v6, v6, 170), _mm_moveldup_ps(_mm_hadd_ps(v6, v6))), _mm_mul_ps(v5, v5)); /*0x1042bf88c*/
  result = true; /*0x1042bf88f*/
  if ( v7.f32[0] > 0.0 ) /*0x1042bf897*/
  {
    v9 = _mm_mul_ps(v4, *a3); /*0x1042bf899*/
    v10 = _mm_add_ps(_mm_shuffle_ps(v9, v9, 170), _mm_moveldup_ps(_mm_hadd_ps(v9, v9))); /*0x1042bf8ab*/
    if ( v10.f32[0] >= 0.0 ) /*0x1042bf8b1*/
    {
      v11 = _mm_max_ps((__m128)0LL, _mm_sub_ps(v10, *a4)); /*0x1042bf8c0*/
      return (~(unsigned __int8)_mm_movemask_ps(_mm_cmple_ps(_mm_mul_ps(v11, v11), _mm_sub_ps(_mm_mul_ps(v10, v10), v7))) /*0x1042bf8d7*/
            & 7) == 0;
    }
    else
    {
      return false; /*0x1042bf8b3*/
    }
  }
  return result; /*0x1042bf8da*/
}

// Address: 0x10437f630 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRjEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<unsigned int &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x10437f643*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 2); /*0x10437f660*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10437f66f*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x10437f679*/
  __cxa_throw( /*0x10437f68f*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10437f6db | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKyRKPKcEEEvS4_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<unsigned long long const&,char const* const&>(
        const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x10437f6f1*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 196); /*0x10437f716*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10437f725*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x10437f72f*/
  __cxa_throw( /*0x10437f745*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1043e13b0 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRPKcEEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*&>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1043e13c3*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 12); /*0x1043e13e1*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1043e13f0*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1043e13fa*/
  __cxa_throw( /*0x1043e1410*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1043e201f | Name: __ZN3RBX31throw_runtime_error_safe_formatIJPKcmEEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*,unsigned long>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1043e2035*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 76); /*0x1043e205a*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1043e2069*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1043e2073*/
  __cxa_throw( /*0x1043e2089*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1043e2346 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNS_10StringViewEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView const&>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1043e2359*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 15); /*0x1043e237f*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1043e238e*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1043e2398*/
  __cxa_throw( /*0x1043e23ae*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10446a975 | Name: __ZN3RBX23threadingViolationCheckEPKNS_9DataModelE
void __fastcall RBX::threadingViolationCheck(RBX *this, const RBX::DataModel *a2)
{
  if ( this != nullptr && (unsigned __int8)RBX::DataModel::currentThreadHasWriteLock(this) == 0 ) /*0x10446a985*/
    RBXCRASH(a1: "DM Lock Violation", a2: "read the above comments for details"); /*0x10446a997*/
}

// Address: 0x104495f0a | Name: __ZN3RBX14TexturePackKeyaSEOS0_
__int64 __fastcall RBX::TexturePackKey::operator=(__int64 a1, _OWORD *a2)
{
  char *v4; // r15
  __int64 i; // r12
  __int64 v6; // rax

  *(_OWORD *)a1 = *a2; /*0x104495f1e*/
  v4 = (char *)a2 + 25; /*0x104495f21*/
  for ( i = 0; i != 192; i += 32 ) /*0x104495f25*/
  {
    *(_WORD *)(a1 + i + 16) = *(_WORD *)&v4[i - 9]; /*0x104495f2e*/
    if ( (*(_BYTE *)(a1 + i + 24) & 1) != 0 ) /*0x104495f3a*/
      operator delete(a1: *(RBX::Memory **)(a1 + i + 40), a2); /*0x104495f41*/
    v6 = a1 + i + 24; /*0x104495f4a*/
    *(_QWORD *)(v6 + 16) = *(_QWORD *)&v4[i + 15]; /*0x104495f53*/
    *(_OWORD *)v6 = *(_OWORD *)&v4[i - 1]; /*0x104495f5d*/
    *(_WORD *)&v4[i - 1] = 0; /*0x104495f60*/
  }
  std::vector<std::array<RBX::TexturePackSource,6ul>>::__vdeallocate(a1: a1 + 208); /*0x104495f7c*/
  *(_OWORD *)(a1 + 208) = a2[13]; /*0x104495f89*/
  *(_QWORD *)(a1 + 224) = *((_QWORD *)a2 + 28); /*0x104495f97*/
  a2[13] = 0; /*0x104495fa1*/
  *((_QWORD *)a2 + 28) = 0; /*0x104495fa9*/
  return a1; /*0x104495fb7*/
}

// Address: 0x104496ac4 | Name: __ZN3RBX30texturePackPreviewRetryEnabledENS_16TexturePackUsageE
char __fastcall RBX::texturePackPreviewRetryEnabled(int a1)
{
  char result; // al

  if ( a1 != 4 ) /*0x104496acb*/
    return FFlag::DebugAlwaysPreviewRetry; /*0x104496acb*/
  result = 1; /*0x104496acd*/
  if ( FFlag::DebugEnableTexturePackPreviewRetryStudio == 0 ) /*0x104496ad6*/
    return FFlag::DebugAlwaysPreviewRetry; /*0x104496ad8*/
  return result; /*0x104496ade*/
}

// Address: 0x104515e5c | Name: __ZN3RBX20toVideoConnectParamsERKNSt3__110shared_ptrIKNS_10Reflection10ValueTableEEERKNS0_6vectorINS0_12basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEENSC_ISE_EEEE
__int64 __fastcall RBX::toVideoConnectParams(__int64 a1, __int64 a2, __int64 *a3)
{
  __int64 v5; // rbx
  __int64 v6; // r12
  _QWORD *i; // r15
  _OWORD *v8; // r12
  __int64 v9; // rdi
  __int64 v10; // rsi
  __int64 *v11; // r13
  __int64 v12; // rbx
  __int64 v13; // rdi
  __int64 v14; // rbx
  __int64 v15; // rdi
  __int64 v16; // rsi
  __int64 v17; // rbx
  __int64 v18; // rdi
  __int64 v19; // rbx
  __int64 v20; // rdx
  __int64 v21; // rcx
  __int64 v22; // rdi
  __int64 v23; // rsi
  __int64 v24; // rbx
  bool v25; // zf
  unsigned __int64 v26; // r13
  void *v27; // rsi
  __int64 v28; // r13
  char v29; // al
  unsigned __int64 v30; // r13
  double v31; // xmm0_8
  __int64 v32; // rax
  __int64 v33; // r13
  unsigned __int8 v35; // r8
  _QWORD v36[13]; // [rsp+0h] [rbp-B0h] BYREF
  double v37[3]; // [rsp+68h] [rbp-48h] BYREF
  __int64 v38; // [rsp+80h] [rbp-30h]

  v5 = a1; /*0x104515e76*/
  v38 = a1; /*0x104515e81*/
  if ( (_BYTE)`guard variable for'RBX::toVideoConnectParams(std::shared_ptr<RBX::Reflection::ValueTable const> const&,std::vector<std::string> const&)::proftoken15 == 0 /*0x1045161b9*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::toVideoConnectParams(std::shared_ptr<RBX::Reflection::ValueTable const> const&,std::vector<std::string> const&)::proftoken15) != 0 )
  {
    v36[0] = "VALUE"; /*0x1045161e2*/
    RBX::toVideoConnectParams(std::shared_ptr<RBX::Reflection::ValueTable const> const&,std::vector<std::string> const&)::proftoken15 = RBX::Profiler::getToken(this: (RBX::Profiler *)&aDatastoregetre[-44401], a2: &aSetUpvalue[-134476], a3: (const char *)0xFFFFFFFFLL, a4: 255, a5: v35); /*0x104516206*/
    __cxa_guard_release(a1: &`guard variable for'RBX::toVideoConnectParams(std::shared_ptr<RBX::Reflection::ValueTable const> const&,std::vector<std::string> const&)::proftoken15); /*0x104516214*/
    v5 = v38; /*0x104516219*/
  }
  v6 = RBX::toVideoConnectParams(std::shared_ptr<RBX::Reflection::ValueTable const> const&,std::vector<std::string> const&)::proftoken15; /*0x104515e8b*/
  *(_OWORD *)v36 = 0; /*0x104515e9d*/
  v36[3] = -1; /*0x104515ea3*/
  memset(&v36[4], 0, 52); /*0x104515eab*/
  *(_OWORD *)&v36[11] = 0; /*0x104515ec5*/
  v36[2] = RBX::toVideoConnectParams(std::shared_ptr<RBX::Reflection::ValueTable const> const&,std::vector<std::string> const&)::proftoken15; /*0x104515ecb*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v36); /*0x104515ed2*/
  v36[3] = RBX::Profiler::enterRegion(a1: v6, a2: -1, a3: 0); /*0x104515ee8*/
  *(_OWORD *)v5 = 0; /*0x104515ef0*/
  *(_QWORD *)(v5 + 16) = 0; /*0x104515ef4*/
  if ( *(_QWORD *)a2 != 0 ) /*0x104515f02*/
  {
    for ( i = *(_QWORD **)(*(_QWORD *)a2 + 16LL); i != nullptr; i = (_QWORD *)*i ) /*0x104515f08*/
    {
      v8 = i + 2; /*0x104515f15*/
      v9 = *a3; /*0x104515f19*/
      v10 = a3[1]; /*0x104515f1c*/
      if ( *a3 == v10 /*0x104515f35*/
        || std::__find[abi:ne200100]<std::string const*,std::string const*,std::string,std::__identity>(
             a1: v9,
             a2: v10,
             a3: i + 2,
             a4: v37) == a3[1] )
      {
        v11 = i + 5; /*0x104515f3b*/
        v12 = i[5]; /*0x104515f3f*/
        if ( RBX::Reflection::Type::getSingleton<bool>(a1: v9) == v12 ) /*0x104515f4b*/
        {
          v5 = v38; /*0x104515fce*/
          v29 = RBX::Reflection::Variant::get<bool>(a1: i + 5); /*0x104515fd2*/
          LOBYTE(v37[0]) = v29; /*0x104515fd7*/
          v30 = *(_QWORD *)(v5 + 8); /*0x104515fda*/
          if ( v30 < *(_QWORD *)(v5 + 16) ) /*0x104515fe2*/
          {
            if ( (*(_BYTE *)v8 & 1) != 0 ) /*0x104515fe9*/
            {
              std::string::__init_copy_ctor_external(a1: *(_QWORD *)(v5 + 8), a2: i[4], a3: i[3]); /*0x1045160b4*/
              v29 = LOBYTE(v37[0]); /*0x1045160b9*/
            }
            else
            {
              *(_QWORD *)(v30 + 16) = i[4]; /*0x104515ff4*/
              *(_OWORD *)v30 = *v8; /*0x104515ffd*/
            }
            *(_DWORD *)(v30 + 24) = 2; /*0x1045160bc*/
            *(_BYTE *)(v30 + 32) = v29; /*0x1045160c4*/
            goto LABEL_37; /*0x1045160c8*/
          }
          v32 = std::vector<std::pair<std::string,RSL::Variant<std::string,double,bool>>>::__emplace_back_slow_path<std::string const&,bool>( /*0x10451604c*/
                  a1: v5,
                  a2: i + 2,
                  a3: v37);
          goto LABEL_31; /*0x104516051*/
        }
        v14 = *v11; /*0x104515f4d*/
        if ( RBX::Reflection::Type::getSingleton<double>(a1: v13) == v14 ) /*0x104515f59*/
        {
          v5 = v38; /*0x10451600a*/
          v31 = RBX::Reflection::Variant::get<double>(a1: i + 5); /*0x10451600e*/
          v37[0] = v31; /*0x104516013*/
          v30 = *(_QWORD *)(v5 + 8); /*0x104516018*/
          if ( v30 < *(_QWORD *)(v5 + 16) ) /*0x104516020*/
          {
            if ( (*(_BYTE *)v8 & 1) == 0 ) /*0x104516027*/
              goto LABEL_29; /*0x104516027*/
            goto LABEL_35; /*0x104516027*/
          }
          goto LABEL_30; /*0x104516020*/
        }
        v17 = *v11; /*0x104515f5f*/
        if ( RBX::Reflection::Type::getSingleton<float>(a1: v15, a2: v16) == v17 ) /*0x104515f6b*/
        {
          v5 = v38; /*0x104516059*/
          v31 = RBX::Reflection::Variant::get<float>(a1: i + 5); /*0x104516062*/
          v37[0] = v31; /*0x104516066*/
          v30 = *(_QWORD *)(v5 + 8); /*0x10451606b*/
          if ( v30 < *(_QWORD *)(v5 + 16) ) /*0x104516073*/
          {
            if ( (*(_BYTE *)v8 & 1) == 0 ) /*0x10451607e*/
              goto LABEL_29; /*0x10451607e*/
            goto LABEL_35; /*0x10451607e*/
          }
          goto LABEL_30; /*0x104516073*/
        }
        v19 = *v11; /*0x104515f71*/
        if ( RBX::Reflection::Type::getSingleton<int>(a1: v18) == v19 ) /*0x104515f7d*/
        {
          v5 = v38; /*0x1045160d0*/
          v31 = (double)(int)RBX::Reflection::Variant::get<int>(a1: i + 5); /*0x1045160dc*/
          v37[0] = v31; /*0x1045160e0*/
          v30 = *(_QWORD *)(v5 + 8); /*0x1045160e5*/
          if ( v30 < *(_QWORD *)(v5 + 16) ) /*0x1045160ed*/
          {
            if ( (*(_BYTE *)v8 & 1) == 0 ) /*0x1045160f4*/
            {
LABEL_29:
              *(_QWORD *)(v30 + 16) = i[4]; /*0x1045160f6*/
              *(_OWORD *)v30 = *v8; /*0x104516104*/
              goto LABEL_36; /*0x104516109*/
            }
LABEL_35:
            std::string::__init_copy_ctor_external(a1: *(_QWORD *)(v5 + 8), a2: i[4], a3: i[3]); /*0x104516157*/
            v31 = v37[0]; /*0x104516167*/
LABEL_36:
            *(_DWORD *)(v30 + 24) = 1; /*0x10451616c*/
            *(double *)(v30 + 32) = v31; /*0x104516174*/
LABEL_37:
            v33 = v30 + 56; /*0x10451617a*/
LABEL_38:
            *(_QWORD *)(v5 + 8) = v33; /*0x10451617e*/
            continue; /*0x10451617e*/
          }
LABEL_30:
          v32 = std::vector<std::pair<std::string,RSL::Variant<std::string,double,bool>>>::__emplace_back_slow_path<std::string const&,double>( /*0x10451611c*/
                  a1: v5,
                  a2: i + 2,
                  a3: v37);
LABEL_31:
          v33 = v32; /*0x10451612b*/
          goto LABEL_38; /*0x10451612e*/
        }
        v24 = *v11; /*0x104515f83*/
        v25 = RBX::Reflection::Type::getSingleton<std::string>(a1: v22, a2: v23, a3: v20, a4: v21) == v24; /*0x104515f8c*/
        v5 = v38; /*0x104515f8f*/
        if ( v25 ) /*0x104515f93*/
        {
          RBX::Reflection::Variant::get<std::string>(a1: v37, a2: i + 5); /*0x104515fa0*/
          v26 = *(_QWORD *)(v5 + 8); /*0x104515fa5*/
          if ( v26 >= *(_QWORD *)(v5 + 16) ) /*0x104515fad*/
          {
            v28 = std::vector<std::pair<std::string,RSL::Variant<std::string,double,bool>>>::__emplace_back_slow_path<std::string const&,std::string>( /*0x10451613f*/
                    a1: v5,
                    a2: i + 2,
                    a3: v37);
          }
          else
          {
            std::pair<std::string,RSL::Variant<std::string,double,bool>>::pair[abi:ne200100]<std::string const&,std::string,0>( /*0x104515fbd*/
              a1: *(_QWORD *)(v5 + 8),
              a2: i + 2,
              a3: v37);
            v28 = v26 + 56; /*0x104515fc2*/
          }
          *(_QWORD *)(v5 + 8) = v28; /*0x104516142*/
          if ( (LOBYTE(v37[0]) & 1) != 0 ) /*0x10451614a*/
            operator delete(a1: *(RBX::Memory **)&v37[2], a2: v27); /*0x104516150*/
        }
      }
    }
  }
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v36); /*0x10451618a*/
  return v5; /*0x104516199*/
}

// Address: 0x1045ddf47 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewERKiRiEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &,int const&,int &>(
        const char *a1,
        __int64 a2,
        unsigned int *a3,
        unsigned int *a4)
{
  size_t v8; // rax
  __int64 v9; // rcx
  __int64 v10; // rdx
  __int64 v11; // r9
  void *exception; // r15
  _QWORD v13[7]; // [rsp+0h] [rbp-70h] BYREF
  _BYTE v14[56]; // [rsp+38h] [rbp-38h] BYREF

  v8 = strlen(__s: a1); /*0x1045ddf62*/
  v9 = *a3; /*0x1045ddf67*/
  v10 = *a4; /*0x1045ddf6a*/
  v13[0] = a2; /*0x1045ddf70*/
  v13[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045ddf7a*/
  v13[2] = v9; /*0x1045ddf7e*/
  v13[4] = v10; /*0x1045ddf82*/
  fmt::v8::vformat(a1: v14, a2: a1, v8, 287, v13, v11); /*0x1045ddf95*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045ddfa4*/
  std::runtime_error::runtime_error(a1: exception, a2: v14); /*0x1045ddfae*/
  __cxa_throw( /*0x1045ddfc4*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045de1ae | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRmEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<unsigned long &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1045de1c1*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 4); /*0x1045de1df*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045de1ee*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1045de1f8*/
  __cxa_throw( /*0x1045de20e*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045de794 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEiRmRKiEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,int,unsigned long &,int const&>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned int *a3,
        __int64 *a4,
        unsigned int *a5)
{
  size_t v10; // rax
  unsigned __int8 *v11; // rdx
  __int64 v12; // rsi
  __int64 v13; // rcx
  __int64 v14; // rdi
  __int64 v15; // r9
  void *exception; // r15
  _QWORD v17[8]; // [rsp+0h] [rbp-80h] BYREF
  _BYTE v18[64]; // [rsp+40h] [rbp-40h] BYREF

  v10 = strlen(__s: a1); /*0x1045de7b4*/
  v11 = a2 + 1; /*0x1045de7be*/
  v12 = *a2 >> 1; /*0x1045de7c4*/
  if ( (*a2 & 1) != 0 ) /*0x1045de7c9*/
  {
    v11 = *((unsigned __int8 **)a2 + 2); /*0x1045de7c9*/
    v12 = *((_QWORD *)a2 + 1); /*0x1045de7ce*/
  }
  v13 = *a3; /*0x1045de7d3*/
  v14 = *a4; /*0x1045de7d7*/
  v15 = *a5; /*0x1045de7da*/
  v17[0] = v11; /*0x1045de7e1*/
  v17[1] = v12; /*0x1045de7e4*/
  v17[2] = v13; /*0x1045de7e8*/
  v17[4] = v14; /*0x1045de7ec*/
  v17[6] = v15; /*0x1045de7f0*/
  fmt::v8::vformat(a1: v18, a2: a1, v10, 5149, v17, v15); /*0x1045de803*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045de812*/
  std::runtime_error::runtime_error(a1: exception, a2: v18); /*0x1045de81c*/
  __cxa_throw( /*0x1045de832*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045de87e | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERmRKiEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,unsigned long &,int const&>(
        const char *a1,
        unsigned __int8 *a2,
        __int64 *a3,
        unsigned int *a4)
{
  size_t v8; // rax
  __int64 v9; // r9
  unsigned __int8 *v10; // rdx
  __int64 v11; // rsi
  __int64 v12; // rcx
  __int64 v13; // rdi
  void *exception; // r15
  _QWORD v15[7]; // [rsp+0h] [rbp-70h] BYREF
  _BYTE v16[56]; // [rsp+38h] [rbp-38h] BYREF

  v8 = strlen(__s: a1); /*0x1045de899*/
  v10 = a2 + 1; /*0x1045de8a3*/
  v11 = *a2 >> 1; /*0x1045de8aa*/
  if ( (*a2 & 1) != 0 ) /*0x1045de8af*/
  {
    v10 = *((unsigned __int8 **)a2 + 2); /*0x1045de8af*/
    v11 = *((_QWORD *)a2 + 1); /*0x1045de8b5*/
  }
  v12 = *a3; /*0x1045de8bb*/
  v13 = *a4; /*0x1045de8be*/
  v15[0] = v10; /*0x1045de8c5*/
  v15[1] = v11; /*0x1045de8c8*/
  v15[2] = v12; /*0x1045de8cc*/
  v15[4] = v13; /*0x1045de8d0*/
  fmt::v8::vformat(a1: v16, a2: a1, v8, 333, v15, v9); /*0x1045de8e3*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045de8f2*/
  std::runtime_error::runtime_error(a1: exception, a2: v16); /*0x1045de8fc*/
  __cxa_throw( /*0x1045de912*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045de95e | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_RKS7_iEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string &,std::string,std::string const&,int>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3,
        unsigned __int8 *a4,
        unsigned int *a5)
{
  void *exception; // r15
  unsigned __int8 *v11[9]; // [rsp+0h] [rbp-90h] BYREF
  _BYTE v12[24]; // [rsp+48h] [rbp-48h] BYREF
  size_t v13; // [rsp+60h] [rbp-30h]

  v13 = strlen(__s: a1); /*0x1045de983*/
  fmt::v8::make_format_args<fmt::v8::basic_format_context<fmt::v8::appender,char>,std::string &,std::string &,std::string const&,int &>( /*0x1045de99a*/
    a1: v11,
    a2,
    a3,
    a4,
    a5);
  fmt::v8::vformat(a1: v12, a2: a1, v13, 7645, v11); /*0x1045de9b6*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045de9c5*/
  std::runtime_error::runtime_error(a1: exception, a2: v12); /*0x1045de9cf*/
  __cxa_throw( /*0x1045de9e5*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045dea31 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_RKS7_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string &,std::string,std::string const&>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3,
        unsigned __int8 *a4)
{
  size_t v8; // r14
  void *exception; // r15
  unsigned __int8 *v10[6]; // [rsp+0h] [rbp-70h] BYREF
  _BYTE v11[64]; // [rsp+30h] [rbp-40h] BYREF

  v8 = strlen(__s: a1); /*0x1045dea53*/
  fmt::v8::make_format_args<fmt::v8::basic_format_context<fmt::v8::appender,char>,std::string &,std::string &,std::string const&>( /*0x1045dea63*/
    a1: v10,
    a2,
    a3,
    a4);
  fmt::v8::vformat(a1: v11, a2: a1, v8, 3549, v10); /*0x1045dea7b*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045dea8a*/
  std::runtime_error::runtime_error(a1: exception, a2: v11); /*0x1045dea94*/
  __cxa_throw( /*0x1045deaaa*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045e3e07 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewES2_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &,RBX::StringView &>(
        const char *a1,
        __int64 a2,
        __int64 a3)
{
  size_t v6; // rax
  __int64 v7; // r9
  void *exception; // r15
  _QWORD v9[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v10[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x1045e3e1d*/
  v9[0] = a2; /*0x1045e3e26*/
  v9[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045e3e30*/
  v9[2] = a3; /*0x1045e3e34*/
  v9[3] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045e3e38*/
  fmt::v8::vformat(a1: v10, a2: a1, v6, 255, v9, v7); /*0x1045e3e4b*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045e3e5a*/
  std::runtime_error::runtime_error(a1: exception, a2: v10); /*0x1045e3e64*/
  __cxa_throw( /*0x1045e3e7a*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045f3c7c | Name: __ZN3RBX31throw_runtime_error_safe_formatIJmEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<unsigned long>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1045f3c8f*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 4); /*0x1045f3cad*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045f3cbc*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1045f3cc6*/
  __cxa_throw( /*0x1045f3cdc*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045f879a | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &,std::string>(
        const char *a1,
        __int64 a2,
        unsigned __int8 *a3)
{
  size_t v6; // rax
  __int64 v7; // r9
  unsigned __int8 *v8; // rdx
  __int64 v9; // rsi
  void *exception; // r15
  _QWORD v11[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v12[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x1045f87b0*/
  v8 = a3 + 1; /*0x1045f87b9*/
  v9 = *a3 >> 1; /*0x1045f87bf*/
  if ( (*a3 & 1) != 0 ) /*0x1045f87c4*/
  {
    v8 = *((unsigned __int8 **)a3 + 2); /*0x1045f87c4*/
    v9 = *((_QWORD *)a3 + 1); /*0x1045f87c9*/
  }
  v11[0] = a2; /*0x1045f87d2*/
  v11[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045f87dc*/
  v11[2] = v8; /*0x1045f87e0*/
  v11[3] = v9; /*0x1045f87e4*/
  fmt::v8::vformat(a1: v12, a2: a1, v6, 223, v11, v7); /*0x1045f87f7*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045f8806*/
  std::runtime_error::runtime_error(a1: exception, a2: v12); /*0x1045f8810*/
  __cxa_throw( /*0x1045f8826*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045f8872 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKiiEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<int const&,int>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1045f8888*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 17); /*0x1045f88ac*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045f88bb*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1045f88c5*/
  __cxa_throw( /*0x1045f88db*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045f8927 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJNS_10StringViewEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1045f893a*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 15); /*0x1045f8960*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045f896f*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1045f8979*/
  __cxa_throw( /*0x1045f898f*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045f89dd | Name: __ZN3RBX31throw_runtime_error_safe_formatIJmRKiRNS_10StringViewEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<unsigned long,int const&,RBX::StringView &>(
        const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[56]; // [rsp+38h] [rbp-38h] BYREF

  v2 = strlen(__s: a1); /*0x1045f89f8*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 3860); /*0x1045f8a2c*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045f8a3b*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1045f8a45*/
  __cxa_throw( /*0x1045f8a5b*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045f8aa7 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewEmNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEES9_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &,unsigned long,std::string,std::string>(
        const char *a1,
        __int64 a2,
        __int64 *a3,
        unsigned __int8 *a4,
        unsigned __int8 *a5)
{
  size_t v10; // rax
  unsigned __int8 *v11; // rdx
  __int64 v12; // rsi
  __int64 v13; // rcx
  unsigned __int8 *v14; // r9
  __int64 v15; // r10
  void *exception; // r15
  _QWORD v17[8]; // [rsp+0h] [rbp-80h] BYREF
  _BYTE v18[64]; // [rsp+40h] [rbp-40h] BYREF

  v10 = strlen(__s: a1); /*0x1045f8ac7*/
  v11 = a4 + 1; /*0x1045f8ad1*/
  v12 = *a4 >> 1; /*0x1045f8ad8*/
  if ( (*a4 & 1) != 0 ) /*0x1045f8add*/
    v11 = *((unsigned __int8 **)a4 + 2); /*0x1045f8add*/
  v13 = *a3; /*0x1045f8ae3*/
  if ( (*a4 & 1) != 0 ) /*0x1045f8ae7*/
    v12 = *((_QWORD *)a4 + 1); /*0x1045f8ae7*/
  v14 = a5 + 1; /*0x1045f8af1*/
  v15 = *a5 >> 1; /*0x1045f8af8*/
  if ( (*a5 & 1) != 0 ) /*0x1045f8aff*/
  {
    v14 = *((unsigned __int8 **)a5 + 2); /*0x1045f8aff*/
    v15 = *((_QWORD *)a5 + 1); /*0x1045f8b04*/
  }
  v17[0] = a2; /*0x1045f8b0d*/
  v17[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045f8b17*/
  v17[2] = v13; /*0x1045f8b1b*/
  v17[4] = v11; /*0x1045f8b1f*/
  v17[5] = v12; /*0x1045f8b23*/
  v17[6] = v14; /*0x1045f8b27*/
  v17[7] = v15; /*0x1045f8b2b*/
  fmt::v8::vformat(a1: v18, a2: a1, v10, 56655, v17, v14); /*0x1045f8b3e*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045f8b4d*/
  std::runtime_error::runtime_error(a1: exception, a2: v18); /*0x1045f8b57*/
  __cxa_throw( /*0x1045f8b6d*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045f8bb9 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewEmEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &,unsigned long>(
        const char *a1,
        __int64 a2,
        __int64 *a3)
{
  size_t v6; // rax
  __int64 v7; // rcx
  __int64 v8; // r9
  void *exception; // r15
  _QWORD v10[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v11[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x1045f8bcf*/
  v7 = *a3; /*0x1045f8bd4*/
  v10[0] = a2; /*0x1045f8bdb*/
  v10[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045f8be5*/
  v10[2] = v7; /*0x1045f8be9*/
  fmt::v8::vformat(a1: v11, a2: a1, v6, 79, v10, v8); /*0x1045f8bfc*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045f8c0b*/
  std::runtime_error::runtime_error(a1: exception, a2: v11); /*0x1045f8c15*/
  __cxa_throw( /*0x1045f8c2b*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045f8c77 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewEmRmRKiEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &,unsigned long,unsigned long &,int const&>(
        const char *a1,
        __int64 a2,
        __int64 *a3,
        __int64 *a4,
        unsigned int *a5)
{
  size_t v10; // rax
  __int64 v11; // rcx
  __int64 v12; // rdx
  __int64 v13; // rsi
  __int64 v14; // r9
  void *exception; // r15
  _QWORD v16[8]; // [rsp+0h] [rbp-80h] BYREF
  _BYTE v17[64]; // [rsp+40h] [rbp-40h] BYREF

  v10 = strlen(__s: a1); /*0x1045f8c97*/
  v11 = *a3; /*0x1045f8c9c*/
  v12 = *a4; /*0x1045f8c9f*/
  v13 = *a5; /*0x1045f8ca2*/
  v16[0] = a2; /*0x1045f8ca8*/
  v16[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045f8cb2*/
  v16[2] = v11; /*0x1045f8cb6*/
  v16[4] = v12; /*0x1045f8cba*/
  v16[6] = v13; /*0x1045f8cbe*/
  fmt::v8::vformat(a1: v17, a2: a1, v10, 5199, v16, v14); /*0x1045f8cd1*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045f8ce0*/
  std::runtime_error::runtime_error(a1: exception, a2: v17); /*0x1045f8cea*/
  __cxa_throw( /*0x1045f8d00*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045f8d4c | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewERmRKiEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &,unsigned long &,int const&>(
        const char *a1,
        __int64 a2,
        __int64 *a3,
        unsigned int *a4)
{
  size_t v8; // rax
  __int64 v9; // rcx
  __int64 v10; // rdx
  __int64 v11; // r9
  void *exception; // r15
  _QWORD v13[7]; // [rsp+0h] [rbp-70h] BYREF
  _BYTE v14[56]; // [rsp+38h] [rbp-38h] BYREF

  v8 = strlen(__s: a1); /*0x1045f8d67*/
  v9 = *a3; /*0x1045f8d6c*/
  v10 = *a4; /*0x1045f8d6f*/
  v13[0] = a2; /*0x1045f8d75*/
  v13[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045f8d7f*/
  v13[2] = v9; /*0x1045f8d83*/
  v13[4] = v10; /*0x1045f8d87*/
  fmt::v8::vformat(a1: v14, a2: a1, v8, 335, v13, v11); /*0x1045f8d9a*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045f8da9*/
  std::runtime_error::runtime_error(a1: exception, a2: v14); /*0x1045f8db3*/
  __cxa_throw( /*0x1045f8dc9*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045f8e15 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJNS_10StringViewENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEERS1_mEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView,std::string,RBX::StringView&,unsigned long>(
        const char *a1,
        __int64 a2,
        unsigned __int8 *a3,
        __int64 a4,
        __int64 *a5)
{
  size_t v10; // rax
  __int64 v11; // r9
  unsigned __int8 *v12; // rdx
  __int64 v13; // rsi
  __int64 v14; // rcx
  void *exception; // r15
  _QWORD v16[8]; // [rsp+0h] [rbp-80h] BYREF
  _BYTE v17[64]; // [rsp+40h] [rbp-40h] BYREF

  v10 = strlen(__s: a1); /*0x1045f8e35*/
  v12 = a3 + 1; /*0x1045f8e3f*/
  v13 = *a3 >> 1; /*0x1045f8e46*/
  if ( (*a3 & 1) != 0 ) /*0x1045f8e4b*/
  {
    v12 = *((unsigned __int8 **)a3 + 2); /*0x1045f8e4b*/
    v13 = *((_QWORD *)a3 + 1); /*0x1045f8e51*/
  }
  v14 = *a5; /*0x1045f8e57*/
  v16[0] = a2; /*0x1045f8e5e*/
  v16[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045f8e68*/
  v16[2] = v12; /*0x1045f8e6c*/
  v16[3] = v13; /*0x1045f8e70*/
  v16[4] = a4; /*0x1045f8e74*/
  v16[5] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045f8e78*/
  v16[6] = v14; /*0x1045f8e7c*/
  fmt::v8::vformat(a1: v17, a2: a1, v10, 20447, v16, v11); /*0x1045f8e8f*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045f8e9e*/
  std::runtime_error::runtime_error(a1: exception, a2: v17); /*0x1045f8ea8*/
  __cxa_throw( /*0x1045f8ebe*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045f8f0a | Name: __ZN3RBX31throw_runtime_error_safe_formatIJNS_10StringViewENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEERS1_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView,std::string,RBX::StringView&>(
        const char *a1,
        __int64 a2,
        unsigned __int8 *a3,
        __int64 a4)
{
  size_t v8; // rax
  __int64 v9; // r9
  unsigned __int8 *v10; // rdx
  __int64 v11; // rsi
  void *exception; // r15
  _QWORD v13[7]; // [rsp+0h] [rbp-70h] BYREF
  _BYTE v14[56]; // [rsp+38h] [rbp-38h] BYREF

  v8 = strlen(__s: a1); /*0x1045f8f25*/
  v10 = a3 + 1; /*0x1045f8f2e*/
  v11 = *a3 >> 1; /*0x1045f8f34*/
  if ( (*a3 & 1) != 0 ) /*0x1045f8f39*/
  {
    v10 = *((unsigned __int8 **)a3 + 2); /*0x1045f8f39*/
    v11 = *((_QWORD *)a3 + 1); /*0x1045f8f3e*/
  }
  v13[0] = a2; /*0x1045f8f47*/
  v13[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045f8f51*/
  v13[2] = v10; /*0x1045f8f55*/
  v13[3] = v11; /*0x1045f8f59*/
  v13[4] = a4; /*0x1045f8f5d*/
  v13[5] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045f8f61*/
  fmt::v8::vformat(a1: v14, a2: a1, v8, 4063, v13, v9); /*0x1045f8f74*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045f8f83*/
  std::runtime_error::runtime_error(a1: exception, a2: v14); /*0x1045f8f8d*/
  __cxa_throw( /*0x1045f8fa3*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1045fdce2 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewERKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &,std::string const&>(
        const char *a1,
        __int64 a2,
        unsigned __int8 *a3)
{
  size_t v6; // rax
  __int64 v7; // r9
  unsigned __int8 *v8; // rdx
  __int64 v9; // rsi
  void *exception; // r15
  _QWORD v11[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v12[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x1045fdcf8*/
  v8 = a3 + 1; /*0x1045fdd01*/
  v9 = *a3 >> 1; /*0x1045fdd07*/
  if ( (*a3 & 1) != 0 ) /*0x1045fdd0c*/
  {
    v8 = *((unsigned __int8 **)a3 + 2); /*0x1045fdd0c*/
    v9 = *((_QWORD *)a3 + 1); /*0x1045fdd11*/
  }
  v11[0] = a2; /*0x1045fdd1a*/
  v11[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1045fdd24*/
  v11[2] = v8; /*0x1045fdd28*/
  v11[3] = v9; /*0x1045fdd2c*/
  fmt::v8::vformat(a1: v12, a2: a1, v6, 223, v11, v7); /*0x1045fdd3f*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1045fdd4e*/
  std::runtime_error::runtime_error(a1: exception, a2: v12); /*0x1045fdd58*/
  __cxa_throw( /*0x1045fdd6e*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10467602d | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewES2_S2_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &,RBX::StringView &,RBX::StringView &>(
        const char *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  size_t v8; // rax
  __int64 v9; // r9
  void *exception; // r15
  _QWORD v11[7]; // [rsp+0h] [rbp-70h] BYREF
  _BYTE v12[56]; // [rsp+38h] [rbp-38h] BYREF

  v8 = strlen(__s: a1); /*0x104676048*/
  v11[0] = a2; /*0x104676051*/
  v11[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x10467605b*/
  v11[2] = a3; /*0x10467605f*/
  v11[3] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x104676063*/
  v11[4] = a4; /*0x104676067*/
  v11[5] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x10467606b*/
  fmt::v8::vformat(a1: v12, a2: a1, v8, 4095, v11, v9); /*0x10467607e*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10467608d*/
  std::runtime_error::runtime_error(a1: exception, a2: v12); /*0x104676097*/
  __cxa_throw( /*0x1046760ad*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x104677182 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJNS_10StringViewES1_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView,RBX::StringView>(
        const char *a1,
        __int64 a2,
        __int64 a3)
{
  size_t v6; // rax
  __int64 v7; // r9
  void *exception; // r15
  _QWORD v9[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v10[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x104677198*/
  v9[0] = a2; /*0x1046771a1*/
  v9[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1046771ab*/
  v9[2] = a3; /*0x1046771af*/
  v9[3] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1046771b3*/
  fmt::v8::vformat(a1: v10, a2: a1, v6, 255, v9, v7); /*0x1046771c6*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1046771d5*/
  std::runtime_error::runtime_error(a1: exception, a2: v10); /*0x1046771df*/
  __cxa_throw( /*0x1046771f5*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1047068f9 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRPKcS3_S3_S2_iEEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*&,char const*&,char const*&,char const*,int>(
        const char *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  size_t v7; // rax
  void *exception; // r15
  _BYTE v9[24]; // [rsp+58h] [rbp-48h] BYREF
  __int64 v10; // [rsp+70h] [rbp-30h]

  v10 = a6; /*0x10470690a*/
  v7 = strlen(__s: a1); /*0x10470691d*/
  fmt::v8::vformat(a1: v9, a2: a1, v7, 117964); /*0x104706960*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10470696f*/
  std::runtime_error::runtime_error(a1: exception, a2: v9); /*0x104706979*/
  __cxa_throw( /*0x10470698f*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1047069dc | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRPKcS3_S2_iEEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*&,char const*&,char const*,int>(
        const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[64]; // [rsp+40h] [rbp-40h] BYREF

  v2 = strlen(__s: a1); /*0x1047069fc*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 7372); /*0x104706a2f*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x104706a3e*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x104706a48*/
  __cxa_throw( /*0x104706a5e*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1047070eb | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_S7_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,std::string,std::string>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3,
        unsigned __int8 *a4)
{
  size_t v8; // r14
  void *exception; // r15
  unsigned __int8 *v10[6]; // [rsp+0h] [rbp-70h] BYREF
  _BYTE v11[64]; // [rsp+30h] [rbp-40h] BYREF

  v8 = strlen(__s: a1); /*0x10470710d*/
  fmt::v8::make_format_args<fmt::v8::basic_format_context<fmt::v8::appender,char>,std::string const&,std::string&,std::string&>( /*0x10470711d*/
    a1: v10,
    a2,
    a3,
    a4);
  fmt::v8::vformat(a1: v11, a2: a1, v8, 3549, v10); /*0x104707135*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x104707144*/
  std::runtime_error::runtime_error(a1: exception, a2: v11); /*0x10470714e*/
  __cxa_throw( /*0x104707164*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1047071b0 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_S7_PKciEEEvSB_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,std::string,std::string,char const*,int>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3,
        unsigned __int8 *a4,
        unsigned __int8 **a5,
        unsigned int *a6)
{
  void *exception; // r15
  unsigned __int8 *v12[10]; // [rsp+0h] [rbp-A0h] BYREF
  _BYTE v13[24]; // [rsp+50h] [rbp-50h] BYREF
  const char *v14; // [rsp+68h] [rbp-38h]
  size_t v15; // [rsp+70h] [rbp-30h]

  v14 = a1; /*0x1047071d0*/
  v15 = strlen(__s: a1); /*0x1047071d9*/
  fmt::v8::make_format_args<fmt::v8::basic_format_context<fmt::v8::appender,char>,std::string const&,std::string&,std::string&,char const*&,int &>( /*0x1047071f3*/
    a1: v12,
    a2,
    a3,
    a4,
    a5,
    a6);
  fmt::v8::vformat(a1: v13, a2: v14, v15, 118237, v12); /*0x104707210*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10470721f*/
  std::runtime_error::runtime_error(a1: exception, a2: v13); /*0x104707229*/
  __cxa_throw( /*0x10470723f*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10470728b | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_S7_PKcEEEvSB_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,std::string,std::string,char const*>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3,
        unsigned __int8 *a4,
        unsigned __int8 **a5)
{
  void *exception; // r15
  unsigned __int8 *v11[9]; // [rsp+0h] [rbp-90h] BYREF
  _BYTE v12[24]; // [rsp+48h] [rbp-48h] BYREF
  size_t v13; // [rsp+60h] [rbp-30h]

  v13 = strlen(__s: a1); /*0x1047072b0*/
  fmt::v8::make_format_args<fmt::v8::basic_format_context<fmt::v8::appender,char>,std::string const&,std::string&,std::string&,char const*&>( /*0x1047072c7*/
    a1: v11,
    a2,
    a3,
    a4,
    a5);
  fmt::v8::vformat(a1: v12, a2: a1, v13, 52701, v11); /*0x1047072e3*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1047072f2*/
  std::runtime_error::runtime_error(a1: exception, a2: v12); /*0x1047072fc*/
  __cxa_throw( /*0x104707312*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10470735e | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_PKciEEEvSB_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,std::string,char const*,int>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3,
        __int64 *a4,
        unsigned int *a5)
{
  size_t v10; // rax
  unsigned __int8 *v11; // rdx
  __int64 v12; // rsi
  unsigned __int8 *v13; // rdi
  __int64 v14; // r9
  __int64 v15; // rcx
  __int64 v16; // r10
  void *exception; // r15
  _QWORD v18[8]; // [rsp+0h] [rbp-80h] BYREF
  _BYTE v19[64]; // [rsp+40h] [rbp-40h] BYREF

  v10 = strlen(__s: a1); /*0x10470737e*/
  v11 = a2 + 1; /*0x104707388*/
  v12 = *a2 >> 1; /*0x10470738e*/
  if ( (*a2 & 1) != 0 ) /*0x104707393*/
  {
    v11 = *((unsigned __int8 **)a2 + 2); /*0x104707393*/
    v12 = *((_QWORD *)a2 + 1); /*0x104707398*/
  }
  v13 = a3 + 1; /*0x1047073a2*/
  v14 = *a3 >> 1; /*0x1047073aa*/
  if ( (*a3 & 1) != 0 ) /*0x1047073b0*/
  {
    v13 = *((unsigned __int8 **)a3 + 2); /*0x1047073b0*/
    v14 = *((_QWORD *)a3 + 1); /*0x1047073b6*/
  }
  v15 = *a4; /*0x1047073bc*/
  v16 = *a5; /*0x1047073bf*/
  v18[0] = v11; /*0x1047073c6*/
  v18[1] = v12; /*0x1047073c9*/
  v18[2] = v13; /*0x1047073cd*/
  v18[3] = v14; /*0x1047073d1*/
  v18[4] = v15; /*0x1047073d5*/
  v18[6] = v16; /*0x1047073d9*/
  fmt::v8::vformat(a1: v19, a2: a1, v10, 7389, v18, v14); /*0x1047073ec*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1047073fb*/
  std::runtime_error::runtime_error(a1: exception, a2: v19); /*0x104707405*/
  __cxa_throw( /*0x10470741b*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x104707467 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_PKcEEEvSB_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,std::string,char const*>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3,
        __int64 *a4)
{
  size_t v8; // rax
  unsigned __int8 *v9; // rdx
  __int64 v10; // rsi
  unsigned __int8 *v11; // rdi
  __int64 v12; // r9
  __int64 v13; // rcx
  void *exception; // r15
  _QWORD v15[7]; // [rsp+0h] [rbp-70h] BYREF
  _BYTE v16[56]; // [rsp+38h] [rbp-38h] BYREF

  v8 = strlen(__s: a1); /*0x104707482*/
  v9 = a2 + 1; /*0x10470748c*/
  v10 = *a2 >> 1; /*0x104707493*/
  if ( (*a2 & 1) != 0 ) /*0x104707498*/
  {
    v9 = *((unsigned __int8 **)a2 + 2); /*0x104707498*/
    v10 = *((_QWORD *)a2 + 1); /*0x10470749e*/
  }
  v11 = a3 + 1; /*0x1047074a8*/
  v12 = *a3 >> 1; /*0x1047074af*/
  if ( (*a3 & 1) != 0 ) /*0x1047074b5*/
  {
    v11 = *((unsigned __int8 **)a3 + 2); /*0x1047074b5*/
    v12 = *((_QWORD *)a3 + 1); /*0x1047074ba*/
  }
  v13 = *a4; /*0x1047074bf*/
  v15[0] = v9; /*0x1047074c6*/
  v15[1] = v10; /*0x1047074c9*/
  v15[2] = v11; /*0x1047074cd*/
  v15[3] = v12; /*0x1047074d1*/
  v15[4] = v13; /*0x1047074d5*/
  fmt::v8::vformat(a1: v16, a2: a1, v8, 3293, v15, v12); /*0x1047074e8*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1047074f7*/
  std::runtime_error::runtime_error(a1: exception, a2: v16); /*0x104707501*/
  __cxa_throw( /*0x104707517*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10474a718 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x10474a72b*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 13); /*0x10474a763*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10474a772*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x10474a77c*/
  __cxa_throw( /*0x10474a792*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10474e080 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x10474e093*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 13); /*0x10474e0cb*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10474e0da*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x10474e0e4*/
  __cxa_throw( /*0x10474e0fa*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1047508b8 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_12ModuleScript16ScriptSetupStateEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::ModuleScript::ScriptSetupState &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1047508cb*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 2); /*0x1047508e9*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1047508f8*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x104750902*/
  __cxa_throw( /*0x104750918*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10475127a | Name: __ZN3RBX31throw_runtime_error_safe_formatIJNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERKiPKcEEEvSB_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string,int const&,char const*>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned int *a3,
        __int64 *a4)
{
  size_t v8; // rax
  __int64 v9; // r9
  unsigned __int8 *v10; // rdx
  __int64 v11; // rsi
  __int64 v12; // rcx
  __int64 v13; // rdi
  void *exception; // r15
  _QWORD v15[7]; // [rsp+0h] [rbp-70h] BYREF
  _BYTE v16[56]; // [rsp+38h] [rbp-38h] BYREF

  v8 = strlen(__s: a1); /*0x104751295*/
  v10 = a2 + 1; /*0x10475129f*/
  v11 = *a2 >> 1; /*0x1047512a6*/
  if ( (*a2 & 1) != 0 ) /*0x1047512ab*/
  {
    v10 = *((unsigned __int8 **)a2 + 2); /*0x1047512ab*/
    v11 = *((_QWORD *)a2 + 1); /*0x1047512b1*/
  }
  v12 = *a3; /*0x1047512b7*/
  v13 = *a4; /*0x1047512ba*/
  v15[0] = v10; /*0x1047512c1*/
  v15[1] = v11; /*0x1047512c4*/
  v15[2] = v12; /*0x1047512c8*/
  v15[4] = v13; /*0x1047512cc*/
  fmt::v8::vformat(a1: v16, a2: a1, v8, 3101, v15, v9); /*0x1047512df*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1047512ee*/
  std::runtime_error::runtime_error(a1: exception, a2: v16); /*0x1047512f8*/
  __cxa_throw( /*0x10475130e*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x104752bc0 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERS7_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,std::string&>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3)
{
  size_t v6; // rax
  unsigned __int8 *v7; // rdx
  __int64 v8; // rsi
  unsigned __int8 *v9; // rdi
  __int64 v10; // r9
  void *exception; // r15
  _QWORD v12[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v13[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x104752bd6*/
  v7 = a2 + 1; /*0x104752bdf*/
  v8 = *a2 >> 1; /*0x104752be5*/
  if ( (*a2 & 1) != 0 ) /*0x104752bea*/
  {
    v7 = *((unsigned __int8 **)a2 + 2); /*0x104752bea*/
    v8 = *((_QWORD *)a2 + 1); /*0x104752bef*/
  }
  v9 = a3 + 1; /*0x104752bf8*/
  v10 = *a3 >> 1; /*0x104752bff*/
  if ( (*a3 & 1) != 0 ) /*0x104752c05*/
  {
    v9 = *((unsigned __int8 **)a3 + 2); /*0x104752c05*/
    v10 = *((_QWORD *)a3 + 1); /*0x104752c0a*/
  }
  v12[0] = v7; /*0x104752c13*/
  v12[1] = v8; /*0x104752c16*/
  v12[2] = v9; /*0x104752c1a*/
  v12[3] = v10; /*0x104752c1e*/
  fmt::v8::vformat(a1: v13, a2: a1, v6, 221, v12, v10); /*0x104752c31*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x104752c40*/
  std::runtime_error::runtime_error(a1: exception, a2: v13); /*0x104752c4a*/
  __cxa_throw( /*0x104752c60*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10479d989 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJiRNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<int,std::string &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x10479d99f*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 209); /*0x10479d9de*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10479d9ed*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x10479d9f7*/
  __cxa_throw( /*0x10479da0d*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10479dcb4 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJmRiRNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<unsigned long,int &,std::string &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[56]; // [rsp+38h] [rbp-38h] BYREF

  v2 = strlen(__s: a1); /*0x10479dccf*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 3348); /*0x10479dd19*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10479dd28*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x10479dd32*/
  __cxa_throw( /*0x10479dd48*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1047a033e | Name: __ZN3RBXL17throwCrossVMErrorEP9lua_State
void __fastcall __noreturn RBX::throwCrossVMError(__int64 a1)
{
  lua_pushlstring(a1, a2: "Attempt to load a function from a different Lua VM", a3: 50); /*0x1047a0353*/
  lua_error(a1); /*0x1047a035b*/
}

// Address: 0x104870135 | Name: __ZN3RBXL5tostrERKNS_23DockWidgetPluginGuiInfoE
RBX *__fastcall RBX::tostr(RBX *this, const RBX::DockWidgetPluginGuiInfo *a2)
{
  int v4; // r12d
  __int64 v5; // r15
  char *v6; // rsi
  __int64 v7; // rdx
  __int64 v8; // rax
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  __int64 v14; // rax
  __int64 v15; // rax
  __int64 v16; // rax
  __int64 v17; // rax
  __int64 v18; // rax
  __int64 v19; // rax
  void *v20; // rsi
  void *v21; // rsi
  __int64 (__fastcall **v23)(); // [rsp+0h] [rbp-140h] BYREF
  __int64 (__fastcall **v24)(); // [rsp+8h] [rbp-138h] BYREF
  _BYTE v25[72]; // [rsp+10h] [rbp-130h] BYREF
  void *v26; // [rsp+58h] [rbp-E8h]
  __int64 (__fastcall **v27)(); // [rsp+70h] [rbp-D0h] BYREF
  unsigned __int8 v28; // [rsp+108h] [rbp-38h] BYREF
  char v29; // [rsp+109h] [rbp-37h] BYREF
  __int64 v30; // [rsp+110h] [rbp-30h]
  void *v31; // [rsp+118h] [rbp-28h]

  v4 = RBX::Reflection::EnumDesc<RBX::Enums::InitialDockState>::singleton(); /*0x104870152*/
  std::ostringstream::basic_ostringstream[abi:ne200100](a1: &v23); /*0x10487015f*/
  v5 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>( /*0x104870178*/
         a1: &v23,
         a2: "InitialDockState:",
         a3: 17);
  RBX::Reflection::EnumDescriptor::_convertToString(this: (RBX::Reflection::EnumDescriptor *)&v28, a2: v4); /*0x104870185*/
  if ( (v28 & 1) != 0 ) /*0x104870191*/
  {
    v6 = (char *)v31; /*0x104870193*/
    v7 = v30; /*0x104870197*/
  }
  else
  {
    v7 = v28 >> 1; /*0x10487019d*/
    v6 = &v29; /*0x10487019f*/
  }
  v8 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v5, a2: v6, a3: v7); /*0x1048701a6*/
  v9 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v8, a2: " InitialEnabled:", a3: 16); /*0x1048701ba*/
  v10 = std::ostream::operator<<(a1: v9, a2: *((unsigned __int8 *)a2 + 4)); /*0x1048701c7*/
  v11 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>( /*0x1048701db*/
          a1: v10,
          a2: " InitialEnabledShouldOverrideRestore:",
          a3: 37);
  v12 = std::ostream::operator<<(a1: v11, a2: *((unsigned __int8 *)a2 + 5)); /*0x1048701e8*/
  v13 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v12, a2: " FloatingXSize:", a3: 15); /*0x1048701fc*/
  v14 = std::ostream::operator<<(a1: v13, a2: *((unsigned int *)a2 + 2)); /*0x104870208*/
  v15 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v14, a2: " FloatingYSize:", a3: 15); /*0x10487021c*/
  v16 = std::ostream::operator<<(a1: v15, a2: *((unsigned int *)a2 + 3)); /*0x104870228*/
  v17 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v16, a2: " MinWidth:", a3: 10); /*0x10487023c*/
  v18 = std::ostream::operator<<(a1: v17, a2: *((unsigned int *)a2 + 4)); /*0x104870248*/
  v19 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v18, a2: " MinHeight:", a3: 11); /*0x10487025c*/
  std::ostream::operator<<(a1: v19, a2: *((unsigned int *)a2 + 5)); /*0x104870268*/
  if ( (v28 & 1) != 0 ) /*0x104870271*/
    operator delete(a1: (RBX::Memory *)v31, a2: v20); /*0x104870277*/
  std::stringbuf::str(a1: this, a2: &v24); /*0x104870286*/
  v23 = &off_10C449768; /*0x10487029d*/
  v27 = off_10C449790; /*0x1048702a5*/
  v24 = &off_10C799250; /*0x1048702b3*/
  if ( (v25[56] & 1) != 0 ) /*0x1048702bc*/
    operator delete(a1: (RBX::Memory *)v26, a2: v21); /*0x1048702c5*/
  v24 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x1048702dc*/
  std::locale::~locale(this: (std::locale *)v25); /*0x1048702e0*/
  std::ostream::~ostream(a1: &v23, a2: off_10C4497A8); /*0x1048702f7*/
  std::ios::~ios(a1: &v27); /*0x1048702ff*/
  return this; /*0x104870307*/
}

// Address: 0x10487df84 | Name: __ZN3RBXL5tostrERKNS_10PluginDragE
RBX *__fastcall RBX::tostr(RBX *this, const RBX::PluginDrag *a2)
{
  __int64 v4; // r15
  _BYTE *v5; // rax
  char *v6; // rsi
  __int64 v7; // rdx
  __int64 v8; // rax
  __int64 v9; // r15
  _BYTE *v10; // rax
  _BYTE *v11; // rax
  char *v12; // rsi
  __int64 v13; // rdx
  __int64 v14; // rax
  __int64 v15; // r15
  __int64 v16; // rax
  __int128 *v17; // rax
  char *v18; // rsi
  __int64 v19; // rdx
  __int64 v20; // rax
  __int64 v21; // r15
  char *v22; // rsi
  __int64 v23; // rdx
  __int64 v24; // rax
  __int64 v25; // r15
  char *v26; // rsi
  __int64 v27; // rdx
  __int64 v28; // rax
  __int64 v29; // r15
  char *v30; // rsi
  __int64 v31; // rdx
  void *v32; // rsi
  void *v33; // rsi
  __int64 (__fastcall **v35)(); // [rsp+8h] [rbp-218h] BYREF
  __int64 (__fastcall **v36)(); // [rsp+10h] [rbp-210h] BYREF
  _BYTE v37[72]; // [rsp+18h] [rbp-208h] BYREF
  void *v38; // [rsp+60h] [rbp-1C0h]
  __int64 (__fastcall **v39)(); // [rsp+78h] [rbp-1A8h] BYREF
  __int64 v40; // [rsp+110h] [rbp-110h] BYREF
  _QWORD v41[3]; // [rsp+118h] [rbp-108h] BYREF
  void *v42; // [rsp+130h] [rbp-F0h]
  _QWORD v43[3]; // [rsp+138h] [rbp-E8h] BYREF
  void *v44; // [rsp+150h] [rbp-D0h]
  unsigned __int8 v45; // [rsp+158h] [rbp-C8h] BYREF
  char v46; // [rsp+159h] [rbp-C7h] BYREF
  __int64 v47; // [rsp+160h] [rbp-C0h]
  void *v48; // [rsp+168h] [rbp-B8h]
  __int128 v49; // [rsp+170h] [rbp-B0h] BYREF
  void *v50; // [rsp+180h] [rbp-A0h]
  __int128 v51; // [rsp+190h] [rbp-90h] BYREF
  void *v52; // [rsp+1A0h] [rbp-80h]
  __int128 v53; // [rsp+1B0h] [rbp-70h] BYREF
  void *v54; // [rsp+1C0h] [rbp-60h]
  __int128 v55; // [rsp+1D0h] [rbp-50h] BYREF
  void *v56; // [rsp+1E0h] [rbp-40h]
  __int128 v57; // [rsp+1F0h] [rbp-30h] BYREF
  void *v58; // [rsp+200h] [rbp-20h]

  std::ostringstream::basic_ostringstream[abi:ne200100](a1: &v35); /*0x10487dfa4*/
  v4 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &v35, a2: "Sender:", a3: 7); /*0x10487dfbd*/
  v5 = *(_BYTE **)a2; /*0x10487dfc0*/
  if ( (**(_BYTE **)a2 & 1) != 0 ) /*0x10487dfc6*/
  {
    std::string::__init_copy_ctor_external(a1: &v49, a2: *((_QWORD *)v5 + 2), a3: *((_QWORD *)v5 + 1)); /*0x10487dfee*/
  }
  else
  {
    v50 = *((void **)v5 + 2); /*0x10487dfcc*/
    v49 = *(_OWORD *)v5; /*0x10487dfd6*/
  }
  if ( (v49 & 1) != 0 ) /*0x10487dffd*/
  {
    v6 = (char *)v50; /*0x10487dfff*/
    v7 = *((_QWORD *)&v49 + 1); /*0x10487e006*/
  }
  else
  {
    v7 = (unsigned __int8)v49 >> 1; /*0x10487e00f*/
    v6 = (char *)&v49 + 1; /*0x10487e011*/
  }
  v8 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v4, a2: v6, a3: v7); /*0x10487e01b*/
  v9 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v8, a2: " MimeType:", a3: 10); /*0x10487e034*/
  v10 = *(_BYTE **)a2; /*0x10487e037*/
  if ( (*(_BYTE *)(*(_QWORD *)a2 + 24LL) & 1) != 0 ) /*0x10487e03e*/
  {
    std::string::__init_copy_ctor_external(a1: &v51, a2: *((_QWORD *)v10 + 5), a3: *((_QWORD *)v10 + 4)); /*0x10487e067*/
  }
  else
  {
    v11 = v10 + 24; /*0x10487e040*/
    v52 = *((void **)v11 + 2); /*0x10487e048*/
    v51 = *(_OWORD *)v11; /*0x10487e04f*/
  }
  if ( (v51 & 1) != 0 ) /*0x10487e076*/
  {
    v12 = (char *)v52; /*0x10487e078*/
    v13 = *((_QWORD *)&v51 + 1); /*0x10487e07c*/
  }
  else
  {
    v13 = (unsigned __int8)v51 >> 1; /*0x10487e085*/
    v12 = (char *)&v51 + 1; /*0x10487e087*/
  }
  v14 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v9, a2: v12, a3: v13); /*0x10487e091*/
  v15 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v14, a2: " Data:", a3: 6); /*0x10487e0aa*/
  v16 = *(_QWORD *)a2; /*0x10487e0ad*/
  if ( (*(_BYTE *)(*(_QWORD *)a2 + 48LL) & 1) != 0 ) /*0x10487e0b4*/
  {
    std::string::__init_copy_ctor_external(a1: &v53, a2: *(_QWORD *)(v16 + 64), a3: *(_QWORD *)(v16 + 56)); /*0x10487e0d7*/
  }
  else
  {
    v17 = (__int128 *)(v16 + 48); /*0x10487e0b6*/
    v54 = *((void **)v17 + 2); /*0x10487e0be*/
    v53 = *v17; /*0x10487e0c5*/
  }
  if ( (v53 & 1) != 0 ) /*0x10487e0e3*/
  {
    v18 = (char *)v54; /*0x10487e0e5*/
    v19 = *((_QWORD *)&v53 + 1); /*0x10487e0e9*/
  }
  else
  {
    v19 = (unsigned __int8)v53 >> 1; /*0x10487e0ef*/
    v18 = (char *)&v53 + 1; /*0x10487e0f1*/
  }
  v20 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v15, a2: v18, a3: v19); /*0x10487e0f8*/
  v21 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v20, a2: " MouseIcon:", a3: 11); /*0x10487e111*/
  RBX::PluginDrag::getMouseIcon(this: (RBX::PluginDrag *)v41); /*0x10487e11e*/
  if ( (v41[1] & 1) != 0 ) /*0x10487e12a*/
  {
    std::string::__init_copy_ctor_external(a1: &v55, a2: v42, a3: v41[2]); /*0x10487e156*/
  }
  else
  {
    v56 = v42; /*0x10487e137*/
    v55 = *(_OWORD *)&v41[1]; /*0x10487e13e*/
  }
  if ( (v55 & 1) != 0 ) /*0x10487e162*/
  {
    v22 = (char *)v56; /*0x10487e164*/
    v23 = *((_QWORD *)&v55 + 1); /*0x10487e168*/
  }
  else
  {
    v23 = (unsigned __int8)v55 >> 1; /*0x10487e16e*/
    v22 = (char *)&v55 + 1; /*0x10487e170*/
  }
  v24 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v21, a2: v22, a3: v23); /*0x10487e177*/
  v25 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v24, a2: " DragIcon:", a3: 10); /*0x10487e190*/
  RBX::PluginDrag::getDragIcon(this: (RBX::PluginDrag *)v43); /*0x10487e19d*/
  if ( (v43[1] & 1) != 0 ) /*0x10487e1a9*/
  {
    std::string::__init_copy_ctor_external(a1: &v57, a2: v44, a3: v43[2]); /*0x10487e1d5*/
  }
  else
  {
    v58 = v44; /*0x10487e1b6*/
    v57 = *(_OWORD *)&v43[1]; /*0x10487e1bd*/
  }
  if ( (v57 & 1) != 0 ) /*0x10487e1e1*/
  {
    v26 = (char *)v58; /*0x10487e1e3*/
    v27 = *((_QWORD *)&v57 + 1); /*0x10487e1e7*/
  }
  else
  {
    v27 = (unsigned __int8)v57 >> 1; /*0x10487e1ed*/
    v26 = (char *)&v57 + 1; /*0x10487e1ef*/
  }
  v28 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v25, a2: v26, a3: v27); /*0x10487e1f6*/
  v29 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v28, a2: " HotSpot:", a3: 9); /*0x10487e20f*/
  v40 = *(_QWORD *)(*(_QWORD *)a2 + 136LL); /*0x10487e224*/
  RBX::Z_ExtensionPoints_Vector2::Stringable::toString( /*0x10487e22f*/
    this: (RBX::Z_ExtensionPoints_Vector2::Stringable *)&v45,
    a2: (const RBX::Vector2 *)&v40);
  if ( (v45 & 1) != 0 ) /*0x10487e23e*/
  {
    v30 = (char *)v48; /*0x10487e240*/
    v31 = v47; /*0x10487e247*/
  }
  else
  {
    v31 = v45 >> 1; /*0x10487e250*/
    v30 = &v46; /*0x10487e252*/
  }
  std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v29, a2: v30, a3: v31); /*0x10487e25c*/
  if ( (v45 & 1) != 0 ) /*0x10487e268*/
    operator delete(a1: (RBX::Memory *)v48, a2: v32); /*0x10487e271*/
  if ( (v57 & 1) != 0 ) /*0x10487e27a*/
    operator delete(a1: (RBX::Memory *)v58, a2: v32); /*0x10487e280*/
  if ( (v43[1] & 1) != 0 ) /*0x10487e28c*/
    operator delete(a1: (RBX::Memory *)v44, a2: v32); /*0x10487e295*/
  if ( (v55 & 1) != 0 ) /*0x10487e29e*/
    operator delete(a1: (RBX::Memory *)v56, a2: v32); /*0x10487e2a4*/
  if ( (v41[1] & 1) != 0 ) /*0x10487e2b0*/
    operator delete(a1: (RBX::Memory *)v42, a2: v32); /*0x10487e2b9*/
  if ( (v53 & 1) != 0 ) /*0x10487e2c2*/
    operator delete(a1: (RBX::Memory *)v54, a2: v32); /*0x10487e2c8*/
  if ( (v51 & 1) != 0 ) /*0x10487e2d4*/
    operator delete(a1: (RBX::Memory *)v52, a2: v32); /*0x10487e2da*/
  if ( (v49 & 1) != 0 ) /*0x10487e2e6*/
    operator delete(a1: (RBX::Memory *)v50, a2: v32); /*0x10487e2ef*/
  std::stringbuf::str(a1: this, a2: &v36); /*0x10487e2fe*/
  v35 = &off_10C449768; /*0x10487e315*/
  v39 = off_10C449790; /*0x10487e31d*/
  v36 = &off_10C799250; /*0x10487e32b*/
  if ( (v37[56] & 1) != 0 ) /*0x10487e334*/
    operator delete(a1: (RBX::Memory *)v38, a2: v33); /*0x10487e33d*/
  v36 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x10487e354*/
  std::locale::~locale(this: (std::locale *)v37); /*0x10487e358*/
  std::ostream::~ostream(a1: &v35, a2: off_10C4497A8); /*0x10487e36f*/
  std::ios::~ios(a1: &v39); /*0x10487e377*/
  return this; /*0x10487e37f*/
}

// Address: 0x1048976d2 | Name: __ZN3RBX10twoProductEPfS0_ff
void __fastcall RBX::twoProduct(RBX *this, float *a2, float *a3, __m128 a4, __m128 a5)
{
  float v5; // xmm2_4
  __m128 inserted; // xmm0
  __m128 v7; // xmm3
  __m128 v8; // xmm1
  __m128 v9; // xmm0
  __m128 v10; // xmm1
  __m128 v11; // xmm1

  v5 = a4.f32[0] * a5.f32[0]; /*0x1048976d9*/
  *(float *)this = a4.f32[0] * a5.f32[0]; /*0x1048976dd*/
  inserted = _mm_insert_ps(a4, a5, 16); /*0x1048976ed*/
  v7 = _mm_mul_ps(_mm_moveldup_ps((__m128)(unsigned int)RBX::CSG_SPLITTER), inserted); /*0x1048976f3*/
  v8 = _mm_add_ps(_mm_sub_ps(inserted, v7), v7); /*0x1048976fc*/
  v9 = _mm_sub_ps(inserted, v8); /*0x1048976ff*/
  v7.f32[0] = _mm_movehdup_ps(v8).f32[0]; /*0x104897702*/
  v7.f32[0] = (float)(v7.f32[0] * v9.f32[0]) + (float)((float)(v8.f32[0] * v7.f32[0]) - v5); /*0x104897715*/
  v10 = _mm_blend_ps(v8, v9, 2); /*0x104897719*/
  v11 = _mm_mul_ps(_mm_shuffle_ps(v10, v10, 225), v9); /*0x104897723*/
  *a2 = (float)(_mm_movehdup_ps(v11).f32[0] + v7.f32[0]) + v11.f32[0]; /*0x104897732*/
}

// Address: 0x104898c2b | Name: __ZN3RBX12translate4x4EPffff
__int64 __fastcall RBX::translate4x4(RBX *this, float *a2, float a3, float a4, float a5)
{
  _mm_storel_ps((double *)this, (__m128)0x3F800000u); /*0x104898c37*/
  *((_DWORD *)this + 2) = 0; /*0x104898c3c*/
  *((float *)this + 3) = a3; /*0x104898c3f*/
  *((_QWORD *)this + 2) = 0x3F80000000000000LL; /*0x104898c4c*/
  *((_DWORD *)this + 6) = 0; /*0x104898c51*/
  *((float *)this + 7) = a4; /*0x104898c54*/
  *((_QWORD *)this + 4) = 0; /*0x104898c59*/
  *((_DWORD *)this + 10) = 1065353216; /*0x104898c61*/
  *((float *)this + 11) = a5; /*0x104898c68*/
  *((_OWORD *)this + 3) = xmmword_108F46940; /*0x104898c74*/
  return 0; /*0x104898c78*/
}

// Address: 0x104898e43 | Name: __ZN3RBX12transpose4x4EPfPKf
unsigned __int64 __fastcall RBX::transpose4x4(RBX *this, RBX *a2, const float *a3)
{
  unsigned __int64 result; // rax
  __int64 j; // rcx
  __int64 v5; // rcx
  unsigned __int64 i; // rdx
  int v7; // xmm0_4

  result = 0; /*0x104898e47*/
  if ( this == a2 ) /*0x104898e4c*/
  {
    do /*0x104898eb1*/
    {
      if ( result <= 2 ) /*0x104898e7b*/
      {
        v5 = 4; /*0x104898e7d*/
        for ( i = result; i < 3; ++i ) /*0x104898e82*/
        {
          v7 = *(_DWORD *)((char *)this + v5); /*0x104898e85*/
          *(_DWORD *)((char *)this + v5) = *((_DWORD *)this + v5); /*0x104898e8f*/
          *((_DWORD *)this + v5) = v7; /*0x104898e94*/
          v5 += 4; /*0x104898e99*/
        }
      }
      ++result; /*0x104898ea6*/
      this = (RBX *)((char *)this + 20); /*0x104898ea9*/
    }
    while ( result != 4 ); /*0x104898eb1*/
  }
  else
  {
    do /*0x104898e73*/
    {
      for ( j = 0; j != 16; j += 4 ) /*0x104898e4e*/
        *(_DWORD *)((char *)this + j) = *((_DWORD *)a2 + j); /*0x104898e55*/
      ++result; /*0x104898e64*/
      this = (RBX *)((char *)this + 16); /*0x104898e67*/
      a2 = (RBX *)((char *)a2 + 4); /*0x104898e6b*/
    }
    while ( result != 4 ); /*0x104898e73*/
  }
  return result; /*0x104898eb3*/
}

// Address: 0x104899564 | Name: __ZN3RBX12transform4x4EPfPKfS2_
__int64 __fastcall RBX::transform4x4(RBX *this, float *a2, __m128 *a3, const float *a4, __int64 a5, __int64 a6)
{
  __int64 i; // r13
  __m128 v10; // xmm3
  __m128 v11; // xmm1
  __m128 v12; // xmm4
  __m128 v13; // xmm5
  __m128 v14; // xmm2
  __m128 v15; // xmm3
  __m128 v16; // xmm4
  __m128 v17; // xmm0
  __m128 v18; // xmm0
  int v20; // [rsp+0h] [rbp-64h]
  _QWORD v21[4]; // [rsp+4h] [rbp-60h] BYREF
  _QWORD v22[2]; // [rsp+24h] [rbp-40h]

  for ( i = 0; i != 16; i += 4 ) /*0x10489958c*/
  {
    v10 = _mm_shuffle_ps((__m128)(unsigned int)RBX::CSG_SPLITTER, (__m128)(unsigned int)RBX::CSG_SPLITTER, 0); /*0x10489959b*/
    v11 = _mm_mul_ps(*(__m128 *)&a2[i], *a3); /*0x1048995ab*/
    v12 = _mm_mul_ps(*(__m128 *)&a2[i], v10); /*0x1048995b1*/
    v13 = _mm_add_ps(_mm_sub_ps(*(__m128 *)&a2[i], v12), v12); /*0x1048995ba*/
    v14 = _mm_sub_ps(*(__m128 *)&a2[i], v13); /*0x1048995bd*/
    v15 = _mm_mul_ps(v10, *a3); /*0x1048995c0*/
    v16 = _mm_add_ps(_mm_sub_ps(*a3, v15), v15); /*0x1048995c9*/
    v17 = _mm_sub_ps(*a3, v16); /*0x1048995cc*/
    v18 = _mm_add_ps( /*0x1048995e7*/
            _mm_mul_ps(v17, v14),
            _mm_add_ps(_mm_mul_ps(v13, v17), _mm_add_ps(_mm_mul_ps(v16, v14), _mm_sub_ps(_mm_mul_ps(v13, v16), v11))));
    *(__m128 *)&v21[2] = _mm_unpackhi_ps(v11, v18); /*0x1048995f3*/
    *(__m128 *)v21 = _mm_unpacklo_ps(v11, v18); /*0x1048995f7*/
    *(_DWORD *)((char *)v22 + i) = *(&v20 /*0x10489960e*/
                                   + (_QWORD)RBX::distill(
                                               this: (RBX *)v21,
                                               a2: (float *)8,
                                               (unsigned __int64)a3,
                                               (__int64)a4,
                                               a5,
                                               a6));
  }
  *(_OWORD *)this = *(_OWORD *)v22; /*0x104899627*/
  return __stack_chk_guard; /*0x10489963a*/
}

// Address: 0x10489964e | Name: __ZN3RBX13transform4x4tEPfPKfS2_
__int64 __fastcall RBX::transform4x4t(RBX *this, float *a2, __m128 *a3, const float *a4, __int64 a5, __int64 a6)
{
  __int64 i; // r13
  __m128 v10; // xmm3
  __m128 inserted; // xmm0
  __m128 v12; // xmm2
  __m128 v13; // xmm4
  __m128 v14; // xmm5
  __m128 v15; // xmm0
  __m128 v16; // xmm3
  __m128 v17; // xmm4
  __m128 v18; // xmm1
  __m128 v19; // xmm1
  int v21; // [rsp+0h] [rbp-64h]
  _QWORD v22[4]; // [rsp+4h] [rbp-60h] BYREF
  _QWORD v23[2]; // [rsp+24h] [rbp-40h]

  for ( i = 0; i != 4; ++i ) /*0x104899676*/
  {
    v10 = _mm_shuffle_ps((__m128)(unsigned int)RBX::CSG_SPLITTER, (__m128)(unsigned int)RBX::CSG_SPLITTER, 0); /*0x104899685*/
    inserted = _mm_insert_ps( /*0x1048996a1*/
                 _mm_insert_ps(
                   _mm_insert_ps((__m128)LODWORD(a2[i]), (__m128)LODWORD(a2[i + 4]), 16),
                   (__m128)LODWORD(a2[i + 8]),
                   32),
                 (__m128)LODWORD(a2[i + 12]),
                 48);
    v12 = _mm_mul_ps(inserted, *a3); /*0x1048996b1*/
    v13 = _mm_mul_ps(inserted, v10); /*0x1048996b7*/
    v14 = _mm_add_ps(_mm_sub_ps(inserted, v13), v13); /*0x1048996c0*/
    v15 = _mm_sub_ps(inserted, v14); /*0x1048996c3*/
    v16 = _mm_mul_ps(v10, *a3); /*0x1048996c6*/
    v17 = _mm_add_ps(_mm_sub_ps(*a3, v16), v16); /*0x1048996cf*/
    v18 = _mm_sub_ps(*a3, v17); /*0x1048996d2*/
    v19 = _mm_add_ps( /*0x1048996ed*/
            _mm_mul_ps(v18, v15),
            _mm_add_ps(_mm_mul_ps(v14, v18), _mm_add_ps(_mm_mul_ps(v17, v15), _mm_sub_ps(_mm_mul_ps(v14, v17), v12))));
    *(__m128 *)&v22[2] = _mm_unpackhi_ps(v19, v12); /*0x1048996f9*/
    *(__m128 *)v22 = _mm_unpacklo_ps(v19, v12); /*0x1048996fd*/
    *((_DWORD *)v23 + i) = *(&v21 /*0x104899714*/
                           + (_QWORD)RBX::distill(
                                       this: (RBX *)v22,
                                       a2: (float *)8,
                                       (unsigned __int64)a3,
                                       (__int64)a4,
                                       a5,
                                       a6));
  }
  *(_OWORD *)this = *(_OWORD *)v23; /*0x10489972c*/
  return __stack_chk_guard; /*0x10489973f*/
}

// Address: 0x10489a23a | Name: __ZN3RBXL12threeProductEPfmfff
void __fastcall RBX::threeProduct(RBX *this, float *a2, float a3, float a4, float a5)
{
  float v5; // xmm4_4
  float v6; // xmm3_4
  float v7; // xmm6_4
  float v8; // xmm1_4
  float v9; // xmm6_4
  float v10; // xmm0_4
  float v11; // xmm5_4
  float v12; // xmm2_4

  v5 = a3 * a4; /*0x10489a241*/
  v6 = *(float *)&RBX::CSG_SPLITTER; /*0x10489a245*/
  v7 = (float)(a3 - (float)(*(float *)&RBX::CSG_SPLITTER * a3)) + (float)(*(float *)&RBX::CSG_SPLITTER * a3); /*0x10489a25b*/
  v8 = (float)((float)(a4 /*0x10489a298*/
                     - (float)((float)(a4 - (float)(*(float *)&RBX::CSG_SPLITTER * a4))
                             + (float)(*(float *)&RBX::CSG_SPLITTER * a4)))
             * (float)(a3 - v7))
     + (float)((float)(v7
                     * (float)(a4
                             - (float)((float)(a4 - (float)(*(float *)&RBX::CSG_SPLITTER * a4))
                                     + (float)(*(float *)&RBX::CSG_SPLITTER * a4))))
             + (float)((float)((float)((float)(a4 - (float)(*(float *)&RBX::CSG_SPLITTER * a4))
                                     + (float)(*(float *)&RBX::CSG_SPLITTER * a4))
                             * (float)(a3 - v7))
                     + (float)((float)(v7
                                     * (float)((float)(a4 - (float)(*(float *)&RBX::CSG_SPLITTER * a4))
                                             + (float)(*(float *)&RBX::CSG_SPLITTER * a4)))
                             - (float)(a3 * a4))));
  v9 = v5 * a5; /*0x10489a29f*/
  *(float *)this = v5 * a5; /*0x10489a2a3*/
  v10 = (float)(a5 - (float)(v6 * a5)) + (float)(v6 * a5); /*0x10489a2cb*/
  v11 = v8 * a5; /*0x10489a2d2*/
  v12 = a5 - v10; /*0x10489a2d6*/
  *((float *)this + 1) = (float)((float)(v5 - (float)((float)(v5 - (float)(v5 * v6)) + (float)(v5 * v6))) * v12) /*0x10489a304*/
                       + (float)((float)((float)((float)(v5 - (float)(v5 * v6)) + (float)(v5 * v6)) * v12)
                               + (float)((float)(v10
                                               * (float)(v5 - (float)((float)(v5 - (float)(v5 * v6)) + (float)(v5 * v6))))
                                       + (float)((float)((float)((float)(v5 - (float)(v5 * v6)) + (float)(v5 * v6)) * v10)
                                               - v9)));
  *((float *)this + 2) = v11; /*0x10489a309*/
  *((float *)this + 3) = (float)((float)(v8 - (float)((float)(v8 - (float)(v6 * v8)) + (float)(v6 * v8))) * v12) /*0x10489a344*/
                       + (float)((float)((float)((float)(v8 - (float)(v6 * v8)) + (float)(v6 * v8)) * v12)
                               + (float)((float)(v10
                                               * (float)(v8 - (float)((float)(v8 - (float)(v6 * v8)) + (float)(v6 * v8))))
                                       + (float)((float)(v10 * (float)((float)(v8 - (float)(v6 * v8)) + (float)(v6 * v8)))
                                               - v11)));
}

// Address: 0x1048fd7e4 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKcEEEvPS1_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const&>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1048fd7f7*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 8); /*0x1048fd815*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1048fd824*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1048fd82e*/
  __cxa_throw( /*0x1048fd844*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1048fde03 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNS_10StringViewEPKcEEEvS5_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView const&,char const*>(
        const char *a1,
        __int64 a2,
        __int64 *a3)
{
  size_t v6; // rax
  __int64 v7; // rcx
  __int64 v8; // r9
  void *exception; // r15
  _QWORD v10[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v11[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x1048fde19*/
  v7 = *a3; /*0x1048fde1e*/
  v10[0] = a2; /*0x1048fde25*/
  v10[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1048fde2f*/
  v10[2] = v7; /*0x1048fde33*/
  fmt::v8::vformat(a1: v11, a2: a1, v6, 207, v10, v8); /*0x1048fde46*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1048fde55*/
  std::runtime_error::runtime_error(a1: exception, a2: v11); /*0x1048fde5f*/
  __cxa_throw( /*0x1048fde75*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1048fe1de | Name: __ZN3RBX31throw_runtime_error_safe_formatIJPKcS2_EEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*,char const*>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1048fe1f4*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 204); /*0x1048fe219*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1048fe228*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1048fe232*/
  __cxa_throw( /*0x1048fe248*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10490010c | Name: __ZN3RBX31throw_runtime_error_safe_formatIJPKcRKNS_10StringViewEEEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*,RBX::StringView const&>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x104900122*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 252); /*0x10490014f*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10490015e*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x104900168*/
  __cxa_throw( /*0x10490017e*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1049001ca | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNS_10StringViewES3_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView const&,RBX::StringView const&>(
        const char *a1,
        __int64 a2,
        __int64 a3)
{
  size_t v6; // rax
  __int64 v7; // r9
  void *exception; // r15
  _QWORD v9[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v10[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x1049001e0*/
  v9[0] = a2; /*0x1049001e9*/
  v9[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1049001f3*/
  v9[2] = a3; /*0x1049001f7*/
  v9[3] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x1049001fb*/
  fmt::v8::vformat(a1: v10, a2: a1, v6, 255, v9, v7); /*0x10490020e*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10490021d*/
  std::runtime_error::runtime_error(a1: exception, a2: v10); /*0x104900227*/
  __cxa_throw( /*0x10490023d*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1049592fd | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_S9_S7_S9_S7_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,std::string const&,std::string const&,std::string,std::string const&,std::string>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3,
        unsigned __int8 *a4,
        unsigned __int8 *a5,
        unsigned __int8 *a6,
        unsigned __int8 *a7)
{
  void *exception; // r15
  unsigned __int8 *v13[12]; // [rsp+10h] [rbp-B0h] BYREF
  _BYTE v14[24]; // [rsp+70h] [rbp-50h] BYREF
  unsigned __int8 *v15; // [rsp+88h] [rbp-38h]
  size_t v16; // [rsp+90h] [rbp-30h]

  v15 = a6; /*0x104959311*/
  v16 = strlen(__s: a1); /*0x104959329*/
  fmt::v8::make_format_args<fmt::v8::basic_format_context<fmt::v8::appender,char>,std::string const&,std::string const&,std::string const&,std::string&,std::string const&,std::string&>( /*0x10495934c*/
    a1: v13,
    a2,
    a3,
    a4,
    a5,
    a6: v15,
    a7);
  fmt::v8::vformat(a1: v14, a2: a1, v16, 14540253, v13); /*0x104959368*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x104959377*/
  std::runtime_error::runtime_error(a1: exception, a2: v14); /*0x104959381*/
  __cxa_throw( /*0x104959397*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x104969cfa | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKPKcEEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const* const&>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x104969d0d*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 12); /*0x104969d2b*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x104969d3a*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x104969d44*/
  __cxa_throw( /*0x104969d5a*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x104a04208 | Name: __ZN3RBX16TextFilterResultaSERKS0_
__int64 __fastcall RBX::TextFilterResult::operator=(__int64 a1, __int64 a2)
{
  *(_DWORD *)(a1 + 7) = *(_DWORD *)(a2 + 7); /*0x104a0421b*/
  *(_QWORD *)a1 = *(_QWORD *)a2; /*0x104a04221*/
  std::string::operator=(a1: a1 + 16, a2: a2 + 16); /*0x104a0422c*/
  std::string::operator=(a1: a1 + 40, a2: a2 + 40); /*0x104a04239*/
  std::string::operator=(a1: a1 + 64, a2: a2 + 64); /*0x104a04246*/
  std::string::operator=(a1: a1 + 88, a2: a2 + 88); /*0x104a04253*/
  std::string::operator=(a1: a1 + 112, a2: a2 + 112); /*0x104a04260*/
  std::string::operator=(a1: a1 + 136, a2: a2 + 136); /*0x104a04271*/
  std::string::operator=(a1: a1 + 160, a2: a2 + 160); /*0x104a04282*/
  std::string::operator=(a1: a1 + 184, a2: a2 + 184); /*0x104a04293*/
  std::string::operator=(a1: a1 + 208, a2: a2 + 208); /*0x104a042a4*/
  std::string::operator=(a1: a1 + 232, a2: a2 + 232); /*0x104a042b5*/
  RBX::details::SplitHashTable<long long,long long,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<long long>,RBX::details::DefaultEqualTo<long long>,RBX::details::GetSelfKey<long long>>::copy_from<RBX::details::SplitHashTable<long long,long long,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<long long>,RBX::details::DefaultEqualTo<long long>,RBX::details::GetSelfKey<long long>>>( /*0x104a042c6*/
    a1: a1 + 256,
    a2: a2 + 256);
  if ( a1 != a2 ) /*0x104a042ce*/
  {
    std::vector<long long>::__assign_with_size[abi:ne200100]<long long *,long long *>( /*0x104a042ef*/
      a1: a1 + 296,
      a2: *(_QWORD *)(a2 + 296),
      a3: *(_QWORD *)(a2 + 304),
      a4: (__int64)(*(_QWORD *)(a2 + 304) - *(_QWORD *)(a2 + 296)) >> 3);
    std::vector<std::string>::__assign_with_size[abi:ne200100]<std::string*,std::string*>( /*0x104a04321*/
      a1: (__int64 *)(a1 + 320),
      a2: *(_QWORD *)(a2 + 320),
      a3: *(_QWORD *)(a2 + 328),
      a4: 0xAAAAAAAAAAAAAAABLL * ((__int64)(*(_QWORD *)(a2 + 328) - *(_QWORD *)(a2 + 320)) >> 3));
    std::vector<std::string>::__assign_with_size[abi:ne200100]<std::string*,std::string*>( /*0x104a04349*/
      a1: (__int64 *)(a1 + 344),
      a2: *(_QWORD *)(a2 + 344),
      a3: *(_QWORD *)(a2 + 352),
      a4: 0xAAAAAAAAAAAAAAABLL * ((__int64)(*(_QWORD *)(a2 + 352) - *(_QWORD *)(a2 + 344)) >> 3));
  }
  return a1; /*0x104a04355*/
}

// Address: 0x104a1c194 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewERKNS_13StringLiteralEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &,RBX::StringLiteral const&>(
        const char *a1,
        __int64 a2,
        __int64 a3)
{
  size_t v6; // rax
  __int64 v7; // r9
  void *exception; // r15
  _QWORD v9[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v10[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x104a1c1aa*/
  v9[0] = a2; /*0x104a1c1b3*/
  v9[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x104a1c1bd*/
  v9[2] = a3; /*0x104a1c1c1*/
  v9[3] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringLiteral,fmt::v8::formatter<RBX::StringLiteral,char,void>>; /*0x104a1c1cc*/
  fmt::v8::vformat(a1: v10, a2: a1, v6, 255, v9, v7); /*0x104a1c1df*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x104a1c1ee*/
  std::runtime_error::runtime_error(a1: exception, a2: v10); /*0x104a1c1f8*/
  __cxa_throw( /*0x104a1c20e*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x104a28840 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x104a28853*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 15); /*0x104a28879*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x104a28888*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x104a28892*/
  __cxa_throw( /*0x104a288a8*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x104a8fb9e | Name: __ZN3RBX24tupleContainsInputObjectENSt3__110shared_ptrIKNS_10Reflection5TupleEEERKNS1_INS_11InputObjectEEERb
char __fastcall RBX::tupleContainsInputObject(_QWORD *a1, RBX::InputObject **a2, _BYTE *a3)
{
  _QWORD *v3; // rax
  char isGamepadEvent; // r12
  __int64 v7; // rdi
  __int64 *v8; // r13
  __int64 v9; // rbx
  __int64 v10; // rax
  __int64 v11; // rdx
  __int64 v12; // rcx
  __int64 v13; // rdi
  __int64 v14; // rsi
  __int64 v15; // r14
  __int64 v16; // rdi
  void *v17; // rsi
  int v18; // ebx
  __int64 v19; // rbx
  __int64 v20; // rdx
  __int64 v21; // rcx
  const char *v22; // rsi
  __int64 v23; // r8
  __int64 v24; // r9
  __m128 v25; // xmm0
  __m128 v26; // xmm1
  __m128 v27; // xmm2
  __m128 v28; // xmm3
  __m128 v29; // xmm4
  __m128 v30; // xmm5
  __m128 v31; // xmm6
  __m128 v32; // xmm7
  __int64 v33; // rdx
  __int64 v34; // rcx
  const char *v35; // rsi
  __int64 v36; // r8
  __int64 v37; // r9
  __m128 v38; // xmm0
  __m128 v39; // xmm1
  __m128 v40; // xmm2
  __m128 v41; // xmm3
  __m128 v42; // xmm4
  __m128 v43; // xmm5
  __m128 v44; // xmm6
  __m128 v45; // xmm7
  __int64 v46; // r14
  __int64 v47; // rax
  __int64 v48; // rdi
  __int64 v49; // rbx
  __int64 v50; // rbx
  __int64 v51; // rdx
  __int64 v52; // rcx
  const char *v53; // rsi
  __int64 v54; // r8
  __int64 v55; // r9
  __m128 v56; // xmm0
  __m128 v57; // xmm1
  __m128 v58; // xmm2
  __m128 v59; // xmm3
  __m128 v60; // xmm4
  __m128 v61; // xmm5
  __m128 v62; // xmm6
  __m128 v63; // xmm7
  __int64 v64; // rdx
  __int64 v65; // rcx
  const char *v66; // rsi
  __int64 v67; // r8
  __int64 v68; // r9
  __m128 v69; // xmm0
  __m128 v70; // xmm1
  __m128 v71; // xmm2
  __m128 v72; // xmm3
  __m128 v73; // xmm4
  __m128 v74; // xmm5
  __m128 v75; // xmm6
  __m128 v76; // xmm7
  __int128 v78; // [rsp+0h] [rbp-60h] BYREF
  __int64 v79; // [rsp+10h] [rbp-50h]
  _BYTE *v80; // [rsp+18h] [rbp-48h]
  void **v81[2]; // [rsp+20h] [rbp-40h] BYREF
  void *v82; // [rsp+30h] [rbp-30h]

  *a3 = 1; /*0x104a8fbaf*/
  v3 = (_QWORD *)*a1; /*0x104a8fbb2*/
  if ( *a1 == 0 || v3[1] == *v3 ) /*0x104a8fbc5*/
    goto LABEL_32; /*0x104a8fbc5*/
  v80 = a3; /*0x104a8fbd1*/
  isGamepadEvent = 1; /*0x104a8fbd8*/
  if ( *((_DWORD *)*a2 + 51) != 8 ) /*0x104a8fbe2*/
  {
    isGamepadEvent = RBX::InputObject::isGamepadEvent(this: *a2); /*0x104a8fbe9*/
    v3 = (_QWORD *)*a1; /*0x104a8fbec*/
  }
  v78 = 0; /*0x104a8fbf6*/
  v79 = 0; /*0x104a8fbf9*/
  std::vector<RBX::Reflection::Variant>::__init_with_size[abi:ne200100]<RBX::Reflection::Variant*,RBX::Reflection::Variant*>( /*0x104a8fc23*/
    a1: &v78,
    a2: *v3,
    a3: v3[1],
    a4: 0xCCCCCCCCCCCCCCCDLL * ((__int64)(v3[1] - *v3) >> 4));
  v8 = (__int64 *)v78; /*0x104a8fc28*/
  if ( (_QWORD)v78 == *((_QWORD *)&v78 + 1) ) /*0x104a8fc2f*/
  {
LABEL_31:
    v81[0] = (void **)&v78; /*0x104a8fd5b*/
    std::vector<RBX::Reflection::Variant>::__destroy_vector::operator()[abi:ne200100](a1: v81); /*0x104a8fd66*/
    a3 = v80; /*0x104a8fd6b*/
LABEL_32:
    *a3 = 0; /*0x104a8fd6f*/
    return 0; /*0x104a8fd82*/
  }
  while ( 1 ) /*0x104a8fc35*/
  {
    v9 = *v8; /*0x104a8fc35*/
    if ( isGamepadEvent != 0 ) /*0x104a8fc3c*/
      break; /*0x104a8fc3c*/
    if ( RBX::Reflection::Type::getSingleton<RBX::Enums::UserInputTypeEnum::UserInputType>(a1: v7) == v9 ) /*0x104a8fc81*/
    {
      v19 = *v8; /*0x104a8fc87*/
      if ( RBX::Reflection::Type::getSingleton<RBX::Enums::UserInputTypeEnum::UserInputType>(a1: v7) != v19 ) /*0x104a8fc93*/
        RBX::throw_runtime_error( /*0x104a8fda7*/
          this: (RBX *)"Variant cast failed",
          a2: v22,
          a3: v20,
          a4: v21,
          a5: v23,
          a6: v24,
          a7: v25,
          a8: v26,
          a9: v27,
          a10: v28,
          a11: v29,
          a12: v30,
          a13: v31,
          a14: v32,
          a15: v78);
LABEL_29:
      if ( *((_DWORD *)v8 + 4) == *((_DWORD *)*a2 + 51) ) /*0x104a8fd4b*/
        goto LABEL_33; /*0x104a8fd4b*/
    }
LABEL_30:
    v8 += 10; /*0x104a8fd4d*/
    if ( v8 == *((__int64 **)&v78 + 1) ) /*0x104a8fd55*/
      goto LABEL_31; /*0x104a8fd55*/
  }
  v10 = RBX::Reflection::Type::getSingleton<RBX::KeyCode>(); /*0x104a8fc3e*/
  v15 = *v8; /*0x104a8fc43*/
  if ( v10 == v9 ) /*0x104a8fc4a*/
  {
    if ( RBX::Reflection::Type::getSingleton<RBX::KeyCode>() != v15 ) /*0x104a8fca6*/
      RBX::throw_runtime_error( /*0x104a8fdb7*/
        this: (RBX *)"Variant cast failed",
        a2: v35,
        a3: v33,
        a4: v34,
        a5: v36,
        a6: v37,
        a7: v38,
        a8: v39,
        a9: v40,
        a10: v41,
        a11: v42,
        a12: v43,
        a13: v44,
        a14: v45,
        a15: v78);
    v18 = *((_DWORD *)v8 + 4); /*0x104a8fcac*/
  }
  else
  {
    if ( RBX::Reflection::Type::getSingleton<std::string>(a1: v13, a2: v14, a3: v11, a4: v12) != v15 ) /*0x104a8fc54*/
      goto LABEL_22; /*0x104a8fc54*/
    RBX::Reflection::Variant::get<std::string>(a1: v81, a2: v8); /*0x104a8fc61*/
    if ( ((__int64)v81[0] & 1) != 0 ) /*0x104a8fc6b*/
    {
      v18 = 0; /*0x104a8fcb6*/
      if ( v81[1] == (void **)1 ) /*0x104a8fcbd*/
        v18 = *(char *)v82; /*0x104a8fcbf*/
      operator delete(a1: (RBX::Memory *)v82, a2: v17); /*0x104a8fcc2*/
    }
    else
    {
      v18 = 0; /*0x104a8fc6d*/
      if ( LOBYTE(v81[0]) == 2 ) /*0x104a8fc71*/
        v18 = SBYTE1(v81[0]); /*0x104a8fc73*/
    }
  }
  if ( v18 != 0 && *((_DWORD *)*a2 + 49) == v18 ) /*0x104a8fcd4*/
    goto LABEL_33; /*0x104a8fcd4*/
LABEL_22:
  v46 = *v8; /*0x104a8fcda*/
  v47 = RBX::Reflection::Type::getSingleton<RBX::Enums::UserInputTypeEnum::UserInputType>(a1: v16); /*0x104a8fcde*/
  v49 = *v8; /*0x104a8fce3*/
  if ( v47 == v46 ) /*0x104a8fcea*/
  {
    if ( RBX::Reflection::Type::getSingleton<RBX::Enums::UserInputTypeEnum::UserInputType>(a1: v48) != v49 ) /*0x104a8fd38*/
      RBX::throw_runtime_error( /*0x104a8fdc7*/
        this: (RBX *)"Variant cast failed",
        a2: v66,
        a3: v64,
        a4: v65,
        a5: v67,
        a6: v68,
        a7: v69,
        a8: v70,
        a9: v71,
        a10: v72,
        a11: v73,
        a12: v74,
        a13: v75,
        a14: v76,
        a15: v78);
    goto LABEL_29; /*0x104a8fd38*/
  }
  if ( RBX::Reflection::EnumDesc<RBX::PlayerActionType>::singleton() != v49 ) /*0x104a8fcf4*/
    goto LABEL_30; /*0x104a8fcf4*/
  v50 = *v8; /*0x104a8fcf6*/
  if ( RBX::Reflection::EnumDesc<RBX::PlayerActionType>::singleton() != v50 ) /*0x104a8fd02*/
    RBX::throw_runtime_error( /*0x104a8fdd7*/
      this: (RBX *)"Variant cast failed",
      a2: v53,
      a3: v51,
      a4: v52,
      a5: v54,
      a6: v55,
      a7: v56,
      a8: v57,
      a9: v58,
      a10: v59,
      a11: v60,
      a12: v61,
      a13: v62,
      a14: v63,
      a15: v78);
  LODWORD(v81[0]) = *((_DWORD *)v8 + 4); /*0x104a8fd0c*/
  if ( *((_DWORD *)*a2 + 51) != 8 || !RBX::processKeyInputForPlayerMovement(a1: v81, a2: *((_DWORD *)*a2 + 49)) ) /*0x104a8fd25*/
    goto LABEL_30; /*0x104a8fd2c*/
  *v80 = 0; /*0x104a8fd87*/
LABEL_33:
  v81[0] = (void **)&v78; /*0x104a8fd8a*/
  std::vector<RBX::Reflection::Variant>::__destroy_vector::operator()[abi:ne200100](a1: v81); /*0x104a8fd95*/
  return 1; /*0x104a8fd74*/
}

// Address: 0x104aa75b1 | Name: __ZN3RBXL27tryCopyOptionalOrThrowErrorIfEEvNSt3__18optionalIT_EERS3_RKNS1_12basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEESD_
void __fastcall RBX::tryCopyOptionalOrThrowError<float>(
        __int64 a1,
        _DWORD *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __m128 a7,
        __m128 a8,
        __m128 a9,
        __m128 a10,
        __m128 a11,
        __m128 a12,
        __m128 a13,
        __m128 a14)
{
  char v14; // bp
  const char *v15; // rdx
  __int64 v16; // rcx

  if ( (a1 & 0x100000000LL) == 0 ) /*0x104aa75b6*/
  {
    if ( (*(_BYTE *)a3 & 1) != 0 ) /*0x104aa75be*/
      v15 = *(const char **)(a3 + 16); /*0x104aa75c0*/
    else
      v15 = (const char *)(a3 + 1); /*0x104aa75c6*/
    if ( (*(_BYTE *)a4 & 1) != 0 ) /*0x104aa75cc*/
      v16 = *(_QWORD *)(a4 + 16); /*0x104aa75ce*/
    else
      v16 = a4 + 1; /*0x104aa75d4*/
    RBX::throw_runtime_error( /*0x104aa75ea*/
      this: (RBX *)"EditableImage::DrawImageProjected Param %s, is missing %s",
      a2: v15,
      a3: v16,
      a4: v16,
      a5,
      a6,
      a7,
      a8,
      a9,
      a10,
      a11,
      a12,
      a13,
      a14,
      a15: v14);
  }
  *a2 = a1; /*0x104aa75b8*/
}

// Address: 0x104ab578c | Name: __ZN3RBX27tryGetEditableTelemetrySinkEPNS_13EngineContextE
__int64 __fastcall RBX::tryGetEditableTelemetrySink(RBX *this, RBX::EngineContext *a2)
{
  char *v3; // r14

  if ( this == nullptr ) /*0x104ab578f*/
    return 0; /*0x104ab57d4*/
  v3 = (char *)this + 64; /*0x104ab579f*/
  RBX::EngineModule::ModuleInfo<RBX::EditableTelemetryModule>::getId(a1: this, a2); /*0x104ab57a3*/
  if ( RBX::details::SplitHashTable<unsigned long,std::pair<unsigned long,std::unique_ptr<RBX::EngineModule>>,(RBX::SplitHashPolicy)9,0u,RBX::details::DefaultHash<unsigned long>,RBX::details::DefaultEqualTo<unsigned long>,RBX::details::GetMapKey<unsigned long,std::unique_ptr<RBX::EngineModule>>>::find_as<int>(a1: v3) == *((_QWORD *)this + 10) + 16LL * *((unsigned int *)this + 16) ) /*0x104ab57c4*/
    return 0; /*0x104ab57d7*/
  else
    return RBX::EngineContext::getModule<RBX::EditableTelemetryModule>(a1: this) + 16; /*0x104ab57ce*/
}

// Address: 0x104ab62bb | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKiEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<int const&>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x104ab62ce*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 1); /*0x104ab62eb*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x104ab62fa*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x104ab6304*/
  __cxa_throw( /*0x104ab631a*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x104b1bedd | Name: __ZN3RBXL13triDistanceSqERKNS_7Vector3ES2_S2_S2_
float __fastcall RBX::triDistanceSq(
        RBX *this,
        const RBX::Vector3 *a2,
        const RBX::Vector3 *a3,
        const RBX::Vector3 *a4,
        const RBX::Vector3 *a5)
{
  __m128 v5; // xmm12
  __m128 v6; // xmm5
  __m128 v7; // xmm4
  __m128 v8; // xmm1
  __m128 v9; // xmm9
  __m128 v10; // xmm3
  __m128 v11; // xmm11
  __m128 v12; // xmm10
  __m128 v13; // xmm2
  __m128 v14; // xmm6
  __m128 v15; // xmm7
  __m128 v16; // xmm8
  __m128 v17; // xmm0
  __m128 v18; // xmm12
  __m128 v19; // xmm13
  __m128 v20; // xmm14
  __m128 v21; // xmm2
  float v22; // xmm2_4
  float v23; // xmm0_4
  __m128 v24; // xmm0
  __m128 v25; // xmm2
  __m128 v26; // xmm15
  __m128 v27; // xmm2
  __m128 v28; // xmm12
  float v29; // xmm0_4
  __m128 v30; // xmm0
  __m128 v31; // xmm1
  __m128 v32; // xmm1
  __m128 v34; // xmm2
  __m128 v35; // xmm8
  __m128 v36; // xmm6
  __m128 v37; // xmm15
  float v38; // xmm6_4
  __m128 v39; // xmm0
  __m128 v40; // xmm3
  __m128 v41; // xmm3
  __m128 v42; // xmm1
  float v43; // xmm0_4
  __m128 v44; // xmm7
  float v45; // xmm7_4
  float v46; // xmm1_4
  __m128 v47; // xmm4
  __m128 v48; // xmm14
  __m128 v49; // xmm14
  __m128 v50; // xmm4
  __m128 v51; // xmm4
  float v52; // xmm13_4
  __m128 v53; // xmm6
  float v54; // xmm2_4
  float v55; // xmm15_4
  __m128 v56; // xmm0
  float v57; // xmm1_4
  float v58; // xmm2_4
  float v59; // xmm1_4
  __m128 v60; // xmm2
  __m128 v61; // xmm4
  __m128 v62; // xmm0
  __m128 v63; // xmm4
  __m128 v64; // xmm4
  __m128 v65; // xmm2
  float v66; // xmm3_4
  float v67; // xmm0_4
  float v68; // xmm3_4
  __m128 v69; // xmm0
  __m128 v70; // xmm1
  __m128 v71; // xmm0
  __m128 v72; // xmm1
  __m128 v73; // [rsp+0h] [rbp-40h]
  __m128 v74; // [rsp+10h] [rbp-30h]
  float v75; // [rsp+20h] [rbp-20h]
  float v76; // [rsp+30h] [rbp-10h]

  v5 = (__m128)*((unsigned int *)a2 + 2); /*0x104b1bee6*/
  v73 = (__m128)*((unsigned int *)a3 + 2); /*0x104b1bef1*/
  v74 = (__m128)*((unsigned int *)a4 + 2); /*0x104b1bef5*/
  v6 = _mm_sub_ps(_mm_insert_ps(v73, v74, 16), _mm_moveldup_ps(v5)); /*0x104b1bf04*/
  v7 = (__m128)*(unsigned __int64 *)a2; /*0x104b1bf07*/
  v8 = (__m128)*(unsigned __int64 *)a3; /*0x104b1bf0b*/
  v9 = _mm_sub_ps(v8, v7); /*0x104b1bf13*/
  v10 = (__m128)*(unsigned __int64 *)a4; /*0x104b1bf17*/
  v11 = _mm_sub_ps(v10, v7); /*0x104b1bf1f*/
  v12 = (__m128)*(unsigned __int64 *)this; /*0x104b1bf23*/
  v13 = _mm_sub_ps(v12, v7); /*0x104b1bf2c*/
  v14 = _mm_blend_ps(v11, v9, 2); /*0x104b1bf39*/
  v15 = _mm_blend_ps(v9, v11, 2); /*0x104b1bf4a*/
  v16 = _mm_mul_ps(v15, v13); /*0x104b1bf55*/
  v17 = (__m128)*((unsigned int *)this + 2); /*0x104b1bf62*/
  v75 = *((float *)a2 + 2); /*0x104b1bf66*/
  v17.f32[0] = v17.f32[0] - v5.f32[0]; /*0x104b1bf6b*/
  v18 = _mm_shuffle_ps(v6, v6, 225); /*0x104b1bf74*/
  v19 = _mm_add_ps( /*0x104b1bf82*/
          _mm_mul_ps(_mm_moveldup_ps(v17), v18),
          _mm_add_ps(_mm_shuffle_ps(v16, v16, 225), _mm_mul_ps(v14, v13)));
  v20 = _mm_movehdup_ps(v19); /*0x104b1bf86*/
  if ( v20.f32[0] <= 0.0 && v19.f32[0] <= 0.0 ) /*0x104b1bf99*/
  {
    v21 = _mm_mul_ps(v13, v13); /*0x104b1bf9b*/
    v22 = _mm_hadd_ps(v21, v21).f32[0]; /*0x104b1bf9e*/
    v23 = v17.f32[0] * v17.f32[0]; /*0x104b1bfa2*/
    return v23 + v22; /*0x104b1c01e*/
  }
  v76 = *((float *)this + 2); /*0x104b1bfa8*/
  v24 = (__m128)LODWORD(v76); /*0x104b1bfad*/
  v24.f32[0] = v76 - v73.f32[0]; /*0x104b1bfb1*/
  v25 = _mm_sub_ps(v12, v8); /*0x104b1bfba*/
  v26 = _mm_mul_ps(v14, v25); /*0x104b1bfc1*/
  v27 = _mm_mul_ps(v25, v15); /*0x104b1bfc5*/
  v28 = _mm_add_ps(_mm_mul_ps(v18, _mm_moveldup_ps(v24)), _mm_add_ps(_mm_shuffle_ps(v27, v27, 225), v26)); /*0x104b1bfd8*/
  v29 = _mm_movehdup_ps(v28).f32[0]; /*0x104b1bfdc*/
  if ( v29 >= 0.0 && v29 >= v28.f32[0] ) /*0x104b1bfeb*/
  {
    v30 = _mm_sub_ps(v8, v12); /*0x104b1bff0*/
    v31 = _mm_sub_ps(_mm_insert_ps(v8, (__m128)v73.u32[0], 16), _mm_insert_ps(v12, (__m128)LODWORD(v76), 16)); /*0x104b1c006*/
    v32 = _mm_mul_ps(v31, v31); /*0x104b1c00a*/
    v22 = _mm_movehdup_ps(_mm_mul_ps(v30, v30)).f32[0] + v32.f32[0]; /*0x104b1c011*/
    v23 = _mm_movehdup_ps(v32).f32[0]; /*0x104b1c015*/
    return v23 + v22; /*0x104b1c015*/
  }
  v34 = (__m128)*((unsigned int *)this + 2); /*0x104b1c01f*/
  v34.f32[0] = v76 - v74.f32[0]; /*0x104b1c023*/
  v35 = _mm_sub_ps(v12, v10); /*0x104b1c02c*/
  v36 = _mm_mul_ps(v14, v35); /*0x104b1c030*/
  v37 = _mm_add_ps( /*0x104b1c048*/
          _mm_mul_ps(_mm_moveldup_ps(v34), v6),
          _mm_add_ps(_mm_mul_ps(v15, v35), _mm_shuffle_ps(v36, v36, 225)));
  v38 = _mm_movehdup_ps(v37).f32[0]; /*0x104b1c04c*/
  if ( v38 >= 0.0 && v38 >= v37.f32[0] ) /*0x104b1c05d*/
  {
    v39 = _mm_sub_ps(v10, v12); /*0x104b1c062*/
    v40 = _mm_sub_ps(_mm_insert_ps(v10, (__m128)v74.u32[0], 16), _mm_insert_ps(v12, (__m128)LODWORD(v76), 16)); /*0x104b1c078*/
    v41 = _mm_mul_ps(v40, v40); /*0x104b1c07c*/
    v42.f32[0] = _mm_movehdup_ps(_mm_mul_ps(v39, v39)).f32[0] + v41.f32[0]; /*0x104b1c083*/
    v43 = _mm_movehdup_ps(v41).f32[0]; /*0x104b1c087*/
    return v43 + v42.f32[0]; /*0x104b1c08f*/
  }
  v44 = _mm_mul_ps(_mm_shuffle_ps(v19, v19, 225), v28); /*0x104b1c09a*/
  v45 = _mm_hsub_ps(v44, v44).f32[0]; /*0x104b1c09e*/
  if ( v29 <= 0.0 && v20.f32[0] >= 0.0 && v45 <= 0.0 ) /*0x104b1c0b0*/
  {
    v20.f32[0] = v20.f32[0] / (float)(v20.f32[0] - v29); /*0x104b1c0ba*/
    v46 = v75 + (float)(v6.f32[0] * v20.f32[0]); /*0x104b1c0c8*/
    v47 = _mm_add_ps(v7, _mm_mul_ps(v9, _mm_moveldup_ps(v20))); /*0x104b1c0d5*/
LABEL_20:
    v50 = _mm_sub_ps(v47, v12); /*0x104b1c129*/
    v51 = _mm_mul_ps(v50, v50); /*0x104b1c12d*/
    return (float)((float)(v46 - v76) * (float)(v46 - v76)) + _mm_hadd_ps(v51, v51).f32[0]; /*0x104b1c144*/
  }
  v48 = _mm_mul_ps(v19, v37); /*0x104b1c0df*/
  v49 = _mm_hsub_ps(v48, v48); /*0x104b1c0e3*/
  if ( v38 <= 0.0 && v49.f32[0] <= 0.0 && v19.f32[0] >= 0.0 ) /*0x104b1c0fc*/
  {
    v19.f32[0] = v19.f32[0] / (float)(v19.f32[0] - v38); /*0x104b1c106*/
    v46 = v75 + (float)(_mm_movehdup_ps(v6).f32[0] * v19.f32[0]); /*0x104b1c118*/
    v47 = _mm_add_ps(v7, _mm_mul_ps(v11, _mm_moveldup_ps(v19))); /*0x104b1c125*/
    goto LABEL_20; /*0x104b1c125*/
  }
  v52 = v38; /*0x104b1c149*/
  v53 = _mm_mul_ps(v37, v28); /*0x104b1c151*/
  v54 = _mm_movehdup_ps(v53).f32[0] - v53.f32[0]; /*0x104b1c159*/
  if ( v54 <= 0.0 ) /*0x104b1c160*/
  {
    v28.f32[0] = v28.f32[0] - v29; /*0x104b1c162*/
    if ( v28.f32[0] >= 0.0 ) /*0x104b1c16e*/
    {
      v55 = v37.f32[0] - v52; /*0x104b1c170*/
      if ( v55 >= 0.0 ) /*0x104b1c179*/
      {
        v28.f32[0] = v28.f32[0] / (float)(v55 + v28.f32[0]); /*0x104b1c22b*/
        v65 = _mm_moveldup_ps(v10); /*0x104b1c234*/
        v66 = (float)(_mm_movehdup_ps(_mm_sub_ps(v10, v8)).f32[0] * v28.f32[0]) + _mm_movehdup_ps(v8).f32[0]; /*0x104b1c244*/
        v67 = _mm_movehdup_ps(v12).f32[0]; /*0x104b1c248*/
        v68 = (float)(v66 - v67) * (float)(v66 - v67); /*0x104b1c251*/
        v65.f32[0] = v74.f32[0]; /*0x104b1c259*/
        v69 = _mm_moveldup_ps(v8); /*0x104b1c25d*/
        v69.f32[0] = v73.f32[0]; /*0x104b1c265*/
        v70 = _mm_add_ps(_mm_mul_ps(_mm_moveldup_ps(v28), _mm_sub_ps(v65, v69)), v69); /*0x104b1c274*/
        v71 = _mm_moveldup_ps(v12); /*0x104b1c277*/
        v71.f32[0] = v76; /*0x104b1c280*/
        v72 = _mm_sub_ps(v70, v71); /*0x104b1c284*/
        v42 = _mm_mul_ps(v72, v72); /*0x104b1c287*/
        v43 = _mm_movehdup_ps(v42).f32[0] + v68; /*0x104b1c28e*/
        return v43 + v42.f32[0]; /*0x104b1c292*/
      }
    }
  }
  v56 = (__m128)0x3F800000u; /*0x104b1c18b*/
  v56.f32[0] = 1.0 / (float)(v45 + (float)(v54 + v49.f32[0])); /*0x104b1c193*/
  v49.f32[0] = v49.f32[0] * v56.f32[0]; /*0x104b1c197*/
  v56.f32[0] = v56.f32[0] * v45; /*0x104b1c19c*/
  v57 = (float)(_mm_movehdup_ps(v11).f32[0] * v56.f32[0]) /*0x104b1c1bb*/
      + (float)(_mm_movehdup_ps(v7).f32[0] + (float)(_mm_movehdup_ps(v9).f32[0] * v49.f32[0]));
  v58 = _mm_movehdup_ps(v12).f32[0]; /*0x104b1c1bf*/
  v59 = (float)(v57 - v58) * (float)(v57 - v58); /*0x104b1c1c8*/
  v60 = _mm_moveldup_ps(v7); /*0x104b1c1de*/
  v60.f32[0] = v75; /*0x104b1c1e6*/
  v61 = _mm_add_ps( /*0x104b1c1ff*/
          _mm_mul_ps(_mm_moveldup_ps(v56), _mm_insert_ps(_mm_moveldup_ps(v11), v6, 76)),
          _mm_add_ps(v60, _mm_mul_ps(_mm_moveldup_ps(v49), _mm_insert_ps(v6, v9, 16))));
  v62 = _mm_moveldup_ps(v12); /*0x104b1c202*/
  v62.f32[0] = v76; /*0x104b1c20b*/
  v63 = _mm_sub_ps(v61, v62); /*0x104b1c20f*/
  v64 = _mm_mul_ps(v63, v63); /*0x104b1c212*/
  return (float)(_mm_movehdup_ps(v64).f32[0] + v59) + v64.f32[0]; /*0x104b1c01d*/
}

// Address: 0x104b2775d | Name: __ZN3RBXL24trySetGuidToSourceScriptERNS_4GuidE
__int64 __fastcall RBX::trySetGuidToSourceScript(RBX *this, RBX::Guid *a2)
{
  __int64 v3; // rbx
  std::__shared_weak_count *v4; // r14
  __int128 v6; // [rsp+8h] [rbp-28h] BYREF

  v3 = *(_QWORD *)(RBX::Security::Context::current(this) + 24); /*0x104b27772*/
  if ( *(_BYTE *)(lua_getthreaddata(a1: v3) + 162) == 1 ) /*0x104b27785*/
  {
    RBX::getScriptForFunctionAtLevel(a1: &v6, a2: v3, a3: 1u); /*0x104b27796*/
    LOBYTE(v3) = (_QWORD)v6 != 0; /*0x104b277a1*/
    if ( (_QWORD)v6 != 0 ) /*0x104b277a4*/
      *(_QWORD *)this = *(_QWORD *)(v6 + 48); /*0x104b277aa*/
    v4 = *((std::__shared_weak_count **)&v6 + 1); /*0x104b277ad*/
    if ( *((_QWORD *)&v6 + 1) != 0 /*0x104b277c6*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v6 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(a1: v4); /*0x104b277ce*/
      std::__shared_weak_count::__release_weak(this: v4); /*0x104b277d4*/
    }
  }
  else
  {
    LODWORD(v3) = 0; /*0x104b277db*/
  }
  return (unsigned int)v3; /*0x104b277df*/
}

// Address: 0x104bc0f1b | Name: __ZN3RBXL12toValueTableERKNS_18SplineControlPointINS_7Vector3EEE
_OWORD *__fastcall RBX::toValueTable(_OWORD *a1, __int64 a2)
{
  _OWORD v5[3]; // [rsp+0h] [rbp-30h] BYREF

  RBX::make_shared<RBX::Reflection::ValueTable>(a1: (RSL::Arena *)v5); /*0x104bc0f35*/
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_impl<char const(&)[9],RBX::Vector3 const&>( /*0x104bc0f47*/
    a1: *(_QWORD *)&v5[0],
    a2: "Position",
    a3: a2);
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_impl<char const(&)[12],RBX::Vector3 const&>( /*0x104bc0f5b*/
    a1: *(_QWORD *)&v5[0],
    a2: "LeftTangent",
    a3: a2 + 12);
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_impl<char const(&)[13],RBX::Vector3 const&>( /*0x104bc0f72*/
    a1: *(_QWORD *)&v5[0],
    a2: "RightTangent",
    a3: a2 + 24);
  *a1 = v5[0]; /*0x104bc0f7b*/
  return a1; /*0x104bc0f81*/
}

// Address: 0x104c2e260 | Name: __ZN3RBX10toSlimEnumENS_17WrapLayerAutoSkinE
__int64 __fastcall RBX::toSlimEnum(unsigned __int8 a1)
{
  return a1; /*0x104c2e268*/
}

// Address: 0x104c2e26a | Name: __ZN3RBX10toSlimEnumENS_5Enums15BodyPartR15Enum11R15PartTypeE
__int64 __fastcall RBX::toSlimEnum(unsigned int a1)
{
  return a1; /*0x104c2e270*/
}

// Address: 0x104c2e272 | Name: __ZN3RBX10toSlimEnumENS_15HumanoidRigTypeE
_BOOL8 __fastcall RBX::toSlimEnum(int a1)
{
  return a1 == 1; /*0x104c2e27e*/
}

// Address: 0x104c2e280 | Name: __ZN3RBX10toSlimEnumENS_13AccessoryTypeE
__int64 __fastcall RBX::toSlimEnum(unsigned int a1)
{
  return a1; /*0x104c2e286*/
}

// Address: 0x104c2e288 | Name: __ZN3RBX10toSlimEnumENS_11RenderShapeE
__int64 __fastcall RBX::toSlimEnum(unsigned int a1)
{
  if ( a1 >= 9 ) /*0x104c2e28b*/
    RBXCRASH(a1: "Unhandled enumeration.", a2: ""); /*0x104c2e2a2*/
  return a1; /*0x104c2e28f*/
}

// Address: 0x104c2e2a7 | Name: __ZN3RBX10toSlimEnumENS_20TexturePackAlphaModeE
__int64 __fastcall RBX::toSlimEnum(unsigned int a1)
{
  if ( a1 >= 5 ) /*0x104c2e2aa*/
    RBXCRASH(a1: "Unhandled enumeration.", a2: ""); /*0x104c2e2cb*/
  return dword_10972D354[a1]; /*0x104c2e2b8*/
}

// Address: 0x104c2e2d0 | Name: __ZN3RBX10toSlimEnumENS_12MaterialTypeE
__int64 __fastcall RBX::toSlimEnum(int a1)
{
  __int64 result; // rax

  if ( a1 > 1283 ) /*0x104c2e2d6*/
  {
    if ( a1 > 1791 ) /*0x104c2e32c*/
    {
      if ( a1 <= 2303 ) /*0x104c2e3bc*/
      {
        if ( a1 == 1792 ) /*0x104c2e561*/
        {
          return 35; /*0x104c2e62b*/
        }
        else
        {
          if ( a1 != 2048 ) /*0x104c2e56d*/
            goto LABEL_99; /*0x104c2e56d*/
          return 36; /*0x104c2e573*/
        }
      }
      else
      {
        switch ( a1 ) /*0x104c2e3df*/
        {
          case 2304: /*0x104c2e3df*/
            return 37; /*0x104c2e3e6*/
          case 2305: /*0x104c2e3df*/
            return 38; /*0x104c2e64e*/
          case 2306: /*0x104c2e3df*/
            return 39; /*0x104c2e63c*/
          case 2307: /*0x104c2e3df*/
            return 40; /*0x104c2e642*/
          case 2308: /*0x104c2e3df*/
            return 41; /*0x104c2e636*/
          case 2309: /*0x104c2e3df*/
            return 42; /*0x104c2e654*/
          case 2310: /*0x104c2e3df*/
            return 43; /*0x104c2e65a*/
          case 2311: /*0x104c2e3df*/
            return 44; /*0x104c2e648*/
          default:
            if ( a1 != 0xFFFF ) /*0x104c2e59b*/
              goto LABEL_99; /*0x104c2e59b*/
            result = 45; /*0x104c2e5a1*/
            break; /*0x104c2e5a6*/
        }
      }
    }
    else if ( a1 > 1375 ) /*0x104c2e338*/
    {
      if ( a1 > 1551 ) /*0x104c2e423*/
      {
        switch ( a1 ) /*0x104c2e537*/
        {
          case 1552: /*0x104c2e537*/
            return 32; /*0x104c2e625*/
          case 1568: /*0x104c2e537*/
            return 33; /*0x104c2e5e9*/
          case 1584: /*0x104c2e537*/
            return 34; /*0x104c2e555*/
          default:
            goto LABEL_99; /*0x104c2e54f*/
        }
      }
      else
      {
        switch ( a1 ) /*0x104c2e42f*/
        {
          case 1376: /*0x104c2e42f*/
            return 29; /*0x104c2e60d*/
          case 1392: /*0x104c2e42f*/
            return 30; /*0x104c2e5d1*/
          case 1536: /*0x104c2e42f*/
            return 31; /*0x104c2e44d*/
          default:
            goto LABEL_99; /*0x104c2e447*/
        }
      }
    }
    else if ( a1 > 1327 ) /*0x104c2e344*/
    {
      switch ( a1 ) /*0x104c2e4e3*/
      {
        case 1328: /*0x104c2e4e3*/
          return 26; /*0x104c2e619*/
        case 1344: /*0x104c2e4e3*/
          return 27; /*0x104c2e5dd*/
        case 1360: /*0x104c2e4e3*/
          return 28; /*0x104c2e501*/
        default:
          goto LABEL_99; /*0x104c2e4fb*/
      }
    }
    else
    {
      switch ( a1 ) /*0x104c2e350*/
      {
        case 1284: /*0x104c2e350*/
          return 23; /*0x104c2e601*/
        case 1296: /*0x104c2e350*/
          return 24; /*0x104c2e5c5*/
        case 1312: /*0x104c2e350*/
          return 25; /*0x104c2e36e*/
        default:
          goto LABEL_99; /*0x104c2e368*/
      }
    }
  }
  else if ( a1 <= 831 ) /*0x104c2e2de*/
  {
    if ( a1 <= 783 ) /*0x104c2e37a*/
    {
      if ( a1 <= 287 ) /*0x104c2e459*/
      {
        result = 0; /*0x104c2e579*/
        if ( a1 != 256 ) /*0x104c2e581*/
        {
          if ( a1 != 272 ) /*0x104c2e589*/
            goto LABEL_99; /*0x104c2e589*/
          return 1; /*0x104c2e58f*/
        }
      }
      else
      {
        switch ( a1 ) /*0x104c2e465*/
        {
          case 288: /*0x104c2e465*/
            return 2; /*0x104c2e5ad*/
          case 512: /*0x104c2e465*/
            return 3; /*0x104c2e5a7*/
          case 528: /*0x104c2e465*/
            return 4; /*0x104c2e483*/
          default:
            goto LABEL_99; /*0x104c2e47d*/
        }
      }
    }
    else if ( a1 > 803 ) /*0x104c2e386*/
    {
      switch ( a1 ) /*0x104c2e48f*/
      {
        case 804: /*0x104c2e48f*/
          return 15; /*0x104c2e5f5*/
        case 816: /*0x104c2e48f*/
          return 7; /*0x104c2e5b9*/
        case 820: /*0x104c2e48f*/
          return 16; /*0x104c2e4ad*/
        default:
          goto LABEL_99; /*0x104c2e4a7*/
      }
    }
    else
    {
      switch ( a1 ) /*0x104c2e392*/
      {
        case 784: /*0x104c2e392*/
          return 5; /*0x104c2e5ef*/
        case 788: /*0x104c2e392*/
          return 14; /*0x104c2e5b3*/
        case 800: /*0x104c2e392*/
          return 6; /*0x104c2e3b0*/
        default:
          goto LABEL_99; /*0x104c2e3aa*/
      }
    }
  }
  else if ( a1 > 911 ) /*0x104c2e2ea*/
  {
    if ( a1 > 1071 ) /*0x104c2e3ed*/
    {
      switch ( a1 ) /*0x104c2e50d*/
      {
        case 1072: /*0x104c2e50d*/
          return 20; /*0x104c2e61f*/
        case 1088: /*0x104c2e50d*/
          return 21; /*0x104c2e5e3*/
        case 1280: /*0x104c2e50d*/
          return 22; /*0x104c2e52b*/
        default:
          goto LABEL_99; /*0x104c2e525*/
      }
    }
    else
    {
      switch ( a1 ) /*0x104c2e3f9*/
      {
        case 912: /*0x104c2e3f9*/
          return 13; /*0x104c2e607*/
        case 1040: /*0x104c2e3f9*/
          return 18; /*0x104c2e5cb*/
        case 1056: /*0x104c2e3f9*/
          return 19; /*0x104c2e417*/
        default:
          goto LABEL_99; /*0x104c2e411*/
      }
    }
  }
  else if ( a1 > 863 ) /*0x104c2e2f6*/
  {
    switch ( a1 ) /*0x104c2e4b9*/
    {
      case 864: /*0x104c2e4b9*/
        return 10; /*0x104c2e613*/
      case 880: /*0x104c2e4b9*/
        return 11; /*0x104c2e5d7*/
      case 896: /*0x104c2e4b9*/
        return 12; /*0x104c2e4d7*/
      default:
        goto LABEL_99; /*0x104c2e4d1*/
    }
  }
  else
  {
    switch ( a1 ) /*0x104c2e302*/
    {
      case 832: /*0x104c2e302*/
        return 8; /*0x104c2e5fb*/
      case 836: /*0x104c2e302*/
        return 17; /*0x104c2e5bf*/
      case 848: /*0x104c2e302*/
        return 9; /*0x104c2e325*/
      default:
LABEL_99:
        RBXCRASH(a1: "Unhandled enumeration.", a2: ""); /*0x104c2e65b*/
    }
  }
  return result; /*0x104c2e325*/
}

// Address: 0x104c2e694 | Name: __ZN3RBX10toSlimEnumENS_5Enums12MeshTypeEnum8MeshTypeE
__int64 __fastcall RBX::toSlimEnum(unsigned int a1)
{
  if ( a1 >= 0xC ) /*0x104c2e697*/
    RBXCRASH(a1: "Unhandled enumeration.", a2: ""); /*0x104c2e6ae*/
  return a1; /*0x104c2e69b*/
}

// Address: 0x104c2e6b3 | Name: __ZN3RBX10toSlimEnumENS_8NormalIdE
__int64 __fastcall RBX::toSlimEnum(unsigned int a1)
{
  if ( a1 >= 7 ) /*0x104c2e6b6*/
    RBXCRASH(a1: "Unhandled enumeration.", a2: ""); /*0x104c2e6cf*/
  return (unsigned __int8)a1; /*0x104c2e6bc*/
}

// Address: 0x104c2e6d4 | Name: __ZN3RBX10toSlimEnumENS_5Enums9StyleEnum16VisualTrussStyleE
__int64 __fastcall RBX::toSlimEnum(unsigned int a1)
{
  if ( a1 >= 3 ) /*0x104c2e6d7*/
    RBXCRASH(a1: 0, a2: ""); /*0x104c2e6eb*/
  return (unsigned __int8)a1; /*0x104c2e6dd*/
}

// Address: 0x104c2e6f0 | Name: __ZN3RBX10toSlimEnumENS_11SurfaceTypeE
__int64 __fastcall RBX::toSlimEnum(int a1)
{
  unsigned int v1; // edi
  __int64 result; // rax

  v1 = a1 - 1; /*0x104c2e6f4*/
  if ( v1 > 9 ) /*0x104c2e6f9*/
    LOBYTE(result) = 0; /*0x104c2e709*/
  else
    LOBYTE(result) = byte_10972D368[v1]; /*0x104c2e704*/
  return (unsigned __int8)result; /*0x104c2e70e*/
}

// Address: 0x104ca926a | Name: __ZN3RBX4trimERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
__int64 __fastcall RBX::trim(__int64 a1, unsigned __int8 *a2)
{
  unsigned int v3; // eax
  unsigned __int64 v4; // rax
  unsigned __int8 *v5; // rsi
  unsigned __int64 first_not_of; // rax
  unsigned __int64 v7; // r12
  __int64 last_not_of; // rax
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rax
  unsigned __int8 *v12; // [rsp+0h] [rbp-40h] BYREF
  unsigned __int64 v13; // [rsp+8h] [rbp-38h]
  unsigned __int8 *v14; // [rsp+10h] [rbp-30h] BYREF
  unsigned __int64 v15; // [rsp+18h] [rbp-28h]

  v3 = *a2; /*0x104ca927c*/
  if ( (v3 & 1) != 0 ) /*0x104ca9281*/
  {
    v4 = *((_QWORD *)a2 + 1); /*0x104ca9283*/
    v5 = *((unsigned __int8 **)a2 + 2); /*0x104ca9287*/
  }
  else
  {
    v5 = a2 + 1; /*0x104ca928d*/
    v4 = v3 >> 1; /*0x104ca9290*/
  }
  v12 = v5; /*0x104ca9296*/
  v13 = v4; /*0x104ca9299*/
  first_not_of = RBX::detail::StringViewBase::find_first_not_of(a1: &v12, a2: " \t\n\v\f\r", a3: 6, a4: 0); /*0x104ca92b1*/
  if ( first_not_of >= v13 ) /*0x104ca92bd*/
    first_not_of = v13; /*0x104ca92bd*/
  v7 = v13 - first_not_of; /*0x104ca92c1*/
  v14 = &v12[first_not_of]; /*0x104ca92cb*/
  v15 = v13 - first_not_of; /*0x104ca92ce*/
  last_not_of = RBX::detail::StringViewBase::find_last_not_of(a1: &v14, a2: " \t\n\v\f\r", a3: 6, a4: -1); /*0x104ca92e4*/
  if ( v14 != nullptr ) /*0x104ca92ef*/
  {
    v9 = last_not_of + 1; /*0x104ca92fb*/
    if ( v9 >= v15 ) /*0x104ca9301*/
      v9 = v15; /*0x104ca9301*/
    v10 = v15 - v7 + v9; /*0x104ca9305*/
    if ( v15 < v10 ) /*0x104ca930b*/
      v10 = v15; /*0x104ca930b*/
    std::string::basic_string[abi:ne200100](a1, a2: v14, a3: v10); /*0x104ca9315*/
  }
  else
  {
    *(_OWORD *)a1 = 0; /*0x104ca931f*/
    *(_QWORD *)(a1 + 16) = 0; /*0x104ca9322*/
  }
  return a1; /*0x104ca932d*/
}

// Address: 0x104cbb6ad | Name: __ZN3RBX34treeDiffHasNonCustomizationChangesERKNS_9ITreeDiffERKNS_8InstanceE
__int64 __fastcall RBX::treeDiffHasNonCustomizationChanges(__int64 a1, __int64 a2)
{
  if ( qword_10D3F58E0 != 0 ) /*0x104cbb6c1*/
    return (*(__int64 (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)qword_10D3F58E0 + 48LL))( /*0x104cbb6cb*/
             a1: qword_10D3F58E0,
             a2: a1,
             a3: a2);
  else
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 16LL))(a1); /*0x104cbb6d4*/
}

// Address: 0x104cc6af0 | Name: __ZN3RBX8toVectorENSt3__110shared_ptrIKNS0_6vectorINS_10Reflection7VariantENS0_9allocatorIS4_EEEEEE
__int64 __fastcall RBX::toVector(__int64 a1, __int64 ***a2, __int64 a3, __int64 a4)
{
  __int64 *v5; // r15
  __int64 *i; // r12
  __int64 v7; // r13
  void (__fastcall **v8)(__int64, char *); // rax
  __int64 v9; // rax
  __int64 v10; // rdx
  __int64 v11; // rcx
  const char *v12; // rsi
  __int64 v13; // r8
  __int64 v14; // r9
  __m128 v15; // xmm0
  __m128 v16; // xmm1
  __m128 v17; // xmm2
  __m128 v18; // xmm3
  __m128 v19; // xmm4
  __m128 v20; // xmm5
  __m128 v21; // xmm6
  __m128 v22; // xmm7
  char *v23; // rsi
  __int64 v25; // [rsp+0h] [rbp-80h]
  __int64 v26; // [rsp+8h] [rbp-78h]
  char v27[64]; // [rsp+10h] [rbp-70h] BYREF

  *(_OWORD *)a1 = 0; /*0x104cc6b15*/
  *(_QWORD *)(a1 + 16) = 0; /*0x104cc6b18*/
  v5 = **a2; /*0x104cc6b23*/
  for ( i = (*a2)[1]; v5 != i; v5 += 10 ) /*0x104cc6b2d*/
  {
    v7 = *v5; /*0x104cc6b33*/
    v25 = *v5; /*0x104cc6b36*/
    v8 = (void (__fastcall **)(__int64, char *))v5[1]; /*0x104cc6b42*/
    if ( v8 != nullptr ) /*0x104cc6b49*/
    {
      (*v8)(a1: (__int64)(v5 + 2), a2: v27); /*0x104cc6b52*/
      v9 = v5[1]; /*0x104cc6b54*/
      v7 = v25; /*0x104cc6b58*/
    }
    else
    {
      v9 = 0; /*0x104cc6b5e*/
    }
    v26 = v9; /*0x104cc6b60*/
    if ( RBX::Reflection::Type::getSingleton<std::string>(a1, a2, a3, a4) == v7 ) /*0x104cc6b6c*/
    {
      if ( RBX::Reflection::Type::getSingleton<std::string>(a1, a2, a3, a4) != v25 ) /*0x104cc6b7a*/
        RBX::throw_runtime_error( /*0x104cc6bd2*/
          this: (RBX *)"Variant cast failed",
          a2: v12,
          a3: v10,
          a4: v11,
          a5: v13,
          a6: v14,
          a7: v15,
          a8: v16,
          a9: v17,
          a10: v18,
          a11: v19,
          a12: v20,
          a13: v21,
          a14: v22,
          a15: v25);
      v23 = (char *)v26; /*0x104cc6b7c*/
      if ( v26 != 0 ) /*0x104cc6b83*/
        v23 = v27; /*0x104cc6b83*/
      std::vector<std::string>::push_back[abi:ne200100](a1, a2: (__int64)v23); /*0x104cc6b8a*/
    }
    if ( v26 != 0 ) /*0x104cc6b96*/
      (*(void (__fastcall **)(char *))(v26 + 16))(a1: v27); /*0x104cc6b9b*/
  }
  return a1; /*0x104cc6bba*/
}

// Address: 0x104cc6c1e | Name: __ZN3RBX12toValueArrayERKNSt3__16vectorINS0_12basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEENS5_IS7_EEEE
_OWORD *__fastcall RBX::toValueArray(_OWORD *a1, __int64 *a2)
{
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // rdi
  __int64 v6; // rsi
  __int64 v7; // r15
  __int64 v8; // r14
  std::__shared_weak_count *v9; // rbx
  std::__shared_weak_count *v10; // rax
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v14[2]; // [rsp+10h] [rbp-90h] BYREF
  __int64 v15; // [rsp+20h] [rbp-80h] BYREF
  __int64 *v16; // [rsp+28h] [rbp-78h] BYREF
  char v17[64]; // [rsp+30h] [rbp-70h] BYREF

  RBX::make_shared<std::vector<RBX::Reflection::Variant>>(a1: (RSL::Arena *)v14, (unsigned __int64)a2); /*0x104cc6c4e*/
  v7 = *a2; /*0x104cc6c53*/
  v8 = a2[1]; /*0x104cc6c56*/
  if ( *a2 != v8 ) /*0x104cc6c5d*/
  {
    do /*0x104cc6cac*/
    {
      v9 = v14[0]; /*0x104cc6c67*/
      v15 = RBX::Reflection::Type::getSingleton<std::string>(a1: v5, a2: v6, a3: v3, a4: v4); /*0x104cc6c73*/
      v16 = nullptr; /*0x104cc6c77*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>(a1: &v16, a2: v7); /*0x104cc6c85*/
      std::vector<RBX::Reflection::Variant>::push_back[abi:ne200100](a1: (__int64)v9, a2: (__int64)&v15); /*0x104cc6c90*/
      if ( v16 != nullptr ) /*0x104cc6c9c*/
        ((void (__fastcall *)(char *))v16[2])(a1: v17); /*0x104cc6ca2*/
      v7 += 24; /*0x104cc6ca5*/
    }
    while ( v7 != v8 ); /*0x104cc6cac*/
  }
  v10 = v14[1]; /*0x104cc6cae*/
  *a1 = *(_OWORD *)v14; /*0x104cc6cc3*/
  if ( v10 != nullptr ) /*0x104cc6cca*/
  {
    _InterlockedIncrement64((volatile signed __int64 *)v10 + 1); /*0x104cc6ccc*/
    v11 = v14[1]; /*0x104cc6cd1*/
    if ( v14[1] != nullptr /*0x104cc6ced*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(a1: v11); /*0x104cc6cf5*/
      std::__shared_weak_count::__release_weak(this: v11); /*0x104cc6cfb*/
    }
  }
  return a1; /*0x104cc6d13*/
}

// Address: 0x104d8d47a | Name: __ZN3RBXL22tryCreateEditableImageEPNS_9DataModelERKNS_7Vector2ENSt3__18optionalINS_6GImageEEEb
RBX::Security::Context *__fastcall RBX::tryCreateEditableImage(
        RBX::Security::Context *a1,
        RBX::DataModel *a2,
        double *a3,
        __int64 a4,
        int a5)
{
  RBX::Security::Context *v8; // rbx
  RBX::EngineContext *v9; // rdi
  _QWORD *v10; // r13
  __int64 v11; // rax
  __int64 (__fastcall *v12)(__int64, _QWORD); // rcx
  RBX::EditableService *v13; // r13
  int MemoryUsage; // r14d
  int v15; // ebx
  RBX::EngineContext *v16; // rdi
  RBX::Security::Context *result; // rax
  __int64 v18; // rsi
  _QWORD v19[2]; // [rsp+0h] [rbp-50h] BYREF
  int v20; // [rsp+14h] [rbp-3Ch]
  __int64 v21; // [rsp+18h] [rbp-38h]
  RBX::Security::Context *v22; // [rsp+20h] [rbp-30h]

  v21 = a4; /*0x104d8d48e*/
  v8 = a1; /*0x104d8d498*/
  v10 = (_QWORD *)RBX::Security::Context::current(this: a1); /*0x104d8d4a0*/
  v11 = v10[5]; /*0x104d8d4a3*/
  v12 = (__int64 (__fastcall *)(__int64, _QWORD))v10[6]; /*0x104d8d4a7*/
  if ( v12 != nullptr ) /*0x104d8d4ae*/
  {
    v11 = v12(a1: v11, a2: v10[3]); /*0x104d8d4b7*/
    v10[5] = v11; /*0x104d8d4b9*/
    v10[6] = 0; /*0x104d8d4bd*/
  }
  if ( (v11 & 8) != 0 ) /*0x104d8d4c7*/
  {
    if ( FFlag::EditableUseEngineContextDataModel == 1 ) /*0x104d8d545*/
    {
      RBX::Creatable::createWithEngineContext<RBX::EditableImage,float const&,float const&>( /*0x104d8d55d*/
        a1: v8,
        a2: *((_QWORD *)a2 + 69) & 0xFFFFFFFFFFFFFFF8LL,
        a3,
        a4: (char *)a3 + 4);
    }
    else
    {
      v19[0] = RBX::EngineContext::getThreadLocal(this: v9); /*0x104d8d59e*/
      LODWORD(v19[1]) = 3000183; /*0x104d8d5a1*/
      RBX::Creatable::createImpl<RBX::EditableImage,RBX::ForceConstructionInCreatable &,float const&,float const&>( /*0x104d8d5b1*/
        a1: v8,
        a2: v19,
        a3,
        a4: (char *)a3 + 4);
    }
    v18 = v21; /*0x104d8d5b6*/
    if ( *(_BYTE *)(v21 + 32) != 1 ) /*0x104d8d5be*/
      return v8; /*0x104d8d5be*/
    goto LABEL_15; /*0x104d8d5be*/
  }
  v20 = a5; /*0x104d8d4c9*/
  v22 = v8; /*0x104d8d4cd*/
  v13 = (RBX::EditableService *)RBX::ServiceProvider::create<RBX::EditableService>(a1: (char *)a2 + 464, a2: 0); /*0x104d8d4e0*/
  MemoryUsage = RBX::EditableService::getMemoryUsage(this: v13); /*0x104d8d4eb*/
  v15 = MemoryUsage + RBX::EditableImage::calculateMemoryCost(a1: *a3); /*0x104d8d4fa*/
  if ( v15 > (int)RBX::EditableService::getBudget(this: v13, a2) ) /*0x104d8d50a*/
  {
    RBX::EditableService::incrementImageCounter( /*0x104d8d527*/
      a1: v13,
      a2: 8 - (unsigned int)*(unsigned __int8 *)(v21 + 32),
      a3: (unsigned __int8)v20,
      a4: 1);
    result = v22; /*0x104d8d52f*/
    *(_OWORD *)v22 = 0; /*0x104d8d533*/
    return result; /*0x104d8d536*/
  }
  if ( FFlag::EditableUseEngineContextDataModel == 1 ) /*0x104d8d56e*/
  {
    v8 = v22; /*0x104d8d580*/
    RBX::Creatable::createWithEngineContext<RBX::EditableImage,float const&,float const&>( /*0x104d8d58a*/
      a1: v22,
      a2: *((_QWORD *)a2 + 69) & 0xFFFFFFFFFFFFFFF8LL,
      a3,
      a4: (char *)a3 + 4);
  }
  else
  {
    v19[0] = RBX::EngineContext::getThreadLocal(this: v16); /*0x104d8d5d7*/
    LODWORD(v19[1]) = 3000183; /*0x104d8d5da*/
    v8 = v22; /*0x104d8d5eb*/
    RBX::Creatable::createImpl<RBX::EditableImage,RBX::ForceConstructionInCreatable &,float const&,float const&>( /*0x104d8d5ee*/
      a1: v22,
      a2: v19,
      a3,
      a4: (char *)a3 + 4);
  }
  v18 = v21; /*0x104d8d5f3*/
  if ( *(_BYTE *)(v21 + 32) == 1 ) /*0x104d8d5fb*/
LABEL_15:
    RBX::EditableImage::moveAssignImage(a1: *(_QWORD *)v8, a2: v18); /*0x104d8d5fd*/
  return v8; /*0x104d8d608*/
}

// Address: 0x104dc2798 | Name: __ZNK3RBX14TexturePackKeyeqERKS0_
__int64 __fastcall RBX::TexturePackKey::operator==(__int64 a1, _DWORD *a2)
{
  _DWORD *v2; // rbx
  __int64 v4; // r15
  __int64 v5; // r15
  __int64 v6; // r13
  __int64 v7; // r12
  __int64 v8; // r14
  unsigned __int8 v9; // al
  bool v10; // zf

  if ( *(_DWORD *)a1 == *a2 ) /*0x104dc27aa*/
  {
    v2 = a2; /*0x104dc27b0*/
    if ( *(_DWORD *)(a1 + 4) == a2[1] && *(_DWORD *)(a1 + 8) == a2[2] && *(_DWORD *)(a1 + 12) == a2[3] ) /*0x104dc27d6*/
    {
      v4 = 4; /*0x104dc27dc*/
      while ( (unsigned __int8)RBX::operator==(a1: a1 + v4 * 4, a2: &v2[v4]) != 0 ) /*0x104dc27f1*/
      {
        v4 += 8; /*0x104dc27f3*/
        if ( v4 == 52 ) /*0x104dc27fe*/
        {
          v5 = *(_QWORD *)(a1 + 208); /*0x104dc2800*/
          v6 = *(_QWORD *)(a1 + 216); /*0x104dc2807*/
          v7 = *((_QWORD *)v2 + 26); /*0x104dc2814*/
          if ( v6 - v5 == *((_QWORD *)v2 + 27) - v7 ) /*0x104dc2828*/
          {
            LOBYTE(v2) = 1; /*0x104dc282a*/
            if ( v5 == v6 ) /*0x104dc282f*/
              return (unsigned int)v2; /*0x104dc282f*/
            do /*0x104dc2868*/
            {
              v8 = 0; /*0x104dc2831*/
              do /*0x104dc2853*/
              {
                v9 = RBX::operator==(a1: v5 + v8, a2: v7 + v8); /*0x104dc283c*/
                if ( (v9 & 1) == 0 ) /*0x104dc2843*/
                  break; /*0x104dc2843*/
                v10 = v8 == 160; /*0x104dc2849*/
                v8 += 32; /*0x104dc2850*/
              }
              while ( !v10 ); /*0x104dc2853*/
              v5 += 192; /*0x104dc285a*/
              v7 += 192; /*0x104dc285d*/
            }
            while ( ((v5 != v6) & v9) != 0 ); /*0x104dc2868*/
            if ( (v9 & 1) != 0 ) /*0x104dc286c*/
              return (unsigned int)v2; /*0x104dc286c*/
          }
          break; /*0x104dc286c*/
        }
      }
    }
  }
  LODWORD(v2) = 0; /*0x104dc286e*/
  return (unsigned int)v2; /*0x104dc2876*/
}

// Address: 0x104dc5aa6 | Name: __ZN3RBX35tagAnimationsWithMaxPartTranslationERKNSt3__16vectorINS0_10shared_ptrINS_8InstanceEEENS0_9allocatorIS4_EEEE
__int64 __fastcall RBX::tagAnimationsWithMaxPartTranslation(__int64 **a1)
{
  __int64 *v1; // r13
  __int64 *v2; // rbx
  __int64 v3; // r15
  __int64 v4; // rax
  __int64 v5; // rdi
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // rax
  __int64 v9; // r15
  __int64 v10; // rdi
  __int64 v11; // rsi
  void *v12; // rsi
  int v14; // [rsp+Ch] [rbp-B4h] BYREF
  __int64 v15; // [rsp+10h] [rbp-B0h] BYREF
  __int64 v16; // [rsp+18h] [rbp-A8h] BYREF
  _BYTE v17[64]; // [rsp+20h] [rbp-A0h] BYREF
  void *v18[4]; // [rsp+60h] [rbp-60h] BYREF
  void **v19; // [rsp+80h] [rbp-40h]

  v1 = *a1; /*0x104dc5ac8*/
  v2 = a1[1]; /*0x104dc5acb*/
  if ( *a1 != v2 ) /*0x104dc5ad2*/
  {
    while ( 1 ) /*0x104dc5ae7*/
    {
      v3 = *(_QWORD *)(*v1 + 24); /*0x104dc5ae7*/
      v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::CurveAnimation>(); /*0x104dc5aeb*/
      if ( *(unsigned __int16 *)(v3 + 440) - (unsigned int)*(unsigned __int16 *)(v4 + 440) <= *(unsigned __int16 *)(v4 + 442) ) /*0x104dc5b0a*/
        break; /*0x104dc5b0a*/
LABEL_12:
      v1 += 2; /*0x104dc5bc9*/
      if ( v1 == v2 ) /*0x104dc5bd0*/
        return __stack_chk_guard; /*0x104dc5bd0*/
    }
    v14 = 0; /*0x104dc5b10*/
    v5 = *v1; /*0x104dc5b1a*/
    v18[0] = off_10C9E4098; /*0x104dc5b25*/
    v18[1] = &v14; /*0x104dc5b29*/
    v19 = v18; /*0x104dc5b2d*/
    RBX::Instance::visitDescendantsOfType<RBX::Vector3Curve>(a1: v5, a2: v18); /*0x104dc5b34*/
    if ( v19 == v18 ) /*0x104dc5b40*/
    {
      v8 = 32; /*0x104dc5b4e*/
    }
    else
    {
      v8 = 40; /*0x104dc5b42*/
      if ( v19 == nullptr ) /*0x104dc5b4a*/
        goto LABEL_8; /*0x104dc5b4a*/
    }
    (*(void (**)(void))((char *)*v19 + v8))(); /*0x104dc5b56*/
LABEL_8:
    v9 = *v1; /*0x104dc5b59*/
    std::string::basic_string[abi:ne200100]<0>(a1: v18, a2: "maxPartTranslation", a3: v6, a4: v7); /*0x104dc5b67*/
    v15 = RBX::Reflection::Type::getSingleton<float>(a1: v10, a2: v11); /*0x104dc5b71*/
    v16 = 0; /*0x104dc5b78*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<float>(a1: &v16, a2: &v14); /*0x104dc5b8d*/
    RBX::Instance::setAttribute(a1: v9, a2: v18, a3: &v15); /*0x104dc5b9f*/
    if ( v16 != 0 ) /*0x104dc5bae*/
      (*(void (__fastcall **)(_BYTE *))(v16 + 16))(a1: v17); /*0x104dc5bb7*/
    if ( ((__int64)v18[0] & 1) != 0 ) /*0x104dc5bbe*/
      operator delete(a1: (RBX::Memory *)v18[2], a2: v12); /*0x104dc5bc4*/
    goto LABEL_12; /*0x104dc5bc4*/
  }
  return __stack_chk_guard; /*0x104dc5be6*/
}

// Address: 0x104df10df | Name: __ZN3RBX31throw_runtime_error_safe_formatIJKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x104df10f2*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 13); /*0x104df112a*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x104df1139*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x104df1143*/
  __cxa_throw( /*0x104df1159*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x104e76cef | Name: __ZN3RBXL9TranslateENSt3__110shared_ptrINS_8InstanceEEEPKNS_7Vector3E
void __fastcall RBX::Translate(_QWORD **a1, float *a2)
{
  _QWORD *v2; // rbx
  __int64 v4; // r15
  __int64 v5; // rax
  _BYTE v6[36]; // [rsp+8h] [rbp-48h] BYREF
  unsigned __int64 v7; // [rsp+2Ch] [rbp-24h] BYREF
  float v8; // [rsp+34h] [rbp-1Ch]

  v2 = *a1; /*0x104e76cfc*/
  if ( *a1 != nullptr ) /*0x104e76d02*/
  {
    v4 = v2[3]; /*0x104e76d07*/
    v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::BasePart>(a1, a2); /*0x104e76d0b*/
    if ( *(unsigned __int16 *)(v4 + 440) - (unsigned int)*(unsigned __int16 *)(v5 + 440) <= *(unsigned __int16 *)(v5 + 442) ) /*0x104e76d2a*/
    {
      RBX::BasePartProp::getCoordinateFrame(this: (RBX::BasePartProp *)v6); /*0x104e76d3a*/
      _mm_storel_ps((double *)&v7, _mm_add_ps((__m128)v7, (__m128)*(unsigned __int64 *)a2)); /*0x104e76d4d*/
      v8 = a2[2] + v8; /*0x104e76d5e*/
      (*(void (__fastcall **)(_QWORD *, _BYTE *))(*v2 + 1392LL))(a1: v2, a2: v6); /*0x104e76d6d*/
    }
  }
}

// Address: 0x104ebcd97 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJPKcS2_S2_EEEvS2_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<char const*,char const*,char const*>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[56]; // [rsp+38h] [rbp-38h] BYREF

  v2 = strlen(__s: a1); /*0x104ebcdb2*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 3276); /*0x104ebcdde*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x104ebcded*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x104ebcdf7*/
  __cxa_throw( /*0x104ebce0d*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x104ebd0ec | Name: __ZN3RBXL6typeOfERKNS_10Reflection4TypeE
RBX *__fastcall RBX::typeOf(RBX *this, const RBX::Reflection::Type *a2, __int64 a3, __int64 a4)
{
  __int64 v5; // rax
  const char *v6; // rsi
  char v7; // al

  switch ( *((_DWORD *)a2 + 12) ) /*0x104ebd10d*/
  {
    case 1: /*0x104ebd10d*/
      v6 = "boolean"; /*0x104ebd170*/
      goto LABEL_15; /*0x104ebd177*/
    case 2: /*0x104ebd10d*/
    case 3: /*0x104ebd10d*/
    case 4: /*0x104ebd10d*/
    case 5: /*0x104ebd10d*/
      v6 = "number"; /*0x104ebd13a*/
      goto LABEL_15; /*0x104ebd141*/
    case 6: /*0x104ebd10d*/
    case 7: /*0x104ebd10d*/
    case 0x31: /*0x104ebd10d*/
      v6 = "string"; /*0x104ebd143*/
      goto LABEL_15; /*0x104ebd14a*/
    case 8: /*0x104ebd10d*/
    case 9: /*0x104ebd10d*/
    case 0xA: /*0x104ebd10d*/
    case 0xB: /*0x104ebd10d*/
    case 0xC: /*0x104ebd10d*/
    case 0xD: /*0x104ebd10d*/
    case 0xE: /*0x104ebd10d*/
    case 0x11: /*0x104ebd10d*/
    case 0x13: /*0x104ebd10d*/
    case 0x14: /*0x104ebd10d*/
    case 0x15: /*0x104ebd10d*/
    case 0x16: /*0x104ebd10d*/
    case 0x17: /*0x104ebd10d*/
    case 0x18: /*0x104ebd10d*/
    case 0x19: /*0x104ebd10d*/
    case 0x1B: /*0x104ebd10d*/
    case 0x1C: /*0x104ebd10d*/
    case 0x22: /*0x104ebd10d*/
    case 0x26: /*0x104ebd10d*/
    case 0x28: /*0x104ebd10d*/
    case 0x29: /*0x104ebd10d*/
    case 0x2A: /*0x104ebd10d*/
    case 0x2B: /*0x104ebd10d*/
    case 0x2C: /*0x104ebd10d*/
    case 0x2D: /*0x104ebd10d*/
    case 0x2E: /*0x104ebd10d*/
    case 0x30: /*0x104ebd10d*/
    case 0x36: /*0x104ebd10d*/
    case 0x37: /*0x104ebd10d*/
    case 0x38: /*0x104ebd10d*/
    case 0x39: /*0x104ebd10d*/
    case 0x3A: /*0x104ebd10d*/
    case 0x3B: /*0x104ebd10d*/
    case 0x3C: /*0x104ebd10d*/
    case 0x3D: /*0x104ebd10d*/
    case 0x40: /*0x104ebd10d*/
    case 0x41: /*0x104ebd10d*/
    case 0x42: /*0x104ebd10d*/
    case 0x43: /*0x104ebd10d*/
    case 0x46: /*0x104ebd10d*/
    case 0x4A: /*0x104ebd10d*/
    case 0x4B: /*0x104ebd10d*/
    case 0x4C: /*0x104ebd10d*/
    case 0x4D: /*0x104ebd10d*/
    case 0x4E: /*0x104ebd10d*/
    case 0x4F: /*0x104ebd10d*/
    case 0x50: /*0x104ebd10d*/
    case 0x51: /*0x104ebd10d*/
    case 0x52: /*0x104ebd10d*/
    case 0x54: /*0x104ebd10d*/
    case 0x55: /*0x104ebd10d*/
    case 0x56: /*0x104ebd10d*/
    case 0x58: /*0x104ebd10d*/
    case 0x5B: /*0x104ebd10d*/
    case 0x5C: /*0x104ebd10d*/
    case 0x5F: /*0x104ebd10d*/
      v5 = *((_QWORD *)a2 + 1); /*0x104ebd10f*/
      if ( (*(_BYTE *)v5 & 1) != 0 ) /*0x104ebd116*/
      {
        std::string::__init_copy_ctor_external(a1: this, a2: *(_QWORD *)(v5 + 16), a3: *(_QWORD *)(v5 + 8)); /*0x104ebd133*/
      }
      else
      {
        *((_QWORD *)this + 2) = *(_QWORD *)(v5 + 16); /*0x104ebd11c*/
        *(_OWORD *)this = *(_OWORD *)v5; /*0x104ebd123*/
      }
      goto LABEL_16; /*0x104ebd126*/
    case 0xF: /*0x104ebd10d*/
      v6 = "Rect"; /*0x104ebd15e*/
      goto LABEL_15; /*0x104ebd165*/
    case 0x10: /*0x104ebd10d*/
    case 0x47: /*0x104ebd10d*/
      v6 = "CFrame"; /*0x104ebd14c*/
      goto LABEL_15; /*0x104ebd153*/
    case 0x21: /*0x104ebd10d*/
      v6 = "EnumItem"; /*0x104ebd180*/
      goto LABEL_15; /*0x104ebd187*/
    case 0x23: /*0x104ebd10d*/
      v6 = "..."; /*0x104ebd189*/
      goto LABEL_15; /*0x104ebd189*/
    case 0x24: /*0x104ebd10d*/
    case 0x25: /*0x104ebd10d*/
      v6 = "table"; /*0x104ebd155*/
      goto LABEL_15; /*0x104ebd15c*/
    case 0x33: /*0x104ebd10d*/
      v6 = "Instance"; /*0x104ebd167*/
LABEL_15:
      std::string::basic_string[abi:ne200100]<0>(a1: this, a2: v6, a3, a4); /*0x104ebd190*/
LABEL_16:
      v7 = 1; /*0x104ebd198*/
      break; /*0x104ebd198*/
    default:
      *(_BYTE *)this = 0; /*0x104ebd179*/
      v7 = 0; /*0x104ebd17c*/
      break; /*0x104ebd17e*/
  }
  *((_BYTE *)this + 24) = v7; /*0x104ebd19a*/
  return this; /*0x104ebd1a4*/
}

// Address: 0x104ed7d2a | Name: __ZN3RBX8toStringENS_23RuntimeContentErrorCodeE
const char *__fastcall RBX::toString(int a1)
{
  unsigned int v1; // edi

  v1 = a1 + 9; /*0x104ed7d2e*/
  if ( v1 > 9 ) /*0x104ed7d34*/
    return "Unknown_Error_Code"; /*0x104ed7d53*/
  else
    return (char *)dword_109755B80 + dword_109755B80[v1]; /*0x104ed7d4e*/
}

// Address: 0x104f3a388 | Name: __ZN3RBX22TeleportTransitionDataaSEOS0_
__int64 __fastcall RBX::TeleportTransitionData::operator=(__int64 a1, _OWORD *a2)
{
  __int128 v4; // xmm0
  __int128 v5; // xmm1
  __int128 v6; // xmm2
  __int64 v7; // rdi
  __int64 v8; // rsi
  __int64 v9; // rax
  __int64 v10; // rdi
  __int64 v11; // rsi
  __int64 v12; // rax
  __int64 v13; // rdi
  __int64 v14; // rsi
  __int64 v15; // rax
  __int64 v16; // rdi
  __int64 v17; // rsi
  void *v18; // rsi
  __int64 v19; // rax

  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x104f3a39c*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x104f3a3a2*/
  *(_QWORD *)(a1 + 16) = *((_QWORD *)a2 + 2); /*0x104f3a3ab*/
  *(_OWORD *)a1 = *a2; /*0x104f3a3b3*/
  *(_WORD *)a2 = 0; /*0x104f3a3b6*/
  v4 = *(_OWORD *)((char *)a2 + 24); /*0x104f3a3bc*/
  v5 = *(_OWORD *)((char *)a2 + 40); /*0x104f3a3c1*/
  v6 = *(_OWORD *)((char *)a2 + 56); /*0x104f3a3c6*/
  *(_OWORD *)(a1 + 65) = *(_OWORD *)((char *)a2 + 65); /*0x104f3a3d0*/
  *(_OWORD *)(a1 + 56) = v6; /*0x104f3a3d4*/
  *(_OWORD *)(a1 + 40) = v5; /*0x104f3a3d8*/
  *(_OWORD *)(a1 + 24) = v4; /*0x104f3a3dc*/
  std::shared_ptr<RBX::Instance>::operator=[abi:ne200100](a1: a1 + 88, a2: (_OWORD *)((char *)a2 + 88)); /*0x104f3a3e8*/
  std::shared_ptr<RBX::Instance>::operator=[abi:ne200100](a1: a1 + 104, a2: (_OWORD *)((char *)a2 + 104)); /*0x104f3a3f5*/
  *(_QWORD *)(a1 + 120) = *((_QWORD *)a2 + 15); /*0x104f3a3fe*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: a1 + 128, a2: a2 + 8); /*0x104f3a40e*/
  *((_QWORD *)a2 + 15) = RBX::Reflection::Type::getSingleton<void>(a1: v7, a2: v8); /*0x104f3a418*/
  v9 = *((_QWORD *)a2 + 16); /*0x104f3a41c*/
  if ( v9 != 0 ) /*0x104f3a426*/
  {
    (*(void (__fastcall **)(__int64))(v9 + 16))(a1: (__int64)a2 + 136); /*0x104f3a42f*/
    *((_QWORD *)a2 + 16) = 0; /*0x104f3a432*/
  }
  *(_QWORD *)(a1 + 200) = *((_QWORD *)a2 + 25); /*0x104f3a444*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: a1 + 208, a2: a2 + 13); /*0x104f3a457*/
  *((_QWORD *)a2 + 25) = RBX::Reflection::Type::getSingleton<void>(a1: v10, a2: v11); /*0x104f3a461*/
  v12 = *((_QWORD *)a2 + 26); /*0x104f3a468*/
  if ( v12 != 0 ) /*0x104f3a472*/
  {
    (*(void (__fastcall **)(__int64))(v12 + 16))(a1: (__int64)a2 + 216); /*0x104f3a47b*/
    *((_QWORD *)a2 + 26) = 0; /*0x104f3a47e*/
  }
  *(_QWORD *)(a1 + 280) = *((_QWORD *)a2 + 35); /*0x104f3a492*/
  *(_QWORD *)(a1 + 288) = *((_QWORD *)a2 + 36); /*0x104f3a4a1*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: a1 + 296, a2: (char *)a2 + 296); /*0x104f3a4b4*/
  *((_QWORD *)a2 + 36) = RBX::Reflection::Type::getSingleton<void>(a1: v13, a2: v14); /*0x104f3a4be*/
  v15 = *((_QWORD *)a2 + 37); /*0x104f3a4c5*/
  if ( v15 != 0 ) /*0x104f3a4cf*/
  {
    (*(void (__fastcall **)(_OWORD *))(v15 + 16))(a1: a2 + 19); /*0x104f3a4d8*/
    *((_QWORD *)a2 + 37) = 0; /*0x104f3a4db*/
  }
  *(_QWORD *)(a1 + 368) = *((_QWORD *)a2 + 46); /*0x104f3a4ed*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: a1 + 376, a2: (char *)a2 + 376); /*0x104f3a500*/
  *((_QWORD *)a2 + 46) = RBX::Reflection::Type::getSingleton<void>(a1: v16, a2: v17); /*0x104f3a50a*/
  v19 = *((_QWORD *)a2 + 47); /*0x104f3a511*/
  if ( v19 != 0 ) /*0x104f3a51b*/
  {
    (*(void (__fastcall **)(_OWORD *))(v19 + 16))(a1: a2 + 24); /*0x104f3a524*/
    *((_QWORD *)a2 + 47) = 0; /*0x104f3a527*/
  }
  if ( (*(_BYTE *)(a1 + 448) & 1) != 0 ) /*0x104f3a546*/
    operator delete(a1: *(RBX::Memory **)(a1 + 464), a2: v18); /*0x104f3a54f*/
  *(_QWORD *)(a1 + 464) = *((_QWORD *)a2 + 58); /*0x104f3a559*/
  *(_OWORD *)(a1 + 448) = a2[28]; /*0x104f3a562*/
  *((_WORD *)a2 + 224) = 0; /*0x104f3a566*/
  if ( (*(_BYTE *)(a1 + 472) & 1) != 0 ) /*0x104f3a584*/
    operator delete(a1: *(RBX::Memory **)(a1 + 488), a2: v18); /*0x104f3a58d*/
  *(_QWORD *)(a1 + 488) = *((_QWORD *)a2 + 61); /*0x104f3a597*/
  *(_OWORD *)(a1 + 472) = *(_OWORD *)((char *)a2 + 472); /*0x104f3a5a0*/
  *((_WORD *)a2 + 236) = 0; /*0x104f3a5a4*/
  if ( (*(_BYTE *)(a1 + 496) & 1) != 0 ) /*0x104f3a5bc*/
    operator delete(a1: *(RBX::Memory **)(a1 + 512), a2: v18); /*0x104f3a5c5*/
  *(_QWORD *)(a1 + 512) = *((_QWORD *)a2 + 64); /*0x104f3a5d1*/
  *(_OWORD *)(a1 + 496) = a2[31]; /*0x104f3a5dd*/
  *((_WORD *)a2 + 248) = 0; /*0x104f3a5e1*/
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__move_assign( /*0x104f3a5f7*/
    a1: a1 + 520,
    a2: (char *)a2 + 520);
  std::deque<std::pair<long long,long long>>::__move_assign(a1: a1 + 560, a2: a2 + 35); /*0x104f3a608*/
  std::deque<std::pair<long long,long long>>::__move_assign(a1: a1 + 608, a2: a2 + 38); /*0x104f3a61c*/
  return a1; /*0x104f3a624*/
}

// Address: 0x1050f593e | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRN8PBRSynth8VkFormatEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<PBRSynth::VkFormat &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1050f5951*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 2); /*0x1050f596e*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1050f597d*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1050f5987*/
  __cxa_throw( /*0x1050f599d*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1050f6079 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKjEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<unsigned int const&>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1050f608c*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 2); /*0x1050f60a9*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1050f60b8*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1050f60c2*/
  __cxa_throw( /*0x1050f60d8*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1051a0114 | Name: __ZNK3RBX13TmpVertexHashclERKNS_9TmpVertexE
__int64 __fastcall RBX::TmpVertexHash::operator()(__int64 a1, __int64 a2)
{
  __m128i v2; // xmm1
  __int64 v3; // rax
  unsigned __int64 v4; // rdx
  __m128i v5; // xmm1
  __int64 v6; // rax
  __int64 v7; // rdi
  unsigned __int64 v8; // r8
  __m128i v9; // xmm1
  __int64 v10; // rax
  __int64 v11; // rdx
  unsigned __int64 v12; // rdx
  __m128i v13; // xmm1
  __int64 v14; // rax
  __int64 v15; // rdi
  unsigned __int64 v16; // rdi
  __m128i v17; // xmm1
  __int64 v18; // rax
  __int64 v19; // rdx
  unsigned __int64 v20; // rdx
  __m128i v21; // xmm1
  __int64 v22; // rax
  __int64 v23; // rdi
  unsigned __int64 v24; // rdi
  unsigned __int64 v25; // rax
  unsigned __int64 v26; // rdx
  unsigned __int64 v27; // r8

  v2 = _mm_cvtsi32_si128(*(_DWORD *)a2); /*0x1051a0118*/
  v3 = (unsigned int)_mm_cvtsi128_si32(v2) + 2654435769LL; /*0x1051a0125*/
  v4 = 2654435769LL; /*0x1051a012e*/
  if ( *(float *)v2.i32 != 0.0 ) /*0x1051a0133*/
    v4 = v3; /*0x1051a0133*/
  v5 = _mm_cvtsi32_si128(*(_DWORD *)(a2 + 4)); /*0x1051a0137*/
  v6 = (unsigned int)_mm_cvtsi128_si32(v5) + 2654435769LL; /*0x1051a0144*/
  v7 = 2654435769LL; /*0x1051a014a*/
  if ( *(float *)v5.i32 != 0.0 ) /*0x1051a014f*/
    v7 = v6; /*0x1051a014f*/
  v8 = v4 ^ (v7 + (v4 << 6) + (v4 >> 2)); /*0x1051a016b*/
  v9 = _mm_cvtsi32_si128(*(_DWORD *)(a2 + 8)); /*0x1051a016e*/
  v10 = (unsigned int)_mm_cvtsi128_si32(v9) + 2654435769LL; /*0x1051a0177*/
  v11 = 2654435769LL; /*0x1051a017d*/
  if ( *(float *)v9.i32 != 0.0 ) /*0x1051a0182*/
    v11 = v10; /*0x1051a0182*/
  v12 = v8 ^ (v11 + (v8 << 6) + (v8 >> 2)); /*0x1051a019e*/
  v13 = _mm_cvtsi32_si128(*(_DWORD *)(a2 + 12)); /*0x1051a01a1*/
  v14 = (unsigned int)_mm_cvtsi128_si32(v13) + 2654435769LL; /*0x1051a01aa*/
  v15 = 2654435769LL; /*0x1051a01b0*/
  if ( *(float *)v13.i32 != 0.0 ) /*0x1051a01b5*/
    v15 = v14; /*0x1051a01b5*/
  v16 = v12 ^ (v15 + (v12 << 6) + (v12 >> 2)); /*0x1051a01d1*/
  v17 = _mm_cvtsi32_si128(*(_DWORD *)(a2 + 16)); /*0x1051a01d4*/
  v18 = (unsigned int)_mm_cvtsi128_si32(v17) + 2654435769LL; /*0x1051a01dd*/
  v19 = 2654435769LL; /*0x1051a01e3*/
  if ( *(float *)v17.i32 != 0.0 ) /*0x1051a01e8*/
    v19 = v18; /*0x1051a01e8*/
  v20 = v16 ^ (v19 + (v16 << 6) + (v16 >> 2)); /*0x1051a0204*/
  v21 = _mm_cvtsi32_si128(*(_DWORD *)(a2 + 20)); /*0x1051a0207*/
  v22 = (unsigned int)_mm_cvtsi128_si32(v21) + 2654435769LL; /*0x1051a0210*/
  v23 = 2654435769LL; /*0x1051a0216*/
  if ( *(float *)v21.i32 != 0.0 ) /*0x1051a021b*/
    v23 = v22; /*0x1051a021b*/
  v24 = v20 ^ (v23 + (v20 << 6) + (v20 >> 2)); /*0x1051a0237*/
  v25 = v24 ^ (*(unsigned __int8 *)(a2 + 24) + (v24 << 6) + (v24 >> 2) + 2654435769u); /*0x1051a0255*/
  v26 = v25 ^ (*(unsigned __int8 *)(a2 + 25) + (v25 << 6) + (v25 >> 2) + 2654435769u); /*0x1051a0273*/
  v27 = v26 ^ (*(unsigned __int8 *)(a2 + 26) + (v26 << 6) + (v26 >> 2) + 2654435769u); /*0x1051a0291*/
  return v27 ^ (*(unsigned __int8 *)(a2 + 27) + (v27 << 6) + (v27 >> 2) + 2654435769u); /*0x1051a02b2*/
}

// Address: 0x10542c949 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJytEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<unsigned long long,unsigned short>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x10542c95f*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 36); /*0x10542c984*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10542c993*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x10542c99d*/
  __cxa_throw( /*0x10542c9b3*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x105451006 | Name: __ZN3RBX9tempSetV4ERKNS_7Vector3EfRNS_7Vector4E
void __fastcall RBX::tempSetV4(RBX *this, const RBX::Vector3 *a2, float a3, RBX::Vector4 *a4)
{
  *(_QWORD *)a2 = *(_QWORD *)this; /*0x10545100e*/
  *((_DWORD *)a2 + 2) = *((_DWORD *)this + 2); /*0x105451017*/
  *((float *)a2 + 3) = a3; /*0x10545101c*/
}

// Address: 0x10556ff9d | Name: __ZN3RBXL28throwIfEditableMeshDataErrorENS_4Mesh25EditableMeshDataErrorCodeE
void __fastcall RBX::throwIfEditableMeshDataError(int a1, __int64 a2, __int64 a3, int *a4)
{
  __int64 v4; // rdx
  __int64 v5; // rcx
  __int64 v6; // r8
  __int64 v7; // r9
  __m128 v8; // xmm0
  __m128 v9; // xmm1
  __m128 v10; // xmm2
  __m128 v11; // xmm3
  __m128 v12; // xmm4
  __m128 v13; // xmm5
  __m128 v14; // xmm6
  __m128 v15; // xmm7
  char *v16; // rsi
  char v17; // [rsp+0h] [rbp-30h]
  char v18; // [rsp+8h] [rbp-28h] BYREF
  char v19[15]; // [rsp+9h] [rbp-27h] BYREF
  char *v20; // [rsp+18h] [rbp-18h]
  _DWORD v21[3]; // [rsp+24h] [rbp-Ch] BYREF

  v21[0] = a1; /*0x10556ffa6*/
  if ( a1 != 0 )
  {
    RBX::Mesh::getErrorString(a1: (__int64)&v18, a2: v21, a3, a4); /*0x10556ffbf*/
    if ( (v18 & 1) != 0 ) /*0x10556ffc7*/
      v16 = v20; /*0x10556ffc9*/
    else
      v16 = v19; /*0x10556ffcf*/
    RBX::throw_runtime_error(
      this: (RBX *)"EditableMesh Error: %s",
      a2: v16,
      a3: v4,
      a4: v5,
      a5: v6,
      a6: v7,
      a7: v8,
      a8: v9,
      a9: v10,
      a10: v11,
      a11: v12,
      a12: v13,
      a13: v14,
      a14: v15,
      a15: v17);
  }
}

// Address: 0x10557b609 | Name: __ZN3RBXL28throwAndLogEditableMeshErrorENS_21EditableMeshErrorCodeEPKNS_12EditableMeshE
void __fastcall __noreturn RBX::throwAndLogEditableMeshError(
        RBX::EditableMeshReporting *a1,
        int a2,
        const RBX::EditableMesh *a3)
{
  char v3; // al
  int v4; // ebx
  const char *ErrorString; // rax
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // r8
  __int64 v9; // r9
  __m128 v10; // xmm0
  __m128 v11; // xmm1
  __m128 v12; // xmm2
  __m128 v13; // xmm3
  __m128 v14; // xmm4
  __m128 v15; // xmm5
  __m128 v16; // xmm6
  __m128 v17; // xmm7
  char v18; // [rsp-8h] [rbp-10h]

  v18 = v3; /*0x10557b60e*/
  v4 = (int)a1; /*0x10557b60f*/
  RBX::EditableMeshReporting::logRuntimeError(this: a1, a2, a3); /*0x10557b611*/
  ErrorString = RBX::getErrorString(a1: v4); /*0x10557b618*/
  RBX::throw_runtime_error( /*0x10557b629*/
    this: (RBX *)"%s",
    a2: ErrorString,
    a3: v6,
    a4: v7,
    a5: v8,
    a6: v9,
    a7: v10,
    a8: v11,
    a9: v12,
    a10: v13,
    a11: v14,
    a12: v15,
    a13: v16,
    a14: v17,
    a15: v18);
}

// Address: 0x1056cc814 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,std::string>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3)
{
  size_t v6; // rax
  unsigned __int8 *v7; // rdx
  __int64 v8; // rsi
  unsigned __int8 *v9; // rdi
  __int64 v10; // r9
  void *exception; // r15
  _QWORD v12[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v13[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x1056cc82a*/
  v7 = a2 + 1; /*0x1056cc833*/
  v8 = *a2 >> 1; /*0x1056cc839*/
  if ( (*a2 & 1) != 0 ) /*0x1056cc83e*/
  {
    v7 = *((unsigned __int8 **)a2 + 2); /*0x1056cc83e*/
    v8 = *((_QWORD *)a2 + 1); /*0x1056cc843*/
  }
  v9 = a3 + 1; /*0x1056cc84c*/
  v10 = *a3 >> 1; /*0x1056cc853*/
  if ( (*a3 & 1) != 0 ) /*0x1056cc859*/
  {
    v9 = *((unsigned __int8 **)a3 + 2); /*0x1056cc859*/
    v10 = *((_QWORD *)a3 + 1); /*0x1056cc85e*/
  }
  v12[0] = v7; /*0x1056cc867*/
  v12[1] = v8; /*0x1056cc86a*/
  v12[2] = v9; /*0x1056cc86e*/
  v12[3] = v10; /*0x1056cc872*/
  fmt::v8::vformat(a1: v13, a2: a1, v6, 221, v12, v10); /*0x1056cc885*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1056cc894*/
  std::runtime_error::runtime_error(a1: exception, a2: v13); /*0x1056cc89e*/
  __cxa_throw( /*0x1056cc8b4*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x105730234 | Name: __ZN3RBXL19trackAvatarAssetIdsERKNSt3__110shared_ptrINS_6PlayerEEENS1_IKNS_10Reflection10ValueTableEEEbb
__int64 __fastcall RBX::trackAvatarAssetIds(__int64 *a1, __int64 a2, char a3, char a4)
{
  __int64 v4; // rax
  volatile signed __int64 *v5; // rbx
  __int64 v6; // rax
  __int16 v8; // [rsp+8h] [rbp-68h]
  __int64 (__fastcall **v9)(); // [rsp+20h] [rbp-50h] BYREF
  __int16 v10; // [rsp+28h] [rbp-48h]
  __int64 v11; // [rsp+30h] [rbp-40h]
  volatile signed __int64 *v12; // [rsp+38h] [rbp-38h]
  __int64 (__fastcall ***v13)(); // [rsp+40h] [rbp-30h]

  LOBYTE(v8) = a3; /*0x10573024f*/
  HIBYTE(v8) = a4; /*0x105730252*/
  v4 = *a1; /*0x105730255*/
  v5 = (volatile signed __int64 *)a1[1]; /*0x10573025c*/
  if ( v5 != nullptr ) /*0x105730267*/
  {
    _InterlockedIncrement64(v5 + 1); /*0x105730269*/
    v13 = nullptr; /*0x10573026e*/
    v9 = &off_10CA24068; /*0x10573027d*/
    v10 = v8; /*0x105730285*/
    v11 = v4; /*0x105730289*/
    v12 = v5; /*0x10573028d*/
    _InterlockedIncrement64(v5 + 1); /*0x105730291*/
  }
  else
  {
    v13 = nullptr; /*0x105730298*/
    v9 = &off_10CA24068; /*0x1057302a7*/
    v10 = v8; /*0x1057302af*/
    v11 = v4; /*0x1057302b3*/
    v12 = nullptr; /*0x1057302b7*/
  }
  v13 = &v9; /*0x1057302c3*/
  RBX::AvatarFetchParser::parseEachAvatarFetchAsset(a1: a2, a2: &v9); /*0x1057302cd*/
  if ( v13 == &v9 ) /*0x1057302d9*/
  {
    v6 = 4; /*0x1057302e7*/
  }
  else
  {
    v6 = 5; /*0x1057302db*/
    if ( v13 == nullptr ) /*0x1057302e3*/
      goto LABEL_9; /*0x1057302e3*/
  }
  (*v13)[v6](); /*0x1057302ef*/
LABEL_9:
  if ( v5 != nullptr && _InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x105730307*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(a1: v5); /*0x10573030f*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v5); /*0x105730315*/
  }
  return __stack_chk_guard; /*0x10573032a*/
}

// Address: 0x1057773c2 | Name: __ZZN3RBXL37transformBodyColor3sToBodyColorsAsyncENSt3__110shared_ptrINS_9DataModelEEERKNS1_IKNS_10Reflection10ValueTableEEENS0_8functionIFvNS1_IS5_EEEEENSA_IFvNS0_12basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEEEEEEN3$_0D1Ev
signed __int64 __fastcall RBX::transformBodyColor3sToBodyColorsAsync(std::shared_ptr<RBX::DataModel>,std::shared_ptr<RBX::Reflection::ValueTable const> const&,std::function<void ()(std::shared_ptr<RBX::Reflection::ValueTable>)>,std::function<void ()(std::string)>)::$_0::~$_0(
        __int64 a1)
{
  _QWORD *v2; // rax
  _QWORD *v3; // rdi
  __int64 v4; // rax
  _QWORD *v5; // rdi
  __int64 v6; // rax

  v2 = (_QWORD *)(a1 + 64); /*0x1057773cb*/
  v3 = *(_QWORD **)(a1 + 96); /*0x1057773cf*/
  if ( v3 == v2 ) /*0x1057773d6*/
  {
    v4 = 32; /*0x1057773e4*/
    goto LABEL_5; /*0x1057773e4*/
  }
  v4 = 40; /*0x1057773d8*/
  if ( v3 != nullptr ) /*0x1057773e0*/
LABEL_5:
    (*(void (__fastcall **)(_QWORD *))(*v3 + v4))(a1: v3); /*0x1057773e9*/
  v5 = *(_QWORD **)(a1 + 48); /*0x1057773ef*/
  if ( v5 == (_QWORD *)(a1 + 16) ) /*0x1057773fa*/
  {
    v6 = 32; /*0x105777408*/
  }
  else
  {
    v6 = 40; /*0x1057773fc*/
    if ( v5 == nullptr ) /*0x105777404*/
      return std::shared_ptr<RBX::Reflection::ValueTable const>::~shared_ptr[abi:ne200100](a1); /*0x105777404*/
  }
  (*(void (__fastcall **)(_QWORD *))(*v5 + v6))(a1: v5); /*0x105777410*/
  return std::shared_ptr<RBX::Reflection::ValueTable const>::~shared_ptr[abi:ne200100](a1); /*0x10577741a*/
}

// Address: 0x1058228e4 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRiPKcS1_EEEvS3_DpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<int &,char const*,int &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[56]; // [rsp+38h] [rbp-38h] BYREF

  v2 = strlen(__s: a1); /*0x1058228ff*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 449); /*0x10582292a*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x105822939*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x105822943*/
  __cxa_throw( /*0x105822959*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x105912a74 | Name: __ZN3RBX8toStringENS_5Enums4TypeE
RBX::Reflection::EnumDescriptor *__fastcall RBX::toString(RBX::Reflection::EnumDescriptor *this)
{
  int v2; // eax

  v2 = RBX::Reflection::EnumDesc<RBX::Enums::Type>::singleton(); /*0x105912a80*/
  RBX::Reflection::EnumDescriptor::_convertToString(this, a2: v2); /*0x105912a8d*/
  return this; /*0x105912a95*/
}

// Address: 0x10591cffb | Name: __ZN3RBX13typeAwareLerpENS_5Enums4TypeERKNS_15CoordinateFrameES4_f
RBX::CoordinateFrame *__fastcall RBX::typeAwareLerp(
        RBX::CoordinateFrame *this,
        int a2,
        __int128 *a3,
        __int64 a4,
        __m128 a5)
{
  __m128 v8; // xmm4
  float v9; // xmm5_4
  __int128 v10; // xmm1
  __m128 v11; // xmm0
  __m128 v12; // xmm1
  __m128 v13; // xmm0
  __m128 v14; // xmm1
  const RBX::Quaternion *v15; // rdx
  __m128 v16; // xmm0
  __m128 v17; // xmm1
  __m128 v19; // [rsp+0h] [rbp-60h] BYREF
  __m128 v20; // [rsp+10h] [rbp-50h] BYREF
  __m128 v21; // [rsp+20h] [rbp-40h] BYREF
  _QWORD v22[2]; // [rsp+30h] [rbp-30h]

  if ( a2 == 2 ) /*0x10591d016*/
  {
    *(__m128 *)v22 = a5; /*0x10591d08e*/
    RBX::CoordinateFrame::getRotation(this: (RBX::CoordinateFrame *)a3); /*0x10591d092*/
    v20 = _mm_movelh_ps(v11, v12); /*0x10591d09e*/
    RBX::CoordinateFrame::getRotation(this: (RBX::CoordinateFrame *)a4); /*0x10591d0a6*/
    v21 = _mm_movelh_ps(v13, v14); /*0x10591d0b2*/
    RBX::Quaternion::slerp(this: (RBX::Quaternion *)&v20, a2: (const RBX::Quaternion *)&v21, a3: v15, a4: *(float *)v22); /*0x10591d0bc*/
    v19 = _mm_movelh_ps(v16, v17); /*0x10591d0c8*/
    RBX::Matrix3::Matrix3(this, a2: (const RBX::Quaternion *)&v19); /*0x10591d0ce*/
    *((_DWORD *)this + 11) = *((_DWORD *)a3 + 11); /*0x10591d0d7*/
    *(_QWORD *)((char *)this + 36) = *(_QWORD *)((char *)a3 + 36); /*0x10591d0de*/
  }
  else if ( a2 == 1 ) /*0x10591d01b*/
  {
    v8 = _mm_add_ps( /*0x10591d062*/
           _mm_mul_ps(
             _mm_moveldup_ps(a5),
             _mm_sub_ps((__m128)*(unsigned __int64 *)(a4 + 36), (__m128)*(unsigned __int64 *)((char *)a3 + 36))),
           (__m128)*(unsigned __int64 *)((char *)a3 + 36));
    v9 = (float)((float)(*(float *)(a4 + 44) - *((float *)a3 + 11)) * a5.f32[0]) + *((float *)a3 + 11); /*0x10591d065*/
    *((_DWORD *)this + 8) = *((_DWORD *)a3 + 8); /*0x10591d06d*/
    v10 = *a3; /*0x10591d070*/
    *((_OWORD *)this + 1) = a3[1]; /*0x10591d079*/
    *(_OWORD *)this = v10; /*0x10591d07d*/
    _mm_storel_ps((double *)((char *)this + 36), v8); /*0x10591d080*/
    *((float *)this + 11) = v9; /*0x10591d084*/
  }
  else if ( a2 != 0 ) /*0x10591d01f*/
  {
    *(_OWORD *)this = 0x3F800000u; /*0x10591d0ec*/
    *((_OWORD *)this + 1) = 0x3F800000u; /*0x10591d0ef*/
    *((_DWORD *)this + 8) = 1065353216; /*0x10591d0f3*/
    *(_QWORD *)((char *)this + 36) = 0; /*0x10591d0fa*/
    *((_DWORD *)this + 11) = 0; /*0x10591d102*/
  }
  else
  {
    RBX::CoordinateFrame::lerp(this, a2: (const RBX::CoordinateFrame *)a3, a3: a5.f32[0]); /*0x10591d02e*/
  }
  return this; /*0x10591d10c*/
}

// Address: 0x105945422 | Name: __ZN3RBXL28transferKeyframeSequenceDataENSt3__18weak_ptrINS_16KeyframeSequenceEEENS0_10shared_ptrIS2_EENS0_8functionIFvNS4_INS_8InstanceEEEEEENS6_IFvNS0_12basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEEEEE
__int64 __fastcall RBX::transferKeyframeSequenceData(
        RBX::KeyframeSequence **a1,
        RBX::KeyframeSequence **a2,
        __int64 a3,
        __int64 a4)
{
  std::__shared_weak_count *v6; // rdi
  std::__shared_weak_count *v9; // rax
  RBX::KeyframeSequence *v10; // r13
  volatile signed __int64 *v11; // r14
  __int64 v12; // rdi
  std::__shared_weak_count *v13; // rbx
  __int64 v14; // rdx
  __int64 v15; // rcx
  void *v16; // rsi
  __int64 v17; // rax
  std::__shared_weak_count *v18; // rbx
  __int128 v20; // [rsp+8h] [rbp-98h] BYREF
  void *v21; // [rsp+18h] [rbp-88h]
  RBX::KeyframeSequence *v22; // [rsp+20h] [rbp-80h] BYREF
  std::__shared_weak_count *v23; // [rsp+28h] [rbp-78h]
  std::__shared_weak_count *v24[2]; // [rsp+30h] [rbp-70h]
  _BYTE v25[32]; // [rsp+40h] [rbp-60h] BYREF
  _BYTE *v26; // [rsp+60h] [rbp-40h]

  *(_OWORD *)v24 = 0; /*0x10594544a*/
  v6 = a1[1]; /*0x10594544e*/
  if ( v6 != nullptr /*0x10594547a*/
    && (v9 = (std::__shared_weak_count *)std::__shared_weak_count::lock(this: v6), v24[1] = v9, v9 != nullptr)
    && (v10 = *a1, v24[0] = v10, v10 != nullptr) )
  {
    v11 = (volatile signed __int64 *)v9; /*0x10594547c*/
    RBX::KeyframeSequence::transferKeyframeSequence(this: v10, a2: *a2); /*0x105945486*/
    if ( *(_QWORD *)(a3 + 32) != 0 ) /*0x105945490*/
    {
      v22 = v10; /*0x105945496*/
      v23 = (std::__shared_weak_count *)v11; /*0x10594549a*/
      _InterlockedIncrement64(v11 + 1); /*0x10594549e*/
      v12 = *(_QWORD *)(a3 + 32); /*0x1059454a3*/
      if ( v12 == 0 ) /*0x1059454aa*/
        std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x1059455a6*/
      (*(void (__fastcall **)(__int64, RBX::KeyframeSequence **))(*(_QWORD *)v12 + 48LL))(a1: v12, a2: &v22); /*0x1059454b7*/
      v13 = v23; /*0x1059454ba*/
      if ( v23 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v23 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1059454d7*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x1059454df*/
        std::__shared_weak_count::__release_weak(this: v13); /*0x1059454e5*/
      }
    }
  }
  else
  {
    std::__function::__value_func<void ()(std::string)>::__value_func[abi:ne200100](a1: (__int64)v25, a2: a4); /*0x1059454f6*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v20, a2: "Unable to copy KeyframeSequence data.", a3: v14, a4: v15); /*0x105945509*/
    RBX::callErrorFunctionIfNotEmpty(a1: (__int64)v25, a2: &v20); /*0x10594551c*/
    if ( (v20 & 1) != 0 ) /*0x105945528*/
      operator delete(a1: (RBX::Memory *)v21, a2: v16); /*0x105945531*/
    if ( v26 == v25 ) /*0x10594553d*/
    {
      v17 = 32; /*0x10594554b*/
    }
    else
    {
      v17 = 40; /*0x10594553f*/
      if ( v26 == nullptr ) /*0x105945547*/
        goto LABEL_16; /*0x105945547*/
    }
    (*(void (**)(void))(*(_QWORD *)v26 + v17))(); /*0x105945553*/
  }
LABEL_16:
  v18 = v24[1]; /*0x105945556*/
  if ( v24[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v24[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10594556f*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(a1: v18); /*0x105945577*/
    std::__shared_weak_count::__release_weak(this: v18); /*0x10594557d*/
  }
  return __stack_chk_guard; /*0x105945592*/
}

// Address: 0x10597a33c | Name: __ZNK3RBX9TransformcvbEv
bool __fastcall RBX::Transform::operator bool(__int64 a1)
{
  int v1; // eax
  __int64 v3; // rax

  v1 = *(_DWORD *)(a1 + 72); /*0x10597a340*/
  if ( v1 == 0 ) /*0x10597a345*/
    return false; /*0x10597a345*/
  if ( v1 == 6 ) /*0x10597a34a*/
    return RBX::ConstRigHandle::operator bool(a1: a1 + 96); /*0x10597a351*/
  v3 = *(_QWORD *)(a1 + 64); /*0x10597a356*/
  return v3 != 0 && *(_QWORD *)(v3 + 8) != -1; /*0x10597a367*/
}

// Address: 0x10597c5f8 | Name: __ZNK3RBX9TransformeqERKS0_
bool __fastcall RBX::Transform::operator==(__int64 a1, __int64 a2)
{
  int v2; // eax
  bool v6; // r14
  std::__shared_weak_count *v7; // rdi
  volatile signed __int64 *v8; // rax
  volatile signed __int64 *v9; // rbx
  __int64 v10; // r12
  std::__shared_weak_count *v11; // rdi
  volatile signed __int64 *v12; // rax
  std::__shared_weak_count *v13; // r15

  v2 = *(_DWORD *)(a1 + 72); /*0x10597c603*/
  if ( v2 != *(_DWORD *)(a2 + 72) ) /*0x10597c609*/
    return false; /*0x10597c635*/
  if ( v2 == 0 ) /*0x10597c60d*/
    return true; /*0x10597c63d*/
  if ( v2 == 6 ) /*0x10597c618*/
    return RBX::ConstRigHandle::operator==(a1: a1 + 96, a2: a2 + 96); /*0x10597c630*/
  v7 = *(std::__shared_weak_count **)(a1 + 64); /*0x10597c645*/
  if ( v7 != nullptr && (v8 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v7)) != nullptr ) /*0x10597c656*/
  {
    v9 = v8; /*0x10597c658*/
    v10 = *(_QWORD *)(a1 + 56); /*0x10597c65b*/
  }
  else
  {
    v10 = 0; /*0x10597c661*/
    v9 = nullptr; /*0x10597c664*/
  }
  v11 = *(std::__shared_weak_count **)(a2 + 64); /*0x10597c666*/
  if ( v11 != nullptr && (v12 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v11)) != nullptr ) /*0x10597c677*/
  {
    v13 = (std::__shared_weak_count *)v12; /*0x10597c679*/
    v6 = v10 == *(_QWORD *)(a2 + 56); /*0x10597c680*/
    if ( _InterlockedExchangeAdd64(v12 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10597c694*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v12 + 16))(a1: v12); /*0x10597c69c*/
      std::__shared_weak_count::__release_weak(this: v13); /*0x10597c6a2*/
    }
  }
  else
  {
    v6 = v10 == 0; /*0x10597c6ac*/
  }
  if ( v9 != nullptr && _InterlockedExchangeAdd64(v9 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10597c6c5*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v9 + 16))(a1: v9); /*0x10597c6cd*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v9); /*0x10597c6d3*/
  }
  return v6; /*0x10597c628*/
}

// Address: 0x10597c6e4 | Name: __ZNK3RBX9TransformneERKS0_
bool __fastcall RBX::Transform::operator!=(__int64 a1, __int64 a2)
{
  return !RBX::Transform::operator==(a1, a2); /*0x10597c6ef*/
}

// Address: 0x105988f67 | Name: __ZN3RBX8toStringERKNSt3__118unordered_multisetINS0_4pairINS0_12basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEES8_EENS0_4hashIS9_EENS0_8equal_toIS9_EENS6_IS9_EEEE
__int64 __fastcall RBX::toString(__int64 a1, __int64 a2)
{
  __int64 **v3; // r14
  __int64 v4; // rax
  unsigned int v5; // edx
  __int64 *v6; // rsi
  __int64 *v7; // rdx
  __int64 v8; // rax
  __int64 v9; // rax
  unsigned int v10; // edx
  __int64 *v11; // rsi
  __int64 *v12; // rdx
  __int64 v13; // rax
  void *v14; // rsi
  _QWORD v16[2]; // [rsp+8h] [rbp-148h] BYREF
  __int64 (__fastcall **v17)(); // [rsp+18h] [rbp-138h] BYREF
  __int64 (__fastcall **v18)(); // [rsp+20h] [rbp-130h] BYREF
  _BYTE v19[72]; // [rsp+28h] [rbp-128h] BYREF
  void *v20; // [rsp+70h] [rbp-E0h]
  __int64 (__fastcall **v21)(); // [rsp+88h] [rbp-C8h] BYREF
  __int64 v22; // [rsp+120h] [rbp-30h]

  v22 = a1; /*0x105988f7e*/
  std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::basic_stringstream[abi:ne200100](a1: v16); /*0x105988f89*/
  v3 = (__int64 **)(a2 + 16); /*0x105988f8e*/
  while ( 1 ) /*0x105988fae*/
  {
    v3 = (__int64 **)*v3; /*0x105988fae*/
    if ( v3 == nullptr ) /*0x105988fb4*/
      break; /*0x105988fb4*/
    v4 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &v17, a2: "(", a3: 1); /*0x105988fc1*/
    v5 = *((unsigned __int8 *)v3 + 16); /*0x105988fc6*/
    if ( (v5 & 1) != 0 ) /*0x105988fce*/
    {
      v6 = v3[4]; /*0x105988fd0*/
      v7 = v3[3]; /*0x105988fd4*/
    }
    else
    {
      v6 = (__int64 *)((char *)v3 + 17); /*0x105988fda*/
      v7 = (__int64 *)(v5 >> 1); /*0x105988fde*/
    }
    v8 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v4, a2: v6, a3: v7); /*0x105988fe3*/
    v9 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v8, a2: ", ", a3: 2); /*0x105988ff3*/
    v10 = *((unsigned __int8 *)v3 + 40); /*0x105988ff8*/
    if ( (v10 & 1) != 0 ) /*0x105989000*/
    {
      v11 = v3[7]; /*0x105989002*/
      v12 = v3[6]; /*0x105989006*/
    }
    else
    {
      v11 = (__int64 *)((char *)v3 + 41); /*0x10598900c*/
      v12 = (__int64 *)(v10 >> 1); /*0x105989010*/
    }
    v13 = std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v9, a2: v11, a3: v12); /*0x105989015*/
    std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: v13, a2: ") ", a3: 2); /*0x105989025*/
  }
  std::stringbuf::str(a1: v22, a2: &v18); /*0x105989037*/
  v16[0] = &off_10C798D68; /*0x10598904e*/
  v21 = off_10C798DB8; /*0x105989056*/
  v17 = off_10C798D90; /*0x10598905d*/
  v18 = &off_10C799250; /*0x10598906c*/
  if ( (v19[56] & 1) != 0 ) /*0x105989074*/
    operator delete(a1: (RBX::Memory *)v20, a2: v14); /*0x10598907d*/
  v18 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x105989094*/
  std::locale::~locale(this: (std::locale *)v19); /*0x105989098*/
  std::iostream::~iostream(a1: v16, a2: off_10C799178); /*0x1059890af*/
  std::ios::~ios(a1: &v21); /*0x1059890b7*/
  return v22; /*0x1059890c0*/
}

// Address: 0x105ae6060 | Name: __ZN3RBXL19tryFindFaceControlsERKNSt3__110shared_ptrINS_13ModelInstanceEEE
__int64 __fastcall RBX::tryFindFaceControls(__int64 *a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v4; // rbx
  __int64 FirstChildByName; // rbx
  void *v6; // rsi
  _BYTE v8[16]; // [rsp+8h] [rbp-28h] BYREF
  void *v9; // [rsp+18h] [rbp-18h]

  v4 = *a1; /*0x105ae606b*/
  if ( *a1 == 0 ) /*0x105ae6071*/
    return 0; /*0x105ae6071*/
  std::string::basic_string[abi:ne200100]<0>(a1: v8, a2: "Head", a3, a4); /*0x105ae6081*/
  FirstChildByName = RBX::Instance::findFirstChildByName(a1: v4, a2: v8, a3: 0); /*0x105ae6093*/
  if ( (v8[0] & 1) != 0 ) /*0x105ae609a*/
    operator delete(a1: (RBX::Memory *)v9, a2: v6); /*0x105ae60a0*/
  if ( FirstChildByName != 0 ) /*0x105ae60a8*/
    return RBX::Instance::findConstFirstChildOfType<RBX::FaceControls>(a1: FirstChildByName); /*0x105ae60ad*/
  else
    return 0; /*0x105ae60b4*/
}

// Address: 0x105af66b9 | Name: __ZN3RBX22toCommaSeparatedAssetsERKNSt3__113unordered_setIxNS0_4hashIxEENS0_8equal_toIxEENS0_9allocatorIxEEEE
unsigned __int8 *__fastcall RBX::toCommaSeparatedAssets(unsigned __int8 *a1, __int64 a2)
{
  _QWORD *i; // r12
  unsigned int v4; // eax
  __int64 v5; // rax
  char *v6; // rsi
  __int64 v7; // rdx
  void *v8; // rsi
  unsigned __int8 v10; // [rsp+0h] [rbp-40h] BYREF
  char v11; // [rsp+1h] [rbp-3Fh] BYREF
  __int64 v12; // [rsp+8h] [rbp-38h]
  void *v13; // [rsp+10h] [rbp-30h]

  *(_OWORD *)a1 = 0; /*0x105af66d0*/
  *((_QWORD *)a1 + 2) = 0; /*0x105af66d3*/
  for ( i = *(_QWORD **)(a2 + 16); i != nullptr; i = (_QWORD *)*i ) /*0x105af66e2*/
  {
    v4 = *a1; /*0x105af66f3*/
    if ( (v4 & 1) != 0 ) /*0x105af66f8*/
      v5 = *((_QWORD *)a1 + 1); /*0x105af66fa*/
    else
      v5 = v4 >> 1; /*0x105af6700*/
    if ( v5 != 0 ) /*0x105af6705*/
      std::string::append(a1, a2: ","); /*0x105af670d*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: &v10, a2: i[2]); /*0x105af671a*/
    if ( (v10 & 1) != 0 ) /*0x105af6726*/
    {
      v6 = (char *)v13; /*0x105af6728*/
      v7 = v12; /*0x105af672c*/
    }
    else
    {
      v7 = v10 >> 1; /*0x105af6732*/
      v6 = &v11; /*0x105af6734*/
    }
    std::string::append(a1, a2: v6, a3: v7); /*0x105af673a*/
    if ( (v10 & 1) != 0 ) /*0x105af6743*/
      operator delete(a1: (RBX::Memory *)v13, a2: v8); /*0x105af6749*/
  }
  return a1; /*0x105af675a*/
}

// Address: 0x105af6b8b | Name: __ZN3RBXL20toUnorderedSetAssetsERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
__int64 __fastcall RBX::toUnorderedSetAssets(__int64 a1, __int64 a2)
{
  _QWORD *v2; // rax
  void *v3; // rsi
  char *v4; // rdi
  __int64 v5; // rax
  char *v6; // rdi
  __int64 v7; // rcx
  void *v8; // rsi
  __int64 v9; // r8
  __int64 v10; // r9
  std::__shared_weak_count *v11; // rbx
  void *v12; // rsi
  _QWORD v14[2]; // [rsp+0h] [rbp-190h] BYREF
  __int64 (__fastcall **v15)(); // [rsp+10h] [rbp-180h]
  void *v16[12]; // [rsp+18h] [rbp-178h] BYREF
  __int64 (__fastcall **v17)(); // [rsp+78h] [rbp-118h] BYREF
  _QWORD v18[2]; // [rsp+110h] [rbp-80h] BYREF
  std::__shared_weak_count *v19; // [rsp+120h] [rbp-70h]
  char v20; // [rsp+128h] [rbp-68h]
  void *v21; // [rsp+138h] [rbp-58h]
  __int64 v22; // [rsp+140h] [rbp-50h] BYREF
  __int64 v23; // [rsp+148h] [rbp-48h]
  __int128 v24; // [rsp+150h] [rbp-40h] BYREF
  char *v25; // [rsp+160h] [rbp-30h]

  *(_OWORD *)(a1 + 16) = 0; /*0x105af6ba2*/
  *(_OWORD *)a1 = 0; /*0x105af6ba6*/
  v23 = a1; /*0x105af6ba9*/
  *(_DWORD *)(a1 + 32) = 1065353216; /*0x105af6bad*/
  v24 = 0; /*0x105af6bb4*/
  v25 = nullptr; /*0x105af6bb8*/
  std::istringstream::basic_istringstream[abi:ne200100](a1: v14, a2, a3: 8); /*0x105af6bcc*/
  while ( 1 ) /*0x105af6bef*/
  {
    v2 = (_QWORD *)std::getline[abi:ne200100]<char,std::char_traits<char>,std::allocator<char>>( /*0x105af6bef*/
                     a1: v14,
                     a2: &v24,
                     a3: 44);
    if ( (*((_BYTE *)v2 + *(_QWORD *)(*v2 - 24LL) + 32) & 5) != 0 ) /*0x105af6c00*/
      break; /*0x105af6c00*/
    v4 = (char *)&v24 + 1; /*0x105af6c0a*/
    if ( (v24 & 1) != 0 ) /*0x105af6c0d*/
      v4 = v25; /*0x105af6c0f*/
    v5 = atoll(a1: v4); /*0x105af6c13*/
    RBX::HumanoidDescriptionAsset::HumanoidDescriptionAsset(this: (RBX::HumanoidDescriptionAsset *)v18, a2: v5); /*0x105af6c1f*/
    v6 = (char *)&v24 + 1; /*0x105af6c28*/
    if ( (v24 & 1) != 0 ) /*0x105af6c2b*/
      v6 = v25; /*0x105af6c2d*/
    v22 = atoll(a1: v6); /*0x105af6c36*/
    if ( v18[1] != 0 || v18[0] > 0LL ) /*0x105af6c46*/
      std::__hash_table<long long,std::hash<long long>,std::equal_to<long long>,std::allocator<long long>>::__emplace_unique_key_args<long long,long long const&>( /*0x105af6c52*/
        a1: v23,
        a2: &v22,
        a3: &v22,
        a4: v7,
        a5: v9,
        a6: v10,
        a7: v14[0],
        a8: v14[1],
        a9: v15,
        a10: v16[0],
        a11: v16[1]);
    if ( (v20 & 1) != 0 ) /*0x105af6c5b*/
      operator delete(a1: (RBX::Memory *)v21, a2: v8); /*0x105af6c61*/
    v11 = v19; /*0x105af6c66*/
    if ( v19 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v19 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x105af6c83*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(a1: v11); /*0x105af6c8f*/
      std::__shared_weak_count::__release_weak(this: v11); /*0x105af6c95*/
    }
  }
  v14[0] = &off_10C8B6848; /*0x105af6cb1*/
  v17 = off_10C8B6870; /*0x105af6cb9*/
  v15 = &off_10C799250; /*0x105af6cc7*/
  if ( ((__int64)v16[7] & 1) != 0 ) /*0x105af6cd0*/
    operator delete(a1: (RBX::Memory *)v16[9], a2: v3); /*0x105af6cd9*/
  v15 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x105af6cf0*/
  std::locale::~locale(this: (std::locale *)v16); /*0x105af6cf4*/
  std::istream::~istream(a1: v14, a2: off_10C8B6888); /*0x105af6d0b*/
  std::ios::~ios(a1: &v17); /*0x105af6d13*/
  if ( (v24 & 1) != 0 ) /*0x105af6d1c*/
    operator delete(a1: (RBX::Memory *)v25, a2: v12); /*0x105af6d22*/
  return v23; /*0x105af6d2b*/
}

// Address: 0x105b13d29 | Name: __ZN3RBX30transformMatrixRotationToSpaceERKNS_15CoordinateFrameES2_
RBX *__fastcall RBX::transformMatrixRotationToSpace(
        RBX *this,
        const RBX::CoordinateFrame *a2,
        const RBX::CoordinateFrame *a3)
{
  __int128 v4; // xmm0
  _QWORD v6[6]; // [rsp+8h] [rbp-B8h] BYREF
  _BYTE v7[48]; // [rsp+38h] [rbp-88h] BYREF
  _BYTE v8[88]; // [rsp+68h] [rbp-58h] BYREF

  RBX::CoordinateFrame::inverse_SIMD(this: (RBX::CoordinateFrame *)v8); /*0x105b13d50*/
  RBX::CoordinateFrame::operatorMul_SIMD(this: (RBX::CoordinateFrame *)v7, a2: (const RBX::CoordinateFrame *)v8); /*0x105b13d65*/
  RBX::CoordinateFrame::operatorMul_SIMD(this: (RBX::CoordinateFrame *)v6, a2: (const RBX::CoordinateFrame *)v7); /*0x105b13d7a*/
  *((_DWORD *)this + 8) = v6[4]; /*0x105b13d83*/
  v4 = *(_OWORD *)v6; /*0x105b13d86*/
  *((_OWORD *)this + 1) = *(_OWORD *)&v6[2]; /*0x105b13d8f*/
  *(_OWORD *)this = v4; /*0x105b13d93*/
  *(_QWORD *)((char *)this + 36) = 0; /*0x105b13d96*/
  *((_DWORD *)this + 11) = 0; /*0x105b13d9e*/
  return this; /*0x105b13da8*/
}

// Address: 0x105b149bc | Name: __ZN3RBX26transformRtRotationToSpaceERKNS_15RigidTransformTINS_7Vector3EEES4_
__m128 *__fastcall RBX::transformRtRotationToSpace(__m128 *a1, unsigned __int64 *a2, unsigned __int64 *a3)
{
  __m128 v4; // xmm4
  __m128 v5; // xmm9
  __m128 v6; // xmm13
  float v7; // xmm10_4
  __m128 v8; // xmm1
  float v9; // xmm11_4
  __m128 v10; // xmm3
  __m128 v11; // xmm6
  __m128 v12; // xmm7
  float v13; // xmm12_4
  __m128 v14; // xmm8
  __m128 v15; // xmm14
  __m128 v16; // xmm15
  __m128 inserted; // xmm9
  __m128 v18; // xmm5
  float v19; // xmm10_4
  __m128 v20; // xmm8
  __m128 v21; // xmm10
  __m128 v22; // xmm2
  __m128 v23; // xmm2
  __m128 v24; // xmm5

  v4 = (__m128)*((unsigned int *)a3 + 3); /*0x105b149c8*/
  v5 = (__m128)*((unsigned int *)a2 + 3); /*0x105b149cd*/
  v6 = (__m128)*((unsigned int *)a2 + 2); /*0x105b149d3*/
  v7 = (float)(*((float *)a3 + 3) * v6.f32[0]) - (float)(*((float *)a3 + 2) * v5.f32[0]); /*0x105b149ea*/
  v8 = v4; /*0x105b149ef*/
  v8.f32[0] = v4.f32[0] * v5.f32[0]; /*0x105b149f2*/
  v9 = *((float *)a3 + 2) * v6.f32[0]; /*0x105b149fb*/
  v10 = (__m128)*a3; /*0x105b14a00*/
  v11 = (__m128)*(unsigned __int64 *)((char *)a3 + 4); /*0x105b14a04*/
  v12 = _mm_movehdup_ps(v10); /*0x105b14a10*/
  v13 = -v12.f32[0]; /*0x105b14a1c*/
  v14 = _mm_moveldup_ps(v4); /*0x105b14a20*/
  v15 = (__m128)*a2; /*0x105b14a25*/
  v16 = _mm_sub_ps(_mm_mul_ps(v14, v15), _mm_mul_ps(_mm_moveldup_ps(v5), v10)); /*0x105b14a40*/
  inserted = _mm_insert_ps((__m128)*((unsigned int *)a3 + 2), v10, 28); /*0x105b14a48*/
  v18 = _mm_add_ps( /*0x105b14a62*/
          _mm_sub_ps(
            _mm_mul_ps((__m128)*(unsigned __int64 *)((char *)a2 + 4), inserted),
            _mm_mul_ps(_mm_insert_ps(v6, v15, 28), v11)),
          v16);
  v6.f32[0] = _mm_movehdup_ps(v15).f32[0]; /*0x105b14a6b*/
  v12.f32[0] = (float)((float)(v12.f32[0] * v15.f32[0]) - (float)(COERCE_FLOAT(*a3) * v6.f32[0])) + v7; /*0x105b14a7e*/
  v8.f32[0] = v8.f32[0] - (float)((float)((float)(v13 * v6.f32[0]) - (float)(v15.f32[0] * v10.f32[0])) - v9); /*0x105b14a97*/
  v19 = *((float *)a3 + 2) * v8.f32[0]; /*0x105b14aa9*/
  v20 = _mm_add_ps(_mm_mul_ps(v14, v18), _mm_mul_ps(_mm_moveldup_ps(v8), v10)); /*0x105b14ab2*/
  v8.f32[0] = v8.f32[0] * v4.f32[0]; /*0x105b14ab6*/
  v4.f32[0] = (float)(v4.f32[0] * v12.f32[0]) + v19; /*0x105b14abe*/
  v21 = _mm_add_ps( /*0x105b14ae1*/
          _mm_sub_ps(
            _mm_mul_ps(_mm_insert_ps(_mm_movehdup_ps(v18), v12, 16), inserted),
            _mm_mul_ps(_mm_unpacklo_ps(v12, v18), v11)),
          v20);
  v22 = _mm_mul_ps(_mm_shuffle_ps(v10, v10, 225), v18); /*0x105b14ae5*/
  v23 = _mm_hsub_ps(v22, v22); /*0x105b14ae8*/
  v23.f32[0] = v23.f32[0] + v4.f32[0]; /*0x105b14aec*/
  v24 = _mm_mul_ps(v18, v10); /*0x105b14af0*/
  v8.f32[0] = v8.f32[0] - (float)(_mm_hadd_ps(v24, v24).f32[0] + (float)(*((float *)a3 + 2) * v12.f32[0])); /*0x105b14afb*/
  *a1 = _mm_movelh_ps(v21, _mm_insert_ps(v23, v8, 16)); /*0x105b14b09*/
  a1[1].i64[0] = 0; /*0x105b14b0d*/
  a1[1].i32[2] = 0; /*0x105b14b15*/
  return a1; /*0x105b14b1c*/
}

// Address: 0x105b24cb6 | Name: __ZN3RBX15TrackerDataViewIJNS_12PolicyMirrorEEE3getEv
__int64 __fastcall RBX::TrackerDataView<RBX::PolicyMirror>::get(__int64 a1)
{
  _OWORD *v2; // r15
  __int128 v3; // xmm1
  RBX::TrackerData *v4; // rsi

  if ( *(_BYTE *)(a1 + 136) == 0 ) /*0x105b24cca*/
  {
    *(_BYTE *)(a1 + 136) = 1; /*0x105b24ccc*/
    v2 = *(_OWORD **)a1; /*0x105b24cd3*/
    *(_OWORD *)(a1 + 8) = *(_OWORD *)*(_QWORD *)a1; /*0x105b24cde*/
    RBX::FACSData::operator=(a1: (_QWORD *)(a1 + 24), a2: (_QWORD *)v2 + 2); /*0x105b24cea*/
    v3 = v2[7]; /*0x105b24cf4*/
    *(_OWORD *)(a1 + 104) = v2[6]; /*0x105b24cf9*/
    *(_OWORD *)(a1 + 120) = v3; /*0x105b24cfd*/
    RBX::PolicyMirror::apply(this: (RBX::PolicyMirror *)(a1 + 8), a2: v4); /*0x105b24d04*/
  }
  return a1 + 8; /*0x105b24d14*/
}

// Address: 0x105b24d1c | Name: __ZN3RBX15TrackerDataViewIJNS_12PolicyMirrorEEED1Ev
void __fastcall RBX::TrackerDataView<RBX::PolicyMirror>::~TrackerDataView(_QWORD *a1, void *a2)
{
  RBX::Memory *v3; // rdi
  RBX::Memory *v4; // rdi

  v3 = (RBX::Memory *)a1[6]; /*0x105b24d25*/
  if ( v3 != nullptr ) /*0x105b24d2c*/
  {
    a1[7] = v3; /*0x105b24d2e*/
    operator delete(a1: v3, a2); /*0x105b24d32*/
  }
  v4 = (RBX::Memory *)a1[3]; /*0x105b24d37*/
  if ( v4 != nullptr ) /*0x105b24d3e*/
  {
    a1[4] = v4; /*0x105b24d40*/
    operator delete(a1: v4, a2); /*0x105b24d4a*/
  }
}

// Address: 0x105c584fe | Name: __ZN3RBXL20transferKeyValuePairERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEES8_NS0_10shared_ptrIKNS_10Reflection10ValueTableEEENS9_ISB_EE
__int64 __fastcall RBX::transferKeyValuePair(__int64 a1, __int64 a2, _QWORD *a3, __int64 *a4)
{
  __int64 result; // rax
  __int64 v7; // rbx
  __int64 v8; // rdi
  __int64 v9; // rax
  __int64 v10; // [rsp+8h] [rbp-28h] BYREF
  _BYTE v11[25]; // [rsp+17h] [rbp-19h] BYREF

  result = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::find<std::string>( /*0x105c58517*/
             a1: *a3,
             a2: a1);
  if ( result != 0 ) /*0x105c5851f*/
  {
    v7 = result; /*0x105c58521*/
    v8 = *a4; /*0x105c58524*/
    v10 = a2; /*0x105c5852b*/
    v9 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>( /*0x105c5853c*/
           a1: v8,
           a2,
           a3: std::piecewise_construct,
           a4: &v10,
           a5: v11);
    *(_QWORD *)(v9 + 40) = *(_QWORD *)(v7 + 40); /*0x105c58545*/
    return RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v9 + 48, a2: v7 + 48); /*0x105c58554*/
  }
  return result; /*0x105c58559*/
}

// Address: 0x105ebc64e | Name: __ZNK3RBX15TextStrokeStyleeqERKS0_
bool __fastcall RBX::TextStrokeStyle::operator==(__int64 a1, __int64 a2)
{
  return *(float *)a1 == *(float *)a2 /*0x105ebc6a6*/
      && *(float *)(a1 + 4) == *(float *)(a2 + 4)
      && *(float *)(a1 + 8) == *(float *)(a2 + 8)
      && *(float *)(a1 + 12) == *(float *)(a2 + 12)
      && *(float *)(a1 + 16) == *(float *)(a2 + 16)
      && *(_DWORD *)(a1 + 20) == *(_DWORD *)(a2 + 20)
      && *(_DWORD *)(a1 + 24) == *(_DWORD *)(a2 + 24);
}

// Address: 0x105ebc6a8 | Name: __ZNK3RBX17TextStyleModifiereqERKS0_
__int64 __fastcall RBX::TextStyleModifier::operator==(unsigned __int8 *a1, unsigned __int8 *a2)
{
  unsigned int v4; // eax
  size_t v5; // rdx
  unsigned int v6; // ecx
  __int64 v7; // rsi
  unsigned __int8 *v8; // rdi
  unsigned __int8 *v9; // rsi
  unsigned __int8 v10; // al
  unsigned __int8 v11; // cl
  unsigned __int8 v12; // al
  unsigned __int8 v13; // cl
  unsigned __int8 v14; // al
  unsigned __int8 v15; // cl
  unsigned __int8 v16; // al
  unsigned __int8 v17; // cl
  unsigned __int8 v18; // al
  unsigned __int8 v19; // cl
  unsigned __int8 v20; // al
  unsigned __int8 v21; // cl

  v4 = *a1; /*0x105ebc6b5*/
  if ( (v4 & 1) != 0 ) /*0x105ebc6ba*/
    v5 = *((_QWORD *)a1 + 1); /*0x105ebc6bc*/
  else
    v5 = v4 >> 1; /*0x105ebc6c4*/
  v6 = *a2; /*0x105ebc6c6*/
  if ( (v6 & 1) != 0 ) /*0x105ebc6cc*/
    v7 = *((_QWORD *)a2 + 1); /*0x105ebc6ce*/
  else
    v7 = v6 >> 1; /*0x105ebc6d6*/
  if ( v5 != v7 ) /*0x105ebc6db*/
    return 0; /*0x105ebc6db*/
  v8 = (v4 & 1) != 0 ? *((unsigned __int8 **)a1 + 2) : a1 + 1;
  v9 = (v6 & 1) != 0 ? *((unsigned __int8 **)a2 + 2) : a2 + 1;
  if ( memcmp(__s1: v8, __s2: v9, __n: v5) != 0 || a1[24] != a2[24] ) /*0x105ebc712*/
    return 0; /*0x105ebc712*/
  v10 = a1[32]; /*0x105ebc718*/
  v11 = a2[32]; /*0x105ebc721*/
  if ( (v10 ^ 1 | (v10 != v11)) != 0 ) /*0x105ebc72d*/
  {
    if ( v10 != v11 ) /*0x105ebc748*/
      return 0; /*0x105ebc748*/
  }
  else if ( *((float *)a1 + 7) != *((float *)a2 + 7) ) /*0x105ebc739*/
  {
    return 0; /*0x105ebc739*/
  }
  v12 = a1[48]; /*0x105ebc74e*/
  v13 = a2[48]; /*0x105ebc757*/
  if ( (v12 ^ 1 | (v12 != v13)) != 0 ) /*0x105ebc763*/
  {
    if ( v12 != v13 ) /*0x105ebc7aa*/
      return 0; /*0x105ebc7aa*/
  }
  else if ( *((float *)a1 + 9) != *((float *)a2 + 9) /*0x105ebc79b*/
         || *((float *)a1 + 10) != *((float *)a2 + 10)
         || *((float *)a1 + 11) != *((float *)a2 + 11) )
  {
    return 0; /*0x105ebc79b*/
  }
  v14 = a1[56]; /*0x105ebc7b0*/
  v15 = a2[56]; /*0x105ebc7b9*/
  if ( (v14 ^ 1 | (v14 != v15)) != 0 ) /*0x105ebc7c5*/
  {
    if ( v14 != v15 ) /*0x105ebc7e0*/
      return 0; /*0x105ebc7e0*/
  }
  else if ( *((float *)a1 + 13) != *((float *)a2 + 13) ) /*0x105ebc7d1*/
  {
    return 0; /*0x105ebc7d1*/
  }
  v16 = a1[96]; /*0x105ebc7e6*/
  v17 = a2[96]; /*0x105ebc7ef*/
  if ( (v16 ^ 1 | (v16 != v17)) != 0 ) /*0x105ebc7fb*/
  {
    if ( v16 != v17 ) /*0x105ebc812*/
      return 0; /*0x105ebc812*/
  }
  else if ( (unsigned __int8)RBX::operator==(a1: a1 + 64, a2: a2 + 64) == 0 ) /*0x105ebc80c*/
  {
    return 0; /*0x105ebc80c*/
  }
  v18 = a1[140]; /*0x105ebc814*/
  v19 = a2[140]; /*0x105ebc820*/
  if ( (v18 ^ 1 | (v18 != v19)) != 0 ) /*0x105ebc82f*/
  {
    if ( v18 != v19 ) /*0x105ebc846*/
      return 0; /*0x105ebc846*/
  }
  else if ( !RBX::TextStrokeStyle::operator==(a1: (__int64)(a1 + 112), a2: (__int64)(a2 + 112)) ) /*0x105ebc839*/
  {
    return 0; /*0x105ebc840*/
  }
  v20 = a1[148]; /*0x105ebc848*/
  v21 = a2[148]; /*0x105ebc854*/
  if ( (v20 ^ 1 | (v20 != v21)) != 0 ) /*0x105ebc863*/
  {
    if ( v20 == v21 ) /*0x105ebc878*/
      goto LABEL_42; /*0x105ebc878*/
    return 0; /*0x105ebc890*/
  }
  if ( *((_DWORD *)a1 + 36) != *((_DWORD *)a2 + 36) ) /*0x105ebc872*/
    return 0; /*0x105ebc872*/
LABEL_42:
  if ( *((_QWORD *)a1 + 22) != *((_QWORD *)a2 + 22) ) /*0x105ebc888*/
    return 0; /*0x105ebc888*/
  return std::operator==[abi:ne200100]<RBX::Color4,RBX::Color4>(a1: a1 + 152, a2: a2 + 152); /*0x105ebc88c*/
}

// Address: 0x105fb2ce7 | Name: __ZN3RBX12toTextYAlignENS_5Enums18TextYAlignmentEnum10YAlignmentE
__int64 __fastcall RBX::toTextYAlign(int a1)
{
  __int64 result; // rax

  result = a1 == 1; /*0x105fb2cf0*/
  if ( a1 == 2 ) /*0x105fb2cf6*/
    return 2; /*0x105fb2cf6*/
  return result; /*0x105fb2cf9*/
}

// Address: 0x105fe92bf | Name: __ZN3RBX16TextboxIsFocusedEPKNS_7TextBoxE
__int64 __fastcall RBX::TextboxIsFocused(RBX *this, const RBX::TextBox *a2)
{
  RBX *v2; // rbx
  __int64 v3; // r14
  __int64 v4; // rdi
  void *v5; // rsi
  RBX *v6; // r15
  std::__shared_weak_count *v7; // r14
  __int64 v8; // r14
  __int64 v9; // rax
  RBX *v11; // [rsp+0h] [rbp-40h] BYREF
  std::__shared_weak_count *v12; // [rsp+8h] [rbp-38h]
  _BYTE v13[16]; // [rsp+10h] [rbp-30h] BYREF
  void *v14; // [rsp+20h] [rbp-20h]

  v2 = this; /*0x105fe92cc*/
  v3 = RBX::ServiceProvider::find<RBX::UserInputService>(a1: this); /*0x105fe92d4*/
  if ( v3 == 0 || v2 == nullptr ) /*0x105fe92e0*/
  {
    LODWORD(v2) = 0; /*0x105fe92e7*/
  }
  else
  {
    RBX::GuiBase2d::getParentWindowId(this: (RBX::GuiBase2d *)v13); /*0x105fe92f8*/
    RBX::UserInputService::getFocusedTextBox(a1: &v11, a2: v3, a3: v13); /*0x105fe9307*/
    v6 = v11; /*0x105fe930c*/
    v7 = v12; /*0x105fe9310*/
    if ( v12 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v12 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x105fe9329*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x105fe9331*/
      std::__shared_weak_count::__release_weak(this: v7); /*0x105fe9337*/
    }
    if ( v6 != nullptr ) /*0x105fe933f*/
    {
      v8 = *((_QWORD *)v6 + 3); /*0x105fe9341*/
      v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::TextBox>(a1: v4); /*0x105fe9345*/
      if ( *(unsigned __int16 *)(v8 + 440) - (unsigned int)*(unsigned __int16 *)(v9 + 440) > *(unsigned __int16 *)(v9 + 442) ) /*0x105fe9366*/
        v6 = nullptr; /*0x105fe9366*/
      LOBYTE(v2) = v6 == v2; /*0x105fe936d*/
    }
    else
    {
      LODWORD(v2) = 0; /*0x105fe9372*/
    }
    if ( (v13[0] & 1) != 0 ) /*0x105fe9378*/
      operator delete(a1: (RBX::Memory *)v14, a2: v5); /*0x105fe937e*/
  }
  return (unsigned int)v2; /*0x105fe9385*/
}

// Address: 0x10605e757 | Name: __ZN3RBX23throwRegistrationFailedERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEES8_
void __fastcall __noreturn RBX::throwRegistrationFailed(
        __int64 a1,
        __int64 a2,
        __m128 a3,
        __m128 a4,
        __m128 a5,
        __m128 a6,
        __m128 a7,
        __m128 a8,
        __m128 a9,
        __m128 a10,
        __int64 a11,
        __int64 a12,
        __int64 a13,
        __int64 a14)
{
  __int64 v14; // rdx
  __int64 v15; // rcx
  const char *v16; // rcx
  void *exception; // r14
  char v18; // [rsp+0h] [rbp-30h]
  char v19; // [rsp+8h] [rbp-28h] BYREF
  char v20; // [rsp+9h] [rbp-27h] BYREF
  const char *v21; // [rsp+18h] [rbp-18h]

  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x10605e76b*/
    v14 = *(_QWORD *)(a2 + 16); /*0x10605e76d*/
  else
    v14 = a2 + 1; /*0x10605e773*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x10605e779*/
    v15 = *(_QWORD *)(a1 + 16); /*0x10605e77b*/
  else
    v15 = a1 + 1; /*0x10605e781*/
  RBX::format( /*0x10605e791*/
    this: (RBX *)&v19,
    a2: "Flag %s registration from Lua failed, because of %s",
    a3: v14,
    a4: v15,
    a5: a13,
    a6: a14,
    a7: a3,
    a8: a4,
    a9: a5,
    a10: a6,
    a11: a7,
    a12: a8,
    a13: a9,
    a14: a10,
    a15: v18);
  if ( (unsigned __int8)FLog::Output >= 6u && BYTE1(FLog::Output) >= 3u ) /*0x10605e7af*/
  {
    if ( (v19 & 1) != 0 ) /*0x10605e7be*/
      v16 = v21; /*0x10605e7c0*/
    else
      v16 = &v20; /*0x10605e7c6*/
    FLog::FastLogS(this: (FLog *)FLog::Output, a2: qword_10D7BE938, a3: (unsigned __int64)"[FLog::Output] %s", a4: v16); /*0x10605e7d1*/
  }
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10605e7e0*/
  std::runtime_error::runtime_error(a1: exception, a2: &v19); /*0x10605e7ea*/
  __cxa_throw( /*0x10605e800*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10605e82e | Name: __ZN3RBX29throwSettingFlagVersionFailedENS_10StringViewES0_
void __fastcall __noreturn RBX::throwSettingFlagVersionFailed(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  const char *v6; // rcx
  void *exception; // r14
  _QWORD v8[5]; // [rsp+0h] [rbp-70h] BYREF
  _QWORD v9[2]; // [rsp+28h] [rbp-48h] BYREF
  _QWORD v10[2]; // [rsp+38h] [rbp-38h] BYREF
  char v11; // [rsp+48h] [rbp-28h] BYREF
  char v12; // [rsp+49h] [rbp-27h] BYREF
  const char *v13; // [rsp+58h] [rbp-18h]

  v9[0] = a1; /*0x10605e83d*/
  v9[1] = a2; /*0x10605e840*/
  v10[0] = a3; /*0x10605e848*/
  v10[1] = a4; /*0x10605e84b*/
  v8[0] = v10; /*0x10605e853*/
  v8[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x10605e85d*/
  v8[2] = v9; /*0x10605e861*/
  v8[3] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x10605e865*/
  fmt::v8::vformat(a1: &v11, a2: "Setting flag version of {} from Lua, because of {}", 50, 255, v8, a6); /*0x10605e87e*/
  if ( (unsigned __int8)FLog::Output >= 6u && BYTE1(FLog::Output) >= 3u ) /*0x10605e89c*/
  {
    if ( (v11 & 1) != 0 ) /*0x10605e8ab*/
      v6 = v13; /*0x10605e8ad*/
    else
      v6 = &v12; /*0x10605e8b3*/
    FLog::FastLogS(this: (FLog *)FLog::Output, a2: qword_10D7BE938, a3: (unsigned __int64)"[FLog::Output] %s", a4: v6); /*0x10605e8be*/
  }
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10605e8cd*/
  std::runtime_error::runtime_error(a1: exception, a2: &v11); /*0x10605e8d7*/
  __cxa_throw( /*0x10605e8ed*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x106065f96 | Name: __ZN3RBX33throwUndefinedFlagAccessedFromLuaERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
void __fastcall __noreturn RBX::throwUndefinedFlagAccessedFromLua(
        __int64 a1,
        __m128 a2,
        __m128 a3,
        __m128 a4,
        __m128 a5,
        __m128 a6,
        __m128 a7,
        __m128 a8,
        __m128 a9,
        __int64 a10,
        __int64 a11,
        __int64 a12,
        __int64 a13,
        __int64 a14)
{
  __int64 v14; // rdx
  const char *v15; // rcx
  void *exception; // r14
  char v17; // [rsp+0h] [rbp-30h]
  char v18; // [rsp+8h] [rbp-28h] BYREF
  char v19; // [rsp+9h] [rbp-27h] BYREF
  const char *v20; // [rsp+18h] [rbp-18h]

  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x106065fa7*/
    v14 = *(_QWORD *)(a1 + 16); /*0x106065fa9*/
  else
    v14 = a1 + 1; /*0x106065faf*/
  RBX::format( /*0x106065fbf*/
    this: (RBX *)&v18,
    a2: "Flag %s referenced from Lua isn't defined in C++ code",
    a3: v14,
    a4: a12,
    a5: a13,
    a6: a14,
    a7: a2,
    a8: a3,
    a9: a4,
    a10: a5,
    a11: a6,
    a12: a7,
    a13: a8,
    a14: a9,
    a15: v17);
  if ( (unsigned __int8)FLog::Output >= 6u && BYTE1(FLog::Output) >= 3u ) /*0x106065fdd*/
  {
    if ( (v18 & 1) != 0 ) /*0x106065fec*/
      v15 = v20; /*0x106065fee*/
    else
      v15 = &v19; /*0x106065ff4*/
    FLog::FastLogS(this: (FLog *)FLog::Output, a2: qword_10D7BE938, a3: (unsigned __int64)"[FLog::Output] %s", a4: v15); /*0x106065fff*/
  }
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10606600e*/
  std::runtime_error::runtime_error(a1: exception, a2: &v18); /*0x106066018*/
  __cxa_throw( /*0x10606602e*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1061de9f4 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1061dea07*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 13); /*0x1061dea3f*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1061dea4e*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x1061dea58*/
  __cxa_throw( /*0x1061dea6e*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1061dec36 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[16]; // [rsp+0h] [rbp-40h] BYREF
  _BYTE v5[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x1061dec46*/
  fmt::v8::vformat(a1: v5, a2: a1, v2, 0, v4); /*0x1061dec5b*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1061dec6a*/
  std::runtime_error::runtime_error(a1: exception, a2: v5); /*0x1061dec74*/
  __cxa_throw( /*0x1061dec8a*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1061decd6 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERNS_13StringLiteralEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,RBX::StringLiteral &>(
        const char *a1,
        unsigned __int8 *a2,
        __int64 a3)
{
  size_t v6; // rax
  __int64 v7; // r9
  unsigned __int8 *v8; // rdx
  __int64 v9; // rsi
  void *exception; // r15
  _QWORD v11[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v12[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x1061decec*/
  v8 = a2 + 1; /*0x1061decf5*/
  v9 = *a2 >> 1; /*0x1061decfb*/
  if ( (*a2 & 1) != 0 ) /*0x1061ded00*/
  {
    v8 = *((unsigned __int8 **)a2 + 2); /*0x1061ded00*/
    v9 = *((_QWORD *)a2 + 1); /*0x1061ded05*/
  }
  v11[0] = v8; /*0x1061ded0e*/
  v11[1] = v9; /*0x1061ded11*/
  v11[2] = a3; /*0x1061ded15*/
  v11[3] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringLiteral,fmt::v8::formatter<RBX::StringLiteral,char,void>>; /*0x1061ded20*/
  fmt::v8::vformat(a1: v12, a2: a1, v6, 253, v11, v7); /*0x1061ded33*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1061ded42*/
  std::runtime_error::runtime_error(a1: exception, a2: v12); /*0x1061ded4c*/
  __cxa_throw( /*0x1061ded62*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x10627f8d7 | Name: __ZN3RBXL8toPathDMEPNS_14ShadowInstanceE
RBX *__fastcall RBX::toPathDM(RBX *this, RBX::ShadowInstance *a2)
{
  std::__shared_weak_count *v4; // rdi
  volatile signed __int64 *v5; // rax
  volatile signed __int64 *v6; // r14
  RBX::ShadowInstance *v7; // rsi
  __int64 v8; // rax
  __int64 v9; // rsi
  unsigned int v10; // edx
  __int64 v11; // rdx
  __int64 v12; // rsi
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // rax
  __int64 v16; // rax
  __int64 v17; // rax
  void *v18; // rsi
  _BYTE v20[16]; // [rsp+8h] [rbp-58h] BYREF
  void *v21; // [rsp+18h] [rbp-48h]
  __int128 v22; // [rsp+20h] [rbp-40h]
  __int128 v23; // [rsp+30h] [rbp-30h] BYREF
  void *v24; // [rsp+40h] [rbp-20h]

  v22 = 0; /*0x10627f8ed*/
  v4 = *((std::__shared_weak_count **)a2 + 12); /*0x10627f8f1*/
  if ( v4 != nullptr /*0x10627f906*/
    && (v5 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v4),
        *((_QWORD *)&v22 + 1) = v5,
        v5 != nullptr) )
  {
    v6 = v5; /*0x10627f908*/
    v7 = *((RBX::ShadowInstance **)a2 + 11); /*0x10627f90b*/
    *(_QWORD *)&v22 = v7; /*0x10627f90f*/
    if ( v7 != nullptr ) /*0x10627f916*/
    {
      RBX::toPathDM(this: (RBX *)v20, a2: v7); /*0x10627f91c*/
      v8 = std::string::append(a1: v20, a2: "/"); /*0x10627f92c*/
      v24 = *(void **)(v8 + 16); /*0x10627f935*/
      v23 = *(_OWORD *)v8; /*0x10627f93c*/
      *(_OWORD *)v8 = 0; /*0x10627f943*/
      *(_QWORD *)(v8 + 16) = 0; /*0x10627f946*/
      v9 = *((_QWORD *)a2 + 1); /*0x10627f94e*/
      v10 = *(unsigned __int8 *)(v9 + 8); /*0x10627f952*/
      if ( (v10 & 1) != 0 ) /*0x10627f959*/
      {
        v11 = *(_QWORD *)(v9 + 16); /*0x10627f95b*/
        v12 = *(_QWORD *)(v9 + 24); /*0x10627f95f*/
      }
      else
      {
        v12 = v9 + 9; /*0x10627f9c2*/
        v11 = v10 >> 1; /*0x10627f9c6*/
      }
      v17 = std::string::append(a1: &v23, a2: v12, a3: v11); /*0x10627f9cc*/
      *((_QWORD *)this + 2) = *(_QWORD *)(v17 + 16); /*0x10627f9d5*/
      *(_OWORD *)this = *(_OWORD *)v17; /*0x10627f9dc*/
      *(_OWORD *)v17 = 0; /*0x10627f9e2*/
      *(_QWORD *)(v17 + 16) = 0; /*0x10627f9e5*/
      if ( (v23 & 1) != 0 ) /*0x10627f9f1*/
        operator delete(a1: (RBX::Memory *)v24, a2: v18); /*0x10627f9f7*/
      if ( (v20[0] & 1) != 0 ) /*0x10627fa00*/
        operator delete(a1: (RBX::Memory *)v21, a2: v18); /*0x10627fa06*/
      goto LABEL_19; /*0x10627fa06*/
    }
  }
  else
  {
    v6 = nullptr; /*0x10627f965*/
  }
  if ( (unsigned __int8)RBX::operator==<std::string,RBX::ShadowInstanceClassNameBucket,false,char [10]>( /*0x10627f97a*/
                          a1: (char *)a2 + 16,
                          a2: "DataModel") != 0 )
  {
    std::string::basic_string[abi:ne200100]<0>(a1: this, a2: "game", a3: v13, a4: v14); /*0x10627f986*/
  }
  else
  {
    v15 = *((_QWORD *)a2 + 1); /*0x10627f98d*/
    if ( (*(_BYTE *)(v15 + 8) & 1) != 0 ) /*0x10627f995*/
    {
      std::string::__init_copy_ctor_external(a1: this, a2: *(_QWORD *)(v15 + 24), a3: *(_QWORD *)(v15 + 16)); /*0x10627f9b6*/
    }
    else
    {
      v16 = v15 + 8; /*0x10627f997*/
      *((_QWORD *)this + 2) = *(_QWORD *)(v16 + 16); /*0x10627f99f*/
      *(_OWORD *)this = *(_OWORD *)v16; /*0x10627f9a6*/
    }
  }
  if ( v6 != nullptr ) /*0x10627f9be*/
  {
LABEL_19:
    if ( _InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10627fa1b*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(a1: v6); /*0x10627fa23*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v6); /*0x10627fa29*/
    }
  }
  return this; /*0x10627fa31*/
}

// Address: 0x1062b2dd2 | Name: __ZN3RBX22tagFromSecurityContextERKNS_8Security10ProtectionE
__int64 __fastcall RBX::tagFromSecurityContext(__int64 a1, __int64 *a2)
{
  __int64 v3; // rax
  __int128 v4; // xmm0
  __int64 v5; // rsi
  __int64 v6; // rdx
  char v7; // al

  v3 = *a2; /*0x1062b2ddb*/
  if ( (*a2 & 1) != 0 ) /*0x1062b2de0*/
  {
    if ( (RBX::kPluginSecurityTagName & 1) == 0 ) /*0x1062b2e0e*/
    {
      *(_QWORD *)(a1 + 16) = qword_10D805C18; /*0x1062b2e17*/
      v4 = RBX::kPluginSecurityTagName; /*0x1062b2e1b*/
      goto LABEL_10; /*0x1062b2e22*/
    }
    v5 = qword_10D805C18; /*0x1062b2e44*/
    v6 = *((_QWORD *)&RBX::kPluginSecurityTagName + 1); /*0x1062b2e4b*/
LABEL_15:
    std::string::__init_copy_ctor_external(a1, a2: v5, a3: v6); /*0x1062b2e79*/
    goto LABEL_16; /*0x1062b2e7c*/
  }
  if ( (v3 & 2) != 0 ) /*0x1062b2de4*/
  {
    if ( (RBX::kCmdSecurityTagName & 1) == 0 ) /*0x1062b2e2b*/
    {
      *(_QWORD *)(a1 + 16) = qword_10D805C30; /*0x1062b2e34*/
      v4 = RBX::kCmdSecurityTagName; /*0x1062b2e38*/
      goto LABEL_10; /*0x1062b2e38*/
    }
    v5 = qword_10D805C30; /*0x1062b2e54*/
    v6 = *((_QWORD *)&RBX::kCmdSecurityTagName + 1); /*0x1062b2e5b*/
    goto LABEL_15; /*0x1062b2e62*/
  }
  if ( (v3 & 0xFC) != 0 ) /*0x1062b2de8*/
  {
    if ( (RBX::kRobloxSecurityTagName & 1) == 0 ) /*0x1062b2df1*/
    {
      *(_QWORD *)(a1 + 16) = qword_10D805C48; /*0x1062b2dfa*/
      v4 = RBX::kRobloxSecurityTagName; /*0x1062b2dfe*/
LABEL_10:
      *(_OWORD *)a1 = v4; /*0x1062b2e3f*/
LABEL_16:
      v7 = 1; /*0x1062b2e81*/
      goto LABEL_17; /*0x1062b2e81*/
    }
    v5 = qword_10D805C48; /*0x1062b2e6b*/
    v6 = *((_QWORD *)&RBX::kRobloxSecurityTagName + 1); /*0x1062b2e72*/
    goto LABEL_15; /*0x1062b2e72*/
  }
  *(_BYTE *)a1 = 0; /*0x1062b2e64*/
  v7 = 0; /*0x1062b2e67*/
LABEL_17:
  *(_BYTE *)(a1 + 24) = v7; /*0x1062b2e83*/
  return a1; /*0x1062b2e8d*/
}

// Address: 0x1062eef15 | Name: __ZN3RBXL11tryFindTypeERKNS_17DefinitionContextEPKc
__int64 __fastcall RBX::tryFindType(RBX *this, const RBX::DefinitionContext *a2, const char *a3, __int64 a4)
{
  __int64 v4; // rbx
  __int64 v5; // rbx
  void *v6; // rsi
  _BYTE v8[16]; // [rsp+8h] [rbp-28h] BYREF
  void *v9; // [rsp+18h] [rbp-18h]

  v4 = *(_QWORD *)(*((_QWORD *)this + 1) + 392LL) + 128LL; /*0x1062eef2b*/
  std::string::basic_string[abi:ne200100]<0>(a1: v8, a2, a3, a4); /*0x1062eef36*/
  v5 = std::__hash_table<std::__hash_value_type<std::string,Luau::TypeFun>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,Luau::TypeFun>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,Luau::TypeFun>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,Luau::TypeFun>>>::find<std::string>( /*0x1062eef46*/
         a1: v4,
         a2: v8);
  if ( (v8[0] & 1) != 0 ) /*0x1062eef4d*/
    operator delete(a1: (RBX::Memory *)v9, a2: v6); /*0x1062eef53*/
  if ( v5 != 0 ) /*0x1062eef5b*/
    return *(_QWORD *)(v5 + 88); /*0x1062eef5d*/
  else
    return 0; /*0x1062eef65*/
}

// Address: 0x10631c1e8 | Name: __ZN3RBXL14tryMatchLookupERKN4Luau11AstExprCallEPKNS0_11TypePackVarEmb
__int64 __fastcall RBX::tryMatchLookup(__int64 a1, __int64 a2, __int64 a3, unsigned __int64 a4, unsigned __int8 a5)
{
  __int64 v7; // r13
  const Luau::Type *v9; // rsi
  _DWORD *v10; // rax
  _DWORD *v11; // rcx
  __int64 v12; // rdx
  __int64 v13; // rax
  char v14; // dl
  __int64 v15; // rdx
  char v16; // al
  void *v18; // [rsp+0h] [rbp-50h] BYREF
  void *v19; // [rsp+8h] [rbp-48h]

  v7 = *(_QWORD *)(a2 + 64) + *(unsigned __int8 *)(a2 + 72); /*0x10631c204*/
  if ( ((*(_DWORD *)(a2 + 64) + *(unsigned __int8 *)(a2 + 72)) & 0x7FFFFFFFu) > a4 || (int)v7 < 2 ) /*0x10631c20c*/
  {
    *(_BYTE *)a1 = 0; /*0x10631c224*/
    *(_BYTE *)(a1 + 24) = 0; /*0x10631c226*/
    return a1; /*0x10631c229*/
  }
  Luau::flatten(a1: &v18, a2: a3); /*0x10631c23b*/
  if ( v18 != v19 ) /*0x10631c249*/
  {
    v10 = (_DWORD *)Luau::follow(this: *(Luau **)v18, a2: v9); /*0x10631c24e*/
    if ( v10 != nullptr ) /*0x10631c256*/
    {
      v11 = nullptr; /*0x10631c25f*/
      if ( *v10 == 11 ) /*0x10631c264*/
        v11 = v10 + 4; /*0x10631c264*/
    }
    else
    {
      v11 = nullptr; /*0x10631c26a*/
    }
    v12 = *(unsigned __int8 *)(a2 + 72) ^ 1LL; /*0x10631c271*/
    v9 = *(const Luau::Type **)(a2 + 56); /*0x10631c275*/
    v13 = *((_QWORD *)v9 + v12); /*0x10631c279*/
    if ( v13 != 0 && *(_DWORD *)(v13 + 8) == Luau::AstRtti<Luau::AstExprConstantString>::value ) /*0x10631c28b*/
    {
      if ( (a5 | ((_DWORD)v7 != 3)) != 0 ) /*0x10631c298*/
      {
        v14 = 0; /*0x10631c29a*/
LABEL_16:
        *(_QWORD *)a1 = v11; /*0x10631c2b6*/
        *(_QWORD *)(a1 + 8) = v13; /*0x10631c2b9*/
        *(_BYTE *)(a1 + 16) = v14; /*0x10631c2bd*/
        v16 = 1; /*0x10631c2c0*/
        goto LABEL_18; /*0x10631c2c2*/
      }
      v15 = *((_QWORD *)v9 + v12 + 1); /*0x10631c29e*/
      if ( v15 != 0 ) /*0x10631c2a6*/
      {
        v9 = (const Luau::Type *)(unsigned int)Luau::AstRtti<Luau::AstExprConstantBool>::value; /*0x10631c2a8*/
        if ( *(_DWORD *)(v15 + 8) == Luau::AstRtti<Luau::AstExprConstantBool>::value ) /*0x10631c2b1*/
        {
          v14 = *(_BYTE *)(v15 + 28); /*0x10631c2b3*/
          goto LABEL_16; /*0x10631c2b3*/
        }
      }
    }
  }
  *(_BYTE *)a1 = 0; /*0x10631c2c4*/
  v16 = 0; /*0x10631c2c7*/
LABEL_18:
  *(_BYTE *)(a1 + 24) = v16; /*0x10631c2c9*/
  if ( v18 != nullptr ) /*0x10631c2d3*/
  {
    v19 = v18; /*0x10631c2d5*/
    operator delete(a1: (RBX::Memory *)v18, a2: v9); /*0x10631c2d9*/
  }
  return a1; /*0x10631c2e1*/
}

// Address: 0x10631d5aa | Name: __ZN3RBXL11tryMatchIsAERKN4Luau11AstExprCallE
__int64 __fastcall RBX::tryMatchIsA(__int64 a1, __int64 a2)
{
  int v3; // eax
  __int64 v4; // rcx
  __int64 *v5; // rcx
  __int64 *v6; // rdx
  __int64 v7; // r12
  __int64 v8; // r13
  void *v10; // rsi
  bool v11; // zf
  __int128 v12; // [rsp+8h] [rbp-68h]
  __int128 v13; // [rsp+18h] [rbp-58h] BYREF
  void *v14; // [rsp+28h] [rbp-48h]
  __int128 v15; // [rsp+30h] [rbp-40h] BYREF
  void *v16; // [rsp+40h] [rbp-30h]

  v3 = *(unsigned __int8 *)(a2 + 72); /*0x10631d5be*/
  if ( v3 + *(_DWORD *)(a2 + 64) != 2 ) /*0x10631d5ca*/
    goto LABEL_11; /*0x10631d5ca*/
  if ( *(_BYTE *)(a2 + 72) != 0 ) /*0x10631d5d3*/
  {
    v4 = *(_QWORD *)(a2 + 32); /*0x10631d5d5*/
    if ( v4 == 0 || *(_DWORD *)(v4 + 8) != (_DWORD)Luau::AstRtti<Luau::AstExprIndexName>::value ) /*0x10631d5eb*/
      goto LABEL_11; /*0x10631d5eb*/
    v5 = (__int64 *)(v4 + 32); /*0x10631d5f1*/
    v6 = *(__int64 **)(a2 + 56); /*0x10631d5f5*/
  }
  else
  {
    v6 = *(__int64 **)(a2 + 56); /*0x10631d5fb*/
    v5 = v6; /*0x10631d5ff*/
  }
  v7 = v6[v3 ^ 1u]; /*0x10631d605*/
  if ( v7 == 0 || *(_DWORD *)(v7 + 8) != Luau::AstRtti<Luau::AstExprConstantString>::value ) /*0x10631d619*/
  {
LABEL_11:
    *(_BYTE *)a1 = 0; /*0x10631d673*/
    *(_BYTE *)(a1 + 40) = 0; /*0x10631d677*/
    return a1; /*0x10631d677*/
  }
  v8 = *v5; /*0x10631d61b*/
  std::string::basic_string[abi:ne200100](a1: &v15, a2: *(_QWORD *)(v7 + 32), a3: *(_QWORD *)(v7 + 40)); /*0x10631d62f*/
  *(_QWORD *)&v12 = v8; /*0x10631d638*/
  *((_QWORD *)&v12 + 1) = v7; /*0x10631d63c*/
  if ( (v15 & 1) != 0 ) /*0x10631d644*/
  {
    std::string::__init_copy_ctor_external(a1: &v13, a2: v16, a3: *((_QWORD *)&v15 + 1)); /*0x10631d697*/
    v11 = (v15 & 1) == 0; /*0x10631d69c*/
    *(_OWORD *)a1 = v12; /*0x10631d6a4*/
    *(_OWORD *)(a1 + 16) = v13; /*0x10631d6ab*/
    *(_QWORD *)(a1 + 32) = v14; /*0x10631d6b3*/
    *(_BYTE *)(a1 + 40) = 1; /*0x10631d6b7*/
    if ( !v11 ) /*0x10631d6bb*/
      operator delete(a1: (RBX::Memory *)v16, a2: v10); /*0x10631d6c1*/
  }
  else
  {
    v14 = v16; /*0x10631d64a*/
    v13 = v15; /*0x10631d652*/
    *(_OWORD *)a1 = v12; /*0x10631d65a*/
    *(_QWORD *)(a1 + 32) = v14; /*0x10631d661*/
    *(_OWORD *)(a1 + 16) = v13; /*0x10631d669*/
    *(_BYTE *)(a1 + 40) = 1; /*0x10631d66d*/
  }
  return a1; /*0x10631d67d*/
}

// Address: 0x106335ee7 | Name: __ZN3RBX17translateLuauPathEN5boost10filesystem4pathE
unsigned __int8 *__fastcall RBX::translateLuauPath(unsigned __int8 *a1, __int128 *a2)
{
  __int64 v4; // rdx
  __int64 v5; // rcx
  void *v6; // rsi
  bool v7; // bl
  void *v8; // rsi
  void *v9; // rsi
  void *v10; // rsi
  bool v11; // bl
  const char *v12; // rsi
  void *v13; // rsi
  void *v14; // rsi
  bool v15; // bl
  void *v16; // rsi
  unsigned int v17; // eax
  __int64 v18; // rax
  bool i; // bl
  void *v20; // rsi
  bool v21; // r13
  bool v22; // zf
  unsigned __int8 *v23; // rbx
  char *v24; // rsi
  __int64 v25; // rdx
  unsigned __int8 *v26; // rbx
  _BYTE v28[16]; // [rsp+8h] [rbp-148h] BYREF
  void *v29; // [rsp+18h] [rbp-138h]
  _BYTE v30[16]; // [rsp+30h] [rbp-120h] BYREF
  void *v31; // [rsp+40h] [rbp-110h]
  _BYTE v32[16]; // [rsp+58h] [rbp-F8h] BYREF
  void *v33; // [rsp+68h] [rbp-E8h]
  _BYTE v34[16]; // [rsp+80h] [rbp-D0h] BYREF
  void *v35; // [rsp+90h] [rbp-C0h]
  unsigned __int8 *v36; // [rsp+A8h] [rbp-A8h]
  __int128 v37; // [rsp+B0h] [rbp-A0h] BYREF
  void *v38; // [rsp+C0h] [rbp-90h]
  __int128 v39; // [rsp+D0h] [rbp-80h] BYREF
  void *v40; // [rsp+E0h] [rbp-70h]
  __int128 v41; // [rsp+E8h] [rbp-68h]
  __int128 v42; // [rsp+100h] [rbp-50h] BYREF
  void *v43; // [rsp+110h] [rbp-40h]
  __int128 v44; // [rsp+118h] [rbp-38h]

  *(_OWORD *)a1 = 0; /*0x106335f04*/
  *((_QWORD *)a1 + 2) = 0; /*0x106335f07*/
  v36 = a1; /*0x106335f13*/
  boost::filesystem::path::filename(this: (boost::filesystem::path *)&v39, (unsigned __int8 *)a2); /*0x106335f1a*/
  if ( (unsigned int)boost::filesystem::path::compare(this: (boost::filesystem::path *)&v39, a2: "init.lua") != 0 ) /*0x106335f31*/
  {
    boost::filesystem::path::filename(this: (boost::filesystem::path *)&v42, (unsigned __int8 *)a2); /*0x106335f3a*/
    v7 = (unsigned int)boost::filesystem::path::compare(this: (boost::filesystem::path *)&v42, a2: "init.luau") == 0; /*0x106335f51*/
    if ( (v42 & 1) != 0 ) /*0x106335f58*/
      operator delete(a1: (RBX::Memory *)v43, a2: v6); /*0x106335f5e*/
  }
  else
  {
    v7 = true; /*0x106335f65*/
  }
  if ( (v39 & 1) != 0 ) /*0x106335f6b*/
    operator delete(a1: (RBX::Memory *)v40, a2: v6); /*0x106335f71*/
  if ( v7 ) /*0x106335f78*/
    boost::filesystem::path::remove_filename(this: (boost::filesystem::path *)a2); /*0x106335f7d*/
  v39 = 0; /*0x106335f85*/
  v40 = nullptr; /*0x106335f89*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x106335f95*/
  {
    std::string::__init_copy_ctor_external(a1: &v37, a2: *((_QWORD *)a2 + 2), a3: *((_QWORD *)a2 + 1)); /*0x106335fbe*/
  }
  else
  {
    v38 = *((void **)a2 + 2); /*0x106335f9b*/
    v37 = *a2; /*0x106335fa6*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v42, a2: "", a3: v4, a4: v5); /*0x106335fce*/
  boost::filesystem::path::replace_extension( /*0x106335fde*/
    this: (boost::filesystem::path *)&v37,
    a2: (const boost::filesystem::path *)&v42);
  if ( (v42 & 1) != 0 ) /*0x106335fe7*/
    operator delete(a1: (RBX::Memory *)v43, a2: v8); /*0x106335fed*/
  boost::filesystem::path::begin(this: (boost::filesystem::path *)v28, a2: (unsigned __int8 *)&v37); /*0x106336000*/
  boost::filesystem::path::end(this: (boost::filesystem::path *)v30, a2: (unsigned __int8 *)&v37); /*0x106336013*/
  std::find[abi:ne200100]<boost::filesystem::path::iterator,char [8]>(a1: &v42, a2: v28, a3: v30, a4: "Modules"); /*0x106336031*/
  if ( (v39 & 1) != 0 ) /*0x10633603a*/
    operator delete(a1: (RBX::Memory *)v40, a2: v9); /*0x106336040*/
  v40 = v43; /*0x106336049*/
  v39 = v42; /*0x106336051*/
  LOWORD(v42) = 0; /*0x106336055*/
  v41 = v44; /*0x10633605f*/
  if ( (v30[0] & 1) != 0 ) /*0x10633606a*/
    operator delete(a1: (RBX::Memory *)v31, a2: v9); /*0x106336073*/
  if ( (v28[0] & 1) != 0 ) /*0x10633607f*/
    operator delete(a1: (RBX::Memory *)v29, a2: v9); /*0x106336088*/
  boost::filesystem::path::end(this: (boost::filesystem::path *)&v42, a2: (unsigned __int8 *)&v37); /*0x106336098*/
  v11 = v44 != v41; /*0x1063360b0*/
  if ( (v42 & 1) != 0 ) /*0x1063360b7*/
    operator delete(a1: (RBX::Memory *)v43, a2: v10); /*0x1063360bd*/
  if ( v11 ) /*0x1063360c4*/
  {
    v12 = "game/CoreGui/RobloxGui"; /*0x1063360c6*/
LABEL_34:
    std::string::assign(a1, a2: v12); /*0x1063361bb*/
    goto LABEL_38; /*0x1063361c3*/
  }
  boost::filesystem::path::begin(this: (boost::filesystem::path *)v32, a2: (unsigned __int8 *)&v37); /*0x1063360e0*/
  boost::filesystem::path::end(this: (boost::filesystem::path *)v34, a2: (unsigned __int8 *)&v37); /*0x1063360f3*/
  std::find[abi:ne200100]<boost::filesystem::path::iterator,char [12]>(a1: &v42, a2: v32, a3: v34, a4: "LuaPackages"); /*0x106336111*/
  if ( (v39 & 1) != 0 ) /*0x10633611f*/
    operator delete(a1: (RBX::Memory *)v40, a2: v13); /*0x106336125*/
  v40 = v43; /*0x10633612e*/
  v39 = v42; /*0x106336136*/
  LOWORD(v42) = 0; /*0x10633613a*/
  v41 = v44; /*0x106336144*/
  if ( (v34[0] & 1) != 0 ) /*0x10633614f*/
    operator delete(a1: (RBX::Memory *)v35, a2: v13); /*0x106336158*/
  if ( (v32[0] & 1) != 0 ) /*0x106336164*/
    operator delete(a1: (RBX::Memory *)v33, a2: v13); /*0x10633616d*/
  boost::filesystem::path::end(this: (boost::filesystem::path *)&v42, a2: (unsigned __int8 *)&v37); /*0x10633617d*/
  v15 = v44 != v41; /*0x106336195*/
  if ( (v42 & 1) != 0 ) /*0x10633619c*/
    operator delete(a1: (RBX::Memory *)v43, a2: v14); /*0x1063361a2*/
  if ( v15 ) /*0x1063361a9*/
  {
    boost::filesystem::path::m_path_iterator_increment(a1: (unsigned __int8 *)&v39); /*0x1063361af*/
    v12 = "game/CorePackages"; /*0x1063361b4*/
    goto LABEL_34; /*0x1063361b4*/
  }
  boost::filesystem::path::begin(this: (boost::filesystem::path *)&v42, a2: (unsigned __int8 *)&v37); /*0x1063361d0*/
  if ( (v39 & 1) != 0 ) /*0x1063361d9*/
    operator delete(a1: (RBX::Memory *)v40, a2: v16); /*0x1063361df*/
  v40 = v43; /*0x1063361e8*/
  v39 = v42; /*0x1063361f0*/
  v41 = v44; /*0x1063361f8*/
LABEL_38:
  v17 = *a1; /*0x1063361fc*/
  if ( (v17 & 1) != 0 ) /*0x106336202*/
    v18 = *((_QWORD *)a1 + 1); /*0x106336204*/
  else
    v18 = v17 >> 1; /*0x10633620a*/
  for ( i = v18 == 0; ; i = false ) /*0x10633620f*/
  {
    boost::filesystem::path::end(this: (boost::filesystem::path *)&v42, a2: (unsigned __int8 *)&v37); /*0x106336227*/
    v21 = v44 != v41; /*0x10633623f*/
    if ( (v42 & 1) != 0 ) /*0x106336247*/
      operator delete(a1: (RBX::Memory *)v43, a2: v20); /*0x10633624d*/
    if ( !v21 ) /*0x106336255*/
      break; /*0x106336255*/
    v22 = !i; /*0x106336257*/
    v23 = v36; /*0x10633625a*/
    if ( v22 ) /*0x106336261*/
      std::string::push_back(a1: v36, a2: 47); /*0x10633626b*/
    if ( (v39 & 1) != 0 ) /*0x106336277*/
    {
      v24 = (char *)v40; /*0x106336279*/
      v25 = *((_QWORD *)&v39 + 1); /*0x10633627d*/
    }
    else
    {
      v25 = (unsigned __int8)v39 >> 1; /*0x106336283*/
      v24 = (char *)&v39 + 1; /*0x106336285*/
    }
    std::string::append(a1: v23, a2: v24, a3: v25); /*0x10633628c*/
    boost::filesystem::path::m_path_iterator_increment(a1: (unsigned __int8 *)&v39); /*0x106336296*/
  }
  v26 = v36; /*0x1063362a4*/
  if ( (v37 & 1) != 0 ) /*0x1063362ab*/
    operator delete(a1: (RBX::Memory *)v38, a2: v20); /*0x1063362b4*/
  if ( (v39 & 1) != 0 ) /*0x1063362bd*/
    operator delete(a1: (RBX::Memory *)v40, a2: v20); /*0x1063362c3*/
  return v26; /*0x1063362cb*/
}

// Address: 0x10697f127 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_10StringViewERKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEES9_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringView &,std::string const&,std::string>(
        const char *a1,
        __int64 a2,
        unsigned __int8 *a3,
        unsigned __int8 *a4)
{
  size_t v8; // rax
  unsigned __int8 *v9; // rdx
  __int64 v10; // rsi
  unsigned __int8 *v11; // rdi
  __int64 v12; // r9
  void *exception; // r15
  _QWORD v14[7]; // [rsp+0h] [rbp-70h] BYREF
  _BYTE v15[56]; // [rsp+38h] [rbp-38h] BYREF

  v8 = strlen(__s: a1); /*0x10697f142*/
  v9 = a3 + 1; /*0x10697f14c*/
  v10 = *a3 >> 1; /*0x10697f153*/
  if ( (*a3 & 1) != 0 ) /*0x10697f158*/
  {
    v9 = *((unsigned __int8 **)a3 + 2); /*0x10697f158*/
    v10 = *((_QWORD *)a3 + 1); /*0x10697f15e*/
  }
  v11 = a4 + 1; /*0x10697f168*/
  v12 = *a4 >> 1; /*0x10697f16f*/
  if ( (*a4 & 1) != 0 ) /*0x10697f175*/
  {
    v11 = *((unsigned __int8 **)a4 + 2); /*0x10697f175*/
    v12 = *((_QWORD *)a4 + 1); /*0x10697f17a*/
  }
  v14[0] = a2; /*0x10697f183*/
  v14[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::StringView,fmt::v8::formatter<RBX::StringView,char,void>>; /*0x10697f18d*/
  v14[2] = v9; /*0x10697f191*/
  v14[3] = v10; /*0x10697f195*/
  v14[4] = v11; /*0x10697f199*/
  v14[5] = v12; /*0x10697f19d*/
  fmt::v8::vformat(a1: v15, a2: a1, v8, 3551, v14, v12); /*0x10697f1b0*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10697f1bf*/
  std::runtime_error::runtime_error(a1: exception, a2: v15); /*0x10697f1c9*/
  __cxa_throw( /*0x10697f1df*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x106d928db | Name: __ZN3RBX31throw_runtime_error_safe_formatIJmmEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<unsigned long,unsigned long>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+20h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x106d928f1*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 68); /*0x106d92916*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x106d92925*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x106d9292f*/
  __cxa_throw( /*0x106d92945*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x106f69af8 | Name: __ZN3RBX8toStringERKN5boost10filesystem4pathE
RBX *__fastcall RBX::toString(RBX *this, const boost::filesystem::path *a2)
{
  RBX::utf8_encode(a1: this, a2); /*0x106f69b01*/
  return this; /*0x106f69b0d*/
}

// Address: 0x106f7276d | Name: __ZN3RBX9toQStringERK9HttpError
QString *__fastcall RBX::toQString(QString *this, __int64 a2)
{
  const char *v3; // r14
  int v4; // edx

  v3 = *(const char **)(a2 + 8); /*0x106f72777*/
  if ( v3 != nullptr ) /*0x106f7277e*/
    v4 = strlen(__s: *(const char **)(a2 + 8)); /*0x106f72788*/
  else
    v4 = -1; /*0x106f7278d*/
  QString::fromUtf8_helper(this, a2: v3, a3: v4); /*0x106f72798*/
  return this; /*0x106f727a0*/
}

// Address: 0x10704fa40 | Name: __ZN3RBX9toQStringERKNS_4NameE
RBX *__fastcall RBX::toQString(RBX *this, const RBX::Name *a2)
{
  unsigned int v3; // edx
  int v4; // edx
  const char *v5; // r14

  v3 = *(unsigned __int8 *)a2; /*0x10704fa4d*/
  if ( (v3 & 1) != 0 ) /*0x10704fa53*/
  {
    v4 = *((_DWORD *)a2 + 2); /*0x10704fa55*/
    v5 = *((const char **)a2 + 2); /*0x10704fa59*/
  }
  else
  {
    v5 = (char *)a2 + 1; /*0x10704fa5f*/
    v4 = v3 >> 1; /*0x10704fa62*/
  }
  if ( v5 != nullptr && v4 == -1 ) /*0x10704fa6d*/
    v4 = strlen(__s: v5); /*0x10704fa7c*/
  QString::fromUtf8_helper(this, a2: v5, a3: v4); /*0x10704fa85*/
  return this; /*0x10704fa8d*/
}

// Address: 0x10704fa92 | Name: __ZN3RBX9toQStringERKNS_9ContentIdE
RBX *__fastcall RBX::toQString(RBX *this, const RBX::ContentId *a2)
{
  unsigned int v3; // edx
  int v4; // edx
  const char *v5; // r14

  v3 = *((unsigned __int8 *)a2 + 8); /*0x10704fa9f*/
  if ( (v3 & 1) != 0 ) /*0x10704faa6*/
  {
    v4 = *((_DWORD *)a2 + 4); /*0x10704faa8*/
    v5 = *((const char **)a2 + 3); /*0x10704faac*/
  }
  else
  {
    v5 = (char *)a2 + 9; /*0x10704fab2*/
    v4 = v3 >> 1; /*0x10704fab6*/
  }
  if ( v5 != nullptr && v4 == -1 ) /*0x10704fac1*/
    v4 = strlen(__s: v5); /*0x10704fad0*/
  QString::fromUtf8_helper(this, a2: v5, a3: v4); /*0x10704fad9*/
  return this; /*0x10704fae1*/
}

// Address: 0x1070e54fc | Name: __ZN3RBXL12toValueArrayENS_9ArrayViewIxEE
RSL::Arena *__fastcall RBX::toValueArray(RSL::Arena *a1, unsigned __int64 a2, unsigned __int64 a3)
{
  unsigned __int64 v5; // r15
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // r8
  __int64 v9; // rdi
  __int64 v10; // r14
  __int64 v11; // r13
  __int64 v13; // [rsp+0h] [rbp-80h] BYREF
  __int64 v14; // [rsp+8h] [rbp-78h] BYREF
  _BYTE v15[64]; // [rsp+10h] [rbp-70h] BYREF

  if ( a3 != 0 ) /*0x1070e5521*/
  {
    v5 = a2; /*0x1070e5526*/
    RBX::make_shared<std::vector<RBX::Reflection::Variant>>(a1, a2); /*0x1070e552c*/
    std::vector<RBX::Reflection::Variant>::reserve(a1: *(__int64 **)a1, a2: a3, a3: v6, a4: v7, a5: v8); /*0x1070e5537*/
    v10 = 8 * a3; /*0x1070e553c*/
    do /*0x1070e5587*/
    {
      v11 = *(_QWORD *)a1; /*0x1070e5544*/
      v13 = RBX::Reflection::Type::getSingleton<long long>(a1: v9); /*0x1070e554c*/
      v14 = 0; /*0x1070e5550*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<long long>(a1: &v14, a2: v5); /*0x1070e555f*/
      std::vector<RBX::Reflection::Variant>::push_back[abi:ne200100](a1: v11, a2: (__int64)&v13); /*0x1070e556a*/
      if ( v14 != 0 ) /*0x1070e5576*/
        (*(void (__fastcall **)(_BYTE *))(v14 + 16))(a1: v15); /*0x1070e557c*/
      v5 += 8LL; /*0x1070e557f*/
      v10 -= 8; /*0x1070e5583*/
    }
    while ( v10 != 0 ); /*0x1070e5587*/
  }
  else
  {
    *(_OWORD *)a1 = 0; /*0x1070e5598*/
  }
  return a1; /*0x1070e55a4*/
}

// Address: 0x107385d1c | Name: __ZN3RBXL4trimERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
__int64 __fastcall RBX::trim(__int64 a1, unsigned __int8 *a2)
{
  unsigned int v3; // eax
  unsigned __int64 v4; // rax
  unsigned __int8 *v5; // rsi
  unsigned __int64 first_not_of; // rax
  unsigned __int64 v7; // r12
  __int64 last_not_of; // rax
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rax
  unsigned __int8 *v12; // [rsp+0h] [rbp-40h] BYREF
  unsigned __int64 v13; // [rsp+8h] [rbp-38h]
  unsigned __int8 *v14; // [rsp+10h] [rbp-30h] BYREF
  unsigned __int64 v15; // [rsp+18h] [rbp-28h]

  v3 = *a2; /*0x107385d2e*/
  if ( (v3 & 1) != 0 ) /*0x107385d33*/
  {
    v4 = *((_QWORD *)a2 + 1); /*0x107385d35*/
    v5 = *((unsigned __int8 **)a2 + 2); /*0x107385d39*/
  }
  else
  {
    v5 = a2 + 1; /*0x107385d3f*/
    v4 = v3 >> 1; /*0x107385d42*/
  }
  v12 = v5; /*0x107385d48*/
  v13 = v4; /*0x107385d4b*/
  first_not_of = RBX::detail::StringViewBase::find_first_not_of(a1: &v12, a2: " \t\n\v\f\r", a3: 6, a4: 0); /*0x107385d63*/
  if ( first_not_of >= v13 ) /*0x107385d6f*/
    first_not_of = v13; /*0x107385d6f*/
  v7 = v13 - first_not_of; /*0x107385d73*/
  v14 = &v12[first_not_of]; /*0x107385d7d*/
  v15 = v13 - first_not_of; /*0x107385d80*/
  last_not_of = RBX::detail::StringViewBase::find_last_not_of(a1: &v14, a2: " \t\n\v\f\r", a3: 6, a4: -1); /*0x107385d96*/
  if ( v14 != nullptr ) /*0x107385da1*/
  {
    v9 = last_not_of + 1; /*0x107385dad*/
    if ( v9 >= v15 ) /*0x107385db3*/
      v9 = v15; /*0x107385db3*/
    v10 = v15 - v7 + v9; /*0x107385db7*/
    if ( v15 < v10 ) /*0x107385dbd*/
      v10 = v15; /*0x107385dbd*/
    std::string::basic_string[abi:ne200100](a1, a2: v14, a3: v10); /*0x107385dc7*/
  }
  else
  {
    *(_OWORD *)a1 = 0; /*0x107385dd1*/
    *(_QWORD *)(a1 + 16) = 0; /*0x107385dd4*/
  }
  return a1; /*0x107385ddf*/
}

// Address: 0x10739214a | Name: __ZN3RBXL4trimERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE_0
__int64 __fastcall RBX::trim(__int64 a1, unsigned __int8 *a2)
{
  unsigned int v3; // eax
  unsigned __int64 v4; // rax
  unsigned __int8 *v5; // rsi
  unsigned __int64 first_not_of; // rax
  unsigned __int64 v7; // r12
  __int64 last_not_of; // rax
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rax
  unsigned __int8 *v12; // [rsp+0h] [rbp-40h] BYREF
  unsigned __int64 v13; // [rsp+8h] [rbp-38h]
  unsigned __int8 *v14; // [rsp+10h] [rbp-30h] BYREF
  unsigned __int64 v15; // [rsp+18h] [rbp-28h]

  v3 = *a2; /*0x10739215c*/
  if ( (v3 & 1) != 0 ) /*0x107392161*/
  {
    v4 = *((_QWORD *)a2 + 1); /*0x107392163*/
    v5 = *((unsigned __int8 **)a2 + 2); /*0x107392167*/
  }
  else
  {
    v5 = a2 + 1; /*0x10739216d*/
    v4 = v3 >> 1; /*0x107392170*/
  }
  v12 = v5; /*0x107392176*/
  v13 = v4; /*0x107392179*/
  first_not_of = RBX::detail::StringViewBase::find_first_not_of(a1: &v12, a2: " \t\n\v\f\r", a3: 6, a4: 0); /*0x107392191*/
  if ( first_not_of >= v13 ) /*0x10739219d*/
    first_not_of = v13; /*0x10739219d*/
  v7 = v13 - first_not_of; /*0x1073921a1*/
  v14 = &v12[first_not_of]; /*0x1073921ab*/
  v15 = v13 - first_not_of; /*0x1073921ae*/
  last_not_of = RBX::detail::StringViewBase::find_last_not_of(a1: &v14, a2: " \t\n\v\f\r", a3: 6, a4: -1); /*0x1073921c4*/
  if ( v14 != nullptr ) /*0x1073921cf*/
  {
    v9 = last_not_of + 1; /*0x1073921db*/
    if ( v9 >= v15 ) /*0x1073921e1*/
      v9 = v15; /*0x1073921e1*/
    v10 = v15 - v7 + v9; /*0x1073921e5*/
    if ( v15 < v10 ) /*0x1073921eb*/
      v10 = v15; /*0x1073921eb*/
    std::string::basic_string[abi:ne200100](a1, a2: v14, a3: v10); /*0x1073921f5*/
  }
  else
  {
    *(_OWORD *)a1 = 0; /*0x1073921ff*/
    *(_QWORD *)(a1 + 16) = 0; /*0x107392202*/
  }
  return a1; /*0x10739220d*/
}

// Address: 0x1073bd624 | Name: __ZN3RBX26TextFilterTranslatedResultaSEOS0_
__int64 __fastcall RBX::TextFilterTranslatedResult::operator=(__int64 a1, _BYTE *a2)
{
  __int64 v4; // r15
  _BYTE *v5; // r12
  void *v6; // rsi

  *(_BYTE *)a1 = *a2; /*0x1073bd637*/
  v4 = a1 + 8; /*0x1073bd639*/
  v5 = a2 + 8; /*0x1073bd63d*/
  if ( (*(_BYTE *)(a1 + 8) & 1) != 0 ) /*0x1073bd645*/
    operator delete(a1: *(RBX::Memory **)(a1 + 24), a2); /*0x1073bd64b*/
  *(_QWORD *)(v4 + 16) = *((_QWORD *)v5 + 2); /*0x1073bd655*/
  *(_OWORD *)v4 = *(_OWORD *)v5; /*0x1073bd65e*/
  *((_WORD *)a2 + 4) = 0; /*0x1073bd662*/
  if ( (*(_BYTE *)(a1 + 32) & 1) != 0 ) /*0x1073bd675*/
    operator delete(a1: *(RBX::Memory **)(a1 + 48), a2); /*0x1073bd67b*/
  *(_QWORD *)(a1 + 48) = *((_QWORD *)a2 + 6); /*0x1073bd685*/
  *(_OWORD *)(a1 + 32) = *((_OWORD *)a2 + 2); /*0x1073bd68e*/
  *((_WORD *)a2 + 16) = 0; /*0x1073bd692*/
  RBX::TextFilterResult::operator=(a1: a1 + 56, a2: a2 + 56); /*0x1073bd6a1*/
  std::__hash_table<std::__hash_value_type<std::string,RBX::TextFilterResult>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::TextFilterResult>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::TextFilterResult>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::TextFilterResult>>>::__move_assign( /*0x1073bd6b2*/
    a1: a1 + 424,
    a2: a2 + 424);
  *(_BYTE *)(a1 + 464) = a2[464]; /*0x1073bd6be*/
  if ( (*(_BYTE *)(a1 + 472) & 1) != 0 ) /*0x1073bd6d2*/
    operator delete(a1: *(RBX::Memory **)(a1 + 488), a2: v6); /*0x1073bd6db*/
  *(_QWORD *)(a1 + 488) = *((_QWORD *)a2 + 61); /*0x1073bd6e7*/
  *(_OWORD *)(a1 + 472) = *(_OWORD *)(a2 + 472); /*0x1073bd6f3*/
  *((_WORD *)a2 + 236) = 0; /*0x1073bd6f7*/
  RBX::TextFilterResult::operator=(a1: a1 + 496, a2: a2 + 496); /*0x1073bd70d*/
  RBX::details::SplitHashTable<std::string,std::pair<std::string,RBX::TextFilterResult>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,RBX::TextFilterResult>>::operator=<10,void>( /*0x1073bd71e*/
    a1: a1 + 864,
    a2: a2 + 864);
  RBX::details::SplitHashTable<long long,long long,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<long long>,RBX::details::DefaultEqualTo<long long>,RBX::details::GetSelfKey<long long>>::operator=<10,void>( /*0x1073bd732*/
    a1: a1 + 904,
    a2: a2 + 904);
  return a1; /*0x1073bd73a*/
}

// Address: 0x1073c298c | Name: __ZN3RBX16TextFilterResultaSEOS0_
__int64 __fastcall RBX::TextFilterResult::operator=(__int64 a1, __int64 a2)
{
  __int64 v4; // r15
  __int64 v5; // r12

  *(_DWORD *)(a1 + 7) = *(_DWORD *)(a2 + 7); /*0x1073c29a0*/
  *(_QWORD *)a1 = *(_QWORD *)a2; /*0x1073c29a6*/
  v4 = a1 + 16; /*0x1073c29a9*/
  v5 = a2 + 16; /*0x1073c29ad*/
  if ( (*(_BYTE *)(a1 + 16) & 1) != 0 ) /*0x1073c29b5*/
    operator delete(a1: *(RBX::Memory **)(a1 + 32), (void *)a2); /*0x1073c29bb*/
  *(_QWORD *)(v4 + 16) = *(_QWORD *)(v5 + 16); /*0x1073c29c5*/
  *(_OWORD *)v4 = *(_OWORD *)v5; /*0x1073c29ce*/
  *(_WORD *)(a2 + 16) = 0; /*0x1073c29d2*/
  if ( (*(_BYTE *)(a1 + 40) & 1) != 0 ) /*0x1073c29e5*/
    operator delete(a1: *(RBX::Memory **)(a1 + 56), (void *)a2); /*0x1073c29eb*/
  *(_QWORD *)(a1 + 56) = *(_QWORD *)(a2 + 56); /*0x1073c29f5*/
  *(_OWORD *)(a1 + 40) = *(_OWORD *)(a2 + 40); /*0x1073c29fe*/
  *(_WORD *)(a2 + 40) = 0; /*0x1073c2a02*/
  if ( (*(_BYTE *)(a1 + 64) & 1) != 0 ) /*0x1073c2a15*/
    operator delete(a1: *(RBX::Memory **)(a1 + 80), (void *)a2); /*0x1073c2a1b*/
  *(_QWORD *)(a1 + 80) = *(_QWORD *)(a2 + 80); /*0x1073c2a25*/
  *(_OWORD *)(a1 + 64) = *(_OWORD *)(a2 + 64); /*0x1073c2a2e*/
  *(_WORD *)(a2 + 64) = 0; /*0x1073c2a32*/
  if ( (*(_BYTE *)(a1 + 88) & 1) != 0 ) /*0x1073c2a45*/
    operator delete(a1: *(RBX::Memory **)(a1 + 104), (void *)a2); /*0x1073c2a4b*/
  *(_QWORD *)(a1 + 104) = *(_QWORD *)(a2 + 104); /*0x1073c2a55*/
  *(_OWORD *)(a1 + 88) = *(_OWORD *)(a2 + 88); /*0x1073c2a5e*/
  *(_WORD *)(a2 + 88) = 0; /*0x1073c2a62*/
  if ( (*(_BYTE *)(a1 + 112) & 1) != 0 ) /*0x1073c2a75*/
    operator delete(a1: *(RBX::Memory **)(a1 + 128), (void *)a2); /*0x1073c2a7e*/
  *(_QWORD *)(a1 + 128) = *(_QWORD *)(a2 + 128); /*0x1073c2a88*/
  *(_OWORD *)(a1 + 112) = *(_OWORD *)(a2 + 112); /*0x1073c2a91*/
  *(_WORD *)(a2 + 112) = 0; /*0x1073c2a95*/
  if ( (*(_BYTE *)(a1 + 136) & 1) != 0 ) /*0x1073c2ab0*/
    operator delete(a1: *(RBX::Memory **)(a1 + 152), (void *)a2); /*0x1073c2ab9*/
  *(_QWORD *)(a1 + 152) = *(_QWORD *)(a2 + 152); /*0x1073c2ac3*/
  *(_OWORD *)(a1 + 136) = *(_OWORD *)(a2 + 136); /*0x1073c2acc*/
  *(_WORD *)(a2 + 136) = 0; /*0x1073c2ad0*/
  if ( (*(_BYTE *)(a1 + 160) & 1) != 0 ) /*0x1073c2aee*/
    operator delete(a1: *(RBX::Memory **)(a1 + 176), (void *)a2); /*0x1073c2af7*/
  *(_QWORD *)(a1 + 176) = *(_QWORD *)(a2 + 176); /*0x1073c2b01*/
  *(_OWORD *)(a1 + 160) = *(_OWORD *)(a2 + 160); /*0x1073c2b0a*/
  *(_WORD *)(a2 + 160) = 0; /*0x1073c2b0e*/
  if ( (*(_BYTE *)(a1 + 184) & 1) != 0 ) /*0x1073c2b2c*/
    operator delete(a1: *(RBX::Memory **)(a1 + 200), (void *)a2); /*0x1073c2b35*/
  *(_QWORD *)(a1 + 200) = *(_QWORD *)(a2 + 200); /*0x1073c2b3f*/
  *(_OWORD *)(a1 + 184) = *(_OWORD *)(a2 + 184); /*0x1073c2b48*/
  *(_WORD *)(a2 + 184) = 0; /*0x1073c2b4c*/
  if ( (*(_BYTE *)(a1 + 208) & 1) != 0 ) /*0x1073c2b6a*/
    operator delete(a1: *(RBX::Memory **)(a1 + 224), (void *)a2); /*0x1073c2b73*/
  *(_QWORD *)(a1 + 224) = *(_QWORD *)(a2 + 224); /*0x1073c2b7d*/
  *(_OWORD *)(a1 + 208) = *(_OWORD *)(a2 + 208); /*0x1073c2b86*/
  *(_WORD *)(a2 + 208) = 0; /*0x1073c2b8a*/
  if ( (*(_BYTE *)(a1 + 232) & 1) != 0 ) /*0x1073c2ba2*/
    operator delete(a1: *(RBX::Memory **)(a1 + 248), (void *)a2); /*0x1073c2bab*/
  *(_QWORD *)(a1 + 248) = *(_QWORD *)(a2 + 248); /*0x1073c2bb7*/
  *(_OWORD *)(a1 + 232) = *(_OWORD *)(a2 + 232); /*0x1073c2bc3*/
  *(_WORD *)(a2 + 232) = 0; /*0x1073c2bc7*/
  RBX::details::SplitHashTable<long long,long long,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<long long>,RBX::details::DefaultEqualTo<long long>,RBX::details::GetSelfKey<long long>>::operator=<10,void>( /*0x1073c2bdd*/
    a1: a1 + 256,
    a2: a2 + 256);
  std::vector<long long>::__move_assign(a1: a1 + 296, a2: a2 + 296); /*0x1073c2bee*/
  std::vector<std::string>::__vdeallocate(a1: (__int64 *)(a1 + 320)); /*0x1073c2bfa*/
  *(_OWORD *)(a1 + 320) = *(_OWORD *)(a2 + 320); /*0x1073c2c07*/
  *(_QWORD *)(a1 + 336) = *(_QWORD *)(a2 + 336); /*0x1073c2c15*/
  *(_QWORD *)(a2 + 336) = 0; /*0x1073c2c1f*/
  *(_OWORD *)(a2 + 320) = 0; /*0x1073c2c29*/
  std::vector<std::string>::__vdeallocate(a1: (__int64 *)(a1 + 344)); /*0x1073c2c38*/
  *(_OWORD *)(a1 + 344) = *(_OWORD *)(a2 + 344); /*0x1073c2c45*/
  *(_QWORD *)(a1 + 360) = *(_QWORD *)(a2 + 360); /*0x1073c2c53*/
  *(_QWORD *)(a2 + 360) = 0; /*0x1073c2c5a*/
  *(_OWORD *)(a2 + 344) = 0; /*0x1073c2c64*/
  return a1; /*0x1073c2c6f*/
}

// Address: 0x107561e2a | Name: __ZN3RBX22TeleportTransitionDataaSERKS0_
__int64 __fastcall RBX::TeleportTransitionData::operator=(__int64 a1, __int64 a2)
{
  __int128 v4; // xmm1
  __int128 v5; // xmm2
  __int128 v6; // xmm3

  std::string::operator=(a1, a2); /*0x107561e37*/
  v4 = *(_OWORD *)(a2 + 40); /*0x107561e41*/
  v5 = *(_OWORD *)(a2 + 56); /*0x107561e46*/
  v6 = *(_OWORD *)(a2 + 65); /*0x107561e4b*/
  *(_OWORD *)(a1 + 24) = *(_OWORD *)(a2 + 24); /*0x107561e50*/
  *(_OWORD *)(a1 + 40) = v4; /*0x107561e54*/
  *(_OWORD *)(a1 + 56) = v5; /*0x107561e58*/
  *(_OWORD *)(a1 + 65) = v6; /*0x107561e5c*/
  std::shared_ptr<RBX::Instance>::operator=[abi:ne200100](a1: a1 + 88, a2: a2 + 88); /*0x107561e68*/
  std::shared_ptr<RBX::Instance>::operator=[abi:ne200100](a1: a1 + 104, a2: a2 + 104); /*0x107561e75*/
  *(_QWORD *)(a1 + 120) = *(_QWORD *)(a2 + 120); /*0x107561e7e*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: a1 + 128, a2: a2 + 128); /*0x107561e8e*/
  *(_QWORD *)(a1 + 200) = *(_QWORD *)(a2 + 200); /*0x107561e9a*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: a1 + 208, a2: a2 + 208); /*0x107561ead*/
  *(_QWORD *)(a1 + 280) = *(_QWORD *)(a2 + 280); /*0x107561ebb*/
  *(_QWORD *)(a1 + 288) = *(_QWORD *)(a2 + 288); /*0x107561eca*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: a1 + 296, a2: a2 + 296); /*0x107561edd*/
  *(_QWORD *)(a1 + 368) = *(_QWORD *)(a2 + 368); /*0x107561ee9*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: a1 + 376, a2: a2 + 376); /*0x107561efc*/
  std::string::operator=(a1: a1 + 448, a2: a2 + 448); /*0x107561f0d*/
  std::string::operator=(a1: a1 + 472, a2: a2 + 472); /*0x107561f1e*/
  std::string::operator=(a1: a1 + 496, a2: a2 + 496); /*0x107561f2f*/
  if ( a1 != a2 ) /*0x107561f37*/
  {
    *(_DWORD *)(a1 + 552) = *(_DWORD *)(a2 + 552); /*0x107561f49*/
    std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__assign_multi<std::__hash_const_iterator<std::__hash_node<std::__hash_value_type<std::string,RBX::Reflection::Variant>,void *> *>>( /*0x107561f5a*/
      a1: a1 + 520,
      a2: *(_QWORD *)(a2 + 536),
      a3: 0);
  }
  std::deque<std::pair<long long,long long>>::operator=(a1: a1 + 560, a2: a2 + 560); /*0x107561f6b*/
  std::deque<std::pair<long long,long long>>::operator=(a1: a1 + 608, a2: a2 + 608); /*0x107561f7f*/
  return a1; /*0x107561f87*/
}

// Address: 0x10757f318 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_EEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<std::string const&,std::string const&>(
        const char *a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3)
{
  size_t v6; // rax
  unsigned __int8 *v7; // rdx
  __int64 v8; // rsi
  unsigned __int8 *v9; // rdi
  __int64 v10; // r9
  void *exception; // r15
  _QWORD v12[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v13[48]; // [rsp+20h] [rbp-30h] BYREF

  v6 = strlen(__s: a1); /*0x10757f32e*/
  v7 = a2 + 1; /*0x10757f337*/
  v8 = *a2 >> 1; /*0x10757f33d*/
  if ( (*a2 & 1) != 0 ) /*0x10757f342*/
  {
    v7 = *((unsigned __int8 **)a2 + 2); /*0x10757f342*/
    v8 = *((_QWORD *)a2 + 1); /*0x10757f347*/
  }
  v9 = a3 + 1; /*0x10757f350*/
  v10 = *a3 >> 1; /*0x10757f357*/
  if ( (*a3 & 1) != 0 ) /*0x10757f35d*/
  {
    v9 = *((unsigned __int8 **)a3 + 2); /*0x10757f35d*/
    v10 = *((_QWORD *)a3 + 1); /*0x10757f362*/
  }
  v12[0] = v7; /*0x10757f36b*/
  v12[1] = v8; /*0x10757f36e*/
  v12[2] = v9; /*0x10757f372*/
  v12[3] = v10; /*0x10757f376*/
  fmt::v8::vformat(a1: v13, a2: a1, v6, 221, v12, v10); /*0x10757f389*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x10757f398*/
  std::runtime_error::runtime_error(a1: exception, a2: v13); /*0x10757f3a2*/
  __cxa_throw( /*0x10757f3b8*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x107ce709c | Name: __ZN3RBX8toStringENS_18BacktraceAttributeE
const char *__fastcall RBX::toString(unsigned int a1)
{
  if ( a1 > 0xAB ) /*0x107ce70a6*/
    return "Unknown"; /*0x107ce70ba*/
  else
    return (char *)dword_10A52D3AC + dword_10A52D3AC[a1]; /*0x107ce70b5*/
}

// Address: 0x107f21356 | Name: __ZN3RBX31throw_runtime_error_safe_formatIJRNS_13StringLiteralEEEEvPKcDpOT_
void __fastcall __noreturn RBX::throw_runtime_error_safe_format<RBX::StringLiteral &>(const char *a1)
{
  size_t v2; // rax
  void *exception; // r15
  _BYTE v4[48]; // [rsp+10h] [rbp-30h] BYREF

  v2 = strlen(__s: a1); /*0x107f21369*/
  fmt::v8::vformat(a1: v4, a2: a1, v2, 15); /*0x107f2138f*/
  exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x107f2139e*/
  std::runtime_error::runtime_error(a1: exception, a2: v4); /*0x107f213a8*/
  __cxa_throw( /*0x107f213be*/
    a1: exception,
    lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
    a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
}

// Address: 0x1083817d1 | Name: __ZN3RBX30teamCreateFinalSaveWithRetriesENSt3__110shared_ptrINS_9DataModelEEEx
char __fastcall RBX::teamCreateFinalSaveWithRetries(RBX::Tasks::ThisTask *a1, __int64 a2)
{
  __int64 v2; // rdx
  unsigned __int64 v3; // rcx
  RBX::Tasks::ThisTask *v4; // rdi
  int v5; // eax
  std::__shared_weak_count *v6; // rbx
  __int64 v7; // rcx
  __int64 v8; // rdi
  volatile signed __int64 *v9; // rax
  __int64 v10; // rdx
  __int64 v11; // rcx
  unsigned __int64 v12; // r14
  __int64 v13; // r13
  std::__shared_weak_count *v14; // r12
  std::__shared_weak_count *v15; // r12
  RBX::Tasks::ThisTask *v16; // rdi
  char v17; // r14
  unsigned int BackOffMs; // eax
  __int64 v19; // rcx
  __int128 v20; // xmm0
  volatile signed __int64 *v21; // r14
  __int128 v22; // xmm0
  std::__shared_weak_count *v23; // r14
  std::__shared_weak_count *v24; // r14
  bool v25; // cc
  void *v26; // rsi
  void *v27; // rsi
  std::__shared_weak_count *v29[2]; // [rsp+10h] [rbp-330h] BYREF
  void *v30; // [rsp+20h] [rbp-320h]
  __int64 v31; // [rsp+30h] [rbp-310h]
  char v32[472]; // [rsp+58h] [rbp-2E8h] BYREF
  __int64 v33; // [rsp+230h] [rbp-110h]
  RBX::Tasks::ThisTask *v34; // [rsp+238h] [rbp-108h]
  void **v35; // [rsp+240h] [rbp-100h]
  __int64 (__fastcall ***v36)(); // [rsp+248h] [rbp-F8h]
  std::__shared_weak_count *v37[2]; // [rsp+250h] [rbp-F0h] BYREF
  __int128 v38; // [rsp+260h] [rbp-E0h] BYREF
  __int128 v39; // [rsp+270h] [rbp-D0h]
  int v40; // [rsp+280h] [rbp-C0h]
  __int128 v41; // [rsp+288h] [rbp-B8h]
  std::__shared_weak_count *v42[2]; // [rsp+2A0h] [rbp-A0h] BYREF
  char v43; // [rsp+2B0h] [rbp-90h]
  __int128 v44; // [rsp+2C0h] [rbp-80h] BYREF
  char v45; // [rsp+2D0h] [rbp-70h]
  __int64 v46; // [rsp+2E0h] [rbp-60h] BYREF
  std::__shared_weak_count *v47; // [rsp+2E8h] [rbp-58h]
  __int64 v48; // [rsp+2F0h] [rbp-50h]
  double v49; // [rsp+2F8h] [rbp-48h]
  std::__shared_weak_count *v50[2]; // [rsp+300h] [rbp-40h] BYREF

  v33 = a2; /*0x1083817e5*/
  v34 = a1; /*0x1083817ec*/
  RBX::Tasks::ThisTask::requireIsRunningAsTask(this: a1); /*0x1083817f3*/
  v4 = DFLog::PlaceUpload; /*0x1083817f8*/
  if ( (unsigned __int8)DFLog::PlaceUpload >= 6u && ((unsigned __int16)DFLog::PlaceUpload & 0xFC00) != 0 ) /*0x10838180c*/
  {
    v29[0] = nullptr; /*0x108381821*/
    v29[1] = (std::__shared_weak_count *)&v38; /*0x10838182c*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x108381856*/
      a1: (_DWORD)DFLog::PlaceUpload,
      a2: qword_10D87DB70,
      a3: 4,
      a4: (unsigned int)"[DFLog::PlaceUpload] PlaceUploads::teamCreateFinalSaveWithRetries started.",
      a5: 74,
      a6: 1,
      0,
      &v38);
  }
  v38 = xmmword_109483DE0; /*0x108381862*/
  v39 = xmmword_109483DF0; /*0x108381870*/
  v40 = 0; /*0x108381877*/
  v41 = xmmword_108F39B00; /*0x108381889*/
  if ( FFlag::TeamCreateFinalSaveRetryConfigurable == 1 ) /*0x108381898*/
  {
    v3 = (unsigned int)DFInt::TeamCreateFinalSaveRetryMaxBackoffTimeMs; /*0x1083818a0*/
    v2 = (unsigned int)DFInt::TeamCreateFinalSaveRetryMaxElapsedTimeMs; /*0x1083818a6*/
    *(_QWORD *)&v38 = __PAIR64__( /*0x1083818b2*/
                        DFInt::TeamCreateFinalSaveRetryMaxBackoffTimeMs,
                        DFInt::TeamCreateFinalSaveRetryBaseTimeMs);
    HIDWORD(v38) = DFInt::TeamCreateFinalSaveRetryRandomOffsetRangeMs; /*0x1083818be*/
    DWORD1(v39) = DFInt::TeamCreateFinalSaveRetryMaxElapsedTimeMs; /*0x1083818c4*/
    HIDWORD(v39) = 1; /*0x1083818ca*/
    *(_QWORD *)&v41 = 0x4000000000000000LL; /*0x1083818de*/
  }
  v5 = DFInt::TeamCreateFinalSaveRetryMax; /*0x1083818e5*/
  if ( DFInt::TeamCreateFinalSaveRetryMax < 0 ) /*0x1083818ed*/
  {
LABEL_53:
    LOBYTE(v3) = (unsigned __int8)DFLog::PlaceUpload < 6u; /*0x108381cc7*/
    LOBYTE(v2) = (unsigned __int8)DFLog::PlaceUpload < 6u || ((unsigned __int16)DFLog::PlaceUpload & 0xFE00) == 0; /*0x108381cde*/
    if ( (_BYTE)v2 == 0 ) /*0x108381ce0*/
    {
      v50[0] = (std::__shared_weak_count *)(unsigned int)(v5 + 1); /*0x108381cef*/
      v29[0] = (std::__shared_weak_count *)1; /*0x108381cf2*/
      v29[1] = (std::__shared_weak_count *)v50; /*0x108381cfd*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x108381d29*/
        a1: (_DWORD)DFLog::PlaceUpload,
        a2: qword_10D87DB70,
        a3: 2,
        a4: (unsigned int)"[DFLog::PlaceUpload] PlaceUploads::teamCreateFinalSaveWithRetries max attempts {} reached.",
        a5: 90,
        a6: 1,
        1,
        v50);
    }
    std::string::basic_string[abi:ne200100]<0>(a1: v29, a2: "timedout", a3: v2, a4: v3); /*0x108381d3f*/
    RBX::`anonymous namespace'::sendFinalSaveRetryOutcomeTelemetry( /*0x108381d4d*/
      a1: v29,
      a2: (unsigned int)DFInt::TeamCreateFinalSaveRetryMax);
LABEL_70:
    if ( ((__int64)v29[0] & 1) != 0 ) /*0x108381fa0*/
      operator delete(a1: (RBX::Memory *)v30, a2: v26); /*0x108381fa9*/
    return 0; /*0x108381fae*/
  }
  v48 = (unsigned int)DFInt::TeamCreateFinalSaveRetryBaseTimeMs; /*0x1083818f9*/
  v6 = nullptr; /*0x1083818fd*/
  v36 = off_10C8C7EC0; /*0x108381911*/
  v35 = (void **)off_10C8C7EB0; /*0x10838191c*/
  while ( 1 ) /*0x108381923*/
  {
    if ( (unsigned __int8)RBX::Tasks::ThisTask::isStopRequested(this: v4) != 0 ) /*0x10838192a*/
    {
      LOBYTE(v7) = (unsigned __int8)DFLog::PlaceUpload < 6u || ((unsigned __int16)DFLog::PlaceUpload & 0xFC00) == 0; /*0x108381d6e*/
      if ( (_BYTE)v7 == 0 ) /*0x108381d70*/
      {
        v29[0] = nullptr; /*0x108381d79*/
        v29[1] = (std::__shared_weak_count *)v50; /*0x108381d88*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x108381db4*/
          a1: (_DWORD)DFLog::PlaceUpload,
          a2: qword_10D87DB70,
          a3: 4,
          a4: (unsigned int)"[DFLog::PlaceUpload] PlaceUploads::teamCreateFinalSaveWithRetries stopped.",
          a5: 74,
          a6: 1,
          0,
          v50);
      }
      goto LABEL_69; /*0x108381db4*/
    }
    v8 = *(_QWORD *)(*(_QWORD *)v34 + 1176LL); /*0x10838193a*/
    v46 = *(_QWORD *)v34; /*0x108381941*/
    v9 = *((volatile signed __int64 **)v34 + 1); /*0x108381945*/
    v47 = (std::__shared_weak_count *)v9; /*0x108381949*/
    if ( v9 != nullptr ) /*0x108381950*/
      _InterlockedIncrement64(v9 + 1); /*0x108381952*/
    *(_OWORD *)v37 = 0; /*0x10838195b*/
    v12 = (*(__int64 (__fastcall **)(__int64, __int64 *, __int64, _QWORD, __int64, _QWORD, std::__shared_weak_count **))(*(_QWORD *)v8 + 24LL))( /*0x10838198c*/
            a1: v8,
            a2: &v46,
            a3: 2,
            a4: 0,
            a5: v33,
            a6: 0,
            a7: v37);
    v13 = v10; /*0x10838198f*/
    v14 = v37[1]; /*0x108381992*/
    if ( v37[1] != nullptr /*0x1083819af*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v37[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x1083819b8*/
      std::__shared_weak_count::__release_weak(this: v14); /*0x1083819be*/
    }
    v15 = v47; /*0x1083819c3*/
    if ( v47 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v47 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1083819dd*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x1083819e6*/
      std::__shared_weak_count::__release_weak(this: v15); /*0x1083819ec*/
    }
    if ( (v13 & 1) != 0 ) /*0x1083819f5*/
      break; /*0x1083819f5*/
    v16 = DFLog::PlaceUpload; /*0x1083819fb*/
    if ( (unsigned __int8)DFLog::PlaceUpload >= 6u && ((unsigned __int16)DFLog::PlaceUpload & 0xFE00) != 0 ) /*0x108381a0f*/
    {
      v29[0] = v6; /*0x108381a25*/
      v30 = (void *)(unsigned int)(DFInt::TeamCreateFinalSaveRetryMax + 1); /*0x108381a2c*/
      v50[0] = (std::__shared_weak_count *)17; /*0x108381a33*/
      v50[1] = (std::__shared_weak_count *)v29; /*0x108381a3b*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x108381a61*/
        a1: (_DWORD)DFLog::PlaceUpload,
        a2: qword_10D87DB70,
        a3: 2,
        a4: (unsigned int)"[DFLog::PlaceUpload] PlaceUploads::teamCreateFinalSaveWithRetries TeamCreate DataModel save failed"
                      ", attempt {} of {}.",
        a5: 117,
        a6: 1,
        17,
        v29);
    }
    if ( FFlag::TeamCreateFinalSaveRetryConfigurable == 1 && ((unsigned __int64)&_mh_execute_header & v13) == 0 ) /*0x108381a7c*/
    {
      LOBYTE(v11) = (unsigned __int8)DFLog::PlaceUpload < 6u || ((unsigned __int16)DFLog::PlaceUpload & 0xFE00) == 0; /*0x108381ea7*/
      if ( (_BYTE)v11 == 0 ) /*0x108381ea9*/
      {
        v29[0] = nullptr; /*0x108381eb2*/
        v29[1] = (std::__shared_weak_count *)v50; /*0x108381ec1*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x108381eed*/
          a1: (_DWORD)DFLog::PlaceUpload,
          a2: qword_10D87DB70,
          a3: 2,
          a4: (unsigned int)"[DFLog::PlaceUpload] PlaceUploads::teamCreateFinalSaveWithRetries failure not retryable, aborting.",
          a5: 98,
          a6: 1,
          0,
          v50);
      }
      std::string::basic_string[abi:ne200100]<0>(a1: v29, a2: "notRetried", a3: v10, a4: v11); /*0x108381f03*/
      RBX::`anonymous namespace'::sendFinalSaveRetryOutcomeTelemetry(a1: v29, a2: (unsigned int)v6); /*0x108381f0d*/
      goto LABEL_70; /*0x108381f12*/
    }
    if ( DFFlag::TeamCreateFinalSaveRetryLoopWarningCap == 1 /*0x108381a94*/
      && v6 == (std::__shared_weak_count *)(unsigned int)DFInt::TeamCreateFinalSaveRetryLoopWarningCapThreshold )
    {
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x108381aa0*/
        a1: v29,
        a2: (__int64)&RBX::Telemetry::kTeamCreateFinalSaveRetryLoopWarningCapCounter);
      RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v29); /*0x108381aa8*/
      RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v32); /*0x108381abb*/
      RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: (void **)v29, a2: v35); /*0x108381aca*/
    }
    if ( (unsigned __int8)RBX::Tasks::ThisTask::isStopRequested(this: v16) != 0 ) /*0x108381ad6*/
    {
      LOBYTE(v7) = (unsigned __int8)DFLog::PlaceUpload < 6u || ((unsigned __int16)DFLog::PlaceUpload & 0xFC00) == 0; /*0x108381f2e*/
      if ( (_BYTE)v7 == 0 ) /*0x108381f30*/
      {
        v29[0] = nullptr; /*0x108381f39*/
        v29[1] = (std::__shared_weak_count *)v50; /*0x108381f48*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x108381f74*/
          a1: (_DWORD)DFLog::PlaceUpload,
          a2: qword_10D87DB70,
          a3: 4,
          a4: (unsigned int)"[DFLog::PlaceUpload] PlaceUploads::teamCreateFinalSaveWithRetries stopped.",
          a5: 74,
          a6: 1,
          0,
          v50);
      }
LABEL_69:
      std::string::basic_string[abi:ne200100]<0>(a1: v29, a2: "stopped", a3: v2, a4: v7); /*0x108381f79*/
      RBX::`anonymous namespace'::sendFinalSaveRetryOutcomeTelemetry(a1: v29, a2: (unsigned int)v6); /*0x108381f94*/
      goto LABEL_70; /*0x108381f94*/
    }
    if ( (__int64)v6 < DFInt::TeamCreateFinalSaveRetryMax ) /*0x108381ae6*/
    {
      if ( FFlag::TeamCreateFinalSaveRetryConfigurable == 1 ) /*0x108381af3*/
      {
        if ( FFlag::EnableFloatingPointBaseMultiplier == 1 ) /*0x108381aff*/
        {
          if ( *((double *)&v41 + 1) > 32768.0 ) /*0x108381b11*/
            *((_QWORD *)&v41 + 1) = 0x40E0000000000000LL; /*0x108381b1d*/
        }
        else if ( HIDWORD(v39) >= 0x8001 ) /*0x108381b30*/
        {
          HIDWORD(v39) = 0x8000; /*0x108381b32*/
        }
      }
      v17 = DFFlag::TeamCreateFinalSaveRetryMonotonicBackoff; /*0x108381b3c*/
      BackOffMs = RBX::ExponentialBackoff::nextBackOffMs(this: (RBX::ExponentialBackoff *)&v38); /*0x108381b4a*/
      if ( v17 == 1 ) /*0x108381b53*/
      {
        v19 = v48; /*0x108381b55*/
        if ( BackOffMs > (unsigned int)v48 ) /*0x108381b5b*/
          v19 = BackOffMs; /*0x108381b5b*/
        v48 = v19; /*0x108381b5e*/
        v49 = (double)(int)v19 * 0.001; /*0x108381b72*/
        RBX::Tasks::ThisTask::detail::getStopSource(this: (RBX::Tasks::ThisTask::detail *)v50); /*0x108381b7b*/
        v20 = *(_OWORD *)v50; /*0x108381b80*/
        if ( v50[1] != nullptr ) /*0x108381b8b*/
          _InterlockedIncrement64((volatile signed __int64 *)v50[1] + 1); /*0x108381b8d*/
        *(_OWORD *)v42 = v20; /*0x108381b92*/
        *(_OWORD *)v29 = 0; /*0x108381b9c*/
        v43 = 1; /*0x108381ba3*/
        RBX::Tasks::sleep(a1: v42, a2: v49); /*0x108381bb6*/
        if ( v43 != 1 ) /*0x108381bc2*/
          goto LABEL_46; /*0x108381bc2*/
        v21 = (volatile signed __int64 *)v42[1]; /*0x108381bc8*/
      }
      else
      {
        v49 = (double)(int)BackOffMs * 0.001; /*0x108381be3*/
        RBX::Tasks::ThisTask::detail::getStopSource(this: (RBX::Tasks::ThisTask::detail *)v50); /*0x108381bec*/
        v22 = *(_OWORD *)v50; /*0x108381bf1*/
        if ( v50[1] != nullptr ) /*0x108381bfc*/
          _InterlockedIncrement64((volatile signed __int64 *)v50[1] + 1); /*0x108381bfe*/
        v44 = v22; /*0x108381c03*/
        *(_OWORD *)v29 = 0; /*0x108381c0a*/
        v45 = 1; /*0x108381c11*/
        RBX::Tasks::sleep(a1: &v44, a2: v49); /*0x108381c1e*/
        if ( v45 != 1 ) /*0x108381c27*/
          goto LABEL_46; /*0x108381c27*/
        v21 = *((volatile signed __int64 **)&v44 + 1); /*0x108381c29*/
      }
      if ( v21 != nullptr && _InterlockedExchangeAdd64(v21 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x108381c42*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v21 + 16))(a1: v21); /*0x108381c4a*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v21); /*0x108381c50*/
      }
LABEL_46:
      v23 = v29[1]; /*0x108381c55*/
      if ( v29[1] != nullptr /*0x108381c71*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v29[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v23 + 16LL))(a1: v23); /*0x108381c79*/
        std::__shared_weak_count::__release_weak(this: v23); /*0x108381c7f*/
      }
      v24 = v50[1]; /*0x108381c84*/
      if ( v50[1] != nullptr /*0x108381c9d*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v50[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v24 + 16LL))(a1: v24); /*0x108381ca5*/
        std::__shared_weak_count::__release_weak(this: v24); /*0x108381cab*/
      }
    }
    v3 = (unsigned __int64)v6 + 1; /*0x108381cb0*/
    v5 = DFInt::TeamCreateFinalSaveRetryMax; /*0x108381cb4*/
    v25 = (__int64)v6 < DFInt::TeamCreateFinalSaveRetryMax; /*0x108381cbb*/
    v6 = (std::__shared_weak_count *)((char *)v6 + 1); /*0x108381cbe*/
    if ( !v25 ) /*0x108381cc1*/
      goto LABEL_53; /*0x108381cc1*/
  }
  LOBYTE(v11) = (unsigned __int8)DFLog::PlaceUpload < 6u || ((unsigned __int16)DFLog::PlaceUpload & 0xFC00) == 0; /*0x108381df5*/
  if ( (_BYTE)v11 == 0 ) /*0x108381df7*/
  {
    v29[0] = (std::__shared_weak_count *)HIDWORD(v12); /*0x108381e0c*/
    v30 = v6; /*0x108381e13*/
    v31 = (unsigned int)(DFInt::TeamCreateFinalSaveRetryMax + 1); /*0x108381e1a*/
    v50[0] = (std::__shared_weak_count *)273; /*0x108381e21*/
    v50[1] = (std::__shared_weak_count *)v29; /*0x108381e29*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x108381e4f*/
      a1: (_DWORD)DFLog::PlaceUpload,
      a2: qword_10D87DB70,
      a3: 4,
      a4: (unsigned int)"[DFLog::PlaceUpload] PlaceUploads::teamCreateFinalSaveWithRetries TeamCreate DataModel successfully "
                    "saved with place version number = {}, attempt {} of {}.",
      a5: 155,
      a6: 1,
      273,
      v29);
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v29, a2: "success", a3: v10, a4: v11); /*0x108381e65*/
  RBX::`anonymous namespace'::sendFinalSaveRetryOutcomeTelemetry(a1: v29, a2: (unsigned int)v6); /*0x108381e6f*/
  if ( ((__int64)v29[0] & 1) != 0 ) /*0x108381e7b*/
    operator delete(a1: (RBX::Memory *)v30, a2: v27); /*0x108381e84*/
  return 1; /*0x108381fb0*/
}

// Address: 0x10845db07 | Name: __ZN3RBX22tryGetIxpVariableValueIbEENSt3__18optionalIT_EERKNS1_12basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEESC_
__int64 __fastcall RBX::tryGetIxpVariableValue<bool>(RBX::Ixp::IxpController *a1, __int64 a2)
{
  __int64 v4; // r15
  __int64 v5; // rax
  __int64 v6; // rdi
  __int64 v7; // rbx
  __int64 v8; // r14
  unsigned __int16 v9; // r14
  unsigned __int16 v10; // r15
  std::__shared_weak_count *v11; // rbx
  __int128 v13; // [rsp+0h] [rbp-30h] BYREF

  v4 = RBX::Ixp::IxpController::instance(this: a1); /*0x10845db1f*/
  if ( ((*(__int64 (__fastcall **)(__int64, RBX::Ixp::IxpController *))(*(_QWORD *)v4 + 168LL))(a1: v4, a2: a1) /*0x10845db4b*/
      & 0x1FFFFFFFFLL) != 0x100000002LL )
    return 0; /*0x10845dbcc*/
  v13 = 0; /*0x10845db54*/
  if ( (*(unsigned __int8 (__fastcall **)(__int64, RBX::Ixp::IxpController *, __int128 *))(*(_QWORD *)v4 + 112LL))( /*0x10845db8c*/
         a1: v4,
         a2: a1,
         a3: &v13) != 0
    && (_QWORD)v13 != 0
    && (v5 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::find<std::string>(
               a1: v13,
               a2),
        v7 = v5,
        v5 != 0)
    && (v8 = *(_QWORD *)(v5 + 40), RBX::Reflection::Type::getSingleton<bool>(a1: v6) == v8) )
  {
    v9 = (unsigned __int8)RBX::Reflection::Variant::get<bool>(a1: (_QWORD *)(v7 + 40)); /*0x10845dbe5*/
    v10 = 256; /*0x10845dbe9*/
  }
  else
  {
    v9 = 0; /*0x10845db8e*/
    v10 = 0; /*0x10845db91*/
  }
  v11 = *((std::__shared_weak_count **)&v13 + 1); /*0x10845db94*/
  if ( *((_QWORD *)&v13 + 1) != 0 /*0x10845dbad*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v13 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(a1: v11); /*0x10845dbb5*/
    std::__shared_weak_count::__release_weak(this: v11); /*0x10845dbbb*/
  }
  return v9 | (unsigned int)v10; /*0x10845dbce*/
}

// Address: 0x10845dc0a | Name: __ZN3RBX26tryLogUserIxpLayerExposureERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
__int64 __fastcall RBX::tryLogUserIxpLayerExposure(RBX::Ixp::IxpController *a1)
{
  __int64 v2; // r14
  __int64 v3; // rcx
  __int64 result; // rax

  v2 = RBX::Ixp::IxpController::instance(this: a1); /*0x10845dc19*/
  v3 = (*(__int64 (__fastcall **)(__int64, RBX::Ixp::IxpController *))(*(_QWORD *)v2 + 168LL))(a1: v2, a2: a1) /*0x10845dc35*/
     & 0x1FFFFFFFFLL;
  result = 0x100000002LL; /*0x10845dc38*/
  if ( v3 == 0x100000002LL ) /*0x10845dc45*/
    return (*(__int64 (__fastcall **)(__int64, RBX::Ixp::IxpController *))(*(_QWORD *)v2 + 272LL))(a1: v2, a2: a1); /*0x10845dc5b*/
  return result; /*0x10845dc58*/
}

// Address: 0x10869d548 | Name: __ZN3RBX26TextFilterTranslatedResultaSERKS0_
__int64 __fastcall RBX::TextFilterTranslatedResult::operator=(__int64 a1, __int64 a2)
{
  *(_BYTE *)a1 = *(_BYTE *)a2; /*0x10869d557*/
  std::string::operator=(a1: a1 + 8, a2: a2 + 8); /*0x10869d561*/
  std::string::operator=(a1: a1 + 32, a2: a2 + 32); /*0x10869d56e*/
  RBX::TextFilterResult::operator=(a1: a1 + 56, a2: a2 + 56); /*0x10869d57b*/
  if ( a1 != a2 ) /*0x10869d583*/
  {
    *(_DWORD *)(a1 + 456) = *(_DWORD *)(a2 + 456); /*0x10869d595*/
    std::__hash_table<std::__hash_value_type<std::string,RBX::TextFilterResult>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::TextFilterResult>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::TextFilterResult>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::TextFilterResult>>>::__assign_multi<std::__hash_const_iterator<std::__hash_node<std::__hash_value_type<std::string,RBX::TextFilterResult>,void *> *>>( /*0x10869d5a6*/
      a1: a1 + 424,
      a2: *(_QWORD *)(a2 + 440),
      a3: 0);
  }
  *(_BYTE *)(a1 + 464) = *(_BYTE *)(a2 + 464); /*0x10869d5b2*/
  std::string::operator=(a1: a1 + 472, a2: a2 + 472); /*0x10869d5c4*/
  RBX::TextFilterResult::operator=(a1: a1 + 496, a2: a2 + 496); /*0x10869d5d5*/
  RBX::details::SplitHashTable<std::string,std::pair<std::string,RBX::TextFilterResult>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,RBX::TextFilterResult>>::copy_from<RBX::details::SplitHashTable<std::string,std::pair<std::string,RBX::TextFilterResult>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,RBX::TextFilterResult>>>( /*0x10869d5e6*/
    a1: a1 + 864,
    a2: a2 + 864);
  RBX::details::SplitHashTable<long long,long long,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<long long>,RBX::details::DefaultEqualTo<long long>,RBX::details::GetSelfKey<long long>>::copy_from<RBX::details::SplitHashTable<long long,long long,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<long long>,RBX::details::DefaultEqualTo<long long>,RBX::details::GetSelfKey<long long>>>( /*0x10869d5fa*/
    a1: a1 + 904,
    a2: a2 + 904);
  return a1; /*0x10869d602*/
}

// END _free_t part 1/1, 215 functions
