// _free_i -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 229 functions


// Address: 0x100045a50 | Name: __ZN3RBX28initMicroprofilerAssetReaderEb
__int64 __fastcall RBX::initMicroprofilerAssetReader(RBX *this)
{
  return RBX::Profiler::setAssetReaderCallback(a1: RBX::microprofilerAssetReaderTwoImpl); /*0x100045a5b*/
}

// Address: 0x100076d52 | Name: __ZN3RBXL31isLegacyContentIdPropertyStage1ERKNS_10Reflection18PropertyDescriptorE
bool __fastcall RBX::isLegacyContentIdPropertyStage1(RBX *this, const RBX::Reflection::PropertyDescriptor *a2)
{
  bool result; // al

  result = true; /*0x100076d5d*/
  if ( RBX::ImageButtonProperties::prop_Image != (_UNKNOWN *)this /*0x100076d92*/
    && RBX::ImageLabelProperties::prop_Image != (_UNKNOWN *)this
    && RBX::MeshPartProperties::prop_MeshId != (_UNKNOWN *)this
    && RBX::MeshPartProperties::prop_TextureID != (_UNKNOWN *)this
    && RBX::BaseWrapProperties::prop_CageMeshId != (_UNKNOWN *)this )
  {
    return RBX::WrapLayerProperties::prop_ReferenceMeshId == (_UNKNOWN *)this; /*0x100076d9e*/
  }
  return result; /*0x100076da1*/
}

// Address: 0x10010d044 | Name: __ZN3RBX20insertMagicInstancesEPNS_8InstanceENSt3__16vectorINS2_10shared_ptrIS0_EENS2_9allocatorIS5_EEEE
__int64 *__fastcall RBX::insertMagicInstances(__int64 *a1, RBX::ServiceProvider *a2, __int64 *a3)
{
  __int64 v3; // r15
  RBX::Sky *v4; // r13
  volatile signed __int64 *v5; // rbx
  __int64 v6; // r14
  __int64 v7; // rax
  const RBX::Instance *v8; // rsi
  __int64 v9; // r14
  __int64 v10; // rax
  const RBX::Instance *v11; // rsi
  __int64 v12; // r14
  __int64 v13; // rax
  const RBX::Instance *v14; // rsi
  __int64 v15; // r14
  __int64 v16; // rax
  __int64 v17; // rsi
  RBX::SpawnLocation *v18; // rdx
  RBX::Sky **v19; // r14
  unsigned __int64 v20; // rax
  __int64 v21; // r14
  _QWORD *v22; // rdi
  __int64 v23; // rax
  __int64 v24; // rsi
  RBX::ServiceProvider *ServiceProvider; // rax
  RBX::Lighting *v26; // rax
  RBX::ServiceProvider *v27; // rax
  RBX::Lighting *v28; // rax
  RBX::ServiceProvider *v29; // rax
  RBX::Instance *v30; // rax
  unsigned __int64 v31; // rax
  _QWORD *v32; // r14
  __int64 *v33; // rbx
  __int64 v34; // rax
  __int64 v35; // rdx
  __int64 v36; // r12
  __int64 v37; // r14
  __int64 v38; // r12
  size_t v39; // rdx
  void *v40; // r12
  __int64 v41; // rax
  __int64 v42; // rcx
  __int64 v43; // rdx
  __int64 v44; // rsi
  __int64 v45; // r8
  __int64 v46; // r9
  __int64 v48; // [rsp+0h] [rbp-80h]
  RBX::Sky *v49; // [rsp+8h] [rbp-78h]
  volatile signed __int64 *v50; // [rsp+10h] [rbp-70h]
  _QWORD *v51; // [rsp+18h] [rbp-68h]
  _QWORD v52[3]; // [rsp+20h] [rbp-60h] BYREF
  __int64 v53; // [rsp+38h] [rbp-48h]
  _QWORD *v54; // [rsp+40h] [rbp-40h]
  RBX::ServiceProvider *v55; // [rsp+48h] [rbp-38h]
  __int64 *v56; // [rsp+50h] [rbp-30h]

  v55 = a2; /*0x10010d055*/
  *(_OWORD *)a1 = 0; /*0x10010d05c*/
  v56 = a1; /*0x10010d05f*/
  a1[2] = 0; /*0x10010d063*/
  v3 = *a3; /*0x10010d06b*/
  v48 = a3[1]; /*0x10010d072*/
  if ( *a3 != v48 ) /*0x10010d079*/
  {
    v51 = v56 + 2; /*0x10010d087*/
    do /*0x10010d08b*/
    {
      v4 = *(RBX::Sky **)v3; /*0x10010d08b*/
      v49 = *(RBX::Sky **)v3; /*0x10010d08e*/
      v5 = *(volatile signed __int64 **)(v3 + 8); /*0x10010d092*/
      v50 = v5; /*0x10010d096*/
      if ( v5 != nullptr ) /*0x10010d09d*/
        _InterlockedIncrement64(v5 + 1); /*0x10010d09f*/
      v6 = *((_QWORD *)v4 + 3); /*0x10010d0a4*/
      v7 = RBX::Reflection::Class_getDescriptorPtr<RBX::Sky>(); /*0x10010d0a8*/
      if ( *(unsigned __int16 *)(v6 + 440) - (unsigned int)*(unsigned __int16 *)(v7 + 440) <= *(unsigned __int16 *)(v7 + 442) ) /*0x10010d0c7*/
      {
        ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v55, a2: v8); /*0x10010d1bf*/
        if ( ServiceProvider != nullptr ) /*0x10010d1c7*/
          v26 = (RBX::Lighting *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::Lighting>(this: ServiceProvider); /*0x10010d1cc*/
        else
          v26 = nullptr; /*0x10010d1eb*/
        RBX::Lighting::replaceSky(this: v26, a2: v4); /*0x10010d1f3*/
      }
      else
      {
        v9 = *((_QWORD *)v4 + 3); /*0x10010d0cd*/
        v10 = RBX::Reflection::Class_getDescriptorPtr<RBX::Atmosphere>(); /*0x10010d0d1*/
        if ( *(unsigned __int16 *)(v9 + 440) - (unsigned int)*(unsigned __int16 *)(v10 + 440) <= *(unsigned __int16 *)(v10 + 442) ) /*0x10010d0f0*/
        {
          v27 = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v55, a2: v11); /*0x10010d1d7*/
          if ( v27 != nullptr ) /*0x10010d1df*/
            v28 = (RBX::Lighting *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::Lighting>(this: v27); /*0x10010d1e4*/
          else
            v28 = nullptr; /*0x10010d215*/
          RBX::Lighting::replaceAtmosphere(this: v28, a2: v4); /*0x10010d21d*/
        }
        else
        {
          v12 = *((_QWORD *)v4 + 3); /*0x10010d0f6*/
          v13 = RBX::Reflection::Class_getDescriptorPtr<RBX::Team>(); /*0x10010d0fa*/
          if ( *(unsigned __int16 *)(v12 + 440) - (unsigned int)*(unsigned __int16 *)(v13 + 440) > *(unsigned __int16 *)(v13 + 442) ) /*0x10010d119*/
          {
            v15 = *((_QWORD *)v4 + 3); /*0x10010d11f*/
            v16 = RBX::Reflection::Class_getDescriptorPtr<RBX::SpawnLocation>(); /*0x10010d123*/
            v18 = (RBX::SpawnLocation *)*(unsigned __int16 *)(v16 + 440); /*0x10010d130*/
            if ( *(unsigned __int16 *)(v15 + 440) - (unsigned int)v18 <= *(unsigned __int16 *)(v16 + 442) ) /*0x10010d142*/
            {
              RBX::createTeamForSpawnLocationIfNeeded(this: v55, a2: v4, a3: v18); /*0x10010d22e*/
              v19 = (RBX::Sky **)v56[1]; /*0x10010d237*/
              v31 = v56[2]; /*0x10010d23b*/
              if ( (unsigned __int64)v19 < v31 ) /*0x10010d242*/
                goto LABEL_28; /*0x10010d242*/
              v21 = ((__int64)v19 - *v56) >> 4; /*0x10010d27a*/
              v22 = v51; /*0x10010d28f*/
              if ( (unsigned __int64)(v21 + 1) > 0xFFFFFFFFFFFFFFFLL ) /*0x10010d293*/
LABEL_50:
                std::vector<std::shared_ptr<RBX::Instance>>::__throw_length_error[abi:ne200100](a1: v22, a2: v17); /*0x10010d398*/
              v34 = v31 - *v56; /*0x10010d299*/
              v24 = v34 >> 3; /*0x10010d29f*/
              if ( v34 >> 3 <= (unsigned __int64)(v21 + 1) ) /*0x10010d2a6*/
                v24 = v21 + 1; /*0x10010d2a6*/
              if ( (unsigned __int64)v34 >= 0x7FFFFFFFFFFFFFF0LL ) /*0x10010d2b7*/
                v24 = 0xFFFFFFFFFFFFFFFLL; /*0x10010d2b7*/
              v54 = v51; /*0x10010d2bb*/
              if ( v24 == 0 ) /*0x10010d2c2*/
                goto LABEL_40; /*0x10010d2c2*/
LABEL_39:
              v36 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::shared_ptr<RBX::Instance>>>( /*0x10010d2c4*/
                      a1: v22,
                      a2: v24);
LABEL_41:
              v37 = 16 * v21; /*0x10010d2d3*/
              v53 = v36 + 16 * v35; /*0x10010d2de*/
              *(_QWORD *)(v36 + v37) = v4; /*0x10010d2e2*/
              *(_QWORD *)(v36 + v37 + 8) = v5; /*0x10010d2e6*/
              if ( v5 != nullptr ) /*0x10010d2ee*/
                _InterlockedIncrement64(v5 + 1); /*0x10010d2f0*/
              v38 = v37 + v36; /*0x10010d2f5*/
              v32 = (_QWORD *)(v38 + 16); /*0x10010d2f8*/
              v33 = v56; /*0x10010d2fd*/
              v39 = v56[1] - *v56; /*0x10010d308*/
              v40 = (void *)(v38 - v39); /*0x10010d30b*/
              memcpy(__dst: v40, __src: (const void *)*v56, __n: v39); /*0x10010d311*/
              v41 = *v33; /*0x10010d316*/
              *v33 = (__int64)v40; /*0x10010d319*/
              v52[1] = v41; /*0x10010d31c*/
              v33[1] = (__int64)v32; /*0x10010d320*/
              v52[2] = v41; /*0x10010d324*/
              v42 = v33[2]; /*0x10010d328*/
              v43 = v53; /*0x10010d32c*/
              v33[2] = v53; /*0x10010d330*/
              v53 = v42; /*0x10010d334*/
              v52[0] = v41; /*0x10010d338*/
              ((void (__fastcall *)(_QWORD *, __int64, __int64, __int64, __int64, __int64, __int64, RBX::Sky *, volatile signed __int64 *, _QWORD *))std::__split_buffer<std::shared_ptr<RBX::Instance>>::~__split_buffer)( /*0x10010d340*/
                a1: v52,
                a2: v44,
                a3: v43,
                a4: v42,
                a5: v45,
                a6: v46,
                a7: v48,
                a8: v49,
                a9: v50,
                a10: v51);
            }
            else
            {
              v19 = (RBX::Sky **)v56[1]; /*0x10010d14c*/
              v20 = v56[2]; /*0x10010d150*/
              if ( (unsigned __int64)v19 >= v20 ) /*0x10010d157*/
              {
                v21 = ((__int64)v19 - *v56) >> 4; /*0x10010d163*/
                v22 = v51; /*0x10010d178*/
                if ( (unsigned __int64)(v21 + 1) > 0xFFFFFFFFFFFFFFFLL ) /*0x10010d17c*/
                  goto LABEL_50; /*0x10010d17c*/
                v23 = v20 - *v56; /*0x10010d182*/
                v24 = v23 >> 3; /*0x10010d188*/
                if ( v23 >> 3 <= (unsigned __int64)(v21 + 1) ) /*0x10010d18f*/
                  v24 = v21 + 1; /*0x10010d18f*/
                if ( (unsigned __int64)v23 >= 0x7FFFFFFFFFFFFFF0LL ) /*0x10010d1a0*/
                  v24 = 0xFFFFFFFFFFFFFFFLL; /*0x10010d1a0*/
                v54 = v51; /*0x10010d1a4*/
                if ( v24 != 0 ) /*0x10010d1ab*/
                  goto LABEL_39; /*0x10010d1ab*/
LABEL_40:
                v36 = 0; /*0x10010d2ce*/
                v35 = 0; /*0x10010d2d1*/
                goto LABEL_41; /*0x10010d2d1*/
              }
LABEL_28:
              *v19 = v4; /*0x10010d244*/
              v19[1] = (RBX::Sky *)v5; /*0x10010d247*/
              if ( v5 != nullptr ) /*0x10010d24e*/
                _InterlockedIncrement64(v5 + 1); /*0x10010d250*/
              v32 = v19 + 2; /*0x10010d255*/
              v33 = v56; /*0x10010d259*/
            }
            v33[1] = (__int64)v32; /*0x10010d345*/
            goto LABEL_45; /*0x10010d345*/
          }
          v29 = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v55, a2: v14); /*0x10010d201*/
          if ( v29 != nullptr ) /*0x10010d209*/
            v30 = (RBX::Instance *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::Teams>(this: v29); /*0x10010d20e*/
          else
            v30 = nullptr; /*0x10010d262*/
          RBX::Instance::setParent(this: v4, a2: v30); /*0x10010d26a*/
        }
      }
LABEL_45:
      if ( v50 != nullptr && _InterlockedExchangeAdd64(v50 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10010d363*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v50 + 16))(a1: v50); /*0x10010d36c*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v50); /*0x10010d372*/
      }
      v3 += 16; /*0x10010d377*/
    }
    while ( v3 != v48 ); /*0x10010d08b*/
  }
  return v56; /*0x10010d389*/
}

// Address: 0x1001f0b86 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E20SubscriptionContractINSt3__18functionIFbRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEESE_EEEED1Ev
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::SubscriptionContract<std::function<bool ()(std::string const&,std::string const&)>>::~SubscriptionContract(
        __int64 a1,
        void *a2)
{
  _QWORD *v3; // rax
  _QWORD *v4; // rdi
  __int64 v5; // rax

  v3 = (_QWORD *)(a1 + 64); /*0x1001f0b8f*/
  v4 = *(_QWORD **)(a1 + 96); /*0x1001f0b93*/
  if ( v4 == v3 ) /*0x1001f0b9a*/
  {
    v5 = 32; /*0x1001f0ba8*/
  }
  else
  {
    v5 = 40; /*0x1001f0b9c*/
    if ( v4 == nullptr ) /*0x1001f0ba4*/
      goto LABEL_6; /*0x1001f0ba4*/
  }
  (*(void (__fastcall **)(_QWORD *))(*v4 + v5))(a1: v4); /*0x1001f0bb0*/
LABEL_6:
  if ( *(_BYTE *)(a1 + 48) == 1 && (*(_BYTE *)(a1 + 24) & 1) != 0 ) /*0x1001f0bbd*/
    operator delete(a1: *(RBX::Memory **)(a1 + 40), a2); /*0x1001f0bc3*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1001f0bcb*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x1001f0bde*/
}

// Address: 0x1001f101e | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E20SubscriptionContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS6_IFvbEEEEEEED1Ev
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::SubscriptionContract<std::function<void ()(std::string const&,std::function<void ()(bool)>)>>::~SubscriptionContract(
        __int64 a1,
        void *a2)
{
  _QWORD *v3; // rax
  _QWORD *v4; // rdi
  __int64 v5; // rax

  v3 = (_QWORD *)(a1 + 64); /*0x1001f1027*/
  v4 = *(_QWORD **)(a1 + 96); /*0x1001f102b*/
  if ( v4 == v3 ) /*0x1001f1032*/
  {
    v5 = 32; /*0x1001f1040*/
  }
  else
  {
    v5 = 40; /*0x1001f1034*/
    if ( v4 == nullptr ) /*0x1001f103c*/
      goto LABEL_6; /*0x1001f103c*/
  }
  (*(void (__fastcall **)(_QWORD *))(*v4 + v5))(a1: v4); /*0x1001f1048*/
LABEL_6:
  if ( *(_BYTE *)(a1 + 48) == 1 && (*(_BYTE *)(a1 + 24) & 1) != 0 ) /*0x1001f1055*/
    operator delete(a1: *(RBX::Memory **)(a1 + 40), a2); /*0x1001f105b*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1001f1063*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x1001f1076*/
}

// Address: 0x1001f1b12 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E20SubscriptionContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEESE_RKNS6_IFvbEEEEEEED1Ev
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::SubscriptionContract<std::function<void ()(std::string const&,std::string const&,std::function<void ()(bool)> const&)>>::~SubscriptionContract(
        __int64 a1,
        void *a2)
{
  _QWORD *v3; // rax
  _QWORD *v4; // rdi
  __int64 v5; // rax

  v3 = (_QWORD *)(a1 + 64); /*0x1001f1b1b*/
  v4 = *(_QWORD **)(a1 + 96); /*0x1001f1b1f*/
  if ( v4 == v3 ) /*0x1001f1b26*/
  {
    v5 = 32; /*0x1001f1b34*/
  }
  else
  {
    v5 = 40; /*0x1001f1b28*/
    if ( v4 == nullptr ) /*0x1001f1b30*/
      goto LABEL_6; /*0x1001f1b30*/
  }
  (*(void (__fastcall **)(_QWORD *))(*v4 + v5))(a1: v4); /*0x1001f1b3c*/
LABEL_6:
  if ( *(_BYTE *)(a1 + 48) == 1 && (*(_BYTE *)(a1 + 24) & 1) != 0 ) /*0x1001f1b49*/
    operator delete(a1: *(RBX::Memory **)(a1 + 40), a2); /*0x1001f1b4f*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1001f1b57*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x1001f1b6a*/
}

// Address: 0x1001f552e | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS6_IFvbEEEEEESC_ED1Ev
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<void ()(std::string const&,std::function<void ()(bool)>)>,std::string>::~MakeRequestContract(
        __int64 a1)
{
  _QWORD *v2; // rax
  _QWORD *v3; // rdi
  __int64 v4; // rax
  void *v5; // rsi

  v2 = (_QWORD *)(a1 + 64); /*0x1001f5537*/
  v3 = *(_QWORD **)(a1 + 96); /*0x1001f553b*/
  if ( v3 == v2 ) /*0x1001f5542*/
  {
    v4 = 32; /*0x1001f5550*/
    goto LABEL_5; /*0x1001f5550*/
  }
  v4 = 40; /*0x1001f5544*/
  if ( v3 != nullptr ) /*0x1001f554c*/
LABEL_5:
    (*(void (__fastcall **)(_QWORD *))(*v3 + v4))(a1: v3); /*0x1001f5555*/
  std::shared_ptr<std::string const>::~shared_ptr[abi:ne200100](a1: a1 + 48); /*0x1001f555b*/
  if ( (*(_BYTE *)(a1 + 24) & 1) != 0 ) /*0x1001f5568*/
    operator delete(a1: *(RBX::Memory **)(a1 + 40), a2: v5); /*0x1001f556e*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1001f5576*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2: v5); /*0x1001f5589*/
}

// Address: 0x1001f8750 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E22RequestHandlerContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS6_IFvSE_EEEEEEED1Ev
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::RequestHandlerContract<std::function<void ()(std::string const&,std::function<void ()(std::string const&)>)>>::~RequestHandlerContract(
        __int64 a1,
        void *a2)
{
  _QWORD *v3; // rax
  _QWORD *v4; // rdi
  __int64 v5; // rax

  v3 = (_QWORD *)(a1 + 48); /*0x1001f8759*/
  v4 = *(_QWORD **)(a1 + 80); /*0x1001f875d*/
  if ( v4 == v3 ) /*0x1001f8764*/
  {
    v5 = 32; /*0x1001f8772*/
    goto LABEL_5; /*0x1001f8772*/
  }
  v5 = 40; /*0x1001f8766*/
  if ( v4 != nullptr ) /*0x1001f876e*/
LABEL_5:
    (*(void (__fastcall **)(_QWORD *))(*v4 + v5))(a1: v4); /*0x1001f8777*/
  if ( (*(_BYTE *)(a1 + 24) & 1) != 0 ) /*0x1001f8781*/
    operator delete(a1: *(RBX::Memory **)(a1 + 40), a2); /*0x1001f8787*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1001f878f*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x1001f87a2*/
}

// Address: 0x1001f8f62 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFbNS5_10shared_ptrIKS2_EEEEES2_EC2ERKSC_
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<bool ()(std::shared_ptr<RBX::json::Document const>)>,RBX::json::Document>::MakeRequestContract(
        __int64 a1,
        __int64 a2)
{
  __int64 v4; // rax

  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1001f8f76*/
  {
    std::string::__init_copy_ctor_external(a1, a2: *(_QWORD *)(a2 + 16), a3: *(_QWORD *)(a2 + 8)); /*0x1001f8f94*/
  }
  else
  {
    *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1001f8f7c*/
    *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1001f8f84*/
  }
  if ( (*(_BYTE *)(a2 + 24) & 1) != 0 ) /*0x1001f8fa2*/
  {
    std::string::__init_copy_ctor_external(a1: a1 + 24, a2: *(_QWORD *)(a2 + 40), a3: *(_QWORD *)(a2 + 32)); /*0x1001f8fc4*/
  }
  else
  {
    *(_QWORD *)(a1 + 40) = *(_QWORD *)(a2 + 40); /*0x1001f8fac*/
    *(_OWORD *)(a1 + 24) = *(_OWORD *)(a2 + 24); /*0x1001f8fb3*/
  }
  v4 = *(_QWORD *)(a2 + 56); /*0x1001f8fc9*/
  *(_OWORD *)(a1 + 48) = *(_OWORD *)(a2 + 48); /*0x1001f8fd2*/
  if ( v4 != 0 ) /*0x1001f8fd9*/
    _InterlockedIncrement64((volatile signed __int64 *)(v4 + 8)); /*0x1001f8fdb*/
  return std::__function::__value_func<bool ()(std::shared_ptr<RBX::json::Document const>)>::__value_func[abi:ne200100]( /*0x1001f8ff4*/
           a1: a1 + 64,
           a2: a2 + 64);
}

// Address: 0x1001f9102 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFvNS5_10shared_ptrIKS2_EENS6_IFvbEEEEEES2_EC2ERKSE_
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<void ()(std::shared_ptr<RBX::json::Document const>,std::function<void ()(bool)>)>,RBX::json::Document>::MakeRequestContract(
        __int64 a1,
        __int64 a2)
{
  __int64 v4; // rax

  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1001f9116*/
  {
    std::string::__init_copy_ctor_external(a1, a2: *(_QWORD *)(a2 + 16), a3: *(_QWORD *)(a2 + 8)); /*0x1001f9134*/
  }
  else
  {
    *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1001f911c*/
    *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1001f9124*/
  }
  if ( (*(_BYTE *)(a2 + 24) & 1) != 0 ) /*0x1001f9142*/
  {
    std::string::__init_copy_ctor_external(a1: a1 + 24, a2: *(_QWORD *)(a2 + 40), a3: *(_QWORD *)(a2 + 32)); /*0x1001f9164*/
  }
  else
  {
    *(_QWORD *)(a1 + 40) = *(_QWORD *)(a2 + 40); /*0x1001f914c*/
    *(_OWORD *)(a1 + 24) = *(_OWORD *)(a2 + 24); /*0x1001f9153*/
  }
  v4 = *(_QWORD *)(a2 + 56); /*0x1001f9169*/
  *(_OWORD *)(a1 + 48) = *(_OWORD *)(a2 + 48); /*0x1001f9172*/
  if ( v4 != 0 ) /*0x1001f9179*/
    _InterlockedIncrement64((volatile signed __int64 *)(v4 + 8)); /*0x1001f917b*/
  return std::__function::__value_func<void ()(std::shared_ptr<RBX::json::Document const>,std::function<void ()(bool)>)>::__value_func[abi:ne200100]( /*0x1001f9194*/
           a1: a1 + 64,
           a2: a2 + 64);
}

// Address: 0x1001f91d2 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS6_IFvbEEEEEESC_EC2ERKSJ_
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<void ()(std::string const&,std::function<void ()(bool)>)>,std::string>::MakeRequestContract(
        __int64 a1,
        __int64 a2)
{
  __int64 v4; // rax

  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1001f91e6*/
  {
    std::string::__init_copy_ctor_external(a1, a2: *(_QWORD *)(a2 + 16), a3: *(_QWORD *)(a2 + 8)); /*0x1001f9204*/
  }
  else
  {
    *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1001f91ec*/
    *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1001f91f4*/
  }
  if ( (*(_BYTE *)(a2 + 24) & 1) != 0 ) /*0x1001f9212*/
  {
    std::string::__init_copy_ctor_external(a1: a1 + 24, a2: *(_QWORD *)(a2 + 40), a3: *(_QWORD *)(a2 + 32)); /*0x1001f9234*/
  }
  else
  {
    *(_QWORD *)(a1 + 40) = *(_QWORD *)(a2 + 40); /*0x1001f921c*/
    *(_OWORD *)(a1 + 24) = *(_OWORD *)(a2 + 24); /*0x1001f9223*/
  }
  v4 = *(_QWORD *)(a2 + 56); /*0x1001f9239*/
  *(_OWORD *)(a1 + 48) = *(_OWORD *)(a2 + 48); /*0x1001f9242*/
  if ( v4 != 0 ) /*0x1001f9249*/
    _InterlockedIncrement64((volatile signed __int64 *)(v4 + 8)); /*0x1001f924b*/
  return std::__function::__value_func<void ()(std::string const&,std::function<void ()(bool)>)>::__value_func[abi:ne200100]( /*0x1001f9264*/
           a1: a1 + 64,
           a2: a2 + 64);
}

// Address: 0x1001fa5e0 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E20SubscriptionContractINSt3__18functionIFbRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEESE_EEEEC2ESC_SG_RKNS5_8optionalISC_EEbb
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::SubscriptionContract<std::function<bool ()(std::string const&,std::string const&)>>::SubscriptionContract(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        char a5,
        char a6)
{
  __int64 result; // rax

  *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1001fa5fe*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1001fa605*/
  *(_OWORD *)a2 = 0; /*0x1001fa60b*/
  *(_QWORD *)(a2 + 16) = 0; /*0x1001fa60e*/
  std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: a1 + 24, a2: a4); /*0x1001fa620*/
  result = std::__function::__value_func<bool ()(std::string const&,std::string const&)>::__value_func[abi:ne200100]( /*0x1001fa62c*/
             a1: a1 + 64,
             a2: a3);
  *(_BYTE *)(a1 + 112) = a5; /*0x1001fa631*/
  *(_BYTE *)(a1 + 113) = a6; /*0x1001fa635*/
  return result; /*0x1001fa63d*/
}

// Address: 0x1001fab26 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E20SubscriptionContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS6_IFvbEEEEEEEC2ESC_SI_RKNS5_8optionalISC_EEbb
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::SubscriptionContract<std::function<void ()(std::string const&,std::function<void ()(bool)>)>>::SubscriptionContract(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        char a5,
        char a6)
{
  __int64 result; // rax

  *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1001fab44*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1001fab4b*/
  *(_OWORD *)a2 = 0; /*0x1001fab51*/
  *(_QWORD *)(a2 + 16) = 0; /*0x1001fab54*/
  std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: a1 + 24, a2: a4); /*0x1001fab66*/
  result = std::__function::__value_func<void ()(std::string const&,std::function<void ()(bool)>)>::__value_func[abi:ne200100]( /*0x1001fab72*/
             a1: a1 + 64,
             a2: a3);
  *(_BYTE *)(a1 + 112) = a5; /*0x1001fab77*/
  *(_BYTE *)(a1 + 113) = a6; /*0x1001fab7b*/
  return result; /*0x1001fab83*/
}

// Address: 0x1001fb002 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E20SubscriptionContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEESE_RKNS6_IFvbEEEEEEEC2ESC_SK_RKNS5_8optionalISC_EEbb
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::SubscriptionContract<std::function<void ()(std::string const&,std::string const&,std::function<void ()(bool)> const&)>>::SubscriptionContract(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        char a5,
        char a6)
{
  __int64 result; // rax

  *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1001fb020*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1001fb027*/
  *(_OWORD *)a2 = 0; /*0x1001fb02d*/
  *(_QWORD *)(a2 + 16) = 0; /*0x1001fb030*/
  std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: a1 + 24, a2: a4); /*0x1001fb042*/
  result = std::__function::__value_func<void ()(std::string const&,std::string const&,std::function<void ()(bool)> const&)>::__value_func[abi:ne200100]( /*0x1001fb04e*/
             a1: a1 + 64,
             a2: a3);
  *(_BYTE *)(a1 + 112) = a5; /*0x1001fb053*/
  *(_BYTE *)(a1 + 113) = a6; /*0x1001fb057*/
  return result; /*0x1001fb05f*/
}

// Address: 0x1001fd782 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFbNS5_10shared_ptrIKS2_EEEEES2_EC2EOSC_
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<bool ()(std::shared_ptr<RBX::json::Document const>)>,RBX::json::Document>::MakeRequestContract(
        __int64 a1,
        __int64 a2)
{
  __int64 v4; // rax

  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1001fd796*/
  {
    std::string::__init_copy_ctor_external(a1, a2: *(_QWORD *)(a2 + 16), a3: *(_QWORD *)(a2 + 8)); /*0x1001fd7b4*/
  }
  else
  {
    *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1001fd79c*/
    *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1001fd7a4*/
  }
  if ( (*(_BYTE *)(a2 + 24) & 1) != 0 ) /*0x1001fd7c2*/
  {
    std::string::__init_copy_ctor_external(a1: a1 + 24, a2: *(_QWORD *)(a2 + 40), a3: *(_QWORD *)(a2 + 32)); /*0x1001fd7e4*/
  }
  else
  {
    *(_QWORD *)(a1 + 40) = *(_QWORD *)(a2 + 40); /*0x1001fd7cc*/
    *(_OWORD *)(a1 + 24) = *(_OWORD *)(a2 + 24); /*0x1001fd7d3*/
  }
  v4 = *(_QWORD *)(a2 + 56); /*0x1001fd7e9*/
  *(_OWORD *)(a1 + 48) = *(_OWORD *)(a2 + 48); /*0x1001fd7f2*/
  if ( v4 != 0 ) /*0x1001fd7f9*/
    _InterlockedIncrement64((volatile signed __int64 *)(v4 + 8)); /*0x1001fd7fb*/
  return std::__function::__value_func<bool ()(std::shared_ptr<RBX::json::Document const>)>::__value_func[abi:ne200100]( /*0x1001fd814*/
           a1: a1 + 64,
           a2: a2 + 64);
}

// Address: 0x1001fe3a8 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFvNS5_10shared_ptrIKS2_EENS6_IFvbEEEEEES2_EC2EOSE_
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<void ()(std::shared_ptr<RBX::json::Document const>,std::function<void ()(bool)>)>,RBX::json::Document>::MakeRequestContract(
        __int64 a1,
        __int64 a2)
{
  __int64 v4; // rax

  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1001fe3bc*/
  {
    std::string::__init_copy_ctor_external(a1, a2: *(_QWORD *)(a2 + 16), a3: *(_QWORD *)(a2 + 8)); /*0x1001fe3da*/
  }
  else
  {
    *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1001fe3c2*/
    *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1001fe3ca*/
  }
  if ( (*(_BYTE *)(a2 + 24) & 1) != 0 ) /*0x1001fe3e8*/
  {
    std::string::__init_copy_ctor_external(a1: a1 + 24, a2: *(_QWORD *)(a2 + 40), a3: *(_QWORD *)(a2 + 32)); /*0x1001fe40a*/
  }
  else
  {
    *(_QWORD *)(a1 + 40) = *(_QWORD *)(a2 + 40); /*0x1001fe3f2*/
    *(_OWORD *)(a1 + 24) = *(_OWORD *)(a2 + 24); /*0x1001fe3f9*/
  }
  v4 = *(_QWORD *)(a2 + 56); /*0x1001fe40f*/
  *(_OWORD *)(a1 + 48) = *(_OWORD *)(a2 + 48); /*0x1001fe418*/
  if ( v4 != 0 ) /*0x1001fe41f*/
    _InterlockedIncrement64((volatile signed __int64 *)(v4 + 8)); /*0x1001fe421*/
  return std::__function::__value_func<void ()(std::shared_ptr<RBX::json::Document const>,std::function<void ()(bool)>)>::__value_func[abi:ne200100]( /*0x1001fe43a*/
           a1: a1 + 64,
           a2: a2 + 64);
}

// Address: 0x1001fe4d8 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS6_IFvbEEEEEESC_EC2ESC_SC_NS5_10shared_ptrISD_EESI_
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<void ()(std::string const&,std::function<void ()(bool)>)>,std::string>::MakeRequestContract(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5)
{
  __int64 v5; // rax

  *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1001fe4ea*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1001fe4f1*/
  *(_OWORD *)a2 = 0; /*0x1001fe4f7*/
  *(_QWORD *)(a2 + 16) = 0; /*0x1001fe4fc*/
  *(_QWORD *)(a1 + 40) = *(_QWORD *)(a3 + 16); /*0x1001fe504*/
  *(_OWORD *)(a1 + 24) = *(_OWORD *)a3; /*0x1001fe50b*/
  *(_OWORD *)a3 = 0; /*0x1001fe50f*/
  *(_QWORD *)(a3 + 16) = 0; /*0x1001fe512*/
  v5 = *(_QWORD *)(a4 + 8); /*0x1001fe516*/
  *(_OWORD *)(a1 + 48) = *(_OWORD *)a4; /*0x1001fe51d*/
  if ( v5 != 0 ) /*0x1001fe524*/
    _InterlockedIncrement64((volatile signed __int64 *)(v5 + 8)); /*0x1001fe526*/
  return std::__function::__value_func<void ()(std::string const&,std::function<void ()(bool)>)>::__value_func[abi:ne200100]( /*0x1001fe53f*/
           a1: a1 + 64,
           a2: a5);
}

// Address: 0x1001fed72 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS6_IFvbEEEEEESC_EC2EOSJ_
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<void ()(std::string const&,std::function<void ()(bool)>)>,std::string>::MakeRequestContract(
        __int64 a1,
        __int64 a2)
{
  __int64 v4; // rax

  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1001fed86*/
  {
    std::string::__init_copy_ctor_external(a1, a2: *(_QWORD *)(a2 + 16), a3: *(_QWORD *)(a2 + 8)); /*0x1001feda4*/
  }
  else
  {
    *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1001fed8c*/
    *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1001fed94*/
  }
  if ( (*(_BYTE *)(a2 + 24) & 1) != 0 ) /*0x1001fedb2*/
  {
    std::string::__init_copy_ctor_external(a1: a1 + 24, a2: *(_QWORD *)(a2 + 40), a3: *(_QWORD *)(a2 + 32)); /*0x1001fedd4*/
  }
  else
  {
    *(_QWORD *)(a1 + 40) = *(_QWORD *)(a2 + 40); /*0x1001fedbc*/
    *(_OWORD *)(a1 + 24) = *(_OWORD *)(a2 + 24); /*0x1001fedc3*/
  }
  v4 = *(_QWORD *)(a2 + 56); /*0x1001fedd9*/
  *(_OWORD *)(a1 + 48) = *(_OWORD *)(a2 + 48); /*0x1001fede2*/
  if ( v4 != 0 ) /*0x1001fede9*/
    _InterlockedIncrement64((volatile signed __int64 *)(v4 + 8)); /*0x1001fedeb*/
  return std::__function::__value_func<void ()(std::string const&,std::function<void ()(bool)>)>::__value_func[abi:ne200100]( /*0x1001fee04*/
           a1: a1 + 64,
           a2: a2 + 64);
}

// Address: 0x1002023d6 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E22RequestHandlerContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS6_IFvSE_EEEEEEEC2ESC_SC_SI_
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::RequestHandlerContract<std::function<void ()(std::string const&,std::function<void ()(std::string const&)>)>>::RequestHandlerContract(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x1002023e7*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1002023ee*/
  *(_OWORD *)a2 = 0; /*0x1002023f4*/
  *(_QWORD *)(a2 + 16) = 0; /*0x1002023f9*/
  *(_QWORD *)(a1 + 40) = *(_QWORD *)(a3 + 16); /*0x100202405*/
  *(_OWORD *)(a1 + 24) = *(_OWORD *)a3; /*0x10020240c*/
  *(_OWORD *)a3 = 0; /*0x100202410*/
  *(_QWORD *)(a3 + 16) = 0; /*0x100202413*/
  return std::__function::__value_func<void ()(std::string const&,std::function<void ()(std::string const&)>)>::__value_func[abi:ne200100]( /*0x100202427*/
           a1: a1 + 48,
           a2: a4);
}

// Address: 0x1002103ce | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E22RequestHandlerContractINSt3__18functionIFvNS5_10shared_ptrIKS2_EENS6_IFvNS7_IKNS3_21ResponseWithTelemetryEEEEEEEEEED1Ev
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::RequestHandlerContract<std::function<void ()(std::shared_ptr<RBX::json::Document const>,std::function<void ()(std::shared_ptr<RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::ResponseWithTelemetry const>)>)>>::~RequestHandlerContract(
        __int64 a1,
        void *a2)
{
  _QWORD *v3; // rax
  _QWORD *v4; // rdi
  __int64 v5; // rax

  v3 = (_QWORD *)(a1 + 48); /*0x1002103d7*/
  v4 = *(_QWORD **)(a1 + 80); /*0x1002103db*/
  if ( v4 == v3 ) /*0x1002103e2*/
  {
    v5 = 32; /*0x1002103f0*/
    goto LABEL_5; /*0x1002103f0*/
  }
  v5 = 40; /*0x1002103e4*/
  if ( v4 != nullptr ) /*0x1002103ec*/
LABEL_5:
    (*(void (__fastcall **)(_QWORD *))(*v4 + v5))(a1: v4); /*0x1002103f5*/
  if ( (*(_BYTE *)(a1 + 24) & 1) != 0 ) /*0x1002103ff*/
    operator delete(a1: *(RBX::Memory **)(a1 + 40), a2); /*0x100210405*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x10021040d*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x100210420*/
}

// Address: 0x100210692 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFbNS5_10shared_ptrIKS2_EEEEES2_ED1Ev
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<bool ()(std::shared_ptr<RBX::json::Document const>)>,RBX::json::Document>::~MakeRequestContract(
        __int64 a1)
{
  _QWORD *v2; // rax
  _QWORD *v3; // rdi
  __int64 v4; // rax
  void *v5; // rsi

  v2 = (_QWORD *)(a1 + 64); /*0x10021069b*/
  v3 = *(_QWORD **)(a1 + 96); /*0x10021069f*/
  if ( v3 == v2 ) /*0x1002106a6*/
  {
    v4 = 32; /*0x1002106b4*/
    goto LABEL_5; /*0x1002106b4*/
  }
  v4 = 40; /*0x1002106a8*/
  if ( v3 != nullptr ) /*0x1002106b0*/
LABEL_5:
    (*(void (__fastcall **)(_QWORD *))(*v3 + v4))(a1: v3); /*0x1002106b9*/
  std::shared_ptr<RBX::json::Document const>::~shared_ptr[abi:ne200100](a1: a1 + 48); /*0x1002106bf*/
  if ( (*(_BYTE *)(a1 + 24) & 1) != 0 ) /*0x1002106cc*/
    operator delete(a1: *(RBX::Memory **)(a1 + 40), a2: v5); /*0x1002106d2*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1002106da*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2: v5); /*0x1002106ed*/
}

// Address: 0x100210980 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFvNS5_10shared_ptrIKS2_EENS6_IFvbEEEEEES2_ED1Ev
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<void ()(std::shared_ptr<RBX::json::Document const>,std::function<void ()(bool)>)>,RBX::json::Document>::~MakeRequestContract(
        __int64 a1)
{
  _QWORD *v2; // rax
  _QWORD *v3; // rdi
  __int64 v4; // rax
  void *v5; // rsi

  v2 = (_QWORD *)(a1 + 64); /*0x100210989*/
  v3 = *(_QWORD **)(a1 + 96); /*0x10021098d*/
  if ( v3 == v2 ) /*0x100210994*/
  {
    v4 = 32; /*0x1002109a2*/
    goto LABEL_5; /*0x1002109a2*/
  }
  v4 = 40; /*0x100210996*/
  if ( v3 != nullptr ) /*0x10021099e*/
LABEL_5:
    (*(void (__fastcall **)(_QWORD *))(*v3 + v4))(a1: v3); /*0x1002109a7*/
  std::shared_ptr<RBX::json::Document const>::~shared_ptr[abi:ne200100](a1: a1 + 48); /*0x1002109ad*/
  if ( (*(_BYTE *)(a1 + 24) & 1) != 0 ) /*0x1002109ba*/
    operator delete(a1: *(RBX::Memory **)(a1 + 40), a2: v5); /*0x1002109c0*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1002109c8*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2: v5); /*0x1002109db*/
}

// Address: 0x100274110 | Name: __ZN3RBX10IndexArrayINS_9Collision7ContactEXadL_ZNS2_27getContactManagerSleepIndexEvEEE20fastAppendIfNotExistEPS2_
__int64 __fastcall RBX::IndexArray<RBX::Collision::Contact,&RBX::Collision::Contact::getContactManagerSleepIndex>::fastAppendIfNotExist(
        _QWORD *a1,
        __int64 a2)
{
  __int64 result; // rax
  __int64 v3; // [rsp-10h] [rbp-10h] BYREF

  if ( *(int *)(a2 + 40) < 0 ) /*0x100274114*/
  {
    v3 = a2; /*0x100274123*/
    *(_DWORD *)(a2 + 40) = (a1[1] - *a1) >> 3; /*0x100274131*/
    return std::vector<RBX::Collision::Contact *,RSL::Detail::Allocator<RBX::Collision::Contact *>>::push_back[abi:ne200100]( /*0x100274137*/
             a1,
             a2: &v3);
  }
  return result; /*0x100274116*/
}

// Address: 0x1002742d2 | Name: __ZN3RBX10IndexArrayINS_9Collision7ContactEXadL_ZNS2_32getContactManagerTransitionIndexEvEEE20fastAppendIfNotExistEPS2_
__int64 __fastcall RBX::IndexArray<RBX::Collision::Contact,&RBX::Collision::Contact::getContactManagerTransitionIndex>::fastAppendIfNotExist(
        _QWORD *a1,
        __int64 a2)
{
  __int64 result; // rax
  __int64 v3; // [rsp-10h] [rbp-10h] BYREF

  if ( *(int *)(a2 + 36) < 0 ) /*0x1002742d6*/
  {
    v3 = a2; /*0x1002742e5*/
    *(_DWORD *)(a2 + 36) = (a1[1] - *a1) >> 3; /*0x1002742f3*/
    return std::vector<RBX::Collision::Contact *,RSL::Detail::Allocator<RBX::Collision::Contact *>>::push_back[abi:ne200100]( /*0x1002742f9*/
             a1,
             a2: &v3);
  }
  return result; /*0x1002742d8*/
}

// Address: 0x100274a28 | Name: __ZN3RBX10IndexArrayINS_9Collision7ContactEXadL_ZNS2_22getContactManagerIndexEvEEE20fastAppendIfNotExistEPS2_
__int64 __fastcall RBX::IndexArray<RBX::Collision::Contact,&RBX::Collision::Contact::getContactManagerIndex>::fastAppendIfNotExist(
        _QWORD *a1,
        __int64 a2)
{
  __int64 result; // rax
  __int64 v3; // [rsp-10h] [rbp-10h] BYREF

  if ( *(int *)(a2 + 32) < 0 ) /*0x100274a2c*/
  {
    v3 = a2; /*0x100274a3b*/
    *(_DWORD *)(a2 + 32) = (a1[1] - *a1) >> 3; /*0x100274a49*/
    return std::vector<RBX::Collision::Contact *,RSL::Detail::Allocator<RBX::Collision::Contact *>>::push_back[abi:ne200100]( /*0x100274a4f*/
             a1,
             a2: &v3);
  }
  return result; /*0x100274a2e*/
}

// Address: 0x1003aa8d0 | Name: __ZN3RBX24installHarfbuzzAllocatorEv
unsigned __int64 __fastcall RBX::installHarfbuzzAllocator(RBX *this)
{
  unsigned __int64 result; // rax
  __int64 (__fastcall *v2)(RBX *__hidden); // [rsp-18h] [rbp-18h] BYREF
  __int64 (__fastcall **v3)(RBX *__hidden); // [rsp-10h] [rbp-10h] BYREF

  result = RBX::installHarfbuzzAllocator(void)::flag; /*0x1003aa8d0*/
  if ( RBX::installHarfbuzzAllocator(void)::flag != -1 ) /*0x1003aa8db*/
  {
    v2 = RBX::installImpl; /*0x1003aa8f0*/
    v3 = &v2; /*0x1003aa8f7*/
    return std::__call_once( /*0x1003aa908*/
             a1: &RBX::installHarfbuzzAllocator(void)::flag,
             a2: &v3,
             a3: std::__call_once_proxy[abi:ne200100]<std::tuple<void (&)(void)>>);
  }
  return result; /*0x1003aa912*/
}

// Address: 0x1003aa913 | Name: __ZN3RBXL11installImplEv
__int64 __fastcall RBX::installImpl(RBX *this, __int64 a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6)
{
  return hb_set_allocator( /*0x1003aa95d*/
           a1: this,
           a2,
           a3,
           a4,
           a5,
           a6,
           a7: RBX::mallocOrCrashImpl,
           a8: RBX::callocOrCrashImpl,
           a9: RBX::reallocOrCrashImpl,
           a10: RBX::freeImpl,
           a11: RBX::mallocOrCrashImpl,
           a12: RBX::callocOrCrashImpl,
           a13: RBX::reallocOrCrashImpl,
           a14: RBX::freeImpl);
}

// Address: 0x100463ca4 | Name: __ZN3RBX15is_regular_fileERKNS_10CachedPathE
bool __fastcall RBX::is_regular_file(RBX *this, const RBX::CachedPath *a2)
{
  __int64 v3; // rax
  __int64 v4; // rax
  __int64 v5; // r14

  if ( FFlag::ProjectLoadingUseCachedPath != 0 ) /*0x100463cb8*/
  {
    v3 = RBX::PathCacheRepo::sharedInstance(this); /*0x100463cba*/
    v4 = RBX::SmallSplitHashMap<boost::filesystem::path,RBX::PathCache,0u,(RBX::SplitHashPolicy)9,RBX::PathHash,RBX::details::DefaultEqualTo<boost::filesystem::path>>::operator[]( /*0x100463cc5*/
           a1: v3,
           a2: this);
    v5 = v4; /*0x100463cca*/
    if ( *(_BYTE *)v4 == 1 ) /*0x100463cd0*/
    {
      LODWORD(v4) = *(_DWORD *)(v4 + 4); /*0x100463cd2*/
    }
    else
    {
      v4 = boost::filesystem::detail::status(this, a2: 0); /*0x100463ce9*/
      if ( *(_BYTE *)v5 == 0 ) /*0x100463cf2*/
        *(_BYTE *)v5 = 1; /*0x100463cf4*/
      *(_QWORD *)(v5 + 4) = v4; /*0x100463cf8*/
    }
  }
  else
  {
    LODWORD(v4) = boost::filesystem::detail::status(this, a2: 0); /*0x100463cdd*/
  }
  return (_DWORD)v4 == 2; /*0x100463d02*/
}

// Address: 0x100c99509 | Name: __ZN3RBX26isPartFromAssemblySelectedERNS_8BasePartEPNS_8AssemblyE
bool __fastcall RBX::isPartFromAssemblySelected(RBX *this, RBX::BasePart *a2, RBX::Assembly *a3)
{
  RBX::ServiceProvider *ConstWorkspaceIfInWorkspace; // rax
  const RBX::Instance *v5; // rsi
  RBX::ServiceProvider *ServiceProvider; // rax
  __int64 v7; // rax
  RBX::Primitive *v8; // rsi
  __int64 v9; // r15
  __int64 v10; // r14
  __int64 v11; // r15
  bool result; // al
  bool v13; // zf

  ConstWorkspaceIfInWorkspace = (RBX::ServiceProvider *)RBX::Workspace::getConstWorkspaceIfInWorkspace(this, a2); /*0x100c99516*/
  if ( ConstWorkspaceIfInWorkspace == nullptr ) /*0x100c9951e*/
    return false; /*0x100c9951e*/
  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider( /*0x100c99523*/
                                              this: ConstWorkspaceIfInWorkspace,
                                              a2: v5);
  v7 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::FilteredSelection<RBX::BasePart>>(this: ServiceProvider); /*0x100c9952b*/
  v9 = *(_QWORD *)(v7 + 216); /*0x100c99530*/
  v10 = *(_QWORD *)(v7 + 224); /*0x100c99537*/
  if ( v9 == v10 ) /*0x100c99541*/
    return false; /*0x100c9956d*/
  v11 = v9 + 8; /*0x100c99543*/
  do /*0x100c99569*/
  {
    result = RBX::Primitive::getAssembly(this: *(RBX::Primitive **)(*(_QWORD *)(v11 - 8) + 376LL), a2: v8) == (_QWORD)a2; /*0x100c9955a*/
    if ( result ) /*0x100c9955d*/
      break; /*0x100c9955d*/
    v13 = v11 == v10; /*0x100c99563*/
    v11 += 8; /*0x100c99566*/
  }
  while ( !v13 ); /*0x100c99569*/
  return result; /*0x100c99573*/
}

// Address: 0x100ca5e42 | Name: __ZN3RBX30isRotationOrthonormalForAssertERKNS_7Matrix3E
char __fastcall RBX::isRotationOrthonormalForAssert(RBX *this, const RBX::Matrix3 *a2)
{
  __m128 v2; // xmm0
  __m128 v3; // xmm3
  __m128 v4; // xmm2
  float v5; // xmm5_4
  __m128 v6; // xmm6
  float v7; // xmm9_4
  __m128 v8; // xmm1
  __m128 v9; // xmm4
  float v10; // xmm7_4
  bool v11; // cl
  __m128 inserted; // xmm8
  __m128 v13; // xmm9
  __m128 v14; // xmm8
  __m128 v15; // xmm1

  v2 = (__m128)*(unsigned int *)this; /*0x100ca5e46*/
  v3 = (__m128)*((unsigned int *)this + 1); /*0x100ca5e4a*/
  v4 = (__m128)*((unsigned int *)this + 3); /*0x100ca5e4f*/
  v5 = *((float *)this + 4); /*0x100ca5e54*/
  v6 = (__m128)*((unsigned __int64 *)this + 3); /*0x100ca5e59*/
  v7 = _mm_movehdup_ps(v6).f32[0]; /*0x100ca5e5e*/
  v8 = (__m128)*((unsigned int *)this + 2); /*0x100ca5e63*/
  v9 = (__m128)*((unsigned int *)this + 5); /*0x100ca5e68*/
  v10 = *((float *)this + 8); /*0x100ca5e98*/
  v11 = fabs( /*0x100ca6032*/
          (float)(COERCE_FLOAT(*((_QWORD *)this + 3)) * v7)
        + (float)((float)(*((float *)this + 3) * v5) + (float)(*(float *)this * v3.f32[0]))) <= 0.001
     && fabs((float)(v7 * v10) + (float)((float)(v5 * v9.f32[0]) + (float)(v3.f32[0] * v8.f32[0]))) <= 0.001
     && fabs((float)(v6.f32[0] * v10) + (float)((float)(v4.f32[0] * v9.f32[0]) + (float)(v2.f32[0] * v8.f32[0]))) <= 0.001
     && fabs(
          1.0
        - (float)((float)(v6.f32[0] * v6.f32[0])
                + (float)((float)(v4.f32[0] * v4.f32[0]) + (float)(v2.f32[0] * v2.f32[0])))) <= 0.001
     && fabs(1.0 - (float)((float)(v7 * v7) + (float)((float)(v5 * v5) + (float)(v3.f32[0] * v3.f32[0])))) <= 0.001
     && fabs(1.0 - (float)((float)(v10 * v10) + (float)((float)(v9.f32[0] * v9.f32[0]) + (float)(v8.f32[0] * v8.f32[0])))) <= 0.001;
  inserted = _mm_insert_ps(v3, v4, 16); /*0x100ca5f9d*/
  v13 = _mm_mul_ps(_mm_shuffle_ps(v6, v6, 225), _mm_shuffle_ps(inserted, inserted, 225)); /*0x100ca5fb2*/
  v14 = _mm_insert_ps(v6, v2, 16); /*0x100ca5fba*/
  v6.f32[0] = v5; /*0x100ca5fc1*/
  v15 = _mm_mul_ps(_mm_insert_ps(v8, v9, 16), _mm_sub_ps(v13, _mm_mul_ps(v6, v14))); /*0x100ca5fdf*/
  return v11 /*0x100ca5ffa*/
       & ((float)((float)((float)((float)(v2.f32[0] * v5) - (float)(v4.f32[0] * v3.f32[0])) * v10)
                + _mm_hadd_ps(v15, v15).f32[0]) > 0.0);
}

// Address: 0x1011f3fc6 | Name: __ZN3RBX14isPartObstacleEPNS_8BasePartEb
char __fastcall RBX::isPartObstacle(RBX *this, RBX::BasePart *a2)
{
  if ( (*((_BYTE *)this + 400) & 2) != 0 ) /*0x1011f3fcd*/
    return 0; /*0x1011f3fec*/
  else
    return (unsigned __int8)a2 | RBX::BasePartProp::getCanCollide(this: (RBX *)((char *)this + 184)); /*0x1011f3fe3*/
}

// Address: 0x10121b980 | Name: __ZN3RBX16isObstacleNearbyEP14dtNavMeshQueryPK13dtQueryFilterRKNS_7Vector3ERK13dtTilePolyRefS7_b
__int64 __fastcall RBX::isObstacleNearby(
        RBX *this,
        dtNavMeshQuery *a2,
        const dtQueryFilter *a3,
        const RBX::Vector3 *a4,
        const dtTilePolyRef *a5,
        const RBX::Vector3 *a6)
{
  unsigned int v6; // r14d
  __int64 v8; // xmm0_8
  __m128 v9; // xmm2
  __m128 v10; // xmm3
  __m128 v11; // xmm4
  float v12; // xmm1_4
  __m128 v13; // xmm4
  __m128 v14; // xmm2
  __m128 v15; // xmm5
  __m128 v16; // xmm3
  __m128 v17; // xmm2
  __m128 v18; // xmm1
  __m128 v19; // xmm2
  unsigned __int8 v22; // r15
  double v23; // xmm1_8
  __int64 v24; // xmm0_8
  __m128 inserted; // xmm1
  __m128 v26; // xmm0
  __m128 v27; // xmm0
  __m128 v28; // xmm3
  __m128 v29; // xmm5
  __m128 v30; // xmm3
  __m128 v31; // xmm4
  __m128 v32; // xmm1
  __m128 v34; // [rsp+0h] [rbp-80h]
  __int64 v35; // [rsp+10h] [rbp-70h] BYREF
  float v36; // [rsp+18h] [rbp-68h]
  __int64 v37; // [rsp+20h] [rbp-60h] BYREF
  float v38; // [rsp+28h] [rbp-58h]
  dtNavMeshQuery *v39; // [rsp+30h] [rbp-50h]
  bool v40[8]; // [rsp+38h] [rbp-48h] BYREF
  unsigned int v41; // [rsp+40h] [rbp-40h]
  bool v42[8]; // [rsp+48h] [rbp-38h] BYREF
  unsigned int v43; // [rsp+50h] [rbp-30h]
  char v44; // [rsp+56h] [rbp-2Ah] BYREF
  _BYTE v45[41]; // [rsp+57h] [rbp-29h] BYREF

  v8 = 0; /*0x10121b998*/
  v9 = (__m128)*(unsigned int *)a3; /*0x10121b99b*/
  v9.f32[0] = v9.f32[0] * 0.0; /*0x10121b99e*/
  v10 = (__m128)*(unsigned __int64 *)((char *)a3 + 4); /*0x10121b9a2*/
  v11 = _mm_mul_ps((__m128)0LL, v10); /*0x10121b9aa*/
  v12 = *(float *)a3 - v11.f32[0]; /*0x10121b9b7*/
  v13 = _mm_sub_ps(v11, _mm_insert_ps(_mm_movehdup_ps(v10), v9, 16)); /*0x10121b9bb*/
  v14 = _mm_mul_ps(v13, v13); /*0x10121b9c1*/
  v15 = (__m128)*((unsigned int *)a2 + 2); /*0x10121b9c8*/
  v16 = (__m128)0x3F800000u; /*0x10121b9df*/
  v16.f32[0] = 1.0 / fsqrt((float)(v12 * v12) + _mm_hadd_ps(v14, v14).f32[0]); /*0x10121b9e7*/
  v17 = _mm_mul_ps(_mm_moveldup_ps(v16), v13); /*0x10121b9ef*/
  v16.f32[0] = v16.f32[0] * v12; /*0x10121b9f2*/
  v18 = _mm_mul_ps(_mm_moveldup_ps(v15), v17); /*0x10121b9fa*/
  v34 = v15; /*0x10121b9fd*/
  v16.f32[0] = v16.f32[0] * v15.f32[0]; /*0x10121ba01*/
  v19 = (__m128)*(unsigned __int64 *)a5; /*0x10121ba05*/
  v15.i32[0] = *((_DWORD *)a5 + 2); /*0x10121ba10*/
  _mm_storel_ps((double *)&v35, _mm_add_ps(v19, v18)); /*0x10121ba1d*/
  v36 = v15.f32[0] + v16.f32[0]; /*0x10121ba21*/
  _mm_storel_ps((double *)&v37, _mm_sub_ps(v19, v18)); /*0x10121ba2d*/
  v38 = v15.f32[0] - v16.f32[0]; /*0x10121ba31*/
  *(_QWORD *)v40 = 0; /*0x10121ba38*/
  v41 = 0; /*0x10121ba3c*/
  *(_QWORD *)v42 = 0; /*0x10121ba3f*/
  v43 = 0; /*0x10121ba43*/
  v44 = 0; /*0x10121ba46*/
  v45[0] = 0; /*0x10121ba49*/
  if ( DFFlag::NavigationRaycastHigherCostDetection == 0 ) /*0x10121ba55*/
    v8 = 3212836864LL; /*0x10121ba57*/
  v39 = a2; /*0x10121ba6e*/
  v22 = (unsigned __int8)a6; /*0x10121ba7b*/
  LOBYTE(v6) = 1; /*0x10121ba8a*/
  if ( (unsigned int)RBX::getRayHitLocation( /*0x10121ba92*/
                       this,
                       a2,
                       a3: a4,
                       a4: a5,
                       a5: (const RBX::Vector3 *)&v37,
                       a6,
                       a7: *(double *)&v8,
                       a8: *(double *)v18.i64,
                       a9: (__int64)v40,
                       a10: (RBX::Vector3 *)&v44) == 0x40000000 )
  {
    v24 = 0; /*0x10121baa2*/
    if ( DFFlag::NavigationRaycastHigherCostDetection == 0 ) /*0x10121baa5*/
      v24 = 3212836864LL; /*0x10121baa7*/
    if ( (unsigned int)RBX::getRayHitLocation( /*0x10121badd*/
                         this,
                         a2: v39,
                         a3: a4,
                         a4: a5,
                         a5: (const RBX::Vector3 *)&v35,
                         a6: (const RBX::Vector3 *)v22,
                         a7: *(double *)&v24,
                         a8: v23,
                         a9: (__int64)v42,
                         a10: (RBX::Vector3 *)v45) == 0x40000000 )
    {
      if ( v45[0] != 0 || v44 == 1 ) /*0x10121baed*/
      {
        inserted = _mm_insert_ps((__m128)*(unsigned int *)a5, (__m128)*((unsigned int *)a5 + 2), 16); /*0x10121bb03*/
        v26 = _mm_sub_ps(_mm_insert_ps((__m128)*(unsigned int *)v42, (__m128)v43, 16), inserted); /*0x10121bb0f*/
        v27 = _mm_mul_ps(v26, v26); /*0x10121bb12*/
        v28 = _mm_sub_ps(_mm_insert_ps((__m128)*(unsigned int *)v40, (__m128)v41, 16), inserted); /*0x10121bb26*/
        v29 = v34; /*0x10121bb29*/
        v29.f32[0] = v34.f32[0] * 0.5; /*0x10121bb2d*/
        v30 = _mm_mul_ps(v28, v28); /*0x10121bb3c*/
        v31 = _mm_sub_ps( /*0x10121bb43*/
                _mm_insert_ps((__m128)*(unsigned int *)&v40[4], (__m128)*(unsigned int *)&v42[4], 16),
                _mm_moveldup_ps((__m128)*((unsigned int *)a5 + 1)));
        v32 = _mm_cmpnlt_ps( /*0x10121bb65*/
                _mm_moveldup_ps(v29),
                _mm_sqrt_ps(_mm_add_ps(_mm_insert_ps(v27, v30, 76), _mm_add_ps(_mm_insert_ps(v30, v27, 28), _mm_mul_ps(v31, v31)))));
        LOBYTE(v6) = _mm_movemask_pd((__m128d)_mm_unpacklo_ps(v32, v32)) != 0; /*0x10121bb72*/
      }
      else
      {
        return 0; /*0x10121bb78*/
      }
    }
  }
  return v6; /*0x10121bb7e*/
}

// Address: 0x1013059f4 | Name: __ZN3RBX18isProductInfoValidERKNSt3__110shared_ptrIKNS_10Reflection10ValueTableEEE
char __fastcall RBX::isProductInfoValid(RBX::Reflection::ValueTable **a1)
{
  RBX::Reflection::ValueTable *v2; // rdi
  __int64 v3; // rax

  v2 = *a1; /*0x1013059fd*/
  if ( v2 != nullptr /*0x101305a3c*/
    && RBX::Reflection::ValueTable::find(this: v2, a2: "Name") != 0
    && RBX::Reflection::ValueTable::find(this: *a1, a2: "Description") != 0
    && (v3 = RBX::Reflection::ValueTable::find(this: *a1, a2: "ProductId")) != 0 )
  {
    return *(_BYTE *)(*(_QWORD *)(v3 + 40) + 53LL); /*0x101305a42*/
  }
  else
  {
    return 0; /*0x101305a47*/
  }
}

// Address: 0x10286ac43 | Name: __ZN3RBX29importControlsToJointsMappingERNS_12FileMeshDataERKNS_12DenseHashMapINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS3_13unordered_mapIS9_NS_11JointParamsENS3_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SB_EEEEEENS_4HashIS9_EESF_EE
__int64 __fastcall RBX::importControlsToJointsMapping(__int64 a1, __int64 a2)
{
  unsigned int v4; // ebx
  std::__shared_weak_count *v5; // r14
  __int64 v7; // [rsp+8h] [rbp-28h] BYREF
  std::__shared_weak_count *v8; // [rsp+10h] [rbp-20h]

  RBX::make_shared<RBX::ControlsToJointDriver>(a1: &v7); /*0x10286ac5d*/
  v4 = RBX::ControlsToJointDriver::load(a1: v7, a2); /*0x10286ac6d*/
  if ( (_BYTE)v4 != 0 ) /*0x10286ac71*/
    std::shared_ptr<RBX::ControlsToJointDriver>::operator=[abi:ne200100](a1: a1 + 928, a2: &v7); /*0x10286ac81*/
  v5 = v8; /*0x10286ac86*/
  if ( v8 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v8 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10286ac9f*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x10286aca7*/
    std::__shared_weak_count::__release_weak(this: v5); /*0x10286acad*/
  }
  return v4; /*0x10286acb4*/
}

// Address: 0x102a21736 | Name: __ZN3RBXL21isJointParamsIdentityERKNS_11JointParamsE
__int64 __fastcall RBX::isJointParamsIdentity(RBX *this, const RBX::JointParams *a2)
{
  __int64 result; // rax
  __m128 v3; // rt1

  result = 0; /*0x102a2173e*/
  if ( *(float *)this == 0.0 && *((float *)this + 1) == 0.0 && *((float *)this + 2) == 0.0 ) /*0x102a2175e*/
  {
    result = 0; /*0x102a21767*/
    if ( *((float *)this + 3) == 0.0 && *((float *)this + 4) == 0.0 ) /*0x102a21778*/
    {
      v3.i32[0] = *((_DWORD *)this + 5); /*0x102a2177c*/
      return _mm_cvtsi128_si32((__m128i)_mm_cmpeq_ss((__m128)0LL, v3)) & 1; /*0x102a21786*/
    }
  }
  return result; /*0x102a21789*/
}

// Address: 0x102a444a9 | Name: __ZN3RBX24isBehaviorSupportEnabledEv
__int64 __fastcall RBX::isBehaviorSupportEnabled(RBX *this)
{
  __int16 hasInternalPermissionSafe; // ax

  if ( FFlag::DebugHashTableMetrics == 0 && (FFlag::SAuthWorkspaceFlagged & 1) == 0 /*0x102a444c8*/
    || FFlag::ProfileZstdCompressionMetrics != 1 )
  {
    return 0; /*0x102a444e1*/
  }
  hasInternalPermissionSafe = RBX::hasInternalPermissionSafe(this); /*0x102a444ce*/
  return (unsigned __int8)hasInternalPermissionSafe & HIBYTE(hasInternalPermissionSafe) & 1; /*0x102a444e0*/
}

// Address: 0x102a8e631 | Name: __ZN3RBX20isRobloxInternalUserENS_10StringViewE
char __fastcall RBX::isRobloxInternalUser(__int64 a1, unsigned __int64 a2)
{
  unsigned __int8 v4; // dl
  char *v5; // rcx
  __int64 v6; // rax
  unsigned __int8 v7; // si
  bool v8; // zf
  char *v9; // rdx
  __int64 v10; // rdi
  void *v11; // rsi
  __int64 v12; // r15
  __int64 v13; // r13
  __int64 v14; // r15
  char *v15; // rdx
  unsigned __int64 v16; // rbx
  _QWORD v18[2]; // [rsp+8h] [rbp-58h] BYREF
  __int64 v19; // [rsp+18h] [rbp-48h]
  __int128 v20; // [rsp+20h] [rbp-40h] BYREF
  void *v21; // [rsp+30h] [rbp-30h]

  if ( a1 != 0 ) /*0x102a8e64b*/
  {
    std::string::basic_string[abi:ne200100](a1: &v20, a2: a1, a3: a2); /*0x102a8e65a*/
    v4 = v20; /*0x102a8e65f*/
    v5 = (char *)v21; /*0x102a8e662*/
    v6 = *((_QWORD *)&v20 + 1); /*0x102a8e666*/
  }
  else
  {
    v20 = 0; /*0x102a8e66f*/
    v21 = nullptr; /*0x102a8e673*/
    v6 = 0; /*0x102a8e67b*/
    v5 = nullptr; /*0x102a8e67d*/
    v4 = 0; /*0x102a8e67f*/
  }
  v7 = v4 >> 1; /*0x102a8e683*/
  v8 = (v4 & 1) == 0; /*0x102a8e686*/
  v9 = (char *)&v20 + 1; /*0x102a8e689*/
  v10 = v7; /*0x102a8e68d*/
  if ( !v8 ) /*0x102a8e691*/
  {
    v9 = v5; /*0x102a8e691*/
    v10 = v6; /*0x102a8e695*/
  }
  v18[0] = v9; /*0x102a8e69d*/
  v18[1] = v10; /*0x102a8e6a0*/
  v12 = std::__tree<RBX::StringView>::__count_unique<RBX::StringView>(a1: &RBX::emailBlockList, a2: v18, a3: v9, a4: v5); /*0x102a8e6b0*/
  if ( (v20 & 1) != 0 ) /*0x102a8e6b7*/
    operator delete(a1: (RBX::Memory *)v21, a2: v11); /*0x102a8e6bd*/
  if ( v12 != 0 ) /*0x102a8e6c5*/
    return 0; /*0x102a8e738*/
  v19 = a1; /*0x102a8e6c7*/
  v13 = a1 + a2; /*0x102a8e6cb*/
  v14 = 0; /*0x102a8e6cf*/
  while ( 1 ) /*0x102a8e6d9*/
  {
    v15 = (&RBX::robloxEmailSuffixes)[v14 + 1]; /*0x102a8e6d9*/
    v16 = a2 - (_QWORD)v15; /*0x102a8e6e1*/
    if ( a2 >= (unsigned __int64)v15 /*0x102a8e6fc*/
      && (v15 == nullptr
       || memcmp(__s1: (const void *)(v13 - (_QWORD)v15), __s2: (&RBX::robloxEmailSuffixes)[v14], __n: (size_t)v15) == 0) )
    {
      if ( a2 < v16 ) /*0x102a8e701*/
        v16 = a2; /*0x102a8e701*/
      *(_QWORD *)&v20 = v19; /*0x102a8e709*/
      *((_QWORD *)&v20 + 1) = v16; /*0x102a8e70d*/
      if ( RBX::detail::StringViewBase::find(a1: &v20, a2: ".", a3: 1, a4: 0) == -1 ) /*0x102a8e72c*/
        break; /*0x102a8e72c*/
    }
    v14 += 2; /*0x102a8e72e*/
    if ( v14 == 4 ) /*0x102a8e736*/
      return 0; /*0x102a8e736*/
  }
  return 1; /*0x102a8e73a*/
}

// Address: 0x102acc3e3 | Name: __ZN3RBX9isInScopeEPNS_8InstanceES1_
bool __fastcall RBX::isInScope(RBX *this, RBX::Instance *a2, RBX::Instance *a3)
{
  bool result; // al

  if ( this == a2 ) /*0x102acc3e6*/
    return true; /*0x102acc3ff*/
  do /*0x102acc3fb*/
  {
    result = a2 != nullptr; /*0x102acc3ef*/
    if ( a2 == nullptr ) /*0x102acc3f2*/
      break; /*0x102acc3f2*/
    a2 = *((RBX::Instance **)a2 + 13); /*0x102acc3f4*/
  }
  while ( a2 != this ); /*0x102acc3fb*/
  return result; /*0x102acc3fe*/
}

// Address: 0x102ae290c | Name: __ZNK3RBX11InstanceRefeqERKS0_
bool __fastcall RBX::InstanceRef::operator==(RBX::InstanceRef *a1, RBX::InstanceRef *a2)
{
  __int64 AsGuid; // r14

  AsGuid = RBX::InstanceRef::getAsGuid(this: a1); /*0x102ae291b*/
  return AsGuid == RBX::InstanceRef::getAsGuid(this: a2); /*0x102ae292c*/
}

// Address: 0x102ae2932 | Name: __ZNK3RBX11InstanceRefneERKS0_
bool __fastcall RBX::InstanceRef::operator!=(RBX::InstanceRef *a1, RBX::InstanceRef *a2)
{
  __int64 AsGuid; // r14

  AsGuid = RBX::InstanceRef::getAsGuid(this: a1); /*0x102ae2941*/
  return AsGuid != RBX::InstanceRef::getAsGuid(this: a2); /*0x102ae2952*/
}

// Address: 0x102b12ab5 | Name: __ZN3RBXL22initLegacyContentTableEv
__int64 __fastcall RBX::initLegacyContentTable(RBX *this, unsigned __int64 a2)
{
  RBX::LegacyContentTable *v2; // rbx
  __int64 result; // rax
  __int64 v4; // rsi

  v2 = (RBX::LegacyContentTable *)operator new(a1: (RBX::Memory *)0x48, a2); /*0x102b12ac6*/
  result = RBX::LegacyContentTable::LegacyContentTable(this: v2); /*0x102b12acc*/
  v4 = RBX::staticLegacyContentTable; /*0x102b12ad1*/
  RBX::staticLegacyContentTable = (__int64)v2; /*0x102b12ad8*/
  if ( v4 != 0 ) /*0x102b12ae2*/
    return std::default_delete<RBX::LegacyContentTable>::operator()[abi:ne200100](a1: &RBX::staticLegacyContentTable); /*0x102b12aef*/
  return result; /*0x102b12aeb*/
}

// Address: 0x102b4bf16 | Name: __ZN3RBX28isMemoryMappedStorageEnabledEv
__int64 __fastcall RBX::isMemoryMappedStorageEnabled(RBX *this)
{
  int v2; // ebx

  if ( (_BYTE)`guard variable for'RBX::isMemoryMappedStorageEnabled(void)::isEnabled == 0 /*0x102b4bf51*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::isMemoryMappedStorageEnabled(void)::isEnabled) != 0 )
  {
    v2 = FInt::MmapForMemProfStorageThrottle; /*0x102b4bf53*/
    RBX::isMemoryMappedStorageEnabled(void)::isEnabled = v2 > (int)((unsigned int)RBX::globalRand(this) % 0x2710); /*0x102b4bf77*/
    __cxa_guard_release(a1: &`guard variable for'RBX::isMemoryMappedStorageEnabled(void)::isEnabled); /*0x102b4bf85*/
  }
  if ( RBX::isMemoryMappedStorageEnabled(void)::isEnabled == 1 ) /*0x102b4bf2d*/
    return RBX::MappedFile::isSupported(this); /*0x102b4bf35*/
  else
    return 0; /*0x102b4bf3a*/
}

// Address: 0x102ba053c | Name: __ZN3RBX14IsCrashHandlerEv
char __fastcall RBX::IsCrashHandler(RBX *this)
{
  return *(_BYTE *)`anonymous namespace'::isCrashHandler; /*0x102ba0549*/
}

// Address: 0x102ba0578 | Name: __ZN3RBX16IsSimulatedCrashEv
__int64 __fastcall RBX::IsSimulatedCrash(RBX *this)
{
  unsigned int v1; // r14d

  std::mutex::lock(this: (std::mutex *)&`anonymous namespace'::g_globalStateMutex); /*0x102ba0589*/
  LOBYTE(v1) = *(_BYTE *)`anonymous namespace'::isSimulatedCrash; /*0x102ba0595*/
  std::mutex::unlock(this: (std::mutex *)&`anonymous namespace'::g_globalStateMutex); /*0x102ba059b*/
  return v1; /*0x102ba05a3*/
}

// Address: 0x102ba0753 | Name: __ZN3RBX19IsProductionChannelENS_10StringViewE
bool __fastcall RBX::IsProductionChannel(__int64 a1, __int64 a2)
{
  bool result; // al
  __int64 v5; // r12
  __int64 v6; // rdi
  int v7; // eax
  __int64 v8; // rcx
  char *v9; // rsi
  _QWORD v10[7]; // [rsp+8h] [rbp-38h] BYREF

  v10[0] = a1; /*0x102ba0764*/
  v10[1] = a2; /*0x102ba0768*/
  result = true; /*0x102ba076c*/
  if ( a2 != 0 )
  {
    v5 = 0; /*0x102ba077d*/
    while ( 1 )
    {
      v6 = (unsigned int)*(char *)(a1 + v5); /*0x102ba078d*/
      v7 = (int)v6 < 0 ? __maskrune(a1: v6, a2: 0x4000) : _DefaultRuneLocale.__runetype[(unsigned int)v6] & 0x4000;
      if ( v7 == 0 ) /*0x102ba07ae*/
        break; /*0x102ba07ae*/
      if ( a2 == ++v5 ) /*0x102ba07b6*/
        return true; /*0x102ba07ba*/
    }
    if ( (`anonymous namespace'::productionChannelName & 1) != 0 ) /*0x102ba07c5*/
      v8 = *((_QWORD *)&`anonymous namespace'::productionChannelName + 1); /*0x102ba07c7*/
    else
      v8 = (unsigned __int8)`anonymous namespace'::productionChannelName >> 1; /*0x102ba07d2*/
    if ( v8 == a2 ) /*0x102ba07d7*/
    {
      if ( (`anonymous namespace'::productionChannelName & 1) != 0 ) /*0x102ba07db*/
        v9 = (char *)qword_10D0EE4C0; /*0x102ba07dd*/
      else
        v9 = (char *)&`anonymous namespace'::productionChannelName + 1; /*0x102ba07ea*/
      return (unsigned int)RBX::detail::StringViewBase::compare_lower(a1: v10, a2: v9, a3: a2) == 0; /*0x102ba07ff*/
    }
    else
    {
      return false; /*0x102ba07e6*/
    }
  }
  return result; /*0x102ba0802*/
}

// Address: 0x102ba0811 | Name: __ZN3RBX19InProductionChannelEv
bool __fastcall RBX::InProductionChannel(RBX *this)
{
  unsigned int v1; // ecx
  __int64 v2; // r15
  bool result; // al
  __int64 v4; // r14
  __int64 v5; // r12
  __int64 v6; // rdi
  int v7; // eax
  unsigned int v8; // eax
  size_t v9; // rdx
  __int64 v10; // rsi
  const void *v11; // rdi
  char *v12; // rsi

  v1 = *(unsigned __int8 *)`anonymous namespace'::robloxChannel; /*0x102ba0826*/
  if ( (v1 & 1) != 0 ) /*0x102ba082d*/
    v2 = *(_QWORD *)(`anonymous namespace'::robloxChannel + 8); /*0x102ba082f*/
  else
    v2 = v1 >> 1; /*0x102ba0838*/
  result = true; /*0x102ba083b*/
  if ( v2 != 0 )
  {
    if ( (v1 & 1) != 0 ) /*0x102ba0849*/
      v4 = *(_QWORD *)(`anonymous namespace'::robloxChannel + 16); /*0x102ba084b*/
    else
      v4 = `anonymous namespace'::robloxChannel + 1; /*0x102ba0851*/
    v5 = 0; /*0x102ba0854*/
    while ( 1 )
    {
      v6 = (unsigned int)*(char *)(v4 + v5); /*0x102ba0863*/
      v7 = (int)v6 < 0 ? __maskrune(a1: v6, a2: 0x4000) : _DefaultRuneLocale.__runetype[(unsigned int)v6] & 0x4000;
      if ( v7 == 0 ) /*0x102ba0883*/
        break; /*0x102ba0883*/
      if ( v2 == ++v5 ) /*0x102ba088b*/
        return true; /*0x102ba088f*/
    }
    v8 = *(unsigned __int8 *)`anonymous namespace'::robloxChannel; /*0x102ba0898*/
    if ( (v8 & 1) != 0 ) /*0x102ba089d*/
      v9 = *(_QWORD *)(`anonymous namespace'::robloxChannel + 8); /*0x102ba089f*/
    else
      v9 = v8 >> 1; /*0x102ba08a7*/
    if ( (`anonymous namespace'::productionChannelName & 1) != 0 ) /*0x102ba08b3*/
      v10 = *((_QWORD *)&`anonymous namespace'::productionChannelName + 1); /*0x102ba08b5*/
    else
      v10 = (unsigned __int8)`anonymous namespace'::productionChannelName >> 1; /*0x102ba08c0*/
    if ( v9 == v10 ) /*0x102ba08c5*/
    {
      if ( (v8 & 1) != 0 ) /*0x102ba08c9*/
        v11 = *(const void **)(`anonymous namespace'::robloxChannel + 16); /*0x102ba08cb*/
      else
        v11 = (const void *)(`anonymous namespace'::robloxChannel + 1); /*0x102ba08d5*/
      if ( (`anonymous namespace'::productionChannelName & 1) != 0 ) /*0x102ba08db*/
        v12 = (char *)qword_10D0EE4C0; /*0x102ba08dd*/
      else
        v12 = (char *)&`anonymous namespace'::productionChannelName + 1; /*0x102ba08e6*/
      return memcmp(__s1: v11, __s2: v12, __n: v9) == 0; /*0x102ba08f4*/
    }
    else
    {
      return false; /*0x102ba08d1*/
    }
  }
  return result; /*0x102ba08fb*/
}

// Address: 0x102bd89da | Name: __ZN3RBX14isProcessAliveEi
bool __fastcall RBX::isProcessAlive(RBX *this)
{
  return kill(a1: (pid_t)this, a2: 0) == 0; /*0x102bd89ea*/
}

// Address: 0x102f5a10d | Name: __ZN3RBX18isAssetDeliveryUrlERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
bool __fastcall RBX::isAssetDeliveryUrl(unsigned __int8 *a1)
{
  unsigned int v1; // edx
  unsigned __int64 v2; // rdx
  unsigned __int8 *v3; // rdi
  __int64 v4; // rax
  unsigned __int8 *v5; // rax
  unsigned __int8 *v6; // rcx
  unsigned __int8 *v7; // rsi
  __int64 v8; // r8
  bool v9; // zf

  v1 = *a1; /*0x102f5a10d*/
  if ( (v1 & 1) != 0 ) /*0x102f5a113*/
  {
    v2 = *((_QWORD *)a1 + 1); /*0x102f5a115*/
    v3 = *((unsigned __int8 **)a1 + 2); /*0x102f5a119*/
  }
  else
  {
    v3 = a1 + 1; /*0x102f5a11f*/
    v2 = v1 >> 1; /*0x102f5a122*/
  }
  v4 = 32; /*0x102f5a128*/
  if ( v2 < 0x20 ) /*0x102f5a12d*/
    v4 = v2; /*0x102f5a12d*/
  v5 = &v3[v4]; /*0x102f5a131*/
  v6 = v5; /*0x102f5a134*/
  if ( v2 != 0 ) /*0x102f5a13a*/
  {
    v7 = v3; /*0x102f5a147*/
    v6 = v5; /*0x102f5a14a*/
    do /*0x102f5a158*/
    {
      if ( *v7 == 104 ) /*0x102f5a150*/
      {
        v8 = 1; /*0x102f5a15c*/
        while ( v8 != 32 ) /*0x102f5a166*/
        {
          if ( &v7[v8] == v5 ) /*0x102f5a16f*/
            return v6 != v5 && v6 - v3 != -1; /*0x102f5a16f*/
          v9 = v7[v8] == (unsigned __int8)RBX::kAssetDeliveryUrl[v8]; /*0x102f5a178*/
          ++v8; /*0x102f5a17c*/
          if ( !v9 ) /*0x102f5a17f*/
            goto LABEL_9; /*0x102f5a17f*/
        }
        v6 = v7; /*0x102f5a183*/
      }
LABEL_9:
      ++v7; /*0x102f5a152*/
    }
    while ( v7 != v5 ); /*0x102f5a158*/
  }
  return v6 != v5 && v6 - v3 != -1; /*0x102f5a19b*/
}

// Address: 0x102f87a29 | Name: __ZN3RBXL17isFromValidDomainENS_10StringViewES0_S0_
__int64 __fastcall RBX::isFromValidDomain(__int64 a1, __int64 a2, __int64 a3, int a4, __int64 a5, __int64 a6)
{
  char *v9; // rsi
  void *v10; // rsi
  unsigned int isSubdomainOf; // r15d
  _BYTE v13[16]; // [rsp+20h] [rbp-D0h] BYREF
  void *v14; // [rsp+30h] [rbp-C0h]
  char v15; // [rsp+38h] [rbp-B8h]
  void *v16; // [rsp+48h] [rbp-A8h]
  char v17; // [rsp+50h] [rbp-A0h]
  void *v18; // [rsp+60h] [rbp-90h]
  char v19; // [rsp+68h] [rbp-88h]
  void *v20; // [rsp+78h] [rbp-78h]
  char v21; // [rsp+80h] [rbp-70h]
  void *v22; // [rsp+90h] [rbp-60h]
  __int64 v23; // [rsp+A0h] [rbp-50h]
  __int64 v24; // [rsp+A8h] [rbp-48h]
  __int128 v25; // [rsp+B0h] [rbp-40h] BYREF
  char *v26; // [rsp+C0h] [rbp-30h]

  v24 = a6; /*0x102f87a3d*/
  v23 = a5; /*0x102f87a41*/
  RBX::Url::fromString(this: (RBX::Url *)v13); /*0x102f87a5e*/
  if ( a1 != 0 ) /*0x102f87a66*/
  {
    std::string::basic_string[abi:ne200100](a1: &v25, a2: a1, a3: a2); /*0x102f87a72*/
    if ( (v25 & 1) != 0 ) /*0x102f87a7b*/
      v9 = v26; /*0x102f87a98*/
    else
      v9 = (char *)&v25 + 1; /*0x102f87a7d*/
  }
  else
  {
    v9 = (char *)&v25 + 1; /*0x102f87a86*/
    v25 = 0; /*0x102f87a8a*/
    v26 = nullptr; /*0x102f87a8e*/
  }
  isSubdomainOf = RBX::Url::isSubdomainOf(this: (RBX::Url *)v13, a2: v9); /*0x102f87aa8*/
  if ( (v25 & 1) != 0 ) /*0x102f87aaf*/
    operator delete(a1: (RBX::Memory *)v26, a2: v10); /*0x102f87ab5*/
  if ( (v21 & 1) != 0 ) /*0x102f87abe*/
    operator delete(a1: (RBX::Memory *)v22, a2: v10); /*0x102f87ac4*/
  if ( (v19 & 1) != 0 ) /*0x102f87ad0*/
    operator delete(a1: (RBX::Memory *)v20, a2: v10); /*0x102f87ad6*/
  if ( (v17 & 1) != 0 ) /*0x102f87ae2*/
    operator delete(a1: (RBX::Memory *)v18, a2: v10); /*0x102f87aeb*/
  if ( (v15 & 1) != 0 ) /*0x102f87af7*/
    operator delete(a1: (RBX::Memory *)v16, a2: v10); /*0x102f87b00*/
  if ( (v13[0] & 1) != 0 ) /*0x102f87b0c*/
    operator delete(a1: (RBX::Memory *)v14, a2: v10); /*0x102f87b15*/
  if ( (_BYTE)isSubdomainOf == 0 /*0x102f87b34*/
    && (unsigned __int8)FLog::HttpCookieProtocol >= 6u
    && BYTE1(FLog::HttpCookieProtocol) >= 3u )
  {
    FLog::FastLogFormatted( /*0x102f87b64*/
      a1: (_DWORD)FLog::HttpCookieProtocol,
      a2: qword_10D783EC0,
      a3: (unsigned int)"[FLog::HttpCookieProtocol] %.*s cookies from '%.*s' in '%.*s' is prohibited",
      a4: v24,
      a5: v23,
      a6: a4);
  }
  return isSubdomainOf; /*0x102f87b6c*/
}

// Address: 0x102f8959e | Name: __ZN3RBX22isGcsChallengeResponseERKNS_12HttpResponseE
bool __fastcall RBX::isGcsChallengeResponse(RBX *this, const RBX::HttpResponse *a2)
{
  __int64 v3; // rdx
  __int64 v4; // rdx
  __int64 v5; // rdx

  if ( *((_DWORD *)this + 6) != 403 ) /*0x102f895a5*/
    return false; /*0x102f895fb*/
  RBX::HttpResponse::getHeader(a1: this, a2: "rblx-challenge-id", a3: 17); /*0x102f895bc*/
  if ( v3 == 0 ) /*0x102f895c4*/
    return false; /*0x102f895c4*/
  RBX::HttpResponse::getHeader(a1: this, a2: "rblx-challenge-metadata", a3: 23); /*0x102f895d5*/
  if ( v4 == 0 ) /*0x102f895dd*/
    return false; /*0x102f895fe*/
  RBX::HttpResponse::getHeader(a1: this, a2: "rblx-challenge-type", a3: 19); /*0x102f895ee*/
  return v5 != 0; /*0x102f895fd*/
}

// Address: 0x102fbb302 | Name: __ZN3RBX27initializeProxyAllowedCidrsENS_10StringViewERNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall RBX::initializeProxyAllowedCidrs(__int64 a1, __int64 a2, __int64 a3)
{
  unsigned int v3; // ebx

  LOBYTE(v3) = 1; /*0x102fbb308*/
  if ( RBX::kIsProxyAllowedCidrsInitialized == 0 ) /*0x102fbb311*/
  {
    if ( a2 != 0 /*0x102fbb337*/
      && (*(&RBX::kConfiguredIpV4ProxyAllowed + 1) = RBX::kConfiguredIpV4ProxyAllowed,
          (unsigned __int8)RBX::parseAllowedProxyCidrs(a1, a2, a3: &RBX::kConfiguredIpV4ProxyAllowed, a4: a3) == 0) )
    {
      return 0; /*0x102fbb342*/
    }
    else
    {
      RBX::kIsProxyAllowedCidrsInitialized = 1; /*0x102fbb339*/
    }
  }
  return v3; /*0x102fbb34a*/
}

// Address: 0x102fbb34d | Name: __ZN3RBX22isBlockedIpLiteralHostENS_10StringViewE
__int64 __fastcall RBX::isBlockedIpLiteralHost(__int64 a1, __int64 a2)
{
  char *v2; // rdi
  __int64 v3; // rcx
  char *v4; // rsi
  unsigned int v5; // r14d
  unsigned int v6; // r14d
  __int64 v7; // r12
  unsigned int isBlockedIpV6; // ebx
  unsigned __int8 *v9; // rsi
  bool v10; // zf
  void *v11; // rsi
  char ai_flags; // al
  addrinfo v14; // [rsp+0h] [rbp-80h] BYREF
  addrinfo *v15; // [rsp+38h] [rbp-48h] BYREF
  char v16[16]; // [rsp+40h] [rbp-40h] BYREF
  char *v17; // [rsp+50h] [rbp-30h]

  if ( a1 == 0 ) /*0x102fbb369*/
  {
    *(_OWORD *)v16 = 0; /*0x102fbb3ad*/
    v17 = nullptr; /*0x102fbb3b3*/
    memset(&v14.ai_socktype, 0, 40); /*0x102fbb3bf*/
    *(_QWORD *)&v14.ai_flags = 0x200000004LL; /*0x102fbb3c3*/
    v15 = nullptr; /*0x102fbb3c7*/
    goto LABEL_5; /*0x102fbb3c7*/
  }
  std::string::basic_string[abi:ne200100](a1: v16, a2: a1, a3: a2); /*0x102fbb378*/
  v2 = v17; /*0x102fbb37f*/
  memset(&v14.ai_socktype, 0, 40); /*0x102fbb390*/
  *(_QWORD *)&v14.ai_flags = 0x200000004LL; /*0x102fbb394*/
  v15 = nullptr; /*0x102fbb398*/
  if ( (v16[0] & 1) == 0 ) /*0x102fbb3a2*/
LABEL_5:
    v2 = &v16[1]; /*0x102fbb3cb*/
  if ( getaddrinfo(a1: v2, a2: nullptr, a3: &v14, a4: &v15) != 0 ) /*0x102fbb3df*/
  {
    if ( (v16[0] & 1) != 0 ) /*0x102fbb3e8*/
    {
      v3 = *(_QWORD *)&v16[8]; /*0x102fbb44e*/
      if ( *(_QWORD *)&v16[8] < 2u || *v17 != 91 || v17[*(_QWORD *)&v16[8] - 1] != 93 ) /*0x102fbb466*/
      {
        *(_OWORD *)&v14.ai_flags = 0; /*0x102fbb4b8*/
        v4 = v17; /*0x102fbb4bc*/
LABEL_24:
        if ( inet_pton(a1: 30, a2: v4, a3: &v14) == 1 ) /*0x102fbb4d1*/
          isBlockedIpV6 = RBX::isBlockedIpV6(this: (RBX *)&v14, a2: v9); /*0x102fbb4dc*/
        else
          isBlockedIpV6 = 0; /*0x102fbb4e0*/
        goto LABEL_27; /*0x102fbb4de*/
      }
    }
    else if ( v16[0] < 3u || v16[1] != 91 || (v3 = (unsigned __int8)v16[0] >> 1, v16[v3] != 93) ) /*0x102fbb3fc*/
    {
      *(_OWORD *)&v14.ai_flags = 0; /*0x102fbb401*/
LABEL_12:
      v4 = &v16[1]; /*0x102fbb405*/
      goto LABEL_24; /*0x102fbb408*/
    }
    std::string::basic_string(a1: &v14, a2: v16, a3: 1, a4: v3 - 2, a5: &v15); /*0x102fbb47d*/
    if ( (v16[0] & 1) != 0 ) /*0x102fbb486*/
      operator delete(a1: (RBX::Memory *)v17, a2: v11); /*0x102fbb48c*/
    v4 = *(char **)&v14.ai_addrlen; /*0x102fbb491*/
    v17 = *(char **)&v14.ai_addrlen; /*0x102fbb495*/
    *(_OWORD *)v16 = *(_OWORD *)&v14.ai_flags; /*0x102fbb49d*/
    ai_flags = v14.ai_flags; /*0x102fbb4a1*/
    *(_OWORD *)&v14.ai_flags = 0; /*0x102fbb4a7*/
    if ( (ai_flags & 1) != 0 ) /*0x102fbb4ad*/
      goto LABEL_24; /*0x102fbb4ad*/
    goto LABEL_12; /*0x102fbb4ad*/
  }
  v5 = *(_DWORD *)&v15->ai_addr->sa_data[2]; /*0x102fbb415*/
  freeaddrinfo(a1: v15); /*0x102fbb419*/
  v6 = _byteswap_ulong(v5); /*0x102fbb41e*/
  v7 = 0; /*0x102fbb421*/
  do /*0x102fbb447*/
  {
    isBlockedIpV6 = RBX::IpV4Subnet::contains(this: (RBX::IpV4Subnet *)((char *)&RBX::kIpV4Blocked + v7), a2: v6); /*0x102fbb437*/
    v10 = v7 == 120; /*0x102fbb439*/
    v7 += 12; /*0x102fbb43d*/
  }
  while ( ((unsigned __int8)isBlockedIpV6 | v10) == 0 ); /*0x102fbb447*/
LABEL_27:
  if ( (v16[0] & 1) != 0 ) /*0x102fbb4e6*/
    operator delete(a1: (RBX::Memory *)v17, a2: v9); /*0x102fbb4ec*/
  return isBlockedIpV6; /*0x102fbb4f3*/
}

// Address: 0x102fbb522 | Name: __ZN3RBXL13isBlockedIpV6EPh
char __fastcall RBX::isBlockedIpV6(RBX *this, unsigned __int8 *a2)
{
  __int64 i; // r14
  __int64 v4; // r14
  char result; // al
  unsigned int v6; // ebx
  __int64 v7; // r14
  bool v8; // zf

  for ( i = 0; i != 95; i += 19 ) /*0x102fbb52f*/
  {
    if ( (unsigned __int8)RBX::IpV6Subnet::contains( /*0x102fbb547*/
                            this: (RBX::IpV6Subnet *)((char *)&RBX::kIpV6Blocked + i),
                            a2: (const unsigned __int8 *)this) != 0 )
      return 1; /*0x102fbb57b*/
  }
  v4 = 0; /*0x102fbb553*/
  while ( (unsigned __int8)RBX::IpV6Subnet::contains( /*0x102fbb56b*/
                             this: (RBX::IpV6Subnet *)((char *)&RBX::kIpV6Mapped + v4),
                             a2: (const unsigned __int8 *)this) == 0 )
  {
    v4 += 19; /*0x102fbb56d*/
    if ( v4 == 76 ) /*0x102fbb575*/
      return 0; /*0x102fbb579*/
  }
  v6 = _byteswap_ulong(*((_DWORD *)this + 3)); /*0x102fbb58b*/
  v7 = 0; /*0x102fbb58d*/
  do /*0x102fbb5b1*/
  {
    result = RBX::IpV4Subnet::contains(this: (RBX::IpV4Subnet *)((char *)&RBX::kIpV4Blocked + v7), a2: v6); /*0x102fbb59d*/
    if ( result != 0 ) /*0x102fbb5a4*/
      break; /*0x102fbb5a4*/
    v8 = v7 == 120; /*0x102fbb5aa*/
    v7 += 12; /*0x102fbb5ae*/
  }
  while ( !v8 ); /*0x102fbb5b1*/
  return result; /*0x102fbb581*/
}

// Address: 0x102fc3a46 | Name: __ZN3RBX21intrusive_ptr_add_refEPKNS_20HttpRequestMsxmlImplE
void RBX::intrusive_ptr_add_ref()
{
  ; /*0x102fc3a46*/
}

// Address: 0x102fc3a4c | Name: __ZN3RBX21intrusive_ptr_releaseEPKNS_20HttpRequestMsxmlImplE
void RBX::intrusive_ptr_release()
{
  ; /*0x102fc3a4c*/
}

// Address: 0x103225c36 | Name: __ZN3RBX21intersectLinePlaneOldERKNS_3RayERKNS_5PlaneERNS_7Vector3E
char __fastcall RBX::intersectLinePlaneOld(RBX *this, const RBX::Ray *a2, const RBX::Plane *a3, RBX::Vector3 *a4)
{
  RBX::Vector3 *v7; // rcx
  char result; // al
  __m128 v9; // xmm0
  float v10; // xmm2_4
  _DWORD v11[3]; // [rsp+0h] [rbp-30h] BYREF
  double v12[4]; // [rsp+Ch] [rbp-24h] BYREF

  v7 = (RBX::Vector3 *)(unsigned int)RBX::Math::intersectRayPlane(this, a2, a3, a4); /*0x103225c51*/
  result = 1; /*0x103225c53*/
  if ( (_BYTE)v7 == 0 ) /*0x103225c57*/
  {
    v9 = _mm_xor_ps((__m128)*(unsigned __int64 *)((char *)this + 12), *(__m128 *)&xmmword_108F246C0); /*0x103225c66*/
    v10 = -*((float *)this + 5); /*0x103225c6f*/
    v11[2] = *((_DWORD *)this + 2); /*0x103225c7a*/
    *(_QWORD *)v11 = *(_QWORD *)this; /*0x103225c80*/
    _mm_storel_ps(v12, v9); /*0x103225c83*/
    *(float *)&v12[1] = v10; /*0x103225c87*/
    result = RBX::Math::intersectRayPlane(this: (RBX::Math *)v11, a2, a3, a4: v7); /*0x103225c92*/
    if ( result == 0 ) /*0x103225c99*/
    {
      *(_QWORD *)a3 = 0x7F8000007F800000LL; /*0x103225ca3*/
      *((_DWORD *)a3 + 2) = 2139095040; /*0x103225ca7*/
    }
  }
  return result; /*0x103225cae*/
}

// Address: 0x1034abcba | Name: __ZN3RBX20IndexedPriorityQueueImNS_13AssetProvider6detail19AssetDeliveryReqPtrENSt3__14lessIS3_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS4_6vectorINS4_4pairImS3_EENS4_9allocatorISG_EEEEE16insert_or_assignERKmRKS3_
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::insert_or_assign(
        __int64 a1,
        __int64 a2,
        __int64 a3)
{
  unsigned int v6; // r12d
  _BYTE v8[40]; // [rsp+8h] [rbp-28h] BYREF

  v6 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::LookupBucketFor<unsigned long>( /*0x1034abcdf*/
         a1: a1 + 24,
         a2,
         a3: v8);
  if ( (_BYTE)v6 != 0 ) /*0x1034abce4*/
    RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::remove( /*0x1034abcec*/
      a1,
      a2);
  LOBYTE(v6) = v6 ^ 1; /*0x1034abcf1*/
  RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::insert( /*0x1034abcfe*/
    a1,
    a2,
    a3);
  return v6; /*0x1034abd06*/
}

// Address: 0x1034abd7a | Name: __ZN3RBX20IndexedPriorityQueueImNS_13AssetProvider6detail19AssetDeliveryReqPtrENSt3__14lessIS3_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS4_6vectorINS4_4pairImS3_EENS4_9allocatorISG_EEEEE6insertERKmRKS3_
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::insert(
        __int64 a1,
        __int64 *a2,
        __int128 *a3)
{
  __int64 v6; // rdi
  _BYTE *v7; // r14
  __int64 v8; // r8
  unsigned __int64 v9; // r15
  unsigned __int64 v10; // rax
  __int64 v11; // r15
  __int64 v12; // r15
  __int64 v13; // rax
  __int64 v14; // rsi
  __int64 v15; // r12
  __int64 v16; // rax
  __int64 v17; // rdx
  __int64 v18; // r12
  __int64 v19; // r13
  __int64 v20; // r12
  size_t v21; // rdx
  void *v22; // r13
  void *v23; // rsi
  RBX::Memory *v24; // rdi
  _BYTE v26[24]; // [rsp+8h] [rbp-58h] BYREF
  __int128 v27; // [rsp+20h] [rbp-40h]
  __int64 v28; // [rsp+30h] [rbp-30h]

  *(_QWORD *)&v27 = (__int64)(*(_QWORD *)(a1 + 8) - *(_QWORD *)a1) >> 5; /*0x1034abda7*/
  v7 = v26; /*0x1034abdaa*/
  RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::try_emplace<unsigned long>( /*0x1034abdb4*/
    a1: v26,
    a2: a1 + 24,
    a3: a2);
  LOBYTE(v7) = v26[16]; /*0x1034abdb9*/
  if ( v26[16] == 1 ) /*0x1034abdc1*/
  {
    v8 = *a2; /*0x1034abdc7*/
    v28 = *((_QWORD *)a3 + 2); /*0x1034abdcf*/
    v27 = *a3; /*0x1034abdd7*/
    v9 = *(_QWORD *)(a1 + 8); /*0x1034abddb*/
    v10 = *(_QWORD *)(a1 + 16); /*0x1034abddf*/
    if ( v9 >= v10 ) /*0x1034abde6*/
    {
      v12 = (__int64)(v9 - *(_QWORD *)a1) >> 5; /*0x1034abe0b*/
      if ( (unsigned __int64)(v12 + 1) >> 59 != 0 ) /*0x1034abe1a*/
        std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>::__throw_length_error[abi:ne200100]( /*0x1034abeed*/
          a1: v6,
          a2: (unsigned __int64)(v12 + 1) >> 59);
      v13 = v10 - *(_QWORD *)a1; /*0x1034abe2a*/
      v14 = v13 >> 4; /*0x1034abe30*/
      if ( v13 >> 4 <= (unsigned __int64)(v12 + 1) ) /*0x1034abe37*/
        v14 = v12 + 1; /*0x1034abe37*/
      if ( (unsigned __int64)v13 >= 0x7FFFFFFFFFFFFFE0LL ) /*0x1034abe48*/
        v14 = 0x7FFFFFFFFFFFFFFLL; /*0x1034abe48*/
      if ( v14 != 0 ) /*0x1034abe4f*/
      {
        v15 = v8; /*0x1034abe55*/
        v16 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>(a1: a1 + 16); /*0x1034abe58*/
        v8 = v15; /*0x1034abe5d*/
        v18 = v17; /*0x1034abe60*/
      }
      else
      {
        v16 = 0; /*0x1034abe65*/
        v18 = 0; /*0x1034abe67*/
      }
      v19 = v16 + 32 * v12; /*0x1034abe6e*/
      v20 = v16 + 32 * v18; /*0x1034abe76*/
      v11 = v19 + 32; /*0x1034abe7c*/
      *(_QWORD *)v19 = v8; /*0x1034abe80*/
      *(_OWORD *)(v19 + 8) = v27; /*0x1034abe88*/
      *(_QWORD *)(v19 + 24) = v28; /*0x1034abe91*/
      v21 = *(_QWORD *)(a1 + 8) - *(_QWORD *)a1; /*0x1034abe9c*/
      v22 = (void *)(v19 - v21); /*0x1034abe9f*/
      memcpy(__dst: v22, __src: *(const void **)a1, __n: v21); /*0x1034abea5*/
      v24 = *(RBX::Memory **)a1; /*0x1034abeaa*/
      *(_QWORD *)a1 = v22; /*0x1034abead*/
      *(_QWORD *)(a1 + 8) = v11; /*0x1034abeb0*/
      *(_QWORD *)(a1 + 16) = v20; /*0x1034abeb4*/
      if ( v24 != nullptr ) /*0x1034abebb*/
        operator delete(a1: v24, a2: v23); /*0x1034abebd*/
    }
    else
    {
      *(_QWORD *)v9 = v8; /*0x1034abde8*/
      *(_OWORD *)(v9 + 8) = v27; /*0x1034abdef*/
      *(_QWORD *)(v9 + 24) = v28; /*0x1034abdf8*/
      v11 = v9 + 32; /*0x1034abdfc*/
    }
    *(_QWORD *)(a1 + 8) = v11; /*0x1034abec2*/
    RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::bubbleUp( /*0x1034abed6*/
      a1,
      a2: ((v11 - *(_QWORD *)a1) >> 5) - 1);
  }
  return (unsigned int)v7; /*0x1034abede*/
}

// Address: 0x1034abef2 | Name: __ZN3RBX20IndexedPriorityQueueImNS_4TimeENSt3__14lessIS1_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS2_6vectorINS2_4pairImS1_EENS2_9allocatorISE_EEEEE6insertERKmRKS1_
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::less<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::insert(
        RBX::Memory **a1,
        __int64 *a2,
        double *a3)
{
  __int64 v6; // r8
  _BYTE *v7; // r14
  __int64 v8; // r9
  double v9; // xmm0_8
  double *v10; // rdx
  unsigned __int64 v11; // rcx
  RBX::Memory *v12; // r12
  RBX::Memory *v13; // rsi
  signed __int64 v14; // rdx
  __int64 v15; // r12
  unsigned __int64 v16; // rdi
  __int64 v17; // rcx
  __int64 v18; // rax
  __int64 v19; // r15
  __int64 v20; // rax
  __int64 v21; // rdx
  __int64 v22; // r15
  __int64 v23; // rcx
  double *v24; // r13
  __int64 v25; // r15
  double *v26; // r13
  void *v27; // rsi
  RBX::Memory *v28; // rdi
  _BYTE v30[24]; // [rsp+0h] [rbp-50h] BYREF
  __int64 v31; // [rsp+18h] [rbp-38h]
  double v32; // [rsp+20h] [rbp-30h]

  v31 = (a1[1] - *a1) >> 4; /*0x1034abf1f*/
  v7 = v30; /*0x1034abf22*/
  RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::try_emplace<unsigned long>( /*0x1034abf2c*/
    a1: v30,
    a2: a1 + 3,
    a3: a2);
  LOBYTE(v7) = v30[16]; /*0x1034abf31*/
  if ( v30[16] == 1 ) /*0x1034abf39*/
  {
    v8 = *a2; /*0x1034abf3f*/
    v9 = *a3; /*0x1034abf43*/
    v10 = (double *)a1[1]; /*0x1034abf48*/
    v11 = (unsigned __int64)a1[2]; /*0x1034abf4c*/
    if ( (unsigned __int64)v10 >= v11 ) /*0x1034abf53*/
    {
      v13 = *a1; /*0x1034abf69*/
      v14 = (char *)v10 - (char *)*a1; /*0x1034abf6c*/
      v15 = v14 >> 4; /*0x1034abf72*/
      v16 = (v14 >> 4) + 1; /*0x1034abf76*/
      if ( v16 >> 60 != 0 ) /*0x1034abf82*/
        std::vector<std::pair<unsigned long,RBX::Time>>::__throw_length_error[abi:ne200100]( /*0x1034ac067*/
          a1: v16,
          a2: v13,
          a3: v14,
          a4: v11,
          a5: v6,
          a6: v8,
          a7: v9);
      v17 = v11 - (_QWORD)v13; /*0x1034abf92*/
      v18 = v17 >> 3; /*0x1034abf98*/
      if ( v17 >> 3 <= v16 ) /*0x1034abf9f*/
        v18 = (v14 >> 4) + 1; /*0x1034abf9f*/
      if ( (unsigned __int64)v17 >= 0x7FFFFFFFFFFFFFF0LL ) /*0x1034abfb0*/
        v18 = 0xFFFFFFFFFFFFFFFLL; /*0x1034abfb0*/
      if ( v18 != 0 ) /*0x1034abfb7*/
      {
        v32 = *a3; /*0x1034abfc0*/
        v19 = v8; /*0x1034abfc5*/
        v20 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<unsigned long,RBX::Time>>>( /*0x1034abfc8*/
                a1: a1 + 2,
                a2: v18,
                a3: v14,
                a4: v17,
                a5: 0xFFFFFFFFFFFFFFFLL);
        v8 = v19; /*0x1034abfcd*/
        v9 = v32; /*0x1034abfd0*/
        v22 = v21; /*0x1034abfd5*/
        v13 = *a1; /*0x1034abfd8*/
        v14 = a1[1] - *a1; /*0x1034abfdf*/
        v23 = v14 >> 4; /*0x1034abfe5*/
      }
      else
      {
        v20 = 0; /*0x1034abfeb*/
        v23 = v14 >> 4; /*0x1034abfed*/
        v22 = 0; /*0x1034abff0*/
      }
      v24 = (double *)(v20 + 16 * v15); /*0x1034abff7*/
      v25 = v20 + 16 * v22; /*0x1034abfff*/
      v12 = (RBX::Memory *)(v24 + 2); /*0x1034ac005*/
      *(_QWORD *)v24 = v8; /*0x1034ac009*/
      v24[1] = v9; /*0x1034ac00e*/
      v26 = &v24[-2 * v23]; /*0x1034ac019*/
      memcpy(__dst: v26, __src: v13, __n: v14); /*0x1034ac01f*/
      v28 = *a1; /*0x1034ac024*/
      *a1 = (RBX::Memory *)v26; /*0x1034ac027*/
      a1[1] = v12; /*0x1034ac02a*/
      a1[2] = (RBX::Memory *)v25; /*0x1034ac02e*/
      if ( v28 != nullptr ) /*0x1034ac035*/
        operator delete(a1: v28, a2: v27); /*0x1034ac037*/
    }
    else
    {
      *(_QWORD *)v10 = v8; /*0x1034abf55*/
      v10[1] = v9; /*0x1034abf58*/
      v12 = (RBX::Memory *)(v10 + 2); /*0x1034abf61*/
    }
    a1[1] = v12; /*0x1034ac03c*/
    RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::less<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::bubbleUp( /*0x1034ac050*/
      a1,
      a2: ((v12 - *a1) >> 4) - 1);
  }
  return (unsigned int)v7; /*0x1034ac058*/
}

// Address: 0x1034ac06c | Name: __ZN3RBX20IndexedPriorityQueueImNS_4TimeENSt3__17greaterIS1_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS2_6vectorINS2_4pairImS1_EENS2_9allocatorISE_EEEEE6insertERKmRKS1_
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::greater<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::insert(
        RBX::Memory **a1,
        __int64 *a2,
        double *a3)
{
  __int64 v6; // r8
  _BYTE *v7; // r14
  __int64 v8; // r9
  double v9; // xmm0_8
  double *v10; // rdx
  unsigned __int64 v11; // rcx
  RBX::Memory *v12; // r12
  RBX::Memory *v13; // rsi
  signed __int64 v14; // rdx
  __int64 v15; // r12
  unsigned __int64 v16; // rdi
  __int64 v17; // rcx
  __int64 v18; // rax
  __int64 v19; // r15
  __int64 v20; // rax
  __int64 v21; // rdx
  __int64 v22; // r15
  __int64 v23; // rcx
  double *v24; // r13
  __int64 v25; // r15
  double *v26; // r13
  void *v27; // rsi
  RBX::Memory *v28; // rdi
  _BYTE v30[24]; // [rsp+0h] [rbp-50h] BYREF
  __int64 v31; // [rsp+18h] [rbp-38h]
  double v32; // [rsp+20h] [rbp-30h]

  v31 = (a1[1] - *a1) >> 4; /*0x1034ac099*/
  v7 = v30; /*0x1034ac09c*/
  RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::try_emplace<unsigned long>( /*0x1034ac0a6*/
    a1: v30,
    a2: a1 + 3,
    a3: a2);
  LOBYTE(v7) = v30[16]; /*0x1034ac0ab*/
  if ( v30[16] == 1 ) /*0x1034ac0b3*/
  {
    v8 = *a2; /*0x1034ac0b9*/
    v9 = *a3; /*0x1034ac0bd*/
    v10 = (double *)a1[1]; /*0x1034ac0c2*/
    v11 = (unsigned __int64)a1[2]; /*0x1034ac0c6*/
    if ( (unsigned __int64)v10 >= v11 ) /*0x1034ac0cd*/
    {
      v13 = *a1; /*0x1034ac0e3*/
      v14 = (char *)v10 - (char *)*a1; /*0x1034ac0e6*/
      v15 = v14 >> 4; /*0x1034ac0ec*/
      v16 = (v14 >> 4) + 1; /*0x1034ac0f0*/
      if ( v16 >> 60 != 0 ) /*0x1034ac0fc*/
        std::vector<std::pair<unsigned long,RBX::Time>>::__throw_length_error[abi:ne200100]( /*0x1034ac1e1*/
          a1: v16,
          a2: v13,
          a3: v14,
          a4: v11,
          a5: v6,
          a6: v8,
          a7: v9);
      v17 = v11 - (_QWORD)v13; /*0x1034ac10c*/
      v18 = v17 >> 3; /*0x1034ac112*/
      if ( v17 >> 3 <= v16 ) /*0x1034ac119*/
        v18 = (v14 >> 4) + 1; /*0x1034ac119*/
      if ( (unsigned __int64)v17 >= 0x7FFFFFFFFFFFFFF0LL ) /*0x1034ac12a*/
        v18 = 0xFFFFFFFFFFFFFFFLL; /*0x1034ac12a*/
      if ( v18 != 0 ) /*0x1034ac131*/
      {
        v32 = *a3; /*0x1034ac13a*/
        v19 = v8; /*0x1034ac13f*/
        v20 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<unsigned long,RBX::Time>>>( /*0x1034ac142*/
                a1: a1 + 2,
                a2: v18,
                a3: v14,
                a4: v17,
                a5: 0xFFFFFFFFFFFFFFFLL);
        v8 = v19; /*0x1034ac147*/
        v9 = v32; /*0x1034ac14a*/
        v22 = v21; /*0x1034ac14f*/
        v13 = *a1; /*0x1034ac152*/
        v14 = a1[1] - *a1; /*0x1034ac159*/
        v23 = v14 >> 4; /*0x1034ac15f*/
      }
      else
      {
        v20 = 0; /*0x1034ac165*/
        v23 = v14 >> 4; /*0x1034ac167*/
        v22 = 0; /*0x1034ac16a*/
      }
      v24 = (double *)(v20 + 16 * v15); /*0x1034ac171*/
      v25 = v20 + 16 * v22; /*0x1034ac179*/
      v12 = (RBX::Memory *)(v24 + 2); /*0x1034ac17f*/
      *(_QWORD *)v24 = v8; /*0x1034ac183*/
      v24[1] = v9; /*0x1034ac188*/
      v26 = &v24[-2 * v23]; /*0x1034ac193*/
      memcpy(__dst: v26, __src: v13, __n: v14); /*0x1034ac199*/
      v28 = *a1; /*0x1034ac19e*/
      *a1 = (RBX::Memory *)v26; /*0x1034ac1a1*/
      a1[1] = v12; /*0x1034ac1a4*/
      a1[2] = (RBX::Memory *)v25; /*0x1034ac1a8*/
      if ( v28 != nullptr ) /*0x1034ac1af*/
        operator delete(a1: v28, a2: v27); /*0x1034ac1b1*/
    }
    else
    {
      *(_QWORD *)v10 = v8; /*0x1034ac0cf*/
      v10[1] = v9; /*0x1034ac0d2*/
      v12 = (RBX::Memory *)(v10 + 2); /*0x1034ac0db*/
    }
    a1[1] = v12; /*0x1034ac1b6*/
    RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::greater<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::bubbleUp( /*0x1034ac1ca*/
      a1,
      a2: ((v12 - *a1) >> 4) - 1);
  }
  return (unsigned int)v7; /*0x1034ac1d2*/
}

// Address: 0x1034ac560 | Name: __ZN3RBX20IndexedPriorityQueueImNS_13AssetProvider6detail19AssetDeliveryReqPtrENSt3__14lessIS3_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS4_6vectorINS4_4pairImS3_EENS4_9allocatorISG_EEEEE6removeERKm
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::remove(
        __int64 a1,
        __int64 a2)
{
  unsigned int v4; // r15d
  _BYTE v6[48]; // [rsp+0h] [rbp-30h] BYREF

  v4 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::LookupBucketFor<unsigned long>( /*0x1034ac580*/
         a1: a1 + 24,
         a2,
         a3: v6);
  if ( (_BYTE)v4 != 0 ) /*0x1034ac585*/
    RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::extract( /*0x1034ac591*/
      a1: v6,
      a2: a1,
      a3: a2);
  return v4; /*0x1034ac599*/
}

// Address: 0x1034c2a6c | Name: __ZN3RBX20IndexedPriorityQueueImNS_13AssetProvider6detail19AssetDeliveryReqPtrENSt3__14lessIS3_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS4_6vectorINS4_4pairImS3_EENS4_9allocatorISG_EEEEE7pop_minEv
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::pop_min(
        __int64 a1,
        __int64 **a2)
{
  __int64 v2; // rax
  __int64 v5; // [rsp+0h] [rbp-10h] BYREF

  v5 = v2; /*0x1034c2a71*/
  if ( *a2 == a2[1] ) /*0x1034c2a79*/
    RBXCRASH(a1: 0, a2: "Popping from empty IndexedPriorityQueue"); /*0x1034c2aa0*/
  v5 = **a2; /*0x1034c2a85*/
  RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::extract( /*0x1034c2a88*/
    a1,
    a2,
    a3: &v5);
  return a1; /*0x1034c2a94*/
}

// Address: 0x1034c2aa6 | Name: __ZN3RBX20IndexedPriorityQueueImNS_4TimeENSt3__14lessIS1_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS2_6vectorINS2_4pairImS1_EENS2_9allocatorISE_EEEEE6removeERKm
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::less<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::remove(
        __int64 a1,
        __int64 a2)
{
  __int64 v2; // rax
  unsigned int v5; // r15d
  _QWORD v7[4]; // [rsp+0h] [rbp-20h] BYREF

  v7[0] = v2; /*0x1034c2aaf*/
  v5 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::LookupBucketFor<unsigned long>( /*0x1034c2ac3*/
         a1: a1 + 24,
         a2,
         a3: v7);
  if ( (_BYTE)v5 != 0 ) /*0x1034c2ac8*/
    RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::less<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::extract( /*0x1034c2ad0*/
      a1,
      a2);
  return v5; /*0x1034c2adc*/
}

// Address: 0x1034c2ae4 | Name: __ZN3RBX20IndexedPriorityQueueImNS_4TimeENSt3__17greaterIS1_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS2_6vectorINS2_4pairImS1_EENS2_9allocatorISE_EEEEE6removeERKm
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::greater<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::remove(
        __int64 a1,
        __int64 a2)
{
  __int64 v2; // rax
  unsigned int v5; // r15d
  _QWORD v7[4]; // [rsp+0h] [rbp-20h] BYREF

  v7[0] = v2; /*0x1034c2aed*/
  v5 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::LookupBucketFor<unsigned long>( /*0x1034c2b01*/
         a1: a1 + 24,
         a2,
         a3: v7);
  if ( (_BYTE)v5 != 0 ) /*0x1034c2b06*/
    RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::greater<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::extract( /*0x1034c2b0e*/
      a1,
      a2);
  return v5; /*0x1034c2b1a*/
}

// Address: 0x1034c5216 | Name: __ZN3RBX20IndexedPriorityQueueImNS_13AssetProvider6detail19AssetDeliveryReqPtrENSt3__14lessIS3_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS4_6vectorINS4_4pairImS3_EENS4_9allocatorISG_EEEEE7extractERKm
_OWORD *__fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::extract(
        __int64 a1,
        __int64 *a2,
        __int64 a3)
{
  _QWORD *v5; // r13
  unsigned __int64 v6; // r15
  __int64 v7; // rax
  __int64 v8; // rsi
  __int128 v9; // xmm0
  __int64 v10; // rcx
  __int64 v11; // rdx
  __int64 v12; // rbx
  __int64 v13; // rax
  __int64 v14; // rcx
  _OWORD *result; // rax
  __m256i v16; // [rsp+0h] [rbp-70h] BYREF
  __int128 v17; // [rsp+20h] [rbp-50h]
  __int64 v18; // [rsp+30h] [rbp-40h]
  __int64 v19; // [rsp+40h] [rbp-30h]

  v19 = a1; /*0x1034c522d*/
  v5 = a2 + 3; /*0x1034c5231*/
  if ( (unsigned __int8)RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::LookupBucketFor<unsigned long>( /*0x1034c5246*/
                          a1: a2 + 3,
                          a2: a3,
                          a3: &v16) == 0 )
    RBXCRASH(a1: 0, a2: "Extracting non-existent key from IndexedPriorityQueue"); /*0x1034c5365*/
  v6 = *(_QWORD *)(RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c5257*/
                     a1: v5,
                     a2: a3)
                 + 8);
  v7 = *a2; /*0x1034c525b*/
  v8 = 32 * v6; /*0x1034c5261*/
  v9 = *(_OWORD *)(*a2 + 32 * v6); /*0x1034c5265*/
  v16.i128[1] = *(_OWORD *)(*a2 + 32 * v6 + 16); /*0x1034c526e*/
  v16.i128[0] = v9; /*0x1034c5272*/
  v10 = a2[1]; /*0x1034c5276*/
  v11 = *(_QWORD *)(v7 + 32 * v6); /*0x1034c527a*/
  *(_QWORD *)(v7 + v8) = *(_QWORD *)(v10 - 32); /*0x1034c5282*/
  *(_QWORD *)(v10 - 32) = v11; /*0x1034c5286*/
  v18 = *(_QWORD *)(v7 + 32 * v6 + 24); /*0x1034c528f*/
  v17 = *(_OWORD *)(v7 + 32 * v6 + 8); /*0x1034c5298*/
  *(_QWORD *)(v7 + v8 + 24) = *(_QWORD *)(v10 - 8); /*0x1034c52a0*/
  *(_OWORD *)(v7 + v8 + 8) = *(_OWORD *)(v10 - 24); /*0x1034c52a9*/
  *(_QWORD *)(v10 - 8) = v18; /*0x1034c52b2*/
  *(_OWORD *)(v10 - 24) = v17; /*0x1034c52ba*/
  v12 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c52c9*/
          a1: v5,
          a2: *a2 + 32 * v6);
  v13 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c52d7*/
          a1: v5,
          a2: a2[1] - 32);
  v14 = *(_QWORD *)(v12 + 8); /*0x1034c52dc*/
  *(_QWORD *)(v12 + 8) = *(_QWORD *)(v13 + 8); /*0x1034c52e4*/
  *(_QWORD *)(v13 + 8) = v14; /*0x1034c52e8*/
  a2[1] -= 32; /*0x1034c52ec*/
  RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::erase( /*0x1034c52f7*/
    a1: v5,
    a2: a3);
  if ( FFlag::g_flagsLoaded != 1 || DFFlag::CLI207421 != 1 ) /*0x1034c5312*/
    goto LABEL_6; /*0x1034c5312*/
  if ( v6 < (a2[1] - *a2) >> 5 ) /*0x1034c5322*/
  {
    RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::bubbleUp( /*0x1034c532a*/
      a1: a2,
      a2: v6);
LABEL_6:
    RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::bubbleDown( /*0x1034c532f*/
      a1: a2,
      a2: v6);
  }
  result = (_OWORD *)v19; /*0x1034c533a*/
  *(_QWORD *)(v19 + 16) = v16.i64[3]; /*0x1034c5342*/
  *result = *(__int128 *)((char *)v16.i128 + 8); /*0x1034c534a*/
  return result; /*0x1034c534d*/
}

// Address: 0x1034c53a4 | Name: __ZN3RBX20IndexedPriorityQueueImNS_13AssetProvider6detail19AssetDeliveryReqPtrENSt3__14lessIS3_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS4_6vectorINS4_4pairImS3_EENS4_9allocatorISG_EEEEE8bubbleUpEm
void __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::bubbleUp(
        __int64 *a1,
        unsigned __int64 a2)
{
  unsigned __int64 v2; // r15
  _QWORD *v3; // rbx
  __int64 v4; // r13
  __int64 v5; // rdi
  unsigned __int64 v6; // r14
  __int64 v7; // r12
  __int64 v8; // rax
  __int64 v9; // rcx
  __int64 v10; // r13
  __int64 v11; // rax
  __int64 v12; // rcx
  __int128 v13; // [rsp+0h] [rbp-50h]
  __int64 v14; // [rsp+10h] [rbp-40h]

  if ( a2 != 0 ) /*0x1034c53bc*/
  {
    v2 = a2; /*0x1034c53c2*/
    v3 = a1 + 3; /*0x1034c53d1*/
    do /*0x1034c54a0*/
    {
      v4 = 32 * v2; /*0x1034c53df*/
      v5 = *a1 + 32 * v2 + 8; /*0x1034c53e7*/
      v6 = v2 - 1; /*0x1034c53ee*/
      v2 = (v2 - 1) >> 1; /*0x1034c53f4*/
      v7 = 32 * v2; /*0x1034c53fa*/
      if ( (unsigned __int8)RBX::AssetProvider::detail::AssetDeliveryReqPtr::operator<(a1: v5, a2: *a1 + 32 * v2 + 8) == 0 ) /*0x1034c540d*/
        break; /*0x1034c540d*/
      v8 = *a1; /*0x1034c5417*/
      v9 = *(_QWORD *)(*a1 + v4); /*0x1034c541d*/
      *(_QWORD *)(v8 + v4) = *(_QWORD *)(*a1 + 32 * v2); /*0x1034c5425*/
      *(_QWORD *)(v8 + 32 * v2) = v9; /*0x1034c5429*/
      v14 = *(_QWORD *)(v8 + v4 + 24); /*0x1034c5432*/
      v13 = *(_OWORD *)(v8 + v4 + 8); /*0x1034c543c*/
      *(_QWORD *)(v8 + v4 + 24) = *(_QWORD *)(v8 + v7 + 24); /*0x1034c5445*/
      *(_OWORD *)(v8 + v4 + 8) = *(_OWORD *)(v8 + v7 + 8); /*0x1034c5450*/
      *(_QWORD *)(v8 + v7 + 24) = v14; /*0x1034c545a*/
      *(_OWORD *)(v8 + v7 + 8) = v13; /*0x1034c5463*/
      v10 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c5477*/
              a1: v3,
              a2: *a1 + v4);
      v11 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c5487*/
              a1: v3,
              a2: *a1 + v7);
      v12 = *(_QWORD *)(v10 + 8); /*0x1034c548c*/
      *(_QWORD *)(v10 + 8) = *(_QWORD *)(v11 + 8); /*0x1034c5494*/
      *(_QWORD *)(v11 + 8) = v12; /*0x1034c5498*/
    }
    while ( v6 > 1 ); /*0x1034c54a0*/
  }
}

// Address: 0x1034c54b6 | Name: __ZN3RBX20IndexedPriorityQueueImNS_13AssetProvider6detail19AssetDeliveryReqPtrENSt3__14lessIS3_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS4_6vectorINS4_4pairImS3_EENS4_9allocatorISG_EEEEE10bubbleDownEm
void __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr,std::less<RBX::AssetProvider::detail::AssetDeliveryReqPtr>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::AssetProvider::detail::AssetDeliveryReqPtr>>>::bubbleDown(
        __int64 *a1,
        unsigned __int64 a2)
{
  unsigned __int64 v2; // r13
  unsigned __int64 v3; // r15
  unsigned __int64 v4; // r12
  unsigned __int64 v5; // r14
  __int64 v6; // rax
  __int64 v7; // r15
  __int64 v8; // r12
  __int64 v9; // rcx
  __int64 v10; // r15
  __int64 v11; // rax
  __int64 v12; // rcx
  __int128 v13; // [rsp+0h] [rbp-60h]
  __int64 v14; // [rsp+10h] [rbp-50h]
  _QWORD *v15; // [rsp+20h] [rbp-40h]
  unsigned __int64 v16; // [rsp+28h] [rbp-38h]

  v2 = (a1[1] - *a1) >> 5; /*0x1034c54d2*/
  if ( v2 > a2 ) /*0x1034c54d9*/
  {
    v3 = a2; /*0x1034c54df*/
    v15 = a1 + 3; /*0x1034c54ea*/
    v16 = (a1[1] - *a1) >> 5; /*0x1034c54ee*/
    do /*0x1034c5612*/
    {
      v4 = 2 * v3 + 1; /*0x1034c54f6*/
      if ( v4 >= v2 /*0x1034c552f*/
        || (unsigned __int8)RBX::AssetProvider::detail::AssetDeliveryReqPtr::operator<(
                              a1: *a1 + 32 * v4 + 8,
                              a2: *a1 + 32 * v3 + 8) == 0 )
      {
        v4 = v3; /*0x1034c5531*/
      }
      v5 = 2 * v3 + 2; /*0x1034c5538*/
      if ( v5 >= v2 /*0x1034c556d*/
        || (unsigned __int8)RBX::AssetProvider::detail::AssetDeliveryReqPtr::operator<(
                              a1: *a1 + 32 * v5 + 8,
                              a2: *a1 + 32 * v4 + 8) == 0 )
      {
        v5 = v4; /*0x1034c556f*/
      }
      if ( v5 == v3 ) /*0x1034c5575*/
        break; /*0x1034c5575*/
      v6 = *a1; /*0x1034c557b*/
      v7 = 32 * v3; /*0x1034c557e*/
      v8 = 32 * v5; /*0x1034c5585*/
      v9 = *(_QWORD *)(*a1 + v7); /*0x1034c5589*/
      *(_QWORD *)(v6 + v7) = *(_QWORD *)(*a1 + 32 * v5); /*0x1034c5591*/
      *(_QWORD *)(v6 + v8) = v9; /*0x1034c5595*/
      v14 = *(_QWORD *)(v6 + v7 + 24); /*0x1034c559e*/
      v13 = *(_OWORD *)(v6 + v7 + 8); /*0x1034c55a8*/
      *(_QWORD *)(v6 + v7 + 24) = *(_QWORD *)(v6 + 32 * v5 + 24); /*0x1034c55b1*/
      *(_OWORD *)(v6 + v7 + 8) = *(_OWORD *)(v6 + 32 * v5 + 8); /*0x1034c55bc*/
      *(_QWORD *)(v6 + v8 + 24) = v14; /*0x1034c55c6*/
      *(_OWORD *)(v6 + v8 + 8) = v13; /*0x1034c55cf*/
      v10 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c55e7*/
              a1: v15,
              a2: *a1 + v7);
      v2 = v16; /*0x1034c55f0*/
      v11 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c55f7*/
              a1: v15,
              a2: *a1 + 32 * v5);
      v12 = *(_QWORD *)(v10 + 8); /*0x1034c55fc*/
      *(_QWORD *)(v10 + 8) = *(_QWORD *)(v11 + 8); /*0x1034c5604*/
      *(_QWORD *)(v11 + 8) = v12; /*0x1034c5608*/
      v3 = v5; /*0x1034c560c*/
    }
    while ( v5 < v16 ); /*0x1034c5612*/
  }
}

// Address: 0x1034c5628 | Name: __ZN3RBX20IndexedPriorityQueueImNS_4TimeENSt3__14lessIS1_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS2_6vectorINS2_4pairImS1_EENS2_9allocatorISE_EEEEE7extractERKm
double __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::less<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::extract(
        _QWORD *a1,
        __int64 a2)
{
  _QWORD *v4; // r12
  unsigned __int64 v5; // r14
  __int64 v6; // rdx
  double *v7; // rsi
  double v8; // xmm1_8
  double v9; // rdi
  __int64 v10; // r13
  __int64 v11; // rax
  __int64 v12; // rcx
  char v14[8]; // [rsp+8h] [rbp-38h] BYREF
  double v15; // [rsp+10h] [rbp-30h]

  v4 = a1 + 3; /*0x1034c563f*/
  if ( (unsigned __int8)RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::LookupBucketFor<unsigned long>( /*0x1034c5651*/
                          a1: a1 + 3,
                          a2,
                          a3: v14) == 0 )
    RBXCRASH(a1: 0, a2: "Extracting non-existent key from IndexedPriorityQueue"); /*0x1034c572e*/
  v5 = *(_QWORD *)(RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c5662*/
                     a1: v4,
                     a2)
                 + 8);
  v6 = a1[1]; /*0x1034c5670*/
  v7 = (double *)(*a1 + 16 * v5); /*0x1034c5674*/
  v8 = v7[1]; /*0x1034c5678*/
  v9 = *v7; /*0x1034c567e*/
  *(_OWORD *)v7 = *(_OWORD *)(v6 - 16); /*0x1034c5686*/
  *(double *)(v6 - 16) = v9; /*0x1034c568a*/
  v15 = v8; /*0x1034c568e*/
  *(double *)(v6 - 8) = v8; /*0x1034c5693*/
  v10 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c56a0*/
          a1: v4,
          a2: v7);
  v11 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c56ae*/
          a1: v4,
          a2: a1[1] - 16LL);
  v12 = *(_QWORD *)(v10 + 8); /*0x1034c56b3*/
  *(_QWORD *)(v10 + 8) = *(_QWORD *)(v11 + 8); /*0x1034c56bb*/
  *(_QWORD *)(v11 + 8) = v12; /*0x1034c56bf*/
  a1[1] -= 16LL; /*0x1034c56c3*/
  RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::erase( /*0x1034c56ce*/
    a1: v4,
    a2);
  if ( FFlag::g_flagsLoaded != 1 || DFFlag::CLI207421 != 1 ) /*0x1034c56e9*/
    goto LABEL_6; /*0x1034c56e9*/
  if ( v5 < (__int64)(a1[1] - *a1) >> 4 ) /*0x1034c56f9*/
  {
    RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::less<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::bubbleUp( /*0x1034c5701*/
      a1,
      a2: v5);
LABEL_6:
    RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::less<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::bubbleDown( /*0x1034c5706*/
      a1,
      a2: v5);
  }
  return v15; /*0x1034c5716*/
}

// Address: 0x1034c5734 | Name: __ZN3RBX20IndexedPriorityQueueImNS_4TimeENSt3__14lessIS1_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS2_6vectorINS2_4pairImS1_EENS2_9allocatorISE_EEEEE8bubbleUpEm
void __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::less<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::bubbleUp(
        __int64 *a1,
        unsigned __int64 a2)
{
  unsigned __int64 v2; // rbx
  _QWORD *v3; // r15
  __int64 v4; // rax
  __int64 v5; // rsi
  unsigned __int64 v6; // r14
  __int64 v7; // r12
  double v8; // xmm0_8
  double v9; // xmm1_8
  double *v10; // rsi
  double *v11; // rax
  double v12; // rcx
  __int64 v13; // r13
  __int64 v14; // rax
  __int64 v15; // rcx

  if ( a2 != 0 ) /*0x1034c5749*/
  {
    v2 = a2; /*0x1034c574f*/
    v3 = a1 + 3; /*0x1034c5756*/
    do /*0x1034c57db*/
    {
      v4 = *a1; /*0x1034c575e*/
      v5 = 16 * v2; /*0x1034c5764*/
      v6 = v2 - 1; /*0x1034c576b*/
      v2 = (v2 - 1) >> 1; /*0x1034c5771*/
      v7 = 16 * v2; /*0x1034c5777*/
      v8 = *(double *)(*a1 + v5 + 8); /*0x1034c577b*/
      v9 = *(double *)(*a1 + 16 * v2 + 8); /*0x1034c5781*/
      if ( v9 <= v8 ) /*0x1034c578c*/
        break; /*0x1034c578c*/
      v10 = (double *)(v4 + v5); /*0x1034c578e*/
      v11 = (double *)(v7 + v4); /*0x1034c5791*/
      v12 = *v10; /*0x1034c5794*/
      *v10 = *v11; /*0x1034c579a*/
      *v11 = v12; /*0x1034c579d*/
      v10[1] = v9; /*0x1034c57a0*/
      v11[1] = v8; /*0x1034c57a5*/
      v13 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c57b2*/
              a1: v3,
              a2: v10);
      v14 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c57c2*/
              a1: v3,
              a2: *a1 + v7);
      v15 = *(_QWORD *)(v13 + 8); /*0x1034c57c7*/
      *(_QWORD *)(v13 + 8) = *(_QWORD *)(v14 + 8); /*0x1034c57cf*/
      *(_QWORD *)(v14 + 8) = v15; /*0x1034c57d3*/
    }
    while ( v6 > 1 ); /*0x1034c57db*/
  }
}

// Address: 0x1034c57f0 | Name: __ZN3RBX20IndexedPriorityQueueImNS_4TimeENSt3__14lessIS1_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS2_6vectorINS2_4pairImS1_EENS2_9allocatorISE_EEEEE10bubbleDownEm
void __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::less<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::bubbleDown(
        __int64 *a1,
        unsigned __int64 a2)
{
  unsigned __int64 v2; // r8
  _QWORD *v3; // rbx
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // r14
  __int64 v6; // rcx
  __int64 *v7; // rax
  __int64 v8; // r15
  __int64 v9; // rdx
  __int64 v10; // xmm0_8
  __int64 v11; // r12
  __int64 v12; // rax
  __int64 v13; // rcx
  unsigned __int64 v14; // [rsp+8h] [rbp-38h]

  v2 = (a1[1] - *a1) >> 4; /*0x1034c580c*/
  if ( v2 > a2 ) /*0x1034c5813*/
  {
    v14 = (a1[1] - *a1) >> 4; /*0x1034c5825*/
    v3 = a1 + 3; /*0x1034c582d*/
    do /*0x1034c5906*/
    {
      v4 = 2 * a2 + 1; /*0x1034c5831*/
      if ( v4 >= v2 || *(double *)(*a1 + 16 * a2 + 8) <= *(double *)(*a1 + 16 * v4 + 8) ) /*0x1034c585f*/
        v4 = a2; /*0x1034c5861*/
      v5 = 2 * a2 + 2; /*0x1034c5868*/
      if ( v5 >= v2 || *(double *)(*a1 + 16 * v4 + 8) <= *(double *)(*a1 + 16 * v5 + 8) ) /*0x1034c5892*/
        v5 = v4; /*0x1034c5894*/
      if ( v5 == a2 ) /*0x1034c589a*/
        break; /*0x1034c589a*/
      v6 = *a1; /*0x1034c589c*/
      v7 = (__int64 *)(*a1 + 16 * a2); /*0x1034c58a4*/
      v8 = 16 * v5; /*0x1034c58ab*/
      v9 = *v7; /*0x1034c58af*/
      v10 = v7[1]; /*0x1034c58b3*/
      *(_OWORD *)v7 = *(_OWORD *)(*a1 + 16 * v5); /*0x1034c58be*/
      *(_QWORD *)(v6 + v8) = v9; /*0x1034c58c2*/
      *(_QWORD *)(v6 + v8 + 8) = v10; /*0x1034c58c6*/
      v11 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c58d8*/
              a1: v3,
              a2: v7);
      v12 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c58e5*/
              a1: v3,
              a2: *a1 + 16 * v5);
      v2 = v14; /*0x1034c58ea*/
      v13 = *(_QWORD *)(v11 + 8); /*0x1034c58ee*/
      *(_QWORD *)(v11 + 8) = *(_QWORD *)(v12 + 8); /*0x1034c58f7*/
      *(_QWORD *)(v12 + 8) = v13; /*0x1034c58fc*/
      a2 = v5; /*0x1034c5900*/
    }
    while ( v5 < v14 ); /*0x1034c5906*/
  }
}

// Address: 0x1034c591c | Name: __ZN3RBX20IndexedPriorityQueueImNS_4TimeENSt3__17greaterIS1_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS2_6vectorINS2_4pairImS1_EENS2_9allocatorISE_EEEEE7extractERKm
double __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::greater<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::extract(
        _QWORD *a1,
        __int64 a2)
{
  _QWORD *v4; // r12
  unsigned __int64 v5; // r14
  __int64 v6; // rdx
  double *v7; // rsi
  double v8; // xmm1_8
  double v9; // rdi
  __int64 v10; // r13
  __int64 v11; // rax
  __int64 v12; // rcx
  char v14[8]; // [rsp+8h] [rbp-38h] BYREF
  double v15; // [rsp+10h] [rbp-30h]

  v4 = a1 + 3; /*0x1034c5933*/
  if ( (unsigned __int8)RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::LookupBucketFor<unsigned long>( /*0x1034c5945*/
                          a1: a1 + 3,
                          a2,
                          a3: v14) == 0 )
    RBXCRASH(a1: 0, a2: "Extracting non-existent key from IndexedPriorityQueue"); /*0x1034c5a22*/
  v5 = *(_QWORD *)(RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c5956*/
                     a1: v4,
                     a2)
                 + 8);
  v6 = a1[1]; /*0x1034c5964*/
  v7 = (double *)(*a1 + 16 * v5); /*0x1034c5968*/
  v8 = v7[1]; /*0x1034c596c*/
  v9 = *v7; /*0x1034c5972*/
  *(_OWORD *)v7 = *(_OWORD *)(v6 - 16); /*0x1034c597a*/
  *(double *)(v6 - 16) = v9; /*0x1034c597e*/
  v15 = v8; /*0x1034c5982*/
  *(double *)(v6 - 8) = v8; /*0x1034c5987*/
  v10 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c5994*/
          a1: v4,
          a2: v7);
  v11 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c59a2*/
          a1: v4,
          a2: a1[1] - 16LL);
  v12 = *(_QWORD *)(v10 + 8); /*0x1034c59a7*/
  *(_QWORD *)(v10 + 8) = *(_QWORD *)(v11 + 8); /*0x1034c59af*/
  *(_QWORD *)(v11 + 8) = v12; /*0x1034c59b3*/
  a1[1] -= 16LL; /*0x1034c59b7*/
  RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::erase( /*0x1034c59c2*/
    a1: v4,
    a2);
  if ( FFlag::g_flagsLoaded != 1 || DFFlag::CLI207421 != 1 ) /*0x1034c59dd*/
    goto LABEL_6; /*0x1034c59dd*/
  if ( v5 < (__int64)(a1[1] - *a1) >> 4 ) /*0x1034c59ed*/
  {
    RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::greater<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::bubbleUp( /*0x1034c59f5*/
      a1,
      a2: v5);
LABEL_6:
    RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::greater<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::bubbleDown( /*0x1034c59fa*/
      a1,
      a2: v5);
  }
  return v15; /*0x1034c5a0a*/
}

// Address: 0x1034c5a28 | Name: __ZN3RBX20IndexedPriorityQueueImNS_4TimeENSt3__17greaterIS1_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS2_6vectorINS2_4pairImS1_EENS2_9allocatorISE_EEEEE8bubbleUpEm
void __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::greater<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::bubbleUp(
        __int64 *a1,
        unsigned __int64 a2)
{
  unsigned __int64 v2; // rbx
  _QWORD *v3; // r15
  __int64 v4; // rax
  __int64 v5; // rsi
  unsigned __int64 v6; // r14
  __int64 v7; // r12
  double v8; // xmm0_8
  double v9; // xmm1_8
  double *v10; // rsi
  double *v11; // rax
  double v12; // rcx
  __int64 v13; // r13
  __int64 v14; // rax
  __int64 v15; // rcx

  if ( a2 != 0 ) /*0x1034c5a3d*/
  {
    v2 = a2; /*0x1034c5a43*/
    v3 = a1 + 3; /*0x1034c5a4a*/
    do /*0x1034c5acf*/
    {
      v4 = *a1; /*0x1034c5a52*/
      v5 = 16 * v2; /*0x1034c5a58*/
      v6 = v2 - 1; /*0x1034c5a5f*/
      v2 = (v2 - 1) >> 1; /*0x1034c5a65*/
      v7 = 16 * v2; /*0x1034c5a6b*/
      v8 = *(double *)(*a1 + v5 + 8); /*0x1034c5a6f*/
      v9 = *(double *)(*a1 + 16 * v2 + 8); /*0x1034c5a75*/
      if ( v8 <= v9 ) /*0x1034c5a80*/
        break; /*0x1034c5a80*/
      v10 = (double *)(v4 + v5); /*0x1034c5a82*/
      v11 = (double *)(v7 + v4); /*0x1034c5a85*/
      v12 = *v10; /*0x1034c5a88*/
      *v10 = *v11; /*0x1034c5a8e*/
      *v11 = v12; /*0x1034c5a91*/
      v10[1] = v9; /*0x1034c5a94*/
      v11[1] = v8; /*0x1034c5a99*/
      v13 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c5aa6*/
              a1: v3,
              a2: v10);
      v14 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c5ab6*/
              a1: v3,
              a2: *a1 + v7);
      v15 = *(_QWORD *)(v13 + 8); /*0x1034c5abb*/
      *(_QWORD *)(v13 + 8) = *(_QWORD *)(v14 + 8); /*0x1034c5ac3*/
      *(_QWORD *)(v14 + 8) = v15; /*0x1034c5ac7*/
    }
    while ( v6 > 1 ); /*0x1034c5acf*/
  }
}

// Address: 0x1034c5ae4 | Name: __ZN3RBX20IndexedPriorityQueueImNS_4TimeENSt3__17greaterIS1_EENS_8DenseMapImmNS_12DenseMapInfoImvEENS_6detail12DenseMapPairImmEEEENS2_6vectorINS2_4pairImS1_EENS2_9allocatorISE_EEEEE10bubbleDownEm
void __fastcall RBX::IndexedPriorityQueue<unsigned long,RBX::Time,std::greater<RBX::Time>,RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,std::vector<std::pair<unsigned long,RBX::Time>>>::bubbleDown(
        __int64 *a1,
        unsigned __int64 a2)
{
  unsigned __int64 v2; // r8
  _QWORD *v3; // rbx
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // r14
  __int64 v6; // rcx
  __int64 *v7; // rax
  __int64 v8; // r15
  __int64 v9; // rdx
  __int64 v10; // xmm0_8
  __int64 v11; // r12
  __int64 v12; // rax
  __int64 v13; // rcx
  unsigned __int64 v14; // [rsp+8h] [rbp-38h]

  v2 = (a1[1] - *a1) >> 4; /*0x1034c5b00*/
  if ( v2 > a2 ) /*0x1034c5b07*/
  {
    v14 = (a1[1] - *a1) >> 4; /*0x1034c5b19*/
    v3 = a1 + 3; /*0x1034c5b21*/
    do /*0x1034c5bfa*/
    {
      v4 = 2 * a2 + 1; /*0x1034c5b25*/
      if ( v4 >= v2 || *(double *)(*a1 + 16 * v4 + 8) <= *(double *)(*a1 + 16 * a2 + 8) ) /*0x1034c5b53*/
        v4 = a2; /*0x1034c5b55*/
      v5 = 2 * a2 + 2; /*0x1034c5b5c*/
      if ( v5 >= v2 || *(double *)(*a1 + 16 * v5 + 8) <= *(double *)(*a1 + 16 * v4 + 8) ) /*0x1034c5b86*/
        v5 = v4; /*0x1034c5b88*/
      if ( v5 == a2 ) /*0x1034c5b8e*/
        break; /*0x1034c5b8e*/
      v6 = *a1; /*0x1034c5b90*/
      v7 = (__int64 *)(*a1 + 16 * a2); /*0x1034c5b98*/
      v8 = 16 * v5; /*0x1034c5b9f*/
      v9 = *v7; /*0x1034c5ba3*/
      v10 = v7[1]; /*0x1034c5ba7*/
      *(_OWORD *)v7 = *(_OWORD *)(*a1 + 16 * v5); /*0x1034c5bb2*/
      *(_QWORD *)(v6 + v8) = v9; /*0x1034c5bb6*/
      *(_QWORD *)(v6 + v8 + 8) = v10; /*0x1034c5bba*/
      v11 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c5bcc*/
              a1: v3,
              a2: v7);
      v12 = RBX::DenseMapBase<RBX::DenseMap<unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>,unsigned long,unsigned long,RBX::DenseMapInfo<unsigned long,void>,RBX::detail::DenseMapPair<unsigned long,unsigned long>>::FindAndConstruct( /*0x1034c5bd9*/
              a1: v3,
              a2: *a1 + 16 * v5);
      v2 = v14; /*0x1034c5bde*/
      v13 = *(_QWORD *)(v11 + 8); /*0x1034c5be2*/
      *(_QWORD *)(v11 + 8) = *(_QWORD *)(v12 + 8); /*0x1034c5beb*/
      *(_QWORD *)(v12 + 8) = v13; /*0x1034c5bf0*/
      a2 = v5; /*0x1034c5bf4*/
    }
    while ( v5 < v14 ); /*0x1034c5bfa*/
  }
}

// Address: 0x1034dc1f4 | Name: __ZN3RBX20IndexedPriorityQueueIyNS_10Soundscape10Sequencing9ScheduledENSt3__14lessIS3_EENS_8DenseMapIymNS_12DenseMapInfoIyvEENS_6detail12DenseMapPairIymEEEENS4_6vectorINS4_4pairIyS3_EENS4_9allocatorISG_EEEEE6insertERKyRKS3_
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::insert(
        _QWORD *a1,
        __int64 *a2,
        __int64 *a3)
{
  _BYTE *v6; // r14
  unsigned __int64 v7; // r12
  __int64 v8; // rax
  __int64 v9; // r12
  _BYTE v11[24]; // [rsp+8h] [rbp-58h] BYREF
  __int64 v12; // [rsp+20h] [rbp-40h] BYREF
  __int64 v13; // [rsp+28h] [rbp-38h]
  char v14; // [rsp+30h] [rbp-30h]
  int v15; // [rsp+34h] [rbp-2Ch]
  _BYTE v16[40]; // [rsp+38h] [rbp-28h] BYREF

  v12 = (__int64)(a1[1] - *a1) >> 5; /*0x1034dc21f*/
  v6 = v11; /*0x1034dc222*/
  RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::try_emplace<unsigned long>( /*0x1034dc22c*/
    a1: v11,
    a2: a1 + 3,
    a3: a2);
  LOBYTE(v6) = v11[16]; /*0x1034dc231*/
  if ( v11[16] == 1 ) /*0x1034dc239*/
  {
    v12 = *a2; /*0x1034dc246*/
    v13 = *a3; /*0x1034dc24e*/
    v14 = *((_BYTE *)a3 + 8); /*0x1034dc257*/
    v15 = *((_DWORD *)a3 + 3); /*0x1034dc260*/
    ((void (__fastcall *)(_BYTE *, __int64 *))RSL::Variant<bool,float>::Variant(RSL::Variant<bool,float> const&)::table[v15])( /*0x1034dc275*/
      a1: v16,
      a2: a3 + 2);
    v7 = a1[1]; /*0x1034dc278*/
    if ( v7 >= a1[2] ) /*0x1034dc280*/
    {
      v9 = std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>::__emplace_back_slow_path<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>( /*0x1034dc2cf*/
             a1,
             a2: &v12);
    }
    else
    {
      *(_QWORD *)v7 = v12; /*0x1034dc28a*/
      *(_QWORD *)(v7 + 8) = v13; /*0x1034dc291*/
      *(_BYTE *)(v7 + 16) = v14; /*0x1034dc299*/
      v8 = v15; /*0x1034dc29e*/
      *(_DWORD *)(v7 + 20) = v15; /*0x1034dc2a2*/
      ((void (__fastcall *)(unsigned __int64, _BYTE *))RSL::Variant<bool,float>::tableMove[v8])(a1: v7 + 24, a2: v16); /*0x1034dc2b6*/
      v9 = v7 + 32; /*0x1034dc2b9*/
      a1[1] = v9; /*0x1034dc2bd*/
    }
    a1[1] = v9; /*0x1034dc2d2*/
    ((void (__fastcall *)(_BYTE *))RSL::Variant<bool,float>::tableDtor[v15])(a1: v16); /*0x1034dc2e4*/
    RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::bubbleUp( /*0x1034dc2f8*/
      a1,
      a2: ((__int64)(a1[1] - *a1) >> 5) - 1);
  }
  return (unsigned int)v6; /*0x1034dc300*/
}

// Address: 0x1034dc37c | Name: __ZN3RBX20IndexedPriorityQueueIyNS_10Soundscape10Sequencing9ScheduledENSt3__14lessIS3_EENS_8DenseMapIymNS_12DenseMapInfoIyvEENS_6detail12DenseMapPairIymEEEENS4_6vectorINS4_4pairIyS3_EENS4_9allocatorISG_EEEEE6removeERKy
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::remove(
        __int64 a1,
        __int64 a2)
{
  unsigned int v4; // ebx
  _DWORD v6[4]; // [rsp+0h] [rbp-40h] BYREF
  _BYTE v7[8]; // [rsp+10h] [rbp-30h] BYREF
  _BYTE v8[40]; // [rsp+18h] [rbp-28h] BYREF

  v4 = RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::LookupBucketFor<unsigned long long>( /*0x1034dc39e*/
         a1: a1 + 24,
         a2,
         a3: v8);
  if ( (_BYTE)v4 != 0 ) /*0x1034dc3a2*/
  {
    RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::extract( /*0x1034dc3b1*/
      a1: v6,
      a2: a1,
      a3: a2);
    ((void (__fastcall *)(_BYTE *))RSL::Variant<bool,float>::tableDtor[v6[3]])(a1: v7); /*0x1034dc3c6*/
  }
  return v4; /*0x1034dc3cb*/
}

// Address: 0x1034dc410 | Name: __ZNK3RBX20IndexedPriorityQueueIyNS_10Soundscape10Sequencing9ScheduledENSt3__14lessIS3_EENS_8DenseMapIymNS_12DenseMapInfoIyvEENS_6detail12DenseMapPairIymEEEENS4_6vectorINS4_4pairIyS3_EENS4_9allocatorISG_EEEEE7find_ifENS_12function_refIFbRKS3_EEE
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::find_if(
        _QWORD *a1,
        unsigned __int8 (__fastcall *a2)(__int64, __int64),
        __int64 a3)
{
  __int64 v5; // rbx
  void *v6; // rsi
  unsigned int v7; // eax
  unsigned __int64 v8; // r12
  __int64 v9; // r13
  void *v12; // [rsp+10h] [rbp-240h] BYREF
  __int64 v13; // [rsp+18h] [rbp-238h]
  _BYTE v14[512]; // [rsp+20h] [rbp-230h] BYREF

  v5 = a1[1]; /*0x1034dc43f*/
  v12 = v14; /*0x1034dc44a*/
  v13 = 0x4000000000LL; /*0x1034dc458*/
  RBX::SmallVectorTemplateBase<unsigned long,true>::push_back(a1: &v12, a2: 0); /*0x1034dc465*/
  v7 = v13; /*0x1034dc46a*/
  if ( (_DWORD)v13 != 0 ) /*0x1034dc472*/
  {
    do /*0x1034dc50f*/
    {
      v8 = *((_QWORD *)v12 + v7 - 1); /*0x1034dc483*/
      LODWORD(v13) = v7 - 1; /*0x1034dc488*/
      if ( v8 < (__int64)(a1[1] - *a1) >> 5 /*0x1034dc4be*/
        && ((v9 = 32 * v8 + *a1, v5 == a1[1]) || *(double *)(v9 + 8) <= *(double *)(v5 + 8)) )
      {
        if ( a2(a1: a3, a2: v9 + 8) == 0 ) /*0x1034dc4d5*/
        {
          RBX::SmallVectorTemplateBase<unsigned long,true>::push_back(a1: &v12, a2: 2 * v8 + 1); /*0x1034dc4e6*/
          RBX::SmallVectorTemplateBase<unsigned long,true>::push_back(a1: &v12, a2: 2 * v8 + 2); /*0x1034dc4fc*/
          v9 = v5; /*0x1034dc501*/
        }
      }
      else
      {
        v9 = v5; /*0x1034dc4c0*/
      }
      v7 = v13; /*0x1034dc504*/
      v5 = v9; /*0x1034dc50a*/
    }
    while ( (_DWORD)v13 != 0 ); /*0x1034dc50f*/
  }
  else
  {
    v9 = v5; /*0x1034dc517*/
  }
  if ( v12 != v14 ) /*0x1034dc52b*/
    operator delete(a1: (RBX::Memory *)v12, a2: v6); /*0x1034dc52d*/
  return v9; /*0x1034dc545*/
}

// Address: 0x1034dc582 | Name: __ZNK3RBX20IndexedPriorityQueueIyNS_10Soundscape10Sequencing9ScheduledENSt3__14lessIS3_EENS_8DenseMapIymNS_12DenseMapInfoIyvEENS_6detail12DenseMapPairIymEEEENS4_6vectorINS4_4pairIyS3_EENS4_9allocatorISG_EEEEE2atERKy
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::at(
        _QWORD *a1,
        __int64 a2)
{
  __int64 v2; // rax
  _QWORD *v5; // r15
  __int64 v6; // rax
  _QWORD v8[4]; // [rsp+0h] [rbp-20h] BYREF

  v8[0] = v2; /*0x1034dc58b*/
  v5 = a1 + 3; /*0x1034dc592*/
  if ( (unsigned __int8)RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::LookupBucketFor<unsigned long long>( /*0x1034dc5a4*/
                          a1: a1 + 3,
                          a2,
                          a3: v8) == 0 )
    RBXCRASH(a1: 0, a2: "Accessing non-existent key in IndexedPriorityQueue"); /*0x1034dc5e7*/
  if ( (unsigned __int8)RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::LookupBucketFor<unsigned long long>( /*0x1034dc5b7*/
                          a1: v5,
                          a2,
                          a3: v8) != 0 )
    v6 = *(_QWORD *)(v8[0] + 8LL); /*0x1034dc5bd*/
  else
    v6 = 0; /*0x1034dc5c3*/
  return *a1 + 32 * v6 + 8; /*0x1034dc5d7*/
}

// Address: 0x1034dc88c | Name: __ZN3RBX20IndexedPriorityQueueIyNS_10Soundscape10Sequencing9ScheduledENSt3__14lessIS3_EENS_8DenseMapIymNS_12DenseMapInfoIyvEENS_6detail12DenseMapPairIymEEEENS4_6vectorINS4_4pairIyS3_EENS4_9allocatorISG_EEEEE7pop_minEv
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::pop_min(
        __int64 a1,
        __int64 **a2)
{
  __int64 v2; // rax
  __int64 v5; // [rsp+0h] [rbp-10h] BYREF

  v5 = v2; /*0x1034dc891*/
  if ( *a2 == a2[1] ) /*0x1034dc899*/
    RBXCRASH(a1: 0, a2: "Popping from empty IndexedPriorityQueue"); /*0x1034dc8c0*/
  v5 = **a2; /*0x1034dc8a5*/
  RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::extract( /*0x1034dc8a8*/
    a1,
    a2,
    a3: &v5);
  return a1; /*0x1034dc8b4*/
}

// Address: 0x1034ddf1c | Name: __ZN3RBX20IndexedPriorityQueueIyNS_10Soundscape10Sequencing9ScheduledENSt3__14lessIS3_EENS_8DenseMapIymNS_12DenseMapInfoIyvEENS_6detail12DenseMapPairIymEEEENS4_6vectorINS4_4pairIyS3_EENS4_9allocatorISG_EEEEE8bubbleUpEm
void __fastcall RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::bubbleUp(
        _QWORD *a1,
        unsigned __int64 a2)
{
  unsigned __int64 v2; // r15
  _QWORD *v3; // rbx
  __int64 v4; // r13
  unsigned __int64 v5; // r14
  __int64 v6; // r12
  __int64 v7; // r13
  __int64 v8; // rax
  __int64 v9; // rcx

  if ( a2 != 0 ) /*0x1034ddf34*/
  {
    v2 = a2; /*0x1034ddf3a*/
    v3 = a1 + 3; /*0x1034ddf49*/
    do /*0x1034ddfc5*/
    {
      v4 = 32 * v2; /*0x1034ddf57*/
      v5 = v2 - 1; /*0x1034ddf5e*/
      v2 = (v2 - 1) >> 1; /*0x1034ddf64*/
      v6 = 32 * v2; /*0x1034ddf6a*/
      if ( *(double *)(*a1 + 32 * v2 + 8) <= *(double *)(*a1 + v4 + 8) ) /*0x1034ddf7c*/
        break; /*0x1034ddf7c*/
      std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>::swap[abi:ne200100]( /*0x1034ddf85*/
        a1: *a1 + v4,
        a2: v6 + *a1);
      v7 = RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::FindAndConstruct( /*0x1034ddf9c*/
             a1: v3,
             a2: *a1 + v4);
      v8 = RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::FindAndConstruct( /*0x1034ddfac*/
             a1: v3,
             a2: *a1 + v6);
      v9 = *(_QWORD *)(v7 + 8); /*0x1034ddfb1*/
      *(_QWORD *)(v7 + 8) = *(_QWORD *)(v8 + 8); /*0x1034ddfb9*/
      *(_QWORD *)(v8 + 8) = v9; /*0x1034ddfbd*/
    }
    while ( v5 > 1 ); /*0x1034ddfc5*/
  }
}

// Address: 0x1034de82c | Name: __ZN3RBX20IndexedPriorityQueueIyNS_10Soundscape10Sequencing9ScheduledENSt3__14lessIS3_EENS_8DenseMapIymNS_12DenseMapInfoIyvEENS_6detail12DenseMapPairIymEEEENS4_6vectorINS4_4pairIyS3_EENS4_9allocatorISG_EEEEE7extractERKy
__int64 __fastcall RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::extract(
        __int64 a1,
        __int64 *a2,
        __int64 a3)
{
  _QWORD *v6; // r12
  unsigned __int64 v7; // r14
  __int64 v8; // rax
  __int64 v9; // rsi
  __int64 v10; // rax
  __int64 v11; // r14
  __int64 v12; // rax
  __int64 v13; // rcx
  __int64 v14; // rax
  __int64 v16; // [rsp+0h] [rbp-50h] BYREF
  __int64 v17; // [rsp+8h] [rbp-48h]
  char v18; // [rsp+10h] [rbp-40h]
  int v19; // [rsp+14h] [rbp-3Ch]
  _BYTE v20[8]; // [rsp+18h] [rbp-38h] BYREF
  unsigned __int64 v21; // [rsp+20h] [rbp-30h]

  v6 = a2 + 3; /*0x1034de846*/
  if ( (unsigned __int8)RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::LookupBucketFor<unsigned long long>( /*0x1034de85b*/
                          a1: a2 + 3,
                          a2: a3,
                          a3: &v16) == 0 )
    RBXCRASH(a1: 0, a2: "Extracting non-existent key from IndexedPriorityQueue"); /*0x1034de99c*/
  v7 = *(_QWORD *)(RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::FindAndConstruct( /*0x1034de86c*/
                     a1: v6,
                     a2: a3)
                 + 8);
  v8 = *a2; /*0x1034de870*/
  v21 = v7; /*0x1034de873*/
  v7 *= 32LL; /*0x1034de877*/
  v9 = v8 + v7 + 24; /*0x1034de87f*/
  v16 = *(_QWORD *)(v8 + v7); /*0x1034de88b*/
  v17 = *(_QWORD *)(v8 + v7 + 8); /*0x1034de893*/
  v18 = *(_BYTE *)(v8 + v7 + 16); /*0x1034de89a*/
  v10 = *(int *)(v8 + v7 + 20); /*0x1034de89d*/
  v19 = v10; /*0x1034de8a1*/
  ((void (__fastcall *)(_BYTE *, __int64))RSL::Variant<bool,float>::Variant(RSL::Variant<bool,float> const&)::table[v10])( /*0x1034de8ab*/
    a1: v20,
    a2: v9);
  std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>::swap[abi:ne200100](a1: v7 + *a2, a2: a2[1] - 32); /*0x1034de8bc*/
  v11 = RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::FindAndConstruct( /*0x1034de8cf*/
          a1: v6,
          a2: *a2 + v7);
  v12 = RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::FindAndConstruct( /*0x1034de8dd*/
          a1: v6,
          a2: a2[1] - 32);
  v13 = *(_QWORD *)(v11 + 8); /*0x1034de8e2*/
  *(_QWORD *)(v11 + 8) = *(_QWORD *)(v12 + 8); /*0x1034de8ea*/
  *(_QWORD *)(v12 + 8) = v13; /*0x1034de8ee*/
  std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>::pop_back[abi:ne200100](a1: a2); /*0x1034de8f5*/
  RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::erase( /*0x1034de900*/
    a1: v6,
    a2: a3);
  if ( FFlag::g_flagsLoaded != 1 || DFFlag::CLI207421 != 1 ) /*0x1034de91b*/
    goto LABEL_6; /*0x1034de91b*/
  if ( v21 < (a2[1] - *a2) >> 5 ) /*0x1034de92c*/
  {
    RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::bubbleUp( /*0x1034de935*/
      a1: a2,
      a2: v21);
LABEL_6:
    RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::bubbleDown( /*0x1034de93a*/
      a1: a2,
      a2: v21);
  }
  *(_BYTE *)(a1 + 8) = v18; /*0x1034de946*/
  *(_QWORD *)a1 = v17; /*0x1034de953*/
  v14 = v19; /*0x1034de956*/
  *(_DWORD *)(a1 + 12) = v19; /*0x1034de95a*/
  ((void (__fastcall *)(__int64, _BYTE *))RSL::Variant<bool,float>::Variant(RSL::Variant<bool,float> const&)::table[v14])( /*0x1034de96c*/
    a1: a1 + 16,
    a2: v20);
  ((void (__fastcall *)(_BYTE *))RSL::Variant<bool,float>::tableDtor[v19])(a1: v20); /*0x1034de97e*/
  return a1; /*0x1034de984*/
}

// Address: 0x1034dea5e | Name: __ZN3RBX20IndexedPriorityQueueIyNS_10Soundscape10Sequencing9ScheduledENSt3__14lessIS3_EENS_8DenseMapIymNS_12DenseMapInfoIyvEENS_6detail12DenseMapPairIymEEEENS4_6vectorINS4_4pairIyS3_EENS4_9allocatorISG_EEEEE10bubbleDownEm
void __fastcall RBX::IndexedPriorityQueue<unsigned long long,RBX::Soundscape::Sequencing::Scheduled,std::less<RBX::Soundscape::Sequencing::Scheduled>,RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,std::vector<std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>>>::bubbleDown(
        _QWORD *a1,
        unsigned __int64 a2)
{
  unsigned __int64 v2; // r8
  unsigned __int64 v3; // r15
  _QWORD *v4; // r13
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // r14
  __int64 v7; // r15
  __int64 v8; // r15
  __int64 v9; // rax
  __int64 v10; // rcx
  unsigned __int64 v11; // [rsp+8h] [rbp-38h]

  v2 = (__int64)(a1[1] - *a1) >> 5; /*0x1034dea7a*/
  if ( v2 > a2 ) /*0x1034dea81*/
  {
    v3 = a2; /*0x1034dea87*/
    v11 = (__int64)(a1[1] - *a1) >> 5; /*0x1034dea96*/
    v4 = a1 + 3; /*0x1034dea9e*/
    do /*0x1034deb60*/
    {
      v5 = 2 * v3 + 1; /*0x1034deaa2*/
      if ( v5 >= v2 || *(double *)(*a1 + 32 * v3 + 8) <= *(double *)(*a1 + 32 * v5 + 8) ) /*0x1034dead0*/
        v5 = v3; /*0x1034dead2*/
      v6 = 2 * v3 + 2; /*0x1034dead9*/
      if ( v6 >= v2 || *(double *)(*a1 + 32 * v5 + 8) <= *(double *)(*a1 + 32 * v6 + 8) ) /*0x1034deb03*/
        v6 = v5; /*0x1034deb05*/
      if ( v6 == v3 ) /*0x1034deb0b*/
        break; /*0x1034deb0b*/
      v7 = 32 * v3; /*0x1034deb10*/
      std::pair<unsigned long long,RBX::Soundscape::Sequencing::Scheduled>::swap[abi:ne200100]( /*0x1034deb22*/
        a1: *a1 + v7,
        a2: 32 * v6 + *a1);
      v8 = RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::FindAndConstruct( /*0x1034deb35*/
             a1: v4,
             a2: *a1 + v7);
      v9 = RBX::DenseMapBase<RBX::DenseMap<unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>,unsigned long long,unsigned long,RBX::DenseMapInfo<unsigned long long,void>,RBX::detail::DenseMapPair<unsigned long long,unsigned long>>::FindAndConstruct( /*0x1034deb41*/
             a1: v4,
             a2: *a1 + 32 * v6);
      v2 = v11; /*0x1034deb46*/
      v10 = *(_QWORD *)(v8 + 8); /*0x1034deb4a*/
      *(_QWORD *)(v8 + 8) = *(_QWORD *)(v9 + 8); /*0x1034deb52*/
      *(_QWORD *)(v9 + 8) = v10; /*0x1034deb56*/
      v3 = v6; /*0x1034deb5a*/
    }
    while ( v6 < v11 ); /*0x1034deb60*/
  }
}

// Address: 0x1039806c3 | Name: __ZN3RBX16interpolateColorEjjjff
__int64 __fastcall RBX::interpolateColor(RBX *this, unsigned int a2, unsigned int a3, float a4, float a5)
{
  float v5; // xmm2_4

  v5 = (float)(1.0 - a4) - a5; /*0x1039806d8*/
  return ((int)((float)((float)((float)HIBYTE(a3) * v5) /*0x10398082a*/
                      + (float)((float)((float)HIBYTE(a2) * a5) + (float)((float)((unsigned int)this >> 24) * a4)))
              + 0.5) << 24)
       | ((unsigned __int8)(int)((float)((float)((float)(unsigned __int8)a3 * v5)
                                       + (float)((float)((float)(unsigned __int8)a2 * a5)
                                               + (float)((float)(unsigned __int8)this * a4)))
                               + 0.5) << 16)
       | ((unsigned __int8)(int)((float)((float)((float)BYTE1(a3) * v5)
                                       + (float)((float)((float)BYTE1(a2) * a5) + (float)((float)BYTE1(this) * a4)))
                               + 0.5) << 8)
       | (unsigned int)(unsigned __int8)(int)((float)((float)((float)BYTE2(a3) * v5)
                                                    + (float)((float)((float)BYTE2(a2) * a5)
                                                            + (float)((float)BYTE2(this) * a4)))
                                            + 0.5);
}

// Address: 0x103980b36 | Name: __ZN3RBX24isOctantTriangleInteractEPvPdd
__int64 __fastcall RBX::isOctantTriangleInteract(
        RBX *this,
        __m128d *a2,
        double *a3,
        __m128d a4,
        __int64 a5,
        int a6,
        int a7)
{
  __m128d v9; // xmm13
  __m128d v10; // xmm2
  __m128d v11; // xmm7
  __int128 v12; // xmm1
  _QWORD *v13; // rax
  __int64 v14; // rcx
  double v15; // xmm5_8
  double *v16; // rdx
  double v17; // xmm4_8
  double *v18; // rsi
  double v19; // xmm3_8
  __int64 result; // rax
  __m128d v21; // xmm8
  double v22; // xmm4_8
  double v23; // xmm3_8
  double v24; // xmm2_8
  double v25; // xmm9_8
  double v26; // xmm10_8
  __m128d v27; // xmm3
  __m128d v28; // xmm11
  double v29; // xmm6_8
  double v30; // xmm5_8
  double v31; // xmm4_8
  double v32; // xmm11_8
  __m128d v33; // xmm2
  double v34; // xmm12_8
  __m128d v35; // xmm2
  __int64 i; // rax
  double v37; // xmm3_8
  double v38; // xmm3_8
  double v39; // xmm3_8
  __int64 j; // rax
  __int64 v41; // rdx
  RBX *v42; // r13
  double *v43; // rbx
  char *v44; // r12
  _QWORD *v45; // r15
  __int64 v46; // r14
  double *v47; // rdx
  __int64 v48; // rax
  double *v49; // r9
  char v50; // al
  __int64 v51; // rcx
  double v52; // xmm0_8
  __int64 v53; // rcx
  bool v54; // zf
  __int64 v55; // r14
  __m128d v56; // xmm2
  __m128d v57; // xmm3
  __m128d v58; // xmm5
  __m128d v59; // xmm5
  __int64 v60; // rbx
  double v61; // xmm0_8
  double *v62; // [rsp+0h] [rbp-340h]
  int *v63; // [rsp+8h] [rbp-338h]
  __m128d v64; // [rsp+10h] [rbp-330h]
  double v65[3]; // [rsp+7Ch] [rbp-2C4h] BYREF
  double v66; // [rsp+98h] [rbp-2A8h] BYREF
  double v67[4]; // [rsp+A0h] [rbp-2A0h] BYREF
  __m128d v68; // [rsp+C0h] [rbp-280h] BYREF
  __m128d v69; // [rsp+D0h] [rbp-270h]
  double v70; // [rsp+E0h] [rbp-260h]
  double v71; // [rsp+E8h] [rbp-258h]
  __m128d v72; // [rsp+F0h] [rbp-250h]
  double v73; // [rsp+100h] [rbp-240h]
  double v74; // [rsp+108h] [rbp-238h]
  __m128d v75; // [rsp+110h] [rbp-230h]
  double v76; // [rsp+120h] [rbp-220h]
  double v77; // [rsp+128h] [rbp-218h]
  _BYTE v78[24]; // [rsp+130h] [rbp-210h]
  double v79; // [rsp+148h] [rbp-1F8h]
  unsigned __int128 v80; // [rsp+150h] [rbp-1F0h]
  double v81; // [rsp+160h] [rbp-1E0h]
  __m128d v82; // [rsp+168h] [rbp-1D8h]
  double v83; // [rsp+178h] [rbp-1C8h]
  __m128d v84; // [rsp+180h] [rbp-1C0h] BYREF
  double v85; // [rsp+190h] [rbp-1B0h]
  double v86; // [rsp+198h] [rbp-1A8h]
  double v87; // [rsp+1A0h] [rbp-1A0h]
  __int64 v88; // [rsp+1A8h] [rbp-198h]
  double v89; // [rsp+1B0h] [rbp-190h]
  double v90; // [rsp+1B8h] [rbp-188h]
  __int64 v91; // [rsp+1C0h] [rbp-180h]
  double v92; // [rsp+1C8h] [rbp-178h]
  double v93; // [rsp+1D0h] [rbp-170h]
  __int64 v94; // [rsp+1D8h] [rbp-168h]
  __m128d v95; // [rsp+1E0h] [rbp-160h]
  double v96; // [rsp+1F0h] [rbp-150h]
  __m128d v97; // [rsp+1F8h] [rbp-148h]
  double v98; // [rsp+208h] [rbp-138h]
  __m128d v99; // [rsp+210h] [rbp-130h] BYREF
  double v100; // [rsp+220h] [rbp-120h]
  unsigned __int64 v101; // [rsp+228h] [rbp-118h]
  __int128 v102; // [rsp+230h] [rbp-110h]
  __int64 v103; // [rsp+240h] [rbp-100h]
  __int64 v104; // [rsp+248h] [rbp-F8h]
  __int128 v105; // [rsp+250h] [rbp-F0h]
  __int128 v106; // [rsp+260h] [rbp-E0h]
  __int128 v107; // [rsp+270h] [rbp-D0h]
  __int128 v108; // [rsp+280h] [rbp-C0h]
  __int64 v109; // [rsp+290h] [rbp-B0h]
  unsigned __int64 v110; // [rsp+298h] [rbp-A8h]
  double v111; // [rsp+2A0h] [rbp-A0h]
  double v112; // [rsp+2A8h] [rbp-98h]
  double v113[2]; // [rsp+2B0h] [rbp-90h]
  __m128d v114; // [rsp+2C0h] [rbp-80h] BYREF
  double v115; // [rsp+2D0h] [rbp-70h]
  __m128d v116; // [rsp+2D8h] [rbp-68h] BYREF
  double v117; // [rsp+2E8h] [rbp-58h]
  __m128d v118; // [rsp+2F0h] [rbp-50h] BYREF
  double v119; // [rsp+300h] [rbp-40h]
  __int64 savedregs; // [rsp+340h] [rbp+0h] BYREF

  if ( this == nullptr && (unsigned __int8)FLog::ModelLod >= 6u && BYTE1(FLog::ModelLod) >= 3u ) /*0x103980b78*/
  {
    *(__m128d *)((char *)v65 + 4) = a4; /*0x103980b8f*/
    FLog::FastLogFormatted( /*0x103980b96*/
      a1: (_DWORD)FLog::ModelLod,
      a2: qword_10D7BABE8,
      a3: (unsigned int)"[FLog::ModelLod] Null octree element",
      a4: (unsigned __int8)FLog::ModelLod < 6u,
      a5: a6,
      a6: a7);
    a4 = *(__m128d *)((char *)v65 + 4); /*0x103980b9b*/
  }
  a4.f64[0] = a4.f64[0] * 0.5; /*0x103980ba3*/
  v9 = *a2; /*0x103980bab*/
  v10 = _mm_movedup_pd(a4); /*0x103980bb0*/
  v11 = _mm_add_pd(v10, *a2); /*0x103980bb8*/
  v12 = *(unsigned __int64 *)&a2[1].f64[0]; /*0x103980bbd*/
  v13 = *((_QWORD **)this + 1); /*0x103980bc3*/
  v14 = *v13; /*0x103980bc7*/
  v15 = *(double *)(*v13 + 8LL); /*0x103980bca*/
  v114.f64[0] = v15; /*0x103980bcf*/
  v16 = (double *)v13[1]; /*0x103980bd4*/
  v17 = v16[1]; /*0x103980bd8*/
  v116.f64[0] = v17; /*0x103980bdd*/
  v18 = (double *)v13[2]; /*0x103980be2*/
  v19 = v18[1]; /*0x103980be6*/
  v118.f64[0] = v19; /*0x103980beb*/
  if ( v15 <= v11.f64[0] || v17 <= v11.f64[0] || (result = 0, v19 <= v11.f64[0]) ) /*0x103980c02*/
  {
    v21 = _mm_sub_pd(v9, v10); /*0x103980c0d*/
    result = 0; /*0x103980c12*/
    if ( v21.f64[0] <= v15 || v21.f64[0] <= v17 || v21.f64[0] <= v19 ) /*0x103980c27*/
    {
      v22 = *(double *)(v14 + 16); /*0x103980c2d*/
      v114.f64[1] = v22; /*0x103980c32*/
      v23 = v16[2]; /*0x103980c37*/
      v116.f64[1] = v23; /*0x103980c3c*/
      v24 = v18[2]; /*0x103980c41*/
      v118.f64[1] = v24; /*0x103980c46*/
      v25 = _mm_unpackhi_pd(v11, v11).f64[0]; /*0x103980c50*/
      if ( v22 <= v25 || v23 <= v25 || v24 <= v25 ) /*0x103980c68*/
      {
        v26 = _mm_unpackhi_pd(v21, v21).f64[0]; /*0x103980c73*/
        if ( v26 <= v22 || v26 <= v23 || v26 <= v24 ) /*0x103980c8b*/
        {
          v27.f64[1] = *((double *)&v12 + 1); /*0x103980c91*/
          v27.f64[0] = *(double *)&v12 + a4.f64[0]; /*0x103980c95*/
          v28 = _mm_movedup_pd(v27); /*0x103980c99*/
          v29 = *(double *)(v14 + 24); /*0x103980c9e*/
          v115 = v29; /*0x103980ca3*/
          v30 = v16[3]; /*0x103980ca8*/
          v117 = v30; /*0x103980cad*/
          v31 = v18[3]; /*0x103980cb2*/
          v119 = v31; /*0x103980cb7*/
          v32 = _mm_unpackhi_pd(v28, v28).f64[0]; /*0x103980cbc*/
          if ( v29 <= v32 || v30 <= v32 || v31 <= v32 ) /*0x103980cd4*/
          {
            v33.f64[1] = *((double *)&v12 + 1); /*0x103980cda*/
            v33.f64[0] = *(double *)&v12 - a4.f64[0]; /*0x103980cde*/
            v34 = _mm_movedup_pd(v33).f64[0]; /*0x103980ce2*/
            if ( v34 <= v29 || v34 <= v30 || v34 <= v31 ) /*0x103980cfa*/
            {
              v35 = _mm_unpacklo_pd(v33, v27); /*0x103980d00*/
              for ( i = 2; i != 11; i += 3 ) /*0x103980d04*/
              {
                v37 = v113[i]; /*0x103980d09*/
                if ( v37 > v21.f64[0] && v11.f64[0] > v37 ) /*0x103980d1d*/
                {
                  v38 = v113[i + 1]; /*0x103980d1f*/
                  if ( v38 > v26 && v25 > v38 ) /*0x103980d34*/
                  {
                    v39 = v114.f64[i]; /*0x103980d36*/
                    if ( v39 > v34 && v32 > v39 ) /*0x103980d48*/
                      return 1; /*0x103980d48*/
                  }
                }
              }
              for ( j = 0; j != 3; ++j ) /*0x103980d58*/
                *(&v111 + j) = (v114.f64[j] + v116.f64[j] + v118.f64[j]) / 3.0; /*0x103980d78*/
              if ( v111 <= v21.f64[0] /*0x103980dce*/
                || v11.f64[0] <= v111
                || v112 <= v26
                || v25 <= v112
                || v113[0] <= v34
                || (result = 1, v32 <= v113[0]) )
              {
                v100 = 0.0; /*0x103980de0*/
                v103 = 0; /*0x103980df0*/
                v109 = 0; /*0x103980e00*/
                v107 = 0; /*0x103980e08*/
                v105 = 0; /*0x103980e10*/
                v102 = 0; /*0x103980e18*/
                v99 = (__m128d)0x3FF0000000000000uLL; /*0x103980e2a*/
                v101 = 0xBFF0000000000000LL; /*0x103980e3b*/
                v104 = 0x3FF0000000000000LL; /*0x103980e42*/
                v106 = 0xBFF0000000000000LL; /*0x103980e49*/
                v108 = 0x3FF0000000000000uLL; /*0x103980e50*/
                v110 = 0xBFF0000000000000LL; /*0x103980e57*/
                v84.f64[0] = v11.f64[0]; /*0x103980e5e*/
                v84.f64[1] = v9.f64[1]; /*0x103980e66*/
                v85 = *(double *)&v12; /*0x103980e6f*/
                v86 = v21.f64[0]; /*0x103980e77*/
                v87 = v9.f64[1]; /*0x103980e80*/
                v88 = v12; /*0x103980e89*/
                v89 = v9.f64[0]; /*0x103980e91*/
                v90 = v25; /*0x103980e9a*/
                v91 = v12; /*0x103980ea3*/
                v92 = v9.f64[0]; /*0x103980eab*/
                v93 = v26; /*0x103980eb4*/
                v94 = v12; /*0x103980ebd*/
                v95 = v9; /*0x103980ec5*/
                v96 = v32; /*0x103980ed7*/
                v97 = v9; /*0x103980ee0*/
                v98 = v34; /*0x103980ef2*/
                v68.f64[0] = v26; /*0x103980efb*/
                v68.f64[1] = v25; /*0x103980f04*/
                v69 = v35; /*0x103980f0d*/
                v70 = v26; /*0x103980f15*/
                v71 = v25; /*0x103980f1e*/
                v72 = v35; /*0x103980f27*/
                v73 = v21.f64[0]; /*0x103980f2f*/
                v74 = v11.f64[0]; /*0x103980f38*/
                v75 = v35; /*0x103980f40*/
                v76 = v21.f64[0]; /*0x103980f48*/
                v77 = v11.f64[0]; /*0x103980f51*/
                *(__m128d *)v78 = v35; /*0x103980f59*/
                *(double *)&v78[16] = v21.f64[0]; /*0x103980f61*/
                v79 = v11.f64[0]; /*0x103980f6a*/
                *(double *)&v80 = v26; /*0x103980f72*/
                *((double *)&v80 + 1) = v25; /*0x103980f7b*/
                v81 = v21.f64[0]; /*0x103980f8d*/
                v64 = v11; /*0x103980f96*/
                v82.f64[0] = v11.f64[0]; /*0x103980f9e*/
                v82.f64[1] = v26; /*0x103980faf*/
                v83 = v25; /*0x103980fc1*/
                v41 = 0; /*0x103980fd1*/
                do /*0x1039810df*/
                {
                  v42 = (RBX *)((char *)&v84 + 24 * v41); /*0x103980fe3*/
                  v43 = &v99.f64[3 * v41]; /*0x103980fea*/
                  v44 = (char *)&unk_1095778E0 + 8 * v41; /*0x103980ff2*/
                  *(_QWORD *)((char *)v65 + 4) = v41; /*0x103980ff6*/
                  v45 = (_QWORD *)&v68.f64[4 * v41]; /*0x103981008*/
                  v46 = 0; /*0x10398100f*/
                  do /*0x103981068*/
                  {
                    v66 = 0.0; /*0x103981014*/
                    v47 = (double *)(&savedregs + 3 * v46++ - 16); /*0x103981027*/
                    v48 = (unsigned int)v46; /*0x103981031*/
                    if ( v46 == 3 ) /*0x103981034*/
                      v48 = 0; /*0x103981034*/
                    if ( (unsigned int)RBX::linePlaneIntersection( /*0x10398108a*/
                                         this: v42,
                                         a2: v43,
                                         a3: v47,
                                         a4: (double *)&savedregs + 3 * v48 - 16,
                                         a5: v67,
                                         a6: &v66,
                                         a7: v62) == 0
                      && v66 > 0.0
                      && v66 < 1.0 )
                    {
                      v50 = 1; /*0x10398108c*/
                      v51 = 0; /*0x10398108e*/
                      while ( 1 ) /*0x103981094*/
                      {
                        v52 = v67[*(int *)&v44[4 * v51]]; /*0x103981094*/
                        v53 = 2 * v51; /*0x10398109d*/
                        if ( *(double *)&v45[v53] > v52 || v52 > *(double *)&v45[v53 + 1] ) /*0x1039810b5*/
                          break; /*0x1039810b5*/
                        v51 = 1; /*0x1039810b7*/
                        v54 = (v50 & 1) == 0; /*0x1039810bc*/
                        v50 = 0; /*0x1039810be*/
                        if ( v54 ) /*0x1039810c3*/
                          return 1; /*0x1039810c3*/
                      }
                    }
                  }
                  while ( v46 != 3 ); /*0x103981068*/
                  v41 = *(_QWORD *)((char *)v65 + 4) + 1LL; /*0x1039810d1*/
                }
                while ( *(_QWORD *)((char *)v65 + 4) != 5 ); /*0x1039810df*/
                v68 = v21; /*0x1039810ed*/
                v69.f64[0] = v34; /*0x1039810fd*/
                v69.f64[1] = v64.f64[0]; /*0x10398110d*/
                v70 = v26; /*0x10398111c*/
                v71 = v34; /*0x103981124*/
                v72 = v21; /*0x10398112c*/
                v73 = v32; /*0x10398113c*/
                v74 = v64.f64[0]; /*0x103981144*/
                v75.f64[0] = v26; /*0x10398114c*/
                v75.f64[1] = v32; /*0x103981154*/
                v76 = v21.f64[0]; /*0x10398115c*/
                v77 = v25; /*0x10398116c*/
                *(double *)v78 = v34; /*0x103981174*/
                *(__m128d *)&v78[8] = v64; /*0x10398117c*/
                v79 = v34; /*0x103981184*/
                v80 = __PAIR128__(*(unsigned __int64 *)&v25, *(unsigned __int64 *)&v21.f64[0]); /*0x10398118c*/
                v81 = v32; /*0x10398119c*/
                v82 = v64; /*0x1039811a4*/
                v83 = v32; /*0x1039811ac*/
                v55 = 0; /*0x1039811b4*/
                while ( (unsigned int)RBX::lineTriIntersection( /*0x1039811fe*/
                                        this: (RBX *)&v114,
                                        a2: v116.f64,
                                        a3: v118.f64,
                                        a4: (double *)&savedregs + 3 * dword_109577910[2 * v55] - 80,
                                        a5: &v68.f64[3 * dword_109577910[2 * v55 + 1]],
                                        a6: v49) == 0 )
                {
                  if ( ++v55 == 12 ) /*0x10398120b*/
                  {
                    v56 = (__m128d)*(unsigned __int64 *)&v115; /*0x10398121f*/
                    v57 = (__m128d)*(unsigned __int64 *)&v115; /*0x103981224*/
                    v57.f64[0] = v115 - v117; /*0x103981228*/
                    v99 = _mm_sub_pd(v114, v116); /*0x10398122d*/
                    v100 = v115 - v117; /*0x103981235*/
                    v84 = _mm_sub_pd(v114, v118); /*0x103981242*/
                    v56.f64[0] = v115 - v119; /*0x10398124a*/
                    v85 = v115 - v119; /*0x10398124f*/
                    v58 = _mm_sub_pd( /*0x103981281*/
                            _mm_mul_pd(_mm_shuffle_pd(v84, v56, 1), v99),
                            _mm_mul_pd(_mm_shuffle_pd(v99, v57, 1), v84));
                    v59 = _mm_mul_pd(v58, v58); /*0x103981285*/
                    if ( _mm_unpackhi_pd(v59, v59).f64[0] /*0x1039812a1*/
                       + ((v115 - v117) * v84.f64[0] - v99.f64[0] * (v115 - v119))
                       * ((v115 - v117) * v84.f64[0] - v99.f64[0] * (v115 - v119))
                       + v59.f64[0] <= 1.0e-28 )
                      return 0; /*0x103981309*/
                    v60 = 0; /*0x1039812a3*/
                    while ( 1 ) /*0x1039812e7*/
                    {
                      RBX::pointSqrDistToTri( /*0x1039812e7*/
                        this: (RBX *)((char *)&v68 + v60),
                        a2: v114.f64,
                        a3: v99.f64,
                        a4: v84.f64,
                        a5: v67,
                        a6: &v66,
                        a7: v65,
                        a8: v63);
                      if ( v61 < 1.0e-28 ) /*0x1039812f8*/
                        break; /*0x1039812f8*/
                      v60 += 24; /*0x1039812fa*/
                      if ( v60 == 144 ) /*0x103981305*/
                        return 0; /*0x103981305*/
                    }
                    return 1; /*0x1039812f8*/
                  }
                }
                return 1; /*0x10398130b*/
              }
            }
          }
        }
      }
    }
  }
  return result; /*0x103981320*/
}

// Address: 0x103f9f557 | Name: __ZN3RBXL24init_destination_chunkedEP20jpeg_compress_struct
__int64 __fastcall RBX::init_destination_chunked(__int64 a1)
{
  __int64 result; // rax
  unsigned int v2; // ecx
  __int64 v3; // rdx

  result = *(_QWORD *)(a1 + 40); /*0x103f9f55b*/
  *(_QWORD *)result = *(_QWORD *)(result + 40); /*0x103f9f563*/
  v2 = *(_DWORD *)(result + 48); /*0x103f9f566*/
  v3 = 0x8000; /*0x103f9f569*/
  if ( v2 < 0x8000 ) /*0x103f9f570*/
    v3 = v2; /*0x103f9f570*/
  *(_QWORD *)(result + 8) = v3; /*0x103f9f573*/
  *(_DWORD *)(result + 52) = 0; /*0x103f9f577*/
  return result; /*0x103f9f57e*/
}

// Address: 0x103f9f5e2 | Name: __ZN3RBXL27init_destination_DEPRECATEDEP20jpeg_compress_struct
__int64 __fastcall RBX::init_destination_DEPRECATED(__int64 a1)
{
  __int64 result; // rax

  result = *(_QWORD *)(a1 + 40); /*0x103f9f5e6*/
  *(_QWORD *)result = *(_QWORD *)(result + 40); /*0x103f9f5ee*/
  *(_QWORD *)(result + 8) = *(int *)(result + 48); /*0x103f9f5f5*/
  *(_DWORD *)(result + 52) = 0; /*0x103f9f5f9*/
  return result; /*0x103f9f600*/
}

// Address: 0x103f9f633 | Name: __ZN3RBXL11init_sourceEP22jpeg_decompress_struct
__int64 __fastcall RBX::init_source(__int64 a1)
{
  __int64 result; // rax

  result = *(_QWORD *)(a1 + 40); /*0x103f9f637*/
  *(_BYTE *)(result + 72) = 1; /*0x103f9f63b*/
  return result; /*0x103f9f63f*/
}

// Address: 0x10419b9b2 | Name: __ZN3RBX14isStandardGuidENS_10StringViewE
bool __fastcall RBX::isStandardGuid(_BYTE *a1, __int64 a2)
{
  bool v2; // cl
  __int64 v3; // rax
  unsigned __int64 i; // rdx
  unsigned __int8 v5; // si
  unsigned __int64 v6; // rsi
  bool v7; // cl
  unsigned __int64 j; // rdx
  unsigned __int8 v9; // si
  unsigned __int64 v10; // rsi
  bool v11; // cl
  unsigned __int64 k; // rdx
  unsigned __int8 v13; // si
  unsigned __int64 v14; // rsi
  bool v15; // cl
  unsigned __int64 m; // rdx
  unsigned __int8 v17; // si
  unsigned __int64 v18; // rsi
  bool v19; // cl
  unsigned __int64 n; // rdx
  unsigned __int8 v21; // si
  unsigned __int64 v22; // rsi

  if ( a2 != 38 || *a1 != 123 ) /*0x10419b9c3*/
    return false; /*0x10419b9c3*/
  v2 = false; /*0x10419b9c9*/
  v3 = 0x3F0000003FLL; /*0x10419b9cb*/
  for ( i = 0; i != 8; ++i ) /*0x10419b9d5*/
  {
    v5 = a1[i + 1]; /*0x10419b9d7*/
    if ( (unsigned __int8)(v5 - 48) >= 0xAu ) /*0x10419b9e4*/
    {
      v6 = (unsigned int)v5 - 65; /*0x10419b9ea*/
      if ( (unsigned int)v6 > 0x25 || !_bittest64(&v3, v6) ) /*0x10419b9f2*/
        break; /*0x10419b9f6*/
    }
    v2 = i >= 7; /*0x10419ba00*/
  }
  if ( !v2 || a1[9] != 45 ) /*0x10419ba19*/
    return false; /*0x10419ba19*/
  v7 = false; /*0x10419ba1f*/
  for ( j = 0; j != 4; v7 = j++ >= 3 ) /*0x10419ba21*/
  {
    v9 = a1[j + 10]; /*0x10419ba23*/
    if ( (unsigned __int8)(v9 - 48) >= 0xAu ) /*0x10419ba30*/
    {
      v10 = (unsigned int)v9 - 65; /*0x10419ba36*/
      if ( (unsigned int)v10 > 0x25 || !_bittest64(&v3, v10) ) /*0x10419ba3e*/
        break; /*0x10419ba42*/
    }
  }
  if ( !v7 || a1[14] != 45 ) /*0x10419ba65*/
    return false; /*0x10419ba65*/
  v11 = false; /*0x10419ba6b*/
  for ( k = 0; k != 4; v11 = k++ >= 3 ) /*0x10419ba6d*/
  {
    v13 = a1[k + 15]; /*0x10419ba6f*/
    if ( (unsigned __int8)(v13 - 48) >= 0xAu ) /*0x10419ba7c*/
    {
      v14 = (unsigned int)v13 - 65; /*0x10419ba82*/
      if ( (unsigned int)v14 > 0x25 || !_bittest64(&v3, v14) ) /*0x10419ba8a*/
        break; /*0x10419ba8e*/
    }
  }
  if ( !v11 || a1[19] != 45 ) /*0x10419bab1*/
    return false; /*0x10419bab1*/
  v15 = false; /*0x10419bab7*/
  for ( m = 0; m != 4; v15 = m++ >= 3 ) /*0x10419bab9*/
  {
    v17 = a1[m + 20]; /*0x10419babb*/
    if ( (unsigned __int8)(v17 - 48) >= 0xAu ) /*0x10419bac8*/
    {
      v18 = (unsigned int)v17 - 65; /*0x10419bace*/
      if ( (unsigned int)v18 > 0x25 || !_bittest64(&v3, v18) ) /*0x10419bad6*/
        break; /*0x10419bada*/
    }
  }
  if ( !v15 || a1[24] != 45 ) /*0x10419baf9*/
    return false; /*0x10419baf9*/
  v19 = false; /*0x10419bafb*/
  for ( n = 0; n != 12; v19 = n++ >= 0xB ) /*0x10419bafd*/
  {
    v21 = a1[n + 25]; /*0x10419baff*/
    if ( (unsigned __int8)(v21 - 48) >= 0xAu ) /*0x10419bb0c*/
    {
      v22 = (unsigned int)v21 - 65; /*0x10419bb12*/
      if ( (unsigned int)v22 > 0x25 || !_bittest64(&v3, v22) ) /*0x10419bb1a*/
        break; /*0x10419bb1e*/
    }
  }
  return v19 && a1[37] == 125; /*0x10419bb3d*/
}

// Address: 0x10419bb46 | Name: __ZN3RBX27isStandardGuidNoCurlyBracesENS_10StringViewE
bool __fastcall RBX::isStandardGuidNoCurlyBraces(_BYTE *a1, __int64 a2)
{
  bool v2; // al
  __int64 v3; // rcx
  unsigned __int64 i; // rdx
  unsigned __int8 v5; // si
  unsigned __int64 v6; // rsi
  bool v7; // al
  unsigned __int64 j; // rdx
  unsigned __int8 v9; // si
  unsigned __int64 v10; // rsi
  bool v11; // al
  unsigned __int64 k; // rdx
  unsigned __int8 v13; // si
  unsigned __int64 v14; // rsi
  bool v15; // al
  unsigned __int64 m; // rdx
  unsigned __int8 v17; // si
  unsigned __int64 v18; // rsi
  bool v19; // al
  unsigned __int64 n; // rdx
  unsigned __int8 v21; // si
  unsigned __int64 v22; // rsi

  if ( a2 != 36 ) /*0x10419bb4e*/
    return false; /*0x10419bb4e*/
  v2 = false; /*0x10419bb54*/
  v3 = 0x3F0000003FLL; /*0x10419bb56*/
  for ( i = 0; i != 8; ++i ) /*0x10419bb60*/
  {
    v5 = a1[i]; /*0x10419bb62*/
    if ( (unsigned __int8)(v5 - 48) >= 0xAu ) /*0x10419bb6e*/
    {
      v6 = (unsigned int)v5 - 65; /*0x10419bb74*/
      if ( (unsigned int)v6 > 0x25 || !_bittest64(&v3, v6) ) /*0x10419bb7c*/
        break; /*0x10419bb80*/
    }
    v2 = i >= 7; /*0x10419bb8a*/
  }
  if ( !v2 || a1[8] != 45 ) /*0x10419bba2*/
    return false; /*0x10419bba2*/
  v7 = false; /*0x10419bba8*/
  for ( j = 0; j != 4; v7 = j++ >= 3 ) /*0x10419bbaa*/
  {
    v9 = a1[j + 9]; /*0x10419bbac*/
    if ( (unsigned __int8)(v9 - 48) >= 0xAu ) /*0x10419bbb9*/
    {
      v10 = (unsigned int)v9 - 65; /*0x10419bbbf*/
      if ( (unsigned int)v10 > 0x25 || !_bittest64(&v3, v10) ) /*0x10419bbc7*/
        break; /*0x10419bbcb*/
    }
  }
  if ( !v7 || a1[13] != 45 ) /*0x10419bbed*/
    return false; /*0x10419bbed*/
  v11 = false; /*0x10419bbf3*/
  for ( k = 0; k != 4; v11 = k++ >= 3 ) /*0x10419bbf5*/
  {
    v13 = a1[k + 14]; /*0x10419bbf7*/
    if ( (unsigned __int8)(v13 - 48) >= 0xAu ) /*0x10419bc04*/
    {
      v14 = (unsigned int)v13 - 65; /*0x10419bc0a*/
      if ( (unsigned int)v14 > 0x25 || !_bittest64(&v3, v14) ) /*0x10419bc12*/
        break; /*0x10419bc16*/
    }
  }
  if ( !v11 || a1[18] != 45 ) /*0x10419bc38*/
    return false; /*0x10419bc38*/
  v15 = false; /*0x10419bc3a*/
  for ( m = 0; m != 4; v15 = m++ >= 3 ) /*0x10419bc3c*/
  {
    v17 = a1[m + 19]; /*0x10419bc3e*/
    if ( (unsigned __int8)(v17 - 48) >= 0xAu ) /*0x10419bc4b*/
    {
      v18 = (unsigned int)v17 - 65; /*0x10419bc51*/
      if ( (unsigned int)v18 > 0x25 || !_bittest64(&v3, v18) ) /*0x10419bc59*/
        break; /*0x10419bc5d*/
    }
  }
  if ( v15 && a1[23] == 45 ) /*0x10419bc7b*/
  {
    v19 = false; /*0x10419bc7d*/
    for ( n = 0; n != 12; ++n ) /*0x10419bc7f*/
    {
      v21 = a1[n + 24]; /*0x10419bc81*/
      if ( (unsigned __int8)(v21 - 48) >= 0xAu ) /*0x10419bc8e*/
      {
        v22 = (unsigned int)v21 - 65; /*0x10419bc94*/
        if ( (unsigned int)v22 > 0x25 || !_bittest64(&v3, v22) ) /*0x10419bc9c*/
          break; /*0x10419bca0*/
      }
      v19 = n >= 0xB; /*0x10419bcaa*/
    }
  }
  else
  {
    return false; /*0x10419bcb8*/
  }
  return v19; /*0x10419bcbc*/
}

// Address: 0x10419c0be | Name: __ZN3RBX24IsolatedAllocationHandleIvEaSERKS1_
RBX::_anonymous_namespace_ *__fastcall RBX::IsolatedAllocationHandle<void>::operator=(
        RBX::_anonymous_namespace_ *a1,
        RBX::_anonymous_namespace_ *a2)
{
  if ( a1 != a2 ) /*0x10419c0ce*/
  {
    if ( *(_QWORD *)a2 != 0 ) /*0x10419c0d9*/
      _InterlockedIncrement64((volatile signed __int64 *)(*(_QWORD *)a2 /*0x10419c0e0*/
                                                        + RBX::`anonymous namespace'::getPageSizeInBytes(this: a1)
                                                        + 8));
    if ( *(_QWORD *)a1 != 0 ) /*0x10419c0ec*/
      RBX::`anonymous namespace'::releaseOwnership(a1: *(void **)a1); /*0x10419c0ee*/
    *(_QWORD *)a1 = *(_QWORD *)a2; /*0x10419c0f6*/
  }
  return a1; /*0x10419c100*/
}

// Address: 0x10419c1a2 | Name: __ZN3RBX24IsolatedAllocationHandleIvEaSEOS1_
void **__fastcall RBX::IsolatedAllocationHandle<void>::operator=(void **a1, void **a2)
{
  void *v4; // rdi
  void *v5; // rax

  if ( a1 != a2 ) /*0x10419c1af*/
  {
    v4 = *a1; /*0x10419c1b4*/
    if ( *a1 != nullptr ) /*0x10419c1ba*/
      RBX::`anonymous namespace'::releaseOwnership(a1: v4); /*0x10419c1bc*/
    v5 = *a2; /*0x10419c1c1*/
    *a2 = nullptr; /*0x10419c1c4*/
    *a1 = v5; /*0x10419c1cb*/
  }
  return a1; /*0x10419c1d1*/
}

// Address: 0x10419c270 | Name: __ZNK3RBX24IsolatedAllocationHandleIvEcvbEv
bool __fastcall RBX::IsolatedAllocationHandle<void>::operator bool(_QWORD *a1)
{
  return *a1 != 0; /*0x10419c27b*/
}

// Address: 0x10419c2f4 | Name: __ZN3RBX24IsolatedAllocationHandleIvEaSEDn
void **__fastcall RBX::IsolatedAllocationHandle<void>::operator=(void **a1)
{
  void *v2; // rdi

  v2 = *a1; /*0x10419c2fd*/
  if ( v2 != nullptr ) /*0x10419c303*/
  {
    RBX::`anonymous namespace'::releaseOwnership(a1: v2); /*0x10419c305*/
    *a1 = nullptr; /*0x10419c30a*/
  }
  return a1; /*0x10419c318*/
}

// Address: 0x10419c6b8 | Name: __ZN3RBX14IsValueOutlierEdjddNS_10ConfidenceE
__m128d __fastcall RBX::IsValueOutlier(int a1, int a2, double a3, double a4, double a5)
{
  RBX *v5; // rdi
  unsigned int MappedDOF; // eax
  __m128d v8; // xmm3
  __m128d v9; // xmm0
  double v11; // [rsp+0h] [rbp-30h]
  double v12; // [rsp+18h] [rbp-18h]
  double v13; // [rsp+20h] [rbp-10h]

  v5 = (RBX *)(unsigned int)(a1 - 1); /*0x10419c6c1*/
  if ( (_DWORD)v5 != 0 ) /*0x10419c6c3*/
  {
    v11 = a3; /*0x10419c6c7*/
    v12 = a5; /*0x10419c6cb*/
    v13 = a4; /*0x10419c6d0*/
    MappedDOF = RBX::GetMappedDOF(this: v5); /*0x10419c6d5*/
    a4 = v13; /*0x10419c6da*/
    a5 = v12; /*0x10419c6df*/
    a3 = v11; /*0x10419c6e4*/
    v8 = (__m128d)RBX::DOFs[5 * MappedDOF + 1 + a2]; /*0x10419c6fd*/
  }
  else
  {
    v8 = (__m128d)0x7FEFFFFFFFFFFFFFuLL; /*0x10419c705*/
  }
  v9.f64[0] = fabs((a3 - a4) / a5); /*0x10419c715*/
  return _mm_and_pd((__m128d)0x3FF0000000000000uLL, _mm_cmplt_sd(v8, v9)); /*0x10419c72e*/
}

// Address: 0x1041b6dc6 | Name: __ZN3RBXL14initSystemTimeEv
__int128 __usercall RBX::initSystemTime@<xmm0>(RBX *this@<rdi>)
{
  int v1; // r15d
  int v2; // eax
  RBX *v3; // rdi
  __int128 v4; // xmm1
  double v5; // xmm0_8
  _BYTE v7[40]; // [rsp+0h] [rbp-50h] BYREF
  __int64 v8; // [rsp+28h] [rbp-28h] BYREF
  double v9; // [rsp+30h] [rbp-20h]

  v8 = rsl_time(a1: this); /*0x1041b6ddc*/
  memset(v7, 0, 36); /*0x1041b6deb*/
  rsl_gmtime_r(a1: &v8, a2: v7); /*0x1041b6dfd*/
  v1 = v8; /*0x1041b6e02*/
  v2 = rsl_mktime(a1: v7); /*0x1041b6e08*/
  v9 = (double)((int)v8 + v1 - v2); /*0x1041b6e1b*/
  RBX::nowPrecise(this: v3); /*0x1041b6e20*/
  v4 = *(unsigned __int64 *)&v9; /*0x1041b6e25*/
  *(double *)&v4 = v9 - v5; /*0x1041b6e2a*/
  return v4; /*0x1041b6e32*/
}

// Address: 0x1041c36ba | Name: __ZN3RBX32isProcessorArchitectureSupportedENS_22ProcessorArchitecturesE
bool __fastcall RBX::isProcessorArchitectureSupported(RBX *a1)
{
  int v1; // ebx
  int HostArchitecture; // ecx
  _anonymous_namespace_ *v3; // rdi
  bool result; // al

  v1 = (int)a1; /*0x1041c36c0*/
  HostArchitecture = RBX::GetHostArchitecture(this: a1); /*0x1041c36c7*/
  result = true; /*0x1041c36c9*/
  if ( HostArchitecture != v1 ) /*0x1041c36cd*/
    return (v1 ^ 2 | HostArchitecture ^ 3) == 0 /*0x1041c36e6*/
        && (unsigned int)`anonymous namespace'::getProcessIsTranslated(this: v3) == 1;
  return result; /*0x1041c36ec*/
}

// Address: 0x10420a074 | Name: __ZN3RBX17isPointInsideBallERKNS_4simd3vecILi4EfEES4_
bool __fastcall RBX::isPointInsideBall(__m128 *a1, __m128 *a2)
{
  __m128 v2; // xmm0
  __m128 v3; // xmm1

  v2 = _mm_min_ps(*a2, _mm_shuffle_ps(*a2, *a2, 201)); /*0x10420a082*/
  v2.f32[0] = fminf(v2.f32[0], _mm_movehdup_ps(v2).f32[0]); /*0x10420a089*/
  v3 = _mm_mul_ps(*a1, *a1); /*0x10420a098*/
  return (float)((float)(v2.f32[0] * 0.5) * (float)(v2.f32[0] * 0.5)) >= (float)(_mm_movehl_ps(v3, v3).f32[0] /*0x10420a0b3*/
                                                                               + _mm_hadd_ps(v3, v3).f32[0]);
}

// Address: 0x10420a0b5 | Name: __ZN3RBX18isPointInsideBlockERKNS_4simd3vecILi4EfEES4_
bool __fastcall RBX::isPointInsideBlock(__m128 *a1, __m128 *a2)
{
  __m128 v2; // xmm0

  v2 = _mm_mul_ps(*a2, (__m128)xmmword_108F49A20); /*0x10420a0bc*/
  return (~_mm_movemask_epi8((__m128i)_mm_and_ps(_mm_cmple_ps(*a1, v2), _mm_cmple_ps(_mm_sub_ps((__m128)0LL, v2), *a1))) /*0x10420a0e5*/
        & 0xFFF) == 0;
}

// Address: 0x10420a0e7 | Name: __ZN3RBX21isPointInsideCylinderERKNS_4simd3vecILi4EfEES4_
bool __fastcall RBX::isPointInsideCylinder(__m128 *a1, __m128 *a2)
{
  __m128 v2; // xmm1
  __m128 v4; // xmm2
  __m128 v5; // xmm1
  __m128 v6; // xmm3
  __int32 v7; // xmm4_4
  __m128 v8; // xmm0

  v2 = *a2; /*0x10420a0eb*/
  if ( fabs(a1->f32[0]) > (float)(0.5 * COERCE_FLOAT(*a2)) ) /*0x10420a10a*/
    return false; /*0x10420a10c*/
  v4 = _mm_movehdup_ps(v2); /*0x10420a110*/
  v5 = _mm_movehl_ps(v2, v2); /*0x10420a114*/
  v6 = _mm_cmpunord_ss(v4, v4); /*0x10420a11a*/
  v7 = v6.i32[0] & v5.i32[0]; /*0x10420a122*/
  v5.f32[0] = fminf(v5.f32[0], v4.f32[0]); /*0x10420a125*/
  v6.i32[0] = _mm_andnot_ps(v6, v5).u32[0] | v7; /*0x10420a12c*/
  v8 = _mm_mul_ps(*a1, *a1); /*0x10420a137*/
  return (float)((float)(v6.f32[0] * 0.5) * (float)(v6.f32[0] * 0.5)) >= _mm_movehdup_ps(_mm_add_ps(_mm_unpackhi_ps(v5, v8), v8)).f32[0]; /*0x10420a14e*/
}

// Address: 0x10420a150 | Name: __ZN3RBX18isPointInsideWedgeERKNS_4simd3vecILi4EfEES4_
bool __fastcall RBX::isPointInsideWedge(__m128 *a1, __m128 *a2)
{
  __m128 v2; // xmm2
  __m128 v3; // xmm0

  v2 = _mm_mul_ps((__m128)xmmword_108F49A20, *a2); /*0x10420a15e*/
  if ( (~_mm_movemask_epi8((__m128i)_mm_and_ps(_mm_cmple_ps(*a1, v2), _mm_cmple_ps(_mm_sub_ps((__m128)0LL, v2), *a1))) /*0x10420a183*/
      & 0xFFF) != 0 )
    return false; /*0x10420a1b3*/
  v3 = _mm_mul_ps( /*0x10420a197*/
         *a1,
         _mm_mul_ps(
           _mm_shuffle_ps(*a2, *a2, 216),
           _mm_shuffle_ps((__m128)xmmword_109687EB0, (__m128)xmmword_109687EB0, 216)));
  return (float)(_mm_movehl_ps(v3, v3).f32[0] + _mm_hadd_ps(v3, v3).f32[0]) <= 0.0; /*0x10420a1b5*/
}

// Address: 0x10420a1b7 | Name: __ZN3RBX24isPointInsideCornerWedgeERKNS_4simd3vecILi4EfEES4_
bool __fastcall RBX::isPointInsideCornerWedge(__m128 *a1, __m128 *a2)
{
  __m128 v2; // xmm3
  __m128 v3; // xmm0
  __m128 v4; // xmm0

  v2 = _mm_mul_ps((__m128)xmmword_108F49A20, *a2); /*0x10420a1c8*/
  if ( (~_mm_movemask_epi8((__m128i)_mm_and_ps(_mm_cmple_ps(*a1, v2), _mm_cmple_ps(_mm_sub_ps((__m128)0LL, v2), *a1))) /*0x10420a1ed*/
      & 0xFFF) != 0 )
    return false; /*0x10420a217*/
  v3 = _mm_mul_ps(_mm_mul_ps(_mm_shuffle_ps(*a2, *a2, 97), (__m128)xmmword_109687EC0), _mm_shuffle_ps(*a1, *a1, 148)); /*0x10420a1fe*/
  v4 = _mm_hadd_ps(v3, v3); /*0x10420a201*/
  return _mm_movemask_ps(_mm_cmple_ps(_mm_unpacklo_ps(v4, v4), (__m128)0LL)) == 15; /*0x10420a219*/
}

// Address: 0x10421ec21 | Name: __ZN3RBX7isValidERKN19ConvexDecomposition12ConvexResultE
bool __fastcall RBX::isValid(RBX *this, const ConvexDecomposition::ConvexResult *a2)
{
  bool result; // al
  float v3; // xmm0_4

  result = false; /*0x10421ec21*/
  if ( *(_DWORD *)this >= 4u && *((_DWORD *)this + 4) >= 4u ) /*0x10421ec2c*/
  {
    RBX::detail::computeVolume(this, a2); /*0x10421ec32*/
    return v3 > 0.0; /*0x10421ec3d*/
  }
  return result; /*0x10421ec41*/
}

// Address: 0x1043e4f60 | Name: __ZN3RBXL12initEncodersEv
__int64 __fastcall RBX::initEncoders(RBX *this, unsigned __int64 a2)
{
  __int64 v2; // rbx
  RBX::RotationEncoder *v3; // rbx
  __int64 v5; // [rsp+0h] [rbp-160h]
  _BYTE v6[88]; // [rsp+38h] [rbp-128h] BYREF
  _BYTE v7[88]; // [rsp+90h] [rbp-D0h] BYREF
  _BYTE v8[88]; // [rsp+E8h] [rbp-78h] BYREF
  __int64 v9; // [rsp+140h] [rbp-20h] BYREF

  v2 = operator new(a1: (RBX::Memory *)0x18, a2); /*0x1043e4f88*/
  RBX::RotationEncoder::RotationEncoder(this: (RBX::RotationEncoder *)v6, a2: 0xBu, a3: 0x15u); /*0x1043e4fac*/
  RBX::RotationEncoder::RotationEncoder(this: (RBX::RotationEncoder *)v7, a2: 0xEu, a3: 0x1Au); /*0x1043e4fcb*/
  RBX::RotationEncoder::RotationEncoder(this: (RBX::RotationEncoder *)v8, a2: 0x10u, a3: 0x20u); /*0x1043e4fe7*/
  std::vector<RBX::RotationEncoder>::vector[abi:ne200100](a1: v2, a2: v6, a3: 3); /*0x1043e5018*/
  v5 = v2; /*0x1043e5026*/
  v3 = (RBX::RotationEncoder *)&v9; /*0x1043e5037*/
  do /*0x1043e504d*/
  {
    v3 = (RBX::RotationEncoder *)((char *)v3 - 88); /*0x1043e503e*/
    RBX::RotationEncoder::~RotationEncoder(this: v3); /*0x1043e5045*/
  }
  while ( v3 != (RBX::RotationEncoder *)v6 ); /*0x1043e504d*/
  return v5; /*0x1043e5070*/
}

// Address: 0x104442bc2 | Name: __ZZN3RBXL14incrementEntryIN5immer3mapIjNS_10Reflection7VariantENS_12_GLOBAL__N_122OrderedImmerUInt32HashENSt3__18equal_toIjEENS1_13memory_policyINS5_23MultiFreeListHeapPolicyENS1_15refcount_policyENS1_15spinlock_policyENS1_20no_transience_policyELb0ELb1EEELj5EEEjEES4_RT_RKT0_RKS4_ENKUlS4_E_clES4_
__int64 __fastcall RBX::incrementEntry<immer::map<unsigned int,RBX::Reflection::Variant,RBX::`anonymous namespace'::OrderedImmerUInt32Hash,std::equal_to<unsigned int>,immer::memory_policy<RBX::`anonymous namespace'::MultiFreeListHeapPolicy,immer::refcount_policy,immer::spinlock_policy,immer::no_transience_policy,false,true>,5u>,unsigned int>(immer::map<unsigned int,RBX::Reflection::Variant,RBX::`anonymous namespace'::OrderedImmerUInt32Hash,std::equal_to<unsigned int>,immer::memory_policy<RBX::`anonymous namespace'::MultiFreeListHeapPolicy,immer::refcount_policy,immer::spinlock_policy,immer::no_transience_policy,false,true>,5u> &,unsigned int const&,RBX::Reflection::Variant const&)::{lambda(RBX::Reflection::Variant)#1}::operator()(
        __int64 a1,
        __int64 a2,
        __int64 *a3)
{
  double v6; // r15
  _QWORD *v7; // rdi
  _QWORD *v8; // r15
  __int64 v9; // rdi
  __int64 v10; // rsi
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  _QWORD *v14; // rdi
  __int64 v15; // rdi
  __int64 v16; // r14
  __int64 v17; // rax
  double v19; // [rsp+8h] [rbp-28h]

  v6 = *(double *)a3; /*0x104442bda*/
  if ( RBX::Reflection::Type::getSingleton<double>(a1) == *(_QWORD *)&v6 && a3[1] != 0 ) /*0x104442c7c*/
  {
    v14 = *(_QWORD **)a2; /*0x104442c86*/
    *v14 = *a3; /*0x104442c8d*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v14 + 1, a2: a3 + 1); /*0x104442c94*/
    **(_BYTE **)(a2 + 8) = 1; /*0x104442c9e*/
    v19 = *((double *)a3 + 2) + **(double **)(a2 + 16); /*0x104442cb0*/
    *(_QWORD *)a1 = RBX::Reflection::Type::getSingleton<double>(a1: v15); /*0x104442cba*/
    *(_QWORD *)(a1 + 8) = 0; /*0x104442cbd*/
    v16 = RBX::Reflection::detail::typed_holder<double>::singleton(); /*0x104442cca*/
    v17 = *(_QWORD *)(a1 + 8); /*0x104442ccd*/
    if ( v17 == v16 ) /*0x104442cd4*/
    {
      *(double *)(a1 + 16) = v19; /*0x104442cf7*/
    }
    else
    {
      if ( v17 != 0 ) /*0x104442cd9*/
        (*(void (__fastcall **)(__int64))(v17 + 16))(a1: a1 + 16); /*0x104442cdf*/
      *(double *)(a1 + 16) = v19; /*0x104442ce7*/
      *(_QWORD *)(a1 + 8) = v16; /*0x104442cec*/
    }
  }
  else
  {
    v7 = *(_QWORD **)a2; /*0x104442beb*/
    *v7 = *a3; /*0x104442bf2*/
    v8 = a3 + 1; /*0x104442bf5*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v7 + 1, a2: a3 + 1); /*0x104442c00*/
    **(_BYTE **)(a2 + 8) = 0; /*0x104442c0a*/
    *(_QWORD *)a1 = *a3; /*0x104442c10*/
    *(_QWORD *)(a1 + 8) = 0; /*0x104442c13*/
    v11 = a3[1]; /*0x104442c1b*/
    if ( v11 != 0 ) /*0x104442c22*/
    {
      (*(void (__fastcall **)(__int64 *, __int64))(v11 + 8))(a1: a3 + 2, a2: a1 + 16); /*0x104442c2f*/
      v12 = a3[1]; /*0x104442c32*/
      *(_QWORD *)(a1 + 8) = v12; /*0x104442c36*/
      if ( v12 != 0 ) /*0x104442c3d*/
      {
        (*(void (__fastcall **)(__int64 *))(v12 + 16))(a1: a3 + 2); /*0x104442c42*/
        *v8 = 0; /*0x104442c45*/
      }
    }
    *a3 = RBX::Reflection::Type::getSingleton<void>(a1: v9, a2: v10); /*0x104442c51*/
    v13 = a3[1]; /*0x104442c54*/
    if ( v13 != 0 ) /*0x104442c5b*/
    {
      (*(void (__fastcall **)(__int64 *))(v13 + 16))(a1: a3 + 2); /*0x104442c68*/
      *v8 = 0; /*0x104442c6b*/
    }
  }
  return a1; /*0x104442cff*/
}

// Address: 0x104444b5a | Name: __ZZN3RBXL14incrementEntryIN5immer3mapINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_10Reflection7VariantENS3_4hashIS9_EENS3_8equal_toIS9_EENS1_13memory_policyINS_12_GLOBAL__N_123MultiFreeListHeapPolicyENS1_15refcount_policyENS1_15spinlock_policyENS1_20no_transience_policyELb0ELb1EEELj5EEES9_EESB_RT_RKT0_RKSB_ENKUlSB_E_clESB_
__int64 __fastcall RBX::incrementEntry<immer::map<std::string,RBX::Reflection::Variant,std::hash<std::string>,std::equal_to<std::string>,immer::memory_policy<RBX::`anonymous namespace'::MultiFreeListHeapPolicy,immer::refcount_policy,immer::spinlock_policy,immer::no_transience_policy,false,true>,5u>,std::string>(immer::map<std::string,RBX::Reflection::Variant,std::hash<std::string>,std::equal_to<std::string>,immer::memory_policy<RBX::`anonymous namespace'::MultiFreeListHeapPolicy,immer::refcount_policy,immer::spinlock_policy,immer::no_transience_policy,false,true>,5u> &,std::string const&,RBX::Reflection::Variant const&)::{lambda(RBX::Reflection::Variant)#1}::operator()(
        __int64 a1,
        __int64 a2,
        __int64 *a3)
{
  double v6; // r15
  _QWORD *v7; // rdi
  _QWORD *v8; // r15
  __int64 v9; // rdi
  __int64 v10; // rsi
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  _QWORD *v14; // rdi
  __int64 v15; // rdi
  __int64 v16; // r14
  __int64 v17; // rax
  double v19; // [rsp+8h] [rbp-28h]

  v6 = *(double *)a3; /*0x104444b72*/
  if ( RBX::Reflection::Type::getSingleton<double>(a1) == *(_QWORD *)&v6 && a3[1] != 0 ) /*0x104444c14*/
  {
    v14 = *(_QWORD **)a2; /*0x104444c1e*/
    *v14 = *a3; /*0x104444c25*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v14 + 1, a2: a3 + 1); /*0x104444c2c*/
    **(_BYTE **)(a2 + 8) = 1; /*0x104444c36*/
    v19 = *((double *)a3 + 2) + **(double **)(a2 + 16); /*0x104444c48*/
    *(_QWORD *)a1 = RBX::Reflection::Type::getSingleton<double>(a1: v15); /*0x104444c52*/
    *(_QWORD *)(a1 + 8) = 0; /*0x104444c55*/
    v16 = RBX::Reflection::detail::typed_holder<double>::singleton(); /*0x104444c62*/
    v17 = *(_QWORD *)(a1 + 8); /*0x104444c65*/
    if ( v17 == v16 ) /*0x104444c6c*/
    {
      *(double *)(a1 + 16) = v19; /*0x104444c8f*/
    }
    else
    {
      if ( v17 != 0 ) /*0x104444c71*/
        (*(void (__fastcall **)(__int64))(v17 + 16))(a1: a1 + 16); /*0x104444c77*/
      *(double *)(a1 + 16) = v19; /*0x104444c7f*/
      *(_QWORD *)(a1 + 8) = v16; /*0x104444c84*/
    }
  }
  else
  {
    v7 = *(_QWORD **)a2; /*0x104444b83*/
    *v7 = *a3; /*0x104444b8a*/
    v8 = a3 + 1; /*0x104444b8d*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=(a1: v7 + 1, a2: a3 + 1); /*0x104444b98*/
    **(_BYTE **)(a2 + 8) = 0; /*0x104444ba2*/
    *(_QWORD *)a1 = *a3; /*0x104444ba8*/
    *(_QWORD *)(a1 + 8) = 0; /*0x104444bab*/
    v11 = a3[1]; /*0x104444bb3*/
    if ( v11 != 0 ) /*0x104444bba*/
    {
      (*(void (__fastcall **)(__int64 *, __int64))(v11 + 8))(a1: a3 + 2, a2: a1 + 16); /*0x104444bc7*/
      v12 = a3[1]; /*0x104444bca*/
      *(_QWORD *)(a1 + 8) = v12; /*0x104444bce*/
      if ( v12 != 0 ) /*0x104444bd5*/
      {
        (*(void (__fastcall **)(__int64 *))(v12 + 16))(a1: a3 + 2); /*0x104444bda*/
        *v8 = 0; /*0x104444bdd*/
      }
    }
    *a3 = RBX::Reflection::Type::getSingleton<void>(a1: v9, a2: v10); /*0x104444be9*/
    v13 = a3[1]; /*0x104444bec*/
    if ( v13 != 0 ) /*0x104444bf3*/
    {
      (*(void (__fastcall **)(__int64 *))(v13 + 16))(a1: a3 + 2); /*0x104444c00*/
      *v8 = 0; /*0x104444c03*/
    }
  }
  return a1; /*0x104444c97*/
}

// Address: 0x1045053f1 | Name: __ZN3RBX22isVideoApiMaybeEnabledEv
char __fastcall RBX::isVideoApiMaybeEnabled(RBX *this)
{
  return (FFlag::VideoApiEnabled | FFlag::VideoApiEnabledUniversalApp) & 1; /*0x104505403*/
}

// Address: 0x1045cc0bd | Name: __ZN3RBX35isBehaviorSupportEnabledInWorkspaceEPKNS_8InstanceE
__int64 __fastcall RBX::isBehaviorSupportEnabledInWorkspace(RBX *this, const RBX::Instance *a2)
{
  RBX::DataModel *v2; // rbx
  const RBX::Instance *v3; // rsi
  __int64 v4; // rax
  RBX::Workspace *Workspace; // rax

  v2 = this; /*0x1045cc0c3*/
  if ( (unsigned __int8)RBX::isBehaviorSupportEnabled(this) != 0 ) /*0x1045cc0cd*/
  {
    v4 = RBX::DataModel::get(this: v2, a2: v3); /*0x1045cc0d2*/
    LOBYTE(v2) = 1; /*0x1045cc0d7*/
    if ( v4 != 0 ) /*0x1045cc0dc*/
    {
      Workspace = (RBX::Workspace *)RBX::DataModelProp::getWorkspace(this: (RBX::DataModelProp *)(v4 + 720)); /*0x1045cc0e7*/
      if ( Workspace != nullptr ) /*0x1045cc0ef*/
        return RBX::Workspace::isServerAuthorityPropertyEnabledUNSAFE(this: Workspace); /*0x1045cc0fa*/
    }
  }
  else
  {
    LODWORD(v2) = 0; /*0x1045cc0ff*/
  }
  return (unsigned int)v2; /*0x1045cc0f8*/
}

// Address: 0x1045cc10a | Name: __ZN3RBX28isAuroraScriptServiceEnabledEv
char __fastcall RBX::isAuroraScriptServiceEnabled(RBX *this)
{
  return (FFlag::ProfileServiceReplicationMetrics | RBX::isBehaviorSupportEnabled(this)) & 1; /*0x1045cc11b*/
}

// Address: 0x1045cc11d | Name: __ZN3RBX30isAuroraScriptAllowListEnabledEv
__int64 __fastcall RBX::isAuroraScriptAllowListEnabled(RBX *this)
{
  if ( FFlag::DebugDisableAuroraScriptAllowList != 0 ) /*0x1045cc128*/
    return 0; /*0x1045cc12a*/
  else
    return RBX::isBehaviorSupportEnabled(this); /*0x1045cc12f*/
}

// Address: 0x1045cd8c7 | Name: __ZN3RBX17isLODablefunctionENS_10StringViewE
char __fastcall RBX::isLODablefunction(__int64 a1, __int64 a2)
{
  RSL::Arena *v3; // rdi
  __int64 DefaultArena; // rax
  _QWORD v5[2]; // [rsp+8h] [rbp-68h] BYREF
  char v6; // [rsp+1Fh] [rbp-51h] BYREF
  _OWORD v7[4]; // [rsp+20h] [rbp-50h] BYREF
  __int64 v8; // [rsp+60h] [rbp-10h] BYREF

  v5[0] = a1; /*0x1045cd8de*/
  v5[1] = a2; /*0x1045cd8e2*/
  if ( (_BYTE)`guard variable for'RBX::isLODablefunction(RBX::StringView)::lodableFunctions == 0 /*0x1045cd927*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::isLODablefunction(RBX::StringView)::lodableFunctions) != 0 )
  {
    v7[3] = *(_OWORD *)&off_10C96F588; /*0x1045cd934*/
    v7[2] = *(_OWORD *)&off_10C96F578; /*0x1045cd93f*/
    v7[1] = *(_OWORD *)&off_10C96F568; /*0x1045cd94a*/
    v7[0] = *(_OWORD *)&off_10C96F558; /*0x1045cd955*/
    DefaultArena = RSL::Arena::getDefaultArena(this: v3); /*0x1045cd959*/
    RBX::details::SplitHashTable<RBX::StringView,RBX::StringView,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::StringView>,RBX::details::DefaultEqualTo<RBX::StringView>,RBX::details::GetSelfKey<RBX::StringView>>::SplitHashTable<RBX::StringView const*,10,void>( /*0x1045cd96f*/
      a1: &RBX::isLODablefunction(RBX::StringView)::lodableFunctions,
      a2: v7,
      a3: &v8,
      a4: DefaultArena);
    RBX::isLODablefunction(a1: v7); /*0x1045cd978*/
  }
  RBX::isLODablefunction(a1: v5, a2: &v6); /*0x1045cd8f8*/
  return v6 & 1; /*0x1045cd912*/
}

// Address: 0x1045e3948 | Name: __ZN3RBX25isResimulatingAssertCheckEPNS_18AuroraScriptObjectE
__int64 __fastcall RBX::isResimulatingAssertCheck(RBX *this, RBX::AuroraScriptObject *a2, __int64 a3, __int64 a4)
{
  RBX::AuroraScriptService *v4; // rax

  v4 = (RBX::AuroraScriptService *)RBX::ServiceProvider::find<RBX::AuroraScriptService>(a1: this, a2, a3, a4); /*0x1045e394c*/
  if ( v4 != nullptr ) /*0x1045e3954*/
    return RBX::AuroraScriptService::isResimulating(this: v4); /*0x1045e395a*/
  else
    return 0; /*0x1045e395f*/
}

// Address: 0x104758248 | Name: __ZNK3RBX20InstanceArenaDeleterclINS_8InstanceEEEvPT_
char __fastcall RBX::InstanceArenaDeleter::operator()<RBX::Instance>(RBX::Security::Context *a1, unsigned __int16 *a2)
{
  char v3; // r15
  __int64 v4; // rbx
  unsigned int v5; // r15d
  __int64 v6; // rax
  __int64 v7; // r12
  RSL::AtomicPoolArena *Arena; // r15
  __int64 v9; // rdx
  RSL::Arena *v10; // rdi
  __int64 DefaultMover; // rax
  char result; // al
  _QWORD v13[2]; // [rsp+0h] [rbp-60h] BYREF
  __int128 v14; // [rsp+10h] [rbp-50h] BYREF
  unsigned __int16 *v15; // [rsp+28h] [rbp-38h] BYREF
  char v16; // [rsp+36h] [rbp-2Ah]
  char v17; // [rsp+37h] [rbp-29h]

  v16 = DFFlag::CreatableDeleterScopedScriptRestriction; /*0x104758265*/
  if ( DFFlag::CreatableDeleterScopedScriptRestriction == 1 ) /*0x10475826a*/
  {
    v3 = DFFlag::CreatableDeleterScopedScriptRestrictionReport /*0x10475828c*/
       | (2 * DFFlag::CreatableDeleterScopedScriptRestrictionBlock)
       | 4;
    if ( DFFlag::CreatableDeleterScopedScriptRestrictionCrash == 0 ) /*0x104758293*/
      v3 = DFFlag::CreatableDeleterScopedScriptRestrictionReport /*0x104758293*/
         | (2 * DFFlag::CreatableDeleterScopedScriptRestrictionBlock);
    v4 = RBX::Security::Context::currentMutable(this: a1); /*0x10475829c*/
    v17 = *(_BYTE *)(v4 + 32); /*0x1047582a2*/
    *(_BYTE *)(v4 + 32) = v17 | v3; /*0x1047582a8*/
  }
  else
  {
    v4 = 0; /*0x1047582ae*/
  }
  if ( FFlag::RemovePredelete == 0 ) /*0x1047582ba*/
    RBX::Instance::DEPRECATED_predelete(this: (RBX::Instance *)a2, (RBX::Instance *)a2); /*0x1047582bf*/
  v5 = a2[74]; /*0x1047582c4*/
  v6 = RBX::Subsystem<RBX::InstancePool,false>::startup<RBX::SubsystemDefaultFactory<RBX::InstancePool>>(a1); /*0x1047582cc*/
  v7 = v6; /*0x1047582d1*/
  if ( v6 != 0 ) /*0x1047582d7*/
  {
    Arena = (RSL::AtomicPoolArena *)RBX::InstancePool::getArena(a1: *(_QWORD *)(v6 + 24), a2: v5); /*0x1047582e6*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x1047582f0*/
  }
  else
  {
    Arena = (RSL::AtomicPoolArena *)RBX::InstancePool::getArena(a1: 0, a2: v5); /*0x1047582ff*/
  }
  v15 = a2; /*0x104758306*/
  (**(void (__fastcall ***)(unsigned __int16 *))a2)(a1: a2); /*0x104758310*/
  v13[0] = RSL::AtomicPoolArena::getBlockSize(this: Arena); /*0x10475831e*/
  v13[1] = v9; /*0x104758321*/
  v14 = 0; /*0x10475832c*/
  DefaultMover = RSL::Arena::getDefaultMover(this: v10); /*0x104758331*/
  result = RSL::AtomicPoolArena::realloc(a1: Arena, a2: &v15, a3: v13, a4: &v14, a5: DefaultMover); /*0x104758345*/
  if ( v16 != 0 ) /*0x10475834e*/
  {
    result = v17; /*0x104758350*/
    *(_BYTE *)(v4 + 32) = v17; /*0x104758353*/
  }
  return result; /*0x104758356*/
}

// Address: 0x1047583f0 | Name: __ZNK3RBX15InstanceDeleterclINS_8InstanceEEEvPT_
char *__fastcall RBX::InstanceDeleter::operator()<RBX::Instance>(RBX::Security::Context *a1, RBX::Instance *a2)
{
  char v2; // r12
  char v4; // r15
  char v5; // r13
  __int64 v6; // r14
  char *result; // rax

  v4 = DFFlag::CreatableDeleterScopedScriptRestriction; /*0x104758408*/
  if ( DFFlag::CreatableDeleterScopedScriptRestriction == 1 ) /*0x10475840f*/
  {
    v5 = DFFlag::CreatableDeleterScopedScriptRestrictionReport /*0x104758431*/
       | (2 * DFFlag::CreatableDeleterScopedScriptRestrictionBlock)
       | 4;
    if ( DFFlag::CreatableDeleterScopedScriptRestrictionCrash == 0 ) /*0x104758438*/
      v5 = DFFlag::CreatableDeleterScopedScriptRestrictionReport /*0x104758438*/
         | (2 * DFFlag::CreatableDeleterScopedScriptRestrictionBlock);
    v6 = RBX::Security::Context::currentMutable(this: a1); /*0x104758441*/
    v2 = *(_BYTE *)(v6 + 32); /*0x104758444*/
    *(_BYTE *)(v6 + 32) = v2 | v5; /*0x10475844b*/
  }
  else
  {
    v6 = 0; /*0x104758451*/
  }
  result = &FFlag::RemovePredelete; /*0x104758454*/
  if ( FFlag::RemovePredelete == 0 ) /*0x10475845e*/
    result = (char *)RBX::Instance::DEPRECATED_predelete(this: a2, a2); /*0x104758463*/
  if ( a2 != nullptr ) /*0x10475846b*/
    result = (char *)(*(__int64 (__fastcall **)(RBX::Instance *))(*(_QWORD *)a2 + 8LL))(a1: a2); /*0x104758473*/
  if ( v4 != 0 ) /*0x104758479*/
    *(_BYTE *)(v6 + 32) = v2; /*0x10475847b*/
  return result; /*0x104758483*/
}

// Address: 0x104769b88 | Name: __ZN3RBX15InvocationMeterILi2EE13updateBucketsEb
void __fastcall RBX::InvocationMeter<2>::updateBuckets(__int64 a1, char a2)
{
  double v4; // xmm0_8
  unsigned __int32 v5; // eax
  unsigned __int32 v6; // ecx
  unsigned __int32 v7; // ecx
  __int64 v8; // rdx
  int v9; // esi

  v4 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1); /*0x104769b95*/
  if ( *(double *)(a1 + 2064) != v4 ) /*0x104769ba6*/
  {
    *(double *)(a1 + 2064) = v4; /*0x104769baa*/
    v5 = (int)((v4 - *(double *)(a1 + 2056)) * 1024.0); /*0x104769bc2*/
    v6 = _InterlockedExchange((volatile __int32 *)(a1 + 2048), v5); /*0x104769bc9*/
    if ( v6 < v5 ) /*0x104769bd1*/
    {
      v7 = v6 + 1; /*0x104769bd3*/
      do /*0x104769bf8*/
      {
        v8 = v7 & 0x7FF; /*0x104769bd7*/
        v9 = *(char *)(a1 + v8); /*0x104769bdd*/
        if ( v9 > 0 ) /*0x104769be3*/
        {
          do /*0x104769bee*/
          {
            _InterlockedDecrement((volatile signed __int32 *)(a1 + 2052)); /*0x104769be5*/
            --v9; /*0x104769bec*/
          }
          while ( v9 != 0 ); /*0x104769bee*/
        }
        *(_BYTE *)(a1 + v8) = 0; /*0x104769bf0*/
        ++v7; /*0x104769bf4*/
      }
      while ( v7 <= v5 ); /*0x104769bf8*/
    }
    if ( a2 != 0 ) /*0x104769bfd*/
    {
      ++*(_BYTE *)(a1 + (v5 & 0x7FF)); /*0x104769c04*/
      _InterlockedIncrement((volatile signed __int32 *)(a1 + 2052)); /*0x104769c07*/
    }
  }
}

// Address: 0x10479505e | Name: __ZN3RBXL17isRunningNativelyENS_22NativeFunctionProfiler12SamplingModeEP9lua_Statei
bool __fastcall RBX::isRunningNatively(int a1, __int64 a2, unsigned int a3)
{
  int v3; // eax

  if ( a1 != 1 ) /*0x104795061*/
    return false; /*0x10479507f*/
  if ( FFlag::LiftLuauAPIs == 1 ) /*0x104795071*/
    v3 = lua_incustomexecution(a1: a2, a2: a3); /*0x104795078*/
  else
    v3 = luaG_isnative(a1: a2, a2: a3); /*0x104795087*/
  return v3 != 0; /*0x104795081*/
}

// Address: 0x104882a14 | Name: __ZN3RBX26initPluginManagerSingletonEv
RBX *__fastcall RBX::initPluginManagerSingleton(RBX *this)
{
  RBX *result; // rax
  std::__shared_weak_count *v2; // rbx
  _QWORD v3[3]; // [rsp+8h] [rbp-18h] BYREF

  result = RBX::doPluginManagerSingleton(this: (RBX *)v3); /*0x104882a24*/
  v2 = (std::__shared_weak_count *)v3[1]; /*0x104882a29*/
  if ( v3[1] != 0 ) /*0x104882a30*/
  {
    result = (RBX *)_InterlockedExchangeAdd64((volatile signed __int64 *)(v3[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL); /*0x104882a39*/
    if ( result == nullptr ) /*0x104882a42*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v2 + 16LL))(a1: v2); /*0x104882a51*/
      return (RBX *)std::__shared_weak_count::__release_weak(this: v2); /*0x104882a5d*/
    }
  }
  return result; /*0x104882a44*/
}

// Address: 0x10488eea8 | Name: __ZN3RBX32initDebuggerForDebuggablePluginsEPNS_19IPluginDebuggerHostERKNSt3__110shared_ptrINS_9DataModelEEENS_9ArrayViewINS3_INS_6PluginEEEEE
_QWORD *__fastcall RBX::initDebuggerForDebuggablePlugins(
        RBX::Tasks::ThisTask *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5)
{
  __int64 v9; // rdx
  __int64 v10; // rcx
  RBX::Tasks::ThisTask *v11; // rdi
  __int64 v12; // rax
  char v13; // r14
  void *v14; // r15
  std::__shared_weak_count *v15; // rax
  std::__shared_weak_count *v16; // rcx
  _QWORD *v17; // rdx
  volatile signed __int64 *v18; // r12
  unsigned __int64 v19; // rsi
  __int128 v20; // xmm0
  volatile signed __int64 *v21; // rbx
  std::__shared_weak_count *v22; // rbx
  char v23; // cl
  std::__shared_weak_count *v24; // rbx
  std::__shared_weak_count *v25; // rax
  _QWORD *v26; // rcx
  RBX::Tasks::ThisTask *v27; // rdi
  __int64 v28; // r12
  __int64 v29; // rdx
  RBX::Tasks::ThisTask::detail *v30; // rdi
  __int64 TaskDataMap; // rax
  unsigned __int64 v32; // rsi
  __int64 v33; // r15
  __int64 v34; // rbx
  __int64 v35; // rbx
  __int64 v36; // r14
  unsigned int v37; // r15d
  std::__shared_weak_count *v38; // rbx
  std::__shared_weak_count *v39; // rbx
  void *v40; // rsi
  _BYTE v42[24]; // [rsp+10h] [rbp-260h]
  __int128 v43; // [rsp+28h] [rbp-248h] BYREF
  __int64 v44; // [rsp+38h] [rbp-238h]
  __int64 v45; // [rsp+48h] [rbp-228h] BYREF
  std::__shared_weak_count *v46[2]; // [rsp+50h] [rbp-220h]
  char v47; // [rsp+60h] [rbp-210h]
  __int64 v48; // [rsp+68h] [rbp-208h]
  __int16 v49; // [rsp+70h] [rbp-200h]
  __int128 v50; // [rsp+80h] [rbp-1F0h] BYREF
  __int64 v51; // [rsp+90h] [rbp-1E0h]
  __int128 v52; // [rsp+A0h] [rbp-1D0h] BYREF
  void *v53; // [rsp+B0h] [rbp-1C0h]
  __int64 v54; // [rsp+C0h] [rbp-1B0h] BYREF
  _QWORD *v55; // [rsp+C8h] [rbp-1A8h]
  std::__shared_weak_count *v56[2]; // [rsp+D0h] [rbp-1A0h] BYREF
  _QWORD v57[2]; // [rsp+E8h] [rbp-188h]
  __int64 v58; // [rsp+F8h] [rbp-178h] BYREF
  _BYTE v59[160]; // [rsp+100h] [rbp-170h] BYREF
  std::__shared_weak_count *v60[20]; // [rsp+1A0h] [rbp-D0h] BYREF

  v55 = a1; /*0x10488eec8*/
  RBX::Tasks::ThisTask::requireIsRunningAsTask(this: a1); /*0x10488eedd*/
  RBX::filterDebuggablePlugins(a1: (__int64)&v50, a2: a4, a3: a5); /*0x10488eef2*/
  if ( (_QWORD)v50 == *((_QWORD *)&v50 + 1) )
  {
    RBX::make_shared<RBX::Tasks::detail::FutureState<void>,char const*&>(a1: v60); /*0x10488eff3*/
    v15 = v60[0]; /*0x10488eff8*/
    *((_BYTE *)v60[0] + 36) = 1; /*0x10488f001*/
    *((_DWORD *)v15 + 8) = 1; /*0x10488f004*/
    *((_DWORD *)v15 + 6) = 0; /*0x10488f00b*/
    *((_BYTE *)v15 + 28) = 1; /*0x10488f012*/
    v16 = v60[1]; /*0x10488f016*/
    v17 = v55; /*0x10488f01d*/
    *v55 = v15; /*0x10488f024*/
    v17[1] = v16; /*0x10488f027*/
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>( /*0x10488ef19*/
      a1: &v52,
      a2: "PluginManager initDebuggerForDebuggablePlugins",
      a3: v9,
      a4: v10);
    *(_QWORD *)v42 = a2; /*0x10488ef1e*/
    v12 = *(_QWORD *)(a3 + 8); /*0x10488ef25*/
    *(_OWORD *)&v42[8] = *(_OWORD *)a3; /*0x10488ef2c*/
    if ( v12 != 0 ) /*0x10488ef36*/
      _InterlockedIncrement64((volatile signed __int64 *)(v12 + 8)); /*0x10488ef38*/
    v43 = v50; /*0x10488ef44*/
    v44 = v51; /*0x10488ef52*/
    v50 = 0; /*0x10488ef5c*/
    v51 = 0; /*0x10488ef65*/
    v13 = v52; /*0x10488ef6c*/
    v57[0] = *(_QWORD *)((char *)&v52 + 1); /*0x10488ef7a*/
    *(_QWORD *)((char *)v57 + 7) = *((_QWORD *)&v52 + 1); /*0x10488ef88*/
    v14 = v53; /*0x10488ef8f*/
    v52 = 0; /*0x10488ef96*/
    v53 = nullptr; /*0x10488ef9d*/
    LOBYTE(v46[0]) = 0; /*0x10488efa4*/
    v47 = 0; /*0x10488efaa*/
    v48 = 0x40000; /*0x10488efb0*/
    v49 = 1; /*0x10488efbb*/
    if ( (unsigned __int8)RBX::Tasks::ThisTask::isRunningAsTask(this: v11) != 0 ) /*0x10488efcb*/
    {
      RBX::Tasks::ThisTask::detail::getStopSource(this: (RBX::Tasks::ThisTask::detail *)v60); /*0x10488efd4*/
    }
    else
    {
      v56[0] = (std::__shared_weak_count *)"AsyncStopSource"; /*0x10488f03e*/
      RBX::make_shared<RBX::Tasks::detail::StopState,char const*&>(a1: v60); /*0x10488f048*/
    }
    v18 = (volatile signed __int64 *)v60[1]; /*0x10488f054*/
    qmemcpy(v46, v60, sizeof(v46)); /*0x10488f05b*/
    v47 = 1; /*0x10488f069*/
    RBX::Tasks::Promise<void>::Promise(a1: v56, a2: "Promise"); /*0x10488f07e*/
    if ( FFlag::StudioTasksAsyncOptInHangUp == 0 ) /*0x10488f08d*/
    {
      if ( v18 != nullptr ) /*0x10488f096*/
        _InterlockedIncrement64(v18 + 1); /*0x10488f098*/
      RBX::Tasks::Promise<void>::Promise(a1: v60); /*0x10488f0b6*/
      v20 = *(_OWORD *)v60; /*0x10488f0bb*/
      *(_OWORD *)v60 = 0; /*0x10488f0c1*/
      v21 = (volatile signed __int64 *)v56[1]; /*0x10488f0c4*/
      *(_OWORD *)v56 = v20; /*0x10488f0cb*/
      if ( v21 != nullptr && _InterlockedExchangeAdd64(v21 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10488f0e7*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v21 + 16))(a1: v21); /*0x10488f0ef*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v21); /*0x10488f0f5*/
      }
      v22 = v60[1]; /*0x10488f0fa*/
      if ( v60[1] != nullptr /*0x10488f116*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v60[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v22 + 16LL))(a1: v22); /*0x10488f11e*/
        std::__shared_weak_count::__release_weak(this: v22); /*0x10488f124*/
      }
      if ( v18 != nullptr && _InterlockedExchangeAdd64(v18 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10488f145*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v18 + 16))(a1: v18); /*0x10488f14d*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v18); /*0x10488f153*/
      }
    }
    v23 = *((_BYTE *)v56[0] + 36); /*0x10488f161*/
    *((_BYTE *)v56[0] + 36) = 1; /*0x10488f161*/
    if ( (v23 & 1) != 0 )
      RBXCRASH(a1: 0, a2: "Tasks: Promise getFuture() called multiple times");
    v24 = v56[0]; /*0x10488f16d*/
    v25 = v56[1]; /*0x10488f174*/
    if ( v56[1] != nullptr ) /*0x10488f17e*/
      _InterlockedIncrement64((volatile signed __int64 *)v56[1] + 1); /*0x10488f180*/
    v26 = v55; /*0x10488f185*/
    *v55 = v24; /*0x10488f18c*/
    v26[1] = v25; /*0x10488f18f*/
    v28 = operator new(a1: (RBX::Memory *)0x70, a2: v19); /*0x10488f19d*/
    qmemcpy((void *)v28, v42, 24); /*0x10488f1ab*/
    if ( *(_QWORD *)&v42[16] != 0 ) /*0x10488f1ba*/
      _InterlockedIncrement64((volatile signed __int64 *)(*(_QWORD *)&v42[16] + 8LL)); /*0x10488f1bc*/
    *(_OWORD *)(v28 + 24) = v43; /*0x10488f1c8*/
    *(_QWORD *)(v28 + 40) = v44; /*0x10488f1d5*/
    v44 = 0; /*0x10488f1dc*/
    v43 = 0; /*0x10488f1e3*/
    *(_QWORD *)(v28 + 48) = v24; /*0x10488f1e6*/
    *(std::__shared_weak_count **)(v28 + 56) = v56[1]; /*0x10488f1f2*/
    *(_OWORD *)v56 = 0; /*0x10488f1f7*/
    *(_OWORD *)(v28 + 64) = *(_OWORD *)v46; /*0x10488f205*/
    *(_OWORD *)v46 = 0; /*0x10488f20b*/
    *(_BYTE *)(v28 + 80) = v13; /*0x10488f212*/
    v29 = *(_QWORD *)((char *)v57 + 7); /*0x10488f21e*/
    *(_QWORD *)(v28 + 81) = v57[0]; /*0x10488f225*/
    *(_QWORD *)(v28 + 88) = v29; /*0x10488f22a*/
    *(_QWORD *)(v28 + 96) = v14; /*0x10488f22f*/
    *(_QWORD *)((char *)v57 + 7) = 0; /*0x10488f234*/
    v57[0] = 0; /*0x10488f23b*/
    *(_QWORD *)(v28 + 104) = 0; /*0x10488f242*/
    v54 = v28; /*0x10488f247*/
    if ( (unsigned __int8)RBX::Tasks::ThisTask::isRunningAsTask(this: v27) != 0 ) /*0x10488f255*/
    {
      TaskDataMap = RBX::Tasks::ThisTask::detail::getTaskDataMap(this: v30); /*0x10488f257*/
      if ( TaskDataMap != 0 ) /*0x10488f25f*/
      {
        v33 = TaskDataMap; /*0x10488f261*/
        v34 = operator new(a1: (RBX::Memory *)0x28, a2: v32); /*0x10488f26e*/
        std::unordered_map<std::string,std::shared_ptr<RBX::Tasks::ITaskData>>::unordered_map(a1: v34, a2: v33); /*0x10488f277*/
        std::unique_ptr<std::unordered_map<std::string,std::shared_ptr<RBX::Tasks::ITaskData>>>::reset[abi:ne200100]( /*0x10488f284*/
          a1: v28 + 104,
          a2: v34);
      }
    }
    if ( (*(_BYTE *)(v28 + 80) & 1) != 0 ) /*0x10488f28f*/
      v35 = *(_QWORD *)(v28 + 96); /*0x10488f29a*/
    else
      v35 = v28 + 81; /*0x10488f294*/
    v54 = 0; /*0x10488f2a6*/
    v45 = v28; /*0x10488f2b4*/
    RSL::Arena::getDefaultArena(this: v30); /*0x10488f2b7*/
    RSL::Closure::Closure( /*0x10488f2d0*/
      this: (RSL::Closure *)v60,
      a2: &v45,
      a3: RSL_CLOSURE<RBX::Tasks::Future<void> RBX::Tasks::async<RBX::initDebuggerForDebuggablePlugins(RBX::IPluginDebuggerHost *,std::shared_ptr<RBX::DataModel> const&,RBX::ArrayView<std::shared_ptr<RBX::Plugin>>)::$_0,void,void>(std::string,RBX::initDebuggerForDebuggablePlugins(RBX::IPluginDebuggerHost *,std::shared_ptr<RBX::DataModel> const&,RBX::ArrayView<std::shared_ptr<RBX::Plugin>>)::$_0 &&,RBX::Tasks::AsyncConfiguration)::{lambda(void)#1}>);
    RSL::Closure::Closure(a1: v59, a2: v60); /*0x10488f2e2*/
    RSL::Closure::~Closure(this: (RSL::Closure *)v60); /*0x10488f2ea*/
    v36 = v48; /*0x10488f2ef*/
    v37 = (char)v49; /*0x10488f2f6*/
    RSL::ThreadOwnerType::ThreadOwnerType(this: (RSL::ThreadOwnerType *)&v58, a2: nullptr); /*0x10488f30a*/
    RSL::Thread::Thread(a1: v60, a2: v35, a3: v59, a4: v36, a5: v37, a6: v58); /*0x10488f329*/
    RSL::Thread::detach(this: (RSL::Thread *)v60); /*0x10488f331*/
    RSL::Thread::~Thread(this: (RSL::Thread *)v60); /*0x10488f339*/
    RSL::Closure::~Closure(this: (RSL::Closure *)v59); /*0x10488f341*/
    std::unique_ptr<RBX::Tasks::Future<void> RBX::Tasks::async<RBX::initDebuggerForDebuggablePlugins(RBX::IPluginDebuggerHost *,std::shared_ptr<RBX::DataModel> const&,RBX::ArrayView<std::shared_ptr<RBX::Plugin>>)::$_0,void,void>(std::string,RBX::initDebuggerForDebuggablePlugins(RBX::IPluginDebuggerHost *,std::shared_ptr<RBX::DataModel> const&,RBX::ArrayView<std::shared_ptr<RBX::Plugin>>)::$_0 &&,RBX::Tasks::AsyncConfiguration)::TaskDetails,std::default_delete<RBX::Tasks::AsyncConfiguration>>::~unique_ptr[abi:ne200100](a1: &v45); /*0x10488f34d*/
    std::unique_ptr<RBX::Tasks::Future<void> RBX::Tasks::async<RBX::initDebuggerForDebuggablePlugins(RBX::IPluginDebuggerHost *,std::shared_ptr<RBX::DataModel> const&,RBX::ArrayView<std::shared_ptr<RBX::Plugin>>)::$_0,void,void>(std::string,RBX::initDebuggerForDebuggablePlugins(RBX::IPluginDebuggerHost *,std::shared_ptr<RBX::DataModel> const&,RBX::ArrayView<std::shared_ptr<RBX::Plugin>>)::$_0 &&,RBX::Tasks::AsyncConfiguration)::TaskDetails,std::default_delete<RBX::Tasks::AsyncConfiguration>>::~unique_ptr[abi:ne200100](a1: &v54); /*0x10488f359*/
    v38 = v56[1]; /*0x10488f35e*/
    if ( v56[1] != nullptr /*0x10488f37a*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v56[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v38 + 16LL))(a1: v38); /*0x10488f382*/
      std::__shared_weak_count::__release_weak(this: v38); /*0x10488f388*/
    }
    if ( v47 == 1 ) /*0x10488f3a2*/
    {
      v39 = v46[1]; /*0x10488f3a4*/
      if ( v46[1] != nullptr /*0x10488f3c0*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v46[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v39 + 16LL))(a1: v39); /*0x10488f3c8*/
        std::__shared_weak_count::__release_weak(this: v39); /*0x10488f3ce*/
      }
    }
    v60[0] = (std::__shared_weak_count *)&v43; /*0x10488f3da*/
    std::vector<std::shared_ptr<RBX::Plugin>>::__destroy_vector::operator()[abi:ne200100](a1: v60); /*0x10488f3dd*/
    if ( *(_QWORD *)&v42[16] != 0 /*0x10488f3fe*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v42[16] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v42[16] + 16LL))(a1: *(_QWORD *)&v42[16]); /*0x10488f406*/
      std::__shared_weak_count::__release_weak(this: *(std::__shared_weak_count **)&v42[16]); /*0x10488f40c*/
    }
    if ( (v52 & 1) != 0 ) /*0x10488f418*/
      operator delete(a1: (RBX::Memory *)v53, a2: v40); /*0x10488f421*/
  }
  v60[0] = (std::__shared_weak_count *)&v50; /*0x10488f42d*/
  std::vector<std::shared_ptr<RBX::Plugin>>::__destroy_vector::operator()[abi:ne200100](a1: v60); /*0x10488f430*/
  return v55; /*0x10488f44c*/
}

// Address: 0x10488f528 | Name: __ZZN3RBX32initDebuggerForDebuggablePluginsEPNS_19IPluginDebuggerHostERKNSt3__110shared_ptrINS_9DataModelEEENS_9ArrayViewINS3_INS_6PluginEEEEEEN3$_0D1Ev
__int64 __fastcall RBX::initDebuggerForDebuggablePlugins(RBX::IPluginDebuggerHost *,std::shared_ptr<RBX::DataModel> const&,RBX::ArrayView<std::shared_ptr<RBX::Plugin>>)::$_0::~$_0(
        __int64 a1)
{
  __int64 v3; // [rsp+0h] [rbp-10h] BYREF

  v3 = a1 + 24; /*0x10488f539*/
  std::vector<std::shared_ptr<RBX::Plugin>>::__destroy_vector::operator()[abi:ne200100](a1: &v3); /*0x10488f53c*/
  return std::shared_ptr<RBX::DataModel>::~shared_ptr[abi:ne200100](a1: a1 + 8); /*0x10488f551*/
}

// Address: 0x104898c06 | Name: __ZN3RBX11identity4x4EPf
__int64 __fastcall RBX::identity4x4(RBX *this, float *a2)
{
  *(_DWORD *)this = 1065353216; /*0x104898c0f*/
  *(_OWORD *)((char *)this + 4) = 0; /*0x104898c14*/
  *((_DWORD *)this + 5) = 1065353216; /*0x104898c18*/
  *(_OWORD *)((char *)this + 24) = 0; /*0x104898c1b*/
  *((_DWORD *)this + 10) = 1065353216; /*0x104898c1f*/
  *(_OWORD *)((char *)this + 44) = 0; /*0x104898c22*/
  *((_DWORD *)this + 15) = 1065353216; /*0x104898c26*/
  return 1065353216; /*0x104898c29*/
}

// Address: 0x104899486 | Name: __ZN3RBX10inverse4x4EPfPKf
__int64 __fastcall RBX::inverse4x4(RBX *this, float *a2, const float *a3, __int64 a4, __int64 a5, const float *a6)
{
  unsigned __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // r8
  __int64 v11; // r9
  const float *v12; // rdx
  __m128 v13; // xmm1
  __int64 i; // rax
  __m128 v16; // [rsp+0h] [rbp-330h]
  _QWORD v17[96]; // [rsp+10h] [rbp-320h] BYREF

  RBX::expand4x4(this: (RBX *)v17, a2, a3: a2 + 4, a4: a2 + 8, a5: a2 + 12, a6); /*0x1048994c0*/
  v16 = (__m128)v16.u32[(_QWORD)RBX::distill(this: (RBX *)v17, a2: (float *)0xC0, a3: v8, a4: v9, a5: v10, a6: v11) + 3]; /*0x1048994db*/
  RBX::adjoint4x4(this: (RBX *)v17, a2, a3: v12); /*0x1048994ec*/
  v13 = _mm_shuffle_ps(v16, v16, 0); /*0x1048994f8*/
  for ( i = 0; i != 8; i += 2 ) /*0x1048994fc*/
    *(__m128 *)((char *)this + 2 * i) = _mm_div_ps(*(__m128 *)&v17[i], v13); /*0x104899509*/
  return __stack_chk_guard; /*0x104899527*/
}

// Address: 0x10489aa4f | Name: __ZN3RBX17isRepresentableInEPKNS_8BasePartERKNS_15CoordinateFrameE
__int64 __fastcall RBX::isRepresentableIn(RBX *this, const RBX::BasePart *a2, const RBX::CoordinateFrame *a3)
{
  RBX::BasePartProp *v5; // r15
  RBX::Vector3 *v6; // rdx
  RBX::Matrix3 *v7; // rsi
  RBX::Matrix3 *v8; // rsi
  __m128 v10; // xmm0
  float v11; // xmm1_4
  __int64 v12; // r12
  __int64 v13; // rax
  __m128 v14; // xmm0
  float v15; // xmm1_4
  int v16; // eax
  __m128 v17; // xmm6
  float v18; // xmm0_4
  float v19; // xmm1_4
  __m128 v20; // xmm0
  __m128 v21; // xmm3
  __m128 v22; // xmm1
  __m128 v23; // xmm3
  __m128 v24; // xmm0
  __m128 v25; // xmm2
  __m128 v26; // xmm3
  _BYTE v27[48]; // [rsp+0h] [rbp-B0h] BYREF
  _BYTE v28[48]; // [rsp+30h] [rbp-80h] BYREF
  __m128 v29; // [rsp+60h] [rbp-50h]
  __m128 v30; // [rsp+70h] [rbp-40h]
  float v31; // [rsp+80h] [rbp-30h]
  float v32; // [rsp+84h] [rbp-2Ch]

  v5 = (RBX *)((char *)this + 184); /*0x10489aa69*/
  RBX::BasePartProp::getCoordinateFrame(this: (RBX::BasePartProp *)v27); /*0x10489aa7d*/
  RBX::CoordinateFrame::operatorMul_SIMD(this: (RBX::CoordinateFrame *)v28, a2); /*0x10489aa8f*/
  if ( (unsigned __int8)RBX::closestOrthogonalize(this: (RBX *)v28, a2: v7, a3: v6) != 0 ) /*0x10489aa9e*/
    goto LABEL_2; /*0x10489aa9e*/
  RBX::removeScaleComponent(this: (RBX *)v28, a2: v8); /*0x10489aaba*/
  v30 = v10; /*0x10489aabf*/
  v32 = v11; /*0x10489aac3*/
  v12 = *((_QWORD *)this + 3); /*0x10489aac8*/
  v13 = RBX::Reflection::Class_getDescriptorPtr<RBX::Part>(); /*0x10489aacc*/
  LOBYTE(a2) = 1; /*0x10489aad1*/
  if ( this != nullptr /*0x10489aaf3*/
    && *(unsigned __int16 *)(v12 + 440) - (unsigned int)*(unsigned __int16 *)(v13 + 440) <= *(unsigned __int16 *)(v13 + 442) )
  {
    RBX::BasePartProp::getVisualSize(this: v5); /*0x10489aaf8*/
    v29 = v14; /*0x10489aafd*/
    v31 = v15; /*0x10489ab01*/
    v16 = (*(__int64 (__fastcall **)(RBX *))(*(_QWORD *)this + 1296LL))(a1: this); /*0x10489ab0c*/
    if ( v16 == 2 ) /*0x10489ab15*/
    {
      v24 = _mm_movehdup_ps(v30); /*0x10489abe4*/
      if ( v24.f32[0] != v32 ) /*0x10489abf1*/
      {
        v25 = _mm_and_ps((__m128)xmmword_108F46760, v24); /*0x10489ac0a*/
        v25.f32[0] = v25.f32[0] + 1.0; /*0x10489ac0d*/
        v26 = _mm_cmple_ss((__m128)0x7F800000u, v25); /*0x10489ac25*/
        v25.f32[0] = v25.f32[0] * 0.0000099999997; /*0x10489ac2a*/
        if ( COERCE_FLOAT(v26.i32[0] & 0x3727C5AC | _mm_andnot_ps(v26, v25).u32[0]) < fabs(v24.f32[0] - v32) ) /*0x10489ac3d*/
LABEL_2:
          LODWORD(a2) = 0; /*0x10489aaa0*/
      }
    }
    else if ( v16 == 0 ) /*0x10489ab26*/
    {
      v17 = _mm_mul_ps(v30, v29); /*0x10489ab2c*/
      v18 = _mm_movehdup_ps(v17).f32[0]; /*0x10489ab30*/
      if ( v17.f32[0] != v18 ) /*0x10489ab37*/
      {
        v19 = fabs(v17.f32[0] - v18); /*0x10489ab49*/
        v20 = _mm_and_ps((__m128)xmmword_108F46760, v17); /*0x10489ab4c*/
        v20.f32[0] = v20.f32[0] + 1.0; /*0x10489ab4f*/
        v21 = _mm_cmple_ss((__m128)0x7F800000u, v20); /*0x10489ab67*/
        v20.f32[0] = v20.f32[0] * 0.0000099999997; /*0x10489ab6c*/
        if ( COERCE_FLOAT(v21.i32[0] & 0x3727C5AC | _mm_andnot_ps(v21, v20).u32[0]) < v19 ) /*0x10489ab7f*/
          goto LABEL_2; /*0x10489ab7f*/
      }
      if ( v17.f32[0] != (float)(v32 * v31) ) /*0x10489ab8d*/
      {
        v22 = _mm_and_ps((__m128)xmmword_108F46760, v17); /*0x10489aba6*/
        v22.f32[0] = v22.f32[0] + 1.0; /*0x10489aba9*/
        v23 = _mm_cmple_ss((__m128)0x7F800000u, v22); /*0x10489abc1*/
        v22.f32[0] = v22.f32[0] * 0.0000099999997; /*0x10489abc6*/
        if ( COERCE_FLOAT(v23.i32[0] & 0x3727C5AC | _mm_andnot_ps(v23, v22).u32[0]) < fabs(v17.f32[0] - (float)(v32 * v31)) ) /*0x10489abd9*/
          goto LABEL_2; /*0x10489abd9*/
      }
    }
  }
  return (unsigned int)a2; /*0x10489aaa4*/
}

// Address: 0x1048f9dfc | Name: __ZN3RBXL43isTeamCreateAttributeReplicationContextImplEPKNS_8InstanceE
char __fastcall RBX::isTeamCreateAttributeReplicationContextImpl(RBX *this, const RBX::Instance *a2)
{
  const RBX::Instance *v3; // rsi
  __int64 v4; // r15
  std::__shared_weak_count *v5; // r14
  _QWORD v7[6]; // [rsp-30h] [rbp-30h] BYREF

  if ( this == nullptr ) /*0x1048f9dff*/
    return 0; /*0x1048f9e7b*/
  v3 = (const RBX::Instance *)(*((_QWORD *)this + 11) & 0xFFFFFFFFFFFFFFF8LL); /*0x1048f9e15*/
  if ( v3 == nullptr ) /*0x1048f9e19*/
    return RBX::DataModel::isCloudEdit(this, a2: v3); /*0x1048f9e19*/
  RBX::EngineContext::getDataModel(this: (RBX::EngineContext *)v7); /*0x1048f9e22*/
  v4 = v7[0]; /*0x1048f9e27*/
  v5 = (std::__shared_weak_count *)v7[1]; /*0x1048f9e2a*/
  if ( v7[1] != 0 && _InterlockedExchangeAdd64((volatile signed __int64 *)(v7[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1048f9e43*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x1048f9e4b*/
    std::__shared_weak_count::__release_weak(this: v5); /*0x1048f9e51*/
  }
  if ( v4 != 0 ) /*0x1048f9e59*/
    return *(_DWORD *)(v4 + 2264) == 1; /*0x1048f9e63*/
  else
    return RBX::DataModel::isCloudEdit(this, a2: v3); /*0x1048f9e6b*/
}

// Address: 0x1048f9e7e | Name: __ZN3RBXL36isIsrAttributeReplicationEnabledImplEPKNS_8InstanceE
char __fastcall RBX::isIsrAttributeReplicationEnabledImpl(RBX *this, const RBX::Instance *a2)
{
  char result; // al
  __int64 v3; // [rsp+8h] [rbp-8h] BYREF

  RBX::AuroraUtils::getEngineNetConfigurationFromInstance(this: (RBX::AuroraUtils *)&v3, a2: this); /*0x1048f9e8d*/
  result = 1; /*0x1048f9e99*/
  if ( FFlag::DebugHashTableMetrics == 0 ) /*0x1048f9e9e*/
  {
    if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x1048f9eaa*/
    {
      if ( (v3 & 8) == 0 /*0x1048f9ed0*/
        && ((v3 & 1) == 0 && FFlag::NextGenReplicatorEnabledWrite == 0 || FFlag::DebugNextGenRepAttributeRep == 0) )
      {
        return (v3 & 2) != 0; /*0x1048f9ed7*/
      }
    }
    else if ( FFlag::NextGenReplicatorEnabledRead != 0 && FFlag::NextGenReplicatorEnabledWrite != 0 ) /*0x1048f9ef1*/
    {
      return FFlag::DebugNextGenRepAttributeRep; /*0x1048f9efa*/
    }
    else
    {
      return 0; /*0x1048f9efe*/
    }
  }
  return result; /*0x1048f9f00*/
}

// Address: 0x1048fa269 | Name: __ZN3RBXL27isPredictionModeVisibleImplEPKNS_8InstanceE
bool __fastcall RBX::isPredictionModeVisibleImpl(RBX *this, const RBX::Instance *a2)
{
  bool result; // al
  _BYTE v3[8]; // [rsp+8h] [rbp-8h] BYREF

  RBX::AuroraUtils::getEngineNetConfigurationFromInstance(this: (RBX::AuroraUtils *)v3, a2: this); /*0x1048fa278*/
  result = true; /*0x1048fa284*/
  if ( FFlag::DebugHashTableMetrics == 0 ) /*0x1048fa289*/
    return FFlag::SAuthWorkspaceFlagged == 1 && (v3[0] & 8) != 0; /*0x1048fa29c*/
  return result; /*0x1048fa2a3*/
}

// Address: 0x1049ce768 | Name: __ZN3RBX20isRobloxApprovedSiteERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
__int64 __fastcall RBX::isRobloxApprovedSite(__int64 a1)
{
  RBX::Http *v2; // rbx
  bool v3; // dl
  char isRobloxSite; // al
  void *v5; // rsi
  _BYTE v7[16]; // [rsp+0h] [rbp-90h] BYREF
  void *v8; // [rsp+10h] [rbp-80h]
  char v9; // [rsp+18h] [rbp-78h]
  void *v10; // [rsp+28h] [rbp-68h]
  char v11; // [rsp+30h] [rbp-60h]
  void *v12; // [rsp+40h] [rbp-50h]
  char v13; // [rsp+48h] [rbp-48h]
  void *v14; // [rsp+58h] [rbp-38h]
  char v15; // [rsp+60h] [rbp-30h]
  void *v16; // [rsp+70h] [rbp-20h]

  v2 = (RBX::Http *)(a1 + 1); /*0x1049ce77c*/
  RBX::Url::fromString(this: (RBX::Url *)v7); /*0x1049ce79b*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1049ce7a4*/
    v2 = *(RBX::Http **)(a1 + 16); /*0x1049ce7a6*/
  isRobloxSite = RBX::Http::isRobloxSite(this: v2, a2: nullptr, a3: v3); /*0x1049ce7af*/
  LOBYTE(v2) = 1; /*0x1049ce7b4*/
  if ( isRobloxSite == 0 /*0x1049ce7fd*/
    && ((unsigned __int8)RBX::Url::isSubdomainOf(this: (RBX::Url *)v7, a2: "www.youtube.com") == 0
     || (unsigned __int8)RBX::Url::pathEqualsCaseInsensitive(this: (RBX::Url *)v7, a2: "/watch") == 0)
    && (unsigned __int8)RBX::Url::isSubdomainOf(this: (RBX::Url *)v7, a2: "stripe.com") == 0 )
  {
    LODWORD(v2) = RBX::Url::isSubdomainOf(this: (RBX::Url *)v7, a2: "vnggames.com"); /*0x1049ce812*/
  }
  if ( (v15 & 1) != 0 ) /*0x1049ce818*/
    operator delete(a1: (RBX::Memory *)v16, a2: v5); /*0x1049ce81e*/
  if ( (v13 & 1) != 0 ) /*0x1049ce827*/
    operator delete(a1: (RBX::Memory *)v14, a2: v5); /*0x1049ce82d*/
  if ( (v11 & 1) != 0 ) /*0x1049ce836*/
    operator delete(a1: (RBX::Memory *)v12, a2: v5); /*0x1049ce83c*/
  if ( (v9 & 1) != 0 ) /*0x1049ce845*/
    operator delete(a1: (RBX::Memory *)v10, a2: v5); /*0x1049ce84b*/
  if ( (v7[0] & 1) != 0 ) /*0x1049ce857*/
    operator delete(a1: (RBX::Memory *)v8, a2: v5); /*0x1049ce85d*/
  return (unsigned int)v2; /*0x1049ce864*/
}

// Address: 0x1049f0941 | Name: __ZN3RBXL26invokeChatCallbackInternalENSt3__18weak_ptrINS_11ChatServiceEEENS_3Lua13WeakObjectRefENS0_10shared_ptrIKNS_10Reflection5TupleEEE
__int64 __fastcall RBX::invokeChatCallbackInternal(__int64 a1, RBX::ServiceProvider **a2, __int64 a3, _QWORD *a4)
{
  std::__shared_weak_count *v8; // rdi
  std::__shared_weak_count *v9; // rax
  RBX::ServiceProvider *v10; // r13
  const RBX::Instance *v11; // rsi
  volatile signed __int64 *v12; // r12
  RBX::ServiceProvider *ServiceProvider; // rax
  __int64 v14; // rax
  std::__shared_weak_count *v15; // r14
  volatile signed __int64 *v16; // r12
  std::__shared_weak_count *v18; // [rsp+10h] [rbp-50h]
  std::__shared_weak_count *v19; // [rsp+20h] [rbp-40h]
  __int64 v20; // [rsp+28h] [rbp-38h] BYREF
  std::__shared_weak_count *v21; // [rsp+30h] [rbp-30h]

  RBX::make_shared<RBX::Reflection::Tuple const>(); /*0x1049f095e*/
  v8 = a2[1]; /*0x1049f0963*/
  if ( v8 == nullptr ) /*0x1049f096a*/
    return a1; /*0x1049f096a*/
  v9 = (std::__shared_weak_count *)std::__shared_weak_count::lock(this: v8); /*0x1049f0970*/
  v18 = v9; /*0x1049f0975*/
  if ( v9 == nullptr ) /*0x1049f097c*/
    return a1; /*0x1049f097c*/
  v10 = *a2; /*0x1049f0982*/
  if ( v10 == nullptr ) /*0x1049f098d*/
  {
    v16 = (volatile signed __int64 *)v9; /*0x1049f0a5b*/
LABEL_18:
    if ( _InterlockedExchangeAdd64(v16 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1049f0a6f*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v16 + 16))(a1: v16); /*0x1049f0a78*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v16); /*0x1049f0a7e*/
    }
    return a1; /*0x1049f0a7e*/
  }
  RBX::Lua::WeakThreadRef::getLiveLuaRef(this: (RBX::Lua::WeakThreadRef *)&v20); /*0x1049f099a*/
  v12 = (volatile signed __int64 *)v21; /*0x1049f09a3*/
  v19 = v21; /*0x1049f09ab*/
  if ( v20 != 0 ) /*0x1049f09b2*/
  {
    if ( *(_QWORD *)(v20 + 40) != 0 ) /*0x1049f09b9*/
    {
      ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v10, a2: v11); /*0x1049f09be*/
      if ( ServiceProvider != nullptr ) /*0x1049f09c6*/
      {
        v14 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::ScriptContext>(this: ServiceProvider); /*0x1049f09cb*/
        if ( v14 != 0 ) /*0x1049f09d3*/
        {
          RBX::ScriptContext::callInNewThread(a1: &v20, a2: v14, a3, a4: *a4); /*0x1049f09e2*/
          std::shared_ptr<RBX::Reflection::Tuple const>::operator=[abi:ne200100](a1, a2: &v20); /*0x1049f09f1*/
          v15 = v21; /*0x1049f09f6*/
          if ( v21 != nullptr /*0x1049f0a0f*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v21 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x1049f0a17*/
            std::__shared_weak_count::__release_weak(this: v15); /*0x1049f0a1d*/
          }
        }
      }
    }
    v12 = (volatile signed __int64 *)v19; /*0x1049f0a22*/
  }
  if ( v12 != nullptr && _InterlockedExchangeAdd64(v12 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1049f0a3c*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v12 + 16))(a1: v12); /*0x1049f0a45*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v12); /*0x1049f0a4b*/
  }
  v16 = (volatile signed __int64 *)v18; /*0x1049f0a50*/
  if ( v18 != nullptr ) /*0x1049f0a57*/
    goto LABEL_18; /*0x1049f0a57*/
  return a1; /*0x1049f0a86*/
}

// Address: 0x104a193a6 | Name: __ZN3RBX26isCollectionSupportEnabledEv
char __fastcall RBX::isCollectionSupportEnabled(RBX *this)
{
  return FFlag::DebugEncodeTransitiveDependencies; /*0x104a193b0*/
}

// Address: 0x104a1e655 | Name: __ZN3RBXL14invokeCallbackERNS_3Lua13WeakObjectRefERNS0_13WeakThreadRefENS_9ArrayViewINS_10Reflection7VariantEEEb
double __fastcall RBX::invokeCallback(__int64 a1, __int64 a2, __int64 a3, __int64 a4, int a5)
{
  __int64 v10; // rdi
  double v11; // xmm0_8
  _BYTE v13[24]; // [rsp+0h] [rbp-50h] BYREF
  void **v14; // [rsp+18h] [rbp-38h] BYREF
  double v15; // [rsp+20h] [rbp-30h]

  v15 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1); /*0x104a1e67a*/
  if ( a5 != 0 ) /*0x104a1e682*/
  {
    RBX::ScriptContext::callCallback(a1, a2: a3, a3: a4, a4: a2, a5: 0); /*0x104a1e693*/
  }
  else
  {
    memset(v13, 0, sizeof(v13)); /*0x104a1e6a2*/
    ((void (__fastcall *)(__int64, __int64, __int64, __int64, _BYTE *, _QWORD))RBX::ScriptContext::callCallback)( /*0x104a1e6c3*/
      a1,
      a2: a3,
      a3: a4,
      a4: a2,
      a5: v13,
      a6: 0);
    v14 = (void **)v13; /*0x104a1e6cc*/
    std::vector<RBX::Reflection::Variant>::__destroy_vector::operator()[abi:ne200100](a1: &v14); /*0x104a1e6cf*/
  }
  v11 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v10); /*0x104a1e6d4*/
  return v11 - v15; /*0x104a1e6de*/
}

// Address: 0x104b07d97 | Name: __ZN3RBX27intersectRayPartialCylinderENS_7Vector3ES0_fff
unsigned __int64 __fastcall RBX::intersectRayPartialCylinder(
        __int64 a1,
        __int64 a2,
        const RBX::Vector3 *a3,
        __m128 a4,
        __m128 a5,
        __m128 a6,
        float a7,
        float a8,
        float a9,
        float a10)
{
  float v12; // xmm0_4
  float v13; // xmm10_4
  __m128i v14; // xmm9
  float v15; // xmm1_4
  __m128 v16; // xmm11
  float v17; // xmm0_4
  __m128i v18; // xmm4
  float v19; // xmm5_4
  __m128 v20; // xmm0
  const mach_header_64 *v21; // rbx
  float v22; // xmm0_4
  __m128 v23; // xmm0
  __m128 v25; // [rsp+10h] [rbp-50h]
  float v26; // [rsp+40h] [rbp-20h]
  __int32 v27; // [rsp+44h] [rbp-1Ch]
  float v28; // [rsp+48h] [rbp-18h]
  unsigned __int32 v29; // [rsp+50h] [rbp-10h]
  float v30; // [rsp+54h] [rbp-Ch]

  v12 = _mm_movehdup_ps(a6).f32[0]; /*0x104b07da7*/
  v13 = (float)(a7 * a7) + (float)(v12 * v12); /*0x104b07dbb*/
  v14 = 0; /*0x104b07dc0*/
  if ( v13 == 0.0 ) /*0x104b07dc8*/
    goto LABEL_12; /*0x104b07dc8*/
  v15 = _mm_movehdup_ps(a4).f32[0]; /*0x104b07dd0*/
  v16 = a5; /*0x104b07dd9*/
  v16.f32[0] = (float)(a5.f32[0] * a7) + (float)(v12 * v15); /*0x104b07de2*/
  v17 = (float)(v16.f32[0] * v16.f32[0]) /*0x104b07e10*/
      - (float)((float)((float)((float)(a5.f32[0] * a5.f32[0]) + (float)(v15 * v15)) - (float)(a8 * a8)) * v13);
  v14 = 0; /*0x104b07e15*/
  if ( v17 < 0.0 ) /*0x104b07e1d*/
    goto LABEL_12; /*0x104b07e1d*/
  v14 = (__m128i)_mm_xor_ps(*(__m128 *)&xmmword_108F246C0, v16); /*0x104b07e2b*/
  v18 = 0; /*0x104b07e2f*/
  *(float *)v18.i32 = fsqrt(v17); /*0x104b07e32*/
  *(float *)v14.i32 = (float)(*(float *)v14.i32 - *(float *)v18.i32) / v13; /*0x104b07e3b*/
  v19 = a9 * 0.5; /*0x104b07e48*/
  if ( *(float *)v14.i32 <= 0.0 ) /*0x104b07e50*/
    goto LABEL_10; /*0x104b07e50*/
  v20 = _mm_add_ps(_mm_mul_ps(_mm_moveldup_ps((__m128)v14), a6), a4); /*0x104b07e5e*/
  if ( v19 < fabs(v20.f32[0]) ) /*0x104b07e6f*/
    goto LABEL_10; /*0x104b07e6f*/
  v21 = &_mh_execute_header; /*0x104b07e75*/
  if ( a10 < 360.0 ) /*0x104b07e86*/
  {
    v30 = a10; /*0x104b07e98*/
    v26 = a7; /*0x104b07e9d*/
    v27 = a5.i32[0]; /*0x104b07ea7*/
    v28 = v19; /*0x104b07eac*/
    v25 = a6; /*0x104b07eb6*/
    v29 = v18.i32[0]; /*0x104b07ec5*/
    v22 = RBX::get2dCCWAngle(a1: v20, a2: (float)(*(float *)v14.i32 * a7) + a5.f32[0], a3: a1, a4: a2, a5: a3).f32[0]; /*0x104b07eca*/
    v18 = (__m128i)v29; /*0x104b07ed3*/
    a6 = v25; /*0x104b07ee3*/
    v19 = v28; /*0x104b07eec*/
    a5.i32[0] = v27; /*0x104b07ef1*/
    a7 = v26; /*0x104b07efb*/
    a10 = v30; /*0x104b07f00*/
    if ( v30 < v22 ) /*0x104b07f08*/
    {
LABEL_10:
      *(float *)v18.i32 = *(float *)v18.i32 - v16.f32[0]; /*0x104b07f0a*/
      v14 = v18; /*0x104b07f0f*/
      *(float *)v14.i32 = *(float *)v18.i32 / v13; /*0x104b07f13*/
      if ( (float)(*(float *)v18.i32 / v13) <= 0.0 /*0x104b07f74*/
        || (v23 = _mm_add_ps(_mm_mul_ps(_mm_moveldup_ps((__m128)v14), a6), a4), v19 < fabs(v23.f32[0]))
        || (v21 = &_mh_execute_header, a10 < 360.0)
        && a10 < RBX::get2dCCWAngle(a1: v23, a2: (float)(a7 * *(float *)v14.i32) + a5.f32[0], a3: a1, a4: a2, a5: a3).f32[0] )
      {
        v14 = 0; /*0x104b07f76*/
LABEL_12:
        v21 = nullptr; /*0x104b07f7a*/
      }
    }
  }
  return (unsigned __int64)v21 | (unsigned int)_mm_cvtsi128_si32(v14); /*0x104b07f84*/
}

// Address: 0x104b08de1 | Name: __ZN3RBX16insideOfCylinderENS_7Vector3Effff
char __fastcall RBX::insideOfCylinder(
        __int64 a1,
        __int64 a2,
        const RBX::Vector3 *a3,
        __m128 a4,
        float a5,
        float a6,
        float a7,
        float a8,
        __m128 a9)
{
  char v9; // al
  float v10; // xmm3_4

  v9 = 0; /*0x104b08df3*/
  if ( fabs(a4.f32[0]) <= (float)(a7 * 0.5) ) /*0x104b08df8*/
  {
    v10 = fsqrt((float)(a5 * a5) + _mm_movehdup_ps(_mm_mul_ps(a4, a4)).f32[0]); /*0x104b08e12*/
    if ( v10 <= a6 && a8 <= v10 ) /*0x104b08e1e*/
      v9 = _mm_cvtsi128_si32((__m128i)_mm_or_ps( /*0x104b08e4b*/
                                        _mm_cmpnlt_ps(a9, RBX::get2dCCWAngle(a1: a4, a2: a5, a3: a1, a4: a2, a5: a3)),
                                        _mm_cmpnlt_ps(a9, (__m128)0x43B40000u)));
  }
  return v9 & 1; /*0x104b08e56*/
}

// Address: 0x104b2d70e | Name: __ZN3RBX24isStreamedOutOnOurClientERKNS_8InstanceE
char __fastcall RBX::isStreamedOutOnOurClient(RBX *this, const RBX::Instance *a2)
{
  char v3; // al

  do /*0x104b2d730*/
  {
    RBX::assertNotServerLaunchIntent(this, a2); /*0x104b2d71a*/
    v3 = *((_BYTE *)this + 168); /*0x104b2d71f*/
    if ( (v3 & 1) != 0 ) /*0x104b2d727*/
      break; /*0x104b2d727*/
    this = *((RBX **)this + 13); /*0x104b2d729*/
  }
  while ( this != nullptr ); /*0x104b2d730*/
  return v3 & 1; /*0x104b2d738*/
}

// Address: 0x104b53f49 | Name: __ZN3RBXL26isNewMaterialVariantBetterEPKNS_5WorldEPKNS_15MaterialVariantES5_
char __fastcall RBX::isNewMaterialVariantBetter(
        RBX *this,
        const RBX::World *a2,
        const RBX::MaterialVariant *a3,
        const RBX::MaterialVariant *a4)
{
  int v4; // eax

  LOBYTE(v4) = 1; /*0x104b53f56*/
  if ( a3 == nullptr || a2 != nullptr ) /*0x104b53f4c*/
  {
    if ( a3 == nullptr || this == nullptr || a2 == nullptr ) /*0x104b53f6c*/
      LOBYTE(v4) = 0; /*0x104b53f8e*/
    else
      return (unsigned int)RBX::World::compareGuids( /*0x104b53f89*/
                             this,
                             a2: (const RBX::World *)((char *)a2 + 48),
                             a3: (const RBX::MaterialVariant *)((char *)a3 + 48)) >> 31;
  }
  return v4; /*0x104b53f8d*/
}

// Address: 0x104b91fab | Name: __ZN3RBXL19isEnabledUniverseIdEx
char __fastcall RBX::isEnabledUniverseId(RBX *this)
{
  void *v2; // rcx
  __int64 v3; // rax
  unsigned __int64 v5; // rax
  unsigned __int128 v6; // rdi
  unsigned __int64 v7; // rax
  bool v8; // cf
  bool v9; // zf
  bool v10; // cl
  unsigned __int64 v11; // rax
  unsigned __int64 v12; // rax
  unsigned __int64 v13; // rdx
  unsigned __int64 v14; // rcx
  unsigned __int128 v15; // [rsp-58h] [rbp-58h] BYREF
  unsigned __int128 v16; // [rsp-48h] [rbp-48h]
  unsigned __int128 v17; // [rsp-38h] [rbp-38h] BYREF
  char v18; // [rsp-21h] [rbp-21h] BYREF

  if ( this == nullptr ) /*0x104b91fae*/
    return 1; /*0x104b91fdb*/
  if ( (DFString::ModerationServiceEnabledUniverseIds & 1) != 0 ) /*0x104b91fc9*/
  {
    v2 = (void *)qword_10D7CF638; /*0x104b91fcb*/
    v3 = qword_10D7CF630; /*0x104b91fd2*/
  }
  else
  {
    v3 = (unsigned __int8)DFString::ModerationServiceEnabledUniverseIds >> 1; /*0x104b91fde*/
    v2 = &unk_10D7CF629; /*0x104b91fe0*/
  }
  *(_QWORD *)&v15 = v2; /*0x104b91feb*/
  *((_QWORD *)&v15 + 1) = v3; /*0x104b91fee*/
  v18 = 44; /*0x104b91ff6*/
  v5 = RBX::detail::StringViewBase::find(a1: &v15, a2: &v18, a3: 1, a4: 0); /*0x104b92000*/
  if ( v5 == -1 ) /*0x104b92009*/
  {
    v16 = v15; /*0x104b92047*/
    v17 = 0; /*0x104b9204e*/
    v10 = false; /*0x104b92052*/
    *((_QWORD *)&v6 + 1) = *((_QWORD *)&v15 + 1); /*0x104b92054*/
  }
  else
  {
    *((_QWORD *)&v6 + 1) = v5; /*0x104b92016*/
    if ( *((_QWORD *)&v15 + 1) < v5 ) /*0x104b92019*/
      *((_QWORD *)&v6 + 1) = *((_QWORD *)&v15 + 1); /*0x104b92019*/
    v7 = v5 + 1; /*0x104b9201d*/
    v8 = *((_QWORD *)&v15 + 1) < v7; /*0x104b92020*/
    v9 = *((_QWORD *)&v15 + 1) == v7; /*0x104b92020*/
    if ( *((_QWORD *)&v15 + 1) < v7 ) /*0x104b92023*/
      v7 = *((_QWORD *)&v15 + 1); /*0x104b92023*/
    v10 = !v8 && !v9; /*0x104b92027*/
    *(_QWORD *)&v16 = v15; /*0x104b92031*/
    *((_QWORD *)&v16 + 1) = *((_QWORD *)&v6 + 1); /*0x104b92035*/
    *(_QWORD *)&v17 = v15 + v7; /*0x104b92039*/
    *((_QWORD *)&v17 + 1) = *((_QWORD *)&v15 + 1) - v7; /*0x104b9203d*/
  }
  if ( !v10 && *((_QWORD *)&v6 + 1) == 0 ) /*0x104b92060*/
    return 0; /*0x104b920ed*/
  *(_QWORD *)&v6 = v16; /*0x104b9206c*/
  while ( RBX::getAsSignedInteger(a1: v6, a2: *((__int64 *)&v6 + 1), a3: 0xAu, a4: &v15) == 0 || (RBX *)v15 != this ) /*0x104b92089*/
  {
    LOBYTE(v15) = 44; /*0x104b9208b*/
    v11 = RBX::detail::StringViewBase::find(a1: &v17, a2: &v15, a3: 1, a4: 0); /*0x104b9209c*/
    if ( v11 == -1 ) /*0x104b920a5*/
    {
      v6 = v17; /*0x104b920cc*/
      v13 = 0; /*0x104b920d4*/
      v14 = 0; /*0x104b920d6*/
    }
    else
    {
      *(_QWORD *)&v6 = v17; /*0x104b920a7*/
      *((_QWORD *)&v6 + 1) = v11; /*0x104b920b2*/
      if ( *((_QWORD *)&v17 + 1) < v11 ) /*0x104b920b5*/
        *((_QWORD *)&v6 + 1) = *((_QWORD *)&v17 + 1); /*0x104b920b5*/
      v12 = v11 + 1; /*0x104b920b9*/
      if ( *((_QWORD *)&v17 + 1) < v12 ) /*0x104b920bf*/
        v12 = *((_QWORD *)&v17 + 1); /*0x104b920bf*/
      v13 = v17 + v12; /*0x104b920c3*/
      v14 = *((_QWORD *)&v17 + 1) - v12; /*0x104b920c7*/
    }
    v16 = v6; /*0x104b920d8*/
    v17 = __PAIR128__(v14, v13); /*0x104b920e0*/
    if ( (*((_QWORD *)&v6 + 1) | v14) == 0 ) /*0x104b920eb*/
      return 0; /*0x104b920eb*/
  }
  return 1; /*0x104b91fdd*/
}

// Address: 0x104bdcbd9 | Name: __ZN3RBX13isInTheFutureERKNSt3__110shared_ptrINS_15ProceduralModelEEENS0_8optionalIiEE
__int64 __fastcall RBX::isInTheFuture(_QWORD *a1, __int64 a2)
{
  int v2; // ebx
  RBX::ChangeHistoryService *v3; // rax

  if ( (a2 & 0x100000000LL) != 0 /*0x104bdcbf4*/
    && (v2 = a2,
        (v3 = (RBX::ChangeHistoryService *)RBX::ServiceProvider::find<RBX::ChangeHistoryService>(a1: *a1)) != nullptr) )
  {
    return RBX::ChangeHistoryService::isInTheFuture(this: v3, a2: v2); /*0x104bdcc01*/
  }
  else
  {
    return 0; /*0x104bdcc06*/
  }
}

// Address: 0x104bde47d | Name: __ZN3RBX18isBuiltInAttributeERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
bool __fastcall RBX::isBuiltInAttribute(__int64 a1)
{
  _BYTE *v1; // rdi

  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x104bde481*/
  {
    if ( *(_QWORD *)(a1 + 8) != 0 ) /*0x104bde491*/
    {
      v1 = *(_BYTE **)(a1 + 16); /*0x104bde493*/
      return *v1 == 36; /*0x104bde493*/
    }
  }
  else if ( *(_BYTE *)a1 != 0 ) /*0x104bde485*/
  {
    v1 = (_BYTE *)(a1 + 1); /*0x104bde487*/
    return *v1 == 36; /*0x104bde4a2*/
  }
  return false; /*0x104bde4a2*/
}

// Address: 0x104c2da40 | Name: __ZN3RBXL26initSlimLegacyContentTableEv
void __fastcall RBX::initSlimLegacyContentTable(RBX *this, unsigned __int64 a2)
{
  RBX::LegacyContentTable *v2; // r14
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // rsi
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // rdx
  __int64 v9; // rcx
  void *v10; // rsi
  __int64 v11; // rbx
  __int64 v12; // rdx
  __int64 v13; // rcx
  __int64 v14; // rdx
  __int64 v15; // rcx
  void *v16; // rsi
  __int64 v17; // rbx
  __int64 v18; // rdx
  __int64 v19; // rcx
  __int64 v20; // rdx
  __int64 v21; // rcx
  void *v22; // rsi
  __int64 v23; // rbx
  __int64 v24; // rdx
  __int64 v25; // rcx
  __int64 v26; // rdx
  __int64 v27; // rcx
  void *v28; // rsi
  __int64 v29; // rbx
  __int64 v30; // rdx
  __int64 v31; // rcx
  __int64 v32; // rdx
  __int64 v33; // rcx
  void *v34; // rsi
  __int64 v35; // rbx
  __int64 v36; // rdx
  __int64 v37; // rcx
  __int64 v38; // rdx
  __int64 v39; // rcx
  void *v40; // rsi
  __int64 v41; // rbx
  __int64 v42; // rdx
  __int64 v43; // rcx
  __int64 v44; // rdx
  __int64 v45; // rcx
  void *v46; // rsi
  __int64 v47; // rbx
  __int64 v48; // rdx
  __int64 v49; // rcx
  __int64 v50; // rdx
  __int64 v51; // rcx
  void *v52; // rsi
  __int64 v53; // rbx
  __int64 v54; // rdx
  __int64 v55; // rcx
  __int64 v56; // rdx
  __int64 v57; // rcx
  void *v58; // rsi
  __int64 v59; // rbx
  __int64 v60; // rdx
  __int64 v61; // rcx
  __int64 v62; // rdx
  __int64 v63; // rcx
  void *v64; // rsi
  __int64 v65; // rbx
  __int64 v66; // rdx
  __int64 v67; // rcx
  __int64 v68; // rdx
  __int64 v69; // rcx
  void *v70; // rsi
  __int64 v71; // rbx
  __int64 v72; // rdx
  __int64 v73; // rcx
  __int64 v74; // rdx
  __int64 v75; // rcx
  void *v76; // rsi
  __int64 v77; // rbx
  __int64 v78; // rdx
  __int64 v79; // rcx
  __int64 v80; // rdx
  __int64 v81; // rcx
  void *v82; // rsi
  __int64 v83; // rbx
  __int64 v84; // rdx
  __int64 v85; // rcx
  __int64 v86; // rdx
  __int64 v87; // rcx
  void *v88; // rsi
  __int64 v89; // rbx
  __int64 v90; // rdx
  __int64 v91; // rcx
  __int64 v92; // rdx
  __int64 v93; // rcx
  void *v94; // rsi
  __int64 v95; // rbx
  __int64 v96; // rdx
  __int64 v97; // rcx
  __int64 v98; // rdx
  __int64 v99; // rcx
  void *v100; // rsi
  __int64 v101; // rbx
  __int64 v102; // rdx
  __int64 v103; // rcx
  __int64 v104; // rdx
  __int64 v105; // rcx
  void *v106; // rsi
  __int64 v107; // rbx
  __int64 v108; // rdx
  __int64 v109; // rcx
  __int64 v110; // rdx
  __int64 v111; // rcx
  void *v112; // rsi
  __int64 v113; // rbx
  __int64 v114; // rdx
  __int64 v115; // rcx
  __int64 v116; // rdx
  __int64 v117; // rcx
  void *v118; // rsi
  __int64 v119; // rbx
  __int64 v120; // rdx
  __int64 v121; // rcx
  __int64 v122; // rdx
  __int64 v123; // rcx
  void *v124; // rsi
  __int64 v125; // rbx
  __int64 v126; // rdx
  __int64 v127; // rcx
  __int64 v128; // rdx
  __int64 v129; // rcx
  void *v130; // rsi
  __int64 v131; // rbx
  __int64 v132; // rdx
  __int64 v133; // rcx
  void *v134; // rsi
  _BYTE v135[16]; // [rsp+0h] [rbp-40h] BYREF
  void *v136; // [rsp+10h] [rbp-30h]
  unsigned __int8 v137[16]; // [rsp+18h] [rbp-28h] BYREF
  void *v138; // [rsp+28h] [rbp-18h]

  v2 = (RBX::LegacyContentTable *)operator new(a1: (RBX::Memory *)0x48, a2); /*0x104c2da55*/
  RBX::LegacyContentTable::LegacyContentTable(this: v2); /*0x104c2da5b*/
  v5 = RBX::slimLegacyContent; /*0x104c2da60*/
  RBX::slimLegacyContent = (__int64)v2; /*0x104c2da67*/
  if ( v5 != 0 ) /*0x104c2da71*/
  {
    std::default_delete<RBX::LegacyContentTable>::operator()[abi:ne200100](a1: &RBX::slimLegacyContent); /*0x104c2da7a*/
    v2 = (RBX::LegacyContentTable *)RBX::slimLegacyContent; /*0x104c2da7f*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "torso", a3: v3, a4: v4); /*0x104c2da91*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "12221758", a3: v6, a4: v7); /*0x104c2daa1*/
  RBX::addLegacyBodyEntry(a1: (__int64)v2, a2: (__int64)v135, a3: v137); /*0x104c2dab1*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2daba*/
    operator delete(a1: (RBX::Memory *)v138, a2: v10); /*0x104c2dac0*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2dac9*/
    operator delete(a1: (RBX::Memory *)v136, a2: v10); /*0x104c2dacf*/
  v11 = RBX::slimLegacyContent; /*0x104c2dad4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "rightleg", a3: v8, a4: v9); /*0x104c2dae6*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "12221626", a3: v12, a4: v13); /*0x104c2daf6*/
  RBX::addLegacyBodyEntry(a1: v11, a2: (__int64)v135, a3: v137); /*0x104c2db06*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2db0f*/
    operator delete(a1: (RBX::Memory *)v138, a2: v16); /*0x104c2db15*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2db1e*/
    operator delete(a1: (RBX::Memory *)v136, a2: v16); /*0x104c2db24*/
  v17 = RBX::slimLegacyContent; /*0x104c2db29*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "rightarm", a3: v14, a4: v15); /*0x104c2db3b*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "12221614", a3: v18, a4: v19); /*0x104c2db4b*/
  RBX::addLegacyBodyEntry(a1: v17, a2: (__int64)v135, a3: v137); /*0x104c2db5b*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2db64*/
    operator delete(a1: (RBX::Memory *)v138, a2: v22); /*0x104c2db6a*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2db73*/
    operator delete(a1: (RBX::Memory *)v136, a2: v22); /*0x104c2db79*/
  v23 = RBX::slimLegacyContent; /*0x104c2db7e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "leftleg", a3: v20, a4: v21); /*0x104c2db90*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "12221512", a3: v24, a4: v25); /*0x104c2dba0*/
  RBX::addLegacyBodyEntry(a1: v23, a2: (__int64)v135, a3: v137); /*0x104c2dbb0*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2dbb9*/
    operator delete(a1: (RBX::Memory *)v138, a2: v28); /*0x104c2dbbf*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2dbc8*/
    operator delete(a1: (RBX::Memory *)v136, a2: v28); /*0x104c2dbce*/
  v29 = RBX::slimLegacyContent; /*0x104c2dbd3*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "leftarm", a3: v26, a4: v27); /*0x104c2dbe5*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "12221505", a3: v30, a4: v31); /*0x104c2dbf5*/
  RBX::addLegacyBodyEntry(a1: v29, a2: (__int64)v135, a3: v137); /*0x104c2dc05*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2dc0e*/
    operator delete(a1: (RBX::Memory *)v138, a2: v34); /*0x104c2dc14*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2dc1d*/
    operator delete(a1: (RBX::Memory *)v136, a2: v34); /*0x104c2dc23*/
  v35 = RBX::slimLegacyContent; /*0x104c2dc28*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "", a3: v32, a4: v33); /*0x104c2dc3a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "12221462", a3: v36, a4: v37); /*0x104c2dc4a*/
  RBX::addLegacyHeadEntry(a1: v35, a2: (__int64)v135, a3: v137); /*0x104c2dc5a*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2dc63*/
    operator delete(a1: (RBX::Memory *)v138, a2: v40); /*0x104c2dc69*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2dc72*/
    operator delete(a1: (RBX::Memory *)v136, a2: v40); /*0x104c2dc78*/
  v41 = RBX::slimLegacyContent; /*0x104c2dc7d*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "A", a3: v38, a4: v39); /*0x104c2dc8f*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988430467", a3: v42, a4: v43); /*0x104c2dc9f*/
  RBX::addLegacyHeadEntry(a1: v41, a2: (__int64)v135, a3: v137); /*0x104c2dcaf*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2dcb8*/
    operator delete(a1: (RBX::Memory *)v138, a2: v46); /*0x104c2dcbe*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2dcc7*/
    operator delete(a1: (RBX::Memory *)v136, a2: v46); /*0x104c2dccd*/
  v47 = RBX::slimLegacyContent; /*0x104c2dcd2*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "B", a3: v44, a4: v45); /*0x104c2dce4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988432660", a3: v48, a4: v49); /*0x104c2dcf4*/
  RBX::addLegacyHeadEntry(a1: v47, a2: (__int64)v135, a3: v137); /*0x104c2dd04*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2dd0d*/
    operator delete(a1: (RBX::Memory *)v138, a2: v52); /*0x104c2dd13*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2dd1c*/
    operator delete(a1: (RBX::Memory *)v136, a2: v52); /*0x104c2dd22*/
  v53 = RBX::slimLegacyContent; /*0x104c2dd27*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "C", a3: v50, a4: v51); /*0x104c2dd39*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988432929", a3: v54, a4: v55); /*0x104c2dd49*/
  RBX::addLegacyHeadEntry(a1: v53, a2: (__int64)v135, a3: v137); /*0x104c2dd59*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2dd62*/
    operator delete(a1: (RBX::Memory *)v138, a2: v58); /*0x104c2dd68*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2dd71*/
    operator delete(a1: (RBX::Memory *)v136, a2: v58); /*0x104c2dd77*/
  v59 = RBX::slimLegacyContent; /*0x104c2dd7c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "D", a3: v56, a4: v57); /*0x104c2dd8e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988433196", a3: v60, a4: v61); /*0x104c2dd9e*/
  RBX::addLegacyHeadEntry(a1: v59, a2: (__int64)v135, a3: v137); /*0x104c2ddae*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2ddb7*/
    operator delete(a1: (RBX::Memory *)v138, a2: v64); /*0x104c2ddbd*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2ddc6*/
    operator delete(a1: (RBX::Memory *)v136, a2: v64); /*0x104c2ddcc*/
  v65 = RBX::slimLegacyContent; /*0x104c2ddd1*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "E", a3: v62, a4: v63); /*0x104c2dde3*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988433541", a3: v66, a4: v67); /*0x104c2ddf3*/
  RBX::addLegacyHeadEntry(a1: v65, a2: (__int64)v135, a3: v137); /*0x104c2de03*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2de0c*/
    operator delete(a1: (RBX::Memory *)v138, a2: v70); /*0x104c2de12*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2de1b*/
    operator delete(a1: (RBX::Memory *)v136, a2: v70); /*0x104c2de21*/
  v71 = RBX::slimLegacyContent; /*0x104c2de26*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "F", a3: v68, a4: v69); /*0x104c2de38*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988433773", a3: v72, a4: v73); /*0x104c2de48*/
  RBX::addLegacyHeadEntry(a1: v71, a2: (__int64)v135, a3: v137); /*0x104c2de58*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2de61*/
    operator delete(a1: (RBX::Memory *)v138, a2: v76); /*0x104c2de67*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2de70*/
    operator delete(a1: (RBX::Memory *)v136, a2: v76); /*0x104c2de76*/
  v77 = RBX::slimLegacyContent; /*0x104c2de7b*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "G", a3: v74, a4: v75); /*0x104c2de8d*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988434786", a3: v78, a4: v79); /*0x104c2de9d*/
  RBX::addLegacyHeadEntry(a1: v77, a2: (__int64)v135, a3: v137); /*0x104c2dead*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2deb6*/
    operator delete(a1: (RBX::Memory *)v138, a2: v82); /*0x104c2debc*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2dec5*/
    operator delete(a1: (RBX::Memory *)v136, a2: v82); /*0x104c2decb*/
  v83 = RBX::slimLegacyContent; /*0x104c2ded0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "H", a3: v80, a4: v81); /*0x104c2dee2*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988435245", a3: v84, a4: v85); /*0x104c2def2*/
  RBX::addLegacyHeadEntry(a1: v83, a2: (__int64)v135, a3: v137); /*0x104c2df02*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2df0b*/
    operator delete(a1: (RBX::Memory *)v138, a2: v88); /*0x104c2df11*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2df1a*/
    operator delete(a1: (RBX::Memory *)v136, a2: v88); /*0x104c2df20*/
  v89 = RBX::slimLegacyContent; /*0x104c2df25*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "I", a3: v86, a4: v87); /*0x104c2df37*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988435523", a3: v90, a4: v91); /*0x104c2df47*/
  RBX::addLegacyHeadEntry(a1: v89, a2: (__int64)v135, a3: v137); /*0x104c2df57*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2df60*/
    operator delete(a1: (RBX::Memory *)v138, a2: v94); /*0x104c2df66*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2df6f*/
    operator delete(a1: (RBX::Memory *)v136, a2: v94); /*0x104c2df75*/
  v95 = RBX::slimLegacyContent; /*0x104c2df7a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "J", a3: v92, a4: v93); /*0x104c2df8c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988435845", a3: v96, a4: v97); /*0x104c2df9c*/
  RBX::addLegacyHeadEntry(a1: v95, a2: (__int64)v135, a3: v137); /*0x104c2dfac*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2dfb5*/
    operator delete(a1: (RBX::Memory *)v138, a2: v100); /*0x104c2dfbb*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2dfc4*/
    operator delete(a1: (RBX::Memory *)v136, a2: v100); /*0x104c2dfca*/
  v101 = RBX::slimLegacyContent; /*0x104c2dfcf*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "K", a3: v98, a4: v99); /*0x104c2dfe1*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988436995", a3: v102, a4: v103); /*0x104c2dff1*/
  RBX::addLegacyHeadEntry(a1: v101, a2: (__int64)v135, a3: v137); /*0x104c2e001*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2e00a*/
    operator delete(a1: (RBX::Memory *)v138, a2: v106); /*0x104c2e010*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2e019*/
    operator delete(a1: (RBX::Memory *)v136, a2: v106); /*0x104c2e01f*/
  v107 = RBX::slimLegacyContent; /*0x104c2e024*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "L", a3: v104, a4: v105); /*0x104c2e036*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988437215", a3: v108, a4: v109); /*0x104c2e046*/
  RBX::addLegacyHeadEntry(a1: v107, a2: (__int64)v135, a3: v137); /*0x104c2e056*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2e05f*/
    operator delete(a1: (RBX::Memory *)v138, a2: v112); /*0x104c2e065*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2e06e*/
    operator delete(a1: (RBX::Memory *)v136, a2: v112); /*0x104c2e074*/
  v113 = RBX::slimLegacyContent; /*0x104c2e079*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "M", a3: v110, a4: v111); /*0x104c2e08b*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988437563", a3: v114, a4: v115); /*0x104c2e09b*/
  RBX::addLegacyHeadEntry(a1: v113, a2: (__int64)v135, a3: v137); /*0x104c2e0ab*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2e0b4*/
    operator delete(a1: (RBX::Memory *)v138, a2: v118); /*0x104c2e0ba*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2e0c3*/
    operator delete(a1: (RBX::Memory *)v136, a2: v118); /*0x104c2e0c9*/
  v119 = RBX::slimLegacyContent; /*0x104c2e0ce*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "N", a3: v116, a4: v117); /*0x104c2e0e0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988438336", a3: v120, a4: v121); /*0x104c2e0f0*/
  RBX::addLegacyHeadEntry(a1: v119, a2: (__int64)v135, a3: v137); /*0x104c2e100*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2e109*/
    operator delete(a1: (RBX::Memory *)v138, a2: v124); /*0x104c2e10f*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2e118*/
    operator delete(a1: (RBX::Memory *)v136, a2: v124); /*0x104c2e11e*/
  v125 = RBX::slimLegacyContent; /*0x104c2e123*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "O", a3: v122, a4: v123); /*0x104c2e135*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988438902", a3: v126, a4: v127); /*0x104c2e145*/
  RBX::addLegacyHeadEntry(a1: v125, a2: (__int64)v135, a3: v137); /*0x104c2e155*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2e15e*/
    operator delete(a1: (RBX::Memory *)v138, a2: v130); /*0x104c2e164*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2e16d*/
    operator delete(a1: (RBX::Memory *)v136, a2: v130); /*0x104c2e173*/
  v131 = RBX::slimLegacyContent; /*0x104c2e178*/
  std::string::basic_string[abi:ne200100]<0>(a1: v135, a2: "P", a3: v128, a4: v129); /*0x104c2e18a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "988439143", a3: v132, a4: v133); /*0x104c2e19a*/
  RBX::addLegacyHeadEntry(a1: v131, a2: (__int64)v135, a3: v137); /*0x104c2e1aa*/
  if ( (v137[0] & 1) != 0 ) /*0x104c2e1b3*/
    operator delete(a1: (RBX::Memory *)v138, a2: v134); /*0x104c2e1b9*/
  if ( (v135[0] & 1) != 0 ) /*0x104c2e1c2*/
    operator delete(a1: (RBX::Memory *)v136, a2: v134); /*0x104c2e1c8*/
}

// Address: 0x104c2e710 | Name: __ZN3RBX22isValidMaterialVariantERKNSt3__110shared_ptrIKNS_8InstanceEEENS_12MaterialTypeERKNS0_12basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
char __fastcall RBX::isValidMaterialVariant(_QWORD *a1, unsigned int a2, __int64 a3)
{
  __int64 v5; // rax
  __int64 PartMaterialVariant; // rcx
  char result; // al

  v5 = RBX::ServiceProvider::find<RBX::MaterialService>(a1: *a1); /*0x104c2e720*/
  if ( v5 == 0 ) /*0x104c2e728*/
    return 0; /*0x104c2e728*/
  PartMaterialVariant = RBX::MaterialService::getPartMaterialVariant(a1: v5, a2, a3); /*0x104c2e738*/
  result = 1; /*0x104c2e73b*/
  if ( PartMaterialVariant == 0 ) /*0x104c2e740*/
    return 0; /*0x104c2e742*/
  return result; /*0x104c2e744*/
}

// Address: 0x104c32a3c | Name: __ZN3RBXL34isDecalHandledByTextureCompositingEPKNS_5DecalEPKNS_8BasePartERKNS_11AddPartDataE
__int64 __fastcall RBX::isDecalHandledByTextureCompositing(__int64 a1, const RBX::BasePart *a2, __int64 a3)
{
  void *v5; // rsi
  _BYTE v7[8]; // [rsp+0h] [rbp-180h] BYREF
  std::__shared_weak_count *v8; // [rsp+8h] [rbp-178h]
  void *v9; // [rsp+88h] [rbp-F8h]
  void *v10; // [rsp+90h] [rbp-F0h]
  char v11; // [rsp+A8h] [rbp-D8h]
  void *v12; // [rsp+B8h] [rbp-C8h]
  char v13; // [rsp+D8h] [rbp-A8h]
  void *v14; // [rsp+E8h] [rbp-98h]
  char v15; // [rsp+108h] [rbp-78h]
  void *v16; // [rsp+118h] [rbp-68h]
  __int64 v17; // [rsp+158h] [rbp-28h] BYREF
  std::__shared_weak_count *v18; // [rsp+160h] [rbp-20h]

  if ( *(_QWORD *)a3 != 0 && *(_BYTE *)(a3 + 72) == 1 ) /*0x104c32a5b*/
  {
    RBX::weak_from<RBX::Humanoid>(a1: &v17, a2: *(_QWORD *)a3); /*0x104c32a67*/
    RBX::HumanoidIdentifier::HumanoidIdentifier(this: (RBX::HumanoidIdentifier *)v7, a2: &v17); /*0x104c32a76*/
    if ( v18 != nullptr ) /*0x104c32a82*/
      std::__shared_weak_count::__release_weak(this: v18); /*0x104c32a84*/
    if ( (unsigned int)RBX::HumanoidIdentifier::getBodyPartType(this: (RBX::HumanoidIdentifier *)v7, a2) != 0 ) /*0x104c32a9a*/
      LODWORD(a1) = 0; /*0x104c32a9c*/
    else
      LOBYTE(a1) = *(_DWORD *)(a1 + 176) == 5; /*0x104c32aab*/
    if ( (v15 & 1) != 0 ) /*0x104c32ab2*/
      operator delete(a1: (RBX::Memory *)v16, a2: v5); /*0x104c32ab8*/
    if ( (v13 & 1) != 0 ) /*0x104c32ac4*/
      operator delete(a1: (RBX::Memory *)v14, a2: v5); /*0x104c32acd*/
    if ( (v11 & 1) != 0 ) /*0x104c32ad9*/
      operator delete(a1: (RBX::Memory *)v12, a2: v5); /*0x104c32ae2*/
    if ( v9 != nullptr ) /*0x104c32af1*/
    {
      v10 = v9; /*0x104c32af3*/
      operator delete(a1: (RBX::Memory *)v9, a2: v5); /*0x104c32afa*/
    }
    if ( v8 != nullptr ) /*0x104c32b09*/
      std::__shared_weak_count::__release_weak(this: v8); /*0x104c32b0b*/
  }
  else
  {
    LODWORD(a1) = 0; /*0x104c32aa0*/
  }
  return (unsigned int)a1; /*0x104c32b12*/
}

// Address: 0x104c39908 | Name: __ZN3RBXL14isBoneAnimatedERKNS_6Motion8SkeletonEj
__int64 __fastcall RBX::isBoneAnimated(RBX *this, const RBX::Motion::Skeleton *a2)
{
  __int64 v2; // rbx
  __int64 BoneDescriptor; // rax
  __int64 v4; // r14
  __int64 v6; // rax
  __int64 v7; // rdi
  __int64 v8; // r14
  __int64 v9; // r15
  __int64 v10; // rax
  __int64 v11; // rdi
  __int64 v12; // rsi
  __int64 v13; // rax

  BoneDescriptor = RBX::Motion::SkeletonData::getBoneDescriptor(this, (unsigned int)a2); /*0x104c39912*/
  LOBYTE(v2) = 1; /*0x104c39917*/
  if ( *(_DWORD *)(BoneDescriptor + 76) != -1 ) /*0x104c3991d*/
  {
    v4 = BoneDescriptor; /*0x104c3991f*/
    if ( RBX::weak_get_unsafe<RBX::BoneInstance>(a1: BoneDescriptor + 32) == 0 ) /*0x104c3992e*/
    {
      v6 = RBX::weak_get_unsafe<RBX::Instance>(a1: v4 + 16); /*0x104c39944*/
      if ( v6 != 0 ) /*0x104c3994c*/
      {
        v8 = v6; /*0x104c3994e*/
        v9 = *(_QWORD *)(v6 + 24); /*0x104c39951*/
        v10 = RBX::Reflection::Class_getDescriptorPtr<RBX::Motor6D>(a1: v7); /*0x104c39955*/
        if ( *(unsigned __int16 *)(v9 + 440) - (unsigned int)*(unsigned __int16 *)(v10 + 440) > *(unsigned __int16 *)(v10 + 442) ) /*0x104c39974*/
        {
          v2 = *(_QWORD *)(v8 + 24); /*0x104c39976*/
          v13 = RBX::Reflection::Class_getDescriptorPtr<RBX::Constraints::AnimationConstraint>(a1: v11, a2: v12); /*0x104c3997a*/
          LOBYTE(v2) = *(unsigned __int16 *)(v2 + 440) - (unsigned int)*(unsigned __int16 *)(v13 + 440) <= *(unsigned __int16 *)(v13 + 442); /*0x104c39998*/
        }
      }
      else
      {
        LODWORD(v2) = 0; /*0x104c3999d*/
      }
    }
  }
  return (unsigned int)v2; /*0x104c39936*/
}

// Address: 0x104d93976 | Name: __ZN3RBX42isEnableCreateDataModelContentAsyncEnabledEv
char __fastcall RBX::isEnableCreateDataModelContentAsyncEnabled(RBX *this)
{
  return FFlag::ExposeRuntimeContentAPI; /*0x104d93983*/
}

// Address: 0x104d94cd6 | Name: __ZN3RBX31isEnableCreateAssetAsyncEnabledEv
__int64 __fastcall RBX::isEnableCreateAssetAsyncEnabled(RBX *this)
{
  unsigned int v1; // ebx
  _QWORD *v2; // r14
  __int64 v3; // rax
  __int64 (__fastcall *v4)(__int64, _QWORD); // rcx

  LOBYTE(v1) = 1; /*0x104d94cdd*/
  if ( FFlag::EnableCreateAssetAsync == 0 ) /*0x104d94ce6*/
  {
    if ( FFlag::EnableCreateAssetAsyncForRobloxScript != 1 ) /*0x104d94cef*/
      return 0; /*0x104d94cef*/
    v2 = (_QWORD *)RBX::Security::Context::current(this); /*0x104d94cf6*/
    v3 = v2[5]; /*0x104d94cf9*/
    v4 = (__int64 (__fastcall *)(__int64, _QWORD))v2[6]; /*0x104d94cfd*/
    if ( v4 != nullptr ) /*0x104d94d04*/
    {
      v3 = v4(a1: v3, a2: v2[3]); /*0x104d94d0d*/
      v2[5] = v3; /*0x104d94d0f*/
      v2[6] = 0; /*0x104d94d13*/
    }
    if ( (v3 & 8) == 0 ) /*0x104d94d1d*/
      return 0; /*0x104d94d1f*/
  }
  return v1; /*0x104d94d23*/
}

// Address: 0x104df11a5 | Name: __ZN3RBX23inCopyPropertyAllowListEPKNS_10Reflection18PropertyDescriptorE
char __fastcall RBX::inCopyPropertyAllowList(RBX *this, const RBX::Reflection::PropertyDescriptor *a2)
{
  char result; // al

  result = 1; /*0x104df11b0*/
  if ( RBX::BasePartProperties::prop_Velocity != (_UNKNOWN *)this /*0x104df11cd*/
    && RBX::BasePartProperties::prop_RotVelocity != (_UNKNOWN *)this
    && RBX::BasePartProperties::prop_CFrame != (_UNKNOWN *)this )
  {
    if ( RBX::BasePartProperties::prop_ReplicationPV == (_UNKNOWN *)this ) /*0x104df11d9*/
    {
      return 0; /*0x104df11ed*/
    }
    else if ( RBX::InstanceProperties::prop_Name != (_UNKNOWN *)this ) /*0x104df11e5*/
    {
      return RBX::Network::InstanceReplication::InstanceStateReplicationBridge::isPropertyNextGenRepPropertyForAuroraService( /*0x104df11e8*/
               this,
               a2);
    }
  }
  return result; /*0x104df11e7*/
}

// Address: 0x104df4ca6 | Name: __ZN3RBX10InputFrameaSEOS0_
__int64 __fastcall RBX::InputFrame::operator=(__int64 a1, __int64 a2)
{
  __int128 v4; // xmm4
  __int128 v5; // xmm0
  __int128 v6; // xmm1
  __int128 v7; // xmm2
  __int128 v8; // xmm0
  std::__shared_weak_count *v9; // rdi
  __int128 v10; // xmm0
  std::__shared_weak_count *v11; // rdi
  __int128 v12; // xmm0
  std::__shared_weak_count *v13; // rdi

  RBX::details::SplitHashTable<RBX::Guid,std::pair<RBX::Guid,RBX::ActionSnapshot>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Guid>,RBX::details::DefaultEqualTo<RBX::Guid>,RBX::details::GetMapKey<RBX::Guid,RBX::ActionSnapshot>>::operator=<10,void>(); /*0x104df4cb3*/
  std::vector<RBX::Guid>::__move_assign(a1: a1 + 40, a2: a2 + 40); /*0x104df4cc0*/
  std::vector<RBX::ControlStateSnapshot>::__vdeallocate(a1: a1 + 64); /*0x104df4cc9*/
  *(_OWORD *)(a1 + 64) = *(_OWORD *)(a2 + 64); /*0x104df4cd3*/
  *(_QWORD *)(a1 + 80) = *(_QWORD *)(a2 + 80); /*0x104df4cdb*/
  v4 = 0; /*0x104df4cdf*/
  *(_OWORD *)(a2 + 64) = 0; /*0x104df4ce2*/
  *(_QWORD *)(a2 + 80) = 0; /*0x104df4ce7*/
  v5 = *(_OWORD *)(a2 + 88); /*0x104df4cef*/
  v6 = *(_OWORD *)(a2 + 104); /*0x104df4cf4*/
  v7 = *(_OWORD *)(a2 + 120); /*0x104df4cf9*/
  *(_OWORD *)(a1 + 132) = *(_OWORD *)(a2 + 132); /*0x104df4d06*/
  *(_OWORD *)(a1 + 120) = v7; /*0x104df4d0d*/
  *(_OWORD *)(a1 + 104) = v6; /*0x104df4d11*/
  *(_OWORD *)(a1 + 88) = v5; /*0x104df4d15*/
  v8 = *(_OWORD *)(a2 + 152); /*0x104df4d19*/
  *(_OWORD *)(a2 + 152) = 0; /*0x104df4d21*/
  v9 = *(std::__shared_weak_count **)(a1 + 160); /*0x104df4d29*/
  *(_OWORD *)(a1 + 152) = v8; /*0x104df4d30*/
  if ( v9 != nullptr ) /*0x104df4d3a*/
  {
    std::__shared_weak_count::__release_weak(this: v9); /*0x104df4d3c*/
    v4 = 0; /*0x104df4d41*/
  }
  v10 = *(_OWORD *)(a2 + 168); /*0x104df4d44*/
  *(_OWORD *)(a2 + 168) = v4; /*0x104df4d4c*/
  v11 = *(std::__shared_weak_count **)(a1 + 176); /*0x104df4d54*/
  *(_OWORD *)(a1 + 168) = v10; /*0x104df4d5b*/
  if ( v11 != nullptr ) /*0x104df4d65*/
    std::__shared_weak_count::__release_weak(this: v11); /*0x104df4d67*/
  *(_DWORD *)(a1 + 184) = *(_DWORD *)(a2 + 184); /*0x104df4d73*/
  v12 = *(_OWORD *)(a2 + 192); /*0x104df4d79*/
  *(_OWORD *)(a2 + 192) = 0; /*0x104df4d84*/
  v13 = *(std::__shared_weak_count **)(a1 + 200); /*0x104df4d8c*/
  *(_OWORD *)(a1 + 192) = v12; /*0x104df4d93*/
  if ( v13 != nullptr ) /*0x104df4d9d*/
    std::__shared_weak_count::__release_weak(this: v13); /*0x104df4d9f*/
  return a1; /*0x104df4da7*/
}

// Address: 0x104e64c02 | Name: __ZN3RBXL7isArrayEP9lua_Stateii
bool __fastcall RBX::isArray(__int64 a1, __int64 a2, int a3)
{
  unsigned int v4; // r14d

  v4 = a2; /*0x104e64c0e*/
  return (unsigned int)lua_type(a1, a2) == 7 && (unsigned int)lua_objlen(a1, a2: v4) == a3; /*0x104e64c36*/
}

// Address: 0x104e796fe | Name: __ZN3RBX18ignoreModelLODPropERKNS_10Reflection18PropertyDescriptorE
bool __fastcall RBX::ignoreModelLODProp(RBX *this, const RBX::Reflection::PropertyDescriptor *a2)
{
  bool result; // al

  result = true; /*0x104e79705*/
  if ( (*((_BYTE *)this + 139) & 8) != 0 && RBX::BasePartProperties::prop_Anchored != (_UNKNOWN *)this ) /*0x104e79717*/
    return RBX::PartOperationProperties::prop_TriangleCount == (_UNKNOWN *)this; /*0x104e79723*/
  return result; /*0x104e79727*/
}

// Address: 0x104ebf4fc | Name: __ZN3RBX13isPlayerValidEPNS_8InstanceERKNS_13SystemAddressE
bool __fastcall RBX::isPlayerValid(RBX::Player *this, _DWORD *a2)
{
  __int64 v4; // r15
  __int64 v5; // rax

  if ( this == nullptr ) /*0x104ebf4ff*/
    return false; /*0x104ebf53a*/
  v4 = *((_QWORD *)this + 3); /*0x104ebf511*/
  v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(a1: this); /*0x104ebf515*/
  return *(unsigned __int16 *)(v4 + 440) - (unsigned int)*(unsigned __int16 *)(v5 + 440) <= *(unsigned __int16 *)(v5 + 442) /*0x104ebf53c*/
      && (unsigned int)RBX::Player::getRemoteAddressAsRbxAddress(this) == *a2;
}

// Address: 0x104ec00be | Name: __ZN3RBX14isRemotePlayerERKNS_10Reflection7VariantERKNS_13SystemAddressE
__int64 __fastcall RBX::isRemotePlayer(_QWORD *a1, _DWORD *a2)
{
  __int64 v4; // r15
  RBX::Instance *v5; // rdi
  __int64 v6; // r15
  __int64 v7; // r15
  const char *v8; // rsi
  __int64 v9; // rax
  __int64 v10; // r15
  __int64 v11; // rax
  __int64 v12; // rax
  std::__shared_weak_count *v13; // r14
  std::__shared_weak_count *v14; // r14
  RBX::Player *v16; // [rsp+0h] [rbp-40h] BYREF
  std::__shared_weak_count *v17; // [rsp+8h] [rbp-38h]
  std::__shared_weak_count *v18[2]; // [rsp+10h] [rbp-30h] BYREF

  v4 = *a1; /*0x104ec00d1*/
  if ( RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Instance>>(a1) != v4 /*0x104ec0128*/
    && (v6 = *a1, RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Object>>(a1: v5) != v6)
    && (v7 = *a1, RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::DescribedBase>>(a1: v5) != v7)
    || (v9 = a1[2]) != 0
    && (v10 = *(_QWORD *)(v9 + 24),
        v11 = RBX::Instance::classDescriptor(this: v5),
        *(unsigned __int16 *)(v10 + 440) - (unsigned int)*(unsigned __int16 *)(v11 + 440) > *(unsigned __int16 *)(v11 + 442)) )
  {
    RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v8); /*0x104ec01d7*/
  }
  v12 = a1[3]; /*0x104ec012e*/
  *(_OWORD *)v18 = *((_OWORD *)a1 + 1); /*0x104ec0137*/
  if ( v12 != 0 ) /*0x104ec013e*/
    _InterlockedIncrement64((volatile signed __int64 *)(v12 + 8)); /*0x104ec0140*/
  RBX::Reflection::DescribedBase::fastSharedDynamicCast<RBX::Player,RBX::Instance>(a1: &v16, a2: v18); /*0x104ec014d*/
  if ( v16 != nullptr ) /*0x104ec0159*/
    LOBYTE(a2) = (unsigned int)RBX::Player::getRemoteAddressAsRbxAddress(this: v16) == *a2; /*0x104ec0162*/
  else
    LODWORD(a2) = 0; /*0x104ec0167*/
  v13 = v17; /*0x104ec0169*/
  if ( v17 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v17 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104ec0182*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x104ec018a*/
    std::__shared_weak_count::__release_weak(this: v13); /*0x104ec0190*/
  }
  v14 = v18[1]; /*0x104ec0195*/
  if ( v18[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v18[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104ec01ae*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x104ec01b6*/
    std::__shared_weak_count::__release_weak(this: v14); /*0x104ec01bc*/
  }
  return (unsigned int)a2; /*0x104ec01c3*/
}

// Address: 0x104ee0eac | Name: __ZN3RBXL17isValidAcrKeyImplENS_10StringViewE
__int64 __fastcall RBX::isValidAcrKeyImpl(__int64 a1, __int64 a2)
{
  const char *v4; // rsi
  void *v5; // rsi
  unsigned int v6; // r14d
  char v7; // r12
  std::__shared_weak_count *v8; // r15
  void *v10[6]; // [rsp+0h] [rbp-D0h] BYREF
  __int128 v11; // [rsp+30h] [rbp-A0h]
  char v12; // [rsp+40h] [rbp-90h]
  __int128 v13; // [rsp+48h] [rbp-88h]
  char v14; // [rsp+58h] [rbp-78h]
  char v15; // [rsp+60h] [rbp-70h]
  __int64 v16; // [rsp+68h] [rbp-68h]
  _BYTE v17[48]; // [rsp+70h] [rbp-60h] BYREF
  std::__shared_weak_count *v18; // [rsp+A0h] [rbp-30h]

  v4 = "^rbxruntime:\\/\\/[\\w+=(]+$"; /*0x104ee0ecb*/
  if ( FFlag::SimRuntimeContentMeshStreaming != 0 ) /*0x104ee0edc*/
    v4 = "^rbxruntime:\\/\\/[\\w+=(.]+$"; /*0x104ee0edc*/
  std::basic_regex<char,std::regex_traits<char>>::basic_regex[abi:ne200100](a1: v17, a2: v4, a3: 0); /*0x104ee0ee9*/
  v12 = 0; /*0x104ee0ef9*/
  v11 = 0; /*0x104ee0f00*/
  v13 = 0; /*0x104ee0f04*/
  v14 = 0; /*0x104ee0f08*/
  v15 = 0; /*0x104ee0f0c*/
  v16 = 0; /*0x104ee0f10*/
  memset(v10, 0, 41); /*0x104ee0f18*/
  v6 = std::basic_regex<char,std::regex_traits<char>>::__search<std::allocator<std::sub_match<char const*>>>( /*0x104ee0f34*/
         a1: v17,
         a2: a1,
         a3: a1 + a2,
         a4: v10,
         a5: 4160);
  v7 = v14; /*0x104ee0f37*/
  if ( v10[0] != nullptr ) /*0x104ee0f45*/
  {
    v10[1] = v10[0]; /*0x104ee0f47*/
    operator delete(a1: (RBX::Memory *)v10[0], a2: v5); /*0x104ee0f4e*/
  }
  v8 = v18; /*0x104ee0f53*/
  if ( v18 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v18 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104ee0f6c*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x104ee0f74*/
    std::__shared_weak_count::__release_weak(this: v8); /*0x104ee0f7a*/
  }
  LOBYTE(v6) = ~v7 & ((unsigned int)(a2 - 14) < 0x100) & v6; /*0x104ee0f91*/
  std::locale::~locale(this: (std::locale *)v17); /*0x104ee0f98*/
  return v6; /*0x104ee0fa0*/
}

// Address: 0x104f31b77 | Name: __ZN3RBXL27incrementPerUniverseCounterEPNS_9DataModelERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall RBX::incrementPerUniverseCounter(__int64 a1, unsigned __int8 *a2)
{
  __int64 v3; // rdx
  __int64 v4; // rcx
  void *v5; // rsi
  char v6; // r14
  unsigned __int8 *v7; // rcx
  __int64 v8; // rdx
  __int64 v9; // rdi
  _BYTE *v10; // rsi
  _QWORD v11[2]; // [rsp+0h] [rbp-60h] BYREF
  void *v12; // [rsp+10h] [rbp-50h]
  __int64 v13; // [rsp+18h] [rbp-48h]
  _BYTE v14[16]; // [rsp+20h] [rbp-40h] BYREF
  void *v15; // [rsp+30h] [rbp-30h]
  unsigned __int8 v16; // [rsp+38h] [rbp-28h] BYREF
  _BYTE v17[15]; // [rsp+39h] [rbp-27h] BYREF
  void *v18; // [rsp+48h] [rbp-18h]

  std::to_string(a1: (__int64)&v16); /*0x104f31b90*/
  std::string::basic_string[abi:ne200100]<0>(a1: v11, a2: ",", a3: v3, a4: v4); /*0x104f31ba0*/
  v6 = RBX::StringParser::delimitedStringContains( /*0x104f31bb9*/
         a1: &DFString::TeleportPerUniverseErrorRateUniverseIdsCsv,
         a2: &v16,
         a3: v11);
  if ( (v11[0] & 1) != 0 ) /*0x104f31bc0*/
    operator delete(a1: (RBX::Memory *)v12, a2: v5); /*0x104f31bc6*/
  if ( v6 != 0 ) /*0x104f31bce*/
  {
    v7 = a2 + 1; /*0x104f31bd7*/
    v8 = *a2 >> 1; /*0x104f31bdd*/
    if ( (*a2 & 1) != 0 ) /*0x104f31be1*/
    {
      v7 = *((unsigned __int8 **)a2 + 2); /*0x104f31be1*/
      v8 = *((_QWORD *)a2 + 1); /*0x104f31be6*/
    }
    v9 = v16 >> 1; /*0x104f31bf5*/
    v10 = v18; /*0x104f31bfb*/
    if ( (v16 & 1) != 0 ) /*0x104f31bff*/
      v9 = *(_QWORD *)&v17[7]; /*0x104f31c03*/
    else
      v10 = v17; /*0x104f31bff*/
    v11[0] = v7; /*0x104f31c0c*/
    v11[1] = v8; /*0x104f31c0f*/
    v12 = v10; /*0x104f31c13*/
    v13 = v9; /*0x104f31c17*/
    fmt::v8::vformat(a1: v14, a2: "{}-{}", a3: 5, a4: 221, a5: v11); /*0x104f31c30*/
    RBX::Analytics::EphemeralCounter::reportCounter(a1: v14, a2: 1, a3: 0); /*0x104f31c40*/
    if ( (v14[0] & 1) != 0 ) /*0x104f31c49*/
      operator delete(a1: (RBX::Memory *)v15, a2: v5); /*0x104f31c4f*/
  }
  if ( (v16 & 1) != 0 ) /*0x104f31c58*/
    operator delete(a1: (RBX::Memory *)v18, a2: v5); /*0x104f31c5e*/
}

// Address: 0x104f3d3fd | Name: __ZN3RBX21isVariantTeleportSafeERKNS_10Reflection7VariantEiRi
__int64 __fastcall RBX::isVariantTeleportSafe(
        RBX::VariantSerializer **this,
        const RBX::Reflection::Variant *a2,
        int *a3,
        int *a4)
{
  int v4; // ebx
  int v5; // r14d
  RBX::VariantSerializer *v7; // rdi
  unsigned int v8; // r15d
  char SerializedType; // al
  int *v11; // rcx
  _QWORD *v12; // r12
  unsigned int v13; // r14d
  RBX **v14; // rax
  int *v15; // rcx
  RBX *v16; // r12
  RBX *v17; // r13
  unsigned int v18; // r14d
  unsigned int isVariantTeleportSafe; // eax

  if ( (int)a2 <= 0 ) /*0x104f3d40d*/
  {
    return 2; /*0x104f3d449*/
  }
  else
  {
    v4 = (int)a3; /*0x104f3d40f*/
    if ( *a3 <= 0 ) /*0x104f3d416*/
    {
      return 3; /*0x104f3d451*/
    }
    else
    {
      v5 = (int)a2; /*0x104f3d418*/
      --*a3; /*0x104f3d420*/
      v7 = *this; /*0x104f3d422*/
      v8 = 1; /*0x104f3d428*/
      switch ( *((_DWORD *)v7 + 12) ) /*0x104f3d442*/
      {
        case 0: /*0x104f3d442*/
        case 1: /*0x104f3d442*/
        case 2: /*0x104f3d442*/
        case 3: /*0x104f3d442*/
        case 4: /*0x104f3d442*/
        case 5: /*0x104f3d442*/
        case 6: /*0x104f3d442*/
        case 0xA: /*0x104f3d442*/
        case 0xB: /*0x104f3d442*/
        case 0xC: /*0x104f3d442*/
        case 0xD: /*0x104f3d442*/
        case 0xE: /*0x104f3d442*/
        case 0xF: /*0x104f3d442*/
        case 0x10: /*0x104f3d442*/
        case 0x11: /*0x104f3d442*/
        case 0x12: /*0x104f3d442*/
        case 0x13: /*0x104f3d442*/
        case 0x14: /*0x104f3d442*/
        case 0x15: /*0x104f3d442*/
        case 0x16: /*0x104f3d442*/
        case 0x17: /*0x104f3d442*/
        case 0x18: /*0x104f3d442*/
        case 0x1C: /*0x104f3d442*/
        case 0x21: /*0x104f3d442*/
        case 0x2A: /*0x104f3d442*/
        case 0x2B: /*0x104f3d442*/
        case 0x2C: /*0x104f3d442*/
        case 0x2D: /*0x104f3d442*/
        case 0x2E: /*0x104f3d442*/
        case 0x31: /*0x104f3d442*/
        case 0x37: /*0x104f3d442*/
        case 0x3B: /*0x104f3d442*/
        case 0x40: /*0x104f3d442*/
        case 0x49: /*0x104f3d442*/
        case 0x4A: /*0x104f3d442*/
        case 0x56: /*0x104f3d442*/
        case 0x58: /*0x104f3d442*/
          return 0;
        case 8: /*0x104f3d442*/
        case 9: /*0x104f3d442*/
        case 0x28: /*0x104f3d442*/
        case 0x2F: /*0x104f3d442*/
        case 0x30: /*0x104f3d442*/
        case 0x32: /*0x104f3d442*/
        case 0x36: /*0x104f3d442*/
        case 0x41: /*0x104f3d442*/
        case 0x42: /*0x104f3d442*/
        case 0x43: /*0x104f3d442*/
        case 0x44: /*0x104f3d442*/
        case 0x4B: /*0x104f3d442*/
        case 0x4C: /*0x104f3d442*/
        case 0x4D: /*0x104f3d442*/
        case 0x4E: /*0x104f3d442*/
        case 0x4F: /*0x104f3d442*/
        case 0x51: /*0x104f3d442*/
        case 0x5B: /*0x104f3d442*/
        case 0x5C: /*0x104f3d442*/
        case 0x5F: /*0x104f3d442*/
          return v8;
        default:
          SerializedType = RBX::VariantSerializer::getSerializedType(this: v7, a2); /*0x104f3d469*/
          if ( SerializedType == 7 ) /*0x104f3d470*/
          {
            v14 = *(RBX ***)RBX::Reflection::Variant::cast<std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>(a1: this); /*0x104f3d4b6*/
            v16 = *v14; /*0x104f3d4b9*/
            v17 = v14[1]; /*0x104f3d4bc*/
            v8 = 0; /*0x104f3d4c0*/
            if ( *v14 == v17 ) /*0x104f3d4c6*/
              return v8; /*0x104f3d4c6*/
            v18 = v5 - 1; /*0x104f3d4c8*/
            while ( 1 ) /*0x104f3d4d4*/
            {
              isVariantTeleportSafe = RBX::isVariantTeleportSafe( /*0x104f3d4d4*/
                                        this: v16,
                                        a2: (const RBX::Reflection::Variant *)v18,
                                        a3: v4,
                                        a4: v15);
              if ( isVariantTeleportSafe != 0 ) /*0x104f3d4db*/
                break; /*0x104f3d4db*/
              v16 = (RBX *)((char *)v16 + 80); /*0x104f3d4dd*/
              if ( v16 == v17 ) /*0x104f3d4e4*/
                return v8; /*0x104f3d4e4*/
            }
            v8 = isVariantTeleportSafe; /*0x104f3d4eb*/
          }
          else if ( SerializedType == 8 ) /*0x104f3d478*/
          {
            v12 = (_QWORD *)(*(_QWORD *)RBX::Reflection::Variant::cast<std::shared_ptr<RBX::Reflection::ValueTable const>>(a1: this) /*0x104f3d485*/
                           + 16LL);
            v13 = v5 - 1; /*0x104f3d489*/
            do /*0x104f3d4aa*/
            {
              v12 = (_QWORD *)*v12; /*0x104f3d48c*/
              if ( v12 == nullptr ) /*0x104f3d493*/
                return 0; /*0x104f3d447*/
              v8 = RBX::isVariantTeleportSafe( /*0x104f3d4a5*/
                     this: (RBX *)(v12 + 5),
                     a2: (const RBX::Reflection::Variant *)v13,
                     a3: v4,
                     a4: v11);
            }
            while ( v8 == 0 ); /*0x104f3d4aa*/
          }
          break; /*0x104f3d4aa*/
      }
    }
  }
  return v8; /*0x104f3d45e*/
}

// Address: 0x105415c74 | Name: __ZN3RBX10IndexArrayINS_11NetworkBase26InstanceObjectHandleGlobalEXadL_ZNS2_18getDirtyFrameIndexEvEEE6removeEPS2_
__int64 __fastcall RBX::IndexArray<RBX::NetworkBase::InstanceObjectHandleGlobal,&RBX::NetworkBase::InstanceObjectHandleGlobal::getDirtyFrameIndex>::remove(
        __int64 *a1,
        __int64 a2)
{
  unsigned __int64 v2; // rcx
  __int64 result; // rax
  __int64 v4; // rdx
  unsigned __int64 v5; // r8
  __int64 v6; // rdx

  v2 = *(int *)(a2 + 120); /*0x105415c74*/
  result = *a1; /*0x105415c7f*/
  v4 = a1[1]; /*0x105415c82*/
  if ( FFlag::IndexArrayValidateItemSlot != 0 ) /*0x105415c8a*/
  {
    if ( (v2 & 0x80000000) != 0LL ) /*0x105415c8e*/
      return result; /*0x105415c8e*/
    v5 = (v4 - result) >> 3; /*0x105415c96*/
    if ( v5 <= v2 ) /*0x105415c9d*/
      return result; /*0x105415c9d*/
  }
  else
  {
    v5 = (v4 - result) >> 3; /*0x105415ca6*/
  }
  if ( v5 - 1 > v2 ) /*0x105415cb4*/
  {
    do /*0x105415ce0*/
    {
      v6 = *(_QWORD *)(result + 8 * v2 + 8); /*0x105415cb6*/
      *(_QWORD *)(result + 8 * v2) = v6; /*0x105415cbb*/
      *(_DWORD *)(v6 + 120) = v2; /*0x105415cbf*/
      result = *a1; /*0x105415cc6*/
      v4 = a1[1]; /*0x105415cc9*/
      ++v2; /*0x105415cda*/
    }
    while ( ((v4 - *a1) >> 3) - 1 > v2 ); /*0x105415ce0*/
  }
  a1[1] = v4 - 8; /*0x105415ce6*/
  *(_DWORD *)(a2 + 120) = -1; /*0x105415cea*/
  return result; /*0x105415c9f*/
}

// Address: 0x105416032 | Name: __ZN3RBX10IndexArrayINS_11NetworkBase26InstanceObjectHandleGlobalEXadL_ZNS2_18getDirtyFrameIndexEvEEE20fastAppendIfNotExistEPS2_
__int64 __fastcall RBX::IndexArray<RBX::NetworkBase::InstanceObjectHandleGlobal,&RBX::NetworkBase::InstanceObjectHandleGlobal::getDirtyFrameIndex>::fastAppendIfNotExist(
        _QWORD *a1,
        __int64 a2)
{
  __int64 result; // rax
  __int64 v3; // [rsp-10h] [rbp-10h] BYREF

  if ( *(int *)(a2 + 120) < 0 ) /*0x105416036*/
  {
    v3 = a2; /*0x105416045*/
    *(_DWORD *)(a2 + 120) = (a1[1] - *a1) >> 3; /*0x105416053*/
    return std::vector<RBX::NetworkBase::InstanceObjectHandleGlobal *,RSL::Detail::Allocator<RBX::NetworkBase::InstanceObjectHandleGlobal *>>::push_back[abi:ne200100]( /*0x105416059*/
             a1,
             a2: &v3);
  }
  return result; /*0x105416038*/
}

// Address: 0x10543f310 | Name: __ZN3RBX10IndexArrayINS_7Network14NetworkObjects5GroupEXadL_ZNS3_13getGroupIndexEvEEE10fastRemoveEPS3_
__int64 __fastcall RBX::IndexArray<RBX::Network::NetworkObjects::Group,&RBX::Network::NetworkObjects::Group::getGroupIndex>::fastRemove(
        __int64 *a1,
        RBX::Network::NetworkObjects::Group *a2)
{
  int v4; // r15d
  __int64 result; // rax
  __int64 v6; // rcx
  __int64 v7; // rdx
  RBX::Network::NetworkObjects::Group *v8; // rdi

  v4 = *(_DWORD *)RBX::Network::NetworkObjects::Group::getGroupIndex(this: a2); /*0x10543f328*/
  result = v4; /*0x10543f32b*/
  v6 = *a1; /*0x10543f335*/
  v7 = a1[1]; /*0x10543f338*/
  if ( FFlag::IndexArrayValidateItemSlot == 0 || v4 >= 0 && (v7 - v6) >> 3 > (unsigned __int64)v4 ) /*0x10543f353*/
  {
    v8 = *(RBX::Network::NetworkObjects::Group **)(v7 - 8); /*0x10543f355*/
    *(_QWORD *)(v6 + 8LL * v4) = v8; /*0x10543f359*/
    *(_DWORD *)RBX::Network::NetworkObjects::Group::getGroupIndex(this: v8) = v4; /*0x10543f362*/
    a1[1] -= 8; /*0x10543f365*/
    result = RBX::Network::NetworkObjects::Group::getGroupIndex(this: a2); /*0x10543f36d*/
    *(_DWORD *)result = -1; /*0x10543f372*/
  }
  return result; /*0x10543f37c*/
}

// Address: 0x1054411de | Name: __ZN3RBX10IndexArrayINS_7Network14NetworkObjects5GroupEXadL_ZNS3_11getSetIndexEvEEE5clearEv
_DWORD *__fastcall RBX::IndexArray<RBX::Network::NetworkObjects::Group,&RBX::Network::NetworkObjects::Group::getSetIndex>::clear(
        RBX::Network::NetworkObjects::Group ***a1)
{
  RBX::Network::NetworkObjects::Group **v2; // r14
  RBX::Network::NetworkObjects::Group **v3; // r15
  _DWORD *result; // rax

  v2 = *a1; /*0x1054411eb*/
  v3 = a1[1]; /*0x1054411ee*/
  if ( *a1 != v3 ) /*0x1054411f5*/
  {
    do /*0x10544120c*/
    {
      result = (_DWORD *)RBX::Network::NetworkObjects::Group::getSetIndex(this: *v2); /*0x1054411fa*/
      *result = -1; /*0x1054411ff*/
      ++v2; /*0x105441205*/
    }
    while ( v2 != v3 ); /*0x10544120c*/
    v2 = *a1; /*0x10544120e*/
  }
  a1[1] = v2; /*0x105441211*/
  return result; /*0x105441219*/
}

// Address: 0x10544128c | Name: __ZN3RBX10IndexArrayINS_7Network14NetworkObjects5GroupEXadL_ZNS3_11getSetIndexEvEEE10fastRemoveEPS3_
__int64 __fastcall RBX::IndexArray<RBX::Network::NetworkObjects::Group,&RBX::Network::NetworkObjects::Group::getSetIndex>::fastRemove(
        __int64 *a1,
        RBX::Network::NetworkObjects::Group *a2)
{
  int v4; // r15d
  __int64 result; // rax
  __int64 v6; // rcx
  __int64 v7; // rdx
  RBX::Network::NetworkObjects::Group *v8; // rdi

  v4 = *(_DWORD *)RBX::Network::NetworkObjects::Group::getSetIndex(this: a2); /*0x1054412a4*/
  result = v4; /*0x1054412a7*/
  v6 = *a1; /*0x1054412b1*/
  v7 = a1[1]; /*0x1054412b4*/
  if ( FFlag::IndexArrayValidateItemSlot == 0 || v4 >= 0 && (v7 - v6) >> 3 > (unsigned __int64)v4 ) /*0x1054412cf*/
  {
    v8 = *(RBX::Network::NetworkObjects::Group **)(v7 - 8); /*0x1054412d1*/
    *(_QWORD *)(v6 + 8LL * v4) = v8; /*0x1054412d5*/
    *(_DWORD *)RBX::Network::NetworkObjects::Group::getSetIndex(this: v8) = v4; /*0x1054412de*/
    a1[1] -= 8; /*0x1054412e1*/
    result = RBX::Network::NetworkObjects::Group::getSetIndex(this: a2); /*0x1054412e9*/
    *(_DWORD *)result = -1; /*0x1054412ee*/
  }
  return result; /*0x1054412f8*/
}

// Address: 0x10544299e | Name: __ZN3RBX10IndexArrayINS_7Network14NetworkObjects5GroupEXadL_ZNS3_11getSetIndexEvEEE20fastAppendIfNotExistEPS3_
int *__fastcall RBX::IndexArray<RBX::Network::NetworkObjects::Group,&RBX::Network::NetworkObjects::Group::getSetIndex>::fastAppendIfNotExist(
        _QWORD *a1,
        RBX::Network::NetworkObjects::Group *a2)
{
  int *result; // rax
  __int64 v5; // r12
  RBX::Network::NetworkObjects::Group *v6; // [rsp+8h] [rbp-28h] BYREF

  result = (int *)RBX::Network::NetworkObjects::Group::getSetIndex(this: a2); /*0x1054429b6*/
  if ( *result < 0 ) /*0x1054429be*/
  {
    v6 = a2; /*0x1054429c4*/
    v5 = (a1[1] - *a1) >> 3; /*0x1054429ce*/
    *(_DWORD *)RBX::Network::NetworkObjects::Group::getSetIndex(this: a2) = v5; /*0x1054429da*/
    return (int *)std::vector<RBX::Network::NetworkObjects::Group *,RSL::Detail::Allocator<RBX::Network::NetworkObjects::Group *>>::push_back[abi:ne200100]( /*0x1054429e3*/
                    a1,
                    a2: &v6);
  }
  return result; /*0x1054429e8*/
}

// Address: 0x10571f9ce | Name: __ZN3RBX47isStarterPlayerServiceOverridingAnimationScriptEPNS_6PlayerE
__int64 __fastcall RBX::isStarterPlayerServiceOverridingAnimationScript(RBX *this, RBX::Player *a2)
{
  __int64 v2; // rax
  __int64 v3; // rax
  __int64 v4; // rax
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // rbx
  void *v8; // rsi
  _BYTE v10[16]; // [rsp+8h] [rbp-28h] BYREF
  void *v11; // [rsp+18h] [rbp-18h]

  v2 = RBX::DataModel::get(this, a2); /*0x10571f9d9*/
  if ( v2 != 0 /*0x10571fa01*/
    && (v3 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::StarterPlayerService>(this: (RBX::ServiceProvider *)(v2 + 464))) != 0
    && (v4 = RBX::Instance::findConstFirstChildOfType<RBX::StarterCharacterScripts>(a1: v3)) != 0 )
  {
    v7 = v4; /*0x10571fa03*/
    std::string::basic_string[abi:ne200100]<0>(a1: v10, a2: "Animate", a3: v5, a4: v6); /*0x10571fa14*/
    LOBYTE(v7) = RBX::Instance::findFirstChildByName(a1: v7, a2: v10, a3: 0) != 0; /*0x10571fa29*/
    if ( (v10[0] & 1) != 0 ) /*0x10571fa30*/
      operator delete(a1: (RBX::Memory *)v11, a2: v8); /*0x10571fa36*/
  }
  else
  {
    LODWORD(v7) = 0; /*0x10571fa3d*/
  }
  return (unsigned int)v7; /*0x10571fa41*/
}

// Address: 0x1057202bd | Name: __ZN3RBX27injectLuaAdapterPartsScriptEPNS_6PlayerE
void __fastcall RBX::injectLuaAdapterPartsScript(RBX *this, RBX::Player *a2, __int64 a3, __int64 a4)
{
  const RBX::Instance *v5; // rsi
  RBX::ServiceProvider *ServiceProvider; // rax
  const RBX::Instance *v7; // rsi
  __int64 v8; // rax
  RBX::Instance *v9; // r14
  RBX::ServiceProvider *v10; // rax
  __int64 v11; // r12
  RBX::Instance *v12; // rbx
  RBX::EngineContext *v13; // rdi
  RBX::Instance *v14; // r15
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rdx
  __int64 v18; // rcx
  RBX *v19; // rdi
  void *v20; // rsi
  char *v21; // r12
  __int128 *v22; // r13
  __int64 v23; // rax
  __int128 *v24; // r15
  __int64 v25; // rdx
  __int64 v26; // rcx
  void *v27; // rsi
  char ScriptFromFile; // r13
  std::__shared_weak_count *v29; // r14
  bool v30; // zf
  std::__shared_weak_count *v31; // r14
  void *v32; // rsi
  char isA; // r14
  std::__shared_weak_count *v34; // rdi
  std::__shared_weak_count *v35; // r14
  std::__shared_weak_count *v36; // r14
  char v37; // al
  __int64 v38; // rdx
  __int64 v39; // rcx
  void *v40; // rsi
  RBX::Instance *v41; // r15
  char v42; // r14
  const char *v43; // rsi
  void *v44; // rsi
  char v45; // r14
  __int64 FirstChildByName; // rax
  RBX::Instance **v47; // r12
  RBX::Instance **v48; // r15
  RBX::Instance *v49; // r14
  std::__shared_weak_count *v50; // rbx
  RBX::Instance *v51; // [rsp+0h] [rbp-110h]
  __int64 v52; // [rsp+8h] [rbp-108h]
  std::__shared_weak_count *v53[2]; // [rsp+10h] [rbp-100h] BYREF
  std::__shared_weak_count *v54[2]; // [rsp+20h] [rbp-F0h] BYREF
  std::__shared_weak_count *v55[2]; // [rsp+30h] [rbp-E0h]
  _BYTE v56[16]; // [rsp+40h] [rbp-D0h] BYREF
  void *v57; // [rsp+50h] [rbp-C0h]
  RBX::Instance *v58; // [rsp+58h] [rbp-B8h]
  RBX::Instance *v59[2]; // [rsp+60h] [rbp-B0h] BYREF
  __int64 v60; // [rsp+70h] [rbp-A0h]
  __int128 v61; // [rsp+80h] [rbp-90h] BYREF
  void *v62; // [rsp+90h] [rbp-80h]
  std::__shared_weak_count *v63[2]; // [rsp+A0h] [rbp-70h] BYREF
  void *v64; // [rsp+B0h] [rbp-60h]
  __int128 v65; // [rsp+C0h] [rbp-50h] BYREF
  RBX *v66; // [rsp+D0h] [rbp-40h]
  void *v67; // [rsp+D8h] [rbp-38h]

  std::string::basic_string[abi:ne200100]<0>(a1: v56, a2: "UnificationServerScript", a3, a4); /*0x1057202e2*/
  if ( FFlag::AUMUnificationScaleUpdate == 0 ) /*0x1057202ee*/
    std::string::assign(a1: v56, a2: "UnificationServerScriptOldScale"); /*0x1057202fe*/
  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2: v5); /*0x105720306*/
  if ( ServiceProvider != nullptr ) /*0x10572030e*/
  {
    v8 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::StarterPlayerService>(this: ServiceProvider); /*0x105720313*/
    if ( v8 != 0 ) /*0x10572031b*/
    {
      v9 = (RBX::Instance *)RBX::Instance::findConstFirstChildOfType<RBX::StarterCharacterScripts>(a1: v8); /*0x105720325*/
      if ( v9 != nullptr ) /*0x10572032b*/
      {
        v10 = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2: v7); /*0x105720330*/
        if ( v10 != nullptr ) /*0x105720338*/
        {
          v11 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::ContentProvider>(this: v10); /*0x105720342*/
          if ( v11 != 0 && RBX::Instance::findFirstChildByName(a1: v9, a2: v56, a3: 0) == 0 ) /*0x10572035e*/
          {
            v12 = (RBX::Instance *)RBX::ServiceProvider::find<RBX::ReplicatedStorage>(a1: this); /*0x10572038f*/
            *(_QWORD *)&v65 = RBX::EngineContext::getThreadLocal(this: v13); /*0x10572039b*/
            DWORD2(v65) = 6138; /*0x10572039e*/
            RBX::Creatable::createImpl<RBX::Folder,RBX::ForceConstructionInCreatable &>(a1: v59); /*0x1057203ac*/
            v14 = v59[0]; /*0x1057203b1*/
            *(_OWORD *)v55 = *(_OWORD *)v59; /*0x1057203bf*/
            RBX::Instance::setParent(this: v59[0], a2: v12); /*0x1057203cc*/
            std::string::basic_string[abi:ne200100]<0>(a1: &v65, a2: "AvatarUnification", a3: v15, a4: v16); /*0x1057203dc*/
            RBX::Instance::setName(a1: v14, a2: &v65); /*0x1057203e8*/
            if ( (v65 & 1) != 0 ) /*0x1057203f1*/
              operator delete(a1: v66, a2: v20); /*0x1057203f7*/
            *(_OWORD *)v59 = 0; /*0x1057203ff*/
            v60 = 0; /*0x105720406*/
            v58 = v9; /*0x105720418*/
            v52 = v11; /*0x10572041f*/
            if ( FFlag::UseAvatarUnificationV2 == 1 /*0x10572043b*/
              && FFlag::AUMUnificationScaleUpdate == 1
              && FFlag::PrecomputeJointLocations == 1 )
            {
              RBX::getAvatarUnificationV2ScriptsInfo(this: v19); /*0x10572043d*/
              std::vector<std::tuple<std::string,std::string,std::shared_ptr<RBX::Instance>>>::__assign_with_size[abi:ne200100]<std::tuple<std::string,std::string,std::shared_ptr<RBX::Instance>> const*,std::tuple<std::string,std::string,std::shared_ptr<RBX::Instance>> const*>( /*0x10572045c*/
                a1: v59,
                a2: &RBX::getAvatarUnificationV2ScriptsInfo(void)::kAvatarUnificationScripts,
                a3: &`guard variable for'RBX::getAvatarUnificationV2ScriptsInfo(void)::kAvatarUnificationScripts,
                a4: 8);
            }
            else
            {
              RBX::getAvatarUnificationScriptsInfo(this: v19, a2: (__int64)v20, a3: v17, a4: v18); /*0x105720463*/
              std::vector<std::tuple<std::string,std::string,std::shared_ptr<RBX::Instance>>>::__assign_with_size[abi:ne200100]<std::tuple<std::string,std::string,std::shared_ptr<RBX::Instance>> const*,std::tuple<std::string,std::string,std::shared_ptr<RBX::Instance>> const*>( /*0x105720482*/
                a1: v59,
                a2: &RBX::getAvatarUnificationScriptsInfo(void)::kAvatarUnificationScripts,
                a3: &`guard variable for'RBX::getAvatarUnificationScriptsInfo(void)::kAvatarUnificationScripts,
                a4: 7);
            }
            v51 = v59[1]; /*0x105720495*/
            if ( v59[0] != v59[1] ) /*0x10572049f*/
            {
              v21 = (char *)v59[0] + 24; /*0x1057204a5*/
              v22 = &v65; /*0x1057204b0*/
              do /*0x105720683*/
              {
                RBX::Instance::clone(a1: v63, a2: *((_QWORD *)v21 + 3), a3: 3); /*0x1057204c2*/
                std::operator+<char>(a1: &v61, a2: "rbxasset://avatar/unification/", v21 - 24); /*0x1057204d6*/
                v23 = std::string::append(a1: &v61, a2: ".lua"); /*0x1057204e5*/
                v66 = *(RBX **)(v23 + 16); /*0x1057204ee*/
                v65 = *(_OWORD *)v23; /*0x1057204f5*/
                *(_OWORD *)v23 = 0; /*0x1057204fc*/
                *(_QWORD *)(v23 + 16) = 0; /*0x1057204ff*/
                *(_OWORD *)v53 = *(_OWORD *)v63; /*0x10572050f*/
                if ( v63[1] != nullptr ) /*0x105720519*/
                  _InterlockedIncrement64((volatile signed __int64 *)v63[1] + 1); /*0x10572051b*/
                v24 = v22; /*0x105720520*/
                ScriptFromFile = RBX::loadScriptFromFile(a1: v22, a2: v21, a3: v53); /*0x105720535*/
                v29 = v53[1]; /*0x105720538*/
                if ( v53[1] != nullptr /*0x105720554*/
                  && _InterlockedExchangeAdd64((volatile signed __int64 *)v53[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
                {
                  (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v29 + 16LL))(a1: v29); /*0x10572055c*/
                  std::__shared_weak_count::__release_weak(this: v29); /*0x105720562*/
                }
                if ( (v65 & 1) != 0 ) /*0x10572056b*/
                  operator delete(a1: v66, a2: v27); /*0x105720571*/
                if ( (v61 & 1) != 0 ) /*0x10572057d*/
                  operator delete(a1: (RBX::Memory *)v62, a2: v27); /*0x105720583*/
                v30 = ScriptFromFile == 0; /*0x105720588*/
                v22 = v24; /*0x10572058b*/
                if ( !v30 ) /*0x10572058e*/
                {
                  v31 = v63[0]; /*0x105720594*/
                  std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "ModuleScript", a3: v25, a4: v26); /*0x1057205a2*/
                  isA = RBX::Reflection::DescribedBase::isA(a1: v31, a2: v24); /*0x1057205b2*/
                  if ( (v65 & 1) != 0 ) /*0x1057205b9*/
                    operator delete(a1: v66, a2: v32); /*0x1057205bf*/
                  v34 = v63[0]; /*0x1057205c4*/
                  if ( isA != 0 ) /*0x1057205cb*/
                  {
                    *(_OWORD *)v54 = *(_OWORD *)v55; /*0x1057205db*/
                    if ( v55[1] != nullptr ) /*0x1057205e5*/
                      _InterlockedIncrement64((volatile signed __int64 *)v55[1] + 1); /*0x1057205e7*/
                    RBX::Instance::setParent(a1: v34, a2: v54); /*0x1057205f3*/
                    v35 = v54[1]; /*0x1057205f8*/
                    if ( v54[1] != nullptr /*0x105720614*/
                      && _InterlockedExchangeAdd64((volatile signed __int64 *)v54[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
                    {
                      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v35 + 16LL))(a1: v35); /*0x10572061c*/
                      std::__shared_weak_count::__release_weak(this: v35); /*0x105720622*/
                    }
                  }
                  else
                  {
                    RBX::Instance::setParent(this: v63[0], a2: v58); /*0x105720630*/
                  }
                  (*(void (__fastcall **)(std::__shared_weak_count *, _QWORD))(*(_QWORD *)v63[0] + 224LL))( /*0x10572063e*/
                    a1: v63[0],
                    a2: 0);
                }
                v36 = v63[1]; /*0x105720644*/
                if ( v63[1] != nullptr /*0x10572065d*/
                  && _InterlockedExchangeAdd64((volatile signed __int64 *)v63[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
                {
                  (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v36 + 16LL))(a1: v36); /*0x105720665*/
                  std::__shared_weak_count::__release_weak(this: v36); /*0x10572066b*/
                }
                v30 = v21 + 40 == (char *)v51; /*0x105720679*/
                v21 += 64; /*0x105720680*/
              }
              while ( !v30 ); /*0x105720683*/
            }
            v61 = 0; /*0x10572068c*/
            v62 = nullptr; /*0x105720693*/
            RBX::ContentId::fromAssets(this: (RBX::ContentId *)&v65, a2: "avatar/unification/CollisionHead.rbxm"); /*0x1057206a6*/
            v37 = RBX::safeBlockingLoadInstances(a1: v52, a2: &v65, a3: &v61); /*0x1057206c3*/
            v41 = v58; /*0x1057206c8*/
            v42 = v37; /*0x1057206cf*/
            if ( (BYTE8(v65) & 1) != 0 ) /*0x1057206d6*/
              operator delete(a1: (RBX::Memory *)v67, a2: v40); /*0x1057206dc*/
            if ( v42 != 0 ) /*0x1057206e4*/
            {
              std::string::basic_string[abi:ne200100]<0>( /*0x1057206f5*/
                a1: v63,
                a2: "avatar/unification/AdapterReference.rbxm",
                a3: v38,
                a4: v39);
              if ( ((__int64)v63[0] & 1) != 0 ) /*0x1057206fe*/
                v43 = (const char *)v64; /*0x105720700*/
              else
                v43 = (char *)v63 + 1; /*0x105720706*/
              RBX::ContentId::fromAssets(this: (RBX::ContentId *)&v65, a2: v43); /*0x10572070e*/
              v45 = RBX::safeBlockingLoadInstances(a1: v52, a2: &v65, a3: &v61); /*0x105720726*/
              if ( (BYTE8(v65) & 1) != 0 ) /*0x10572072d*/
                operator delete(a1: (RBX::Memory *)v67, a2: v44); /*0x105720733*/
              if ( v45 != 0 ) /*0x10572073b*/
              {
                FirstChildByName = RBX::Instance::findFirstChildByName(a1: v41, a2: v56, a3: 0); /*0x105720749*/
                v47 = *((RBX::Instance ***)&v61 + 1); /*0x105720755*/
                v48 = (RBX::Instance **)v61; /*0x105720755*/
                if ( (_QWORD)v61 != *((_QWORD *)&v61 + 1) ) /*0x10572075f*/
                {
                  v49 = (RBX::Instance *)FirstChildByName; /*0x105720761*/
                  do /*0x105720784*/
                  {
                    RBX::Instance::setParent(this: *v48, a2: v49); /*0x10572076a*/
                    (*(void (__fastcall **)(RBX::Instance *, _QWORD))(*(_QWORD *)*v48 + 224LL))(a1: *v48, a2: 0); /*0x105720777*/
                    v48 += 2; /*0x10572077d*/
                  }
                  while ( v48 != v47 ); /*0x105720784*/
                }
              }
              if ( ((__int64)v63[0] & 1) != 0 ) /*0x10572078a*/
                operator delete(a1: (RBX::Memory *)v64, a2: v44); /*0x105720790*/
            }
            *(_QWORD *)&v65 = &v61; /*0x105720799*/
            std::vector<std::shared_ptr<RBX::Instance>>::__destroy_vector::operator()[abi:ne200100](a1: (void ***)&v65); /*0x10572079f*/
            *(_QWORD *)&v65 = v59; /*0x1057207ab*/
            std::vector<std::tuple<std::string,std::string,std::shared_ptr<RBX::Instance>>>::__destroy_vector::operator()[abi:ne200100](a1: &v65); /*0x1057207b2*/
            v50 = v55[1]; /*0x1057207b7*/
            if ( v55[1] != nullptr /*0x1057207d7*/
              && _InterlockedExchangeAdd64((volatile signed __int64 *)v55[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
            {
              (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v50 + 16LL))(a1: v50); /*0x1057207e3*/
              std::__shared_weak_count::__release_weak(this: v50); /*0x1057207e9*/
            }
          }
        }
      }
    }
  }
  if ( (v56[0] & 1) != 0 ) /*0x105720367*/
    operator delete(a1: (RBX::Memory *)v57, a2: v7); /*0x105720370*/
}

// Address: 0x105727c4d | Name: __ZN3RBXL39injectDefaultHumanoidStrafingAnimationsEPNS_15ContentProviderENSt3__110shared_ptrINS_13ModelInstanceEEEbb
void __fastcall RBX::injectDefaultHumanoidStrafingAnimations(__int64 a1, __int64 *a2, __int64 a3, __int64 a4)
{
  __int64 v4; // rbx
  __int64 v6; // rdx
  __int64 v7; // rcx
  RBX::Instance *FirstChildByName; // rbx
  void *v9; // rsi
  void *v10; // rsi
  __int64 v11; // r15
  __int64 v12; // rdx
  __int64 v13; // rcx
  void *v14; // rsi
  void *v15; // rsi
  __int64 v16; // r15
  void *v17; // rsi
  RBX::Instance **v18; // r12
  RBX::Instance **i; // r14
  __int128 v20; // [rsp+0h] [rbp-60h] BYREF
  __int64 v21; // [rsp+10h] [rbp-50h]
  void **v22; // [rsp+20h] [rbp-40h] BYREF
  char v23; // [rsp+28h] [rbp-38h]
  void *v24; // [rsp+30h] [rbp-30h]
  void *v25; // [rsp+38h] [rbp-28h]

  v4 = *a2; /*0x105727c5c*/
  if ( *a2 != 0 ) /*0x105727c62*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v22, a2: "Animate", a3, a4); /*0x105727c79*/
    FirstChildByName = (RBX::Instance *)RBX::Instance::findFirstChildByName(a1: v4, a2: &v22, a3: 0); /*0x105727c8b*/
    if ( ((unsigned __int8)v22 & 1) != 0 ) /*0x105727c92*/
      operator delete(a1: (RBX::Memory *)v24, a2: v9); /*0x105727c98*/
    if ( FirstChildByName != nullptr ) /*0x105727ca0*/
    {
      v20 = 0; /*0x105727ca9*/
      v21 = 0; /*0x105727cad*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v22, a2: "walk", a3: v6, a4: v7); /*0x105727cc0*/
      v11 = RBX::Instance::findFirstChildByName(a1: FirstChildByName, a2: &v22, a3: 0); /*0x105727cd3*/
      if ( ((unsigned __int8)v22 & 1) != 0 ) /*0x105727cda*/
        operator delete(a1: (RBX::Memory *)v24, a2: v10); /*0x105727ce0*/
      if ( v11 != 0 ) /*0x105727ce8*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v11 + 280LL))(a1: v11); /*0x105727cf0*/
      RBX::ContentId::fromAssets( /*0x105727d01*/
        this: (RBX::ContentId *)&v22,
        a2: "avatar/scripts/humanoidWalkFamilyWithDiagonals.rbxm");
      RBX::safeBlockingLoadInstances(a1, a2: &v22, a3: &v20); /*0x105727d11*/
      if ( (v23 & 1) != 0 ) /*0x105727d1a*/
        operator delete(a1: (RBX::Memory *)v25, a2: v14); /*0x105727d20*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v22, a2: "run", a3: v12, a4: v13); /*0x105727d30*/
      v16 = RBX::Instance::findFirstChildByName(a1: FirstChildByName, a2: &v22, a3: 0); /*0x105727d43*/
      if ( ((unsigned __int8)v22 & 1) != 0 ) /*0x105727d4a*/
        operator delete(a1: (RBX::Memory *)v24, a2: v15); /*0x105727d50*/
      if ( v16 != 0 ) /*0x105727d58*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v16 + 280LL))(a1: v16); /*0x105727d60*/
      RBX::ContentId::fromAssets(this: (RBX::ContentId *)&v22, a2: "avatar/scripts/humanoidRunFamilyWithDiagonals.rbxm"); /*0x105727d71*/
      RBX::safeBlockingLoadInstances(a1, a2: &v22, a3: &v20); /*0x105727d84*/
      if ( (v23 & 1) != 0 ) /*0x105727d8d*/
        operator delete(a1: (RBX::Memory *)v25, a2: v17); /*0x105727d93*/
      v18 = *((RBX::Instance ***)&v20 + 1); /*0x105727d9c*/
      for ( i = (RBX::Instance **)v20; i != v18; i += 2 ) /*0x105727d9c*/
        RBX::Instance::setParent(this: *i, a2: FirstChildByName); /*0x105727dab*/
      v22 = (void **)&v20; /*0x105727dba*/
      std::vector<std::shared_ptr<RBX::Instance>>::__destroy_vector::operator()[abi:ne200100](a1: &v22); /*0x105727dbd*/
    }
  }
}

// Address: 0x1057915b1 | Name: __ZN3RBX20isPlayerScriptModuleERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
__int64 __fastcall RBX::isPlayerScriptModule(unsigned __int8 *a1)
{
  __int64 v1; // rbx
  char v2; // al
  unsigned __int8 *v3; // rcx
  __int64 v4; // r8
  unsigned __int8 *v5; // r8
  unsigned __int8 *v6; // r11
  unsigned __int8 *v7; // r9
  bool v8; // zf
  void *v9; // rsi
  _BYTE v11[16]; // [rsp+0h] [rbp-90h] BYREF
  void *v12; // [rsp+10h] [rbp-80h]
  _BYTE v13[16]; // [rsp+18h] [rbp-78h] BYREF
  void *v14; // [rsp+28h] [rbp-68h]
  _BYTE v15[16]; // [rsp+30h] [rbp-60h] BYREF
  void *v16; // [rsp+40h] [rbp-50h]
  _BYTE v17[16]; // [rsp+48h] [rbp-48h] BYREF
  void *v18; // [rsp+58h] [rbp-38h]
  __int128 v19; // [rsp+60h] [rbp-30h] BYREF
  void *v20; // [rsp+70h] [rbp-20h]

  v2 = *a1; /*0x1057915be*/
  v3 = a1 + 1; /*0x1057915c1*/
  v4 = *a1 >> 1; /*0x1057915c8*/
  if ( (*a1 & 1) != 0 ) /*0x1057915d1*/
    v3 = *((unsigned __int8 **)a1 + 2); /*0x1057915d1*/
  if ( (v2 & 1) != 0 ) /*0x1057915d9*/
    v4 = *((_QWORD *)a1 + 1); /*0x1057915d9*/
  if ( v4 == 0 ) /*0x1057915e0*/
    goto LABEL_18; /*0x1057915e0*/
  v5 = &v3[v4]; /*0x1057915e2*/
  v6 = v3; /*0x1057915ec*/
  v7 = v5; /*0x1057915ef*/
  do /*0x1057915fe*/
  {
    if ( *v6 == 46 ) /*0x1057915f6*/
    {
      v1 = 1; /*0x105791602*/
      while ( v1 != 7 ) /*0x10579160b*/
      {
        if ( &v6[v1] == v5 ) /*0x105791614*/
          goto LABEL_16; /*0x105791614*/
        v8 = v6[v1] == (unsigned __int8)aModule_0[v1]; /*0x10579161d*/
        ++v1; /*0x105791621*/
        if ( !v8 ) /*0x105791624*/
          goto LABEL_8; /*0x105791624*/
      }
      v7 = v6; /*0x105791628*/
    }
LABEL_8:
    ++v6; /*0x1057915f8*/
  }
  while ( v6 != v5 ); /*0x1057915fe*/
LABEL_16:
  if ( v7 == v5 || (LOBYTE(v1) = 1, v7 - v3 == -1) ) /*0x10579163b*/
  {
LABEL_18:
    if ( (v2 & 1) != 0 ) /*0x105791643*/
    {
      std::string::__init_copy_ctor_external(a1: &v19, a2: *((_QWORD *)a1 + 2), a3: *((_QWORD *)a1 + 1)); /*0x10579165a*/
    }
    else
    {
      v20 = *((void **)a1 + 2); /*0x105791649*/
      v19 = *(_OWORD *)a1; /*0x105791650*/
    }
    if ( (unsigned __int8)boost::filesystem::path::has_parent_path(this: (boost::filesystem::path *)&v19) != 0 ) /*0x10579166a*/
    {
      boost::filesystem::path::parent_path(this: (boost::filesystem::path *)v11, a2: (boost::filesystem::path *)&v19); /*0x10579167b*/
      if ( (unsigned int)boost::filesystem::path::compare( /*0x105791695*/
                           this: (boost::filesystem::path *)v11,
                           a2: "StarterPlayerScripts_old") != 0 )
      {
        boost::filesystem::path::parent_path(this: (boost::filesystem::path *)v13, a2: (boost::filesystem::path *)&v19); /*0x10579169f*/
        if ( (unsigned int)boost::filesystem::path::compare( /*0x1057916b6*/
                             this: (boost::filesystem::path *)v13,
                             a2: "StarterPlayerScripts") != 0 )
        {
          boost::filesystem::path::parent_path( /*0x1057916c0*/
            this: (boost::filesystem::path *)v15,
            a2: (boost::filesystem::path *)&v19);
          if ( (unsigned int)boost::filesystem::path::compare( /*0x1057916d7*/
                               this: (boost::filesystem::path *)v15,
                               a2: "StarterPlayerScriptsCommon") != 0 )
          {
            boost::filesystem::path::parent_path( /*0x1057916e1*/
              this: (boost::filesystem::path *)v17,
              a2: (boost::filesystem::path *)&v19);
            LOBYTE(v1) = (unsigned int)boost::filesystem::path::compare( /*0x1057916f8*/
                                         this: (boost::filesystem::path *)v17,
                                         a2: "StarterCharacterScripts") != 0;
            if ( (v17[0] & 1) != 0 ) /*0x1057916ff*/
              operator delete(a1: (RBX::Memory *)v18, a2: v9); /*0x105791705*/
          }
          else
          {
            LODWORD(v1) = 0; /*0x105791718*/
          }
          if ( (v15[0] & 1) != 0 ) /*0x10579171e*/
            operator delete(a1: (RBX::Memory *)v16, a2: v9); /*0x105791724*/
        }
        else
        {
          LODWORD(v1) = 0; /*0x105791714*/
        }
        if ( (v13[0] & 1) != 0 ) /*0x10579172d*/
          operator delete(a1: (RBX::Memory *)v14, a2: v9); /*0x105791733*/
      }
      else
      {
        LODWORD(v1) = 0; /*0x105791710*/
      }
      if ( (v11[0] & 1) != 0 ) /*0x10579173f*/
        operator delete(a1: (RBX::Memory *)v12, a2: v9); /*0x105791745*/
    }
    else
    {
      LODWORD(v1) = 0; /*0x10579170c*/
    }
    if ( (v19 & 1) != 0 ) /*0x10579174e*/
      operator delete(a1: (RBX::Memory *)v20, a2: v9); /*0x105791754*/
  }
  return (unsigned int)v1; /*0x10579175b*/
}

// Address: 0x1057a435a | Name: __ZN3RBX24isLayeredClothingOptedInENS_28LoadCharacterLayeredClothingE
bool __fastcall RBX::isLayeredClothingOptedIn(int a1)
{
  return (a1 & 0xFFFFFFFD) == 0; /*0x1057a4367*/
}

// Address: 0x1057a4369 | Name: __ZN3RBX20isDynamicHeadOptedInENS_16LoadDynamicHeadsE
bool __fastcall RBX::isDynamicHeadOptedIn(int a1)
{
  return (a1 & 0xFFFFFFFD) == 0; /*0x1057a4376*/
}

// Address: 0x10586b52c | Name: __ZN3RBX24InstanceIsChildOfPlayersEPNS_8InstanceE
bool __fastcall RBX::InstanceIsChildOfPlayers(RBX *this, RBX::Instance *a2)
{
  RBX *v2; // rbx
  __int64 v3; // rax

  v2 = this; /*0x10586b532*/
  v3 = RBX::ServiceProvider::find<RBX::Players>(a1: this); /*0x10586b535*/
  if ( v3 == 0 ) /*0x10586b53d*/
    return false; /*0x10586b53d*/
  do /*0x10586b54b*/
    v2 = *((RBX **)v2 + 13); /*0x10586b53f*/
  while ( v2 != (RBX *)v3 && v2 != nullptr ); /*0x10586b54b*/
  return v2 == (RBX *)v3; /*0x10586b556*/
}

// Address: 0x1058c6308 | Name: __ZN3RBX16isAnimatorHolderEPKNS_8InstanceE
bool __fastcall RBX::isAnimatorHolder(RBX *this, const RBX::Instance *a2)
{
  __int64 v3; // r14
  __int64 v4; // rax
  unsigned int v5; // ecx
  unsigned int v6; // edx
  bool result; // al
  __int64 v8; // rbx
  __int64 v9; // rax

  if ( this == nullptr ) /*0x1058c630b*/
    return false; /*0x1058c6368*/
  v3 = *((_QWORD *)this + 3); /*0x1058c6317*/
  v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::Humanoid>(a1: this); /*0x1058c631b*/
  v5 = *(unsigned __int16 *)(v3 + 440) - *(unsigned __int16 *)(v4 + 440); /*0x1058c632f*/
  v6 = *(unsigned __int16 *)(v4 + 442); /*0x1058c6331*/
  result = true; /*0x1058c6338*/
  if ( v5 > v6 ) /*0x1058c633c*/
  {
    v8 = *((_QWORD *)this + 3); /*0x1058c633e*/
    v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::AnimationController>(); /*0x1058c6342*/
    return *(unsigned __int16 *)(v8 + 440) - (unsigned int)*(unsigned __int16 *)(v9 + 440) <= *(unsigned __int16 *)(v9 + 442); /*0x1058c6360*/
  }
  return result; /*0x1058c6367*/
}

// Address: 0x1058c9c57 | Name: __ZN3RBX25instanceAsAnimatableJointEPNS_8InstanceE
__int64 __fastcall RBX::instanceAsAnimatableJoint(RBX *this, RBX::Instance *a2)
{
  __int64 v3; // r14
  __int64 v4; // rax
  __int64 v5; // rdi
  __int64 v6; // rsi
  RBX *v7; // rax
  __int64 v8; // r14
  __int64 v9; // rax
  __int64 v10; // rdi
  __int64 v11; // r14
  __int64 v12; // rax
  RBX *v13; // rcx
  __int64 result; // rax

  if ( this != nullptr ) /*0x1058c9c61*/
  {
    v3 = *((_QWORD *)this + 3); /*0x1058c9c6a*/
    v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::Motor>(a1: this, a2); /*0x1058c9c6e*/
    if ( *(unsigned __int16 *)(v3 + 440) - (unsigned int)*(unsigned __int16 *)(v4 + 440) <= *(unsigned __int16 *)(v4 + 442) ) /*0x1058c9c8f*/
    {
      v7 = this; /*0x1058c9c8f*/
      return (__int64)v7 + 400; /*0x1058c9cf1*/
    }
    v8 = *((_QWORD *)this + 3); /*0x1058c9c95*/
    v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::Constraints::AnimationConstraint>(a1: v5, a2: v6); /*0x1058c9c99*/
    if ( *(unsigned __int16 *)(v8 + 440) - (unsigned int)*(unsigned __int16 *)(v9 + 440) <= *(unsigned __int16 *)(v9 + 442) ) /*0x1058c9cba*/
    {
      v7 = this; /*0x1058c9cba*/
      return (__int64)v7 + 400; /*0x1058c9cbe*/
    }
    v11 = *((_QWORD *)this + 3); /*0x1058c9cc0*/
    v12 = RBX::Reflection::Class_getDescriptorPtr<RBX::BoneInstance>(a1: v10); /*0x1058c9cc4*/
    v13 = nullptr; /*0x1058c9ce1*/
    if ( *(unsigned __int16 *)(v11 + 440) - (unsigned int)*(unsigned __int16 *)(v12 + 440) <= *(unsigned __int16 *)(v12 + 442) ) /*0x1058c9ce5*/
      v13 = this; /*0x1058c9ce5*/
  }
  else
  {
    v13 = nullptr; /*0x1058c9cf3*/
  }
  result = (__int64)v13 + 440; /*0x1058c9cf5*/
  if ( v13 == nullptr ) /*0x1058c9cff*/
    return 0; /*0x1058c9cff*/
  return result; /*0x1058c9d03*/
}

// Address: 0x1058c9d08 | Name: __ZN3RBX30instanceAsMeshDeformerControlsEPNS_8InstanceE
__int64 __fastcall RBX::instanceAsMeshDeformerControls(RBX *this, RBX::Instance *a2)
{
  __int64 v3; // r14
  __int64 v4; // rax
  RBX *v5; // rcx
  __int64 result; // rax

  if ( this != nullptr ) /*0x1058c9d0b*/
  {
    v3 = *((_QWORD *)this + 3); /*0x1058c9d17*/
    v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::FaceControls>(a1: this, a2); /*0x1058c9d1b*/
    v5 = nullptr; /*0x1058c9d38*/
    if ( *(unsigned __int16 *)(v3 + 440) - (unsigned int)*(unsigned __int16 *)(v4 + 440) <= *(unsigned __int16 *)(v4 + 442) ) /*0x1058c9d3c*/
      v5 = this; /*0x1058c9d3c*/
  }
  else
  {
    v5 = nullptr; /*0x1058c9d46*/
  }
  result = (__int64)v5 + 416; /*0x1058c9d48*/
  if ( v5 == nullptr ) /*0x1058c9d52*/
    return 0; /*0x1058c9d52*/
  return result; /*0x1058c9d56*/
}

// Address: 0x105902402 | Name: __ZN3RBX19isValidHandRigLabelENS_16HumanoidRigLabelE
bool __fastcall RBX::isValidHandRigLabel(int a1)
{
  return (unsigned int)(a1 - 30) < 0xF; /*0x10590240f*/
}

// Address: 0x105908cea | Name: __ZN3RBX19isValidBodyRigLabelENS_16HumanoidRigLabelE
char __fastcall RBX::isValidBodyRigLabel(unsigned int a1)
{
  unsigned int v1; // eax

  if ( a1 - 2 > 0x1B ) /*0x105908cf4*/
  {
    LOBYTE(v1) = 0; /*0x105908d08*/
  }
  else
  {
    LOBYTE(v1) = 1; /*0x105908cf6*/
    if ( a1 <= 0x16 ) /*0x105908cfb*/
      v1 = 0x177BBFu >> a1; /*0x105908d04*/
  }
  return v1 & 1; /*0x105908d0c*/
}

// Address: 0x105913afc | Name: __ZN3RBX19isJointDescendantOfERKNS_9TransformES2_
__int64 __fastcall RBX::isJointDescendantOf(RBX *this, const RBX::Transform *a2, const RBX::Transform *a3)
{
  __int128 v3; // xmm0
  __int128 v4; // xmm1
  __int64 v5; // rax
  __int64 v6; // rax
  __int128 v7; // xmm0
  __int128 v8; // xmm1
  __int128 v9; // xmm2
  int v10; // r13d
  _BYTE *v11; // rbx
  __int128 v12; // xmm0
  std::__shared_weak_count *v13; // rdi
  __int128 v14; // xmm0
  std::__shared_weak_count *v15; // rdi
  _QWORD v17[7]; // [rsp+0h] [rbp-1B0h] BYREF
  __int128 v18; // [rsp+38h] [rbp-178h]
  int v19; // [rsp+48h] [rbp-168h]
  __int128 v20; // [rsp+50h] [rbp-160h]
  _BYTE v21[96]; // [rsp+60h] [rbp-150h] BYREF
  _QWORD v22[7]; // [rsp+C0h] [rbp-F0h] BYREF
  std::__shared_weak_count *v23[2]; // [rsp+F8h] [rbp-B8h]
  int v24; // [rsp+108h] [rbp-A8h]
  std::__shared_weak_count *v25[2]; // [rsp+110h] [rbp-A0h]
  _QWORD v26[12]; // [rsp+120h] [rbp-90h]
  const RBX::Transform *v27; // [rsp+180h] [rbp-30h]

  v27 = a2; /*0x105913b10*/
  v22[6] = *((_QWORD *)this + 6); /*0x105913b18*/
  v3 = *(_OWORD *)this; /*0x105913b1f*/
  v4 = *((_OWORD *)this + 1); /*0x105913b22*/
  *(_OWORD *)&v22[4] = *((_OWORD *)this + 2); /*0x105913b2a*/
  *(_OWORD *)&v22[2] = v4; /*0x105913b31*/
  *(_OWORD *)v22 = v3; /*0x105913b38*/
  v5 = *((_QWORD *)this + 8); /*0x105913b3f*/
  *(_OWORD *)v23 = *(_OWORD *)((char *)this + 56); /*0x105913b47*/
  if ( v5 != 0 ) /*0x105913b51*/
    _InterlockedIncrement64((volatile signed __int64 *)(v5 + 16)); /*0x105913b53*/
  v24 = *((_DWORD *)this + 18); /*0x105913b5b*/
  v6 = *((_QWORD *)this + 11); /*0x105913b61*/
  *(_OWORD *)v25 = *((_OWORD *)this + 5); /*0x105913b69*/
  if ( v6 != 0 ) /*0x105913b73*/
    _InterlockedIncrement64((volatile signed __int64 *)(v6 + 16)); /*0x105913b75*/
  *(_OWORD *)&v26[10] = *((_OWORD *)this + 11); /*0x105913b88*/
  *(_OWORD *)&v26[8] = *((_OWORD *)this + 10); /*0x105913b95*/
  v7 = *((_OWORD *)this + 6); /*0x105913b9b*/
  v8 = *((_OWORD *)this + 7); /*0x105913b9f*/
  v9 = *((_OWORD *)this + 8); /*0x105913ba3*/
  *(_OWORD *)&v26[6] = *((_OWORD *)this + 9); /*0x105913bb1*/
  *(_OWORD *)&v26[4] = v9; /*0x105913bb7*/
  *(_OWORD *)&v26[2] = v8; /*0x105913bbd*/
  *(_OWORD *)v26 = v7; /*0x105913bc3*/
  v10 = 0; /*0x105913bc8*/
  v11 = v21; /*0x105913bcb*/
  while ( 1 ) /*0x105913be0*/
  {
    if ( (unsigned __int8)RBX::Transform::operator bool(a1: v22) == 0 ) /*0x105913bea*/
    {
LABEL_20:
      LODWORD(v11) = 0; /*0x105913d13*/
      goto LABEL_22; /*0x105913d15*/
    }
    if ( DFFlag::IkControlFixHierarchyTraversal == 1 ) /*0x105913bf7*/
    {
      if ( v10 > 255 ) /*0x105913c00*/
        goto LABEL_20; /*0x105913c00*/
      ++v10; /*0x105913c06*/
    }
    if ( (unsigned __int8)RBX::Transform::operator==(a1: v22, a2: v27) != 0 ) /*0x105913c17*/
      break; /*0x105913c17*/
    RBX::Transform::getParent(this: (RBX::Transform *)v17); /*0x105913c23*/
    qmemcpy(v22, v17, sizeof(v22)); /*0x105913c2f*/
    v12 = v18; /*0x105913c60*/
    if ( *((_QWORD *)&v18 + 1) != 0 ) /*0x105913c71*/
      _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v18 + 1) + 16LL)); /*0x105913c73*/
    v13 = v23[1]; /*0x105913c78*/
    *(_OWORD *)v23 = v12; /*0x105913c7f*/
    if ( v13 != nullptr ) /*0x105913c89*/
      std::__shared_weak_count::__release_weak(this: v13); /*0x105913c8b*/
    v24 = v19; /*0x105913c96*/
    v14 = v20; /*0x105913c9c*/
    if ( *((_QWORD *)&v20 + 1) != 0 ) /*0x105913cad*/
      _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v20 + 1) + 16LL)); /*0x105913caf*/
    v15 = v25[1]; /*0x105913cb4*/
    *(_OWORD *)v25 = v14; /*0x105913cbb*/
    if ( v15 != nullptr ) /*0x105913cc5*/
      std::__shared_weak_count::__release_weak(this: v15); /*0x105913cc7*/
    qmemcpy(v26, v21, sizeof(v26)); /*0x105913cd0*/
    RBX::Transform::~Transform(this: (RBX::Transform *)v17); /*0x105913d09*/
  }
  LOBYTE(v11) = 1; /*0x105913d17*/
LABEL_22:
  RBX::Transform::~Transform(this: (RBX::Transform *)v22); /*0x105913d19*/
  return (unsigned int)v11; /*0x105913d27*/
}

// Address: 0x1059354a0 | Name: __ZN3RBX15isContainerPoseEPNS_10CFramePoseE
bool __fastcall RBX::isContainerPose(RBX *this, RBX::CFramePose *a2)
{
  __int64 v3; // rax
  __int64 v4; // r14
  __int64 v5; // rax
  bool v6; // cl
  float v7; // xmm0_4
  bool result; // al

  v3 = *((_QWORD *)this + 13); /*0x1059354aa*/
  if ( v3 != 0 ) /*0x1059354b1*/
  {
    v4 = *(_QWORD *)(v3 + 24); /*0x1059354b3*/
    v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::CFramePose>(a1: this); /*0x1059354b7*/
    v6 = *(unsigned __int16 *)(v4 + 440) - (unsigned int)*(unsigned __int16 *)(v5 + 440) > *(unsigned __int16 *)(v5 + 442); /*0x1059354d6*/
  }
  else
  {
    v6 = true; /*0x1059354db*/
  }
  v7 = *((float *)this + 48); /*0x1059354dd*/
  result = v7 <= 0.000001; /*0x1059354ec*/
  if ( FFlag::RootMotionSupportedInternal == 0 ) /*0x1059354f9*/
    return v7 <= 0.000001 || v6; /*0x105935507*/
  return result; /*0x105935509*/
}

// Address: 0x10593550e | Name: __ZN3RBX15isContainerPoseEPNS_8PoseBaseE
char __fastcall RBX::isContainerPose(RBX *this, RBX::PoseBase *a2)
{
  __int64 v3; // r14
  __int64 v4; // r15
  __int64 v5; // rax
  __int64 v6; // rdi
  __int64 v7; // rsi
  __int64 v8; // r15
  __int64 v9; // rax
  __int64 v10; // rdi
  __int64 v11; // r14
  __int64 v12; // rax
  bool v13; // al
  bool v14; // cl
  char v15; // al

  if ( this != nullptr ) /*0x10593551b*/
  {
    v3 = *((_QWORD *)this + 13); /*0x105935524*/
    if ( v3 != 0 /*0x105935575*/
      && (v4 = *(_QWORD *)(v3 + 24),
          v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::CFramePose>(a1: this),
          *(unsigned __int16 *)(v4 + 440) - (unsigned int)*(unsigned __int16 *)(v5 + 440) > *(unsigned __int16 *)(v5 + 442))
      && (v8 = *(_QWORD *)(v3 + 24),
          v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::DoublePose>(a1: v6, a2: v7),
          *(unsigned __int16 *)(v8 + 440) - (unsigned int)*(unsigned __int16 *)(v9 + 440) > *(unsigned __int16 *)(v9 + 442)) )
    {
      v11 = *(_QWORD *)(v3 + 24); /*0x105935577*/
      v12 = RBX::Reflection::Class_getDescriptorPtr<RBX::Folder>(a1: v10); /*0x10593557b*/
      v13 = *(unsigned __int16 *)(v11 + 440) - (unsigned int)*(unsigned __int16 *)(v12 + 440) > *(unsigned __int16 *)(v12 + 442); /*0x10593559a*/
    }
    else
    {
      v13 = false; /*0x10593559f*/
    }
    v14 = *((float *)this + 48) <= 0.000001; /*0x1059355b0*/
    v15 = v14 || v13; /*0x1059355b3*/
  }
  else
  {
    v15 = 1; /*0x1059355b7*/
    v14 = true; /*0x1059355b9*/
  }
  if ( FFlag::RootMotionSupportedInternal != 0 ) /*0x1059355cb*/
    v15 = v14; /*0x1059355cb*/
  return v15 & 1; /*0x1059355d4*/
}

// Address: 0x105a99aa8 | Name: __ZN3RBX36isDynamicHeadWhichSupportsHeadShapesEx
__int64 __fastcall RBX::isDynamicHeadWhichSupportsHeadShapes(RBX *this, __int64 a2)
{
  __int64 *v2; // rbx
  size_t v3; // rdx
  __int64 v4; // rsi
  char *v5; // rdi
  const void *v6; // rsi
  char *v7; // rcx
  __int64 v8; // rax
  void *v9; // rsi
  __int64 *v10; // r13
  __int64 v11; // rax
  int v12; // edx
  _QWORD v14[2]; // [rsp+0h] [rbp-60h] BYREF
  __int64 v15; // [rsp+10h] [rbp-50h] BYREF
  __int64 v16; // [rsp+18h] [rbp-48h] BYREF
  void *v17[2]; // [rsp+20h] [rbp-40h] BYREF
  __int64 v18; // [rsp+30h] [rbp-30h]

  v15 = (__int64)this; /*0x105a99ab9*/
  if ( (_BYTE)`guard variable for'RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::set == 0 ) /*0x105a99ac5*/
    RBX::isDynamicHeadWhichSupportsHeadShapes(this, a2); /*0x105a99c84*/
  if ( (_BYTE)`guard variable for'RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting == 0 ) /*0x105a99ad3*/
    RBX::isDynamicHeadWhichSupportsHeadShapes(this, a2); /*0x105a99c8e*/
  if ( (_BYTE)`guard variable for'RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::mx == 0 ) /*0x105a99ae1*/
    RBX::isDynamicHeadWhichSupportsHeadShapes(this, a2); /*0x105a99c98*/
  std::mutex::lock(this: (std::mutex *)&RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::mx); /*0x105a99aee*/
  if ( (RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting & 1) != 0 ) /*0x105a99afc*/
    v3 = *((_QWORD *)&RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting + 1); /*0x105a99afe*/
  else
    v3 = (unsigned __int8)RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting >> 1; /*0x105a99b09*/
  if ( (DFString::DynamicHeadsWithHeadshapesAssetIds & 1) != 0 ) /*0x105a99b15*/
    v4 = qword_10D7FBFB8; /*0x105a99b17*/
  else
    v4 = (unsigned __int8)DFString::DynamicHeadsWithHeadshapesAssetIds >> 1; /*0x105a99b22*/
  if ( v3 != v4
    || ((RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting & 1) == 0
      ? (v5 = (char *)&RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting + 1)
      : (v5 = (char *)qword_10D463CB0),
        (DFString::DynamicHeadsWithHeadshapesAssetIds & 1) == 0
      ? (v6 = &unk_10D7FBFB1)
      : (v6 = (const void *)qword_10D7FBFC0),
        memcmp(__s1: v5, __s2: v6, __n: v3) != 0) )
  {
    std::string::operator=( /*0x105a99b6d*/
      a1: &RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting,
      a2: &DFString::DynamicHeadsWithHeadshapesAssetIds);
    RBX::details::SplitHashTable<long long,long long,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<long long>,RBX::details::DefaultEqualTo<long long>,RBX::details::GetSelfKey<long long>>::clear(a1: &RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::set); /*0x105a99b79*/
    *(_OWORD *)v17 = 0; /*0x105a99b81*/
    v18 = 0; /*0x105a99b85*/
    if ( (RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting & 1) != 0 ) /*0x105a99b96*/
    {
      v7 = (char *)qword_10D463CB0; /*0x105a99b98*/
      v8 = *((_QWORD *)&RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting + 1); /*0x105a99b9f*/
    }
    else
    {
      v7 = (char *)&RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting + 1; /*0x105a99ba8*/
      v8 = (unsigned __int8)RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting >> 1; /*0x105a99baf*/
    }
    v14[0] = v7; /*0x105a99bb5*/
    v14[1] = v8; /*0x105a99bb8*/
    RBX::detail::StringViewBase::split(a1: v14, a2: v17, a3: ";", a4: 1, a5: 0xFFFFFFFFLL, a6: 0); /*0x105a99bd5*/
    v2 = (__int64 *)v17[0]; /*0x105a99bda*/
    v10 = (__int64 *)v17[1]; /*0x105a99bde*/
    if ( v17[0] != v17[1] ) /*0x105a99be5*/
    {
      do /*0x105a99c33*/
      {
        v16 = -1; /*0x105a99bf6*/
        if ( RBX::getAsSignedInteger(a1: *v2, a2: v2[1], a3: 0xAu, a4: v14) != 0 ) /*0x105a99c14*/
        {
          v16 = v14[0]; /*0x105a99c1a*/
          RBX::details::SplitHashTable<long long,long long,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<long long>,RBX::details::DefaultEqualTo<long long>,RBX::details::GetSelfKey<long long>>::emplace<long long,long long const&>( /*0x105a99c27*/
            a1: &RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::set,
            a2: &v16,
            a3: &v16);
        }
        v2 += 2; /*0x105a99c2c*/
      }
      while ( v2 != v10 ); /*0x105a99c33*/
      v2 = (__int64 *)v17[0]; /*0x105a99c35*/
    }
    if ( v2 != nullptr ) /*0x105a99c3c*/
    {
      v17[1] = v2; /*0x105a99c3e*/
      operator delete(a1: (RBX::Memory *)v2, a2: v9); /*0x105a99c45*/
    }
  }
  v11 = RBX::details::SplitHashTable<long long,long long,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<long long>,RBX::details::DefaultEqualTo<long long>,RBX::details::GetSelfKey<long long>>::find_as<long long>( /*0x105a99c55*/
          a1: &RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::set,
          a2: &v15);
  LOBYTE(v2) = v11 != 0 || v12 != 0; /*0x105a99c65*/
  std::mutex::unlock(this: (std::mutex *)&RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::mx); /*0x105a99c6e*/
  return (unsigned int)v2; /*0x105a99c75*/
}

// Address: 0x105a9ebb3 | Name: __ZN3RBX20isBodyPartAttachmentERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
bool __fastcall RBX::isBodyPartAttachment(__int64 a1)
{
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // rdx
  __int64 v12; // rcx
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rdx
  __int64 v18; // rcx
  __int64 v19; // rdx
  __int64 v20; // rcx
  __int64 v21; // rdx
  __int64 v22; // rcx
  __int64 v23; // rdx
  __int64 v24; // rcx
  __int64 v25; // rdx
  __int64 v26; // rcx
  __int64 v27; // rdx
  __int64 v28; // rcx
  __int64 v29; // rdx
  __int64 v30; // rcx
  __int64 v31; // rdx
  __int64 v32; // rcx
  __int64 v33; // rdx
  __int64 v34; // rcx
  __int64 v35; // rdx
  __int64 v36; // rcx
  __int64 v37; // rdx
  __int64 v38; // rcx
  void *v39; // rsi
  __int64 i; // r14
  _BYTE v41[16]; // [rsp+0h] [rbp-1E0h]
  _BYTE v43[24]; // [rsp+18h] [rbp-1C8h] BYREF
  _BYTE v44[24]; // [rsp+30h] [rbp-1B0h] BYREF
  _BYTE v45[24]; // [rsp+48h] [rbp-198h] BYREF
  _BYTE v46[24]; // [rsp+60h] [rbp-180h] BYREF
  _BYTE v47[24]; // [rsp+78h] [rbp-168h] BYREF
  _BYTE v48[24]; // [rsp+90h] [rbp-150h] BYREF
  _BYTE v49[24]; // [rsp+A8h] [rbp-138h] BYREF
  _BYTE v50[24]; // [rsp+C0h] [rbp-120h] BYREF
  _BYTE v51[24]; // [rsp+D8h] [rbp-108h] BYREF
  _BYTE v52[24]; // [rsp+F0h] [rbp-F0h] BYREF
  _BYTE v53[24]; // [rsp+108h] [rbp-D8h] BYREF
  _BYTE v54[24]; // [rsp+120h] [rbp-C0h] BYREF
  _BYTE v55[24]; // [rsp+138h] [rbp-A8h] BYREF
  _BYTE v56[24]; // [rsp+150h] [rbp-90h] BYREF
  _BYTE v57[24]; // [rsp+168h] [rbp-78h] BYREF
  _BYTE v58[24]; // [rsp+180h] [rbp-60h] BYREF
  _BYTE v59[24]; // [rsp+198h] [rbp-48h] BYREF
  _BYTE v60[24]; // [rsp+1B0h] [rbp-30h] BYREF

  if ( (_BYTE)`guard variable for'RBX::isBodyPartAttachment(std::string const&)::attachmentNames == 0 /*0x105a9ec1f*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::isBodyPartAttachment(std::string const&)::attachmentNames) != 0 )
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v43, a2: "HatAttachment", a3: v3, a4: v4); /*0x105a9ec2f*/
    std::string::basic_string[abi:ne200100]<0>(a1: v44, a2: "HairAttachment", a3: v5, a4: v6); /*0x105a9ec45*/
    std::string::basic_string[abi:ne200100]<0>(a1: v45, a2: "FaceCenterAttachment", a3: v7, a4: v8); /*0x105a9ec5b*/
    std::string::basic_string[abi:ne200100]<0>(a1: v46, a2: "FaceFrontAttachment", a3: v9, a4: v10); /*0x105a9ec71*/
    std::string::basic_string[abi:ne200100]<0>(a1: v47, a2: "NeckAttachment", a3: v11, a4: v12); /*0x105a9ec87*/
    std::string::basic_string[abi:ne200100]<0>(a1: v48, a2: "BodyFrontAttachment", a3: v13, a4: v14); /*0x105a9ec9d*/
    std::string::basic_string[abi:ne200100]<0>(a1: v49, a2: "BodyBackAttachment", a3: v15, a4: v16); /*0x105a9ecb3*/
    std::string::basic_string[abi:ne200100]<0>(a1: v50, a2: "LeftShoulderAttachment", a3: v17, a4: v18); /*0x105a9ecc9*/
    std::string::basic_string[abi:ne200100]<0>(a1: v51, a2: "RightShoulderAttachment", a3: v19, a4: v20); /*0x105a9ecdf*/
    std::string::basic_string[abi:ne200100]<0>(a1: v52, a2: "LeftCollarAttachment", a3: v21, a4: v22); /*0x105a9ecf5*/
    std::string::basic_string[abi:ne200100]<0>(a1: v53, a2: "RightCollarAttachment", a3: v23, a4: v24); /*0x105a9ed0b*/
    std::string::basic_string[abi:ne200100]<0>(a1: v54, a2: "WaistFrontAttachment", a3: v25, a4: v26); /*0x105a9ed21*/
    std::string::basic_string[abi:ne200100]<0>(a1: v55, a2: "WaistCenterAttachment", a3: v27, a4: v28); /*0x105a9ed37*/
    std::string::basic_string[abi:ne200100]<0>(a1: v56, a2: "WaistBackAttachment", a3: v29, a4: v30); /*0x105a9ed4d*/
    std::string::basic_string[abi:ne200100]<0>(a1: v57, a2: "LeftGripAttachment", a3: v31, a4: v32); /*0x105a9ed60*/
    std::string::basic_string[abi:ne200100]<0>(a1: v58, a2: "RightGripAttachment", a3: v33, a4: v34); /*0x105a9ed73*/
    std::string::basic_string[abi:ne200100]<0>(a1: v59, a2: "LeftFootAttachment", a3: v35, a4: v36); /*0x105a9ed86*/
    std::string::basic_string[abi:ne200100]<0>(a1: v60, a2: "RightFootAttachment", a3: v37, a4: v38); /*0x105a9ed99*/
    std::unordered_set<std::string>::unordered_set( /*0x105a9edb1*/
      a1: &RBX::isBodyPartAttachment(std::string const&)::attachmentNames,
      a2: v43,
      a3: 18);
    for ( i = 432; i != 0; i -= 24 ) /*0x105a9edb6*/
    {
      if ( (v41[i] & 1) != 0 ) /*0x105a9edc5*/
        operator delete(a1: *(RBX::Memory **)&v43[i - 8], a2: v39); /*0x105a9edcf*/
    }
    __cxa_atexit( /*0x105a9edef*/
      lpfunc: std::unordered_set<std::string>::~unordered_set[abi:ne200100],
      obj: &RBX::isBodyPartAttachment(std::string const&)::attachmentNames,
      lpdso_handle: (void *)&_mh_execute_header);
    __cxa_guard_release(a1: &`guard variable for'RBX::isBodyPartAttachment(std::string const&)::attachmentNames); /*0x105a9edfb*/
  }
  return std::__hash_table<std::string,std::hash<std::string>,std::equal_to<std::string>,std::allocator<std::string>>::find<std::string>( /*0x105a9ec05*/
           a1: &RBX::isBodyPartAttachment(std::string const&)::attachmentNames,
           a2: a1) != 0;
}

// Address: 0x105ab0691 | Name: __ZN3RBXL20isWrapDeformablePartEPNS_8BasePartE
bool __fastcall RBX::isWrapDeformablePart(RBX *this, RBX::BasePart *a2, __int64 a3)
{
  __int64 v4; // r14
  __int64 v5; // rax

  if ( this == nullptr ) /*0x105ab0694*/
    return false; /*0x105ab06c9*/
  v4 = *((_QWORD *)this + 3); /*0x105ab06a0*/
  v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::MeshPart>(a1: this, a2, a3); /*0x105ab06a4*/
  return *(unsigned __int16 *)(v4 + 440) - (unsigned int)*(unsigned __int16 *)(v5 + 440) <= *(unsigned __int16 *)(v5 + 442) /*0x105ab06cb*/
      && RBX::Instance::findConstFirstChildOfType<RBX::WrapLayer>(a1: this) != 0;
}

// Address: 0x105ac6fa3 | Name: __ZN3RBX28isFloorMovementInsignificantERKNS_15CoordinateFrameES2_RKNS_8VelocityES5_f
__int64 __fastcall RBX::isFloorMovementInsignificant(
        RBX *this,
        const RBX::CoordinateFrame *a2,
        __m128 *a3,
        __m128 *a4,
        const RBX::Velocity *a5,
        float a6)
{
  unsigned int v6; // ebx
  float v7; // xmm0_4
  __m128 v8; // xmm1
  __m128 v9; // xmm1
  __m128 v10; // xmm1
  __m128 v11; // xmm1
  __m128 v12; // xmm2
  __m128 v13; // xmm2

  v6 = 0; /*0x105ac6fa9*/
  if ( a6 < 0.000001 ) /*0x105ac6fb6*/
  {
    v7 = *((float *)this + 10) - *((float *)a2 + 10); /*0x105ac6fc1*/
    v8 = _mm_sub_ps( /*0x105ac6fe2*/
           _mm_insert_ps((__m128)*((unsigned int *)this + 9), (__m128)*((unsigned int *)this + 11), 16),
           _mm_insert_ps((__m128)*((unsigned int *)a2 + 9), (__m128)*((unsigned int *)a2 + 11), 16));
    v9 = _mm_mul_ps(v8, v8); /*0x105ac6fe5*/
    if ( (float)(_mm_movehdup_ps(v9).f32[0] + (float)((float)(v7 * v7) + v9.f32[0])) < 1.0e-12 ) /*0x105ac6fff*/
    {
      v10 = _mm_sub_ps(_mm_insert_ps(*a3, (__m128)a3->u32[2], 16), _mm_insert_ps(*a4, (__m128)a4->u32[2], 16)); /*0x105ac7027*/
      v11 = _mm_mul_ps(v10, v10); /*0x105ac702a*/
      if ( (float)(_mm_movehdup_ps(v11).f32[0] /*0x105ac703c*/
                 + (float)((float)((float)(a3->f32[1] - a4->f32[1]) * (float)(a3->f32[1] - a4->f32[1])) + v11.f32[0])) >= 1.0e-12 )
        return 0; /*0x105ac703c*/
      v12 = _mm_sub_ps( /*0x105ac7064*/
              _mm_insert_ps((__m128)a3->u32[3], (__m128)a3[1].u32[1], 16),
              _mm_insert_ps((__m128)a4->u32[3], (__m128)a4[1].u32[1], 16));
      v13 = _mm_mul_ps(v12, v12); /*0x105ac7067*/
      if ( (float)(_mm_movehdup_ps(v13).f32[0] /*0x105ac7079*/
                 + (float)((float)((float)(a3[1].f32[0] - a4[1].f32[0]) * (float)(a3[1].f32[0] - a4[1].f32[0]))
                         + v13.f32[0])) >= 1.0e-12 )
      {
        return 0; /*0x105ac70b1*/
      }
      else
      {
        LOBYTE(v6) = 1; /*0x105ac7097*/
        if ( (unsigned __int8)FLog::HumanoidFloorProcess >= 6u && BYTE1(FLog::HumanoidFloorProcess) >= 3u ) /*0x105ac7094*/
          FLog::FastLog( /*0x105ac70aa*/
            a1: *(_QWORD *)&FLog::HumanoidFloorProcess,
            a2: qword_10D7FC968,
            a3: "[FLog::HumanoidFloorProcess] Floor Movement too small",
            0,
            a5);
      }
    }
  }
  return v6; /*0x105ac70b9*/
}

// Address: 0x105baf6f4 | Name: __ZN3RBXL20isAvatarRulesManagedEPKNS_9AnimationE
__int64 __fastcall RBX::isAvatarRulesManaged(RBX *this, const RBX::Animation *a2)
{
  __int64 v2; // rbx
  __int64 v3; // rdi
  __int64 v4; // rdi
  __int64 v5; // rbx
  const char *v6; // rsi
  __int64 v8; // [rsp+0h] [rbp-60h] BYREF
  __int64 v9; // [rsp+8h] [rbp-58h]
  _BYTE v10[64]; // [rsp+10h] [rbp-50h] BYREF

  RBX::Instance::getAttribute(this: (RBX::Instance *)&v8, a2: (const char *)this); /*0x105baf719*/
  v2 = v8; /*0x105baf71e*/
  if ( RBX::Reflection::Type::getSingleton<bool>(a1: v3) == v2 ) /*0x105baf72a*/
  {
    v5 = v8; /*0x105baf730*/
    if ( RBX::Reflection::Type::getSingleton<bool>(a1: v4) != v5 ) /*0x105baf73c*/
      RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v6); /*0x105baf778*/
    LOBYTE(v5) = v10[0]; /*0x105baf73e*/
  }
  else
  {
    LODWORD(v5) = 0; /*0x105baf72c*/
  }
  if ( v9 != 0 ) /*0x105baf748*/
    (*(void (__fastcall **)(_BYTE *))(v9 + 16))(a1: v10); /*0x105baf74e*/
  return (unsigned int)v5; /*0x105baf763*/
}

// Address: 0x105bc70f8 | Name: __ZN3RBXL25invokeLuaCallbackInternalENSt3__18weak_ptrINS_32AnimationFromVideoCreatorServiceEEENS_3Lua13WeakObjectRefENS_10Reflection5TupleE
__int64 __fastcall RBX::invokeLuaCallbackInternal(__int64 a1, RBX::ServiceProvider **a2, __int64 a3, __int64 a4)
{
  std::__shared_weak_count *v8; // rdi
  std::__shared_weak_count *v9; // rax
  RBX::ServiceProvider *v10; // r13
  const RBX::Instance *v11; // rsi
  volatile signed __int64 *v12; // r12
  RBX::ServiceProvider *ServiceProvider; // rax
  __int64 v14; // rax
  std::__shared_weak_count *v15; // r14
  volatile signed __int64 *v16; // r12
  std::__shared_weak_count *v18; // [rsp+10h] [rbp-50h]
  std::__shared_weak_count *v19; // [rsp+20h] [rbp-40h]
  __int64 v20; // [rsp+28h] [rbp-38h] BYREF
  std::__shared_weak_count *v21; // [rsp+30h] [rbp-30h]

  RBX::make_shared<RBX::Reflection::Tuple const>(); /*0x105bc7115*/
  v8 = a2[1]; /*0x105bc711a*/
  if ( v8 == nullptr ) /*0x105bc7121*/
    return a1; /*0x105bc7121*/
  v9 = (std::__shared_weak_count *)std::__shared_weak_count::lock(this: v8); /*0x105bc7127*/
  v18 = v9; /*0x105bc712c*/
  if ( v9 == nullptr ) /*0x105bc7133*/
    return a1; /*0x105bc7133*/
  v10 = *a2; /*0x105bc7139*/
  if ( v10 == nullptr ) /*0x105bc7144*/
  {
    v16 = (volatile signed __int64 *)v9; /*0x105bc7212*/
LABEL_18:
    if ( _InterlockedExchangeAdd64(v16 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x105bc7226*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v16 + 16))(a1: v16); /*0x105bc722f*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v16); /*0x105bc7235*/
    }
    return a1; /*0x105bc7235*/
  }
  RBX::Lua::WeakThreadRef::getLiveLuaRef(this: (RBX::Lua::WeakThreadRef *)&v20); /*0x105bc7151*/
  v12 = (volatile signed __int64 *)v21; /*0x105bc715a*/
  v19 = v21; /*0x105bc7162*/
  if ( v20 != 0 ) /*0x105bc7169*/
  {
    if ( *(_QWORD *)(v20 + 40) != 0 ) /*0x105bc7170*/
    {
      ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v10, a2: v11); /*0x105bc7175*/
      if ( ServiceProvider != nullptr ) /*0x105bc717d*/
      {
        v14 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::ScriptContext>(this: ServiceProvider); /*0x105bc7182*/
        if ( v14 != 0 ) /*0x105bc718a*/
        {
          RBX::ScriptContext::callInNewThread(a1: &v20, a2: v14, a3, a4); /*0x105bc7199*/
          std::shared_ptr<RBX::Reflection::Tuple const>::operator=[abi:ne200100](a1, a2: &v20); /*0x105bc71a8*/
          v15 = v21; /*0x105bc71ad*/
          if ( v21 != nullptr /*0x105bc71c6*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v21 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x105bc71ce*/
            std::__shared_weak_count::__release_weak(this: v15); /*0x105bc71d4*/
          }
        }
      }
    }
    v12 = (volatile signed __int64 *)v19; /*0x105bc71d9*/
  }
  if ( v12 != nullptr && _InterlockedExchangeAdd64(v12 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x105bc71f3*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v12 + 16))(a1: v12); /*0x105bc71fc*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v12); /*0x105bc7202*/
  }
  v16 = (volatile signed __int64 *)v18; /*0x105bc7207*/
  if ( v18 != nullptr ) /*0x105bc720e*/
    goto LABEL_18; /*0x105bc720e*/
  return a1; /*0x105bc723d*/
}

// Address: 0x105c307b2 | Name: __ZN3RBXL33invokeCallbackIfPostResponseErrorERKNS_16PromptCreateInfoERNS_12HttpResponseERKNSt3__18functionIFvNS5_10shared_ptrIKNS_10Reflection5TupleEEEEEENS_5TimerILNS_4Time12SampleMethodE0EEENS5_8optionalINS_15AvatarAssetTypeEEE
__int64 __fastcall RBX::invokeCallbackIfPostResponseError(__int64 a1, __int64 a2, __int64 a3, __int64 a4, double a5)
{
  __int64 v8; // rax
  char v9; // dl
  char v10; // dl
  char v11; // dl
  char v12; // dl
  void *v13; // rsi
  _BYTE *v14; // rax
  __int64 v15; // r13
  __int64 v17; // rax
  __int64 v18; // r12
  char *v19; // rcx
  __int64 v20; // rax
  int v21; // edx
  int v22; // eax
  char v23; // r13
  __int64 v24; // rcx
  void *v25; // r12
  __int64 v26; // rdx
  __int64 v27; // rdi
  __int64 v28; // rdx
  __int64 v29; // rcx
  __int64 v30; // rdx
  __int64 v31; // rcx
  __int64 v32; // rdx
  __int64 v33; // rcx
  void *v34; // rsi
  __int64 v35; // r15
  unsigned int v36; // r15d
  __int64 v37; // rdi
  __int64 v38; // rdx
  __int64 v39; // rcx
  __int64 v40; // rdx
  __int64 v41; // rcx
  __int64 v42; // rdx
  __int64 v43; // rcx
  void *v44; // rsi
  _BYTE v45[32]; // [rsp+0h] [rbp-190h] BYREF
  __int128 v46; // [rsp+20h] [rbp-170h] BYREF
  void *v47; // [rsp+30h] [rbp-160h]
  char v48; // [rsp+40h] [rbp-150h]
  _BYTE v49[23]; // [rsp+41h] [rbp-14Fh]
  int v50; // [rsp+58h] [rbp-138h]
  char v51; // [rsp+5Ch] [rbp-134h]
  __int128 v52; // [rsp+90h] [rbp-100h] BYREF
  void *v53; // [rsp+A0h] [rbp-F0h]
  double v54; // [rsp+A8h] [rbp-E8h]
  __int64 v55; // [rsp+B0h] [rbp-E0h] BYREF
  __int64 v56; // [rsp+B8h] [rbp-D8h]
  void *v57; // [rsp+C0h] [rbp-D0h]
  _BYTE v58[16]; // [rsp+C8h] [rbp-C8h] BYREF
  void *v59; // [rsp+D8h] [rbp-B8h]
  _BYTE v60[16]; // [rsp+E0h] [rbp-B0h] BYREF
  void *v61; // [rsp+F0h] [rbp-A0h]
  _BYTE v62[16]; // [rsp+F8h] [rbp-98h] BYREF
  void *v63; // [rsp+108h] [rbp-88h]
  __int64 v64; // [rsp+110h] [rbp-80h] BYREF
  __int64 v65; // [rsp+118h] [rbp-78h]
  void *v66; // [rsp+120h] [rbp-70h]
  double v67; // [rsp+128h] [rbp-68h]
  __int128 v68; // [rsp+130h] [rbp-60h] BYREF
  void *v69; // [rsp+140h] [rbp-50h]
  _QWORD v70[2]; // [rsp+150h] [rbp-40h]

  v54 = a5; /*0x105c307c9*/
  v8 = RBX::WrapperHttpBuf::operator RBX::StringView(a1: a2 + 72); /*0x105c307e9*/
  RBX::json::parse(a1: v45, a2: v8); /*0x105c307f8*/
  *(_QWORD *)&v46 = RBX::json::Value::operator[](a1: (RBX::json::Value *)v45, a2: (__int64)"code", a3: 4u); /*0x105c3081c*/
  BYTE8(v46) = v9; /*0x105c3081f*/
  if ( (unsigned __int8)RBX::json::Value::isNumber(this: (RBX::json::Value *)&v46) == 0 /*0x105c3088c*/
    || (v64 = RBX::json::Value::operator[](a1: (RBX::json::Value *)v45, a2: (__int64)"code", a3: 4u),
        LOBYTE(v65) = v10,
        RBX::json::Value::getInteger<long long>(a1: &v64) != 3)
    || (*(_QWORD *)&v46 = RBX::json::Value::operator[](a1: (RBX::json::Value *)v45, a2: (__int64)"message", a3: 7u),
        BYTE8(v46) = v11,
        (unsigned __int8)RBX::json::Value::isString(this: (RBX::json::Value *)&v46) == 0) )
  {
    LODWORD(v15) = 0; /*0x105c308fd*/
    goto LABEL_10; /*0x105c308fd*/
  }
  v55 = RBX::json::Value::operator[](a1: (RBX::json::Value *)v45, a2: (__int64)"message", a3: 7u); /*0x105c308ad*/
  LOBYTE(v56) = v12; /*0x105c308b0*/
  v46 = 0; /*0x105c308be*/
  v47 = nullptr; /*0x105c308c2*/
  RBX::json::Value::getString(a1: &v64, a2: &v55, a3: &v46); /*0x105c308ce*/
  if ( (v46 & 1) != 0 ) /*0x105c308da*/
    operator delete(a1: (RBX::Memory *)v47, a2: v13); /*0x105c308e3*/
  if ( (v64 & 1) == 0 ) /*0x105c308ed*/
  {
    if ( (_BYTE)v64 != 0 ) /*0x105c308f1*/
    {
      v14 = (char *)&v64 + 1; /*0x105c308f7*/
      goto LABEL_13; /*0x105c308fb*/
    }
LABEL_18:
    LODWORD(v15) = 0; /*0x105c309aa*/
    goto LABEL_19; /*0x105c309aa*/
  }
  if ( v65 == 0 ) /*0x105c3093a*/
    goto LABEL_18; /*0x105c3093a*/
  v14 = v66; /*0x105c3093c*/
LABEL_13:
  if ( *v14 != 91 ) /*0x105c30943*/
    goto LABEL_18; /*0x105c30943*/
  LODWORD(v15) = 0; /*0x105c30945*/
  v17 = std::string::find(a1: &v64, a2: 93, a3: 0); /*0x105c30953*/
  if ( v17 != -1 ) /*0x105c3095c*/
  {
    v18 = v17; /*0x105c3095e*/
    std::string::basic_string(a1: &v55, a2: &v64, a3: 1, a4: v17 - 1, a5: &v46); /*0x105c3097c*/
    if ( (a4 & 0x100000000LL) != 0 ) /*0x105c30986*/
    {
      v15 = RBX::details::SplitHashTable<RBX::StringView,std::pair<RBX::StringView,RBX::PromptCreateAssetResult>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::StringView>,RBX::details::DefaultEqualTo<RBX::StringView>,RBX::details::GetMapKey<RBX::StringView,RBX::PromptCreateAssetResult>>::find_as<std::string>( /*0x105c309d8*/
              a1: &RBX::kPromptCreateAssetResultMap,
              a2: &v55);
      if ( v15 != 0 || v21 != 0 ) /*0x105c309e3*/
      {
        LODWORD(v67) = v21; /*0x105c309f1*/
        std::string::basic_string(a1: &v68, a2: &v64, a3: v18 + 1, a4: -1, a5: &v46); /*0x105c30a10*/
        v22 = *(_DWORD *)(*(_QWORD *)(v15 + 16) + 24LL * LODWORD(v67) + 16); /*0x105c30a20*/
        v23 = v68; /*0x105c30a24*/
        v70[0] = *(_QWORD *)((char *)&v68 + 1); /*0x105c30a2c*/
        v24 = *((_QWORD *)&v68 + 1); /*0x105c30a30*/
        *(_QWORD *)((char *)v70 + 7) = *((_QWORD *)&v68 + 1); /*0x105c30a34*/
        v25 = v69; /*0x105c30a38*/
        v68 = 0; /*0x105c30a40*/
        v69 = nullptr; /*0x105c30a45*/
        LODWORD(v46) = v22; /*0x105c30a54*/
        std::string::basic_string[abi:ne200100]<0>(a1: (char *)&v46 + 8, a2: "", a3: v26, a4: v24); /*0x105c30a5e*/
        v48 = v23; /*0x105c30a63*/
        *(_QWORD *)v49 = v70[0]; /*0x105c30a72*/
        *(_QWORD *)&v49[7] = *(_QWORD *)((char *)v70 + 7); /*0x105c30a79*/
        *(_QWORD *)&v49[15] = v25; /*0x105c30a80*/
        v50 = a4; /*0x105c30a87*/
        v51 = 1; /*0x105c30a8e*/
        v67 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v27); /*0x105c30a9a*/
        std::string::basic_string[abi:ne200100]<0>(a1: v58, a2: "", a3: v28, a4: v29); /*0x105c30aad*/
        std::string::basic_string[abi:ne200100]<0>(a1: v60, a2: "", a3: v30, a4: v31); /*0x105c30ac0*/
        std::string::basic_string[abi:ne200100]<0>(a1: v62, a2: "", a3: v32, a4: v33); /*0x105c30ad3*/
        RBX::sendCreateResultToDev(a1, a2: a3, a3: &v46, a4: v58, a5: v60, a6: v62, a7: (v67 - v54) * 1000.0); /*0x105c30b0f*/
        if ( (v62[0] & 1) != 0 ) /*0x105c30b1b*/
          operator delete(a1: (RBX::Memory *)v63, a2: v34); /*0x105c30b24*/
        if ( (v60[0] & 1) != 0 ) /*0x105c30b30*/
          operator delete(a1: (RBX::Memory *)v61, a2: v34); /*0x105c30b39*/
        if ( (v58[0] & 1) != 0 ) /*0x105c30b45*/
          operator delete(a1: (RBX::Memory *)v59, a2: v34); /*0x105c30b4e*/
        RBX::PromptCreateAvatarAssetResultInfo::~PromptCreateAvatarAssetResultInfo(this: (RBX::PromptCreateAvatarAssetResultInfo *)&v46); /*0x105c30b5a*/
        goto LABEL_43; /*0x105c30b5f*/
      }
    }
    else
    {
      if ( (v55 & 1) != 0 ) /*0x105c30991*/
      {
        v19 = (char *)v57; /*0x105c30997*/
        v20 = v56; /*0x105c3099e*/
      }
      else
      {
        v20 = (unsigned __int8)v55 >> 1; /*0x105c30b64*/
        v19 = (char *)&v55 + 1; /*0x105c30b66*/
      }
      *(_QWORD *)&v46 = v19; /*0x105c30b74*/
      *((_QWORD *)&v46 + 1) = v20; /*0x105c30b77*/
      v35 = std::__hash_table<std::__hash_value_type<RBX::StringView,RBX::PromptCreateAvatarResult>,std::__unordered_map_hasher<RBX::StringView,std::__hash_value_type<RBX::StringView,RBX::PromptCreateAvatarResult>,std::hash<RBX::StringView>,std::equal_to<RBX::StringView>,true>,std::__unordered_map_equal<RBX::StringView,std::__hash_value_type<RBX::StringView,RBX::PromptCreateAvatarResult>,std::equal_to<RBX::StringView>,std::hash<RBX::StringView>,true>,std::allocator<std::__hash_value_type<RBX::StringView,RBX::PromptCreateAvatarResult>>>::find<RBX::StringView>(a1: &RBX::kPromptCreateAvatarResultMap); /*0x105c30b87*/
      if ( v35 != 0 ) /*0x105c30b8d*/
      {
        std::string::basic_string(a1: &v68, a2: &v64, a3: v18 + 1, a4: -1, a5: &v46); /*0x105c30bab*/
        v36 = *(_DWORD *)(v35 + 32); /*0x105c30bb0*/
        if ( (v68 & 1) != 0 ) /*0x105c30bb8*/
        {
          std::string::__init_copy_ctor_external(a1: &v52, a2: v69, a3: *((_QWORD *)&v68 + 1)); /*0x105c30beb*/
        }
        else
        {
          v53 = v69; /*0x105c30bbe*/
          v52 = v68; /*0x105c30bca*/
        }
        RBX::PromptCreateAvatarResultInfo::PromptCreateAvatarResultInfo(a1: &v46, a2: v36, a3: &v52); /*0x105c30c01*/
        v67 = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v37); /*0x105c30c0b*/
        std::string::basic_string[abi:ne200100]<0>(a1: v58, a2: "", a3: v38, a4: v39); /*0x105c30c1e*/
        std::string::basic_string[abi:ne200100]<0>(a1: v60, a2: "", a3: v40, a4: v41); /*0x105c30c31*/
        std::string::basic_string[abi:ne200100]<0>(a1: v62, a2: "", a3: v42, a4: v43); /*0x105c30c44*/
        RBX::sendCreateResultToDev(a1, a2: a3, a3: &v46, a4: v58, a5: v60, a6: v62, a7: (v67 - v54) * 1000.0); /*0x105c30c80*/
        if ( (v62[0] & 1) != 0 ) /*0x105c30c8c*/
          operator delete(a1: (RBX::Memory *)v63, a2: v44); /*0x105c30c95*/
        if ( (v60[0] & 1) != 0 ) /*0x105c30ca1*/
          operator delete(a1: (RBX::Memory *)v61, a2: v44); /*0x105c30caa*/
        if ( (v58[0] & 1) != 0 ) /*0x105c30cb6*/
          operator delete(a1: (RBX::Memory *)v59, a2: v44); /*0x105c30cbf*/
        RBX::PromptCreateAvatarResultInfo::~PromptCreateAvatarResultInfo(this: (RBX::PromptCreateAvatarResultInfo *)&v46); /*0x105c30ccb*/
        if ( (v52 & 1) != 0 ) /*0x105c30cd7*/
          operator delete(a1: (RBX::Memory *)v53, a2: v13); /*0x105c30ce0*/
LABEL_43:
        if ( (v68 & 1) != 0 ) /*0x105c30ce9*/
          operator delete(a1: (RBX::Memory *)v69, a2: v13); /*0x105c30cef*/
        LOBYTE(v15) = 1; /*0x105c30cf4*/
        goto LABEL_46; /*0x105c30cf4*/
      }
    }
    LODWORD(v15) = 0; /*0x105c30bd4*/
LABEL_46:
    if ( (v55 & 1) != 0 ) /*0x105c30cfe*/
      operator delete(a1: (RBX::Memory *)v57, a2: v13); /*0x105c30d0b*/
  }
LABEL_19:
  if ( (v64 & 1) != 0 ) /*0x105c309b1*/
    operator delete(a1: (RBX::Memory *)v66, a2: v13); /*0x105c309bb*/
LABEL_10:
  RBX::json::Document::~Document(this: (RBX::json::Document *)v45); /*0x105c30900*/
  return (unsigned int)v15; /*0x105c30923*/
}

// Address: 0x105d84b8f | Name: __ZN3RBXL8isTruthyERKNS_10Reflection7VariantE
char __fastcall RBX::isTruthy(RBX *this, const RBX::Reflection::Variant *a2)
{
  __int64 v3; // r14
  __int64 v4; // rdi
  __int64 v5; // r14
  __int64 v6; // rcx
  __int64 v7; // rdi
  char result; // al
  __int64 v9; // r14
  const char *v10; // rsi

  v3 = *(_QWORD *)this; /*0x105d84b99*/
  if ( v3 == RBX::Reflection::Type::getSingleton<void>(a1: this, a2) ) /*0x105d84ba4*/
    return 0; /*0x105d84bca*/
  v5 = *(_QWORD *)this; /*0x105d84ba6*/
  v6 = RBX::Reflection::Type::getSingleton<bool>(a1: v4); /*0x105d84bae*/
  result = 1; /*0x105d84bb1*/
  if ( v6 == v5 ) /*0x105d84bb6*/
  {
    v9 = *(_QWORD *)this; /*0x105d84bb8*/
    if ( RBX::Reflection::Type::getSingleton<bool>(a1: v7) != v9 ) /*0x105d84bc3*/
      RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v10); /*0x105d84bda*/
    return *((_BYTE *)this + 16); /*0x105d84bc5*/
  }
  return result; /*0x105d84bcc*/
}

// Address: 0x105ec01c6 | Name: __ZN3RBX10IndexArrayINS_10IAdornableEXadL_ZNS1_11indexFunc2dEvEEE6insertEPS1_i
__int64 __fastcall RBX::IndexArray<RBX::IAdornable,&RBX::IAdornable::indexFunc2d>::insert(
        __int64 *a1,
        __int64 a2,
        int a3)
{
  __int64 result; // rax
  unsigned __int64 v7; // rcx
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // rsi

  std::vector<RBX::IAdornable *,RSL::Detail::Allocator<RBX::IAdornable *>>::resize(a1, a2: ((a1[1] - *a1) >> 3) + 1); /*0x105ec01e6*/
  result = *a1; /*0x105ec01eb*/
  v7 = (unsigned __int64)(a1[1] - *a1) >> 3; /*0x105ec01f5*/
  if ( (int)v7 - 1 <= a3 ) /*0x105ec01fe*/
  {
    v9 = a3; /*0x105ec0229*/
  }
  else
  {
    v8 = (int)v7 - 1LL; /*0x105ec0203*/
    v9 = a3; /*0x105ec0206*/
    do /*0x105ec0225*/
    {
      *(_QWORD *)(result + 8 * v8) = *(_QWORD *)(result + 8 * v8 - 8); /*0x105ec020e*/
      result = *a1; /*0x105ec0212*/
      v10 = *(_QWORD *)(*a1 + 8 * v8--); /*0x105ec0215*/
      *(_DWORD *)(v10 + 8) = v8 + 1; /*0x105ec021f*/
    }
    while ( v8 > a3 ); /*0x105ec0225*/
  }
  *(_QWORD *)(result + 8 * v9) = a2; /*0x105ec022c*/
  *(_DWORD *)(a2 + 8) = a3; /*0x105ec0230*/
  return result; /*0x105ec0238*/
}

// Address: 0x105ec0240 | Name: __ZN3RBX10IndexArrayINS_10IAdornableEXadL_ZNS1_11indexFunc2dEvEEE6removeEPS1_
__int64 __fastcall RBX::IndexArray<RBX::IAdornable,&RBX::IAdornable::indexFunc2d>::remove(__int64 *a1, __int64 a2)
{
  unsigned __int64 v2; // rcx
  __int64 result; // rax
  __int64 v4; // rdx
  unsigned __int64 v5; // r8
  __int64 v6; // rdx

  v2 = *(int *)(a2 + 8); /*0x105ec0240*/
  result = *a1; /*0x105ec024b*/
  v4 = a1[1]; /*0x105ec024e*/
  if ( FFlag::IndexArrayValidateItemSlot != 0 ) /*0x105ec0256*/
  {
    if ( (v2 & 0x80000000) != 0LL ) /*0x105ec025a*/
      return result; /*0x105ec025a*/
    v5 = (v4 - result) >> 3; /*0x105ec0262*/
    if ( v5 <= v2 ) /*0x105ec0269*/
      return result; /*0x105ec0269*/
  }
  else
  {
    v5 = (v4 - result) >> 3; /*0x105ec0272*/
  }
  if ( v5 - 1 > v2 ) /*0x105ec0280*/
  {
    do /*0x105ec02ac*/
    {
      v6 = *(_QWORD *)(result + 8 * v2 + 8); /*0x105ec0282*/
      *(_QWORD *)(result + 8 * v2) = v6; /*0x105ec0287*/
      *(_DWORD *)(v6 + 8) = v2; /*0x105ec028b*/
      result = *a1; /*0x105ec0292*/
      v4 = a1[1]; /*0x105ec0295*/
      ++v2; /*0x105ec02a6*/
    }
    while ( ((v4 - *a1) >> 3) - 1 > v2 ); /*0x105ec02ac*/
  }
  a1[1] = v4 - 8; /*0x105ec02b2*/
  *(_DWORD *)(a2 + 8) = -1; /*0x105ec02b6*/
  return result; /*0x105ec026b*/
}

// Address: 0x105ec03ec | Name: __ZN3RBX10IndexArrayINS_10IAdornableEXadL_ZNS1_11indexFunc2dEvEEE10stableSortEPFbPS1_S3_E
__int64 __fastcall RBX::IndexArray<RBX::IAdornable,&RBX::IAdornable::indexFunc2d>::stableSort(_QWORD *a1)
{
  __int64 result; // rax
  __int64 v3; // rcx
  __int64 v4; // rcx
  __int64 v5; // rdx

  std::__stable_sort_impl[abi:ne200100]<std::_ClassicAlgPolicy,std::__wrap_iter<RBX::IAdornable **>,bool (*)(RBX::IAdornable *,RBX::IAdornable *)>( /*0x105ec0406*/
    a1: *a1,
    a2: a1[1]);
  result = *a1; /*0x105ec040b*/
  v3 = a1[1] - *a1; /*0x105ec0412*/
  if ( v3 != 0 ) /*0x105ec0415*/
  {
    v4 = (v3 >> 3 == 0) + (v3 >> 3); /*0x105ec041f*/
    v5 = 0; /*0x105ec0423*/
    do /*0x105ec0432*/
    {
      *(_DWORD *)(*(_QWORD *)(result + 8 * v5) + 8LL) = v5; /*0x105ec0429*/
      ++v5; /*0x105ec042c*/
    }
    while ( v4 != v5 ); /*0x105ec0432*/
  }
  return result; /*0x105ec0438*/
}

// Address: 0x105ed4d70 | Name: __ZN3RBXL15isCaptureObjectERKNSt3__110shared_ptrINS_6ObjectEEE
bool __fastcall RBX::isCaptureObject(_QWORD *a1)
{
  __int128 v1; // kr00_16
  __int128 v3; // [rsp+0h] [rbp-20h] BYREF

  RBX::Reflection::DescribedBase::fastSharedDynamicCast<RBX::Capture,RBX::Object>(a1: &v3, a2: a1); /*0x105ed4d85*/
  v1 = v3; /*0x105ed4d8d*/
  if ( *((_QWORD *)&v3 + 1) != 0 /*0x105ed4da6*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v3 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v1 + 1) + 16LL))(a1: *((_QWORD *)&v1 + 1)); /*0x105ed4dae*/
    std::__shared_weak_count::__release_weak(this: *((std::__shared_weak_count **)&v1 + 1)); /*0x105ed4db4*/
  }
  return (_QWORD)v1 != 0; /*0x105ed4dbf*/
}

// Address: 0x105f8346d | Name: __ZN3RBX25isDescendantOfRelativeGuiEPNS_8InstanceE
__int64 __fastcall RBX::isDescendantOfRelativeGui(RBX *this, RBX::Instance *a2)
{
  RBX *v2; // rbx
  __int64 v3; // r14
  __int64 v4; // rax
  volatile signed __int64 *v5; // r14
  volatile signed __int64 *v6; // r15
  volatile signed __int64 *v8; // [rsp+8h] [rbp-28h] BYREF
  std::__shared_weak_count *v9; // [rsp+10h] [rbp-20h]

  if ( this == nullptr ) /*0x105f8347d*/
    goto LABEL_14; /*0x105f8347d*/
  v2 = this; /*0x105f83483*/
  v3 = *((_QWORD *)this + 3); /*0x105f83486*/
  v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::GuiObject>(a1: this); /*0x105f8348a*/
  if ( *(unsigned __int16 *)(v3 + 440) - (unsigned int)*(unsigned __int16 *)(v4 + 440) > *(unsigned __int16 *)(v4 + 442) ) /*0x105f834a9*/
    goto LABEL_14; /*0x105f834a9*/
  (*(void (__fastcall **)(volatile signed __int64 **, RBX *))(*(_QWORD *)v2 + 688LL))(a1: &v8, a2: v2); /*0x105f834b8*/
  if ( v9 == nullptr ) /*0x105f834c5*/
    goto LABEL_14; /*0x105f834c5*/
  v5 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v9); /*0x105f834cc*/
  v6 = v5; /*0x105f834cf*/
  if ( v5 != nullptr ) /*0x105f834d5*/
    v6 = v8; /*0x105f834d7*/
  if ( v9 != nullptr ) /*0x105f834e2*/
    std::__shared_weak_count::__release_weak(this: v9); /*0x105f834e4*/
  if ( v6 != nullptr ) /*0x105f834ec*/
    LOBYTE(v2) = *((_BYTE *)v6 + 40) == 1; /*0x105f834f3*/
  if ( v5 != nullptr && _InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x105f8350d*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(a1: v5); /*0x105f83515*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v5); /*0x105f8351b*/
  }
  if ( v6 == nullptr ) /*0x105f83523*/
LABEL_14:
    LODWORD(v2) = 0; /*0x105f83525*/
  LOBYTE(v2) = (unsigned __int8)v2 & 1; /*0x105f83527*/
  return (unsigned int)v2; /*0x105f8352c*/
}

// Address: 0x105f85e87 | Name: __ZN3RBX18isValidSliceCenterENS_6Rect2DENS_7Vector2ES1_
char __fastcall RBX::isValidSliceCenter(__m128 a1, __m128 a2, __m128 a3, __m128 a4)
{
  __m128 v4; // xmm3
  __m128 v5; // xmm5
  __m128 v6; // xmm3
  __m128 v7; // xmm5
  __m128 v8; // xmm4
  __m128 v9; // xmm0
  float v10; // xmm1_4
  __m128 v12; // xmm2
  float v13; // xmm6_4
  __m128 v14; // xmm5

  v4 = _mm_add_ps(a4, a3); /*0x105f85e8e*/
  v5 = _mm_min_ps(v4, a3); /*0x105f85e94*/
  v6 = _mm_max_ps(v4, a3); /*0x105f85e97*/
  if ( _mm_movemask_ps(_mm_cmpneq_ps((__m128)0LL, _mm_movelh_ps(v5, v6))) == 0 ) /*0x105f85eac*/
    return 1; /*0x105f85eda*/
  v7 = _mm_shuffle_ps(v5, v5, 17); /*0x105f85eae*/
  v8 = _mm_add_ps(_mm_shuffle_ps(a1, a2, 17), v7); /*0x105f85eb6*/
  v9 = _mm_cmplt_ps(v8, _mm_shuffle_ps(v8, v8, 78)); /*0x105f85ec3*/
  if ( (_mm_extract_epi8((__m128i)v9, 12) & 1) != 0 ) /*0x105f85ecf*/
    v10 = _mm_movehdup_ps(v8).f32[0]; /*0x105f85ede*/
  else
    v10 = _mm_shuffle_ps(v8, v8, 255).f32[0]; /*0x105f85ed4*/
  v12 = (__m128)_mm_unpackhi_pd((__m128d)v8, (__m128d)v8); /*0x105f85ee5*/
  v13 = v8.f32[0]; /*0x105f85eef*/
  if ( (_mm_extract_epi8((__m128i)v9, 8) & 1) == 0 ) /*0x105f85ef4*/
    v13 = v12.f32[0]; /*0x105f85ef6*/
  v14 = _mm_cmple_ps(v7, _mm_blendv_ps(v12, v8, v9)); /*0x105f85efe*/
  return (_mm_movemask_pd((__m128d)_mm_unpacklo_ps(v14, v14)) == 3) /*0x105f85f23*/
       & (v6.f32[0] >= v10)
       & (_mm_movehdup_ps(v6).f32[0] >= v13);
}

// Address: 0x105f882b4 | Name: __ZN3RBXL25InvokeTweenStatusCallbackENSt3__18weak_ptrINS_9GuiObjectEEENS_3Lua13WeakObjectRefENS_5Enums11TweenStatusE
__int64 __fastcall RBX::InvokeTweenStatusCallback(RBX::ServiceProvider **a1, __int64 a2, int a3)
{
  volatile signed __int64 *v5; // r14
  std::__shared_weak_count *v6; // rdi
  volatile signed __int64 *v7; // rax
  const RBX::Instance *v8; // rsi
  volatile signed __int64 *v9; // r14
  RBX::ServiceProvider *v10; // rdi
  RBX::ServiceProvider *ServiceProvider; // rax
  __int64 v12; // r15
  std::__shared_weak_count *v13; // rbx
  _BYTE v15[8]; // [rsp+0h] [rbp-C0h] BYREF
  std::__shared_weak_count *v16; // [rsp+8h] [rbp-B8h]
  __int128 v17; // [rsp+10h] [rbp-B0h] BYREF
  __int64 v18; // [rsp+20h] [rbp-A0h]
  void **v19; // [rsp+28h] [rbp-98h]
  std::__shared_weak_count *v20; // [rsp+30h] [rbp-90h]
  RBX::ServiceProvider *v21; // [rsp+38h] [rbp-88h]
  volatile signed __int64 *v22; // [rsp+40h] [rbp-80h]
  int v23; // [rsp+4Ch] [rbp-74h] BYREF
  void **v24; // [rsp+50h] [rbp-70h] BYREF
  std::__shared_weak_count *v25; // [rsp+58h] [rbp-68h] BYREF
  _BYTE v26[64]; // [rsp+60h] [rbp-60h] BYREF

  v23 = a3; /*0x105f882d8*/
  RBX::Lua::WeakThreadRef::getLiveLuaRef(this: (RBX::Lua::WeakThreadRef *)&v24); /*0x105f882df*/
  v5 = (volatile signed __int64 *)v25; /*0x105f882e8*/
  v19 = v24; /*0x105f882ec*/
  v20 = v25; /*0x105f882f3*/
  if ( v24 != nullptr && v24[5] != nullptr ) /*0x105f88308*/
  {
    v6 = a1[1]; /*0x105f8830e*/
    if ( v6 != nullptr ) /*0x105f88315*/
    {
      v7 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v6); /*0x105f8831b*/
      v22 = v7; /*0x105f88320*/
      if ( v7 != nullptr ) /*0x105f88327*/
      {
        v9 = v7; /*0x105f8832d*/
        v10 = *a1; /*0x105f88330*/
        v21 = v10; /*0x105f88333*/
        if ( v10 == nullptr ) /*0x105f8833d*/
          goto LABEL_14; /*0x105f8833d*/
        ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this: v10, a2: v8); /*0x105f88343*/
        if ( ServiceProvider == nullptr ) /*0x105f8834b*/
          goto LABEL_14; /*0x105f8834b*/
        v12 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::ScriptContext>(this: ServiceProvider); /*0x105f88359*/
        if ( v12 == 0 ) /*0x105f8835f*/
          goto LABEL_14; /*0x105f8835f*/
        v17 = 0; /*0x105f88368*/
        v18 = 0; /*0x105f8836f*/
        v24 = (void **)RBX::Reflection::Type::getSingleton<RBX::Enums::TweenStatus>(); /*0x105f88383*/
        v25 = nullptr; /*0x105f88387*/
        RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<RBX::Enums::TweenStatus>(a1: &v25, a2: &v23); /*0x105f88392*/
        std::vector<RBX::Reflection::Variant>::push_back[abi:ne200100](a1: (__int64)&v17, a2: (__int64)&v24); /*0x105f883a2*/
        if ( v25 != nullptr ) /*0x105f883ae*/
          (*((void (__fastcall **)(_BYTE *))v25 + 2))(a1: v26); /*0x105f883b4*/
        RBX::ScriptContext::callInNewThread(a1: v15, a2: v12, a3: a2, a4: &v17); /*0x105f883ce*/
        v13 = v16; /*0x105f883d3*/
        if ( v16 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v16 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x105f883ef*/
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x105f883f7*/
          std::__shared_weak_count::__release_weak(this: v13); /*0x105f883fd*/
        }
        v24 = (void **)&v17; /*0x105f88406*/
        std::vector<RBX::Reflection::Variant>::__destroy_vector::operator()[abi:ne200100](a1: &v24); /*0x105f88409*/
        v9 = v22; /*0x105f8840e*/
        if ( v22 != nullptr ) /*0x105f88415*/
        {
LABEL_14:
          if ( _InterlockedExchangeAdd64(v9 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x105f88427*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v9 + 16))(a1: v9); /*0x105f8842f*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v9); /*0x105f88435*/
          }
        }
      }
    }
    v5 = (volatile signed __int64 *)v20; /*0x105f8843a*/
  }
  if ( v5 != nullptr && _InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x105f88456*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(a1: v5); /*0x105f8845e*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v5); /*0x105f88464*/
  }
  return __stack_chk_guard; /*0x105f88479*/
}

// Address: 0x105f88b26 | Name: __ZN3RBXL22InvokeRemoveOnTweenEndENSt3__18weak_ptrINS_9GuiObjectEEENS_3Lua13WeakObjectRefE
void __fastcall RBX::InvokeRemoveOnTweenEnd(RBX::Instance **a1)
{
  std::__shared_weak_count *v2; // rdi
  volatile signed __int64 *v3; // rax
  volatile signed __int64 *v4; // rbx

  v2 = a1[1]; /*0x105f88b34*/
  if ( v2 != nullptr ) /*0x105f88b3b*/
  {
    v3 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v2); /*0x105f88b3d*/
    if ( v3 != nullptr ) /*0x105f88b49*/
    {
      v4 = v3; /*0x105f88b4b*/
      if ( *a1 != nullptr ) /*0x105f88b58*/
        RBX::Instance::setParent(this: *a1, a2: nullptr); /*0x105f88b5c*/
      if ( _InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x105f88b71*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(a1: v4); /*0x105f88b82*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v4); /*0x105f88b90*/
      }
    }
  }
}

// Address: 0x105fead4b | Name: __ZN3RBXL20isCharWhitespaceSafeERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEEi
char __fastcall RBX::isCharWhitespaceSafe(unsigned __int8 *a1, int a2)
{
  unsigned __int64 v2; // rax
  unsigned __int64 v3; // rcx
  unsigned int v4; // edx
  unsigned __int64 v5; // rsi
  unsigned __int8 *v6; // rdi
  unsigned __int8 v7; // cl

  LOBYTE(v2) = 1; /*0x105fead4b*/
  if ( a2 >= 0 )
  {
    v3 = (unsigned int)a2; /*0x105fead51*/
    v4 = *a1; /*0x105fead53*/
    v5 = (v4 & 1) != 0 ? *((_QWORD *)a1 + 1) : v4 >> 1;
    if ( v5 > v3 ) /*0x105fead68*/
    {
      if ( (v4 & 1) != 0 ) /*0x105fead6d*/
        v6 = *((unsigned __int8 **)a1 + 2); /*0x105fead6f*/
      else
        v6 = a1 + 1; /*0x105fead75*/
      v7 = v6[v3]; /*0x105fead7c*/
      if ( v7 > 0x20u ) /*0x105fead82*/
        LOBYTE(v2) = 0; /*0x105fead93*/
      else
        v2 = 0x100000600uLL >> v7; /*0x105fead8e*/
    }
  }
  return v2 & 1; /*0x105fead98*/
}

// Address: 0x10602dc00 | Name: __ZN3RBX10InputFrameaSERKS0_
__int64 __fastcall RBX::InputFrame::operator=(__int64 a1, __int64 a2)
{
  __int128 v4; // xmm0
  __int64 v5; // rax
  std::__shared_weak_count *v6; // rdi
  __int128 v7; // xmm0
  __int128 v8; // xmm1
  __int128 v9; // xmm0
  __int64 v10; // rax
  std::__shared_weak_count *v11; // rdi
  __int128 v12; // xmm0
  __int64 v13; // rax
  std::__shared_weak_count *v14; // rdi

  if ( a1 != a2 ) /*0x10602dc0d*/
  {
    if ( *(_DWORD *)a2 != 0 ) /*0x10602dc19*/
      RBX::details::SplitHashTable<RBX::Guid,std::pair<RBX::Guid,RBX::ActionSnapshot>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Guid>,RBX::details::DefaultEqualTo<RBX::Guid>,RBX::details::GetMapKey<RBX::Guid,RBX::ActionSnapshot>>::copy_from<RBX::details::SplitHashTable<RBX::Guid,std::pair<RBX::Guid,RBX::ActionSnapshot>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Guid>,RBX::details::DefaultEqualTo<RBX::Guid>,RBX::details::GetMapKey<RBX::Guid,RBX::ActionSnapshot>>>( /*0x10602dd18*/
        a1,
        a2);
    RBX::FlatMap<RBX::Guid,RBX::ControlStateSnapshot,std::less<void>,std::vector<RBX::Guid>,std::vector<RBX::ControlStateSnapshot>>::operator=( /*0x10602dc27*/
      a1: (_QWORD *)(a1 + 40),
      a2: (_QWORD *)(a2 + 40));
    *(_QWORD *)(a1 + 88) = *(_QWORD *)(a2 + 88); /*0x10602dc30*/
    *(_BYTE *)(a1 + 96) = *(_BYTE *)(a2 + 96); /*0x10602dc38*/
    *(_DWORD *)(a1 + 184) = *(_DWORD *)(a2 + 184); /*0x10602dc42*/
    v4 = *(_OWORD *)(a2 + 192); /*0x10602dc48*/
    v5 = *(_QWORD *)(a2 + 200); /*0x10602dc50*/
    if ( v5 != 0 ) /*0x10602dc5a*/
      _InterlockedIncrement64((volatile signed __int64 *)(v5 + 16)); /*0x10602dc5c*/
    v6 = *(std::__shared_weak_count **)(a1 + 200); /*0x10602dc61*/
    *(_OWORD *)(a1 + 192) = v4; /*0x10602dc68*/
    if ( v6 != nullptr ) /*0x10602dc72*/
      std::__shared_weak_count::__release_weak(this: v6); /*0x10602dc74*/
    *(_BYTE *)(a1 + 97) = *(_BYTE *)(a2 + 97); /*0x10602dc7d*/
    *(_BYTE *)(a1 + 98) = *(_BYTE *)(a2 + 98); /*0x10602dc84*/
    v7 = *(_OWORD *)(a2 + 100); /*0x10602dc87*/
    v8 = *(_OWORD *)(a2 + 116); /*0x10602dc8c*/
    *(_OWORD *)(a1 + 132) = *(_OWORD *)(a2 + 132); /*0x10602dc99*/
    *(_OWORD *)(a1 + 116) = v8; /*0x10602dca0*/
    *(_OWORD *)(a1 + 100) = v7; /*0x10602dca4*/
    v9 = *(_OWORD *)(a2 + 152); /*0x10602dca8*/
    v10 = *(_QWORD *)(a2 + 160); /*0x10602dcb0*/
    if ( v10 != 0 ) /*0x10602dcba*/
      _InterlockedIncrement64((volatile signed __int64 *)(v10 + 16)); /*0x10602dcbc*/
    v11 = *(std::__shared_weak_count **)(a1 + 160); /*0x10602dcc1*/
    *(_OWORD *)(a1 + 152) = v9; /*0x10602dcc8*/
    if ( v11 != nullptr ) /*0x10602dcd2*/
      std::__shared_weak_count::__release_weak(this: v11); /*0x10602dcd4*/
    v12 = *(_OWORD *)(a2 + 168); /*0x10602dcd9*/
    v13 = *(_QWORD *)(a2 + 176); /*0x10602dce1*/
    if ( v13 != 0 ) /*0x10602dceb*/
      _InterlockedIncrement64((volatile signed __int64 *)(v13 + 16)); /*0x10602dced*/
    v14 = *(std::__shared_weak_count **)(a1 + 176); /*0x10602dcf2*/
    *(_OWORD *)(a1 + 168) = v12; /*0x10602dcf9*/
    if ( v14 != nullptr ) /*0x10602dd03*/
      std::__shared_weak_count::__release_weak(this: v14); /*0x10602dd05*/
  }
  return a1; /*0x10602dd0d*/
}

// Address: 0x10603c266 | Name: __ZN3RBX24isValidPropertyForActionEPKNS_11InputActionEPKNS_10Reflection18PropertyDescriptorE
char __fastcall RBX::isValidPropertyForAction(
        RBX *this,
        const RBX::InputAction *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  char result; // al
  _QWORD *v4; // rax
  const RBX::InputAction **v5; // rcx

  if ( this == nullptr ) /*0x10603c269*/
    return 0; /*0x10603c2e6*/
  switch ( *((_DWORD *)this + 58) ) /*0x10603c289*/
  {
    case 0: /*0x10603c289*/
      result = 1; /*0x10603c292*/
      if ( RBX::InputBindingProperties::prop_KeyCode == (_UNKNOWN *)a2 /*0x10603c2d7*/
        || RBX::InputBindingProperties::prop_ReleasedThreshold == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_PressedThreshold == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_UIButton == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_PrimaryModifier == (_UNKNOWN *)a2 )
      {
        return result; /*0x10603c2d7*/
      }
      v4 = &RBX::InputBindingProperties::prop_SecondaryModifier; /*0x10603c2dd*/
      goto LABEL_14; /*0x10603c2e4*/
    case 1: /*0x10603c289*/
      result = 1; /*0x10603c421*/
      if ( RBX::InputBindingProperties::prop_KeyCode == (_UNKNOWN *)a2 /*0x10603c43e*/
        || RBX::InputBindingProperties::prop_Up == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_Down == (_UNKNOWN *)a2 )
      {
        return result; /*0x10603c43e*/
      }
      v5 = (const RBX::InputAction **)&RBX::InputBindingProperties::prop_Scale; /*0x10603c440*/
      goto LABEL_35; /*0x10603c440*/
    case 2: /*0x10603c289*/
      result = 1; /*0x10603c334*/
      if ( RBX::InputBindingProperties::prop_KeyCode == (_UNKNOWN *)a2 /*0x10603c399*/
        || RBX::InputBindingProperties::prop_Up == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_Down == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_Left == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_Right == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_Vector2Scale == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_Scale == (_UNKNOWN *)a2 )
      {
        return result; /*0x10603c399*/
      }
      v5 = (const RBX::InputAction **)&RBX::InputBindingProperties::prop_ResponseCurve; /*0x10603c39f*/
      goto LABEL_35; /*0x10603c3a6*/
    case 3: /*0x10603c289*/
      result = 1; /*0x10603c3b2*/
      if ( RBX::InputBindingProperties::prop_Up == (_UNKNOWN *)a2 /*0x10603c40f*/
        || RBX::InputBindingProperties::prop_Down == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_Left == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_Right == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_Forward == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_Backward == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_Scale == (_UNKNOWN *)a2 )
      {
        return result; /*0x10603c40f*/
      }
      v5 = (const RBX::InputAction **)&RBX::InputBindingProperties::prop_Vector3Scale; /*0x10603c411*/
LABEL_35:
      if ( *v5 != a2 /*0x10603c462*/
        && RBX::InputBindingProperties::prop_PrimaryModifier != (_UNKNOWN *)a2
        && RBX::InputBindingProperties::prop_SecondaryModifier != (_UNKNOWN *)a2 )
      {
        result = FFlag::IASClampMagnitudeToOne /*0x10603c471*/
               & (RBX::InputBindingProperties::prop_ClampMagnitudeToOne == (_UNKNOWN *)a2);
      }
      break; /*0x10603c471*/
    case 4: /*0x10603c289*/
      result = 1; /*0x10603c2f0*/
      if ( RBX::InputBindingProperties::prop_KeyCode == (_UNKNOWN *)a2 /*0x10603c315*/
        || RBX::InputBindingProperties::prop_PrimaryModifier == (_UNKNOWN *)a2
        || RBX::InputBindingProperties::prop_SecondaryModifier == (_UNKNOWN *)a2 )
      {
        return result; /*0x10603c315*/
      }
      v4 = &RBX::InputBindingProperties::prop_UIModifier; /*0x10603c31b*/
LABEL_14:
      result = *v4 == (_QWORD)a2; /*0x10603c322*/
      break; /*0x10603c328*/
    default:
      return 0;
  }
  return result; /*0x10603c2e8*/
}

// Address: 0x106291785 | Name: __ZN3RBXL16isScriptInstanceERKNSt3__110shared_ptrINS_8InstanceEEE
__int64 __fastcall RBX::isScriptInstance(__int64 a1)
{
  __int64 v2; // rax
  __int64 v3; // rdi
  __int64 v4; // rsi
  unsigned int v5; // ecx
  __int64 v6; // r14
  __int64 v7; // r15
  __int64 v8; // rax
  __int64 v9; // rbx
  __int64 v10; // rax

  v6 = *(_QWORD *)(*(_QWORD *)a1 + 24LL); /*0x106291795*/
  v2 = RBX::Reflection::Class_getDescriptorPtr<RBX::Script>(a1); /*0x106291799*/
  v5 = *(unsigned __int16 *)(v6 + 440) - *(unsigned __int16 *)(v2 + 440); /*0x1062917ad*/
  LOBYTE(v6) = 1; /*0x1062917b6*/
  if ( v5 > *(unsigned __int16 *)(v2 + 442) ) /*0x1062917bb*/
  {
    v7 = *(_QWORD *)(*(_QWORD *)a1 + 24LL); /*0x1062917c0*/
    v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::ModuleScript>(a1: v3, a2: v4); /*0x1062917c4*/
    if ( *(unsigned __int16 *)(v7 + 440) - (unsigned int)*(unsigned __int16 *)(v8 + 440) > *(unsigned __int16 *)(v8 + 442) ) /*0x1062917e3*/
    {
      v9 = *(_QWORD *)(*(_QWORD *)a1 + 24LL); /*0x1062917e8*/
      v10 = RBX::Reflection::Class_getDescriptorPtr<RBX::AuroraScript>(); /*0x1062917ec*/
      LOBYTE(v6) = *(unsigned __int16 *)(v9 + 440) - (unsigned int)*(unsigned __int16 *)(v10 + 440) <= *(unsigned __int16 *)(v10 + 442); /*0x10629180a*/
    }
  }
  return (unsigned int)v6; /*0x106291815*/
}

// Address: 0x106304650 | Name: __ZN3RBXL24instantiateKeyValueTableERN4Luau11GlobalTypesEPKNS0_4TypeES5_
__int64 __fastcall RBX::instantiateKeyValueTable(
        RBX *this,
        Luau::GlobalTypes *a2,
        const Luau::Type *a3,
        const Luau::Type *a4)
{
  __int64 v5; // rbx
  _BYTE v7[280]; // [rsp+0h] [rbp-270h] BYREF
  _BYTE v8[280]; // [rsp+118h] [rbp-158h] BYREF
  _QWORD v9[4]; // [rsp+230h] [rbp-40h] BYREF
  __int128 *v10; // [rsp+250h] [rbp-20h] BYREF
  __int128 v11; // [rsp+258h] [rbp-18h] BYREF

  v11 = 0; /*0x106304666*/
  v10 = &v11; /*0x106304669*/
  v9[0] = a2; /*0x106304671*/
  v9[1] = a3; /*0x106304674*/
  LOBYTE(v9[2]) = 0; /*0x106304678*/
  LOBYTE(v9[3]) = 1; /*0x10630467c*/
  Luau::TableType::TableType(a1: v7, a2: &v10, a3: v9, a4: *(_QWORD *)(*((_QWORD *)this + 49) + 104LL), a5: 0); /*0x10630469c*/
  std::__tree<std::__value_type<std::string,Luau::Property>,std::__map_value_compare<std::string,std::__value_type<std::string,Luau::Property>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,Luau::Property>>>::destroy( /*0x1063046a9*/
    a1: &v10,
    a2: v11);
  Luau::TableType::TableType(this: (Luau::TableType *)v8, a2: (const Luau::TableType *)v7); /*0x1063046bc*/
  v5 = Luau::TypeArena::addType<Luau::TableType>(a1: (char *)this + 8, a2: v8); /*0x1063046d4*/
  Luau::TableType::~TableType(this: (Luau::TableType *)v8); /*0x1063046de*/
  Luau::TableType::~TableType(this: (Luau::TableType *)v7); /*0x1063046ea*/
  return v5; /*0x1063046f2*/
}

// Address: 0x10632ddaf | Name: __ZN3RBXL16isScriptInstanceERKNSt3__110shared_ptrINS_8InstanceEEE_0
__int64 __fastcall RBX::isScriptInstance(__int64 a1)
{
  __int64 v2; // rax
  __int64 v3; // rdi
  __int64 v4; // rsi
  unsigned int v5; // ecx
  __int64 v6; // r14
  __int64 v7; // r15
  __int64 v8; // rax
  __int64 v9; // rdi
  __int64 v10; // rbx
  __int64 v11; // rax

  v6 = *(_QWORD *)(*(_QWORD *)a1 + 24LL); /*0x10632ddbf*/
  v2 = RBX::Reflection::Class_getDescriptorPtr<RBX::Script>(a1); /*0x10632ddc3*/
  v5 = *(unsigned __int16 *)(v6 + 440) - *(unsigned __int16 *)(v2 + 440); /*0x10632ddd7*/
  LOBYTE(v6) = 1; /*0x10632dde0*/
  if ( v5 > *(unsigned __int16 *)(v2 + 442) ) /*0x10632dde5*/
  {
    v7 = *(_QWORD *)(*(_QWORD *)a1 + 24LL); /*0x10632ddea*/
    v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::ModuleScript>(a1: v3, a2: v4); /*0x10632ddee*/
    if ( *(unsigned __int16 *)(v7 + 440) - (unsigned int)*(unsigned __int16 *)(v8 + 440) > *(unsigned __int16 *)(v8 + 442) ) /*0x10632de0d*/
    {
      v10 = *(_QWORD *)(*(_QWORD *)a1 + 24LL); /*0x10632de12*/
      v11 = RBX::Reflection::Class_getDescriptorPtr<RBX::AuroraScript>(a1: v9); /*0x10632de16*/
      LOBYTE(v6) = *(unsigned __int16 *)(v10 + 440) - (unsigned int)*(unsigned __int16 *)(v11 + 440) <= *(unsigned __int16 *)(v11 + 442); /*0x10632de34*/
    }
  }
  return (unsigned int)v6; /*0x10632de3f*/
}

// Address: 0x10668d762 | Name: __ZN3RBX15intersectRayRayENS_7Vector3ES0_S0_S0_Rf
__int64 __fastcall RBX::intersectRayRay(
        float *a1,
        __m128 a2,
        __m128 a3,
        __m128 a4,
        __m128 a5,
        __m128 a6,
        __m128 a7,
        __m128 a8,
        __m128 a9)
{
  __m128 v9; // xmm9
  __m128 v10; // xmm8
  __m128 v11; // xmm9
  __m128 inserted; // xmm7
  __m128 v13; // xmm0
  __m128 v14; // xmm3
  __m128 v15; // xmm3
  __m128 v16; // xmm1
  __m128 v17; // xmm8
  __m128 v18; // xmm7
  __m128 v19; // xmm0
  __int64 result; // rax
  float v21; // xmm0_4

  v9 = _mm_mul_ps(_mm_sub_ps(a6, a2), a4); /*0x10668d76e*/
  v10 = a7; /*0x10668d777*/
  v10.f32[0] = (float)((float)(a7.f32[0] - a3.f32[0]) * a5.f32[0]) + _mm_hadd_ps(v9, v9).f32[0]; /*0x10668d785*/
  v11 = _mm_moveldup_ps(a9); /*0x10668d78a*/
  inserted = _mm_insert_ps(v11, a5, 16); /*0x10668d793*/
  v13 = _mm_sub_ps(a2, a6); /*0x10668d79d*/
  a3.f32[0] = a3.f32[0] - a7.f32[0]; /*0x10668d7a0*/
  v14 = _mm_blend_ps(a4, a8, 2); /*0x10668d7a7*/
  v15 = _mm_add_ps( /*0x10668d7ca*/
          _mm_add_ps(
            _mm_mul_ps(_mm_blend_ps(a8, a4, 2), a8),
            _mm_mul_ps(_mm_shuffle_ps(a8, a8, 225), _mm_shuffle_ps(v14, v14, 225))),
          _mm_mul_ps(v11, inserted));
  v16 = _mm_blend_ps(a3, inserted, 14); /*0x10668d7f6*/
  v17 = _mm_mul_ps(_mm_blend_ps(v10, v15, 14), v15); /*0x10668d811*/
  v18 = _mm_mul_ps( /*0x10668d81a*/
          _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(inserted, inserted, 225), _mm_shuffle_ps(v16, v16, 225)),
            _mm_add_ps(
              _mm_mul_ps(_mm_insert_ps(a8, a4, 76), _mm_blend_ps(_mm_movehdup_ps(a4), v13, 2)),
              _mm_mul_ps(_mm_insert_ps(a4, a8, 28), _mm_insert_ps(a4, v13, 28)))),
          v15);
  v19 = _mm_add_ps(_mm_moveldup_ps(v17), v18); /*0x10668d81d*/
  v18.f32[0] = v18.f32[0] - _mm_movehdup_ps(v17).f32[0]; /*0x10668d825*/
  result = _mm_cvtsi128_si32((__m128i)_mm_cmpneq_ss(v18, (__m128)0LL)) & 1; /*0x10668d838*/
  v21 = _mm_movehdup_ps(v19).f32[0] / v18.f32[0]; /*0x10668d842*/
  if ( v18.f32[0] == 0.0 ) /*0x10668d846*/
    v21 = 0.0; /*0x10668d84a*/
  *a1 = v21; /*0x10668d84d*/
  return result; /*0x10668d851*/
}

// Address: 0x10668d853 | Name: __ZN3RBX16intersectRayLineENS_3RayENS_7Vector3ES1_RS1_
char __fastcall RBX::intersectRayLine(
        __int64 a1,
        __m128 a2,
        __m128 a3,
        __m128 a4,
        float a5,
        __int64 a6,
        __int64 a7,
        __int64 a8,
        __int64 a9,
        __int64 a10,
        unsigned __int64 a11,
        __int128 a12)
{
  __m128 v13; // xmm9
  __m128 v14; // xmm7
  __m128 v15; // xmm6
  __m128 v16; // xmm8
  __m128 v17; // xmm8
  __m128 v18; // xmm11
  __m128 v19; // xmm1
  float v20; // xmm2_4
  __m128 v22; // [rsp+10h] [rbp-70h]
  __m128 v23; // [rsp+20h] [rbp-60h]
  float v25; // [rsp+70h] [rbp-10h] BYREF
  float v26; // [rsp+74h] [rbp-Ch]

  v13 = _mm_mul_ps((__m128)*(unsigned __int64 *)((char *)&a12 + 4), (__m128)*(unsigned __int64 *)((char *)&a12 + 4)); /*0x10668d882*/
  v18 = (__m128)0x3F800000u; /*0x10668d895*/
  v14 = (__m128)0x3F800000u; /*0x10668d89e*/
  v14.f32[0] = 1.0 / fsqrt(_mm_hadd_ps(v13, v13).f32[0] + (float)(*((float *)&a12 + 3) * *((float *)&a12 + 3))); /*0x10668d8a2*/
  v15 = _mm_mul_ps(_mm_moveldup_ps(v14), (__m128)*(unsigned __int64 *)((char *)&a12 + 4)); /*0x10668d8ab*/
  v14.f32[0] = v14.f32[0] * *((float *)&a12 + 3); /*0x10668d8af*/
  v16 = _mm_mul_ps(a4, a4); /*0x10668d8b8*/
  v18.f32[0] = 1.0 / fsqrt((float)(a5 * a5) + _mm_hadd_ps(v16, v16).f32[0]); /*0x10668d8d8*/
  v17 = _mm_mul_ps(_mm_moveldup_ps(v18), a4); /*0x10668d8e2*/
  v18.f32[0] = v18.f32[0] * a5; /*0x10668d8e6*/
  v26 = a3.f32[0]; /*0x10668d8f3*/
  v23 = v15; /*0x10668d913*/
  v22 = v14; /*0x10668d917*/
  if ( (unsigned __int8)RBX::intersectRayRay( /*0x10668d922*/
                          a1: &v25,
                          a2,
                          a3,
                          a4: v17,
                          a5: v18,
                          a6: (__m128)a11,
                          a7: (__m128)(unsigned int)a12,
                          a8: v15,
                          a9: v14) != 0 )
  {
    v19 = _mm_add_ps(_mm_mul_ps(v17, _mm_moveldup_ps((__m128)LODWORD(v25))), a2); /*0x10668d93f*/
    v20 = (float)(v18.f32[0] * v25) + v26; /*0x10668d943*/
LABEL_5:
    _mm_storel_ps((double *)a1, v19); /*0x10668d9ae*/
    *(float *)(a1 + 8) = v20; /*0x10668d9b1*/
    return 1; /*0x10668d9b8*/
  }
  if ( (unsigned __int8)RBX::intersectRayRay( /*0x10668d981*/
                          a1: &v25,
                          a2,
                          a3: (__m128)LODWORD(v26),
                          a4: _mm_xor_ps(v17, *(__m128 *)&xmmword_108F246C0),
                          a5: _mm_xor_ps(*(__m128 *)&xmmword_108F246C0, v18),
                          a6: (__m128)a11,
                          a7: (__m128)(unsigned int)a12,
                          a8: v23,
                          a9: v22) != 0 )
  {
    v19 = _mm_sub_ps(a2, _mm_mul_ps(v17, _mm_moveldup_ps((__m128)LODWORD(v25)))); /*0x10668d99f*/
    v20 = v26 - (float)(v18.f32[0] * v25); /*0x10668d9ab*/
    goto LABEL_5; /*0x10668d9ab*/
  }
  return 0; /*0x10668d9bc*/
}

// Address: 0x10669c2c2 | Name: __ZN3RBX12isTouchEventERKNSt3__110shared_ptrINS_11InputObjectEEE
bool __fastcall RBX::isTouchEvent(__int64 a1)
{
  return *(_QWORD *)a1 != 0 && *(_DWORD *)(*(_QWORD *)a1 + 204LL) == 7; /*0x10669c2d9*/
}

// Address: 0x10669c2dd | Name: __ZN3RBX12isTouchEventENSt3__110shared_ptrIKNS_11InputObjectEEE
bool __fastcall RBX::isTouchEvent(__int64 a1)
{
  return *(_QWORD *)a1 != 0 && *(_DWORD *)(*(_QWORD *)a1 + 204LL) == 7; /*0x10669c2f4*/
}

// Address: 0x10686fb68 | Name: __ZN3RBX11InstanceRefaSERKS0_
__int64 __fastcall RBX::InstanceRef::operator=(__int64 a1, __int128 *a2)
{
  __int128 v4; // xmm0
  __int64 v5; // rax
  std::__shared_weak_count *v6; // rdi

  v4 = *a2; /*0x10686fb75*/
  v5 = *((_QWORD *)a2 + 1); /*0x10686fb78*/
  if ( v5 != 0 ) /*0x10686fb7f*/
    _InterlockedIncrement64((volatile signed __int64 *)(v5 + 16)); /*0x10686fb81*/
  v6 = *(std::__shared_weak_count **)(a1 + 8); /*0x10686fb86*/
  *(_OWORD *)a1 = v4; /*0x10686fb8a*/
  if ( v6 != nullptr ) /*0x10686fb90*/
    std::__shared_weak_count::__release_weak(this: v6); /*0x10686fb92*/
  *(_OWORD *)(a1 + 16) = a2[1]; /*0x10686fb9c*/
  return a1; /*0x10686fba3*/
}

// Address: 0x10693a6a2 | Name: __ZN3RBX10IndexArrayINS_7Network17StreamingObserver24RegionSetData_deprecatedEXadL_ZNS3_8getIndexEvEEE10fastRemoveEPS3_
_DWORD *__fastcall RBX::IndexArray<RBX::Network::StreamingObserver::RegionSetData_deprecated,&RBX::Network::StreamingObserver::RegionSetData_deprecated::getIndex>::fastRemove(
        __int64 *a1,
        unsigned int **a2)
{
  _DWORD *result; // rax
  __int64 v3; // rdx
  __int64 v4; // r8
  _DWORD **v5; // r8

  result = (_DWORD *)**a2; /*0x10693a6a9*/
  v3 = *a1; /*0x10693a6b5*/
  v4 = a1[1]; /*0x10693a6b8*/
  if ( FFlag::IndexArrayValidateItemSlot == 0 || (int)result >= 0 && (v4 - v3) >> 3 > (unsigned __int64)(int)result ) /*0x10693a6d3*/
  {
    v5 = *(_DWORD ***)(v4 - 8); /*0x10693a6d5*/
    *(_QWORD *)(v3 + 8LL * (int)result) = v5; /*0x10693a6d9*/
    **v5 = (_DWORD)result; /*0x10693a6e0*/
    a1[1] -= 8; /*0x10693a6e2*/
    result = *a2; /*0x10693a6e7*/
    **a2 = -1; /*0x10693a6ea*/
  }
  return result; /*0x10693a6f0*/
}

// Address: 0x106954ac0 | Name: __ZN3RBX10IndexArrayINS_7Network8SetStateEXadL_ZNS2_8getIndexEvEEE20fastAppendIfNotExistEPS2_
__int64 __fastcall RBX::IndexArray<RBX::Network::SetState,&RBX::Network::SetState::getIndex>::fastAppendIfNotExist(
        _QWORD *a1,
        __int64 a2)
{
  __int64 result; // rax
  __int64 v3; // [rsp-10h] [rbp-10h] BYREF

  if ( *(int *)(a2 + 12) < 0 ) /*0x106954ac4*/
  {
    v3 = a2; /*0x106954ad3*/
    *(_DWORD *)(a2 + 12) = (a1[1] - *a1) >> 3; /*0x106954ae1*/
    return std::vector<RBX::Network::SetState *,RSL::Detail::Allocator<RBX::Network::SetState *>>::push_back[abi:ne200100]( /*0x106954ae7*/
             a1,
             a2: &v3);
  }
  return result; /*0x106954ac6*/
}

// Address: 0x10718ccda | Name: __ZN3RBX24isEphemeralBackendsValidERKNSt3__110shared_ptrIKNS0_6vectorINS_10Reflection7VariantENS0_9allocatorIS4_EEEEEERKNS0_12basic_stringIcNS0_11char_traitsIcEENS5_IcEEEE
__int64 __fastcall RBX::isEphemeralBackendsValid(__int64 **a1, unsigned __int8 *a2)
{
  __int64 *v2; // rax
  __int64 v4; // rsi
  __int64 v5; // rax
  void *v6; // rsi
  unsigned __int8 v7; // r14
  size_t v8; // rdx
  const void *v9; // rbx
  unsigned int v11; // eax
  __int64 v12; // rcx
  char *p_s1; // rdi
  unsigned __int8 v14; // [rsp+8h] [rbp-28h] BYREF
  char __s1; // [rsp+9h] [rbp-27h] BYREF
  size_t v16; // [rsp+10h] [rbp-20h]
  void *v17; // [rsp+18h] [rbp-18h]

  v2 = *a1; /*0x10718cce5*/
  if ( *a1 != nullptr && (v4 = *v2, (v5 = v2[1]) - v4 == 80) ) /*0x10718cd01*/
  {
    if ( v5 == v4 ) /*0x10718cd06*/
      std::vector<RBX::Reflection::Variant>::__throw_out_of_range[abi:ne200100](); /*0x10718cd8f*/
    RBX::Reflection::Variant::get<std::string>(a1: &v14, a2: v4); /*0x10718cd13*/
    v7 = v14; /*0x10718cd18*/
    if ( (v14 & 1) != 0 ) /*0x10718cd20*/
      v8 = v16; /*0x10718cd22*/
    else
      v8 = v14 >> 1; /*0x10718cd38*/
    v11 = *a2; /*0x10718cd3a*/
    if ( (v11 & 1) != 0 ) /*0x10718cd3f*/
      v12 = *((_QWORD *)a2 + 1); /*0x10718cd41*/
    else
      v12 = v11 >> 1; /*0x10718cd49*/
    if ( v8 == v12 ) /*0x10718cd4e*/
    {
      if ( (v14 & 1) != 0 ) /*0x10718cd54*/
        p_s1 = (char *)v17; /*0x10718cd56*/
      else
        p_s1 = &__s1; /*0x10718cd60*/
      if ( (v11 & 1) != 0 ) /*0x10718cd66*/
        v9 = *((const void **)a2 + 2); /*0x10718cd68*/
      else
        v9 = a2 + 1; /*0x10718cd6e*/
      LOBYTE(v9) = memcmp(__s1: p_s1, __s2: v9, __n: v8) == 0; /*0x10718cd7b*/
    }
    else
    {
      LODWORD(v9) = 0; /*0x10718cd5c*/
    }
    if ( (v7 & 1) != 0 ) /*0x10718cd82*/
      operator delete(a1: (RBX::Memory *)v17, a2: v6); /*0x10718cd88*/
  }
  else
  {
    LODWORD(v9) = 0; /*0x10718cd28*/
  }
  return (unsigned int)v9; /*0x10718cd2c*/
}

// Address: 0x107194b60 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFvNS5_10shared_ptrIKS2_EENS6_IFvbEEEEEES2_EC2ENS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEESK_S9_SD_
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<void ()(std::shared_ptr<RBX::json::Document const>,std::function<void ()(bool)>)>,RBX::json::Document>::MakeRequestContract(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5)
{
  __int64 v5; // rax

  *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x107194b72*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x107194b79*/
  *(_OWORD *)a2 = 0; /*0x107194b7f*/
  *(_QWORD *)(a2 + 16) = 0; /*0x107194b84*/
  *(_QWORD *)(a1 + 40) = *(_QWORD *)(a3 + 16); /*0x107194b8c*/
  *(_OWORD *)(a1 + 24) = *(_OWORD *)a3; /*0x107194b93*/
  *(_OWORD *)a3 = 0; /*0x107194b97*/
  *(_QWORD *)(a3 + 16) = 0; /*0x107194b9a*/
  v5 = *(_QWORD *)(a4 + 8); /*0x107194b9e*/
  *(_OWORD *)(a1 + 48) = *(_OWORD *)a4; /*0x107194ba5*/
  if ( v5 != 0 ) /*0x107194bac*/
    _InterlockedIncrement64((volatile signed __int64 *)(v5 + 8)); /*0x107194bae*/
  return std::__function::__value_func<void ()(std::shared_ptr<RBX::json::Document const>,std::function<void ()(bool)>)>::__value_func[abi:ne200100]( /*0x107194bc7*/
           a1: a1 + 64,
           a2: a5);
}

// Address: 0x1072041fc | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E20SubscriptionContractINSt3__18functionIFbNS5_10shared_ptrIKS2_EEEEEED1Ev
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::SubscriptionContract<std::function<bool ()(std::shared_ptr<RBX::json::Document const>)>>::~SubscriptionContract(
        __int64 a1,
        void *a2)
{
  _QWORD *v3; // rax
  _QWORD *v4; // rdi
  __int64 v5; // rax

  v3 = (_QWORD *)(a1 + 64); /*0x107204205*/
  v4 = *(_QWORD **)(a1 + 96); /*0x107204209*/
  if ( v4 == v3 ) /*0x107204210*/
  {
    v5 = 32; /*0x10720421e*/
  }
  else
  {
    v5 = 40; /*0x107204212*/
    if ( v4 == nullptr ) /*0x10720421a*/
      goto LABEL_6; /*0x10720421a*/
  }
  (*(void (__fastcall **)(_QWORD *))(*v4 + v5))(a1: v4); /*0x107204226*/
LABEL_6:
  if ( *(_BYTE *)(a1 + 48) == 1 && (*(_BYTE *)(a1 + 24) & 1) != 0 ) /*0x107204233*/
    operator delete(a1: *(RBX::Memory **)(a1 + 40), a2); /*0x107204239*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x107204241*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x107204254*/
}

// Address: 0x10720cf36 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E20SubscriptionContractINSt3__18functionIFbNS5_10shared_ptrIKS2_EEEEEEC2ENS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEESB_RKNS5_8optionalISI_EEbb
__int64 __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::SubscriptionContract<std::function<bool ()(std::shared_ptr<RBX::json::Document const>)>>::SubscriptionContract(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        char a5,
        char a6)
{
  __int64 result; // rax

  *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x10720cf54*/
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x10720cf5b*/
  *(_OWORD *)a2 = 0; /*0x10720cf61*/
  *(_QWORD *)(a2 + 16) = 0; /*0x10720cf64*/
  std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: a1 + 24, a2: a4); /*0x10720cf76*/
  result = std::__function::__value_func<bool ()(std::shared_ptr<RBX::json::Document const>)>::__value_func[abi:ne200100]( /*0x10720cf82*/
             a1: a1 + 64,
             a2: a3);
  *(_BYTE *)(a1 + 112) = a5; /*0x10720cf87*/
  *(_BYTE *)(a1 + 113) = a6; /*0x10720cf8b*/
  return result; /*0x10720cf93*/
}

// Address: 0x10756d980 | Name: __ZN3RBXL21isCoreGuiBypassCallerEv
char __fastcall RBX::isCoreGuiBypassCaller(RBX *this)
{
  int v1; // ecx
  RBX::Security::Context *v2; // rdi
  char result; // al
  int v4; // eax
  RBX *v5; // rdi

  if ( FFlag::VirtualInputInternalCallerBypass != 1 ) /*0x10756d98b*/
    return 0; /*0x10756d9b7*/
  v1 = *(_DWORD *)RBX::Security::Context::current(this); /*0x10756d992*/
  result = 1; /*0x10756d994*/
  if ( v1 != 3 && v1 != 12 ) /*0x10756d99e*/
  {
    v4 = *(_DWORD *)RBX::Security::Context::current(this: v2); /*0x10756d9a5*/
    if ( v4 == 10 || v4 == 6 ) /*0x10756d9af*/
      return RBX::hasInternalPermission(this: v5); /*0x10756d9b2*/
    return 0; /*0x10756d9af*/
  }
  return result; /*0x10756d9b1*/
}

// Address: 0x1075b5fd1 | Name: __ZN3RBX30isRobloxTelemetryBackendsValidERKNSt3__110shared_ptrIKNS0_6vectorINS_10Reflection7VariantENS0_9allocatorIS4_EEEEEERKNS0_12basic_stringIcNS0_11char_traitsIcEENS5_IcEEEE
__int64 __fastcall RBX::isRobloxTelemetryBackendsValid(__int64 **a1, unsigned __int8 *a2)
{
  __int64 *v2; // rax
  __int64 v4; // rsi
  __int64 v5; // rax
  void *v6; // rsi
  unsigned __int8 v7; // r14
  size_t v8; // rdx
  const void *v9; // rbx
  unsigned int v11; // eax
  __int64 v12; // rcx
  char *p_s1; // rdi
  unsigned __int8 v14; // [rsp+8h] [rbp-28h] BYREF
  char __s1; // [rsp+9h] [rbp-27h] BYREF
  size_t v16; // [rsp+10h] [rbp-20h]
  void *v17; // [rsp+18h] [rbp-18h]

  v2 = *a1; /*0x1075b5fdc*/
  if ( *a1 != nullptr && (v4 = *v2, (v5 = v2[1]) - v4 == 80) ) /*0x1075b5ff8*/
  {
    if ( v5 == v4 ) /*0x1075b5ffd*/
      std::vector<RBX::Reflection::Variant>::__throw_out_of_range[abi:ne200100](); /*0x1075b6086*/
    RBX::Reflection::Variant::get<std::string>(a1: &v14, a2: v4); /*0x1075b600a*/
    v7 = v14; /*0x1075b600f*/
    if ( (v14 & 1) != 0 ) /*0x1075b6017*/
      v8 = v16; /*0x1075b6019*/
    else
      v8 = v14 >> 1; /*0x1075b602f*/
    v11 = *a2; /*0x1075b6031*/
    if ( (v11 & 1) != 0 ) /*0x1075b6036*/
      v12 = *((_QWORD *)a2 + 1); /*0x1075b6038*/
    else
      v12 = v11 >> 1; /*0x1075b6040*/
    if ( v8 == v12 ) /*0x1075b6045*/
    {
      if ( (v14 & 1) != 0 ) /*0x1075b604b*/
        p_s1 = (char *)v17; /*0x1075b604d*/
      else
        p_s1 = &__s1; /*0x1075b6057*/
      if ( (v11 & 1) != 0 ) /*0x1075b605d*/
        v9 = *((const void **)a2 + 2); /*0x1075b605f*/
      else
        v9 = a2 + 1; /*0x1075b6065*/
      LOBYTE(v9) = memcmp(__s1: p_s1, __s2: v9, __n: v8) == 0; /*0x1075b6072*/
    }
    else
    {
      LODWORD(v9) = 0; /*0x1075b6053*/
    }
    if ( (v7 & 1) != 0 ) /*0x1075b6079*/
      operator delete(a1: (RBX::Memory *)v17, a2: v6); /*0x1075b607f*/
  }
  else
  {
    LODWORD(v9) = 0; /*0x1075b601f*/
  }
  return (unsigned int)v9; /*0x1075b6023*/
}

// Address: 0x10761734f | Name: __ZN3RBX23isGraphicsModeAvailableENS_5Enums12GraphicsModeE
char __fastcall RBX::isGraphicsModeAvailable(int a1)
{
  if ( a1 == 1 ) /*0x107617356*/
    return 1; /*0x107617361*/
  if ( a1 == 9 ) /*0x10761735b*/
    return 0; /*0x10761735d*/
  return FFlag::StudioDisableVulkanGraphicsMode & (a1 == 6) ^ (a1 != 2); /*0x107617379*/
}

// Address: 0x1077d5e22 | Name: __ZN3RBX30isShowServiceSettingToggledOffERKNS_10Reflection15ClassDescriptorEPKNS0_8Metadata5ClassE
__int64 __fastcall RBX::isShowServiceSettingToggledOff(
        RBX *this,
        const RBX::Reflection::ClassDescriptor *a2,
        const RBX::Reflection::Metadata::Class *a3)
{
  const RBX::Reflection::ClassDescriptor *v3; // rbx
  __int64 v5; // rax
  CoreStudioSettings *v6; // rdi
  CoreStudioSettings *v7; // rax
  char ShowCoreGUIInExplorer; // al
  CoreStudioSettings *v9; // rdi
  __int64 v10; // rax
  CoreStudioSettings *v11; // rdi
  void *v12; // rax
  __int64 v13; // rax
  CoreStudioSettings *v14; // rdi
  __int64 v15; // rax
  CoreStudioSettings *v16; // rax
  __int64 v17; // rax
  RBX *v18; // rdi
  CoreStudioSettings *v19; // rdi
  CoreStudioSettings *v20; // rax
  __int64 v21; // rax
  CoreStudioSettings *v22; // rdi
  CoreStudioSettings *v23; // rax
  CoreStudioSettings *v24; // rax
  int v25; // eax

  v3 = a2; /*0x1077d5e29*/
  v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::CoreGuiService>(a1: this, a2, a3); /*0x1077d5e2f*/
  if ( (unsigned __int8)RBX::Reflection::ClassDescriptor::operator==(a1: this, a2: v5) != 0 ) /*0x1077d5e41*/
  {
    v7 = (CoreStudioSettings *)CoreStudioSettings::singleton(this: v6); /*0x1077d5e43*/
    ShowCoreGUIInExplorer = CoreStudioSettings::getShowCoreGUIInExplorer(this: v7); /*0x1077d5e4b*/
  }
  else
  {
    v10 = RBX::Reflection::Class_getDescriptorPtr<RBX::PluginDebugService>(); /*0x1077d5e52*/
    if ( (unsigned __int8)RBX::Reflection::ClassDescriptor::operator==(a1: this, a2: v10) != 0 ) /*0x1077d5e64*/
    {
      v12 = CoreStudioSettings::singleton(this: v11); /*0x1077d5e66*/
      ShowCoreGUIInExplorer = (*(__int64 (__fastcall **)(void *))(*(_QWORD *)v12 + 104LL))(a1: v12); /*0x1077d5e71*/
    }
    else
    {
      v13 = RBX::Reflection::Class_getDescriptorPtr<RBX::PluginGuiService>(); /*0x1077d5e76*/
      if ( (unsigned __int8)RBX::Reflection::ClassDescriptor::operator==(a1: this, a2: v13) != 0 /*0x1077d5e9c*/
        || (v15 = RBX::Reflection::Class_getDescriptorPtr<RBX::RobloxPluginGuiService>(),
            (unsigned __int8)RBX::Reflection::ClassDescriptor::operator==(a1: this, a2: v15) != 0) )
      {
        v16 = (CoreStudioSettings *)CoreStudioSettings::singleton(this: v14); /*0x1077d5e9e*/
        ShowCoreGUIInExplorer = CoreStudioSettings::getShowPluginGUIServiceInExplorer(this: v16); /*0x1077d5ea6*/
      }
      else
      {
        v17 = RBX::Reflection::Class_getDescriptorPtr<RBX::CorePackages>(); /*0x1077d5eb3*/
        if ( (unsigned __int8)RBX::Reflection::ClassDescriptor::operator==(a1: this, a2: v17) != 0 ) /*0x1077d5ec5*/
        {
          LOBYTE(v3) = 1; /*0x1077d5ec7*/
          if ( RBX::hasInternalPermission(this: v18) == 0 ) /*0x1077d5ed0*/
            return (unsigned int)v3; /*0x1077d5ed0*/
          v20 = (CoreStudioSettings *)CoreStudioSettings::singleton(this: v19); /*0x1077d5ed2*/
          ShowCoreGUIInExplorer = CoreStudioSettings::getShowCorePackages(this: v20); /*0x1077d5eda*/
        }
        else
        {
          v21 = RBX::Reflection::Class_getDescriptorPtr<RBX::FileSyncService>(); /*0x1077d5ee1*/
          if ( (unsigned __int8)RBX::Reflection::ClassDescriptor::operator==(a1: this, a2: v21) == 0 ) /*0x1077d5ef3*/
          {
            if ( v3 == nullptr || *((_BYTE *)v3 + 429) != 0 ) /*0x1077d5f1b*/
              goto LABEL_9; /*0x1077d5f1b*/
LABEL_18:
            v24 = (CoreStudioSettings *)CoreStudioSettings::singleton(this: v9); /*0x1077d5f1d*/
            LOBYTE(v25) = CoreStudioSettings::getShowHiddenItemsInExplorer(this: v24); /*0x1077d5f25*/
            LODWORD(v3) = v25; /*0x1077d5f2a*/
            LOBYTE(v3) = v25 ^ 1; /*0x1077d5f2c*/
            return (unsigned int)v3; /*0x1077d5f2c*/
          }
          LOBYTE(v3) = 1; /*0x1077d5ef5*/
          if ( RBX::hasInternalPermission(this: v9) == 0 ) /*0x1077d5efe*/
            return (unsigned int)v3; /*0x1077d5efe*/
          v23 = (CoreStudioSettings *)CoreStudioSettings::singleton(this: v22); /*0x1077d5f00*/
          ShowCoreGUIInExplorer = CoreStudioSettings::getShowFileSyncService(this: v23); /*0x1077d5f08*/
        }
      }
    }
  }
  if ( ShowCoreGUIInExplorer == 0 ) /*0x1077d5ead*/
    goto LABEL_18; /*0x1077d5ead*/
LABEL_9:
  LODWORD(v3) = 0; /*0x1077d5eaf*/
  return (unsigned int)v3; /*0x1077d5f31*/
}

// Address: 0x1079c828f | Name: __ZN3RBX20isSupportedTvKeyCodeENS_7KeyCodeE
bool __fastcall RBX::isSupportedTvKeyCode(RBX *a1)
{
  int v1; // ebx
  __int128 *TVRemoteSupportedKeyCodes; // rax
  __int64 v3; // rcx
  __int64 v4; // rdx
  bool result; // al
  bool v6; // zf

  v1 = (int)a1; /*0x1079c8295*/
  TVRemoteSupportedKeyCodes = RBX::getTVRemoteSupportedKeyCodes(this: a1); /*0x1079c8297*/
  v3 = *((_QWORD *)TVRemoteSupportedKeyCodes + 1); /*0x1079c829f*/
  if ( *(_QWORD *)TVRemoteSupportedKeyCodes == v3 ) /*0x1079c82a6*/
    return false; /*0x1079c82c2*/
  v4 = *(_QWORD *)TVRemoteSupportedKeyCodes + 4LL; /*0x1079c82a8*/
  do /*0x1079c82be*/
  {
    result = *(_DWORD *)(v4 - 4) == v1; /*0x1079c82af*/
    if ( *(_DWORD *)(v4 - 4) == v1 ) /*0x1079c82b2*/
      break; /*0x1079c82b2*/
    v6 = v4 == v3; /*0x1079c82b8*/
    v4 += 4; /*0x1079c82bb*/
  }
  while ( !v6 ); /*0x1079c82be*/
  return result; /*0x1079c82c8*/
}

// Address: 0x1079c83a9 | Name: __ZN3RBX10isVrDeviceEi
bool __fastcall RBX::isVrDevice(RBX *this)
{
  return (unsigned int)((_DWORD)this - 105) < 2; /*0x1079c83b6*/
}

// Address: 0x1079c83b8 | Name: __ZN3RBX10isTvDeviceEi
bool __fastcall RBX::isTvDevice(RBX *this)
{
  return (_DWORD)this == 108; /*0x1079c83c2*/
}

// Address: 0x107b2a2c3 | Name: __ZN3RBX31importAvatarFromFile_deprecatedERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEENS0_8weak_ptrINS_9DataModelEEENS0_8functionIFvNS0_10shared_ptrINS_13ModelInstanceEEEEEENSC_IFvS6_EEE
__int64 __fastcall RBX::importAvatarFromFile_deprecated(__int128 *a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v4; // rbx
  __int64 v5; // r14
  __int64 *v6; // r15
  std::__shared_weak_count *v8; // rdi
  __int64 v9; // rdi
  RBX::StarterPlayerService *v10; // rax
  __int64 v11; // rdx
  __int64 v12; // rcx
  char v13; // r13
  __int64 v14; // r12
  __int64 v15; // r15
  char v16; // bl
  __int64 v17; // rdi
  void *v18; // rsi
  RBX::Memory **v19; // rax
  std::__shared_weak_count *v20; // r14
  bool v21; // zf
  unsigned __int64 v22; // rdx
  __int64 Aligned; // rax
  __int64 v24; // rbx
  __int64 v25; // rdx
  __int64 v26; // rcx
  __int64 v27; // r8
  __int64 v28; // r9
  void *v29; // rsi
  void *v30; // rsi
  __int64 v31; // rax
  __int64 v32; // rax
  __int64 v34; // rdi
  _BYTE v35[16]; // [rsp+10h] [rbp-150h] BYREF
  _BYTE v36[16]; // [rsp+20h] [rbp-140h] BYREF
  char v37; // [rsp+30h] [rbp-130h] BYREF
  _BYTE v38[16]; // [rsp+38h] [rbp-128h] BYREF
  char v39; // [rsp+48h] [rbp-118h] BYREF
  __int64 *v40; // [rsp+50h] [rbp-110h]
  __int128 *v41; // [rsp+58h] [rbp-108h]
  std::__shared_weak_count *v42[2]; // [rsp+60h] [rbp-100h]
  _QWORD v43[3]; // [rsp+70h] [rbp-F0h] BYREF
  char *v44; // [rsp+88h] [rbp-D8h]
  __int128 v45; // [rsp+90h] [rbp-D0h] BYREF
  void *v46; // [rsp+A0h] [rbp-C0h]
  __int128 v47; // [rsp+A8h] [rbp-B8h]
  _BYTE v48[32]; // [rsp+C0h] [rbp-A0h] BYREF
  _BYTE *v49; // [rsp+E0h] [rbp-80h]
  _BYTE v50[32]; // [rsp+F0h] [rbp-70h] BYREF
  _BYTE *v51; // [rsp+110h] [rbp-50h]
  char v52; // [rsp+120h] [rbp-40h]

  v4 = a4; /*0x107b2a2d7*/
  v5 = a3; /*0x107b2a2da*/
  v6 = (__int64 *)a2; /*0x107b2a2dd*/
  if ( FFlag::AvatarGenerationIsAvatarJointUpgradeEnabled != 1 ) /*0x107b2a2f8*/
  {
    v13 = 0; /*0x107b2a368*/
    goto LABEL_20; /*0x107b2a36b*/
  }
  *(_OWORD *)v42 = 0; /*0x107b2a2fd*/
  v8 = *(std::__shared_weak_count **)(a2 + 8); /*0x107b2a304*/
  v40 = (__int64 *)a2; /*0x107b2a30b*/
  v41 = a1; /*0x107b2a312*/
  if ( v8 == nullptr /*0x107b2a339*/
    || (v42[1] = (std::__shared_weak_count *)std::__shared_weak_count::lock(this: v8), v42[1] == nullptr)
    || (v9 = *v6, v42[0] = (std::__shared_weak_count *)v9, v9 == 0) )
  {
    LOBYTE(a4) = (unsigned __int8)FLog::Photo2Avatar < 6u; /*0x107b2a37e*/
    LOBYTE(a3) = (unsigned __int8)FLog::Photo2Avatar < 6u || (FLog::Photo2Avatar & 0xFE00) == 0; /*0x107b2a38a*/
    if ( (_BYTE)a3 == 0 ) /*0x107b2a38c*/
    {
      v43[0] = 0; /*0x107b2a392*/
      v43[1] = v35; /*0x107b2a3a4*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x107b2a3ce*/
        a1: FLog::Photo2Avatar,
        a2: qword_10D7FF200,
        a3: 2,
        a4: (unsigned int)"[FLog::Photo2Avatar] Datamodel is null.",
        a5: 39,
        a6: 1,
        0,
        v35);
    }
    std::string::basic_string[abi:ne200100]<0>(a1: v36, a2: "Unexpected error, DataModel is null.", a3, a4); /*0x107b2a3e1*/
    v17 = *(_QWORD *)(v4 + 32); /*0x107b2a3e6*/
    if ( v17 == 0 ) /*0x107b2a3ed*/
      std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x107b2a6ec*/
    (*(void (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v17 + 48LL))(a1: v17, a2: v36); /*0x107b2a3fd*/
    if ( (v36[0] & 1) != 0 ) /*0x107b2a407*/
    {
      v15 = v4; /*0x107b2a411*/
      v19 = (RBX::Memory **)&v37; /*0x107b2a414*/
LABEL_14:
      v14 = v5; /*0x107b2a41b*/
      operator delete(a1: *v19, a2: v18); /*0x107b2a421*/
      goto LABEL_15; /*0x107b2a421*/
    }
LABEL_12:
    v14 = v5; /*0x107b2a409*/
    v15 = v4; /*0x107b2a40c*/
LABEL_15:
    v16 = 0; /*0x107b2a426*/
    v13 = 0; /*0x107b2a428*/
    goto LABEL_16; /*0x107b2a428*/
  }
  v10 = (RBX::StarterPlayerService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::StarterPlayerService>(this: (RBX::ServiceProvider *)(v9 + 464)); /*0x107b2a342*/
  if ( v10 == nullptr ) /*0x107b2a34a*/
  {
    LOBYTE(v12) = (unsigned __int8)FLog::Photo2Avatar < 6u; /*0x107b2a64d*/
    LOBYTE(v11) = (unsigned __int8)FLog::Photo2Avatar < 6u || (FLog::Photo2Avatar & 0xFE00) == 0; /*0x107b2a659*/
    if ( (_BYTE)v11 == 0 ) /*0x107b2a65b*/
    {
      v43[0] = 0; /*0x107b2a661*/
      v43[1] = v35; /*0x107b2a673*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x107b2a69d*/
        a1: FLog::Photo2Avatar,
        a2: qword_10D7FF200,
        a3: 2,
        a4: (unsigned int)"[FLog::Photo2Avatar] StarterPlayer is null.",
        a5: 43,
        a6: 1,
        0,
        v35);
    }
    std::string::basic_string[abi:ne200100]<0>( /*0x107b2a6b0*/
      a1: v38,
      a2: "Unexpected error, StarterPlayer is null.",
      a3: v11,
      a4: v12);
    v34 = *(_QWORD *)(v4 + 32); /*0x107b2a6b5*/
    if ( v34 == 0 ) /*0x107b2a6bc*/
      std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x107b2a6f3*/
    (*(void (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v34 + 48LL))(a1: v34, a2: v38); /*0x107b2a6c8*/
    if ( (v38[0] & 1) != 0 ) /*0x107b2a6d2*/
    {
      v15 = v4; /*0x107b2a6d8*/
      v19 = (RBX::Memory **)&v39; /*0x107b2a6db*/
      goto LABEL_14; /*0x107b2a6e2*/
    }
    goto LABEL_12; /*0x107b2a6d2*/
  }
  v13 = RBX::StarterPlayerService::avatarJointUpgradeActive(this: v10); /*0x107b2a358*/
  v14 = v5; /*0x107b2a35b*/
  v15 = v4; /*0x107b2a35e*/
  v16 = 1; /*0x107b2a361*/
LABEL_16:
  v20 = v42[1]; /*0x107b2a42b*/
  if ( v42[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v42[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107b2a447*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(a1: v20); /*0x107b2a44f*/
    std::__shared_weak_count::__release_weak(this: v20); /*0x107b2a455*/
  }
  v21 = v16 == 0; /*0x107b2a45a*/
  v4 = v15; /*0x107b2a45c*/
  v5 = v14; /*0x107b2a45f*/
  v6 = v40; /*0x107b2a462*/
  a1 = v41; /*0x107b2a469*/
  if ( !v21 ) /*0x107b2a470*/
  {
LABEL_20:
    if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x107b2a47b*/
    {
      std::string::__init_copy_ctor_external(a1: &v45, a2: *((_QWORD *)a1 + 2), a3: *((_QWORD *)a1 + 1)); /*0x107b2a4a8*/
    }
    else
    {
      v46 = *((void **)a1 + 2); /*0x107b2a482*/
      v45 = *a1; /*0x107b2a48e*/
    }
    v47 = *(_OWORD *)v6; /*0x107b2a4b8*/
    *(_OWORD *)v6 = 0; /*0x107b2a4c1*/
    std::__function::__value_func<void ()(std::shared_ptr<RBX::ModelInstance>)>::__value_func[abi:ne200100]( /*0x107b2a4cb*/
      a1: v48,
      a2: v5);
    std::__function::__value_func<void ()(std::string)>::__value_func[abi:ne200100](a1: v50, a2: v4); /*0x107b2a4da*/
    v52 = v13; /*0x107b2a4df*/
    v44 = nullptr; /*0x107b2a4e3*/
    Aligned = RBX::Memory::allocateAligned(this: (RBX::Memory *)0xA0, a2: 0x10u, a3: v22); /*0x107b2a4f8*/
    v24 = Aligned; /*0x107b2a4fd*/
    v43[0] = Aligned; /*0x107b2a500*/
    v43[1] = 160; /*0x107b2a507*/
    v43[2] = 16; /*0x107b2a512*/
    if ( (v45 & 1) != 0 ) /*0x107b2a524*/
    {
      std::string::__init_copy_ctor_external(a1: Aligned, a2: v46, a3: *((_QWORD *)&v45 + 1)); /*0x107b2a54e*/
    }
    else
    {
      *(_QWORD *)(Aligned + 16) = v46; /*0x107b2a52d*/
      *(_OWORD *)Aligned = v45; /*0x107b2a538*/
    }
    *(_OWORD *)(v24 + 24) = v47; /*0x107b2a55e*/
    v47 = 0; /*0x107b2a565*/
    std::__function::__value_func<void ()(std::shared_ptr<RBX::ModelInstance>)>::__value_func[abi:ne200100]( /*0x107b2a570*/
      a1: v24 + 48,
      a2: v48);
    std::__function::__value_func<void ()(std::string)>::__value_func[abi:ne200100](a1: v24 + 96, a2: v50); /*0x107b2a57f*/
    *(_BYTE *)(v24 + 144) = v52; /*0x107b2a588*/
    v44 = (char *)RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<RBX::importAvatarFromFile_deprecated(std::string const&,std::weak_ptr<RBX::DataModel>,std::function<void ()(std::shared_ptr<RBX::ModelInstance>)>,std::function<void ()(std::string)>)::$_0>(RBX::importAvatarFromFile_deprecated(std::string const&,std::weak_ptr<RBX::DataModel>,std::function<void ()(std::shared_ptr<RBX::ModelInstance>)>,std::function<void ()(std::string)>)::$_0)::Callbacks /*0x107b2a59c*/
        + 4;
    RBX::TaskScheduler::submitAsyncTask(a1: v43, a2: 0, a3: v25, a4: v26, a5: v27, a6: v28); /*0x107b2a5a2*/
    RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v43, a2: v29); /*0x107b2a5ae*/
    if ( v51 == v50 ) /*0x107b2a5ba*/
    {
      v31 = 32; /*0x107b2a5c8*/
    }
    else
    {
      v31 = 40; /*0x107b2a5bc*/
      if ( v51 == nullptr ) /*0x107b2a5c4*/
      {
LABEL_31:
        if ( v49 == v48 ) /*0x107b2a5da*/
        {
          v32 = 32; /*0x107b2a5e8*/
        }
        else
        {
          v32 = 40; /*0x107b2a5dc*/
          if ( v49 == nullptr ) /*0x107b2a5e4*/
            goto LABEL_36; /*0x107b2a5e4*/
        }
        (*(void (**)(void))(*(_QWORD *)v49 + v32))(); /*0x107b2a5f0*/
LABEL_36:
        if ( *((_QWORD *)&v47 + 1) != 0 ) /*0x107b2a5fd*/
          std::__shared_weak_count::__release_weak(this: *((std::__shared_weak_count **)&v47 + 1)); /*0x107b2a5ff*/
        if ( (v45 & 1) != 0 ) /*0x107b2a60b*/
          operator delete(a1: (RBX::Memory *)v46, a2: v30); /*0x107b2a614*/
        return __stack_chk_guard; /*0x107b2a614*/
      }
    }
    (*(void (**)(void))(*(_QWORD *)v51 + v31))(); /*0x107b2a5d0*/
    goto LABEL_31; /*0x107b2a5d0*/
  }
  return __stack_chk_guard; /*0x107b2a62d*/
}

// Address: 0x107b2a76a | Name: __ZZN3RBX31importAvatarFromFile_deprecatedERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEENS0_8weak_ptrINS_9DataModelEEENS0_8functionIFvNS0_10shared_ptrINS_13ModelInstanceEEEEEENSC_IFvS6_EEEEN3$_0D1Ev
void __fastcall RBX::importAvatarFromFile_deprecated(std::string const&,std::weak_ptr<RBX::DataModel>,std::function<void ()(std::shared_ptr<RBX::ModelInstance>)>,std::function<void ()(std::string)>)::$_0::~$_0(
        __int64 a1,
        void *a2)
{
  _QWORD *v3; // rax
  _QWORD *v4; // rdi
  __int64 v5; // rax
  _QWORD *v6; // rdi
  __int64 v7; // rax
  std::__shared_weak_count *v8; // rdi

  v3 = (_QWORD *)(a1 + 96); /*0x107b2a773*/
  v4 = *(_QWORD **)(a1 + 128); /*0x107b2a777*/
  if ( v4 == v3 ) /*0x107b2a781*/
  {
    v5 = 32; /*0x107b2a78f*/
    goto LABEL_5; /*0x107b2a78f*/
  }
  v5 = 40; /*0x107b2a783*/
  if ( v4 != nullptr ) /*0x107b2a78b*/
LABEL_5:
    (*(void (__fastcall **)(_QWORD *))(*v4 + v5))(a1: v4); /*0x107b2a794*/
  v6 = *(_QWORD **)(a1 + 80); /*0x107b2a79a*/
  if ( v6 == (_QWORD *)(a1 + 48) ) /*0x107b2a7a5*/
  {
    v7 = 32; /*0x107b2a7b3*/
    goto LABEL_10; /*0x107b2a7b3*/
  }
  v7 = 40; /*0x107b2a7a7*/
  if ( v6 != nullptr ) /*0x107b2a7af*/
LABEL_10:
    (*(void (__fastcall **)(_QWORD *))(*v6 + v7))(a1: v6); /*0x107b2a7b8*/
  v8 = *(std::__shared_weak_count **)(a1 + 32); /*0x107b2a7be*/
  if ( v8 != nullptr ) /*0x107b2a7c5*/
    std::__shared_weak_count::__release_weak(this: v8); /*0x107b2a7c7*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x107b2a7cf*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x107b2a7e2*/
}

// Address: 0x107b2a7e7 | Name: __ZN3RBX20importAvatarFromFileERKNS_17ImportAvatarInputENSt3__18functionIFvNS3_10shared_ptrINS_13ModelInstanceEEEEEENS4_IFvNS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEEEE
__int64 __fastcall RBX::importAvatarFromFile(__int128 *a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v4; // rbx
  std::__shared_weak_count *v7; // rdi
  __int64 v8; // rdi
  RBX::StarterPlayerService *v9; // rax
  __int64 v10; // rdx
  __int64 v11; // rcx
  char v12; // r12
  __int64 v13; // rbx
  char v14; // r14
  __int64 v15; // rdi
  void *v16; // rsi
  RBX::Memory **v17; // rax
  std::__shared_weak_count *v18; // r13
  bool v19; // zf
  __int64 v20; // rax
  unsigned __int64 v21; // rdx
  __int64 Aligned; // rax
  __int64 v23; // rbx
  std::__shared_weak_count *v24; // rcx
  __int64 v25; // rdx
  __int64 v26; // rcx
  __int64 v27; // r8
  __int64 v28; // r9
  void *v29; // rsi
  void *v30; // rsi
  __int64 v31; // rax
  __int64 v32; // rax
  __int64 v34; // rdi
  _BYTE v35[24]; // [rsp+10h] [rbp-160h] BYREF
  _BYTE v36[16]; // [rsp+28h] [rbp-148h] BYREF
  char v37; // [rsp+38h] [rbp-138h] BYREF
  _BYTE v38[16]; // [rsp+40h] [rbp-130h] BYREF
  char v39; // [rsp+50h] [rbp-120h] BYREF
  __int64 v40; // [rsp+58h] [rbp-118h]
  std::__shared_weak_count *v41[2]; // [rsp+60h] [rbp-110h]
  _QWORD v42[3]; // [rsp+70h] [rbp-100h] BYREF
  char *v43; // [rsp+88h] [rbp-E8h]
  __int128 v44; // [rsp+90h] [rbp-E0h] BYREF
  void *v45; // [rsp+A0h] [rbp-D0h]
  std::__shared_weak_count *v46[2]; // [rsp+A8h] [rbp-C8h]
  __int128 v47; // [rsp+B8h] [rbp-B8h]
  _BYTE v48[32]; // [rsp+D0h] [rbp-A0h] BYREF
  _BYTE *v49; // [rsp+F0h] [rbp-80h]
  _BYTE v50[32]; // [rsp+100h] [rbp-70h] BYREF
  _BYTE *v51; // [rsp+120h] [rbp-50h]
  char v52; // [rsp+130h] [rbp-40h]

  v4 = a3; /*0x107b2a7fb*/
  if ( FFlag::AvatarGenerationIsAvatarJointUpgradeEnabled != 1 ) /*0x107b2a819*/
  {
    v12 = 0; /*0x107b2a881*/
    goto LABEL_20; /*0x107b2a884*/
  }
  *(_OWORD *)v41 = 0; /*0x107b2a81e*/
  v7 = *((std::__shared_weak_count **)a1 + 4); /*0x107b2a825*/
  v40 = a3; /*0x107b2a82c*/
  if ( v7 == nullptr /*0x107b2a854*/
    || (v41[1] = (std::__shared_weak_count *)std::__shared_weak_count::lock(this: v7), v41[1] == nullptr)
    || (v8 = *((_QWORD *)a1 + 3), v41[0] = (std::__shared_weak_count *)v8, v8 == 0) )
  {
    LOBYTE(a4) = (unsigned __int8)FLog::Photo2Avatar < 6u; /*0x107b2a897*/
    LOBYTE(a3) = (unsigned __int8)FLog::Photo2Avatar < 6u || (FLog::Photo2Avatar & 0xFE00) == 0; /*0x107b2a8a3*/
    if ( (_BYTE)a3 == 0 ) /*0x107b2a8a5*/
    {
      v42[0] = 0; /*0x107b2a8ab*/
      v42[1] = v35; /*0x107b2a8bd*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x107b2a8e7*/
        a1: FLog::Photo2Avatar,
        a2: qword_10D7FF200,
        a3: 2,
        a4: (unsigned int)"[FLog::Photo2Avatar] Datamodel is null.",
        a5: 39,
        a6: 1,
        0,
        v35);
    }
    std::string::basic_string[abi:ne200100]<0>(a1: v36, a2: "Unexpected error, DataModel is null.", a3, a4); /*0x107b2a8fa*/
    v15 = *(_QWORD *)(v4 + 32); /*0x107b2a8ff*/
    if ( v15 == 0 ) /*0x107b2a906*/
      std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x107b2ac13*/
    (*(void (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v15 + 48LL))(a1: v15, a2: v36); /*0x107b2a916*/
    if ( (v36[0] & 1) != 0 ) /*0x107b2a920*/
    {
      v13 = a2; /*0x107b2a927*/
      v17 = (RBX::Memory **)&v37; /*0x107b2a92a*/
LABEL_14:
      operator delete(a1: *v17, a2: v16); /*0x107b2a931*/
      goto LABEL_15; /*0x107b2a934*/
    }
LABEL_12:
    v13 = a2; /*0x107b2a922*/
LABEL_15:
    v14 = 0; /*0x107b2a939*/
    v12 = 0; /*0x107b2a93c*/
    goto LABEL_16; /*0x107b2a93c*/
  }
  v9 = (RBX::StarterPlayerService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::StarterPlayerService>(this: (RBX::ServiceProvider *)(v8 + 464)); /*0x107b2a85d*/
  if ( v9 == nullptr ) /*0x107b2a865*/
  {
    LOBYTE(v11) = (unsigned __int8)FLog::Photo2Avatar < 6u; /*0x107b2ab74*/
    LOBYTE(v10) = (unsigned __int8)FLog::Photo2Avatar < 6u || (FLog::Photo2Avatar & 0xFE00) == 0; /*0x107b2ab80*/
    if ( (_BYTE)v10 == 0 ) /*0x107b2ab82*/
    {
      v42[0] = 0; /*0x107b2ab88*/
      v42[1] = v35; /*0x107b2ab9a*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x107b2abc4*/
        a1: FLog::Photo2Avatar,
        a2: qword_10D7FF200,
        a3: 2,
        a4: (unsigned int)"[FLog::Photo2Avatar] StarterPlayer is null.",
        a5: 43,
        a6: 1,
        0,
        v35);
    }
    std::string::basic_string[abi:ne200100]<0>( /*0x107b2abd7*/
      a1: v38,
      a2: "Unexpected error, StarterPlayer is null.",
      a3: v10,
      a4: v11);
    v34 = *(_QWORD *)(v4 + 32); /*0x107b2abdc*/
    if ( v34 == 0 ) /*0x107b2abe3*/
      std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x107b2ac1a*/
    (*(void (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v34 + 48LL))(a1: v34, a2: v38); /*0x107b2abef*/
    if ( (v38[0] & 1) != 0 ) /*0x107b2abf9*/
    {
      v13 = a2; /*0x107b2abff*/
      v17 = (RBX::Memory **)&v39; /*0x107b2ac02*/
      goto LABEL_14; /*0x107b2ac09*/
    }
    goto LABEL_12; /*0x107b2abf9*/
  }
  v12 = RBX::StarterPlayerService::avatarJointUpgradeActive(this: v9); /*0x107b2a873*/
  v13 = a2; /*0x107b2a876*/
  v14 = 1; /*0x107b2a879*/
LABEL_16:
  v18 = v41[1]; /*0x107b2a93f*/
  if ( v41[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v41[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107b2a95b*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(a1: v18); /*0x107b2a964*/
    std::__shared_weak_count::__release_weak(this: v18); /*0x107b2a96a*/
  }
  v19 = v14 == 0; /*0x107b2a96f*/
  a2 = v13; /*0x107b2a972*/
  v4 = v40; /*0x107b2a975*/
  if ( !v19 ) /*0x107b2a97c*/
  {
LABEL_20:
    if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x107b2a986*/
    {
      std::string::__init_copy_ctor_external(a1: &v44, a2: *((_QWORD *)a1 + 2), a3: *((_QWORD *)a1 + 1)); /*0x107b2a9af*/
    }
    else
    {
      v45 = *((void **)a1 + 2); /*0x107b2a98c*/
      v44 = *a1; /*0x107b2a997*/
    }
    v20 = *((_QWORD *)a1 + 4); /*0x107b2a9b4*/
    *(_OWORD *)v46 = *(__int128 *)((char *)a1 + 24); /*0x107b2a9bd*/
    if ( v20 != 0 ) /*0x107b2a9c7*/
      _InterlockedIncrement64((volatile signed __int64 *)(v20 + 16)); /*0x107b2a9c9*/
    v47 = *(__int128 *)((char *)a1 + 40); /*0x107b2a9da*/
    std::__function::__value_func<void ()(std::shared_ptr<RBX::ModelInstance>)>::__value_func[abi:ne200100](a1: v48, a2); /*0x107b2a9e5*/
    std::__function::__value_func<void ()(std::string)>::__value_func[abi:ne200100](a1: v50, a2: v4); /*0x107b2a9f4*/
    v52 = v12; /*0x107b2a9f9*/
    v43 = nullptr; /*0x107b2a9fd*/
    Aligned = RBX::Memory::allocateAligned(this: (RBX::Memory *)0xB0, a2: 0x10u, a3: v21); /*0x107b2aa12*/
    v23 = Aligned; /*0x107b2aa17*/
    v42[0] = Aligned; /*0x107b2aa1a*/
    v42[1] = 176; /*0x107b2aa21*/
    v42[2] = 16; /*0x107b2aa2c*/
    if ( (v44 & 1) != 0 ) /*0x107b2aa3e*/
    {
      std::string::__init_copy_ctor_external(a1: Aligned, a2: v45, a3: *((_QWORD *)&v44 + 1)); /*0x107b2aa68*/
    }
    else
    {
      *(_QWORD *)(Aligned + 16) = v45; /*0x107b2aa47*/
      *(_OWORD *)Aligned = v44; /*0x107b2aa52*/
    }
    v24 = v46[1]; /*0x107b2aa74*/
    *(_OWORD *)(v23 + 24) = *(_OWORD *)v46; /*0x107b2aa7c*/
    if ( v24 != nullptr ) /*0x107b2aa83*/
      _InterlockedIncrement64((volatile signed __int64 *)v24 + 2); /*0x107b2aa85*/
    *(_OWORD *)(v23 + 40) = v47; /*0x107b2aa8d*/
    std::__function::__value_func<void ()(std::shared_ptr<RBX::ModelInstance>)>::__value_func[abi:ne200100]( /*0x107b2aa98*/
      a1: v23 + 64,
      a2: v48);
    std::__function::__value_func<void ()(std::string)>::__value_func[abi:ne200100](a1: v23 + 112, a2: v50); /*0x107b2aaa7*/
    *(_BYTE *)(v23 + 160) = v52; /*0x107b2aaaf*/
    v43 = (char *)RBX::unique_function<void ()(void),24ul,8ul,true>::unique_function<RBX::importAvatarFromFile(RBX::ImportAvatarInput const&,std::function<void ()(std::shared_ptr<RBX::ModelInstance>)>,std::function<void ()(std::string)>)::$_0>(RBX::importAvatarFromFile(RBX::ImportAvatarInput const&,std::function<void ()(std::shared_ptr<RBX::ModelInstance>)>,std::function<void ()(std::string)>)::$_0)::Callbacks /*0x107b2aac3*/
        + 4;
    RBX::TaskScheduler::submitAsyncTask(a1: v42, a2: 0, a3: v25, a4: v26, a5: v27, a6: v28); /*0x107b2aac9*/
    RBX::unique_function<void ()(void),24ul,8ul,true>::~unique_function(a1: (__int64)v42, a2: v29); /*0x107b2aad5*/
    if ( v51 == v50 ) /*0x107b2aae1*/
    {
      v31 = 32; /*0x107b2aaef*/
    }
    else
    {
      v31 = 40; /*0x107b2aae3*/
      if ( v51 == nullptr ) /*0x107b2aaeb*/
      {
LABEL_35:
        if ( v49 == v48 ) /*0x107b2ab01*/
        {
          v32 = 32; /*0x107b2ab0f*/
        }
        else
        {
          v32 = 40; /*0x107b2ab03*/
          if ( v49 == nullptr ) /*0x107b2ab0b*/
            goto LABEL_40; /*0x107b2ab0b*/
        }
        (*(void (**)(void))(*(_QWORD *)v49 + v32))(); /*0x107b2ab17*/
LABEL_40:
        if ( v46[1] != nullptr ) /*0x107b2ab24*/
          std::__shared_weak_count::__release_weak(this: v46[1]); /*0x107b2ab26*/
        if ( (v44 & 1) != 0 ) /*0x107b2ab32*/
          operator delete(a1: (RBX::Memory *)v45, a2: v30); /*0x107b2ab3b*/
        return __stack_chk_guard; /*0x107b2ab3b*/
      }
    }
    (*(void (**)(void))(*(_QWORD *)v51 + v31))(); /*0x107b2aaf7*/
    goto LABEL_35; /*0x107b2aaf7*/
  }
  return __stack_chk_guard; /*0x107b2ab54*/
}

// Address: 0x107b2ac90 | Name: __ZZN3RBX20importAvatarFromFileERKNS_17ImportAvatarInputENSt3__18functionIFvNS3_10shared_ptrINS_13ModelInstanceEEEEEENS4_IFvNS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEEEEEN3$_0D1Ev
void __fastcall RBX::importAvatarFromFile(RBX::ImportAvatarInput const&,std::function<void ()(std::shared_ptr<RBX::ModelInstance>)>,std::function<void ()(std::string)>)::$_0::~$_0(
        __int64 a1,
        void *a2)
{
  _QWORD *v3; // rax
  _QWORD *v4; // rdi
  __int64 v5; // rax
  _QWORD *v6; // rdi
  __int64 v7; // rax
  std::__shared_weak_count *v8; // rdi

  v3 = (_QWORD *)(a1 + 112); /*0x107b2ac99*/
  v4 = *(_QWORD **)(a1 + 144); /*0x107b2ac9d*/
  if ( v4 == v3 ) /*0x107b2aca7*/
  {
    v5 = 32; /*0x107b2acb5*/
    goto LABEL_5; /*0x107b2acb5*/
  }
  v5 = 40; /*0x107b2aca9*/
  if ( v4 != nullptr ) /*0x107b2acb1*/
LABEL_5:
    (*(void (__fastcall **)(_QWORD *))(*v4 + v5))(a1: v4); /*0x107b2acba*/
  v6 = *(_QWORD **)(a1 + 96); /*0x107b2acc0*/
  if ( v6 == (_QWORD *)(a1 + 64) ) /*0x107b2accb*/
  {
    v7 = 32; /*0x107b2acd9*/
    goto LABEL_10; /*0x107b2acd9*/
  }
  v7 = 40; /*0x107b2accd*/
  if ( v6 != nullptr ) /*0x107b2acd5*/
LABEL_10:
    (*(void (__fastcall **)(_QWORD *))(*v6 + v7))(a1: v6); /*0x107b2acde*/
  v8 = *(std::__shared_weak_count **)(a1 + 32); /*0x107b2ace4*/
  if ( v8 != nullptr ) /*0x107b2aceb*/
    std::__shared_weak_count::__release_weak(this: v8); /*0x107b2aced*/
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x107b2acf5*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x107b2ad08*/
}

// Address: 0x107b2b26e | Name: __ZN3RBXL24importAvatarFromFileImplENSt3__110shared_ptrINS_18AvatarImportParamsEEE
__int64 __fastcall RBX::importAvatarFromFileImpl(_QWORD *a1)
{
  __int64 v2; // r12
  volatile signed __int64 *v3; // r14
  unsigned int v4; // esi
  __int64 v5; // r15
  __int64 v6; // rdi
  __int64 v7; // rsi
  __int64 v8; // rdx
  __int64 v9; // rcx
  unsigned int v10; // edx
  __int64 v11; // rdx
  __int64 v12; // rdi
  void *v13; // rsi
  std::__shared_weak_count *v14; // r14
  __int64 v15; // rdx
  __int64 v16; // rcx
  RBX::AssetImport::ImportManager *v17; // r14
  RBX::AssetImport::Node *v18; // rdi
  __int64 v19; // rcx
  __int64 v20; // r15
  std::__shared_weak_count *v21; // rdi
  std::__shared_weak_count *v22; // rax
  RBX::EngineContext *v23; // r15
  __int64 v24; // rax
  char v25; // cl
  RBX::AssetImport::SettingsStore *v26; // rdi
  __int64 RootSettings; // rax
  int v28; // ecx
  __int64 v29; // rbx
  __int64 v30; // rdi
  void *v31; // rsi
  __int64 Root; // rax
  __int64 v33; // rcx
  std::__shared_weak_count *v34; // r12
  RBX::AssetImport::SettingsStore *v35; // r13
  __int64 v36; // rdx
  __int64 v37; // rcx
  __int64 v38; // rdx
  __int64 v39; // rcx
  void *v40; // rsi
  std::__shared_weak_count *v41; // rdi
  __int128 v42; // xmm0
  __int64 v43; // rax
  __int64 v44; // rax
  __int64 v45; // rbx
  __int64 v46; // rdi
  void *v47; // rsi
  std::__shared_weak_count *v48; // rbx
  std::__shared_weak_count *v49; // rbx
  std::__shared_weak_count *v50; // rbx
  std::__shared_weak_count *v51; // rbx
  std::__shared_weak_count *v52; // rbx
  _BYTE v54[16]; // [rsp+30h] [rbp-190h] BYREF
  void *v55; // [rsp+40h] [rbp-180h]
  _BYTE v56[16]; // [rsp+48h] [rbp-178h] BYREF
  void *v57; // [rsp+58h] [rbp-168h]
  std::__shared_weak_count *v58[2]; // [rsp+60h] [rbp-160h]
  std::__shared_weak_count *v59[2]; // [rsp+70h] [rbp-150h] BYREF
  std::__shared_weak_count *v60[2]; // [rsp+80h] [rbp-140h] BYREF
  __int128 v61; // [rsp+90h] [rbp-130h] BYREF
  __int128 v62; // [rsp+A0h] [rbp-120h]
  __int128 v63; // [rsp+B0h] [rbp-110h]
  char v64; // [rsp+C0h] [rbp-100h]
  __int128 v65; // [rsp+D0h] [rbp-F0h] BYREF
  void *v66; // [rsp+E0h] [rbp-E0h]
  __int64 v67; // [rsp+E8h] [rbp-D8h] BYREF
  __int128 *v68; // [rsp+F0h] [rbp-D0h]
  std::__shared_weak_count *v69[2]; // [rsp+110h] [rbp-B0h] BYREF
  std::__shared_weak_count *v70[2]; // [rsp+120h] [rbp-A0h]
  std::__shared_weak_count *v71[2]; // [rsp+130h] [rbp-90h] BYREF
  std::__shared_weak_count *v72[2]; // [rsp+140h] [rbp-80h]
  std::__shared_weak_count *v73[2]; // [rsp+150h] [rbp-70h]
  _QWORD v74[4]; // [rsp+160h] [rbp-60h] BYREF
  _QWORD *v75; // [rsp+180h] [rbp-40h]

  v2 = *a1; /*0x107b2b293*/
  v3 = (volatile signed __int64 *)a1[1]; /*0x107b2b29d*/
  if ( v3 != nullptr ) /*0x107b2b2ab*/
    _InterlockedIncrement64(v3 + 1); /*0x107b2b2ad*/
  v4 = *(unsigned __int8 *)(v2 + 96); /*0x107b2b2b2*/
  v5 = v2 + 97; /*0x107b2b2b8*/
  if ( (v4 & 1) != 0 ) /*0x107b2b2c1*/
  {
    v6 = *(_QWORD *)(v2 + 112); /*0x107b2b2c3*/
    v7 = *(_QWORD *)(v2 + 104); /*0x107b2b2c8*/
  }
  else
  {
    v7 = v4 >> 1; /*0x107b2b2cf*/
    v6 = v2 + 97; /*0x107b2b2d1*/
  }
  if ( (RBX::AssetImport::Utils::getSceneFileTypeFromPath(a1: v6, a2: v7) & 0xFFFFFFFE) == 2 ) /*0x107b2b2df*/
  {
    v10 = *(unsigned __int8 *)(v2 + 96); /*0x107b2b2e1*/
    if ( (v10 & 1) != 0 ) /*0x107b2b2ea*/
    {
      v5 = *(_QWORD *)(v2 + 112); /*0x107b2b2ec*/
      v11 = *(_QWORD *)(v2 + 104); /*0x107b2b2f1*/
    }
    else
    {
      v11 = v10 >> 1; /*0x107b2b348*/
    }
    RBX::AssetImport::Utils::createImportObjectsGltf(a1: v71, a2: v5, a3: v11, a4: 65793); /*0x107b2b359*/
    v61 = *(_OWORD *)v71; /*0x107b2b36d*/
    v62 = *(_OWORD *)v72; /*0x107b2b374*/
    v63 = *(_OWORD *)v73; /*0x107b2b37b*/
    v64 = 1; /*0x107b2b382*/
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v71, a2: "Unsupported file format.", a3: v8, a4: v9); /*0x107b2b306*/
    v12 = *(_QWORD *)(v2 + 80); /*0x107b2b30b*/
    if ( v12 == 0 ) /*0x107b2b313*/
      std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x107b2b9d8*/
    (*(void (__fastcall **)(__int64, std::__shared_weak_count **))(*(_QWORD *)v12 + 48LL))(a1: v12, a2: v71); /*0x107b2b323*/
    if ( ((__int64)v71[0] & 1) != 0 ) /*0x107b2b32d*/
      operator delete(a1: v72[0], a2: v13); /*0x107b2b333*/
    LOBYTE(v61) = 0; /*0x107b2b33a*/
    v64 = 0; /*0x107b2b340*/
  }
  if ( v3 != nullptr && _InterlockedExchangeAdd64(v3 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107b2b39e*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v3 + 16))(a1: v3); /*0x107b2b3a6*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v3); /*0x107b2b3ac*/
  }
  if ( v64 != 0 ) /*0x107b2b3b8*/
  {
    *(_OWORD *)v71 = v61; /*0x107b2b3d7*/
    v61 = 0; /*0x107b2b3de*/
    *(_OWORD *)v72 = v62; /*0x107b2b3e5*/
    v62 = 0; /*0x107b2b3e9*/
    *(_OWORD *)v73 = v63; /*0x107b2b3f0*/
    v63 = 0; /*0x107b2b3f3*/
    RBX::make_shared<RBX::AssetImport::SettingsStore,std::shared_ptr<RBX::AssetImport::ImportManager> &,std::shared_ptr<RBX::AssetImport::BaseParser> &>( /*0x107b2b408*/
      a1: &v67,
      a2: v71);
    std::shared_ptr<RBX::AssetImport::SettingsStore>::operator=[abi:ne200100](a1: *a1 + 152LL, a2: &v67); /*0x107b2b41f*/
    v14 = (std::__shared_weak_count *)v68; /*0x107b2b424*/
    if ( v68 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v68 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107b2b43d*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x107b2b445*/
      std::__shared_weak_count::__release_weak(this: v14); /*0x107b2b44b*/
    }
    *(_DWORD *)(RBX::AssetImport::SettingsStore::getRootSettings(this: *(RBX::AssetImport::SettingsStore **)(*a1 + 152LL)) /*0x107b2b45f*/
              + 172) = 1;
    if ( v71[0] == nullptr ) /*0x107b2b471*/
    {
      LOBYTE(v16) = (unsigned __int8)FLog::Photo2Avatar < 6u; /*0x107b2b5a2*/
      LOBYTE(v15) = (unsigned __int8)FLog::Photo2Avatar < 6u || (FLog::Photo2Avatar & 0xFE00) == 0; /*0x107b2b5ae*/
      if ( (_BYTE)v15 == 0 ) /*0x107b2b5b0*/
      {
        v67 = 0; /*0x107b2b5b6*/
        v68 = &v65; /*0x107b2b5c8*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x107b2b5f2*/
          a1: FLog::Photo2Avatar,
          a2: qword_10D7FF200,
          a3: 2,
          a4: (unsigned int)"[FLog::Photo2Avatar] ImportManager is null.",
          a5: 43,
          a6: 1,
          0,
          &v65);
      }
      v29 = *a1; /*0x107b2b5f7*/
      std::string::basic_string[abi:ne200100]<0>(a1: v54, a2: "Unexpected error.", a3: v15, a4: v16); /*0x107b2b608*/
      v30 = *(_QWORD *)(v29 + 80); /*0x107b2b60d*/
      if ( v30 == 0 ) /*0x107b2b614*/
        std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x107b2b9df*/
      (*(void (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v30 + 48LL))(a1: v30, a2: v54); /*0x107b2b624*/
      if ( (v54[0] & 1) != 0 ) /*0x107b2b62e*/
        operator delete(a1: (RBX::Memory *)v55, a2: v31); /*0x107b2b63b*/
      goto LABEL_73; /*0x107b2b640*/
    }
    std::shared_ptr<RBX::AssetImport::ImportManager>::operator=[abi:ne200100](a1: *a1 + 136LL, a2: v71); /*0x107b2b486*/
    v17 = *(RBX::AssetImport::ImportManager **)(*a1 + 136LL); /*0x107b2b48e*/
    RBX::AssetImport::SettingsStore::getRootSettings(this: *(RBX::AssetImport::SettingsStore **)(*a1 + 152LL)); /*0x107b2b49c*/
    v18 = *(RBX::AssetImport::Node **)(*a1 + 136LL); /*0x107b2b4aa*/
    v19 = *(_QWORD *)(*a1 + 160LL); /*0x107b2b4b1*/
    *(_OWORD *)v58 = *(_OWORD *)(*a1 + 152LL); /*0x107b2b4bf*/
    if ( v19 != 0 ) /*0x107b2b4c9*/
      _InterlockedIncrement64((volatile signed __int64 *)(v19 + 8)); /*0x107b2b4cb*/
    RBX::performLayeredClothingChecks(a1: v18); /*0x107b2b4da*/
    if ( v58[1] != nullptr /*0x107b2b4fb*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v58[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v58[1] + 16LL))(a1: v58[1]); /*0x107b2b503*/
      std::__shared_weak_count::__release_weak(this: v58[1]); /*0x107b2b509*/
    }
    v20 = *a1; /*0x107b2b50e*/
    *(_OWORD *)v70 = 0; /*0x107b2b514*/
    v21 = *(std::__shared_weak_count **)(v20 + 128); /*0x107b2b51b*/
    if ( v21 != nullptr /*0x107b2b546*/
      && (v70[1] = (std::__shared_weak_count *)std::__shared_weak_count::lock(this: v21), v70[1] != nullptr)
      && (v22 = *(std::__shared_weak_count **)(v20 + 120), v70[0] = v22, v22 != nullptr) )
    {
      v23 = (RBX::EngineContext *)(*((_QWORD *)v22 + 69) & 0xFFFFFFFFFFFFFFF8LL); /*0x107b2b54f*/
    }
    else
    {
      v23 = nullptr; /*0x107b2b555*/
    }
    if ( FFlag::AvatarGenerationIsAvatarJointUpgradeEnabled == 1 ) /*0x107b2b55f*/
    {
      v24 = *a1; /*0x107b2b565*/
      v25 = *(_BYTE *)(*a1 + 400LL); /*0x107b2b568*/
      *(_BYTE *)(*(_QWORD *)(*a1 + 136LL) + 64LL) = v25; /*0x107b2b575*/
      v26 = *(RBX::AssetImport::SettingsStore **)(v24 + 152); /*0x107b2b578*/
      if ( v25 == 1 ) /*0x107b2b582*/
      {
        RootSettings = RBX::AssetImport::SettingsStore::getRootSettings(this: v26); /*0x107b2b588*/
        v28 = 0; /*0x107b2b58d*/
      }
      else
      {
        RootSettings = RBX::AssetImport::SettingsStore::getRootSettings(this: v26); /*0x107b2b645*/
        v28 = 1; /*0x107b2b64a*/
      }
      *(_DWORD *)(RootSettings + 180) = v28; /*0x107b2b64f*/
    }
    Root = RBX::AssetImport::ImportManager::getRoot(this: v17); /*0x107b2b658*/
    v33 = *(_QWORD *)(*a1 + 160LL); /*0x107b2b660*/
    *(_OWORD *)v59 = *(_OWORD *)(*a1 + 152LL); /*0x107b2b66e*/
    if ( v33 != 0 ) /*0x107b2b678*/
      _InterlockedIncrement64((volatile signed __int64 *)(v33 + 16)); /*0x107b2b67a*/
    RBX::AssetImport::constructImportDataTree(a1: v69, a2: v23, a3: Root, a4: v59, a5: v72[0]); /*0x107b2b697*/
    if ( v59[1] != nullptr ) /*0x107b2b6a6*/
      std::__shared_weak_count::__release_weak(this: v59[1]); /*0x107b2b6a8*/
    *(_OWORD *)v60 = *(_OWORD *)v69; /*0x107b2b6bb*/
    if ( v69[1] != nullptr ) /*0x107b2b6c5*/
      _InterlockedIncrement64((volatile signed __int64 *)v69[1] + 1); /*0x107b2b6c7*/
    RBX::AssetImport::Utils::uncheckErroredNodesRecursive(a1: v60); /*0x107b2b6d3*/
    v34 = v60[1]; /*0x107b2b6d8*/
    if ( v60[1] != nullptr /*0x107b2b6f5*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v60[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v34 + 16LL))(a1: v34); /*0x107b2b6fe*/
      std::__shared_weak_count::__release_weak(this: v34); /*0x107b2b704*/
    }
    RBX::getMeshesForPublish(this: (RBX *)&v67, a2: (RBX::AssetImport::Node **)v17); /*0x107b2b713*/
    std::__hash_table<std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::__unordered_map_hasher<RBX::AssetImport::Core::UploadNodeId,std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::hash<RBX::AssetImport::Core::UploadNodeId>,std::equal_to<RBX::AssetImport::Core::UploadNodeId>,true>,std::__unordered_map_equal<RBX::AssetImport::Core::UploadNodeId,std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::equal_to<RBX::AssetImport::Core::UploadNodeId>,std::hash<RBX::AssetImport::Core::UploadNodeId>,true>,std::allocator<std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>>>::__move_assign( /*0x107b2b72a*/
      a1: *a1 + 168LL,
      a2: &v67);
    std::__hash_table<std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::__unordered_map_hasher<RBX::AssetImport::Core::UploadNodeId,std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::hash<RBX::AssetImport::Core::UploadNodeId>,std::equal_to<RBX::AssetImport::Core::UploadNodeId>,true>,std::__unordered_map_equal<RBX::AssetImport::Core::UploadNodeId,std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::equal_to<RBX::AssetImport::Core::UploadNodeId>,std::hash<RBX::AssetImport::Core::UploadNodeId>,true>,std::allocator<std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>>>::~__hash_table(a1: &v67); /*0x107b2b732*/
    v35 = *(RBX::AssetImport::SettingsStore **)(*a1 + 152LL); /*0x107b2b73a*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v65, a2: "", a3: v36, a4: v37); /*0x107b2b74f*/
    RBX::getTexturesForPublish(a1: (__int64)&v67, a2: v23, a3: (RBX::AssetImport::Node **)v17, a4: v35, a5: &v65); /*0x107b2b76e*/
    std::__hash_table<std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::__unordered_map_hasher<RBX::AssetImport::Core::UploadNodeId,std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::hash<RBX::AssetImport::Core::UploadNodeId>,std::equal_to<RBX::AssetImport::Core::UploadNodeId>,true>,std::__unordered_map_equal<RBX::AssetImport::Core::UploadNodeId,std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::equal_to<RBX::AssetImport::Core::UploadNodeId>,std::hash<RBX::AssetImport::Core::UploadNodeId>,true>,std::allocator<std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>>>::__move_assign( /*0x107b2b785*/
      a1: *a1 + 208LL,
      a2: &v67);
    std::__hash_table<std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::__unordered_map_hasher<RBX::AssetImport::Core::UploadNodeId,std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::hash<RBX::AssetImport::Core::UploadNodeId>,std::equal_to<RBX::AssetImport::Core::UploadNodeId>,true>,std::__unordered_map_equal<RBX::AssetImport::Core::UploadNodeId,std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>,std::equal_to<RBX::AssetImport::Core::UploadNodeId>,std::hash<RBX::AssetImport::Core::UploadNodeId>,true>,std::allocator<std::__hash_value_type<RBX::AssetImport::Core::UploadNodeId,std::shared_ptr<RBX::ReadOnlySharedBuffer const>>>>::~__hash_table(a1: &v67); /*0x107b2b78d*/
    if ( (v65 & 1) != 0 ) /*0x107b2b799*/
      operator delete(a1: (RBX::Memory *)v66, a2: v40); /*0x107b2b7a2*/
    v41 = v70[0]; /*0x107b2b7a7*/
    if ( v70[0] == nullptr ) /*0x107b2b7b1*/
    {
      LOBYTE(v39) = (unsigned __int8)FLog::Photo2Avatar < 6u; /*0x107b2b820*/
      LOBYTE(v38) = (unsigned __int8)FLog::Photo2Avatar < 6u || (FLog::Photo2Avatar & 0xFE00) == 0; /*0x107b2b82c*/
      if ( (_BYTE)v38 == 0 ) /*0x107b2b82e*/
      {
        v67 = 0; /*0x107b2b834*/
        v68 = &v65; /*0x107b2b83f*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x107b2b869*/
          a1: FLog::Photo2Avatar,
          a2: qword_10D7FF200,
          a3: 2,
          a4: (unsigned int)"[FLog::Photo2Avatar] Datamodel is null.",
          a5: 39,
          a6: 1,
          0,
          &v65);
      }
      v45 = *a1; /*0x107b2b86e*/
      std::string::basic_string[abi:ne200100]<0>(a1: v56, a2: "Unexpected error.", a3: v38, a4: v39); /*0x107b2b87f*/
      v46 = *(_QWORD *)(v45 + 80); /*0x107b2b884*/
      if ( v46 == 0 ) /*0x107b2b88b*/
        std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x107b2b9e6*/
      (*(void (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v46 + 48LL))(a1: v46, a2: v56); /*0x107b2b89b*/
      if ( (v56[0] & 1) != 0 ) /*0x107b2b8a5*/
        operator delete(a1: (RBX::Memory *)v57, a2: v47); /*0x107b2b8ae*/
      goto LABEL_67; /*0x107b2b8b3*/
    }
    v42 = *(_OWORD *)a1; /*0x107b2b7b3*/
    v43 = a1[1]; /*0x107b2b7b6*/
    if ( v43 != 0 ) /*0x107b2b7bd*/
      _InterlockedIncrement64((volatile signed __int64 *)(v43 + 8)); /*0x107b2b7bf*/
    v74[0] = &off_10CBB6FB0; /*0x107b2b7cf*/
    *(_OWORD *)&v74[1] = v42; /*0x107b2b7d2*/
    v75 = v74; /*0x107b2b7e1*/
    RBX::DataModel::submitTask(a1: v41, a2: v74, a3: 1); /*0x107b2b7ed*/
    if ( v75 == v74 ) /*0x107b2b7f9*/
    {
      v44 = 32; /*0x107b2b8b5*/
    }
    else
    {
      v44 = 40; /*0x107b2b7ff*/
      if ( v75 == nullptr ) /*0x107b2b807*/
      {
LABEL_67:
        v48 = v69[1]; /*0x107b2b8c0*/
        if ( v69[1] != nullptr /*0x107b2b8dc*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v69[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v48 + 16LL))(a1: v48); /*0x107b2b8e4*/
          std::__shared_weak_count::__release_weak(this: v48); /*0x107b2b8ea*/
        }
        v49 = v70[1]; /*0x107b2b8ef*/
        if ( v70[1] != nullptr /*0x107b2b90b*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v70[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v49 + 16LL))(a1: v49); /*0x107b2b913*/
          std::__shared_weak_count::__release_weak(this: v49); /*0x107b2b919*/
        }
LABEL_73:
        v50 = v73[1]; /*0x107b2b91e*/
        if ( v73[1] != nullptr /*0x107b2b937*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v73[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v50 + 16LL))(a1: v50); /*0x107b2b93f*/
          std::__shared_weak_count::__release_weak(this: v50); /*0x107b2b945*/
        }
        v51 = v72[1]; /*0x107b2b94a*/
        if ( v72[1] != nullptr /*0x107b2b963*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v72[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v51 + 16LL))(a1: v51); /*0x107b2b96b*/
          std::__shared_weak_count::__release_weak(this: v51); /*0x107b2b971*/
        }
        v52 = v71[1]; /*0x107b2b976*/
        if ( v71[1] != nullptr /*0x107b2b992*/
          && _InterlockedExchangeAdd64((volatile signed __int64 *)v71[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v52 + 16LL))(a1: v52); /*0x107b2b99a*/
          std::__shared_weak_count::__release_weak(this: v52); /*0x107b2b9a0*/
        }
        goto LABEL_82; /*0x107b2b9a0*/
      }
    }
    (*(void (**)(void))(*v75 + v44))(); /*0x107b2b8bd*/
    goto LABEL_67; /*0x107b2b8bd*/
  }
LABEL_82:
  std::__optional_destruct_base<RBX::AssetImport::Utils::ImportObjects,false>::~__optional_destruct_base[abi:ne200100](a1: &v61); /*0x107b2b9a5*/
  return __stack_chk_guard; /*0x107b2b9c1*/
}

// Address: 0x107c9b6a5 | Name: __ZN3RBX33isExplicitlyIgnoringCFrameChangesEPKNS_8InstanceE
char __fastcall RBX::isExplicitlyIgnoringCFrameChanges(RBX *this, const RBX::Instance *a2)
{
  RBX::PVInstance *i; // rbx
  __int64 v3; // r14
  __int64 v4; // rax

  for ( i = *((RBX::PVInstance **)this + 13); ; i = *((RBX::PVInstance **)i + 13) ) /*0x107c9b6ac*/
  {
    if ( i == nullptr ) /*0x107c9b6b3*/
      return 0; /*0x107c9b6ee*/
    v3 = *((_QWORD *)i + 3); /*0x107c9b6b5*/
    v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::PVInstance>(a1: this); /*0x107c9b6b9*/
    if ( *(unsigned __int16 *)(v3 + 440) - (unsigned int)*(unsigned __int16 *)(v4 + 440) <= *(unsigned __int16 *)(v4 + 442) /*0x107c9b6e4*/
      && (unsigned __int8)RBX::PVInstance::isPivoting(this: i) != 0 )
    {
      break; /*0x107c9b6e4*/
    }
  }
  return 1; /*0x107c9b6f2*/
}

// Address: 0x107fb72ab | Name: __ZN3RBXL17isFromValidDomainENS_10StringViewES0_S0__0
__int64 __fastcall RBX::isFromValidDomain(__int64 a1, __int64 a2, __int64 a3, int a4, __int64 a5, __int64 a6)
{
  char *v9; // rsi
  void *v10; // rsi
  unsigned int isSubdomainOf; // r15d
  _BYTE v13[16]; // [rsp+20h] [rbp-D0h] BYREF
  void *v14; // [rsp+30h] [rbp-C0h]
  char v15; // [rsp+38h] [rbp-B8h]
  void *v16; // [rsp+48h] [rbp-A8h]
  char v17; // [rsp+50h] [rbp-A0h]
  void *v18; // [rsp+60h] [rbp-90h]
  char v19; // [rsp+68h] [rbp-88h]
  void *v20; // [rsp+78h] [rbp-78h]
  char v21; // [rsp+80h] [rbp-70h]
  void *v22; // [rsp+90h] [rbp-60h]
  __int64 v23; // [rsp+A0h] [rbp-50h]
  __int64 v24; // [rsp+A8h] [rbp-48h]
  __int128 v25; // [rsp+B0h] [rbp-40h] BYREF
  char *v26; // [rsp+C0h] [rbp-30h]

  v24 = a6; /*0x107fb72bf*/
  v23 = a5; /*0x107fb72c3*/
  RBX::Url::fromString(this: (RBX::Url *)v13); /*0x107fb72e0*/
  if ( a1 != 0 ) /*0x107fb72e8*/
  {
    std::string::basic_string[abi:ne200100](a1: &v25, a2: a1, a3: a2); /*0x107fb72f4*/
    if ( (v25 & 1) != 0 ) /*0x107fb72fd*/
      v9 = v26; /*0x107fb731a*/
    else
      v9 = (char *)&v25 + 1; /*0x107fb72ff*/
  }
  else
  {
    v9 = (char *)&v25 + 1; /*0x107fb7308*/
    v25 = 0; /*0x107fb730c*/
    v26 = nullptr; /*0x107fb7310*/
  }
  isSubdomainOf = RBX::Url::isSubdomainOf(this: (RBX::Url *)v13, a2: v9); /*0x107fb732a*/
  if ( (v25 & 1) != 0 ) /*0x107fb7331*/
    operator delete(a1: (RBX::Memory *)v26, a2: v10); /*0x107fb7337*/
  if ( (v21 & 1) != 0 ) /*0x107fb7340*/
    operator delete(a1: (RBX::Memory *)v22, a2: v10); /*0x107fb7346*/
  if ( (v19 & 1) != 0 ) /*0x107fb7352*/
    operator delete(a1: (RBX::Memory *)v20, a2: v10); /*0x107fb7358*/
  if ( (v17 & 1) != 0 ) /*0x107fb7364*/
    operator delete(a1: (RBX::Memory *)v18, a2: v10); /*0x107fb736d*/
  if ( (v15 & 1) != 0 ) /*0x107fb7379*/
    operator delete(a1: (RBX::Memory *)v16, a2: v10); /*0x107fb7382*/
  if ( (v13[0] & 1) != 0 ) /*0x107fb738e*/
    operator delete(a1: (RBX::Memory *)v14, a2: v10); /*0x107fb7397*/
  if ( (_BYTE)isSubdomainOf == 0 /*0x107fb73b6*/
    && (unsigned __int8)FLog::StudioCookieManager >= 6u
    && BYTE1(FLog::StudioCookieManager) >= 3u )
  {
    FLog::FastLogFormatted( /*0x107fb73e6*/
      a1: FLog::StudioCookieManager,
      a2: (_DWORD)qword_10D87B8C0,
      a3: (unsigned int)"[FLog::StudioCookieManager] %.*s cookies from '%.*s' in '%.*s' is prohibited",
      a4: v24,
      a5: v23,
      a6: a4);
  }
  return isSubdomainOf; /*0x107fb73ee*/
}

// Address: 0x108370e8a | Name: __ZN3RBX7isErrorENS_13HttpErrorCodeERNS_12HttpResponseE
bool __fastcall RBX::isError(int a1, __int64 a2)
{
  return a1 != 0 || *(_DWORD *)(a2 + 24) >= 400; /*0x108370e9f*/
}

// Address: 0x1083716c8 | Name: __ZN3RBXL25internalPublishPlaceAsyncERNS_9DataModelERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEERKNS_9ContentIdESA_x
__int64 __fastcall RBX::internalPublishPlaceAsync(__int64 a1, unsigned __int8 *a2, __int64 a3, __int64 a4, __int64 a5)
{
  unsigned __int8 *v7; // r13
  unsigned int v8; // edx
  __int64 v9; // rdx
  char *v10; // r8
  char *v11; // r15
  signed __int64 v12; // r14
  char *v13; // rbx
  char *v14; // r13
  bool v15; // r15
  int v16; // r12d
  const void *v17; // r13
  size_t v18; // rdx
  char *v19; // rax
  const char *v20; // rcx
  __int64 v21; // r12
  unsigned int v22; // eax
  std::__shared_weak_count *v23; // rax
  __int64 v24; // rax
  DRolloutFlag *v25; // rdi
  __int64 v26; // rdx
  __int64 v27; // rcx
  __int64 v28; // rax
  void *v29; // rsi
  __int64 v30; // rbx
  void *v31; // rsi
  unsigned __int64 v32; // rsi
  std::__shared_weak_count *v33; // rbx
  volatile signed __int64 *v34; // r14
  __int64 v35; // rax
  __int64 v36; // rax
  __int64 v37; // rax
  __int64 v38; // rax
  _QWORD v40[16]; // [rsp+10h] [rbp-250h] BYREF
  _WORD v41[24]; // [rsp+90h] [rbp-1D0h] BYREF
  _BYTE v42[72]; // [rsp+C0h] [rbp-1A0h] BYREF
  _BYTE *v43; // [rsp+108h] [rbp-158h] BYREF
  _BYTE v44[16]; // [rsp+110h] [rbp-150h] BYREF
  void *v45; // [rsp+120h] [rbp-140h]
  unsigned __int8 *v46; // [rsp+128h] [rbp-138h]
  __int64 v47; // [rsp+130h] [rbp-130h]
  __int64 v48; // [rsp+138h] [rbp-128h]
  __int64 v49; // [rsp+140h] [rbp-120h]
  char *v50; // [rsp+148h] [rbp-118h]
  std::__shared_weak_count *v51[2]; // [rsp+150h] [rbp-110h] BYREF
  void *v52; // [rsp+160h] [rbp-100h]
  char v53; // [rsp+16Fh] [rbp-F1h] BYREF
  char v54; // [rsp+170h] [rbp-F0h] BYREF
  char *v55; // [rsp+190h] [rbp-D0h]
  char v56; // [rsp+1A0h] [rbp-C0h] BYREF
  char *v57; // [rsp+1C0h] [rbp-A0h]
  _QWORD v58[2]; // [rsp+1D0h] [rbp-90h] BYREF
  volatile signed __int64 *v59; // [rsp+1E0h] [rbp-80h]
  _QWORD *v60; // [rsp+1F0h] [rbp-70h]
  _QWORD v61[4]; // [rsp+200h] [rbp-60h] BYREF
  _QWORD *v62; // [rsp+220h] [rbp-40h]

  v7 = a2; /*0x1083716e2*/
  v48 = a1; /*0x1083716e5*/
  v8 = *(unsigned __int8 *)(a3 + 8); /*0x1083716fa*/
  if ( (v8 & 1) != 0 ) /*0x108371701*/
  {
    v9 = *(_QWORD *)(a3 + 16); /*0x108371703*/
    v10 = *(char **)(a3 + 24); /*0x108371707*/
  }
  else
  {
    v10 = (char *)(a3 + 9); /*0x10837170d*/
    v9 = v8 >> 1; /*0x108371711*/
  }
  if ( (kIsSavedVersionOnlyFalse_lower & 1) != 0 ) /*0x10837171f*/
  {
    v11 = (char *)qword_10D4F57C8; /*0x108371721*/
    v12 = qword_10D4F57C0; /*0x108371728*/
  }
  else
  {
    v12 = (unsigned __int8)kIsSavedVersionOnlyFalse_lower >> 1; /*0x108371731*/
    v11 = (char *)&unk_10D4F57B9; /*0x108371734*/
  }
  if ( v12 != 0 ) /*0x10837173e*/
  {
    v47 = a5; /*0x108371740*/
    v46 = a2; /*0x108371747*/
    v13 = &v10[v9]; /*0x10837174e*/
    if ( v9 >= v12 ) /*0x108371755*/
    {
      v49 = a4; /*0x108371764*/
      v16 = *v11; /*0x10837176b*/
      v50 = v10; /*0x10837176f*/
      v17 = v10; /*0x108371776*/
      do /*0x1083717b2*/
      {
        v18 = v9 - v12 + 1; /*0x10837177c*/
        if ( v18 == 0 ) /*0x10837177f*/
          break; /*0x10837177f*/
        v19 = (char *)memchr(__s: v17, __c: v16, __n: v18); /*0x108371787*/
        if ( v19 == nullptr ) /*0x10837178f*/
          break; /*0x10837178f*/
        v14 = v19; /*0x108371791*/
        if ( memcmp(__s1: v19, __s2: v11, __n: v12) == 0 ) /*0x1083717a4*/
          goto LABEL_17; /*0x1083717a4*/
        v17 = v14 + 1; /*0x1083717a6*/
        v9 = v13 - (_BYTE *)v17; /*0x1083717ac*/
      }
      while ( v13 - (_BYTE *)v17 >= v12 ); /*0x1083717b2*/
      v14 = v13; /*0x1083717b4*/
LABEL_17:
      a4 = v49; /*0x1083717b7*/
      v10 = v50; /*0x1083717be*/
    }
    else
    {
      v14 = &v10[v9]; /*0x108371757*/
    }
    v15 = v14 != v13 && v14 - v10 != -1; /*0x1083717d6*/
    v7 = v46; /*0x1083717d9*/
    a5 = v47; /*0x1083717e0*/
  }
  else
  {
    v15 = true; /*0x10837175c*/
  }
  if ( (*(_BYTE *)a4 & 1) != 0 ) /*0x1083717ea*/
    v20 = *(const char **)(a4 + 16); /*0x1083717ec*/
  else
    v20 = (const char *)(a4 + 1); /*0x1083717f2*/
  v21 = strtoll(__str: v20, __endptr: nullptr, __base: 10); /*0x108371804*/
  v22 = *v7; /*0x108371807*/
  if ( (v22 & 1) != 0 ) /*0x10837180e*/
    v23 = *((std::__shared_weak_count **)v7 + 1); /*0x108371810*/
  else
    v23 = (std::__shared_weak_count *)(v22 >> 1); /*0x108371816*/
  if ( (unsigned __int64)v23 <= FInt::StudioPlaceUploadSizeLimitBytes ) /*0x108371822*/
  {
    RBX::CreateAssetRequest::CreateAssetRequest(this: (RBX::CreateAssetRequest *)v40); /*0x1083718db*/
    v40[7] = v21; /*0x1083718e7*/
    v41[12] = v15 | 0x100; /*0x1083718f4*/
    LODWORD(v40[0]) = 9; /*0x1083718f8*/
    std::string::assign(a1: v41, a2: RBX::Http::kContentTypeApplicationOctetStream[0]); /*0x108371909*/
    if ( DRolloutFlag::getFFlagStudioZstdPlaceUploadCompressionRollout(this: v25) != 0 ) /*0x108371915*/
      v42[41] = 1; /*0x108371917*/
    if ( a5 != 0 ) /*0x108371921*/
    {
      std::to_string(a1: (__int64)v51); /*0x108371931*/
      std::string::basic_string[abi:ne200100]<0>(a1: v44, a2: "SourcePlaceId", a3: v26, a4: v27); /*0x108371947*/
      v43 = v44; /*0x10837195a*/
      v28 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x10837196e*/
              a1: v42,
              a2: v44,
              a3: std::piecewise_construct,
              a4: &v43,
              a5: &v53);
      v30 = v28 + 40; /*0x108371976*/
      if ( (*(_BYTE *)(v28 + 40) & 1) != 0 ) /*0x10837197e*/
        operator delete(a1: *(RBX::Memory **)(v28 + 56), a2: v29); /*0x108371984*/
      *(_QWORD *)(v30 + 16) = v52; /*0x108371990*/
      *(_OWORD *)v30 = *(_OWORD *)v51; /*0x10837199b*/
      LOWORD(v51[0]) = 0; /*0x10837199e*/
      if ( (v44[0] & 1) != 0 ) /*0x1083719ae*/
      {
        operator delete(a1: (RBX::Memory *)v45, a2: v29); /*0x1083719b7*/
        if ( ((__int64)v51[0] & 1) != 0 ) /*0x1083719c3*/
          operator delete(a1: (RBX::Memory *)v52, a2: v31); /*0x1083719cc*/
      }
    }
    RBX::weak_from<RBX::DataModel>(a1: v51, a2: v48); /*0x1083719df*/
    v33 = v51[0]; /*0x1083719e4*/
    v34 = (volatile signed __int64 *)v51[1]; /*0x1083719eb*/
    if ( v51[1] != nullptr ) /*0x1083719fc*/
    {
      _InterlockedIncrement64((volatile signed __int64 *)v51[1] + 2); /*0x1083719fe*/
      *(_OWORD *)v51 = 0; /*0x108371a06*/
      _InterlockedIncrement64(v34 + 2); /*0x108371a0d*/
      v59 = v34; /*0x108371a12*/
      v60 = v58; /*0x108371a16*/
      _InterlockedIncrement64(v34 + 2); /*0x108371a1a*/
    }
    else
    {
      *(_OWORD *)v51 = 0; /*0x108371a34*/
      v59 = nullptr; /*0x108371a3b*/
      v60 = v58; /*0x108371a43*/
    }
    v58[0] = &off_10CC2A3B0; /*0x108371a4e*/
    v58[1] = v33; /*0x108371a55*/
    v57 = nullptr; /*0x108371a5c*/
    v35 = operator new(a1: (RBX::Memory *)0x28, a2: v32); /*0x108371a6c*/
    *(_QWORD *)v35 = &off_10CC2A4B0; /*0x108371a78*/
    *(_QWORD *)(v35 + 8) = v33; /*0x108371a7b*/
    *(_QWORD *)(v35 + 16) = v34; /*0x108371a7f*/
    *(_QWORD *)(v35 + 24) = v21; /*0x108371a83*/
    *(_BYTE *)(v35 + 32) = v15; /*0x108371a87*/
    *(_DWORD *)(v35 + 33) = 0; /*0x108371a8d*/
    *(_DWORD *)(v35 + 36) = 0; /*0x108371a90*/
    v57 = (char *)v35; /*0x108371a9a*/
    v55 = nullptr; /*0x108371aac*/
    RBX::PublishService::createAssetOrAssetVersionAndPollAssetAsync(a1: (RBX::CreateAssetRequest *)v40); /*0x108371acf*/
    if ( v55 == &v54 ) /*0x108371ade*/
    {
      v36 = 32; /*0x108371aec*/
    }
    else
    {
      v36 = 40; /*0x108371ae0*/
      if ( v55 == nullptr ) /*0x108371ae8*/
      {
LABEL_49:
        if ( v57 == &v56 ) /*0x108371b01*/
        {
          v37 = 32; /*0x108371b0f*/
        }
        else
        {
          v37 = 40; /*0x108371b03*/
          if ( v57 == nullptr ) /*0x108371b0b*/
          {
LABEL_54:
            if ( v60 == v58 ) /*0x108371b21*/
            {
              v38 = 32; /*0x108371b2f*/
            }
            else
            {
              v38 = 40; /*0x108371b23*/
              if ( v60 == nullptr ) /*0x108371b2b*/
                goto LABEL_59; /*0x108371b2b*/
            }
            (*(void (**)(void))(*v60 + v38))(); /*0x108371b37*/
LABEL_59:
            if ( v34 != nullptr ) /*0x108371b3d*/
            {
              std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v34); /*0x108371b42*/
              std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v34); /*0x108371b4a*/
            }
            if ( v51[1] != nullptr ) /*0x108371b59*/
              std::__shared_weak_count::__release_weak(this: v51[1]); /*0x108371b5b*/
            RBX::CreateAssetRequest::~CreateAssetRequest(this: (RBX::CreateAssetRequest *)v40); /*0x108371b67*/
            return __stack_chk_guard; /*0x108371b67*/
          }
        }
        (*(void (**)(void))(*(_QWORD *)v57 + v37))(); /*0x108371b17*/
        goto LABEL_54; /*0x108371b17*/
      }
    }
    (*(void (**)(void))(*(_QWORD *)v55 + v36))(); /*0x108371af4*/
    goto LABEL_49; /*0x108371af4*/
  }
  if ( (unsigned __int8)FLog::LocalPlaceUpload >= 6u && (FLog::LocalPlaceUpload & 0xFE00) != 0 ) /*0x10837183c*/
  {
    v51[0] = v23; /*0x108371851*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x108371889*/
      a1: FLog::LocalPlaceUpload,
      a2: qword_10D87D948,
      a3: 2,
      a4: (unsigned int)"[FLog::LocalPlaceUpload] local place upload failed - place size is {}, exceeded size limit",
      a5: 90,
      a6: 1,
      4,
      v51,
      4,
      v51);
  }
  v61[0] = off_10CC2A330; /*0x108371899*/
  v62 = v61; /*0x10837189c*/
  RBX::DataModel::submitTask(a1: v48, a2: v61, a3: 1); /*0x1083718af*/
  if ( v62 == v61 ) /*0x1083718bb*/
  {
    v24 = 32; /*0x108371a21*/
  }
  else
  {
    v24 = 40; /*0x1083718c1*/
    if ( v62 == nullptr ) /*0x1083718c9*/
      return __stack_chk_guard; /*0x1083718c9*/
  }
  (*(void (**)(void))(*v62 + v24))(); /*0x108371a29*/
  return __stack_chk_guard; /*0x108371b7c*/
}

// Address: 0x108479110 | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS6_IFvbEEEEEESC_EC2ESC_SC_NS5_10shared_ptrISD_EESI_.cold.1
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<void ()(std::string const&,std::function<void ()(bool)>)>,std::string>::MakeRequestContract(
        __int64 a1,
        void *a2)
{
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x108479117*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x108479120*/
}

// Address: 0x10847913a | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E22RequestHandlerContractINSt3__18functionIFvRKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS6_IFvSE_EEEEEEEC2ESC_SC_SI_.cold.1
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::RequestHandlerContract<std::function<void ()(std::string const&,std::function<void ()(std::string const&)>)>>::RequestHandlerContract(
        __int64 a1,
        void *a2)
{
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x108479141*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x10847914a*/
}

// Address: 0x108680a49 | Name: __ZN3RBX17isLODablefunctionENS_10StringViewE.cold.1
void RBX::isLODablefunction()
{
  __cxa_atexit( /*0x108680a62*/
    lpfunc: RBX::SmallSplitHashSet<RBX::StringView,0u,(RBX::SplitHashPolicy)10,RBX::details::DefaultHash<RBX::StringView>,RBX::details::DefaultEqualTo<RBX::StringView>>::~SmallSplitHashSet,
    obj: &RBX::isLODablefunction(RBX::StringView)::lodableFunctions,
    lpdso_handle: (void *)&_mh_execute_header);
  __cxa_guard_release(a1: &`guard variable for'RBX::isLODablefunction(RBX::StringView)::lodableFunctions); /*0x108680a6e*/
}

// Address: 0x108680a75 | Name: __ZN3RBX17isLODablefunctionENS_10StringViewE.cold.2
bool __fastcall RBX::isLODablefunction(__int64 a1, bool *a2)
{
  bool result; // al

  result = RBX::isLODablefunction(RBX::StringView)::lodableFunctions != 0 /*0x108680a9d*/
        && (RBX::details::SplitHashTable<RBX::StringView,RBX::StringView,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::StringView>,RBX::details::DefaultEqualTo<RBX::StringView>,RBX::details::GetSelfKey<RBX::StringView>>::findTableSlot<RBX::StringView>(
              a1: &RBX::isLODablefunction(RBX::StringView)::lodableFunctions,
              a2: a1,
              a3: 0)
          & 0x100000000LL) == 0;
  *a2 = result; /*0x108680aa0*/
  return result; /*0x108680aa6*/
}

// Address: 0x10870f9cb | Name: __ZN3RBX36isDynamicHeadWhichSupportsHeadShapesEx.cold.1
void __fastcall RBX::isDynamicHeadWhichSupportsHeadShapes(RBX *this)
{
  RSL::Arena *v1; // rdi

  if ( __cxa_guard_acquire(a1: &`guard variable for'RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::set) != 0 ) /*0x10870f9dd*/
  {
    qword_10D463C90 = RSL::Arena::getDefaultArena(this: v1); /*0x10870f9e4*/
    RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::set = 0; /*0x10870f9f5*/
    xmmword_10D463C80 = 0; /*0x10870f9fc*/
    __cxa_atexit( /*0x10870fa11*/
      lpfunc: RBX::SmallSplitHashSet<long long,0u,(RBX::SplitHashPolicy)10,RBX::details::DefaultHash<long long>,RBX::details::DefaultEqualTo<long long>>::~SmallSplitHashSet,
      obj: &RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::set,
      lpdso_handle: (void *)&_mh_execute_header);
    __cxa_guard_release(a1: &`guard variable for'RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::set); /*0x10870fa1e*/
  }
}

// Address: 0x10870fa25 | Name: __ZN3RBX36isDynamicHeadWhichSupportsHeadShapesEx.cold.2
void __fastcall RBX::isDynamicHeadWhichSupportsHeadShapes(RBX *this)
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting) != 0 ) /*0x10870fa37*/
  {
    RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting = 0; /*0x10870fa3c*/
    qword_10D463CB0 = 0; /*0x10870fa43*/
    __cxa_atexit( /*0x10870fa60*/
      lpfunc: (void (__fastcall *)(void *))&std::string::~string,
      obj: &RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting,
      lpdso_handle: (void *)&_mh_execute_header);
    __cxa_guard_release(a1: &`guard variable for'RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::lastParsedSetting); /*0x10870fa6d*/
  }
}

// Address: 0x10870fa74 | Name: __ZN3RBX36isDynamicHeadWhichSupportsHeadShapesEx.cold.3
void __fastcall RBX::isDynamicHeadWhichSupportsHeadShapes(RBX *this)
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::mx) != 0 ) /*0x10870fa86*/
  {
    __cxa_atexit( /*0x10870fa9d*/
      lpfunc: RBX::StdMutex::~StdMutex,
      obj: &RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::mx,
      lpdso_handle: (void *)&_mh_execute_header);
    __cxa_guard_release(a1: &`guard variable for'RBX::isDynamicHeadWhichSupportsHeadShapes(long long)::mx); /*0x10870faaa*/
  }
}

// Address: 0x10870fd86 | Name: __ZN3RBX20isBodyPartAttachmentERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE.cold.1
void __fastcall RBX::isBodyPartAttachment(RBX::Memory **a1, RBX::Memory **a2)
{
  do /*0x10870fdaa*/
  {
    if ( (*(_BYTE *)(a1 - 3) & 1) != 0 ) /*0x10870fd98*/
      operator delete(a1: *(a1 - 1), a2); /*0x10870fd9e*/
    a1 -= 3; /*0x10870fda3*/
  }
  while ( a1 != a2 ); /*0x10870fdaa*/
}

// Address: 0x10870fdb1 | Name: __ZN3RBX20isBodyPartAttachmentERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE.cold.2
void __fastcall RBX::isBodyPartAttachment(RBX::Memory **a1, RBX::Memory **a2)
{
  do /*0x10870fdd5*/
  {
    if ( (*(_BYTE *)(a1 - 3) & 1) != 0 ) /*0x10870fdc3*/
      operator delete(a1: *(a1 - 1), a2); /*0x10870fdc9*/
    a1 -= 3; /*0x10870fdce*/
  }
  while ( a1 != a2 ); /*0x10870fdd5*/
}

// Address: 0x1087a542f | Name: __ZN3RBX15ITransportLayerINS_4json8DocumentES2_S2_S2_E19MakeRequestContractINSt3__18functionIFvNS5_10shared_ptrIKS2_EENS6_IFvbEEEEEES2_EC2ENS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEESK_S9_SD_.cold.1
void __fastcall RBX::ITransportLayer<RBX::json::Document,RBX::json::Document,RBX::json::Document,RBX::json::Document>::MakeRequestContract<std::function<void ()(std::shared_ptr<RBX::json::Document const>,std::function<void ()(bool)>)>,RBX::json::Document>::MakeRequestContract(
        __int64 a1,
        void *a2)
{
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x1087a5436*/
    operator delete(a1: *(RBX::Memory **)(a1 + 16), a2); /*0x1087a543f*/
}

// END _free_i part 1/1, 229 functions
