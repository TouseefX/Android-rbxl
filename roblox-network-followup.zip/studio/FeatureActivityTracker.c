// FeatureActivityTracker -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 36 functions


// Address: 0x101151308 | Name: __ZN3RBX6Studio22FeatureActivityTracker6defineEv
RBX::Studio::FeatureActivityTracker *__fastcall RBX::Studio::FeatureActivityTracker::define(
        RBX::Studio::FeatureActivityTracker *this)
{
  __int64 v2; // rax
  __int64 v3; // rsi
  __int64 v4; // rsi
  __int64 v6; // [rsp+0h] [rbp-20h] BYREF
  _QWORD v7[3]; // [rsp+8h] [rbp-18h] BYREF

  RBX::Component::define<RBX::Studio::IFeatureActivityTracker,RBX::Component::ManagedPtr<IHardwareSleepListener>,RBX::Component::ManagedPtr<RBX::Studio::INotificationService>>( /*0x101151324*/
    a1: &v6,
    a2: &RBX::Studio::FeatureActivityTracker::create);
  v2 = v6; /*0x101151329*/
  *(_QWORD *)(v6 + 56) = &RBX::Component::GetClassId<RBX::Studio::IAppContext>::id; /*0x101151333*/
  v6 = 0; /*0x101151337*/
  v7[0] = v2; /*0x101151342*/
  RBX::Component::ComponentSpec::ComponentSpec(a1: this, a2: v7); /*0x101151348*/
  v3 = v7[0]; /*0x10115134d*/
  v7[0] = 0; /*0x101151351*/
  if ( v3 != 0 ) /*0x10115135c*/
    std::default_delete<RBX::Component::ComponentSpec>::operator()[abi:ne200100](a1: v7); /*0x101151362*/
  v4 = v6; /*0x101151367*/
  v6 = 0; /*0x10115136b*/
  if ( v4 != 0 ) /*0x101151376*/
    std::default_delete<RBX::Component::ComponentSpec>::operator()[abi:ne200100](a1: &v6); /*0x10115137c*/
  return this; /*0x101151384*/
}

// Address: 0x101151474 | Name: __ZN3RBX6Studio22FeatureActivityTracker6createENS_9Component10ManagedPtrI22IHardwareSleepListenerEENS3_INS0_20INotificationServiceEEE
_QWORD *__fastcall RBX::Studio::FeatureActivityTracker::create(
        _QWORD *a1,
        RBX::Component::detail::ComponentState *a2,
        RBX::Component::detail::ComponentState *a3)
{
  __int64 Component; // r15
  __int64 v6; // r12
  __int64 v7; // r14

  Component = RBX::Component::detail::ComponentState::loadAndGetComponent(this: a2); /*0x10115148d*/
  v6 = RBX::Component::detail::ComponentState::loadAndGetComponent(this: a3); /*0x101151498*/
  v7 = operator new(a1: 0xC0u); /*0x1011514a5*/
  RBX::Studio::FeatureActivityTracker::FeatureActivityTracker(a1: v7, a2: Component, a3: v6); /*0x1011514b1*/
  *a1 = v7 + 16; /*0x1011514ba*/
  return a1; /*0x1011514c0*/
}

// Address: 0x1011514dc | Name: __ZN3RBX6Studio22FeatureActivityTracker8createV2ER22IHardwareSleepListenerRNS0_20INotificationServiceE
_QWORD *__fastcall RBX::Studio::FeatureActivityTracker::createV2(_QWORD *a1, __int64 a2, __int64 a3)
{
  __int64 v6; // r14

  v6 = operator new(a1: 0xC0u); /*0x1011514fa*/
  RBX::Studio::FeatureActivityTracker::FeatureActivityTracker(a1: v6, a2, a3); /*0x101151506*/
  *a1 = v6 + 16; /*0x10115150f*/
  return a1; /*0x101151515*/
}

// Address: 0x101151532 | Name: __ZN3RBX6Studio22FeatureActivityTrackerC2ENS_9Component10IComponent6SecretEP22IHardwareSleepListenerPNS0_20INotificationServiceE
__int64 __fastcall RBX::Studio::FeatureActivityTracker::FeatureActivityTracker(
        __int64 a1,
        rbx::signals::slots_holder **a2,
        __int64 a3)
{
  const QObject *v6; // rsi
  void *v7; // rax
  unsigned int v8; // esi
  std::__shared_weak_count *v9; // r12
  __int64 v10; // rax
  unsigned int v11; // r14d
  unsigned __int64 v12; // rsi
  volatile signed __int32 *v13; // r12
  rbx::signals::slots_holder *v14; // rax
  unsigned __int64 v15; // rax
  unsigned int v16; // esi
  unsigned int v17; // esi
  void *v18; // rdi
  unsigned int v19; // r14d
  unsigned __int64 v20; // rsi
  volatile signed __int32 *v21; // r12
  rbx::signals::slots_holder *v22; // rax
  unsigned __int64 v23; // rax
  unsigned int v24; // esi
  unsigned int v25; // esi
  void *v26; // rdi
  unsigned int v27; // r14d
  unsigned __int64 v28; // rsi
  volatile signed __int32 *v29; // r12
  rbx::signals::slots_holder *v30; // rax
  unsigned __int64 v31; // rax
  unsigned int v32; // esi
  unsigned int v33; // esi
  void *v34; // rdi
  unsigned int v35; // r14d
  rbx::signals::slots_holder **v36; // r15
  unsigned __int64 v37; // rsi
  volatile signed __int32 *v38; // r12
  rbx::signals::slots_holder *v39; // rax
  unsigned __int64 v40; // rax
  unsigned int v41; // esi
  void *v42; // rdi
  __int64 v43; // rax
  __int64 v44; // rax
  __int64 v45; // r14
  __int64 v46; // rax
  _BYTE v48[8]; // [rsp+20h] [rbp-F0h] BYREF
  __int64 v49; // [rsp+28h] [rbp-E8h]
  __int64 v50; // [rsp+30h] [rbp-E0h]
  rbx::signals::connection *v51; // [rsp+38h] [rbp-D8h]
  rbx::signals::connection *v52; // [rsp+40h] [rbp-D0h]
  rbx::signals::connection *v53; // [rsp+48h] [rbp-C8h]
  rbx::signals::connection *v54; // [rsp+50h] [rbp-C0h]
  __int64 v55; // [rsp+58h] [rbp-B8h]
  unsigned int v56[2]; // [rsp+60h] [rbp-B0h] BYREF
  volatile signed __int64 *v57; // [rsp+68h] [rbp-A8h]
  unsigned int v58; // [rsp+7Ch] [rbp-94h]
  _QWORD v59[4]; // [rsp+80h] [rbp-90h] BYREF
  _QWORD *v60; // [rsp+A0h] [rbp-70h]
  void *v61[2]; // [rsp+B0h] [rbp-60h] BYREF
  __int64 v62; // [rsp+C0h] [rbp-50h]
  void **v63; // [rsp+D0h] [rbp-40h]

  QObject::QObject(this: (QObject *)a1, a2: nullptr); /*0x10115155f*/
  *(_OWORD *)(a1 + 24) = 0; /*0x101151568*/
  *(_QWORD *)(a1 + 40) = 0; /*0x10115156d*/
  *(_QWORD *)a1 = &off_10CB16768; /*0x101151580*/
  *(_QWORD *)(a1 + 16) = off_10CB16818; /*0x101151589*/
  *(_OWORD *)(a1 + 48) = 0; /*0x10115158d*/
  *(_OWORD *)(a1 + 64) = 0; /*0x101151592*/
  *(_DWORD *)(a1 + 80) = 1065353216; /*0x101151597*/
  v50 = a1 + 88; /*0x1011515a2*/
  RBX::SimpleTimer::SimpleTimer(this: (RBX::SimpleTimer *)(a1 + 88)); /*0x1011515a9*/
  v55 = a1 + 112; /*0x1011515b2*/
  *(_QWORD *)(a1 + 144) = 0; /*0x1011515b9*/
  v54 = (rbx::signals::connection *)(a1 + 160); /*0x1011515cb*/
  v53 = (rbx::signals::connection *)(a1 + 168); /*0x1011515d9*/
  v51 = (rbx::signals::connection *)(a1 + 176); /*0x1011515e7*/
  v52 = (rbx::signals::connection *)(a1 + 184); /*0x1011515f5*/
  *(_OWORD *)(a1 + 160) = 0; /*0x101151600*/
  *(_OWORD *)(a1 + 176) = 0; /*0x101151608*/
  if ( (unsigned __int8)FLog::StudioFeatureActivityTrackerLog >= 6u /*0x101151625*/
    && BYTE1(FLog::StudioFeatureActivityTrackerLog) >= 5u )
  {
    v61[0] = nullptr; /*0x10115163a*/
    v61[1] = v56; /*0x101151642*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x101151668*/
      a1: FLog::StudioFeatureActivityTrackerLog,
      a2: qword_10D504898,
      a3: 5,
      a4: (unsigned int)"[FLog::StudioFeatureActivityTrackerLog] Constructing FeatureActivityTracker",
      a5: 75,
      a6: 1,
      0,
      v56);
  }
  v7 = (void *)QtSharedPointer::ExternalRefCountData::getAndRef( /*0x101151670*/
                 this: (QtSharedPointer::ExternalRefCountData *)a1,
                 a2: v6);
  v49 = a3; /*0x101151675*/
  v61[0] = &off_10C71E7F8; /*0x101151687*/
  v61[1] = v7; /*0x10115168a*/
  v62 = a1; /*0x10115168e*/
  v63 = v61; /*0x101151692*/
  RBX::SimpleTimer::callEvery( /*0x1011516ad*/
    a1: v56,
    a2: v61,
    a3: 0,
    a4: (double)FInt::StudioFeatureActivityTrackerInactivityTimerIntervalSeconds);
  std::shared_ptr<RBX::TimerData>::operator=[abi:ne200100](a1: v50, a2: v56); /*0x1011516c3*/
  v9 = (std::__shared_weak_count *)v57; /*0x1011516c8*/
  if ( v57 != nullptr && _InterlockedExchangeAdd64(v57 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1011516e3*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x1011516ec*/
    std::__shared_weak_count::__release_weak(this: v9); /*0x1011516f2*/
  }
  if ( v63 == v61 ) /*0x1011516fe*/
  {
    v10 = 32; /*0x10115170c*/
    goto LABEL_10; /*0x10115170c*/
  }
  v10 = 40; /*0x101151700*/
  if ( v63 != nullptr ) /*0x101151708*/
LABEL_10:
    (*(void (**)(void))((char *)*v63 + v10))(); /*0x101151711*/
  v58 = (unsigned int)RBX::Memory::InstanceSignal; /*0x101151717*/
  v11 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v8); /*0x10115172b*/
  rbx::lazyInitSlotsHolder(a1: a2 + 4); /*0x101151735*/
  v13 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v12); /*0x101151744*/
  *(_QWORD *)v13 = &_mh_execute_header; /*0x101151751*/
  *((_QWORD *)v13 + 1) = rbx::signals::slot_with_functor<RBX::Studio::FeatureActivityTracker::FeatureActivityTracker(RBX::Component::IComponent::Secret,IHardwareSleepListener *,RBX::Studio::INotificationService *)::$_2>::do_call; /*0x10115175c*/
  *((_OWORD *)v13 + 1) = 0; /*0x101151765*/
  v14 = a2[4]; /*0x10115176c*/
  *((_QWORD *)v13 + 4) = v14; /*0x101151770*/
  if ( v14 != nullptr ) /*0x101151778*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v14 + 1); /*0x10115177a*/
    v15 = *((_QWORD *)v13 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x101151783*/
  }
  else
  {
    v15 = 0; /*0x101151789*/
  }
  *((_QWORD *)v13 + 3) = v15; /*0x10115178b*/
  *((_QWORD *)v13 + 5) = a1; /*0x101151790*/
  rbx::signals::slots_holder::insert(this: a2[4], a2: (unsigned __int64)v13); /*0x10115179c*/
  v61[0] = (void *)v13; /*0x1011517a1*/
  _InterlockedIncrement(v13 + 1); /*0x1011517a5*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v11, a2: v16); /*0x1011517ae*/
  rbx::signals::scoped_connection::operator=(this: v51); /*0x1011517be*/
  v18 = v61[0]; /*0x1011517c3*/
  if ( v61[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v61[0] + 1) == 0 ) /*0x1011517d0*/
    rbx::signals::slot_base::operator delete(a1: v18); /*0x1011517d2*/
  v19 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v58, a2: v17); /*0x1011517e2*/
  rbx::lazyInitSlotsHolder(a1: a2 + 5); /*0x1011517ec*/
  v21 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v20); /*0x1011517fb*/
  *(_QWORD *)v21 = &_mh_execute_header; /*0x101151808*/
  *((_QWORD *)v21 + 1) = rbx::signals::slot_with_functor<RBX::Studio::FeatureActivityTracker::FeatureActivityTracker(RBX::Component::IComponent::Secret,IHardwareSleepListener *,RBX::Studio::INotificationService *)::$_3>::do_call; /*0x101151813*/
  *((_OWORD *)v21 + 1) = 0; /*0x10115181c*/
  v22 = a2[5]; /*0x101151823*/
  *((_QWORD *)v21 + 4) = v22; /*0x101151827*/
  if ( v22 != nullptr ) /*0x10115182f*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v22 + 1); /*0x101151831*/
    v23 = *((_QWORD *)v21 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x10115183a*/
  }
  else
  {
    v23 = 0; /*0x101151840*/
  }
  *((_QWORD *)v21 + 3) = v23; /*0x101151842*/
  *((_QWORD *)v21 + 5) = a1; /*0x101151847*/
  rbx::signals::slots_holder::insert(this: a2[5], a2: (unsigned __int64)v21); /*0x101151853*/
  v61[0] = (void *)v21; /*0x101151858*/
  _InterlockedIncrement(v21 + 1); /*0x10115185c*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v19, a2: v24); /*0x101151865*/
  rbx::signals::scoped_connection::operator=(this: v52); /*0x101151875*/
  v26 = v61[0]; /*0x10115187a*/
  if ( v61[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v61[0] + 1) == 0 ) /*0x101151887*/
    rbx::signals::slot_base::operator delete(a1: v26); /*0x101151889*/
  v27 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v58, a2: v25); /*0x101151899*/
  rbx::lazyInitSlotsHolder(a1: a2 + 7); /*0x1011518a3*/
  v29 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v28); /*0x1011518b2*/
  *(_QWORD *)v29 = &_mh_execute_header; /*0x1011518bf*/
  *((_QWORD *)v29 + 1) = rbx::signals::slot_with_functor<RBX::Studio::FeatureActivityTracker::FeatureActivityTracker(RBX::Component::IComponent::Secret,IHardwareSleepListener *,RBX::Studio::INotificationService *)::$_4>::do_call; /*0x1011518ca*/
  *((_OWORD *)v29 + 1) = 0; /*0x1011518d3*/
  v30 = a2[7]; /*0x1011518da*/
  *((_QWORD *)v29 + 4) = v30; /*0x1011518de*/
  if ( v30 != nullptr ) /*0x1011518e6*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v30 + 1); /*0x1011518e8*/
    v31 = *((_QWORD *)v29 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x1011518f1*/
  }
  else
  {
    v31 = 0; /*0x1011518f7*/
  }
  *((_QWORD *)v29 + 3) = v31; /*0x1011518f9*/
  *((_QWORD *)v29 + 5) = a1; /*0x1011518fe*/
  rbx::signals::slots_holder::insert(this: a2[7], a2: (unsigned __int64)v29); /*0x10115190a*/
  v61[0] = (void *)v29; /*0x10115190f*/
  _InterlockedIncrement(v29 + 1); /*0x101151913*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v27, a2: v32); /*0x10115191c*/
  rbx::signals::scoped_connection::operator=(this: v53); /*0x10115192c*/
  v34 = v61[0]; /*0x101151931*/
  if ( v61[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v61[0] + 1) == 0 ) /*0x10115193e*/
    rbx::signals::slot_base::operator delete(a1: v34); /*0x101151940*/
  v35 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v58, a2: v33); /*0x101151950*/
  v36 = a2 + 6; /*0x101151953*/
  rbx::lazyInitSlotsHolder(a1: v36); /*0x10115195a*/
  v38 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v37); /*0x101151969*/
  *(_QWORD *)v38 = &_mh_execute_header; /*0x101151976*/
  *((_QWORD *)v38 + 1) = rbx::signals::slot_with_functor<RBX::Studio::FeatureActivityTracker::FeatureActivityTracker(RBX::Component::IComponent::Secret,IHardwareSleepListener *,RBX::Studio::INotificationService *)::$_5>::do_call; /*0x101151981*/
  *((_OWORD *)v38 + 1) = 0; /*0x10115198a*/
  v39 = *v36; /*0x101151991*/
  *((_QWORD *)v38 + 4) = *v36; /*0x101151994*/
  if ( v39 != nullptr ) /*0x10115199c*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v39 + 1); /*0x10115199e*/
    v40 = *((_QWORD *)v38 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x1011519a7*/
  }
  else
  {
    v40 = 0; /*0x1011519ad*/
  }
  *((_QWORD *)v38 + 3) = v40; /*0x1011519af*/
  *((_QWORD *)v38 + 5) = a1; /*0x1011519b4*/
  rbx::signals::slots_holder::insert(this: *v36, a2: (unsigned __int64)v38); /*0x1011519bf*/
  v61[0] = (void *)v38; /*0x1011519c4*/
  _InterlockedIncrement(v38 + 1); /*0x1011519c8*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v35, a2: v41); /*0x1011519d1*/
  rbx::signals::scoped_connection::operator=(this: v54); /*0x1011519e1*/
  v42 = v61[0]; /*0x1011519e6*/
  if ( v61[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v61[0] + 1) == 0 ) /*0x1011519f3*/
    rbx::signals::slot_base::operator delete(a1: v42); /*0x1011519f5*/
  v59[0] = off_10C71E8F8; /*0x101151a08*/
  v59[1] = a1; /*0x101151a0c*/
  v60 = v59; /*0x101151a11*/
  (*(void (__fastcall **)(void **, __int64, const char *, __int64, _QWORD *))(*(_QWORD *)v49 + 16LL))( /*0x101151a33*/
    a1: v61,
    a2: v49,
    a3: "AboutToCloseProcess",
    a4: 19,
    a5: v59);
  RBX::Studio::INotificationService::ScopedUnregisterEventCallback::operator=(a1: v55, a2: v61); /*0x101151a44*/
  if ( v63 == v61 ) /*0x101151a50*/
  {
    v43 = 32; /*0x101151a5e*/
    goto LABEL_39; /*0x101151a5e*/
  }
  v43 = 40; /*0x101151a52*/
  if ( v63 != nullptr ) /*0x101151a5a*/
LABEL_39:
    (*(void (**)(void))((char *)*v63 + v43))(); /*0x101151a63*/
  if ( v60 == v59 ) /*0x101151a70*/
  {
    v44 = 32; /*0x101151a7e*/
    goto LABEL_44; /*0x101151a7e*/
  }
  v44 = 40; /*0x101151a72*/
  if ( v60 != nullptr ) /*0x101151a7a*/
LABEL_44:
    (*(void (**)(void))(*v60 + v44))(); /*0x101151a83*/
  v45 = QCoreApplication::self; /*0x101151a89*/
  if ( QCoreApplication::self != 0 ) /*0x101151a96*/
  {
    v61[0] = &QGuiApplication::lastWindowClosed; /*0x101151aa3*/
    v61[1] = nullptr; /*0x101151aa9*/
    *(_QWORD *)v56 = RBX::Studio::FeatureActivityTracker::onApplicationWillClose; /*0x101151ab4*/
    v57 = nullptr; /*0x101151abb*/
    v46 = operator new(a1: 0x20u); /*0x101151ac7*/
    *(_DWORD *)v46 = 1; /*0x101151acc*/
    *(_QWORD *)(v46 + 8) = &QtPrivate::QSlotObject<void (RBX::Studio::FeatureActivityTracker::*)(void),QtPrivate::List<>,void>::impl; /*0x101151ad9*/
    *(_QWORD *)(v46 + 16) = RBX::Studio::FeatureActivityTracker::onApplicationWillClose; /*0x101151add*/
    *(_QWORD *)(v46 + 24) = 0; /*0x101151ae3*/
    QObject::connectImpl( /*0x101151b1a*/
      a1: v48,
      a2: v45,
      a3: v61,
      a4: a1,
      a5: v56,
      a6: v46,
      a7: 0,
      a8: 0,
      a9: &QGuiApplication::staticMetaObject);
    QMetaObject::Connection::~Connection(this: (QMetaObject::Connection *)v48); /*0x101151b26*/
  }
  return __stack_chk_guard; /*0x101151b3b*/
}

// Address: 0x101151cd4 | Name: __ZN3RBX6Studio22FeatureActivityTracker22onApplicationWillCloseEv
__int64 __fastcall RBX::Studio::FeatureActivityTracker::onApplicationWillClose(
        RBX::Studio::FeatureActivityTracker *this)
{
  RbxQt::RequireUIThread(this); /*0x101151cdd*/
  return (*(__int64 (__fastcall **)(RBX::Studio::FeatureActivityTracker *, const char *, __int64))(*(_QWORD *)this /*0x101151d00*/
                                                                                                 + 152LL))(
           a1: this,
           a2: "ApplicationClose",
           a3: 16);
}

// Address: 0x101151d04 | Name: __ZN3RBX6Studio22FeatureActivityTrackerC1ENS_9Component10IComponent6SecretEP22IHardwareSleepListenerPNS0_20INotificationServiceE
__int64 __fastcall RBX::Studio::FeatureActivityTracker::FeatureActivityTracker(
        __int64 a1,
        rbx::signals::slots_holder **a2,
        __int64 a3)
{
  return RBX::Studio::FeatureActivityTracker::FeatureActivityTracker(a1, a2, a3); /*0x101151d08*/
}

// Address: 0x101151d0e | Name: __ZN3RBX6Studio22FeatureActivityTrackerD2Ev
void __fastcall RBX::Studio::FeatureActivityTracker::~FeatureActivityTracker(RBX::Studio::FeatureActivityTracker *this)
{
  _BYTE v2[16]; // [rsp+10h] [rbp-30h] BYREF
  __int64 v3; // [rsp+20h] [rbp-20h]
  _BYTE *v4; // [rsp+28h] [rbp-18h]

  *(_QWORD *)this = &off_10CB16768; /*0x101151d27*/
  *((_QWORD *)this + 2) = off_10CB16818; /*0x101151d30*/
  if ( (unsigned __int8)FLog::StudioFeatureActivityTrackerLog >= 6u /*0x101151d49*/
    && BYTE1(FLog::StudioFeatureActivityTrackerLog) >= 5u )
  {
    v3 = 0; /*0x101151d57*/
    v4 = v2; /*0x101151d63*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x101151d87*/
      a1: FLog::StudioFeatureActivityTrackerLog,
      a2: qword_10D504898,
      a3: 5,
      a4: (unsigned int)"[FLog::StudioFeatureActivityTrackerLog] Destructing FeatureActivityTracker",
      a5: 74,
      a6: 1,
      0,
      v2);
  }
  if ( (unsigned __int8)RBX::SimpleTimer::isValid(this: (RBX::Studio::FeatureActivityTracker *)((char *)this + 88)) != 0 ) /*0x101151d9a*/
    RBX::SimpleTimer::stop(this: (RBX::Studio::FeatureActivityTracker *)((char *)this + 88)); /*0x101151d9f*/
  (*(void (__fastcall **)(RBX::Studio::FeatureActivityTracker *, const char *, __int64))(*(_QWORD *)this + 152LL))( /*0x101151db6*/
    a1: this,
    a2: "TrackerDestruction",
    a3: 18);
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Studio::FeatureActivityTracker *)((char *)this + 184)); /*0x101151dc3*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Studio::FeatureActivityTracker *)((char *)this + 176)); /*0x101151dcf*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Studio::FeatureActivityTracker *)((char *)this + 168)); /*0x101151ddb*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::Studio::FeatureActivityTracker *)((char *)this + 160)); /*0x101151de7*/
  RBX::Studio::INotificationService::ScopedUnregisterEventCallback::~ScopedUnregisterEventCallback(this: (RBX::Studio::FeatureActivityTracker *)((char *)this + 112)); /*0x101151df0*/
  std::shared_ptr<RBX::TimerData>::~shared_ptr[abi:ne200100](a1: (char *)this + 88); /*0x101151df8*/
  std::__hash_table<std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Studio::FeatureSession>>>::~__hash_table(a1: (char *)this + 48); /*0x101151e01*/
  *((_QWORD *)this + 2) = off_10C780330; /*0x101151e0d*/
  if ( (*((_BYTE *)this + 24) & 1) != 0 ) /*0x101151e15*/
    operator delete(a1: *((void **)this + 5)); /*0x101151e1b*/
  QObject::~QObject(this); /*0x101151e23*/
}

// Address: 0x101151e3a | Name: __ZN3RBX6Studio22FeatureActivityTrackerD1Ev
void __fastcall RBX::Studio::FeatureActivityTracker::~FeatureActivityTracker(RBX::Studio::FeatureActivityTracker *this)
{
  RBX::Studio::FeatureActivityTracker::~FeatureActivityTracker(this); /*0x101151e3f*/
}

// Address: 0x101151e44 | Name: __ZThn16_N3RBX6Studio22FeatureActivityTrackerD1Ev
void __fastcall `non-virtual thunk to'RBX::Studio::FeatureActivityTracker::~FeatureActivityTracker(
        RBX::Studio::FeatureActivityTracker *this)
{
  RBX::Studio::FeatureActivityTracker::~FeatureActivityTracker(this: (RBX::Studio::FeatureActivityTracker *)((char *)this - 16)); /*0x101151e4d*/
}

// Address: 0x101151e52 | Name: __ZN3RBX6Studio22FeatureActivityTrackerD0Ev
void __fastcall RBX::Studio::FeatureActivityTracker::~FeatureActivityTracker(RBX::Studio::FeatureActivityTracker *this)
{
  RBX::Studio::FeatureActivityTracker::~FeatureActivityTracker(this); /*0x101151e5b*/
  operator delete(a1: this); /*0x101151e69*/
}

// Address: 0x101151e6e | Name: __ZThn16_N3RBX6Studio22FeatureActivityTrackerD0Ev
void __fastcall `non-virtual thunk to'RBX::Studio::FeatureActivityTracker::~FeatureActivityTracker(
        RBX::Studio::FeatureActivityTracker *this)
{
  char *v1; // rbx

  v1 = (char *)this - 16; /*0x101151e77*/
  RBX::Studio::FeatureActivityTracker::~FeatureActivityTracker(this: (RBX::Studio::FeatureActivityTracker *)((char *)this - 16)); /*0x101151e7e*/
  operator delete(a1: v1); /*0x101151e8c*/
}

// Address: 0x101151e92 | Name: __ZN3RBX6Studio22FeatureActivityTracker11logActivityENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall RBX::Studio::FeatureActivityTracker::logActivity(RbxQt *a1, __int128 *a2)
{
  __int128 v4; // [rsp+0h] [rbp-50h] BYREF
  void *v5; // [rsp+10h] [rbp-40h]
  __int128 v6; // [rsp+20h] [rbp-30h] BYREF
  void *v7; // [rsp+30h] [rbp-20h]

  RbxQt::RequireUIThread(this: a1); /*0x101151ea3*/
  v5 = *((void **)a2 + 2); /*0x101151eb0*/
  v4 = *a2; /*0x101151eb7*/
  *a2 = 0; /*0x101151ebd*/
  *((_QWORD *)a2 + 2) = 0; /*0x101151ec2*/
  v7 = nullptr; /*0x101151eca*/
  v6 = 0; /*0x101151ece*/
  (*(void (__fastcall **)(RbxQt *, __int128 *, __int128 *))(*(_QWORD *)a1 + 104LL))(a1, a2: &v4, a3: &v6); /*0x101151ed7*/
  if ( (v6 & 1) != 0 ) /*0x101151ede*/
    operator delete(a1: v7); /*0x101151ee4*/
  if ( (v4 & 1) != 0 ) /*0x101151eed*/
    operator delete(a1: v5); /*0x101151ef3*/
}

// Address: 0x101151f24 | Name: __ZThn16_N3RBX6Studio22FeatureActivityTracker11logActivityENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall `non-virtual thunk to'RBX::Studio::FeatureActivityTracker::logActivity(__int64 a1, __int128 *a2)
{
  RBX::Studio::FeatureActivityTracker::logActivity(a1: (RbxQt *)(a1 - 16), a2); /*0x101151f2d*/
}

// Address: 0x101151f32 | Name: __ZN3RBX6Studio22FeatureActivityTracker13getSessionKeyERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEESA_
__int64 __fastcall RBX::Studio::FeatureActivityTracker::getSessionKey(__int64 a1, __int64 a2, __int64 a3)
{
  std::operator+[abi:ne200100]<char,std::char_traits<char>,std::allocator<char>>(a1, a2, a3); /*0x101151f3b*/
  return a1; /*0x101151f47*/
}

// Address: 0x101151f4c | Name: __ZN3RBX6Studio22FeatureActivityTracker15getTimePointNowEv
__int64 __fastcall RBX::Studio::FeatureActivityTracker::getTimePointNow(RBX::Studio::FeatureActivityTracker *this)
{
  return std::chrono::system_clock::now(this); /*0x101151f50*/
}

// Address: 0x101151f56 | Name: __ZN3RBX6Studio22FeatureActivityTracker11logActivityENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEES8_
__int64 __fastcall RBX::Studio::FeatureActivityTracker::logActivity(RbxQt *a1, char *a2, char *a3)
{
  __int64 v6; // rbx
  char v7; // al
  void *v8; // rcx
  char v9; // si
  void *v10; // rdi
  __int64 v11; // r14
  char v12; // dl
  char v13; // r15
  unsigned __int8 *v14; // r9
  bool v15; // al
  char v17; // [rsp+10h] [rbp-C0h] BYREF
  _BYTE v18[15]; // [rsp+11h] [rbp-BFh]
  void *v19; // [rsp+20h] [rbp-B0h]
  char v20; // [rsp+28h] [rbp-A8h]
  _BYTE v21[15]; // [rsp+29h] [rbp-A7h]
  void *v22; // [rsp+38h] [rbp-98h]
  __int128 v23; // [rsp+40h] [rbp-90h]
  __int64 v24; // [rsp+50h] [rbp-80h]
  _BYTE *v25; // [rsp+58h] [rbp-78h]
  char *v26; // [rsp+60h] [rbp-70h]
  _BYTE v27[16]; // [rsp+68h] [rbp-68h] BYREF
  void *v28; // [rsp+78h] [rbp-58h]
  _QWORD v29[4]; // [rsp+80h] [rbp-50h] BYREF

  RbxQt::RequireUIThread(this: a1); /*0x101151f81*/
  std::operator+[abi:ne200100]<char,std::char_traits<char>,std::allocator<char>>(a1: v27, a2, a3); /*0x101151f93*/
  v6 = (*(__int64 (__fastcall **)(RbxQt *))(*(_QWORD *)a1 + 128LL))(a1); /*0x101151fa4*/
  v7 = *a2; /*0x101151fa7*/
  *(_QWORD *)((char *)&v29[2] + 7) = *((_QWORD *)a2 + 1); /*0x101151faf*/
  v29[2] = *(_QWORD *)(a2 + 1); /*0x101151fb7*/
  v8 = *((void **)a2 + 2); /*0x101151fbb*/
  *(_OWORD *)a2 = 0; /*0x101151fc2*/
  *((_QWORD *)a2 + 2) = 0; /*0x101151fc9*/
  v9 = *a3; /*0x101151fcd*/
  *(_QWORD *)((char *)v29 + 7) = *((_QWORD *)a3 + 1); /*0x101151fd6*/
  v29[0] = *(_QWORD *)(a3 + 1); /*0x101151fdf*/
  v10 = *((void **)a3 + 2); /*0x101151fe3*/
  *(_OWORD *)a3 = 0; /*0x101151fe8*/
  *((_QWORD *)a3 + 2) = 0; /*0x101151fed*/
  v17 = v7; /*0x101151ff9*/
  *(_QWORD *)v18 = v29[2]; /*0x101152004*/
  *(_QWORD *)&v18[7] = *(_QWORD *)((char *)&v29[2] + 7); /*0x101152008*/
  v19 = v8; /*0x10115200c*/
  memset(&v29[2], 0, 15); /*0x101152010*/
  v20 = v9; /*0x101152018*/
  qmemcpy(v21, v29, sizeof(v21)); /*0x101152024*/
  v22 = v10; /*0x10115202c*/
  memset(v29, 0, 15); /*0x101152030*/
  v24 = 0; /*0x101152038*/
  v23 = 0; /*0x10115203c*/
  v25 = v27; /*0x101152049*/
  v26 = &v17; /*0x101152050*/
  v11 = std::__hash_table<std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Studio::FeatureSession>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<RBX::Studio::FeatureSession&&>>( /*0x101152065*/
          a1: (char *)a1 + 48,
          a2: v27,
          a3: std::piecewise_construct);
  v13 = v12; /*0x101152068*/
  if ( (v20 & 1) != 0 ) /*0x101152072*/
    operator delete(a1: v22); /*0x10115207b*/
  if ( (v17 & 1) != 0 ) /*0x101152087*/
    operator delete(a1: v19); /*0x101152090*/
  v14 = (unsigned __int8 *)(v11 + 40); /*0x101152095*/
  *(_QWORD *)(v11 + 96) = v6; /*0x101152099*/
  v15 = (unsigned __int8)FLog::StudioFeatureActivityTrackerLog >= 6u /*0x1011520b4*/
     && (FLog::StudioFeatureActivityTrackerLog & 0xFC00) != 0;
  if ( (v13 & 1) != 0 ) /*0x1011520ba*/
  {
    if ( v15 ) /*0x1011520be*/
      FLog::FastLogSafeFormatted<std::string &,std::string &>( /*0x1011520e4*/
        a1: FLog::StudioFeatureActivityTrackerLog,
        a2: qword_10D504898,
        a3: 4,
        a4: (int)"[FLog::StudioFeatureActivityTrackerLog] Session start - \"{}\" / \"{}\"",
        a5: 67,
        a6: v14,
        a7: (unsigned __int8 *)(v11 + 64));
    *(_QWORD *)(v11 + 88) = v6; /*0x1011520e9*/
  }
  else if ( v15 ) /*0x1011520f1*/
  {
    FLog::FastLogSafeFormatted<std::string &,std::string &>( /*0x101152114*/
      a1: FLog::StudioFeatureActivityTrackerLog,
      a2: qword_10D504898,
      a3: 4,
      a4: (int)"[FLog::StudioFeatureActivityTrackerLog] Log activity - \"{}\" / \"{}\"",
      a5: 66,
      a6: v14,
      a7: (unsigned __int8 *)(v11 + 64));
  }
  if ( (v27[0] & 1) != 0 ) /*0x10115211d*/
    operator delete(a1: v28); /*0x101152123*/
  return __stack_chk_guard; /*0x101152138*/
}

// Address: 0x1011521b6 | Name: __ZThn16_N3RBX6Studio22FeatureActivityTracker11logActivityENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEES8_
__int64 __fastcall `non-virtual thunk to'RBX::Studio::FeatureActivityTracker::logActivity(
        __int64 a1,
        char *a2,
        char *a3)
{
  return RBX::Studio::FeatureActivityTracker::logActivity(a1: (RbxQt *)(a1 - 16), a2, a3); /*0x1011521be*/
}

// Address: 0x1011521c4 | Name: __ZN3RBX6Studio22FeatureActivityTracker10endSessionENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS_10StringViewE
void __fastcall RBX::Studio::FeatureActivityTracker::endSession(RbxQt *a1, __int128 *a2, __int64 a3, __int64 a4)
{
  __int128 v8; // [rsp+0h] [rbp-60h] BYREF
  void *v9; // [rsp+10h] [rbp-50h]
  __int128 v10; // [rsp+20h] [rbp-40h] BYREF
  void *v11; // [rsp+30h] [rbp-30h]

  RbxQt::RequireUIThread(this: a1); /*0x1011521df*/
  v9 = *((void **)a2 + 2); /*0x1011521ec*/
  v8 = *a2; /*0x1011521f4*/
  *a2 = 0; /*0x1011521fa*/
  *((_QWORD *)a2 + 2) = 0; /*0x101152200*/
  v11 = nullptr; /*0x101152208*/
  v10 = 0; /*0x10115220c*/
  (*(void (__fastcall **)(RbxQt *, __int128 *, __int128 *, __int64, __int64))(*(_QWORD *)a1 + 120LL))( /*0x10115221c*/
    a1,
    a2: &v8,
    a3: &v10,
    a4: a3,
    a5: a4);
  if ( (v10 & 1) != 0 ) /*0x101152223*/
    operator delete(a1: v11); /*0x101152229*/
  if ( (v8 & 1) != 0 ) /*0x101152232*/
    operator delete(a1: v9); /*0x101152238*/
}

// Address: 0x10115226e | Name: __ZThn16_N3RBX6Studio22FeatureActivityTracker10endSessionENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS_10StringViewE
void __fastcall `non-virtual thunk to'RBX::Studio::FeatureActivityTracker::endSession(
        __int64 a1,
        __int128 *a2,
        __int64 a3,
        __int64 a4)
{
  RBX::Studio::FeatureActivityTracker::endSession(a1: (RbxQt *)(a1 - 16), a2, a3, a4); /*0x101152277*/
}

// Address: 0x10115227c | Name: __ZN3RBX6Studio22FeatureActivityTracker10endSessionENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEES8_NS_10StringViewE
void __fastcall RBX::Studio::FeatureActivityTracker::endSession(
        RbxQt *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5)
{
  __int64 v9; // rax
  _BYTE v10[16]; // [rsp+8h] [rbp-48h] BYREF
  void *v11; // [rsp+18h] [rbp-38h]
  __int64 v12; // [rsp+20h] [rbp-30h]

  v12 = a5; /*0x10115228d*/
  RbxQt::RequireUIThread(this: a1); /*0x10115229d*/
  std::operator+[abi:ne200100]<char,std::char_traits<char>,std::allocator<char>>(a1: v10, a2, a3); /*0x1011522af*/
  v9 = std::__hash_table<std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Studio::FeatureSession>>>::find<std::string>( /*0x1011522bb*/
         a1: (char *)a1 + 48,
         a2: v10);
  if ( v9 != 0 ) /*0x1011522c3*/
    (*(void (__fastcall **)(RbxQt *, __int64, __int64, __int64))(*(_QWORD *)a1 + 136LL))(a1, a2: v9, a3: a4, a4: v12); /*0x1011522d5*/
  if ( (v10[0] & 1) != 0 ) /*0x1011522e0*/
    operator delete(a1: v11); /*0x1011522e6*/
}

// Address: 0x101152314 | Name: __ZThn16_N3RBX6Studio22FeatureActivityTracker10endSessionENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEES8_NS_10StringViewE
void __fastcall `non-virtual thunk to'RBX::Studio::FeatureActivityTracker::endSession(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5)
{
  RBX::Studio::FeatureActivityTracker::endSession(a1: (RbxQt *)(a1 - 16), a2, a3, a4, a5); /*0x10115231d*/
}

// Address: 0x101152322 | Name: __ZN3RBX6Studio22FeatureActivityTracker31endSessionWithTelemetryAndEraseENSt3__119__hash_map_iteratorINS2_15__hash_iteratorIPNS2_11__hash_nodeINS2_17__hash_value_typeINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS0_14FeatureSessionEEEPvEEEEEENS_10StringViewE
__int64 __fastcall RBX::Studio::FeatureActivityTracker::endSessionWithTelemetryAndErase(
        RbxQt *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  __int64 v4; // r12
  __int64 v5; // r13
  __int64 v9; // [rsp+0h] [rbp-40h] BYREF
  __int64 v10; // [rsp+8h] [rbp-38h] BYREF
  __int64 v11; // [rsp+10h] [rbp-30h]

  v4 = a4; /*0x101152333*/
  v5 = a3; /*0x101152336*/
  v10 = a3; /*0x10115233f*/
  v11 = a4; /*0x101152343*/
  RbxQt::RequireUIThread(this: a1); /*0x101152347*/
  *(_QWORD *)(a2 + 104) = (*(__int64 (__fastcall **)(RbxQt *))(*(_QWORD *)a1 + 128LL))(a1); /*0x10115235c*/
  if ( (unsigned __int8)FLog::StudioFeatureActivityTrackerLog >= 6u
    && (FLog::StudioFeatureActivityTrackerLog & 0xFC00) != 0 )
  {
    v9 = (*(_QWORD *)(a2 + 96) - *(_QWORD *)(a2 + 88)) / 1000000LL; /*0x1011523ad*/
    FLog::FastLogSafeFormatted<std::string &,std::string &,RBX::StringView &,long long>(
      a1: FLog::StudioFeatureActivityTrackerLog,
      a2: qword_10D504898,
      a3: 4,
      a4: (int)"[FLog::StudioFeatureActivityTrackerLog] Session end - \"{}\" / \"{}\" - {} - duration: {}s",
      a5: 86,
      a6: (unsigned __int8 *)(a2 + 40),
      a7: (unsigned __int8 *)(a2 + 64),
      a8: (__int64)&v10,
      a9: &v9);
    v5 = v10; /*0x1011523db*/
    v4 = v11; /*0x1011523df*/
  }
  RBX::Studio::FeatureActivityTracker::sendSessionEndTelemetry(a1: a2 + 40, a2: v5, a3: v4); /*0x1011523ed*/
  return std::__hash_table<std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Studio::FeatureSession>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Studio::FeatureSession>>>::erase( /*0x101152401*/
           a1: (char *)a1 + 48,
           a2);
}

// Address: 0x1011524b4 | Name: __ZN3RBX6Studio22FeatureActivityTracker23sendSessionEndTelemetryERKNS0_14FeatureSessionENS_10StringViewE
void __fastcall RBX::Studio::FeatureActivityTracker::sendSessionEndTelemetry(RbxQt *a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rbx
  __int64 v5; // r13
  __int64 v6; // r15
  __int64 v7; // rdx
  __int64 v8; // rcx
  unsigned int v9; // r8d
  unsigned __int8 *v10; // rcx
  __int64 v11; // r8
  unsigned int v12; // r8d
  __int64 v13; // r8
  unsigned __int8 *v14; // r14
  _BYTE v15[72]; // [rsp+8h] [rbp-2A8h] BYREF
  _BYTE v16[528]; // [rsp+50h] [rbp-260h] BYREF
  _BYTE v17[16]; // [rsp+260h] [rbp-50h] BYREF
  void *v18; // [rsp+270h] [rbp-40h]
  __int64 v19; // [rsp+278h] [rbp-38h]
  __int64 v20; // [rsp+280h] [rbp-30h]

  v19 = a3; /*0x1011524c8*/
  v20 = a2; /*0x1011524cc*/
  RbxQt::RequireUIThread(this: a1); /*0x1011524d3*/
  v4 = std::chrono::system_clock::to_time_t(a1: (char *)a1 + 48); /*0x1011524e1*/
  v5 = std::chrono::system_clock::to_time_t(a1: (char *)a1 + 64); /*0x1011524ed*/
  v6 = std::chrono::system_clock::to_time_t(a1: (char *)a1 + 56); /*0x1011524f9*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)1,std::enable_if<true,void>>( /*0x10115250a*/
    a1: v15,
    a2: &RBX::Telemetry::kFeatureActivityTrackerSessionEnd);
  std::string::basic_string[abi:ne200100]<0>(a1: v17, a2: "", a3: v7, a4: v8); /*0x10115251a*/
  RBX::Telemetry::FieldsContainer::addPlaceId(this: (RBX::Analytics *)v16); /*0x10115252d*/
  if ( (v17[0] & 1) != 0 ) /*0x101152536*/
    operator delete(a1: v18); /*0x10115253c*/
  v9 = *(unsigned __int8 *)a1; /*0x101152541*/
  if ( (v9 & 1) != 0 ) /*0x101152549*/
  {
    v10 = *((unsigned __int8 **)a1 + 2); /*0x10115254b*/
    v11 = *((_QWORD *)a1 + 1); /*0x10115254f*/
  }
  else
  {
    v10 = (unsigned __int8 *)a1 + 1; /*0x101152555*/
    v11 = v9 >> 1; /*0x101152559*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "featureName", a3: 11, a4: v10, a5: v11, a6: 1); /*0x101152571*/
  v12 = *((unsigned __int8 *)a1 + 24); /*0x101152576*/
  if ( (v12 & 1) != 0 ) /*0x10115257f*/
  {
    v13 = *((_QWORD *)a1 + 4); /*0x101152581*/
    v14 = *((unsigned __int8 **)a1 + 5); /*0x101152585*/
  }
  else
  {
    v14 = (unsigned __int8 *)a1 + 25; /*0x10115258b*/
    v13 = v12 >> 1; /*0x10115258f*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "featureSessionId", a3: 16, a4: v14, a5: v13, a6: 1); /*0x1011525aa*/
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "startTimeUnix", a3: 13, a4: v4, a5: 1); /*0x1011525c7*/
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "endTimeUnix", a3: 11, a4: v5, a5: 1); /*0x1011525e4*/
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "lastActivityTimeUnix", a3: 20, a4: v6, a5: 1); /*0x101152601*/
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "reason", a3: 6, a4: v20, a5: v19, a6: 1); /*0x101152623*/
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v15); /*0x10115262f*/
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v15); /*0x101152642*/
}

// Address: 0x101152690 | Name: __ZN3RBX6Studio22FeatureActivityTracker19onHardwareWillSleepEv
void __fastcall RBX::Studio::FeatureActivityTracker::onHardwareWillSleep(RBX::Studio::FeatureActivityTracker *this)
{
  RBX::Telemetry::RobloxTelemetryEvent *v2; // rsi
  RBX::Telemetry::RobloxTelemetryEvent *v3; // rsi
  _BYTE v4[616]; // [rsp+8h] [rbp-268h] BYREF

  RbxQt::RequireUIThread(this); /*0x1011526a1*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)3,std::enable_if<true,void>>( /*0x1011526b7*/
    a1: v4,
    a2: &RBX::Telemetry::kWillSleep);
  RBX::Analytics::Studio::addStudioClientId(this: (RBX::Analytics::Studio *)v4, a2: v2); /*0x1011526bf*/
  RBX::Analytics::Studio::addStudioSessionId(this: (RBX::Analytics::Studio *)v4, a2: v3); /*0x1011526cb*/
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v4); /*0x1011526d7*/
  (*(void (__fastcall **)(RBX::Studio::FeatureActivityTracker *, const char *, __int64))(*(_QWORD *)this + 152LL))( /*0x1011526ee*/
    a1: this,
    a2: "HardwareSleep",
    a3: 13);
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v4); /*0x101152702*/
}

// Address: 0x101152734 | Name: __ZN3RBX6Studio22FeatureActivityTracker17onHardwareDidWakeEv
void __fastcall RBX::Studio::FeatureActivityTracker::onHardwareDidWake(RBX::Studio::FeatureActivityTracker *this)
{
  RBX::Telemetry::RobloxTelemetryEvent *v1; // rsi
  RBX::Telemetry::RobloxTelemetryEvent *v2; // rsi
  _BYTE v3[608]; // [rsp+0h] [rbp-260h] BYREF

  RbxQt::RequireUIThread(this); /*0x101152740*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)3,std::enable_if<true,void>>( /*0x101152756*/
    a1: v3,
    a2: &RBX::Telemetry::kDidWake);
  RBX::Analytics::Studio::addStudioClientId(this: (RBX::Analytics::Studio *)v3, a2: v1); /*0x10115275e*/
  RBX::Analytics::Studio::addStudioSessionId(this: (RBX::Analytics::Studio *)v3, a2: v2); /*0x10115276a*/
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v3); /*0x101152776*/
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v3); /*0x101152789*/
}

// Address: 0x1011527b6 | Name: __ZN3RBX6Studio22FeatureActivityTracker12onMonitorOffEv
void __fastcall RBX::Studio::FeatureActivityTracker::onMonitorOff(RBX::Studio::FeatureActivityTracker *this)
{
  RBX::Telemetry::RobloxTelemetryEvent *v2; // rsi
  RBX::Telemetry::RobloxTelemetryEvent *v3; // rsi
  _BYTE v4[616]; // [rsp+8h] [rbp-268h] BYREF

  RbxQt::RequireUIThread(this); /*0x1011527c7*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)3,std::enable_if<true,void>>( /*0x1011527dd*/
    a1: v4,
    a2: &RBX::Telemetry::kMonitorIsOff);
  RBX::Analytics::Studio::addStudioClientId(this: (RBX::Analytics::Studio *)v4, a2: v2); /*0x1011527e5*/
  RBX::Analytics::Studio::addStudioSessionId(this: (RBX::Analytics::Studio *)v4, a2: v3); /*0x1011527f1*/
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v4); /*0x1011527fd*/
  (*(void (__fastcall **)(RBX::Studio::FeatureActivityTracker *, const char *, __int64))(*(_QWORD *)this + 152LL))( /*0x101152814*/
    a1: this,
    a2: "HardwareSleep",
    a3: 13);
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v4); /*0x101152828*/
}

// Address: 0x101152858 | Name: __ZN3RBX6Studio22FeatureActivityTracker11onMonitorOnEv
void __fastcall RBX::Studio::FeatureActivityTracker::onMonitorOn(RBX::Studio::FeatureActivityTracker *this)
{
  RBX::Telemetry::RobloxTelemetryEvent *v1; // rsi
  RBX::Telemetry::RobloxTelemetryEvent *v2; // rsi
  _BYTE v3[608]; // [rsp+0h] [rbp-260h] BYREF

  RbxQt::RequireUIThread(this); /*0x101152864*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)3,std::enable_if<true,void>>( /*0x10115287a*/
    a1: v3,
    a2: &RBX::Telemetry::kMonitorIsOn);
  RBX::Analytics::Studio::addStudioClientId(this: (RBX::Analytics::Studio *)v3, a2: v1); /*0x101152882*/
  RBX::Analytics::Studio::addStudioSessionId(this: (RBX::Analytics::Studio *)v3, a2: v2); /*0x10115288e*/
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v3); /*0x10115289a*/
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v3); /*0x1011528ad*/
}

// Address: 0x1011528da | Name: __ZN3RBX6Studio22FeatureActivityTracker19endInactiveSessionsEv
char __fastcall RBX::Studio::FeatureActivityTracker::endInactiveSessions(RBX::Studio::FeatureActivityTracker *this)
{
  __int64 v2; // rax
  __int64 v3; // r14
  __int64 v4; // rdx
  _QWORD v6[3]; // [rsp+10h] [rbp-50h] BYREF
  __int64 v7[7]; // [rsp+28h] [rbp-38h] BYREF

  RbxQt::RequireUIThread(this); /*0x1011528ee*/
  LOBYTE(v2) = (unsigned __int8)FLog::StudioFeatureActivityTrackerLog < 6u /*0x10115290b*/
            || BYTE1(FLog::StudioFeatureActivityTrackerLog) < 5u;
  if ( (_BYTE)v2 == 0 )
  {
    v6[0] = *((_QWORD *)this + 9); /*0x10115291e*/
    v7[0] = 4; /*0x101152921*/
    v7[1] = (__int64)v6; /*0x101152929*/
    LOBYTE(v2) = FLog::detail::FastLogSafeFormattedInternal(
                   a1: FLog::StudioFeatureActivityTrackerLog,
                   a2: qword_10D504898,
                   a3: 5,
                   a4: (unsigned int)"[FLog::StudioFeatureActivityTrackerLog] Checking for inactive sessions : Tracked sessions ({})",
                   a5: 94,
                   a6: 1,
                   4,
                   v6,
                   v6[0]);
  }
  v3 = *((_QWORD *)this + 8); /*0x101152952*/
  while ( v3 != 0 )
  {
    v4 = ((*(__int64 (__fastcall **)(RBX::Studio::FeatureActivityTracker *))(*(_QWORD *)this + 128LL))(a1: this) /*0x101152995*/
        - *(_QWORD *)(v3 + 96))
       / 1000000;
    v7[0] = v4; /*0x101152998*/
    if ( (unsigned __int8)FLog::StudioFeatureActivityTrackerLog >= 6u
      && BYTE1(FLog::StudioFeatureActivityTrackerLog) >= 5u )
    {
      FLog::FastLogSafeFormatted<std::string &,std::string &,long long &>(
        a1: FLog::StudioFeatureActivityTrackerLog,
        a2: qword_10D504898,
        a3: 5,
        a4: (int)"[FLog::StudioFeatureActivityTrackerLog] \"{}\" / \"{}\": {}s since last activity",
        a5: 76,
        a6: (unsigned __int8 *)(v3 + 40),
        a7: (unsigned __int8 *)(v3 + 64),
        a8: v7);
      v4 = v7[0]; /*0x1011529e7*/
    }
    LOBYTE(v2) = FInt::StudioFeatureActivityTrackerInactivityDurationSeconds; /*0x1011529eb*/
    if ( v4 <= FInt::StudioFeatureActivityTrackerInactivityDurationSeconds ) /*0x1011529f5*/
    {
      v3 = *(_QWORD *)v3; /*0x101152a13*/
    }
    else
    {
      v2 = (*(__int64 (__fastcall **)(RBX::Studio::FeatureActivityTracker *, __int64, const char *, __int64))(*(_QWORD *)this + 136LL))( /*0x101152a08*/
             a1: this,
             a2: v3,
             a3: "Inactivity",
             a4: 10);
      v3 = v2; /*0x101152a0e*/
    }
  }
  return v2; /*0x101152a1f*/
}

// Address: 0x101152abe | Name: __ZN3RBX6Studio22FeatureActivityTracker14endAllSessionsENS_10StringViewE
__int64 __fastcall RBX::Studio::FeatureActivityTracker::endAllSessions(RbxQt *a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax

  RbxQt::RequireUIThread(this: a1); /*0x101152ad1*/
  for ( result = *((_QWORD *)a1 + 8); /*0x101152ad6*/
        result != 0;
        result = (*(__int64 (__fastcall **)(RbxQt *, __int64, __int64, __int64))(*(_QWORD *)a1 + 136LL))(
                   a1,
                   a2: result,
                   a3: a2,
                   a4: a3) )
  {
    ; /*0x101152aee*/
  }
  return result; /*0x101152afb*/
}

// Address: 0x10708d0c8 | Name: __ZN3RBX6Studio22FeatureActivityTracker18qt_static_metacallEP7QObjectN11QMetaObject4CallEiPPv
void __fastcall RBX::Studio::FeatureActivityTracker::qt_static_metacall(
        RBX::Studio::FeatureActivityTracker *a1,
        int a2,
        int a3)
{
  if ( a2 == 0 ) /*0x10708d0ce*/
  {
    switch ( a3 ) /*0x10708d0e7*/
    {
      case 0: /*0x10708d0e7*/
        RBX::Studio::FeatureActivityTracker::onApplicationWillClose(this: a1); /*0x10708d0ea*/
        break; /*0x10708d0ea*/
      case 1: /*0x10708d0e7*/
        RBX::Studio::FeatureActivityTracker::onHardwareWillSleep(this: a1); /*0x10708d102*/
        break; /*0x10708d102*/
      case 2: /*0x10708d0e7*/
        RBX::Studio::FeatureActivityTracker::onHardwareDidWake(this: a1); /*0x10708d0f6*/
        break; /*0x10708d0f6*/
      case 3: /*0x10708d0e7*/
        RBX::Studio::FeatureActivityTracker::onMonitorOff(this: a1); /*0x10708d0fc*/
        break; /*0x10708d0fc*/
      case 4: /*0x10708d0e7*/
        RBX::Studio::FeatureActivityTracker::onMonitorOn(this: a1); /*0x10708d0f0*/
        break; /*0x10708d0f0*/
      default:
        return;
    }
  }
}

// Address: 0x10708d11c | Name: __ZNK3RBX6Studio22FeatureActivityTracker10metaObjectEv
_UNKNOWN **__fastcall RBX::Studio::FeatureActivityTracker::metaObject(RBX::Studio::FeatureActivityTracker *this)
{
  QObjectData *v1; // rdi

  v1 = *((QObjectData **)this + 1); /*0x10708d120*/
  if ( *((_QWORD *)v1 + 5) != 0 ) /*0x10708d129*/
    return (_UNKNOWN **)QObjectData::dynamicMetaObject(this: v1); /*0x10708d12c*/
  else
    return &RBX::Studio::FeatureActivityTracker::staticMetaObject; /*0x10708d131*/
}

// Address: 0x10708d13a | Name: __ZN3RBX6Studio22FeatureActivityTracker11qt_metacastEPKc
RBX::Studio::FeatureActivityTracker *__fastcall RBX::Studio::FeatureActivityTracker::qt_metacast(
        RBX::Studio::FeatureActivityTracker *this,
        const char *a2)
{
  if ( a2 == nullptr ) /*0x10708d144*/
    return nullptr; /*0x10708d181*/
  if ( strcmp(__s1: a2, __s2: aRbxStudioFeatu) != 0 ) /*0x10708d15d*/
  {
    if ( strcmp(__s1: a2, __s2: "IFeatureActivityTracker") != 0 ) /*0x10708d170*/
      return (RBX::Studio::FeatureActivityTracker *)QObject::qt_metacast(this, a2); /*0x10708d17c*/
    return (RBX::Studio::FeatureActivityTracker *)((char *)this + 16); /*0x10708d185*/
  }
  return this; /*0x10708d178*/
}

// Address: 0x10708d192 | Name: __ZN3RBX6Studio22FeatureActivityTracker11qt_metacallEN11QMetaObject4CallEiPPv
__int64 __fastcall RBX::Studio::FeatureActivityTracker::qt_metacall(
        RBX::Studio::FeatureActivityTracker *a1,
        int a2,
        __int64 a3,
        _DWORD **a4)
{
  int v7; // eax
  unsigned int v8; // ebx

  v7 = QObject::qt_metacall(); /*0x10708d1a6*/
  v8 = v7; /*0x10708d1ab*/
  if ( v7 >= 0 ) /*0x10708d1af*/
  {
    if ( a2 == 12 ) /*0x10708d1b5*/
    {
      if ( (unsigned int)v7 <= 4 ) /*0x10708d1d2*/
        **a4 = -1; /*0x10708d1d7*/
      goto LABEL_8; /*0x10708d1d7*/
    }
    if ( a2 == 0 ) /*0x10708d1ba*/
    {
      if ( (unsigned int)v7 <= 4 ) /*0x10708d1bf*/
        RBX::Studio::FeatureActivityTracker::qt_static_metacall(a1, a2: 0, a3: v7); /*0x10708d1c8*/
LABEL_8:
      v8 -= 5; /*0x10708d1dd*/
    }
  }
  return v8; /*0x10708d1e2*/
}

// Address: 0x108534a7d | Name: __ZN3RBX6Studio22FeatureActivityTracker6defineEv.cold.1
__int64 __fastcall RBX::Studio::FeatureActivityTracker::define(RBX::Studio::FeatureActivityTracker *this)
{
  __int64 v1; // rsi
  __int64 result; // rax

  v1 = *(_QWORD *)this; /*0x108534a7d*/
  *(_QWORD *)this = 0; /*0x108534a80*/
  if ( v1 != 0 ) /*0x108534a87*/
    return std::default_delete<RBX::Component::ComponentSpec>::operator()[abi:ne200100](a1: this); /*0x108534a8d*/
  return result; /*0x108534a93*/
}

// Address: 0x108534a94 | Name: __ZN3RBX6Studio22FeatureActivityTracker11logActivityENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE.cold.1
void __fastcall RBX::Studio::FeatureActivityTracker::logActivity(__int64 a1)
{
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x108534a97*/
    operator delete(a1: *(void **)(a1 + 16)); /*0x108534aa1*/
}

// Address: 0x108534aa8 | Name: __ZN3RBX6Studio22FeatureActivityTracker10endSessionENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS_10StringViewE.cold.1
void __fastcall RBX::Studio::FeatureActivityTracker::endSession(__int64 a1)
{
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x108534aab*/
    operator delete(a1: *(void **)(a1 + 16)); /*0x108534ab5*/
}

// END FeatureActivityTracker part 1/1, 36 functions
