// SessionCrypto -- 2022 Studio + full PDB
// tier 3, 20 functions


// Address: 0x1410b8a30 | Name: ??1SessionCrypto@Security@RBX@@UEAA@XZ
void __fastcall RBX::Security::SessionCrypto::~SessionCrypto(RBX::Security::SessionCrypto *this)
{
  std::_Ref_count_base *Rep; // rbx
  RBX::Security::SessionCrypto::KeyExchangeKeys *Myval2; // rbx

  this->__vftable = (RBX::Security::SessionCrypto_vtbl *)RBX::Security::SessionCrypto::`vftable'; /*0x1410b8a42*/
  Rep = this->earlyAuthData._Rep; /*0x1410b8a48*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b8a65*/
  {
    Rep->_Destroy(this: Rep); /*0x1410b8a6d*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b8a77*/
      Rep->_Delete_this(this: Rep); /*0x1410b8a7f*/
  }
  Myval2 = this->keyExchangeKeys._Mypair._Myval2; /*0x1410b8a87*/
  if ( Myval2 != nullptr ) /*0x1410b8a93*/
  {
    RBX::Security::SessionCrypto::KeyExchangeKeys::~KeyExchangeKeys(this: Myval2); /*0x1410b8a98*/
    operator delete(ptr: Myval2); /*0x1410b8aaa*/
  }
}

// Address: 0x1421bb930 | Name: ??0SessionCrypto@Security@RBX@@IEAA@XZ
RBX::Security::SessionCrypto *__fastcall RBX::Security::SessionCrypto::SessionCrypto(
        RBX::Security::SessionCrypto *this)
{
  this->__vftable = (RBX::Security::SessionCrypto_vtbl *)RBX::Security::SessionCrypto::`vftable'; /*0x1421bb939*/
  this->appNonce._Storage._Value = 0; /*0x1421bb93e*/
  this->txRakNonce._Storage._Value = 0; /*0x1421bb942*/
  this->keyExchangeKeys._Mypair._Myval2 = nullptr; /*0x1421bb946*/
  *(_DWORD *)&this->isServer = 0; /*0x1421bb94a*/
  this->rakFormat = NoCrypto; /*0x1421bb94d*/
  this->earlyAuthData._Ptr = nullptr; /*0x1421bb95a*/
  this->earlyAuthData._Rep = nullptr; /*0x1421bb95e*/
  this->rxRakNonce = 0x754E657571696E55LL; /*0x1421bb962*/
  _InterlockedExchange64((volatile __int64 *)&this->txRakNonce, 0x754E657571696E55LL); /*0x1421bb966*/
  return this; /*0x1421bb96d*/
}

// Address: 0x1421bb9d0 | Name: ?decryptData@SessionCrypto@Security@RBX@@QEBA?AV?$optional@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@std@@V?$ArrayView@E@3@@Z
std::optional<std::string > *__fastcall RBX::Security::SessionCrypto::decryptData(
        RBX::Security::SessionCrypto *this,
        std::optional<std::string > *result,
        RBX::ArrayView<unsigned char> *box)
{
  unsigned __int64 length; // rax
  unsigned __int64 v7; // r14
  std::optional<std::string > *p_message; // r11
  char *Ptr; // rcx
  unsigned __int64 Myres; // rdx
  __int64 v11; // rax
  bool Has_value; // al
  char *v14; // rax
  unsigned __int8 *ca[2]; // [rsp+50h] [rbp-9h]
  std::optional<std::string > message; // [rsp+70h] [rbp+17h] BYREF
  $398703F7114EBF6440C4EA32EC5760FD c; // 0:^50.32

  length = box->length; /*0x1421bb9f9*/
  if ( length < 0x1C ) /*0x1421bba01*/
  {
    result->_Has_value = false; /*0x1421bba03*/
    return result; /*0x1421bba07*/
  }
  __wind /*0xf1c0000000000010*/
  {
    c._Value._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1421bba0f*/
    c._Value._Mypair._Myval2._Mysize = 0; /*0x1421bba13*/
    c._Value._Mypair._Myval2._Myres = 15; /*0x1421bba17*/
    message.___u0 = c; /*0x1421bba23*/
    message._Has_value = true; /*0x1421bba2f*/
    v7 = length - 28; /*0x1421bba33*/
    std::string::resize(this: (std::string *)&message, _Newsize: length - 28, _Ch: 0); /*0x1421bba41*/
    p_message = &message; /*0x1421bba46*/
    Ptr = message._Value._Mypair._Myval2._Bx._Ptr; /*0x1421bba4a*/
    Myres = message._Value._Mypair._Myval2._Myres; /*0x1421bba4e*/
    if ( message._Value._Mypair._Myval2._Myres >= 0x10 ) /*0x1421bba56*/
      p_message = (std::optional<std::string > *)message._Value._Mypair._Myval2._Bx._Ptr; /*0x1421bba56*/
    *(RBX::ArrayView<unsigned char> *)ca = *box; /*0x1421bba5d*/
    if ( !this->isError /*0x1421bba8a*/
      && this->isSessionReady
      && (unsigned __int8 *)v7 == ca[1] - 28
      && ca[1] >= (unsigned __int8 *)0x1C )
    {
      v11 = 64; /*0x1421bba9c*/
      if ( !this->isServer ) /*0x1421bbaaa*/
        v11 = 96; /*0x1421bbaaa*/
      if ( crypto_aead_chacha20poly1305_ietf_decrypt_detached( /*0x1421bbad8*/
             m: (unsigned __int8 *)p_message,
             nsec: nullptr,
             c: ca[0],
             clen: v7,
             mac: &ca[0][v7 + 12],
             ad: nullptr,
             adlen: 0,
             npub: &ca[0][v7],
             k: (const unsigned __int8 *)this + v11) == 0 )
      {
        result->_Has_value = false; /*0x1421bbade*/
        Has_value = message._Has_value; /*0x1421bbae2*/
        if ( message._Has_value ) /*0x1421bbae8*/
        {
          result->___u0 = message.___u0; /*0x1421bbaee*/
          *(__m128i *)&message._Value._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x1421bbb01*/
          message._Value._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1421bbb06*/
          result->_Has_value = true; /*0x1421bbb0a*/
        }
        if ( !Has_value || message._Value._Mypair._Myval2._Myres < 0x10 ) /*0x1421bbb1a*/
          return result; /*0x1421bbb1a*/
        Ptr = message._Value._Mypair._Myval2._Bx._Ptr; /*0x1421bbb1f*/
        if ( message._Value._Mypair._Myval2._Myres + 1 < 0x1000 ) /*0x1421bbb2d*/
          goto LABEL_18; /*0x1421bbb2d*/
        Ptr = *((char **)message._Value._Mypair._Myval2._Bx._Ptr - 1); /*0x1421bbb33*/
        if ( (unsigned __int64)(message._Value._Mypair._Myval2._Bx._Ptr - Ptr - 8) <= 0x1F ) /*0x1421bbb42*/
          goto LABEL_18; /*0x1421bbb42*/
        goto LABEL_25; /*0x1421bbb42*/
      }
      Myres = message._Value._Mypair._Myval2._Myres; /*0x1421bbb69*/
      Ptr = message._Value._Mypair._Myval2._Bx._Ptr; /*0x1421bbb6d*/
    }
    result->_Has_value = false; /*0x1421bbb71*/
    if ( message._Has_value && Myres >= 0x10 ) /*0x1421bbb7f*/
    {
      v14 = Ptr; /*0x1421bbb84*/
      if ( Myres + 1 < 0x1000 || (Ptr = *((char **)Ptr - 1), (unsigned __int64)(v14 - Ptr - 8) <= 0x1F) ) /*0x1421bbba3*/
      {
LABEL_18:
        operator delete(ptr: Ptr); /*0x1421bbb44*/
        return result; /*0xf1c000000000001c*/
      }
LABEL_25:
      _invalid_parameter_noinfo_noreturn(); /*0x1421bbba5*/
    }
  }
  __unwind
  {
    std::optional<std::string>::~optional<std::string>(this: (Luau::FunctionDefinition *)&message); /*0xf1c0000000000008*/
  }
  return result; /*0x1421bbb4c*/
}

// Address: 0x1421bbbb0 | Name: ?decryptRakDataInPlace@SessionCrypto@Security@RBX@@QEAA_NV?$MutableArrayView@E@3@@Z
char __fastcall RBX::Security::SessionCrypto::decryptRakDataInPlace(
        RBX::Security::SessionCrypto *this,
        RBX::MutableArrayView<unsigned char> *boxToMessage)
{
  unsigned __int64 length; // r8
  unsigned __int64 v4; // r9
  const unsigned __int8 *buffer; // r10
  int (__fastcall *v6)(unsigned __int8 *, unsigned __int8 *, const unsigned __int8 *, unsigned __int64, const unsigned __int8 *, const unsigned __int8 *, unsigned __int64, const unsigned __int8 *, const unsigned __int8 *); // rbp
  int v7; // edi
  __int64 v8; // rsi
  int v9; // edi

  length = boxToMessage->length; /*0x1421bbbbf*/
  if ( length < 0x12 ) /*0x1421bbbca*/
    return 0; /*0x1421bbbca*/
  buffer = boxToMessage->buffer; /*0x1421bbbd8*/
  if ( this->isError || !this->isSessionReady ) /*0x1421bbbe5*/
    return 0; /*0x1421bbbe5*/
  v6 = crypto_aead_chacha20poly1305_ietf_decrypt_detached; /*0x1421bbc03*/
  v4 = length - 18; /*0x1421bbbd4*/
  if ( (this->rakFormat & 2) != 0 ) /*0x1421bbc1d*/
    v6 = crypto_aead_aes256gcm_decrypt_detached; /*0x1421bbc1d*/
  v7 = *(unsigned __int16 *)&buffer[v4]; /*0x1421bbc27*/
  v8 = *(unsigned __int16 *)&buffer[v4]; /*0x1421bbc29*/
  if ( ((unsigned int (__fastcall *)(const unsigned __int8 *, _QWORD, const unsigned __int8 *))v6)( /*0x1421bbca2*/
         a1: buffer,
         a2: 0,
         a3: buffer) != 0 )
    return 0; /*0x1421bbd08*/
  v9 = v7 - LOWORD(this->rxRakNonce); /*0x1421bbca8*/
  if ( v9 >= -32768 ) /*0x1421bbcb0*/
  {
    if ( v9 > 0 ) /*0x1421bbce0*/
    {
      this->rxRakNonce &= 0xFFFFFFFFFFFF0000uLL; /*0x1421bbce2*/
      this->rxRakNonce |= v8; /*0x1421bbcea*/
    }
    return 1; /*0x1421bbcee*/
  }
  else
  {
    this->rxRakNonce = v8 | (this->rxRakNonce + 0x10000) & 0xFFFFFFFFFFFF0000uLL; /*0x1421bbcc5*/
    return 1; /*0x1421bbcc9*/
  }
}

// Address: 0x1421bbd20 | Name: ?decryptString@SessionCrypto@Security@RBX@@QEBA?AV?$optional@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@std@@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@5@@Z
std::optional<std::string > *__fastcall RBX::Security::SessionCrypto::decryptString(
        RBX::Security::SessionCrypto *this,
        std::optional<std::string > *result,
        const std::string *box)
{
  unsigned __int64 Mysize; // rax
  RBX::ArrayView<unsigned char> v6; // [rsp+20h] [rbp-18h] BYREF

  Mysize = box->_Mypair._Myval2._Mysize; /*0x1421bbd2e*/
  if ( box->_Mypair._Myval2._Myres >= 0x10 ) /*0x1421bbd32*/
    box = (const std::string *)box->_Mypair._Myval2._Bx._Ptr; /*0x1421bbd34*/
  v6.buffer = (const unsigned __int8 *)box; /*0x1421bbd37*/
  v6.length = Mysize; /*0x1421bbd41*/
  RBX::Security::SessionCrypto::decryptData(this, result, box: &v6); /*0x1421bbd46*/
  return result; /*0x1421bbd4e*/
}

// Address: 0x1421bbd60 | Name: ?earlyDecryptData@SessionCrypto@Security@RBX@@IEBA_NV?$MutableArrayView@E@3@V?$ArrayView@E@3@_K@Z
bool __fastcall RBX::Security::SessionCrypto::earlyDecryptData(
        RBX::Security::SessionCrypto *this,
        RBX::MutableArrayView<unsigned char> *message,
        RBX::ArrayView<unsigned char> *box,
        size_t aadSize)
{
  unsigned __int8 *buffer; // rbx
  __int64 v7; // rsi
  const unsigned __int8 *ad; // rdi
  const unsigned __int8 *k; // rsi

  if ( this->isError || !this->isEarlySessionReady ) /*0x1421bbd7f*/
    return false; /*0x1421bbd7f*/
  buffer = (unsigned __int8 *)message->buffer; /*0x1421bbd93*/
  v7 = 128; /*0x1421bbd9b*/
  if ( !this->isServer ) /*0x1421bbda0*/
    v7 = 160; /*0x1421bbda0*/
  ad = box->buffer; /*0x1421bbda8*/
  k = &this->keyExchangeKeys._Mypair._Myval2->publicEphemeralKey._Elems[v7]; /*0x1421bbdae*/
  memcpy_0(a1: buffer, Src: box->buffer, Size: aadSize); /*0x1421bbdb8*/
  return crypto_aead_chacha20poly1305_ietf_decrypt_detached( /*0x1421bbe1a*/
           m: &buffer[aadSize],
           nsec: nullptr,
           c: &ad[aadSize],
           clen: message->length - aadSize,
           mac: &ad[message->length + 12],
           ad,
           adlen: aadSize,
           npub: &ad[message->length],
           k) == 0;
}

// Address: 0x1421bbe30 | Name: ?earlyEncryptData@SessionCrypto@Security@RBX@@IEBA_NV?$MutableArrayView@E@3@V?$ArrayView@E@3@_K@Z
bool __fastcall RBX::Security::SessionCrypto::earlyEncryptData(
        RBX::Security::SessionCrypto *this,
        RBX::MutableArrayView<unsigned char> *box,
        RBX::ArrayView<unsigned char> *message,
        size_t aadSize)
{
  unsigned __int8 *buffer; // rbx
  __int64 v8; // rsi
  const unsigned __int8 *ad; // rdi
  const unsigned __int8 *k; // rsi
  unsigned __int64 length; // r10
  unsigned __int8 *npub; // [rsp+40h] [rbp-38h]
  unsigned __int64 macLen; // [rsp+80h] [rbp+8h] BYREF

  if ( this->isError || !this->isEarlySessionReady ) /*0x1421bbe53*/
    return false; /*0x1421bbe53*/
  buffer = (unsigned __int8 *)box->buffer; /*0x1421bbe61*/
  v8 = 160; /*0x1421bbe68*/
  ad = message->buffer; /*0x1421bbe76*/
  if ( !this->isServer ) /*0x1421bbe79*/
    v8 = 128; /*0x1421bbe79*/
  k = &this->keyExchangeKeys._Mypair._Myval2->publicEphemeralKey._Elems[v8]; /*0x1421bbe7c*/
  memcpy_0(a1: buffer, Src: ad, Size: aadSize); /*0x1421bbe89*/
  length = message->length; /*0x1421bbe8e*/
  npub = &buffer[length]; /*0x1421bbec6*/
  *(_QWORD *)npub = *(_QWORD *)"UniqueNumber" /*0x1421bbeec*/
                  + _InterlockedExchangeAdd64((volatile signed __int64 *)&this->appNonce, 1u);
  *((_DWORD *)npub + 2) = *(_DWORD *)"mber"; /*0x1421bbef1*/
  return crypto_aead_chacha20poly1305_ietf_encrypt_detached( /*0x1421bbf47*/
           c: &buffer[aadSize],
           mac: npub + 12,
           maclen_p: &macLen,
           m: &ad[aadSize],
           mlen: length - aadSize,
           ad,
           adlen: aadSize,
           nsec: nullptr,
           npub,
           k) == 0
      && macLen == 16;
}

// Address: 0x1421bbf60 | Name: ?encryptData@SessionCrypto@Security@RBX@@QEBA?AV?$optional@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@std@@V?$ArrayView@E@3@@Z
std::optional<std::string > *__fastcall RBX::Security::SessionCrypto::encryptData(
        RBX::Security::SessionCrypto *this,
        std::optional<std::string > *result,
        RBX::ArrayView<unsigned char> *message)
{
  unsigned __int64 v6; // rsi
  std::optional<std::string > *p_box; // r10
  char *Ptr; // rcx
  unsigned __int64 Myres; // rdx
  __int64 v10; // r9
  const unsigned __int8 *k; // r9
  char *v12; // r8
  bool Has_value; // al
  char *v15; // rax
  unsigned __int8 *m[2]; // [rsp+60h] [rbp-19h]
  std::optional<std::string > box; // [rsp+90h] [rbp+17h] BYREF
  unsigned __int64 maclen_p; // [rsp+F8h] [rbp+7Fh] BYREF
  $398703F7114EBF6440C4EA32EC5760FD v19; // 0:^70.32

  v19._Value._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1421bbf8c*/
  v19._Value._Mypair._Myval2._Mysize = 0; /*0x1421bbf90*/
  v6 = 15; /*0x1421bbf94*/
  v19._Value._Mypair._Myval2._Myres = 15; /*0x1421bbf99*/
  box.___u0 = v19; /*0x1421bbfa1*/
  box._Has_value = true; /*0x1421bbfad*/
  __wind /*0xf1c0000000000010*/
  {
    std::string::resize(this: (std::string *)&box, _Newsize: message->length + 28, _Ch: 0); /*0x1421bbfc0*/
    p_box = &box; /*0x1421bbfc5*/
    Ptr = box._Value._Mypair._Myval2._Bx._Ptr; /*0x1421bbfc9*/
    Myres = box._Value._Mypair._Myval2._Myres; /*0x1421bbfcd*/
    if ( box._Value._Mypair._Myval2._Myres >= 0x10 ) /*0x1421bbfd5*/
      p_box = (std::optional<std::string > *)box._Value._Mypair._Myval2._Bx._Ptr; /*0x1421bbfd5*/
    *(RBX::ArrayView<unsigned char> *)m = *message; /*0x1421bbfdc*/
    if ( !this->isError && this->isSessionReady ) /*0x1421bbfea*/
    {
      v10 = 96; /*0x1421bbff9*/
      if ( !this->isServer ) /*0x1421bc003*/
        v10 = 64; /*0x1421bc003*/
      k = (const unsigned __int8 *)this + v10; /*0x1421bc007*/
      if ( (unsigned __int8 *)box._Value._Mypair._Myval2._Mysize == m[1] + 28 ) /*0x1421bc016*/
      {
        v12 = &p_box->_Value._Mypair._Myval2._Bx._Buf[(unsigned __int64)m[1]]; /*0x1421bc01c*/
        *(_QWORD *)v12 = _InterlockedExchangeAdd64((volatile signed __int64 *)&this->appNonce, 1u) /*0x1421bc046*/
                       + *(_QWORD *)"UniqueNumber";
        *((_DWORD *)v12 + 2) = *(_DWORD *)"mber"; /*0x1421bc04b*/
        if ( crypto_aead_chacha20poly1305_ietf_encrypt_detached( /*0x1421bc087*/
               c: (unsigned __int8 *)p_box,
               mac: (unsigned __int8 *)&p_box->_Value._Mypair._Myval2._Bx._Buf[(unsigned __int64)m[1] + 12],
               &maclen_p,
               m: m[0],
               mlen: (unsigned __int64)m[1],
               ad: nullptr,
               adlen: 0,
               nsec: nullptr,
               npub: (const unsigned __int8 *)&p_box->_Value._Mypair._Myval2._Bx._Buf[(unsigned __int64)m[1]],
               k) == 0 )
        {
          result->_Has_value = false; /*0x1421bc08d*/
          Has_value = box._Has_value; /*0x1421bc091*/
          if ( box._Has_value ) /*0x1421bc097*/
          {
            result->___u0 = box.___u0; /*0x1421bc09d*/
            box._Value._Mypair._Myval2._Mysize = 0; /*0x1421bc0a8*/
            box._Value._Mypair._Myval2._Myres = 15; /*0x1421bc0ac*/
            box._Value._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1421bc0b0*/
            result->_Has_value = true; /*0x1421bc0b4*/
          }
          else
          {
            v6 = box._Value._Mypair._Myval2._Myres; /*0x1421bc0ba*/
          }
          if ( !Has_value || v6 < 0x10 ) /*0x1421bc0c6*/
            return result; /*0x1421bc0c6*/
          Ptr = box._Value._Mypair._Myval2._Bx._Ptr; /*0x1421bc0cc*/
          if ( v6 + 1 < 0x1000 ) /*0x1421bc0da*/
            goto LABEL_17; /*0x1421bc0da*/
          Ptr = *((char **)box._Value._Mypair._Myval2._Bx._Ptr - 1); /*0x1421bc0e0*/
          if ( (unsigned __int64)(box._Value._Mypair._Myval2._Bx._Ptr - Ptr - 8) <= 0x1F ) /*0x1421bc0ef*/
            goto LABEL_17; /*0x1421bc0ef*/
          goto LABEL_24; /*0x1421bc0ef*/
        }
        Myres = box._Value._Mypair._Myval2._Myres; /*0x1421bc116*/
        Ptr = box._Value._Mypair._Myval2._Bx._Ptr; /*0x1421bc11a*/
      }
    }
    result->_Has_value = false; /*0x1421bc11e*/
    if ( !box._Has_value || Myres < 0x10 ) /*0x1421bc12c*/
      return result; /*0x1421bc12c*/
    v15 = Ptr; /*0x1421bc131*/
    if ( Myres + 1 < 0x1000 || (Ptr = *((char **)Ptr - 1), (unsigned __int64)(v15 - Ptr - 8) <= 0x1F) ) /*0x1421bc150*/
    {
LABEL_17:
      operator delete(ptr: Ptr); /*0x1421bc0f1*/
      return result; /*0xf1c000000000001c*/
    }
LABEL_24:
    _invalid_parameter_noinfo_noreturn(); /*0x1421bc152*/
  }
  __unwind
  {
    std::optional<std::string>::~optional<std::string>(this: (Luau::FunctionDefinition *)&box); /*0xf1c0000000000008*/
  }
}

// Address: 0x1421bc160 | Name: ?encryptRakDataInPlace@SessionCrypto@Security@RBX@@QEBA_NV?$MutableArrayView@E@3@@Z
bool __fastcall RBX::Security::SessionCrypto::encryptRakDataInPlace(
        RBX::Security::SessionCrypto *this,
        RBX::MutableArrayView<unsigned char> *messageToBox)
{
  unsigned __int64 length; // r9
  unsigned __int64 v4; // r9
  bool isServer; // cl
  const unsigned __int8 *buffer; // r11
  unsigned __int8 *v7; // r8
  int (__fastcall *v8)(unsigned __int8 *, unsigned __int8 *, unsigned __int64 *, const unsigned __int8 *, unsigned __int64, const unsigned __int8 *, unsigned __int64, const unsigned __int8 *, const unsigned __int8 *, const unsigned __int8 *); // r10
  __int64 v9; // rax
  unsigned __int64 macLen; // [rsp+68h] [rbp+10h] BYREF

  length = messageToBox->length; /*0x1421bc166*/
  if ( length < 0x12 || this->isError || !this->isSessionReady ) /*0x1421bc185*/
    return false; /*0x1421bc224*/
  v4 = length - 18; /*0x1421bc193*/
  isServer = this->isServer; /*0x1421bc197*/
  buffer = messageToBox->buffer; /*0x1421bc19b*/
  v7 = (unsigned __int8 *)&messageToBox->buffer[v4]; /*0x1421bc19e*/
  qmemcpy(v7, "UniqueNumbeR", 12); /*0x1421bc1a2*/
  *(_QWORD *)v7 = _InterlockedExchangeAdd64((volatile signed __int64 *)&this->txRakNonce, 1u); /*0x1421bc1bc*/
  v8 = crypto_aead_chacha20poly1305_ietf_encrypt_detached; /*0x1421bc1bf*/
  if ( (this->rakFormat & 2) != 0 ) /*0x1421bc1d6*/
    v8 = crypto_aead_aes256gcm_encrypt_detached; /*0x1421bc1d6*/
  v9 = 96; /*0x1421bc1dc*/
  if ( !isServer ) /*0x1421bc1e4*/
    v9 = 64; /*0x1421bc1e4*/
  return v8( /*0x1421bc21e*/
           c: (unsigned __int8 *)buffer,
           mac: v7 + 2,
           maclen_p: &macLen,
           m: buffer,
           mlen: v4,
           ad: nullptr,
           adlen: 0,
           nsec: nullptr,
           npub: v7,
           k: (const unsigned __int8 *)this + v9) == 0;
}

// Address: 0x1421bc230 | Name: ?encryptString@SessionCrypto@Security@RBX@@QEBA?AV?$optional@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@std@@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@5@@Z
std::optional<std::string > *__fastcall RBX::Security::SessionCrypto::encryptString(
        RBX::Security::SessionCrypto *this,
        std::optional<std::string > *result,
        const std::string *message)
{
  unsigned __int64 Mysize; // rax
  RBX::ArrayView<unsigned char> v6; // [rsp+20h] [rbp-18h] BYREF

  Mysize = message->_Mypair._Myval2._Mysize; /*0x1421bc23e*/
  if ( message->_Mypair._Myval2._Myres >= 0x10 ) /*0x1421bc242*/
    message = (const std::string *)message->_Mypair._Myval2._Bx._Ptr; /*0x1421bc244*/
  v6.buffer = (const unsigned __int8 *)message; /*0x1421bc247*/
  v6.length = Mysize; /*0x1421bc251*/
  RBX::Security::SessionCrypto::encryptData(this, result, message: &v6); /*0x1421bc256*/
  return result; /*0x1421bc25e*/
}

// Address: 0x1421bc270 | Name: ?getEnabledForRaknet@SessionCrypto@Security@RBX@@QEBA_NXZ
RBX::Security::SessionCrypto::CryptoFormat __fastcall RBX::Security::SessionCrypto::getEnabledForRaknet(
        RBX::Security::SessionCrypto *this)
{
  RBX::Security::SessionCrypto::CryptoFormat result; // al

  result = this->rakFormat; /*0x1421bc270*/
  if ( result != NoCrypto ) /*0x1421bc276*/
    return (unsigned __int8)~result >> 7; /*0x1421bc27b*/
  return result; /*0x1421bc278*/
}

// Address: 0x1421bc280 | Name: ?getRakCryptoFormat@SessionCrypto@Security@RBX@@IEBA?AW4CryptoFormat@123@XZ
__int64 __fastcall RBX::Security::SessionCrypto::getRakCryptoFormat(RBX::Security::SessionCrypto *this)
{
  return (unsigned __int8)this->rakFormat; /*0x1421bc284*/
}

// Address: 0x1421bc290 | Name: ?getSupportAes@SessionCrypto@Security@RBX@@IEBA_NXZ
bool __fastcall RBX::Security::SessionCrypto::getSupportAes(RBX::Security::SessionCrypto *this)
{
  int is_available; // eax

  if ( DFFlag::ScNoAes.value || (is_available = crypto_aead_aes256gcm_is_available()) != 1 ) /*0x1421bc2a5*/
    LOBYTE(is_available) = 0; /*0x1421bc2ac*/
  return is_available; /*0x1421bc2a7*/
}

// Address: 0x1421bc2c0 | Name: ?initCommon@SessionCrypto@Security@RBX@@IEAA_NXZ
bool __fastcall RBX::Security::SessionCrypto::initCommon(RBX::Security::SessionCrypto *this)
{
  std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys> *p_keyExchangeKeys; // rdi
  RBX::Security::SessionCrypto::KeyExchangeKeys *v2; // rax
  RBX::Security::SessionCrypto::KeyExchangeKeys *v3; // rbx

  *(_WORD *)&this->isEarlySessionReady = 0; /*0x1421bc2ca*/
  p_keyExchangeKeys = &this->keyExchangeKeys; /*0x1421bc2d0*/
  this->isError = false; /*0x1421bc2d4*/
  v2 = (RBX::Security::SessionCrypto::KeyExchangeKeys *)operator new(size: 0xE0u); /*0x1421bc2dd*/
  v3 = v2; /*0x1421bc2e7*/
  if ( v2 != nullptr ) /*0x1421bc2ed*/
  {
    sodium_memzero(ptr: v2, len: 0x20u); /*0x1421bc2f7*/
    sodium_memzero(ptr: &v3->secretEphemeralKey, len: 0x20u); /*0x1421bc305*/
    sodium_memzero(ptr: &v3->publicEarlyKey, len: 0x20u); /*0x1421bc313*/
    sodium_memzero(ptr: &v3->secretEarlyKey, len: 0x20u); /*0x1421bc321*/
    sodium_memzero(ptr: &v3->earlySessionKeyClientToServer, len: 0x20u); /*0x1421bc332*/
    sodium_memzero(ptr: &v3->earlySessionKeyServerToClient, len: 0x20u); /*0x1421bc343*/
  }
  else
  {
    v3 = nullptr; /*0x1421bc34a*/
  }
  std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>::reset(this: p_keyExchangeKeys, _Ptr: v3); /*0x1421bc352*/
  return crypto_kx_keypair( /*0x1421bc36d*/
           pk: p_keyExchangeKeys->_Mypair._Myval2->publicEphemeralKey._Elems,
           sk: p_keyExchangeKeys->_Mypair._Myval2->secretEphemeralKey._Elems) == 0;
}

// Address: 0x1421bc380 | Name: ?isAesGcm@SessionCrypto@Security@RBX@@SA_NW4CryptoFormat@123@@Z
_BOOL8 __fastcall RBX::Security::SessionCrypto::isAesGcm(RBX::Security::SessionCrypto::CryptoFormat format)
{
  return (format & 2) != 0; /*0x1421bc388*/
}

// Address: 0x1421bc390 | Name: ?isKeyExchangeComplete@SessionCrypto@Security@RBX@@QEBA_NXZ
bool __fastcall RBX::Security::SessionCrypto::isKeyExchangeComplete(RBX::Security::SessionCrypto *this)
{
  return !this->isError && this->isSessionReady; /*0x1421bc39e*/
}

// Address: 0x1421bc3b0 | Name: ?isTestOnly@SessionCrypto@Security@RBX@@SA_NW4CryptoFormat@123@@Z
__int64 __fastcall RBX::Security::SessionCrypto::isTestOnly(unsigned __int8 format)
{
  return format >> 7; /*0x1421bc3b6*/
}

// Address: 0x1421bc480 | Name: ?resetKeyExchangeKeys@SessionCrypto@Security@RBX@@QEAAX_N@Z
void __fastcall RBX::Security::SessionCrypto::resetKeyExchangeKeys(RBX::Security::SessionCrypto *this, bool error)
{
  std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>::reset(this: &this->keyExchangeKeys, _Ptr: nullptr); /*0x1421bc496*/
  this->isEarlySessionReady = false; /*0x1421bc49b*/
  if ( error ) /*0x1421bc4a1*/
    *(_WORD *)&this->isSessionReady = 256; /*0x1421bc4a3*/
}

// Address: 0x1421bc4c0 | Name: ?setRakCryptoFormat@SessionCrypto@Security@RBX@@IEAAXW4CryptoFormat@123@@Z
void __fastcall RBX::Security::SessionCrypto::setRakCryptoFormat(
        RBX::Security::SessionCrypto *this,
        RBX::Security::SessionCrypto::CryptoFormat value)
{
  this->rakFormat = value; /*0x1421bc4c0*/
}

// Address: 0x1421bc4d0 | Name: ?verifyPreauthMac@SessionCrypto@Security@RBX@@SA?AU?$pair@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@_N@std@@VStringView@3@0@Z
// local variable allocation has failed, the output may be wrong!
std::pair<std::string,bool> *__fastcall RBX::Security::SessionCrypto::verifyPreauthMac(
        std::pair<std::string,bool> *result,
        RBX::StringView *msg,
        RBX::StringView *preauthBlob)
{
  bool v5; // bl
  char v6; // r13
  _QWORD *v7; // rax
  __int64 i; // r8
  unsigned __int64 v9; // rsi
  unsigned __int64 v10; // rcx
  unsigned __int64 v11; // rdx
  unsigned __int64 Length; // r9
  _QWORD *v13; // r8
  const char *Data; // r10
  char v15; // al
  unsigned __int64 v16; // rcx
  unsigned int v17; // r9d
  char *Ptr; // rcx
  unsigned __int8 *Mylast; // rcx
  std::string *v20; // rbx
  char *v21; // rax
  char *v22; // rdi
  std::_String_val<std::_Simple_types<char> >::_Bxty Bx; // xmm7
  __int128 v24; // xmm6
  char *v25; // rcx
  char *v26; // rcx
  unsigned __int8 *v27; // rax
  unsigned __int64 v28; // r12
  _BYTE *v29; // r15
  unsigned __int8 *Instance; // rcx
  char *v31; // rax
  std::pair<std::string,bool> *v32; // rax
  _WORD name[4]; // [rsp+28h] [rbp-E0h]
  std::_String_val<std::_Simple_types<char> >::_Bxty name_8; // [rsp+30h] [rbp-D8h] BYREF
  _BYTE name_24[48]; // [rsp+40h] [rbp-C8h] OVERLAPPED BYREF
  std::vector<unsigned char> key; // [rsp+70h] [rbp-98h] BYREF
  __int64 v37; // [rsp+88h] [rbp-80h]
  _BYTE v38[48]; // [rsp+98h] [rbp-70h] OVERLAPPED BYREF
  RBX::StringView v39; // [rsp+C8h] [rbp-40h] BYREF
  RBX::StringView v40; // [rsp+D8h] [rbp-30h] BYREF
  std::string v41; // [rsp+E8h] [rbp-20h] BYREF
  char v43; // [rsp+180h] [rbp+78h]

  v5 = true; /*0x1421bc4ff*/
  v43 = 1; /*0x1421bc501*/
  v6 = 0; /*0x1421bc504*/
  name[0] = 0; /*0x1421bc509*/
  *(_OWORD *)&v38[32] = 0; /*0x1421bc511*/
  v7 = &v38[16]; /*0x1421bc516*/
  for ( i = 2; i != 0; --i ) /*0x1421bc51a*/
  {
    *v7 = 0; /*0x1421bc520*/
    v7[1] = 0; /*0x1421bc523*/
    v7 += 2; /*0x1421bc527*/
  }
  *(_QWORD *)&name_24[16] = 0; /*0x1421bc531*/
  *(_QWORD *)&name_24[32] = 0; /*0x1421bc536*/
  v9 = 15; /*0x1421bc53b*/
  *(_QWORD *)&name_24[40] = 15; /*0x1421bc540*/
  if ( DFFlag::ForceNewPaBlob2.value || preauthBlob->Length > 0x20 ) /*0x1421bc558*/
  {
    v10 = 16; /*0x1421bc574*/
    v11 = 0; /*0x1421bc579*/
    Length = preauthBlob->Length; /*0x1421bc57c*/
    v13 = &v38[16]; /*0x1421bc580*/
    do /*0x1421bc5ce*/
    {
      if ( Length == v10 ) /*0x1421bc58e*/
        break; /*0x1421bc58e*/
      Data = preauthBlob->Data; /*0x1421bc590*/
      v15 = preauthBlob->Data[v10]; /*0x1421bc593*/
      v16 = v10 + 1; /*0x1421bc598*/
      *((_BYTE *)name + v11) = v15; /*0x1421bc59b*/
      if ( Length - v16 < 0x10 ) /*0x1421bc5a9*/
        break; /*0x1421bc5a9*/
      *v13 = &Data[v16]; /*0x1421bc5af*/
      v13[1] = 16; /*0x1421bc5b2*/
      v10 = v16 + 16; /*0x1421bc5ba*/
      if ( v10 >= Length ) /*0x1421bc5c1*/
        break; /*0x1421bc5c1*/
      ++v11; /*0x1421bc5c3*/
      v13 += 2; /*0x1421bc5c6*/
    }
    while ( v11 < 2 ); /*0x1421bc5ce*/
  }
  else
  {
    LOBYTE(name[0]) = 6; /*0x1421bc55a*/
    *(_QWORD *)&v38[16] = preauthBlob->Data + 16; /*0x1421bc566*/
    *(_QWORD *)&v38[24] = 16; /*0x1421bc56a*/
  }
  __wind /*0xf1c0000000000050*/
  {
    Instance = (unsigned __int8 *)RBX::Security::KeyRing::getInstance(); /*0x1421bc5d5*/
    key._Mypair._Myval2._Myfirst = Instance; /*0x1421bc5d8*/
    v28 = 0; /*0x1421bc5dd*/
    v29 = &v38[16]; /*0x1421bc5e0*/
    v24 = *(_OWORD *)&name_24[32]; /*0x1421bc5e4*/
    v22 = *(char **)&name_24[16]; /*0x1421bc5e9*/
    Bx = *(std::_String_val<std::_Simple_types<char> >::_Bxty *)&name_24[16]; /*0x1421bc5ee*/
    while ( 1 ) /*0x1421bc5f3*/
    {
      if ( v6 != 0 ) /*0x1421bc5f6*/
        goto LABEL_53; /*0x1421bc5f6*/
      __wind /*0xf1c0000000000024*/
      {
        v17 = *((unsigned __int8 *)name + v28); /*0x1421bc5fc*/
        *(_QWORD *)&name_24[8] = 15; /*0x1421bc602*/
        *(_QWORD *)name_24 = 10; /*0x1421bc60b*/
        strcpy(name_8._Buf, "PreAuthKey"); /*0x1421bc61c*/
        RBX::Security::KeyRing::getKeyForConsumption( /*0x1421bc63d*/
          this: (RBX::Security::KeyRing *)Instance,
          result: (std::vector<unsigned char> *)&key._Mypair._Myval2._Mylast,
          name: (const std::string *)&name_8,
          id: v17);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&name_8); /*0xf1c0000000000034*/
      }
      __eh34_enter_wind_state(0, 3); /*0xf1c000000000003c*/
      if ( *(_QWORD *)&name_24[8] >= 0x10u ) /*0x1421bc64c*/
      {
        Ptr = name_8._Ptr; /*0x1421bc651*/
        if ( (unsigned __int64)(*(_QWORD *)&name_24[8] + 1LL) >= 0x1000 ) /*0x1421bc660*/
        {
          Ptr = *((char **)name_8._Ptr - 1); /*0x1421bc666*/
          if ( (unsigned __int64)(name_8._Ptr - Ptr - 8) > 0x1F ) /*0x1421bc675*/
            _invalid_parameter_noinfo_noreturn(); /*0x1421bc819*/
        }
        operator delete(ptr: Ptr); /*0x1421bc67b*/
      }
      *(_QWORD *)name_24 = 0; /*0x1421bc680*/
      *(_QWORD *)&name_24[8] = 15; /*0x1421bc689*/
      name_8._Buf[0] = 0; /*0x1421bc692*/
      Mylast = key._Mypair._Myval2._Mylast; /*0x1421bc697*/
      if ( key._Mypair._Myval2._Mylast == key._Mypair._Myval2._Myend || *(_QWORD *)v29 == 0 ) /*0x1421bc6ae*/
      {
        v5 = false; /*0x1421bc7cb*/
        v43 = 0; /*0x1421bc7cd*/
      }
      else
      {
        *(_QWORD *)v38 = key._Mypair._Myval2._Mylast; /*0x1421bc6b7*/
        *(_QWORD *)&v38[8] = key._Mypair._Myval2._Myend - key._Mypair._Myval2._Mylast; /*0x1421bc6bb*/
        v39 = *(RBX::StringView *)v38; /*0x1421bc6c3*/
        v40 = *msg; /*0x1421bc6cf*/
        v20 = RBX::Crypto::computeKeyedBlake2b(result: &v41, data: &v40, secret: &v39, digestSize: 16); /*0x1421bc6ea*/
        if ( &name_24[16] != (_BYTE *)v20 ) /*0x1421bc6f5*/
        {
          if ( v9 >= 0x10 ) /*0x1421bc6fb*/
          {
            v21 = v22; /*0x1421bc701*/
            if ( v9 + 1 >= 0x1000 ) /*0x1421bc70b*/
            {
              v22 = *((char **)v22 - 1); /*0x1421bc711*/
              if ( (unsigned __int64)(v21 - v22 - 8) > 0x1F ) /*0x1421bc720*/
LABEL_45:
                _invalid_parameter_noinfo_noreturn(); /*0x1421bc820*/
            }
            operator delete(ptr: v22); /*0x1421bc729*/
          }
          Bx = v20->_Mypair._Myval2._Bx; /*0x1421bc72e*/
          *(std::_String_val<std::_Simple_types<char> >::_Bxty *)&name_24[16] = v20->_Mypair._Myval2._Bx; /*0x1421bc731*/
          v24 = *(_OWORD *)&v20->_Mypair._Myval2._Mysize; /*0x1421bc736*/
          *(_OWORD *)&name_24[32] = v24; /*0x1421bc73a*/
          v20->_Mypair._Myval2._Mysize = 0; /*0x1421bc741*/
          v20->_Mypair._Myval2._Myres = 15; /*0x1421bc745*/
          v20->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x1421bc74d*/
          v9 = *(_QWORD *)&name_24[40]; /*0x1421bc74f*/
          v22 = *(char **)&name_24[16]; /*0x1421bc754*/
        }
        if ( v41._Mypair._Myval2._Myres >= 0x10 ) /*0x1421bc761*/
        {
          v25 = v41._Mypair._Myval2._Bx._Ptr; /*0x1421bc766*/
          if ( v41._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1421bc774*/
          {
            v25 = *((char **)v41._Mypair._Myval2._Bx._Ptr - 1); /*0x1421bc77a*/
            if ( (unsigned __int64)(v41._Mypair._Myval2._Bx._Ptr - v25 - 8) > 0x1F ) /*0x1421bc789*/
              goto LABEL_45; /*0x1421bc789*/
          }
          operator delete(ptr: v25); /*0x1421bc78f*/
        }
        v26 = &name_24[16]; /*0x1421bc794*/
        if ( v9 >= 0x10 ) /*0x1421bc79d*/
          v26 = v22; /*0x1421bc79d*/
        if ( *(_QWORD *)v26 == **(_QWORD **)v29 && *((_QWORD *)v26 + 1) == *(_QWORD *)(*(_QWORD *)v29 + 8LL) ) /*0x1421bc7b4*/
        {
          v6 = 1; /*0x1421bc7b6*/
          v5 = v43; /*0x1421bc7b9*/
        }
        else
        {
          v5 = false; /*0x1421bc7bf*/
          v43 = 0; /*0x1421bc7c1*/
        }
        Mylast = key._Mypair._Myval2._Mylast; /*0x1421bc7c4*/
      }
      if ( Mylast != nullptr ) /*0x1421bc7d3*/
      {
        v27 = Mylast; /*0x1421bc7e3*/
        if ( (unsigned __int64)(v37 - (_QWORD)Mylast) >= 0x1000 ) /*0x1421bc7e6*/
        {
          Mylast = *((unsigned __int8 **)Mylast - 1); /*0x1421bc7e8*/
          if ( (unsigned __int64)(v27 - Mylast - 8) > 0x1F ) /*0x1421bc7fb*/
            _invalid_parameter_noinfo_noreturn(); /*0x1421bc827*/
        }
        operator delete(ptr: Mylast); /*0x1421bc7fd*/
      }
      ++v28; /*0x1421bc802*/
      v29 += 16; /*0x1421bc805*/
      if ( v28 >= 2 ) /*0x1421bc80d*/
        break; /*0x1421bc80d*/
      Instance = key._Mypair._Myval2._Myfirst; /*0x1421bc80f*/
      if ( __eh34_unwind(3) ) /*0xf1c0000000000044*/
        goto unwind_state_3; /*0xf1c0000000000044*/
      __eh34_exit_wind_state(3, 0); /*0xf1c0000000000048*/
    }
    if ( __eh34_unwind(3) ) /*0xf1c0000000000010*/
    {
unwind_state_3:
      RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&key._Mypair._Myval2._Mylast); /*0xf1c0000000000014*/
      __eh34_continue_unwinding(3, 0); /*0xf1c0000000000018*/
    }
    __eh34_exit_wind_state(3, 0); /*0xf1c000000000001c*/
    if ( v6 != 0 ) /*0x1421bc831*/
    {
LABEL_53:
      result->first._Mypair._Myval2._Bx = Bx; /*0x1421bc8bc*/
      *(_OWORD *)&result->first._Mypair._Myval2._Mysize = v24; /*0x1421bc8c0*/
      result->second = v5; /*0x1421bc8c5*/
      goto LABEL_54; /*0x1421bc8c5*/
    }
    name_8._Ptr = nullptr; /*0x1421bc837*/
    *(_QWORD *)name_24 = 0; /*0x1421bc840*/
    *(_QWORD *)&name_24[8] = 15; /*0x1421bc849*/
    result->first._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1421bc852*/
    result->first._Mypair._Myval2._Mysize = 0; /*0x1421bc859*/
    result->first._Mypair._Myval2._Myres = 0; /*0x1421bc861*/
    result->first._Mypair._Myval2._Bx = name_8; /*0x1421bc86e*/
    *(_OWORD *)&result->first._Mypair._Myval2._Mysize = *(_OWORD *)name_24; /*0x1421bc877*/
    result->second = false; /*0x1421bc87c*/
    if ( v9 >= 0x10 ) /*0x1421bc884*/
    {
      v31 = v22; /*0x1421bc88a*/
      if ( v9 + 1 >= 0x1000 ) /*0x1421bc894*/
      {
        v22 = *((char **)v22 - 1); /*0x1421bc89a*/
        if ( (unsigned __int64)(v31 - v22 - 8) > 0x1F ) /*0x1421bc8a9*/
          _invalid_parameter_noinfo_noreturn(); /*0x1421bc8ab*/
      }
      operator delete(ptr: v22); /*0x1421bc8b5*/
    }
LABEL_54:
    v32 = result; /*0x1421bc8c9*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&name_24[16]); /*0xf1c0000000000008*/
  }
  return v32; /*0x1421bc8cc*/
}

// END SessionCrypto part 1/1, 20 functions
