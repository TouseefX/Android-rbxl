// RakPeerCrypto -- 2022 Studio + full PDB
// tier 3, 11 functions


// Address: 0x1410a6210 | Name: ?clientInitEphemeralSessionKeys@RakPeerCrypto@Security@RBX@@AEAA_NV?$ArrayView@E@3@@Z
char __fastcall RBX::Security::RakPeerCrypto::clientInitEphemeralSessionKeys(
        RBX::Security::RakPeerCrypto *this,
        RBX::ArrayView<unsigned char> *peerPublicKey)
{
  RBX::Security::SessionCrypto::KeyExchangeKeys *Myval2; // r8

  if ( this->isError ) /*0x1410a6216*/
    return 0; /*0x1410a6220*/
  if ( peerPublicKey->length != 32 ) /*0x1410a6227*/
    return 0; /*0x1410a6227*/
  if ( this->isServer ) /*0x1410a6229*/
    return 0; /*0x1410a622d*/
  Myval2 = this->keyExchangeKeys._Mypair._Myval2; /*0x1410a622f*/
  if ( Myval2 == nullptr ) /*0x1410a6236*/
    return 0; /*0x1410a6236*/
  if ( crypto_kx_client_session_keys( /*0x1410a6253*/
         rx: this->sessionKeyServerToClient._Elems,
         tx: this->sessionKeyClientToServer._Elems,
         client_pk: Myval2->publicEphemeralKey._Elems,
         client_sk: Myval2->secretEphemeralKey._Elems,
         server_pk: peerPublicKey->buffer) != 0 )
  {
    RBX::Security::SessionCrypto::resetKeyExchangeKeys(this, error: true); /*0x1410a625a*/
    return 0; /*0x1410a6266*/
  }
  this->isSessionReady = true; /*0x1410a6267*/
  return 1; /*0x1410a6261*/
}

// Address: 0x1410a6280 | Name: ?earlyDecryptData@RakPeerCrypto@Security@RBX@@AEBA_NAEAVBitStream@RakNet@@_K@Z
char __fastcall RBX::Security::RakPeerCrypto::earlyDecryptData(
        RBX::Security::RakPeerCrypto *this,
        RakNet::BitStream *bitstream,
        unsigned __int64 aadSize)
{
  unsigned __int64 v6; // rdi
  const unsigned __int8 *v7; // rax
  RBX::ArrayView<unsigned char> box; // [rsp+20h] [rbp-28h] BYREF
  RBX::MutableArrayView<unsigned char> message; // [rsp+30h] [rbp-18h] BYREF

  v6 = bitstream->GetNumberOfBytesUsed(this: bitstream); /*0x1410a62ac*/
  if ( v6 < aadSize + 28 ) /*0x1410a62b5*/
    return 0; /*0x1410a62b5*/
  RakNet::BitStream::AssertCopyData(this: bitstream); /*0x1410a62be*/
  v7 = bitstream->GetData(this: bitstream); /*0x1410a62c9*/
  message.length = v6 - 28; /*0x1410a62cf*/
  message.buffer = v7; /*0x1410a62d4*/
  box.buffer = bitstream->GetData(this: bitstream); /*0x1410a62e9*/
  box.length = v6; /*0x1410a62f3*/
  if ( !RBX::Security::SessionCrypto::earlyDecryptData(this, &message, &box, aadSize) ) /*0x1410a630f*/
    return 0; /*0x1410a632e*/
  RakNet::BitStream::SetWriteOffset(this: bitstream, offset: 8 * (v6 - 28), eraseDataToCurrentOffset: false); /*0x1410a6325*/
  return 1; /*0x1410a6330*/
}

// Address: 0x1410a6350 | Name: ?earlyEncryptData@RakPeerCrypto@Security@RBX@@AEBA_NAEAVBitStream@RakNet@@_KG@Z
bool __fastcall RBX::Security::RakPeerCrypto::earlyEncryptData(
        RBX::Security::RakPeerCrypto *this,
        RakNet::BitStream *bitstream,
        unsigned __int64 aadSize,
        unsigned __int16 ruppLength)
{
  __int64 v5; // rbp
  unsigned __int64 v8; // rdi
  unsigned __int8 *v9; // rax
  RBX::ArrayView<unsigned char> v11; // [rsp+20h] [rbp-38h] BYREF
  RBX::MutableArrayView<unsigned char> v12; // [rsp+30h] [rbp-28h] BYREF

  v5 = ruppLength; /*0x1410a6377*/
  v8 = bitstream->GetNumberOfBytesUsed(this: bitstream) - ruppLength; /*0x1410a6389*/
  RakNet::BitStream::AssertCopyData(this: bitstream); /*0x1410a638f*/
  RakNet::BitStream::PadWithZeroToByteLength(this: bitstream, bytes: v8 + 28 + v5); /*0x1410a639a*/
  v9 = bitstream->GetData(this: bitstream); /*0x1410a63a5*/
  v11.length = v8; /*0x1410a63ab*/
  v12.length = v8 + 28; /*0x1410a63b5*/
  v11.buffer = &v9[v5]; /*0x1410a63c1*/
  v12.buffer = &v9[v5]; /*0x1410a63c6*/
  return RBX::Security::SessionCrypto::earlyEncryptData(this, box: &v12, message: &v11, aadSize); /*0x1410a63d5*/
}

// Address: 0x1410a6400 | Name: ?getClientKeyInfo@RakPeerCrypto@Security@RBX@@CA?AUKeyInfo@KeyRing@23@_N@Z
RBX::Security::KeyRing::KeyInfo *__fastcall RBX::Security::RakPeerCrypto::getClientKeyInfo(
        RBX::Security::KeyRing::KeyInfo *result,
        bool useRccKey)
{
  RBX::Security::KeyRing *Instance; // rax
  RBX::Security::KeyRing::KeyInfo *KeyForProduction; // rbx
  bool allowed; // al
  unsigned __int8 *Myfirst; // rcx
  RBX::Security::KeyRing::KeyInfo *v7; // rax
  RBX::Security::KeyRing::KeyInfo v8; // [rsp+40h] [rbp-38h] BYREF

  __wind /*0xf1c000000000001c*/
  {
    result->value._Mypair._Myval2._Myfirst = nullptr; /*0x1410a6426*/
    result->value._Mypair._Myval2._Mylast = nullptr; /*0x1410a6429*/
    result->value._Mypair._Myval2._Myend = nullptr; /*0x1410a642d*/
    result->id = 0; /*0x1410a6431*/
    result->allowed = false; /*0x1410a6434*/
    if ( !useRccKey ) /*0x1410a6441*/
      goto LABEL_9; /*0x1410a6441*/
    Instance = RBX::Security::KeyRing::getInstance(); /*0x1410a6443*/
    KeyForProduction = RBX::Security::KeyRing::getKeyForProduction( /*0x1410a645c*/
                         this: Instance,
                         result: &v8,
                         name: &RBX::Security::kRakNetEarlyPublicKeyName);
    std::vector<char>::operator=(this: &result->value, _Right: &KeyForProduction->value); /*0x1410a6465*/
    result->id = KeyForProduction->id; /*0x1410a646d*/
    allowed = KeyForProduction->allowed; /*0x1410a6470*/
    result->allowed = allowed; /*0x1410a6474*/
    Myfirst = v8.value._Mypair._Myval2._Myfirst; /*0x1410a6477*/
    if ( v8.value._Mypair._Myval2._Myfirst != nullptr ) /*0x1410a647f*/
    {
      if ( (unsigned __int8 *)(v8.value._Mypair._Myval2._Myend - v8.value._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x1410a6493*/
      {
        Myfirst = *((unsigned __int8 **)v8.value._Mypair._Myval2._Myfirst - 1); /*0x1410a6499*/
        if ( (unsigned __int64)(v8.value._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x1410a64a8*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410a64aa*/
      }
      operator delete(ptr: Myfirst); /*0x1410a64b1*/
      allowed = result->allowed; /*0x1410a64b6*/
    }
    if ( !allowed ) /*0x1410a64bc*/
    {
LABEL_9:
      result->allowed = true; /*0x1410a64be*/
      std::vector<unsigned char>::resize(this: &result->value, _Newsize: 0x20u); /*0x1410a64ca*/
      *(std::array<unsigned char,32> *)result->value._Mypair._Myval2._Myfirst = RBX::Security::RakPeerCrypto::kPublicEarlyTestKey; /*0x1410a64d9*/
    }
    v7 = result; /*0x1410a64e7*/
  }
  __unwind
  {
    RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)result); /*0x1431ec39e*/
  }
  return v7; /*0x1410a64ea*/
}

// Address: 0x1410a6500 | Name: ?getPublicKey@RakPeerCrypto@Security@RBX@@AEBA?AV?$ArrayView@E@3@XZ
RBX::ArrayView<unsigned char> *__fastcall RBX::Security::RakPeerCrypto::getPublicKey(
        RBX::Security::RakPeerCrypto *this,
        RBX::ArrayView<unsigned char> *result)
{
  RBX::Security::SessionCrypto::KeyExchangeKeys *Myval2; // rax

  if ( this->isError || (Myval2 = this->keyExchangeKeys._Mypair._Myval2) == nullptr ) /*0x1410a650d*/
  {
    result->length = 0; /*0x1410a6520*/
    result->buffer = nullptr; /*0x1410a6524*/
    return result; /*0x1410a6527*/
  }
  else
  {
    result->buffer = (const unsigned __int8 *)Myval2; /*0x1410a650f*/
    result->length = 32; /*0x1410a6515*/
    return result; /*0x1410a6512*/
  }
}

// Address: 0x1410a6530 | Name: ?getServerKeyInfo@RakPeerCrypto@Security@RBX@@CA?AU?$pair@V?$vector@EV?$allocator@E@std@@@std@@V12@@std@@I@Z
std::pair<std::vector<unsigned char>,std::vector<unsigned char> > *__fastcall RBX::Security::RakPeerCrypto::getServerKeyInfo(
        std::pair<std::vector<unsigned char>,std::vector<unsigned char> > *result,
        unsigned int version)
{
  RBX::Security::KeyRing *Instance; // r14
  std::vector<unsigned char> *KeyForConsumption; // rbx
  unsigned __int8 *Myfirst; // rcx
  unsigned __int8 *v7; // rcx
  std::vector<unsigned char> *v8; // rbx
  unsigned __int8 *v9; // rcx
  unsigned __int8 *v10; // rcx
  std::array<unsigned char,32> *v11; // rcx
  std::vector<unsigned char> secretKey; // [rsp+20h] [rbp-50h] BYREF
  std::vector<unsigned char> publicKey; // [rsp+38h] [rbp-38h] BYREF
  std::vector<unsigned char> v15; // [rsp+50h] [rbp-20h] BYREF
  std::_Value_init_tag _Val; // [rsp+98h] [rbp+28h] BYREF

  __wind /*0xf1c000000000001c*/
  {
    __wind /*0xf1c0000000000024*/
    {
      memset(&publicKey, 0, sizeof(publicKey)); /*0x1410a6553*/
      memset(&secretKey, 0, sizeof(secretKey)); /*0x1410a655f*/
      if ( version != 0 ) /*0x1410a656a*/
      {
        Instance = RBX::Security::KeyRing::getInstance(); /*0x1410a6575*/
        KeyForConsumption = RBX::Security::KeyRing::getKeyForConsumption( /*0x1410a658e*/
                              this: Instance,
                              result: &v15,
                              name: &RBX::Security::kRakNetEarlyPublicKeyName,
                              id: version);
        if ( &publicKey != KeyForConsumption ) /*0x1410a6598*/
        {
          Myfirst = publicKey._Mypair._Myval2._Myfirst; /*0x1410a659a*/
          if ( publicKey._Mypair._Myval2._Myfirst != nullptr ) /*0x1410a65a1*/
          {
            if ( (unsigned __int8 *)(publicKey._Mypair._Myval2._Myend - publicKey._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x1410a65b4*/
            {
              Myfirst = *((unsigned __int8 **)publicKey._Mypair._Myval2._Myfirst - 1); /*0x1410a65ba*/
              if ( (unsigned __int64)(publicKey._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x1410a65c9*/
LABEL_12:
                _invalid_parameter_noinfo_noreturn(); /*0x1410a662f*/
            }
            operator delete(ptr: Myfirst); /*0x1410a65cb*/
            memset(&publicKey, 0, sizeof(publicKey)); /*0x1410a65d3*/
          }
          publicKey = *KeyForConsumption; /*0x1410a65df*/
          KeyForConsumption->_Mypair._Myval2._Myfirst = nullptr; /*0x1410a65f3*/
          KeyForConsumption->_Mypair._Myval2._Mylast = nullptr; /*0x1410a65f6*/
          KeyForConsumption->_Mypair._Myval2._Myend = nullptr; /*0x1410a65fa*/
        }
        v7 = v15._Mypair._Myval2._Myfirst; /*0x1410a65fe*/
        if ( v15._Mypair._Myval2._Myfirst != nullptr ) /*0x1410a6605*/
        {
          if ( (unsigned __int8 *)(v15._Mypair._Myval2._Myend - v15._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x1410a6618*/
          {
            v7 = *((unsigned __int8 **)v15._Mypair._Myval2._Myfirst - 1); /*0x1410a661e*/
            if ( (unsigned __int64)(v15._Mypair._Myval2._Myfirst - v7 - 8) > 0x1F ) /*0x1410a662d*/
              goto LABEL_12; /*0x1410a662d*/
          }
          operator delete(ptr: v7); /*0x1410a6636*/
        }
        v8 = RBX::Security::KeyRing::getKeyForConsumption( /*0x1410a6651*/
               this: Instance,
               result: &v15,
               name: &RBX::Security::kRakNetEarlySecretKeyName,
               id: version);
        if ( &secretKey != v8 ) /*0x1410a665b*/
        {
          v9 = secretKey._Mypair._Myval2._Myfirst; /*0x1410a665d*/
          if ( secretKey._Mypair._Myval2._Myfirst != nullptr ) /*0x1410a6664*/
          {
            if ( (unsigned __int8 *)(secretKey._Mypair._Myval2._Myend - secretKey._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x1410a6677*/
            {
              v9 = *((unsigned __int8 **)secretKey._Mypair._Myval2._Myfirst - 1); /*0x1410a667d*/
              if ( (unsigned __int64)(secretKey._Mypair._Myval2._Myfirst - v9 - 8) > 0x1F ) /*0x1410a668c*/
LABEL_23:
                _invalid_parameter_noinfo_noreturn(); /*0x1410a66f6*/
            }
            operator delete(ptr: v9); /*0x1410a668e*/
            memset(&secretKey, 0, sizeof(secretKey)); /*0x1410a6696*/
          }
          secretKey = *v8; /*0x1410a66a2*/
          v8->_Mypair._Myval2._Myfirst = nullptr; /*0x1410a66b6*/
          v8->_Mypair._Myval2._Mylast = nullptr; /*0x1410a66b9*/
          v8->_Mypair._Myval2._Myend = nullptr; /*0x1410a66bd*/
        }
        v10 = v15._Mypair._Myval2._Myfirst; /*0x1410a66c1*/
        if ( v15._Mypair._Myval2._Myfirst != nullptr ) /*0x1410a66c8*/
        {
          if ( (unsigned __int8 *)(v15._Mypair._Myval2._Myend - v15._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x1410a66df*/
          {
            v10 = *((unsigned __int8 **)v15._Mypair._Myval2._Myfirst - 1); /*0x1410a66e5*/
            if ( (unsigned __int64)(v15._Mypair._Myval2._Myfirst - v10 - 8) > 0x1F ) /*0x1410a66f4*/
              goto LABEL_23; /*0x1410a66f4*/
          }
          operator delete(ptr: v10); /*0x1410a66fd*/
        }
      }
      else
      {
        std::vector<unsigned char>::_Resize_reallocate<std::_Value_init_tag>( /*0x1410a6716*/
          this: (std::vector<signed char> *)&publicKey,
          _Newsize: 0x20u,
          &_Val);
        *(std::array<unsigned char,32> *)publicKey._Mypair._Myval2._Myfirst = RBX::Security::RakPeerCrypto::kPublicEarlyTestKey; /*0x1410a6726*/
        v11 = (std::array<unsigned char,32> *)secretKey._Mypair._Myval2._Myfirst; /*0x1410a673b*/
        if ( (unsigned __int8 *)(secretKey._Mypair._Myval2._Mylast - secretKey._Mypair._Myval2._Myfirst) <= (unsigned __int8 *)0x20 ) /*0x1410a6745*/
        {
          if ( (unsigned __int8 *)(secretKey._Mypair._Myval2._Mylast - secretKey._Mypair._Myval2._Myfirst) < (unsigned __int8 *)0x20 ) /*0x1410a6751*/
          {
            if ( (unsigned __int8 *)(secretKey._Mypair._Myval2._Myend - secretKey._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x20 ) /*0x1410a675d*/
            {
              memset_0( /*0x1410a6780*/
                a1: secretKey._Mypair._Myval2._Mylast,
                Val: 0,
                Size: 32 - (secretKey._Mypair._Myval2._Mylast - secretKey._Mypair._Myval2._Myfirst));
              secretKey._Mypair._Myval2._Mylast = secretKey._Mypair._Myval2._Myfirst + 32; /*0x1410a6785*/
            }
            else
            {
              std::vector<unsigned char>::_Resize_reallocate<std::_Value_init_tag>( /*0x1410a676a*/
                this: (std::vector<signed char> *)&secretKey,
                _Newsize: 0x20u,
                &_Val);
            }
            v11 = (std::array<unsigned char,32> *)secretKey._Mypair._Myval2._Myfirst; /*0x1410a6789*/
          }
        }
        else
        {
          secretKey._Mypair._Myval2._Mylast = secretKey._Mypair._Myval2._Myfirst + 32; /*0x1410a674b*/
        }
        *v11 = RBX::Security::RakPeerCrypto::kSecretEarlyTestKey; /*0x1410a6794*/
      }
      result->first = publicKey; /*0x1410a67a6*/
      result->second = secretKey; /*0x1410a67bd*/
    }
    __unwind
    {
      RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&secretKey); /*0xf1c0000000000008*/
    }
  }
  __unwind
  {
    RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&publicKey); /*0xf1c0000000000014*/
  }
  return result; /*0x1410a67d4*/
}

// Address: 0x1410a67f0 | Name: ?initClient@RakPeerCrypto@Security@RBX@@AEAA_NV?$ArrayView@E@3@@Z
char __fastcall RBX::Security::RakPeerCrypto::initClient(
        RBX::Security::RakPeerCrypto *this,
        RBX::ArrayView<unsigned char> *publicEarlyKey)
{
  RBX::Security::SessionCrypto::KeyExchangeKeys *Myval2; // rax
  unsigned __int8 *server_pk; // [rsp+20h] [rbp-18h]

  this->isServer = false; /*0x1410a67fd*/
  if ( RBX::Security::SessionCrypto::initCommon(this) /*0x1410a684e*/
    && publicEarlyKey->length == 32
    && (Myval2 = this->keyExchangeKeys._Mypair._Myval2,
        server_pk = (unsigned __int8 *)publicEarlyKey->buffer,
        *(_OWORD *)Myval2->publicEarlyKey._Elems = *(_OWORD *)publicEarlyKey->buffer,
        *(_OWORD *)&Myval2->publicEarlyKey._Elems[16] = *((_OWORD *)server_pk + 1),
        crypto_kx_client_session_keys(
          rx: this->keyExchangeKeys._Mypair._Myval2->earlySessionKeyServerToClient._Elems,
          tx: this->keyExchangeKeys._Mypair._Myval2->earlySessionKeyClientToServer._Elems,
          client_pk: this->keyExchangeKeys._Mypair._Myval2->publicEphemeralKey._Elems,
          client_sk: this->keyExchangeKeys._Mypair._Myval2->secretEphemeralKey._Elems,
          server_pk) == 0) )
  {
    this->isEarlySessionReady = true; /*0x1410a6850*/
    return 1; /*0x1410a6854*/
  }
  else
  {
    RBX::Security::SessionCrypto::resetKeyExchangeKeys(this, error: true); /*0x1410a6866*/
    return 0; /*0x1410a6870*/
  }
}

// Address: 0x1410a6880 | Name: ?initServer@RakPeerCrypto@Security@RBX@@AEAA_NV?$ArrayView@E@3@0@Z
char __fastcall RBX::Security::RakPeerCrypto::initServer(
        RBX::Security::RakPeerCrypto *this,
        RBX::ArrayView<unsigned char> *publicEarlyKey,
        RBX::ArrayView<unsigned char> *secretEarlyKey)
{
  RBX::Security::SessionCrypto::KeyExchangeKeys *Myval2; // rcx
  const unsigned __int8 *buffer; // rax
  __int128 v8; // xmm1
  const unsigned __int8 *v9; // rax
  RBX::Security::SessionCrypto::KeyExchangeKeys *v10; // rcx
  __int128 v11; // xmm1

  this->isServer = true; /*0x1410a6892*/
  if ( RBX::Security::SessionCrypto::initCommon(this) && publicEarlyKey->length == 32 && secretEarlyKey->length == 32 ) /*0x1410a68b1*/
  {
    Myval2 = this->keyExchangeKeys._Mypair._Myval2; /*0x1410a68b3*/
    buffer = publicEarlyKey->buffer; /*0x1410a68b7*/
    *(_OWORD *)Myval2->publicEarlyKey._Elems = *(_OWORD *)publicEarlyKey->buffer; /*0x1410a68bd*/
    v8 = *((_OWORD *)buffer + 1); /*0x1410a68c1*/
    v9 = secretEarlyKey->buffer; /*0x1410a68c5*/
    *(_OWORD *)&Myval2->publicEarlyKey._Elems[16] = v8; /*0x1410a68c8*/
    v10 = this->keyExchangeKeys._Mypair._Myval2; /*0x1410a68cc*/
    *(_OWORD *)v10->secretEarlyKey._Elems = *(_OWORD *)v9; /*0x1410a68d3*/
    v11 = *((_OWORD *)v9 + 1); /*0x1410a68d7*/
    *(_OWORD *)&v10->secretEarlyKey._Elems[16] = v11; /*0x1410a68dd*/
    return 1; /*0x1410a68db*/
  }
  else
  {
    RBX::Security::SessionCrypto::resetKeyExchangeKeys(this, error: true); /*0x1410a68f6*/
    return 0; /*0x1410a6900*/
  }
}

// Address: 0x1410a6910 | Name: ?serverInitEarlySessionKeys@RakPeerCrypto@Security@RBX@@AEAA_NV?$ArrayView@E@3@@Z
char __fastcall RBX::Security::RakPeerCrypto::serverInitEarlySessionKeys(
        RBX::Security::RakPeerCrypto *this,
        RBX::ArrayView<unsigned char> *peerPublicKey)
{
  RBX::Security::SessionCrypto::KeyExchangeKeys *Myval2; // rcx
  const unsigned __int8 *buffer; // rdi
  RBX::Security::SessionCrypto::KeyExchangeKeys *v6; // rax

  if ( this->isError ) /*0x1410a6916*/
    return 0; /*0x1410a691d*/
  if ( peerPublicKey->length != 32 ) /*0x1410a6928*/
    return 0; /*0x1410a6928*/
  if ( !this->isServer ) /*0x1410a692e*/
    return 0; /*0x1410a692e*/
  Myval2 = this->keyExchangeKeys._Mypair._Myval2; /*0x1410a6930*/
  if ( Myval2 == nullptr ) /*0x1410a6937*/
    return 0; /*0x1410a69a3*/
  buffer = peerPublicKey->buffer; /*0x1410a6942*/
  if ( crypto_kx_server_session_keys( /*0x1410a6960*/
         rx: Myval2->earlySessionKeyClientToServer._Elems,
         tx: Myval2->earlySessionKeyServerToClient._Elems,
         server_pk: Myval2->publicEarlyKey._Elems,
         server_sk: Myval2->secretEarlyKey._Elems,
         client_pk: peerPublicKey->buffer) != 0 )
  {
    RBX::Security::SessionCrypto::resetKeyExchangeKeys(this, error: true); /*0x1410a6967*/
    return 0; /*0x1410a6971*/
  }
  else
  {
    v6 = this->keyExchangeKeys._Mypair._Myval2; /*0x1410a6979*/
    this->isEarlySessionReady = true; /*0x1410a697d*/
    *(_OWORD *)v6->peerPublicEphemeralKey._Elems = *(_OWORD *)buffer; /*0x1410a6984*/
    *(_OWORD *)&v6->peerPublicEphemeralKey._Elems[16] = *((_OWORD *)buffer + 1); /*0x1410a6994*/
    return 1; /*0x1410a699b*/
  }
}

// Address: 0x1410a69b0 | Name: ?serverInitEphemeralSessionKeys@RakPeerCrypto@Security@RBX@@AEAA_NXZ
char __fastcall RBX::Security::RakPeerCrypto::serverInitEphemeralSessionKeys(RBX::Security::RakPeerCrypto *this)
{
  RBX::Security::SessionCrypto::KeyExchangeKeys *Myval2; // r8

  if ( this->isError ) /*0x1410a69b6*/
    return 0; /*0x1410a69bd*/
  Myval2 = this->keyExchangeKeys._Mypair._Myval2; /*0x1410a69bf*/
  if ( Myval2 == nullptr || !this->isServer ) /*0x1410a69cc*/
    return 0; /*0x1410a69cc*/
  if ( crypto_kx_server_session_keys( /*0x1410a69ed*/
         rx: this->sessionKeyClientToServer._Elems,
         tx: this->sessionKeyServerToClient._Elems,
         server_pk: Myval2->publicEphemeralKey._Elems,
         server_sk: Myval2->secretEphemeralKey._Elems,
         client_pk: Myval2->peerPublicEphemeralKey._Elems) != 0 )
  {
    RBX::Security::SessionCrypto::resetKeyExchangeKeys(this, error: true); /*0x1410a69f4*/
    return 0; /*0x1410a6a00*/
  }
  this->isSessionReady = true; /*0x1410a6a01*/
  return 1; /*0x1410a69fb*/
}

// Address: 0x1410b71b0 | Name: ??$reset@VRakPeerCrypto@Security@RBX@@@?$shared_ptr@VRakPeerCrypto@Security@RBX@@@std@@QEAAXPEAVRakPeerCrypto@Security@RBX@@@Z
void __fastcall std::shared_ptr<RBX::Security::RakPeerCrypto>::reset<RBX::Security::RakPeerCrypto>(
        std::shared_ptr<RBX::Security::RakPeerCrypto> *this,
        std::_Ref_count_base_vtbl *_Px)
{
  std::_Ref_count_base *v4; // rax
  std::_Ref_count_base *Rep; // rbx

  v4 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x1410b71ca*/
  if ( v4 != nullptr ) /*0x1410b71d7*/
  {
    *v4 = 0; /*0x1410b71dc*/
    v4->_Uses = 1; /*0x1410b71df*/
    v4->_Weaks = 1; /*0x1410b71e6*/
    v4->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Security::RakPeerCrypto>::`vftable'; /*0x1410b71f4*/
    v4[1].__vftable = _Px; /*0x1410b71f7*/
  }
  this->_Ptr = (RBX::Security::RakPeerCrypto *)_Px; /*0x1410b71fb*/
  Rep = this->_Rep; /*0x1410b71fe*/
  this->_Rep = v4; /*0x1410b7202*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b721a*/
  {
    Rep->_Destroy(this: Rep); /*0x1410b7222*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b722c*/
      Rep->_Delete_this(this: Rep); /*0x1410b7234*/
  }
}

// END RakPeerCrypto part 1/1, 11 functions
