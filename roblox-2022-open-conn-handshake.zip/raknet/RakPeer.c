// RakPeer -- 2022 Studio + full PDB
// tier 3, 171 functions


// Address: 0x1408b7fa0 | Name: ?setServerReceiveRupp@RakPeer@RakNet@@MEAAX_N@Z
void __fastcall RakNet::RakPeer::setServerReceiveRupp(RakNet::RakPeer *this, bool value)
{
  this->serverReceiveRupp = value; /*0x1408b7fa0*/
}

// Address: 0x1410b7680 | Name: ??0RakPeer@RakNet@@QEAA@XZ
RakNet::RakPeer *__fastcall RakNet::RakPeer::RakPeer(RakNet::RakPeer *this)
{
  RakNet::SystemAddress *p_rccBoundAddress; // rcx
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *>,void *> *v3; // rax
  RakNet::SimpleMutex *p_requestedConnectionQueueMutex; // rcx
  DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct> *p_bufferedPackets; // rbx
  RakNet::SimpleMutex *p_memoryPoolMutex; // rcx
  RakNet::RakPeer::RecvSpecQueue *p_artificialDelayBufferedPackets; // rbx
  RakNet::SimpleMutex *v8; // rcx
  RakNet::RakPeer::DelayTransmitQueue *p_artificialDelayTransmitPackets; // rbx
  RakNet::SimpleMutex *v10; // rcx
  DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput> *p_socketQueryOutput; // rbx
  RakNet::SimpleMutex *v12; // rcx
  RakNet::SimpleMutex *p_securityExceptionMutex; // rcx
  std::vector<int> *p_mtuSizeList; // r15
  RakNet::SystemAddress *v15; // rbx
  __int64 i; // rbp
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *v17; // rax
  std::queue<RakNet::RakPeer::DeferredQueueInfo> *v18; // rbx
  std::queue<RakNet::RakPeer::DeferredQueueInfo> **v19; // rax
  std::_Tree_node<std::string,void *> *v20; // rax
  int *Myfirst; // rbx
  RakNet::SystemAddress *ipList; // rsi
  __int64 v23; // r14
  int v24; // r8d
  void **v25; // r9
  _BYTE v27[32]; // [rsp+0h] [rbp-78h] BYREF
  void (__fastcall *destructor)(void *); // [rsp+20h] [rbp-58h]
  _DWORD Src[18]; // [rsp+30h] [rbp-48h] BYREF
  RakNet::RakPeer::RecvSpecQueue *v31; // [rsp+88h] [rbp+10h]
  RakNet::RakPeer::DelayTransmitQueue *v32; // [rsp+88h] [rbp+10h]
  DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput> *v33; // [rsp+88h] [rbp+10h]
  std::queue<RakNet::RakPeer::DeferredQueueInfo> *v34; // [rsp+88h] [rbp+10h]

  this->__vftable = (RakNet::RakPeer_vtbl *)RakNet::RakPeer::`vftable'; /*0x1410b76a3*/
  p_rccBoundAddress = &this->rccBoundAddress; /*0x1410b76a6*/
  __wind /*0xf1c00000000004b4*/
  {
    RakNet::SystemAddress::SystemAddress(this: p_rccBoundAddress); /*0x1410b76aa*/
    *(_WORD *)&this->serverReceiveRupp = 0; /*0x1410b76af*/
    *(_QWORD *)&this->bcsQueueTime = 0; /*0x1410b76b8*/
    *(_QWORD *)&this->bytesInQueueStats.maxBytesInReturnQueueSinglePeer = 0; /*0x1410b76bc*/
    *(_QWORD *)&this->bytesInQueueStats.maxBytesIncompleteDatagrams = 0; /*0x1410b76c0*/
    *(_QWORD *)&this->bytesInQueueStats.lastReportBytesInQueueStatsMS = 0; /*0x1410b76c4*/
    RakNet::LocklessUint32_t::LocklessUint32_t(this: &this->isRecvFromLoopThreadActive); /*0x1410b76cc*/
    RakNet::BitStream::BitStream(this: &this->offlinePingResponse); /*0x1410b76d5*/
    __wind /*0xf1c00000000004a8*/
    {
      this->activeSystemListSize._Storage._Value = 0; /*0x1410b76dd*/
      *(_QWORD *)&this->remoteSystemIndexPool.availablePagesSize = 0; /*0x1410b76e3*/
      this->remoteSystemIndexPool.memoryPoolPageSize = 0x4000; /*0x1410b76ea*/
      destructor = (void (__fastcall *)(void *))RakNet::SimpleMutex::~SimpleMutex; /*0x1410b7702*/
      __wind /*0xf1c000000000049c*/
      {
        `eh vector constructor iterator'( /*0x1410b7716*/
          ptr: this->rakPeerMutexes,
          size: 0x28u,
          count: 2u,
          constructor: (void (__fastcall *)(void *))RakNet::SimpleMutex::SimpleMutex,
          destructor);
        __wind /*0xf1c0000000000490*/
        {
          RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&this->incomingQueueMutex); /*0x1410b7723*/
          __wind /*0xf1c0000000000484*/
          {
            RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&this->banListMutex); /*0x1410b7730*/
            this->banMap._Traitsobj._Mypair._Myval2._Myval2 = 0.0; /*0x1410b7745*/
            this->banMap._List._Mypair._Myval2._Myhead = nullptr; /*0x1410b7748*/
            this->banMap._List._Mypair._Myval2._Mysize = 0; /*0x1410b774c*/
            __wind /*0xf1c0000000000478*/
            {
              v3 = (std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *>,void *> *)operator new(size: 0x38u); /*0x1410b7754*/
              v3->_Next = v3; /*0x1410b7759*/
              v3->_Prev = v3; /*0x1410b775c*/
              this->banMap._List._Mypair._Myval2._Myhead = v3; /*0x1410b7760*/
              this->banMap._Vec._Mypair._Myval2._Myfirst = nullptr; /*0x1410b7768*/
              this->banMap._Vec._Mypair._Myval2._Mylast = nullptr; /*0x1410b776b*/
              this->banMap._Vec._Mypair._Myval2._Myend = nullptr; /*0x1410b776f*/
              this->banMap._Mask = 7; /*0x1410b7773*/
              this->banMap._Maxidx = 8; /*0x1410b777b*/
              this->banMap._Traitsobj._Mypair._Myval2._Myval2 = 1.0; /*0x1410b7783*/
              __wind /*0xf1c00000000006dc*/
              {
                __wind /*0xf1c00000000006e4*/
                {
                  std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::shared_ptr<RBX::Graphics::Shader>>>>>>>::_Assign_grow( /*0x1410b7791*/
                    this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > > > > *)&this->banMap._Vec,
                    _Cells: 0x10u,
                    _Val: (const std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > >)this->banMap._List._Mypair._Myval2._Myhead);
                  *(_QWORD *)&this->requestedConnectionQueue.tail = 0; /*0x1410b7797*/
                  this->requestedConnectionQueue.array = nullptr; /*0x1410b779e*/
                  this->requestedConnectionQueue.head = 0; /*0x1410b77a5*/
                  p_requestedConnectionQueueMutex = &this->requestedConnectionQueueMutex; /*0x1410b77ac*/
                }
                __unwind
                {
                  std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&this->banMap._Vec); /*0x14316e31b*/
                }
              }
              __unwind
              {
                std::list<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BanStruct *>>::~list<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BanStruct *>>(this: (std::list<webrtc::ProcessThreadImpl::ModuleCallback> *)&this->banMap._List); /*0x1431ce58b*/
              }
              __wind /*0xf1c0000000000708*/
              {
                __wind /*0xf1c0000000000710*/
                {
                  RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)p_requestedConnectionQueueMutex); /*0x1410b77b3*/
                  *(_QWORD *)&this->bufferedCommands_deprecated.memoryPool.availablePagesSize = 0; /*0x1410b77c8*/
                  this->bufferedCommands_deprecated.memoryPool.memoryPoolPageSize = 0x4000; /*0x1410b77cc*/
                  __wind /*0xf1c00000000006c8*/
                  {
                    __wind /*0xf1c00000000006d0*/
                    {
                      RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&this->bufferedCommands_deprecated.memoryPoolMutex); /*0x1410b77d7*/
                      *(_QWORD *)&this->bufferedCommands_deprecated.queue.tail = 0; /*0x1410b77dd*/
                      this->bufferedCommands_deprecated.queue.array = nullptr; /*0x1410b77e1*/
                      this->bufferedCommands_deprecated.queue.head = 0; /*0x1410b77e5*/
                      __wind /*0xf1c0000000000634*/
                      {
                        __wind /*0xf1c000000000063c*/
                        {
                          RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&this->bufferedCommands_deprecated.queueMutex); /*0x1410b77ed*/
                          this->bufferedCommandsCircular.itemCapacity = 8; /*0x1410b77f3*/
                          this->bufferedCommandsCircular.read = 0; /*0x1410b77fe*/
                          this->bufferedCommandsCircular.itemCount = 0; /*0x1410b7805*/
                        }
                        __unwind
                        {
                          DataStructures::Queue<RakNet::RakPeer::SocketQueryOutput *>::~Queue<RakNet::RakPeer::SocketQueryOutput *>(this: (DataStructures::Queue<bool> *)&this->bufferedCommands_deprecated.queue); /*0x1431ecd1b*/
                        }
                      }
                      __unwind
                      {
                        RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->bufferedCommands_deprecated.memoryPoolMutex.criticalSection); /*0x1431ecd0b*/
                      }
                    }
                    __unwind
                    {
                      DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::~MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>(this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->bufferedCommands_deprecated); /*0xf1c0000000000664*/
                    }
                    __wind /*0xf1c000000000066c*/
                    {
                      __wind /*0xf1c0000000000674*/
                      {
                        this->bufferedCommandsCircular.buffer = (unsigned __int8 *)RBX::Memory::allocate(size: 0x500u); /*0x1410b7816*/
                        this->bufferedCommandsCircularSwap.itemCapacity = 8; /*0x1410b781d*/
                        this->bufferedCommandsCircularSwap.read = 0; /*0x1410b7828*/
                        this->bufferedCommandsCircularSwap.itemCount = 0; /*0x1410b782f*/
                      }
                      __unwind
                      {
                        __std_terminate(a1: 1280, a2: v27); /*0x142f39fa8*/
                      }
                      __wind /*0xf1c000000000068c*/
                      {
                        __wind /*0xf1c0000000000694*/
                        {
                          this->bufferedCommandsCircularSwap.buffer = (unsigned __int8 *)RBX::Memory::allocate(size: 0x500u); /*0x1410b7840*/
                          this->bufferedCommandsMutex.active_count = 0; /*0x1410b7847*/
                          this->bufferedCommandsMutex.event = nullptr; /*0x1410b784e*/
                          p_bufferedPackets = &this->bufferedPackets; /*0x1410b7855*/
                          *(_QWORD *)&this->bufferedPackets.memoryPool.availablePagesSize = 0; /*0x1410b7864*/
                          this->bufferedPackets.memoryPool.memoryPoolPageSize = 0x4000; /*0x1410b7868*/
                          p_memoryPoolMutex = &this->bufferedPackets.memoryPoolMutex; /*0x1410b786f*/
                        }
                        __unwind
                        {
                          __std_terminate(a1: p_memoryPoolMutex, a2: v27); /*0xf1c00000000001ec*/
                        }
                        __wind /*0xf1c00000000006ac*/
                        {
                          __wind /*0xf1c00000000006b4*/
                          {
                            __wind /*0xf1c00000000006bc*/
                            {
                              RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)p_memoryPoolMutex); /*0x1410b7873*/
                              *(_QWORD *)&p_bufferedPackets->queue.tail = 0; /*0x1410b7879*/
                              p_bufferedPackets->queue.array = nullptr; /*0x1410b787d*/
                              p_bufferedPackets->queue.head = 0; /*0x1410b7881*/
                              __wind /*0xf1c00000000005e8*/
                              {
                                __wind /*0xf1c00000000005f0*/
                                {
                                  RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&p_bufferedPackets->queueMutex); /*0x1410b7889*/
                                  p_artificialDelayBufferedPackets = &this->artificialDelayBufferedPackets; /*0x1410b788f*/
                                  v31 = &this->artificialDelayBufferedPackets; /*0x1410b7896*/
                                  *(_QWORD *)&this->artificialDelayBufferedPackets.memoryPool.availablePagesSize = 0; /*0x1410b789e*/
                                  this->artificialDelayBufferedPackets.memoryPool.memoryPoolPageSize = 0x4000; /*0x1410b78a2*/
                                  v8 = &this->artificialDelayBufferedPackets.memoryPoolMutex; /*0x1410b78a9*/
                                }
                                __unwind
                                {
                                  DataStructures::Queue<RakNet::RakPeer::SocketQueryOutput *>::~Queue<RakNet::RakPeer::SocketQueryOutput *>(this: (DataStructures::Queue<bool> *)&v31->queue); /*0xf1c0000000000210*/
                                }
                              }
                              __unwind
                              {
                                RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &v31->memoryPoolMutex.criticalSection); /*0xf1c00000000001fc*/
                              }
                            }
                            __unwind
                            {
                              DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::~MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>(this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)v31); /*0xf1c0000000000618*/
                            }
                            __wind /*0xf1c0000000000620*/
                            {
                              __wind /*0xf1c0000000000628*/
                              {
                                RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)v8); /*0x1410b78ad*/
                                *(_QWORD *)&p_artificialDelayBufferedPackets->queue.tail = 0; /*0x1410b78b3*/
                                p_artificialDelayBufferedPackets->queue.array = nullptr; /*0x1410b78b7*/
                                p_artificialDelayBufferedPackets->queue.head = 0; /*0x1410b78bb*/
                                __wind /*0xf1c000000000059c*/
                                {
                                  __wind /*0xf1c00000000005a4*/
                                  {
                                    RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&p_artificialDelayBufferedPackets->queueMutex); /*0x1410b78c3*/
                                    p_artificialDelayTransmitPackets = &this->artificialDelayTransmitPackets; /*0x1410b78c9*/
                                    v32 = &this->artificialDelayTransmitPackets; /*0x1410b78d0*/
                                    *(_QWORD *)&this->artificialDelayTransmitPackets.memoryPool.availablePagesSize = 0; /*0x1410b78d8*/
                                    this->artificialDelayTransmitPackets.memoryPool.memoryPoolPageSize = 0x4000; /*0x1410b78dc*/
                                    v10 = &this->artificialDelayTransmitPackets.memoryPoolMutex; /*0x1410b78e3*/
                                  }
                                  __unwind
                                  {
                                    DataStructures::Queue<RakNet::RakPeer::SocketQueryOutput *>::~Queue<RakNet::RakPeer::SocketQueryOutput *>(this: (DataStructures::Queue<bool> *)&v32->queue); /*0xf1c0000000000238*/
                                  }
                                }
                                __unwind
                                {
                                  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &v32->memoryPoolMutex.criticalSection); /*0xf1c0000000000224*/
                                }
                              }
                              __unwind
                              {
                                DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::~MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>(this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)v32); /*0xf1c00000000005cc*/
                              }
                              __wind /*0xf1c00000000005d4*/
                              {
                                __wind /*0xf1c00000000005dc*/
                                {
                                  RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)v10); /*0x1410b78e7*/
                                  *(_QWORD *)&p_artificialDelayTransmitPackets->queue.tail = 0; /*0x1410b78ed*/
                                  p_artificialDelayTransmitPackets->queue.array = nullptr; /*0x1410b78f1*/
                                  p_artificialDelayTransmitPackets->queue.head = 0; /*0x1410b78f5*/
                                  __wind /*0xf1c0000000000550*/
                                  {
                                    __wind /*0xf1c0000000000558*/
                                    {
                                      RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&p_artificialDelayTransmitPackets->queueMutex); /*0x1410b78fd*/
                                      this->latencyRx._Storage._Value = 0; /*0x1410b7903*/
                                      this->latencyTx._Storage._Value = 0; /*0x1410b790a*/
                                      p_socketQueryOutput = &this->socketQueryOutput; /*0x1410b7911*/
                                      v33 = &this->socketQueryOutput; /*0x1410b7918*/
                                      *(_QWORD *)&this->socketQueryOutput.memoryPool.availablePagesSize = 0; /*0x1410b7920*/
                                      this->socketQueryOutput.memoryPool.memoryPoolPageSize = 0x4000; /*0x1410b7924*/
                                      v12 = &this->socketQueryOutput.memoryPoolMutex; /*0x1410b792b*/
                                    }
                                    __unwind
                                    {
                                      DataStructures::Queue<RakNet::RakPeer::SocketQueryOutput *>::~Queue<RakNet::RakPeer::SocketQueryOutput *>(this: (DataStructures::Queue<bool> *)&v33->queue); /*0xf1c0000000000260*/
                                    }
                                  }
                                  __unwind
                                  {
                                    RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &v33->memoryPoolMutex.criticalSection); /*0xf1c000000000024c*/
                                  }
                                }
                                __unwind
                                {
                                  DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::~MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>(this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)v33); /*0xf1c0000000000580*/
                                }
                                __wind /*0xf1c0000000000588*/
                                {
                                  __wind /*0xf1c0000000000590*/
                                  {
                                    RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)v12); /*0x1410b792f*/
                                    *(_QWORD *)&p_socketQueryOutput->queue.tail = 0; /*0x1410b7935*/
                                    p_socketQueryOutput->queue.array = nullptr; /*0x1410b7939*/
                                    p_socketQueryOutput->queue.head = 0; /*0x1410b793d*/
                                    __wind /*0xf1c000000000050c*/
                                    {
                                      __wind /*0xf1c0000000000514*/
                                      {
                                        RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&p_socketQueryOutput->queueMutex); /*0x1410b7945*/
                                        p_securityExceptionMutex = &this->securityExceptionMutex; /*0x1410b794b*/
                                      }
                                      __unwind
                                      {
                                        DataStructures::Queue<RakNet::RakPeer::SocketQueryOutput *>::~Queue<RakNet::RakPeer::SocketQueryOutput *>(this: (DataStructures::Queue<bool> *)&v33->queue); /*0xf1c0000000000288*/
                                      }
                                    }
                                    __unwind
                                    {
                                      RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &v33->memoryPoolMutex.criticalSection); /*0xf1c0000000000274*/
                                    }
                                  }
                                  __unwind
                                  {
                                    DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::~MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>(this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)v33); /*0xf1c000000000053c*/
                                  }
                                  __wind /*0xf1c0000000000544*/
                                  {
                                    RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)p_securityExceptionMutex); /*0x1410b7952*/
                                    p_mtuSizeList = &this->mtuSizeList; /*0x1410b7958*/
                                    this->mtuSizeList._Mypair._Myval2._Myfirst = nullptr; /*0x1410b795f*/
                                    this->mtuSizeList._Mypair._Myval2._Mylast = nullptr; /*0x1410b7962*/
                                    this->mtuSizeList._Mypair._Myval2._Myend = nullptr; /*0x1410b7966*/
                                    *(_QWORD *)&this->socketList.list_size = 0; /*0x1410b796a*/
                                    this->socketList.listArray = nullptr; /*0x1410b7971*/
                                    __wind /*0xf1c00000000007cc*/
                                    {
                                      __wind /*0xf1c00000000007d4*/
                                      {
                                        __wind /*0xf1c00000000007dc*/
                                        {
                                          RakNet::SystemAddress::SystemAddress(this: &this->replyFromTargetPlayer); /*0x1410b797f*/
                                          RakNet::RakNetGUID::RakNetGUID(this: &this->myGuid); /*0x1410b798b*/
                                          RakNet::SystemAddress::SystemAddress(this: &this->firstExternalID); /*0x1410b7997*/
                                          *(_QWORD *)&this->securityExceptionList.list_size = 0; /*0x1410b799c*/
                                          this->securityExceptionList.listArray = nullptr; /*0x1410b79a3*/
                                          __wind /*0xf1c000000000046c*/
                                          {
                                            ipList = this->ipList; /*0x1410b79aa*/
                                            v15 = this->ipList; /*0x1410b79b1*/
                                            v23 = 10; /*0x1410b79b4*/
                                            for ( i = 10; i != 0; --i ) /*0x1410b79ba*/
                                              RakNet::SystemAddress::SystemAddress(this: v15++); /*0x1410b79c3*/
                                            RBX::CEvent::CEvent(this: &this->recvFromLoopEnded, manualReset: true); /*0x1410b79db*/
                                            __wind /*0xf1c0000000000460*/
                                            {
                                              RBX::CEvent::CEvent( /*0x1410b79ea*/
                                                this: &this->updateNetworkLoopEnded,
                                                manualReset: true);
                                              __wind /*0xf1c0000000000454*/
                                              {
                                                RakNet::SignaledEvent::SignaledEvent(this: &this->quitAndDataEvents); /*0x1410b79f7*/
                                                __wind /*0xf1c0000000000448*/
                                                {
                                                  RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&this->packetAllocationPoolMutex); /*0x1410b7a04*/
                                                  __wind /*0xf1c000000000043c*/
                                                  {
                                                    *(_QWORD *)&this->packetAllocationPool.availablePagesSize = 0; /*0x1410b7a0a*/
                                                    this->packetAllocationPool.memoryPoolPageSize = 0x4000; /*0x1410b7a11*/
                                                    __wind /*0xf1c0000000000430*/
                                                    {
                                                      RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&this->packetReturnMutex); /*0x1410b7a22*/
                                                      *(_QWORD *)&this->packetReturnQueue.tail = 0; /*0x1410b7a28*/
                                                      this->packetReturnQueue.array = nullptr; /*0x1410b7a2f*/
                                                      this->packetReturnQueue.head = 0; /*0x1410b7a36*/
                                                      this->bytesInReturnQueue._Traitsobj._Mypair._Myval2._Myval2 = 0.0; /*0x1410b7a4c*/
                                                      this->bytesInReturnQueue._List._Mypair._Myval2._Myhead = nullptr; /*0x1410b7a4f*/
                                                      this->bytesInReturnQueue._List._Mypair._Myval2._Mysize = 0; /*0x1410b7a53*/
                                                      __wind /*0xf1c00000000004f8*/
                                                      {
                                                        __wind /*0xf1c0000000000500*/
                                                        {
                                                          v17 = (std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *)operator new(size: 0x38u); /*0x1410b7a5a*/
                                                          v17->_Next = v17; /*0x1410b7a5f*/
                                                          v17->_Prev = v17; /*0x1410b7a62*/
                                                          this->bytesInReturnQueue._List._Mypair._Myval2._Myhead = v17; /*0x1410b7a66*/
                                                          this->bytesInReturnQueue._Vec._Mypair._Myval2._Myfirst = nullptr; /*0x1410b7a6e*/
                                                          this->bytesInReturnQueue._Vec._Mypair._Myval2._Mylast = nullptr; /*0x1410b7a71*/
                                                          this->bytesInReturnQueue._Vec._Mypair._Myval2._Myend = nullptr; /*0x1410b7a75*/
                                                          this->bytesInReturnQueue._Mask = 7; /*0x1410b7a79*/
                                                          this->bytesInReturnQueue._Maxidx = 8; /*0x1410b7a81*/
                                                          this->bytesInReturnQueue._Traitsobj._Mypair._Myval2._Myval2 = 1.0; /*0x1410b7a89*/
                                                          __wind /*0xf1c00000000004c0*/
                                                          {
                                                            __wind /*0xf1c00000000004c8*/
                                                            {
                                                              std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::shared_ptr<RBX::Graphics::Shader>>>>>>>::_Assign_grow( /*0x1410b7a96*/
                                                                this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > > > > *)&this->bytesInReturnQueue._Vec,
                                                                _Cells: 0x10u,
                                                                _Val: (const std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > >)this->bytesInReturnQueue._List._Mypair._Myval2._Myhead);
                                                              v18 = &this->deferredJoinAndDisconnectTickets_deprecated; /*0x1410b7a9c*/
                                                              v34 = &this->deferredJoinAndDisconnectTickets_deprecated; /*0x1410b7aa3*/
                                                              this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myproxy = nullptr; /*0x1410b7aab*/
                                                              this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Map = nullptr; /*0x1410b7aae*/
                                                              this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mapsize = 0; /*0x1410b7ab2*/
                                                              this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff = 0; /*0x1410b7ab6*/
                                                              this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize = 0; /*0x1410b7aba*/
                                                            }
                                                            __unwind
                                                            {
                                                              std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&v34->c._Mypair._Myval2._Myoff); /*0xf1c00000000002b0*/
                                                            }
                                                          }
                                                          __unwind
                                                          {
                                                            std::list<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BanStruct *>>::~list<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BanStruct *>>(this: (std::list<webrtc::ProcessThreadImpl::ModuleCallback> *)&v34->c._Mypair._Myval2._Map); /*0xf1c000000000029c*/
                                                          }
                                                          __wind /*0xf1c00000000004ec*/
                                                          {
                                                            v19 = (std::queue<RakNet::RakPeer::DeferredQueueInfo> **)operator new(size: 0x10u); /*0x1410b7ac1*/
                                                            v19[1] = nullptr; /*0x1410b7ac6*/
                                                            v18->c._Mypair._Myval2._Myproxy = (std::_Container_proxy *)v19; /*0x1410b7aca*/
                                                            *v19 = v18; /*0x1410b7acd*/
                                                            __wind /*0xf1c00000000002bc*/
                                                            {
                                                              RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&this->sendReceiptSerialMutex); /*0x1410b7ad7*/
                                                              this->jobId._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410b7adf*/
                                                              this->jobId._Mypair._Myval2._Mysize = 0; /*0x1410b7ae6*/
                                                              this->jobId._Mypair._Myval2._Myres = 15; /*0x1410b7aed*/
                                                              this->jobId._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410b7af8*/
                                                              this->preauthKey._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410b7afe*/
                                                              this->preauthKey._Mypair._Myval2._Mysize = 0; /*0x1410b7b05*/
                                                              this->preauthKey._Mypair._Myval2._Myres = 15; /*0x1410b7b0c*/
                                                              this->preauthKey._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410b7b17*/
                                                              this->usedMacs._Mypair._Myval2._Myval2._Myhead = nullptr; /*0x1410b7b2c*/
                                                              this->usedMacs._Mypair._Myval2._Myval2._Mysize = 0; /*0x1410b7b2f*/
                                                              __wind /*0xf1c00000000007b0*/
                                                              {
                                                                __wind /*0xf1c00000000007b8*/
                                                                {
                                                                  __wind /*0xf1c00000000007c0*/
                                                                  {
                                                                    v20 = (std::_Tree_node<std::string,void *> *)operator new(size: 0x40u); /*0x1410b7b36*/
                                                                    v20->_Left = v20; /*0x1410b7b3b*/
                                                                    v20->_Parent = v20; /*0x1410b7b3e*/
                                                                    v20->_Right = v20; /*0x1410b7b42*/
                                                                    *(_WORD *)&v20->_Color = 257; /*0x1410b7b46*/
                                                                    this->usedMacs._Mypair._Myval2._Myval2._Myhead = v20; /*0x1410b7b4c*/
                                                                    this->runUpdateCycleStats.lastCycleStart.sec = 0.0; /*0x1410b7b51*/
                                                                    this->runUpdateCycleStats.cycleStartToAfterBufferedHandling.sec = 0.0; /*0x1410b7b58*/
                                                                    this->runUpdateCycleStats.cycleStartToAfterRequestConnection.sec = 0.0; /*0x1410b7b5f*/
                                                                    this->runUpdateCycleStats.cycleStartToAfterDisconnectChecks.sec = 0.0; /*0x1410b7b66*/
                                                                    this->runUpdateCycleStats.cycleStartToAfterPingInternal.sec = 0.0; /*0x1410b7b6d*/
                                                                    this->runUpdateCycleStats.cycleStartToAfterReliableReceive.sec = 0.0; /*0x1410b7b74*/
                                                                    this->runUpdateCycleStats.cycleStartToReturn.sec = 0.0; /*0x1410b7b7b*/
                                                                    this->runUpdateCycleStats.trackedStatsLastCycle = false; /*0x1410b7b82*/
                                                                    this->earlyAuthData._Ptr = nullptr; /*0x1410b7b88*/
                                                                    this->earlyAuthData._Rep = nullptr; /*0x1410b7b8f*/
                                                                    this->testSendHook._Mystorage._Ptrs[7] = nullptr; /*0x1410b7b96*/
                                                                    this->testDeserializeHook._Mystorage._Ptrs[7] = nullptr; /*0x1410b7b9d*/
                                                                    *(_OWORD *)this->connectionRequestsStats.counters = 0; /*0x1410b7bb6*/
                                                                    *(_OWORD *)&this->connectionRequestsStats.counters[4] = 0; /*0x1410b7bb9*/
                                                                    __wind /*0xf1c00000000007e8*/
                                                                    {
                                                                      __wind /*0xf1c00000000007f0*/
                                                                      {
                                                                        __wind /*0xf1c00000000007f8*/
                                                                        {
                                                                          __wind /*0xf1c0000000000800*/
                                                                          {
                                                                            RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&this->connectionRequestsStats.mx); /*0x1410b7bc1*/
                                                                            this->ruppHeader._Ptr = nullptr; /*0x1410b7bc7*/
                                                                            this->ruppHeader._Rep = nullptr; /*0x1410b7bce*/
                                                                            this->ruppTokenProcessor._Mypair._Myval2 = nullptr; /*0x1410b7bd5*/
                                                                            __wind /*0xf1c000000000071c*/
                                                                            {
                                                                              __wind /*0xf1c0000000000724*/
                                                                              {
                                                                                __wind /*0xf1c000000000072c*/
                                                                                {
                                                                                  RakNet::SimpleMutex::SimpleMutex(this: (rtc::CriticalSection *)&this->rakNetStatisticsMutex); /*0x1410b7be3*/
                                                                                  this->downloadBandwidthTracker._Ptr = nullptr; /*0x1410b7be9*/
                                                                                  this->downloadBandwidthTracker._Rep = nullptr; /*0x1410b7bf0*/
                                                                                  this->trackDroppedPackets.droppedPktQueue.m_buff = nullptr; /*0x1410b7bf7*/
                                                                                  this->trackDroppedPackets.droppedPktQueue.m_end = nullptr; /*0x1410b7bfe*/
                                                                                  this->trackDroppedPackets.droppedPktQueue.m_first = nullptr; /*0x1410b7c05*/
                                                                                  this->trackDroppedPackets.droppedPktQueue.m_last = nullptr; /*0x1410b7c0c*/
                                                                                  this->trackDroppedPackets.droppedPktQueue.m_size = 0; /*0x1410b7c13*/
                                                                                  this->trackDroppedPackets.timeDroppedPktStatsLastChecked = 0; /*0x1410b7c1a*/
                                                                                  *(_QWORD *)&this->trackDroppedPackets.numOfPktsDroppedForTheReportingWindow = 0; /*0x1410b7c21*/
                                                                                  this->trackDroppedPackets.invalidPortPktDrop._Storage._Value = 0; /*0x1410b7c28*/
                                                                                  *(_QWORD *)&this->totalPacketsPerPeerOneCycle = 0; /*0x1410b7c2e*/
                                                                                  this->minPacketsPerPeerOneCycle = 0x7FFFFFFF; /*0x1410b7c35*/
                                                                                  this->maxPacketsPerPeerOneCycle = 0x80000000; /*0x1410b7c3f*/
                                                                                  *(_QWORD *)&this->bcStats.totalCommandsPerCycle = 0; /*0x1410b7c49*/
                                                                                  this->bcStats.minCommandsPerCycle = 0x7FFFFFFF; /*0x1410b7c50*/
                                                                                  this->bcStats.maxCommandsPerCycle = 0x80000000; /*0x1410b7c5a*/
                                                                                  this->bcStats.lastReportCommandsPerCycle = 0; /*0x1410b7c64*/
                                                                                  this->artificialLatencyStats.txQueueExcessDelay = 0; /*0x1410b7c6a*/
                                                                                  this->artificialLatencyStats.txDelayedPackets = 0; /*0x1410b7c71*/
                                                                                  this->artificialLatencyStats.rxQueueExcessDelay = 0; /*0x1410b7c77*/
                                                                                  this->artificialLatencyStats.rxDelayedPackets = 0; /*0x1410b7c7e*/
                                                                                  this->artificialLatencyStats.rxQueueMaxDelay = 0; /*0x1410b7c84*/
                                                                                  this->artificialLatencyStats.txQueueMaxDelay = 0; /*0x1410b7c8b*/
                                                                                  *(_QWORD *)&this->artificialLatencyStats.peakTxQueueSize = 0; /*0x1410b7c92*/
                                                                                  this->artificialLatencyStats.lastReportTime = 0; /*0x1410b7c99*/
                                                                                  this->avoidedPacketSizesString._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410b7c9f*/
                                                                                  this->avoidedPacketSizesString._Mypair._Myval2._Mysize = 0; /*0x1410b7ca6*/
                                                                                  this->avoidedPacketSizesString._Mypair._Myval2._Myres = 15; /*0x1410b7cad*/
                                                                                  this->avoidedPacketSizesString._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410b7cb8*/
                                                                                  this->avoidedPacketSizes._Mypair._Myval2._Myfirst = nullptr; /*0x1410b7cbe*/
                                                                                  this->avoidedPacketSizes._Mypair._Myval2._Mylast = nullptr; /*0x1410b7cc5*/
                                                                                  this->avoidedPacketSizes._Mypair._Myval2._Myend = nullptr; /*0x1410b7ccc*/
                                                                                  this->reducedMTU = false; /*0x1410b7cd3*/
                                                                                  *(_QWORD *)&this->unconnectedPingStats.unconnectedPings = 0; /*0x1410b7cd9*/
                                                                                  *(_QWORD *)&this->unconnectedPingStats.lastReportUnconnectedPingsMS = 0; /*0x1410b7ce0*/
                                                                                  this->firstOpenReq1Sent = false; /*0x1410b7ce7*/
                                                                                  __wind /*0xf1c000000000080c*/
                                                                                  {
                                                                                    __wind /*0xf1c0000000000814*/
                                                                                    {
                                                                                      __wind /*0xf1c000000000081c*/
                                                                                      {
                                                                                        __wind /*0xf1c0000000000824*/
                                                                                        {
                                                                                          __wind /*0xf1c000000000082c*/
                                                                                          {
                                                                                            WSAStartupSingleton::AddRef(); /*0x1410b7ced*/
                                                                                            Src[0] = DFInt::RakNetMtuValue1InBytes; /*0x1410b7cf8*/
                                                                                            Src[1] = DFInt::RakNetMtuValue2InBytes; /*0x1410b7d02*/
                                                                                            Src[2] = DFInt::RakNetMtuValue3InBytes; /*0x1410b7d0c*/
                                                                                            Myfirst = p_mtuSizeList->_Mypair._Myval2._Myfirst; /*0x1410b7d10*/
                                                                                            if ( (unsigned __int64)(this->mtuSizeList._Mypair._Myval2._Myend - this->mtuSizeList._Mypair._Myval2._Myfirst) < 3 ) /*0x1410b7d22*/
                                                                                            {
                                                                                              std::vector<webrtc::RtpPacket::ExtensionInfo>::_Clear_and_reserve_geometric( /*0x1410b7d2a*/
                                                                                                this: (std::vector<webrtc::RtpPacket::ExtensionInfo> *)&this->mtuSizeList,
                                                                                                _Newsize: 3u);
                                                                                              Myfirst = p_mtuSizeList->_Mypair._Myval2._Myfirst; /*0x1410b7d2f*/
                                                                                            }
                                                                                            memmove_0( /*0x1410b7d40*/
                                                                                              a1: Myfirst,
                                                                                              Src,
                                                                                              Size: 0xCu);
                                                                                            this->mtuSizeList._Mypair._Myval2._Mylast = Myfirst + 3; /*0x1410b7d49*/
                                                                                            this->defaultMTUSize = p_mtuSizeList->_Mypair._Myval2._Myfirst[Myfirst + 3 - p_mtuSizeList->_Mypair._Myval2._Myfirst - 1]; /*0x1410b7d5b*/
                                                                                            this->trackFrequencyTable = false; /*0x1410b7d61*/
                                                                                            *(_DWORD *)&this->maximumNumberOfPeers = 0; /*0x1410b7d6a*/
                                                                                            this->remoteSystemList = nullptr; /*0x1410b7d6d*/
                                                                                            this->activeSystemList = nullptr; /*0x1410b7d74*/
                                                                                            _InterlockedExchange( /*0x1410b7d7d*/
                                                                                              (volatile __int32 *)&this->activeSystemListSize,
                                                                                              0);
                                                                                            this->remoteSystemLookup = nullptr; /*0x1410b7d83*/
                                                                                            *(_QWORD *)&this->bytesSentPerSecond = 0; /*0x1410b7d8a*/
                                                                                            this->prepareEndThreads._Storage._Value = true; /*0x1410b7d96*/
                                                                                            this->endThreads._Storage._Value = true; /*0x1410b7d9e*/
                                                                                            this->isMainLoopThreadActive._Storage._Value = false; /*0x1410b7da3*/
                                                                                            this->startingActiveSystemListIndex = 0; /*0x1410b7da6*/
                                                                                            this->disconnectReason = -1; /*0x1410b7dac*/
                                                                                            if ( !FFlag::NoJoinDiscoThrottleRakNet3.value ) /*0x1410b7dbc*/
                                                                                              this->stepsFromLastJoinOrDisconnect_deprecated = DFInt::StepsToJoin; /*0x1410b7dc4*/
                                                                                            this->peerPlugin = nullptr; /*0x1410b7dca*/
                                                                                            this->occasionalPing = false; /*0x1410b7dd1*/
                                                                                            this->allowInternalRouting = false; /*0x1410b7dd4*/
                                                                                            do /*0x1410b7df7*/
                                                                                            {
                                                                                              RakNet::SystemAddress::operator=( /*0x1410b7dea*/
                                                                                                this: ipList++,
                                                                                                input: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30);
                                                                                              --v23; /*0x1410b7df3*/
                                                                                            }
                                                                                            while ( v23 != 0 ); /*0x1410b7df7*/
                                                                                            this->allowConnectionResponseIPMigration = false; /*0x1410b7df9*/
                                                                                            this->incomingPasswordLength = 0; /*0x1410b7dff*/
                                                                                            this->splitMessageProgressInterval = 0; /*0x1410b7e05*/
                                                                                            this->unreliableTimeout = 1000; /*0x1410b7e0b*/
                                                                                            this->maxOutgoingBPS = 0; /*0x1410b7e15*/
                                                                                            RakNet::SystemAddress::operator=( /*0x1410b7e29*/
                                                                                              this: &this->firstExternalID,
                                                                                              input: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30);
                                                                                            this->myGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410b7e35*/
                                                                                            this->userUpdateThreadPtr = nullptr; /*0x1410b7e4a*/
                                                                                            this->userUpdateThreadData = nullptr; /*0x1410b7e51*/
                                                                                            this->defaultTimeoutTime = DFInt::DefaultTimeoutTimeMs; /*0x1410b7e5e*/
                                                                                            this->isRbxConnection = false; /*0x1410b7e64*/
                                                                                            this->packetsDistributedToPluginsSinceLastDebug = 0; /*0x1410b7e6a*/
                                                                                            if ( !FFlag::BufferedCommandsCircular.value ) /*0x1410b7e77*/
                                                                                              this->bufferedCommands_deprecated.memoryPool.memoryPoolPageSize = 2560; /*0x1410b7e79*/
                                                                                            this->socketQueryOutput.memoryPool.memoryPoolPageSize = 128; /*0x1410b7e83*/
                                                                                            if ( FFlag::CLI52064Experiment2.value ) /*0x1410b7e93*/
                                                                                              this->artificialDelayBufferedPackets.memoryPool.memoryPoolPageSize = 12608; /*0x1410b7e95*/
                                                                                            else
                                                                                              this->bufferedPackets.memoryPool.memoryPoolPageSize = 12608; /*0x1410b7ea1*/
                                                                                            rtc::CriticalSection::Enter(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410b7eb2*/
                                                                                            this->packetAllocationPool.memoryPoolPageSize = 3328; /*0x1410b7eb7*/
                                                                                            RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410b7ec8*/
                                                                                            this->remoteSystemIndexPool.memoryPoolPageSize = 768; /*0x1410b7ecd*/
                                                                                            this->myGuid.g = RBX::globalRand64(); /*0x1410b7edc*/
                                                                                            RakNet::SignaledEvent::InitEvent(this: &this->quitAndDataEvents); /*0x1410b7eea*/
                                                                                            this->limitConnectionFrequencyFromTheSameIP = false; /*0x1410b7eef*/
                                                                                            rtc::CriticalSection::Enter(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410b7efc*/
                                                                                            this->sendReceiptSerial = 1; /*0x1410b7f01*/
                                                                                            RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410b7f12*/
                                                                                          }
                                                                                          __unwind
                                                                                          {
                                                                                            std::vector<std::pair<unsigned short,unsigned short>>::~vector<std::pair<unsigned short,unsigned short>>(this: (std::vector<enum VkPresentModeKHR> *)&this->avoidedPacketSizes); /*0x1431eccde*/
                                                                                          }
                                                                                        }
                                                                                        __unwind
                                                                                        {
                                                                                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->avoidedPacketSizesString); /*0x1431eccbe*/
                                                                                        }
                                                                                      }
                                                                                      __unwind
                                                                                      {
                                                                                        RakNet::RakPeer::TrackDroppedPackets::~TrackDroppedPackets(this: &this->trackDroppedPackets); /*0x1431ecc9e*/
                                                                                      }
                                                                                    }
                                                                                    __unwind
                                                                                    {
                                                                                      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->downloadBandwidthTracker); /*0x1431ecc7e*/
                                                                                    }
                                                                                  }
                                                                                  __unwind
                                                                                  {
                                                                                    RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1431ecc5e*/
                                                                                  }
                                                                                }
                                                                                __unwind
                                                                                {
                                                                                  std::unique_ptr<RBX::RuppTokenProcessor>::~unique_ptr<RBX::RuppTokenProcessor>(this: (std::unique_ptr<RBX::Network::NetworkFilter> *)&this->ruppTokenProcessor); /*0x1431ecc3e*/
                                                                                }
                                                                              }
                                                                              __unwind
                                                                              {
                                                                                std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->ruppHeader); /*0x1431ecc1e*/
                                                                              }
                                                                            }
                                                                            __unwind
                                                                            {
                                                                              RakNet::RakPeer::ConnectionRequestsStats::~ConnectionRequestsStats(this: &this->connectionRequestsStats); /*0x1431ecbfe*/
                                                                            }
                                                                          }
                                                                          __unwind
                                                                          {
                                                                            std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&this->testDeserializeHook); /*0x1431ecbde*/
                                                                          }
                                                                        }
                                                                        __unwind
                                                                        {
                                                                          std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&this->testSendHook); /*0x1431ecbbe*/
                                                                        }
                                                                      }
                                                                      __unwind
                                                                      {
                                                                        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->earlyAuthData); /*0x1431ecb9e*/
                                                                      }
                                                                    }
                                                                    __unwind
                                                                    {
                                                                      std::set<RBX::ContentId>::~set<RBX::ContentId>(this: (std::set<RBX::Studio::ScriptRef> *)&this->usedMacs); /*0x1431ecb7e*/
                                                                    }
                                                                  }
                                                                  __unwind
                                                                  {
                                                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->preauthKey); /*0x1431ecb5e*/
                                                                  }
                                                                }
                                                                __unwind
                                                                {
                                                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->jobId); /*0x1431ecb3e*/
                                                                }
                                                              }
                                                              __unwind
                                                              {
                                                                RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1431ecb1e*/
                                                              }
                                                            }
                                                            __unwind
                                                            {
                                                              std::queue<RakNet::RakPeer::DeferredQueueInfo>::~queue<RakNet::RakPeer::DeferredQueueInfo,std::deque<RakNet::RakPeer::DeferredQueueInfo>>(this: (std::queue<webrtc::RtpPacketizerH264::PacketUnit> *)&this->deferredJoinAndDisconnectTickets_deprecated); /*0x1431ecafe*/
                                                            }
                                                          }
                                                          __unwind
                                                          {
                                                            std::unordered_map<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>::~unordered_map<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>(this: (std::unordered_map<__int64,RBX::HumanoidDescription::AssetData> *)&this->bytesInReturnQueue); /*0x1431ecade*/
                                                          }
                                                        }
                                                        __unwind
                                                        {
                                                          DataStructures::Queue<RakNet::RakPeer::SocketQueryOutput *>::~Queue<RakNet::RakPeer::SocketQueryOutput *>(this: (DataStructures::Queue<bool> *)&this->packetReturnQueue); /*0x1431ecabe*/
                                                        }
                                                      }
                                                      __unwind
                                                      {
                                                        RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1431eca9e*/
                                                      }
                                                    }
                                                    __unwind
                                                    {
                                                      DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::~MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>(this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->packetAllocationPool); /*0x1431eca7e*/
                                                    }
                                                  }
                                                  __unwind
                                                  {
                                                    RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1431eca5e*/
                                                  }
                                                }
                                                __unwind
                                                {
                                                  RBX::LSP::ILSPEditor::onSignalQuiescenceResponse( /*0x1431eca3e*/
                                                    _o: (QObject *)&this->quitAndDataEvents,
                                                    _c: (QMetaObject::Call)v27,
                                                    _id: v24,
                                                    _a: v25);
                                                }
                                              }
                                              __unwind
                                              {
                                                ATL::CEvent::~CEvent(this: (ATL::CMutex *)&this->updateNetworkLoopEnded); /*0x1431eca1e*/
                                              }
                                            }
                                            __unwind
                                            {
                                              ATL::CEvent::~CEvent(this: (ATL::CMutex *)&this->recvFromLoopEnded); /*0x1431ec9fe*/
                                            }
                                          }
                                          __unwind
                                          {
                                            DataStructures::List<RakNet::RakString>::~List<RakNet::RakString>(this: &this->securityExceptionList); /*0x1431ec9de*/
                                          }
                                        }
                                        __unwind
                                        {
                                          DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::~List<std::shared_ptr<RakNet::RakNetSocket>>(this: &this->socketList); /*0x1431ec9be*/
                                        }
                                      }
                                      __unwind
                                      {
                                        std::vector<std::pair<unsigned short,unsigned short>>::~vector<std::pair<unsigned short,unsigned short>>(this: (std::vector<enum VkPresentModeKHR> *)&this->mtuSizeList); /*0x1431ec99e*/
                                      }
                                    }
                                    __unwind
                                    {
                                      RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->securityExceptionMutex.criticalSection); /*0x1431ec97e*/
                                    }
                                  }
                                  __unwind
                                  {
                                    RakNet::RakPeer::RecvSpecQueue::~RecvSpecQueue(this: (RakNet::RakPeer::RecvSpecQueue *)&this->socketQueryOutput); /*0x1431ec95e*/
                                  }
                                }
                                __unwind
                                {
                                  RakNet::RakPeer::RecvSpecQueue::~RecvSpecQueue(this: (RakNet::RakPeer::RecvSpecQueue *)&this->artificialDelayTransmitPackets); /*0x1431ec93e*/
                                }
                              }
                              __unwind
                              {
                                RakNet::RakPeer::RecvSpecQueue::~RecvSpecQueue(this: &this->artificialDelayBufferedPackets); /*0x1431ec91e*/
                              }
                            }
                            __unwind
                            {
                              RakNet::RakPeer::RecvSpecQueue::~RecvSpecQueue(this: (RakNet::RakPeer::RecvSpecQueue *)&this->bufferedPackets); /*0x1431ec8fe*/
                            }
                          }
                          __unwind
                          {
                            boost::mutex::~mutex(this: &this->bufferedCommandsMutex); /*0x1431ec8de*/
                          }
                        }
                        __unwind
                        {
                          RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::~UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>(this: &this->bufferedCommandsCircularSwap); /*0x1431ec8be*/
                        }
                      }
                      __unwind
                      {
                        RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::~UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>(this: &this->bufferedCommandsCircular); /*0x1431ec89e*/
                      }
                    }
                    __unwind
                    {
                      RakNet::RakPeer::RecvSpecQueue::~RecvSpecQueue(this: (RakNet::RakPeer::RecvSpecQueue *)&this->bufferedCommands_deprecated); /*0x1431ec87e*/
                    }
                  }
                  __unwind
                  {
                    RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1431ec85e*/
                  }
                }
                __unwind
                {
                  DataStructures::Queue<RakNet::RakPeer::SocketQueryOutput *>::~Queue<RakNet::RakPeer::SocketQueryOutput *>(this: (DataStructures::Queue<bool> *)&this->requestedConnectionQueue); /*0x1431ec83e*/
                }
              }
              __unwind
              {
                std::unordered_map<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>::~unordered_map<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>(this: (std::unordered_map<__int64,RBX::HumanoidDescription::AssetData> *)&this->banMap); /*0x1431ec81e*/
              }
            }
            __unwind
            {
              RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->banListMutex.criticalSection); /*0x1431ec7fe*/
            }
          }
          __unwind
          {
            RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->incomingQueueMutex.criticalSection); /*0x1431ec7de*/
          }
        }
        __unwind
        {
          `eh vector destructor iterator'( /*0x1431ec7b9*/
            ptr: this->rakPeerMutexes,
            size: 0x28u,
            count: 2u,
            destructor: (void (__fastcall *)(void *))RakNet::SimpleMutex::~SimpleMutex);
        }
      }
      __unwind
      {
        DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::~MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>(this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->remoteSystemIndexPool); /*0x1431ec77e*/
      }
    }
    __unwind
    {
      RakNet::BitStream::~BitStream(this: &this->offlinePingResponse); /*0x1431ec76b*/
    }
  }
  __unwind
  {
    RakNet::RakPeerInterface::~RakPeerInterface(this); /*0xf1c0000000000428*/
  }
  return this; /*0x1410b7f1b*/
}

// Address: 0x1410b8270 | Name: ??1RakPeer@RakNet@@UEAA@XZ
void __fastcall RakNet::RakPeer::~RakPeer(RakNet::RakPeer *this)
{
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *>,void *> *Myhead; // rax
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *>,void *> *Next; // rbx
  int *Myfirst; // rcx
  unsigned __int64 Myres; // rdx
  char *Ptr; // rcx
  std::_Ref_count_base *Rep; // rbx
  QMetaObject::Call v8; // edx
  int v9; // r8d
  void **v10; // r9
  RBX::RuppTokenProcessor *Myval2; // rbx
  std::_Ref_count_base *v12; // rbx
  __int64 v13; // rdx
  std::function<int __cdecl(RakNet::BitStream &)> *v14; // rcx
  std::function<void __cdecl(RakNet::AbstractBitStream const *)> *v15; // rcx
  std::_Ref_count_base *v16; // rbx
  unsigned __int64 v17; // rdx
  char *v18; // rcx
  unsigned __int64 v19; // rdx
  char *v20; // rcx
  char *listArray; // rcx
  QMetaObject::Call v22; // edx
  int v23; // r8d
  void **v24; // r9
  char *v25; // rbx
  char *v26; // rbx
  int *v27; // rcx
  void *v28; // rbp
  __int64 v29; // [rsp+0h] [rbp-28h] BYREF

  this->__vftable = (RakNet::RakPeer_vtbl *)RakNet::RakPeer::`vftable'; /*0x1410b8294*/
  RakNet::RakPeer::Shutdown(this, calledFromDestructor: true); /*0x1410b8299*/
  if ( this->banMap._List._Mypair._Myval2._Mysize != 0 ) /*0x1410b82a6*/
  {
    rtc::CriticalSection::Enter(lpCriticalSection: &this->banListMutex.criticalSection); /*0x1410b82af*/
    Myhead = this->banMap._List._Mypair._Myval2._Myhead; /*0x1410b82b4*/
    Next = Myhead->_Next; /*0x1410b82bb*/
    if ( Myhead->_Next != Myhead ) /*0x1410b82c1*/
    {
      do /*0x1410b82eb*/
      {
        operator delete(ptr: Next->_Myval.second); /*0x1410b82d9*/
        Next = Next->_Next; /*0x1410b82e1*/
      }
      while ( Next != this->banMap._List._Mypair._Myval2._Myhead ); /*0x1410b82eb*/
    }
    std::_Hash<std::_Umap_traits<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *,std::_Uhash_compare<RakNet::SystemAddress,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BanStruct *>>,0>>::clear(this: &this->banMap); /*0x1410b82f4*/
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->banListMutex.criticalSection); /*0x1410b8300*/
  }
  WSAStartupSingleton::Deref(); /*0x1410b8305*/
  RakNet::SignaledEvent::CloseEvent(this: &this->quitAndDataEvents); /*0x1410b8311*/
  Myfirst = this->avoidedPacketSizes._Mypair._Myval2._Myfirst; /*0x1410b8316*/
  if ( Myfirst != nullptr ) /*0x1410b8322*/
  {
    if ( (unsigned __int64)(4 * (this->avoidedPacketSizes._Mypair._Myval2._Myend - Myfirst)) >= 0x1000 ) /*0x1410b8341*/
    {
      if ( (unsigned __int64)Myfirst - *((_QWORD *)Myfirst - 1) - 8 > 0x1F ) /*0x1410b8356*/
        goto LABEL_74; /*0x1410b8356*/
      Myfirst = *((int **)Myfirst - 1); /*0x1410b835c*/
    }
    operator delete(ptr: Myfirst); /*0x1410b835f*/
    this->avoidedPacketSizes._Mypair._Myval2._Myfirst = nullptr; /*0x1410b8364*/
    this->avoidedPacketSizes._Mypair._Myval2._Mylast = nullptr; /*0x1410b836b*/
    this->avoidedPacketSizes._Mypair._Myval2._Myend = nullptr; /*0x1410b8372*/
  }
  Myres = this->avoidedPacketSizesString._Mypair._Myval2._Myres; /*0x1410b8379*/
  if ( Myres >= 0x10 ) /*0x1410b8384*/
  {
    Ptr = this->avoidedPacketSizesString._Mypair._Myval2._Bx._Ptr; /*0x1410b8386*/
    if ( Myres + 1 >= 0x1000 ) /*0x1410b8397*/
    {
      if ( (unsigned __int64)&Ptr[-*((_QWORD *)Ptr - 1) - 8] > 0x1F ) /*0x1410b83ac*/
        goto LABEL_74; /*0x1410b83ac*/
      Ptr = *((char **)Ptr - 1); /*0x1410b83b2*/
    }
    operator delete(ptr: Ptr); /*0x1410b83b5*/
  }
  this->avoidedPacketSizesString._Mypair._Myval2._Mysize = 0; /*0x1410b83ba*/
  this->avoidedPacketSizesString._Mypair._Myval2._Myres = 15; /*0x1410b83c1*/
  this->avoidedPacketSizesString._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410b83cc*/
  boost::circular_buffer<RakNet::RakPeer::TrackDroppedPackets::DroppedPktInfo,std::allocator<RakNet::RakPeer::TrackDroppedPackets::DroppedPktInfo>>::destroy(this: &this->trackDroppedPackets.droppedPktQueue); /*0x1410b83da*/
  Rep = this->downloadBandwidthTracker._Rep; /*0x1410b83df*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b83fa*/
  {
    Rep->_Destroy(this: Rep); /*0x1410b8402*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b840e*/
      Rep->_Delete_this(this: Rep); /*0x1410b8416*/
  }
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410b8420*/
  Myval2 = this->ruppTokenProcessor._Mypair._Myval2; /*0x1410b8425*/
  if ( Myval2 != nullptr ) /*0x1410b842f*/
  {
    RBX::LSP::ILSPEditor::onSignalQuiescenceResponse( /*0x1410b8434*/
      _o: (QObject *)this->ruppTokenProcessor._Mypair._Myval2,
      _c: v8,
      _id: v9,
      _a: v10);
    operator delete(ptr: Myval2); /*0x1410b8441*/
  }
  v12 = this->ruppHeader._Rep; /*0x1410b8446*/
  if ( v12 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v12->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b845c*/
  {
    v12->_Destroy(this: v12); /*0x1410b8464*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v12->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b8470*/
      v12->_Delete_this(this: v12); /*0x1410b8478*/
  }
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->connectionRequestsStats.mx.criticalSection); /*0x1410b8482*/
  v14 = (std::function<int __cdecl(RakNet::BitStream &)> *)this->testDeserializeHook._Mystorage._Ptrs[7]; /*0x1410b848e*/
  if ( v14 != nullptr ) /*0x1410b8495*/
  {
    LOBYTE(v13) = v14 != &this->testDeserializeHook; /*0x1410b849d*/
    ((void (__fastcall *)(std::function<int __cdecl(RakNet::BitStream &)> *, __int64))v14->_Mystorage._Ptrs[0][4].__vftable)( /*0x1410b84a0*/
      a1: v14,
      a2: v13);
    this->testDeserializeHook._Mystorage._Ptrs[7] = nullptr; /*0x1410b84a3*/
  }
  v15 = (std::function<void __cdecl(RakNet::AbstractBitStream const *)> *)this->testSendHook._Mystorage._Ptrs[7]; /*0x1410b84ae*/
  if ( v15 != nullptr ) /*0x1410b84b5*/
  {
    LOBYTE(v13) = v15 != &this->testSendHook; /*0x1410b84bd*/
    ((void (__fastcall *)(std::function<void __cdecl(RakNet::AbstractBitStream const *)> *, __int64))v15->_Mystorage._Ptrs[0][4].__vftable)( /*0x1410b84c0*/
      a1: v15,
      a2: v13);
    this->testSendHook._Mystorage._Ptrs[7] = nullptr; /*0x1410b84c3*/
  }
  v16 = this->earlyAuthData._Rep; /*0x1410b84c7*/
  if ( v16 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v16->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b84dd*/
  {
    v16->_Destroy(this: v16); /*0x1410b84e5*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v16->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b84ef*/
      v16->_Delete_this(this: v16); /*0x1410b84f7*/
  }
  std::_Tree_val<std::_Tree_simple_types<RBX::ContentId>>::_Erase_tree<std::allocator<std::_Tree_node<RBX::ContentId,void *>>>( /*0x1410b8513*/
    this: (std::_Tree_val<std::_Tree_simple_types<RBX::Studio::ScriptRef> > *)&this->usedMacs,
    _Al: (std::allocator<std::_Tree_node<RBX::Studio::ScriptRef,void *> > *)&this->usedMacs,
    _Rootnode: (std::_Tree_node<RBX::Studio::ScriptRef,void *> *)this->usedMacs._Mypair._Myval2._Myval2._Myhead->_Parent);
  operator delete(ptr: this->usedMacs._Mypair._Myval2._Myval2._Myhead); /*0x1410b8524*/
  v17 = this->preauthKey._Mypair._Myval2._Myres; /*0x1410b8529*/
  if ( v17 >= 0x10 ) /*0x1410b8534*/
  {
    v18 = this->preauthKey._Mypair._Myval2._Bx._Ptr; /*0x1410b8536*/
    if ( v17 + 1 >= 0x1000 ) /*0x1410b8547*/
    {
      if ( (unsigned __int64)&v18[-*((_QWORD *)v18 - 1) - 8] > 0x1F ) /*0x1410b855c*/
        goto LABEL_74; /*0x1410b855c*/
      v18 = *((char **)v18 - 1); /*0x1410b8562*/
    }
    operator delete(ptr: v18); /*0x1410b8565*/
  }
  this->preauthKey._Mypair._Myval2._Mysize = 0; /*0x1410b856a*/
  this->preauthKey._Mypair._Myval2._Myres = 15; /*0x1410b8571*/
  this->preauthKey._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410b857c*/
  v19 = this->jobId._Mypair._Myval2._Myres; /*0x1410b8583*/
  if ( v19 >= 0x10 ) /*0x1410b858e*/
  {
    v20 = this->jobId._Mypair._Myval2._Bx._Ptr; /*0x1410b8590*/
    if ( v19 + 1 >= 0x1000 ) /*0x1410b85a1*/
    {
      if ( (unsigned __int64)&v20[-*((_QWORD *)v20 - 1) - 8] > 0x1F ) /*0x1410b85b6*/
        goto LABEL_74; /*0x1410b85b6*/
      v20 = *((char **)v20 - 1); /*0x1410b85bc*/
    }
    operator delete(ptr: v20); /*0x1410b85bf*/
  }
  this->jobId._Mypair._Myval2._Mysize = 0; /*0x1410b85c4*/
  this->jobId._Mypair._Myval2._Myres = 15; /*0x1410b85cb*/
  this->jobId._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410b85d6*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410b85e4*/
  std::deque<RBX::Graphics::UITextureRenderer::JobRequest>::~deque<RBX::Graphics::UITextureRenderer::JobRequest>(this: (std::deque<webrtc::TrendlineEstimator::PacketTiming> *)&this->deferredJoinAndDisconnectTickets_deprecated); /*0x1410b85f0*/
  std::_Hash<std::_Umap_traits<__int64,RBX::HumanoidDescription::AssetData,std::_Uhash_compare<__int64,std::hash<__int64>,std::equal_to<__int64>>,std::allocator<std::pair<__int64 const,RBX::HumanoidDescription::AssetData>>,0>>::~_Hash<std::_Umap_traits<__int64,RBX::HumanoidDescription::AssetData,std::_Uhash_compare<__int64,std::hash<__int64>,std::equal_to<__int64>>,std::allocator<std::pair<__int64 const,RBX::HumanoidDescription::AssetData>>,0>>(this: (std::_Hash<std::_Umap_traits<RBX::Collision::MidPhasePrimHashPair,RBX::Collision::MidPhaseComponentResultPair,std::_Uhash_compare<RBX::Collision::MidPhasePrimHashPair,RBX::Collision::PairHash,std::equal_to<RBX::Collision::MidPhasePrimHashPair> >,std::allocator<std::pair<RBX::Collision::MidPhasePrimHashPair const ,RBX::Collision::MidPhaseComponentResultPair> >,0> > *)&this->bytesInReturnQueue); /*0x1410b85fc*/
  if ( this->packetReturnQueue.allocation_size != 0 ) /*0x1410b8607*/
    operator delete(ptr: this->packetReturnQueue.array); /*0x1410b8610*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410b861c*/
  __eh34_enter_wind_state(-1, 0); /*0xf1c000000000008c*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410b8636*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->packetAllocationPool,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\DS_MemoryPool.h",
    line: 0x51u);
  if ( __eh34_unwind(0) ) /*0xf1c0000000000080*/
unwind_state_0:
    __std_terminate(a1: listArray, a2: &v29); /*0xf1c0000000000018*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000084*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410b8643*/
  RBX::LSP::ILSPEditor::onSignalQuiescenceResponse(_o: (QObject *)&this->quitAndDataEvents, _c: v22, _id: v23, _a: v24); /*0x1410b864f*/
  ATL::CEvent::~CEvent(this: (ATL::CMutex *)&this->updateNetworkLoopEnded); /*0x1410b865b*/
  ATL::CEvent::~CEvent(this: (ATL::CMutex *)&this->recvFromLoopEnded); /*0x1410b8667*/
  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000078*/
  if ( this->securityExceptionList.allocation_size != 0 ) /*0x1410b8673*/
  {
    listArray = (char *)this->securityExceptionList.listArray; /*0x1410b8675*/
    if ( listArray != nullptr ) /*0x1410b867f*/
    {
      v25 = listArray - 8; /*0x1410b8681*/
      `eh vector destructor iterator'( /*0x1410b8694*/
        ptr: listArray,
        size: 8u,
        count: *((_QWORD *)listArray - 1),
        destructor: (void (__fastcall *)(void *))RakNet::RakString::~RakString);
      operator delete(ptr: v25); /*0x1410b86a7*/
    }
  }
  if ( this->socketList.allocation_size != 0 ) /*0x1410b86b4*/
  {
    listArray = (char *)this->socketList.listArray; /*0x1410b86b6*/
    if ( listArray != nullptr ) /*0x1410b86c0*/
    {
      v26 = listArray - 8; /*0x1410b86c2*/
      `eh vector destructor iterator'( /*0x1410b86d5*/
        ptr: listArray,
        size: 0x10u,
        count: *((_QWORD *)listArray - 1),
        destructor: (void (__fastcall *)(void *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>);
      operator delete(ptr: v26); /*0x1410b86e8*/
    }
  }
  if ( __eh34_unwind(0) ) /*0xf1c000000000006c*/
    goto unwind_state_0; /*0xf1c000000000006c*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000070*/
  v27 = this->mtuSizeList._Mypair._Myval2._Myfirst; /*0x1410b86ee*/
  if ( v27 != nullptr ) /*0x1410b86f8*/
  {
    if ( (unsigned __int64)(4 * (this->mtuSizeList._Mypair._Myval2._Myend - v27)) < 0x1000 ) /*0x1410b8717*/
    {
LABEL_56:
      operator delete(ptr: v27); /*0x1410b8735*/
      this->mtuSizeList._Mypair._Myval2._Myfirst = nullptr; /*0x1410b873a*/
      this->mtuSizeList._Mypair._Myval2._Mylast = nullptr; /*0x1410b8741*/
      this->mtuSizeList._Mypair._Myval2._Myend = nullptr; /*0x1410b8748*/
      goto LABEL_57; /*0x1410b8748*/
    }
    if ( (unsigned __int64)v27 - *((_QWORD *)v27 - 1) - 8 <= 0x1F ) /*0x1410b872c*/
    {
      v27 = *((int **)v27 - 1); /*0x1410b8732*/
      goto LABEL_56; /*0x1410b8732*/
    }
LABEL_74:
    _invalid_parameter_noinfo_noreturn(); /*0x1410b899a*/
  }
LABEL_57:
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->securityExceptionMutex.criticalSection); /*0x1410b874f*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->socketQueryOutput.queueMutex.criticalSection); /*0x1410b8762*/
  if ( this->socketQueryOutput.queue.allocation_size != 0 ) /*0x1410b876e*/
    operator delete(ptr: this->socketQueryOutput.queue.array); /*0x1410b8777*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->socketQueryOutput.memoryPoolMutex.criticalSection); /*0x1410b8783*/
  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000064*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410b879d*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->socketQueryOutput,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\DS_MemoryPool.h",
    line: 0x51u);
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->artificialDelayTransmitPackets.queueMutex.criticalSection); /*0x1410b87aa*/
  if ( this->artificialDelayTransmitPackets.queue.allocation_size != 0 ) /*0x1410b87b6*/
    operator delete(ptr: this->artificialDelayTransmitPackets.queue.array); /*0x1410b87bf*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->artificialDelayTransmitPackets.memoryPoolMutex.criticalSection); /*0x1410b87cb*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410b87e5*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->artificialDelayTransmitPackets,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\DS_MemoryPool.h",
    line: 0x51u);
  if ( __eh34_unwind(0) ) /*0xf1c0000000000058*/
    goto unwind_state_0; /*0xf1c0000000000058*/
  __eh34_exit_wind_state(0, -1); /*0xf1c000000000005c*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410b87f2*/
  if ( this->artificialDelayBufferedPackets.queue.allocation_size != 0 ) /*0x1410b87fe*/
    operator delete(ptr: this->artificialDelayBufferedPackets.queue.array); /*0x1410b8807*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->artificialDelayBufferedPackets.memoryPoolMutex.criticalSection); /*0x1410b8813*/
  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000050*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410b882d*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->artificialDelayBufferedPackets,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\DS_MemoryPool.h",
    line: 0x51u);
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->bufferedPackets.queueMutex.criticalSection); /*0x1410b883a*/
  if ( this->bufferedPackets.queue.allocation_size != 0 ) /*0x1410b8846*/
    operator delete(ptr: this->bufferedPackets.queue.array); /*0x1410b884f*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->bufferedPackets.memoryPoolMutex.criticalSection); /*0x1410b885b*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410b8875*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->bufferedPackets,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\DS_MemoryPool.h",
    line: 0x51u);
  if ( __eh34_unwind(0) ) /*0xf1c0000000000044*/
    goto unwind_state_0; /*0xf1c0000000000044*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000048*/
  v28 = (void *)_InterlockedExchange64((volatile __int64 *)&this->bufferedCommandsMutex.event, 0); /*0x1410b887b*/
  if ( v28 != nullptr ) /*0x1410b8885*/
    CloseHandle(hObject: v28); /*0x1410b888a*/
  RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::~UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>(this: &this->bufferedCommandsCircularSwap); /*0x1410b8897*/
  RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::~UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>(this: &this->bufferedCommandsCircular); /*0x1410b88a3*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->bufferedCommands_deprecated.queueMutex.criticalSection); /*0x1410b88af*/
  if ( this->bufferedCommands_deprecated.queue.allocation_size != 0 ) /*0x1410b88bb*/
    operator delete(ptr: this->bufferedCommands_deprecated.queue.array); /*0x1410b88c4*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->bufferedCommands_deprecated.memoryPoolMutex.criticalSection); /*0x1410b88d0*/
  __eh34_enter_wind_state(-1, 0); /*0xf1c000000000003c*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410b88ea*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->bufferedCommands_deprecated,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\DS_MemoryPool.h",
    line: 0x51u);
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410b88f7*/
  if ( this->requestedConnectionQueue.allocation_size != 0 ) /*0x1410b8903*/
    operator delete(ptr: this->requestedConnectionQueue.array); /*0x1410b890c*/
  std::_Hash<std::_Umap_traits<__int64,RBX::HumanoidDescription::AssetData,std::_Uhash_compare<__int64,std::hash<__int64>,std::equal_to<__int64>>,std::allocator<std::pair<__int64 const,RBX::HumanoidDescription::AssetData>>,0>>::~_Hash<std::_Umap_traits<__int64,RBX::HumanoidDescription::AssetData,std::_Uhash_compare<__int64,std::hash<__int64>,std::equal_to<__int64>>,std::allocator<std::pair<__int64 const,RBX::HumanoidDescription::AssetData>>,0>>(this: (std::_Hash<std::_Umap_traits<RBX::Collision::MidPhasePrimHashPair,RBX::Collision::MidPhaseComponentResultPair,std::_Uhash_compare<RBX::Collision::MidPhasePrimHashPair,RBX::Collision::PairHash,std::equal_to<RBX::Collision::MidPhasePrimHashPair> >,std::allocator<std::pair<RBX::Collision::MidPhasePrimHashPair const ,RBX::Collision::MidPhaseComponentResultPair> >,0> > *)&this->banMap); /*0x1410b8918*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->banListMutex.criticalSection); /*0x1410b8924*/
  RakNet::SimpleMutex::~SimpleMutex(lpCriticalSection: &this->incomingQueueMutex.criticalSection); /*0x1410b8930*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000030*/
    goto unwind_state_0; /*0xf1c0000000000030*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000034*/
  `eh vector destructor iterator'( /*0x1410b894c*/
    ptr: this->rakPeerMutexes,
    size: 0x28u,
    count: 2u,
    destructor: (void (__fastcall *)(void *))RakNet::SimpleMutex::~SimpleMutex);
  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000028*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410b8966*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->remoteSystemIndexPool,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\DS_MemoryPool.h",
    line: 0x51u);
  RakNet::BitStream::~BitStream(this: &this->offlinePingResponse); /*0x1410b8970*/
  this->__vftable = (RakNet::RakPeer_vtbl *)RakNet::RakPeerInterface::`vftable'; /*0x1410b897c*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000014*/
    goto unwind_state_0; /*0xf1c0000000000014*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000020*/
}

// Address: 0x1410b8cf0 | Name: ??_GRequestedConnectionStruct@RakPeer@RakNet@@QEAAPEAXI@Z
RakNet::RakPeer::RequestedConnectionStruct *__fastcall RakNet::RakPeer::RequestedConnectionStruct::`scalar deleting destructor'(
        RakNet::RakPeer::RequestedConnectionStruct *this,
        char a2)
{
  std::_Ref_count_base *Rep; // rbx
  std::_Ref_count_base *v5; // rbx

  Rep = this->rbxSessionCrypto._Rep; /*0x1410b8d04*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b8d24*/
  {
    Rep->_Destroy(this: Rep); /*0x1410b8d2c*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b8d38*/
      Rep->_Delete_this(this: Rep); /*0x1410b8d40*/
  }
  v5 = this->socket._Rep; /*0x1410b8d43*/
  if ( v5 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b8d59*/
  {
    v5->_Destroy(this: v5); /*0x1410b8d61*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b8d6b*/
      v5->_Delete_this(this: v5); /*0x1410b8d73*/
  }
  if ( (a2 & 1) != 0 ) /*0x1410b8d7a*/
    operator delete(ptr: this); /*0x1410b8d84*/
  return this; /*0x1410b8d89*/
}

// Address: 0x1410b8db0 | Name: ?AddPacketToProducer@RakPeer@RakNet@@IEAAXPEAUPacket@2@@Z
void __fastcall RakNet::RakPeer::AddPacketToProducer(RakNet::RakPeer *this, RakNet::InternalPacket *p)
{
  char v4; // si
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *Ptr; // rax
  int bytes; // r8d
  int v7; // edx
  RakNet::RakPeer::BytesInReturnQueuePeerTracker *p_second; // rcx
  RakNet::RakPeer::BytesInQueueStats *p_bytesInQueueStats; // rax
  unsigned int v10; // r9d
  _WORD *v11; // rax
  void *g; // rcx
  RakNet::AddressOrGUID counterName; // [rsp+30h] [rbp-D0h] BYREF
  char peerAddress[1040]; // [rsp+60h] [rbp-A0h] BYREF
  std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker> > > > bytesInReturnQueueIter; // [rsp+490h] [rbp+390h] BYREF
  RakNet::InternalPacket *input; // [rsp+498h] [rbp+398h] BYREF

  input = p; /*0x1410b8dba*/
  *(_QWORD *)&p->allocationScheme = (unsigned int)RakNet::GetTimeMS(); /*0x1410b8ddf*/
  v4 = 0; /*0x1410b8de3*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410b8ded*/
  if ( !DFFlag::CLI56775.value ) /*0x1410b8df9*/
  {
    v10 = 4739; /*0x1410b8e76*/
    goto LABEL_12; /*0x1410b8e76*/
  }
  std::_Hash<std::_Umap_traits<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,std::_Uhash_compare<RakNet::SystemAddress,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>,0>>::find<void>( /*0x1410b8e0c*/
    this: &this->bytesInReturnQueue,
    result: &bytesInReturnQueueIter,
    _Keyval: (const RakNet::SystemAddress *)p);
  Ptr = bytesInReturnQueueIter._Ptr; /*0x1410b8e11*/
  if ( bytesInReturnQueueIter._Ptr == this->bytesInReturnQueue._List._Mypair._Myval2._Myhead ) /*0x1410b8e1f*/
  {
    v10 = 4734; /*0x1410b8e6e*/
LABEL_12:
    DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push( /*0x1410b8e7c*/
      this: (DataStructures::Queue<RakNet::InternalPacket *> *)&this->packetReturnQueue,
      &input,
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
      line: v10);
    goto LABEL_13; /*0x1410b8e91*/
  }
  bytes = bytesInReturnQueueIter._Ptr->_Myval.second.bytes; /*0x1410b8e21*/
  if ( bytes + LODWORD(p->nextActionTime) < (unsigned int)DFInt::CLI56775B ) /*0x1410b8e31*/
    goto LABEL_7; /*0x1410b8e31*/
  if ( !bytesInReturnQueueIter._Ptr->_Myval.second.hasReported ) /*0x1410b8e37*/
  {
    bytesInReturnQueueIter._Ptr->_Myval.second.hasReported = true; /*0x1410b8e39*/
    v4 = 1; /*0x1410b8e3d*/
  }
  if ( !DFFlag::CLI56775D.value ) /*0x1410b8e47*/
  {
LABEL_7:
    v7 = bytes + LODWORD(p->nextActionTime); /*0x1410b8e4c*/
    Ptr->_Myval.second.bytes = v7; /*0x1410b8e4f*/
    p_second = &Ptr->_Myval.second; /*0x1410b8e52*/
    p_bytesInQueueStats = &this->bytesInQueueStats; /*0x1410b8e56*/
    if ( this->bytesInQueueStats.maxBytesInReturnQueueSinglePeer < v7 ) /*0x1410b8e5d*/
      p_bytesInQueueStats = (RakNet::RakPeer::BytesInQueueStats *)p_second; /*0x1410b8e5d*/
    this->bytesInQueueStats.maxBytesInReturnQueueSinglePeer = p_bytesInQueueStats->maxBytesInReturnQueueSinglePeer; /*0x1410b8e63*/
    v10 = 4729; /*0x1410b8e66*/
    goto LABEL_12; /*0x1410b8e6c*/
  }
LABEL_13:
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410b8e96*/
  if ( DFFlag::CLI56775.value && v4 != 0 )
  {
    RakNet::SystemAddress::ToStringN( /*0x1410b8ecd*/
      this: (RakNet::SystemAddress *)p,
      writePort: true,
      dest: peerAddress,
      size: 1025,
      portDelineator: 124);
    if ( FLog::Network != 0 )
      FLog::FastLogFormatted(
        level: FLog::Network,
        message: "[FLog::Network] Rx: Peer %s exceeded buffered complete datagram byte cap of %d",
        peerAddress,
        DFInt::CLI56775B);
    v11 = operator new(size: 0x30u); /*0x1410b8f13*/
    *(_QWORD *)&counterName.systemAddress.address.addr6.sin6_family = 39; /*0x1410b8f18*/
    *(_QWORD *)counterName.systemAddress.address.addr4.sin_zero = 47; /*0x1410b8f21*/
    qmemcpy(v11, "RakNetRxCompleteDatagramByteCapExceede", 38); /*0x1410b8f31*/
    v11[19] = (unsigned __int8)aRaknetrxcomple[38]; /*0x1410b8f5a*/
    counterName.rakNetGuid.g = (unsigned __int64)v11; /*0x1410b8f61*/
    __wind /*0xf1c0000000000010*/
    {
      RBX::Analytics::EphemeralCounter::reportCounter((const std::string *)&counterName, amount: 1, blocking: false); /*0x1410b8f72*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c0000000000008*/
    }
    if ( *(_QWORD *)counterName.systemAddress.address.addr4.sin_zero >= 0x10u ) /*0x1410b8f81*/
    {
      g = (void *)counterName.rakNetGuid.g; /*0x1410b8f86*/
      if ( (unsigned __int64)(*(_QWORD *)counterName.systemAddress.address.addr4.sin_zero + 1LL) >= 0x1000 ) /*0x1410b8f95*/
      {
        g = *(void **)(counterName.rakNetGuid.g - 8); /*0x1410b8f9b*/
        if ( counterName.rakNetGuid.g - (unsigned __int64)g - 8 > 0x1F ) /*0x1410b8faa*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410b8fac*/
      }
      operator delete(ptr: g); /*0x1410b8fb3*/
    }
    ++this->bytesInQueueStats.peersExceededByteCapInReturnQueue; /*0x1410b8fb8*/
    if ( DFFlag::CLI56775D.value ) /*0x1410b8fc2*/
    {
      RakNet::RakNetGUID::RakNetGUID(this: &counterName.rakNetGuid); /*0x1410b8fc9*/
      RakNet::SystemAddress::SystemAddress(this: &counterName.systemAddress); /*0x1410b8fd3*/
      counterName.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410b8fdf*/
      RakNet::SystemAddress::operator=(this: &counterName.systemAddress, input: (const RakNet::SystemAddress *)p); /*0x1410b8ff8*/
      RakNet::RakPeer::CloseConnectionInternal( /*0x1410b9018*/
        this,
        systemIdentifier: &counterName,
        sendDisconnectionNotification: false,
        performImmediate: true,
        orderingChannel: 0,
        disconnectionNotificationPriority: LOW_PRIORITY);
      this->DeallocatePacket(this, a2: (RakNet::Packet *)p); /*0x1410b9026*/
    }
  }
}

// Address: 0x1410b9050 | Name: ?AddToBanList@RakPeer@RakNet@@UEAAXAEBUSystemAddress@2@I@Z
void __fastcall RakNet::RakPeer::AddToBanList(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *ipToBan,
        unsigned int milliseconds)
{
  int TimeMS; // r14d
  RakNet::SimpleMutex *p_banListMutex; // rbp
  std::unordered_map<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,std::allocator<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *> > > *p_banMap; // r12
  RakNet::RakPeer::BanStruct *second; // rax
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *>,void *> *v10; // rax
  RakNet::RakPeer::BanStruct *v11; // rbx
  unsigned int v12; // edi
  std::pair<std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *>,void *> *,bool> result; // [rsp+20h] [rbp-38h] BYREF
  std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *> > > > banIter; // [rsp+60h] [rbp+8h] BYREF

  TimeMS = RakNet::GetTimeMS(); /*0x1410b9074*/
  p_banListMutex = &this->banListMutex; /*0x1410b9077*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->banListMutex.criticalSection); /*0x1410b9081*/
  p_banMap = &this->banMap; /*0x1410b9086*/
  std::_Hash<std::_Umap_traits<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,std::_Uhash_compare<RakNet::SystemAddress,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>,0>>::find<void>( /*0x1410b9098*/
    this: (std::_Hash<std::_Umap_traits<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,std::_Uhash_compare<RakNet::SystemAddress,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress> >,std::allocator<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker> >,0> > *)&this->banMap,
    result: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker> > > > *)&banIter,
    _Keyval: ipToBan);
  if ( banIter._Ptr == this->banMap._List._Mypair._Myval2._Myhead ) /*0x1410b90a9*/
  {
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->banListMutex.criticalSection); /*0x1410b90c6*/
    v10 = (std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *>,void *> *)operator new(size: 0x24u); /*0x1410b90d0*/
    v11 = (RakNet::RakPeer::BanStruct *)v10; /*0x1410b90d5*/
    banIter._Ptr = v10; /*0x1410b90d8*/
    __wind /*0xf1c000000000001c*/
    {
      v12 = 0; /*0x1410b90dd*/
      if ( v10 != nullptr ) /*0x1410b90e2*/
        RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v10); /*0x1410b90e7*/
      else
        v11 = nullptr; /*0x1410b90ee*/
    }
    __unwind
    {
      operator delete(ptr: banIter._Ptr); /*0x1431ecd52*/
    }
    RakNet::SystemAddress::operator=(this: &v11->bannedAddress, input: ipToBan); /*0x1410b90f7*/
    if ( milliseconds != 0 ) /*0x1410b9102*/
      v12 = TimeMS + milliseconds; /*0x1410b9102*/
    v11->timeout = v12; /*0x1410b9105*/
    rtc::CriticalSection::Enter(lpCriticalSection: &p_banListMutex->criticalSection); /*0x1410b910b*/
    std::_Hash<std::_Umap_traits<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *,std::_Uhash_compare<RakNet::SystemAddress,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BanStruct *>>,0>>::_Try_emplace<RakNet::SystemAddress const &,>( /*0x1410b9123*/
      this: p_banMap,
      &result,
      _Keyval_arg: ipToBan)->first->_Myval.second = v11;
  }
  else
  {
    second = banIter._Ptr->_Myval.second; /*0x1410b90ab*/
    if ( milliseconds != 0 ) /*0x1410b90b1*/
      second->timeout = TimeMS + milliseconds; /*0x1410b90be*/
    else
      second->timeout = 0; /*0x1410b90b5*/
  }
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_banListMutex->criticalSection); /*0x1410b9140*/
}

// Address: 0x1410b9150 | Name: ?AddToSecurityExceptionList@RakPeer@RakNet@@UEAAXPEBD@Z
void __fastcall RakNet::RakPeer::AddToSecurityExceptionList(RakNet::RakPeer *this, const char *ip)
{
  const RakNet::RakString *v4; // rax
  RakNet::RakString v5; // [rsp+30h] [rbp+8h] BYREF

  rtc::CriticalSection::Enter(lpCriticalSection: &this->securityExceptionMutex.criticalSection); /*0x1410b916c*/
  v4 = RakNet::RakString::RakString(this: &v5, format: ip); /*0x1410b9179*/
  __wind /*0xf1c0000000000010*/
  {
    DataStructures::List<RakNet::RakString>::Insert( /*0x1410b9196*/
      this: &this->securityExceptionList,
      input: v4,
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
      line: 0x3AEu);
  }
  __unwind
  {
    RakNet::RakString::~RakString(this: &v5); /*0xf1c0000000000008*/
  }
  RakNet::RakString::~RakString(this: &v5); /*0x1410b91a1*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->securityExceptionMutex.criticalSection); /*0x1410b91bc*/
}

// Address: 0x1410b91d0 | Name: ?AllocPacket@RakPeer@RakNet@@IEAAPEAUPacket@2@IPEAEPEBDI@Z
DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *__fastcall RakNet::RakPeer::AllocPacket(
        RakNet::RakPeer *this,
        unsigned int dataSize,
        unsigned __int8 *data,
        const char *file,
        unsigned int line)
{
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v9; // rsi

  rtc::CriticalSection::Enter(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410b91fd*/
  v9 = DataStructures::MemoryPool<RakNet::Packet>::Allocate(this: &this->packetAllocationPool, file, line); /*0x1410b921d*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410b9220*/
  RakNet::SystemAddress::SystemAddress(this: &v9->userMemory.systemAddress); /*0x1410b9228*/
  RakNet::RakNetGUID::RakNetGUID(this: &v9->userMemory.guid); /*0x1410b9231*/
  v9->userMemory.data = data; /*0x1410b9248*/
  v9->userMemory.bitSize = 8 * dataSize; /*0x1410b9251*/
  v9->userMemory.cycleReceivedByApplication = 0; /*0x1410b9254*/
  v9->userMemory.length = dataSize; /*0x1410b925b*/
  v9->userMemory.deleteData = true; /*0x1410b925f*/
  v9->userMemory.guid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410b926a*/
  v9->userMemory.wasGeneratedLocally = false; /*0x1410b927c*/
  return v9; /*0x1410b9280*/
}

// Address: 0x1410b9290 | Name: ?AllocPacket@RakPeer@RakNet@@IEAAPEAUPacket@2@IPEBDI@Z
DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *__fastcall RakNet::RakPeer::AllocPacket(
        RakNet::RakPeer *this,
        unsigned int dataSize,
        const char *file,
        unsigned int line)
{
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v8; // rsi

  rtc::CriticalSection::Enter(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410b92bd*/
  v8 = DataStructures::MemoryPool<RakNet::Packet>::Allocate(this: &this->packetAllocationPool, file, line); /*0x1410b92db*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410b92de*/
  RakNet::SystemAddress::SystemAddress(this: &v8->userMemory.systemAddress); /*0x1410b92e6*/
  RakNet::RakNetGUID::RakNetGUID(this: &v8->userMemory.guid); /*0x1410b92ef*/
  v8->userMemory.cycleReceivedByApplication = 0; /*0x1410b92f7*/
  v8->userMemory.data = (unsigned __int8 *)RBX::Memory::allocate(size: dataSize); /*0x1410b931a*/
  v8->userMemory.bitSize = 8 * dataSize; /*0x1410b931e*/
  v8->userMemory.length = dataSize; /*0x1410b9321*/
  v8->userMemory.deleteData = true; /*0x1410b9325*/
  v8->userMemory.guid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410b9330*/
  v8->userMemory.wasGeneratedLocally = false; /*0x1410b9342*/
  return v8; /*0x1410b9346*/
}

// Address: 0x1410b9d60 | Name: ?AllocatePacket@RakPeer@RakNet@@UEAAPEAUPacket@2@I@Z
DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *__fastcall RakNet::RakPeer::AllocatePacket(
        RakNet::RakPeer *this,
        unsigned int dataSize)
{
  return RakNet::RakPeer::AllocPacket(
           this,
           dataSize,
           file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
           line: 0xBA6u);
}

// Address: 0x1410b9d80 | Name: ?AllocateQueueTxPacket@RakPeer@RakNet@@QEAAPEAUDelayTransmitStruct@2@XZ
RakNet::DelayTransmitStruct *__fastcall RakNet::RakPeer::AllocateQueueTxPacket(RakNet::RakPeer *this)
{
  return DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Allocate(
           this: &this->artificialDelayTransmitPackets,
           file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
           line: 0xF4Eu);
}

// Address: 0x1410b9da0 | Name: ?AllowConnectionResponseIPMigration@RakPeer@RakNet@@UEAAX_N@Z
void __fastcall RakNet::RakPeer::AllowConnectionResponseIPMigration(RakNet::RakPeer *this, bool allow)
{
  this->allowConnectionResponseIPMigration = allow; /*0x1410b9da0*/
}

// Address: 0x1410b9db0 | Name: ?AllowIncomingConnections@RakPeer@RakNet@@IEBA_NXZ
bool __fastcall RakNet::RakPeer::AllowIncomingConnections(RakNet::RakPeer *this)
{
  unsigned __int16 v2; // bx
  unsigned int i; // r8d
  __int64 v4; // r9
  RakNet::RakPeer::RemoteSystemStruct *v5; // rcx

  if ( this->remoteSystemList == nullptr || this->endThreads._Storage._Value ) /*0x1410b9dc3*/
  {
    v2 = 0; /*0x1410b9e2c*/
  }
  else
  {
    v2 = 0; /*0x1410b9dd2*/
    for ( i = 0; i < this->activeSystemListSize._Storage._Value; ++i ) /*0x1410b9dda*/
    {
      v4 = i; /*0x1410b9de3*/
      if ( this->activeSystemList[v4]->isActive._Storage._Value ) /*0x1410b9df6*/
      {
        v5 = this->activeSystemList[v4]; /*0x1410b9e05*/
        if ( v5->connectMode == (UNVERIFIED_SENDER|DISCONNECT_ASAP) && !v5->weInitiatedTheConnection ) /*0x1410b9e16*/
          ++v2; /*0x1410b9e18*/
      }
    }
  }
  return v2 < this->GetMaximumIncomingConnections(this); /*0x1410b9e3d*/
}

// Address: 0x1410b9e50 | Name: ?AssignSystemAddressToRemoteSystemList@RakPeer@RakNet@@IEAAPEAURemoteSystemStruct@12@USystemAddress@2@W4ConnectMode@312@V?$shared_ptr@URakNetSocket@RakNet@@@std@@PEA_NU42@HURakNetGUID@2@_N_KV?$shared_ptr@VRakPeerCrypto@Security@RBX@@@7@VStringView@RBX@@@Z
RakNet::RakPeer::RemoteSystemStruct *__fastcall RakNet::RakPeer::AssignSystemAddressToRemoteSystemList(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *systemAddress,
        RakNet::RakPeer::RemoteSystemStruct::ConnectMode connectionMode,
        std::shared_ptr<RBX::File> *incomingRakNetSocket,
        bool *thisIPConnectedRecently,
        RakNet::SystemAddress *bindingAddress,
        int incomingMTU,
        RakNet::RakNetGUID *guid,
        bool useSecurity,
        unsigned __int64 commonCapabilities,
        std::shared_ptr<RBX::File> *crypto,
        RBX::StringView *gameServiceToken)
{
  unsigned __int64 TimeMS; // r13
  bool v16; // al
  int i; // edi
  __int64 v18; // rsi
  unsigned int v19; // edi
  bool j; // cf
  __int64 v21; // rsi
  unsigned __int64 connectionTime; // rdx
  __int64 v23; // rdx
  __int64 v24; // r8
  __int64 v25; // rsi
  std::_Ref_count_base *v26; // rbx
  std::_Ref_count_base *v27; // rbx
  RakNet::RakPeer::RemoteSystemStruct *result; // rax
  RakNet::RakPeer::RemoteSystemStruct *v29; // r14
  RBX::RuppTokenProcessor *Myval2; // rcx
  RakNet::RakPeer::RemoteSystemStruct *v31; // r8
  RakNet::RakPeer::RemoteSystemStruct **activeSystemList; // rdx
  std::_Ref_count_base *Rep; // rbx
  std::_Ref_count_base *v34; // rbx
  RakNet::RakPeer::BytesInReturnQueuePeerTracker v35; // [rsp+30h] [rbp-59h]
  std::pair<std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *,bool> v36; // [rsp+50h] [rbp-39h] BYREF
  RakNet::RakNetGUID lhs; // [rsp+60h] [rbp-29h] BYREF
  RakNet::SystemAddress right; // [rsp+70h] [rbp-19h] BYREF

  __wind /*0xf1c000000000003c*/
  {
    __eh34_enter_wind_state(0, 1); /*0xf1c0000000000044*/
    TimeMS = (unsigned int)RakNet::GetTimeMS(); /*0x1410b9e84*/
    if ( this->limitConnectionFrequencyFromTheSameIP ) /*0x1410b9e8a*/
    {
      RakNet::RakNetGUID::RakNetGUID(this: &lhs); /*0x1410b9e9b*/
      RakNet::SystemAddress::SystemAddress(this: &right); /*0x1410b9ea4*/
      lhs = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410b9eb0*/
      RakNet::SystemAddress::operator=(this: &right, input: systemAddress); /*0x1410b9ec6*/
      if ( StudioResourceId::operator!=( /*0x1410b9ed6*/
             this: (RBX::json::ArrayIterator *)&lhs,
             rhs: (const RBX::json::ArrayIterator *)&RakNet::UNASSIGNED_RAKNET_GUID_30) )
      {
        v16 = StudioResourceId::operator==(&lhs, rhs: &this->myGuid); /*0x1410b9eea*/
      }
      else
      {
        for ( i = 0; i < 10; ++i ) /*0x1410b9ef1*/
        {
          v18 = i; /*0x1410b9f03*/
          if ( RakNet::SystemAddress::operator!=(this: &this->ipList[v18], right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410b9f1f*/
            break; /*0x1410b9f1f*/
          if ( RakNet::SystemAddress::EqualsExcludingPort(this: &this->ipList[v18], &right) ) /*0x1410b9f2f*/
            goto LABEL_19; /*0x1410b9f36*/
        }
        v16 = RakNet::SystemAddress::EqualsExcludingPort(this: &right, right: &this->firstExternalID); /*0x1410b9f4e*/
      }
      if ( !v16 ) /*0x1410b9f55*/
      {
        v19 = 0; /*0x1410b9f5b*/
        for ( j = this->maximumNumberOfPeers != 0; j; j = v19 < this->maximumNumberOfPeers ) /*0x1410b9f5e*/
        {
          v21 = v19; /*0x1410b9f67*/
          if ( this->remoteSystemList[v21].isActive._Storage._Value /*0x1410b9f90*/
            && RakNet::SystemAddress::EqualsExcludingPort(
                 this: &this->remoteSystemList[v21].systemAddress,
                 right: systemAddress) )
          {
            connectionTime = this->remoteSystemList[v21].connectionTime; /*0x1410b9fa3*/
            if ( TimeMS >= connectionTime && TimeMS - connectionTime < 0x64 ) /*0x1410b9fb7*/
            {
              *thisIPConnectedRecently = true; /*0x1410b9fc7*/
              if ( __eh34_unwind(1) ) /*0xf1c0000000000030*/
                goto unwind_state_1; /*0xf1c0000000000030*/
              __eh34_exit_wind_state(1, 0); /*0xf1c0000000000034*/
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: incomingRakNetSocket); /*0x1410b9fcd*/
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: crypto); /*0x1410b9fda*/
              goto LABEL_30; /*0x1410b9fdf*/
            }
          }
          ++v19; /*0x1410b9fb9*/
        }
      }
    }
LABEL_19:
    RakNet::SystemAddress::CopyPort( /*0x1410b9fe4*/
      this: bindingAddress,
      right: (const RakNet::SystemAddress *)((char *)&incomingRakNetSocket->_Ptr->_Wptr.std::_Ptr_base<RBX::File>::_Ptr + 4));
    *thisIPConnectedRecently = false; /*0x1410b9ff9*/
    v24 = 0; /*0x1410b9ffc*/
    if ( this->maximumNumberOfPeers != 0 ) /*0x1410ba004*/
    {
      while ( 1 ) /*0x1410ba009*/
      {
        v25 = (unsigned int)v24; /*0x1410ba009*/
        if ( !this->remoteSystemList[v25].isActive._Storage._Value ) /*0x1410ba01e*/
          break; /*0x1410ba01e*/
        v24 = (unsigned int)(v24 + 1); /*0x1410ba024*/
        if ( (unsigned int)v24 >= this->maximumNumberOfPeers ) /*0x1410ba02e*/
          goto LABEL_22; /*0x1410ba02e*/
      }
      v29 = &this->remoteSystemList[v25]; /*0x1410ba0c4*/
      RakNet::RakPeer::ReferenceRemoteSystem(this, sa: systemAddress, remoteSystemListIndex: v24); /*0x1410ba0cd*/
      v29->MTUSize = this->defaultMTUSize; /*0x1410ba0d8*/
      v29->guid = *guid; /*0x1410ba0e6*/
      v29->isActive._Storage._Value = true; /*0x1410ba0fe*/
      if ( incomingMTU > v29->MTUSize ) /*0x1410ba10b*/
        v29->MTUSize = incomingMTU; /*0x1410ba10d*/
      v29->remoteCommonCapabilities = commonCapabilities; /*0x1410ba11b*/
      if ( DFFlag::CLI50798.value ) /*0x1410ba129*/
      {
        *(unsigned __int64 *)((char *)&v29->reliabilityLayer.commonCapabilities + 4) = commonCapabilities; /*0x1410ba132*/
        RakNet::ReliabilityLayer::setAvoidedPacketSizes( /*0x1410ba140*/
          this: (RakNet::ReliabilityLayer *)((char *)&v29->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
          packetSizes: &this->avoidedPacketSizes);
      }
      if ( FFlag::RuppTokEn4.value && this->getServerReceiveRuppToken(this) ) /*0x1410ba158*/
      {
        if ( gameServiceToken->Length == 16 ) /*0x1410ba172*/
        {
          if ( DFFlag::RuppTokenDebugMsg.value ) /*0x1410ba17f*/
            *(_OWORD *)v29->debugFirstGameServiceToken = *(_OWORD *)gameServiceToken->Data; /*0x1410ba187*/
          Myval2 = this->ruppTokenProcessor._Mypair._Myval2; /*0x1410ba196*/
          if ( Myval2 != nullptr /*0x1410ba1ca*/
            && gameServiceToken->Length == 16
            && !RBX::Reflection::TypedPropertyDescriptor<RBX::UDim>::hasStringValue(__formal: (bool)Myval2) )
          {
            if ( DFFlag::RuppTokEnAnyOpt.value ) /*0x1410ba1d9*/
              v35.bytes = (unsigned int)RBX::Reflection::EventDescBase<RBX::Humanoid,void (bool),rbx::remote_signal<void (bool)>,rbx::remote_signal<void (bool)> RBX::Humanoid::*>::getLatchedSignal(_Where: this->ruppTokenProcessor._Mypair._Myval2); /*0x1410ba1ed*/
            else
              v35.bytes = 0; /*0x1410ba1fb*/
            v35.hasReported = true; /*0x1410ba1f0*/
          }
          else
          {
            v35.bytes = 0; /*0x1410ba207*/
            v35.hasReported = true; /*0x1410ba20a*/
          }
        }
        else
        {
          if ( DFFlag::RuppTokenDebugMsg.value ) /*0x1410ba217*/
            *(_OWORD *)v29->debugFirstGameServiceToken = 0; /*0x1410ba21c*/
          v35.hasReported = false; /*0x1410ba224*/
        }
        v29->tokenOptions = (std::optional<unsigned int>)v35; /*0x1410ba22c*/
      }
      std::shared_ptr<RBX::GfxGui>::operator=( /*0x1410ba244*/
        this: (std::shared_ptr<RobloxDiagnosticsView::ItemData> *)((char *)&v29->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
        _Right: (const std::shared_ptr<RobloxDiagnosticsView::ItemData> *)crypto);
      RakNet::ReliabilityLayer::Reset( /*0x1410ba25d*/
        this: (RakNet::ReliabilityLayer *)((char *)&v29->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
        resetVariables: true,
        MTUSize: v29->MTUSize,
        _useSecurity: useSecurity);
      RakNet::ReliabilityLayer::SetSplitMessageProgressInterval( /*0x1410ba26b*/
        this: (RakNet::ReliabilityLayer *)((char *)&v29->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
        interval: this->splitMessageProgressInterval);
      RakNet::ReliabilityLayer::SetUnreliableTimeout( /*0x1410ba279*/
        this: (RakNet::ReliabilityLayer *)((char *)&v29->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
        timeoutMS: this->unreliableTimeout);
      RakNet::ReliabilityLayer::SetTimeoutTime( /*0x1410ba287*/
        this: (RakNet::ReliabilityLayer *)((char *)&v29->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
        time: this->defaultTimeoutTime);
      RakNet::ReliabilityLayer::SetMaxRxPayloadSizePtr( /*0x1410ba296*/
        this: (RakNet::ReliabilityLayer *)((char *)&v29->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
        maxRxPayloadDataSize: this->maxRxPayloadSize);
      v31 = &this->remoteSystemList[v25]; /*0x1410ba2a2*/
      activeSystemList = this->activeSystemList; /*0x1410ba2a5*/
      activeSystemList[_InterlockedExchangeAdd((volatile signed __int32 *)&this->activeSystemListSize, 1u)] = v31; /*0x1410ba2b9*/
      std::shared_ptr<RBX::GfxGui>::operator=( /*0x1410ba2c7*/
        this: (std::shared_ptr<RobloxDiagnosticsView::ItemData> *)&v29->rakNetSocket,
        _Right: (const std::shared_ptr<RobloxDiagnosticsView::ItemData> *)incomingRakNetSocket);
      v29->pingAndClockDifferential[0].pingTime = -1; /*0x1410ba2d1*/
      v29->pingAndClockDifferential[0].monotonicClockDifferentialMS = 0; /*0x1410ba2db*/
      v29->pingAndClockDifferential[1].pingTime = -1; /*0x1410ba2e2*/
      v29->pingAndClockDifferential[1].monotonicClockDifferentialMS = 0; /*0x1410ba2ea*/
      v29->pingAndClockDifferential[2].pingTime = -1; /*0x1410ba2f1*/
      v29->pingAndClockDifferential[2].monotonicClockDifferentialMS = 0; /*0x1410ba2f9*/
      v29->pingAndClockDifferential[3].pingTime = -1; /*0x1410ba300*/
      v29->pingAndClockDifferential[3].monotonicClockDifferentialMS = 0; /*0x1410ba308*/
      v29->pingAndClockDifferential[4].pingTime = -1; /*0x1410ba30f*/
      v29->pingAndClockDifferential[4].monotonicClockDifferentialMS = 0; /*0x1410ba317*/
      v29->connectMode = connectionMode; /*0x1410ba321*/
      v29->pingAndClockDifferentialWriteIndex = 0; /*0x1410ba328*/
      v29->lowestPing._Storage._Value = -1; /*0x1410ba336*/
      v29->nextPingTime = 0; /*0x1410ba33b*/
      v29->weInitiatedTheConnection = false; /*0x1410ba342*/
      v29->connectionTime = TimeMS; /*0x1410ba349*/
      v29->lastReliableSend = TimeMS; /*0x1410ba350*/
      if ( DFFlag::CLI50798.value ) /*0x1410ba35d*/
        v29->lastAvoidPacketReportMS = TimeMS; /*0x1410ba35f*/
      if ( DFFlag::CLI56775.value ) /*0x1410ba36c*/
      {
        rtc::CriticalSection::Enter(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410ba375*/
        v35.bytes = 0; /*0x1410ba37a*/
        v35.hasReported = false; /*0x1410ba381*/
        std::_Hash<std::_Umap_traits<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,std::_Uhash_compare<RakNet::SystemAddress,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>,0>>::_Try_emplace<RakNet::SystemAddress const &,>( /*0x1410ba39f*/
          this: &this->bytesInReturnQueue,
          result: &v36,
          _Keyval_arg: systemAddress)->first->_Myval.second = v35;
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410ba3aa*/
      }
      if ( __eh34_unwind(1) ) /*0xf1c0000000000004*/
      {
unwind_state_1:
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: incomingRakNetSocket); /*0xf1c0000000000008*/
        __eh34_continue_unwinding(1, 0); /*0xf1c000000000000c*/
      }
      __eh34_exit_wind_state(1, 0); /*0xf1c0000000000010*/
      Rep = incomingRakNetSocket->_Rep; /*0x1410ba3b0*/
      if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410ba3c4*/
      {
        Rep->_Destroy(this: Rep); /*0x1410ba3cc*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410ba3d8*/
          Rep->_Delete_this(this: Rep); /*0x1410ba3e0*/
      }
      v34 = crypto->_Rep; /*0x1410ba3eb*/
      if ( v34 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v34->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410ba3fe*/
      {
        v34->_Destroy(this: v34); /*0x1410ba406*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v34->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410ba410*/
          v34->_Delete_this(this: v34); /*0x1410ba418*/
      }
      result = v29; /*0x1410ba41b*/
    }
    else
    {
LABEL_22:
      v26 = incomingRakNetSocket->_Rep; /*0x1410ba030*/
      if ( v26 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v26->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410ba049*/
      {
        ((void (__fastcall *)(std::_Ref_count_base *, __int64, __int64))v26->_Destroy)(a1: v26, a2: v23, a3: v24); /*0x1410ba051*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v26->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410ba05d*/
          v26->_Delete_this(this: v26); /*0x1410ba065*/
      }
      v27 = crypto->_Rep; /*0x1410ba070*/
      if ( v27 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v27->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410ba083*/
      {
        ((void (__fastcall *)(std::_Ref_count_base *, __int64, __int64))v27->_Destroy)(a1: v27, a2: v23, a3: v24); /*0x1410ba08b*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v27->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410ba095*/
          v27->_Delete_this(this: v27); /*0x1410ba09d*/
      }
      if ( __eh34_unwind(1) ) /*0xf1c0000000000024*/
        goto unwind_state_1; /*0xf1c0000000000024*/
      __eh34_exit_wind_state(1, 0); /*0xf1c0000000000028*/
LABEL_30:
      result = nullptr; /*0x1410ba0a0*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: crypto); /*0xf1c000000000001c*/
  }
  return result; /*0x1410ba0a2*/
}

// Address: 0x1410ba850 | Name: ?ClearBanList@RakPeer@RakNet@@UEAAXXZ
void __fastcall RakNet::RakPeer::ClearBanList(RakNet::RakPeer *this)
{
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *>,void *> *Myhead; // rax
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *>,void *> *Next; // rbx

  if ( this->banMap._List._Mypair._Myval2._Mysize != 0 ) /*0x1410ba861*/
  {
    rtc::CriticalSection::Enter(lpCriticalSection: &this->banListMutex.criticalSection); /*0x1410ba874*/
    Myhead = this->banMap._List._Mypair._Myval2._Myhead; /*0x1410ba879*/
    Next = Myhead->_Next; /*0x1410ba880*/
    if ( Myhead->_Next != Myhead ) /*0x1410ba886*/
    {
      do /*0x1410ba8a8*/
      {
        operator delete(ptr: Next->_Myval.second); /*0x1410ba899*/
        Next = Next->_Next; /*0x1410ba89e*/
      }
      while ( Next != this->banMap._List._Mypair._Myval2._Myhead ); /*0x1410ba8a8*/
    }
    std::_Hash<std::_Umap_traits<RakNet::SystemAddress,RakNet::RakPeer::BanStruct *,std::_Uhash_compare<RakNet::SystemAddress,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BanStruct *>>,0>>::clear(this: &this->banMap); /*0x1410ba8b1*/
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->banListMutex.criticalSection); /*0x1410ba8bd*/
  }
}

// Address: 0x1410ba8e0 | Name: ?ClearBufferedCommands@RakPeer@RakNet@@IEAAXXZ
void __fastcall RakNet::RakPeer::ClearBufferedCommands(RakNet::RakPeer *this)
{
  boost::mutex *p_bufferedCommandsMutex; // rsi
  unsigned __int64 read; // r9
  unsigned __int8 *buffer; // r10
  unsigned __int64 v5; // rax
  void *v6; // rcx
  unsigned __int64 itemCapacity; // r8
  volatile signed __int32 *v8; // rdi
  signed __int32 v9; // eax
  HANDLE event; // rax
  unsigned int head; // eax
  unsigned int allocation_size; // ecx
  unsigned int v13; // eax
  RakNet::RakPeer::BufferedCommandStruct **array; // rsi
  __int64 v15; // rax
  DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::MemoryWithPage *v16; // rsi
  char *data; // rcx
  volatile signed __int32 *Rep; // rdi

  if ( FFlag::BufferedCommandsCircular.value ) /*0x1410ba8f2*/
  {
    p_bufferedCommandsMutex = &this->bufferedCommandsMutex; /*0x1410ba8f8*/
    boost::detail::basic_timed_mutex::lock(this: &this->bufferedCommandsMutex); /*0x1410ba902*/
    for ( ; this->bufferedCommandsCircular.itemCount != 0; --this->bufferedCommandsCircular.itemCount ) /*0x1410ba90f*/
    {
      read = this->bufferedCommandsCircular.read; /*0x1410ba920*/
      buffer = this->bufferedCommandsCircular.buffer; /*0x1410ba929*/
      v5 = 160 * (read % this->bufferedCommandsCircular.itemCapacity); /*0x1410ba93e*/
      v6 = *(void **)&buffer[v5 + 104]; /*0x1410ba942*/
      if ( v6 != nullptr && *(_QWORD *)&buffer[v5] == 0 ) /*0x1410ba951*/
      {
        operator delete(ptr: v6); /*0x1410ba953*/
        read = this->bufferedCommandsCircular.read; /*0x1410ba958*/
        buffer = this->bufferedCommandsCircular.buffer; /*0x1410ba95f*/
      }
      itemCapacity = this->bufferedCommandsCircular.itemCapacity; /*0x1410ba966*/
      this->bufferedCommandsCircular.read = (read + 1) % itemCapacity; /*0x1410ba986*/
      v8 = *(volatile signed __int32 **)&buffer[160 * (read % itemCapacity) + 8]; /*0x1410ba98d*/
      if ( v8 != nullptr && _InterlockedExchangeAdd(v8 + 2, 0xFFFFFFFF) == 1 ) /*0x1410ba9a4*/
      {
        (**(void (__fastcall ***)(volatile signed __int32 *))v8)(a1: v8); /*0x1410ba9ac*/
        if ( _InterlockedExchangeAdd(v8 + 3, 0xFFFFFFFF) == 1 ) /*0x1410ba9bb*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 8LL))(a1: v8); /*0x1410ba9c3*/
      }
    }
    v9 = _InterlockedExchangeAdd(&p_bufferedCommandsMutex->active_count, 0x80000000); /*0x1410ba9e0*/
    if ( (v9 & 0x40000000) == 0 /*0x1410ba9fe*/
      && v9 != 0x80000000
      && !_interlockedbittestandset(&p_bufferedCommandsMutex->active_count, 0x1Eu) )
    {
      event = boost::detail::basic_timed_mutex::get_event(this: p_bufferedCommandsMutex); /*0x1410baa07*/
      SetEvent(hEvent: event); /*0x1410baa16*/
    }
  }
  else
  {
    while ( 1 ) /*0x1410baa37*/
    {
      rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedCommands_deprecated.queueMutex.criticalSection); /*0x1410baa37*/
      head = this->bufferedCommands_deprecated.queue.head; /*0x1410baa3c*/
      if ( head == this->bufferedCommands_deprecated.queue.tail ) /*0x1410baa48*/
        break; /*0x1410baa48*/
      allocation_size = this->bufferedCommands_deprecated.queue.allocation_size; /*0x1410baa4e*/
      v13 = head + 1; /*0x1410baa54*/
      array = this->bufferedCommands_deprecated.queue.array; /*0x1410baa56*/
      this->bufferedCommands_deprecated.queue.head = v13; /*0x1410baa5d*/
      if ( v13 == allocation_size ) /*0x1410baa65*/
      {
        this->bufferedCommands_deprecated.queue.head = 0; /*0x1410baa67*/
        v15 = allocation_size - 1; /*0x1410baa6e*/
      }
      else if ( v13 != 0 ) /*0x1410baa75*/
      {
        v15 = v13 - 1; /*0x1410baa7c*/
      }
      else
      {
        v15 = allocation_size - 1; /*0x1410baa77*/
      }
      v16 = (DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::MemoryWithPage *)array[v15]; /*0x1410baa7e*/
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedCommands_deprecated.queueMutex.criticalSection); /*0x1410baa89*/
      if ( v16 == nullptr ) /*0x1410baa91*/
        goto LABEL_31; /*0x1410baa91*/
      data = v16->userMemory.data; /*0x1410baa97*/
      if ( data != nullptr && v16->userMemory.stream._Ptr == nullptr ) /*0x1410baaa3*/
        operator delete(ptr: data); /*0x1410baaa5*/
      Rep = (volatile signed __int32 *)v16->userMemory.stream._Rep; /*0x1410baaaa*/
      if ( Rep != nullptr && _InterlockedExchangeAdd(Rep + 2, 0xFFFFFFFF) == 1 ) /*0x1410baac0*/
      {
        (**(void (__fastcall ***)(volatile signed __int32 *))Rep)(a1: Rep); /*0x1410baac8*/
        if ( _InterlockedExchangeAdd(Rep + 3, 0xFFFFFFFF) == 1 ) /*0x1410baad7*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)Rep + 8LL))(a1: Rep); /*0x1410baadf*/
      }
      rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedCommands_deprecated.memoryPoolMutex.criticalSection); /*0x1410baae9*/
      DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::Release( /*0x1410bab05*/
        this: &this->bufferedCommands_deprecated.memoryPool,
        m: v16,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
        line: 0x1219u);
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedCommands_deprecated.memoryPoolMutex.criticalSection); /*0x1410bab11*/
    }
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedCommands_deprecated.queueMutex.criticalSection); /*0x1410bab22*/
LABEL_31:
    DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::BufferedCommandStruct>::Clear( /*0x1410bab27*/
      this: &this->bufferedCommands_deprecated,
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
      line: 0x121Bu);
  }
}

// Address: 0x1410bab60 | Name: ?ClearBufferedPackets@RakPeer@RakNet@@IEAAXXZ
void __fastcall RakNet::RakPeer::ClearBufferedPackets(RakNet::RakPeer *this)
{
  unsigned int head; // eax
  unsigned int allocation_size; // ecx
  unsigned int v4; // eax
  RakNet::RakPeer::RecvFromStruct **array; // rdx
  __int64 v6; // rax
  DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::MemoryWithPage *v7; // rsi
  unsigned int v8; // eax
  unsigned int v9; // ecx
  unsigned int v10; // eax
  RakNet::DelayTransmitStruct **v11; // rsi
  __int64 v12; // rax
  DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::MemoryWithPage *v13; // rsi
  volatile signed __int32 *Rep; // rcx
  unsigned int i; // ebx
  unsigned int v16; // ecx
  unsigned int tail; // edx
  unsigned int v18; // edx
  unsigned int v19; // r8d
  __int64 v20; // rax
  RakNet::DelayTransmitStruct **v21; // rdx
  RakNet::DelayTransmitStruct **v22; // rax
  volatile signed __int32 *v23; // rcx
  unsigned int v24; // eax
  unsigned int v25; // r8d
  RakNet::DelayTransmitStruct **v26; // rdx
  __int64 v27; // rcx
  DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::MemoryWithPage **v28; // rdx
  unsigned int v29; // eax
  unsigned int v30; // eax
  unsigned int v31; // ecx
  unsigned int v32; // eax
  RakNet::RakPeer::RecvFromStruct **v33; // rdx
  __int64 v34; // rax
  DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::MemoryWithPage *v35; // rsi

  if ( FFlag::CLI52064Experiment2.value )
  {
    if ( !DFFlag::RecvFromLoopMemoryReleaseFix.value ) /*0x1410bab92*/
    {
      while ( 1 ) /*0x1410baba7*/
      {
        rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410baba7*/
        head = this->artificialDelayBufferedPackets.queue.head; /*0x1410babac*/
        if ( head == this->artificialDelayBufferedPackets.queue.tail ) /*0x1410babb8*/
          break; /*0x1410babb8*/
        allocation_size = this->artificialDelayBufferedPackets.queue.allocation_size; /*0x1410babba*/
        v4 = head + 1; /*0x1410babc0*/
        array = this->artificialDelayBufferedPackets.queue.array; /*0x1410babc2*/
        this->artificialDelayBufferedPackets.queue.head = v4; /*0x1410babc9*/
        if ( v4 == allocation_size ) /*0x1410babd1*/
        {
          this->artificialDelayBufferedPackets.queue.head = 0; /*0x1410babd3*/
          v6 = allocation_size - 1; /*0x1410babda*/
        }
        else if ( v4 != 0 ) /*0x1410babe1*/
        {
          v6 = v4 - 1; /*0x1410babe8*/
        }
        else
        {
          v6 = allocation_size - 1; /*0x1410babe3*/
        }
        v7 = (DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::MemoryWithPage *)array[v6]; /*0x1410babea*/
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410babf5*/
        if ( v7 == nullptr ) /*0x1410babfd*/
          goto LABEL_12; /*0x1410babfd*/
        rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayBufferedPackets.memoryPoolMutex.criticalSection); /*0x1410bac06*/
        DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::Release( /*0x1410bac22*/
          this: &this->artificialDelayBufferedPackets.memoryPool,
          m: v7,
          file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
          line: 0x1229u);
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayBufferedPackets.memoryPoolMutex.criticalSection); /*0x1410bac2e*/
      }
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410bac3f*/
    }
LABEL_12:
    DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Clear( /*0x1410bac44*/
      this: &this->artificialDelayBufferedPackets,
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
      line: 0x122Cu);
    if ( !DFFlag::RecvFromLoopMemoryReleaseFix.value ) /*0x1410bac64*/
    {
      while ( 1 ) /*0x1410bac77*/
      {
        rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayTransmitPackets.queueMutex.criticalSection); /*0x1410bac77*/
        v8 = this->artificialDelayTransmitPackets.queue.head; /*0x1410bac7c*/
        if ( v8 == this->artificialDelayTransmitPackets.queue.tail ) /*0x1410bac88*/
          break; /*0x1410bac88*/
        v9 = this->artificialDelayTransmitPackets.queue.allocation_size; /*0x1410bac8e*/
        v10 = v8 + 1; /*0x1410bac94*/
        v11 = this->artificialDelayTransmitPackets.queue.array; /*0x1410bac96*/
        this->artificialDelayTransmitPackets.queue.head = v10; /*0x1410bac9d*/
        if ( v10 == v9 ) /*0x1410baca5*/
        {
          this->artificialDelayTransmitPackets.queue.head = 0; /*0x1410baca7*/
          v12 = v9 - 1; /*0x1410bacae*/
        }
        else if ( v10 != 0 ) /*0x1410bacb5*/
        {
          v12 = v10 - 1; /*0x1410bacbc*/
        }
        else
        {
          v12 = v9 - 1; /*0x1410bacb7*/
        }
        v13 = (DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::MemoryWithPage *)v11[v12]; /*0x1410bacbe*/
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayTransmitPackets.queueMutex.criticalSection); /*0x1410bacc9*/
        if ( v13 == nullptr ) /*0x1410bacd1*/
          goto LABEL_25; /*0x1410bacd1*/
        Rep = (volatile signed __int32 *)v13->userMemory.socket._Rep; /*0x1410bacd3*/
        if ( Rep != nullptr && _InterlockedExchangeAdd(Rep + 3, 0xFFFFFFFF) == 1 ) /*0x1410bace9*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)Rep + 8LL))(a1: Rep); /*0x1410bacee*/
        rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayTransmitPackets.memoryPoolMutex.criticalSection); /*0x1410bacf8*/
        DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::Release( /*0x1410bad14*/
          this: &this->artificialDelayTransmitPackets.memoryPool,
          m: v13,
          file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
          line: 0x1234u);
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayTransmitPackets.memoryPoolMutex.criticalSection); /*0x1410bad20*/
      }
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayTransmitPackets.queueMutex.criticalSection); /*0x1410bad31*/
    }
LABEL_25:
    rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayTransmitPackets.memoryPoolMutex.criticalSection); /*0x1410bad36*/
    for ( i = 0; ; ++i )
    {
      v16 = this->artificialDelayTransmitPackets.queue.head; /*0x1410bad50*/
      tail = this->artificialDelayTransmitPackets.queue.tail; /*0x1410bad56*/
      v18 = v16 > tail ? this->artificialDelayTransmitPackets.queue.allocation_size - v16 + tail : tail - v16;
      if ( i >= v18 ) /*0x1410bad70*/
        break; /*0x1410bad70*/
      v19 = this->artificialDelayTransmitPackets.queue.allocation_size; /*0x1410bad76*/
      v20 = v16 + i; /*0x1410bad7d*/
      v21 = this->artificialDelayTransmitPackets.queue.array; /*0x1410bad80*/
      if ( (unsigned int)v20 < v19 ) /*0x1410bad8a*/
        v22 = &v21[v20]; /*0x1410bad97*/
      else
        v22 = &v21[i] + v16 - v19; /*0x1410bad91*/
      v23 = (volatile signed __int32 *)(*v22)->socket._Rep; /*0x1410bad9e*/
      if ( v23 != nullptr && _InterlockedExchangeAdd(v23 + 3, 0xFFFFFFFF) == 1 ) /*0x1410badb4*/
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 8LL))(a1: v23); /*0x1410badb9*/
      v24 = this->artificialDelayTransmitPackets.queue.head; /*0x1410badbc*/
      v25 = this->artificialDelayTransmitPackets.queue.allocation_size; /*0x1410badbf*/
      v26 = this->artificialDelayTransmitPackets.queue.array; /*0x1410badc3*/
      v27 = v24 + i; /*0x1410badc7*/
      if ( (unsigned int)v27 < v25 ) /*0x1410badcd*/
        v28 = (DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::MemoryWithPage **)&v26[v27]; /*0x1410badda*/
      else
        v28 = (DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::MemoryWithPage **)(&v26[i] + v24 - v25); /*0x1410badd4*/
      DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::Release( /*0x1410badf1*/
        this: &this->artificialDelayTransmitPackets.memoryPool,
        m: *v28,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
        line: 0x1237u);
    }
    v29 = this->artificialDelayTransmitPackets.queue.allocation_size; /*0x1410badfd*/
    if ( v29 != 0 ) /*0x1410bae05*/
    {
      if ( v29 > 0x20 ) /*0x1410bae0a*/
      {
        operator delete(ptr: this->artificialDelayTransmitPackets.queue.array); /*0x1410bae13*/
        this->artificialDelayTransmitPackets.queue.allocation_size = 0; /*0x1410bae18*/
      }
      *(_QWORD *)&this->artificialDelayTransmitPackets.queue.head = 0; /*0x1410bae1f*/
    }
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayTransmitPackets.memoryPoolMutex.criticalSection); /*0x1410bae2a*/
    rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayTransmitPackets.memoryPoolMutex.criticalSection); /*0x1410bae33*/
    DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410bae48*/
      this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->artificialDelayTransmitPackets,
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
      line: 0x1237u);
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayTransmitPackets.memoryPoolMutex.criticalSection); /*0x1410bae51*/
  }
  else
  {
    if ( !DFFlag::RecvFromLoopMemoryReleaseFix.value ) /*0x1410bae62*/
    {
      while ( 1 ) /*0x1410bae77*/
      {
        rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedPackets.queueMutex.criticalSection); /*0x1410bae77*/
        v30 = this->bufferedPackets.queue.head; /*0x1410bae7c*/
        if ( v30 == this->bufferedPackets.queue.tail ) /*0x1410bae88*/
          break; /*0x1410bae88*/
        v31 = this->bufferedPackets.queue.allocation_size; /*0x1410bae8a*/
        v32 = v30 + 1; /*0x1410bae90*/
        v33 = this->bufferedPackets.queue.array; /*0x1410bae92*/
        this->bufferedPackets.queue.head = v32; /*0x1410bae99*/
        if ( v32 == v31 ) /*0x1410baea1*/
        {
          this->bufferedPackets.queue.head = 0; /*0x1410baea3*/
          v34 = v31 - 1; /*0x1410baeaa*/
        }
        else if ( v32 != 0 ) /*0x1410baeb1*/
        {
          v34 = v32 - 1; /*0x1410baeb8*/
        }
        else
        {
          v34 = v31 - 1; /*0x1410baeb3*/
        }
        v35 = (DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::MemoryWithPage *)v33[v34]; /*0x1410baeba*/
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedPackets.queueMutex.criticalSection); /*0x1410baec5*/
        if ( v35 == nullptr ) /*0x1410baecd*/
          goto LABEL_55; /*0x1410baecd*/
        rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedPackets.memoryPoolMutex.criticalSection); /*0x1410baed6*/
        DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::Release( /*0x1410baef2*/
          this: &this->bufferedPackets.memoryPool,
          m: v35,
          file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
          line: 0x1240u);
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedPackets.memoryPoolMutex.criticalSection); /*0x1410baefe*/
      }
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedPackets.queueMutex.criticalSection); /*0x1410baf0f*/
    }
LABEL_55:
    DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct>::Clear( /*0x1410baf14*/
      this: &this->bufferedPackets,
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
      line: 0x1243u);
  }
}

// Address: 0x1410baf50 | Name: ?ClearRequestedConnectionList@RakPeer@RakNet@@IEAAXXZ
void __fastcall RakNet::RakPeer::ClearRequestedConnectionList(RakNet::RakPeer *this)
{
  unsigned int v2; // r14d
  unsigned int allocation_size; // edi
  RakNet::RakPeer::RequestedConnectionStruct **array; // rsi
  unsigned int head; // edx
  unsigned int tail; // ecx
  unsigned int v7; // ecx
  unsigned int v8; // eax
  unsigned int v9; // ecx
  RakNet::RakPeer::RequestedConnectionStruct **v10; // rdx
  __int64 v11; // rax
  RakNet::RakPeer::RequestedConnectionStruct *v12; // rbx
  unsigned int v13; // ecx
  unsigned int v14; // ecx
  signed int v15; // ebx
  RakNet::RakPeer::RequestedConnectionStruct **v16; // rax
  RakNet::RakPeer::RequestedConnectionStruct **v17; // r12
  unsigned int v18; // r8d
  RakNet::RakPeer::RequestedConnectionStruct **v19; // r9
  __int64 v20; // rax
  RakNet::RakPeer::RequestedConnectionStruct *v21; // r15
  volatile signed __int32 *Rep; // rbx
  volatile signed __int32 *v23; // rbx
  DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *> freeQueue; // [rsp+20h] [rbp-20h] BYREF

  if ( DFLog::RakNetConnectTrace != 0 )
    FLog::FastLogFormatted(
      level: DFLog::RakNetConnectTrace,
      message: "[DFLog::RakNetConnectTrace] RakNet: Clearing Requested Connection List");
  v2 = 0; /*0x1410baf8b*/
  allocation_size = 0; /*0x1410baf8e*/
  array = nullptr; /*0x1410baf95*/
  memset(&freeQueue, 0, 20); /*0x1410baf98*/
  __wind
  {
    rtc::CriticalSection::Enter(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410bafae*/
    while ( 1 )
    {
      while ( 1 )
      {
        head = this->requestedConnectionQueue.head; /*0x1410bafc0*/
        tail = this->requestedConnectionQueue.tail; /*0x1410bafc7*/
        if ( head > tail ) /*0x1410bafd0*/
          v7 = this->requestedConnectionQueue.allocation_size - head + tail; /*0x1410bafdf*/
        else
          v7 = tail - head; /*0x1410bafd2*/
        if ( v7 == 0 ) /*0x1410bafe3*/
        {
          RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410bb0ee*/
          while ( v2 < freeQueue.tail ) /*0x1410bb0f7*/
          {
            if ( v2 < allocation_size ) /*0x1410bb100*/
              v20 = v2; /*0x1410bb109*/
            else
              v20 = v2 - allocation_size; /*0x1410bb105*/
            v21 = array[v20]; /*0x1410bb110*/
            if ( v21 != nullptr ) /*0x1410bb116*/
            {
              Rep = (volatile signed __int32 *)v21->rbxSessionCrypto._Rep; /*0x1410bb11c*/
              if ( Rep != nullptr ) /*0x1410bb126*/
              {
                if ( _InterlockedExchangeAdd(Rep + 2, 0xFFFFFFFF) == 1 ) /*0x1410bb133*/
                {
                  (**(void (__fastcall ***)(volatile signed __int32 *))Rep)(a1: Rep); /*0x1410bb13b*/
                  if ( _InterlockedExchangeAdd(Rep + 3, 0xFFFFFFFF) == 1 ) /*0x1410bb148*/
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)Rep + 8LL))(a1: Rep); /*0x1410bb150*/
                }
                array = freeQueue.array; /*0x1410bb153*/
                allocation_size = freeQueue.allocation_size; /*0x1410bb157*/
              }
              v23 = (volatile signed __int32 *)v21->socket._Rep; /*0x1410bb15a*/
              if ( v23 != nullptr ) /*0x1410bb164*/
              {
                if ( _InterlockedExchangeAdd(v23 + 2, 0xFFFFFFFF) == 1 ) /*0x1410bb171*/
                {
                  (**(void (__fastcall ***)(volatile signed __int32 *))v23)(a1: v23); /*0x1410bb179*/
                  if ( _InterlockedExchangeAdd(v23 + 3, 0xFFFFFFFF) == 1 ) /*0x1410bb186*/
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 8LL))(a1: v23); /*0x1410bb18e*/
                }
                array = freeQueue.array; /*0x1410bb191*/
                allocation_size = freeQueue.allocation_size; /*0x1410bb195*/
              }
              operator delete(ptr: v21); /*0x1410bb1a0*/
            }
            ++v2; /*0x1410bb1a5*/
          }
          goto LABEL_44; /*0x1410bb0f7*/
        }
        v8 = head + 1; /*0x1410bafe9*/
        this->requestedConnectionQueue.head = head + 1; /*0x1410bafec*/
        v9 = this->requestedConnectionQueue.allocation_size; /*0x1410baff3*/
        v10 = this->requestedConnectionQueue.array; /*0x1410baffa*/
        if ( v8 == v9 )
        {
          this->requestedConnectionQueue.head = 0; /*0x1410bb005*/
          v11 = v9 - 1; /*0x1410bb00c*/
        }
        else
        {
          v11 = v8 != 0 ? v8 - 1 : v9 - 1;
        }
        v12 = v10[v11]; /*0x1410bb01c*/
        if ( allocation_size != 0 ) /*0x1410bb022*/
          break; /*0x1410bb022*/
        array = (RakNet::RakPeer::RequestedConnectionStruct **)operator new(size: 0x80u); /*0x1410bb02e*/
        freeQueue.array = array; /*0x1410bb031*/
        freeQueue.head = 0; /*0x1410bb035*/
        freeQueue.tail = 1; /*0x1410bb039*/
        *array = v12; /*0x1410bb040*/
        allocation_size = 16; /*0x1410bb043*/
        freeQueue.allocation_size = 16; /*0x1410bb048*/
      }
      v13 = freeQueue.tail; /*0x1410bb050*/
      array[freeQueue.tail] = v12; /*0x1410bb053*/
      v14 = v13 + 1; /*0x1410bb057*/
      freeQueue.tail = v14; /*0x1410bb059*/
      if ( v14 == allocation_size ) /*0x1410bb05e*/
        break; /*0x1410bb05e*/
      if ( v14 == 0 ) /*0x1410bb068*/
      {
LABEL_18:
        v15 = 2 * allocation_size; /*0x1410bb06e*/
        if ( 2 * allocation_size != 0 ) /*0x1410bb073*/
        {
          v16 = (RakNet::RakPeer::RequestedConnectionStruct **)operator new(size: saturated_mul(v15, 8u)); /*0x1410bb08b*/
          v17 = v16; /*0x1410bb090*/
          if ( v16 != nullptr ) /*0x1410bb096*/
          {
            v18 = 0; /*0x1410bb09c*/
            v19 = v16; /*0x1410bb0a3*/
            do /*0x1410bb0c8*/
            {
              *v19 = array[v18 % allocation_size]; /*0x1410bb0bb*/
              ++v18; /*0x1410bb0be*/
              ++v19; /*0x1410bb0c1*/
            }
            while ( v18 < allocation_size ); /*0x1410bb0c8*/
            freeQueue.head = 0; /*0x1410bb0ca*/
            freeQueue.tail = allocation_size; /*0x1410bb0ce*/
            allocation_size *= 2; /*0x1410bb0d1*/
            freeQueue.allocation_size = v15; /*0x1410bb0d3*/
            operator delete(ptr: array); /*0x1410bb0d9*/
            array = v17; /*0x1410bb0de*/
            freeQueue.array = v17; /*0x1410bb0e1*/
          }
        }
      }
    }
    freeQueue.tail = 0; /*0x1410bb060*/
    goto LABEL_18; /*0x1410bb064*/
  }
  __unwind
  {
    DataStructures::Queue<RakNet::RakPeer::SocketQueryOutput *>::~Queue<RakNet::RakPeer::SocketQueryOutput *>(this: (DataStructures::Queue<bool> *)&freeQueue); /*0xf1c0000000000008*/
  }
LABEL_44:
  if ( allocation_size != 0 ) /*0x1410bb1af*/
    operator delete(ptr: array); /*0x1410bb1b4*/
}

// Address: 0x1410bb1e0 | Name: ?CloseConnection@RakPeer@RakNet@@UEAAXUAddressOrGUID@2@_NEW4PacketPriority@@@Z
void __fastcall RakNet::RakPeer::CloseConnection(
        RakNet::RakPeer *this,
        const RakNet::AddressOrGUID *target,
        bool sendDisconnectionNotification,
        unsigned __int8 orderingChannel,
        PacketPriority disconnectionNotificationPriority)
{
  RakNet::ConnectionState (__fastcall *GetConnectionState)(struct RakNet::RakPeer *, const RakNet::AddressOrGUID *__struct_ptr); // rbx
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v9; // rbx
  __int128 v10; // xmm1
  const RakNet::RakNetGUID *(__fastcall *GetGuidFromSystemAddress)(struct RakNet::RakPeer *, const RakNet::SystemAddress *__struct_ptr); // r8
  const RakNet::AddressOrGUID *v12; // rcx
  RakNet::RakPeer_vtbl *v13; // rax
  const RakNet::SystemAddress *v14; // rax
  __int128 v15; // xmm1
  RakNet::RakPeer_vtbl *v16; // rax
  __int128 v17; // xmm1
  unsigned __int16 v18; // ax
  _QWORD v19[4]; // [rsp+30h] [rbp-78h] BYREF
  __int128 v20; // [rsp+50h] [rbp-58h] BYREF
  __int128 v21; // [rsp+60h] [rbp-48h]
  RakNet::RakNetGUID rakNetGuid; // [rsp+70h] [rbp-38h] BYREF
  RakNet::SystemAddress v23; // [rsp+80h] [rbp-28h] BYREF

  RakNet::RakPeer::CloseConnectionInternal( /*0x1410bb210*/
    this,
    systemIdentifier: target,
    sendDisconnectionNotification,
    performImmediate: false,
    orderingChannel,
    disconnectionNotificationPriority);
  if ( !sendDisconnectionNotification ) /*0x1410bb217*/
  {
    GetConnectionState = this->GetConnectionState; /*0x1410bb22d*/
    RakNet::RakNetGUID::RakNetGUID(this: &rakNetGuid); /*0x1410bb234*/
    RakNet::SystemAddress::SystemAddress(this: &v23); /*0x1410bb241*/
    rakNetGuid = target->rakNetGuid; /*0x1410bb24d*/
    RakNet::SystemAddress::operator=(this: &v23, input: &target->systemAddress); /*0x1410bb264*/
    if ( GetConnectionState(this, a2: (const RakNet::AddressOrGUID *)&rakNetGuid) == IS_CONNECTED ) /*0x1410bb276*/
    {
      if ( FLog::Network != 0 ) /*0x1410bb285*/
        FLog::FastLog(level: FLog::Network, message: "[FLog::Network] Closing connection internally", arg0: nullptr); /*0x1410bb291*/
      v9 = RakNet::RakPeer::AllocPacket( /*0x1410bb2b7*/
             this,
             dataSize: 1u,
             file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
             line: 0x828u);
      *v9->userMemory.data = 22; /*0x1410bb2be*/
      if ( StudioResourceId::operator==(lhs: target, rhs: &RakNet::UNASSIGNED_RAKNET_GUID_30) ) /*0x1410bb2c4*/
      {
        v10 = *((_OWORD *)&target->systemAddress.address.addr4 + 1); /*0x1410bb2da*/
        GetGuidFromSystemAddress = this->GetGuidFromSystemAddress; /*0x1410bb2df*/
        *(_OWORD *)v19 = *(_OWORD *)&target->systemAddress.address.addr6.sin6_family; /*0x1410bb2e9*/
        *(_OWORD *)&v19[2] = v10; /*0x1410bb2ee*/
        v12 = (const RakNet::AddressOrGUID *)GetGuidFromSystemAddress(this, a2: (const RakNet::SystemAddress *)v19); /*0x1410bb2f6*/
      }
      else
      {
        v12 = target; /*0x1410bb2fb*/
      }
      v9->userMemory.guid.g = v12->rakNetGuid.g; /*0x1410bb308*/
      v9->userMemory.guid.systemIndex = v12->rakNetGuid.systemIndex; /*0x1410bb314*/
      if ( RakNet::SystemAddress::operator==(this: &target->systemAddress, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bb31f*/
      {
        v13 = this->__vftable; /*0x1410bb325*/
        *(RakNet::RakNetGUID *)v19 = target->rakNetGuid; /*0x1410bb335*/
        v14 = v13->GetSystemAddressFromGuid( /*0x1410bb33a*/
                this,
                result: (RakNet::SystemAddress *)&rakNetGuid,
                a3: (const RakNet::RakNetGUID *)v19);
      }
      else
      {
        v14 = (const RakNet::SystemAddress *)&v20; /*0x1410bb347*/
        v15 = *((_OWORD *)&target->systemAddress.address.addr4 + 1); /*0x1410bb34c*/
        v20 = *(_OWORD *)&target->systemAddress.address.addr6.sin6_family; /*0x1410bb351*/
        v21 = v15; /*0x1410bb356*/
      }
      RakNet::SystemAddress::operator=(this: &v9->userMemory.systemAddress, input: v14); /*0x1410bb361*/
      v16 = this->__vftable; /*0x1410bb369*/
      v17 = *((_OWORD *)&v9->userMemory.systemAddress.address.addr4 + 1); /*0x1410bb371*/
      v20 = *(_OWORD *)&v9->userMemory.systemAddress.address.addr6.sin6_family; /*0x1410bb378*/
      v21 = v17; /*0x1410bb37d*/
      v18 = v16->GetIndexFromSystemAddress(this, a2: (const RakNet::SystemAddress *)&v20); /*0x1410bb382*/
      v9->userMemory.wasGeneratedLocally = true; /*0x1410bb38b*/
      v9->userMemory.systemAddress.systemIndex = v18; /*0x1410bb392*/
      v9->userMemory.guid.systemIndex = v18; /*0x1410bb396*/
      RakNet::RakPeer::AddPacketToProducer(this, p: (RakNet::InternalPacket *)v9); /*0x1410bb39a*/
    }
  }
}

// Address: 0x1410bb3c0 | Name: ?CloseConnectionInternal@RakPeer@RakNet@@IEAAXAEBUAddressOrGUID@2@_N1EW4PacketPriority@@@Z
void __fastcall RakNet::RakPeer::CloseConnectionInternal(
        RakNet::RakPeer *this,
        const RakNet::AddressOrGUID *systemIdentifier,
        bool sendDisconnectionNotification,
        bool performImmediate,
        unsigned __int8 orderingChannel,
        PacketPriority disconnectionNotificationPriority)
{
  RakNet::SystemAddress *p_systemAddress; // rdx
  RakNet::RakPeer_vtbl *v11; // rax
  unsigned int RemoteSystemIndex; // eax
  __int64 v13; // r15
  RakNet::RakPeer::RemoteSystemStruct *remoteSystemList; // rcx
  std::_Ref_count_base *Rep; // rax
  int v16; // edi
  bool v17; // zf
  unsigned int Value; // eax
  __int64 v19; // r14
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker> > > > *Myfirst; // rax
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *Ptr; // rdi
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *v22; // rsi
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker> > > > *v23; // rcx
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *v24; // rax
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *Myhead; // rax
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *Next; // rdx
  RakNet::RakPeer::BufferedCommandStruct *v27; // rax
  std::_Ref_count_base *v28; // rbx
  DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::BufferedCommandStruct> *p_bufferedCommands_deprecated; // rdi
  RakNet::RakPeer::BufferedCommandStruct *v30; // rbx
  RakNet::SystemAddress target; // [rsp+40h] [rbp-C0h] BYREF
  std::shared_ptr<RakNet::RakNetSocket> rakNetSocket; // [rsp+60h] [rbp-A0h] BYREF
  RakNet::RakNetGUID rakNetGuid; // [rsp+70h] [rbp-90h] BYREF
  RakNet::SystemAddress v34; // [rsp+80h] [rbp-80h] BYREF
  RakNet::RakPeer::BufferedCommandStruct bcs; // [rsp+A0h] [rbp-60h] BYREF
  RakNet::SystemAddress v36; // [rsp+140h] [rbp+40h] BYREF
  RakNet::RakPeer::BufferedCommandStruct v37; // [rsp+160h] [rbp+60h] BYREF
  char peerAddress[1040]; // [rsp+200h] [rbp+100h] BYREF

  if ( (!StudioResourceId::operator==(lhs: systemIdentifier, rhs: &RakNet::UNASSIGNED_RAKNET_GUID_30)
     || RakNet::SystemAddress::operator==(
          this: &systemIdentifier->systemAddress,
          right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0)
    && this->remoteSystemList != nullptr
    && !this->endThreads._Storage._Value )
  {
    RakNet::SystemAddress::SystemAddress(this: &target); /*0x1410bb43a*/
    if ( RakNet::SystemAddress::operator!=( /*0x1410bb451*/
           this: &systemIdentifier->systemAddress,
           right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 )
    {
      p_systemAddress = &systemIdentifier->systemAddress; /*0x1410bb453*/
    }
    else
    {
      v11 = this->__vftable; /*0x1410bb459*/
      rakNetGuid = systemIdentifier->rakNetGuid; /*0x1410bb460*/
      p_systemAddress = v11->GetSystemAddressFromGuid(this, result: &v36, a3: &rakNetGuid); /*0x1410bb477*/
    }
    RakNet::SystemAddress::operator=(this: &target, input: p_systemAddress); /*0x1410bb47f*/
    if ( RakNet::SystemAddress::operator!=(this: &target, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 /*0x1410bb49c*/
      && performImmediate )
    {
      RakNet::SystemAddress::FixForIPVersion( /*0x1410bb4b1*/
        this: &target,
        boundAddressToSocket: &this->socketList.listArray->_Ptr->boundAddress);
    }
    if ( sendDisconnectionNotification )
    {
      v34 = target; /*0x1410bb4c0*/
      RakNet::RakPeer::NotifyAndFlagForShutdown( /*0x1410bb4f5*/
        this,
        systemAddress: &v34,
        performImmediate,
        orderingChannel,
        disconnectionNotificationPriority,
        file: nullptr,
        line: 0);
    }
    else if ( performImmediate )
    {
      RakNet::AddressOrGUID::ToStringN(this: systemIdentifier, writePort: true, dest: peerAddress, size: 1025); /*0x1410bb51a*/
      if ( DFLog::NetworkAudit != 0 )
        FLog::FastLog(
          level: DFLog::NetworkAudit,
          message: "[DFLog::NetworkAudit] RakNet Disconnect: Closing connection to %s",
          arg0: peerAddress);
      RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, sa: &target); /*0x1410bb545*/
      if ( RemoteSystemIndex != -1 ) /*0x1410bb54d*/
      {
        v13 = RemoteSystemIndex; /*0x1410bb555*/
        if ( this->remoteSystemList[v13].isActive._Storage._Value ) /*0x1410bb563*/
        {
          if ( FFlag::CLI52064Experiment2.value ) /*0x1410bb578*/
          {
            remoteSystemList = this->remoteSystemList; /*0x1410bb57a*/
            rakNetSocket = 0; /*0x1410bb584*/
            Rep = remoteSystemList[v13].rakNetSocket._Rep; /*0x1410bb58a*/
            if ( Rep != nullptr ) /*0x1410bb595*/
              _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410bb597*/
            rakNetSocket = remoteSystemList[v13].rakNetSocket; /*0x1410bb5a3*/
            RakNet::RakPeer::FlushArtificialLatencyTransmitPacketsForSocket(this, socketToFlush: &rakNetSocket); /*0x1410bb5bd*/
          }
          v16 = 0; /*0x1410bb5c4*/
          if ( this->activeSystemListSize._Storage._Value != 0 ) /*0x1410bb5cf*/
          {
            while ( 1 ) /*0x1410bb5ed*/
            {
              v17 = RakNet::SystemAddress::operator==(this: &this->activeSystemList[v16]->systemAddress, right: &target) == 0; /*0x1410bb5ed*/
              Value = this->activeSystemListSize._Storage._Value; /*0x1410bb5ef*/
              if ( !v17 ) /*0x1410bb5f5*/
                break; /*0x1410bb5f5*/
              if ( ++v16 >= Value ) /*0x1410bb5fc*/
                goto LABEL_27; /*0x1410bb5fc*/
            }
            this->activeSystemList[v16] = this->activeSystemList[Value - 1]; /*0x1410bb615*/
            _InterlockedDecrement((volatile signed __int32 *)&this->activeSystemListSize); /*0x1410bb619*/
          }
LABEL_27:
          this->remoteSystemList[v13].isActive._Storage._Value = false; /*0x1410bb620*/
          this->remoteSystemList[v13].guid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410bb639*/
          if ( DFFlag::CLI56775.value ) /*0x1410bb658*/
          {
            rtc::CriticalSection::Enter(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410bb665*/
            v19 = RakNet::SystemAddress::ToInteger(sa: &target); /*0x1410bb674*/
            Myfirst = this->bytesInReturnQueue._Vec._Mypair._Myval2._Myfirst; /*0x1410bb683*/
            Ptr = Myfirst[2 * (this->bytesInReturnQueue._Mask & v19) + 1]._Ptr; /*0x1410bb68a*/
            if ( Ptr != this->bytesInReturnQueue._List._Mypair._Myval2._Myhead ) /*0x1410bb696*/
            {
              v22 = Myfirst[2 * (this->bytesInReturnQueue._Mask & v19)]._Ptr; /*0x1410bb69c*/
              if ( RakNet::SystemAddress::operator==(this: &target, right: &Ptr->_Myval.first) != 0 ) /*0x1410bb6b0*/
              {
LABEL_32:
                if ( Ptr != nullptr ) /*0x1410bb6d4*/
                {
                  v23 = &this->bytesInReturnQueue._Vec._Mypair._Myval2._Myfirst[2 /*0x1410bb6e8*/
                                                                              * (this->bytesInReturnQueue._Mask & v19)];
                  v24 = v23->_Ptr; /*0x1410bb6eb*/
                  if ( v23[1]._Ptr == Ptr ) /*0x1410bb6f2*/
                  {
                    if ( v24 == Ptr ) /*0x1410bb6f7*/
                    {
                      Myhead = this->bytesInReturnQueue._List._Mypair._Myval2._Myhead; /*0x1410bb6f9*/
                      v23->_Ptr = Myhead; /*0x1410bb700*/
                    }
                    else
                    {
                      Myhead = Ptr->_Prev; /*0x1410bb709*/
                    }
                    v23[1]._Ptr = Myhead; /*0x1410bb703*/
                  }
                  else if ( v24 == Ptr ) /*0x1410bb716*/
                  {
                    v23->_Ptr = Ptr->_Next; /*0x1410bb71b*/
                  }
                  Next = Ptr->_Next; /*0x1410bb71e*/
                  --this->bytesInReturnQueue._List._Mypair._Myval2._Mysize; /*0x1410bb721*/
                  Ptr->_Prev->_Next = Next; /*0x1410bb72c*/
                  Next->_Prev = Ptr->_Prev; /*0x1410bb733*/
                  operator delete(ptr: Ptr); /*0x1410bb73f*/
                }
              }
              else
              {
                while ( Ptr != v22 ) /*0x1410bb6b5*/
                {
                  Ptr = Ptr->_Prev; /*0x1410bb6bb*/
                  if ( RakNet::SystemAddress::operator==(this: &target, right: &Ptr->_Myval.first) != 0 ) /*0x1410bb6cf*/
                    goto LABEL_32; /*0x1410bb6cf*/
                }
              }
            }
            RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410bb74b*/
          }
          RakNet::ReliabilityLayer::Reset( /*0x1410bb76e*/
            this: (RakNet::ReliabilityLayer *)((char *)&this->remoteSystemList->reliabilityLayer.rbxSessionCrypto._Ptr
                                       + v13 * 4600
                                       + 4),
            resetVariables: false,
            MTUSize: this->remoteSystemList[v13].MTUSize,
            _useSecurity: false);
          std::shared_ptr<SDLGameController_2_0_16>::reset(this: (std::shared_ptr<RBX::Graphics::FramebufferVulkan> *)&this->remoteSystemList[v13].rakNetSocket); /*0x1410bb784*/
        }
      }
    }
    else if ( FFlag::BufferedCommandsCircular.value ) /*0x1410bb795*/
    {
      bcs.stream = 0; /*0x1410bb79e*/
      __wind /*0xf1c0000000000010*/
      {
        RakNet::RakNetGUID::RakNetGUID(this: &bcs.systemIdentifier.rakNetGuid); /*0x1410bb7a7*/
        RakNet::SystemAddress::SystemAddress(this: &bcs.systemIdentifier.systemAddress); /*0x1410bb7b0*/
        bcs.data = nullptr; /*0x1410bb7b7*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&bcs); /*0xf1c0000000000020*/
      }
      __wind /*0xf1c0000000000028*/
      {
        bcs.command = BCS_CLOSE_CONNECTION; /*0x1410bb7bb*/
        bcs.systemIdentifier.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410bb7c9*/
        RakNet::SystemAddress::operator=(this: &bcs.systemIdentifier.systemAddress, input: &target); /*0x1410bb7e1*/
        bcs.data = nullptr; /*0x1410bb7e6*/
        bcs.orderingChannel = orderingChannel; /*0x1410bb7f1*/
        bcs.priority = disconnectionNotificationPriority; /*0x1410bb7fa*/
        boost::detail::basic_timed_mutex::lock(this: &this->bufferedCommandsMutex); /*0x1410bb804*/
        v27 = RakNet::RakPeer::BufferedCommandStruct::BufferedCommandStruct(this: &v37, __that: &bcs); /*0x1410bb811*/
        RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::push_back( /*0x1410bb820*/
          this: &this->bufferedCommandsCircular,
          item: v27);
        boost::detail::basic_timed_mutex::unlock(this: &this->bufferedCommandsMutex); /*0x1410bb82c*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&bcs); /*0xf1c0000000000008*/
      }
      v28 = bcs.stream._Rep; /*0x1410bb832*/
      if ( bcs.stream._Rep != nullptr /*0x1410bb84e*/
        && _InterlockedExchangeAdd((volatile signed __int32 *)&bcs.stream._Rep->_Uses, 0xFFFFFFFF) == 1 )
      {
        v28->_Destroy(this: v28); /*0x1410bb85a*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v28->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410bb864*/
          v28->_Delete_this(this: v28); /*0x1410bb870*/
      }
    }
    else
    {
      p_bufferedCommands_deprecated = &this->bufferedCommands_deprecated; /*0x1410bb878*/
      v30 = DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::BufferedCommandStruct>::Allocate( /*0x1410bb894*/
              this: &this->bufferedCommands_deprecated,
              file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
              line: 0x10E8u);
      v30->command = BCS_CLOSE_CONNECTION; /*0x1410bb897*/
      v30->systemIdentifier.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410bb8a8*/
      RakNet::SystemAddress::operator=(this: &v30->systemIdentifier.systemAddress, input: &target); /*0x1410bb8c0*/
      v30->data = nullptr; /*0x1410bb8c7*/
      v30->orderingChannel = orderingChannel; /*0x1410bb8d2*/
      v30->priority = disconnectionNotificationPriority; /*0x1410bb8db*/
      DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::BufferedCommandStruct>::Push( /*0x1410bb8e4*/
        this: (DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput> *)p_bufferedCommands_deprecated,
        s: (RakNet::RakPeer::SocketQueryOutput *)v30);
    }
  }
}

// Address: 0x1410bb910 | Name: ?Connect@RakPeer@RakNet@@UEAA?AW4ConnectionAttemptResult@2@PEBDG0HPEAUPublicKey@2@IIII@Z
RakNet::ConnectionAttemptResult __fastcall RakNet::RakPeer::Connect(
        RakNet::RakPeer *this,
        const char *host,
        unsigned __int16 remotePort,
        const char *passwordData,
        int passwordDataLength,
        RakNet::PublicKey *publicKey,
        unsigned int connectionSocketIndex,
        unsigned int sendConnectionAttemptCount,
        unsigned int timeBetweenSendConnectionAttemptsMS,
        unsigned int timeoutTime)
{
  unsigned int list_size; // r10d
  unsigned int v15; // ebx
  std::shared_ptr<RakNet::RakNetSocket> *listArray; // rcx
  int v17; // ecx
  int v18; // esi

  if ( host == nullptr ) /*0x1410bb92e*/
    return 1; /*0x1410bb92e*/
  if ( this->endThreads._Storage._Value ) /*0x1410bb934*/
    return 1; /*0x1410bb93b*/
  list_size = this->socketList.list_size; /*0x1410bb941*/
  if ( connectionSocketIndex >= list_size ) /*0x1410bb953*/
    return 1; /*0x1410bba51*/
  v15 = 0; /*0x1410bb95d*/
  if ( list_size != 0 ) /*0x1410bb96e*/
  {
    listArray = this->socketList.listArray; /*0x1410bb970*/
    while ( listArray[v15]._Ptr->userConnectionSocketIndex != connectionSocketIndex ) /*0x1410bb98d*/
    {
      if ( ++v15 >= list_size ) /*0x1410bb994*/
        goto LABEL_8; /*0x1410bb994*/
    }
  }
  else
  {
LABEL_8:
    v15 = -1; /*0x1410bb996*/
  }
  v17 = 255; /*0x1410bb9a2*/
  if ( passwordDataLength <= 255 ) /*0x1410bb9b5*/
    v17 = passwordDataLength; /*0x1410bb9b5*/
  v18 = 0; /*0x1410bb9bd*/
  if ( passwordData != nullptr ) /*0x1410bb9ca*/
    v18 = v17; /*0x1410bb9ca*/
  if ( DFLog::RakNetConnectTrace != 0 )
    FLog::FastLogFormatted(
      level: DFLog::RakNetConnectTrace,
      message: "[DFLog::RakNetConnectTrace] RakNet: Connect requested with attempt count %u , time between attempts %u",
      sendConnectionAttemptCount,
      timeBetweenSendConnectionAttemptsMS);
  return RakNet::RakPeer::SendConnectionRequest( /*0x1410bba45*/
           this,
           host,
           remotePort,
           passwordData,
           passwordDataLength: v18,
           publicKey,
           connectionSocketIndex: v15,
           extraData: 0,
           sendConnectionAttemptCount,
           timeBetweenSendConnectionAttemptsMS,
           timeoutTime);
}

// Address: 0x1410bba70 | Name: ?DeallocatePacket@RakPeer@RakNet@@UEAAXPEAUPacket@2@@Z
void __fastcall RakNet::RakPeer::DeallocatePacket(
        RakNet::RakPeer *this,
        DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *packet)
{
  DataStructures::MemoryPool<RakNet::Packet>::Page *parentPage; // rbx
  __int64 availableStackSize; // rax
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage **availableStack; // rcx
  DataStructures::MemoryPool<RakNet::Packet>::Page *unavailablePages; // rax
  int availablePagesSize; // ecx

  if ( packet != nullptr ) /*0x1410bba73*/
  {
    if ( packet->userMemory.deleteData ) /*0x1410bba83*/
    {
      operator delete(ptr: packet->userMemory.data); /*0x1410bbaa1*/
      rtc::CriticalSection::Enter(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410bbaad*/
      parentPage = packet->parentPage; /*0x1410bbab2*/
      availableStackSize = parentPage->availableStackSize; /*0x1410bbab6*/
      availableStack = parentPage->availableStack; /*0x1410bbaba*/
      if ( (_DWORD)availableStackSize != 0 ) /*0x1410bbabf*/
      {
        availableStack[availableStackSize] = packet; /*0x1410bbb66*/
        if ( ++parentPage->availableStackSize == (unsigned int)(this->packetAllocationPool.memoryPoolPageSize / 0x68uLL) /*0x1410bbb91*/
          && this->packetAllocationPool.availablePagesSize >= 4 )
        {
          if ( parentPage == this->packetAllocationPool.availablePages ) /*0x1410bbb9a*/
            this->packetAllocationPool.availablePages = parentPage->next; /*0x1410bbba0*/
          parentPage->prev->next = parentPage->next; /*0x1410bbbaf*/
          parentPage->next->prev = parentPage->prev; /*0x1410bbbbb*/
          --this->packetAllocationPool.availablePagesSize; /*0x1410bbbbf*/
          operator delete(ptr: parentPage->availableStack); /*0x1410bbbc8*/
          operator delete(ptr: parentPage->block); /*0x1410bbbd1*/
          operator delete(ptr: parentPage); /*0x1410bbbd9*/
        }
      }
      else
      {
        *availableStack = packet; /*0x1410bbac5*/
        ++parentPage->availableStackSize; /*0x1410bbac8*/
        --this->packetAllocationPool.unavailablePagesSize; /*0x1410bbacb*/
        parentPage->next->prev = parentPage->prev; /*0x1410bbad9*/
        parentPage->prev->next = parentPage->next; /*0x1410bbae5*/
        if ( this->packetAllocationPool.unavailablePagesSize > 0 ) /*0x1410bbaf0*/
        {
          unavailablePages = this->packetAllocationPool.unavailablePages; /*0x1410bbaf2*/
          if ( parentPage == unavailablePages ) /*0x1410bbafc*/
            this->packetAllocationPool.unavailablePages = unavailablePages->next; /*0x1410bbb02*/
        }
        availablePagesSize = this->packetAllocationPool.availablePagesSize; /*0x1410bbb09*/
        this->packetAllocationPool.availablePagesSize = availablePagesSize + 1; /*0x1410bbb12*/
        if ( availablePagesSize != 0 ) /*0x1410bbb1a*/
        {
          parentPage->next = this->packetAllocationPool.availablePages; /*0x1410bbb37*/
          parentPage->prev = this->packetAllocationPool.availablePages->prev; /*0x1410bbb46*/
          this->packetAllocationPool.availablePages->prev->next = parentPage; /*0x1410bbb55*/
          this->packetAllocationPool.availablePages->prev = parentPage; /*0x1410bbb60*/
        }
        else
        {
          this->packetAllocationPool.availablePages = parentPage; /*0x1410bbb1c*/
          parentPage->next = parentPage; /*0x1410bbb23*/
          parentPage->prev = parentPage; /*0x1410bbb27*/
        }
      }
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410bbbf9*/
    }
    else
    {
      operator delete(ptr: packet); /*0x1410bbc01*/
    }
  }
}

// Address: 0x1410bbc20 | Name: ?DerefAllSockets@RakPeer@RakNet@@IEAAXXZ
void __fastcall RakNet::RakPeer::DerefAllSockets(RakNet::RakPeer *this)
{
  unsigned int i; // edi
  std::shared_ptr<RakNet::RakNetSocket> *v3; // rax
  volatile signed __int32 *Rep; // rbx
  std::shared_ptr<RakNet::RakNetSocket> *listArray; // rcx
  std::_Ref_count_base **p_Rep; // rbx
  __int64 v7; // [rsp+0h] [rbp-28h] BYREF

  for ( i = 0; i < this->socketList.list_size; ++i ) /*0x1410bbc41*/
  {
    v3 = &this->socketList.listArray[i]; /*0x1410bbc56*/
    v3->_Ptr = nullptr; /*0x1410bbc5d*/
    Rep = (volatile signed __int32 *)v3->_Rep; /*0x1410bbc60*/
    v3->_Rep = nullptr; /*0x1410bbc64*/
    if ( Rep != nullptr && _InterlockedExchangeAdd(Rep + 2, 0xFFFFFFFF) == 1 ) /*0x1410bbc7a*/
    {
      (**(void (__fastcall ***)(volatile signed __int32 *))Rep)(a1: Rep); /*0x1410bbc82*/
      if ( _InterlockedExchangeAdd(Rep + 3, 0xFFFFFFFF) == 1 ) /*0x1410bbc91*/
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)Rep + 8LL))(a1: Rep); /*0x1410bbc99*/
    }
  }
  if ( this->socketList.allocation_size != 0 ) /*0x1410bbcac*/
  {
    __wind /*0xf1c0000000000020*/
    {
      listArray = this->socketList.listArray; /*0x1410bbcae*/
      if ( listArray != nullptr ) /*0x1410bbcb8*/
      {
        p_Rep = &listArray[-1]._Rep; /*0x1410bbcba*/
        `eh vector destructor iterator'( /*0x1410bbccd*/
          ptr: listArray,
          size: 0x10u,
          count: (unsigned __int64)listArray[-1]._Rep,
          destructor: (void (__fastcall *)(void *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>);
        operator delete(ptr: p_Rep); /*0x1410bbce0*/
      }
      *(_QWORD *)&this->socketList.list_size = 0; /*0x1410bbce6*/
      this->socketList.listArray = nullptr; /*0x1410bbced*/
    }
    __unwind
    {
      __std_terminate(a1: listArray, a2: &v7); /*0x142f39fa8*/
    }
  }
}

// Address: 0x1410bbd10 | Name: ?DereferenceRemoteSystem@RakPeer@RakNet@@IEAAXAEBUSystemAddress@2@@Z
void __fastcall RakNet::RakPeer::DereferenceRemoteSystem(RakNet::RakPeer *this, const RakNet::SystemAddress *sa)
{
  RakNet::RemoteSystemIndex *v4; // rbp
  __int64 v5; // r15
  RakNet::RemoteSystemIndex *v6; // rsi
  RakNet::RemoteSystemIndex *next; // rax
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Page *v8; // rbx
  __int64 availableStackSize; // rax
  _QWORD *availableStack; // rcx
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Page *unavailablePages; // rax
  int availablePagesSize; // ecx

  v4 = nullptr; /*0x1410bbd3c*/
  v5 = RakNet::SystemAddress::ToInteger(sa) % (8 * (unsigned int)this->maximumNumberOfPeers); /*0x1410bbd48*/
  v6 = this->remoteSystemLookup[v5]; /*0x1410bbd50*/
  if ( v6 != nullptr ) /*0x1410bbd57*/
  {
    while ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v6->index].systemAddress, right: sa) == 0 ) /*0x1410bbd83*/
    {
      v4 = v6; /*0x1410bbd85*/
      v6 = v6->next; /*0x1410bbd88*/
      if ( v6 == nullptr ) /*0x1410bbd8f*/
        return; /*0x1410bbd8f*/
    }
    next = v6->next; /*0x1410bbd96*/
    if ( v4 != nullptr ) /*0x1410bbd9d*/
      v4->next = next; /*0x1410bbdac*/
    else
      this->remoteSystemLookup[v5] = next; /*0x1410bbda6*/
    v8 = *(DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Page **)&v6[1].index; /*0x1410bbdb0*/
    availableStackSize = v8->availableStackSize; /*0x1410bbdb4*/
    availableStack = v8->availableStack; /*0x1410bbdb8*/
    if ( (_DWORD)availableStackSize != 0 ) /*0x1410bbdbd*/
    {
      availableStack[availableStackSize] = v6; /*0x1410bbe64*/
      if ( ++v8->availableStackSize == (unsigned int)(this->remoteSystemIndexPool.memoryPoolPageSize / 0x18uLL) /*0x1410bbe8f*/
        && this->remoteSystemIndexPool.availablePagesSize >= 4 )
      {
        if ( v8 == this->remoteSystemIndexPool.availablePages ) /*0x1410bbe98*/
          this->remoteSystemIndexPool.availablePages = v8->next; /*0x1410bbe9e*/
        v8->prev->next = v8->next; /*0x1410bbead*/
        v8->next->prev = v8->prev; /*0x1410bbeb9*/
        --this->remoteSystemIndexPool.availablePagesSize; /*0x1410bbebd*/
        operator delete(ptr: v8->availableStack); /*0x1410bbec6*/
        operator delete(ptr: v8->block); /*0x1410bbecf*/
        operator delete(ptr: v8); /*0x1410bbed7*/
      }
    }
    else
    {
      *availableStack = v6; /*0x1410bbdc3*/
      ++v8->availableStackSize; /*0x1410bbdc6*/
      --this->remoteSystemIndexPool.unavailablePagesSize; /*0x1410bbdc9*/
      v8->next->prev = v8->prev; /*0x1410bbdd7*/
      v8->prev->next = v8->next; /*0x1410bbde3*/
      if ( this->remoteSystemIndexPool.unavailablePagesSize > 0 ) /*0x1410bbdee*/
      {
        unavailablePages = this->remoteSystemIndexPool.unavailablePages; /*0x1410bbdf0*/
        if ( v8 == unavailablePages ) /*0x1410bbdfa*/
          this->remoteSystemIndexPool.unavailablePages = unavailablePages->next; /*0x1410bbe00*/
      }
      availablePagesSize = this->remoteSystemIndexPool.availablePagesSize; /*0x1410bbe07*/
      this->remoteSystemIndexPool.availablePagesSize = availablePagesSize + 1; /*0x1410bbe10*/
      if ( availablePagesSize != 0 ) /*0x1410bbe18*/
      {
        v8->next = this->remoteSystemIndexPool.availablePages; /*0x1410bbe35*/
        v8->prev = this->remoteSystemIndexPool.availablePages->prev; /*0x1410bbe44*/
        this->remoteSystemIndexPool.availablePages->prev->next = v8; /*0x1410bbe53*/
        this->remoteSystemIndexPool.availablePages->prev = v8; /*0x1410bbe5e*/
      }
      else
      {
        this->remoteSystemIndexPool.availablePages = v8; /*0x1410bbe1a*/
        v8->next = v8; /*0x1410bbe21*/
        v8->prev = v8; /*0x1410bbe25*/
      }
    }
  }
}

// Address: 0x1410bbf00 | Name: ?FlushArtificialLatencyTransmitPacketsForSocket@RakPeer@RakNet@@IEAAXV?$shared_ptr@URakNetSocket@RakNet@@@std@@@Z
void __fastcall RakNet::RakPeer::FlushArtificialLatencyTransmitPacketsForSocket(
        RakNet::RakPeer *this,
        std::shared_ptr<RBX::File> *socketToFlush)
{
  std::_Container_proxy *v3; // rax
  unsigned int head; // eax
  unsigned int v5; // eax
  unsigned int allocation_size; // ecx
  RakNet::DelayTransmitStruct **array; // rbx
  __int64 v8; // rax
  DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::MemoryWithPage *v9; // rbx
  std::_Ref_count_base *Rep; // rdx
  DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::MemoryWithPage *v11; // r14
  signed __int32 Uses; // eax
  signed __int32 v13; // ett
  RakNet::RakNetSocket *Ptr; // rcx
  std::_Ref_count_base *v15; // rdi
  volatile signed __int32 *v16; // rcx
  unsigned __int64 Myoff; // r8
  unsigned __int64 Mysize; // rdx
  unsigned __int64 Mapsize; // rcx
  char v20; // bl
  unsigned __int64 v21; // rdi
  RakNet::DelayTransmitStruct ***Map; // rax
  unsigned __int64 v23; // rax
  unsigned __int64 i; // rdx
  unsigned __int64 v25; // rbx
  RakNet::DelayTransmitStruct ***v26; // rcx
  RakNet::DelayTransmitStruct ***v27; // rax
  std::_Container_proxy *Myproxy; // rcx
  std::_Ref_count_base *v29; // rbx
  std::shared_ptr<RakNet::RakNetSocket> socket; // [rsp+20h] [rbp-40h] BYREF
  std::queue<RakNet::DelayTransmitStruct *> tempQueue; // [rsp+30h] [rbp-30h] BYREF

  __wind /*0xf1c0000000000050*/
  {
    memset(&tempQueue, 0, sizeof(tempQueue)); /*0x1410bbf2a*/
    v3 = (std::_Container_proxy *)operator new(size: 0x10u); /*0x1410bbf4c*/
    v3->_Myfirstiter = nullptr; /*0x1410bbf51*/
    tempQueue.c._Mypair._Myval2._Myproxy = v3; /*0x1410bbf59*/
    v3->_Mycont = (const std::_Container_base12 *)&tempQueue; /*0x1410bbf61*/
    __wind /*0xf1c0000000000044*/
    {
      while ( 1 ) /*0x1410bbf77*/
      {
        rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayTransmitPackets.queueMutex.criticalSection); /*0x1410bbf77*/
        head = this->artificialDelayTransmitPackets.queue.head; /*0x1410bbf7c*/
        if ( head == this->artificialDelayTransmitPackets.queue.tail ) /*0x1410bbf88*/
          break; /*0x1410bbf88*/
        v5 = head + 1; /*0x1410bbf8e*/
        this->artificialDelayTransmitPackets.queue.head = v5; /*0x1410bbf90*/
        allocation_size = this->artificialDelayTransmitPackets.queue.allocation_size; /*0x1410bbf96*/
        if ( v5 == allocation_size ) /*0x1410bbf9e*/
        {
          this->artificialDelayTransmitPackets.queue.head = 0; /*0x1410bbfa0*/
          array = this->artificialDelayTransmitPackets.queue.array; /*0x1410bbfaa*/
          v8 = allocation_size - 1; /*0x1410bbfb1*/
        }
        else
        {
          array = this->artificialDelayTransmitPackets.queue.array; /*0x1410bbfb6*/
          if ( v5 != 0 ) /*0x1410bbfbf*/
            v8 = v5 - 1; /*0x1410bbfc6*/
          else
            v8 = allocation_size - 1; /*0x1410bbfc1*/
        }
        v9 = (DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::MemoryWithPage *)array[v8]; /*0x1410bbfc8*/
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayTransmitPackets.queueMutex.criticalSection); /*0x1410bbfd3*/
        if ( v9 == nullptr ) /*0x1410bbfdb*/
          goto LABEL_37; /*0x1410bbfdb*/
        socket = 0; /*0x1410bbfe4*/
        Rep = v9->userMemory.socket._Rep; /*0x1410bbfe9*/
        v11 = v9; /*0x1410bbfed*/
        if ( Rep != nullptr && (Uses = Rep->_Uses) != 0 ) /*0x1410bbffa*/
        {
          while ( 1 ) /*0x1410bc003*/
          {
            v13 = Uses; /*0x1410bc003*/
            Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x1410bc003*/
            if ( v13 == Uses ) /*0x1410bc008*/
              break; /*0x1410bc008*/
            if ( Uses == 0 ) /*0x1410bc010*/
              goto LABEL_13; /*0x1410bc010*/
          }
          Ptr = v9->userMemory.socket._Ptr; /*0x1410bc0d6*/
          socket._Ptr = v9->userMemory.socket._Ptr; /*0x1410bc0d9*/
          v15 = v9->userMemory.socket._Rep; /*0x1410bc0dd*/
          socket._Rep = v15; /*0x1410bc0e1*/
        }
        else
        {
LABEL_13:
          Ptr = socket._Ptr; /*0x1410bc012*/
          v15 = socket._Rep; /*0x1410bc016*/
        }
        __eh34_enter_wind_state(1, 2); /*0xf1c000000000003c*/
        if ( Ptr != nullptr && Ptr == (RakNet::RakNetSocket *)socketToFlush->_Ptr ) /*0x1410bc02a*/
        {
          RakNet::SocketLayer::SendToAfterDelay(s: Ptr->s, delayTx: &v9->userMemory); /*0x1410bc036*/
          v16 = (volatile signed __int32 *)v9->userMemory.socket._Rep; /*0x1410bc03b*/
          if ( v16 != nullptr ) /*0x1410bc042*/
          {
            if ( _InterlockedExchangeAdd(v16 + 3, 0xFFFFFFFF) == 1 ) /*0x1410bc04f*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 8LL))(a1: v16); /*0x1410bc054*/
            v15 = socket._Rep; /*0x1410bc057*/
          }
          rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayTransmitPackets.memoryPoolMutex.criticalSection); /*0x1410bc062*/
          DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::Release( /*0x1410bc07e*/
            this: &this->artificialDelayTransmitPackets.memoryPool,
            m: v9,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
            line: 0x14B7u);
          RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayTransmitPackets.memoryPoolMutex.criticalSection); /*0x1410bc08a*/
          if ( __eh34_unwind(2) ) /*0xf1c0000000000030*/
            goto unwind_state_2; /*0xf1c0000000000030*/
          __eh34_exit_wind_state(2, 1); /*0xf1c0000000000034*/
          if ( v15 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v15->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410bc0a4*/
          {
            socket._Rep->_Destroy(this: socket._Rep); /*0x1410bc0b4*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&socket._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410bc0c1*/
              socket._Rep->_Delete_this(this: socket._Rep); /*0x1410bc0ce*/
          }
        }
        else
        {
          if ( __eh34_unwind(2) ) /*0xf1c000000000001c*/
          {
unwind_state_2:
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&socket); /*0xf1c0000000000020*/
            __eh34_continue_unwinding(2, 1); /*0xf1c0000000000024*/
          }
          __eh34_exit_wind_state(2, 1); /*0xf1c0000000000028*/
          if ( v15 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v15->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410bc0fa*/
          {
            socket._Rep->_Destroy(this: socket._Rep); /*0x1410bc106*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&socket._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410bc113*/
              socket._Rep->_Delete_this(this: socket._Rep); /*0x1410bc11c*/
          }
          Myoff = tempQueue.c._Mypair._Myval2._Myoff; /*0x1410bc11f*/
          Mysize = tempQueue.c._Mypair._Myval2._Mysize; /*0x1410bc123*/
          Mapsize = tempQueue.c._Mypair._Myval2._Mapsize; /*0x1410bc12b*/
          if ( ((LOBYTE(tempQueue.c._Mypair._Myval2._Mysize) + LOBYTE(tempQueue.c._Mypair._Myval2._Myoff)) & 1) == 0 /*0x1410bc13d*/
            && tempQueue.c._Mypair._Myval2._Mapsize <= (tempQueue.c._Mypair._Myval2._Mysize + 2) >> 1 )
          {
            std::deque<double>::_Growmap( /*0x1410bc148*/
              this: (std::deque<std::unique_ptr<Luau::detail::Node>> *)&tempQueue,
              _Count: 1u);
            Mysize = tempQueue.c._Mypair._Myval2._Mysize; /*0x1410bc14d*/
            Myoff = tempQueue.c._Mypair._Myval2._Myoff; /*0x1410bc151*/
            Mapsize = tempQueue.c._Mypair._Myval2._Mapsize; /*0x1410bc155*/
          }
          tempQueue.c._Mypair._Myval2._Myoff = (2 * Mapsize - 1) & Myoff; /*0x1410bc164*/
          v20 = LOBYTE(tempQueue.c._Mypair._Myval2._Myoff) + Mysize; /*0x1410bc168*/
          v21 = ((tempQueue.c._Mypair._Myval2._Myoff + Mysize) >> 1) & (Mapsize - 1); /*0x1410bc178*/
          Map = tempQueue.c._Mypair._Myval2._Map; /*0x1410bc180*/
          if ( tempQueue.c._Mypair._Myval2._Map[v21] == nullptr ) /*0x1410bc189*/
          {
            tempQueue.c._Mypair._Myval2._Map[v21] = (RakNet::DelayTransmitStruct **)operator new(size: 0x10u); /*0x1410bc199*/
            Map = tempQueue.c._Mypair._Myval2._Map; /*0x1410bc19d*/
          }
          Map[v21][v20 & 1] = &v11->userMemory; /*0x1410bc1a8*/
          ++tempQueue.c._Mypair._Myval2._Mysize; /*0x1410bc1ac*/
        }
      }
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayTransmitPackets.queueMutex.criticalSection); /*0x1410bc1bc*/
LABEL_37:
      v23 = tempQueue.c._Mypair._Myval2._Mysize; /*0x1410bc1c1*/
      if ( tempQueue.c._Mypair._Myval2._Mysize != 0 ) /*0x1410bc1c8*/
      {
        for ( i = tempQueue.c._Mypair._Myval2._Myoff; ; i = ++tempQueue.c._Mypair._Myval2._Myoff ) /*0x1410bc1ca*/
        {
          DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::BufferedCommandStruct>::Push( /*0x1410bc1f6*/
            this: (DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput> *)&this->artificialDelayTransmitPackets,
            s: (RakNet::RakPeer::SocketQueryOutput *)tempQueue.c._Mypair._Myval2._Map[(i >> 1)
                                                                                 & (tempQueue.c._Mypair._Myval2._Mapsize
                                                                                  - 1)][i & 1]);
          v23 = --tempQueue.c._Mypair._Myval2._Mysize; /*0x1410bc1ff*/
          if ( tempQueue.c._Mypair._Myval2._Mysize == 0 ) /*0x1410bc207*/
            break; /*0x1410bc207*/
        }
        tempQueue.c._Mypair._Myval2._Myoff = 0; /*0x1410bc216*/
      }
    }
    __unwind
    {
      std::queue<RakNet::DelayTransmitStruct *>::~queue<RakNet::DelayTransmitStruct *,std::deque<RakNet::DelayTransmitStruct *>>(this: (std::queue<float> *)&tempQueue); /*0xf1c0000000000014*/
    }
    if ( v23 != 0 ) /*0x1410bc221*/
    {
      do /*0x1410bc227*/
        --v23; /*0x1410bc223*/
      while ( v23 != 0 ); /*0x1410bc227*/
      tempQueue.c._Mypair._Myval2._Mysize = 0; /*0x1410bc229*/
      tempQueue.c._Mypair._Myval2._Myoff = 0; /*0x1410bc22d*/
    }
    v25 = tempQueue.c._Mypair._Myval2._Mapsize; /*0x1410bc231*/
    v26 = tempQueue.c._Mypair._Myval2._Map; /*0x1410bc235*/
    if ( tempQueue.c._Mypair._Myval2._Mapsize != 0 ) /*0x1410bc23c*/
    {
      do /*0x1410bc260*/
      {
        if ( v26[--v25] != nullptr ) /*0x1410bc24a*/
        {
          operator delete(ptr: v26[v25]); /*0x1410bc254*/
          v26 = tempQueue.c._Mypair._Myval2._Map; /*0x1410bc259*/
        }
      }
      while ( v25 != 0 ); /*0x1410bc260*/
      v25 = tempQueue.c._Mypair._Myval2._Mapsize; /*0x1410bc262*/
    }
    if ( v26 != nullptr ) /*0x1410bc269*/
    {
      v27 = v26; /*0x1410bc273*/
      if ( 8 * v25 >= 0x1000 ) /*0x1410bc27d*/
      {
        v26 = (RakNet::DelayTransmitStruct ***)*(v26 - 1); /*0x1410bc283*/
        if ( (unsigned __int64)((char *)v27 - (char *)v26 - 8) > 0x1F ) /*0x1410bc292*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410bc294*/
      }
      operator delete(ptr: v26); /*0x1410bc29b*/
    }
    Myproxy = tempQueue.c._Mypair._Myval2._Myproxy; /*0x1410bc2b0*/
    memset(&tempQueue, 0, 24); /*0x1410bc2b4*/
    operator delete(ptr: Myproxy); /*0x1410bc2c1*/
    v29 = socketToFlush->_Rep; /*0x1410bc2cb*/
    if ( v29 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v29->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410bc2df*/
    {
      v29->_Destroy(this: v29); /*0x1410bc2e7*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v29->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410bc2f3*/
        v29->_Delete_this(this: v29); /*0x1410bc2fb*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: socketToFlush); /*0xf1c0000000000008*/
  }
}

// Address: 0x1410bc320 | Name: ?GetArtificialLatencyRx@RakPeer@RakNet@@UEBA_KXZ
unsigned __int64 __fastcall RakNet::RakPeer::GetArtificialLatencyRx(RakNet::RakPeer *this)
{
  return this->latencyRx._Storage._Value; /*0x1410bc327*/
}

// Address: 0x1410bc330 | Name: ?GetArtificialLatencyTx@RakPeer@RakNet@@UEBA_KXZ
unsigned __int64 __fastcall RakNet::RakPeer::GetArtificialLatencyTx(RakNet::RakPeer *this)
{
  return this->latencyTx._Storage._Value; /*0x1410bc337*/
}

// Address: 0x1410bc340 | Name: ?GetAveragePing@RakPeer@RakNet@@UEAAHUAddressOrGUID@2@@Z
__int64 __fastcall RakNet::RakPeer::GetAveragePing(
        RakNet::RakPeer *this,
        const RakNet::AddressOrGUID *systemIdentifier)
{
  RakNet::RakPeer::RemoteSystemStruct *RemoteSystem; // rbp
  int v5; // edi
  RakNet::RakPeer::PingAndClockDifferential *pingAndClockDifferential; // r8
  int i; // ebx
  int pingTime; // edx
  RakNet::AddressOrGUID v10; // [rsp+20h] [rbp-38h] BYREF

  RakNet::RakNetGUID::RakNetGUID(this: &v10.rakNetGuid); /*0x1410bc35f*/
  RakNet::SystemAddress::SystemAddress(this: &v10.systemAddress); /*0x1410bc369*/
  v10.rakNetGuid.g = systemIdentifier->rakNetGuid.g; /*0x1410bc375*/
  v10.rakNetGuid.systemIndex = systemIdentifier->rakNetGuid.systemIndex; /*0x1410bc383*/
  RakNet::SystemAddress::operator=(this: &v10.systemAddress, input: &systemIdentifier->systemAddress); /*0x1410bc388*/
  RemoteSystem = RakNet::RakPeer::GetRemoteSystem( /*0x1410bc3a0*/
                   this,
                   systemIdentifier: &v10,
                   calledFromNetworkThread: false,
                   onlyActive: false);
  if ( RemoteSystem == nullptr ) /*0x1410bc3a6*/
    return 0xFFFFFFFFLL; /*0x1410bc3a6*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410bc3af*/
  v5 = 0; /*0x1410bc3b4*/
  pingAndClockDifferential = RemoteSystem->pingAndClockDifferential; /*0x1410bc3b6*/
  for ( i = 0; i < 5; ++i ) /*0x1410bc3bd*/
  {
    pingTime = pingAndClockDifferential->pingTime; /*0x1410bc3c4*/
    if ( (_WORD)pingTime == 0xFFFF ) /*0x1410bc3cb*/
      break; /*0x1410bc3cb*/
    v5 += pingTime; /*0x1410bc3cd*/
    ++pingAndClockDifferential; /*0x1410bc3d1*/
  }
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410bc3e1*/
  if ( i > 0 ) /*0x1410bc3e8*/
    return (unsigned int)(v5 / i); /*0x1410bc3ed*/
  else
    return 0xFFFFFFFFLL; /*0x1410bc3f1*/
}

// Address: 0x1410bc410 | Name: ?GetBandwidthManagerFeedback@RakPeer@RakNet@@UEBA_NUSystemAddress@2@AEAUBandwidthManagerFeedbackData@2@@Z
char __fastcall RakNet::RakPeer::GetBandwidthManagerFeedback(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *systemAddress,
        RakNet::BandwidthManagerFeedbackData *feedbackData)
{
  __int128 v4; // xmm1
  unsigned int v6; // ebx
  int v7; // edi
  __int64 v8; // r14
  RakNet::RakPeer::RemoteSystemStruct *v9; // rcx
  RakNet::SystemAddress right; // [rsp+20h] [rbp-28h] BYREF

  v4 = *((_OWORD *)&systemAddress->address.addr4 + 1); /*0x1410bc433*/
  *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&systemAddress->address.addr6.sin6_family; /*0x1410bc441*/
  *((_OWORD *)&right.address.addr4 + 1) = v4; /*0x1410bc445*/
  if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bc450*/
    return 0; /*0x1410bc450*/
  v6 = 0; /*0x1410bc456*/
  v7 = -1; /*0x1410bc458*/
  if ( this->maximumNumberOfPeers == 0 ) /*0x1410bc461*/
    return 0; /*0x1410bc461*/
  do /*0x1410bc4b5*/
  {
    v8 = (int)v6; /*0x1410bc483*/
    if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v8].systemAddress, &right) != 0 ) /*0x1410bc494*/
    {
      if ( this->remoteSystemList[v8].isActive._Storage._Value ) /*0x1410bc49d*/
      {
        v9 = &this->remoteSystemList[v8]; /*0x1410bc4f5*/
        goto LABEL_10; /*0x1410bc4f8*/
      }
      if ( v7 == -1 ) /*0x1410bc4aa*/
        v7 = v6; /*0x1410bc4aa*/
    }
    ++v6; /*0x1410bc4b1*/
  }
  while ( v6 < this->maximumNumberOfPeers ); /*0x1410bc4b5*/
  if ( v7 == -1 ) /*0x1410bc4ba*/
    return 0; /*0x1410bc4ba*/
  v9 = &this->remoteSystemList[v7]; /*0x1410bc4c6*/
LABEL_10:
  if ( v9 == nullptr || this->endThreads._Storage._Value ) /*0x1410bc4d2*/
    return 0; /*0x1410bc4fa*/
  RakNet::ReliabilityLayer::GetBandwidthManagerFeedback( /*0x1410bc4e5*/
    this: (RakNet::ReliabilityLayer *)((char *)&v9->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
    feedbackData);
  return 1; /*0x1410bc4fc*/
}

// Address: 0x1410bc520 | Name: ?GetConnectionList@RakPeer@RakNet@@UEBA_NPEAUSystemAddress@2@PEAG@Z
bool __fastcall RakNet::RakPeer::GetConnectionList(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *remoteSystems,
        unsigned __int16 *numberOfSystems)
{
  bool Value; // al
  unsigned __int16 v6; // bx
  bool result; // al
  DataStructures::List<RakNet::SystemAddress> addresses; // [rsp+20h] [rbp-28h] BYREF
  DataStructures::List<RakNet::RakNetGUID> guids; // [rsp+30h] [rbp-18h] BYREF

  if ( numberOfSystems == nullptr ) /*0x1410bc539*/
    return false; /*0x1410bc539*/
  if ( this->remoteSystemList == nullptr || (Value = this->endThreads._Storage._Value) ) /*0x1410bc54d*/
  {
    *numberOfSystems = 0; /*0x1410bc5f3*/
    return false; /*0x1410bc608*/
  }
  __wind /*0xf1c000000000001c*/
  {
    __wind /*0xf1c0000000000024*/
    {
      v6 = 0; /*0x1410bc55a*/
      *(_QWORD *)&addresses.list_size = 0; /*0x1410bc55c*/
      addresses.listArray = nullptr; /*0x1410bc560*/
      *(_QWORD *)&guids.list_size = 0; /*0x1410bc564*/
      guids.listArray = nullptr; /*0x1410bc568*/
      this->GetSystemList(this, a2: &addresses, a3: &guids); /*0x1410bc577*/
      if ( remoteSystems != nullptr ) /*0x1410bc580*/
      {
        if ( *numberOfSystems != 0 ) /*0x1410bc585*/
        {
          do /*0x1410bc5ad*/
          {
            if ( v6 >= addresses.list_size ) /*0x1410bc58e*/
              break; /*0x1410bc58e*/
            RakNet::SystemAddress::operator=(this: &remoteSystems[v6], input: &addresses.listArray[v6]); /*0x1410bc5a2*/
            ++v6; /*0x1410bc5a7*/
          }
          while ( v6 < *numberOfSystems ); /*0x1410bc5ad*/
        }
        *numberOfSystems = v6; /*0x1410bc5af*/
      }
      else
      {
        *numberOfSystems = addresses.list_size; /*0x1410bc5b9*/
      }
    }
    __unwind
    {
      DataStructures::List<bool>::~List<bool>(this: (DataStructures::List<bool> *)&guids); /*0xf1c0000000000014*/
    }
    if ( guids.allocation_size != 0 ) /*0x1410bc5c1*/
      operator delete(ptr: guids.listArray); /*0x1410bc5c8*/
    if ( addresses.allocation_size != 0 ) /*0x1410bc5d3*/
      operator delete(ptr: addresses.listArray); /*0x1410bc5da*/
    result = true; /*0x1410bc5df*/
  }
  __unwind
  {
    DataStructures::List<bool>::~List<bool>(this: (DataStructures::List<bool> *)&addresses); /*0xf1c0000000000008*/
  }
  return result; /*0x1410bc5e1*/
}

// Address: 0x1410bc610 | Name: ?GetConnectionState@RakPeer@RakNet@@UEAA?AW4ConnectionState@2@UAddressOrGUID@2@@Z
__int64 __fastcall RakNet::RakPeer::GetConnectionState(
        RakNet::RakPeer *this,
        const RakNet::AddressOrGUID *systemIdentifier)
{
  unsigned int v4; // ebx
  unsigned int head; // r8d
  unsigned int tail; // ecx
  unsigned int v7; // ecx
  unsigned int allocation_size; // eax
  unsigned int v9; // edx
  unsigned int v10; // r8d
  __int64 result; // rax
  __int128 v12; // xmm1
  int IndexFromSystemAddress; // ebx
  __int64 v14; // rdx
  unsigned int maximumNumberOfPeers; // eax
  __int64 v16; // rdx
  RakNet::SystemAddress lhs; // [rsp+20h] [rbp-38h] BYREF

  if ( RakNet::SystemAddress::operator!=(
         this: &systemIdentifier->systemAddress,
         right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 )
  {
    v4 = 0; /*0x1410bc650*/
    rtc::CriticalSection::Enter(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410bc653*/
    while ( 1 )
    {
      head = this->requestedConnectionQueue.head; /*0x1410bc660*/
      tail = this->requestedConnectionQueue.tail; /*0x1410bc667*/
      v7 = head > tail ? this->requestedConnectionQueue.allocation_size - head + tail : tail - head;
      if ( v4 >= v7 ) /*0x1410bc684*/
        break; /*0x1410bc684*/
      allocation_size = this->requestedConnectionQueue.allocation_size; /*0x1410bc686*/
      v9 = head + v4; /*0x1410bc68c*/
      v10 = v4 + head - allocation_size; /*0x1410bc69a*/
      if ( v9 >= allocation_size ) /*0x1410bc69f*/
        v9 = v10; /*0x1410bc69f*/
      if ( RakNet::SystemAddress::operator==( /*0x1410bc6b4*/
             this: &this->requestedConnectionQueue.array[v9]->systemAddress,
             right: &systemIdentifier->systemAddress) != 0 )
      {
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410bc6c1*/
        return 0; /*0x1410bc6c8*/
      }
      ++v4; /*0x1410bc6b6*/
    }
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410bc6d4*/
  }
  if ( RakNet::SystemAddress::operator!=( /*0x1410bc6eb*/
         this: &systemIdentifier->systemAddress,
         right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 )
  {
    v12 = *((_OWORD *)&systemIdentifier->systemAddress.address.addr4 + 1); /*0x1410bc6fa*/
    *(_OWORD *)&lhs.address.addr6.sin6_family = *(_OWORD *)&systemIdentifier->systemAddress.address.addr6.sin6_family; /*0x1410bc702*/
    *((_OWORD *)&lhs.address.addr4 + 1) = v12; /*0x1410bc707*/
    IndexFromSystemAddress = RakNet::RakPeer::GetIndexFromSystemAddress( /*0x1410bc711*/
                               this,
                               systemAddress: &lhs,
                               calledFromNetworkThread: false);
  }
  else
  {
    *(RakNet::RakNetGUID *)&lhs.address.addr6.sin6_family = systemIdentifier->rakNetGuid; /*0x1410bc754*/
    if ( StudioResourceId::operator==(&lhs, rhs: &RakNet::UNASSIGNED_RAKNET_GUID_30) ) /*0x1410bc759*/
      return 6; /*0x1410bc760*/
    if ( lhs.address.addr6.sin6_addr.u.Word[0] != 0xFFFF /*0x1410bc7ac*/
      && lhs.address.addr6.sin6_addr.u.Word[0] < this->maximumNumberOfPeers
      && StudioResourceId::operator==(
           lhs: &this->remoteSystemList[lhs.address.addr6.sin6_addr.u.Word[0]].guid,
           rhs: &lhs)
      && this->remoteSystemList[lhs.address.addr6.sin6_addr.u.Word[0]].isActive._Storage._Value )
    {
      IndexFromSystemAddress = lhs.address.addr6.sin6_addr.u.Word[0]; /*0x1410bc7bb*/
    }
    else
    {
      LOWORD(maximumNumberOfPeers) = this->maximumNumberOfPeers; /*0x1410bc7c5*/
      IndexFromSystemAddress = 0; /*0x1410bc7c9*/
      if ( (_WORD)maximumNumberOfPeers != 0 ) /*0x1410bc7d0*/
      {
        while ( 1 ) /*0x1410bc7e2*/
        {
          v16 = (unsigned int)IndexFromSystemAddress; /*0x1410bc7e2*/
          if ( this->remoteSystemList[v16].isActive._Storage._Value /*0x1410bc80f*/
            && StudioResourceId::operator==(lhs: &this->remoteSystemList[v16].guid, rhs: &lhs) )
          {
            break; /*0x1410bc80f*/
          }
          maximumNumberOfPeers = this->maximumNumberOfPeers; /*0x1410bc81c*/
          if ( ++IndexFromSystemAddress >= maximumNumberOfPeers ) /*0x1410bc824*/
            goto LABEL_28; /*0x1410bc824*/
        }
      }
      else
      {
LABEL_28:
        IndexFromSystemAddress = 0; /*0x1410bc826*/
        if ( (_WORD)maximumNumberOfPeers == 0 ) /*0x1410bc82d*/
          return 6; /*0x1410bc82d*/
        while ( !StudioResourceId::operator==(lhs: &this->remoteSystemList[IndexFromSystemAddress].guid, rhs: &lhs) ) /*0x1410bc855*/
        {
          if ( ++IndexFromSystemAddress >= (unsigned int)this->maximumNumberOfPeers ) /*0x1410bc863*/
            return 6; /*0x1410bc863*/
        }
      }
    }
  }
  if ( IndexFromSystemAddress == -1 ) /*0x1410bc716*/
    return 6; /*0x1410bc865*/
  v14 = IndexFromSystemAddress; /*0x1410bc71f*/
  if ( !this->remoteSystemList[v14].isActive._Storage._Value ) /*0x1410bc734*/
    return 5; /*0x1410bc73a*/
  switch ( this->remoteSystemList[v14].connectMode ) /*0x1410bc8ac*/
  {
    case DISCONNECT_ASAP: /*0x1410bc8ac*/
    case DISCONNECT_ON_NO_ACK: /*0x1410bc8ac*/
      result = 3; /*0x1410bc8b5*/
      break; /*0x1410bc8ba*/
    case DISCONNECT_ASAP_SILENTLY: /*0x1410bc8ac*/
      result = 4; /*0x1410bc8ae*/
      break; /*0x1410bc8b3*/
    case REQUESTED_CONNECTION: /*0x1410bc8ac*/
    case HANDLING_CONNECTION_REQUEST: /*0x1410bc8ac*/
    case UNVERIFIED_SENDER: /*0x1410bc8ac*/
      result = 1; /*0x1410bc8bc*/
      break; /*0x1410bc8c1*/
    case UNVERIFIED_SENDER|DISCONNECT_ASAP: /*0x1410bc8ac*/
      result = 2; /*0x1410bc8c3*/
      break; /*0x1410bc8c8*/
    default:
      return 6;
  }
  return result; /*0x1410bc86a*/
}

// Address: 0x1410bc8f0 | Name: ?GetConnectionStatus@RakPeer@RakNet@@UEAA_NUSystemAddress@2@HAEAH111AEAPEAURakNetStatistics@2@@Z
char __fastcall RakNet::RakPeer::GetConnectionStatus(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *target,
        const int rssIndexHint,
        int *mtuSize,
        int *averagePing,
        int *lastPing,
        int *lowestPing,
        RakNet::RakNetStatistics **stats)
{
  int v12; // edi
  __int128 v13; // xmm1
  unsigned __int16 maximumNumberOfPeers; // cx
  unsigned int v15; // ebx
  signed int v16; // edx
  __int64 v17; // r14
  RakNet::RakPeer::RemoteSystemStruct *v19; // r9
  RakNet::RakPeer::PingAndClockDifferential *pingAndClockDifferential; // rdx
  int i; // r8d
  int pingTime; // ecx
  int v23; // ecx
  unsigned __int64 pingAndClockDifferentialWriteIndex; // rax
  unsigned __int16 v25; // ax
  RakNet::SystemAddress right; // [rsp+20h] [rbp-38h] BYREF

  v12 = 0; /*0x1410bc923*/
  if ( RakNet::SystemAddress::operator!=(this: target, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410bc927*/
    goto LABEL_10; /*0x1410bc927*/
  v13 = *((_OWORD *)&target->address.addr4 + 1); /*0x1410bc937*/
  *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&target->address.addr6.sin6_family; /*0x1410bc940*/
  *((_OWORD *)&right.address.addr4 + 1) = v13; /*0x1410bc945*/
  if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bc951*/
    goto LABEL_10; /*0x1410bc951*/
  maximumNumberOfPeers = this->maximumNumberOfPeers; /*0x1410bc953*/
  v15 = 0; /*0x1410bc957*/
  if ( maximumNumberOfPeers == 0 ) /*0x1410bc95c*/
    goto LABEL_10; /*0x1410bc95c*/
  while ( 1 )
  {
    v16 = rssIndexHint == -1 ? v15 : (v15 + rssIndexHint) % maximumNumberOfPeers;
    v17 = v16; /*0x1410bc981*/
    if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v17].systemAddress, &right) != 0 /*0x1410bc9a0*/
      && this->remoteSystemList[v17].isActive._Storage._Value )
    {
      break; /*0x1410bc9a8*/
    }
    ++v15; /*0x1410bc9ae*/
    maximumNumberOfPeers = this->maximumNumberOfPeers; /*0x1410bc9b0*/
    if ( v15 >= maximumNumberOfPeers ) /*0x1410bc9b5*/
      goto LABEL_10; /*0x1410bc9b5*/
  }
  v19 = &this->remoteSystemList[v17]; /*0x1410bca10*/
  if ( v19 != nullptr ) /*0x1410bca13*/
  {
    pingAndClockDifferential = v19->pingAndClockDifferential; /*0x1410bca1c*/
    *mtuSize = v19->MTUSize; /*0x1410bca23*/
    for ( i = 0; i < 5; ++i ) /*0x1410bca26*/
    {
      pingTime = pingAndClockDifferential->pingTime; /*0x1410bca30*/
      if ( (_WORD)pingTime == 0xFFFF ) /*0x1410bca36*/
        break; /*0x1410bca36*/
      v12 += pingTime; /*0x1410bca38*/
      ++pingAndClockDifferential; /*0x1410bca3d*/
    }
    if ( i <= 0 ) /*0x1410bca4a*/
      v23 = -1; /*0x1410bca56*/
    else
      v23 = v12 / i; /*0x1410bca52*/
    *averagePing = v23; /*0x1410bca63*/
    pingAndClockDifferentialWriteIndex = v19->pingAndClockDifferentialWriteIndex; /*0x1410bca65*/
    if ( pingAndClockDifferentialWriteIndex != 0 ) /*0x1410bca6f*/
      v25 = *((_WORD *)&v19->reliabilityLayer.rakPeer + 8 * pingAndClockDifferentialWriteIndex + 2); /*0x1410bca84*/
    else
      v25 = v19->pingAndClockDifferential[4].pingTime; /*0x1410bca71*/
    *lastPing = v25; /*0x1410bca94*/
    *lowestPing = v19->lowestPing._Storage._Value; /*0x1410bcaa4*/
    if ( !this->endThreads._Storage._Value ) /*0x1410bcaad*/
    {
      RakNet::ReliabilityLayer::GetStatistics( /*0x1410bcac0*/
        this: (RakNet::ReliabilityLayer *)((char *)&v19->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
        rns: &staticStats);
      *stats = &staticStats; /*0x1410bcacd*/
    }
    return 1; /*0x1410bcad0*/
  }
  else
  {
LABEL_10:
    *mtuSize = this->defaultMTUSize; /*0x1410bc9b7*/
    *averagePing = -1; /*0x1410bc9cd*/
    *lastPing = -1; /*0x1410bc9d7*/
    *lowestPing = -1; /*0x1410bc9e1*/
    *stats = nullptr; /*0x1410bc9eb*/
    return 0; /*0x1410bc9ee*/
  }
}

// Address: 0x1410bcae0 | Name: ?GetConnectionStatusSafe@RakPeer@RakNet@@UEAA_NUSystemAddress@2@HAEAH1111AEAURakNetStatistics@2@@Z
char __fastcall RakNet::RakPeer::GetConnectionStatusSafe(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *target,
        const int rssIndexHint,
        int *mtuSize,
        int *averagePing,
        int *lastPing,
        int *lowestPing,
        int *lastBcsQueueTime,
        RakNet::RakNetStatistics *stats)
{
  __int128 v13; // xmm1
  unsigned __int16 maximumNumberOfPeers; // cx
  int v15; // ebp
  unsigned int v16; // ebx
  signed int v17; // edx
  __int64 v18; // rsi
  int *v19; // r14
  RakNet::RakPeer::RemoteSystemStruct *v21; // rbx
  RakNet::RakPeer::PingAndClockDifferential *pingAndClockDifferential; // rdx
  int i; // r8d
  int pingTime; // ecx
  int v25; // eax
  unsigned __int64 pingAndClockDifferentialWriteIndex; // rax
  unsigned __int16 v27; // ax
  RakNet::SystemAddress right; // [rsp+20h] [rbp-48h] BYREF

  if ( RakNet::SystemAddress::operator!=(this: target, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410bcb29*/
    goto LABEL_10; /*0x1410bcb29*/
  v13 = *((_OWORD *)&target->address.addr4 + 1); /*0x1410bcb39*/
  *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&target->address.addr6.sin6_family; /*0x1410bcb42*/
  *((_OWORD *)&right.address.addr4 + 1) = v13; /*0x1410bcb47*/
  if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bcb53*/
    goto LABEL_10; /*0x1410bcb53*/
  maximumNumberOfPeers = this->maximumNumberOfPeers; /*0x1410bcb55*/
  v15 = 0; /*0x1410bcb59*/
  v16 = 0; /*0x1410bcb5b*/
  if ( maximumNumberOfPeers == 0 ) /*0x1410bcb60*/
    goto LABEL_10; /*0x1410bcb60*/
  while ( 1 )
  {
    v17 = rssIndexHint == -1 ? v16 : (v16 + rssIndexHint) % maximumNumberOfPeers;
    v18 = v17; /*0x1410bcb85*/
    if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v18].systemAddress, &right) != 0 /*0x1410bcba4*/
      && this->remoteSystemList[v18].isActive._Storage._Value )
    {
      break; /*0x1410bcbab*/
    }
    ++v16; /*0x1410bcbb1*/
    maximumNumberOfPeers = this->maximumNumberOfPeers; /*0x1410bcbb3*/
    if ( v16 >= maximumNumberOfPeers ) /*0x1410bcbb8*/
      goto LABEL_10; /*0x1410bcbb8*/
  }
  v21 = &this->remoteSystemList[v18]; /*0x1410bcc0b*/
  if ( v21 == nullptr ) /*0x1410bcc0e*/
  {
LABEL_10:
    v19 = lastPing; /*0x1410bcbba*/
LABEL_11:
    *mtuSize = this->defaultMTUSize; /*0x1410bcbc2*/
    *averagePing = -1; /*0x1410bcbce*/
    *v19 = -1; /*0x1410bcbd5*/
    *lowestPing = -1; /*0x1410bcbdc*/
    return 0; /*0x1410bcc03*/
  }
  rtc::CriticalSection::Enter(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410bcc17*/
  pingAndClockDifferential = v21->pingAndClockDifferential; /*0x1410bcc22*/
  *mtuSize = v21->MTUSize; /*0x1410bcc29*/
  for ( i = 0; i < 5; ++i ) /*0x1410bcc2d*/
  {
    pingTime = pingAndClockDifferential->pingTime; /*0x1410bcc35*/
    if ( (_WORD)pingTime == 0xFFFF ) /*0x1410bcc3b*/
      break; /*0x1410bcc3b*/
    v15 += pingTime; /*0x1410bcc3d*/
    ++pingAndClockDifferential; /*0x1410bcc42*/
  }
  if ( i <= 0 ) /*0x1410bcc4f*/
    v25 = -1; /*0x1410bcc59*/
  else
    v25 = v15 / i; /*0x1410bcc54*/
  *averagePing = v25; /*0x1410bcc5e*/
  pingAndClockDifferentialWriteIndex = v21->pingAndClockDifferentialWriteIndex; /*0x1410bcc61*/
  if ( pingAndClockDifferentialWriteIndex != 0 ) /*0x1410bcc6b*/
    v27 = *((_WORD *)&v21->reliabilityLayer.rakPeer + 8 * pingAndClockDifferentialWriteIndex + 2); /*0x1410bcc7f*/
  else
    v27 = v21->pingAndClockDifferential[4].pingTime; /*0x1410bcc6d*/
  v19 = lastPing; /*0x1410bcc83*/
  *lastPing = v27; /*0x1410bcc8e*/
  *lowestPing = v21->lowestPing._Storage._Value; /*0x1410bcc96*/
  *lastBcsQueueTime = this->bcsQueueTime; /*0x1410bcca5*/
  if ( this->endThreads._Storage._Value ) /*0x1410bcca7*/
  {
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410bccde*/
    goto LABEL_11; /*0x1410bcce3*/
  }
  RakNet::ReliabilityLayer::GetStatistics( /*0x1410bccbf*/
    this: (RakNet::ReliabilityLayer *)((char *)&v21->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
    rns: stats);
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410bcccb*/
  return 1; /*0x1410bcbe4*/
}

// Address: 0x1410bccf0 | Name: ?GetDataStatistics@RakPeer@RakNet@@UEAA_NAEBUSystemAddress@2@AEAUDataStatistics@2@_N@Z
char __fastcall RakNet::RakPeer::GetDataStatistics(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *target,
        RakNet::DataStatistics *ds,
        bool checkInactivePeers)
{
  int v4; // ebx
  int v9; // esi
  RakNet::RakPeer::RemoteSystemStruct *v11; // rcx
  RakNet::RakPeer::RemoteSystemStruct *remoteSystemList; // rax
  __int64 v13; // xmm0_8

  v4 = 0; /*0x1410bcd14*/
  v9 = 0; /*0x1410bcd23*/
  if ( this->activeSystemListSize._Storage._Value != 0 ) /*0x1410bcd28*/
  {
    while ( RakNet::SystemAddress::operator==(this: &this->activeSystemList[v9]->systemAddress, right: target) == 0 ) /*0x1410bcd4c*/
    {
      if ( ++v9 >= this->activeSystemListSize._Storage._Value ) /*0x1410bcd59*/
        goto LABEL_4; /*0x1410bcd59*/
    }
    v11 = this->activeSystemList[v9]; /*0x1410bcdc9*/
    *(_OWORD *)&ds->totalBytesRakPeerSent = *(_OWORD *)((char *)&v11->reliabilityLayer.statistics.ds.totalBytesRakPeerSent /*0x1410bcdd6*/
                                                      + 4);
    *(_OWORD *)&ds->totalBytesReceived = *(_OWORD *)((char *)&v11->reliabilityLayer.statistics.ds.totalBytesReceived + 4); /*0x1410bcde1*/
    *(_OWORD *)&ds->totalJoinDataRakPeerSent = *(_OWORD *)((char *)&v11->reliabilityLayer.statistics.ds.totalJoinDataRakPeerSent /*0x1410bcdec*/
                                                         + 4);
    *(_OWORD *)&ds->totalJoinDataSent = *(_OWORD *)((char *)&v11->reliabilityLayer.statistics.ds.totalJoinDataSent + 4); /*0x1410bcdf7*/
    *(_OWORD *)&ds->totalJoinDataSentCount = *(_OWORD *)&v11->reliabilityLayer.statistics.ds.totalJoinDataResentCount; /*0x1410bce02*/
    *(_OWORD *)&ds->joinInternalResentRTOCount = *(_OWORD *)(&v11->reliabilityLayer.statistics.ds.joinInternalResentRTOCount /*0x1410bce0d*/
                                                           + 1);
    ds->totalJoinDataNakSize_DEPRECATED = *(__int64 *)((char *)&v11->reliabilityLayer.statistics.ds.totalJoinDataNakSize_DEPRECATED /*0x1410bce19*/
                                                     + 4);
    return 1; /*0x1410bcdcd*/
  }
  else
  {
LABEL_4:
    if ( checkInactivePeers && this->remoteSystemList != nullptr && this->maximumNumberOfPeers != 0 ) /*0x1410bcd6d*/
    {
      while ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v4].systemAddress, right: target) == 0 ) /*0x1410bcd91*/
      {
        if ( ++v4 >= (unsigned int)this->maximumNumberOfPeers ) /*0x1410bcd9f*/
          return 0; /*0x1410bcd9f*/
      }
      remoteSystemList = this->remoteSystemList; /*0x1410bce20*/
      *(_OWORD *)&ds->totalBytesRakPeerSent = *(_OWORD *)((char *)&remoteSystemList[v4].reliabilityLayer.statistics.ds.totalBytesRakPeerSent /*0x1410bce36*/
                                                        + 4);
      *(_OWORD *)&ds->totalBytesReceived = *(_OWORD *)((char *)&remoteSystemList[v4].reliabilityLayer.statistics.ds.totalBytesReceived /*0x1410bce42*/
                                                     + 4);
      *(_OWORD *)&ds->totalJoinDataRakPeerSent = *(_OWORD *)((char *)&remoteSystemList[v4].reliabilityLayer.statistics.ds.totalJoinDataRakPeerSent /*0x1410bce4e*/
                                                           + 4);
      *(_OWORD *)&ds->totalJoinDataSent = *(_OWORD *)((char *)&remoteSystemList[v4].reliabilityLayer.statistics.ds.totalJoinDataSent /*0x1410bce5a*/
                                                    + 4);
      *(_OWORD *)&ds->totalJoinDataSentCount = *(_OWORD *)&remoteSystemList[v4].reliabilityLayer.statistics.ds.totalJoinDataResentCount; /*0x1410bce66*/
      *(_OWORD *)&ds->joinInternalResentRTOCount = *(_OWORD *)(&remoteSystemList[v4].reliabilityLayer.statistics.ds.joinInternalResentRTOCount /*0x1410bce72*/
                                                             + 1);
      v13 = *(__int64 *)((char *)&remoteSystemList[v4].reliabilityLayer.statistics.ds.totalJoinDataNakSize_DEPRECATED + 4); /*0x1410bce76*/
      ds->totalJoinDataNakSize_DEPRECATED = v13; /*0x1410bce81*/
      return 1; /*0x1410bce7f*/
    }
    else
    {
      return 0; /*0x1410bcda1*/
    }
  }
}

// Address: 0x1410bce90 | Name: ?GetGUIDFromIndex@RakPeer@RakNet@@UEAA?AURakNetGUID@2@H@Z
RakNet::RakNetGUID *__fastcall RakNet::RakPeer::GetGUIDFromIndex(
        RakNet::RakPeer *this,
        RakNet::RakNetGUID *result,
        int index)
{
  __int64 v3; // r8
  RakNet::RakPeer::RemoteSystemStruct *remoteSystemList; // rax
  RakNet::RakNetGUID guid; // xmm0

  if ( index >= 0 /*0x1410bcecc*/
    && index < this->maximumNumberOfPeers
    && *(&this->remoteSystemList->isActive._Storage._Value + (v3 = index))
    && (remoteSystemList = this->remoteSystemList,
        remoteSystemList[v3].connectMode == (UNVERIFIED_SENDER|DISCONNECT_ASAP)) )
  {
    guid = remoteSystemList[v3].guid; /*0x1410bcece*/
    *result = guid; /*0x1410bceda*/
    return result; /*0x1410bced7*/
  }
  else
  {
    *result = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410bcee9*/
    return result; /*0x1410bcee6*/
  }
}

// Address: 0x1410bcef0 | Name: ?GetGuidFromSystemAddress@RakPeer@RakNet@@UEBAAEBURakNetGUID@2@USystemAddress@2@@Z
const RakNet::RakNetGUID *__fastcall RakNet::RakPeer::GetGuidFromSystemAddress(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *input)
{
  __int64 systemIndex; // rax
  unsigned int v6; // ebx
  __int64 v7; // rbp

  if ( RakNet::SystemAddress::operator==(this: input, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bcf11*/
    return &this->myGuid; /*0x1410bcf13*/
  systemIndex = input->systemIndex; /*0x1410bcf25*/
  if ( (_WORD)systemIndex != 0xFFFF /*0x1410bcf58*/
    && (unsigned __int16)systemIndex < this->maximumNumberOfPeers
    && RakNet::SystemAddress::operator==(this: &this->remoteSystemList[systemIndex].systemAddress, right: input) != 0 )
  {
    return &this->remoteSystemList[input->systemIndex].guid; /*0x1410bcf72*/
  }
  v6 = 0; /*0x1410bcf85*/
  if ( this->maximumNumberOfPeers == 0 ) /*0x1410bcf90*/
    return &RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410bcfcd*/
  while ( 1 ) /*0x1410bcfb0*/
  {
    v7 = v6; /*0x1410bcfb0*/
    if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v7].systemAddress, right: input) != 0 ) /*0x1410bcfc1*/
      break; /*0x1410bcfc1*/
    if ( ++v6 >= this->maximumNumberOfPeers ) /*0x1410bcfcb*/
      return &RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410bcfcb*/
  }
  return &this->remoteSystemList[v7].guid; /*0x1410bcf1a*/
}

// Address: 0x1410bd000 | Name: ?GetIncomingPassword@RakPeer@RakNet@@UEAAXPEADPEAH@Z
void __fastcall RakNet::RakPeer::GetIncomingPassword(
        RakNet::RakPeer *this,
        char *passwordData,
        int *passwordDataLength)
{
  int incomingPasswordLength; // ecx
  int v6; // eax

  if ( passwordData != nullptr ) /*0x1410bd010*/
  {
    incomingPasswordLength = this->incomingPasswordLength; /*0x1410bd016*/
    v6 = *passwordDataLength; /*0x1410bd018*/
    if ( *passwordDataLength > incomingPasswordLength ) /*0x1410bd01d*/
    {
      *passwordDataLength = incomingPasswordLength; /*0x1410bd01f*/
      v6 = incomingPasswordLength; /*0x1410bd022*/
    }
    if ( v6 > 0 ) /*0x1410bd026*/
      memcpy_0(a1: passwordData, Src: this->incomingPassword, Size: v6); /*0x1410bd035*/
  }
  else
  {
    *passwordDataLength = this->incomingPasswordLength; /*0x1410bd012*/
  }
}

// Address: 0x1410bd040 | Name: ?GetIndexFromSystemAddress@RakPeer@RakNet@@IEBAHUSystemAddress@2@_N@Z
unsigned int __fastcall RakNet::RakPeer::GetIndexFromSystemAddress(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *systemAddress,
        bool calledFromNetworkThread)
{
  __int64 systemIndex; // rax
  int v8; // ebx
  unsigned int v9; // esi
  __int64 v10; // rdx
  unsigned int maximumNumberOfPeers; // eax

  if ( RakNet::SystemAddress::operator==(this: systemAddress, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bd06f*/
    return -1; /*0x1410bd06f*/
  systemIndex = systemAddress->systemIndex; /*0x1410bd075*/
  if ( (_WORD)systemIndex != 0xFFFF /*0x1410bd0b5*/
    && (unsigned __int16)systemIndex < this->maximumNumberOfPeers
    && RakNet::SystemAddress::operator==(this: &this->remoteSystemList[systemIndex].systemAddress, right: systemAddress) != 0
    && this->remoteSystemList[systemAddress->systemIndex].isActive._Storage._Value )
  {
    return systemAddress->systemIndex; /*0x1410bd0c8*/
  }
  if ( calledFromNetworkThread ) /*0x1410bd0cf*/
    return RakNet::RakPeer::GetRemoteSystemIndex(this, sa: systemAddress); /*0x1410bd0dc*/
  v8 = 0; /*0x1410bd0e5*/
  v9 = 0; /*0x1410bd0e7*/
  if ( this->maximumNumberOfPeers == 0 ) /*0x1410bd0ec*/
    return -1; /*0x1410bd15f*/
  do /*0x1410bd12b*/
  {
    v10 = v9; /*0x1410bd0f2*/
    if ( this->remoteSystemList[v10].isActive._Storage._Value /*0x1410bd121*/
      && RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v10].systemAddress, right: systemAddress) != 0 )
    {
      return v9; /*0x1410bd17b*/
    }
    maximumNumberOfPeers = this->maximumNumberOfPeers; /*0x1410bd123*/
    ++v9; /*0x1410bd127*/
  }
  while ( v9 < maximumNumberOfPeers ); /*0x1410bd12b*/
  if ( (_WORD)maximumNumberOfPeers == 0 ) /*0x1410bd130*/
    return -1; /*0x1410bd130*/
  while ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v8].systemAddress, right: systemAddress) == 0 ) /*0x1410bd153*/
  {
    if ( ++v8 >= (unsigned int)this->maximumNumberOfPeers ) /*0x1410bd15d*/
      return -1; /*0x1410bd15d*/
  }
  return v8; /*0x1410bd164*/
}

// Address: 0x1410bd190 | Name: ?GetIndexFromSystemAddress@RakPeer@RakNet@@UEBAHUSystemAddress@2@@Z
unsigned int __fastcall RakNet::RakPeer::GetIndexFromSystemAddress(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *systemAddress)
{
  __int128 v2; // xmm1
  RakNet::SystemAddress v4; // [rsp+20h] [rbp-28h] BYREF

  v2 = *((_OWORD *)&systemAddress->address.addr4 + 1); /*0x1410bd19a*/
  *(_OWORD *)&v4.address.addr6.sin6_family = *(_OWORD *)&systemAddress->address.addr6.sin6_family; /*0x1410bd1a3*/
  *((_OWORD *)&v4.address.addr4 + 1) = v2; /*0x1410bd1a8*/
  return RakNet::RakPeer::GetIndexFromSystemAddress(this, systemAddress: &v4, calledFromNetworkThread: false); /*0x1410bd1b2*/
}

// Address: 0x1410bd1c0 | Name: ?GetInternalID@RakPeer@RakNet@@UEBA?AUSystemAddress@2@U32@H@Z
RakNet::SystemAddress *__fastcall RakNet::RakPeer::GetInternalID(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *result,
        RakNet::SystemAddress *systemAddress,
        const int index)
{
  __int64 v5; // rbp
  __int128 v8; // xmm0
  __int128 v9; // xmm1
  __int128 v10; // xmm1
  int v11; // ebx
  __int64 v12; // r14
  RakNet::RakPeer::RemoteSystemStruct *v14; // rcx
  RakNet::SystemAddress right; // [rsp+20h] [rbp-28h] BYREF

  v5 = index; /*0x1410bd1d7*/
  if ( RakNet::SystemAddress::operator==(this: systemAddress, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bd1f1*/
  {
    v8 = *(_OWORD *)&this->ipList[v5].address.addr6.sin6_family; /*0x1410bd1fa*/
    v9 = *((_OWORD *)&this->ipList[v5].address.addr4 + 1); /*0x1410bd202*/
  }
  else
  {
    v10 = *((_OWORD *)&systemAddress->address.addr4 + 1); /*0x1410bd21e*/
    *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&systemAddress->address.addr6.sin6_family; /*0x1410bd227*/
    *((_OWORD *)&right.address.addr4 + 1) = v10; /*0x1410bd22c*/
    if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bd238*/
      goto LABEL_8; /*0x1410bd238*/
    v11 = 0; /*0x1410bd23a*/
    if ( this->maximumNumberOfPeers == 0 ) /*0x1410bd240*/
      goto LABEL_8; /*0x1410bd240*/
    while ( 1 ) /*0x1410bd263*/
    {
      v12 = v11; /*0x1410bd263*/
      if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v12].systemAddress, &right) != 0 /*0x1410bd27d*/
        && this->remoteSystemList[v12].isActive._Storage._Value )
      {
        break; /*0x1410bd285*/
      }
      if ( ++v11 >= (unsigned int)this->maximumNumberOfPeers ) /*0x1410bd28f*/
        goto LABEL_8; /*0x1410bd28f*/
    }
    v14 = &this->remoteSystemList[v12]; /*0x1410bd2ca*/
    if ( v14 != nullptr ) /*0x1410bd2cd*/
    {
      v8 = *(_OWORD *)&v14->theirInternalSystemAddress[v5].address.addr6.sin6_family; /*0x1410bd2d6*/
      v9 = *((_OWORD *)&v14->theirInternalSystemAddress[v5].address.addr4 + 1); /*0x1410bd2db*/
    }
    else
    {
LABEL_8:
      v8 = *(_OWORD *)&RakNet::UNASSIGNED_SYSTEM_ADDRESS_30.address.addr6.sin6_family; /*0x1410bd291*/
      v9 = *((_OWORD *)&RakNet::UNASSIGNED_SYSTEM_ADDRESS_30.address.addr4 + 1); /*0x1410bd298*/
    }
  }
  *(_OWORD *)&result->address.addr6.sin6_family = v8; /*0x1410bd2b1*/
  *((_OWORD *)&result->address.addr4 + 1) = v9; /*0x1410bd2b4*/
  return result; /*0x1410bd2a4*/
}

// Address: 0x1410bd2f0 | Name: ?GetJoinRxStats@RakPeer@RakNet@@UEAAXUAddressOrGUID@2@AEAUJoinRxStats@2@@Z
void __fastcall RakNet::RakPeer::GetJoinRxStats(
        RakNet::RakPeer *this,
        const RakNet::AddressOrGUID *systemIdentifier,
        RakNet::JoinRxStats *joinRxStats)
{
  RakNet::JoinRxStats *RemoteSystem; // rax
  RakNet::AddressOrGUID v7; // [rsp+20h] [rbp-38h] BYREF

  RakNet::RakNetGUID::RakNetGUID(this: &v7.rakNetGuid); /*0x1410bd30d*/
  RakNet::SystemAddress::SystemAddress(this: &v7.systemAddress); /*0x1410bd317*/
  v7.rakNetGuid.g = systemIdentifier->rakNetGuid.g; /*0x1410bd323*/
  v7.rakNetGuid.systemIndex = systemIdentifier->rakNetGuid.systemIndex; /*0x1410bd331*/
  RakNet::SystemAddress::operator=(this: &v7.systemAddress, input: &systemIdentifier->systemAddress); /*0x1410bd336*/
  RemoteSystem = (RakNet::JoinRxStats *)RakNet::RakPeer::GetRemoteSystem( /*0x1410bd349*/
                                          this,
                                          systemIdentifier: &v7,
                                          calledFromNetworkThread: false,
                                          onlyActive: false);
  if ( RemoteSystem != nullptr ) /*0x1410bd351*/
    *joinRxStats = RemoteSystem[94]; /*0x1410bd35a*/
}

// Address: 0x1410bd370 | Name: ?GetLastPing@RakPeer@RakNet@@UEBAHUAddressOrGUID@2@@Z
__int64 __fastcall RakNet::RakPeer::GetLastPing(RakNet::RakPeer *this, const RakNet::AddressOrGUID *systemIdentifier)
{
  RakNet::RakPeer::RemoteSystemStruct *RemoteSystem; // rbx
  unsigned __int64 pingAndClockDifferentialWriteIndex; // rax
  unsigned __int16 pingTime; // bx
  RakNet::AddressOrGUID v8; // [rsp+20h] [rbp-38h] BYREF

  RakNet::RakNetGUID::RakNetGUID(this: &v8.rakNetGuid); /*0x1410bd385*/
  RakNet::SystemAddress::SystemAddress(this: &v8.systemAddress); /*0x1410bd38f*/
  v8.rakNetGuid.g = systemIdentifier->rakNetGuid.g; /*0x1410bd39b*/
  v8.rakNetGuid.systemIndex = systemIdentifier->rakNetGuid.systemIndex; /*0x1410bd3a9*/
  RakNet::SystemAddress::operator=(this: &v8.systemAddress, input: &systemIdentifier->systemAddress); /*0x1410bd3ae*/
  RemoteSystem = RakNet::RakPeer::GetRemoteSystem( /*0x1410bd3c6*/
                   this,
                   systemIdentifier: &v8,
                   calledFromNetworkThread: false,
                   onlyActive: false);
  if ( RemoteSystem == nullptr ) /*0x1410bd3cc*/
    return 0xFFFFFFFFLL; /*0x1410bd3ce*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410bd3e3*/
  pingAndClockDifferentialWriteIndex = RemoteSystem->pingAndClockDifferentialWriteIndex; /*0x1410bd3e8*/
  if ( pingAndClockDifferentialWriteIndex != 0 ) /*0x1410bd3f2*/
    pingTime = *((_WORD *)&RemoteSystem->reliabilityLayer.rakPeer + 8 * pingAndClockDifferentialWriteIndex + 2); /*0x1410bd406*/
  else
    pingTime = RemoteSystem->pingAndClockDifferential[4].pingTime; /*0x1410bd3f4*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410bd411*/
  return pingTime; /*0x1410bd3d1*/
}

// Address: 0x1410bd430 | Name: ?GetLocalIP@RakPeer@RakNet@@UEAAPEBDI@Z
char *__fastcall RakNet::RakPeer::GetLocalIP(RakNet::RakPeer *this, unsigned int index)
{
  __int64 v3; // rdi

  v3 = index; /*0x1410bd440*/
  if ( !this->IsActive(this) ) /*0x1410bd447*/
    RakNet::SocketLayer::GetMyIP(addresses: this->ipList); /*0x1410bd450*/
  RakNet::SystemAddress::ToStringN( /*0x1410bd477*/
    this: &this->ipList[v3],
    writePort: false,
    dest: str,
    size: 1025,
    portDelineator: 124);
  return str; /*0x1410bd47c*/
}

// Address: 0x1410bd490 | Name: ?GetLowestPing@RakPeer@RakNet@@UEBAHUAddressOrGUID@2@@Z
__int64 __fastcall RakNet::RakPeer::GetLowestPing(RakNet::RakPeer *this, const RakNet::AddressOrGUID *systemIdentifier)
{
  RakNet::RakPeer::RemoteSystemStruct *RemoteSystem; // rbx
  unsigned int Value; // ebx
  RakNet::AddressOrGUID v7; // [rsp+20h] [rbp-38h] BYREF

  RakNet::RakNetGUID::RakNetGUID(this: &v7.rakNetGuid); /*0x1410bd4a5*/
  RakNet::SystemAddress::SystemAddress(this: &v7.systemAddress); /*0x1410bd4af*/
  v7.rakNetGuid.g = systemIdentifier->rakNetGuid.g; /*0x1410bd4bb*/
  v7.rakNetGuid.systemIndex = systemIdentifier->rakNetGuid.systemIndex; /*0x1410bd4c9*/
  RakNet::SystemAddress::operator=(this: &v7.systemAddress, input: &systemIdentifier->systemAddress); /*0x1410bd4ce*/
  RemoteSystem = RakNet::RakPeer::GetRemoteSystem( /*0x1410bd4e6*/
                   this,
                   systemIdentifier: &v7,
                   calledFromNetworkThread: false,
                   onlyActive: false);
  if ( RemoteSystem == nullptr ) /*0x1410bd4ec*/
    return 0xFFFFFFFFLL; /*0x1410bd4ee*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410bd503*/
  Value = RemoteSystem->lowestPing._Storage._Value; /*0x1410bd508*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410bd514*/
  return Value; /*0x1410bd4f1*/
}

// Address: 0x1410bd530 | Name: ?GetMTUSize@RakPeer@RakNet@@UEBAHUSystemAddress@2@@Z
__int64 __fastcall RakNet::RakPeer::GetMTUSize(RakNet::RakPeer *this, RakNet::SystemAddress *target)
{
  __int128 v4; // xmm1
  int v5; // ebx
  __int64 v6; // rsi
  RakNet::RakPeer::RemoteSystemStruct *v8; // rbx
  unsigned int MTUSize; // ebx
  RakNet::SystemAddress right; // [rsp+20h] [rbp-28h] BYREF

  if ( RakNet::SystemAddress::operator!=(this: target, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410bd556*/
    return (unsigned int)this->defaultMTUSize; /*0x1410bd556*/
  v4 = *((_OWORD *)&target->address.addr4 + 1); /*0x1410bd562*/
  *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&target->address.addr6.sin6_family; /*0x1410bd56b*/
  *((_OWORD *)&right.address.addr4 + 1) = v4; /*0x1410bd570*/
  if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bd57c*/
    return (unsigned int)this->defaultMTUSize; /*0x1410bd57c*/
  v5 = 0; /*0x1410bd57e*/
  if ( this->maximumNumberOfPeers == 0 ) /*0x1410bd584*/
    return (unsigned int)this->defaultMTUSize; /*0x1410bd584*/
  while ( 1 ) /*0x1410bd5a3*/
  {
    v6 = v5; /*0x1410bd5a3*/
    if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v6].systemAddress, &right) != 0 /*0x1410bd5bd*/
      && this->remoteSystemList[v6].isActive._Storage._Value )
    {
      break; /*0x1410bd5c4*/
    }
    if ( ++v5 >= (unsigned int)this->maximumNumberOfPeers ) /*0x1410bd5ce*/
      return (unsigned int)this->defaultMTUSize; /*0x1410bd5ce*/
  }
  v8 = &this->remoteSystemList[v6]; /*0x1410bd5ed*/
  if ( v8 == nullptr ) /*0x1410bd5f0*/
    return (unsigned int)this->defaultMTUSize; /*0x1410bd5d0*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410bd5f9*/
  MTUSize = v8->MTUSize; /*0x1410bd5fe*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410bd60b*/
  return MTUSize; /*0x1410bd5d6*/
}

// Address: 0x1410bd630 | Name: ?GetMaximumIncomingConnections@RakPeer@RakNet@@UEBAGXZ
__int64 __fastcall RakNet::RakPeer::GetMaximumIncomingConnections(RakNet::RakPeer *this)
{
  return this->maximumIncomingConnections; /*0x1410bd634*/
}

// Address: 0x1410bd640 | Name: ?GetMaximumNumberOfPeers@RakPeer@RakNet@@UEBAGXZ
__int64 __fastcall RakNet::RakPeer::GetMaximumNumberOfPeers(RakNet::RakPeer *this)
{
  return this->maximumNumberOfPeers; /*0x1410bd644*/
}

// Address: 0x1410bd650 | Name: ?GetMyBoundAddress@RakPeer@RakNet@@UEAA?AUSystemAddress@2@H@Z
RakNet::SystemAddress *__fastcall RakNet::RakPeer::GetMyBoundAddress(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *result,
        const int socketIndex)
{
  std::shared_ptr<RakNet::RakNetSocket> *listArray; // r10
  char *Ptr; // rcx
  std::_Ref_count_base **p_Rep; // rbx
  RakNet::SystemAddress *v8; // rax
  std::_Ref_count_base **v9; // rbx
  __int64 v10; // [rsp+0h] [rbp-38h] BYREF
  DataStructures::List<std::shared_ptr<RakNet::RakNetSocket> > sockets; // [rsp+20h] [rbp-18h] BYREF

  __wind /*0xf1c0000000000034*/
  {
    *(_QWORD *)&sockets.list_size = 0; /*0x1410bd662*/
    sockets.listArray = nullptr; /*0x1410bd667*/
    this->GetSockets(this, a2: &sockets); /*0x1410bd674*/
  }
  __unwind
  {
    DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::~List<std::shared_ptr<RakNet::RakNetSocket>>(this: &sockets); /*0xf1c0000000000044*/
  }
  __eh34_enter_wind_state(-1, 1); /*0xf1c000000000004c*/
  if ( sockets.list_size != 0 ) /*0x1410bd67f*/
  {
    listArray = sockets.listArray; /*0x1410bd686*/
    Ptr = (char *)sockets.listArray[socketIndex]._Ptr; /*0x1410bd68b*/
    *(_OWORD *)&result->address.addr6.sin6_family = *(_OWORD *)(Ptr + 12); /*0x1410bd693*/
    *((_OWORD *)&result->address.addr4 + 1) = *(_OWORD *)(Ptr + 28); /*0x1410bd69a*/
    if ( sockets.allocation_size != 0 && listArray != nullptr ) /*0x1410bd6ac*/
    {
      p_Rep = &listArray[-1]._Rep; /*0x1410bd6b2*/
      `eh vector destructor iterator'( /*0x1410bd6c8*/
        ptr: listArray,
        size: 0x10u,
        count: (unsigned __int64)listArray[-1]._Rep,
        destructor: (void (__fastcall *)(void *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>);
      operator delete(ptr: p_Rep); /*0x1410bd6db*/
      v8 = result; /*0x1410bd6e1*/
      if ( __eh34_unwind(1) ) /*0xf1c0000000000028*/
        goto unwind_state_1; /*0xf1c0000000000028*/
      __eh34_exit_wind_state(1, -1); /*0xf1c000000000002c*/
      return v8; /*0xf1c0000000000030*/
    }
  }
  else
  {
    *result = RakNet::UNASSIGNED_SYSTEM_ADDRESS_30; /*0x1410bd6f6*/
    if ( sockets.allocation_size != 0 ) /*0x1410bd709*/
    {
      Ptr = (char *)sockets.listArray; /*0x1410bd70b*/
      if ( sockets.listArray != nullptr ) /*0x1410bd713*/
      {
        v9 = &sockets.listArray[-1]._Rep; /*0x1410bd715*/
        `eh vector destructor iterator'( /*0x1410bd728*/
          ptr: sockets.listArray,
          size: 0x10u,
          count: (unsigned __int64)sockets.listArray[-1]._Rep,
          destructor: (void (__fastcall *)(void *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>);
        operator delete(ptr: v9); /*0x1410bd73b*/
      }
    }
  }
  if ( __eh34_unwind(1) ) /*0xf1c0000000000014*/
unwind_state_1:
    __std_terminate(a1: Ptr, a2: &v10); /*0xf1c0000000000018*/
  __eh34_exit_wind_state(1, -1); /*0xf1c0000000000020*/
  return result; /*0x1410bd6e4*/
}

// Address: 0x1410bd750 | Name: ?GetMyGUID@RakPeer@RakNet@@UEBA?BURakNetGUID@2@XZ
const RakNet::RakNetGUID *__fastcall RakNet::RakPeer::GetMyGUID(RakNet::RakPeer *this, RakNet::RakNetGUID *result)
{
  *result = this->myGuid; /*0x1410bd75a*/
  return result; /*0x1410bd75d*/
}

// Address: 0x1410bd760 | Name: ?GetNextSendReceipt@RakPeer@RakNet@@UEAAIXZ
__int64 __fastcall RakNet::RakPeer::GetNextSendReceipt(RakNet::RakPeer *this)
{
  RakNet::SimpleMutex *p_sendReceiptSerialMutex; // rdi
  RakNet::RakPeer *v2; // rbx

  p_sendReceiptSerialMutex = &this->sendReceiptSerialMutex; /*0x1410bd76a*/
  v2 = this; /*0x1410bd771*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410bd777*/
  LODWORD(v2) = v2->sendReceiptSerial; /*0x1410bd77c*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_sendReceiptSerialMutex->criticalSection); /*0x1410bd785*/
  return (unsigned int)v2; /*0x1410bd78c*/
}

// Address: 0x1410bd7a0 | Name: ?GetNumberOfAddresses@RakPeer@RakNet@@UEAAIXZ
__int64 __fastcall RakNet::RakPeer::GetNumberOfAddresses(RakNet::RakPeer *this)
{
  unsigned int v2; // ebx

  v2 = 0; /*0x1410bd7bb*/
  if ( RakNet::SystemAddress::operator!=(this: this->ipList, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bd7c4*/
  {
    do /*0x1410bd7f1*/
      ++v2; /*0x1410bd7d0*/
    while ( RakNet::SystemAddress::operator!=(this: &this->ipList[v2], right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ); /*0x1410bd7f1*/
  }
  return v2; /*0x1410bd7f5*/
}

// Address: 0x1410bd810 | Name: ?GetOfflinePingResponse@RakPeer@RakNet@@UEAAXPEAPEADPEAI@Z
void __fastcall RakNet::RakPeer::GetOfflinePingResponse(RakNet::RakPeer *this, char **data, unsigned int *length)
{
  rtc::CriticalSection::Enter(lpCriticalSection: &this->rakPeerMutexes[1].criticalSection); /*0x1410bd835*/
  *data = (char *)this->offlinePingResponse.GetData(this: &this->offlinePingResponse); /*0x1410bd845*/
  *length = this->offlinePingResponse.GetNumberOfBytesUsed(this: &this->offlinePingResponse); /*0x1410bd85a*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->rakPeerMutexes[1].criticalSection); /*0x1410bd872*/
}

// Address: 0x1410bd880 | Name: ?GetPerSecTxBwStatistics@RakPeer@RakNet@@UEBA_NUSystemAddress@2@AEAUTxBwData@2@@Z
char __fastcall RakNet::RakPeer::GetPerSecTxBwStatistics(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *systemAddress,
        RakNet::TxBwData *perSecTxBwStats)
{
  __int128 v4; // xmm1
  unsigned int v6; // ebx
  int v7; // edi
  __int64 v8; // r14
  RakNet::RakPeer::RemoteSystemStruct *v9; // rcx
  RakNet::SystemAddress right; // [rsp+20h] [rbp-28h] BYREF

  v4 = *((_OWORD *)&systemAddress->address.addr4 + 1); /*0x1410bd8a3*/
  *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&systemAddress->address.addr6.sin6_family; /*0x1410bd8b1*/
  *((_OWORD *)&right.address.addr4 + 1) = v4; /*0x1410bd8b5*/
  if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bd8c0*/
    return 0; /*0x1410bd8c0*/
  v6 = 0; /*0x1410bd8c6*/
  v7 = -1; /*0x1410bd8c8*/
  if ( this->maximumNumberOfPeers == 0 ) /*0x1410bd8d1*/
    return 0; /*0x1410bd8d1*/
  do /*0x1410bd925*/
  {
    v8 = (int)v6; /*0x1410bd8f3*/
    if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v8].systemAddress, &right) != 0 ) /*0x1410bd904*/
    {
      if ( this->remoteSystemList[v8].isActive._Storage._Value ) /*0x1410bd90d*/
      {
        v9 = &this->remoteSystemList[v8]; /*0x1410bd98d*/
        goto LABEL_10; /*0x1410bd990*/
      }
      if ( v7 == -1 ) /*0x1410bd91a*/
        v7 = v6; /*0x1410bd91a*/
    }
    ++v6; /*0x1410bd921*/
  }
  while ( v6 < this->maximumNumberOfPeers ); /*0x1410bd925*/
  if ( v7 == -1 ) /*0x1410bd92a*/
    return 0; /*0x1410bd92a*/
  v9 = &this->remoteSystemList[v7]; /*0x1410bd936*/
LABEL_10:
  if ( v9 == nullptr || this->endThreads._Storage._Value ) /*0x1410bd942*/
    return 0; /*0x1410bd992*/
  *(_OWORD *)&perSecTxBwStats->availableCapacity = *(_OWORD *)&v9->reliabilityLayer.statistics.perSecTxBwData.totalAvailableCapacity; /*0x1410bd954*/
  *(_OWORD *)&perSecTxBwStats->reliablePackets = *(_OWORD *)&v9->reliabilityLayer.statistics.perSecTxBwData.reliablePacketBytesRe; /*0x1410bd95f*/
  *(_OWORD *)&perSecTxBwStats->unreliablePackets = *(_OWORD *)&v9->reliabilityLayer.statistics.perSecTxBwData.txBwInfluencers.totalGetTxBwCount; /*0x1410bd96a*/
  *(_OWORD *)&perSecTxBwStats->txBwInfluencers.nonZeroTargetSpeedStartTimeCount = *(_OWORD *)&v9->reliabilityLayer.statistics.perSecTxBwData.txBwInfluencers.uncappedByteAllowanceFromTargetSpeed; /*0x1410bd975*/
  *(_OWORD *)&perSecTxBwStats->txBwInfluencers.bwCappedDueTo2xTargetSpeedCount = *(_OWORD *)&v9->reliabilityLayer.statistics.perSecTxBwData.txBwInfluencers.bwcappedDueToMaxBytesInFlightCount; /*0x1410bd980*/
  return 1; /*0x1410bd994*/
}

// Address: 0x1410bd9b0 | Name: ?GetPerSecTxBwStatistics_deprecated@RakPeer@RakNet@@UEBA_NUSystemAddress@2@AEAUTxBwStatistics_deprecated@2@@Z
char __fastcall RakNet::RakPeer::GetPerSecTxBwStatistics_deprecated(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *systemAddress,
        RakNet::TxBwStatistics_deprecated *perSecTxBwStats)
{
  __int128 v4; // xmm1
  unsigned int v6; // ebx
  int v7; // edi
  __int64 v8; // r14
  RakNet::RakPeer::RemoteSystemStruct *v9; // rcx
  RakNet::SystemAddress right; // [rsp+20h] [rbp-28h] BYREF

  v4 = *((_OWORD *)&systemAddress->address.addr4 + 1); /*0x1410bd9d3*/
  *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&systemAddress->address.addr6.sin6_family; /*0x1410bd9e1*/
  *((_OWORD *)&right.address.addr4 + 1) = v4; /*0x1410bd9e5*/
  if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bd9f0*/
    return 0; /*0x1410bd9f0*/
  v6 = 0; /*0x1410bd9f6*/
  v7 = -1; /*0x1410bd9f8*/
  if ( this->maximumNumberOfPeers == 0 ) /*0x1410bda01*/
    return 0; /*0x1410bda01*/
  do /*0x1410bda55*/
  {
    v8 = (int)v6; /*0x1410bda23*/
    if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v8].systemAddress, &right) != 0 ) /*0x1410bda34*/
    {
      if ( this->remoteSystemList[v8].isActive._Storage._Value ) /*0x1410bda3d*/
      {
        v9 = &this->remoteSystemList[v8]; /*0x1410bda9c*/
        goto LABEL_10; /*0x1410bda9f*/
      }
      if ( v7 == -1 ) /*0x1410bda4a*/
        v7 = v6; /*0x1410bda4a*/
    }
    ++v6; /*0x1410bda51*/
  }
  while ( v6 < this->maximumNumberOfPeers ); /*0x1410bda55*/
  if ( v7 == -1 ) /*0x1410bda5a*/
    return 0; /*0x1410bda5a*/
  v9 = &this->remoteSystemList[v7]; /*0x1410bda66*/
LABEL_10:
  if ( v9 == nullptr || this->endThreads._Storage._Value ) /*0x1410bda72*/
    return 0; /*0x1410bdaa1*/
  *(_OWORD *)&perSecTxBwStats->availableCapacity = *(_OWORD *)&v9->reliabilityLayer.statistics.perSecTxBw_deprecated.allBytes; /*0x1410bda84*/
  *(_OWORD *)&perSecTxBwStats->reliablePacketBytesRe = *(_OWORD *)&v9->reliabilityLayer.statistics.perSecTxBw_deprecated.reliablePacketsRe; /*0x1410bda8f*/
  return 1; /*0x1410bdaa3*/
}

// Address: 0x1410bdac0 | Name: ?GetRakNetHandshakeStartTimeMs@RakPeer@RakNet@@UEAAXAEAI@Z
void __fastcall RakNet::RakPeer::GetRakNetHandshakeStartTimeMs(RakNet::RakPeer *this, unsigned int *timeMs)
{
  *timeMs = this->raknetHandshakeStartTimeMs._Storage._Value; /*0x1410bdac7*/
}

// Address: 0x1410bdad0 | Name: ?GetRakNetJoinRxStats@RakPeer@RakNet@@UEAAXUAddressOrGUID@2@AEAURakNetJoinRxStats@2@@Z
void __fastcall RakNet::RakPeer::GetRakNetJoinRxStats(
        RakNet::RakPeer *this,
        const RakNet::AddressOrGUID *systemIdentifier,
        RakNet::RakNetJoinRxStats *raknetJoinRxStats)
{
  RakNet::RakPeer::RemoteSystemStruct *RemoteSystem; // rax
  RakNet::AddressOrGUID v7; // [rsp+20h] [rbp-38h] BYREF

  RakNet::RakNetGUID::RakNetGUID(this: &v7.rakNetGuid); /*0x1410bdaed*/
  RakNet::SystemAddress::SystemAddress(this: &v7.systemAddress); /*0x1410bdaf7*/
  v7.rakNetGuid.g = systemIdentifier->rakNetGuid.g; /*0x1410bdb03*/
  v7.rakNetGuid.systemIndex = systemIdentifier->rakNetGuid.systemIndex; /*0x1410bdb11*/
  RakNet::SystemAddress::operator=(this: &v7.systemAddress, input: &systemIdentifier->systemAddress); /*0x1410bdb16*/
  RemoteSystem = RakNet::RakPeer::GetRemoteSystem( /*0x1410bdb29*/
                   this,
                   systemIdentifier: &v7,
                   calledFromNetworkThread: false,
                   onlyActive: false);
  if ( RemoteSystem != nullptr ) /*0x1410bdb31*/
  {
    *(_OWORD *)&raknetJoinRxStats->bytes = *(_OWORD *)&RemoteSystem->reliabilityLayer.raknetJoinRxStats.packets; /*0x1410bdb3a*/
    *(_OWORD *)&raknetJoinRxStats->ignoredBytes = *(_OWORD *)&RemoteSystem->reliabilityLayer.raknetJoinRxStats.ignoredPackets; /*0x1410bdb44*/
    raknetJoinRxStats->timeLastNonReTxJoinPacketReceivedMs = *((_DWORD *)&RemoteSystem->reliabilityLayer.raknetJoinRxStats /*0x1410bdb4e*/
                                                             + 9);
  }
}

// Address: 0x1410bdb70 | Name: ?GetReceiveBufferSize@RakPeer@RakNet@@UEAAIXZ
__int64 __fastcall RakNet::RakPeer::GetReceiveBufferSize(RakNet::RakPeer *this)
{
  unsigned int head; // eax
  unsigned int tail; // ebx
  unsigned int v4; // ebx

  rtc::CriticalSection::Enter(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410bdb89*/
  head = this->packetReturnQueue.head; /*0x1410bdb8e*/
  tail = this->packetReturnQueue.tail; /*0x1410bdb94*/
  if ( head > tail ) /*0x1410bdb9c*/
    v4 = this->packetReturnQueue.allocation_size - head + tail; /*0x1410bdbaa*/
  else
    v4 = tail - head; /*0x1410bdb9e*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410bdbb3*/
  return v4; /*0x1410bdbb8*/
}

// Address: 0x1410bdbd0 | Name: ?GetRemoteSystem@RakPeer@RakNet@@QEBAPEAURemoteSystemStruct@12@UAddressOrGUID@2@_N1@Z
RakNet::RakPeer::RemoteSystemStruct *__fastcall RakNet::RakPeer::GetRemoteSystem(
        RakNet::RakPeer *this,
        RBX::json::ArrayIterator *systemIdentifier,
        bool calledFromNetworkThread,
        bool onlyActive)
{
  __int128 v9; // xmm1
  RakNet::SystemAddress v10; // [rsp+30h] [rbp-28h] BYREF

  if ( StudioResourceId::operator!=( /*0x1410bdbfc*/
         this: systemIdentifier,
         rhs: (const RBX::json::ArrayIterator *)&RakNet::UNASSIGNED_RAKNET_GUID_30) )
  {
    *(_OWORD *)&v10.address.addr6.sin6_family = *(_OWORD *)&systemIdentifier->it; /*0x1410bdc14*/
    return RakNet::RakPeer::GetRemoteSystemFromGUID(this, guid: (const RakNet::RakNetGUID *)&v10, onlyActive); /*0x1410bdc19*/
  }
  else
  {
    v9 = *(_OWORD *)&systemIdentifier[4].it; /*0x1410bdc2c*/
    *(_OWORD *)&v10.address.addr6.sin6_family = *(_OWORD *)&systemIdentifier[2].it; /*0x1410bdc3d*/
    *((_OWORD *)&v10.address.addr4 + 1) = v9; /*0x1410bdc42*/
    return RakNet::RakPeer::GetRemoteSystemFromSystemAddress( /*0x1410bdc47*/
             this,
             systemAddress: &v10,
             calledFromNetworkThread,
             onlyActive,
             rssIndexHint: -1);
  }
}

// Address: 0x1410bdc70 | Name: ?GetRemoteSystemFromGUID@RakPeer@RakNet@@IEBAPEAURemoteSystemStruct@12@URakNetGUID@2@_N@Z
RakNet::RakPeer::RemoteSystemStruct *__fastcall RakNet::RakPeer::GetRemoteSystemFromGUID(
        RakNet::RakPeer *this,
        const RakNet::RakNetGUID *guid,
        bool onlyActive)
{
  unsigned int v6; // ebx
  __int64 v7; // rsi

  if ( StudioResourceId::operator==(lhs: guid, rhs: &RakNet::UNASSIGNED_RAKNET_GUID_30) ) /*0x1410bdc9e*/
    return nullptr; /*0x1410bdc9e*/
  v6 = 0; /*0x1410bdca7*/
  if ( this->maximumNumberOfPeers == 0 ) /*0x1410bdcad*/
    return nullptr; /*0x1410bdcf5*/
  while ( 1 ) /*0x1410bdcc3*/
  {
    v7 = v6; /*0x1410bdcc3*/
    if ( StudioResourceId::operator==(lhs: &this->remoteSystemList[v7].guid, rhs: guid) /*0x1410bdce2*/
      && (!onlyActive || this->remoteSystemList[v7].isActive._Storage._Value) )
    {
      break; /*0x1410bdce9*/
    }
    if ( ++v6 >= this->maximumNumberOfPeers ) /*0x1410bdcf3*/
      return nullptr; /*0x1410bdcf3*/
  }
  return &this->remoteSystemList[v7]; /*0x1410bdcf7*/
}

// Address: 0x1410bdd20 | Name: ?GetRemoteSystemFromSystemAddress@RakPeer@RakNet@@IEBAPEAURemoteSystemStruct@12@USystemAddress@2@_N1H@Z
RakNet::RakPeer::RemoteSystemStruct *__fastcall RakNet::RakPeer::GetRemoteSystemFromSystemAddress(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *systemAddress,
        bool calledFromNetworkThread,
        bool onlyActive,
        const int rssIndexHint)
{
  unsigned int RemoteSystemIndex; // eax
  __int64 v10; // rdx
  unsigned __int16 maximumNumberOfPeers; // cx
  unsigned int v13; // ebx
  int v14; // edi
  signed int v15; // ebp
  __int64 v16; // r14

  if ( RakNet::SystemAddress::operator==(this: systemAddress, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410bdd5b*/
  {
    if ( calledFromNetworkThread ) /*0x1410bdd63*/
    {
      RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, sa: systemAddress); /*0x1410bdd6b*/
      if ( RemoteSystemIndex != -1 ) /*0x1410bdd73*/
      {
        v10 = RemoteSystemIndex; /*0x1410bdd7b*/
        if ( !onlyActive || this->remoteSystemList[v10].isActive._Storage._Value ) /*0x1410bdd8e*/
          return &this->remoteSystemList[v10]; /*0x1410bdda6*/
      }
    }
    else
    {
      maximumNumberOfPeers = this->maximumNumberOfPeers; /*0x1410bddab*/
      v13 = 0; /*0x1410bddaf*/
      v14 = -1; /*0x1410bddb1*/
      if ( maximumNumberOfPeers != 0 ) /*0x1410bddb9*/
      {
        do /*0x1410bde21*/
        {
          if ( rssIndexHint == -1 ) /*0x1410bddc8*/
            v15 = v13; /*0x1410bddd9*/
          else
            v15 = (v13 + rssIndexHint) % maximumNumberOfPeers; /*0x1410bddd5*/
          v16 = v15; /*0x1410bddec*/
          if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v16].systemAddress, right: systemAddress) != 0 ) /*0x1410bddfd*/
          {
            if ( this->remoteSystemList[v16].isActive._Storage._Value ) /*0x1410bde06*/
              return &this->remoteSystemList[v16]; /*0x1410bde4a*/
            if ( v14 == -1 ) /*0x1410bde13*/
              v14 = v15; /*0x1410bde13*/
          }
          ++v13; /*0x1410bde1a*/
          maximumNumberOfPeers = this->maximumNumberOfPeers; /*0x1410bde1c*/
        }
        while ( v13 < maximumNumberOfPeers ); /*0x1410bde21*/
        if ( v14 != -1 && !onlyActive ) /*0x1410bde2b*/
          return &this->remoteSystemList[v14]; /*0x1410bde3e*/
      }
    }
  }
  return nullptr; /*0x1410bde4e*/
}

// Address: 0x1410bde70 | Name: ?GetRemoteSystemIndex@RakPeer@RakNet@@IEBAIAEBUSystemAddress@2@@Z
__int64 __fastcall RakNet::RakPeer::GetRemoteSystemIndex(RakNet::RakPeer *this, const RakNet::SystemAddress *sa)
{
  RakNet::RemoteSystemIndex *v4; // rbx

  v4 = this->remoteSystemLookup[RakNet::SystemAddress::ToInteger(sa) % (8 * (unsigned int)this->maximumNumberOfPeers)]; /*0x1410bdea2*/
  if ( v4 == nullptr ) /*0x1410bdea9*/
    return 0xFFFFFFFFLL; /*0x1410bdedc*/
  while ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v4->index].systemAddress, right: sa) == 0 ) /*0x1410bded1*/
  {
    v4 = v4->next; /*0x1410bded3*/
    if ( v4 == nullptr ) /*0x1410bdeda*/
      return 0xFFFFFFFFLL; /*0x1410bdeda*/
  }
  return v4->index; /*0x1410bdee1*/
}

// Address: 0x1410bdf10 | Name: ?GetSockets@RakPeer@RakNet@@UEAAXAEAV?$List@V?$shared_ptr@URakNetSocket@RakNet@@@std@@@DataStructures@@@Z
void __fastcall RakNet::RakPeer::GetSockets(
        RakNet::RakPeer *this,
        DataStructures::List<std::shared_ptr<RakNet::RakNetSocket> > *sockets)
{
  std::shared_ptr<RakNet::RakNetSocket> *listArray; // rcx
  std::_Ref_count_base **p_Rep; // rdi
  __int64 v6; // rcx
  RakNet::RakPeer::BufferedCommandStruct *v7; // rax
  signed __int32 v8; // eax
  HANDLE event; // rax
  std::_Ref_count_base *Rep; // rdi
  DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::MemoryWithPage *v11; // r14
  unsigned int head; // eax
  unsigned int v13; // eax
  unsigned int allocation_size; // ecx
  RakNet::RakPeer::SocketQueryOutput **array; // rsi
  __int64 v16; // rax
  RakNet::RakPeer::SocketQueryOutput *v17; // rsi
  std::shared_ptr<RakNet::RakNetSocket> *v18; // rcx
  char *v19; // rdi
  __int64 v20; // rcx
  _BYTE v21[32]; // [rsp+0h] [rbp-198h] BYREF
  RakNet::RakPeer::BufferedCommandStruct bcs; // [rsp+20h] [rbp-178h] BYREF
  std::shared_ptr<RakNet::RakNetSocket> output; // [rsp+C0h] [rbp-D8h] BYREF
  RakNet::RakPeer::BufferedCommandStruct v24; // [rsp+D0h] [rbp-C8h] BYREF

  if ( sockets->allocation_size != 0 ) /*0x1410bdf36*/
  {
    listArray = sockets->listArray; /*0x1410bdf38*/
    if ( sockets->listArray != nullptr ) /*0x1410bdf3e*/
    {
      __wind /*0xf1c00000000000a8*/
      {
        p_Rep = &listArray[-1]._Rep; /*0x1410bdf40*/
        `eh vector destructor iterator'( /*0x1410bdf53*/
          ptr: listArray,
          size: 0x10u,
          count: (unsigned __int64)listArray[-1]._Rep,
          destructor: (void (__fastcall *)(void *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>);
        operator delete(ptr: p_Rep); /*0x1410bdf66*/
      }
      __unwind
      {
        __std_terminate(a1: v6, a2: v21); /*0x142f39fa8*/
      }
    }
    *(_QWORD *)&sockets->list_size = 0; /*0x1410bdf6c*/
    sockets->listArray = nullptr; /*0x1410bdf70*/
  }
  if ( FFlag::BufferedCommandsCircular.value ) /*0x1410bdf7a*/
  {
    __wind /*0xf1c0000000000078*/
    {
      bcs.stream = 0; /*0x1410bdf83*/
      RakNet::RakNetGUID::RakNetGUID(this: &bcs.systemIdentifier.rakNetGuid); /*0x1410bdf8e*/
      RakNet::SystemAddress::SystemAddress(this: &bcs.systemIdentifier.systemAddress); /*0x1410bdf98*/
      bcs.data = nullptr; /*0x1410bdf9d*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&bcs); /*0xf1c0000000000088*/
    }
    __wind /*0xf1c0000000000090*/
    {
      bcs.command = BCS_GET_SOCKET; /*0x1410bdfa5*/
      bcs.systemIdentifier.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410bdfb7*/
      RakNet::SystemAddress::operator=( /*0x1410bdfd4*/
        this: &bcs.systemIdentifier.systemAddress,
        input: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30);
      bcs.data = nullptr; /*0x1410bdfd9*/
      boost::detail::basic_timed_mutex::lock(this: &this->bufferedCommandsMutex); /*0x1410bdfeb*/
      v7 = RakNet::RakPeer::BufferedCommandStruct::BufferedCommandStruct(this: &v24, __that: &bcs); /*0x1410bdffd*/
      RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::push_back( /*0x1410be00c*/
        this: &this->bufferedCommandsCircular,
        item: v7);
      v8 = _InterlockedExchangeAdd(&this->bufferedCommandsMutex.active_count, 0x80000000); /*0x1410be016*/
      if ( (v8 & 0x40000000) == 0 /*0x1410be02c*/
        && v8 != 0x80000000
        && !_interlockedbittestandset(&this->bufferedCommandsMutex.active_count, 0x1Eu) )
      {
        event = boost::detail::basic_timed_mutex::get_event(this: &this->bufferedCommandsMutex); /*0x1410be031*/
        SetEvent(hEvent: event); /*0x1410be039*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&bcs); /*0xf1c0000000000070*/
    }
    Rep = bcs.stream._Rep; /*0x1410be040*/
    if ( bcs.stream._Rep != nullptr /*0x1410be05d*/
      && _InterlockedExchangeAdd((volatile signed __int32 *)&bcs.stream._Rep->_Uses, 0xFFFFFFFF) == 1 )
    {
      Rep->_Destroy(this: Rep); /*0x1410be069*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410be073*/
        Rep->_Delete_this(this: Rep); /*0x1410be07f*/
    }
  }
  else
  {
    rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedCommands_deprecated.memoryPoolMutex.criticalSection); /*0x1410be08e*/
    v11 = DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::Allocate( /*0x1410be0ac*/
            this: &this->bufferedCommands_deprecated.memoryPool,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
            line: 0xBBEu);
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedCommands_deprecated.memoryPoolMutex.criticalSection); /*0x1410be0b6*/
    v11->userMemory.stream._Ptr = nullptr; /*0x1410be0c3*/
    v11->userMemory.stream._Rep = nullptr; /*0x1410be0c6*/
    __wind /*0xf1c0000000000060*/
    {
      RakNet::RakNetGUID::RakNetGUID(this: &v11->userMemory.systemIdentifier.rakNetGuid); /*0x1410be0ce*/
      RakNet::SystemAddress::SystemAddress(this: &v11->userMemory.systemIdentifier.systemAddress); /*0x1410be0d7*/
      v11->userMemory.data = nullptr; /*0x1410be0dc*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)v11); /*0xf1c0000000000058*/
    }
    v11->userMemory.command = BCS_GET_SOCKET; /*0x1410be0e0*/
    v11->userMemory.systemIdentifier.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410be0f2*/
    RakNet::SystemAddress::operator=( /*0x1410be10d*/
      this: &v11->userMemory.systemIdentifier.systemAddress,
      input: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30);
    v11->userMemory.data = nullptr; /*0x1410be112*/
    DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::BufferedCommandStruct>::Push( /*0x1410be120*/
      this: (DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput> *)&this->bufferedCommands_deprecated,
      s: (RakNet::RakPeer::SocketQueryOutput *)v11);
  }
  output = 0; /*0x1410be128*/
  __wind /*0xf1c0000000000048*/
  {
    if ( !this->isMainLoopThreadActive._Storage._Value ) /*0x1410be138*/
      return; /*0x1410be138*/
    do /*0x1410be142*/
    {
      RESTRICTED_QtUtilities::sleep(dwMilliseconds: 0); /*0x1410be142*/
      rtc::CriticalSection::Enter(lpCriticalSection: &this->socketQueryOutput.queueMutex.criticalSection); /*0x1410be14e*/
      head = this->socketQueryOutput.queue.head; /*0x1410be153*/
      if ( head == this->socketQueryOutput.queue.tail ) /*0x1410be15f*/
      {
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->socketQueryOutput.queueMutex.criticalSection); /*0x1410be168*/
      }
      else
      {
        v13 = head + 1; /*0x1410be16f*/
        this->socketQueryOutput.queue.head = v13; /*0x1410be171*/
        allocation_size = this->socketQueryOutput.queue.allocation_size; /*0x1410be177*/
        if ( v13 == allocation_size ) /*0x1410be17f*/
        {
          this->socketQueryOutput.queue.head = 0; /*0x1410be181*/
          array = this->socketQueryOutput.queue.array; /*0x1410be188*/
          v16 = allocation_size - 1; /*0x1410be18f*/
        }
        else
        {
          array = this->socketQueryOutput.queue.array; /*0x1410be194*/
          if ( v13 != 0 ) /*0x1410be19d*/
            v16 = v13 - 1; /*0x1410be1a4*/
          else
            v16 = allocation_size - 1; /*0x1410be19f*/
        }
        v17 = array[v16]; /*0x1410be1a6*/
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->socketQueryOutput.queueMutex.criticalSection); /*0x1410be1b1*/
        if ( v17 != nullptr ) /*0x1410be1b9*/
        {
          DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::operator=( /*0x1410be1d3*/
            this: sockets,
            original_copy: &v17->sockets);
          if ( v17->sockets.allocation_size != 0 ) /*0x1410be1dc*/
          {
            v18 = v17->sockets.listArray; /*0x1410be1de*/
            if ( v17->sockets.listArray != nullptr ) /*0x1410be1e4*/
            {
              __wind /*0xf1c000000000003c*/
              {
                v19 = (char *)&v18[-1]._Rep; /*0x1410be1e6*/
                `eh vector destructor iterator'( /*0x1410be1f9*/
                  ptr: v18,
                  size: 0x10u,
                  count: (unsigned __int64)v18[-1]._Rep,
                  destructor: (void (__fastcall *)(void *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>);
                operator delete(ptr: v19); /*0x1410be20c*/
              }
              __unwind
              {
                __std_terminate(a1: v20, a2: v21); /*0xf1c000000000001c*/
              }
            }
            *(_QWORD *)&v17->sockets.list_size = 0; /*0x1410be212*/
            v17->sockets.listArray = nullptr; /*0x1410be216*/
          }
          rtc::CriticalSection::Enter(lpCriticalSection: &this->socketQueryOutput.memoryPoolMutex.criticalSection); /*0x1410be220*/
          DataStructures::MemoryPool<RakNet::RakPeer::SocketQueryOutput>::Release( /*0x1410be23c*/
            this: &this->socketQueryOutput.memoryPool,
            m: (DataStructures::MemoryPool<RakNet::RakPeer::SocketQueryOutput>::MemoryWithPage *)v17,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
            line: 0xBD4u);
          RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->socketQueryOutput.memoryPoolMutex.criticalSection); /*0x1410be248*/
          return; /*0x1410be248*/
        }
      }
    }
    while ( this->isMainLoopThreadActive._Storage._Value ); /*0x1410be142*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&output); /*0xf1c0000000000028*/
  }
}

// Address: 0x1410be270 | Name: ?GetSplitMessageProgressInterval@RakPeer@RakNet@@UEBAHXZ
__int64 __fastcall RakNet::RakPeer::GetSplitMessageProgressInterval(RakNet::RakPeer *this)
{
  return (unsigned int)this->splitMessageProgressInterval; /*0x1410be276*/
}

// Address: 0x1410be280 | Name: ?GetStatistics@RakPeer@RakNet@@UEAAPEAURakNetStatistics@2@USystemAddress@2@PEAU32@@Z
RakNet::RakNetStatistics *__fastcall RakNet::RakPeer::GetStatistics(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *systemAddress,
        RakNet::RakNetStatistics *rns)
{
  RakNet::RakNetStatistics *v4; // rsi
  char v6; // r15
  unsigned __int16 i; // r14
  __int64 v8; // rdx
  RakNet::RakPeer::RemoteSystemStruct *remoteSystemList; // rcx
  RakNet::RakNetStatistics *v10; // rax
  RakNet::RakNetStatistics *p_rnsTemp; // rcx
  __int64 j; // rdx
  __int128 v13; // xmm0
  __int128 v14; // xmm1
  __int128 v15; // xmm0
  __int128 v16; // xmm1
  __int128 v17; // xmm0
  __int128 v18; // xmm1
  __int128 v19; // xmm0
  __int128 v20; // xmm1
  __int128 v21; // xmm1
  __int128 v22; // xmm0
  __int128 v23; // xmm1
  unsigned int v24; // eax
  unsigned __int64 v25; // rcx
  unsigned int v26; // eax
  unsigned int v27; // eax
  unsigned __int64 v28; // rax
  __int128 v30; // xmm1
  unsigned int v31; // ebx
  int v32; // r14d
  __int64 v33; // r15
  RakNet::RakPeer::RemoteSystemStruct *v34; // rcx
  RakNet::RakNetStatistics rnsTemp; // [rsp+20h] [rbp-E0h] BYREF
  RakNet::SystemAddress right; // [rsp+1E0h] [rbp+E0h] BYREF

  v4 = &staticStatistics; /*0x1410be2a6*/
  if ( rns != nullptr ) /*0x1410be2bd*/
    v4 = rns; /*0x1410be2bd*/
  if ( RakNet::SystemAddress::operator==(this: systemAddress, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410be2c8*/
  {
    v6 = 0; /*0x1410be2d0*/
    for ( i = 0; i < this->maximumNumberOfPeers; ++i ) /*0x1410be2db*/
    {
      v8 = i; /*0x1410be2e5*/
      if ( this->remoteSystemList[v8].isActive._Storage._Value ) /*0x1410be2f3*/
      {
        remoteSystemList = this->remoteSystemList; /*0x1410be300*/
        memset(&rnsTemp, 0, 56); /*0x1410be333*/
        memset(&rnsTemp.ds, 0, 216); /*0x1410be357*/
        RakNet::ReliabilityLayer::GetStatistics( /*0x1410be3a7*/
          this: (RakNet::ReliabilityLayer *)((char *)&remoteSystemList->reliabilityLayer.rbxSessionCrypto._Ptr + v8 * 4600 + 4),
          rns: &rnsTemp);
        if ( v6 != 0 ) /*0x1410be3af*/
        {
          v4->messageInSendBuffer[0] += rnsTemp.messageInSendBuffer[0]; /*0x1410be43e*/
          v24 = rnsTemp.messageInSendBuffer[1]; /*0x1410be444*/
          v25 = rnsTemp.valueOverLastSecond[6]; /*0x1410be454*/
          v4->bytesInSendBuffer[0] = rnsTemp.bytesInSendBuffer[0] + v4->bytesInSendBuffer[0]; /*0x1410be459*/
          v4->messageInSendBuffer[1] += v24; /*0x1410be461*/
          v26 = rnsTemp.messageInSendBuffer[2]; /*0x1410be467*/
          v4->bytesInSendBuffer[1] = rnsTemp.bytesInSendBuffer[1] + v4->bytesInSendBuffer[1]; /*0x1410be477*/
          v4->messageInSendBuffer[2] += v26; /*0x1410be47f*/
          v27 = rnsTemp.messageInSendBuffer[3]; /*0x1410be492*/
          v4->bytesInSendBuffer[2] = rnsTemp.bytesInSendBuffer[2] + v4->bytesInSendBuffer[2]; /*0x1410be495*/
          v4->messageInSendBuffer[3] += v27; /*0x1410be49d*/
          v28 = rnsTemp.valueOverLastSecond[0]; /*0x1410be4a3*/
          v4->bytesInSendBuffer[3] = rnsTemp.bytesInSendBuffer[3] + v4->bytesInSendBuffer[3]; /*0x1410be4b5*/
          v4->valueOverLastSecond[0] += v28; /*0x1410be4bd*/
          v4->runningTotal[0] += rnsTemp.runningTotal[0]; /*0x1410be4c5*/
          v4->valueOverLastSecond[1] += rnsTemp.valueOverLastSecond[1]; /*0x1410be4ce*/
          v4->runningTotal[1] += rnsTemp.runningTotal[1]; /*0x1410be4d7*/
          v4->valueOverLastSecond[2] += rnsTemp.valueOverLastSecond[2]; /*0x1410be4e0*/
          v4->runningTotal[2] += rnsTemp.runningTotal[2]; /*0x1410be4e9*/
          v4->valueOverLastSecond[3] += rnsTemp.valueOverLastSecond[3]; /*0x1410be4f2*/
          v4->runningTotal[3] += rnsTemp.runningTotal[3]; /*0x1410be4fb*/
          v4->valueOverLastSecond[4] += rnsTemp.valueOverLastSecond[4]; /*0x1410be504*/
          v4->runningTotal[4] += rnsTemp.runningTotal[4]; /*0x1410be50d*/
          v4->valueOverLastSecond[5] += rnsTemp.valueOverLastSecond[5]; /*0x1410be516*/
          v4->runningTotal[5] += rnsTemp.runningTotal[5]; /*0x1410be51e*/
          v4->valueOverLastSecond[6] += v25; /*0x1410be522*/
          v4->runningTotal[6] += rnsTemp.runningTotal[6]; /*0x1410be52a*/
        }
        else
        {
          v10 = v4; /*0x1410be3b5*/
          p_rnsTemp = &rnsTemp; /*0x1410be3b8*/
          for ( j = 3; j != 0; --j ) /*0x1410be3bd*/
          {
            v10 = (RakNet::RakNetStatistics *)((char *)v10 + 128); /*0x1410be3c2*/
            v13 = *(_OWORD *)p_rnsTemp->valueOverLastSecond; /*0x1410be3c9*/
            v14 = *(_OWORD *)&p_rnsTemp->valueOverLastSecond[2]; /*0x1410be3cc*/
            p_rnsTemp = (RakNet::RakNetStatistics *)((char *)p_rnsTemp + 128); /*0x1410be3d0*/
            *(_OWORD *)&v10[-1].ds.totalJoinDataNakSize_DEPRECATED = v13; /*0x1410be3d7*/
            v15 = *(_OWORD *)&p_rnsTemp[-1].perSecTxBw_deprecated.unreliablePacketBytes; /*0x1410be3db*/
            *(_OWORD *)&v10[-1].perSecTxBw_deprecated.reliablePacketBytes = v14; /*0x1410be3df*/
            v16 = *(_OWORD *)&p_rnsTemp[-1].perSecTxBwData.allBytes; /*0x1410be3e3*/
            *(_OWORD *)&v10[-1].perSecTxBw_deprecated.unreliablePacketBytes = v15; /*0x1410be3e7*/
            v17 = *(_OWORD *)&p_rnsTemp[-1].perSecTxBwData.reliablePacketsRe; /*0x1410be3eb*/
            *(_OWORD *)&v10[-1].perSecTxBwData.allBytes = v16; /*0x1410be3ef*/
            v18 = *(_OWORD *)&p_rnsTemp[-1].perSecTxBwData.txBwInfluencers.bwLimitedByAppCount; /*0x1410be3f3*/
            *(_OWORD *)&v10[-1].perSecTxBwData.reliablePacketsRe = v17; /*0x1410be3f7*/
            v19 = *(_OWORD *)&p_rnsTemp[-1].perSecTxBwData.txBwInfluencers.bytesGivenByTargetSpeed; /*0x1410be3fb*/
            *(_OWORD *)&v10[-1].perSecTxBwData.txBwInfluencers.bwLimitedByAppCount = v18; /*0x1410be3ff*/
            v20 = *(_OWORD *)&p_rnsTemp[-1].perSecTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount; /*0x1410be403*/
            *(_OWORD *)&v10[-1].perSecTxBwData.txBwInfluencers.bytesGivenByTargetSpeed = v19; /*0x1410be407*/
            *(_OWORD *)&v10[-1].perSecTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount = v20; /*0x1410be40b*/
          }
          v6 = 1; /*0x1410be418*/
          v21 = *(_OWORD *)&p_rnsTemp->valueOverLastSecond[2]; /*0x1410be41b*/
          *(_OWORD *)v10->valueOverLastSecond = *(_OWORD *)p_rnsTemp->valueOverLastSecond; /*0x1410be41f*/
          v22 = *(_OWORD *)&p_rnsTemp->valueOverLastSecond[4]; /*0x1410be422*/
          *(_OWORD *)&v10->valueOverLastSecond[2] = v21; /*0x1410be426*/
          v23 = *(_OWORD *)&p_rnsTemp->valueOverLastSecond[6]; /*0x1410be42a*/
          *(_OWORD *)&v10->valueOverLastSecond[4] = v22; /*0x1410be42e*/
          *(_OWORD *)&v10->valueOverLastSecond[6] = v23; /*0x1410be432*/
        }
      }
    }
    return v4; /*0x1410be53d*/
  }
  else
  {
    v30 = *((_OWORD *)&systemAddress->address.addr4 + 1); /*0x1410be54f*/
    *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&systemAddress->address.addr6.sin6_family; /*0x1410be55a*/
    *((_OWORD *)&right.address.addr4 + 1) = v30; /*0x1410be561*/
    if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410be56f*/
      return nullptr; /*0x1410be56f*/
    v31 = 0; /*0x1410be575*/
    v32 = -1; /*0x1410be577*/
    if ( this->maximumNumberOfPeers == 0 ) /*0x1410be57f*/
      return nullptr; /*0x1410be57f*/
    do /*0x1410be5d9*/
    {
      v33 = (int)v31; /*0x1410be5a5*/
      if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v33].systemAddress, &right) != 0 ) /*0x1410be5b6*/
      {
        if ( this->remoteSystemList[v33].isActive._Storage._Value ) /*0x1410be5bf*/
        {
          v34 = &this->remoteSystemList[v33]; /*0x1410be61b*/
          goto LABEL_22; /*0x1410be61e*/
        }
        if ( v32 == -1 ) /*0x1410be5cd*/
          v32 = v31; /*0x1410be5cd*/
      }
      ++v31; /*0x1410be5d5*/
    }
    while ( v31 < this->maximumNumberOfPeers ); /*0x1410be5d9*/
    if ( v32 == -1 ) /*0x1410be5df*/
      return nullptr; /*0x1410be5df*/
    v34 = &this->remoteSystemList[v32]; /*0x1410be5eb*/
LABEL_22:
    if ( v34 == nullptr || this->endThreads._Storage._Value ) /*0x1410be5f7*/
    {
      return nullptr; /*0x1410be620*/
    }
    else
    {
      RakNet::ReliabilityLayer::GetStatistics( /*0x1410be60a*/
        this: (RakNet::ReliabilityLayer *)((char *)&v34->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
        rns: v4);
      return v4; /*0x1410be60f*/
    }
  }
}

// Address: 0x1410be640 | Name: ?GetStatistics@RakPeer@RakNet@@UEAA_NHPEAURakNetStatistics@2@@Z
char __fastcall RakNet::RakPeer::GetStatistics(RakNet::RakPeer *this, const int index, RakNet::RakNetStatistics *rns)
{
  __int64 v3; // r9

  if ( index >= this->maximumNumberOfPeers ) /*0x1410be64a*/
    return 0; /*0x1410be64a*/
  v3 = index; /*0x1410be64f*/
  if ( !this->remoteSystemList[v3].isActive._Storage._Value ) /*0x1410be665*/
    return 0; /*0x1410be687*/
  RakNet::ReliabilityLayer::GetStatistics( /*0x1410be67b*/
    this: (RakNet::ReliabilityLayer *)((char *)&this->remoteSystemList->reliabilityLayer.rbxSessionCrypto._Ptr + v3 * 4600 + 4),
    rns);
  return 1; /*0x1410be682*/
}

// Address: 0x1410be690 | Name: ?GetSystemAddressFromGuid@RakPeer@RakNet@@UEBA?AUSystemAddress@2@URakNetGUID@2@@Z
RakNet::SystemAddress *__fastcall RakNet::RakPeer::GetSystemAddressFromGuid(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *result,
        const RakNet::RakNetGUID *input)
{
  RakNet::RakPeer_vtbl *v6; // rax
  __int64 systemIndex; // rax
  __int64 v8; // rcx
  RakNet::RakPeer::RemoteSystemStruct *remoteSystemList; // rax
  __int128 v10; // xmm1
  int v11; // ebx
  RakNet::RakPeer::RemoteSystemStruct *v13; // rax
  RakNet::SystemAddress v14; // [rsp+20h] [rbp-28h] BYREF

  if ( StudioResourceId::operator==(lhs: input, rhs: &RakNet::UNASSIGNED_RAKNET_GUID_30) ) /*0x1410be6bd*/
    goto LABEL_11; /*0x1410be6c4*/
  if ( !StudioResourceId::operator==(lhs: input, rhs: &this->myGuid) ) /*0x1410be6db*/
  {
    systemIndex = input->systemIndex; /*0x1410be711*/
    if ( (_WORD)systemIndex != 0xFFFF /*0x1410be73f*/
      && (unsigned __int16)systemIndex < this->maximumNumberOfPeers
      && StudioResourceId::operator==(lhs: &this->remoteSystemList[systemIndex].guid, rhs: input) )
    {
      v8 = input->systemIndex; /*0x1410be74c*/
      remoteSystemList = this->remoteSystemList; /*0x1410be753*/
      *(_OWORD *)&result->address.addr6.sin6_family = *(_OWORD *)&remoteSystemList[v8].systemAddress.address.addr6.sin6_family; /*0x1410be75f*/
      v10 = *((_OWORD *)&remoteSystemList[v8].systemAddress.address.addr4 + 1); /*0x1410be762*/
LABEL_12:
      *((_OWORD *)&result->address.addr4 + 1) = v10; /*0x1410be7c1*/
      return result; /*0x1410be7c1*/
    }
    v11 = 0; /*0x1410be769*/
    if ( this->maximumNumberOfPeers != 0 ) /*0x1410be76f*/
    {
      while ( !StudioResourceId::operator==(lhs: &this->remoteSystemList[v11].guid, rhs: input) ) /*0x1410be7a4*/
      {
        if ( ++v11 >= (unsigned int)this->maximumNumberOfPeers ) /*0x1410be7ae*/
          goto LABEL_11; /*0x1410be7ae*/
      }
      v13 = this->remoteSystemList; /*0x1410be7e3*/
      *(_OWORD *)&result->address.addr6.sin6_family = *(_OWORD *)&v13[v11].systemAddress.address.addr6.sin6_family; /*0x1410be7f6*/
      v10 = *((_OWORD *)&v13[v11].systemAddress.address.addr4 + 1); /*0x1410be7f9*/
      goto LABEL_12; /*0x1410be7fe*/
    }
LABEL_11:
    *(_OWORD *)&result->address.addr6.sin6_family = *(_OWORD *)&RakNet::UNASSIGNED_SYSTEM_ADDRESS_30.address.addr6.sin6_family; /*0x1410be7b0*/
    v10 = *((_OWORD *)&RakNet::UNASSIGNED_SYSTEM_ADDRESS_30.address.addr4 + 1); /*0x1410be7ba*/
    goto LABEL_12; /*0x1410be7ba*/
  }
  v6 = this->__vftable; /*0x1410be6e4*/
  v14 = RakNet::UNASSIGNED_SYSTEM_ADDRESS_30; /*0x1410be6fc*/
  v6->GetInternalID(this, result, a3: &v14, a4: 0); /*0x1410be706*/
  return result; /*0x1410be7c5*/
}

// Address: 0x1410be800 | Name: ?GetSystemAddressFromIndex@RakPeer@RakNet@@UEAA?AUSystemAddress@2@H@Z
RakNet::SystemAddress *__fastcall RakNet::RakPeer::GetSystemAddressFromIndex(
        RakNet::RakPeer *this,
        RakNet::SystemAddress *result,
        int index)
{
  __int64 v3; // r8
  RakNet::RakPeer::RemoteSystemStruct *remoteSystemList; // rax
  __int128 v5; // xmm1

  if ( index >= 0 /*0x1410be83c*/
    && index < this->maximumNumberOfPeers
    && *(&this->remoteSystemList->isActive._Storage._Value + (v3 = index))
    && (remoteSystemList = this->remoteSystemList,
        remoteSystemList[v3].connectMode == (UNVERIFIED_SENDER|DISCONNECT_ASAP)) )
  {
    v5 = *((_OWORD *)&remoteSystemList[v3].systemAddress.address.addr4 + 1); /*0x1410be844*/
    *(_OWORD *)&result->address.addr6.sin6_family = *(_OWORD *)&remoteSystemList[v3].systemAddress.address.addr6.sin6_family; /*0x1410be84d*/
    *((_OWORD *)&result->address.addr4 + 1) = v5; /*0x1410be851*/
    return result; /*0x1410be84a*/
  }
  else
  {
    *result = RakNet::UNASSIGNED_SYSTEM_ADDRESS_30; /*0x1410be868*/
    return result; /*0x1410be85e*/
  }
}

// Address: 0x1410be880 | Name: ?GetSystemList@RakPeer@RakNet@@UEBAXAEAV?$List@USystemAddress@RakNet@@@DataStructures@@AEAV?$List@URakNetGUID@RakNet@@@4@@Z
void __fastcall RakNet::RakPeer::GetSystemList(
        RakNet::RakPeer *this,
        DataStructures::List<RakNet::SystemAddress> *addresses,
        DataStructures::List<RakNet::RakNetGUID> *guids)
{
  __int64 v6; // rcx
  __int64 v7; // r15
  RakNet::RakPeer::RemoteSystemStruct *v8; // rcx
  const RakNet::SystemAddress *p_systemAddress; // r12
  __int64 list_size; // rax
  unsigned int allocation_size; // ecx
  signed int v12; // ecx
  __int64 v13; // rbx
  RakNet::SystemAddress *v14; // rax
  RakNet::SystemAddress *listArray; // rbp
  RakNet::SystemAddress *v16; // rdi
  bool v17; // zf
  __int64 v18; // rcx
  RakNet::SystemAddress *v19; // rdx
  unsigned int v20; // ebx
  RakNet::RakPeer::RemoteSystemStruct *v21; // r15
  __int64 v22; // rax
  unsigned int v23; // ecx
  signed int v24; // ecx
  __int64 v25; // rbx
  RakNet::RakNetGUID *v26; // rax
  RakNet::RakNetGUID *v27; // rbp
  RakNet::RakNetGUID *i; // rdi
  __int64 v29; // rcx
  RakNet::RakNetGUID *v30; // rdx
  unsigned int v31; // r8d
  __int64 v32; // rdx
  RakNet::RakNetGUID *v33; // rcx
  __int64 v34; // rcx
  int v35; // [rsp+70h] [rbp+8h]
  unsigned __int64 v36; // [rsp+78h] [rbp+10h]
  unsigned __int64 v37; // [rsp+78h] [rbp+10h]
  RakNet::SystemAddress *v38; // [rsp+80h] [rbp+18h]
  RakNet::RakNetGUID *v39; // [rsp+88h] [rbp+20h]

  if ( addresses->allocation_size != 0 ) /*0x1410be89e*/
  {
    operator delete(ptr: addresses->listArray); /*0x1410be8a3*/
    *(_QWORD *)&addresses->list_size = 0; /*0x1410be8a8*/
    addresses->listArray = nullptr; /*0x1410be8b0*/
  }
  if ( guids->allocation_size != 0 ) /*0x1410be8bc*/
  {
    operator delete(ptr: guids->listArray); /*0x1410be8c1*/
    *(_QWORD *)&guids->list_size = 0; /*0x1410be8c6*/
    guids->listArray = nullptr; /*0x1410be8ce*/
  }
  if ( this->remoteSystemList != nullptr && !this->endThreads._Storage._Value ) /*0x1410be8eb*/
  {
    v6 = 0; /*0x1410be8f1*/
    v35 = 0; /*0x1410be8f3*/
    if ( this->activeSystemListSize._Storage._Value != 0 ) /*0x1410be901*/
    {
      while ( 1 ) /*0x1410be910*/
      {
        v7 = v6; /*0x1410be910*/
        if ( !this->activeSystemList[v6]->isActive._Storage._Value ) /*0x1410be929*/
          goto LABEL_47; /*0x1410be929*/
        v8 = this->activeSystemList[v7]; /*0x1410be936*/
        if ( v8->connectMode != (UNVERIFIED_SENDER|DISCONNECT_ASAP) ) /*0x1410be941*/
          goto LABEL_47; /*0x1410be941*/
        p_systemAddress = &v8->systemAddress; /*0x1410be947*/
        list_size = addresses->list_size; /*0x1410be94b*/
        allocation_size = addresses->allocation_size; /*0x1410be94e*/
        if ( (_DWORD)list_size != allocation_size ) /*0x1410be953*/
        {
          listArray = addresses->listArray; /*0x1410bea0e*/
          v18 = addresses->list_size; /*0x1410bea11*/
          goto LABEL_29; /*0x1410bea11*/
        }
        if ( allocation_size == 0 ) /*0x1410be95b*/
          break; /*0x1410be95b*/
        v17 = 2 * allocation_size == 0; /*0x1410be9bb*/
        v12 = 2 * allocation_size; /*0x1410be9bb*/
        addresses->allocation_size = v12; /*0x1410be9bd*/
        if ( !v17 ) /*0x1410be9c0*/
          goto LABEL_13; /*0x1410be9c0*/
        listArray = nullptr; /*0x1410be9c2*/
LABEL_22:
        v18 = list_size; /*0x1410be9cb*/
        v19 = addresses->listArray; /*0x1410be9ce*/
        if ( addresses->listArray != nullptr ) /*0x1410be9d4*/
        {
          v20 = 0; /*0x1410be9d6*/
          if ( (_DWORD)list_size != 0 ) /*0x1410be9da*/
          {
            do /*0x1410be9f9*/
            {
              RakNet::SystemAddress::operator=(this: &listArray[v20], input: &addresses->listArray[v20]); /*0x1410be9ef*/
              ++v20; /*0x1410be9f4*/
            }
            while ( v20 < addresses->list_size ); /*0x1410be9f9*/
            v19 = addresses->listArray; /*0x1410be9fb*/
          }
          operator delete(ptr: v19); /*0x1410bea01*/
          v18 = addresses->list_size; /*0x1410bea06*/
        }
        addresses->listArray = listArray; /*0x1410bea09*/
LABEL_29:
        RakNet::SystemAddress::operator=(this: &listArray[v18], input: p_systemAddress); /*0x1410bea14*/
        ++addresses->list_size; /*0x1410bea23*/
        v21 = this->activeSystemList[v7]; /*0x1410bea2d*/
        v22 = guids->list_size; /*0x1410bea31*/
        v23 = guids->allocation_size; /*0x1410bea35*/
        if ( (_DWORD)v22 == v23 ) /*0x1410bea3b*/
        {
          if ( v23 == 0 ) /*0x1410bea43*/
          {
            guids->allocation_size = 16; /*0x1410bea45*/
            v24 = 16; /*0x1410bea4d*/
            goto LABEL_32; /*0x1410bea4d*/
          }
          v17 = 2 * v23 == 0; /*0x1410beaa1*/
          v24 = 2 * v23; /*0x1410beaa1*/
          guids->allocation_size = v24; /*0x1410beaa3*/
          if ( v17 ) /*0x1410beaa7*/
          {
            v27 = nullptr; /*0x1410beaa9*/
          }
          else
          {
LABEL_32:
            v25 = v24; /*0x1410bea52*/
            v37 = v24; /*0x1410bea55*/
            v26 = (RakNet::RakNetGUID *)operator new(size: saturated_mul(v24, 0x10u)); /*0x1410bea69*/
            v27 = v26; /*0x1410bea6e*/
            v39 = v26; /*0x1410bea71*/
            __eh34_enter_wind_state(-1, 1); /*0xf1c0000000000038*/
            if ( v26 != nullptr ) /*0x1410bea7c*/
            {
              for ( i = v26; v25 != 0; --v25 ) /*0x1410bea84*/
                RakNet::RakNetGUID::RakNetGUID(this: i++); /*0x1410bea89*/
              if ( __eh34_unwind(1) ) /*0xf1c0000000000018*/
                goto unwind_state_1; /*0xf1c0000000000018*/
              __eh34_exit_wind_state(1, -1); /*0xf1c0000000000024*/
            }
            else
            {
              if ( __eh34_unwind(1) ) /*0xf1c000000000002c*/
              {
unwind_state_1:
                is_mul_ok(v37, 0x10u); /*0xf1c000000000001c*/
                operator delete(ptr: v39); /*0x1431ece27*/
                __eh34_propagate_exception_into_caller(1, -1); /*0xf1c0000000000020*/
              }
              __eh34_exit_wind_state(1, -1); /*0xf1c0000000000030*/
              v27 = nullptr; /*0x1410beaad*/
            }
            v22 = guids->list_size; /*0x1410beaaf*/
          }
          v29 = v22; /*0x1410beab3*/
          v30 = guids->listArray; /*0x1410beab6*/
          if ( guids->listArray != nullptr ) /*0x1410beabc*/
          {
            v31 = 0; /*0x1410beabe*/
            if ( (_DWORD)v22 != 0 ) /*0x1410beac3*/
            {
              do /*0x1410beaf3*/
              {
                v32 = v31; /*0x1410bead3*/
                v33 = guids->listArray; /*0x1410bead6*/
                v27[v32].g = guids->listArray[v31].g; /*0x1410beadd*/
                v27[v32].systemIndex = v33[v31++].systemIndex; /*0x1410beae7*/
              }
              while ( v31 < guids->list_size ); /*0x1410beaf3*/
              v30 = guids->listArray; /*0x1410beaf5*/
            }
            operator delete(ptr: v30); /*0x1410beafb*/
            v29 = guids->list_size; /*0x1410beb00*/
          }
          guids->listArray = v27; /*0x1410beb04*/
          goto LABEL_46; /*0x1410beb07*/
        }
        v27 = guids->listArray; /*0x1410beb09*/
        v29 = guids->list_size; /*0x1410beb0c*/
LABEL_46:
        v34 = v29; /*0x1410beb0f*/
        v27[v34].g = v21->guid.g; /*0x1410beb19*/
        v27[v34].systemIndex = v21->guid.systemIndex; /*0x1410beb26*/
        ++guids->list_size; /*0x1410beb2b*/
LABEL_47:
        v6 = (unsigned int)(v35 + 1); /*0x1410beb2f*/
        v35 = v6; /*0x1410beb35*/
        if ( (unsigned int)v6 >= this->activeSystemListSize._Storage._Value ) /*0x1410beb43*/
          return; /*0x1410beb43*/
      }
      addresses->allocation_size = 16; /*0x1410be95d*/
      v12 = 16; /*0x1410be964*/
LABEL_13:
      v13 = v12; /*0x1410be969*/
      v36 = v12; /*0x1410be96c*/
      v14 = (RakNet::SystemAddress *)operator new(size: saturated_mul(v12, 0x20u)); /*0x1410be980*/
      listArray = v14; /*0x1410be985*/
      v38 = v14; /*0x1410be988*/
      if ( v14 != nullptr ) /*0x1410be993*/
      {
        v16 = v14; /*0x1410be995*/
        if ( v13 != 0 ) /*0x1410be99b*/
        {
          __wind /*0xf1c000000000004c*/
          {
            do /*0x1410be9b0*/
            {
              RakNet::SystemAddress::SystemAddress(this: v16++); /*0x1410be9a3*/
              --v13; /*0x1410be9ac*/
            }
            while ( v13 != 0 ); /*0x1410be9b0*/
          }
          __unwind
          {
            is_mul_ok(v36, 0x20u); /*0x1431ecdce*/
            operator delete(ptr: v38); /*0x1431ecde7*/
          }
        }
      }
      else
      {
        listArray = nullptr; /*0x1410be9c6*/
      }
      list_size = addresses->list_size; /*0x1410be9c8*/
      goto LABEL_22; /*0x1410be9c8*/
    }
  }
}

// Address: 0x1410beb60 | Name: ?GetTimeoutTime@RakPeer@RakNet@@UEAAIUSystemAddress@2@@Z
__int64 __fastcall RakNet::RakPeer::GetTimeoutTime(RakNet::RakPeer *this, RakNet::SystemAddress *target)
{
  __int128 v4; // xmm1
  int v5; // ebx
  __int64 v6; // rsi
  RakNet::RakPeer::RemoteSystemStruct *v7; // rcx
  RakNet::SystemAddress right; // [rsp+20h] [rbp-28h] BYREF

  if ( RakNet::SystemAddress::operator==(this: target, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410beb81*/
  {
    v4 = *((_OWORD *)&target->address.addr4 + 1); /*0x1410beb91*/
    *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&target->address.addr6.sin6_family; /*0x1410beb9a*/
    *((_OWORD *)&right.address.addr4 + 1) = v4; /*0x1410beb9f*/
    if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410bebab*/
    {
      v5 = 0; /*0x1410bebad*/
      if ( this->maximumNumberOfPeers != 0 ) /*0x1410bebb3*/
      {
        while ( 1 ) /*0x1410bebd3*/
        {
          v6 = v5; /*0x1410bebd3*/
          if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v6].systemAddress, &right) != 0 /*0x1410bebed*/
            && this->remoteSystemList[v6].isActive._Storage._Value )
          {
            break; /*0x1410bebf4*/
          }
          if ( ++v5 >= (unsigned int)this->maximumNumberOfPeers ) /*0x1410bebfe*/
            return this->defaultTimeoutTime; /*0x1410bebfe*/
        }
        v7 = &this->remoteSystemList[v6]; /*0x1410bec09*/
        if ( v7 != nullptr ) /*0x1410bec0c*/
          RakNet::ReliabilityLayer::GetTimeoutTime(this: (RakNet::ReliabilityLayer *)((char *)&v7->reliabilityLayer.rbxSessionCrypto._Ptr /*0x1410bec15*/
                                                                                    + 4));
      }
    }
  }
  return this->defaultTimeoutTime; /*0x1410bec25*/
}

// Address: 0x1410bec30 | Name: ?HandleActiveSystemList@RakPeer@RakNet@@IEAAXAEAVBitStream@2@AEA_K1@Z
void __fastcall RakNet::RakPeer::HandleActiveSystemList(
        RakNet::RakPeer *this,
        RakNet::BitStream *updateBitStream,
        unsigned __int64 *timeUS,
        unsigned __int64 *timeMS)
{
  unsigned __int64 *v4; // rsi
  unsigned int startingActiveSystemListIndex; // edx
  unsigned int v7; // edi
  int v8; // r12d
  bool v9; // r15
  RakNet::RakPeer::RemoteSystemStruct *v10; // rdi
  void **v11; // rbx
  int *Myfirst; // r12
  signed __int64 v13; // r15
  char *v14; // rsi
  bool v15; // r12
  unsigned int v16; // r15d
  unsigned int maxOutgoingBPS; // edx
  unsigned __int64 v18; // r8
  int MTUSize; // r9d
  std::_Ref_count_base *Rep; // rcx
  unsigned __int64 connectionTime; // rcx
  bool v22; // bl
  bool v23; // si
  RakNet::RakPeer::RemoteSystemStruct::ConnectMode connectMode; // ecx
  RBX::Network::Peer *peerPlugin; // rcx
  RBX::Network::Peer *v26; // rcx
  RBX::Network::Peer *v27; // rcx
  unsigned int v28; // eax
  int v29; // ecx
  const char *v30; // r8
  _BOOL8 IsOutgoingDataWaiting; // rbx
  bool v32; // al
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v33; // rsi
  RakNet::RakPeer::RemoteSystemStruct::ConnectMode v34; // eax
  unsigned __int16 remoteSystemIndex; // ax
  __int64 v36; // rbx
  bool v37; // [rsp+50h] [rbp-B0h]
  unsigned int v38; // [rsp+54h] [rbp-ACh]
  unsigned int v39; // [rsp+54h] [rbp-ACh]
  int v40; // [rsp+58h] [rbp-A8h]
  unsigned int v41; // [rsp+5Ch] [rbp-A4h]
  RakNet::SystemAddress systemAddress; // [rsp+68h] [rbp-98h] BYREF
  std::shared_ptr<RakNet::RakNetSocket> v43; // [rsp+88h] [rbp-78h] BYREF
  std::shared_ptr<RakNet::RakNetSocket> v44; // [rsp+98h] [rbp-68h] BYREF
  RBX::Time result; // [rsp+A8h] [rbp-58h] BYREF
  RBX::Time v46; // [rsp+B0h] [rbp-50h] BYREF
  RBX::Time v47; // [rsp+B8h] [rbp-48h] BYREF
  RakNet::AddressOrGUID v48; // [rsp+C0h] [rbp-40h] BYREF
  RakNet::SystemAddress v49; // [rsp+F0h] [rbp-10h] BYREF
  RakNet::SystemAddress v50; // [rsp+110h] [rbp+10h] BYREF
  RakNet::RakNetStatistics rakNetStatistics; // [rsp+130h] [rbp+30h] BYREF
  char v52; // [rsp+340h] [rbp+240h]

  v4 = timeMS; /*0x1410bec5a*/
  RakNet::SystemAddress::SystemAddress(this: &systemAddress); /*0x1410bec65*/
  startingActiveSystemListIndex = this->startingActiveSystemListIndex; /*0x1410bec6a*/
  v38 = startingActiveSystemListIndex; /*0x1410bec71*/
  v7 = 0; /*0x1410bec78*/
  v8 = 0; /*0x1410bec7b*/
  v40 = 0; /*0x1410bec7e*/
  v52 = 0; /*0x1410bec85*/
  v9 = false; /*0x1410bec8b*/
  v37 = false; /*0x1410bec8e*/
  if ( DFFlag::CLI50798.value ) /*0x1410bec99*/
  {
    v9 = RakNet::RakPeer::parseAvoidedPacketSizes(this); /*0x1410beca3*/
    v37 = v9; /*0x1410beca7*/
    startingActiveSystemListIndex = v38; /*0x1410becab*/
  }
  if ( this->activeSystemListSize._Storage._Value != 0 )
  {
    do
    {
      if ( startingActiveSystemListIndex + 1 >= this->activeSystemListSize._Storage._Value ) /*0x1410becdd*/
        startingActiveSystemListIndex = -1; /*0x1410becdd*/
      v41 = v7 + 1; /*0x1410bece3*/
      v39 = startingActiveSystemListIndex + 1; /*0x1410bece9*/
      v10 = this->activeSystemList[startingActiveSystemListIndex + 1]; /*0x1410becf4*/
      RakNet::SystemAddress::operator=(this: &systemAddress, input: &v10->systemAddress); /*0x1410bed01*/
      if ( *v4 > v10->lastReliableSend /*0x1410bed41*/
        && *v4 - v10->lastReliableSend > (unsigned __int64)RakNet::ReliabilityLayer::GetTimeoutTime(this: (RakNet::ReliabilityLayer *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr + 4)) >> 1
        && v10->connectMode == (UNVERIFIED_SENDER|DISCONNECT_ASAP) )
      {
        memset(&rakNetStatistics, 0, 56); /*0x1410bed4c*/
        memset(&rakNetStatistics.ds, 0, 216); /*0x1410bed5f*/
        if ( RakNet::ReliabilityLayer::GetStatistics( /*0x1410bee09*/
               this: (RakNet::ReliabilityLayer *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
               rns: &rakNetStatistics)->messagesInResendBuffer == 0 )
        {
          v49 = systemAddress; /*0x1410bee10*/
          RakNet::RakPeer::PingInternal(this, target: &v49, performImmediate: true, reliability: RELIABLE); /*0x1410bee2d*/
          v10->lastReliableSend = *v4; /*0x1410bee35*/
        }
      }
      if ( (v10->remoteCommonCapabilities & 0x8000) != 0 ) /*0x1410bee47*/
      {
        if ( v9 ) /*0x1410bee50*/
        {
          v11 = (void **)((char *)&v10->reliabilityLayer.avoidedPacketSizes._Mypair._Myval2._Myfirst + 4); /*0x1410bee59*/
          if ( (std::vector<int> *)((char *)&v10->reliabilityLayer.avoidedPacketSizes._Mypair._Myval2._Myfirst + 4) != &this->avoidedPacketSizes ) /*0x1410bee63*/
          {
            Myfirst = this->avoidedPacketSizes._Mypair._Myval2._Myfirst; /*0x1410bee69*/
            v13 = (char *)this->avoidedPacketSizes._Mypair._Myval2._Mylast - (char *)Myfirst; /*0x1410bee6c*/
            v14 = (char *)*v11; /*0x1410bee76*/
            if ( v13 >> 2 > (unsigned __int64)(*(int **)((char *)&v10->reliabilityLayer.avoidedPacketSizes._Mypair._Myval2._Myend /*0x1410bee87*/
                                                       + 4)
                                             - *(int **)((char *)&v10->reliabilityLayer.avoidedPacketSizes._Mypair._Myval2._Myfirst
                                                       + 4)) )
            {
              std::vector<webrtc::RtpPacket::ExtensionInfo>::_Clear_and_reserve_geometric( /*0x1410bee8c*/
                this: (std::vector<webrtc::RtpPacket::ExtensionInfo> *)((char *)&v10->reliabilityLayer.avoidedPacketSizes._Mypair._Myval2._Myfirst
                                                                + 4),
                _Newsize: v13 >> 2);
              v14 = (char *)*v11; /*0x1410bee91*/
            }
            memmove_0(a1: v14, Src: Myfirst, Size: v13); /*0x1410bee9d*/
            *(int **)((char *)&v10->reliabilityLayer.avoidedPacketSizes._Mypair._Myval2._Mylast + 4) = (int *)&v14[v13]; /*0x1410beea6*/
            v4 = timeMS; /*0x1410beeaa*/
          }
        }
        if ( (DFFlag::CLI50798ReportFix.value || DFString::CLI50798S._Mypair._Myval2._Mysize != 0) /*0x1410beedb*/
          && *v4 - v10->lastAvoidPacketReportMS >= DFInt::CLI50798MS )
        {
          v10->lastAvoidPacketReportMS = *v4; /*0x1410beedd*/
          RakNet::RakPeer::reportAvoidPacketStatistics(this, remoteSystem: v10); /*0x1410beeea*/
        }
      }
      v15 = true; /*0x1410beeef*/
      v16 = 0; /*0x1410beef2*/
      maxOutgoingBPS = this->maxOutgoingBPS; /*0x1410beefc*/
      v18 = *timeUS; /*0x1410bef0a*/
      MTUSize = v10->MTUSize; /*0x1410bef0d*/
      Rep = v10->rakNetSocket._Rep; /*0x1410bef17*/
      if ( DFFlag::RakNetSendReceiveMicroprofiles.value ) /*0x1410bef25*/
      {
        v43 = 0; /*0x1410bef27*/
        if ( Rep != nullptr ) /*0x1410bef2f*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410bef31*/
          Rep = v10->rakNetSocket._Rep; /*0x1410bef35*/
        }
        v43._Ptr = v10->rakNetSocket._Ptr; /*0x1410bef43*/
        v43._Rep = Rep; /*0x1410bef47*/
        v16 = RakNet::ReliabilityLayer::Update( /*0x1410bef86*/
                this: (RakNet::ReliabilityLayer *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
                socket: &v43,
                &systemAddress,
                MTUSize,
                time: v18,
                bitsPerSecondLimit: maxOutgoingBPS,
                updateBitStream,
                ruppHeader: &this->ruppHeader,
                udmuxAddress: &v10->myExternalSystemAddress);
        v40 += v16; /*0x1410bef89*/
      }
      else
      {
        v44 = 0; /*0x1410bef8f*/
        if ( Rep != nullptr ) /*0x1410bef97*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410bef99*/
          Rep = v10->rakNetSocket._Rep; /*0x1410bef9d*/
        }
        v44._Ptr = v10->rakNetSocket._Ptr; /*0x1410befab*/
        v44._Rep = Rep; /*0x1410befaf*/
        v15 = RakNet::ReliabilityLayer::Update( /*0x1410beff0*/
                this: (RakNet::ReliabilityLayer *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
                socket: &v44,
                &systemAddress,
                MTUSize,
                time: v18,
                bitsPerSecondLimit: maxOutgoingBPS,
                updateBitStream,
                ruppHeader: &this->ruppHeader,
                udmuxAddress: &v10->myExternalSystemAddress) == 0;
      }
      connectionTime = v10->connectionTime; /*0x1410beff7*/
      v22 = *v4 > connectionTime && *v4 - connectionTime > 0x2710; /*0x1410bf012*/
      v23 = (unsigned int)(v10->connectMode - 4) <= 2; /*0x1410bf020*/
      if ( (unsigned __int8)rtc::SocketDispatcher::GetRequestedEvents(this: (rtc::SocketDispatcher *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr + 4)) != 0
        || (unsigned int)(v10->connectMode - 1) <= 1
        && !RakNet::ReliabilityLayer::IsOutgoingDataWaiting(this: (RakNet::ReliabilityLayer *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr
                                                                                             + 4))
        || v10->connectMode == DISCONNECT_ON_NO_ACK
        && (!RakNet::ReliabilityLayer::AreAcksWaiting(this: (RakNet::ReliabilityLayer *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr
                                                                                       + 4))
         || RakNet::ReliabilityLayer::AckTimeout(
              this: (RakNet::ReliabilityLayer *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
              curTime: *timeMS))
        || v23 && v22 )
      {
        connectMode = v10->connectMode; /*0x1410bf1cc*/
        if ( (unsigned int)(connectMode - 1) > 1 ) /*0x1410bf1d8*/
        {
          if ( connectMode == DISCONNECT_ON_NO_ACK ) /*0x1410bf1dd*/
          {
            peerPlugin = this->peerPlugin; /*0x1410bf1df*/
            if ( peerPlugin != nullptr ) /*0x1410bf1e9*/
              peerPlugin->OnRemoteActiveDisconnect(this: peerPlugin, a2: &v10->systemAddress); /*0x1410bf1f2*/
          }
          else if ( (unsigned __int8)rtc::SocketDispatcher::GetRequestedEvents(this: (rtc::SocketDispatcher *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr + 4)) != 0 ) /*0x1410bf204*/
          {
            v26 = this->peerPlugin; /*0x1410bf206*/
            if ( v26 != nullptr ) /*0x1410bf210*/
              v26->OnReliabilityLayerDeadConnection(this: v26, a2: &v10->systemAddress); /*0x1410bf219*/
          }
          else if ( v23 && v22 ) /*0x1410bf228*/
          {
            v27 = this->peerPlugin; /*0x1410bf22a*/
            if ( v27 != nullptr ) /*0x1410bf234*/
              v27->OnTimeoutWaitingForPasswordAccepted(this: v27, a2: &v10->systemAddress); /*0x1410bf23d*/
          }
        }
        v28 = v10->connectMode; /*0x1410bf243*/
        if ( v28 <= 7 )
        {
          v29 = 154; /*0x1410bf252*/
          if ( _bittest(&v29, v28) )
          {
            if ( FLog::Network != 0 )
            {
              FLog::FastLog(level: FLog::Network, message: "[FLog::Network] Connection lost", arg0: nullptr); /*0x1410bf279*/
              if ( FLog::Network != 0 )
              {
                switch ( v10->connectMode ) /*0x1410bf2b3*/
                {
                  case 0: /*0x1410bf2b3*/
                    v30 = "No action"; /*0x1410bf2b5*/
                    break; /*0x1410bf2bc*/
                  case 1: /*0x1410bf2b3*/
                    v30 = "Disconnect ASAP"; /*0x1410bf2be*/
                    break; /*0x1410bf2c5*/
                  case 2: /*0x1410bf2b3*/
                    v30 = "Disconnect ASAP Silently"; /*0x1410bf2c7*/
                    break; /*0x1410bf2ce*/
                  case 3: /*0x1410bf2b3*/
                    v30 = "Disconnect from no ACK"; /*0x1410bf2d0*/
                    break; /*0x1410bf2d7*/
                  case 4: /*0x1410bf2b3*/
                    v30 = "Requested Connection"; /*0x1410bf2d9*/
                    break; /*0x1410bf2e0*/
                  case 5: /*0x1410bf2b3*/
                    v30 = "Handling Connection Request"; /*0x1410bf2e2*/
                    break; /*0x1410bf2e9*/
                  case 6: /*0x1410bf2b3*/
                    v30 = "Unverified Sender"; /*0x1410bf2eb*/
                    break; /*0x1410bf2f2*/
                  case 7: /*0x1410bf2b3*/
                    v30 = "Connected"; /*0x1410bf2f4*/
                    break; /*0x1410bf2fb*/
                  default:
                    v30 = "Unknown"; /*0x1410bf2fd*/
                    break; /*0x1410bf2fd*/
                }
                FLog::FastLogFormatted(
                  level: FLog::Network,
                  message: "[FLog::Network] Connection lost: connectMode: %s, timeMS:%llu, connectionTime %llu",
                  v30,
                  *timeMS,
                  v10->connectionTime);
                if ( FLog::Network != 0 )
                {
                  IsOutgoingDataWaiting = RakNet::ReliabilityLayer::IsOutgoingDataWaiting(this: (RakNet::ReliabilityLayer *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr + 4)); /*0x1410bf337*/
                  v32 = RakNet::ReliabilityLayer::AckTimeout( /*0x1410bf340*/
                          this: (RakNet::ReliabilityLayer *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
                          curTime: *timeMS);
                  FLog::FastLog(
                    level: FLog::Network,
                    message: "[FLog::Network] Connection lost: AckTimeout %d, IsOutgoingDataWaiting %d",
                    arg0: (const void *)v32,
                    arg1: (const void *)IsOutgoingDataWaiting,
                    arg2: nullptr);
                }
              }
            }
            rtc::CriticalSection::Enter(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410bf374*/
            v33 = DataStructures::MemoryPool<RakNet::Packet>::Allocate( /*0x1410bf392*/
                    this: &this->packetAllocationPool,
                    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                    line: 0x187Au);
            RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410bf39c*/
            RakNet::SystemAddress::SystemAddress(this: &v33->userMemory.systemAddress); /*0x1410bf3a4*/
            RakNet::RakNetGUID::RakNetGUID(this: &v33->userMemory.guid); /*0x1410bf3ad*/
            v33->userMemory.cycleReceivedByApplication = 0; /*0x1410bf3b2*/
            v33->userMemory.data = (unsigned __int8 *)RBX::Memory::allocate(size: 1u); /*0x1410bf3c3*/
            v33->userMemory.length = 1; /*0x1410bf3c7*/
            v33->userMemory.bitSize = 8; /*0x1410bf3ce*/
            v33->userMemory.deleteData = true; /*0x1410bf3d5*/
            v33->userMemory.guid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410bf3e0*/
            v33->userMemory.wasGeneratedLocally = false; /*0x1410bf3ef*/
            v34 = v10->connectMode; /*0x1410bf3f3*/
            if ( v34 == REQUESTED_CONNECTION )
            {
              if ( FLog::Network != 0 ) /*0x1410bf407*/
                FLog::FastLog(level: FLog::Network, message: "[FLog::Network] Connection attempt failed", arg0: nullptr); /*0x1410bf413*/
              *v33->userMemory.data = 17; /*0x1410bf41c*/
            }
            else if ( v34 == (UNVERIFIED_SENDER|DISCONNECT_ASAP) )
            {
              if ( FLog::Network != 0 ) /*0x1410bf42f*/
                FLog::FastLog( /*0x1410bf43b*/
                  level: FLog::Network,
                  message: "[FLog::Network] Connection lost - Cannot contact server/client",
                  arg0: nullptr);
              *v33->userMemory.data = 22; /*0x1410bf444*/
            }
            else
            {
              if ( FLog::Network != 0 )
                FLog::FastLogFormatted(
                  level: FLog::Network,
                  message: "[FLog::Network] Disconnection Notification. Reason: %d",
                  this->disconnectReason);
              *v33->userMemory.data = 21; /*0x1410bf46d*/
            }
            v33->userMemory.guid.g = v10->guid.g; /*0x1410bf477*/
            v33->userMemory.guid.systemIndex = v10->guid.systemIndex; /*0x1410bf482*/
            RakNet::SystemAddress::operator=(this: &v33->userMemory.systemAddress, input: &systemAddress); /*0x1410bf48e*/
            remoteSystemIndex = v10->remoteSystemIndex; /*0x1410bf493*/
            v33->userMemory.systemAddress.systemIndex = remoteSystemIndex; /*0x1410bf49a*/
            v33->userMemory.guid.systemIndex = remoteSystemIndex; /*0x1410bf49e*/
            RakNet::RakPeer::AddPacketToProducer(this, p: (RakNet::InternalPacket *)v33); /*0x1410bf4a8*/
          }
        }
        RakNet::RakNetGUID::RakNetGUID(this: &v48.rakNetGuid); /*0x1410bf4b1*/
        RakNet::SystemAddress::SystemAddress(this: &v48.systemAddress); /*0x1410bf4ba*/
        v48.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410bf4c6*/
        RakNet::SystemAddress::operator=(this: &v48.systemAddress, input: &systemAddress); /*0x1410bf4de*/
        RakNet::RakPeer::CloseConnectionInternal( /*0x1410bf4fd*/
          this,
          systemIdentifier: &v48,
          sendDisconnectionNotification: false,
          performImmediate: true,
          orderingChannel: 0,
          disconnectionNotificationPriority: LOW_PRIORITY);
      }
      else
      {
        if ( (DFFlag::RakNetSendReceiveMicroprofiles.value && v16 != 0 || !v15) /*0x1410bf0b8*/
          && v52 == 0
          && this->startingActiveSystemListIndex != v39 )
        {
          this->startingActiveSystemListIndex = v39; /*0x1410bf0ba*/
          v52 = 1; /*0x1410bf0c1*/
        }
        if ( DFFlag::TrackRunUpdateCycleTime.value ) /*0x1410bf0cf*/
          this->runUpdateCycleStats.cycleStartToAfterDisconnectChecks.sec = RBX::Time::nowFast(&result)->sec /*0x1410bf0e7*/
                                                                          - this->runUpdateCycleStats.lastCycleStart.sec;
        if ( v10->connectMode == (UNVERIFIED_SENDER|DISCONNECT_ASAP) /*0x1410bf120*/
          && *timeMS > v10->nextPingTime
          && (this->occasionalPing || v10->lowestPing._Storage._Value == 0xFFFF) )
        {
          v10->nextPingTime = *timeMS + DFInt::RakNetPingFrequencyMillisecond; /*0x1410bf12c*/
          v50 = systemAddress; /*0x1410bf138*/
          RakNet::RakPeer::PingInternal(this, target: &v50, performImmediate: true, reliability: UNRELIABLE); /*0x1410bf152*/
          RakNet::SignaledEvent::SetEvent(this: (rtc::Event *)&this->quitAndDataEvents); /*0x1410bf15e*/
        }
        if ( DFFlag::TrackRunUpdateCycleTime.value ) /*0x1410bf16a*/
          this->runUpdateCycleStats.cycleStartToAfterPingInternal.sec = RBX::Time::nowFast(result: &v46)->sec /*0x1410bf182*/
                                                                      - this->runUpdateCycleStats.lastCycleStart.sec;
        RakNet::RakPeer::HandlePacketRequest(this, remoteSystem: v10, &systemAddress); /*0x1410bf196*/
        if ( DFFlag::TrackRunUpdateCycleTime.value ) /*0x1410bf1a2*/
          this->runUpdateCycleStats.cycleStartToAfterReliableReceive.sec = RBX::Time::nowFast(result: &v47)->sec /*0x1410bf1be*/
                                                                         - this->runUpdateCycleStats.lastCycleStart.sec;
      }
      v7 = v41; /*0x1410bf50a*/
      v4 = timeMS; /*0x1410bf510*/
      startingActiveSystemListIndex = v39; /*0x1410bf517*/
      v9 = v37; /*0x1410bf51b*/
    }
    while ( v41 < this->activeSystemListSize._Storage._Value );
    v8 = v40; /*0x1410bf533*/
  }
  v36 = *((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index); /*0x1410bf54c*/
  if ( _TSS0_538 > *(_DWORD *)(v36 + 260) ) /*0x1410bf559*/
  {
    Init_thread_header(pOnce: &_TSS0_538); /*0x1410bf5e7*/
    if ( _TSS0_538 == -1 ) /*0x1410bf5f3*/
    {
      __wind /*0xf1c000000000001c*/
      {
        proflabeltoken_48 = RBX::Profiler::getLabelToken(group: "RakNet"); /*0x1410bf605*/
        Init_thread_footer(pOnce: &_TSS0_538); /*0x1410bf613*/
      }
      __unwind
      {
        Init_thread_abort(pOnce: &_TSS0_538); /*0x1431ece47*/
      }
    }
  }
  RBX::Profiler::addLabelFormat(token: proflabeltoken_48, name: "#clients: %d", v7);
  if ( _TSS1_114 > *(_DWORD *)(v36 + 260) ) /*0x1410bf57e*/
  {
    Init_thread_header(pOnce: &_TSS1_114); /*0x1410bf5b1*/
    if ( _TSS1_114 == -1 ) /*0x1410bf5bd*/
    {
      __wind /*0xf1c0000000000040*/
      {
        proflabeltoken_49 = RBX::Profiler::getLabelToken(group: "RakNet"); /*0x1410bf5cb*/
      }
      __unwind
      {
        Init_thread_abort(pOnce: &_TSS1_114); /*0x1431ece57*/
      }
      Init_thread_footer(pOnce: &_TSS1_114); /*0x1410bf5d9*/
    }
  }
  RBX::Profiler::addLabelFormat(token: proflabeltoken_49, name: "#packets sent: %d", v8);
}

// Address: 0x1410bf640 | Name: ?HandleIDConnectedPing@RakPeer@RakNet@@IEAAXPEBURemoteSystemStruct@12@AEBUSystemAddress@2@PEAEI@Z
void __fastcall RakNet::RakPeer::HandleIDConnectedPing(
        RakNet::RakPeer *this,
        const RakNet::RakPeer::RemoteSystemStruct *remoteSystem,
        const RakNet::SystemAddress *systemAddress,
        unsigned __int8 *data,
        unsigned int byteSize)
{
  unsigned __int8 *p_sendPingTime; // rdx
  unsigned __int8 *p_inOutByteArray; // rdx
  unsigned __int8 *v10; // rdx
  unsigned __int64 TimeUS; // rbx
  unsigned __int64 sendPingTime; // [rsp+60h] [rbp-A0h] BYREF
  unsigned __int8 v13[8]; // [rsp+68h] [rbp-98h] BYREF
  RakNet::AddressOrGUID v14; // [rsp+70h] [rbp-90h] BYREF
  RakNet::BitStream outBitStream; // [rsp+A0h] [rbp-60h] BYREF
  RakNet::BitStream inBitStream; // [rsp+1D0h] [rbp+D0h] BYREF
  __int64 inOutByteArray; // [rsp+320h] [rbp+220h] BYREF

  RakNet::BitStream::BitStream(this: &inBitStream, _data: data, lengthInBytes: byteSize, _copyData: false); /*0x1410bf67a*/
  __wind /*0xf1c0000000000028*/
  {
    RakNet::BitStream::IgnoreBits(this: &inBitStream, numberOfBits: 8u); /*0x1410bf68c*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410bf691*/
    {
      RakNet::BitStream::ReadBits( /*0x1410bf6d8*/
        this: &inBitStream,
        inOutByteArray: (unsigned __int8 *)&sendPingTime,
        numberOfBitsToRead: 0x40u,
        alignBitsToRight: true);
    }
    else if ( RakNet::BitStream::ReadBits( /*0x1410bf6b8*/
                this: &inBitStream,
                (unsigned __int8 *)&inOutByteArray,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true) != 0 )
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410bf6cc*/
        inByteArray: (unsigned __int8 *)&inOutByteArray,
        inOutByteArray: (unsigned __int8 *)&sendPingTime,
        length: 8u);
    }
    RakNet::BitStream::BitStream(this: &outBitStream); /*0x1410bf6e1*/
    __wind /*0xf1c000000000001c*/
    {
      LOBYTE(inOutByteArray) = 3; /*0x1410bf6e7*/
      RakNet::BitStream::WriteBits( /*0x1410bf702*/
        this: &outBitStream,
        inByteArray: (unsigned __int8 *)&inOutByteArray,
        numberOfBitsToWrite: 8u,
        rightAlignedBits: true);
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410bf707*/
      {
        p_sendPingTime = (unsigned __int8 *)&sendPingTime; /*0x1410bf730*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410bf722*/
          inByteArray: (unsigned __int8 *)&sendPingTime,
          (unsigned __int8 *)&inOutByteArray,
          length: 8u);
        p_sendPingTime = (unsigned __int8 *)&inOutByteArray; /*0x1410bf727*/
      }
      RakNet::BitStream::WriteBits( /*0x1410bf742*/
        this: &outBitStream,
        inByteArray: p_sendPingTime,
        numberOfBitsToWrite: 0x40u,
        rightAlignedBits: true);
      inOutByteArray = RakNet::GetTime(isNetworkSynced: false); /*0x1410bf74e*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410bf755*/
      {
        p_inOutByteArray = (unsigned __int8 *)&inOutByteArray; /*0x1410bf77c*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410bf770*/
          inByteArray: (unsigned __int8 *)&inOutByteArray,
          inOutByteArray: v13,
          length: 8u);
        p_inOutByteArray = v13; /*0x1410bf775*/
      }
      RakNet::BitStream::WriteBits( /*0x1410bf790*/
        this: &outBitStream,
        inByteArray: p_inOutByteArray,
        numberOfBitsToWrite: 0x40u,
        rightAlignedBits: true);
      inOutByteArray = RBX::Time::epochTimeNs() / 1000; /*0x1410bf7b8*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410bf7bf*/
      {
        v10 = (unsigned __int8 *)&inOutByteArray; /*0x1410bf7e6*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410bf7da*/
          inByteArray: (unsigned __int8 *)&inOutByteArray,
          inOutByteArray: v13,
          length: 8u);
        v10 = v13; /*0x1410bf7df*/
      }
      RakNet::BitStream::WriteBits( /*0x1410bf7fa*/
        this: &outBitStream,
        inByteArray: v10,
        numberOfBitsToWrite: 0x40u,
        rightAlignedBits: true);
      TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x1410bf806*/
      RakNet::RakNetGUID::RakNetGUID(this: &v14.rakNetGuid); /*0x1410bf80e*/
      RakNet::SystemAddress::SystemAddress(this: &v14.systemAddress); /*0x1410bf817*/
      v14.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410bf823*/
      RakNet::SystemAddress::operator=(this: &v14.systemAddress, input: systemAddress); /*0x1410bf83b*/
      RakNet::RakPeer::SendImmediate( /*0x1410bf878*/
        this,
        data: (char *)outBitStream.data,
        numberOfBitsToSend: outBitStream.numberOfBitsUsed,
        priority: IMMEDIATE_PRIORITY,
        reliability: UNRELIABLE,
        orderingChannel: 0,
        systemIdentifier: &v14,
        broadcast: false,
        useCallerDataAllocation: false,
        currentTime: TimeUS,
        receipt: 0,
        isJoinData: false);
      RakNet::SignaledEvent::SetEvent(this: (rtc::Event *)&this->quitAndDataEvents); /*0x1410bf884*/
      operator delete(ptr: data); /*0x1410bf88c*/
    }
    __unwind
    {
      RakNet::BitStream::~BitStream(this: &outBitStream); /*0xf1c0000000000014*/
    }
    RakNet::BitStream::~BitStream(this: &outBitStream); /*0x1410bf896*/
    RakNet::BitStream::~BitStream(this: &inBitStream); /*0x1410bf8a3*/
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &inBitStream); /*0xf1c0000000000008*/
  }
}

// Address: 0x1410bf8c0 | Name: ?HandleIDConnectionRequestAccepted@RakPeer@RakNet@@IEAAXPEAURemoteSystemStruct@12@AEBUSystemAddress@2@PEAEI@Z
void __fastcall RakNet::RakPeer::HandleIDConnectionRequestAccepted(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *remoteSystem,
        const RakNet::SystemAddress *systemAddress,
        unsigned __int8 *data,
        unsigned int byteSize)
{
  unsigned int v9; // ebx
  RakNet::RakPeer::RemoteSystemStruct::ConnectMode connectMode; // ecx
  char v11; // al
  unsigned __int16 *p_sin6_port; // rbx
  __int64 i; // rdi
  __int64 v14; // r15
  unsigned int v15; // ebx
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v16; // rdi
  __int16 RemoteSystemIndex; // ax
  RakNet::SystemAddress *ipList; // rbx
  unsigned __int8 *p_sendPongTime; // rdx
  unsigned __int8 *v20; // rdx
  unsigned __int8 *v21; // rdx
  unsigned __int64 TimeUS; // rbx
  char v23; // [rsp+60h] [rbp-A0h]
  unsigned __int8 inOutByteArray; // [rsp+61h] [rbp-9Fh] BYREF
  unsigned __int8 v25; // [rsp+62h] [rbp-9Eh] BYREF
  unsigned __int8 v26; // [rsp+63h] [rbp-9Dh] BYREF
  unsigned __int8 v27[4]; // [rsp+64h] [rbp-9Ch] BYREF
  unsigned __int8 inByteArray[4]; // [rsp+68h] [rbp-98h] BYREF
  unsigned __int16 systemIndex; // [rsp+6Ch] [rbp-94h] BYREF
  unsigned __int8 v30[4]; // [rsp+70h] [rbp-90h] BYREF
  unsigned __int8 v31[4]; // [rsp+74h] [rbp-8Ch] BYREF
  unsigned __int64 sendPongTime; // [rsp+78h] [rbp-88h] BYREF
  unsigned __int8 v33[4]; // [rsp+80h] [rbp-80h] BYREF
  unsigned __int8 v34[4]; // [rsp+84h] [rbp-7Ch] BYREF
  unsigned __int8 v35[4]; // [rsp+88h] [rbp-78h] BYREF
  unsigned __int8 v36[4]; // [rsp+8Ch] [rbp-74h] BYREF
  unsigned __int64 sendEpochTimeMicro; // [rsp+90h] [rbp-70h] BYREF
  unsigned __int64 sendPingTime; // [rsp+98h] [rbp-68h] BYREF
  unsigned __int8 v39[8]; // [rsp+A0h] [rbp-60h] BYREF
  unsigned __int8 v40[8]; // [rsp+A8h] [rbp-58h] BYREF
  unsigned __int8 v41[8]; // [rsp+B0h] [rbp-50h] BYREF
  unsigned __int8 v42[8]; // [rsp+B8h] [rbp-48h] BYREF
  unsigned __int8 v43[8]; // [rsp+C0h] [rbp-40h] BYREF
  unsigned __int8 v44[8]; // [rsp+C8h] [rbp-38h] BYREF
  unsigned __int8 v45[8]; // [rsp+D0h] [rbp-30h] BYREF
  unsigned __int8 v46[8]; // [rsp+D8h] [rbp-28h] BYREF
  RakNet::SystemAddress right; // [rsp+E0h] [rbp-20h] BYREF
  RakNet::SystemAddress externalID; // [rsp+100h] [rbp+0h] BYREF
  RakNet::AddressOrGUID v49; // [rsp+120h] [rbp+20h] BYREF
  _BYTE v50[32]; // [rsp+150h] [rbp+50h] BYREF
  _QWORD v51[4]; // [rsp+170h] [rbp+70h] BYREF
  RakNet::SystemAddress v52; // [rsp+190h] [rbp+90h] BYREF
  RakNet::BitStream outBitStream; // [rsp+1B0h] [rbp+B0h] BYREF
  RakNet::BitStream inBitStream; // [rsp+2E0h] [rbp+1E0h] BYREF

  v9 = byteSize; /*0x1410bf8f3*/
  if ( byteSize <= 0x21 ) /*0x1410bf8fc*/
    goto LABEL_56; /*0x1410bf8fc*/
  connectMode = remoteSystem->connectMode; /*0x1410bf902*/
  if ( (unsigned int)(connectMode - 4) > 1 && !this->allowConnectionResponseIPMigration ) /*0x1410bf91b*/
  {
    v11 = 0; /*0x1410bf921*/
    goto LABEL_5; /*0x1410bf921*/
  }
  v11 = 1; /*0x1410bfa09*/
  if ( connectMode != HANDLING_CONNECTION_REQUEST ) /*0x1410bfa0e*/
  {
LABEL_5:
    v23 = 0; /*0x1410bf923*/
    if ( v11 != 0 ) /*0x1410bf92a*/
      goto LABEL_6; /*0x1410bf92a*/
LABEL_56:
    operator delete(ptr: data); /*0x1410bffeb*/
    return; /*0x1410bffee*/
  }
  v23 = 1; /*0x1410bfa14*/
LABEL_6:
  RakNet::SystemAddress::SystemAddress(this: &externalID); /*0x1410bf930*/
  RakNet::BitStream::BitStream(this: &inBitStream, _data: data, lengthInBytes: v9, _copyData: false); /*0x1410bf949*/
  __wind
  {
    RakNet::BitStream::IgnoreBits(this: &inBitStream, numberOfBits: 8u); /*0x1410bf95b*/
    RakNet::BitStream::ReadBits(this: &inBitStream, &inOutByteArray, numberOfBitsToRead: 8u, alignBitsToRight: true); /*0x1410bf975*/
    if ( inOutByteArray == 4 ) /*0x1410bf984*/
    {
      externalID.address.addr6.sin6_family = 2; /*0x1410bf986*/
      RakNet::BitStream::ReadBits( /*0x1410bf99c*/
        this: &inBitStream,
        inOutByteArray: v33,
        numberOfBitsToRead: 0x20u,
        alignBitsToRight: true);
      externalID.address.addr6.sin6_flowinfo = ~*(_DWORD *)v33; /*0x1410bf9a6*/
      RakNet::BitStream::ReadBits( /*0x1410bf9bb*/
        this: &inBitStream,
        inOutByteArray: (unsigned __int8 *)&externalID.address.addr4.sin_port,
        numberOfBitsToRead: 0x10u,
        alignBitsToRight: true);
      externalID.debugPort = ntohs(netshort: externalID.address.addr6.sin6_port); /*0x1410bf9ca*/
    }
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410bf9ce*/
    {
      RakNet::BitStream::ReadBits( /*0x1410bfa22*/
        this: &inBitStream,
        inOutByteArray: (unsigned __int8 *)&systemIndex,
        numberOfBitsToRead: 0x10u,
        alignBitsToRight: true);
    }
    else if ( RakNet::BitStream::ReadBits( /*0x1410bf9f3*/
                this: &inBitStream,
                inOutByteArray: inByteArray,
                numberOfBitsToRead: 0x10u,
                alignBitsToRight: true) != 0 )
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410bfa02*/
        inByteArray,
        inOutByteArray: (unsigned __int8 *)&systemIndex,
        length: 2u);
    }
    p_sin6_port = &remoteSystem->theirInternalSystemAddress[0].address.addr6.sin6_port; /*0x1410bfa27*/
    for ( i = 10; i != 0; --i ) /*0x1410bfa2b*/
    {
      RakNet::BitStream::ReadBits( /*0x1410bfa55*/
        this: &inBitStream,
        inOutByteArray: &v25,
        numberOfBitsToRead: 8u,
        alignBitsToRight: true);
      if ( v25 == 4 ) /*0x1410bfa5f*/
      {
        *(p_sin6_port - 1) = 2; /*0x1410bfa61*/
        RakNet::BitStream::ReadBits( /*0x1410bfa7a*/
          this: &inBitStream,
          inOutByteArray: v34,
          numberOfBitsToRead: 0x20u,
          alignBitsToRight: true);
        *(_DWORD *)(p_sin6_port + 1) = ~*(_DWORD *)v34; /*0x1410bfa84*/
        RakNet::BitStream::ReadBits( /*0x1410bfa9a*/
          this: &inBitStream,
          inOutByteArray: (unsigned __int8 *)p_sin6_port,
          numberOfBitsToRead: 0x10u,
          alignBitsToRight: true);
        p_sin6_port[13] = ntohs(netshort: *p_sin6_port); /*0x1410bfaa8*/
      }
      p_sin6_port += 16; /*0x1410bfaac*/
    }
    sendEpochTimeMicro = 0; /*0x1410bfab6*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410bfaba*/
    {
      RakNet::BitStream::ReadBits( /*0x1410bfaf5*/
        this: &inBitStream,
        inOutByteArray: (unsigned __int8 *)&sendPingTime,
        numberOfBitsToRead: 0x40u,
        alignBitsToRight: true);
    }
    else if ( RakNet::BitStream::ReadBits( /*0x1410bfadc*/
                this: &inBitStream,
                inOutByteArray: v41,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true) != 0 )
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410bfaea*/
        inByteArray: v41,
        inOutByteArray: (unsigned __int8 *)&sendPingTime,
        length: 8u);
    }
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410bfafa*/
    {
      RakNet::BitStream::ReadBits( /*0x1410bfb3b*/
        this: &inBitStream,
        inOutByteArray: (unsigned __int8 *)&sendPongTime,
        numberOfBitsToRead: 0x40u,
        alignBitsToRight: true);
    }
    else if ( RakNet::BitStream::ReadBits( /*0x1410bfb1e*/
                this: &inBitStream,
                inOutByteArray: v42,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true) != 0 )
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410bfb2f*/
        inByteArray: v42,
        inOutByteArray: (unsigned __int8 *)&sendPongTime,
        length: 8u);
    }
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410bfb40*/
    {
      RakNet::BitStream::ReadBits( /*0x1410bfb7f*/
        this: &inBitStream,
        inOutByteArray: (unsigned __int8 *)&sendEpochTimeMicro,
        numberOfBitsToRead: 0x40u,
        alignBitsToRight: true);
    }
    else if ( RakNet::BitStream::ReadBits( /*0x1410bfb64*/
                this: &inBitStream,
                inOutByteArray: v43,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true) != 0 )
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410bfb74*/
        inByteArray: v43,
        inOutByteArray: (unsigned __int8 *)&sendEpochTimeMicro,
        length: 8u);
    }
    RakNet::RakPeer::OnConnectedPong(this, sendPingTime, sendPongTime, sendEpochTimeMicro, remoteSystem); /*0x1410bfb99*/
    v14 = 10; /*0x1410bfba7*/
    if ( DFLog::RakNetConnectTrace != 0 )
      FLog::FastLog(
        level: DFLog::RakNetConnectTrace,
        message: "[DFLog::RakNetConnectTrace] RakNet: App Level connection accepted!",
        arg0: nullptr);
    remoteSystem->connectMode = UNVERIFIED_SENDER|DISCONNECT_ASAP; /*0x1410bfbbe*/
    RakNet::SystemAddress::operator=(this: &this->firstExternalID, input: &externalID); /*0x1410bfbd4*/
    this->firstExternalID.debugPort = ntohs(netshort: this->firstExternalID.address.addr6.sin6_port); /*0x1410bfbe6*/
    v15 = byteSize; /*0x1410bfbff*/
    v16 = RakNet::RakPeer::AllocPacket( /*0x1410bfc0f*/
            this,
            dataSize: byteSize,
            data,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
            line: 0x1764u);
    v16->userMemory.bitSize = 8 * v15; /*0x1410bfc19*/
    RakNet::SystemAddress::operator=(this: &v16->userMemory.systemAddress, input: systemAddress); /*0x1410bfc22*/
    right = *systemAddress; /*0x1410bfc2c*/
    if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410bfc4b*/
    {
      RemoteSystemIndex = -1; /*0x1410bfc4d*/
    }
    else if ( right.systemIndex != 0xFFFF /*0x1410bfc95*/
           && right.systemIndex < this->maximumNumberOfPeers
           && RakNet::SystemAddress::operator==(this: &this->remoteSystemList[right.systemIndex].systemAddress, &right) != 0
           && this->remoteSystemList[right.systemIndex].isActive._Storage._Value )
    {
      RemoteSystemIndex = right.systemIndex; /*0x1410bfca4*/
    }
    else
    {
      RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, sa: &right); /*0x1410bfcb1*/
    }
    v16->userMemory.systemAddress.systemIndex = RemoteSystemIndex; /*0x1410bfcc0*/
    v16->userMemory.guid.g = remoteSystem->guid.g; /*0x1410bfccb*/
    v16->userMemory.guid.systemIndex = RemoteSystemIndex; /*0x1410bfccf*/
    RakNet::RakPeer::AddPacketToProducer(this, p: (RakNet::InternalPacket *)v16); /*0x1410bfcd9*/
    RakNet::BitStream::BitStream(this: &outBitStream); /*0x1410bfce5*/
    __wind /*0xf1c000000000001c*/
    {
      LOBYTE(byteSize) = 19; /*0x1410bfceb*/
      RakNet::BitStream::WriteBits( /*0x1410bfd09*/
        this: &outBitStream,
        inByteArray: (unsigned __int8 *)&byteSize,
        numberOfBitsToWrite: 8u,
        rightAlignedBits: true);
      v26 = 4; /*0x1410bfd0e*/
      RakNet::BitStream::WriteBits( /*0x1410bfd28*/
        this: &outBitStream,
        inByteArray: &v26,
        numberOfBitsToWrite: 8u,
        rightAlignedBits: true);
      qmemcpy(v50, systemAddress, sizeof(v50)); /*0x1410bfd32*/
      *(_DWORD *)v35 = ~systemAddress->address.addr6.sin6_flowinfo; /*0x1410bfd45*/
      RakNet::BitStream::WriteBits( /*0x1410bfd5c*/
        this: &outBitStream,
        inByteArray: v35,
        numberOfBitsToWrite: 0x20u,
        rightAlignedBits: true);
      *(_WORD *)v30 = webrtc::RtpGenericFrameDescriptor::FrameId(this: (webrtc::RtpGenericFrameDescriptor *)v50); /*0x1410bfd6a*/
      RakNet::BitStream::WriteBits( /*0x1410bfd84*/
        this: &outBitStream,
        inByteArray: v30,
        numberOfBitsToWrite: 0x10u,
        rightAlignedBits: true);
      ipList = this->ipList; /*0x1410bfd89*/
      do /*0x1410bfe12*/
      {
        v27[0] = 4; /*0x1410bfd90*/
        RakNet::BitStream::WriteBits( /*0x1410bfdaa*/
          this: &outBitStream,
          inByteArray: v27,
          numberOfBitsToWrite: 8u,
          rightAlignedBits: true);
        qmemcpy(v51, ipList, sizeof(v51)); /*0x1410bfdb2*/
        *(_DWORD *)v36 = ~ipList->address.addr6.sin6_flowinfo; /*0x1410bfdc6*/
        RakNet::BitStream::WriteBits( /*0x1410bfddd*/
          this: &outBitStream,
          inByteArray: v36,
          numberOfBitsToWrite: 0x20u,
          rightAlignedBits: true);
        *(_WORD *)v31 = webrtc::RtpGenericFrameDescriptor::FrameId(this: (webrtc::RtpGenericFrameDescriptor *)v51); /*0x1410bfdeb*/
        RakNet::BitStream::WriteBits( /*0x1410bfe05*/
          this: &outBitStream,
          inByteArray: v31,
          numberOfBitsToWrite: 0x10u,
          rightAlignedBits: true);
        ++ipList; /*0x1410bfe0a*/
        --v14; /*0x1410bfe0e*/
      }
      while ( v14 != 0 ); /*0x1410bfe12*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410bfe18*/
      {
        p_sendPongTime = (unsigned __int8 *)&sendPongTime; /*0x1410bfe39*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410bfe2e*/
          inByteArray: (unsigned __int8 *)&sendPongTime,
          inOutByteArray: v44,
          length: 8u);
        p_sendPongTime = v44; /*0x1410bfe33*/
      }
      RakNet::BitStream::WriteBits( /*0x1410bfe4e*/
        this: &outBitStream,
        inByteArray: p_sendPongTime,
        numberOfBitsToWrite: 0x40u,
        rightAlignedBits: true);
      *(_QWORD *)v39 = RakNet::GetTime(isNetworkSynced: false); /*0x1410bfe5a*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410bfe5e*/
      {
        v20 = v39; /*0x1410bfe80*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes(inByteArray: v39, inOutByteArray: v45, length: 8u); /*0x1410bfe75*/
        v20 = v45; /*0x1410bfe7a*/
      }
      RakNet::BitStream::WriteBits( /*0x1410bfe94*/
        this: &outBitStream,
        inByteArray: v20,
        numberOfBitsToWrite: 0x40u,
        rightAlignedBits: true);
      *(_QWORD *)v40 = RBX::Time::epochTimeNs() / 1000; /*0x1410bfebc*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410bfec0*/
      {
        v21 = v40; /*0x1410bfee2*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes(inByteArray: v40, inOutByteArray: v46, length: 8u); /*0x1410bfed7*/
        v21 = v46; /*0x1410bfedc*/
      }
      RakNet::BitStream::WriteBits( /*0x1410bfef6*/
        this: &outBitStream,
        inByteArray: v21,
        numberOfBitsToWrite: 0x40u,
        rightAlignedBits: true);
      TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x1410bff02*/
      RakNet::RakNetGUID::RakNetGUID(this: &v49.rakNetGuid); /*0x1410bff09*/
      RakNet::SystemAddress::SystemAddress(this: &v49.systemAddress); /*0x1410bff12*/
      v49.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410bff1e*/
      RakNet::SystemAddress::operator=(this: &v49.systemAddress, input: systemAddress); /*0x1410bff34*/
      RakNet::RakPeer::SendImmediate( /*0x1410bff7f*/
        this,
        data: (char *)outBitStream.data,
        numberOfBitsToSend: outBitStream.numberOfBitsUsed,
        priority: IMMEDIATE_PRIORITY,
        reliability: RELIABLE_ORDERED,
        orderingChannel: 0,
        systemIdentifier: &v49,
        broadcast: false,
        useCallerDataAllocation: false,
        currentTime: TimeUS,
        receipt: 0,
        isJoinData: false);
      if ( v23 == 0 ) /*0x1410bff89*/
      {
        v52 = *systemAddress; /*0x1410bff90*/
        RakNet::RakPeer::PingInternal(this, target: &v52, performImmediate: true, reliability: UNRELIABLE); /*0x1410bffb3*/
      }
      remoteSystem->recordJoinDataRxStats._Storage._Value = true; /*0x1410bffbd*/
      remoteSystem->joinRequestInitiatedTimeInMS = RakNet::GetTimeMS(); /*0x1410bffc9*/
    }
    __unwind
    {
      RakNet::BitStream::~BitStream(this: &outBitStream); /*0xf1c0000000000014*/
    }
    RakNet::BitStream::~BitStream(this: &outBitStream); /*0x1410bffd7*/
    RakNet::BitStream::~BitStream(this: &inBitStream); /*0x1410bffe4*/
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &inBitStream); /*0xf1c0000000000008*/
  }
}

// Address: 0x1410c0020 | Name: ?HandleIDNewIncomingConnection@RakPeer@RakNet@@IEAAXPEAURemoteSystemStruct@12@AEBUSystemAddress@2@PEAEII@Z
void __fastcall RakNet::RakPeer::HandleIDNewIncomingConnection(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *remoteSystem,
        const RakNet::SystemAddress *systemAddress,
        unsigned __int8 *data,
        unsigned int byteSize,
        unsigned int bitSize)
{
  unsigned __int16 *p_sin6_port; // rbx
  __int64 i; // rdi
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v12; // rbx
  unsigned __int16 remoteSystemIndex; // dx
  unsigned __int8 v14[8]; // [rsp+30h] [rbp-D0h] BYREF
  unsigned __int64 sendEpochTimeMicro; // [rsp+38h] [rbp-C8h] BYREF
  unsigned __int64 sendPongTime; // [rsp+40h] [rbp-C0h] BYREF
  unsigned __int64 sendPingTime; // [rsp+48h] [rbp-B8h] BYREF
  RakNet::SystemAddress bsSystemAddress; // [rsp+50h] [rbp-B0h] BYREF
  RakNet::SystemAddress v19; // [rsp+70h] [rbp-90h] BYREF
  RakNet::BitStream inBitStream; // [rsp+90h] [rbp-70h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+1F8h] [rbp+F8h] BYREF

  if ( remoteSystem->connectMode == HANDLING_CONNECTION_REQUEST ) /*0x1410c005a*/
  {
    remoteSystem->connectMode = UNVERIFIED_SENDER|DISCONNECT_ASAP; /*0x1410c0060*/
    v19 = *systemAddress; /*0x1410c006e*/
    RakNet::RakPeer::PingInternal(this, target: &v19, performImmediate: true, reliability: UNRELIABLE); /*0x1410c0087*/
    RakNet::SignaledEvent::SetEvent(this: (rtc::Event *)&this->quitAndDataEvents); /*0x1410c0093*/
    RakNet::BitStream::BitStream(this: &inBitStream, _data: data, lengthInBytes: byteSize, _copyData: false); /*0x1410c00a9*/
    __wind /*0xf1c0000000000010*/
    {
      RakNet::SystemAddress::SystemAddress(this: &bsSystemAddress); /*0x1410c00b4*/
      RakNet::BitStream::IgnoreBits(this: &inBitStream, numberOfBits: 8u); /*0x1410c00c2*/
      RakNet::BitStream::ReadBits(this: &inBitStream, &inOutByteArray, numberOfBitsToRead: 8u, alignBitsToRight: true); /*0x1410c00db*/
      if ( inOutByteArray == 4 ) /*0x1410c00ec*/
      {
        bsSystemAddress.address.addr6.sin6_family = 2; /*0x1410c00ee*/
        RakNet::BitStream::ReadBits( /*0x1410c0103*/
          this: &inBitStream,
          inOutByteArray: v14,
          numberOfBitsToRead: 0x20u,
          alignBitsToRight: true);
        bsSystemAddress.address.addr6.sin6_flowinfo = ~*(_DWORD *)v14; /*0x1410c010e*/
        RakNet::BitStream::ReadBits( /*0x1410c0124*/
          this: &inBitStream,
          inOutByteArray: (unsigned __int8 *)&bsSystemAddress.address.addr4.sin_port,
          numberOfBitsToRead: 0x10u,
          alignBitsToRight: true);
        bsSystemAddress.debugPort = ntohs(netshort: bsSystemAddress.address.addr6.sin6_port); /*0x1410c0134*/
      }
      p_sin6_port = &remoteSystem->theirInternalSystemAddress[0].address.addr6.sin6_port; /*0x1410c0139*/
      for ( i = 10; i != 0; --i ) /*0x1410c013d*/
      {
        RakNet::BitStream::ReadBits(this: &inBitStream, &inOutByteArray, numberOfBitsToRead: 8u, alignBitsToRight: true); /*0x1410c0164*/
        if ( inOutByteArray == 4 ) /*0x1410c0170*/
        {
          *(p_sin6_port - 1) = 2; /*0x1410c0172*/
          RakNet::BitStream::ReadBits( /*0x1410c0189*/
            this: &inBitStream,
            inOutByteArray: v14,
            numberOfBitsToRead: 0x20u,
            alignBitsToRight: true);
          *(_DWORD *)(p_sin6_port + 1) = ~*(_DWORD *)v14; /*0x1410c0194*/
          RakNet::BitStream::ReadBits( /*0x1410c01a7*/
            this: &inBitStream,
            inOutByteArray: (unsigned __int8 *)p_sin6_port,
            numberOfBitsToRead: 0x10u,
            alignBitsToRight: true);
          p_sin6_port[13] = ntohs(netshort: *p_sin6_port); /*0x1410c01b5*/
        }
        p_sin6_port += 16; /*0x1410c01b9*/
      }
      sendEpochTimeMicro = 0; /*0x1410c01c3*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c01c8*/
      {
        RakNet::BitStream::ReadBits( /*0x1410c0208*/
          this: &inBitStream,
          inOutByteArray: (unsigned __int8 *)&sendPingTime,
          numberOfBitsToRead: 0x40u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits( /*0x1410c01ea*/
                  this: &inBitStream,
                  &inOutByteArray,
                  numberOfBitsToRead: 0x40u,
                  alignBitsToRight: true) != 0 )
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410c01fc*/
          inByteArray: &inOutByteArray,
          inOutByteArray: (unsigned __int8 *)&sendPingTime,
          length: 8u);
      }
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c020d*/
      {
        RakNet::BitStream::ReadBits( /*0x1410c0251*/
          this: &inBitStream,
          inOutByteArray: (unsigned __int8 *)&sendPongTime,
          numberOfBitsToRead: 0x40u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits( /*0x1410c0231*/
                  this: &inBitStream,
                  &inOutByteArray,
                  numberOfBitsToRead: 0x40u,
                  alignBitsToRight: true) != 0 )
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410c0245*/
          inByteArray: &inOutByteArray,
          inOutByteArray: (unsigned __int8 *)&sendPongTime,
          length: 8u);
      }
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c0256*/
      {
        RakNet::BitStream::ReadBits( /*0x1410c029a*/
          this: &inBitStream,
          inOutByteArray: (unsigned __int8 *)&sendEpochTimeMicro,
          numberOfBitsToRead: 0x40u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits( /*0x1410c027a*/
                  this: &inBitStream,
                  &inOutByteArray,
                  numberOfBitsToRead: 0x40u,
                  alignBitsToRight: true) != 0 )
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410c028e*/
          inByteArray: &inOutByteArray,
          inOutByteArray: (unsigned __int8 *)&sendEpochTimeMicro,
          length: 8u);
      }
      RakNet::RakPeer::OnConnectedPong(this, sendPingTime, sendPongTime, sendEpochTimeMicro, remoteSystem); /*0x1410c02b6*/
      RakNet::SystemAddress::operator=(this: &this->firstExternalID, input: &bsSystemAddress); /*0x1410c02c7*/
      this->firstExternalID.debugPort = ntohs(netshort: this->firstExternalID.address.addr6.sin6_port); /*0x1410c02da*/
      v12 = RakNet::RakPeer::AllocPacket( /*0x1410c0302*/
              this,
              dataSize: byteSize,
              data,
              file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
              line: 0x16CBu);
      v12->userMemory.bitSize = bitSize; /*0x1410c030b*/
      RakNet::SystemAddress::operator=(this: &v12->userMemory.systemAddress, input: systemAddress); /*0x1410c0314*/
      remoteSystemIndex = remoteSystem->remoteSystemIndex; /*0x1410c0319*/
      v12->userMemory.systemAddress.systemIndex = remoteSystemIndex; /*0x1410c0320*/
      v12->userMemory.guid.g = remoteSystem->guid.g; /*0x1410c032b*/
      v12->userMemory.guid.systemIndex = remoteSystemIndex; /*0x1410c032f*/
      RakNet::RakPeer::AddPacketToProducer(this, p: (RakNet::InternalPacket *)v12); /*0x1410c0339*/
    }
    __unwind
    {
      RakNet::BitStream::~BitStream(this: &inBitStream); /*0xf1c0000000000008*/
    }
    RakNet::BitStream::~BitStream(this: &inBitStream); /*0x1410c0343*/
  }
}

// Address: 0x1410c0370 | Name: ?HandlePacketRequest@RakPeer@RakNet@@IEAAXPEAURemoteSystemStruct@12@AEBUSystemAddress@2@@Z
void __fastcall RakNet::RakPeer::HandlePacketRequest(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *remoteSystem,
        const RakNet::SystemAddress *systemAddress)
{
  unsigned int v6; // esi
  unsigned __int8 *v7; // rdi
  unsigned __int8 v8; // al
  unsigned int byteSize; // edx
  RakNet::RakPeer::RemoteSystemStruct::ConnectMode connectMode; // ecx
  void (__fastcall *AddToBanList)(struct RakNet::RakPeer *, const RakNet::SystemAddress *, unsigned int); // rbx
  unsigned int TimeoutTime; // eax
  unsigned int v13; // r8d
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v14; // rbx
  unsigned __int16 remoteSystemIndex; // dx
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v16; // rbx
  unsigned __int16 v17; // dx
  unsigned __int8 *data; // [rsp+30h] [rbp-D0h] BYREF
  unsigned __int8 v19[8]; // [rsp+38h] [rbp-C8h] BYREF
  unsigned __int8 v20[8]; // [rsp+40h] [rbp-C0h] BYREF
  unsigned __int8 v21[8]; // [rsp+48h] [rbp-B8h] BYREF
  unsigned __int8 v22[8]; // [rsp+50h] [rbp-B0h] BYREF
  unsigned __int8 inOutByteArray[8]; // [rsp+58h] [rbp-A8h] BYREF
  unsigned __int8 inByteArray[8]; // [rsp+60h] [rbp-A0h] BYREF
  unsigned __int8 v25[8]; // [rsp+68h] [rbp-98h] BYREF
  unsigned __int8 v26[8]; // [rsp+70h] [rbp-90h] BYREF
  RakNet::AddressOrGUID v27; // [rsp+78h] [rbp-88h] BYREF
  RakNet::BitStream v28; // [rsp+B0h] [rbp-50h] BYREF
  unsigned int v29; // [rsp+228h] [rbp+128h] BYREF
  unsigned __int8 v30; // [rsp+238h] [rbp+138h] BYREF

  v6 = RakNet::ReliabilityLayer::Receive( /*0x1410c03a9*/
         this: (RakNet::ReliabilityLayer *)((char *)&remoteSystem->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
         &data);
  if ( v6 != 0 )
  {
    while ( 1 )
    {
      v7 = data; /*0x1410c03c0*/
      v8 = *data; /*0x1410c03c5*/
      if ( *data == 17 ) /*0x1410c03ca*/
        return; /*0x1410c03ca*/
      byteSize = (v6 + 7) >> 3; /*0x1410c03d3*/
      connectMode = remoteSystem->connectMode; /*0x1410c03d6*/
      if ( connectMode == UNVERIFIED_SENDER ) /*0x1410c03e0*/
        break; /*0x1410c03e0*/
      switch ( v8 )
      {
        case 9u:
          if ( connectMode != REQUESTED_CONNECTION ) /*0x1410c048b*/
          {
            RakNet::BitStream::BitStream(this: &v28, _data: data, lengthInBytes: byteSize, _copyData: false); /*0x1410c049e*/
            __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000040*/
            RakNet::BitStream::IgnoreBytes(this: &v28, numberOfBytes: 1u); /*0x1410c04ad*/
            RakNet::BitStream::IgnoreBytes(this: &v28, numberOfBytes: 0x10u); /*0x1410c04bb*/
            RakNet::BitStream::IgnoreBytes(this: &v28, numberOfBytes: 8u); /*0x1410c04c9*/
            if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c04ce*/
            {
              RakNet::BitStream::ReadBits( /*0x1410c050e*/
                this: &v28,
                inOutByteArray: v20,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true);
            }
            else if ( RakNet::BitStream::ReadBits( /*0x1410c04f0*/
                        this: &v28,
                        inOutByteArray,
                        numberOfBitsToRead: 0x40u,
                        alignBitsToRight: true) != 0 )
            {
              RBX::Network::NetworkStream::ReverseBytes(inByteArray: inOutByteArray, inOutByteArray: v20, length: 8u); /*0x1410c0502*/
            }
            RakNet::RakPeer::OnConnectionRequest(this, remoteSystem, incomingTimestamp: *(unsigned __int64 *)v20); /*0x1410c051e*/
            if ( __eh34_unwind(0) ) /*0xf1c0000000000034*/
              goto unwind_state_0; /*0xf1c0000000000034*/
            __eh34_exit_wind_state(0, -1); /*0xf1c0000000000038*/
            RakNet::BitStream::~BitStream(this: &v28); /*0x1410c0528*/
            goto LABEL_55; /*0x1410c052d*/
          }
LABEL_5:
          RakNet::RakPeer::ParseConnectionRequestPacket(this, remoteSystem, systemAddress, (const char *)data, byteSize); /*0x1410c03ea*/
LABEL_55:
          operator delete(ptr: v7); /*0x1410c087f*/
          break; /*0x1410c0882*/
        case 0x13u:
          if ( byteSize <= 0x1F ) /*0x1410c0539*/
            goto LABEL_55; /*0x1410c0539*/
          RakNet::RakPeer::HandleIDNewIncomingConnection(this, remoteSystem, systemAddress, data, byteSize, bitSize: v6); /*0x1410c0553*/
          break;
        case 3u:
          if ( byteSize == 25 ) /*0x1410c0568*/
          {
            *(_QWORD *)v19 = 0; /*0x1410c056e*/
            RakNet::BitStream::BitStream(this: &v28, _data: data, lengthInBytes: 0x19u, _copyData: false); /*0x1410c0584*/
            __eh34_enter_wind_state(-1, 0); /*0xf1c000000000002c*/
            RakNet::BitStream::IgnoreBits(this: &v28, numberOfBits: 8u); /*0x1410c0593*/
            if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c0598*/
            {
              RakNet::BitStream::ReadBits( /*0x1410c05d8*/
                this: &v28,
                inOutByteArray: v22,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true);
            }
            else if ( RakNet::BitStream::ReadBits( /*0x1410c05ba*/
                        this: &v28,
                        inOutByteArray: inByteArray,
                        numberOfBitsToRead: 0x40u,
                        alignBitsToRight: true) != 0 )
            {
              RBX::Network::NetworkStream::ReverseBytes(inByteArray, inOutByteArray: v22, length: 8u); /*0x1410c05cc*/
            }
            if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c05dd*/
            {
              RakNet::BitStream::ReadBits( /*0x1410c061d*/
                this: &v28,
                inOutByteArray: v21,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true);
            }
            else if ( RakNet::BitStream::ReadBits( /*0x1410c05ff*/
                        this: &v28,
                        inOutByteArray: v25,
                        numberOfBitsToRead: 0x40u,
                        alignBitsToRight: true) != 0 )
            {
              RBX::Network::NetworkStream::ReverseBytes(inByteArray: v25, inOutByteArray: v21, length: 8u); /*0x1410c0611*/
            }
            if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c0622*/
            {
              RakNet::BitStream::ReadBits( /*0x1410c0662*/
                this: &v28,
                inOutByteArray: v19,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true);
            }
            else if ( RakNet::BitStream::ReadBits( /*0x1410c0644*/
                        this: &v28,
                        inOutByteArray: v26,
                        numberOfBitsToRead: 0x40u,
                        alignBitsToRight: true) != 0 )
            {
              RBX::Network::NetworkStream::ReverseBytes(inByteArray: v26, inOutByteArray: v19, length: 8u); /*0x1410c0656*/
            }
            RakNet::RakPeer::OnConnectedPong( /*0x1410c067e*/
              this,
              sendPingTime: *(unsigned __int64 *)v22,
              sendPongTime: *(unsigned __int64 *)v21,
              sendEpochTimeMicro: *(unsigned __int64 *)v19,
              remoteSystem);
            operator delete(ptr: v7); /*0x1410c0686*/
            if ( __eh34_unwind(0) ) /*0xf1c0000000000020*/
              goto unwind_state_0; /*0xf1c0000000000020*/
            __eh34_exit_wind_state(0, -1); /*0xf1c0000000000024*/
            RakNet::BitStream::~BitStream(this: &v28); /*0x1410c0690*/
            break; /*0x1410c0695*/
          }
          goto LABEL_55; /*0x1410c0568*/
        default:
          if ( v8 != 0 )
          {
            switch ( v8 )
            {
              case 0x15u:
                if ( v6 >= 0x28 )
                {
                  RakNet::BitStream::BitStream(this: &v28, _data: data, lengthInBytes: byteSize, _copyData: false); /*0x1410c06df*/
                  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000018*/
                  RakNet::BitStream::IgnoreBits(this: &v28, numberOfBits: 8u); /*0x1410c06ee*/
                  if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c06f3*/
                  {
                    RakNet::BitStream::ReadBits( /*0x1410c073b*/
                      this: &v28,
                      inOutByteArray: (unsigned __int8 *)&v29,
                      numberOfBitsToRead: 0x20u,
                      alignBitsToRight: true);
                  }
                  else if ( RakNet::BitStream::ReadBits( /*0x1410c0717*/
                              this: &v28,
                              inOutByteArray: &v30,
                              numberOfBitsToRead: 0x20u,
                              alignBitsToRight: true) != 0 )
                  {
                    RBX::Network::NetworkStream::ReverseBytes( /*0x1410c072d*/
                      inByteArray: &v30,
                      inOutByteArray: (unsigned __int8 *)&v29,
                      length: 4u);
                  }
                  v13 = v29; /*0x1410c0740*/
                  this->disconnectReason = v29; /*0x1410c0747*/
                  if ( FLog::Network != 0 )
                    FLog::FastLogFormatted(
                      level: FLog::Network,
                      message: "[FLog::Network] Disconnect reason received: %d",
                      v13);
                  if ( __eh34_unwind(0) ) /*0xf1c0000000000004*/
                  {
unwind_state_0:
                    RakNet::BitStream::~BitStream(this: &v28); /*0xf1c0000000000008*/
                    __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000000c*/
                  }
                  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000010*/
                  RakNet::BitStream::~BitStream(this: &v28); /*0x1410c076c*/
                }
                remoteSystem->connectMode = DISCONNECT_ON_NO_ACK; /*0x1410c0771*/
                goto LABEL_55; /*0x1410c077c*/
              case 4u:
                goto LABEL_55; /*0x1410c0783*/
              case 0x18u:
                if ( connectMode != REQUESTED_CONNECTION ) /*0x1410c0790*/
                  goto LABEL_55; /*0x1410c0790*/
                v14 = RakNet::RakPeer::AllocPacket( /*0x1410c07b0*/
                        this,
                        dataSize: byteSize,
                        data,
                        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                        line: 0x1720u);
                v14->userMemory.bitSize = v6; /*0x1410c07b3*/
                RakNet::SystemAddress::operator=(this: &v14->userMemory.systemAddress, input: systemAddress); /*0x1410c07bc*/
                remoteSystemIndex = remoteSystem->remoteSystemIndex; /*0x1410c07c1*/
                v14->userMemory.systemAddress.systemIndex = remoteSystemIndex; /*0x1410c07c9*/
                v14->userMemory.guid.g = remoteSystem->guid.g; /*0x1410c07d4*/
                v14->userMemory.guid.systemIndex = remoteSystemIndex; /*0x1410c07d8*/
                RakNet::RakPeer::AddPacketToProducer(this, p: (RakNet::InternalPacket *)v14); /*0x1410c07e2*/
                remoteSystem->connectMode = DISCONNECT_ASAP_SILENTLY; /*0x1410c07e7*/
                break;
              case 0x10u:
                RakNet::RakPeer::HandleIDConnectionRequestAccepted(this, remoteSystem, systemAddress, data, byteSize); /*0x1410c080b*/
                break;
              default:
                if ( v8 < 0x1Bu && (unsigned __int8)(v8 - 14) > 1u ) /*0x1410c081a*/
                  goto LABEL_55; /*0x1410c081a*/
                if ( !remoteSystem->isActive._Storage._Value ) /*0x1410c0823*/
                {
                  v7 = data; /*0x1410c087a*/
                  goto LABEL_55; /*0x1410c087a*/
                }
                v16 = RakNet::RakPeer::AllocPacket( /*0x1410c0841*/
                        this,
                        dataSize: byteSize,
                        data,
                        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                        line: 0x17DAu);
                v16->userMemory.bitSize = v6; /*0x1410c0844*/
                RakNet::SystemAddress::operator=(this: &v16->userMemory.systemAddress, input: systemAddress); /*0x1410c084d*/
                v17 = remoteSystem->remoteSystemIndex; /*0x1410c0852*/
                v16->userMemory.systemAddress.systemIndex = v17; /*0x1410c085a*/
                v16->userMemory.guid.g = remoteSystem->guid.g; /*0x1410c0865*/
                v16->userMemory.guid.systemIndex = v17; /*0x1410c0869*/
                RakNet::RakPeer::AddPacketToProducer(this, p: (RakNet::InternalPacket *)v16); /*0x1410c0873*/
                break;
            }
          }
          else
          {
            if ( byteSize != 9 ) /*0x1410c06a1*/
              goto LABEL_55; /*0x1410c06a1*/
            RakNet::RakPeer::HandleIDConnectedPing(this, remoteSystem, systemAddress, data, byteSize: 9u); /*0x1410c06b7*/
          }
          break;
      }
      v6 = RakNet::ReliabilityLayer::Receive( /*0x1410c0887*/
             this: (RakNet::ReliabilityLayer *)((char *)&remoteSystem->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
             &data);
      if ( v6 == 0 ) /*0x1410c089c*/
        return; /*0x1410c089c*/
    }
    if ( v8 == 9 ) /*0x1410c03e8*/
      goto LABEL_5; /*0x1410c03e8*/
    RakNet::RakNetGUID::RakNetGUID(this: &v27.rakNetGuid); /*0x1410c0409*/
    RakNet::SystemAddress::SystemAddress(this: &v27.systemAddress); /*0x1410c0412*/
    v27.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410c041e*/
    RakNet::SystemAddress::operator=(this: &v27.systemAddress, input: systemAddress); /*0x1410c0435*/
    RakNet::RakPeer::CloseConnectionInternal( /*0x1410c0455*/
      this,
      systemIdentifier: &v27,
      sendDisconnectionNotification: false,
      performImmediate: true,
      orderingChannel: 0,
      disconnectionNotificationPriority: LOW_PRIORITY);
    AddToBanList = this->AddToBanList; /*0x1410c045d*/
    TimeoutTime = RakNet::ReliabilityLayer::GetTimeoutTime(this: (RakNet::ReliabilityLayer *)((char *)&remoteSystem->reliabilityLayer.rbxSessionCrypto._Ptr /*0x1410c046b*/
                                                                                            + 4));
    AddToBanList(this, a2: systemAddress, a3: TimeoutTime); /*0x1410c0479*/
    goto LABEL_55; /*0x1410c047b*/
  }
}

// Address: 0x1410c08c0 | Name: ?HandleRequestedConnectionQueue@RakPeer@RakNet@@IEAAXAEB_K0@Z
void __fastcall RakNet::RakPeer::HandleRequestedConnectionQueue(
        RakNet::RakPeer *this,
        const unsigned __int64 *timeUS,
        const unsigned __int64 *timeMS)
{
  RakNet::SimpleMutex *p_requestedConnectionQueueMutex; // r13
  unsigned int v5; // r15d
  const unsigned __int64 *v6; // rbx
  unsigned int head; // r8d
  unsigned int tail; // ecx
  unsigned int v9; // ecx
  __int64 v10; // rdx
  unsigned int v11; // r8d
  RakNet::RakPeer::RequestedConnectionStruct *v12; // rdi
  int requestsMade; // r14d
  int v14; // ebp
  char v15; // al
  bool v16; // bl
  char *data; // rcx
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v18; // rbx
  RBX::Network::Peer *peerPlugin; // rcx
  unsigned int v20; // r10d
  unsigned int v21; // r9d
  unsigned int v22; // r11d
  unsigned int i; // ebx
  unsigned int v24; // eax
  __int64 v25; // rax

  p_requestedConnectionQueueMutex = &this->requestedConnectionQueueMutex; /*0x1410c08d6*/
  v5 = 0; /*0x1410c08e3*/
  v6 = timeMS; /*0x1410c08e6*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410c08e9*/
  while ( 1 )
  {
    head = this->requestedConnectionQueue.head; /*0x1410c0900*/
    tail = this->requestedConnectionQueue.tail; /*0x1410c0907*/
    v9 = head > tail ? this->requestedConnectionQueue.allocation_size - head + tail : tail - head;
    if ( v5 >= v9 ) /*0x1410c0925*/
      break; /*0x1410c0925*/
    v10 = head + v5; /*0x1410c092b*/
    v11 = v5 + head - this->requestedConnectionQueue.allocation_size; /*0x1410c093f*/
    if ( (unsigned int)v10 >= this->requestedConnectionQueue.allocation_size ) /*0x1410c0947*/
      v10 = v11; /*0x1410c0947*/
    v12 = this->requestedConnectionQueue.array[v10]; /*0x1410c094b*/
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_requestedConnectionQueueMutex->criticalSection); /*0x1410c0952*/
    if ( v12->nextRequestTime >= *v6 )
    {
LABEL_14:
      ++v5; /*0x1410c09bb*/
      rtc::CriticalSection::Enter(lpCriticalSection: &p_requestedConnectionQueueMutex->criticalSection); /*0x1410c09c1*/
    }
    else
    {
      if ( DFLog::RakNetConnectTrace != 0 )
        FLog::FastLogFormatted(
          level: DFLog::RakNetConnectTrace,
          message: "[DFLog::RakNetConnectTrace] RakNet : OpenRequest1 next request time triggered, requestsMade %u",
          v12->requestsMade);
      requestsMade = v12->requestsMade; /*0x1410c098b*/
      v14 = v12->sendConnectionAttemptCount + 1; /*0x1410c0993*/
      v15 = RakNet::SystemAddress::operator==(this: &v12->systemAddress, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30); /*0x1410c0995*/
      v16 = v15 == 1; /*0x1410c099c*/
      if ( requestsMade != v14 && v15 != 1 ) /*0x1410c09a6*/
      {
        v6 = timeMS; /*0x1410c09a8*/
        RakNet::RakPeer::sendRbxOpenRequest1(this, rcs: v12, timeMS); /*0x1410c09b6*/
        goto LABEL_14; /*0x1410c09b6*/
      }
      data = v12->data; /*0x1410c09cb*/
      if ( data != nullptr ) /*0x1410c09d2*/
      {
        operator delete(ptr: data); /*0x1410c09d4*/
        v12->data = nullptr; /*0x1410c09d9*/
      }
      if ( requestsMade == v14 && !v16 && v12->actionToTake == CONNECT )
      {
        if ( DFLog::RakNetConnectTrace != 0 )
          FLog::FastLogFormatted(
            level: DFLog::RakNetConnectTrace,
            message: "[DFLog::RakNetConnectTrace] RakNet : Too many attempts tries : timed out, inform failure");
        v18 = RakNet::RakPeer::AllocPacket( /*0x1410c0a29*/
                this,
                dataSize: 1u,
                file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                line: 0x1654u);
        *v18->userMemory.data = 17; /*0x1410c0a30*/
        v18->userMemory.bitSize = 8; /*0x1410c0a36*/
        RakNet::SystemAddress::operator=(this: &v18->userMemory.systemAddress, input: &v12->systemAddress); /*0x1410c0a3d*/
        RakNet::RakPeer::AddPacketToProducer(this, p: (RakNet::InternalPacket *)v18); /*0x1410c0a48*/
        peerPlugin = this->peerPlugin; /*0x1410c0a4d*/
        if ( peerPlugin != nullptr ) /*0x1410c0a57*/
          peerPlugin->OnConnectFirstStageTimeout(this: peerPlugin, a2: &v12->systemAddress); /*0x1410c0a5f*/
      }
      RakNet::RakPeer::RequestedConnectionStruct::`scalar deleting destructor'(this: v12, a2: 1); /*0x1410c0a6d*/
      rtc::CriticalSection::Enter(lpCriticalSection: &p_requestedConnectionQueueMutex->criticalSection); /*0x1410c0a75*/
      v20 = this->requestedConnectionQueue.head; /*0x1410c0a7a*/
      v21 = 0; /*0x1410c0a81*/
      v22 = this->requestedConnectionQueue.tail; /*0x1410c0a84*/
      for ( i = v20; ; ++i )
      {
        v24 = v20 > v22 ? v22 + this->requestedConnectionQueue.allocation_size - v20 : v22 - v20;
        if ( v21 >= v24 ) /*0x1410c0aac*/
          break; /*0x1410c0aac*/
        v25 = i; /*0x1410c0ab2*/
        if ( i >= this->requestedConnectionQueue.allocation_size ) /*0x1410c0ac4*/
          v25 = v21 + v20 - this->requestedConnectionQueue.allocation_size; /*0x1410c0ac4*/
        if ( this->requestedConnectionQueue.array[v25] == v12 ) /*0x1410c0acb*/
        {
          DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::RemoveAtIndex( /*0x1410c0ada*/
            this: &this->requestedConnectionQueue,
            position: v21);
          break; /*0x1410c0ada*/
        }
        ++v21; /*0x1410c0acd*/
      }
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_requestedConnectionQueueMutex->criticalSection); /*0x1410c0adf*/
      v6 = timeMS; /*0x1410c0ae7*/
      rtc::CriticalSection::Enter(lpCriticalSection: &p_requestedConnectionQueueMutex->criticalSection); /*0x1410c0aef*/
    }
  }
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_requestedConnectionQueueMutex->criticalSection); /*0x1410c0b17*/
}

// Address: 0x1410c0b60 | Name: ?IncrementNextSendReceipt@RakPeer@RakNet@@UEAAIXZ
__int64 __fastcall RakNet::RakPeer::IncrementNextSendReceipt(RakNet::RakPeer *this)
{
  unsigned int sendReceiptSerial; // esi

  rtc::CriticalSection::Enter(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410c0b79*/
  sendReceiptSerial = this->sendReceiptSerial; /*0x1410c0b7e*/
  this->sendReceiptSerial = sendReceiptSerial + 1; /*0x1410c0b87*/
  if ( sendReceiptSerial == -1 ) /*0x1410c0b8f*/
    this->sendReceiptSerial = 1; /*0x1410c0b91*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410c0ba2*/
  return sendReceiptSerial; /*0x1410c0ba7*/
}

// Address: 0x1410c0bc0 | Name: ?InitBandwidthTracker@RakPeer@RakNet@@UEAAXXZ
void __fastcall RakNet::RakPeer::InitBandwidthTracker(RakNet::RakPeer *this)
{
  std::shared_ptr<RBX::DownloadBandwidthTracker> *v2; // rax
  RBX::DownloadBandwidthTracker *v3; // rcx
  std::_Ref_count_base *Rep; // rdx
  std::_Ref_count_base *v5; // rbx
  volatile signed __int32 *v6; // rbx
  char *v7; // rcx
  std::string *v8; // rax
  const std::string *v9; // rax
  char *v10; // rcx
  char *v11; // rcx
  char *v12; // rax
  char *v13; // rcx
  char *v14; // rax
  char *v15; // rcx
  char *v16; // rcx
  char *v17; // rcx
  std::string counterName; // [rsp+40h] [rbp-C0h] BYREF
  std::string resource; // [rsp+60h] [rbp-A0h] BYREF
  RBX::NetworkUtils::ErrorInfo errInfo; // [rsp+80h] [rbp-80h] BYREF
  std::string ptr; // [rsp+D0h] [rbp-30h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v22; // [rsp+F0h] [rbp-10h] BYREF
  unsigned __int64 v23; // [rsp+138h] [rbp+38h]
  RBX::unique_function<void __cdecl(double,unsigned __int64)> v24; // [rsp+140h] [rbp+40h] BYREF
  std::string result; // [rsp+160h] [rbp+60h] BYREF
  boost::filesystem::path cacheDirectory; // [rsp+180h] [rbp+80h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+1A0h] [rbp+A0h] BYREF

  if ( this->downloadBandwidthTracker._Ptr == nullptr ) /*0x1410c0bea*/
  {
    __wind /*0xf1c00000000000a0*/
    {
      errInfo.syscallName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410c0bf2*/
      errInfo.syscallName._Mypair._Myval2._Mysize = 0; /*0x1410c0bf6*/
      errInfo.syscallName._Mypair._Myval2._Myres = 15; /*0x1410c0bfa*/
      errInfo.errdata._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410c0c06*/
      errInfo.errdata._Mypair._Myval2._Mysize = 0; /*0x1410c0c0a*/
      errInfo.errdata._Mypair._Myval2._Myres = 15; /*0x1410c0c0e*/
      RBX::FileSystem::getCacheDirectory(result: &cacheDirectory, create: true, subDirectory: "raknet"); /*0x1410c0c2a*/
      __wind /*0xf1c00000000000ac*/
      {
        __wind /*0xf1c00000000000b4*/
        {
          *(_QWORD *)&v22.color = reportExpBwCountStats; /*0x1410c0c42*/
          v23 = (unsigned __int64)&`RBX::unique_function<void (int)>::unique_function<void (int)>'::`8'::Callback /*0x1410c0c55*/
              & 0xFFFFFFFFFFFFFFF9uLL
              | 2;
          v24.StorageUnion.OutOfLineStorage.StoragePtr = reportComputedBwStats; /*0x1410c0c6b*/
          v24.CallbackAndInlineFlag.Value = (unsigned __int64)`RBX::unique_function<void (double,unsigned __int64)>::unique_function<void (double,unsigned __int64)>'::`8'::Callback /*0x1410c0c7e*/
                                          & 0xFFFFFFFFFFFFFFF9uLL
                                          | 2;
          ptr._Mypair._Myval2._Myres = 15; /*0x1410c0c9a*/
          ptr._Mypair._Myval2._Mysize = 6; /*0x1410c0ca2*/
          *(_DWORD *)ptr._Mypair._Myval2._Bx._Buf = *(_DWORD *)"raknet"; /*0x1410c0cb0*/
          *(_DWORD *)&ptr._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"et"; /*0x1410c0cba*/
          v2 = RBX::DownloadBandwidthTracker::create( /*0x1410c0cf9*/
                 result: (std::shared_ptr<RBX::DownloadBandwidthTracker> *)&v22.x,
                 logPrefix: &ptr,
                 directory: &cacheDirectory,
                 cacheFilenameSeed: &DFString::RaknetDownloadBandwidthCacheFileName,
                 minEpisodeDuration: COERCE_RBX_TIME_INTERVAL((double)DFInt::RaknetDownloadEpisodeInMs * 0.001),
                 &errInfo,
                 bwComputedReportStats: &v24,
                 expBwCountReportStats: (RBX::unique_function<void __cdecl(int)> *)&v22.color);
          v3 = v2->_Ptr; /*0x1410c0cfe*/
          Rep = v2->_Rep; /*0x1410c0d01*/
          v2->_Ptr = nullptr; /*0x1410c0d05*/
          v2->_Rep = nullptr; /*0x1410c0d08*/
          this->downloadBandwidthTracker._Ptr = v3; /*0x1410c0d0c*/
          v5 = this->downloadBandwidthTracker._Rep; /*0x1410c0d13*/
          this->downloadBandwidthTracker._Rep = Rep; /*0x1410c0d1a*/
          if ( v5 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410c0d33*/
          {
            v5->_Destroy(this: v5); /*0x1410c0d3b*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c0d47*/
              v5->_Delete_this(this: v5); /*0x1410c0d4f*/
          }
          v6 = *(volatile signed __int32 **)&v22.width; /*0x1410c0d52*/
          if ( *(_QWORD *)&v22.width != 0 /*0x1410c0d65*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)&v22.width + 8LL), 0xFFFFFFFF) == 1 )
          {
            (**(void (__fastcall ***)(volatile signed __int32 *))v6)(a1: v6); /*0x1410c0d6d*/
            if ( _InterlockedExchangeAdd(v6 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c0d77*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 8LL))(a1: v6); /*0x1410c0d7f*/
          }
          if ( ptr._Mypair._Myval2._Myres >= 0x10 ) /*0x1410c0d8b*/
          {
            v7 = ptr._Mypair._Myval2._Bx._Ptr; /*0x1410c0d90*/
            if ( ptr._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410c0d9e*/
            {
              v7 = *((char **)ptr._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c0da4*/
              if ( (unsigned __int64)(ptr._Mypair._Myval2._Bx._Ptr - v7 - 8) > 0x1F ) /*0x1410c0db3*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410c0db5*/
            }
            operator delete(ptr: v7); /*0x1410c0dbc*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&ptr); /*0xf1c0000000000098*/
        }
        if ( errInfo.syscallName._Mypair._Myval2._Mysize != 0 ) /*0x1410c0dc6*/
        {
          v8 = RBX::SystemUtil::osPlatform(&result); /*0x1410c0dd0*/
          __wind /*0xf1c0000000000088*/
          {
            v9 = std::operator+<char>(result: &v22.text, _Left: "DownloadBandwidthNetworkIdNotFound-", _Right: v8); /*0x1410c0de4*/
            __wind /*0xf1c0000000000064*/
            {
              RBX::Analytics::EphemeralCounter::reportCounter(counterName: v9, amount: 1, blocking: false); /*0x1410c0df4*/
              if ( v22.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410c0e02*/
              {
                v10 = v22.text._Mypair._Myval2._Bx._Ptr; /*0x1410c0e07*/
                if ( v22.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410c0e15*/
                {
                  v10 = *((char **)v22.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c0e1b*/
                  if ( (unsigned __int64)(v22.text._Mypair._Myval2._Bx._Ptr - v10 - 8) > 0x1F ) /*0x1410c0e2a*/
                    _invalid_parameter_noinfo_noreturn(); /*0x1410c0e2c*/
                }
                operator delete(ptr: v10); /*0x1410c0e33*/
              }
              v22.text._Mypair._Myval2._Mysize = 0; /*0x1410c0e38*/
              v22.text._Mypair._Myval2._Myres = 15; /*0x1410c0e3c*/
              v22.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410c0e44*/
              if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x1410c0e50*/
              {
                v11 = result._Mypair._Myval2._Bx._Ptr; /*0x1410c0e55*/
                if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410c0e63*/
                {
                  v11 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c0e69*/
                  if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v11 - 8) > 0x1F ) /*0x1410c0e78*/
                    _invalid_parameter_noinfo_noreturn(); /*0x1410c0e7a*/
                }
                operator delete(ptr: v11); /*0x1410c0e81*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v22); /*0xf1c0000000000074*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000080*/
          }
          counterName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410c0e86*/
          counterName._Mypair._Myval2._Mysize = 0; /*0x1410c0e8b*/
          counterName._Mypair._Myval2._Myres = 15; /*0x1410c0e90*/
          v12 = (char *)operator new(size: 0x30u); /*0x1410c0ea3*/
          __wind /*0xf1c0000000000058*/
          {
            counterName._Mypair._Myval2._Mysize = 38; /*0x1410c0ea8*/
            counterName._Mypair._Myval2._Myres = 47; /*0x1410c0eb1*/
            strcpy(v12, "DownloadBandwidthNetworkIdNotFound-All"); /*0x1410c0ec1*/
            counterName._Mypair._Myval2._Bx._Ptr = v12; /*0x1410c0ee7*/
            RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x1410c0ef8*/
            if ( counterName._Mypair._Myval2._Myres >= 0x10 ) /*0x1410c0f07*/
            {
              v13 = counterName._Mypair._Myval2._Bx._Ptr; /*0x1410c0f0c*/
              if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410c0f1b*/
              {
                v13 = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c0f21*/
                if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - v13 - 8) > 0x1F ) /*0x1410c0f30*/
                  _invalid_parameter_noinfo_noreturn(); /*0x1410c0f32*/
              }
              operator delete(ptr: v13); /*0x1410c0f39*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c0000000000050*/
          }
          if ( RBX::Analytics::InfluxDb::canSend(throttleHundredthsPercentage: DFInt::DownloadBandwidthNetworkIdFailInfluxHundredthsPercentage) ) /*0x1410c0f44*/
          {
            RBX::Analytics::InfluxDb::Points::Points( /*0x1410c0f64*/
              this: &points,
              throttleHundredthsPercentage: DFInt::DownloadBandwidthNetworkIdFailInfluxHundredthsPercentage,
              categoryType: kStandardType,
              priorityHundredthsPercentage: 0);
            __wind /*0xf1c000000000001c*/
            {
              RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c0f7c*/
                this: &points,
                name: "NetworkIdNotFoundFailedSyscall",
                value: &errInfo.syscallName);
              RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c0f93*/
                this: &points,
                name: "NetworkIdNotFoundSyscallReturnValue",
                value: errInfo.returnValue);
              RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c0faa*/
                this: &points,
                name: "NetworkIdNotFoundErrno",
                value: errInfo.err);
              RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c0fc1*/
                this: &points,
                name: "NetworkIdNotFoundErrData",
                value: &errInfo.errdata);
              resource._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410c0fc6*/
              resource._Mypair._Myval2._Mysize = 0; /*0x1410c0fcb*/
              resource._Mypair._Myval2._Myres = 15; /*0x1410c0fd0*/
              v14 = (char *)operator new(size: 0x20u); /*0x1410c0fe3*/
              resource._Mypair._Myval2._Mysize = 26; /*0x1410c0fe8*/
              resource._Mypair._Myval2._Myres = 31; /*0x1410c0ff1*/
              strcpy(v14, "DownloadBandwidthNetworkId"); /*0x1410c1001*/
              resource._Mypair._Myval2._Bx._Ptr = v14; /*0x1410c1020*/
              __wind /*0xf1c0000000000010*/
              {
                RBX::Analytics::InfluxDb::Points::report( /*0x1410c103a*/
                  this: &points,
                  &resource,
                  throttleHundredthsPercentage: 10000,
                  blocking: false);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000008*/
              }
              if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x1410c1049*/
              {
                v15 = resource._Mypair._Myval2._Bx._Ptr; /*0x1410c104e*/
                if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410c105d*/
                {
                  v15 = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c1063*/
                  if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - v15 - 8) > 0x1F ) /*0x1410c1072*/
                    _invalid_parameter_noinfo_noreturn(); /*0x1410c1074*/
                }
                operator delete(ptr: v15); /*0x1410c107b*/
              }
              RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0x1410c1088*/
            }
            __unwind
            {
              RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c000000000002c*/
            }
          }
        }
      }
      __unwind
      {
        boost::filesystem::path::~path(this: (std::pair<std::wstring const ,char const *> *)&cacheDirectory); /*0xf1c0000000000038*/
      }
    }
    __unwind
    {
      std::tuple<std::pair<std::string,enum RBX::AssetImport::NodeType>,std::pair<std::string,enum RBX::AssetImport::NodeType>>::~tuple<std::pair<std::string,enum RBX::AssetImport::NodeType>,std::pair<std::string,enum RBX::AssetImport::NodeType>>(this: (std::tuple<std::string,int,std::string > *)&errInfo); /*0xf1c0000000000044*/
    }
    boost::filesystem::path::~path(this: (std::pair<std::wstring const ,char const *> *)&cacheDirectory); /*0x1410c1095*/
    if ( errInfo.errdata._Mypair._Myval2._Myres >= 0x10 ) /*0x1410c10a3*/
    {
      v16 = errInfo.errdata._Mypair._Myval2._Bx._Ptr; /*0x1410c10a8*/
      if ( errInfo.errdata._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410c10b6*/
      {
        v16 = *((char **)errInfo.errdata._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c10bc*/
        if ( (unsigned __int64)(errInfo.errdata._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x1410c10cb*/
LABEL_49:
          _invalid_parameter_noinfo_noreturn(); /*0x1410c1114*/
      }
      operator delete(ptr: v16); /*0x1410c10cd*/
    }
    errInfo.errdata._Mypair._Myval2._Mysize = 0; /*0x1410c10d2*/
    errInfo.errdata._Mypair._Myval2._Myres = 15; /*0x1410c10d6*/
    errInfo.errdata._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410c10de*/
    if ( errInfo.syscallName._Mypair._Myval2._Myres >= 0x10 ) /*0x1410c10ea*/
    {
      v17 = errInfo.syscallName._Mypair._Myval2._Bx._Ptr; /*0x1410c10ef*/
      if ( errInfo.syscallName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410c10fd*/
      {
        v17 = *((char **)errInfo.syscallName._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c1103*/
        if ( (unsigned __int64)(errInfo.syscallName._Mypair._Myval2._Bx._Ptr - v17 - 8) > 0x1F ) /*0x1410c1112*/
          goto LABEL_49; /*0x1410c1112*/
      }
      operator delete(ptr: v17); /*0x1410c111b*/
    }
  }
}

// Address: 0x1410c1430 | Name: ?IsActive@RakPeer@RakNet@@UEBA_NXZ
bool __fastcall RakNet::RakPeer::IsActive(RakNet::RakPeer *this)
{
  return !this->endThreads._Storage._Value; /*0x1410c143a*/
}

// Address: 0x1410c1440 | Name: ?IsBanned@RakPeer@RakNet@@UEAA_NAEBUSystemAddress@2@@Z
bool __fastcall RakNet::RakPeer::IsBanned(RakNet::RakPeer *this, const RakNet::SystemAddress *ipAddress)
{
  std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BanStruct *> > > > banIter; // [rsp+30h] [rbp+8h] BYREF

  if ( this->banMap._List._Mypair._Myval2._Mysize == 0 ) /*0x1410c1458*/
    return false; /*0x1410c145a*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->banListMutex.criticalSection); /*0x1410c1473*/
  std::_Hash<std::_Umap_traits<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,std::_Uhash_compare<RakNet::SystemAddress,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>,0>>::find<void>( /*0x1410c1487*/
    this: (std::_Hash<std::_Umap_traits<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,std::_Uhash_compare<RakNet::SystemAddress,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress> >,std::allocator<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker> >,0> > *)&this->banMap,
    result: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker> > > > *)&banIter,
    _Keyval: ipAddress);
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->banListMutex.criticalSection); /*0x1410c1493*/
  return banIter._Ptr != this->banMap._List._Mypair._Myval2._Myhead; /*0x1410c145c*/
}

// Address: 0x1410c14c0 | Name: ?IsInSecurityExceptionList@RakPeer@RakNet@@UEAA_NPEBD@Z
char __fastcall RakNet::RakPeer::IsInSecurityExceptionList(RakNet::RakPeer *this, const char *ip)
{
  __int64 v5; // rbx

  if ( this->securityExceptionList.list_size == 0 ) /*0x1410c14d7*/
    return 0; /*0x1410c14d9*/
  v5 = 0; /*0x1410c14f7*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->securityExceptionMutex.criticalSection); /*0x1410c14f9*/
  if ( this->securityExceptionList.list_size != 0 ) /*0x1410c1504*/
  {
    while ( !RakNet::RakString::IPAddressMatch(this: &this->securityExceptionList.listArray[v5], IP: ip) ) /*0x1410c1525*/
    {
      v5 = (unsigned int)(v5 + 1); /*0x1410c1527*/
      if ( (unsigned int)v5 >= this->securityExceptionList.list_size ) /*0x1410c152f*/
        goto LABEL_6; /*0x1410c152f*/
    }
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->securityExceptionMutex.criticalSection); /*0x1410c155b*/
    return 1; /*0x1410c1560*/
  }
  else
  {
LABEL_6:
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->securityExceptionMutex.criticalSection); /*0x1410c1531*/
    return 0; /*0x1410c153d*/
  }
}

// Address: 0x1410c1570 | Name: ?IsLocalIP@RakPeer@RakNet@@UEAA_NPEBD@Z
char __fastcall RakNet::RakPeer::IsLocalIP(RakNet::RakPeer *this, const char *ip)
{
  unsigned int v4; // ebx
  __int64 v5; // rcx
  char v6; // al
  int v8; // esi

  if ( ip != nullptr && *ip != 0 ) /*0x1410c1597*/
  {
    if ( strcmp_0(Str1: ip, Str2: "127.0.0.1") == 0 /*0x1410c15c1*/
      || strcmp_0(Str1: ip, Str2: (const char *)&RBX::Studio::ClientDataModel::`vftable'[20]) == 0 )
    {
      return 1; /*0x1410c15e5*/
    }
    v4 = 0; /*0x1410c15c3*/
    v5 = 0; /*0x1410c15cc*/
    while ( 1 ) /*0x1410c15d0*/
    {
      v6 = ip[v5++]; /*0x1410c15d0*/
      if ( v6 != a1_9[v5 - 1] ) /*0x1410c15db*/
        break; /*0x1410c15db*/
      if ( v5 == 4 ) /*0x1410c15e1*/
        return 1; /*0x1410c15e1*/
    }
    v8 = ((__int64 (__fastcall *)(RakNet::RakPeer *, const char *))this->GetNumberOfAddresses)(a1: this, a2: "::1"); /*0x1410c15f3*/
    if ( v8 > 0 ) /*0x1410c15f7*/
    {
      while ( strcmp(ip, this->GetLocalIP(this, a2: v4)) != 0 ) /*0x1410c1637*/
      {
        if ( (int)++v4 >= v8 ) /*0x1410c163d*/
          return 0; /*0x1410c163d*/
      }
      return 1; /*0x1410c1637*/
    }
  }
  return 0; /*0x1410c1641*/
}

// Address: 0x1410c1920 | Name: ?NotifyAndFlagForShutdown@RakPeer@RakNet@@IEAAXUSystemAddress@2@_NEW4PacketPriority@@PEBDI@Z
void __fastcall RakNet::RakPeer::NotifyAndFlagForShutdown(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *systemAddress,
        bool performImmediate,
        char orderingChannel,
        PacketPriority disconnectionNotificationPriority)
{
  unsigned __int8 *p_reasonToStream; // rdx
  unsigned __int64 TimeUS; // rbx
  unsigned int RemoteSystemIndex; // eax
  __int64 v12; // rdx
  RakNet::RakPeer::RemoteSystemStruct *v13; // rcx
  RakNet::AddressOrGUID v14; // [rsp+60h] [rbp-A0h] BYREF
  RakNet::BitStream temp; // [rsp+90h] [rbp-70h] BYREF
  unsigned int reasonToStream; // [rsp+1E0h] [rbp+E0h] BYREF
  unsigned __int8 inByteArray; // [rsp+1F0h] [rbp+F0h] BYREF

  RakNet::BitStream::BitStream(this: &temp, initialBytesToAllocate: 1u); /*0x1410c1954*/
  __wind
  {
    if ( FLog::Network != 0 )
      FLog::FastLogFormatted(
        level: FLog::Network,
        message: "[FLog::Network] Sending disconnect with reason: %d",
        this->disconnectReason);
    inByteArray = 21; /*0x1410c197a*/
    RakNet::BitStream::WriteBits(this: &temp, &inByteArray, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410c1995*/
    reasonToStream = this->disconnectReason; /*0x1410c19a0*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c19a6*/
    {
      p_reasonToStream = (unsigned __int8 *)&reasonToStream; /*0x1410c19d1*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410c19c3*/
        inByteArray: (unsigned __int8 *)&reasonToStream,
        inOutByteArray: &inByteArray,
        length: 4u);
      p_reasonToStream = &inByteArray; /*0x1410c19c8*/
    }
    RakNet::BitStream::WriteBits( /*0x1410c19e5*/
      this: &temp,
      inByteArray: p_reasonToStream,
      numberOfBitsToWrite: 0x20u,
      rightAlignedBits: true);
    if ( performImmediate ) /*0x1410c19ec*/
    {
      TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x1410c19f9*/
      RakNet::RakNetGUID::RakNetGUID(this: &v14.rakNetGuid); /*0x1410c1a01*/
      RakNet::SystemAddress::SystemAddress(this: &v14.systemAddress); /*0x1410c1a0b*/
      v14.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410c1a17*/
      RakNet::SystemAddress::operator=(this: &v14.systemAddress, input: systemAddress); /*0x1410c1a30*/
      RakNet::RakPeer::SendImmediate( /*0x1410c1a7a*/
        this,
        data: (char *)temp.data,
        numberOfBitsToSend: temp.numberOfBitsUsed,
        priority: disconnectionNotificationPriority,
        reliability: RELIABLE_ORDERED,
        orderingChannel,
        systemIdentifier: &v14,
        broadcast: false,
        useCallerDataAllocation: false,
        currentTime: TimeUS,
        receipt: 0,
        isJoinData: false);
      v14.rakNetGuid = *(RakNet::RakNetGUID *)&systemAddress->address.addr6.sin6_family; /*0x1410c1a82*/
      *(_OWORD *)&v14.systemAddress.address.addr6.sin6_family = *((_OWORD *)&systemAddress->address.addr4 + 1); /*0x1410c1a8b*/
      if ( RakNet::SystemAddress::operator==( /*0x1410c1aa3*/
             this: (RakNet::SystemAddress *)&v14,
             right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 )
      {
        RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, sa: (const RakNet::SystemAddress *)&v14); /*0x1410c1ab1*/
        if ( RemoteSystemIndex != -1 ) /*0x1410c1ab9*/
        {
          v12 = RemoteSystemIndex; /*0x1410c1ac1*/
          if ( this->remoteSystemList[v12].isActive._Storage._Value ) /*0x1410c1acf*/
          {
            v13 = &this->remoteSystemList[v12]; /*0x1410c1ae4*/
            if ( v13 != nullptr ) /*0x1410c1ae7*/
              v13->connectMode = DISCONNECT_ASAP; /*0x1410c1aed*/
          }
        }
      }
    }
    else
    {
      RakNet::RakNetGUID::RakNetGUID(this: &v14.rakNetGuid); /*0x1410c1b01*/
      RakNet::SystemAddress::SystemAddress(this: &v14.systemAddress); /*0x1410c1b0b*/
      v14.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410c1b17*/
      RakNet::SystemAddress::operator=(this: &v14.systemAddress, input: systemAddress); /*0x1410c1b30*/
      RakNet::RakPeer::SendBuffered( /*0x1410c1b78*/
        this,
        data: (const char *)temp.data,
        numberOfBitsToSend: temp.numberOfBitsUsed,
        priority: disconnectionNotificationPriority,
        reliability: RELIABLE_ORDERED,
        orderingChannel,
        systemIdentifier: &v14,
        broadcast: false,
        connectionMode: DISCONNECT_ASAP,
        receipt: 0,
        isJoinData: false);
    }
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &temp); /*0xf1c0000000000008*/
  }
  RakNet::BitStream::~BitStream(this: &temp); /*0x1410c1b82*/
}

// Address: 0x1410c1ba0 | Name: ?NumberOfConnections@RakPeer@RakNet@@UEBAGXZ
__int64 __fastcall RakNet::RakPeer::NumberOfConnections(RakNet::RakPeer *this)
{
  __int64 result; // rax
  DataStructures::List<RakNet::SystemAddress> addresses; // [rsp+20h] [rbp-28h] BYREF
  DataStructures::List<RakNet::RakNetGUID> guids; // [rsp+30h] [rbp-18h] BYREF

  *(_QWORD *)&addresses.list_size = 0; /*0x1410c1ba8*/
  addresses.listArray = nullptr; /*0x1410c1bad*/
  *(_QWORD *)&guids.list_size = 0; /*0x1410c1bb2*/
  guids.listArray = nullptr; /*0x1410c1bb7*/
  __wind /*0xf1c000000000001c*/
  {
    __wind /*0xf1c0000000000024*/
    {
      ((void (*)(void))this->GetSystemList)(); /*0x1410c1bc9*/
      result = LOWORD(addresses.list_size); /*0x1410c1bf7*/
    }
    __unwind
    {
      DataStructures::List<bool>::~List<bool>(this: (DataStructures::List<bool> *)&guids); /*0xf1c0000000000008*/
    }
  }
  __unwind
  {
    DataStructures::List<bool>::~List<bool>(this: (DataStructures::List<bool> *)&addresses); /*0xf1c0000000000014*/
  }
  return result; /*0x1410c1bfa*/
}

// Address: 0x1410c1c00 | Name: ?OnConnectedPong@RakPeer@RakNet@@IEAAX_K00PEAURemoteSystemStruct@12@@Z
void __fastcall RakNet::RakPeer::OnConnectedPong(
        RakNet::RakPeer *this,
        unsigned __int64 sendPingTime,
        unsigned __int64 sendPongTime,
        unsigned __int64 sendEpochTimeMicro,
        RakNet::RakPeer::RemoteSystemStruct *remoteSystem)
{
  unsigned __int64 TimeUS; // r13
  __int64 v9; // r15
  RBX::Network::Peer *peerPlugin; // r11
  __int64 *p_monotonicClockDifferentialMS; // rcx
  __int64 v12; // r10
  int v13; // r8d
  int v14; // eax
  int v15; // edx
  __int64 v16; // r9
  unsigned __int64 v17; // rax

  TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x1410c1c31*/
  v9 = TimeUS / 0x3E8 - sendPingTime; /*0x1410c1c60*/
  if ( TimeUS / 0x3E8 <= sendPingTime ) /*0x1410c1c66*/
    LODWORD(v9) = 0; /*0x1410c1c66*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410c1c6a*/
  remoteSystem->pingAndClockDifferential[remoteSystem->pingAndClockDifferentialWriteIndex].pingTime = v9; /*0x1410c1c9a*/
  remoteSystem->pingAndClockDifferential[remoteSystem->pingAndClockDifferentialWriteIndex].monotonicClockDifferentialMS = sendPongTime - TimeUS / 0x7D0 - (sendPingTime >> 1); /*0x1410c1caa*/
  peerPlugin = this->peerPlugin; /*0x1410c1cb2*/
  if ( peerPlugin != nullptr ) /*0x1410c1cbe*/
  {
    p_monotonicClockDifferentialMS = &remoteSystem->pingAndClockDifferential[0].monotonicClockDifferentialMS; /*0x1410c1cc3*/
    v12 = 0; /*0x1410c1cca*/
    v13 = 0; /*0x1410c1ccd*/
    v14 = 0xFFFF; /*0x1410c1cd7*/
    do /*0x1410c1d07*/
    {
      v15 = *((unsigned __int16 *)p_monotonicClockDifferentialMS - 4); /*0x1410c1ce0*/
      v16 = (unsigned int)v14; /*0x1410c1ce4*/
      if ( (_WORD)v15 == 0xFFFF ) /*0x1410c1cea*/
        break; /*0x1410c1cea*/
      if ( v15 < v14 ) /*0x1410c1cee*/
        v12 = *p_monotonicClockDifferentialMS; /*0x1410c1cf0*/
      ++v13; /*0x1410c1cf3*/
      p_monotonicClockDifferentialMS += 2; /*0x1410c1cf6*/
      v14 = v15; /*0x1410c1cfd*/
      if ( v15 >= (int)v16 ) /*0x1410c1cff*/
        v14 = v16; /*0x1410c1cff*/
    }
    while ( v13 < 5 ); /*0x1410c1d07*/
    ((void (__fastcall *)(RBX::Network::Peer *, unsigned __int64, unsigned __int64, __int64))peerPlugin->updateMonotonicClockDifferential)( /*0x1410c1d32*/
      a1: peerPlugin,
      a2: TimeUS,
      a3: v12 + sendEpochTimeMicro / 0x3E8 - sendPongTime,
      a4: v16);
  }
  if ( remoteSystem->lowestPing._Storage._Value == 0xFFFF || remoteSystem->lowestPing._Storage._Value > (int)v9 ) /*0x1410c1d46*/
    remoteSystem->lowestPing._Storage._Value = v9; /*0x1410c1d48*/
  v17 = ++remoteSystem->pingAndClockDifferentialWriteIndex; /*0x1410c1d57*/
  if ( v17 == 5 ) /*0x1410c1d62*/
    v17 = 0; /*0x1410c1d62*/
  remoteSystem->pingAndClockDifferentialWriteIndex = v17; /*0x1410c1d66*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410c1d89*/
}

// Address: 0x1410c1d90 | Name: ?OnConnectionRequest@RakPeer@RakNet@@IEAAXPEAURemoteSystemStruct@12@_K@Z
void __fastcall RakNet::RakPeer::OnConnectionRequest(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *remoteSystem,
        unsigned __int64 incomingTimestamp)
{
  unsigned __int16 RemoteSystemIndex; // ax
  unsigned __int8 *p_systemIndex; // rdx
  RakNet::SystemAddress *ipList; // rbx
  __int64 i; // rdi
  unsigned __int8 *v9; // rdx
  unsigned __int8 *v10; // rdx
  unsigned __int8 *v11; // rdx
  unsigned __int64 TimeUS; // rbx
  unsigned __int8 v13[4]; // [rsp+60h] [rbp-A0h] BYREF
  unsigned __int8 v14[4]; // [rsp+64h] [rbp-9Ch] BYREF
  unsigned __int8 v15[8]; // [rsp+68h] [rbp-98h] BYREF
  unsigned __int8 v16[8]; // [rsp+70h] [rbp-90h] BYREF
  unsigned __int8 inOutByteArray[8]; // [rsp+78h] [rbp-88h] BYREF
  unsigned __int8 v18[8]; // [rsp+80h] [rbp-80h] BYREF
  unsigned __int8 v19[8]; // [rsp+88h] [rbp-78h] BYREF
  RakNet::SystemAddress right; // [rsp+90h] [rbp-70h] BYREF
  _BYTE v21[32]; // [rsp+B0h] [rbp-50h] BYREF
  RakNet::AddressOrGUID v22; // [rsp+D0h] [rbp-30h] BYREF
  RakNet::BitStream bitStream; // [rsp+100h] [rbp+0h] BYREF
  unsigned __int8 inByteArray; // [rsp+268h] [rbp+168h] BYREF
  unsigned __int64 v25; // [rsp+270h] [rbp+170h] BYREF
  unsigned __int16 systemIndex; // [rsp+278h] [rbp+178h] BYREF

  v25 = incomingTimestamp; /*0x1410c1d90*/
  RakNet::BitStream::BitStream(this: &bitStream); /*0x1410c1db4*/
  inByteArray = 16; /*0x1410c1dba*/
  __wind /*0xf1c0000000000010*/
  {
    RakNet::BitStream::WriteBits(this: &bitStream, &inByteArray, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410c1dd5*/
    inByteArray = 4; /*0x1410c1dda*/
    RakNet::BitStream::WriteBits(this: &bitStream, &inByteArray, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410c1df5*/
    qmemcpy(v21, &remoteSystem->systemAddress, sizeof(v21)); /*0x1410c1dff*/
    *(_DWORD *)v14 = ~remoteSystem->systemAddress.address.addr6.sin6_flowinfo; /*0x1410c1e12*/
    RakNet::BitStream::WriteBits(this: &bitStream, inByteArray: v14, numberOfBitsToWrite: 0x20u, rightAlignedBits: true); /*0x1410c1e28*/
    *(_WORD *)v13 = webrtc::RtpGenericFrameDescriptor::FrameId(this: (webrtc::RtpGenericFrameDescriptor *)v21); /*0x1410c1e36*/
    RakNet::BitStream::WriteBits(this: &bitStream, inByteArray: v13, numberOfBitsToWrite: 0x10u, rightAlignedBits: true); /*0x1410c1e4d*/
    right = remoteSystem->systemAddress; /*0x1410c1e57*/
    if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410c1e76*/
    {
      RemoteSystemIndex = -1; /*0x1410c1e78*/
    }
    else if ( right.systemIndex != 0xFFFF /*0x1410c1ec0*/
           && right.systemIndex < this->maximumNumberOfPeers
           && RakNet::SystemAddress::operator==(this: &this->remoteSystemList[right.systemIndex].systemAddress, &right) != 0
           && this->remoteSystemList[right.systemIndex].isActive._Storage._Value )
    {
      RemoteSystemIndex = right.systemIndex; /*0x1410c1ecf*/
    }
    else
    {
      RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, sa: &right); /*0x1410c1edc*/
    }
    systemIndex = RemoteSystemIndex; /*0x1410c1ee1*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c1ee8*/
    {
      p_systemIndex = (unsigned __int8 *)&systemIndex; /*0x1410c1f13*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410c1f05*/
        inByteArray: (unsigned __int8 *)&systemIndex,
        inOutByteArray: &inByteArray,
        length: 2u);
      p_systemIndex = &inByteArray; /*0x1410c1f0a*/
    }
    RakNet::BitStream::WriteBits( /*0x1410c1f27*/
      this: &bitStream,
      inByteArray: p_systemIndex,
      numberOfBitsToWrite: 0x10u,
      rightAlignedBits: true);
    ipList = this->ipList; /*0x1410c1f2c*/
    for ( i = 10; i != 0; --i ) /*0x1410c1f33*/
    {
      inByteArray = 4; /*0x1410c1f40*/
      RakNet::BitStream::WriteBits(this: &bitStream, &inByteArray, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410c1f5b*/
      qmemcpy(v21, ipList, sizeof(v21)); /*0x1410c1f63*/
      *(_DWORD *)v14 = ~ipList->address.addr6.sin6_flowinfo; /*0x1410c1f74*/
      RakNet::BitStream::WriteBits( /*0x1410c1f8a*/
        this: &bitStream,
        inByteArray: v14,
        numberOfBitsToWrite: 0x20u,
        rightAlignedBits: true);
      *(_WORD *)v13 = webrtc::RtpGenericFrameDescriptor::FrameId(this: (webrtc::RtpGenericFrameDescriptor *)v21); /*0x1410c1f98*/
      RakNet::BitStream::WriteBits( /*0x1410c1faf*/
        this: &bitStream,
        inByteArray: v13,
        numberOfBitsToWrite: 0x10u,
        rightAlignedBits: true);
      ++ipList; /*0x1410c1fb4*/
    }
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c1fbe*/
    {
      v9 = (unsigned __int8 *)&v25; /*0x1410c1fe3*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes(inByteArray: (unsigned __int8 *)&v25, inOutByteArray, length: 8u); /*0x1410c1fd7*/
      v9 = inOutByteArray; /*0x1410c1fdc*/
    }
    RakNet::BitStream::WriteBits(this: &bitStream, inByteArray: v9, numberOfBitsToWrite: 0x40u, rightAlignedBits: true); /*0x1410c1ff7*/
    *(_QWORD *)v15 = RakNet::GetTime(isNetworkSynced: false); /*0x1410c2003*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c2008*/
    {
      v10 = v15; /*0x1410c202b*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes(inByteArray: v15, inOutByteArray: v18, length: 8u); /*0x1410c2020*/
      v10 = v18; /*0x1410c2025*/
    }
    RakNet::BitStream::WriteBits(this: &bitStream, inByteArray: v10, numberOfBitsToWrite: 0x40u, rightAlignedBits: true); /*0x1410c203d*/
    *(_QWORD *)v16 = RBX::Time::epochTimeNs() / 1000; /*0x1410c2065*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c206a*/
    {
      v11 = v16; /*0x1410c208d*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes(inByteArray: v16, inOutByteArray: v19, length: 8u); /*0x1410c2082*/
      v11 = v19; /*0x1410c2087*/
    }
    RakNet::BitStream::WriteBits(this: &bitStream, inByteArray: v11, numberOfBitsToWrite: 0x40u, rightAlignedBits: true); /*0x1410c209f*/
    TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x1410c20ab*/
    RakNet::RakNetGUID::RakNetGUID(this: &v22.rakNetGuid); /*0x1410c20b2*/
    RakNet::SystemAddress::SystemAddress(this: &v22.systemAddress); /*0x1410c20bb*/
    v22.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410c20c7*/
    RakNet::SystemAddress::operator=(this: &v22.systemAddress, input: &remoteSystem->systemAddress); /*0x1410c20de*/
    RakNet::RakPeer::SendImmediate( /*0x1410c2123*/
      this,
      data: (char *)bitStream.data,
      numberOfBitsToSend: bitStream.numberOfBitsUsed,
      priority: IMMEDIATE_PRIORITY,
      reliability: RELIABLE_ORDERED,
      orderingChannel: 0,
      systemIdentifier: &v22,
      broadcast: false,
      useCallerDataAllocation: false,
      currentTime: TimeUS,
      receipt: 0,
      isJoinData: false);
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &bitStream); /*0xf1c0000000000008*/
  }
  RakNet::BitStream::~BitStream(this: &bitStream); /*0x1410c212d*/
}

// Address: 0x1410c2140 | Name: ?ParseConnectionRequestPacket@RakPeer@RakNet@@IEAAXPEAURemoteSystemStruct@12@AEBUSystemAddress@2@PEBDH@Z
void __fastcall RakNet::RakPeer::ParseConnectionRequestPacket(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *remoteSystem,
        const RakNet::SystemAddress *systemAddress,
        char *data,
        unsigned int byteSize)
{
  unsigned int v8; // ebx
  RBX::Security::SessionCrypto *v9; // rbx
  RakNet::RakPeer_vtbl *v10; // rax
  unsigned __int8 *v11; // rbx
  unsigned __int8 *v12; // rdx
  unsigned __int64 TimeUS; // rbx
  unsigned __int8 inOutByteArray[8]; // [rsp+60h] [rbp-A0h] BYREF
  unsigned __int64 incomingTimestamp; // [rsp+68h] [rbp-98h] BYREF
  RakNet::RakNetGUID guid; // [rsp+70h] [rbp-90h] BYREF
  RakNet::AddressOrGUID v17; // [rsp+80h] [rbp-80h] BYREF
  RakNet::BitStream bs; // [rsp+B0h] [rbp-50h] BYREF
  RakNet::BitStream bitStream; // [rsp+1E0h] [rbp+E0h] BYREF
  unsigned __int8 doSecurity; // [rsp+330h] [rbp+230h] BYREF

  v8 = byteSize; /*0x1410c216c*/
  RakNet::BitStream::BitStream(this: &bs, _data: (unsigned __int8 *)data, lengthInBytes: byteSize, _copyData: false); /*0x1410c217c*/
  __wind /*0xf1c0000000000028*/
  {
    RakNet::BitStream::IgnoreBytes(this: &bs, numberOfBytes: 1u); /*0x1410c218b*/
    RakNet::RakNetGUID::RakNetGUID(this: &guid); /*0x1410c2195*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c219a*/
    {
      RakNet::BitStream::ReadBits( /*0x1410c21da*/
        this: &bs,
        inOutByteArray: (unsigned __int8 *)&guid,
        numberOfBitsToRead: 0x40u,
        alignBitsToRight: true);
    }
    else if ( RakNet::BitStream::ReadBits(this: &bs, inOutByteArray, numberOfBitsToRead: 0x40u, alignBitsToRight: true) != 0 ) /*0x1410c21bc*/
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410c21ce*/
        inByteArray: inOutByteArray,
        inOutByteArray: (unsigned __int8 *)&guid,
        length: 8u);
    }
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c21df*/
    {
      RakNet::BitStream::ReadBits( /*0x1410c221f*/
        this: &bs,
        inOutByteArray: (unsigned __int8 *)&incomingTimestamp,
        numberOfBitsToRead: 0x40u,
        alignBitsToRight: true);
    }
    else if ( RakNet::BitStream::ReadBits(this: &bs, inOutByteArray, numberOfBitsToRead: 0x40u, alignBitsToRight: true) != 0 ) /*0x1410c2201*/
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410c2213*/
        inByteArray: inOutByteArray,
        inOutByteArray: (unsigned __int8 *)&incomingTimestamp,
        length: 8u);
    }
    RakNet::BitStream::ReadBits(this: &bs, inOutByteArray: &doSecurity, numberOfBitsToRead: 8u, alignBitsToRight: true); /*0x1410c2238*/
    if ( this->incomingPasswordLength == v8 - ((bs.readOffset + 7) >> 3) /*0x1410c226e*/
      && memcmp_0(
           Buf1: &bs.data[(unsigned __int64)(bs.readOffset + 7) >> 3],
           Buf2: this->incomingPassword,
           Size: this->incomingPasswordLength) == 0 )
    {
      remoteSystem->connectMode = HANDLING_CONNECTION_REQUEST; /*0x1410c2270*/
      v9 = *(RBX::Security::RakPeerCrypto **)((char *)&remoteSystem->reliabilityLayer.rbxSessionCrypto._Ptr + 4); /*0x1410c227a*/
      if ( v9 != nullptr /*0x1410c2289*/
        && !RBX::Security::SessionCrypto::isKeyExchangeComplete(this: *(RBX::Security::SessionCrypto **)((char *)&remoteSystem->reliabilityLayer.rbxSessionCrypto._Ptr + 4)) )
      {
        RBX::Security::SessionCrypto::resetKeyExchangeKeys(this: v9, error: false); /*0x1410c2297*/
      }
      RakNet::RakPeer::OnConnectionRequest(this, remoteSystem, incomingTimestamp); /*0x1410c22a7*/
    }
    else
    {
      RakNet::BitStream::BitStream(this: &bitStream); /*0x1410c22b8*/
      __wind /*0xf1c000000000001c*/
      {
        LOBYTE(byteSize) = 24; /*0x1410c22be*/
        RakNet::BitStream::WriteBits( /*0x1410c22dc*/
          this: &bitStream,
          inByteArray: (unsigned __int8 *)&byteSize,
          numberOfBitsToWrite: 8u,
          rightAlignedBits: true);
        v10 = this->__vftable; /*0x1410c22e1*/
        *(RakNet::SystemAddress *)&v17.rakNetGuid.g = RakNet::UNASSIGNED_SYSTEM_ADDRESS_30; /*0x1410c22eb*/
        v11 = (unsigned __int8 *)v10->GetGuidFromSystemAddress(this, a2: (const RakNet::SystemAddress *)&v17); /*0x1410c2307*/
        if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c230a*/
        {
          v12 = v11; /*0x1410c232d*/
        }
        else
        {
          RBX::Network::NetworkStream::ReverseBytes(inByteArray: v11, inOutByteArray, length: 8u); /*0x1410c2321*/
          v12 = inOutByteArray; /*0x1410c2326*/
        }
        RakNet::BitStream::WriteBits( /*0x1410c2340*/
          this: &bitStream,
          inByteArray: v12,
          numberOfBitsToWrite: 0x40u,
          rightAlignedBits: true);
        TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x1410c234c*/
        RakNet::RakNetGUID::RakNetGUID(this: &v17.rakNetGuid); /*0x1410c2353*/
        RakNet::SystemAddress::SystemAddress(this: &v17.systemAddress); /*0x1410c235c*/
        v17.rakNetGuid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410c2368*/
        RakNet::SystemAddress::operator=(this: &v17.systemAddress, input: systemAddress); /*0x1410c237e*/
        RakNet::RakPeer::SendImmediate( /*0x1410c23d1*/
          this,
          data: (char *)bitStream.data,
          numberOfBitsToSend: (bitStream.numberOfBitsUsed + 7) >> 3,
          priority: IMMEDIATE_PRIORITY,
          reliability: RELIABLE,
          orderingChannel: 0,
          systemIdentifier: &v17,
          broadcast: false,
          useCallerDataAllocation: false,
          currentTime: TimeUS,
          receipt: 0,
          isJoinData: false);
        remoteSystem->connectMode = DISCONNECT_ASAP_SILENTLY; /*0x1410c23d6*/
      }
      __unwind
      {
        RakNet::BitStream::~BitStream(this: &bitStream); /*0xf1c0000000000014*/
      }
      RakNet::BitStream::~BitStream(this: &bitStream); /*0x1410c23e7*/
    }
    RakNet::BitStream::~BitStream(this: &bs); /*0x1410c23f1*/
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &bs); /*0xf1c0000000000008*/
  }
}

// Address: 0x1410c2410 | Name: ?PingInternal@RakPeer@RakNet@@IEAAXUSystemAddress@2@_NW4PacketReliability@@@Z
void __fastcall RakNet::RakPeer::PingInternal(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *target,
        bool performImmediate,
        PacketReliability reliability)
{
  unsigned int RemoteSystemIndex; // eax
  __int64 v9; // rdx
  RakNet::RakPeer::RemoteSystemStruct *v10; // rax
  unsigned __int8 *p_inByteArray; // rdx
  unsigned __int64 TimeUS; // rbx
  const RakNet::AddressOrGUID *v13; // rax
  unsigned int (__fastcall *Send_2)(struct RakNet::RakPeer *, const RakNet::AbstractBitStream *, PacketPriority, PacketReliability, char, const RakNet::AddressOrGUID *__struct_ptr, bool, unsigned int); // rbx
  RakNet::AddressOrGUID *v15; // rax
  unsigned __int8 inOutByteArray[16]; // [rsp+60h] [rbp-198h] BYREF
  RakNet::SystemAddress sa; // [rsp+70h] [rbp-188h] BYREF
  RakNet::AddressOrGUID v18; // [rsp+90h] [rbp-168h] BYREF
  RakNet::BitStream bitStream; // [rsp+C0h] [rbp-138h] BYREF
  unsigned __int64 inByteArray; // [rsp+200h] [rbp+8h] BYREF

  if ( this->IsActive(this) ) /*0x1410c2437*/
  {
    RakNet::BitStream::BitStream(this: &bitStream, initialBytesToAllocate: 9u); /*0x1410c244f*/
    __wind /*0xf1c0000000000010*/
    {
      LOBYTE(inByteArray) = 0; /*0x1410c2455*/
      RakNet::BitStream::WriteBits( /*0x1410c2476*/
        this: &bitStream,
        (unsigned __int8 *)&inByteArray,
        numberOfBitsToWrite: 8u,
        rightAlignedBits: true);
      sa = *target; /*0x1410c247e*/
      if ( RakNet::SystemAddress::operator==(this: &sa, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 /*0x1410c24ce*/
        || (RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, &sa)) == -1
        || !*(&this->remoteSystemList->isActive._Storage._Value + (v9 = RemoteSystemIndex)) )
      {
        v10 = nullptr; /*0x1410c24dc*/
      }
      else
      {
        v10 = &this->remoteSystemList[v9]; /*0x1410c24d7*/
      }
      inByteArray = RakNet::GetTime(isNetworkSynced: v10 == nullptr); /*0x1410c24e9*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c24f1*/
      {
        p_inByteArray = (unsigned __int8 *)&inByteArray; /*0x1410c2519*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, inOutByteArray, length: 8u); /*0x1410c250d*/
        p_inByteArray = inOutByteArray; /*0x1410c2512*/
      }
      RakNet::BitStream::WriteBits( /*0x1410c2532*/
        this: &bitStream,
        inByteArray: p_inByteArray,
        numberOfBitsToWrite: 0x40u,
        rightAlignedBits: true);
      if ( performImmediate ) /*0x1410c2539*/
      {
        TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x1410c2542*/
        v13 = RakNet::AddressOrGUID::AddressOrGUID(this: &v18, input: target); /*0x1410c2550*/
        RakNet::RakPeer::SendImmediate( /*0x1410c2595*/
          this,
          data: (char *)bitStream.data,
          numberOfBitsToSend: bitStream.numberOfBitsUsed,
          priority: IMMEDIATE_PRIORITY,
          reliability,
          orderingChannel: 0,
          systemIdentifier: v13,
          broadcast: false,
          useCallerDataAllocation: false,
          currentTime: TimeUS,
          receipt: 0,
          isJoinData: false);
      }
      else
      {
        Send_2 = this->Send_2; /*0x1410c259f*/
        v15 = RakNet::AddressOrGUID::AddressOrGUID(this: &v18, input: target); /*0x1410c25b1*/
        Send_2(this, a2: &bitStream, a3: IMMEDIATE_PRIORITY, a4: reliability, a5: 0, a6: v15, a7: false, a8: 0); /*0x1410c25de*/
      }
    }
    __unwind
    {
      RakNet::BitStream::~BitStream(this: &bitStream); /*0xf1c0000000000008*/
    }
    RakNet::BitStream::~BitStream(this: &bitStream); /*0x1410c25e9*/
  }
}

// Address: 0x1410c2610 | Name: ?ProcessArtificialLatencyTransmitPackets@RakPeer@RakNet@@IEAA_K_K@Z
unsigned __int64 __fastcall RakNet::RakPeer::ProcessArtificialLatencyTransmitPackets(
        RakNet::RakPeer *this,
        unsigned __int64 timeUS)
{
  RakNet::SimpleMutex *p_queueMutex; // rbp
  unsigned int head; // ecx
  unsigned int tail; // ebx
  int v7; // ebx
  int *p_peakTxQueueSize; // rax
  unsigned __int64 v9; // r15
  unsigned __int64 timeToSend; // rbx
  unsigned int v11; // eax
  unsigned int v12; // eax
  unsigned int v13; // eax
  unsigned int allocation_size; // ecx
  RakNet::DelayTransmitStruct **array; // rsi
  __int64 v16; // rax
  DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::MemoryWithPage *v17; // rsi
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v20; // ett
  RakNet::RakNetSocket *Ptr; // rcx
  std::_Ref_count_base *v22; // rbx
  int v23; // eax
  unsigned __int64 *p_txQueueMaxDelay; // rax
  RakNet::ReliabilityLayer *reliabilityLayer; // rcx
  volatile signed __int32 *v26; // rcx
  unsigned int v27; // eax
  std::shared_ptr<RakNet::RakNetSocket> socket; // [rsp+20h] [rbp-48h] BYREF
  int v30; // [rsp+70h] [rbp+8h] BYREF
  unsigned __int64 v31; // [rsp+78h] [rbp+10h] BYREF

  p_queueMutex = &this->artificialDelayTransmitPackets.queueMutex; /*0x1410c262a*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayTransmitPackets.queueMutex.criticalSection); /*0x1410c2634*/
  head = this->artificialDelayTransmitPackets.queue.head; /*0x1410c2639*/
  tail = this->artificialDelayTransmitPackets.queue.tail; /*0x1410c263f*/
  if ( head > tail ) /*0x1410c2647*/
    v7 = this->artificialDelayTransmitPackets.queue.allocation_size - head + tail; /*0x1410c2655*/
  else
    v7 = tail - head; /*0x1410c2649*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_queueMutex->criticalSection); /*0x1410c265a*/
  v30 = v7; /*0x1410c265f*/
  p_peakTxQueueSize = &v30; /*0x1410c266a*/
  if ( this->artificialLatencyStats.peakTxQueueSize >= v7 ) /*0x1410c2671*/
    p_peakTxQueueSize = &this->artificialLatencyStats.peakTxQueueSize; /*0x1410c2671*/
  this->artificialLatencyStats.peakTxQueueSize = *p_peakTxQueueSize; /*0x1410c2677*/
  v9 = -1; /*0x1410c2679*/
  while ( 1 ) /*0x1410c2680*/
  {
    timeToSend = -1; /*0x1410c2680*/
    rtc::CriticalSection::Enter(lpCriticalSection: &p_queueMutex->criticalSection); /*0x1410c2686*/
    v11 = this->artificialDelayTransmitPackets.queue.head; /*0x1410c268b*/
    if ( v11 != this->artificialDelayTransmitPackets.queue.tail ) /*0x1410c2697*/
      timeToSend = this->artificialDelayTransmitPackets.queue.array[v11]->timeToSend; /*0x1410c26a6*/
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_queueMutex->criticalSection); /*0x1410c26b0*/
    rtc::CriticalSection::Enter(lpCriticalSection: &p_queueMutex->criticalSection); /*0x1410c26b8*/
    if ( timeToSend > timeUS ) /*0x1410c26c0*/
      break; /*0x1410c26c0*/
    v12 = this->artificialDelayTransmitPackets.queue.head; /*0x1410c26c6*/
    if ( v12 == this->artificialDelayTransmitPackets.queue.tail ) /*0x1410c26d2*/
    {
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_queueMutex->criticalSection); /*0x1410c26d7*/
    }
    else
    {
      v13 = v12 + 1; /*0x1410c26de*/
      this->artificialDelayTransmitPackets.queue.head = v13; /*0x1410c26e0*/
      allocation_size = this->artificialDelayTransmitPackets.queue.allocation_size; /*0x1410c26e6*/
      if ( v13 == allocation_size ) /*0x1410c26ee*/
      {
        this->artificialDelayTransmitPackets.queue.head = 0; /*0x1410c26f0*/
        array = this->artificialDelayTransmitPackets.queue.array; /*0x1410c26fa*/
        v16 = allocation_size - 1; /*0x1410c2701*/
      }
      else
      {
        array = this->artificialDelayTransmitPackets.queue.array; /*0x1410c2706*/
        if ( v13 != 0 ) /*0x1410c270f*/
          v16 = v13 - 1; /*0x1410c2716*/
        else
          v16 = allocation_size - 1; /*0x1410c2711*/
      }
      v17 = (DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::MemoryWithPage *)array[v16]; /*0x1410c2718*/
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_queueMutex->criticalSection); /*0x1410c271f*/
      if ( v17 != nullptr ) /*0x1410c2727*/
      {
        socket = 0; /*0x1410c2730*/
        Rep = v17->userMemory.socket._Rep; /*0x1410c2736*/
        if ( Rep != nullptr && (Uses = Rep->_Uses) != 0 ) /*0x1410c2747*/
        {
          while ( 1 ) /*0x1410c2753*/
          {
            v20 = Uses; /*0x1410c2753*/
            Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x1410c2753*/
            if ( v20 == Uses ) /*0x1410c2758*/
              break; /*0x1410c2758*/
            if ( Uses == 0 ) /*0x1410c275c*/
              goto LABEL_22; /*0x1410c275c*/
          }
          Ptr = v17->userMemory.socket._Ptr; /*0x1410c27bd*/
          socket._Ptr = v17->userMemory.socket._Ptr; /*0x1410c27c0*/
          v22 = v17->userMemory.socket._Rep; /*0x1410c27c5*/
          socket._Rep = v22; /*0x1410c27c9*/
        }
        else
        {
LABEL_22:
          Ptr = socket._Ptr; /*0x1410c275e*/
          v22 = socket._Rep; /*0x1410c2763*/
        }
        __wind /*0xf1c0000000000010*/
        {
          if ( Ptr != nullptr ) /*0x1410c276b*/
          {
            v23 = RakNet::SocketLayer::SendToAfterDelay(s: Ptr->s, delayTx: &v17->userMemory); /*0x1410c2773*/
            if ( v23 != 0 ) /*0x1410c277a*/
            {
              reliabilityLayer = v17->userMemory.reliabilityLayer; /*0x1410c27d0*/
              if ( reliabilityLayer != nullptr ) /*0x1410c27da*/
                RakNet::ReliabilityLayer::HandleSendFailure(this: reliabilityLayer, sendResult: v23); /*0x1410c27de*/
            }
            else
            {
              v31 = timeUS - v17->userMemory.timeToSend; /*0x1410c2786*/
              p_txQueueMaxDelay = &v31; /*0x1410c2792*/
              if ( this->artificialLatencyStats.txQueueMaxDelay >= v31 ) /*0x1410c279a*/
                p_txQueueMaxDelay = &this->artificialLatencyStats.txQueueMaxDelay; /*0x1410c279a*/
              this->artificialLatencyStats.txQueueMaxDelay = *p_txQueueMaxDelay; /*0x1410c27a1*/
              this->artificialLatencyStats.txQueueExcessDelay += timeUS - v17->userMemory.timeToSend; /*0x1410c27ae*/
              ++this->artificialLatencyStats.txDelayedPackets; /*0x1410c27b5*/
            }
          }
          if ( v22 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410c27f4*/
          {
            socket._Rep->_Destroy(this: socket._Rep); /*0x1410c2801*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&socket._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c280e*/
              socket._Rep->_Delete_this(this: socket._Rep); /*0x1410c2818*/
          }
          v26 = (volatile signed __int32 *)v17->userMemory.socket._Rep; /*0x1410c281b*/
          if ( v26 != nullptr && _InterlockedExchangeAdd(v26 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c282f*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v26 + 8LL))(a1: v26); /*0x1410c2834*/
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&socket); /*0xf1c0000000000008*/
        }
        rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayTransmitPackets.memoryPoolMutex.criticalSection); /*0x1410c283e*/
        DataStructures::MemoryPool<RakNet::DelayTransmitStruct>::Release( /*0x1410c285a*/
          this: &this->artificialDelayTransmitPackets.memoryPool,
          m: v17,
          file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
          line: 0x14E4u);
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayTransmitPackets.memoryPoolMutex.criticalSection); /*0x1410c2866*/
      }
    }
  }
  v27 = this->artificialDelayTransmitPackets.queue.head; /*0x1410c2870*/
  if ( v27 != this->artificialDelayTransmitPackets.queue.tail ) /*0x1410c287c*/
    v9 = this->artificialDelayTransmitPackets.queue.array[v27]->timeToSend; /*0x1410c288b*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_queueMutex->criticalSection); /*0x1410c2895*/
  return v9; /*0x1410c289d*/
}

// Address: 0x1410c28c0 | Name: ?ProcessBannedPacket@RakPeer@RakNet@@CA_NAEBUSystemAddress@2@0PEAV12@V?$shared_ptr@URakNetSocket@RakNet@@@std@@_K@Z
bool __fastcall RakNet::RakPeer::ProcessBannedPacket(
        const RakNet::SystemAddress *systemAddress,
        const RakNet::SystemAddress *udmuxAddress,
        RakNet::RakPeer *rakPeer,
        std::shared_ptr<RBX::File> *rakNetSocket,
        unsigned __int64 timeUS)
{
  char v9; // di
  bool v10; // r15
  volatile signed __int32 *v11; // rdi
  std::shared_ptr<RBX::Network::Rupp::Rupp> *v12; // rax
  std::_Ref_count_base *Rep; // rdi
  RakNet::RakPeer_vtbl *v14; // rax
  unsigned __int8 *v15; // rdi
  unsigned __int8 *v16; // rdx
  unsigned __int8 *data; // rdx
  unsigned int v18; // r8d
  std::_Ref_count_base *v19; // rcx
  std::_Ref_count_base *v20; // rdi
  bool result; // al
  std::_Ref_count_base *v22; // rdi
  std::shared_ptr<RakNet::RakNetSocket> v23; // [rsp+60h] [rbp-A0h] BYREF
  unsigned __int8 inOutByteArray[8]; // [rsp+70h] [rbp-90h] BYREF
  _BYTE v25[8]; // [rsp+78h] [rbp-88h] BYREF
  volatile signed __int32 *v26; // [rsp+80h] [rbp-80h]
  std::shared_ptr<RBX::File> v27; // [rsp+88h] [rbp-78h] BYREF
  RakNet::SystemAddress v28; // [rsp+A0h] [rbp-60h] BYREF
  RakNet::BitStream bs; // [rsp+C0h] [rbp-40h] BYREF
  int inByteArray; // [rsp+240h] [rbp+140h] BYREF
  std::shared_ptr<RBX::File> *v31; // [rsp+248h] [rbp+148h]

  v31 = rakNetSocket; /*0x1410c28c5*/
  v9 = 0; /*0x1410c28f0*/
  inByteArray = 0; /*0x1410c28f2*/
  __wind /*0xf1c0000000000040*/
  {
    if ( ((unsigned __int8 (*)(void))rakPeer->IsBanned)() != 0 ) /*0x1410c2909*/
    {
      RakNet::BitStream::BitStream(this: &bs); /*0x1410c2913*/
      __wind /*0xf1c0000000000034*/
      {
        v10 = false; /*0x1410c293e*/
        if ( DFFlag::RuppHeaderFromClientEnabled3.value ) /*0x1410c2920*/
        {
          v9 = 1; /*0x1410c2933*/
          if ( rakPeer->getRuppHeader(this: rakPeer, result: v25)->_Ptr != nullptr ) /*0x1410c293c*/
            v10 = true; /*0x1410c2920*/
        }
        if ( (v9 & 1) != 0 ) /*0x1410c2950*/
        {
          v11 = v26; /*0x1410c2952*/
          if ( v26 != nullptr && _InterlockedExchangeAdd(v26 + 2, 0xFFFFFFFF) == 1 ) /*0x1410c2965*/
          {
            (**(void (__fastcall ***)(volatile signed __int32 *))v11)(a1: v11); /*0x1410c296d*/
            if ( _InterlockedExchangeAdd(v11 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c2979*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 8LL))(a1: v11); /*0x1410c2981*/
          }
        }
        if ( v10 ) /*0x1410c2987*/
        {
          v12 = rakPeer->getRuppHeader(this: rakPeer, result: &v27); /*0x1410c2993*/
          __wind /*0xf1c0000000000028*/
          {
            RBX::Network::Rupp::Rupp::serialize(this: v12->_Ptr, b: &bs); /*0x1410c29a1*/
          }
          __unwind
          {
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v27); /*0xf1c0000000000020*/
          }
          Rep = v27._Rep; /*0x1410c29a7*/
          if ( v27._Rep != nullptr /*0x1410c29ba*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&v27._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            Rep->_Destroy(this: Rep); /*0x1410c29c2*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c29ce*/
              Rep->_Delete_this(this: Rep); /*0x1410c29d6*/
          }
        }
        LOBYTE(inByteArray) = 23; /*0x1410c29d9*/
        RakNet::BitStream::WriteBits( /*0x1410c29f4*/
          this: &bs,
          (unsigned __int8 *)&inByteArray,
          numberOfBitsToWrite: 8u,
          rightAlignedBits: true);
        RakNet::BitStream::WriteAlignedBytes( /*0x1410c2a0a*/
          this: &bs,
          inByteArray: OFFLINE_MESSAGE_DATA_ID,
          numberOfBytesToWrite: 0x10u);
        v14 = rakPeer->__vftable; /*0x1410c2a0f*/
        v28 = RakNet::UNASSIGNED_SYSTEM_ADDRESS_30; /*0x1410c2a19*/
        v15 = (unsigned __int8 *)v14->GetGuidFromSystemAddress(this: rakPeer, a2: &v28); /*0x1410c2a35*/
        if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c2a38*/
        {
          v16 = v15; /*0x1410c2a5b*/
        }
        else
        {
          RBX::Network::NetworkStream::ReverseBytes(inByteArray: v15, inOutByteArray, length: 8u); /*0x1410c2a4f*/
          v16 = inOutByteArray; /*0x1410c2a54*/
        }
        RakNet::BitStream::WriteBits(this: &bs, inByteArray: v16, numberOfBitsToWrite: 0x40u, rightAlignedBits: true); /*0x1410c2a6b*/
        data = bs.data; /*0x1410c2a74*/
        v18 = (bs.numberOfBitsUsed + 7) >> 3; /*0x1410c2a7c*/
        if ( FFlag::CLI52064Experiment2.value ) /*0x1410c2a87*/
        {
          v23 = 0; /*0x1410c2a8c*/
          v19 = rakNetSocket->_Rep; /*0x1410c2a92*/
          if ( v19 != nullptr ) /*0x1410c2a99*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&v19->_Uses); /*0x1410c2a9b*/
            v19 = rakNetSocket->_Rep; /*0x1410c2a9f*/
          }
          v23._Ptr = (RakNet::RakNetSocket *)rakNetSocket->_Ptr; /*0x1410c2aa6*/
          v23._Rep = v19; /*0x1410c2aab*/
          RakNet::SocketLayer::SendToOrDelay( /*0x1410c2af0*/
            socket: &v23,
            (const char *)data,
            length: v18,
            dstAddress: systemAddress,
            srcAddress: udmuxAddress,
            raknetMetaDataEncrypted: false,
            rakPeer,
            reliabilityLayer: nullptr,
            now: timeUS,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
            line: 4825);
        }
        else
        {
          RakNet::SocketLayer::SendTo( /*0x1410c2b1e*/
            s: (unsigned __int64)rakNetSocket->_Ptr->__vftable,
            data: (const char *)bs.data,
            length: v18,
            dstAddress: systemAddress,
            srcAddress: udmuxAddress,
            raknetMetaDataEncrypted: false,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
            line: 4829);
        }
      }
      __unwind
      {
        RakNet::BitStream::~BitStream(this: &bs); /*0xf1c0000000000014*/
      }
      RakNet::BitStream::~BitStream(this: &bs); /*0x1410c2b28*/
      v20 = rakNetSocket->_Rep; /*0x1410c2b2e*/
      if ( v20 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410c2b41*/
      {
        v20->_Destroy(this: v20); /*0x1410c2b49*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c2b53*/
          v20->_Delete_this(this: v20); /*0x1410c2b5b*/
      }
      result = true; /*0x1410c2b5e*/
    }
    else
    {
      v22 = rakNetSocket->_Rep; /*0x1410c2b62*/
      if ( v22 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410c2b7a*/
      {
        v22->_Destroy(this: v22); /*0x1410c2b82*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c2b8c*/
          v22->_Delete_this(this: v22); /*0x1410c2b94*/
      }
      result = false; /*0x1410c2b97*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v31); /*0xf1c0000000000008*/
  }
  return result; /*0x1410c2b99*/
}

// Address: 0x1410c2bc0 | Name: ?ProcessBufferedCommands@RakPeer@RakNet@@IEAAXAEA_K0@Z
void __fastcall RakNet::RakPeer::ProcessBufferedCommands(
        RakNet::RakPeer *this,
        unsigned __int64 *timeUS,
        unsigned __int64 *timeMS)
{
  unsigned __int64 *v3; // rsi
  unsigned __int64 *v4; // r15
  unsigned __int8 *v6; // r13
  boost::mutex *p_bufferedCommandsMutex; // rdi
  signed __int32 v8; // eax
  HANDLE event; // rax
  int itemCount; // edx
  int *p_minCommandsPerCycle; // rax
  int *p_maxCommandsPerCycle; // rcx
  int *v13; // rax
  bool v14; // cc
  unsigned int head; // ecx
  unsigned int tail; // edi
  int v17; // edi
  int *v18; // rax
  unsigned int v19; // eax
  unsigned int v20; // eax
  unsigned int allocation_size; // ecx
  RakNet::RakPeer::BufferedCommandStruct **array; // r13
  __int64 v23; // rax
  int v24; // eax
  __int64 v25; // rdi
  unsigned __int8 v26; // si
  unsigned int v27; // r14d
  unsigned __int64 v28; // r15
  unsigned __int8 v29; // r12
  bool v30; // al
  unsigned int v31; // edi
  bool i; // cf
  __int64 v33; // rsi
  RakNet::RakPeer::RemoteSystemStruct *v34; // rcx
  unsigned int v35; // eax
  __int64 v36; // rdx
  RakNet::RakPeer::RemoteSystemStruct *RemoteSystem; // rax
  unsigned int RemoteSystemIndex; // eax
  RakNet::RakPeer::SocketQueryOutput *v39; // rdi
  RakNet::RakPeer::SocketQueryOutput *v40; // rdx
  DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput> *p_socketQueryOutput; // rcx
  DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput> *v42; // r14
  RakNet::RakPeer::RemoteSystemStruct *v43; // r12
  RakNet::RakPeer::SocketQueryOutput *v44; // rax
  RakNet::RakPeer::SocketQueryOutput *v45; // rsi
  std::shared_ptr<RakNet::RakNetSocket> *listArray; // rcx
  std::_Ref_count_base **p_Rep; // rdi
  __int64 v48; // rcx
  unsigned int list_size; // eax
  _QWORD *v50; // rax
  std::shared_ptr<RakNet::RakNetSocket> *v51; // r15
  std::shared_ptr<RakNet::RakNetSocket> *v52; // rcx
  unsigned int v53; // r14d
  __int64 v54; // rcx
  std::shared_ptr<RakNet::RakNetSocket> *v55; // rax
  std::shared_ptr<RakNet::RakNetSocket> *v56; // rdx
  std::_Ref_count_base *Rep; // rcx
  volatile signed __int32 *v58; // rdi
  char *v59; // rdi
  unsigned __int64 read; // r8
  unsigned __int64 itemCapacity; // r9
  unsigned __int8 *v62; // rcx
  volatile signed __int32 *v63; // rdi
  volatile signed __int32 *v64; // rdi
  __int64 v65; // [rsp+0h] [rbp-100h] BYREF
  _DWORD v66[4]; // [rsp+60h] [rbp-A0h] BYREF
  RakNet::RakNetGUID lhs; // [rsp+70h] [rbp-90h] BYREF
  RakNet::RakNetGUID v68; // [rsp+80h] [rbp-80h] BYREF
  RakNet::SystemAddress v69; // [rsp+90h] [rbp-70h] BYREF
  RakNet::SystemAddress sa; // [rsp+B0h] [rbp-50h] BYREF
  RakNet::AddressOrGUID v71; // [rsp+D0h] [rbp-30h] BYREF
  RakNet::RakNetGUID v72; // [rsp+100h] [rbp+0h] BYREF
  RakNet::SystemAddress v73; // [rsp+110h] [rbp+10h] BYREF
  RakNet::RakNetGUID v74; // [rsp+130h] [rbp+30h] BYREF
  RakNet::SystemAddress v75; // [rsp+140h] [rbp+40h] BYREF
  int v78; // [rsp+1B8h] [rbp+B8h] BYREF

  v3 = timeMS; /*0x1410c2be6*/
  v4 = timeUS; /*0x1410c2be9*/
  v6 = nullptr; /*0x1410c2bf2*/
  if ( FFlag::BufferedCommandsCircular.value ) /*0x1410c2bfc*/
  {
    p_bufferedCommandsMutex = &this->bufferedCommandsMutex; /*0x1410c2bfe*/
    boost::detail::basic_timed_mutex::lock(this: &this->bufferedCommandsMutex); /*0x1410c2c08*/
    std::swap<RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>,0>( /*0x1410c2c1b*/
      _Left: &this->bufferedCommandsCircular,
      _Right: &this->bufferedCommandsCircularSwap);
    v8 = _InterlockedExchangeAdd(&p_bufferedCommandsMutex->active_count, 0x80000000); /*0x1410c2c25*/
    if ( (v8 & 0x40000000) == 0 /*0x1410c2c3b*/
      && v8 != 0x80000000
      && !_interlockedbittestandset(&p_bufferedCommandsMutex->active_count, 0x1Eu) )
    {
      event = boost::detail::basic_timed_mutex::get_event(this: p_bufferedCommandsMutex); /*0x1410c2c40*/
      SetEvent(hEvent: event); /*0x1410c2c48*/
    }
  }
  if ( DFFlag::ReportNumCommandsPerCycle.value ) /*0x1410c2c55*/
  {
    if ( FFlag::BufferedCommandsCircular.value ) /*0x1410c2c62*/
    {
      itemCount = this->bufferedCommandsCircularSwap.itemCount; /*0x1410c2c64*/
      v78 = itemCount; /*0x1410c2c6a*/
      this->bcStats.totalCommandsPerCycle += itemCount; /*0x1410c2c70*/
      ++this->bcStats.numCommandCyclesSampled; /*0x1410c2c76*/
      p_minCommandsPerCycle = &v78; /*0x1410c2c83*/
      if ( itemCount >= this->bcStats.minCommandsPerCycle ) /*0x1410c2c8c*/
        p_minCommandsPerCycle = &this->bcStats.minCommandsPerCycle; /*0x1410c2c8c*/
      this->bcStats.minCommandsPerCycle = *p_minCommandsPerCycle; /*0x1410c2c92*/
      p_maxCommandsPerCycle = &this->bcStats.maxCommandsPerCycle; /*0x1410c2c94*/
      v13 = &v78; /*0x1410c2c9b*/
      v14 = this->bcStats.maxCommandsPerCycle < itemCount; /*0x1410c2ca2*/
    }
    else
    {
      rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedCommands_deprecated.queueMutex.criticalSection); /*0x1410c2cad*/
      head = this->bufferedCommands_deprecated.queue.head; /*0x1410c2cb2*/
      tail = this->bufferedCommands_deprecated.queue.tail; /*0x1410c2cb8*/
      if ( head > tail ) /*0x1410c2cc0*/
        v17 = this->bufferedCommands_deprecated.queue.allocation_size - head + tail; /*0x1410c2cce*/
      else
        v17 = tail - head; /*0x1410c2cc2*/
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedCommands_deprecated.queueMutex.criticalSection); /*0x1410c2cd7*/
      v66[0] = v17; /*0x1410c2cdc*/
      this->bcStats.totalCommandsPerCycle += v17; /*0x1410c2ce0*/
      ++this->bcStats.numCommandCyclesSampled; /*0x1410c2ce6*/
      v18 = v66; /*0x1410c2cf3*/
      if ( v17 >= this->bcStats.minCommandsPerCycle ) /*0x1410c2cfa*/
        v18 = &this->bcStats.minCommandsPerCycle; /*0x1410c2cfa*/
      this->bcStats.minCommandsPerCycle = *v18; /*0x1410c2d00*/
      p_maxCommandsPerCycle = &this->bcStats.maxCommandsPerCycle; /*0x1410c2d02*/
      v13 = v66; /*0x1410c2d09*/
      v14 = this->bcStats.maxCommandsPerCycle < v17; /*0x1410c2d0e*/
      v3 = timeMS; /*0x1410c2d10*/
    }
    if ( !v14 ) /*0x1410c2d17*/
      v13 = p_maxCommandsPerCycle; /*0x1410c2d17*/
    *p_maxCommandsPerCycle = *v13; /*0x1410c2d1d*/
  }
  while ( 1 ) /*0x1410c2d20*/
  {
    if ( FFlag::BufferedCommandsCircular.value ) /*0x1410c2d27*/
    {
      if ( this->bufferedCommandsCircularSwap.itemCount == 0 ) /*0x1410c2d31*/
        return; /*0x1410c2d31*/
      goto LABEL_30; /*0x1410c2d31*/
    }
    rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedCommands_deprecated.queueMutex.criticalSection); /*0x1410c2d40*/
    v19 = this->bufferedCommands_deprecated.queue.head; /*0x1410c2d45*/
    if ( v19 == this->bufferedCommands_deprecated.queue.tail ) /*0x1410c2d51*/
      break; /*0x1410c2d51*/
    v20 = v19 + 1; /*0x1410c2d57*/
    this->bufferedCommands_deprecated.queue.head = v20; /*0x1410c2d59*/
    allocation_size = this->bufferedCommands_deprecated.queue.allocation_size; /*0x1410c2d5f*/
    if ( v20 == allocation_size ) /*0x1410c2d67*/
    {
      this->bufferedCommands_deprecated.queue.head = 0; /*0x1410c2d69*/
      array = this->bufferedCommands_deprecated.queue.array; /*0x1410c2d70*/
      v23 = allocation_size - 1; /*0x1410c2d77*/
    }
    else
    {
      array = this->bufferedCommands_deprecated.queue.array; /*0x1410c2d7c*/
      if ( v20 != 0 ) /*0x1410c2d85*/
        v23 = v20 - 1; /*0x1410c2d8c*/
      else
        v23 = allocation_size - 1; /*0x1410c2d87*/
    }
    v6 = (unsigned __int8 *)array[v23]; /*0x1410c2d8e*/
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedCommands_deprecated.queueMutex.criticalSection); /*0x1410c2d9a*/
    if ( v6 == nullptr ) /*0x1410c2da2*/
      return; /*0x1410c2da2*/
LABEL_30:
    if ( FFlag::BufferedCommandsCircular.value ) /*0x1410c2daf*/
      v6 = &this->bufferedCommandsCircularSwap.buffer[160 /*0x1410c2dc9*/
                                                    * (this->bufferedCommandsCircularSwap.read
                                                     % this->bufferedCommandsCircularSwap.itemCapacity)];
    v24 = *((_DWORD *)v6 + 38); /*0x1410c2dd0*/
    if ( v24 != 0 ) /*0x1410c2dd9*/
    {
      switch ( v24 ) /*0x1410c2fe3*/
      {
        case 1: /*0x1410c2fe3*/
          if ( FLog::Network != 0 ) /*0x1410c2fee*/
            FLog::FastLog(level: FLog::Network, message: "[FLog::Network] Closing connection internally", arg0: nullptr); /*0x1410c2ffa*/
          RakNet::RakPeer::CloseConnectionInternal( /*0x1410c301d*/
            this,
            systemIdentifier: (const RakNet::AddressOrGUID *)(v6 + 32),
            sendDisconnectionNotification: false,
            performImmediate: true,
            orderingChannel: v6[28],
            disconnectionNotificationPriority: *((PacketPriority *)v6 + 5));
          break;
        case 3: /*0x1410c2fe3*/
          RakNet::RakNetGUID::RakNetGUID(this: &v72); /*0x1410c3030*/
          RakNet::SystemAddress::SystemAddress(this: &v73); /*0x1410c3039*/
          v72 = *((RakNet::RakNetGUID *)v6 + 2); /*0x1410c3042*/
          RakNet::SystemAddress::operator=(this: &v73, input: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30); /*0x1410c305a*/
          RemoteSystem = RakNet::RakPeer::GetRemoteSystem( /*0x1410c306d*/
                           this,
                           systemIdentifier: (RBX::json::ArrayIterator *)&v72,
                           calledFromNetworkThread: true,
                           onlyActive: true);
          if ( RemoteSystem != nullptr ) /*0x1410c3075*/
          {
            RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, sa: &RemoteSystem->systemAddress); /*0x1410c3082*/
            RakNet::RakPeer::ReferenceRemoteSystem( /*0x1410c3091*/
              this,
              sa: (const RakNet::SystemAddress *)(v6 + 48),
              remoteSystemListIndex: RemoteSystemIndex);
          }
          break;
        case 2: /*0x1410c2fe3*/
          if ( StudioResourceId::operator==(lhs: v6 + 32, rhs: &RakNet::UNASSIGNED_RAKNET_GUID_30) /*0x1410c30ca*/
            && RakNet::SystemAddress::operator==(
                 this: (RakNet::SystemAddress *)(v6 + 48),
                 right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 )
          {
            v39 = DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Allocate( /*0x1410c30e5*/
                    this: &this->socketQueryOutput,
                    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                    line: 0x15CEu);
            DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::operator=( /*0x1410c30f2*/
              this: &v39->sockets,
              original_copy: &this->socketList);
            v40 = v39; /*0x1410c30f7*/
            p_socketQueryOutput = &this->socketQueryOutput; /*0x1410c30fa*/
          }
          else
          {
            v42 = &this->socketQueryOutput; /*0x1410c3106*/
            RakNet::RakNetGUID::RakNetGUID(this: &v74); /*0x1410c3111*/
            RakNet::SystemAddress::SystemAddress(this: &v75); /*0x1410c311a*/
            v74 = *((RakNet::RakNetGUID *)v6 + 2); /*0x1410c3123*/
            RakNet::SystemAddress::operator=(this: &v75, input: (const RakNet::SystemAddress *)(v6 + 48)); /*0x1410c3138*/
            v43 = RakNet::RakPeer::GetRemoteSystem( /*0x1410c3150*/
                    this,
                    systemIdentifier: (RBX::json::ArrayIterator *)&v74,
                    calledFromNetworkThread: true,
                    onlyActive: true);
            v44 = DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Allocate( /*0x1410c3163*/
                    this: &this->socketQueryOutput,
                    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                    line: 0x15D5u);
            v45 = v44; /*0x1410c3168*/
            if ( v44->sockets.allocation_size != 0 ) /*0x1410c316f*/
            {
              listArray = v44->sockets.listArray; /*0x1410c3171*/
              if ( v44->sockets.listArray != nullptr ) /*0x1410c3177*/
              {
                __eh34_enter_wind_state(-1, 0); /*0xf1c000000000003c*/
                p_Rep = &listArray[-1]._Rep; /*0x1410c3179*/
                `eh vector destructor iterator'( /*0x1410c318c*/
                  ptr: listArray,
                  size: 0x10u,
                  count: (unsigned __int64)listArray[-1]._Rep,
                  destructor: (void (__fastcall *)(void *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>);
                operator delete(ptr: p_Rep); /*0x1410c319f*/
                if ( __eh34_unwind(0) ) /*0xf1c0000000000030*/
unwind_state_0:
                  __std_terminate(a1: v48, a2: &v65); /*0xf1c0000000000018*/
                __eh34_exit_wind_state(0, -1); /*0xf1c0000000000034*/
              }
              *(_QWORD *)&v45->sockets.list_size = 0; /*0x1410c31a7*/
              v45->sockets.listArray = nullptr; /*0x1410c31ab*/
            }
            if ( v43 != nullptr ) /*0x1410c31b5*/
            {
              list_size = v45->sockets.list_size; /*0x1410c31bb*/
              if ( list_size != 0 ) /*0x1410c31c0*/
              {
                v51 = v45->sockets.listArray; /*0x1410c32e0*/
              }
              else
              {
                v45->sockets.allocation_size = 16; /*0x1410c31c6*/
                v50 = operator new(size: 0x108u); /*0x1410c31d2*/
                if ( v50 != nullptr ) /*0x1410c31da*/
                {
                  *v50 = 16; /*0x1410c31dc*/
                  v51 = (std::shared_ptr<RakNet::RakNetSocket> *)(v50 + 1); /*0x1410c31e3*/
                  `eh vector constructor iterator'( /*0x1410c3205*/
                    ptr: v50 + 1,
                    size: 0x10u,
                    count: 0x10u,
                    constructor: (void (__fastcall *)(void *))std::weak_ptr<RBX::BasePart>::weak_ptr<RBX::BasePart>,
                    destructor: (void (__fastcall *)(void *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>);
                }
                else
                {
                  v51 = nullptr; /*0x1410c320c*/
                }
                v52 = v45->sockets.listArray; /*0x1410c320f*/
                if ( v45->sockets.listArray != nullptr ) /*0x1410c3215*/
                {
                  v53 = 0; /*0x1410c321b*/
                  if ( v45->sockets.list_size != 0 ) /*0x1410c3222*/
                  {
                    do /*0x1410c329b*/
                    {
                      v54 = v53; /*0x1410c3233*/
                      v55 = &v45->sockets.listArray[v54]; /*0x1410c323a*/
                      v56 = &v51[v54]; /*0x1410c323d*/
                      Rep = v55->_Rep; /*0x1410c3241*/
                      if ( Rep != nullptr ) /*0x1410c3248*/
                      {
                        _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410c324a*/
                        Rep = v55->_Rep; /*0x1410c324e*/
                      }
                      v56->_Ptr = v55->_Ptr; /*0x1410c3255*/
                      v58 = (volatile signed __int32 *)v56->_Rep; /*0x1410c3258*/
                      v56->_Rep = Rep; /*0x1410c325c*/
                      if ( v58 != nullptr && _InterlockedExchangeAdd(v58 + 2, 0xFFFFFFFF) == 1 ) /*0x1410c3272*/
                      {
                        (**(void (__fastcall ***)(volatile signed __int32 *))v58)(a1: v58); /*0x1410c327a*/
                        if ( _InterlockedExchangeAdd(v58 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c3289*/
                          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v58 + 8LL))(a1: v58); /*0x1410c3291*/
                      }
                      ++v53; /*0x1410c3294*/
                    }
                    while ( v53 < v45->sockets.list_size ); /*0x1410c329b*/
                    v52 = v45->sockets.listArray; /*0x1410c329d*/
                  }
                  if ( v52 != nullptr ) /*0x1410c32a3*/
                  {
                    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000028*/
                    v59 = (char *)&v52[-1]._Rep; /*0x1410c32a5*/
                    `eh vector destructor iterator'( /*0x1410c32b8*/
                      ptr: v52,
                      size: 0x10u,
                      count: (unsigned __int64)v52[-1]._Rep,
                      destructor: (void (__fastcall *)(void *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>);
                    operator delete(ptr: v59); /*0x1410c32cb*/
                    if ( __eh34_unwind(0) ) /*0xf1c0000000000014*/
                      goto unwind_state_0; /*0xf1c0000000000014*/
                    __eh34_exit_wind_state(0, -1); /*0xf1c0000000000020*/
                  }
                  v42 = &this->socketQueryOutput; /*0x1410c32d1*/
                }
                v45->sockets.listArray = v51; /*0x1410c32d8*/
                list_size = v45->sockets.list_size; /*0x1410c32db*/
              }
              std::shared_ptr<RBX::GfxGui>::operator=( /*0x1410c32f4*/
                this: (std::shared_ptr<RobloxDiagnosticsView::ItemData> *)&v51[list_size],
                _Right: (const std::shared_ptr<RobloxDiagnosticsView::ItemData> *)&v43->rakNetSocket);
              ++v45->sockets.list_size; /*0x1410c32f9*/
            }
            v40 = v45; /*0x1410c32fc*/
            p_socketQueryOutput = v42; /*0x1410c32ff*/
          }
          DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::BufferedCommandStruct>::Push( /*0x1410c3302*/
            this: p_socketQueryOutput,
            s: v40);
          break;
        default:
          break; /*0x1410c2fe3*/
      }
    }
    else
    {
      this->bcsQueueTime = *(_DWORD *)v3 - *((_DWORD *)v6 + 36); /*0x1410c2de8*/
      v25 = *(_QWORD *)v6; /*0x1410c2deb*/
      v26 = v6[136]; /*0x1410c2def*/
      v27 = *((_DWORD *)v6 + 33); /*0x1410c2df7*/
      v28 = *v4; /*0x1410c2dfe*/
      v29 = v6[80]; /*0x1410c2e01*/
      RakNet::RakNetGUID::RakNetGUID(this: &v71.rakNetGuid); /*0x1410c2e0a*/
      RakNet::SystemAddress::SystemAddress(this: &v71.systemAddress); /*0x1410c2e13*/
      v71.rakNetGuid.g = *((_QWORD *)v6 + 4); /*0x1410c2e1c*/
      v71.rakNetGuid.systemIndex = *((_WORD *)v6 + 20); /*0x1410c2e25*/
      RakNet::SystemAddress::operator=(this: &v71.systemAddress, input: (const RakNet::SystemAddress *)(v6 + 48)); /*0x1410c2e31*/
      v30 = RakNet::RakPeer::SendImmediate( /*0x1410c2e7d*/
              this,
              data: *((char **)v6 + 13),
              numberOfBitsToSend: *((_DWORD *)v6 + 4),
              priority: *((PacketPriority *)v6 + 5),
              reliability: *((PacketReliability *)v6 + 6),
              orderingChannel: v6[28],
              systemIdentifier: &v71,
              broadcast: v29,
              useCallerDataAllocation: v25 == 0,
              currentTime: v28,
              receipt: v27,
              isJoinData: v26);
      if ( *(_QWORD *)v6 == 0 && !v30 ) /*0x1410c2e8b*/
        operator delete(ptr: *((void **)v6 + 13)); /*0x1410c2e91*/
      if ( *((_DWORD *)v6 + 21) != 0 ) /*0x1410c2e9b*/
      {
        RakNet::RakNetGUID::RakNetGUID(this: &v68); /*0x1410c2ea5*/
        RakNet::SystemAddress::SystemAddress(this: &v69); /*0x1410c2eae*/
        v68 = *((RakNet::RakNetGUID *)v6 + 2); /*0x1410c2eb7*/
        RakNet::SystemAddress::operator=(this: &v69, input: (const RakNet::SystemAddress *)(v6 + 48)); /*0x1410c2ecc*/
        if ( StudioResourceId::operator!=( /*0x1410c2edc*/
               this: (RBX::json::ArrayIterator *)&v68,
               rhs: (const RBX::json::ArrayIterator *)&RakNet::UNASSIGNED_RAKNET_GUID_30) )
        {
          lhs = v68; /*0x1410c2eed*/
          if ( !StudioResourceId::operator==(&lhs, rhs: &RakNet::UNASSIGNED_RAKNET_GUID_30) ) /*0x1410c2efe*/
          {
            v31 = 0; /*0x1410c2f0e*/
            for ( i = this->maximumNumberOfPeers != 0; i; i = v31 < this->maximumNumberOfPeers ) /*0x1410c2f11*/
            {
              v33 = v31; /*0x1410c2f1a*/
              if ( StudioResourceId::operator==(lhs: &this->remoteSystemList[v33].guid, rhs: &lhs) /*0x1410c2f47*/
                && this->remoteSystemList[v33].isActive._Storage._Value )
              {
                v34 = &this->remoteSystemList[v33]; /*0x1410c2f61*/
                goto LABEL_51; /*0x1410c2f64*/
              }
              ++v31; /*0x1410c2f50*/
            }
            v34 = nullptr; /*0x1410c2f66*/
            goto LABEL_51; /*0x1410c2f69*/
          }
LABEL_50:
          v34 = nullptr; /*0x1410c2fc6*/
        }
        else
        {
          sa = v69; /*0x1410c2f6f*/
          if ( RakNet::SystemAddress::operator==(this: &sa, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410c2f8d*/
            goto LABEL_50; /*0x1410c2f8d*/
          v35 = RakNet::RakPeer::GetRemoteSystemIndex(this, &sa); /*0x1410c2f96*/
          if ( v35 == -1 ) /*0x1410c2f9e*/
            goto LABEL_50; /*0x1410c2f9e*/
          v36 = v35; /*0x1410c2fa2*/
          if ( !this->remoteSystemList[v36].isActive._Storage._Value ) /*0x1410c2fb8*/
            goto LABEL_50; /*0x1410c2fb8*/
          v34 = &this->remoteSystemList[v36]; /*0x1410c2fc1*/
        }
LABEL_51:
        if ( v34 != nullptr ) /*0x1410c2fcb*/
          v34->connectMode = *((_DWORD *)v6 + 21); /*0x1410c2fd5*/
      }
    }
    if ( FFlag::BufferedCommandsCircular.value ) /*0x1410c330e*/
    {
      read = this->bufferedCommandsCircularSwap.read; /*0x1410c3314*/
      itemCapacity = this->bufferedCommandsCircularSwap.itemCapacity; /*0x1410c331b*/
      v62 = &this->bufferedCommandsCircularSwap.buffer[160 * (read % itemCapacity)]; /*0x1410c3332*/
      this->bufferedCommandsCircularSwap.read = (read + 1) % itemCapacity; /*0x1410c3342*/
      v63 = *((volatile signed __int32 **)v62 + 1); /*0x1410c3349*/
      if ( v63 != nullptr && _InterlockedExchangeAdd(v63 + 2, 0xFFFFFFFF) == 1 ) /*0x1410c335f*/
      {
        (**(void (__fastcall ***)(volatile signed __int32 *))v63)(a1: v63); /*0x1410c3367*/
        if ( _InterlockedExchangeAdd(v63 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c3376*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v63 + 8LL))(a1: v63); /*0x1410c337e*/
      }
      --this->bufferedCommandsCircularSwap.itemCount; /*0x1410c3381*/
      v3 = timeMS; /*0x1410c3388*/
      v4 = timeUS; /*0x1410c338f*/
    }
    else
    {
      v64 = *((volatile signed __int32 **)v6 + 1); /*0x1410c339e*/
      if ( v64 != nullptr && _InterlockedExchangeAdd(v64 + 2, 0xFFFFFFFF) == 1 ) /*0x1410c33b4*/
      {
        (**(void (__fastcall ***)(volatile signed __int32 *))v64)(a1: v64); /*0x1410c33bc*/
        if ( _InterlockedExchangeAdd(v64 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c33cb*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v64 + 8LL))(a1: v64); /*0x1410c33d3*/
      }
      rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedCommands_deprecated.memoryPoolMutex.criticalSection); /*0x1410c33dd*/
      DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::Release( /*0x1410c33f9*/
        this: &this->bufferedCommands_deprecated.memoryPool,
        m: (DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::MemoryWithPage *)v6,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
        line: 0x15EAu);
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedCommands_deprecated.memoryPoolMutex.criticalSection); /*0x1410c3405*/
      v3 = timeMS; /*0x1410c340a*/
      v4 = timeUS; /*0x1410c3411*/
    }
  }
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedCommands_deprecated.queueMutex.criticalSection); /*0x1410c3427*/
}

// Address: 0x1410c3450 | Name: ?ProcessBufferedPackets@RakPeer@RakNet@@IEAA_KAEAVBitStream@2@_K@Z
unsigned __int64 __fastcall RakNet::RakPeer::ProcessBufferedPackets(
        RakNet::RakPeer *this,
        RakNet::BitStream *updateBitStream,
        unsigned __int64 timeUS)
{
  unsigned __int64 v3; // r15
  bool v5; // r14
  int *v6; // rdi
  int v7; // eax
  unsigned int head; // ecx
  unsigned int tail; // edi
  unsigned int v10; // edi
  unsigned __int64 v11; // rcx
  unsigned int v12; // ecx
  unsigned int v13; // edi
  RakNet::SimpleMutex *p_queueMutex; // rdi
  RakNet::SimpleMutex *v15; // rcx
  RakNet::RakPeer::RecvFromStruct *v16; // r14
  unsigned int v17; // ecx
  unsigned int v18; // esi
  int v19; // esi
  int *p_peakRxQueueSize; // rax
  unsigned __int64 timeRead; // rsi
  unsigned int v22; // eax
  unsigned int v23; // eax
  unsigned int v24; // eax
  unsigned int v25; // ecx
  RakNet::RakPeer::RecvFromStruct **v26; // r14
  __int64 v27; // rax
  unsigned __int64 *p_rxQueueMaxDelay; // rax
  unsigned int v29; // eax
  unsigned int v30; // eax
  unsigned int v31; // eax
  unsigned int v32; // ecx
  RakNet::RakPeer::RecvFromStruct **array; // r14
  __int64 v34; // rax
  unsigned int v35; // eax
  unsigned int allocation_size; // ecx
  unsigned int v37; // edi
  unsigned int list_size; // ecx
  const void *bytesRead; // rsi
  unsigned __int16 v40; // r12
  RBX::Network::Rupp::RuppError::ErrorCode v41; // eax
  const char *v42; // rax
  int v43; // r13d
  bool v44; // si
  std::shared_ptr<RBX::File> *listArray; // rcx
  std::_Ref_count_base *Rep; // rax
  int v47; // ecx
  char *v48; // r15
  __int64 v49; // rax
  __int64 v50; // rax
  unsigned int v51; // edx
  int v52; // r8d
  int v53; // r8d
  unsigned __int64 v54; // r8
  std::shared_ptr<RakNet::RakNetSocket> *v55; // rcx
  std::_Ref_count_base *v56; // rax
  RakNet::SystemAddress *p_systemAddress; // rdi
  bool v58; // r15
  int v59; // r13d
  RakNet::RemoteSystemIndex *v60; // rdi
  __int64 index; // rax
  RakNet::RakPeer::RemoteSystemStruct *v62; // rdi
  RakNet::ReliabilityLayer *v63; // r10
  bool Value; // dl
  std::shared_ptr<RakNet::RakNetSocket> *v65; // rcx
  std::_Ref_count_base *v66; // rax
  __int64 v67; // rdx
  RakNet::RakPeer::TrackDroppedPackets::DroppedPktInfo *m_last; // rcx
  int minDropPktSize; // eax
  int maxDropPktSize; // eax
  __int64 v71; // rdi
  char *v72; // rdi
  unsigned __int64 result; // rax
  int maxPacketsPerPeerOneCycle; // esi
  int minPacketsPerPeerOneCycle; // ecx
  int arg2; // [rsp+20h] [rbp-E0h]
  const RakNet::SystemAddress *p_myExternalSystemAddress; // [rsp+50h] [rbp-B0h]
  unsigned __int16 ruppHeaderLength[2]; // [rsp+60h] [rbp-A0h] BYREF
  int v79; // [rsp+64h] [rbp-9Ch]
  int v80; // [rsp+68h] [rbp-98h]
  unsigned __int64 v81; // [rsp+70h] [rbp-90h]
  int v82; // [rsp+78h] [rbp-88h] BYREF
  unsigned __int64 v83; // [rsp+80h] [rbp-80h]
  std::shared_ptr<RakNet::RakNetSocket> v84; // [rsp+88h] [rbp-78h] BYREF
  std::shared_ptr<RBX::File> v85; // [rsp+98h] [rbp-68h] BYREF
  std::shared_ptr<RakNet::RakNetSocket> v86; // [rsp+A8h] [rbp-58h] BYREF
  RBX::Network::Rupp::Rupp::RuppInfo ruppInfoObject; // [rsp+B8h] [rbp-48h] BYREF
  unsigned __int64 v88; // [rsp+D0h] [rbp-30h] BYREF
  RBX::StringView tokenInBitstream; // [rsp+E0h] [rbp-20h]
  RakNet::SystemAddress sa; // [rsp+F0h] [rbp-10h] BYREF
  RBX::StringView v91; // [rsp+110h] [rbp+10h] BYREF
  RakNet::SystemAddress firstReceivedDataPacketAddress; // [rsp+120h] [rbp+20h] BYREF
  RakNet::SystemAddress dstAddress; // [rsp+140h] [rbp+40h] BYREF
  RakNet::SystemAddress v94; // [rsp+160h] [rbp+60h] BYREF
  RakNet::BitStream b; // [rsp+180h] [rbp+80h] BYREF
  bool v98; // [rsp+318h] [rbp+218h]

  v3 = timeUS; /*0x1410c3475*/
  v5 = (__int64)this->GetArtificialLatencyRx(this) != 0; /*0x1410c3487*/
  v98 = v5; /*0x1410c348b*/
  v6 = (int *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL); /*0x1410c34aa*/
  if ( _TSS0_537 > *v6 ) /*0x1410c34b5*/
  {
    Init_thread_header(pOnce: &_TSS0_537); /*0x1410c34be*/
    if ( _TSS0_537 == -1 ) /*0x1410c34ca*/
    {
      __wind /*0xf1c0000000000074*/
      {
        proflabeltoken_45 = RBX::Profiler::getLabelToken(group: "RakNet"); /*0x1410c34d8*/
        Init_thread_footer(pOnce: &_TSS0_537); /*0x1410c34e6*/
      }
      __unwind
      {
        Init_thread_abort(pOnce: &_TSS0_537); /*0x1431ecf77*/
      }
    }
  }
  RBX::Profiler::addLabelFormat(
    token: proflabeltoken_45,
    name: "#clients: %u",
    this->activeSystemListSize._Storage._Value);
  v7 = *v6; /*0x1410c3506*/
  if ( FFlag::CLI52064Experiment2.value ) /*0x1410c350f*/
  {
    if ( _TSS1_113 > v7 ) /*0x1410c3517*/
    {
      Init_thread_header(pOnce: &_TSS1_113); /*0x1410c3520*/
      if ( _TSS1_113 == -1 ) /*0x1410c352c*/
      {
        __wind /*0xf1c000000000005c*/
        {
          proflabeltoken_46 = RBX::Profiler::getLabelToken(group: "RakNet"); /*0x1410c353a*/
          Init_thread_footer(pOnce: &_TSS1_113); /*0x1410c3548*/
        }
        __unwind
        {
          Init_thread_abort(pOnce: &_TSS1_113); /*0x1431ecf87*/
        }
      }
    }
    rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410c3554*/
    head = this->artificialDelayBufferedPackets.queue.head; /*0x1410c3559*/
    tail = this->artificialDelayBufferedPackets.queue.tail; /*0x1410c355f*/
    if ( head > tail ) /*0x1410c3567*/
      v10 = this->artificialDelayBufferedPackets.queue.allocation_size - head + tail; /*0x1410c3575*/
    else
      v10 = tail - head; /*0x1410c3569*/
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410c357e*/
    v11 = proflabeltoken_46; /*0x1410c3583*/
  }
  else
  {
    if ( _TSS2_49 > v7 ) /*0x1410c3592*/
    {
      Init_thread_header(pOnce: &_TSS2_49); /*0x1410c359b*/
      if ( _TSS2_49 == -1 ) /*0x1410c35a7*/
      {
        __wind /*0xf1c0000000000044*/
        {
          proflabeltoken_47 = RBX::Profiler::getLabelToken(group: "RakNet"); /*0x1410c35b5*/
        }
        __unwind
        {
          Init_thread_abort(pOnce: &_TSS2_49); /*0x1431ecf97*/
        }
        Init_thread_footer(pOnce: &_TSS2_49); /*0x1410c35c3*/
      }
    }
    rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedPackets.queueMutex.criticalSection); /*0x1410c35cf*/
    v12 = this->bufferedPackets.queue.head; /*0x1410c35d4*/
    v13 = this->bufferedPackets.queue.tail; /*0x1410c35da*/
    if ( v12 > v13 ) /*0x1410c35e2*/
      v10 = this->bufferedPackets.queue.allocation_size - v12 + v13; /*0x1410c35f0*/
    else
      v10 = v13 - v12; /*0x1410c35e4*/
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedPackets.queueMutex.criticalSection); /*0x1410c35f9*/
    v11 = proflabeltoken_47; /*0x1410c35fe*/
  }
  RBX::Profiler::addLabelFormat(token: v11, name: "#bufferedPackets: %d", v10);
  RakNet::SystemAddress::SystemAddress(this: &firstReceivedDataPacketAddress); /*0x1410c3618*/
  v79 = 0; /*0x1410c3620*/
  v81 = -1; /*0x1410c3625*/
  while ( 1 )
  {
    if ( !FFlag::CLI52064Experiment2.value ) /*0x1410c3637*/
    {
      p_queueMutex = &this->bufferedPackets.queueMutex; /*0x1410c3813*/
      rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedPackets.queueMutex.criticalSection); /*0x1410c381d*/
      v35 = this->bufferedPackets.queue.head; /*0x1410c3822*/
      if ( v35 == this->bufferedPackets.queue.tail ) /*0x1410c382e*/
      {
        v16 = nullptr; /*0x1410c3830*/
        goto LABEL_56; /*0x1410c3833*/
      }
      v31 = v35 + 1; /*0x1410c3835*/
      this->bufferedPackets.queue.head = v31; /*0x1410c3837*/
      allocation_size = this->bufferedPackets.queue.allocation_size; /*0x1410c383d*/
      if ( v31 == allocation_size ) /*0x1410c3845*/
      {
        this->bufferedPackets.queue.head = 0; /*0x1410c3847*/
        array = this->bufferedPackets.queue.array; /*0x1410c384e*/
        v34 = allocation_size - 1; /*0x1410c3855*/
        goto LABEL_55; /*0x1410c3858*/
      }
      array = this->bufferedPackets.queue.array; /*0x1410c385a*/
      if ( v31 == 0 ) /*0x1410c3863*/
      {
        v34 = allocation_size - 1; /*0x1410c3865*/
        goto LABEL_55; /*0x1410c3868*/
      }
      goto LABEL_54; /*0x1410c3863*/
    }
    p_queueMutex = &this->artificialDelayBufferedPackets.queueMutex; /*0x1410c363d*/
    v15 = &this->artificialDelayBufferedPackets.queueMutex; /*0x1410c3644*/
    if ( !v5 ) /*0x1410c364a*/
    {
      rtc::CriticalSection::Enter(lpCriticalSection: &v15->criticalSection); /*0x1410c37c3*/
      v30 = this->artificialDelayBufferedPackets.queue.head; /*0x1410c37c8*/
      if ( v30 == this->artificialDelayBufferedPackets.queue.tail ) /*0x1410c37d4*/
      {
        v16 = nullptr; /*0x1410c37d6*/
        goto LABEL_56; /*0x1410c37d9*/
      }
      v31 = v30 + 1; /*0x1410c37de*/
      this->artificialDelayBufferedPackets.queue.head = v31; /*0x1410c37e0*/
      v32 = this->artificialDelayBufferedPackets.queue.allocation_size; /*0x1410c37e6*/
      if ( v31 == v32 ) /*0x1410c37ee*/
      {
        this->artificialDelayBufferedPackets.queue.head = 0; /*0x1410c37f0*/
        array = this->artificialDelayBufferedPackets.queue.array; /*0x1410c37f7*/
        v34 = v32 - 1; /*0x1410c37fe*/
LABEL_55:
        v16 = array[v34]; /*0x1410c386c*/
        goto LABEL_56; /*0x1410c386c*/
      }
      array = this->artificialDelayBufferedPackets.queue.array; /*0x1410c3803*/
      if ( v31 == 0 ) /*0x1410c380c*/
      {
        v34 = v32 - 1; /*0x1410c380e*/
        goto LABEL_55; /*0x1410c3811*/
      }
LABEL_54:
      v34 = v31 - 1; /*0x1410c386a*/
      goto LABEL_55; /*0x1410c386a*/
    }
    v16 = nullptr; /*0x1410c3650*/
    rtc::CriticalSection::Enter(lpCriticalSection: &v15->criticalSection); /*0x1410c3653*/
    v17 = this->artificialDelayBufferedPackets.queue.head; /*0x1410c3658*/
    v18 = this->artificialDelayBufferedPackets.queue.tail; /*0x1410c365e*/
    if ( v17 > v18 ) /*0x1410c3666*/
      v19 = this->artificialDelayBufferedPackets.queue.allocation_size - v17 + v18; /*0x1410c3674*/
    else
      v19 = v18 - v17; /*0x1410c3668*/
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410c3679*/
    v82 = v19; /*0x1410c367e*/
    p_peakRxQueueSize = &v82; /*0x1410c3689*/
    if ( this->artificialLatencyStats.peakRxQueueSize >= v19 ) /*0x1410c3690*/
      p_peakRxQueueSize = &this->artificialLatencyStats.peakRxQueueSize; /*0x1410c3690*/
    this->artificialLatencyStats.peakRxQueueSize = *p_peakRxQueueSize; /*0x1410c3696*/
    timeRead = -1; /*0x1410c3698*/
    rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410c36a2*/
    v22 = this->artificialDelayBufferedPackets.queue.head; /*0x1410c36a7*/
    if ( v22 != this->artificialDelayBufferedPackets.queue.tail ) /*0x1410c36b3*/
      timeRead = this->artificialDelayBufferedPackets.queue.array[v22]->timeRead; /*0x1410c36c2*/
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410c36cc*/
    if ( timeRead <= v3 ) /*0x1410c36d4*/
    {
      rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410c36dd*/
      v23 = this->artificialDelayBufferedPackets.queue.head; /*0x1410c36e2*/
      if ( v23 == this->artificialDelayBufferedPackets.queue.tail ) /*0x1410c36ee*/
      {
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410c36f3*/
      }
      else
      {
        v24 = v23 + 1; /*0x1410c36fd*/
        this->artificialDelayBufferedPackets.queue.head = v24; /*0x1410c36ff*/
        v25 = this->artificialDelayBufferedPackets.queue.allocation_size; /*0x1410c3705*/
        if ( v24 == v25 ) /*0x1410c370d*/
        {
          this->artificialDelayBufferedPackets.queue.head = 0; /*0x1410c370f*/
          v26 = this->artificialDelayBufferedPackets.queue.array; /*0x1410c3716*/
          v27 = v25 - 1; /*0x1410c371d*/
        }
        else
        {
          v26 = this->artificialDelayBufferedPackets.queue.array; /*0x1410c3722*/
          if ( v24 != 0 ) /*0x1410c372b*/
            v27 = v24 - 1; /*0x1410c3732*/
          else
            v27 = v25 - 1; /*0x1410c372d*/
        }
        v16 = v26[v27]; /*0x1410c3734*/
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410c373b*/
        if ( v16 != nullptr ) /*0x1410c3743*/
        {
          v88 = v3 - v16->timeRead; /*0x1410c374f*/
          p_rxQueueMaxDelay = &v88; /*0x1410c375a*/
          if ( this->artificialLatencyStats.rxQueueMaxDelay >= v88 ) /*0x1410c3761*/
            p_rxQueueMaxDelay = &this->artificialLatencyStats.rxQueueMaxDelay; /*0x1410c3761*/
          this->artificialLatencyStats.rxQueueMaxDelay = *p_rxQueueMaxDelay; /*0x1410c3768*/
          this->artificialLatencyStats.rxQueueExcessDelay += v3 - v16->timeRead; /*0x1410c3775*/
          ++this->artificialLatencyStats.rxDelayedPackets; /*0x1410c377c*/
        }
      }
    }
    v81 = -1; /*0x1410c3782*/
    rtc::CriticalSection::Enter(lpCriticalSection: &this->artificialDelayBufferedPackets.queueMutex.criticalSection); /*0x1410c378e*/
    v29 = this->artificialDelayBufferedPackets.queue.head; /*0x1410c3793*/
    if ( v29 != this->artificialDelayBufferedPackets.queue.tail ) /*0x1410c379f*/
      v81 = this->artificialDelayBufferedPackets.queue.array[v29]->timeRead; /*0x1410c37b9*/
LABEL_56:
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_queueMutex->criticalSection); /*0x1410c3873*/
    if ( v16 == nullptr ) /*0x1410c387b*/
      break; /*0x1410c387b*/
    v37 = 0; /*0x1410c3881*/
    list_size = this->socketList.list_size; /*0x1410c3884*/
    if ( list_size != 0 ) /*0x1410c388c*/
    {
      do /*0x1410c38b2*/
      {
        if ( this->socketList.listArray[v37]._Ptr->s == v16->s ) /*0x1410c38ac*/
          break; /*0x1410c38ac*/
        ++v37; /*0x1410c38ae*/
      }
      while ( v37 < list_size ); /*0x1410c38b2*/
    }
    if ( v37 != list_size )
    {
      bytesRead = (const void *)v16->bytesRead; /*0x1410c38c3*/
      v40 = 0; /*0x1410c38ca*/
      ruppHeaderLength[0] = 0; /*0x1410c38ce*/
      tokenInBitstream = (RBX::StringView)0LL; /*0x1410c38d4*/
      if ( DFFlag::RuppHeaderFromClientEnabled3.value && this->serverReceiveRupp && (int)bytesRead > 4 )
      {
        RakNet::BitStream::BitStream( /*0x1410c390c*/
          this: &b,
          _data: (unsigned __int8 *)v16,
          lengthInBytes: (unsigned int)bytesRead,
          _copyData: false);
        __wind
        {
          ruppInfoObject.tokenInBitstream.Data = nullptr; /*0x1410c3912*/
          ruppInfoObject.tokenInBitstream.Length = 0; /*0x1410c3916*/
          *(_WORD *)&ruppInfoObject.protocol = 1; /*0x1410c391a*/
          v41 = RBX::Network::Rupp::Rupp::deserialize(&ruppInfoObject, &b, ruppHeaderLength); /*0x1410c3930*/
          if ( v41 != 0 && DFLog::Rupp != 0 )
          {
            v42 = RBX::Network::Rupp::RuppError::toString(code: v41); /*0x1410c3944*/
            FLog::FastLogS(level: DFLog::Rupp, message: "[DFLog::Rupp] Rupp deserialization: %s", sarg: v42);
          }
          if ( ((ruppInfoObject.tokenType + 1) & 0xFD) == 0 ) /*0x1410c3967*/
            tokenInBitstream = ruppInfoObject.tokenInBitstream; /*0x1410c396d*/
        }
        __unwind
        {
          RakNet::BitStream::~BitStream(this: &b); /*0xf1c0000000000024*/
        }
        RakNet::BitStream::~BitStream(this: &b); /*0x1410c3978*/
        v40 = ruppHeaderLength[0]; /*0x1410c397d*/
      }
      if ( v40 > (int)bytesRead && DFLog::Rupp != 0 ) /*0x1410c3994*/
      {
        FLog::FastLog( /*0x1410c39a9*/
          level: DFLog::Rupp,
          message: "[DFLog::Rupp] Invalid Rupp header length [%d] > bytes read [%d]",
          arg0: (const void *)v40,
          arg1: bytesRead,
          arg2: nullptr);
        v40 = ruppHeaderLength[0]; /*0x1410c39ae*/
      }
      v43 = v40; /*0x1410c39b4*/
      v80 = v40; /*0x1410c39b8*/
      v44 = v40 > v16->bytesRead; /*0x1410c39c4*/
      if ( v40 <= v16->bytesRead ) /*0x1410c39c8*/
      {
        listArray = (std::shared_ptr<RBX::File> *)this->socketList.listArray; /*0x1410c39ce*/
        v85 = 0; /*0x1410c39d8*/
        Rep = listArray->_Rep; /*0x1410c39dd*/
        if ( Rep != nullptr ) /*0x1410c39e4*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410c39e6*/
          v40 = ruppHeaderLength[0]; /*0x1410c39ea*/
        }
        v85 = *listArray; /*0x1410c39f3*/
        v44 = RakNet::RakPeer::ProcessBannedPacket( /*0x1410c3a25*/
                systemAddress: &v16->systemAddress,
                udmuxAddress: &v16->dstAddress,
                rakPeer: this,
                rakNetSocket: &v85,
                timeUS);
        if ( !v44 ) /*0x1410c3a2a*/
        {
          v47 = v16->bytesRead - v43; /*0x1410c3a37*/
          v48 = &v16->data[v40]; /*0x1410c3a3e*/
          if ( v47 <= 2 ) /*0x1410c3a44*/
          {
            v44 = true; /*0x1410c3a46*/
            goto LABEL_102; /*0x1410c3a49*/
          }
          if ( DFFlag::IgnoreUnconnectedPing.value ) /*0x1410c3a55*/
            goto LABEL_89; /*0x1410c3a55*/
          if ( (unsigned __int8)(*v48 - 1) <= 1u && v47 == 25 ) /*0x1410c3a65*/
          {
            v49 = *(_QWORD *)(v48 + 9) + 0x1010101FF000100LL; /*0x1410c3a6b*/
            if ( *(_QWORD *)(v48 + 9) == 0xFEFEFEFE00FFFF00uLL ) /*0x1410c3a72*/
            {
              v50 = *(_QWORD *)(v48 + 17); /*0x1410c3a78*/
              goto LABEL_100; /*0x1410c3a7c*/
            }
LABEL_101:
            v44 = v49 == 0; /*0x1410c3b08*/
            if ( v49 == 0 ) /*0x1410c3b12*/
            {
LABEL_102:
              v54 = v16->timeRead; /*0x1410c3b18*/
              v55 = &this->socketList.listArray[v37]; /*0x1410c3b25*/
              v86 = 0; /*0x1410c3b2f*/
              v56 = v55->_Rep; /*0x1410c3b34*/
              if ( v56 != nullptr ) /*0x1410c3b3b*/
              {
                _InterlockedIncrement((volatile signed __int32 *)&v56->_Uses); /*0x1410c3b3d*/
                v40 = ruppHeaderLength[0]; /*0x1410c3b41*/
              }
              v86 = *v55; /*0x1410c3b4a*/
              v91 = tokenInBitstream; /*0x1410c3b5a*/
              p_systemAddress = &v16->systemAddress; /*0x1410c3ba1*/
              RakNet::RakPeer::ProcessOfflineNetworkPacket( /*0x1410c3bab*/
                systemAddress: &v16->systemAddress,
                dstAddress: &v16->dstAddress,
                data: v48,
                length: v16->bytesRead - v43,
                rakPeer: this,
                rakNetSocket: &v86,
                timeRead: v54,
                timeUS,
                ruppLength: v40,
                gameServiceToken: &v91);
              v58 = false; /*0x1410c3bb0*/
              goto LABEL_124; /*0x1410c3bb3*/
            }
LABEL_105:
            p_systemAddress = &v16->systemAddress; /*0x1410c3bb8*/
            if ( DFInt::ReportNumDataPacketsPerPeerEachCycle_HundredthsPercentage != 0 ) /*0x1410c3bc6*/
            {
              RakNet::SystemAddress::operator=(this: &firstReceivedDataPacketAddress, input: &v16->systemAddress); /*0x1410c3bcf*/
              if ( RakNet::SystemAddress::operator==(this: &v16->systemAddress, right: &firstReceivedDataPacketAddress) != 0 ) /*0x1410c3be2*/
                ++v79; /*0x1410c3be4*/
            }
            v83 = v16->timeRead; /*0x1410c3bef*/
            v59 = v16->bytesRead; /*0x1410c3bf3*/
            *(_OWORD *)&sa.address.addr6.sin6_family = *(_OWORD *)&p_systemAddress->address.addr6.sin6_family; /*0x1410c3bfd*/
            *((_OWORD *)&sa.address.addr4 + 1) = *((_OWORD *)&v16->systemAddress.address.addr4 + 1); /*0x1410c3c05*/
            if ( RakNet::SystemAddress::operator==(this: &sa, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410c3c1b*/
            {
              v60 = this->remoteSystemLookup[RakNet::SystemAddress::ToInteger(&sa) /*0x1410c3c3c*/
                                           % (8 * (unsigned int)this->maximumNumberOfPeers)];
              if ( v60 != nullptr ) /*0x1410c3c43*/
              {
                while ( RakNet::SystemAddress::operator==( /*0x1410c3c72*/
                          this: &this->remoteSystemList[v60->index].systemAddress,
                          right: &sa) == 0 )
                {
                  v60 = v60->next; /*0x1410c3c74*/
                  if ( v60 == nullptr ) /*0x1410c3c7b*/
                  {
                    p_systemAddress = &v16->systemAddress; /*0x1410c3c7d*/
                    v44 = true; /*0x1410c3c84*/
                    v43 = v80; /*0x1410c3c87*/
                    goto LABEL_123; /*0x1410c3c8c*/
                  }
                }
                index = v60->index; /*0x1410c3c91*/
                if ( (_DWORD)index != -1 ) /*0x1410c3c96*/
                {
                  if ( this->remoteSystemList[index].isActive._Storage._Value ) /*0x1410c3caa*/
                  {
                    v62 = &this->remoteSystemList[index]; /*0x1410c3cbf*/
                    if ( v62 != nullptr ) /*0x1410c3cc2*/
                    {
                      RakNet::SystemAddress::operator=(this: &v62->myExternalSystemAddress, input: &v16->dstAddress); /*0x1410c3cd6*/
                      v63 = (RakNet::ReliabilityLayer *)((char *)&v62->reliabilityLayer.rbxSessionCrypto._Ptr + 4); /*0x1410c3cdb*/
                      Value = v62->recordJoinDataRxStats._Storage._Value; /*0x1410c3ce2*/
                      v65 = this->socketList.listArray; /*0x1410c3cea*/
                      v84 = 0; /*0x1410c3cf4*/
                      v66 = v65->_Rep; /*0x1410c3cf9*/
                      if ( v66 != nullptr ) /*0x1410c3d00*/
                        _InterlockedIncrement((volatile signed __int32 *)&v66->_Uses); /*0x1410c3d02*/
                      v84 = *v65; /*0x1410c3d09*/
                      p_myExternalSystemAddress = &v62->myExternalSystemAddress; /*0x1410c3d21*/
                      arg2 = v62->MTUSize; /*0x1410c3d53*/
                      p_systemAddress = &v16->systemAddress; /*0x1410c3d57*/
                      RakNet::ReliabilityLayer::HandleSocketReceiveFromConnectedPlayer( /*0x1410c3d6a*/
                        this: v63,
                        buffer: &v16->data[v40],
                        length: v59 - v80,
                        systemAddress: &v16->systemAddress,
                        MTUSize: arg2,
                        socket: &v84,
                        timeRead: v83,
                        updateBitStream,
                        recordJoinDataRxStats: Value,
                        ruppHeader: &this->ruppHeader,
                        udmuxAddress: p_myExternalSystemAddress);
                      v44 = false; /*0x1410c3d6f*/
                      v40 = ruppHeaderLength[0]; /*0x1410c3d72*/
                      v43 = v80; /*0x1410c3d78*/
                      goto LABEL_123; /*0x1410c3d7d*/
                    }
                  }
                  v40 = ruppHeaderLength[0]; /*0x1410c3d7f*/
                }
              }
              p_systemAddress = &v16->systemAddress; /*0x1410c3d85*/
            }
            v44 = true; /*0x1410c3d8c*/
            v43 = v80; /*0x1410c3d8f*/
LABEL_123:
            v58 = true; /*0x1410c3d9d*/
LABEL_124:
            if ( DFLog::RakNetPktTrace != 0 && v44 ) /*0x1410c3db1*/
            {
              dstAddress = v16->dstAddress; /*0x1410c3dbb*/
              v94 = *p_systemAddress; /*0x1410c3dce*/
              RakNet::LogPkt( /*0x1410c3e04*/
                systemAddress: &v94,
                externalAddress: &dstAddress,
                data: &v16->data[v40],
                length: v16->bytesRead - v43,
                direction: "Rx",
                isDrop: v58);
            }
            if ( DFFlag::ReportPktDropStats2.value && v58 ) /*0x1410c3e15*/
            {
              v67 = (unsigned int)v16->bytesRead; /*0x1410c3e17*/
              if ( this->trackDroppedPackets.droppedPktQueue.m_size != 0 ) /*0x1410c3e26*/
              {
                m_last = this->trackDroppedPackets.droppedPktQueue.m_last; /*0x1410c3e28*/
                if ( m_last == this->trackDroppedPackets.droppedPktQueue.m_buff ) /*0x1410c3e36*/
                  m_last = this->trackDroppedPackets.droppedPktQueue.m_end; /*0x1410c3e38*/
                ++m_last[-1].numOfPktsDropped; /*0x1410c3e3f*/
                m_last[-1].totalDroppedBytes += v67; /*0x1410c3e42*/
                minDropPktSize = m_last[-1].minDropPktSize; /*0x1410c3e46*/
                if ( (int)v67 < minDropPktSize ) /*0x1410c3e4b*/
                  minDropPktSize = v67; /*0x1410c3e4b*/
                m_last[-1].minDropPktSize = minDropPktSize; /*0x1410c3e4e*/
                maxDropPktSize = m_last[-1].maxDropPktSize; /*0x1410c3e51*/
                if ( maxDropPktSize < (int)v67 ) /*0x1410c3e56*/
                  maxDropPktSize = v67; /*0x1410c3e56*/
                m_last[-1].maxDropPktSize = maxDropPktSize; /*0x1410c3e59*/
              }
            }
            v3 = timeUS; /*0x1410c3e5f*/
            goto LABEL_138; /*0x1410c3e5f*/
          }
          if ( *v48 != 28 || (unsigned int)v47 < 0x1D ) /*0x1410c3a89*/
          {
LABEL_89:
            v51 = (unsigned __int8)*v48; /*0x1410c3a9e*/
            if ( ((unsigned __int8)v51 <= 0x1Au && (v52 = 76941792, _bittest(&v52, v51)) /*0x1410c3ac9*/
               || (unsigned __int8)(v51 - 120) <= 6u && (v53 = 105, _bittest(&v53, v51 - 120)))
              && (unsigned int)v47 >= 0x19 )
            {
              v49 = *(_QWORD *)(v48 + 1) + 0x1010101FF000100LL; /*0x1410c3acf*/
              if ( *(_QWORD *)(v48 + 1) != 0xFEFEFEFE00FFFF00uLL ) /*0x1410c3ad6*/
                goto LABEL_101; /*0x1410c3ad6*/
              v50 = *(_QWORD *)(v48 + 9); /*0x1410c3ad8*/
            }
            else
            {
              if ( (_BYTE)v51 != 25 || v47 != 26 ) /*0x1410c3aea*/
                goto LABEL_105; /*0x1410c3aea*/
              v49 = *(_QWORD *)(v48 + 2) + 0x1010101FF000100LL; /*0x1410c3af4*/
              if ( *(_QWORD *)(v48 + 2) != 0xFEFEFEFE00FFFF00uLL ) /*0x1410c3afb*/
                goto LABEL_101; /*0x1410c3afb*/
              v50 = *(_QWORD *)(v48 + 10); /*0x1410c3afd*/
            }
          }
          else
          {
            v49 = *(_QWORD *)(v48 + 17) + 0x1010101FF000100LL; /*0x1410c3a8f*/
            if ( *(_QWORD *)(v48 + 17) != 0xFEFEFEFE00FFFF00uLL ) /*0x1410c3a96*/
              goto LABEL_101; /*0x1410c3a96*/
            v50 = *(_QWORD *)(v48 + 25); /*0x1410c3a98*/
          }
LABEL_100:
          v49 = v50 - 0x78563412FDFDFDFDLL; /*0x1410c3b01*/
          goto LABEL_101; /*0x1410c3b01*/
        }
      }
      p_systemAddress = &v16->systemAddress; /*0x1410c3d96*/
      goto LABEL_123; /*0x1410c3d96*/
    }
LABEL_138:
    v71 = 1240; /*0x1410c3e66*/
    if ( FFlag::CLI52064Experiment2.value ) /*0x1410c3e77*/
      v71 = 1376; /*0x1410c3e77*/
    v72 = (char *)this + v71; /*0x1410c3e7a*/
    rtc::CriticalSection::Enter(lpCriticalSection: (LPCRITICAL_SECTION)(v72 + 32)); /*0x1410c3e81*/
    DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::Release( /*0x1410c3e99*/
      this: (DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct> *)v72,
      m: (DataStructures::MemoryPool<RakNet::RakPeer::RecvFromStruct>::MemoryWithPage *)v16,
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
      line: 0x1570u);
    RakNet::SimpleMutex::Unlock(lpCriticalSection: (LPCRITICAL_SECTION)(v72 + 32)); /*0x1410c3ea2*/
    v5 = v98; /*0x1410c3ea7*/
  }
  result = v81; /*0x1410c3eb4*/
  if ( DFInt::ReportNumDataPacketsPerPeerEachCycle_HundredthsPercentage != 0 ) /*0x1410c3ec0*/
  {
    maxPacketsPerPeerOneCycle = v79; /*0x1410c3ec2*/
    if ( v79 >= 1 ) /*0x1410c3ec9*/
    {
      this->totalPacketsPerPeerOneCycle += v79; /*0x1410c3ecb*/
      ++this->numCyclesSampled; /*0x1410c3ed1*/
      minPacketsPerPeerOneCycle = maxPacketsPerPeerOneCycle; /*0x1410c3edd*/
      if ( this->minPacketsPerPeerOneCycle < maxPacketsPerPeerOneCycle ) /*0x1410c3ee1*/
        minPacketsPerPeerOneCycle = this->minPacketsPerPeerOneCycle; /*0x1410c3ee1*/
      this->minPacketsPerPeerOneCycle = minPacketsPerPeerOneCycle; /*0x1410c3ee4*/
      if ( maxPacketsPerPeerOneCycle < this->maxPacketsPerPeerOneCycle ) /*0x1410c3ef2*/
        maxPacketsPerPeerOneCycle = this->maxPacketsPerPeerOneCycle; /*0x1410c3ef2*/
      this->maxPacketsPerPeerOneCycle = maxPacketsPerPeerOneCycle; /*0x1410c3ef5*/
    }
  }
  return result; /*0x1410c3efb*/
}

// Address: 0x1410c3f10 | Name: ?ProcessOfflineNetworkPacket@RakPeer@RakNet@@CAXAEBUSystemAddress@2@0PEBDHPEAV12@V?$shared_ptr@URakNetSocket@RakNet@@@std@@_K4GVStringView@RBX@@@Z
void __fastcall RakNet::RakPeer::ProcessOfflineNetworkPacket(
        RakNet::SystemAddress *systemAddress,
        const RakNet::SystemAddress *dstAddress,
        char *data,
        int length,
        RakNet::RakPeer *rakPeer,
        std::shared_ptr<RakNet::RakNetSocket> *rakNetSocket,
        unsigned __int64 timeRead,
        unsigned __int64 timeUS,
        unsigned __int16 ruppLength,
        RBX::StringView *gameServiceToken)
{
  unsigned __int64 v10; // rdi
  const RakNet::SystemAddress *v12; // r15
  unsigned int v14; // r14d
  char v15; // bl
  unsigned __int8 v16; // cl
  bool v17; // di
  volatile signed __int32 *v18; // rbx
  std::shared_ptr<RBX::Network::Rupp::Rupp> *v19; // rax
  std::_Ref_count_base *Rep; // rbx
  unsigned __int8 *p_sendPingTime; // rdx
  unsigned __int8 *p_myGuid; // rdx
  unsigned int v23; // ebx
  const char *v24; // rax
  unsigned __int8 *v25; // rdx
  unsigned int v26; // r8d
  std::_Ref_count_base *v27; // rcx
  std::shared_ptr<RakNet::RakNetSocket> *v28; // rdi
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v29; // rbx
  __int16 systemIndex; // ax
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v31; // r14
  unsigned __int8 *p_pingMS; // rdx
  __int16 RemoteSystemIndex; // ax
  RakNet::BitStream *p_bsIn; // rcx
  volatile signed __int32 *v35; // rbx
  unsigned int v36; // ecx
  std::_Ref_count_base *v37; // rbx
  int v38; // edx
  unsigned int head; // ecx
  unsigned int tail; // edx
  unsigned int v41; // edx
  __int64 v42; // rax
  unsigned int allocation_size; // r8d
  RakNet::RakPeer::RequestedConnectionStruct **array; // rdx
  RakNet::RakPeer::RequestedConnectionStruct **v45; // rbx
  RakNet::RakPeer::RequestedConnectionStruct *v46; // rbx
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v47; // rbx
  unsigned __int64 v48; // rbx
  RakNet::RakPeer_vtbl *v49; // rax
  const RakNet::RakNetGUID *v50; // rax
  unsigned __int8 inByteArray; // [rsp+60h] [rbp-A0h] BYREF
  unsigned __int8 v52[3]; // [rsp+61h] [rbp-9Fh] BYREF
  unsigned int pingMS; // [rsp+64h] [rbp-9Ch] BYREF
  unsigned __int8 inOutByteArray[8]; // [rsp+68h] [rbp-98h] BYREF
  unsigned __int64 sendPingTime; // [rsp+70h] [rbp-90h] BYREF
  RakNet::RakNetGUID guid; // [rsp+78h] [rbp-88h] BYREF
  unsigned __int64 ping; // [rsp+88h] [rbp-78h] BYREF
  std::shared_ptr<RakNet::RakNetSocket> v58; // [rsp+90h] [rbp-70h] BYREF
  RakNet::SystemAddress v59; // [rsp+A0h] [rbp-60h] BYREF
  unsigned __int8 v60[8]; // [rsp+C0h] [rbp-40h] BYREF
  unsigned __int8 v61[8]; // [rsp+C8h] [rbp-38h] BYREF
  RakNet::SystemAddress right; // [rsp+D0h] [rbp-30h] BYREF
  RakNet::SystemAddress sa; // [rsp+F0h] [rbp-10h] BYREF
  char v64[8]; // [rsp+110h] [rbp+10h] BYREF
  volatile signed __int32 *v65; // [rsp+118h] [rbp+18h]
  std::shared_ptr<RBX::File> v66; // [rsp+120h] [rbp+20h] BYREF
  RakNet::BitStream outBitStream; // [rsp+130h] [rbp+30h] BYREF
  RakNet::BitStream bsOut; // [rsp+260h] [rbp+160h] BYREF
  RakNet::BitStream bsIn; // [rsp+390h] [rbp+290h] BYREF
  RakNet::BitStream inBitStream; // [rsp+4C0h] [rbp+3C0h] BYREF
  RakNet::BitStream bs; // [rsp+5F0h] [rbp+4F0h] BYREF

  __wind
  {
    v10 = length; /*0x1410c3f39*/
    v12 = dstAddress; /*0x1410c3f3f*/
    v14 = 0; /*0x1410c3f45*/
    v15 = 0; /*0x1410c3f48*/
    *(_DWORD *)inOutByteArray = 0; /*0x1410c3f4b*/
    if ( !DFFlag::IgnoreUnconnectedPing.value ) /*0x1410c3f5a*/
    {
      v16 = *data; /*0x1410c3f60*/
      if ( (unsigned __int8)(*data - 1) <= 1u && length == 25 ) /*0x1410c3f72*/
      {
        if ( DFFlag::UnconnectedPingReport.value ) /*0x1410c3f86*/
        {
          ++rakPeer->unconnectedPingStats.unconnectedPings; /*0x1410c3f88*/
          v16 = *data; /*0x1410c3f8f*/
        }
        if ( v16 == 1 || RakNet::RakPeer::AllowIncomingConnections(this: rakPeer) ) /*0x1410c3f9b*/
        {
          RakNet::BitStream::BitStream( /*0x1410c3fb9*/
            this: &inBitStream,
            _data: (unsigned __int8 *)data,
            lengthInBytes: 0x19u,
            _copyData: false);
          __wind /*0xf1c0000000000094*/
          {
            RakNet::BitStream::IgnoreBits(this: &inBitStream, numberOfBits: 8u); /*0x1410c3fcb*/
            if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c3fd0*/
            {
              RakNet::BitStream::ReadBits( /*0x1410c4013*/
                this: &inBitStream,
                inOutByteArray: (unsigned __int8 *)&sendPingTime,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true);
            }
            else if ( RakNet::BitStream::ReadBits( /*0x1410c3ff5*/
                        this: &inBitStream,
                        inOutByteArray,
                        numberOfBitsToRead: 0x40u,
                        alignBitsToRight: true) != 0 )
            {
              RBX::Network::NetworkStream::ReverseBytes( /*0x1410c4007*/
                inByteArray: inOutByteArray,
                inOutByteArray: (unsigned __int8 *)&sendPingTime,
                length: 8u);
            }
            RakNet::BitStream::BitStream(this: &outBitStream); /*0x1410c401c*/
            __wind /*0xf1c0000000000088*/
            {
              v17 = false; /*0x1410c4046*/
              if ( DFFlag::RuppHeaderFromClientEnabled3.value ) /*0x1410c4029*/
              {
                v15 = 1; /*0x1410c403b*/
                if ( rakPeer->getRuppHeader(this: rakPeer, result: v64)->_Ptr != nullptr ) /*0x1410c4044*/
                  v17 = true; /*0x1410c4029*/
              }
              if ( (v15 & 1) != 0 ) /*0x1410c4051*/
              {
                v18 = v65; /*0x1410c4053*/
                if ( v65 != nullptr && _InterlockedExchangeAdd(v65 + 2, 0xFFFFFFFF) == 1 ) /*0x1410c4067*/
                {
                  (**(void (__fastcall ***)(volatile signed __int32 *))v18)(a1: v18); /*0x1410c406f*/
                  if ( _InterlockedExchangeAdd(v18 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c407c*/
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 8LL))(a1: v18); /*0x1410c4084*/
                }
              }
              if ( v17 ) /*0x1410c408a*/
              {
                v19 = rakPeer->getRuppHeader(this: rakPeer, result: &v66); /*0x1410c4096*/
                __wind /*0xf1c000000000007c*/
                {
                  RBX::Network::Rupp::Rupp::serialize(this: v19->_Ptr, b: &outBitStream); /*0x1410c40a4*/
                }
                __unwind
                {
                  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v66); /*0xf1c0000000000074*/
                }
                Rep = v66._Rep; /*0x1410c40aa*/
                if ( v66._Rep != nullptr /*0x1410c40be*/
                  && _InterlockedExchangeAdd((volatile signed __int32 *)&v66._Rep->_Uses, 0xFFFFFFFF) == 1 )
                {
                  Rep->_Destroy(this: Rep); /*0x1410c40c6*/
                  if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c40d3*/
                    Rep->_Delete_this(this: Rep); /*0x1410c40db*/
                }
              }
              inByteArray = 28; /*0x1410c40de*/
              RakNet::BitStream::WriteBits( /*0x1410c40f5*/
                this: &outBitStream,
                &inByteArray,
                numberOfBitsToWrite: 8u,
                rightAlignedBits: true);
              if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c40fa*/
              {
                p_sendPingTime = (unsigned __int8 *)&sendPingTime; /*0x1410c411d*/
              }
              else
              {
                RBX::Network::NetworkStream::ReverseBytes( /*0x1410c4112*/
                  inByteArray: (unsigned __int8 *)&sendPingTime,
                  inOutByteArray: v60,
                  length: 8u);
                p_sendPingTime = v60; /*0x1410c4117*/
              }
              RakNet::BitStream::WriteBits( /*0x1410c412f*/
                this: &outBitStream,
                inByteArray: p_sendPingTime,
                numberOfBitsToWrite: 0x40u,
                rightAlignedBits: true);
              if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c4134*/
              {
                p_myGuid = (unsigned __int8 *)&rakPeer->myGuid; /*0x1410c4159*/
              }
              else
              {
                RBX::Network::NetworkStream::ReverseBytes( /*0x1410c414e*/
                  inByteArray: (unsigned __int8 *)&rakPeer->myGuid,
                  inOutByteArray: v61,
                  length: 8u);
                p_myGuid = v61; /*0x1410c4153*/
              }
              RakNet::BitStream::WriteBits( /*0x1410c416d*/
                this: &outBitStream,
                inByteArray: p_myGuid,
                numberOfBitsToWrite: 0x40u,
                rightAlignedBits: true);
              RakNet::BitStream::WriteAlignedBytes( /*0x1410c4183*/
                this: &outBitStream,
                inByteArray: OFFLINE_MESSAGE_DATA_ID,
                numberOfBytesToWrite: 0x10u);
              rtc::CriticalSection::Enter(lpCriticalSection: &rakPeer->rakPeerMutexes[1].criticalSection); /*0x1410c418f*/
              v23 = rakPeer->offlinePingResponse.GetNumberOfBytesUsed(this: &rakPeer->offlinePingResponse); /*0x1410c419f*/
              v24 = (const char *)rakPeer->offlinePingResponse.GetData(this: &rakPeer->offlinePingResponse); /*0x1410c41a9*/
              RakNet::BitStream::Write(this: &outBitStream, inputByteArray: v24, numberOfBytes: v23); /*0x1410c41b6*/
              RakNet::SimpleMutex::Unlock(lpCriticalSection: &rakPeer->rakPeerMutexes[1].criticalSection); /*0x1410c41c2*/
              v25 = outBitStream.data; /*0x1410c41cb*/
              v26 = (outBitStream.numberOfBitsUsed + 7) >> 3; /*0x1410c41d3*/
              if ( FFlag::CLI52064Experiment2.value ) /*0x1410c41de*/
              {
                v58 = 0; /*0x1410c41e3*/
                v27 = rakNetSocket->_Rep; /*0x1410c41ef*/
                if ( v27 != nullptr ) /*0x1410c41f6*/
                {
                  _InterlockedIncrement((volatile signed __int32 *)&v27->_Uses); /*0x1410c41f8*/
                  v27 = rakNetSocket->_Rep; /*0x1410c41fc*/
                }
                v58._Ptr = rakNetSocket->_Ptr; /*0x1410c4203*/
                v58._Rep = v27; /*0x1410c4207*/
                RakNet::SocketLayer::SendToOrDelay( /*0x1410c424d*/
                  socket: &v58,
                  data: (const char *)v25,
                  length: v26,
                  dstAddress: systemAddress,
                  srcAddress: dstAddress,
                  raknetMetaDataEncrypted: false,
                  rakPeer,
                  reliabilityLayer: nullptr,
                  now: timeUS,
                  file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                  line: 4917);
                v28 = rakNetSocket; /*0x1410c4252*/
              }
              else
              {
                v28 = rakNetSocket; /*0x1410c425b*/
                RakNet::SocketLayer::SendTo( /*0x1410c4290*/
                  s: rakNetSocket->_Ptr->s,
                  data: (const char *)outBitStream.data,
                  length: v26,
                  dstAddress: systemAddress,
                  srcAddress: dstAddress,
                  raknetMetaDataEncrypted: false,
                  file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                  line: 4922);
              }
              v29 = RakNet::RakPeer::AllocPacket( /*0x1410c42ab*/
                      this: rakPeer,
                      dataSize: 1u,
                      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                      line: 0x133Du);
              *v29->userMemory.data = *data; /*0x1410c42bc*/
              RakNet::SystemAddress::operator=(this: &v29->userMemory.systemAddress, input: systemAddress); /*0x1410c42c4*/
              v29->userMemory.guid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410c42d0*/
              right = *systemAddress; /*0x1410c42e4*/
              if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410c4303*/
              {
                systemIndex = -1; /*0x1410c4305*/
              }
              else if ( right.systemIndex != 0xFFFF /*0x1410c434c*/
                     && right.systemIndex < rakPeer->maximumNumberOfPeers
                     && RakNet::SystemAddress::operator==(
                          this: &rakPeer->remoteSystemList[right.systemIndex].systemAddress,
                          &right) != 0
                     && rakPeer->remoteSystemList[right.systemIndex].isActive._Storage._Value )
              {
                systemIndex = right.systemIndex; /*0x1410c435b*/
              }
              else
              {
                systemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this: rakPeer, sa: &right); /*0x1410c4368*/
              }
              v29->userMemory.systemAddress.systemIndex = systemIndex; /*0x1410c4370*/
              v29->userMemory.guid.systemIndex = systemIndex; /*0x1410c4374*/
              RakNet::RakPeer::AddPacketToProducer(this: rakPeer, p: (RakNet::InternalPacket *)v29); /*0x1410c437e*/
            }
            __unwind
            {
              RakNet::BitStream::~BitStream(this: &outBitStream); /*0xf1c0000000000068*/
            }
            RakNet::BitStream::~BitStream(this: &outBitStream); /*0x1410c4388*/
            RakNet::BitStream::~BitStream(this: &inBitStream); /*0x1410c4395*/
          }
          __unwind
          {
            RakNet::BitStream::~BitStream(this: &inBitStream); /*0xf1c000000000002c*/
          }
          goto LABEL_80; /*0xf1c0000000000028*/
        }
        goto LABEL_79; /*0x1410c3fa2*/
      }
      if ( v16 == 28 ) /*0x1410c43a2*/
      {
        if ( (unsigned int)(length - 33) <= 0x18F ) /*0x1410c43b3*/
        {
          if ( DFFlag::UnconnectedPingReport.value ) /*0x1410c43c7*/
            ++rakPeer->unconnectedPingStats.unconnectedPongs; /*0x1410c43c9*/
          v31 = RakNet::RakPeer::AllocPacket( /*0x1410c43e7*/
                  this: rakPeer,
                  dataSize: length - 28,
                  file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                  line: 0x1354u);
          RakNet::BitStream::BitStream( /*0x1410c43fa*/
            this: &bsIn,
            _data: (unsigned __int8 *)data,
            lengthInBytes: v10,
            _copyData: false);
          __wind /*0xf1c0000000000058*/
          {
            RakNet::BitStream::IgnoreBytes(this: &bsIn, numberOfBytes: 1u); /*0x1410c440c*/
            if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c4411*/
            {
              RakNet::BitStream::ReadBits( /*0x1410c4452*/
                this: &bsIn,
                inOutByteArray: (unsigned __int8 *)&ping,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true);
            }
            else if ( RakNet::BitStream::ReadBits( /*0x1410c4436*/
                        this: &bsIn,
                        inOutByteArray: (unsigned __int8 *)&guid,
                        numberOfBitsToRead: 0x40u,
                        alignBitsToRight: true) != 0 )
            {
              RBX::Network::NetworkStream::ReverseBytes( /*0x1410c4447*/
                inByteArray: (unsigned __int8 *)&guid,
                inOutByteArray: (unsigned __int8 *)&ping,
                length: 8u);
            }
            if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c4457*/
            {
              RakNet::BitStream::ReadBits( /*0x1410c4496*/
                this: &bsIn,
                inOutByteArray: (unsigned __int8 *)&v31->userMemory.guid,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true);
            }
            else if ( RakNet::BitStream::ReadBits( /*0x1410c447b*/
                        this: &bsIn,
                        inOutByteArray: (unsigned __int8 *)&v59,
                        numberOfBitsToRead: 0x40u,
                        alignBitsToRight: true) != 0 )
            {
              RBX::Network::NetworkStream::ReverseBytes( /*0x1410c448b*/
                inByteArray: (unsigned __int8 *)&v59,
                inOutByteArray: (unsigned __int8 *)&v31->userMemory.guid,
                length: 8u);
            }
            RakNet::BitStream::BitStream( /*0x1410c44ad*/
              this: &bsOut,
              _data: v31->userMemory.data,
              lengthInBytes: v31->userMemory.length,
              _copyData: false);
            __wind /*0xf1c000000000004c*/
            {
              RakNet::BitStream::ResetWritePointer(this: &bsOut); /*0x1410c44ba*/
              v52[0] = 28; /*0x1410c44bf*/
              RakNet::BitStream::WriteBits( /*0x1410c44d9*/
                this: &bsOut,
                inByteArray: v52,
                numberOfBitsToWrite: 8u,
                rightAlignedBits: true);
              pingMS = ping; /*0x1410c44e1*/
              if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c44e5*/
              {
                p_pingMS = (unsigned __int8 *)&pingMS; /*0x1410c450a*/
              }
              else
              {
                RBX::Network::NetworkStream::ReverseBytes( /*0x1410c44fe*/
                  inByteArray: (unsigned __int8 *)&pingMS,
                  inOutByteArray,
                  length: 4u);
                p_pingMS = inOutByteArray; /*0x1410c4503*/
              }
              RakNet::BitStream::WriteBits( /*0x1410c451f*/
                this: &bsOut,
                inByteArray: p_pingMS,
                numberOfBitsToWrite: 0x20u,
                rightAlignedBits: true);
              RakNet::BitStream::WriteAlignedBytes( /*0x1410c4532*/
                this: &bsOut,
                inByteArray: (const unsigned __int8 *)data + 33,
                numberOfBytesToWrite: v10 - 33);
              RakNet::SystemAddress::operator=(this: &v31->userMemory.systemAddress, input: systemAddress); /*0x1410c453d*/
              sa = *systemAddress; /*0x1410c4547*/
              if ( RakNet::SystemAddress::operator==(this: &sa, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410c4566*/
              {
                RemoteSystemIndex = -1; /*0x1410c4568*/
              }
              else if ( sa.systemIndex != 0xFFFF /*0x1410c45ae*/
                     && sa.systemIndex < rakPeer->maximumNumberOfPeers
                     && RakNet::SystemAddress::operator==(
                          this: &rakPeer->remoteSystemList[sa.systemIndex].systemAddress,
                          right: &sa) != 0
                     && rakPeer->remoteSystemList[sa.systemIndex].isActive._Storage._Value )
              {
                RemoteSystemIndex = sa.systemIndex; /*0x1410c45bd*/
              }
              else
              {
                RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this: rakPeer, &sa); /*0x1410c45ca*/
              }
              v31->userMemory.systemAddress.systemIndex = RemoteSystemIndex; /*0x1410c45d0*/
              v31->userMemory.guid.systemIndex = RemoteSystemIndex; /*0x1410c45d5*/
              RakNet::RakPeer::AddPacketToProducer(this: rakPeer, p: (RakNet::InternalPacket *)v31); /*0x1410c45e0*/
            }
            __unwind
            {
              RakNet::BitStream::~BitStream(this: &bsOut); /*0xf1c0000000000044*/
            }
            RakNet::BitStream::~BitStream(this: &bsOut); /*0x1410c45ed*/
            p_bsIn = &bsIn; /*0x1410c45f3*/
          }
          __unwind
          {
            RakNet::BitStream::~BitStream(this: &bsIn); /*0xf1c0000000000038*/
          }
LABEL_78:
          RakNet::BitStream::~BitStream(this: p_bsIn); /*0x1410c45fa*/
          goto LABEL_79; /*0x1410c45fa*/
        }
        v12 = dstAddress; /*0x1410c464a*/
      }
    }
    v36 = (unsigned __int8)*data; /*0x1410c4651*/
    if ( (_BYTE)v36 != 6 )
    {
      if ( (_BYTE)v36 != 8 )
      {
        if ( (unsigned __int8)v36 <= 0x1Au )
        {
          v38 = 127272960; /*0x1410c46bd*/
          if ( _bittest(&v38, v36) )
          {
            RakNet::BitStream::BitStream( /*0x1410c46db*/
              this: &bs,
              _data: (unsigned __int8 *)data,
              lengthInBytes: length,
              _copyData: false);
            __wind
            {
              RakNet::BitStream::IgnoreBytes(this: &bs, numberOfBytes: 1u); /*0x1410c46ed*/
              RakNet::BitStream::IgnoreBytes(this: &bs, numberOfBytes: 0x10u); /*0x1410c46fe*/
              if ( *data == 25 ) /*0x1410c4706*/
                RakNet::BitStream::IgnoreBytes(this: &bs, numberOfBytes: 1u); /*0x1410c4714*/
              RakNet::RakNetGUID::RakNetGUID(this: &guid); /*0x1410c471e*/
              if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c4723*/
              {
                RakNet::BitStream::ReadBits( /*0x1410c4764*/
                  this: &bs,
                  inOutByteArray: (unsigned __int8 *)&guid,
                  numberOfBitsToRead: 0x40u,
                  alignBitsToRight: true);
              }
              else if ( RakNet::BitStream::ReadBits( /*0x1410c4747*/
                          this: &bs,
                          inOutByteArray: (unsigned __int8 *)&v59,
                          numberOfBitsToRead: 0x40u,
                          alignBitsToRight: true) != 0 )
              {
                RBX::Network::NetworkStream::ReverseBytes( /*0x1410c4758*/
                  inByteArray: (unsigned __int8 *)&v59,
                  inOutByteArray: (unsigned __int8 *)&guid,
                  length: 8u);
              }
              if ( DFLog::RakNetConnectTrace != 0 )
                FLog::FastLogFormatted(
                  level: DFLog::RakNetConnectTrace,
                  message: "[DFLog::RakNetConnectTrace] RakNet: Bad Offline message received, message id : %u",
                  (unsigned __int8)*data);
              rtc::CriticalSection::Enter(lpCriticalSection: &rakPeer->requestedConnectionQueueMutex.criticalSection); /*0x1410c4794*/
              while ( 1 )
              {
                head = rakPeer->requestedConnectionQueue.head; /*0x1410c47a0*/
                tail = rakPeer->requestedConnectionQueue.tail; /*0x1410c47a6*/
                v41 = head > tail ? rakPeer->requestedConnectionQueue.allocation_size - head + tail : tail - head;
                if ( v14 >= v41 ) /*0x1410c47c1*/
                  break; /*0x1410c47c1*/
                v42 = head + v14; /*0x1410c47c7*/
                allocation_size = rakPeer->requestedConnectionQueue.allocation_size; /*0x1410c47cb*/
                array = rakPeer->requestedConnectionQueue.array; /*0x1410c47d2*/
                if ( (unsigned int)v42 < allocation_size ) /*0x1410c47dc*/
                  v45 = &array[v42]; /*0x1410c47ea*/
                else
                  v45 = &array[v14] + head - allocation_size; /*0x1410c47e4*/
                v46 = *v45; /*0x1410c47ee*/
                if ( v46->actionToTake == CONNECT /*0x1410c4807*/
                  && RakNet::SystemAddress::operator==(this: &v46->systemAddress, right: systemAddress) != 0 )
                {
                  DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::RemoveAtIndex( /*0x1410c4818*/
                    this: &rakPeer->requestedConnectionQueue,
                    position: v14);
                  RakNet::RakPeer::RequestedConnectionStruct::`scalar deleting destructor'(this: v46, a2: 1); /*0x1410c4825*/
                  RakNet::SimpleMutex::Unlock(lpCriticalSection: &rakPeer->requestedConnectionQueueMutex.criticalSection); /*0x1410c4831*/
                  v47 = RakNet::RakPeer::AllocPacket( /*0x1410c4850*/
                          this: rakPeer,
                          dataSize: 1u,
                          file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                          line: 0x139Eu);
                  *v47->userMemory.data = *data; /*0x1410c4861*/
                  v47->userMemory.bitSize = 8; /*0x1410c4864*/
                  RakNet::SystemAddress::operator=(this: &v47->userMemory.systemAddress, input: systemAddress); /*0x1410c4871*/
                  v47->userMemory.guid = guid; /*0x1410c487b*/
                  RakNet::RakPeer::AddPacketToProducer(this: rakPeer, p: (RakNet::InternalPacket *)v47); /*0x1410c488d*/
                  goto LABEL_140; /*0x1410c4892*/
                }
                ++v14; /*0x1410c4809*/
              }
              RakNet::SimpleMutex::Unlock(lpCriticalSection: &rakPeer->requestedConnectionQueueMutex.criticalSection); /*0x1410c489b*/
            }
            __unwind
            {
              RakNet::BitStream::~BitStream(this: &bs); /*0xf1c0000000000014*/
            }
LABEL_140:
            p_bsIn = &bs; /*0x1410c48a1*/
            goto LABEL_78; /*0x1410c48a8*/
          }
        }
        switch ( (_BYTE)v36 ) /*0x1410c48b0*/
        {
          case 5: /*0x1410c48b0*/
            if ( length <= 17 ) /*0x1410c48b5*/
              goto LABEL_79; /*0x1410c48b5*/
            break;
          case 7: /*0x1410c48b0*/
            break;
          case 0x7B: /*0x1410c48b0*/
            rtc::CriticalSection::Enter(lpCriticalSection: &rakPeer->connectionRequestsStats.mx.criticalSection); /*0x1410c48fe*/
            ++rakPeer->connectionRequestsStats.counters[1]; /*0x1410c4903*/
            RakNet::SimpleMutex::Unlock(lpCriticalSection: &rakPeer->connectionRequestsStats.mx.criticalSection); /*0x1410c4910*/
            if ( v10 >= 0x12 ) /*0x1410c4919*/
            {
              v48 = v10 + ruppLength; /*0x1410c4926*/
              if ( v48 + 40 >= 0x240 ) /*0x1410c4933*/
              {
                if ( data[17] == 5 ) /*0x1410c4944*/
                {
                  RakNet::SystemAddress::ToStringN( /*0x1410c49be*/
                    this: systemAddress,
                    writePort: true,
                    dest: (char *)&bs,
                    size: 1025,
                    portDelineator: 124);
                  if ( FLog::Network != 0 ) /*0x1410c49cc*/
                    FLog::FastLogS( /*0x1410c49dc*/
                      level: FLog::Network,
                      message: "[FLog::Network] Received RbxOpenRequest1 from %s",
                      sarg: (const char *)&bs);
                  v28 = rakNetSocket; /*0x1410c49e1*/
                  RakNet::RakPeer::sendRbxOpenReply1( /*0x1410c49f9*/
                    this: rakPeer,
                    mtu: v48,
                    systemAddress,
                    udmuxAddress: v12,
                    rakNetSocket);
                }
                else
                {
                  if ( DFLog::SessionCrypto != 0 ) /*0x1410c494f*/
                    FLog::FastLog( /*0x1410c495b*/
                      level: DFLog::SessionCrypto,
                      message: "[DFLog::SessionCrypto] RbxOpenRequest1 Incompatible Protocol",
                      arg0: nullptr);
                  v49 = rakPeer->__vftable; /*0x1410c4960*/
                  v59 = RakNet::UNASSIGNED_SYSTEM_ADDRESS_30; /*0x1410c496a*/
                  v50 = v49->GetGuidFromSystemAddress(this: rakPeer, a2: &v59); /*0x1410c4980*/
                  v28 = rakNetSocket; /*0x1410c4989*/
                  RakNet::RakPeer::sendRbxOpenError(this: rakPeer, id: 0x19u, guid: v50, systemAddress, rakNetSocket); /*0x1410c499d*/
                }
                goto LABEL_80; /*0x1410c49a2*/
              }
            }
            if ( DFLog::SessionCrypto != 0 ) /*0x1410c4a0c*/
              FLog::FastLogFormatted( /*0x1410c4a1e*/
                level: DFLog::SessionCrypto,
                message: "[DFLog::SessionCrypto] RbxOpenRequest1 has incorrect size %d.",
                v10);
            break;
          case 0x7E: /*0x1410c48b0*/
            v28 = rakNetSocket; /*0x1410c4a30*/
            RakNet::RakPeer::processRbxOpenReply1( /*0x1410c4a49*/
              this: rakPeer,
              (const unsigned __int8 *)data,
              length,
              systemAddress,
              rakNetSocket);
            goto LABEL_80; /*0x1410c4a4e*/
          case 0x78: /*0x1410c48b0*/
            *(RBX::StringView *)&v59.address.addr6.sin6_family = *gameServiceToken; /*0x1410c4a62*/
            v28 = rakNetSocket; /*0x1410c4a7e*/
            RakNet::RakPeer::processRbxOpenRequest2( /*0x1410c4a9c*/
              this: rakPeer,
              (const unsigned __int8 *)data,
              length,
              systemAddress,
              udmuxAddress: v12,
              rakNetSocket,
              ruppLength,
              gameServiceToken: (RBX::StringView *)&v59);
            goto LABEL_80; /*0x1410c4aa1*/
          case 0x7D: /*0x1410c48b0*/
            v28 = rakNetSocket; /*0x1410c4abe*/
            RakNet::RakPeer::processRbxOpenReply2( /*0x1410c4ad7*/
              this: rakPeer,
              (const unsigned __int8 *)data,
              length,
              systemAddress,
              rakNetSocket,
              timeRead);
            goto LABEL_80; /*0x1410c4adc*/
          default:
LABEL_79:
            v28 = rakNetSocket; /*0x1410c45ff*/
LABEL_80:
            v35 = (volatile signed __int32 *)v28->_Rep; /*0x1410c4606*/
            if ( v35 != nullptr && _InterlockedExchangeAdd(v35 + 2, 0xFFFFFFFF) == 1 ) /*0x1410c461e*/
            {
              (**(void (__fastcall ***)(volatile signed __int32 *))v35)(a1: v35); /*0x1410c462a*/
              if ( _InterlockedExchangeAdd(v35 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c4636*/
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v35 + 8LL))(a1: v35); /*0x1410c4642*/
            }
            return; /*0x1410c4645*/
        }
      }
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)rakNetSocket); /*0x1410c48c2*/
      return; /*0xf1c00000000000ac*/
    }
    v37 = rakNetSocket->_Rep; /*0x1410c4661*/
    if ( v37 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v37->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410c467f*/
    {
      v37->_Destroy(this: v37); /*0x1410c468b*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v37->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c4697*/
        v37->_Delete_this(this: v37); /*0x1410c46a3*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)rakNetSocket); /*0xf1c0000000000008*/
  }
}

// Address: 0x1410c4d00 | Name: ?PushBackPacket@RakPeer@RakNet@@UEAAXPEAUPacket@2@_N@Z
void __fastcall RakNet::RakPeer::PushBackPacket(RakNet::RakPeer *this, RakNet::InternalPacket *packet, bool pushAtHead)
{
  RakNet::SimpleMutex *p_packetReturnMutex; // rbp
  DataStructures::Queue<RakNet::InternalPacket *> *p_packetReturnQueue; // rdi
  unsigned int tail; // edx
  unsigned int head; // ecx
  unsigned int v10; // r11d
  unsigned int v11; // eax
  unsigned int v12; // r11d
  unsigned int i; // ebx
  unsigned int v14; // r9d
  unsigned int allocation_size; // r8d
  unsigned int v16; // edx
  unsigned int v17; // ecx
  __int64 v18; // rdx
  unsigned int v19; // edx
  __int64 v20; // rcx
  RakNet::InternalPacket *input; // [rsp+38h] [rbp+10h] BYREF

  if ( packet != nullptr ) /*0x1410c4d03*/
  {
    input = packet; /*0x1410c4d13*/
    p_packetReturnMutex = &this->packetReturnMutex; /*0x1410c4d25*/
    rtc::CriticalSection::Enter(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410c4d36*/
    p_packetReturnQueue = (DataStructures::Queue<RakNet::InternalPacket *> *)&this->packetReturnQueue; /*0x1410c4d3b*/
    if ( pushAtHead ) /*0x1410c4d53*/
    {
      DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push( /*0x1410c4d5f*/
        this: p_packetReturnQueue,
        &input,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
        line: 0xB9Du);
      tail = p_packetReturnQueue->tail; /*0x1410c4d64*/
      head = p_packetReturnQueue->head; /*0x1410c4d6a*/
      v10 = tail - head; /*0x1410c4d6d*/
      if ( head > tail ) /*0x1410c4d72*/
        v11 = tail + p_packetReturnQueue->allocation_size - head; /*0x1410c4d7e*/
      else
        v11 = p_packetReturnQueue->tail - head; /*0x1410c4d74*/
      if ( v11 != 1 ) /*0x1410c4d83*/
      {
        if ( head > tail ) /*0x1410c4d8b*/
          v10 = tail + p_packetReturnQueue->allocation_size - head; /*0x1410c4d94*/
        v12 = v10 - 1; /*0x1410c4d97*/
        for ( i = v12 - 1; ; --i ) /*0x1410c4d9a*/
        {
          v14 = p_packetReturnQueue->head; /*0x1410c4da0*/
          allocation_size = p_packetReturnQueue->allocation_size; /*0x1410c4da7*/
          v16 = v14 - allocation_size; /*0x1410c4db1*/
          if ( v14 + i < allocation_size ) /*0x1410c4dbf*/
            v16 = p_packetReturnQueue->head; /*0x1410c4dbf*/
          v17 = p_packetReturnQueue->head - allocation_size; /*0x1410c4dc3*/
          v18 = i + v16; /*0x1410c4dc6*/
          if ( v14 + v12 < allocation_size ) /*0x1410c4dcb*/
            v17 = p_packetReturnQueue->head; /*0x1410c4dcb*/
          *((_QWORD *)&p_packetReturnQueue->array[v12] + v17) = p_packetReturnQueue->array[v18]; /*0x1410c4dd6*/
          if ( i == 0 ) /*0x1410c4ddc*/
            break; /*0x1410c4ddc*/
          --v12; /*0x1410c4dde*/
        }
        v19 = p_packetReturnQueue->head; /*0x1410c4de5*/
        v20 = v19 - p_packetReturnQueue->allocation_size; /*0x1410c4dea*/
        if ( v19 < p_packetReturnQueue->allocation_size ) /*0x1410c4df3*/
          v20 = v19; /*0x1410c4df3*/
        p_packetReturnQueue->array[v20] = packet; /*0x1410c4df6*/
      }
    }
    else
    {
      DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push( /*0x1410c4e02*/
        this: p_packetReturnQueue,
        &input,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
        line: 0xB9Fu);
    }
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_packetReturnMutex->criticalSection); /*0x1410c4e0a*/
  }
}

// Address: 0x1410c4e30 | Name: ?QueueTxPacketForDelay@RakPeer@RakNet@@QEAAXPEAUDelayTransmitStruct@2@@Z
void __fastcall RakNet::RakPeer::QueueTxPacketForDelay(
        RakNet::RakPeer *this,
        RakNet::RakPeer::SocketQueryOutput *txPacket)
{
  if ( this->closeTxLatencyQueue._Storage._Value ) /*0x1410c4e30*/
  {
    if ( DFLog::NetworkTrace != 0 ) /*0x1410c4e4e*/
      FLog::FastLog( /*0x1410c4e5a*/
        level: DFLog::NetworkTrace,
        message: "[DFLog::NetworkTrace] Did not add packet to tx delay queue, already shutting down",
        arg0: nullptr);
  }
  else
  {
    DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::BufferedCommandStruct>::Push( /*0x1410c4e40*/
      this: (DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput> *)&this->artificialDelayTransmitPackets,
      s: txPacket);
  }
}

// Address: 0x1410c4e60 | Name: ?Receive_deprecated@RakPeer@RakNet@@UEAAPEAUPacket@2@_N@Z
RakNet::Packet *__fastcall RakNet::RakPeer::Receive_deprecated(RakNet::RakPeer *this, bool debugReport)
{
  unsigned __int8 v4; // cl
  const char *v5; // rdx
  bool v6; // r13
  unsigned __int64 TimeMS; // rdi
  unsigned __int64 Mysize; // rdx
  RakNet::Packet *packet; // rsi
  unsigned int head; // eax
  unsigned int allocation_size; // ecx
  unsigned int v12; // eax
  RakNet::Packet **array; // rsi
  __int64 v14; // rax
  unsigned __int64 v15; // rcx
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker> > > > *Myfirst; // rax
  __int64 v17; // rcx
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *Ptr; // rdi
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *v19; // rbp
  int v20; // eax
  unsigned __int8 v21; // cl
  bool v22; // zf
  bool v23; // bp
  unsigned __int64 v24; // r15
  unsigned int v25; // r12d
  unsigned __int64 v26; // r8
  unsigned __int64 Mapsize; // rdx
  RakNet::RakPeer::DeferredQueueInfo **Map; // rax
  unsigned __int64 v29; // r14
  RakNet::RakPeer::DeferredQueueInfo *v30; // rax
  unsigned __int8 *data; // rdx
  RBX::Network::Peer *peerPlugin; // rcx
  RakNet::PeerReceiveResult v33; // eax
  int stepsFromLastJoinOrDisconnect_deprecated; // eax
  unsigned __int64 v36; // [rsp+60h] [rbp+8h]

  if ( debugReport ) /*0x1410c4e77*/
  {
    if ( DFLog::ClientRecvFromRaknet != 0 ) /*0x1410c4e82*/
      FLog::FastLog( /*0x1410c4e92*/
        level: DFLog::ClientRecvFromRaknet,
        message: "[DFLog::ClientRecvFromRaknet] RakPeer has distributed %d packets to plugins since last debug time",
        arg0: (const void *)this->packetsDistributedToPluginsSinceLastDebug);
    if ( DFFlag::DebugRakPeerReceiveCountDistributedPackets.value ) /*0x1410c4e9e*/
      this->packetsDistributedToPluginsSinceLastDebug = 0; /*0x1410c4ea0*/
  }
  if ( !this->IsActive(this) ) /*0x1410c4ecb*/
  {
    if ( debugReport ) /*0x1410c4ed0*/
    {
      v4 = DFLog::ClientRecvFromRaknet; /*0x1410c4ed6*/
      if ( DFLog::ClientRecvFromRaknet != 0 ) /*0x1410c4edf*/
      {
        v5 = "[DFLog::ClientRecvFromRaknet] RakPeer is NOT active, returning"; /*0x1410c4ee5*/
        goto LABEL_64; /*0x1410c4eec*/
      }
    }
    return nullptr; /*0x1410c4edf*/
  }
  v6 = this->stepsFromLastJoinOrDisconnect_deprecated >= DFInt::StepsToJoin; /*0x1410c4efd*/
  TimeMS = (unsigned int)RakNet::GetTimeMS(); /*0x1410c4f06*/
  v36 = TimeMS; /*0x1410c4f08*/
  while ( 1 ) /*0x1410c4f10*/
  {
    if ( !FFlag::NoJoinDiscoThrottleRakNet3.value && v6 ) /*0x1410c4f1c*/
    {
      Mysize = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize; /*0x1410c4f1e*/
      if ( Mysize != 0 ) /*0x1410c4f28*/
      {
        packet = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Map[this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff /*0x1410c4f4a*/
                                                                                        & (this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mapsize
                                                                                         - 1)]->packet;
        this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize = Mysize - 1; /*0x1410c4f4d*/
        if ( Mysize == 1 ) /*0x1410c4f57*/
          this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff = 0; /*0x1410c4f59*/
        else
          ++this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff; /*0x1410c4f65*/
        goto LABEL_36; /*0x1410c4f60*/
      }
    }
    rtc::CriticalSection::Enter(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410c4f78*/
    head = this->packetReturnQueue.head; /*0x1410c4f7d*/
    if ( head == this->packetReturnQueue.tail ) /*0x1410c4f89*/
      break; /*0x1410c4f89*/
    allocation_size = this->packetReturnQueue.allocation_size; /*0x1410c4f8f*/
    v12 = head + 1; /*0x1410c4f95*/
    array = this->packetReturnQueue.array; /*0x1410c4f97*/
    this->packetReturnQueue.head = v12; /*0x1410c4f9e*/
    if ( v12 == allocation_size ) /*0x1410c4fa6*/
    {
      this->packetReturnQueue.head = 0; /*0x1410c4fa8*/
      v14 = allocation_size - 1; /*0x1410c4faf*/
    }
    else if ( v12 != 0 ) /*0x1410c4fb6*/
    {
      v14 = v12 - 1; /*0x1410c4fbd*/
    }
    else
    {
      v14 = allocation_size - 1; /*0x1410c4fb8*/
    }
    packet = array[v14]; /*0x1410c4fc6*/
    if ( DFFlag::CLI56775.value ) /*0x1410c4fca*/
    {
      v15 = RakNet::SystemAddress::ToInteger(sa: &packet->systemAddress) & this->bytesInReturnQueue._Mask; /*0x1410c4fe1*/
      Myfirst = this->bytesInReturnQueue._Vec._Mypair._Myval2._Myfirst; /*0x1410c4fe4*/
      v17 = 2 * v15; /*0x1410c4feb*/
      Ptr = Myfirst[v17 + 1]._Ptr; /*0x1410c4fee*/
      if ( Ptr != this->bytesInReturnQueue._List._Mypair._Myval2._Myhead ) /*0x1410c4ffa*/
      {
        v19 = Myfirst[v17]._Ptr; /*0x1410c4ffc*/
        if ( RakNet::SystemAddress::operator==(this: &packet->systemAddress, right: &Ptr->_Myval.first) != 0 ) /*0x1410c500e*/
        {
LABEL_28:
          if ( Ptr != nullptr && Ptr != this->bytesInReturnQueue._List._Mypair._Myval2._Myhead ) /*0x1410c5035*/
          {
            v20 = 0; /*0x1410c503a*/
            if ( (signed int)(Ptr->_Myval.second.bytes - packet->length) > 0 ) /*0x1410c5042*/
              v20 = Ptr->_Myval.second.bytes - packet->length; /*0x1410c5042*/
            Ptr->_Myval.second.bytes = v20; /*0x1410c5045*/
          }
        }
        else
        {
          while ( Ptr != v19 ) /*0x1410c5013*/
          {
            Ptr = Ptr->_Prev; /*0x1410c5015*/
            if ( RakNet::SystemAddress::operator==(this: &packet->systemAddress, right: &Ptr->_Myval.first) != 0 ) /*0x1410c5027*/
              goto LABEL_28; /*0x1410c5027*/
          }
        }
      }
      TimeMS = v36; /*0x1410c5048*/
    }
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410c5054*/
    if ( packet == nullptr ) /*0x1410c505c*/
      goto LABEL_58; /*0x1410c505c*/
    packet->timePopped = TimeMS; /*0x1410c5062*/
LABEL_36:
    if ( FFlag::NoJoinDiscoThrottleRakNet3.value ) /*0x1410c506d*/
      goto LABEL_47; /*0x1410c506d*/
    v21 = *packet->data; /*0x1410c5077*/
    v22 = v21 == 0x90; /*0x1410c507a*/
    if ( v21 == 0x90 ) /*0x1410c507d*/
      goto LABEL_40; /*0x1410c507d*/
    if ( (unsigned __int8)(v21 - 21) > 1u ) /*0x1410c5084*/
    {
LABEL_47:
      if ( packet->length >= 9 ) /*0x1410c5144*/
      {
        data = packet->data; /*0x1410c5146*/
        if ( *data == 27 ) /*0x1410c514d*/
          RakNet::RakPeer::ShiftIncomingTimestamp(this, data: data + 1, systemAddress: &packet->systemAddress); /*0x1410c5158*/
      }
      if ( DFFlag::DebugRakPeerReceiveCountDistributedPackets.value ) /*0x1410c5164*/
        ++this->packetsDistributedToPluginsSinceLastDebug; /*0x1410c5166*/
      peerPlugin = this->peerPlugin; /*0x1410c516d*/
      if ( peerPlugin == nullptr ) /*0x1410c5177*/
        return packet; /*0x1410c51a9*/
      v33 = peerPlugin->OnReceive(this: peerPlugin, a2: packet); /*0x1410c517f*/
      if ( v33 != RR_STOP_PROCESSING_AND_DEALLOCATE ) /*0x1410c5187*/
      {
        if ( v33 != RR_STOP_PROCESSING ) /*0x1410c51a0*/
          return packet; /*0x1410c51a0*/
      }
      else
      {
        this->DeallocatePacket(this, a2: packet); /*0x1410c5192*/
      }
    }
    else
    {
      v22 = v21 == 0x90; /*0x1410c508a*/
LABEL_40:
      v23 = v22; /*0x1410c508d*/
      if ( v6 ) /*0x1410c5094*/
      {
        this->stepsFromLastJoinOrDisconnect_deprecated = 0; /*0x1410c5139*/
        goto LABEL_47; /*0x1410c5139*/
      }
      v24 = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize; /*0x1410c509a*/
      v25 = RakNet::GetTimeMS(); /*0x1410c50ad*/
      v26 = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize; /*0x1410c50b0*/
      Mapsize = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mapsize; /*0x1410c50b4*/
      if ( Mapsize <= v26 + 1 ) /*0x1410c50bf*/
      {
        std::deque<RBX::json::Document>::_Growmap( /*0x1410c50c9*/
          this: (std::deque<webrtc::EncoderOvershootDetector::BitrateUpdate> *)&this->deferredJoinAndDisconnectTickets_deprecated,
          _Count: 1u);
        Mapsize = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mapsize; /*0x1410c50ce*/
        v26 = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize; /*0x1410c50d2*/
      }
      this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff &= Mapsize - 1; /*0x1410c50da*/
      Map = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Map; /*0x1410c50ec*/
      v29 = (Mapsize - 1) & (v26 + this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff); /*0x1410c50f5*/
      if ( Map[v29] == nullptr ) /*0x1410c50fd*/
      {
        this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Map[v29] = (RakNet::RakPeer::DeferredQueueInfo *)operator new(size: 0x18u); /*0x1410c510d*/
        Map = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Map; /*0x1410c5111*/
      }
      v30 = Map[v29]; /*0x1410c5115*/
      v30->queueLengthAtDefer = v24; /*0x1410c5119*/
      v30->packet = packet; /*0x1410c511d*/
      v30->timeQueued = v25; /*0x1410c5120*/
      v30->isJoin = v23; /*0x1410c5124*/
      ++this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize; /*0x1410c5128*/
      TimeMS = v36; /*0x1410c512c*/
    }
  }
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410c51b2*/
LABEL_58:
  if ( !FFlag::NoJoinDiscoThrottleRakNet3.value ) /*0x1410c51be*/
  {
    stepsFromLastJoinOrDisconnect_deprecated = this->stepsFromLastJoinOrDisconnect_deprecated; /*0x1410c51c0*/
    if ( stepsFromLastJoinOrDisconnect_deprecated < DFInt::StepsToJoin ) /*0x1410c51cc*/
      this->stepsFromLastJoinOrDisconnect_deprecated = stepsFromLastJoinOrDisconnect_deprecated + 1; /*0x1410c51d0*/
  }
  if ( debugReport ) /*0x1410c51db*/
  {
    v4 = DFLog::ClientRecvFromRaknet; /*0x1410c51dd*/
    if ( DFLog::ClientRecvFromRaknet != 0 ) /*0x1410c51e6*/
    {
      v5 = "[DFLog::ClientRecvFromRaknet] PacketReturnQueue is empty, no work to do"; /*0x1410c51e8*/
LABEL_64:
      FLog::FastLog(level: v4, message: v5, arg0: nullptr); /*0x1410c51ef*/
    }
  }
  return nullptr; /*0x1410c51f9*/
}

// Address: 0x1410c55e0 | Name: ?ReferenceRemoteSystem@RakPeer@RakNet@@IEAAXAEBUSystemAddress@2@I@Z
void __fastcall RakNet::RakPeer::ReferenceRemoteSystem(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *sa,
        unsigned int remoteSystemListIndex)
{
  __int64 v5; // r14
  RakNet::RemoteSystemIndex *v7; // rbx
  RakNet::RakPeer::RemoteSystemStruct *remoteSystemList; // rdx
  RakNet::RakPeer::RemoteSystemStruct *v9; // rcx
  __int64 v10; // rbx
  RakNet::RemoteSystemIndex *v11; // rax
  __int64 v12; // rdx
  RakNet::RemoteSystemIndex *v13; // rbx
  __int64 index; // rax
  RakNet::RemoteSystemIndex *i; // rax
  DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::MemoryWithPage *v16; // rax
  RakNet::SystemAddress oldAddress; // [rsp+20h] [rbp-28h] BYREF

  v5 = remoteSystemListIndex; /*0x1410c560e*/
  oldAddress = this->remoteSystemList[v5].systemAddress; /*0x1410c5623*/
  if ( RakNet::SystemAddress::operator!=(this: &oldAddress, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410c563a*/
  {
    v7 = this->remoteSystemLookup[RakNet::SystemAddress::ToInteger(sa: &oldAddress) /*0x1410c5658*/
                                % (8 * (unsigned int)this->maximumNumberOfPeers)];
    if ( v7 == nullptr ) /*0x1410c565f*/
      goto LABEL_5; /*0x1410c565f*/
    while ( RakNet::SystemAddress::operator==( /*0x1410c5684*/
              this: &this->remoteSystemList[v7->index].systemAddress,
              right: &oldAddress) == 0 )
    {
      v7 = v7->next; /*0x1410c568a*/
      if ( v7 == nullptr ) /*0x1410c5691*/
        goto LABEL_5; /*0x1410c5691*/
    }
    index = v7->index; /*0x1410c572c*/
    if ( (_DWORD)index == -1 ) /*0x1410c5731*/
    {
LABEL_5:
      remoteSystemList = this->remoteSystemList; /*0x1410c5693*/
      v9 = nullptr; /*0x1410c569a*/
    }
    else
    {
      remoteSystemList = this->remoteSystemList; /*0x1410c5737*/
      v9 = &remoteSystemList[index]; /*0x1410c5745*/
    }
    if ( v9 == &remoteSystemList[v5] ) /*0x1410c56a3*/
      RakNet::RakPeer::DereferenceRemoteSystem(this, sa: &oldAddress); /*0x1410c56ad*/
  }
  RakNet::RakPeer::DereferenceRemoteSystem(this, sa); /*0x1410c56b8*/
  RakNet::SystemAddress::operator=(this: &this->remoteSystemList[v5].systemAddress, input: sa); /*0x1410c56ce*/
  v10 = RakNet::SystemAddress::ToInteger(sa) % (8 * (unsigned int)this->maximumNumberOfPeers); /*0x1410c56f3*/
  v11 = (RakNet::RemoteSystemIndex *)DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Allocate( /*0x1410c56fc*/
                                       this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->remoteSystemIndexPool,
                                       file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                                       line: 0xFAEu);
  v12 = v10; /*0x1410c5708*/
  v13 = this->remoteSystemLookup[v10]; /*0x1410c5710*/
  if ( v13 != nullptr ) /*0x1410c5717*/
  {
    for ( i = v13->next; i != nullptr; i = i->next ) /*0x1410c5754*/
      v13 = i; /*0x1410c5760*/
    v16 = DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Allocate( /*0x1410c5780*/
            this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->remoteSystemIndexPool,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
            line: 0xFBDu);
    v16->userMemory.next = nullptr; /*0x1410c5785*/
    v16->userMemory.messageNumber.val = remoteSystemListIndex; /*0x1410c578d*/
    v13->next = (RakNet::RemoteSystemIndex *)v16; /*0x1410c578f*/
  }
  else
  {
    v11->next = nullptr; /*0x1410c5719*/
    v11->index = remoteSystemListIndex; /*0x1410c571d*/
    this->remoteSystemLookup[v12] = v11; /*0x1410c5726*/
  }
}

// Address: 0x1410c5c30 | Name: ?ReleaseSockets@RakPeer@RakNet@@UEAAXAEAV?$List@V?$shared_ptr@URakNetSocket@RakNet@@@std@@@DataStructures@@@Z
void __fastcall RakNet::RakPeer::ReleaseSockets(
        RakNet::RakPeer *this,
        DataStructures::List<std::shared_ptr<RakNet::RakNetSocket> > *sockets)
{
  std::shared_ptr<RakNet::RakNetSocket> *listArray; // rcx
  std::_Ref_count_base **p_Rep; // rbx
  __int64 v5; // [rsp+0h] [rbp-28h] BYREF

  if ( sockets->allocation_size != 0 ) /*0x1410c5c41*/
  {
    __wind /*0xf1c0000000000020*/
    {
      listArray = sockets->listArray; /*0x1410c5c43*/
      if ( sockets->listArray != nullptr ) /*0x1410c5c49*/
      {
        p_Rep = &listArray[-1]._Rep; /*0x1410c5c4b*/
        `eh vector destructor iterator'( /*0x1410c5c5e*/
          ptr: listArray,
          size: 0x10u,
          count: (unsigned __int64)listArray[-1]._Rep,
          destructor: (void (__fastcall *)(void *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>);
        operator delete(ptr: p_Rep); /*0x1410c5c71*/
      }
      *(_QWORD *)&sockets->list_size = 0; /*0x1410c5c79*/
      sockets->listArray = nullptr; /*0x1410c5c7d*/
    }
    __unwind
    {
      __std_terminate(a1: listArray, a2: &v5); /*0x142f39fa8*/
    }
  }
}

// Address: 0x1410c5d20 | Name: ?RemoveFromSecurityExceptionList@RakPeer@RakNet@@UEAAXPEBD@Z
void __fastcall RakNet::RakPeer::RemoveFromSecurityExceptionList(RakNet::RakPeer *this, const char *ip)
{
  RakNet::SimpleMutex *p_securityExceptionMutex; // rcx
  RakNet::RakString *listArray; // rcx
  RakNet::RakString *v6; // rdi
  unsigned int v7; // esi
  __int64 v8; // rdi
  unsigned int v9; // r8d
  unsigned int list_size; // ecx
  __int64 v11; // rdi
  __int64 v12; // [rsp+0h] [rbp-28h] BYREF

  if ( this->securityExceptionList.list_size != 0 ) /*0x1410c5d47*/
  {
    p_securityExceptionMutex = &this->securityExceptionMutex; /*0x1410c5d4d*/
    if ( ip != nullptr ) /*0x1410c5d57*/
    {
      v7 = 0; /*0x1410c5db5*/
      rtc::CriticalSection::Enter(lpCriticalSection: &p_securityExceptionMutex->criticalSection); /*0x1410c5db7*/
      if ( this->securityExceptionList.list_size != 0 ) /*0x1410c5dc2*/
      {
        do /*0x1410c5e6e*/
        {
          v8 = v7; /*0x1410c5dd2*/
          if ( RakNet::RakString::IPAddressMatch(this: &this->securityExceptionList.listArray[v8], IP: ip) ) /*0x1410c5de7*/
          {
            RakNet::RakString::operator=( /*0x1410c5e06*/
              this: &this->securityExceptionList.listArray[v8],
              rhs: &this->securityExceptionList.listArray[this->securityExceptionList.list_size - 1]);
            v9 = this->securityExceptionList.list_size - 1; /*0x1410c5e12*/
            list_size = this->securityExceptionList.list_size; /*0x1410c5e15*/
            if ( v9 < list_size ) /*0x1410c5e1e*/
            {
              if ( v9 < list_size - 1 ) /*0x1410c5e26*/
              {
                do /*0x1410c5e59*/
                {
                  v11 = v9 + 1; /*0x1410c5e30*/
                  RakNet::RakString::operator=( /*0x1410c5e46*/
                    this: &this->securityExceptionList.listArray[v9],
                    rhs: &this->securityExceptionList.listArray[v11]);
                  v9 = v11; /*0x1410c5e4b*/
                  list_size = this->securityExceptionList.list_size; /*0x1410c5e4e*/
                }
                while ( (unsigned int)v11 < list_size - 1 ); /*0x1410c5e59*/
              }
              this->securityExceptionList.list_size = list_size - 1; /*0x1410c5e5e*/
            }
          }
          else
          {
            ++v7; /*0x1410c5e66*/
          }
        }
        while ( v7 < this->securityExceptionList.list_size ); /*0x1410c5e6e*/
      }
    }
    else
    {
      rtc::CriticalSection::Enter(lpCriticalSection: &p_securityExceptionMutex->criticalSection); /*0x1410c5d59*/
      if ( this->securityExceptionList.allocation_size != (_DWORD)ip ) /*0x1410c5d64*/
      {
        __wind /*0xf1c0000000000020*/
        {
          listArray = this->securityExceptionList.listArray; /*0x1410c5d6a*/
          if ( listArray != nullptr ) /*0x1410c5d74*/
          {
            v6 = listArray - 1; /*0x1410c5d76*/
            `eh vector destructor iterator'( /*0x1410c5d87*/
              ptr: listArray,
              size: (unsigned int)((_DWORD)ip + 8),
              count: (unsigned __int64)listArray[-1].sharedString,
              destructor: (void (__fastcall *)(void *))RakNet::RakString::~RakString);
            operator delete(ptr: v6); /*0x1410c5d9a*/
          }
          *(_QWORD *)&this->securityExceptionList.list_size = 0; /*0x1410c5da2*/
          this->securityExceptionList.listArray = nullptr; /*0x1410c5da9*/
        }
        __unwind
        {
          __std_terminate(a1: listArray, a2: &v12); /*0x142f39fa8*/
        }
      }
    }
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->securityExceptionMutex.criticalSection); /*0x1410c5e7b*/
  }
}

// Address: 0x1410c6580 | Name: ?ReportRakNetHandshakeStats@RakPeer@RakNet@@UEAAX_N@Z
void __fastcall RakNet::RakPeer::ReportRakNetHandshakeStats(RakNet::RakPeer *this, bool blocking)
{
  RakNet::RakPeer::ConnectionRequestsStats::Report(this: &this->connectionRequestsStats, blocking); /*0x1410c6587*/
}

// Address: 0x1410c6590 | Name: ?ReportRakNetLatencyMeasurementStats@RakPeer@RakNet@@IEAAX_K@Z
void __fastcall RakNet::RakPeer::ReportRakNetLatencyMeasurementStats(RakNet::RakPeer *this, unsigned __int64 timeMS)
{
  __int64 lastReportTime; // rax
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // rax
  int v6; // eax
  int v7; // eax
  signed __int64 txQueueExcessDelay; // rcx
  double v9; // xmm2_8
  unsigned __int64 v10; // rax
  signed __int64 rxQueueExcessDelay; // rcx
  double v12; // xmm2_8
  unsigned __int64 v13; // rax
  std::pair<std::string,double> *v14; // rax
  long double second; // rcx
  int peakTxQueueSize; // edi
  std::pair<std::string,double> *Mylast; // rdx
  unsigned __int64 Myres; // rax
  char *Ptr; // rcx
  int peakRxQueueSize; // edi
  std::pair<std::string,double> *v21; // rdx
  unsigned __int64 v22; // rax
  char *v23; // rcx
  signed __int64 txQueueMaxDelay; // rdi
  double v25; // xmm2_8
  unsigned __int64 v26; // rax
  std::pair<std::string,double> *v27; // rdx
  unsigned __int64 v28; // rax
  char *v29; // rcx
  signed __int64 rxQueueMaxDelay; // rbx
  double v31; // xmm2_8
  unsigned __int64 v32; // rax
  std::pair<std::string,double> *v33; // rdx
  unsigned __int64 v34; // rax
  char *v35; // rcx
  std::pair<std::string,double> *Myfirst; // rbx
  std::pair<std::string,double> *v37; // rdi
  unsigned __int64 v38; // rdx
  char *v39; // rcx
  std::pair<std::string,double> *v40; // rax
  std::vector<std::pair<std::string,double>> stat; // [rsp+20h] [rbp-E0h] BYREF
  unsigned __int64 v42; // [rsp+38h] [rbp-C8h]
  std::pair<std::string,double> v43; // [rsp+40h] [rbp-C0h] BYREF
  std::pair<std::string,double> v44; // [rsp+68h] [rbp-98h] BYREF
  std::pair<std::string,double> v45; // [rsp+90h] [rbp-70h] BYREF
  std::pair<std::string,double> v46; // [rsp+B8h] [rbp-48h] BYREF
  RBX::Analytics::InfluxDb::Points v47; // [rsp+E0h] [rbp-20h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+150h] [rbp+50h] BYREF

  lastReportTime = this->artificialLatencyStats.lastReportTime; /*0x1410c65b2*/
  if ( (_DWORD)lastReportTime != 0 ) /*0x1410c65bc*/
  {
    if ( timeMS - lastReportTime >= DFInt::CLI52064ReportIntervalMS ) /*0x1410c65d9*/
    {
      this->artificialLatencyStats.lastReportTime = timeMS; /*0x1410c65df*/
      RBX::Analytics::InfluxDb::Points::Points( /*0x1410c65f3*/
        this: &points,
        throttleHundredthsPercentage: -1,
        categoryType: kStandardType,
        priorityHundredthsPercentage: 0);
      __wind /*0xf1c00000000000b8*/
      {
        if ( RBX::Analytics::InfluxDb::canSend(throttleHundredthsPercentage: DFInt::CLI52064InfluxHundredthsPercentage) ) /*0x1410c65ff*/
        {
          RBX::Analytics::InfluxDb::Points::Points( /*0x1410c661c*/
            this: &v47,
            throttleHundredthsPercentage: DFInt::CLI52064InfluxHundredthsPercentage,
            categoryType: kStandardType,
            priorityHundredthsPercentage: 0);
          __wind /*0xf1c00000000000a0*/
          {
            v4 = this->GetArtificialLatencyTx(this); /*0x1410c6628*/
            RBX::Analytics::InfluxDb::Points::addPoint(this: &v47, name: "AddedTxMs", value: v4 / 0x3E8); /*0x1410c6659*/
            v5 = this->GetArtificialLatencyRx(this); /*0x1410c6664*/
            RBX::Analytics::InfluxDb::Points::addPoint(this: &v47, name: "AddedRxMs", value: v5 / 0x3E8); /*0x1410c668b*/
            v6 = DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Size(this: (DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::RecvFromStruct> *)&this->artificialDelayTransmitPackets); /*0x1410c6697*/
            RBX::Analytics::InfluxDb::Points::addPoint(this: &v47, name: "TxQueueSize", value: v6); /*0x1410c66aa*/
            v7 = DataStructures::ThreadsafeAllocatingQueue<RakNet::DelayTransmitStruct>::Size(this: &this->artificialDelayBufferedPackets); /*0x1410c66b6*/
            RBX::Analytics::InfluxDb::Points::addPoint(this: &v47, name: "RxQueueSize", value: v7); /*0x1410c66c9*/
            txQueueExcessDelay = this->artificialLatencyStats.txQueueExcessDelay; /*0x1410c66ce*/
            if ( txQueueExcessDelay < 0 ) /*0x1410c66db*/
            {
              v10 = this->artificialLatencyStats.txQueueExcessDelay & 1 | ((unsigned __int64)txQueueExcessDelay >> 1); /*0x1410c66ed*/
              v9 = (double)(int)v10 + (double)(int)v10; /*0x1410c66f5*/
            }
            else
            {
              v9 = (double)(int)txQueueExcessDelay; /*0x1410c66dd*/
            }
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c6716*/
              this: &v47,
              name: "AvgExcessTxDelayUs",
              value: v9 / (double)(int)this->artificialLatencyStats.txDelayedPackets);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c672d*/
              this: &v47,
              name: "MaxExcessTxDelayUs",
              value: this->artificialLatencyStats.txQueueMaxDelay);
            rxQueueExcessDelay = this->artificialLatencyStats.rxQueueExcessDelay; /*0x1410c6732*/
            if ( rxQueueExcessDelay < 0 ) /*0x1410c673f*/
            {
              v13 = this->artificialLatencyStats.rxQueueExcessDelay & 1 | ((unsigned __int64)rxQueueExcessDelay >> 1); /*0x1410c6751*/
              v12 = (double)(int)v13 + (double)(int)v13; /*0x1410c6759*/
            }
            else
            {
              v12 = (double)(int)rxQueueExcessDelay; /*0x1410c6741*/
            }
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c677a*/
              this: &v47,
              name: "AvgExcessRxDelayUs",
              value: v12 / (double)(int)this->artificialLatencyStats.rxDelayedPackets);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c6791*/
              this: &v47,
              name: "MaxExcessRxDelayUs",
              value: this->artificialLatencyStats.rxQueueMaxDelay);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c67a8*/
              this: &v47,
              name: "PeakTxQueueSize",
              value: this->artificialLatencyStats.peakTxQueueSize);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c67bf*/
              this: &v47,
              name: "PeakRxQueueSize",
              value: this->artificialLatencyStats.peakRxQueueSize);
            v14 = (std::pair<std::string,double> *)operator new(size: 0x20u); /*0x1410c67e1*/
            stat._Mypair._Myval2._Myend = (std::pair<std::string,double> *)23; /*0x1410c67e6*/
            v42 = 31; /*0x1410c67ef*/
            qmemcpy(v14, "RaknetArtificialLatenc", 22); /*0x1410c67ff*/
            HIWORD(v14->first._Mypair._Myval2._Mysize) = (unsigned __int8)aRaknetartifici[22]; /*0x1410c681d*/
            stat._Mypair._Myval2._Myfirst = v14; /*0x1410c6824*/
            __wind /*0xf1c0000000000094*/
            {
              RBX::Analytics::InfluxDb::Points::report( /*0x1410c683b*/
                this: &v47,
                resource: (const std::string *)&stat,
                throttleHundredthsPercentage: 10000,
                blocking: false);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&stat); /*0xf1c000000000008c*/
            }
            if ( v42 >= 0x10 ) /*0x1410c684a*/
            {
              second = *(double *)&stat._Mypair._Myval2._Myfirst; /*0x1410c684f*/
              if ( v42 + 1 >= 0x1000 ) /*0x1410c685e*/
              {
                second = stat._Mypair._Myval2._Myfirst[-1].second; /*0x1410c6864*/
                if ( (unsigned __int64)stat._Mypair._Myval2._Myfirst - *(_QWORD *)&second - 8 > 0x1F ) /*0x1410c6873*/
                  _invalid_parameter_noinfo_noreturn(); /*0x1410c6875*/
              }
              operator delete(ptr: *(void **)&second); /*0x1410c687c*/
            }
            RBX::Analytics::InfluxDb::Points::~Points(this: &v47); /*0x1410c6886*/
          }
          __unwind
          {
            RBX::Analytics::InfluxDb::Points::~Points(this: &v47); /*0xf1c00000000000b0*/
          }
        }
      }
      __unwind
      {
        RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c0000000000080*/
      }
      this->artificialLatencyStats.txQueueExcessDelay = 0; /*0x1410c688b*/
      this->artificialLatencyStats.txDelayedPackets = 0; /*0x1410c6892*/
      this->artificialLatencyStats.rxQueueExcessDelay = 0; /*0x1410c6898*/
      this->artificialLatencyStats.rxDelayedPackets = 0; /*0x1410c689f*/
      RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0x1410c68a9*/
    }
  }
  else
  {
    this->artificialLatencyStats.lastReportTime = timeMS; /*0x1410c65be*/
  }
  __wind /*0xf1c0000000000070*/
  {
    if ( !this->endThreads._Storage._Value ) /*0x1410c68b5*/
      return; /*0x1410c68b5*/
    memset(&stat, 0, sizeof(stat)); /*0x1410c68be*/
    peakTxQueueSize = this->artificialLatencyStats.peakTxQueueSize; /*0x1410c68c9*/
    if ( peakTxQueueSize != 0 ) /*0x1410c68d1*/
    {
      v43.first._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410c68d7*/
      *(__m128i *)&v43.first._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x1410c68e4*/
      std::string::assign(this: &v43.first, _Ptr: "RakNetLatencyPeakTxQueue", _Count: 0x18u); /*0x1410c6901*/
      v43.second = (double)peakTxQueueSize; /*0x1410c690e*/
      Mylast = stat._Mypair._Myval2._Mylast; /*0x1410c6914*/
      if ( stat._Mypair._Myval2._Mylast == stat._Mypair._Myval2._Myend ) /*0x1410c691e*/
      {
        __wind /*0xf1c0000000000064*/
        {
          std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x1410c6952*/
            this: &stat,
            _Whereptr: stat._Mypair._Myval2._Mylast,
            <_Val_0>: &v43);
          Myres = v43.first._Mypair._Myval2._Myres; /*0x1410c6957*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v43); /*0xf1c000000000005c*/
        }
      }
      else
      {
        stat._Mypair._Myval2._Mylast->first._Mypair._Myval2._Bx = v43.first._Mypair._Myval2._Bx; /*0x1410c6925*/
        *(_OWORD *)&Mylast->first._Mypair._Myval2._Mysize = *(_OWORD *)&v43.first._Mypair._Myval2._Mysize; /*0x1410c692d*/
        Myres = 15; /*0x1410c6931*/
        v43.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410c6936*/
        Mylast->second = (double)peakTxQueueSize; /*0x1410c693b*/
        ++stat._Mypair._Myval2._Mylast; /*0x1410c6940*/
      }
      if ( Myres >= 0x10 ) /*0x1410c6960*/
      {
        Ptr = v43.first._Mypair._Myval2._Bx._Ptr; /*0x1410c6966*/
        if ( Myres + 1 >= 0x1000 ) /*0x1410c6975*/
        {
          Ptr = *((char **)v43.first._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c697b*/
          if ( (unsigned __int64)(v43.first._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410c698a*/
            goto LABEL_55; /*0x1410c698a*/
        }
        operator delete(ptr: Ptr); /*0x1410c6990*/
      }
    }
    peakRxQueueSize = this->artificialLatencyStats.peakRxQueueSize; /*0x1410c6995*/
    if ( peakRxQueueSize != 0 ) /*0x1410c699d*/
    {
      v44.first._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410c69a3*/
      *(__m128i *)&v44.first._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x1410c69b0*/
      std::string::assign(this: &v44.first, _Ptr: "RakNetLatencyPeakRxQueue", _Count: 0x18u); /*0x1410c69cd*/
      v44.second = (double)peakRxQueueSize; /*0x1410c69da*/
      v21 = stat._Mypair._Myval2._Mylast; /*0x1410c69df*/
      if ( stat._Mypair._Myval2._Mylast == stat._Mypair._Myval2._Myend ) /*0x1410c69e9*/
      {
        __wind /*0xf1c000000000004c*/
        {
          std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x1410c6a1d*/
            this: &stat,
            _Whereptr: stat._Mypair._Myval2._Mylast,
            <_Val_0>: &v44);
          v22 = v44.first._Mypair._Myval2._Myres; /*0x1410c6a22*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v44); /*0xf1c0000000000044*/
        }
      }
      else
      {
        stat._Mypair._Myval2._Mylast->first._Mypair._Myval2._Bx = v44.first._Mypair._Myval2._Bx; /*0x1410c69f0*/
        *(_OWORD *)&v21->first._Mypair._Myval2._Mysize = *(_OWORD *)&v44.first._Mypair._Myval2._Mysize; /*0x1410c69f8*/
        v22 = 15; /*0x1410c69fc*/
        v44.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410c6a01*/
        v21->second = (double)peakRxQueueSize; /*0x1410c6a06*/
        ++stat._Mypair._Myval2._Mylast; /*0x1410c6a0b*/
      }
      if ( v22 >= 0x10 ) /*0x1410c6a2a*/
      {
        v23 = v44.first._Mypair._Myval2._Bx._Ptr; /*0x1410c6a30*/
        if ( v22 + 1 >= 0x1000 ) /*0x1410c6a3f*/
        {
          v23 = *((char **)v44.first._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c6a45*/
          if ( (unsigned __int64)(v44.first._Mypair._Myval2._Bx._Ptr - v23 - 8) > 0x1F ) /*0x1410c6a54*/
            goto LABEL_55; /*0x1410c6a54*/
        }
        operator delete(ptr: v23); /*0x1410c6a5a*/
      }
    }
    txQueueMaxDelay = this->artificialLatencyStats.txQueueMaxDelay; /*0x1410c6a5f*/
    if ( txQueueMaxDelay == 0 ) /*0x1410c6a69*/
      goto LABEL_46; /*0x1410c6a69*/
    v45.first._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410c6a6f*/
    *(__m128i *)&v45.first._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x1410c6a7b*/
    std::string::assign(this: &v45.first, _Ptr: "RakNetLatencyPeakTxDelay", _Count: 0x18u); /*0x1410c6a95*/
    if ( txQueueMaxDelay < 0 ) /*0x1410c6aa0*/
    {
      v26 = txQueueMaxDelay & 1 | ((unsigned __int64)txQueueMaxDelay >> 1); /*0x1410c6ab2*/
      v25 = (double)(int)v26 + (double)(int)v26; /*0x1410c6aba*/
    }
    else
    {
      v25 = (double)(int)txQueueMaxDelay; /*0x1410c6aa2*/
    }
    v45.second = v25; /*0x1410c6abe*/
    v27 = stat._Mypair._Myval2._Mylast; /*0x1410c6ac3*/
    if ( stat._Mypair._Myval2._Mylast == stat._Mypair._Myval2._Myend ) /*0x1410c6acd*/
    {
      __wind /*0xf1c0000000000034*/
      {
        std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x1410c6afd*/
          this: &stat,
          _Whereptr: stat._Mypair._Myval2._Mylast,
          <_Val_0>: &v45);
        v28 = v45.first._Mypair._Myval2._Myres; /*0x1410c6b02*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v45); /*0xf1c000000000002c*/
      }
    }
    else
    {
      stat._Mypair._Myval2._Mylast->first._Mypair._Myval2._Bx = v45.first._Mypair._Myval2._Bx; /*0x1410c6ad3*/
      *(_OWORD *)&v27->first._Mypair._Myval2._Mysize = *(_OWORD *)&v45.first._Mypair._Myval2._Mysize; /*0x1410c6ada*/
      v28 = 15; /*0x1410c6ade*/
      v45.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410c6ae3*/
      v27->second = v25; /*0x1410c6ae7*/
      ++stat._Mypair._Myval2._Mylast; /*0x1410c6aec*/
    }
    if ( v28 < 0x10 ) /*0x1410c6b0a*/
      goto LABEL_46; /*0x1410c6b0a*/
    v29 = v45.first._Mypair._Myval2._Bx._Ptr; /*0x1410c6b10*/
    if ( v28 + 1 < 0x1000 /*0x1410c6b33*/
      || (v29 = *((char **)v45.first._Mypair._Myval2._Bx._Ptr - 1),
          (unsigned __int64)(v45.first._Mypair._Myval2._Bx._Ptr - v29 - 8) <= 0x1F) )
    {
      operator delete(ptr: v29); /*0x1410c6b39*/
LABEL_46:
      rxQueueMaxDelay = this->artificialLatencyStats.rxQueueMaxDelay; /*0x1410c6b3e*/
      if ( rxQueueMaxDelay != 0 ) /*0x1410c6b48*/
      {
        v46.first._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410c6b4e*/
        *(__m128i *)&v46.first._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x1410c6b5a*/
        std::string::assign(this: &v46.first, _Ptr: "RakNetLatencyPeakRxDelay", _Count: 0x18u); /*0x1410c6b74*/
        if ( rxQueueMaxDelay < 0 ) /*0x1410c6b7f*/
        {
          v32 = rxQueueMaxDelay & 1 | ((unsigned __int64)rxQueueMaxDelay >> 1); /*0x1410c6b91*/
          v31 = (double)(int)v32 + (double)(int)v32; /*0x1410c6b99*/
        }
        else
        {
          v31 = (double)(int)rxQueueMaxDelay; /*0x1410c6b81*/
        }
        v46.second = v31; /*0x1410c6b9d*/
        v33 = stat._Mypair._Myval2._Mylast; /*0x1410c6ba2*/
        if ( stat._Mypair._Myval2._Mylast == stat._Mypair._Myval2._Myend ) /*0x1410c6bac*/
        {
          __wind /*0xf1c000000000001c*/
          {
            std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x1410c6bdc*/
              this: &stat,
              _Whereptr: stat._Mypair._Myval2._Mylast,
              <_Val_0>: &v46);
            v34 = v46.first._Mypair._Myval2._Myres; /*0x1410c6be1*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v46); /*0xf1c0000000000014*/
          }
        }
        else
        {
          stat._Mypair._Myval2._Mylast->first._Mypair._Myval2._Bx = v46.first._Mypair._Myval2._Bx; /*0x1410c6bb2*/
          *(_OWORD *)&v33->first._Mypair._Myval2._Mysize = *(_OWORD *)&v46.first._Mypair._Myval2._Mysize; /*0x1410c6bb9*/
          v34 = 15; /*0x1410c6bbd*/
          v46.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410c6bc2*/
          v33->second = v31; /*0x1410c6bc6*/
          ++stat._Mypair._Myval2._Mylast; /*0x1410c6bcb*/
        }
        if ( v34 >= 0x10 ) /*0x1410c6be9*/
        {
          v35 = v46.first._Mypair._Myval2._Bx._Ptr; /*0x1410c6bef*/
          if ( v34 + 1 >= 0x1000 ) /*0x1410c6bfd*/
          {
            v35 = *((char **)v46.first._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c6c03*/
            if ( (unsigned __int64)(v46.first._Mypair._Myval2._Bx._Ptr - v35 - 8) > 0x1F ) /*0x1410c6c12*/
              goto LABEL_55; /*0x1410c6c12*/
          }
          operator delete(ptr: v35); /*0x1410c6c1b*/
        }
      }
      RBX::Analytics::EphemeralCounter::bulkReportStats(stats: &stat, blocking: false); /*0x1410c6c27*/
      Myfirst = stat._Mypair._Myval2._Myfirst; /*0x1410c6c2d*/
      if ( stat._Mypair._Myval2._Myfirst != nullptr ) /*0x1410c6c35*/
      {
        v37 = stat._Mypair._Myval2._Mylast; /*0x1410c6c3b*/
        if ( stat._Mypair._Myval2._Myfirst != stat._Mypair._Myval2._Mylast ) /*0x1410c6c43*/
        {
          do /*0x1410c6c91*/
          {
            v38 = Myfirst->first._Mypair._Myval2._Myres; /*0x1410c6c45*/
            if ( v38 >= 0x10 ) /*0x1410c6c4d*/
            {
              v39 = Myfirst->first._Mypair._Myval2._Bx._Ptr; /*0x1410c6c52*/
              if ( v38 + 1 >= 0x1000 ) /*0x1410c6c5c*/
              {
                if ( (unsigned __int64)&v39[-*((_QWORD *)v39 - 1) - 8] > 0x1F ) /*0x1410c6c71*/
                  goto LABEL_68; /*0x1410c6c71*/
                v39 = *((char **)v39 - 1); /*0x1410c6c73*/
              }
              operator delete(ptr: v39); /*0x1410c6c76*/
            }
            Myfirst->first._Mypair._Myval2._Mysize = 0; /*0x1410c6c7b*/
            Myfirst->first._Mypair._Myval2._Myres = 15; /*0x1410c6c7f*/
            Myfirst->first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410c6c87*/
            ++Myfirst; /*0x1410c6c8a*/
          }
          while ( Myfirst != v37 ); /*0x1410c6c91*/
          Myfirst = stat._Mypair._Myval2._Myfirst; /*0x1410c6c93*/
        }
        v40 = Myfirst; /*0x1410c6cc3*/
        if ( (unsigned __int64)(40 * (stat._Mypair._Myval2._Myend - Myfirst)) >= 0x1000 ) /*0x1410c6ccd*/
        {
          Myfirst = *(std::pair<std::string,double> **)&Myfirst[-1].second; /*0x1410c6cd3*/
          if ( (unsigned __int64)((char *)v40 - (char *)Myfirst - 8) > 0x1F ) /*0x1410c6ce2*/
LABEL_68:
            _invalid_parameter_noinfo_noreturn(); /*0x1410c6ce4*/
        }
        operator delete(ptr: Myfirst); /*0x1410c6cee*/
      }
      return; /*0x1410c6cee*/
    }
LABEL_55:
    _invalid_parameter_noinfo_noreturn(); /*0x1410c6c14*/
  }
  __unwind
  {
    std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)&stat); /*0xf1c0000000000008*/
  }
}

// Address: 0x1410c6fe0 | Name: ?RunUpdateCycle@RakPeer@RakNet@@MEAA_K_K0AEAVBitStream@2@@Z
unsigned __int64 __fastcall RakNet::RakPeer::RunUpdateCycle(
        RakNet::RakPeer *this,
        unsigned __int64 timeUS,
        unsigned __int64 timeMS,
        RakNet::BitStream *updateBitStream)
{
  unsigned __int64 v8; // r12
  unsigned __int64 v9; // rdi
  unsigned __int64 v10; // rbx
  int v11; // ebx
  char *v12; // rax
  void *token; // rcx
  unsigned int head; // edi
  unsigned int tail; // ebx
  unsigned __int64 v16; // rax
  unsigned __int64 v17; // rdi
  unsigned __int64 v18; // rbx
  __int64 v19; // rcx
  unsigned int v20; // eax
  int v21; // ecx
  _WORD *v22; // rax
  void *v23; // rcx
  __int64 v25; // [rsp+0h] [rbp-89h] BYREF
  RBX::Profiler::Scope profscope6550; // [rsp+20h] [rbp-69h] BYREF
  __int64 v27; // [rsp+30h] [rbp-59h]
  unsigned __int64 v28; // [rsp+38h] [rbp-51h]
  RBX::Analytics::InfluxDb::Points unconnectedPingReport; // [rsp+40h] [rbp-49h] BYREF
  unsigned __int64 v30; // [rsp+F8h] [rbp+6Fh] BYREF
  unsigned __int64 v31; // [rsp+100h] [rbp+77h] BYREF
  RakNet::BitStream *v32; // [rsp+108h] [rbp+7Fh]

  v32 = updateBitStream; /*0x1410c6fe5*/
  v31 = timeMS; /*0x1410c6fea*/
  v30 = timeUS; /*0x1410c6fef*/
  if ( DFFlag::TrackRunUpdateCycleTime.value ) /*0x1410c701e*/
  {
    RakNet::RakPeer::TrackRunUpdateCycleTime(this); /*0x1410c7020*/
    this->runUpdateCycleStats.trackedStatsLastCycle = true; /*0x1410c7025*/
  }
  if ( DFFlag::ReportPktDropStats2.value ) /*0x1410c7034*/
    RakNet::RakPeer::TrackDroppedPackets::Report(this: &this->trackDroppedPackets, timeMS); /*0x1410c7040*/
  if ( FFlag::DebugClientDumpMicroprofileForJoins.value ) /*0x1410c7051*/
  {
    v8 = RakNet::RakPeer::ProcessBufferedPackets(this, updateBitStream, timeUS); /*0x1410c7061*/
  }
  else
  {
    if ( _TSS0_539 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x1410c7082*/
    {
      __wind /*0xf1c0000000000024*/
      {
        Init_thread_header(pOnce: &_TSS0_539); /*0x1410c764d*/
        if ( _TSS0_539 == -1 ) /*0x1410c7659*/
        {
          proftoken6505 = RBX::Profiler::getToken(group: "RakNet", name: "RakPeer::ProcessNetworkPacket", color: -1); /*0x1410c7678*/
          Init_thread_footer(pOnce: &_TSS0_539); /*0x1410c7686*/
        }
      }
      __unwind
      {
        Init_thread_abort(pOnce: &_TSS0_539); /*0x1431ed037*/
      }
    }
    v9 = proftoken6505; /*0x1410c7088*/
    profscope6550.region.token = proftoken6505; /*0x1410c708f*/
    v10 = RBX::Profiler::enterRegion(token: proftoken6505); /*0x1410c709b*/
    profscope6550.region.timestamp = v10; /*0x1410c709e*/
    __eh34_enter_wind_state(-1, 1); /*0xf1c00000000000dc*/
    v8 = RakNet::RakPeer::ProcessBufferedPackets(this, updateBitStream, timeUS); /*0x1410c70b0*/
    if ( __eh34_unwind(1) ) /*0xf1c00000000000fc*/
    {
unwind_state_1:
      RBX::Profiler::Scope::~Scope(this: &profscope6550); /*0xf1c00000000000e8*/
      __eh34_propagate_exception_into_caller(1, -1); /*0xf1c00000000000ec*/
    }
    __eh34_exit_wind_state(1, -1); /*0xf1c0000000000100*/
    __eh34_enter_wind_state(-1, 2); /*0xf1c0000000000104*/
    RBX::Profiler::leaveRegion(token: v9, enterTimestamp: v10); /*0x1410c70b9*/
    if ( __eh34_unwind(2) ) /*0xf1c00000000000d0*/
unwind_state_2:
      __std_terminate(a1: v19, a2: &v25); /*0xf1c0000000000090*/
    __eh34_exit_wind_state(2, -1); /*0xf1c00000000000d4*/
  }
  if ( DFFlag::ReportNumCommandsPerCycle.value /*0x1410c70eb*/
    && this->bcStats.numCommandCyclesSampled != 0
    && (int)timeMS - this->bcStats.lastReportCommandsPerCycle >= DFInt::ReportCommandsPerCycleIntervalMS )
  {
    this->bcStats.lastReportCommandsPerCycle = timeMS; /*0x1410c70f1*/
    RBX::Analytics::InfluxDb::Points::Points( /*0x1410c7105*/
      this: &unconnectedPingReport,
      throttleHundredthsPercentage: -1,
      categoryType: kStandardType,
      priorityHundredthsPercentage: 0);
    __eh34_enter_wind_state(-1, 3); /*0xf1c00000000000c8*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c7128*/
      this: &unconnectedPingReport,
      name: "Avg",
      value: this->bcStats.totalCommandsPerCycle / this->bcStats.numCommandCyclesSampled);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c713f*/
      this: &unconnectedPingReport,
      name: (const char *)&PropertiesWidget::NumberRangePropertyItem::`vftable'{for `PropertiesWidget::WeightSortedItem'}[7],
      value: this->bcStats.minCommandsPerCycle);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c7156*/
      this: &unconnectedPingReport,
      name: (const char *)&PropertiesWidget::NumberRangePropertyItem::`vftable'{for `PropertiesWidget::WeightSortedItem'}[7]
    + 4,
      value: this->bcStats.maxCommandsPerCycle);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c716d*/
      this: &unconnectedPingReport,
      name: "NumCycles",
      value: this->bcStats.numCommandCyclesSampled);
    v11 = DFInt::ReportNumCommandsPerCycle_HundredthsPercentage; /*0x1410c7172*/
    v12 = (char *)operator new(size: 0x20u); /*0x1410c718f*/
    v27 = 28; /*0x1410c7194*/
    v28 = 31; /*0x1410c719c*/
    strcpy(v12, "ProcessBufferedCommandsStats"); /*0x1410c71ab*/
    profscope6550.region.token = (unsigned __int64)v12; /*0x1410c71c8*/
    __eh34_enter_wind_state(3, 4); /*0xf1c00000000000c0*/
    RBX::Analytics::InfluxDb::Points::report( /*0x1410c71da*/
      this: &unconnectedPingReport,
      resource: (const std::string *)&profscope6550,
      throttleHundredthsPercentage: v11,
      blocking: false);
    if ( __eh34_unwind(4) ) /*0xf1c00000000000b4*/
    {
unwind_state_4:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&profscope6550); /*0xf1c000000000006c*/
      __eh34_continue_unwinding(4, 3); /*0xf1c0000000000070*/
    }
    __eh34_exit_wind_state(4, 3); /*0xf1c00000000000b8*/
    if ( v28 >= 0x10 ) /*0x1410c71e8*/
    {
      token = (void *)profscope6550.region.token; /*0x1410c71ed*/
      if ( v28 + 1 >= 0x1000 ) /*0x1410c71fb*/
      {
        token = *(void **)(profscope6550.region.token - 8); /*0x1410c7201*/
        if ( profscope6550.region.token - (unsigned __int64)token - 8 > 0x1F ) /*0x1410c7210*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410c7212*/
      }
      operator delete(ptr: token); /*0x1410c7219*/
    }
    *(_QWORD *)&this->bcStats.totalCommandsPerCycle = 0; /*0x1410c721e*/
    this->bcStats.minCommandsPerCycle = 0x7FFFFFFF; /*0x1410c7225*/
    this->bcStats.maxCommandsPerCycle = 0x80000000; /*0x1410c7230*/
    RBX::Analytics::InfluxDb::Points::~Points(this: &unconnectedPingReport); /*0x1410c723f*/
    if ( __eh34_unwind(3) ) /*0xf1c00000000000a8*/
    {
unwind_state_3:
      RBX::Analytics::InfluxDb::Points::~Points(this: &unconnectedPingReport); /*0xf1c0000000000058*/
      __eh34_propagate_exception_into_caller(3, -1); /*0xf1c000000000005c*/
    }
    __eh34_exit_wind_state(3, -1); /*0xf1c00000000000ac*/
  }
  RakNet::RakPeer::ProcessBufferedCommands(this, timeUS: &v30, timeMS: &v31); /*0x1410c724f*/
  if ( DFFlag::TrackRunUpdateCycleTime.value ) /*0x1410c725b*/
    this->runUpdateCycleStats.cycleStartToAfterBufferedHandling.sec = RBX::Time::nowFast(result: (RBX::Time *)&profscope6550)->sec /*0x1410c7273*/
                                                                    - this->runUpdateCycleStats.lastCycleStart.sec;
  rtc::CriticalSection::Enter(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410c7283*/
  head = this->requestedConnectionQueue.head; /*0x1410c7288*/
  tail = this->requestedConnectionQueue.tail; /*0x1410c728f*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410c729d*/
  if ( head != tail ) /*0x1410c72a4*/
    RakNet::RakPeer::HandleRequestedConnectionQueue(this, timeUS: &v30, timeMS: &v31); /*0x1410c72b1*/
  if ( DFFlag::TrackRunUpdateCycleTime.value ) /*0x1410c72bd*/
    this->runUpdateCycleStats.cycleStartToAfterRequestConnection.sec = RBX::Time::nowFast(result: (RBX::Time *)&profscope6550)->sec /*0x1410c72d5*/
                                                                     - this->runUpdateCycleStats.lastCycleStart.sec;
  if ( FFlag::CLI52064Experiment2.value ) /*0x1410c72e5*/
  {
    v16 = RakNet::RakPeer::ProcessArtificialLatencyTransmitPackets(this, timeUS); /*0x1410c72ed*/
    if ( v16 < v8 ) /*0x1410c72f5*/
      v8 = v16; /*0x1410c72f5*/
  }
  if ( FFlag::DebugClientDumpMicroprofileForJoins.value ) /*0x1410c7300*/
  {
    RakNet::RakPeer::HandleActiveSystemList(this, updateBitStream: v32, timeUS: &v30, timeMS: &v31); /*0x1410c7311*/
  }
  else
  {
    if ( _TSS1_115 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x1410c7339*/
    {
      __wind /*0xf1c000000000003c*/
      {
        Init_thread_header(pOnce: &_TSS1_115); /*0x1410c7603*/
        if ( _TSS1_115 == -1 ) /*0x1410c760f*/
        {
          proftoken6550 = RBX::Profiler::getToken(group: "RakNet", name: "RakPeer::HandleActiveSystemList", color: -1); /*0x1410c762e*/
          Init_thread_footer(pOnce: &_TSS1_115); /*0x1410c763c*/
        }
      }
      __unwind
      {
        Init_thread_abort(pOnce: &_TSS1_115); /*0x1431ed047*/
      }
    }
    v17 = proftoken6550; /*0x1410c733f*/
    profscope6550.region.token = proftoken6550; /*0x1410c7346*/
    v18 = RBX::Profiler::enterRegion(token: proftoken6550); /*0x1410c7352*/
    profscope6550.region.timestamp = v18; /*0x1410c7355*/
    __eh34_enter_wind_state(-1, 1); /*0xf1c00000000000a0*/
    RakNet::RakPeer::HandleActiveSystemList(this, updateBitStream: v32, timeUS: &v30, timeMS: &v31); /*0x1410c7368*/
    if ( __eh34_unwind(1) ) /*0xf1c00000000000e4*/
      goto unwind_state_1; /*0xf1c00000000000e4*/
    __eh34_exit_wind_state(1, -1); /*0xf1c00000000000f0*/
    __eh34_enter_wind_state(-1, 2); /*0xf1c00000000000f4*/
    RBX::Profiler::leaveRegion(token: v17, enterTimestamp: v18); /*0x1410c7374*/
    if ( __eh34_unwind(2) ) /*0xf1c000000000008c*/
      goto unwind_state_2; /*0xf1c000000000008c*/
    __eh34_exit_wind_state(2, -1); /*0xf1c0000000000098*/
  }
  if ( FFlag::CLI52064Experiment2.value /*0x1410c73a3*/
    && ((__int64)this->GetArtificialLatencyRx(this) != 0 || (__int64)this->GetArtificialLatencyTx(this) != 0) )
  {
    RakNet::RakPeer::ReportRakNetLatencyMeasurementStats(this, timeMS); /*0x1410c73ab*/
  }
  if ( DFFlag::TrackRunUpdateCycleTime.value ) /*0x1410c73b7*/
    this->runUpdateCycleStats.cycleStartToReturn.sec = RBX::Time::nowFast(result: (RBX::Time *)&profscope6550)->sec /*0x1410c73cf*/
                                                     - this->runUpdateCycleStats.lastCycleStart.sec;
  if ( DFInt::CLI56775MS != 0 && timeMS - this->bytesInQueueStats.lastReportBytesInQueueStatsMS >= DFInt::CLI56775MS ) /*0x1410c73f0*/
  {
    this->bytesInQueueStats.lastReportBytesInQueueStatsMS = timeMS; /*0x1410c73f2*/
    if ( DFFlag::ReportQueueStatsCanSend.value ) /*0x1410c73fd*/
    {
      v20 = RBX::globalRand(); /*0x1410c73ff*/
      v21 = DFInt::CLI56775_HundredthsPercentage; /*0x1410c741b*/
      if ( v20 % 0x2710 < DFInt::CLI56775_HundredthsPercentage ) /*0x1410c7424*/
      {
LABEL_46:
        RakNet::RakPeer::reportQueuedByteStats(this); /*0x1410c7440*/
        goto LABEL_47; /*0x1410c7443*/
      }
      if ( DFFlag::ReportQueueStatsCanSend.value ) /*0x1410c742d*/
      {
LABEL_47:
        *(_QWORD *)&this->bytesInQueueStats.maxBytesInReturnQueueSinglePeer = 0; /*0x1410c7448*/
        *(_QWORD *)&this->bytesInQueueStats.maxBytesIncompleteDatagrams = 0; /*0x1410c744e*/
        goto LABEL_48; /*0x1410c744e*/
      }
    }
    else
    {
      v21 = DFInt::CLI56775_HundredthsPercentage; /*0x1410c7431*/
    }
    if ( RBX::Analytics::InfluxDb::canSend(throttleHundredthsPercentage: v21) ) /*0x1410c7437*/
      goto LABEL_46; /*0x1410c743e*/
    goto LABEL_47; /*0x1410c743e*/
  }
LABEL_48:
  if ( DFFlag::UnconnectedPingReport.value /*0x1410c747a*/
    && timeMS - this->unconnectedPingStats.lastReportUnconnectedPingsMS >= DFInt::UnconnectedPingReportMS )
  {
    this->unconnectedPingStats.lastReportUnconnectedPingsMS = timeMS; /*0x1410c7480*/
    if ( rand() % 10000 < DFInt::UnconnectedPingReport_HundredthsPercentage /*0x1410c74ca*/
      && (this->unconnectedPingStats.unconnectedPings != 0 || this->unconnectedPingStats.unconnectedPongs != 0) )
    {
      RBX::Analytics::InfluxDb::Points::Points( /*0x1410c74de*/
        this: &unconnectedPingReport,
        throttleHundredthsPercentage: -1,
        categoryType: kStandardType,
        priorityHundredthsPercentage: 0);
      __eh34_enter_wind_state(-1, 3); /*0xf1c0000000000084*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c74f6*/
        this: &unconnectedPingReport,
        name: "Pings",
        value: this->unconnectedPingStats.unconnectedPings);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410c750d*/
        this: &unconnectedPingReport,
        name: "Pongs",
        value: this->unconnectedPingStats.unconnectedPongs);
      profscope6550.region.token = 0; /*0x1410c7512*/
      v27 = 0; /*0x1410c7516*/
      v28 = 15; /*0x1410c751a*/
      v22 = operator new(size: 0x20u); /*0x1410c752b*/
      v27 = 27; /*0x1410c7530*/
      v28 = 31; /*0x1410c7538*/
      qmemcpy(v22, "RakNetRxUnconnectedPingPon", 26); /*0x1410c7547*/
      v22[13] = (unsigned __int8)aRaknetrxunconn[26]; /*0x1410c7569*/
      profscope6550.region.token = (unsigned __int64)v22; /*0x1410c7570*/
      __eh34_enter_wind_state(3, 4); /*0xf1c000000000007c*/
      RBX::Analytics::InfluxDb::Points::report( /*0x1410c7585*/
        this: &unconnectedPingReport,
        resource: (const std::string *)&profscope6550,
        throttleHundredthsPercentage: 10000,
        blocking: false);
      if ( __eh34_unwind(4) ) /*0xf1c0000000000068*/
        goto unwind_state_4; /*0xf1c0000000000068*/
      __eh34_exit_wind_state(4, 3); /*0xf1c0000000000074*/
      if ( v28 >= 0x10 ) /*0x1410c7593*/
      {
        v23 = (void *)profscope6550.region.token; /*0x1410c7598*/
        if ( v28 + 1 >= 0x1000 ) /*0x1410c75a6*/
        {
          v23 = *(void **)(profscope6550.region.token - 8); /*0x1410c75ac*/
          if ( profscope6550.region.token - (unsigned __int64)v23 - 8 > 0x1F ) /*0x1410c75bb*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410c75bd*/
        }
        operator delete(ptr: v23); /*0x1410c75c4*/
      }
      RBX::Analytics::InfluxDb::Points::~Points(this: &unconnectedPingReport); /*0x1410c75ce*/
      if ( __eh34_unwind(3) ) /*0xf1c0000000000054*/
        goto unwind_state_3; /*0xf1c0000000000054*/
      __eh34_exit_wind_state(3, -1); /*0xf1c0000000000060*/
    }
    *(_QWORD *)&this->unconnectedPingStats.unconnectedPings = 0; /*0x1410c75d3*/
  }
  return v8; /*0x1410c75e1*/
}

// Address: 0x1410c7690 | Name: ?Send@RakPeer@RakNet@@UEAAIAEAV?$shared_ptr@$$CBVAbstractBitStream@RakNet@@@std@@W4PacketPriority@@W4PacketReliability@@DUAddressOrGUID@2@_NI@Z
__int64 __fastcall RakNet::RakPeer::Send(
        RakNet::RakPeer *this,
        std::shared_ptr<RakNet::AbstractBitStream const > *bitStream,
        PacketPriority priority,
        PacketReliability reliability,
        char orderingChannel,
        const RakNet::AddressOrGUID *systemIdentifier,
        bool broadcast,
        unsigned int forceReceiptNumber)
{
  const RakNet::AddressOrGUID *v8; // r14
  bool v11; // r12
  unsigned int v12; // r15d
  char v13; // al
  int v14; // ebx
  RakNet::SystemAddress *p_systemAddress; // rdi
  __int64 v16; // rbp
  void (__fastcall *SendLoopback)(struct RakNet::RakPeer *, const char *, const int); // rdi
  unsigned int v18; // ebx
  unsigned __int8 *v19; // rax
  bool isJoinData; // bl
  const RakNet::AddressOrGUID *v22; // rdi
  unsigned int v23; // eax
  RakNet::AddressOrGUID v24; // [rsp+60h] [rbp-68h] BYREF
  char buff[5]; // [rsp+D8h] [rbp+10h] BYREF
  PacketPriority v26; // [rsp+E0h] [rbp+18h]
  PacketReliability v27; // [rsp+E8h] [rbp+20h]

  v27 = reliability; /*0x1410c7690*/
  v26 = priority; /*0x1410c7695*/
  v8 = systemIdentifier; /*0x1410c76a8*/
  if ( bitStream->_Ptr->GetNumberOfBytesUsed(this: bitStream->_Ptr) == 0 ) /*0x1410c76c1*/
    return 0; /*0x1410c76c1*/
  if ( this->remoteSystemList == nullptr ) /*0x1410c76cf*/
    return 0; /*0x1410c76cf*/
  if ( this->endThreads._Storage._Value ) /*0x1410c76d5*/
    return 0; /*0x1410c76dc*/
  v11 = broadcast; /*0x1410c76e2*/
  if ( !broadcast && RakNet::AddressOrGUID::IsUndefined(this: v8) ) /*0x1410c76f3*/
    return 0; /*0x1410c78ea*/
  v12 = forceReceiptNumber; /*0x1410c7708*/
  if ( forceReceiptNumber == 0 ) /*0x1410c7713*/
    v12 = this->IncrementNextSendReceipt(this); /*0x1410c7721*/
  if ( v11 ) /*0x1410c773f*/
    goto LABEL_20; /*0x1410c773f*/
  if ( StudioResourceId::operator!=( /*0x1410c774f*/
         this: (RBX::json::ArrayIterator *)v8,
         rhs: (const RBX::json::ArrayIterator *)&RakNet::UNASSIGNED_RAKNET_GUID_30) )
  {
    v13 = StudioResourceId::operator==(lhs: v8, rhs: &this->myGuid); /*0x1410c7762*/
  }
  else
  {
    v14 = 0; /*0x1410c7769*/
    p_systemAddress = &v8->systemAddress; /*0x1410c776b*/
    do /*0x1410c77b0*/
    {
      v16 = v14; /*0x1410c777a*/
      if ( RakNet::SystemAddress::operator!=(this: &this->ipList[v16], right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410c778f*/
        break; /*0x1410c778f*/
      p_systemAddress = &v8->systemAddress; /*0x1410c7791*/
      if ( RakNet::SystemAddress::operator==(this: &this->ipList[v16], right: &v8->systemAddress) != 0 ) /*0x1410c77a9*/
        goto LABEL_17; /*0x1410c77a9*/
      ++v14; /*0x1410c77ab*/
    }
    while ( v14 < 10 ); /*0x1410c77b0*/
    v13 = RakNet::SystemAddress::operator==(this: p_systemAddress, right: &this->firstExternalID); /*0x1410c77bc*/
  }
  if ( v13 == 0 ) /*0x1410c77c3*/
  {
LABEL_20:
    isJoinData = bitStream->_Ptr->isJoinData; /*0x1410c7883*/
    v22 = RakNet::AddressOrGUID::AddressOrGUID(this: &v24, input: v8); /*0x1410c7890*/
    v23 = bitStream->_Ptr->GetNumberOfBytesUsed(this: bitStream->_Ptr); /*0x1410c7896*/
    RakNet::RakPeer::SendBufferedShared( /*0x1410c78e0*/
      this,
      bytestream: bitStream,
      numberOfBitsToSend: 8 * v23,
      priority: v26,
      reliability: v27,
      orderingChannel,
      systemIdentifier: v22,
      broadcast: v11,
      connectionMode: (RakNet::RakPeer::RemoteSystemStruct::ConnectMode)0,
      receipt: v12,
      isJoinData);
  }
  else
  {
LABEL_17:
    SendLoopback = this->SendLoopback; /*0x1410c77c9*/
    v18 = bitStream->_Ptr->GetNumberOfBytesUsed(this: bitStream->_Ptr); /*0x1410c77e1*/
    v19 = bitStream->_Ptr->GetData(this: bitStream->_Ptr); /*0x1410c77e6*/
    SendLoopback(this, a2: (const char *)v19, a3: v18); /*0x1410c77f2*/
    if ( v27 >= UNRELIABLE_WITH_ACK_RECEIPT ) /*0x1410c77fc*/
    {
      buff[0] = 14; /*0x1410c7805*/
      rtc::CriticalSection::Enter(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410c780d*/
      *(_DWORD *)&buff[1] = this->sendReceiptSerial; /*0x1410c781f*/
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410c7826*/
      this->SendLoopback(this, a2: buff, a3: 5); /*0x1410c783f*/
    }
  }
  return v12; /*0x1410c7868*/
}

// Address: 0x1410c7900 | Name: ?Send@RakPeer@RakNet@@UEAAIPEBDHW4PacketPriority@@W4PacketReliability@@DUAddressOrGUID@2@_NI@Z
__int64 __fastcall RakNet::RakPeer::Send(
        RakNet::RakPeer *this,
        const char *data,
        int length,
        PacketPriority priority,
        PacketReliability reliability,
        char orderingChannel,
        const RakNet::AddressOrGUID *systemIdentifier,
        bool broadcast,
        unsigned int forceReceiptNumber)
{
  const RakNet::AddressOrGUID *v9; // r14
  bool v12; // r12
  unsigned int v13; // r15d
  char v14; // al
  int v15; // ebx
  RakNet::SystemAddress *p_systemAddress; // rsi
  __int64 v17; // rbp
  const RakNet::AddressOrGUID *v19; // rax
  RakNet::AddressOrGUID v20; // [rsp+60h] [rbp-68h] BYREF
  const char *buff; // [rsp+D8h] [rbp+10h] BYREF
  PacketPriority v22; // [rsp+E8h] [rbp+20h]

  v22 = priority; /*0x1410c7900*/
  buff = data; /*0x1410c7905*/
  v9 = systemIdentifier; /*0x1410c7918*/
  if ( data == nullptr ) /*0x1410c7929*/
    return 0; /*0x1410c7929*/
  if ( length < 0 ) /*0x1410c7932*/
    return 0; /*0x1410c7932*/
  if ( this->remoteSystemList == nullptr ) /*0x1410c7940*/
    return 0; /*0x1410c7940*/
  if ( this->endThreads._Storage._Value ) /*0x1410c7946*/
    return 0; /*0x1410c794d*/
  v12 = broadcast; /*0x1410c7953*/
  if ( !broadcast && RakNet::AddressOrGUID::IsUndefined(this: systemIdentifier) ) /*0x1410c7964*/
    return 0; /*0x1410c7b38*/
  v13 = forceReceiptNumber; /*0x1410c7979*/
  if ( forceReceiptNumber == 0 ) /*0x1410c7984*/
    v13 = this->IncrementNextSendReceipt(this); /*0x1410c7992*/
  if ( v12 ) /*0x1410c79b0*/
    goto LABEL_21; /*0x1410c79b0*/
  if ( StudioResourceId::operator!=( /*0x1410c79c0*/
         this: (RBX::json::ArrayIterator *)v9,
         rhs: (const RBX::json::ArrayIterator *)&RakNet::UNASSIGNED_RAKNET_GUID_30) )
  {
    v14 = StudioResourceId::operator==(lhs: v9, rhs: &this->myGuid); /*0x1410c79d3*/
  }
  else
  {
    v15 = 0; /*0x1410c79da*/
    p_systemAddress = &v9->systemAddress; /*0x1410c79dc*/
    do /*0x1410c7a20*/
    {
      v17 = v15; /*0x1410c79ea*/
      if ( RakNet::SystemAddress::operator!=(this: &this->ipList[v17], right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410c79ff*/
        break; /*0x1410c79ff*/
      p_systemAddress = &v9->systemAddress; /*0x1410c7a01*/
      if ( RakNet::SystemAddress::operator==(this: &this->ipList[v17], right: &v9->systemAddress) != 0 ) /*0x1410c7a19*/
        goto LABEL_18; /*0x1410c7a19*/
      ++v15; /*0x1410c7a1b*/
    }
    while ( v15 < 10 ); /*0x1410c7a20*/
    v14 = RakNet::SystemAddress::operator==(this: p_systemAddress, right: &this->firstExternalID); /*0x1410c7a2c*/
  }
  if ( v14 == 0 ) /*0x1410c7a33*/
  {
LABEL_21:
    v19 = RakNet::AddressOrGUID::AddressOrGUID(this: &v20, input: v9); /*0x1410c7adb*/
    RakNet::RakPeer::SendBuffered( /*0x1410c7b2e*/
      this,
      data: buff,
      numberOfBitsToSend: 8 * length,
      priority: v22,
      reliability,
      orderingChannel,
      systemIdentifier: v19,
      broadcast: v12,
      connectionMode: (RakNet::RakPeer::RemoteSystemStruct::ConnectMode)0,
      receipt: v13,
      isJoinData: false);
  }
  else
  {
LABEL_18:
    this->SendLoopback(this, a2: buff, a3: length); /*0x1410c7a39*/
    if ( reliability >= UNRELIABLE_WITH_ACK_RECEIPT ) /*0x1410c7a58*/
    {
      LOBYTE(buff) = 14; /*0x1410c7a61*/
      rtc::CriticalSection::Enter(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410c7a69*/
      *(_DWORD *)((char *)&buff + 1) = this->sendReceiptSerial; /*0x1410c7a7b*/
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410c7a82*/
      this->SendLoopback(this, a2: (const char *)&buff, a3: 5); /*0x1410c7a9b*/
    }
  }
  return v13; /*0x1410c7ac4*/
}

// Address: 0x1410c7b50 | Name: ?Send@RakPeer@RakNet@@UEAAIPEBVAbstractBitStream@2@W4PacketPriority@@W4PacketReliability@@DUAddressOrGUID@2@_NI@Z
__int64 __fastcall RakNet::RakPeer::Send(
        RakNet::RakPeer *this,
        const RakNet::AbstractBitStream *bitStream,
        PacketPriority priority,
        PacketReliability reliability,
        char orderingChannel,
        const RakNet::AddressOrGUID *systemIdentifier,
        bool broadcast,
        unsigned int forceReceiptNumber)
{
  const RakNet::AddressOrGUID *v9; // rbp
  bool v11; // r13
  unsigned int v12; // r12d
  char v13; // al
  int v14; // ebx
  RakNet::SystemAddress *p_systemAddress; // rdi
  __int64 v16; // rsi
  void (__fastcall *SendLoopback)(struct RakNet::RakPeer *, const char *, const int); // rdi
  unsigned int v18; // ebx
  unsigned __int8 *v19; // rax
  bool isJoinData; // bl
  const RakNet::AddressOrGUID *v22; // rdi
  unsigned int v23; // esi
  const char *v24; // rax
  RakNet::AddressOrGUID v25; // [rsp+60h] [rbp-68h] BYREF
  char buff[5]; // [rsp+D8h] [rbp+10h] BYREF
  PacketPriority v27; // [rsp+E0h] [rbp+18h]
  PacketReliability v28; // [rsp+E8h] [rbp+20h]

  v28 = reliability; /*0x1410c7b50*/
  v27 = priority; /*0x1410c7b55*/
  v9 = systemIdentifier; /*0x1410c7b6e*/
  if ( bitStream->GetNumberOfBytesUsed(this: bitStream) == 0 ) /*0x1410c7b81*/
    return 0; /*0x1410c7b81*/
  if ( this->remoteSystemList == nullptr ) /*0x1410c7b8f*/
    return 0; /*0x1410c7b8f*/
  if ( this->endThreads._Storage._Value ) /*0x1410c7b95*/
    return 0; /*0x1410c7b9d*/
  v11 = broadcast; /*0x1410c7ba3*/
  if ( !broadcast && RakNet::AddressOrGUID::IsUndefined(this: v9) ) /*0x1410c7bb4*/
    return 0; /*0x1410c7daf*/
  v12 = forceReceiptNumber; /*0x1410c7bc9*/
  if ( forceReceiptNumber == 0 ) /*0x1410c7bd4*/
    v12 = this->IncrementNextSendReceipt(this); /*0x1410c7be2*/
  if ( v11 ) /*0x1410c7c00*/
    goto LABEL_20; /*0x1410c7c00*/
  if ( StudioResourceId::operator!=( /*0x1410c7c10*/
         this: (RBX::json::ArrayIterator *)v9,
         rhs: (const RBX::json::ArrayIterator *)&RakNet::UNASSIGNED_RAKNET_GUID_30) )
  {
    v13 = StudioResourceId::operator==(lhs: v9, rhs: &this->myGuid); /*0x1410c7c23*/
  }
  else
  {
    v14 = 0; /*0x1410c7c2a*/
    p_systemAddress = &v9->systemAddress; /*0x1410c7c2c*/
    do /*0x1410c7c70*/
    {
      v16 = v14; /*0x1410c7c3a*/
      if ( RakNet::SystemAddress::operator!=(this: &this->ipList[v16], right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410c7c4f*/
        break; /*0x1410c7c4f*/
      p_systemAddress = &v9->systemAddress; /*0x1410c7c51*/
      if ( RakNet::SystemAddress::operator==(this: &this->ipList[v16], right: &v9->systemAddress) != 0 ) /*0x1410c7c69*/
        goto LABEL_17; /*0x1410c7c69*/
      ++v14; /*0x1410c7c6b*/
    }
    while ( v14 < 10 ); /*0x1410c7c70*/
    v13 = RakNet::SystemAddress::operator==(this: p_systemAddress, right: &this->firstExternalID); /*0x1410c7c7c*/
  }
  if ( v13 == 0 ) /*0x1410c7c83*/
  {
LABEL_20:
    isJoinData = bitStream->isJoinData; /*0x1410c7d36*/
    v22 = RakNet::AddressOrGUID::AddressOrGUID(this: &v25, input: v9); /*0x1410c7d4e*/
    v23 = 8 /*0x1410c7d5c*/
        * ((__int64 (__fastcall *)(const RakNet::AbstractBitStream *))bitStream->GetNumberOfBytesUsed)(a1: bitStream);
    v24 = (const char *)bitStream->GetData(this: bitStream); /*0x1410c7d5f*/
    RakNet::RakPeer::SendBuffered( /*0x1410c7da5*/
      this,
      data: v24,
      numberOfBitsToSend: v23,
      priority: v27,
      reliability: v28,
      orderingChannel,
      systemIdentifier: v22,
      broadcast: v11,
      connectionMode: (RakNet::RakPeer::RemoteSystemStruct::ConnectMode)0,
      receipt: v12,
      isJoinData);
  }
  else
  {
LABEL_17:
    SendLoopback = this->SendLoopback; /*0x1410c7c89*/
    v18 = bitStream->GetNumberOfBytesUsed(this: bitStream); /*0x1410c7ca2*/
    v19 = bitStream->GetData(this: bitStream); /*0x1410c7ca4*/
    SendLoopback(this, a2: (const char *)v19, a3: v18); /*0x1410c7cb0*/
    if ( v28 >= UNRELIABLE_WITH_ACK_RECEIPT ) /*0x1410c7cba*/
    {
      buff[0] = 14; /*0x1410c7cc3*/
      rtc::CriticalSection::Enter(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410c7ccb*/
      *(_DWORD *)&buff[1] = this->sendReceiptSerial; /*0x1410c7cde*/
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410c7ce5*/
      this->SendLoopback(this, a2: buff, a3: 5); /*0x1410c7cfe*/
    }
  }
  return v12; /*0x1410c7d27*/
}

// Address: 0x1410c7dc0 | Name: ?SendBuffered@RakPeer@RakNet@@IEAAXPEBDIW4PacketPriority@@W4PacketReliability@@DUAddressOrGUID@2@_NW4ConnectMode@RemoteSystemStruct@12@I4@Z
void __fastcall RakNet::RakPeer::SendBuffered(
        RakNet::RakPeer *this,
        const char *data,
        unsigned int numberOfBitsToSend,
        PacketPriority priority,
        PacketReliability reliability,
        char orderingChannel,
        const RakNet::AddressOrGUID *systemIdentifier,
        bool broadcast,
        RakNet::RakPeer::RemoteSystemStruct::ConnectMode connectionMode,
        unsigned int receipt,
        bool isJoinData)
{
  unsigned __int64 v15; // rbx
  char *v16; // rax
  RakNet::RakPeer::BufferedCommandStruct *v17; // rax
  signed __int32 v18; // eax
  HANDLE event; // rax
  std::_Ref_count_base *Rep; // rdi
  DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::BufferedCommandStruct> *p_bufferedCommands_deprecated; // r15
  DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::MemoryWithPage *v22; // rsi
  char *v23; // rax
  volatile signed __int32 *v24; // rdi
  RakNet::RakPeer::BufferedCommandStruct bcs; // [rsp+30h] [rbp-D0h] BYREF
  RakNet::RakPeer::BufferedCommandStruct v26; // [rsp+D0h] [rbp-30h] BYREF

  v15 = (unsigned __int64)(numberOfBitsToSend + 7) >> 3; /*0x1410c7df6*/
  if ( FFlag::BufferedCommandsCircular.value ) /*0x1410c7e01*/
  {
    __wind /*0xf1c000000000003c*/
    {
      bcs.stream = 0; /*0x1410c7e0a*/
      RakNet::RakNetGUID::RakNetGUID(this: &bcs.systemIdentifier.rakNetGuid); /*0x1410c7e15*/
      RakNet::SystemAddress::SystemAddress(this: &bcs.systemIdentifier.systemAddress); /*0x1410c7e1f*/
      bcs.data = nullptr; /*0x1410c7e26*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&bcs); /*0xf1c000000000004c*/
    }
    __eh34_enter_wind_state(-1, 1); /*0xf1c0000000000054*/
    v16 = (char *)RBX::Memory::allocate(size: v15); /*0x1410c7e2d*/
    bcs.data = v16; /*0x1410c7e32*/
    if ( v16 == nullptr ) /*0x1410c7e39*/
    {
      if ( FLog::Network != 0 ) /*0x1410c7e44*/
        FLog::FastLogFormatted( /*0x1410c7e5c*/
          level: FLog::Network,
          message: "[FLog::Network] out of memory in raknet file %s, line %ld",
          "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
          4353);
      if ( __eh34_unwind(1) ) /*0xf1c0000000000030*/
        goto unwind_state_1; /*0xf1c0000000000030*/
      __eh34_exit_wind_state(1, -1); /*0xf1c0000000000034*/
      if ( bcs.stream._Rep != nullptr /*0x1410c7e7f*/
        && _InterlockedExchangeAdd((volatile signed __int32 *)&bcs.stream._Rep->_Uses, 0xFFFFFFFF) == 1 )
      {
        bcs.stream._Rep->_Destroy(this: bcs.stream._Rep); /*0x1410c7e8b*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&bcs.stream._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c7e95*/
          bcs.stream._Rep->_Delete_this(this: bcs.stream._Rep); /*0x1410c7ea1*/
      }
      return; /*0x1410c7ea4*/
    }
    memcpy_0(a1: v16, Src: data, Size: v15); /*0x1410c7eb2*/
    bcs.numberOfBitsToSend = numberOfBitsToSend; /*0x1410c7eb7*/
    bcs.priority = priority; /*0x1410c7ebb*/
    bcs.reliability = reliability; /*0x1410c7ec6*/
    bcs.orderingChannel = orderingChannel; /*0x1410c7ed1*/
    bcs.systemIdentifier.rakNetGuid.g = systemIdentifier->rakNetGuid.g; /*0x1410c7edf*/
    bcs.systemIdentifier.rakNetGuid.systemIndex = systemIdentifier->rakNetGuid.systemIndex; /*0x1410c7ee8*/
    RakNet::SystemAddress::operator=(this: &bcs.systemIdentifier.systemAddress, input: &systemIdentifier->systemAddress); /*0x1410c7ef6*/
    bcs.broadcast = broadcast; /*0x1410c7f02*/
    bcs.connectionMode = connectionMode; /*0x1410c7f0b*/
    bcs.receipt = receipt; /*0x1410c7f14*/
    bcs.isJoinData = isJoinData; /*0x1410c7f1e*/
    bcs.command = BCS_SEND; /*0x1410c7f21*/
    bcs.queueTime = (unsigned int)RakNet::GetTimeMS(); /*0x1410c7f2b*/
    boost::detail::basic_timed_mutex::lock(this: &this->bufferedCommandsMutex); /*0x1410c7f39*/
    v17 = RakNet::RakPeer::BufferedCommandStruct::BufferedCommandStruct(this: &v26, __that: &bcs); /*0x1410c7f47*/
    RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::push_back( /*0x1410c7f56*/
      this: &this->bufferedCommandsCircular,
      item: v17);
    v18 = _InterlockedExchangeAdd(&this->bufferedCommandsMutex.active_count, 0x80000000); /*0x1410c7f60*/
    if ( (v18 & 0x40000000) == 0 /*0x1410c7f76*/
      && v18 != 0x80000000
      && !_interlockedbittestandset(&this->bufferedCommandsMutex.active_count, 0x1Eu) )
    {
      event = boost::detail::basic_timed_mutex::get_event(this: &this->bufferedCommandsMutex); /*0x1410c7f7b*/
      SetEvent(hEvent: event); /*0x1410c7f83*/
    }
    if ( __eh34_unwind(1) ) /*0xf1c000000000001c*/
    {
unwind_state_1:
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&bcs); /*0xf1c0000000000020*/
      __eh34_propagate_exception_into_caller(1, -1); /*0xf1c0000000000024*/
    }
    __eh34_exit_wind_state(1, -1); /*0xf1c0000000000028*/
    Rep = bcs.stream._Rep; /*0x1410c7f8a*/
    if ( bcs.stream._Rep != nullptr /*0x1410c7fa7*/
      && _InterlockedExchangeAdd((volatile signed __int32 *)&bcs.stream._Rep->_Uses, 0xFFFFFFFF) == 1 )
    {
      Rep->_Destroy(this: Rep); /*0x1410c7fb3*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c7fbd*/
        Rep->_Delete_this(this: Rep); /*0x1410c7fc9*/
    }
    goto LABEL_28; /*0x1410c7fcc*/
  }
  p_bufferedCommands_deprecated = &this->bufferedCommands_deprecated; /*0x1410c7fd1*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedCommands_deprecated.memoryPoolMutex.criticalSection); /*0x1410c7fdc*/
  v22 = DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::Allocate( /*0x1410c7ff6*/
          this: &p_bufferedCommands_deprecated->memoryPool,
          file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
          line: 0x1119u);
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_bufferedCommands_deprecated->memoryPoolMutex.criticalSection); /*0x1410c7ffd*/
  v22->userMemory.stream._Ptr = nullptr; /*0x1410c8009*/
  v22->userMemory.stream._Rep = nullptr; /*0x1410c800c*/
  __wind /*0xf1c0000000000010*/
  {
    RakNet::RakNetGUID::RakNetGUID(this: &v22->userMemory.systemIdentifier.rakNetGuid); /*0x1410c8014*/
    RakNet::SystemAddress::SystemAddress(this: &v22->userMemory.systemIdentifier.systemAddress); /*0x1410c801d*/
    v22->userMemory.data = nullptr; /*0x1410c8022*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)v22); /*0xf1c0000000000008*/
  }
  v23 = (char *)RBX::Memory::allocate(size: v15); /*0x1410c8029*/
  v22->userMemory.data = v23; /*0x1410c802e*/
  if ( v23 != nullptr ) /*0x1410c8035*/
  {
    memcpy_0(a1: v23, Src: data, Size: v15); /*0x1410c80d2*/
    v22->userMemory.numberOfBitsToSend = numberOfBitsToSend; /*0x1410c80dd*/
    v22->userMemory.priority = priority; /*0x1410c80e0*/
    v22->userMemory.reliability = reliability; /*0x1410c80ea*/
    v22->userMemory.orderingChannel = orderingChannel; /*0x1410c80f4*/
    v22->userMemory.systemIdentifier.rakNetGuid.g = systemIdentifier->rakNetGuid.g; /*0x1410c8101*/
    v22->userMemory.systemIdentifier.rakNetGuid.systemIndex = systemIdentifier->rakNetGuid.systemIndex; /*0x1410c8109*/
    RakNet::SystemAddress::operator=( /*0x1410c8115*/
      this: &v22->userMemory.systemIdentifier.systemAddress,
      input: &systemIdentifier->systemAddress);
    v22->userMemory.broadcast = broadcast; /*0x1410c8121*/
    v22->userMemory.connectionMode = connectionMode; /*0x1410c812a*/
    v22->userMemory.receipt = receipt; /*0x1410c8133*/
    v22->userMemory.isJoinData = isJoinData; /*0x1410c8140*/
    v22->userMemory.command = BCS_SEND; /*0x1410c8146*/
    v22->userMemory.queueTime = (unsigned int)RakNet::GetTimeMS(); /*0x1410c8153*/
    DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::BufferedCommandStruct>::Push( /*0x1410c8160*/
      this: (DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput> *)p_bufferedCommands_deprecated,
      s: (RakNet::RakPeer::SocketQueryOutput *)v22);
LABEL_28:
    if ( priority == IMMEDIATE_PRIORITY ) /*0x1410c8168*/
      RakNet::SignaledEvent::SetEvent(this: (rtc::Event *)&this->quitAndDataEvents); /*0x1410c8171*/
    return; /*0x1410c8171*/
  }
  if ( FLog::Network != 0 ) /*0x1410c8044*/
    FLog::FastLogFormatted( /*0x1410c805c*/
      level: FLog::Network,
      message: "[FLog::Network] out of memory in raknet file %s, line %ld",
      "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
      4383);
  v24 = (volatile signed __int32 *)v22->userMemory.stream._Rep; /*0x1410c8061*/
  if ( v24 != nullptr && _InterlockedExchangeAdd(v24 + 2, 0xFFFFFFFF) == 1 ) /*0x1410c8079*/
  {
    (**(void (__fastcall ***)(volatile signed __int32 *))v24)(a1: v24); /*0x1410c8081*/
    if ( _InterlockedExchangeAdd(v24 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c808b*/
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 8LL))(a1: v24); /*0x1410c8093*/
  }
  rtc::CriticalSection::Enter(lpCriticalSection: &p_bufferedCommands_deprecated->memoryPoolMutex.criticalSection); /*0x1410c809a*/
  DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::Release( /*0x1410c80b2*/
    this: &p_bufferedCommands_deprecated->memoryPool,
    m: v22,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
    line: 0x1120u);
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_bufferedCommands_deprecated->memoryPoolMutex.criticalSection); /*0x1410c80bb*/
}

// Address: 0x1410c81a0 | Name: ?SendBufferedShared@RakPeer@RakNet@@IEAAXAEAV?$shared_ptr@$$CBVAbstractBitStream@RakNet@@@std@@IW4PacketPriority@@W4PacketReliability@@DUAddressOrGUID@2@_NW4ConnectMode@RemoteSystemStruct@12@I4@Z
void __fastcall RakNet::RakPeer::SendBufferedShared(
        RakNet::RakPeer *this,
        std::shared_ptr<RakNet::AbstractBitStream const > *bytestream,
        unsigned int numberOfBitsToSend,
        PacketPriority priority,
        PacketReliability reliability,
        char orderingChannel,
        const RakNet::AddressOrGUID *systemIdentifier,
        bool broadcast,
        RakNet::RakPeer::RemoteSystemStruct::ConnectMode connectionMode,
        unsigned int receipt,
        bool isJoinData)
{
  std::_Ref_count_base *Rep; // rcx
  std::_Ref_count_base *v16; // rbx
  RakNet::RakPeer::BufferedCommandStruct *v17; // rax
  signed __int32 v18; // eax
  HANDLE event; // rax
  std::_Ref_count_base *v20; // rbx
  PacketPriority v21; // ebx
  DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::MemoryWithPage *v22; // rsi
  std::_Ref_count_base *v23; // rcx
  volatile signed __int32 *v24; // rbx
  RakNet::RakPeer::BufferedCommandStruct bcs; // [rsp+30h] [rbp-D0h] BYREF
  RakNet::RakPeer::BufferedCommandStruct v26; // [rsp+D0h] [rbp-30h] BYREF

  if ( FFlag::BufferedCommandsCircular.value ) /*0x1410c81d9*/
  {
    bcs.stream = 0; /*0x1410c81e2*/
    __wind /*0xf1c0000000000028*/
    {
      RakNet::RakNetGUID::RakNetGUID(this: &bcs.systemIdentifier.rakNetGuid); /*0x1410c81ed*/
      RakNet::SystemAddress::SystemAddress(this: &bcs.systemIdentifier.systemAddress); /*0x1410c81f7*/
      bcs.data = nullptr; /*0x1410c81ff*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&bcs); /*0xf1c0000000000038*/
    }
    __wind /*0xf1c0000000000040*/
    {
      Rep = bytestream->_Rep; /*0x1410c8203*/
      if ( Rep != nullptr ) /*0x1410c820a*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410c820c*/
        Rep = bytestream->_Rep; /*0x1410c8210*/
      }
      bcs.stream._Ptr = bytestream->_Ptr; /*0x1410c8217*/
      v16 = bcs.stream._Rep; /*0x1410c821c*/
      bcs.stream._Rep = Rep; /*0x1410c8221*/
      if ( v16 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v16->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410c823a*/
      {
        v16->_Destroy(this: v16); /*0x1410c8242*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v16->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c824e*/
          v16->_Delete_this(this: v16); /*0x1410c8256*/
      }
      bcs.data = (char *)bytestream->_Ptr->GetData(this: bytestream->_Ptr); /*0x1410c8262*/
      bcs.numberOfBitsToSend = numberOfBitsToSend; /*0x1410c8266*/
      bcs.priority = priority; /*0x1410c826b*/
      bcs.reliability = reliability; /*0x1410c8275*/
      bcs.orderingChannel = orderingChannel; /*0x1410c8280*/
      bcs.systemIdentifier.rakNetGuid.g = systemIdentifier->rakNetGuid.g; /*0x1410c828e*/
      bcs.systemIdentifier.rakNetGuid.systemIndex = systemIdentifier->rakNetGuid.systemIndex; /*0x1410c8297*/
      RakNet::SystemAddress::operator=( /*0x1410c82a5*/
        this: &bcs.systemIdentifier.systemAddress,
        input: &systemIdentifier->systemAddress);
      bcs.broadcast = broadcast; /*0x1410c82b1*/
      bcs.connectionMode = connectionMode; /*0x1410c82ba*/
      bcs.receipt = receipt; /*0x1410c82c3*/
      bcs.isJoinData = isJoinData; /*0x1410c82cd*/
      bcs.command = BCS_SEND; /*0x1410c82d0*/
      bcs.queueTime = (unsigned int)RakNet::GetTimeMS(); /*0x1410c82db*/
      boost::detail::basic_timed_mutex::lock(this: &this->bufferedCommandsMutex); /*0x1410c82e9*/
      v17 = RakNet::RakPeer::BufferedCommandStruct::BufferedCommandStruct(this: &v26, __that: &bcs); /*0x1410c82f7*/
      RBX::UnboundedCircularBuffer<RakNet::RakPeer::BufferedCommandStruct>::push_back( /*0x1410c8306*/
        this: &this->bufferedCommandsCircular,
        item: v17);
      v18 = _InterlockedExchangeAdd(&this->bufferedCommandsMutex.active_count, 0x80000000); /*0x1410c8310*/
      if ( (v18 & 0x40000000) == 0 /*0x1410c8326*/
        && v18 != 0x80000000
        && !_interlockedbittestandset(&this->bufferedCommandsMutex.active_count, 0x1Eu) )
      {
        event = boost::detail::basic_timed_mutex::get_event(this: &this->bufferedCommandsMutex); /*0x1410c832b*/
        SetEvent(hEvent: event); /*0x1410c8333*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&bcs); /*0xf1c0000000000020*/
    }
    v20 = bcs.stream._Rep; /*0x1410c833a*/
    if ( bcs.stream._Rep != nullptr /*0x1410c834e*/
      && _InterlockedExchangeAdd((volatile signed __int32 *)&bcs.stream._Rep->_Uses, 0xFFFFFFFF) == 1 )
    {
      v20->_Destroy(this: v20); /*0x1410c8356*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c8360*/
        v20->_Delete_this(this: v20); /*0x1410c8368*/
    }
    v21 = priority; /*0x1410c836b*/
  }
  else
  {
    rtc::CriticalSection::Enter(lpCriticalSection: &this->bufferedCommands_deprecated.memoryPoolMutex.criticalSection); /*0x1410c83a3*/
    v22 = DataStructures::MemoryPool<RakNet::RakPeer::BufferedCommandStruct>::Allocate( /*0x1410c83c1*/
            this: &this->bufferedCommands_deprecated.memoryPool,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
            line: 0x1158u);
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->bufferedCommands_deprecated.memoryPoolMutex.criticalSection); /*0x1410c83cb*/
    v22->userMemory.stream._Ptr = nullptr; /*0x1410c83d8*/
    v22->userMemory.stream._Rep = nullptr; /*0x1410c83db*/
    __wind /*0xf1c0000000000010*/
    {
      RakNet::RakNetGUID::RakNetGUID(this: &v22->userMemory.systemIdentifier.rakNetGuid); /*0x1410c83e3*/
      RakNet::SystemAddress::SystemAddress(this: &v22->userMemory.systemIdentifier.systemAddress); /*0x1410c83ec*/
      v22->userMemory.data = nullptr; /*0x1410c83f1*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)v22); /*0xf1c0000000000008*/
    }
    v23 = bytestream->_Rep; /*0x1410c83f5*/
    if ( v23 != nullptr ) /*0x1410c83fc*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&v23->_Uses); /*0x1410c83fe*/
      v23 = bytestream->_Rep; /*0x1410c8402*/
    }
    v22->userMemory.stream._Ptr = bytestream->_Ptr; /*0x1410c8409*/
    v24 = (volatile signed __int32 *)v22->userMemory.stream._Rep; /*0x1410c840c*/
    v22->userMemory.stream._Rep = v23; /*0x1410c8410*/
    if ( v24 != nullptr && _InterlockedExchangeAdd(v24 + 2, 0xFFFFFFFF) == 1 ) /*0x1410c8428*/
    {
      (**(void (__fastcall ***)(volatile signed __int32 *))v24)(a1: v24); /*0x1410c8430*/
      if ( _InterlockedExchangeAdd(v24 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c843a*/
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 8LL))(a1: v24); /*0x1410c8442*/
    }
    v22->userMemory.data = (char *)bytestream->_Ptr->GetData(this: bytestream->_Ptr); /*0x1410c844e*/
    v22->userMemory.numberOfBitsToSend = numberOfBitsToSend; /*0x1410c8458*/
    v21 = priority; /*0x1410c845b*/
    v22->userMemory.priority = priority; /*0x1410c8461*/
    v22->userMemory.reliability = reliability; /*0x1410c846a*/
    v22->userMemory.orderingChannel = orderingChannel; /*0x1410c8474*/
    v22->userMemory.systemIdentifier.rakNetGuid.g = systemIdentifier->rakNetGuid.g; /*0x1410c8481*/
    v22->userMemory.systemIdentifier.rakNetGuid.systemIndex = systemIdentifier->rakNetGuid.systemIndex; /*0x1410c8489*/
    RakNet::SystemAddress::operator=( /*0x1410c8495*/
      this: &v22->userMemory.systemIdentifier.systemAddress,
      input: &systemIdentifier->systemAddress);
    v22->userMemory.broadcast = broadcast; /*0x1410c84a1*/
    v22->userMemory.connectionMode = connectionMode; /*0x1410c84aa*/
    v22->userMemory.receipt = receipt; /*0x1410c84b3*/
    v22->userMemory.isJoinData = isJoinData; /*0x1410c84c0*/
    v22->userMemory.command = BCS_SEND; /*0x1410c84c6*/
    v22->userMemory.queueTime = (unsigned int)RakNet::GetTimeMS(); /*0x1410c84d4*/
    DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::BufferedCommandStruct>::Push( /*0x1410c84e5*/
      this: (DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput> *)&this->bufferedCommands_deprecated,
      s: (RakNet::RakPeer::SocketQueryOutput *)v22);
  }
  if ( v21 == IMMEDIATE_PRIORITY ) /*0x1410c8373*/
    RakNet::SignaledEvent::SetEvent(this: (rtc::Event *)&this->quitAndDataEvents); /*0x1410c837c*/
}

// Address: 0x1410c84f0 | Name: ?SendConnectionRequest@RakPeer@RakNet@@IEAA?AW4ConnectionAttemptResult@2@PEBDG0HPEAUPublicKey@2@IIIII@Z
__int64 __fastcall RakNet::RakPeer::SendConnectionRequest(
        RakNet::RakPeer *this,
        const char *host,
        unsigned __int16 remotePort,
        const char *passwordData,
        int passwordDataLength,
        RakNet::PublicKey *publicKey,
        unsigned int connectionSocketIndex,
        unsigned int extraData,
        unsigned int sendConnectionAttemptCount,
        unsigned int timeBetweenSendConnectionAttemptsMS,
        unsigned int timeoutTime)
{
  unsigned int v16; // r14d
  unsigned int v17; // ebx
  bool i; // cf
  __int64 v19; // rdi
  RakNet::RakPeer::RequestedConnectionStruct *v20; // rax
  RakNet::RakPeer::RequestedConnectionStruct *v21; // rdi
  RBX::Graphics::TextureVulkan::DownloadBuffer *v22; // rax
  RBX::Graphics::TextureVulkan::DownloadBuffer *v23; // rbx
  _DWORD *v24; // rax
  volatile signed __int32 *Rep; // rbx
  bool isRbxConnection; // dl
  unsigned int head; // r8d
  unsigned int tail; // ecx
  unsigned int v29; // ecx
  unsigned int v30; // edx
  unsigned int v31; // r8d
  unsigned int v32; // ebx
  volatile signed __int32 *v33; // rbx
  volatile signed __int32 *v34; // rbx
  unsigned __int8 *Myfirst; // rcx
  RakNet::RakPeer::RequestedConnectionStruct *rcs; // [rsp+20h] [rbp-99h] BYREF
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> v37; // [rsp+28h] [rbp-91h] BYREF
  RBX::ArrayView<unsigned char> v38; // [rsp+30h] [rbp-89h]
  RakNet::SystemAddress systemAddress; // [rsp+40h] [rbp-79h] BYREF
  RBX::Security::KeyRing::KeyInfo keyInfo; // [rsp+60h] [rbp-59h] BYREF
  _DWORD *v41; // [rsp+80h] [rbp-39h]
  RBX::ArrayView<unsigned char> v42; // [rsp+90h] [rbp-29h] BYREF
  RakNet::SystemAddress right; // [rsp+A0h] [rbp-19h] BYREF

  RakNet::SystemAddress::SystemAddress(this: &systemAddress); /*0x1410c8525*/
  if ( !RakNet::SystemAddress::FromStringExplicitPort(this: &systemAddress, str: host, port: remotePort) ) /*0x1410c8535*/
    return 2; /*0x1410c853e*/
  right = systemAddress; /*0x1410c854c*/
  v16 = 0; /*0x1410c8568*/
  if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410c856d*/
  {
    v17 = 0; /*0x1410c856f*/
    for ( i = this->maximumNumberOfPeers != 0; i; i = v17 < this->maximumNumberOfPeers ) /*0x1410c8572*/
    {
      v19 = (int)v17; /*0x1410c857c*/
      if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v19].systemAddress, &right) != 0 /*0x1410c85a5*/
        && this->remoteSystemList[v19].isActive._Storage._Value )
      {
        if ( &this->remoteSystemList[v19] == nullptr ) /*0x1410c85c2*/
          break; /*0x1410c85c2*/
        return 3; /*0x1410c85c9*/
      }
      ++v17; /*0x1410c85ae*/
    }
  }
  v20 = (RakNet::RakPeer::RequestedConnectionStruct *)operator new(size: 0x180u); /*0x1410c85ce*/
  v21 = v20; /*0x1410c85d8*/
  rcs = v20; /*0x1410c85db*/
  __wind /*0xf1c000000000006c*/
  {
    if ( v20 != nullptr ) /*0x1410c85e3*/
    {
      RakNet::SystemAddress::SystemAddress(this: &v20->systemAddress); /*0x1410c85e8*/
      v21->socket._Ptr = nullptr; /*0x1410c85ed*/
      v21->socket._Rep = nullptr; /*0x1410c85f4*/
      v21->rbxSessionCrypto._Ptr = nullptr; /*0x1410c85fb*/
      v21->rbxSessionCrypto._Rep = nullptr; /*0x1410c8602*/
    }
    else
    {
      v21 = nullptr; /*0x1410c860b*/
    }
  }
  __unwind
  {
    operator delete(ptr: rcs); /*0x1431ed062*/
  }
  rcs = v21; /*0x1410c860e*/
  RakNet::SystemAddress::operator=(this: &v21->systemAddress, input: &systemAddress); /*0x1410c861a*/
  v21->nextRequestTime = (unsigned int)RakNet::GetTimeMS(); /*0x1410c8626*/
  v21->requestsMade = 0; /*0x1410c862a*/
  v21->data = nullptr; /*0x1410c862e*/
  v21->extraData = extraData; /*0x1410c8635*/
  v21->socketIndex = connectionSocketIndex; /*0x1410c863e*/
  v21->actionToTake = CONNECT; /*0x1410c8644*/
  v21->sendConnectionAttemptCount = sendConnectionAttemptCount; /*0x1410c8651*/
  v21->timeBetweenSendConnectionAttemptsMS = timeBetweenSendConnectionAttemptsMS; /*0x1410c865a*/
  memcpy_0(a1: v21->outgoingPassword, Src: passwordData, Size: passwordDataLength); /*0x1410c866e*/
  v21->outgoingPasswordLength = passwordDataLength; /*0x1410c8673*/
  v21->timeoutTime = timeoutTime; /*0x1410c867f*/
  v22 = (RBX::Graphics::TextureVulkan::DownloadBuffer *)operator new(size: 0x80u); /*0x1410c868a*/
  v23 = v22; /*0x1410c868f*/
  v37._Ptr = v22; /*0x1410c8692*/
  __wind /*0xf1c0000000000054*/
  {
    if ( v22 != nullptr ) /*0x1410c869a*/
    {
      RBX::Security::SessionCrypto::SessionCrypto(this: (RBX::Security::SessionCrypto *)v22); /*0x1410c869f*/
      v23->__vftable = (RBX::Graphics::TextureVulkan::DownloadBuffer_vtbl *)RBX::Security::RakPeerCrypto::`vftable'; /*0x1410c86ab*/
    }
    else
    {
      v23 = nullptr; /*0x1410c86b0*/
    }
  }
  __unwind
  {
    operator delete(ptr: v37._Ptr); /*0x14315b802*/
  }
  v37._Ptr = v23; /*0x1410c86b3*/
  __wind /*0xf1c000000000003c*/
  {
    v24 = operator new(size: 0x18u); /*0x1410c86bd*/
    v41 = v24; /*0x1410c86c2*/
    if ( v24 != nullptr ) /*0x1410c86c9*/
    {
      *(_OWORD *)v24 = 0; /*0x1410c86ce*/
      v24[2] = 1; /*0x1410c86d1*/
      v24[3] = 1; /*0x1410c86d8*/
      *(_QWORD *)v24 = std::_Ref_count<RBX::Security::RakPeerCrypto>::`vftable'; /*0x1410c86e6*/
      *((_QWORD *)v24 + 2) = v23; /*0x1410c86e9*/
    }
    else
    {
      v24 = nullptr; /*0x1410c86ef*/
    }
    v21->rbxSessionCrypto._Ptr = (RBX::Security::RakPeerCrypto *)v23; /*0x1410c86f2*/
    Rep = (volatile signed __int32 *)v21->rbxSessionCrypto._Rep; /*0x1410c86f9*/
    v21->rbxSessionCrypto._Rep = (std::_Ref_count_base *)v24; /*0x1410c8700*/
    if ( Rep != nullptr && _InterlockedExchangeAdd(Rep + 2, 0xFFFFFFFF) == 1 ) /*0x1410c871d*/
    {
      (**(void (__fastcall ***)(volatile signed __int32 *))Rep)(a1: Rep); /*0x1410c8725*/
      if ( _InterlockedExchangeAdd(Rep + 3, 0xFFFFFFFF) == 1 ) /*0x1410c8732*/
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)Rep + 8LL))(a1: Rep); /*0x1410c873a*/
    }
    isRbxConnection = this->isRbxConnection; /*0x1410c873d*/
  }
  __unwind
  {
    RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: &v37); /*0xf1c0000000000034*/
  }
  RBX::Security::RakPeerCrypto::getClientKeyInfo(result: &keyInfo, useRccKey: isRbxConnection); /*0x1410c8748*/
  v38.buffer = keyInfo.value._Mypair._Myval2._Myfirst; /*0x1410c8759*/
  v38.length = keyInfo.value._Mypair._Myval2._Mylast - keyInfo.value._Mypair._Myval2._Myfirst; /*0x1410c875e*/
  v42 = v38; /*0x1410c8768*/
  __wind
  {
    RBX::Security::RakPeerCrypto::initClient(this: v21->rbxSessionCrypto._Ptr, publicEarlyKey: &v42); /*0x1410c8778*/
    v21->earlyPublicKeyVersion = keyInfo.id; /*0x1410c8780*/
    v32 = 0; /*0x1410c8786*/
    rtc::CriticalSection::Enter(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410c8790*/
    while ( 1 )
    {
      head = this->requestedConnectionQueue.head; /*0x1410c87a0*/
      tail = this->requestedConnectionQueue.tail; /*0x1410c87a7*/
      v29 = head > tail ? this->requestedConnectionQueue.allocation_size - head + tail : tail - head;
      if ( v32 >= v29 ) /*0x1410c87c4*/
        break; /*0x1410c87c4*/
      v30 = head + v32; /*0x1410c87ca*/
      v31 = v32 + head - this->requestedConnectionQueue.allocation_size; /*0x1410c87dc*/
      if ( v30 >= this->requestedConnectionQueue.allocation_size ) /*0x1410c87e5*/
        v30 = v31; /*0x1410c87e5*/
      if ( RakNet::SystemAddress::operator==( /*0x1410c87fa*/
             this: &this->requestedConnectionQueue.array[v30]->systemAddress,
             right: &systemAddress) != 0 )
      {
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410c8807*/
        v33 = (volatile signed __int32 *)v21->rbxSessionCrypto._Rep; /*0x1410c880c*/
        if ( v33 != nullptr && _InterlockedExchangeAdd(v33 + 2, 0xFFFFFFFF) == 1 ) /*0x1410c8823*/
        {
          (**(void (__fastcall ***)(volatile signed __int32 *))v33)(a1: v33); /*0x1410c882b*/
          if ( _InterlockedExchangeAdd(v33 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c8838*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v33 + 8LL))(a1: v33); /*0x1410c8840*/
        }
        v34 = (volatile signed __int32 *)v21->socket._Rep; /*0x1410c8843*/
        if ( v34 != nullptr && _InterlockedExchangeAdd(v34 + 2, 0xFFFFFFFF) == 1 ) /*0x1410c885a*/
        {
          (**(void (__fastcall ***)(volatile signed __int32 *))v34)(a1: v34); /*0x1410c8862*/
          if ( _InterlockedExchangeAdd(v34 + 3, 0xFFFFFFFF) == 1 ) /*0x1410c886e*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v34 + 8LL))(a1: v34); /*0x1410c8876*/
        }
        operator delete(ptr: v21); /*0x1410c8881*/
        v16 = 4; /*0x1410c8886*/
        goto LABEL_55; /*0x1410c888c*/
      }
      ++v32; /*0x1410c87fc*/
    }
    if ( DFLog::RakNetConnectTrace != 0 )
      FLog::FastLogFormatted(
        level: DFLog::RakNetConnectTrace,
        message: "[DFLog::RakNetConnectTrace] RakNet: Added connect request to queue");
    DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::Push( /*0x1410c88c0*/
      this: (DataStructures::Queue<RakNet::InternalPacket *> *)&this->requestedConnectionQueue,
      input: (RakNet::InternalPacket **)&rcs,
      file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
      line: 0xD7Bu);
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410c88cc*/
  }
  __unwind
  {
    RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&keyInfo); /*0xf1c000000000001c*/
  }
LABEL_55:
  Myfirst = keyInfo.value._Mypair._Myval2._Myfirst; /*0x1410c88d2*/
  if ( keyInfo.value._Mypair._Myval2._Myfirst != nullptr ) /*0x1410c88d9*/
  {
    if ( (unsigned __int8 *)(keyInfo.value._Mypair._Myval2._Myend - keyInfo.value._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x1410c88ec*/
    {
      Myfirst = *((unsigned __int8 **)keyInfo.value._Mypair._Myval2._Myfirst - 1); /*0x1410c88f2*/
      if ( (unsigned __int64)(keyInfo.value._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x1410c8901*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410c8903*/
    }
    operator delete(ptr: Myfirst); /*0x1410c890a*/
  }
  return v16; /*0x1410c8912*/
}

// Address: 0x1410c8940 | Name: ?SendImmediate@RakPeer@RakNet@@IEAA_NPEADIW4PacketPriority@@W4PacketReliability@@DUAddressOrGUID@2@_N4_KI4@Z
char __fastcall RakNet::RakPeer::SendImmediate(
        RakNet::RakPeer *this,
        char *data,
        unsigned int numberOfBitsToSend,
        PacketPriority priority,
        PacketReliability reliability,
        char orderingChannel,
        RBX::json::ArrayIterator *systemIdentifier,
        bool broadcast,
        bool useCallerDataAllocation,
        unsigned __int64 currentTime,
        unsigned int receipt,
        bool isJoinData)
{
  int v12; // r12d
  unsigned int v14; // r14d
  __int128 v15; // xmm1
  unsigned int systemIndex; // ebx
  unsigned int *v17; // r15
  __int64 v18; // rdx
  unsigned __int64 v19; // rax
  __int64 v20; // rcx
  void *v21; // rsp
  void *v22; // rsp
  unsigned int v23; // esi
  __int64 v24; // rdx
  __int64 v25; // rax
  unsigned int i; // ebx
  bool v27; // si
  RBX::Network::Rupp::Rupp *Ptr; // rcx
  int ruppLength; // r9d
  RakNet::RakPeer::RemoteSystemStruct *v30; // rdx
  int v31; // eax
  char v32; // r12
  unsigned int v34; // [rsp+50h] [rbp-10h] BYREF
  _DWORD v35[4]; // [rsp+60h] [rbp+0h] BYREF
  RakNet::SystemAddress right; // [rsp+70h] [rbp+10h] BYREF

  LOBYTE(v12) = 0; /*0x1410c897b*/
  v35[0] = v12; /*0x1410c8981*/
  v14 = 0; /*0x1410c8985*/
  if ( RakNet::SystemAddress::operator!=( /*0x1410c8993*/
         this: (RakNet::SystemAddress *)&systemIdentifier[2],
         right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 )
  {
    v15 = *(_OWORD *)&systemIdentifier[4].it; /*0x1410c89a4*/
    *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&systemIdentifier[2].it; /*0x1410c89ac*/
    *((_OWORD *)&right.address.addr4 + 1) = v15; /*0x1410c89b0*/
    if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410c89bb*/
    {
      systemIndex = -1; /*0x1410c89bd*/
    }
    else if ( right.systemIndex != 0xFFFF /*0x1410c8a07*/
           && right.systemIndex < this->maximumNumberOfPeers
           && RakNet::SystemAddress::operator==(this: &this->remoteSystemList[right.systemIndex].systemAddress, &right) != 0
           && this->remoteSystemList[right.systemIndex].isActive._Storage._Value )
    {
      systemIndex = right.systemIndex; /*0x1410c8a16*/
    }
    else
    {
      systemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, sa: &right); /*0x1410c8a2b*/
    }
  }
  else
  {
    if ( !StudioResourceId::operator!=( /*0x1410c8a3c*/
            this: systemIdentifier,
            rhs: (const RBX::json::ArrayIterator *)&RakNet::UNASSIGNED_RAKNET_GUID_30) )
      goto LABEL_20; /*0x1410c8a3c*/
    *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&systemIdentifier->it; /*0x1410c8a57*/
    if ( StudioResourceId::operator==(lhs: &right, rhs: &RakNet::UNASSIGNED_RAKNET_GUID_30) /*0x1410c8a73*/
      || StudioResourceId::operator==(lhs: &right, rhs: &this->myGuid) )
    {
      goto LABEL_20; /*0x1410c8a73*/
    }
    if ( right.address.addr6.sin6_addr.u.Word[0] != 0xFFFF /*0x1410c8aaf*/
      && right.address.addr6.sin6_addr.u.Word[0] < this->maximumNumberOfPeers
      && StudioResourceId::operator==(
           lhs: &this->remoteSystemList[right.address.addr6.sin6_addr.u.Word[0]].guid,
           rhs: &right) )
    {
      systemIndex = right.address.addr6.sin6_addr.u.Word[0]; /*0x1410c8ab8*/
      goto LABEL_21; /*0x1410c8abc*/
    }
    systemIndex = 0; /*0x1410c8abe*/
    if ( this->maximumNumberOfPeers == 0 ) /*0x1410c8ac6*/
    {
LABEL_20:
      systemIndex = -1; /*0x1410c8b00*/
    }
    else
    {
      while ( !StudioResourceId::operator==(lhs: &this->remoteSystemList[systemIndex].guid, rhs: &right) ) /*0x1410c8af4*/
      {
        if ( ++systemIndex >= this->maximumNumberOfPeers ) /*0x1410c8afe*/
          goto LABEL_20; /*0x1410c8afe*/
      }
    }
  }
LABEL_21:
  if ( broadcast ) /*0x1410c8b12*/
  {
    v19 = 4LL * this->maximumNumberOfPeers; /*0x1410c8b73*/
    v20 = v19 + 15; /*0x1410c8b77*/
    if ( v19 + 15 < v19 ) /*0x1410c8b7e*/
      v20 = 0xFFFFFFFFFFFFFF0LL; /*0x1410c8b80*/
    v21 = alloca(v20 & 0xFFFFFFFFFFFFFFF0uLL); /*0x1410c8b91*/
    v22 = alloca(v20 & 0xFFFFFFFFFFFFFFF0uLL); /*0x1410c8b96*/
    v23 = 0; /*0x1410c8b99*/
    v17 = v35; /*0x1410c8b9c*/
    if ( this->maximumNumberOfPeers != 0 ) /*0x1410c8ba5*/
    {
      do /*0x1410c8c02*/
      {
        if ( systemIndex == -1 || v23 != systemIndex ) /*0x1410c8bb7*/
        {
          v24 = v23; /*0x1410c8bbb*/
          if ( this->remoteSystemList[v24].isActive._Storage._Value /*0x1410c8bee*/
            && RakNet::SystemAddress::operator!=(
                 this: &this->remoteSystemList[v24].systemAddress,
                 right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 )
          {
            v25 = v14++; /*0x1410c8bf0*/
            v35[v25] = v23; /*0x1410c8bf6*/
          }
        }
        ++v23; /*0x1410c8bfe*/
      }
      while ( v23 < this->maximumNumberOfPeers ); /*0x1410c8c02*/
      if ( v14 != 0 ) /*0x1410c8c07*/
        goto LABEL_36; /*0x1410c8c07*/
    }
    return 0; /*0x1410c8d65*/
  }
  if ( systemIndex == -1 ) /*0x1410c8b17*/
    return 0; /*0x1410c8b17*/
  v17 = &v34; /*0x1410c8b24*/
  v18 = systemIndex; /*0x1410c8b2e*/
  if ( !this->remoteSystemList[v18].isActive._Storage._Value /*0x1410c8b5c*/
    || (unsigned int)(this->remoteSystemList[v18].connectMode - 1) <= 2 )
  {
    return 0; /*0x1410c8b5c*/
  }
  v34 = systemIndex; /*0x1410c8b62*/
  v14 = 1; /*0x1410c8b65*/
LABEL_36:
  for ( i = 0; i < v14; ++i ) /*0x1410c8c14*/
  {
    v27 = useCallerDataAllocation && LOBYTE(v35[0]) == 0 && i + 1 == v14; /*0x1410c8c37*/
    if ( DFFlag::RuppHeaderFromClientEnabled3.value && (Ptr = this->ruppHeader._Ptr) != nullptr ) /*0x1410c8c52*/
      ruppLength = RBX::Network::Rupp::Rupp::getHeaderTotalByteLength(this: Ptr); /*0x1410c8c59*/
    else
      ruppLength = 0; /*0x1410c8c5f*/
    v30 = &this->remoteSystemList[*v17]; /*0x1410c8c7b*/
    RakNet::ReliabilityLayer::Send( /*0x1410c8cd2*/
      this: (RakNet::ReliabilityLayer *)((char *)&v30->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
      data,
      numberOfBitsToSend,
      priority,
      reliability,
      orderingChannel,
      makeDataCopy: !v27,
      MTUSize: v30->MTUSize,
      currentTime,
      receipt,
      ruppLength,
      isJoinData);
    v31 = LOBYTE(v35[0]); /*0x1410c8cdd*/
    if ( v27 ) /*0x1410c8ce6*/
      v31 = 1; /*0x1410c8ce6*/
    v35[0] = v31; /*0x1410c8cea*/
    if ( (unsigned int)(reliability - 2) <= 2 || (unsigned int)(reliability - 6) <= 1 ) /*0x1410c8cfd*/
      this->remoteSystemList[*v17].lastReliableSend = (unsigned int)(currentTime / 0x3E8); /*0x1410c8d2f*/
    ++v17; /*0x1410c8d39*/
  }
  v32 = v35[0]; /*0x1410c8d4d*/
  if ( priority == IMMEDIATE_PRIORITY ) /*0x1410c8d51*/
    RakNet::SignaledEvent::SetEvent(this: (rtc::Event *)&this->quitAndDataEvents); /*0x1410c8d5a*/
  return v32; /*0x1410c8d67*/
}

// Address: 0x1410c8d80 | Name: ?SendLoopback@RakPeer@RakNet@@UEAAXPEBDH@Z
void __fastcall RakNet::RakPeer::SendLoopback(RakNet::RakPeer *this, const char *data, signed int length)
{
  size_t v3; // rdi
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v6; // rbx
  __int128 v7; // xmm1
  RakNet::SystemAddress input; // [rsp+20h] [rbp-28h] BYREF

  if ( data != nullptr ) /*0x1410c8d83*/
  {
    v3 = length; /*0x1410c8d98*/
    if ( length >= 0 ) /*0x1410c8da4*/
    {
      v6 = RakNet::RakPeer::AllocPacket( /*0x1410c8dc5*/
             this,
             dataSize: length,
             file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
             line: 0x5C4u);
      memcpy_0(a1: v6->userMemory.data, Src: data, Size: v3); /*0x1410c8dcc*/
      v7 = *((_OWORD *)&this->ipList[0].address.addr4 + 1); /*0x1410c8de0*/
      *(_OWORD *)&input.address.addr6.sin6_family = *(_OWORD *)&this->ipList[0].address.addr6.sin6_family; /*0x1410c8de7*/
      *((_OWORD *)&input.address.addr4 + 1) = v7; /*0x1410c8dec*/
      RakNet::SystemAddress::operator=(this: &v6->userMemory.systemAddress, &input); /*0x1410c8df1*/
      v6->userMemory.guid = this->myGuid; /*0x1410c8e00*/
      this->PushBackPacket(this, a2: (RakNet::Packet *)v6, a3: false); /*0x1410c8e18*/
    }
  }
}

// Address: 0x1410c8e40 | Name: ?SetArtificialLatency@RakPeer@RakNet@@UEAAX_K0@Z
void __fastcall RakNet::RakPeer::SetArtificialLatency(
        RakNet::RakPeer *this,
        const void *newTxlatency,
        const void *newRxlatency)
{
  if ( FLog::Network != 0 )
    FLog::FastLog(
      level: FLog::Network,
      message: "[FLog::Network] Setting latency from Ixp tx: %llu rx: %llu",
      arg0: newTxlatency,
      arg1: newRxlatency,
      arg2: nullptr);
  this->latencyTx._Storage._Value = (unsigned __int64)newTxlatency; /*0x1410c8e7e*/
  this->latencyRx._Storage._Value = (unsigned __int64)newRxlatency; /*0x1410c8e85*/
}

// Address: 0x1410c8ea0 | Name: ?SetIncomingPassword@RakPeer@RakNet@@UEAAXPEBDH@Z
void __fastcall RakNet::RakPeer::SetIncomingPassword(
        RakNet::RakPeer *this,
        const char *passwordData,
        int passwordDataLength)
{
  int v3; // eax
  int v5; // ebx

  v3 = 255; /*0x1410c8eaa*/
  if ( passwordDataLength <= 255 ) /*0x1410c8eb5*/
    v3 = passwordDataLength; /*0x1410c8eb5*/
  v5 = 0; /*0x1410c8eb9*/
  if ( passwordData != nullptr ) /*0x1410c8ebe*/
    v5 = v3; /*0x1410c8ebe*/
  if ( v5 <= 0 ) /*0x1410c8ec3*/
  {
    this->incomingPasswordLength = v5; /*0x1410c8ee5*/
  }
  else
  {
    memcpy_0(a1: this->incomingPassword, Src: passwordData, Size: v5); /*0x1410c8ecf*/
    this->incomingPasswordLength = v5; /*0x1410c8ed4*/
  }
}

// Address: 0x1410c8f00 | Name: ?SetLimitIPConnectionFrequency@RakPeer@RakNet@@UEAAX_N@Z
void __fastcall RakNet::RakPeer::SetLimitIPConnectionFrequency(RakNet::RakPeer *this, bool b)
{
  this->limitConnectionFrequencyFromTheSameIP = b; /*0x1410c8f00*/
}

// Address: 0x1410c8f10 | Name: ?SetMaximumIncomingConnections@RakPeer@RakNet@@UEAAXG@Z
void __fastcall RakNet::RakPeer::SetMaximumIncomingConnections(RakNet::RakPeer *this, unsigned __int16 numberAllowed)
{
  this->maximumIncomingConnections = numberAllowed; /*0x1410c8f10*/
}

// Address: 0x1410c8f20 | Name: ?SetOccasionalPing@RakPeer@RakNet@@UEAAX_N@Z
void __fastcall RakNet::RakPeer::SetOccasionalPing(RakNet::RakPeer *this, bool doPing)
{
  this->occasionalPing = doPing; /*0x1410c8f20*/
}

// Address: 0x1410c8f30 | Name: ?SetOfflinePingResponse@RakPeer@RakNet@@UEAAXPEBDI@Z
void __fastcall RakNet::RakPeer::SetOfflinePingResponse(RakNet::RakPeer *this, const char *data, unsigned int length)
{
  rtc::CriticalSection::Enter(lpCriticalSection: &this->rakPeerMutexes[1].criticalSection); /*0x1410c8f54*/
  RakNet::BitStream::Reset(this: &this->offlinePingResponse); /*0x1410c8f5d*/
  if ( data != nullptr && length != 0 ) /*0x1410c8f69*/
    RakNet::BitStream::Write(this: &this->offlinePingResponse, inputByteArray: data, numberOfBytes: length); /*0x1410c8f75*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->rakPeerMutexes[1].criticalSection); /*0x1410c8f95*/
}

// Address: 0x1410c8fa0 | Name: ?SetPeerBandwidthLimit@RakPeer@RakNet@@UEAAXUSystemAddress@2@I@Z
void __fastcall RakNet::RakPeer::SetPeerBandwidthLimit(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *target,
        unsigned int maxBitsPerSecond)
{
  unsigned __int16 v6; // bx

  if ( this->remoteSystemList != nullptr ) /*0x1410c8fc1*/
  {
    v6 = 0; /*0x1410c8fc8*/
    if ( this->maximumNumberOfPeers != 0 ) /*0x1410c8fce*/
    {
      while ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v6].systemAddress, right: target) == 0 ) /*0x1410c9002*/
      {
        if ( ++v6 >= this->maximumNumberOfPeers ) /*0x1410c900b*/
          return; /*0x1410c900b*/
      }
      this->remoteSystemList[v6].remoteSystemBPSLimit = maxBitsPerSecond; /*0x1410c901d*/
    }
  }
}

// Address: 0x1410c9040 | Name: ?SetPeerPlugin@RakPeer@RakNet@@UEAAXPEAVPeer@Network@RBX@@@Z
void __fastcall RakNet::RakPeer::SetPeerPlugin(RakNet::RakPeer *this, RBX::Network::Peer *setPeerPlugin)
{
  this->peerPlugin = setPeerPlugin; /*0x1410c9040*/
}

// Address: 0x1410c9050 | Name: ?SetPerConnectionOutgoingBandwidthLimit@RakPeer@RakNet@@UEAAXI@Z
void __fastcall RakNet::RakPeer::SetPerConnectionOutgoingBandwidthLimit(
        RakNet::RakPeer *this,
        unsigned int maxBitsPerSecond)
{
  this->maxOutgoingBPS = maxBitsPerSecond; /*0x1410c9050*/
}

// Address: 0x1410c9060 | Name: ?SetSplitMessageProgressInterval@RakPeer@RakNet@@UEAAXH@Z
void __fastcall RakNet::RakPeer::SetSplitMessageProgressInterval(RakNet::RakPeer *this, int interval)
{
  unsigned __int16 v2; // bx

  v2 = 0; /*0x1410c906a*/
  for ( this->splitMessageProgressInterval = interval; v2 < this->maximumNumberOfPeers; ++v2 ) /*0x1410c9079*/
    RakNet::ReliabilityLayer::SetSplitMessageProgressInterval( /*0x1410c90a0*/
      this: (RakNet::ReliabilityLayer *)((char *)&this->remoteSystemList->reliabilityLayer.rbxSessionCrypto._Ptr
                                 + 4600 * v2
                                 + 4),
      interval: this->splitMessageProgressInterval);
}

// Address: 0x1410c90c0 | Name: ?SetTimeoutTime@RakPeer@RakNet@@UEAAXIUSystemAddress@2@@Z
void __fastcall RakNet::RakPeer::SetTimeoutTime(
        RakNet::RakPeer *this,
        unsigned int timeMS,
        RakNet::SystemAddress *target)
{
  unsigned int v6; // ebx
  __int64 v7; // rdx
  __int128 v8; // xmm1
  int v9; // ebx
  __int64 v10; // rsi
  RakNet::RakPeer::RemoteSystemStruct *v11; // rcx
  RakNet::SystemAddress right; // [rsp+20h] [rbp-28h] BYREF

  if ( RakNet::SystemAddress::operator==(this: target, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410c90e8*/
  {
    v6 = 0; /*0x1410c90ea*/
    for ( this->defaultTimeoutTime = timeMS; v6 < this->maximumNumberOfPeers; ++v6 ) /*0x1410c90f6*/
    {
      v7 = v6; /*0x1410c9102*/
      if ( this->remoteSystemList[v7].isActive._Storage._Value ) /*0x1410c9110*/
        RakNet::ReliabilityLayer::SetTimeoutTime( /*0x1410c913c*/
          this: (RakNet::ReliabilityLayer *)((char *)&this->remoteSystemList->reliabilityLayer.rbxSessionCrypto._Ptr
                                     + v7 * 4600
                                     + 4),
          time: timeMS);
    }
  }
  else
  {
    v8 = *((_OWORD *)&target->address.addr4 + 1); /*0x1410c9165*/
    *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&target->address.addr6.sin6_family; /*0x1410c916e*/
    *((_OWORD *)&right.address.addr4 + 1) = v8; /*0x1410c9173*/
    if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410c917f*/
    {
      v9 = 0; /*0x1410c9181*/
      if ( this->maximumNumberOfPeers != 0 ) /*0x1410c9187*/
      {
        while ( 1 ) /*0x1410c91a3*/
        {
          v10 = v9; /*0x1410c91a3*/
          if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v10].systemAddress, &right) != 0 /*0x1410c91bd*/
            && this->remoteSystemList[v10].isActive._Storage._Value )
          {
            break; /*0x1410c91c4*/
          }
          if ( ++v9 >= (unsigned int)this->maximumNumberOfPeers ) /*0x1410c91ce*/
            return; /*0x1410c91ce*/
        }
        v11 = &this->remoteSystemList[v10]; /*0x1410c91d9*/
        if ( v11 != nullptr ) /*0x1410c91dc*/
          RakNet::ReliabilityLayer::SetTimeoutTime( /*0x1410c91e7*/
            this: (RakNet::ReliabilityLayer *)((char *)&v11->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
            time: timeMS);
      }
    }
  }
}

// Address: 0x1410c9210 | Name: ?SetUnreliableTimeout@RakPeer@RakNet@@UEAAXI@Z
void __fastcall RakNet::RakPeer::SetUnreliableTimeout(RakNet::RakPeer *this, unsigned int timeoutMS)
{
  unsigned __int16 v2; // bx

  v2 = 0; /*0x1410c921a*/
  for ( this->unreliableTimeout = timeoutMS; v2 < this->maximumNumberOfPeers; ++v2 ) /*0x1410c9229*/
    RakNet::ReliabilityLayer::SetUnreliableTimeout( /*0x1410c9250*/
      this: (RakNet::ReliabilityLayer *)((char *)&this->remoteSystemList->reliabilityLayer.rbxSessionCrypto._Ptr
                                 + 4600 * v2
                                 + 4),
      timeoutMS: this->unreliableTimeout);
}

// Address: 0x1410c9270 | Name: ?SetUserUpdateThread@RakPeer@RakNet@@UEAAXP6AXPEAVRakPeerInterface@2@PEAX@Z1@Z
void __fastcall RakNet::RakPeer::SetUserUpdateThread(
        RakNet::RakPeer *this,
        void (__fastcall *_userUpdateThreadPtr)(RakNet::RakPeerInterface *, void *),
        void *_userUpdateThreadData)
{
  this->userUpdateThreadPtr = _userUpdateThreadPtr; /*0x1410c9270*/
  this->userUpdateThreadData = _userUpdateThreadData; /*0x1410c9277*/
}

// Address: 0x1410c9280 | Name: ?ShiftIncomingTimestamp@RakPeer@RakNet@@IEBAXPEAEAEBUSystemAddress@2@@Z
void __fastcall RakNet::RakPeer::ShiftIncomingTimestamp(
        RakNet::RakPeer *this,
        unsigned __int8 *data,
        const RakNet::SystemAddress *systemAddress)
{
  unsigned int RemoteSystemIndex; // eax
  __int64 v6; // rdx
  RakNet::RakPeer::RemoteSystemStruct *v7; // rdi
  RakNet::SimpleMutex *p_rakNetStatisticsMutex; // rsi
  int v9; // eax
  __int64 v10; // rbx
  int v11; // r10d
  __int64 *p_monotonicClockDifferentialMS; // rdx
  int v13; // r9d
  int v14; // ecx
  unsigned __int8 *p_encodedTimestamp; // rdx
  RakNet::SystemAddress sa; // [rsp+20h] [rbp-158h] BYREF
  RakNet::BitStream timeBS; // [rsp+40h] [rbp-138h] BYREF
  unsigned __int64 encodedTimestamp; // [rsp+190h] [rbp+18h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+198h] [rbp+20h] BYREF

  RakNet::BitStream::BitStream(this: &timeBS, _data: data, lengthInBytes: 8u, _copyData: false); /*0x1410c92a4*/
  __wind /*0xf1c0000000000010*/
  {
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c92aa*/
    {
      RakNet::BitStream::ReadBits( /*0x1410c92f7*/
        this: &timeBS,
        inOutByteArray: (unsigned __int8 *)&encodedTimestamp,
        numberOfBitsToRead: 0x40u,
        alignBitsToRight: true);
    }
    else if ( RakNet::BitStream::ReadBits( /*0x1410c92d0*/
                this: &timeBS,
                &inOutByteArray,
                numberOfBitsToRead: 0x40u,
                alignBitsToRight: true) != 0 )
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410c92e8*/
        inByteArray: &inOutByteArray,
        inOutByteArray: (unsigned __int8 *)&encodedTimestamp,
        length: 8u);
    }
    sa = *systemAddress; /*0x1410c92ff*/
    if ( RakNet::SystemAddress::operator==(this: &sa, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 /*0x1410c9360*/
      || (RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, &sa)) == -1
      || !*(&this->remoteSystemList->isActive._Storage._Value + (v6 = RemoteSystemIndex))
      || (v7 = &this->remoteSystemList[v6]) == nullptr )
    {
      v10 = 0; /*0x1410c93c4*/
    }
    else
    {
      p_rakNetStatisticsMutex = &this->rakNetStatisticsMutex; /*0x1410c9362*/
      rtc::CriticalSection::Enter(lpCriticalSection: &this->rakNetStatisticsMutex.criticalSection); /*0x1410c936c*/
      v9 = 0xFFFF; /*0x1410c9377*/
      v10 = 0; /*0x1410c937a*/
      v11 = 0; /*0x1410c937c*/
      p_monotonicClockDifferentialMS = &v7->pingAndClockDifferential[0].monotonicClockDifferentialMS; /*0x1410c937f*/
      do /*0x1410c93b8*/
      {
        v13 = v9; /*0x1410c9390*/
        v14 = *((unsigned __int16 *)p_monotonicClockDifferentialMS - 4); /*0x1410c9393*/
        if ( (_WORD)v14 == 0xFFFF ) /*0x1410c939b*/
          break; /*0x1410c939b*/
        if ( v14 < v9 ) /*0x1410c939f*/
          v10 = *p_monotonicClockDifferentialMS; /*0x1410c93a1*/
        ++v11; /*0x1410c93a4*/
        p_monotonicClockDifferentialMS += 2; /*0x1410c93a7*/
        v9 = v14; /*0x1410c93ab*/
        if ( v14 >= v13 ) /*0x1410c93b0*/
          v9 = v13; /*0x1410c93b0*/
      }
      while ( v11 < 5 ); /*0x1410c93b8*/
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &p_rakNetStatisticsMutex->criticalSection); /*0x1410c93bd*/
    }
    encodedTimestamp -= v10; /*0x1410c93c6*/
    RakNet::BitStream::SetWriteOffset(this: &timeBS, offset: 0, eraseDataToCurrentOffset: false); /*0x1410c93d8*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410c93dd*/
    {
      p_encodedTimestamp = (unsigned __int8 *)&encodedTimestamp; /*0x1410c940b*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410c93fc*/
        inByteArray: (unsigned __int8 *)&encodedTimestamp,
        &inOutByteArray,
        length: 8u);
      p_encodedTimestamp = &inOutByteArray; /*0x1410c9401*/
    }
    RakNet::BitStream::WriteBits( /*0x1410c9421*/
      this: &timeBS,
      inByteArray: p_encodedTimestamp,
      numberOfBitsToWrite: 0x40u,
      rightAlignedBits: true);
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &timeBS); /*0xf1c0000000000008*/
  }
  RakNet::BitStream::~BitStream(this: &timeBS); /*0x1410c942c*/
}

// Address: 0x1410c9450 | Name: ?Shutdown@RakPeer@RakNet@@UEAAX_N@Z
void __fastcall RakNet::RakPeer::Shutdown(RakNet::RakPeer *this, bool calledFromDestructor)
{
  char *v3; // rax
  char *Ptr; // rcx
  char *v5; // rax
  std::_List_node<std::pair<std::string const ,int>,void *> *v6; // rax
  _WORD *v7; // rax
  char *v8; // rcx
  _WORD *v9; // rax
  char *v10; // rcx
  int v11; // esi
  __int64 v12; // r14
  __int64 v13; // r8
  RakNet::RakPeer::RemoteSystemStruct *remoteSystemList; // rax
  volatile signed __int32 *Rep; // rbx
  RakNet::RakPeer::RemoteSystemStruct *v16; // rcx
  RakNet::RakPeer::RemoteSystemStruct::ConnectMode *p_connectMode; // rbx
  __int64 v18; // rcx
  RBX::DownloadBandwidthTracker *v19; // rcx
  char *Myfirst; // rcx
  __int64 v21; // [rsp+0h] [rbp-99h] BYREF
  std::string counterName; // [rsp+20h] [rbp-79h] BYREF
  std::unordered_map<std::string,int> shutdownReport; // [rsp+40h] [rbp-59h] BYREF
  std::string _Keyval_arg; // [rsp+80h] [rbp-19h] BYREF
  std::string v25; // [rsp+A0h] [rbp+7h] BYREF
  std::pair<std::_List_node<std::pair<std::string const ,float>,void *> *,bool> result; // [rsp+C0h] [rbp+27h] BYREF
  std::pair<std::_List_node<std::pair<std::string const ,float>,void *> *,bool> v27; // [rsp+D0h] [rbp+37h] BYREF

  if ( !DFFlag::RakNetShutdownCallstackCount.value ) /*0x1410c947d*/
    goto LABEL_12; /*0x1410c947d*/
  counterName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410c9483*/
  counterName._Mypair._Myval2._Mysize = 0; /*0x1410c9487*/
  counterName._Mypair._Myval2._Myres = 15; /*0x1410c948b*/
  if ( calledFromDestructor ) /*0x1410c949d*/
  {
    v3 = (char *)operator new(size: 0x20u); /*0x1410c94a3*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000094*/
    counterName._Mypair._Myval2._Mysize = 26; /*0x1410c94a8*/
    counterName._Mypair._Myval2._Myres = 31; /*0x1410c94b0*/
    strcpy(v3, "RakPeerShutdown-Destructor"); /*0x1410c94bf*/
    counterName._Mypair._Myval2._Bx._Ptr = v3; /*0x1410c94de*/
    RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x1410c94ed*/
    if ( counterName._Mypair._Myval2._Myres >= 0x10 ) /*0x1410c94fb*/
    {
      Ptr = counterName._Mypair._Myval2._Bx._Ptr; /*0x1410c9504*/
      if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410c9512*/
      {
        Ptr = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c951c*/
        if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410c952b*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410c9531*/
      }
LABEL_11:
      operator delete(ptr: Ptr); /*0x1410c95c1*/
    }
  }
  else
  {
    v5 = (char *)operator new(size: 0x20u); /*0x1410c9538*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000008c*/
    counterName._Mypair._Myval2._Mysize = 26; /*0x1410c953d*/
    counterName._Mypair._Myval2._Myres = 31; /*0x1410c9545*/
    strcpy(v5, "RakPeerShutdown-Disconnect"); /*0x1410c9554*/
    counterName._Mypair._Myval2._Bx._Ptr = v5; /*0x1410c9573*/
    RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x1410c9582*/
    if ( counterName._Mypair._Myval2._Myres >= 0x10 ) /*0x1410c9590*/
    {
      Ptr = counterName._Mypair._Myval2._Bx._Ptr; /*0x1410c9595*/
      if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410c95a3*/
      {
        Ptr = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c95a9*/
        if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410c95b8*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410c95ba*/
      }
      goto LABEL_11; /*0x1410c95b8*/
    }
  }
  if ( __eh34_unwind(0) ) /*0xf1c0000000000078*/
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c000000000007c*/
    __eh34_propagate_exception_into_caller(0, -1); /*0xf1c0000000000080*/
  }
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000084*/
LABEL_12:
  if ( !DFFlag::RakNetShutdownOnce.value || !this->prepareEndThreads._Storage._Value )
  {
    shutdownReport._Traitsobj._Mypair._Myval2._Myval2 = 0.0; /*0x1410c95df*/
    shutdownReport._List._Mypair._Myval2._Myhead = nullptr; /*0x1410c95e4*/
    shutdownReport._List._Mypair._Myval2._Mysize = 0; /*0x1410c95e8*/
    v6 = (std::_List_node<std::pair<std::string const ,int>,void *> *)operator new(size: 0x38u); /*0x1410c95f1*/
    __wind /*0xf1c000000000009c*/
    {
      __wind /*0xf1c00000000000a4*/
      {
        v6->_Next = v6; /*0x1410c95f6*/
        v6->_Prev = v6; /*0x1410c95f9*/
        shutdownReport._List._Mypair._Myval2._Myhead = v6; /*0x1410c95fd*/
        memset(&shutdownReport._Vec, 0, sizeof(shutdownReport._Vec)); /*0x1410c9601*/
        shutdownReport._Mask = 7; /*0x1410c960d*/
        shutdownReport._Maxidx = 8; /*0x1410c9615*/
        shutdownReport._Traitsobj._Mypair._Myval2._Myval2 = 1.0; /*0x1410c9625*/
        std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::shared_ptr<RBX::Graphics::Shader>>>>>>>::_Assign_grow( /*0x1410c9636*/
          this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > > > > *)&shutdownReport._Vec,
          _Cells: 0x10u,
          _Val: (const std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > >)v6);
      }
      __unwind
      {
        std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&shutdownReport._Vec); /*0x143156b2b*/
      }
    }
    __unwind
    {
      std::list<std::pair<std::string const,enum RBX::Studio::LaunchTask>>::~list<std::pair<std::string const,enum RBX::Studio::LaunchTask>>(this: (std::list<std::pair<std::string const ,PluginMenuRelay *>> *)&shutdownReport._List); /*0x14315de1b*/
    }
    __wind
    {
      this->prepareEndThreads._Storage._Value = true; /*0x1410c9641*/
      RakNet::SignaledEvent::SetEvent(this: (rtc::Event *)&this->quitAndDataEvents); /*0x1410c964b*/
      if ( this->isMainLoopThreadActive._Storage._Value
        && !RBX::CEvent::Wait(this: &this->updateNetworkLoopEnded, milliseconds: DFInt::WaitOnUpdateNetworkLoopEndedMS) )
      {
        if ( FLog::Network != 0 )
          FLog::FastLog(
            level: FLog::Network,
            message: "[FLog::Network] Timed-out: Failed to gracefully end update loop within %d (ms)",
            arg0: (const void *)DFInt::WaitOnUpdateNetworkLoopEndedMS);
        _Keyval_arg._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410c9695*/
        _Keyval_arg._Mypair._Myval2._Mysize = 0; /*0x1410c9699*/
        _Keyval_arg._Mypair._Myval2._Myres = 15; /*0x1410c969d*/
        v7 = operator new(size: 0x30u); /*0x1410c96ae*/
        _Keyval_arg._Mypair._Myval2._Mysize = 35; /*0x1410c96b3*/
        _Keyval_arg._Mypair._Myval2._Myres = 47; /*0x1410c96bb*/
        qmemcpy(v7, "RakNetShutdown_endUpdateLoopFailur", 34); /*0x1410c96ca*/
        v7[17] = (unsigned __int8)aRaknetshutdown_1[34]; /*0x1410c96ea*/
        _Keyval_arg._Mypair._Myval2._Bx._Ptr = (char *)v7; /*0x1410c96f1*/
        __wind /*0xf1c000000000006c*/
        {
          LODWORD(std::_Hash<std::_Umap_traits<std::string,int,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,int>>,0>>::_Try_emplace<std::string,>( /*0x1410c9709*/
                    this: (std::_Hash<std::_Umap_traits<std::string,float,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,float> >,0> > *)&shutdownReport,
                    &result,
                    &_Keyval_arg)->first->_Myval.second) = 1;
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&_Keyval_arg); /*0xf1c0000000000064*/
        }
        if ( _Keyval_arg._Mypair._Myval2._Myres >= 0x10 ) /*0x1410c9718*/
        {
          v8 = _Keyval_arg._Mypair._Myval2._Bx._Ptr; /*0x1410c971d*/
          if ( _Keyval_arg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410c972b*/
          {
            v8 = *((char **)_Keyval_arg._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c9731*/
            if ( (unsigned __int64)(_Keyval_arg._Mypair._Myval2._Bx._Ptr - v8 - 8) > 0x1F ) /*0x1410c9740*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410c9742*/
          }
          operator delete(ptr: v8); /*0x1410c9749*/
        }
      }
      _InterlockedExchange((volatile __int32 *)&this->activeSystemListSize, 0); /*0x1410c9751*/
      if ( this->isRecvFromLoopThreadActive.value._Storage._Value != 0
        && !RBX::CEvent::Wait(this: &this->recvFromLoopEnded, milliseconds: DFInt::WaitOnRecvFromLoopEndedMS) )
      {
        if ( FLog::Network != 0 )
          FLog::FastLog(
            level: FLog::Network,
            message: "[FLog::Network] Timed-out: Failed to gracefully end receive loop within %d (ms)",
            arg0: (const void *)DFInt::WaitOnRecvFromLoopEndedMS);
        v25._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410c979b*/
        v25._Mypair._Myval2._Mysize = 0; /*0x1410c979f*/
        v25._Mypair._Myval2._Myres = 15; /*0x1410c97a3*/
        v9 = operator new(size: 0x30u); /*0x1410c97b4*/
        v25._Mypair._Myval2._Mysize = 33; /*0x1410c97b9*/
        v25._Mypair._Myval2._Myres = 47; /*0x1410c97c1*/
        qmemcpy(v9, "RakNetShutdown_endRecvLoopFailur", 32); /*0x1410c97d0*/
        v9[16] = (unsigned __int8)aRaknetshutdown_2[32]; /*0x1410c97e5*/
        v25._Mypair._Myval2._Bx._Ptr = (char *)v9; /*0x1410c97ec*/
        __wind /*0xf1c0000000000054*/
        {
          LODWORD(std::_Hash<std::_Umap_traits<std::string,int,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,int>>,0>>::_Try_emplace<std::string,>( /*0x1410c9804*/
                    this: (std::_Hash<std::_Umap_traits<std::string,float,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,float> >,0> > *)&shutdownReport,
                    result: &v27,
                    _Keyval_arg: &v25)->first->_Myval.second) = 1;
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v25); /*0xf1c000000000004c*/
        }
        if ( v25._Mypair._Myval2._Myres >= 0x10 ) /*0x1410c9813*/
        {
          v10 = v25._Mypair._Myval2._Bx._Ptr; /*0x1410c9818*/
          if ( v25._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410c9826*/
          {
            v10 = *((char **)v25._Mypair._Myval2._Bx._Ptr - 1); /*0x1410c982c*/
            if ( (unsigned __int64)(v25._Mypair._Myval2._Bx._Ptr - v10 - 8) > 0x1F ) /*0x1410c983b*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410c983d*/
          }
          operator delete(ptr: v10); /*0x1410c9844*/
        }
      }
      if ( shutdownReport._List._Mypair._Myval2._Mysize != 0 ) /*0x1410c984e*/
        RBX::Analytics::EphemeralCounter::bulkReportCounters(stats: &shutdownReport, blocking: false); /*0x1410c9856*/
      v11 = 0; /*0x1410c985b*/
      if ( this->maximumNumberOfPeers != 0 ) /*0x1410c9863*/
      {
        v12 = 0; /*0x1410c9869*/
        do /*0x1410c990d*/
        {
          v13 = v11; /*0x1410c9873*/
          this->remoteSystemList[v13].isActive._Storage._Value = false; /*0x1410c9884*/
          RakNet::ReliabilityLayer::Reset( /*0x1410c98a6*/
            this: (RakNet::ReliabilityLayer *)((char *)&this->remoteSystemList->reliabilityLayer.rbxSessionCrypto._Ptr
                                       + v13 * 4600
                                       + 4),
            resetVariables: false,
            MTUSize: this->remoteSystemList[v12].MTUSize,
            _useSecurity: false);
          remoteSystemList = this->remoteSystemList; /*0x1410c98ab*/
          remoteSystemList[v12].rakNetSocket._Ptr = nullptr; /*0x1410c98b2*/
          Rep = (volatile signed __int32 *)remoteSystemList[v12].rakNetSocket._Rep; /*0x1410c98ba*/
          remoteSystemList[v12].rakNetSocket._Rep = nullptr; /*0x1410c98c2*/
          if ( Rep != nullptr && _InterlockedExchangeAdd(Rep + 2, 0xFFFFFFFF) == 1 ) /*0x1410c98dc*/
          {
            (**(void (__fastcall ***)(volatile signed __int32 *))Rep)(a1: Rep); /*0x1410c98e4*/
            if ( _InterlockedExchangeAdd(Rep + 3, 0xFFFFFFFF) == 1 ) /*0x1410c98f3*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)Rep + 8LL))(a1: Rep); /*0x1410c98fb*/
          }
          ++v11; /*0x1410c98fe*/
          ++v12; /*0x1410c9900*/
        }
        while ( v11 < this->maximumNumberOfPeers ); /*0x1410c990d*/
      }
      this->maximumNumberOfPeers = 0; /*0x1410c9913*/
      RakNet::RakPeer::freeAllocatedSendPackets(this); /*0x1410c991b*/
      RakNet::RakPeer::DerefAllSockets(this); /*0x1410c9923*/
      RakNet::RakPeer::ClearBufferedCommands(this); /*0x1410c992b*/
      RakNet::RakPeer::ClearBufferedPackets(this); /*0x1410c9933*/
      DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Clear( /*0x1410c994c*/
        this: &this->socketQueryOutput,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
        line: 0x1249u);
      RakNet::RakPeer::ClearRequestedConnectionList(this); /*0x1410c9954*/
      *(_QWORD *)&this->bytesSentPerSecond = 0; /*0x1410c9959*/
      v16 = this->remoteSystemList; /*0x1410c9960*/
      this->remoteSystemList = nullptr; /*0x1410c9967*/
      if ( v16 != nullptr ) /*0x1410c9971*/
      {
        __wind /*0xf1c000000000003c*/
        {
          p_connectMode = &v16[-1].connectMode; /*0x1410c9973*/
          `eh vector destructor iterator'( /*0x1410c9986*/
            ptr: v16,
            size: 0x11F8u,
            count: *(_QWORD *)&v16[-1].connectMode,
            destructor: (void (__fastcall *)(void *))RakNet::RakPeer::RemoteSystemStruct::~RemoteSystemStruct);
          operator delete(ptr: p_connectMode); /*0x1410c9999*/
        }
        __unwind
        {
          __std_terminate(a1: v18, a2: &v21); /*0x142f39fa8*/
        }
      }
      operator delete(ptr: this->activeSystemList); /*0x1410c99a6*/
      this->activeSystemList = nullptr; /*0x1410c99ab*/
      DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410c99c6*/
        this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->remoteSystemIndexPool,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
        line: 0x1001u);
      operator delete(ptr: this->remoteSystemLookup); /*0x1410c99d2*/
      this->remoteSystemLookup = nullptr; /*0x1410c99d7*/
      rtc::CriticalSection::Enter(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410c99e5*/
      this->sendReceiptSerial = 1; /*0x1410c99ea*/
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->sendReceiptSerialMutex.criticalSection); /*0x1410c99fb*/
      v19 = this->downloadBandwidthTracker._Ptr; /*0x1410c9a00*/
      if ( v19 != nullptr ) /*0x1410c9a0a*/
        RBX::DownloadBandwidthTracker::abort(this: v19); /*0x1410c9a0c*/
    }
    __unwind
    {
      std::unordered_map<std::string,std::_List_iterator<std::_List_val<std::_List_simple_types<std::string>>>>::~unordered_map<std::string,std::_List_iterator<std::_List_val<std::_List_simple_types<std::string>>>>(this: (std::unordered_map<std::string,PluginMenuRelay *> *)&shutdownReport); /*0xf1c0000000000028*/
    }
    Myfirst = (char *)shutdownReport._Vec._Mypair._Myval2._Myfirst; /*0x1410c9a16*/
    if ( (((char *)shutdownReport._Vec._Mypair._Myval2._Mylast - (char *)shutdownReport._Vec._Mypair._Myval2._Myfirst) /*0x1410c9a2b*/
        & 0xFFFFFFFFFFFFFFF8uLL) >= 0x1000 )
    {
      Myfirst = (char *)shutdownReport._Vec._Mypair._Myval2._Myfirst[-1]._Ptr; /*0x1410c9a31*/
      if ( (unsigned __int64)((char *)shutdownReport._Vec._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x1410c9a40*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410c9a42*/
    }
    operator delete(ptr: Myfirst); /*0x1410c9a49*/
    memset(&shutdownReport._Vec, 0, sizeof(shutdownReport._Vec)); /*0x1410c9a4e*/
    std::_List_node<std::pair<std::string const,RBX::LocalizationTable *>,void *>::_Free_non_head<std::allocator<std::_List_node<std::pair<std::string const,RBX::LocalizationTable *>,void *>>>( /*0x1410c9a62*/
      _Al: (std::allocator<std::_List_node<std::pair<std::string const ,PluginMenuRelay *>,void *> > *)&shutdownReport._List,
      _Head: (std::_List_node<std::pair<std::string const ,PluginMenuRelay *>,void *> *)shutdownReport._List._Mypair._Myval2._Myhead);
    operator delete(ptr: shutdownReport._List._Mypair._Myval2._Myhead); /*0x1410c9a70*/
  }
}

// Address: 0x1410c9af0 | Name: ?Startup@RakPeer@RakNet@@UEAA?AW4StartupResult@2@GPEAHPEAUSocketDescriptor@2@IGGH@Z
__int64 __fastcall RakNet::RakPeer::Startup(
        RakNet::RakPeer *this,
        unsigned __int16 maxConnections,
        int *maxReceivePayloadSize,
        RakNet::SocketDescriptor *socketDescriptors,
        unsigned int socketDescriptorCount,
        unsigned __int16 portLow,
        unsigned __int16 portHigh,
        int threadPriority)
{
  RakNet::SocketDescriptor *v8; // r12
  unsigned int v12; // eax
  int v13; // eax
  unsigned int v14; // ebp
  int v15; // ecx
  unsigned int v16; // eax
  unsigned __int16 *p_socketFamily; // r13
  const char *forceHostAddress; // r12
  RakNet::RakNetSocket *v19; // rax
  RakNet::RakNetSocket *v20; // rdi
  std::_Ref_count_base *v21; // rax
  std::_Ref_count_base *v22; // rbx
  addrinfo *v23; // rax
  addrinfo *v24; // r15
  unsigned __int16 Port; // ax
  __int64 v26; // rax
  bool v27; // cf
  unsigned __int64 v28; // rax
  _QWORD *v29; // rax
  RakNet::RakPeer::RemoteSystemStruct *v30; // rdi
  __int64 maximumNumberOfPeers; // rax
  RakNet::RakPeer::RemoteSystemStruct **p_remoteSystemList; // r15
  RakNet::RemoteSystemIndex **v33; // rdx
  int v34; // ecx
  RakNet::RakPeer::RemoteSystemStruct **v35; // rdx
  int v36; // r14d
  __int64 v37; // rbx
  unsigned int v38; // edx
  int v39; // r15d
  unsigned int v40; // r14d
  unsigned int v41; // ebx
  __int64 v42; // rdi
  __int64 v43; // rcx
  __int64 v45; // [rsp+0h] [rbp-6C8h] BYREF
  unsigned int v46; // [rsp+40h] [rbp-688h]
  int priority; // [rsp+44h] [rbp-684h]
  RBX::Memory::Scope memscopeRakNet; // [rsp+48h] [rbp-680h] BYREF
  std::_Ref_count_base *v49; // [rsp+50h] [rbp-678h]
  std::shared_ptr<RakNet::RakNetSocket> rns; // [rsp+58h] [rbp-670h] BYREF
  RakNet::RakNetSocket *v51; // [rsp+68h] [rbp-660h]
  std::_Temporary_owner<RakNet::RakNetSocket> v52; // [rsp+70h] [rbp-658h] BYREF
  RakPeerAndIndex rpai[32]; // [rsp+80h] [rbp-648h] BYREF
  char addressBuffer[1096]; // [rsp+280h] [rbp-448h] BYREF
  unsigned int v55; // [rsp+6D0h] [rbp+8h]

  v8 = socketDescriptors; /*0x1410c9b11*/
  v12 = RBX::Memory::setCurrentCategory(category: RBX::Memory::RakNet); /*0x1410c9b23*/
  __wind
  {
    memscopeRakNet.parent = v12; /*0x1410c9b28*/
    if ( this->IsActive(this) ) /*0x1410c9b32*/
    {
      v13 = 1; /*0x1410c9b39*/
LABEL_79:
      v14 = v13; /*0x1410ca13c*/
      goto LABEL_103; /*0xf1c00000000000e8*/
    }
    v14 = 0; /*0x1410c9b43*/
    v15 = 0; /*0x1410c9b45*/
    if ( threadPriority != -99999 ) /*0x1410c9b52*/
      v15 = threadPriority; /*0x1410c9b52*/
    priority = v15; /*0x1410c9b5a*/
    RakNet::SocketLayer::GetMyIP(addresses: this->ipList); /*0x1410c9b65*/
    if ( v8 == nullptr || socketDescriptorCount == 0 ) /*0x1410c9b7b*/
    {
      v13 = 2; /*0x1410ca137*/
      goto LABEL_79; /*0x1410ca137*/
    }
    this->maxRxPayloadSize = maxReceivePayloadSize; /*0x1410c9b81*/
    if ( maxConnections == 0 ) /*0x1410c9b8b*/
    {
      v13 = 3; /*0x1410c9b8d*/
      goto LABEL_79; /*0x1410c9b90*/
    }
    RakNet::RakPeer::DerefAllSockets(this); /*0x1410c9b98*/
    v46 = 0; /*0x1410c9b9d*/
    v16 = 0; /*0x1410c9ba1*/
    v55 = 0; /*0x1410c9ba3*/
    p_socketFamily = (unsigned __int16 *)&v8->socketFamily; /*0x1410c9baa*/
    while ( 1 )
    {
      if ( *((_BYTE *)p_socketFamily - 66) != 0 ) /*0x1410c9bc1*/
        forceHostAddress = v8[v16].hostAddress; /*0x1410c9bd2*/
      else
        forceHostAddress = nullptr; /*0x1410c9bc3*/
      v19 = (RakNet::RakNetSocket *)operator new(size: 0x38u); /*0x1410c9bda*/
      v51 = v19; /*0x1410c9bdf*/
      __wind /*0xf1c0000000000094*/
      {
        if ( v19 != nullptr ) /*0x1410c9be7*/
          v20 = RakNet::RakNetSocket::RakNetSocket(this: v19); /*0x1410c9bf1*/
        else
          v20 = nullptr; /*0x1410c9bf6*/
      }
      __unwind
      {
        operator delete(ptr: v51); /*0x1431ed0b2*/
      }
      v52._Ptr = v20; /*0x1410c9bf9*/
      __wind /*0xf1c0000000000068*/
      {
        v21 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x1410c9c03*/
        v22 = v21; /*0x1410c9c08*/
        v49 = v21; /*0x1410c9c0b*/
        if ( v21 != nullptr ) /*0x1410c9c13*/
        {
          *v21 = 0; /*0x1410c9c18*/
          v21->_Uses = 1; /*0x1410c9c1b*/
          v21->_Weaks = 1; /*0x1410c9c1f*/
          v21->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RakNet::RakNetSocket>::`vftable'; /*0x1410c9c2a*/
          v21[1].__vftable = (std::_Ref_count_base_vtbl *)v20; /*0x1410c9c2d*/
        }
        else
        {
          v22 = nullptr; /*0x1410c9c33*/
        }
      }
      __unwind
      {
        std::_Temporary_owner<RakNet::RakNetSocket>::~_Temporary_owner<RakNet::RakNetSocket>(this: &v52); /*0xf1c0000000000078*/
      }
      __eh34_enter_wind_state(0, 6); /*0xf1c0000000000080*/
      rns._Ptr = v20; /*0x1410c9c36*/
      rns._Rep = v22; /*0x1410c9c3b*/
      v23 = RakNet::SocketLayer::GetAddrInfoAllocate(family: *p_socketFamily); /*0x1410c9c45*/
      v24 = v23; /*0x1410c9c4a*/
      if ( v23 != nullptr )
      {
        ++v46; /*0x1410c9c56*/
        v20->s = (unsigned int)RakNet::SocketLayer::CreateBoundSocket( /*0x1410c9c97*/
                                 servInfo: v23,
                                 port: *(p_socketFamily - 34),
                                 portLow,
                                 portHigh,
                                 blockingSocket: true,
                                 forceHostAddress,
                                 sleepOn10048: 0x64u,
                                 socketFamily: *p_socketFamily);
        freeaddrinfo(pAddrInfo: v24); /*0x1410c9c9d*/
        if ( v20->s == -1 ) /*0x1410c9caa*/
        {
          RakNet::RakPeer::DerefAllSockets(this); /*0x1410c9dd1*/
          v14 = 6; /*0x1410c9dd6*/
          if ( __eh34_unwind(6) ) /*0xf1c0000000000048*/
          {
unwind_state_6:
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&rns); /*0xf1c000000000004c*/
            __eh34_continue_unwinding(6, 0); /*0xf1c0000000000050*/
          }
LABEL_87:
          __eh34_exit_wind_state(6, 0); /*0xf1c0000000000054*/
          if ( v22 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410c9def*/
          {
            v22->_Destroy(this: v22); /*0x1410c9dfb*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c9e07*/
              v22->_Delete_this(this: v22); /*0x1410c9e13*/
          }
          goto LABEL_103; /*0x1410c9e16*/
        }
        RakNet::SocketLayer::GetSystemAddress(s: v20->s, systemAddressOut: &v20->boundAddress); /*0x1410c9cb4*/
        if ( DFFlag::DropPacketFromInvalidPort2.value
          && RakNet::SystemAddress::GetPort(this: &v20->boundAddress) < DFInt::FirstValidPort )
        {
          if ( FLog::Network != 0 )
          {
            Port = RakNet::SystemAddress::GetPort(this: &v20->boundAddress); /*0x1410c9dab*/
            FLog::FastLog(
              level: FLog::Network,
              message: "[FLog::Network] RakNet Socket bound to invalid (privileged) port: %u",
              arg0: (const void *)Port);
          }
          v14 = 11; /*0x1410c9dc7*/
          goto LABEL_87; /*0x1410c9dcc*/
        }
        v20->userConnectionSocketIndex = v55; /*0x1410c9ce1*/
        RakNet::SystemAddress::ToStringN( /*0x1410c9cfd*/
          this: &v20->boundAddress,
          writePort: true,
          dest: addressBuffer,
          size: 1025,
          portDelineator: 124);
        if ( DFLog::NetworkAudit != 0 )
          FLog::FastLog(
            level: DFLog::NetworkAudit,
            message: "[DFLog::NetworkAudit] RakNet Socket Open: %s",
            arg0: addressBuffer);
        DataStructures::List<std::shared_ptr<RakNet::RakNetSocket>>::Insert( /*0x1410c9d3a*/
          this: &this->socketList,
          input: (const std::shared_ptr<RobloxDiagnosticsView::ItemData> *)&rns,
          file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
          line: 0x2DFu);
      }
      if ( __eh34_unwind(6) ) /*0xf1c000000000005c*/
        goto unwind_state_6; /*0xf1c000000000005c*/
      __eh34_exit_wind_state(6, 0); /*0xf1c0000000000060*/
      if ( v22 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410c9d50*/
      {
        v22->_Destroy(this: v22); /*0x1410c9d58*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410c9d65*/
          v22->_Delete_this(this: v22); /*0x1410c9d6d*/
      }
      v16 = v55 + 1; /*0x1410c9d77*/
      v55 = v16; /*0x1410c9d79*/
      p_socketFamily += 35; /*0x1410c9d80*/
      if ( v16 >= socketDescriptorCount ) /*0x1410c9d8b*/
      {
        if ( this->maximumNumberOfPeers == 0 ) /*0x1410c9e20*/
        {
          this->maximumNumberOfPeers = maxConnections; /*0x1410c9e2e*/
          if ( this->maximumIncomingConnections > maxConnections ) /*0x1410c9e36*/
            this->maximumIncomingConnections = maxConnections; /*0x1410c9e38*/
          v26 = 4600LL * maxConnections; /*0x1410c9e4c*/
          if ( !is_mul_ok(maxConnections, 0x11F8u) ) /*0x1410c9e4c*/
            v26 = -1; /*0x1410c9e4f*/
          v27 = __CFADD__(v26, 8); /*0x1410c9e53*/
          v28 = v26 + 8; /*0x1410c9e53*/
          if ( v27 ) /*0x1410c9e57*/
            v28 = -1; /*0x1410c9e57*/
          v29 = operator new(size: v28); /*0x1410c9e5e*/
          v49 = (std::_Ref_count_base *)v29; /*0x1410c9e63*/
          __wind /*0xf1c000000000003c*/
          {
            if ( v29 != nullptr ) /*0x1410c9e6b*/
            {
              *v29 = maxConnections; /*0x1410c9e6d*/
              v30 = (RakNet::RakPeer::RemoteSystemStruct *)(v29 + 1); /*0x1410c9e70*/
              `eh vector constructor iterator'( /*0x1410c9e92*/
                ptr: v29 + 1,
                size: 0x11F8u,
                count: maxConnections,
                constructor: (void (__fastcall *)(void *))RakNet::RakPeer::RemoteSystemStruct::RemoteSystemStruct,
                destructor: (void (__fastcall *)(void *))RakNet::RakPeer::RemoteSystemStruct::~RemoteSystemStruct);
            }
            else
            {
              v30 = nullptr; /*0x1410c9e99*/
            }
          }
          __unwind
          {
            is_mul_ok(maxConnections, 0x11F8u); /*0x1431ed0de*/
            operator delete(ptr: v49); /*0x1431ed106*/
          }
          maximumNumberOfPeers = this->maximumNumberOfPeers; /*0x1410c9e9c*/
          p_remoteSystemList = &this->remoteSystemList; /*0x1410c9ea0*/
          this->remoteSystemList = v30; /*0x1410c9ea7*/
          if ( (_WORD)maximumNumberOfPeers != 0 ) /*0x1410c9ead*/
          {
            v33 = (RakNet::RemoteSystemIndex **)operator new(size: saturated_mul(8 * maximumNumberOfPeers, 8u)); /*0x1410c9ecf*/
            LOWORD(maximumNumberOfPeers) = this->maximumNumberOfPeers; /*0x1410c9ed2*/
          }
          else
          {
            v33 = nullptr; /*0x1410c9eaf*/
          }
          LOWORD(v34) = maximumNumberOfPeers; /*0x1410c9ed6*/
          this->remoteSystemLookup = v33; /*0x1410c9ed9*/
          if ( (_WORD)maximumNumberOfPeers != 0 ) /*0x1410c9ee3*/
          {
            v35 = (RakNet::RakPeer::RemoteSystemStruct **)operator new(size: saturated_mul((unsigned __int16)maximumNumberOfPeers, 8u)); /*0x1410c9f01*/
            LOWORD(maximumNumberOfPeers) = this->maximumNumberOfPeers; /*0x1410c9f04*/
            LOWORD(v34) = maximumNumberOfPeers; /*0x1410c9f08*/
          }
          else
          {
            v35 = nullptr; /*0x1410c9ee5*/
          }
          this->activeSystemList = v35; /*0x1410c9f0b*/
          v36 = 0; /*0x1410c9f12*/
          if ( (_WORD)maximumNumberOfPeers != 0 ) /*0x1410c9f18*/
          {
            do /*0x1410c9fca*/
            {
              v37 = v36; /*0x1410c9f23*/
              (*p_remoteSystemList)[v37].isActive._Storage._Value = false; /*0x1410c9f2f*/
              RakNet::SystemAddress::operator=( /*0x1410c9f43*/
                this: &(*p_remoteSystemList)[v37].systemAddress,
                input: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30);
              (*p_remoteSystemList)[v37].guid = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410c9f52*/
              (*p_remoteSystemList)[v37].connectMode = 0; /*0x1410c9f6c*/
              (*p_remoteSystemList)[v37].MTUSize = this->defaultMTUSize; /*0x1410c9f7c*/
              (*p_remoteSystemList)[v37].remoteSystemIndex = v36; /*0x1410c9f86*/
              (*p_remoteSystemList)[v37].remoteSystemBPSLimit = 0; /*0x1410c9f92*/
              (*p_remoteSystemList)[v37].remoteCommonCapabilities = 0; /*0x1410c9f9c*/
              *(RakNet::RakPeer **)((char *)&(*p_remoteSystemList)[v37].reliabilityLayer.rakPeer + 4) = this; /*0x1410c9fa7*/
              this->activeSystemList[v36++] = &(*p_remoteSystemList)[v37]; /*0x1410c9fbc*/
              v34 = this->maximumNumberOfPeers; /*0x1410c9fc3*/
            }
            while ( v36 < v34 ); /*0x1410c9fca*/
          }
          v38 = 0; /*0x1410c9fd0*/
          if ( 8 * (unsigned __int16)v34 != 0 ) /*0x1410c9fda*/
          {
            do /*0x1410c9ff8*/
              this->remoteSystemLookup[v38++] = nullptr; /*0x1410c9fe9*/
            while ( v38 < 8 * (unsigned int)this->maximumNumberOfPeers ); /*0x1410c9ff8*/
          }
        }
        if ( this->endThreads._Storage._Value ) /*0x1410c9ffa*/
        {
          this->updateCycleIsRunning = false; /*0x1410ca007*/
          this->endThreads._Storage._Value = false; /*0x1410ca010*/
          this->prepareEndThreads._Storage._Value = false; /*0x1410ca015*/
          RakNet::RakPeer::ClearBufferedCommands(this); /*0x1410ca01b*/
          RakNet::RakPeer::ClearBufferedPackets(this); /*0x1410ca023*/
          DataStructures::ThreadsafeAllocatingQueue<RakNet::RakPeer::SocketQueryOutput>::Clear( /*0x1410ca03c*/
            this: &this->socketQueryOutput,
            file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
            line: 0x1249u);
          if ( this->isMainLoopThreadActive._Storage._Value ) /*0x1410ca041*/
          {
LABEL_74:
            while ( !this->isMainLoopThreadActive._Storage._Value ) /*0x1410ca10a*/
              RESTRICTED_QtUtilities::sleep(dwMilliseconds: 0xAu); /*0x1410ca115*/
          }
          else
          {
            v39 = priority; /*0x1410ca04e*/
            if ( RakNet::RakThread::Create( /*0x1410ca067*/
                   start_address: (unsigned int (__fastcall *)(void *))RakNet::UpdateNetworkLoop,
                   arglist: this,
                   priority) == 0 )
            {
              v40 = v46; /*0x1410ca06d*/
              if ( v46 == 0 ) /*0x1410ca075*/
              {
                RakNet::RakPeer::DerefAllSockets(this); /*0x1410ca07a*/
                v14 = 7; /*0x1410ca07f*/
                goto LABEL_103; /*0x1410ca083*/
              }
              v41 = 0; /*0x1410ca088*/
              v42 = 0; /*0x1410ca08a*/
              while ( 1 ) /*0x1410ca09e*/
              {
                rpai[v42].s = this->socketList.listArray[v42]._Ptr->s; /*0x1410ca09e*/
                rpai[v42].rakPeer = this; /*0x1410ca0a6*/
                if ( RakNet::RakThread::Create( /*0x1410ca0d1*/
                       start_address: (unsigned int (__fastcall *)(void *))RakNet::RecvFromLoop,
                       arglist: &rpai[v41],
                       priority: v39) != 0 )
                  break; /*0x1410ca0d1*/
                ++v41; /*0x1410ca0d3*/
                ++v42; /*0x1410ca0d5*/
                if ( v41 >= v40 ) /*0x1410ca0dc*/
                {
                  while ( this->isRecvFromLoopThreadActive.value._Storage._Value < v40 ) /*0x1410ca0e5*/
                    RESTRICTED_QtUtilities::sleep(dwMilliseconds: 0xAu); /*0x1410ca0f5*/
                  goto LABEL_74; /*0x1410ca101*/
                }
              }
            }
            this->Shutdown(this, a2: false); /*0x1410ca12d*/
            v14 = 9; /*0x1410ca130*/
          }
        }
        goto LABEL_103; /*0x1410ca135*/
      }
      v8 = socketDescriptors; /*0x1410c9d91*/
    }
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&memscopeRakNet); /*0xf1c00000000000b0*/
  }
LABEL_103:
  __wind /*0xf1c00000000000b8*/
  {
    RBX::Memory::setCurrentCategory(category: memscopeRakNet.parent); /*0x1410ca142*/
  }
  __unwind
  {
    __std_terminate(a1: v43, a2: &v45); /*0x142f39fa8*/
  }
  return v14; /*0x1410ca14a*/
}

// Address: 0x1410ca170 | Name: ?TrackRunUpdateCycleTime@RakPeer@RakNet@@IEAAXXZ
void __fastcall RakNet::RakPeer::TrackRunUpdateCycleTime(RakNet::RakPeer *this)
{
  long double v2; // xmm6_8
  long double v3; // xmm7_8
  long double v4; // xmm8_8
  long double v5; // xmm9_8
  long double v6; // xmm10_8
  long double v7; // xmm11_8
  long double v8; // xmm12_8
  int v9; // ebx
  char *v10; // rax
  char *Ptr; // rcx
  std::string resource; // [rsp+50h] [rbp-108h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+70h] [rbp-E8h] BYREF
  RBX::Time cycleStartFast; // [rsp+160h] [rbp+8h] BYREF

  RBX::Time::nowFast(result: &cycleStartFast); /*0x1410ca1a7*/
  if ( this->runUpdateCycleStats.trackedStatsLastCycle )
  {
    v2 = (cycleStartFast.sec - this->runUpdateCycleStats.lastCycleStart.sec) * 1000.0; /*0x1410ca1d2*/
    if ( v2 > (double)DFInt::TrackRunUpdateCycleReportMs )
    {
      v3 = this->runUpdateCycleStats.cycleStartToAfterBufferedHandling.sec * 1000.0; /*0x1410ca1f4*/
      v4 = this->runUpdateCycleStats.cycleStartToAfterRequestConnection.sec * 1000.0; /*0x1410ca201*/
      v5 = this->runUpdateCycleStats.cycleStartToAfterDisconnectChecks.sec * 1000.0; /*0x1410ca20f*/
      v6 = this->runUpdateCycleStats.cycleStartToAfterPingInternal.sec * 1000.0; /*0x1410ca21d*/
      v7 = this->runUpdateCycleStats.cycleStartToAfterReliableReceive.sec * 1000.0; /*0x1410ca22b*/
      v8 = this->runUpdateCycleStats.cycleStartToReturn.sec * 1000.0; /*0x1410ca239*/
      if ( FLog::Network != 0 )
        FLog::FastLogFormatted(
          level: FLog::Network,
          message: "[FLog::Network] Detected long RunUpdateCycle. sinceLastCycle: %.3f toAfterBufferedHandling: %.3f toAfterReques"
          "tConnection: %.3f toAfterDisconnectChecks: %.3f toAfterPingInternal: %.3f toAfterReliableReceive: %.3f toReturn: %.3f",
          v2,
          v3,
          v4,
          v5,
          v6,
          v7,
          v8);
      RBX::Analytics::InfluxDb::Points::Points( /*0x1410ca299*/
        this: &points,
        throttleHundredthsPercentage: -1,
        categoryType: kStandardType,
        priorityHundredthsPercentage: 0);
      __wind /*0xf1c0000000000028*/
      {
        RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "TimeSinceLastCycleMs", value: v2); /*0x1410ca2ae*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410ca2c2*/
          this: &points,
          name: "CycleStartToAfterBufferedHandlingMs",
          value: v3);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410ca2d7*/
          this: &points,
          name: "CycleStartToAfterRequestConnectionMs",
          value: v4);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410ca2ec*/
          this: &points,
          name: "CycleStartToAfterDisconnectChecksMs",
          value: v5);
        RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "CycleStartToAfterPingInternalMs", value: v6); /*0x1410ca301*/
        RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "CycleStartToAfterReliableReceiveMs", value: v7); /*0x1410ca316*/
        RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "CycleStartToReturn", value: v8); /*0x1410ca32b*/
        v9 = DFInt::TrackRunUpdateCycleReportInfluxPermyriad; /*0x1410ca330*/
        v10 = (char *)operator new(size: 0x20u); /*0x1410ca352*/
        resource._Mypair._Myval2._Mysize = 18; /*0x1410ca357*/
        resource._Mypair._Myval2._Myres = 31; /*0x1410ca360*/
        strcpy(v10, "LongRunUpdateCycle"); /*0x1410ca370*/
        resource._Mypair._Myval2._Bx._Ptr = v10; /*0x1410ca382*/
        __wind /*0xf1c000000000001c*/
        {
          RBX::Analytics::InfluxDb::Points::report( /*0x1410ca397*/
            this: &points,
            &resource,
            throttleHundredthsPercentage: v9,
            blocking: false);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000014*/
        }
        if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x1410ca3a6*/
        {
          Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x1410ca3ab*/
          if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410ca3ba*/
          {
            Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x1410ca3c0*/
            if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410ca3cf*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410ca3d1*/
          }
          operator delete(ptr: Ptr); /*0x1410ca3d8*/
        }
        RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0x1410ca3e3*/
      }
      __unwind
      {
        RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c0000000000008*/
      }
    }
  }
  this->runUpdateCycleStats.lastCycleStart.sec = cycleStartFast.sec; /*0x1410ca3f1*/
}

// Address: 0x1410cad40 | Name: ?doReceiveLoop@RakPeer@RakNet@@UEAAX_N@Z
void __fastcall RakNet::RakPeer::doReceiveLoop(RakNet::RakPeer *this, bool debugReport)
{
  unsigned __int64 TimeMS; // rbp
  char v5; // si
  bool v6; // zf
  RakNet::Packet *packet; // rdi
  unsigned __int8 *data; // rdx
  RBX::Network::Peer *peerPlugin; // rcx
  RakNet::RakPeer::ReceivedPacketAndMetaData receivedPacket; // [rsp+20h] [rbp-28h] BYREF
  RakNet::RakPeer::ReceivedPacketAndMetaData result; // [rsp+30h] [rbp-18h] BYREF

  if ( debugReport ) /*0x1410cad52*/
  {
    if ( DFLog::ClientRecvFromRaknet != 0 ) /*0x1410cad5d*/
      FLog::FastLog( /*0x1410cad6d*/
        level: DFLog::ClientRecvFromRaknet,
        message: "[DFLog::ClientRecvFromRaknet] RakPeer has distributed %d packets to plugins since last debug time",
        arg0: (const void *)this->packetsDistributedToPluginsSinceLastDebug);
    if ( DFFlag::DebugRakPeerReceiveCountDistributedPackets.value ) /*0x1410cad79*/
      this->packetsDistributedToPluginsSinceLastDebug = 0; /*0x1410cad7b*/
  }
  if ( !this->IsActive(this) ) /*0x1410cad91*/
  {
    if ( debugReport && DFLog::ClientRecvFromRaknet != 0 ) /*0x1410cada5*/
      FLog::FastLog( /*0x1410cadbf*/
        level: DFLog::ClientRecvFromRaknet,
        message: "[DFLog::ClientRecvFromRaknet] RakPeer is NOT active, returning",
        arg0: nullptr);
    return; /*0x1410cadbf*/
  }
  TimeMS = (unsigned int)RakNet::GetTimeMS(); /*0x1410cadd8*/
  v5 = 0; /*0x1410caddd*/
  RakNet::RakPeer::getNextPacket(this, result: &receivedPacket); /*0x1410cade0*/
  v6 = !debugReport; /*0x1410cade5*/
  packet = receivedPacket.packet; /*0x1410cade8*/
  if ( !v6 ) /*0x1410caded*/
  {
    if ( receivedPacket.packet == nullptr ) /*0x1410cadf2*/
    {
      if ( DFLog::ClientRecvFromRaknet != 0 ) /*0x1410cadfd*/
        FLog::FastLog( /*0x1410cae0d*/
          level: DFLog::ClientRecvFromRaknet,
          message: "[DFLog::ClientRecvFromRaknet] PacketReturnQueue is empty, no work to do",
          arg0: nullptr);
      goto LABEL_29; /*0x1410cae12*/
    }
    do /*0x1410caecd*/
    {
LABEL_15:
      if ( !FFlag::NoJoinDiscoThrottleRakNet3.value && receivedPacket.isJoinOrDisconnectRequest ) /*0x1410cae4b*/
        v5 = 1; /*0x1410cae4b*/
      if ( !receivedPacket.wasPacketDeferred ) /*0x1410cae51*/
        packet->timePopped = TimeMS; /*0x1410cae53*/
      if ( packet->length >= 9 ) /*0x1410cae5b*/
      {
        data = packet->data; /*0x1410cae5d*/
        if ( *data == 27 ) /*0x1410cae64*/
          RakNet::RakPeer::ShiftIncomingTimestamp(this, data: data + 1, systemAddress: &packet->systemAddress); /*0x1410cae6f*/
      }
      if ( DFFlag::DebugRakPeerReceiveCountDistributedPackets.value ) /*0x1410cae7b*/
        ++this->packetsDistributedToPluginsSinceLastDebug; /*0x1410cae7d*/
      peerPlugin = this->peerPlugin; /*0x1410cae84*/
      if ( peerPlugin == nullptr || peerPlugin->OnReceive(this: peerPlugin, a2: packet) != RR_STOP_PROCESSING ) /*0x1410cae9f*/
        this->DeallocatePacket(this, a2: packet); /*0x1410caeaa*/
      receivedPacket = *RakNet::RakPeer::getNextPacket(this, &result); /*0x1410caec5*/
      packet = receivedPacket.packet; /*0x1410caec0*/
    }
    while ( receivedPacket.packet != nullptr ); /*0x1410caecd*/
    goto LABEL_29; /*0x1410caecd*/
  }
  if ( receivedPacket.packet != nullptr ) /*0x1410cae1a*/
    goto LABEL_15; /*0x1410cae1a*/
LABEL_29:
  if ( !FFlag::NoJoinDiscoThrottleRakNet3.value && v5 == 0 ) /*0x1410caee9*/
    ++this->stepsFromLastJoinOrDisconnect_deprecated; /*0x1410caeeb*/
}

// Address: 0x1410caf10 | Name: ?doesPeerHaveCapabilityInCommon@RakPeer@RakNet@@UEBA_NUSystemAddress@2@W4RakPeerCapabilities@2@@Z
bool __fastcall RakNet::RakPeer::doesPeerHaveCapabilityInCommon(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *systemAddress,
        RakNet::RakPeerCapabilities capability)
{
  RakNet::RakPeer_vtbl *v3; // rax
  __int128 v4; // xmm1
  _QWORD v6[4]; // [rsp+20h] [rbp-28h] BYREF

  v3 = this->__vftable; /*0x1410caf19*/
  v4 = *((_OWORD *)&systemAddress->address.addr4 + 1); /*0x1410caf1f*/
  *(_OWORD *)v6 = *(_OWORD *)&systemAddress->address.addr6.sin6_family; /*0x1410caf28*/
  *(_OWORD *)&v6[2] = v4; /*0x1410caf2d*/
  return (v3->getCommonCapabilities(this, a2: (const RakNet::SystemAddress *)v6) & capability) != 0; /*0x1410caf3e*/
}

// Address: 0x1410caf50 | Name: ?findRequestedConnectionStruct@RakPeer@RakNet@@IEAAPEAURequestedConnectionStruct@12@AEBUSystemAddress@2@@Z
RakNet::RakPeer::RequestedConnectionStruct *__fastcall RakNet::RakPeer::findRequestedConnectionStruct(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *systemAddress)
{
  unsigned __int64 i; // rdi
  unsigned int head; // r8d
  unsigned int tail; // eax
  unsigned int v7; // eax
  unsigned int allocation_size; // eax
  __int64 v9; // rdx
  unsigned int v10; // r8d
  RakNet::RakPeer::RequestedConnectionStruct *v11; // rbp

  rtc::CriticalSection::Enter(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410caf72*/
  for ( i = 0; ; ++i )
  {
    head = this->requestedConnectionQueue.head; /*0x1410caf80*/
    tail = this->requestedConnectionQueue.tail; /*0x1410caf87*/
    v7 = head > tail ? this->requestedConnectionQueue.allocation_size - head + tail : tail - head;
    if ( i >= v7 ) /*0x1410cafa7*/
      break; /*0x1410cafa7*/
    allocation_size = this->requestedConnectionQueue.allocation_size; /*0x1410cafa9*/
    v9 = head + (unsigned int)i; /*0x1410cafaf*/
    v10 = i + head - allocation_size; /*0x1410cafbd*/
    if ( (unsigned int)v9 >= allocation_size ) /*0x1410cafc2*/
      v9 = v10; /*0x1410cafc2*/
    v11 = this->requestedConnectionQueue.array[v9]; /*0x1410cafc6*/
    if ( RakNet::SystemAddress::operator==(this: &v11->systemAddress, right: systemAddress) != 0 ) /*0x1410cafd7*/
    {
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410cafe5*/
      return v11; /*0x1410cafed*/
    }
  }
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410caff6*/
  return nullptr; /*0x1410caffd*/
}

// Address: 0x1410cb020 | Name: ?freeAllocatedSendPackets@RakPeer@RakNet@@QEAAXXZ
void __fastcall RakNet::RakPeer::freeAllocatedSendPackets(RakNet::RakPeer *this)
{
  unsigned int i; // edi
  unsigned int head; // r9d
  unsigned int tail; // ecx
  unsigned int v5; // ecx
  __int64 v6; // rdx
  unsigned int allocation_size; // eax
  unsigned int v8; // r9d
  unsigned int v9; // eax
  unsigned __int64 j; // rdx
  RakNet::Packet *packet; // r8

  rtc::CriticalSection::Enter(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410cb03e*/
  for ( i = 0; ; ++i )
  {
    head = this->packetReturnQueue.head; /*0x1410cb050*/
    tail = this->packetReturnQueue.tail; /*0x1410cb057*/
    v5 = head > tail ? this->packetReturnQueue.allocation_size - head + tail : tail - head;
    if ( i >= v5 ) /*0x1410cb074*/
      break; /*0x1410cb074*/
    v6 = head + i; /*0x1410cb079*/
    allocation_size = this->packetReturnQueue.allocation_size; /*0x1410cb08b*/
    v8 = i + head - allocation_size; /*0x1410cb094*/
    if ( (unsigned int)v6 >= allocation_size ) /*0x1410cb099*/
      v6 = v8; /*0x1410cb099*/
    this->DeallocatePacket(this, a2: this->packetReturnQueue.array[v6]); /*0x1410cb0a4*/
  }
  v9 = this->packetReturnQueue.allocation_size; /*0x1410cb0ab*/
  if ( v9 != 0 ) /*0x1410cb0b3*/
  {
    if ( v9 > 0x20 ) /*0x1410cb0b8*/
    {
      operator delete(ptr: this->packetReturnQueue.array); /*0x1410cb0c1*/
      this->packetReturnQueue.allocation_size = 0; /*0x1410cb0c6*/
    }
    *(_QWORD *)&this->packetReturnQueue.head = 0; /*0x1410cb0cc*/
  }
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410cb0da*/
  if ( !FFlag::NoJoinDiscoThrottleRakNet3.value ) /*0x1410cb0e6*/
  {
    for ( j = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize; /*0x1410cb0f2*/
          j != 0;
          j = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize )
    {
      packet = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Map[this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff /*0x1410cb120*/
                                                                                      & (this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mapsize
                                                                                       - 1)]->packet;
      this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize = j - 1; /*0x1410cb123*/
      if ( j == 1 ) /*0x1410cb12d*/
        this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff = 0; /*0x1410cb12f*/
      else
        ++this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff; /*0x1410cb138*/
      this->DeallocatePacket(this, a2: packet); /*0x1410cb148*/
    }
  }
  rtc::CriticalSection::Enter(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410cb161*/
  DataStructures::MemoryPool<RakNet::RemoteSystemIndex>::Clear( /*0x1410cb17a*/
    this: (DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode> *)&this->packetAllocationPool,
    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
    line: 0x4DFu);
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetAllocationPoolMutex.criticalSection); /*0x1410cb19a*/
}

// Address: 0x1410cb1a0 | Name: ?generateUdmuxToken@RakPeer@RakNet@@MEAAXPEAEPEBUSystemAddress@2@IPEAV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@_N@Z
void __fastcall RakNet::RakPeer::generateUdmuxToken(
        RakNet::RakPeer *this,
        unsigned __int8 *token,
        const RakNet::SystemAddress *systemAddress,
        unsigned int tokenOptions,
        std::string *logInfo,
        bool includeFirst)
{
  unsigned int v9; // edi
  bool i; // cf
  __int64 v11; // rsi
  std::string *p_thisLogInfo; // r9
  std::string *p_firstLogInfo; // r8
  std::string *v14; // rax
  char *Ptr; // rcx
  char *v16; // rcx
  char *v17; // rcx
  std::string thisLogInfo; // [rsp+30h] [rbp-59h] BYREF
  std::string firstLogInfo; // [rsp+50h] [rbp-39h] BYREF
  RakNet::SystemAddress right; // [rsp+70h] [rbp-19h] BYREF
  std::string result; // [rsp+90h] [rbp+7h] BYREF

  if ( logInfo != nullptr && includeFirst ) /*0x1410cb1e3*/
  {
    right = *systemAddress; /*0x1410cb1ed*/
    if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410cb20f*/
    {
      v9 = 0; /*0x1410cb211*/
      for ( i = this->maximumNumberOfPeers != 0; i; i = v9 < this->maximumNumberOfPeers ) /*0x1410cb214*/
      {
        v11 = (int)v9; /*0x1410cb21e*/
        if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v11].systemAddress, &right) != 0 /*0x1410cb247*/
          && this->remoteSystemList[v11].isActive._Storage._Value )
        {
          break; /*0x1410cb24e*/
        }
        ++v9; /*0x1410cb250*/
      }
    }
    firstLogInfo._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410cb269*/
    firstLogInfo._Mypair._Myval2._Mysize = 0; /*0x1410cb26d*/
    firstLogInfo._Mypair._Myval2._Myres = 15; /*0x1410cb271*/
    __wind /*0xf1c0000000000028*/
    {
      RBX::Reflection::TypedPropertyDescriptor<RBX::UDim>::hasStringValue(__formal: (bool)this->ruppTokenProcessor._Mypair._Myval2); /*0x1410cb2a0*/
      thisLogInfo._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410cb2a5*/
      thisLogInfo._Mypair._Myval2._Mysize = 0; /*0x1410cb2a9*/
      thisLogInfo._Mypair._Myval2._Myres = 15; /*0x1410cb2ad*/
      __wind /*0xf1c000000000001c*/
      {
        RBX::RuppTokenProcessor::generate( /*0x1410cb2d9*/
          this: this->ruppTokenProcessor._Mypair._Myval2,
          token,
          server: &this->rccBoundAddress,
          client: systemAddress,
          options: tokenOptions,
          logInfo: &thisLogInfo);
        p_thisLogInfo = &thisLogInfo; /*0x1410cb2de*/
        if ( thisLogInfo._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cb2e7*/
          p_thisLogInfo = (std::string *)thisLogInfo._Mypair._Myval2._Bx._Ptr; /*0x1410cb2e7*/
        p_firstLogInfo = &firstLogInfo; /*0x1410cb2ec*/
        if ( firstLogInfo._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cb2f5*/
          p_firstLogInfo = (std::string *)firstLogInfo._Mypair._Myval2._Bx._Ptr; /*0x1410cb2f5*/
        v14 = RBX::format( /*0x1410cb305*/
                &result,
                fmt: "%s && %s",
                p_firstLogInfo->_Mypair._Myval2._Bx._Buf,
                p_thisLogInfo->_Mypair._Myval2._Bx._Buf);
        std::string::operator=(this: logInfo, _Right: v14); /*0x1410cb310*/
        if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cb31d*/
        {
          Ptr = result._Mypair._Myval2._Bx._Ptr; /*0x1410cb322*/
          if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cb330*/
          {
            Ptr = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cb336*/
            if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410cb345*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410cb347*/
          }
          operator delete(ptr: Ptr); /*0x1410cb34e*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&thisLogInfo); /*0xf1c0000000000014*/
      }
      if ( thisLogInfo._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cb35c*/
      {
        v16 = thisLogInfo._Mypair._Myval2._Bx._Ptr; /*0x1410cb361*/
        if ( thisLogInfo._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cb36f*/
        {
          v16 = *((char **)thisLogInfo._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cb375*/
          if ( (unsigned __int64)(thisLogInfo._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x1410cb384*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410cb386*/
        }
        operator delete(ptr: v16); /*0x1410cb38d*/
      }
      thisLogInfo._Mypair._Myval2._Mysize = 0; /*0x1410cb392*/
      thisLogInfo._Mypair._Myval2._Myres = 15; /*0x1410cb396*/
      thisLogInfo._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410cb39e*/
      if ( firstLogInfo._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cb3aa*/
      {
        v17 = firstLogInfo._Mypair._Myval2._Bx._Ptr; /*0x1410cb3af*/
        if ( firstLogInfo._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cb3bd*/
        {
          v17 = *((char **)firstLogInfo._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cb3c3*/
          if ( (unsigned __int64)(firstLogInfo._Mypair._Myval2._Bx._Ptr - v17 - 8) > 0x1F ) /*0x1410cb3d2*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410cb3d4*/
        }
        operator delete(ptr: v17); /*0x1410cb3db*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&firstLogInfo); /*0xf1c0000000000008*/
    }
  }
  else
  {
    RBX::RuppTokenProcessor::generate( /*0x1410cb3fa*/
      this: this->ruppTokenProcessor._Mypair._Myval2,
      token,
      server: &this->rccBoundAddress,
      client: systemAddress,
      options: tokenOptions,
      logInfo);
  }
}

// Address: 0x1410cb420 | Name: ?getAvaliableNetworkCapacityInBytesInNextMs@RakPeer@RakNet@@UEAAHAEBUSystemAddress@2@HM@Z
int __fastcall RakNet::RakPeer::getAvaliableNetworkCapacityInBytesInNextMs(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *target,
        const int rssIndexHint,
        float ms)
{
  __int128 v5; // xmm1
  int v7; // ebx
  __int64 v8; // rsi
  RakNet::RakPeer::RemoteSystemStruct *v10; // rcx
  RakNet::SystemAddress right; // [rsp+20h] [rbp-38h] BYREF

  v5 = *((_OWORD *)&target->address.addr4 + 1); /*0x1410cb43a*/
  *(_OWORD *)&right.address.addr6.sin6_family = *(_OWORD *)&target->address.addr6.sin6_family; /*0x1410cb44d*/
  *((_OWORD *)&right.address.addr4 + 1) = v5; /*0x1410cb452*/
  if ( RakNet::SystemAddress::operator==(this: &right, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 ) /*0x1410cb45e*/
    return -1; /*0x1410cb45e*/
  v7 = 0; /*0x1410cb460*/
  if ( this->maximumNumberOfPeers == 0 ) /*0x1410cb466*/
    return -1; /*0x1410cb466*/
  while ( 1 ) /*0x1410cb483*/
  {
    v8 = v7; /*0x1410cb483*/
    if ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v8].systemAddress, &right) != 0 /*0x1410cb49d*/
      && this->remoteSystemList[v8].isActive._Storage._Value )
    {
      break; /*0x1410cb4a4*/
    }
    if ( ++v7 >= (unsigned int)this->maximumNumberOfPeers ) /*0x1410cb4ae*/
      return -1; /*0x1410cb4ae*/
  }
  v10 = &this->remoteSystemList[v8]; /*0x1410cb4d1*/
  if ( v10 != nullptr ) /*0x1410cb4d4*/
    return RakNet::ReliabilityLayer::getAvaliableNetworkCapacityInBytesInNextMs( /*0x1410cb4e0*/
             this: (RakNet::ReliabilityLayer *)((char *)&v10->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
             ms);
  else
    return -1; /*0x1410cb4b0*/
}

// Address: 0x1410cb4f0 | Name: ?getCommonCapabilities@RakPeer@RakNet@@UEBA_KUSystemAddress@2@@Z
unsigned __int64 __fastcall RakNet::RakPeer::getCommonCapabilities(
        RakNet::RakPeer *this,
        const RakNet::SystemAddress *systemAddress)
{
  unsigned __int16 v4; // bx

  if ( this->remoteSystemList == nullptr ) /*0x1410cb512*/
    return 0; /*0x1410cb512*/
  v4 = 0; /*0x1410cb514*/
  if ( this->maximumNumberOfPeers == 0 ) /*0x1410cb51a*/
    return 0; /*0x1410cb54d*/
  while ( RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v4].systemAddress, right: systemAddress) == 0 ) /*0x1410cb542*/
  {
    if ( ++v4 >= this->maximumNumberOfPeers ) /*0x1410cb54b*/
      return 0; /*0x1410cb54b*/
  }
  return this->remoteSystemList[v4].remoteCommonCapabilities; /*0x1410cb54f*/
}

// Address: 0x1410cb580 | Name: ?getDisconnectReason@RakPeer@RakNet@@UEAAIXZ
__int64 __fastcall RakNet::RakPeer::getDisconnectReason(RakNet::RakPeer *this)
{
  return this->disconnectReason; /*0x1410cb586*/
}

// Address: 0x1410cb590 | Name: ?getJoinRequestInitiatedTimeInMS@RakPeer@RakNet@@UEAAIUAddressOrGUID@2@@Z
RakNet::RakPeer::RemoteSystemStruct *__fastcall RakNet::RakPeer::getJoinRequestInitiatedTimeInMS(
        RakNet::RakPeer *this,
        const RakNet::AddressOrGUID *systemIdentifier)
{
  RakNet::RakPeer::RemoteSystemStruct *result; // rax
  RakNet::RakNetGUID rakNetGuid; // [rsp+20h] [rbp-38h] BYREF
  RakNet::SystemAddress v6; // [rsp+30h] [rbp-28h] BYREF

  RakNet::RakNetGUID::RakNetGUID(this: &rakNetGuid); /*0x1410cb5a5*/
  RakNet::SystemAddress::SystemAddress(this: &v6); /*0x1410cb5af*/
  rakNetGuid = systemIdentifier->rakNetGuid; /*0x1410cb5bb*/
  RakNet::SystemAddress::operator=(this: &v6, input: &systemIdentifier->systemAddress); /*0x1410cb5ce*/
  result = RakNet::RakPeer::GetRemoteSystem( /*0x1410cb5e1*/
             this,
             systemIdentifier: (RBX::json::ArrayIterator *)&rakNetGuid,
             calledFromNetworkThread: false,
             onlyActive: true);
  if ( result != nullptr ) /*0x1410cb5e9*/
    return (RakNet::RakPeer::RemoteSystemStruct *)result->joinRequestInitiatedTimeInMS; /*0x1410cb5f6*/
  return result; /*0x1410cb5eb*/
}

// Address: 0x1410cb610 | Name: ?getNextPacket@RakPeer@RakNet@@IEAA?AUReceivedPacketAndMetaData@12@XZ
RakNet::RakPeer::ReceivedPacketAndMetaData *__fastcall RakNet::RakPeer::getNextPacket(
        RakNet::RakPeer *this,
        RakNet::RakPeer::ReceivedPacketAndMetaData *result)
{
  unsigned int head; // eax
  unsigned int allocation_size; // ecx
  unsigned int v6; // eax
  RakNet::Packet **array; // rdx
  __int64 v8; // rax
  RakNet::Packet *v9; // rdx
  unsigned __int8 v10; // cl
  const char *v12; // r8
  unsigned int i; // eax
  unsigned int v15; // ecx
  unsigned int v16; // eax
  RakNet::Packet **v17; // rsi
  __int64 v18; // rax
  RakNet::Packet *v19; // rsi
  unsigned __int64 v20; // rcx
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker> > > > *Myfirst; // rax
  __int64 v22; // rcx
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *Ptr; // rdi
  std::_List_node<std::pair<RakNet::SystemAddress const ,RakNet::RakPeer::BytesInReturnQueuePeerTracker>,void *> *v24; // rbp
  unsigned int v25; // eax
  RakNet::Packet *packet; // rcx
  unsigned __int8 v27; // dl
  unsigned __int8 v28; // cl
  unsigned int TimeMS; // [rsp+78h] [rbp+10h] BYREF
  unsigned __int64 Mysize; // [rsp+80h] [rbp+18h] BYREF

  result->packet = nullptr; /*0x1410cb623*/
  *(_WORD *)&result->wasPacketDeferred = 0; /*0x1410cb629*/
  if ( FFlag::NoJoinDiscoThrottleRakNet3.value ) /*0x1410cb635*/
  {
    rtc::CriticalSection::Enter(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410cb642*/
    head = this->packetReturnQueue.head; /*0x1410cb647*/
    if ( head != this->packetReturnQueue.tail ) /*0x1410cb653*/
    {
      allocation_size = this->packetReturnQueue.allocation_size; /*0x1410cb659*/
      v6 = head + 1; /*0x1410cb65f*/
      array = this->packetReturnQueue.array; /*0x1410cb661*/
      this->packetReturnQueue.head = v6; /*0x1410cb668*/
      if ( v6 == allocation_size ) /*0x1410cb670*/
      {
        this->packetReturnQueue.head = 0; /*0x1410cb672*/
        v8 = allocation_size - 1; /*0x1410cb679*/
      }
      else if ( v6 != 0 ) /*0x1410cb680*/
      {
        v8 = v6 - 1; /*0x1410cb687*/
      }
      else
      {
        v8 = allocation_size - 1; /*0x1410cb682*/
      }
      v9 = array[v8]; /*0x1410cb689*/
      result->packet = v9; /*0x1410cb68d*/
      v10 = *v9->data; /*0x1410cb694*/
      if ( v10 != 0x90 && (unsigned __int8)(v10 - 21) > 1u ) /*0x1410cb6a2*/
      {
        result->isJoinOrDisconnectRequest = false; /*0x1410cb6ab*/
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410cb6af*/
        return result; /*0x1410cb6c3*/
      }
      result->isJoinOrDisconnectRequest = true; /*0x1410cb6c4*/
      if ( DFLog::RaknetJoinOrDisconnectRequest != 0 ) /*0x1410cb6d4*/
      {
        v12 = "disconnect"; /*0x1410cb6e1*/
        if ( *v9->data == 0x90 ) /*0x1410cb6f2*/
          v12 = "join"; /*0x1410cb6f2*/
        FLog::FastLogFormatted( /*0x1410cb6f9*/
          level: DFLog::RaknetJoinOrDisconnectRequest,
          message: "[DFLog::RaknetJoinOrDisconnectRequest] RakNet Receiving %s packet",
          v12);
      }
    }
    RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410cb705*/
    return result; /*0x1410cb70a*/
  }
  else
  {
    if ( this->stepsFromLastJoinOrDisconnect_deprecated >= DFInt::StepsToJoinOrDisconnect /*0x1410cb72f*/
      && this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize != 0 )
    {
      result->packet = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Map[this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff /*0x1410cb750*/
                                                                                              & (this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mapsize
                                                                                               - 1)]->packet;
      result->wasPacketDeferred = true; /*0x1410cb753*/
      if ( this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize-- == 1 ) /*0x1410cb757*/
        this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff = 0; /*0x1410cb761*/
      else
        ++this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Myoff; /*0x1410cb76d*/
    }
    else
    {
      rtc::CriticalSection::Enter(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410cb785*/
      for ( i = this->packetReturnQueue.head; i != this->packetReturnQueue.tail; i = this->packetReturnQueue.head ) /*0x1410cb796*/
      {
        v15 = this->packetReturnQueue.allocation_size; /*0x1410cb7b0*/
        v16 = i + 1; /*0x1410cb7b6*/
        v17 = this->packetReturnQueue.array; /*0x1410cb7b8*/
        this->packetReturnQueue.head = v16; /*0x1410cb7bf*/
        if ( v16 == v15 ) /*0x1410cb7c7*/
        {
          this->packetReturnQueue.head = 0; /*0x1410cb7c9*/
          v18 = v15 - 1; /*0x1410cb7d0*/
        }
        else if ( v16 != 0 ) /*0x1410cb7d7*/
        {
          v18 = v16 - 1; /*0x1410cb7de*/
        }
        else
        {
          v18 = v15 - 1; /*0x1410cb7d9*/
        }
        v19 = v17[v18]; /*0x1410cb7e0*/
        result->packet = v19; /*0x1410cb7e4*/
        if ( DFFlag::CLI56775.value ) /*0x1410cb7ee*/
        {
          v20 = RakNet::SystemAddress::ToInteger(sa: &v19->systemAddress) & this->bytesInReturnQueue._Mask; /*0x1410cb801*/
          Myfirst = this->bytesInReturnQueue._Vec._Mypair._Myval2._Myfirst; /*0x1410cb804*/
          v22 = 2 * v20; /*0x1410cb80b*/
          Ptr = Myfirst[v22 + 1]._Ptr; /*0x1410cb80e*/
          if ( Ptr != this->bytesInReturnQueue._List._Mypair._Myval2._Myhead ) /*0x1410cb81a*/
          {
            v24 = Myfirst[v22]._Ptr; /*0x1410cb81c*/
            if ( RakNet::SystemAddress::operator==(this: &v19->systemAddress, right: &Ptr->_Myval.first) != 0 ) /*0x1410cb82e*/
            {
LABEL_32:
              if ( Ptr != nullptr && Ptr != this->bytesInReturnQueue._List._Mypair._Myval2._Myhead ) /*0x1410cb855*/
              {
                v25 = 0; /*0x1410cb860*/
                if ( (signed int)(Ptr->_Myval.second.bytes - result->packet->length) > 0 ) /*0x1410cb865*/
                  v25 = Ptr->_Myval.second.bytes - result->packet->length; /*0x1410cb865*/
                Ptr->_Myval.second.bytes = v25; /*0x1410cb868*/
              }
            }
            else
            {
              while ( Ptr != v24 ) /*0x1410cb833*/
              {
                Ptr = Ptr->_Prev; /*0x1410cb835*/
                if ( RakNet::SystemAddress::operator==(this: &v19->systemAddress, right: &Ptr->_Myval.first) != 0 ) /*0x1410cb847*/
                  goto LABEL_32; /*0x1410cb847*/
              }
            }
          }
        }
        packet = result->packet; /*0x1410cb86b*/
        v27 = *result->packet->data; /*0x1410cb872*/
        if ( (v27 == 0x90 || (unsigned __int8)(v27 - 21) <= 1u) /*0x1410cb88e*/
          && this->stepsFromLastJoinOrDisconnect_deprecated < DFInt::StepsToJoinOrDisconnect )
        {
          Mysize = this->deferredJoinAndDisconnectTickets_deprecated.c._Mypair._Myval2._Mysize; /*0x1410cb897*/
          TimeMS = RakNet::GetTimeMS(); /*0x1410cb8a4*/
          std::queue<RakNet::RakPeer::DeferredQueueInfo>::emplace<RakNet::Packet * &,unsigned int,bool &,unsigned __int64>( /*0x1410cb8c8*/
            this: &this->deferredJoinAndDisconnectTickets_deprecated,
            <_Val_0>: &result->packet,
            <_Val_1>: &TimeMS,
            <_Val_2>: &result->isJoinOrDisconnectRequest,
            <_Val_3>: &Mysize);
          *result = 0; /*0x1410cb8d0*/
          packet = result->packet; /*0x1410cb8d4*/
        }
        if ( packet != nullptr ) /*0x1410cb8da*/
          break; /*0x1410cb8da*/
      }
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->packetReturnMutex.criticalSection); /*0x1410cb8ff*/
    }
    if ( result->packet != nullptr ) /*0x1410cb90f*/
    {
      v28 = *result->packet->data; /*0x1410cb915*/
      if ( v28 != 0x90 && (unsigned __int8)(v28 - 21) > 1u ) /*0x1410cb923*/
      {
        result->isJoinOrDisconnectRequest = false; /*0x1410cb925*/
        return result; /*0x1410cb938*/
      }
      result->isJoinOrDisconnectRequest = true; /*0x1410cb939*/
      this->stepsFromLastJoinOrDisconnect_deprecated = 0; /*0x1410cb93e*/
    }
    return result; /*0x1410cb945*/
  }
}

// Address: 0x1410cb960 | Name: ?getPacketsPerPeerOneCycleStatsAndReset@RakPeer@RakNet@@UEAAXAEAMAEAH1@Z
void __fastcall RakNet::RakPeer::getPacketsPerPeerOneCycleStatsAndReset(
        RakNet::RakPeer *this,
        float *avg,
        int *min,
        int *max)
{
  int numCyclesSampled; // r10d

  numCyclesSampled = this->numCyclesSampled; /*0x1410cb960*/
  if ( numCyclesSampled != 0 ) /*0x1410cb96d*/
    *avg = (float)(this->totalPacketsPerPeerOneCycle / numCyclesSampled); /*0x1410cb980*/
  *min = this->minPacketsPerPeerOneCycle; /*0x1410cb98b*/
  *max = this->maxPacketsPerPeerOneCycle; /*0x1410cb994*/
  *(_QWORD *)&this->totalPacketsPerPeerOneCycle = 0; /*0x1410cb999*/
  this->minPacketsPerPeerOneCycle = 0x7FFFFFFF; /*0x1410cb9a0*/
  this->maxPacketsPerPeerOneCycle = 0x80000000; /*0x1410cb9aa*/
}

// Address: 0x1410cb9c0 | Name: ?getRuppHeader@RakPeer@RakNet@@UEAA?AV?$shared_ptr@VRupp@1Network@RBX@@@std@@XZ
std::shared_ptr<RBX::Network::Rupp::Rupp> *__fastcall RakNet::RakPeer::getRuppHeader(
        RakNet::RakPeer *this,
        std::shared_ptr<RBX::Network::Rupp::Rupp> *result)
{
  std::_Ref_count_base *Rep; // r8

  Rep = this->ruppHeader._Rep; /*0x1410cb9c0*/
  result->_Ptr = nullptr; /*0x1410cb9c9*/
  result->_Rep = nullptr; /*0x1410cb9cc*/
  if ( Rep != nullptr ) /*0x1410cb9d3*/
  {
    _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410cb9d5*/
    Rep = this->ruppHeader._Rep; /*0x1410cb9da*/
  }
  result->_Ptr = this->ruppHeader._Ptr; /*0x1410cb9e8*/
  result->_Rep = Rep; /*0x1410cb9ee*/
  return result; /*0x1410cb9f2*/
}

// Address: 0x1410cba00 | Name: ?getServerReceiveRuppToken@RakPeer@RakNet@@MEAA_NXZ
_BOOL8 __fastcall RakNet::RakPeer::getServerReceiveRuppToken(RakNet::RakPeer *this)
{
  return this->serverReceiveRuppToken; /*0x1410cba04*/
}

// Address: 0x1410cba10 | Name: ?getSessionCryptoFromSystemAddress@RakPeer@RakNet@@UEAA?AV?$shared_ptr@VSessionCrypto@Security@RBX@@@std@@USystemAddress@2@@Z
std::shared_ptr<RBX::Security::SessionCrypto> *__fastcall RakNet::RakPeer::getSessionCryptoFromSystemAddress(
        RakNet::RakPeer *this,
        std::shared_ptr<RBX::Security::SessionCrypto> *result,
        const RakNet::SystemAddress *systemAddress)
{
  unsigned __int16 v6; // bx
  bool i; // cf
  __int64 v8; // rdx
  __int64 v9; // rcx
  RakNet::RakPeer::RemoteSystemStruct *remoteSystemList; // rax
  std::_Ref_count_base *v11; // rdi
  RBX::Security::RakPeerCrypto *v12; // rbx
  bool isKeyExchangeComplete; // al
  std::shared_ptr<RBX::Security::RakPeerCrypto> crypto; // [rsp+40h] [rbp-28h] BYREF

  if ( this->remoteSystemList != nullptr ) /*0x1410cba3b*/
  {
    v6 = 0; /*0x1410cba41*/
    for ( i = this->maximumNumberOfPeers != 0; i; i = v6 < this->maximumNumberOfPeers ) /*0x1410cba45*/
    {
      v8 = v6; /*0x1410cba53*/
      if ( this->remoteSystemList[v8].isActive._Storage._Value /*0x1410cba82*/
        && RakNet::SystemAddress::operator==(this: &this->remoteSystemList[v8].systemAddress, right: systemAddress) != 0 )
      {
        v9 = v6; /*0x1410cba8d*/
        remoteSystemList = this->remoteSystemList; /*0x1410cba94*/
        v11 = *(std::_Ref_count_base **)((char *)&remoteSystemList[v9].reliabilityLayer.rbxSessionCrypto._Rep + 4); /*0x1410cba9b*/
        if ( v11 != nullptr ) /*0x1410cbaa6*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v11->_Uses); /*0x1410cbaa8*/
          v11 = *(std::_Ref_count_base **)((char *)&remoteSystemList[v9].reliabilityLayer.rbxSessionCrypto._Rep + 4); /*0x1410cbaac*/
        }
        v12 = *(RBX::Security::RakPeerCrypto **)((char *)&remoteSystemList[v9].reliabilityLayer.rbxSessionCrypto._Ptr + 4); /*0x1410cbab4*/
        crypto._Ptr = v12; /*0x1410cbabc*/
        crypto._Rep = v11; /*0x1410cbac1*/
        if ( v12 == nullptr ) /*0x1410cbace*/
          goto LABEL_15; /*0x1410cbace*/
        __wind /*0xf1c0000000000010*/
        {
          isKeyExchangeComplete = RBX::Security::SessionCrypto::isKeyExchangeComplete(this: v12); /*0x1410cbad3*/
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&crypto); /*0xf1c0000000000008*/
        }
        if ( isKeyExchangeComplete ) /*0x1410cbada*/
        {
          if ( v11 != nullptr ) /*0x1410cbadf*/
            _InterlockedIncrement((volatile signed __int32 *)&v11->_Uses); /*0x1410cbae1*/
          result->_Ptr = v12; /*0x1410cbae5*/
          result->_Rep = v11; /*0x1410cbae8*/
        }
        else
        {
LABEL_15:
          result->_Ptr = nullptr; /*0x1410cbaf3*/
          result->_Rep = nullptr; /*0x1410cbaf6*/
        }
        if ( v11 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v11->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410cbb0e*/
        {
          v11->_Destroy(this: v11); /*0x1410cbb16*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v11->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410cbb20*/
            v11->_Delete_this(this: v11); /*0x1410cbb28*/
        }
        return result; /*0x1410cbb2b*/
      }
      ++v6; /*0x1410cba84*/
    }
  }
  *result = 0; /*0x1410cbb30*/
  result->_Ptr = nullptr; /*0x1410cbb34*/
  result->_Rep = nullptr; /*0x1410cbb37*/
  return result; /*0x1410cbb3e*/
}

// Address: 0x1410cbb60 | Name: ?getTokenOptionsFromSystemAddress@RakPeer@RakNet@@UEAA?AV?$optional@I@std@@USystemAddress@2@@Z
std::optional<unsigned int> *__fastcall RakNet::RakPeer::getTokenOptionsFromSystemAddress(
        RakNet::RakPeer *this,
        std::optional<unsigned int> *result,
        const RakNet::SystemAddress *systemAddress)
{
  unsigned int RemoteSystemIndex; // eax
  __int64 v6; // rdx
  std::optional<unsigned int> v8; // [rsp+30h] [rbp+8h]

  if ( this->remoteSystemList == nullptr /*0x1410cbb85*/
    || (RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, sa: systemAddress)) == -1 )
  {
    result->_Has_value = false; /*0x1410cbbdb*/
    return result; /*0x1410cbbdf*/
  }
  else
  {
    v6 = RemoteSystemIndex; /*0x1410cbb89*/
    if ( this->remoteSystemList[v6].isActive._Storage._Value ) /*0x1410cbb97*/
    {
      *result = this->remoteSystemList[v6].tokenOptions; /*0x1410cbbaf*/
    }
    else
    {
      v8._Has_value = false; /*0x1410cbbc0*/
      *result = v8; /*0x1410cbbca*/
    }
    return result; /*0x1410cbbb2*/
  }
}

// Address: 0x1410cbbf0 | Name: ?getUsableBandwidthMbps@RakPeer@RakNet@@UEBANXZ
long double __fastcall RakNet::RakPeer::getUsableBandwidthMbps(RakNet::RakPeer *this)
{
  std::string *v2; // rax
  std::string *v3; // rbx
  unsigned __int64 Mysize; // r8
  unsigned __int64 Myres; // rdx
  unsigned __int64 Ptr; // rdi
  size_t v7; // r14
  char *v8; // rcx
  char *v9; // rcx
  char *v10; // rax
  char *v11; // rcx
  std::string counterName; // [rsp+30h] [rbp-40h] BYREF
  RBX::Graphics::ProfilerAdorn::Item resulta; // [rsp+50h] [rbp-20h] BYREF

  if ( this->downloadBandwidthTracker._Ptr == nullptr ) /*0x1410cbc1a*/
    return -1.0; /*0x1410cbe6a*/
  v2 = RBX::SystemUtil::osPlatform(result: &resulta.text); /*0x1410cbc24*/
  __wind /*0xf1c0000000000040*/
  {
    v3 = v2; /*0x1410cbc29*/
    Mysize = v2->_Mypair._Myval2._Mysize; /*0x1410cbc2c*/
    Myres = v2->_Mypair._Myval2._Myres; /*0x1410cbc30*/
    if ( Myres - Mysize < 0x21 ) /*0x1410cbc41*/
    {
      v3 = std::string::_Reallocate_grow_by<_lambda_f3a66ab6a0570788f31503db83886f49_,unsigned __int64,char const *,unsigned __int64>( /*0x1410cbcef*/
             this: v2,
             _Size_increase: 0x21u,
             _Fn: 0,
             <_Args_0>: 0,
             <_Args_1>: "RaknetDownloadBandwidthReadCount-",
             <_Args_2>: 0x21u);
    }
    else
    {
      v2->_Mypair._Myval2._Mysize = Mysize + 33; /*0x1410cbc4b*/
      Ptr = (unsigned __int64)v2; /*0x1410cbc4f*/
      if ( Myres >= 0x10 ) /*0x1410cbc56*/
        Ptr = (unsigned __int64)v2->_Mypair._Myval2._Bx._Ptr; /*0x1410cbc58*/
      if ( (unsigned __int64)"" <= Ptr || (unsigned __int64)"RaknetDownloadBandwidthReadCount-" > Ptr + Mysize ) /*0x1410cbc7b*/
      {
        v7 = 33; /*0x1410cbc8f*/
      }
      else if ( Ptr > (unsigned __int64)"RaknetDownloadBandwidthReadCount-" ) /*0x1410cbc80*/
      {
        v7 = Ptr - (_QWORD)"RaknetDownloadBandwidthReadCount-"; /*0x1410cbc8a*/
      }
      else
      {
        v7 = 0; /*0x1410cbc82*/
      }
      memmove_0(a1: (void *)(Ptr + 33), Src: (const void *)Ptr, Size: Mysize + 1); /*0x1410cbc9c*/
      memcpy_0(a1: (void *)Ptr, Src: "RaknetDownloadBandwidthReadCount-", Size: v7); /*0x1410cbcaa*/
      memcpy_0(a1: (void *)(Ptr + v7), Src: &aRaknetdownload_3[v7 + 33], Size: 33 - v7); /*0x1410cbcc0*/
    }
    __wind /*0xf1c000000000001c*/
    {
      counterName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410cbcf2*/
      counterName._Mypair._Myval2._Mysize = 0; /*0x1410cbcf6*/
      counterName._Mypair._Myval2._Myres = 0; /*0x1410cbcfa*/
      counterName = *v3; /*0x1410cbd01*/
      v3->_Mypair._Myval2._Mysize = 0; /*0x1410cbd0d*/
      v3->_Mypair._Myval2._Myres = 15; /*0x1410cbd11*/
      v3->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410cbd19*/
      RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x1410cbd27*/
      if ( counterName._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cbd35*/
      {
        v8 = counterName._Mypair._Myval2._Bx._Ptr; /*0x1410cbd3a*/
        if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cbd48*/
        {
          v8 = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cbd4e*/
          if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - v8 - 8) > 0x1F ) /*0x1410cbd5d*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410cbd5f*/
        }
        operator delete(ptr: v8); /*0x1410cbd66*/
      }
      counterName._Mypair._Myval2._Mysize = 0; /*0x1410cbd6b*/
      counterName._Mypair._Myval2._Myres = 15; /*0x1410cbd6f*/
      counterName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410cbd77*/
      if ( resulta.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cbd83*/
      {
        v9 = resulta.text._Mypair._Myval2._Bx._Ptr; /*0x1410cbd88*/
        if ( resulta.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cbd96*/
        {
          v9 = *((char **)resulta.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cbd9c*/
          if ( (unsigned __int64)(resulta.text._Mypair._Myval2._Bx._Ptr - v9 - 8) > 0x1F ) /*0x1410cbdab*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410cbdad*/
        }
        operator delete(ptr: v9); /*0x1410cbdb4*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c000000000002c*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: &resulta); /*0xf1c0000000000038*/
  }
  counterName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410cbdb9*/
  counterName._Mypair._Myval2._Mysize = 0; /*0x1410cbdbd*/
  counterName._Mypair._Myval2._Myres = 15; /*0x1410cbdc1*/
  v10 = (char *)operator new(size: 0x30u); /*0x1410cbdd2*/
  __wind /*0xf1c0000000000010*/
  {
    counterName._Mypair._Myval2._Mysize = 36; /*0x1410cbdd7*/
    counterName._Mypair._Myval2._Myres = 47; /*0x1410cbddf*/
    strcpy(v10, "RaknetDownloadBandwidthReadCount-All"); /*0x1410cbdee*/
    counterName._Mypair._Myval2._Bx._Ptr = v10; /*0x1410cbe09*/
    RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x1410cbe18*/
    if ( counterName._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cbe26*/
    {
      v11 = counterName._Mypair._Myval2._Bx._Ptr; /*0x1410cbe2b*/
      if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cbe39*/
      {
        v11 = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cbe3f*/
        if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - v11 - 8) > 0x1F ) /*0x1410cbe4e*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410cbe50*/
      }
      operator delete(ptr: v11); /*0x1410cbe57*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c0000000000008*/
  }
  return RBX::DownloadBandwidthTracker::getUsableBandwidthMbps(this: this->downloadBandwidthTracker._Ptr); /*0x1410cbe72*/
}

// Address: 0x1410cc060 | Name: ?isRecordJoinDataRxStats@RakPeer@RakNet@@UEAA_NUAddressOrGUID@2@@Z
RakNet::RakPeer::RemoteSystemStruct *__fastcall RakNet::RakPeer::isRecordJoinDataRxStats(
        RakNet::RakPeer *this,
        const RakNet::AddressOrGUID *systemIdentifier)
{
  RakNet::RakPeer::RemoteSystemStruct *result; // rax
  RakNet::RakNetGUID rakNetGuid; // [rsp+20h] [rbp-38h] BYREF
  RakNet::SystemAddress v6; // [rsp+30h] [rbp-28h] BYREF

  RakNet::RakNetGUID::RakNetGUID(this: &rakNetGuid); /*0x1410cc075*/
  RakNet::SystemAddress::SystemAddress(this: &v6); /*0x1410cc07f*/
  rakNetGuid = systemIdentifier->rakNetGuid; /*0x1410cc08b*/
  RakNet::SystemAddress::operator=(this: &v6, input: &systemIdentifier->systemAddress); /*0x1410cc09e*/
  result = RakNet::RakPeer::GetRemoteSystem( /*0x1410cc0b1*/
             this,
             systemIdentifier: (RBX::json::ArrayIterator *)&rakNetGuid,
             calledFromNetworkThread: false,
             onlyActive: true);
  if ( result != nullptr ) /*0x1410cc0b9*/
    return (RakNet::RakPeer::RemoteSystemStruct *)result->recordJoinDataRxStats._Storage._Value; /*0x1410cc0c6*/
  return result; /*0x1410cc0bb*/
}

// Address: 0x1410cc0e0 | Name: ?notifyAllAndFlagForShutdown@RakPeer@RakNet@@QEAA_NEW4PacketPriority@@@Z
__int64 __fastcall RakNet::RakPeer::notifyAllAndFlagForShutdown(
        RakNet::RakPeer *this,
        char orderingChannel,
        PacketPriority disconnectionNotificationPriority)
{
  unsigned __int8 v6; // r15
  __int64 result; // rax
  int v8; // r14d
  __int64 v9; // rsi
  unsigned __int8 *p_disconnectReason; // rdx
  unsigned __int64 TimeUS; // rbx
  RakNet::RemoteSystemIndex *v12; // rbx
  __int64 index; // rax
  RakNet::RakPeer::RemoteSystemStruct *v14; // rcx
  unsigned __int8 inOutByteArray[16]; // [rsp+60h] [rbp-A0h] BYREF
  RakNet::SystemAddress input; // [rsp+70h] [rbp-90h] BYREF
  RakNet::SystemAddress sa; // [rsp+90h] [rbp-70h] BYREF
  RakNet::RakNetGUID v18; // [rsp+B0h] [rbp-50h] BYREF
  RakNet::SystemAddress v19; // [rsp+C0h] [rbp-40h] BYREF
  RakNet::BitStream v20; // [rsp+E0h] [rbp-20h] BYREF
  unsigned __int8 inByteArray; // [rsp+250h] [rbp+150h] BYREF
  unsigned int disconnectReason; // [rsp+268h] [rbp+168h] BYREF

  v6 = 0; /*0x1410cc109*/
  result = 0; /*0x1410cc10c*/
  v8 = 0; /*0x1410cc10e*/
  if ( this->maximumNumberOfPeers != 0 )
  {
    v9 = 0; /*0x1410cc11b*/
    do
    {
      if ( this->remoteSystemList[v9].isActive._Storage._Value )
      {
        v6 = 1; /*0x1410cc134*/
        input = this->remoteSystemList[v9].systemAddress; /*0x1410cc143*/
        RakNet::BitStream::BitStream(this: &v20, initialBytesToAllocate: 1u); /*0x1410cc15a*/
        __wind
        {
          if ( FLog::Network != 0 )
            FLog::FastLogFormatted(
              level: FLog::Network,
              message: "[FLog::Network] Sending disconnect with reason: %d",
              this->disconnectReason);
          inByteArray = 21; /*0x1410cc180*/
          RakNet::BitStream::WriteBits(this: &v20, &inByteArray, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410cc19b*/
          disconnectReason = this->disconnectReason; /*0x1410cc1a6*/
          if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410cc1ac*/
          {
            p_disconnectReason = (unsigned __int8 *)&disconnectReason; /*0x1410cc1d3*/
          }
          else
          {
            RBX::Network::NetworkStream::ReverseBytes( /*0x1410cc1c7*/
              inByteArray: (unsigned __int8 *)&disconnectReason,
              inOutByteArray,
              length: 4u);
            p_disconnectReason = inOutByteArray; /*0x1410cc1cc*/
          }
          RakNet::BitStream::WriteBits( /*0x1410cc1e7*/
            this: &v20,
            inByteArray: p_disconnectReason,
            numberOfBitsToWrite: 0x20u,
            rightAlignedBits: true);
          TimeUS = RakNet::GetTimeUS(isNetworkSynced: false); /*0x1410cc1f3*/
          RakNet::RakNetGUID::RakNetGUID(this: &v18); /*0x1410cc1fa*/
          RakNet::SystemAddress::SystemAddress(this: &v19); /*0x1410cc203*/
          v18 = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410cc20f*/
          RakNet::SystemAddress::operator=(this: &v19, &input); /*0x1410cc227*/
          RakNet::RakPeer::SendImmediate( /*0x1410cc26c*/
            this,
            data: (char *)v20.data,
            numberOfBitsToSend: v20.numberOfBitsUsed,
            priority: disconnectionNotificationPriority,
            reliability: RELIABLE_ORDERED,
            orderingChannel,
            systemIdentifier: (RBX::json::ArrayIterator *)&v18,
            broadcast: false,
            useCallerDataAllocation: false,
            currentTime: TimeUS,
            receipt: 0,
            isJoinData: false);
          sa = input; /*0x1410cc276*/
          if ( RakNet::SystemAddress::operator==(this: &sa, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) == 0 ) /*0x1410cc294*/
          {
            v12 = this->remoteSystemLookup[RakNet::SystemAddress::ToInteger(&sa) /*0x1410cc2b5*/
                                         % (8 * (unsigned int)this->maximumNumberOfPeers)];
            if ( v12 != nullptr ) /*0x1410cc2bc*/
            {
              while ( RakNet::SystemAddress::operator==( /*0x1410cc2e2*/
                        this: &this->remoteSystemList[v12->index].systemAddress,
                        right: &sa) == 0 )
              {
                v12 = v12->next; /*0x1410cc2e4*/
                if ( v12 == nullptr ) /*0x1410cc2eb*/
                  goto LABEL_22; /*0x1410cc2eb*/
              }
              index = v12->index; /*0x1410cc2ef*/
              if ( (_DWORD)index != -1 && this->remoteSystemList[index].isActive._Storage._Value ) /*0x1410cc304*/
              {
                v14 = &this->remoteSystemList[index]; /*0x1410cc315*/
                if ( v14 != nullptr ) /*0x1410cc318*/
                  v14->connectMode = DISCONNECT_ASAP; /*0x1410cc31a*/
              }
            }
          }
        }
        __unwind
        {
          RakNet::BitStream::~BitStream(this: &v20); /*0xf1c0000000000008*/
        }
LABEL_22:
        RakNet::BitStream::~BitStream(this: &v20); /*0x1410cc328*/
      }
      ++v8; /*0x1410cc32d*/
      ++v9; /*0x1410cc330*/
    }
    while ( v8 < this->maximumNumberOfPeers );
    return v6; /*0x1410cc344*/
  }
  return result; /*0x1410cc348*/
}

// Address: 0x1410cc390 | Name: ?overrideCapabilities@RakPeer@RakNet@@UEAAX_K@Z
void __fastcall RakNet::RakPeer::overrideCapabilities(RakNet::RakPeer *this, unsigned __int64 capabilities)
{
  this->overridingCapabilities = capabilities; /*0x1410cc390*/
}

// Address: 0x1410cc3a0 | Name: ?parseAvoidedPacketSizes@RakPeer@RakNet@@AEAA_NXZ
bool __fastcall RakNet::RakPeer::parseAvoidedPacketSizes(RakNet::RakPeer *this)
{
  std::string *p_avoidedPacketSizesString; // rbx
  std::string *Ptr; // rdx
  unsigned __int64 Mysize; // rdi
  std::string *v5; // rsi
  unsigned __int64 Myres; // r14
  std::string *v7; // rcx
  char *v8; // r15
  int v9; // eax
  std::string *v10; // rdx
  std::string *p_decodedAvoidedPackets; // rax
  std::vector<int> *p_avoidedPacketSizes; // rdi
  RBX::StringView *Myfirst; // rdx
  unsigned __int64 v14; // rbx
  int *Mylast; // rsi
  int *v16; // r8
  unsigned __int64 v17; // rcx
  int *v18; // rax
  size_t v19; // rbx
  int v20; // esi
  __int64 v21; // rax
  __int64 v22; // rbx
  int *v23; // r14
  char *Length; // rcx
  char *v25; // rcx
  RBX::StringView avoidedString; // [rsp+30h] [rbp-50h] BYREF
  std::vector<RBX::StringView> sVector; // [rsp+40h] [rbp-40h] BYREF
  std::string decodedAvoidedPackets; // [rsp+58h] [rbp-28h] BYREF
  __int64 _Val; // [rsp+B0h] [rbp+30h] BYREF

  p_avoidedPacketSizesString = &this->avoidedPacketSizesString; /*0x1410cc3c5*/
  Ptr = &this->avoidedPacketSizesString; /*0x1410cc3cc*/
  if ( this->avoidedPacketSizesString._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cc3d4*/
    Ptr = (std::string *)p_avoidedPacketSizesString->_Mypair._Myval2._Bx._Ptr; /*0x1410cc3d6*/
  Mysize = DFString::CLI50798S._Mypair._Myval2._Mysize; /*0x1410cc3d9*/
  v5 = &DFString::CLI50798S; /*0x1410cc3e0*/
  Myres = DFString::CLI50798S._Mypair._Myval2._Myres; /*0x1410cc3e7*/
  v7 = &DFString::CLI50798S; /*0x1410cc3ee*/
  v8 = DFString::CLI50798S._Mypair._Myval2._Bx._Ptr; /*0x1410cc3f1*/
  if ( DFString::CLI50798S._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cc3fc*/
    v7 = (std::string *)DFString::CLI50798S._Mypair._Myval2._Bx._Ptr; /*0x1410cc3fc*/
  if ( DFString::CLI50798S._Mypair._Myval2._Mysize != p_avoidedPacketSizesString->_Mypair._Myval2._Mysize /*0x1410cc410*/
    || (v9 = memcmp_0(Buf1: v7, Buf2: Ptr, Size: DFString::CLI50798S._Mypair._Myval2._Mysize)) != 0 )
  {
    if ( p_avoidedPacketSizesString != &DFString::CLI50798S ) /*0x1410cc419*/
    {
      v10 = &DFString::CLI50798S; /*0x1410cc41b*/
      if ( Myres >= 0x10 ) /*0x1410cc422*/
        v10 = (std::string *)v8; /*0x1410cc422*/
      std::string::assign(this: p_avoidedPacketSizesString, _Ptr: v10->_Mypair._Myval2._Bx._Buf, _Count: Mysize); /*0x1410cc42c*/
      Myres = DFString::CLI50798S._Mypair._Myval2._Myres; /*0x1410cc431*/
      Mysize = DFString::CLI50798S._Mypair._Myval2._Mysize; /*0x1410cc438*/
      v8 = DFString::CLI50798S._Mypair._Myval2._Bx._Ptr; /*0x1410cc43f*/
    }
    decodedAvoidedPackets._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410cc449*/
    decodedAvoidedPackets._Mypair._Myval2._Mysize = 0; /*0x1410cc44d*/
    decodedAvoidedPackets._Mypair._Myval2._Myres = 15; /*0x1410cc451*/
    if ( Myres >= 0x10 ) /*0x1410cc461*/
      v5 = (std::string *)v8; /*0x1410cc461*/
    __wind /*0xf1c0000000000028*/
    {
      base64<unsigned char,std::char_traits<unsigned char>>::decode( /*0x1410cc46f*/
        input: v5->_Mypair._Myval2._Bx._Buf,
        length: Mysize,
        output: &decodedAvoidedPackets);
      p_decodedAvoidedPackets = &decodedAvoidedPackets; /*0x1410cc474*/
      if ( decodedAvoidedPackets._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cc47d*/
        p_decodedAvoidedPackets = (std::string *)decodedAvoidedPackets._Mypair._Myval2._Bx._Ptr; /*0x1410cc47d*/
      avoidedString.Data = (const char *)p_decodedAvoidedPackets; /*0x1410cc482*/
      avoidedString.Length = decodedAvoidedPackets._Mypair._Myval2._Mysize; /*0x1410cc48a*/
      memset(&sVector, 0, sizeof(sVector)); /*0x1410cc491*/
      __wind /*0xf1c000000000001c*/
      {
        RBX::detail::StringViewBase::split( /*0x1410cc4af*/
          this: &avoidedString,
          A: &sVector,
          Separator: 44,
          MaxSplit: -1,
          KeepEmpty: true);
        p_avoidedPacketSizes = &this->avoidedPacketSizes; /*0x1410cc4b4*/
        Myfirst = sVector._Mypair._Myval2._Myfirst; /*0x1410cc4bf*/
        v14 = sVector._Mypair._Myval2._Mylast - sVector._Mypair._Myval2._Myfirst; /*0x1410cc4c6*/
        Mylast = this->avoidedPacketSizes._Mypair._Myval2._Mylast; /*0x1410cc4ca*/
        v16 = this->avoidedPacketSizes._Mypair._Myval2._Myfirst; /*0x1410cc4ce*/
        v17 = Mylast - v16; /*0x1410cc4d7*/
        if ( v14 < v17 ) /*0x1410cc4de*/
        {
          v18 = &v16[v14]; /*0x1410cc4e0*/
LABEL_22:
          this->avoidedPacketSizes._Mypair._Myval2._Mylast = v18; /*0x1410cc52d*/
          goto LABEL_23; /*0x1410cc52d*/
        }
        if ( v14 > v17 ) /*0x1410cc4e6*/
        {
          if ( v14 <= this->avoidedPacketSizes._Mypair._Myval2._Myend - v16 ) /*0x1410cc4f6*/
          {
            v19 = v14 - v17; /*0x1410cc510*/
            memset_0(a1: this->avoidedPacketSizes._Mypair._Myval2._Mylast, Val: 0, Size: v19 * 4); /*0x1410cc520*/
            v18 = &Mylast[v19]; /*0x1410cc525*/
            Myfirst = sVector._Mypair._Myval2._Myfirst; /*0x1410cc529*/
            goto LABEL_22; /*0x1410cc529*/
          }
          std::vector<enum RBX::CSG3Bsp::fid_t>::_Resize_reallocate<std::_Value_init_tag>( /*0x1410cc502*/
            this: (std::vector<enum RBX::CSG3Mesh::faceref_t> *)p_avoidedPacketSizes,
            _Newsize: sVector._Mypair._Myval2._Mylast - sVector._Mypair._Myval2._Myfirst,
            (const std::_Value_init_tag *)&_Val);
          Myfirst = sVector._Mypair._Myval2._Myfirst; /*0x1410cc507*/
        }
LABEL_23:
        v20 = 0; /*0x1410cc531*/
        if ( sVector._Mypair._Myval2._Mylast - Myfirst != 0 ) /*0x1410cc542*/
        {
          v21 = 0; /*0x1410cc544*/
          v22 = 0; /*0x1410cc547*/
          do /*0x1410cc5a6*/
          {
            v23 = p_avoidedPacketSizes->_Mypair._Myval2._Myfirst; /*0x1410cc557*/
            if ( RBX::consumeSignedInteger(Str: &Myfirst[v21], Radix: 0xAu, Result: &_Val) && (int)_Val == _Val ) /*0x1410cc576*/
              v23[v22] = _Val; /*0x1410cc578*/
            p_avoidedPacketSizes->_Mypair._Myval2._Myfirst[v22] -= DFInt::CLI50798I; /*0x1410cc588*/
            ++v20; /*0x1410cc58b*/
            ++v22; /*0x1410cc58d*/
            Myfirst = sVector._Mypair._Myval2._Myfirst; /*0x1410cc595*/
            v21 = v20; /*0x1410cc5a0*/
          }
          while ( v20 < (unsigned __int64)(sVector._Mypair._Myval2._Mylast - sVector._Mypair._Myval2._Myfirst) ); /*0x1410cc5a6*/
        }
        std::_Sort_unchecked<int *,std::less<void>>( /*0x1410cc5bf*/
          _First: (RBX::CSG3Mesh::planeref_t *)p_avoidedPacketSizes->_Mypair._Myval2._Myfirst,
          _Last: (RBX::CSG3Mesh::planeref_t *)this->avoidedPacketSizes._Mypair._Myval2._Mylast,
          _Ideal: this->avoidedPacketSizes._Mypair._Myval2._Mylast - p_avoidedPacketSizes->_Mypair._Myval2._Myfirst,
          _Pred: 0);
      }
      __unwind
      {
        std::vector<Luau::Location>::~vector<Luau::Location>(this: (RBX::DenseHashMap<RBX::Graphics::ShaderProgram *,VkPipeline_T *,boost::hash<RBX::Graphics::ShaderProgram *>,std::equal_to<RBX::Graphics::ShaderProgram *> > *)&sVector); /*0xf1c0000000000014*/
      }
      Length = (char *)sVector._Mypair._Myval2._Myfirst; /*0x1410cc5c5*/
      if ( sVector._Mypair._Myval2._Myfirst != nullptr ) /*0x1410cc5cc*/
      {
        if ( (((char *)sVector._Mypair._Myval2._Myend - (char *)sVector._Mypair._Myval2._Myfirst) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x1410cc5e3*/
        {
          Length = (char *)sVector._Mypair._Myval2._Myfirst[-1].Length; /*0x1410cc5e9*/
          if ( (unsigned __int64)((char *)sVector._Mypair._Myval2._Myfirst - Length - 8) > 0x1F ) /*0x1410cc5f8*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410cc5fa*/
        }
        operator delete(ptr: Length); /*0x1410cc601*/
        memset(&sVector, 0, sizeof(sVector)); /*0x1410cc609*/
      }
      if ( decodedAvoidedPackets._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cc61a*/
      {
        v25 = decodedAvoidedPackets._Mypair._Myval2._Bx._Ptr; /*0x1410cc61f*/
        if ( decodedAvoidedPackets._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cc62d*/
        {
          v25 = *((char **)decodedAvoidedPackets._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cc633*/
          if ( (unsigned __int64)(decodedAvoidedPackets._Mypair._Myval2._Bx._Ptr - v25 - 8) > 0x1F ) /*0x1410cc642*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410cc644*/
        }
        operator delete(ptr: v25); /*0x1410cc64b*/
      }
      LOBYTE(v9) = 1; /*0x1410cc650*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&decodedAvoidedPackets); /*0xf1c0000000000008*/
    }
  }
  return v9; /*0x1410cc652*/
}

// Address: 0x1410cc680 | Name: ?processRbxOpenReply1@RakPeer@RakNet@@IEAA_NPEBE_KAEBUSystemAddress@2@AEAV?$shared_ptr@URakNetSocket@RakNet@@@std@@@Z
bool __fastcall RakNet::RakPeer::processRbxOpenReply1(
        RakNet::RakPeer *this,
        unsigned __int8 *data,
        unsigned __int64 length,
        const RakNet::SystemAddress *systemAddress,
        std::shared_ptr<RakNet::RakNetSocket> *rakNetSocket)
{
  RBX::Network::Peer *peerPlugin; // rcx
  unsigned __int16 v11; // cx
  RakNet::RakPeer::RequestedConnectionStruct *RequestedConnectionStruct; // rbx
  bool v13; // bl
  RakNet::RakNetGUID serverGuid; // [rsp+30h] [rbp-158h] BYREF
  RakNet::BitStream bsIn; // [rsp+40h] [rbp-148h] BYREF
  unsigned __int16 mtu; // [rsp+190h] [rbp+8h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+1A0h] [rbp+18h] BYREF

  rtc::CriticalSection::Enter(lpCriticalSection: &this->connectionRequestsStats.mx.criticalSection); /*0x1410cc6a8*/
  ++this->connectionRequestsStats.counters[3]; /*0x1410cc6ad*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->connectionRequestsStats.mx.criticalSection); /*0x1410cc6ba*/
  if ( length == 28 )
  {
    peerPlugin = this->peerPlugin; /*0x1410cc6e8*/
    if ( peerPlugin != nullptr ) /*0x1410cc6f2*/
      peerPlugin->OnReceiveOpenConnectionReply1(this: peerPlugin); /*0x1410cc6f7*/
    RakNet::BitStream::BitStream(this: &bsIn, _data: data, lengthInBytes: 0x1Cu, _copyData: false); /*0x1410cc70c*/
    __wind
    {
      RakNet::BitStream::IgnoreBytes(this: &bsIn, numberOfBytes: 1u); /*0x1410cc71c*/
      RakNet::BitStream::IgnoreBytes(this: &bsIn, numberOfBytes: 0x10u); /*0x1410cc72b*/
      RakNet::RakNetGUID::RakNetGUID(this: &serverGuid); /*0x1410cc735*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410cc73a*/
      {
        RakNet::BitStream::ReadBits( /*0x1410cc781*/
          this: &bsIn,
          inOutByteArray: (unsigned __int8 *)&serverGuid,
          numberOfBitsToRead: 0x40u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits( /*0x1410cc760*/
                  this: &bsIn,
                  &inOutByteArray,
                  numberOfBitsToRead: 0x40u,
                  alignBitsToRight: true) != 0 )
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410cc775*/
          inByteArray: &inOutByteArray,
          inOutByteArray: (unsigned __int8 *)&serverGuid,
          length: 8u);
      }
      RakNet::BitStream::IgnoreBytes(this: &bsIn, numberOfBytes: 1u); /*0x1410cc790*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410cc795*/
      {
        RakNet::BitStream::ReadBits( /*0x1410cc7e2*/
          this: &bsIn,
          inOutByteArray: (unsigned __int8 *)&mtu,
          numberOfBitsToRead: 0x10u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits( /*0x1410cc7bb*/
                  this: &bsIn,
                  &inOutByteArray,
                  numberOfBitsToRead: 0x10u,
                  alignBitsToRight: true) != 0 )
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410cc7d3*/
          inByteArray: &inOutByteArray,
          inOutByteArray: (unsigned __int8 *)&mtu,
          length: 2u);
      }
      v11 = mtu; /*0x1410cc7ed*/
      if ( DFInt::ConnectionMTUSize > 0 ) /*0x1410cc7f7*/
        v11 = DFInt::ConnectionMTUSize; /*0x1410cc7f7*/
      mtu = v11; /*0x1410cc7fb*/
      RequestedConnectionStruct = RakNet::RakPeer::findRequestedConnectionStruct(this, systemAddress); /*0x1410cc80e*/
      if ( RequestedConnectionStruct != nullptr )
      {
        if ( DFLog::RakNetConnectTrace != 0 )
          FLog::FastLog(
            level: DFLog::RakNetConnectTrace,
            message: "[DFLog::RakNetConnectTrace] RakNet: OpenReply1 received will send OpenRequest2 with mtu size %d",
            arg0: (const void *)mtu);
        v13 = RakNet::RakPeer::sendRbxOpenRequest2( /*0x1410cc859*/
                this,
                mtu,
                rcs: RequestedConnectionStruct,
                systemAddress,
                rakNetSocket);
      }
      else
      {
        if ( DFLog::RakNetConnectTrace != 0 )
          FLog::FastLog(
            level: DFLog::RakNetConnectTrace,
            message: "[DFLog::RakNetConnectTrace] RakNet: OpenReply1 received but cannot find related RCS",
            arg0: nullptr);
        v13 = false; /*0x1410cc871*/
      }
    }
    __unwind
    {
      RakNet::BitStream::~BitStream(this: &bsIn); /*0xf1c0000000000008*/
    }
    RakNet::BitStream::~BitStream(this: &bsIn); /*0x1410cc878*/
    return v13; /*0x1410cc87d*/
  }
  else
  {
    if ( DFLog::SessionCrypto != 0 ) /*0x1410cc6ce*/
      FLog::FastLogFormatted( /*0x1410cc6dc*/
        level: DFLog::SessionCrypto,
        message: "[DFLog::SessionCrypto] RbxOpenReply1 has invalid size %d.",
        length);
    return false; /*0x1410cc6e1*/
  }
}

// Address: 0x1410cc8a0 | Name: ?processRbxOpenReply2@RakPeer@RakNet@@IEAA_NPEBE_KAEBUSystemAddress@2@AEAV?$shared_ptr@URakNetSocket@RakNet@@@std@@1@Z
char __fastcall RakNet::RakPeer::processRbxOpenReply2(
        RakNet::RakPeer *this,
        unsigned __int8 *data,
        unsigned __int64 length,
        const RakNet::SystemAddress *systemAddress,
        std::shared_ptr<RakNet::RakNetSocket> *rakNetSocket,
        unsigned __int64 timeRead)
{
  RakNet::RakPeer::RequestedConnectionStruct *RequestedConnectionStruct; // rax
  RakNet::RakPeer::RequestedConnectionStruct *v12; // r15
  RBX::Network::Peer *peerPlugin; // rcx
  unsigned __int64 v14; // r13
  unsigned __int64 v15; // rbx
  RBX::Network::Rupp::Rupp *Ptr; // rax
  const char *v17; // r8
  std::_Ref_count_base *Rep; // rsi
  unsigned __int64 v19; // rax
  unsigned __int8 v20; // r10
  unsigned int v21; // esi
  unsigned int RemoteSystemIndex; // eax
  __int64 v23; // rdx
  RakNet::RakPeer::RemoteSystemStruct *v24; // r14
  std::shared_ptr<RakNet::RakNetSocket> *p_socket; // rdx
  std::_Ref_count_base *v26; // rcx
  RakNet::RakNetGUID v27; // xmm1
  int v28; // r8d
  __int128 v29; // xmm2
  __int128 v30; // xmm3
  std::_Ref_count_base *v31; // rcx
  char *v32; // rcx
  unsigned int timeoutTime; // edx
  DataStructures::MemoryPool<RakNet::Packet>::MemoryWithPage *v34; // rbx
  RBX::Network::Peer *v35; // rcx
  unsigned int head; // r8d
  unsigned int tail; // ecx
  unsigned int v38; // ecx
  unsigned int v39; // edx
  unsigned int v40; // r8d
  char v41; // bl
  RakNet::RakPeer_vtbl *v42; // rax
  const RakNet::RakNetGUID *v43; // rax
  unsigned __int8 aadLen; // [rsp+60h] [rbp-A0h] BYREF
  unsigned __int8 v45; // [rsp+61h] [rbp-9Fh] BYREF
  unsigned __int8 version[2]; // [rsp+62h] [rbp-9Eh] BYREF
  unsigned __int16 mtu; // [rsp+64h] [rbp-9Ch] BYREF
  unsigned __int8 tokenLen[4]; // [rsp+68h] [rbp-98h] BYREF
  unsigned __int8 inOutByteArray[4]; // [rsp+6Ch] [rbp-94h] BYREF
  unsigned __int16 ciphertextLen[2]; // [rsp+70h] [rbp-90h] BYREF
  unsigned __int8 v51[4]; // [rsp+74h] [rbp-8Ch] BYREF
  unsigned __int8 v52[8]; // [rsp+78h] [rbp-88h] BYREF
  RakNet::RakNetGUID guid; // [rsp+80h] [rbp-80h] BYREF
  std::shared_ptr<RBX::File> v54; // [rsp+90h] [rbp-70h] BYREF
  std::shared_ptr<RBX::File> v55; // [rsp+A0h] [rbp-60h] BYREF
  unsigned __int8 inByteArray[16]; // [rsp+B0h] [rbp-50h] BYREF
  std::shared_ptr<RBX::Network::Rupp::Rupp> rupp; // [rsp+C0h] [rbp-40h] BYREF
  RakNet::SystemAddress bindingAddress; // [rsp+D0h] [rbp-30h] BYREF
  std::string _Right; // [rsp+F0h] [rbp-10h] BYREF
  __int128 v60; // [rsp+110h] [rbp+10h]
  RBX::ArrayView<unsigned char> v61; // [rsp+120h] [rbp+20h]
  RBX::StringView v62; // [rsp+130h] [rbp+30h]
  RakNet::SystemAddress v63; // [rsp+140h] [rbp+40h] BYREF
  unsigned __int8 token[16]; // [rsp+160h] [rbp+60h] BYREF
  RBX::ArrayView<unsigned char> v65; // [rsp+170h] [rbp+70h] BYREF
  RBX::StringView v66; // [rsp+180h] [rbp+80h] BYREF
  RakNet::RakNetGUID v67; // [rsp+190h] [rbp+90h] BYREF
  RakNet::SystemAddress sa; // [rsp+1A0h] [rbp+A0h] BYREF
  RakNet::SystemAddress v69; // [rsp+1C0h] [rbp+C0h] BYREF
  RakNet::SystemAddress v70; // [rsp+1E0h] [rbp+E0h] BYREF
  std::array<unsigned char,32> peerKey; // [rsp+200h] [rbp+100h] BYREF
  RakNet::BitStream postBitStream; // [rsp+220h] [rbp+120h] BYREF
  RakNet::BitStream preBitStream; // [rsp+350h] [rbp+250h] BYREF
  char addressBuffer[1088]; // [rsp+480h] [rbp+380h] BYREF
  unsigned __int8 selectedEncryption; // [rsp+8D0h] [rbp+7D0h] BYREF
  bool thisIPConnectedRecently; // [rsp+8E0h] [rbp+7E0h] BYREF

  rtc::CriticalSection::Enter(lpCriticalSection: &this->connectionRequestsStats.mx.criticalSection); /*0x1410cc8d2*/
  ++this->connectionRequestsStats.counters[7]; /*0x1410cc8d7*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->connectionRequestsStats.mx.criticalSection); /*0x1410cc8e4*/
  if ( DFLog::RakNetConnectTrace != 0 )
    FLog::FastLog(
      level: DFLog::RakNetConnectTrace,
      message: "[DFLog::RakNetConnectTrace] RakNet: OpenReply2 received",
      arg0: nullptr);
  if ( length < 0x6B ) /*0x1410cc907*/
  {
    if ( DFLog::SessionCrypto != 0 ) /*0x1410cc912*/
      FLog::FastLogFormatted( /*0x1410cc920*/
        level: DFLog::SessionCrypto,
        message: "[DFLog::SessionCrypto] RbxOpenReply2 invalid size %d.",
        length);
    return 0; /*0x1410cc927*/
  }
  RequestedConnectionStruct = RakNet::RakPeer::findRequestedConnectionStruct(this, systemAddress); /*0x1410cc932*/
  v12 = RequestedConnectionStruct; /*0x1410cc937*/
  if ( RequestedConnectionStruct == nullptr ) /*0x1410cc93d*/
  {
    if ( DFLog::SessionCrypto != 0 ) /*0x1410cc948*/
    {
      FLog::FastLog( /*0x1410cc954*/
        level: DFLog::SessionCrypto,
        message: "[DFLog::SessionCrypto] RbxOpenReply2 unexptected reply",
        arg0: nullptr);
      return 1; /*0x1410cc95b*/
    }
    return 1; /*0x1410cc948*/
  }
  if ( RequestedConnectionStruct->rbxSessionCrypto._Ptr == nullptr ) /*0x1410cc968*/
  {
    if ( DFLog::SessionCrypto != 0 ) /*0x1410cc973*/
      FLog::FastLog( /*0x1410cc97f*/
        level: DFLog::SessionCrypto,
        message: "[DFLog::SessionCrypto] RbxOpenReply2 no session crypto",
        arg0: nullptr);
    return 1; /*0x1410cc986*/
  }
  RakNet::BitStream::BitStream(this: &preBitStream, _data: data, lengthInBytes: length, _copyData: false); /*0x1410cc99b*/
  __wind /*0xf1c0000000000040*/
  {
    RakNet::BitStream::IgnoreBytes(this: &preBitStream, numberOfBytes: 0x11u); /*0x1410cc9ad*/
    RakNet::BitStream::ReadBits( /*0x1410cc9c7*/
      this: &preBitStream,
      inOutByteArray: version,
      numberOfBitsToRead: 8u,
      alignBitsToRight: true);
    RakNet::BitStream::ReadBits( /*0x1410cc9e1*/
      this: &preBitStream,
      inOutByteArray: &aadLen,
      numberOfBitsToRead: 8u,
      alignBitsToRight: true);
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410cc9e6*/
    {
      RakNet::BitStream::ReadBits( /*0x1410cca29*/
        this: &preBitStream,
        inOutByteArray: (unsigned __int8 *)ciphertextLen,
        numberOfBitsToRead: 0x10u,
        alignBitsToRight: true);
    }
    else if ( RakNet::BitStream::ReadBits( /*0x1410cca0e*/
                this: &preBitStream,
                inOutByteArray,
                numberOfBitsToRead: 0x10u,
                alignBitsToRight: true) != 0 )
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410cca1d*/
        inByteArray: inOutByteArray,
        inOutByteArray: (unsigned __int8 *)ciphertextLen,
        length: 2u);
    }
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &preBitStream); /*0xf1c0000000000038*/
  }
  RakNet::BitStream::~BitStream(this: &preBitStream); /*0x1410cca36*/
  RakNet::BitStream::BitStream(this: &postBitStream, _data: data, lengthInBytes: length, _copyData: false); /*0x1410cca4b*/
  __wind
  {
    if ( RBX::Security::RakPeerCrypto::earlyDecryptData(
           this: v12->rbxSessionCrypto._Ptr,
           bitstream: &postBitStream,
           aadSize: aadLen) )
    {
      peerPlugin = this->peerPlugin; /*0x1410cca91*/
      if ( peerPlugin != nullptr ) /*0x1410cca9b*/
        peerPlugin->OnReceiveOpenConnectionReply2(this: peerPlugin); /*0x1410ccaa0*/
      RakNet::BitStream::IgnoreBytes(this: &postBitStream, numberOfBytes: 0x15u); /*0x1410ccab2*/
      RakNet::BitStream::ReadAlignedBytes( /*0x1410ccacb*/
        this: &postBitStream,
        inOutByteArray: peerKey._Elems,
        numberOfBytesToRead: 0x20u);
      v14 = readCapabilitiesIfAny(bs: &postBitStream); /*0x1410ccadc*/
      RakNet::RakNetGUID::RakNetGUID(this: &guid); /*0x1410ccae3*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410ccae8*/
      {
        RakNet::BitStream::ReadBits( /*0x1410ccb27*/
          this: &postBitStream,
          inOutByteArray: (unsigned __int8 *)&guid,
          numberOfBitsToRead: 0x40u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits( /*0x1410ccb0c*/
                  this: &postBitStream,
                  inOutByteArray: inByteArray,
                  numberOfBitsToRead: 0x40u,
                  alignBitsToRight: true) != 0 )
      {
        RBX::Network::NetworkStream::ReverseBytes(inByteArray, inOutByteArray: (unsigned __int8 *)&guid, length: 8u); /*0x1410ccb1c*/
      }
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410ccb2c*/
      {
        RakNet::BitStream::ReadBits( /*0x1410ccb6c*/
          this: &postBitStream,
          inOutByteArray: (unsigned __int8 *)&mtu,
          numberOfBitsToRead: 0x10u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits( /*0x1410ccb51*/
                  this: &postBitStream,
                  inOutByteArray: v51,
                  numberOfBitsToRead: 0x10u,
                  alignBitsToRight: true) != 0 )
      {
        RBX::Network::NetworkStream::ReverseBytes(inByteArray: v51, inOutByteArray: (unsigned __int8 *)&mtu, length: 2u); /*0x1410ccb60*/
      }
      RakNet::BitStream::ReadBits( /*0x1410ccb88*/
        this: &postBitStream,
        inOutByteArray: &selectedEncryption,
        numberOfBitsToRead: 8u,
        alignBitsToRight: true);
      RakNet::SystemAddress::SystemAddress(this: &bindingAddress); /*0x1410ccb91*/
      RakNet::BitStream::ReadBits( /*0x1410ccbab*/
        this: &postBitStream,
        inOutByteArray: &v45,
        numberOfBitsToRead: 8u,
        alignBitsToRight: true);
      if ( v45 == 4 ) /*0x1410ccbb5*/
      {
        bindingAddress.address.addr6.sin6_family = 2; /*0x1410ccbb7*/
        RakNet::BitStream::ReadBits( /*0x1410ccbd0*/
          this: &postBitStream,
          inOutByteArray: v52,
          numberOfBitsToRead: 0x20u,
          alignBitsToRight: true);
        bindingAddress.address.addr6.sin6_flowinfo = ~*(_DWORD *)v52; /*0x1410ccbdb*/
        RakNet::BitStream::ReadBits( /*0x1410ccbf2*/
          this: &postBitStream,
          inOutByteArray: (unsigned __int8 *)&bindingAddress.address.addr4.sin_port,
          numberOfBitsToRead: 0x10u,
          alignBitsToRight: true);
        bindingAddress.debugPort = ntohs(netshort: bindingAddress.address.addr6.sin6_port); /*0x1410ccc01*/
      }
      v15 = -1; /*0x1410ccc05*/
      if ( FFlag::RuppTokEn4.value ) /*0x1410ccc13*/
      {
        if ( version[0] != 0 ) /*0x1410ccc1e*/
        {
          RakNet::BitStream::ReadBits( /*0x1410ccc37*/
            this: &postBitStream,
            inOutByteArray: tokenLen,
            numberOfBitsToRead: 8u,
            alignBitsToRight: true);
          RakNet::BitStream::ReadAlignedBytes(this: &postBitStream, inOutByteArray: token, numberOfBytesToRead: 0x10u); /*0x1410ccc4b*/
          this->getRuppHeader(this, result: &rupp); /*0x1410ccc5a*/
          __wind /*0xf1c000000000001c*/
          {
            Ptr = rupp._Ptr; /*0x1410ccc61*/
            if ( rupp._Ptr != nullptr ) /*0x1410ccc68*/
            {
              *(_QWORD *)&v60 = token; /*0x1410ccc6e*/
              *((_QWORD *)&v60 + 1) = 16; /*0x1410ccc72*/
              *(_OWORD *)&v63.address.addr6.sin6_family = v60; /*0x1410ccc7e*/
              RBX::Network::Rupp::Rupp::updateTokenTlv( /*0x1410ccc8c*/
                this: rupp._Ptr,
                setType: Rcc,
                setTokenValue: (RBX::StringView *)&v63);
              Ptr = rupp._Ptr; /*0x1410ccc91*/
            }
            if ( DFLog::RuppTokenLog != 0 ) /*0x1410ccc9e*/
            {
              v17 = "unprocessed."; /*0x1410ccca7*/
              if ( Ptr != nullptr ) /*0x1410cccb1*/
                v17 = "ok."; /*0x1410cccb1*/
              FLog::FastLog( /*0x1410cccbc*/
                level: DFLog::RuppTokenLog,
                message: "[DFLog::RuppTokenLog] RbxOpenReply2 token received %s",
                arg0: v17);
            }
          }
          __unwind
          {
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&rupp); /*0xf1c0000000000014*/
          }
          Rep = rupp._Rep; /*0x1410cccc2*/
          if ( rupp._Rep != nullptr /*0x1410cccd5*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&rupp._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            Rep->_Destroy(this: Rep); /*0x1410cccdd*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410ccce9*/
              Rep->_Delete_this(this: Rep); /*0x1410cccf1*/
          }
        }
        else if ( DFLog::RuppTokenLog != 0 ) /*0x1410cccff*/
        {
          FLog::FastLog( /*0x1410ccd0b*/
            level: DFLog::RuppTokenLog,
            message: "[DFLog::RuppTokenLog] RbxOpenReply2 token not received.",
            arg0: nullptr);
        }
      }
      if ( DFLog::NetworkTrace != 0 )
      {
        v19 = buildRakPeerCapabilities(peer: this); /*0x1410ccd20*/
        FLog::FastLogFormatted(
          level: v20,
          message: "[DFLog::NetworkTrace] Peer has capabilities: 0x%llx ,common capabilities: 0x%llx",
          v19,
          v14);
      }
      v61.buffer = (const unsigned __int8 *)&peerKey; /*0x1410ccd41*/
      v61.length = 32; /*0x1410ccd45*/
      v65 = v61; /*0x1410ccd51*/
      RBX::Security::RakPeerCrypto::clientInitEphemeralSessionKeys( /*0x1410ccd61*/
        this: v12->rbxSessionCrypto._Ptr,
        peerPublicKey: &v65);
      if ( !RBX::Security::SessionCrypto::isTestOnly(format: (RBX::Security::SessionCrypto::CryptoFormat)selectedEncryption)
        && selectedEncryption != 0 )
      {
        RBX::Security::SessionCrypto::setRakCryptoFormat( /*0x1410ccd90*/
          this: v12->rbxSessionCrypto._Ptr,
          value: (RBX::Security::SessionCrypto::CryptoFormat)selectedEncryption);
        thisIPConnectedRecently = false; /*0x1410ccd95*/
        sa = *systemAddress; /*0x1410ccda1*/
        v21 = 0; /*0x1410ccdc8*/
        if ( RakNet::SystemAddress::operator==(this: &sa, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 /*0x1410cce06*/
          || (RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, &sa)) == -1
          || !*(&this->remoteSystemList->isActive._Storage._Value + (v23 = RemoteSystemIndex))
          || (v24 = &this->remoteSystemList[v23]) == nullptr )
        {
          p_socket = &v12->socket; /*0x1410cce0c*/
          if ( v12->socket._Ptr == nullptr ) /*0x1410cce16*/
            p_socket = rakNetSocket; /*0x1410cce16*/
          v62 = (RBX::StringView)0LL; /*0x1410cce1e*/
          v54 = 0; /*0x1410cce29*/
          v26 = v12->rbxSessionCrypto._Rep; /*0x1410cce2e*/
          if ( v26 != nullptr ) /*0x1410cce38*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&v26->_Uses); /*0x1410cce3a*/
            v26 = v12->rbxSessionCrypto._Rep; /*0x1410cce3e*/
          }
          v54._Ptr = (RBX::File *)v12->rbxSessionCrypto._Ptr; /*0x1410cce4c*/
          v54._Rep = v26; /*0x1410cce50*/
          v27 = guid; /*0x1410cce54*/
          v28 = mtu; /*0x1410cce58*/
          v29 = *(_OWORD *)&bindingAddress.address.addr6.sin6_family; /*0x1410cce5e*/
          v30 = *((_OWORD *)&bindingAddress.address.addr4 + 1); /*0x1410cce62*/
          v55 = 0; /*0x1410cce66*/
          v31 = p_socket->_Rep; /*0x1410cce6b*/
          if ( v31 != nullptr ) /*0x1410cce72*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&v31->_Uses); /*0x1410cce74*/
            v31 = p_socket->_Rep; /*0x1410cce78*/
          }
          v55._Ptr = (RBX::File *)p_socket->_Ptr; /*0x1410cce7f*/
          v55._Rep = v31; /*0x1410cce83*/
          v66 = v62; /*0x1410cce8b*/
          v67 = v27; /*0x1410cce93*/
          *(_OWORD *)&v69.address.addr6.sin6_family = v29; /*0x1410cce9a*/
          *((_OWORD *)&v69.address.addr4 + 1) = v30; /*0x1410ccea1*/
          v70 = *systemAddress; /*0x1410ccead*/
          v24 = RakNet::RakPeer::AssignSystemAddressToRemoteSystemList( /*0x1410ccf22*/
                  this,
                  systemAddress: &v70,
                  connectionMode: UNVERIFIED_SENDER,
                  incomingRakNetSocket: &v55,
                  &thisIPConnectedRecently,
                  bindingAddress: &v69,
                  incomingMTU: v28,
                  guid: &v67,
                  useSecurity: false,
                  commonCapabilities: v14,
                  crypto: &v54,
                  gameServiceToken: &v66);
        }
        if ( DFFlag::TransportLibraryTest.value ) /*0x1410ccf2c*/
        {
          RakNet::SystemAddress::ToStringN( /*0x1410ccf54*/
            this: &this->socketList.listArray->_Ptr->boundAddress,
            writePort: true,
            dest: addressBuffer,
            size: 1025,
            portDelineator: 124);
          _Right._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410ccf59*/
          _Right._Mypair._Myval2._Mysize = 0; /*0x1410ccf5d*/
          _Right._Mypair._Myval2._Myres = 15; /*0x1410ccf61*/
          do /*0x1410ccf77*/
            ++v15; /*0x1410ccf70*/
          while ( addressBuffer[v15] != 0 ); /*0x1410ccf77*/
          std::string::assign(this: &_Right, _Ptr: addressBuffer, _Count: v15); /*0x1410ccf87*/
          std::string::operator=( /*0x1410ccf97*/
            this: (std::string *)&v24->reliabilityLayer.tLibTestClientStats.address._Mypair._Myval2._Bx._Alias[4],
            &_Right);
          if ( _Right._Mypair._Myval2._Myres >= 0x10 ) /*0x1410ccfa4*/
          {
            v32 = _Right._Mypair._Myval2._Bx._Ptr; /*0x1410ccfa9*/
            if ( _Right._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410ccfb7*/
            {
              v32 = *((char **)_Right._Mypair._Myval2._Bx._Ptr - 1); /*0x1410ccfbd*/
              if ( (unsigned __int64)(_Right._Mypair._Myval2._Bx._Ptr - v32 - 8) > 0x1F ) /*0x1410ccfcc*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410ccfce*/
            }
            operator delete(ptr: v32); /*0x1410ccfd5*/
          }
          _InterlockedExchange64( /*0x1410ccfde*/
            (volatile __int64 *)((char *)&v24->reliabilityLayer.tLibTestClientStats.bytesToReceive._Storage._Value + 4),
            this->tLibTestBytesToReceive);
        }
        if ( !thisIPConnectedRecently ) /*0x1410ccfec*/
        {
          if ( v24 != nullptr ) /*0x1410ccff5*/
          {
            v24->weInitiatedTheConnection = true; /*0x1410ccff7*/
            v24->connectMode = REQUESTED_CONNECTION; /*0x1410ccffc*/
            timeoutTime = v12->timeoutTime; /*0x1410cd007*/
            if ( timeoutTime != 0 ) /*0x1410cd010*/
              RakNet::ReliabilityLayer::SetTimeoutTime( /*0x1410cd019*/
                this: (RakNet::ReliabilityLayer *)((char *)&v24->reliabilityLayer.rbxSessionCrypto._Ptr + 4),
                time: timeoutTime);
            RakNet::RakPeer::sendApplicationConnectionRequest(this, rcs: v12, systemAddress, timeRead); /*0x1410cd02e*/
          }
          else
          {
            if ( DFLog::SessionCrypto != 0 ) /*0x1410cd041*/
              FLog::FastLog( /*0x1410cd04d*/
                level: DFLog::SessionCrypto,
                message: "[DFLog::SessionCrypto] RbxOpenReply2 too many recent connections",
                arg0: nullptr);
            v34 = RakNet::RakPeer::AllocPacket( /*0x1410cd06c*/
                    this,
                    dataSize: 1u,
                    file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                    line: 0x1DDBu);
            *v34->userMemory.data = 17; /*0x1410cd073*/
            v34->userMemory.bitSize = 8; /*0x1410cd076*/
            RakNet::SystemAddress::operator=(this: &v34->userMemory.systemAddress, input: &v12->systemAddress); /*0x1410cd083*/
            v34->userMemory.guid = guid; /*0x1410cd08c*/
            RakNet::RakPeer::AddPacketToProducer(this, p: (RakNet::InternalPacket *)v34); /*0x1410cd09e*/
            v35 = this->peerPlugin; /*0x1410cd0a3*/
            if ( v35 != nullptr ) /*0x1410cd0ad*/
              v35->OnFailedToIncludeRemoteSystemInRemoteSystemList(this: v35, a2: &v12->systemAddress); /*0x1410cd0b5*/
          }
        }
        rtc::CriticalSection::Enter(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410cd0c2*/
        while ( 1 )
        {
          head = this->requestedConnectionQueue.head; /*0x1410cd0d0*/
          tail = this->requestedConnectionQueue.tail; /*0x1410cd0d7*/
          v38 = head > tail ? this->requestedConnectionQueue.allocation_size - head + tail : tail - head;
          if ( v21 >= v38 ) /*0x1410cd0f4*/
            break; /*0x1410cd0f4*/
          v39 = head + v21; /*0x1410cd0f6*/
          v40 = v21 + head - this->requestedConnectionQueue.allocation_size; /*0x1410cd108*/
          if ( v39 >= this->requestedConnectionQueue.allocation_size ) /*0x1410cd111*/
            v39 = v40; /*0x1410cd111*/
          if ( RakNet::SystemAddress::operator==( /*0x1410cd125*/
                 this: &this->requestedConnectionQueue.array[v39]->systemAddress,
                 right: systemAddress) != 0 )
          {
            DataStructures::Queue<RakNet::RakPeer::RequestedConnectionStruct *>::RemoveAtIndex( /*0x1410cd134*/
              this: &this->requestedConnectionQueue,
              position: v21);
            break; /*0x1410cd134*/
          }
          ++v21; /*0x1410cd127*/
        }
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->requestedConnectionQueueMutex.criticalSection); /*0x1410cd139*/
        RakNet::RakPeer::RequestedConnectionStruct::`scalar deleting destructor'(this: v12, a2: 1); /*0x1410cd14d*/
        v41 = 1; /*0x1410cd152*/
        goto LABEL_97; /*0x1410cd154*/
      }
      v42 = this->__vftable; /*0x1410cd156*/
      v63 = RakNet::UNASSIGNED_SYSTEM_ADDRESS_30; /*0x1410cd160*/
      v43 = v42->GetGuidFromSystemAddress(this, a2: &v63); /*0x1410cd176*/
      RakNet::RakPeer::sendRbxOpenError(this, id: 0xBu, guid: v43, systemAddress, rakNetSocket); /*0x1410cd193*/
    }
    else if ( DFLog::SessionCrypto != 0 ) /*0x1410cca77*/
    {
      FLog::FastLog( /*0x1410cca87*/
        level: DFLog::SessionCrypto,
        message: "[DFLog::SessionCrypto] RbxOpenReply2 decrypt failed",
        arg0: nullptr);
    }
    v41 = 0; /*0x1410cd198*/
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &postBitStream); /*0xf1c0000000000008*/
  }
LABEL_97:
  RakNet::BitStream::~BitStream(this: &postBitStream); /*0x1410cd1a1*/
  return v41; /*0x1410cd1a9*/
}

// Address: 0x1410cd1d0 | Name: ?processRbxOpenRequest2@RakPeer@RakNet@@IEAA_NPEBE_KAEBUSystemAddress@2@2AEAV?$shared_ptr@URakNetSocket@RakNet@@@std@@GVStringView@RBX@@@Z
// local variable allocation has failed, the output may be wrong!
char __fastcall RakNet::RakPeer::processRbxOpenRequest2(
        RakNet::RakPeer *this,
        unsigned __int8 *data,
        unsigned __int64 length,
        RakNet::SystemAddress *systemAddress,
        const RakNet::SystemAddress *udmuxAddress,
        std::shared_ptr<RakNet::RakNetSocket> *rakNetSocket,
        unsigned __int16 ruppLength,
        std::shared_ptr<lm::StageResults> *gameServiceToken)
{
  std::string *Ptr; // rdx
  std::string *v13; // rax
  std::string *v14; // rbx
  std::_Ref_count_base *v15; // rax
  std::_Ref_count_base *v16; // r12
  unsigned __int8 *v17; // rdx
  unsigned __int64 Mysize; // rcx
  const char *v19; // rax
  RakNet::RakPeer::PreauthResult v20; // esi
  char *v21; // rcx
  char *v22; // rcx
  char *v23; // rax
  char v24; // bl
  unsigned int RemoteSystemIndex; // eax
  __int64 v26; // rdx
  RakNet::RakPeer::RemoteSystemStruct *v27; // r14
  char v28; // r15
  char *v29; // rcx
  std::_Ref_count_base *v30; // rax
  RBX::Security::RakPeerCrypto *v31; // rsi
  char *v32; // rcx
  RBX::Security::SessionCrypto *v33; // rax
  RBX::Security::RakPeerCrypto *v34; // rsi
  bool isRbxConnection; // dl
  const char *v36; // r8
  RBX::Network::Peer *peerPlugin; // rcx
  std::string *v38; // rbx
  unsigned __int64 v39; // rax
  unsigned __int64 v40; // r15
  int v41; // ebx
  char *v42; // rcx
  RakNet::RakPeer::RemoteSystemStruct *RemoteSystemFromGUID; // rax
  bool v44; // cl
  bool v45; // al
  bool v46; // zf
  __int128 v47; // xmm8
  int v48; // ebx
  std::_String_val<std::_Simple_types<char> >::_Bxty v49; // xmm6
  __int128 v50; // xmm7
  std::shared_ptr<RakNet::RakNetSocket> *v51; // r14
  std::shared_ptr<RBX::File> *v52; // rax
  RakNet::RakPeer::RemoteSystemStruct *v53; // rbx
  bool SupportAes; // al
  unsigned __int8 v55; // cl
  RBX::Security::SessionCrypto::CryptoFormat v56; // cl
  unsigned __int16 keyVersion; // [rsp+68h] [rbp-A0h] BYREF
  unsigned __int8 v59; // [rsp+6Ah] [rbp-9Eh] BYREF
  char v60; // [rsp+6Bh] [rbp-9Dh]
  unsigned __int16 mtu; // [rsp+6Ch] [rbp-9Ch] BYREF
  unsigned __int16 ciphertextLen[2]; // [rsp+70h] [rbp-98h] BYREF
  unsigned __int8 version[4]; // [rsp+74h] [rbp-94h] OVERLAPPED BYREF
  unsigned __int16 v64[2]; // [rsp+78h] [rbp-90h] BYREF
  unsigned __int8 inOutByteArray[4]; // [rsp+7Ch] [rbp-8Ch] BYREF
  unsigned __int8 inByteArray[4]; // [rsp+80h] [rbp-88h] BYREF
  unsigned __int8 v67[4]; // [rsp+84h] [rbp-84h] BYREF
  unsigned __int8 v68[16]; // [rsp+88h] [rbp-80h] BYREF
  std::string counterName; // [rsp+98h] [rbp-70h] BYREF
  std::shared_ptr<RBX::Security::RakPeerCrypto> v70; // [rsp+B8h] [rbp-50h] BYREF
  __m256i v71; // [rsp+C8h] [rbp-40h] OVERLAPPED BYREF
  std::shared_ptr<lm::StageResults> v72; // [rsp+E8h] [rbp-20h] BYREF
  __m256i v73; // [rsp+F8h] [rbp-10h] OVERLAPPED BYREF
  std::shared_ptr<lm::StageResults> v74; // [rsp+118h] [rbp+10h] BYREF
  std::string v75; // [rsp+128h] [rbp+20h] BYREF
  std::string v76; // [rsp+148h] [rbp+40h] BYREF
  std::string resource; // [rsp+168h] [rbp+60h] BYREF
  RBX::ArrayView<unsigned char> v78; // [rsp+188h] [rbp+80h]
  RBX::ArrayView<unsigned char> v79; // [rsp+198h] [rbp+90h]
  RBX::ArrayView<unsigned char> v80; // [rsp+1A8h] [rbp+A0h]
  std::pair<std::vector<unsigned char>,std::vector<unsigned char> > v81; // [rsp+1B8h] [rbp+B0h] BYREF
  RBX::ArrayView<unsigned char> v82; // [rsp+1E8h] [rbp+E0h] BYREF
  RBX::ArrayView<unsigned char> v83; // [rsp+1F8h] [rbp+F0h] BYREF
  RBX::ArrayView<unsigned char> v84; // [rsp+208h] [rbp+100h] BYREF
  RakNet::RakNetGUID v85; // [rsp+218h] [rbp+110h] BYREF
  RakNet::SystemAddress sa; // [rsp+228h] [rbp+120h] BYREF
  RakNet::SystemAddress outTemplateVar; // [rsp+248h] [rbp+140h] BYREF
  RakNet::SystemAddress input; // [rsp+268h] [rbp+160h] BYREF
  __int128 v89; // [rsp+288h] [rbp+180h] BYREF
  _BYTE v90[17]; // [rsp+298h] [rbp+190h] OVERLAPPED BYREF
  RakNet::BitStream postBitStream; // [rsp+2C0h] [rbp+1B8h] BYREF
  RBX::Analytics::InfluxDb::Points capBitReport; // [rsp+3F0h] [rbp+2E8h] BYREF
  char addressBuffer[1025]; // [rsp+460h] [rbp+358h] BYREF
  unsigned __int8 aadLen; // [rsp+8E8h] [rbp+7E0h] BYREF
  unsigned __int8 *_data; // [rsp+8F0h] [rbp+7E8h]
  unsigned __int8 desiredEncryption; // [rsp+8F8h] [rbp+7F0h] BYREF

  _data = data; /*0x1410cd1d7*/
  rtc::CriticalSection::Enter(lpCriticalSection: &this->connectionRequestsStats.mx.criticalSection); /*0x1410cd214*/
  ++this->connectionRequestsStats.counters[5]; /*0x1410cd219*/
  RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->connectionRequestsStats.mx.criticalSection); /*0x1410cd226*/
  if ( length >= 0x6B && length + ruppLength + 40LL >= 0x240 )
  {
    ciphertextLen[0] = 0; /*0x1410cd254*/
    *(_OWORD *)&v73.m256i_u64[2] = 0; /*0x1410cd25d*/
    __wind
    {
      RakNet::BitStream::BitStream( /*0x1410cd272*/
        this: (RakNet::BitStream *)&addressBuffer[8],
        _data: data,
        lengthInBytes: length,
        _copyData: false);
      __eh34_enter_wind_state(0, 1); /*0xf1c000000000014c*/
      RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)&addressBuffer[8], numberOfBytes: 0x11u); /*0x1410cd283*/
      RakNet::BitStream::ReadBits( /*0x1410cd29b*/
        this: (RakNet::BitStream *)&addressBuffer[8],
        inOutByteArray,
        numberOfBitsToRead: 8u,
        alignBitsToRight: true);
      RakNet::BitStream::ReadBits( /*0x1410cd2b5*/
        this: (RakNet::BitStream *)&addressBuffer[8],
        inOutByteArray: &aadLen,
        numberOfBitsToRead: 8u,
        alignBitsToRight: true);
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410cd2ba*/
      {
        RakNet::BitStream::ReadBits( /*0x1410cd2f9*/
          this: (RakNet::BitStream *)&addressBuffer[8],
          inOutByteArray: (unsigned __int8 *)v64,
          numberOfBitsToRead: 0x10u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits( /*0x1410cd2dd*/
                  this: (RakNet::BitStream *)&addressBuffer[8],
                  inOutByteArray: inByteArray,
                  numberOfBitsToRead: 0x10u,
                  alignBitsToRight: true) != 0 )
      {
        RBX::Network::NetworkStream::ReverseBytes(inByteArray, inOutByteArray: (unsigned __int8 *)v64, length: 2u); /*0x1410cd2ed*/
      }
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410cd2fe*/
      {
        RakNet::BitStream::ReadBits( /*0x1410cd341*/
          this: (RakNet::BitStream *)&addressBuffer[8],
          inOutByteArray: (unsigned __int8 *)ciphertextLen,
          numberOfBitsToRead: 0x10u,
          alignBitsToRight: true);
      }
      else if ( RakNet::BitStream::ReadBits( /*0x1410cd323*/
                  this: (RakNet::BitStream *)&addressBuffer[8],
                  inOutByteArray: v67,
                  numberOfBitsToRead: 0x10u,
                  alignBitsToRight: true) != 0 )
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410cd335*/
          inByteArray: v67,
          inOutByteArray: (unsigned __int8 *)ciphertextLen,
          length: 2u);
      }
      RakNet::BitStream::ReadAlignedBytes( /*0x1410cd35a*/
        this: (RakNet::BitStream *)&addressBuffer[8],
        inOutByteArray: &v90[16],
        numberOfBytesToRead: 0x20u);
      if ( FFlag::DebugLocalRccServerConnection.value && FFlag::DebugLocalRccTicketTesting.value ) /*0x1410cd373*/
      {
        HIBYTE(keyVersion) = 0; /*0x1410cd379*/
        RakNet::BitStream::ReadBits( /*0x1410cd393*/
          this: (RakNet::BitStream *)&addressBuffer[8],
          inOutByteArray: (unsigned __int8 *)&keyVersion + 1,
          numberOfBitsToRead: 8u,
          alignBitsToRight: true);
        std::string::resize(this: &RBX::Http::gameID, _Newsize: HIBYTE(keyVersion), _Ch: 0); /*0x1410cd3a7*/
        Ptr = &RBX::Http::gameID; /*0x1410cd3ac*/
        if ( RBX::Http::gameID._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cd3bb*/
          Ptr = (std::string *)RBX::Http::gameID._Mypair._Myval2._Bx._Ptr; /*0x1410cd3bb*/
        RakNet::BitStream::ReadAlignedBytes( /*0x1410cd3d1*/
          this: (RakNet::BitStream *)&addressBuffer[8],
          inOutByteArray: (unsigned __int8 *)Ptr,
          numberOfBytesToRead: RBX::Http::gameID._Mypair._Myval2._Mysize);
        this->setJobId(this, a2: &RBX::Http::gameID); /*0x1410cd3e3*/
        if ( RBX::debugLocalRccTicketCallback != nullptr ) /*0x1410cd3f3*/
          RBX::debugLocalRccTicketCallback(a1: &RBX::Http::gameID); /*0x1410cd3fc*/
      }
      v13 = (std::string *)operator new(size: 0x48u); /*0x1410cd403*/
      v14 = v13; /*0x1410cd408*/
      if ( v13 != nullptr ) /*0x1410cd40e*/
      {
        v13->_Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410cd410*/
        v13->_Mypair._Myval2._Mysize = 0; /*0x1410cd413*/
        v13->_Mypair._Myval2._Myres = 15; /*0x1410cd417*/
        v13[1]._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410cd41f*/
        v13[1]._Mypair._Myval2._Mysize = 0; /*0x1410cd423*/
        v13[1]._Mypair._Myval2._Myres = 15; /*0x1410cd427*/
      }
      else
      {
        v14 = nullptr; /*0x1410cd431*/
      }
      v73.m256i_i64[0] = (__int64)v14; /*0x1410cd434*/
      __wind /*0xf1c0000000000140*/
      {
        v15 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x1410cd43d*/
        v16 = v15; /*0x1410cd442*/
        v71.m256i_i64[0] = (__int64)v15; /*0x1410cd445*/
        if ( v15 != nullptr ) /*0x1410cd452*/
        {
          *v15 = 0; /*0x1410cd457*/
          v15->_Uses = 1; /*0x1410cd45a*/
          v15->_Weaks = 1; /*0x1410cd45e*/
          v15->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Security::EarlyAuthData>::`vftable'; /*0x1410cd469*/
          v15[1].__vftable = (std::_Ref_count_base_vtbl *)v14; /*0x1410cd46d*/
        }
        else
        {
          v16 = nullptr; /*0x1410cd474*/
        }
      }
      __unwind
      {
        std::_Temporary_owner<RBX::Security::EarlyAuthData>::~_Temporary_owner<RBX::Security::EarlyAuthData>(this: (std::_Temporary_owner<RBX::Security::EarlyAuthData> *)&v73); /*0xf1c0000000000138*/
      }
      v73.m256i_i64[2] = (__int64)v14; /*0x1410cd477*/
      v73.m256i_i64[3] = (__int64)v16; /*0x1410cd47b*/
      RakNet::BitStream::ReadBits( /*0x1410cd493*/
        this: (RakNet::BitStream *)&addressBuffer[8],
        inOutByteArray: (unsigned __int8 *)&v14[2],
        numberOfBitsToRead: 8u,
        alignBitsToRight: true);
      RakNet::BitStream::ReadBits( /*0x1410cd4ad*/
        this: (RakNet::BitStream *)&addressBuffer[8],
        inOutByteArray: &v59,
        numberOfBitsToRead: 8u,
        alignBitsToRight: true);
      std::string::resize(this: v14, _Newsize: v59, _Ch: 0); /*0x1410cd4bd*/
      v17 = (unsigned __int8 *)v14; /*0x1410cd4c8*/
      if ( v14->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410cd4d0*/
        v17 = (unsigned __int8 *)v14->_Mypair._Myval2._Bx._Ptr; /*0x1410cd4d2*/
      RakNet::BitStream::ReadAlignedBytes( /*0x1410cd4dc*/
        this: (RakNet::BitStream *)&addressBuffer[8],
        inOutByteArray: v17,
        numberOfBytesToRead: v59);
      Mysize = v14->_Mypair._Myval2._Mysize; /*0x1410cd4e1*/
      v19 = (const char *)v14; /*0x1410cd4e5*/
      if ( v14->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410cd4ed*/
        v19 = v14->_Mypair._Myval2._Bx._Ptr; /*0x1410cd4ef*/
      v72._Ptr = (lm::StageResults *)v19; /*0x1410cd4f2*/
      v72._Rep = (std::_Ref_count_base *)Mysize; /*0x1410cd4f6*/
      v74 = v72; /*0x1410cd4fe*/
      v20 = RakNet::RakPeer::verifyPreauthMac( /*0x1410cd514*/
              this,
              preauthBlob: (RBX::StringView *)&v74,
              authVersion: v14[2]._Mypair._Myval2._Bx._Buf[0]);
      switch ( v20 )
      {
        case FailToVerify:
          counterName._Mypair._Myval2._Myres = 15; /*0x1410cd51e*/
          counterName._Mypair._Myval2._Mysize = 12; /*0x1410cd526*/
          strcpy(counterName._Mypair._Myval2._Bx._Buf, "Preauth-Fail"); /*0x1410cd536*/
          __eh34_enter_wind_state(1, 3); /*0xf1c000000000012c*/
          RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x1410cd551*/
          if ( __eh34_unwind(3) ) /*0xf1c0000000000120*/
            goto unwind_state_3; /*0xf1c0000000000120*/
          __eh34_exit_wind_state(3, 1); /*0xf1c0000000000124*/
          if ( counterName._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cd55f*/
          {
            v21 = counterName._Mypair._Myval2._Bx._Ptr; /*0x1410cd564*/
            if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cd572*/
            {
              v21 = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cd578*/
              if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x1410cd587*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410cd589*/
            }
            operator delete(ptr: v21); /*0x1410cd590*/
          }
          if ( !FFlag::DebugLocalRccServerConnection.value || FFlag::DebugLocalRccTicketTesting.value ) /*0x1410cd5a9*/
            goto LABEL_53; /*0x1410cd5a9*/
LABEL_50:
          if ( aadLen != *(_DWORD *)&addressBuffer[32] >> 3 ) /*0x1410cd6e1*/
          {
            if ( DFLog::SessionCrypto != 0 ) /*0x1410cd6ec*/
              FLog::FastLogFormatted( /*0x1410cd6f7*/
                level: DFLog::SessionCrypto,
                message: "[DFLog::SessionCrypto] RbxOpenRequest2 unexpected aad size %d.",
                aadLen);
LABEL_53:
            RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&addressBuffer[8]); /*0x1410cd6fd*/
            v24 = 0; /*0x1410cd709*/
            if ( __eh34_unwind(1) ) /*0xf1c0000000000160*/
              goto unwind_state_1; /*0xf1c0000000000160*/
            __eh34_exit_wind_state(1, 0); /*0xf1c0000000000164*/
            goto LABEL_174; /*0xf1c0000000000168*/
          }
          RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&addressBuffer[8]); /*0x1410cd717*/
          if ( __eh34_unwind(1) ) /*0xf1c00000000000e8*/
          {
unwind_state_1:
            RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&addressBuffer[8]); /*0xf1c00000000000ec*/
            __eh34_continue_unwinding(1, 0); /*0xf1c00000000000f0*/
          }
          __eh34_exit_wind_state(1, 0); /*0xf1c00000000000f4*/
          *(_DWORD *)v68 = aadLen + v64[0]; /*0x1410cd72d*/
          if ( aadLen < 0x35u ) /*0x1410cd732*/
          {
            if ( DFLog::SessionCrypto != 0 ) /*0x1410cd73d*/
            {
              FLog::FastLogFormatted( /*0x1410cd74c*/
                level: DFLog::SessionCrypto,
                message: "[DFLog::SessionCrypto] RbxOpenRequest2 unexpected aad size %d.",
                aadLen);
              v24 = 0; /*0x1410cd751*/
              goto LABEL_174; /*0x1410cd753*/
            }
LABEL_85:
            v24 = 0; /*0x1410cd94f*/
            goto LABEL_174; /*0x1410cd951*/
          }
          sa = *systemAddress; /*0x1410cd75d*/
          if ( RakNet::SystemAddress::operator==(this: &sa, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 /*0x1410cd7bb*/
            || (RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, &sa)) == -1
            || !*(&this->remoteSystemList->isActive._Storage._Value + (v26 = RemoteSystemIndex)) )
          {
            v27 = nullptr; /*0x1410cd89f*/
          }
          else
          {
            v27 = &this->remoteSystemList[v26]; /*0x1410cd7c8*/
            if ( v27 != nullptr && v27->isActive._Storage._Value ) /*0x1410cd7d1*/
            {
              v28 = 1; /*0x1410cd7de*/
              v60 = 1; /*0x1410cd7e2*/
              if ( v20 == Duplicate ) /*0x1410cd7e9*/
              {
                v75._Mypair._Myval2._Myres = 15; /*0x1410cd7eb*/
                v75._Mypair._Myval2._Mysize = 12; /*0x1410cd7f3*/
                strcpy(v75._Mypair._Myval2._Bx._Buf, "Preauth-Drop"); /*0x1410cd803*/
                __wind /*0xf1c00000000000dc*/
                {
                  RBX::Analytics::EphemeralCounter::reportCounter(counterName: &v75, amount: 1, blocking: false); /*0x1410cd81f*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v75); /*0xf1c00000000000d4*/
                }
                if ( v75._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cd82d*/
                {
                  v29 = v75._Mypair._Myval2._Bx._Ptr; /*0x1410cd832*/
                  if ( v75._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cd840*/
                  {
                    v29 = *((char **)v75._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cd846*/
                    if ( (unsigned __int64)(v75._Mypair._Myval2._Bx._Ptr - v29 - 8) > 0x1F ) /*0x1410cd855*/
                      _invalid_parameter_noinfo_noreturn(); /*0x1410cd857*/
                  }
                  operator delete(ptr: v29); /*0x1410cd85e*/
                }
              }
              goto LABEL_70; /*0x1410cd85e*/
            }
          }
          v28 = 0; /*0x1410cd8a2*/
          v60 = 0; /*0x1410cd8a5*/
          if ( v20 == Duplicate ) /*0x1410cd8ad*/
          {
            __wind /*0xf1c00000000000c4*/
            {
              v76._Mypair._Myval2._Myres = 15; /*0x1410cd8af*/
              v76._Mypair._Myval2._Mysize = 12; /*0x1410cd8b7*/
              strcpy(v76._Mypair._Myval2._Bx._Buf, "Preauth-Dupe"); /*0x1410cd8c7*/
              RBX::Analytics::EphemeralCounter::reportCounter(counterName: &v76, amount: 1, blocking: false); /*0x1410cd8e3*/
              if ( v76._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cd8f1*/
              {
                v32 = v76._Mypair._Myval2._Bx._Ptr; /*0x1410cd8f6*/
                if ( v76._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cd904*/
                {
                  v32 = *((char **)v76._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cd90a*/
                  if ( (unsigned __int64)(v76._Mypair._Myval2._Bx._Ptr - v32 - 8) > 0x1F ) /*0x1410cd919*/
                    _invalid_parameter_noinfo_noreturn(); /*0x1410cd91b*/
                }
                operator delete(ptr: v32); /*0x1410cd922*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v76); /*0xf1c00000000000bc*/
            }
            if ( this->preauthKey._Mypair._Myval2._Mysize != 0 ) /*0x1410cd92f*/
            {
              if ( DFLog::SessionCrypto != 0 ) /*0x1410cd93e*/
                FLog::FastLog( /*0x1410cd94a*/
                  level: DFLog::SessionCrypto,
                  message: "[DFLog::SessionCrypto] RbxOpenRequest2 mac was previously used but did not create active rss",
                  arg0: nullptr);
              goto LABEL_85; /*0x1410cd94a*/
            }
          }
LABEL_70:
          v70 = 0; /*0x1410cd863*/
          if ( v28 != 0 ) /*0x1410cd86e*/
          {
            v30 = *(std::_Ref_count_base **)((char *)&v27->reliabilityLayer.rbxSessionCrypto._Rep + 4); /*0x1410cd874*/
            if ( v30 != nullptr ) /*0x1410cd87e*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v30->_Uses); /*0x1410cd880*/
              v30 = *(std::_Ref_count_base **)((char *)&v27->reliabilityLayer.rbxSessionCrypto._Rep + 4); /*0x1410cd884*/
            }
            v31 = *(RBX::Security::RakPeerCrypto **)((char *)&v27->reliabilityLayer.rbxSessionCrypto._Ptr + 4); /*0x1410cd88b*/
            v70._Ptr = v31; /*0x1410cd892*/
            v70._Rep = v30; /*0x1410cd896*/
            __eh34_enter_wind_state(0, 6); /*0xf1c0000000000078*/
          }
          else
          {
            __eh34_enter_wind_state(0, 6); /*0xf1c00000000000b0*/
            v33 = (RBX::Security::SessionCrypto *)operator new(size: 0x80u); /*0x1410cd95b*/
            __wind /*0xf1c00000000000a4*/
            {
              v34 = (RBX::Security::RakPeerCrypto *)v33; /*0x1410cd960*/
              v71.m256i_i64[0] = (__int64)v33; /*0x1410cd963*/
              if ( v33 != nullptr ) /*0x1410cd96a*/
              {
                RBX::Security::SessionCrypto::SessionCrypto(this: v33); /*0x1410cd96f*/
                v34->__vftable = (RBX::Security::RakPeerCrypto_vtbl *)RBX::Security::RakPeerCrypto::`vftable'; /*0x1410cd97b*/
              }
              else
              {
                v34 = nullptr; /*0x1410cd980*/
              }
            }
            __unwind
            {
              operator delete(ptr: (void *)v71.m256i_i64[0]); /*0x1431d1e15*/
            }
            std::shared_ptr<RBX::Security::RakPeerCrypto>::reset<RBX::Security::RakPeerCrypto>(this: &v70, _Px: v34); /*0x1410cd989*/
            isRbxConnection = this->isRbxConnection; /*0x1410cd999*/
            if ( isRbxConnection != (ciphertextLen[0] != 0) ) /*0x1410cd9a2*/
            {
              if ( DFLog::SessionCrypto != 0 ) /*0x1410cd9ad*/
              {
                v36 = "local"; /*0x1410cd9ba*/
                if ( isRbxConnection ) /*0x1410cd9c3*/
                  v36 = aRobl; /*0x1410cd9c3*/
                FLog::FastLogS( /*0x1410cd9ce*/
                  level: DFLog::SessionCrypto,
                  message: "[DFLog::SessionCrypto] RbxOpenRequest2 key exchange version incorrect for connecting to %s server",
                  sarg: v36);
                v24 = 0; /*0x1410cd9d3*/
                goto LABEL_176; /*0x1410cd9d5*/
              }
              goto LABEL_99; /*0x1410cd9ad*/
            }
            RBX::Security::RakPeerCrypto::getServerKeyInfo(result: &v81, version: ciphertextLen[0]); /*0x1410cd9e3*/
            __wind /*0xf1c000000000008c*/
            {
              v79.buffer = v81.second._Mypair._Myval2._Myfirst; /*0x1410cd9fa*/
              v79.length = v81.second._Mypair._Myval2._Mylast - v81.second._Mypair._Myval2._Myfirst; /*0x1410cda01*/
              v80.buffer = v81.first._Mypair._Myval2._Myfirst; /*0x1410cda19*/
              v80.length = v81.first._Mypair._Myval2._Mylast - v81.first._Mypair._Myval2._Myfirst; /*0x1410cda20*/
              v82 = v79; /*0x1410cda2e*/
              v83 = v80; /*0x1410cda3d*/
              v31 = v70._Ptr; /*0x1410cda53*/
              RBX::Security::RakPeerCrypto::initServer(this: v70._Ptr, publicEarlyKey: &v83, secretEarlyKey: &v82); /*0x1410cda5a*/
              v78.buffer = &v90[16]; /*0x1410cda66*/
              v78.length = 32; /*0x1410cda6d*/
              v84 = v78; /*0x1410cda7f*/
              RBX::Security::RakPeerCrypto::serverInitEarlySessionKeys(this: v31, peerPublicKey: &v84); /*0x1410cda91*/
            }
            __unwind
            {
              std::pair<std::vector<unsigned char>,std::vector<unsigned char>>::~pair<std::vector<unsigned char>,std::vector<unsigned char>>(this: &v81); /*0xf1c0000000000084*/
            }
            RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&v81.second); /*0x1410cda9e*/
            RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&v81); /*0x1410cdaaa*/
          }
          if ( v31 == nullptr ) /*0x1410cdab2*/
          {
            if ( DFLog::SessionCrypto != 0 ) /*0x1410cdabd*/
              FLog::FastLog( /*0x1410cdac9*/
                level: DFLog::SessionCrypto,
                message: "[DFLog::SessionCrypto] RbxOpenRequest2 no session crypto",
                arg0: nullptr);
LABEL_99:
            v24 = 0; /*0x1410cdace*/
            if ( __eh34_unwind(6) ) /*0xf1c000000000001c*/
            {
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v70); /*0xf1c0000000000020*/
              __eh34_continue_unwinding(6, 0); /*0xf1c0000000000024*/
            }
LABEL_176:
            __eh34_exit_wind_state(6, 0); /*0xf1c0000000000028*/
            if ( v70._Rep != nullptr ) /*0x1410ce0e5*/
              std::_Ref_count_base::_Decref(this: v70._Rep); /*0x1410ce0e7*/
            goto LABEL_174; /*0xf1c000000000016c*/
          }
          RakNet::BitStream::BitStream( /*0x1410cdaee*/
            this: (RakNet::BitStream *)&postBitStream.isJoinData,
            _data,
            lengthInBytes: *(_DWORD *)v68 + 28,
            _copyData: false);
          __wind
          {
            if ( !RBX::Security::RakPeerCrypto::earlyDecryptData( /*0x1410cdb06*/
                    this: v31,
                    bitstream: (RakNet::BitStream *)&postBitStream.isJoinData,
                    aadSize: aadLen) )
            {
              RakNet::SystemAddress::ToStringN( /*0x1410cdb26*/
                this: systemAddress,
                writePort: false,
                dest: &addressBuffer[8],
                size: 1025,
                portDelineator: 124);
              if ( DFLog::SessionCrypto != 0 ) /*0x1410cdb34*/
              {
                FLog::FastLogS( /*0x1410cdb48*/
                  level: DFLog::SessionCrypto,
                  message: "[DFLog::SessionCrypto] RbxOpenRequest2 decrypt failed for %s",
                  sarg: &addressBuffer[8]);
                v24 = 0; /*0x1410cdb4d*/
LABEL_165:
                RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&postBitStream.isJoinData); /*0x1410ce0d1*/
                goto LABEL_189; /*0xf1c00000000001cc*/
              }
LABEL_118:
              v24 = 0; /*0x1410cdcf1*/
              goto LABEL_165; /*0x1410cdcf3*/
            }
            peerPlugin = this->peerPlugin; /*0x1410cdb54*/
            if ( peerPlugin != nullptr ) /*0x1410cdb5e*/
              peerPlugin->OnReceiveOpenConnectionReply2(this: peerPlugin); /*0x1410cdb63*/
            RakNet::BitStream::IgnoreBytes(this: (RakNet::BitStream *)&postBitStream.isJoinData, numberOfBytes: aadLen); /*0x1410cdb77*/
            v71.m256i_i64[0] = readCapabilitiesIfAny(bs: (RakNet::BitStream *)&postBitStream.isJoinData); /*0x1410cdb88*/
            RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)&v71.m256i_u64[2]); /*0x1410cdb90*/
            RakNet::BitStream::Read<unsigned __int64>( /*0x1410cdba0*/
              this: (RakNet::BitStream *)&postBitStream.isJoinData,
              outTemplateVar: &v71.m256i_u64[2]);
            if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410cdba5*/
            {
              RakNet::BitStream::ReadBits( /*0x1410cdbe6*/
                this: (RakNet::BitStream *)&postBitStream.isJoinData,
                inOutByteArray: version,
                numberOfBitsToRead: 0x10u,
                alignBitsToRight: true);
            }
            else if ( RakNet::BitStream::ReadBits( /*0x1410cdbc9*/
                        this: (RakNet::BitStream *)&postBitStream.isJoinData,
                        inOutByteArray: v68,
                        numberOfBitsToRead: 0x10u,
                        alignBitsToRight: true) != 0 )
            {
              RBX::Network::NetworkStream::ReverseBytes(inByteArray: v68, inOutByteArray: version, length: 2u); /*0x1410cdbda*/
            }
            RakNet::BitStream::ReadBits( /*0x1410cdc02*/
              this: (RakNet::BitStream *)&postBitStream.isJoinData,
              inOutByteArray: &desiredEncryption,
              numberOfBitsToRead: 8u,
              alignBitsToRight: true);
            RakNet::SystemAddress::SystemAddress(this: &outTemplateVar); /*0x1410cdc0e*/
            RakNet::BitStream::Read<RakNet::SystemAddress>( /*0x1410cdc21*/
              this: (RakNet::BitStream *)&postBitStream.isJoinData,
              &outTemplateVar);
            if ( FFlag::DebugLocalRccServerConnection.value && FFlag::DebugLocalRccRuppToken.value ) /*0x1410cdc36*/
            {
              RakNet::SystemAddress::SystemAddress(this: &input); /*0x1410cdc3f*/
              RakNet::BitStream::Read<RakNet::SystemAddress>( /*0x1410cdc52*/
                this: (RakNet::BitStream *)&postBitStream.isJoinData,
                outTemplateVar: &input);
              RakNet::SystemAddress::operator=(this: &this->rccBoundAddress, &input); /*0x1410cdc62*/
            }
            LOBYTE(keyVersion) = 0; /*0x1410cdc67*/
            RakNet::BitStream::ReadBits( /*0x1410cdc81*/
              this: (RakNet::BitStream *)&postBitStream.isJoinData,
              inOutByteArray: (unsigned __int8 *)&keyVersion,
              numberOfBitsToRead: 8u,
              alignBitsToRight: true);
            v38 = v14 + 1; /*0x1410cdc86*/
            std::string::resize(this: v38, _Newsize: (unsigned __int8)keyVersion, _Ch: 0); /*0x1410cdc95*/
            if ( v38->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410cdca5*/
              v38 = (std::string *)v38->_Mypair._Myval2._Bx._Ptr; /*0x1410cdca7*/
            RakNet::BitStream::ReadAlignedBytes( /*0x1410cdcb4*/
              this: (RakNet::BitStream *)&postBitStream.isJoinData,
              inOutByteArray: (unsigned __int8 *)v38,
              numberOfBytesToRead: (unsigned __int8)keyVersion);
            std::shared_ptr<RBX::GfxGui>::operator=( /*0x1410cdcc1*/
              this: (std::shared_ptr<RobloxDiagnosticsView::ItemData> *)&v31->earlyAuthData,
              _Right: (const std::shared_ptr<RobloxDiagnosticsView::ItemData> *)&v73.m256i_u64[2]);
            if ( *(_WORD *)version < 0x240u ) /*0x1410cdcd3*/
            {
              if ( DFLog::SessionCrypto != 0 ) /*0x1410cdcde*/
                FLog::FastLogFormatted( /*0x1410cdcec*/
                  level: DFLog::SessionCrypto,
                  message: "[DFLog::SessionCrypto] RbxOpenRequest2 invalide mtu %d.",
                  *(unsigned __int16 *)version);
              goto LABEL_118; /*0x1410cdcec*/
            }
            v39 = buildRakPeerCapabilities(peer: this); /*0x1410cdcfb*/
            v40 = v71.m256i_i64[0] & v39; /*0x1410cdd07*/
            if ( DFLog::NetworkTrace != 0 )
              FLog::FastLogFormatted(
                level: DFLog::NetworkTrace,
                message: "[DFLog::NetworkTrace] Peer has capabilities: 0x%llx ,common capabilities: 0x%llx",
                v71.m256i_i64[0],
                v40);
            RBX::Analytics::InfluxDb::Points::Points( /*0x1410cdd37*/
              this: (RBX::Analytics::InfluxDb::Points *)&capBitReport.pointList._List,
              throttleHundredthsPercentage: -1,
              categoryType: kStandardType,
              priorityHundredthsPercentage: 0);
            __wind /*0xf1c0000000000054*/
            {
              RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410cdd4e*/
                this: (RBX::Analytics::InfluxDb::Points *)&capBitReport.pointList._List,
                name: "NegotiatedCapabilityBit",
                value: v40);
              v41 = DFInt::NetworkCapBitReportPerMyriad; /*0x1410cdd53*/
              resource._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410cdd5b*/
              resource._Mypair._Myval2._Mysize = 0; /*0x1410cdd5f*/
              resource._Mypair._Myval2._Myres = 15; /*0x1410cdd63*/
              std::string::assign(this: &resource, _Ptr: "RakNetCapabilityBitNegotiated", _Count: 0x1Du); /*0x1410cdd7d*/
              __wind /*0xf1c0000000000048*/
              {
                RBX::Analytics::InfluxDb::Points::report( /*0x1410cdd94*/
                  this: (RBX::Analytics::InfluxDb::Points *)&capBitReport.pointList._List,
                  &resource,
                  throttleHundredthsPercentage: v41,
                  blocking: false);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000040*/
              }
              if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cdda2*/
              {
                v42 = resource._Mypair._Myval2._Bx._Ptr; /*0x1410cdda7*/
                if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cddb5*/
                {
                  v42 = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cddbb*/
                  if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - v42 - 8) > 0x1F ) /*0x1410cddca*/
                    _invalid_parameter_noinfo_noreturn(); /*0x1410cddcc*/
                }
                operator delete(ptr: v42); /*0x1410cddd3*/
              }
              v85 = *(RakNet::RakNetGUID *)&v71.m256i_u64[2]; /*0x1410cdddc*/
              RemoteSystemFromGUID = RakNet::RakPeer::GetRemoteSystemFromGUID(this, guid: &v85, onlyActive: true); /*0x1410cddf1*/
              v44 = false; /*0x1410cde07*/
              if ( RemoteSystemFromGUID != nullptr ) /*0x1410cddf9*/
              {
                v31 = v70._Ptr; /*0x1410cddff*/
                if ( RemoteSystemFromGUID->isActive._Storage._Value ) /*0x1410cddfb*/
                  v44 = true; /*0x1410cddf9*/
              }
              if ( v60 != 0 ) /*0x1410cde14*/
              {
                if ( v44 ) /*0x1410cde18*/
                {
                  if ( v27 == RemoteSystemFromGUID && v27->connectMode == UNVERIFIED_SENDER ) /*0x1410cde27*/
                  {
                    v45 = RakNet::RakPeer::sendRbxOpenReply2(this, rss: v27, systemAddress, udmuxAddress, rakNetSocket); /*0x1410cde38*/
LABEL_163:
                    v24 = v45; /*0x1410ce0c1*/
                    goto LABEL_179; /*0xf1c0000000000170*/
                  }
                  goto LABEL_139; /*0x1410cde27*/
                }
                v46 = v60 == 1; /*0x1410cde3d*/
              }
              else
              {
                v46 = v44; /*0x1410cde42*/
              }
              if ( !v46 ) /*0x1410cde45*/
              {
                if ( !RakNet::RakPeer::AllowIncomingConnections(this) ) /*0x1410cde88*/
                {
                  if ( DFLog::SessionCrypto != 0 ) /*0x1410cde9a*/
                    FLog::FastLog( /*0x1410cdea6*/
                      level: DFLog::SessionCrypto,
                      message: "[DFLog::SessionCrypto] RbxOpenRequest2 no free incoming connections",
                      arg0: nullptr);
                  RakNet::RakPeer::sendRbxOpenError( /*0x1410cdec3*/
                    this,
                    id: 0x14u,
                    guid: (const RakNet::RakNetGUID *)&v71.m256i_u64[2],
                    systemAddress,
                    rakNetSocket);
                  v24 = 1; /*0x1410cdec8*/
                  goto LABEL_179; /*0x1410cdeca*/
                }
                LOBYTE(mtu) = 0; /*0x1410cdecf*/
                *(_OWORD *)v71.m256i_i8 = 0; /*0x1410cded7*/
                if ( v70._Rep != nullptr ) /*0x1410cdee3*/
                {
                  _InterlockedIncrement((volatile signed __int32 *)&v70._Rep->_Uses); /*0x1410cdee5*/
                  v31 = v70._Ptr; /*0x1410cdee9*/
                }
                *(std::shared_ptr<RBX::Security::RakPeerCrypto> *)v71.m256i_i8 = v70; /*0x1410cdef1*/
                v47 = *(_OWORD *)&v71.m256i_u64[2]; /*0x1410cdef6*/
                v48 = *(unsigned __int16 *)version; /*0x1410cdefb*/
                v49 = *(std::_String_val<std::_Simple_types<char> >::_Bxty *)&outTemplateVar.address.addr6.sin6_family; /*0x1410cdf00*/
                v50 = *((_OWORD *)&outTemplateVar.address.addr4 + 1); /*0x1410cdf07*/
                v51 = rakNetSocket; /*0x1410cdf0e*/
                v52 = (std::shared_ptr<RBX::File> *)std::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>( /*0x1410cdf1c*/
                                                      this: &v74,
                                                      _Other: (const std::shared_ptr<lm::StageResults> *)rakNetSocket);
                v72 = *gameServiceToken; /*0x1410cdf2b*/
                *(_OWORD *)v73.m256i_i8 = v47; /*0x1410cdf2f*/
                counterName._Mypair._Myval2._Bx = v49; /*0x1410cdf34*/
                *(_OWORD *)&counterName._Mypair._Myval2._Mysize = v50; /*0x1410cdf38*/
                v89 = *(_OWORD *)&systemAddress->address.addr6.sin6_family; /*0x1410cdf41*/
                *(_OWORD *)v90 = *((_OWORD *)&systemAddress->address.addr4 + 1); /*0x1410cdf4d*/
                v53 = RakNet::RakPeer::AssignSystemAddressToRemoteSystemList( /*0x1410cdfa8*/
                        this,
                        systemAddress: (RakNet::SystemAddress *)&v89,
                        connectionMode: UNVERIFIED_SENDER,
                        incomingRakNetSocket: v52,
                        thisIPConnectedRecently: (bool *)&mtu,
                        bindingAddress: (RakNet::SystemAddress *)&counterName,
                        incomingMTU: v48,
                        guid: (RakNet::RakNetGUID *)&v73,
                        useSecurity: false,
                        commonCapabilities: v40,
                        crypto: (std::shared_ptr<RBX::File> *)&v71,
                        gameServiceToken: (RBX::StringView *)&v72);
                if ( (_BYTE)mtu == 1 ) /*0x1410cdfb0*/
                {
                  if ( DFLog::SessionCrypto != 0 ) /*0x1410cdfbb*/
                    FLog::FastLog( /*0x1410cdfc7*/
                      level: DFLog::SessionCrypto,
                      message: "[DFLog::SessionCrypto] RbxOpenRequest2 recently connected",
                      arg0: nullptr);
                  RakNet::RakPeer::sendRbxOpenError( /*0x1410cdfdd*/
                    this,
                    id: 0x1Au,
                    guid: (const RakNet::RakNetGUID *)&v71.m256i_u64[2],
                    systemAddress,
                    rakNetSocket: v51);
                  v24 = 1; /*0x1410cdfe2*/
                  goto LABEL_179; /*0x1410cdfe4*/
                }
                RBX::Security::RakPeerCrypto::serverInitEphemeralSessionKeys(this: v31); /*0x1410cdfec*/
                if ( RBX::Security::SessionCrypto::isAesGcm(format: (RBX::Security::SessionCrypto::CryptoFormat)desiredEncryption) ) /*0x1410cdff8*/
                {
                  SupportAes = RBX::Security::SessionCrypto::getSupportAes(this: v31); /*0x1410ce004*/
                  v55 = desiredEncryption; /*0x1410ce009*/
                  if ( !SupportAes ) /*0x1410ce017*/
                    v55 = 1; /*0x1410ce017*/
                }
                else
                {
                  v55 = desiredEncryption; /*0x1410ce01c*/
                }
                v56 = v55 & 0x7F; /*0x1410ce023*/
                desiredEncryption = v56; /*0x1410ce026*/
                if ( v56 == NoCrypto ) /*0x1410ce02c*/
                {
                  if ( DFLog::SessionCrypto != 0 ) /*0x1410ce037*/
                    FLog::FastLog( /*0x1410ce043*/
                      level: DFLog::SessionCrypto,
                      message: "[DFLog::SessionCrypto] RbxOpenRequest2 desired encryption is unset",
                      arg0: nullptr);
                  RakNet::RakPeer::sendRbxOpenError( /*0x1410ce059*/
                    this,
                    id: 0xBu,
                    guid: (const RakNet::RakNetGUID *)&v71.m256i_u64[2],
                    systemAddress,
                    rakNetSocket: v51);
                  v24 = 0; /*0x1410ce05e*/
                  goto LABEL_179; /*0x1410ce060*/
                }
                RBX::Security::SessionCrypto::setRakCryptoFormat(this: v31, value: v56); /*0x1410ce068*/
                RakNet::SystemAddress::ToStringN( /*0x1410ce084*/
                  this: systemAddress,
                  writePort: true,
                  dest: &addressBuffer[8],
                  size: 1025,
                  portDelineator: 124);
                if ( FLog::Network != 0 ) /*0x1410ce092*/
                  FLog::FastLogS( /*0x1410ce0a2*/
                    level: FLog::Network,
                    message: "[FLog::Network] Received RbxOpenRequest2 from %s",
                    sarg: &addressBuffer[8]);
                v45 = RakNet::RakPeer::sendRbxOpenReply2(this, rss: v53, systemAddress, udmuxAddress, rakNetSocket: v51); /*0x1410ce0bc*/
                goto LABEL_163; /*0x1410ce0bc*/
              }
LABEL_139:
              if ( DFLog::SessionCrypto != 0 ) /*0x1410cde50*/
                FLog::FastLog( /*0x1410cde5c*/
                  level: DFLog::SessionCrypto,
                  message: "[DFLog::SessionCrypto] RbxOpenRequest2 already connected",
                  arg0: nullptr);
              RakNet::RakPeer::sendRbxOpenError( /*0x1410cde79*/
                this,
                id: 0x12u,
                guid: (const RakNet::RakNetGUID *)&v71.m256i_u64[2],
                systemAddress,
                rakNetSocket);
              v24 = 1; /*0x1410cde7e*/
            }
            __unwind
            {
              RBX::Analytics::InfluxDb::Points::~Points(this: (RBX::Analytics::InfluxDb::Points *)&capBitReport.pointList._List); /*0xf1c0000000000034*/
            }
LABEL_179:
            RBX::Analytics::InfluxDb::Points::~Points(this: (RBX::Analytics::InfluxDb::Points *)&capBitReport.pointList._List); /*0x1410ce0cb*/
            goto LABEL_165; /*0x1410ce0cb*/
          }
          __unwind
          {
            RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&postBitStream.isJoinData); /*0xf1c0000000000070*/
          }
LABEL_189:
          goto LABEL_176; /*0xf1c000000000006c*/
        case VerifiedFirst:
          __eh34_enter_wind_state(1, 3); /*0xf1c0000000000118*/
          counterName._Mypair._Myval2._Myres = 15; /*0x1410cd5b9*/
          counterName._Mypair._Myval2._Mysize = 12; /*0x1410cd5c1*/
          strcpy(counterName._Mypair._Myval2._Bx._Buf, "Preauth-Pass"); /*0x1410cd5d1*/
          RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x1410cd5ed*/
          if ( counterName._Mypair._Myval2._Myres < 0x10 ) /*0x1410cd5fb*/
          {
            if ( __eh34_unwind(3) ) /*0xf1c00000000000fc*/
            {
unwind_state_3:
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c0000000000100*/
              __eh34_continue_unwinding(3, 1); /*0xf1c0000000000104*/
            }
LABEL_211:
            __eh34_exit_wind_state(3, 1); /*0xf1c0000000000108*/
            goto LABEL_50; /*0xf1c000000000010c*/
          }
          v22 = counterName._Mypair._Myval2._Bx._Ptr; /*0x1410cd604*/
          if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cd612*/
          {
            v22 = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cd61c*/
            if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x1410cd62b*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410cd631*/
          }
          break;
        case VerifiedSecond:
          counterName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410cd641*/
          counterName._Mypair._Myval2._Mysize = 0; /*0x1410cd645*/
          counterName._Mypair._Myval2._Myres = 15; /*0x1410cd649*/
          v23 = (char *)operator new(size: 0x20u); /*0x1410cd658*/
          __eh34_enter_wind_state(1, 3); /*0xf1c0000000000110*/
          counterName._Mypair._Myval2._Mysize = 16; /*0x1410cd65d*/
          counterName._Mypair._Myval2._Myres = 31; /*0x1410cd665*/
          strcpy(v23, "Preauth-Failover"); /*0x1410cd674*/
          counterName._Mypair._Myval2._Bx._Ptr = v23; /*0x1410cd67b*/
          RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x1410cd689*/
          if ( counterName._Mypair._Myval2._Myres < 0x10 ) /*0x1410cd697*/
            goto LABEL_211; /*0x1410cd697*/
          v22 = counterName._Mypair._Myval2._Bx._Ptr; /*0x1410cd69c*/
          if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cd6aa*/
          {
            v22 = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cd6b0*/
            if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x1410cd6bf*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410cd6c1*/
          }
          break;
        default:
          goto LABEL_50; /*0x1410cd63b*/
      }
      operator delete(ptr: v22); /*0x1410cd6c8*/
      goto LABEL_211; /*0xf1c00000000001a8*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v73.m256i_u64[2]); /*0xf1c0000000000014*/
    }
LABEL_174:
    if ( v16 != nullptr ) /*0x1410ce0f0*/
      std::_Ref_count_base::_Decref(this: v16); /*0x1410ce0f5*/
    return v24; /*0x1410ce0fd*/
  }
  if ( DFLog::SessionCrypto != 0 ) /*0x1410ce108*/
    FLog::FastLogFormatted( /*0x1410ce116*/
      level: DFLog::SessionCrypto,
      message: "[DFLog::SessionCrypto] RbxOpenRequest2 has invalid size %d.",
      length);
  return 0; /*0x1410ce11d*/
}

// Address: 0x1410ced80 | Name: ?reportAvoidPacketStatistics@RakPeer@RakNet@@QEAAXPEAURemoteSystemStruct@12@@Z
void __fastcall RakNet::RakPeer::reportAvoidPacketStatistics(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *remoteSystem)
{
  int v4; // eax
  rtc::webrtc_checks_impl::ToStringVal *p_value; // rax
  char v6; // bl
  char *Ptr; // rcx
  char *v8; // rcx
  int v9; // ebx
  char *v10; // rax
  char *v11; // rcx
  char *v12; // rcx
  std::string value; // [rsp+20h] [rbp-59h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v14; // [rsp+40h] [rbp-39h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+60h] [rbp-19h] BYREF
  char v16; // [rsp+E8h] [rbp+6Fh]

  RBX::Analytics::InfluxDb::Points::Points( /*0x1410cedb4*/
    this: &points,
    throttleHundredthsPercentage: -1,
    categoryType: kStandardType,
    priorityHundredthsPercentage: 0);
  __wind /*0xf1c000000000007c*/
  {
    v4 = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)((char *)&remoteSystem->reliabilityLayer.congestionManager + 4) /*0x1410cedc4*/
                                           + 192LL))(a1: *(RakNet::CCRakNetBase **)((char *)&remoteSystem->reliabilityLayer.congestionManager
                                                                                  + 4));
    RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "MTU", value: v4); /*0x1410cedd8*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410cedf0*/
      this: &points,
      name: "PaddedPacketsRatio",
      value: *(long double *)((char *)&remoteSystem->reliabilityLayer.paddedPacketsPercentage.averageValue + 4));
    if ( DFFlag::CLI50798ReportFix.value ) /*0x1410cedfc*/
    {
      if ( this->avoidedPacketSizesString._Mypair._Myval2._Mysize != 0 ) /*0x1410cee09*/
      {
        p_value = std::string::string( /*0x1410cee39*/
                    this: &v14,
                    __that: (const rtc::webrtc_checks_impl::ToStringVal *)&this->avoidedPacketSizesString);
        v6 = 2; /*0x1410cee3f*/
        __eh34_enter_wind_state(0, 1); /*0xf1c0000000000094*/
      }
      else
      {
        value._Mypair._Myval2._Bx._Ptr = (char *)46; /*0x1410cee0b*/
        value._Mypair._Myval2._Myres = 15; /*0x1410cee0f*/
        value._Mypair._Myval2._Mysize = 1; /*0x1410cee17*/
        p_value = (rtc::webrtc_checks_impl::ToStringVal *)&value; /*0x1410cee25*/
        __eh34_enter_wind_state(0, 1); /*0xf1c0000000000074*/
        v6 = 1; /*0x1410cee29*/
      }
      __wind /*0xf1c0000000000048*/
      {
        v16 = v6; /*0x1410cee44*/
        RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "AvoidedPayloads", value: &p_value->val); /*0x1410cee55*/
        if ( (v6 & 2) != 0 ) /*0x1410cee5e*/
        {
          v6 &= ~2u; /*0x1410cee60*/
          if ( v14.val._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cee6b*/
          {
            Ptr = v14.val._Mypair._Myval2._Bx._Ptr; /*0x1410cee70*/
            if ( v14.val._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cee7e*/
            {
              Ptr = *((char **)v14.val._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cee84*/
              if ( (unsigned __int64)(v14.val._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410cee93*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410cee95*/
            }
            operator delete(ptr: Ptr); /*0x1410cee9c*/
          }
          v14.val._Mypair._Myval2._Mysize = 0; /*0x1410ceea1*/
          v14.val._Mypair._Myval2._Myres = 15; /*0x1410ceea5*/
          v14.val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410ceead*/
        }
        if ( (v6 & 1) != 0 && value._Mypair._Myval2._Myres >= 0x10 ) /*0x1410ceebe*/
        {
          v8 = value._Mypair._Myval2._Bx._Ptr; /*0x1410ceec3*/
          if ( value._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410ceed1*/
          {
            v8 = *((char **)value._Mypair._Myval2._Bx._Ptr - 1); /*0x1410ceed7*/
            if ( (unsigned __int64)(value._Mypair._Myval2._Bx._Ptr - v8 - 8) > 0x1F ) /*0x1410ceee6*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410ceee8*/
          }
          operator delete(ptr: v8); /*0x1410ceeef*/
        }
      }
      __unwind
      {
        if ( (v16 & 2) != 0 ) /*0x1431ed234*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v14); /*0x1431ed241*/
      }
      if ( __eh34_unwind(1) ) /*0xf1c0000000000060*/
      {
        if ( (v16 & 1) != 0 ) /*0x1431ed204*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&value); /*0x1431ed211*/
        __eh34_continue_unwinding(1, 0); /*0xf1c0000000000068*/
      }
      __eh34_exit_wind_state(1, 0); /*0xf1c000000000006c*/
    }
    else
    {
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410cef08*/
        this: &points,
        name: "AvoidedPayloads",
        value: &this->avoidedPacketSizesString);
    }
    v9 = DFInt::CLI50798HundredthsPercentage; /*0x1410cef0d*/
    value._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410cef13*/
    value._Mypair._Myval2._Mysize = 0; /*0x1410cef17*/
    value._Mypair._Myval2._Myres = 15; /*0x1410cef1b*/
    v10 = (char *)operator new(size: 0x20u); /*0x1410cef2c*/
    value._Mypair._Myval2._Mysize = 26; /*0x1410cef31*/
    value._Mypair._Myval2._Myres = 31; /*0x1410cef39*/
    strcpy(v10, "AvoidPayloadSizeStatistics"); /*0x1410cef48*/
    value._Mypair._Myval2._Bx._Ptr = v10; /*0x1410cef67*/
    __eh34_enter_wind_state(0, 3); /*0xf1c0000000000040*/
    RBX::Analytics::InfluxDb::Points::report( /*0x1410cef79*/
      this: &points,
      resource: &value,
      throttleHundredthsPercentage: v9,
      blocking: false);
    if ( __eh34_unwind(3) ) /*0xf1c000000000002c*/
    {
unwind_state_3:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&value); /*0xf1c0000000000030*/
      __eh34_continue_unwinding(3, 0); /*0xf1c0000000000034*/
    }
    __eh34_exit_wind_state(3, 0); /*0xf1c0000000000038*/
    if ( value._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cef87*/
    {
      v11 = value._Mypair._Myval2._Bx._Ptr; /*0x1410cef8c*/
      if ( value._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cef9a*/
      {
        v11 = *((char **)value._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cefa0*/
        if ( (unsigned __int64)(value._Mypair._Myval2._Bx._Ptr - v11 - 8) > 0x1F ) /*0x1410cefaf*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410cefb1*/
      }
      operator delete(ptr: v11); /*0x1410cefb8*/
    }
    if ( this->reducedMTU ) /*0x1410cefbd*/
    {
      __eh34_enter_wind_state(0, 3); /*0xf1c0000000000024*/
      value._Mypair._Myval2._Myres = 15; /*0x1410cefc6*/
      value._Mypair._Myval2._Mysize = 10; /*0x1410cefce*/
      strcpy(value._Mypair._Myval2._Bx._Buf, "ReducedMTU"); /*0x1410cefde*/
      RBX::Analytics::EphemeralCounter::reportCounter(counterName: &value, amount: 1, blocking: false); /*0x1410ceffd*/
      if ( value._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cf00b*/
      {
        v12 = value._Mypair._Myval2._Bx._Ptr; /*0x1410cf010*/
        if ( value._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cf01e*/
        {
          v12 = *((char **)value._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cf024*/
          if ( (unsigned __int64)(value._Mypair._Myval2._Bx._Ptr - v12 - 8) > 0x1F ) /*0x1410cf033*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410cf035*/
        }
        operator delete(ptr: v12); /*0x1410cf03c*/
      }
      if ( __eh34_unwind(3) ) /*0xf1c0000000000088*/
        goto unwind_state_3; /*0xf1c0000000000088*/
      __eh34_exit_wind_state(3, 0); /*0xf1c000000000008c*/
    }
  }
  __unwind
  {
    RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c000000000001c*/
  }
  RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0x1410cf046*/
}

// Address: 0x1410cf9e0 | Name: ?reportQueuedByteStats@RakPeer@RakNet@@AEAAXXZ
void __fastcall RakNet::RakPeer::reportQueuedByteStats(RakNet::RakPeer *this)
{
  _WORD *v2; // rax
  char *Ptr; // rcx
  std::string resource; // [rsp+20h] [rbp-98h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+40h] [rbp-78h] BYREF

  RBX::Analytics::InfluxDb::Points::Points( /*0x1410cf9fb*/
    this: &points,
    throttleHundredthsPercentage: -1,
    categoryType: kStandardType,
    priorityHundredthsPercentage: 0);
  __wind /*0xf1c0000000000028*/
  {
    if ( DFFlag::CLI56775.value ) /*0x1410cfa08*/
    {
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410cfa1a*/
        this: &points,
        name: "MaxBytesReturnQueue",
        value: this->bytesInQueueStats.maxBytesInReturnQueueSinglePeer);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410cfa2f*/
        this: &points,
        name: "PeersExceededReturnQueue",
        value: this->bytesInQueueStats.peersExceededByteCapInReturnQueue);
    }
    if ( DFFlag::CLI57133.value ) /*0x1410cfa3b*/
    {
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410cfa4d*/
        this: &points,
        name: "MaxBytesIncompleteDatagrams",
        value: this->bytesInQueueStats.maxBytesIncompleteDatagrams);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410cfa62*/
        this: &points,
        name: "PeersExceededIncompleteDatagrams",
        value: this->bytesInQueueStats.peersExceededByteCapIncompleteDatagrams);
    }
    if ( boost::multi_index::detail::auto_space<unsigned __int64,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>::data(this: (ShareModalController *)&points) != nullptr ) /*0x1410cfa74*/
    {
      v2 = operator new(size: 0x20u); /*0x1410cfa96*/
      resource._Mypair._Myval2._Mysize = 25; /*0x1410cfa9b*/
      resource._Mypair._Myval2._Myres = 31; /*0x1410cfaa4*/
      qmemcpy(v2, "RakNetRxBytesInQueueStat", 24); /*0x1410cfab4*/
      v2[12] = (unsigned __int8)aRaknetrxbytesi[24]; /*0x1410cfacb*/
      resource._Mypair._Myval2._Bx._Ptr = (char *)v2; /*0x1410cfad2*/
      __wind /*0xf1c000000000001c*/
      {
        RBX::Analytics::InfluxDb::Points::report( /*0x1410cfaea*/
          this: &points,
          &resource,
          throttleHundredthsPercentage: 10000,
          blocking: false);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000014*/
      }
      if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x1410cfaf9*/
      {
        Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x1410cfafe*/
        if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410cfb0d*/
        {
          Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x1410cfb13*/
          if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410cfb22*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410cfb24*/
        }
        operator delete(ptr: Ptr); /*0x1410cfb2b*/
      }
    }
    RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0x1410cfb36*/
  }
  __unwind
  {
    RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c0000000000008*/
  }
}

// Address: 0x1410cfb50 | Name: ?resolveSocketFamily@RakPeer@RakNet@@SAHPEAUSocketDescriptor@2@PEBD@Z
INT __fastcall RakNet::RakPeer::resolveSocketFamily(RakNet::SocketDescriptor *socketDescriptor, const char *address)
{
  INT result; // eax
  addrinfo *v4; // rcx
  INT v5; // ebx
  addrinfo hints; // [rsp+20h] [rbp-38h] BYREF
  addrinfo *res; // [rsp+60h] [rbp+8h] BYREF

  *(_QWORD *)&hints.ai_flags = 3072; /*0x1410cfb5d*/
  socketDescriptor->socketFamily = 2; /*0x1410cfb70*/
  hints.ai_socktype = 2; /*0x1410cfb7c*/
  res = nullptr; /*0x1410cfb85*/
  memset(&hints.ai_protocol, 0, 36); /*0x1410cfb96*/
  result = getaddrinfo(pNodeName: address, pServiceName: nullptr, pHints: &hints, ppResult: &res); /*0x1410cfba2*/
  v4 = res; /*0x1410cfba8*/
  v5 = result; /*0x1410cfbad*/
  if ( result == 0 ) /*0x1410cfbb1*/
  {
    if ( res == nullptr ) /*0x1410cfbb6*/
      return result; /*0x1410cfbb6*/
    if ( res->ai_family == 23 ) /*0x1410cfbbc*/
      socketDescriptor->socketFamily = 23; /*0x1410cfbc3*/
  }
  if ( v4 != nullptr ) /*0x1410cfbca*/
    freeaddrinfo(pAddrInfo: v4); /*0x1410cfbcc*/
  return v5; /*0x1410cfbd4*/
}

// Address: 0x1410cfbe0 | Name: ?sendApplicationConnectionRequest@RakPeer@RakNet@@IEAAXPEBURequestedConnectionStruct@12@AEBUSystemAddress@2@_K@Z
void __fastcall RakNet::RakPeer::sendApplicationConnectionRequest(
        RakNet::RakPeer *this,
        const RakNet::RakPeer::RequestedConnectionStruct *rcs,
        const RakNet::SystemAddress *systemAddress,
        unsigned __int64 timeRead)
{
  RakNet::RakPeer_vtbl *v8; // rax
  unsigned __int8 *v9; // rdi
  unsigned __int8 *p_inByteArray; // rdx
  unsigned int RemoteSystemIndex; // eax
  __int64 v12; // rdx
  RakNet::RakPeer::RemoteSystemStruct *v13; // rax
  unsigned __int8 *p_inOutByteArray; // rdx
  RakNet::RakNetGUID v15; // [rsp+60h] [rbp-A0h] BYREF
  RakNet::SystemAddress v16; // [rsp+70h] [rbp-90h] BYREF
  RakNet::SystemAddress sa; // [rsp+90h] [rbp-70h] BYREF
  RakNet::BitStream bsOut; // [rsp+B0h] [rbp-50h] BYREF
  unsigned __int64 inByteArray; // [rsp+210h] [rbp+110h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+218h] [rbp+118h] BYREF

  if ( DFLog::RakNetConnectTrace != 0 )
    FLog::FastLog(
      level: DFLog::RakNetConnectTrace,
      message: "[DFLog::RakNetConnectTrace] RakNet: Send App Connection Request",
      arg0: nullptr);
  RakNet::BitStream::BitStream(this: &bsOut); /*0x1410cfc25*/
  __wind /*0xf1c0000000000010*/
  {
    LOBYTE(inByteArray) = 9; /*0x1410cfc2b*/
    RakNet::BitStream::WriteBits( /*0x1410cfc46*/
      this: &bsOut,
      (unsigned __int8 *)&inByteArray,
      numberOfBitsToWrite: 8u,
      rightAlignedBits: true);
    v8 = this->__vftable; /*0x1410cfc4b*/
    v15 = *(RakNet::RakNetGUID *)&RakNet::UNASSIGNED_SYSTEM_ADDRESS_30.address.addr6.sin6_family; /*0x1410cfc55*/
    *(_OWORD *)&v16.address.addr6.sin6_family = *((_OWORD *)&RakNet::UNASSIGNED_SYSTEM_ADDRESS_30.address.addr4 + 1); /*0x1410cfc61*/
    v9 = (unsigned __int8 *)v8->GetGuidFromSystemAddress(this, a2: (const RakNet::SystemAddress *)&v15); /*0x1410cfc74*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410cfc77*/
    {
      p_inByteArray = v9; /*0x1410cfc9e*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410cfc90*/
        inByteArray: v9,
        inOutByteArray: (unsigned __int8 *)&inByteArray,
        length: 8u);
      p_inByteArray = (unsigned __int8 *)&inByteArray; /*0x1410cfc95*/
    }
    RakNet::BitStream::WriteBits( /*0x1410cfcae*/
      this: &bsOut,
      inByteArray: p_inByteArray,
      numberOfBitsToWrite: 0x40u,
      rightAlignedBits: true);
    sa = *systemAddress; /*0x1410cfcb7*/
    if ( RakNet::SystemAddress::operator==(this: &sa, right: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_30) != 0 /*0x1410cfd01*/
      || (RemoteSystemIndex = RakNet::RakPeer::GetRemoteSystemIndex(this, &sa)) == -1
      || !*(&this->remoteSystemList->isActive._Storage._Value + (v12 = RemoteSystemIndex)) )
    {
      v13 = nullptr; /*0x1410cfd0f*/
    }
    else
    {
      v13 = &this->remoteSystemList[v12]; /*0x1410cfd0a*/
    }
    inByteArray = RakNet::GetTime(isNetworkSynced: v13 == nullptr); /*0x1410cfd1c*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410cfd23*/
    {
      p_inOutByteArray = (unsigned __int8 *)&inByteArray; /*0x1410cfd4e*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 8u); /*0x1410cfd40*/
      p_inOutByteArray = &inOutByteArray; /*0x1410cfd45*/
    }
    RakNet::BitStream::WriteBits( /*0x1410cfd62*/
      this: &bsOut,
      inByteArray: p_inOutByteArray,
      numberOfBitsToWrite: 0x40u,
      rightAlignedBits: true);
    LOBYTE(inByteArray) = 0; /*0x1410cfd67*/
    RakNet::BitStream::WriteBits( /*0x1410cfd82*/
      this: &bsOut,
      (unsigned __int8 *)&inByteArray,
      numberOfBitsToWrite: 8u,
      rightAlignedBits: true);
    if ( rcs->outgoingPasswordLength != 0 ) /*0x1410cfd90*/
      RakNet::BitStream::Write( /*0x1410cfd9d*/
        this: &bsOut,
        inputByteArray: rcs->outgoingPassword,
        numberOfBytes: rcs->outgoingPasswordLength);
    RakNet::RakNetGUID::RakNetGUID(this: &v15); /*0x1410cfda7*/
    RakNet::SystemAddress::SystemAddress(this: &v16); /*0x1410cfdb1*/
    v15 = RakNet::UNASSIGNED_RAKNET_GUID_30; /*0x1410cfdbd*/
    RakNet::SystemAddress::operator=(this: &v16, input: systemAddress); /*0x1410cfdd6*/
    RakNet::RakPeer::SendImmediate( /*0x1410cfe1c*/
      this,
      data: (char *)bsOut.data,
      numberOfBitsToSend: bsOut.numberOfBitsUsed,
      priority: IMMEDIATE_PRIORITY,
      reliability: RELIABLE,
      orderingChannel: 0,
      systemIdentifier: (RBX::json::ArrayIterator *)&v15,
      broadcast: false,
      useCallerDataAllocation: false,
      currentTime: timeRead,
      receipt: 0,
      isJoinData: false);
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &bsOut); /*0xf1c0000000000008*/
  }
  RakNet::BitStream::~BitStream(this: &bsOut); /*0x1410cfe26*/
}

// Address: 0x1410cfe50 | Name: ?sendRbxOpenError@RakPeer@RakNet@@IEAAXEAEBURakNetGUID@2@AEBUSystemAddress@2@AEAV?$shared_ptr@URakNetSocket@RakNet@@@std@@@Z
void __fastcall RakNet::RakPeer::sendRbxOpenError(
        RakNet::RakPeer *this,
        unsigned __int8 id,
        RakNet::RakNetGUID *guid,
        const RakNet::SystemAddress *systemAddress,
        std::shared_ptr<RakNet::RakNetSocket> *rakNetSocket)
{
  unsigned __int8 *p_inOutByteArray; // rdx
  unsigned __int8 *data; // rdx
  std::shared_ptr<RakNet::RakNetSocket> *v10; // rax
  unsigned int v11; // r8d
  std::_Ref_count_base *Rep; // rcx
  std::shared_ptr<RakNet::RakNetSocket> v13; // [rsp+60h] [rbp-168h] BYREF
  RakNet::SystemAddress udmuxAddress; // [rsp+70h] [rbp-158h] BYREF
  RakNet::BitStream bsOut; // [rsp+90h] [rbp-138h] BYREF
  unsigned __int8 inByteArray; // [rsp+1D8h] [rbp+10h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+1E0h] [rbp+18h] BYREF

  inByteArray = id; /*0x1410cfe5a*/
  RakNet::BitStream::BitStream(this: &bsOut, initialBytesToAllocate: 0xC8u); /*0x1410cfe7c*/
  __wind /*0xf1c0000000000010*/
  {
    RakNet::BitStream::WriteBits(this: &bsOut, &inByteArray, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410cfe9b*/
    RakNet::BitStream::WriteAlignedBytes( /*0x1410cfeb5*/
      this: &bsOut,
      inByteArray: OFFLINE_MESSAGE_DATA_ID,
      numberOfBytesToWrite: 0x10u);
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410cfeba*/
    {
      p_inOutByteArray = (unsigned __int8 *)guid; /*0x1410cfee3*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes(inByteArray: (unsigned __int8 *)guid, &inOutByteArray, length: 8u); /*0x1410cfed4*/
      p_inOutByteArray = &inOutByteArray; /*0x1410cfed9*/
    }
    RakNet::BitStream::WriteBits( /*0x1410cfef7*/
      this: &bsOut,
      inByteArray: p_inOutByteArray,
      numberOfBitsToWrite: 0x40u,
      rightAlignedBits: true);
    RakNet::SystemAddress::SystemAddress(this: &udmuxAddress, str: nullptr); /*0x1410cff03*/
    data = bsOut.data; /*0x1410cff10*/
    v10 = rakNetSocket; /*0x1410cff18*/
    v11 = (bsOut.numberOfBitsUsed + 7) >> 3; /*0x1410cff24*/
    if ( FFlag::CLI52064Experiment2.value ) /*0x1410cff2f*/
    {
      v13 = 0; /*0x1410cff34*/
      Rep = rakNetSocket->_Rep; /*0x1410cff3a*/
      if ( Rep != nullptr ) /*0x1410cff41*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410cff43*/
        Rep = v10->_Rep; /*0x1410cff47*/
      }
      v13._Ptr = v10->_Ptr; /*0x1410cff4e*/
      v13._Rep = Rep; /*0x1410cff53*/
      RakNet::SocketLayer::SendToOrDelay( /*0x1410cff93*/
        socket: &v13,
        (const char *)data,
        length: v11,
        dstAddress: systemAddress,
        srcAddress: &udmuxAddress,
        raknetMetaDataEncrypted: false,
        rakPeer: this,
        reliabilityLayer: nullptr,
        now: 0,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
        line: 7611);
    }
    else
    {
      RakNet::SocketLayer::SendTo( /*0x1410cffc6*/
        s: rakNetSocket->_Ptr->s,
        data: (const char *)bsOut.data,
        length: v11,
        dstAddress: systemAddress,
        srcAddress: &udmuxAddress,
        raknetMetaDataEncrypted: false,
        file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
        line: 7616);
    }
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &bsOut); /*0xf1c0000000000008*/
  }
  RakNet::BitStream::~BitStream(this: &bsOut); /*0x1410cffd4*/
}

// Address: 0x1410cfff0 | Name: ?sendRbxOpenReply1@RakPeer@RakNet@@IEAAX_KAEBUSystemAddress@2@1AEAV?$shared_ptr@URakNetSocket@RakNet@@@std@@@Z
void __fastcall RakNet::RakPeer::sendRbxOpenReply1(
        RakNet::RakPeer *this,
        unsigned __int64 mtu,
        const RakNet::SystemAddress *systemAddress,
        const RakNet::SystemAddress *udmuxAddress,
        std::shared_ptr<RakNet::RakNetSocket> *rakNetSocket)
{
  __int16 v7; // bx
  RakNet::RakPeer_vtbl *v9; // rax
  unsigned __int8 *v10; // rsi
  unsigned __int8 *v11; // rdx
  unsigned __int8 *v12; // rdx
  unsigned __int8 *data; // rdx
  std::shared_ptr<RakNet::RakNetSocket> *v14; // rax
  unsigned int v15; // r8d
  std::_Ref_count_base *Rep; // rcx
  int v17; // eax
  unsigned __int8 v18[4]; // [rsp+60h] [rbp-A0h] BYREF
  unsigned __int8 v19[4]; // [rsp+64h] [rbp-9Ch] BYREF
  std::shared_ptr<RakNet::RakNetSocket> v20; // [rsp+68h] [rbp-98h] BYREF
  unsigned __int8 inOutByteArray[8]; // [rsp+78h] [rbp-88h] BYREF
  RakNet::SystemAddress v22; // [rsp+80h] [rbp-80h] BYREF
  RakNet::BitStream bsOut; // [rsp+A0h] [rbp-60h] BYREF
  unsigned __int8 inByteArray; // [rsp+200h] [rbp+100h] BYREF
  unsigned __int8 v25; // [rsp+208h] [rbp+108h] BYREF

  v7 = mtu; /*0x1410d0011*/
  RakNet::BitStream::BitStream(this: &bsOut, initialBytesToAllocate: 0x1Cu); /*0x1410d0020*/
  inByteArray = 126; /*0x1410d0026*/
  __wind /*0xf1c0000000000010*/
  {
    RakNet::BitStream::WriteBits(this: &bsOut, &inByteArray, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d0041*/
    RakNet::BitStream::WriteAlignedBytes( /*0x1410d0057*/
      this: &bsOut,
      inByteArray: OFFLINE_MESSAGE_DATA_ID,
      numberOfBytesToWrite: 0x10u);
    v9 = this->__vftable; /*0x1410d005c*/
    v22 = RakNet::UNASSIGNED_SYSTEM_ADDRESS_30; /*0x1410d0066*/
    v10 = (unsigned __int8 *)v9->GetGuidFromSystemAddress(this, a2: &v22); /*0x1410d0082*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d0085*/
    {
      v11 = v10; /*0x1410d00a8*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes(inByteArray: v10, inOutByteArray, length: 8u); /*0x1410d009c*/
      v11 = inOutByteArray; /*0x1410d00a1*/
    }
    RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: v11, numberOfBitsToWrite: 0x40u, rightAlignedBits: true); /*0x1410d00b8*/
    v25 = 0; /*0x1410d00bd*/
    RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: &v25, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d00d8*/
    *(_WORD *)v18 = v7 + 40; /*0x1410d00e1*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d00e6*/
    {
      v12 = v18; /*0x1410d010b*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes(inByteArray: v18, inOutByteArray: v19, length: 2u); /*0x1410d00ff*/
      v12 = v19; /*0x1410d0104*/
    }
    RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: v12, numberOfBitsToWrite: 0x10u, rightAlignedBits: true); /*0x1410d011d*/
    data = bsOut.data; /*0x1410d0126*/
    v14 = rakNetSocket; /*0x1410d012a*/
    v15 = (bsOut.numberOfBitsUsed + 7) >> 3; /*0x1410d0135*/
    if ( FFlag::CLI52064Experiment2.value ) /*0x1410d0140*/
    {
      v20 = 0; /*0x1410d0145*/
      Rep = rakNetSocket->_Rep; /*0x1410d014b*/
      if ( Rep != nullptr ) /*0x1410d0152*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410d0154*/
        Rep = v14->_Rep; /*0x1410d0158*/
      }
      v20._Ptr = v14->_Ptr; /*0x1410d015f*/
      v20._Rep = Rep; /*0x1410d0164*/
      v17 = RakNet::SocketLayer::SendToOrDelay( /*0x1410d019f*/
              socket: &v20,
              (const char *)data,
              length: v15,
              dstAddress: systemAddress,
              srcAddress: udmuxAddress,
              raknetMetaDataEncrypted: false,
              rakPeer: this,
              reliabilityLayer: nullptr,
              now: 0,
              file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
              line: 6904);
    }
    else
    {
      v17 = RakNet::SocketLayer::SendTo( /*0x1410d01cd*/
              s: rakNetSocket->_Ptr->s,
              data: (const char *)bsOut.data,
              length: v15,
              dstAddress: systemAddress,
              srcAddress: udmuxAddress,
              raknetMetaDataEncrypted: false,
              file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
              line: 6909);
    }
    if ( v17 == 0 ) /*0x1410d01d4*/
    {
      rtc::CriticalSection::Enter(lpCriticalSection: &this->connectionRequestsStats.mx.criticalSection); /*0x1410d01dd*/
      ++this->connectionRequestsStats.counters[2]; /*0x1410d01e2*/
      RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->connectionRequestsStats.mx.criticalSection); /*0x1410d01ef*/
    }
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &bsOut); /*0xf1c0000000000008*/
  }
  RakNet::BitStream::~BitStream(this: &bsOut); /*0x1410d01f9*/
}

// Address: 0x1410d0220 | Name: ?sendRbxOpenReply2@RakPeer@RakNet@@IEAA_NPEAURemoteSystemStruct@12@AEBUSystemAddress@2@1AEAV?$shared_ptr@URakNetSocket@RakNet@@@std@@@Z
char __fastcall RakNet::RakPeer::sendRbxOpenReply2(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RemoteSystemStruct *rss,
        const RakNet::SystemAddress *systemAddress,
        const RakNet::SystemAddress *udmuxAddress,
        std::shared_ptr<RakNet::RakNetSocket> *rakNetSocket)
{
  unsigned int v10; // edx
  unsigned __int8 v11; // al
  RBX::Security::RakPeerCrypto *v12; // r15
  unsigned __int8 *p_ciphertextLen; // rdx
  unsigned __int8 *v14; // rdx
  RakNet::RakPeer_vtbl *v15; // rax
  unsigned __int8 *v16; // rbx
  unsigned __int8 *v17; // rdx
  unsigned __int8 *p_mtu16; // rdx
  const char *v19; // rdi
  const char *v20; // rbx
  bool v21; // al
  const char *v22; // r8
  unsigned __int64 v23; // rbx
  unsigned __int8 *v24; // rdx
  unsigned __int8 v25; // cl
  const char *v26; // rdx
  unsigned __int8 *data; // rdx
  std::shared_ptr<RakNet::RakNetSocket> *v28; // rax
  unsigned int v29; // r8d
  std::_Ref_count_base *Rep; // rcx
  int v31; // eax
  char v32; // bl
  unsigned __int8 version[4]; // [rsp+60h] [rbp-A0h] BYREF
  unsigned __int16 ciphertextLen; // [rsp+64h] [rbp-9Ch] BYREF
  unsigned __int8 inByteArray; // [rsp+68h] [rbp-98h] BYREF
  unsigned __int8 selectedEncryption; // [rsp+69h] [rbp-97h] BYREF
  unsigned __int8 tokenSize[2]; // [rsp+6Ah] [rbp-96h] BYREF
  unsigned __int16 mtu16; // [rsp+6Ch] [rbp-94h] BYREF
  unsigned __int8 inOutByteArray[4]; // [rsp+70h] [rbp-90h] BYREF
  unsigned __int8 v40[4]; // [rsp+74h] [rbp-8Ch] BYREF
  unsigned __int8 v41[8]; // [rsp+78h] [rbp-88h] BYREF
  unsigned __int8 v42[8]; // [rsp+80h] [rbp-80h] BYREF
  std::shared_ptr<RakNet::RakNetSocket> v43; // [rsp+88h] [rbp-78h] BYREF
  unsigned __int8 v44[8]; // [rsp+98h] [rbp-68h] BYREF
  unsigned __int8 v45[8]; // [rsp+A0h] [rbp-60h] BYREF
  RBX::ArrayView<unsigned char> publicEphemeralKey; // [rsp+A8h] [rbp-58h] BYREF
  unsigned __int8 token[24]; // [rsp+B8h] [rbp-48h] BYREF
  RakNet::BitStream bsOut; // [rsp+D0h] [rbp-30h] BYREF
  RakNet::SystemAddress v49; // [rsp+200h] [rbp+100h] BYREF
  unsigned __int8 aadLen; // [rsp+258h] [rbp+158h] BYREF

  if ( *(RBX::Security::RakPeerCrypto **)((char *)&rss->reliabilityLayer.rbxSessionCrypto._Ptr + 4) == nullptr ) /*0x1410d025b*/
  {
    if ( DFLog::SessionCrypto != 0 ) /*0x1410d0266*/
      FLog::FastLog( /*0x1410d0272*/
        level: DFLog::SessionCrypto,
        message: "[DFLog::SessionCrypto] RbxOpenReply2 no session crypto",
        arg0: nullptr);
    return 0; /*0x1410d0279*/
  }
  v10 = 952; /*0x1410d027e*/
  if ( FFlag::RuppTokEn4.value ) /*0x1410d028f*/
    v10 = 1088; /*0x1410d028f*/
  RakNet::BitStream::BitStream(this: &bsOut, initialBytesToAllocate: v10); /*0x1410d0296*/
  __wind /*0xf1c0000000000010*/
  {
    v11 = FFlag::RuppTokEn4.value && this->getServerReceiveRuppToken(this) && rss->tokenOptions._Has_value; /*0x1410d02be*/
    version[0] = v11; /*0x1410d02c4*/
    aadLen = 0; /*0x1410d02c8*/
    ciphertextLen = 0; /*0x1410d02d1*/
    v12 = *(RBX::Security::RakPeerCrypto **)((char *)&rss->reliabilityLayer.rbxSessionCrypto._Ptr + 4); /*0x1410d02d6*/
    RBX::Security::RakPeerCrypto::getPublicKey(this: v12, result: &publicEphemeralKey); /*0x1410d02e4*/
    if ( publicEphemeralKey.buffer != nullptr && publicEphemeralKey.length != 0 ) /*0x1410d02f7*/
    {
      selectedEncryption = RBX::Security::SessionCrypto::getRakCryptoFormat(this: v12); /*0x1410d0305*/
      inByteArray = 125; /*0x1410d0309*/
      RakNet::BitStream::WriteBits(this: &bsOut, &inByteArray, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d031e*/
      RakNet::BitStream::WriteAlignedBytes( /*0x1410d0332*/
        this: &bsOut,
        inByteArray: OFFLINE_MESSAGE_DATA_ID,
        numberOfBytesToWrite: 0x10u);
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: version, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d0347*/
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: &aadLen, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d035e*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d0363*/
      {
        p_ciphertextLen = (unsigned __int8 *)&ciphertextLen; /*0x1410d0386*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410d037a*/
          inByteArray: (unsigned __int8 *)&ciphertextLen,
          inOutByteArray,
          length: 2u);
        p_ciphertextLen = inOutByteArray; /*0x1410d037f*/
      }
      RakNet::BitStream::WriteBits( /*0x1410d0398*/
        this: &bsOut,
        inByteArray: p_ciphertextLen,
        numberOfBitsToWrite: 0x10u,
        rightAlignedBits: true);
      aadLen = bsOut.numberOfBitsUsed >> 3; /*0x1410d03a3*/
      RakNet::BitStream::WriteAlignedBytes( /*0x1410d03b7*/
        this: &bsOut,
        inByteArray: publicEphemeralKey.buffer,
        numberOfBytesToWrite: 0x20u);
      *(_QWORD *)v42 = rss->remoteCommonCapabilities; /*0x1410d03c3*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d03c7*/
      {
        v14 = v42; /*0x1410d03e9*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes(inByteArray: v42, inOutByteArray: v44, length: 8u); /*0x1410d03de*/
        v14 = v44; /*0x1410d03e3*/
      }
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: v14, numberOfBitsToWrite: 0x40u, rightAlignedBits: true); /*0x1410d03fa*/
      v15 = this->__vftable; /*0x1410d03ff*/
      v49 = RakNet::UNASSIGNED_SYSTEM_ADDRESS_30; /*0x1410d0409*/
      v16 = (unsigned __int8 *)v15->GetGuidFromSystemAddress(this, a2: &v49); /*0x1410d042e*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d0431*/
      {
        v17 = v16; /*0x1410d0452*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes(inByteArray: v16, inOutByteArray: v45, length: 8u); /*0x1410d0447*/
        v17 = v45; /*0x1410d044c*/
      }
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: v17, numberOfBitsToWrite: 0x40u, rightAlignedBits: true); /*0x1410d0462*/
      mtu16 = rss->MTUSize; /*0x1410d046e*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d0473*/
      {
        p_mtu16 = (unsigned __int8 *)&mtu16; /*0x1410d0498*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410d048c*/
          inByteArray: (unsigned __int8 *)&mtu16,
          inOutByteArray: v40,
          length: 2u);
        p_mtu16 = v40; /*0x1410d0491*/
      }
      RakNet::BitStream::WriteBits( /*0x1410d04aa*/
        this: &bsOut,
        inByteArray: p_mtu16,
        numberOfBitsToWrite: 0x10u,
        rightAlignedBits: true);
      RakNet::BitStream::WriteBits( /*0x1410d04c1*/
        this: &bsOut,
        inByteArray: &selectedEncryption,
        numberOfBitsToWrite: 8u,
        rightAlignedBits: true);
      RakNet::BitStream::Write<RakNet::SystemAddress>(this: &bsOut, inTemplateVar: &rss->systemAddress); /*0x1410d04ce*/
      if ( FFlag::RuppTokEn4.value && version[0] != 0 ) /*0x1410d04e1*/
      {
        tokenSize[0] = 16; /*0x1410d04e3*/
        RakNet::BitStream::WriteBits( /*0x1410d04fa*/
          this: &bsOut,
          inByteArray: tokenSize,
          numberOfBitsToWrite: 8u,
          rightAlignedBits: true);
        *(_OWORD *)token = 0; /*0x1410d0502*/
        this->generateUdmuxToken( /*0x1410d0524*/
          this,
          a2: token,
          a3: systemAddress,
          a4: rss->tokenOptions._Value,
          a5: nullptr,
          a6: false);
        RakNet::BitStream::WriteAlignedBytes(this: &bsOut, inByteArray: token, numberOfBytesToWrite: 0x10u); /*0x1410d0538*/
      }
      if ( DFLog::RuppTokenLog != 0 ) /*0x1410d0544*/
      {
        v19 = "not replied."; /*0x1410d054d*/
        if ( version[0] != 0 ) /*0x1410d0559*/
          v19 = "replied."; /*0x1410d0559*/
        v20 = "not received"; /*0x1410d0564*/
        if ( rss->tokenOptions._Has_value ) /*0x1410d056b*/
          v20 = "received"; /*0x1410d0572*/
        v21 = this->getServerReceiveRuppToken(this); /*0x1410d057c*/
        v22 = "not expected"; /*0x1410d0589*/
        if ( v21 ) /*0x1410d0592*/
          v22 = "expected"; /*0x1410d0592*/
        FLog::FastLogFormatted( /*0x1410d05ac*/
          level: DFLog::RuppTokenLog,
          message: "[DFLog::RuppTokenLog] Token %s.  RbxOpenRequest2 token %s.  RbxOpenReply2 token %s",
          v22,
          v20,
          v19);
      }
      ciphertextLen = ((unsigned __int64)bsOut.numberOfBitsUsed >> 3) - aadLen; /*0x1410d05c4*/
      RakNet::BitStream::WriteAlignedBytes(this: &bsOut, inByteArray: kZeroPacket, numberOfBytesToWrite: 0x1Cu); /*0x1410d05da*/
      v23 = (unsigned __int64)bsOut.numberOfBitsUsed >> 3; /*0x1410d05e2*/
      RakNet::BitStream::SetWriteOffset(this: &bsOut, offset: 0x90u, eraseDataToCurrentOffset: false); /*0x1410d05f2*/
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: &aadLen, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d060b*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d0610*/
      {
        v24 = (unsigned __int8 *)&ciphertextLen; /*0x1410d0635*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410d0629*/
          inByteArray: (unsigned __int8 *)&ciphertextLen,
          inOutByteArray: v41,
          length: 2u);
        v24 = v41; /*0x1410d062e*/
      }
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: v24, numberOfBitsToWrite: 0x10u, rightAlignedBits: true); /*0x1410d0647*/
      RakNet::BitStream::SetWriteOffset(this: &bsOut, offset: 8 * v23, eraseDataToCurrentOffset: false); /*0x1410d065a*/
      if ( RBX::Security::RakPeerCrypto::earlyEncryptData(this: v12, bitstream: &bsOut, aadSize: aadLen, ruppLength: 0) ) /*0x1410d0671*/
      {
        data = bsOut.data; /*0x1410d0699*/
        v28 = rakNetSocket; /*0x1410d069d*/
        v29 = (bsOut.numberOfBitsUsed + 7) >> 3; /*0x1410d06a8*/
        if ( FFlag::CLI52064Experiment2.value ) /*0x1410d06b3*/
        {
          v43 = 0; /*0x1410d06b8*/
          Rep = rakNetSocket->_Rep; /*0x1410d06bd*/
          if ( Rep != nullptr ) /*0x1410d06c4*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410d06c6*/
            Rep = v28->_Rep; /*0x1410d06ca*/
          }
          v43._Ptr = v28->_Ptr; /*0x1410d06d1*/
          v43._Rep = Rep; /*0x1410d06d5*/
          v31 = RakNet::SocketLayer::SendToOrDelay( /*0x1410d070d*/
                  socket: &v43,
                  (const char *)data,
                  length: v29,
                  dstAddress: systemAddress,
                  srcAddress: udmuxAddress,
                  raknetMetaDataEncrypted: false,
                  rakPeer: this,
                  reliabilityLayer: nullptr,
                  now: 0,
                  file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                  line: 7426);
        }
        else
        {
          v31 = RakNet::SocketLayer::SendTo( /*0x1410d073b*/
                  s: rakNetSocket->_Ptr->s,
                  data: (const char *)bsOut.data,
                  length: v29,
                  dstAddress: systemAddress,
                  srcAddress: udmuxAddress,
                  raknetMetaDataEncrypted: false,
                  file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                  line: 7431);
        }
        if ( v31 == 0 ) /*0x1410d0742*/
          RakNet::RakPeer::ConnectionRequestsStats::Increment(this: &this->connectionRequestsStats, type: 6u); /*0x1410d074e*/
        v32 = 1; /*0x1410d0753*/
        goto LABEL_57; /*0x1410d0755*/
      }
      v25 = DFLog::SessionCrypto; /*0x1410d067a*/
      if ( DFLog::SessionCrypto == 0 ) /*0x1410d0683*/
        goto LABEL_55; /*0x1410d0683*/
      v26 = "[DFLog::SessionCrypto] RbxOpenReply2 encrypt failed"; /*0x1410d0689*/
    }
    else
    {
      v25 = DFLog::SessionCrypto; /*0x1410d0757*/
      if ( DFLog::SessionCrypto == 0 ) /*0x1410d0760*/
      {
LABEL_55:
        v32 = 0; /*0x1410d0771*/
        goto LABEL_57; /*0xf1c000000000001c*/
      }
      v26 = "[DFLog::SessionCrypto] RbxOpenReply2 no public key"; /*0x1410d0762*/
    }
    FLog::FastLog(level: v25, message: v26, arg0: nullptr); /*0x1410d076c*/
    goto LABEL_55; /*0x1410d076c*/
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &bsOut); /*0xf1c0000000000008*/
  }
LABEL_57:
  RakNet::BitStream::~BitStream(this: &bsOut); /*0x1410d0777*/
  return v32; /*0x1410d077f*/
}

// Address: 0x1410d07a0 | Name: ?sendRbxOpenRequest1@RakPeer@RakNet@@IEAAXPEAURequestedConnectionStruct@12@AEB_K@Z
void __fastcall RakNet::RakPeer::sendRbxOpenRequest1(
        RakNet::RakPeer *this,
        RakNet::RakPeer::RequestedConnectionStruct *rcs,
        const unsigned __int64 *timeMS)
{
  unsigned __int64 v5; // r12
  RBX::Network::Rupp::Rupp *Ptr; // rcx
  int *Myfirst; // rdx
  unsigned __int64 v8; // rcx
  int v9; // ebx
  __int64 v10; // r13
  int *Mylast; // r12
  int *v12; // r11
  __int64 v13; // rdi
  unsigned __int64 v14; // rdx
  int *v15; // r8
  int *v16; // rax
  int v17; // r10d
  signed int v18; // r9d
  unsigned __int64 v19; // rdx
  int *v20; // r8
  signed int *v21; // rax
  unsigned __int64 *v22; // r13
  std::_Ref_count_base *Rep; // rbx
  RakNet::RakNetSocket *v24; // rdi
  RakNet::RakNetSocket *v25; // rcx
  std::shared_ptr<RakNet::RakNetSocket> *v26; // rdi
  std::_Ref_count_base *v27; // rax
  RakNet::SystemAddress *p_boundAddress; // rbx
  int IPPROTO; // eax
  unsigned __int64 Time; // rbx
  DWORD LastError; // ebx
  std::string *v32; // rax
  char *v33; // rcx
  std::string *v34; // rax
  char *v35; // rcx
  char v36; // bl
  int v37; // eax
  unsigned __int64 v38; // rcx
  unsigned int sendConnectionAttemptCount; // r8d
  int v40; // eax
  RakNet::SystemAddress *v41; // rcx
  int v42; // eax
  std::shared_ptr<RakNet::RakNetSocket> socket; // [rsp+40h] [rbp-C0h] BYREF
  std::string result; // [rsp+50h] [rbp-B0h] BYREF
  std::string v45; // [rsp+70h] [rbp-90h] BYREF
  RakNet::SystemAddress udmuxAddress; // [rsp+90h] [rbp-70h] BYREF
  RakNet::BitStream bitStream; // [rsp+B0h] [rbp-50h] BYREF
  char addressBuffer[1104]; // [rsp+1E0h] [rbp+E0h] BYREF
  unsigned __int8 inByteArray; // [rsp+640h] [rbp+540h] BYREF
  unsigned __int8 v50; // [rsp+648h] [rbp+548h] BYREF
  const unsigned __int64 *v51; // [rsp+650h] [rbp+550h]
  unsigned __int64 v52; // [rsp+658h] [rbp+558h]

  v51 = timeMS; /*0x1410d07a0*/
  v5 = rcs->requestsMade /*0x1410d07f0*/
     / (rcs->sendConnectionAttemptCount
      / (unsigned __int64)(this->mtuSizeList._Mypair._Myval2._Mylast - this->mtuSizeList._Mypair._Myval2._Myfirst));
  v52 = v5; /*0x1410d07f3*/
  RakNet::BitStream::BitStream(this: &bitStream); /*0x1410d07fe*/
  __wind
  {
    if ( DFFlag::RuppHeaderFromClientEnabled3.value ) /*0x1410d080b*/
    {
      Ptr = this->ruppHeader._Ptr; /*0x1410d080d*/
      if ( Ptr != nullptr ) /*0x1410d0817*/
        RBX::Network::Rupp::Rupp::serialize(this: Ptr, b: &bitStream); /*0x1410d081d*/
    }
    Myfirst = this->mtuSizeList._Mypair._Myval2._Myfirst; /*0x1410d0822*/
    v8 = this->mtuSizeList._Mypair._Myval2._Mylast - Myfirst; /*0x1410d0833*/
    if ( (int)v5 >= v8 ) /*0x1410d083d*/
    {
      LODWORD(v5) = v8 - 1; /*0x1410d083f*/
      v52 = (unsigned int)(v8 - 1); /*0x1410d0843*/
    }
    if ( DFLog::RakNetConnectTrace != 0 )
      FLog::FastLog(
        level: DFLog::RakNetConnectTrace,
        message: "[DFLog::RakNetConnectTrace] RakNet: Create OpenRequest1 with MTU %d",
        arg0: (const void *)Myfirst[(int)v5]);
    v9 = this->mtuSizeList._Mypair._Myval2._Myfirst[(int)v5] - 40; /*0x1410d0872*/
    v10 = v9; /*0x1410d0875*/
    inByteArray = 123; /*0x1410d0878*/
    RakNet::BitStream::WriteBits(this: &bitStream, &inByteArray, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d0893*/
    RakNet::BitStream::WriteAlignedBytes( /*0x1410d08a9*/
      this: &bitStream,
      inByteArray: OFFLINE_MESSAGE_DATA_ID,
      numberOfBytesToWrite: 0x10u);
    v50 = 5; /*0x1410d08ae*/
    RakNet::BitStream::WriteBits(this: &bitStream, inByteArray: &v50, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d08c9*/
    if ( DFFlag::CLI50798.value ) /*0x1410d08dc*/
    {
      RakNet::RakPeer::parseAvoidedPacketSizes(this); /*0x1410d08e5*/
      Mylast = this->avoidedPacketSizes._Mypair._Myval2._Mylast; /*0x1410d08ea*/
      v12 = this->avoidedPacketSizes._Mypair._Myval2._Myfirst; /*0x1410d08f1*/
      v13 = Mylast - v12; /*0x1410d08fe*/
      v14 = v13; /*0x1410d0902*/
      v15 = v12; /*0x1410d0905*/
      while ( (__int64)v14 > 0 ) /*0x1410d090b*/
      {
        v16 = &v15[v14 >> 1]; /*0x1410d0916*/
        if ( *v16 >= v9 ) /*0x1410d091c*/
        {
          v14 >>= 1; /*0x1410d092d*/
        }
        else
        {
          v15 = v16 + 1; /*0x1410d091e*/
          v14 += -1LL - (v14 >> 1); /*0x1410d0928*/
        }
      }
      if ( v15 != Mylast && v9 >= *v15 ) /*0x1410d093d*/
      {
        v17 = 1; /*0x1410d093f*/
        if ( v9 > 1 ) /*0x1410d0948*/
        {
          v18 = v9 - 1; /*0x1410d094a*/
          do /*0x1410d09a2*/
          {
            v19 = this->avoidedPacketSizes._Mypair._Myval2._Mylast - v12; /*0x1410d0950*/
            v20 = this->avoidedPacketSizes._Mypair._Myval2._Myfirst; /*0x1410d0953*/
            if ( v13 > 0 ) /*0x1410d0959*/
            {
              do /*0x1410d0984*/
              {
                v21 = &v20[v19 >> 1]; /*0x1410d0966*/
                if ( *v21 >= v18 ) /*0x1410d096d*/
                {
                  v19 >>= 1; /*0x1410d097e*/
                }
                else
                {
                  v20 = v21 + 1; /*0x1410d096f*/
                  v19 += -1LL - (v19 >> 1); /*0x1410d0979*/
                }
              }
              while ( (__int64)v19 > 0 ); /*0x1410d0984*/
            }
            if ( v20 == Mylast ) /*0x1410d0989*/
              break; /*0x1410d0989*/
            if ( v18 < *v20 ) /*0x1410d098e*/
              break; /*0x1410d098e*/
            if ( (unsigned int)v18 < 0x240 ) /*0x1410d0997*/
              break; /*0x1410d0997*/
            ++v17; /*0x1410d0999*/
            --v18; /*0x1410d099c*/
          }
          while ( v17 < v9 ); /*0x1410d09a2*/
        }
        v9 -= v17; /*0x1410d09a4*/
      }
      LOBYTE(v5) = v52; /*0x1410d09aa*/
      if ( v10 != v9 ) /*0x1410d09b4*/
      {
        LODWORD(v10) = v9; /*0x1410d09b6*/
        this->reducedMTU = true; /*0x1410d09b9*/
      }
    }
    RakNet::BitStream::PadWithZeroToByteLength(this: &bitStream, bytes: v10); /*0x1410d09c8*/
    ++rcs->requestsMade; /*0x1410d09cd*/
    v22 = (unsigned __int64 *)v51; /*0x1410d09d8*/
    rcs->nextRequestTime = *v51 + rcs->timeBetweenSendConnectionAttemptsMS; /*0x1410d09e3*/
    RakNet::SystemAddress::SystemAddress(this: &udmuxAddress, str: nullptr); /*0x1410d09ed*/
    Rep = rcs->socket._Rep; /*0x1410d09f2*/
    if ( Rep != nullptr ) /*0x1410d09fc*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410d09fe*/
      Rep = rcs->socket._Rep; /*0x1410d0a02*/
    }
    v24 = rcs->socket._Ptr; /*0x1410d0a09*/
    socket._Ptr = v24; /*0x1410d0a10*/
    socket._Rep = Rep; /*0x1410d0a15*/
    __wind
    {
      v25 = v24; /*0x1410d0a1a*/
      if ( v24 == nullptr ) /*0x1410d0a20*/
      {
        v26 = &this->socketList.listArray[rcs->socketIndex]; /*0x1410d0a2d*/
        v27 = v26->_Rep; /*0x1410d0a34*/
        if ( v27 != nullptr ) /*0x1410d0a3b*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v27->_Uses); /*0x1410d0a3d*/
          v27 = v26->_Rep; /*0x1410d0a41*/
        }
        v24 = v26->_Ptr; /*0x1410d0a45*/
        socket._Ptr = v24; /*0x1410d0a48*/
        socket._Rep = v27; /*0x1410d0a4d*/
        v25 = v24; /*0x1410d0a52*/
        if ( Rep != nullptr ) /*0x1410d0a58*/
        {
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410d0a64*/
          {
            Rep->_Destroy(this: Rep); /*0x1410d0a6c*/
            v25 = v24; /*0x1410d0a6e*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410d0a7b*/
            {
              Rep->_Delete_this(this: Rep); /*0x1410d0a83*/
              v25 = v24; /*0x1410d0a86*/
            }
          }
          v24 = socket._Ptr; /*0x1410d0a89*/
        }
      }
      p_boundAddress = &v25->boundAddress; /*0x1410d0a8e*/
      RakNet::SystemAddress::FixForIPVersion(this: &rcs->systemAddress, boundAddressToSocket: &v25->boundAddress); /*0x1410d0a98*/
      IPPROTO = RakNet::SystemAddress::GetIPPROTO(this: p_boundAddress); /*0x1410d0aa0*/
      RakNet::SocketLayer::SetDoNotFragment(listenSocket: v24->s, opt: 1, IPPROTO); /*0x1410d0ab0*/
      Time = RakNet::GetTime(isNetworkSynced: false); /*0x1410d0abc*/
      if ( DFLog::RakNetConnectTrace != 0 )
        FLog::FastLog(
          level: DFLog::RakNetConnectTrace,
          message: "[DFLog::RakNetConnectTrace] RakNet: Sending OpenRequest1",
          arg0: nullptr);
      if ( RakNet::SocketLayer::SendTo( /*0x1410d0b18*/
             s: v24->s,
             data: (const char *)bitStream.data,
             length: (bitStream.numberOfBitsUsed + 7) >> 3,
             dstAddress: &rcs->systemAddress,
             srcAddress: &udmuxAddress,
             raknetMetaDataEncrypted: false,
             file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
             line: 5640) != 0 )
      {
        LastError = GetLastError(); /*0x1410d0b24*/
        RakNet::SystemAddress::ToStringN( /*0x1410d0b3d*/
          this: &rcs->systemAddress,
          writePort: false,
          dest: addressBuffer,
          size: 1025,
          portDelineator: 124);
        if ( rcs->requestsMade == 1 && FLog::Network != 0 ) /*0x1410d0b50*/
        {
          v32 = RBX::systemErrorToString(&result, err: LastError); /*0x1410d0b59*/
          __wind /*0xf1c0000000000040*/
          {
            if ( v32->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410d0b64*/
              v32 = (std::string *)v32->_Mypair._Myval2._Bx._Ptr; /*0x1410d0b66*/
            FLog::FastLogFormatted( /*0x1410d0b81*/
              level: FLog::Network,
              message: "[FLog::Network] Socket send OpenRequest1 failed. Tried to connect to %s, %s",
              addressBuffer,
              v32->_Mypair._Myval2._Bx._Buf);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000038*/
          }
          if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d0b90*/
          {
            v33 = result._Mypair._Myval2._Bx._Ptr; /*0x1410d0b95*/
            if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410d0ba4*/
            {
              v33 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x1410d0baa*/
              if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v33 - 8) > 0x1F ) /*0x1410d0bb9*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410d0bbb*/
            }
            operator delete(ptr: v33); /*0x1410d0bc2*/
          }
        }
        if ( DFLog::RakNetConnectTrace != 0 ) /*0x1410d0bce*/
        {
          v34 = RBX::systemErrorToString(result: &v45, err: LastError); /*0x1410d0bd7*/
          __wind /*0xf1c0000000000028*/
          {
            if ( v34->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410d0be2*/
              v34 = (std::string *)v34->_Mypair._Myval2._Bx._Ptr; /*0x1410d0be4*/
            FLog::FastLogFormatted( /*0x1410d0bff*/
              level: DFLog::RakNetConnectTrace,
              message: "[DFLog::RakNetConnectTrace] Socket send OpenRequest1 failed. Tried to connect to %s, %s",
              addressBuffer,
              v34->_Mypair._Myval2._Bx._Buf);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v45); /*0xf1c0000000000020*/
          }
          if ( v45._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d0c0d*/
          {
            v35 = v45._Mypair._Myval2._Bx._Ptr; /*0x1410d0c12*/
            if ( v45._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410d0c21*/
            {
              v35 = *((char **)v45._Mypair._Myval2._Bx._Ptr - 1); /*0x1410d0c27*/
              if ( (unsigned __int64)(v45._Mypair._Myval2._Bx._Ptr - v35 - 8) > 0x1F ) /*0x1410d0c36*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410d0c38*/
            }
            operator delete(ptr: v35); /*0x1410d0c3f*/
          }
        }
        rcs->requestsMade = (v5 + 1) /*0x1410d0c6f*/
                          * (rcs->sendConnectionAttemptCount
                           / (unsigned __int64)(this->mtuSizeList._Mypair._Myval2._Mylast
                                              - this->mtuSizeList._Mypair._Myval2._Myfirst));
        rcs->nextRequestTime = *v22; /*0x1410d0c77*/
        v36 = 1; /*0x1410d0c7b*/
        v37 = RakNet::SystemAddress::GetIPPROTO(this: &v24->boundAddress); /*0x1410d0c81*/
        RakNet::SocketLayer::SetDoNotFragment(listenSocket: v24->s, opt: 0, IPPROTO: v37); /*0x1410d0c8e*/
      }
      else
      {
        if ( RakNet::GetTime(isNetworkSynced: false) - Time <= 0x64 ) /*0x1410d0ca6*/
        {
          v41 = &v24->boundAddress; /*0x1410d0cf2*/
        }
        else
        {
          v38 = this->mtuSizeList._Mypair._Myval2._Mylast - this->mtuSizeList._Mypair._Myval2._Myfirst; /*0x1410d0cb6*/
          sendConnectionAttemptCount = rcs->sendConnectionAttemptCount; /*0x1410d0cba*/
          v40 = (v38 - 1) * (sendConnectionAttemptCount / v38); /*0x1410d0ccb*/
          v41 = &v24->boundAddress; /*0x1410d0cd5*/
          if ( v40 <= rcs->requestsMade ) /*0x1410d0cd9*/
          {
            rcs->requestsMade = sendConnectionAttemptCount + 1; /*0x1410d0cec*/
          }
          else
          {
            rcs->requestsMade = v40; /*0x1410d0cdb*/
            rcs->nextRequestTime = *v22; /*0x1410d0ce3*/
          }
        }
        v42 = RakNet::SystemAddress::GetIPPROTO(this: v41); /*0x1410d0cf6*/
        RakNet::SocketLayer::SetDoNotFragment(listenSocket: v24->s, opt: 0, IPPROTO: v42); /*0x1410d0d03*/
        rtc::CriticalSection::Enter(lpCriticalSection: &this->connectionRequestsStats.mx.criticalSection); /*0x1410d0d0f*/
        ++this->connectionRequestsStats.counters[0]; /*0x1410d0d14*/
        RakNet::SimpleMutex::Unlock(lpCriticalSection: &this->connectionRequestsStats.mx.criticalSection); /*0x1410d0d22*/
        v36 = 0; /*0x1410d0d27*/
      }
      if ( DFFlag::RakNetSendJoinDataBit.value && v36 == 0 && !this->firstOpenReq1Sent ) /*0x1410d0d3d*/
      {
        this->firstOpenReq1Sent = true; /*0x1410d0d3f*/
        _InterlockedExchange( /*0x1410d0d4e*/
          (volatile __int32 *)&this->raknetHandshakeStartTimeMs,
          RakNet::GetTime(isNetworkSynced: false));
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&socket); /*0xf1c0000000000014*/
    }
    if ( socket._Rep != nullptr /*0x1410d0d69*/
      && _InterlockedExchangeAdd((volatile signed __int32 *)&socket._Rep->_Uses, 0xFFFFFFFF) == 1 )
    {
      socket._Rep->_Destroy(this: socket._Rep); /*0x1410d0d76*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&socket._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410d0d80*/
        socket._Rep->_Delete_this(this: socket._Rep); /*0x1410d0d8a*/
    }
    RakNet::BitStream::~BitStream(this: &bitStream); /*0x1410d0d92*/
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &bitStream); /*0xf1c0000000000008*/
  }
}

// Address: 0x1410d0db0 | Name: ?sendRbxOpenRequest2@RakPeer@RakNet@@IEAA_N_KPEAURequestedConnectionStruct@12@AEBUSystemAddress@2@AEAV?$shared_ptr@URakNetSocket@RakNet@@@std@@@Z
char __fastcall RakNet::RakPeer::sendRbxOpenRequest2(
        RakNet::RakPeer *this,
        unsigned __int64 mtu,
        RakNet::RakPeer::RequestedConnectionStruct *rcs,
        const RakNet::SystemAddress *systemAddress)
{
  int v5; // r15d
  unsigned __int16 HeaderTotalByteLength; // r14
  RBX::Network::Rupp::Rupp *Ptr; // rcx
  RBX::Security::RakPeerCrypto *v10; // r12
  unsigned __int64 v11; // rsi
  unsigned __int8 *p_ciphertextLen; // rdx
  unsigned __int8 *v13; // rdx
  std::string *v14; // rdx
  RBX::Security::EarlyAuthData *v15; // rdx
  RBX::Security::EarlyAuthData *v16; // rdx
  unsigned int Mysize; // r8d
  unsigned __int8 *v18; // rdx
  unsigned __int8 *v19; // rdx
  RakNet::RakPeer_vtbl *v20; // rax
  unsigned __int8 *v21; // rsi
  unsigned __int8 *v22; // rdx
  unsigned __int8 *p_mtu16b; // rdx
  RakNet::SystemAddress *v24; // rax
  RBX::Security::EarlyAuthData *v25; // rax
  RBX::Security::EarlyAuthData *v26; // rax
  const unsigned __int8 *p_authBlob; // rdx
  unsigned __int64 v28; // rsi
  unsigned __int8 *v29; // rdx
  unsigned __int8 v30; // cl
  const char *v31; // rdx
  __int64 socketIndex; // rcx
  std::shared_ptr<RakNet::RakNetSocket> *listArray; // rdx
  unsigned int v34; // r8d
  unsigned __int8 *data; // r10
  __int64 v36; // rcx
  std::_Ref_count_base *Rep; // rax
  int v38; // eax
  char v39; // bl
  unsigned __int8 kBlobSize[4]; // [rsp+60h] [rbp-A0h] BYREF
  unsigned __int16 ciphertextLen; // [rsp+64h] [rbp-9Ch] BYREF
  unsigned __int16 kBlobVersionAndSize[2]; // [rsp+68h] [rbp-98h] BYREF
  unsigned __int8 inByteArray; // [rsp+6Ch] [rbp-94h] BYREF
  unsigned __int8 version; // [rsp+6Dh] [rbp-93h] BYREF
  unsigned __int8 jobIdSize; // [rsp+6Eh] [rbp-92h] BYREF
  unsigned __int8 desiredEncryption; // [rsp+6Fh] [rbp-91h] BYREF
  unsigned __int16 keyVersion[2]; // [rsp+70h] [rbp-90h] BYREF
  unsigned __int16 mtu16b; // [rsp+74h] [rbp-8Ch] BYREF
  unsigned __int8 inOutByteArray[4]; // [rsp+78h] [rbp-88h] BYREF
  unsigned __int8 v50[4]; // [rsp+7Ch] [rbp-84h] BYREF
  unsigned __int8 v51[4]; // [rsp+80h] [rbp-80h] BYREF
  unsigned __int8 v52[4]; // [rsp+84h] [rbp-7Ch] BYREF
  unsigned __int8 v53[8]; // [rsp+88h] [rbp-78h] BYREF
  unsigned __int8 v54[8]; // [rsp+90h] [rbp-70h] BYREF
  std::shared_ptr<RakNet::RakNetSocket> v55; // [rsp+98h] [rbp-68h] BYREF
  unsigned __int8 v56[8]; // [rsp+A8h] [rbp-58h] BYREF
  unsigned __int8 v57[8]; // [rsp+B0h] [rbp-50h] BYREF
  RBX::ArrayView<unsigned char> publicEphemeralKey; // [rsp+B8h] [rbp-48h] BYREF
  RakNet::BitStream bsOut; // [rsp+D0h] [rbp-30h] BYREF
  RakNet::SystemAddress v60; // [rsp+200h] [rbp+100h] BYREF
  RakNet::SystemAddress udmuxAddress; // [rsp+220h] [rbp+120h] BYREF
  RakNet::RakNetGUID guid; // [rsp+240h] [rbp+140h] BYREF
  RakNet::SystemAddress v63; // [rsp+250h] [rbp+150h] BYREF
  unsigned __int8 aadLen; // [rsp+2B0h] [rbp+1B0h] BYREF

  v5 = mtu; /*0x1410d0dda*/
  if ( rcs->rbxSessionCrypto._Ptr == nullptr ) /*0x1410d0de8*/
  {
    if ( DFLog::SessionCrypto != 0 ) /*0x1410d0df3*/
      FLog::FastLog( /*0x1410d0dff*/
        level: DFLog::SessionCrypto,
        message: "[DFLog::SessionCrypto] RbxOpenRequest2 no session crypto",
        arg0: nullptr);
    return 0; /*0x1410d0e06*/
  }
  RakNet::BitStream::BitStream(this: &bsOut, initialBytesToAllocate: 8 * mtu); /*0x1410d0e16*/
  __wind /*0xf1c0000000000010*/
  {
    HeaderTotalByteLength = 0; /*0x1410d0e1f*/
    if ( DFFlag::RuppHeaderFromClientEnabled3.value ) /*0x1410d0e2a*/
    {
      Ptr = this->ruppHeader._Ptr; /*0x1410d0e2c*/
      if ( Ptr != nullptr ) /*0x1410d0e36*/
      {
        HeaderTotalByteLength = RBX::Network::Rupp::Rupp::getHeaderTotalByteLength(this: Ptr); /*0x1410d0e3d*/
        RBX::Network::Rupp::Rupp::serialize(this: this->ruppHeader._Ptr, b: &bsOut); /*0x1410d0e4c*/
      }
    }
    version = 3; /*0x1410d0e51*/
    keyVersion[0] = rcs->earlyPublicKeyVersion; /*0x1410d0e5d*/
    aadLen = 0; /*0x1410d0e62*/
    ciphertextLen = 0; /*0x1410d0e69*/
    v10 = rcs->rbxSessionCrypto._Ptr; /*0x1410d0e6f*/
    RBX::Security::RakPeerCrypto::getPublicKey(this: v10, result: &publicEphemeralKey); /*0x1410d0e7d*/
    if ( publicEphemeralKey.buffer != nullptr && publicEphemeralKey.length != 0 ) /*0x1410d0e90*/
    {
      desiredEncryption = RBX::Security::SessionCrypto::getSupportAes(this: v10) + 1; /*0x1410d0ea5*/
      v11 = buildRakPeerCapabilities(peer: this); /*0x1410d0eb1*/
      RakNet::RakNetGUID::RakNetGUID(this: &guid); /*0x1410d0ebb*/
      inByteArray = 120; /*0x1410d0ec0*/
      RakNet::BitStream::WriteBits(this: &bsOut, &inByteArray, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d0ed7*/
      RakNet::BitStream::WriteAlignedBytes( /*0x1410d0eed*/
        this: &bsOut,
        inByteArray: OFFLINE_MESSAGE_DATA_ID,
        numberOfBytesToWrite: 0x10u);
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: &version, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d0f04*/
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: &aadLen, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d0f1d*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d0f22*/
      {
        p_ciphertextLen = (unsigned __int8 *)&ciphertextLen; /*0x1410d0f47*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410d0f3b*/
          inByteArray: (unsigned __int8 *)&ciphertextLen,
          inOutByteArray,
          length: 2u);
        p_ciphertextLen = inOutByteArray; /*0x1410d0f40*/
      }
      RakNet::BitStream::WriteBits( /*0x1410d0f59*/
        this: &bsOut,
        inByteArray: p_ciphertextLen,
        numberOfBitsToWrite: 0x10u,
        rightAlignedBits: true);
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d0f5e*/
      {
        v13 = (unsigned __int8 *)keyVersion; /*0x1410d0f83*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410d0f77*/
          inByteArray: (unsigned __int8 *)keyVersion,
          inOutByteArray: v50,
          length: 2u);
        v13 = v50; /*0x1410d0f7c*/
      }
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: v13, numberOfBitsToWrite: 0x10u, rightAlignedBits: true); /*0x1410d0f95*/
      RakNet::BitStream::WriteAlignedBytes( /*0x1410d0fa8*/
        this: &bsOut,
        inByteArray: publicEphemeralKey.buffer,
        numberOfBytesToWrite: 0x20u);
      if ( FFlag::DebugLocalRccServerConnection.value && FFlag::DebugLocalRccTicketTesting.value ) /*0x1410d0fbd*/
      {
        jobIdSize = RBX::Http::gameID._Mypair._Myval2._Mysize; /*0x1410d0fc6*/
        RakNet::BitStream::WriteBits( /*0x1410d0fdc*/
          this: &bsOut,
          inByteArray: &jobIdSize,
          numberOfBitsToWrite: 8u,
          rightAlignedBits: true);
        v14 = &RBX::Http::gameID; /*0x1410d0fe1*/
        if ( RBX::Http::gameID._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d0ff0*/
          v14 = (std::string *)RBX::Http::gameID._Mypair._Myval2._Bx._Ptr; /*0x1410d0ff0*/
        RakNet::BitStream::WriteAlignedBytes( /*0x1410d1003*/
          this: &bsOut,
          inByteArray: (const unsigned __int8 *)v14,
          numberOfBytesToWrite: RBX::Http::gameID._Mypair._Myval2._Mysize);
      }
      v15 = this->earlyAuthData._Ptr; /*0x1410d1008*/
      if ( v15 != nullptr ) /*0x1410d1012*/
      {
        RakNet::BitStream::WriteBits( /*0x1410d1025*/
          this: &bsOut,
          inByteArray: &v15->authVersion,
          numberOfBitsToWrite: 8u,
          rightAlignedBits: true);
        LOBYTE(kBlobVersionAndSize[0]) = this->earlyAuthData._Ptr->preauthBlob._Mypair._Myval2._Mysize; /*0x1410d1035*/
        RakNet::BitStream::WriteBits( /*0x1410d104b*/
          this: &bsOut,
          inByteArray: (unsigned __int8 *)kBlobVersionAndSize,
          numberOfBitsToWrite: 8u,
          rightAlignedBits: true);
        v16 = this->earlyAuthData._Ptr; /*0x1410d1050*/
        Mysize = v16->preauthBlob._Mypair._Myval2._Mysize; /*0x1410d1057*/
        if ( v16->preauthBlob._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d1060*/
          v16 = (RBX::Security::EarlyAuthData *)v16->preauthBlob._Mypair._Myval2._Bx._Ptr; /*0x1410d1062*/
        RakNet::BitStream::WriteAlignedBytes( /*0x1410d1069*/
          this: &bsOut,
          inByteArray: (const unsigned __int8 *)v16,
          numberOfBytesToWrite: Mysize);
      }
      else
      {
        kBlobVersionAndSize[0] = 0; /*0x1410d1070*/
        if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d1076*/
        {
          v18 = (unsigned __int8 *)kBlobVersionAndSize; /*0x1410d1099*/
        }
        else
        {
          RBX::Network::NetworkStream::ReverseBytes( /*0x1410d108e*/
            inByteArray: (unsigned __int8 *)kBlobVersionAndSize,
            inOutByteArray: v51,
            length: 2u);
          v18 = v51; /*0x1410d1093*/
        }
        RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: v18, numberOfBitsToWrite: 0x10u, rightAlignedBits: true); /*0x1410d10ab*/
      }
      aadLen = (bsOut.numberOfBitsUsed >> 3) - HeaderTotalByteLength; /*0x1410d10b9*/
      *(_QWORD *)v54 = v11; /*0x1410d10bf*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d10c3*/
      {
        v19 = v54; /*0x1410d10e5*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes(inByteArray: v54, inOutByteArray: v56, length: 8u); /*0x1410d10da*/
        v19 = v56; /*0x1410d10df*/
      }
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: v19, numberOfBitsToWrite: 0x40u, rightAlignedBits: true); /*0x1410d10f6*/
      v20 = this->__vftable; /*0x1410d10fb*/
      v60 = RakNet::UNASSIGNED_SYSTEM_ADDRESS_30; /*0x1410d1105*/
      v21 = (unsigned __int8 *)v20->GetGuidFromSystemAddress(this, a2: &v60); /*0x1410d112a*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d112d*/
      {
        v22 = v21; /*0x1410d114e*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes(inByteArray: v21, inOutByteArray: v57, length: 8u); /*0x1410d1143*/
        v22 = v57; /*0x1410d1148*/
      }
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: v22, numberOfBitsToWrite: 0x40u, rightAlignedBits: true); /*0x1410d115e*/
      mtu16b = v5; /*0x1410d1163*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d1169*/
      {
        p_mtu16b = (unsigned __int8 *)&mtu16b; /*0x1410d118c*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410d1181*/
          inByteArray: (unsigned __int8 *)&mtu16b,
          inOutByteArray: v52,
          length: 2u);
        p_mtu16b = v52; /*0x1410d1186*/
      }
      RakNet::BitStream::WriteBits( /*0x1410d119e*/
        this: &bsOut,
        inByteArray: p_mtu16b,
        numberOfBitsToWrite: 0x10u,
        rightAlignedBits: true);
      RakNet::BitStream::WriteBits( /*0x1410d11b5*/
        this: &bsOut,
        inByteArray: &desiredEncryption,
        numberOfBitsToWrite: 8u,
        rightAlignedBits: true);
      RakNet::BitStream::Write<RakNet::SystemAddress>(this: &bsOut, inTemplateVar: &rcs->systemAddress); /*0x1410d11c1*/
      if ( FFlag::DebugLocalRccServerConnection.value && FFlag::DebugLocalRccRuppToken.value ) /*0x1410d11d6*/
      {
        v24 = RakNet::SystemAddress::SystemAddress( /*0x1410d11ee*/
                this: &v63,
                str: RBX::RbxDbgInfo::s_instance.ServerIP,
                port: RBX::RbxDbgInfo::s_instance.DebugServerPort);
        RakNet::BitStream::Write<RakNet::SystemAddress>(this: &bsOut, inTemplateVar: v24); /*0x1410d11fa*/
      }
      v25 = this->earlyAuthData._Ptr; /*0x1410d11ff*/
      if ( v25 != nullptr ) /*0x1410d121b*/
      {
        kBlobSize[0] = v25->authBlob._Mypair._Myval2._Mysize; /*0x1410d1221*/
        RakNet::BitStream::WriteBits( /*0x1410d1225*/
          this: &bsOut,
          inByteArray: kBlobSize,
          numberOfBitsToWrite: 8u,
          rightAlignedBits: true);
        v26 = this->earlyAuthData._Ptr; /*0x1410d122a*/
        p_authBlob = (const unsigned __int8 *)&v26->authBlob; /*0x1410d1231*/
        if ( v26->authBlob._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d123a*/
          p_authBlob = *(const unsigned __int8 **)p_authBlob; /*0x1410d123c*/
        RakNet::BitStream::WriteAlignedBytes( /*0x1410d1247*/
          this: &bsOut,
          inByteArray: p_authBlob,
          numberOfBytesToWrite: v26->authBlob._Mypair._Myval2._Mysize);
      }
      else
      {
        kBlobSize[0] = 0; /*0x1410d124e*/
        RakNet::BitStream::WriteBits( /*0x1410d1253*/
          this: &bsOut,
          inByteArray: kBlobSize,
          numberOfBitsToWrite: 8u,
          rightAlignedBits: true);
      }
      ciphertextLen = (bsOut.numberOfBitsUsed >> 3) - aadLen - HeaderTotalByteLength; /*0x1410d1272*/
      v28 = (unsigned __int64)bsOut.numberOfBitsUsed >> 3; /*0x1410d1279*/
      RakNet::BitStream::SetWriteOffset( /*0x1410d128c*/
        this: &bsOut,
        offset: 8 * HeaderTotalByteLength + 144,
        eraseDataToCurrentOffset: false);
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: &aadLen, numberOfBitsToWrite: 8u, rightAlignedBits: true); /*0x1410d12a5*/
      if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410d12aa*/
      {
        v29 = (unsigned __int8 *)&ciphertextLen; /*0x1410d12cd*/
      }
      else
      {
        RBX::Network::NetworkStream::ReverseBytes( /*0x1410d12c2*/
          inByteArray: (unsigned __int8 *)&ciphertextLen,
          inOutByteArray: v53,
          length: 2u);
        v29 = v53; /*0x1410d12c7*/
      }
      RakNet::BitStream::WriteBits(this: &bsOut, inByteArray: v29, numberOfBitsToWrite: 0x10u, rightAlignedBits: true); /*0x1410d12df*/
      RakNet::BitStream::SetWriteOffset(this: &bsOut, offset: 8 * v28, eraseDataToCurrentOffset: false); /*0x1410d12f2*/
      if ( RBX::Security::RakPeerCrypto::earlyEncryptData( /*0x1410d130a*/
             this: v10,
             bitstream: &bsOut,
             aadSize: aadLen,
             ruppLength: HeaderTotalByteLength) )
      {
        RakNet::BitStream::PadWithZeroToByteLength(this: &bsOut, bytes: v5 - 40); /*0x1410d1336*/
        RakNet::SystemAddress::SystemAddress(this: &udmuxAddress); /*0x1410d1342*/
        socketIndex = rcs->socketIndex; /*0x1410d1347*/
        listArray = this->socketList.listArray; /*0x1410d134d*/
        v34 = (bsOut.numberOfBitsUsed + 7) >> 3; /*0x1410d135c*/
        if ( FFlag::CLI52064Experiment2.value ) /*0x1410d1367*/
        {
          data = bsOut.data; /*0x1410d1369*/
          v36 = socketIndex; /*0x1410d136d*/
          v55 = 0; /*0x1410d1373*/
          Rep = listArray[v36]._Rep; /*0x1410d1378*/
          if ( Rep != nullptr ) /*0x1410d1380*/
            _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410d1382*/
          v55 = listArray[v36]; /*0x1410d138a*/
          v38 = RakNet::SocketLayer::SendToOrDelay( /*0x1410d13d5*/
                  socket: &v55,
                  (const char *)data,
                  length: v34,
                  dstAddress: &rcs->systemAddress,
                  srcAddress: &udmuxAddress,
                  raknetMetaDataEncrypted: false,
                  rakPeer: this,
                  reliabilityLayer: nullptr,
                  now: 0,
                  file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                  line: 7066);
        }
        else
        {
          v38 = RakNet::SocketLayer::SendTo( /*0x1410d1415*/
                  s: listArray[socketIndex]._Ptr->s,
                  data: (const char *)bsOut.data,
                  length: v34,
                  dstAddress: &rcs->systemAddress,
                  srcAddress: &udmuxAddress,
                  raknetMetaDataEncrypted: false,
                  file: "C:\\teamcity-agent\\work\\qa_nbs_stu-x64\\Client\\Network\\raknet\\Source\\RakPeer.cpp",
                  line: 7071);
        }
        if ( v38 == 0 ) /*0x1410d141c*/
          RakNet::RakPeer::ConnectionRequestsStats::Increment(this: &this->connectionRequestsStats, type: 4u); /*0x1410d1428*/
        v39 = 1; /*0x1410d142d*/
        goto LABEL_66; /*0x1410d142f*/
      }
      v30 = DFLog::SessionCrypto; /*0x1410d1313*/
      if ( DFLog::SessionCrypto == 0 ) /*0x1410d131c*/
        goto LABEL_64; /*0x1410d131c*/
      v31 = "[DFLog::SessionCrypto] RbxOpenRequest2 failed to encrypt"; /*0x1410d1322*/
    }
    else
    {
      v30 = DFLog::SessionCrypto; /*0x1410d1431*/
      if ( DFLog::SessionCrypto == 0 ) /*0x1410d143a*/
      {
LABEL_64:
        v39 = 0; /*0x1410d144b*/
        goto LABEL_66; /*0xf1c000000000001c*/
      }
      v31 = "[DFLog::SessionCrypto] RbxOpenRequest2 no public key"; /*0x1410d143c*/
    }
    FLog::FastLog(level: v30, message: v31, arg0: nullptr); /*0x1410d1446*/
    goto LABEL_64; /*0x1410d1446*/
  }
  __unwind
  {
    RakNet::BitStream::~BitStream(this: &bsOut); /*0xf1c0000000000008*/
  }
LABEL_66:
  RakNet::BitStream::~BitStream(this: &bsOut); /*0x1410d1451*/
  return v39; /*0x1410d1459*/
}

// Address: 0x1410d1500 | Name: ?setDisconnectReason@RakPeer@RakNet@@UEAAXI@Z
void __fastcall RakNet::RakPeer::setDisconnectReason(RakNet::RakPeer *this, unsigned int reason)
{
  this->disconnectReason = reason; /*0x1410d1500*/
}

// Address: 0x1410d1510 | Name: ?setEarlyAuthData@RakPeer@RakNet@@MEAAXV?$shared_ptr@UEarlyAuthData@Security@RBX@@@std@@@Z
void __fastcall RakNet::RakPeer::setEarlyAuthData(
        RakNet::RakPeer *this,
        const std::shared_ptr<RobloxDiagnosticsView::ItemData> *data)
{
  std::_Ref_count_base *Rep; // rbx

  std::shared_ptr<RBX::GfxGui>::operator=( /*0x1410d1520*/
    this: (std::shared_ptr<RobloxDiagnosticsView::ItemData> *)&this->earlyAuthData,
    _Right: data);
  Rep = data->_Rep; /*0x1410d1525*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410d1542*/
  {
    Rep->_Destroy(this: Rep); /*0x1410d154a*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410d1554*/
      Rep->_Delete_this(this: Rep); /*0x1410d155c*/
  }
}

// Address: 0x1410d1570 | Name: ?setIsRbxConnection@RakPeer@RakNet@@UEAAX_N@Z
void __fastcall RakNet::RakPeer::setIsRbxConnection(RakNet::RakPeer *this, bool isRbxConnection_)
{
  this->isRbxConnection = isRbxConnection_; /*0x1410d1570*/
}

// Address: 0x1410d1580 | Name: ?setJobId@RakPeer@RakNet@@MEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RakNet::RakPeer::setJobId(RakNet::RakPeer *this, const std::string *newJobId)
{
  std::string *p_jobId; // rcx
  unsigned __int64 Mysize; // r8

  p_jobId = &this->jobId; /*0x1410d1580*/
  if ( p_jobId != newJobId ) /*0x1410d158a*/
  {
    Mysize = newJobId->_Mypair._Myval2._Mysize; /*0x1410d1591*/
    if ( newJobId->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410d1595*/
      newJobId = (const std::string *)newJobId->_Mypair._Myval2._Bx._Ptr; /*0x1410d1597*/
    std::string::assign(this: p_jobId, _Ptr: newJobId->_Mypair._Myval2._Bx._Buf, _Count: Mysize); /*0x1410d159a*/
  }
}

// Address: 0x1410d15c0 | Name: ?setRecordJoinDataRxStats@RakPeer@RakNet@@UEAAXUAddressOrGUID@2@_N@Z
void __fastcall RakNet::RakPeer::setRecordJoinDataRxStats(
        RakNet::RakPeer *this,
        const RakNet::AddressOrGUID *systemIdentifier,
        bool val)
{
  RakNet::RakPeer::RemoteSystemStruct *RemoteSystem; // rax
  RakNet::RakNetGUID rakNetGuid; // [rsp+20h] [rbp-38h] BYREF
  RakNet::SystemAddress v8; // [rsp+30h] [rbp-28h] BYREF

  RakNet::RakNetGUID::RakNetGUID(this: &rakNetGuid); /*0x1410d15de*/
  RakNet::SystemAddress::SystemAddress(this: &v8); /*0x1410d15e8*/
  rakNetGuid = systemIdentifier->rakNetGuid; /*0x1410d15f4*/
  RakNet::SystemAddress::operator=(this: &v8, input: &systemIdentifier->systemAddress); /*0x1410d1607*/
  RemoteSystem = RakNet::RakPeer::GetRemoteSystem( /*0x1410d161a*/
                   this,
                   systemIdentifier: (RBX::json::ArrayIterator *)&rakNetGuid,
                   calledFromNetworkThread: false,
                   onlyActive: true);
  if ( RemoteSystem != nullptr ) /*0x1410d1622*/
    RemoteSystem->recordJoinDataRxStats._Storage._Value = val; /*0x1410d1624*/
}

// Address: 0x1410d1640 | Name: ?setServerMachineAddress@RakPeer@RakNet@@MEAAXAEBUSystemAddress@2@@Z
void __fastcall RakNet::RakPeer::setServerMachineAddress(RakNet::RakPeer *this, const RakNet::SystemAddress *addr)
{
  RakNet::SystemAddress *p_rccBoundAddress; // rbx
  char buf[72]; // [rsp+30h] [rbp-48h] BYREF

  p_rccBoundAddress = &this->rccBoundAddress; /*0x1410d1646*/
  RakNet::SystemAddress::operator=(this: &this->rccBoundAddress, input: addr); /*0x1410d164d*/
  RakNet::SystemAddress::ConvertToIpV6(this: p_rccBoundAddress); /*0x1410d1655*/
  if ( DFLog::RuppTokenLog != 0 ) /*0x1410d1661*/
  {
    memset(buf, 0, 64); /*0x1410d167b*/
    RakNet::SystemAddress::ToStringN( /*0x1410d168f*/
      this: p_rccBoundAddress,
      writePort: false,
      dest: buf,
      size: 64,
      portDelineator: 124);
    if ( DFLog::RuppTokenLog != 0 ) /*0x1410d169d*/
      FLog::FastLog( /*0x1410d16ab*/
        level: DFLog::RuppTokenLog,
        message: "[DFLog::RuppTokenLog] RakPeer::setServerMachineAddress %s",
        arg0: buf);
  }
}

// Address: 0x1410d16c0 | Name: ?setServerPort@RakPeer@RakNet@@MEAAXG@Z
void __fastcall RakNet::RakPeer::setServerPort(RakNet::RakPeer *this, unsigned __int16 port)
{
  RakNet::SystemAddress::SetPort(this: &this->rccBoundAddress, s: port); /*0x1410d16c4*/
}

// Address: 0x1410d16d0 | Name: ?setServerReceiveRuppToken@RakPeer@RakNet@@MEAAX_N@Z
void __fastcall RakNet::RakPeer::setServerReceiveRuppToken(RakNet::RakPeer *this, bool value)
{
  this->serverReceiveRuppToken = value; /*0x1410d16d0*/
}

// Address: 0x1410d16e0 | Name: ?setServerRuppStemma@RakPeer@RakNet@@MEAAXPEBD@Z
void __fastcall RakNet::RakPeer::setServerRuppStemma(RakNet::RakPeer *this, const char *serverRuppStemma)
{
  std::unique_ptr<RBX::RuppTokenProcessor> *p_ruppTokenProcessor; // rdi
  Json::Value::CommentInfo *v3; // rax
  QMetaObject::Call v4; // edx
  int v5; // r8d
  void **v6; // r9
  QObject *v7; // rbx
  QObject *Myval2; // rsi
  QObject *v9; // rcx
  const char *v10; // r8
  Json::Value::CommentInfo *v11; // [rsp+30h] [rbp+8h] BYREF

  p_ruppTokenProcessor = &this->ruppTokenProcessor; /*0x1410d16f2*/
  if ( this->ruppTokenProcessor._Mypair._Myval2 != nullptr ) /*0x1410d16fd*/
    return; /*0x1410d16fd*/
  v3 = (Json::Value::CommentInfo *)operator new(size: 8u); /*0x1410d1708*/
  v11 = v3; /*0x1410d170d*/
  if ( v3 != nullptr ) /*0x1410d1715*/
  {
    __wind /*0xf1c000000000001c*/
    {
      v7 = (QObject *)webrtc::AudioNetworkAdaptorImpl::Config::Config(this: v3); /*0x1410d1722*/
    }
    __unwind
    {
      operator delete(ptr: v11); /*0x143192a62*/
    }
  }
  else
  {
    v7 = nullptr; /*0x1410d1727*/
  }
  if ( p_ruppTokenProcessor == (std::unique_ptr<RBX::RuppTokenProcessor> *)&v11 ) /*0x1410d1731*/
  {
    if ( v7 == nullptr ) /*0x1410d174e*/
      goto LABEL_10; /*0x1410d174e*/
    RBX::LSP::ILSPEditor::onSignalQuiescenceResponse(_o: v7, _c: v4, _id: v5, _a: v6); /*0x1410d1753*/
    v9 = v7; /*0x1410d1758*/
  }
  else
  {
    Myval2 = (QObject *)p_ruppTokenProcessor->_Mypair._Myval2; /*0x1410d1733*/
    p_ruppTokenProcessor->_Mypair._Myval2 = (RBX::RuppTokenProcessor *)v7; /*0x1410d1736*/
    if ( Myval2 == nullptr ) /*0x1410d173c*/
      goto LABEL_10; /*0x1410d173c*/
    RBX::LSP::ILSPEditor::onSignalQuiescenceResponse(_o: Myval2, _c: v4, _id: v5, _a: v6); /*0x1410d1741*/
    v9 = Myval2; /*0x1410d1746*/
  }
  operator delete(ptr: v9); /*0x1410d1760*/
LABEL_10:
  if ( DFLog::RuppTokenLog != 0 ) /*0x1410d176e*/
  {
    v10 = "failed!"; /*0x1410d1777*/
    if ( p_ruppTokenProcessor->_Mypair._Myval2 != nullptr ) /*0x1410d1782*/
      v10 = "passed."; /*0x1410d1782*/
    FLog::FastLog( /*0x1410d178d*/
      level: DFLog::RuppTokenLog,
      message: "[DFLog::RuppTokenLog] RakPeer::setServerRuppStemma %s",
      arg0: v10);
  }
}

// Address: 0x1410d17b0 | Name: ?setTestDeserializeHook@RakPeer@RakNet@@MEAAXP6AHAEAVBitStream@2@@Z@Z
void __fastcall RakNet::RakPeer::setTestDeserializeHook(
        RakNet::RakPeer *this,
        int (__fastcall *setHook)(RakNet::BitStream *))
{
  std::function<int __cdecl(RakNet::BitStream &)> *p_testDeserializeHook; // rbx
  std::_Func_base<int,RakNet::BitStream &> *v3; // rax
  _QWORD *v4; // rcx
  std::_Func_base<int,RakNet::BitStream &> *v5; // r8
  _QWORD *v6; // rdx
  std::function<int __cdecl(RakNet::BitStream &)> *v7; // r9
  __int64 v8; // rax
  __int64 v9; // rdx
  std::function<int __cdecl(RakNet::BitStream &)> *v10; // r8
  __int64 v11; // rax
  std::_Func_base<int,RakNet::BitStream &> *v12; // rcx
  _BYTE *v13; // rdx
  _QWORD *v14; // rdx
  _QWORD _Where[7]; // [rsp+20h] [rbp-29h] BYREF
  _QWORD *v16; // [rsp+58h] [rbp+Fh]
  _BYTE v17[56]; // [rsp+60h] [rbp+17h] BYREF
  std::_Func_base<int,RakNet::BitStream &> *v18; // [rsp+98h] [rbp+4Fh]

  _Where[1] = setHook; /*0x1410d17c9*/
  _Where[0] = std::_Func_impl_no_alloc__lambda_3b00943932df17c78cf331b48a9ecc5b__int_RakNet::BitStream___::_vftable_; /*0x1410d17cd*/
  p_testDeserializeHook = &this->testDeserializeHook; /*0x1410d17d1*/
  v18 = nullptr; /*0x1410d17dc*/
  v16 = _Where; /*0x1410d17e8*/
  v3 = std::_Func_impl_no_alloc__lambda_3b00943932df17c78cf331b48a9ecc5b__int_RakNet::BitStream___::_Move(_Where); /*0x1410d17f0*/
  v4 = v16; /*0x1410d17f6*/
  v5 = v3; /*0x1410d17fa*/
  v18 = v3; /*0x1410d17fd*/
  if ( v16 != nullptr ) /*0x1410d1804*/
  {
    v6 = _Where; /*0x1410d1809*/
    LOBYTE(v6) = v16 != _Where; /*0x1410d1810*/
    (*(void (__fastcall **)(_QWORD *, _QWORD *, std::_Func_base<int,RakNet::BitStream &> *))(*v16 + 32LL))( /*0x1410d1813*/
      a1: v16,
      a2: v6,
      a3: v3);
    v5 = v18; /*0x1410d1816*/
    v4 = nullptr; /*0x1410d181a*/
    v16 = nullptr; /*0x1410d181c*/
  }
  v7 = (std::function<int __cdecl(RakNet::BitStream &)> *)p_testDeserializeHook->_Mystorage._Ptrs[7]; /*0x1410d1820*/
  if ( v7 != nullptr ) /*0x1410d1827*/
  {
    v4 = &p_testDeserializeHook->_Mystorage._Ptrs[7]->__vftable; /*0x1410d1829*/
    if ( v7 == p_testDeserializeHook ) /*0x1410d182f*/
    {
      v8 = ((__int64 (__fastcall *)(_QWORD *, _QWORD *, std::_Func_base<int,RakNet::BitStream &> *))v7->_Mystorage._Ptrs[0][1].__vftable)( /*0x1410d1838*/
             a1: v4,
             a2: _Where,
             a3: v5);
      v10 = (std::function<int __cdecl(RakNet::BitStream &)> *)p_testDeserializeHook->_Mystorage._Ptrs[7]; /*0x1410d183b*/
      v4 = (_QWORD *)v8; /*0x1410d183f*/
      v16 = (_QWORD *)v8; /*0x1410d1842*/
      if ( v10 == nullptr ) /*0x1410d1849*/
      {
        v5 = v18; /*0x1410d1864*/
        goto LABEL_10; /*0x1410d1868*/
      }
      LOBYTE(v9) = v10 != p_testDeserializeHook; /*0x1410d1854*/
      ((void (__fastcall *)(std::function<int __cdecl(RakNet::BitStream &)> *, __int64))v10->_Mystorage._Ptrs[0][4].__vftable)( /*0x1410d1857*/
        a1: v10,
        a2: v9);
      v4 = v16; /*0x1410d185a*/
      v5 = v18; /*0x1410d185e*/
    }
    else
    {
      v16 = &p_testDeserializeHook->_Mystorage._Ptrs[7]->__vftable; /*0x1410d186a*/
    }
    p_testDeserializeHook->_Mystorage._Ptrs[7] = nullptr; /*0x1410d186e*/
  }
LABEL_10:
  if ( v5 != nullptr ) /*0x1410d1879*/
  {
    if ( v5 == (std::_Func_base<int,RakNet::BitStream &> *)v17 ) /*0x1410d1882*/
    {
      v11 = (__int64)v5->_Move(this: v5, a2: p_testDeserializeHook); /*0x1410d188d*/
      v12 = v18; /*0x1410d1890*/
      p_testDeserializeHook->_Mystorage._Ptrs[7] = (std::_Func_base<int,RakNet::BitStream &> *)v11; /*0x1410d1894*/
      if ( v12 != nullptr ) /*0x1410d189b*/
      {
        v13 = v17; /*0x1410d18a0*/
        LOBYTE(v13) = v12 != (std::_Func_base<int,RakNet::BitStream &> *)v17; /*0x1410d18a7*/
        v12->_Delete_this(this: v12, a2: (bool)v13); /*0x1410d18aa*/
      }
      v4 = v16; /*0x1410d18ad*/
    }
    else
    {
      p_testDeserializeHook->_Mystorage._Ptrs[7] = v5; /*0x1410d18b3*/
    }
  }
  if ( v4 != nullptr ) /*0x1410d18ba*/
  {
    v14 = _Where; /*0x1410d18bf*/
    LOBYTE(v14) = v4 != _Where; /*0x1410d18c6*/
    (*(void (__fastcall **)(_QWORD *, _QWORD *))(*v4 + 32LL))(a1: v4, a2: v14); /*0x1410d18c9*/
  }
}

// Address: 0x1410d18e0 | Name: ?setTestSendHook@RakPeer@RakNet@@MEAAXV?$function@$$A6AXPEBVAbstractBitStream@RakNet@@@Z@std@@@Z
void __fastcall RakNet::RakPeer::setTestSendHook(
        RakNet::RakPeer *this,
        const std::function<void __cdecl(RBX::GImage const *,bool,bool)> *hook)
{
  _BOOL8 v3; // rdx
  std::_Func_base<void,RakNet::AbstractBitStream const *> *v4; // rcx

  std::function<void (std::shared_ptr<RBX::Player>,std::function<void (std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>)>,std::function<void (std::string)>)>::operator=( /*0x1410d18f4*/
    this: (std::function<void __cdecl(RBX::GImage const *,bool,bool)> *)&this->testSendHook,
    _Right: hook);
  v4 = (std::_Func_base<void,RakNet::AbstractBitStream const *> *)hook->_Mystorage._Ptrs[7]; /*0x1410d18fa*/
  if ( v4 != nullptr ) /*0x1410d1901*/
  {
    LOBYTE(v3) = v4 != (std::_Func_base<void,RakNet::AbstractBitStream const *> *)hook; /*0x1410d1909*/
    v4->_Delete_this(this: v4, a2: v3); /*0x1410d190c*/
    hook->_Mystorage._Ptrs[7] = nullptr; /*0x1410d190f*/
  }
}

// Address: 0x1410d1aa0 | Name: ?setupRupp@RakPeer@RakNet@@MEAA?AW4ErrorCode@RuppError@Rupp@Network@RBX@@_NAEAUToken@TokenTlv@567@PEBDG@Z
RBX::Network::Rupp::RuppError::ErrorCode __fastcall RakNet::RakPeer::setupRupp(
        RakNet::RakPeer *this,
        bool directServerReturn,
        RBX::Network::Rupp::TokenTlv::Token *token,
        const char *host,
        unsigned __int16 remotePort)
{
  char *v9; // rax
  char *v10; // r14
  __int64 v11; // rbx
  std::_Ref_count_base *Rep; // rdi
  RBX::Network::Rupp::RuppError::ErrorCode result; // eax
  char v14; // al
  in6_addr v15; // [rsp+20h] [rbp-48h] BYREF
  in6_addr ipv6Addr; // [rsp+30h] [rbp-38h] BYREF
  in_addr ipv4Addr; // [rsp+70h] [rbp+8h] BYREF

  v9 = (char *)operator new(size: 0x180u); /*0x1410d1ace*/
  __wind /*0xf1c000000000001c*/
  {
    v10 = v9; /*0x1410d1ad3*/
    *(_QWORD *)v15.u.Byte = v9; /*0x1410d1ad6*/
    v11 = 0; /*0x1410d1adb*/
    if ( v9 != nullptr ) /*0x1410d1ae0*/
    {
      *(_OWORD *)v9 = 0; /*0x1410d1ae5*/
      *((_DWORD *)v9 + 2) = 1; /*0x1410d1ae8*/
      *((_DWORD *)v9 + 3) = 1; /*0x1410d1aef*/
      *(_QWORD *)v9 = std::_Ref_count_obj2<RBX::Network::Rupp::Rupp>::`vftable'; /*0x1410d1afd*/
      RBX::Network::Rupp::Rupp::Rupp(this: (RBX::Network::Rupp::Rupp *)(v9 + 16), setFlag: DirectServerReturn); /*0x1410d1b06*/
    }
    else
    {
      v10 = nullptr; /*0x1410d1b0d*/
    }
    this->ruppHeader._Ptr = (RBX::Network::Rupp::Rupp *)(v10 + 16); /*0x1410d1b14*/
    Rep = this->ruppHeader._Rep; /*0x1410d1b1b*/
    this->ruppHeader._Rep = (std::_Ref_count_base *)v10; /*0x1410d1b22*/
    if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410d1b3d*/
    {
      Rep->_Destroy(this: Rep); /*0x1410d1b45*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410d1b4f*/
        Rep->_Delete_this(this: Rep); /*0x1410d1b57*/
    }
  }
  __unwind
  {
    operator delete(ptr: *(void **)v15.u.Byte); /*0x1431ed062*/
  }
  RBX::Network::Rupp::Rupp::setFlag( /*0x1410d1b67*/
    this: this->ruppHeader._Ptr,
    flagEnum: DirectServerReturn,
    value: directServerReturn);
  result = RBX::Network::Rupp::Rupp::addTokenTlv(this: this->ruppHeader._Ptr, token); /*0x1410d1b76*/
  if ( result == 0 ) /*0x1410d1b7d*/
  {
    if ( strcmp_0(Str1: host, Str2: (const char *)&RBX::Studio::ClientDataModel::`vftable'[20]) == 0 ) /*0x1410d1b94*/
    {
LABEL_13:
      host = "127.0.0.1"; /*0x1410d1bb3*/
    }
    else
    {
      while ( 1 ) /*0x1410d1ba0*/
      {
        v14 = host[v11++]; /*0x1410d1ba0*/
        if ( v14 != a1_9[v11 - 1] ) /*0x1410d1bab*/
          break; /*0x1410d1bab*/
        if ( v11 == 4 ) /*0x1410d1bb1*/
          goto LABEL_13; /*0x1410d1bb1*/
      }
    }
    if ( inet_pton(Family: 2, pszAddrString: host, pAddrBuf: &ipv4Addr) != 0 ) /*0x1410d1bcf*/
    {
      return RBX::Network::Rupp::Rupp::addIpv4EndpointTlv( /*0x1410d1be5*/
               this: this->ruppHeader._Ptr,
               setIP: ipv4Addr,
               setPort: remotePort);
    }
    else if ( inet_pton(Family: 23, pszAddrString: host, pAddrBuf: &ipv6Addr) != 0 ) /*0x1410d1c01*/
    {
      v15 = ipv6Addr; /*0x1410d1c08*/
      return RBX::Network::Rupp::Rupp::addIpv6EndpointTlv(this: this->ruppHeader._Ptr, setIP: &v15, setPort: remotePort); /*0x1410d1c23*/
    }
    else
    {
      return INVALID_ENDPOINT; /*0x1410d1c2a*/
    }
  }
  return result; /*0x1410d1c2f*/
}

// Address: 0x1410d1c50 | Name: ?verifyPreauthMac@RakPeer@RakNet@@IEAA?AW4PreauthResult@12@VStringView@RBX@@E@Z
// local variable allocation has failed, the output may be wrong!
__int64 __fastcall RakNet::RakPeer::verifyPreauthMac(
        RakNet::RakPeer *this,
        RBX::StringView *preauthBlob,
        unsigned __int8 authVersion)
{
  unsigned int v3; // esi
  unsigned __int64 Length; // rax
  RBX::Security::KeyRing *Instance; // rax
  RBX::Security::KeyRing *v9; // r14
  const char *Data; // rdi
  char *v11; // rax
  std::string *p_jobId; // rdx
  __m256i *v13; // rax
  char *Ptr; // rcx
  char v15; // r12
  char *v16; // rcx
  char *v17; // rcx
  std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *p_msg_8; // rax
  __m256i *v19; // rbx
  char *v20; // rcx
  void *v21; // rcx
  std::string *p_mac_8; // rcx
  void *v23; // rcx
  unsigned __int64 Mysize; // rdi
  std::_Tree<std::_Tmap_traits<std::string,std::shared_ptr<std::string const >,std::less<std::string >,std::allocator<std::pair<std::string const ,std::shared_ptr<std::string const > > >,0> > *p_usedMacs; // r15
  std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *Myhead; // r14
  std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *Parent; // rbx
  std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *v28; // rsi
  char **p_Myval; // rcx
  std::string *v30; // rdx
  unsigned __int64 v31; // rsi
  size_t v32; // r8
  int v33; // eax
  char *v34; // rax
  unsigned int v35; // ebx
  std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *v36; // rax
  __m256i *v37; // rbx
  char *v38; // rcx
  void *v39; // rcx
  char **v40; // rdx
  unsigned __int64 v41; // rbx
  std::string *v42; // rcx
  size_t v43; // r8
  int v44; // eax
  std::_Tree_find_result<std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *> *v45; // rax
  std::_Tree_id<std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *> Location; // xmm6
  char **v47; // rdx
  unsigned __int64 v48; // rbx
  std::string *v49; // rcx
  size_t v50; // r8
  unsigned int v51; // eax
  unsigned int v52; // eax
  std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *v53; // rbx
  std::string *v54; // rax
  char *v55; // rcx
  char *v56; // rcx
  std::string mac_8; // [rsp+28h] [rbp-E0h] OVERLAPPED BYREF
  std::_Tree_find_result<std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *> result_8; // [rsp+48h] [rbp-C0h] BYREF
  std::string msg_8; // [rsp+68h] [rbp-A0h] OVERLAPPED BYREF
  std::string v60; // [rsp+88h] [rbp-80h] BYREF
  __m256i v61; // [rsp+A8h] [rbp-60h] OVERLAPPED BYREF
  std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *Bound; // [rsp+C8h] [rbp-40h]
  RBX::Graphics::ProfilerAdorn::Item name; // [rsp+D0h] [rbp-38h] BYREF
  unsigned __int64 v64; // [rsp+108h] [rbp+0h]

  v3 = authVersion; /*0x1410d1c77*/
  if ( !this->isRbxConnection ) /*0x1410d1c88*/
    return 1; /*0x1410d1c8f*/
  if ( DFFlag::NewPaBlob2.value ) /*0x1410d1c98*/
  {
    if ( DFFlag::ForceNewPaBlob2.value || preauthBlob->Length != 32 ) /*0x1410d1ca8*/
    {
      Length = preauthBlob->Length; /*0x1410d1caa*/
      if ( Length != 33 && Length != 50 ) /*0x1410d1cb8*/
        return 0; /*0x1410d1cb8*/
    }
  }
  else if ( preauthBlob->Length != 32 || authVersion != 6 ) /*0x1410d1ced*/
  {
    return 0; /*0x1410d1ce1*/
  }
  __wind /*0xf1c0000000000088*/
  {
    mac_8._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410d1cf2*/
    mac_8._Mypair._Myval2._Mysize = 0; /*0x1410d1cf7*/
    mac_8._Mypair._Myval2._Myres = 15; /*0x1410d1cfc*/
    Instance = RBX::Security::KeyRing::getInstance(); /*0x1410d1d0a*/
    v9 = Instance; /*0x1410d1d0f*/
    Data = preauthBlob->Data; /*0x1410d1d12*/
    v60._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410d1d15*/
    v60._Mypair._Myval2._Mysize = 0; /*0x1410d1d19*/
    v60._Mypair._Myval2._Myres = 15; /*0x1410d1d1d*/
    if ( Data != nullptr ) /*0x1410d1d2c*/
    {
      v11 = (char *)operator new(size: 0x20u); /*0x1410d1d32*/
      v60._Mypair._Myval2._Mysize = 16; /*0x1410d1d37*/
      v60._Mypair._Myval2._Myres = 31; /*0x1410d1d3f*/
      *(_OWORD *)v11 = *(_OWORD *)Data; /*0x1410d1d4a*/
      v11[16] = 0; /*0x1410d1d4d*/
      v60._Mypair._Myval2._Bx._Ptr = v11; /*0x1410d1d51*/
    }
    __wind /*0xf1c000000000004c*/
    {
      p_jobId = &this->jobId; /*0x1410d1d55*/
      if ( this->jobId._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d1d65*/
        p_jobId = (std::string *)p_jobId->_Mypair._Myval2._Bx._Ptr; /*0x1410d1d67*/
      v13 = (__m256i *)std::string::append( /*0x1410d1d6e*/
                         this: &v60,
                         _Ptr: p_jobId->_Mypair._Myval2._Bx._Buf,
                         _Count: this->jobId._Mypair._Myval2._Mysize);
      msg_8._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410d1d73*/
      *(_OWORD *)&msg_8._Mypair._Myval2._Mysize = 0u; /*0x1410d1d78*/
      msg_8 = *(std::string *)v13; /*0x1410d1d85*/
      v13->m256i_i64[2] = 0; /*0x1410d1d93*/
      v13->m256i_i64[3] = 15; /*0x1410d1d97*/
      v13->m256i_i8[0] = 0; /*0x1410d1d9f*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v60); /*0xf1c000000000005c*/
    }
    __wind /*0xf1c0000000000064*/
    {
      if ( v60._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d1daa*/
      {
        Ptr = v60._Mypair._Myval2._Bx._Ptr; /*0x1410d1daf*/
        if ( v60._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410d1dbd*/
        {
          Ptr = *((char **)v60._Mypair._Myval2._Bx._Ptr - 1); /*0x1410d1dc3*/
          if ( (unsigned __int64)(v60._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410d1dd2*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410d1dd4*/
        }
        operator delete(ptr: Ptr); /*0x1410d1ddb*/
      }
      v60._Mypair._Myval2._Mysize = 0; /*0x1410d1de0*/
      v60._Mypair._Myval2._Myres = 15; /*0x1410d1de4*/
      v60._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410d1dec*/
      v15 = 1; /*0x1410d1df0*/
      if ( !DFFlag::ForceNewPaBlob2.value && !DFFlag::NewPaBlob2.value ) /*0x1410d1e07*/
      {
        __wind /*0xf1c0000000000040*/
        {
          name.text._Mypair._Myval2._Myres = 15; /*0x1410d1e0d*/
          name.text._Mypair._Myval2._Mysize = 10; /*0x1410d1e15*/
          strcpy(name.text._Mypair._Myval2._Bx._Buf, "PreAuthKey"); /*0x1410d1e25*/
          RBX::Security::KeyRing::getKeyForConsumption( /*0x1410d1e47*/
            this: v9,
            result: (std::vector<unsigned char> *)&v61.m256i_u64[2],
            name: &name.text,
            id: v3);
          if ( name.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d1e55*/
          {
            v16 = name.text._Mypair._Myval2._Bx._Ptr; /*0x1410d1e5a*/
            if ( name.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410d1e68*/
            {
              v16 = *((char **)name.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410d1e6e*/
              if ( (unsigned __int64)(name.text._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x1410d1e7d*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410d1e7f*/
            }
            operator delete(ptr: v16); /*0x1410d1e86*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &name); /*0xf1c0000000000038*/
        }
        name.text._Mypair._Myval2._Mysize = 0; /*0x1410d1e8b*/
        name.text._Mypair._Myval2._Myres = 15; /*0x1410d1e8f*/
        name.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410d1e97*/
        v17 = (char *)v61.m256i_i64[2]; /*0x1410d1e9b*/
        if ( v61.m256i_i64[2] != v61.m256i_i64[3] ) /*0x1410d1ea6*/
        {
          v61.m256i_i64[0] = v61.m256i_i64[2]; /*0x1410d1eaf*/
          v61.m256i_i64[1] = v61.m256i_i64[3] - v61.m256i_i64[2]; /*0x1410d1eb3*/
          p_msg_8 = (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *)&msg_8; /*0x1410d1eb7*/
          if ( msg_8._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d1ec2*/
            p_msg_8 = (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *)msg_8._Mypair._Myval2._Bx._Ptr; /*0x1410d1ec2*/
          __wind /*0xf1c0000000000028*/
          {
            result_8._Location._Parent = p_msg_8; /*0x1410d1ec8*/
            *(_QWORD *)&result_8._Location._Child = msg_8._Mypair._Myval2._Mysize; /*0x1410d1ed2*/
            v19 = (__m256i *)RBX::Crypto::computeKeyedBlake2b( /*0x1410d1f03*/
                               result: (std::string *)&name.x,
                               data: (const RBX::StringView *)&result_8,
                               secret: (const RBX::StringView *)&v61,
                               digestSize: 16);
            if ( &mac_8 != (std::string *)v19 ) /*0x1410d1f0e*/
            {
              if ( mac_8._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d1f19*/
              {
                v20 = mac_8._Mypair._Myval2._Bx._Ptr; /*0x1410d1f1e*/
                if ( mac_8._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410d1f2d*/
                {
                  v20 = *((char **)mac_8._Mypair._Myval2._Bx._Ptr - 1); /*0x1410d1f33*/
                  if ( (unsigned __int64)(mac_8._Mypair._Myval2._Bx._Ptr - v20 - 8) > 0x1F ) /*0x1410d1f42*/
LABEL_42:
                    _invalid_parameter_noinfo_noreturn(); /*0x1410d1fae*/
                }
                operator delete(ptr: v20); /*0x1410d1f44*/
              }
              mac_8._Mypair._Myval2._Mysize = 0; /*0x1410d1f49*/
              mac_8._Mypair._Myval2._Myres = 15; /*0x1410d1f4e*/
              mac_8._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410d1f57*/
              mac_8 = *(std::string *)v19; /*0x1410d1f5f*/
              v19->m256i_i64[2] = 0; /*0x1410d1f6d*/
              v19->m256i_i64[3] = 15; /*0x1410d1f71*/
              v19->m256i_i8[0] = 0; /*0x1410d1f79*/
            }
            if ( v64 >= 0x10 ) /*0x1410d1f84*/
            {
              v21 = *(void **)&name.x; /*0x1410d1f89*/
              if ( v64 + 1 >= 0x1000 ) /*0x1410d1f97*/
              {
                v21 = *(void **)(*(_QWORD *)&name.x - 8LL); /*0x1410d1f9d*/
                if ( (unsigned __int64)(*(_QWORD *)&name.x - (_QWORD)v21 - 8LL) > 0x1F ) /*0x1410d1fac*/
                  goto LABEL_42; /*0x1410d1fac*/
              }
              operator delete(ptr: v21); /*0x1410d1fb5*/
            }
            p_mac_8 = &mac_8; /*0x1410d1fba*/
            if ( mac_8._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d1fc5*/
              p_mac_8 = (std::string *)mac_8._Mypair._Myval2._Bx._Ptr; /*0x1410d1fc5*/
          }
          __unwind
          {
            RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&v61.m256i_u64[2]); /*0xf1c0000000000020*/
          }
          if ( p_mac_8->_Mypair._Myval2._Bx._Ptr == *((char **)Data + 2) /*0x1410d1fe0*/
            && *(_QWORD *)&p_mac_8->_Mypair._Myval2._Bx._Alias[8] == *((_QWORD *)Data + 3) )
          {
            v23 = (void *)v61.m256i_i64[2]; /*0x1410d1fe6*/
            if ( v61.m256i_i64[2] == 0 ) /*0x1410d1fed*/
            {
LABEL_52:
              Mysize = mac_8._Mypair._Myval2._Mysize; /*0x1410d2020*/
LABEL_53:
              p_usedMacs = (std::_Tree<std::_Tmap_traits<std::string,std::shared_ptr<std::string const >,std::less<std::string >,std::allocator<std::pair<std::string const ,std::shared_ptr<std::string const > > >,0> > *)&this->usedMacs; /*0x1410d2025*/
              Myhead = p_usedMacs->_Mypair._Myval2._Myval2._Myhead; /*0x1410d202c*/
              Parent = p_usedMacs->_Mypair._Myval2._Myval2._Myhead->_Parent; /*0x1410d202f*/
              v28 = p_usedMacs->_Mypair._Myval2._Myval2._Myhead; /*0x1410d2033*/
              if ( Parent->_Isnil == 0 ) /*0x1410d203a*/
              {
                do /*0x1410d223d*/
                {
                  p_Myval = (char **)&Parent->_Myval; /*0x1410d2040*/
                  v30 = &mac_8; /*0x1410d2044*/
                  if ( mac_8._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d204f*/
                    v30 = (std::string *)mac_8._Mypair._Myval2._Bx._Ptr; /*0x1410d204f*/
                  v31 = Parent->_Myval.first._Mypair._Myval2._Mysize; /*0x1410d2055*/
                  if ( Parent->_Myval.first._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d205e*/
                    p_Myval = (char **)*p_Myval; /*0x1410d2060*/
                  v32 = Parent->_Myval.first._Mypair._Myval2._Mysize; /*0x1410d2063*/
                  if ( Mysize < v31 ) /*0x1410d2069*/
                    v32 = Mysize; /*0x1410d2069*/
                  v33 = memcmp_0(Buf1: p_Myval, Buf2: v30, Size: v32); /*0x1410d206d*/
                  if ( v33 == 0 ) /*0x1410d2074*/
                  {
                    if ( v31 >= Mysize ) /*0x1410d207d*/
                      v33 = v31 > Mysize; /*0x1410d2223*/
                    else
                      v33 = -1; /*0x1410d2083*/
                  }
                  if ( v33 >= 0 ) /*0x1410d222b*/
                  {
                    Myhead = Parent; /*0x1410d2233*/
                    Parent = Parent->_Left; /*0x1410d2236*/
                  }
                  else
                  {
                    Parent = Parent->_Right; /*0x1410d222d*/
                  }
                }
                while ( Parent->_Isnil == 0 ); /*0x1410d223d*/
                v28 = p_usedMacs->_Mypair._Myval2._Myval2._Myhead; /*0x1410d2243*/
              }
              if ( Myhead->_Isnil != 0 ) /*0x1410d224b*/
                goto LABEL_108; /*0x1410d224b*/
              v40 = (char **)&Myhead->_Myval; /*0x1410d224d*/
              v41 = Myhead->_Myval.first._Mypair._Myval2._Mysize; /*0x1410d2251*/
              if ( Myhead->_Myval.first._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d225a*/
                v40 = (char **)*v40; /*0x1410d225c*/
              v42 = &mac_8; /*0x1410d225f*/
              if ( mac_8._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d226a*/
                v42 = (std::string *)mac_8._Mypair._Myval2._Bx._Ptr; /*0x1410d226a*/
              v43 = Mysize; /*0x1410d2270*/
              if ( v41 < Mysize ) /*0x1410d2276*/
                v43 = Myhead->_Myval.first._Mypair._Myval2._Mysize; /*0x1410d2276*/
              v44 = memcmp_0(Buf1: v42, Buf2: v40, Size: v43); /*0x1410d227a*/
              if ( v44 == 0 ) /*0x1410d2281*/
              {
                if ( Mysize >= v41 ) /*0x1410d2286*/
                  v44 = Mysize > v41; /*0x1410d2292*/
                else
                  v44 = -1; /*0x1410d2288*/
              }
              if ( v44 < 0 || Myhead == v28 ) /*0x1410d229f*/
              {
LABEL_108:
                v45 = std::_Tree<std::_Tmap_traits<std::string,RBX::VoiceChatSession *,std::less<std::string>,std::allocator<std::pair<std::string const,RBX::VoiceChatSession *>>,0>>::_Find_lower_bound<std::string>( /*0x1410d22b8*/
                        this: p_usedMacs,
                        result: &result_8,
                        _Keyval: &mac_8);
                Location = v45->_Location; /*0x1410d22bd*/
                Bound = v45->_Bound; /*0x1410d22c5*/
                if ( Bound->_Isnil != 0 ) /*0x1410d22d2*/
                  goto LABEL_120; /*0x1410d22d2*/
                v47 = (char **)&Bound->_Myval; /*0x1410d22d4*/
                v48 = Bound->_Myval.first._Mypair._Myval2._Mysize; /*0x1410d22d8*/
                if ( Bound->_Myval.first._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d22e1*/
                  v47 = (char **)*v47; /*0x1410d22e3*/
                v49 = &mac_8; /*0x1410d22e6*/
                if ( mac_8._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d22f1*/
                  v49 = (std::string *)mac_8._Mypair._Myval2._Bx._Ptr; /*0x1410d22f1*/
                v50 = Mysize; /*0x1410d22f7*/
                if ( v48 < Mysize ) /*0x1410d22fd*/
                  v50 = Bound->_Myval.first._Mypair._Myval2._Mysize; /*0x1410d22fd*/
                v51 = memcmp_0(Buf1: v49, Buf2: v47, Size: v50); /*0x1410d2301*/
                if ( v51 == 0 ) /*0x1410d2308*/
                {
                  if ( Mysize >= v48 ) /*0x1410d230d*/
                    v51 = Mysize > v48; /*0x1410d2319*/
                  else
                    v51 = -1; /*0x1410d230f*/
                }
                v52 = v51 >> 31; /*0x1410d231c*/
                if ( (_BYTE)v52 != 0 ) /*0x1410d2321*/
                {
LABEL_120:
                  if ( p_usedMacs->_Mypair._Myval2._Myval2._Mysize == 0x3FFFFFFFFFFFFFFLL ) /*0x1410d2335*/
                    std::_Throw_tree_length_error(); /*0x1410d2448*/
                  v53 = p_usedMacs->_Mypair._Myval2._Myval2._Myhead; /*0x1410d233b*/
                  result_8._Location._Parent = (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *)p_usedMacs; /*0x1410d233e*/
                  __wind /*0xf1c0000000000010*/
                  {
                    *(_QWORD *)&result_8._Location._Child = 0; /*0x1410d2343*/
                    v54 = (std::string *)operator new(size: 0x40u); /*0x1410d234d*/
                  }
                  __unwind
                  {
                    std::_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<__int64 const,std::deque<__int64>>,void *>>>::~_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<__int64 const,std::deque<__int64>>,void *>>>(this: (std::_Alloc_construct_ptr<std::allocator<std::_List_node<std::pair<__int64 const ,PluginVersionDetails>,void *> > > *)&result_8); /*0xf1c0000000000008*/
                  }
                  v54[1]._Mypair._Myval2._Mysize = 0; /*0x1410d2353*/
                  v54[1]._Mypair._Myval2._Myres = 0; /*0x1410d2357*/
                  v54[1] = mac_8; /*0x1410d2360*/
                  mac_8._Mypair._Myval2._Mysize = 0; /*0x1410d236d*/
                  mac_8._Mypair._Myval2._Myres = 15; /*0x1410d2372*/
                  mac_8._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410d237b*/
                  v54->_Mypair._Myval2._Bx._Ptr = (char *)v53; /*0x1410d2380*/
                  *(_QWORD *)&v54->_Mypair._Myval2._Bx._Alias[8] = v53; /*0x1410d2383*/
                  v54->_Mypair._Myval2._Mysize = (unsigned __int64)v53; /*0x1410d2387*/
                  LOWORD(v54->_Mypair._Myval2._Myres) = 0; /*0x1410d238b*/
                  result_8._Location = Location; /*0x1410d2391*/
                  std::_Tree_val<std::_Tree_simple_types<std::pair<RBX::Assembly * const,int>>>::_Insert_node( /*0x1410d23a1*/
                    this: &p_usedMacs->_Mypair._Myval2._Myval2,
                    _Loc: &result_8._Location,
                    _Newnode: (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *const)v54);
                }
                v35 = 2 - (v15 != 0); /*0x1410d23ab*/
              }
              else
              {
                v35 = 3; /*0x1410d22a1*/
              }
              goto LABEL_124; /*0x1410d22a6*/
            }
            if ( (unsigned __int64)Bound - v61.m256i_i64[2] < 0x1000 /*0x1410d2015*/
              || (v23 = *(void **)(v61.m256i_i64[2] - 8), (unsigned __int64)(v61.m256i_i64[2] - (_QWORD)v23 - 8) <= 0x1F) )
            {
              operator delete(ptr: v23); /*0x1410d201b*/
              goto LABEL_52; /*0x1410d201b*/
            }
LABEL_69:
            _invalid_parameter_noinfo_noreturn(); /*0x1410d20dc*/
          }
          if ( DFLog::SessionCrypto != 0 ) /*0x1410d2096*/
            FLog::FastLog( /*0x1410d20a2*/
              level: DFLog::SessionCrypto,
              message: "[DFLog::SessionCrypto] RbxOpenRequest2 invalid.",
              arg0: nullptr);
          v17 = (char *)v61.m256i_i64[2]; /*0x1410d20a7*/
        }
        if ( v17 != nullptr ) /*0x1410d20ae*/
        {
          v34 = v17; /*0x1410d20bb*/
          if ( (unsigned __int64)((char *)Bound - v17) >= 0x1000 ) /*0x1410d20c5*/
          {
            v17 = *((char **)v17 - 1); /*0x1410d20cb*/
            if ( (unsigned __int64)(v34 - v17 - 8) > 0x1F ) /*0x1410d20da*/
              goto LABEL_69; /*0x1410d20da*/
          }
          operator delete(ptr: v17); /*0x1410d20e3*/
          v35 = 0; /*0x1410d20e8*/
LABEL_124:
          if ( msg_8._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d23b7*/
          {
            v55 = msg_8._Mypair._Myval2._Bx._Ptr; /*0x1410d23bc*/
            if ( msg_8._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410d23cb*/
            {
              v55 = *((char **)msg_8._Mypair._Myval2._Bx._Ptr - 1); /*0x1410d23d1*/
              if ( (unsigned __int64)(msg_8._Mypair._Myval2._Bx._Ptr - v55 - 8) > 0x1F ) /*0x1410d23e0*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410d23e2*/
            }
            operator delete(ptr: v55); /*0x1410d23e9*/
          }
          msg_8._Mypair._Myval2._Mysize = 0; /*0x1410d23ee*/
          msg_8._Mypair._Myval2._Myres = 15; /*0x1410d23f3*/
          msg_8._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410d23fc*/
          if ( mac_8._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d240a*/
          {
            v56 = mac_8._Mypair._Myval2._Bx._Ptr; /*0x1410d240f*/
            if ( mac_8._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410d241e*/
            {
              v56 = *((char **)mac_8._Mypair._Myval2._Bx._Ptr - 1); /*0x1410d2424*/
              if ( (unsigned __int64)(mac_8._Mypair._Myval2._Bx._Ptr - v56 - 8) > 0x1F ) /*0x1410d2433*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410d2435*/
            }
            operator delete(ptr: v56); /*0x1410d243c*/
          }
          return v35; /*0x1410d2443*/
        }
LABEL_87:
        v35 = 0; /*0x1410d2218*/
        goto LABEL_124; /*0x1410d221b*/
      }
      v36 = (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *)&msg_8; /*0x1410d20f0*/
      if ( msg_8._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d20fb*/
        v36 = (std::_Tree_node<std::pair<std::string const ,std::shared_ptr<std::string const > >,void *> *)msg_8._Mypair._Myval2._Bx._Ptr; /*0x1410d20fb*/
      result_8._Location._Parent = v36; /*0x1410d2101*/
      *(_QWORD *)&result_8._Location._Child = msg_8._Mypair._Myval2._Mysize; /*0x1410d210b*/
      *(RBX::StringView *)v61.m256i_i8 = *preauthBlob; /*0x1410d2113*/
      v37 = (__m256i *)RBX::Security::SessionCrypto::verifyPreauthMac( /*0x1410d2134*/
                         result: (std::pair<std::string,bool> *)&name.x,
                         msg: (RBX::StringView *)&result_8,
                         preauthBlob: (RBX::StringView *)&v61);
      if ( &mac_8 != (std::string *)v37 ) /*0x1410d213f*/
      {
        if ( mac_8._Mypair._Myval2._Myres >= 0x10 ) /*0x1410d214a*/
        {
          v38 = mac_8._Mypair._Myval2._Bx._Ptr; /*0x1410d214f*/
          if ( mac_8._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410d215e*/
          {
            v38 = *((char **)mac_8._Mypair._Myval2._Bx._Ptr - 1); /*0x1410d2164*/
            if ( (unsigned __int64)(mac_8._Mypair._Myval2._Bx._Ptr - v38 - 8) > 0x1F ) /*0x1410d2173*/
LABEL_82:
              _invalid_parameter_noinfo_noreturn(); /*0x1410d21e4*/
          }
          operator delete(ptr: v38); /*0x1410d2175*/
        }
        mac_8._Mypair._Myval2._Mysize = 0; /*0x1410d217a*/
        mac_8._Mypair._Myval2._Myres = 15; /*0x1410d217f*/
        mac_8._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410d2188*/
        mac_8 = *(std::string *)v37; /*0x1410d2190*/
        v37->m256i_i64[2] = 0; /*0x1410d219e*/
        v37->m256i_i64[3] = 15; /*0x1410d21a2*/
        v37->m256i_i8[0] = 0; /*0x1410d21aa*/
      }
      v15 = v37[1].m256i_i8[0]; /*0x1410d21ad*/
      if ( v64 >= 0x10 ) /*0x1410d21ba*/
      {
        v39 = *(void **)&name.x; /*0x1410d21bf*/
        if ( v64 + 1 >= 0x1000 ) /*0x1410d21cd*/
        {
          v39 = *(void **)(*(_QWORD *)&name.x - 8LL); /*0x1410d21d3*/
          if ( (unsigned __int64)(*(_QWORD *)&name.x - (_QWORD)v39 - 8LL) > 0x1F ) /*0x1410d21e2*/
            goto LABEL_82; /*0x1410d21e2*/
        }
        operator delete(ptr: v39); /*0x1410d21eb*/
      }
      Mysize = mac_8._Mypair._Myval2._Mysize; /*0x1410d21f0*/
      if ( mac_8._Mypair._Myval2._Mysize != 0 ) /*0x1410d21f8*/
        goto LABEL_53; /*0x1410d21f8*/
      if ( DFLog::SessionCrypto != 0 ) /*0x1410d2207*/
        FLog::FastLog( /*0x1410d2213*/
          level: DFLog::SessionCrypto,
          message: "[DFLog::SessionCrypto] RbxOpenRequest2 invalid.",
          arg0: nullptr);
      goto LABEL_87; /*0x1410d2213*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&msg_8); /*0xf1c0000000000074*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&mac_8); /*0xf1c0000000000080*/
  }
}

// END RakPeer part 1/1, 171 functions
