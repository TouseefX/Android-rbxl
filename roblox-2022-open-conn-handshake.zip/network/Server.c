// Server -- 2022 Studio + full PDB
// tier 3, 44 functions


// Address: 0x1401ae290 | Name: _dynamic_initializer_for__RBX::Network::Server::createReplicator__
int dynamic_initializer_for__RBX::Network::Server::createReplicator__()
{
  return atexit(function: dynamic_atexit_destructor_for__RBX::Network::Server::createReplicator__);
}

// Address: 0x140a2b600 | Name: ??$Class_getDescriptor@VServer@Network@RBX@@@@YAAEAVClassDescriptor@Reflection@RBX@@XZ
// attributes: thunk
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptor<RBX::Network::Server>()
{
  return RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Server>();
}

// Address: 0x140a2b620 | Name: ??$callDoGetClassIndex@VServer@Network@RBX@@@ServiceProvider@RBX@@CAXXZ
// attributes: thunk
unsigned __int64 __fastcall RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Server>()
{
  return RBX::ServiceProvider::doGetClassIndex<RBX::Network::Server>();
}

// Address: 0x140a2b9a0 | Name: ??$create@VServer@Network@RBX@@$$V@?$Creatable@VInstance@RBX@@@RBX@@SA?AV?$shared_ptr@VServer@Network@RBX@@@std@@XZ
RBX::Network::Server *__fastcall RBX::Creatable<RBX::Instance>::create<RBX::Network::Server,>(
        RBX::Network::Server *result)
{
  const unsigned int *memoryCategory; // rcx
  unsigned int v3; // ecx
  unsigned int v4; // eax
  RBX::Network::Server *v5; // rax
  RBX::File *v6; // rbp
  RBX::Network::Server *v7; // rax
  RBX::File *v8; // rdi
  std::_Ref_count_base *v9; // rax
  std::_Ref_count_base *Ptr; // rbx
  std::_Ref_count_base *Rep; // rax
  std::_Ref_count_base *v12; // rax
  volatile signed __int32 *v13; // rcx
  signed __int32 v14; // eax
  signed __int32 v15; // eax
  unsigned int parent; // ecx
  __int64 v17; // rcx
  RBX::Network::Server *v18; // rax
  __int64 v19; // [rsp+0h] [rbp-58h] BYREF
  std::_Temporary_owner_del<RBX::File *,RBX::Creatable<RBX::Instance>::Deleter<RBX::File> > v20; // [rsp+20h] [rbp-38h] BYREF
  RBX::Network::Server *v21; // [rsp+60h] [rbp+8h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::Network::Server,void> scope; // [rsp+68h] [rbp+10h] BYREF
  std::_Ref_count_base *v23; // [rsp+70h] [rbp+18h]

  v21 = result; /*0x140a2b9a5*/
  memoryCategory = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Server>()->memoryCategory; /*0x140a2b9b9*/
  if ( memoryCategory != nullptr ) /*0x140a2b9c3*/
    v3 = *memoryCategory; /*0x140a2b9c5*/
  else
    v3 = RBX::Memory::InstanceObject; /*0x140a2b9c9*/
  v4 = RBX::Memory::setCurrentCategory(category: v3); /*0x140a2b9cf*/
  scope.parent = v4; /*0x140a2b9d4*/
  __wind /*0xf1c0000000000070*/
  {
    v5 = (RBX::Network::Server *)operator new(size: 0xCD8u); /*0x140a2b9dd*/
    v21 = v5; /*0x140a2b9e2*/
    __wind /*0xf1c0000000000064*/
    {
      v6 = nullptr; /*0x140a2b9e7*/
      if ( v5 != nullptr ) /*0x140a2b9ec*/
      {
        v7 = RBX::Network::Server::Server(this: v5); /*0x140a2b9f1*/
        v8 = (RBX::File *)v7; /*0x140a2b9f6*/
      }
      else
      {
        v8 = nullptr; /*0x140a2b9fb*/
      }
    }
    __unwind
    {
      operator delete(ptr: v21); /*0x1431a5a12*/
    }
    result->__vftable = nullptr; /*0x140a2b9fe*/
    result->_Wptr._Ptr = nullptr; /*0x140a2ba01*/
    v20._Ptr = v8; /*0x140a2ba0e*/
    v20._Dt = (RBX::Creatable<RBX::Instance>::Deleter<RBX::File> *)&v21; /*0x140a2ba18*/
    v20._Call_deleter = true; /*0x140a2ba1d*/
    __wind /*0xf1c0000000000028*/
    {
      v9 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x140a2ba27*/
      Ptr = v9; /*0x140a2ba2c*/
      v23 = v9; /*0x140a2ba2f*/
      if ( v9 != nullptr ) /*0x140a2ba37*/
      {
        *v9 = 0; /*0x140a2ba3c*/
        v9->_Uses = 1; /*0x140a2ba3f*/
        v9->_Weaks = 1; /*0x140a2ba46*/
        v9->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count_resource<RBX::Network::Server *,RBX::Creatable<RBX::Instance>::Deleter<RBX::Network::Server>>::`vftable'; /*0x140a2ba54*/
        v9[1].__vftable = (std::_Ref_count_base_vtbl *)v8; /*0x140a2ba57*/
      }
      else
      {
        Ptr = nullptr; /*0x140a2ba5d*/
      }
      result->__vftable = (RBX::Network::Server_vtbl *)v8; /*0x140a2ba60*/
      result->_Wptr._Ptr = (RBX::Reflection::DescribedBase *)Ptr; /*0x140a2ba63*/
      if ( v8 != nullptr ) /*0x140a2ba6a*/
      {
        Rep = v8->_Wptr._Rep; /*0x140a2ba70*/
        if ( Rep == nullptr || Rep->_Uses == 0 ) /*0x140a2ba7d*/
        {
          if ( Ptr != nullptr ) /*0x140a2ba82*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&Ptr->_Uses); /*0x140a2ba84*/
            Ptr = (std::_Ref_count_base *)result->_Wptr._Ptr; /*0x140a2ba88*/
          }
          v12 = nullptr; /*0x140a2ba8c*/
          if ( Ptr != nullptr ) /*0x140a2ba92*/
          {
            v6 = v8; /*0x140a2ba94*/
            v12 = Ptr; /*0x140a2ba97*/
            _InterlockedIncrement((volatile signed __int32 *)&Ptr->_Weaks); /*0x140a2ba9a*/
          }
          v8->_Wptr._Ptr = v6; /*0x140a2ba9e*/
          v13 = (volatile signed __int32 *)v8->_Wptr._Rep; /*0x140a2baa2*/
          v8->_Wptr._Rep = v12; /*0x140a2baa6*/
          if ( v13 != nullptr ) /*0x140a2bab2*/
          {
            v14 = _InterlockedExchangeAdd(v13 + 3, 0xFFFFFFFF); /*0x140a2bab6*/
            if ( v14 == 1 ) /*0x140a2babe*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 8LL))(a1: v13); /*0x140a2bac3*/
          }
          if ( Ptr != nullptr ) /*0x140a2bac9*/
          {
            v15 = _InterlockedExchangeAdd((volatile signed __int32 *)&Ptr->_Uses, 0xFFFFFFFF); /*0x140a2bacd*/
            if ( v15 == 1 ) /*0x140a2bad5*/
            {
              Ptr->_Destroy(this: Ptr); /*0x140a2badd*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Ptr->_Weaks, 0xFFFFFFFF) == 1 ) /*0x140a2bae7*/
                Ptr->_Delete_this(this: Ptr); /*0x140a2baef*/
            }
          }
        }
      }
      parent = scope.parent; /*0x140a2baf3*/
    }
    __unwind
    {
      std::_Temporary_owner_del<RBX::ScriptService *,RBX::Creatable<RBX::Instance>::Deleter<RBX::ScriptService>>::~_Temporary_owner_del<RBX::ScriptService *,RBX::Creatable<RBX::Instance>::Deleter<RBX::ScriptService>>(this: &v20); /*0xf1c0000000000038*/
    }
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&scope); /*0xf1c0000000000044*/
  }
  __wind /*0xf1c000000000004c*/
  {
    RBX::Memory::setCurrentCategory(category: parent); /*0x140a2baf7*/
    v18 = result; /*0x140a2bafd*/
  }
  __unwind
  {
    __std_terminate(a1: v17, a2: &v19); /*0x142f39fa8*/
  }
  return v18; /*0x140a2bb00*/
}

// Address: 0x140a2bb10 | Name: ??$create@VServer@Network@RBX@@@ServiceProvider@RBX@@QEBAPEAVServer@Network@1@XZ
RBX::Network::Server *__fastcall RBX::ServiceProvider::create<RBX::Network::Server>(RBX::ServiceProvider *this)
{
  unsigned __int64 v2; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v3; // rdi
  RBX::Network::Server *result; // rax
  const RBX::Name *v5; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *Rep; // rbx
  RBX::Network::Server *Ptr; // rdi
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > *h; // rcx
  unsigned __int64 Mysize; // rax
  void (__fastcall *setName)(struct RBX::Network::Server *, const std::string *); // rbx
  __int64 v12; // rax
  unsigned __int64 v13; // rax
  std::shared_ptr<RBX::Instance> *v14; // rax
  std::_Ref_count_base *v15; // rcx
  volatile signed __int32 *v16; // rbx
  std::_Ref_count_base *v17; // rbx
  std::shared_ptr<RBX::Network::Server> s; // [rsp+20h] [rbp-38h] BYREF
  std::shared_ptr<std::vector<RBX::Guid> > v19; // [rsp+30h] [rbp-28h] BYREF
  std::shared_ptr<RBX::Instance> v20; // [rsp+40h] [rbp-18h] BYREF

  boost::call_once( /*0x140a2bb35*/
    flag: &`RBX::ServiceProvider::getClassIndex<RBX::Network::Server>'::`2'::flag,
    f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Server>);
  v2 = RBX::ServiceProvider::doGetClassIndex<RBX::Network::Server>(); /*0x140a2bb3a*/
  v3 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt(this, index: v2); /*0x140a2bb4a*/
  result = (RBX::Network::Server *)v3->_Ptr; /*0x140a2bb4d*/
  if ( v3->_Ptr == nullptr ) /*0x140a2bb53*/
  {
    v5 = RBX::Reflection::Class_getNamePtr<RBX::Network::Server>(); /*0x140a2bb59*/
    ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName( /*0x140a2bb69*/
                                                                                              this,
                                                                                              result: &v20,
                                                                                              className: v5);
    std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v3, _Right: ServiceByClassName); /*0x140a2bb74*/
    Rep = v20._Rep; /*0x140a2bb7e*/
    if ( v20._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v20._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x140a2bb92*/
    {
      Rep->_Destroy(this: Rep); /*0x140a2bb9a*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x140a2bba6*/
        Rep->_Delete_this(this: Rep); /*0x140a2bbae*/
    }
    result = (RBX::Network::Server *)v3->_Ptr; /*0x140a2bbb1*/
    if ( v3->_Ptr == nullptr ) /*0x140a2bbb7*/
    {
      RBX::Creatable<RBX::Instance>::create<RBX::Network::Server,>(result: (RBX::Network::Server *)&s); /*0x140a2bbc2*/
      Ptr = s._Ptr; /*0x140a2bbc8*/
      if ( DFFlag::ServiceProviderSetName.value ) /*0x140a2bbd4*/
      {
        h = s._Ptr->name.h.h; /*0x140a2bbd6*/
        Mysize = h->x.x._Mypair._Myval2._Mysize; /*0x140a2bbda*/
        if ( h->x.x._Mypair._Myval2._Myres >= 0x10 ) /*0x140a2bbe3*/
          h = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > *)h->x.x._Mypair._Myval2._Bx._Ptr; /*0x140a2bbe5*/
        if ( Mysize == 8 /*0x140a2bbff*/
          && memcmp_0(
               Buf1: h,
               Buf2: &std::_Ref_count_obj2<RBX::AssetImport::Errors::FileEmptyError>::`vftable'[4],
               Size: 8u) == 0 )
        {
          setName = Ptr->setName; /*0x140a2bc04*/
          v12 = (__int64)Ptr->getClassName(this: Ptr); /*0x140a2bc0e*/
          setName(this: Ptr, a2: (const std::string *)v12); /*0x140a2bc17*/
        }
      }
      v19 = 0; /*0x140a2bc1c*/
      RBX::Instance::setAndLockParent(this: Ptr, instance: this, destroying: false, destroyedGuids: &v19); /*0x140a2bc30*/
      boost::call_once( /*0x140a2bc43*/
        flag: &`RBX::ServiceProvider::getClassIndex<RBX::Network::Server>'::`2'::flag,
        f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Server>);
      v13 = RBX::ServiceProvider::doGetClassIndex<RBX::Network::Server>(); /*0x140a2bc48*/
      v14 = RBX::ServiceProvider::refAt(this, index: v13); /*0x140a2bc53*/
      v15 = s._Rep; /*0x140a2bc58*/
      if ( s._Rep != nullptr ) /*0x140a2bc60*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&s._Rep->_Uses); /*0x140a2bc62*/
        v15 = s._Rep; /*0x140a2bc66*/
        Ptr = s._Ptr; /*0x140a2bc6b*/
      }
      v14->_Ptr = Ptr; /*0x140a2bc70*/
      v16 = (volatile signed __int32 *)v14->_Rep; /*0x140a2bc73*/
      v14->_Rep = v15; /*0x140a2bc77*/
      if ( v16 != nullptr ) /*0x140a2bc7e*/
      {
        if ( _InterlockedExchangeAdd(v16 + 2, 0xFFFFFFFF) == 1 ) /*0x140a2bc8a*/
        {
          (**(void (__fastcall ***)(volatile signed __int32 *))v16)(a1: v16); /*0x140a2bc92*/
          if ( _InterlockedExchangeAdd(v16 + 3, 0xFFFFFFFF) == 1 ) /*0x140a2bc9e*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 8LL))(a1: v16); /*0x140a2bca6*/
        }
        Ptr = s._Ptr; /*0x140a2bca9*/
        v15 = s._Rep; /*0x140a2bcae*/
      }
      if ( v15 != nullptr ) /*0x140a2bcb6*/
      {
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v15->_Uses, 0xFFFFFFFF) == 1 ) /*0x140a2bcc2*/
        {
          v17 = s._Rep; /*0x140a2bcc4*/
          s._Rep->_Destroy(this: s._Rep); /*0x140a2bccf*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v17->_Weaks, 0xFFFFFFFF) == 1 ) /*0x140a2bcd9*/
            s._Rep->_Delete_this(this: s._Rep); /*0x140a2bce3*/
        }
        return s._Ptr; /*0x140a2bce6*/
      }
      return Ptr; /*0x140a2bceb*/
    }
  }
  return result; /*0x140a2bcee*/
}

// Address: 0x140a2bd80 | Name: ??$doGetClassIndex@VServer@Network@RBX@@@ServiceProvider@RBX@@CA_KXZ
unsigned __int64 __fastcall RBX::ServiceProvider::doGetClassIndex<RBX::Network::Server>()
{
  unsigned __int64 result; // rax

  if ( __TSS0__1____doGetClassIndex_VServer_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA <= *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x140a2bda5*/
    return `RBX::ServiceProvider::doGetClassIndex<RBX::Network::Server>'::`2'::index; /*0x140a2bda5*/
  Init_thread_header(pOnce: &__TSS0__1____doGetClassIndex_VServer_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA); /*0x140a2bdba*/
  if ( __TSS0__1____doGetClassIndex_VServer_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA != -1 ) /*0x140a2bdc6*/
    return `RBX::ServiceProvider::doGetClassIndex<RBX::Network::Server>'::`2'::index; /*0x140a2bda7*/
  __wind /*0xf1c000000000001c*/
  {
    `RBX::ServiceProvider::doGetClassIndex<RBX::Network::Server>'::`2'::index = RBX::ServiceProvider::newIndex(); /*0x140a2bdcd*/
    Init_thread_footer(pOnce: &__TSS0__1____doGetClassIndex_VServer_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA); /*0x140a2bddb*/
    result = `RBX::ServiceProvider::doGetClassIndex<RBX::Network::Server>'::`2'::index; /*0x140a2bde0*/
  }
  __unwind
  {
    Init_thread_abort(pOnce: &__TSS0__1____doGetClassIndex_VServer_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA); /*0x1431a5a37*/
  }
  return result; /*0x140a2bdae*/
}

// Address: 0x140a2bdf0 | Name: ??$refByClass@VServer@Network@RBX@@@ServiceProvider@RBX@@AEBAAEAV?$shared_ptr@VInstance@RBX@@@std@@XZ
std::shared_ptr<RBX::Instance> *__fastcall RBX::ServiceProvider::refByClass<RBX::Network::Server>(
        RBX::ServiceProvider *this)
{
  unsigned __int64 v2; // rax
  std::shared_ptr<RBX::Instance> *result; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v4; // rdi
  const RBX::Name *v5; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *Rep; // rbx
  std::shared_ptr<RBX::Instance> v8; // [rsp+20h] [rbp-18h] BYREF

  boost::call_once( /*0x140a2be0b*/
    flag: &`RBX::ServiceProvider::getClassIndex<RBX::Network::Server>'::`2'::flag,
    f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Server>);
  v2 = RBX::ServiceProvider::doGetClassIndex<RBX::Network::Server>(); /*0x140a2be10*/
  result = RBX::ServiceProvider::refAt(this, index: v2); /*0x140a2be1b*/
  v4 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)result; /*0x140a2be20*/
  if ( result->_Ptr == nullptr ) /*0x140a2be27*/
  {
    v5 = RBX::Reflection::Class_getNamePtr<RBX::Network::Server>(); /*0x140a2be29*/
    ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName( /*0x140a2be39*/
                                                                                              this,
                                                                                              result: &v8,
                                                                                              className: v5);
    std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v4, _Right: ServiceByClassName); /*0x140a2be44*/
    Rep = v8._Rep; /*0x140a2be49*/
    if ( v8._Rep != nullptr ) /*0x140a2be51*/
    {
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v8._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x140a2be67*/
      {
        Rep->_Destroy(this: Rep); /*0x140a2be6f*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x140a2be79*/
          Rep->_Delete_this(this: Rep); /*0x140a2be81*/
      }
      return (std::shared_ptr<RBX::Instance> *)v4; /*0x140a2be89*/
    }
    else
    {
      return (std::shared_ptr<RBX::Instance> *)v4; /*0x140a2be9c*/
    }
  }
  return result; /*0x140a2be8c*/
}

// Address: 0x14100a8a0 | Name: ??$Class_getDescriptorPtr@VServer@Network@RBX@@@Reflection@RBX@@YAAEAVClassDescriptor@01@XZ
RBX::ClassRegistrar<RBX::Network::Server,1> *__fastcall RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Server>()
{
  RBX::ClassRegistrar<RBX::Network::Server,1> *result; // rax
  RBX::ClassRegistrar<RBX::Network::Peer,0> *v1; // rax
  RBX::Reflection::ClassDescriptor::Attributes v3; // [rsp+60h] [rbp-28h] BYREF
  RBX::Reflection::ClassDescriptor::Attributes v4; // 0:^50.32

  result = (RBX::ClassRegistrar<RBX::Network::Server,1> *)ret_85; /*0x14100a8ad*/
  if ( ret_85 == nullptr ) /*0x14100a8b7*/
  {
    if ( _TSS0_511 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x14100a8e3*/
    {
      Init_thread_header(pOnce: &_TSS0_511); /*0x14100a907*/
      if ( _TSS0_511 == -1 ) /*0x14100a913*/
      {
        v4.isDeprecated = false; /*0x14100a915*/
        v4.preferred = nullptr; /*0x14100a91c*/
        v4.threadSafety = Unset; /*0x14100a921*/
        v4.flags = INTERNAL_LOCAL; /*0x14100a925*/
        __wind /*0xf1c000000000005c*/
        {
          v1 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Peer>(); /*0x14100a92d*/
          v3 = v4; /*0x14100a937*/
          RBX::Reflection::ClassDescriptor::ClassDescriptor( /*0x14100a969*/
            this: &reg_77.desc,
            base: &v1->desc,
            name: (const char *)&RBX::Creator<RBX::Network::Server>::`vftable'[3],
            isService: true,
            attributes: &v3,
            security: (RBX::Security::Permissions)0,
            memoryCategory: nullptr);
          __wind /*0xf1c0000000000050*/
          {
            reg_77.creator.__vftable = (RBX::Creator<RBX::Network::Server>_vtbl *)RBX::Creator<RBX::Network::Server>::`vftable'; /*0x14100a976*/
            __wind /*0xf1c0000000000020*/
            {
              RBX::Creatable<RBX::Instance>::setCreator(desc: &reg_77.desc, creator: &reg_77.creator); /*0x14100a987*/
              atexit(function: RBX::Reflection::Class_getDescriptorPtr_RBX::Network::Server__::_2_::_dynamic_atexit_destructor_for__reg__); /*0x14100a994*/
              Init_thread_footer(pOnce: &_TSS0_511); /*0x14100a9a1*/
            }
            __unwind
            {
              RBX::Creator<RBX::Network::Server>::~Creator<RBX::Network::Server>(this: &reg_77.creator); /*0x1431e50fe*/
            }
          }
          __unwind
          {
            RBX::Reflection::ClassDescriptor::~ClassDescriptor(this: &reg_77.desc); /*0x1431e50e7*/
          }
        }
        __unwind
        {
          Init_thread_abort(pOnce: &_TSS0_511); /*0x1431e50d7*/
        }
      }
    }
    ret_85 = (RBX::Reflection::ClassDescriptor *)&reg_77; /*0x14100a8e5*/
    return &reg_77; /*0x14100a8ec*/
  }
  return result; /*0x14100a8ef*/
}

// Address: 0x14100abf0 | Name: ??$Class_getNamePtr@VServer@Network@RBX@@@Reflection@RBX@@YAAEBVName@1@XZ
const RBX::Name *__fastcall RBX::Reflection::Class_getNamePtr<RBX::Network::Server>()
{
  const RBX::Name *result; // rax

  result = name_41; /*0x14100abf4*/
  if ( name_41 == nullptr ) /*0x14100abfe*/
  {
    result = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Server>()->desc.name; /*0x14100ac05*/
    name_41 = result; /*0x14100ac09*/
  }
  return result; /*0x14100ac10*/
}

// Address: 0x14101dd50 | Name: ??$find@VServer@Network@RBX@@@ServiceProvider@RBX@@QEBAPEAVServer@Network@1@XZ
RBX::Network::Server *__fastcall RBX::ServiceProvider::find<RBX::Network::Server>(RBX::ServiceProvider *this)
{
  return (RBX::Network::Server *)RBX::ServiceProvider::refByClass<RBX::Network::Server>(this)->_Ptr; /*0x14101dd5c*/
}

// Address: 0x141021ce0 | Name: ??0Server@Network@RBX@@QEAA@XZ
RBX::Network::Server *__fastcall RBX::Network::Server::Server(RBX::Network::Server *this)
{
  RBX::ClassRegistrar<RBX::Network::Server,1> *v2; // rax
  rtc::RefCountedObject<webrtc::RtpReceiverInternal> *ClassEntry; // rax
  RBX::NetworkSettings *v4; // rsi
  RBX::GlobalAdvancedSettings *Ptr; // rsi
  _Mtx_internal_imp_t *p_mx; // rbx
  int v7; // eax
  std::_Ref_count_base *Rep; // rbx
  std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *v9; // rax
  const unsigned __int64 *v10; // rax
  const unsigned __int64 *v11; // r9
  unsigned __int64 v12; // r8
  unsigned __int64 *v13; // rax
  const unsigned __int64 *v14; // rax
  const unsigned __int64 *v15; // r10
  unsigned __int64 v16; // rdx
  unsigned __int64 *v17; // rax
  std::_Tree_node<std::string,void *> *v18; // rax
  std::_Tree_node<std::string,void *> *v19; // rax
  RBX::Security::Context *v20; // rbx
  char *v21; // rcx
  const RBX::SharedString *v22; // rax
  const RBX::SharedString *v23; // rax
  std::shared_ptr<RBX::NetworkSettings> v25; // [rsp+30h] [rbp-50h] BYREF
  std::shared_ptr<std::vector<RBX::Guid> > v26; // [rsp+40h] [rbp-40h] BYREF
  RBX::SharedString v27; // [rsp+50h] [rbp-30h] BYREF
  std::string value; // [rsp+60h] [rbp-20h] BYREF
  MicroProfileScopeLock v30; // [rsp+B8h] [rbp+38h] BYREF

  RBX::Network::Peer::Peer(this); /*0x141021cf8*/
  __wind /*0xf1c000000000028c*/
  {
    this->__vftable = (RBX::Network::Server_vtbl *)RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer>::`vftable'; /*0x141021d05*/
    this->descriptor = (const RBX::Reflection::ClassDescriptor *)RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Server>(); /*0x141021d0d*/
    if ( FFlag::g_flagsLoaded && FFlag::DebugTraceCreatableCounts3.value ) /*0x141021d21*/
    {
      v2 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Server>(); /*0x141021d23*/
      ClassEntry = (rtc::RefCountedObject<webrtc::RtpReceiverInternal> *)RBX::Reflection::Stat::getClassEntry(desc: &v2->desc); /*0x141021d2b*/
      rtc::RefCountedObject<rtc::RefCountInterface>::AddRef(this: ClassEntry); /*0x141021d33*/
    }
  }
  __unwind
  {
    RBX::Network::Peer::~Peer(this); /*0xf1c000000000029c*/
  }
  __wind /*0xf1c00000000002a4*/
  {
    this->isPublic = true; /*0x141021d39*/
    this->__vftable = (RBX::Network::Server_vtbl *)RBX::Network::Server::`vftable'; /*0x141021d47*/
    this->outgoingPort = 0; /*0x141021d4d*/
    this->players._Ptr = nullptr; /*0x141021d54*/
    this->players._Rep = nullptr; /*0x141021d5b*/
    this->networkOwnerJob._Ptr = nullptr; /*0x141021d62*/
    this->networkOwnerJob._Rep = nullptr; /*0x141021d69*/
    this->romarkPhaseTrackingJob._Ptr = nullptr; /*0x141021d70*/
    this->romarkPhaseTrackingJob._Rep = nullptr; /*0x141021d77*/
    this->serverReplicationMode = ReplicationMode_Client; /*0x141021d7e*/
    __wind /*0xf1c0000000000358*/
    {
      __wind /*0xf1c0000000000360*/
      {
        __wind /*0xf1c0000000000368*/
        {
          RBX::Network::MegaReplicator::MegaReplicator(this: &this->megaReplicator, cacheAvailable: true, server: this); /*0x141021d91*/
          __wind /*0xf1c0000000000388*/
          {
            __wind /*0xf1c0000000000390*/
            {
              __wind /*0xf1c0000000000398*/
              {
                __wind /*0xf1c00000000003a0*/
                {
                  __wind /*0xf1c00000000003a8*/
                  {
                    this->closingConnection.con.weak_slot.p_ = nullptr; /*0x141021d97*/
                    this->itemAddedConnection.con.weak_slot.p_ = nullptr; /*0x141021d9e*/
                    this->workspaceLoadedConnection.con.weak_slot.p_ = nullptr; /*0x141021da5*/
                    this->ipCache._Mypair._Myval2._Myfirst = nullptr; /*0x141021dac*/
                    this->ipCache._Mypair._Myval2._Mylast = nullptr; /*0x141021db3*/
                    this->ipCache._Mypair._Myval2._Myend = nullptr; /*0x141021dba*/
                    *(_WORD *)&this->isPlayerAuthenticationRequired = 0; /*0x141021dc1*/
                    v4 = (RBX::NetworkSettings *)RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing; /*0x141021dc9*/
                    if ( RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing == nullptr ) /*0x141021dd3*/
                    {
                      Ptr = RBX::GlobalAdvancedSettings::singleton()->_Ptr; /*0x141021dde*/
                      p_mx = (_Mtx_internal_imp_t *)&Ptr->mx; /*0x141021de1*/
                      v30.m = (std::recursive_mutex *)&Ptr->mx; /*0x141021de8*/
                      v7 = Mtx_lock_0(a1: (_Mtx_t)&Ptr->mx); /*0x141021def*/
                      if ( v7 != 0 ) /*0x141021df6*/
                      {
                        std::_Throw_C_error(a1: v7); /*0x141022288*/
                        JUMPOUT(0x14102228DLL); /*0x14102228d*/
                      }
                      __wind /*0xf1c0000000000258*/
                      {
                        if ( RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing != nullptr ) /*0x141021e03*/
                        {
                          __eh34_enter_wind_state(10, 11); /*0xf1c0000000000248*/
                        }
                        else
                        {
                          RBX::Creatable<RBX::Instance>::create<RBX::NetworkSettings,>(result: &v25); /*0x141021e09*/
                          __eh34_enter_wind_state(10, 11); /*0xf1c0000000000250*/
                          v26 = 0; /*0x141021e12*/
                          RBX::Instance::setParentInternal( /*0x141021e2d*/
                            this: v25._Ptr,
                            newParent: Ptr,
                            ignoreLock: false,
                            destroying: false,
                            destroyedGuids: &v26);
                          if ( v25._Rep != nullptr ) /*0x141021e3a*/
                          {
                            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v25._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141021e49*/
                            {
                              Rep = v25._Rep; /*0x141021e4b*/
                              v25._Rep->_Destroy(this: v25._Rep); /*0x141021e55*/
                              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141021e64*/
                                v25._Rep->_Delete_this(this: v25._Rep); /*0x141021e6d*/
                            }
                            p_mx = (_Mtx_internal_imp_t *)v30.m; /*0x141021e70*/
                          }
                        }
                        v4 = (RBX::NetworkSettings *)RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing; /*0x141021e74*/
                        Mtx_unlock_0(a1: p_mx); /*0x141021e7e*/
                        if ( __eh34_unwind(11) ) /*0xf1c0000000000374*/
                        {
                          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v25); /*0xf1c0000000000378*/
                          __eh34_continue_unwinding(11, 10); /*0xf1c000000000037c*/
                        }
                        __eh34_exit_wind_state(11, 10); /*0xf1c0000000000380*/
                      }
                      __unwind
                      {
                        std::scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>::~scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>(this: &v30); /*0xf1c0000000000268*/
                      }
                    }
                    __wind /*0xf1c0000000000270*/
                    {
                      __wind /*0xf1c0000000000278*/
                      {
                        __wind /*0xf1c0000000000280*/
                        {
                          this->networkSettings = v4; /*0x141021e83*/
                          this->lastReportedPhysicsUnthrottledWorldStepId = 0; /*0x141021e8a*/
                          this->lastReportedPhysicsWallTime = -1.0; /*0x141021e9b*/
                          this->legalScripts._Mypair._Myval2._Myfirst = nullptr; /*0x141021ea2*/
                          this->legalScripts._Mypair._Myval2._Mylast = nullptr; /*0x141021ea9*/
                          this->legalScripts._Mypair._Myval2._Myend = nullptr; /*0x141021eb0*/
                          this->scriptsBySharedSource.table_.current_ = false; /*0x141021eb7*/
                          this->scriptsBySharedSource.table_.bucket_count_ = 16; /*0x141021ebe*/
                          this->scriptsBySharedSource.table_.size_ = 0; /*0x141021ec9*/
                          this->scriptsBySharedSource.table_.mlf_ = 1.0; /*0x141021ed0*/
                          this->scriptsBySharedSource.table_.max_load_ = 0; /*0x141021eda*/
                          this->scriptsBySharedSource.table_.buckets_ = nullptr; /*0x141021ee1*/
                          this->scriptsBySharedBytecode.table_.current_ = false; /*0x141021eef*/
                          this->scriptsBySharedBytecode.table_.bucket_count_ = 16; /*0x141021ef2*/
                          this->scriptsBySharedBytecode.table_.size_ = 0; /*0x141021efa*/
                          this->scriptsBySharedBytecode.table_.mlf_ = 1.0; /*0x141021efe*/
                          this->scriptsBySharedBytecode.table_.max_load_ = 0; /*0x141021f05*/
                          this->scriptsBySharedBytecode.table_.buckets_ = nullptr; /*0x141021f09*/
                          v30.m = (std::recursive_mutex *)&this->serverReplicatorByAddress; /*0x141021f14*/
                          this->serverReplicatorByAddress._Traitsobj._Mypair._Myval2._Myval2 = 0.0; /*0x141021f18*/
                          this->serverReplicatorByAddress._List._Mypair._Myval2._Myhead = nullptr; /*0x141021f1b*/
                          this->serverReplicatorByAddress._List._Mypair._Myval2._Mysize = 0; /*0x141021f1f*/
                          v9 = (std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *)operator new(size: 0x38u); /*0x141021f28*/
                          __wind /*0xf1c00000000002dc*/
                          {
                            __wind /*0xf1c00000000002e4*/
                            {
                              v9->_Next = v9; /*0x141021f2d*/
                              v9->_Prev = v9; /*0x141021f30*/
                              this->serverReplicatorByAddress._List._Mypair._Myval2._Myhead = v9; /*0x141021f34*/
                              this->serverReplicatorByAddress._Vec._Mypair._Myval2._Myfirst = nullptr; /*0x141021f3c*/
                              this->serverReplicatorByAddress._Vec._Mypair._Myval2._Mylast = nullptr; /*0x141021f3f*/
                              this->serverReplicatorByAddress._Vec._Mypair._Myval2._Myend = nullptr; /*0x141021f43*/
                              this->serverReplicatorByAddress._Mask = 7; /*0x141021f47*/
                              this->serverReplicatorByAddress._Maxidx = 8; /*0x141021f4f*/
                              this->serverReplicatorByAddress._Traitsobj._Mypair._Myval2._Myval2 = 1.0; /*0x141021f57*/
                              std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::shared_ptr<RBX::Graphics::Shader>>>>>>>::_Assign_grow( /*0x141021f66*/
                                this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > > > > *)&this->serverReplicatorByAddress._Vec,
                                _Cells: 0x10u,
                                _Val: (const std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > >)this->serverReplicatorByAddress._List._Mypair._Myval2._Myhead);
                              this->placeAuthenticationResultCacheMutex.active_count = 0; /*0x141021f6c*/
                              this->placeAuthenticationResultCacheMutex.event = nullptr; /*0x141021f73*/
                              this->placeAuthenticationResultCache.table_.current_ = false; /*0x141021f7a*/
                              v15 = boost::unordered::detail::prime_list_template<unsigned __int64>::value; /*0x141021f81*/
                              v11 = boost::unordered::detail::prime_list_template<unsigned __int64>::value; /*0x141021f88*/
                              v16 = 38; /*0x141021f8b*/
                              v12 = 38; /*0x141021f90*/
                              do /*0x141021fc9*/
                              {
                                v10 = &v11[v12 >> 1]; /*0x141021fa6*/
                                if ( *v10 >= 0xB ) /*0x141021fae*/
                                {
                                  v12 >>= 1; /*0x141021fc3*/
                                }
                                else
                                {
                                  v11 = v10 + 1; /*0x141021fb0*/
                                  v12 += -1LL - (v12 >> 1); /*0x141021fbe*/
                                }
                              }
                              while ( (__int64)v12 > 0 ); /*0x141021fc9*/
                              v13 = (unsigned __int64 *)(v11 - 1); /*0x141021fd2*/
                              if ( v11 != (const unsigned __int64 *)&off_143C37C40 ) /*0x141021fd9*/
                                v13 = (unsigned __int64 *)v11; /*0x141021fd9*/
                              this->placeAuthenticationResultCache.table_.bucket_count_ = *v13; /*0x141021fe0*/
                              this->placeAuthenticationResultCache.table_.size_ = 0; /*0x141021fe7*/
                              this->placeAuthenticationResultCache.table_.mlf_ = 1.0; /*0x141021fee*/
                              this->placeAuthenticationResultCache.table_.max_load_ = 0; /*0x141021ff8*/
                              this->placeAuthenticationResultCache.table_.buckets_ = nullptr; /*0x141021fff*/
                              this->serverReplicatorByPlayer.table_.current_ = false; /*0x141022006*/
                              do /*0x141022039*/
                              {
                                v14 = &v15[v16 >> 1]; /*0x141022016*/
                                if ( *v14 >= 0xB ) /*0x14102201e*/
                                {
                                  v16 >>= 1; /*0x141022033*/
                                }
                                else
                                {
                                  v15 = v14 + 1; /*0x141022020*/
                                  v16 += -1LL - (v16 >> 1); /*0x14102202e*/
                                }
                              }
                              while ( (__int64)v16 > 0 ); /*0x141022039*/
                              v17 = (unsigned __int64 *)(v15 - 1); /*0x14102203b*/
                              if ( v15 != (const unsigned __int64 *)&off_143C37C40 ) /*0x141022042*/
                                v17 = (unsigned __int64 *)v15; /*0x141022042*/
                            }
                            __unwind
                            {
                              std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&v30.m->_Mtx_storage._Pad[24]); /*0x14316e3cb*/
                            }
                          }
                          __unwind
                          {
                            std::list<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BanStruct *>>::~list<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BanStruct *>>(this: (std::list<webrtc::ProcessThreadImpl::ModuleCallback> *)&v30.m->_Mtx_storage._Pad[8]); /*0x1431e626b*/
                          }
                          __wind /*0xf1c0000000000308*/
                          {
                            __wind /*0xf1c0000000000310*/
                            {
                              __wind /*0xf1c0000000000318*/
                              {
                                __wind /*0xf1c0000000000320*/
                                {
                                  __wind /*0xf1c0000000000328*/
                                  {
                                    __wind /*0xf1c0000000000330*/
                                    {
                                      this->serverReplicatorByPlayer.table_.bucket_count_ = *v17; /*0x141022049*/
                                      this->serverReplicatorByPlayer.table_.size_ = 0; /*0x141022050*/
                                      this->serverReplicatorByPlayer.table_.mlf_ = 1.0; /*0x141022057*/
                                      this->serverReplicatorByPlayer.table_.max_load_ = 0; /*0x141022061*/
                                      this->serverReplicatorByPlayer.table_.buckets_ = nullptr; /*0x141022068*/
                                      this->aslrPmcHasher._Ptr = nullptr; /*0x14102206f*/
                                      this->aslrPmcHasher._Rep = nullptr; /*0x141022076*/
                                      *(_QWORD *)&this->newGuiCount.v = 0; /*0x14102207d*/
                                      this->targetPlayerCount.v = 0; /*0x141022084*/
                                      this->cachedNetworkSchemaInfo._Ptr = nullptr; /*0x14102208b*/
                                      this->cachedNetworkSchemaInfo._Rep = nullptr; /*0x141022092*/
                                      RBX::ProtectedString::ProtectedString(this: &this->dynLuaChallenge); /*0x1410220a0*/
                                      __wind /*0xf1c000000000033c*/
                                      {
                                        __wind /*0xf1c0000000000344*/
                                        {
                                          __wind /*0xf1c000000000034c*/
                                          {
                                            this->dynamicLuaChallengeIdx = -1; /*0x1410220a6*/
                                            this->dynIpRateScalingMutex.active_count = 0; /*0x1410220b0*/
                                            this->dynIpRateScalingMutex.event = nullptr; /*0x1410220b7*/
                                            this->dynIpRateScaling = 3; /*0x1410220be*/
                                            this->lastDynIpRateDecrement = 0.0; /*0x1410220c8*/
                                            this->userScoreDecryptionKeys._Mypair._Myval2._Myfirst = nullptr; /*0x1410220cf*/
                                            this->userScoreDecryptionKeys._Mypair._Myval2._Mylast = nullptr; /*0x1410220d6*/
                                            this->userScoreDecryptionKeys._Mypair._Myval2._Myend = nullptr; /*0x1410220dd*/
                                            v30.m = (std::recursive_mutex *)&this->extAntiCheatSignal; /*0x1410220eb*/
                                            rbx::signals::signal_base::signal_base(this: &this->extAntiCheatSignal); /*0x1410220ef*/
                                            __wind /*0xf1c000000000023c*/
                                            {
                                              v30.m = (std::recursive_mutex *)&this->usedTickets; /*0x1410220fc*/
                                              this->usedTickets._Mypair._Myval2._Myval2._Myhead = nullptr; /*0x141022100*/
                                              this->usedTickets._Mypair._Myval2._Myval2._Mysize = 0; /*0x141022103*/
                                              v18 = (std::_Tree_node<std::string,void *> *)operator new(size: 0x40u); /*0x14102210c*/
                                              __wind /*0xf1c000000000011c*/
                                              {
                                                v18->_Left = v18; /*0x141022111*/
                                                v18->_Parent = v18; /*0x141022114*/
                                                v18->_Right = v18; /*0x141022118*/
                                                *(_WORD *)&v18->_Color = 257; /*0x14102211c*/
                                                this->usedTickets._Mypair._Myval2._Myval2._Myhead = v18; /*0x141022122*/
                                                v30.m = (std::recursive_mutex *)&this->preusedTickets; /*0x14102212c*/
                                                this->preusedTickets._Mypair._Myval2._Myval2._Myhead = nullptr; /*0x141022130*/
                                                this->preusedTickets._Mypair._Myval2._Myval2._Mysize = 0; /*0x141022133*/
                                                v19 = (std::_Tree_node<std::string,void *> *)operator new(size: 0x40u); /*0x14102213c*/
                                                __wind /*0xf1c00000000002b0*/
                                                {
                                                  __wind /*0xf1c00000000002b8*/
                                                  {
                                                    v19->_Left = v19; /*0x141022141*/
                                                    v19->_Parent = v19; /*0x141022144*/
                                                    v19->_Right = v19; /*0x141022148*/
                                                    *(_WORD *)&v19->_Color = 257; /*0x14102214c*/
                                                    this->preusedTickets._Mypair._Myval2._Myval2._Myhead = v19; /*0x141022152*/
                                                    this->remoteEventMonitor._Ptr = nullptr; /*0x141022155*/
                                                    this->remoteEventMonitor._Rep = nullptr; /*0x14102215c*/
                                                    v20 = RBX::Security::Context::current(); /*0x141022168*/
                                                    if ( !RBX::Security::Context::isInRole( /*0x141022173*/
                                                            identity: &v20->identity,
                                                            p: RobloxEngine) )
                                                      RBX::Security::Context::throwPermissionError( /*0x14102218b*/
                                                        this: v20,
                                                        permission: RobloxEngine,
                                                        operation: "create a NetworkServer");
                                                    value._Mypair._Myval2._Myres = 15; /*0x141022190*/
                                                    value._Mypair._Myval2._Mysize = 13; /*0x141022198*/
                                                    strcpy(value._Mypair._Myval2._Bx._Buf, "NetworkServer"); /*0x1410221a8*/
                                                    __wind /*0xf1c0000000000110*/
                                                    {
                                                      RBX::Instance::setName(this, &value); /*0x1410221cb*/
                                                    }
                                                    __unwind
                                                    {
                                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&value); /*0xf1c0000000000108*/
                                                    }
                                                    if ( value._Mypair._Myval2._Myres >= 0x10 ) /*0x1410221d9*/
                                                    {
                                                      v21 = value._Mypair._Myval2._Bx._Ptr; /*0x1410221de*/
                                                      if ( value._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410221ec*/
                                                      {
                                                        v21 = *((char **)value._Mypair._Myval2._Bx._Ptr - 1); /*0x1410221f2*/
                                                        if ( (unsigned __int64)(value._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x141022201*/
                                                          _invalid_parameter_noinfo_noreturn(); /*0x141022203*/
                                                      }
                                                      operator delete(ptr: v21); /*0x14102220a*/
                                                    }
                                                    v22 = RBX::SharedString::SharedString(this: (RBX::SharedString *)&v25); /*0x141022213*/
                                                    __wind /*0xf1c00000000000f8*/
                                                    {
                                                      RBX::Network::Server::registerLegalSharedScript(this, source: v22); /*0x14102221f*/
                                                    }
                                                    __unwind
                                                    {
                                                      RBX::SharedString::~SharedString(this: (RBX::SharedString *)&v25); /*0xf1c00000000000f0*/
                                                    }
                                                    boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&v25); /*0x141022229*/
                                                    v23 = RBX::SharedString::SharedString(this: &v27); /*0x141022232*/
                                                    __wind /*0xf1c00000000000e0*/
                                                    {
                                                      boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,int>>,RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::operator[]( /*0x141022243*/
                                                        this: &this->scriptsBySharedBytecode.table_,
                                                        k: v23)->second = 0;
                                                    }
                                                    __unwind
                                                    {
                                                      RBX::SharedString::~SharedString(this: &v27); /*0xf1c00000000000d8*/
                                                    }
                                                    boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &v27.flyweight.h); /*0x14102224b*/
                                                    this->nextFreePeerId = 4; /*0x141022250*/
                                                    if ( FLog::Network != 0 ) /*0x141022263*/
                                                      FLog::FastLog( /*0x14102226f*/
                                                        level: FLog::Network,
                                                        message: "[FLog::Network] NetworkServer:Create",
                                                        arg0: nullptr);
                                                  }
                                                  __unwind
                                                  {
                                                    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->remoteEventMonitor); /*0x1431e622e*/
                                                  }
                                                }
                                                __unwind
                                                {
                                                  std::set<RBX::ContentId>::~set<RBX::ContentId>(this: (std::set<RBX::Studio::ScriptRef> *)&this->preusedTickets); /*0x1431e620e*/
                                                }
                                              }
                                              __unwind
                                              {
                                                std::set<RBX::ContentId>::~set<RBX::ContentId>(this: (std::set<RBX::Studio::ScriptRef> *)&this->usedTickets); /*0x1431e61ee*/
                                              }
                                            }
                                            __unwind
                                            {
                                              rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)&this->extAntiCheatSignal); /*0x1431e61ce*/
                                            }
                                          }
                                          __unwind
                                          {
                                            RBX::ScriptServices::Documentation::ValidateResult::~ValidateResult(this: (std::vector<RBX::MeshId> *)&this->userScoreDecryptionKeys); /*0x1431e61ae*/
                                          }
                                        }
                                        __unwind
                                        {
                                          boost::mutex::~mutex(this: &this->dynIpRateScalingMutex); /*0x1431e618e*/
                                        }
                                      }
                                      __unwind
                                      {
                                        RBX::ProtectedString::~ProtectedString(this: (RBX::Scripting::DebuggerEvalExpression *)&this->dynLuaChallenge); /*0x1431e616e*/
                                      }
                                    }
                                    __unwind
                                    {
                                      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->cachedNetworkSchemaInfo); /*0x1431e614e*/
                                    }
                                  }
                                  __unwind
                                  {
                                    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->aslrPmcHasher); /*0x1431e612e*/
                                  }
                                }
                                __unwind
                                {
                                  boost::unordered::unordered_map<__int64,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<__int64>,std::equal_to<__int64>,std::allocator<std::pair<__int64 const,std::weak_ptr<RBX::Network::ServerReplicator>>>>::~unordered_map<__int64,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<__int64>,std::equal_to<__int64>,std::allocator<std::pair<__int64 const,std::weak_ptr<RBX::Network::ServerReplicator>>>>(this: &this->serverReplicatorByPlayer); /*0x1431e610e*/
                                }
                              }
                              __unwind
                              {
                                boost::unordered::unordered_set<RBX::PackageAssetVersion,boost::hash<RBX::PackageAssetVersion>,std::equal_to<RBX::PackageAssetVersion>,std::allocator<RBX::PackageAssetVersion>>::~unordered_set<RBX::PackageAssetVersion,boost::hash<RBX::PackageAssetVersion>,std::equal_to<RBX::PackageAssetVersion>,std::allocator<RBX::PackageAssetVersion>>(this: (boost::unordered::unordered_map<__int64,enum RBX::MembershipType,boost::hash<__int64>,std::equal_to<__int64>,std::allocator<std::pair<__int64 const ,enum RBX::MembershipType> > > *)&this->placeAuthenticationResultCache); /*0x1431e60ee*/
                              }
                            }
                            __unwind
                            {
                              boost::mutex::~mutex(this: &this->placeAuthenticationResultCacheMutex); /*0x1431e60ce*/
                            }
                          }
                          __unwind
                          {
                            std::unordered_map<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>::~unordered_map<RakNet::SystemAddress,RakNet::RakPeer::BytesInReturnQueuePeerTracker,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,std::allocator<std::pair<RakNet::SystemAddress const,RakNet::RakPeer::BytesInReturnQueuePeerTracker>>>(this: (std::unordered_map<__int64,RBX::HumanoidDescription::AssetData> *)&this->serverReplicatorByAddress); /*0x1431e60ae*/
                          }
                        }
                        __unwind
                        {
                          boost::unordered::unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const,int>>>::~unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const,int>>>(this: &this->scriptsBySharedBytecode); /*0x1431e608e*/
                        }
                      }
                      __unwind
                      {
                        boost::unordered::unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const,int>>>::~unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const,int>>>(this: &this->scriptsBySharedSource); /*0x1431e606e*/
                      }
                    }
                    __unwind
                    {
                      std::vector<RBX::Network::Server::LegalScript>::~vector<RBX::Network::Server::LegalScript>(this: &this->legalScripts); /*0x1431e604e*/
                    }
                  }
                  __unwind
                  {
                    std::vector<RBX::Network::SecurityJoinInfo>::~vector<RBX::Network::SecurityJoinInfo>(this: &this->ipCache); /*0x1431e602e*/
                  }
                }
                __unwind
                {
                  rbx::signals::scoped_connection::~scoped_connection(this: &this->workspaceLoadedConnection); /*0x1431e600e*/
                }
              }
              __unwind
              {
                rbx::signals::scoped_connection::~scoped_connection(this: &this->itemAddedConnection); /*0x1431e5fee*/
              }
            }
            __unwind
            {
              rbx::signals::scoped_connection::~scoped_connection(this: &this->closingConnection); /*0x1431e5fce*/
            }
          }
          __unwind
          {
            RBX::Network::MegaReplicator::~MegaReplicator(this: &this->megaReplicator); /*0x1431e5fae*/
          }
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->romarkPhaseTrackingJob); /*0x1431e5f8e*/
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->networkOwnerJob); /*0x1431e5f6e*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->players); /*0x1431e5f4e*/
    }
  }
  __unwind
  {
    RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer>::~DescribedCreatable<RBX::Network::Server,RBX::Network::Peer>(this); /*0xf1c0000000000234*/
  }
  return this; /*0x141022278*/
}

// Address: 0x141022c40 | Name: ??1Server@Network@RBX@@UEAA@XZ
void __fastcall RBX::Network::Server::~Server(RBX::Network::Server *this)
{
  std::_Ref_count_base *Rep; // rbx
  void *v3; // rcx
  std::_Ref_count_base *v4; // rbx
  std::_Ref_count_base *v5; // rbx
  void *v6; // rbp
  rbx::signals::slot_base *p; // rcx
  rbx::signals::slot_base *v8; // rcx
  rbx::signals::slot_base *v9; // rcx
  std::_Ref_count_base *v10; // rbx
  std::_Ref_count_base *v11; // rbx
  std::_Ref_count_base *v12; // rbx
  RBX::ClassRegistrar<RBX::Network::Server,1> *v13; // rax
  RBX::Reflection::Stat::ClassEntry *ClassEntry; // rax
  __int64 v15; // [rsp+0h] [rbp-28h] BYREF

  this->__vftable = (RBX::Network::Server_vtbl *)RBX::Network::Server::`vftable'; /*0x141022c5e*/
  if ( FLog::Network != 0 ) /*0x141022c6a*/
    FLog::FastLog(level: FLog::Network, message: "[FLog::Network] NetworkServer:Destroy", arg0: nullptr); /*0x141022c76*/
  Rep = this->remoteEventMonitor._Rep; /*0x141022c7b*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141022c96*/
  {
    Rep->_Destroy(this: Rep); /*0x141022c9e*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141022caa*/
      Rep->_Delete_this(this: Rep); /*0x141022cb2*/
  }
  std::_Tree_val<std::_Tree_simple_types<RBX::ContentId>>::_Erase_tree<std::allocator<std::_Tree_node<RBX::ContentId,void *>>>( /*0x141022cce*/
    this: (std::_Tree_val<std::_Tree_simple_types<RBX::Studio::ScriptRef> > *)&this->preusedTickets,
    _Al: (std::allocator<std::_Tree_node<RBX::Studio::ScriptRef,void *> > *)&this->preusedTickets,
    _Rootnode: (std::_Tree_node<RBX::Studio::ScriptRef,void *> *)this->preusedTickets._Mypair._Myval2._Myval2._Myhead->_Parent);
  operator delete(ptr: this->preusedTickets._Mypair._Myval2._Myval2._Myhead); /*0x141022cdf*/
  std::_Tree_val<std::_Tree_simple_types<RBX::ContentId>>::_Erase_tree<std::allocator<std::_Tree_node<RBX::ContentId,void *>>>( /*0x141022cfd*/
    this: (std::_Tree_val<std::_Tree_simple_types<RBX::Studio::ScriptRef> > *)&this->usedTickets,
    _Al: (std::allocator<std::_Tree_node<RBX::Studio::ScriptRef,void *> > *)&this->usedTickets,
    _Rootnode: (std::_Tree_node<RBX::Studio::ScriptRef,void *> *)this->usedTickets._Mypair._Myval2._Myval2._Myhead->_Parent);
  operator delete(ptr: this->usedTickets._Mypair._Myval2._Myval2._Myhead); /*0x141022d0e*/
  rbx::signals::signal_base::~signal_base(this: &this->extAntiCheatSignal); /*0x141022d1a*/
  std::vector<RBX::Scripting::DAP::ExceptionOptions>::_Tidy(this: (std::vector<RBX::TextureId> *)&this->userScoreDecryptionKeys); /*0x141022d26*/
  v3 = (void *)_InterlockedExchange64((volatile __int64 *)&this->dynIpRateScalingMutex.event, 0); /*0x141022d2f*/
  if ( v3 != nullptr ) /*0x141022d39*/
    CloseHandle(hObject: v3); /*0x141022d3b*/
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &this->dynLuaChallenge.sharedBytecode.flyweight.h); /*0x141022d48*/
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &this->dynLuaChallenge.sharedSource.flyweight.h); /*0x141022d54*/
  v4 = this->cachedNetworkSchemaInfo._Rep; /*0x141022d59*/
  if ( v4 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Uses, 0xFFFFFFFF) == 1 ) /*0x141022d6f*/
  {
    v4->_Destroy(this: v4); /*0x141022d77*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141022d83*/
      v4->_Delete_this(this: v4); /*0x141022d8b*/
  }
  v5 = this->aslrPmcHasher._Rep; /*0x141022d8e*/
  if ( v5 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Uses, 0xFFFFFFFF) == 1 ) /*0x141022da4*/
  {
    v5->_Destroy(this: v5); /*0x141022dac*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141022db8*/
      v5->_Delete_this(this: v5); /*0x141022dc0*/
  }
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<__int64 const,std::weak_ptr<RBX::Network::ServerReplicator>>>,__int64,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<__int64>,std::equal_to<__int64>>>::~table<boost::unordered::detail::map<std::allocator<std::pair<__int64 const,std::weak_ptr<RBX::Network::ServerReplicator>>>,__int64,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<__int64>,std::equal_to<__int64>>>(this: &this->serverReplicatorByPlayer.table_); /*0x141022dca*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<__int64 const,enum RBX::MembershipType>>,__int64,enum RBX::MembershipType,boost::hash<__int64>,std::equal_to<__int64>>>::~table<boost::unordered::detail::map<std::allocator<std::pair<__int64 const,enum RBX::MembershipType>>,__int64,enum RBX::MembershipType,boost::hash<__int64>,std::equal_to<__int64>>>(this: (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<__int64 const ,enum RBX::MembershipType> >,__int64,enum RBX::MembershipType,boost::hash<__int64>,std::equal_to<__int64> > > *)&this->placeAuthenticationResultCache); /*0x141022dd6*/
  v6 = (void *)_InterlockedExchange64((volatile __int64 *)&this->placeAuthenticationResultCacheMutex.event, 0); /*0x141022ddb*/
  if ( v6 != nullptr ) /*0x141022de5*/
    CloseHandle(hObject: v6); /*0x141022dea*/
  std::_Hash<std::_Umap_traits<__int64,RBX::HumanoidDescription::AssetData,std::_Uhash_compare<__int64,std::hash<__int64>,std::equal_to<__int64>>,std::allocator<std::pair<__int64 const,RBX::HumanoidDescription::AssetData>>,0>>::~_Hash<std::_Umap_traits<__int64,RBX::HumanoidDescription::AssetData,std::_Uhash_compare<__int64,std::hash<__int64>,std::equal_to<__int64>>,std::allocator<std::pair<__int64 const,RBX::HumanoidDescription::AssetData>>,0>>(this: (std::_Hash<std::_Umap_traits<RBX::Collision::MidPhasePrimHashPair,RBX::Collision::MidPhaseComponentResultPair,std::_Uhash_compare<RBX::Collision::MidPhasePrimHashPair,RBX::Collision::PairHash,std::equal_to<RBX::Collision::MidPhasePrimHashPair> >,std::allocator<std::pair<RBX::Collision::MidPhasePrimHashPair const ,RBX::Collision::MidPhaseComponentResultPair> >,0> > *)&this->serverReplicatorByAddress); /*0x141022df7*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,int>>,RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::~table<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,int>>,RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>(this: &this->scriptsBySharedBytecode.table_); /*0x141022e03*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,int>>,RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::~table<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,int>>,RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>(this: &this->scriptsBySharedSource.table_); /*0x141022e0f*/
  std::vector<RBX::Network::Server::LegalScript>::~vector<RBX::Network::Server::LegalScript>(this: &this->legalScripts); /*0x141022e1b*/
  std::vector<RBX::Network::SecurityJoinInfo>::~vector<RBX::Network::SecurityJoinInfo>(this: &this->ipCache); /*0x141022e27*/
  __eh34_enter_wind_state(-1, 0); /*0xf1c000000000003c*/
  rbx::signals::connection::disconnect(this: &this->workspaceLoadedConnection.con); /*0x141022e34*/
  p = this->workspaceLoadedConnection.con.weak_slot.p_; /*0x141022e39*/
  if ( p != nullptr && _InterlockedExchangeAdd(&p->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x141022e4f*/
    operator delete(ptr: p); /*0x141022e51*/
  rbx::signals::connection::disconnect(this: &this->itemAddedConnection.con); /*0x141022e5e*/
  v8 = this->itemAddedConnection.con.weak_slot.p_; /*0x141022e63*/
  if ( v8 != nullptr && _InterlockedExchangeAdd(&v8->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x141022e79*/
    operator delete(ptr: v8); /*0x141022e7b*/
  rbx::signals::connection::disconnect(this: &this->closingConnection.con); /*0x141022e88*/
  v9 = this->closingConnection.con.weak_slot.p_; /*0x141022e8d*/
  if ( v9 != nullptr && _InterlockedExchangeAdd(&v9->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x141022ea3*/
    operator delete(ptr: v9); /*0x141022ea5*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000030*/
unwind_state_0:
    __std_terminate(a1: v9, a2: &v15); /*0xf1c0000000000018*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000034*/
  RBX::Network::MegaReplicator::~MegaReplicator(this: &this->megaReplicator); /*0x141022eb2*/
  v10 = this->romarkPhaseTrackingJob._Rep; /*0x141022eb7*/
  if ( v10 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Uses, 0xFFFFFFFF) == 1 ) /*0x141022ecd*/
  {
    v10->_Destroy(this: v10); /*0x141022ed5*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141022ee1*/
      v10->_Delete_this(this: v10); /*0x141022ee9*/
  }
  v11 = this->networkOwnerJob._Rep; /*0x141022eec*/
  if ( v11 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v11->_Uses, 0xFFFFFFFF) == 1 ) /*0x141022f02*/
  {
    v11->_Destroy(this: v11); /*0x141022f0a*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v11->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141022f16*/
      v11->_Delete_this(this: v11); /*0x141022f1e*/
  }
  v12 = this->players._Rep; /*0x141022f21*/
  if ( v12 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v12->_Uses, 0xFFFFFFFF) == 1 ) /*0x141022f37*/
  {
    v12->_Destroy(this: v12); /*0x141022f3f*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v12->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141022f49*/
      v12->_Delete_this(this: v12); /*0x141022f51*/
  }
  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000028*/
  this->__vftable = (RBX::Network::Server_vtbl *)RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer>::`vftable'; /*0x141022f5c*/
  if ( FFlag::g_flagsLoaded && FFlag::DebugTraceCreatableCounts3.value ) /*0x141022f6f*/
  {
    v13 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Server>(); /*0x141022f71*/
    ClassEntry = RBX::Reflection::Stat::getClassEntry(desc: &v13->desc); /*0x141022f79*/
    RBX::Reflection::Stat::ClassEntry::destroyed(this: ClassEntry); /*0x141022f81*/
  }
  RBX::Network::Peer::~Peer(this); /*0x141022f89*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000014*/
    goto unwind_state_0; /*0xf1c0000000000014*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000020*/
}

// Address: 0x1410242b0 | Name: ??_E?$DescribedCreatable@VServer@Network@RBX@@VPeer@23@@RBX@@UEAAPEAXI@Z
RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer> *__fastcall RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer>::`vector deleting destructor'(
        RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer> *this,
        char a2)
{
  RBX::ClassRegistrar<RBX::Network::Server,1> *v4; // rax
  RBX::Reflection::Stat::ClassEntry *ClassEntry; // rax

  this->__vftable = (RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer>_vtbl *)RBX::DescribedCreatable<RBX::Network::Server,RBX::Network::Peer>::`vftable'; /*0x1410242c6*/
  if ( FFlag::g_flagsLoaded && FFlag::DebugTraceCreatableCounts3.value ) /*0x1410242d9*/
  {
    v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Server>(); /*0x1410242db*/
    ClassEntry = RBX::Reflection::Stat::getClassEntry(desc: &v4->desc); /*0x1410242e3*/
    RBX::Reflection::Stat::ClassEntry::destroyed(this: ClassEntry); /*0x1410242eb*/
  }
  RBX::Network::Peer::~Peer(this); /*0x1410242f3*/
  if ( (a2 & 1) != 0 ) /*0x1410242fd*/
    operator delete(ptr: this); /*0x141024307*/
  return this; /*0x14102430f*/
}

// Address: 0x141024480 | Name: ?OnReceive@Server@Network@RBX@@UEAA?AW4PeerReceiveResult@RakNet@@PEAUPacket@5@@Z
__int64 __fastcall RBX::Network::Server::OnReceive(RBX::Network::Server *this, RakNet::Packet *packet)
{
  std::_Ref_count_base *v2; // rbx
  RakNet::Packet *v3; // r14
  RBX::Network::Server *v4; // rsi
  unsigned int v5; // eax
  float v6; // xmm2_4
  std::string *Ptr; // rax
  char *v8; // rcx
  std::string *v9; // rax
  char *v10; // rcx
  unsigned int nextFreePeerId; // edx
  std::_Ref_count_base *Rep; // rcx
  std::_Ref_count_base *v13; // rbx
  Luau::InternalErrorReporter *v14; // rax
  std::_Func_base<void,char const *>_vtbl *v15; // r8
  __int64 capability; // rdx
  RBX::NetworkSettings *networkSettings; // r8
  std::_Ref_count_base *v18; // rcx
  volatile signed __int32 *v19; // rbx
  std::pair<std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *,bool> *v20; // rax
  RBX::Network::ServerReplicator *v21; // rbx
  Luau::InternalErrorReporter *v22; // rax
  std::_Func_base<void,char const *>_vtbl *v23; // r9
  std::shared_ptr<RBX::Security::SessionCrypto> *v24; // rax
  Luau::InternalErrorReporter *v25; // rax
  std::_Func_base<void,char const *>_vtbl *v26; // r9
  unsigned int v27; // eax
  unsigned __int64 v28; // rdi
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *> > > > *Myfirst; // rax
  std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *v30; // rbx
  std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *v31; // rdi
  RakNet::PeerReceiveResult v32; // ebx
  __int64 v33; // rcx
  __int64 result; // rax
  std::_Ref_count_base *v35; // kr00_8
  std::exception *v36; // rbx
  const char *v37; // rax
  const char *v38; // rax
  RBX::Network::ServerReplicator *v39; // rcx
  __int64 v40; // [rsp+0h] [rbp-208h] BYREF
  std::_Binder<std::_Unforced,void (__cdecl RBX::NavigationDebugDraw::*)(dtNavMesh *,RBX::Extents),std::shared_ptr<RBX::NavigationDebugDraw> &,std::_Ph<1> const &,RBX::Extents &> *p_peerId; // [rsp+30h] [rbp-1D8h]
  std::exception *e; // [rsp+38h] [rbp-1D0h] BYREF
  std::shared_ptr<RBX::Network::ServerReplicator> proxy; // [rsp+40h] [rbp-1C8h] BYREF
  RBX::Network::Replicator::ReplicatorPeerInfo peerInfo; // [rsp+50h] [rbp-1B8h] BYREF
  RBX::Network::Server *v45; // [rsp+90h] [rbp-178h] BYREF
  std::shared_ptr<std::vector<RBX::Guid> > v46; // [rsp+98h] [rbp-170h] BYREF
  RBX::Network::ServerReplicator *v47[2]; // [rsp+B0h] [rbp-158h] BYREF
  std::shared_ptr<std::vector<RBX::Guid> > v48; // [rsp+C0h] [rbp-148h] BYREF
  unsigned int peerId; // [rsp+D0h] [rbp-138h] BYREF
  RakNet::SystemAddress remotePlayerAddress; // [rsp+D4h] [rbp-134h]
  __int128 v51; // [rsp+F8h] [rbp-110h]
  __int64 v52; // [rsp+108h] [rbp-100h]
  char v53[8]; // [rsp+110h] [rbp-F8h] BYREF
  char v54[16]; // [rsp+118h] [rbp-F0h] BYREF
  std::string v55; // [rsp+128h] [rbp-E0h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v56; // [rsp+148h] [rbp-C0h] BYREF
  __int128 v57; // [rsp+180h] [rbp-88h]
  _QWORD v58[4]; // [rsp+190h] [rbp-78h] BYREF
  std::pair<std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *,bool> v59[2]; // [rsp+1B0h] [rbp-58h] BYREF
  std::pair<std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *,bool> v60; // [rsp+1D0h] [rbp-38h] BYREF
  RBX::Memory::Scope memscopeNetworkReplicator; // [rsp+220h] [rbp+18h] BYREF
  RBX::NetworkSettings *v64; // [rsp+228h] [rbp+20h] BYREF

  v3 = packet; /*0x141024496*/
  v4 = this; /*0x141024499*/
  v5 = RBX::Memory::setCurrentCategory(category: RBX::Memory::NetworkReplicator); /*0x1410244a2*/
  __wind
  {
    __wind
    {
      __eh34_enter_try_state(1, 2); /*0xf1c00000000000f8*/
      memscopeNetworkReplicator.parent = v5; /*0x1410244a7*/
      if ( *v3->data == 19 )
      {
        proxy = 0; /*0x1410244be*/
        if ( FLog::Network != 0 ) /*0x1410244cd*/
          FLog::FastLog( /*0x1410244d9*/
            level: FLog::Network,
            message: "[FLog::Network] NetworkServer:NewIncomingConnection",
            arg0: nullptr);
        if ( DFLog::NetworkJoin != 0 ) /*0x1410244e5*/
        {
          v6 = RBX::Time::nowFastSec(); /*0x1410244ef*/
          FLog::FastLogF( /*0x141024510*/
            channel: DFLog::NetworkJoin,
            message: "[DFLog::NetworkJoin] Server::OnReceive new connection @ %f s",
            arg1: v6,
            arg2: 0.0,
            arg3: 0.0,
            arg4: 0.0);
        }
        if ( FLog::Output != 0 ) /*0x14102451c*/
        {
          Ptr = RBX::Network::RakNetAddressToString( /*0x14102452f*/
                  result: &v55,
                  raknetAddress: &v3->systemAddress,
                  writePort: true,
                  portDelineator: 124);
          __wind /*0xf1c00000000000a8*/
          {
            if ( Ptr->_Mypair._Myval2._Myres >= 0x10 ) /*0x14102453a*/
              Ptr = (std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x14102453c*/
            FLog::FastLogFormatted( /*0x141024550*/
              level: FLog::Output,
              message: "[FLog::Output] New connection from %s",
              Ptr->_Mypair._Myval2._Bx._Buf);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v55); /*0xf1c00000000000a0*/
          }
          if ( v55._Mypair._Myval2._Myres >= 0x10 ) /*0x141024562*/
          {
            v8 = v55._Mypair._Myval2._Bx._Ptr; /*0x141024567*/
            if ( v55._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141024579*/
            {
              v8 = *((char **)v55._Mypair._Myval2._Bx._Ptr - 1); /*0x14102457f*/
              if ( (unsigned __int64)(v55._Mypair._Myval2._Bx._Ptr - v8 - 8) > 0x1F ) /*0x14102458e*/
                _invalid_parameter_noinfo_noreturn(); /*0x141024590*/
            }
            operator delete(ptr: v8); /*0x141024597*/
          }
        }
        if ( DFLog::NetworkAudit != 0 )
        {
          v9 = RBX::Network::RakNetAddressToString( /*0x1410245b6*/
                 result: &v56.text,
                 raknetAddress: &v3->systemAddress,
                 writePort: true,
                 portDelineator: 124);
          __wind
          {
            if ( v9->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410245c1*/
              v9 = (std::string *)v9->_Mypair._Myval2._Bx._Ptr; /*0x1410245c3*/
            FLog::FastLogFormatted(
              level: DFLog::NetworkAudit,
              message: "[DFLog::NetworkAudit] RakNet Connect: New connection from %s",
              v9->_Mypair._Myval2._Bx._Buf);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v56); /*0xf1c0000000000088*/
          }
          if ( v56.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410245e9*/
          {
            v10 = v56.text._Mypair._Myval2._Bx._Ptr; /*0x1410245ee*/
            if ( v56.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141024600*/
            {
              v10 = *((char **)v56.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141024606*/
              if ( (unsigned __int64)(v56.text._Mypair._Myval2._Bx._Ptr - v10 - 8) > 0x1F ) /*0x141024615*/
                _invalid_parameter_noinfo_noreturn(); /*0x141024617*/
            }
            operator delete(ptr: v10); /*0x14102461e*/
          }
        }
        peerInfo.remotePeerId.peerId = -1; /*0x141024623*/
        RakNet::SystemAddress::SystemAddress(this: &peerInfo.remotePlayerAddress); /*0x141024630*/
        peerInfo.rakPeer._Ptr = nullptr; /*0x141024637*/
        peerInfo.rakPeer._Rep = nullptr; /*0x14102463c*/
        __wind /*0xf1c0000000000078*/
        {
          nextFreePeerId = v4->nextFreePeerId; /*0x141024644*/
          v4->nextFreePeerId = nextFreePeerId + 1; /*0x14102464d*/
          peerInfo.remotePeerId.peerId = nextFreePeerId; /*0x141024653*/
          if ( FLog::Network != 0 ) /*0x141024660*/
            FLog::FastLog( /*0x14102466c*/
              level: FLog::Network,
              message: "[FLog::Network] assigning peer id = %d",
              arg0: (const void *)nextFreePeerId);
          RakNet::SystemAddress::operator=(this: &peerInfo.remotePlayerAddress, input: &v3->systemAddress); /*0x141024679*/
          Rep = v4->rakPeer._Rep; /*0x14102467e*/
          if ( Rep != nullptr ) /*0x141024688*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x14102468a*/
            Rep = v4->rakPeer._Rep; /*0x14102468e*/
          }
          peerInfo.rakPeer._Ptr = v4->rakPeer._Ptr; /*0x14102469c*/
          v13 = peerInfo.rakPeer._Rep; /*0x1410246a1*/
          peerInfo.rakPeer._Rep = Rep; /*0x1410246a9*/
          if ( v13 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v13->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410246c5*/
          {
            v13->_Destroy(this: v13); /*0x1410246cd*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v13->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410246d9*/
              v13->_Delete_this(this: v13); /*0x1410246e1*/
          }
          v14 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)v4->rakPeer._Ptr); /*0x1410246eb*/
          v15 = v14->onInternalError._Mystorage._Ptrs[0][82].__vftable; /*0x1410246f3*/
          *(_OWORD *)&v56.width = *(_OWORD *)&v3->systemAddress.address.addr6.sin6_family; /*0x1410246fe*/
          v57 = *((_OWORD *)&v3->systemAddress.address.addr4 + 1); /*0x14102470b*/
          capability = ((__int64 (__fastcall *)(Luau::InternalErrorReporter *, int *))v15)(a1: v14, a2: &v56.width); /*0x141024721*/
          peerInfo.capability = capability; /*0x141024724*/
          networkSettings = v4->networkSettings; /*0x14102472c*/
          peerId = peerInfo.remotePeerId.peerId; /*0x141024737*/
          remotePlayerAddress = peerInfo.remotePlayerAddress; /*0x141024743*/
          v51 = 0; /*0x14102475b*/
          v18 = peerInfo.rakPeer._Rep; /*0x141024764*/
          if ( peerInfo.rakPeer._Rep != nullptr ) /*0x14102476f*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&peerInfo.rakPeer._Rep->_Uses); /*0x141024771*/
            capability = peerInfo.capability; /*0x141024775*/
            v18 = peerInfo.rakPeer._Rep; /*0x14102477d*/
          }
          *(_QWORD *)&v51 = peerInfo.rakPeer._Ptr; /*0x14102478a*/
          *((_QWORD *)&v51 + 1) = v18; /*0x141024792*/
          v52 = capability; /*0x14102479a*/
          p_peerId = (std::_Binder<std::_Unforced,void (__cdecl RBX::NavigationDebugDraw::*)(dtNavMesh *,RBX::Extents),std::shared_ptr<RBX::NavigationDebugDraw> &,std::_Ph<1> const &,RBX::Extents &> *)&peerId; /*0x1410247aa*/
          v64 = networkSettings; /*0x1410247af*/
          v45 = v4; /*0x1410247b7*/
          __wind /*0xf1c000000000006c*/
          {
            if ( RBX::Network::Server::createReplicator._Mystorage._Ptrs[7] == nullptr ) /*0x1410247c9*/
            {
              std::_Xbad_function_call(); /*0x141024a84*/
              JUMPOUT(0x141024A8ALL); /*0x141024a8a*/
            }
            RBX::Network::Server::createReplicator._Mystorage._Ptrs[7]->_Do_call( /*0x1410247f7*/
              this: RBX::Network::Server::createReplicator._Mystorage._Ptrs[7],
              result: (std::shared_ptr<RBX::Network::ServerReplicator> *)v47,
              a3: (RBX::Network::Replicator::ReplicatorPeerInfo *)&peerId,
              a4: &v45,
              a5: &v64);
          }
          __unwind
          {
            rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (enum RBX::MaterialType)>>,enum RBX::MaterialType>::do_dtor(this: p_peerId); /*0xf1c0000000000064*/
          }
          v19 = *((volatile signed __int32 **)&v51 + 1); /*0x1410247fb*/
          if ( *((_QWORD *)&v51 + 1) != 0 /*0x141024812*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)(*((_QWORD *)&v51 + 1) + 8LL), 0xFFFFFFFF) == 1 )
          {
            (**(void (__fastcall ***)(volatile signed __int32 *))v19)(a1: v19); /*0x14102481a*/
            if ( _InterlockedExchangeAdd(v19 + 3, 0xFFFFFFFF) == 1 ) /*0x141024826*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v19 + 8LL))(a1: v19); /*0x14102482e*/
          }
          proxy = *(std::shared_ptr<RBX::Network::ServerReplicator> *)v47; /*0x141024839*/
          v20 = std::_Hash<std::_Umap_traits<RakNet::SystemAddress,RBX::Network::Replicator *,std::_Uhash_compare<RakNet::SystemAddress,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>,std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::Replicator *>>,0>>::_Try_emplace<RakNet::SystemAddress const &,>( /*0x141024853*/
                  this: &v4->serverReplicatorByAddress,
                  result: &v60,
                  _Keyval_arg: &peerInfo.remotePlayerAddress);
          v21 = v47[0]; /*0x14102485b*/
          v20->first->_Myval.second = v47[0]; /*0x141024863*/
          v22 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)v4->rakPeer._Ptr); /*0x14102486e*/
          v23 = v22->onInternalError._Mystorage._Ptrs[0][84].__vftable; /*0x141024876*/
          qmemcpy(v58, v3, sizeof(v58)); /*0x141024881*/
          v24 = (std::shared_ptr<RBX::Security::SessionCrypto> *)((__int64 (__fastcall *)(Luau::InternalErrorReporter *, char *, _QWORD *))v23)( /*0x1410248a9*/
                                                                   a1: v22,
                                                                   a2: v54,
                                                                   a3: v58);
          RBX::Network::Replicator::setSessionCrypto(this: v21, context: v24); /*0x1410248b2*/
          if ( FFlag::RuppTokEn4.value ) /*0x1410248be*/
          {
            v25 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)v4->rakPeer._Ptr); /*0x1410248c7*/
            v26 = v25->onInternalError._Mystorage._Ptrs[0][85].__vftable; /*0x1410248cf*/
            qmemcpy(v59, v3, sizeof(v59)); /*0x1410248da*/
            v21->tokenOptions = *(std::optional<unsigned int> *)((__int64 (__fastcall *)(Luau::InternalErrorReporter *, char *, std::pair<std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *,bool> *))v26)( /*0x141024908*/
                                                                  a1: v25,
                                                                  a2: v53,
                                                                  a3: v59);
          }
          if ( v21->shouldReportToEventIngest ) /*0x14102490f*/
            RBX::Network::ServerReplicator::updateConnectionAcceptedTime(this: v21); /*0x14102491b*/
          v48 = 0; /*0x141024923*/
          RBX::Instance::setAndLockParent(this: v21, instance: v4, destroying: false, destroyedGuids: &v48); /*0x14102493d*/
        }
        __unwind
        {
          rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (enum RBX::MaterialType)>>,enum RBX::MaterialType>::do_dtor(this: (std::_Binder<std::_Unforced,void (__cdecl RBX::NavigationDebugDraw::*)(dtNavMesh *,RBX::Extents),std::shared_ptr<RBX::NavigationDebugDraw> &,std::_Ph<1> const &,RBX::Extents &> *)&peerInfo); /*0xf1c0000000000058*/
        }
        v2 = peerInfo.rakPeer._Rep; /*0x141024943*/
        if ( peerInfo.rakPeer._Rep != nullptr /*0x14102495a*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&peerInfo.rakPeer._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v2->_Destroy(this: v2); /*0x141024962*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v2->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14102496e*/
            v2->_Delete_this(this: v2); /*0x141024976*/
        }
LABEL_54:
        if ( proxy._Rep != nullptr /*0x1410249a5*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&proxy._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v2 = proxy._Rep; /*0x1410249a7*/
          proxy._Rep->_Destroy(this: proxy._Rep); /*0x1410249b2*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v2->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410249bc*/
            proxy._Rep->_Delete_this(this: proxy._Rep); /*0x1410249c6*/
        }
      }
      if ( __eh34_catch(2) )
      {
        if ( __eh34_catch_type(2, &std::exception `RTTI Type Descriptor', &e) )
        {
          v35 = v2; /*0x1431e6350*/
          if ( FLog::Error != 0 ) /*0x1431e636f*/
          {
            FLog::FastLog( /*0x1431e6380*/
              level: FLog::Error,
              message: "[FLog::Error] On receive packet %d",
              arg0: (const void *)*packet->data);
            v36 = e; /*0x1431e6385*/
            if ( FLog::Error != 0 ) /*0x1431e6390*/
            {
              v37 = e->what(this: e); /*0x1431e6398*/
              FLog::FastLogS(level: FLog::Error, message: "[FLog::Error] Error %s", sarg: v37); /*0x1431e63ac*/
            }
          }
          else
          {
            v36 = e; /*0x1431e63b3*/
          }
          v38 = v36->what(this: v36); /*0x1431e63bd*/
          RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "Server::OnReceive packet %d: %s", *packet->data, v38);
          v39 = proxy._Ptr; /*0x1431e63dc*/
          if ( proxy._Ptr != nullptr ) /*0x1431e63e8*/
          {
            proxy._Ptr->isParentLocked = false; /*0x1431e63ea*/
            v46 = 0; /*0x1431e63f1*/
            RBX::Instance::setParentInternal( /*0x1431e640d*/
              this: v39,
              newParent: nullptr,
              ignoreLock: false,
              destroying: false,
              destroyedGuids: &v46);
          }
          v2 = v35; /*0x1431e6424*/
          v4 = this; /*0x141024981*/
          v3 = packet; /*0x141024989*/
          __eh34_enter_try_state(1, 2); /*0xf1c000000000004c*/
          goto LABEL_54; /*0xf1c000000000001c*/
        }
      }
      __eh34_exit_try_state(2, 1); /*0xf1c00000000000d8*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&proxy); /*0xf1c00000000000e0*/
    }
    v27 = RakNet::SystemAddress::ToInteger(sa: &v3->systemAddress); /*0x1410249cc*/
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&memscopeNetworkReplicator); /*0xf1c00000000000b8*/
  }
  __eh34_enter_wind_state(-1, 8); /*0xf1c00000000000c0*/
  v28 = 2 * (v27 & v4->serverReplicatorByAddress._Mask); /*0x1410249dd*/
  Myfirst = v4->serverReplicatorByAddress._Vec._Mypair._Myval2._Myfirst; /*0x1410249e0*/
  v30 = Myfirst[v28 + 1]._Ptr; /*0x1410249e7*/
  if ( v30 != v4->serverReplicatorByAddress._List._Mypair._Myval2._Myhead ) /*0x1410249f3*/
  {
    v31 = Myfirst[v28]._Ptr; /*0x1410249f5*/
    if ( RakNet::SystemAddress::operator==(this: &v3->systemAddress, right: &v30->_Myval.first) != 0 ) /*0x141024a07*/
    {
LABEL_63:
      if ( v30 != nullptr && v30 != v4->serverReplicatorByAddress._List._Mypair._Myval2._Myhead ) /*0x141024a35*/
      {
        v32 = v30->_Myval.second->OnReceive(this: v30->_Myval.second, a2: v3); /*0x141024a47*/
        RBX::Memory::setCurrentCategory(category: memscopeNetworkReplicator.parent); /*0x141024a50*/
        if ( __eh34_unwind(8) ) /*0xf1c0000000000040*/
          goto unwind_state_8; /*0xf1c0000000000040*/
        __eh34_exit_wind_state(8, -1); /*0xf1c0000000000044*/
        return (unsigned int)v32; /*0x141024a64*/
      }
    }
    else
    {
      while ( v30 != v31 ) /*0x141024a13*/
      {
        v30 = v30->_Prev; /*0x141024a15*/
        if ( RakNet::SystemAddress::operator==(this: &v3->systemAddress, right: &v30->_Myval.first) != 0 ) /*0x141024a27*/
          goto LABEL_63; /*0x141024a27*/
      }
    }
  }
  RBX::Memory::setCurrentCategory(category: memscopeNetworkReplicator.parent); /*0x141024a6c*/
  result = 1; /*0x141024a72*/
  if ( __eh34_unwind(8) ) /*0xf1c000000000002c*/
unwind_state_8:
    __std_terminate(a1: v33, a2: &v40); /*0xf1c0000000000030*/
  __eh34_exit_wind_state(8, -1); /*0xf1c0000000000038*/
  return result; /*0x141024a58*/
}

// Address: 0x1410255a0 | Name: ?askAddChild@Server@Network@RBX@@MEBA_NPEBVInstance@3@@Z
bool __fastcall RBX::Network::Server::askAddChild(RBX::Network::Server *this, const RBX::Instance *instance)
{
  const RBX::Instance *v2; // rdi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v4; // rax

  v2 = instance; /*0x1410255a6*/
  if ( instance == nullptr /*0x1410255dd*/
    || (descriptor = instance->descriptor,
        v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ServerReplicator>(),
        descriptor->index - (unsigned int)v4->index > v4->descendantCount) )
  {
    v2 = nullptr; /*0x1410255df*/
  }
  return v2 != nullptr; /*0x1410255e7*/
}

// Address: 0x141025620 | Name: ?configureAsCloudEditServer@Server@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::Server::configureAsCloudEditServer(RBX::Network::Server *this)
{
  RBX::Network *v2; // rcx
  RBX::DataModel *v3; // rax
  Luau::InternalErrorReporter *v4; // rax
  std::string *Ptr; // rdx
  RBX::Analytics::Event::GAReporter *CurrentReporter; // r9
  char *v7; // rcx
  void *v8; // rcx
  RBX::Graphics::ProfilerAdorn::Item key; // [rsp+30h] [rbp-48h] BYREF
  unsigned __int64 value_24; // [rsp+68h] [rbp-10h]

  if ( RBX::Players::clientIsPresent(context: this, testInDatamodel: true) ) /*0x14102562b*/
  {
    RBX::runtime_error(result: (std::runtime_error *)&key, fmt: "Can not call server, client is present."); /*0x141025807*/
    throw (std::runtime_error *)&key; /*0x141025818*/
  }
  if ( DFFlag::RCCSupportCloudEdit.value ) /*0x14102563e*/
  {
    if ( FFlag::UsingDataModelCloudMode.value ) /*0x14102564a*/
    {
      v3 = RBX::DataModel::get(context: this); /*0x14102564f*/
      if ( v3 != nullptr ) /*0x141025657*/
        RBX::DataModel::setCloudEdit(this: v3); /*0x14102565c*/
    }
    if ( !FFlag::DebugLocalRccServerConnection.value ) /*0x141025668*/
      RBX::Network::initWithCloudEditSecurity(this: v2); /*0x14102566a*/
    v4 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141025676*/
    Ptr = &RBX::Network::versionB; /*0x141025682*/
    if ( RBX::Network::versionB._Mypair._Myval2._Myres >= 0x10 ) /*0x141025691*/
      Ptr = (std::string *)RBX::Network::versionB._Mypair._Myval2._Bx._Ptr; /*0x141025691*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, std::string *, _QWORD))v4->onInternalError._Mystorage._Ptrs[0][10].__vftable)( /*0x1410256a3*/
      a1: v4,
      a2: Ptr,
      a3: LODWORD(RBX::Network::versionB._Mypair._Myval2._Mysize));
    this->serverReplicationMode = ReplicationMode_StudioAsEditor; /*0x1410256a6*/
    RBX::Network::MegaReplicator::setIsCloudEdit(this: &this->megaReplicator); /*0x1410256b7*/
    RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1410256d9*/
      category: "Game",
      action: "Team Create",
      label: "Server Start",
      value: 0,
      sync: false);
    CurrentReporter = RBX::Analytics::Event::getCurrentReporter(); /*0x1410256e3*/
    if ( CurrentReporter != nullptr ) /*0x1410256e9*/
    {
      value_24 = 15; /*0x1410256f6*/
      *(_QWORD *)&key.color = 4; /*0x1410256ff*/
      *(_QWORD *)&key.x = *(unsigned int *)"edit"; /*0x14102570e*/
      __wind /*0xf1c0000000000028*/
      {
        key.text._Mypair._Myval2._Myres = 15; /*0x141025716*/
        key.text._Mypair._Myval2._Mysize = 13; /*0x14102571f*/
        qmemcpy(&key, "rcc_tc_confi", 12); /*0x141025730*/
        *(_WORD *)&key.text._Mypair._Myval2._Bx._Alias[12] = (unsigned __int8)aRccTcConfig[12]; /*0x141025747*/
        __wind /*0xf1c0000000000004*/
        {
          RBX::Analytics::Event::GAReporter::addParameter( /*0x14102575c*/
            this: CurrentReporter,
            key: &key.text,
            value: (const std::string *)&key.x);
          if ( key.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14102576b*/
          {
            v7 = key.text._Mypair._Myval2._Bx._Ptr; /*0x141025770*/
            if ( key.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14102577f*/
            {
              v7 = *((char **)key.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141025785*/
              if ( (unsigned __int64)(key.text._Mypair._Myval2._Bx._Ptr - v7 - 8) > 0x1F ) /*0x141025794*/
                _invalid_parameter_noinfo_noreturn(); /*0x141025796*/
            }
            operator delete(ptr: v7); /*0x14102579d*/
          }
          key.text._Mypair._Myval2._Mysize = 0; /*0x1410257a2*/
          key.text._Mypair._Myval2._Myres = 15; /*0x1410257a7*/
          key.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410257b0*/
          if ( value_24 >= 0x10 ) /*0x1410257be*/
          {
            v8 = *(void **)&key.x; /*0x1410257c3*/
            if ( value_24 + 1 >= 0x1000 ) /*0x1410257d2*/
            {
              v8 = *(void **)(*(_QWORD *)&key.x - 8LL); /*0x1410257d8*/
              if ( (unsigned __int64)(*(_QWORD *)&key.x - (_QWORD)v8 - 8LL) > 0x1F ) /*0x1410257e7*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410257e9*/
            }
            operator delete(ptr: v8); /*0x1410257f0*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &key); /*0xf1c0000000000014*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key.x); /*0xf1c0000000000020*/
      }
    }
  }
}

// Address: 0x141025820 | Name: ?configureAsTeamTestServer@Server@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::Server::configureAsTeamTestServer(RBX::Network::Server *this)
{
  RBX::Network *v2; // rcx
  RBX::DataModel *v3; // rax
  Luau::InternalErrorReporter *v4; // rax
  std::string *Ptr; // rdx
  RBX::Analytics::Event::GAReporter *CurrentReporter; // r9
  char *v7; // rcx
  void *v8; // rcx
  RBX::Graphics::ProfilerAdorn::Item key; // [rsp+30h] [rbp-48h] BYREF
  unsigned __int64 value_24; // [rsp+68h] [rbp-10h]

  if ( RBX::Players::clientIsPresent(context: this, testInDatamodel: true) ) /*0x14102582b*/
  {
    RBX::runtime_error(result: (std::runtime_error *)&key, fmt: "Cannot call configureAsTeamTestServer() from clients"); /*0x141025a2a*/
    throw (std::runtime_error *)&key; /*0x141025a3b*/
  }
  if ( FFlag::RCCSupportTeamTest.value ) /*0x14102583e*/
  {
    if ( FFlag::UsingDataModelCloudMode.value ) /*0x14102584a*/
    {
      v3 = RBX::DataModel::get(context: this); /*0x14102584f*/
      if ( v3 != nullptr ) /*0x141025857*/
        *(_DWORD *)v3->cloudMode = 2; /*0x141025859*/
    }
    if ( !FFlag::DebugLocalRccServerConnection.value ) /*0x14102586a*/
      RBX::Network::initWithCloudEditSecurity(this: v2); /*0x14102586c*/
    v4 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141025878*/
    Ptr = &RBX::Network::versionB; /*0x141025884*/
    if ( RBX::Network::versionB._Mypair._Myval2._Myres >= 0x10 ) /*0x141025893*/
      Ptr = (std::string *)RBX::Network::versionB._Mypair._Myval2._Bx._Ptr; /*0x141025893*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, std::string *, _QWORD))v4->onInternalError._Mystorage._Ptrs[0][10].__vftable)( /*0x1410258a5*/
      a1: v4,
      a2: Ptr,
      a3: LODWORD(RBX::Network::versionB._Mypair._Myval2._Mysize));
    this->serverReplicationMode = ReplicationMode_StudioAsClient; /*0x1410258a8*/
    RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1410258cf*/
      category: "Game",
      action: "Team Create",
      label: "Test Server Start",
      value: 0,
      sync: false);
    CurrentReporter = RBX::Analytics::Event::getCurrentReporter(); /*0x1410258d9*/
    if ( CurrentReporter != nullptr ) /*0x1410258df*/
    {
      value_24 = 15; /*0x1410258e5*/
      *(_QWORD *)&key.color = 9; /*0x1410258ee*/
      *(_QWORD *)&key.x = *(_QWORD *)"team_test"; /*0x1410258ff*/
      LOWORD(key.width) = (unsigned __int8)aTeamTest[8]; /*0x14102590c*/
      __wind /*0xf1c0000000000028*/
      {
        key.text._Mypair._Myval2._Myres = 15; /*0x141025915*/
        key.text._Mypair._Myval2._Mysize = 13; /*0x14102591e*/
        qmemcpy(&key, "rcc_tc_confi", 12); /*0x14102592f*/
        *(_WORD *)&key.text._Mypair._Myval2._Bx._Alias[12] = (unsigned __int8)aRccTcConfig[12]; /*0x141025946*/
        __wind /*0xf1c0000000000004*/
        {
          RBX::Analytics::Event::GAReporter::addParameter( /*0x14102595c*/
            this: CurrentReporter,
            key: &key.text,
            value: (const std::string *)&key.x);
          if ( key.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14102596b*/
          {
            v7 = key.text._Mypair._Myval2._Bx._Ptr; /*0x141025970*/
            if ( key.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14102597f*/
            {
              v7 = *((char **)key.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141025985*/
              if ( (unsigned __int64)(key.text._Mypair._Myval2._Bx._Ptr - v7 - 8) > 0x1F ) /*0x141025994*/
                _invalid_parameter_noinfo_noreturn(); /*0x141025996*/
            }
            operator delete(ptr: v7); /*0x14102599d*/
          }
          key.text._Mypair._Myval2._Mysize = 0; /*0x1410259a2*/
          key.text._Mypair._Myval2._Myres = 15; /*0x1410259ab*/
          key.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410259b4*/
          if ( value_24 >= 0x10 ) /*0x1410259c2*/
          {
            v8 = *(void **)&key.x; /*0x1410259c7*/
            if ( value_24 + 1 >= 0x1000 ) /*0x1410259d6*/
            {
              v8 = *(void **)(*(_QWORD *)&key.x - 8LL); /*0x1410259dc*/
              if ( (unsigned __int64)(*(_QWORD *)&key.x - (_QWORD)v8 - 8LL) > 0x1F ) /*0x1410259eb*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410259ed*/
            }
            operator delete(ptr: v8); /*0x1410259f4*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &key); /*0xf1c0000000000014*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key.x); /*0xf1c0000000000020*/
      }
    }
    if ( DFLog::TeamTest != 0 ) /*0x141025a02*/
      FLog::FastLog( /*0x141025a13*/
        level: DFLog::TeamTest,
        message: "[DFLog::TeamTest] Finished configuring as team test server",
        arg0: nullptr);
  }
}

// Address: 0x141025e50 | Name: ?detachReplicatorFromPeer@Server@Network@RBX@@QEAAXAEBUSystemAddress@RakNet@@@Z
void __fastcall RBX::Network::Server::detachReplicatorFromPeer(
        RBX::Network::Server *this,
        RakNet::SystemAddress *address)
{
  __int64 v4; // r14
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *> > > > *Myfirst; // rax
  std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *Ptr; // rbx
  std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *v7; // rdi
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *> > > > *v8; // rdx
  std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *v9; // rax
  std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *Myhead; // rax
  std::_List_node<std::pair<RakNet::SystemAddress const ,RBX::Network::Replicator *>,void *> *Next; // rcx

  v4 = RakNet::SystemAddress::ToInteger(sa: address); /*0x141025e7a*/
  Myfirst = this->serverReplicatorByAddress._Vec._Mypair._Myval2._Myfirst; /*0x141025e7d*/
  Ptr = Myfirst[2 * (v4 & this->serverReplicatorByAddress._Mask) + 1]._Ptr; /*0x141025e8a*/
  if ( Ptr != this->serverReplicatorByAddress._List._Mypair._Myval2._Myhead ) /*0x141025e96*/
  {
    v7 = Myfirst[2 * (v4 & this->serverReplicatorByAddress._Mask)]._Ptr; /*0x141025ea5*/
    if ( RakNet::SystemAddress::operator==(this: address, right: &Ptr->_Myval.first) != 0 ) /*0x141025eb3*/
    {
LABEL_5:
      if ( Ptr != nullptr ) /*0x141025ed5*/
      {
        v8 = &this->serverReplicatorByAddress._Vec._Mypair._Myval2._Myfirst[2 /*0x141025ee5*/
                                                                          * (v4 & this->serverReplicatorByAddress._Mask)];
        v9 = v8->_Ptr; /*0x141025eec*/
        if ( v8[1]._Ptr == Ptr ) /*0x141025ef3*/
        {
          if ( v9 == Ptr ) /*0x141025ef8*/
          {
            Myhead = this->serverReplicatorByAddress._List._Mypair._Myval2._Myhead; /*0x141025efa*/
            v8->_Ptr = Myhead; /*0x141025f01*/
          }
          else
          {
            Myhead = Ptr->_Prev; /*0x141025f0a*/
          }
          v8[1]._Ptr = Myhead; /*0x141025f04*/
        }
        else if ( v9 == Ptr ) /*0x141025f17*/
        {
          v8->_Ptr = Ptr->_Next; /*0x141025f1c*/
        }
        Next = Ptr->_Next; /*0x141025f1f*/
        --this->serverReplicatorByAddress._List._Mypair._Myval2._Mysize; /*0x141025f27*/
        Ptr->_Prev->_Next = Next; /*0x141025f32*/
        Next->_Prev = Ptr->_Prev; /*0x141025f39*/
        operator delete(ptr: Ptr); /*0x141025f40*/
      }
    }
    else
    {
      while ( Ptr != v7 ) /*0x141025eb8*/
      {
        Ptr = Ptr->_Prev; /*0x141025ebe*/
        if ( RakNet::SystemAddress::operator==(this: address, right: &Ptr->_Myval.first) != 0 ) /*0x141025ed0*/
          goto LABEL_5; /*0x141025ed0*/
      }
    }
  }
}

// Address: 0x141026900 | Name: ?encryptStringForPlayerId@Server@Network@RBX@@QEAA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@AEBV45@_J@Z
std::string *__fastcall RBX::Network::Server::encryptStringForPlayerId(
        RBX::Network::Server *this,
        std::string *result,
        const std::string *toEncrypt,
        __int64 playerId)
{
  std::string *v6; // rax
  std::_Ref_count_base *Rep; // rbx
  std::shared_ptr<RBX::Network::ServerReplicator> replicator; // [rsp+20h] [rbp-18h] BYREF

  if ( DFFlag::EnableLuaApiToRegisterEncryptedAssets.value ) /*0x14102691c*/
  {
    RBX::Network::Server::getServerReplicatorForPlayerId(this, result: &replicator, playerId); /*0x14102694c*/
    __wind /*0xf1c0000000000010*/
    {
      if ( replicator._Ptr != nullptr ) /*0x14102695a*/
      {
        RBX::Network::Replicator::sessionEncryptString(this: replicator._Ptr, result, toEncrypt); /*0x141026977*/
      }
      else
      {
        result->_Mypair._Myval2._Bx._Ptr = nullptr; /*0x14102695e*/
        result->_Mypair._Myval2._Mysize = 0; /*0x141026961*/
        result->_Mypair._Myval2._Myres = 15; /*0x141026965*/
        result->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14102696d*/
      }
      if ( replicator._Rep != nullptr /*0x141026996*/
        && _InterlockedExchangeAdd((volatile signed __int32 *)&replicator._Rep->_Uses, 0xFFFFFFFF) == 1 )
      {
        Rep = replicator._Rep; /*0x141026998*/
        replicator._Rep->_Destroy(this: replicator._Rep); /*0x1410269a3*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410269ad*/
          replicator._Rep->_Delete_this(this: replicator._Rep); /*0x1410269b7*/
      }
      v6 = result; /*0x1410269ba*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&replicator); /*0xf1c0000000000008*/
    }
  }
  else
  {
    result->_Mypair._Myval2._Bx._Ptr = nullptr; /*0x141026920*/
    result->_Mypair._Myval2._Mysize = 0; /*0x141026923*/
    result->_Mypair._Myval2._Myres = 15; /*0x141026927*/
    result->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14102692f*/
    return result; /*0x141026931*/
  }
  return v6; /*0x141026934*/
}

// Address: 0x1410271f0 | Name: ?getIsPlayerAuthenticationRequired@Server@Network@RBX@@QEBA_NXZ
bool __fastcall RBX::Network::Server::getIsPlayerAuthenticationRequired(RBX::Network::Server *this)
{
  return !FFlag::DebugLocalRccServerConnection.value /*0x141027216*/
      && RBX::Network::isPlayerAuthenticationEnabled()
      && this->isPlayerAuthenticationRequired;
}

// Address: 0x141027230 | Name: ?getNetworkOwnerJob@Server@Network@RBX@@QEAAPEAVNetworkOwnerJob@23@XZ
RBX::Network::NetworkOwnerJob *__fastcall RBX::Network::Server::getNetworkOwnerJob(RBX::Network::Server *this)
{
  return (RBX::Network::NetworkOwnerJob *)this->networkOwnerJob._Ptr; /*0x141027237*/
}

// Address: 0x141027240 | Name: ?getNetworkSchemaInfo@Server@Network@RBX@@QEAA?AV?$shared_ptr@$$CBUServerSchemaInfo@Network@RBX@@@std@@XZ
std::shared_ptr<RBX::Network::ServerSchemaInfo const > *__fastcall RBX::Network::Server::getNetworkSchemaInfo(
        RBX::Network::Server *this,
        std::shared_ptr<RBX::Network::ServerSchemaInfo const > *result)
{
  const RBX::Network::ServerSchemaInfo *Ptr; // rcx
  std::_Ref_count_base *Rep; // rax
  std::shared_ptr<RBX::File> *v6; // rax
  std::shared_ptr<RBX::File> *v7; // rbx
  std::shared_ptr<RBX::File> *v8; // r14
  char *v9; // rax
  std::_Ref_count_base *v10; // r15
  RBX::Network::ServerSchemaInfo *v11; // r14
  std::_Ref_count_base *v12; // r14
  std::_Ref_count_base *v13; // rcx
  std::shared_ptr<RBX::Network::ServerSchemaInfo> newInfo; // [rsp+20h] [rbp-38h] BYREF
  std::shared_ptr<RBX::File> *v16; // [rsp+60h] [rbp+8h]
  std::shared_ptr<RBX::File> *v17; // [rsp+70h] [rbp+18h]
  void *v18; // [rsp+78h] [rbp+20h]

  Ptr = this->cachedNetworkSchemaInfo._Ptr; /*0x141027256*/
  if ( Ptr != nullptr ) /*0x141027260*/
  {
    result->_Ptr = nullptr; /*0x141027264*/
    result->_Rep = nullptr; /*0x141027267*/
    Rep = this->cachedNetworkSchemaInfo._Rep; /*0x14102726b*/
    if ( Rep != nullptr ) /*0x141027275*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141027277*/
      Ptr = this->cachedNetworkSchemaInfo._Ptr; /*0x14102727b*/
      Rep = this->cachedNetworkSchemaInfo._Rep; /*0x141027282*/
    }
    result->_Ptr = Ptr; /*0x141027289*/
    result->_Rep = Rep; /*0x14102728c*/
  }
  else
  {
    v6 = (std::shared_ptr<RBX::File> *)operator new(size: 0x90u); /*0x14102729a*/
    v7 = v6; /*0x14102729f*/
    v16 = v6; /*0x1410272a2*/
    if ( v6 != nullptr ) /*0x1410272aa*/
    {
      __wind /*0xf1c000000000006c*/
      {
        *v6 = 0; /*0x1410272b3*/
        LODWORD(v6->_Rep) = 1; /*0x1410272b6*/
        HIDWORD(v6->_Rep) = 1; /*0x1410272bd*/
        v6->_Ptr = (RBX::File *)std::_Ref_count_obj2<RBX::Network::ServerSchemaInfo>::`vftable'; /*0x1410272cb*/
        v8 = v6 + 1; /*0x1410272ce*/
        v17 = v6 + 1; /*0x1410272d2*/
        v9 = (char *)operator new(size: 0x50u); /*0x1410272dc*/
        __wind /*0xf1c0000000000030*/
        {
          v10 = (std::_Ref_count_base *)v9; /*0x1410272e1*/
          v18 = v9; /*0x1410272e4*/
          if ( v9 != nullptr ) /*0x1410272ee*/
          {
            *(_OWORD *)v9 = 0; /*0x1410272f3*/
            *((_DWORD *)v9 + 2) = 1; /*0x1410272f6*/
            *((_DWORD *)v9 + 3) = 1; /*0x1410272fd*/
            *(_QWORD *)v9 = std::_Ref_count_obj2<RBX::Network::NetworkStream>::`vftable'; /*0x14102730b*/
            RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)(v9 + 16)); /*0x141027312*/
          }
          else
          {
            v10 = nullptr; /*0x141027319*/
          }
        }
        __unwind
        {
          operator delete(ptr: v18); /*0x1431df032*/
        }
        __wind /*0xf1c0000000000048*/
        {
          v8->_Ptr = (RBX::File *)&v10[1]; /*0x141027320*/
          v7[1]._Rep = v10; /*0x141027323*/
          RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)&v7[2]); /*0x14102732b*/
          v7[6]._Ptr = nullptr; /*0x141027331*/
          v7[6]._Rep = nullptr; /*0x141027335*/
          v7[7]._Ptr = nullptr; /*0x141027339*/
          v7[7]._Rep = nullptr; /*0x14102733d*/
          v7[8]._Ptr = nullptr; /*0x141027341*/
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v17); /*0xf1c0000000000058*/
        }
      }
      __unwind
      {
        operator delete(ptr: v16); /*0x1431a55b2*/
      }
    }
    else
    {
      v7 = nullptr; /*0x141027349*/
    }
    __wind /*0xf1c0000000000024*/
    {
      v11 = (RBX::Network::ServerSchemaInfo *)&v7[1]; /*0x14102734b*/
      newInfo._Ptr = (RBX::Network::ServerSchemaInfo *)&v7[1]; /*0x14102734f*/
      newInfo._Rep = (std::_Ref_count_base *)v7; /*0x141027354*/
      RBX::Network::NetworkSchema::generateSchemaDefinitionPacket( /*0x141027362*/
        replicationMode: this->serverReplicationMode,
        out: (RBX::Network::ServerSchemaInfo *)&v7[1]);
      if ( v7 != nullptr ) /*0x14102736a*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v7->_Rep); /*0x14102736c*/
        v11 = newInfo._Ptr; /*0x141027370*/
      }
      this->cachedNetworkSchemaInfo._Ptr = v11; /*0x141027375*/
      v12 = this->cachedNetworkSchemaInfo._Rep; /*0x14102737c*/
      this->cachedNetworkSchemaInfo._Rep = (std::_Ref_count_base *)v7; /*0x141027383*/
      if ( v12 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v12->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410273a1*/
      {
        v12->_Destroy(this: v12); /*0x1410273a9*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v12->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410273b7*/
          v12->_Delete_this(this: v12); /*0x1410273bf*/
      }
      result->_Ptr = nullptr; /*0x1410273c2*/
      result->_Rep = nullptr; /*0x1410273c5*/
      v13 = this->cachedNetworkSchemaInfo._Rep; /*0x1410273c9*/
      if ( v13 != nullptr ) /*0x1410273d3*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v13->_Uses); /*0x1410273d5*/
        v13 = this->cachedNetworkSchemaInfo._Rep; /*0x1410273d9*/
      }
      result->_Ptr = this->cachedNetworkSchemaInfo._Ptr; /*0x1410273e7*/
      result->_Rep = v13; /*0x1410273ea*/
      if ( v7 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Rep, 0xFFFFFFFF) == 1 ) /*0x1410273fe*/
      {
        ((void (__fastcall *)(std::shared_ptr<RBX::File> *))v7->_Ptr->__vftable)(a1: v7); /*0x141027406*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Rep + 1, 0xFFFFFFFF) == 1 ) /*0x141027412*/
          ((void (__fastcall *)(std::shared_ptr<RBX::File> *))v7->_Ptr->_Wptr.std::_Ptr_base<RBX::File>::_Ptr)(a1: v7); /*0x14102741a*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&newInfo); /*0xf1c000000000001c*/
    }
  }
  return result; /*0x141027420*/
}

// Address: 0x141027440 | Name: ?getPlaceAuthenticationResultForOrigin@Server@Network@RBX@@QEAA?AV?$optional@H@std@@_J@Z
std::optional<int> *__fastcall RBX::Network::Server::getPlaceAuthenticationResultForOrigin(
        RBX::Network::Server *this,
        std::optional<int> *result,
        unsigned __int64 originPlaceId)
{
  boost::mutex *p_placeAuthenticationResultCacheMutex; // rbx
  unsigned __int64 bucket_count; // r9
  boost::unordered::detail::ptr_bucket *next; // rcx
  signed __int32 v9; // eax
  HANDLE event; // rax
  const boost::lock_error *v12; // rax
  __int64 v13; // [rsp+0h] [rbp-78h] BYREF
  boost::lock_error v14; // [rsp+20h] [rbp-58h] BYREF

  p_placeAuthenticationResultCacheMutex = &this->placeAuthenticationResultCacheMutex; /*0x14102745e*/
  if ( this == (RBX::Network::Server *)-2952LL ) /*0x141027468*/
  {
    v12 = boost::lock_error::lock_error(this: &v14, ev: 1, what_arg: "boost unique_lock has no mutex"); /*0x14102753c*/
    __wind /*0xf1c0000000000014*/
    {
      boost::throw_exception<boost::lock_error>(e: v12); /*0x141027545*/
    }
    __unwind
    {
      boost::thread_resource_error::~thread_resource_error(this: &v14); /*0xf1c0000000000024*/
    }
  }
  boost::detail::basic_timed_mutex::lock(this: p_placeAuthenticationResultCacheMutex); /*0x141027471*/
  __wind /*0xf1c0000000000038*/
  {
    bucket_count = this->placeAuthenticationResultCache.table_.bucket_count_; /*0x141027476*/
    if ( this->placeAuthenticationResultCache.table_.size_ != 0 /*0x1410274a4*/
      && (next = this->placeAuthenticationResultCache.table_.buckets_[originPlaceId % bucket_count].next_) != nullptr )
    {
      while ( 1 ) /*0x1410274a6*/
      {
        next = next->next_; /*0x1410274a6*/
        if ( next == nullptr ) /*0x1410274ac*/
          break; /*0x1410274ac*/
        if ( (boost::unordered::detail::ptr_bucket *)originPlaceId == next[1].next_ ) /*0x1410274b5*/
        {
          if ( (boost::unordered::detail::ptr_bucket *)originPlaceId == next[2].next_ ) /*0x1410274bb*/
            goto LABEL_17; /*0x1410274bb*/
        }
        else if ( (unsigned __int64)next[1].next_ % bucket_count != originPlaceId % bucket_count ) /*0x1410274c7*/
        {
          break; /*0x1410274c7*/
        }
      }
    }
    else
    {
      next = nullptr; /*0x141027517*/
LABEL_17:
      if ( next != nullptr ) /*0x14102751c*/
      {
        result->_Value = (int)next[3].next_; /*0x141027521*/
        result->_Has_value = true; /*0x141027524*/
LABEL_11:
        v9 = _InterlockedExchangeAdd(&p_placeAuthenticationResultCacheMutex->active_count, 0x80000000); /*0x1410274ce*/
        if ( (v9 & 0x40000000) == 0 /*0x1410274e9*/
          && v9 != 0x80000000
          && !_interlockedbittestandset(&p_placeAuthenticationResultCacheMutex->active_count, 0x1Eu) )
        {
          event = boost::detail::basic_timed_mutex::get_event(this: p_placeAuthenticationResultCacheMutex); /*0x1410274ee*/
          SetEvent(hEvent: event); /*0x1410274f6*/
        }
        return result; /*0xf1c0000000000048*/
      }
    }
    result->_Has_value = false; /*0x1410274c9*/
    goto LABEL_11; /*0x1410274c9*/
  }
  __unwind
  {
    __std_terminate(a1: next, a2: &v13); /*0x142f39fa8*/
  }
}

// Address: 0x141027550 | Name: ?getScriptIndexForSharedSource@Server@Network@RBX@@QEBA?AV?$optional@H@std@@AEBVSharedString@3@@Z
std::optional<int> *__fastcall RBX::Network::Server::getScriptIndexForSharedSource(
        RBX::Network::Server *this,
        std::optional<int> *result,
        const RBX::SharedString *source)
{
  boost::unordered::iterator_detail::c_iterator<boost::unordered::detail::ptr_node<std::pair<RBX::SharedString const ,int> > > it; // [rsp+30h] [rbp+8h] BYREF

  boost::unordered::unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const,int>>>::find( /*0x141027565*/
    this: &this->scriptsBySharedSource,
    result: &it,
    k: source);
  if ( it.node_ != nullptr ) /*0x141027572*/
  {
    result->_Value = *((_DWORD *)&it.node_->value_base_.data_.data_.align_ + 4); /*0x14102757a*/
    result->_Has_value = true; /*0x14102757c*/
    return result; /*0x141027577*/
  }
  else
  {
    result->_Has_value = false; /*0x141027586*/
    return result; /*0x14102758a*/
  }
}

// Address: 0x1410276e0 | Name: ?getServerReplicatorForPlayerId@Server@Network@RBX@@QEAA?AV?$shared_ptr@VServerReplicator@Network@RBX@@@std@@_J@Z
std::shared_ptr<RBX::Network::ServerReplicator> *__fastcall RBX::Network::Server::getServerReplicatorForPlayerId(
        RBX::Network::Server *this,
        std::shared_ptr<RBX::Network::ServerReplicator> *result,
        unsigned __int64 playerId)
{
  unsigned __int64 bucket_count; // r11
  boost::unordered::detail::ptr_bucket *next; // rcx
  boost::unordered::detail::ptr_bucket *v5; // r8
  signed __int32 v6; // eax
  signed __int32 v7; // ett

  bucket_count = this->serverReplicatorByPlayer.table_.bucket_count_; /*0x1410276e0*/
  if ( this->serverReplicatorByPlayer.table_.size_ != 0 ) /*0x1410276fd*/
  {
    next = this->serverReplicatorByPlayer.table_.buckets_[playerId % bucket_count].next_; /*0x141027706*/
    if ( next != nullptr ) /*0x14102770d*/
    {
      while ( 1 ) /*0x14102770f*/
      {
        next = next->next_; /*0x14102770f*/
        if ( next == nullptr ) /*0x141027715*/
          break; /*0x141027715*/
        if ( (boost::unordered::detail::ptr_bucket *)playerId == next[1].next_ ) /*0x14102771e*/
        {
          if ( (boost::unordered::detail::ptr_bucket *)playerId == next[2].next_ ) /*0x141027724*/
          {
            result->_Ptr = nullptr; /*0x14102772d*/
            result->_Rep = nullptr; /*0x141027730*/
            v5 = next[4].next_; /*0x141027734*/
            if ( v5 == nullptr ) /*0x14102773b*/
              return result; /*0x14102773b*/
            v6 = (signed __int32)v5[1].next_; /*0x14102773d*/
            if ( v6 == 0 ) /*0x141027743*/
              return result; /*0x141027743*/
            while ( 1 ) /*0x141027748*/
            {
              v7 = v6; /*0x141027748*/
              v6 = _InterlockedCompareExchange((volatile signed __int32 *)&v5[1], v6 + 1, v6); /*0x141027748*/
              if ( v7 == v6 ) /*0x14102774e*/
                break; /*0x14102774e*/
              if ( v6 == 0 ) /*0x141027752*/
                return result; /*0x141027757*/
            }
            *result = *(std::shared_ptr<RBX::Network::ServerReplicator> *)&next[3].next_; /*0x141027773*/
            return result; /*0x14102777e*/
          }
        }
        else if ( (unsigned __int64)next[1].next_ % bucket_count != playerId % bucket_count ) /*0x141027760*/
        {
          break; /*0x141027760*/
        }
      }
    }
  }
  result->_Ptr = nullptr; /*0x141027762*/
  result->_Rep = nullptr; /*0x141027767*/
  return result; /*0x141027757*/
}

// Address: 0x141027790 | Name: ?getSharedScriptBytecodeForIndex@Server@Network@RBX@@QEBA?AV?$optional@VSharedString@RBX@@@std@@H@Z
std::optional<RBX::SharedString> *__fastcall RBX::Network::Server::getSharedScriptBytecodeForIndex(
        RBX::Network::Server *this,
        std::optional<RBX::SharedString> *result,
        int index)
{
  RBX::Network::Server::LegalScript *Myfirst; // r10
  __int64 v4; // r9
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *h; // rax

  Myfirst = this->legalScripts._Mypair._Myval2._Myfirst; /*0x141027790*/
  if ( index >= (unsigned __int64)(this->legalScripts._Mypair._Myval2._Mylast - Myfirst) ) /*0x1410277ab*/
  {
    result->_Has_value = false; /*0x1410277cd*/
    return result; /*0x1410277d1*/
  }
  else
  {
    v4 = index; /*0x1410277ad*/
    h = Myfirst[v4].sharedBytecode.flyweight.h.h; /*0x1410277b1*/
    result->_Value.flyweight.h.h = h; /*0x1410277b6*/
    _InterlockedIncrement(&h->ref.value_); /*0x1410277b9*/
    result->_Value.readCount = Myfirst[v4].sharedBytecode.readCount; /*0x1410277c2*/
    result->_Has_value = true; /*0x1410277c8*/
    return result; /*0x1410277c5*/
  }
}

// Address: 0x141027840 | Name: ?handleExtAntiCheat@Server@Network@RBX@@QEAAXPEAUPacket@RakNet@@V?$shared_ptr@UExternalAntiCheatData@Security@RBX@@@std@@_JPEBD3AEBUSystemAddress@5@@Z
void __fastcall RBX::Network::Server::handleExtAntiCheat(
        RBX::Network::Server *this,
        RakNet::Packet *packet,
        std::shared_ptr<RBX::File> *extAntiCheatData,
        __int64 userId,
        const char *username,
        char *platform,
        const ec_method_st *addr)
{
  RBX::Network::Server *v8; // rdi
  unsigned __int8 *v9; // rbx
  unsigned __int64 v10; // r8
  unsigned __int8 *Myfirst; // r12
  unsigned __int8 *Mylast; // r13
  unsigned __int64 v13; // rdi
  void *v14; // rax
  __int64 v15; // r12
  char *Ptr; // rcx
  unsigned int v17; // edx
  std::_Ref_count_base *Rep; // rcx
  unsigned __int8 *v19; // rcx
  std::_Ref_count_base *v20; // rbx
  RBX::Network::ExtAntiCheatSubtype subtype[4]; // [rsp+40h] [rbp-81h] BYREF
  unsigned int sequenceNumber; // [rsp+44h] [rbp-7Dh] BYREF
  std::shared_ptr<RBX::Security::ExternalAntiCheatData> v23; // [rsp+48h] [rbp-79h] BYREF
  std::vector<unsigned char> msg; // [rsp+58h] [rbp-69h] BYREF
  std::vector<unsigned char> v25; // [rsp+70h] [rbp-51h] BYREF
  std::string v26; // [rsp+88h] [rbp-39h] BYREF
  RakNet::SystemAddress v27; // [rsp+B0h] [rbp-11h] BYREF

  v8 = this; /*0x14102786e*/
  memset(&msg, 0, sizeof(msg)); /*0x141027874*/
  v9 = nullptr; /*0x141027879*/
  __wind /*0xf1c0000000000034*/
  {
    __wind /*0xf1c000000000003c*/
    {
      RBX::Network::Peer::recvExtAntiCheatHelper(this, packet, subtype, &sequenceNumber, &msg); /*0x141027891*/
      if ( subtype[0] == SendMsg ) /*0x14102789e*/
      {
        v26._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410278a4*/
        v26._Mypair._Myval2._Mysize = 0; /*0x1410278a8*/
        v26._Mypair._Myval2._Myres = 15; /*0x1410278ac*/
        v10 = -1; /*0x1410278bb*/
        do /*0x1410278c8*/
          ++v10; /*0x1410278c0*/
        while ( platform[v10] != 0 ); /*0x1410278c8*/
        std::string::assign(this: &v26, _Ptr: platform, _Count: v10); /*0x1410278d1*/
        __wind /*0xf1c0000000000028*/
        {
          memset(&v25, 0, sizeof(v25)); /*0x1410278da*/
          Myfirst = msg._Mypair._Myval2._Myfirst; /*0x1410278e3*/
          Mylast = msg._Mypair._Myval2._Mylast; /*0x1410278e7*/
          if ( msg._Mypair._Myval2._Myfirst != msg._Mypair._Myval2._Mylast ) /*0x1410278ee*/
          {
            v13 = msg._Mypair._Myval2._Mylast - msg._Mypair._Myval2._Myfirst; /*0x1410278f3*/
            if ( (unsigned __int8 *)(msg._Mypair._Myval2._Mylast - msg._Mypair._Myval2._Myfirst) < (unsigned __int8 *)0x1000 ) /*0x1410278fd*/
            {
              if ( v13 != 0 ) /*0x14102792e*/
                v9 = (unsigned __int8 *)operator new(size: msg._Mypair._Myval2._Mylast - msg._Mypair._Myval2._Myfirst); /*0x141027938*/
            }
            else
            {
              if ( v13 + 39 < v13 ) /*0x141027906*/
                std::_Throw_bad_array_new_length(); /*0x141027adc*/
              v14 = operator new(size: v13 + 39); /*0x14102790c*/
              if ( v14 == nullptr ) /*0x141027914*/
                _invalid_parameter_noinfo_noreturn(); /*0x141027924*/
              v9 = (unsigned __int8 *)(((unsigned __int64)v14 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x14102791a*/
              *((_QWORD *)v9 - 1) = v14; /*0x14102791e*/
            }
            v25._Mypair._Myval2._Myfirst = v9; /*0x14102793b*/
            v25._Mypair._Myval2._Mylast = v9; /*0x14102793f*/
            v25._Mypair._Myval2._Myend = &v9[v13]; /*0x141027947*/
            memmove_0(a1: v9, Src: Myfirst, Size: Mylast - Myfirst); /*0x141027954*/
            v25._Mypair._Myval2._Mylast = &Mylast[v9 - Myfirst]; /*0x141027960*/
            v8 = this; /*0x141027964*/
          }
          v15 = userId; /*0x14102796c*/
          rbx::signal<void (std::vector<unsigned char>,__int64,std::string const &)>::operator()( /*0x14102797e*/
            this: &v8->extAntiCheatSignal,
            <args_0>: &v25,
            <args_1>: userId,
            <args_2>: &v26);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v26); /*0xf1c0000000000020*/
        }
        if ( v26._Mypair._Myval2._Myres >= 0x10 ) /*0x14102798c*/
        {
          Ptr = v26._Mypair._Myval2._Bx._Ptr; /*0x141027991*/
          if ( v26._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14102799f*/
          {
            Ptr = *((char **)v26._Mypair._Myval2._Bx._Ptr - 1); /*0x1410279a5*/
            if ( (unsigned __int64)(v26._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410279b4*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410279b6*/
          }
          operator delete(ptr: Ptr); /*0x1410279bd*/
        }
        if ( RBX::serverExtAntiCheatSignal != nullptr ) /*0x1410279ce*/
        {
          v17 = EVP_MD_pkey_type(meth: addr); /*0x1410279d8*/
          v23 = 0; /*0x1410279dd*/
          Rep = extAntiCheatData->_Rep; /*0x1410279e2*/
          if ( Rep != nullptr ) /*0x1410279e9*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410279eb*/
            Rep = extAntiCheatData->_Rep; /*0x1410279ef*/
          }
          v23._Ptr = (RBX::Security::ExternalAntiCheatData *)extAntiCheatData->_Ptr; /*0x1410279f6*/
          v23._Rep = Rep; /*0x1410279fa*/
          rbx::signal<void (std::vector<unsigned char> const &,std::shared_ptr<RBX::Security::ExternalAntiCheatData>,__int64,char const *,char const *,unsigned long)>::operator()( /*0x141027a22*/
            this: RBX::serverExtAntiCheatSignal,
            <args_0>: &msg,
            <args_1>: &v23,
            <args_2>: v15,
            <args_3>: username,
            <args_4>: platform,
            <args_5>: v17);
        }
        v27 = *(RakNet::SystemAddress *)&addr->flags; /*0x141027a2a*/
        RBX::Network::Peer::sendExtAntiCheatAckHelper(this: v8, addr: &v27, sequenceNumber); /*0x141027a41*/
      }
    }
    __unwind
    {
      RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&msg); /*0xf1c0000000000014*/
    }
    v19 = msg._Mypair._Myval2._Myfirst; /*0x141027a48*/
    if ( msg._Mypair._Myval2._Myfirst != nullptr ) /*0x141027a4f*/
    {
      if ( (unsigned __int8 *)(msg._Mypair._Myval2._Myend - msg._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x141027a62*/
      {
        v19 = *((unsigned __int8 **)msg._Mypair._Myval2._Myfirst - 1); /*0x141027a68*/
        if ( (unsigned __int64)(msg._Mypair._Myval2._Myfirst - v19 - 8) > 0x1F ) /*0x141027a77*/
          _invalid_parameter_noinfo_noreturn(); /*0x141027a79*/
      }
      operator delete(ptr: v19); /*0x141027a80*/
      memset(&msg, 0, sizeof(msg)); /*0x141027a88*/
    }
    v20 = extAntiCheatData->_Rep; /*0x141027a91*/
    if ( v20 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Uses, 0xFFFFFFFF) == 1 ) /*0x141027aa4*/
    {
      v20->_Destroy(this: v20); /*0x141027aac*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141027ab6*/
        v20->_Delete_this(this: v20); /*0x141027abe*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: extAntiCheatData); /*0xf1c0000000000008*/
  }
}

// Address: 0x141027af0 | Name: ?isScriptLegal@Server@Network@RBX@@QEBA_NPEAVInstance@3@@Z
_BOOL8 __fastcall RBX::Network::Server::isScriptLegal(RBX::Network::Server *this, RBX::Script *instance)
{
  bool v3; // bl
  _BOOL8 result; // rax
  std::optional<RBX::ProtectedString> scriptSource; // [rsp+20h] [rbp-38h] BYREF
  boost::unordered::iterator_detail::c_iterator<boost::unordered::detail::ptr_node<std::pair<RBX::SharedString const ,int> > > v6; // [rsp+70h] [rbp+18h] BYREF

  RBX::getScriptSourceFromInstance(result: &scriptSource, instance); /*0x141027afe*/
  __wind /*0xf1c0000000000010*/
  {
    v3 = !scriptSource._Has_value /*0x141027b2b*/
      || boost::unordered::unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const,int>>>::find(
           this: &this->scriptsBySharedSource,
           result: &v6,
           k: (const RBX::SharedString *)&scriptSource)->node_ != nullptr;
    if ( scriptSource._Has_value ) /*0x141027b32*/
    {
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &scriptSource._Value.sharedBytecode.flyweight.h); /*0x141027b39*/
      boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&scriptSource); /*0x141027b43*/
    }
    result = v3; /*0x141027b48*/
  }
  __unwind
  {
    std::optional<RBX::ProtectedString>::~optional<RBX::ProtectedString>(this: &scriptSource); /*0xf1c0000000000008*/
  }
  return result; /*0x141027b4b*/
}

// Address: 0x141027b60 | Name: ?onCreateRakPeer@Server@Network@RBX@@UEAAXXZ
void __fastcall RBX::Network::Server::onCreateRakPeer(RBX::Network::Server *this)
{
  Luau::InternalErrorReporter *v2; // rax
  std::string *Ptr; // rbx
  Luau::InternalErrorReporter *v4; // rax
  RBX::ServiceProvider *parent; // rdi
  RBX::Instance *v6; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v8; // rax
  unsigned __int8 v9; // al
  bool value; // bl
  Luau::InternalErrorReporter *v11; // rax

  RBX::Network::Peer::onCreateRakPeer(this); /*0x141027b72*/
  v2 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141027b7e*/
  ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD))v2->onInternalError._Mystorage._Ptrs[0][7].__vftable)( /*0x141027b90*/
    a1: v2,
    a2: (unsigned __int16)FInt::MaxClients);
  Ptr = &RBX::Network::versionB; /*0x141027b9b*/
  if ( FFlag::DebugLocalRccServerConnection.value ) /*0x141027ba2*/
    std::string::assign(this: &RBX::Network::versionB, _Ptr: "test", _Count: 4u); /*0x141027bb4*/
  v4 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141027bc0*/
  if ( RBX::Network::versionB._Mypair._Myval2._Myres >= 0x10 ) /*0x141027bd4*/
    Ptr = (std::string *)RBX::Network::versionB._Mypair._Myval2._Bx._Ptr; /*0x141027bd4*/
  ((void (__fastcall *)(Luau::InternalErrorReporter *, std::string *, _QWORD))v4->onInternalError._Mystorage._Ptrs[0][10].__vftable)( /*0x141027be9*/
    a1: v4,
    a2: Ptr,
    a3: LODWORD(RBX::Network::versionB._Mypair._Myval2._Mysize));
  parent = (RBX::ServiceProvider *)this->parent; /*0x141027bec*/
  if ( parent != nullptr ) /*0x141027bf3*/
  {
    v6 = parent->parent; /*0x141027bf5*/
    if ( v6 != nullptr ) /*0x141027bfc*/
      parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v6); /*0x141027c03*/
  }
  else
  {
    parent = (RBX::ServiceProvider *)this; /*0x141027c08*/
  }
  if ( parent != nullptr /*0x141027c32*/
    && (descriptor = parent->descriptor,
        v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(),
        descriptor->index - (unsigned int)v8->index <= v8->descendantCount) )
  {
    v9 = (unsigned __int8)RBX::ServiceProvider::create<RBX::RunService>(this: parent); /*0x141027c37*/
  }
  else
  {
    v9 = 0; /*0x141027c3e*/
  }
  if ( FFlag::DebugLocalRccServerConnection.value ) /*0x141027c47*/
    value = FFlag::DebugLocalRccTicketTesting.value; /*0x141027c49*/
  else
    value = RBX::Reflection::TypedPropertyDescriptor<RBX::UDim>::hasStringValue(__formal: v9) == 0; /*0x141027c5c*/
  v11 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141027c66*/
  ((void (__fastcall *)(Luau::InternalErrorReporter *, bool))v11->onInternalError._Mystorage._Ptrs[0][86].__vftable)( /*0x141027c83*/
    a1: v11,
    a2: value);
}

// Address: 0x141027c90 | Name: ?onItemAdded@Server@Network@RBX@@AEAAXV?$shared_ptr@VInstance@RBX@@@std@@@Z
void __fastcall RBX::Network::Server::onItemAdded(RBX::Network::Server *this, std::shared_ptr<RBX::File> *item)
{
  unsigned int v4; // eax
  unsigned int v5; // ebx
  bool Has_value; // al
  __int64 v7; // rcx
  std::_Ref_count_base *Rep; // rbx
  __int64 v9; // [rsp+0h] [rbp-58h] BYREF
  std::optional<RBX::ProtectedString> scriptSource; // [rsp+20h] [rbp-38h] BYREF
  RBX::Memory::Scope memscopeNetworkReplicator; // [rsp+70h] [rbp+18h] BYREF

  __wind /*0xf1c0000000000068*/
  {
    v4 = RBX::Memory::setCurrentCategory(category: RBX::Memory::NetworkReplicator); /*0x141027cb0*/
    __wind /*0xf1c000000000005c*/
    {
      v5 = v4; /*0x141027cb5*/
      memscopeNetworkReplicator.parent = v4; /*0x141027cb7*/
      RBX::getScriptSourceFromInstance(result: &scriptSource, instance: item->_Ptr); /*0x141027cc3*/
      Has_value = scriptSource._Has_value; /*0x141027cc9*/
      if ( scriptSource._Has_value ) /*0x141027cd0*/
      {
        __wind /*0xf1c0000000000014*/
        {
          RBX::Network::Server::registerLegalSharedScript(this, source: (const RBX::SharedString *)&scriptSource); /*0x141027cda*/
          Has_value = scriptSource._Has_value; /*0x141027cdf*/
        }
        __unwind
        {
          std::optional<RBX::ProtectedString>::~optional<RBX::ProtectedString>(this: &scriptSource); /*0xf1c0000000000024*/
        }
      }
    }
    __unwind
    {
      RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&memscopeNetworkReplicator); /*0xf1c0000000000030*/
    }
    __wind /*0xf1c0000000000038*/
    {
      if ( Has_value ) /*0x141027ce6*/
      {
        boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &scriptSource._Value.sharedBytecode.flyweight.h); /*0x141027ced*/
        boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&scriptSource); /*0x141027cf7*/
      }
      RBX::Memory::setCurrentCategory(category: v5); /*0x141027cff*/
      Rep = item->_Rep; /*0x141027d05*/
      if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141027d1d*/
      {
        Rep->_Destroy(this: Rep); /*0x141027d25*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141027d2f*/
          Rep->_Delete_this(this: Rep); /*0x141027d37*/
      }
    }
    __unwind
    {
      __std_terminate(a1: v7, a2: &v9); /*0x142f39fa8*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: item); /*0xf1c0000000000054*/
  }
}

// Address: 0x141027d50 | Name: ?onServiceProvider@Server@Network@RBX@@MEAAXPEAVServiceProvider@3@0@Z
void __fastcall RBX::Network::Server::onServiceProvider(
        RBX::Network::Server *this,
        RBX::ServiceProvider *oldProvider,
        RBX::ServiceProvider *newProvider)
{
  std::_Ref_count_base *Rep; // rcx
  std::_Ref_count_base *v7; // rbx
  std::_Ref_count_base *v8; // rdx
  RBX::Players *Ptr; // rcx
  unsigned int parent; // ebx
  rbx::signals::slot_base *v11; // rax
  rbx::signals::slot_base *v12; // rdi
  rbx::signal<void __cdecl(void)> *p_closingSignal; // rcx
  __int64 v14; // rcx
  rbx::signals::slot_base *p; // rcx
  RBX::Players *v16; // rax
  RBX::Players *v17; // r8
  std::_Ref_count_base *v18; // rdx
  signed __int32 Uses; // eax
  signed __int32 v20; // ett
  RBX::Players *v21; // r15
  char *v22; // rax
  int v23; // edi
  std::_Ref_count_base *v24; // r12
  int v25; // edi
  volatile signed __int32 *v26; // rbx
  volatile signed __int32 *v27; // rbx
  std::_Ref_count_base *v28; // rbx
  rbx::signal<void __cdecl(std::shared_ptr<RBX::Instance>)> *p_serviceRemovingSignal; // r12
  RBX::Network::NetworkOwnerJob *v30; // rax
  RBX::Network::NetworkOwnerJob *v31; // r15
  std::_Ref_count_base *v32; // rdx
  signed __int32 v33; // eax
  signed __int32 v34; // ett
  std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> *v35; // rcx
  char *v36; // rdx
  int v37; // edi
  std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> *v38; // rax
  volatile signed __int32 *v39; // rbx
  volatile signed __int32 *v40; // rbx
  RBX::Graphics::TextureVulkan::DownloadBuffer *v41; // r15
  std::_Ref_count_base *v42; // rax
  std::_Ref_count_base *v43; // rbx
  unsigned __int64 resourceListIndex; // rax
  RBX::Graphics::Device *v45; // rax
  std::_Ref_count_base *v46; // rdx
  volatile signed __int32 *v47; // rcx
  std::_Ref_count_base *v48; // r15
  std::_Ref_count_base *v49; // rcx
  RBX::Network::RomarkPhaseTrackingJob *v50; // rax
  RBX::Network::RomarkPhaseTrackingJob *v51; // r15
  std::_Ref_count_base *v52; // rdx
  signed __int32 v53; // eax
  signed __int32 v54; // ett
  std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> *v55; // rcx
  char *v56; // rdx
  int v57; // edi
  RBX::File *v58; // rax
  int v59; // edi
  volatile signed __int32 *v60; // rbx
  volatile signed __int32 *v61; // rbx
  RBX::Graphics::TextureVulkan::DownloadBuffer *v62; // rdi
  std::_Ref_count_base *v63; // rax
  std::_Ref_count_base *v64; // rbx
  unsigned __int64 v65; // rax
  RBX::Graphics::Device *v66; // rax
  std::_Ref_count_base *v67; // rdx
  volatile signed __int32 *v68; // rcx
  std::_Ref_count_base *v69; // rdi
  std::_Ref_count_base *v70; // rcx
  RBX::ObscureValue<__int64,0> *Myval2; // rcx
  boost::mutex *p_placeAuthenticationResultCacheMutex; // rbx
  signed __int32 v73; // eax
  HANDLE event; // rax
  __int64 v75; // rcx
  std::_Ref_count_base *v76; // rdx
  signed __int32 v77; // eax
  signed __int32 v78; // ett
  std::vector<boost::intrusive_ptr<rbx::signals::slot_base>> *v79; // rcx
  char *v80; // rdx
  int v81; // edi
  RBX::DataModel *v82; // rax
  int v83; // edi
  signed __int32 v84; // eax
  volatile signed __int32 *v85; // rbx
  signed __int32 v86; // eax
  signed __int32 v87; // eax
  volatile signed __int32 *v88; // rbx
  signed __int32 v89; // eax
  std::_Ref_count_base *v90; // rbx
  std::_Ref_count_base *v91; // rcx
  int v92; // edi
  __int64 v93; // rbx
  unsigned __int64 v94; // rax
  const char *v95; // rax
  RBX::Graphics::ProfilerAdorn::Item *v96; // r8
  unsigned int v97; // edi
  char *v98; // rcx
  std::_Ref_count_base *v99; // rcx
  rbx::signals::signal_base *v100; // r12
  rbx::signals::slot_base *v101; // rax
  rbx::signals::slot_base *v102; // r15
  unsigned int v103; // ebx
  __int64 v104; // rcx
  rbx::signals::scoped_connection *p_workspaceLoadedConnection; // r14
  rbx::signals::slot_base *v106; // rcx
  const boost::lock_error *v107; // rax
  _BYTE v108[32]; // [rsp+0h] [rbp-100h] BYREF
  void *v109; // [rsp+30h] [rbp-D0h]
  void *v110; // [rsp+38h] [rbp-C8h]
  rbx::signals::connection other; // [rsp+40h] [rbp-C0h] BYREF
  rbx::signals::connection con; // [rsp+48h] [rbp-B8h] BYREF
  __int64 v113; // [rsp+50h] [rbp-B0h]
  __int64 v114; // [rsp+58h] [rbp-A8h]
  __int64 v115; // [rsp+60h] [rbp-A0h]
  std::shared_ptr<RBX::TaskScheduler::Job> v116; // [rsp+68h] [rbp-98h] BYREF
  std::shared_ptr<RBX::TaskScheduler::Job> v117; // [rsp+78h] [rbp-88h] BYREF
  char v118; // [rsp+88h] [rbp-78h] BYREF
  volatile signed __int32 *v119; // [rsp+90h] [rbp-70h]
  char v120; // [rsp+98h] [rbp-68h] BYREF
  volatile signed __int32 *v121; // [rsp+A0h] [rbp-60h]
  char v122; // [rsp+A8h] [rbp-58h] BYREF
  volatile signed __int32 *v123; // [rsp+B0h] [rbp-50h]
  char v124; // [rsp+B8h] [rbp-48h] BYREF
  volatile signed __int32 *v125; // [rsp+C0h] [rbp-40h]
  std::shared_ptr<RBX::TaskScheduler::Job> v126; // [rsp+C8h] [rbp-38h] BYREF
  char v127; // [rsp+D8h] [rbp-28h] BYREF
  volatile signed __int32 *v128; // [rsp+E0h] [rbp-20h]
  char v129; // [rsp+E8h] [rbp-18h] BYREF
  volatile signed __int32 *v130; // [rsp+F0h] [rbp-10h]
  std::shared_ptr<RBX::TaskScheduler::Job> v131; // [rsp+F8h] [rbp-8h] BYREF
  char v132; // [rsp+108h] [rbp+8h] BYREF
  volatile signed __int32 *v133; // [rsp+110h] [rbp+10h]
  char v134; // [rsp+118h] [rbp+18h] BYREF
  volatile signed __int32 *v135; // [rsp+120h] [rbp+20h]
  RBX::Graphics::ProfilerAdorn::Item v136; // [rsp+128h] [rbp+28h] BYREF
  std::shared_ptr<RBX::File> v137; // [rsp+160h] [rbp+60h] BYREF
  std::shared_ptr<RBX::DataModel> dm; // [rsp+170h] [rbp+70h] BYREF
  boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned __int64,char> v139; // [rsp+180h] [rbp+80h] BYREF
  boost::unique_lock<boost::mutex> v140; // [rsp+198h] [rbp+98h] BYREF
  char v141; // [rsp+1A9h] [rbp+A9h] BYREF
  const char *v142; // [rsp+1D0h] [rbp+D0h] BYREF
  const char **v143; // [rsp+1D8h] [rbp+D8h]
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> v144; // [rsp+1E0h] [rbp+E0h] BYREF
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> v145; // [rsp+1E8h] [rbp+E8h] BYREF
  std::runtime_error result; // [rsp+1F0h] [rbp+F0h] BYREF
  boost::lock_error v147; // [rsp+208h] [rbp+108h] BYREF
  unsigned int v148; // [rsp+298h] [rbp+198h]
  int v149; // [rsp+298h] [rbp+198h]
  unsigned int v150; // [rsp+298h] [rbp+198h]
  int v151; // [rsp+298h] [rbp+198h]
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v152; // [rsp+2A0h] [rbp+1A0h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v153; // [rsp+2A8h] [rbp+1A8h] BYREF

  if ( oldProvider != nullptr ) /*0x141027d8a*/
  {
    rbx::signals::connection::disconnect(this: &this->closingConnection.con); /*0x141027d97*/
    v116 = 0; /*0x141027d9f*/
    Rep = this->networkOwnerJob._Rep; /*0x141027da5*/
    if ( Rep != nullptr ) /*0x141027daf*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141027db1*/
      Rep = this->networkOwnerJob._Rep; /*0x141027db5*/
    }
    v116._Ptr = this->networkOwnerJob._Ptr; /*0x141027dc3*/
    v116._Rep = Rep; /*0x141027dc8*/
    RBX::TaskScheduler::remove(job: &v116); /*0x141027dd2*/
    this->networkOwnerJob._Ptr = nullptr; /*0x141027dd7*/
    v7 = this->networkOwnerJob._Rep; /*0x141027dde*/
    this->networkOwnerJob._Rep = nullptr; /*0x141027de5*/
    if ( v7 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Uses, 0xFFFFFFFF) == 1 ) /*0x141027dfb*/
    {
      v7->_Destroy(this: v7); /*0x141027e03*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141027e0f*/
        v7->_Delete_this(this: v7); /*0x141027e17*/
    }
    if ( DFFlag::DebugEnablePhaseTracking.value ) /*0x141027e21*/
    {
      v117 = 0; /*0x141027e26*/
      v8 = this->romarkPhaseTrackingJob._Rep; /*0x141027e2c*/
      if ( v8 != nullptr ) /*0x141027e36*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v8->_Uses); /*0x141027e38*/
        v8 = this->romarkPhaseTrackingJob._Rep; /*0x141027e3c*/
      }
      v117._Ptr = this->romarkPhaseTrackingJob._Ptr; /*0x141027e4a*/
      v117._Rep = v8; /*0x141027e4f*/
      RBX::TaskScheduler::remove(job: &v117); /*0x141027e58*/
      std::shared_ptr<SDLGameController_2_0_16>::reset(this: (std::shared_ptr<RBX::Graphics::FramebufferVulkan> *)&this->romarkPhaseTrackingJob); /*0x141027e64*/
    }
    RBX::Network::MegaReplicator::removeMegaJobs(this: &this->megaReplicator); /*0x141027e70*/
    Ptr = this->players._Ptr; /*0x141027e75*/
    if ( Ptr != nullptr ) /*0x141027e7f*/
    {
      RBX::Players::setConnection(this: Ptr, rakPeer: nullptr); /*0x141027e83*/
      RBX::Network::Server::stop(this); /*0x141027e8b*/
      std::shared_ptr<SDLGameController_2_0_16>::reset(this: (std::shared_ptr<RBX::Graphics::FramebufferVulkan> *)&this->players); /*0x141027e97*/
    }
    rbx::signals::connection::disconnect(this: &this->itemAddedConnection.con); /*0x141027ea3*/
    rbx::signals::connection::disconnect(this: &this->workspaceLoadedConnection.con); /*0x141027eaf*/
    RBX::Network::MegaReplicator::stopStreamingObserver(this: &this->megaReplicator); /*0x141027ebb*/
    if ( RBX::Network::StreamingSolver::isSolverEnabled() ) /*0x141027ec0*/
      RBX::Network::MegaReplicator::stopStreamingSolver(this: &this->megaReplicator); /*0x141027ed0*/
  }
  if ( newProvider != nullptr && RBX::Players::clientIsPresent(context: newProvider, testInDatamodel: true) ) /*0x141027edf*/
  {
    RBX::runtime_error(&result, fmt: "Can not create server, client is present."); /*0x141028bee*/
    throw &result; /*0x141028c01*/
  }
  RBX::Network::Peer::onServiceProvider(this, oldProvider, newProvider); /*0x141027ef5*/
  if ( newProvider != nullptr ) /*0x141027efd*/
  {
    __eh34_enter_wind_state(-1, 0); /*0xf1c00000000001d4*/
    parent = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x141027f15*/
    v152.parent = parent; /*0x141027f17*/
    __wind /*0xf1c00000000001b0*/
    {
      v11 = (rbx::signals::slot_base *)operator new(size: 0x30u); /*0x141027f22*/
      v12 = v11; /*0x141027f27*/
      v110 = v11; /*0x141027f2a*/
      p_closingSignal = &newProvider->closingSignal; /*0x141027f2f*/
      if ( v11 != nullptr ) /*0x141027f35*/
      {
        v11->strong._Storage._Value = 0; /*0x141027f37*/
        v11->weak._Storage._Value = 1; /*0x141027f3a*/
        v11->call = rbx::signals::slot_with_functor__lambda_77a79c646a42c9815f132bc38cbce504___::do_call; /*0x141027f48*/
        v11->dtor = (void (__fastcall *)(rbx::signals::slot_base *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x141027f53*/
        v11->next.px = nullptr; /*0x141027f57*/
        v11->owner = &newProvider->closingSignal; /*0x141027f5b*/
        v11[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)this; /*0x141027f5f*/
        rbx::signals::signal_base::insert(this: p_closingSignal, item: v11); /*0x141027f66*/
        other.weak_slot.p_ = v12; /*0x141027f6b*/
        _InterlockedIncrement(&v12->weak._Storage._Value); /*0x141027f75*/
        parent = v152.parent; /*0x141027f79*/
      }
      else
      {
        rbx::signals::signal_base::insert(this: p_closingSignal, item: nullptr); /*0x141027f83*/
        other.weak_slot.p_ = nullptr; /*0x141027f88*/
      }
    }
    __unwind
    {
      RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v152); /*0xf1c00000000001c0*/
    }
    __wind /*0xf1c00000000001c8*/
    {
      RBX::Memory::setCurrentCategory(category: parent); /*0x141027f99*/
    }
    __unwind
    {
      __std_terminate(a1: v14, a2: v108); /*0x142f39fa8*/
    }
    if ( rbx::signals::connection::operator!=(this: &this->closingConnection.con, &other) ) /*0x141027fab*/
    {
      rbx::signals::connection::disconnect(this: &this->closingConnection.con); /*0x141027fbb*/
      rbx::signals::connection::operator=(this: &this->closingConnection.con, con: &other); /*0x141027fcc*/
    }
    if ( __eh34_unwind(0) ) /*0xf1c0000000000198*/
    {
unwind_state_0:
      rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&other); /*0xf1c0000000000188*/
      __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000018c*/
    }
    __eh34_exit_wind_state(0, -1); /*0xf1c000000000019c*/
    p = other.weak_slot.p_; /*0x141027fd2*/
    if ( other.weak_slot.p_ != nullptr /*0x141027fe6*/
      && _InterlockedExchangeAdd(&other.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
    {
      operator delete(ptr: p); /*0x141027fe8*/
    }
    v16 = RBX::ServiceProvider::create<RBX::Players>(this: newProvider); /*0x141027ff0*/
    v17 = v16; /*0x141027ff5*/
    if ( v16 != nullptr ) /*0x141027ffb*/
    {
      v18 = v16->_Wptr._Rep; /*0x141027ffd*/
      if ( v18 == nullptr || (Uses = v18->_Uses) == 0 ) /*0x14102800f*/
LABEL_215:
        std::_Throw_bad_weak_ptr(); /*0x141028bc8*/
      while ( 1 ) /*0x141028018*/
      {
        v20 = Uses; /*0x141028018*/
        Uses = _InterlockedCompareExchange((volatile signed __int32 *)&v18->_Uses, Uses + 1, Uses); /*0x141028018*/
        if ( v20 == Uses ) /*0x14102801d*/
          break; /*0x14102801d*/
        if ( Uses == 0 ) /*0x141028021*/
          goto LABEL_215; /*0x141028021*/
        __eh34_enter_wind_state(-1, 0); /*0xf1c000000000017c*/
        if ( __eh34_unwind(0) ) /*0xf1c0000000000184*/
          goto unwind_state_0; /*0xf1c0000000000184*/
        __eh34_exit_wind_state(0, -1); /*0xf1c0000000000190*/
      }
      v21 = (RBX::Players *)v17->_Wptr._Ptr; /*0x141028029*/
      v121 = (volatile signed __int32 *)v17->_Wptr._Rep; /*0x141028031*/
      v22 = &v120; /*0x141028035*/
      v23 = 38; /*0x141028039*/
    }
    else
    {
      v119 = nullptr; /*0x141028040*/
      v22 = &v118; /*0x141028044*/
      v23 = 8; /*0x141028048*/
      v21 = nullptr; /*0x14102804d*/
    }
    v24 = *((std::_Ref_count_base **)v22 + 1); /*0x141028050*/
    *(_QWORD *)v22 = 0; /*0x141028056*/
    *((_QWORD *)v22 + 1) = 0; /*0x141028059*/
    v25 = v23 | 0x10; /*0x14102805d*/
    v148 = v25; /*0x141028060*/
    if ( (v25 & 8) != 0 ) /*0x14102806a*/
    {
      v25 &= ~8u; /*0x14102806c*/
      v148 = v25; /*0x14102806f*/
      if ( v119 != nullptr && _InterlockedExchangeAdd(v119 + 2, 0xFFFFFFFF) == 1 ) /*0x141028088*/
      {
        v26 = v119; /*0x14102808a*/
        (**(void (__fastcall ***)(volatile signed __int32 *))v119)(a1: v119); /*0x141028094*/
        if ( _InterlockedExchangeAdd(v26 + 3, 0xFFFFFFFF) == 1 ) /*0x1410280a0*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v119 + 8LL))(a1: v119); /*0x1410280a9*/
      }
    }
    if ( (v25 & 4) != 0 ) /*0x1410280b6*/
    {
      v25 &= ~4u; /*0x1410280b8*/
      v148 = v25; /*0x1410280bb*/
      if ( v121 != nullptr && _InterlockedExchangeAdd(v121 + 2, 0xFFFFFFFF) == 1 ) /*0x1410280d4*/
      {
        v27 = v121; /*0x1410280d6*/
        (**(void (__fastcall ***)(volatile signed __int32 *))v121)(a1: v121); /*0x1410280e0*/
        if ( _InterlockedExchangeAdd(v27 + 3, 0xFFFFFFFF) == 1 ) /*0x1410280ec*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v121 + 8LL))(a1: v121); /*0x1410280f5*/
      }
    }
    if ( (v25 & 2) != 0 ) /*0x141028102*/
    {
      v25 &= ~2u; /*0x141028104*/
      v148 = v25; /*0x141028107*/
    }
    this->players._Ptr = v21; /*0x14102810d*/
    v28 = this->players._Rep; /*0x141028114*/
    this->players._Rep = v24; /*0x14102811b*/
    if ( v28 != nullptr ) /*0x141028125*/
    {
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v28->_Uses, 0xFFFFFFFF) == 1 ) /*0x141028131*/
      {
        v28->_Destroy(this: v28); /*0x141028139*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v28->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141028145*/
          v28->_Delete_this(this: v28); /*0x14102814d*/
      }
      v25 = v148; /*0x141028150*/
    }
    RBX::Players::setConnection(this: this->players._Ptr, rakPeer: this->rakPeer._Ptr); /*0x141028164*/
    p_serviceRemovingSignal = &newProvider[-1].serviceRemovingSignal; /*0x141028169*/
    RBX::ServiceProvider::create<RBX::Network::ClusterPacketCache>(this: newProvider); /*0x141028170*/
    v30 = (RBX::Network::NetworkOwnerJob *)operator new(size: 0x1D0u); /*0x14102817a*/
    v31 = v30; /*0x14102817f*/
    v110 = v30; /*0x141028182*/
    __wind /*0xf1c0000000000170*/
    {
      if ( v30 != nullptr ) /*0x14102818a*/
      {
        if ( newProvider == (RBX::ServiceProvider *)24 ) /*0x141028193*/
        {
          v123 = nullptr; /*0x1410281f6*/
          v36 = &v122; /*0x1410281fa*/
          v37 = v25 | 0x100; /*0x1410281fe*/
          v38 = nullptr; /*0x141028202*/
        }
        else
        {
          v32 = p_serviceRemovingSignal[1].slots._Rep; /*0x141028195*/
          if ( v32 == nullptr || (v33 = v32->_Uses) == 0 ) /*0x1410281a8*/
LABEL_216:
            std::_Throw_bad_weak_ptr(); /*0x141028bce*/
          while ( 1 ) /*0x1410281b3*/
          {
            v34 = v33; /*0x1410281b3*/
            v33 = _InterlockedCompareExchange((volatile signed __int32 *)&v32->_Uses, v33 + 1, v33); /*0x1410281b3*/
            if ( v34 == v33 ) /*0x1410281b8*/
              break; /*0x1410281b8*/
            if ( v33 == 0 ) /*0x1410281bc*/
              goto LABEL_216; /*0x1410281bc*/
          }
          v35 = p_serviceRemovingSignal[1].slots._Ptr; /*0x1410281c4*/
          v125 = (volatile signed __int32 *)p_serviceRemovingSignal[1].slots._Rep; /*0x1410281ce*/
          v36 = &v124; /*0x1410281d2*/
          v37 = v148 | 0x4C0; /*0x1410281dc*/
          v38 = v35 - 1; /*0x1410281e2*/
          if ( v35 == nullptr ) /*0x1410281ee*/
            v38 = nullptr; /*0x1410281ee*/
        }
        *(_QWORD *)&v136.width = v38; /*0x141028204*/
        *(_QWORD *)&v136.color = *((_QWORD *)v36 + 1); /*0x14102820c*/
        *(_QWORD *)v36 = 0; /*0x141028210*/
        *((_QWORD *)v36 + 1) = 0; /*0x141028213*/
        v25 = v37 | 0x200; /*0x141028217*/
        v148 = v25; /*0x14102821b*/
        if ( (v25 & 0x100) != 0 ) /*0x141028225*/
        {
          v25 &= ~0x100u; /*0x141028227*/
          v148 = v25; /*0x14102822b*/
          if ( v123 != nullptr && _InterlockedExchangeAdd(v123 + 2, 0xFFFFFFFF) == 1 ) /*0x141028244*/
          {
            v39 = v123; /*0x141028246*/
            (**(void (__fastcall ***)(volatile signed __int32 *))v123)(a1: v123); /*0x141028250*/
            if ( _InterlockedExchangeAdd(v39 + 3, 0xFFFFFFFF) == 1 ) /*0x14102825c*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v123 + 8LL))(a1: v123); /*0x141028265*/
          }
        }
        if ( (v25 & 0x80u) != 0 ) /*0x141028271*/
        {
          v25 &= ~0x80u; /*0x141028273*/
          v148 = v25; /*0x141028277*/
          if ( v125 != nullptr && _InterlockedExchangeAdd(v125 + 2, 0xFFFFFFFF) == 1 ) /*0x141028290*/
          {
            v40 = v125; /*0x141028292*/
            (**(void (__fastcall ***)(volatile signed __int32 *))v125)(a1: v125); /*0x14102829c*/
            if ( _InterlockedExchangeAdd(v40 + 3, 0xFFFFFFFF) == 1 ) /*0x1410282a8*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v125 + 8LL))(a1: v125); /*0x1410282b1*/
          }
        }
        if ( (v25 & 0x40) != 0 ) /*0x1410282be*/
        {
          v25 &= ~0x40u; /*0x1410282c0*/
          v148 = v25; /*0x1410282c3*/
        }
        v41 = (RBX::Graphics::TextureVulkan::DownloadBuffer *)RBX::Network::NetworkOwnerJob::NetworkOwnerJob( /*0x1410282d5*/
                                                                this: v31,
                                                                dataModel: (std::shared_ptr<RBX::File> *)&v136.width);
      }
      else
      {
        v41 = nullptr; /*0x1410282da*/
      }
    }
    __unwind
    {
      operator delete(ptr: v110); /*0x1431e6572*/
    }
    v144._Ptr = v41; /*0x1410282dd*/
    __wind /*0xf1c0000000000158*/
    {
      v42 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x1410282e9*/
      v43 = v42; /*0x1410282ee*/
      v109 = v42; /*0x1410282f1*/
      if ( v42 != nullptr ) /*0x1410282fb*/
      {
        *v42 = 0; /*0x141028300*/
        v42->_Uses = 1; /*0x141028303*/
        v42->_Weaks = 1; /*0x14102830a*/
        v42->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::NetworkOwnerJob>::`vftable'; /*0x141028318*/
        v42[1].__vftable = (std::_Ref_count_base_vtbl *)v41; /*0x14102831b*/
      }
      else
      {
        v43 = nullptr; /*0x141028321*/
      }
      if ( v41 != nullptr ) /*0x141028327*/
      {
        resourceListIndex = v41->resourceListIndex; /*0x14102832d*/
        if ( resourceListIndex == 0 || *(_DWORD *)(resourceListIndex + 8) == 0 ) /*0x14102833a*/
        {
          if ( v43 != nullptr ) /*0x14102833f*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&v43->_Uses); /*0x141028341*/
            v45 = (RBX::Graphics::Device *)v41; /*0x141028345*/
            _InterlockedIncrement((volatile signed __int32 *)&v43->_Weaks); /*0x141028348*/
            v46 = v43; /*0x14102834c*/
            v25 = v148; /*0x14102834f*/
          }
          else
          {
            v45 = nullptr; /*0x141028357*/
            v46 = nullptr; /*0x14102835a*/
          }
          v41->device = v45; /*0x14102835d*/
          v47 = (volatile signed __int32 *)v41->resourceListIndex; /*0x141028361*/
          v41->resourceListIndex = (unsigned __int64)v46; /*0x141028365*/
          if ( v47 != nullptr ) /*0x14102836c*/
          {
            if ( _InterlockedExchangeAdd(v47 + 3, 0xFFFFFFFF) == 1 ) /*0x141028378*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v47 + 8LL))(a1: v47); /*0x14102837d*/
            v25 = v148; /*0x141028380*/
          }
          if ( v43 != nullptr ) /*0x141028389*/
          {
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v43->_Uses, 0xFFFFFFFF) == 1 ) /*0x141028395*/
            {
              v43->_Destroy(this: v43); /*0x14102839d*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v43->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410283a9*/
                v43->_Delete_this(this: v43); /*0x1410283b1*/
            }
            v25 = v148; /*0x1410283b4*/
          }
        }
      }
      this->networkOwnerJob._Ptr = (RBX::TaskScheduler::Job *)v41; /*0x1410283ba*/
      v48 = this->networkOwnerJob._Rep; /*0x1410283c1*/
      this->networkOwnerJob._Rep = v43; /*0x1410283c8*/
      if ( v48 != nullptr ) /*0x1410283d2*/
      {
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v48->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410283df*/
        {
          v48->_Destroy(this: v48); /*0x1410283e7*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v48->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410283f4*/
            v48->_Delete_this(this: v48); /*0x1410283fc*/
        }
        v25 = v148; /*0x1410283ff*/
      }
      v126 = 0; /*0x141028408*/
      v49 = this->networkOwnerJob._Rep; /*0x14102840d*/
      if ( v49 != nullptr ) /*0x141028417*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v49->_Uses); /*0x141028419*/
        v49 = this->networkOwnerJob._Rep; /*0x14102841d*/
        v25 = v148; /*0x141028424*/
      }
    }
    __unwind
    {
      RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: &v144); /*0xf1c0000000000150*/
    }
    v126._Ptr = this->networkOwnerJob._Ptr; /*0x141028431*/
    v126._Rep = v49; /*0x141028435*/
    RBX::TaskScheduler::add(job: &v126); /*0x14102843d*/
    if ( DFFlag::DebugEnablePhaseTracking.value ) /*0x141028449*/
    {
      v50 = (RBX::Network::RomarkPhaseTrackingJob *)operator new(size: 0x1C0u); /*0x141028454*/
      v51 = v50; /*0x141028459*/
      v109 = v50; /*0x14102845c*/
      __wind /*0xf1c0000000000140*/
      {
        if ( v50 != nullptr ) /*0x141028464*/
        {
          if ( newProvider == (RBX::ServiceProvider *)24 ) /*0x14102846d*/
          {
            v128 = nullptr; /*0x1410284d6*/
            v56 = &v127; /*0x1410284da*/
            v57 = v25 | 0x2000; /*0x1410284de*/
            v58 = nullptr; /*0x1410284e2*/
          }
          else
          {
            v52 = p_serviceRemovingSignal[1].slots._Rep; /*0x14102846f*/
            if ( v52 == nullptr || (v53 = v52->_Uses) == 0 ) /*0x141028482*/
LABEL_217:
              std::_Throw_bad_weak_ptr(); /*0x141028bd4*/
            while ( 1 ) /*0x141028493*/
            {
              v54 = v53; /*0x141028493*/
              v53 = _InterlockedCompareExchange((volatile signed __int32 *)&v52->_Uses, v53 + 1, v53); /*0x141028493*/
              if ( v54 == v53 ) /*0x141028498*/
                break; /*0x141028498*/
              if ( v53 == 0 ) /*0x14102849c*/
                goto LABEL_217; /*0x14102849c*/
            }
            v55 = p_serviceRemovingSignal[1].slots._Ptr; /*0x1410284a4*/
            v130 = (volatile signed __int32 *)p_serviceRemovingSignal[1].slots._Rep; /*0x1410284ae*/
            v56 = &v129; /*0x1410284b2*/
            v57 = v148 | 0x9800; /*0x1410284bc*/
            v58 = (RBX::File *)&v55[-1]; /*0x1410284c2*/
            if ( v55 == nullptr ) /*0x1410284ce*/
              v58 = nullptr; /*0x1410284ce*/
          }
          v137._Ptr = v58; /*0x1410284e4*/
          v137._Rep = *((std::_Ref_count_base **)v56 + 1); /*0x1410284ec*/
          *(_QWORD *)v56 = 0; /*0x1410284f0*/
          *((_QWORD *)v56 + 1) = 0; /*0x1410284f3*/
          v59 = v57 | 0x4000; /*0x1410284f7*/
          v148 = v59; /*0x1410284fb*/
          if ( (v59 & 0x2000) != 0 ) /*0x141028505*/
          {
            v59 &= ~0x2000u; /*0x141028507*/
            v148 = v59; /*0x14102850b*/
            if ( v128 != nullptr && _InterlockedExchangeAdd(v128 + 2, 0xFFFFFFFF) == 1 ) /*0x141028524*/
            {
              v60 = v128; /*0x141028526*/
              (**(void (__fastcall ***)(volatile signed __int32 *))v128)(a1: v128); /*0x141028530*/
              if ( _InterlockedExchangeAdd(v60 + 3, 0xFFFFFFFF) == 1 ) /*0x14102853c*/
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v128 + 8LL))(a1: v128); /*0x141028545*/
            }
          }
          if ( (v59 & 0x1000) != 0 ) /*0x141028552*/
          {
            v59 &= ~0x1000u; /*0x141028554*/
            v148 = v59; /*0x141028558*/
            if ( v130 != nullptr && _InterlockedExchangeAdd(v130 + 2, 0xFFFFFFFF) == 1 ) /*0x141028571*/
            {
              v61 = v130; /*0x141028573*/
              (**(void (__fastcall ***)(volatile signed __int32 *))v130)(a1: v130); /*0x14102857d*/
              if ( _InterlockedExchangeAdd(v61 + 3, 0xFFFFFFFF) == 1 ) /*0x141028589*/
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v130 + 8LL))(a1: v130); /*0x141028592*/
            }
          }
          if ( (v59 & 0x800) != 0 ) /*0x14102859f*/
            v148 = v59 & 0xFFFFF7FF; /*0x1410285a5*/
          v62 = (RBX::Graphics::TextureVulkan::DownloadBuffer *)RBX::Network::RomarkPhaseTrackingJob::RomarkPhaseTrackingJob( /*0x1410285be*/
                                                                  this: v51,
                                                                  dm: &v137,
                                                                  megaReplicator: &this->megaReplicator);
        }
        else
        {
          v62 = nullptr; /*0x1410285c9*/
        }
      }
      __unwind
      {
        operator delete(ptr: v109); /*0x1431e6592*/
      }
      v145._Ptr = v62; /*0x1410285cc*/
      __wind /*0xf1c0000000000128*/
      {
        v63 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x1410285d8*/
        v64 = v63; /*0x1410285dd*/
        v109 = v63; /*0x1410285e0*/
        if ( v63 != nullptr ) /*0x1410285e8*/
        {
          *v63 = 0; /*0x1410285ed*/
          v63->_Uses = 1; /*0x1410285f0*/
          v63->_Weaks = 1; /*0x1410285f7*/
          v63->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::RomarkPhaseTrackingJob>::`vftable'; /*0x141028605*/
          v63[1].__vftable = (std::_Ref_count_base_vtbl *)v62; /*0x141028608*/
        }
        else
        {
          v64 = nullptr; /*0x14102860e*/
        }
        if ( v62 != nullptr ) /*0x141028614*/
        {
          v65 = v62->resourceListIndex; /*0x141028616*/
          if ( v65 == 0 || *(_DWORD *)(v65 + 8) == 0 ) /*0x141028623*/
          {
            if ( v64 != nullptr ) /*0x141028628*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v64->_Uses); /*0x14102862a*/
              v66 = (RBX::Graphics::Device *)v62; /*0x14102862e*/
              _InterlockedIncrement((volatile signed __int32 *)&v64->_Weaks); /*0x141028631*/
              v67 = v64; /*0x141028635*/
            }
            else
            {
              v66 = nullptr; /*0x14102863a*/
              v67 = nullptr; /*0x14102863d*/
            }
            v62->device = v66; /*0x141028640*/
            v68 = (volatile signed __int32 *)v62->resourceListIndex; /*0x141028644*/
            v62->resourceListIndex = (unsigned __int64)v67; /*0x141028648*/
            if ( v68 != nullptr && _InterlockedExchangeAdd(v68 + 3, 0xFFFFFFFF) == 1 ) /*0x14102865b*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v68 + 8LL))(a1: v68); /*0x141028660*/
            if ( v64 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v64->_Uses, 0xFFFFFFFF) == 1 ) /*0x141028672*/
            {
              v64->_Destroy(this: v64); /*0x14102867a*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v64->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141028686*/
                v64->_Delete_this(this: v64); /*0x14102868e*/
            }
          }
        }
        this->romarkPhaseTrackingJob._Ptr = (RBX::TaskScheduler::Job *)v62; /*0x141028692*/
        v69 = this->romarkPhaseTrackingJob._Rep; /*0x141028699*/
        this->romarkPhaseTrackingJob._Rep = v64; /*0x1410286a0*/
        if ( v69 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v69->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410286b6*/
        {
          v69->_Destroy(this: v69); /*0x1410286be*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v69->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410286ca*/
            v69->_Delete_this(this: v69); /*0x1410286d2*/
        }
        v131 = 0; /*0x1410286d8*/
        v70 = this->romarkPhaseTrackingJob._Rep; /*0x1410286dd*/
        if ( v70 != nullptr ) /*0x1410286e7*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v70->_Uses); /*0x1410286e9*/
          v70 = this->romarkPhaseTrackingJob._Rep; /*0x1410286ed*/
        }
      }
      __unwind
      {
        RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: &v145); /*0xf1c0000000000120*/
      }
      v131._Ptr = this->romarkPhaseTrackingJob._Ptr; /*0x1410286fb*/
      v131._Rep = v70; /*0x1410286ff*/
      RBX::TaskScheduler::add(job: &v131); /*0x141028707*/
      Myval2 = RBX::DataModel::get(context: newProvider)->placeID.storage._Mypair._Myval2; /*0x141028714*/
      LODWORD(v113) = Myval2->storage.asRaw[0] - (_DWORD)Myval2; /*0x14102871f*/
      HIDWORD(v113) = Myval2->storage.asRaw[1] - (_DWORD)Myval2; /*0x141028728*/
      *(_QWORD *)&v136.x = v113; /*0x141028731*/
      p_placeAuthenticationResultCacheMutex = &this->placeAuthenticationResultCacheMutex; /*0x141028735*/
      v140.m = &this->placeAuthenticationResultCacheMutex; /*0x14102873c*/
      v140.is_locked = false; /*0x141028743*/
      if ( this == (RBX::Network::Server *)-2952LL ) /*0x14102874d*/
      {
        v107 = boost::lock_error::lock_error(this: &v147, ev: 1, what_arg: "boost unique_lock has no mutex"); /*0x141028bb9*/
        __wind /*0xf1c000000000005c*/
        {
          boost::throw_exception<boost::lock_error>(e: v107); /*0x141028bc2*/
        }
        __unwind
        {
          boost::thread_resource_error::~thread_resource_error(this: &v147); /*0xf1c000000000006c*/
        }
      }
      boost::detail::basic_timed_mutex::lock(this: &this->placeAuthenticationResultCacheMutex); /*0x141028756*/
      v140.is_locked = true; /*0x14102875b*/
      __wind /*0xf1c00000000000f8*/
      {
        boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<__int64 const,int>>,__int64,int,boost::hash<__int64>,std::equal_to<__int64>>>::operator[]( /*0x141028772*/
          this: (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<__int64 const ,enum RBX::MembershipType> >,__int64,enum RBX::MembershipType,boost::hash<__int64>,std::equal_to<__int64> > > *)&this->placeAuthenticationResultCache,
          k: (const __int64 *)&v136.x)->second = MEMBERSHIP_TURBO_BUILDERS_CLUB;
      }
      __unwind
      {
        boost::unique_lock<boost::mutex>::~unique_lock<boost::mutex>(this: &v140); /*0xf1c0000000000108*/
      }
      __wind /*0xf1c0000000000110*/
      {
        v73 = _InterlockedExchangeAdd(&p_placeAuthenticationResultCacheMutex->active_count, 0x80000000); /*0x14102877e*/
        if ( (v73 & 0x40000000) == 0 /*0x141028794*/
          && v73 != 0x80000000
          && !_interlockedbittestandset(&p_placeAuthenticationResultCacheMutex->active_count, 0x1Eu) )
        {
          event = boost::detail::basic_timed_mutex::get_event(this: &this->placeAuthenticationResultCacheMutex); /*0x141028799*/
          SetEvent(hEvent: event); /*0x1410287a1*/
        }
      }
      __unwind
      {
        __std_terminate(a1: v75, a2: v108); /*0xf1c000000000004c*/
      }
      v25 = v148; /*0x1410287a8*/
    }
    if ( newProvider == (RBX::ServiceProvider *)24 ) /*0x1410287b1*/
    {
      v133 = nullptr; /*0x141028818*/
      v80 = &v132; /*0x14102881c*/
      v81 = v25 | 0x40000; /*0x141028820*/
      v82 = nullptr; /*0x141028824*/
    }
    else
    {
      v76 = p_serviceRemovingSignal[1].slots._Rep; /*0x1410287b3*/
      if ( v76 == nullptr || (v77 = v76->_Uses) == 0 ) /*0x1410287c6*/
LABEL_218:
        std::_Throw_bad_weak_ptr(); /*0x141028bda*/
      while ( 1 ) /*0x1410287d3*/
      {
        v78 = v77; /*0x1410287d3*/
        v77 = _InterlockedCompareExchange((volatile signed __int32 *)&v76->_Uses, v77 + 1, v77); /*0x1410287d3*/
        if ( v78 == v77 ) /*0x1410287d8*/
          break; /*0x1410287d8*/
        if ( v77 == 0 ) /*0x1410287dc*/
          goto LABEL_218; /*0x1410287dc*/
      }
      v79 = p_serviceRemovingSignal[1].slots._Ptr; /*0x1410287e4*/
      v135 = (volatile signed __int32 *)p_serviceRemovingSignal[1].slots._Rep; /*0x1410287ee*/
      v80 = &v134; /*0x1410287f2*/
      v81 = v148 | 0x130000; /*0x1410287fc*/
      v82 = (RBX::DataModel *)&v79[-1]; /*0x141028802*/
      if ( v79 == nullptr ) /*0x14102880f*/
        v82 = nullptr; /*0x14102880f*/
    }
    dm._Ptr = v82; /*0x141028827*/
    dm._Rep = *((std::_Ref_count_base **)v80 + 1); /*0x14102882f*/
    *(_QWORD *)v80 = 0; /*0x141028833*/
    *((_QWORD *)v80 + 1) = 0; /*0x141028836*/
    v83 = v81 | 0x80000; /*0x14102883a*/
    v149 = v83; /*0x14102883e*/
    if ( (v83 & 0x40000) != 0 ) /*0x141028848*/
    {
      v83 &= ~0x40000u; /*0x14102884a*/
      v149 = v83; /*0x14102884e*/
      if ( v133 != nullptr ) /*0x14102885b*/
      {
        v84 = _InterlockedExchangeAdd(v133 + 2, 0xFFFFFFFF); /*0x14102885f*/
        if ( v84 == 1 ) /*0x141028867*/
        {
          v85 = v133; /*0x141028869*/
          (**(void (__fastcall ***)(volatile signed __int32 *))v133)(a1: v133); /*0x141028873*/
          v86 = _InterlockedExchangeAdd(v85 + 3, 0xFFFFFFFF); /*0x141028877*/
          if ( v86 == 1 ) /*0x14102887f*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v133 + 8LL))(a1: v133); /*0x141028888*/
        }
      }
    }
    if ( (v83 & 0x20000) != 0 ) /*0x141028895*/
    {
      v83 &= ~0x20000u; /*0x141028897*/
      v149 = v83; /*0x14102889b*/
      if ( v135 != nullptr ) /*0x1410288a8*/
      {
        v87 = _InterlockedExchangeAdd(v135 + 2, 0xFFFFFFFF); /*0x1410288ac*/
        if ( v87 == 1 ) /*0x1410288b4*/
        {
          v88 = v135; /*0x1410288b6*/
          (**(void (__fastcall ***)(volatile signed __int32 *))v135)(a1: v135); /*0x1410288c0*/
          v89 = _InterlockedExchangeAdd(v88 + 3, 0xFFFFFFFF); /*0x1410288c4*/
          if ( v89 == 1 ) /*0x1410288cc*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v135 + 8LL))(a1: v135); /*0x1410288d5*/
        }
      }
    }
    if ( (v83 & 0x10000) != 0 ) /*0x1410288e2*/
    {
      v83 &= ~0x10000u; /*0x1410288e4*/
      v149 = v83; /*0x1410288e8*/
    }
    __wind /*0xf1c00000000000c8*/
    {
      RBX::Network::MegaReplicator::startMegaJobs(this: &this->megaReplicator, &dm); /*0x1410288f9*/
      v90 = dm._Rep; /*0x1410288ff*/
      if ( dm._Rep != nullptr ) /*0x141028906*/
      {
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&dm._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141028912*/
        {
          v90->_Destroy(this: v90); /*0x14102891a*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v90->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141028926*/
            v90->_Delete_this(this: v90); /*0x14102892e*/
        }
        v83 = v149; /*0x141028931*/
      }
      v91 = p_serviceRemovingSignal[94].slots._Rep; /*0x141028937*/
      LODWORD(v114) = LODWORD(v91->__vftable) - (_DWORD)v91; /*0x141028943*/
      HIDWORD(v114) = HIDWORD(v91->__vftable) - (_DWORD)v91; /*0x14102894c*/
      v136.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141028950*/
      v136.text._Mypair._Myval2._Mysize = 0; /*0x141028954*/
      v136.text._Mypair._Myval2._Myres = 15; /*0x141028958*/
      v92 = v83 | 0x200000; /*0x141028964*/
      v142 = &v141; /*0x141028975*/
      v143 = &v142; /*0x141028983*/
      v93 = v114; /*0x14102898a*/
      v94 = v114; /*0x14102898f*/
      if ( v114 < 0 ) /*0x141028995*/
        v94 = -v114; /*0x141028997*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&dm); /*0xf1c00000000000d8*/
    }
    __wind /*0xf1c00000000000e0*/
    {
      v139.m_value = v94; /*0x14102899a*/
      v139.m_finish = (char *)&v142; /*0x1410289a8*/
      v139.m_czero = 48; /*0x1410289af*/
      v139.m_zero = 48; /*0x1410289b6*/
      v95 = boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned __int64,char>::convert(this: &v139); /*0x1410289c7*/
      if ( v93 < 0 ) /*0x1410289cf*/
        *--v95 = 45; /*0x1410289d4*/
      v142 = v95; /*0x1410289d7*/
      v143 = &v142; /*0x1410289e5*/
      std::string::assign(this: &v136.text, _Ptr: v95, _Count: (char *)&v142 - v95); /*0x1410289fd*/
      v96 = &v136; /*0x141028a02*/
      if ( v136.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141028a0b*/
        v96 = (RBX::Graphics::ProfilerAdorn::Item *)v136.text._Mypair._Myval2._Bx._Ptr; /*0x141028a0b*/
      RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x141028a26*/
        category: "Game",
        action: "PlaceID",
        label: v96->text._Mypair._Myval2._Bx._Buf,
        value: 0,
        sync: false);
      v97 = v92 & 0xFFDFFFFF; /*0x141028a2b*/
      v150 = v97; /*0x141028a2f*/
    }
    __unwind
    {
      if ( (v150 & 0x200000) != 0 ) /*0x1431e6616*/
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v136); /*0x1431e6629*/
    }
    if ( v136.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141028a3d*/
    {
      v98 = v136.text._Mypair._Myval2._Bx._Ptr; /*0x141028a42*/
      if ( v136.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141028a50*/
      {
        v98 = *((char **)v136.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141028a56*/
        if ( (unsigned __int64)(v136.text._Mypair._Myval2._Bx._Ptr - v98 - 8) > 0x1F ) /*0x141028a65*/
          _invalid_parameter_noinfo_noreturn(); /*0x141028a67*/
      }
      operator delete(ptr: v98); /*0x141028a6e*/
    }
    v99 = p_serviceRemovingSignal[94].slots._Rep; /*0x141028a73*/
    LODWORD(v115) = LODWORD(v99->__vftable) - (_DWORD)v99; /*0x141028a7f*/
    HIDWORD(v115) = HIDWORD(v99->__vftable) - (_DWORD)v99; /*0x141028a88*/
    if ( v115 != 0 ) /*0x141028a92*/
    {
      v100 = p_serviceRemovingSignal + 27; /*0x141028aa1*/
      __wind /*0xf1c00000000000b0*/
      {
        v103 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x141028ab3*/
        v153.parent = v103; /*0x141028ab5*/
        __wind /*0xf1c000000000008c*/
        {
          v101 = (rbx::signals::slot_base *)operator new(size: 0x30u); /*0x141028ac0*/
          v102 = v101; /*0x141028ac5*/
          v109 = v101; /*0x141028ac8*/
          if ( v101 != nullptr ) /*0x141028ad3*/
          {
            v101->strong._Storage._Value = 0; /*0x141028ad5*/
            v101->weak._Storage._Value = 1; /*0x141028ad8*/
            v101->call = rbx::signals::slot_with_functor__lambda_45996ccaec3f4d421db10f9e0bf49a96___::do_call; /*0x141028ae6*/
            v101->dtor = (void (__fastcall *)(rbx::signals::slot_base *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x141028af1*/
            v101->next.px = nullptr; /*0x141028af5*/
            v101->owner = v100; /*0x141028af9*/
            v101[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)this; /*0x141028afd*/
            rbx::signals::signal_base::insert(this: v100, item: v101); /*0x141028b04*/
            con.weak_slot.p_ = v102; /*0x141028b09*/
            _InterlockedIncrement(&v102->weak._Storage._Value); /*0x141028b13*/
            v97 = v150; /*0x141028b18*/
            v103 = v153.parent; /*0x141028b1e*/
          }
          else
          {
            rbx::signals::signal_base::insert(this: v100, item: nullptr); /*0x141028b28*/
            con.weak_slot.p_ = nullptr; /*0x141028b2d*/
          }
          v151 = v97 | 0x400000; /*0x141028b36*/
        }
        __unwind
        {
          RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v153); /*0xf1c000000000009c*/
        }
        __wind /*0xf1c00000000000a4*/
        {
          RBX::Memory::setCurrentCategory(category: v103); /*0x141028b3e*/
        }
        __unwind
        {
          __std_terminate(a1: v104, a2: v108); /*0xf1c0000000000054*/
        }
        p_workspaceLoadedConnection = &this->workspaceLoadedConnection; /*0x141028b44*/
        if ( rbx::signals::connection::operator!=(this: &p_workspaceLoadedConnection->con, other: &con) ) /*0x141028b53*/
        {
          rbx::signals::connection::disconnect(this: &p_workspaceLoadedConnection->con); /*0x141028b5f*/
          rbx::signals::connection::operator=(this: &p_workspaceLoadedConnection->con, &con); /*0x141028b6c*/
        }
      }
      __unwind
      {
        if ( (v151 & 0x400000) != 0 ) /*0x1431e6666*/
          rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&con); /*0x1431e6676*/
      }
      v106 = con.weak_slot.p_; /*0x141028b72*/
      if ( con.weak_slot.p_ != nullptr /*0x141028b84*/
        && _InterlockedExchangeAdd(&con.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
      {
        operator delete(ptr: v106); /*0x141028b86*/
      }
    }
    else
    {
      RBX::Network::Server::onWorkspaceLoaded(this); /*0x141028a97*/
    }
  }
}

// Address: 0x141028c10 | Name: ?onWorkspaceLoaded@Server@Network@RBX@@AEAAXXZ
void __fastcall RBX::Network::Server::onWorkspaceLoaded(RBX::Network::Server *this)
{
  unsigned int v2; // eax
  RBX::ServiceProvider *parent; // rsi
  RBX::Instance *v4; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v6; // rax
  unsigned __int64 v7; // rax
  RBX::Described<RBX::Workspace,RBX::WorldRoot> *v8; // rcx
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v9; // r14
  const RBX::Name *v10; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *Rep; // rbx
  RBX::Graphics::FrameRateManagerStatsStringItem *Ptr; // rbx
  __int64 Terrain; // rax
  RBX::MegaClusterInstance *v15; // rsi
  __int64 v16; // rbx
  RBX::Reflection::ClassDescriptor *v17; // rax
  RBX::ObscureValue<__int64,0> *Myval2; // rdx
  RBX::ServiceProvider *RootAncestor; // rsi
  RBX::Instance *v20; // rcx
  const RBX::Reflection::ClassDescriptor *v21; // rbx
  RBX::Reflection::ClassDescriptor *v22; // rax
  RBX::StarterPlayerService *v23; // rax
  const RBX::Network::Server::onWorkspaceLoaded::__l13::<lambda_ac6bd2bee9b1e5db0c8f272e99de10db> *v24; // rax
  RBX::Instance *v25; // rbx
  rbx::signal<void __cdecl(std::shared_ptr<RBX::Instance>)> *p_descendantAddedSignal; // r14
  rbx::signals::slot_base *v27; // rax
  rbx::signals::slot_base *v28; // rsi
  unsigned int v29; // ebx
  __int64 v30; // rcx
  rbx::signals::scoped_connection *p_itemAddedConnection; // rdi
  rbx::signals::slot_base *p; // rcx
  __int64 v33; // rcx
  _BYTE v34[32]; // [rsp+0h] [rbp-B8h] BYREF
  __int64 v35; // [rsp+30h] [rbp-88h]
  RBX::Network::Server *v36; // [rsp+38h] [rbp-80h]
  rbx::signals::slot_base *v37; // [rsp+40h] [rbp-78h]
  std::shared_ptr<RBX::Instance> result; // [rsp+48h] [rbp-70h] BYREF
  char placeId[96]; // [rsp+58h] [rbp-60h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v40; // [rsp+C0h] [rbp+8h] BYREF
  int v41; // [rsp+C8h] [rbp+10h]
  RBX::Memory::Scope memscopeNetworkReplicator; // [rsp+D0h] [rbp+18h] BYREF
  rbx::signals::connection other; // [rsp+D8h] [rbp+20h] BYREF

  v41 = 0; /*0x141028c26*/
  v2 = RBX::Memory::setCurrentCategory(category: RBX::Memory::NetworkReplicator); /*0x141028c34*/
  __wind /*0xf1c0000000000080*/
  {
    memscopeNetworkReplicator.parent = v2; /*0x141028c39*/
    if ( this == nullptr ) /*0x141028c47*/
      goto LABEL_15; /*0x141028c47*/
    parent = (RBX::ServiceProvider *)this->parent; /*0x141028c4d*/
    if ( parent != nullptr ) /*0x141028c54*/
    {
      v4 = parent->parent; /*0x141028c56*/
      if ( v4 != nullptr ) /*0x141028c5d*/
        parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v4); /*0x141028c64*/
    }
    else
    {
      parent = (RBX::ServiceProvider *)this; /*0x141028c69*/
    }
    if ( parent != nullptr /*0x141028c97*/
      && (descriptor = parent->descriptor,
          v6 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(),
          descriptor->index - (unsigned int)v6->index <= v6->descendantCount) )
    {
      boost::call_once( /*0x141028cab*/
        flag: &`RBX::ServiceProvider::getClassIndex<RBX::Workspace>'::`2'::flag,
        f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Workspace>);
      v7 = RBX::ServiceProvider::doGetClassIndex<RBX::Workspace>(); /*0x141028cb0*/
      v9 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt( /*0x141028cc0*/
                                                                                this: parent,
                                                                                index: v7);
      if ( v9->_Ptr == nullptr ) /*0x141028cc7*/
      {
        v10 = RBX::Reflection::Class_getNamePtr<RBX::Workspace>(this: v8); /*0x141028cc9*/
        ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName( /*0x141028cd9*/
                                                                                                  this: parent,
                                                                                                  &result,
                                                                                                  className: v10);
        std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v9, _Right: ServiceByClassName); /*0x141028ce4*/
        Rep = result._Rep; /*0x141028ce9*/
        if ( result._Rep != nullptr /*0x141028cfd*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&result._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          Rep->_Destroy(this: Rep); /*0x141028d05*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141028d11*/
            Rep->_Delete_this(this: Rep); /*0x141028d19*/
        }
      }
      Ptr = v9->_Ptr; /*0x141028d1c*/
    }
    else
    {
LABEL_15:
      Ptr = nullptr; /*0x141028d21*/
    }
    if ( BYTE1(Ptr[6].completeness.numLocalReplicatedChildren) != 0 ) /*0x141028d2b*/
      RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x141028d4a*/
        category: "Game",
        action: "NetworkStreamingEnabled",
        label: "none",
        value: 0,
        sync: false);
    Terrain = RBX::WorldRoot::getTerrain(this: (RBX::HumanoidDescription *)Ptr); /*0x141028d52*/
    v15 = (RBX::MegaClusterInstance *)Terrain; /*0x141028d57*/
    if ( Terrain != 0 ) /*0x141028d5d*/
    {
      v16 = *(_QWORD *)(Terrain + 24); /*0x141028d63*/
      v17 = RBX::Reflection::Class_getDescriptorPtr<RBX::MegaClusterInstance>(); /*0x141028d67*/
      if ( *(unsigned __int16 *)(v16 + 888) - (unsigned int)v17->index <= v17->descendantCount /*0x141028d8a*/
        && RBX::MegaClusterInstance::isAllocated(this: v15) )
      {
        Myval2 = RBX::DataModel::get(context: this)->placeID.storage._Mypair._Myval2; /*0x141028d9b*/
        LODWORD(v35) = Myval2->storage.asRaw[0] - (_DWORD)Myval2; /*0x141028da6*/
        HIDWORD(v35) = Myval2->storage.asRaw[1] - (_DWORD)Myval2; /*0x141028daf*/
        sprintf(_Buffer: placeId, _Format: "%lld", v35); /*0x141028dc4*/
        RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x141028de4*/
          category: "Game",
          action: "SmoothTerrain",
          label: placeId,
          value: 0,
          sync: false);
      }
    }
    if ( this != nullptr ) /*0x141028dec*/
    {
      RootAncestor = (RBX::ServiceProvider *)this->parent; /*0x141028dee*/
      if ( RootAncestor != nullptr ) /*0x141028df5*/
      {
        v20 = RootAncestor->parent; /*0x141028df7*/
        if ( v20 != nullptr ) /*0x141028dfe*/
          RootAncestor = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v20); /*0x141028e05*/
      }
      else
      {
        RootAncestor = (RBX::ServiceProvider *)this; /*0x141028e0a*/
      }
      if ( RootAncestor != nullptr ) /*0x141028e10*/
      {
        v21 = RootAncestor->descriptor; /*0x141028e12*/
        v22 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(); /*0x141028e16*/
        if ( v21->index - (unsigned int)v22->index <= v22->descendantCount ) /*0x141028e34*/
        {
          v23 = RBX::ServiceProvider::create<RBX::StarterPlayerService>(this: RootAncestor); /*0x141028e39*/
          if ( v23 != nullptr ) /*0x141028e41*/
            RBX::StarterPlayerService::recordSettingsInGA(this: v23); /*0x141028e46*/
        }
      }
    }
    v24 = (const RBX::Network::Server::onWorkspaceLoaded::__l13::<lambda_ac6bd2bee9b1e5db0c8f272e99de10db> *)RBX::DataModel::get(context: this); /*0x141028e4e*/
    if ( v24 != nullptr ) /*0x141028e56*/
    {
      v25 = (RBX::Instance *)&v24[3]; /*0x141028e5c*/
      v36 = this; /*0x141028e60*/
      RBX::Instance::visitDescendants__lambda_ac6bd2bee9b1e5db0c8f272e99de10db___(func: v24 + 3); /*0x141028e6d*/
      p_descendantAddedSignal = &RBX::Instance::onDemandWrite(this: v25)->descendantAddedSignal; /*0x141028e7a*/
      __wind /*0xf1c0000000000074*/
      {
        v29 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x141028e89*/
        v40.parent = v29; /*0x141028e8b*/
        __wind /*0xf1c0000000000050*/
        {
          v27 = (rbx::signals::slot_base *)operator new(size: 0x30u); /*0x141028e97*/
          v28 = v27; /*0x141028e9c*/
          v37 = v27; /*0x141028e9f*/
          if ( v27 != nullptr ) /*0x141028eaa*/
          {
            v27->strong._Storage._Value = 0; /*0x141028eac*/
            v27->weak._Storage._Value = 1; /*0x141028eaf*/
            v27->call = (void (__fastcall *)(rbx::signals::slot_base *))rbx::signals::slot_with_functor__lambda_bdd8d87a05247948a3880d85c7761359__std::shared_ptr_RBX::Instance___::do_call; /*0x141028ebd*/
            v27->dtor = (void (__fastcall *)(rbx::signals::slot_base *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x141028ec8*/
            v27->next.px = nullptr; /*0x141028ecc*/
            v27->owner = p_descendantAddedSignal; /*0x141028ed0*/
            v27[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)this; /*0x141028ed4*/
            rbx::signals::signal_base::insert(this: p_descendantAddedSignal, item: v27); /*0x141028edb*/
            other.weak_slot.p_ = v28; /*0x141028ee0*/
            _InterlockedIncrement(&v28->weak._Storage._Value); /*0x141028eed*/
            v29 = v40.parent; /*0x141028ef1*/
          }
          else
          {
            rbx::signals::signal_base::insert(this: p_descendantAddedSignal, item: nullptr); /*0x141028efc*/
            other.weak_slot.p_ = nullptr; /*0x141028f01*/
          }
          v41 = 1; /*0x141028f09*/
        }
        __unwind
        {
          RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v40); /*0xf1c0000000000060*/
        }
        __wind /*0xf1c0000000000068*/
        {
          RBX::Memory::setCurrentCategory(category: v29); /*0x141028f16*/
        }
        __unwind
        {
          __std_terminate(a1: v30, a2: v34); /*0x142f39fa8*/
        }
        p_itemAddedConnection = &this->itemAddedConnection; /*0x141028f1c*/
        if ( rbx::signals::connection::operator!=(this: &p_itemAddedConnection->con, &other) ) /*0x141028f2e*/
        {
          rbx::signals::connection::disconnect(this: &p_itemAddedConnection->con); /*0x141028f3a*/
          rbx::signals::connection::operator=(this: &p_itemAddedConnection->con, con: &other); /*0x141028f4a*/
        }
      }
      __unwind
      {
        if ( (v41 & 1) != 0 ) /*0x1431e66a4*/
        {
          v41 &= ~1u; /*0x1431e66a6*/
          rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&other); /*0x1431e66b4*/
        }
      }
      p = other.weak_slot.p_; /*0x141028f50*/
      if ( other.weak_slot.p_ != nullptr /*0x141028f65*/
        && _InterlockedExchangeAdd(&other.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
      {
        operator delete(ptr: p); /*0x141028f67*/
      }
    }
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&memscopeNetworkReplicator); /*0xf1c0000000000090*/
  }
  __wind /*0xf1c0000000000098*/
  {
    RBX::Memory::setCurrentCategory(category: memscopeNetworkReplicator.parent); /*0x141028f74*/
  }
  __unwind
  {
    __std_terminate(a1: v33, a2: v34); /*0xf1c0000000000024*/
  }
}

// Address: 0x1410294f0 | Name: ?registerLegalSharedScript@Server@Network@RBX@@AEAAHAEBVSharedString@3@@Z
__int64 __fastcall RBX::Network::Server::registerLegalSharedScript(
        RBX::Network::Server *this,
        RBX::SharedString *source)
{
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // rcx
  unsigned __int64 v6; // r14
  unsigned __int64 v7; // rbp
  boost::unordered::detail::ptr_bucket *next; // rbx
  boost::unordered::detail::ptr_bucket *v9; // rcx
  signed __int64 v11; // rbp
  RBX::Network::Server::LegalScript *Mylast; // rdx
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *h; // rax
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *v14; // rax
  RBX::Network::Server::LegalScript *v15; // rbx
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *v16; // rcx
  const std::string *Contents; // rax
  std::string *v18; // rax
  char *Ptr; // rcx
  std::string *v20; // rax
  RBX::Network::Server::LegalScript v21; // [rsp+20h] [rbp-58h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v22; // [rsp+40h] [rbp-38h] BYREF
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > v23; // [rsp+80h] [rbp+8h] BYREF

  v4 = RBX::hash_value(sharedString: source); /*0x14102950b*/
  v5 = 265 * ((~v4 + (v4 << 21)) ^ ((~v4 + (v4 << 21)) >> 24)); /*0x141029527*/
  v6 = 2147483649u * (((21 * (v5 ^ (v5 >> 14))) >> 28) ^ (21 * (v5 ^ (v5 >> 14)))); /*0x14102954b*/
  v7 = v6 & (this->scriptsBySharedSource.table_.bucket_count_ - 1); /*0x141029559*/
  if ( this->scriptsBySharedSource.table_.size_ != 0 ) /*0x141029564*/
  {
    next = this->scriptsBySharedSource.table_.buckets_[v7].next_; /*0x14102956d*/
    if ( next != nullptr ) /*0x141029574*/
    {
      while ( 1 ) /*0x141029576*/
      {
        next = next->next_; /*0x141029576*/
        if ( next == nullptr ) /*0x14102957c*/
          break; /*0x14102957c*/
        v9 = next[1].next_; /*0x14102957e*/
        if ( (boost::unordered::detail::ptr_bucket *)v6 == v9 ) /*0x141029585*/
        {
          if ( StudioResourceId::operator==(lhs: source, rhs: &next[2].next_) ) /*0x14102958e*/
            return LODWORD(next[4].next_); /*0x14102959f*/
        }
        else if ( ((unsigned __int64)v9 & (this->scriptsBySharedSource.table_.bucket_count_ - 1)) != v7 ) /*0x1410295b4*/
        {
          break; /*0x1410295b4*/
        }
      }
    }
  }
  v11 = this->legalScripts._Mypair._Myval2._Mylast - this->legalScripts._Mypair._Myval2._Myfirst; /*0x1410295b6*/
  memset(&v21, 0, sizeof(v21)); /*0x1410295cb*/
  RBX::SharedString::SharedString(this: &v21.sharedSource); /*0x1410295da*/
  __wind /*0xf1c0000000000040*/
  {
    RBX::SharedString::SharedString(this: &v21.sharedBytecode); /*0x1410295e5*/
  }
  __unwind
  {
    RBX::SharedString::~SharedString(this: &v21.sharedSource); /*0xf1c0000000000050*/
  }
  __wind /*0xf1c0000000000058*/
  {
    Mylast = this->legalScripts._Mypair._Myval2._Mylast; /*0x1410295eb*/
    if ( Mylast == this->legalScripts._Mypair._Myval2._Myend ) /*0x1410295f9*/
    {
      std::vector<RBX::Network::Server::LegalScript>::_Emplace_reallocate<RBX::Network::Server::LegalScript>( /*0x141029638*/
        this: &this->legalScripts,
        _Whereptr: Mylast,
        <_Val_0>: &v21);
    }
    else
    {
      h = v21.sharedSource.flyweight.h.h; /*0x1410295fb*/
      Mylast->sharedSource.flyweight.h.h = v21.sharedSource.flyweight.h.h; /*0x141029600*/
      _InterlockedIncrement(&h->ref.value_); /*0x141029603*/
      Mylast->sharedSource.readCount = v21.sharedSource.readCount; /*0x14102960b*/
      v14 = v21.sharedBytecode.flyweight.h.h; /*0x14102960e*/
      Mylast->sharedBytecode.flyweight.h.h = v21.sharedBytecode.flyweight.h.h; /*0x141029613*/
      _InterlockedIncrement(&v14->ref.value_); /*0x141029617*/
      Mylast->sharedBytecode.readCount = v21.sharedBytecode.readCount; /*0x14102961f*/
      ++this->legalScripts._Mypair._Myval2._Mylast; /*0x141029622*/
    }
  }
  __unwind
  {
    rbx::implementation::typed_holder<RBX::ProtectedString>::destruct_func(dest: (char *)&v21); /*0xf1c0000000000038*/
  }
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &v21.sharedBytecode.flyweight.h); /*0x141029643*/
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &v21.sharedSource.flyweight.h); /*0x14102964d*/
  v15 = this->legalScripts._Mypair._Myval2._Mylast; /*0x141029652*/
  v23.h = source->flyweight.h.h; /*0x14102965c*/
  _InterlockedIncrement(&v23.h->ref.value_); /*0x141029664*/
  v16 = v15[-1].sharedSource.flyweight.h.h; /*0x141029668*/
  v15[-1].sharedSource.flyweight.h = v23; /*0x141029674*/
  v23.h = v16; /*0x141029678*/
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &v23); /*0x141029688*/
  v15[-1].sharedSource.readCount = source->readCount; /*0x141029690*/
  if ( this->serverReplicationMode == ReplicationMode_StudioAsClient )
  {
    if ( DFLog::TeamTest != 0 )
    {
      Contents = RBX::SharedString::getContents(this: source); /*0x1410296ac*/
      if ( Contents->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410296b6*/
        Contents = (const std::string *)Contents->_Mypair._Myval2._Bx._Ptr; /*0x1410296b8*/
      FLog::FastLogS(
        level: DFLog::TeamTest,
        message: "[DFLog::TeamTest] Compiling script: %s",
        sarg: Contents->_Mypair._Myval2._Bx._Buf);
    }
    RBX::SharedString::getContents(this: source); /*0x1410296d4*/
    v18 = LuaVM::compile(result: &v22.text); /*0x1410296eb*/
    __eh34_enter_wind_state(-1, 2); /*0xf1c000000000002c*/
    RBX::SharedString::setContents(this: &v15[-1].sharedBytecode, contents: v18); /*0x1410296f8*/
    if ( __eh34_unwind(2) ) /*0xf1c0000000000020*/
      goto unwind_state_2; /*0xf1c0000000000020*/
    __eh34_exit_wind_state(2, -1); /*0xf1c0000000000024*/
    if ( v22.text._Mypair._Myval2._Myres < 0x10 ) /*0x141029707*/
      goto LABEL_28; /*0x141029707*/
    Ptr = v22.text._Mypair._Myval2._Bx._Ptr; /*0x141029710*/
    if ( v22.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14102971f*/
    {
      Ptr = *((char **)v22.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141029729*/
      if ( (unsigned __int64)(v22.text._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141029738*/
        _invalid_parameter_noinfo_noreturn(); /*0x14102973a*/
    }
  }
  else
  {
    RBX::SharedString::getContents(this: source); /*0x141029744*/
    v20 = LuaVM::compile(result: &v22.text); /*0x14102975a*/
    __eh34_enter_wind_state(-1, 2); /*0xf1c0000000000018*/
    RBX::SharedString::setContents(this: &v15[-1].sharedBytecode, contents: v20); /*0x141029767*/
    if ( __eh34_unwind(2) ) /*0xf1c0000000000004*/
    {
unwind_state_2:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v22); /*0xf1c0000000000008*/
      __eh34_propagate_exception_into_caller(2, -1); /*0xf1c000000000000c*/
    }
    __eh34_exit_wind_state(2, -1); /*0xf1c0000000000010*/
    if ( v22.text._Mypair._Myval2._Myres < 0x10 ) /*0x141029776*/
      goto LABEL_28; /*0x141029776*/
    Ptr = v22.text._Mypair._Myval2._Bx._Ptr; /*0x14102977b*/
    if ( v22.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14102978a*/
    {
      Ptr = *((char **)v22.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141029790*/
      if ( (unsigned __int64)(v22.text._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14102979f*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410297a1*/
    }
  }
  operator delete(ptr: Ptr); /*0x1410297a8*/
LABEL_28:
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::SharedString const,int>>,RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::operator[]( /*0x1410297ad*/
    this: &this->scriptsBySharedSource.table_,
    k: source)->second = v11;
  return (unsigned int)v11; /*0x1410297c1*/
}

// Address: 0x1410297e0 | Name: ?registerServerReplicatorForPlayerId@Server@Network@RBX@@QEAAX_J$$QEAV?$weak_ptr@VServerReplicator@Network@RBX@@@std@@@Z
void __fastcall RBX::Network::Server::registerServerReplicatorForPlayerId(
        RBX::Network::Server *this,
        __int64 playerId,
        std::weak_ptr<RBX::Network::ServerReplicator> *serverReplicator)
{
  std::pair<__int64 const ,std::weak_ptr<RBX::Network::ServerReplicator> > *v4; // rax
  std::_Ref_count_base *Rep; // rcx
  RBX::Network::ServerReplicator *Ptr; // rdx
  std::_Ref_count_base *v7; // r9
  volatile signed __int32 *v8; // rcx
  __int64 k; // [rsp+38h] [rbp+10h] BYREF

  k = playerId; /*0x1410297e0*/
  v4 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<__int64 const,std::weak_ptr<RBX::Network::ServerReplicator>>>,__int64,std::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<__int64>,std::equal_to<__int64>>>::operator[]( /*0x1410297f9*/
         this: &this->serverReplicatorByPlayer.table_,
         &k);
  Rep = serverReplicator->_Rep; /*0x1410297fe*/
  Ptr = nullptr; /*0x141029802*/
  v7 = nullptr; /*0x141029804*/
  if ( Rep != nullptr ) /*0x14102980a*/
  {
    Ptr = serverReplicator->_Ptr; /*0x14102980c*/
    _InterlockedIncrement((volatile signed __int32 *)&Rep->_Weaks); /*0x14102980f*/
    v7 = Rep; /*0x141029813*/
  }
  v8 = (volatile signed __int32 *)v4->second._Rep; /*0x141029816*/
  v4->second._Ptr = Ptr; /*0x14102981a*/
  v4->second._Rep = v7; /*0x14102981e*/
  if ( v8 != nullptr && _InterlockedExchangeAdd(v8 + 3, 0xFFFFFFFF) == 1 ) /*0x141029834*/
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 8LL))(a1: v8); /*0x14102983e*/
}

// Address: 0x14102e100 | Name: ?sendLuaKickMessageBeforeDisco@Server@Network@RBX@@QEAAXPEAVPlayer@3@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RBX::Network::Server::sendLuaKickMessageBeforeDisco(
        RBX::Network::Server *this,
        RBX::Player *player,
        const std::string *msg)
{
  unsigned __int64 UserID; // rax
  std::_Ref_count_base *Rep; // rbx
  std::shared_ptr<RBX::Network::ServerReplicator> result; // [rsp+20h] [rbp-18h] BYREF

  if ( player != nullptr ) /*0x14102e103*/
  {
    UserID = RBX::Player::getUserID(this: player); /*0x14102e11c*/
    RBX::Network::Server::getServerReplicatorForPlayerId(this, &result, playerId: UserID); /*0x14102e12c*/
    __wind /*0xf1c0000000000010*/
    {
      if ( result._Ptr != nullptr ) /*0x14102e13a*/
        RBX::Network::ServerReplicator::sendLuaKickMessageBeforeDisco(this: result._Ptr, message: msg); /*0x14102e13f*/
      if ( result._Rep != nullptr /*0x14102e15e*/
        && _InterlockedExchangeAdd((volatile signed __int32 *)&result._Rep->_Uses, 0xFFFFFFFF) == 1 )
      {
        Rep = result._Rep; /*0x14102e160*/
        result._Rep->_Destroy(this: result._Rep); /*0x14102e16b*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14102e175*/
          result._Rep->_Delete_this(this: result._Rep); /*0x14102e17f*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&result); /*0xf1c0000000000008*/
    }
  }
}

// Address: 0x14102e190 | Name: ?serverIsPresent@Server@Network@RBX@@SA_NPEBVInstance@3@_N@Z
bool __fastcall RBX::Network::Server::serverIsPresent(RBX::ServiceProvider *context, bool testInDatamodel)
{
  RBX::ServiceProvider *parent; // rdi
  RBX::Instance *v3; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v5; // rax

  if ( context == nullptr ) /*0x14102e199*/
    return false; /*0x14102e199*/
  parent = (RBX::ServiceProvider *)context->parent; /*0x14102e19b*/
  if ( parent != nullptr ) /*0x14102e1a2*/
  {
    v3 = parent->parent; /*0x14102e1a4*/
    if ( v3 != nullptr ) /*0x14102e1ab*/
      parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v3); /*0x14102e1b2*/
  }
  else
  {
    parent = context; /*0x14102e1b7*/
  }
  if ( parent != nullptr /*0x14102e1eb*/
    && (descriptor = parent->descriptor,
        v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(),
        descriptor->index - (unsigned int)v5->index <= v5->descendantCount) )
  {
    return RBX::ServiceProvider::refByClass<RBX::Network::Server>(this: parent)->_Ptr != nullptr; /*0x14102e1fb*/
  }
  else
  {
    return false; /*0x14102e209*/
  }
}

// Address: 0x14102e220 | Name: ?setJobId@Server@Network@RBX@@QEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RBX::Network::Server::setJobId(RBX::Network::Server *this, const std::string *jobId)
{
  Luau::InternalErrorReporter *v3; // rax

  v3 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14102e230*/
  ((void (__fastcall *)(Luau::InternalErrorReporter *, const std::string *))v3->onInternalError._Mystorage._Ptrs[0][102].__vftable)( /*0x14102e243*/
    a1: v3,
    a2: jobId);
}

// Address: 0x14102e250 | Name: ?setPreauthKey@Server@Network@RBX@@QEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RBX::Network::Server::setPreauthKey(RBX::Network::Server *this, const std::string *newKey)
{
  Luau::InternalErrorReporter *v3; // rax

  v3 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14102e260*/
  ((void (__fastcall *)(Luau::InternalErrorReporter *, const std::string *))v3->onInternalError._Mystorage._Ptrs[0][103].__vftable)( /*0x14102e273*/
    a1: v3,
    a2: newKey);
}

// Address: 0x14102e280 | Name: ?setRemoteEventMonitor@Server@Network@RBX@@QEAAXV?$shared_ptr@VRemoteEventMonitor@Network@RBX@@@std@@@Z
void __fastcall RBX::Network::Server::setRemoteEventMonitor(
        RBX::Network::Server *this,
        std::shared_ptr<RBX::Network::RemoteEventMonitor> *remoteEventMonitor)
{
  std::_Ref_count_base *Rep; // r8
  std::_Ref_count_base *v4; // rbx
  std::_Ref_count_base *v5; // rbx

  Rep = remoteEventMonitor->_Rep; /*0x14102e28f*/
  if ( Rep != nullptr ) /*0x14102e299*/
  {
    _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x14102e29b*/
    Rep = remoteEventMonitor->_Rep; /*0x14102e2a0*/
  }
  v4 = this->remoteEventMonitor._Rep; /*0x14102e2a4*/
  this->remoteEventMonitor._Ptr = remoteEventMonitor->_Ptr; /*0x14102e2b3*/
  this->remoteEventMonitor._Rep = Rep; /*0x14102e2ba*/
  if ( v4 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Uses, 0xFFFFFFFF) == 1 ) /*0x14102e2d0*/
  {
    v4->_Destroy(this: v4); /*0x14102e2d8*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14102e2e4*/
      v4->_Delete_this(this: v4); /*0x14102e2ec*/
  }
  v5 = remoteEventMonitor->_Rep; /*0x14102e2ef*/
  if ( v5 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Uses, 0xFFFFFFFF) == 1 ) /*0x14102e302*/
  {
    v5->_Destroy(this: v5); /*0x14102e30a*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14102e314*/
      v5->_Delete_this(this: v5); /*0x14102e31c*/
  }
}

// Address: 0x14102e330 | Name: ?start@Server@Network@RBX@@QEAAXHHH_N0AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@AEBUSystemAddress@RakNet@@@Z
// local variable allocation has failed, the output may be wrong!
void __fastcall RBX::Network::Server::start(
        RBX::Network::Server *this,
        int port,
        __int16 lowPortRange,
        __int16 highPortRange,
        bool localhost,
        bool ruppAware,
        std::string *serverRuppStemma,
        const RakNet::SystemAddress *ipv6)
{
  unsigned int v12; // eax
  Luau::InternalErrorReporter *v13; // rsi
  std::string *arg2; // rbx
  const std::string *Ptr; // r8
  std::_Func_base<void,char const *> *v16; // rax
  std::string *v17; // rdx
  __int64 v18; // rdx
  const char *v19; // r8
  const char *v20; // r9
  int *v21; // rbx
  Luau::InternalErrorReporter *v22; // rax
  std::_Func_base<void,char const *>_vtbl *v23; // r10
  int v24; // eax
  __int64 v25; // rbx
  Luau::InternalErrorReporter *v26; // rax
  RakNet::SystemAddress *v27; // rax
  Luau::InternalErrorReporter *v28; // rax
  Luau::InternalErrorReporter *v29; // rax
  RakNet::SystemAddress *v30; // rax
  std::string *v31; // rax
  char *v32; // rcx
  RBX::DataModel *v33; // r14
  double sec; // xmm6_8
  RBX::Time *v35; // rax
  Luau::InternalErrorReporter *v36; // rax
  std::_Func_base<void,char const *>_vtbl *v37; // r9
  Luau::InternalErrorReporter *v38; // rax
  std::_Func_base<void,char const *>_vtbl *v39; // r9
  RBX::TimerService *v40; // r12
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v43; // ett
  RBX::Reflection::DescribedBase *v44; // rax
  std::_Ref_count_base *v45; // rbx
  PluginPermissionsFetcher *v46; // rax
  std::_Ref_count_base *v47; // rdx
  RBX::Instance *v48; // rax
  __int64 v49; // rcx
  RBX::Graphics::ProfilerAdorn::Item *v50; // rax
  __int64 v51; // [rsp+8h] [rbp-100h] BYREF
  int v52; // [rsp+30h] [rbp-D8h]
  int v53; // [rsp+38h] [rbp-D0h]
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> category; // [rsp+48h] [rbp-C0h] BYREF
  std::weak_ptr<PluginPermissionsFetcher> category_8; // [rsp+50h] [rbp-B8h] BYREF
  std::runtime_error pExceptionObject; // [rsp+60h] [rbp-A8h] BYREF
  RBX::Time v57; // [rsp+78h] [rbp-90h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v58; // [rsp+88h] [rbp-80h] BYREF
  int *p_x; // [rsp+E0h] [rbp-28h]
  std::string result; // [rsp+E8h] [rbp-20h] BYREF
  __int128 v61; // [rsp+108h] [rbp+0h] BYREF
  __m256i v62; // [rsp+118h] [rbp+10h] OVERLAPPED BYREF
  __int64 v63; // [rsp+138h] [rbp+30h]
  _BYTE v64[32]; // [rsp+140h] [rbp+38h] BYREF
  _BYTE v65[32]; // [rsp+160h] [rbp+58h] BYREF
  RakNet::SocketDescriptor d; // [rsp+180h] [rbp+78h] BYREF

  v12 = RBX::Memory::setCurrentCategory(category: RBX::Memory::NetworkReplicator); /*0x14102e36c*/
  __wind /*0xf1c000000000008c*/
  {
    category.parent = v12; /*0x14102e371*/
    if ( RBX::Players::clientIsPresent(context: this, testInDatamodel: true) ) /*0x14102e37a*/
    {
      RBX::runtime_error(result: &pExceptionObject, fmt: "Can not call server, client is present."); /*0x14102e8e0*/
      throw &pExceptionObject; /*0x14102e8f1*/
    }
    if ( FLog::Network != 0 ) /*0x14102e390*/
      FLog::FastLog(level: FLog::Network, message: "[FLog::Network] NetworkServer:Start", arg0: nullptr); /*0x14102e39c*/
    if ( !DFFlag::RuppHeaderFromClientEnabled3.value ) /*0x14102e3b0*/
      goto LABEL_32; /*0x14102e3b0*/
    v13 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14102e3c2*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, bool))v13->onInternalError._Mystorage._Ptrs[0][92].__vftable)( /*0x14102e3d6*/
      a1: v13,
      a2: ruppAware);
    arg2 = serverRuppStemma; /*0x14102e3d9*/
    if ( FFlag::RuppTokEn4.value ) /*0x14102e3e9*/
    {
      if ( ruppAware && serverRuppStemma->_Mypair._Myval2._Mysize != 0 ) /*0x14102e3f9*/
      {
        if ( DFLog::RuppTokenLog != 0 ) /*0x14102e404*/
        {
          Ptr = serverRuppStemma; /*0x14102e406*/
          if ( serverRuppStemma->_Mypair._Myval2._Myres >= 0x10 ) /*0x14102e40e*/
            Ptr = (const std::string *)serverRuppStemma->_Mypair._Myval2._Bx._Ptr; /*0x14102e410*/
          FLog::FastLog( /*0x14102e41a*/
            level: DFLog::RuppTokenLog,
            message: "[DFLog::RuppTokenLog] Server::start RuppTokenStemma = %s",
            arg0: Ptr);
        }
        v16 = v13->onInternalError._Mystorage._Ptrs[0]; /*0x14102e41f*/
        if ( serverRuppStemma->_Mypair._Myval2._Myres >= 0x10 ) /*0x14102e427*/
          arg2 = (std::string *)serverRuppStemma->_Mypair._Myval2._Bx._Ptr; /*0x14102e429*/
        v17 = arg2; /*0x14102e42c*/
LABEL_21:
        ((void (__fastcall *)(Luau::InternalErrorReporter *, std::string *))v16[97].__vftable)(a1: v13, a2: v17); /*0x14102e45e*/
        ((void (__fastcall *)(Luau::InternalErrorReporter *, const RakNet::SystemAddress *))v13->onInternalError._Mystorage._Ptrs[0][98].__vftable)( /*0x14102e474*/
          a1: v13,
          a2: ipv6);
        LOBYTE(v18) = 1; /*0x14102e47d*/
        ((void (__fastcall *)(Luau::InternalErrorReporter *, __int64))v13->onInternalError._Mystorage._Ptrs[0][94].__vftable)( /*0x14102e482*/
          a1: v13,
          a2: v18);
LABEL_32:
        *(_OWORD *)&v62.m256i_u64[2] = 0; /*0x14102e4de*/
        v63 = 0; /*0x14102e4e6*/
        __eh34_enter_wind_state(0, 1); /*0xf1c0000000000084*/
        RakNet::SocketDescriptor::SocketDescriptor( /*0x14102e4fc*/
          this: (RakNet::SocketDescriptor *)&d.hostAddress[6],
          _port: port,
          _hostAddress: nullptr);
        v21 = &DFInt::RccMaxPayloadRcv; /*0x14102e508*/
        if ( this->serverReplicationMode == ReplicationMode_StudioAsEditor ) /*0x14102e516*/
          v21 = &DFInt::RccTcMaxPayloadRcv; /*0x14102e516*/
        v22 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14102e521*/
        v23 = v22->onInternalError._Mystorage._Ptrs[0][1].__vftable; /*0x14102e529*/
        LOWORD(v53) = highPortRange; /*0x14102e535*/
        LOWORD(v52) = lowPortRange; /*0x14102e53b*/
        v24 = ((__int64 (__fastcall *)(Luau::InternalErrorReporter *, _QWORD, int *, char *, int, int, int, int))v23)( /*0x14102e55d*/
                a1: v22,
                a2: (unsigned __int16)FInt::MaxClients,
                a3: v21,
                a4: &d.hostAddress[6],
                a5: 1,
                a6: v52,
                a7: v53,
                a8: -99999);
        v25 = v24; /*0x14102e560*/
        if ( v24 != 0 ) /*0x14102e565*/
        {
          reportServerStartupFailure(res: v24, port, ruppAware); /*0x14102e88b*/
          v50 = RBX::format( /*0x14102e8a9*/
                  result: &v58,
                  fmt: "Failed to start network server, port:%d, error:%s",
                  port,
                  RakNet::StartupResultStrings[v25]);
          __wind /*0xf1c0000000000014*/
          {
            std::runtime_error::runtime_error(this: &pExceptionObject, _Message: &v50->text); /*0x14102e8b7*/
            throw &pExceptionObject; /*0x14102e8c8*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v58); /*0xf1c0000000000024*/
          }
        }
        v26 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14102e572*/
        v27 = (RakNet::SystemAddress *)((__int64 (__fastcall *)(Luau::InternalErrorReporter *, _BYTE *, _QWORD))v26->onInternalError._Mystorage._Ptrs[0][48].__vftable)( /*0x14102e58b*/
                                         a1: v26,
                                         a2: v64,
                                         a3: 0);
        this->outgoingPort = RakNet::SystemAddress::GetPort(this: v27); /*0x14102e599*/
        if ( FFlag::RuppTokEn4.value ) /*0x14102e5a6*/
        {
          v28 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14102e5af*/
          ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD))v28->onInternalError._Mystorage._Ptrs[0][99].__vftable)( /*0x14102e5c8*/
            a1: v28,
            a2: LOWORD(this->outgoingPort));
        }
        if ( FLog::Output != 0 ) /*0x14102e5d2*/
        {
          v29 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14102e5df*/
          v30 = (RakNet::SystemAddress *)((__int64 (__fastcall *)(Luau::InternalErrorReporter *, _BYTE *, _QWORD))v29->onInternalError._Mystorage._Ptrs[0][48].__vftable)( /*0x14102e5f8*/
                                           a1: v29,
                                           a2: v65,
                                           a3: 0);
          v31 = RBX::Network::RakNetAddressToString(&result, raknetAddress: v30, writePort: true, portDelineator: 124); /*0x14102e608*/
          __wind /*0xf1c0000000000078*/
          {
            if ( v31->_Mypair._Myval2._Myres >= 0x10 ) /*0x14102e613*/
              v31 = (std::string *)v31->_Mypair._Myval2._Bx._Ptr; /*0x14102e615*/
            FLog::FastLogFormatted( /*0x14102e629*/
              level: FLog::Output,
              message: "[FLog::Output] Started network server %s",
              v31->_Mypair._Myval2._Bx._Buf);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000070*/
          }
          if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14102e637*/
          {
            v32 = result._Mypair._Myval2._Bx._Ptr; /*0x14102e63c*/
            if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14102e64a*/
            {
              v32 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14102e650*/
              if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v32 - 8) > 0x1F ) /*0x14102e65f*/
                _invalid_parameter_noinfo_noreturn(); /*0x14102e661*/
            }
            operator delete(ptr: v32); /*0x14102e668*/
          }
        }
        v33 = RBX::DataModel::get(context: this); /*0x14102e675*/
        sec = v33->dataModelInitTime.sec; /*0x14102e678*/
        v35 = RBX::Time::nowFast(result: &v57); /*0x14102e685*/
        RBX::Analytics::Event::DEPRECATED_trackUserTiming( /*0x14102e6b9*/
          category: "Game",
          variable: "ServerStartTime",
          milliseconds: (int)((v35->sec - sec) * 1000.0),
          label: "none",
          sync: false);
        if ( DFFlag::DebugDisableTimeoutDisconnect.value ) /*0x14102e6c5*/
        {
          v36 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14102e6ce*/
          v37 = v36->onInternalError._Mystorage._Ptrs[0][52].__vftable; /*0x14102e6d6*/
          v61 = *(_OWORD *)&RakNet::UNASSIGNED_SYSTEM_ADDRESS_16.address.addr6.sin6_family; /*0x14102e6e4*/
          *(_OWORD *)v62.m256i_i8 = *((_OWORD *)&RakNet::UNASSIGNED_SYSTEM_ADDRESS_16.address.addr4 + 1); /*0x14102e6ef*/
          ((void (__fastcall *)(Luau::InternalErrorReporter *, __int64, __int128 *))v37)(a1: v36, a2: 600000, a3: &v61); /*0x14102e6ff*/
        }
        if ( this->serverReplicationMode == ReplicationMode_StudioAsEditor ) /*0x14102e709*/
        {
          v38 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14102e712*/
          v39 = v38->onInternalError._Mystorage._Ptrs[0][52].__vftable; /*0x14102e71a*/
          v58.text = (std::string)RakNet::UNASSIGNED_SYSTEM_ADDRESS_16; /*0x14102e732*/
          ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD, RBX::Graphics::ProfilerAdorn::Item *))v39)( /*0x14102e748*/
            a1: v38,
            a2: (unsigned int)(1000 * DFInt::TeamCreateTimeOutInSec),
            a3: &v58);
        }
        v40 = RBX::ServiceProvider::create<RBX::TimerService>(this: &v33->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x14102e754*/
        Rep = this->_Wptr._Rep; /*0x14102e757*/
        if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x14102e769*/
LABEL_65:
          std::_Throw_bad_weak_ptr(); /*0x14102e8ce*/
        while ( 1 ) /*0x14102e773*/
        {
          v43 = Uses; /*0x14102e773*/
          Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x14102e773*/
          if ( v43 == Uses ) /*0x14102e778*/
            break; /*0x14102e778*/
          if ( Uses == 0 ) /*0x14102e77c*/
            goto LABEL_65; /*0x14102e77c*/
          if ( __eh34_unwind(1) ) /*0xf1c0000000000050*/
            goto unwind_state_1; /*0xf1c0000000000050*/
          __eh34_exit_wind_state(1, 0); /*0xf1c000000000005c*/
          __eh34_enter_wind_state(0, 1); /*0xf1c0000000000064*/
        }
        __wind /*0xf1c0000000000044*/
        {
          v44 = this->_Wptr._Ptr; /*0x14102e784*/
          v45 = this->_Wptr._Rep; /*0x14102e788*/
          category_8 = 0; /*0x14102e78f*/
          if ( v45 != nullptr ) /*0x14102e798*/
          {
            category_8._Ptr = (PluginPermissionsFetcher *)v44; /*0x14102e79a*/
            category_8._Rep = v45; /*0x14102e79f*/
            _InterlockedIncrement((volatile signed __int32 *)&v45->_Weaks); /*0x14102e7a4*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v45->_Uses, 0xFFFFFFFF) == 1 ) /*0x14102e7b7*/
            {
              v45->_Destroy(this: v45); /*0x14102e7bf*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v45->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14102e7c9*/
                v45->_Delete_this(this: v45); /*0x14102e7d1*/
            }
          }
          v46 = category_8._Ptr; /*0x14102e7d5*/
          v47 = category_8._Rep; /*0x14102e7da*/
          category_8 = 0; /*0x14102e7e2*/
          *(_QWORD *)&v58.x = std::_Func_impl_no_alloc__lambda_3ce4644ed9e3114c72832389cfba4888__void_::_vftable_; /*0x14102e7ef*/
          *(_QWORD *)&v58.width = v46; /*0x14102e7f3*/
          *(_QWORD *)&v58.color = v47; /*0x14102e7f7*/
          p_x = &v58.x; /*0x14102e7ff*/
          RBX::TimerService::delay(this: v40, func: (std::function<void __cdecl(void)> *)&v58.x, seconds: 300.0); /*0x14102e812*/
        }
        __unwind
        {
          std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: &category_8); /*0xf1c000000000003c*/
        }
        v48 = RBX::ServiceProvider::refByClass<RBX::RunService>(this: &v33->RBX::Described<RBX::DataModel,RBX::ServiceProvider>)->_Ptr; /*0x14102e821*/
        if ( v48 != nullptr ) /*0x14102e827*/
          *(_QWORD *)&this->lastReportedPhysicsWallTime = v48[1].name.h.h; /*0x14102e830*/
        this->lastReportedPhysicsUnthrottledWorldStepId = RBX::DataModel::getCurrentUnthrottledWorldStepId(this: v33); /*0x14102e83f*/
        RBX::Network::MegaReplicator::initializeForServerStart(this: &this->megaReplicator); /*0x14102e84c*/
        if ( __eh34_unwind(1) ) /*0xf1c00000000000b0*/
        {
unwind_state_1:
          RBX::ScriptServices::Documentation::ValidateResult::~ValidateResult(this: (std::vector<RBX::MeshId> *)&v62.m256i_u64[2]); /*0xf1c0000000000054*/
          __eh34_continue_unwinding(1, 0); /*0xf1c0000000000058*/
        }
        __eh34_exit_wind_state(1, 0); /*0xf1c00000000000b4*/
        goto LABEL_86; /*0xf1c00000000000b8*/
      }
      if ( FFlag::RuppTokEnTest.value && ruppAware ) /*0x14102e43d*/
      {
        if ( DFLog::RuppTokenLog != 0 ) /*0x14102e448*/
          FLog::FastLog( /*0x14102e454*/
            level: DFLog::RuppTokenLog,
            message: "[DFLog::RuppTokenLog] Server::start RuppTokenStemma = Default",
            arg0: nullptr);
        v16 = v13->onInternalError._Mystorage._Ptrs[0]; /*0x14102e459*/
        v17 = nullptr; /*0x14102e45c*/
        goto LABEL_21; /*0x14102e45c*/
      }
    }
    if ( DFLog::RuppTokenLog != 0 ) /*0x14102e493*/
    {
      if ( serverRuppStemma->_Mypair._Myval2._Mysize != 0 ) /*0x14102e49a*/
      {
        if ( serverRuppStemma->_Mypair._Myval2._Myres >= 0x10 ) /*0x14102e4aa*/
          arg2 = (std::string *)serverRuppStemma->_Mypair._Myval2._Bx._Ptr; /*0x14102e4ac*/
      }
      else
      {
        arg2 = (std::string *)"empty"; /*0x14102e49c*/
      }
      v19 = "f"; /*0x14102e4b6*/
      v20 = "f"; /*0x14102e4bd*/
      if ( FFlag::RuppTokEn4.value ) /*0x14102e4c2*/
        v20 = "t"; /*0x14102e4c2*/
      if ( ruppAware ) /*0x14102e4c9*/
        v19 = "t"; /*0x14102e4c9*/
      FLog::FastLog( /*0x14102e4d9*/
        level: DFLog::RuppTokenLog,
        message: "[DFLog::RuppTokenLog] Server::start RuppAware = %s, TokeEn = %s, Stemma = %s",
        arg0: v19,
        arg1: v20,
        arg2);
    }
    goto LABEL_32; /*0x14102e4d9*/
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &category); /*0xf1c000000000009c*/
  }
LABEL_86:
  __wind /*0xf1c00000000000a4*/
  {
    RBX::Memory::setCurrentCategory(category: category.parent); /*0x14102e856*/
  }
  __unwind
  {
    __std_terminate(a1: v49, a2: &v51); /*0x142f39fa8*/
  }
}

// Address: 0x14102eb30 | Name: ?stop@Server@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::Server::stop(RBX::Network::Server *this)
{
  std::vector<std::shared_ptr<RBX::Instance>> *Ptr; // rax
  std::_Ref_count_base *Rep; // rbx
  std::shared_ptr<RBX::Instance> *Mylast; // rcx
  std::shared_ptr<RBX::Instance> *i; // rax
  RBX::Instance *v6; // rdx
  Luau::InternalErrorReporter *v7; // rax
  Luau::InternalErrorReporter *v8; // rax
  std::runtime_error result; // [rsp+20h] [rbp-28h] BYREF

  if ( RBX::Players::clientIsPresent(context: this, testInDatamodel: true) ) /*0x14102eb3b*/
  {
    RBX::runtime_error(&result, fmt: "Can not call server, client is present."); /*0x14102ec20*/
    throw &result; /*0x14102ec31*/
  }
  Ptr = this->children.object._Ptr; /*0x14102eb48*/
  if ( Ptr != nullptr ) /*0x14102eb4f*/
  {
    Rep = this->children.object._Rep; /*0x14102eb5a*/
    if ( Rep != nullptr ) /*0x14102eb61*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x14102eb63*/
      Ptr = this->children.object._Ptr; /*0x14102eb67*/
      Rep = this->children.object._Rep; /*0x14102eb6b*/
    }
    Mylast = Ptr->_Mypair._Myval2._Mylast; /*0x14102eb6f*/
    for ( i = Ptr->_Mypair._Myval2._Myfirst; i != Mylast; v6->isParentLocked = false ) /*0x14102eb79*/
    {
      v6 = i->_Ptr; /*0x14102eb80*/
      ++i; /*0x14102eb83*/
    }
    if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14102eba9*/
    {
      Rep->_Destroy(this: Rep); /*0x14102ebb1*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14102ebbb*/
        Rep->_Delete_this(this: Rep); /*0x14102ebc3*/
    }
  }
  RBX::Instance::removeAllChildren(this); /*0x14102ebd3*/
  v7 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14102ebdf*/
  if ( ((unsigned __int8 (__fastcall *)(Luau::InternalErrorReporter *))v7->onInternalError._Mystorage._Ptrs[0][14].__vftable)(a1: v7) != 0 ) /*0x14102ebef*/
  {
    v8 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14102ebf8*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD))v8->onInternalError._Mystorage._Ptrs[0][13].__vftable)( /*0x14102ec0a*/
      a1: v8,
      a2: 0);
  }
}

// Address: 0x14102ec40 | Name: ?unregisterServerReplicatorForPlayerId@Server@Network@RBX@@QEAAX_JAEBV?$shared_ptr@VServerReplicator@Network@RBX@@@std@@@Z
void __fastcall RBX::Network::Server::unregisterServerReplicatorForPlayerId(
        RBX::Network::Server *this,
        unsigned __int64 playerId,
        const std::shared_ptr<RBX::Network::ServerReplicator> *serverReplicator)
{
  unsigned __int64 bucket_count; // r11
  unsigned __int64 v5; // rdx
  char v7; // bp
  boost::unordered::detail::ptr_bucket *next; // rcx
  boost::unordered::detail::ptr_bucket *i; // rcx
  boost::unordered::detail::ptr_bucket *v11; // rbx
  volatile signed __int32 *v12; // rdi
  char v13; // si
  unsigned __int64 v14; // rbp
  boost::unordered::detail::ptr_bucket *v15; // r15
  boost::unordered::detail::ptr_bucket *v16; // rsi
  boost::unordered::detail::ptr_bucket *j; // rdi
  volatile signed __int32 *v18; // rcx
  unsigned __int64 v19; // rdx
  boost::unordered::detail::ptr_bucket *buckets; // rax
  boost::unordered::detail::ptr_bucket *v21; // r8
  RBX::Network::ServerReplicator *v22; // r9
  signed __int32 v23; // eax
  signed __int32 v24; // ett
  volatile signed __int32 *v25; // [rsp+50h] [rbp+8h]

  bucket_count = this->serverReplicatorByPlayer.table_.bucket_count_; /*0x14102ec50*/
  v5 = playerId % bucket_count; /*0x14102ec5f*/
  v7 = 0; /*0x14102ec68*/
  LODWORD(v25) = 0; /*0x14102ec6b*/
  if ( this->serverReplicatorByPlayer.table_.size_ != 0 /*0x14102ec91*/
    && (next = this->serverReplicatorByPlayer.table_.buckets_[v5].next_) != nullptr )
  {
    for ( i = next->next_; i != nullptr; i = i->next_ ) /*0x14102ec9d*/
    {
      if ( (boost::unordered::detail::ptr_bucket *)playerId == i[1].next_ ) /*0x14102ecaa*/
      {
        if ( (boost::unordered::detail::ptr_bucket *)playerId == i[2].next_ ) /*0x14102ecb0*/
          break; /*0x14102ecb0*/
      }
      else if ( (unsigned __int64)i[1].next_ % bucket_count != v5 ) /*0x14102ecc0*/
      {
        v11 = nullptr; /*0x14102eccf*/
        goto LABEL_11; /*0x14102eccf*/
      }
    }
  }
  else
  {
    i = nullptr; /*0x14102edf2*/
  }
  v11 = i; /*0x14102edf5*/
  if ( i != nullptr ) /*0x14102edfb*/
  {
    v21 = i[4].next_; /*0x14102ee01*/
    v22 = nullptr; /*0x14102ee05*/
    v12 = nullptr; /*0x14102ee08*/
    if ( v21 != nullptr ) /*0x14102ee0e*/
    {
      v23 = (signed __int32)v21[1].next_; /*0x14102ee10*/
      if ( v23 != 0 ) /*0x14102ee16*/
      {
        while ( 1 ) /*0x14102ee23*/
        {
          v24 = v23; /*0x14102ee23*/
          v23 = _InterlockedCompareExchange((volatile signed __int32 *)&v21[1], v23 + 1, v23); /*0x14102ee23*/
          if ( v24 == v23 ) /*0x14102ee29*/
            break; /*0x14102ee29*/
          if ( v23 == 0 ) /*0x14102ee2d*/
            goto LABEL_39; /*0x14102ee2d*/
        }
        v22 = (RBX::Network::ServerReplicator *)i[3].next_; /*0x14102ee31*/
        v12 = (volatile signed __int32 *)i[4].next_; /*0x14102ee35*/
      }
    }
LABEL_39:
    v7 = 1; /*0x14102ee39*/
    if ( v22 == serverReplicator->_Ptr ) /*0x14102ee41*/
    {
      v13 = 1; /*0x14102ee47*/
      goto LABEL_13; /*0x14102ee4b*/
    }
  }
  else
  {
LABEL_11:
    v12 = v25; /*0x14102ecd2*/
  }
  v13 = 0; /*0x14102ecd7*/
LABEL_13:
  if ( (v7 & 1) != 0 && v12 != nullptr && _InterlockedExchangeAdd(v12 + 2, 0xFFFFFFFF) == 1 ) /*0x14102ecf2*/
  {
    (**(void (__fastcall ***)(volatile signed __int32 *))v12)(a1: v12); /*0x14102ecfa*/
    if ( _InterlockedExchangeAdd(v12 + 3, 0xFFFFFFFF) == 1 ) /*0x14102ed09*/
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 8LL))(a1: v12); /*0x14102ed11*/
  }
  if ( v13 != 0 ) /*0x14102ed17*/
  {
    v14 = (unsigned __int64)v11[1].next_ % this->serverReplicatorByPlayer.table_.bucket_count_; /*0x14102ed36*/
    v15 = v11->next_; /*0x14102ed39*/
    v16 = this->serverReplicatorByPlayer.table_.buckets_[v14].next_; /*0x14102ed3c*/
    for ( j = v16->next_; j != v11; j = j->next_ ) /*0x14102ed46*/
      v16 = j; /*0x14102ed50*/
    while ( 1 ) /*0x14102ed63*/
    {
      v16->next_ = j->next_; /*0x14102ed63*/
      v18 = (volatile signed __int32 *)j[4].next_; /*0x14102ed66*/
      if ( v18 != nullptr && _InterlockedExchangeAdd(v18 + 3, 0xFFFFFFFF) == 1 ) /*0x14102ed7c*/
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 8LL))(a1: v18); /*0x14102ed81*/
      operator delete(ptr: j); /*0x14102ed8c*/
      --this->serverReplicatorByPlayer.table_.size_; /*0x14102ed91*/
      v19 = v14; /*0x14102ed98*/
      if ( v16->next_ == nullptr ) /*0x14102eda1*/
        goto LABEL_27; /*0x14102eda1*/
      v19 = (unsigned __int64)v16->next_[1].next_ % this->serverReplicatorByPlayer.table_.bucket_count_; /*0x14102eda9*/
      if ( v14 != v19 ) /*0x14102edb3*/
        break; /*0x14102edb3*/
LABEL_29:
      j = v16->next_; /*0x14102edd1*/
      v14 = v19; /*0x14102edd4*/
      if ( v16->next_ == v15 ) /*0x14102edda*/
        return; /*0x14102edda*/
    }
    this->serverReplicatorByPlayer.table_.buckets_[v19].next_ = v16; /*0x14102edbc*/
LABEL_27:
    buckets = this->serverReplicatorByPlayer.table_.buckets_; /*0x14102edc0*/
    if ( buckets[v14].next_ == v16 ) /*0x14102edcb*/
      buckets[v14].next_ = nullptr; /*0x14102edcd*/
    goto LABEL_29; /*0x14102edcd*/
  }
}

// Address: 0x1414c0540 | Name: ??$find@VServer@Network@RBX@@@ServiceProvider@RBX@@SAPEAVServer@Network@1@PEBVInstance@1@@Z
RBX::Network::Server *__fastcall RBX::ServiceProvider::find<RBX::Network::Server>(RBX::ServiceProvider *context)
{
  RBX::ServiceProvider *parent; // rdi
  RBX::Instance *v2; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v4; // rax

  if ( context == nullptr ) /*0x1414c0549*/
    return nullptr; /*0x1414c0549*/
  parent = (RBX::ServiceProvider *)context->parent; /*0x1414c054b*/
  if ( parent != nullptr ) /*0x1414c0552*/
  {
    v2 = parent->parent; /*0x1414c0554*/
    if ( v2 != nullptr ) /*0x1414c055b*/
      parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v2); /*0x1414c0562*/
  }
  else
  {
    parent = context; /*0x1414c0567*/
  }
  if ( parent != nullptr /*0x1414c059b*/
    && (descriptor = parent->descriptor,
        v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(),
        descriptor->index - (unsigned int)v4->index <= v4->descendantCount) )
  {
    return RBX::ServiceProvider::find<RBX::Network::Server>(this: parent); /*0x1414c05a5*/
  }
  else
  {
    return nullptr; /*0x1414c05aa*/
  }
}

// Address: 0x1433069c0 | Name: _dynamic_atexit_destructor_for__RBX::Network::Server::createReplicator__
void __fastcall dynamic_atexit_destructor_for__RBX::Network::Server::createReplicator__()
{
  std::function<std::shared_ptr<RBX::Network::ServerReplicator> __cdecl(RBX::Network::Replicator::ReplicatorPeerInfo,RBX::Network::Server *,RBX::NetworkSettings *)> *v0; // rdx

  if ( RBX::Network::Server::createReplicator._Mystorage._Ptrs[7] != nullptr ) /*0x1433069ce*/
  {
    v0 = &RBX::Network::Server::createReplicator; /*0x1433069d3*/
    LOBYTE(v0) = RBX::Network::Server::createReplicator._Mystorage._Ptrs[7] != (std::_Func_base<std::shared_ptr<RBX::Network::ServerReplicator>,RBX::Network::Replicator::ReplicatorPeerInfo,RBX::Network::Server *,RBX::NetworkSettings *> *)&RBX::Network::Server::createReplicator; /*0x1433069dd*/
    RBX::Network::Server::createReplicator._Mystorage._Ptrs[7]->_Delete_this( /*0x1433069e0*/
      this: RBX::Network::Server::createReplicator._Mystorage._Ptrs[7],
      a2: (bool)v0);
    RBX::Network::Server::createReplicator._Mystorage._Ptrs[7] = nullptr; /*0x1433069e3*/
  }
}

// END Server part 1/1, 44 functions
