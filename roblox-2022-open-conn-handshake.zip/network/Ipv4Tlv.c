// Ipv4Tlv -- 2022 Studio + full PDB
// tier 3, 5 functions


// Address: 0x1410ae240 | Name: ??0Ipv4Tlv@Rupp@Network@RBX@@QEAA@Uin_addr@@G@Z
RBX::Network::Rupp::Ipv4Tlv *__fastcall RBX::Network::Rupp::Ipv4Tlv::Ipv4Tlv(
        RBX::Network::Rupp::Ipv4Tlv *this,
        in_addr setIP,
        unsigned __int16 setPort)
{
  this->ipAddress = setIP; /*0x1410ae247*/
  this->__vftable = (RBX::Network::Rupp::Ipv4Tlv_vtbl *)RBX::Network::Rupp::Ipv4Tlv::`vftable'; /*0x1410ae24a*/
  this->port = setPort; /*0x1410ae250*/
  return this; /*0x1410ae255*/
}

// Address: 0x1410ae390 | Name: ?deserialize@Ipv4Tlv@Rupp@Network@RBX@@UEAA?AW4ErrorCode@RuppError@234@AEAVBitStream@RakNet@@H@Z
_BOOL8 __fastcall RBX::Network::Rupp::Ipv4Tlv::deserialize(
        RBX::Network::Rupp::Ipv4Tlv *this,
        RakNet::BitStream *b,
        int lengthOfTlvValue)
{
  return !RakNet::BitStream::Read(this: b, outByteArray: (char *)&this->ipAddress, numberOfBytes: 4u) /*0x1410ae3c8*/
      || RakNet::BitStream::Read<unsigned short>(this: b, outTemplateVar: (unsigned __int8 *)&this->port) == 0;
}

// Address: 0x1410ae5a0 | Name: ?getTlvType@Ipv4Tlv@Rupp@Network@RBX@@UEBA?AW4TlvType@TypeLengthValue@234@XZ
char __fastcall RBX::Network::Rupp::Ipv4Tlv::getTlvType(RBX::Network::Rupp::Ipv4Tlv *this)
{
  return 2; /*0x1410ae5a2*/
}

// Address: 0x1410ae5c0 | Name: ?getValueByteLength@Ipv4Tlv@Rupp@Network@RBX@@UEBAEXZ
unsigned __int8 __fastcall RBX::Network::Rupp::Ipv4Tlv::getValueByteLength(RBX::Network::Rupp::Ipv4Tlv *this)
{
  return 6; /*0x1410ae5c2*/
}

// Address: 0x1410ae5f0 | Name: ?serialize@Ipv4Tlv@Rupp@Network@RBX@@UEBAXAEAVBitStream@RakNet@@@Z
void __fastcall RBX::Network::Rupp::Ipv4Tlv::serialize(RBX::Network::Rupp::Ipv4Tlv *this, RakNet::BitStream *b)
{
  unsigned __int8 *p_port; // rdx
  unsigned __int8 inOutByteArray; // [rsp+30h] [rbp+8h] BYREF

  RakNet::BitStream::Write(this: b, inputByteArray: (const char *)&this->ipAddress, numberOfBytes: 4u); /*0x1410ae60d*/
  if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410ae612*/
  {
    p_port = (unsigned __int8 *)&this->port; /*0x1410ae636*/
  }
  else
  {
    RBX::Network::NetworkStream::ReverseBytes(inByteArray: (unsigned __int8 *)&this->port, &inOutByteArray, length: 2u); /*0x1410ae62a*/
    p_port = &inOutByteArray; /*0x1410ae62f*/
  }
  RakNet::BitStream::WriteBits(this: b, inByteArray: p_port, numberOfBitsToWrite: 0x10u, rightAlignedBits: true); /*0x1410ae646*/
}

// END Ipv4Tlv part 1/1, 5 functions
