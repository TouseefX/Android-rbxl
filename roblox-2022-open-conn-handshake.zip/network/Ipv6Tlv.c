// Ipv6Tlv -- 2022 Studio + full PDB
// tier 3, 5 functions


// Address: 0x1410ae260 | Name: ??0Ipv6Tlv@Rupp@Network@RBX@@QEAA@Uin6_addr@@G@Z
RBX::Network::Rupp::Ipv6Tlv *__fastcall RBX::Network::Rupp::Ipv6Tlv::Ipv6Tlv(
        RBX::Network::Rupp::Ipv6Tlv *this,
        in6_addr *setIP,
        unsigned __int16 setPort)
{
  in6_addr v3; // xmm0

  v3 = *setIP; /*0x1410ae260*/
  this->port = setPort; /*0x1410ae26a*/
  this->__vftable = (RBX::Network::Rupp::Ipv6Tlv_vtbl *)RBX::Network::Rupp::Ipv6Tlv::`vftable'; /*0x1410ae26f*/
  this->ipAddress = v3; /*0x1410ae275*/
  return this; /*0x1410ae279*/
}

// Address: 0x1410ae3f0 | Name: ?deserialize@Ipv6Tlv@Rupp@Network@RBX@@UEAA?AW4ErrorCode@RuppError@234@AEAVBitStream@RakNet@@H@Z
_BOOL8 __fastcall RBX::Network::Rupp::Ipv6Tlv::deserialize(
        RBX::Network::Rupp::Ipv6Tlv *this,
        RakNet::BitStream *b,
        int lengthOfTlvValue)
{
  return !RakNet::BitStream::Read(this: b, outByteArray: (char *)&this->ipAddress, numberOfBytes: 0x10u) /*0x1410ae428*/
      || RakNet::BitStream::Read<unsigned short>(this: b, outTemplateVar: (unsigned __int8 *)&this->port) == 0;
}

// Address: 0x1410ae5b0 | Name: ?getTlvType@Ipv6Tlv@Rupp@Network@RBX@@UEBA?AW4TlvType@TypeLengthValue@234@XZ
unsigned __int8 __fastcall RBX::Network::Rupp::Ipv6Tlv::getTlvType()
{
  return 3; /*0x1410ae5b2*/
}

// Address: 0x1410ae5d0 | Name: ?getValueByteLength@Ipv6Tlv@Rupp@Network@RBX@@UEBAEXZ
unsigned __int8 __fastcall RBX::Network::Rupp::Ipv6Tlv::getValueByteLength(RBX::Network::Rupp::Ipv6Tlv *this)
{
  return 18; /*0x1410ae5d2*/
}

// Address: 0x1410ae660 | Name: ?serialize@Ipv6Tlv@Rupp@Network@RBX@@UEBAXAEAVBitStream@RakNet@@@Z
void __fastcall RBX::Network::Rupp::Ipv6Tlv::serialize(RBX::Network::Rupp::Ipv6Tlv *this, RakNet::BitStream *b)
{
  unsigned __int8 *p_port; // rdx
  unsigned __int8 inOutByteArray; // [rsp+30h] [rbp+8h] BYREF

  RakNet::BitStream::Write(this: b, inputByteArray: (const char *)&this->ipAddress, numberOfBytes: 0x10u); /*0x1410ae67d*/
  if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410ae682*/
  {
    p_port = (unsigned __int8 *)&this->port; /*0x1410ae6a6*/
  }
  else
  {
    RBX::Network::NetworkStream::ReverseBytes(inByteArray: (unsigned __int8 *)&this->port, &inOutByteArray, length: 2u); /*0x1410ae69a*/
    p_port = &inOutByteArray; /*0x1410ae69f*/
  }
  RakNet::BitStream::WriteBits(this: b, inByteArray: p_port, numberOfBitsToWrite: 0x10u, rightAlignedBits: true); /*0x1410ae6b6*/
}

// END Ipv6Tlv part 1/1, 5 functions
