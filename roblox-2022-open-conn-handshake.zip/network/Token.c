// Token -- 2022 Studio + full PDB
// tier 3, 2 functions


// Address: 0x141033cc0 | Name: ??0Token@TokenTlv@Rupp@Network@RBX@@QEAA@XZ
RBX::Network::Rupp::TokenTlv::Token *__fastcall RBX::Network::Rupp::TokenTlv::Token::Token(
        RBX::Network::Rupp::TokenTlv::Token *this)
{
  this->type = 0; /*0x141033cc3*/
  *(_OWORD *)this->value = 0; /*0x141033cc6*/
  return this; /*0x141033ccd*/
}

// Address: 0x1410ae280 | Name: ??0Token@TokenTlv@Rupp@Network@RBX@@QEAA@W4TokenType@1234@VStringView@4@@Z
RBX::Network::Rupp::TokenTlv::Token *__fastcall RBX::Network::Rupp::TokenTlv::Token::Token(
        RBX::Network::Rupp::TokenTlv::Token *this,
        RBX::Network::Rupp::TokenTlv::TokenType setType,
        RBX::StringView *setToken)
{
  this->type = setType; /*0x1410ae280*/
  *(_OWORD *)this->value = 0; /*0x1410ae285*/
  if ( setType != 0 && setToken->Length == 16 ) /*0x1410ae292*/
    *(_OWORD *)this->value = *(_OWORD *)setToken->Data; /*0x1410ae29a*/
  return this; /*0x1410ae2a1*/
}

// END Token part 1/1, 2 functions
