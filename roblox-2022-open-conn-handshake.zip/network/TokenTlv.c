// TokenTlv -- 2022 Studio + full PDB
// tier 3, 7 functions


// Address: 0x1410ae2b0 | Name: ??0TokenTlv@Rupp@Network@RBX@@QEAA@UToken@0123@@Z
RBX::Network::Rupp::TokenTlv *__fastcall RBX::Network::Rupp::TokenTlv::TokenTlv(
        RBX::Network::Rupp::TokenTlv *this,
        RBX::Network::Rupp::TokenTlv::Token *setToken)
{
  __int128 v2; // xmm0
  unsigned __int8 v3; // al

  v2 = *(_OWORD *)&setToken->type; /*0x1410ae2b0*/
  this->__vftable = (RBX::Network::Rupp::TokenTlv_vtbl *)RBX::Network::Rupp::TokenTlv::`vftable'; /*0x1410ae2ba*/
  v3 = setToken->value[15]; /*0x1410ae2bd*/
  *(_OWORD *)&this->token.type = v2; /*0x1410ae2c1*/
  this->token.value[15] = v3; /*0x1410ae2c5*/
  return this; /*0x1410ae2cb*/
}

// Address: 0x1410ae340 | Name: ?compareEqual@TokenTlv@Rupp@Network@RBX@@QEAA_NVStringView@4@@Z
bool __fastcall RBX::Network::Rupp::TokenTlv::compareEqual(RBX::Network::Rupp::TokenTlv *this, __m128i *cmpToken)
{
  __int64 v3; // rax
  __m128i v4; // [rsp+0h] [rbp-18h]

  v4 = *cmpToken; /*0x1410ae34a*/
  if ( _mm_srli_si128(*cmpToken, 8).m128i_u64[0] != 16 ) /*0x1410ae35c*/
    return false; /*0x1410ae35e*/
  v3 = *(_QWORD *)this->token.value - *(_QWORD *)v4.m128i_i64[0]; /*0x1410ae36d*/
  if ( v3 == 0 ) /*0x1410ae370*/
    v3 = *(_QWORD *)&this->token.value[8] - *(_QWORD *)(v4.m128i_i64[0] + 8); /*0x1410ae376*/
  return v3 == 0; /*0x1410ae360*/
}

// Address: 0x1410ae450 | Name: ?deserialize@TokenTlv@Rupp@Network@RBX@@UEAA?AW4ErrorCode@RuppError@234@AEAVBitStream@RakNet@@H@Z
_BOOL8 __fastcall RBX::Network::Rupp::TokenTlv::deserialize(
        RBX::Network::Rupp::TokenTlv *this,
        RakNet::BitStream *b,
        int lengthOfTlvValue)
{
  return RakNet::BitStream::ReadBits( /*0x1410ae491*/
           this: b,
           inOutByteArray: (unsigned __int8 *)&this->token,
           numberOfBitsToRead: 8u,
           alignBitsToRight: true) == 0
      || !RakNet::BitStream::Read(this: b, outByteArray: (char *)this->token.value, numberOfBytes: 0x10u);
}

// Address: 0x1410ae4b0 | Name: ?findTokenInBitstreamIfNext@TokenTlv@Rupp@Network@RBX@@SA?AU?$pair@W4TokenType@TokenTlv@Rupp@Network@RBX@@VStringView@5@@std@@AEAVBitStream@RakNet@@@Z
std::pair<enum RBX::Network::Rupp::TokenTlv::TokenType,RBX::StringView> *__fastcall RBX::Network::Rupp::TokenTlv::findTokenInBitstreamIfNext(
        std::pair<enum RBX::Network::Rupp::TokenTlv::TokenType,RBX::StringView> *result,
        RakNet::BitStream *b)
{
  RBX::Network::Rupp::TokenTlv::TokenType v4; // si
  bool v5; // al
  unsigned __int8 *v6; // rax
  unsigned __int64 v7; // rcx
  __int64 v8; // rax
  unsigned __int8 tlvType[8]; // [rsp+20h] [rbp-28h] BYREF
  RBX::StringView v11; // [rsp+28h] [rbp-20h]
  unsigned __int8 tlvLen; // [rsp+60h] [rbp+18h] BYREF
  unsigned __int8 tlvSubType; // [rsp+68h] [rbp+20h] BYREF

  tlvType[0] = 0; /*0x1410ae4c2*/
  tlvLen = 0; /*0x1410ae4ca*/
  tlvSubType = 0; /*0x1410ae4d2*/
  RakNet::BitStream::ReadBits(this: b, inOutByteArray: tlvType, numberOfBitsToRead: 8u, alignBitsToRight: true); /*0x1410ae4e5*/
  RakNet::BitStream::ReadBits(this: b, inOutByteArray: &tlvLen, numberOfBitsToRead: 8u, alignBitsToRight: true); /*0x1410ae4fb*/
  RakNet::BitStream::ReadBits(this: b, inOutByteArray: &tlvSubType, numberOfBitsToRead: 8u, alignBitsToRight: true); /*0x1410ae511*/
  v4 = tlvSubType; /*0x1410ae516*/
  v5 = tlvSubType != 0 && (unsigned __int8)(tlvSubType - 3) > 0xFBu; /*0x1410ae527*/
  if ( tlvType[0] == 1 && v5 && (b->numberOfBitsUsed - b->readOffset) >> 3 >= tlvLen ) /*0x1410ae548*/
  {
    v6 = b->GetData(this: b); /*0x1410ae550*/
    v7 = (unsigned __int64)b->readOffset >> 3; /*0x1410ae556*/
    result->first = v4; /*0x1410ae55d*/
    v11.Data = (const char *)&v6[v7]; /*0x1410ae560*/
    v8 = tlvLen - 1LL; /*0x1410ae56a*/
  }
  else
  {
    v8 = 0; /*0x1410ae56f*/
    v11.Data = nullptr; /*0x1410ae571*/
    result->first = 0; /*0x1410ae576*/
  }
  v11.Length = v8; /*0x1410ae57d*/
  result->second = v11; /*0x1410ae58a*/
  return result; /*0x1410ae578*/
}

// Address: 0x1410ae5e0 | Name: ?getValueByteLength@TokenTlv@Rupp@Network@RBX@@UEBAEXZ
unsigned __int8 __fastcall RBX::Network::Rupp::TokenTlv::getValueByteLength(RBX::Network::Rupp::TokenTlv *this)
{
  return 17; /*0x1410ae5e2*/
}

// Address: 0x1410ae6d0 | Name: ?serialize@TokenTlv@Rupp@Network@RBX@@UEBAXAEAVBitStream@RakNet@@@Z
void __fastcall RBX::Network::Rupp::TokenTlv::serialize(RBX::Network::Rupp::TokenTlv *this, RakNet::BitStream *b)
{
  RakNet::BitStream::Write(this: b, inputByteArray: (const char *)&this->token, numberOfBytes: 1u); /*0x1410ae6ed*/
  RakNet::BitStream::Write(this: b, inputByteArray: (const char *)this->token.value, numberOfBytes: 0x10u); /*0x1410ae709*/
}

// Address: 0x1410ae710 | Name: ?setTokenValue@TokenTlv@Rupp@Network@RBX@@QEAA?AW4ErrorCode@RuppError@234@VStringView@4@@Z
__int64 __fastcall RBX::Network::Rupp::TokenTlv::setTokenValue(
        RBX::Network::Rupp::TokenTlv *this,
        RBX::StringView *setToken)
{
  if ( this->token.type != 0 && setToken->Length == 16 ) /*0x1410ae71b*/
  {
    *(_OWORD *)this->token.value = *(_OWORD *)setToken->Data; /*0x1410ae725*/
    return 0; /*0x1410ae723*/
  }
  else
  {
    this->token.type = 0; /*0x1410ae72d*/
    *(_OWORD *)this->token.value = 0; /*0x1410ae731*/
    return 9; /*0x1410ae735*/
  }
}

// END TokenTlv part 1/1, 7 functions
