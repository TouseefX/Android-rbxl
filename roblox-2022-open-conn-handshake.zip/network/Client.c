// Client -- 2022 Studio + full PDB
// tier 3, 64 functions


// Address: 0x1406df640 | Name: ??$callDoGetClassIndex@VClient@Network@RBX@@@ServiceProvider@RBX@@CAXXZ
// attributes: thunk
unsigned __int64 __fastcall RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Client>()
{
  return RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>();
}

// Address: 0x1406df760 | Name: ??$doGetClassIndex@VClient@Network@RBX@@@ServiceProvider@RBX@@CA_KXZ
unsigned __int64 __fastcall RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>()
{
  unsigned __int64 result; // rax

  if ( __TSS0__1____doGetClassIndex_VClient_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA <= *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x1406df785*/
    return `RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>'::`2'::index; /*0x1406df785*/
  Init_thread_header(pOnce: &__TSS0__1____doGetClassIndex_VClient_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA); /*0x1406df79a*/
  if ( __TSS0__1____doGetClassIndex_VClient_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA != -1 ) /*0x1406df7a6*/
    return `RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>'::`2'::index; /*0x1406df787*/
  __wind /*0xf1c000000000001c*/
  {
    `RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>'::`2'::index = RBX::ServiceProvider::newIndex(); /*0x1406df7ad*/
    Init_thread_footer(pOnce: &__TSS0__1____doGetClassIndex_VClient_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA); /*0x1406df7bb*/
    result = `RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>'::`2'::index; /*0x1406df7c0*/
  }
  __unwind
  {
    Init_thread_abort(pOnce: &__TSS0__1____doGetClassIndex_VClient_Network_RBX___ServiceProvider_RBX__CA_KXZ_4HA); /*0x14317eab7*/
  }
  return result; /*0x1406df78e*/
}

// Address: 0x1406dfd90 | Name: ??$find@VClient@Network@RBX@@@ServiceProvider@RBX@@QEBAPEAVClient@Network@1@XZ
RBX::Graphics::FrameRateManagerStatsStringItem *__fastcall RBX::ServiceProvider::find<RBX::Network::Client>(
        RBX::ServiceProvider *this)
{
  unsigned __int64 v2; // rax
  std::shared_ptr<RBX::Instance> *v3; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v4; // rdi
  const RBX::Name *v5; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *Rep; // rbx
  std::shared_ptr<RBX::Instance> v9; // [rsp+20h] [rbp-18h] BYREF

  boost::call_once( /*0x1406dfdab*/
    flag: &`RBX::ServiceProvider::getClassIndex<RBX::Network::Client>'::`2'::flag,
    f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Client>);
  v2 = RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>(); /*0x1406dfdb0*/
  v3 = RBX::ServiceProvider::refAt(this, index: v2); /*0x1406dfdbb*/
  v4 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)v3; /*0x1406dfdc0*/
  if ( v3->_Ptr != nullptr ) /*0x1406dfdc7*/
    return (RBX::Graphics::FrameRateManagerStatsStringItem *)v3->_Ptr; /*0x1406dfe45*/
  v5 = RBX::Reflection::Class_getNamePtr<RBX::Network::Client>(); /*0x1406dfdc9*/
  ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName( /*0x1406dfdd9*/
                                                                                            this,
                                                                                            result: &v9,
                                                                                            className: v5);
  std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v4, _Right: ServiceByClassName); /*0x1406dfde4*/
  Rep = v9._Rep; /*0x1406dfde9*/
  if ( v9._Rep == nullptr ) /*0x1406dfdf1*/
    return v4->_Ptr; /*0x1406dfe37*/
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v9._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1406dfe07*/
  {
    Rep->_Destroy(this: Rep); /*0x1406dfe0f*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1406dfe19*/
      Rep->_Delete_this(this: Rep); /*0x1406dfe21*/
  }
  return v4->_Ptr; /*0x1406dfe2c*/
}

// Address: 0x1406dfe60 | Name: ??$find@VClient@Network@RBX@@@ServiceProvider@RBX@@SAPEAVClient@Network@1@PEBV01@@Z
RBX::Graphics::FrameRateManagerStatsStringItem *__fastcall RBX::ServiceProvider::find<RBX::Network::Client>(
        RBX::ServiceProvider *serviceProvider)
{
  unsigned __int64 v2; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v3; // rsi
  const RBX::Name *v4; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *Rep; // rbx
  std::shared_ptr<RBX::Instance> v8; // [rsp+20h] [rbp-18h] BYREF

  if ( serviceProvider == nullptr ) /*0x1406dfe6c*/
    return nullptr; /*0x1406dff11*/
  boost::call_once( /*0x1406dfe85*/
    flag: &`RBX::ServiceProvider::getClassIndex<RBX::Network::Client>'::`2'::flag,
    f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Client>);
  v2 = RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>(); /*0x1406dfe8a*/
  v3 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt( /*0x1406dfe9a*/
                                                                            this: serviceProvider,
                                                                            index: v2);
  if ( v3->_Ptr == nullptr ) /*0x1406dfea1*/
  {
    v4 = RBX::Reflection::Class_getNamePtr<RBX::Network::Client>(); /*0x1406dfea3*/
    ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName( /*0x1406dfeb3*/
                                                                                              this: serviceProvider,
                                                                                              result: &v8,
                                                                                              className: v4);
    std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v3, _Right: ServiceByClassName); /*0x1406dfebe*/
    Rep = v8._Rep; /*0x1406dfec3*/
    if ( v8._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v8._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1406dfee1*/
    {
      Rep->_Destroy(this: Rep); /*0x1406dfee9*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1406dfef3*/
        Rep->_Delete_this(this: Rep); /*0x1406dfefb*/
    }
  }
  return v3->_Ptr; /*0x1406dff0b*/
}

// Address: 0x1406e00b0 | Name: ??$refByClass@VClient@Network@RBX@@@ServiceProvider@RBX@@AEBAAEAV?$shared_ptr@VInstance@RBX@@@std@@XZ
std::shared_ptr<RBX::Instance> *__fastcall RBX::ServiceProvider::refByClass<RBX::Network::Client>(
        RBX::ServiceProvider *this)
{
  unsigned __int64 v2; // rax
  std::shared_ptr<RBX::Instance> *result; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v4; // rdi
  const RBX::Name *v5; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *Rep; // rbx
  std::shared_ptr<RBX::Instance> v8; // [rsp+20h] [rbp-18h] BYREF

  boost::call_once( /*0x1406e00cb*/
    flag: &`RBX::ServiceProvider::getClassIndex<RBX::Network::Client>'::`2'::flag,
    f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Client>);
  v2 = RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>(); /*0x1406e00d0*/
  result = RBX::ServiceProvider::refAt(this, index: v2); /*0x1406e00db*/
  v4 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)result; /*0x1406e00e0*/
  if ( result->_Ptr == nullptr ) /*0x1406e00e7*/
  {
    v5 = RBX::Reflection::Class_getNamePtr<RBX::Network::Client>(); /*0x1406e00e9*/
    ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName( /*0x1406e00f9*/
                                                                                              this,
                                                                                              result: &v8,
                                                                                              className: v5);
    std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v4, _Right: ServiceByClassName); /*0x1406e0104*/
    Rep = v8._Rep; /*0x1406e0109*/
    if ( v8._Rep != nullptr ) /*0x1406e0111*/
    {
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v8._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1406e0127*/
      {
        Rep->_Destroy(this: Rep); /*0x1406e012f*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1406e0139*/
          Rep->_Delete_this(this: Rep); /*0x1406e0141*/
      }
      return (std::shared_ptr<RBX::Instance> *)v4; /*0x1406e0149*/
    }
    else
    {
      return (std::shared_ptr<RBX::Instance> *)v4; /*0x1406e015c*/
    }
  }
  return result; /*0x1406e014c*/
}

// Address: 0x140a2f160 | Name: ??$Class_getDescriptor@VClient@Network@RBX@@@@YAAEAVClassDescriptor@Reflection@RBX@@XZ
// attributes: thunk
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptor<RBX::Network::Client>()
{
  return RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>();
}

// Address: 0x140a2f170 | Name: ??$create@VClient@Network@RBX@@$$V@?$Creatable@VInstance@RBX@@@RBX@@SA?AV?$shared_ptr@VClient@Network@RBX@@@std@@XZ
RBX::Network::Client *__fastcall RBX::Creatable<RBX::Instance>::create<RBX::Network::Client,>(
        RBX::Network::Client *result)
{
  const unsigned int *memoryCategory; // rcx
  unsigned int v3; // ecx
  unsigned int v4; // eax
  RBX::Network::Client *v5; // rax
  RBX::File *v6; // rbp
  RBX::Network::Client *v7; // rax
  RBX::File *v8; // rdi
  std::_Ref_count_base *v9; // rax
  std::_Ref_count_base *Ptr; // rbx
  std::_Ref_count_base *Rep; // rax
  std::_Ref_count_base *v12; // rax
  volatile signed __int32 *v13; // rcx
  signed __int32 v14; // eax
  signed __int32 v15; // eax
  unsigned int parent; // ecx
  __int64 v17; // rcx
  RBX::Network::Client *v18; // rax
  __int64 v19; // [rsp+0h] [rbp-58h] BYREF
  std::_Temporary_owner_del<RBX::File *,RBX::Creatable<RBX::Instance>::Deleter<RBX::File> > v20; // [rsp+20h] [rbp-38h] BYREF
  RBX::Network::Client *v21; // [rsp+60h] [rbp+8h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::Network::Client,void> scope; // [rsp+68h] [rbp+10h] BYREF
  std::_Ref_count_base *v23; // [rsp+70h] [rbp+18h]

  v21 = result; /*0x140a2f175*/
  memoryCategory = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>()->memoryCategory; /*0x140a2f189*/
  if ( memoryCategory != nullptr ) /*0x140a2f193*/
    v3 = *memoryCategory; /*0x140a2f195*/
  else
    v3 = RBX::Memory::InstanceObject; /*0x140a2f199*/
  v4 = RBX::Memory::setCurrentCategory(category: v3); /*0x140a2f19f*/
  scope.parent = v4; /*0x140a2f1a4*/
  __wind /*0xf1c0000000000070*/
  {
    v5 = (RBX::Network::Client *)operator new(size: 0xD48u); /*0x140a2f1ad*/
    v21 = v5; /*0x140a2f1b2*/
    __wind /*0xf1c0000000000064*/
    {
      v6 = nullptr; /*0x140a2f1b7*/
      if ( v5 != nullptr ) /*0x140a2f1bc*/
      {
        v7 = RBX::Network::Client::Client(this: v5); /*0x140a2f1c1*/
        v8 = (RBX::File *)v7; /*0x140a2f1c6*/
      }
      else
      {
        v8 = nullptr; /*0x140a2f1cb*/
      }
    }
    __unwind
    {
      operator delete(ptr: v21); /*0x1431a5c12*/
    }
    result->__vftable = nullptr; /*0x140a2f1ce*/
    result->_Wptr._Ptr = nullptr; /*0x140a2f1d1*/
    v20._Ptr = v8; /*0x140a2f1de*/
    v20._Dt = (RBX::Creatable<RBX::Instance>::Deleter<RBX::File> *)&v21; /*0x140a2f1e8*/
    v20._Call_deleter = true; /*0x140a2f1ed*/
    __wind /*0xf1c0000000000028*/
    {
      v9 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x140a2f1f7*/
      Ptr = v9; /*0x140a2f1fc*/
      v23 = v9; /*0x140a2f1ff*/
      if ( v9 != nullptr ) /*0x140a2f207*/
      {
        *v9 = 0; /*0x140a2f20c*/
        v9->_Uses = 1; /*0x140a2f20f*/
        v9->_Weaks = 1; /*0x140a2f216*/
        v9->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count_resource<RBX::Network::Client *,RBX::Creatable<RBX::Instance>::Deleter<RBX::Network::Client>>::`vftable'; /*0x140a2f224*/
        v9[1].__vftable = (std::_Ref_count_base_vtbl *)v8; /*0x140a2f227*/
      }
      else
      {
        Ptr = nullptr; /*0x140a2f22d*/
      }
      result->__vftable = (RBX::Network::Client_vtbl *)v8; /*0x140a2f230*/
      result->_Wptr._Ptr = (RBX::Reflection::DescribedBase *)Ptr; /*0x140a2f233*/
      if ( v8 != nullptr ) /*0x140a2f23a*/
      {
        Rep = v8->_Wptr._Rep; /*0x140a2f240*/
        if ( Rep == nullptr || Rep->_Uses == 0 ) /*0x140a2f24d*/
        {
          if ( Ptr != nullptr ) /*0x140a2f252*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&Ptr->_Uses); /*0x140a2f254*/
            Ptr = (std::_Ref_count_base *)result->_Wptr._Ptr; /*0x140a2f258*/
          }
          v12 = nullptr; /*0x140a2f25c*/
          if ( Ptr != nullptr ) /*0x140a2f262*/
          {
            v6 = v8; /*0x140a2f264*/
            v12 = Ptr; /*0x140a2f267*/
            _InterlockedIncrement((volatile signed __int32 *)&Ptr->_Weaks); /*0x140a2f26a*/
          }
          v8->_Wptr._Ptr = v6; /*0x140a2f26e*/
          v13 = (volatile signed __int32 *)v8->_Wptr._Rep; /*0x140a2f272*/
          v8->_Wptr._Rep = v12; /*0x140a2f276*/
          if ( v13 != nullptr ) /*0x140a2f282*/
          {
            v14 = _InterlockedExchangeAdd(v13 + 3, 0xFFFFFFFF); /*0x140a2f286*/
            if ( v14 == 1 ) /*0x140a2f28e*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 8LL))(a1: v13); /*0x140a2f293*/
          }
          if ( Ptr != nullptr ) /*0x140a2f299*/
          {
            v15 = _InterlockedExchangeAdd((volatile signed __int32 *)&Ptr->_Uses, 0xFFFFFFFF); /*0x140a2f29d*/
            if ( v15 == 1 ) /*0x140a2f2a5*/
            {
              Ptr->_Destroy(this: Ptr); /*0x140a2f2ad*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Ptr->_Weaks, 0xFFFFFFFF) == 1 ) /*0x140a2f2b7*/
                Ptr->_Delete_this(this: Ptr); /*0x140a2f2bf*/
            }
          }
        }
      }
      parent = scope.parent; /*0x140a2f2c3*/
    }
    __unwind
    {
      std::_Temporary_owner_del<RBX::ScriptService *,RBX::Creatable<RBX::Instance>::Deleter<RBX::ScriptService>>::~_Temporary_owner_del<RBX::ScriptService *,RBX::Creatable<RBX::Instance>::Deleter<RBX::ScriptService>>(this: &v20); /*0xf1c0000000000038*/
    }
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&scope); /*0xf1c0000000000044*/
  }
  __wind /*0xf1c000000000004c*/
  {
    RBX::Memory::setCurrentCategory(category: parent); /*0x140a2f2c7*/
    v18 = result; /*0x140a2f2cd*/
  }
  __unwind
  {
    __std_terminate(a1: v17, a2: &v19); /*0x142f39fa8*/
  }
  return v18; /*0x140a2f2d0*/
}

// Address: 0x140a2f2e0 | Name: ??$create@VClient@Network@RBX@@@ServiceProvider@RBX@@QEBAPEAVClient@Network@1@XZ
RBX::Network::Client *__fastcall RBX::ServiceProvider::create<RBX::Network::Client>(RBX::ServiceProvider *this)
{
  unsigned __int64 v2; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v3; // rdi
  RBX::Network::Client *result; // rax
  const RBX::Name *v5; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *Rep; // rbx
  RBX::Network::Client *Ptr; // rdi
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > *h; // rcx
  unsigned __int64 Mysize; // rax
  void (__fastcall *setName)(struct RBX::Network::Client *, const std::string *); // rbx
  __int64 v12; // rax
  unsigned __int64 v13; // rax
  std::shared_ptr<RBX::Instance> *v14; // rax
  std::_Ref_count_base *v15; // rcx
  volatile signed __int32 *v16; // rbx
  std::_Ref_count_base *v17; // rbx
  std::shared_ptr<RBX::Network::Client> s; // [rsp+20h] [rbp-38h] BYREF
  std::shared_ptr<std::vector<RBX::Guid> > v19; // [rsp+30h] [rbp-28h] BYREF
  std::shared_ptr<RBX::Instance> v20; // [rsp+40h] [rbp-18h] BYREF

  boost::call_once( /*0x140a2f305*/
    flag: &`RBX::ServiceProvider::getClassIndex<RBX::Network::Client>'::`2'::flag,
    f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Client>);
  v2 = RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>(); /*0x140a2f30a*/
  v3 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt(this, index: v2); /*0x140a2f31a*/
  result = (RBX::Network::Client *)v3->_Ptr; /*0x140a2f31d*/
  if ( v3->_Ptr == nullptr ) /*0x140a2f323*/
  {
    v5 = RBX::Reflection::Class_getNamePtr<RBX::Network::Client>(); /*0x140a2f329*/
    ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName( /*0x140a2f339*/
                                                                                              this,
                                                                                              result: &v20,
                                                                                              className: v5);
    std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v3, _Right: ServiceByClassName); /*0x140a2f344*/
    Rep = v20._Rep; /*0x140a2f34e*/
    if ( v20._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v20._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x140a2f362*/
    {
      Rep->_Destroy(this: Rep); /*0x140a2f36a*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x140a2f376*/
        Rep->_Delete_this(this: Rep); /*0x140a2f37e*/
    }
    result = (RBX::Network::Client *)v3->_Ptr; /*0x140a2f381*/
    if ( v3->_Ptr == nullptr ) /*0x140a2f387*/
    {
      RBX::Creatable<RBX::Instance>::create<RBX::Network::Client,>(result: (RBX::Network::Client *)&s); /*0x140a2f392*/
      Ptr = s._Ptr; /*0x140a2f398*/
      if ( DFFlag::ServiceProviderSetName.value ) /*0x140a2f3a4*/
      {
        h = s._Ptr->name.h.h; /*0x140a2f3a6*/
        Mysize = h->x.x._Mypair._Myval2._Mysize; /*0x140a2f3aa*/
        if ( h->x.x._Mypair._Myval2._Myres >= 0x10 ) /*0x140a2f3b3*/
          h = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > *)h->x.x._Mypair._Myval2._Bx._Ptr; /*0x140a2f3b5*/
        if ( Mysize == 8 /*0x140a2f3cf*/
          && memcmp_0(
               Buf1: h,
               Buf2: &std::_Ref_count_obj2<RBX::AssetImport::Errors::FileEmptyError>::`vftable'[4],
               Size: 8u) == 0 )
        {
          setName = Ptr->setName; /*0x140a2f3d4*/
          v12 = (__int64)Ptr->getClassName(this: Ptr); /*0x140a2f3de*/
          setName(this: Ptr, a2: (const std::string *)v12); /*0x140a2f3e7*/
        }
      }
      v19 = 0; /*0x140a2f3ec*/
      RBX::Instance::setAndLockParent(this: Ptr, instance: this, destroying: false, destroyedGuids: &v19); /*0x140a2f400*/
      boost::call_once( /*0x140a2f413*/
        flag: &`RBX::ServiceProvider::getClassIndex<RBX::Network::Client>'::`2'::flag,
        f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Client>);
      v13 = RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>(); /*0x140a2f418*/
      v14 = RBX::ServiceProvider::refAt(this, index: v13); /*0x140a2f423*/
      v15 = s._Rep; /*0x140a2f428*/
      if ( s._Rep != nullptr ) /*0x140a2f430*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&s._Rep->_Uses); /*0x140a2f432*/
        v15 = s._Rep; /*0x140a2f436*/
        Ptr = s._Ptr; /*0x140a2f43b*/
      }
      v14->_Ptr = Ptr; /*0x140a2f440*/
      v16 = (volatile signed __int32 *)v14->_Rep; /*0x140a2f443*/
      v14->_Rep = v15; /*0x140a2f447*/
      if ( v16 != nullptr ) /*0x140a2f44e*/
      {
        if ( _InterlockedExchangeAdd(v16 + 2, 0xFFFFFFFF) == 1 ) /*0x140a2f45a*/
        {
          (**(void (__fastcall ***)(volatile signed __int32 *))v16)(a1: v16); /*0x140a2f462*/
          if ( _InterlockedExchangeAdd(v16 + 3, 0xFFFFFFFF) == 1 ) /*0x140a2f46e*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 8LL))(a1: v16); /*0x140a2f476*/
        }
        Ptr = s._Ptr; /*0x140a2f479*/
        v15 = s._Rep; /*0x140a2f47e*/
      }
      if ( v15 != nullptr ) /*0x140a2f486*/
      {
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v15->_Uses, 0xFFFFFFFF) == 1 ) /*0x140a2f492*/
        {
          v17 = s._Rep; /*0x140a2f494*/
          s._Rep->_Destroy(this: s._Rep); /*0x140a2f49f*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v17->_Weaks, 0xFFFFFFFF) == 1 ) /*0x140a2f4a9*/
            s._Rep->_Delete_this(this: s._Rep); /*0x140a2f4b3*/
        }
        return s._Ptr; /*0x140a2f4b6*/
      }
      return Ptr; /*0x140a2f4bb*/
    }
  }
  return result; /*0x140a2f4be*/
}

// Address: 0x140fa1ff0 | Name: ??$find@VClient@Network@RBX@@@ServiceProvider@RBX@@SAPEAVClient@Network@1@PEBVInstance@1@@Z
RBX::Graphics::FrameRateManagerStatsStringItem *__fastcall RBX::ServiceProvider::find<RBX::Network::Client>(
        RBX::ServiceProvider *context)
{
  RBX::ServiceProvider *parent; // rdi
  RBX::Instance *v2; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v4; // rax
  unsigned __int64 v5; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v6; // rsi
  const RBX::Name *v7; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *Rep; // rbx
  std::shared_ptr<RBX::Instance> v11; // [rsp+20h] [rbp-18h] BYREF

  if ( context == nullptr ) /*0x140fa1ffd*/
    return nullptr; /*0x140fa1ffd*/
  parent = (RBX::ServiceProvider *)context->parent; /*0x140fa2003*/
  if ( parent != nullptr ) /*0x140fa200a*/
  {
    v2 = parent->parent; /*0x140fa200c*/
    if ( v2 != nullptr ) /*0x140fa2013*/
      parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v2); /*0x140fa201a*/
  }
  else
  {
    parent = context; /*0x140fa201f*/
  }
  if ( parent == nullptr ) /*0x140fa2025*/
    return nullptr; /*0x140fa2025*/
  descriptor = parent->descriptor; /*0x140fa202b*/
  v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(); /*0x140fa202f*/
  if ( descriptor->index - (unsigned int)v4->index > v4->descendantCount ) /*0x140fa204d*/
    return nullptr; /*0x140fa20f2*/
  boost::call_once( /*0x140fa2066*/
    flag: &`RBX::ServiceProvider::getClassIndex<RBX::Network::Client>'::`2'::flag,
    f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Client>);
  v5 = RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>(); /*0x140fa206b*/
  v6 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt( /*0x140fa207b*/
                                                                            this: parent,
                                                                            index: v5);
  if ( v6->_Ptr == nullptr ) /*0x140fa2082*/
  {
    v7 = RBX::Reflection::Class_getNamePtr<RBX::Network::Client>(); /*0x140fa2084*/
    ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName( /*0x140fa2094*/
                                                                                              this: parent,
                                                                                              result: &v11,
                                                                                              className: v7);
    std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v6, _Right: ServiceByClassName); /*0x140fa209f*/
    Rep = v11._Rep; /*0x140fa20a4*/
    if ( v11._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v11._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x140fa20bd*/
    {
      Rep->_Destroy(this: Rep); /*0x140fa20c5*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x140fa20cf*/
        Rep->_Delete_this(this: Rep); /*0x140fa20d7*/
    }
  }
  return v6->_Ptr; /*0x140fa20e2*/
}

// Address: 0x14100a1f0 | Name: ??$Class_getDescriptorPtr@VClient@Network@RBX@@@Reflection@RBX@@YAAEAVClassDescriptor@01@XZ
RBX::ClassRegistrar<RBX::Network::Client,1> *__fastcall RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>()
{
  RBX::ClassRegistrar<RBX::Network::Client,1> *result; // rax
  RBX::Reflection::ClassDescriptor *v1; // rax
  RBX::Reflection::ClassDescriptor::Attributes v3; // [rsp+60h] [rbp-28h] BYREF
  RBX::Reflection::ClassDescriptor::Attributes v4; // 0:^50.32

  result = (RBX::ClassRegistrar<RBX::Network::Client,1> *)ret_84; /*0x14100a1fd*/
  if ( ret_84 == nullptr ) /*0x14100a207*/
  {
    if ( _TSS0_510 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x14100a233*/
    {
      Init_thread_header(pOnce: &_TSS0_510); /*0x14100a257*/
      if ( _TSS0_510 == -1 ) /*0x14100a263*/
      {
        v4.isDeprecated = false; /*0x14100a265*/
        v4.preferred = nullptr; /*0x14100a26c*/
        v4.threadSafety = Unset; /*0x14100a271*/
        v4.flags = INTERNAL_LOCAL; /*0x14100a275*/
        __wind /*0xf1c000000000005c*/
        {
          v1 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Peer>(); /*0x14100a27d*/
          v3 = v4; /*0x14100a287*/
          RBX::Reflection::ClassDescriptor::ClassDescriptor( /*0x14100a2b9*/
            this: &reg_76.desc,
            base: v1,
            name: (const char *)&RBX::Creator<RBX::Network::Client>::`vftable'[3],
            isService: true,
            attributes: &v3,
            security: (RBX::Security::Permissions)0,
            memoryCategory: nullptr);
          __wind /*0xf1c0000000000050*/
          {
            reg_76.creator.__vftable = (RBX::Creator<RBX::Network::Client>_vtbl *)RBX::Creator<RBX::Network::Client>::`vftable'; /*0x14100a2c6*/
            __wind /*0xf1c0000000000020*/
            {
              RBX::Creatable<RBX::Instance>::setCreator(desc: &reg_76.desc, creator: &reg_76.creator); /*0x14100a2d7*/
              atexit(function: RBX::Reflection::Class_getDescriptorPtr_RBX::Network::Client__::_2_::_dynamic_atexit_destructor_for__reg__); /*0x14100a2e4*/
              Init_thread_footer(pOnce: &_TSS0_510); /*0x14100a2f1*/
            }
            __unwind
            {
              RBX::Creator<RBX::Network::Client>::~Creator<RBX::Network::Client>(this: &reg_76.creator); /*0x1431e505e*/
            }
          }
          __unwind
          {
            RBX::Reflection::ClassDescriptor::~ClassDescriptor(this: &reg_76.desc); /*0x1431e5047*/
          }
        }
        __unwind
        {
          Init_thread_abort(pOnce: &_TSS0_510); /*0x1431e5037*/
        }
      }
    }
    ret_84 = (RBX::Reflection::ClassDescriptor *)&reg_76; /*0x14100a235*/
    return &reg_76; /*0x14100a23c*/
  }
  return result; /*0x14100a23f*/
}

// Address: 0x14100aaa0 | Name: ??$Class_getNamePtr@VClient@Network@RBX@@@Reflection@RBX@@YAAEBVName@1@XZ
const RBX::Name *__fastcall RBX::Reflection::Class_getNamePtr<RBX::Network::Client>()
{
  const RBX::Name *result; // rax

  result = name_40; /*0x14100aaa4*/
  if ( name_40 == nullptr ) /*0x14100aaae*/
  {
    result = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>()->desc.name; /*0x14100aab5*/
    name_40 = result; /*0x14100aab9*/
  }
  return result; /*0x14100aac0*/
}

// Address: 0x14100f210 | Name: ??0Client@Network@RBX@@QEAA@XZ
RBX::Network::Client *__fastcall RBX::Network::Client::Client(RBX::Network::Client *this)
{
  RBX::ClassRegistrar<RBX::Network::Client,1> *v2; // rax
  rtc::RefCountedObject<webrtc::RtpReceiverInternal> *ClassEntry; // rax
  RBX::NetworkSettings *v4; // rsi
  RBX::GlobalAdvancedSettings *Ptr; // rsi
  _Mtx_internal_imp_t *p_mx; // rbx
  int v7; // eax
  __int64 v8; // rbx
  RBX::Security::Context *v9; // rbx
  char *v10; // rcx
  RBX::Graphics::ProfilerAdorn::Item v12; // [rsp+30h] [rbp-48h] BYREF
  MicroProfileScopeLock v14; // [rsp+88h] [rbp+10h] BYREF

  RBX::Network::Peer::Peer(this); /*0x14100f224*/
  __wind /*0xf1c00000000001fc*/
  {
    this->__vftable = (RBX::Network::Client_vtbl *)RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer>::`vftable'; /*0x14100f231*/
    this->descriptor = (const RBX::Reflection::ClassDescriptor *)RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(); /*0x14100f239*/
    if ( FFlag::g_flagsLoaded && FFlag::DebugTraceCreatableCounts3.value ) /*0x14100f24d*/
    {
      v2 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(); /*0x14100f24f*/
      ClassEntry = (rtc::RefCountedObject<webrtc::RtpReceiverInternal> *)RBX::Reflection::Stat::getClassEntry(desc: &v2->desc); /*0x14100f257*/
      rtc::RefCountedObject<rtc::RefCountInterface>::AddRef(this: ClassEntry); /*0x14100f25f*/
    }
  }
  __unwind
  {
    RBX::Network::Peer::~Peer(this); /*0xf1c000000000020c*/
  }
  __wind /*0xf1c0000000000214*/
  {
    this->isPublic = true; /*0x14100f265*/
    this->__vftable = (RBX::Network::Client_vtbl *)RBX::Network::Client::`vftable'; /*0x14100f273*/
    this->closingConnection.con.weak_slot.p_ = nullptr; /*0x14100f278*/
    this->extAntiCheatConnectConnection.con.weak_slot.p_ = nullptr; /*0x14100f27f*/
    this->extAntiCheatDisconnectConnection.con.weak_slot.p_ = nullptr; /*0x14100f286*/
    this->requestProfilerDataConnection.con.weak_slot.p_ = nullptr; /*0x14100f28d*/
    __wind /*0xf1c0000000000264*/
    {
      __wind /*0xf1c000000000026c*/
      {
        __wind /*0xf1c0000000000274*/
        {
          __wind /*0xf1c000000000027c*/
          {
            RakNet::SystemAddress::SystemAddress(this: &this->serverId); /*0x14100f29b*/
            __wind /*0xf1c0000000000234*/
            {
              __wind /*0xf1c000000000023c*/
              {
                this->userId = -1; /*0x14100f2a0*/
                this->ticket._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14100f2ab*/
                this->ticket._Mypair._Myval2._Mysize = 0; /*0x14100f2b2*/
                this->ticket._Mypair._Myval2._Myres = 15; /*0x14100f2b9*/
                this->ticket._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100f2c4*/
                this->playSessionId._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14100f2cb*/
                this->playSessionId._Mypair._Myval2._Mysize = 0; /*0x14100f2d2*/
                this->playSessionId._Mypair._Myval2._Myres = 15; /*0x14100f2d9*/
                this->playSessionId._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100f2e4*/
                v4 = (RBX::NetworkSettings *)RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing; /*0x14100f2eb*/
                if ( RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing == nullptr ) /*0x14100f2f5*/
                {
                  Ptr = RBX::GlobalAdvancedSettings::singleton()->_Ptr; /*0x14100f300*/
                  p_mx = (_Mtx_internal_imp_t *)&Ptr->mx; /*0x14100f303*/
                  v14.m = (std::recursive_mutex *)&Ptr->mx; /*0x14100f30a*/
                  v7 = Mtx_lock_0(a1: (_Mtx_t)&Ptr->mx); /*0x14100f315*/
                  if ( v7 != 0 ) /*0x14100f31c*/
                  {
                    std::_Throw_C_error(a1: v7); /*0x14100f677*/
                    JUMPOUT(0x14100F67CLL); /*0x14100f67c*/
                  }
                  if ( RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing == nullptr ) /*0x14100f329*/
                  {
                    __wind /*0xf1c00000000001f0*/
                    {
                      RBX::Creatable<RBX::Instance>::create<RBX::NetworkSettings,>(result: (std::shared_ptr<RBX::NetworkSettings> *)&v12); /*0x14100f330*/
                      __wind /*0xf1c00000000001cc*/
                      {
                        *(_OWORD *)&v12.x = 0; /*0x14100f339*/
                        RBX::Instance::setParentInternal( /*0x14100f357*/
                          this: (RBX::Instance *)v12.text._Mypair._Myval2._Bx._Ptr,
                          newParent: Ptr,
                          ignoreLock: false,
                          destroying: false,
                          destroyedGuids: (std::shared_ptr<std::vector<RBX::Guid> > *)&v12.x);
                        if ( *(_QWORD *)&v12.text._Mypair._Myval2._Bx._Alias[8] != 0 ) /*0x14100f365*/
                        {
                          if ( _InterlockedExchangeAdd( /*0x14100f374*/
                                 (volatile signed __int32 *)(*(_QWORD *)&v12.text._Mypair._Myval2._Bx._Alias[8] + 8LL),
                                 0xFFFFFFFF) == 1 )
                          {
                            v8 = *(_QWORD *)&v12.text._Mypair._Myval2._Bx._Alias[8]; /*0x14100f376*/
                            (***(void (__fastcall ****)(_QWORD))&v12.text._Mypair._Myval2._Bx._Alias[8])(a1: *(_QWORD *)&v12.text._Mypair._Myval2._Bx._Alias[8]); /*0x14100f381*/
                            if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v8 + 12), 0xFFFFFFFF) == 1 ) /*0x14100f390*/
                              (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v12.text._Mypair._Myval2._Bx._Alias[8] + 8LL))(a1: *(_QWORD *)&v12.text._Mypair._Myval2._Bx._Alias[8]); /*0x14100f39a*/
                          }
                          p_mx = (_Mtx_internal_imp_t *)v14.m; /*0x14100f39d*/
                        }
                      }
                      __unwind
                      {
                        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v12); /*0xf1c00000000001dc*/
                      }
                    }
                    __unwind
                    {
                      std::scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>::~scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>(this: &v14); /*0xf1c00000000001e8*/
                    }
                  }
                  v4 = (RBX::NetworkSettings *)RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing; /*0x14100f3a5*/
                  Mtx_unlock_0(a1: p_mx); /*0x14100f3af*/
                }
                this->networkSettings = v4; /*0x14100f3b4*/
                *(_QWORD *)&this->serverDataCenterId = -1; /*0x14100f3bb*/
                *(_DWORD *)&this->receivedOpenConnectionReply1 = 0; /*0x14100f3c6*/
                *(_WORD *)&this->ruppEnabled = 0; /*0x14100f3d0*/
                this->requestedServerAddress._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14100f3e0*/
                this->requestedServerAddress._Mypair._Myval2._Myres = 15; /*0x14100f3e3*/
                this->requestedServerAddress._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100f3eb*/
                this->requestedServerAddress._Mypair._Myval2._Mysize = 7; /*0x14100f3ee*/
                memmove_0(a1: &this->requestedServerAddress, Src: "Unknown", Size: 7u); /*0x14100f406*/
                __wind /*0xf1c0000000000220*/
                {
                  __wind /*0xf1c0000000000228*/
                  {
                    this->requestedServerAddress._Mypair._Myval2._Bx._Buf[7] = 0; /*0x14100f40b*/
                    this->reportingJoinState = JoinState_NotStartedYet; /*0x14100f40f*/
                    this->lastReportedMetric._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14100f415*/
                    this->lastReportedMetric._Mypair._Myval2._Mysize = 0; /*0x14100f41c*/
                    this->lastReportedMetric._Mypair._Myval2._Myres = 15; /*0x14100f423*/
                    this->lastReportedMetric._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100f42e*/
                    RBX::Time::nowFast(result: &this->lastReportedTime); /*0x14100f43c*/
                    __wind /*0xf1c00000000001c0*/
                    {
                      this->playerInfoJson._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14100f441*/
                      this->playerInfoJson._Mypair._Myval2._Mysize = 0; /*0x14100f448*/
                      this->playerInfoJson._Mypair._Myval2._Myres = 15; /*0x14100f44f*/
                      this->playerInfoJson._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100f45a*/
                      RBX::Network::MegaReplicator::MegaReplicator( /*0x14100f46d*/
                        this: &this->megaReplicator,
                        cacheAvailable: false,
                        server: nullptr);
                      this->clientReplicator = nullptr; /*0x14100f473*/
                      Mtx_init_in_situ_0(a1: (_Mtx_t)&this->connectionStateAndJoinDataMutex, a2: 2); /*0x14100f486*/
                      __wind /*0xf1c0000000000248*/
                      {
                        __wind /*0xf1c0000000000250*/
                        {
                          __wind /*0xf1c0000000000258*/
                          {
                            this->gameSessionID._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14100f48c*/
                            this->gameSessionID._Mypair._Myval2._Mysize = 0; /*0x14100f493*/
                            this->gameSessionID._Mypair._Myval2._Myres = 15; /*0x14100f49a*/
                            this->gameSessionID._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100f4a5*/
                            v14.m = (std::recursive_mutex *)&this->connectionAcceptedSignal; /*0x14100f4b3*/
                            rbx::signals::signal_base::signal_base(this: &this->connectionAcceptedSignal); /*0x14100f4bb*/
                            __wind /*0xf1c00000000001b4*/
                            {
                              v14.m = (std::recursive_mutex *)&this->connectionFailedSignal; /*0x14100f4c8*/
                              rbx::signals::signal_base::signal_base(this: &this->connectionFailedSignal); /*0x14100f4d0*/
                              __wind /*0xf1c00000000001a8*/
                              {
                                v14.m = (std::recursive_mutex *)&this->extAntiCheatSignal; /*0x14100f4dd*/
                                rbx::signals::signal_base::signal_base(this: &this->extAntiCheatSignal); /*0x14100f4e5*/
                                __wind /*0xf1c000000000019c*/
                                {
                                  v14.m = (std::recursive_mutex *)&this->outOfMemorySignal; /*0x14100f4f2*/
                                  rbx::signals::signal_base::signal_base(this: &this->outOfMemorySignal); /*0x14100f4fa*/
                                  __wind /*0xf1c00000000000c4*/
                                  {
                                    v14.m = (std::recursive_mutex *)&this->ticketSentSignal; /*0x14100f507*/
                                    rbx::signals::signal_base::signal_base(this: &this->ticketSentSignal); /*0x14100f50f*/
                                    this->clientReplicationMode = ReplicationMode_Client; /*0x14100f515*/
                                    this->serverConnections._Mypair._Myval2._Myfirst = nullptr; /*0x14100f51b*/
                                    this->serverConnections._Mypair._Myval2._Mylast = nullptr; /*0x14100f522*/
                                    this->serverConnections._Mypair._Myval2._Myend = nullptr; /*0x14100f529*/
                                    this->perServerMetricReported = false; /*0x14100f530*/
                                    Mtx_init_in_situ_0(a1: (_Mtx_t)&this->latencyExperimentCache, a2: 2); /*0x14100f543*/
                                    this->latencyExperimentCache.artificialLatencyRecords._Mypair._Myval2._Myfirst = nullptr; /*0x14100f548*/
                                    this->latencyExperimentCache.artificialLatencyRecords._Mypair._Myval2._Mylast = nullptr; /*0x14100f54f*/
                                    this->latencyExperimentCache.artificialLatencyRecords._Mypair._Myval2._Myend = nullptr; /*0x14100f556*/
                                    this->latencyExperimentCache.cacheReadAttempted = false; /*0x14100f55d*/
                                    this->ixpChangedListener._Ptr = nullptr; /*0x14100f564*/
                                    this->ixpChangedListener._Rep = nullptr; /*0x14100f56b*/
                                    Mtx_init_in_situ_0(a1: (_Mtx_t)&this->setLatencyMx, a2: 2); /*0x14100f57e*/
                                    __wind /*0xf1c0000000000288*/
                                    {
                                      __wind /*0xf1c0000000000290*/
                                      {
                                        __wind /*0xf1c0000000000298*/
                                        {
                                          __wind /*0xf1c00000000002a0*/
                                          {
                                            __wind /*0xf1c00000000002a8*/
                                            {
                                              this->latencySetFromLiveResponse = false; /*0x14100f584*/
                                              this->latencyCheckStartTime.sec = 0.0; /*0x14100f58b*/
                                              v9 = RBX::Security::Context::current(); /*0x14100f597*/
                                              if ( !RBX::Security::Context::isInRole( /*0x14100f5a2*/
                                                      identity: &v9->identity,
                                                      p: (RBX::Security::Permissions)1) )
                                                RBX::Security::Context::throwPermissionError( /*0x14100f5ba*/
                                                  this: v9,
                                                  permission: (RBX::Security::Permissions)1,
                                                  operation: (const char *)&RBX::Reflection::EventDesc<RBX::Network::Client,void (std::string,int,std::string),rbx::signal<void (std::string,int,std::string)>,rbx::signal<void (std::string,int,std::string)> * (RBX::Network::Client::*)(bool)>::`vftable'[7]);
                                              v12.text._Mypair._Myval2._Myres = 15; /*0x14100f5bf*/
                                              v12.text._Mypair._Myval2._Mysize = 13; /*0x14100f5c8*/
                                              strcpy(v12.text._Mypair._Myval2._Bx._Buf, "NetworkClient"); /*0x14100f5d9*/
                                              __wind /*0xf1c00000000000b8*/
                                              {
                                                RBX::Instance::setName(this, value: &v12.text); /*0x14100f601*/
                                              }
                                              __unwind
                                              {
                                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v12); /*0xf1c00000000000b0*/
                                              }
                                              if ( v12.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14100f610*/
                                              {
                                                v10 = v12.text._Mypair._Myval2._Bx._Ptr; /*0x14100f615*/
                                                if ( v12.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14100f624*/
                                                {
                                                  v10 = *((char **)v12.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14100f62a*/
                                                  if ( (unsigned __int64)(v12.text._Mypair._Myval2._Bx._Ptr - v10 - 8) > 0x1F ) /*0x14100f639*/
                                                    _invalid_parameter_noinfo_noreturn(); /*0x14100f63b*/
                                                }
                                                operator delete(ptr: v10); /*0x14100f642*/
                                              }
                                              if ( FLog::Network != 0 ) /*0x14100f650*/
                                                FLog::FastLog( /*0x14100f65c*/
                                                  level: FLog::Network,
                                                  message: "[FLog::Network] NetworkClient:Create",
                                                  arg0: nullptr);
                                            }
                                            __unwind
                                            {
                                              std::recursive_mutex::~recursive_mutex(this: (RBX::InstrumentedMutex<std::mutex> *)&this->setLatencyMx); /*0x1431e56de*/
                                            }
                                          }
                                          __unwind
                                          {
                                            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->ixpChangedListener); /*0x1431e56be*/
                                          }
                                        }
                                        __unwind
                                        {
                                          RBX::Network::Client::LatencyExperimentCache::~LatencyExperimentCache(this: &this->latencyExperimentCache); /*0x1431e569e*/
                                        }
                                      }
                                      __unwind
                                      {
                                        std::vector<RBX::Network::Client::ServerConnection>::~vector<RBX::Network::Client::ServerConnection>(this: &this->serverConnections); /*0x1431e567e*/
                                      }
                                    }
                                    __unwind
                                    {
                                      rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)&this->ticketSentSignal); /*0x1431e565e*/
                                    }
                                  }
                                  __unwind
                                  {
                                    rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)&this->outOfMemorySignal); /*0x1431e563e*/
                                  }
                                }
                                __unwind
                                {
                                  rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)&this->extAntiCheatSignal); /*0x1431e561e*/
                                }
                              }
                              __unwind
                              {
                                rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)&this->connectionFailedSignal); /*0x1431e55fe*/
                              }
                            }
                            __unwind
                            {
                              rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)&this->connectionAcceptedSignal); /*0x1431e55de*/
                            }
                          }
                          __unwind
                          {
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->gameSessionID); /*0x1431e55be*/
                          }
                        }
                        __unwind
                        {
                          std::recursive_mutex::~recursive_mutex(this: &this->connectionStateAndJoinDataMutex); /*0x1431e559e*/
                        }
                      }
                      __unwind
                      {
                        RBX::Network::MegaReplicator::~MegaReplicator(this: &this->megaReplicator); /*0x1431e557e*/
                      }
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->playerInfoJson); /*0x1431e555e*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->lastReportedMetric); /*0x1431e553e*/
                  }
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->requestedServerAddress); /*0x1431e551e*/
                }
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->playSessionId); /*0x1431e54fe*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->ticket); /*0x1431e54de*/
            }
          }
          __unwind
          {
            rbx::signals::scoped_connection::~scoped_connection(this: &this->requestProfilerDataConnection); /*0x1431e54be*/
          }
        }
        __unwind
        {
          rbx::signals::scoped_connection::~scoped_connection(this: &this->extAntiCheatDisconnectConnection); /*0x1431e549e*/
        }
      }
      __unwind
      {
        rbx::signals::scoped_connection::~scoped_connection(this: &this->extAntiCheatConnectConnection); /*0x1431e547e*/
      }
    }
    __unwind
    {
      rbx::signals::scoped_connection::~scoped_connection(this: &this->closingConnection); /*0x1431e545e*/
    }
  }
  __unwind
  {
    RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer>::~DescribedCreatable<RBX::Network::Client,RBX::Network::Peer>(this); /*0xf1c0000000000194*/
  }
  return this; /*0x14100f665*/
}

// Address: 0x14100fc90 | Name: ??1Client@Network@RBX@@UEAA@XZ
void __fastcall RBX::Network::Client::~Client(RBX::Network::Client *this)
{
  RBX::Ixp::IxpController *v2; // rax
  void (__fastcall *removeUserChangedListener)(struct RBX::Ixp::IxpController *, std::weak_ptr<RBX::Ixp::ChangedListener> *__struct_ptr); // r8
  std::_Ref_count_base *Rep; // rdx
  std::_Ref_count_base *v5; // rbx
  unsigned __int64 Myres; // rdx
  char *Ptr; // rcx
  unsigned __int64 v8; // rdx
  char *v9; // rcx
  unsigned __int64 v10; // rdx
  char *v11; // rcx
  unsigned __int64 v12; // rdx
  char *v13; // rcx
  unsigned __int64 v14; // rdx
  char *v15; // rcx
  unsigned __int64 v16; // rdx
  char *v17; // rcx
  rbx::signals::slot_base *p; // rcx
  rbx::signals::slot_base *v19; // rcx
  rbx::signals::slot_base *v20; // rcx
  rbx::signals::slot_base *v21; // rcx
  RBX::ClassRegistrar<RBX::Network::Client,1> *v22; // rax
  RBX::Reflection::Stat::ClassEntry *ClassEntry; // rax
  __int64 v24; // rcx
  __int64 v25; // [rsp+0h] [rbp-38h] BYREF
  std::weak_ptr<RBX::Ixp::ChangedListener> v26; // [rsp+20h] [rbp-18h] BYREF

  this->__vftable = (RBX::Network::Client_vtbl *)RBX::Network::Client::`vftable'; /*0x14100fca9*/
  if ( FLog::Network != 0 ) /*0x14100fcb5*/
    FLog::FastLog(level: FLog::Network, message: "[FLog::Network] NetworkClient:Remove", arg0: nullptr); /*0x14100fcc1*/
  if ( DFFlag::CLI52064UseIxp.value && this->ixpChangedListener._Ptr != nullptr ) /*0x14100fcd7*/
  {
    v2 = RBX::Ixp::IxpController::instance(); /*0x14100fcd9*/
    removeUserChangedListener = v2->removeUserChangedListener; /*0x14100fce1*/
    v26 = 0; /*0x14100fceb*/
    Rep = this->ixpChangedListener._Rep; /*0x14100fcf1*/
    if ( Rep != nullptr ) /*0x14100fcfb*/
    {
      v26._Ptr = this->ixpChangedListener._Ptr; /*0x14100fd04*/
      v26._Rep = Rep; /*0x14100fd09*/
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Weaks); /*0x14100fd0e*/
    }
    removeUserChangedListener(this: v2, a2: &v26); /*0x14100fd1a*/
  }
  Mtx_destroy_in_situ_0(a1: (_Mtx_t)&this->setLatencyMx); /*0x14100fd24*/
  v5 = this->ixpChangedListener._Rep; /*0x14100fd29*/
  if ( v5 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Uses, 0xFFFFFFFF) == 1 ) /*0x14100fd44*/
  {
    v5->_Destroy(this: v5); /*0x14100fd4c*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14100fd58*/
      v5->_Delete_this(this: v5); /*0x14100fd60*/
  }
  RBX::Network::Client::LatencyExperimentCache::~LatencyExperimentCache(this: &this->latencyExperimentCache); /*0x14100fd6a*/
  std::vector<RBX::Network::Client::ServerConnection>::~vector<RBX::Network::Client::ServerConnection>(this: &this->serverConnections); /*0x14100fd76*/
  rbx::signals::signal_base::~signal_base(this: &this->ticketSentSignal); /*0x14100fd82*/
  rbx::signals::signal_base::~signal_base(this: &this->outOfMemorySignal); /*0x14100fd8e*/
  rbx::signals::signal_base::~signal_base(this: &this->extAntiCheatSignal); /*0x14100fd9a*/
  rbx::signals::signal_base::~signal_base(this: &this->connectionFailedSignal); /*0x14100fda6*/
  rbx::signals::signal_base::~signal_base(this: &this->connectionAcceptedSignal); /*0x14100fdb2*/
  Myres = this->gameSessionID._Mypair._Myval2._Myres; /*0x14100fdb7*/
  if ( Myres >= 0x10 ) /*0x14100fdc2*/
  {
    Ptr = this->gameSessionID._Mypair._Myval2._Bx._Ptr; /*0x14100fdc4*/
    if ( Myres + 1 >= 0x1000 ) /*0x14100fdd5*/
    {
      if ( (unsigned __int64)&Ptr[-*((_QWORD *)Ptr - 1) - 8] > 0x1F ) /*0x14100fdea*/
        goto LABEL_59; /*0x14100fdea*/
      Ptr = *((char **)Ptr - 1); /*0x14100fdf0*/
    }
    operator delete(ptr: Ptr); /*0x14100fdf3*/
  }
  this->gameSessionID._Mypair._Myval2._Mysize = 0; /*0x14100fdfa*/
  this->gameSessionID._Mypair._Myval2._Myres = 15; /*0x14100fe01*/
  this->gameSessionID._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100fe0c*/
  Mtx_destroy_in_situ_0(a1: (_Mtx_t)&this->connectionStateAndJoinDataMutex); /*0x14100fe19*/
  RBX::Network::MegaReplicator::~MegaReplicator(this: &this->megaReplicator); /*0x14100fe25*/
  v8 = this->playerInfoJson._Mypair._Myval2._Myres; /*0x14100fe2a*/
  if ( v8 >= 0x10 ) /*0x14100fe35*/
  {
    v9 = this->playerInfoJson._Mypair._Myval2._Bx._Ptr; /*0x14100fe37*/
    if ( v8 + 1 >= 0x1000 ) /*0x14100fe48*/
    {
      if ( (unsigned __int64)&v9[-*((_QWORD *)v9 - 1) - 8] > 0x1F ) /*0x14100fe5d*/
        goto LABEL_59; /*0x14100fe5d*/
      v9 = *((char **)v9 - 1); /*0x14100fe63*/
    }
    operator delete(ptr: v9); /*0x14100fe66*/
  }
  this->playerInfoJson._Mypair._Myval2._Mysize = 0; /*0x14100fe6b*/
  this->playerInfoJson._Mypair._Myval2._Myres = 15; /*0x14100fe72*/
  this->playerInfoJson._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100fe7d*/
  v10 = this->lastReportedMetric._Mypair._Myval2._Myres; /*0x14100fe83*/
  if ( v10 >= 0x10 ) /*0x14100fe8e*/
  {
    v11 = this->lastReportedMetric._Mypair._Myval2._Bx._Ptr; /*0x14100fe90*/
    if ( v10 + 1 >= 0x1000 ) /*0x14100fea1*/
    {
      if ( (unsigned __int64)&v11[-*((_QWORD *)v11 - 1) - 8] > 0x1F ) /*0x14100feb6*/
        goto LABEL_59; /*0x14100feb6*/
      v11 = *((char **)v11 - 1); /*0x14100febc*/
    }
    operator delete(ptr: v11); /*0x14100febf*/
  }
  this->lastReportedMetric._Mypair._Myval2._Mysize = 0; /*0x14100fec4*/
  this->lastReportedMetric._Mypair._Myval2._Myres = 15; /*0x14100fecb*/
  this->lastReportedMetric._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100fed6*/
  v12 = this->requestedServerAddress._Mypair._Myval2._Myres; /*0x14100fedc*/
  if ( v12 >= 0x10 ) /*0x14100fee7*/
  {
    v13 = this->requestedServerAddress._Mypair._Myval2._Bx._Ptr; /*0x14100fee9*/
    if ( v12 + 1 >= 0x1000 ) /*0x14100fefa*/
    {
      if ( (unsigned __int64)&v13[-*((_QWORD *)v13 - 1) - 8] > 0x1F ) /*0x14100ff0f*/
        goto LABEL_59; /*0x14100ff0f*/
      v13 = *((char **)v13 - 1); /*0x14100ff15*/
    }
    operator delete(ptr: v13); /*0x14100ff18*/
  }
  this->requestedServerAddress._Mypair._Myval2._Mysize = 0; /*0x14100ff1d*/
  this->requestedServerAddress._Mypair._Myval2._Myres = 15; /*0x14100ff24*/
  this->requestedServerAddress._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100ff2f*/
  v14 = this->playSessionId._Mypair._Myval2._Myres; /*0x14100ff35*/
  if ( v14 >= 0x10 ) /*0x14100ff40*/
  {
    v15 = this->playSessionId._Mypair._Myval2._Bx._Ptr; /*0x14100ff42*/
    if ( v14 + 1 >= 0x1000 ) /*0x14100ff53*/
    {
      if ( (unsigned __int64)&v15[-*((_QWORD *)v15 - 1) - 8] > 0x1F ) /*0x14100ff68*/
        goto LABEL_59; /*0x14100ff68*/
      v15 = *((char **)v15 - 1); /*0x14100ff6e*/
    }
    operator delete(ptr: v15); /*0x14100ff71*/
  }
  this->playSessionId._Mypair._Myval2._Mysize = 0; /*0x14100ff76*/
  this->playSessionId._Mypair._Myval2._Myres = 15; /*0x14100ff7d*/
  this->playSessionId._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100ff88*/
  v16 = this->ticket._Mypair._Myval2._Myres; /*0x14100ff8e*/
  if ( v16 >= 0x10 ) /*0x14100ff99*/
  {
    v17 = this->ticket._Mypair._Myval2._Bx._Ptr; /*0x14100ff9b*/
    if ( v16 + 1 < 0x1000 ) /*0x14100ffac*/
    {
LABEL_41:
      operator delete(ptr: v17); /*0x14100ffca*/
      goto LABEL_42; /*0x14100ffca*/
    }
    if ( (unsigned __int64)&v17[-*((_QWORD *)v17 - 1) - 8] <= 0x1F ) /*0x14100ffc1*/
    {
      v17 = *((char **)v17 - 1); /*0x14100ffc7*/
      goto LABEL_41; /*0x14100ffc7*/
    }
LABEL_59:
    _invalid_parameter_noinfo_noreturn(); /*0x1410100d7*/
  }
LABEL_42:
  this->ticket._Mypair._Myval2._Mysize = 0; /*0x14100ffcf*/
  this->ticket._Mypair._Myval2._Myres = 15; /*0x14100ffd6*/
  this->ticket._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14100ffe1*/
  __wind /*0xf1c0000000000020*/
  {
    rbx::signals::connection::disconnect(this: &this->requestProfilerDataConnection.con); /*0x14100ffee*/
    p = this->requestProfilerDataConnection.con.weak_slot.p_; /*0x14100fff3*/
    if ( p != nullptr && _InterlockedExchangeAdd(&p->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x141010009*/
      operator delete(ptr: p); /*0x14101000b*/
    rbx::signals::connection::disconnect(this: &this->extAntiCheatDisconnectConnection.con); /*0x141010018*/
    v19 = this->extAntiCheatDisconnectConnection.con.weak_slot.p_; /*0x14101001d*/
    if ( v19 != nullptr && _InterlockedExchangeAdd(&v19->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x141010033*/
      operator delete(ptr: v19); /*0x141010035*/
    rbx::signals::connection::disconnect(this: &this->extAntiCheatConnectConnection.con); /*0x141010042*/
    v20 = this->extAntiCheatConnectConnection.con.weak_slot.p_; /*0x141010047*/
    if ( v20 != nullptr && _InterlockedExchangeAdd(&v20->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x14101005d*/
      operator delete(ptr: v20); /*0x14101005f*/
    rbx::signals::connection::disconnect(this: &this->closingConnection.con); /*0x14101006c*/
    v21 = this->closingConnection.con.weak_slot.p_; /*0x141010071*/
    if ( v21 != nullptr && _InterlockedExchangeAdd(&v21->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x141010085*/
      operator delete(ptr: v21); /*0x141010087*/
    this->__vftable = (RBX::Network::Client_vtbl *)RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer>::`vftable'; /*0x141010094*/
    if ( FFlag::g_flagsLoaded && FFlag::DebugTraceCreatableCounts3.value ) /*0x1410100a7*/
    {
      v22 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(); /*0x1410100a9*/
      ClassEntry = RBX::Reflection::Stat::getClassEntry(desc: &v22->desc); /*0x1410100b1*/
      RBX::Reflection::Stat::ClassEntry::destroyed(this: ClassEntry); /*0x1410100b9*/
    }
    RBX::Network::Peer::~Peer(this); /*0x1410100c1*/
  }
  __unwind
  {
    __std_terminate(a1: v24, a2: &v25); /*0x142f39fa8*/
  }
}

// Address: 0x141011070 | Name: ??_G?$DescribedCreatable@VClient@Network@RBX@@VPeer@23@@RBX@@UEAAPEAXI@Z
RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer> *__fastcall RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer>::`scalar deleting destructor'(
        RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer> *this,
        char a2)
{
  RBX::ClassRegistrar<RBX::Network::Client,1> *v4; // rax
  RBX::Reflection::Stat::ClassEntry *ClassEntry; // rax

  this->__vftable = (RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer>_vtbl *)RBX::DescribedCreatable<RBX::Network::Client,RBX::Network::Peer>::`vftable'; /*0x141011086*/
  if ( FFlag::g_flagsLoaded && FFlag::DebugTraceCreatableCounts3.value ) /*0x141011099*/
  {
    v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(); /*0x14101109b*/
    ClassEntry = RBX::Reflection::Stat::getClassEntry(desc: &v4->desc); /*0x1410110a3*/
    RBX::Reflection::Stat::ClassEntry::destroyed(this: ClassEntry); /*0x1410110ab*/
  }
  RBX::Network::Peer::~Peer(this); /*0x1410110b3*/
  if ( (a2 & 1) != 0 ) /*0x1410110bd*/
    operator delete(ptr: this); /*0x1410110c7*/
  return this; /*0x1410110cf*/
}

// Address: 0x141011290 | Name: ??_EIxpChangedListener@Client@Network@RBX@@UEAAPEAXI@Z
RBX::Network::Client::IxpChangedListener *__fastcall RBX::Network::Client::IxpChangedListener::`vector deleting destructor'(
        RBX::Network::Client::IxpChangedListener *this,
        char a2)
{
  std::_Ref_count_base *Rep; // rcx
  std::_Ref_count_base *v5; // rcx

  Rep = this->weakDm._Rep; /*0x1410112a4*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410112bc*/
    Rep->_Delete_this(this: Rep); /*0x1410112c1*/
  v5 = this->weakClient._Rep; /*0x1410112c4*/
  if ( v5 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410112d5*/
    v5->_Delete_this(this: v5); /*0x1410112da*/
  if ( (a2 & 1) != 0 ) /*0x1410112e1*/
    operator delete(ptr: this); /*0x1410112eb*/
  return this; /*0x1410112f0*/
}

// Address: 0x141011310 | Name: ?HandleConnection@Client@Network@RBX@@AEAAXPEAUPacket@RakNet@@@Z
void __fastcall RBX::Network::Client::HandleConnection(RBX::Network::Client *this, RakNet::Packet *packet)
{
  Luau::InternalErrorReporter *v4; // rdi
  std::_Func_base<void,char const *>_vtbl *v5; // rsi
  RBX::Workspace *Workspace; // rax
  std::_Ref_count_base *Rep; // rcx
  std::_Ref_count_base *v8; // rsi
  Luau::InternalErrorReporter *v9; // rax
  std::_Func_base<void,char const *>_vtbl *v10; // r8
  std::shared_ptr<RBX::Network::ClientReplicator> *v11; // rax
  RBX::Network::ClientReplicator *Ptr; // r15
  std::_Ref_count_base *v13; // r14
  std::_Ref_count_base *v14; // rsi
  Luau::InternalErrorReporter *v15; // rax
  std::_Func_base<void,char const *>_vtbl *v16; // r9
  std::_Ref_count_base *v17; // rsi
  RBX::DataModel *v18; // rsi
  const char *v19; // rdx
  void *v20; // rcx
  std::string *v21; // rax
  RBX::AvatarProfiler *v22; // rcx
  std::_Ref_count_base *v23; // rbx
  unsigned __int8 *Myfirst; // rcx
  const char *v25; // rax
  RBX::Network::ClientReplicator *v26; // rcx
  std::shared_ptr<RBX::Network::ClientReplicator> proxy; // [rsp+48h] [rbp-1F0h] BYREF
  _QWORD v28[2]; // [rsp+58h] [rbp-1E0h] BYREF
  unsigned __int64 v29; // [rsp+68h] [rbp-1D0h]
  unsigned __int64 v30; // [rsp+70h] [rbp-1C8h]
  std::shared_ptr<RBX::Security::SessionCrypto> sessionCrypto; // [rsp+80h] [rbp-1B8h] BYREF
  std::shared_ptr<RBX::Instance> v32; // [rsp+90h] [rbp-1A8h] BYREF
  RBX::Network::MegaReplicator *p_megaReplicator; // [rsp+A0h] [rbp-198h] BYREF
  std::shared_ptr<RBX::Security::SessionCrypto> v34; // [rsp+B0h] [rbp-188h] BYREF
  std::shared_ptr<std::vector<RBX::Guid> > v35; // [rsp+C0h] [rbp-178h] BYREF
  std::shared_ptr<std::vector<RBX::Guid> > v36; // [rsp+D0h] [rbp-168h] BYREF
  RBX::Network::Replicator::ReplicatorPeerInfo peerInfo; // [rsp+E0h] [rbp-158h] BYREF
  std::exception *e; // [rsp+120h] [rbp-118h] BYREF
  std::shared_ptr<RBX::Network::ClientReplicator> result; // [rsp+128h] [rbp-110h] BYREF
  RakNet::RakNetGUID v40; // [rsp+138h] [rbp-100h] BYREF
  RakNet::SystemAddress v41; // [rsp+148h] [rbp-F0h] BYREF
  _QWORD v42[4]; // [rsp+170h] [rbp-C8h] BYREF
  _QWORD v43[4]; // [rsp+190h] [rbp-A8h] BYREF
  RBX::Network::NetworkStream bitStream; // [rsp+1B0h] [rbp-88h] BYREF
  std::string v45; // [rsp+1F0h] [rbp-48h] BYREF
  char inByteArray; // [rsp+250h] [rbp+18h] BYREF
  __int64 value; // [rsp+258h] [rbp+20h]

  __wind
  {
    try
    {
      proxy = 0; /*0x141011333*/
      RBX::Network::NetworkStream::NetworkStream(this: &bitStream); /*0x141011341*/
      __wind /*0xf1c000000000008c*/
      {
        inByteArray = -110; /*0x141011347*/
        RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x141011365*/
        LODWORD(value) = RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2->storage.asRaw[0] /*0x141011375*/
                       - LODWORD(RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2);
        HIDWORD(value) = RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2->storage.asRaw[1] /*0x141011381*/
                       - LODWORD(RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2);
        RBX::Network::serializeSignedVarint64(value, stream: &bitStream); /*0x141011398*/
        v4 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410113a9*/
        v5 = v4->onInternalError._Mystorage._Ptrs[0][20].__vftable; /*0x1410113af*/
        RakNet::RakNetGUID::RakNetGUID(this: &v40); /*0x1410113be*/
        RakNet::SystemAddress::SystemAddress(this: &v41); /*0x1410113cb*/
        v40 = RakNet::UNASSIGNED_RAKNET_GUID_14; /*0x1410113d7*/
        RakNet::SystemAddress::operator=(this: &v41, input: &this->serverId); /*0x1410113fd*/
        ((void (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::NetworkStream *, __int64, __int64, _BYTE, RakNet::RakNetGUID *, _BYTE, _DWORD))v5)( /*0x141011434*/
          a1: v4,
          a2: &bitStream,
          a3: 2,
          a4: 3,
          a5: 0,
          a6: &v40,
          a7: 0,
          a8: 0);
        RBX::Network::Client::sendTicket(this); /*0x141011439*/
        RBX::Network::Client::sendPreferedSpawnName(this); /*0x141011441*/
        Workspace = RBX::Workspace::findWorkspace(context: this); /*0x141011449*/
        RBX::Workspace::clearTerrain(this: Workspace); /*0x141011451*/
        peerInfo.remotePeerId.peerId = -1; /*0x141011456*/
        RakNet::SystemAddress::SystemAddress(this: &peerInfo.remotePlayerAddress); /*0x141011469*/
        peerInfo.rakPeer._Ptr = nullptr; /*0x14101146e*/
        peerInfo.rakPeer._Rep = nullptr; /*0x141011476*/
        __wind /*0xf1c0000000000080*/
        {
          RakNet::SystemAddress::operator=(this: &peerInfo.remotePlayerAddress, input: &packet->systemAddress); /*0x141011489*/
          Rep = this->rakPeer._Rep; /*0x14101148e*/
          if ( Rep != nullptr ) /*0x141011498*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x14101149a*/
            Rep = this->rakPeer._Rep; /*0x14101149e*/
          }
          peerInfo.rakPeer._Ptr = this->rakPeer._Ptr; /*0x1410114ac*/
          v8 = peerInfo.rakPeer._Rep; /*0x1410114b4*/
          peerInfo.rakPeer._Rep = Rep; /*0x1410114bc*/
          if ( v8 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v8->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410114d8*/
          {
            v8->_Destroy(this: v8); /*0x1410114e0*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v8->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410114ec*/
              v8->_Delete_this(this: v8); /*0x1410114f4*/
          }
          peerInfo.remotePeerId.peerId = 1; /*0x1410114f7*/
          v9 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141011509*/
          v10 = v9->onInternalError._Mystorage._Ptrs[0][82].__vftable; /*0x141011511*/
          qmemcpy(v42, packet, sizeof(v42)); /*0x14101151d*/
          peerInfo.capability = ((__int64 (__fastcall *)(Luau::InternalErrorReporter *, _QWORD *))v10)(a1: v9, a2: v42); /*0x141011541*/
          p_megaReplicator = &this->megaReplicator; /*0x141011550*/
          v11 = RBX::Creatable<RBX::Instance>::create<RBX::Network::ClientReplicator,RBX::Network::Replicator::ReplicatorPeerInfo &,RBX::NetworkSettings * &,RBX::Network::MegaReplicator *>( /*0x141011577*/
                  &result,
                  <args_0>: &peerInfo,
                  <args_1>: &this->networkSettings,
                  <args_2>: &p_megaReplicator);
          Ptr = v11->_Ptr; /*0x14101157c*/
          v13 = v11->_Rep; /*0x14101157f*/
          v11->_Ptr = nullptr; /*0x141011583*/
          v11->_Rep = nullptr; /*0x141011586*/
          proxy._Ptr = Ptr; /*0x14101158a*/
          proxy._Rep = v13; /*0x14101158f*/
          v14 = result._Rep; /*0x141011594*/
          if ( result._Rep != nullptr /*0x1410115ab*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&result._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v14->_Destroy(this: v14); /*0x1410115b3*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v14->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410115bf*/
              v14->_Delete_this(this: v14); /*0x1410115c7*/
          }
          this->clientReplicator = Ptr; /*0x1410115ca*/
          v15 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410115d8*/
          v16 = v15->onInternalError._Mystorage._Ptrs[0][84].__vftable; /*0x1410115e0*/
          qmemcpy(v43, packet, sizeof(v43)); /*0x1410115ec*/
          ((void (__fastcall *)(Luau::InternalErrorReporter *, std::shared_ptr<RBX::Security::SessionCrypto> *, _QWORD *))v16)( /*0x141011615*/
            a1: v15,
            a2: &sessionCrypto,
            a3: v43);
          __wind /*0xf1c0000000000074*/
          {
            if ( sessionCrypto._Ptr != nullptr ) /*0x141011622*/
            {
              v34 = 0; /*0x141011627*/
              if ( sessionCrypto._Rep != nullptr ) /*0x14101163b*/
                _InterlockedIncrement((volatile signed __int32 *)&sessionCrypto._Rep->_Uses); /*0x14101163d*/
              v34 = sessionCrypto; /*0x141011649*/
              RBX::Network::Replicator::setSessionCrypto(this: Ptr, context: &v34); /*0x14101165d*/
            }
          }
          __unwind
          {
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&sessionCrypto); /*0xf1c000000000006c*/
          }
          v17 = sessionCrypto._Rep; /*0x141011663*/
          if ( sessionCrypto._Rep != nullptr /*0x14101167a*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&sessionCrypto._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v17->_Destroy(this: v17); /*0x141011682*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v17->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101168e*/
              v17->_Delete_this(this: v17); /*0x141011696*/
          }
          Ptr->expectedPlayerId = this->userId; /*0x1410116a0*/
          v36 = 0; /*0x1410116aa*/
          RBX::Instance::setAndLockParent(this: Ptr, instance: this, destroying: false, destroyedGuids: &v36); /*0x1410116c4*/
          v18 = RBX::DataModel::get(context: this); /*0x1410116d1*/
          v28[0] = 0; /*0x1410116d4*/
          v29 = 0; /*0x1410116d9*/
          v30 = 15; /*0x1410116de*/
          std::string::assign(this: (std::string *)v28, _Ptr: "Connected to Server", _Count: 0x13u); /*0x1410116f9*/
          __wind /*0xf1c000000000005c*/
          {
            if ( &v18->joinStageString != (std::string *)v28 ) /*0x141011717*/
            {
              v19 = (const char *)v28; /*0x141011719*/
              if ( v30 >= 0x10 ) /*0x141011724*/
                v19 = (const char *)v28[0]; /*0x141011724*/
              std::string::assign(this: &v18->joinStageString, _Ptr: v19, _Count: v29); /*0x14101172f*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)v28); /*0xf1c0000000000054*/
          }
          if ( v30 >= 0x10 ) /*0x14101173e*/
          {
            v20 = (void *)v28[0]; /*0x141011743*/
            if ( v30 + 1 >= 0x1000 ) /*0x141011752*/
            {
              v20 = *(void **)(v28[0] - 8LL); /*0x141011758*/
              if ( (unsigned __int64)(v28[0] - (_QWORD)v20 - 8LL) > 0x1F ) /*0x141011767*/
                _invalid_parameter_noinfo_noreturn(); /*0x141011769*/
            }
            operator delete(ptr: v20); /*0x141011770*/
          }
          v32 = 0; /*0x141011785*/
          if ( v13 != nullptr ) /*0x141011791*/
            _InterlockedIncrement((volatile signed __int32 *)&v13->_Uses); /*0x141011793*/
          __wind /*0xf1c0000000000044*/
          {
            v32._Ptr = Ptr; /*0x141011798*/
            v32._Rep = v13; /*0x1410117a0*/
            v21 = RBX::Network::RakNetAddressToString( /*0x1410117b9*/
                    result: &v45,
                    raknetAddress: &packet->systemAddress,
                    writePort: true,
                    portDelineator: 124);
          }
          __unwind
          {
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v32); /*0xf1c000000000003c*/
          }
          rbx::signal<void (std::string,std::shared_ptr<RBX::Instance>)>::operator()( /*0x1410117d1*/
            this: &this->connectionAcceptedSignal,
            <args_0>: v21,
            <args_1>: &v32);
          if ( DFFlag::DebugAvatarProfilerCallers.value ) /*0x1410117dd*/
            RBX::AvatarProfiler::logNetConnectionAccepted(this: v22); /*0x1410117df*/
        }
        __unwind
        {
          rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (enum RBX::MaterialType)>>,enum RBX::MaterialType>::do_dtor(this: (std::_Binder<std::_Unforced,void (__cdecl RBX::NavigationDebugDraw::*)(dtNavMesh *,RBX::Extents),std::shared_ptr<RBX::NavigationDebugDraw> &,std::_Ph<1> const &,RBX::Extents &> *)&peerInfo); /*0xf1c0000000000030*/
        }
        v23 = peerInfo.rakPeer._Rep; /*0x1410117e5*/
        if ( peerInfo.rakPeer._Rep != nullptr /*0x1410117fc*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&peerInfo.rakPeer._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v23->_Destroy(this: v23); /*0x141011804*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v23->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141011810*/
            v23->_Delete_this(this: v23); /*0x141011818*/
        }
        Myfirst = bitStream.dataVector._Mypair._Myval2._Myfirst; /*0x14101181c*/
        if ( bitStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x141011827*/
        {
          if ( (unsigned __int8 *)(bitStream.dataVector._Mypair._Myval2._Myend /*0x14101183e*/
                                 - bitStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 )
          {
            Myfirst = *((unsigned __int8 **)bitStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x141011844*/
            if ( (unsigned __int64)(bitStream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x141011853*/
              _invalid_parameter_noinfo_noreturn(); /*0x141011855*/
          }
          operator delete(ptr: Myfirst); /*0x14101185c*/
        }
      }
      __unwind
      {
        RBX::Network::NetworkStream::~NetworkStream(this: &bitStream); /*0xf1c000000000009c*/
      }
    }
    catch ( std::exception *e )
    {
      v25 = e->what(this: e); /*0x1431e5847*/
      RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "Error in ID_CONNECTION_REQUEST_ACCEPTED: %s", v25);
      v26 = proxy._Ptr; /*0x1431e585e*/
      if ( proxy._Ptr != nullptr ) /*0x1431e586a*/
      {
        proxy._Ptr->isParentLocked = false; /*0x1431e586c*/
        v35 = 0; /*0x1431e5873*/
        RBX::Instance::setParentInternal( /*0x1431e588f*/
          this: v26,
          newParent: nullptr,
          ignoreLock: false,
          destroying: false,
          destroyedGuids: &v35);
      }
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&proxy); /*0xf1c0000000000024*/
  }
  if ( proxy._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&proxy._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14101187d*/
  {
    proxy._Rep->_Destroy(this: proxy._Rep); /*0x14101188a*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&proxy._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141011894*/
      proxy._Rep->_Delete_this(this: proxy._Rep); /*0x14101189e*/
  }
}

// Address: 0x1410118c0 | Name: ?OnClosedConnection@Client@Network@RBX@@QEAAXAEBUSystemAddress@RakNet@@@Z
void __fastcall RBX::Network::Client::OnClosedConnection(
        RBX::Network::Client *this,
        RakNet::SystemAddress *systemAddress)
{
  char addressBuffer[1048]; // [rsp+30h] [rbp-418h] BYREF

  RakNet::SystemAddress::ToStringN( /*0x1410118e4*/
    this: systemAddress,
    writePort: true,
    dest: addressBuffer,
    size: 1025,
    portDelineator: 124);
  RBX::Network::Client::updateServerConnectionState( /*0x141011903*/
    this,
    serverAddress: addressBuffer,
    state: ConnectionState_Closed,
    metric: pass,
    takeLock: true);
}

// Address: 0x141011920 | Name: ?OnConnectFirstStageTimeout@Client@Network@RBX@@UEAAXAEBUSystemAddress@RakNet@@@Z
void __fastcall RBX::Network::Client::OnConnectFirstStageTimeout(
        RBX::Network::Client *this,
        RakNet::SystemAddress *systemAddress)
{
  std::_List_node<std::pair<std::string const ,std::string >,void *> *v3; // rax
  char *v4; // rax
  std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *v5; // rax
  char *Ptr; // rcx
  std::_List_node<std::pair<std::string const ,std::string >,void *> *v7; // rax
  const char *v8; // rdx
  char *Myfirst; // rcx
  std::_List_node<std::pair<std::string const ,std::string >,void *> *Myhead; // rcx
  std::_List_node<std::pair<std::string const ,std::string >,void *> *Next; // rdi
  std::_List_node<std::pair<std::string const ,std::string >,void *> *v12; // rbx
  std::string _Keyval_arg; // [rsp+30h] [rbp-D0h] BYREF
  std::unordered_map<std::string,std::string> eventArgs; // [rsp+50h] [rbp-B0h] BYREF
  std::string result; // [rsp+90h] [rbp-70h] BYREF
  std::string v16; // [rsp+B0h] [rbp-50h] BYREF
  std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::string > >,0> > v17; // [rsp+D0h] [rbp-30h] BYREF
  char addressBuffer[1040]; // [rsp+110h] [rbp+10h] BYREF

  RakNet::SystemAddress::ToStringN( /*0x141011954*/
    this: systemAddress,
    writePort: true,
    dest: addressBuffer,
    size: 1025,
    portDelineator: 124);
  eventArgs._Traitsobj._Mypair._Myval2._Myval2 = 0.0; /*0x14101195c*/
  eventArgs._List._Mypair._Myval2._Mysize = 0; /*0x141011969*/
  v3 = (std::_List_node<std::pair<std::string const ,std::string >,void *> *)operator new(size: 0x50u); /*0x141011971*/
  v3->_Next = v3; /*0x141011976*/
  v3->_Prev = v3; /*0x141011979*/
  eventArgs._List._Mypair._Myval2._Myhead = v3; /*0x14101197d*/
  __wind /*0xf1c00000000000c4*/
  {
    memset(&eventArgs._Vec, 0, sizeof(eventArgs._Vec)); /*0x141011982*/
    eventArgs._Mask = 7; /*0x141011990*/
    eventArgs._Maxidx = 8; /*0x141011998*/
    eventArgs._Traitsobj._Mypair._Myval2._Myval2 = 1.0; /*0x1410119a8*/
    __wind /*0xf1c0000000000094*/
    {
      std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::shared_ptr<RBX::Graphics::Shader>>>>>>>::_Assign_grow( /*0x1410119b9*/
        this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > > > > *)&eventArgs._Vec,
        _Cells: 0x10u,
        _Val: (const std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > >)v3);
      _Keyval_arg._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410119bf*/
      _Keyval_arg._Mypair._Myval2._Mysize = 0; /*0x1410119c4*/
      _Keyval_arg._Mypair._Myval2._Myres = 15; /*0x1410119c9*/
    }
    __unwind
    {
      std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&eventArgs._Vec); /*0x143156eab*/
    }
  }
  __unwind
  {
    std::list<std::pair<std::string const,std::string>>::~list<std::pair<std::string const,std::string>>(this: (std::list<std::pair<std::string,std::string >> *)&eventArgs._List); /*0x143156e9b*/
  }
  __wind /*0xf1c00000000000b8*/
  {
    v4 = (char *)operator new(size: 0x20u); /*0x1410119da*/
    _Keyval_arg._Mypair._Myval2._Mysize = 21; /*0x1410119df*/
    _Keyval_arg._Mypair._Myval2._Myres = 31; /*0x1410119e8*/
    strcpy(v4, "gameJoinFailureReason"); /*0x1410119f8*/
    _Keyval_arg._Mypair._Myval2._Bx._Ptr = v4; /*0x141011a12*/
    __wind /*0xf1c0000000000088*/
    {
      v5 = std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Try_emplace<std::string,>( /*0x141011a25*/
             this: &eventArgs,
             (std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *)&result,
             &_Keyval_arg);
      std::string::assign(this: &v5->first->_Myval.second, _Ptr: "ConnectTimeOut", _Count: 0xEu); /*0x141011a3c*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&_Keyval_arg); /*0xf1c0000000000080*/
    }
    if ( _Keyval_arg._Mypair._Myval2._Myres >= 0x10 ) /*0x141011a4b*/
    {
      Ptr = _Keyval_arg._Mypair._Myval2._Bx._Ptr; /*0x141011a50*/
      if ( _Keyval_arg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141011a5f*/
      {
        Ptr = *((char **)_Keyval_arg._Mypair._Myval2._Bx._Ptr - 1); /*0x141011a65*/
        if ( (unsigned __int64)(_Keyval_arg._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141011a74*/
          _invalid_parameter_noinfo_noreturn(); /*0x141011a76*/
      }
      operator delete(ptr: Ptr); /*0x141011a7d*/
    }
    v17._Traitsobj._Mypair._Myval2._Myval2 = eventArgs._Traitsobj._Mypair._Myval2._Myval2; /*0x141011a91*/
    v17._List._Mypair._Myval2._Myhead = nullptr; /*0x141011a94*/
    v17._List._Mypair._Myval2._Mysize = 0; /*0x141011a98*/
    v7 = (std::_List_node<std::pair<std::string const ,std::string >,void *> *)operator new(size: 0x50u); /*0x141011aa1*/
    v7->_Next = v7; /*0x141011aa6*/
    v7->_Prev = v7; /*0x141011aa9*/
    v17._List._Mypair._Myval2._Myhead = v7; /*0x141011aad*/
    __wind /*0xf1c0000000000070*/
    {
      memset(&v17._Vec, 0, sizeof(v17._Vec)); /*0x141011ab4*/
      v17._Mask = eventArgs._Mask; /*0x141011ac1*/
      v17._Maxidx = eventArgs._Maxidx; /*0x141011ac9*/
      __wind /*0xf1c0000000000040*/
      {
        std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::shared_ptr<RBX::Graphics::Shader>>>>>>>::_Assign_grow( /*0x141011ae2*/
          this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > > > > *)&v17._Vec,
          _Cells: eventArgs._Vec._Mypair._Myval2._Mylast - eventArgs._Vec._Mypair._Myval2._Myfirst,
          _Val: (const std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > >)v7);
        std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::insert<std::_List_unchecked_const_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::string>>>,std::_Iterator_base0>>( /*0x141011af3*/
          this: &v17,
          _First: (std::_List_unchecked_const_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::string > > >,std::_Iterator_base0>)eventArgs._List._Mypair._Myval2._Myhead->_Next,
          _Last: (std::_List_unchecked_const_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::string > > >,std::_Iterator_base0>)eventArgs._List._Mypair._Myval2._Myhead);
      }
      __unwind
      {
        std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&v17._Vec); /*0x1431e58eb*/
      }
    }
    __unwind
    {
      std::list<std::pair<std::string const,std::string>>::~list<std::pair<std::string const,std::string>>(this: (std::list<std::pair<std::string,std::string >> *)&v17._List); /*0x1431e58db*/
    }
    __wind /*0xf1c0000000000064*/
    {
      _Keyval_arg._Mypair._Myval2._Myres = 15; /*0x141011b05*/
      _Keyval_arg._Mypair._Myval2._Mysize = 15; /*0x141011b0e*/
      qmemcpy(&_Keyval_arg, "GameJoinFailur", 14); /*0x141011b1f*/
      *(_WORD *)&_Keyval_arg._Mypair._Myval2._Bx._Alias[14] = (unsigned __int8)aGamejoinfailur_0[14]; /*0x141011b42*/
      result._Mypair._Myval2._Myres = 15; /*0x141011b5a*/
      result._Mypair._Myval2._Mysize = 6; /*0x141011b62*/
      *(_DWORD *)result._Mypair._Myval2._Bx._Buf = *(_DWORD *)"report"; /*0x141011b70*/
      *(_DWORD *)&result._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"rt"; /*0x141011b7a*/
      v16._Mypair._Myval2._Myres = 15; /*0x141011b86*/
      v16._Mypair._Myval2._Mysize = 6; /*0x141011b8e*/
      *(_DWORD *)v16._Mypair._Myval2._Bx._Buf = *(_DWORD *)"client"; /*0x141011b9c*/
      *(_DWORD *)&v16._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"nt"; /*0x141011ba6*/
    }
    __unwind
    {
      std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &result); /*0xf1c0000000000038*/
    }
    RBX::Analytics::EventIngest::setRBXEvent( /*0x141011bbf*/
      target: &v16,
      eventContext: &result,
      eventName: &_Keyval_arg,
      additionalArgs: (std::unordered_map<std::string,std::string> *)&v17);
    if ( this->receivedOpenConnectionReply1 ) /*0x141011bdb*/
    {
      v8 = "ConnectFailed_Timeout_FirstReplyOnly"; /*0x141011c06*/
      if ( this->receivedOpenConnectionReply2 ) /*0x141011bff*/
        v8 = "ConnectFailed_Timeout_FirstAndSecondReplied"; /*0x141011c0f*/
    }
    else if ( this->receivedOpenConnectionReply2 ) /*0x141011be4*/
    {
      v8 = "ConnectFailed_Timeout_SecondReplyOnly"; /*0x141011bf6*/
    }
    else
    {
      v8 = "ConnectFailed_Timeout_NoReplies"; /*0x141011bed*/
    }
    RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x141011c16*/
      this,
      metric: v8,
      connectionFailed: true,
      serverAddress: addressBuffer,
      state: ConnectionState_Failed,
      takeLock: true);
  }
  __unwind
  {
    std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &eventArgs); /*0xf1c000000000002c*/
  }
  Myfirst = (char *)eventArgs._Vec._Mypair._Myval2._Myfirst; /*0x141011c21*/
  if ( (((char *)eventArgs._Vec._Mypair._Myval2._Mylast - (char *)eventArgs._Vec._Mypair._Myval2._Myfirst) /*0x141011c37*/
      & 0xFFFFFFFFFFFFFFF8uLL) >= 0x1000 )
  {
    Myfirst = (char *)eventArgs._Vec._Mypair._Myval2._Myfirst[-1]._Ptr; /*0x141011c3d*/
    if ( (unsigned __int64)((char *)eventArgs._Vec._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x141011c4c*/
      _invalid_parameter_noinfo_noreturn(); /*0x141011c4e*/
  }
  operator delete(ptr: Myfirst); /*0x141011c55*/
  memset(&eventArgs._Vec, 0, sizeof(eventArgs._Vec)); /*0x141011c5a*/
  Myhead = eventArgs._List._Mypair._Myval2._Myhead; /*0x141011c68*/
  eventArgs._List._Mypair._Myval2._Myhead->_Prev->_Next = nullptr; /*0x141011c71*/
  Next = Myhead->_Next; /*0x141011c74*/
  if ( Myhead->_Next != nullptr ) /*0x141011c7a*/
  {
    do /*0x141011c9f*/
    {
      v12 = Next->_Next; /*0x141011c80*/
      std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>(this: (ScopedFlagOverrider::FlagItem *)&Next->_Myval); /*0x141011c87*/
      operator delete(ptr: Next); /*0x141011c94*/
      Next = v12; /*0x141011c99*/
    }
    while ( v12 != nullptr ); /*0x141011c9f*/
  }
  operator delete(ptr: eventArgs._List._Mypair._Myval2._Myhead); /*0x141011cab*/
}

// Address: 0x141011cd0 | Name: ?OnFailedConnectionAttempt@Client@Network@RBX@@QEAAXPEAUPacket@RakNet@@W4PI2_FailedConnectionAttemptReason@23@@Z
void __fastcall RBX::Network::Client::OnFailedConnectionAttempt(
        RBX::Network::Client *this,
        RakNet::Packet *packet,
        RBX::Network::PI2_FailedConnectionAttemptReason failedConnectionAttemptReason)
{
  __int64 v3; // rdi
  int v6; // r8d
  char *v7; // rbx
  unsigned __int64 v8; // r14
  char *v9; // rax
  const char *v10; // r9
  std::string *p_message; // rdi
  std::string *Ptr; // rax
  char *v13; // rcx
  std::string *v14; // rax
  std::string *v15; // rax
  rbx::signal<void __cdecl(std::string,int,std::string)> *p_connectionFailedSignal; // r15
  unsigned __int64 Mysize; // rsi
  std::string *v18; // rdi
  void *v19; // rax
  int v20; // ebx
  std::string *v21; // rax
  char *v22; // rcx
  std::string message; // [rsp+30h] [rbp-D0h] BYREF
  std::string result; // [rsp+50h] [rbp-B0h] BYREF
  std::string v25; // [rsp+70h] [rbp-90h] BYREF
  char addressBuffer[1040]; // [rsp+90h] [rbp-70h] BYREF

  v3 = failedConnectionAttemptReason; /*0x141011cf1*/
  v6 = *packet->data; /*0x141011cfe*/
  v7 = nullptr; /*0x141011d05*/
  v8 = 15; /*0x141011d07*/
  switch ( v6 ) /*0x141011d0f*/
  {
    case 17: /*0x141011d0f*/
      message._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141011e31*/
      v9 = (char *)operator new(size: 0x20u); /*0x141011e49*/
      message._Mypair._Myval2._Mysize = 26; /*0x141011e4e*/
      message._Mypair._Myval2._Myres = 31; /*0x141011e57*/
      strcpy(v9, "Connection attempt failed."); /*0x141011e67*/
      break;
    case 24: /*0x141011d0f*/
    case 148: /*0x141011d0f*/
      message._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141011dbc*/
      v9 = (char *)operator new(size: 0x40u); /*0x141011dd4*/
      message._Mypair._Myval2._Mysize = 62; /*0x141011dd9*/
      message._Mypair._Myval2._Myres = 63; /*0x141011de2*/
      strcpy(v9, "Roblox version is out of date. Please uninstall and try again."); /*0x141011df2*/
      break;
    case 149: /*0x141011d0f*/
      message._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141011d45*/
      v9 = (char *)operator new(size: 0x50u); /*0x141011d5d*/
      message._Mypair._Myval2._Mysize = 67; /*0x141011d62*/
      message._Mypair._Myval2._Myres = 79; /*0x141011d6b*/
      strcpy(v9, "Version not compatible with server. Please uninstall and try again."); /*0x141011d7b*/
      break;
    default:
      RBX::format(result: (RBX::Graphics::ProfilerAdorn::Item *)&message, fmt: "Network error %d", v6); /*0x141011d3b*/
      goto LABEL_90; /*0x141011d40*/
  }
  message._Mypair._Myval2._Bx._Ptr = v9; /*0x141011e85*/
LABEL_90:
  __wind /*0xf1c0000000000070*/
  {
    RakNet::SystemAddress::ToStringN( /*0x141011e9e*/
      this: &packet->systemAddress,
      writePort: true,
      dest: addressBuffer,
      size: 1025,
      portDelineator: 124);
    switch ( v3 ) /*0x141011eb9*/
    {
      case 0LL: /*0x141011eb9*/
        v10 = "Error_ConnectionAttemptFailed"; /*0x141011ebb*/
        break; /*0x141011ec2*/
      case 1LL: /*0x141011eb9*/
        v10 = "Error_AlreadyConnected"; /*0x141011ec4*/
        break; /*0x141011ecb*/
      case 2LL: /*0x141011eb9*/
        v10 = "Error_NoFreeIncomingConnections"; /*0x141011ecd*/
        break; /*0x141011ed4*/
      case 3LL: /*0x141011eb9*/
        v10 = "Error_SecurityPublicKeyMismatch"; /*0x141011ed6*/
        break; /*0x141011edd*/
      case 4LL: /*0x141011eb9*/
        v10 = "Error_ConnectionBanned"; /*0x141011edf*/
        break; /*0x141011ee6*/
      case 5LL: /*0x141011eb9*/
        v10 = "Error_InvalidPassword"; /*0x141011ee8*/
        break; /*0x141011eef*/
      case 6LL: /*0x141011eb9*/
        v10 = "Error_IncompatibleProtocol"; /*0x141011ef1*/
        break; /*0x141011ef8*/
      case 7LL: /*0x141011eb9*/
        v10 = "Error_IpRecentlyConnected"; /*0x141011efa*/
        break; /*0x141011f01*/
      case 8LL: /*0x141011eb9*/
        v10 = "Error_RemoteSystemRequiresPubcKey"; /*0x141011f03*/
        break; /*0x141011f0a*/
      case 9LL: /*0x141011eb9*/
        v10 = "Error_OurSystemRequiresSecurity"; /*0x141011f0c*/
        break; /*0x141011f13*/
      case 10LL: /*0x141011eb9*/
        v10 = "Error_PublicKeyMismatch"; /*0x141011f15*/
        break; /*0x141011f1c*/
      default:
        v10 = "Error_Unknown"; /*0x141011f1e*/
        break; /*0x141011f1e*/
    }
    RBX::Network::Client::updateServerConnectionState( /*0x141011f37*/
      this,
      serverAddress: addressBuffer,
      state: ConnectionState_Failed,
      metric: v10,
      takeLock: true);
    if ( RBX::Network::Client::noViableConnectionsLeft(this) ) /*0x141011f3f*/
    {
      p_message = &message; /*0x141011f4c*/
      if ( DFFlag::BetterHandshakeLogs.value ) /*0x141011f66*/
      {
        if ( this->receivedOpenConnectionReply1 ) /*0x141011f6c*/
        {
          if ( message._Mypair._Myval2._Myres >= 0x10 ) /*0x141011f7b*/
            p_message = (std::string *)message._Mypair._Myval2._Bx._Ptr; /*0x141011f7b*/
          Ptr = RBX::Network::RakNetAddressToString( /*0x141011f81*/
                  &result,
                  raknetAddress: &packet->systemAddress,
                  writePort: true,
                  portDelineator: 124);
          __eh34_enter_wind_state(0, 1); /*0xf1c0000000000068*/
          if ( Ptr->_Mypair._Myval2._Myres >= 0x10 ) /*0x141011f8c*/
            Ptr = (std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x141011f8e*/
          RBX::StandardOut::printf( /*0x141011fa3*/
            type: MESSAGE_SENSITIVE,
            format: "Server reached at %s, but handshake failed. %s\n",
            Ptr->_Mypair._Myval2._Bx._Buf,
            p_message->_Mypair._Myval2._Bx._Buf);
          if ( __eh34_unwind(1) ) /*0xf1c000000000005c*/
            goto unwind_state_1; /*0xf1c000000000005c*/
          __eh34_exit_wind_state(1, 0); /*0xf1c0000000000060*/
          if ( result._Mypair._Myval2._Myres < 0x10 ) /*0x141011fb2*/
            goto LABEL_54; /*0x141011fb2*/
          v13 = result._Mypair._Myval2._Bx._Ptr; /*0x141011fbb*/
          if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141011fca*/
          {
            v13 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x141011fd4*/
            if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v13 - 8) > 0x1F ) /*0x141011fe3*/
              _invalid_parameter_noinfo_noreturn(); /*0x141011fe9*/
          }
        }
        else
        {
          if ( message._Mypair._Myval2._Myres >= 0x10 ) /*0x141011ff6*/
            p_message = (std::string *)message._Mypair._Myval2._Bx._Ptr; /*0x141011ff6*/
          v14 = RBX::Network::RakNetAddressToString( /*0x141011ffc*/
                  &result,
                  raknetAddress: &packet->systemAddress,
                  writePort: true,
                  portDelineator: 124);
          __eh34_enter_wind_state(0, 1); /*0xf1c0000000000054*/
          if ( v14->_Mypair._Myval2._Myres >= 0x10 ) /*0x141012007*/
            v14 = (std::string *)v14->_Mypair._Myval2._Bx._Ptr; /*0x141012009*/
          RBX::StandardOut::printf( /*0x14101201e*/
            type: MESSAGE_SENSITIVE,
            format: "Failed to connect to %s; no response. %s\n",
            v14->_Mypair._Myval2._Bx._Buf,
            p_message->_Mypair._Myval2._Bx._Buf);
          if ( __eh34_unwind(1) ) /*0xf1c0000000000048*/
            goto unwind_state_1; /*0xf1c0000000000048*/
          __eh34_exit_wind_state(1, 0); /*0xf1c000000000004c*/
          if ( result._Mypair._Myval2._Myres < 0x10 ) /*0x14101202d*/
            goto LABEL_54; /*0x14101202d*/
          v13 = result._Mypair._Myval2._Bx._Ptr; /*0x141012036*/
          if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141012045*/
          {
            v13 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14101204f*/
            if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v13 - 8) > 0x1F ) /*0x14101205e*/
              _invalid_parameter_noinfo_noreturn(); /*0x141012060*/
          }
        }
      }
      else
      {
        if ( message._Mypair._Myval2._Myres >= 0x10 ) /*0x14101206d*/
          p_message = (std::string *)message._Mypair._Myval2._Bx._Ptr; /*0x14101206d*/
        v15 = RBX::Network::RakNetAddressToString( /*0x141012073*/
                &result,
                raknetAddress: &packet->systemAddress,
                writePort: true,
                portDelineator: 124);
        __eh34_enter_wind_state(0, 1); /*0xf1c0000000000040*/
        if ( v15->_Mypair._Myval2._Myres >= 0x10 ) /*0x14101207e*/
          v15 = (std::string *)v15->_Mypair._Myval2._Bx._Ptr; /*0x141012080*/
        RBX::StandardOut::printf( /*0x141012095*/
          type: MESSAGE_SENSITIVE,
          format: "Failed to connect to %s. %s\n",
          v15->_Mypair._Myval2._Bx._Buf,
          p_message->_Mypair._Myval2._Bx._Buf);
        if ( __eh34_unwind(1) ) /*0xf1c000000000002c*/
        {
unwind_state_1:
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000030*/
          __eh34_continue_unwinding(1, 0); /*0xf1c0000000000034*/
        }
        __eh34_exit_wind_state(1, 0); /*0xf1c0000000000038*/
        if ( result._Mypair._Myval2._Myres < 0x10 ) /*0x1410120a4*/
          goto LABEL_54; /*0x1410120a4*/
        v13 = result._Mypair._Myval2._Bx._Ptr; /*0x1410120a9*/
        if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410120b8*/
        {
          v13 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x1410120be*/
          if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v13 - 8) > 0x1F ) /*0x1410120cd*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410120cf*/
        }
      }
      operator delete(ptr: v13); /*0x1410120d6*/
LABEL_54:
      p_connectionFailedSignal = &this->connectionFailedSignal; /*0x1410120db*/
      result._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410120ee*/
      result._Mypair._Myval2._Mysize = 0; /*0x1410120f3*/
      result._Mypair._Myval2._Myres = 0; /*0x1410120f8*/
      Mysize = message._Mypair._Myval2._Mysize; /*0x1410120fd*/
      v18 = &message; /*0x141012102*/
      if ( message._Mypair._Myval2._Myres >= 0x10 ) /*0x14101210d*/
        v18 = (std::string *)message._Mypair._Myval2._Bx._Ptr; /*0x14101210d*/
      if ( message._Mypair._Myval2._Mysize >= 0x10 ) /*0x141012117*/
      {
        v8 = message._Mypair._Myval2._Mysize | 0xF; /*0x141012126*/
        if ( (message._Mypair._Myval2._Mysize | 0xF) > 0x7FFFFFFFFFFFFFFFLL ) /*0x141012137*/
          v8 = 0x7FFFFFFFFFFFFFFFLL; /*0x141012137*/
        if ( v8 + 1 < 0x1000 ) /*0x141012146*/
        {
          if ( v8 != -1 ) /*0x14101217a*/
            v7 = (char *)operator new(size: v8 + 1); /*0x141012181*/
        }
        else
        {
          if ( v8 + 40 < v8 + 1 ) /*0x14101214f*/
            std::_Throw_bad_array_new_length(); /*0x14101222d*/
          v19 = operator new(size: v8 + 40); /*0x141012158*/
          if ( v19 == nullptr ) /*0x141012160*/
            _invalid_parameter_noinfo_noreturn(); /*0x141012170*/
          v7 = (char *)(((unsigned __int64)v19 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x141012166*/
          *((_QWORD *)v7 - 1) = v19; /*0x14101216a*/
        }
        result._Mypair._Myval2._Bx._Ptr = v7; /*0x141012184*/
        memcpy_0(a1: v7, Src: v18, Size: Mysize + 1); /*0x141012193*/
      }
      else
      {
        result._Mypair._Myval2._Bx = v18->_Mypair._Myval2._Bx; /*0x14101211c*/
      }
      result._Mypair._Myval2._Mysize = Mysize; /*0x141012198*/
      result._Mypair._Myval2._Myres = v8; /*0x14101219d*/
      __wind /*0xf1c0000000000020*/
      {
        v20 = *packet->data; /*0x1410121a6*/
        v21 = RBX::Network::RakNetAddressToString( /*0x1410121b7*/
                result: &v25,
                raknetAddress: &packet->systemAddress,
                writePort: true,
                portDelineator: 124);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000018*/
      }
      rbx::signal<void (std::string,int,std::string)>::operator()( /*0x1410121cb*/
        this: p_connectionFailedSignal,
        <args_0>: v21,
        <args_1>: v20,
        <args_2>: &result);
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&message); /*0xf1c000000000000c*/
  }
  if ( message._Mypair._Myval2._Myres >= 0x10 ) /*0x1410121da*/
  {
    v22 = message._Mypair._Myval2._Bx._Ptr; /*0x1410121df*/
    if ( message._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410121ee*/
    {
      v22 = *((char **)message._Mypair._Myval2._Bx._Ptr - 1); /*0x1410121f4*/
      if ( (unsigned __int64)(message._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x141012203*/
        _invalid_parameter_noinfo_noreturn(); /*0x141012205*/
    }
    operator delete(ptr: v22); /*0x14101220c*/
  }
}

// Address: 0x141012260 | Name: ?OnFailedToIncludeRemoteSystemInRemoteSystemList@Client@Network@RBX@@UEAAXAEBUSystemAddress@RakNet@@@Z
void __fastcall RBX::Network::Client::OnFailedToIncludeRemoteSystemInRemoteSystemList(
        RBX::Network::Client *this,
        RakNet::SystemAddress *systemAddress)
{
  char addressBuffer[1048]; // [rsp+30h] [rbp-418h] BYREF

  RakNet::SystemAddress::ToStringN( /*0x141012284*/
    this: systemAddress,
    writePort: true,
    dest: addressBuffer,
    size: 1025,
    portDelineator: 124);
  RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1410122a8*/
    this,
    metric: "ConnectFailed_InternalRakNet",
    connectionFailed: true,
    serverAddress: addressBuffer,
    state: ConnectionState_Failed,
    takeLock: true);
}

// Address: 0x1410122c0 | Name: ?OnNewConnection@Client@Network@RBX@@QEAAXPEAUPacket@RakNet@@AEBUSystemAddress@5@@Z
void __fastcall RBX::Network::Client::OnNewConnection(
        RBX::Network::Client *this,
        RakNet::Packet *packet,
        const RakNet::SystemAddress *systemAddress)
{
  __int64 userId; // rcx
  std::unordered_set<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<std::string,std::string > > > *v6; // rbx
  std::unordered_map<std::string,std::string> *v7; // r9
  RBX::DataModel *v8; // rbx
  long double v9; // xmm0_8
  std::string *Ptr; // rax
  char *v11; // rcx
  RBX::Graphics::ProfilerAdorn::Item v12; // [rsp+38h] [rbp-D0h] BYREF
  __int64 v13; // [rsp+70h] [rbp-98h]
  std::string v14; // [rsp+78h] [rbp-90h] BYREF
  std::unordered_set<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<std::string,std::string > > > v15; // [rsp+98h] [rbp-70h] BYREF
  char v16[1056]; // [rsp+D8h] [rbp-30h] BYREF
  RBX::Time result; // [rsp+518h] [rbp+410h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *v18; // [rsp+520h] [rbp+418h]

  if ( DFLog::ClientRecvFromRaknet != 0 ) /*0x1410122f0*/
    FLog::FastLog( /*0x1410122fc*/
      level: DFLog::ClientRecvFromRaknet,
      message: "[DFLog::ClientRecvFromRaknet] Client received ID_CONNECTION_REQUEST_ACCEPTED successfully",
      arg0: nullptr);
  RakNet::SystemAddress::ToStringN( /*0x141012315*/
    this: &packet->systemAddress,
    writePort: true,
    dest: v16,
    size: 1025,
    portDelineator: 124);
  RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x141012338*/
    this,
    metric: "RakNetPasswordAccepted",
    connectionFailed: false,
    serverAddress: v16,
    state: ConnectionState_Connected,
    takeLock: true);
  this->reportingJoinState = JoinState_RakNetPasswordAccepted; /*0x14101233d*/
  userId = this->userId; /*0x141012347*/
  if ( userId > 0 && userId % 1000 < DFInt::ClientJoinProcessPositiveSamplesThousandths ) /*0x141012386*/
  {
    *(RBX::Time *)&result.sec = (RBX::Time)&v15; /*0x141012390*/
    v6 = std::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>(this: &v15); /*0x1410123a0*/
    __wind /*0xf1c0000000000040*/
    {
      v18 = &v12; /*0x1410123a8*/
      v12.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410123b2*/
      v12.text._Mypair._Myval2._Mysize = 0; /*0x1410123b7*/
      v12.text._Mypair._Myval2._Myres = 15; /*0x1410123bc*/
      std::string::assign(this: &v12.text, _Ptr: "GameServerConnectSuccess", _Count: 0x18u); /*0x1410123d5*/
      __wind /*0xf1c000000000001c*/
      {
        *(RBX::Time *)&result.sec = (RBX::Time)&v12.x; /*0x1410123e0*/
        v13 = 15; /*0x1410123ec*/
        *(_QWORD *)&v12.color = 6; /*0x1410123f5*/
        v12.x = *(_DWORD *)"report"; /*0x141012404*/
        v12.y = *(unsigned __int16 *)"rt"; /*0x14101240f*/
        v14._Mypair._Myval2._Myres = 15; /*0x14101241e*/
        v14._Mypair._Myval2._Mysize = 6; /*0x141012426*/
        *(_DWORD *)v14._Mypair._Myval2._Bx._Buf = *(_DWORD *)"client"; /*0x141012434*/
        *(_DWORD *)&v14._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"nt"; /*0x14101243f*/
        v7 = (std::unordered_map<std::string,std::string> *)v6; /*0x141012449*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: v18); /*0xf1c000000000002c*/
      }
    }
    __unwind
    {
      std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: (void *)result.sec); /*0xf1c0000000000038*/
    }
    RBX::Analytics::EventIngest::setRBXEvent( /*0x14101245b*/
      target: &v14,
      eventContext: (std::string *)&v12.x,
      eventName: &v12.text,
      additionalArgs: v7);
  }
  v8 = RBX::DataModel::get(context: this); /*0x141012468*/
  v9 = RBX::Time::nowFast(&result)->sec - v8->joinData.clientStartTime.sec; /*0x14101247b*/
  RBX::DataModel::get(context: this)->joinData.raknetPassweordAcceptedTime = v9; /*0x14101248f*/
  if ( FLog::Output != 0 ) /*0x14101249e*/
  {
    Ptr = RBX::Network::RakNetAddressToString( /*0x1410124ae*/
            result: &v12.text,
            raknetAddress: &packet->systemAddress,
            writePort: true,
            portDelineator: 124);
    __wind /*0xf1c0000000000010*/
    {
      if ( Ptr->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410124b9*/
        Ptr = (std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x1410124bb*/
      FLog::FastLogFormatted( /*0x1410124cf*/
        level: FLog::Output,
        message: "[FLog::Output] Connection accepted from %s",
        Ptr->_Mypair._Myval2._Bx._Buf);
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v12); /*0xf1c0000000000008*/
    }
    if ( v12.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410124de*/
    {
      v11 = v12.text._Mypair._Myval2._Bx._Ptr; /*0x1410124e3*/
      if ( v12.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410124f2*/
      {
        v11 = *((char **)v12.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410124f8*/
        if ( (unsigned __int64)(v12.text._Mypair._Myval2._Bx._Ptr - v11 - 8) > 0x1F ) /*0x141012507*/
          _invalid_parameter_noinfo_noreturn(); /*0x141012509*/
      }
      operator delete(ptr: v11); /*0x141012510*/
    }
  }
  RakNet::SystemAddress::operator=(this: &this->serverId, input: &packet->systemAddress); /*0x14101251f*/
  RBX::Network::Client::sendVersionInfo(this); /*0x141012527*/
  RBX::Network::Client::HandleConnection(this, packet); /*0x141012532*/
}

// Address: 0x141012560 | Name: ?OnReceive@Client@Network@RBX@@UEAA?AW4PeerReceiveResult@RakNet@@PEAUPacket@5@@Z
__int64 __fastcall RBX::Network::Client::OnReceive(RBX::Network::Client *this, RakNet::Packet *packet)
{
  unsigned int v4; // ebx
  RBX::Network::PI2_FailedConnectionAttemptReason v5; // r8d
  unsigned int v6; // r12d
  std::string *Ptr; // rax
  char *v8; // rcx
  rbx::signal<void __cdecl(std::string,int,std::string)> *p_connectionFailedSignal; // r14
  std::string *v10; // rsi
  std::string *v11; // rcx
  const char *v12; // rdi
  int v13; // edi
  std::string *v14; // rax
  RBX::Network::ClientReplicator *clientReplicator; // rcx
  char *v16; // rcx
  __int64 v17; // rcx
  __int64 v19; // [rsp+0h] [rbp-100h] BYREF
  std::string v20; // [rsp+30h] [rbp-D0h] BYREF
  std::string metric; // [rsp+50h] [rbp-B0h] BYREF
  std::string v22; // [rsp+70h] [rbp-90h] BYREF
  char addressBuffer[1088]; // [rsp+90h] [rbp-70h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *subtype; // [rsp+4E8h] [rbp+3E8h] BYREF
  unsigned int sequenceNumber; // [rsp+4F0h] [rbp+3F0h] BYREF
  RBX::Memory::Scope memscopeNetworkReplicator; // [rsp+4F8h] [rbp+3F8h] BYREF

  v4 = RBX::Memory::setCurrentCategory(category: RBX::Memory::NetworkReplicator); /*0x14101258b*/
  memscopeNetworkReplicator.parent = v4; /*0x14101258d*/
  __wind /*0xf1c00000000000ac*/
  {
    switch ( *packet->data ) /*0x1410125bd*/
    {
      case 0xAu: /*0x1410125bd*/
        v5 = FCAR_REMOTE_SYSTEM_REQUIRES_PUBLIC_KEY; /*0x1410125fe*/
        goto LABEL_17; /*0x141012604*/
      case 0xBu: /*0x1410125bd*/
        v5 = FCAR_OUR_SYSTEM_REQUIRES_SECURITY; /*0x141012606*/
        goto LABEL_17; /*0x14101260c*/
      case 0xCu: /*0x1410125bd*/
        v5 = FCAR_PUBLIC_KEY_MISMATCH; /*0x14101260e*/
        goto LABEL_17; /*0x141012614*/
      case 0x10u: /*0x1410125bd*/
        if ( DFLog::ClientRecvFromRaknet != 0 ) /*0x1410125d8*/
          FLog::FastLog( /*0x1410125e4*/
            level: DFLog::ClientRecvFromRaknet,
            message: "[DFLog::ClientRecvFromRaknet] RakPeer received ID_CONNECTION_REQUEST_ACCEPTED packet, calling OnNewConnectio"
            "n callback of plugin",
            arg0: nullptr);
        RBX::Network::Client::OnNewConnection(this, packet, systemAddress: &packet->systemAddress); /*0x1410125f2*/
        break; /*0x1410125f7*/
      case 0x11u: /*0x1410125bd*/
        v5 = FCAR_CONNECTION_ATTEMPT_FAILED; /*0x1410125f9*/
        goto LABEL_17; /*0x1410125fc*/
      case 0x12u: /*0x1410125bd*/
        v5 = FCAR_ALREADY_CONNECTED; /*0x141012616*/
        goto LABEL_17; /*0x14101261c*/
      case 0x14u: /*0x1410125bd*/
        v5 = FCAR_NO_FREE_INCOMING_CONNECTIONS; /*0x14101261e*/
        goto LABEL_17; /*0x141012624*/
      case 0x15u: /*0x1410125bd*/
      case 0x16u: /*0x1410125bd*/
        RBX::Network::Client::OnClosedConnection(this, systemAddress: &packet->systemAddress); /*0x1410125c5*/
        break; /*0x1410125ca*/
      case 0x17u: /*0x1410125bd*/
        v5 = FCAR_CONNECTION_BANNED; /*0x141012626*/
        goto LABEL_17; /*0x14101262c*/
      case 0x18u: /*0x1410125bd*/
        v5 = FCAR_INVALID_PASSWORD; /*0x14101262e*/
        goto LABEL_17; /*0x141012634*/
      case 0x19u: /*0x1410125bd*/
        v5 = FCAR_INCOMPATIBLE_PROTOCOL; /*0x141012636*/
        goto LABEL_17; /*0x14101263c*/
      case 0x1Au: /*0x1410125bd*/
        v5 = FCAR_IP_RECENTLY_CONNECTED; /*0x14101263e*/
LABEL_17:
        RBX::Network::Client::OnFailedConnectionAttempt(this, packet, failedConnectionAttemptReason: v5); /*0x141012644*/
        break; /*0x14101264a*/
      default:
        break;
    }
    v6 = 0; /*0x14101264f*/
    metric._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141012652*/
    metric._Mypair._Myval2._Mysize = 0; /*0x141012657*/
    metric._Mypair._Myval2._Myres = 15; /*0x14101265c*/
    __wind /*0xf1c000000000007c*/
    {
      switch ( *packet->data ) /*0x141012693*/
      {
        case 0x15u: /*0x141012693*/
        case 0x16u: /*0x141012693*/
          RakNet::SystemAddress::operator=(this: &this->serverId, input: &RakNet::UNASSIGNED_SYSTEM_ADDRESS_14); /*0x141012825*/
          goto LABEL_35; /*0x141012825*/
        case 0x18u: /*0x141012693*/
          RakNet::SystemAddress::ToStringN( /*0x1410126a9*/
            this: &packet->systemAddress,
            writePort: true,
            dest: addressBuffer,
            size: 1025,
            portDelineator: 124);
          RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1410126cc*/
            this,
            metric: "RakNetPasswordRejected",
            connectionFailed: true,
            serverAddress: addressBuffer,
            state: ConnectionState_Failed,
            takeLock: true);
          Ptr = RBX::Network::RakNetAddressToString( /*0x1410126df*/
                  result: &v20,
                  raknetAddress: &packet->systemAddress,
                  writePort: true,
                  portDelineator: 124);
          __wind /*0xf1c0000000000070*/
          {
            if ( Ptr->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410126ea*/
              Ptr = (std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x1410126ec*/
            RBX::StandardOut::printf( /*0x1410126fe*/
              type: MESSAGE_SENSITIVE,
              format: "Invalid password from %s",
              Ptr->_Mypair._Myval2._Bx._Buf);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v20); /*0xf1c0000000000068*/
          }
          if ( v20._Mypair._Myval2._Myres >= 0x10 ) /*0x14101270d*/
          {
            v8 = v20._Mypair._Myval2._Bx._Ptr; /*0x141012712*/
            if ( v20._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141012721*/
            {
              v8 = *((char **)v20._Mypair._Myval2._Bx._Ptr - 1); /*0x141012727*/
              if ( (unsigned __int64)(v20._Mypair._Myval2._Bx._Ptr - v8 - 8) > 0x1F ) /*0x141012736*/
                _invalid_parameter_noinfo_noreturn(); /*0x141012738*/
            }
            operator delete(ptr: v8); /*0x14101273f*/
          }
          p_connectionFailedSignal = &this->connectionFailedSignal; /*0x141012744*/
          subtype = (RBX::Graphics::ProfilerAdorn::Item *)&v20; /*0x141012750*/
          v10 = rakIdToString(result: &v20, id: *packet->data); /*0x141012768*/
          __eh34_enter_wind_state(1, 3); /*0xf1c000000000005c*/
          v11 = &v22; /*0x14101276b*/
          goto LABEL_33; /*0x141012770*/
        case 0x94u: /*0x141012693*/
        case 0x95u: /*0x141012693*/
          v12 = "SecurityKeyRejected"; /*0x141012779*/
          if ( *packet->data == 0x94 ) /*0x141012783*/
            v12 = "HashRejected"; /*0x141012783*/
          RakNet::SystemAddress::ToStringN( /*0x14101279b*/
            this: &packet->systemAddress,
            writePort: true,
            dest: addressBuffer,
            size: 1025,
            portDelineator: 124);
          RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1410127ba*/
            this,
            metric: v12,
            connectionFailed: true,
            serverAddress: addressBuffer,
            state: ConnectionState_Failed,
            takeLock: true);
          p_connectionFailedSignal = &this->connectionFailedSignal; /*0x1410127bf*/
          subtype = (RBX::Graphics::ProfilerAdorn::Item *)&v22; /*0x1410127cb*/
          v10 = rakIdToString(result: &v22, id: *packet->data); /*0x1410127e3*/
          __eh34_enter_wind_state(1, 3); /*0xf1c0000000000054*/
          v11 = &v20; /*0x1410127e6*/
LABEL_33:
          v13 = *packet->data; /*0x1410127eb*/
          v14 = RBX::Network::RakNetAddressToString( /*0x1410127fb*/
                  result: v11,
                  raknetAddress: &packet->systemAddress,
                  writePort: true,
                  portDelineator: 124);
          if ( __eh34_unwind(3) ) /*0xf1c0000000000040*/
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: subtype); /*0xf1c0000000000044*/
            __eh34_continue_unwinding(3, 1); /*0xf1c0000000000048*/
          }
          __eh34_exit_wind_state(3, 1); /*0xf1c000000000004c*/
          rbx::signal<void (std::string,int,std::string)>::operator()( /*0x14101280d*/
            this: p_connectionFailedSignal,
            <args_0>: v14,
            <args_1>: v13,
            <args_2>: v10);
          goto LABEL_67; /*0x141012812*/
        case 0x9Cu: /*0x141012693*/
          memset(&v20, 0, 24); /*0x141012851*/
          __wind /*0xf1c0000000000034*/
          {
            RBX::Network::Peer::recvExtAntiCheatHelper( /*0x14101287a*/
              this,
              packet,
              (RBX::Network::ExtAntiCheatSubtype *)&subtype,
              &sequenceNumber,
              msg: (std::vector<unsigned char> *)&v20);
            if ( (_BYTE)subtype != 0 ) /*0x141012888*/
            {
              if ( (_BYTE)subtype == 1 ) /*0x1410128b5*/
                RBX::Network::ExtAntiCheatCommunicator::onAck(sequenceNumber); /*0x1410128bd*/
            }
            else
            {
              rbx::signal<void (std::vector<unsigned char> const &)>::operator()( /*0x141012896*/
                this: &this->extAntiCheatSignal,
                <args_0>: (const std::vector<unsigned char> *)&v20);
              if ( RBX::clientExtAntiCheatSignal != nullptr ) /*0x1410128a5*/
                rbx::signal<void (std::vector<unsigned char> const &)>::operator()( /*0x1410128ac*/
                  this: RBX::clientExtAntiCheatSignal,
                  <args_0>: (const std::vector<unsigned char> *)&v20);
            }
          }
          __unwind
          {
            RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&v20); /*0xf1c000000000002c*/
          }
          v16 = v20._Mypair._Myval2._Bx._Ptr; /*0x1410128c3*/
          if ( v20._Mypair._Myval2._Bx._Ptr != nullptr ) /*0x1410128cb*/
          {
            if ( v20._Mypair._Myval2._Mysize - (unsigned __int64)v20._Mypair._Myval2._Bx._Ptr >= 0x1000 ) /*0x1410128e3*/
            {
              v16 = *((char **)v20._Mypair._Myval2._Bx._Ptr - 1); /*0x1410128e9*/
              if ( (unsigned __int64)(v20._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x1410128f8*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410128fa*/
            }
            operator delete(ptr: v16); /*0x141012901*/
          }
          goto LABEL_35; /*0x141012906*/
        case 0x9Du: /*0x141012693*/
          if ( !FFlag::RuppTokEn4.value ) /*0x141012912*/
            goto LABEL_35; /*0x141012912*/
          RBX::Network::Client::handleUpdateToken(this, packet); /*0x14101291e*/
          break; /*0x141012923*/
        default:
LABEL_35:
          clientReplicator = this->clientReplicator; /*0x14101282a*/
          if ( clientReplicator != nullptr ) /*0x141012834*/
            v6 = clientReplicator->OnReceive(this: clientReplicator, a2: packet); /*0x141012846*/
          else
            v6 = 1; /*0x141012925*/
          break; /*0x141012849*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&metric); /*0xf1c000000000008c*/
    }
LABEL_67:
    ;
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&memscopeNetworkReplicator); /*0xf1c0000000000098*/
  }
  __wind /*0xf1c00000000000a0*/
  {
    RBX::Memory::setCurrentCategory(category: v4); /*0x14101292d*/
  }
  __unwind
  {
    __std_terminate(a1: v17, a2: &v19); /*0x142f39fa8*/
  }
  return v6; /*0x141012936*/
}

// Address: 0x141012a30 | Name: ?OnReceiveOpenConnectionReply1@Client@Network@RBX@@UEAAXXZ
void __fastcall RBX::Network::Client::OnReceiveOpenConnectionReply1(RBX::Network::Client *this)
{
  this->receivedOpenConnectionReply1 = true; /*0x141012a30*/
}

// Address: 0x141012a40 | Name: ?OnReceiveOpenConnectionReply2@Client@Network@RBX@@UEAAXXZ
void __fastcall RBX::Network::Client::OnReceiveOpenConnectionReply2(RBX::Network::Client *this)
{
  this->receivedOpenConnectionReply2 = true; /*0x141012a40*/
}

// Address: 0x141012a50 | Name: ?OnReliabilityLayerDeadConnection@Client@Network@RBX@@UEAAXAEBUSystemAddress@RakNet@@@Z
void __fastcall RBX::Network::Client::OnReliabilityLayerDeadConnection(
        RBX::Network::Client *this,
        RakNet::SystemAddress *systemAddress)
{
  char *v4; // rax
  RBX::Network::Client::JoinState reportingJoinState; // ecx
  __int32 v6; // ecx
  __int32 v7; // ecx
  const char *v8; // r9
  unsigned __int64 v9; // rdi
  unsigned __int64 Mysize; // rcx
  char *v11; // rbx
  std::string *p_metric; // rdx
  RBX::Network::ClientReplicator *clientReplicator; // rcx
  char *Ptr; // rcx
  std::string metric; // [rsp+30h] [rbp-438h] BYREF
  char addressBuffer[1040]; // [rsp+50h] [rbp-418h] BYREF

  v4 = (char *)operator new(size: 0x20u); /*0x141012a84*/
  metric._Mypair._Myval2._Mysize = 22; /*0x141012a89*/
  metric._Mypair._Myval2._Myres = 31; /*0x141012a92*/
  strcpy(v4, "LostReliableConnection"); /*0x141012aa2*/
  metric._Mypair._Myval2._Bx._Ptr = v4; /*0x141012abd*/
  __wind /*0xf1c0000000000010*/
  {
    RakNet::SystemAddress::ToStringN( /*0x141012ad7*/
      this: systemAddress,
      writePort: true,
      dest: addressBuffer,
      size: 1025,
      portDelineator: 124);
    reportingJoinState = this->reportingJoinState; /*0x141012adc*/
    if ( reportingJoinState != JoinState_NotStartedYet ) /*0x141012ae4*/
    {
      v6 = reportingJoinState - 1; /*0x141012ae6*/
      if ( v6 != 0 ) /*0x141012ae9*/
      {
        v7 = v6 - 1; /*0x141012aeb*/
        if ( v7 != 0 ) /*0x141012aee*/
        {
          if ( v7 == 1 ) /*0x141012af3*/
            v8 = "_AfterLoadFinished"; /*0x141012afe*/
          else
            v8 = pass; /*0x141012af5*/
        }
        else
        {
          v8 = "_BeforeLoadFinished"; /*0x141012b07*/
        }
      }
      else
      {
        v8 = "_BeforeConnected"; /*0x141012b10*/
      }
    }
    else
    {
      v8 = "_NotStartedYet"; /*0x141012b19*/
    }
    v9 = -1; /*0x141012b20*/
    do /*0x141012b38*/
      ++v9; /*0x141012b30*/
    while ( v8[v9] != 0 ); /*0x141012b38*/
    Mysize = metric._Mypair._Myval2._Mysize; /*0x141012b3a*/
    if ( v9 > metric._Mypair._Myval2._Myres - metric._Mypair._Myval2._Mysize ) /*0x141012b4d*/
    {
      std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x141012b8e*/
        this: &metric,
        _Size_increase: v9,
        _Fn: 0,
        <_Args_0>: v8,
        <_Args_1>: v9);
    }
    else
    {
      metric._Mypair._Myval2._Mysize += v9; /*0x141012b53*/
      v11 = &metric._Mypair._Myval2._Bx._Ptr[Mysize]; /*0x141012b67*/
      memmove_0(a1: &metric._Mypair._Myval2._Bx._Ptr[Mysize], Src: v8, Size: v9); /*0x141012b73*/
      v11[v9] = 0; /*0x141012b78*/
    }
    p_metric = &metric; /*0x141012b93*/
    if ( metric._Mypair._Myval2._Myres >= 0x10 ) /*0x141012b9e*/
      p_metric = (std::string *)metric._Mypair._Myval2._Bx._Ptr; /*0x141012b9e*/
    RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x141012bbc*/
      this,
      metric: p_metric->_Mypair._Myval2._Bx._Buf,
      connectionFailed: true,
      serverAddress: addressBuffer,
      state: ConnectionState_Failed,
      takeLock: true);
    clientReplicator = this->clientReplicator; /*0x141012bc1*/
    if ( clientReplicator != nullptr ) /*0x141012bcb*/
      RBX::Network::Replicator::safeSetDisconnectReason(this: clientReplicator, reason: 0x115u); /*0x141012bd2*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&metric); /*0xf1c0000000000008*/
  }
  if ( metric._Mypair._Myval2._Myres >= 0x10 ) /*0x141012be1*/
  {
    Ptr = metric._Mypair._Myval2._Bx._Ptr; /*0x141012be6*/
    if ( metric._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141012bf5*/
    {
      Ptr = *((char **)metric._Mypair._Myval2._Bx._Ptr - 1); /*0x141012bfb*/
      if ( (unsigned __int64)(metric._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141012c0a*/
        _invalid_parameter_noinfo_noreturn(); /*0x141012c0c*/
    }
    operator delete(ptr: Ptr); /*0x141012c13*/
  }
}

// Address: 0x141012c30 | Name: ?OnRemoteActiveDisconnect@Client@Network@RBX@@UEAAXAEBUSystemAddress@RakNet@@@Z
void __fastcall RBX::Network::Client::OnRemoteActiveDisconnect(
        RBX::Network::Client *this,
        RakNet::SystemAddress *systemAddress)
{
  char *v4; // rax
  RBX::Network::Client::JoinState reportingJoinState; // ecx
  __int32 v6; // ecx
  __int32 v7; // ecx
  const char *v8; // r9
  unsigned __int64 v9; // rdi
  unsigned __int64 Mysize; // rcx
  char *v11; // rbx
  std::string *p_metric; // rdx
  char *Ptr; // rcx
  std::string metric; // [rsp+30h] [rbp-438h] BYREF
  char addressBuffer[1040]; // [rsp+50h] [rbp-418h] BYREF

  v4 = (char *)operator new(size: 0x20u); /*0x141012c64*/
  metric._Mypair._Myval2._Mysize = 22; /*0x141012c69*/
  metric._Mypair._Myval2._Myres = 31; /*0x141012c72*/
  strcpy(v4, "RemoteActiveDisconnect"); /*0x141012c82*/
  metric._Mypair._Myval2._Bx._Ptr = v4; /*0x141012c9d*/
  __wind /*0xf1c0000000000010*/
  {
    RakNet::SystemAddress::ToStringN( /*0x141012cb7*/
      this: systemAddress,
      writePort: true,
      dest: addressBuffer,
      size: 1025,
      portDelineator: 124);
    reportingJoinState = this->reportingJoinState; /*0x141012cbc*/
    if ( reportingJoinState != JoinState_NotStartedYet ) /*0x141012cc4*/
    {
      v6 = reportingJoinState - 1; /*0x141012cc6*/
      if ( v6 != 0 ) /*0x141012cc9*/
      {
        v7 = v6 - 1; /*0x141012ccb*/
        if ( v7 != 0 ) /*0x141012cce*/
        {
          if ( v7 == 1 ) /*0x141012cd3*/
            v8 = "_AfterLoadFinished"; /*0x141012cde*/
          else
            v8 = pass; /*0x141012cd5*/
        }
        else
        {
          v8 = "_BeforeLoadFinished"; /*0x141012ce7*/
        }
      }
      else
      {
        v8 = "_BeforeConnected"; /*0x141012cf0*/
      }
    }
    else
    {
      v8 = "_NotStartedYet"; /*0x141012cf9*/
    }
    v9 = -1; /*0x141012d00*/
    do /*0x141012d18*/
      ++v9; /*0x141012d10*/
    while ( v8[v9] != 0 ); /*0x141012d18*/
    Mysize = metric._Mypair._Myval2._Mysize; /*0x141012d1a*/
    if ( v9 > metric._Mypair._Myval2._Myres - metric._Mypair._Myval2._Mysize ) /*0x141012d2d*/
    {
      std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x141012d6e*/
        this: &metric,
        _Size_increase: v9,
        _Fn: 0,
        <_Args_0>: v8,
        <_Args_1>: v9);
    }
    else
    {
      metric._Mypair._Myval2._Mysize += v9; /*0x141012d33*/
      v11 = &metric._Mypair._Myval2._Bx._Ptr[Mysize]; /*0x141012d47*/
      memmove_0(a1: &metric._Mypair._Myval2._Bx._Ptr[Mysize], Src: v8, Size: v9); /*0x141012d53*/
      v11[v9] = 0; /*0x141012d58*/
    }
    p_metric = &metric; /*0x141012d73*/
    if ( metric._Mypair._Myval2._Myres >= 0x10 ) /*0x141012d7e*/
      p_metric = (std::string *)metric._Mypair._Myval2._Bx._Ptr; /*0x141012d7e*/
    RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x141012d9c*/
      this,
      metric: p_metric->_Mypair._Myval2._Bx._Buf,
      connectionFailed: true,
      serverAddress: addressBuffer,
      state: ConnectionState_Failed,
      takeLock: true);
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&metric); /*0xf1c0000000000008*/
  }
  if ( metric._Mypair._Myval2._Myres >= 0x10 ) /*0x141012dab*/
  {
    Ptr = metric._Mypair._Myval2._Bx._Ptr; /*0x141012db0*/
    if ( metric._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141012dbf*/
    {
      Ptr = *((char **)metric._Mypair._Myval2._Bx._Ptr - 1); /*0x141012dc5*/
      if ( (unsigned __int64)(metric._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141012dd4*/
        _invalid_parameter_noinfo_noreturn(); /*0x141012dd6*/
    }
    operator delete(ptr: Ptr); /*0x141012ddd*/
  }
}

// Address: 0x141012e00 | Name: ?OnTimeoutWaitingForPasswordAccepted@Client@Network@RBX@@UEAAXAEBUSystemAddress@RakNet@@@Z
void __fastcall RBX::Network::Client::OnTimeoutWaitingForPasswordAccepted(
        RBX::Network::Client *this,
        RakNet::SystemAddress *systemAddress)
{
  char addressBuffer[1048]; // [rsp+30h] [rbp-418h] BYREF

  RakNet::SystemAddress::ToStringN( /*0x141012e24*/
    this: systemAddress,
    writePort: true,
    dest: addressBuffer,
    size: 1025,
    portDelineator: 124);
  RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x141012e48*/
    this,
    metric: "TimeoutRakNetPassword",
    connectionFailed: true,
    serverAddress: addressBuffer,
    state: ConnectionState_Failed,
    takeLock: true);
}

// Address: 0x141013ee0 | Name: ?checkArtificialLatency@Client@Network@RBX@@AEAAX_J@Z
void __fastcall RBX::Network::Client::checkArtificialLatency(RBX::Network::Client *this, std::_Func_base<void> *userId)
{
  std::_Ref_count_base *Rep; // r8
  signed __int32 Uses; // eax
  signed __int32 v6; // ett
  std::_Ref_count_base *v7; // rsi
  RBX::Network::Client *v8; // rax
  std::_Ref_count_base *v9; // rdi
  const RBX::DataModel *v10; // rax
  RBX::Ixp::IxpController *v11; // rax
  RBX::Ixp::IxpController *v12; // r15
  RBX::Network::Client::IxpChangedListener *Ptr; // rdx
  void (__fastcall *removeUserChangedListener)(struct RBX::Ixp::IxpController *, std::weak_ptr<RBX::Ixp::ChangedListener> *__struct_ptr); // r8
  std::_Ref_count_base *v15; // rax
  _DWORD *v16; // rax
  std::_Ref_count_base *v17; // rdx
  RBX::DataModel *v18; // r8
  _DWORD *v19; // rdi
  std::_Ref_count_base *v20; // rsi
  RBX::Network::Client *v21; // rax
  std::_Ref_count_base *v22; // rsi
  void (__fastcall *addUserChangedListener)(struct RBX::Ixp::IxpController *, std::weak_ptr<RBX::Ixp::ChangedListener> *__struct_ptr); // r8
  std::_Ref_count_base *v24; // rcx
  std::_Ref_count_base *v25; // rdi
  _QWORD v26[8]; // [rsp+0h] [rbp-100h] BYREF
  std::weak_ptr<RBX::DataModel> weakDm; // [rsp+40h] [rbp-C0h] BYREF
  std::weak_ptr<RBX::Network::Client> weakThis; // [rsp+50h] [rbp-B0h] BYREF
  __int128 v29; // [rsp+60h] [rbp-A0h] BYREF
  __int128 v30; // [rsp+70h] [rbp-90h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > layerVariables; // [rsp+80h] [rbp-80h] BYREF
  std::weak_ptr<RBX::Network::Client> v32; // [rsp+90h] [rbp-70h]
  std::weak_ptr<RBX::DataModel> v33; // [rsp+A0h] [rbp-60h]
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > v34; // [rsp+C0h] [rbp-40h] BYREF
  std::weak_ptr<RBX::DataModel> v35; // [rsp+D0h] [rbp-30h] BYREF
  std::function<void __cdecl(void)> v36; // [rsp+E0h] [rbp-20h] BYREF
  char v37; // [rsp+120h] [rbp+20h] BYREF
  std::_Ref_count_base *v38; // [rsp+128h] [rbp+28h]
  std::optional<enum RBX::IXPLoadingStatus> status; // [rsp+170h] [rbp+70h] BYREF
  __int64 currentIxpUserId; // [rsp+180h] [rbp+80h] BYREF
  RBX::Time result; // [rsp+188h] [rbp+88h] BYREF

  Rep = this->_Wptr._Rep; /*0x141013f02*/
  if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x141013f15*/
LABEL_76:
    std::_Throw_bad_weak_ptr(); /*0x1410143db*/
  while ( 1 ) /*0x141013f23*/
  {
    v6 = Uses; /*0x141013f23*/
    Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x141013f23*/
    if ( v6 == Uses ) /*0x141013f29*/
      break; /*0x141013f29*/
    if ( Uses == 0 ) /*0x141013f2d*/
      goto LABEL_76; /*0x141013f2d*/
  }
  v7 = this->_Wptr._Rep; /*0x141013f35*/
  LODWORD(v26[4]) = 0; /*0x141013f3c*/
  __wind /*0xf1c0000000000050*/
  {
    v8 = (RBX::Network::Client *)_RTDynamicCast_0(); /*0x141013f55*/
    if ( v8 != nullptr ) /*0x141013f5d*/
    {
      v9 = v7; /*0x141013f5f*/
      v7 = nullptr; /*0x141013f62*/
    }
    else
    {
      v8 = nullptr; /*0x141013f67*/
      v9 = nullptr; /*0x141013f6a*/
    }
    weakThis = 0; /*0x141013f70*/
    if ( v9 != nullptr ) /*0x141013f79*/
    {
      weakThis._Ptr = v8; /*0x141013f7b*/
      weakThis._Rep = v9; /*0x141013f80*/
      _InterlockedIncrement((volatile signed __int32 *)&v9->_Weaks); /*0x141013f85*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v9->_Uses, 0xFFFFFFFF) == 1 ) /*0x141013f9d*/
      {
        v9->_Destroy(this: v9); /*0x141013fa5*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v9->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141013fb1*/
          v9->_Delete_this(this: v9); /*0x141013fb9*/
      }
    }
    if ( v7 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Uses, 0xFFFFFFFF) == 1 ) /*0x141013fcb*/
    {
      v7->_Destroy(this: v7); /*0x141013fd3*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141013fdf*/
        v7->_Delete_this(this: v7); /*0x141013fe7*/
    }
  }
  __unwind
  {
    __std_terminate(a1: &result, a2: v26); /*0x142f39fa8*/
  }
  __wind /*0xf1c0000000000068*/
  {
    this->latencyCheckStartTime = *(RBX::Time *)&RBX::Time::nowFast(&result)->sec; /*0x141013ffa*/
    v10 = RBX::DataModel::get(context: this); /*0x141014006*/
    if ( v10 != nullptr ) /*0x14101400e*/
    {
      RBX::weak_from<RBX::DataModel>(result: (std::weak_ptr<RBX::DataModel const > *)&weakDm, r: v10); /*0x14101403b*/
      __wind /*0xf1c0000000000044*/
      {
        v11 = RBX::Ixp::IxpController::instance(); /*0x141014041*/
        v12 = v11; /*0x141014046*/
        Ptr = this->ixpChangedListener._Ptr; /*0x141014049*/
        if ( Ptr != nullptr ) /*0x141014053*/
        {
          removeUserChangedListener = v11->removeUserChangedListener; /*0x141014058*/
          v29 = 0; /*0x141014062*/
          v15 = this->ixpChangedListener._Rep; /*0x141014068*/
          if ( v15 != nullptr ) /*0x141014072*/
          {
            *(_QWORD *)&v29 = Ptr; /*0x141014074*/
            *((_QWORD *)&v29 + 1) = v15; /*0x141014079*/
            _InterlockedIncrement((volatile signed __int32 *)&v15->_Weaks); /*0x14101407e*/
          }
          removeUserChangedListener(this: v12, a2: (std::weak_ptr<RBX::Ixp::ChangedListener> *)&v29); /*0x14101408a*/
        }
        v16 = operator new(size: 0x40u); /*0x141014092*/
        v19 = v16; /*0x141014097*/
        v26[6] = v16; /*0x14101409a*/
        if ( v16 != nullptr ) /*0x1410140a2*/
        {
          *(_OWORD *)v16 = 0; /*0x1410140ab*/
          v16[2] = 1; /*0x1410140ae*/
          v16[3] = 1; /*0x1410140b5*/
          *(_QWORD *)v16 = std::_Ref_count_obj2<RBX::Network::Client::IxpChangedListener>::`vftable'; /*0x1410140c3*/
          v20 = nullptr; /*0x1410140c6*/
          v18 = nullptr; /*0x1410140c9*/
          if ( weakDm._Rep != nullptr ) /*0x1410140d4*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&weakDm._Rep->_Weaks); /*0x1410140d6*/
            v18 = weakDm._Ptr; /*0x1410140da*/
            v20 = weakDm._Rep; /*0x1410140df*/
          }
          v17 = nullptr; /*0x1410140e4*/
          v21 = nullptr; /*0x1410140e7*/
          if ( weakThis._Rep != nullptr ) /*0x1410140f2*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&weakThis._Rep->_Weaks); /*0x1410140f4*/
            v17 = weakThis._Rep; /*0x1410140f8*/
            v21 = weakThis._Ptr; /*0x1410140fd*/
          }
          *((_QWORD *)v19 + 2) = RBX::Network::Client::IxpChangedListener::`vftable'; /*0x141014109*/
          *((_QWORD *)v19 + 3) = 0; /*0x14101410d*/
          *((_QWORD *)v19 + 4) = 0; /*0x141014111*/
          if ( v17 != nullptr ) /*0x141014118*/
          {
            *((_QWORD *)v19 + 3) = v21; /*0x14101411a*/
            *((_QWORD *)v19 + 4) = v17; /*0x14101411e*/
            _InterlockedIncrement((volatile signed __int32 *)&v17->_Weaks); /*0x141014122*/
          }
          *((_QWORD *)v19 + 5) = 0; /*0x141014126*/
          *((_QWORD *)v19 + 6) = 0; /*0x14101412a*/
          if ( v20 != nullptr ) /*0x141014131*/
          {
            *((_QWORD *)v19 + 5) = v18; /*0x141014133*/
            *((_QWORD *)v19 + 6) = v20; /*0x141014137*/
            _InterlockedIncrement((volatile signed __int32 *)&v20->_Weaks); /*0x14101413b*/
          }
          *((_QWORD *)v19 + 7) = userId; /*0x14101413f*/
          if ( v17 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v17->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141014152*/
            v17->_Delete_this(this: v17); /*0x14101415a*/
          if ( v20 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101416c*/
            ((void (__fastcall *)(std::_Ref_count_base *, std::_Ref_count_base *, RBX::DataModel *))v20->_Delete_this)( /*0x141014174*/
              a1: v20,
              a2: v17,
              a3: v18);
        }
        else
        {
          v19 = nullptr; /*0x141014179*/
        }
        this->ixpChangedListener._Ptr = (RBX::Network::Client::IxpChangedListener *)(v19 + 4); /*0x141014180*/
        v22 = this->ixpChangedListener._Rep; /*0x141014187*/
        this->ixpChangedListener._Rep = (std::_Ref_count_base *)v19; /*0x14101418e*/
        if ( v22 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410141a4*/
        {
          ((void (__fastcall *)(std::_Ref_count_base *, std::_Ref_count_base *, RBX::DataModel *))v22->_Destroy)( /*0x1410141ac*/
            a1: v22,
            a2: v17,
            a3: v18);
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410141b8*/
            v22->_Delete_this(this: v22); /*0x1410141c0*/
        }
        addUserChangedListener = v12->addUserChangedListener; /*0x1410141c6*/
        v30 = 0; /*0x1410141cd*/
        v24 = this->ixpChangedListener._Rep; /*0x1410141d3*/
        if ( v24 != nullptr ) /*0x1410141dd*/
        {
          *(_QWORD *)&v30 = this->ixpChangedListener._Ptr; /*0x1410141e6*/
          *((_QWORD *)&v30 + 1) = v24; /*0x1410141eb*/
          _InterlockedIncrement((volatile signed __int32 *)&v24->_Weaks); /*0x1410141f0*/
        }
        addUserChangedListener(this: v12, a2: (std::weak_ptr<RBX::Ixp::ChangedListener> *)&v30); /*0x1410141fc*/
        v12->getUserLayerLoadingStatusAndSubjectId(this: v12, a2: &currentIxpUserId); /*0x14101420c*/
        v12->getUserStatusForLayer(this: v12, result: &status, a3: &FString::CLI52064IxpLayer); /*0x141014223*/
        if ( (std::_Func_base<void> *)currentIxpUserId == userId && status._Has_value && status._Value == 2 ) /*0x14101423d*/
        {
          layerVariables = 0; /*0x141014242*/
          __wind /*0xf1c0000000000038*/
          {
            if ( v12->getUserLayerVariables(this: v12, a2: &FString::CLI52064IxpLayer, a3: &layerVariables) ) /*0x141014258*/
            {
              v34 = 0; /*0x141014262*/
              if ( layerVariables._Rep != nullptr ) /*0x14101426e*/
                _InterlockedIncrement((volatile signed __int32 *)&layerVariables._Rep->_Uses); /*0x141014270*/
              v34 = layerVariables; /*0x141014278*/
              v35 = 0; /*0x141014280*/
              if ( weakDm._Rep != nullptr ) /*0x14101428d*/
              {
                v35 = weakDm; /*0x141014294*/
                _InterlockedIncrement((volatile signed __int32 *)&weakDm._Rep->_Weaks); /*0x141014299*/
              }
              RBX::Network::Client::setArtificialLatencyFromIxp( /*0x1410142ab*/
                this,
                weakDm: &v35,
                (__int64)userId,
                layerVariables: &v34);
            }
          }
          __unwind
          {
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&layerVariables); /*0xf1c0000000000030*/
          }
          v25 = layerVariables._Rep; /*0x1410142b1*/
        }
        else
        {
          v12->fetchLayersForUserId( /*0x1410142c4*/
            this: v12,
            result: (std::shared_ptr<std::promise<void> > *)&v37,
            a3: (__int64)userId);
          v25 = v38; /*0x1410142c7*/
        }
        if ( v25 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v25->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410142da*/
        {
          v25->_Destroy(this: v25); /*0x1410142e2*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v25->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410142ee*/
            v25->_Delete_this(this: v25); /*0x1410142f6*/
        }
        v32 = 0; /*0x1410142fc*/
        if ( weakThis._Rep != nullptr ) /*0x141014309*/
        {
          v32 = weakThis; /*0x141014310*/
          _InterlockedIncrement((volatile signed __int32 *)&weakThis._Rep->_Weaks); /*0x141014318*/
        }
        v33 = 0; /*0x14101431c*/
        if ( weakDm._Rep != nullptr ) /*0x141014329*/
        {
          v33 = weakDm; /*0x141014330*/
          _InterlockedIncrement((volatile signed __int32 *)&weakDm._Rep->_Weaks); /*0x141014338*/
        }
        v36._Mystorage._Ptrs[0] = (std::_Func_base<void> *)std::_Func_impl_no_alloc__lambda_1ad3a5c617f5d49266658a67ddd0930a__void_::_vftable_; /*0x141014343*/
        *(std::weak_ptr<RBX::Network::Client> *)&v36._Mystorage._Ptrs[1] = v32; /*0x14101434b*/
        *(std::weak_ptr<RBX::DataModel> *)&v36._Mystorage._Ptrs[3] = v33; /*0x14101435b*/
        v36._Mystorage._Ptrs[5] = userId; /*0x141014367*/
        v36._Mystorage._Ptrs[7] = (std::_Func_base<void> *)&v36; /*0x14101436f*/
        RBX::TaskScheduler::submitAsyncTask(task: &v36, queueCounter: nullptr); /*0x141014379*/
      }
      __unwind
      {
        std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)&weakDm); /*0xf1c0000000000024*/
      }
      if ( weakDm._Rep != nullptr /*0x141014393*/
        && _InterlockedExchangeAdd((volatile signed __int32 *)&weakDm._Rep->_Weaks, 0xFFFFFFFF) == 1 )
      {
        weakDm._Rep->_Delete_this(this: weakDm._Rep); /*0x14101439d*/
      }
    }
    else if ( FLog::Network != 0 ) /*0x141014019*/
    {
      FLog::FastLog( /*0x141014029*/
        level: FLog::Network,
        message: "[FLog::Network] Unable to access DataModel when checking IXP",
        arg0: nullptr);
    }
    if ( weakThis._Rep != nullptr /*0x1410143b3*/
      && _InterlockedExchangeAdd((volatile signed __int32 *)&weakThis._Rep->_Weaks, 0xFFFFFFFF) == 1 )
    {
      weakThis._Rep->_Delete_this(this: weakThis._Rep); /*0x1410143bd*/
    }
  }
  __unwind
  {
    std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)&weakThis); /*0xf1c0000000000018*/
  }
}

// Address: 0x1410144e0 | Name: ?clientIsPresent@Client@Network@RBX@@SA_NPEBVInstance@3@_N@Z
bool __fastcall RBX::Network::Client::clientIsPresent(RBX::ServiceProvider *context, bool testInDatamodel)
{
  RBX::ServiceProvider *parent; // rdi
  RBX::Instance *v3; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v5; // rax

  if ( context == nullptr ) /*0x1410144e9*/
    return false; /*0x1410144e9*/
  parent = (RBX::ServiceProvider *)context->parent; /*0x1410144eb*/
  if ( parent != nullptr ) /*0x1410144f2*/
  {
    v3 = parent->parent; /*0x1410144f4*/
    if ( v3 != nullptr ) /*0x1410144fb*/
      parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v3); /*0x141014502*/
  }
  else
  {
    parent = context; /*0x141014507*/
  }
  if ( parent != nullptr /*0x14101453b*/
    && (descriptor = parent->descriptor,
        v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(),
        descriptor->index - (unsigned int)v5->index <= v5->descendantCount) )
  {
    return RBX::ServiceProvider::find<RBX::Network::Client>(this: parent) != nullptr; /*0x141014548*/
  }
  else
  {
    return false; /*0x141014556*/
  }
}

// Address: 0x141014580 | Name: ?configureAsCloudEditClient@Client@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::Client::configureAsCloudEditClient(RBX::Network::Client *this)
{
  RBX::DataModel *v2; // rax

  if ( FFlag::UsingDataModelCloudMode.value ) /*0x141014590*/
  {
    v2 = RBX::DataModel::get(context: this); /*0x141014592*/
    if ( v2 != nullptr ) /*0x14101459a*/
      RBX::DataModel::setCloudEdit(this: v2); /*0x14101459f*/
  }
  this->clientReplicationMode = ReplicationMode_StudioAsEditor; /*0x1410145ab*/
  RBX::Network::MegaReplicator::setIsCloudEdit(this: &this->megaReplicator); /*0x1410145ba*/
}

// Address: 0x1410145c0 | Name: ?configureAsCloudTestClient@Client@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::Client::configureAsCloudTestClient(RBX::Network::Client *this)
{
  RBX::DataModel *v2; // rax

  if ( FFlag::UsingDataModelCloudMode.value ) /*0x1410145d0*/
  {
    v2 = RBX::DataModel::get(context: this); /*0x1410145d2*/
    if ( v2 != nullptr ) /*0x1410145da*/
      *(_DWORD *)v2->cloudMode = 2; /*0x1410145dc*/
    this->clientReplicationMode = ReplicationMode_StudioAsClient; /*0x1410145e6*/
  }
  else
  {
    this->clientReplicationMode = ReplicationMode_StudioAsClient; /*0x1410145f6*/
  }
}

// Address: 0x141014b30 | Name: ?disconnect@Client@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::Client::disconnect(RBX::Network::Client *this)
{
  std::vector<std::shared_ptr<RBX::Instance>> *Ptr; // rax
  std::_Ref_count_base *Rep; // rbx
  std::shared_ptr<RBX::Instance> *Mylast; // rcx
  std::shared_ptr<RBX::Instance> *i; // rax
  RBX::Instance *v6; // rdx
  RBX::Network::ConcurrentRakPeer *v7; // rcx
  Luau::InternalErrorReporter *v8; // rdi
  std::_Func_base<void,char const *>_vtbl *v9; // rbx
  __int64 v10; // r8
  Luau::InternalErrorReporter *v11; // rax
  RakNet::RakNetGUID v12; // [rsp+30h] [rbp-38h] BYREF
  RakNet::SystemAddress v13; // [rsp+40h] [rbp-28h] BYREF

  if ( FLog::Network != 0 ) /*0x141014b42*/
    FLog::FastLog(level: FLog::Network, message: "[FLog::Network] Client:Disconnect", arg0: nullptr); /*0x141014b4e*/
  Ptr = this->children.object._Ptr; /*0x141014b53*/
  if ( Ptr != nullptr ) /*0x141014b64*/
  {
    Rep = this->children.object._Rep; /*0x141014b66*/
    if ( Rep != nullptr ) /*0x141014b6d*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141014b6f*/
      Ptr = this->children.object._Ptr; /*0x141014b73*/
      Rep = this->children.object._Rep; /*0x141014b77*/
    }
    Mylast = Ptr->_Mypair._Myval2._Mylast; /*0x141014b7b*/
    for ( i = Ptr->_Mypair._Myval2._Myfirst; i != Mylast; v6->isParentLocked = false ) /*0x141014b85*/
    {
      v6 = i->_Ptr; /*0x141014b90*/
      ++i; /*0x141014b93*/
    }
    if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141014bb4*/
    {
      Rep->_Destroy(this: Rep); /*0x141014bbc*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141014bc6*/
        Rep->_Delete_this(this: Rep); /*0x141014bce*/
    }
  }
  RBX::Instance::removeAllChildren(this); /*0x141014bd4*/
  v7 = this->rakPeer._Ptr; /*0x141014bd9*/
  if ( v7 != nullptr ) /*0x141014be3*/
  {
    v8 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)v7); /*0x141014bea*/
    v9 = v8->onInternalError._Mystorage._Ptrs[0][27].__vftable; /*0x141014bf0*/
    RakNet::RakNetGUID::RakNetGUID(this: &v12); /*0x141014bfc*/
    RakNet::SystemAddress::SystemAddress(this: &v13); /*0x141014c06*/
    v12 = RakNet::UNASSIGNED_RAKNET_GUID_14; /*0x141014c19*/
    RakNet::SystemAddress::operator=(this: &v13, input: &this->serverId); /*0x141014c2f*/
    LOBYTE(v10) = 1; /*0x141014c3f*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, RakNet::RakNetGUID *, __int64, _QWORD, int))v9)( /*0x141014c4a*/
      a1: v8,
      a2: &v12,
      a3: v10,
      a4: 0,
      a5: 3);
    v11 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141014c53*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD))v11->onInternalError._Mystorage._Ptrs[0][13].__vftable)( /*0x141014c60*/
      a1: v11,
      a2: 0);
  }
}

// Address: 0x1410157b0 | Name: ?findClient@Client@Network@RBX@@SAPEAV123@PEBVInstance@3@_N@Z
RBX::Graphics::FrameRateManagerStatsStringItem *__fastcall RBX::Network::Client::findClient(
        RBX::ServiceProvider *player)
{
  RBX::ServiceProvider *parent; // rdi
  RBX::Instance *v2; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v4; // rax

  if ( player == nullptr ) /*0x1410157b9*/
    return nullptr; /*0x1410157b9*/
  parent = (RBX::ServiceProvider *)player->parent; /*0x1410157bb*/
  if ( parent != nullptr ) /*0x1410157c2*/
  {
    v2 = parent->parent; /*0x1410157c4*/
    if ( v2 != nullptr ) /*0x1410157cb*/
      parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v2); /*0x1410157d2*/
  }
  else
  {
    parent = player; /*0x1410157d7*/
  }
  if ( parent != nullptr /*0x14101580b*/
    && (descriptor = parent->descriptor,
        v4 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(),
        descriptor->index - (unsigned int)v4->index <= v4->descendantCount) )
  {
    return RBX::ServiceProvider::find<RBX::Network::Client>(this: parent); /*0x141015815*/
  }
  else
  {
    return nullptr; /*0x14101581a*/
  }
}

// Address: 0x141015830 | Name: ?findLocalSimulatorAddress@Client@Network@RBX@@SA?BVSystemAddress@3@PEBVInstance@3@@Z
const RBX::SystemAddress *__fastcall RBX::Network::Client::findLocalSimulatorAddress(
        const RBX::SystemAddress *result,
        RBX::ServiceProvider *context)
{
  RBX::ServiceProvider *parent; // rdi
  RBX::Instance *v4; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v6; // rax
  RBX::Graphics::FrameRateManagerStatsStringItem *v7; // rax
  std::_Ref_count_base *Rep; // rax

  if ( context == nullptr ) /*0x141015840*/
    goto LABEL_11; /*0x141015840*/
  parent = (RBX::ServiceProvider *)context->parent; /*0x141015846*/
  if ( parent != nullptr ) /*0x14101584d*/
  {
    v4 = parent->parent; /*0x14101584f*/
    if ( v4 != nullptr ) /*0x141015856*/
      parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v4); /*0x14101585d*/
  }
  else
  {
    parent = context; /*0x141015862*/
  }
  if ( parent != nullptr /*0x1410158af*/
    && (descriptor = parent->descriptor,
        v6 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(),
        descriptor->index - (unsigned int)v6->index <= v6->descendantCount)
    && (v7 = RBX::ServiceProvider::find<RBX::Network::Client>(this: parent)) != nullptr
    && (Rep = v7[10].ancestryChangedSignal.slots._Rep) != nullptr )
  {
    result->remoteId.peerId = (unsigned int)Rep[850].__vftable; /*0x1410158b7*/
    return result; /*0x1410158b9*/
  }
  else
  {
LABEL_11:
    if ( __TSS0__1__Unassigned_NetworkOwner_RBX__SA_BVSystemAddress_3_XZ_4HA > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] /*0x1410158e8*/
                                                                                           + (unsigned int)tls_index)
                                                                                         + 260LL) )
    {
      Init_thread_header(pOnce: &__TSS0__1__Unassigned_NetworkOwner_RBX__SA_BVSystemAddress_3_XZ_4HA); /*0x141015907*/
      if ( __TSS0__1__Unassigned_NetworkOwner_RBX__SA_BVSystemAddress_3_XZ_4HA == -1 ) /*0x141015913*/
      {
        `RBX::NetworkOwner::Unassigned'::`2'::s.remoteId.peerId = -1; /*0x14101591c*/
        Init_thread_footer(pOnce: &__TSS0__1__Unassigned_NetworkOwner_RBX__SA_BVSystemAddress_3_XZ_4HA); /*0x141015926*/
      }
    }
    result->remoteId.peerId = `RBX::NetworkOwner::Unassigned'::`2'::s.remoteId.peerId; /*0x1410158f0*/
    return result; /*0x1410158f2*/
  }
}

// Address: 0x141015b40 | Name: ?getConnectedServer@Client@Network@RBX@@QEAA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@XZ
std::string *__fastcall RBX::Network::Client::getConnectedServer(RBX::Network::Client *this, std::string *result)
{
  RBX::Network::Client::ServerConnection *Myfirst; // r10
  unsigned int v4; // r8d
  unsigned __int64 v5; // rdx
  __int64 v6; // rcx
  RBX::Network::Client::ServerConnection *v8; // r9
  RBX::Network::Client::ServerConnection *Ptr; // rcx
  char *v10; // rdx
  char v11; // al
  unsigned __int64 v12; // rbx
  __int64 v13; // rdx
  char addressBuffer[1048]; // [rsp+20h] [rbp-418h] BYREF

  Myfirst = this->serverConnections._Mypair._Myval2._Myfirst; /*0x141015b4d*/
  v4 = 0; /*0x141015b70*/
  v5 = this->serverConnections._Mypair._Myval2._Mylast - Myfirst; /*0x141015b7e*/
  if ( v5 != 0 )
  {
    v6 = 0; /*0x141015b83*/
    while ( Myfirst[v6].state != ConnectionState_Connected ) /*0x141015b9d*/
    {
      v6 = ++v4; /*0x141015ba2*/
      if ( v4 >= v5 ) /*0x141015ba8*/
        goto LABEL_5; /*0x141015ba8*/
    }
    v8 = &Myfirst[v6]; /*0x141015be0*/
    Ptr = v8; /*0x141015be3*/
    if ( v8->address._Mypair._Myval2._Myres >= 0x10 ) /*0x141015beb*/
      Ptr = (RBX::Network::Client::ServerConnection *)v8->address._Mypair._Myval2._Bx._Ptr; /*0x141015bed*/
    v10 = (char *)(addressBuffer - (char *)Ptr); /*0x141015bf5*/
    do /*0x141015c0c*/
    {
      v11 = Ptr->address._Mypair._Myval2._Bx._Buf[0]; /*0x141015c00*/
      Ptr->address._Mypair._Myval2._Bx._Buf[(_QWORD)v10] = Ptr->address._Mypair._Myval2._Bx._Buf[0]; /*0x141015c03*/
      Ptr = (RBX::Network::Client::ServerConnection *)((char *)Ptr + 1); /*0x141015c06*/
    }
    while ( v11 != 0 ); /*0x141015c0c*/
    v12 = -1; /*0x141015c0e*/
    v13 = -1; /*0x141015c1a*/
    do /*0x141015c27*/
      ++v13; /*0x141015c20*/
    while ( addressBuffer[v13] != 0 ); /*0x141015c27*/
    addressBuffer[(int)v13] = 124; /*0x141015c32*/
    Itoa(value: v8->port, result: &addressBuffer[(int)v13 + 1], base: 10); /*0x141015c49*/
    if ( DFLog::NetworkTrace != 0 )
      FLog::FastLogFormatted(
        level: DFLog::NetworkTrace,
        message: "[DFLog::NetworkTrace] getConnectedServer::: returning %s",
        addressBuffer);
    result->_Mypair._Myval2._Bx._Ptr = nullptr; /*0x141015c6c*/
    result->_Mypair._Myval2._Mysize = 0; /*0x141015c74*/
    result->_Mypair._Myval2._Myres = 15; /*0x141015c78*/
    result->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141015c80*/
    do /*0x141015c8a*/
      ++v12; /*0x141015c83*/
    while ( addressBuffer[v12] != 0 ); /*0x141015c8a*/
    std::string::assign(this: result, _Ptr: addressBuffer, _Count: v12); /*0x141015c97*/
  }
  else
  {
LABEL_5:
    result->_Mypair._Myval2._Bx._Ptr = nullptr; /*0x141015baa*/
    result->_Mypair._Myval2._Myres = 15; /*0x141015bad*/
    result->_Mypair._Myval2._Mysize = 0; /*0x141015bb5*/
    result->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141015bb9*/
  }
  return result; /*0x141015bbc*/
}

// Address: 0x141015d80 | Name: ?getLoadStateSuffix@Client@Network@RBX@@QEAAPEBDXZ
const char *__fastcall RBX::Network::Client::getLoadStateSuffix(RBX::Network::Client *this)
{
  RBX::Network::Client::JoinState reportingJoinState; // edx
  __int32 v2; // edx
  __int32 v3; // edx

  reportingJoinState = this->reportingJoinState; /*0x141015d80*/
  if ( reportingJoinState == JoinState_NotStartedYet ) /*0x141015d88*/
    return "_NotStartedYet"; /*0x141015db9*/
  v2 = reportingJoinState - 1; /*0x141015d8a*/
  if ( v2 == 0 ) /*0x141015d8d*/
    return "_BeforeConnected"; /*0x141015db1*/
  v3 = v2 - 1; /*0x141015d8f*/
  if ( v3 == 0 ) /*0x141015d92*/
    return "_BeforeLoadFinished"; /*0x141015da9*/
  if ( v3 == 1 ) /*0x141015d97*/
    return "_AfterLoadFinished"; /*0x141015da1*/
  return pass; /*0x141015da0*/
}

// Address: 0x141015e10 | Name: ?handleConnectionStateAndMetricReporting@Client@Network@RBX@@QEAAXPEBD_N0W4ConnectionState@ServerConnection@123@1@Z
void __fastcall RBX::Network::Client::handleConnectionStateAndMetricReporting(
        RBX::Network::Client *this,
        const char *metric,
        bool connectionFailed,
        const char *serverAddress,
        RBX::Network::Client::ServerConnection::ConnectionState state,
        bool takeLock)
{
  std::_Func_base<void,RBX::DataModel *> *v9; // xmm6_8
  RBX::Graphics::ProfilerAdorn::Item *v10; // rsi
  RBX::DataModel *v11; // r14
  unsigned __int64 Myres; // rdx
  char *Ptr; // rcx
  bool v14; // al
  bool v15; // si
  double v16; // xmm0_8
  unsigned __int64 v17; // rax
  unsigned __int64 v18; // rbp
  const char *v19; // r14
  const char *v20; // r8
  bool v21; // al
  unsigned __int64 v22; // r8
  Luau::InternalErrorReporter *v23; // rax
  RBX::Network::Client::ServerConnection *Myfirst; // r8
  RBX::Network::Client::ServerConnection *Mylast; // rcx
  unsigned int v26; // eax
  int port; // r9d
  RBX::Time result; // [rsp+30h] [rbp-C8h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *v29; // [rsp+38h] [rbp-C0h]
  std::function<void __cdecl(RBX::DataModel *)> v30; // [rsp+40h] [rbp-B8h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v31; // [rsp+80h] [rbp-78h] BYREF
  std::string v32; // [rsp+A8h] [rbp-50h] BYREF

  if ( state != ConnectionState_NotStartedYet ) /*0x141015e4e*/
    RBX::Network::Client::updateServerConnectionState(this, serverAddress, state, metric, takeLock); /*0x141015e5e*/
  if ( DFFlag::ReportFailuresInClientJoinAll2.value /*0x141015e89*/
    && this->reportingJoinState < JoinState_GameLoaded
    && connectionFailed
    && state == ConnectionState_Failed )
  {
    v9 = COERCE_STD_FUNC_BASE_VOID_RBX_DATAMODEL_(RBX::Time::nowFastSec()); /*0x141015e94*/
    v10 = (RBX::Graphics::ProfilerAdorn::Item *)std::string::string(this: &v32, _Ptr: metric); /*0x141015ea7*/
    v29 = v10; /*0x141015eaa*/
    __wind /*0xf1c0000000000010*/
    {
      v11 = RBX::DataModel::get(context: this); /*0x141015eb7*/
      if ( v11 != nullptr ) /*0x141015ebd*/
      {
        std::string::string(this: &v31, __that: (const rtc::webrtc_checks_impl::ToStringVal *)v10); /*0x141015eca*/
        v30._Mystorage._Ptrs[0] = (std::_Func_base<void,RBX::DataModel *> *)std::_Func_impl_no_alloc__lambda_bcc187dbfecae90bf8e52e9ca58c33de__void_RBX::DataModel___::_vftable_; /*0x141015ed6*/
        *(rtc::webrtc_checks_impl::ToStringVal *)&v30._Mystorage._Ptrs[1] = v31; /*0x141015ee3*/
        v30._Mystorage._Ptrs[5] = v9; /*0x141015ef5*/
        v30._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::DataModel *> *)&v30; /*0x141015f00*/
        RBX::DataModel::submitTask(this: v11, task: &v30, taskType: (RBX::DMTaskType)1); /*0x141015f13*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: v29); /*0xf1c0000000000008*/
    }
    Myres = v10->text._Mypair._Myval2._Myres; /*0x141015f19*/
    if ( Myres >= 0x10 ) /*0x141015f21*/
    {
      Ptr = v10->text._Mypair._Myval2._Bx._Ptr; /*0x141015f26*/
      if ( Myres + 1 >= 0x1000 ) /*0x141015f30*/
      {
        if ( (unsigned __int64)&Ptr[-*((_QWORD *)Ptr - 1) - 8] > 0x1F ) /*0x141015f45*/
          _invalid_parameter_noinfo_noreturn(); /*0x141016063*/
        Ptr = *((char **)Ptr - 1); /*0x141015f4b*/
      }
      operator delete(ptr: Ptr); /*0x141015f4e*/
    }
    v10->text._Mypair._Myval2._Mysize = 0; /*0x141015f53*/
    v10->text._Mypair._Myval2._Myres = 15; /*0x141015f5b*/
    v10->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141015f63*/
  }
  if ( this->clientReplicationMode != ReplicationMode_Client )
  {
    if ( takeLock ) /*0x141015f76*/
      RBX::InstrumentedMutex<std::mutex>::lock(this: &this->connectionStateAndJoinDataMutex); /*0x141015f7f*/
    v14 = RBX::Network::Client::noViableConnectionsLeft(this); /*0x141015f87*/
    v15 = v14; /*0x141015f8c*/
    if ( !connectionFailed || v14 ) /*0x141015f96*/
    {
      v16 = (RBX::Time::nowFast(&result)->sec - this->lastReportedTime.sec) * 1000.0; /*0x141015fb2*/
      v17 = 0; /*0x141015fba*/
      if ( v16 >= 9.223372036854776e18 ) /*0x141015fc8*/
      {
        v16 = v16 - 9.223372036854776e18; /*0x141015fca*/
        if ( v16 < 9.223372036854776e18 ) /*0x141015fd2*/
          v17 = 0x8000000000000000uLL; /*0x141015fde*/
      }
      v18 = v17 + (unsigned int)(int)v16; /*0x141015fe6*/
      v19 = "ConnectionFailure"; /*0x141015fe9*/
      if ( !v15 || (v20 = "ConnectionFailure", this->wasConnected) ) /*0x141015ff5*/
        v20 = metric; /*0x141016001*/
      RBX::Network::Client::reportNetworkMetricToDiag( /*0x141016017*/
        this,
        prefix: "StudioNetwork",
        metric: v20,
        endOfSession: v15,
        msSinceLastMetric: v17 + (unsigned int)(int)v16);
      if ( DFInt::ClientNetworkInfluxHundredthsPercentage != 0 ) /*0x141016023*/
      {
        if ( !v15 || this->wasConnected ) /*0x14101602a*/
          v19 = metric; /*0x141016033*/
        RBX::Network::Client::reportClientLevelNetworkMetricToInflux( /*0x14101604c*/
          this,
          prefix: "StudioNetwork",
          metric: v19,
          endOfSession: v15,
          msSinceLastMetric: v18);
      }
      v21 = this->haveReportedEndOfSession || v15; /*0x14101606a*/
      this->haveReportedEndOfSession = v21; /*0x14101606c*/
      v22 = -1; /*0x141016072*/
      do /*0x141016088*/
        ++v22; /*0x141016080*/
      while ( metric[v22] != 0 ); /*0x141016088*/
      std::string::assign(this: &this->lastReportedMetric, _Ptr: metric, _Count: v22); /*0x141016094*/
      this->lastReportedTime = *(RBX::Time *)&RBX::Time::nowFast(&result)->sec; /*0x1410160a7*/
      v23 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410160b6*/
      ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD))v23->onInternalError._Mystorage._Ptrs[0][110].__vftable)( /*0x1410160c3*/
        a1: v23,
        a2: 0);
    }
    RBX::Network::Client::reportNetworkMetricToGA(this, prefix: "StudioNetwork", metric); /*0x1410160d7*/
    if ( DFInt::ClientNetworkInfluxHundredthsPercentage != 0 && !this->perServerMetricReported )
    {
      Myfirst = this->serverConnections._Mypair._Myval2._Myfirst; /*0x1410160ee*/
      Mylast = this->serverConnections._Mypair._Myval2._Mylast; /*0x1410160f5*/
      if ( Myfirst == Mylast )
      {
LABEL_45:
        RBX::Network::Client::reportConnectionLevelNetworkMetricToInflux(this, prefix: "StudioNetworkDetailed"); /*0x141016113*/
        this->perServerMetricReported = true; /*0x141016122*/
      }
      else
      {
        while ( 1 ) /*0x141016101*/
        {
          v26 = Myfirst->state; /*0x141016101*/
          if ( v26 <= 1 ) /*0x141016108*/
            break; /*0x141016108*/
          if ( ++Myfirst == Mylast ) /*0x141016111*/
            goto LABEL_45; /*0x141016111*/
        }
        if ( DFLog::NetworkTrace != 0 )
        {
          port = Myfirst->port; /*0x141016167*/
          if ( Myfirst->address._Mypair._Myval2._Myres >= 0x10 ) /*0x141016170*/
            Myfirst = (RBX::Network::Client::ServerConnection *)Myfirst->address._Mypair._Myval2._Bx._Ptr; /*0x141016172*/
          FLog::FastLogFormatted(
            level: DFLog::NetworkTrace,
            message: "[DFLog::NetworkTrace] reportPerServerMetric::: sc(%s:%d).state = %d :: returning false",
            Myfirst->address._Mypair._Myval2._Bx._Buf,
            port,
            v26);
        }
      }
    }
    if ( takeLock ) /*0x14101612c*/
      Mtx_unlock_0(a1: (_Mtx_t)&this->connectionStateAndJoinDataMutex); /*0x141016135*/
  }
}

// Address: 0x141016190 | Name: ?handleUpdateToken@Client@Network@RBX@@AEAAXPEAUPacket@RakNet@@@Z
void __fastcall RBX::Network::Client::handleUpdateToken(RBX::Network::Client *this, RakNet::Packet *packet)
{
  Luau::InternalErrorReporter *v3; // rax
  RBX::Network::Rupp::Rupp *Ptr; // rcx
  unsigned __int8 v5; // al
  const char *v6; // r8
  unsigned int length; // r8d
  __int16 v8; // ax
  unsigned int v9; // ebx
  std::string *p_logInfo; // rdx
  std::string *v11; // r8
  unsigned __int64 Myres; // rcx
  unsigned __int64 v13; // rdx
  char *v14; // rcx
  unsigned __int8 *Myfirst; // rcx
  std::_Ref_count_base *Rep; // rbx
  std::string logInfo; // [rsp+20h] [rbp-39h] BYREF
  std::shared_ptr<RBX::Network::Rupp::Rupp> rupp; // [rsp+40h] [rbp-19h] BYREF
  RBX::StringView v19; // [rsp+50h] [rbp-9h]
  RBX::StringView v20; // [rsp+60h] [rbp+7h] BYREF
  RBX::Network::NetworkStream bs; // [rsp+70h] [rbp+17h] BYREF

  if ( FFlag::RuppTokEn4.value ) /*0x1410161b1*/
  {
    if ( packet->length >= 0x12 && packet->data[1] == 16 ) /*0x1410161c9*/
    {
      v3 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410161d6*/
      ((void (__fastcall *)(Luau::InternalErrorReporter *, std::shared_ptr<RBX::Network::Rupp::Rupp> *))v3->onInternalError._Mystorage._Ptrs[0][96].__vftable)( /*0x1410161ec*/
        a1: v3,
        a2: &rupp);
      __wind /*0xf1c0000000000040*/
      {
        Ptr = rupp._Ptr; /*0x1410161f0*/
        if ( rupp._Ptr != nullptr ) /*0x1410161f7*/
        {
          v19.Data = (const char *)(packet->data + 2); /*0x141016201*/
          v19.Length = 16; /*0x141016205*/
          v20 = v19; /*0x141016211*/
          RBX::Network::Rupp::Rupp::updateTokenTlvValue(this: rupp._Ptr, setTokenValue: &v20); /*0x14101621a*/
          Ptr = rupp._Ptr; /*0x14101621f*/
        }
        v5 = DFLog::RuppTokenClientLog; /*0x141016223*/
        if ( DFLog::RuppTokenClientLog != 0 ) /*0x14101622c*/
        {
          v6 = "unprocessed."; /*0x141016235*/
          if ( Ptr != nullptr ) /*0x14101623f*/
            v6 = "ok."; /*0x14101623f*/
          FLog::FastLog( /*0x14101624d*/
            level: DFLog::RuppTokenClientLog,
            message: "[DFLog::RuppTokenClientLog] handleUpdateToken received %s",
            arg0: v6);
          v5 = DFLog::RuppTokenClientLog; /*0x141016252*/
        }
        length = packet->length; /*0x141016259*/
        if ( length >= 0x14 && v5 != 0 ) /*0x141016269*/
        {
          RBX::Network::NetworkStream::NetworkStream( /*0x14101627a*/
            this: &bs,
            _data: packet->data,
            lengthInBytes: length,
            copyData: false);
          __wind /*0xf1c0000000000028*/
          {
            RBX::Network::NetworkStream::IgnoreBytes(this: &bs, numberOfBytes: 0x12u); /*0x141016289*/
            v8 = RBX::Network::NetworkStream::readInt16(this: &bs); /*0x141016292*/
            logInfo._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141016299*/
            logInfo._Mypair._Myval2._Mysize = 0; /*0x14101629d*/
            Myres = 15; /*0x1410162a1*/
            logInfo._Mypair._Myval2._Myres = 15; /*0x1410162a6*/
            __wind /*0xf1c000000000001c*/
            {
              if ( v8 > 0 ) /*0x1410162b1*/
              {
                v9 = v8; /*0x1410162b3*/
                std::string::resize(this: &logInfo, _Newsize: v8 + 1, _Ch: 0); /*0x1410162c3*/
                p_logInfo = &logInfo; /*0x1410162c8*/
                if ( logInfo._Mypair._Myval2._Myres >= 0x10 ) /*0x1410162d1*/
                  p_logInfo = (std::string *)logInfo._Mypair._Myval2._Bx._Ptr; /*0x1410162d1*/
                RBX::Network::NetworkStream::readBytes(this: &bs, inOutByteArray: p_logInfo, numberOfBytesToRead: v9); /*0x1410162dd*/
                if ( DFLog::RuppTokenClientLog != 0 ) /*0x1410162eb*/
                {
                  v11 = &logInfo; /*0x1410162ed*/
                  if ( logInfo._Mypair._Myval2._Myres >= 0x10 ) /*0x1410162f6*/
                    v11 = (std::string *)logInfo._Mypair._Myval2._Bx._Ptr; /*0x1410162f6*/
                  FLog::FastLog( /*0x141016302*/
                    level: DFLog::RuppTokenClientLog,
                    message: "[DFLog::RuppTokenClientLog] ServerMsg = %s",
                    arg0: v11);
                }
                Myres = logInfo._Mypair._Myval2._Myres; /*0x141016307*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&logInfo); /*0xf1c0000000000014*/
            }
            if ( Myres >= 0x10 ) /*0x14101630f*/
            {
              v13 = Myres + 1; /*0x141016311*/
              v14 = logInfo._Mypair._Myval2._Bx._Ptr; /*0x141016315*/
              if ( v13 >= 0x1000 ) /*0x141016323*/
              {
                v14 = *((char **)logInfo._Mypair._Myval2._Bx._Ptr - 1); /*0x141016329*/
                if ( (unsigned __int64)(logInfo._Mypair._Myval2._Bx._Ptr - v14 - 8) > 0x1F ) /*0x141016338*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14101633a*/
              }
              operator delete(ptr: v14); /*0x141016341*/
            }
            logInfo._Mypair._Myval2._Mysize = 0; /*0x141016346*/
            logInfo._Mypair._Myval2._Myres = 15; /*0x14101634a*/
            logInfo._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141016352*/
            Myfirst = bs.dataVector._Mypair._Myval2._Myfirst; /*0x141016356*/
            if ( bs.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x14101635d*/
            {
              if ( (unsigned __int8 *)(bs.dataVector._Mypair._Myval2._Myend - bs.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x141016370*/
              {
                Myfirst = *((unsigned __int8 **)bs.dataVector._Mypair._Myval2._Myfirst - 1); /*0x141016376*/
                if ( (unsigned __int64)(bs.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x141016385*/
                  _invalid_parameter_noinfo_noreturn(); /*0x141016387*/
              }
              operator delete(ptr: Myfirst); /*0x14101638e*/
            }
          }
          __unwind
          {
            RBX::Network::NetworkStream::~NetworkStream(this: &bs); /*0xf1c0000000000038*/
          }
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&rupp); /*0xf1c0000000000008*/
      }
      Rep = rupp._Rep; /*0x141016394*/
      if ( rupp._Rep != nullptr /*0x1410163ac*/
        && _InterlockedExchangeAdd((volatile signed __int32 *)&rupp._Rep->_Uses, 0xFFFFFFFF) == 1 )
      {
        Rep->_Destroy(this: Rep); /*0x1410163b4*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410163be*/
          Rep->_Delete_this(this: Rep); /*0x1410163c6*/
      }
    }
    else if ( DFLog::RuppTokenClientLog != 0 ) /*0x1410163d4*/
    {
      FLog::FastLog( /*0x1410163e0*/
        level: DFLog::RuppTokenClientLog,
        message: "[DFLog::RuppTokenClientLog] handleUpdateToken bad length/fmt.",
        arg0: nullptr);
    }
  }
}

// Address: 0x141016400 | Name: ?isCloudEdit@Client@Network@RBX@@QEBA_NXZ
bool __fastcall RBX::Network::Client::isCloudEdit(RBX::Network::Client *this)
{
  return this->clientReplicationMode == ReplicationMode_StudioAsEditor; /*0x14101640a*/
}

// Address: 0x141016410 | Name: ?isCloudTest@Client@Network@RBX@@QEBA_NXZ
bool __fastcall RBX::Network::Client::isCloudTest(RBX::Network::Client *this)
{
  return this->clientReplicationMode == ReplicationMode_StudioAsClient; /*0x14101641a*/
}

// Address: 0x141016420 | Name: ?luaGetConnectionAcceptedSignal@Client@Network@RBX@@QEAAPEAV?$signal@$$A6AXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$shared_ptr@VInstance@RBX@@@2@@Z@rbx@@_N@Z
rbx::signal<void __cdecl(std::string,std::shared_ptr<RBX::Instance>)> *__fastcall RBX::Network::Client::luaGetConnectionAcceptedSignal(
        RBX::Network::Client *this,
        bool __formal)
{
  int v3; // ebx
  _WORD *v4; // rax
  char *Ptr; // rcx
  char *v6; // rcx
  std::string resource; // [rsp+20h] [rbp-98h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+40h] [rbp-78h] BYREF

  if ( DFInt::ClientReportLuaConnectionSignalsInfluxHundrethsPercentage != 0 && !reported_1 ) /*0x141016444*/
  {
    reported_1 = true; /*0x14101644a*/
    RBX::Analytics::InfluxDb::Points::Points( /*0x141016460*/
      this: &points,
      throttleHundredthsPercentage: -1,
      categoryType: kStandardType,
      priorityHundredthsPercentage: 0);
    __wind /*0xf1c0000000000028*/
    {
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "Signal", value: "ConnectionAccepted"); /*0x141016479*/
      v3 = DFInt::ClientReportLuaConnectionSignalsInfluxHundrethsPercentage; /*0x14101647e*/
      v4 = operator new(size: 0x20u); /*0x1410164a0*/
      resource._Mypair._Myval2._Mysize = 23; /*0x1410164a5*/
      resource._Mypair._Myval2._Myres = 31; /*0x1410164ae*/
      qmemcpy(v4, "ClientConnectionSignal", 22); /*0x1410164be*/
      v4[11] = (unsigned __int8)kConnectionSignalInfluxReportName[22]; /*0x1410164dc*/
      resource._Mypair._Myval2._Bx._Ptr = (char *)v4; /*0x1410164e3*/
      __wind /*0xf1c000000000001c*/
      {
        RBX::Analytics::InfluxDb::Points::report( /*0x1410164f8*/
          this: &points,
          &resource,
          throttleHundredthsPercentage: v3,
          blocking: false);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000014*/
      }
      if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x141016507*/
      {
        Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x14101650c*/
        if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101651b*/
        {
          Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x141016521*/
          if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141016530*/
            _invalid_parameter_noinfo_noreturn(); /*0x141016532*/
        }
        operator delete(ptr: Ptr); /*0x141016539*/
      }
      if ( points.userIdOverride._Mypair._Myval2._Myres >= 0x10 ) /*0x14101654b*/
      {
        v6 = points.userIdOverride._Mypair._Myval2._Bx._Ptr; /*0x141016550*/
        if ( points.userIdOverride._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141016562*/
        {
          v6 = *((char **)points.userIdOverride._Mypair._Myval2._Bx._Ptr - 1); /*0x141016568*/
          if ( (unsigned __int64)(points.userIdOverride._Mypair._Myval2._Bx._Ptr - v6 - 8) > 0x1F ) /*0x141016577*/
            _invalid_parameter_noinfo_noreturn(); /*0x141016579*/
        }
        operator delete(ptr: v6); /*0x141016580*/
      }
      *(__m128i *)&points.userIdOverride._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14101658d*/
      points.userIdOverride._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141016596*/
      std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&points); /*0x1410165a3*/
    }
    __unwind
    {
      RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c0000000000008*/
    }
  }
  return &this->connectionAcceptedSignal; /*0x1410165af*/
}

// Address: 0x1410165c0 | Name: ?luaGetConnectionFailedSignal@Client@Network@RBX@@QEAAPEAV?$signal@$$A6AXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@H0@Z@rbx@@_N@Z
rbx::signal<void __cdecl(std::string,int,std::string)> *__fastcall RBX::Network::Client::luaGetConnectionFailedSignal(
        RBX::Network::Client *this,
        bool __formal)
{
  int v3; // ebx
  char *v4; // rax
  char *Ptr; // rcx
  char *v6; // rcx
  std::string resource; // [rsp+20h] [rbp-98h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+40h] [rbp-78h] BYREF

  if ( DFInt::ClientReportLuaConnectionSignalsInfluxHundrethsPercentage != 0 && !reported_2 ) /*0x1410165e4*/
  {
    reported_2 = true; /*0x1410165ea*/
    RBX::Analytics::InfluxDb::Points::Points( /*0x141016600*/
      this: &points,
      throttleHundredthsPercentage: -1,
      categoryType: kStandardType,
      priorityHundredthsPercentage: 0);
    RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "Signal", value: "ConnectionFailed"); /*0x141016619*/
    v3 = DFInt::ClientReportLuaConnectionSignalsInfluxHundrethsPercentage; /*0x14101661e*/
    resource._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141016626*/
    v4 = (char *)operator new(size: 0x20u); /*0x141016640*/
    resource._Mypair._Myval2._Mysize = 23; /*0x141016645*/
    resource._Mypair._Myval2._Myres = 31; /*0x14101664e*/
    strcpy(v4, "ClientConnectionSignals"); /*0x14101665e*/
    resource._Mypair._Myval2._Bx._Ptr = v4; /*0x141016683*/
    RBX::Analytics::InfluxDb::Points::report( /*0x141016698*/
      this: &points,
      &resource,
      throttleHundredthsPercentage: v3,
      blocking: false);
    if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x1410166a7*/
    {
      Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x1410166ac*/
      if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410166bb*/
      {
        Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x1410166c1*/
        if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410166d0*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410166d2*/
      }
      operator delete(ptr: Ptr); /*0x1410166d9*/
    }
    if ( points.userIdOverride._Mypair._Myval2._Myres >= 0x10 ) /*0x1410166eb*/
    {
      v6 = points.userIdOverride._Mypair._Myval2._Bx._Ptr; /*0x1410166f0*/
      if ( points.userIdOverride._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141016702*/
      {
        v6 = *((char **)points.userIdOverride._Mypair._Myval2._Bx._Ptr - 1); /*0x141016708*/
        if ( (unsigned __int64)(points.userIdOverride._Mypair._Myval2._Bx._Ptr - v6 - 8) > 0x1F ) /*0x141016717*/
          _invalid_parameter_noinfo_noreturn(); /*0x141016719*/
      }
      operator delete(ptr: v6); /*0x141016720*/
    }
    *(__m128i *)&points.userIdOverride._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14101672d*/
    points.userIdOverride._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141016736*/
    std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&points); /*0x141016743*/
  }
  return &this->connectionFailedSignal; /*0x14101674f*/
}

// Address: 0x141016760 | Name: ?noViableConnectionsLeft@Client@Network@RBX@@AEAA_NXZ
char __fastcall RBX::Network::Client::noViableConnectionsLeft(RBX::Network::Client *this)
{
  RBX::Network::Client::ServerConnection *Myfirst; // r8
  RBX::Network::Client::ServerConnection *Mylast; // rdx
  unsigned int state; // ecx
  int port; // r9d

  Myfirst = this->serverConnections._Mypair._Myval2._Myfirst; /*0x141016764*/
  Mylast = this->serverConnections._Mypair._Myval2._Mylast; /*0x14101676b*/
  if ( Myfirst == Mylast ) /*0x141016775*/
    return 1; /*0x141016789*/
  while ( 1 ) /*0x141016777*/
  {
    state = Myfirst->state; /*0x141016777*/
    if ( state <= 2 ) /*0x14101677e*/
      break; /*0x14101677e*/
    if ( ++Myfirst == Mylast ) /*0x141016787*/
      return 1; /*0x141016787*/
  }
  if ( DFLog::NetworkTrace != 0 )
  {
    port = Myfirst->port; /*0x1410167a2*/
    if ( Myfirst->address._Mypair._Myval2._Myres >= 0x10 ) /*0x1410167a6*/
      Myfirst = (RBX::Network::Client::ServerConnection *)Myfirst->address._Mypair._Myval2._Bx._Ptr; /*0x1410167a8*/
    FLog::FastLogFormatted(
      level: DFLog::NetworkTrace,
      message: "[DFLog::NetworkTrace] noViableConnectionsLeft::: sc(%s:%d).state = %d :: returning false",
      Myfirst->address._Mypair._Myval2._Bx._Buf,
      port,
      state);
  }
  return 0; /*0x14101678b*/
}

// Address: 0x141016950 | Name: ?onClosing@Client@Network@RBX@@AEAAXXZ
void __fastcall RBX::Network::Client::onClosing(RBX::Network::Client *this)
{
  RBX::Network::ClientReplicator *clientReplicator; // rcx
  unsigned __int64 Myres; // rbx
  unsigned __int64 Mysize; // r11
  unsigned int v5; // r8d
  RBX::Network::Client::ServerConnection *Myfirst; // r10
  unsigned __int64 v7; // rdx
  __int64 v8; // rcx
  unsigned __int64 v9; // r15
  RBX::Network::Client::JoinState reportingJoinState; // ecx
  __int32 v11; // ecx
  __int32 v12; // ecx
  const char *v13; // r9
  RBX::Network::Client::ServerConnection *v14; // r9
  RBX::Network::Client::ServerConnection *Ptr; // rcx
  char *v16; // rdx
  char v17; // al
  __int64 v18; // rdx
  unsigned __int64 v19; // r8
  unsigned __int64 v20; // rdi
  std::string *p_metric; // rax
  char *v22; // rbx
  std::string *p_serverAddress; // r9
  std::string *v24; // rdx
  char *v25; // rcx
  char *v26; // rcx
  std::vector<std::shared_ptr<RBX::Instance>> *v27; // rax
  std::_Ref_count_base *Rep; // rbx
  std::shared_ptr<RBX::Instance> *Mylast; // rcx
  std::shared_ptr<RBX::Instance> *i; // rax
  RBX::Network::ConcurrentRakPeer *v31; // rcx
  Luau::InternalErrorReporter *v32; // rdi
  std::_Func_base<void,char const *>_vtbl *v33; // rbx
  __int64 v34; // r8
  Luau::InternalErrorReporter *v35; // rax
  std::string metric; // [rsp+30h] [rbp-D0h] BYREF
  std::string serverAddress; // [rsp+50h] [rbp-B0h] BYREF
  char _Ptr[1040]; // [rsp+80h] [rbp-80h] BYREF

  clientReplicator = this->clientReplicator; /*0x141016976*/
  if ( clientReplicator != nullptr ) /*0x141016980*/
    RBX::Network::Replicator::safeSetDisconnectReason(this: clientReplicator, reason: 0x11Du); /*0x141016987*/
  if ( !this->haveReportedEndOfSession )
  {
    __wind
    {
      __eh34_enter_wind_state(0, 1); /*0xf1c0000000000040*/
      Myres = 15; /*0x1410169a0*/
      metric._Mypair._Myval2._Myres = 15; /*0x1410169a5*/
      Mysize = 15; /*0x1410169aa*/
      metric._Mypair._Myval2._Mysize = 15; /*0x1410169ad*/
      qmemcpy(&metric, "OtherDisconnec", 14); /*0x1410169ba*/
      *(_WORD *)&metric._Mypair._Myval2._Bx._Alias[14] = (unsigned __int8)aOtherdisconnec[14]; /*0x1410169dd*/
      v5 = 0; /*0x1410169e8*/
      Myfirst = this->serverConnections._Mypair._Myval2._Myfirst; /*0x1410169eb*/
      v7 = this->serverConnections._Mypair._Myval2._Mylast - Myfirst; /*0x141016a14*/
      if ( v7 != 0 )
      {
        v8 = 0; /*0x141016a19*/
        while ( Myfirst[v8].state != ConnectionState_Connected ) /*0x141016a2d*/
        {
          v8 = ++v5; /*0x141016a32*/
          if ( v5 >= v7 ) /*0x141016a38*/
            goto LABEL_9; /*0x141016a38*/
        }
        v14 = &Myfirst[v8]; /*0x141016a8e*/
        Ptr = v14; /*0x141016a91*/
        if ( v14->address._Mypair._Myval2._Myres >= 0x10 ) /*0x141016a99*/
          Ptr = (RBX::Network::Client::ServerConnection *)v14->address._Mypair._Myval2._Bx._Ptr; /*0x141016a9b*/
        v16 = (char *)(_Ptr - (char *)Ptr); /*0x141016aa2*/
        do /*0x141016abc*/
        {
          v17 = Ptr->address._Mypair._Myval2._Bx._Buf[0]; /*0x141016ab0*/
          Ptr->address._Mypair._Myval2._Bx._Buf[(_QWORD)v16] = Ptr->address._Mypair._Myval2._Bx._Buf[0]; /*0x141016ab3*/
          Ptr = (RBX::Network::Client::ServerConnection *)((char *)Ptr + 1); /*0x141016ab6*/
        }
        while ( v17 != 0 ); /*0x141016abc*/
        v18 = -1; /*0x141016ac2*/
        do /*0x141016acc*/
          ++v18; /*0x141016ac5*/
        while ( _Ptr[v18] != 0 ); /*0x141016acc*/
        _Ptr[(int)v18] = 124; /*0x141016ad1*/
        Itoa(value: v14->port, result: &_Ptr[(int)v18 + 1], base: 10); /*0x141016aed*/
        if ( DFLog::NetworkTrace != 0 )
        {
          if ( __eh34_unwind(1) ) /*0xf1c000000000002c*/
          {
unwind_state_1:
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&serverAddress); /*0xf1c0000000000014*/
            __eh34_continue_unwinding(1, 0); /*0xf1c0000000000018*/
          }
          __eh34_exit_wind_state(1, 0); /*0xf1c0000000000030*/
          FLog::FastLogFormatted(
            level: DFLog::NetworkTrace,
            message: "[DFLog::NetworkTrace] getConnectedServer::: returning %s",
            _Ptr);
          __eh34_enter_wind_state(0, 1); /*0xf1c0000000000024*/
        }
        serverAddress._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141016b0f*/
        serverAddress._Mypair._Myval2._Mysize = 0; /*0x141016b14*/
        serverAddress._Mypair._Myval2._Myres = 15; /*0x141016b19*/
        v19 = -1; /*0x141016b27*/
        do /*0x141016b37*/
          ++v19; /*0x141016b30*/
        while ( _Ptr[v19] != 0 ); /*0x141016b37*/
        std::string::assign(this: &serverAddress, _Ptr, _Count: v19); /*0x141016b42*/
        Myres = metric._Mypair._Myval2._Myres; /*0x141016b47*/
        Mysize = metric._Mypair._Myval2._Mysize; /*0x141016b4c*/
        v9 = serverAddress._Mypair._Myval2._Myres; /*0x141016b51*/
      }
      else
      {
LABEL_9:
        serverAddress._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141016a3a*/
        v9 = 15; /*0x141016a3f*/
        serverAddress._Mypair._Myval2._Myres = 15; /*0x141016a42*/
        serverAddress._Mypair._Myval2._Mysize = 0; /*0x141016a47*/
      }
      reportingJoinState = this->reportingJoinState; /*0x141016a51*/
      if ( reportingJoinState != JoinState_NotStartedYet ) /*0x141016a59*/
      {
        v11 = reportingJoinState - 1; /*0x141016a5f*/
        if ( v11 != 0 ) /*0x141016a62*/
        {
          v12 = v11 - 1; /*0x141016a68*/
          if ( v12 != 0 ) /*0x141016a6b*/
          {
            if ( v12 == 1 ) /*0x141016a74*/
              v13 = "_AfterLoadFinished"; /*0x141016b5b*/
            else
              v13 = pass; /*0x141016a7a*/
          }
          else
          {
            v13 = "_BeforeLoadFinished"; /*0x141016b64*/
          }
        }
        else
        {
          v13 = "_BeforeConnected"; /*0x141016b6d*/
        }
      }
      else
      {
        v13 = "_NotStartedYet"; /*0x141016b76*/
      }
      v20 = -1; /*0x141016b7d*/
      do /*0x141016b88*/
        ++v20; /*0x141016b80*/
      while ( v13[v20] != 0 ); /*0x141016b88*/
      if ( v20 > Myres - Mysize ) /*0x141016b93*/
      {
        std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x141016bd5*/
          this: &metric,
          _Size_increase: v20,
          _Fn: 0,
          <_Args_0>: v13,
          <_Args_1>: v20);
      }
      else
      {
        metric._Mypair._Myval2._Mysize = v20 + Mysize; /*0x141016b99*/
        p_metric = &metric; /*0x141016b9e*/
        if ( Myres >= 0x10 ) /*0x141016ba7*/
          p_metric = (std::string *)metric._Mypair._Myval2._Bx._Ptr; /*0x141016ba7*/
        v22 = &p_metric->_Mypair._Myval2._Bx._Buf[Mysize]; /*0x141016bad*/
        memmove_0(a1: &p_metric->_Mypair._Myval2._Bx._Buf[Mysize], Src: v13, Size: v20); /*0x141016bba*/
        v22[v20] = 0; /*0x141016bbf*/
      }
      p_serverAddress = &serverAddress; /*0x141016bda*/
      if ( v9 >= 0x10 ) /*0x141016be3*/
        p_serverAddress = (std::string *)serverAddress._Mypair._Myval2._Bx._Ptr; /*0x141016be3*/
      v24 = &metric; /*0x141016be9*/
      if ( metric._Mypair._Myval2._Myres >= 0x10 ) /*0x141016bf4*/
        v24 = (std::string *)metric._Mypair._Myval2._Bx._Ptr; /*0x141016bf4*/
      RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x141016c0d*/
        this,
        metric: v24->_Mypair._Myval2._Bx._Buf,
        connectionFailed: true,
        serverAddress: p_serverAddress->_Mypair._Myval2._Bx._Buf,
        state: ConnectionState_Closed,
        takeLock: true);
      if ( __eh34_unwind(1) ) /*0xf1c0000000000010*/
        goto unwind_state_1; /*0xf1c0000000000010*/
      __eh34_exit_wind_state(1, 0); /*0xf1c000000000001c*/
      if ( serverAddress._Mypair._Myval2._Myres >= 0x10 ) /*0x141016c1c*/
      {
        v25 = serverAddress._Mypair._Myval2._Bx._Ptr; /*0x141016c21*/
        if ( serverAddress._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141016c30*/
        {
          v25 = *((char **)serverAddress._Mypair._Myval2._Bx._Ptr - 1); /*0x141016c36*/
          if ( (unsigned __int64)(serverAddress._Mypair._Myval2._Bx._Ptr - v25 - 8) > 0x1F ) /*0x141016c45*/
            _invalid_parameter_noinfo_noreturn(); /*0x141016c47*/
        }
        operator delete(ptr: v25); /*0x141016c4e*/
      }
      if ( metric._Mypair._Myval2._Myres >= 0x10 ) /*0x141016c5d*/
      {
        v26 = metric._Mypair._Myval2._Bx._Ptr; /*0x141016c62*/
        if ( metric._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141016c71*/
        {
          v26 = *((char **)metric._Mypair._Myval2._Bx._Ptr - 1); /*0x141016c77*/
          if ( (unsigned __int64)(metric._Mypair._Myval2._Bx._Ptr - v26 - 8) > 0x1F ) /*0x141016c86*/
            _invalid_parameter_noinfo_noreturn(); /*0x141016c88*/
        }
        operator delete(ptr: v26); /*0x141016c8f*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&metric); /*0xf1c0000000000008*/
    }
  }
  if ( FLog::Network != 0 ) /*0x141016c9d*/
    FLog::FastLog(level: FLog::Network, message: "[FLog::Network] Client:Disconnect", arg0: nullptr); /*0x141016ca9*/
  v27 = this->children.object._Ptr; /*0x141016cae*/
  if ( v27 != nullptr ) /*0x141016cb5*/
  {
    Rep = this->children.object._Rep; /*0x141016cb7*/
    if ( Rep != nullptr ) /*0x141016cbe*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141016cc0*/
      v27 = this->children.object._Ptr; /*0x141016cc4*/
      Rep = this->children.object._Rep; /*0x141016cc8*/
    }
    Mylast = v27->_Mypair._Myval2._Mylast; /*0x141016ccc*/
    for ( i = v27->_Mypair._Myval2._Myfirst; i != Mylast; ++i ) /*0x141016cd6*/
      i->_Ptr->isParentLocked = false; /*0x141016ce3*/
    if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141016d00*/
    {
      Rep->_Destroy(this: Rep); /*0x141016d08*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141016d14*/
        Rep->_Delete_this(this: Rep); /*0x141016d1c*/
    }
  }
  RBX::Instance::removeAllChildren(this); /*0x141016d22*/
  v31 = this->rakPeer._Ptr; /*0x141016d27*/
  if ( v31 != nullptr ) /*0x141016d31*/
  {
    v32 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)v31); /*0x141016d38*/
    v33 = v32->onInternalError._Mystorage._Ptrs[0][27].__vftable; /*0x141016d3e*/
    RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)&serverAddress); /*0x141016d4a*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)&serverAddress._Mypair._Myval2._Mysize); /*0x141016d54*/
    serverAddress._Mypair._Myval2._Bx._Ptr = (char *)RakNet::UNASSIGNED_RAKNET_GUID_14.g; /*0x141016d60*/
    *(_WORD *)&serverAddress._Mypair._Myval2._Bx._Alias[8] = RakNet::UNASSIGNED_RAKNET_GUID_14.systemIndex; /*0x141016d6c*/
    RakNet::SystemAddress::operator=( /*0x141016d7d*/
      this: (RakNet::SystemAddress *)&serverAddress._Mypair._Myval2._Mysize,
      input: &this->serverId);
    LOBYTE(v34) = 1; /*0x141016d8d*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, std::string *, __int64, _QWORD, int))v33)( /*0x141016d98*/
      a1: v32,
      a2: &serverAddress,
      a3: v34,
      a4: 0,
      a5: 3);
    v35 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141016da1*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD))v35->onInternalError._Mystorage._Ptrs[0][13].__vftable)( /*0x141016dae*/
      a1: v35,
      a2: 0);
  }
}

// Address: 0x141017230 | Name: ?onServiceProvider@Client@Network@RBX@@MEAAXPEAVServiceProvider@3@0@Z
void __fastcall RBX::Network::Client::onServiceProvider(
        RBX::Network::Client *this,
        RBX::ServiceProvider *oldProvider,
        RBX::ServiceProvider *newProvider)
{
  RBX::Players **v6; // rax
  RBX::DataModel *v7; // rax
  RBX::Verb *Myval2; // rcx
  RBX::Players *v9; // r12
  rbx::signals::slot_base *v10; // rsi
  unsigned int parent; // ebx
  __int64 v12; // rcx
  rbx::signals::slot_base *p; // rcx
  rbx::signals::signal_base *p_playerRemovingSignal; // r12
  rbx::signals::slot_base *v15; // rax
  rbx::signals::slot_base *v16; // rsi
  unsigned int v17; // ebx
  __int64 v18; // rcx
  rbx::signals::slot_base *v19; // rcx
  rbx::signal<void __cdecl(void)> *p_closingSignal; // r15
  rbx::signals::slot_base *v21; // rax
  rbx::signals::slot_base *v22; // rsi
  unsigned int v23; // ebx
  __int64 v24; // rcx
  rbx::signals::slot_base *v25; // rcx
  RBX::DataModel *v26; // rax
  rbx::signals::signal_base *p_requestProfilerDataSignal; // r15
  rbx::signals::slot_base *v28; // rax
  rbx::signals::slot_base *v29; // rsi
  unsigned int v30; // ebx
  __int64 v31; // rcx
  rbx::signals::scoped_connection *p_requestProfilerDataConnection; // rdi
  rbx::signals::slot_base *v33; // rcx
  _BYTE v34[32]; // [rsp+0h] [rbp-50h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v35; // [rsp+20h] [rbp-30h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v36; // [rsp+24h] [rbp-2Ch] BYREF
  rbx::signals::connection other; // [rsp+28h] [rbp-28h] BYREF
  rbx::signals::connection con; // [rsp+30h] [rbp-20h] BYREF
  rbx::signals::connection v39; // [rsp+38h] [rbp-18h] BYREF
  rbx::signals::connection v40; // [rsp+40h] [rbp-10h] BYREF
  rbx::signals::slot_base *v41; // [rsp+48h] [rbp-8h]
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v42; // [rsp+A0h] [rbp+50h] BYREF
  rbx::signals::slot_base *v43; // [rsp+A8h] [rbp+58h] BYREF

  if ( oldProvider != nullptr ) /*0x14101725a*/
  {
    rbx::signals::connection::disconnect(this: &this->closingConnection.con); /*0x141017263*/
    rbx::signals::connection::disconnect(this: &this->extAntiCheatConnectConnection.con); /*0x14101726f*/
    rbx::signals::connection::disconnect(this: &this->extAntiCheatDisconnectConnection.con); /*0x14101727b*/
    if ( FFlag::ProfilerDataToSignal.value ) /*0x141017287*/
      rbx::signals::connection::disconnect(this: &this->requestProfilerDataConnection.con); /*0x141017290*/
    RBX::Network::Client::onClosing(this); /*0x141017298*/
    v6 = (RBX::Players **)RBX::ServiceProvider::refByClass<RBX::Players>(this: oldProvider); /*0x1410172a0*/
    RBX::Players::setConnection(this: *v6, rakPeer: nullptr); /*0x1410172aa*/
  }
  RBX::Network::Peer::onServiceProvider(this, oldProvider, newProvider); /*0x1410172b8*/
  if ( newProvider != nullptr ) /*0x1410172c0*/
  {
    v7 = RBX::DataModel::get(context: this); /*0x1410172c9*/
    if ( v7 != nullptr ) /*0x1410172d1*/
    {
      Myval2 = v7->lockVerb._Mypair._Myval2; /*0x1410172d3*/
      if ( Myval2 != nullptr ) /*0x1410172dd*/
        Myval2->doIt(this: Myval2, a2: nullptr); /*0x1410172e4*/
    }
    v9 = RBX::ServiceProvider::create<RBX::Players>(this: newProvider); /*0x1410172ef*/
    RBX::Players::setConnection(this: v9, rakPeer: this->rakPeer._Ptr); /*0x1410172fc*/
    __wind /*0xf1c0000000000178*/
    {
      parent = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x141017314*/
      v42.parent = parent; /*0x141017316*/
      __wind /*0xf1c0000000000154*/
      {
        v10 = (rbx::signals::slot_base *)operator new(size: 0x30u); /*0x141017323*/
        v43 = v10; /*0x141017326*/
        if ( v10 != nullptr ) /*0x14101733b*/
        {
          v10->strong._Storage._Value = 0; /*0x14101733d*/
          v10->weak._Storage._Value = 1; /*0x141017340*/
          v10->call = (void (__fastcall *)(rbx::signals::slot_base *))rbx::signals::slot_with_functor<void (*)(std::shared_ptr<RBX::Instance>),std::shared_ptr<RBX::Player>>::do_call; /*0x141017347*/
          v10->dtor = (void (__fastcall *)(rbx::signals::slot_base *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x14101734b*/
          v10->next.px = nullptr; /*0x14101734f*/
          v10->owner = &v9->playerAddedSignal; /*0x141017353*/
          v10[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)RBX::Network::ExtAntiCheatCommunicator::onConnect; /*0x14101735e*/
          rbx::signals::signal_base::insert(this: &v9->playerAddedSignal, item: v10); /*0x141017368*/
          other.weak_slot.p_ = v10; /*0x14101736d*/
          _InterlockedIncrement(&v10->weak._Storage._Value); /*0x141017376*/
          parent = v42.parent; /*0x14101737a*/
        }
        else
        {
          rbx::signals::signal_base::insert(this: &v9->playerAddedSignal, item: nullptr); /*0x141017384*/
          other.weak_slot.p_ = nullptr; /*0x141017389*/
        }
      }
      __unwind
      {
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v42); /*0xf1c0000000000164*/
      }
      __wind /*0xf1c000000000016c*/
      {
        RBX::Memory::setCurrentCategory(category: parent); /*0x141017396*/
      }
      __unwind
      {
        __std_terminate(a1: v12, a2: v34); /*0x142f39fa8*/
      }
      if ( rbx::signals::connection::operator!=(this: &this->extAntiCheatConnectConnection.con, &other) ) /*0x1410173a7*/
      {
        rbx::signals::connection::disconnect(this: &this->extAntiCheatConnectConnection.con); /*0x1410173b7*/
        rbx::signals::connection::operator=(this: &this->extAntiCheatConnectConnection.con, con: &other); /*0x1410173c7*/
      }
    }
    __unwind
    {
    }
    p = other.weak_slot.p_; /*0x1410173d6*/
    if ( other.weak_slot.p_ != nullptr /*0x1410173ea*/
      && _InterlockedExchangeAdd(&other.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
    {
      operator delete(ptr: p); /*0x1410173ec*/
    }
    p_playerRemovingSignal = &v9->playerRemovingSignal; /*0x1410173f1*/
    __wind /*0xf1c0000000000130*/
    {
      v17 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x141017403*/
      LODWORD(v43) = v17; /*0x141017405*/
      __wind /*0xf1c000000000010c*/
      {
        v15 = (rbx::signals::slot_base *)operator new(size: 0x30u); /*0x14101740d*/
        v16 = v15; /*0x141017412*/
        v41 = v15; /*0x141017415*/
        if ( v15 != nullptr ) /*0x14101741f*/
        {
          v15->strong._Storage._Value = 0; /*0x141017421*/
          v15->weak._Storage._Value = 1; /*0x141017424*/
          v15->call = (void (__fastcall *)(rbx::signals::slot_base *))rbx::signals::slot_with_functor<void (*)(std::shared_ptr<RBX::Instance>),std::shared_ptr<RBX::Player>>::do_call; /*0x141017432*/
          v15->dtor = (void (__fastcall *)(rbx::signals::slot_base *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x14101743d*/
          v15->next.px = nullptr; /*0x141017441*/
          v15->owner = p_playerRemovingSignal; /*0x141017445*/
          v15[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)RBX::Network::ExtAntiCheatCommunicator::onDisconnect; /*0x141017450*/
          rbx::signals::signal_base::insert(this: p_playerRemovingSignal, item: v15); /*0x141017457*/
          con.weak_slot.p_ = v16; /*0x14101745c*/
          _InterlockedIncrement(&v16->weak._Storage._Value); /*0x141017465*/
          v17 = (unsigned int)v43; /*0x141017469*/
        }
        else
        {
          rbx::signals::signal_base::insert(this: p_playerRemovingSignal, item: nullptr); /*0x141017470*/
          con.weak_slot.p_ = nullptr; /*0x141017475*/
        }
      }
      __unwind
      {
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&v43); /*0xf1c000000000011c*/
      }
      __wind /*0xf1c0000000000124*/
      {
        RBX::Memory::setCurrentCategory(category: v17); /*0x141017482*/
      }
      __unwind
      {
        __std_terminate(a1: v18, a2: v34); /*0xf1c000000000004c*/
      }
      if ( rbx::signals::connection::operator!=(this: &this->extAntiCheatDisconnectConnection.con, other: &con) ) /*0x141017493*/
      {
        rbx::signals::connection::disconnect(this: &this->extAntiCheatDisconnectConnection.con); /*0x1410174a3*/
        rbx::signals::connection::operator=(this: &this->extAntiCheatDisconnectConnection.con, &con); /*0x1410174b3*/
      }
    }
    __unwind
    {
    }
    v19 = con.weak_slot.p_; /*0x1410174bc*/
    if ( con.weak_slot.p_ != nullptr /*0x1410174d0*/
      && _InterlockedExchangeAdd(&con.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
    {
      operator delete(ptr: v19); /*0x1410174d2*/
    }
    p_closingSignal = &newProvider->closingSignal; /*0x1410174d7*/
    __wind /*0xf1c00000000000e8*/
    {
      v23 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x1410174e9*/
      v35.parent = v23; /*0x1410174eb*/
      __wind /*0xf1c00000000000c4*/
      {
        v21 = (rbx::signals::slot_base *)operator new(size: 0x30u); /*0x1410174f3*/
        v22 = v21; /*0x1410174f8*/
        v41 = v21; /*0x1410174fb*/
        if ( v21 != nullptr ) /*0x141017505*/
        {
          v21->strong._Storage._Value = 0; /*0x141017507*/
          v21->weak._Storage._Value = 1; /*0x14101750a*/
          v21->call = rbx::signals::slot_with_functor__lambda_ab19a070f052cfe6415bb1ea8166749e___::do_call; /*0x141017518*/
          v21->dtor = (void (__fastcall *)(rbx::signals::slot_base *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x141017523*/
          v21->next.px = nullptr; /*0x141017527*/
          v21->owner = p_closingSignal; /*0x14101752b*/
          v21[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)this; /*0x14101752f*/
          rbx::signals::signal_base::insert(this: p_closingSignal, item: v21); /*0x141017536*/
          v39.weak_slot.p_ = v22; /*0x14101753b*/
          _InterlockedIncrement(&v22->weak._Storage._Value); /*0x141017544*/
          v23 = v35.parent; /*0x141017548*/
        }
        else
        {
          rbx::signals::signal_base::insert(this: p_closingSignal, item: nullptr); /*0x14101754f*/
          v39.weak_slot.p_ = nullptr; /*0x141017554*/
        }
      }
      __unwind
      {
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v35); /*0xf1c00000000000d4*/
      }
      __wind /*0xf1c00000000000dc*/
      {
        RBX::Memory::setCurrentCategory(category: v23); /*0x141017561*/
      }
      __unwind
      {
        __std_terminate(a1: v24, a2: v34); /*0xf1c0000000000054*/
      }
      if ( rbx::signals::connection::operator!=(this: &this->closingConnection.con, other: &v39) ) /*0x141017572*/
      {
        rbx::signals::connection::disconnect(this: &this->closingConnection.con); /*0x141017582*/
        rbx::signals::connection::operator=(this: &this->closingConnection.con, con: &v39); /*0x141017592*/
      }
    }
    __unwind
    {
    }
    v25 = v39.weak_slot.p_; /*0x14101759b*/
    if ( v39.weak_slot.p_ != nullptr /*0x1410175af*/
      && _InterlockedExchangeAdd(&v39.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
    {
      operator delete(ptr: v25); /*0x1410175b1*/
    }
    if ( FFlag::ProfilerDataToSignal.value ) /*0x1410175bd*/
    {
      v26 = RBX::DataModel::get(context: this); /*0x1410175c6*/
      if ( v26 != nullptr ) /*0x1410175ce*/
      {
        p_requestProfilerDataSignal = &v26->requestProfilerDataSignal; /*0x1410175d4*/
        __wind /*0xf1c00000000000a0*/
        {
          v30 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x1410175e6*/
          v36.parent = v30; /*0x1410175e8*/
          __wind /*0xf1c000000000007c*/
          {
            v28 = (rbx::signals::slot_base *)operator new(size: 0x30u); /*0x1410175f0*/
            v29 = v28; /*0x1410175f5*/
            v41 = v28; /*0x1410175f8*/
            if ( v28 != nullptr ) /*0x141017602*/
            {
              v28->strong._Storage._Value = 0; /*0x141017604*/
              v28->weak._Storage._Value = 1; /*0x141017607*/
              v28->call = rbx::signals::slot_with_functor__lambda_5c5189a2b15c848ee95f6d75547a4f70___::do_call; /*0x141017615*/
              v28->dtor = (void (__fastcall *)(rbx::signals::slot_base *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x141017620*/
              v28->next.px = nullptr; /*0x141017624*/
              v28->owner = p_requestProfilerDataSignal; /*0x141017628*/
              v28[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)this; /*0x14101762c*/
              rbx::signals::signal_base::insert(this: p_requestProfilerDataSignal, item: v28); /*0x141017633*/
              v40.weak_slot.p_ = v29; /*0x141017638*/
              _InterlockedIncrement(&v29->weak._Storage._Value); /*0x141017641*/
              v30 = v36.parent; /*0x141017645*/
            }
            else
            {
              rbx::signals::signal_base::insert(this: p_requestProfilerDataSignal, item: nullptr); /*0x14101764c*/
              v40.weak_slot.p_ = nullptr; /*0x141017651*/
            }
          }
          __unwind
          {
            RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v36); /*0xf1c000000000008c*/
          }
          __wind /*0xf1c0000000000094*/
          {
            RBX::Memory::setCurrentCategory(category: v30); /*0x14101765e*/
          }
          __unwind
          {
            __std_terminate(a1: v31, a2: v34); /*0xf1c000000000005c*/
          }
          p_requestProfilerDataConnection = &this->requestProfilerDataConnection; /*0x141017664*/
          if ( rbx::signals::connection::operator!=(this: &p_requestProfilerDataConnection->con, other: &v40) ) /*0x141017672*/
          {
            rbx::signals::connection::disconnect(this: &p_requestProfilerDataConnection->con); /*0x14101767e*/
            rbx::signals::connection::operator=(this: &p_requestProfilerDataConnection->con, con: &v40); /*0x14101768a*/
          }
        }
        __unwind
        {
          rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v40); /*0x1431e5ac1*/
        }
        v33 = v40.weak_slot.p_; /*0x141017690*/
        if ( v40.weak_slot.p_ != nullptr /*0x1410176a3*/
          && _InterlockedExchangeAdd(&v40.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
        {
          operator delete(ptr: v33); /*0x1410176a5*/
        }
      }
    }
  }
}

// Address: 0x1410176d0 | Name: ?playerConnect@Client@Network@RBX@@QEAAX_JV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@HHHH1_NV?$shared_ptr@$$CBV?$unordered_map@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@VVariant@Reflection@RBX@@U?$hash@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@U?$equal_to@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@V?$allocator@U?$pair@$$CBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@VVariant@Reflection@RBX@@@std@@@2@@std@@@5@AEBV?$vector@UServerConnection@Client@Network@RBX@@V?$allocator@UServerConnection@Client@Network@RBX@@@std@@@5@4AEAUToken@TokenTlv@Rupp@23@2@Z
void __fastcall RBX::Network::Client::playerConnect(
        RBX::Network::Client *this,
        __int64 userId,
        RBX::Graphics::ProfilerAdorn::Item *server_deprecated,
        int serverPort,
        int clientPort,
        int threadSleepTime,
        int dataCenterId,
        RBX::Graphics::ProfilerAdorn::Item *userName,
        bool isUnder13,
        std::shared_ptr<RBX::File> *playerInfoTable,
        std::vector<RBX::Network::Client::ServerConnection> *serverConnectionsArg,
        std::vector<RBX::Network::Client::ServerConnection> *udmuxEndpointsArg,
        RBX::Network::Rupp::TokenTlv::Token *token,
        bool directServerReturn)
{
  rtc::webrtc_checks_impl::ToStringVal *v15; // r15
  Luau::InternalErrorReporter *v17; // rax
  int v18; // r14d
  rtc::webrtc_checks_impl::ToStringVal *Ptr; // rcx
  std::vector<RBX::Network::Client::ServerConnection> *p_serverConnections; // r13
  RBX::Network::Client::ServerConnection *v21; // rax
  std::vector<RBX::Network::Client::ServerConnection> *v22; // r9
  RBX::Network::Client::ServerConnection *Mylast; // rdi
  RBX::Network::Client::ServerConnection *Myfirst; // rbx
  Luau::InternalErrorReporter *v25; // rax
  std::_Func_base<void,char const *>_vtbl *v26; // r10
  RBX::Network::Client::ServerConnection *v27; // r9
  RBX::Network::Rupp::RuppError::ErrorCode v28; // eax
  const char *v29; // rdx
  unsigned __int64 v30; // r8
  std::reverse_iterator<RBX::Network::Client::ServerConnection const *> v31; // r8
  std::reverse_iterator<RBX::Network::Client::ServerConnection const *> v32; // r9
  rtc::webrtc_checks_impl::ToStringVal *v33; // rax
  RBX::Network::Client::ServerConnection *v34; // rax
  Luau::InternalErrorReporter *v35; // rax
  std::_Func_base<void,char const *>_vtbl *v36; // r10
  rtc::webrtc_checks_impl::ToStringVal *v37; // r9
  RBX::Network::Client::ServerConnection *v38; // rdi
  RBX::Network::Client::ServerConnection *v39; // rbx
  unsigned __int8 v40; // cl
  const char *v41; // rax
  const char *v42; // r8
  RBX::Network::Client::ServerConnection *v43; // rdi
  RBX::Network::Client::ServerConnection *v44; // rbx
  unsigned __int8 v45; // al
  const char *v46; // r8
  const std::unordered_map<std::string,RBX::Reflection::Variant> *v47; // r9
  __int64 v48; // rcx
  unsigned __int64 i; // rdx
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > > *v50; // r14
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v51; // rdi
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *Myhead; // r15
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v53; // r14
  char **p_Myval; // rdx
  const RBX::Reflection::Type *type; // rbx
  const RBX::Reflection::Type *v56; // r14
  __int64 *data; // rax
  __int64 v58; // rbx
  const rbx::implementation::type_holder *holder; // rax
  __int64 v60; // rcx
  bool v61; // di
  RBX::Network::Client::ServerConnection *v62; // r8
  RBX::Network::Client::ServerConnection *v63; // rcx
  const char *v64; // r14
  unsigned int v65; // eax
  double v66; // xmm0_8
  unsigned __int64 v67; // rcx
  unsigned __int64 v68; // rbx
  int v69; // r9d
  double v70; // xmm0_8
  unsigned __int64 v71; // rcx
  double v72; // xmm0_8
  unsigned __int64 v73; // rcx
  const char *v74; // r8
  bool v75; // al
  Luau::InternalErrorReporter *v76; // rax
  RBX::Network::Client::ServerConnection *v77; // r8
  RBX::Network::Client::ServerConnection *v78; // rcx
  unsigned int state; // eax
  std::unordered_map<std::string,std::string> *v80; // rbx
  int v81; // r9d
  RakNet::SocketDescriptor *v82; // r15
  RBX::DataModel *v83; // rdi
  RBX::DataModel *v84; // rbx
  RBX::ServiceProvider *ServiceProvider; // rax
  RBX::Players *v86; // rax
  std::_Ref_count_base *Rep; // rcx
  __int64 v88; // r12
  RakNet::SocketDescriptor *v89; // rdi
  RakNet::SocketDescriptor *v90; // rdi
  RakNet::SocketDescriptor *v91; // rbx
  int v92; // r14d
  int v93; // r13d
  __int64 v94; // rbx
  __int64 v95; // rdi
  RBX::Network::Client::ServerConnection *v96; // rdx
  int v97; // eax
  RBX::Network::Client::ServerConnection *v98; // r8
  int v99; // r9d
  RBX::DataModel *v100; // rax
  int *v101; // rbx
  Luau::InternalErrorReporter *v102; // rax
  std::_Func_base<void,char const *>_vtbl *v103; // r10
  char *v104; // r9
  char *v105; // rcx
  char *v106; // rdx
  char v107; // al
  __int64 v108; // rdx
  RBX::ServiceProvider *v109; // rax
  unsigned __int8 v110; // al
  bool value; // bl
  Luau::InternalErrorReporter *v112; // rax
  Luau::InternalErrorReporter *v113; // rax
  char v114; // bl
  int v115; // r13d
  __int64 v116; // r14
  Luau::InternalErrorReporter *v117; // rax
  std::_Func_base<void,char const *>_vtbl *v118; // r10
  std::string *v119; // r9
  RBX::Network::Client::ServerConnection *v120; // rdx
  __int64 port_low; // r8
  int v122; // edi
  RBX::Network::Client::ServerConnection *v123; // rcx
  RBX::Network::Client::ServerConnection *v124; // r9
  RBX::Network::Client::ServerConnection *v125; // rcx
  char *v126; // rdx
  char v127; // al
  __int64 v128; // rdx
  float v129; // xmm2_4
  const char *v130; // rdx
  RBX::Network::Client::ServerConnection *v131; // r8
  int v132; // r9d
  RBX::Network::Client::ServerConnection *v133; // r8
  int v134; // r9d
  RBX::Network::Client::ServerConnection *v135; // r8
  int v136; // r9d
  RBX::Graphics::ProfilerAdorn::Item *v137; // rbx
  Luau::InternalErrorReporter *v138; // rax
  std::_Func_base<void,char const *>_vtbl *v139; // r9
  Luau::InternalErrorReporter *v140; // rax
  std::_Func_base<void,char const *>_vtbl *v141; // r9
  RakNet::SocketDescriptor *v142; // r8
  void (__fastcall *v143)(std::shared_ptr<RBX::File> *); // rdx
  void *v144; // rcx
  const char *v145; // rax
  RBX::ContentId *v146; // rax
  const char *v147; // rax
  __int64 v148; // [rsp+8h] [rbp-100h] BYREF
  std::forward_iterator_tag __formal[8]; // [rsp+28h] [rbp-E0h]
  bool takeLock[4]; // [rsp+30h] [rbp-D8h]
  int v151; // [rsp+38h] [rbp-D0h]
  char v152; // [rsp+58h] [rbp-B0h]
  int port; // [rsp+5Ch] [rbp-ACh]
  std::vector<RakNet::SocketDescriptor> sdArray; // [rsp+60h] [rbp-A8h] BYREF
  RakNet::SocketDescriptor *v155; // [rsp+78h] [rbp-90h]
  std::runtime_error pExceptionObject; // [rsp+80h] [rbp-88h] BYREF
  __int64 v157; // [rsp+98h] [rbp-70h]
  RBX::Time result; // [rsp+A0h] [rbp-68h] BYREF
  std::string rccAddress; // [rsp+A8h] [rbp-60h] BYREF
  unsigned __int64 v160; // [rsp+C8h] [rbp-40h]
  rtc::webrtc_checks_impl::ToStringVal v161; // [rsp+D8h] [rbp-30h] BYREF
  std::string v162; // [rsp+F8h] [rbp-10h] BYREF
  std::string v163; // [rsp+118h] [rbp+10h] BYREF
  std::string v164; // [rsp+138h] [rbp+30h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *v165; // [rsp+158h] [rbp+50h]
  RBX::Graphics::ProfilerAdorn::Item *v166; // [rsp+160h] [rbp+58h]
  std::unordered_set<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<std::string,std::string > > > *v167; // [rsp+168h] [rbp+60h]
  RBX::Reflection::Variant playerInfoVar; // [rsp+170h] [rbp+68h] BYREF
  RBX::Reflection::Variant v169; // [rsp+1C8h] [rbp+C0h] BYREF
  std::unordered_set<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<std::string,std::string > > > v170; // [rsp+218h] [rbp+110h] BYREF
  RBX::Network::Client::ServerConnection v171; // [rsp+258h] [rbp+150h] BYREF
  char serverAddress[1032]; // [rsp+2A8h] [rbp+1A0h] BYREF

  __wind
  {
    __eh34_enter_wind_state(0, 1); /*0xf1c0000000000198*/
    __eh34_enter_wind_state(1, 2); /*0xf1c000000000019c*/
    v15 = (rtc::webrtc_checks_impl::ToStringVal *)server_deprecated; /*0x1410176ff*/
    if ( FFlag::CLI52064Experiment2.value ) /*0x14101770c*/
    {
      if ( DFFlag::CLI52064UseIxp.value && DFInt::DebugCLI52064TransmitUS <= 0 && DFInt::DebugCLI52064ReceiveUS <= 0 ) /*0x141017727*/
      {
        RBX::Network::Client::checkArtificialLatency(this, (std::_Func_base<void> *)userId); /*0x141017729*/
      }
      else
      {
        v17 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141017737*/
        ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD, _QWORD))v17->onInternalError._Mystorage._Ptrs[0][106].__vftable)( /*0x141017757*/
          a1: v17,
          a2: DFInt::DebugCLI52064TransmitUS,
          a3: DFInt::DebugCLI52064ReceiveUS);
      }
    }
    *(_QWORD *)&rccAddress._Mypair._Myval2._Bx._Alias[8] = 0; /*0x14101775d*/
    rccAddress._Mypair._Myval2._Myres = 0; /*0x141017761*/
    v160 = 15; /*0x14101776a*/
    __eh34_enter_wind_state(2, 3); /*0xf1c000000000012c*/
    v18 = 0; /*0x141017772*/
    port = 0; /*0x141017775*/
    if ( FFlag::DebugLocalRccServerConnection.value ) /*0x141017781*/
    {
      std::string::assign( /*0x141017792*/
        this: &v15->val,
        _Ptr: (const char *const)&RBX::Studio::ClientDataModel::`vftable'[20],
        _Count: 9u);
      serverPort = 53640; /*0x141017797*/
    }
    Ptr = v15; /*0x14101779d*/
    if ( v15->val._Mypair._Myval2._Myres >= 0x10 ) /*0x1410177a5*/
      Ptr = (rtc::webrtc_checks_impl::ToStringVal *)v15->val._Mypair._Myval2._Bx._Ptr; /*0x1410177a7*/
    if ( v15->val._Mypair._Myval2._Mysize == 9 /*0x1410177c5*/
      && memcmp_0(Buf1: Ptr, Buf2: &RBX::Studio::ClientDataModel::`vftable'[20], Size: 9u) == 0 )
    {
      std::string::assign(this: &v15->val, _Ptr: "127.0.0.1", _Count: 9u); /*0x1410177d5*/
    }
    if ( FFlag::DebugLocalRccServerConnection.value )
    {
      p_serverConnections = &this->serverConnections; /*0x1410177e3*/
      v161.val._Mypair._Myval2._Myres = 15; /*0x1410177ea*/
      v161.val._Mypair._Myval2._Mysize = 9; /*0x1410177ee*/
      strcpy(v161.val._Mypair._Myval2._Bx._Buf, "127.0.0.1"); /*0x1410177fe*/
      v21 = RBX::Network::Client::ServerConnection::ServerConnection(this: &v171, a: &v161.val, p: 53640); /*0x141017822*/
      __eh34_enter_wind_state(3, 4); /*0xf1c0000000000124*/
      std::vector<RBX::Network::Client::ServerConnection>::push_back(this: &this->serverConnections, _Val: v21); /*0x14101782e*/
      if ( __eh34_unwind(4) ) /*0xf1c0000000000118*/
        goto unwind_state_4; /*0xf1c0000000000118*/
      __eh34_exit_wind_state(4, 3); /*0xf1c000000000011c*/
      RBX::Network::Client::ServerConnection::~ServerConnection(this: &v171); /*0x14101783b*/
    }
    else
    {
      v22 = serverConnectionsArg; /*0x141017845*/
      if ( DFFlag::RuppHeaderFromClientEnabled3.value )
      {
        if ( udmuxEndpointsArg->_Mypair._Myval2._Myfirst != udmuxEndpointsArg->_Mypair._Myval2._Mylast )
        {
          Mylast = serverConnectionsArg->_Mypair._Myval2._Mylast; /*0x14101786d*/
          Myfirst = serverConnectionsArg->_Mypair._Myval2._Myfirst; /*0x141017871*/
          if ( serverConnectionsArg->_Mypair._Myval2._Myfirst == Mylast )
          {
            v35 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141017985*/
            v36 = v35->onInternalError._Mystorage._Ptrs[0][91].__vftable; /*0x14101798d*/
            v37 = v15; /*0x141017994*/
            if ( v15->val._Mypair._Myval2._Myres >= 0x10 ) /*0x14101799c*/
              v37 = (rtc::webrtc_checks_impl::ToStringVal *)v15->val._Mypair._Myval2._Bx._Ptr; /*0x14101799e*/
            *(_WORD *)&__formal[0].std::input_iterator_tag = serverPort; /*0x1410179a1*/
            v28 = ((unsigned int (__fastcall *)(Luau::InternalErrorReporter *, bool, RBX::Network::Rupp::TokenTlv::Token *, rtc::webrtc_checks_impl::ToStringVal *, _DWORD))v36)( /*0x1410179b8*/
                    a1: v35,
                    a2: directServerReturn,
                    a3: token,
                    a4: v37,
                    a5: *(_DWORD *)&__formal[0].std::input_iterator_tag);
LABEL_38:
            if ( v28 != 0 )
            {
              if ( DFLog::Rupp != 0 )
              {
                v145 = RBX::Network::Rupp::RuppError::toString(code: v28); /*0x1410189cb*/
                FLog::FastLogS(level: DFLog::Rupp, message: "[DFLog::Rupp] Client failed Rupp setup: %s", sarg: v145);
              }
              v146 = (RBX::ContentId *)std::vector<RBX::Network::Client::ServerConnection>::operator[]( /*0x1410189eb*/
                                         this: udmuxEndpointsArg,
                                         _Pos: 0);
              v147 = std::string::c_str(this: v146); /*0x1410189f3*/
              RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x141018a12*/
                this,
                metric: "RuppSetupFailed",
                connectionFailed: false,
                serverAddress: v147,
                state: ConnectionState_NotStartedYet,
                takeLock: true);
              RBX::runtime_error(result: &pExceptionObject, fmt: "Failed to start setup client Rupp"); /*0x141018a23*/
              throw &pExceptionObject; /*0x141018a34*/
            }
            if ( __eh34_unwind(3) ) /*0xf1c000000000014c*/
            {
unwind_state_3:
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&rccAddress._Mypair._Myval2._Bx._Alias[8]); /*0xf1c0000000000150*/
              __eh34_continue_unwinding(3, 2); /*0xf1c0000000000154*/
            }
            __eh34_exit_wind_state(3, 2); /*0xf1c0000000000158*/
            if ( __eh34_unwind(2) ) /*0xf1c000000000015c*/
            {
unwind_state_2:
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: server_deprecated); /*0xf1c0000000000160*/
              __eh34_continue_unwinding(2, 1); /*0xf1c0000000000164*/
            }
            __eh34_exit_wind_state(2, 1); /*0xf1c0000000000168*/
            if ( __eh34_unwind(1) ) /*0xf1c000000000016c*/
            {
unwind_state_1:
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: userName); /*0xf1c0000000000170*/
              __eh34_continue_unwinding(1, 0); /*0xf1c0000000000174*/
            }
            __eh34_exit_wind_state(1, 0); /*0xf1c0000000000178*/
            __eh34_enter_wind_state(0, 1); /*0xf1c0000000000180*/
            __eh34_enter_wind_state(1, 2); /*0xf1c0000000000184*/
            __eh34_enter_wind_state(2, 3); /*0xf1c0000000000188*/
          }
          else
          {
            while ( 1 ) /*0x141017897*/
            {
              v25 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141017897*/
              v26 = v25->onInternalError._Mystorage._Ptrs[0][91].__vftable; /*0x14101789f*/
              v27 = Myfirst; /*0x1410178aa*/
              if ( Myfirst->address._Mypair._Myval2._Myres >= 0x10 ) /*0x1410178b2*/
                v27 = (RBX::Network::Client::ServerConnection *)Myfirst->address._Mypair._Myval2._Bx._Ptr; /*0x1410178b4*/
              *(_WORD *)&__formal[0].std::input_iterator_tag = Myfirst->port; /*0x1410178b7*/
              v28 = ((unsigned int (__fastcall *)(Luau::InternalErrorReporter *, bool, RBX::Network::Rupp::TokenTlv::Token *, RBX::Network::Client::ServerConnection *, _DWORD))v26)( /*0x1410178c6*/
                      a1: v25,
                      a2: directServerReturn,
                      a3: token,
                      a4: v27,
                      a5: *(_DWORD *)&__formal[0].std::input_iterator_tag);
              if ( v28 == 0 ) /*0x1410178cb*/
                break; /*0x1410178cb*/
              if ( ++Myfirst == Mylast ) /*0x1410178d4*/
                goto LABEL_38; /*0x1410178d4*/
            }
            this->ruppEnabled = true; /*0x1410178de*/
            if ( DFFlag::LogUdmuxAndRccIp.value ) /*0x1410178ec*/
            {
              v29 = (const char *)Myfirst; /*0x1410178ee*/
              if ( Myfirst->address._Mypair._Myval2._Myres >= 0x10 ) /*0x1410178f6*/
                v29 = Myfirst->address._Mypair._Myval2._Bx._Ptr; /*0x1410178f8*/
              v30 = -1; /*0x1410178fb*/
              do /*0x14101790a*/
                ++v30; /*0x141017902*/
              while ( v29[v30] != 0 ); /*0x14101790a*/
              std::string::assign( /*0x141017910*/
                this: (std::string *)&rccAddress._Mypair._Myval2._Bx._Alias[8],
                _Ptr: v29,
                _Count: v30);
              port = Myfirst->port; /*0x141017918*/
            }
          }
          v22 = udmuxEndpointsArg; /*0x14101791c*/
          v15 = (rtc::webrtc_checks_impl::ToStringVal *)server_deprecated; /*0x141017922*/
        }
        v18 = port; /*0x141017929*/
      }
      v31.current = v22->_Mypair._Myval2._Mylast; /*0x14101792e*/
      v32.current = v22->_Mypair._Myval2._Myfirst; /*0x141017932*/
      if ( v32.current == v31.current ) /*0x141017938*/
      {
        v33 = std::string::string(this: &v161, __that: v15); /*0x141017945*/
        v34 = RBX::Network::Client::ServerConnection::ServerConnection(this: &v171, a: &v33->val, p: serverPort); /*0x141017957*/
        __eh34_enter_wind_state(3, 4); /*0xf1c0000000000110*/
        p_serverConnections = &this->serverConnections; /*0x141017960*/
        std::vector<RBX::Network::Client::ServerConnection>::push_back(this: &this->serverConnections, _Val: v34); /*0x14101796a*/
        if ( __eh34_unwind(4) ) /*0xf1c00000000000fc*/
        {
unwind_state_4:
          RBX::Network::Client::ServerConnection::~ServerConnection(this: &v171); /*0xf1c0000000000100*/
          __eh34_continue_unwinding(4, 3); /*0xf1c0000000000104*/
        }
        __eh34_exit_wind_state(4, 3); /*0xf1c0000000000108*/
        RBX::Network::Client::ServerConnection::~ServerConnection(this: &v171); /*0x141017977*/
      }
      else
      {
        p_serverConnections = &this->serverConnections; /*0x1410179c8*/
        std::vector<RBX::Network::Client::ServerConnection>::_Insert_range<std::reverse_iterator<RBX::Network::Client::ServerConnection const *>>( /*0x1410179e1*/
          this: &this->serverConnections,
          _Where: (std::_Vector_const_iterator<std::_Vector_val<std::_Simple_types<RBX::Network::Client::ServerConnection> > >)this->serverConnections._Mypair._Myval2._Myfirst,
          _First: v31,
          _Last: v32,
          __formal: (std::forward_iterator_tag)server_deprecated);
      }
    }
    if ( FLog::Network != 0 ) /*0x1410179ef*/
    {
      FLog::FastLogFormatted( /*0x141017a05*/
        level: FLog::Network,
        message: "[FLog::Network] Client will attempt to connect following server endpoints with threadSleepTime(%d)",
        threadSleepTime);
      if ( DFFlag::LogUdmuxAndRccIp.value && this->ruppEnabled ) /*0x141017a13*/
      {
        v38 = p_serverConnections->_Mypair._Myval2._Mylast; /*0x141017a1c*/
        v39 = p_serverConnections->_Mypair._Myval2._Myfirst; /*0x141017a20*/
        if ( p_serverConnections->_Mypair._Myval2._Myfirst != v38 ) /*0x141017a27*/
        {
          v40 = FLog::Network; /*0x141017a2d*/
          do /*0x141017a7e*/
          {
            if ( v40 != 0 ) /*0x141017a36*/
            {
              v41 = &rccAddress._Mypair._Myval2._Bx._Buf[8]; /*0x141017a38*/
              if ( v160 >= 0x10 ) /*0x141017a41*/
                v41 = *(const char **)&rccAddress._Mypair._Myval2._Bx._Alias[8]; /*0x141017a41*/
              v42 = (const char *)v39; /*0x141017a46*/
              if ( v39->address._Mypair._Myval2._Myres >= 0x10 ) /*0x141017a4e*/
                v42 = v39->address._Mypair._Myval2._Bx._Ptr; /*0x141017a50*/
              FLog::FastLogFormatted( /*0x141017a6b*/
                level: v40,
                message: "[FLog::Network] UDMUX Address = %s, Port = %d | RCC Server Address = %s, Port = %d",
                v42,
                v39->port,
                v41,
                v18);
              v40 = FLog::Network; /*0x141017a70*/
            }
            ++v39; /*0x141017a77*/
          }
          while ( v39 != v38 ); /*0x141017a7e*/
        }
      }
      else
      {
        v43 = p_serverConnections->_Mypair._Myval2._Mylast; /*0x141017a82*/
        v44 = p_serverConnections->_Mypair._Myval2._Myfirst; /*0x141017a86*/
        if ( p_serverConnections->_Mypair._Myval2._Myfirst != v43 ) /*0x141017a8d*/
        {
          v45 = FLog::Network; /*0x141017a8f*/
          do /*0x141017ac8*/
          {
            if ( v45 != 0 ) /*0x141017a98*/
            {
              v46 = (const char *)v44; /*0x141017a9a*/
              if ( v44->address._Mypair._Myval2._Myres >= 0x10 ) /*0x141017aa2*/
                v46 = v44->address._Mypair._Myval2._Bx._Ptr; /*0x141017aa4*/
              FLog::FastLogFormatted( /*0x141017ab5*/
                level: v45,
                message: "[FLog::Network] Server Address = %s, Port = %d",
                v46,
                v44->port);
              v45 = FLog::Network; /*0x141017aba*/
            }
            ++v44; /*0x141017ac1*/
          }
          while ( v44 != v43 ); /*0x141017ac8*/
        }
      }
    }
    this->serverDataCenterId = dataCenterId; /*0x141017ad0*/
    v47 = (const std::unordered_map<std::string,RBX::Reflection::Variant> *)playerInfoTable->_Ptr; /*0x141017add*/
    v157 = 15; /*0x141017aeb*/
    *(_QWORD *)&pExceptionObject._Data._DoFree = 6; /*0x141017af5*/
    pExceptionObject.__vftable = (std::runtime_error_vtbl *)(*(unsigned int *)aUser_9 | 0x644900000000LL); /*0x141017aff*/
    v48 = 0xCBF29CE484222325uLL; /*0x141017b1e*/
    for ( i = 0; i < 6; ++i ) /*0x141017b28*/
      v48 = 0x100000001B3LL * (*((unsigned __int8 *)&pExceptionObject.__vftable + i) ^ (unsigned __int64)v48); /*0x141017b48*/
    v50 = v47->_Vec._Mypair._Myval2._Myfirst; /*0x141017b64*/
    v51 = v50[2 * (v48 & v47->_Mask) + 1]._Ptr; /*0x141017b68*/
    Myhead = v47->_List._Mypair._Myval2._Myhead; /*0x141017b6d*/
    if ( v51 == Myhead ) /*0x141017b74*/
      goto LABEL_72; /*0x141017b74*/
    v53 = v50[2 * (v48 & v47->_Mask)]._Ptr; /*0x141017b76*/
    while ( 1 ) /*0x141017b80*/
    {
      p_Myval = (char **)&v51->_Myval; /*0x141017b80*/
      if ( v51->_Myval.first._Mypair._Myval2._Myres >= 0x10 ) /*0x141017b8d*/
        p_Myval = (char **)*p_Myval; /*0x141017b8f*/
      if ( v51->_Myval.first._Mypair._Myval2._Mysize == 6 /*0x141017bae*/
        && memcmp_0(Buf1: &pExceptionObject, Buf2: p_Myval, Size: 6u) == 0 )
      {
        break; /*0x141017bae*/
      }
      if ( v51 == v53 ) /*0x141017bbd*/
        goto LABEL_72; /*0x141017bbd*/
      v51 = v51->_Prev; /*0x141017bbf*/
    }
    if ( v51 == nullptr ) /*0x141017bc8*/
LABEL_72:
      v51 = Myhead; /*0x141017bca*/
    type = v51->_Myval.second._type; /*0x141017bcd*/
    if ( type == RBX::Reflection::Type::getSingleton<__int64>() ) /*0x141017bdd*/
    {
      v56 = v51->_Myval.second._type; /*0x141017bd6*/
      if ( v56 != RBX::Reflection::Type::getSingleton<__int64>() ) /*0x141017be7*/
        RBX::throw_runtime_error(fmt: "Variant cast failed"); /*0x141018a82*/
      data = (__int64 *)v51->_Myval.second.value.data; /*0x141017bed*/
      if ( v51->_Myval.second.value.holder == nullptr ) /*0x141017bf6*/
        data = nullptr; /*0x141017bf6*/
      v58 = *data; /*0x141017bfa*/
    }
    else
    {
      v169._type = v51->_Myval.second._type; /*0x141017bff*/
      v169.value.holder = nullptr; /*0x141017c06*/
      holder = v51->_Myval.second.value.holder; /*0x141017c0d*/
      if ( holder != nullptr ) /*0x141017c14*/
      {
        holder->construct(a1: v51->_Myval.second.value.data, a2: v169.value.data); /*0x141017c24*/
        holder = v51->_Myval.second.value.holder; /*0x141017c26*/
      }
      v169.value.holder = holder; /*0x141017c2a*/
      __wind /*0xf1c00000000000dc*/
      {
        v58 = *RBX::Reflection::Variant::convert<__int64>(this: &v169); /*0x141017c3d*/
      }
      __unwind
      {
        std::tuple<bool,RBX::Reflection::Variant>::~tuple<bool,RBX::Reflection::Variant>(this: (RBX::setupTweenUpdate::__l5::<lambda_fde46e4afccb457705ab91f32d9aea10> *)&v169); /*0xf1c00000000000ec*/
      }
      __eh34_enter_wind_state(3, 6); /*0xf1c00000000000f4*/
      if ( v169.value.holder != nullptr ) /*0x141017c4a*/
        v169.value.holder->destruct(a1: v169.value.data); /*0x141017c57*/
      if ( __eh34_unwind(6) ) /*0xf1c00000000000c8*/
unwind_state_6:
        __std_terminate(a1: v60, a2: &v148); /*0xf1c00000000000cc*/
      __eh34_exit_wind_state(6, 3); /*0xf1c00000000000d4*/
    }
    this->userId = v58; /*0x141017c5a*/
    if ( this->clientReplicationMode == ReplicationMode_Client ) /*0x141017c68*/
      goto LABEL_120; /*0x141017c68*/
    RBX::InstrumentedMutex<std::mutex>::lock(this: &this->connectionStateAndJoinDataMutex); /*0x141017c75*/
    v61 = true; /*0x141017c7a*/
    v62 = p_serverConnections->_Mypair._Myval2._Myfirst; /*0x141017c7d*/
    v63 = p_serverConnections->_Mypair._Myval2._Mylast; /*0x141017c81*/
    v64 = "ConnectionFailure"; /*0x141017c85*/
    if ( p_serverConnections->_Mypair._Myval2._Myfirst == v63 )
    {
LABEL_98:
      v72 = (RBX::Time::nowFast(result: (RBX::Time *)&sdArray)->sec - this->lastReportedTime.sec) * 1000.0; /*0x141017d74*/
      v73 = 0; /*0x141017d92*/
      if ( v72 >= 9.223372036854776e18 ) /*0x141017da0*/
      {
        v72 = v72 - 9.223372036854776e18; /*0x141017da2*/
        if ( v72 < 9.223372036854776e18 ) /*0x141017daa*/
          v73 = 0x8000000000000000uLL; /*0x141017db6*/
      }
      v68 = v73 + (unsigned int)(int)v72; /*0x141017dbe*/
      if ( v61 )
      {
LABEL_102:
        v74 = "ConnectionFailure"; /*0x141017dc6*/
        if ( !this->wasConnected )
        {
LABEL_104:
          RBX::Network::Client::reportNetworkMetricToDiag( /*0x141017dd9*/
            this,
            prefix: "StudioNetwork",
            metric: v74,
            endOfSession: v61,
            msSinceLastMetric: v68);
          if ( DFInt::ClientNetworkInfluxHundredthsPercentage != 0 ) /*0x141017df8*/
          {
            if ( !v61 || this->wasConnected ) /*0x141017dff*/
              v64 = "JoinStart"; /*0x141017e08*/
            RBX::Network::Client::reportClientLevelNetworkMetricToInflux( /*0x141017e25*/
              this,
              prefix: "StudioNetwork",
              metric: v64,
              endOfSession: v61,
              msSinceLastMetric: v68);
          }
          v75 = this->haveReportedEndOfSession || v61; /*0x141017e3c*/
          this->haveReportedEndOfSession = v75; /*0x141017e3e*/
          std::string::assign(this: &this->lastReportedMetric, _Ptr: "JoinStart", _Count: 9u); /*0x141017e58*/
          this->lastReportedTime = *(RBX::Time *)&RBX::Time::nowFast(&result)->sec; /*0x141017e6a*/
          v76 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141017e79*/
          ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD))v76->onInternalError._Mystorage._Ptrs[0][110].__vftable)( /*0x141017e8d*/
            a1: v76,
            a2: 0);
          RBX::Network::Client::reportNetworkMetricToGA(this, prefix: "StudioNetwork", metric: "JoinStart"); /*0x141017ea1*/
          if ( DFInt::ClientNetworkInfluxHundredthsPercentage != 0 && !this->perServerMetricReported )
          {
            v77 = p_serverConnections->_Mypair._Myval2._Myfirst; /*0x141017eb8*/
            v78 = p_serverConnections->_Mypair._Myval2._Mylast; /*0x141017ebc*/
            if ( p_serverConnections->_Mypair._Myval2._Myfirst == v78 )
            {
LABEL_118:
              RBX::Network::Client::reportConnectionLevelNetworkMetricToInflux(this, prefix: "StudioNetworkDetailed"); /*0x141017ee6*/
              this->perServerMetricReported = true; /*0x141017ef5*/
            }
            else
            {
              while ( 1 ) /*0x141017ed0*/
              {
                state = v77->state; /*0x141017ed0*/
                if ( state <= 1 ) /*0x141017ed7*/
                  break; /*0x141017ed7*/
                if ( ++v77 == v78 ) /*0x141017ee4*/
                  goto LABEL_118; /*0x141017ee4*/
              }
              if ( DFLog::NetworkTrace != 0 )
              {
                v81 = v77->port; /*0x141018013*/
                if ( v77->address._Mypair._Myval2._Myres >= 0x10 ) /*0x14101801c*/
                  v77 = (RBX::Network::Client::ServerConnection *)v77->address._Mypair._Myval2._Bx._Ptr; /*0x14101801e*/
                FLog::FastLogFormatted(
                  level: DFLog::NetworkTrace,
                  message: "[DFLog::NetworkTrace] reportPerServerMetric::: sc(%s:%d).state = %d :: returning false",
                  v77->address._Mypair._Myval2._Bx._Buf,
                  v81,
                  state);
              }
            }
          }
          Mtx_unlock_0(a1: (_Mtx_t)&this->connectionStateAndJoinDataMutex); /*0x141017f03*/
LABEL_120:
          this->reportingJoinState = JoinState_JoinStarted; /*0x141017f08*/
          if ( userId <= 0 || (__int64)(userId % 0x3E8uLL) >= DFInt::ClientJoinProcessPositiveSamplesThousandths ) /*0x141017f53*/
          {
            v82 = nullptr; /*0x141018036*/
          }
          else
          {
            v167 = &v170; /*0x141017f60*/
            v80 = (std::unordered_map<std::string,std::string> *)std::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>(this: &v170); /*0x141017f70*/
            __wind /*0xf1c00000000000bc*/
            {
              v165 = (RBX::Graphics::ProfilerAdorn::Item *)&v164; /*0x141017f77*/
              v82 = nullptr; /*0x141017f7b*/
              v164._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141017f7e*/
              v164._Mypair._Myval2._Mysize = 0; /*0x141017f82*/
              v164._Mypair._Myval2._Myres = 15; /*0x141017f8b*/
              std::string::assign(this: &v164, _Ptr: "GameServerConnectStarted", _Count: 0x18u); /*0x141017f9e*/
              __wind /*0xf1c00000000000b0*/
              {
                v166 = (RBX::Graphics::ProfilerAdorn::Item *)&v162; /*0x141017fa8*/
                v162._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141017fac*/
                v162._Mypair._Myval2._Mysize = 0; /*0x141017fb0*/
                v162._Mypair._Myval2._Myres = 15; /*0x141017fb4*/
                std::string::assign(this: &v162, _Ptr: "report", _Count: 6u); /*0x141017fc7*/
                __wind /*0xf1c0000000000080*/
                {
                  v163._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141017fcd*/
                  v163._Mypair._Myval2._Mysize = 0; /*0x141017fd1*/
                  v163._Mypair._Myval2._Myres = 15; /*0x141017fd5*/
                  std::string::assign(this: &v163, _Ptr: "client", _Count: 6u); /*0x141017fe8*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: v166); /*0xf1c0000000000090*/
                }
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: v165); /*0xf1c000000000009c*/
              }
            }
            __unwind
            {
              std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: v167); /*0xf1c00000000000a8*/
            }
            RBX::Analytics::EventIngest::setRBXEvent( /*0x141017ffd*/
              target: &v163,
              eventContext: &v162,
              eventName: &v164,
              additionalArgs: v80);
          }
          v83 = RBX::DataModel::get(context: this); /*0x141018041*/
          if ( v83 != nullptr ) /*0x141018047*/
          {
            v84 = RBX::DataModel::get(context: this); /*0x141018051*/
            v83->joinData.joinStartTime = RBX::Time::nowFast(result: (RBX::Time *)&rccAddress)->sec /*0x14101806d*/
                                        - v84->joinData.clientStartTime.sec;
            v83->joinData.dataCenterID = dataCenterId; /*0x14101807b*/
          }
          ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(context: this); /*0x141018084*/
          if ( ServiceProvider == nullptr /*0x14101809d*/
            || (v86 = RBX::ServiceProvider::create<RBX::Players>(this: ServiceProvider)) == nullptr )
          {
            RBX::runtime_error(result: &pExceptionObject, fmt: "Cannot get players"); /*0x141018a64*/
            throw &pExceptionObject; /*0x141018a75*/
          }
          if ( v86->localPlayer._Ptr != nullptr ) /*0x1410180ab*/
            RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1410180cb*/
              this,
              metric: "ReJoinFromSameDataModel",
              connectionFailed: false,
              serverAddress: pass,
              state: ConnectionState_NotStartedYet,
              takeLock: true);
          playerInfoVar.value.holder = (const rbx::implementation::type_holder *)RBX::Reflection::Type::getSingleton<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>(); /*0x1410180d5*/
          memset(playerInfoVar.value.data, 0, 24); /*0x1410180d9*/
          Rep = playerInfoTable->_Rep; /*0x1410180ef*/
          if ( Rep != nullptr ) /*0x1410180f6*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410180f8*/
            Rep = playerInfoTable->_Rep; /*0x1410180fc*/
          }
          *(_QWORD *)&playerInfoVar.value.data[8] = playerInfoTable->_Ptr; /*0x141018103*/
          *(_QWORD *)&playerInfoVar.value.data[16] = Rep; /*0x14101810a*/
          if ( __TSS0__1__singleton___typed_holder_V__shared_ptr___CBV__unordered_map_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__VVariant_Reflection_RBX__U__hash_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___2_U__equal_to_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___2_V__allocator_U__pair___CBV__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__VVariant_Reflection_RBX___std___2__std___std___implementation_rbx__SAPEBV234_XZ_4HA > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x14101813b*/
          {
            Init_thread_header(pOnce: &__TSS0__1__singleton___typed_holder_V__shared_ptr___CBV__unordered_map_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__VVariant_Reflection_RBX__U__hash_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___2_U__equal_to_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___2_V__allocator_U__pair___CBV__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__VVariant_Reflection_RBX___std___2__std___std___implementation_rbx__SAPEBV234_XZ_4HA); /*0x141018a8f*/
            if ( __TSS0__1__singleton___typed_holder_V__shared_ptr___CBV__unordered_map_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__VVariant_Reflection_RBX__U__hash_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___2_U__equal_to_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___2_V__allocator_U__pair___CBV__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__VVariant_Reflection_RBX___std___2__std___std___implementation_rbx__SAPEBV234_XZ_4HA == -1 ) /*0x141018a9b*/
            {
              `rbx::implementation::typed_holder<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>::singleton'::`2'::s.construct = rbx::implementation::typed_holder<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant>>>::construct_func; /*0x141018aa8*/
              `rbx::implementation::typed_holder<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>::singleton'::`2'::s.moveConstruct = rbx::implementation::typed_holder<std::shared_ptr<RBX::DataStoreSetOptions>>::moveConstruct_func; /*0x141018ab6*/
              `rbx::implementation::typed_holder<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>::singleton'::`2'::s.destruct = (void (__fastcall *)(char *))std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>; /*0x141018abd*/
              Init_thread_footer(pOnce: &__TSS0__1__singleton___typed_holder_V__shared_ptr___CBV__unordered_map_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__VVariant_Reflection_RBX__U__hash_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___2_U__equal_to_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___2_V__allocator_U__pair___CBV__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__VVariant_Reflection_RBX___std___2__std___std___implementation_rbx__SAPEBV234_XZ_4HA); /*0x141018acb*/
            }
          }
          *(_QWORD *)playerInfoVar.value.data = &`rbx::implementation::typed_holder<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>::singleton'::`2'::s; /*0x141018148*/
          __eh34_enter_wind_state(3, 11); /*0xf1c0000000000078*/
          if ( !RBX::WebParser::writeJSON( /*0x141018164*/
                  value: (const RBX::Reflection::Variant *)&playerInfoVar.value,
                  result: &this->playerInfoJson,
                  skip: SkipNonJSON) )
          {
            std::runtime_error::runtime_error( /*0x141018ae1*/
              this: &pExceptionObject,
              _Message: "Cannot construct player information to send to server");
            throw &pExceptionObject; /*0x141018af2*/
          }
          v88 = p_serverConnections->_Mypair._Myval2._Mylast - p_serverConnections->_Mypair._Myval2._Myfirst; /*0x14101818d*/
          *(RBX::Time *)&result.sec = (RBX::Time)v88; /*0x141018190*/
          v89 = (RakNet::SocketDescriptor *)(int)v88; /*0x141018194*/
          sdArray._Mypair._Myval2._Myfirst = (RakNet::SocketDescriptor *)(int)v88; /*0x141018197*/
          *(_OWORD *)&sdArray._Mypair._Myval2._Mylast = 0; /*0x14101819f*/
          v155 = nullptr; /*0x1410181a5*/
          if ( (_DWORD)v88 != 0 ) /*0x1410181ad*/
          {
            if ( (unsigned __int64)(int)v88 > 0x3A83A83A83A83A8LL ) /*0x1410181bc*/
              std::vector<Luau::AstNode *>::_Xlength(); /*0x141018af8*/
            v90 = (RakNet::SocketDescriptor *)std::_Allocate<16,std::_Default_allocate_traits,0>(_Bytes: 70LL * (int)v88); /*0x1410181ce*/
            sdArray._Mypair._Myval2._Mylast = v90; /*0x1410181d1*/
            sdArray._Mypair._Myval2._Myend = v90; /*0x1410181d6*/
            v155 = &v90[(int)v88]; /*0x1410181df*/
            rccAddress._Mypair._Myval2._Bx._Ptr = (char *)&sdArray._Mypair._Myval2._Mylast; /*0x1410181e9*/
            __wind /*0xf1c000000000006c*/
            {
              v91 = sdArray._Mypair._Myval2._Myfirst; /*0x1410181ed*/
              do /*0x141018202*/
              {
                RakNet::SocketDescriptor::SocketDescriptor(this: v90++); /*0x1410181f5*/
                v91 = (RakNet::SocketDescriptor *)((char *)v91 - 1); /*0x1410181fe*/
              }
              while ( v91 != nullptr ); /*0x141018202*/
              sdArray._Mypair._Myval2._Myend = v90; /*0x141018204*/
            }
            __unwind
            {
              std::_Tidy_guard<std::vector<RakNet::SocketDescriptor>>::~_Tidy_guard<std::vector<RakNet::SocketDescriptor>>(this: (std::_Tidy_guard<std::vector<RakNet::SocketDescriptor> > *)&rccAddress); /*0xf1c0000000000064*/
            }
            v89 = sdArray._Mypair._Myval2._Myfirst; /*0x141018209*/
          }
          __eh34_enter_wind_state(11, 13); /*0xf1c0000000000058*/
          v92 = 0; /*0x14101820e*/
          v93 = clientPort; /*0x141018211*/
          if ( (__int64)v89 > 0 )
          {
            v94 = 0; /*0x141018221*/
            v95 = 0; /*0x141018224*/
            v82 = sdArray._Mypair._Myval2._Myfirst; /*0x141018227*/
            do
            {
              v96 = &this->serverConnections._Mypair._Myval2._Myfirst[v94]; /*0x141018237*/
              if ( v96->address._Mypair._Myval2._Myres >= 0x10 ) /*0x14101823f*/
                v96 = (RBX::Network::Client::ServerConnection *)v96->address._Mypair._Myval2._Bx._Ptr; /*0x141018241*/
              v97 = RakNet::RakPeer::resolveSocketFamily( /*0x141018250*/
                      socketDescriptor: &sdArray._Mypair._Myval2._Mylast[v92],
                      address: v96->address._Mypair._Myval2._Bx._Buf);
              if ( v97 != 0 && FLog::Output != 0 )
              {
                v98 = &this->serverConnections._Mypair._Myval2._Myfirst[v94]; /*0x14101826d*/
                v99 = v98->port; /*0x141018270*/
                if ( v98->address._Mypair._Myval2._Myres >= 0x10 ) /*0x141018279*/
                  v98 = (RBX::Network::Client::ServerConnection *)v98->address._Mypair._Myval2._Bx._Ptr; /*0x14101827b*/
                FLog::FastLogFormatted(
                  level: FLog::Output,
                  message: "[FLog::Output] serverConnection(%s|%d) couldn't be resolved : %d",
                  v98->address._Mypair._Myval2._Bx._Buf,
                  v99,
                  v97);
              }
              v100 = RBX::DataModel::get(context: this); /*0x141018294*/
              if ( v100 != nullptr && sdArray._Mypair._Myval2._Mylast[v95].socketFamily == 23 ) /*0x1410182a9*/
                v100->isIPV6 = true; /*0x1410182ab*/
              sdArray._Mypair._Myval2._Mylast[v95].port = clientPort; /*0x1410182b7*/
              this->serverConnections._Mypair._Myval2._Myfirst[v94].socketFamily = sdArray._Mypair._Myval2._Mylast[v95].socketFamily; /*0x1410182cd*/
              ++v92; /*0x1410182d2*/
              ++v95; /*0x1410182d5*/
              ++v94; /*0x1410182d9*/
              v82 = (RakNet::SocketDescriptor *)((char *)v82 - 1); /*0x1410182dd*/
            }
            while ( v82 != nullptr );
            LODWORD(v88) = LODWORD(result.sec); /*0x1410182e7*/
            v89 = sdArray._Mypair._Myval2._Myfirst; /*0x1410182eb*/
          }
          v101 = &DFInt::CliMaxPayloadRcv; /*0x1410182f7*/
          if ( this->clientReplicationMode == ReplicationMode_StudioAsEditor ) /*0x141018305*/
            v101 = &DFInt::CliTcMaxPayloadRcv; /*0x141018305*/
          v102 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141018310*/
          v103 = v102->onInternalError._Mystorage._Ptrs[0][1].__vftable; /*0x141018318*/
          LOWORD(v151) = 0; /*0x141018329*/
          *(_WORD *)takeLock = 0; /*0x14101832f*/
          if ( ((unsigned int (__fastcall *)(Luau::InternalErrorReporter *, __int64, int *, RakNet::SocketDescriptor *, _DWORD, _DWORD, int, int))v103)( /*0x14101834a*/
                 a1: v102,
                 a2: 1,
                 a3: v101,
                 a4: sdArray._Mypair._Myval2._Mylast,
                 a5: v88,
                 a6: *(_DWORD *)takeLock,
                 a7: v151,
                 a8: -99999) != 0 )
          {
            if ( (__int64)v89 > 0 ) /*0x141018353*/
            {
              do /*0x141018401*/
              {
                v104 = (char *)v82 + (unsigned __int64)this->serverConnections._Mypair._Myval2._Myfirst; /*0x141018367*/
                v105 = v104; /*0x14101836a*/
                if ( *((_QWORD *)v104 + 3) >= 0x10u ) /*0x141018372*/
                  v105 = *(char **)v104; /*0x141018374*/
                v106 = (char *)(serverAddress - v105); /*0x14101837e*/
                do /*0x14101838d*/
                {
                  v107 = *v105; /*0x141018381*/
                  v105[(_QWORD)v106] = *v105; /*0x141018384*/
                  ++v105; /*0x141018387*/
                }
                while ( v107 != 0 ); /*0x14101838d*/
                v108 = -1; /*0x141018396*/
                do /*0x1410183a7*/
                  ++v108; /*0x1410183a0*/
                while ( serverAddress[v108] != 0 ); /*0x1410183a7*/
                serverAddress[(int)v108] = 124; /*0x1410183ac*/
                Itoa(value: *((_DWORD *)v104 + 8), result: &serverAddress[(int)v108 + 1], base: 10); /*0x1410183ce*/
                RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1410183f4*/
                  this,
                  metric: "RakNetStartupFailed",
                  connectionFailed: true,
                  serverAddress,
                  state: ConnectionState_Failed,
                  takeLock: true);
                v82 = (RakNet::SocketDescriptor *)((char *)v82 + 80); /*0x1410183f9*/
                v89 = (RakNet::SocketDescriptor *)((char *)v89 - 1); /*0x1410183fd*/
              }
              while ( v89 != nullptr ); /*0x141018401*/
              v93 = clientPort; /*0x141018407*/
            }
            if ( v93 != 0 ) /*0x141018416*/
            {
              if ( __eh34_unwind(13) ) /*0xf1c00000000001ec*/
                goto unwind_state_13; /*0xf1c00000000001ec*/
              __eh34_exit_wind_state(13, 11); /*0xf1c00000000001f0*/
              if ( __eh34_unwind(11) ) /*0xf1c00000000001f4*/
                goto unwind_state_11; /*0xf1c00000000001f4*/
              __eh34_exit_wind_state(11, 3); /*0xf1c00000000001f8*/
              if ( __eh34_unwind(3) ) /*0xf1c00000000001fc*/
                goto unwind_state_3; /*0xf1c00000000001fc*/
              __eh34_exit_wind_state(3, 2); /*0xf1c0000000000200*/
              if ( __eh34_unwind(2) ) /*0xf1c0000000000204*/
                goto unwind_state_2; /*0xf1c0000000000204*/
              __eh34_exit_wind_state(2, 1); /*0xf1c0000000000208*/
              if ( __eh34_unwind(1) ) /*0xf1c000000000020c*/
                goto unwind_state_1; /*0xf1c000000000020c*/
              __eh34_exit_wind_state(1, 0); /*0xf1c0000000000210*/
              __eh34_enter_wind_state(0, 1); /*0xf1c00000000001b0*/
              __eh34_enter_wind_state(1, 2); /*0xf1c00000000001b4*/
              __eh34_enter_wind_state(2, 3); /*0xf1c00000000001b8*/
              __eh34_enter_wind_state(3, 11); /*0xf1c00000000001bc*/
              __eh34_enter_wind_state(11, 13); /*0xf1c00000000001c0*/
              RBX::runtime_error(result: &pExceptionObject, fmt: "Failed to start network client on port %d", v93); /*0x141018b08*/
              throw &pExceptionObject; /*0x141018b19*/
            }
            RBX::runtime_error(result: &pExceptionObject, fmt: "Failed to start network client"); /*0x141018a41*/
            throw &pExceptionObject; /*0x141018a52*/
          }
          if ( FFlag::DebugLocalRccServerConnection.value ) /*0x141018428*/
            std::string::assign(this: &RBX::Network::versionB, _Ptr: "test", _Count: 4u); /*0x14101843e*/
          v109 = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(context: this); /*0x141018446*/
          if ( v109 != nullptr ) /*0x14101844e*/
            v110 = (unsigned __int8)RBX::ServiceProvider::create<RBX::RunService>(this: v109); /*0x141018453*/
          else
            v110 = 0; /*0x14101845a*/
          if ( FFlag::DebugLocalRccServerConnection.value ) /*0x141018464*/
            value = FFlag::DebugLocalRccTicketTesting.value; /*0x141018466*/
          else
            value = RBX::Reflection::TypedPropertyDescriptor<RBX::UDim>::hasStringValue(__formal: v110) == 0 /*0x141018488*/
                 || (unsigned int)(this->clientReplicationMode - 1) <= 1;
          v112 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141018495*/
          ((void (__fastcall *)(Luau::InternalErrorReporter *, bool))v112->onInternalError._Mystorage._Ptrs[0][86].__vftable)( /*0x1410184aa*/
            a1: v112,
            a2: value);
          if ( value && this->clientReplicationMode == ReplicationMode_Client ) /*0x1410184b8*/
          {
            v113 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410184c1*/
            ((void (__fastcall *)(Luau::InternalErrorReporter *))v113->onInternalError._Mystorage._Ptrs[0][87].__vftable)(a1: v113); /*0x1410184cc*/
          }
          v114 = 0; /*0x1410184d2*/
          v152 = 0; /*0x1410184d4*/
          RBX::InstrumentedMutex<std::mutex>::lock(this: &this->connectionStateAndJoinDataMutex); /*0x1410184df*/
          v115 = 0; /*0x1410184e4*/
          if ( (__int64)v89 <= 0 ) /*0x1410184ea*/
          {
            v122 = (int)server_deprecated; /*0x1410187b6*/
          }
          else
          {
            v116 = 0; /*0x1410184f0*/
            do /*0x1410187a9*/
            {
              v117 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141018507*/
              v118 = v117->onInternalError._Mystorage._Ptrs[0][12].__vftable; /*0x14101850f*/
              v119 = &RBX::Network::versionB; /*0x141018526*/
              if ( RBX::Network::versionB._Mypair._Myval2._Myres >= 0x10 ) /*0x141018535*/
                v119 = (std::string *)RBX::Network::versionB._Mypair._Myval2._Bx._Ptr; /*0x141018535*/
              v120 = &this->serverConnections._Mypair._Myval2._Myfirst[v116]; /*0x141018544*/
              port_low = LOWORD(v120->port); /*0x141018547*/
              if ( v120->address._Mypair._Myval2._Myres >= 0x10 ) /*0x141018551*/
                v120 = (RBX::Network::Client::ServerConnection *)v120->address._Mypair._Myval2._Bx._Ptr; /*0x141018553*/
              *(_DWORD *)&__formal[0].std::input_iterator_tag = RBX::Network::versionB._Mypair._Myval2._Mysize; /*0x14101856e*/
              v122 = ((__int64 (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::Client::ServerConnection *, __int64, std::string *, _QWORD, _QWORD, int, int, int, _DWORD))v118)( /*0x141018578*/
                       a1: v117,
                       a2: v120,
                       a3: port_low,
                       a4: v119,
                       a5: *(_QWORD *)&__formal[0].std::input_iterator_tag,
                       a6: 0,
                       a7: v115,
                       a8: DFInt::SendConnectionAttemptCount,
                       a9: DFInt::TimeBetweenSendConnectionAttemptsMS,
                       a10: 0);
              v123 = this->serverConnections._Mypair._Myval2._Myfirst; /*0x14101857a*/
              if ( v122 != 0 ) /*0x141018583*/
              {
                v124 = &v123[v116]; /*0x141018589*/
                v125 = v124; /*0x14101858d*/
                if ( v124->address._Mypair._Myval2._Myres >= 0x10 ) /*0x141018595*/
                  v125 = (RBX::Network::Client::ServerConnection *)v124->address._Mypair._Myval2._Bx._Ptr; /*0x141018597*/
                v126 = (char *)(serverAddress - (char *)v125); /*0x1410185a1*/
                do /*0x1410185bc*/
                {
                  v127 = v125->address._Mypair._Myval2._Bx._Buf[0]; /*0x1410185b0*/
                  v125->address._Mypair._Myval2._Bx._Buf[(_QWORD)v126] = v125->address._Mypair._Myval2._Bx._Buf[0]; /*0x1410185b3*/
                  v125 = (RBX::Network::Client::ServerConnection *)((char *)v125 + 1); /*0x1410185b6*/
                }
                while ( v127 != 0 ); /*0x1410185bc*/
                v128 = -1; /*0x1410185c5*/
                do /*0x1410185d7*/
                  ++v128; /*0x1410185d0*/
                while ( serverAddress[v128] != 0 ); /*0x1410185d7*/
                serverAddress[(int)v128] = 124; /*0x1410185dc*/
                Itoa(value: v124->port, result: &serverAddress[(int)v128 + 1], base: 10); /*0x1410185fe*/
                RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x141018624*/
                  this,
                  metric: "RakNetDidNotStartConnectAttempt",
                  connectionFailed: true,
                  serverAddress,
                  state: ConnectionState_Failed,
                  takeLock: false);
              }
              else
              {
                v123[v116].state = ConnectionState_Initiated; /*0x14101862e*/
                v152 = 1; /*0x141018637*/
                if ( DFLog::NetworkJoin != 0 ) /*0x141018643*/
                {
                  v129 = RBX::Time::nowFastSec(); /*0x14101864d*/
                  FLog::FastLogF( /*0x14101866e*/
                    channel: DFLog::NetworkJoin,
                    message: "[DFLog::NetworkJoin] playerConnect connecting to server @ %f s",
                    arg1: v129,
                    arg2: 0.0,
                    arg3: 0.0,
                    arg4: 0.0);
                }
                if ( DFFlag::LogUdmuxAndRccIp.value && this->ruppEnabled ) /*0x14101867c*/
                {
                  if ( FLog::Output != 0 ) /*0x14101868e*/
                  {
                    v130 = &rccAddress._Mypair._Myval2._Bx._Buf[8]; /*0x141018690*/
                    if ( v160 >= 0x10 ) /*0x141018699*/
                      v130 = *(const char **)&rccAddress._Mypair._Myval2._Bx._Alias[8]; /*0x141018699*/
                    v131 = &this->serverConnections._Mypair._Myval2._Myfirst[v116]; /*0x1410186a5*/
                    v132 = v131->port; /*0x1410186a8*/
                    if ( v131->address._Mypair._Myval2._Myres >= 0x10 ) /*0x1410186b1*/
                      v131 = (RBX::Network::Client::ServerConnection *)v131->address._Mypair._Myval2._Bx._Ptr; /*0x1410186b3*/
                    FLog::FastLogFormatted( /*0x1410186ca*/
                      level: FLog::Output,
                      message: "[FLog::Output] Connecting to UDMUX server %s:%d, and RCC server %s:%d",
                      v131->address._Mypair._Myval2._Bx._Buf,
                      v132,
                      v130,
                      port);
                  }
                }
                else if ( FLog::Output != 0 ) /*0x1410186da*/
                {
                  v133 = &this->serverConnections._Mypair._Myval2._Myfirst[v116]; /*0x1410186e3*/
                  v134 = v133->port; /*0x1410186e6*/
                  if ( v133->address._Mypair._Myval2._Myres >= 0x10 ) /*0x1410186ef*/
                    v133 = (RBX::Network::Client::ServerConnection *)v133->address._Mypair._Myval2._Bx._Ptr; /*0x1410186f1*/
                  FLog::FastLogFormatted( /*0x1410186fb*/
                    level: FLog::Output,
                    message: "[FLog::Output] Connecting to %s:%d",
                    v133->address._Mypair._Myval2._Bx._Buf,
                    v134);
                }
                rccAddress._Mypair._Myval2._Bx._Ptr = (char *)&v163; /*0x141018704*/
                v163._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141018708*/
                v163._Mypair._Myval2._Mysize = 0; /*0x14101870c*/
                v163._Mypair._Myval2._Myres = 15; /*0x141018710*/
                std::string::assign(this: &v163, _Ptr: pass, _Count: 0); /*0x141018726*/
                __wind /*0xf1c000000000004c*/
                {
                  v166 = (RBX::Graphics::ProfilerAdorn::Item *)&v170; /*0x141018733*/
                  v135 = &this->serverConnections._Mypair._Myval2._Myfirst[v116]; /*0x14101873e*/
                  v136 = v135->port; /*0x141018741*/
                  if ( v135->address._Mypair._Myval2._Myres >= 0x10 ) /*0x14101874a*/
                    v135 = (RBX::Network::Client::ServerConnection *)v135->address._Mypair._Myval2._Bx._Ptr; /*0x14101874c*/
                  v137 = RBX::format( /*0x141018762*/
                           result: (RBX::Graphics::ProfilerAdorn::Item *)&v170,
                           fmt: "IP=%s,Port=%d",
                           v135->address._Mypair._Myval2._Bx._Buf,
                           v136);
                  __wind /*0xf1c0000000000028*/
                  {
                    v162._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141018765*/
                    v162._Mypair._Myval2._Mysize = 0; /*0x141018769*/
                    v162._Mypair._Myval2._Myres = 15; /*0x14101876d*/
                    std::string::assign(this: &v162, _Ptr: "ClientConnecting", _Count: 0x10u); /*0x141018786*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: v166); /*0xf1c0000000000038*/
                  }
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)rccAddress._Mypair._Myval2._Bx._Ptr); /*0xf1c0000000000044*/
                }
                RBX::TeleportService::logClientGroupTeleportInfluxDB(event: &v162, status: &v137->text, response: &v163); /*0x141018797*/
              }
              ++v115; /*0x14101879c*/
              ++v116; /*0x14101879f*/
              --sdArray._Mypair._Myval2._Myfirst; /*0x1410187a3*/
            }
            while ( sdArray._Mypair._Myval2._Myfirst != nullptr ); /*0x1410187a9*/
            v114 = v152; /*0x1410187af*/
          }
          Mtx_unlock_0(a1: (_Mtx_t)&this->connectionStateAndJoinDataMutex); /*0x1410187c3*/
          if ( v114 == 0 ) /*0x1410187ca*/
          {
            RBX::runtime_error(result: &pExceptionObject, fmt: "Failed to connect to server, id %d", v122); /*0x1410189a9*/
            throw &pExceptionObject; /*0x1410189ba*/
          }
          RBX::RbxDbgInfo::s_instance.DatacenterID = dataCenterId; /*0x1410187d6*/
          if ( DFFlag::DebugDisableTimeoutDisconnect.value ) /*0x1410187e3*/
          {
            v138 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410187ec*/
            v139 = v138->onInternalError._Mystorage._Ptrs[0][52].__vftable; /*0x1410187f4*/
            v164 = (std::string)RakNet::UNASSIGNED_SYSTEM_ADDRESS_14; /*0x141018802*/
            ((void (__fastcall *)(Luau::InternalErrorReporter *, __int64, std::string *))v139)( /*0x14101881d*/
              a1: v138,
              a2: 600000,
              a3: &v164);
          }
          if ( this->clientReplicationMode == ReplicationMode_StudioAsEditor ) /*0x141018827*/
          {
            v140 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141018830*/
            v141 = v140->onInternalError._Mystorage._Ptrs[0][52].__vftable; /*0x141018838*/
            v161 = (rtc::webrtc_checks_impl::ToStringVal)RakNet::UNASSIGNED_SYSTEM_ADDRESS_14; /*0x141018850*/
            ((void (__fastcall *)(Luau::InternalErrorReporter *, _QWORD, rtc::webrtc_checks_impl::ToStringVal *))v141)( /*0x141018866*/
              a1: v140,
              a2: (unsigned int)(1000 * DFInt::TeamCreateTimeOutInSec),
              a3: &v161);
          }
          if ( __eh34_unwind(13) ) /*0xf1c0000000000014*/
          {
unwind_state_13:
            std::vector<RakNet::SocketDescriptor>::~vector<RakNet::SocketDescriptor>(this: (std::vector<RakNet::SocketDescriptor> *)&sdArray._Mypair._Myval2._Mylast); /*0xf1c0000000000018*/
            __eh34_continue_unwinding(13, 11); /*0xf1c000000000001c*/
          }
          __eh34_exit_wind_state(13, 11); /*0xf1c0000000000020*/
          v142 = sdArray._Mypair._Myval2._Mylast; /*0x14101886a*/
          if ( sdArray._Mypair._Myval2._Mylast != nullptr ) /*0x141018872*/
          {
            if ( (unsigned __int64)(70 * (v155 - sdArray._Mypair._Myval2._Mylast)) >= 0x1000 ) /*0x1410188a5*/
            {
              v142 = *(RakNet::SocketDescriptor **)&sdArray._Mypair._Myval2._Mylast[-1].hostAddress[60]; /*0x1410188ab*/
              if ( (unsigned __int64)((char *)sdArray._Mypair._Myval2._Mylast - (char *)v142 - 8) > 0x1F ) /*0x1410188ba*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410188bc*/
            }
            operator delete(ptr: v142); /*0x1410188c6*/
            *(_OWORD *)&sdArray._Mypair._Myval2._Mylast = 0; /*0x1410188ce*/
            v155 = nullptr; /*0x1410188d4*/
          }
          if ( __eh34_unwind(11) ) /*0xf1c0000000000134*/
          {
unwind_state_11:
            std::tuple<bool,RBX::Reflection::Variant>::~tuple<bool,RBX::Reflection::Variant>(this: (RBX::setupTweenUpdate::__l5::<lambda_fde46e4afccb457705ab91f32d9aea10> *)&playerInfoVar.value); /*0xf1c0000000000138*/
            __eh34_continue_unwinding(11, 3); /*0xf1c000000000013c*/
          }
          __eh34_exit_wind_state(11, 3); /*0xf1c0000000000140*/
          __eh34_enter_wind_state(3, 6); /*0xf1c0000000000144*/
          if ( *(_QWORD *)playerInfoVar.value.data != 0 ) /*0x1410188e0*/
          {
            v143 = *(void (__fastcall **)(std::shared_ptr<RBX::File> *))(*(_QWORD *)playerInfoVar.value.data + 16LL); /*0x1410188e2*/
            if ( v143 == std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>> ) /*0x1410188f7*/
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&playerInfoVar.value.data[8]); /*0x1410188f9*/
            else
              v143(this: (std::shared_ptr<RBX::File> *)&playerInfoVar.value.data[8]); /*0x141018900*/
          }
          if ( v160 >= 0x10 ) /*0x14101890b*/
          {
            v144 = *(void **)&rccAddress._Mypair._Myval2._Bx._Alias[8]; /*0x141018910*/
            if ( v160 + 1 >= 0x1000 ) /*0x14101891e*/
            {
              v144 = *(void **)(*(_QWORD *)&rccAddress._Mypair._Myval2._Bx._Alias[8] - 8LL); /*0x141018924*/
              if ( (unsigned __int64)(*(_QWORD *)&rccAddress._Mypair._Myval2._Bx._Alias[8] - (_QWORD)v144 - 8LL) > 0x1F ) /*0x141018933*/
                _invalid_parameter_noinfo_noreturn(); /*0x141018935*/
            }
            operator delete(ptr: v144); /*0x14101893c*/
          }
          rccAddress._Mypair._Myval2._Myres = 0; /*0x141018941*/
          v160 = 15; /*0x141018945*/
          rccAddress._Mypair._Myval2._Bx._Buf[8] = 0; /*0x14101894d*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: server_deprecated); /*0x141018958*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: userName); /*0x141018965*/
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: playerInfoTable); /*0x141018972*/
          if ( __eh34_unwind(6) ) /*0xf1c00000000001c8*/
            goto unwind_state_6; /*0xf1c00000000001c8*/
          __eh34_exit_wind_state(6, 3); /*0xf1c00000000001cc*/
          if ( __eh34_unwind(3) ) /*0xf1c00000000001d0*/
            goto unwind_state_3; /*0xf1c00000000001d0*/
          __eh34_exit_wind_state(3, 2); /*0xf1c00000000001d4*/
          if ( __eh34_unwind(2) ) /*0xf1c00000000001d8*/
            goto unwind_state_2; /*0xf1c00000000001d8*/
          __eh34_exit_wind_state(2, 1); /*0xf1c00000000001dc*/
          if ( __eh34_unwind(1) ) /*0xf1c00000000001e0*/
            goto unwind_state_1; /*0xf1c00000000001e0*/
          __eh34_exit_wind_state(1, 0); /*0xf1c00000000001e4*/
          return; /*0xf1c00000000001e8*/
        }
      }
    }
    else
    {
      while ( 1 ) /*0x141017c95*/
      {
        v65 = v62->state; /*0x141017c95*/
        if ( v65 <= 2 ) /*0x141017c9c*/
          break; /*0x141017c9c*/
        if ( ++v62 == v63 ) /*0x141017ca5*/
        {
          v66 = (RBX::Time::nowFast(result: (RBX::Time *)&sdArray)->sec - this->lastReportedTime.sec) * 1000.0; /*0x141017cbd*/
          v67 = 0; /*0x141017cc5*/
          if ( v66 >= 9.223372036854776e18 ) /*0x141017cd3*/
          {
            v66 = v66 - 9.223372036854776e18; /*0x141017cd5*/
            if ( v66 < 9.223372036854776e18 ) /*0x141017cdd*/
              v67 = 0x8000000000000000uLL; /*0x141017ce9*/
          }
          v68 = v67 + (unsigned int)(int)v66; /*0x141017cf1*/
          goto LABEL_102; /*0x141017cf4*/
        }
      }
      v61 = false; /*0x141017cf9*/
      if ( DFLog::NetworkTrace == 0 ) /*0x141017d05*/
        goto LABEL_98; /*0x141017d05*/
      v69 = v62->port; /*0x141017d07*/
      if ( v62->address._Mypair._Myval2._Myres >= 0x10 ) /*0x141017d10*/
        v62 = (RBX::Network::Client::ServerConnection *)v62->address._Mypair._Myval2._Bx._Ptr; /*0x141017d12*/
      FLog::FastLogFormatted(
        level: DFLog::NetworkTrace,
        message: "[DFLog::NetworkTrace] noViableConnectionsLeft::: sc(%s:%d).state = %d :: returning false",
        v62->address._Mypair._Myval2._Bx._Buf,
        v69,
        v65);
      v70 = (RBX::Time::nowFast(result: (RBX::Time *)&sdArray)->sec - this->lastReportedTime.sec) * 1000.0; /*0x141017d3b*/
      v71 = 0; /*0x141017d43*/
      if ( v70 >= 9.223372036854776e18 ) /*0x141017d51*/
      {
        v70 = v70 - 9.223372036854776e18; /*0x141017d53*/
        if ( v70 < 9.223372036854776e18 ) /*0x141017d5b*/
          v71 = 0x8000000000000000uLL; /*0x141017d67*/
      }
      v68 = v71 + (unsigned int)(int)v70; /*0x141017d6f*/
    }
    v74 = "JoinStart"; /*0x141017dd2*/
    goto LABEL_104; /*0x141017dd2*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: playerInfoTable); /*0xf1c00000000001a8*/
  }
}

// Address: 0x1410193e0 | Name: ?reportClientLevelNetworkMetricToInflux@Client@Network@RBX@@AEAAXPEBD0_N_K@Z
void __fastcall RBX::Network::Client::reportClientLevelNetworkMetricToInflux(
        RBX::Network::Client *this,
        const char *prefix,
        const char *metric,
        bool endOfSession,
        unsigned __int64 msSinceLastMetric)
{
  std::string *p_lastReportedMetric; // r8
  RBX::Network::Client::ServerConnection *Myfirst; // r8
  int v11; // ebx
  unsigned __int64 v12; // r8
  char *Ptr; // rcx
  char *v14; // rcx
  std::string resource; // [rsp+20h] [rbp-41h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+40h] [rbp-21h] BYREF

  RBX::Analytics::InfluxDb::Points::Points( /*0x14101941e*/
    this: &points,
    throttleHundredthsPercentage: DFInt::ClientNetworkInfluxHundredthsPercentage,
    categoryType: kStandardType,
    priorityHundredthsPercentage: 0);
  __wind /*0xf1c0000000000028*/
  {
    RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "Metric", value: metric); /*0x141019432*/
    p_lastReportedMetric = &this->lastReportedMetric; /*0x141019437*/
    if ( this->lastReportedMetric._Mypair._Myval2._Myres >= 0x10 ) /*0x141019443*/
      p_lastReportedMetric = (std::string *)p_lastReportedMetric->_Mypair._Myval2._Bx._Ptr; /*0x141019445*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141019453*/
      this: &points,
      name: "PreviousMetric",
      value: p_lastReportedMetric->_Mypair._Myval2._Bx._Buf);
    RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "TimeDeltaMs", value: msSinceLastMetric); /*0x141019467*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "EndsSession", value: endOfSession); /*0x14101947b*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141019493*/
      this: &points,
      name: "SessionAlreadyOver",
      value: this->haveReportedEndOfSession);
    RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "DatacenterId", value: this->serverDataCenterId); /*0x1410194aa*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "GameInstanceId", value: &RBX::Http::gameID); /*0x1410194c1*/
    if ( this->playSessionId._Mypair._Myval2._Mysize != 0 ) /*0x1410194ce*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "PlaySessionId", value: &this->playSessionId); /*0x1410194e2*/
    if ( DFFlag::RuppHeaderFromClientEnabled3.value && this->ruppEnabled ) /*0x1410194f0*/
    {
      Myfirst = this->serverConnections._Mypair._Myval2._Myfirst; /*0x1410194f9*/
      if ( Myfirst->address._Mypair._Myval2._Myres >= 0x10 ) /*0x141019505*/
        Myfirst = (RBX::Network::Client::ServerConnection *)Myfirst->address._Mypair._Myval2._Bx._Ptr; /*0x141019507*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x141019515*/
        this: &points,
        name: "UdMuxIp",
        value: Myfirst->address._Mypair._Myval2._Bx._Buf);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x141019530*/
        this: &points,
        name: "UdMuxPort",
        value: this->serverConnections._Mypair._Myval2._Myfirst->port);
    }
    v11 = DFInt::ClientNetworkInfluxHundredthsPercentage; /*0x141019535*/
    resource._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14101953d*/
    resource._Mypair._Myval2._Mysize = 0; /*0x141019541*/
    resource._Mypair._Myval2._Myres = 15; /*0x141019545*/
    v12 = -1; /*0x141019550*/
    do /*0x14101955e*/
      ++v12; /*0x141019557*/
    while ( prefix[v12] != 0 ); /*0x14101955e*/
    std::string::assign(this: &resource, _Ptr: prefix, _Count: v12); /*0x141019567*/
    __wind /*0xf1c000000000001c*/
    {
      RBX::Analytics::InfluxDb::Points::report( /*0x14101957b*/
        this: &points,
        &resource,
        throttleHundredthsPercentage: v11,
        blocking: false);
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000014*/
    }
    if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x141019589*/
    {
      Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x14101958e*/
      if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101959c*/
      {
        Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x1410195a2*/
        if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410195b1*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410195b3*/
      }
      operator delete(ptr: Ptr); /*0x1410195ba*/
    }
    if ( points.userIdOverride._Mypair._Myval2._Myres >= 0x10 ) /*0x1410195c8*/
    {
      v14 = points.userIdOverride._Mypair._Myval2._Bx._Ptr; /*0x1410195cd*/
      if ( points.userIdOverride._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410195db*/
      {
        v14 = *((char **)points.userIdOverride._Mypair._Myval2._Bx._Ptr - 1); /*0x1410195e1*/
        if ( (unsigned __int64)(points.userIdOverride._Mypair._Myval2._Bx._Ptr - v14 - 8) > 0x1F ) /*0x1410195f0*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410195f2*/
      }
      operator delete(ptr: v14); /*0x1410195f9*/
    }
    *(__m128i *)&points.userIdOverride._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x141019606*/
    points.userIdOverride._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101960b*/
    std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&points); /*0x141019613*/
  }
  __unwind
  {
    RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c0000000000008*/
  }
}

// Address: 0x141019640 | Name: ?reportConnectionLevelNetworkMetricToInflux@Client@Network@RBX@@AEAAXPEBD@Z
void __fastcall RBX::Network::Client::reportConnectionLevelNetworkMetricToInflux(
        RBX::Network::Client *this,
        const char *prefix)
{
  RBX::Network::Client::ServerConnection *Myfirst; // rbx
  RBX::Network::Client::ServerConnection *i; // r12
  const char *Buf; // rsi
  const char *Ptr; // r8
  unsigned __int16 socketFamily; // ax
  int v9; // r8d
  RBX::Network::Client::ServerConnection *v10; // r8
  int v11; // edi
  unsigned __int64 v12; // r8
  char *v13; // rcx
  const char *v14; // r8
  char *v15; // rcx
  std::string resource; // [rsp+30h] [rbp-59h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+50h] [rbp-39h] BYREF

  Myfirst = this->serverConnections._Mypair._Myval2._Myfirst; /*0x14101966a*/
  for ( i = this->serverConnections._Mypair._Myval2._Mylast; Myfirst != i; ++Myfirst )
  {
    if ( (unsigned int)(Myfirst->state - 2) <= 1 )
    {
      RBX::Analytics::InfluxDb::Points::Points( /*0x1410196af*/
        this: &points,
        throttleHundredthsPercentage: DFInt::ClientNetworkInfluxHundredthsPercentage,
        categoryType: kStandardType,
        priorityHundredthsPercentage: 0);
      __eh34_enter_wind_state(-1, 0); /*0xf1c000000000003c*/
      Buf = Myfirst->reportMetric._Mypair._Myval2._Bx._Buf; /*0x1410196b5*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "Metric", value: &Myfirst->reportMetric); /*0x1410196c7*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "DatacenterId", value: this->serverDataCenterId); /*0x1410196de*/
      Ptr = (const char *)Myfirst; /*0x1410196e3*/
      if ( Myfirst->address._Mypair._Myval2._Myres >= 0x10 ) /*0x1410196eb*/
        Ptr = Myfirst->address._Mypair._Myval2._Bx._Ptr; /*0x1410196ed*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "ServerIp", value: Ptr); /*0x1410196fb*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "ServerPort", value: Myfirst->port); /*0x14101970f*/
      socketFamily = Myfirst->socketFamily; /*0x141019714*/
      if ( socketFamily == 23 ) /*0x14101971c*/
      {
        v9 = 6; /*0x14101971e*/
      }
      else if ( socketFamily == 2 ) /*0x14101972a*/
      {
        v9 = 4; /*0x14101972c*/
      }
      else
      {
        v9 = -(socketFamily != 0); /*0x141019737*/
      }
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "ClientSocketIPVersion", value: v9); /*0x141019745*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "ServerConnectionState", value: Myfirst->state); /*0x141019759*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x141019770*/
        this: &points,
        name: "ClientJoinState",
        value: this->reportingJoinState);
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "GameInstanceId", value: &RBX::Http::gameID); /*0x141019787*/
      if ( DFFlag::RuppHeaderFromClientEnabled3.value && this->ruppEnabled ) /*0x141019795*/
      {
        v10 = this->serverConnections._Mypair._Myval2._Myfirst; /*0x14101979f*/
        if ( v10->address._Mypair._Myval2._Myres >= 0x10 ) /*0x1410197ab*/
          v10 = (RBX::Network::Client::ServerConnection *)v10->address._Mypair._Myval2._Bx._Ptr; /*0x1410197ad*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410197bb*/
          this: &points,
          name: "UdMuxIp",
          value: v10->address._Mypair._Myval2._Bx._Buf);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410197d6*/
          this: &points,
          name: "UdMuxPort",
          value: this->serverConnections._Mypair._Myval2._Myfirst->port);
      }
      v11 = DFInt::ClientNetworkInfluxHundredthsPercentage; /*0x1410197db*/
      resource._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410197e1*/
      resource._Mypair._Myval2._Mysize = 0; /*0x1410197e5*/
      resource._Mypair._Myval2._Myres = 15; /*0x1410197e9*/
      v12 = -1; /*0x1410197f5*/
      do /*0x141019808*/
        ++v12; /*0x141019800*/
      while ( prefix[v12] != 0 ); /*0x141019808*/
      std::string::assign(this: &resource, _Ptr: prefix, _Count: v12); /*0x141019811*/
      __wind /*0xf1c0000000000030*/
      {
        RBX::Analytics::InfluxDb::Points::report( /*0x141019825*/
          this: &points,
          &resource,
          throttleHundredthsPercentage: v11,
          blocking: false);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000028*/
      }
      if ( resource._Mypair._Myval2._Myres < 0x10 ) /*0x141019833*/
      {
        if ( __eh34_unwind(0) ) /*0xf1c0000000000004*/
        {
unwind_state_0:
          RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c0000000000008*/
          __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000000c*/
        }
        __eh34_exit_wind_state(0, -1); /*0xf1c0000000000010*/
      }
      else
      {
        if ( __eh34_unwind(0) ) /*0xf1c0000000000018*/
          goto unwind_state_0; /*0xf1c0000000000018*/
        __eh34_exit_wind_state(0, -1); /*0xf1c000000000001c*/
        v13 = resource._Mypair._Myval2._Bx._Ptr; /*0x141019838*/
        if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141019846*/
        {
          v13 = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x14101984c*/
          if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - v13 - 8) > 0x1F ) /*0x14101985b*/
            _invalid_parameter_noinfo_noreturn(); /*0x14101991e*/
        }
        operator delete(ptr: v13); /*0x141019861*/
      }
      if ( DFLog::NetworkTrace != 0 )
      {
        if ( Myfirst->reportMetric._Mypair._Myval2._Myres >= 0x10 ) /*0x141019876*/
          Buf = *(const char **)Buf; /*0x141019878*/
        v14 = (const char *)Myfirst; /*0x14101987b*/
        if ( Myfirst->address._Mypair._Myval2._Myres >= 0x10 ) /*0x141019883*/
          v14 = Myfirst->address._Mypair._Myval2._Bx._Ptr; /*0x141019885*/
        FLog::FastLogFormatted(
          level: DFLog::NetworkTrace,
          message: "[DFLog::NetworkTrace] Reporting per server(%s:%d) metric to influx: %s.",
          v14,
          Myfirst->port,
          Buf);
      }
      if ( points.userIdOverride._Mypair._Myval2._Myres >= 0x10 ) /*0x1410198a8*/
      {
        v15 = points.userIdOverride._Mypair._Myval2._Bx._Ptr; /*0x1410198ad*/
        if ( points.userIdOverride._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410198bb*/
        {
          v15 = *((char **)points.userIdOverride._Mypair._Myval2._Bx._Ptr - 1); /*0x1410198c1*/
          if ( (unsigned __int64)(points.userIdOverride._Mypair._Myval2._Bx._Ptr - v15 - 8) > 0x1F ) /*0x1410198d0*/
            _invalid_parameter_noinfo_noreturn(); /*0x141019925*/
        }
        operator delete(ptr: v15); /*0x1410198d2*/
      }
      points.userIdOverride._Mypair._Myval2._Mysize = 0; /*0x1410198d7*/
      points.userIdOverride._Mypair._Myval2._Myres = 15; /*0x1410198db*/
      points.userIdOverride._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410198e3*/
      std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&points); /*0x1410198eb*/
    }
  }
}

// Address: 0x141019930 | Name: ?reportNetworkMetricToDiag@Client@Network@RBX@@AEAAXPEBD0_N_K@Z
void __fastcall RBX::Network::Client::reportNetworkMetricToDiag(
        RBX::Network::Client *this,
        const char *prefix,
        const char *metric,
        bool endOfSession,
        __int64 msSinceLastMetric)
{
  __int64 v9; // rbx
  const char *v10; // rsi
  double v11; // xmm6_8
  RBX::Graphics::ProfilerAdorn::Item *v12; // rax
  std::pair<std::string,double> *Myend; // rdx
  char *Ptr; // rcx
  std::string *v15; // rax
  RBX::Graphics::ProfilerAdorn::Item *v16; // rax
  std::pair<std::string,double> *v17; // rdx
  char *v18; // rcx
  void *v19; // rcx
  RBX::Graphics::ProfilerAdorn::Item *v20; // rax
  std::pair<std::string,double> *v21; // rdx
  void *v22; // rcx
  std::string *v23; // rax
  RBX::Graphics::ProfilerAdorn::Item *v24; // rax
  std::pair<std::string,double> *v25; // rdx
  void *v26; // rcx
  std::string *v27; // rbx
  std::string *v28; // rax
  RBX::Graphics::ProfilerAdorn::Item *v29; // rax
  std::pair<std::string,double> *v30; // rdx
  void *v31; // rcx
  RBX::Network::ClientReplicator *clientReplicator; // rcx
  __int64 v33; // rcx
  double v34; // xmm6_8
  RBX::Graphics::ProfilerAdorn::Item *v35; // rax
  std::pair<std::string,double> *v36; // rdx
  void *v37; // rcx
  RBX::Graphics::ProfilerAdorn::Item *v38; // rax
  std::pair<std::string,double> *v39; // rdx
  void *v40; // rcx
  std::pair<std::string,double> *Mylast; // rbx
  std::pair<std::string,double> *v42; // rdi
  unsigned __int64 Myres; // rdx
  char *v44; // rcx
  std::pair<std::string,double> *v45; // rax
  std::vector<std::pair<std::string,double>> stats; // [rsp+30h] [rbp-49h] BYREF
  std::pair<std::string,double> *v47; // [rsp+48h] [rbp-31h]
  RBX::Graphics::ProfilerAdorn::Item result; // [rsp+50h] [rbp-29h] BYREF
  unsigned __int64 v49; // [rsp+88h] [rbp+Fh]

  v9 = msSinceLastMetric; /*0x141019964*/
  if ( DFLog::NetworkTrace != 0 )
    FLog::FastLogFormatted(
      level: DFLog::NetworkTrace,
      message: "[DFLog::NetworkTrace] Reporting network metric: %s to diag. Time since last metric = %u",
      metric,
      msSinceLastMetric);
  *(_OWORD *)&stats._Mypair._Myval2._Mylast = 0; /*0x141019987*/
  v47 = nullptr; /*0x14101998f*/
  v10 = "EventAfterEndOfSession"; /*0x141019993*/
  if ( !this->haveReportedEndOfSession ) /*0x1410199a1*/
    v10 = metric; /*0x1410199a1*/
  if ( v9 < 0 ) /*0x1410199ab*/
    v11 = (double)(int)(v9 & 1 | ((unsigned __int64)v9 >> 1)) + (double)(int)(v9 & 1 | ((unsigned __int64)v9 >> 1)); /*0x1410199c5*/
  else
    v11 = (double)(int)v9; /*0x1410199ad*/
  __wind /*0xf1c00000000000c0*/
  {
    msSinceLastMetric = *(_QWORD *)&v11; /*0x1410199c9*/
    v12 = RBX::format(&result, fmt: "%s_%s", prefix, v10); /*0x1410199df*/
    __wind /*0xf1c00000000000b4*/
    {
      Myend = stats._Mypair._Myval2._Myend; /*0x1410199e5*/
      if ( stats._Mypair._Myval2._Myend == v47 ) /*0x1410199ed*/
      {
        std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x141019a2e*/
          this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
          _Whereptr: stats._Mypair._Myval2._Myend,
          <_Val_0>: &v12->text,
          <_Val_1>: (long double *)&msSinceLastMetric);
      }
      else
      {
        *(_QWORD *)stats._Mypair._Myval2._Myend = 0; /*0x1410199ef*/
        Myend->first._Mypair._Myval2._Mysize = 0; /*0x1410199f2*/
        Myend->first._Mypair._Myval2._Myres = 0; /*0x1410199f6*/
        Myend->first._Mypair._Myval2._Bx = v12->text._Mypair._Myval2._Bx; /*0x1410199fd*/
        *(_OWORD *)&Myend->first._Mypair._Myval2._Mysize = *(_OWORD *)&v12->text._Mypair._Myval2._Mysize; /*0x141019a04*/
        v12->text._Mypair._Myval2._Mysize = 0; /*0x141019a08*/
        v12->text._Mypair._Myval2._Myres = 15; /*0x141019a0c*/
        v12->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141019a14*/
        Myend->second = v11; /*0x141019a17*/
        ++stats._Mypair._Myval2._Myend; /*0x141019a1c*/
      }
      if ( result.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141019a3c*/
      {
        Ptr = result.text._Mypair._Myval2._Bx._Ptr; /*0x141019a41*/
        if ( result.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141019a4f*/
        {
          Ptr = *((char **)result.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141019a55*/
          if ( (unsigned __int64)(result.text._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141019a64*/
            _invalid_parameter_noinfo_noreturn(); /*0x141019a66*/
        }
        operator delete(ptr: Ptr); /*0x141019a6d*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: &result); /*0xf1c00000000000ac*/
    }
    msSinceLastMetric = *(_QWORD *)&v11; /*0x141019a72*/
    v15 = RBX::SystemUtil::osPlatform(result: (std::string *)&result.x); /*0x141019a7b*/
    if ( v15->_Mypair._Myval2._Myres >= 0x10 ) /*0x141019a86*/
      v15 = (std::string *)v15->_Mypair._Myval2._Bx._Ptr; /*0x141019a88*/
    __eh34_enter_wind_state(0, 2); /*0xf1c00000000000a0*/
    v16 = RBX::format(&result, fmt: "%s_%s_Platform_%s", prefix, v10, v15->_Mypair._Myval2._Bx._Buf); /*0x141019aa1*/
    v17 = stats._Mypair._Myval2._Myend; /*0x141019aa7*/
    if ( stats._Mypair._Myval2._Myend == v47 ) /*0x141019aaf*/
    {
      __wind /*0xf1c0000000000088*/
      {
        std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x141019af0*/
          this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
          _Whereptr: stats._Mypair._Myval2._Myend,
          <_Val_0>: &v16->text,
          <_Val_1>: (long double *)&msSinceLastMetric);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &result); /*0xf1c0000000000098*/
      }
    }
    else
    {
      *(_QWORD *)stats._Mypair._Myval2._Myend = 0; /*0x141019ab1*/
      v17->first._Mypair._Myval2._Mysize = 0; /*0x141019ab4*/
      v17->first._Mypair._Myval2._Myres = 0; /*0x141019ab8*/
      v17->first._Mypair._Myval2._Bx = v16->text._Mypair._Myval2._Bx; /*0x141019abf*/
      *(_OWORD *)&v17->first._Mypair._Myval2._Mysize = *(_OWORD *)&v16->text._Mypair._Myval2._Mysize; /*0x141019ac6*/
      v16->text._Mypair._Myval2._Mysize = 0; /*0x141019aca*/
      v16->text._Mypair._Myval2._Myres = 15; /*0x141019ace*/
      v16->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141019ad6*/
      v17->second = v11; /*0x141019ad9*/
      ++stats._Mypair._Myval2._Myend; /*0x141019ade*/
    }
    if ( __eh34_unwind(2) ) /*0xf1c000000000007c*/
    {
unwind_state_2:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result.x); /*0xf1c0000000000014*/
      __eh34_continue_unwinding(2, 0); /*0xf1c0000000000018*/
    }
    __eh34_exit_wind_state(2, 0); /*0xf1c0000000000080*/
    if ( result.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141019afe*/
    {
      v18 = result.text._Mypair._Myval2._Bx._Ptr; /*0x141019b03*/
      if ( result.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141019b11*/
      {
        v18 = *((char **)result.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141019b17*/
        if ( (unsigned __int64)(result.text._Mypair._Myval2._Bx._Ptr - v18 - 8) > 0x1F ) /*0x141019b26*/
          _invalid_parameter_noinfo_noreturn(); /*0x141019b28*/
      }
      operator delete(ptr: v18); /*0x141019b2f*/
    }
    result.text._Mypair._Myval2._Mysize = 0; /*0x141019b34*/
    result.text._Mypair._Myval2._Myres = 15; /*0x141019b38*/
    result.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141019b40*/
    if ( v49 >= 0x10 ) /*0x141019b4c*/
    {
      v19 = *(void **)&result.x; /*0x141019b51*/
      if ( v49 + 1 >= 0x1000 ) /*0x141019b5f*/
      {
        v19 = *(void **)(*(_QWORD *)&result.x - 8LL); /*0x141019b65*/
        if ( (unsigned __int64)(*(_QWORD *)&result.x - (_QWORD)v19 - 8LL) > 0x1F ) /*0x141019b74*/
          _invalid_parameter_noinfo_noreturn(); /*0x141019b76*/
      }
      operator delete(ptr: v19); /*0x141019b7d*/
    }
    msSinceLastMetric = *(_QWORD *)&v11; /*0x141019b82*/
    v20 = RBX::format( /*0x141019ba3*/
            result: (RBX::Graphics::ProfilerAdorn::Item *)&result.x,
            fmt: "%s_%s_DatacenterId_%d",
            prefix,
            v10,
            this->serverDataCenterId);
    __eh34_enter_wind_state(0, 2); /*0xf1c0000000000074*/
    v21 = stats._Mypair._Myval2._Myend; /*0x141019ba9*/
    if ( stats._Mypair._Myval2._Myend == v47 ) /*0x141019bb1*/
    {
      std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x141019bf2*/
        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
        _Whereptr: stats._Mypair._Myval2._Myend,
        <_Val_0>: &v20->text,
        <_Val_1>: (long double *)&msSinceLastMetric);
    }
    else
    {
      *(_QWORD *)stats._Mypair._Myval2._Myend = 0; /*0x141019bb3*/
      v21->first._Mypair._Myval2._Mysize = 0; /*0x141019bb6*/
      v21->first._Mypair._Myval2._Myres = 0; /*0x141019bba*/
      v21->first._Mypair._Myval2._Bx = v20->text._Mypair._Myval2._Bx; /*0x141019bc1*/
      *(_OWORD *)&v21->first._Mypair._Myval2._Mysize = *(_OWORD *)&v20->text._Mypair._Myval2._Mysize; /*0x141019bc8*/
      v20->text._Mypair._Myval2._Mysize = 0; /*0x141019bcc*/
      v20->text._Mypair._Myval2._Myres = 15; /*0x141019bd0*/
      v20->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141019bd8*/
      v21->second = v11; /*0x141019bdb*/
      ++stats._Mypair._Myval2._Myend; /*0x141019be0*/
    }
    if ( v49 >= 0x10 ) /*0x141019c00*/
    {
      v22 = *(void **)&result.x; /*0x141019c05*/
      if ( v49 + 1 >= 0x1000 ) /*0x141019c13*/
      {
        v22 = *(void **)(*(_QWORD *)&result.x - 8LL); /*0x141019c19*/
        if ( (unsigned __int64)(*(_QWORD *)&result.x - (_QWORD)v22 - 8LL) > 0x1F ) /*0x141019c28*/
          _invalid_parameter_noinfo_noreturn(); /*0x141019c2a*/
      }
      operator delete(ptr: v22); /*0x141019c31*/
    }
    msSinceLastMetric = *(_QWORD *)&v11; /*0x141019c36*/
    v23 = &RBX::Analytics::location; /*0x141019c3b*/
    if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x141019c4a*/
      v23 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x141019c4a*/
    if ( __eh34_unwind(2) ) /*0xf1c0000000000068*/
      goto unwind_state_2; /*0xf1c0000000000068*/
    __eh34_exit_wind_state(2, 0); /*0xf1c000000000006c*/
    v24 = RBX::format( /*0x141019c68*/
            result: (RBX::Graphics::ProfilerAdorn::Item *)&result.x,
            fmt: "%s_%s_Country_%s",
            prefix,
            v10,
            v23->_Mypair._Myval2._Bx._Buf);
    __eh34_enter_wind_state(0, 2); /*0xf1c0000000000060*/
    v25 = stats._Mypair._Myval2._Myend; /*0x141019c6e*/
    if ( stats._Mypair._Myval2._Myend == v47 ) /*0x141019c76*/
    {
      std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x141019cb7*/
        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
        _Whereptr: stats._Mypair._Myval2._Myend,
        <_Val_0>: &v24->text,
        <_Val_1>: (long double *)&msSinceLastMetric);
    }
    else
    {
      *(_QWORD *)stats._Mypair._Myval2._Myend = 0; /*0x141019c78*/
      v25->first._Mypair._Myval2._Mysize = 0; /*0x141019c7b*/
      v25->first._Mypair._Myval2._Myres = 0; /*0x141019c7f*/
      v25->first._Mypair._Myval2._Bx = v24->text._Mypair._Myval2._Bx; /*0x141019c86*/
      *(_OWORD *)&v25->first._Mypair._Myval2._Mysize = *(_OWORD *)&v24->text._Mypair._Myval2._Mysize; /*0x141019c8d*/
      v24->text._Mypair._Myval2._Mysize = 0; /*0x141019c91*/
      v24->text._Mypair._Myval2._Myres = 15; /*0x141019c95*/
      v24->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141019c9d*/
      v25->second = v11; /*0x141019ca0*/
      ++stats._Mypair._Myval2._Myend; /*0x141019ca5*/
    }
    if ( v49 >= 0x10 ) /*0x141019cc5*/
    {
      v26 = *(void **)&result.x; /*0x141019cca*/
      if ( v49 + 1 >= 0x1000 ) /*0x141019cd8*/
      {
        v26 = *(void **)(*(_QWORD *)&result.x - 8LL); /*0x141019cde*/
        if ( (unsigned __int64)(*(_QWORD *)&result.x - (_QWORD)v26 - 8LL) > 0x1F ) /*0x141019ced*/
          _invalid_parameter_noinfo_noreturn(); /*0x141019cef*/
      }
      operator delete(ptr: v26); /*0x141019cf6*/
    }
    v27 = &RBX::Http::placeID; /*0x141019cfb*/
    if ( FFlag::DebugClientNetworkPerPlaceMetrics.value ) /*0x141019d09*/
    {
      msSinceLastMetric = *(_QWORD *)&v11; /*0x141019d0f*/
      v28 = &RBX::Http::placeID; /*0x141019d14*/
      if ( RBX::Http::placeID._Mypair._Myval2._Myres >= 0x10 ) /*0x141019d1f*/
        v28 = (std::string *)RBX::Http::placeID._Mypair._Myval2._Bx._Ptr; /*0x141019d1f*/
      if ( __eh34_unwind(2) ) /*0xf1c0000000000054*/
        goto unwind_state_2; /*0xf1c0000000000054*/
      __eh34_exit_wind_state(2, 0); /*0xf1c0000000000058*/
      v29 = RBX::format( /*0x141019d3d*/
              result: (RBX::Graphics::ProfilerAdorn::Item *)&result.x,
              fmt: "%s_%s_PlaceId_%s",
              prefix,
              v10,
              v28->_Mypair._Myval2._Bx._Buf);
      __eh34_enter_wind_state(0, 2); /*0xf1c000000000004c*/
      v30 = stats._Mypair._Myval2._Myend; /*0x141019d43*/
      if ( stats._Mypair._Myval2._Myend == v47 ) /*0x141019d4b*/
      {
        std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x141019d8c*/
          this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
          _Whereptr: stats._Mypair._Myval2._Myend,
          <_Val_0>: &v29->text,
          <_Val_1>: (long double *)&msSinceLastMetric);
      }
      else
      {
        *(_QWORD *)stats._Mypair._Myval2._Myend = 0; /*0x141019d4d*/
        v30->first._Mypair._Myval2._Mysize = 0; /*0x141019d50*/
        v30->first._Mypair._Myval2._Myres = 0; /*0x141019d54*/
        v30->first._Mypair._Myval2._Bx = v29->text._Mypair._Myval2._Bx; /*0x141019d5b*/
        *(_OWORD *)&v30->first._Mypair._Myval2._Mysize = *(_OWORD *)&v29->text._Mypair._Myval2._Mysize; /*0x141019d62*/
        v29->text._Mypair._Myval2._Mysize = 0; /*0x141019d66*/
        v29->text._Mypair._Myval2._Myres = 15; /*0x141019d6a*/
        v29->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141019d72*/
        v30->second = v11; /*0x141019d75*/
        ++stats._Mypair._Myval2._Myend; /*0x141019d7a*/
      }
      if ( v49 >= 0x10 ) /*0x141019d9a*/
      {
        v31 = *(void **)&result.x; /*0x141019d9f*/
        if ( v49 + 1 >= 0x1000 ) /*0x141019dad*/
        {
          v31 = *(void **)(*(_QWORD *)&result.x - 8LL); /*0x141019db3*/
          if ( (unsigned __int64)(*(_QWORD *)&result.x - (_QWORD)v31 - 8LL) > 0x1F ) /*0x141019dc2*/
            _invalid_parameter_noinfo_noreturn(); /*0x141019dc4*/
        }
        operator delete(ptr: v31); /*0x141019dcb*/
      }
    }
    if ( this->reportingJoinState == JoinState_RakNetPasswordAccepted && endOfSession ) /*0x141019de1*/
    {
      clientReplicator = this->clientReplicator; /*0x141019de7*/
      if ( clientReplicator != nullptr ) /*0x141019df1*/
      {
        v33 = clientReplicator->replicatorStats.peerStats.rakStats.runningTotal[6]; /*0x141019df7*/
        if ( v33 < 0 ) /*0x141019e04*/
          v34 = (double)(int)(v33 & 1 | ((unsigned __int64)v33 >> 1)) /*0x141019e1e*/
              + (double)(int)(v33 & 1 | ((unsigned __int64)v33 >> 1));
        else
          v34 = (double)(int)v33; /*0x141019e06*/
        if ( __eh34_unwind(2) ) /*0xf1c0000000000040*/
          goto unwind_state_2; /*0xf1c0000000000040*/
        __eh34_exit_wind_state(2, 0); /*0xf1c0000000000044*/
        msSinceLastMetric = *(_QWORD *)&v34; /*0x141019e22*/
        v35 = RBX::format( /*0x141019e38*/
                result: (RBX::Graphics::ProfilerAdorn::Item *)&result.x,
                fmt: "%s_%s_RakRecvBeforeFail",
                prefix,
                v10);
        __eh34_enter_wind_state(0, 2); /*0xf1c0000000000038*/
        v36 = stats._Mypair._Myval2._Myend; /*0x141019e3e*/
        if ( stats._Mypair._Myval2._Myend == v47 ) /*0x141019e46*/
        {
          std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x141019e87*/
            this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
            _Whereptr: stats._Mypair._Myval2._Myend,
            <_Val_0>: &v35->text,
            <_Val_1>: (long double *)&msSinceLastMetric);
        }
        else
        {
          *(_QWORD *)stats._Mypair._Myval2._Myend = 0; /*0x141019e48*/
          v36->first._Mypair._Myval2._Mysize = 0; /*0x141019e4b*/
          v36->first._Mypair._Myval2._Myres = 0; /*0x141019e4f*/
          v36->first._Mypair._Myval2._Bx = v35->text._Mypair._Myval2._Bx; /*0x141019e56*/
          *(_OWORD *)&v36->first._Mypair._Myval2._Mysize = *(_OWORD *)&v35->text._Mypair._Myval2._Mysize; /*0x141019e5d*/
          v35->text._Mypair._Myval2._Mysize = 0; /*0x141019e61*/
          v35->text._Mypair._Myval2._Myres = 15; /*0x141019e65*/
          v35->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141019e6d*/
          v36->second = v34; /*0x141019e70*/
          ++stats._Mypair._Myval2._Myend; /*0x141019e75*/
        }
        if ( v49 >= 0x10 ) /*0x141019e95*/
        {
          v37 = *(void **)&result.x; /*0x141019e9a*/
          if ( v49 + 1 >= 0x1000 ) /*0x141019ea8*/
          {
            v37 = *(void **)(*(_QWORD *)&result.x - 8LL); /*0x141019eae*/
            if ( (unsigned __int64)(*(_QWORD *)&result.x - (_QWORD)v37 - 8LL) > 0x1F ) /*0x141019ebd*/
              _invalid_parameter_noinfo_noreturn(); /*0x141019ebf*/
          }
          operator delete(ptr: v37); /*0x141019ec6*/
        }
        msSinceLastMetric = *(_QWORD *)&v34; /*0x141019ecb*/
        if ( RBX::Http::placeID._Mypair._Myval2._Myres >= 0x10 ) /*0x141019ed8*/
          v27 = (std::string *)RBX::Http::placeID._Mypair._Myval2._Bx._Ptr; /*0x141019ed8*/
        if ( __eh34_unwind(2) ) /*0xf1c000000000002c*/
          goto unwind_state_2; /*0xf1c000000000002c*/
        __eh34_exit_wind_state(2, 0); /*0xf1c0000000000030*/
        v38 = RBX::format( /*0x141019ef6*/
                result: (RBX::Graphics::ProfilerAdorn::Item *)&result.x,
                fmt: "%s_%s_RakRecvBeforeFailWithPlace_%s",
                prefix,
                v10,
                v27->_Mypair._Myval2._Bx._Buf);
        __eh34_enter_wind_state(0, 2); /*0xf1c0000000000024*/
        v39 = stats._Mypair._Myval2._Myend; /*0x141019efc*/
        if ( stats._Mypair._Myval2._Myend == v47 ) /*0x141019f04*/
        {
          std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x141019f45*/
            this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
            _Whereptr: stats._Mypair._Myval2._Myend,
            <_Val_0>: &v38->text,
            <_Val_1>: (long double *)&msSinceLastMetric);
        }
        else
        {
          *(_QWORD *)stats._Mypair._Myval2._Myend = 0; /*0x141019f06*/
          v39->first._Mypair._Myval2._Mysize = 0; /*0x141019f09*/
          v39->first._Mypair._Myval2._Myres = 0; /*0x141019f0d*/
          v39->first._Mypair._Myval2._Bx = v38->text._Mypair._Myval2._Bx; /*0x141019f14*/
          *(_OWORD *)&v39->first._Mypair._Myval2._Mysize = *(_OWORD *)&v38->text._Mypair._Myval2._Mysize; /*0x141019f1b*/
          v38->text._Mypair._Myval2._Mysize = 0; /*0x141019f1f*/
          v38->text._Mypair._Myval2._Myres = 15; /*0x141019f23*/
          v38->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141019f2b*/
          v39->second = v34; /*0x141019f2e*/
          ++stats._Mypair._Myval2._Myend; /*0x141019f33*/
        }
        if ( v49 >= 0x10 ) /*0x141019f53*/
        {
          v40 = *(void **)&result.x; /*0x141019f58*/
          if ( v49 + 1 >= 0x1000 ) /*0x141019f66*/
          {
            v40 = *(void **)(*(_QWORD *)&result.x - 8LL); /*0x141019f6c*/
            if ( (unsigned __int64)(*(_QWORD *)&result.x - (_QWORD)v40 - 8LL) > 0x1F ) /*0x141019f7b*/
              _invalid_parameter_noinfo_noreturn(); /*0x141019f7d*/
          }
          operator delete(ptr: v40); /*0x141019f84*/
        }
      }
    }
    if ( __eh34_unwind(2) ) /*0xf1c0000000000010*/
      goto unwind_state_2; /*0xf1c0000000000010*/
    __eh34_exit_wind_state(2, 0); /*0xf1c000000000001c*/
    RBX::Analytics::EphemeralCounter::bulkReportStats( /*0x141019f8f*/
      stats: (const std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
      blocking: false);
    Mylast = stats._Mypair._Myval2._Mylast; /*0x141019f95*/
    if ( stats._Mypair._Myval2._Mylast != nullptr ) /*0x141019f9c*/
    {
      v42 = stats._Mypair._Myval2._Myend; /*0x141019fa2*/
      if ( stats._Mypair._Myval2._Mylast != stats._Mypair._Myval2._Myend ) /*0x141019fa9*/
      {
        do /*0x141019ffc*/
        {
          Myres = Mylast->first._Mypair._Myval2._Myres; /*0x141019fb0*/
          if ( Myres >= 0x10 ) /*0x141019fb8*/
          {
            v44 = Mylast->first._Mypair._Myval2._Bx._Ptr; /*0x141019fbd*/
            if ( Myres + 1 >= 0x1000 ) /*0x141019fc7*/
            {
              if ( (unsigned __int64)&v44[-*((_QWORD *)v44 - 1) - 8] > 0x1F ) /*0x141019fdc*/
                goto LABEL_94; /*0x141019fdc*/
              v44 = *((char **)v44 - 1); /*0x141019fde*/
            }
            operator delete(ptr: v44); /*0x141019fe1*/
          }
          Mylast->first._Mypair._Myval2._Mysize = 0; /*0x141019fe6*/
          Mylast->first._Mypair._Myval2._Myres = 15; /*0x141019fea*/
          Mylast->first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141019ff2*/
          ++Mylast; /*0x141019ff5*/
        }
        while ( Mylast != v42 ); /*0x141019ffc*/
        Mylast = stats._Mypair._Myval2._Mylast; /*0x141019ffe*/
      }
      v45 = Mylast; /*0x14101a02c*/
      if ( (unsigned __int64)(40 * (v47 - Mylast)) >= 0x1000 ) /*0x14101a036*/
      {
        Mylast = *(std::pair<std::string,double> **)&Mylast[-1].second; /*0x14101a03c*/
        if ( (unsigned __int64)((char *)v45 - (char *)Mylast - 8) > 0x1F ) /*0x14101a04b*/
LABEL_94:
          _invalid_parameter_noinfo_noreturn(); /*0x14101a04d*/
      }
      operator delete(ptr: Mylast); /*0x14101a057*/
    }
  }
  __unwind
  {
    std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)&stats._Mypair._Myval2._Mylast); /*0xf1c0000000000008*/
  }
}

// Address: 0x14101a090 | Name: ?reportNetworkMetricToGA@Client@Network@RBX@@AEAAXPEBD0@Z
void __fastcall RBX::Network::Client::reportNetworkMetricToGA(
        RBX::Network::Client *this,
        const char *prefix,
        const char *metric)
{
  unsigned __int64 v5; // r8
  unsigned __int64 Mysize; // rcx
  std::string *p_gaPrefix; // rbx
  char *v8; // rbx
  std::string *Ptr; // rax
  char *v10; // rcx
  std::string *v11; // rsi
  std::string *v12; // r8
  std::string *p_metricByVersionForPlatform; // rdx
  std::string *v14; // rcx
  std::string *v15; // r14
  std::string *v16; // r8
  std::string *p_metricByLocationForDataCenterId; // rdx
  std::string *v18; // rcx
  unsigned __int64 v19; // rcx
  std::string *v20; // rbx
  char *v21; // rbx
  std::string *v22; // rdx
  std::string *v23; // rcx
  std::string *v24; // rdx
  std::string *v25; // rcx
  char *v26; // rcx
  char *v27; // rcx
  char *v28; // rcx
  char *v29; // rcx
  std::string gaPrefix; // [rsp+30h] [rbp-59h] BYREF
  std::string metricByLocationForDataCenterId; // [rsp+50h] [rbp-39h] BYREF
  std::string metricByVersionForPlatform; // [rsp+70h] [rbp-19h] BYREF
  std::string result; // [rsp+90h] [rbp+7h] BYREF
  std::string metricByIpForDataCenterId; // [rsp+B0h] [rbp+27h] BYREF

  gaPrefix._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14101a0b9*/
  gaPrefix._Mypair._Myval2._Mysize = 0; /*0x14101a0bd*/
  gaPrefix._Mypair._Myval2._Myres = 15; /*0x14101a0c1*/
  v5 = -1; /*0x14101a0cd*/
  do /*0x14101a0db*/
    ++v5; /*0x14101a0d4*/
  while ( prefix[v5] != 0 ); /*0x14101a0db*/
  std::string::assign(this: &gaPrefix, _Ptr: prefix, _Count: v5); /*0x14101a0e1*/
  __wind /*0xf1c0000000000070*/
  {
    if ( this->haveReportedEndOfSession ) /*0x14101a0e7*/
    {
      Mysize = gaPrefix._Mypair._Myval2._Mysize; /*0x14101a0f0*/
      if ( gaPrefix._Mypair._Myval2._Myres - gaPrefix._Mypair._Myval2._Mysize < 0x17 ) /*0x14101a102*/
      {
        std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x14101a152*/
          this: &gaPrefix,
          _Size_increase: 0x17u,
          _Fn: 0,
          <_Args_0>: " (After End Of Session)",
          <_Args_1>: 0x17u);
      }
      else
      {
        gaPrefix._Mypair._Myval2._Mysize += 23LL; /*0x14101a108*/
        p_gaPrefix = &gaPrefix; /*0x14101a10c*/
        if ( gaPrefix._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a114*/
          p_gaPrefix = (std::string *)gaPrefix._Mypair._Myval2._Bx._Ptr; /*0x14101a114*/
        v8 = &p_gaPrefix->_Mypair._Myval2._Bx._Buf[Mysize]; /*0x14101a119*/
        memmove_0(a1: v8, Src: " (After End Of Session)", Size: 0x17u); /*0x14101a12c*/
        v8[23] = 0; /*0x14101a131*/
      }
    }
    Ptr = RBX::SystemUtil::osPlatform(&result); /*0x14101a15b*/
    __wind /*0xf1c000000000004c*/
    {
      if ( Ptr->_Mypair._Myval2._Myres >= 0x10 ) /*0x14101a166*/
        Ptr = (std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x14101a168*/
      RBX::format( /*0x14101a17c*/
        result: (RBX::Graphics::ProfilerAdorn::Item *)&metricByVersionForPlatform,
        fmt: "%s_ByVersionForPlatform_%s",
        metric,
        Ptr->_Mypair._Myval2._Bx._Buf);
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c000000000005c*/
    }
    __wind /*0xf1c0000000000064*/
    {
      if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a18a*/
      {
        v10 = result._Mypair._Myval2._Bx._Ptr; /*0x14101a18f*/
        if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101a19d*/
        {
          v10 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14101a1a3*/
          if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v10 - 8) > 0x1F ) /*0x14101a1b2*/
            _invalid_parameter_noinfo_noreturn(); /*0x14101a1b4*/
        }
        operator delete(ptr: v10); /*0x14101a1bb*/
      }
      result._Mypair._Myval2._Mysize = 0; /*0x14101a1c0*/
      result._Mypair._Myval2._Myres = 15; /*0x14101a1c4*/
      result._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101a1cc*/
      RBX::format( /*0x14101a1e5*/
        result: (RBX::Graphics::ProfilerAdorn::Item *)&metricByIpForDataCenterId,
        fmt: "%s_ByIPForDatacenterId_%d",
        metric,
        this->serverDataCenterId);
      __wind /*0xf1c000000000001c*/
      {
        RBX::format( /*0x14101a200*/
          result: (RBX::Graphics::ProfilerAdorn::Item *)&metricByLocationForDataCenterId,
          fmt: "%s_ByLocationForDatacenterId_%d",
          metric,
          this->serverDataCenterId);
        __wind /*0xf1c0000000000010*/
        {
          v11 = &RBX::Analytics::appVersion; /*0x14101a206*/
          v12 = &RBX::Analytics::appVersion; /*0x14101a20d*/
          if ( RBX::Analytics::appVersion._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a218*/
            v12 = (std::string *)RBX::Analytics::appVersion._Mypair._Myval2._Bx._Ptr; /*0x14101a218*/
          p_metricByVersionForPlatform = &metricByVersionForPlatform; /*0x14101a220*/
          if ( metricByVersionForPlatform._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a229*/
            p_metricByVersionForPlatform = (std::string *)metricByVersionForPlatform._Mypair._Myval2._Bx._Ptr; /*0x14101a229*/
          v14 = &gaPrefix; /*0x14101a22e*/
          if ( gaPrefix._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a237*/
            v14 = (std::string *)gaPrefix._Mypair._Myval2._Bx._Ptr; /*0x14101a237*/
          RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x14101a244*/
            category: v14->_Mypair._Myval2._Bx._Buf,
            action: p_metricByVersionForPlatform->_Mypair._Myval2._Bx._Buf,
            label: v12->_Mypair._Myval2._Bx._Buf,
            value: 0,
            sync: false);
          v15 = &RBX::Analytics::location; /*0x14101a249*/
          v16 = &RBX::Analytics::location; /*0x14101a250*/
          if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a25b*/
            v16 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x14101a25b*/
          p_metricByLocationForDataCenterId = &metricByLocationForDataCenterId; /*0x14101a263*/
          if ( metricByLocationForDataCenterId._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a26c*/
            p_metricByLocationForDataCenterId = (std::string *)metricByLocationForDataCenterId._Mypair._Myval2._Bx._Ptr; /*0x14101a26c*/
          v18 = &gaPrefix; /*0x14101a271*/
          if ( gaPrefix._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a27a*/
            v18 = (std::string *)gaPrefix._Mypair._Myval2._Bx._Ptr; /*0x14101a27a*/
          RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x14101a287*/
            category: v18->_Mypair._Myval2._Bx._Buf,
            action: p_metricByLocationForDataCenterId->_Mypair._Myval2._Bx._Buf,
            label: v16->_Mypair._Myval2._Bx._Buf,
            value: 0,
            sync: false);
          if ( FInt::DebugClientNetworkUnthrottledGAForDatacenterId > 0 /*0x14101a2a0*/
            && FInt::DebugClientNetworkUnthrottledGAForDatacenterId == this->serverDataCenterId )
          {
            v19 = gaPrefix._Mypair._Myval2._Mysize; /*0x14101a2a6*/
            if ( gaPrefix._Mypair._Myval2._Myres - gaPrefix._Mypair._Myval2._Mysize < 0xE ) /*0x14101a2b8*/
            {
              std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x14101a308*/
                this: &gaPrefix,
                _Size_increase: 0xEu,
                _Fn: 0,
                <_Args_0>: " [Unthrottled]",
                <_Args_1>: 0xEu);
            }
            else
            {
              gaPrefix._Mypair._Myval2._Mysize += 14LL; /*0x14101a2be*/
              v20 = &gaPrefix; /*0x14101a2c2*/
              if ( gaPrefix._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a2ca*/
                v20 = (std::string *)gaPrefix._Mypair._Myval2._Bx._Ptr; /*0x14101a2ca*/
              v21 = &v20->_Mypair._Myval2._Bx._Buf[v19]; /*0x14101a2cf*/
              memmove_0(a1: v21, Src: " [Unthrottled]", Size: 0xEu); /*0x14101a2e2*/
              v21[14] = 0; /*0x14101a2e7*/
            }
            if ( RBX::Analytics::appVersion._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a315*/
              v11 = (std::string *)RBX::Analytics::appVersion._Mypair._Myval2._Bx._Ptr; /*0x14101a315*/
            v22 = &metricByVersionForPlatform; /*0x14101a31d*/
            if ( metricByVersionForPlatform._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a326*/
              v22 = (std::string *)metricByVersionForPlatform._Mypair._Myval2._Bx._Ptr; /*0x14101a326*/
            v23 = &gaPrefix; /*0x14101a32b*/
            if ( gaPrefix._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a334*/
              v23 = (std::string *)gaPrefix._Mypair._Myval2._Bx._Ptr; /*0x14101a334*/
            RBX::Analytics::Event::DEPRECATED_trackEventWithoutThrottling( /*0x14101a34c*/
              category: v23->_Mypair._Myval2._Bx._Buf,
              action: v22->_Mypair._Myval2._Bx._Buf,
              label: v11->_Mypair._Myval2._Bx._Buf,
              value: 0,
              sync: false,
              engine: 3);
            if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a359*/
              v15 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x14101a359*/
            v24 = &metricByLocationForDataCenterId; /*0x14101a361*/
            if ( metricByLocationForDataCenterId._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a36a*/
              v24 = (std::string *)metricByLocationForDataCenterId._Mypair._Myval2._Bx._Ptr; /*0x14101a36a*/
            v25 = &gaPrefix; /*0x14101a36f*/
            if ( gaPrefix._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a378*/
              v25 = (std::string *)gaPrefix._Mypair._Myval2._Bx._Ptr; /*0x14101a378*/
            RBX::Analytics::Event::DEPRECATED_trackEventWithoutThrottling( /*0x14101a390*/
              category: v25->_Mypair._Myval2._Bx._Buf,
              action: v24->_Mypair._Myval2._Bx._Buf,
              label: v15->_Mypair._Myval2._Bx._Buf,
              value: 0,
              sync: false,
              engine: 3);
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&metricByLocationForDataCenterId); /*0xf1c0000000000008*/
        }
        if ( metricByLocationForDataCenterId._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a39e*/
        {
          v26 = metricByLocationForDataCenterId._Mypair._Myval2._Bx._Ptr; /*0x14101a3a3*/
          if ( metricByLocationForDataCenterId._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101a3b1*/
          {
            v26 = *((char **)metricByLocationForDataCenterId._Mypair._Myval2._Bx._Ptr - 1); /*0x14101a3b7*/
            if ( (unsigned __int64)(metricByLocationForDataCenterId._Mypair._Myval2._Bx._Ptr - v26 - 8) > 0x1F ) /*0x14101a3c6*/
              _invalid_parameter_noinfo_noreturn(); /*0x14101a3c8*/
          }
          operator delete(ptr: v26); /*0x14101a3cf*/
        }
        metricByLocationForDataCenterId._Mypair._Myval2._Mysize = 0; /*0x14101a3d4*/
        metricByLocationForDataCenterId._Mypair._Myval2._Myres = 15; /*0x14101a3d8*/
        metricByLocationForDataCenterId._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101a3e0*/
        if ( metricByIpForDataCenterId._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a3ec*/
        {
          v27 = metricByIpForDataCenterId._Mypair._Myval2._Bx._Ptr; /*0x14101a3f1*/
          if ( metricByIpForDataCenterId._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101a3ff*/
          {
            v27 = *((char **)metricByIpForDataCenterId._Mypair._Myval2._Bx._Ptr - 1); /*0x14101a405*/
            if ( (unsigned __int64)(metricByIpForDataCenterId._Mypair._Myval2._Bx._Ptr - v27 - 8) > 0x1F ) /*0x14101a414*/
              _invalid_parameter_noinfo_noreturn(); /*0x14101a416*/
          }
          operator delete(ptr: v27); /*0x14101a41d*/
        }
        metricByIpForDataCenterId._Mypair._Myval2._Mysize = 0; /*0x14101a422*/
        metricByIpForDataCenterId._Mypair._Myval2._Myres = 15; /*0x14101a426*/
        metricByIpForDataCenterId._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101a42e*/
        if ( metricByVersionForPlatform._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a43a*/
        {
          v28 = metricByVersionForPlatform._Mypair._Myval2._Bx._Ptr; /*0x14101a43f*/
          if ( metricByVersionForPlatform._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101a44d*/
          {
            v28 = *((char **)metricByVersionForPlatform._Mypair._Myval2._Bx._Ptr - 1); /*0x14101a453*/
            if ( (unsigned __int64)(metricByVersionForPlatform._Mypair._Myval2._Bx._Ptr - v28 - 8) > 0x1F ) /*0x14101a462*/
              _invalid_parameter_noinfo_noreturn(); /*0x14101a464*/
          }
          operator delete(ptr: v28); /*0x14101a46b*/
        }
        metricByVersionForPlatform._Mypair._Myval2._Mysize = 0; /*0x14101a470*/
        metricByVersionForPlatform._Mypair._Myval2._Myres = 15; /*0x14101a474*/
        metricByVersionForPlatform._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101a47c*/
        if ( gaPrefix._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a488*/
        {
          v29 = gaPrefix._Mypair._Myval2._Bx._Ptr; /*0x14101a48d*/
          if ( gaPrefix._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101a49b*/
          {
            v29 = *((char **)gaPrefix._Mypair._Myval2._Bx._Ptr - 1); /*0x14101a4a1*/
            if ( (unsigned __int64)(gaPrefix._Mypair._Myval2._Bx._Ptr - v29 - 8) > 0x1F ) /*0x14101a4b0*/
              _invalid_parameter_noinfo_noreturn(); /*0x14101a4b2*/
          }
          operator delete(ptr: v29); /*0x14101a4b9*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&metricByIpForDataCenterId); /*0xf1c000000000002c*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&metricByVersionForPlatform); /*0xf1c0000000000038*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&gaPrefix); /*0xf1c0000000000044*/
  }
}

// Address: 0x14101a5d0 | Name: ?sendExtAntiCheat@Client@Network@RBX@@SAXV?$weak_ptr@VDataModel@RBX@@@std@@AEBV?$vector@EV?$allocator@E@std@@@5@I@Z
void __fastcall RBX::Network::Client::sendExtAntiCheat(
        std::weak_ptr<PluginPermissionsFetcher> *weakDataModel,
        const std::vector<unsigned char> *msg,
        unsigned int sequenceNumber)
{
  std::_Ref_count_base *Rep; // r9
  signed __int32 Uses; // eax
  signed __int32 v7; // ett
  RBX::DataModel *Ptr; // r14
  std::_Ref_count_base *v9; // rsi
  char *v10; // rax
  char *v11; // rbx
  unsigned __int8 *Myfirst; // rcx
  std::_Ref_count_base *v13; // rcx
  std::shared_ptr<RBX::DataModel> datamodel; // [rsp+20h] [rbp-49h] BYREF
  std::vector<unsigned char> _Right; // [rsp+30h] [rbp-39h] BYREF
  unsigned int v16; // [rsp+48h] [rbp-21h]
  std::vector<unsigned char> *p_Right; // [rsp+50h] [rbp-19h]
  std::unique_ptr<webrtc::ComfortNoise> v18; // [rsp+58h] [rbp-11h] BYREF
  std::function<void __cdecl(RBX::DataModel *)> v19; // [rsp+60h] [rbp-9h] BYREF

  datamodel = 0; /*0x14101a5f6*/
  Rep = weakDataModel->_Rep; /*0x14101a5fb*/
  if ( Rep != nullptr && (Uses = Rep->_Uses) != 0 ) /*0x14101a60a*/
  {
    while ( 1 ) /*0x14101a613*/
    {
      v7 = Uses; /*0x14101a613*/
      Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x14101a613*/
      if ( v7 == Uses ) /*0x14101a619*/
        break; /*0x14101a619*/
      if ( Uses == 0 ) /*0x14101a621*/
        goto LABEL_5; /*0x14101a621*/
    }
    Ptr = (RBX::DataModel *)weakDataModel->_Ptr; /*0x14101a6c2*/
    datamodel._Ptr = (RBX::DataModel *)weakDataModel->_Ptr; /*0x14101a6c5*/
    v9 = weakDataModel->_Rep; /*0x14101a6c9*/
    datamodel._Rep = v9; /*0x14101a6cd*/
  }
  else
  {
LABEL_5:
    Ptr = datamodel._Ptr; /*0x14101a623*/
    v9 = datamodel._Rep; /*0x14101a627*/
  }
  __eh34_enter_wind_state(-1, 0); /*0xf1c000000000008c*/
  __eh34_enter_wind_state(0, 1); /*0xf1c0000000000090*/
  if ( Ptr != nullptr ) /*0x14101a62e*/
  {
    std::vector<unsigned char>::vector<unsigned char>(this: &_Right, _Right: msg); /*0x14101a640*/
    __wind /*0xf1c0000000000078*/
    {
      __wind /*0xf1c0000000000080*/
      {
        v16 = sequenceNumber; /*0x14101a645*/
        p_Right = &_Right; /*0x14101a64c*/
        v19._Mystorage._Ptrs[7] = nullptr; /*0x14101a650*/
        v10 = (char *)operator new(size: 0x28u); /*0x14101a65d*/
        __wind /*0xf1c0000000000004*/
        {
          v11 = v10; /*0x14101a662*/
          v18._Mypair._Myval2 = (webrtc::ComfortNoise *)v10; /*0x14101a665*/
          *(_QWORD *)v10 = std::_Func_impl_no_alloc__lambda_296d3da0b53b7165d85aadcb1642c9d5__void_RBX::DataModel___::_vftable_; /*0x14101a670*/
          std::vector<unsigned char>::vector<unsigned char>(this: (std::vector<unsigned char> *)(v10 + 8), &_Right); /*0x14101a67b*/
        }
        __unwind
        {
          `std::_Global_new<std::_Func_impl_no_alloc<_lambda_f8c4b7e6150b88b311f5039a2ec2dc7b_,void,>,_lambda_f8c4b7e6150b88b311f5039a2ec2dc7b_ const &>'::`2'::_Guard_type::~_Guard_type(this: &v18); /*0xf1c0000000000014*/
        }
      }
      __unwind
      {
        std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&v19); /*0xf1c0000000000020*/
      }
    }
    __unwind
    {
      lambda_296d3da0b53b7165d85aadcb1642c9d5_::__lambda_296d3da0b53b7165d85aadcb1642c9d5_(a1: p_Right); /*0xf1c000000000002c*/
    }
    if ( __eh34_unwind(1) ) /*0xf1c0000000000034*/
    {
unwind_state_1:
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&datamodel); /*0xf1c0000000000038*/
      __eh34_continue_unwinding(1, 0); /*0xf1c000000000003c*/
    }
    __eh34_exit_wind_state(1, 0); /*0xf1c0000000000040*/
    if ( __eh34_unwind(0) ) /*0xf1c0000000000044*/
    {
unwind_state_0:
      std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: weakDataModel); /*0xf1c0000000000048*/
      __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000004c*/
    }
    __eh34_exit_wind_state(0, -1); /*0xf1c0000000000050*/
    *((_DWORD *)v11 + 8) = v16; /*0x14101a683*/
    v19._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::DataModel *> *)v11; /*0x14101a686*/
    Myfirst = _Right._Mypair._Myval2._Myfirst; /*0x14101a68a*/
    if ( _Right._Mypair._Myval2._Myfirst != nullptr ) /*0x14101a691*/
    {
      if ( (unsigned __int8 *)(_Right._Mypair._Myval2._Myend - _Right._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x14101a6a4*/
      {
        Myfirst = *((unsigned __int8 **)_Right._Mypair._Myval2._Myfirst - 1); /*0x14101a6aa*/
        if ( (unsigned __int64)(_Right._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x14101a6b9*/
          _invalid_parameter_noinfo_noreturn(); /*0x14101a6bb*/
      }
      operator delete(ptr: Myfirst); /*0x14101a6d6*/
      memset(&_Right, 0, sizeof(_Right)); /*0x14101a6de*/
    }
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000006c*/
    __eh34_enter_wind_state(0, 1); /*0xf1c0000000000070*/
    RBX::DataModel::submitTask(this: Ptr, task: &v19, taskType: (RBX::DMTaskType)1); /*0x14101a6f8*/
  }
  if ( v9 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v9->_Uses, 0xFFFFFFFF) == 1 ) /*0x14101a712*/
  {
    datamodel._Rep->_Destroy(this: datamodel._Rep); /*0x14101a71e*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&datamodel._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101a72a*/
      datamodel._Rep->_Delete_this(this: datamodel._Rep); /*0x14101a733*/
  }
  v13 = weakDataModel->_Rep; /*0x14101a737*/
  if ( v13 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v13->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101a748*/
    v13->_Delete_this(this: v13); /*0x14101a74d*/
  if ( __eh34_unwind(1) ) /*0xf1c0000000000058*/
    goto unwind_state_1; /*0xf1c0000000000058*/
  __eh34_exit_wind_state(1, 0); /*0xf1c000000000005c*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000060*/
    goto unwind_state_0; /*0xf1c0000000000060*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000064*/
}

// Address: 0x14101a770 | Name: ?sendPreferedSpawnName@Client@Network@RBX@@AEBAXXZ
void __fastcall RBX::Network::Client::sendPreferedSpawnName(RBX::Network::Client *this)
{
  int v2; // ebx
  const std::string *SpawnName; // rax
  std::string *Ptr; // rax
  char *v5; // rcx
  Luau::InternalErrorReporter *v6; // rdi
  std::_Func_base<void,char const *>_vtbl *v7; // rbx
  unsigned __int8 *Myfirst; // rcx
  std::string result; // [rsp+40h] [rbp-78h] BYREF
  RBX::Network::NetworkStream bitStream; // [rsp+70h] [rbp-48h] BYREF
  char inByteArray; // [rsp+C8h] [rbp+10h] BYREF

  RBX::Network::NetworkStream::NetworkStream(this: &bitStream); /*0x14101a78a*/
  inByteArray = -113; /*0x14101a790*/
  __wind
  {
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14101a7ab*/
    v2 = DFInt::CliMaxPayloadSnd; /*0x14101a7b0*/
    SpawnName = RBX::TeleportService::GetSpawnName(); /*0x14101a7b6*/
    RBX::Network::serializeString(value: SpawnName, stream: &bitStream, maxStringWriteSize: v2); /*0x14101a7c6*/
    if ( FLog::Network != 0 )
    {
      Ptr = RBX::Network::RakNetAddressToString( /*0x14101a7e6*/
              &result,
              raknetAddress: &this->serverId,
              writePort: true,
              portDelineator: 124);
      __wind
      {
        if ( Ptr->_Mypair._Myval2._Myres >= 0x10 ) /*0x14101a7f1*/
          Ptr = (std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x14101a7f3*/
        FLog::FastLogS(
          level: FLog::Network,
          message: "[FLog::Network] serverId: %s",
          sarg: Ptr->_Mypair._Myval2._Bx._Buf);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000014*/
      }
      if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14101a816*/
      {
        v5 = result._Mypair._Myval2._Bx._Ptr; /*0x14101a81b*/
        if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101a82a*/
        {
          v5 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14101a830*/
          if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v5 - 8) > 0x1F ) /*0x14101a83f*/
            _invalid_parameter_noinfo_noreturn(); /*0x14101a841*/
        }
        operator delete(ptr: v5); /*0x14101a848*/
      }
    }
    v6 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14101a859*/
    v7 = v6->onInternalError._Mystorage._Ptrs[0][20].__vftable; /*0x14101a85f*/
    RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)&result); /*0x14101a86b*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)&result._Mypair._Myval2._Mysize); /*0x14101a875*/
    result._Mypair._Myval2._Bx._Ptr = (char *)RakNet::UNASSIGNED_RAKNET_GUID_14.g; /*0x14101a881*/
    *(_WORD *)&result._Mypair._Myval2._Bx._Alias[8] = RakNet::UNASSIGNED_RAKNET_GUID_14.systemIndex; /*0x14101a88d*/
    RakNet::SystemAddress::operator=( /*0x14101a89e*/
      this: (RakNet::SystemAddress *)&result._Mypair._Myval2._Mysize,
      input: &this->serverId);
    ((void (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::NetworkStream *, __int64))v7)( /*0x14101a8d1*/
      a1: v6,
      a2: &bitStream,
      a3: 2);
  }
  __unwind
  {
    RBX::Network::NetworkStream::~NetworkStream(this: &bitStream); /*0xf1c0000000000008*/
  }
  Myfirst = bitStream.dataVector._Mypair._Myval2._Myfirst; /*0x14101a8d4*/
  if ( bitStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x14101a8df*/
  {
    if ( (unsigned __int8 *)(bitStream.dataVector._Mypair._Myval2._Myend - bitStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x14101a8f6*/
    {
      Myfirst = *((unsigned __int8 **)bitStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x14101a8fc*/
      if ( (unsigned __int64)(bitStream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x14101a90b*/
        _invalid_parameter_noinfo_noreturn(); /*0x14101a90d*/
    }
    operator delete(ptr: Myfirst); /*0x14101a914*/
  }
}

// Address: 0x14101a930 | Name: ?sendTicket@Client@Network@RBX@@AEAAXXZ
void __fastcall RBX::Network::Client::sendTicket(RBX::Network::Client *this)
{
  const std::shared_ptr<RBX::GlobalBasicSettings> *v2; // rax
  std::_Ref_count_base *Rep; // rsi
  RBX::GlobalBasicSettings *Ptr; // rbx
  unsigned __int8 v5; // r8
  int v6; // ebx
  const std::string *v7; // rax
  char *v8; // rcx
  char *v9; // rcx
  std::string *p_gameSessionID; // rcx
  int v11; // r8d
  RBX::DataModel *v12; // rax
  unsigned __int64 Mysize; // rcx
  std::string *v14; // rax
  unsigned __int64 v15; // rdi
  std::string *p_hashKey; // rbx
  char *v17; // rbx
  std::string *v18; // r8
  Luau::InternalErrorReporter *v19; // rdi
  std::_Func_base<void,char const *>_vtbl *v20; // rbx
  char *v21; // rcx
  char *v22; // rcx
  unsigned __int8 *Myfirst; // rcx
  std::string hashKey; // [rsp+40h] [rbp-C0h] BYREF
  unsigned __int8 v25[8]; // [rsp+60h] [rbp-A0h] BYREF
  unsigned __int8 v26[8]; // [rsp+68h] [rbp-98h] BYREF
  std::string value; // [rsp+70h] [rbp-90h] BYREF
  RBX::Network::NetworkStream bitStream; // [rsp+90h] [rbp-70h] BYREF
  std::string encodedKey; // [rsp+D0h] [rbp-30h] BYREF
  std::shared_ptr<RBX::GlobalBasicSettings> basicSettings; // [rsp+F0h] [rbp-10h] BYREF
  RakNet::RakNetGUID v31; // [rsp+100h] [rbp+0h] BYREF
  RakNet::SystemAddress v32; // [rsp+110h] [rbp+10h] BYREF
  std::string result; // [rsp+130h] [rbp+30h] BYREF
  std::basic_stringstream<char,std::char_traits<char>,std::allocator<char> > encodedGuid; // [rsp+150h] [rbp+50h] BYREF
  char inByteArray; // [rsp+290h] [rbp+190h] BYREF
  int protocolVersion; // [rsp+298h] [rbp+198h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+2A0h] [rbp+1A0h] BYREF
  int v38; // [rsp+2A8h] [rbp+1A8h]

  v38 = 0; /*0x14101a950*/
  RBX::Network::NetworkStream::NetworkStream(this: &bitStream); /*0x14101a95b*/
  inByteArray = -118; /*0x14101a961*/
  __wind /*0xf1c00000000000e8*/
  {
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14101a977*/
    RBX::Network::serializeSignedVarint64(value: this->userId, stream: &bitStream); /*0x14101a987*/
    RBX::Network::serializeString(value: &this->ticket, stream: &bitStream, maxStringWriteSize: DFInt::CliMaxPayloadSnd); /*0x14101a99e*/
    RBX::Network::serializeString( /*0x14101a9b5*/
      value: &RBX::DataModel::hash,
      stream: &bitStream,
      maxStringWriteSize: DFInt::CliMaxPayloadSnd);
    protocolVersion = this->protocolVersion; /*0x14101a9c1*/
    RBX::Network::NetworkStream::ReverseBytes( /*0x14101a9d9*/
      inByteArray: (unsigned __int8 *)&protocolVersion,
      &inOutByteArray,
      length: 4u);
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x14101a9ed*/
    v2 = RBX::GlobalBasicSettings::singleton(); /*0x14101a9f2*/
    Rep = v2->_Rep; /*0x14101a9f7*/
    if ( Rep != nullptr ) /*0x14101a9fe*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x14101aa00*/
      Rep = v2->_Rep; /*0x14101aa04*/
    }
    Ptr = v2->_Ptr; /*0x14101aa08*/
    basicSettings._Ptr = v2->_Ptr; /*0x14101aa0b*/
    basicSettings._Rep = Rep; /*0x14101aa0f*/
    __wind /*0xf1c00000000000dc*/
    {
      *(_QWORD *)encodedGuid.gap0 = &std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vftable'[1]; /*0x14101aa1a*/
      *(_QWORD *)encodedGuid.gap10 = &std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vbtable'{for `std::ostream'}; /*0x14101aa25*/
      std::ios::ios(a1: &encodedGuid.gap90[8]); /*0x14101aa30*/
      __wind /*0xf1c00000000000d0*/
      {
        v38 = 1; /*0x14101aa37*/
        std::iostream::iostream(a1: &encodedGuid, a2: &encodedGuid.gap10[8], a3: 0); /*0x14101aa4c*/
        __wind /*0xf1c00000000000a0*/
        {
          *(_QWORD *)&encodedGuid.gap0[*(int *)(*(_QWORD *)encodedGuid.gap0 + 4LL)] = std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vftable'; /*0x14101aa62*/
          *(_DWORD *)((char *)&result._Mypair._Myval2._Myres + *(int *)(*(_QWORD *)encodedGuid.gap0 + 4LL) + 4) = *(_DWORD *)(*(_QWORD *)encodedGuid.gap0 + 4LL) - 152; /*0x14101aa75*/
          std::streambuf::streambuf(a1: &encodedGuid.gap10[8]); /*0x14101aa7d*/
          *(_QWORD *)&encodedGuid.gap10[8] = std::stringbuf::`vftable'; /*0x14101aa8a*/
          *(_QWORD *)encodedGuid._Stringbuffer = 0; /*0x14101aa8e*/
          *(_DWORD *)&encodedGuid._Stringbuffer[8] = 0; /*0x14101aa95*/
        }
        __unwind
        {
          std::iostream::~iostream<char,std::char_traits<char>>(a1: &encodedGuid.gap10[16]); /*0x14316c77b*/
        }
      }
      __unwind
      {
        if ( (v38 & 1) != 0 ) /*0x1431e5b84*/
        {
          v38 &= ~1u; /*0x1431e5b86*/
          std::ios::~ios<char,std::char_traits<char>>(a1: &encodedGuid.gap90[8]); /*0x1431e5b9b*/
        }
      }
      __wind /*0xf1c00000000000c4*/
      {
        if ( !DFFlag::CLI120342.value || (v5 = 47, Ptr->referent._Mypair._Myval2._Mysize < 0x23) ) /*0x14101aab0*/
          v5 = 46; /*0x14101aab2*/
        RBX::Security::encodeVersionKey(result: &encodedKey, legacyKey: &RBX::Network::securityKey, ticketVersion: v5); /*0x14101aac0*/
        __wind /*0xf1c0000000000064*/
        {
          RBX::Network::serializeString( /*0x14101aad5*/
            value: &encodedKey,
            stream: &bitStream,
            maxStringWriteSize: DFInt::CliMaxPayloadSnd);
          v6 = DFInt::CliMaxPayloadSnd; /*0x14101aada*/
          v7 = RBX::SystemUtil::osPlatform(&result); /*0x14101aae4*/
          __wind /*0xf1c0000000000058*/
          {
            RBX::Network::serializeString(value: v7, stream: &bitStream, maxStringWriteSize: v6); /*0x14101aaf4*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000050*/
          }
          if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14101ab02*/
          {
            v8 = result._Mypair._Myval2._Bx._Ptr; /*0x14101ab07*/
            if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101ab15*/
            {
              v8 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14101ab1b*/
              if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v8 - 8) > 0x1F ) /*0x14101ab2a*/
                _invalid_parameter_noinfo_noreturn(); /*0x14101ab2c*/
            }
            operator delete(ptr: v8); /*0x14101ab33*/
          }
          value._Mypair._Myval2._Bx._Ptr = (char *)63; /*0x14101ab38*/
          value._Mypair._Myval2._Myres = 15; /*0x14101ab3d*/
          value._Mypair._Myval2._Mysize = 1; /*0x14101ab45*/
          __wind /*0xf1c0000000000040*/
          {
            RBX::Network::serializeString(&value, stream: &bitStream, maxStringWriteSize: DFInt::CliMaxPayloadSnd); /*0x14101ab64*/
            if ( value._Mypair._Myval2._Myres >= 0x10 ) /*0x14101ab72*/
            {
              v9 = value._Mypair._Myval2._Bx._Ptr; /*0x14101ab77*/
              if ( value._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101ab86*/
              {
                v9 = *((char **)value._Mypair._Myval2._Bx._Ptr - 1); /*0x14101ab8c*/
                if ( (unsigned __int64)(value._Mypair._Myval2._Bx._Ptr - v9 - 8) > 0x1F ) /*0x14101ab9b*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14101ab9d*/
              }
              operator delete(ptr: v9); /*0x14101aba4*/
            }
            p_gameSessionID = &this->gameSessionID; /*0x14101aba9*/
            v11 = DFInt::CliMaxPayloadSnd; /*0x14101abb0*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&value); /*0xf1c0000000000038*/
          }
          RBX::Network::serializeString(value: p_gameSessionID, stream: &bitStream, maxStringWriteSize: v11); /*0x14101abbb*/
          *(_DWORD *)v25 = (unsigned int)GetModuleHandleA(lpModuleName: nullptr); /*0x14101abc8*/
          RBX::Network::NetworkStream::ReverseBytes(inByteArray: v25, inOutByteArray: v26, length: 4u); /*0x14101abdc*/
          RBX::Network::NetworkStream::writeBytes(this: &bitStream, inByteArray: v26, numberOfBytesToWrite: 4u); /*0x14101abf0*/
          v12 = RBX::DataModel::get(context: this); /*0x14101abf8*/
          RBX::format( /*0x14101ac31*/
            result: (RBX::Graphics::ProfilerAdorn::Item *)&hashKey,
            fmt: "%d%d%d%d",
            v12->placeID.storage._Mypair._Myval2->storage.asRaw[0]
          - (unsigned __int64)v12->placeID.storage._Mypair._Myval2,
            278316012,
            833983291,
            1930942843);
          __wind /*0xf1c0000000000028*/
          {
            Mysize = hashKey._Mypair._Myval2._Mysize; /*0x14101ac37*/
            if ( hashKey._Mypair._Myval2._Mysize < 0x10 ) /*0x14101ac40*/
            {
              v15 = 16 - hashKey._Mypair._Myval2._Mysize; /*0x14101ac67*/
              if ( 16 - hashKey._Mypair._Myval2._Mysize > hashKey._Mypair._Myval2._Myres /*0x14101ac78*/
                                                        - hashKey._Mypair._Myval2._Mysize )
              {
                std::string::_Reallocate_grow_by<_lambda_e1befb086ad3257e3f042a63030725f7_,unsigned __int64,char>( /*0x14101acbb*/
                  this: &hashKey,
                  _Size_increase: 16 - hashKey._Mypair._Myval2._Mysize,
                  _Fn: 0,
                  <_Args_0>: 16 - hashKey._Mypair._Myval2._Mysize,
                  <_Args_1>: 0);
              }
              else
              {
                hashKey._Mypair._Myval2._Mysize = 16; /*0x14101ac7a*/
                p_hashKey = &hashKey; /*0x14101ac83*/
                if ( hashKey._Mypair._Myval2._Myres >= 0x10 ) /*0x14101ac8c*/
                  p_hashKey = (std::string *)hashKey._Mypair._Myval2._Bx._Ptr; /*0x14101ac8c*/
                v17 = &p_hashKey->_Mypair._Myval2._Bx._Buf[Mysize]; /*0x14101ac92*/
                memset_0(a1: v17, Val: 0, Size: 16 - Mysize); /*0x14101ac9d*/
                v17[v15] = 0; /*0x14101aca2*/
              }
            }
            else
            {
              v14 = &hashKey; /*0x14101ac42*/
              if ( hashKey._Mypair._Myval2._Myres >= 0x10 ) /*0x14101ac4d*/
                v14 = (std::string *)hashKey._Mypair._Myval2._Bx._Ptr; /*0x14101ac4d*/
              hashKey._Mypair._Myval2._Mysize = 16; /*0x14101ac53*/
              LOBYTE(v14->_Mypair._Myval2._Mysize) = 0; /*0x14101ac5c*/
            }
            v18 = &hashKey; /*0x14101acc0*/
            if ( hashKey._Mypair._Myval2._Myres >= 0x10 ) /*0x14101accb*/
              v18 = (std::string *)hashKey._Mypair._Myval2._Bx._Ptr; /*0x14101accb*/
            RBX::Network::Peer::encryptDataPartWithKey(this, &bitStream, key: (const unsigned __int8 *)v18); /*0x14101acd8*/
            v19 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14101ace9*/
            v20 = v19->onInternalError._Mystorage._Ptrs[0][20].__vftable; /*0x14101acef*/
            RakNet::RakNetGUID::RakNetGUID(this: &v31); /*0x14101acfa*/
            RakNet::SystemAddress::SystemAddress(this: &v32); /*0x14101ad03*/
            v31 = RakNet::UNASSIGNED_RAKNET_GUID_14; /*0x14101ad0f*/
            RakNet::SystemAddress::operator=(this: &v32, input: &this->serverId); /*0x14101ad29*/
            ((void (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::NetworkStream *, __int64))v20)( /*0x14101ad57*/
              a1: v19,
              a2: &bitStream,
              a3: 2);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&hashKey); /*0xf1c0000000000020*/
          }
          if ( hashKey._Mypair._Myval2._Myres >= 0x10 ) /*0x14101ad63*/
          {
            v21 = hashKey._Mypair._Myval2._Bx._Ptr; /*0x14101ad68*/
            if ( hashKey._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101ad77*/
            {
              v21 = *((char **)hashKey._Mypair._Myval2._Bx._Ptr - 1); /*0x14101ad7d*/
              if ( (unsigned __int64)(hashKey._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x14101ad8c*/
                _invalid_parameter_noinfo_noreturn(); /*0x14101ad8e*/
            }
            operator delete(ptr: v21); /*0x14101ad95*/
          }
          hashKey._Mypair._Myval2._Mysize = 0; /*0x14101ad9a*/
          hashKey._Mypair._Myval2._Myres = 15; /*0x14101ad9f*/
          hashKey._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101ada8*/
          if ( encodedKey._Mypair._Myval2._Myres >= 0x10 ) /*0x14101adb5*/
          {
            v22 = encodedKey._Mypair._Myval2._Bx._Ptr; /*0x14101adba*/
            if ( encodedKey._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101adc8*/
            {
              v22 = *((char **)encodedKey._Mypair._Myval2._Bx._Ptr - 1); /*0x14101adce*/
              if ( (unsigned __int64)(encodedKey._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x14101addd*/
                _invalid_parameter_noinfo_noreturn(); /*0x14101addf*/
            }
            operator delete(ptr: v22); /*0x14101ade6*/
          }
          encodedKey._Mypair._Myval2._Mysize = 0; /*0x14101adeb*/
          encodedKey._Mypair._Myval2._Myres = 15; /*0x14101adef*/
          encodedKey._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101adf7*/
          *(_QWORD *)&encodedGuid.gap0[*(int *)(*(_QWORD *)encodedGuid.gap0 + 4LL)] = std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vftable'; /*0x14101ae03*/
          *(_DWORD *)((char *)&result._Mypair._Myval2._Myres + *(int *)(*(_QWORD *)encodedGuid.gap0 + 4LL) + 4) = *(_DWORD *)(*(_QWORD *)encodedGuid.gap0 + 4LL) - 152; /*0x14101ae16*/
          std::stringbuf::~stringbuf(this: (std::stringbuf *)&encodedGuid.gap10[8]); /*0x14101ae1e*/
          std::iostream::~iostream<char,std::char_traits<char>>(a1: &encodedGuid.gap10[16]); /*0x14101ae27*/
          std::ios::~ios<char,std::char_traits<char>>(a1: &encodedGuid.gap90[8]); /*0x14101ae34*/
          if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14101ae4f*/
          {
            Rep->_Destroy(this: Rep); /*0x14101ae57*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101ae61*/
              Rep->_Delete_this(this: Rep); /*0x14101ae69*/
          }
          Myfirst = bitStream.dataVector._Mypair._Myval2._Myfirst; /*0x14101ae6d*/
          if ( bitStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x14101ae74*/
          {
            if ( (unsigned __int8 *)(bitStream.dataVector._Mypair._Myval2._Myend /*0x14101ae87*/
                                   - bitStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 )
            {
              Myfirst = *((unsigned __int8 **)bitStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x14101ae8d*/
              if ( (unsigned __int64)(bitStream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x14101ae9c*/
                _invalid_parameter_noinfo_noreturn(); /*0x14101ae9e*/
            }
            operator delete(ptr: Myfirst); /*0x14101aea5*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&encodedKey); /*0xf1c0000000000074*/
        }
      }
      __unwind
      {
        std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vbase destructor'(this: &encodedGuid); /*0xf1c0000000000080*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&basicSettings); /*0xf1c000000000008c*/
    }
  }
  __unwind
  {
    RBX::Network::NetworkStream::~NetworkStream(this: &bitStream); /*0xf1c0000000000098*/
  }
}

// Address: 0x14101aec0 | Name: ?sendVersionInfo@Client@Network@RBX@@AEAAXXZ
void __fastcall RBX::Network::Client::sendVersionInfo(RBX::Network::Client *this)
{
  Luau::InternalErrorReporter *v2; // rax
  std::_Func_base<void,char const *>_vtbl *v3; // r9
  RakNet::SystemAddress *p_serverId; // rsi
  Luau::InternalErrorReporter *v5; // rax
  std::_Func_base<void,char const *>_vtbl *v6; // r9
  Luau::InternalErrorReporter *v7; // rdi
  std::_Func_base<void,char const *>_vtbl *v8; // rbx
  unsigned __int8 *Myfirst; // rcx
  RakNet::RakNetGUID v10; // [rsp+40h] [rbp-29h] BYREF
  RakNet::SystemAddress v11; // [rsp+50h] [rbp-19h] BYREF
  RBX::Network::NetworkStream bitStream; // [rsp+70h] [rbp+7h] BYREF
  int inByteArray; // [rsp+D0h] [rbp+67h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+D8h] [rbp+6Fh] BYREF

  RBX::Network::NetworkStream::NetworkStream(this: &bitStream); /*0x14101aedb*/
  LOBYTE(inByteArray) = -112; /*0x14101aee1*/
  __wind /*0xf1c0000000000010*/
  {
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14101aef3*/
    LOBYTE(inByteArray) = 1; /*0x14101aef8*/
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14101af0a*/
    inByteArray = this->protocolVersion; /*0x14101af15*/
    RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x14101af26*/
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x14101af39*/
    v2 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14101af45*/
    v3 = v2->onInternalError._Mystorage._Ptrs[0][83].__vftable; /*0x14101af4d*/
    p_serverId = &this->serverId; /*0x14101af54*/
    v10 = *(RakNet::RakNetGUID *)&this->serverId.address.addr6.sin6_family; /*0x14101af5e*/
    *(_OWORD *)&v11.address.addr6.sin6_family = *((_OWORD *)&this->serverId.address.addr4 + 1); /*0x14101af66*/
    if ( ((unsigned __int8 (__fastcall *)(Luau::InternalErrorReporter *, RakNet::RakNetGUID *, __int64))v3)( /*0x14101af7c*/
           a1: v2,
           a2: &v10,
           a3: 0x100000) != 0 )
    {
      LOBYTE(inByteArray) = 3; /*0x14101af7e*/
      RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14101af90*/
    }
    else
    {
      v5 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14101af9e*/
      v6 = v5->onInternalError._Mystorage._Ptrs[0][83].__vftable; /*0x14101afa6*/
      v10 = *(RakNet::RakNetGUID *)&p_serverId->address.addr6.sin6_family; /*0x14101afb0*/
      *(_OWORD *)&v11.address.addr6.sin6_family = *((_OWORD *)&this->serverId.address.addr4 + 1); /*0x14101afb8*/
      if ( ((unsigned __int8 (__fastcall *)(Luau::InternalErrorReporter *, RakNet::RakNetGUID *, __int64))v6)( /*0x14101afce*/
             a1: v5,
             a2: &v10,
             a3: 2048) == 0 )
      {
LABEL_6:
        LOWORD(inByteArray) = FLog::GetNumSynchronizedVariable(); /*0x14101afe7*/
        RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 2u); /*0x14101affe*/
        RBX::Network::NetworkStream::writeBytes( /*0x14101b011*/
          this: &bitStream,
          inByteArray: &inOutByteArray,
          numberOfBytesToWrite: 2u);
        FLog::ForEachVariable(visitor: clientSFFlagVisitor, context: (void *)&bitStream, flagType: FASTVARTYPE_SYNC); /*0x14101b027*/
        RBX::Network::serializeString( /*0x14101b03e*/
          value: &this->playerInfoJson,
          stream: &bitStream,
          maxStringWriteSize: DFInt::CliMaxPayloadSnd);
        inByteArray = 278316012; /*0x14101b049*/
        RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x14101b05a*/
        RBX::Network::NetworkStream::writeBytes( /*0x14101b06d*/
          this: &bitStream,
          inByteArray: &inOutByteArray,
          numberOfBytesToWrite: 4u);
        inByteArray = 1930942843; /*0x14101b0ac*/
        RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x14101b0bd*/
        RBX::Network::NetworkStream::writeBytes( /*0x14101b0d0*/
          this: &bitStream,
          inByteArray: &inOutByteArray,
          numberOfBytesToWrite: 4u);
        inByteArray = 833983291; /*0x14101b10f*/
        RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x14101b120*/
        RBX::Network::NetworkStream::writeBytes( /*0x14101b133*/
          this: &bitStream,
          inByteArray: &inOutByteArray,
          numberOfBytesToWrite: 4u);
        inByteArray = -1588031631; /*0x14101b172*/
        RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x14101b183*/
        RBX::Network::NetworkStream::writeBytes( /*0x14101b196*/
          this: &bitStream,
          inByteArray: &inOutByteArray,
          numberOfBytesToWrite: 4u);
        inByteArray = 886203999; /*0x14101b1d7*/
        RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x14101b1e8*/
        RBX::Network::NetworkStream::writeBytes( /*0x14101b1fb*/
          this: &bitStream,
          inByteArray: &inOutByteArray,
          numberOfBytesToWrite: 4u);
        RBX::Network::Peer::encryptDataPart(this, &bitStream); /*0x14101b207*/
        v7 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14101b218*/
        v8 = v7->onInternalError._Mystorage._Ptrs[0][20].__vftable; /*0x14101b21e*/
        RakNet::RakNetGUID::RakNetGUID(this: &v10); /*0x14101b229*/
        RakNet::SystemAddress::SystemAddress(this: &v11); /*0x14101b232*/
        v10 = RakNet::UNASSIGNED_RAKNET_GUID_14; /*0x14101b23e*/
        RakNet::SystemAddress::operator=(this: &v11, input: p_serverId); /*0x14101b254*/
        ((void (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::NetworkStream *, __int64))v8)( /*0x14101b285*/
          a1: v7,
          a2: &bitStream,
          a3: 2);
        goto LABEL_13; /*0xf1c000000000001c*/
      }
    }
    LOBYTE(inByteArray) = 3; /*0x14101afd0*/
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14101afe2*/
    goto LABEL_6; /*0x14101afe2*/
  }
  __unwind
  {
    RBX::Network::NetworkStream::~NetworkStream(this: &bitStream); /*0xf1c0000000000008*/
  }
LABEL_13:
  Myfirst = bitStream.dataVector._Mypair._Myval2._Myfirst; /*0x14101b288*/
  if ( bitStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x14101b28f*/
  {
    if ( (unsigned __int8 *)(bitStream.dataVector._Mypair._Myval2._Myend - bitStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x14101b2a2*/
    {
      Myfirst = *((unsigned __int8 **)bitStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x14101b2a8*/
      if ( (unsigned __int64)(bitStream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x14101b2b7*/
        _invalid_parameter_noinfo_noreturn(); /*0x14101b2b9*/
    }
    operator delete(ptr: Myfirst); /*0x14101b2c0*/
  }
}

// Address: 0x14101b2e0 | Name: ?setArtificialLatencyDmWriteLock@Client@Network@RBX@@AEAAXV?$weak_ptr@VDataModel@RBX@@@std@@_K1@Z
void __fastcall RBX::Network::Client::setArtificialLatencyDmWriteLock(
        RBX::Network::Client *this,
        std::weak_ptr<PluginPermissionsFetcher> *weakDm,
        unsigned __int64 txLatency,
        unsigned __int64 rxLatency)
{
  std::_Ref_count_base *Rep; // r10
  signed __int32 Uses; // eax
  signed __int32 v7; // ett
  RBX::DataModel *Ptr; // rcx
  std::_Ref_count_base *v9; // rbx
  std::_Ref_count_base *v10; // rcx
  std::shared_ptr<RBX::DataModel> dm; // [rsp+28h] [rbp-70h] BYREF
  __int128 v12; // [rsp+40h] [rbp-58h]
  std::function<void __cdecl(RBX::DataModel *)> v13; // [rsp+50h] [rbp-48h] BYREF

  __wind /*0xf1c000000000001c*/
  {
    __wind /*0xf1c0000000000024*/
    {
      dm = 0; /*0x14101b2fd*/
      Rep = weakDm->_Rep; /*0x14101b303*/
      if ( Rep != nullptr && (Uses = Rep->_Uses) != 0 ) /*0x14101b312*/
      {
        while ( 1 ) /*0x14101b323*/
        {
          v7 = Uses; /*0x14101b323*/
          Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x14101b323*/
          if ( v7 == Uses ) /*0x14101b329*/
            break; /*0x14101b329*/
          if ( Uses == 0 ) /*0x14101b331*/
            goto LABEL_6; /*0x14101b331*/
        }
        Ptr = (RBX::DataModel *)weakDm->_Ptr; /*0x14101b3e9*/
        dm._Ptr = (RBX::DataModel *)weakDm->_Ptr; /*0x14101b3ec*/
        v9 = weakDm->_Rep; /*0x14101b3f1*/
        dm._Rep = v9; /*0x14101b3f5*/
      }
      else
      {
LABEL_6:
        Ptr = dm._Ptr; /*0x14101b333*/
        v9 = dm._Rep; /*0x14101b338*/
      }
      if ( Ptr != nullptr ) /*0x14101b340*/
      {
        *(_QWORD *)&v12 = txLatency; /*0x14101b342*/
        *((_QWORD *)&v12 + 1) = rxLatency; /*0x14101b347*/
        v13._Mystorage._Ptrs[0] = (std::_Func_base<void,RBX::DataModel *> *)std::_Func_impl_no_alloc__lambda_b9e12f1dd7d6009c968b8c9ef80bdb3e__void_RBX::DataModel___::_vftable_; /*0x14101b353*/
        *(_OWORD *)&v13._Mystorage._Ptrs[1] = v12; /*0x14101b35d*/
        v13._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::DataModel *> *)&v13; /*0x14101b367*/
        RBX::DataModel::submitTask(this: Ptr, task: &v13, taskType: (RBX::DMTaskType)1); /*0x14101b37a*/
      }
      if ( v9 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v9->_Uses, 0xFFFFFFFF) == 1 ) /*0x14101b394*/
      {
        dm._Rep->_Destroy(this: dm._Rep); /*0x14101b3a1*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&dm._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101b3ad*/
          dm._Rep->_Delete_this(this: dm._Rep); /*0x14101b3b7*/
      }
      v10 = weakDm->_Rep; /*0x14101b3bb*/
      if ( v10 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101b3cc*/
        v10->_Delete_this(this: v10); /*0x14101b3d1*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&dm); /*0xf1c0000000000008*/
    }
  }
  __unwind
  {
    std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: weakDm); /*0xf1c0000000000014*/
  }
}

// Address: 0x14101b400 | Name: ?setArtificialLatencyFromCache@Client@Network@RBX@@AEAAXV?$weak_ptr@VDataModel@RBX@@@std@@_J@Z
void __fastcall RBX::Network::Client::setArtificialLatencyFromCache(
        RBX::Network::Client *this,
        std::weak_ptr<PluginPermissionsFetcher> *weakDm,
        __int64 userId)
{
  char v5; // si
  RBX::Network::Client::LatencyExperimentCache *p_latencyExperimentCache; // rcx
  _Mtx_internal_imp_t *p_setLatencyMx; // rbx
  int v8; // eax
  std::_Ref_count_base *Rep; // rcx
  int httpPopDcLatencyMs; // r13d
  unsigned __int64 receiveLatencyUS; // r15
  unsigned __int64 transmitLatencyUS; // r14
  std::string *v13; // rax
  const std::string *v14; // rax
  char *Ptr; // rcx
  char *v16; // rcx
  std::string *v17; // rax
  const std::string *v18; // rax
  char *v19; // rcx
  char *v20; // rcx
  std::pair<unsigned __int64,unsigned __int64> *LatencyFromCache_deprecated; // rax
  unsigned __int64 first; // r14
  unsigned __int64 second; // r15
  _Mtx_internal_imp_t *MyMutex; // rbx
  int v25; // eax
  std::_Ref_count_base *v26; // rcx
  long double v27; // xmm6_8
  float v28; // xmm2_4
  std::string *v29; // rax
  std::string *v30; // rbx
  unsigned __int64 Mysize; // r8
  unsigned __int64 Myres; // rcx
  unsigned __int64 v33; // rdi
  size_t v34; // r14
  char *v35; // rcx
  char *v36; // rcx
  std::_Ref_count_base *v37; // rcx
  std::string category; // [rsp+30h] [rbp-D0h] BYREF
  std::weak_ptr<PluginPermissionsFetcher> v39; // [rsp+50h] [rbp-B0h] BYREF
  std::weak_ptr<PluginPermissionsFetcher> v40; // [rsp+60h] [rbp-A0h] BYREF
  RBX::Network::Client::LatencyExperimentCache::Record record; // [rsp+70h] [rbp-90h] BYREF
  RBX::Time v42; // [rsp+98h] [rbp-68h] BYREF
  std::string v43; // [rsp+A0h] [rbp-60h] BYREF
  std::string v44; // [rsp+C0h] [rbp-40h] BYREF
  std::string result; // [rsp+E0h] [rbp-20h] BYREF
  std::string v46; // [rsp+100h] [rbp+0h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v47; // [rsp+120h] [rbp+20h] BYREF
  std::lock_guard<std::mutex> latencyCacheLock; // [rsp+1A8h] [rbp+A8h] BYREF

  __wind /*0xf1c00000000000d0*/
  {
    v5 = 0; /*0x14101b42f*/
    p_latencyExperimentCache = &this->latencyExperimentCache; /*0x14101b432*/
    if ( DFFlag::CLI55145Experiment.value ) /*0x14101b443*/
    {
      RBX::Network::Client::LatencyExperimentCache::readLatencyFromCache( /*0x14101b44e*/
        this: p_latencyExperimentCache,
        result: &record,
        userId);
      p_setLatencyMx = (_Mtx_internal_imp_t *)&this->setLatencyMx; /*0x14101b453*/
      latencyCacheLock._MyMutex = &this->setLatencyMx; /*0x14101b45a*/
      v8 = Mtx_lock_0(a1: (_Mtx_t)&this->setLatencyMx); /*0x14101b464*/
      if ( v8 != 0 ) /*0x14101b46b*/
      {
        std::_Throw_C_error(a1: v8); /*0x14101b966*/
        JUMPOUT(0x14101B96BLL); /*0x14101b96b*/
      }
      if ( this->latencySetFromLiveResponse ) /*0x14101b471*/
      {
        httpPopDcLatencyMs = record.httpPopDcLatencyMs; /*0x14101b4d5*/
        receiveLatencyUS = record.receiveLatencyUS; /*0x14101b4d9*/
        transmitLatencyUS = record.transmitLatencyUS; /*0x14101b4dd*/
      }
      else
      {
        v5 = 1; /*0x14101b479*/
        v39 = 0; /*0x14101b47f*/
        Rep = weakDm->_Rep; /*0x14101b485*/
        if ( Rep != nullptr ) /*0x14101b48d*/
        {
          v39._Ptr = weakDm->_Ptr; /*0x14101b493*/
          v39._Rep = Rep; /*0x14101b498*/
          _InterlockedIncrement((volatile signed __int32 *)&Rep->_Weaks); /*0x14101b49d*/
          p_setLatencyMx = (_Mtx_internal_imp_t *)latencyCacheLock._MyMutex; /*0x14101b4a1*/
        }
        __eh34_enter_wind_state(0, 1); /*0xf1c00000000000c8*/
        receiveLatencyUS = record.receiveLatencyUS; /*0x14101b4a8*/
        transmitLatencyUS = record.transmitLatencyUS; /*0x14101b4af*/
        RBX::Network::Client::setArtificialLatencyDmWriteLock( /*0x14101b4bf*/
          this,
          weakDm: &v39,
          txLatency: record.transmitLatencyUS,
          rxLatency: record.receiveLatencyUS);
        httpPopDcLatencyMs = record.httpPopDcLatencyMs; /*0x14101b4c4*/
        RBX::Http::setDefaultArtificialLatencyValues( /*0x14101b4ce*/
          newClientPopDelayMs: record.httpCliPopLatencyMs,
          newPopDcDelayMs: record.httpPopDcLatencyMs);
        if ( __eh34_unwind(1) ) /*0xf1c00000000000bc*/
          goto unwind_state_1; /*0xf1c00000000000bc*/
        __eh34_exit_wind_state(1, 0); /*0xf1c00000000000c0*/
      }
      Mtx_unlock_0(a1: p_setLatencyMx); /*0x14101b4e5*/
      if ( v5 != 0 ) /*0x14101b4ed*/
      {
        if ( transmitLatencyUS != 0 || receiveLatencyUS != 0 ) /*0x14101b4fb*/
        {
          v13 = RBX::SystemUtil::osPlatform(&result); /*0x14101b505*/
          __wind /*0xf1c00000000000b0*/
          {
            v14 = std::operator+<char>(result: &v43, _Left: "RakNetLatencySetCache-", _Right: v13); /*0x14101b519*/
            __wind /*0xf1c00000000000a4*/
            {
              RBX::Analytics::EphemeralCounter::reportCounter(counterName: v14, amount: 1, blocking: false); /*0x14101b529*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v43); /*0xf1c000000000009c*/
            }
            if ( v43._Mypair._Myval2._Myres >= 0x10 ) /*0x14101b537*/
            {
              Ptr = v43._Mypair._Myval2._Bx._Ptr; /*0x14101b53c*/
              if ( v43._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101b54a*/
              {
                Ptr = *((char **)v43._Mypair._Myval2._Bx._Ptr - 1); /*0x14101b550*/
                if ( (unsigned __int64)(v43._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14101b55f*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14101b561*/
              }
              operator delete(ptr: Ptr); /*0x14101b568*/
            }
            v43._Mypair._Myval2._Mysize = 0; /*0x14101b56d*/
            v43._Mypair._Myval2._Myres = 15; /*0x14101b575*/
            v43._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101b57d*/
            if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14101b589*/
            {
              v16 = result._Mypair._Myval2._Bx._Ptr; /*0x14101b58e*/
              if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101b59c*/
              {
                v16 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14101b5a2*/
                if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x14101b5b1*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14101b5b3*/
              }
              operator delete(ptr: v16); /*0x14101b5ba*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000090*/
          }
        }
        if ( record.httpCliPopLatencyMs != 0 || httpPopDcLatencyMs != 0 ) /*0x14101b5c8*/
        {
          v17 = RBX::SystemUtil::osPlatform(result: &v46); /*0x14101b5d2*/
          __wind /*0xf1c0000000000080*/
          {
            v18 = std::operator+<char>(result: &v44, _Left: "HttpLatencySetCache-", _Right: v17); /*0x14101b5e6*/
            __wind /*0xf1c000000000005c*/
            {
              RBX::Analytics::EphemeralCounter::reportCounter(counterName: v18, amount: 1, blocking: false); /*0x14101b5f6*/
              if ( v44._Mypair._Myval2._Myres >= 0x10 ) /*0x14101b604*/
              {
                v19 = v44._Mypair._Myval2._Bx._Ptr; /*0x14101b609*/
                if ( v44._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101b617*/
                {
                  v19 = *((char **)v44._Mypair._Myval2._Bx._Ptr - 1); /*0x14101b61d*/
                  if ( (unsigned __int64)(v44._Mypair._Myval2._Bx._Ptr - v19 - 8) > 0x1F ) /*0x14101b62c*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14101b62e*/
                }
                operator delete(ptr: v19); /*0x14101b635*/
              }
              v44._Mypair._Myval2._Mysize = 0; /*0x14101b63d*/
              v44._Mypair._Myval2._Myres = 15; /*0x14101b641*/
              v44._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101b649*/
              if ( v46._Mypair._Myval2._Myres >= 0x10 ) /*0x14101b655*/
              {
                v20 = v46._Mypair._Myval2._Bx._Ptr; /*0x14101b65e*/
                if ( v46._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101b66c*/
                {
                  v20 = *((char **)v46._Mypair._Myval2._Bx._Ptr - 1); /*0x14101b672*/
                  if ( (unsigned __int64)(v46._Mypair._Myval2._Bx._Ptr - v20 - 8) > 0x1F ) /*0x14101b681*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14101b683*/
                }
                operator delete(ptr: v20); /*0x14101b68a*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v44); /*0xf1c000000000006c*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v46); /*0xf1c0000000000078*/
          }
        }
LABEL_41:
        v27 = (RBX::Time::nowFast(result: &v42)->sec - this->latencyCheckStartTime.sec) * 1000.0; /*0x14101b732*/
        if ( FLog::Network != 0 ) /*0x14101b758*/
        {
          v28 = v27; /*0x14101b75a*/
          FLog::FastLogF( /*0x14101b774*/
            channel: FLog::Network,
            message: "[FLog::Network] Set latency from Ixp cache after %02f ms",
            arg1: v28,
            arg2: 0.0,
            arg3: 0.0,
            arg4: 0.0);
        }
        v29 = RBX::SystemUtil::osPlatform(result: &v47.text); /*0x14101b77d*/
        v30 = v29; /*0x14101b782*/
        __wind /*0xf1c0000000000028*/
        {
          Mysize = v29->_Mypair._Myval2._Mysize; /*0x14101b785*/
          Myres = v29->_Mypair._Myval2._Myres; /*0x14101b789*/
          if ( Myres - Mysize < 0x1C ) /*0x14101b797*/
          {
            v30 = std::string::_Reallocate_grow_by<_lambda_f3a66ab6a0570788f31503db83886f49_,unsigned __int64,char const *,unsigned __int64>( /*0x14101b845*/
                    this: v29,
                    _Size_increase: 0x1Cu,
                    _Fn: 0,
                    <_Args_0>: 0,
                    <_Args_1>: "ArtificialLatencyIxpCacheMs-",
                    <_Args_2>: 0x1Cu);
          }
          else
          {
            v29->_Mypair._Myval2._Mysize = Mysize + 28; /*0x14101b7a1*/
            v33 = (unsigned __int64)v29; /*0x14101b7a5*/
            if ( Myres >= 0x10 ) /*0x14101b7ac*/
              v33 = (unsigned __int64)v29->_Mypair._Myval2._Bx._Ptr; /*0x14101b7ae*/
            if ( (unsigned __int64)"" <= v33 || (unsigned __int64)"ArtificialLatencyIxpCacheMs-" > v33 + Mysize ) /*0x14101b7d1*/
            {
              v34 = 28; /*0x14101b7e5*/
            }
            else if ( v33 > (unsigned __int64)"ArtificialLatencyIxpCacheMs-" ) /*0x14101b7d6*/
            {
              v34 = v33 - (_QWORD)"ArtificialLatencyIxpCacheMs-"; /*0x14101b7e0*/
            }
            else
            {
              v34 = 0; /*0x14101b7d8*/
            }
            memmove_0(a1: (void *)(v33 + 28), Src: (const void *)v33, Size: Mysize + 1); /*0x14101b7f2*/
            memcpy_0(a1: (void *)v33, Src: "ArtificialLatencyIxpCacheMs-", Size: v34); /*0x14101b800*/
            memcpy_0(a1: (void *)(v33 + v34), Src: &aArtificiallate[v34 + 28], Size: 28 - v34); /*0x14101b816*/
          }
          category._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14101b848*/
          category._Mypair._Myval2._Mysize = 0; /*0x14101b84d*/
          category._Mypair._Myval2._Myres = 0; /*0x14101b852*/
          category = *v30; /*0x14101b85a*/
          v30->_Mypair._Myval2._Mysize = 0; /*0x14101b868*/
          v30->_Mypair._Myval2._Myres = 15; /*0x14101b86c*/
          v30->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101b874*/
          __wind /*0xf1c000000000001c*/
          {
            RBX::Analytics::EphemeralCounter::reportStats(&category, value: v27, blocking: false); /*0x14101b882*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&category); /*0xf1c0000000000014*/
          }
          if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x14101b891*/
          {
            v35 = category._Mypair._Myval2._Bx._Ptr; /*0x14101b896*/
            if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101b8a5*/
            {
              v35 = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x14101b8ab*/
              if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - v35 - 8) > 0x1F ) /*0x14101b8ba*/
                _invalid_parameter_noinfo_noreturn(); /*0x14101b8bc*/
            }
            operator delete(ptr: v35); /*0x14101b8c3*/
          }
          category._Mypair._Myval2._Mysize = 0; /*0x14101b8c8*/
          category._Mypair._Myval2._Myres = 15; /*0x14101b8cd*/
          category._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101b8d6*/
          if ( v47.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14101b8e3*/
          {
            v36 = v47.text._Mypair._Myval2._Bx._Ptr; /*0x14101b8e8*/
            if ( v47.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101b8f6*/
            {
              v36 = *((char **)v47.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14101b8fc*/
              if ( (unsigned __int64)(v47.text._Mypair._Myval2._Bx._Ptr - v36 - 8) > 0x1F ) /*0x14101b90b*/
                _invalid_parameter_noinfo_noreturn(); /*0x14101b90d*/
            }
            operator delete(ptr: v36); /*0x14101b914*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v47); /*0xf1c0000000000038*/
        }
      }
    }
    else
    {
      LatencyFromCache_deprecated = RBX::Network::Client::LatencyExperimentCache::readLatencyFromCache_deprecated( /*0x14101b699*/
                                      this: p_latencyExperimentCache,
                                      result: (std::pair<unsigned __int64,unsigned __int64> *)&record,
                                      userId);
      first = LatencyFromCache_deprecated->first; /*0x14101b69e*/
      second = LatencyFromCache_deprecated->second; /*0x14101b6a1*/
      if ( *(_OWORD *)LatencyFromCache_deprecated != 0 ) /*0x14101b6a8*/
      {
        MyMutex = (_Mtx_internal_imp_t *)&this->setLatencyMx; /*0x14101b6b3*/
        latencyCacheLock._MyMutex = &this->setLatencyMx; /*0x14101b6ba*/
        v25 = Mtx_lock_0(a1: (_Mtx_t)&this->setLatencyMx); /*0x14101b6c4*/
        if ( v25 != 0 ) /*0x14101b6cb*/
        {
          std::_Throw_C_error(a1: v25); /*0x14101b95e*/
          __debugbreak(); /*0x14101b963*/
        }
        if ( !this->latencySetFromLiveResponse ) /*0x14101b6d7*/
        {
          v5 = 1; /*0x14101b6d9*/
          v40 = 0; /*0x14101b6df*/
          v26 = weakDm->_Rep; /*0x14101b6e5*/
          if ( v26 != nullptr ) /*0x14101b6ed*/
          {
            v40._Ptr = weakDm->_Ptr; /*0x14101b6f3*/
            v40._Rep = v26; /*0x14101b6f8*/
            _InterlockedIncrement((volatile signed __int32 *)&v26->_Weaks); /*0x14101b6fd*/
            MyMutex = (_Mtx_internal_imp_t *)latencyCacheLock._MyMutex; /*0x14101b701*/
          }
          __eh34_enter_wind_state(0, 1); /*0xf1c0000000000054*/
          RBX::Network::Client::setArtificialLatencyDmWriteLock(this, weakDm: &v40, txLatency: first, rxLatency: second); /*0x14101b716*/
          if ( __eh34_unwind(1) ) /*0xf1c0000000000040*/
          {
unwind_state_1:
            std::scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>::~scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>(this: (MicroProfileScopeLock *)&latencyCacheLock); /*0xf1c0000000000044*/
            __eh34_continue_unwinding(1, 0); /*0xf1c0000000000048*/
          }
          __eh34_exit_wind_state(1, 0); /*0xf1c000000000004c*/
        }
        Mtx_unlock_0(a1: MyMutex); /*0x14101b71f*/
        if ( v5 != 0 ) /*0x14101b727*/
          goto LABEL_41; /*0x14101b727*/
      }
    }
  }
  __unwind
  {
    std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: weakDm); /*0xf1c0000000000008*/
  }
  v37 = weakDm->_Rep; /*0x14101b91a*/
  if ( v37 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v37->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101b931*/
    v37->_Delete_this(this: v37); /*0x14101b936*/
}

// Address: 0x14101b970 | Name: ?setArtificialLatencyFromIxp@Client@Network@RBX@@AEAAXV?$weak_ptr@VDataModel@RBX@@@std@@_JV?$shared_ptr@$$CBV?$unordered_map@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@VVariant@Reflection@RBX@@U?$hash@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@U?$equal_to@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@V?$allocator@U?$pair@$$CBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@VVariant@Reflection@RBX@@@std@@@2@@std@@@5@@Z
// local variable allocation has failed, the output may be wrong!
void __fastcall RBX::Network::Client::setArtificialLatencyFromIxp(
        RBX::Network::Client *this,
        std::weak_ptr<PluginPermissionsFetcher> *weakDm,
        __int64 userId,
        std::shared_ptr<RBX::File> *layerVariables)
{
  unsigned __int64 v6; // r12
  unsigned __int64 v7; // rsi
  int v8; // r14d
  int v9; // r15d
  const std::unordered_map<std::string,RBX::Reflection::Variant> *Ptr; // rbx
  const std::unordered_map<std::string,RBX::Reflection::Variant> *v11; // rbx
  const std::unordered_map<std::string,RBX::Reflection::Variant> *v12; // rbx
  const std::unordered_map<std::string,RBX::Reflection::Variant> *v13; // rbx
  _Mtx_internal_imp_t *p_setLatencyMx; // rbx
  int v15; // eax
  bool latencySetFromLiveResponse; // di
  std::_Ref_count_base *Rep; // rcx
  long double v18; // xmm6_8
  float v19; // xmm2_4
  std::string *v20; // rax
  std::string *v21; // rbx
  unsigned __int64 Mysize; // r8
  unsigned __int64 Myres; // rcx
  unsigned __int64 v24; // rdi
  size_t v25; // rsi
  char *v26; // rcx
  char *v27; // rcx
  std::string *v28; // rax
  const std::string *v29; // rax
  char *v30; // rcx
  char *v31; // rcx
  int v32; // ebx
  std::string *v33; // rax
  const std::string *v34; // rax
  char *v35; // rcx
  char *v36; // rcx
  __int128 v37; // xmm6
  __int128 v38; // xmm7
  std::_Ref_count_base *v39; // rdx
  signed __int32 Uses; // eax
  signed __int32 v41; // ett
  std::_Ref_count_base *v42; // rsi
  __int64 v43; // rax
  __int64 v44; // rcx
  volatile signed __int32 *v45; // rbx
  __int64 v46; // rbx
  std::_Ref_count_base *v47; // rcx
  std::_Ref_count_base *v48; // rbx
  _DWORD v49[10]; // [rsp+8h] [rbp-100h] BYREF
  _BYTE weakThis[24]; // [rsp+38h] [rbp-D0h] OVERLAPPED BYREF
  std::_String_val<std::_Simple_types<char> >::_Bxty category_8; // [rsp+50h] [rbp-B8h] BYREF
  __int128 category_24; // [rsp+60h] [rbp-A8h]
  std::weak_ptr<PluginPermissionsFetcher> v53; // [rsp+70h] [rbp-98h] OVERLAPPED BYREF
  std::_List_const_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > > receiveIt; // [rsp+80h] [rbp-88h] BYREF
  std::_List_const_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > > httpCliPopIt; // [rsp+88h] [rbp-80h] BYREF
  std::_List_const_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > > httpPopDcIt; // [rsp+90h] [rbp-78h] BYREF
  std::lock_guard<std::mutex> latencyCacheLock; // [rsp+98h] [rbp-70h] BYREF
  MicroProfileScopeLock v58; // [rsp+A0h] [rbp-68h] BYREF
  RBX::Time result; // [rsp+A8h] [rbp-60h] BYREF
  __int128 v60; // [rsp+B0h] [rbp-58h]
  __int128 v61; // [rsp+C0h] [rbp-48h]
  std::string v62; // [rsp+D0h] [rbp-38h] BYREF
  std::string v63; // [rsp+F0h] [rbp-18h] BYREF
  __int128 v64; // [rsp+110h] [rbp+8h]
  __int128 v65; // [rsp+120h] [rbp+18h]
  std::function<void __cdecl(void)> v66; // [rsp+130h] [rbp+28h] BYREF
  __int128 v67; // [rsp+170h] [rbp+68h]
  std::string v68; // [rsp+1A0h] [rbp+98h] BYREF
  std::string v69; // [rsp+1C0h] [rbp+B8h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v70[2]; // [rsp+1E0h] [rbp+D8h] BYREF
  int v71; // [rsp+278h] [rbp+170h]

  v6 = 0; /*0x14101b9a7*/
  v7 = 0; /*0x14101b9aa*/
  *(_QWORD *)&weakThis[8] = 0; /*0x14101b9ac*/
  v8 = 0; /*0x14101b9b1*/
  *(_DWORD *)weakThis = 0; /*0x14101b9b4*/
  v9 = 0; /*0x14101b9b9*/
  v71 = 0; /*0x14101b9bc*/
  Ptr = (const std::unordered_map<std::string,RBX::Reflection::Variant> *)layerVariables->_Ptr; /*0x14101b9c3*/
  std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::find<void>( /*0x14101b9d5*/
    this: (std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<Luau::Module>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<Luau::Module> > >,0> > *)layerVariables->_Ptr,
    result: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<Luau::Module> > > > > *)&receiveIt,
    _Keyval: &FString::CLI52064IxpTxParam);
  __wind /*0xf1c0000000000104*/
  {
    __wind /*0xf1c000000000010c*/
    {
      if ( receiveIt._Ptr != Ptr->_List._Mypair._Myval2._Myhead && receiveIt._Ptr->_Myval.second._type->isNumber ) /*0x14101b9ec*/
        v6 = 1000 * RBX::Reflection::Variant::get<int>(this: &receiveIt._Ptr->_Myval.second); /*0x14101b9fd*/
      v11 = (const std::unordered_map<std::string,RBX::Reflection::Variant> *)layerVariables->_Ptr; /*0x14101ba00*/
      std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::find<void>( /*0x14101ba11*/
        this: (std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<Luau::Module>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<Luau::Module> > >,0> > *)layerVariables->_Ptr,
        result: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<Luau::Module> > > > > *)&httpCliPopIt,
        _Keyval: &FString::CLI52064IxpRxParam);
      if ( httpCliPopIt._Ptr != v11->_List._Mypair._Myval2._Myhead && httpCliPopIt._Ptr->_Myval.second._type->isNumber ) /*0x14101ba27*/
      {
        v7 = 1000 * RBX::Reflection::Variant::get<int>(this: &httpCliPopIt._Ptr->_Myval.second); /*0x14101ba38*/
        *(_QWORD *)&weakThis[8] = v7; /*0x14101ba3b*/
      }
      if ( DFFlag::CLI55145Experiment.value ) /*0x14101ba47*/
      {
        v12 = (const std::unordered_map<std::string,RBX::Reflection::Variant> *)layerVariables->_Ptr; /*0x14101ba49*/
        std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::find<void>( /*0x14101ba5a*/
          this: (std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<Luau::Module>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<Luau::Module> > >,0> > *)layerVariables->_Ptr,
          result: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<Luau::Module> > > > > *)&httpPopDcIt,
          _Keyval: &FString::CLI55145IxpCliPopParam);
        if ( httpPopDcIt._Ptr != v12->_List._Mypair._Myval2._Myhead && httpPopDcIt._Ptr->_Myval.second._type->isNumber ) /*0x14101ba70*/
        {
          v8 = RBX::Reflection::Variant::get<int>(this: &httpPopDcIt._Ptr->_Myval.second); /*0x14101ba7b*/
          *(_DWORD *)weakThis = v8; /*0x14101ba7e*/
        }
        v13 = (const std::unordered_map<std::string,RBX::Reflection::Variant> *)layerVariables->_Ptr; /*0x14101ba82*/
        std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::find<void>( /*0x14101ba93*/
          this: (std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<Luau::Module>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<Luau::Module> > >,0> > *)layerVariables->_Ptr,
          result: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<Luau::Module> > > > > *)&latencyCacheLock,
          _Keyval: &FString::CLI55145IxpPopDcParam);
        if ( latencyCacheLock._MyMutex != (std::mutex *)v13->_List._Mypair._Myval2._Myhead /*0x14101baad*/
          && *(_BYTE *)(*(_QWORD *)&latencyCacheLock._MyMutex->_Mtx_storage._Pad[48] + 53LL) != 0 )
        {
          v9 = RBX::Reflection::Variant::get<int>(this: (RBX::Reflection::Variant *)&latencyCacheLock._MyMutex->_Mtx_storage._Pad[48]); /*0x14101bab4*/
          v71 = v9; /*0x14101bab7*/
        }
      }
      p_setLatencyMx = (_Mtx_internal_imp_t *)&this->setLatencyMx; /*0x14101babd*/
      v58.m = (std::recursive_mutex *)&this->setLatencyMx; /*0x14101bac4*/
      v15 = Mtx_lock_0(a1: (_Mtx_t)&this->setLatencyMx); /*0x14101bacb*/
      if ( v15 != 0 ) /*0x14101bad2*/
      {
        std::_Throw_C_error(a1: v15); /*0x14101c131*/
        __debugbreak(); /*0x14101c136*/
      }
      __wind /*0xf1c00000000000f8*/
      {
        latencySetFromLiveResponse = this->latencySetFromLiveResponse; /*0x14101bad8*/
        this->latencySetFromLiveResponse = true; /*0x14101bae0*/
        v53 = 0; /*0x14101baeb*/
        Rep = weakDm->_Rep; /*0x14101baf8*/
        if ( Rep != nullptr ) /*0x14101baff*/
        {
          v53._Ptr = weakDm->_Ptr; /*0x14101bb04*/
          v53._Rep = Rep; /*0x14101bb09*/
          _InterlockedIncrement((volatile signed __int32 *)&Rep->_Weaks); /*0x14101bb0e*/
          p_setLatencyMx = (_Mtx_internal_imp_t *)v58.m; /*0x14101bb12*/
        }
        RBX::Network::Client::setArtificialLatencyDmWriteLock(this, weakDm: &v53, txLatency: v6, rxLatency: v7); /*0x14101bb24*/
        if ( DFFlag::CLI55145Experiment.value ) /*0x14101bb30*/
          RBX::Http::setDefaultArtificialLatencyValues(newClientPopDelayMs: v8, newPopDcDelayMs: v9); /*0x14101bb38*/
      }
      __unwind
      {
        std::scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>::~scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>(this: &v58); /*0xf1c00000000000f0*/
      }
      Mtx_unlock_0(a1: p_setLatencyMx); /*0x14101bb41*/
      if ( latencySetFromLiveResponse ) /*0x14101bb49*/
      {
        v32 = v71; /*0x14101bf01*/
      }
      else
      {
        v18 = (RBX::Time::nowFast(&result)->sec - this->latencyCheckStartTime.sec) * 1000.0; /*0x14101bb6c*/
        if ( FLog::Network != 0 ) /*0x14101bb76*/
        {
          v19 = v18; /*0x14101bb78*/
          FLog::FastLogF( /*0x14101bb92*/
            channel: FLog::Network,
            message: "[FLog::Network] Set latency from Ixp live response after %02f ms",
            arg1: v19,
            arg2: 0.0,
            arg3: 0.0,
            arg4: 0.0);
        }
        v20 = RBX::SystemUtil::osPlatform(result: &v68); /*0x14101bb9e*/
        v21 = v20; /*0x14101bba3*/
        __wind /*0xf1c00000000000e0*/
        {
          Mysize = v20->_Mypair._Myval2._Mysize; /*0x14101bba6*/
          Myres = v20->_Mypair._Myval2._Myres; /*0x14101bbaa*/
          if ( Myres - Mysize < 0x1E ) /*0x14101bbb8*/
          {
            v21 = std::string::_Reallocate_grow_by<_lambda_f3a66ab6a0570788f31503db83886f49_,unsigned __int64,char const *,unsigned __int64>( /*0x14101bc6a*/
                    this: v20,
                    _Size_increase: 0x1Eu,
                    _Fn: 0,
                    <_Args_0>: 0,
                    <_Args_1>: "ArtificialLatencyIxpBackendMs-",
                    <_Args_2>: 0x1Eu);
          }
          else
          {
            v20->_Mypair._Myval2._Mysize = Mysize + 30; /*0x14101bbc2*/
            v24 = (unsigned __int64)v20; /*0x14101bbc6*/
            if ( Myres >= 0x10 ) /*0x14101bbcd*/
              v24 = (unsigned __int64)v20->_Mypair._Myval2._Bx._Ptr; /*0x14101bbcf*/
            if ( (unsigned __int64)"" <= v24 || (unsigned __int64)"ArtificialLatencyIxpBackendMs-" > v24 + Mysize ) /*0x14101bbf2*/
            {
              v25 = 30; /*0x14101bc05*/
            }
            else if ( v24 > (unsigned __int64)"ArtificialLatencyIxpBackendMs-" ) /*0x14101bbf7*/
            {
              v25 = v24 - (_QWORD)"ArtificialLatencyIxpBackendMs-"; /*0x14101bc00*/
            }
            else
            {
              v25 = 0; /*0x14101bbf9*/
            }
            memmove_0(a1: (void *)(v24 + 30), Src: (const void *)v24, Size: Mysize + 1); /*0x14101bc12*/
            memcpy_0(a1: (void *)v24, Src: "ArtificialLatencyIxpBackendMs-", Size: v25); /*0x14101bc20*/
            memcpy_0(a1: (void *)(v24 + v25), Src: &aArtificiallate_0[v25 + 30], Size: 30 - v25); /*0x14101bc36*/
            v7 = *(_QWORD *)&weakThis[8]; /*0x14101bc3b*/
          }
          category_8._Ptr = nullptr; /*0x14101bc6f*/
          category_24 = 0u; /*0x14101bc74*/
          category_8 = v21->_Mypair._Myval2._Bx; /*0x14101bc81*/
          category_24 = *(_OWORD *)&v21->_Mypair._Myval2._Mysize; /*0x14101bc8a*/
          v21->_Mypair._Myval2._Mysize = 0; /*0x14101bc8f*/
          v21->_Mypair._Myval2._Myres = 15; /*0x14101bc93*/
          v21->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101bc9b*/
          __wind /*0xf1c00000000000d4*/
          {
            RBX::Analytics::EphemeralCounter::reportStats( /*0x14101bca9*/
              category: (const std::string *)&category_8,
              value: v18,
              blocking: false);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&category_8); /*0xf1c00000000000cc*/
          }
          if ( *((_QWORD *)&category_24 + 1) >= 0x10u ) /*0x14101bcb8*/
          {
            v26 = category_8._Ptr; /*0x14101bcbd*/
            if ( (unsigned __int64)(*((_QWORD *)&category_24 + 1) + 1LL) >= 0x1000 ) /*0x14101bccc*/
            {
              v26 = *((char **)category_8._Ptr - 1); /*0x14101bcd2*/
              if ( (unsigned __int64)(category_8._Ptr - v26 - 8) > 0x1F ) /*0x14101bce1*/
                _invalid_parameter_noinfo_noreturn(); /*0x14101bce3*/
            }
            operator delete(ptr: v26); /*0x14101bcea*/
          }
          *(_QWORD *)&category_24 = 0; /*0x14101bcef*/
          *((_QWORD *)&category_24 + 1) = 15; /*0x14101bcf4*/
          category_8._Buf[0] = 0; /*0x14101bcfd*/
          if ( v68._Mypair._Myval2._Myres >= 0x10 ) /*0x14101bd0d*/
          {
            v27 = v68._Mypair._Myval2._Bx._Ptr; /*0x14101bd12*/
            if ( v68._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101bd23*/
            {
              v27 = *((char **)v68._Mypair._Myval2._Bx._Ptr - 1); /*0x14101bd29*/
              if ( (unsigned __int64)(v68._Mypair._Myval2._Bx._Ptr - v27 - 8) > 0x1F ) /*0x14101bd38*/
                _invalid_parameter_noinfo_noreturn(); /*0x14101bd3a*/
            }
            operator delete(ptr: v27); /*0x14101bd41*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v68); /*0xf1c00000000000c0*/
        }
        if ( !DFFlag::CLI55145Experiment.value ) /*0x14101bd4d*/
          goto LABEL_77; /*0x14101bd4d*/
        if ( v6 != 0 || v7 != 0 ) /*0x14101bd5b*/
        {
          v28 = RBX::SystemUtil::osPlatform(result: &v69); /*0x14101bd68*/
          __wind /*0xf1c00000000000b0*/
          {
            v29 = std::operator+<char>(result: &v62, _Left: "RakNetLatencySetLive-", _Right: v28); /*0x14101bd7c*/
            __wind /*0xf1c000000000008c*/
            {
              RBX::Analytics::EphemeralCounter::reportCounter(counterName: v29, amount: 1, blocking: false); /*0x14101bd8c*/
              if ( v62._Mypair._Myval2._Myres >= 0x10 ) /*0x14101bd9a*/
              {
                v30 = v62._Mypair._Myval2._Bx._Ptr; /*0x14101bd9f*/
                if ( v62._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101bdad*/
                {
                  v30 = *((char **)v62._Mypair._Myval2._Bx._Ptr - 1); /*0x14101bdb3*/
                  if ( (unsigned __int64)(v62._Mypair._Myval2._Bx._Ptr - v30 - 8) > 0x1F ) /*0x14101bdc2*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14101bdc4*/
                }
                operator delete(ptr: v30); /*0x14101bdcb*/
              }
              v62._Mypair._Myval2._Mysize = 0; /*0x14101bdd0*/
              v62._Mypair._Myval2._Myres = 15; /*0x14101bdd4*/
              v62._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101bddc*/
              if ( v69._Mypair._Myval2._Myres >= 0x10 ) /*0x14101bdeb*/
              {
                v31 = v69._Mypair._Myval2._Bx._Ptr; /*0x14101bdf0*/
                if ( v69._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101be01*/
                {
                  v31 = *((char **)v69._Mypair._Myval2._Bx._Ptr - 1); /*0x14101be07*/
                  if ( (unsigned __int64)(v69._Mypair._Myval2._Bx._Ptr - v31 - 8) > 0x1F ) /*0x14101be16*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14101be18*/
                }
                operator delete(ptr: v31); /*0x14101be1f*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v62); /*0xf1c000000000009c*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v69); /*0xf1c00000000000a8*/
          }
        }
        v8 = *(_DWORD *)weakThis; /*0x14101be24*/
        v32 = v71; /*0x14101be29*/
        if ( *(_DWORD *)weakThis != 0 || v71 != 0 ) /*0x14101be36*/
        {
          v33 = RBX::SystemUtil::osPlatform(result: &v70[0].text); /*0x14101be43*/
          __wind /*0xf1c0000000000080*/
          {
            v34 = std::operator+<char>(result: &v63, _Left: "HttpLatencySetLive-", _Right: v33); /*0x14101be57*/
            __wind /*0xf1c000000000005c*/
            {
              RBX::Analytics::EphemeralCounter::reportCounter(counterName: v34, amount: 1, blocking: false); /*0x14101be67*/
              if ( v63._Mypair._Myval2._Myres >= 0x10 ) /*0x14101be75*/
              {
                v35 = v63._Mypair._Myval2._Bx._Ptr; /*0x14101be7a*/
                if ( v63._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101be88*/
                {
                  v35 = *((char **)v63._Mypair._Myval2._Bx._Ptr - 1); /*0x14101be8e*/
                  if ( (unsigned __int64)(v63._Mypair._Myval2._Bx._Ptr - v35 - 8) > 0x1F ) /*0x14101be9d*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14101be9f*/
                }
                operator delete(ptr: v35); /*0x14101bea6*/
              }
              v63._Mypair._Myval2._Mysize = 0; /*0x14101beab*/
              v63._Mypair._Myval2._Myres = 15; /*0x14101beaf*/
              v63._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101beb7*/
              if ( v70[0].text._Mypair._Myval2._Myres >= 0x10 ) /*0x14101bec6*/
              {
                v36 = v70[0].text._Mypair._Myval2._Bx._Ptr; /*0x14101becb*/
                if ( v70[0].text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14101bedc*/
                {
                  v36 = *((char **)v70[0].text._Mypair._Myval2._Bx._Ptr - 1); /*0x14101bee2*/
                  if ( (unsigned __int64)(v70[0].text._Mypair._Myval2._Bx._Ptr - v36 - 8) > 0x1F ) /*0x14101bef1*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14101bef3*/
                }
                operator delete(ptr: v36); /*0x14101befa*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v63); /*0xf1c000000000006c*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: v70); /*0xf1c0000000000078*/
          }
        }
      }
      if ( DFFlag::CLI55145Experiment.value ) /*0x14101bf10*/
      {
        *(_QWORD *)&v60 = userId; /*0x14101bf19*/
        *((_QWORD *)&v60 + 1) = v6; /*0x14101bf1d*/
        *(_QWORD *)&v61 = v7; /*0x14101bf21*/
        *((_QWORD *)&v61 + 1) = __PAIR64__(v32, v8); /*0x14101bf25*/
        v37 = v60; /*0x14101bf2c*/
        v38 = v61; /*0x14101bf30*/
        goto LABEL_78; /*0x14101bf34*/
      }
LABEL_77:
      *(_QWORD *)&v64 = userId; /*0x14101bf36*/
      *((_QWORD *)&v64 + 1) = v6; /*0x14101bf41*/
      v65 = v7; /*0x14101bf45*/
      v37 = v64; /*0x14101bf4f*/
      v38 = v7; /*0x14101bf53*/
LABEL_78:
      v39 = this->_Wptr._Rep; /*0x14101bf57*/
      if ( v39 == nullptr || (Uses = v39->_Uses) == 0 ) /*0x14101bf69*/
LABEL_107:
        std::_Throw_bad_weak_ptr(); /*0x14101c137*/
      while ( 1 ) /*0x14101bf73*/
      {
        v41 = Uses; /*0x14101bf73*/
        Uses = _InterlockedCompareExchange((volatile signed __int32 *)&v39->_Uses, Uses + 1, Uses); /*0x14101bf73*/
        if ( v41 == Uses ) /*0x14101bf78*/
          break; /*0x14101bf78*/
        if ( Uses == 0 ) /*0x14101bf7c*/
          goto LABEL_107; /*0x14101bf7c*/
      }
      __wind /*0xf1c0000000000014*/
      {
        v42 = this->_Wptr._Rep; /*0x14101bf84*/
        v49[8] = 0; /*0x14101bf88*/
        v43 = _RTDynamicCast_0(); /*0x14101bfa0*/
        if ( v43 != 0 ) /*0x14101bfa8*/
        {
          v45 = (volatile signed __int32 *)v42; /*0x14101bfaa*/
          v42 = nullptr; /*0x14101bfad*/
        }
        else
        {
          v43 = 0; /*0x14101bfb2*/
          v45 = nullptr; /*0x14101bfb5*/
        }
        *(_OWORD *)&weakThis[8] = 0; /*0x14101bfbb*/
        if ( v45 != nullptr ) /*0x14101bfc4*/
        {
          *(_QWORD *)&weakThis[8] = v43; /*0x14101bfc6*/
          *(_QWORD *)&weakThis[16] = v45; /*0x14101bfcb*/
          _InterlockedIncrement(v45 + 3); /*0x14101bfd0*/
          if ( _InterlockedExchangeAdd(v45 + 2, 0xFFFFFFFF) == 1 ) /*0x14101bfe8*/
          {
            (**(void (__fastcall ***)(volatile signed __int32 *))v45)(a1: v45); /*0x14101bff0*/
            if ( _InterlockedExchangeAdd(v45 + 3, 0xFFFFFFFF) == 1 ) /*0x14101bffc*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v45 + 8LL))(a1: v45); /*0x14101c004*/
          }
        }
        if ( v42 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v42->_Uses, 0xFFFFFFFF) == 1 ) /*0x14101c016*/
        {
          v42->_Destroy(this: v42); /*0x14101c01e*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v42->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101c02a*/
            v42->_Delete_this(this: v42); /*0x14101c032*/
        }
        v67 = 0; /*0x14101c038*/
        v46 = *(_QWORD *)&weakThis[16]; /*0x14101c03d*/
        if ( *(_QWORD *)&weakThis[16] != 0 ) /*0x14101c045*/
        {
          v67 = *(_OWORD *)&weakThis[8]; /*0x14101c04c*/
          _InterlockedIncrement((volatile signed __int32 *)(*(_QWORD *)&weakThis[16] + 12LL)); /*0x14101c054*/
          v46 = *(_QWORD *)&weakThis[16]; /*0x14101c058*/
        }
      }
      __unwind
      {
        __std_terminate(a1: v44, a2: v49); /*0x142f39fa8*/
      }
      __wind /*0xf1c000000000002c*/
      {
        v66._Mystorage._Ptrs[0] = (std::_Func_base<void> *)std::_Func_impl_no_alloc__lambda_33db0bfb4553aa426401a79f5f51d8dc__void_::_vftable_; /*0x14101c064*/
        *(_OWORD *)&v66._Mystorage._Ptrs[1] = v67; /*0x14101c06c*/
        *(_OWORD *)&v66._Mystorage._Ptrs[3] = v37; /*0x14101c078*/
        *(_OWORD *)&v66._Mystorage._Ptrs[5] = v38; /*0x14101c07c*/
        v66._Mystorage._Ptrs[7] = (std::_Func_base<void> *)&v66; /*0x14101c084*/
        RBX::TaskScheduler::submitAsyncTask(task: &v66, queueCounter: nullptr); /*0x14101c08e*/
        if ( v46 != 0 && _InterlockedExchangeAdd((volatile signed __int32 *)(v46 + 12), 0xFFFFFFFF) == 1 ) /*0x14101c0a3*/
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&weakThis[16] + 8LL))(a1: *(_QWORD *)&weakThis[16]); /*0x14101c0ad*/
        v47 = weakDm->_Rep; /*0x14101c0b8*/
        if ( v47 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v47->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101c0cb*/
          v47->_Delete_this(this: v47); /*0x14101c0d0*/
        v48 = layerVariables->_Rep; /*0x14101c0db*/
        if ( v48 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v48->_Uses, 0xFFFFFFFF) == 1 ) /*0x14101c0ee*/
        {
          v48->_Destroy(this: v48); /*0x14101c0f6*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v48->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101c100*/
            v48->_Delete_this(this: v48); /*0x14101c108*/
        }
      }
      __unwind
      {
        std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)&weakThis[8]); /*0xf1c000000000003c*/
      }
    }
    __unwind
    {
      std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: weakDm); /*0xf1c0000000000048*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: layerVariables); /*0xf1c0000000000054*/
  }
}

// Address: 0x14101c140 | Name: ?setGameSessionID@Client@Network@RBX@@QEAAXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RBX::Network::Client::setGameSessionID(
        RBX::Network::Client *this,
        RBX::Graphics::ProfilerAdorn::Item *value)
{
  std::string *p_gameSessionID; // rdi
  std::string *Ptr; // rdx
  unsigned __int64 Mysize; // rsi
  RBX::Graphics::ProfilerAdorn::Item *v6; // rcx
  RBX::Graphics::ProfilerAdorn::Item *v7; // rdx
  RBX::Graphics::ProfilerAdorn::Item *v8; // rdx
  unsigned __int64 Myres; // rdx
  char *v10; // rcx

  p_gameSessionID = &this->gameSessionID; /*0x14101c157*/
  Ptr = &this->gameSessionID; /*0x14101c15e*/
  if ( this->gameSessionID._Mypair._Myval2._Myres >= 0x10 ) /*0x14101c166*/
    Ptr = (std::string *)p_gameSessionID->_Mypair._Myval2._Bx._Ptr; /*0x14101c168*/
  Mysize = value->text._Mypair._Myval2._Mysize; /*0x14101c16b*/
  v6 = value; /*0x14101c16f*/
  if ( value->text._Mypair._Myval2._Myres >= 0x10 ) /*0x14101c177*/
    v6 = (RBX::Graphics::ProfilerAdorn::Item *)value->text._Mypair._Myval2._Bx._Ptr; /*0x14101c179*/
  if ( Mysize != p_gameSessionID->_Mypair._Myval2._Mysize /*0x14101c18c*/
    || memcmp_0(Buf1: v6, Buf2: Ptr, Size: value->text._Mypair._Myval2._Mysize) != 0 )
  {
    __wind /*0xf1c0000000000010*/
    {
      if ( p_gameSessionID != (std::string *)value ) /*0x14101c191*/
      {
        v7 = value; /*0x14101c193*/
        if ( value->text._Mypair._Myval2._Myres >= 0x10 ) /*0x14101c19b*/
          v7 = (RBX::Graphics::ProfilerAdorn::Item *)value->text._Mypair._Myval2._Bx._Ptr; /*0x14101c19d*/
        std::string::assign(this: p_gameSessionID, _Ptr: v7->text._Mypair._Myval2._Bx._Buf, _Count: Mysize); /*0x14101c1a6*/
      }
      if ( &RBX::Http::gameSessionID != (std::string *)value ) /*0x14101c1b5*/
      {
        v8 = value; /*0x14101c1b7*/
        if ( value->text._Mypair._Myval2._Myres >= 0x10 ) /*0x14101c1bf*/
          v8 = (RBX::Graphics::ProfilerAdorn::Item *)value->text._Mypair._Myval2._Bx._Ptr; /*0x14101c1c1*/
        std::string::assign( /*0x14101c1c8*/
          this: &RBX::Http::gameSessionID,
          _Ptr: v8->text._Mypair._Myval2._Bx._Buf,
          _Count: value->text._Mypair._Myval2._Mysize);
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: value); /*0xf1c0000000000008*/
    }
  }
  Myres = value->text._Mypair._Myval2._Myres; /*0x14101c1ce*/
  if ( Myres >= 0x10 ) /*0x14101c1d6*/
  {
    v10 = value->text._Mypair._Myval2._Bx._Ptr; /*0x14101c1db*/
    if ( Myres + 1 >= 0x1000 ) /*0x14101c1e5*/
    {
      if ( (unsigned __int64)&v10[-*((_QWORD *)v10 - 1) - 8] > 0x1F ) /*0x14101c1fa*/
        _invalid_parameter_noinfo_noreturn(); /*0x14101c227*/
      v10 = *((char **)v10 - 1); /*0x14101c1fc*/
    }
    operator delete(ptr: v10); /*0x14101c1ff*/
  }
  value->text._Mypair._Myval2._Mysize = 0; /*0x14101c204*/
  value->text._Mypair._Myval2._Myres = 15; /*0x14101c20c*/
  value->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101c214*/
}

// Address: 0x14101c230 | Name: ?setJoinStateFinishedReceivingInitialGameData@Client@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::Client::setJoinStateFinishedReceivingInitialGameData(RBX::Network::Client *this)
{
  this->reportingJoinState = JoinState_GameLoaded; /*0x14101c230*/
}

// Address: 0x14101c240 | Name: ?setPlaySessionId@Client@Network@RBX@@QEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RBX::Network::Client::setPlaySessionId(RBX::Network::Client *this, const std::string *pid)
{
  std::string *p_playSessionId; // rcx
  unsigned __int64 Mysize; // r8

  p_playSessionId = &this->playSessionId; /*0x14101c240*/
  if ( p_playSessionId != pid ) /*0x14101c24a*/
  {
    Mysize = pid->_Mypair._Myval2._Mysize; /*0x14101c251*/
    if ( pid->_Mypair._Myval2._Myres >= 0x10 ) /*0x14101c255*/
      pid = (const std::string *)pid->_Mypair._Myval2._Bx._Ptr; /*0x14101c257*/
    std::string::assign(this: p_playSessionId, _Ptr: pid->_Mypair._Myval2._Bx._Buf, _Count: Mysize); /*0x14101c25a*/
  }
}

// Address: 0x14101c260 | Name: ?setTicket@Client@Network@RBX@@QEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RBX::Network::Client::setTicket(RBX::Network::Client *this, const std::string *t)
{
  std::string *p_ticket; // rbx
  unsigned __int64 Mysize; // r8
  unsigned __int64 v5; // rax
  RBX::StringView *Myfirst; // rcx
  RBX::Security::EarlyAuthData *v7; // rax
  RBX::Security::EarlyAuthData *v8; // rdi
  std::_Ref_count_base *v9; // rax
  std::_Ref_count_base *v10; // rbx
  Luau::InternalErrorReporter *v11; // rax
  std::_Func_base<void,char const *>_vtbl *v12; // r8
  RBX::StringView *v13; // rax
  __int128 v14; // [rsp+30h] [rbp-68h] BYREF
  RBX::StringView blob; // [rsp+40h] [rbp-58h] BYREF
  std::shared_ptr<RBX::Security::EarlyAuthData> earlyAuthData; // [rsp+50h] [rbp-48h] BYREF
  std::vector<RBX::StringView> fields; // [rsp+60h] [rbp-38h] BYREF
  std::_Temporary_owner<RBX::Security::EarlyAuthData> v18; // [rsp+A0h] [rbp+8h] BYREF
  std::_Ref_count_base *v19; // [rsp+A8h] [rbp+10h]

  p_ticket = &this->ticket; /*0x14101c278*/
  if ( &this->ticket != t ) /*0x14101c282*/
  {
    Mysize = t->_Mypair._Myval2._Mysize; /*0x14101c284*/
    if ( t->_Mypair._Myval2._Myres >= 0x10 ) /*0x14101c28d*/
      t = (const std::string *)t->_Mypair._Myval2._Bx._Ptr; /*0x14101c28f*/
    std::string::assign(this: &this->ticket, _Ptr: t->_Mypair._Myval2._Bx._Buf, _Count: Mysize); /*0x14101c295*/
  }
  v5 = p_ticket->_Mypair._Myval2._Mysize; /*0x14101c29a*/
  if ( p_ticket->_Mypair._Myval2._Myres >= 0x10 ) /*0x14101c2a3*/
    p_ticket = (std::string *)p_ticket->_Mypair._Myval2._Bx._Ptr; /*0x14101c2a5*/
  blob.Data = (const char *)p_ticket; /*0x14101c2a8*/
  blob.Length = v5; /*0x14101c2ad*/
  memset(&fields, 0, sizeof(fields)); /*0x14101c2b5*/
  __wind /*0xf1c0000000000040*/
  {
    RBX::detail::StringViewBase::split(this: &blob, A: &fields, Separator: 59, MaxSplit: -1, KeepEmpty: true); /*0x14101c2dd*/
    Myfirst = fields._Mypair._Myval2._Myfirst; /*0x14101c2e7*/
    if ( (unsigned __int64)(fields._Mypair._Myval2._Mylast - fields._Mypair._Myval2._Myfirst) >= 5 ) /*0x14101c2f7*/
    {
      v7 = (RBX::Security::EarlyAuthData *)operator new(size: 0x48u); /*0x14101c300*/
      v8 = v7; /*0x14101c305*/
      if ( v7 != nullptr ) /*0x14101c30b*/
      {
        v7->preauthBlob._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14101c30d*/
        v7->preauthBlob._Mypair._Myval2._Mysize = 0; /*0x14101c310*/
        v7->preauthBlob._Mypair._Myval2._Myres = 15; /*0x14101c314*/
        v7->authBlob._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14101c31c*/
        v7->authBlob._Mypair._Myval2._Mysize = 0; /*0x14101c320*/
        v7->authBlob._Mypair._Myval2._Myres = 15; /*0x14101c324*/
      }
      else
      {
        v8 = nullptr; /*0x14101c32e*/
      }
      v18._Ptr = v8; /*0x14101c331*/
      __wind /*0xf1c000000000001c*/
      {
        v9 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x14101c33e*/
        v10 = v9; /*0x14101c343*/
        v19 = v9; /*0x14101c346*/
        if ( v9 != nullptr ) /*0x14101c351*/
        {
          *v9 = 0; /*0x14101c356*/
          v9->_Uses = 1; /*0x14101c359*/
          v9->_Weaks = 1; /*0x14101c360*/
          v9->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Security::EarlyAuthData>::`vftable'; /*0x14101c36e*/
          v9[1].__vftable = (std::_Ref_count_base_vtbl *)v8; /*0x14101c371*/
        }
        else
        {
          v10 = nullptr; /*0x14101c377*/
        }
        earlyAuthData._Ptr = v8; /*0x14101c37a*/
        earlyAuthData._Rep = v10; /*0x14101c37f*/
      }
      __unwind
      {
        std::_Temporary_owner<RBX::Security::EarlyAuthData>::~_Temporary_owner<RBX::Security::EarlyAuthData>(this: &v18); /*0xf1c000000000002c*/
      }
      __wind /*0xf1c0000000000034*/
      {
        v8->authVersion = atoi(String: *(const char **)((char *)&fields._Mypair._Myval2._Myfirst[-1].Data /*0x14101c3a0*/
                                                      + (((char *)fields._Mypair._Myval2._Mylast
                                                        - (char *)fields._Mypair._Myval2._Myfirst)
                                                       & 0xFFFFFFFFFFFFFFF0uLL)));
        base64<unsigned char,std::char_traits<unsigned char>>::decode( /*0x14101c3b3*/
          input: fields._Mypair._Myval2._Myfirst[2].Data,
          length: fields._Mypair._Myval2._Myfirst[2].Length,
          output: &v8->preauthBlob);
        base64<unsigned char,std::char_traits<unsigned char>>::decode( /*0x14101c3c9*/
          input: fields._Mypair._Myval2._Myfirst[3].Data,
          length: fields._Mypair._Myval2._Myfirst[3].Length,
          output: &v8->authBlob);
        v11 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14101c3d5*/
        v12 = v11->onInternalError._Mystorage._Ptrs[0][101].__vftable; /*0x14101c3dd*/
        v14 = 0; /*0x14101c3e7*/
        if ( v10 != nullptr ) /*0x14101c3f0*/
          _InterlockedIncrement((volatile signed __int32 *)&v10->_Uses); /*0x14101c3f2*/
        *(_QWORD *)&v14 = v8; /*0x14101c3f6*/
        *((_QWORD *)&v14 + 1) = v10; /*0x14101c3fb*/
        ((void (__fastcall *)(Luau::InternalErrorReporter *, __int128 *))v12)(a1: v11, a2: &v14); /*0x14101c408*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&earlyAuthData); /*0xf1c0000000000014*/
      }
      if ( v10 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Uses, 0xFFFFFFFF) == 1 ) /*0x14101c41b*/
      {
        v10->_Destroy(this: v10); /*0x14101c423*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14101c42d*/
          v10->_Delete_this(this: v10); /*0x14101c435*/
      }
      Myfirst = fields._Mypair._Myval2._Myfirst; /*0x14101c438*/
    }
    if ( Myfirst != nullptr ) /*0x14101c440*/
    {
      v13 = Myfirst; /*0x14101c44e*/
      if ( (((char *)fields._Mypair._Myval2._Myend - (char *)Myfirst) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x14101c458*/
      {
        Myfirst = (RBX::StringView *)Myfirst[-1].Length; /*0x14101c45e*/
        if ( (unsigned __int64)((char *)v13 - (char *)Myfirst - 8) > 0x1F ) /*0x14101c46d*/
          _invalid_parameter_noinfo_noreturn(); /*0x14101c46f*/
      }
      operator delete(ptr: Myfirst); /*0x14101c476*/
    }
  }
  __unwind
  {
    std::vector<Luau::Location>::~vector<Luau::Location>(this: (RBX::DenseHashMap<RBX::Graphics::ShaderProgram *,VkPipeline_T *,boost::hash<RBX::Graphics::ShaderProgram *>,std::equal_to<RBX::Graphics::ShaderProgram *> > *)&fields); /*0xf1c0000000000008*/
  }
}

// Address: 0x14101c4a0 | Name: ?updateMonotonicClockDifferential@Client@Network@RBX@@UEAAX_K_J@Z
void __fastcall RBX::Network::Client::updateMonotonicClockDifferential(
        RBX::Network::Client *this,
        unsigned __int64 receiveTimeMicro,
        __int64 updateDifferentialMS)
{
  RBX::DataModel *v5; // rax
  __int128 v6; // [rsp+20h] [rbp-58h]
  std::function<void __cdecl(RBX::DataModel *)> v7; // [rsp+30h] [rbp-48h] BYREF

  v5 = RBX::DataModel::get(context: this); /*0x14101c4b0*/
  if ( v5 != nullptr ) /*0x14101c4b8*/
  {
    *(_QWORD *)&v6 = receiveTimeMicro; /*0x14101c4c1*/
    v7._Mystorage._Ptrs[0] = (std::_Func_base<void,RBX::DataModel *> *)std::_Func_impl_no_alloc__lambda_86124e40cc81df3b35a06855c5c0c579__void_RBX::DataModel___::_vftable_; /*0x14101c4c6*/
    *((_QWORD *)&v6 + 1) = updateDifferentialMS; /*0x14101c4d5*/
    v7._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::DataModel *> *)&v7; /*0x14101c4e5*/
    *(_OWORD *)&v7._Mystorage._Ptrs[1] = v6; /*0x14101c4ed*/
    RBX::DataModel::submitTask(this: v5, task: &v7, taskType: (RBX::DMTaskType)1); /*0x14101c4f2*/
  }
}

// Address: 0x14101c510 | Name: ?updateServerConnectionState@Client@Network@RBX@@AEAAXPEBDW4ConnectionState@ServerConnection@123@0_N@Z
void __fastcall RBX::Network::Client::updateServerConnectionState(
        RBX::Network::Client *this,
        const char *serverAddress,
        RBX::Network::Client::ServerConnection::ConnectionState state,
        const char *metric,
        bool takeLock)
{
  RBX::Network::Client::ServerConnection *Myfirst; // r9
  unsigned int v10; // edi
  __int64 v11; // r8
  unsigned __int64 v12; // rbx
  RBX::Network::Client::ServerConnection *v13; // r10
  RBX::Network::Client::ServerConnection *Ptr; // rax
  char *v15; // rdx
  char v16; // cl
  __int64 v17; // rdx
  const char *v18; // rax
  int v19; // ecx
  int v20; // edx
  __int64 v21; // rdi
  RBX::Network::Client::ServerConnection *v22; // rcx
  char addressBuffer[1040]; // [rsp+30h] [rbp-428h] BYREF

  if ( takeLock ) /*0x14101c543*/
    RBX::InstrumentedMutex<std::mutex>::lock(this: &this->connectionStateAndJoinDataMutex); /*0x14101c54c*/
  Myfirst = this->serverConnections._Mypair._Myval2._Myfirst; /*0x14101c551*/
  v10 = 0; /*0x14101c56f*/
  if ( this->serverConnections._Mypair._Myval2._Mylast - Myfirst != 0 )
  {
    v11 = 0; /*0x14101c590*/
    v12 = -1; /*0x14101c593*/
    while ( 1 ) /*0x14101c5a8*/
    {
      v13 = &Myfirst[v11]; /*0x14101c5a8*/
      Ptr = v13; /*0x14101c5ab*/
      if ( v13->address._Mypair._Myval2._Myres >= 0x10 ) /*0x14101c5b3*/
        Ptr = (RBX::Network::Client::ServerConnection *)v13->address._Mypair._Myval2._Bx._Ptr; /*0x14101c5b5*/
      v15 = (char *)(addressBuffer - (char *)Ptr); /*0x14101c5bd*/
      do /*0x14101c5cc*/
      {
        v16 = Ptr->address._Mypair._Myval2._Bx._Buf[0]; /*0x14101c5c0*/
        Ptr->address._Mypair._Myval2._Bx._Buf[(_QWORD)v15] = Ptr->address._Mypair._Myval2._Bx._Buf[0]; /*0x14101c5c3*/
        Ptr = (RBX::Network::Client::ServerConnection *)((char *)Ptr + 1); /*0x14101c5c6*/
      }
      while ( v16 != 0 ); /*0x14101c5cc*/
      v17 = -1; /*0x14101c5d3*/
      do /*0x14101c5dd*/
        ++v17; /*0x14101c5d6*/
      while ( addressBuffer[v17] != 0 ); /*0x14101c5dd*/
      addressBuffer[(int)v17] = 124; /*0x14101c5e8*/
      Itoa(value: v13->port, result: &addressBuffer[(int)v17 + 1], base: 10); /*0x14101c5ff*/
      v18 = serverAddress; /*0x14101c609*/
      do /*0x14101c621*/
      {
        v19 = (unsigned __int8)v18[addressBuffer - serverAddress]; /*0x14101c613*/
        v20 = *(unsigned __int8 *)v18 - v19; /*0x14101c618*/
        if ( v20 != 0 ) /*0x14101c61a*/
          break; /*0x14101c61a*/
        ++v18; /*0x14101c61c*/
      }
      while ( v19 != 0 ); /*0x14101c621*/
      if ( v20 == 0 ) /*0x14101c625*/
        break; /*0x14101c625*/
      Myfirst = this->serverConnections._Mypair._Myval2._Myfirst; /*0x14101c627*/
      v11 = ++v10; /*0x14101c63d*/
      if ( v10 >= (unsigned __int64)(this->serverConnections._Mypair._Myval2._Mylast - Myfirst) ) /*0x14101c654*/
        goto LABEL_25; /*0x14101c654*/
    }
    if ( DFLog::NetworkTrace != 0 )
      FLog::FastLogFormatted(
        level: DFLog::NetworkTrace,
        message: "[DFLog::NetworkTrace] updateServerConnectionState::: sc(%s).old_state = %d -> new_state = %d :: returning false",
        addressBuffer,
        this->serverConnections._Mypair._Myval2._Myfirst[v10].state,
        state);
    v21 = v10; /*0x14101c6a5*/
    this->serverConnections._Mypair._Myval2._Myfirst[v21].state = state; /*0x14101c6a9*/
    do /*0x14101c6b7*/
      ++v12; /*0x14101c6b0*/
    while ( metric[v12] != 0 ); /*0x14101c6b7*/
    std::string::assign( /*0x14101c6cd*/
      this: &this->serverConnections._Mypair._Myval2._Myfirst[v21].reportMetric,
      _Ptr: metric,
      _Count: v12);
    v22 = &this->serverConnections._Mypair._Myval2._Myfirst[v21]; /*0x14101c6d9*/
    if ( v22->state == ConnectionState_Connected ) /*0x14101c6e0*/
    {
      if ( v22->address._Mypair._Myval2._Myres >= 0x10 ) /*0x14101c6e7*/
        v22 = (RBX::Network::Client::ServerConnection *)v22->address._Mypair._Myval2._Bx._Ptr; /*0x14101c6e9*/
      RBX::RbxDbgInfo::SetServerIP(s: v22->address._Mypair._Myval2._Bx._Buf); /*0x14101c6ec*/
      this->wasConnected = true; /*0x14101c6f1*/
    }
  }
LABEL_25:
  if ( takeLock ) /*0x14101c730*/
    Mtx_unlock_0(a1: (_Mtx_t)&this->connectionStateAndJoinDataMutex); /*0x14101c739*/
}

// Address: 0x141092bf0 | Name: ??$fastDynamicCast@VClient@Network@RBX@@@DescribedBase@Reflection@RBX@@QEAAPEAVClient@Network@2@XZ
RBX::Network::Client *__fastcall RBX::Reflection::DescribedBase::fastDynamicCast<RBX::Network::Client>(
        RBX::Reflection::DescribedBase *this)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::ClassRegistrar<RBX::Network::Client,1> *v3; // rax
  unsigned int v4; // r8d
  unsigned int descendantCount; // edx
  RBX::Network::Client *result; // rax

  descriptor = this->descriptor; /*0x141092bfa*/
  v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(); /*0x141092c01*/
  v4 = descriptor->index - v3->desc.index; /*0x141092c1a*/
  descendantCount = v3->desc.descendantCount; /*0x141092c1d*/
  result = nullptr; /*0x141092c24*/
  if ( v4 <= descendantCount ) /*0x141092c29*/
    return (RBX::Network::Client *)this; /*0x141092c29*/
  return result; /*0x141092c2d*/
}

// END Client part 1/1, 64 functions
