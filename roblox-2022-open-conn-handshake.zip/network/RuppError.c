// RuppError -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x1410ae740 | Name: ?toString@RuppError@Rupp@Network@RBX@@SAPEBDW4ErrorCode@1234@@Z
const char *__fastcall RBX::Network::Rupp::RuppError::toString(RBX::Network::Rupp::RuppError::ErrorCode code)
{
  const char *result; // rax

  switch ( code ) /*0x1410ae75b*/
  {
    case 1: /*0x1410ae75b*/
      result = "Unable to read bitstream"; /*0x1410ae75d*/
      break; /*0x1410ae764*/
    case 2: /*0x1410ae75b*/
      result = "Invalid protocol"; /*0x1410ae765*/
      break; /*0x1410ae76c*/
    case 3: /*0x1410ae75b*/
      result = "Invalid flags"; /*0x1410ae76d*/
      break; /*0x1410ae774*/
    case 4: /*0x1410ae75b*/
      result = "Invalid header length"; /*0x1410ae775*/
      break; /*0x1410ae77c*/
    case 5: /*0x1410ae75b*/
      result = "Invalid Tlv type"; /*0x1410ae77d*/
      break; /*0x1410ae784*/
    case 6: /*0x1410ae75b*/
      result = "Invalid Tlv length"; /*0x1410ae785*/
      break; /*0x1410ae78c*/
    case 7: /*0x1410ae75b*/
      result = "Duplicate Tlv"; /*0x1410ae78d*/
      break; /*0x1410ae794*/
    case 8: /*0x1410ae75b*/
      result = "Tlv not found"; /*0x1410ae795*/
      break; /*0x1410ae79c*/
    case 9: /*0x1410ae75b*/
      result = "Invalid token value"; /*0x1410ae79d*/
      break; /*0x1410ae7a4*/
    case 10: /*0x1410ae75b*/
      result = "Invalid endpoint address"; /*0x1410ae7a5*/
      break; /*0x1410ae7ac*/
    default:
      result = "Default rupp error"; /*0x1410ae7ad*/
      break; /*0x1410ae7ad*/
  }
  return result; /*0x1410ae764*/
}

// END RuppError part 1/1, 1 functions
