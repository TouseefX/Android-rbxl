// Rupp -- 2022 Studio + full PDB
// tier 3, 14 functions


// Address: 0x140725090 | Name: ??_GIpv4Tlv@Rupp@Network@RBX@@UEAAPEAXI@Z
webrtc::rtcp::RtcpPacket *__fastcall RBX::Network::Rupp::Ipv4Tlv::`scalar deleting destructor'(
        webrtc::rtcp::RtcpPacket *this,
        char a2)
{
  if ( (a2 & 1) != 0 ) /*0x14072509c*/
    operator delete(ptr: this); /*0x1407250a3*/
  return this; /*0x1407250ab*/
}

// Address: 0x1410aea30 | Name: ??0Rupp@0Network@RBX@@QEAA@W4RuppRakNetFlags@012@@Z
RBX::Network::Rupp::Rupp *__fastcall RBX::Network::Rupp::Rupp::Rupp(
        RBX::Network::Rupp::Rupp *this,
        RBX::Network::Rupp::RuppRakNetFlags setFlag)
{
  RakNet::BitStream *p_cachedSerialization; // rcx
  RBX::Network::Rupp::Rupp *result; // rax
  __int64 v5; // [rsp+30h] [rbp-18h]

  LOWORD(v5) = 256; /*0x1410aea49*/
  BYTE2(v5) = setFlag; /*0x1410aea50*/
  this->ruppInfo.tokenInBitstream = 0u; /*0x1410aea59*/
  *(_QWORD *)&this->ruppInfo.tokenType = v5; /*0x1410aea62*/
  this->typeLengthValues._Mypair._Myval2._Myfirst = nullptr; /*0x1410aea67*/
  this->typeLengthValues._Mypair._Myval2._Mylast = nullptr; /*0x1410aea6b*/
  this->typeLengthValues._Mypair._Myval2._Myend = nullptr; /*0x1410aea6f*/
  this->cachedSerializationIsValid = false; /*0x1410aea73*/
  p_cachedSerialization = &this->cachedSerialization; /*0x1410aea76*/
  __wind /*0xf1c000000000001c*/
  {
    RakNet::BitStream::BitStream(this: p_cachedSerialization); /*0x1410aea7a*/
    this->tokenValueCacheLocation = -1; /*0x1410aea7f*/
    result = this; /*0x1410aea89*/
  }
  __unwind
  {
    std::vector<std::unique_ptr<webrtc::JsepIceCandidate>>::~vector<std::unique_ptr<webrtc::JsepIceCandidate>>(this: (std::vector<std::unique_ptr<webrtc::FieldTrialListWrapper>> *)&this->typeLengthValues); /*0x1431ec57b*/
  }
  return result; /*0x1410aea8c*/
}

// Address: 0x1410aeaa0 | Name: ?addIpv4EndpointTlv@Rupp@1Network@RBX@@QEAA?AW4ErrorCode@RuppError@123@Uin_addr@@G@Z
RBX::Network::Rupp::RuppError::ErrorCode __fastcall RBX::Network::Rupp::Rupp::addIpv4EndpointTlv(
        RBX::Network::Rupp::Rupp *this,
        in_addr setIP,
        unsigned __int16 setPort)
{
  RBX::Network::Rupp::Ipv4Tlv *v6; // rax
  RBX::Network::Rupp::Rupp *v7; // rcx
  RBX::Network::Rupp::Ipv4Tlv *v9; // [rsp+20h] [rbp-18h]
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> tlv; // [rsp+58h] [rbp+20h] BYREF

  v6 = (RBX::Network::Rupp::Ipv4Tlv *)operator new(size: 0x10u); /*0x1410aeabd*/
  __wind /*0xf1c000000000001c*/
  {
    v9 = v6; /*0x1410aeac2*/
    if ( v6 != nullptr ) /*0x1410aeaca*/
      v6 = RBX::Network::Rupp::Ipv4Tlv::Ipv4Tlv(this: v6, setIP, setPort); /*0x1410aead5*/
    tlv._Mypair._Myval2 = v6; /*0x1410aeadb*/
    v7 = this; /*0x1410aeae5*/
  }
  __unwind
  {
    operator delete(ptr: v9); /*0x1431854d2*/
  }
  return RBX::Network::Rupp::Rupp::addTlv(this: v7, (std::unique_ptr<RBX::Network::Rupp::TypeLengthValue>)&tlv); /*0x1410aeaed*/
}

// Address: 0x1410aeb00 | Name: ?addIpv6EndpointTlv@Rupp@1Network@RBX@@QEAA?AW4ErrorCode@RuppError@123@Uin6_addr@@G@Z
RBX::Network::Rupp::RuppError::ErrorCode __fastcall RBX::Network::Rupp::Rupp::addIpv6EndpointTlv(
        RBX::Network::Rupp::Rupp *this,
        in6_addr *setIP,
        unsigned __int16 setPort)
{
  RBX::Network::Rupp::Ipv6Tlv *v6; // rax
  RBX::Network::Rupp::Rupp *v7; // rcx
  RBX::Network::Rupp::Ipv6Tlv *v9; // [rsp+20h] [rbp-28h]
  in6_addr v10; // [rsp+30h] [rbp-18h] BYREF
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> tlv; // [rsp+68h] [rbp+20h] BYREF

  v6 = (RBX::Network::Rupp::Ipv6Tlv *)operator new(size: 0x20u); /*0x1410aeb1e*/
  __wind /*0xf1c000000000001c*/
  {
    v9 = v6; /*0x1410aeb23*/
    if ( v6 != nullptr ) /*0x1410aeb2b*/
    {
      v10 = *setIP; /*0x1410aeb30*/
      v6 = RBX::Network::Rupp::Ipv6Tlv::Ipv6Tlv(this: v6, setIP: &v10, setPort); /*0x1410aeb41*/
    }
    tlv._Mypair._Myval2 = v6; /*0x1410aeb47*/
    v7 = this; /*0x1410aeb51*/
  }
  __unwind
  {
    operator delete(ptr: v9); /*0x1431938c2*/
  }
  return RBX::Network::Rupp::Rupp::addTlv(this: v7, (std::unique_ptr<RBX::Network::Rupp::TypeLengthValue>)&tlv); /*0x1410aeb59*/
}

// Address: 0x1410aeb70 | Name: ?addTlv@Rupp@1Network@RBX@@AEAA?AW4ErrorCode@RuppError@123@V?$unique_ptr@VTypeLengthValue@Rupp@Network@RBX@@U?$default_delete@VTypeLengthValue@Rupp@Network@RBX@@@std@@@std@@@Z
__int64 __fastcall RBX::Network::Rupp::Rupp::addTlv(
        RBX::Network::Rupp::Rupp *this,
        std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> tlv)
{
  RBX::Network::Rupp::TypeLengthValue::TlvType v4; // al
  __int64 result; // rax
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *Mylast; // rdx
  RBX::Network::Rupp::TypeLengthValue_vtbl *v7; // rax

  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000024*/
  v4 = (*((unsigned __int8 (__fastcall **)(RBX::Network::Rupp::TypeLengthValue_vtbl *))tlv._Mypair._Myval2->dtr_TypeLengthValue /*0x1410aeb8b*/
        + 1))(a1: tlv._Mypair._Myval2->__vftable);
  if ( RBX::Network::Rupp::Rupp::getTlvIndex(this, type: v4) == -1 ) /*0x1410aeb9c*/
  {
    this->cachedSerializationIsValid = false; /*0x1410aebc0*/
    Mylast = this->typeLengthValues._Mypair._Myval2._Mylast; /*0x1410aebc8*/
    if ( Mylast == this->typeLengthValues._Mypair._Myval2._Myend ) /*0x1410aebd0*/
    {
      std::vector<std::unique_ptr<webrtc::RtpVideoSenderInterface>>::_Emplace_reallocate<std::unique_ptr<webrtc::RtpVideoSenderInterface>>( /*0x1410aebe9*/
        this: (std::vector<std::unique_ptr<webrtc::FieldTrialListWrapper>> *)&this->typeLengthValues,
        _Whereptr: (std::unique_ptr<webrtc::FieldTrialListWrapper> *const)Mylast,
        <_Val_0>: (std::unique_ptr<webrtc::FieldTrialListWrapper> *)tlv._Mypair._Myval2);
    }
    else
    {
      v7 = tlv._Mypair._Myval2->__vftable; /*0x1410aebd2*/
      tlv._Mypair._Myval2->__vftable = nullptr; /*0x1410aebd5*/
      Mylast->_Mypair._Myval2 = (RBX::Network::Rupp::TypeLengthValue *)v7; /*0x1410aebdc*/
      ++this->typeLengthValues._Mypair._Myval2._Mylast; /*0x1410aebdf*/
    }
    if ( tlv._Mypair._Myval2->__vftable != nullptr ) /*0x1410aebf5*/
      (*(void (__fastcall **)(RBX::Network::Rupp::TypeLengthValue_vtbl *, __int64))tlv._Mypair._Myval2->dtr_TypeLengthValue)( /*0x1410aebff*/
        a1: tlv._Mypair._Myval2->__vftable,
        a2: 1);
    result = 0; /*0x1410aec01*/
    if ( __eh34_unwind(0) ) /*0xf1c0000000000004*/
    {
unwind_state_0:
      RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: (std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *)tlv._Mypair._Myval2); /*0xf1c0000000000008*/
      __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000000c*/
    }
    __eh34_exit_wind_state(0, -1); /*0xf1c0000000000010*/
  }
  else
  {
    if ( __eh34_unwind(0) ) /*0xf1c0000000000018*/
      goto unwind_state_0; /*0xf1c0000000000018*/
    __eh34_exit_wind_state(0, -1); /*0xf1c000000000001c*/
    if ( tlv._Mypair._Myval2->__vftable != nullptr ) /*0x1410aeba4*/
      (*(void (__fastcall **)(RBX::Network::Rupp::TypeLengthValue_vtbl *, __int64))tlv._Mypair._Myval2->dtr_TypeLengthValue)( /*0x1410aebae*/
        a1: tlv._Mypair._Myval2->__vftable,
        a2: 1);
    return 7; /*0x1410aebb0*/
  }
  return result; /*0x1410aebb5*/
}

// Address: 0x1410aec10 | Name: ?addTokenTlv@Rupp@1Network@RBX@@QEAA?AW4ErrorCode@RuppError@123@AEAUToken@TokenTlv@123@@Z
__int64 __fastcall RBX::Network::Rupp::Rupp::addTokenTlv(
        RBX::Network::Rupp::Rupp *this,
        RBX::Network::Rupp::TokenTlv::Token *token)
{
  RBX::Network::Rupp::TokenTlv *v4; // rax
  RBX::Network::Rupp::Rupp *v5; // rcx
  RBX::Network::Rupp::TokenTlv::Token v7; // [rsp+20h] [rbp-28h] BYREF
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> tlv; // [rsp+60h] [rbp+18h] BYREF
  RBX::Network::Rupp::TokenTlv *v9; // [rsp+68h] [rbp+20h]

  v4 = (RBX::Network::Rupp::TokenTlv *)operator new(size: 0x20u); /*0x1410aec25*/
  __wind /*0xf1c000000000001c*/
  {
    v9 = v4; /*0x1410aec2a*/
    if ( v4 != nullptr ) /*0x1410aec32*/
    {
      v7 = *token; /*0x1410aec37*/
      v4 = RBX::Network::Rupp::TokenTlv::TokenTlv(this: v4, setToken: &v7); /*0x1410aec4c*/
    }
    tlv._Mypair._Myval2 = v4; /*0x1410aec52*/
    v5 = this; /*0x1410aec5c*/
  }
  __unwind
  {
    operator delete(ptr: v9); /*0x143170e12*/
  }
  return RBX::Network::Rupp::Rupp::addTlv(this: v5, (std::unique_ptr<RBX::Network::Rupp::TypeLengthValue>)&tlv); /*0x1410aec64*/
}

// Address: 0x1410aec70 | Name: ?deserialize@Rupp@1Network@RBX@@SA?AW4ErrorCode@RuppError@123@AEAURuppInfo@1123@AEAVBitStream@RakNet@@AEAG@Z
__int64 __fastcall RBX::Network::Rupp::Rupp::deserialize(
        RBX::Network::Rupp::Rupp::RuppInfo *ruppInfoObject,
        RakNet::BitStream *b,
        unsigned __int8 *ruppHeaderLength)
{
  unsigned int readOffset; // r14d
  unsigned int v8; // eax
  int v9; // edi
  std::pair<enum RBX::Network::Rupp::TokenTlv::TokenType,RBX::StringView> *TokenInBitstreamIfNext; // rax
  std::pair<enum RBX::Network::Rupp::TokenTlv::TokenType,RBX::StringView> v11; // [rsp+20h] [rbp-38h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+60h] [rbp+8h] BYREF

  readOffset = b->readOffset; /*0x1410aec82*/
  if ( RakNet::BitStream::ReadBits( /*0x1410aeca6*/
         this: b,
         inOutByteArray: (unsigned __int8 *)&ruppInfoObject->protocol,
         numberOfBitsToRead: 8u,
         alignBitsToRight: true) == 0 )
    return 1; /*0x1410aeca6*/
  if ( ruppInfoObject->protocol != RakNet ) /*0x1410aecb0*/
    return 2; /*0x1410aecb7*/
  if ( RakNet::BitStream::ReadBits( /*0x1410aecd3*/
         this: b,
         inOutByteArray: &ruppInfoObject->flag,
         numberOfBitsToRead: 8u,
         alignBitsToRight: true) == 0 )
    return 1; /*0x1410aecd3*/
  if ( !RakNet::BitStream::IsNetworkOrder() ) /*0x1410aecd9*/
  {
    if ( RakNet::BitStream::ReadBits(this: b, &inOutByteArray, numberOfBitsToRead: 0x10u, alignBitsToRight: true) != 0 ) /*0x1410aecfa*/
    {
      RBX::Network::NetworkStream::ReverseBytes( /*0x1410aed0a*/
        inByteArray: &inOutByteArray,
        inOutByteArray: ruppHeaderLength,
        length: 2u);
      goto LABEL_9; /*0x1410aed0f*/
    }
    return 1; /*0x1410aed74*/
  }
  if ( RakNet::BitStream::ReadBits( /*0x1410aed1b*/
         this: b,
         inOutByteArray: ruppHeaderLength,
         numberOfBitsToRead: 0x10u,
         alignBitsToRight: true) == 0 )
    return 1; /*0x1410aed1b*/
LABEL_9:
  v8 = *(unsigned __int16 *)ruppHeaderLength; /*0x1410aed1d*/
  if ( v8 <= 4 ) /*0x1410aed23*/
    return 4; /*0x1410aed25*/
  v9 = *(unsigned __int16 *)ruppHeaderLength; /*0x1410aed33*/
  if ( FFlag::RuppTokEn4.value ) /*0x1410aed35*/
  {
    TokenInBitstreamIfNext = RBX::Network::Rupp::TokenTlv::findTokenInBitstreamIfNext(result: &v11, b); /*0x1410aed3f*/
    ruppInfoObject->tokenType = TokenInBitstreamIfNext->first; /*0x1410aed47*/
    ruppInfoObject->tokenInBitstream = TokenInBitstreamIfNext->second; /*0x1410aed58*/
    b->readOffset = readOffset + 8 * v9; /*0x1410aed5c*/
  }
  else
  {
    b->readOffset = readOffset + 8 * v8; /*0x1410aed6d*/
  }
  return 0; /*0x1410aed79*/
}

// Address: 0x1410aed90 | Name: ?getHeaderTotalByteLength@Rupp@1Network@RBX@@QEBAGXZ
__int64 __fastcall RBX::Network::Rupp::Rupp::getHeaderTotalByteLength(RBX::Network::Rupp::Rupp *this)
{
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *Mylast; // rsi
  unsigned __int16 v2; // di
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *i; // rbx
  unsigned __int8 v4; // al

  Mylast = this->typeLengthValues._Mypair._Myval2._Mylast; /*0x1410aed9f*/
  v2 = 4; /*0x1410aeda3*/
  for ( i = this->typeLengthValues._Mypair._Myval2._Myfirst; i != Mylast; v2 += v4 + 2 ) /*0x1410aedaf*/
  {
    v4 = i->_Mypair._Myval2->getValueByteLength(this: i->_Mypair._Myval2); /*0x1410aedb7*/
    ++i; /*0x1410aedbd*/
  }
  return v2; /*0x1410aedd5*/
}

// Address: 0x1410aede0 | Name: ?getTlvIndex@Rupp@1Network@RBX@@AEBAHW4TlvType@TypeLengthValue@123@@Z
__int64 __fastcall RBX::Network::Rupp::Rupp::getTlvIndex(
        RBX::Network::Rupp::Rupp *this,
        RBX::Network::Rupp::TypeLengthValue::TlvType type)
{
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *Myfirst; // rbx

  Myfirst = this->typeLengthValues._Mypair._Myval2._Myfirst; /*0x1410aedef*/
  if ( Myfirst >= this->typeLengthValues._Mypair._Myval2._Mylast ) /*0x1410aedfd*/
    return 0xFFFFFFFFLL; /*0x1410aee18*/
  while ( (unsigned __int8)Myfirst->_Mypair._Myval2->getTlvType(this: Myfirst->_Mypair._Myval2) != type ) /*0x1410aee0c*/
  {
    if ( ++Myfirst >= this->typeLengthValues._Mypair._Myval2._Mylast ) /*0x1410aee16*/
      return 0xFFFFFFFFLL; /*0x1410aee16*/
  }
  return (unsigned int)(Myfirst - this->typeLengthValues._Mypair._Myval2._Myfirst); /*0x1410aee1d*/
}

// Address: 0x1410aee50 | Name: ?serialize@Rupp@1Network@RBX@@QEAAXAEAVBitStream@RakNet@@@Z
void __fastcall RBX::Network::Rupp::Rupp::serialize(RBX::Network::Rupp::Rupp *this, RakNet::BitStream *b)
{
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *Mylast; // r14
  __int16 v5; // bp
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *i; // rbx
  unsigned __int8 v7; // al
  unsigned __int8 *p_inByteArray; // rdx
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *v9; // rbp
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *j; // rbx
  __int16 inByteArray; // [rsp+50h] [rbp+8h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+60h] [rbp+18h] BYREF

  if ( this->cachedSerializationIsValid ) /*0x1410aee59*/
  {
    RakNet::BitStream::ResetReadPointer(this: &this->cachedSerialization); /*0x1410aee69*/
    RakNet::BitStream::Write(this: b, bitStream: &this->cachedSerialization); /*0x1410aee7d*/
  }
  else
  {
    RakNet::BitStream::ResetWritePointer(this: &this->cachedSerialization); /*0x1410aee95*/
    RakNet::BitStream::WriteBits( /*0x1410aeeab*/
      this: &this->cachedSerialization,
      inByteArray: (unsigned __int8 *)&this->ruppInfo.protocol,
      numberOfBitsToWrite: 8u,
      rightAlignedBits: true);
    RakNet::BitStream::WriteBits( /*0x1410aeec1*/
      this: &this->cachedSerialization,
      inByteArray: &this->ruppInfo.flag,
      numberOfBitsToWrite: 8u,
      rightAlignedBits: true);
    Mylast = this->typeLengthValues._Mypair._Myval2._Mylast; /*0x1410aeec6*/
    v5 = 4; /*0x1410aeeca*/
    for ( i = this->typeLengthValues._Mypair._Myval2._Myfirst; i != Mylast; v5 += v7 + 2 ) /*0x1410aeed6*/
    {
      v7 = i->_Mypair._Myval2->getValueByteLength(this: i->_Mypair._Myval2); /*0x1410aeee6*/
      ++i; /*0x1410aeeec*/
    }
    inByteArray = v5; /*0x1410aeefc*/
    if ( RakNet::BitStream::IsNetworkOrder() ) /*0x1410aef01*/
    {
      p_inByteArray = (unsigned __int8 *)&inByteArray; /*0x1410aef2b*/
    }
    else
    {
      RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 2u); /*0x1410aef1f*/
      p_inByteArray = &inOutByteArray; /*0x1410aef24*/
    }
    RakNet::BitStream::WriteBits( /*0x1410aef3d*/
      this: &this->cachedSerialization,
      inByteArray: p_inByteArray,
      numberOfBitsToWrite: 0x10u,
      rightAlignedBits: true);
    v9 = this->typeLengthValues._Mypair._Myval2._Mylast; /*0x1410aef42*/
    for ( j = this->typeLengthValues._Mypair._Myval2._Myfirst; j != v9; ++j ) /*0x1410aef4d*/
    {
      LOBYTE(inByteArray) = j->_Mypair._Myval2->getTlvType(this: j->_Mypair._Myval2); /*0x1410aef65*/
      RakNet::BitStream::WriteBits( /*0x1410aef6f*/
        this: &this->cachedSerialization,
        (unsigned __int8 *)&inByteArray,
        numberOfBitsToWrite: 8u,
        rightAlignedBits: true);
      inOutByteArray = j->_Mypair._Myval2->getValueByteLength(this: j->_Mypair._Myval2); /*0x1410aef89*/
      RakNet::BitStream::WriteBits( /*0x1410aef93*/
        this: &this->cachedSerialization,
        inByteArray: &inOutByteArray,
        numberOfBitsToWrite: 8u,
        rightAlignedBits: true);
      if ( j->_Mypair._Myval2->getTlvType(this: j->_Mypair._Myval2) == TokenTlv ) /*0x1410aefa3*/
        this->tokenValueCacheLocation = this->cachedSerialization.numberOfBitsUsed + 8; /*0x1410aefab*/
      j->_Mypair._Myval2->serialize(this: j->_Mypair._Myval2, a2: &this->cachedSerialization); /*0x1410aefbb*/
    }
    RakNet::BitStream::ResetReadPointer(this: &this->cachedSerialization); /*0x1410aefcb*/
    RakNet::BitStream::Write(this: b, bitStream: &this->cachedSerialization); /*0x1410aefd7*/
    this->cachedSerializationIsValid = true; /*0x1410aefe6*/
  }
}

// Address: 0x1410af000 | Name: ?setFlag@Rupp@1Network@RBX@@QEAAXW4RuppRakNetFlags@123@_N@Z
void __fastcall RBX::Network::Rupp::Rupp::setFlag(
        RBX::Network::Rupp::Rupp *this,
        RBX::Network::Rupp::RuppRakNetFlags flagEnum,
        bool value)
{
  unsigned __int8 flag; // al

  flag = this->ruppInfo.flag; /*0x1410af000*/
  this->cachedSerializationIsValid = false; /*0x1410af004*/
  if ( value ) /*0x1410af00b*/
    this->ruppInfo.flag = flagEnum | flag; /*0x1410af00f*/
  else
    this->ruppInfo.flag = flag & ~flagEnum; /*0x1410af017*/
}

// Address: 0x1410af020 | Name: ?updateTokenTlv@Rupp@1Network@RBX@@QEAA?AW4ErrorCode@RuppError@123@W4TokenType@TokenTlv@123@VStringView@3@@Z
RBX::Network::Rupp::RuppError::ErrorCode __fastcall RBX::Network::Rupp::Rupp::updateTokenTlv(
        RBX::Network::Rupp::Rupp *this,
        RBX::Network::Rupp::TokenTlv::TokenType setType,
        RBX::StringView *setTokenValue)
{
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *Myfirst; // rbx
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *v8; // rcx
  __int64 v9; // rbx
  RBX::Network::Rupp::TypeLengthValue *Myval2; // rbx
  RBX::StringView v11; // xmm0
  RBX::StringView v12; // [rsp+20h] [rbp-18h] BYREF

  Myfirst = this->typeLengthValues._Mypair._Myval2._Myfirst; /*0x1410af034*/
  if ( Myfirst >= this->typeLengthValues._Mypair._Myval2._Mylast ) /*0x1410af045*/
    return TLV_NOT_FOUND; /*0x1410af045*/
  while ( Myfirst->_Mypair._Myval2->getTlvType(this: Myfirst->_Mypair._Myval2) != TokenTlv ) /*0x1410af052*/
  {
    if ( ++Myfirst >= this->typeLengthValues._Mypair._Myval2._Mylast ) /*0x1410af05c*/
      return TLV_NOT_FOUND; /*0x1410af05c*/
  }
  v8 = this->typeLengthValues._Mypair._Myval2._Myfirst; /*0x1410af078*/
  v9 = Myfirst - v8; /*0x1410af07f*/
  if ( (int)v9 < 0 ) /*0x1410af085*/
    return TLV_NOT_FOUND; /*0x1410af05e*/
  if ( setTokenValue->Length != 16 ) /*0x1410af08c*/
    return INVALID_TOKEN; /*0x1410af08e*/
  Myval2 = v8[(int)v9]._Mypair._Myval2; /*0x1410af098*/
  if ( setType == LOBYTE(Myval2[1].__vftable) ) /*0x1410af0a0*/
  {
    v12 = *setTokenValue; /*0x1410af0ad*/
    if ( RBX::Network::Rupp::TokenTlv::compareEqual(this: (RBX::Network::Rupp::TokenTlv *)Myval2, cmpToken: &v12) ) /*0x1410af0b2*/
      return 0; /*0x1410af0bb*/
  }
  v11 = *setTokenValue; /*0x1410af0bf*/
  this->cachedSerializationIsValid = false; /*0x1410af0c2*/
  LOBYTE(Myval2[1].__vftable) = setType; /*0x1410af0ce*/
  v12 = v11; /*0x1410af0d2*/
  return RBX::Network::Rupp::TokenTlv::setTokenValue(this: (RBX::Network::Rupp::TokenTlv *)Myval2, setToken: &v12); /*0x1410af063*/
}

// Address: 0x1410af0e0 | Name: ?updateTokenTlvValue@Rupp@1Network@RBX@@QEAA?AW4ErrorCode@RuppError@123@VStringView@3@@Z
RBX::Network::Rupp::RuppError::ErrorCode __fastcall RBX::Network::Rupp::Rupp::updateTokenTlvValue(
        RBX::Network::Rupp::Rupp *this,
        RBX::StringView *setTokenValue)
{
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *Myfirst; // rbx
  std::unique_ptr<RBX::Network::Rupp::TypeLengthValue> *v6; // rcx
  __int64 v7; // rbx
  unsigned int tokenValueCacheLocation; // edx
  RBX::Network::Rupp::TokenTlv *Myval2; // rbp
  unsigned int numberOfBitsUsed; // ebx
  RakNet::BitStream *p_cachedSerialization; // rdi
  RBX::StringView v12; // [rsp+20h] [rbp-18h] BYREF

  Myfirst = this->typeLengthValues._Mypair._Myval2._Myfirst; /*0x1410af0ef*/
  if ( Myfirst >= this->typeLengthValues._Mypair._Myval2._Mylast ) /*0x1410af0fd*/
    return TLV_NOT_FOUND; /*0x1410af0fd*/
  while ( Myfirst->_Mypair._Myval2->getTlvType(this: Myfirst->_Mypair._Myval2) != TokenTlv ) /*0x1410af10b*/
  {
    if ( ++Myfirst >= this->typeLengthValues._Mypair._Myval2._Mylast ) /*0x1410af115*/
      return TLV_NOT_FOUND; /*0x1410af115*/
  }
  v6 = this->typeLengthValues._Mypair._Myval2._Myfirst; /*0x1410af12c*/
  v7 = Myfirst - v6; /*0x1410af133*/
  if ( (int)v7 < 0 ) /*0x1410af139*/
    return TLV_NOT_FOUND; /*0x1410af117*/
  if ( setTokenValue->Length != 16 ) /*0x1410af140*/
    return INVALID_TOKEN; /*0x1410af142*/
  tokenValueCacheLocation = this->tokenValueCacheLocation; /*0x1410af157*/
  Myval2 = (RBX::Network::Rupp::TokenTlv *)v6[(int)v7]._Mypair._Myval2; /*0x1410af165*/
  if ( tokenValueCacheLocation != 0 ) /*0x1410af16b*/
  {
    numberOfBitsUsed = this->cachedSerialization.numberOfBitsUsed; /*0x1410af16d*/
    p_cachedSerialization = &this->cachedSerialization; /*0x1410af173*/
    RakNet::BitStream::SetWriteOffset( /*0x1410af17a*/
      this: p_cachedSerialization,
      offset: tokenValueCacheLocation,
      eraseDataToCurrentOffset: false);
    RakNet::BitStream::Write(this: p_cachedSerialization, inputByteArray: setTokenValue->Data, numberOfBytes: 0x10u); /*0x1410af18b*/
    RakNet::BitStream::SetWriteOffset( /*0x1410af198*/
      this: p_cachedSerialization,
      offset: numberOfBitsUsed,
      eraseDataToCurrentOffset: false);
  }
  else
  {
    this->cachedSerializationIsValid = false; /*0x1410af19f*/
  }
  v12 = *setTokenValue; /*0x1410af1ae*/
  return RBX::Network::Rupp::TokenTlv::setTokenValue(this: Myval2, setToken: &v12); /*0x1410af11c*/
}

// Address: 0x1410b8c10 | Name: ??_G?$_Ref_count_obj2@VRupp@1Network@RBX@@@std@@UEAAPEAXI@Z
std::_Ref_count_obj2<RBX::Network::Rupp::Rupp> *__fastcall std::_Ref_count_obj2<RBX::Network::Rupp::Rupp>::`scalar deleting destructor'(
        std::_Ref_count_obj2<RBX::Network::Rupp::Rupp> *this,
        char a2)
{
  this->__vftable = (std::_Ref_count_obj2<RBX::Network::Rupp::Rupp>_vtbl *)std::_Ref_count_obj2<RBX::Network::Rupp::Rupp>::`vftable'; /*0x1410b8c20*/
  if ( (a2 & 1) != 0 ) /*0x1410b8c26*/
    operator delete(ptr: this); /*0x1410b8c2d*/
  return this; /*0x1410b8c35*/
}

// END Rupp part 1/1, 14 functions
