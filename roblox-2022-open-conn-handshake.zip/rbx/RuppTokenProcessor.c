// RuppTokenProcessor -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x141190800 | Name: ?generate@RuppTokenProcessor@RBX@@QEAA_NPEAEAEBUSystemAddress@RakNet@@PEBU34@IPEAV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
char __fastcall RBX::RuppTokenProcessor::generate(
        RBX::RuppTokenProcessor *this,
        unsigned __int8 *token,
        const RakNet::SystemAddress *server,
        const RakNet::SystemAddress *client)
{
  *(_OWORD *)token = *(_OWORD *)"SixteenCharValue"; /*0x141190809*/
  return 1; /*0x14119080c*/
}

// END RuppTokenProcessor part 1/1, 1 functions
