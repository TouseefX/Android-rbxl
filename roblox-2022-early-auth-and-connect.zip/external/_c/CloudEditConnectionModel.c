// CloudEditConnectionModel -- 2022 Studio + full PDB
// tier 3, 21 functions


// Address: 0x1406edd70 | Name: ??1CloudEditConnectionModel@@UEAA@XZ
void __fastcall CloudEditConnectionModel::~CloudEditConnectionModel(CloudEditConnectionModel *this)
{
  rbx::signals::scoped_connection *p_m_replicatorLoadedConnection; // rcx
  rbx::signals::slot_base *p; // rcx
  rbx::signals::slot_base *v4; // rcx
  rbx::signals::slot_base *v5; // rcx
  __int64 v6; // rdx
  rbx::signals::slot_base *v7; // rcx
  std::function<void __cdecl(std::string,int,std::string)> *v8; // rcx
  std::_Ref_count_base *Rep; // rbx
  std::_Ref_count_base *v10; // rbx
  std::_Ref_count_base *v11; // rcx
  __int64 v12; // [rsp+0h] [rbp-28h] BYREF

  p_m_replicatorLoadedConnection = &this->m_replicatorLoadedConnection; /*0x1406edd82*/
  __wind /*0xf1c0000000000020*/
  {
    rbx::signals::connection::disconnect(this: &p_m_replicatorLoadedConnection->con); /*0x1406edd89*/
    p = this->m_replicatorLoadedConnection.con.weak_slot.p_; /*0x1406edd8e*/
    if ( p != nullptr && _InterlockedExchangeAdd(&p->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x1406edda9*/
      operator delete(ptr: p); /*0x1406eddab*/
    rbx::signals::connection::disconnect(this: &this->m_connectionFailedConnection.con); /*0x1406eddb8*/
    v4 = this->m_connectionFailedConnection.con.weak_slot.p_; /*0x1406eddbd*/
    if ( v4 != nullptr && _InterlockedExchangeAdd(&v4->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x1406eddd3*/
      operator delete(ptr: v4); /*0x1406eddd5*/
    rbx::signals::connection::disconnect(this: &this->m_connectionAcceptedConnection.con); /*0x1406edde2*/
    v5 = this->m_connectionAcceptedConnection.con.weak_slot.p_; /*0x1406edde7*/
    if ( v5 != nullptr && _InterlockedExchangeAdd(&v5->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x1406eddfd*/
      operator delete(ptr: v5); /*0x1406eddff*/
    rbx::signals::connection::disconnect(this: &this->m_gameLoadedConnection.con); /*0x1406ede0c*/
    v7 = this->m_gameLoadedConnection.con.weak_slot.p_; /*0x1406ede11*/
    if ( v7 != nullptr && _InterlockedExchangeAdd(&v7->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x1406ede27*/
      operator delete(ptr: v7); /*0x1406ede29*/
  }
  __unwind
  {
    __std_terminate(a1: v7, a2: &v12); /*0x142f39fa8*/
  }
  v8 = (std::function<void __cdecl(std::string,int,std::string)> *)this->m_onFailedSignalCallBack._Mystorage._Ptrs[7]; /*0x1406ede36*/
  if ( v8 != nullptr ) /*0x1406ede3d*/
  {
    LOBYTE(v6) = v8 != &this->m_onFailedSignalCallBack; /*0x1406ede45*/
    ((void (__fastcall *)(std::function<void __cdecl(std::string,int,std::string)> *, __int64))v8->_Mystorage._Ptrs[0][4].__vftable)( /*0x1406ede48*/
      a1: v8,
      a2: v6);
    this->m_onFailedSignalCallBack._Mystorage._Ptrs[7] = nullptr; /*0x1406ede4b*/
  }
  Rep = this->m_request._Rep; /*0x1406ede53*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1406ede66*/
  {
    Rep->_Destroy(this: Rep); /*0x1406ede6e*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1406ede7a*/
      Rep->_Delete_this(this: Rep); /*0x1406ede82*/
  }
  v10 = this->m_config._Rep; /*0x1406ede85*/
  if ( v10 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Uses, 0xFFFFFFFF) == 1 ) /*0x1406ede98*/
  {
    v10->_Destroy(this: v10); /*0x1406edea0*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1406edeac*/
      v10->_Delete_this(this: v10); /*0x1406edeb4*/
  }
  v11 = this->m_weakDM._Rep; /*0x1406edeb7*/
  if ( v11 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v11->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1406edec8*/
    v11->_Delete_this(this: v11); /*0x1406edecd*/
  std::vector<std::shared_ptr<RBX::RVideo::RvPacket>>::~vector<std::shared_ptr<RBX::RVideo::RvPacket>>(this: (std::vector<std::shared_ptr<StudioCmdBase>> *)&this->m_connectPlayerReceivedFromServerConnections); /*0x1406eded4*/
  std::vector<std::shared_ptr<RBX::RVideo::RvPacket>>::~vector<std::shared_ptr<RBX::RVideo::RvPacket>>(this: (std::vector<std::shared_ptr<StudioCmdBase>> *)&this->m_localPlayerCreateConnections_deprecated); /*0x1406ededd*/
  QObject::~QObject(this); /*0x1406edef4*/
}

// Address: 0x1406ef710 | Name: ??_G?$_Ref_count_obj2@VCloudEditConnectionModel@@@std@@UEAAPEAXI@Z
std::_Ref_count_obj2<CloudEditConnectionModel> *__fastcall std::_Ref_count_obj2<CloudEditConnectionModel>::`scalar deleting destructor'(
        std::_Ref_count_obj2<CloudEditConnectionModel> *this,
        char a2)
{
  this->__vftable = (std::_Ref_count_obj2<CloudEditConnectionModel>_vtbl *)std::_Ref_count_obj2<CloudEditConnectionModel>::`vftable'; /*0x1406ef720*/
  if ( (a2 & 1) != 0 ) /*0x1406ef726*/
    operator delete(ptr: this); /*0x1406ef72d*/
  return this; /*0x1406ef735*/
}

// Address: 0x142facb90 | Name: ??$runInUIThreadWithQtContext@VCloudEditConnectionModel@@@@YAXV?$QPointer@VCloudEditConnectionModel@@@@V?$function@$$A6AXXZ@std@@@Z
void __fastcall runInUIThreadWithQtContext<CloudEditConnectionModel>(
        QPointer<CloudEditConnectionModel> *obj,
        std::_Func_base<void> *func)
{
  std::_Func_base<void> *v4; // rcx
  char *v5; // rbx
  std::function<void __cdecl(UserPluginReference,std::string)> *v6; // rdx
  _BOOL8 v7; // rdx
  std::_Func_base<void> *v8; // rcx
  std::function<void __cdecl(UserPluginReference,std::string)> _Right; // [rsp+30h] [rbp-59h] BYREF
  std::function<void __cdecl(UserPluginReference,std::string)> *p_Right; // [rsp+70h] [rbp-19h]
  std::function<void __cdecl(void)> v12; // [rsp+78h] [rbp-11h] BYREF
  QPointer<CloudEditConnectionModel> ptr; // 0:^20.16

  ptr = *obj; /*0x142facbc5*/
  if ( obj->wp.d != nullptr ) /*0x142facbd4*/
    _InterlockedIncrement(&obj->wp.d->weakref._q_value._Storage._Value); /*0x142facbd6*/
  p_Right = &_Right; /*0x142facbdd*/
  _Right._Mystorage._Ptrs[7] = nullptr; /*0x142facbe4*/
  v4 = (std::_Func_base<void> *)func[7].__vftable; /*0x142facbe8*/
  if ( v4 != nullptr ) /*0x142facbef*/
    _Right._Mystorage._Ptrs[7] = (std::_Func_base<void,UserPluginReference,std::string > *)v4->_Copy( /*0x142facbfa*/
                                                                                             this: v4,
                                                                                             a2: &_Right);
  v12._Mystorage._Ptrs[7] = nullptr; /*0x142facc06*/
  v5 = (char *)operator new(size: 0x58u); /*0x142facc14*/
  *(_QWORD *)v5 = std::_Func_impl_no_alloc<_lambda_35ef00208b6518c0b6076295622f8b97_,void,>::`vftable'; /*0x142facc1e*/
  *(QPointer<CloudEditConnectionModel> *)(v5 + 8) = ptr; /*0x142facc25*/
  std::function<void (QVector<RobloxApiGame>,QString)>::function<void (QVector<RobloxApiGame>,QString)>( /*0x142facc41*/
    this: (std::function<void __cdecl(UserPluginReference,std::string)> *)(v5 + 24),
    &_Right);
  v12._Mystorage._Ptrs[7] = (std::_Func_base<void> *)v5; /*0x142facc46*/
  if ( _Right._Mystorage._Ptrs[7] != nullptr ) /*0x142facc51*/
  {
    v6 = &_Right; /*0x142facc56*/
    LOBYTE(v6) = _Right._Mystorage._Ptrs[7] != (std::_Func_base<void,UserPluginReference,std::string > *)&_Right; /*0x142facc5d*/
    _Right._Mystorage._Ptrs[7]->_Delete_this(this: _Right._Mystorage._Ptrs[7], a2: (bool)v6); /*0x142facc60*/
    _Right._Mystorage._Ptrs[7] = nullptr; /*0x142facc63*/
  }
  doRunInUIThread(func: &v12); /*0x142facc92*/
  if ( obj->wp.d != nullptr /*0x142faccaf*/
    && _InterlockedExchangeAdd(&obj->wp.d->weakref._q_value._Storage._Value, 0xFFFFFFFF) == 1
    && obj->wp.d != nullptr )
  {
    operator delete(ptr: obj->wp.d); /*0x142faccb1*/
  }
  v8 = (std::_Func_base<void> *)func[7].__vftable; /*0x142faccb7*/
  if ( v8 != nullptr ) /*0x142faccbe*/
  {
    LOBYTE(v7) = v8 != func; /*0x142faccc6*/
    v8->_Delete_this(this: v8, a2: v7); /*0x142faccc9*/
    func[7].__vftable = nullptr; /*0x142facccc*/
  }
}

// Address: 0x142facd30 | Name: ??0CloudEditConnectionModel@@QEAA@XZ
CloudEditConnectionModel *__fastcall CloudEditConnectionModel::CloudEditConnectionModel(CloudEditConnectionModel *this)
{
  QObject::QObject(this, a2: nullptr); /*0x142facd3b*/
  this->__vftable = (CloudEditConnectionModel_vtbl *)CloudEditConnectionModel::`vftable'; /*0x142facd48*/
  this->m_localPlayerCreateConnections_deprecated._Mypair._Myval2._Myfirst = nullptr; /*0x142facd4d*/
  this->m_localPlayerCreateConnections_deprecated._Mypair._Myval2._Mylast = nullptr; /*0x142facd51*/
  this->m_localPlayerCreateConnections_deprecated._Mypair._Myval2._Myend = nullptr; /*0x142facd55*/
  this->m_connectPlayerReceivedFromServerConnections._Mypair._Myval2._Myfirst = nullptr; /*0x142facd59*/
  this->m_connectPlayerReceivedFromServerConnections._Mypair._Myval2._Mylast = nullptr; /*0x142facd5d*/
  this->m_connectPlayerReceivedFromServerConnections._Mypair._Myval2._Myend = nullptr; /*0x142facd61*/
  this->m_weakDM._Ptr = nullptr; /*0x142facd65*/
  this->m_weakDM._Rep = nullptr; /*0x142facd69*/
  this->m_config._Ptr = nullptr; /*0x142facd6d*/
  this->m_config._Rep = nullptr; /*0x142facd71*/
  this->m_request._Ptr = nullptr; /*0x142facd75*/
  this->m_request._Rep = nullptr; /*0x142facd79*/
  *(_DWORD *)&this->m_gameLoaded = 0; /*0x142facd7d*/
  this->DEPRECATED_m_initialStreamSizeInBytes = 0; /*0x142facd83*/
  this->m_placeLauncherRequestStatus = -1; /*0x142facd8a*/
  this->m_connectionResult = 6; /*0x142facd91*/
  this->m_placeId = -1; /*0x142facd98*/
  this->m_onFailedSignalCallBack._Mystorage._Ptrs[7] = nullptr; /*0x142facda0*/
  this->m_gameLoadedConnection.con.weak_slot.p_ = nullptr; /*0x142facda7*/
  this->m_connectionAcceptedConnection.con.weak_slot.p_ = nullptr; /*0x142facdae*/
  this->m_connectionFailedConnection.con.weak_slot.p_ = nullptr; /*0x142facdb5*/
  this->m_replicatorLoadedConnection.con.weak_slot.p_ = nullptr; /*0x142facdbc*/
  return this; /*0x142facdc6*/
}

// Address: 0x142fae1d0 | Name: ?abort@CloudEditConnectionModel@@QEAAX_N@Z
void __fastcall CloudEditConnectionModel::abort(CloudEditConnectionModel *this, bool cancelStudioHttpRequest)
{
  StudioHttpRequest *Ptr; // rcx
  __int64 m_placeId; // rdx

  if ( !this->m_aborted ) /*0x142fae1e0*/
  {
    if ( cancelStudioHttpRequest ) /*0x142fae1e4*/
    {
      Ptr = this->m_request._Ptr; /*0x142fae1e6*/
      if ( Ptr != nullptr ) /*0x142fae1ed*/
        StudioHttpRequest::cancel(this: Ptr); /*0x142fae1ef*/
    }
    m_placeId = this->m_placeId; /*0x142fae1f4*/
    this->m_aborted = true; /*0x142fae1fb*/
    ICloudEditConnectionModel::teamCreateConnectionAborted(this, _t1: m_placeId); /*0x142fae207*/
  }
}

// Address: 0x142fae220 | Name: ?cancel@CloudEditConnectionModel@@UEAAXXZ
void __fastcall CloudEditConnectionModel::cancel(CloudEditConnectionModel *this)
{
  bool v1; // zf
  StudioHttpRequest *Ptr; // rcx
  __int64 m_placeId; // rdx

  v1 = !this->m_aborted; /*0x142fae226*/
  this->m_cancelled = true; /*0x142fae230*/
  if ( v1 ) /*0x142fae237*/
  {
    Ptr = this->m_request._Ptr; /*0x142fae239*/
    if ( Ptr != nullptr ) /*0x142fae240*/
      StudioHttpRequest::cancel(this: Ptr); /*0x142fae242*/
    m_placeId = this->m_placeId; /*0x142fae247*/
    this->m_aborted = true; /*0x142fae24e*/
    ICloudEditConnectionModel::teamCreateConnectionAborted(this, _t1: m_placeId); /*0x142fae25a*/
  }
}

// Address: 0x142fae270 | Name: ?connectLocalPlayerCreate_deprecated@CloudEditConnectionModel@@AEAAXPEAVPlayers@RBX@@V?$shared_ptr@VEntityProperties@@@std@@@Z
void __fastcall CloudEditConnectionModel::connectLocalPlayerCreate_deprecated(
        CloudEditConnectionModel *this,
        RBX::Players *players,
        std::shared_ptr<RBX::File> *config)
{
  _DWORD *v6; // rax
  _DWORD *v7; // rdi
  std::_Ref_count_base *Rep; // r12
  unsigned int v9; // eax
  unsigned int parent; // ebx
  rbx::signals::slot_base *v11; // rax
  rbx::signals::slot_base *v12; // r14
  rbx::signals::signal_base *v13; // rcx
  CloudEditConnectionModel *v14; // r12
  __int64 v15; // rcx
  rbx::signals::slot_base *p; // rcx
  __int64 v17; // rbx
  std::shared_ptr<rbx::signals::scoped_connection> *Mylast; // rdx
  std::_Ref_count_base *v19; // rbx
  std::_Ref_count_base *v20; // rbx
  __int64 v21; // [rsp+0h] [rbp-78h] BYREF
  rbx::signals::signal_base *p_localPlayerCreate_deprecated; // [rsp+20h] [rbp-58h]
  rbx::signals::connection other; // [rsp+28h] [rbp-50h] BYREF
  EntityProperties *Ptr; // [rsp+30h] [rbp-48h]
  rbx::signals::slot_base *v25; // [rsp+38h] [rbp-40h]
  std::shared_ptr<rbx::signals::scoped_connection> connection; // [rsp+40h] [rbp-38h] BYREF
  __int128 v27; // [rsp+50h] [rbp-28h] BYREF
  CloudEditConnectionModel *v28; // [rsp+60h] [rbp-18h]
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v31; // [rsp+D8h] [rbp+60h] BYREF

  if ( players != nullptr && config->_Ptr != nullptr ) /*0x142fae2ae*/
  {
    __wind /*0xf1c0000000000064*/
    {
      v6 = operator new(size: 0x18u); /*0x142fae2b7*/
      v7 = v6; /*0x142fae2bc*/
      if ( v6 != nullptr ) /*0x142fae2c6*/
      {
        *(_OWORD *)v6 = 0; /*0x142fae2cb*/
        v6[2] = 1; /*0x142fae2ce*/
        v6[3] = 1; /*0x142fae2d5*/
        *(_QWORD *)v6 = std::_Ref_count_obj2<rbx::signals::scoped_connection>::`vftable'; /*0x142fae2e3*/
        *((_QWORD *)v6 + 2) = 0; /*0x142fae2e6*/
      }
      else
      {
        v7 = nullptr; /*0x142fae2ec*/
      }
      connection._Ptr = (rbx::signals::scoped_connection *)(v7 + 4); /*0x142fae2fa*/
      connection._Rep = (std::_Ref_count_base *)v7; /*0x142fae2fe*/
      p_localPlayerCreate_deprecated = &players->localPlayerCreate_deprecated; /*0x142fae309*/
      Rep = config->_Rep; /*0x142fae30d*/
      if ( Rep != nullptr ) /*0x142fae314*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x142fae316*/
        Rep = config->_Rep; /*0x142fae31c*/
      }
      __wind /*0xf1c0000000000088*/
      {
        __wind /*0xf1c0000000000090*/
        {
          __wind /*0xf1c0000000000098*/
          {
            Ptr = (EntityProperties *)config->_Ptr; /*0x142fae323*/
            *(_QWORD *)&v27 = Ptr; /*0x142fae327*/
            *((_QWORD *)&v27 + 1) = Rep; /*0x142fae32b*/
            v28 = this; /*0x142fae32f*/
            v9 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x142fae339*/
            __wind /*0xf1c0000000000040*/
            {
              parent = v9; /*0x142fae33e*/
              v31.parent = v9; /*0x142fae340*/
              v11 = (rbx::signals::slot_base *)operator new(size: 0x40u); /*0x142fae348*/
              v12 = v11; /*0x142fae34d*/
              v25 = v11; /*0x142fae350*/
              v13 = p_localPlayerCreate_deprecated; /*0x142fae354*/
              if ( v11 != nullptr ) /*0x142fae35b*/
              {
                v11->strong._Storage._Value = 0; /*0x142fae35d*/
                v11->weak._Storage._Value = 1; /*0x142fae363*/
                v11->call = rbx::signals::slot_with_functor__lambda_66de22f242451b5e11d0901b12e4e8d2___::do_call; /*0x142fae371*/
                v11->dtor = rbx::signals::slot_with_functor__lambda_632facf5fef7583a5bba4c3b596e7767__bool_::do_dtor; /*0x142fae37c*/
                v11->next.px = nullptr; /*0x142fae380*/
                v11->owner = v13; /*0x142fae388*/
                v11[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)Ptr; /*0x142fae390*/
                v11[1].call = (void (__fastcall *)(rbx::signals::slot_base *))Rep; /*0x142fae394*/
                v27 = 0; /*0x142fae39b*/
                v14 = this; /*0x142fae3a0*/
                v11[1].dtor = (void (__fastcall *)(rbx::signals::slot_base *))this; /*0x142fae3a4*/
              }
              else
              {
                v12 = nullptr; /*0x142fae3aa*/
                v14 = this; /*0x142fae3ad*/
              }
              rbx::signals::signal_base::insert(this: v13, item: v12); /*0x142fae3b4*/
              other.weak_slot.p_ = v12; /*0x142fae3b9*/
              if ( v12 != nullptr ) /*0x142fae3c0*/
              {
                _InterlockedIncrement(&v12->weak._Storage._Value); /*0x142fae3c2*/
                parent = v31.parent; /*0x142fae3c7*/
              }
            }
            __unwind
            {
              RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v31); /*0xf1c0000000000050*/
            }
            __wind /*0xf1c0000000000058*/
            {
              RBX::Memory::setCurrentCategory(category: parent); /*0x142fae3d3*/
            }
            __unwind
            {
              __std_terminate(a1: v15, a2: &v21); /*0x142f39fa8*/
            }
            if ( rbx::signals::connection::operator!=(this: (rbx::signals::connection *)v7 + 2, &other) ) /*0x142fae3e0*/
            {
              rbx::signals::connection::disconnect(this: (rbx::signals::connection *)v7 + 2); /*0x142fae3ec*/
              rbx::signals::connection::operator=(this: (rbx::signals::connection *)v7 + 2, con: &other); /*0x142fae3f8*/
            }
          }
          __unwind
          {
            rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&other); /*0x143189811*/
          }
          p = other.weak_slot.p_; /*0x142fae3fe*/
          if ( other.weak_slot.p_ != nullptr /*0x142fae411*/
            && _InterlockedExchangeAdd(&other.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
          {
            operator delete(ptr: p); /*0x142fae413*/
          }
          if ( *((_QWORD *)&v27 + 1) != 0 /*0x142fae42c*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)(*((_QWORD *)&v27 + 1) + 8LL), 0xFFFFFFFF) == 1 )
          {
            v17 = *((_QWORD *)&v27 + 1); /*0x142fae42e*/
            (***((void (__fastcall ****)(_QWORD))&v27 + 1))(a1: *((_QWORD *)&v27 + 1)); /*0x142fae438*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v17 + 12), 0xFFFFFFFF) == 1 ) /*0x142fae444*/
              (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v27 + 1) + 8LL))(a1: *((_QWORD *)&v27 + 1)); /*0x142fae44d*/
          }
        }
        __unwind
        {
          lambda_b40c0602a8d2a792d1786c15b8b923de_::__lambda_b40c0602a8d2a792d1786c15b8b923de_(CallableAddr: &v27); /*0xf1c0000000000020*/
        }
        Mylast = v14->m_localPlayerCreateConnections_deprecated._Mypair._Myval2._Mylast; /*0x142fae455*/
        if ( Mylast == v14->m_localPlayerCreateConnections_deprecated._Mypair._Myval2._Myend ) /*0x142fae45f*/
        {
          std::vector<std::shared_ptr<rbx::signals::scoped_connection>>::_Emplace_reallocate<std::shared_ptr<rbx::signals::scoped_connection> &>( /*0x142fae489*/
            this: &v14->m_localPlayerCreateConnections_deprecated,
            _Whereptr: Mylast,
            <_Val_0>: &connection);
        }
        else
        {
          Mylast->_Ptr = nullptr; /*0x142fae463*/
          Mylast->_Rep = nullptr; /*0x142fae466*/
          if ( v7 != nullptr ) /*0x142fae46d*/
            _InterlockedIncrement(v7 + 2); /*0x142fae46f*/
          Mylast->_Ptr = connection._Ptr; /*0x142fae477*/
          Mylast->_Rep = (std::_Ref_count_base *)v7; /*0x142fae47a*/
          ++v14->m_localPlayerCreateConnections_deprecated._Mypair._Myval2._Mylast; /*0x142fae47e*/
        }
        if ( connection._Rep != nullptr /*0x142fae4a2*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&connection._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v19 = connection._Rep; /*0x142fae4a4*/
          connection._Rep->_Destroy(this: connection._Rep); /*0x142fae4ae*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v19->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fae4ba*/
            connection._Rep->_Delete_this(this: connection._Rep); /*0x142fae4c3*/
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&connection); /*0xf1c0000000000080*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: config); /*0xf1c0000000000074*/
    }
  }
  v20 = config->_Rep; /*0x142fae4c7*/
  if ( v20 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Uses, 0xFFFFFFFF) == 1 ) /*0x142fae4da*/
  {
    v20->_Destroy(this: v20); /*0x142fae4e2*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fae4ec*/
      v20->_Delete_this(this: v20); /*0x142fae4f4*/
  }
}

// Address: 0x142fae510 | Name: ?connectPlayerReceivedFromServerInCloudEdit@CloudEditConnectionModel@@AEAAXPEAVPlayers@RBX@@@Z
void __fastcall CloudEditConnectionModel::connectPlayerReceivedFromServerInCloudEdit(
        CloudEditConnectionModel *this,
        RBX::Players *players)
{
  _DWORD *v4; // rax
  _DWORD *v5; // rdi
  rbx::signal<void __cdecl(std::shared_ptr<RBX::Player>)> *p_connectPlayerSignals; // r15
  rbx::signals::slot_base *v7; // rax
  rbx::signals::slot_base *v8; // rsi
  unsigned int parent; // ebx
  __int64 v10; // rcx
  rbx::signals::slot_base *p; // rcx
  std::shared_ptr<rbx::signals::scoped_connection> *Mylast; // rdx
  std::_Ref_count_base *Rep; // rbx
  __int64 v14; // [rsp+0h] [rbp-78h] BYREF
  rbx::signals::connection other; // [rsp+20h] [rbp-58h] BYREF
  std::shared_ptr<rbx::signals::scoped_connection> connection; // [rsp+28h] [rbp-50h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v17; // [rsp+90h] [rbp+18h] BYREF
  rbx::signals::slot_base *v18; // [rsp+98h] [rbp+20h]

  if ( players != nullptr ) /*0x142fae513*/
  {
    v4 = operator new(size: 0x18u); /*0x142fae53d*/
    v5 = v4; /*0x142fae542*/
    if ( v4 != nullptr ) /*0x142fae550*/
    {
      *(_OWORD *)v4 = 0; /*0x142fae555*/
      v4[2] = 1; /*0x142fae558*/
      v4[3] = 1; /*0x142fae55f*/
      *(_QWORD *)v4 = std::_Ref_count_obj2<rbx::signals::scoped_connection>::`vftable'; /*0x142fae56d*/
      *((_QWORD *)v4 + 2) = 0; /*0x142fae570*/
    }
    else
    {
      v5 = nullptr; /*0x142fae576*/
    }
    connection._Ptr = (rbx::signals::scoped_connection *)(v5 + 4); /*0x142fae588*/
    connection._Rep = (std::_Ref_count_base *)v5; /*0x142fae58d*/
    p_connectPlayerSignals = &players->connectPlayerSignals; /*0x142fae592*/
    __wind /*0xf1c0000000000064*/
    {
      __wind /*0xf1c000000000006c*/
      {
        parent = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x142fae5a4*/
        v17.parent = parent; /*0x142fae5a6*/
        __wind /*0xf1c0000000000040*/
        {
          v7 = (rbx::signals::slot_base *)operator new(size: 0x30u); /*0x142fae5b2*/
          v8 = v7; /*0x142fae5b7*/
          v18 = v7; /*0x142fae5ba*/
          if ( v7 != nullptr ) /*0x142fae5c8*/
          {
            v7->strong._Storage._Value = 0; /*0x142fae5ca*/
            v7->weak._Storage._Value = 1; /*0x142fae5cd*/
            v7->call = (void (__fastcall *)(rbx::signals::slot_base *))rbx::signals::slot_with_functor__lambda_8f65404d13e5d4794735c79032e84287__std::shared_ptr_RBX::Player___::do_call; /*0x142fae5db*/
            v7->dtor = (void (__fastcall *)(rbx::signals::slot_base *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x142fae5e6*/
            v7->next.px = nullptr; /*0x142fae5ea*/
            v7->owner = p_connectPlayerSignals; /*0x142fae5ee*/
            v7[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)this; /*0x142fae5f2*/
            rbx::signals::signal_base::insert(this: p_connectPlayerSignals, item: v7); /*0x142fae5f9*/
            other.weak_slot.p_ = v8; /*0x142fae5fe*/
            _InterlockedIncrement(&v8->weak._Storage._Value); /*0x142fae608*/
            parent = v17.parent; /*0x142fae60c*/
          }
          else
          {
            rbx::signals::signal_base::insert(this: p_connectPlayerSignals, item: nullptr); /*0x142fae617*/
            other.weak_slot.p_ = nullptr; /*0x142fae61c*/
          }
        }
        __unwind
        {
          RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v17); /*0xf1c0000000000050*/
        }
        __wind /*0xf1c0000000000058*/
        {
          RBX::Memory::setCurrentCategory(category: parent); /*0x142fae62e*/
        }
        __unwind
        {
          __std_terminate(a1: v10, a2: &v14); /*0x142f39fa8*/
        }
        if ( rbx::signals::connection::operator!=(this: (rbx::signals::connection *)v5 + 2, &other) ) /*0x142fae63c*/
        {
          rbx::signals::connection::disconnect(this: (rbx::signals::connection *)v5 + 2); /*0x142fae648*/
          rbx::signals::connection::operator=(this: (rbx::signals::connection *)v5 + 2, con: &other); /*0x142fae655*/
        }
      }
      __unwind
      {
        rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&other); /*0x14315eec1*/
      }
      p = other.weak_slot.p_; /*0x142fae660*/
      if ( other.weak_slot.p_ != nullptr /*0x142fae674*/
        && _InterlockedExchangeAdd(&other.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
      {
        operator delete(ptr: p); /*0x142fae676*/
      }
      Mylast = this->m_connectPlayerReceivedFromServerConnections._Mypair._Myval2._Mylast; /*0x142fae67f*/
      if ( Mylast == this->m_connectPlayerReceivedFromServerConnections._Mypair._Myval2._Myend ) /*0x142fae687*/
      {
        std::vector<std::shared_ptr<rbx::signals::scoped_connection>>::_Emplace_reallocate<std::shared_ptr<rbx::signals::scoped_connection> &>( /*0x142fae6ac*/
          this: &this->m_connectPlayerReceivedFromServerConnections,
          _Whereptr: Mylast,
          <_Val_0>: &connection);
      }
      else
      {
        Mylast->_Ptr = nullptr; /*0x142fae689*/
        Mylast->_Rep = nullptr; /*0x142fae68c*/
        if ( v5 != nullptr ) /*0x142fae693*/
          _InterlockedIncrement(v5 + 2); /*0x142fae695*/
        Mylast->_Ptr = (rbx::signals::scoped_connection *)(v5 + 4); /*0x142fae699*/
        Mylast->_Rep = (std::_Ref_count_base *)v5; /*0x142fae69c*/
        ++this->m_connectPlayerReceivedFromServerConnections._Mypair._Myval2._Mylast; /*0x142fae6a0*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&connection); /*0xf1c0000000000020*/
    }
    if ( connection._Rep != nullptr /*0x142fae6c6*/
      && _InterlockedExchangeAdd((volatile signed __int32 *)&connection._Rep->_Uses, 0xFFFFFFFF) == 1 )
    {
      Rep = connection._Rep; /*0x142fae6c8*/
      connection._Rep->_Destroy(this: connection._Rep); /*0x142fae6d3*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fae6dd*/
        connection._Rep->_Delete_this(this: connection._Rep); /*0x142fae6e7*/
    }
  }
}

// Address: 0x142fae700 | Name: ?connectToTeamCreateSession@CloudEditConnectionModel@@AEAA?AW4CloudEditConnectionResult@1@V?$shared_ptr@VPlaceSessionConfiguration@@@std@@@Z
__int64 __fastcall CloudEditConnectionModel::connectToTeamCreateSession(
        CloudEditConnectionModel *this,
        std::shared_ptr<RBX::File> *psc)
{
  std::_Ref_count_base *v2; // rbx
  std::shared_ptr<RBX::File> *v3; // rdi
  CloudEditConnectionModel *v4; // r13
  std::_Ref_count_base *Rep; // r8
  signed __int32 Uses; // eax
  signed __int32 v7; // ett
  volatile signed __int32 *v8; // rbx
  __int64 result; // rax
  QtSharedPointer::ExternalRefCountData *v10; // rbx
  RBX::Graphics::Framebuffer *v11; // rax
  RBX::Graphics::Framebuffer *v12; // rsi
  rbx::signal<void __cdecl(int)> *p_placeReplicatedSizeAvailableSignal; // r12
  __int64 *v14; // r15
  unsigned int v15; // eax
  unsigned int parent; // ebx
  RBX::Graphics::Framebuffer *v17; // rax
  volatile signed __int32 *v18; // rdi
  __int64 v19; // rcx
  rbx::signal<void __cdecl(void)> *p_gameLoadedSignal; // r12
  __int64 *v21; // r15
  unsigned int v22; // eax
  unsigned int v23; // ebx
  RBX::Graphics::Framebuffer *v24; // rax
  rbx::signals::slot_base *v25; // rdi
  __int64 v26; // rcx
  rbx::signals::slot_base *p; // rcx
  __int64 v28; // rbx
  StudioTimingStatistics *v29; // rbx
  RBX::Graphics::DeviceD3D11 *v30; // rax
  EntityProperties **p_Ptr; // r15
  std::optional<std::string > *v32; // rax
  std::string *v33; // rsi
  char *v34; // rcx
  __int64 Value; // r12
  char *v36; // rcx
  __int64 v37; // rdi
  void *v38; // rcx
  std::optional<int> *v39; // rax
  char *v40; // rcx
  std::optional<std::string > *v41; // rax
  char *v42; // rcx
  EntityProperties *v43; // rbx
  char *v44; // rcx
  std::string *p_serverAddress; // rax
  std::string *v46; // r8
  __int64 Mysize; // rdi
  rtc::webrtc_checks_impl::ToStringVal *v48; // rdx
  __int64 v49; // rcx
  unsigned __int8 v50; // al
  int v51; // eax
  RBX::DataModelCreatorType v52; // r8d
  RBX::DataModel *v53; // rbx
  __int64 v54; // r9
  TeamCreateDisconnectInfo *v55; // rdi
  std::string *v56; // rax
  RBX::ServiceProvider *v57; // rbx
  RBX::Network::Client *v58; // rdi
  EntityProperties *v59; // rbx
  RBX::DataModel *v60; // rsi
  std::optional<std::string > *v61; // rax
  char *v62; // rcx
  EntityProperties *v63; // rbx
  std::optional<std::string > *v64; // rax
  char *v65; // rcx
  rbx::signals::signal_base *p_connectionAcceptedSignal; // r13
  struct QtSharedPointer::ExternalRefCountData *v67; // rax
  struct QtSharedPointer::ExternalRefCountData *v68; // r12
  std::_Ref_count_base *v69; // rcx
  std::_Ref_count_base *v70; // r15
  unsigned int v71; // eax
  unsigned int v72; // ebx
  rbx::signals::slot_base *v73; // rax
  rbx::signals::slot_base *v74; // rdi
  __int64 v75; // rcx
  rbx::signals::slot_base *v76; // rcx
  rbx::signals::signal_base *p_connectionFailedSignal; // rsi
  unsigned int v78; // eax
  unsigned int v79; // ebx
  rbx::signals::slot_base *v80; // rax
  rbx::signals::slot_base *v81; // rdi
  __int64 v82; // rcx
  int v83; // esi
  rbx::signals::slot_base *v84; // rcx
  rbx::signals::signal_base *v85; // r15
  _DWORD *v86; // rax
  std::_Func_base<void,std::string,int,std::string > *v87; // rcx
  rbx::signals::slot_base *v88; // rdi
  unsigned int v89; // ebx
  __int64 v90; // rcx
  RBX::Network::Client *v91; // r12
  RBX::Players *v92; // rbx
  std::shared_ptr<RBX::File> *v93; // rax
  StudioTimingStatistics *v94; // rdi
  std::shared_ptr<EntityProperties> *v95; // rax
  EntityProperties *v96; // rbx
  char *v97; // rcx
  RBX::Reflection::Variant *Myfirst; // r12
  RBX::ServiceProvider *Mylast; // rax
  std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<PluginPermissionsFetcher>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > >,0> > *v100; // rsi
  std::string *p_Keyval; // rdx
  char *v102; // rbx
  unsigned __int64 Myres; // rdi
  unsigned __int64 v104; // r9
  unsigned __int64 i; // rcx
  std::_List_node<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> >,void *> *Duplicate; // r15
  char *v107; // rax
  std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<PluginPermissionsFetcher>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > >,0> > *v108; // r13
  std::string *v109; // rdx
  char *v110; // rbx
  unsigned __int64 v111; // rsi
  unsigned __int64 v112; // r9
  unsigned __int64 j; // rcx
  std::_List_node<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> >,void *> *Myhead; // rdi
  char *v115; // rax
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v116; // rcx
  int v117; // ebx
  std::string *v118; // rax
  RBX::Network::Client::ServerConnection *v119; // rcx
  char v120; // r15
  std::shared_ptr<EntityProperties> *v121; // rax
  EntityProperties *v122; // rdi
  std::optional<bool> *v123; // rax
  char *v124; // rcx
  EntityProperties *v125; // rbx
  std::optional<std::string > *v126; // rax
  int v127; // esi
  char *v128; // rcx
  std::string *p_tokenValue; // rdi
  char *v130; // rbx
  unsigned __int64 v131; // rsi
  std::_Ref_count_base *v132; // rax
  __int64 v133; // rcx
  char *v134; // rcx
  std::string *p_tokenValueDecode; // rax
  char *v136; // rcx
  char *v137; // rax
  int v138; // ebx
  unsigned __int8 v139; // r10
  RBX::Network::Client::ServerConnection *v140; // r8
  RBX::Network::Client::ServerConnection *v141; // r9
  int port; // eax
  EntityProperties *v143; // rbx
  std::optional<std::string > *v144; // rax
  rtc::webrtc_checks_impl::ToStringVal *v145; // rax
  bool *v146; // rax
  rbx::signals::connection *v147; // r10
  std::_Ref_count_base *v148; // kr00_8
  std::shared_ptr<RBX::File> *v149; // kr10_8
  const std::exception *v150; // rdi
  const char *v151; // rax
  TeamCreateDisconnectInfo *Instance; // rbx
  const char *v153; // rax
  const char *v154; // rax
  EntityProperties *v155; // rbx
  std::optional<__int64> *v156; // rax
  int v157; // ebx
  _BYTE v158[32]; // [rsp+0h] [rbp-AC8h] BYREF
  unsigned int v159; // [rsp+70h] [rbp-A58h]
  std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *v160; // [rsp+78h] [rbp-A50h]
  int v161; // [rsp+80h] [rbp-A48h]
  rbx::signals::slot_base *v162; // [rsp+88h] [rbp-A40h]
  std::shared_ptr<RBX::DataModel> dataModel; // [rsp+90h] [rbp-A38h] BYREF
  int centerId; // [rsp+A0h] [rbp-A28h]
  RBX::Network::Client *v165; // [rsp+A8h] [rbp-A20h]
  RBX::Graphics::Framebuffer *QWidget; // [rsp+B0h] [rbp-A18h]
  std::vector<RBX::Network::Client::ServerConnection> serverConnections; // [rsp+B8h] [rbp-A10h] BYREF
  std::string tokenValueDecode; // [rsp+D0h] [rbp-9F8h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v169; // [rsp+F0h] [rbp-9D8h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v170; // [rsp+F4h] [rbp-9D4h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v171; // [rsp+F8h] [rbp-9D0h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v172; // [rsp+FCh] [rbp-9CCh] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v173; // [rsp+100h] [rbp-9C8h] BYREF
  int v174; // [rsp+104h] [rbp-9C4h] BYREF
  int v175; // [rsp+108h] [rbp-9C0h] BYREF
  rbx::signals::connection other; // [rsp+110h] [rbp-9B8h] BYREF
  std::optional<bool> v177; // [rsp+118h] [rbp-9B0h] BYREF
  RBX::ServiceProvider *v178; // [rsp+120h] [rbp-9A8h]
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > v179; // [rsp+130h] [rbp-998h] BYREF
  std::string serverAddress; // [rsp+140h] [rbp-988h] BYREF
  rbx::signals::connection con; // [rsp+160h] [rbp-968h] BYREF
  rbx::signals::connection v182; // [rsp+168h] [rbp-960h] BYREF
  TeamCreateDisconnectInfo *v183; // [rsp+170h] [rbp-958h]
  std::string v184; // [rsp+178h] [rbp-950h] BYREF
  void *ptr[2]; // [rsp+198h] [rbp-930h] BYREF
  __int128 v186; // [rsp+1A8h] [rbp-920h]
  std::string v187; // [rsp+1B8h] [rbp-910h] BYREF
  void *v188[2]; // [rsp+1D8h] [rbp-8F0h] BYREF
  __int128 v189; // [rsp+1E8h] [rbp-8E0h]
  __int128 v190; // [rsp+1F8h] [rbp-8D0h] BYREF
  void *v191[2]; // [rsp+208h] [rbp-8C0h]
  std::string tokenValue; // [rsp+218h] [rbp-8B0h] BYREF
  std::shared_ptr<bool> debouncer; // [rsp+240h] [rbp-888h] BYREF
  QPointer<CloudEditConnectionModel> safeThis; // [rsp+250h] [rbp-878h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > serverConnection; // [rsp+260h] [rbp-868h] BYREF
  std::shared_ptr<__int64> streamSizeInBytes; // [rsp+270h] [rbp-858h] BYREF
  _QWORD v197[3]; // [rsp+280h] [rbp-848h] BYREF
  unsigned __int64 v198; // [rsp+298h] [rbp-830h]
  RBX::Network::Rupp::TokenTlv::Token token; // [rsp+2A0h] [rbp-828h] BYREF
  std::string v200; // [rsp+2B8h] [rbp-810h] BYREF
  std::string fieldName; // [rsp+2D8h] [rbp-7F0h] BYREF
  std::string _Keyval; // [rsp+2F8h] [rbp-7D0h] BYREF
  RBX::DataModel::LegacyLock function[5]; // [rsp+318h] [rbp-7B0h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > playerInfo; // [rsp+340h] [rbp-788h] BYREF
  std::string v205; // [rsp+350h] [rbp-778h] BYREF
  std::string v206; // [rsp+370h] [rbp-758h] BYREF
  std::string v207; // [rsp+390h] [rbp-738h] BYREF
  std::string v208; // [rsp+3B0h] [rbp-718h] BYREF
  std::string v209; // [rsp+3D0h] [rbp-6F8h] BYREF
  std::string v210; // [rsp+3F0h] [rbp-6D8h] BYREF
  std::string v211; // [rsp+410h] [rbp-6B8h] BYREF
  $398703F7114EBF6440C4EA32EC5760FD v212; // [rsp+430h] [rbp-698h] BYREF
  $398703F7114EBF6440C4EA32EC5760FD v213; // [rsp+450h] [rbp-678h] BYREF
  std::vector<RBX::Network::Client::ServerConnection> udmuxEndpoint; // [rsp+470h] [rbp-658h] BYREF
  RBX::StringView v215; // [rsp+490h] [rbp-638h]
  RBX::StringView v216; // [rsp+4A0h] [rbp-628h]
  RBX::StringView v217; // [rsp+4B0h] [rbp-618h]
  rtc::webrtc_checks_impl::ToStringVal v218; // [rsp+4C0h] [rbp-608h] BYREF
  std::string v219; // [rsp+4E0h] [rbp-5E8h] BYREF
  std::string v220; // [rsp+500h] [rbp-5C8h] BYREF
  std::string v221; // [rsp+520h] [rbp-5A8h] BYREF
  std::string v222; // [rsp+540h] [rbp-588h] BYREF
  std::string v223; // [rsp+560h] [rbp-568h] BYREF
  std::optional<std::shared_ptr<std::vector<RBX::Reflection::Variant> const > > serverConnectionsArray; // [rsp+580h] [rbp-548h] BYREF
  RBX::StringView v225; // [rsp+5A0h] [rbp-528h] BYREF
  RBX::Security::Identity v226; // [rsp+5B0h] [rbp-518h] BYREF
  volatile signed __int32 *v227; // [rsp+5D0h] [rbp-4F8h]
  std::optional<int> v228; // [rsp+5D8h] [rbp-4F0h] BYREF
  std::optional<int> v229; // [rsp+5E0h] [rbp-4E8h] BYREF
  rbx::signals::slot_base *v230; // [rsp+5E8h] [rbp-4E0h] BYREF
  const std::exception *e; // [rsp+5F0h] [rbp-4D8h] BYREF
  RBX::StringView v232; // [rsp+600h] [rbp-4C8h] BYREF
  std::shared_ptr<lm::StageResults> v233; // [rsp+610h] [rbp-4B8h] BYREF
  std::shared_ptr<lm::StageResults> v234; // [rsp+620h] [rbp-4A8h] BYREF
  std::shared_ptr<lm::StageResults> v235; // [rsp+630h] [rbp-498h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > v236; // [rsp+640h] [rbp-488h] BYREF
  RBX::StringView v237; // [rsp+650h] [rbp-478h] BYREF
  std::string v238; // [rsp+660h] [rbp-468h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v239; // [rsp+680h] [rbp-448h] BYREF
  std::string v240; // [rsp+6C0h] [rbp-408h] BYREF
  std::string sanitizedException; // [rsp+6E0h] [rbp-3E8h] BYREF
  RBX::Security::Impersonator impersonate; // [rsp+700h] [rbp-3C8h] BYREF
  std::optional<std::string > v243; // [rsp+718h] [rbp-3B0h] BYREF
  std::optional<std::string > v244; // [rsp+740h] [rbp-388h] BYREF
  std::optional<std::string > v245; // [rsp+768h] [rbp-360h] BYREF
  std::optional<std::string > v246; // [rsp+790h] [rbp-338h] BYREF
  std::optional<std::string > v247; // [rsp+7B8h] [rbp-310h] BYREF
  std::optional<std::string > v248; // [rsp+7E0h] [rbp-2E8h] BYREF
  int v249; // [rsp+80Ch] [rbp-2BCh]
  std::basic_stringstream<char,std::char_traits<char>,std::allocator<char> > v250; // [rsp+810h] [rbp-2B8h] BYREF
  std::optional<__int64> v251; // [rsp+910h] [rbp-1B8h] BYREF
  std::optional<__int64> v252; // [rsp+920h] [rbp-1A8h] BYREF
  std::optional<__int64> v253; // [rsp+930h] [rbp-198h] BYREF
  std::_Hash_find_last_result<std::_List_node<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> >,void *> *> v254; // [rsp+940h] [rbp-188h] BYREF
  std::_Hash_find_last_result<std::_List_node<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> >,void *> *> v255; // [rsp+950h] [rbp-178h] BYREF
  QPointer<FindReplaceLockedScriptsDialog> v256; // [rsp+960h] [rbp-168h] BYREF
  RBX::StringView v257; // [rsp+970h] [rbp-158h] BYREF
  std::string v258; // [rsp+980h] [rbp-148h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v259; // [rsp+9A0h] [rbp-128h] BYREF
  std::shared_ptr<bool> v260; // [rsp+9C0h] [rbp-108h] BYREF
  RBX::Network::Rupp::TokenTlv::Token v261; // [rsp+9E0h] [rbp-E8h] BYREF
  RBX::Analytics::InfluxDb::Points responsePoints; // [rsp+A00h] [rbp-C8h] BYREF
  RBX::Security::Identity v263; // [rsp+A70h] [rbp-58h] BYREF
  $398703F7114EBF6440C4EA32EC5760FD *v266; // [rsp+AE0h] [rbp+18h] BYREF
  std::optional<bool> v267; // [rsp+AE8h] [rbp+20h] BYREF

  v3 = psc; /*0x142fae71c*/
  v4 = this; /*0x142fae71f*/
  v159 = 0; /*0x142fae722*/
  dataModel = 0; /*0x142fae72d*/
  Rep = this->m_weakDM._Rep; /*0x142fae736*/
  if ( Rep != nullptr ) /*0x142fae73d*/
  {
    Uses = Rep->_Uses; /*0x142fae73f*/
    if ( Uses != 0 ) /*0x142fae745*/
    {
      while ( 1 ) /*0x142fae753*/
      {
        v7 = Uses; /*0x142fae753*/
        Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x142fae753*/
        if ( v7 == Uses ) /*0x142fae759*/
          break; /*0x142fae759*/
        if ( Uses == 0 ) /*0x142fae75d*/
          goto LABEL_553; /*0x142fae75d*/
      }
      dataModel = (std::shared_ptr<RBX::DataModel>)this->m_weakDM; /*0x142fae765*/
    }
  }
LABEL_553:
  __wind
  {
    __wind
    {
      if ( dataModel._Ptr == nullptr ) /*0x142fae782*/
      {
        if ( FLog::Error != 0 ) /*0x142fae791*/
          FLog::FastLog( /*0x142fae79d*/
            level: FLog::Error,
            message: "[FLog::Error] CloudEditConnectionModel::connectToTeamCreateSession got an empty datamodel.",
            arg0: nullptr);
        if ( dataModel._Rep != nullptr /*0x142fae7c2*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&dataModel._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          dataModel._Rep->_Destroy(this: dataModel._Rep); /*0x142fae7d2*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&dataModel._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fae7df*/
            dataModel._Rep->_Delete_this(this: dataModel._Rep); /*0x142fae7ec*/
        }
        v8 = (volatile signed __int32 *)v3->_Rep; /*0x142fae7f0*/
        if ( v8 != nullptr && _InterlockedExchangeAdd(v8 + 2, 0xFFFFFFFF) == 1 ) /*0x142fae804*/
        {
          (**(void (__fastcall ***)(volatile signed __int32 *))v8)(a1: v8); /*0x142fae80c*/
          if ( _InterlockedExchangeAdd(v8 + 3, 0xFFFFFFFF) == 1 ) /*0x142fae818*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 8LL))(a1: v8); /*0x142fae820*/
        }
        return 1; /*0x142fae828*/
      }
      __eh34_enter_try_state(1, 2); /*0xf1c0000000000614*/
      if ( !dataModel._Ptr->isInitialized )
      {
        if ( FLog::Error != 0 ) /*0x142fae847*/
          FLog::FastLog( /*0x142fae853*/
            level: FLog::Error,
            message: "[FLog::Error] CloudEditConnectionModel::connectToTeamCreateSession got a closed DataModel.",
            arg0: nullptr);
        if ( dataModel._Rep != nullptr /*0x142fae878*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&dataModel._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v2 = dataModel._Rep; /*0x142fae87a*/
          dataModel._Rep->_Destroy(this: dataModel._Rep); /*0x142fae888*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&dataModel._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fae894*/
            dataModel._Rep->_Delete_this(this: dataModel._Rep); /*0x142fae8a1*/
        }
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v3); /*0x142fae8a8*/
        result = 2; /*0x142fae8ad*/
        if ( __eh34_catch(2) )
        {
          if ( __eh34_catch_type(2, &std::exception `RTTI Type Descriptor', &e) )
          {
            v148 = v2; /*0x1432c96b0*/
            v149 = v3; /*0x1432c96b0*/
            v150 = e; /*0x1432c96bf*/
            v151 = e->what(this: e); /*0x1432c96cc*/
            RESTRICTED_SanitizeUtilities::sanitizeExceptionsForLogs(result: &sanitizedException, exception: v151); /*0x1432c96d9*/
            __wind
            {
              Instance = TeamCreateDisconnectInfo::getInstance(); /*0x1432c96e4*/
              debouncer = (std::shared_ptr<bool>)*RBX::StringView::StringView(this: &v257, Str: &sanitizedException); /*0x1432c96fd*/
              TeamCreateDisconnectInfo::setJoinException(this: Instance, msg: (RBX::StringView *)&debouncer); /*0x1432c970e*/
              v153 = v150->what(this: v150); /*0x1432c9719*/
              RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "Error while joining CloudEdit: %s", v153);
              RBX::Analytics::InfluxDb::Points::Points( /*0x1432c9741*/
                this: &responsePoints,
                throttleHundredthsPercentage: -1,
                categoryType: kStandardType,
                priorityHundredthsPercentage: 0);
              __wind /*0xf1c0000000000108*/
              {
                v154 = v150->what(this: v150); /*0x1432c974d*/
                RBX::Analytics::InfluxDb::Points::addPoint(this: &responsePoints, name: "Error", value: v154); /*0x1432c9761*/
                v155 = this->m_config._Ptr; /*0x1432c976d*/
                std::string::string(this: &v239.text, _Ptr: "PlaceId"); /*0x1432c977f*/
                __wind /*0xf1c00000000000fc*/
                {
                  v156 = EntityProperties::getConverted<__int64>(this: v155, result: &v253, fieldName: &v239.text); /*0x1432c9796*/
                  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1432c97ac*/
                    this: &responsePoints,
                    name: "PlaceID",
                    value: v156->_Value);
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v239); /*0xf1c00000000000f4*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v239); /*0x1432c97b9*/
                v157 = DFInt::ReportCloudEditJoinFailureReportPerMyriad; /*0x1432c97be*/
                std::string::string(this: (std::string *)&v239.x, _Ptr: "TeamCreateJoinCloudEditSessionFailure"); /*0x1432c97d2*/
                __wind /*0xf1c00000000000e4*/
                {
                  RBX::Analytics::InfluxDb::Points::report( /*0x1432c97ec*/
                    this: &responsePoints,
                    resource: (const std::string *)&v239.x,
                    throttleHundredthsPercentage: v157,
                    blocking: false);
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v239.x); /*0xf1c00000000000dc*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v239.x); /*0x1432c97f9*/
                std::string::string(this: &v240, _Ptr: "TeamCreate.Open.Place.Failure"); /*0x1432c980c*/
                __wind /*0xf1c00000000000cc*/
                {
                  RBX::Analytics::EphemeralCounter::reportCounter(counterName: &v240, amount: 1, blocking: false); /*0x1432c9820*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v240); /*0xf1c00000000000c4*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v240); /*0x1432c982d*/
                RBX::Analytics::InfluxDb::Points::~Points(this: &responsePoints); /*0x1432c983a*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&sanitizedException); /*0x1432c9847*/
              }
              __unwind
              {
                RBX::Analytics::InfluxDb::Points::~Points(this: &responsePoints); /*0xf1c0000000000118*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&sanitizedException); /*0xf1c0000000000124*/
            }
            v2 = v148; /*0x1432c985e*/
            v3 = v149; /*0x1432c985e*/
            __eh34_enter_try_state(1, 2); /*0xf1c0000000000718*/
            __eh34_enter_wind_state(2, 3); /*0xf1c000000000071c*/
            __eh34_enter_wind_state(3, 4); /*0xf1c0000000000720*/
            __eh34_enter_wind_state(4, 13); /*0xf1c0000000000724*/
            __eh34_enter_wind_state(13, 14); /*0xf1c0000000000728*/
            __eh34_enter_wind_state(14, 21); /*0xf1c000000000072c*/
            __eh34_enter_wind_state(21, 42); /*0xf1c0000000000730*/
            __eh34_enter_wind_state(42, 48); /*0xf1c0000000000734*/
            __eh34_enter_wind_state(48, 49); /*0xf1c0000000000738*/
LABEL_310:
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&dataModel); /*0x142fb084d*/
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: psc); /*0x142fb085b*/
            result = 4; /*0x142fb0860*/
            if ( __eh34_unwind(49) ) /*0xf1c0000000000740*/
            {
              std::vector<RBX::Network::Client::ServerConnection>::~vector<RBX::Network::Client::ServerConnection>(this: &udmuxEndpoint); /*0xf1c0000000000744*/
              __eh34_continue_unwinding(49, 48); /*0xf1c0000000000748*/
            }
LABEL_570:
            __eh34_exit_wind_state(49, 48); /*0xf1c000000000074c*/
            if ( __eh34_unwind(48) ) /*0xf1c0000000000750*/
            {
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&playerInfo); /*0xf1c0000000000754*/
              __eh34_continue_unwinding(48, 42); /*0xf1c0000000000758*/
            }
            __eh34_exit_wind_state(48, 42); /*0xf1c000000000075c*/
            if ( __eh34_unwind(42) ) /*0xf1c0000000000760*/
            {
              std::vector<RBX::Network::Client::ServerConnection>::~vector<RBX::Network::Client::ServerConnection>(this: &serverConnections); /*0xf1c0000000000764*/
              __eh34_continue_unwinding(42, 21); /*0xf1c0000000000768*/
            }
            __eh34_exit_wind_state(42, 21); /*0xf1c000000000076c*/
            if ( __eh34_unwind(21) ) /*0xf1c0000000000770*/
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&serverAddress); /*0xf1c0000000000774*/
              __eh34_continue_unwinding(21, 14); /*0xf1c0000000000778*/
            }
            __eh34_exit_wind_state(21, 14); /*0xf1c000000000077c*/
            if ( __eh34_unwind(14) ) /*0xf1c0000000000780*/
            {
              RBX::Security::Impersonator::~Impersonator(this: &impersonate); /*0xf1c0000000000784*/
              __eh34_continue_unwinding(14, 13); /*0xf1c0000000000788*/
            }
            __eh34_exit_wind_state(14, 13); /*0xf1c000000000078c*/
            if ( __eh34_unwind(13) ) /*0xf1c0000000000790*/
            {
              RBX::DataModel::LegacyLock::~LegacyLock(this: &function[1]); /*0xf1c0000000000794*/
              __eh34_continue_unwinding(13, 4); /*0xf1c0000000000798*/
            }
            __eh34_exit_wind_state(13, 4); /*0xf1c000000000079c*/
            if ( __eh34_unwind(4) ) /*0xf1c00000000007a0*/
            {
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&streamSizeInBytes); /*0xf1c00000000007a4*/
              __eh34_continue_unwinding(4, 3); /*0xf1c00000000007a8*/
            }
            __eh34_exit_wind_state(4, 3); /*0xf1c00000000007ac*/
            if ( __eh34_unwind(3) ) /*0xf1c00000000007b0*/
            {
              QPointer<MassUpdateWindow>::~QPointer<MassUpdateWindow>(this: (QPointer<FindReplaceLockedScriptsDialog> *)&safeThis); /*0xf1c00000000007b4*/
              __eh34_continue_unwinding(3, 2); /*0xf1c00000000007b8*/
            }
            __eh34_exit_wind_state(3, 2); /*0xf1c00000000007bc*/
          }
        }
        __eh34_exit_try_state(2, 1); /*0xf1c00000000006d0*/
        return result; /*0xf1c00000000006d4*/
      }
      if ( this != nullptr ) /*0x142fae8ba*/
        v10 = QtSharedPointer::ExternalRefCountData::getAndRef(a1: this); /*0x142fae8c5*/
      else
        v10 = nullptr; /*0x142fae8ca*/
      safeThis.wp.d = v10; /*0x142fae8cc*/
      safeThis.wp.value = v4; /*0x142fae8d4*/
      __eh34_enter_wind_state(2, 3); /*0xf1c000000000060c*/
      v11 = (RBX::Graphics::Framebuffer *)operator new(size: 0x18u); /*0x142fae8e1*/
      v12 = v11; /*0x142fae8e6*/
      QWidget = v11; /*0x142fae8e9*/
      if ( v11 != nullptr ) /*0x142fae8fb*/
      {
        *(_OWORD *)&v11->__vftable = 0; /*0x142fae900*/
        LODWORD(v11->device) = 1; /*0x142fae903*/
        HIDWORD(v11->device) = 1; /*0x142fae90a*/
        v11->__vftable = (RBX::Graphics::Framebuffer_vtbl *)std::_Ref_count_obj2<__int64>::`vftable'; /*0x142fae918*/
        v11->resourceListIndex = -1; /*0x142fae91b*/
      }
      v159 = 1; /*0x142fae91f*/
      streamSizeInBytes._Ptr = (__int64 *)&v11->resourceListIndex; /*0x142fae92b*/
      streamSizeInBytes._Rep = (std::_Ref_count_base *)v11; /*0x142fae933*/
      __eh34_enter_wind_state(3, 4); /*0xf1c0000000000604*/
      p_placeReplicatedSizeAvailableSignal = &dataModel._Ptr->placeReplicatedSizeAvailableSignal; /*0x142fae943*/
      ptr[0] = v10; /*0x142fae94a*/
      ptr[1] = v4; /*0x142fae952*/
      if ( v10 != nullptr ) /*0x142fae95d*/
        _InterlockedIncrement(&v10->weakref._q_value._Storage._Value); /*0x142fae95f*/
      if ( v11 != nullptr ) /*0x142fae965*/
        _InterlockedIncrement((volatile signed __int32 *)&v11->device); /*0x142fae967*/
      __wind /*0xf1c000000000066c*/
      {
        __wind /*0xf1c0000000000674*/
        {
          v14 = streamSizeInBytes._Ptr; /*0x142fae96b*/
          *(_QWORD *)&v186 = streamSizeInBytes._Ptr; /*0x142fae973*/
          *((_QWORD *)&v186 + 1) = v11; /*0x142fae97b*/
          v15 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x142fae989*/
          __wind /*0xf1c00000000005e0*/
          {
            parent = v15; /*0x142fae98e*/
            v169.parent = v15; /*0x142fae990*/
            v17 = (RBX::Graphics::Framebuffer *)operator new(size: 0x48u); /*0x142fae99c*/
            v18 = (volatile signed __int32 *)v17; /*0x142fae9a1*/
            QWidget = v17; /*0x142fae9a4*/
            if ( v17 != nullptr ) /*0x142fae9af*/
            {
              LODWORD(v17->__vftable) = 0; /*0x142fae9b3*/
              HIDWORD(v17->__vftable) = 1; /*0x142fae9b5*/
              v17->device = (RBX::Graphics::Device *)rbx::signals::slot_with_functor__lambda_8abb9f1893b22eed115157198ee04238__int_::do_call; /*0x142fae9c3*/
              v17->resourceListIndex = (unsigned __int64)rbx::signals::slot_with_functor__lambda_95d582b32f748d8a04b05ed7d5ee178e___::do_dtor; /*0x142fae9ce*/
              *(_QWORD *)&v17->memoryCategory = 0; /*0x142fae9d2*/
              v17->debugName._Mypair._Myval2._Bx._Ptr = (char *)p_placeReplicatedSizeAvailableSignal; /*0x142fae9d6*/
              *(void **)&v17->debugName._Mypair._Myval2._Bx._Alias[8] = ptr[0]; /*0x142fae9e2*/
              v17->debugName._Mypair._Myval2._Mysize = (unsigned __int64)v4; /*0x142fae9e6*/
              *(_OWORD *)ptr = 0; /*0x142fae9ed*/
              v17->debugName._Mypair._Myval2._Myres = (unsigned __int64)v14; /*0x142fae9f6*/
              *(_QWORD *)&v17->width = v12; /*0x142fae9fa*/
              v186 = 0; /*0x142fae9fe*/
            }
            rbx::signals::signal_base::insert( /*0x142faea0d*/
              this: p_placeReplicatedSizeAvailableSignal,
              item: (rbx::signals::slot_base *)v17);
            v227 = v18; /*0x142faea12*/
            if ( v18 != nullptr ) /*0x142faea1d*/
            {
              _InterlockedIncrement(v18 + 1); /*0x142faea1f*/
              parent = v169.parent; /*0x142faea23*/
            }
            v159 = 3; /*0x142faea2a*/
          }
          __unwind
          {
            RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v169); /*0xf1c00000000005f0*/
          }
          __wind /*0xf1c00000000005f8*/
          {
            RBX::Memory::setCurrentCategory(category: parent); /*0x142faea34*/
          }
          __unwind
          {
            __std_terminate(a1: v19, a2: v158); /*0x142f39fa8*/
          }
          v159 = 1; /*0x142faea3a*/
          if ( v18 != nullptr && _InterlockedExchangeAdd(v18 + 1, 0xFFFFFFFF) == 1 ) /*0x142faea52*/
            operator delete(ptr: (void *)v18); /*0x142faea57*/
          if ( *((_QWORD *)&v186 + 1) != 0 /*0x142faea75*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)(*((_QWORD *)&v186 + 1) + 8LL), 0xFFFFFFFF) == 1 )
          {
            (***((void (__fastcall ****)(_QWORD))&v186 + 1))(a1: *((_QWORD *)&v186 + 1)); /*0x142faea85*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)(*((_QWORD *)&v186 + 1) + 12LL), 0xFFFFFFFF) == 1 ) /*0x142faea92*/
              (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v186 + 1) + 8LL))(a1: *((_QWORD *)&v186 + 1)); /*0x142faea9f*/
          }
          if ( ptr[0] != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)ptr[0], 0xFFFFFFFF) == 1 ) /*0x142faeabe*/
            operator delete(ptr: ptr[0]); /*0x142faeac8*/
          p_gameLoadedSignal = &dataModel._Ptr->gameLoadedSignal; /*0x142faead5*/
          v188[0] = safeThis.wp.d; /*0x142faeae4*/
          v188[1] = v4; /*0x142faeaec*/
          if ( safeThis.wp.d != nullptr ) /*0x142faeaf7*/
            _InterlockedIncrement(&safeThis.wp.d->weakref._q_value._Storage._Value); /*0x142faeaf9*/
          if ( v12 != nullptr ) /*0x142faeaff*/
            _InterlockedIncrement((volatile signed __int32 *)&v12->device); /*0x142faeb01*/
        }
        __unwind
        {
        }
      }
      __unwind
      {
        lambda_280be0a152e4142550b583fe8fca28fc_::__lambda_280be0a152e4142550b583fe8fca28fc_(a1: ptr); /*0xf1c0000000000690*/
      }
      __wind /*0xf1c0000000000698*/
      {
        __wind /*0xf1c00000000006a0*/
        {
          v21 = streamSizeInBytes._Ptr; /*0x142faeb05*/
          *(_QWORD *)&v189 = streamSizeInBytes._Ptr; /*0x142faeb0d*/
          *((_QWORD *)&v189 + 1) = v12; /*0x142faeb15*/
          v22 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x142faeb23*/
          __wind /*0xf1c00000000005b0*/
          {
            v23 = v22; /*0x142faeb28*/
            v170.parent = v22; /*0x142faeb2a*/
            v24 = (RBX::Graphics::Framebuffer *)operator new(size: 0x48u); /*0x142faeb36*/
            v25 = (rbx::signals::slot_base *)v24; /*0x142faeb3b*/
            QWidget = v24; /*0x142faeb3e*/
            if ( v24 != nullptr ) /*0x142faeb49*/
            {
              LODWORD(v24->__vftable) = 0; /*0x142faeb4d*/
              HIDWORD(v24->__vftable) = 1; /*0x142faeb4f*/
              v24->device = (RBX::Graphics::Device *)rbx::signals::slot_with_functor__lambda_ecaf9e0281ddd9afc415511fc31e8c92___::do_call; /*0x142faeb5d*/
              v24->resourceListIndex = (unsigned __int64)rbx::signals::slot_with_functor__lambda_95d582b32f748d8a04b05ed7d5ee178e___::do_dtor; /*0x142faeb68*/
              *(_QWORD *)&v24->memoryCategory = 0; /*0x142faeb6c*/
              v24->debugName._Mypair._Myval2._Bx._Ptr = (char *)p_gameLoadedSignal; /*0x142faeb70*/
              *(_QWORD *)&v24->debugName._Mypair._Myval2._Bx._Alias[8] = safeThis.wp.d; /*0x142faeb7c*/
              v24->debugName._Mypair._Myval2._Mysize = (unsigned __int64)v4; /*0x142faeb80*/
              *(_OWORD *)v188 = 0; /*0x142faeb87*/
              v24->debugName._Mypair._Myval2._Myres = (unsigned __int64)v21; /*0x142faeb90*/
              *(_QWORD *)&v24->width = v12; /*0x142faeb94*/
              v189 = 0; /*0x142faeb98*/
            }
            rbx::signals::signal_base::insert(this: p_gameLoadedSignal, item: (rbx::signals::slot_base *)v24); /*0x142faeba7*/
            other.weak_slot.p_ = v25; /*0x142faebac*/
            if ( v25 != nullptr ) /*0x142faebb7*/
            {
              _InterlockedIncrement(&v25->weak._Storage._Value); /*0x142faebb9*/
              v23 = v170.parent; /*0x142faebbd*/
            }
            v159 = 5; /*0x142faebc4*/
          }
          __unwind
          {
            RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v170); /*0xf1c00000000005c0*/
          }
          __wind /*0xf1c00000000005c8*/
          {
            RBX::Memory::setCurrentCategory(category: v23); /*0x142faebce*/
          }
          __unwind
          {
            __std_terminate(a1: v26, a2: v158); /*0xf1c0000000000094*/
          }
          if ( rbx::signals::connection::operator!=(this: &v4->m_gameLoadedConnection.con, &other) ) /*0x142faebe3*/
          {
            rbx::signals::connection::disconnect(this: &v4->m_gameLoadedConnection.con); /*0x142faebf3*/
            rbx::signals::connection::operator=(this: &v4->m_gameLoadedConnection.con, con: &other); /*0x142faec07*/
          }
        }
        __unwind
        {
          v159 &= ~4u; /*0x1432c9593*/
          rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&other); /*0x1432c959e*/
        }
        p = other.weak_slot.p_; /*0x142faec0d*/
        if ( other.weak_slot.p_ != nullptr /*0x142faec25*/
          && _InterlockedExchangeAdd(&other.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
        {
          operator delete(ptr: p); /*0x142faec27*/
        }
        if ( *((_QWORD *)&v189 + 1) != 0 /*0x142faec45*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)(*((_QWORD *)&v189 + 1) + 8LL), 0xFFFFFFFF) == 1 )
        {
          v28 = *((_QWORD *)&v189 + 1); /*0x142faec47*/
          (***((void (__fastcall ****)(_QWORD))&v189 + 1))(a1: *((_QWORD *)&v189 + 1)); /*0x142faec55*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v28 + 12), 0xFFFFFFFF) == 1 ) /*0x142faec62*/
            (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v189 + 1) + 8LL))(a1: *((_QWORD *)&v189 + 1)); /*0x142faec6f*/
        }
        if ( v188[0] != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)v188[0], 0xFFFFFFFF) == 1 ) /*0x142faec8e*/
          operator delete(ptr: v188[0]); /*0x142faec98*/
      }
      __unwind
      {
        lambda_280be0a152e4142550b583fe8fca28fc_::__lambda_280be0a152e4142550b583fe8fca28fc_(a1: v188); /*0xf1c0000000000590*/
      }
      v29 = StudioTimingStatistics::getInstance(); /*0x142faeca2*/
      v29->teamCreateReplicateDataModelTime.startTime = RBX::Time::nowFastSec(); /*0x142faecaa*/
      *(_OWORD *)&function[3].implementation._Mypair._Myval2 = 0; /*0x142faecb2*/
      if ( dataModel._Rep != nullptr ) /*0x142faecc6*/
        _InterlockedIncrement((volatile signed __int32 *)&dataModel._Rep->_Uses); /*0x142faecc8*/
      *(std::shared_ptr<RBX::DataModel> *)&function[3].implementation._Mypair._Myval2 = dataModel; /*0x142faecd4*/
      RBX::DataModel::LegacyLock::LegacyLock( /*0x142faecf3*/
        this: &function[1],
        dataModel: (std::shared_ptr<RBX::DataModel> *)&function[3],
        taskType: (RBX::DMTaskType)1);
      __eh34_enter_wind_state(4, 13); /*0xf1c0000000000584*/
      v226 = *RBX::Security::Identity::Identity(this: &v263, type: COM, assetId: 0, scriptContext: nullptr); /*0x142faed13*/
      RBX::Security::Impersonator::Impersonator(this: &impersonate, identity: &v226); /*0x142faed39*/
      __eh34_enter_wind_state(13, 14); /*0xf1c000000000057c*/
      v30 = (RBX::Graphics::DeviceD3D11 *)DEPRECATED_RobloxUser::singleton(); /*0x142faed3f*/
      QWidget = PluginQWidgetRelay::getQWidget(this: v30); /*0x142faed4c*/
      p_Ptr = &v4->m_config._Ptr; /*0x142faed54*/
      fieldName._Mypair._Myval2._Myres = 15; /*0x142faed62*/
      fieldName._Mypair._Myval2._Mysize = 6; /*0x142faed6e*/
      *(_DWORD *)fieldName._Mypair._Myval2._Bx._Buf = *(_DWORD *)"GameId"; /*0x142faed80*/
      *(_DWORD *)&fieldName._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"Id"; /*0x142faed8e*/
      __wind /*0xf1c0000000000570*/
      {
        v32 = EntityProperties::get<std::string>(this: *p_Ptr, result: &v243, &fieldName); /*0x142faedb0*/
        v33 = &RBX::Http::gameID; /*0x142faedb8*/
        std::string::operator=(this: &RBX::Http::gameID, _Right: (std::string *)v32); /*0x142faedc2*/
        if ( v243._Has_value ) /*0x142faedce*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v243); /*0x142faedd8*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&fieldName); /*0xf1c0000000000568*/
      }
      if ( fieldName._Mypair._Myval2._Myres >= 0x10 ) /*0x142faedea*/
      {
        v34 = fieldName._Mypair._Myval2._Bx._Ptr; /*0x142faedef*/
        if ( fieldName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142faee01*/
        {
          v34 = *((char **)fieldName._Mypair._Myval2._Bx._Ptr - 1); /*0x142faee07*/
          if ( (unsigned __int64)(fieldName._Mypair._Myval2._Bx._Ptr - v34 - 8) > 0x1F ) /*0x142faee16*/
            _invalid_parameter_noinfo_noreturn(); /*0x142faee18*/
        }
        operator delete(ptr: v34); /*0x142faee1f*/
      }
      __wind /*0xf1c00000000004fc*/
      {
        v205._Mypair._Myval2._Myres = 15; /*0x142faee24*/
        v205._Mypair._Myval2._Mysize = 10; /*0x142faee30*/
        strcpy(v205._Mypair._Myval2._Bx._Buf, "UniverseId"); /*0x142faee44*/
        Value = EntityProperties::getConverted<__int64>(this: *p_Ptr, result: &v252, fieldName: &v205)->_Value; /*0x142faee7c*/
        if ( v205._Mypair._Myval2._Myres >= 0x10 ) /*0x142faee8b*/
        {
          v36 = v205._Mypair._Myval2._Bx._Ptr; /*0x142faee90*/
          if ( v205._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142faeea2*/
          {
            v36 = *((char **)v205._Mypair._Myval2._Bx._Ptr - 1); /*0x142faeea8*/
            if ( (unsigned __int64)(v205._Mypair._Myval2._Bx._Ptr - v36 - 8) > 0x1F ) /*0x142faeeb7*/
              _invalid_parameter_noinfo_noreturn(); /*0x142faeeb9*/
          }
          operator delete(ptr: v36); /*0x142faeec0*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v205); /*0xf1c000000000050c*/
      }
      __wind /*0xf1c0000000000514*/
      {
        v198 = 15; /*0x142faeecd*/
        v197[2] = 7; /*0x142faeed9*/
        qmemcpy(v197, "PlaceI", 6); /*0x142faeeeb*/
        HIWORD(v197[0]) = (unsigned __int8)aPlaceid_16[6]; /*0x142faef08*/
        v37 = EntityProperties::getConverted<__int64>(this: *p_Ptr, result: &v251, fieldName: (const std::string *)v197)->_Value; /*0x142faef2f*/
        if ( v198 >= 0x10 ) /*0x142faef3e*/
        {
          v38 = (void *)v197[0]; /*0x142faef43*/
          if ( v198 + 1 >= 0x1000 ) /*0x142faef55*/
          {
            v38 = *(void **)(v197[0] - 8LL); /*0x142faef5b*/
            if ( (unsigned __int64)(v197[0] - (_QWORD)v38 - 8LL) > 0x1F ) /*0x142faef6a*/
              _invalid_parameter_noinfo_noreturn(); /*0x142faef6c*/
          }
          operator delete(ptr: v38); /*0x142faef73*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)v197); /*0xf1c0000000000524*/
      }
      __wind /*0xf1c000000000052c*/
      {
        v206._Mypair._Myval2._Myres = 15; /*0x142faef78*/
        v206._Mypair._Myval2._Mysize = 12; /*0x142faef84*/
        strcpy(v206._Mypair._Myval2._Bx._Buf, "DataCenterId"); /*0x142faef98*/
        v39 = EntityProperties::getConverted<int>(this: *p_Ptr, result: &v228, fieldName: &v206); /*0x142faefc9*/
        if ( v39->_Has_value ) /*0x142faefce*/
          centerId = v39->_Value; /*0x142faefd6*/
        else
          centerId = -1; /*0x142faefdf*/
        if ( v206._Mypair._Myval2._Myres >= 0x10 ) /*0x142faeff3*/
        {
          v40 = v206._Mypair._Myval2._Bx._Ptr; /*0x142faeff8*/
          if ( v206._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142faf00a*/
          {
            v40 = *((char **)v206._Mypair._Myval2._Bx._Ptr - 1); /*0x142faf010*/
            if ( (unsigned __int64)(v206._Mypair._Myval2._Bx._Ptr - v40 - 8) > 0x1F ) /*0x142faf01f*/
              _invalid_parameter_noinfo_noreturn(); /*0x142faf021*/
          }
          operator delete(ptr: v40); /*0x142faf028*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v206); /*0xf1c000000000053c*/
      }
      __wind /*0xf1c0000000000544*/
      {
        v184._Mypair._Myval2._Myres = 15; /*0x142faf02d*/
        v184._Mypair._Myval2._Mysize = 14; /*0x142faf039*/
        strcpy(v184._Mypair._Myval2._Bx._Buf, "MachineAddress"); /*0x142faf04d*/
        v41 = EntityProperties::get<std::string>(this: *p_Ptr, result: &v244, fieldName: &v184); /*0x142faf08d*/
        serverAddress._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142faf092*/
        serverAddress._Mypair._Myval2._Mysize = 0; /*0x142faf09a*/
        serverAddress._Mypair._Myval2._Myres = 0; /*0x142faf0a2*/
        serverAddress = (std::string)v41->___u0; /*0x142faf0ad*/
        v41->_Value._Mypair._Myval2._Mysize = 0; /*0x142faf0c1*/
        v41->_Value._Mypair._Myval2._Myres = 15; /*0x142faf0c5*/
        v41->_Value._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142faf0cd*/
        if ( v244._Has_value ) /*0x142faf0d8*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v244); /*0x142faf0e2*/
        if ( v184._Mypair._Myval2._Myres >= 0x10 ) /*0x142faf0f4*/
        {
          v42 = v184._Mypair._Myval2._Bx._Ptr; /*0x142faf0f9*/
          if ( v184._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142faf10b*/
          {
            v42 = *((char **)v184._Mypair._Myval2._Bx._Ptr - 1); /*0x142faf111*/
            if ( (unsigned __int64)(v184._Mypair._Myval2._Bx._Ptr - v42 - 8) > 0x1F ) /*0x142faf120*/
              _invalid_parameter_noinfo_noreturn(); /*0x142faf122*/
          }
          operator delete(ptr: v42); /*0x142faf129*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v184); /*0xf1c0000000000554*/
      }
      __eh34_enter_wind_state(14, 21); /*0xf1c000000000055c*/
      v184._Mypair._Myval2._Mysize = 0; /*0x142faf12e*/
      v184._Mypair._Myval2._Myres = 15; /*0x142faf136*/
      v184._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142faf142*/
      v43 = *p_Ptr; /*0x142faf14a*/
      v207._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142faf14f*/
      v207._Mypair._Myval2._Mysize = 0; /*0x142faf157*/
      v207._Mypair._Myval2._Myres = 15; /*0x142faf15f*/
      std::string::assign(this: &v207, _Ptr: "ServerPort", _Count: 0xAu); /*0x142faf185*/
      __wind /*0xf1c00000000004f0*/
      {
        v161 = EntityProperties::get<int>(this: v43, result: &v229, fieldName: &v207)->_Value; /*0x142faf1a5*/
        if ( v207._Mypair._Myval2._Myres >= 0x10 ) /*0x142faf1b8*/
        {
          v44 = v207._Mypair._Myval2._Bx._Ptr; /*0x142faf1bd*/
          if ( v207._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142faf1cf*/
          {
            v44 = *((char **)v207._Mypair._Myval2._Bx._Ptr - 1); /*0x142faf1d5*/
            if ( (unsigned __int64)(v207._Mypair._Myval2._Bx._Ptr - v44 - 8) > 0x1F ) /*0x142faf1e4*/
              _invalid_parameter_noinfo_noreturn(); /*0x142faf1e6*/
          }
          operator delete(ptr: v44); /*0x142faf1ed*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v207); /*0xf1c00000000004e8*/
      }
      RBX::DataModel::setPlaceIdAndDataCenterId(this: dataModel._Ptr, placeID: v37, centerId); /*0x142faf208*/
      RBX::DataModel::setUniverseId(this: dataModel._Ptr, uId: Value); /*0x142faf213*/
      v183 = TeamCreateDisconnectInfo::getInstance(); /*0x142faf21d*/
      if ( FLog::Output != 0 ) /*0x142faf22e*/
      {
        p_serverAddress = &serverAddress; /*0x142faf230*/
        if ( serverAddress._Mypair._Myval2._Myres >= 0x10 ) /*0x142faf241*/
          p_serverAddress = (std::string *)serverAddress._Mypair._Myval2._Bx._Ptr; /*0x142faf241*/
        v46 = &RBX::Http::gameID; /*0x142faf24a*/
        if ( RBX::Http::gameID._Mypair._Myval2._Myres >= 0x10 ) /*0x142faf255*/
          v46 = (std::string *)RBX::Http::gameID._Mypair._Myval2._Bx._Ptr; /*0x142faf255*/
        FLog::FastLogFormatted( /*0x142faf279*/
          level: FLog::Output,
          message: "[FLog::Output] Joining game %s place %lld at [%s]:%d",
          v46->_Mypair._Myval2._Bx._Buf,
          v37,
          p_serverAddress->_Mypair._Myval2._Bx._Buf,
          v161);
      }
      Mysize = psc->_Ptr[8].fileName._Mypair._Myval2._Mysize; /*0x142faf289*/
      std::string::string( /*0x142faf29f*/
        this: &v218,
        __that: (const rtc::webrtc_checks_impl::ToStringVal *)&psc->_Ptr[8].fileName._Mypair._Myval2._Myres);
      LODWORD(v160) = 17; /*0x142faf2a9*/
      v159 = 17; /*0x142faf2ad*/
      __wind
      {
        v48 = &v218; /*0x142faf2b1*/
        if ( v218.val._Mypair._Myval2._Myres >= 0x10 ) /*0x142faf2c2*/
          v48 = (rtc::webrtc_checks_impl::ToStringVal *)v218.val._Mypair._Myval2._Bx._Ptr; /*0x142faf2c2*/
        if ( v218.val._Mypair._Myval2._Mysize != 4 ) /*0x142faf2d4*/
          goto LABEL_129; /*0x142faf2d4*/
        v49 = 0; /*0x142faf2d6*/
        while ( 1 ) /*0x142faf2e0*/
        {
          v50 = v48->val._Mypair._Myval2._Bx._Buf[v49++]; /*0x142faf2e0*/
          if ( v50 != *((_BYTE *)&RBX::Studio::EditDataModel::`vftable'[19] + v49 + 7) ) /*0x142faf2ec*/
            break; /*0x142faf2ec*/
          if ( v49 == 4 ) /*0x142faf2f2*/
          {
            v51 = 0; /*0x142faf2f4*/
            goto LABEL_127; /*0x142faf2f6*/
          }
        }
        v51 = v50 < *((_BYTE *)&RBX::Studio::EditDataModel::`vftable'[19] + v49 + 7) ? -1 : 1;
LABEL_127:
        if ( v51 != 0 ) /*0x142faf2ff*/
LABEL_129:
          v52 = 1; /*0x142faf306*/
        else
          v52 = 0; /*0x142faf301*/
        v53 = dataModel._Ptr; /*0x142faf30f*/
        RBX::DataModel::setCreatorID(this: dataModel._Ptr, creatorID: Mysize, creatorType: v52); /*0x142faf31a*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v218); /*0xf1c00000000004d0*/
      }
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v218); /*0x142faf328*/
      if ( RBX::Http::gameID._Mypair._Myval2._Myres >= 0x10 ) /*0x142faf33c*/
        v33 = (std::string *)RBX::Http::gameID._Mypair._Myval2._Bx._Ptr; /*0x142faf33c*/
      v215.Data = (const char *)v33; /*0x142faf344*/
      v215.Length = RBX::Http::gameID._Mypair._Myval2._Mysize; /*0x142faf34c*/
      v232 = v215; /*0x142faf35c*/
      v54 = Mysize; /*0x142faf365*/
      v55 = v183; /*0x142faf373*/
      TeamCreateDisconnectInfo::setUserPlaceInfo(this: v183, placeinstanceid: &v232, universeid: Value, creatorid: v54); /*0x142faf37e*/
      v56 = &serverAddress; /*0x142faf383*/
      if ( serverAddress._Mypair._Myval2._Myres >= 0x10 ) /*0x142faf394*/
        v56 = (std::string *)serverAddress._Mypair._Myval2._Bx._Ptr; /*0x142faf394*/
      v217.Data = (const char *)v56; /*0x142faf39d*/
      v217.Length = serverAddress._Mypair._Myval2._Mysize; /*0x142faf3ad*/
      v225 = v217; /*0x142faf3bd*/
      TeamCreateDisconnectInfo::setServerInfo(this: v55, datacenterid: centerId, serveraddress: &v225, serverport: v161); /*0x142faf3e0*/
      v57 = &v53->RBX::Described<RBX::DataModel,RBX::ServiceProvider>; /*0x142faf3e5*/
      v178 = v57; /*0x142faf3e9*/
      RBX::ServiceProvider::create<RBX::ContentProvider>(this: v57); /*0x142faf3f4*/
      RBX::ServiceProvider::create<RBX::Visit>(this: v57); /*0x142faf3fc*/
      v58 = RBX::ServiceProvider::create<RBX::Network::Client>(this: v57); /*0x142faf409*/
      v165 = v58; /*0x142faf40c*/
      RBX::Network::Client::configureAsCloudEditClient(this: v58); /*0x142faf417*/
      v59 = *p_Ptr; /*0x142faf41c*/
      v60 = nullptr; /*0x142faf41f*/
      v208._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142faf421*/
      v208._Mypair._Myval2._Mysize = 0; /*0x142faf429*/
      v208._Mypair._Myval2._Myres = 15; /*0x142faf431*/
      std::string::assign(this: &v208, _Ptr: "ClientTicket", _Count: 0xCu); /*0x142faf458*/
      __wind /*0xf1c00000000004c0*/
      {
        v61 = EntityProperties::get<std::string>(this: v59, result: &v245, fieldName: &v208); /*0x142faf471*/
        __wind /*0xf1c00000000004b4*/
        {
          RBX::Network::Client::setTicket(this: v58, t: (const std::string *)v61); /*0x142faf47d*/
        }
        __unwind
        {
          std::optional<std::string>::~optional<std::string>(this: (Luau::FunctionDefinition *)&v245); /*0xf1c00000000004ac*/
        }
        if ( v245._Has_value ) /*0x142faf48b*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v245); /*0x142faf495*/
        if ( v208._Mypair._Myval2._Myres >= 0x10 ) /*0x142faf4a7*/
        {
          v62 = v208._Mypair._Myval2._Bx._Ptr; /*0x142faf4ac*/
          if ( v208._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142faf4be*/
          {
            v62 = *((char **)v208._Mypair._Myval2._Bx._Ptr - 1); /*0x142faf4c4*/
            if ( (unsigned __int64)(v208._Mypair._Myval2._Bx._Ptr - v62 - 8) > 0x1F ) /*0x142faf4d3*/
              _invalid_parameter_noinfo_noreturn(); /*0x142faf4d5*/
          }
          operator delete(ptr: v62); /*0x142faf4dc*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v208); /*0xf1c00000000004a0*/
      }
      v63 = *p_Ptr; /*0x142faf4e1*/
      v209._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142faf4e4*/
      v209._Mypair._Myval2._Mysize = 0; /*0x142faf4ec*/
      v209._Mypair._Myval2._Myres = 15; /*0x142faf4f4*/
      std::string::assign(this: &v209, _Ptr: "SessionId", _Count: 9u); /*0x142faf51d*/
      __wind /*0xf1c0000000000490*/
      {
        v64 = EntityProperties::get<std::string>(this: v63, result: &v246, fieldName: &v209); /*0x142faf536*/
        __wind /*0xf1c000000000046c*/
        {
          v212._Value._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142faf53c*/
          *(_OWORD *)&v212._Value._Mypair._Myval2._Mysize = 0u; /*0x142faf544*/
          v212._Value = (std::string)v64->___u0; /*0x142faf557*/
          v64->_Value._Mypair._Myval2._Mysize = 0; /*0x142faf56b*/
          v64->_Value._Mypair._Myval2._Myres = 15; /*0x142faf56f*/
          v64->_Value._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142faf577*/
          RBX::Network::Client::setGameSessionID(this: v58, value: (std::string *)&v212); /*0x142faf585*/
          if ( v246._Has_value ) /*0x142faf593*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v246); /*0x142faf59d*/
          if ( v209._Mypair._Myval2._Myres >= 0x10 ) /*0x142faf5af*/
          {
            v65 = v209._Mypair._Myval2._Bx._Ptr; /*0x142faf5b4*/
            if ( v209._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142faf5c6*/
            {
              v65 = *((char **)v209._Mypair._Myval2._Bx._Ptr - 1); /*0x142faf5cc*/
              if ( (unsigned __int64)(v209._Mypair._Myval2._Bx._Ptr - v65 - 8) > 0x1F ) /*0x142faf5db*/
                _invalid_parameter_noinfo_noreturn(); /*0x142faf5dd*/
            }
            operator delete(ptr: v65); /*0x142faf5e4*/
          }
        }
        __unwind
        {
          std::optional<std::string>::~optional<std::string>(this: (Luau::FunctionDefinition *)&v246); /*0xf1c000000000047c*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v209); /*0xf1c0000000000488*/
      }
      if ( v4->m_isVisibleDM ) /*0x142faf5e9*/
      {
        p_connectionAcceptedSignal = &v58->connectionAcceptedSignal; /*0x142faf5f7*/
        v67 = QtSharedPointer::ExternalRefCountData::getAndRef(a1: this); /*0x142faf609*/
        v68 = v67; /*0x142faf60f*/
        v190 = 0; /*0x142faf615*/
        v69 = this->m_weakDM._Rep; /*0x142faf61e*/
        v70 = nullptr; /*0x142faf622*/
        if ( v69 != nullptr ) /*0x142faf628*/
        {
          v60 = this->m_weakDM._Ptr; /*0x142faf62a*/
          *(_QWORD *)&v190 = v60; /*0x142faf62e*/
          *((_QWORD *)&v190 + 1) = v69; /*0x142faf636*/
          _InterlockedIncrement((volatile signed __int32 *)&v69->_Weaks); /*0x142faf63e*/
          v70 = v69; /*0x142faf642*/
        }
        __wind /*0xf1c00000000006fc*/
        {
          __wind /*0xf1c0000000000704*/
          {
            __wind /*0xf1c000000000070c*/
            {
              v191[0] = v67; /*0x142faf645*/
              v191[1] = this; /*0x142faf64d*/
              v256 = 0; /*0x142faf655*/
              v71 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x142faf664*/
              __wind /*0xf1c0000000000448*/
              {
                v72 = v71; /*0x142faf669*/
                v171.parent = v71; /*0x142faf66b*/
                v73 = (rbx::signals::slot_base *)operator new(size: 0x48u); /*0x142faf677*/
                v74 = v73; /*0x142faf67c*/
                v162 = v73; /*0x142faf67f*/
                if ( v73 != nullptr ) /*0x142faf68a*/
                {
                  v73->strong._Storage._Value = 0; /*0x142faf68e*/
                  v73->weak._Storage._Value = 1; /*0x142faf690*/
                  v73->call = (void (__fastcall *)(rbx::signals::slot_base *))rbx::signals::slot_with_functor__lambda_e3a4fa6bdde7999e22462e2a5a1b3382__std::basic_string_char_std::char_traits_char__std::allocator_char____std::shared_ptr_RBX::Instance___::do_call; /*0x142faf69e*/
                  v73->dtor = rbx::signals::slot_with_functor__lambda_cde54834d08c00cbfb56a3bc80a6d022__bool_::do_dtor; /*0x142faf6a9*/
                  v73->next.px = nullptr; /*0x142faf6ad*/
                  v73->owner = p_connectionAcceptedSignal; /*0x142faf6b1*/
                  v73[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)v60; /*0x142faf6b5*/
                  v73[1].call = (void (__fastcall *)(rbx::signals::slot_base *))v70; /*0x142faf6b9*/
                  v190 = 0; /*0x142faf6c0*/
                  v73[1].dtor = (void (__fastcall *)(rbx::signals::slot_base *))v68; /*0x142faf6c9*/
                  v73[1].next.px = (rbx::signals::slot_base *)this; /*0x142faf6d5*/
                  *(_OWORD *)v191 = 0; /*0x142faf6d9*/
                }
                rbx::signals::signal_base::insert(this: p_connectionAcceptedSignal, item: v73); /*0x142faf6e8*/
                con.weak_slot.p_ = v74; /*0x142faf6ed*/
                if ( v74 != nullptr ) /*0x142faf6f8*/
                {
                  _InterlockedIncrement(&v74->weak._Storage._Value); /*0x142faf6fa*/
                  v72 = v171.parent; /*0x142faf6fe*/
                }
                v159 = 49; /*0x142faf705*/
              }
              __unwind
              {
                RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v171); /*0xf1c0000000000458*/
              }
              __wind /*0xf1c0000000000460*/
              {
                RBX::Memory::setCurrentCategory(category: v72); /*0x142faf70f*/
              }
              __unwind
              {
                __std_terminate(a1: v75, a2: v158); /*0xf1c000000000009c*/
              }
              v4 = this; /*0x142faf715*/
              rbx::signals::scoped_connection::operator=(this: &this->m_connectionAcceptedConnection, &con); /*0x142faf72c*/
              v159 = 17; /*0x142faf731*/
            }
            __unwind
            {
            }
            v76 = con.weak_slot.p_; /*0x142faf739*/
            if ( con.weak_slot.p_ != nullptr /*0x142faf751*/
              && _InterlockedExchangeAdd(&con.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
            {
              operator delete(ptr: v76); /*0x142faf753*/
            }
            if ( v191[0] != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)v191[0], 0xFFFFFFFF) == 1 ) /*0x142faf775*/
              operator delete(ptr: v191[0]); /*0x142faf77f*/
            if ( *((_QWORD *)&v190 + 1) != 0 /*0x142faf79c*/
              && _InterlockedExchangeAdd((volatile signed __int32 *)(*((_QWORD *)&v190 + 1) + 12LL), 0xFFFFFFFF) == 1 )
            {
              (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v190 + 1) + 8LL))(a1: *((_QWORD *)&v190 + 1)); /*0x142faf7a9*/
            }
          }
          __unwind
          {
            lambda_cde54834d08c00cbfb56a3bc80a6d022_::__lambda_cde54834d08c00cbfb56a3bc80a6d022_(a1: &v190); /*0xf1c00000000006dc*/
          }
        }
        __unwind
        {
          QPointer<MassUpdateWindow>::~QPointer<MassUpdateWindow>(this: &v256); /*0xf1c00000000006e8*/
        }
        __wind /*0xf1c00000000006f0*/
        {
          v91 = v165; /*0x142faf7ad*/
          p_connectionFailedSignal = &v165->connectionFailedSignal; /*0x142faf7b5*/
          v78 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x142faf7c3*/
          __wind /*0xf1c000000000040c*/
          {
            v79 = v78; /*0x142faf7c8*/
            v172.parent = v78; /*0x142faf7ca*/
            v80 = (rbx::signals::slot_base *)operator new(size: 0x30u); /*0x142faf7d6*/
            v81 = v80; /*0x142faf7db*/
            v162 = v80; /*0x142faf7de*/
            if ( v80 != nullptr ) /*0x142faf7e9*/
            {
              v80->strong._Storage._Value = 0; /*0x142faf7eb*/
              v80->weak._Storage._Value = 1; /*0x142faf7f1*/
              v80->call = (void (__fastcall *)(rbx::signals::slot_base *))rbx::signals::slot_with_functor__lambda_423c6ea87389674b0d913a88f4d3dbac__std::basic_string_char_std::char_traits_char__std::allocator_char____int_std::basic_string_char_std::char_traits_char__std::allocator_char_____::do_call; /*0x142faf7ff*/
              v80->dtor = (void (__fastcall *)(rbx::signals::slot_base *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x142faf80a*/
              v80->next.px = nullptr; /*0x142faf80e*/
              v80->owner = p_connectionFailedSignal; /*0x142faf816*/
            }
            rbx::signals::signal_base::insert(this: p_connectionFailedSignal, item: v80); /*0x142faf820*/
            v182.weak_slot.p_ = v81; /*0x142faf825*/
            if ( v81 != nullptr ) /*0x142faf830*/
            {
              _InterlockedIncrement(&v81->weak._Storage._Value); /*0x142faf832*/
              v79 = v172.parent; /*0x142faf836*/
            }
            v159 = 81; /*0x142faf83d*/
          }
          __unwind
          {
            RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v172); /*0xf1c000000000041c*/
          }
          __wind /*0xf1c0000000000424*/
          {
            RBX::Memory::setCurrentCategory(category: v79); /*0x142faf847*/
          }
          __unwind
          {
            __std_terminate(a1: v82, a2: v158); /*0xf1c00000000000a4*/
          }
          rbx::signals::scoped_connection::operator=(this: &v4->m_connectionFailedConnection, con: &v182); /*0x142faf85c*/
          v83 = 17; /*0x142faf861*/
          LODWORD(v160) = 17; /*0x142faf866*/
          v159 = 17; /*0x142faf86a*/
        }
        __unwind
        {
        }
        v84 = v182.weak_slot.p_; /*0x142faf86e*/
        if ( v182.weak_slot.p_ == nullptr ) /*0x142faf879*/
          goto LABEL_178; /*0x142faf879*/
        if ( _InterlockedExchangeAdd(&v182.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x142faf886*/
        {
          operator delete(ptr: v84); /*0x142faf88c*/
          v83 = v159; /*0x142faf891*/
          LODWORD(v160) = v159; /*0x142faf895*/
LABEL_178:
          p_Ptr = &v4->m_config._Ptr; /*0x142faf899*/
          goto LABEL_195; /*0x142faf89d*/
        }
        goto LABEL_192; /*0x142faf886*/
      }
      RBX::Network::Peer::disableTimeout(this: v58); /*0x142faf8a5*/
      if ( v4->m_onFailedSignalCallBack._Mystorage._Ptrs[7] != nullptr ) /*0x142faf8b2*/
      {
        v85 = &v58->connectionFailedSignal; /*0x142faf8b8*/
        __wind /*0xf1c00000000003e8*/
        {
          v89 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x142faf8ca*/
          v173.parent = v89; /*0x142faf8cc*/
          __wind /*0xf1c00000000003ac*/
          {
            v86 = operator new(size: 0x68u); /*0x142faf8d8*/
            v88 = (rbx::signals::slot_base *)v86; /*0x142faf8dd*/
            v162 = (rbx::signals::slot_base *)v86; /*0x142faf8e0*/
            __wind /*0xf1c00000000003a0*/
            {
              if ( v86 != nullptr ) /*0x142faf8eb*/
              {
                *v86 = 0; /*0x142faf8ed*/
                v86[1] = 1; /*0x142faf8ef*/
                *((_QWORD *)v86 + 1) = rbx::signals::slot_with_functor<std::function<void (std::string,int,std::string)>,std::string,int,std::string>::do_call; /*0x142faf8fd*/
                *((_QWORD *)v86 + 2) = std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>::~pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>; /*0x142faf908*/
                *((_QWORD *)v86 + 3) = 0; /*0x142faf90c*/
                *((_QWORD *)v86 + 4) = v85; /*0x142faf910*/
                v160 = (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)(v86 + 10); /*0x142faf918*/
                *((_QWORD *)v86 + 12) = 0; /*0x142faf91d*/
                v87 = v4->m_onFailedSignalCallBack._Mystorage._Ptrs[7]; /*0x142faf925*/
                if ( v87 != nullptr ) /*0x142faf92f*/
                {
                  __wind /*0xf1c0000000000658*/
                  {
                    __wind /*0xf1c0000000000660*/
                    {
                      *((_QWORD *)v86 + 12) = v87->_Copy(this: v87, a2: v86 + 10); /*0x142faf939*/
                    }
                    __unwind
                    {
                      std::function<void (__int64)>::~function<void (__int64)>(this: v160); /*0xf1c0000000000644*/
                    }
                  }
                  __unwind
                  {
                    rbx::signals::slot_base::~slot_base(this: v162); /*0xf1c0000000000650*/
                  }
                }
              }
              else
              {
                v88 = nullptr; /*0x142faf93f*/
              }
            }
            __unwind
            {
              operator delete(ptr: v162); /*0x143286d05*/
            }
            rbx::signals::signal_base::insert(this: v85, item: v88); /*0x142faf948*/
            v230 = v88; /*0x142faf94d*/
            if ( v88 != nullptr ) /*0x142faf958*/
            {
              _InterlockedIncrement(&v88->weak._Storage._Value); /*0x142faf95a*/
              v89 = v173.parent; /*0x142faf95e*/
            }
          }
          __unwind
          {
            RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v173); /*0xf1c00000000003bc*/
          }
          __wind /*0xf1c00000000003c4*/
          {
            v159 = 145; /*0x142faf965*/
            RBX::Memory::setCurrentCategory(category: v89); /*0x142faf96f*/
          }
          __unwind
          {
            __std_terminate(a1: v90, a2: v158); /*0xf1c00000000000ac*/
          }
        }
        __unwind
        {
          v159 &= ~0x80u; /*0x1432c9625*/
          rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v230); /*0x1432c9633*/
        }
        v83 = 17; /*0x142faf975*/
        LODWORD(v160) = 17; /*0x142faf97a*/
        v159 = 17; /*0x142faf97e*/
        if ( v88 != nullptr ) /*0x142faf985*/
        {
          if ( _InterlockedExchangeAdd(&v88->weak._Storage._Value, 0xFFFFFFFF) != 1 ) /*0x142faf992*/
          {
            v91 = v165; /*0x142faf9aa*/
LABEL_192:
            v83 = v159; /*0x142faf9b2*/
            LODWORD(v160) = v159; /*0x142faf9b6*/
            p_Ptr = &v4->m_config._Ptr; /*0x142faf9ba*/
            goto LABEL_195; /*0x142faf9be*/
          }
          operator delete(ptr: v88); /*0x142faf997*/
          v83 = v159; /*0x142faf99c*/
          LODWORD(v160) = v159; /*0x142faf9a0*/
        }
        p_Ptr = &v4->m_config._Ptr; /*0x142faf9a4*/
      }
      else
      {
        v83 = (int)v160; /*0x142faf9c0*/
      }
      v91 = v165; /*0x142faf9c4*/
LABEL_195:
      v92 = RBX::ServiceProvider::create<RBX::Players>(this: v178); /*0x142faf9cc*/
      if ( !DFFlag::DeprecateLocalPlayerCreatedSignal.value ) /*0x142faf9e3*/
      {
        if ( !v4->m_isVisibleDM ) /*0x142faf9ed*/
          goto LABEL_200; /*0x142faf9ed*/
        v93 = (std::shared_ptr<RBX::File> *)std::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>( /*0x142faf9fa*/
                                              this: &v233,
                                              _Other: (const std::shared_ptr<lm::StageResults> *)p_Ptr);
        CloudEditConnectionModel::connectLocalPlayerCreate_deprecated(this: v4, players: v92, config: v93); /*0x142fafa08*/
      }
      if ( v4->m_isVisibleDM ) /*0x142fafa0d*/
      {
        v94 = StudioTimingStatistics::getInstance(); /*0x142fafa1c*/
        v94->teamPlayerConnectTime.startTime = RBX::Time::nowFastSec(); /*0x142fafa24*/
        CloudEditConnectionModel::connectPlayerReceivedFromServerInCloudEdit(this: v4, players: v92); /*0x142fafa2f*/
      }
LABEL_200:
      memset(&serverConnections, 0, sizeof(serverConnections)); /*0x142fafa34*/
      __eh34_enter_wind_state(21, 42); /*0xf1c000000000038c*/
      if ( DFFlag::RuppHeaderFromClientEnabled3.value ) /*0x142fafa5c*/
      {
        v219._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fafa5e*/
        v219._Mypair._Myval2._Mysize = 0; /*0x142fafa66*/
        v219._Mypair._Myval2._Myres = 15; /*0x142fafa6e*/
        std::string::assign(this: &v219, _Ptr: "ServerConnections", _Count: 0x11u); /*0x142fafa82*/
        v95 = (std::shared_ptr<EntityProperties> *)std::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>( /*0x142fafa92*/
                                                     this: &v234,
                                                     _Other: (const std::shared_ptr<lm::StageResults> *)p_Ptr);
        CloudEditConnectionModel::fillServerConnectionsArrayFromConfig( /*0x142fafaaa*/
          endpoints: &serverConnections,
          config: v95,
          key: &v219);
      }
      else
      {
        v96 = *p_Ptr; /*0x142fafab4*/
        v187._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fafab7*/
        v187._Mypair._Myval2._Mysize = 0; /*0x142fafabf*/
        v187._Mypair._Myval2._Myres = 15; /*0x142fafac7*/
        std::string::assign(this: &v187, _Ptr: "ServerConnections", _Count: 0x11u); /*0x142fafae3*/
        __wind /*0xf1c0000000000368*/
        {
          EntityProperties::get<std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>( /*0x142fafafc*/
            this: v96,
            result: &serverConnectionsArray,
            fieldName: &v187);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v187); /*0xf1c0000000000378*/
        }
        __wind /*0xf1c0000000000380*/
        {
          if ( v187._Mypair._Myval2._Myres >= 0x10 ) /*0x142fafb0e*/
          {
            v97 = v187._Mypair._Myval2._Bx._Ptr; /*0x142fafb13*/
            if ( v187._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fafb25*/
            {
              v97 = *((char **)v187._Mypair._Myval2._Bx._Ptr - 1); /*0x142fafb2b*/
              if ( (unsigned __int64)(v187._Mypair._Myval2._Bx._Ptr - v97 - 8) > 0x1F ) /*0x142fafb3a*/
                _invalid_parameter_noinfo_noreturn(); /*0x142fafb3c*/
            }
            operator delete(ptr: v97); /*0x142fafb43*/
          }
          v187._Mypair._Myval2._Mysize = 0; /*0x142fafb48*/
          v187._Mypair._Myval2._Myres = 15; /*0x142fafb50*/
          v187._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fafb5c*/
          if ( serverConnectionsArray._Has_value && serverConnectionsArray._Value._Ptr != nullptr ) /*0x142fafb7d*/
          {
            Myfirst = serverConnectionsArray._Value._Ptr->_Mypair._Myval2._Myfirst; /*0x142fafb83*/
            Mylast = (RBX::ServiceProvider *)serverConnectionsArray._Value._Ptr->_Mypair._Myval2._Mylast; /*0x142fafb86*/
            v178 = Mylast; /*0x142fafb8a*/
            while ( Myfirst != (RBX::Reflection::Variant *)Mylast ) /*0x142fafba9*/
            {
              RBX::Reflection::Variant::get<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>( /*0x142fafbba*/
                this: Myfirst,
                result: &serverConnection);
              __wind /*0xf1c0000000000350*/
              {
                v100 = (std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<PluginPermissionsFetcher>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > >,0> > *)serverConnection._Ptr; /*0x142fafbc0*/
                _Keyval._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fafbc8*/
                _Keyval._Mypair._Myval2._Mysize = 0; /*0x142fafbd0*/
                _Keyval._Mypair._Myval2._Myres = 15; /*0x142fafbd8*/
                std::string::assign(this: &_Keyval, _Ptr: "Address", _Count: 7u); /*0x142fafbf9*/
                p_Keyval = &_Keyval; /*0x142fafbfe*/
                v102 = _Keyval._Mypair._Myval2._Bx._Ptr; /*0x142fafc06*/
                Myres = _Keyval._Mypair._Myval2._Myres; /*0x142fafc0e*/
                if ( _Keyval._Mypair._Myval2._Myres >= 0x10 ) /*0x142fafc1a*/
                  p_Keyval = (std::string *)_Keyval._Mypair._Myval2._Bx._Ptr; /*0x142fafc1a*/
                v104 = 0xCBF29CE484222325uLL; /*0x142fafc1e*/
                for ( i = 0; i < _Keyval._Mypair._Myval2._Mysize; ++i ) /*0x142fafc2e*/
                  v104 = 0x100000001B3LL * ((unsigned __int8)p_Keyval->_Mypair._Myval2._Bx._Buf[i] ^ v104); /*0x142fafc37*/
                Duplicate = std::_Hash<std::_Umap_traits<std::string,RBX::BatchThumbnailFetcher::BatchThumbnailRequest,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::BatchThumbnailFetcher::BatchThumbnailRequest>>,0>>::_Find_last<std::string>( /*0x142fafc5b*/
                              this: v100,
                              result: &v255,
                              &_Keyval,
                              _Hashval: v104)->_Duplicate;
                if ( Duplicate == nullptr ) /*0x142fafc62*/
                  Duplicate = v100->_List._Mypair._Myval2._Myhead; /*0x142fafc64*/
                if ( Myres >= 0x10 ) /*0x142fafc6c*/
                {
                  v107 = v102; /*0x142fafc72*/
                  if ( Myres + 1 >= 0x1000 ) /*0x142fafc7c*/
                  {
                    v102 = *((char **)v102 - 1); /*0x142fafc82*/
                    if ( (unsigned __int64)(v107 - v102 - 8) > 0x1F ) /*0x142fafc91*/
LABEL_232:
                      _invalid_parameter_noinfo_noreturn(); /*0x142fafd83*/
                  }
                  operator delete(ptr: v102); /*0x142fafc9a*/
                }
                v108 = (std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<PluginPermissionsFetcher>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > >,0> > *)serverConnection._Ptr; /*0x142fafc9f*/
                v200._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fafca9*/
                v200._Mypair._Myval2._Mysize = 0; /*0x142fafcb1*/
                v200._Mypair._Myval2._Myres = 15; /*0x142fafcb9*/
                std::string::assign(this: &v200, _Ptr: "Port", _Count: 4u); /*0x142fafcd8*/
                v109 = &v200; /*0x142fafcdd*/
                v110 = v200._Mypair._Myval2._Bx._Ptr; /*0x142fafce5*/
                v111 = v200._Mypair._Myval2._Myres; /*0x142fafced*/
                if ( v200._Mypair._Myval2._Myres >= 0x10 ) /*0x142fafcf9*/
                  v109 = (std::string *)v200._Mypair._Myval2._Bx._Ptr; /*0x142fafcf9*/
                v112 = 0xCBF29CE484222325uLL; /*0x142fafcfd*/
                for ( j = 0; j < v200._Mypair._Myval2._Mysize; ++j ) /*0x142fafd14*/
                  v112 = 0x100000001B3LL * ((unsigned __int8)v109->_Mypair._Myval2._Bx._Buf[j] ^ v112); /*0x142fafd27*/
                Myhead = std::_Hash<std::_Umap_traits<std::string,RBX::BatchThumbnailFetcher::BatchThumbnailRequest,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::BatchThumbnailFetcher::BatchThumbnailRequest>>,0>>::_Find_last<std::string>( /*0x142fafd4b*/
                           this: v108,
                           result: &v254,
                           _Keyval: &v200,
                           _Hashval: v112)->_Duplicate;
                if ( Myhead == nullptr ) /*0x142fafd52*/
                  Myhead = v108->_List._Mypair._Myval2._Myhead; /*0x142fafd54*/
                if ( v111 >= 0x10 ) /*0x142fafd5c*/
                {
                  v115 = v110; /*0x142fafd62*/
                  if ( v111 + 1 >= 0x1000 ) /*0x142fafd6c*/
                  {
                    v110 = *((char **)v110 - 1); /*0x142fafd72*/
                    if ( (unsigned __int64)(v115 - v110 - 8) > 0x1F ) /*0x142fafd81*/
                      goto LABEL_232; /*0x142fafd81*/
                  }
                  operator delete(ptr: v110); /*0x142fafd8d*/
                }
                v116 = serverConnection._Ptr->_List._Mypair._Myval2._Myhead; /*0x142fafd9a*/
                if ( Duplicate != (std::_List_node<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> >,void *> *)v116 /*0x142fafdaa*/
                  && Myhead != (std::_List_node<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> >,void *> *)v116 )
                {
                  v117 = RBX::Reflection::Variant::get<int>(this: (RBX::Reflection::Variant *)&Myhead->_Myval.second); /*0x142fafdb9*/
                  v174 = v117; /*0x142fafdbb*/
                  v118 = RBX::Reflection::Variant::get<std::string>( /*0x142fafdce*/
                           this: (RBX::Reflection::Variant *)&Duplicate->_Myval.second,
                           result: &v258);
                  __wind /*0xf1c0000000000344*/
                  {
                    v119 = serverConnections._Mypair._Myval2._Mylast; /*0x142fafdd4*/
                    if ( serverConnections._Mypair._Myval2._Mylast == serverConnections._Mypair._Myval2._Myend ) /*0x142fafde4*/
                    {
                      std::vector<RBX::Network::Client::ServerConnection>::_Emplace_reallocate<std::string,int>( /*0x142fafe41*/
                        this: &serverConnections,
                        _Whereptr: serverConnections._Mypair._Myval2._Mylast,
                        <_Val_0>: v118,
                        <_Val_1>: &v174);
                    }
                    else
                    {
                      v238 = *v118; /*0x142fafde9*/
                      v118->_Mypair._Myval2._Mysize = 0; /*0x142fafdfd*/
                      v118->_Mypair._Myval2._Myres = 15; /*0x142fafe05*/
                      v118->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fafe0d*/
                      RBX::Network::Client::ServerConnection::ServerConnection(this: v119, a: &v238, p: v117); /*0x142fafe1b*/
                      ++serverConnections._Mypair._Myval2._Mylast; /*0x142fafe20*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v258); /*0xf1c000000000033c*/
                  }
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v258); /*0x142fafe4f*/
                }
                if ( serverConnection._Rep != nullptr ) /*0x142fafe60*/
                  std::_Ref_count_base::_Decref(this: serverConnection._Rep); /*0x142fafe62*/
                ++Myfirst; /*0x142fafe67*/
                Mylast = v178; /*0x142fafe6b*/
              }
              __unwind
              {
                std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&serverConnection); /*0xf1c0000000000360*/
              }
            }
            v4 = this; /*0x142fafe7a*/
            v83 = (int)v160; /*0x142fafe82*/
            v91 = v165; /*0x142fafe86*/
          }
          std::optional<std::shared_ptr<Luau::Scope>>::~optional<std::shared_ptr<Luau::Scope>>(this: (std::optional<std::shared_ptr<Luau::Scope> > *)&serverConnectionsArray); /*0x142fafe96*/
        }
        __unwind
        {
          std::optional<std::shared_ptr<Luau::Scope>>::~optional<std::shared_ptr<Luau::Scope>>(this: (std::optional<std::shared_ptr<Luau::Scope> > *)&serverConnectionsArray); /*0xf1c0000000000330*/
        }
      }
      anonymous_namespace_::getPlayerInfoSharedValueTable(result: &playerInfo, config: &v4->m_config); /*0x142fafea7*/
      __eh34_enter_wind_state(42, 48); /*0xf1c0000000000634*/
      __eh34_enter_wind_state(48, 49); /*0xf1c0000000000638*/
      memset(&udmuxEndpoint, 0, sizeof(udmuxEndpoint)); /*0x142fafeb0*/
      memset(&token, 0, sizeof(token)); /*0x142fafec3*/
      v120 = 0; /*0x142fafed2*/
      if ( DFFlag::RuppHeaderFromClientEnabled3.value ) /*0x142fafedb*/
      {
        v220._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fafee1*/
        v220._Mypair._Myval2._Mysize = 0; /*0x142fafee9*/
        v220._Mypair._Myval2._Myres = 15; /*0x142fafef1*/
        std::string::assign(this: &v220, _Ptr: "UdmuxEndpoints", _Count: 0xEu); /*0x142faff10*/
        v121 = (std::shared_ptr<EntityProperties> *)std::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>( /*0x142faff21*/
                                                      this: &v235,
                                                      _Other: (const std::shared_ptr<lm::StageResults> *)&v4->m_config);
        CloudEditConnectionModel::fillServerConnectionsArrayFromConfig( /*0x142faff39*/
          endpoints: &udmuxEndpoint,
          config: v121,
          key: &v220);
        v122 = v4->m_config._Ptr; /*0x142faff3e*/
        v210._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142faff44*/
        v210._Mypair._Myval2._Mysize = 0; /*0x142faff4c*/
        v210._Mypair._Myval2._Myres = 15; /*0x142faff54*/
        std::string::assign(this: &v210, _Ptr: "DirectServerReturn", _Count: 0x12u); /*0x142faff7a*/
        __wind /*0xf1c0000000000320*/
        {
          v123 = EntityProperties::get<bool>(this: v122, result: &v267, fieldName: &v210); /*0x142faff93*/
          v120 = !v123->_Has_value || v123->_Value; /*0x142faff9e*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v210); /*0xf1c0000000000318*/
        }
        if ( v210._Mypair._Myval2._Myres >= 0x10 ) /*0x142faffb3*/
        {
          v124 = v210._Mypair._Myval2._Bx._Ptr; /*0x142faffb8*/
          if ( v210._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142faffca*/
          {
            v124 = *((char **)v210._Mypair._Myval2._Bx._Ptr - 1); /*0x142faffd0*/
            if ( (unsigned __int64)(v210._Mypair._Myval2._Bx._Ptr - v124 - 8) > 0x1F ) /*0x142faffdf*/
              _invalid_parameter_noinfo_noreturn(); /*0x142faffe1*/
          }
          operator delete(ptr: v124); /*0x142faffe8*/
        }
        v125 = v4->m_config._Ptr; /*0x142faffed*/
        v211._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fafff3*/
        v211._Mypair._Myval2._Mysize = 0; /*0x142fafffb*/
        v211._Mypair._Myval2._Myres = 15; /*0x142fb0003*/
        std::string::assign(this: &v211, _Ptr: "TokenValue", _Count: 0xAu); /*0x142fb002a*/
        __wind /*0xf1c0000000000308*/
        {
          v126 = EntityProperties::get<std::string>(this: v125, result: &v247, fieldName: &v211); /*0x142fb0043*/
          __wind /*0xf1c00000000002b8*/
          {
            if ( v126->_Has_value ) /*0x142fb0049*/
            {
              tokenValue = (std::string)v126->___u0; /*0x142fb0052*/
              v126->_Value._Mypair._Myval2._Mysize = 0; /*0x142fb0066*/
              v126->_Value._Mypair._Myval2._Myres = 15; /*0x142fb006a*/
              v126->_Value._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb0072*/
            }
            else
            {
              tokenValue._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb0077*/
              tokenValue._Mypair._Myval2._Mysize = 0; /*0x142fb007f*/
              tokenValue._Mypair._Myval2._Myres = 15; /*0x142fb0087*/
              std::string::assign(this: &tokenValue, _Ptr: pass, _Count: 0); /*0x142fb00ad*/
            }
            v127 = v83 | 0x100; /*0x142fb00b2*/
            LODWORD(v160) = v127; /*0x142fb00b6*/
          }
          __unwind
          {
            std::optional<std::string>::~optional<std::string>(this: (Luau::FunctionDefinition *)&v247); /*0xf1c00000000002c8*/
          }
          __wind /*0xf1c00000000002d0*/
          {
            if ( v247._Has_value ) /*0x142fb00c2*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v247); /*0x142fb00cc*/
            if ( v211._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb00de*/
            {
              v128 = v211._Mypair._Myval2._Bx._Ptr; /*0x142fb00e3*/
              if ( v211._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb00f5*/
              {
                v128 = *((char **)v211._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb00fb*/
                if ( (unsigned __int64)(v211._Mypair._Myval2._Bx._Ptr - v128 - 8) > 0x1F ) /*0x142fb010a*/
                  _invalid_parameter_noinfo_noreturn(); /*0x142fb010c*/
              }
              operator delete(ptr: v128); /*0x142fb0113*/
            }
            tokenValueDecode._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb0118*/
            tokenValueDecode._Mypair._Myval2._Mysize = 0; /*0x142fb0120*/
            tokenValueDecode._Mypair._Myval2._Myres = 15; /*0x142fb0128*/
            p_tokenValue = &tokenValue; /*0x142fb013c*/
            v130 = tokenValue._Mypair._Myval2._Bx._Ptr; /*0x142fb0144*/
            v131 = tokenValue._Mypair._Myval2._Myres; /*0x142fb014c*/
            if ( tokenValue._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb0158*/
              p_tokenValue = (std::string *)tokenValue._Mypair._Myval2._Bx._Ptr; /*0x142fb0158*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&tokenValue); /*0xf1c00000000002e0*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v211); /*0xf1c00000000002ec*/
        }
        __wind /*0xf1c00000000002f4*/
        {
          __wind /*0xf1c00000000002fc*/
          {
            *(_QWORD *)v250.gap0 = &std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vftable'[1]; /*0x142fb0163*/
            *(_QWORD *)v250.gap10 = &std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vbtable'{for `std::ostream'}; /*0x142fb0172*/
            std::ios::ios(a1: &v250.gap90[8]); /*0x142fb0182*/
            __wind /*0xf1c00000000002ac*/
            {
              v159 = (unsigned int)v160 | 0x200; /*0x142fb0191*/
              std::iostream::iostream(a1: &v250, a2: &v250.gap10[8], a3: 0); /*0x142fb01a8*/
              __wind /*0xf1c0000000000274*/
              {
                *(_QWORD *)&v250.gap0[*(int *)(*(_QWORD *)v250.gap0 + 4LL)] = std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vftable'; /*0x142fb01c2*/
                *(int *)((char *)&v249 + *(int *)(*(_QWORD *)v250.gap0 + 4LL)) = *(_DWORD *)(*(_QWORD *)v250.gap0 + 4LL) /*0x142fb01dc*/
                                                                               - 152;
                std::streambuf::streambuf(a1: &v250.gap10[8]); /*0x142fb01eb*/
              }
              __unwind
              {
                std::iostream::~iostream<char,std::char_traits<char>>(a1: &v250.gap10[16]); /*0x1432c969b*/
              }
            }
            __unwind
            {
              if ( (v159 & 0x200) != 0 ) /*0x1432c9663*/
              {
                v159 &= ~0x200u; /*0x1432c9665*/
                std::ios::~ios<char,std::char_traits<char>>(a1: &v250.gap90[8]); /*0x1432c967a*/
              }
            }
            __wind /*0xf1c0000000000298*/
            {
              __wind /*0xf1c00000000002a0*/
              {
                *(_QWORD *)&v250.gap10[8] = std::stringbuf::`vftable'; /*0x142fb01f8*/
                *(_QWORD *)v250._Stringbuffer = 0; /*0x142fb0202*/
                *(_DWORD *)&v250._Stringbuffer[8] = 0; /*0x142fb020a*/
                v175 = 0; /*0x142fb0211*/
                LOBYTE(v179._Ptr) = 0; /*0x142fb0218*/
                v132 = (std::_Ref_count_base *)std::ios::rdbuf(a1: &v250.gap10[*(int *)(*(_QWORD *)v250.gap10 + 4LL)]); /*0x142fb0236*/
              }
              __unwind
              {
                __std_terminate(a1: v133, a2: v158); /*0xf1c00000000000b8*/
              }
              v179._Rep = v132; /*0x142fb023c*/
              v236 = v179; /*0x142fb024c*/
              base64<char,std::char_traits<char>>::get<char const *,std::ostreambuf_iterator<char>,int>( /*0x142fb0280*/
                this: (base64<char,std::char_traits<char> > *)&v266,
                _First: p_tokenValue->_Mypair._Myval2._Bx._Buf,
                _Last: &p_tokenValue->_Mypair._Myval2._Bx._Buf[tokenValue._Mypair._Myval2._Mysize],
                _To: (std::ostreambuf_iterator<char> *)&v236,
                _St: &v175);
              std::stringbuf::str(this: (std::stringbuf *)&v250.gap10[8], result: &v221); /*0x142fb0295*/
              if ( tokenValueDecode._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb02a6*/
              {
                v134 = tokenValueDecode._Mypair._Myval2._Bx._Ptr; /*0x142fb02ab*/
                if ( tokenValueDecode._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb02bd*/
                {
                  v134 = *((char **)tokenValueDecode._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb02c3*/
                  if ( (unsigned __int64)(tokenValueDecode._Mypair._Myval2._Bx._Ptr - v134 - 8) > 0x1F ) /*0x142fb02d2*/
                    _invalid_parameter_noinfo_noreturn(); /*0x142fb02d4*/
                }
                operator delete(ptr: v134); /*0x142fb02db*/
              }
              tokenValueDecode = v221; /*0x142fb02e8*/
              *(__m128i *)&v221._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x142fb0308*/
              v221._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb0311*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v221); /*0x142fb0321*/
            }
            __unwind
            {
              std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vbase destructor'(this: &v250); /*0xf1c0000000000260*/
            }
            std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vbase destructor'(this: &v250); /*0x142fb032f*/
            p_tokenValueDecode = &tokenValueDecode; /*0x142fb0334*/
            if ( tokenValueDecode._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb0345*/
              p_tokenValueDecode = (std::string *)tokenValueDecode._Mypair._Myval2._Bx._Ptr; /*0x142fb0345*/
            v216.Data = (const char *)p_tokenValueDecode; /*0x142fb034e*/
            v216.Length = tokenValueDecode._Mypair._Myval2._Mysize; /*0x142fb035e*/
            v237 = v216; /*0x142fb036e*/
            token = *RBX::Network::Rupp::TokenTlv::Token::Token(this: &v261, setType: GameService, setToken: &v237); /*0x142fb0391*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&tokenValueDecode); /*0xf1c0000000000254*/
          }
          if ( tokenValueDecode._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb03b0*/
          {
            v136 = tokenValueDecode._Mypair._Myval2._Bx._Ptr; /*0x142fb03b5*/
            if ( tokenValueDecode._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb03c7*/
            {
              v136 = *((char **)tokenValueDecode._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb03cd*/
              if ( (unsigned __int64)(tokenValueDecode._Mypair._Myval2._Bx._Ptr - v136 - 8) > 0x1F ) /*0x142fb03dc*/
                _invalid_parameter_noinfo_noreturn(); /*0x142fb03de*/
            }
            operator delete(ptr: v136); /*0x142fb03e5*/
          }
          tokenValueDecode._Mypair._Myval2._Mysize = 0; /*0x142fb03ec*/
          tokenValueDecode._Mypair._Myval2._Myres = 15; /*0x142fb03f4*/
          tokenValueDecode._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb0400*/
          if ( v131 >= 0x10 ) /*0x142fb040c*/
          {
            v137 = v130; /*0x142fb0412*/
            if ( v131 + 1 >= 0x1000 ) /*0x142fb041c*/
            {
              v130 = *((char **)v130 - 1); /*0x142fb0422*/
              if ( (unsigned __int64)(v137 - v130 - 8) > 0x1F ) /*0x142fb0431*/
                _invalid_parameter_noinfo_noreturn(); /*0x142fb0433*/
            }
            operator delete(ptr: v130); /*0x142fb043d*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&tokenValue); /*0xf1c0000000000248*/
        }
      }
      TeamCreateDisconnectInfo::setConnections(this: v183, connections: &serverConnections); /*0x142fb0452*/
      v138 = 0; /*0x142fb0457*/
      v139 = FLog::Output; /*0x142fb0463*/
      v140 = serverConnections._Mypair._Myval2._Myfirst; /*0x142fb046b*/
      while ( v138 < (unsigned __int64)(serverConnections._Mypair._Myval2._Mylast - v140) )
      {
        if ( v139 != 0 )
        {
          v141 = &v140[v138]; /*0x142fb04b4*/
          port = v141->port; /*0x142fb04b7*/
          if ( v141->address._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb04c0*/
            v141 = (RBX::Network::Client::ServerConnection *)v141->address._Mypair._Myval2._Bx._Ptr; /*0x142fb04c2*/
          FLog::FastLogFormatted(
            level: v139,
            message: "[FLog::Output] serverConnections[%d]: [%s]:%d",
            v138,
            v141->address._Mypair._Myval2._Bx._Buf,
            port);
          v139 = FLog::Output; /*0x142fb04dc*/
          v140 = serverConnections._Mypair._Myval2._Myfirst; /*0x142fb04e4*/
        }
        ++v138; /*0x142fb04ec*/
      }
      v162 = (rbx::signals::slot_base *)&v179; /*0x142fb04f8*/
      v179 = 0; /*0x142fb0503*/
      if ( playerInfo._Rep != nullptr ) /*0x142fb0517*/
        _InterlockedIncrement((volatile signed __int32 *)&playerInfo._Rep->_Uses); /*0x142fb0519*/
      v179 = playerInfo; /*0x142fb0525*/
      __wind /*0xf1c0000000000238*/
      {
        v143 = v4->m_config._Ptr; /*0x142fb052e*/
        v223._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb0532*/
        *(__m128i *)&v223._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x142fb0542*/
        std::string::assign(this: &v223, _Ptr: "IsUnknownOrUnder13", _Count: 0x12u); /*0x142fb0568*/
        __wind /*0xf1c000000000022c*/
        {
          v3 = (std::shared_ptr<RBX::File> *)EntityProperties::get<bool>(this: v143, result: &v177, fieldName: &v223)->_Value; /*0x142fb0586*/
          v266 = &v213; /*0x142fb0591*/
          v2 = (std::_Ref_count_base *)v4->m_config._Ptr; /*0x142fb0599*/
          v222._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb059f*/
          *(__m128i *)&v222._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x142fb05af*/
          std::string::assign(this: &v222, _Ptr: "UserName", _Count: 8u); /*0x142fb05d3*/
          __wind /*0xf1c0000000000220*/
          {
            v144 = EntityProperties::get<std::string>(this: (EntityProperties *)v2, result: &v248, fieldName: &v222); /*0x142fb05ec*/
            __wind /*0xf1c0000000000214*/
            {
              v213._Value._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb05f2*/
              *(_OWORD *)&v213._Value._Mypair._Myval2._Mysize = 0u; /*0x142fb05fa*/
              v213._Value = (std::string)v144->___u0; /*0x142fb060d*/
              v144->_Value._Mypair._Myval2._Mysize = 0; /*0x142fb0621*/
              v144->_Value._Mypair._Myval2._Myres = 15; /*0x142fb0625*/
              v144->_Value._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb062d*/
              __wind /*0xf1c000000000018c*/
              {
                v145 = std::string::string( /*0x142fb0640*/
                         this: &v259,
                         __that: (const rtc::webrtc_checks_impl::ToStringVal *)&serverAddress);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)v266); /*0xf1c000000000019c*/
              }
            }
            __unwind
            {
              std::optional<std::string>::~optional<std::string>(this: (Luau::FunctionDefinition *)&v248); /*0xf1c00000000001a8*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v222); /*0xf1c00000000001b4*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v223); /*0xf1c00000000001c0*/
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)v162); /*0xf1c00000000001cc*/
      }
      __wind /*0xf1c00000000001d4*/
      {
        __wind /*0xf1c00000000001dc*/
        {
          __wind /*0xf1c00000000001e4*/
          {
            RBX::Network::Client::playerConnect( /*0x142fb06bb*/
              this: v91,
              userId: (__int64)QWidget,
              server_deprecated: &v145->val,
              serverPort: v161,
              clientPort: 0,
              threadSleepTime: -1,
              dataCenterId: centerId,
              userName: (std::string *)&v213,
              isUnder13: (bool)v3,
              playerInfoTable: &v179,
              serverConnectionsArg: &serverConnections,
              udmuxEndpointsArg: &udmuxEndpoint,
              &token,
              directServerReturn: v120);
            if ( v248._Has_value ) /*0x142fb06c9*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v248); /*0x142fb06d3*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v222); /*0x142fb06e1*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v223); /*0x142fb06ef*/
          }
          __unwind
          {
            std::optional<std::string>::~optional<std::string>(this: (Luau::FunctionDefinition *)&v248); /*0xf1c00000000001f4*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v222); /*0xf1c0000000000200*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v223); /*0xf1c000000000020c*/
      }
      if ( v4->m_isVisibleDM ) /*0x142fb06f4*/
      {
        v146 = (bool *)operator new(size: 1u); /*0x142fb0707*/
        if ( v146 != nullptr ) /*0x142fb070f*/
          *v146 = false; /*0x142fb0711*/
        else
          v146 = nullptr; /*0x142fb0716*/
        std::shared_ptr<bool>::shared_ptr<bool>(this: &debouncer, _Px: v146); /*0x142fb0724*/
        __wind /*0xf1c0000000000180*/
        {
          RBX::ServiceProvider::create<RBX::Selection>(this: &dataModel._Ptr->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x142fb0736*/
          lambda_3df8de9dcbbe5c3cbc65423c0f1e4022_::_lambda_3df8de9dcbbe5c3cbc65423c0f1e4022_( /*0x142fb0756*/
            <debouncer>: &v260,
            <weakDM>: (const std::weak_ptr<RBX::DataModel> *)&debouncer);
          __wind /*0xf1c0000000000174*/
          {
            rbx::signal_void___cdecl_RBX::SelectionChanged_const____::connect__lambda_3df8de9dcbbe5c3cbc65423c0f1e4022___( /*0x142fb076a*/
              result: v147,
              (CloudEditConnectionModel::connectToTeamCreateSession::__l68::<lambda_3df8de9dcbbe5c3cbc65423c0f1e4022> *)function);
            rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)function); /*0x142fb0777*/
          }
          __unwind
          {
            lambda_3df8de9dcbbe5c3cbc65423c0f1e4022_::__lambda_3df8de9dcbbe5c3cbc65423c0f1e4022_(a1: &v260); /*0xf1c000000000016c*/
          }
          lambda_3df8de9dcbbe5c3cbc65423c0f1e4022_::__lambda_3df8de9dcbbe5c3cbc65423c0f1e4022_(a1: &v260); /*0x142fb0785*/
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&debouncer); /*0x142fb0793*/
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&debouncer); /*0xf1c0000000000160*/
        }
      }
      RBX::Workspace::setDefaultMouseCommand(this: dataModel._Ptr->workspace._Ptr); /*0x142fb07a7*/
      std::vector<RBX::Network::Client::ServerConnection>::~vector<RBX::Network::Client::ServerConnection>(this: &udmuxEndpoint); /*0x142fb07b5*/
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&playerInfo); /*0x142fb07c3*/
      std::vector<RBX::Network::Client::ServerConnection>::~vector<RBX::Network::Client::ServerConnection>(this: &serverConnections); /*0x142fb07d1*/
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&serverAddress); /*0x142fb07df*/
      RBX::Security::Impersonator::~Impersonator(this: &impersonate); /*0x142fb07ed*/
      RBX::DataModel::LegacyLock::~LegacyLock(this: &function[1]); /*0x142fb07fb*/
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&streamSizeInBytes); /*0x142fb0809*/
      QPointer<MassUpdateWindow>::~QPointer<MassUpdateWindow>(this: (QPointer<FindReplaceLockedScriptsDialog> *)&safeThis); /*0x142fb0817*/
      if ( FFlag::DebugIsTeamCreateJoinForcedFailureEnabled.value ) /*0x142fb082c*/
        goto LABEL_310; /*0x142fb082c*/
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&dataModel); /*0x142fb082e*/
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: psc); /*0x142fb083c*/
      result = 0; /*0x142fb0841*/
      goto LABEL_570; /*0x142fb0843*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&dataModel); /*0xf1c0000000000620*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: psc); /*0xf1c000000000062c*/
  }
}

// Address: 0x142fb0880 | Name: ?connectToTeamCreateSession@CloudEditConnectionModel@@QEAAXAEBV?$shared_ptr@VDataModel@RBX@@@std@@V?$shared_ptr@VPlaceSessionConfiguration@@@3@_NV?$shared_ptr@VSpan@Tracing@RBX@@@3@@Z
void __fastcall CloudEditConnectionModel::connectToTeamCreateSession(
        CloudEditConnectionModel *this,
        const std::shared_ptr<RBX::DataModel> *dm,
        std::shared_ptr<RBX::File> *psc,
        bool isVisibleDM,
        std::shared_ptr<RBX::File> *span)
{
  std::shared_ptr<RBX::File> *v6; // r12
  std::_Ref_count_base *Rep; // rax
  RBX::DataModel *Ptr; // rcx
  std::_Ref_count_base *v10; // r8
  std::_Ref_count_base *v11; // rcx
  TeamCreateDisconnectInfo *Instance; // rax
  StudioTimingStatistics *v13; // rbx
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v14; // rax
  std::shared_ptr<StudioHttpRequest> *p_m_request; // r15
  std::_Ref_count_base *v16; // rbx
  _OWORD *v17; // rax
  _OWORD *v18; // rsi
  std::unordered_map<std::string,RBX::Reflection::Variant> *v19; // r15
  std::pair<std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> *v20; // rax
  char *v21; // rcx
  char *v22; // rax
  rtc::webrtc_checks_impl::ToStringVal *first; // r14
  const rbx::implementation::typed_holder<std::string > *v24; // r12
  unsigned __int64 Myres; // rax
  std::string *p_gameJoinAttemptId; // rdx
  char *v27; // rcx
  std::_Ref_count_base *v28; // rcx
  std::_Ref_count_base *v29; // rbx
  rtc::webrtc_checks_impl::ToStringVal *v30; // rax
  std::string *p_val; // rbx
  std::string *v32; // rax
  std::shared_ptr<RBX::HttpRequest> *JsonHttpPostRequest; // rax
  RBX::HttpRequest *v34; // r15
  std::_Ref_count_base *v35; // rbx
  std::_Ref_count_base *v36; // r14
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v37; // rax
  std::_Ref_count_base *v38; // r14
  char *v39; // rcx
  char *v40; // rcx
  StudioHttpRequest *v41; // r14
  std::shared_ptr<RBX::Tracing::Span> *v42; // rsi
  std::_Ref_count_base *v43; // rcx
  std::_Ref_count_base *v44; // rbx
  std::_Ref_count_base *v45; // rdx
  std::_Ref_count_base *v46; // rbx
  std::_Ref_count_base *v47; // rbx
  StudioHttpRequest *v48; // rcx
  long double sec; // xmm0_8
  std::_Ref_count_base *v50; // rdx
  volatile signed __int32 *v51; // rbx
  volatile signed __int32 *v52; // rbx
  __int64 v53; // [rsp+0h] [rbp-100h] BYREF
  __m128d v54; // [rsp+20h] [rbp-E0h]
  std::string gameJoinAttemptId; // [rsp+30h] [rbp-D0h] BYREF
  std::shared_ptr<RBX::Tracing::Span> referenced; // [rsp+50h] [rbp-B0h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > value; // [rsp+60h] [rbp-A0h] BYREF
  std::string postJson; // [rsp+70h] [rbp-90h] BYREF
  std::shared_ptr<RBX::HttpRequest> v59; // [rsp+90h] [rbp-70h] BYREF
  std::string _Keyval_arg; // [rsp+A0h] [rbp-60h] BYREF
  std::string v61; // [rsp+C0h] [rbp-40h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *v62; // [rsp+E0h] [rbp-20h]
  RBX::Tracing::SpanReference v63; // [rsp+E8h] [rbp-18h] BYREF
  std::optional<RBX::Tracing::SpanReference> spanReference; // [rsp+100h] [rbp+0h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > postData; // [rsp+120h] [rbp+20h] BYREF
  std::shared_ptr<RBX::HttpRequest> httpReq; // [rsp+130h] [rbp+30h] BYREF
  std::string v67; // [rsp+140h] [rbp+40h] BYREF
  std::function<RetryBehavior __cdecl(QJsonDocument const &)> v68; // [rsp+160h] [rbp+60h] BYREF
  std::shared_ptr<StudioHttpRequest> result; // [rsp+1A0h] [rbp+A0h] BYREF
  std::shared_ptr<RBX::HttpRequest> v70; // [rsp+1B0h] [rbp+B0h] BYREF
  std::shared_ptr<StudioHttpRequest> v71; // [rsp+1C0h] [rbp+C0h] BYREF
  long double v72; // [rsp+1D8h] [rbp+D8h]
  std::_Func_base<RetryBehavior,QJsonDocument const &> *v73; // [rsp+1E8h] [rbp+E8h]
  std::function<void __cdecl(HttpError const &)> v74; // [rsp+1F8h] [rbp+F8h] BYREF
  std::pair<std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> v75; // [rsp+238h] [rbp+138h] BYREF
  std::pair<std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> v76; // [rsp+248h] [rbp+148h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v77; // [rsp+258h] [rbp+158h] BYREF
  std::string v78; // [rsp+278h] [rbp+178h] BYREF
  RBX::Reflection::Variant v79; // [rsp+298h] [rbp+198h] BYREF
  RBX::Time startTime; // [rsp+330h] [rbp+230h] BYREF
  Luau::NotNull<Luau::InternalErrorReporter> v81; // [rsp+338h] [rbp+238h] BYREF
  std::shared_ptr<RBX::File> *v82; // [rsp+340h] [rbp+240h]

  v82 = psc; /*0x142fb0885*/
  v6 = psc; /*0x142fb08a8*/
  Rep = dm->_Rep; /*0x142fb08ae*/
  Ptr = nullptr; /*0x142fb08b2*/
  v10 = nullptr; /*0x142fb08b4*/
  if ( Rep != nullptr ) /*0x142fb08ba*/
  {
    Ptr = dm->_Ptr; /*0x142fb08bc*/
    _InterlockedIncrement((volatile signed __int32 *)&Rep->_Weaks); /*0x142fb08bf*/
    v10 = Rep; /*0x142fb08c3*/
  }
  this->m_weakDM._Ptr = Ptr; /*0x142fb08c6*/
  v11 = this->m_weakDM._Rep; /*0x142fb08ca*/
  this->m_weakDM._Rep = v10; /*0x142fb08ce*/
  if ( v11 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v11->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb08e6*/
    v11->_Delete_this(this: v11); /*0x142fb08eb*/
  __wind /*0xf1c0000000000178*/
  {
    __wind /*0xf1c0000000000180*/
    {
      v81.ptr = (Luau::InternalErrorReporter *)v6->_Ptr->guid; /*0x142fb08f6*/
      this->m_placeId = (__int64)std::shared_ptr<std::string>::operator-><std::string,0>(this: &v81); /*0x142fb0909*/
      this->m_isVisibleDM = isVisibleDM; /*0x142fb090d*/
      Instance = TeamCreateDisconnectInfo::getInstance(); /*0x142fb0914*/
      webrtc::DtlsTransport::RegisterObserver(this: Instance, placeid: this->m_placeId); /*0x142fb0920*/
      RBX::Time::nowFast(result: &startTime); /*0x142fb092c*/
      v13 = StudioTimingStatistics::getInstance(); /*0x142fb0936*/
      v13->teamCreateServerStartTime.startTime = RBX::Time::nowFastSec(); /*0x142fb093e*/
      RBX::Analytics::Studio::reportTeamCreateProgress(status: STARTING_NEW_STAGE); /*0x142fb0945*/
      if ( FFlag::COLLAB2264PreemptiveLoadTCRecentGamesOnStartUp.value ) /*0x142fb0951*/
      {
        v14 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)CloudEditConnectionModel::constructTeamCreateGameJoinRequest( /*0x142fb0961*/
                                                                                   &result,
                                                                                   placeId: this->m_placeId,
                                                                                   isPreemptive: false);
        p_m_request = &this->m_request; /*0x142fb0966*/
        std::shared_ptr<RBX::Network::CachedBitstream>::operator=( /*0x142fb0970*/
          this: (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)&this->m_request,
          _Right: v14);
        v16 = result._Rep; /*0x142fb0975*/
        if ( result._Rep != nullptr /*0x142fb098f*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&result._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v16->_Destroy(this: v16); /*0x142fb099b*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v16->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb09a7*/
            v16->_Delete_this(this: v16); /*0x142fb09b3*/
        }
      }
      else
      {
        httpReq = 0; /*0x142fb09be*/
        __wind /*0xf1c0000000000144*/
        {
          v17 = operator new(size: 0x50u); /*0x142fb09c8*/
          v18 = v17; /*0x142fb09cd*/
          v62 = (RBX::Graphics::ProfilerAdorn::Item *)v17; /*0x142fb09d0*/
          __wind /*0xf1c0000000000138*/
          {
            if ( v17 != nullptr ) /*0x142fb09d7*/
            {
              *v17 = 0; /*0x142fb09dc*/
              *((_DWORD *)v17 + 2) = 1; /*0x142fb09df*/
              *((_DWORD *)v17 + 3) = 1; /*0x142fb09e6*/
              *(_QWORD *)v17 = std::_Ref_count_obj2<std::unordered_map<std::string,RBX::Reflection::Variant>>::`vftable'; /*0x142fb09f4*/
              std::unordered_map<std::string,RBX::Reflection::Variant>::unordered_map<std::string,RBX::Reflection::Variant>(this: (std::unordered_map<std::string,RBX::Reflection::Variant> *)(v17 + 1)); /*0x142fb09fb*/
            }
            else
            {
              v18 = nullptr; /*0x142fb0a06*/
            }
          }
          __unwind
          {
            operator delete(ptr: v62); /*0x143181cd5*/
          }
          v19 = (std::unordered_map<std::string,RBX::Reflection::Variant> *)(v18 + 1); /*0x142fb0a08*/
          postData._Ptr = (std::unordered_map<std::string,RBX::Reflection::Variant> *)(v18 + 1); /*0x142fb0a0c*/
          postData._Rep = (std::_Ref_count_base *)v18; /*0x142fb0a10*/
          _Keyval_arg._Mypair._Myval2._Myres = 15; /*0x142fb0a18*/
          _Keyval_arg._Mypair._Myval2._Mysize = 7; /*0x142fb0a20*/
          strcpy(_Keyval_arg._Mypair._Myval2._Bx._Buf, "placeId"); /*0x142fb0a2e*/
          __wind /*0xf1c0000000000164*/
          {
            __wind /*0xf1c000000000016c*/
            {
              v20 = std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::_Try_emplace<std::string,>( /*0x142fb0a58*/
                      this: (std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,RBX::Reflection::Variant> >,0> > *)(v18 + 1),
                      result: &v75,
                      &_Keyval_arg);
              RBX::Reflection::Variant::operator=<__int64 &,0>(this: &v20->first->_Myval.second, rhs: &this->m_placeId); /*0x142fb0a68*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&_Keyval_arg); /*0xf1c0000000000124*/
            }
            if ( _Keyval_arg._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb0a76*/
            {
              v21 = _Keyval_arg._Mypair._Myval2._Bx._Ptr; /*0x142fb0a7b*/
              if ( _Keyval_arg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb0a89*/
              {
                v21 = *((char **)_Keyval_arg._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb0a8f*/
                if ( (unsigned __int64)(_Keyval_arg._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x142fb0a9e*/
                  _invalid_parameter_noinfo_noreturn(); /*0x142fb0aa0*/
              }
              operator delete(ptr: v21); /*0x142fb0aa7*/
            }
            __wind /*0xf1c00000000000f0*/
            {
              gameJoinAttemptId._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb0aac*/
              gameJoinAttemptId._Mypair._Myval2._Mysize = 0; /*0x142fb0ab1*/
              gameJoinAttemptId._Mypair._Myval2._Myres = 15; /*0x142fb0ab6*/
              RBX::generateStandardGUIDNoCurlyBraces(result: &gameJoinAttemptId); /*0x142fb0ac9*/
              v61._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb0ace*/
              v61._Mypair._Myval2._Mysize = 0; /*0x142fb0ad2*/
              v61._Mypair._Myval2._Myres = 15; /*0x142fb0ad6*/
              v22 = (char *)operator new(size: 0x20u); /*0x142fb0ae7*/
              v61._Mypair._Myval2._Mysize = 17; /*0x142fb0aec*/
              v61._Mypair._Myval2._Myres = 31; /*0x142fb0af4*/
              *(_OWORD *)v22 = *(_OWORD *)"gameJoinAttemptId"; /*0x142fb0b03*/
              *((_WORD *)v22 + 8) = (unsigned __int8)aGamejoinattemp[16]; /*0x142fb0b0d*/
              v61._Mypair._Myval2._Bx._Ptr = v22; /*0x142fb0b14*/
              __wind /*0xf1c00000000000e4*/
              {
                first = (rtc::webrtc_checks_impl::ToStringVal *)std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::_Try_emplace<std::string,>( /*0x142fb0b2b*/
                                                                  this: (std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,RBX::Reflection::Variant> >,0> > *)(v18 + 1),
                                                                  result: &v76,
                                                                  _Keyval_arg: &v61)->first;
                first[1].val._Mypair._Myval2._Mysize = (unsigned __int64)RBX::Reflection::Type::getSingleton<std::string>(); /*0x142fb0b33*/
                v24 = rbx::implementation::typed_holder<std::string>::singleton(); /*0x142fb0b3c*/
                Myres = first[1].val._Mypair._Myval2._Myres; /*0x142fb0b3f*/
                if ( (const rbx::implementation::typed_holder<std::string > *)Myres == v24 ) /*0x142fb0b4a*/
                {
                  if ( &first[2] != (rtc::webrtc_checks_impl::ToStringVal *)&gameJoinAttemptId ) /*0x142fb0b54*/
                  {
                    p_gameJoinAttemptId = &gameJoinAttemptId; /*0x142fb0b56*/
                    if ( gameJoinAttemptId._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb0b61*/
                      p_gameJoinAttemptId = (std::string *)gameJoinAttemptId._Mypair._Myval2._Bx._Ptr; /*0x142fb0b61*/
                    std::string::assign( /*0x142fb0b6f*/
                      this: &first[2].val,
                      _Ptr: p_gameJoinAttemptId->_Mypair._Myval2._Bx._Buf,
                      _Count: gameJoinAttemptId._Mypair._Myval2._Mysize);
                  }
                }
                else
                {
                  if ( Myres != 0 ) /*0x142fb0b79*/
                  {
                    (*(void (__fastcall **)(rtc::webrtc_checks_impl::ToStringVal *))(Myres + 16))(a1: first + 2); /*0x142fb0b82*/
                    first[1].val._Mypair._Myval2._Myres = 0; /*0x142fb0b84*/
                  }
                  std::string::string( /*0x142fb0b94*/
                    this: first + 2,
                    __that: (const rtc::webrtc_checks_impl::ToStringVal *)&gameJoinAttemptId);
                  first[1].val._Mypair._Myval2._Myres = (unsigned __int64)v24; /*0x142fb0b99*/
                }
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v61); /*0xf1c00000000000dc*/
              }
              if ( v61._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb0ba5*/
              {
                v27 = v61._Mypair._Myval2._Bx._Ptr; /*0x142fb0baa*/
                if ( v61._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb0bb8*/
                {
                  v27 = *((char **)v61._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb0bbe*/
                  if ( (unsigned __int64)(v61._Mypair._Myval2._Bx._Ptr - v27 - 8) > 0x1F ) /*0x142fb0bcd*/
                    _invalid_parameter_noinfo_noreturn(); /*0x142fb0bcf*/
                }
                operator delete(ptr: v27); /*0x142fb0bd6*/
              }
              postJson._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb0bde*/
              postJson._Mypair._Myval2._Mysize = 0; /*0x142fb0be3*/
              postJson._Mypair._Myval2._Myres = 15; /*0x142fb0be7*/
              if ( v18 != nullptr ) /*0x142fb0bf7*/
              {
                _InterlockedIncrement((volatile signed __int32 *)v18 + 2); /*0x142fb0bf9*/
                v19 = postData._Ptr; /*0x142fb0bfd*/
              }
              __wind /*0xf1c0000000000150*/
              {
                __wind /*0xf1c0000000000158*/
                {
                  value._Ptr = v19; /*0x142fb0c01*/
                  value._Rep = (std::_Ref_count_base *)v18; /*0x142fb0c06*/
                  RBX::Reflection::Variant::Variant(this: &v79, &value); /*0x142fb0c17*/
                  __wind /*0xf1c000000000009c*/
                  {
                    RBX::WebParser::writeJSON(value: &v79, result: &postJson, skip: SkipNonJSON); /*0x142fb0c2f*/
                  }
                  __unwind
                  {
                    std::tuple<bool,RBX::Reflection::Variant>::~tuple<bool,RBX::Reflection::Variant>(this: (RBX::setupTweenUpdate::__l5::<lambda_fde46e4afccb457705ab91f32d9aea10> *)&v79); /*0xf1c00000000000ac*/
                  }
                  __wind /*0xf1c00000000000b4*/
                  {
                    if ( v79.value.holder != nullptr ) /*0x142fb0c3f*/
                      v79.value.holder->destruct(a1: v79.value.data); /*0x142fb0c4c*/
                    v28 = value._Rep; /*0x142fb0c4f*/
                    if ( value._Rep != nullptr /*0x142fb0c63*/
                      && _InterlockedExchangeAdd((volatile signed __int32 *)&value._Rep->_Uses, 0xFFFFFFFF) == 1 )
                    {
                      v29 = value._Rep; /*0x142fb0c65*/
                      value._Rep->_Destroy(this: value._Rep); /*0x142fb0c70*/
                      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v29->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb0c7c*/
                        value._Rep->_Delete_this(this: value._Rep); /*0x142fb0c86*/
                    }
                  }
                  __unwind
                  {
                    __std_terminate(a1: v28, a2: &v53); /*0x142f39fa8*/
                  }
                }
                __unwind
                {
                  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&value); /*0xf1c00000000000d0*/
                }
                v62 = (RBX::Graphics::ProfilerAdorn::Item *)&v77; /*0x142fb0c90*/
                v30 = std::string::string(this: &v77, __that: (const rtc::webrtc_checks_impl::ToStringVal *)&postJson); /*0x142fb0ca0*/
                __wind /*0xf1c0000000000090*/
                {
                  p_val = &v30->val; /*0x142fb0ca5*/
                  v32 = ApiGameJoinUrlConstruction::constructJoinTeamCreateUrl(result: &v78); /*0x142fb0caf*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: v62); /*0xf1c0000000000088*/
                }
                JsonHttpPostRequest = StudioHttpRequest::makeJsonHttpPostRequest(result: &v70, url: v32, json: p_val); /*0x142fb0cc2*/
                v34 = JsonHttpPostRequest->_Ptr; /*0x142fb0cc7*/
                v35 = JsonHttpPostRequest->_Rep; /*0x142fb0cca*/
                JsonHttpPostRequest->_Ptr = nullptr; /*0x142fb0cce*/
                JsonHttpPostRequest->_Rep = nullptr; /*0x142fb0cd1*/
                httpReq._Ptr = v34; /*0x142fb0cd5*/
                httpReq._Rep = v35; /*0x142fb0cd9*/
                v36 = v70._Rep; /*0x142fb0cdd*/
                if ( v70._Rep != nullptr /*0x142fb0cf4*/
                  && _InterlockedExchangeAdd((volatile signed __int32 *)&v70._Rep->_Uses, 0xFFFFFFFF) == 1 )
                {
                  v36->_Destroy(this: v36); /*0x142fb0cfc*/
                  if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v36->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb0d09*/
                    v36->_Delete_this(this: v36); /*0x142fb0d11*/
                }
                v67._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb0d14*/
                v67._Mypair._Myval2._Mysize = 0; /*0x142fb0d18*/
                v67._Mypair._Myval2._Myres = 15; /*0x142fb0d1c*/
                std::string::assign( /*0x142fb0d35*/
                  this: &v67,
                  _Ptr: "CloudEditConnectionModel::connectToTeamCreateSession",
                  _Count: 0x34u);
                v59 = 0; /*0x142fb0d3d*/
                if ( v35 != nullptr ) /*0x142fb0d45*/
                  _InterlockedIncrement((volatile signed __int32 *)&v35->_Uses); /*0x142fb0d47*/
                v59._Ptr = v34; /*0x142fb0d4b*/
                v59._Rep = v35; /*0x142fb0d4f*/
                v37 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)StudioHttpRequest::create( /*0x142fb0d62*/
                                                                                           result: &v71,
                                                                                           req: &v59,
                                                                                           name: &v67);
                p_m_request = &this->m_request; /*0x142fb0d67*/
                std::shared_ptr<RBX::Network::CachedBitstream>::operator=( /*0x142fb0d71*/
                  this: (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)&this->m_request,
                  _Right: v37);
                v38 = v71._Rep; /*0x142fb0d76*/
                if ( v71._Rep != nullptr /*0x142fb0d8d*/
                  && _InterlockedExchangeAdd((volatile signed __int32 *)&v71._Rep->_Uses, 0xFFFFFFFF) == 1 )
                {
                  v38->_Destroy(this: v38); /*0x142fb0d95*/
                  if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v38->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb0da2*/
                    v38->_Delete_this(this: v38); /*0x142fb0daa*/
                }
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&postJson); /*0xf1c000000000007c*/
              }
              if ( postJson._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb0db6*/
              {
                v39 = postJson._Mypair._Myval2._Bx._Ptr; /*0x142fb0dbb*/
                if ( postJson._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb0dca*/
                {
                  v39 = *((char **)postJson._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb0dd0*/
                  if ( (unsigned __int64)(postJson._Mypair._Myval2._Bx._Ptr - v39 - 8) > 0x1F ) /*0x142fb0ddf*/
                    _invalid_parameter_noinfo_noreturn(); /*0x142fb0de1*/
                }
                operator delete(ptr: v39); /*0x142fb0de8*/
              }
              postJson._Mypair._Myval2._Mysize = 0; /*0x142fb0ded*/
              postJson._Mypair._Myval2._Myres = 15; /*0x142fb0df1*/
              postJson._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb0df9*/
              if ( gameJoinAttemptId._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb0e07*/
              {
                v40 = gameJoinAttemptId._Mypair._Myval2._Bx._Ptr; /*0x142fb0e0c*/
                if ( gameJoinAttemptId._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb0e1b*/
                {
                  v40 = *((char **)gameJoinAttemptId._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb0e21*/
                  if ( (unsigned __int64)(gameJoinAttemptId._Mypair._Myval2._Bx._Ptr - v40 - 8) > 0x1F ) /*0x142fb0e30*/
                    _invalid_parameter_noinfo_noreturn(); /*0x142fb0e32*/
                }
                operator delete(ptr: v40); /*0x142fb0e39*/
              }
              gameJoinAttemptId._Mypair._Myval2._Mysize = 0; /*0x142fb0e3e*/
              gameJoinAttemptId._Mypair._Myval2._Myres = 15; /*0x142fb0e43*/
              gameJoinAttemptId._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb0e4c*/
              if ( v18 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)v18 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb0e60*/
              {
                (**(void (__fastcall ***)(_OWORD *))v18)(a1: v18); /*0x142fb0e68*/
                if ( _InterlockedExchangeAdd((volatile signed __int32 *)v18 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb0e74*/
                  (*(void (__fastcall **)(_OWORD *))(*(_QWORD *)v18 + 8LL))(a1: v18); /*0x142fb0e7c*/
              }
              if ( v35 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v35->_Uses, 0xFFFFFFFF) == 1 ) /*0x142fb0e8f*/
              {
                v35->_Destroy(this: v35); /*0x142fb0e97*/
                if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v35->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb0ea3*/
                  v35->_Delete_this(this: v35); /*0x142fb0eab*/
              }
              v6 = v82; /*0x142fb0eae*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&gameJoinAttemptId); /*0xf1c0000000000100*/
            }
          }
          __unwind
          {
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&postData); /*0xf1c000000000010c*/
          }
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&httpReq); /*0xf1c0000000000118*/
        }
      }
      StudioHttpRequest::setQtContext(this: p_m_request->_Ptr, context: this); /*0x142fb0ebb*/
      v41 = p_m_request->_Ptr; /*0x142fb0ec0*/
      referenced = 0; /*0x142fb0ec6*/
      v42 = (std::shared_ptr<RBX::Tracing::Span> *)span; /*0x142fb0ecc*/
      v43 = span->_Rep; /*0x142fb0ed3*/
      if ( v43 != nullptr ) /*0x142fb0eda*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v43->_Uses); /*0x142fb0edc*/
        v43 = v42->_Rep; /*0x142fb0ee0*/
      }
      __wind /*0xf1c0000000000034*/
      {
        referenced._Ptr = v42->_Ptr; /*0x142fb0ee7*/
        referenced._Rep = v43; /*0x142fb0eec*/
        *(_QWORD *)&v54.m128d_f64[0] = &referenced; /*0x142fb0ef6*/
        RBX::Tracing::SpanReference::SpanReference(this: &v63, type: ChildOf, &referenced); /*0x142fb0f06*/
        v44 = referenced._Rep; /*0x142fb0f0c*/
        if ( referenced._Rep != nullptr /*0x142fb0f20*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&referenced._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v44->_Destroy(this: v44); /*0x142fb0f28*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v44->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb0f34*/
            v44->_Delete_this(this: v44); /*0x142fb0f3c*/
        }
        spanReference._Value.referenceType = v63.referenceType; /*0x142fb0f43*/
        spanReference._Value.referencedSpan = 0; /*0x142fb0f49*/
        v45 = v63.referencedSpan._Rep; /*0x142fb0f4e*/
        if ( v63.referencedSpan._Rep != nullptr ) /*0x142fb0f55*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v63.referencedSpan._Rep->_Uses); /*0x142fb0f57*/
          v45 = v63.referencedSpan._Rep; /*0x142fb0f5b*/
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: *(std::shared_ptr<RBX::File> **)&v54.m128d_f64[0]); /*0xf1c0000000000044*/
      }
      __wind /*0xf1c000000000004c*/
      {
        __wind /*0xf1c0000000000054*/
        {
          spanReference._Value.referencedSpan = (const std::shared_ptr<RBX::Tracing::Span>)__PAIR128__( /*0x142fb0f63*/
                                                                                             (unsigned __int64)v45,
                                                                                             (unsigned __int64)v63.referencedSpan._Ptr);
          spanReference._Has_value = true; /*0x142fb0f6b*/
          StudioHttpRequest::setupSpan(this: v41, &spanReference); /*0x142fb0f76*/
          if ( spanReference._Has_value ) /*0x142fb0f80*/
          {
            v46 = spanReference._Value.referencedSpan._Rep; /*0x142fb0f82*/
            if ( spanReference._Value.referencedSpan._Rep != nullptr /*0x142fb0f95*/
              && _InterlockedExchangeAdd(
                   (volatile signed __int32 *)&spanReference._Value.referencedSpan._Rep->_Uses,
                   0xFFFFFFFF) == 1 )
            {
              v46->_Destroy(this: v46); /*0x142fb0f9d*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v46->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb0fa9*/
                v46->_Delete_this(this: v46); /*0x142fb0fb1*/
            }
          }
          v47 = v63.referencedSpan._Rep; /*0x142fb0fb5*/
          if ( v63.referencedSpan._Rep != nullptr /*0x142fb0fc8*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&v63.referencedSpan._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v47->_Destroy(this: v47); /*0x142fb0fd0*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v47->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb0fdc*/
              v47->_Delete_this(this: v47); /*0x142fb0fe4*/
          }
          v48 = p_m_request->_Ptr; /*0x142fb0fe7*/
          sec = startTime.sec; /*0x142fb0fea*/
          v72 = startTime.sec; /*0x142fb0ff2*/
          v50 = v6->_Rep; /*0x142fb0ffa*/
          if ( v50 != nullptr ) /*0x142fb1002*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&v50->_Uses); /*0x142fb1004*/
            v50 = v6->_Rep; /*0x142fb1008*/
            sec = v72; /*0x142fb100d*/
          }
        }
        __unwind
        {
          std::optional<RBX::Tracing::SpanReference>::~optional<RBX::Tracing::SpanReference>(this: &spanReference); /*0xf1c0000000000064*/
        }
      }
      __unwind
      {
        RBX::CageHSRFetchRequest::CageHSRAsset::~CageHSRAsset(this: (std::pair<RBX::Instance * const,std::shared_ptr<SearchResult> > *)&v63); /*0xf1c0000000000070*/
      }
      v73 = (std::_Func_base<RetryBehavior,QJsonDocument const &> *)v6->_Ptr; /*0x142fb1019*/
      v68._Mystorage._Ptrs[0] = (std::_Func_base<RetryBehavior,QJsonDocument const &> *)std::_Func_impl_no_alloc__lambda_e6c5d9ab565a8845bd630cf3438feb12__RetryBehavior_QJsonDocument_const___::_vftable_; /*0x142fb1027*/
      v68._Mystorage._Ptrs[1] = (std::_Func_base<RetryBehavior,QJsonDocument const &> *)this; /*0x142fb102b*/
      *(long double *)&v68._Mystorage._Ptrs[2] = sec; /*0x142fb102f*/
      LODWORD(v68._Mystorage._Ptrs[3]) = 0; /*0x142fb1034*/
      v68._Mystorage._Ptrs[4] = v73; /*0x142fb103b*/
      v68._Mystorage._Ptrs[5] = (std::_Func_base<RetryBehavior,QJsonDocument const &> *)v50; /*0x142fb1042*/
      v68._Mystorage._Ptrs[7] = (std::_Func_base<RetryBehavior,QJsonDocument const &> *)&v68; /*0x142fb104d*/
      StudioHttpRequest::setJsonSuccessCallback(this: v48, callback: &v68); /*0x142fb1058*/
      *(_QWORD *)&v54.m128d_f64[0] = this; /*0x142fb105d*/
      v74._Mystorage._Ptrs[0] = (std::_Func_base<void,HttpError const &> *)std::_Func_impl_no_alloc__lambda_d184be313a755f7dff05d3c72f7322d1__void_HttpError_const___::_vftable_; /*0x142fb1071*/
      *(__m128d *)&v74._Mystorage._Ptrs[1] = _mm_unpacklo_pd(v54, (__m128d)(unsigned __int64)startTime.sec); /*0x142fb1081*/
      v74._Mystorage._Ptrs[7] = (std::_Func_base<void,HttpError const &> *)&v74; /*0x142fb108f*/
      StudioHttpRequest::setErrorCallback(this: p_m_request->_Ptr, callback: &v74); /*0x142fb10a0*/
      StudioHttpRequest::send(this: p_m_request->_Ptr); /*0x142fb10a8*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v82); /*0xf1c000000000002c*/
    }
    v51 = (volatile signed __int32 *)v6->_Rep; /*0x142fb10ae*/
    if ( v51 != nullptr && _InterlockedExchangeAdd(v51 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb10c2*/
    {
      (**(void (__fastcall ***)(volatile signed __int32 *))v51)(a1: v51); /*0x142fb10ca*/
      if ( _InterlockedExchangeAdd(v51 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb10d6*/
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v51 + 8LL))(a1: v51); /*0x142fb10de*/
    }
    v52 = (volatile signed __int32 *)v42->_Rep; /*0x142fb10e2*/
    if ( v52 != nullptr && _InterlockedExchangeAdd(v52 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb10f5*/
    {
      (**(void (__fastcall ***)(volatile signed __int32 *))v52)(a1: v52); /*0x142fb10fd*/
      if ( _InterlockedExchangeAdd(v52 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb1107*/
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v52 + 8LL))(a1: v52); /*0x142fb110f*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: span); /*0xf1c0000000000020*/
  }
}

// Address: 0x142fb1130 | Name: ?constructTeamCreateGameJoinRequest@CloudEditConnectionModel@@SA?AV?$shared_ptr@VStudioHttpRequest@@@std@@_J_N@Z
std::shared_ptr<StudioHttpRequest> *__fastcall CloudEditConnectionModel::constructTeamCreateGameJoinRequest(
        std::shared_ptr<StudioHttpRequest> *result,
        __int64 placeId,
        bool isPreemptive)
{
  char *v6; // rax
  char *v7; // rdi
  int v8; // ebx
  std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,RBX::Reflection::Variant> >,0> > *v9; // r15
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *first; // rdi
  const rbx::implementation::typed_holder<__int64> *v11; // rax
  const rbx::implementation::typed_holder<__int64> *v12; // r14
  const rbx::implementation::type_holder *holder; // rdx
  char *Ptr; // rcx
  char *v15; // rax
  rtc::webrtc_checks_impl::ToStringVal *v16; // rsi
  const rbx::implementation::typed_holder<std::string > *v17; // r14
  unsigned __int64 Myres; // rax
  std::string *p_gameJoinAttemptId; // rdx
  char *v20; // rcx
  __int64 v21; // rcx
  std::_Ref_count_base *Rep; // rbx
  std::string *started; // rax
  int v24; // ebx
  char *v25; // rcx
  char *v26; // rcx
  const char *v27; // rsi
  unsigned __int64 Mysize; // r15
  std::string *p_postJson; // r14
  __int64 v30; // rbx
  void *v31; // rax
  void *v32; // rcx
  _QWORD *v33; // rax
  std::string *p_url; // r14
  unsigned __int64 v35; // r15
  unsigned __int64 v36; // rbx
  void *v37; // rax
  void *v38; // rcx
  char *v39; // rax
  unsigned __int64 v40; // r8
  std::_Ref_count_base *v41; // rbx
  char *v42; // rcx
  char *v43; // rcx
  char *v44; // rcx
  std::_Ref_count_base *v45; // rbx
  std::shared_ptr<StudioHttpRequest> *v46; // rax
  __int64 v47; // [rsp+0h] [rbp-100h] BYREF
  int v48; // [rsp+20h] [rbp-E0h]
  std::string gameJoinAttemptId; // [rsp+28h] [rbp-D8h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > postData; // [rsp+50h] [rbp-B0h] BYREF
  std::string postJson; // [rsp+60h] [rbp-A0h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > value; // [rsp+80h] [rbp-80h] BYREF
  std::string _Keyval_arg; // [rsp+90h] [rbp-70h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v54; // [rsp+B0h] [rbp-50h] BYREF
  __int64 v55; // [rsp+E8h] [rbp-18h]
  std::string v56; // [rsp+F0h] [rbp-10h] BYREF
  std::shared_ptr<RBX::HttpRequest> v57; // [rsp+110h] [rbp+10h] BYREF
  std::shared_ptr<RBX::HttpRequest> httpReq; // [rsp+120h] [rbp+20h] BYREF
  std::string url; // [rsp+130h] [rbp+30h] BYREF
  std::string v60; // [rsp+150h] [rbp+50h] BYREF
  std::string v61; // [rsp+170h] [rbp+70h] BYREF
  std::string v62; // [rsp+190h] [rbp+90h] BYREF
  std::pair<std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> v63; // [rsp+1B8h] [rbp+B8h] BYREF
  std::pair<std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *,bool> v64; // [rsp+1C8h] [rbp+C8h] BYREF
  RBX::Reflection::Variant v65; // [rsp+1D8h] [rbp+D8h] BYREF
  void *v66; // [rsp+278h] [rbp+178h]

  v48 = 0; /*0x142fb1164*/
  v6 = (char *)operator new(size: 0x50u); /*0x142fb116d*/
  __wind /*0xf1c0000000000114*/
  {
    v7 = v6; /*0x142fb1172*/
    v66 = v6; /*0x142fb1175*/
    if ( v6 != nullptr ) /*0x142fb117f*/
    {
      *(_OWORD *)v6 = 0; /*0x142fb1184*/
      *((_DWORD *)v6 + 2) = 1; /*0x142fb1187*/
      *((_DWORD *)v6 + 3) = 1; /*0x142fb118e*/
      *(_QWORD *)v6 = std::_Ref_count_obj2<std::unordered_map<std::string,RBX::Reflection::Variant>>::`vftable'; /*0x142fb119c*/
      std::unordered_map<std::string,RBX::Reflection::Variant>::unordered_map<std::string,RBX::Reflection::Variant>(this: (std::unordered_map<std::string,RBX::Reflection::Variant> *)(v6 + 16)); /*0x142fb11a3*/
    }
    else
    {
      v7 = nullptr; /*0x142fb11aa*/
    }
  }
  __unwind
  {
    operator delete(ptr: v66); /*0x1431b28f5*/
  }
  __wind /*0xf1c000000000012c*/
  {
    __wind /*0xf1c0000000000134*/
    {
      v8 = 8; /*0x142fb11ad*/
      v48 = 8; /*0x142fb11b2*/
      v9 = (std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,RBX::Reflection::Variant> >,0> > *)(v7 + 16); /*0x142fb11b6*/
      postData._Ptr = (std::unordered_map<std::string,RBX::Reflection::Variant> *)(v7 + 16); /*0x142fb11ba*/
      postData._Rep = (std::_Ref_count_base *)v7; /*0x142fb11bf*/
      _Keyval_arg._Mypair._Myval2._Myres = 15; /*0x142fb11c8*/
      _Keyval_arg._Mypair._Myval2._Mysize = 7; /*0x142fb11d0*/
      strcpy(_Keyval_arg._Mypair._Myval2._Bx._Buf, "placeId"); /*0x142fb11de*/
      first = std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::_Try_emplace<std::string,>( /*0x142fb120d*/
                this: (std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,RBX::Reflection::Variant> >,0> > *)(v7 + 16),
                result: &v63,
                &_Keyval_arg)->first;
      first->_Myval.second._type = RBX::Reflection::Type::getSingleton<__int64>(); /*0x142fb1215*/
      v11 = rbx::implementation::typed_holder<__int64>::singleton(); /*0x142fb1219*/
      v12 = v11; /*0x142fb121e*/
      holder = first->_Myval.second.value.holder; /*0x142fb1221*/
      if ( holder != v11 ) /*0x142fb1228*/
      {
        if ( holder != nullptr ) /*0x142fb122d*/
          holder->destruct(a1: first->_Myval.second.value.data); /*0x142fb1237*/
        first->_Myval.second.value.holder = v12; /*0x142fb1239*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&_Keyval_arg); /*0xf1c000000000010c*/
    }
    *(_QWORD *)first->_Myval.second.value.data = placeId; /*0x142fb123d*/
    if ( _Keyval_arg._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb1249*/
    {
      Ptr = _Keyval_arg._Mypair._Myval2._Bx._Ptr; /*0x142fb124e*/
      if ( _Keyval_arg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb125c*/
      {
        Ptr = *((char **)_Keyval_arg._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb1262*/
        if ( (unsigned __int64)(_Keyval_arg._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x142fb1271*/
          _invalid_parameter_noinfo_noreturn(); /*0x142fb1273*/
      }
      operator delete(ptr: Ptr); /*0x142fb127a*/
    }
    __wind /*0xf1c00000000000fc*/
    {
      gameJoinAttemptId._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb1281*/
      gameJoinAttemptId._Mypair._Myval2._Mysize = 0; /*0x142fb1286*/
      gameJoinAttemptId._Mypair._Myval2._Myres = 15; /*0x142fb128b*/
      RBX::generateStandardGUIDNoCurlyBraces(result: &gameJoinAttemptId); /*0x142fb129e*/
      v54.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb12a3*/
      v54.text._Mypair._Myval2._Mysize = 0; /*0x142fb12a7*/
      v54.text._Mypair._Myval2._Myres = 15; /*0x142fb12ab*/
      v15 = (char *)operator new(size: 0x20u); /*0x142fb12ba*/
      v54.text._Mypair._Myval2._Mysize = 17; /*0x142fb12bf*/
      v54.text._Mypair._Myval2._Myres = 31; /*0x142fb12c7*/
      strcpy(v15, "gameJoinAttemptId"); /*0x142fb12d6*/
      v54.text._Mypair._Myval2._Bx._Ptr = v15; /*0x142fb12e7*/
      __wind /*0xf1c00000000000f0*/
      {
        v16 = (rtc::webrtc_checks_impl::ToStringVal *)std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::_Try_emplace<std::string,>( /*0x142fb12fe*/
                                                        this: v9,
                                                        result: &v64,
                                                        _Keyval_arg: &v54.text)->first;
        v16[1].val._Mypair._Myval2._Mysize = (unsigned __int64)RBX::Reflection::Type::getSingleton<std::string>(); /*0x142fb1306*/
        v17 = rbx::implementation::typed_holder<std::string>::singleton(); /*0x142fb130f*/
        Myres = v16[1].val._Mypair._Myval2._Myres; /*0x142fb1312*/
        if ( (const rbx::implementation::typed_holder<std::string > *)Myres == v17 ) /*0x142fb131d*/
        {
          if ( &v16[2] != (rtc::webrtc_checks_impl::ToStringVal *)&gameJoinAttemptId ) /*0x142fb1327*/
          {
            p_gameJoinAttemptId = &gameJoinAttemptId; /*0x142fb1329*/
            if ( gameJoinAttemptId._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb1334*/
              p_gameJoinAttemptId = (std::string *)gameJoinAttemptId._Mypair._Myval2._Bx._Ptr; /*0x142fb1334*/
            std::string::assign( /*0x142fb1342*/
              this: &v16[2].val,
              _Ptr: p_gameJoinAttemptId->_Mypair._Myval2._Bx._Buf,
              _Count: gameJoinAttemptId._Mypair._Myval2._Mysize);
          }
        }
        else
        {
          if ( Myres != 0 ) /*0x142fb134c*/
          {
            (*(void (__fastcall **)(rtc::webrtc_checks_impl::ToStringVal *))(Myres + 16))(a1: v16 + 2); /*0x142fb1355*/
            v16[1].val._Mypair._Myval2._Myres = 0; /*0x142fb1357*/
          }
          std::string::string(this: v16 + 2, __that: (const rtc::webrtc_checks_impl::ToStringVal *)&gameJoinAttemptId); /*0x142fb1367*/
          v16[1].val._Mypair._Myval2._Myres = (unsigned __int64)v17; /*0x142fb136c*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v54); /*0xf1c00000000000e8*/
      }
      if ( v54.text._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb1378*/
      {
        v20 = v54.text._Mypair._Myval2._Bx._Ptr; /*0x142fb137d*/
        if ( v54.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb138b*/
        {
          v20 = *((char **)v54.text._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb1391*/
          if ( (unsigned __int64)(v54.text._Mypair._Myval2._Bx._Ptr - v20 - 8) > 0x1F ) /*0x142fb13a0*/
            _invalid_parameter_noinfo_noreturn(); /*0x142fb13a2*/
        }
        operator delete(ptr: v20); /*0x142fb13a9*/
      }
      postJson._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb13b0*/
      postJson._Mypair._Myval2._Mysize = 0; /*0x142fb13b5*/
      postJson._Mypair._Myval2._Myres = 15; /*0x142fb13ba*/
      if ( postData._Rep != nullptr ) /*0x142fb13d0*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&postData._Rep->_Uses); /*0x142fb13d2*/
        v8 = v48; /*0x142fb13d6*/
      }
      __wind /*0xf1c0000000000140*/
      {
        __wind /*0xf1c0000000000148*/
        {
          value = (std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const >)postData; /*0x142fb13df*/
          RBX::Reflection::Variant::Variant(this: &v65, &value); /*0x142fb13ef*/
          __wind /*0xf1c00000000000a8*/
          {
            RBX::WebParser::writeJSON(value: &v65, result: &postJson, skip: SkipNonJSON); /*0x142fb1407*/
          }
          __unwind
          {
            std::tuple<bool,RBX::Reflection::Variant>::~tuple<bool,RBX::Reflection::Variant>(this: (RBX::setupTweenUpdate::__l5::<lambda_fde46e4afccb457705ab91f32d9aea10> *)&v65); /*0xf1c00000000000b8*/
          }
          __wind /*0xf1c00000000000c0*/
          {
            if ( v65.value.holder != nullptr ) /*0x142fb1417*/
              v65.value.holder->destruct(a1: v65.value.data); /*0x142fb1424*/
          }
          __unwind
          {
            __std_terminate(a1: v21, a2: &v47); /*0x142f39fa8*/
          }
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&value); /*0xf1c00000000000dc*/
        }
        if ( value._Rep != nullptr ) /*0x142fb1435*/
        {
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&value._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x142fb1441*/
          {
            Rep = value._Rep; /*0x142fb1443*/
            value._Rep->_Destroy(this: value._Rep); /*0x142fb144d*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb1459*/
              value._Rep->_Delete_this(this: value._Rep); /*0x142fb1462*/
          }
          v8 = v48; /*0x142fb1465*/
        }
        if ( isPreemptive ) /*0x142fb146c*/
        {
          started = ApiGameJoinUrlConstruction::constructPreemptiveStartTeamCreateUrl(result: &v61); /*0x142fb1472*/
          v24 = v8 | 1; /*0x142fb1478*/
        }
        else
        {
          started = ApiGameJoinUrlConstruction::constructJoinTeamCreateUrl(result: &v60); /*0x142fb1481*/
          v24 = v8 | 2; /*0x142fb1486*/
        }
        __wind /*0xf1c0000000000054*/
        {
          v48 = v24; /*0x142fb1489*/
          url = *started; /*0x142fb1490*/
          started->_Mypair._Myval2._Mysize = 0; /*0x142fb149c*/
          started->_Mypair._Myval2._Myres = 15; /*0x142fb14a0*/
          started->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb14a8*/
          if ( (v24 & 2) != 0 ) /*0x142fb14ae*/
          {
            v24 &= ~2u; /*0x142fb14b0*/
            v48 = v24; /*0x142fb14b3*/
            if ( v60._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb14bf*/
            {
              v25 = v60._Mypair._Myval2._Bx._Ptr; /*0x142fb14c4*/
              if ( v60._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb14d2*/
              {
                v25 = *((char **)v60._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb14d8*/
                if ( (unsigned __int64)(v60._Mypair._Myval2._Bx._Ptr - v25 - 8) > 0x1F ) /*0x142fb14e7*/
                  _invalid_parameter_noinfo_noreturn(); /*0x142fb14e9*/
              }
              operator delete(ptr: v25); /*0x142fb14f0*/
            }
            v60._Mypair._Myval2._Mysize = 0; /*0x142fb14f5*/
            v60._Mypair._Myval2._Myres = 15; /*0x142fb14f9*/
            v60._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb1501*/
          }
          if ( (v24 & 1) != 0 ) /*0x142fb1508*/
          {
            if ( v61._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb1515*/
            {
              v26 = v61._Mypair._Myval2._Bx._Ptr; /*0x142fb151a*/
              if ( v61._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb1528*/
              {
                v26 = *((char **)v61._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb152e*/
                if ( (unsigned __int64)(v61._Mypair._Myval2._Bx._Ptr - v26 - 8) > 0x1F ) /*0x142fb153d*/
                  _invalid_parameter_noinfo_noreturn(); /*0x142fb153f*/
              }
              operator delete(ptr: v26); /*0x142fb1546*/
            }
            v61._Mypair._Myval2._Mysize = 0; /*0x142fb154b*/
            v61._Mypair._Myval2._Myres = 15; /*0x142fb1552*/
            v61._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb155d*/
          }
          v27 = "CloudEditConnectionModel::connectToTeamCreateSession"; /*0x142fb1568*/
          if ( isPreemptive ) /*0x142fb1572*/
            v27 = "CloudEditConnectionModel::preemptiveStartTeamCreateSession"; /*0x142fb1572*/
          *(_QWORD *)&v54.x = 0; /*0x142fb1584*/
          *(_QWORD *)&v54.color = 0; /*0x142fb1588*/
          v55 = 0; /*0x142fb158c*/
          Mysize = postJson._Mypair._Myval2._Mysize; /*0x142fb1590*/
          p_postJson = &postJson; /*0x142fb1595*/
          if ( postJson._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb15a0*/
            p_postJson = (std::string *)postJson._Mypair._Myval2._Bx._Ptr; /*0x142fb15a0*/
        }
        __unwind
        {
          if ( (v48 & 1) != 0 ) /*0x1432c9891*/
          {
            v48 &= ~1u; /*0x1432c9893*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v61); /*0x1432c989e*/
          }
        }
        __wind /*0xf1c000000000006c*/
        {
          if ( Mysize >= 0x10 ) /*0x142fb15b4*/
          {
            v30 = Mysize | 0xF; /*0x142fb15c8*/
            if ( (Mysize | 0xF) > 0x7FFFFFFFFFFFFFFFLL ) /*0x142fb15cf*/
              v30 = 0x7FFFFFFFFFFFFFFFLL; /*0x142fb15cf*/
            if ( (unsigned __int64)(v30 + 1) < 0x1000 ) /*0x142fb15de*/
            {
              if ( v30 == -1 ) /*0x142fb1615*/
                v33 = nullptr; /*0x142fb161e*/
              else
                v33 = operator new(size: v30 + 1); /*0x142fb1617*/
            }
            else
            {
              if ( v30 + 40 < (unsigned __int64)(v30 + 1) ) /*0x142fb15e7*/
                std::_Throw_bad_array_new_length(); /*0x142fb18e5*/
              v31 = operator new(size: v30 + 40); /*0x142fb15f0*/
              v32 = v31; /*0x142fb15f5*/
              if ( v31 == nullptr ) /*0x142fb15fb*/
                _invalid_parameter_noinfo_noreturn(); /*0x142fb160b*/
              v33 = (_QWORD *)(((unsigned __int64)v31 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x142fb1601*/
              *(v33 - 1) = v32; /*0x142fb1605*/
            }
            *(_QWORD *)&v54.x = v33; /*0x142fb1621*/
            memcpy_0(a1: v33, Src: p_postJson, Size: Mysize + 1); /*0x142fb162f*/
          }
          else
          {
            *(std::_String_val<std::_Simple_types<char> >::_Bxty *)&v54.x = p_postJson->_Mypair._Myval2._Bx; /*0x142fb15ba*/
            v30 = 15; /*0x142fb15be*/
          }
          *(_QWORD *)&v54.color = Mysize; /*0x142fb163e*/
          v55 = v30; /*0x142fb1642*/
          __wind /*0xf1c0000000000048*/
          {
            v56._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb1646*/
            v56._Mypair._Myval2._Mysize = 0; /*0x142fb164a*/
            v56._Mypair._Myval2._Myres = 0; /*0x142fb164e*/
            p_url = &url; /*0x142fb1652*/
            if ( url._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb165b*/
              p_url = (std::string *)url._Mypair._Myval2._Bx._Ptr; /*0x142fb165b*/
            v35 = url._Mypair._Myval2._Mysize; /*0x142fb1660*/
            if ( url._Mypair._Myval2._Mysize >= 0x10 ) /*0x142fb1668*/
            {
              v36 = url._Mypair._Myval2._Mysize | 0xF; /*0x142fb167c*/
              if ( (url._Mypair._Myval2._Mysize | 0xF) > 0x7FFFFFFFFFFFFFFFLL ) /*0x142fb1683*/
                v36 = 0x7FFFFFFFFFFFFFFFLL; /*0x142fb1683*/
              if ( v36 + 1 < 0x1000 ) /*0x142fb1692*/
              {
                if ( v36 == -1 ) /*0x142fb16c9*/
                  v39 = nullptr; /*0x142fb16d2*/
                else
                  v39 = (char *)operator new(size: v36 + 1); /*0x142fb16cb*/
              }
              else
              {
                if ( v36 + 40 < v36 + 1 ) /*0x142fb169b*/
                  std::_Throw_bad_array_new_length(); /*0x142fb18df*/
                v37 = operator new(size: v36 + 40); /*0x142fb16a4*/
                v38 = v37; /*0x142fb16a9*/
                if ( v37 == nullptr ) /*0x142fb16af*/
                  _invalid_parameter_noinfo_noreturn(); /*0x142fb16bf*/
                v39 = (char *)(((unsigned __int64)v37 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x142fb16b5*/
                *((_QWORD *)v39 - 1) = v38; /*0x142fb16b9*/
              }
              v56._Mypair._Myval2._Bx._Ptr = v39; /*0x142fb16d5*/
              memcpy_0(a1: v39, Src: p_url, Size: v35 + 1); /*0x142fb16e3*/
            }
            else
            {
              v56._Mypair._Myval2._Bx = p_url->_Mypair._Myval2._Bx; /*0x142fb166e*/
              v36 = 15; /*0x142fb1672*/
            }
            v56._Mypair._Myval2._Mysize = v35; /*0x142fb16e8*/
            v56._Mypair._Myval2._Myres = v36; /*0x142fb16ec*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v54.x); /*0xf1c0000000000040*/
          }
          StudioHttpRequest::makeJsonHttpPostRequest(result: &httpReq, url: &v56, json: (std::string *)&v54.x); /*0x142fb16fc*/
          __wind /*0xf1c0000000000030*/
          {
            v62._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb1702*/
            v62._Mypair._Myval2._Mysize = 0; /*0x142fb1709*/
            v62._Mypair._Myval2._Myres = 15; /*0x142fb1710*/
            v40 = -1; /*0x142fb171b*/
            do /*0x142fb1728*/
              ++v40; /*0x142fb1720*/
            while ( v27[v40] != 0 ); /*0x142fb1728*/
            std::string::assign(this: &v62, _Ptr: v27, _Count: v40); /*0x142fb1734*/
            v57 = 0; /*0x142fb173c*/
            if ( httpReq._Rep != nullptr ) /*0x142fb1748*/
              _InterlockedIncrement((volatile signed __int32 *)&httpReq._Rep->_Uses); /*0x142fb174a*/
            v57 = httpReq; /*0x142fb1752*/
            StudioHttpRequest::create(result, req: &v57, name: &v62); /*0x142fb1765*/
          }
          __unwind
          {
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&httpReq); /*0xf1c0000000000028*/
          }
          v41 = httpReq._Rep; /*0x142fb176b*/
          if ( httpReq._Rep != nullptr /*0x142fb177e*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&httpReq._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v41->_Destroy(this: v41); /*0x142fb1786*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v41->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb1792*/
              v41->_Delete_this(this: v41); /*0x142fb179a*/
          }
          if ( url._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb17a6*/
          {
            v42 = url._Mypair._Myval2._Bx._Ptr; /*0x142fb17ab*/
            if ( url._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb17b9*/
            {
              v42 = *((char **)url._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb17bf*/
              if ( (unsigned __int64)(url._Mypair._Myval2._Bx._Ptr - v42 - 8) > 0x1F ) /*0x142fb17ce*/
                _invalid_parameter_noinfo_noreturn(); /*0x142fb17d0*/
            }
            operator delete(ptr: v42); /*0x142fb17d7*/
          }
          if ( postJson._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb17e6*/
          {
            v43 = postJson._Mypair._Myval2._Bx._Ptr; /*0x142fb17eb*/
            if ( postJson._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb17fa*/
            {
              v43 = *((char **)postJson._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb1800*/
              if ( (unsigned __int64)(postJson._Mypair._Myval2._Bx._Ptr - v43 - 8) > 0x1F ) /*0x142fb180f*/
                _invalid_parameter_noinfo_noreturn(); /*0x142fb1811*/
            }
            operator delete(ptr: v43); /*0x142fb1818*/
          }
          postJson._Mypair._Myval2._Mysize = 0; /*0x142fb181d*/
          postJson._Mypair._Myval2._Myres = 15; /*0x142fb1822*/
          postJson._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb182b*/
          if ( gameJoinAttemptId._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb1839*/
          {
            v44 = gameJoinAttemptId._Mypair._Myval2._Bx._Ptr; /*0x142fb183e*/
            if ( gameJoinAttemptId._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb184d*/
            {
              v44 = *((char **)gameJoinAttemptId._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb1853*/
              if ( (unsigned __int64)(gameJoinAttemptId._Mypair._Myval2._Bx._Ptr - v44 - 8) > 0x1F ) /*0x142fb1862*/
                _invalid_parameter_noinfo_noreturn(); /*0x142fb1864*/
            }
            operator delete(ptr: v44); /*0x142fb186b*/
          }
          gameJoinAttemptId._Mypair._Myval2._Mysize = 0; /*0x142fb1870*/
          gameJoinAttemptId._Mypair._Myval2._Myres = 15; /*0x142fb1875*/
          gameJoinAttemptId._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb187e*/
          if ( postData._Rep != nullptr /*0x142fb1897*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&postData._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v45 = postData._Rep; /*0x142fb1899*/
            postData._Rep->_Destroy(this: postData._Rep); /*0x142fb18a4*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v45->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb18ae*/
              postData._Rep->_Delete_this(this: postData._Rep); /*0x142fb18b8*/
          }
          v46 = result; /*0x142fb18bb*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&url); /*0xf1c000000000007c*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&postJson); /*0xf1c0000000000088*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&gameJoinAttemptId); /*0xf1c0000000000094*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&postData); /*0xf1c00000000000a0*/
  }
  return v46; /*0x142fb18be*/
}

// Address: 0x142fb2240 | Name: ?fillServerConnectionsArrayFromConfig@CloudEditConnectionModel@@CAXAEAV?$vector@UServerConnection@Client@Network@RBX@@V?$allocator@UServerConnection@Client@Network@RBX@@@std@@@std@@V?$shared_ptr@VEntityProperties@@@3@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@3@@Z
void __fastcall CloudEditConnectionModel::fillServerConnectionsArrayFromConfig(
        std::vector<RBX::Network::Client::ServerConnection> *endpoints,
        std::shared_ptr<RBX::File> *config,
        RBX::Graphics::ProfilerAdorn::Item *key)
{
  RBX::Graphics::ProfilerAdorn::Item *v3; // rdi
  std::shared_ptr<RBX::File> *v4; // rsi
  bool Has_value; // cl
  RBX::Reflection::Variant *Myfirst; // r13
  __int64 v7; // rdx
  unsigned __int64 i; // rcx
  const std::unordered_map<std::string,RBX::Reflection::Variant> *Ptr; // r15
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > > *v10; // rax
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v11; // rsi
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *Myhead; // r14
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v13; // rdi
  char **p_Myval; // rdx
  __int64 v15; // rdx
  unsigned __int64 j; // rcx
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > > *v17; // rax
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v18; // r8
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v19; // r10
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v20; // r9
  char **v21; // rdx
  __int64 v22; // rax
  unsigned __int8 v23; // cl
  int v24; // eax
  int v25; // ebx
  std::string *v26; // rax
  RBX::Network::Client::ServerConnection *v27; // rax
  RBX::Network::Client::ServerConnection *v28; // rdx
  std::_Ref_count_base *Rep; // rbx
  std::_Ref_count_base *v30; // rbx
  volatile signed __int32 *v31; // rbx
  unsigned __int64 Myres; // rdx
  char *v33; // rcx
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > oneEndpoint; // [rsp+20h] [rbp-E0h] BYREF
  _WORD Buf1[16]; // [rsp+30h] [rbp-D0h] BYREF
  _QWORD v36[4]; // [rsp+50h] [rbp-B0h]
  std::optional<std::shared_ptr<std::vector<RBX::Reflection::Variant> const > > endpointsArray; // [rsp+70h] [rbp-90h] BYREF
  std::string result; // [rsp+90h] [rbp-70h] BYREF
  RBX::Network::Client::ServerConnection v39; // [rsp+B0h] [rbp-50h] BYREF
  RBX::Reflection::Variant *Mylast; // [rsp+168h] [rbp+68h]

  __wind
  {
    __wind
    {
      v3 = key; /*0x142fb2267*/
      v4 = config; /*0x142fb226a*/
      if ( config->_Ptr != nullptr )
      {
        EntityProperties::get<std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>( /*0x142fb2289*/
          this: (EntityProperties *)config->_Ptr,
          result: &endpointsArray,
          fieldName: &key->text);
        Has_value = endpointsArray._Has_value; /*0x142fb228f*/
        if ( endpointsArray._Has_value )
        {
          Myfirst = endpointsArray._Value._Ptr->_Mypair._Myval2._Myfirst; /*0x142fb22a0*/
          Mylast = endpointsArray._Value._Ptr->_Mypair._Myval2._Mylast; /*0x142fb22a7*/
          if ( endpointsArray._Value._Ptr->_Mypair._Myval2._Myfirst != Mylast )
          {
            do
            {
              __wind
              {
                RBX::Reflection::Variant::get<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>( /*0x142fb22d0*/
                  this: Myfirst,
                  result: &oneEndpoint);
                *(_QWORD *)&Buf1[12] = 15; /*0x142fb22e1*/
                *(_QWORD *)&Buf1[8] = 7; /*0x142fb22ec*/
                qmemcpy(Buf1, "Addres", 6); /*0x142fb22f7*/
                Buf1[3] = (unsigned __int8)aAddress[6]; /*0x142fb230e*/
                v7 = 0xCBF29CE484222325uLL; /*0x142fb2321*/
                for ( i = 0; i < 7; ++i ) /*0x142fb2324*/
                  v7 = 0x100000001B3LL * (*((unsigned __int8 *)Buf1 + i) ^ (unsigned __int64)v7); /*0x142fb2338*/
                Ptr = oneEndpoint._Ptr; /*0x142fb2344*/
                v10 = oneEndpoint._Ptr->_Vec._Mypair._Myval2._Myfirst; /*0x142fb2353*/
                v11 = v10[2 * (v7 & oneEndpoint._Ptr->_Mask) + 1]._Ptr; /*0x142fb2357*/
                Myhead = oneEndpoint._Ptr->_List._Mypair._Myval2._Myhead; /*0x142fb235c*/
                if ( v11 == Myhead ) /*0x142fb2363*/
                  goto LABEL_16; /*0x142fb2363*/
                v13 = v10[2 * (v7 & oneEndpoint._Ptr->_Mask)]._Ptr; /*0x142fb2365*/
                while ( 1 ) /*0x142fb2370*/
                {
                  p_Myval = (char **)&v11->_Myval; /*0x142fb2370*/
                  if ( v11->_Myval.first._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb237d*/
                    p_Myval = (char **)*p_Myval; /*0x142fb237f*/
                  if ( v11->_Myval.first._Mypair._Myval2._Mysize == 7 && memcmp_0(Buf1, Buf2: p_Myval, Size: 7u) == 0 ) /*0x142fb239e*/
                    break; /*0x142fb239e*/
                  if ( v11 == v13 ) /*0x142fb23ad*/
                    goto LABEL_16; /*0x142fb23ad*/
                  v11 = v11->_Prev; /*0x142fb23af*/
                }
                if ( v11 == nullptr ) /*0x142fb23b8*/
LABEL_16:
                  v11 = Myhead; /*0x142fb23ba*/
                v36[3] = 15; /*0x142fb23ca*/
                v36[2] = 4; /*0x142fb23cf*/
                v36[0] = 1953656656; /*0x142fb23d8*/
                v15 = 0xCBF29CE484222325uLL; /*0x142fb23e5*/
                for ( j = 0; j < 4; ++j ) /*0x142fb23ef*/
                  v15 = 0x100000001B3LL * (*((unsigned __int8 *)v36 + j) ^ (unsigned __int64)v15); /*0x142fb2408*/
                v17 = Ptr->_Vec._Mypair._Myval2._Myfirst; /*0x142fb241f*/
                v18 = v17[2 * (v15 & Ptr->_Mask) + 1]._Ptr; /*0x142fb2423*/
                v19 = Ptr->_List._Mypair._Myval2._Myhead; /*0x142fb2428*/
                if ( v18 == v19 ) /*0x142fb242f*/
                  goto LABEL_33; /*0x142fb242f*/
                v20 = v17[2 * (v15 & Ptr->_Mask)]._Ptr; /*0x142fb2431*/
                while ( 1 )
                {
                  v21 = (char **)&v18->_Myval; /*0x142fb2440*/
                  if ( v18->_Myval.first._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb244d*/
                    v21 = (char **)*v21; /*0x142fb244f*/
                  if ( v18->_Myval.first._Mypair._Myval2._Mysize == 4 )
                  {
                    v22 = 0; /*0x142fb2458*/
                    while ( 1 ) /*0x142fb2460*/
                    {
                      v23 = *((_BYTE *)v36 + v22++); /*0x142fb2460*/
                      if ( v23 != *((_BYTE *)v21 + v22 - 1) ) /*0x142fb246c*/
                        break; /*0x142fb246c*/
                      if ( v22 == 4 ) /*0x142fb2472*/
                      {
                        v24 = 0; /*0x142fb2474*/
                        goto LABEL_29; /*0x142fb2477*/
                      }
                    }
                    v24 = v23 < *((_BYTE *)v21 + v22 - 1) ? -1 : 1;
LABEL_29:
                    if ( v24 == 0 ) /*0x142fb2480*/
                      break; /*0x142fb2480*/
                  }
                  if ( v18 == v20 ) /*0x142fb2485*/
                    goto LABEL_33; /*0x142fb2485*/
                  v18 = v18->_Prev; /*0x142fb2487*/
                }
                if ( v18 == nullptr ) /*0x142fb2490*/
LABEL_33:
                  v18 = Ptr->_List._Mypair._Myval2._Myhead; /*0x142fb2492*/
                if ( v11 != v19 && v18 != v19 ) /*0x142fb24a1*/
                {
                  __wind /*0xf1c0000000000028*/
                  {
                    v25 = RBX::Reflection::Variant::get<int>(this: &v18->_Myval.second); /*0x142fb24b0*/
                    v26 = RBX::Reflection::Variant::get<std::string>(this: &v11->_Myval.second, &result); /*0x142fb24ba*/
                    v27 = RBX::Network::Client::ServerConnection::ServerConnection(this: &v39, a: v26, p: v25); /*0x142fb24c9*/
                    __wind /*0xf1c000000000001c*/
                    {
                      v28 = endpoints->_Mypair._Myval2._Mylast; /*0x142fb24d5*/
                      if ( v28 == endpoints->_Mypair._Myval2._Myend ) /*0x142fb24dd*/
                      {
                        std::vector<RBX::Network::Client::ServerConnection>::_Emplace_reallocate<RBX::Network::Client::ServerConnection>( /*0x142fb254e*/
                          this: endpoints,
                          _Whereptr: v28,
                          <_Val_0>: v27);
                      }
                      else
                      {
                        v28->address._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb24df*/
                        v28->address._Mypair._Myval2._Mysize = 0; /*0x142fb24e2*/
                        v28->address._Mypair._Myval2._Myres = 0; /*0x142fb24e6*/
                        v28->address._Mypair._Myval2._Bx = v27->address._Mypair._Myval2._Bx; /*0x142fb24ed*/
                        *(_OWORD *)&v28->address._Mypair._Myval2._Mysize = *(_OWORD *)&v27->address._Mypair._Myval2._Mysize; /*0x142fb24f4*/
                        v27->address._Mypair._Myval2._Mysize = 0; /*0x142fb24f8*/
                        v27->address._Mypair._Myval2._Myres = 15; /*0x142fb24fc*/
                        v27->address._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb2500*/
                        v28->port = v27->port; /*0x142fb2506*/
                        v28->socketFamily = v27->socketFamily; /*0x142fb250e*/
                        v28->state = v27->state; /*0x142fb2516*/
                        v28->reportMetric._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb2519*/
                        v28->reportMetric._Mypair._Myval2._Mysize = 0; /*0x142fb251d*/
                        v28->reportMetric._Mypair._Myval2._Myres = 0; /*0x142fb2521*/
                        v28->reportMetric._Mypair._Myval2._Bx = v27->reportMetric._Mypair._Myval2._Bx; /*0x142fb252a*/
                        *(_OWORD *)&v28->reportMetric._Mypair._Myval2._Mysize = *(_OWORD *)&v27->reportMetric._Mypair._Myval2._Mysize; /*0x142fb2533*/
                        v27->reportMetric._Mypair._Myval2._Mysize = 0; /*0x142fb2537*/
                        v27->reportMetric._Mypair._Myval2._Myres = 15; /*0x142fb253b*/
                        v27->reportMetric._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb253f*/
                        ++endpoints->_Mypair._Myval2._Mylast; /*0x142fb2544*/
                      }
                    }
                    __unwind
                    {
                      RBX::Network::Client::ServerConnection::~ServerConnection(this: &v39); /*0xf1c0000000000014*/
                    }
                    RBX::Network::Client::ServerConnection::~ServerConnection(this: &v39); /*0x142fb2558*/
                  }
                  __unwind
                  {
                    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&oneEndpoint); /*0xf1c0000000000038*/
                  }
                }
              }
              __unwind
              {
                std::optional<std::shared_ptr<Luau::Scope>>::~optional<std::shared_ptr<Luau::Scope>>(this: (std::optional<std::shared_ptr<Luau::Scope> > *)&endpointsArray); /*0xf1c0000000000008*/
              }
              if ( oneEndpoint._Rep != nullptr /*0x142fb2573*/
                && _InterlockedExchangeAdd((volatile signed __int32 *)&oneEndpoint._Rep->_Uses, 0xFFFFFFFF) == 1 )
              {
                Rep = oneEndpoint._Rep; /*0x142fb2575*/
                oneEndpoint._Rep->_Destroy(this: oneEndpoint._Rep); /*0x142fb2580*/
                if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb258d*/
                  oneEndpoint._Rep->_Delete_this(this: oneEndpoint._Rep); /*0x142fb2597*/
              }
              ++Myfirst; /*0x142fb259a*/
            }
            while ( Myfirst != Mylast );
            Has_value = endpointsArray._Has_value; /*0x142fb25a8*/
            v3 = key; /*0x142fb25ac*/
            v4 = config; /*0x142fb25b0*/
          }
        }
        if ( Has_value ) /*0x142fb25bc*/
        {
          v30 = endpointsArray._Value._Rep; /*0x142fb25be*/
          if ( endpointsArray._Value._Rep != nullptr /*0x142fb25d3*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&endpointsArray._Value._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v30->_Destroy(this: v30); /*0x142fb25db*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v30->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb25e8*/
              v30->_Delete_this(this: v30); /*0x142fb25f0*/
          }
        }
      }
      v31 = (volatile signed __int32 *)v4->_Rep; /*0x142fb25f4*/
      if ( v31 != nullptr && _InterlockedExchangeAdd(v31 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb2608*/
      {
        (**(void (__fastcall ***)(volatile signed __int32 *))v31)(a1: v31); /*0x142fb2610*/
        if ( _InterlockedExchangeAdd(v31 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb261c*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v31 + 8LL))(a1: v31); /*0x142fb2624*/
      }
      Myres = v3->text._Mypair._Myval2._Myres; /*0x142fb2628*/
      if ( Myres >= 0x10 ) /*0x142fb2630*/
      {
        v33 = v3->text._Mypair._Myval2._Bx._Ptr; /*0x142fb2635*/
        if ( Myres + 1 >= 0x1000 ) /*0x142fb263f*/
        {
          if ( (unsigned __int64)&v33[-*((_QWORD *)v33 - 1) - 8] > 0x1F ) /*0x142fb2654*/
            _invalid_parameter_noinfo_noreturn(); /*0x142fb267d*/
          v33 = *((char **)v33 - 1); /*0x142fb2656*/
        }
        operator delete(ptr: v33); /*0x142fb2659*/
      }
      v3->text._Mypair._Myval2._Mysize = 0; /*0x142fb265e*/
      v3->text._Mypair._Myval2._Myres = 15; /*0x142fb2662*/
      v3->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb2666*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: config); /*0xf1c0000000000050*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: key); /*0xf1c000000000005c*/
  }
}

// Address: 0x142fb2690 | Name: ?getConnectResult@CloudEditConnectionModel@@QEBA?AUConnectionResult@1@XZ
bool *__fastcall CloudEditConnectionModel::getConnectResult(CloudEditConnectionModel *this, bool *a2)
{
  bool m_cancelled; // al

  m_cancelled = this->m_cancelled; /*0x142fb2690*/
  *a2 = m_cancelled; /*0x142fb2697*/
  if ( __PAIR16__(this->m_aborted, m_cancelled) != 0 /*0x142fb26b7*/
    || this->m_placeLauncherRequestStatus != 2
    || this->m_connectionResult != 0
    || !this->m_gameLoaded )
  {
    a2[1] = false; /*0x142fb26c1*/
    return a2; /*0x142fb26c5*/
  }
  else
  {
    a2[1] = true; /*0x142fb26b9*/
    return a2; /*0x142fb26bd*/
  }
}

// Address: 0x142fb26d0 | Name: ?getIsRetryNeededAndMaybeSetupTeamCreateConfig@CloudEditConnectionModel@@AEAA_NAEBVEntityProperties@@AEBVTime@RBX@@@Z
char __fastcall CloudEditConnectionModel::getIsRetryNeededAndMaybeSetupTeamCreateConfig(
        CloudEditConnectionModel *this,
        EntityProperties *properties,
        const RBX::Time *startTime)
{
  char *Ptr; // rcx
  std::optional<std::string > *p_error; // r8
  bool Has_value; // al
  const RBX::Reflection::Type *type; // rbx
  const RBX::Reflection::Type *v11; // rbx
  char *data; // rax
  unsigned int sec_low; // ebx
  char v14; // si
  __int64 v15; // rcx
  char *v16; // rcx
  char *v17; // rcx
  std::_Ref_count_base *v18; // rbx
  char *v19; // rax
  char *v20; // rbx
  EntityProperties *v21; // rcx
  std::_Ref_count_base *Rep; // rax
  EntityProperties *v23; // rbx
  char *v24; // rcx
  RBX::Security::KeyRing *Instance; // rax
  bool v26; // al
  const char *v27; // r9
  const std::string *v28; // rax
  char *v29; // rcx
  char *v30; // rcx
  std::string *v31; // rbx
  char *v32; // rcx
  char *v33; // rcx
  _WORD *v34; // rax
  char *v35; // rcx
  __int64 v36; // [rsp+0h] [rbp-100h] BYREF
  std::string counterName; // [rsp+20h] [rbp-E0h] BYREF
  std::string fieldName; // [rsp+40h] [rbp-C0h] BYREF
  std::string v39; // [rsp+60h] [rbp-A0h] BYREF
  std::optional<std::string > error; // [rsp+80h] [rbp-80h] BYREF
  std::optional<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > > settingsProp; // [rsp+A8h] [rbp-58h] BYREF
  std::optional<RBX::Reflection::Variant> v42; // [rsp+C0h] [rbp-40h] BYREF
  RBX::Time v43; // [rsp+168h] [rbp+68h] BYREF

  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000174*/
  counterName._Mypair._Myval2._Myres = 15; /*0x142fb26ff*/
  counterName._Mypair._Myval2._Mysize = 5; /*0x142fb2708*/
  *(_DWORD *)counterName._Mypair._Myval2._Bx._Buf = *(_DWORD *)"Error"; /*0x142fb2717*/
  *(_DWORD *)&counterName._Mypair._Myval2._Bx._Alias[4] = (unsigned __int8)category[4]; /*0x142fb2722*/
  EntityProperties::get<std::string>(this: properties, result: &error, fieldName: &counterName); /*0x142fb2737*/
  if ( counterName._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb2746*/
  {
    Ptr = counterName._Mypair._Myval2._Bx._Ptr; /*0x142fb274b*/
    if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb275a*/
    {
      Ptr = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb2760*/
      if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x142fb276f*/
        _invalid_parameter_noinfo_noreturn(); /*0x142fb2771*/
    }
    operator delete(ptr: Ptr); /*0x142fb2778*/
  }
  if ( __eh34_unwind(0) ) /*0xf1c0000000000168*/
  {
unwind_state_0:
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c000000000003c*/
    __eh34_propagate_exception_into_caller(0, -1); /*0xf1c0000000000040*/
  }
  __eh34_exit_wind_state(0, -1); /*0xf1c000000000016c*/
  counterName._Mypair._Myval2._Mysize = 0; /*0x142fb277d*/
  counterName._Mypair._Myval2._Myres = 15; /*0x142fb2782*/
  counterName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb278b*/
  if ( error._Has_value )
  {
    p_error = &error; /*0x142fb2796*/
    if ( error._Value._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb279f*/
      p_error = (std::optional<std::string > *)error._Value._Mypair._Myval2._Bx._Ptr; /*0x142fb279f*/
    __wind
    {
      RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "Error connecting to server: %s", (const char *)p_error);
    }
    __unwind
    {
      std::optional<std::string>::~optional<std::string>(this: (Luau::FunctionDefinition *)&error); /*0xf1c0000000000154*/
    }
    if ( error._Has_value ) /*0x142fb27ba*/
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&error); /*0x142fb27c4*/
      return 0; /*0x142fb27cb*/
    }
    return 0; /*0x142fb27ba*/
  }
  __wind /*0xf1c0000000000144*/
  {
    fieldName._Mypair._Myval2._Myres = 15; /*0x142fb27d5*/
    fieldName._Mypair._Myval2._Mysize = 6; /*0x142fb27de*/
    strcpy(fieldName._Mypair._Myval2._Bx._Buf, "status"); /*0x142fb27ed*/
    fieldName._Mypair._Myval2._Bx._Buf[7] = 0; /*0x142fb27f8*/
    EntityProperties::getVariant(this: properties, result: &v42, &fieldName); /*0x142fb280e*/
    Has_value = v42._Has_value; /*0x142fb2814*/
    if ( v42._Has_value ) /*0x142fb281a*/
    {
      __eh34_enter_wind_state(3, 4); /*0xf1c000000000013c*/
      type = v42._Value._type; /*0x142fb281c*/
      if ( type == RBX::Reflection::Type::getSingleton<int>() ) /*0x142fb2828*/
      {
        v11 = v42._Value._type; /*0x142fb282a*/
        if ( v11 != RBX::Reflection::Type::getSingleton<int>() ) /*0x142fb2836*/
          RBX::throw_runtime_error(fmt: "Variant cast failed"); /*0x142fb2ea6*/
        data = v42._Value.value.data; /*0x142fb283c*/
        if ( v42._Value.value.holder == nullptr ) /*0x142fb2847*/
          data = nullptr; /*0x142fb2847*/
        sec_low = *(_DWORD *)data; /*0x142fb284b*/
        v14 = 1; /*0x142fb284d*/
        if ( __eh34_unwind(4) ) /*0xf1c0000000000130*/
          goto unwind_state_4; /*0xf1c0000000000130*/
        __eh34_exit_wind_state(4, 3); /*0xf1c0000000000134*/
        if ( v42._Has_value && v42._Value.value.holder != nullptr ) /*0x142fb2859*/
        {
          __wind /*0xf1c0000000000124*/
          {
            v42._Value.value.holder->destruct(a1: v42._Value.value.data); /*0x142fb2863*/
          }
          __unwind
          {
            __std_terminate(a1: v15, a2: &v36); /*0x142f39fa8*/
          }
        }
LABEL_24:
        if ( fieldName._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb2893*/
        {
          v16 = fieldName._Mypair._Myval2._Bx._Ptr; /*0x142fb2898*/
          if ( fieldName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb28a7*/
          {
            v16 = *((char **)fieldName._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb28ad*/
            if ( (unsigned __int64)(fieldName._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x142fb28bc*/
              _invalid_parameter_noinfo_noreturn(); /*0x142fb28be*/
          }
          operator delete(ptr: v16); /*0x142fb28c5*/
        }
        goto LABEL_135; /*0xf1c00000000001ac*/
      }
      if ( __eh34_unwind(4) ) /*0xf1c0000000000104*/
      {
unwind_state_4:
        std::optional<RBX::Reflection::Variant>::~optional<RBX::Reflection::Variant>(this: &v42); /*0xf1c0000000000108*/
        __eh34_continue_unwinding(4, 3); /*0xf1c000000000010c*/
      }
      __eh34_exit_wind_state(4, 3); /*0xf1c0000000000110*/
      Has_value = v42._Has_value; /*0x142fb2868*/
    }
    v14 = 0; /*0x142fb286c*/
    if ( Has_value && v42._Value.value.holder != nullptr ) /*0x142fb287a*/
      v42._Value.value.holder->destruct(a1: v42._Value.value.data); /*0x142fb2884*/
    sec_low = LODWORD(v43.sec); /*0x142fb2887*/
    goto LABEL_24; /*0x142fb2887*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&fieldName); /*0xf1c00000000000fc*/
  }
LABEL_135:
  if ( v14 == 0 ) /*0x142fb28cd*/
    return 1; /*0x142fb28cd*/
  this->m_placeLauncherRequestStatus = sec_low; /*0x142fb28d3*/
  if ( sec_low <= 1 )
  {
    if ( (RBX::Time::nowFast(result: &v43)->sec - startTime->sec) * 1000.0 >= (double)FInt::CloudEditTimeoutTimeMs )
    {
      v39._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb2d9c*/
      v39._Mypair._Myval2._Mysize = 0; /*0x142fb2da1*/
      v39._Mypair._Myval2._Myres = 15; /*0x142fb2da6*/
      v34 = operator new(size: 0x40u); /*0x142fb2db9*/
      v39._Mypair._Myval2._Mysize = 57; /*0x142fb2dbe*/
      v39._Mypair._Myval2._Myres = 63; /*0x142fb2dc7*/
      qmemcpy(v34, "Studio.TeamCreate.JoinProgress.CloudSettingsLoadedTimeou", 56); /*0x142fb2dd7*/
      v34[28] = (unsigned __int8)aStudioTeamcrea_1[56]; /*0x142fb2e04*/
      v39._Mypair._Myval2._Bx._Ptr = (char *)v34; /*0x142fb2e0b*/
      __eh34_enter_wind_state(-1, 6); /*0xf1c0000000000030*/
      RBX::Analytics::EphemeralCounter::reportCounter(counterName: &v39, amount: 1, blocking: false); /*0x142fb2e1c*/
      if ( __eh34_unwind(6) ) /*0xf1c000000000001c*/
      {
unwind_state_6:
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v39); /*0xf1c0000000000020*/
        __eh34_propagate_exception_into_caller(6, -1); /*0xf1c0000000000024*/
      }
      __eh34_exit_wind_state(6, -1); /*0xf1c0000000000028*/
      if ( v39._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb2e2b*/
      {
        v35 = v39._Mypair._Myval2._Bx._Ptr; /*0x142fb2e30*/
        if ( v39._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb2e3f*/
        {
          v35 = *((char **)v39._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb2e45*/
          if ( (unsigned __int64)(v39._Mypair._Myval2._Bx._Ptr - v35 - 8) > 0x1F ) /*0x142fb2e54*/
            _invalid_parameter_noinfo_noreturn(); /*0x142fb2e56*/
        }
        operator delete(ptr: v35); /*0x142fb2e5d*/
      }
      if ( FLog::Error != 0 )
        FLog::FastLog(
          level: FLog::Error,
          message: "[FLog::Error] Timeout on connect, unable to initialize Team Create server: code %d",
          arg0: (const void *)this->m_placeLauncherRequestStatus);
      return 0; /*0x142fb2e78*/
    }
    return 1; /*0x142fb2e9e*/
  }
  if ( sec_low == 2 ) /*0x142fb28e2*/
  {
    __eh34_enter_wind_state(-1, 6); /*0xf1c00000000000f0*/
    v39._Mypair._Myval2._Myres = 15; /*0x142fb28e8*/
    v39._Mypair._Myval2._Mysize = 8; /*0x142fb28f1*/
    strcpy(v39._Mypair._Myval2._Bx._Buf, "settings"); /*0x142fb2904*/
    EntityProperties::get<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>( /*0x142fb291a*/
      this: properties,
      result: &settingsProp,
      fieldName: &v39);
    if ( v39._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb2929*/
    {
      v17 = v39._Mypair._Myval2._Bx._Ptr; /*0x142fb292e*/
      if ( v39._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb293d*/
      {
        v17 = *((char **)v39._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb2943*/
        if ( (unsigned __int64)(v39._Mypair._Myval2._Bx._Ptr - v17 - 8) > 0x1F ) /*0x142fb2952*/
          _invalid_parameter_noinfo_noreturn(); /*0x142fb2954*/
      }
      operator delete(ptr: v17); /*0x142fb295b*/
    }
    if ( __eh34_unwind(6) ) /*0xf1c00000000000e4*/
      goto unwind_state_6; /*0xf1c00000000000e4*/
    __eh34_exit_wind_state(6, -1); /*0xf1c00000000000e8*/
    v39._Mypair._Myval2._Mysize = 0; /*0x142fb2960*/
    v39._Mypair._Myval2._Myres = 15; /*0x142fb2965*/
    v39._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb296e*/
    if ( settingsProp._Has_value ) /*0x142fb2977*/
    {
      __wind /*0xf1c00000000000d8*/
      {
        v19 = (char *)operator new(size: 0xA8u); /*0x142fb29e6*/
        __wind /*0xf1c00000000000cc*/
        {
          v20 = v19; /*0x142fb29eb*/
          *(RBX::Time *)&v43.sec = (RBX::Time)v19; /*0x142fb29ee*/
          if ( v19 != nullptr ) /*0x142fb29f5*/
          {
            *(_OWORD *)v19 = 0; /*0x142fb29fa*/
            *((_DWORD *)v19 + 2) = 1; /*0x142fb29fd*/
            *((_DWORD *)v19 + 3) = 1; /*0x142fb2a04*/
            *(_QWORD *)v19 = std::_Ref_count_obj2<EntityProperties>::`vftable'; /*0x142fb2a12*/
            EntityProperties::EntityProperties(this: (EntityProperties *)(v19 + 16)); /*0x142fb2a19*/
          }
          else
          {
            v20 = nullptr; /*0x142fb2a20*/
          }
          v21 = (EntityProperties *)(v20 + 16); /*0x142fb2a23*/
          this->m_config._Ptr = (EntityProperties *)(v20 + 16); /*0x142fb2a27*/
          Rep = this->m_config._Rep; /*0x142fb2a2b*/
          this->m_config._Rep = (std::_Ref_count_base *)v20; /*0x142fb2a2f*/
          if ( Rep != nullptr ) /*0x142fb2a36*/
          {
            std::_Ref_count_base::_Decref(this: Rep); /*0x142fb2a3b*/
            v21 = this->m_config._Ptr; /*0x142fb2a40*/
          }
        }
        __unwind
        {
          operator delete(ptr: (void *)v43.sec); /*0x1432c98f5*/
        }
        EntityProperties::setFromValueTable( /*0x142fb2a48*/
          this: v21,
          valueTable: (const std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > *)&settingsProp);
        v23 = this->m_config._Ptr; /*0x142fb2a4d*/
        counterName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb2a51*/
        counterName._Mypair._Myval2._Mysize = 0; /*0x142fb2a56*/
        counterName._Mypair._Myval2._Myres = 15; /*0x142fb2a5b*/
        std::string::assign(this: &counterName, _Ptr: "ClientPublicKeyData", _Count: 0x13u); /*0x142fb2a7b*/
        __wind /*0xf1c000000000009c*/
        {
          EntityProperties::get<std::string>(this: v23, result: &error, fieldName: &counterName); /*0x142fb2a8d*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c00000000000ac*/
        }
        __wind /*0xf1c00000000000b4*/
        {
          if ( counterName._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb2a9c*/
          {
            v24 = counterName._Mypair._Myval2._Bx._Ptr; /*0x142fb2aa1*/
            if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb2ab0*/
            {
              v24 = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb2ab6*/
              if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - v24 - 8) > 0x1F ) /*0x142fb2ac5*/
                _invalid_parameter_noinfo_noreturn(); /*0x142fb2ac7*/
            }
            operator delete(ptr: v24); /*0x142fb2ace*/
          }
          counterName._Mypair._Myval2._Mysize = 0; /*0x142fb2ad3*/
          counterName._Mypair._Myval2._Myres = 15; /*0x142fb2ad8*/
          counterName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb2ae1*/
          if ( error._Has_value ) /*0x142fb2aea*/
          {
            Instance = RBX::Security::KeyRing::getInstance(); /*0x142fb2af0*/
            v26 = RBX::Security::KeyRing::parseConfig( /*0x142fb2aff*/
                    this: Instance,
                    config: (const std::string *)&error,
                    isDiagOnly: false);
            v27 = "Error"; /*0x142fb2b0b*/
            if ( v26 ) /*0x142fb2b14*/
              v27 = "Loaded"; /*0x142fb2b14*/
            v28 = RBX::format(result: &fieldName, fmt: "KeyRing%s%s", "TeamCreate", v27); /*0x142fb2b2b*/
            __wind /*0xf1c0000000000090*/
            {
              RBX::Analytics::EphemeralCounter::reportCounter(counterName: v28, amount: 0, blocking: false); /*0x142fb2b39*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&fieldName); /*0xf1c0000000000088*/
            }
            if ( fieldName._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb2b48*/
            {
              v29 = fieldName._Mypair._Myval2._Bx._Ptr; /*0x142fb2b4d*/
              if ( fieldName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb2b5c*/
              {
                v29 = *((char **)fieldName._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb2b62*/
                if ( (unsigned __int64)(fieldName._Mypair._Myval2._Bx._Ptr - v29 - 8) > 0x1F ) /*0x142fb2b71*/
                  _invalid_parameter_noinfo_noreturn(); /*0x142fb2b73*/
              }
              operator delete(ptr: v29); /*0x142fb2b7a*/
            }
          }
          if ( error._Has_value ) /*0x142fb2b84*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&error); /*0x142fb2b8a*/
        }
        __unwind
        {
          std::optional<std::string>::~optional<std::string>(this: (Luau::FunctionDefinition *)&error); /*0xf1c000000000007c*/
        }
        fieldName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb2b8f*/
        fieldName._Mypair._Myval2._Mysize = 0; /*0x142fb2b94*/
        fieldName._Mypair._Myval2._Myres = 15; /*0x142fb2b99*/
        std::string::assign( /*0x142fb2bb9*/
          this: &fieldName,
          _Ptr: "Studio.TeamCreate.JoinProgress.CloudSettingsLoadedReady",
          _Count: 0x37u);
        __wind /*0xf1c0000000000054*/
        {
          RBX::Analytics::EphemeralCounter::reportCounter(counterName: &fieldName, amount: 1, blocking: false); /*0x142fb2bcb*/
          if ( fieldName._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb2bda*/
          {
            v30 = fieldName._Mypair._Myval2._Bx._Ptr; /*0x142fb2be3*/
            if ( fieldName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb2bf2*/
            {
              v30 = *((char **)fieldName._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb2bf8*/
              if ( (unsigned __int64)(fieldName._Mypair._Myval2._Bx._Ptr - v30 - 8) > 0x1F ) /*0x142fb2c07*/
                _invalid_parameter_noinfo_noreturn(); /*0x142fb2c09*/
            }
            operator delete(ptr: v30); /*0x142fb2c10*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&fieldName); /*0xf1c0000000000064*/
        }
      }
      __unwind
      {
        std::optional<std::shared_ptr<Luau::Scope>>::~optional<std::shared_ptr<Luau::Scope>>(this: (std::optional<std::shared_ptr<Luau::Scope> > *)&settingsProp); /*0xf1c0000000000070*/
      }
    }
    else
    {
      this->m_connectionResult = InvalidSettings; /*0x142fb2979*/
      this->m_config._Ptr = nullptr; /*0x142fb2980*/
      v18 = this->m_config._Rep; /*0x142fb2984*/
      this->m_config._Rep = nullptr; /*0x142fb2988*/
      if ( v18 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v18->_Uses, 0xFFFFFFFF) == 1 ) /*0x142fb29a0*/
      {
        v18->_Destroy(this: v18); /*0x142fb29a8*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v18->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb29b2*/
          v18->_Delete_this(this: v18); /*0x142fb29ba*/
      }
    }
    if ( settingsProp._Has_value && settingsProp._Value._Rep != nullptr ) /*0x142fb29cf*/
    {
      std::_Ref_count_base::_Decref(this: settingsProp._Value._Rep); /*0x142fb29d5*/
      return 0; /*0x142fb29dc*/
    }
    return 0; /*0x142fb29cf*/
  }
  __eh34_enter_wind_state(-1, 0); /*0xf1c000000000004c*/
  counterName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb2c1a*/
  counterName._Mypair._Myval2._Mysize = 0; /*0x142fb2c1f*/
  counterName._Mypair._Myval2._Myres = 15; /*0x142fb2c24*/
  if ( sec_low - 5 <= 3 ) /*0x142fb2c38*/
  {
    v31 = RBX::format(result: &fieldName, fmt: "Studio.TeamCreate.JoinProgress.CloudSettingsLoadedError%d", sec_low); /*0x142fb2c6a*/
    if ( &counterName != v31 ) /*0x142fb2c75*/
    {
      if ( counterName._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb2c80*/
      {
        v32 = counterName._Mypair._Myval2._Bx._Ptr; /*0x142fb2c85*/
        if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb2c94*/
        {
          v32 = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb2c9a*/
          if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - v32 - 8) > 0x1F ) /*0x142fb2ca9*/
            _invalid_parameter_noinfo_noreturn(); /*0x142fb2cab*/
        }
        operator delete(ptr: v32); /*0x142fb2cb2*/
      }
      counterName._Mypair._Myval2._Mysize = 0; /*0x142fb2cb7*/
      counterName._Mypair._Myval2._Myres = 15; /*0x142fb2cbc*/
      counterName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb2cc5*/
      counterName = *v31; /*0x142fb2ccd*/
      v31->_Mypair._Myval2._Mysize = 0; /*0x142fb2cdb*/
      v31->_Mypair._Myval2._Myres = 15; /*0x142fb2cdf*/
      v31->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb2ce7*/
    }
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&fieldName); /*0x142fb2cef*/
  }
  else
  {
    std::string::assign( /*0x142fb2c4c*/
      this: &counterName,
      _Ptr: "Studio.TeamCreate.JoinProgress.CloudSettingsLoadedErrorUnknown",
      _Count: 0x3Eu);
  }
  RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x142fb2d00*/
  if ( FLog::Error != 0 )
    FLog::FastLog(
      level: FLog::Error,
      message: "[FLog::Error] Error on connect, unable to initialize Team Create server: code %d",
      arg0: (const void *)this->m_placeLauncherRequestStatus);
  if ( __eh34_unwind(0) ) /*0xf1c0000000000038*/
    goto unwind_state_0; /*0xf1c0000000000038*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000044*/
  if ( counterName._Mypair._Myval2._Myres < 0x10 ) /*0x142fb2d2a*/
    return 0; /*0x142fb2e7f*/
  v33 = counterName._Mypair._Myval2._Bx._Ptr; /*0x142fb2d33*/
  if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb2d42*/
  {
    v33 = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb2d48*/
    if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - v33 - 8) > 0x1F ) /*0x142fb2d57*/
      _invalid_parameter_noinfo_noreturn(); /*0x142fb2d59*/
  }
  operator delete(ptr: v33); /*0x142fb2d60*/
  return 0; /*0x142fb2e83*/
}

// Address: 0x142fb3fb0 | Name: ?onConnectionAccepted@CloudEditConnectionModel@@AEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$shared_ptr@VInstance@RBX@@@3@V?$weak_ptr@VDataModel@RBX@@@3@@Z
void __fastcall CloudEditConnectionModel::onConnectionAccepted(
        CloudEditConnectionModel *this,
        const std::string *url,
        std::shared_ptr<RBX::File> *replicator,
        std::weak_ptr<PluginPermissionsFetcher> *weakDM)
{
  TeamCreateDisconnectInfo *Instance; // rax
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v8; // rax
  RBX::Network::ClientReplicator *Ptr; // r15
  std::_Ref_count_base *v10; // rax
  char *v11; // rcx
  int v12; // edi
  int v13; // edi
  volatile signed __int32 *v14; // rbx
  volatile signed __int32 *v15; // rbx
  std::_Ref_count_base *v16; // rcx
  rbx::signals::slot_base *v17; // rax
  rbx::signals::slot_base *v18; // r14
  unsigned int parent; // ebx
  int v20; // edi
  __int64 v21; // rcx
  unsigned int v22; // edi
  std::_Ref_count_base *v23; // rax
  unsigned int v24; // ecx
  rbx::signals::slot_base *v25; // rax
  rbx::signals::slot_base *v26; // r15
  rbx::signals::signal_base *v27; // rcx
  unsigned int v28; // ebx
  __int64 v29; // rcx
  rbx::signals::scoped_connection *p_m_replicatorLoadedConnection; // rbx
  rbx::signals::slot_base *p; // rcx
  std::_Ref_count_base *v32; // rbx
  std::_Ref_count_base *v33; // rbx
  std::_Ref_count_base *v34; // rcx
  _BYTE v35[32]; // [rsp+0h] [rbp-100h] BYREF
  int v36; // [rsp+20h] [rbp-E0h]
  rbx::signals::signal_base *p_gameLoadedSignal; // [rsp+28h] [rbp-D8h]
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v38; // [rsp+30h] [rbp-D0h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v39; // [rsp+34h] [rbp-CCh] BYREF
  rbx::signals::connection other; // [rsp+38h] [rbp-C8h] BYREF
  std::shared_ptr<RBX::Network::ClientReplicator> rep; // [rsp+40h] [rbp-C0h] BYREF
  RBX::DataModel *v42; // [rsp+50h] [rbp-B0h]
  std::_Ref_count_base *v43; // [rsp+58h] [rbp-A8h]
  std::weak_ptr<PluginPermissionsFetcher> v44; // [rsp+60h] [rbp-A0h] BYREF
  char v45; // [rsp+70h] [rbp-90h] BYREF
  volatile signed __int32 *v46; // [rsp+78h] [rbp-88h]
  char v47; // [rsp+80h] [rbp-80h] BYREF
  volatile signed __int32 *v48; // [rsp+88h] [rbp-78h]
  __int64 v49; // [rsp+90h] [rbp-70h] BYREF
  rbx::signals::slot_base *v50; // [rsp+98h] [rbp-68h] BYREF
  rbx::signals::connection disconnectedConnection; // [rsp+A0h] [rbp-60h] BYREF
  __int128 v52; // [rsp+B8h] [rbp-48h]
  std::function<void __cdecl(void)> v53; // [rsp+C8h] [rbp-38h] BYREF
  rbx::signals::slot_base *v54; // [rsp+108h] [rbp+8h]

  v36 = 0; /*0x142fb3fe4*/
  __wind /*0xf1c0000000000134*/
  {
    __wind /*0xf1c000000000013c*/
    {
      Instance = TeamCreateDisconnectInfo::getInstance(); /*0x142fb3fe9*/
      TeamCreateDisconnectInfo::connectionAccepted(this: Instance); /*0x142fb3ff1*/
      if ( replicator->_Ptr != nullptr /*0x142fb4021*/
        && (descriptor = replicator->_Ptr->descriptor,
            v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(),
            descriptor->index - (unsigned int)v8->index <= v8->descendantCount) )
      {
        Ptr = (RBX::Network::ClientReplicator *)replicator->_Ptr; /*0x142fb4023*/
        v10 = replicator->_Rep; /*0x142fb4027*/
        if ( v10 != nullptr ) /*0x142fb402f*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v10->_Uses); /*0x142fb4031*/
          v10 = replicator->_Rep; /*0x142fb4035*/
        }
        v48 = (volatile signed __int32 *)v10; /*0x142fb403a*/
        v11 = &v47; /*0x142fb403e*/
        v12 = 1; /*0x142fb4042*/
      }
      else
      {
        v46 = nullptr; /*0x142fb4049*/
        v11 = &v45; /*0x142fb404e*/
        v12 = 2; /*0x142fb4053*/
        Ptr = nullptr; /*0x142fb4058*/
      }
      rep._Ptr = Ptr; /*0x142fb405b*/
      rep._Rep = *((std::_Ref_count_base **)v11 + 1); /*0x142fb4064*/
      *(_QWORD *)v11 = 0; /*0x142fb4069*/
      *((_QWORD *)v11 + 1) = 0; /*0x142fb406c*/
      v13 = v12 | 4; /*0x142fb4070*/
      v36 = v13; /*0x142fb4073*/
      if ( (v13 & 2) != 0 ) /*0x142fb4080*/
      {
        v13 &= ~2u; /*0x142fb4082*/
        v36 = v13; /*0x142fb4085*/
        if ( v46 != nullptr ) /*0x142fb4091*/
        {
          if ( _InterlockedExchangeAdd(v46 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb409d*/
          {
            v14 = v46; /*0x142fb409f*/
            (**(void (__fastcall ***)(volatile signed __int32 *))v46)(a1: v46); /*0x142fb40aa*/
            if ( _InterlockedExchangeAdd(v14 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb40b6*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v46 + 8LL))(a1: v46); /*0x142fb40c0*/
          }
          v13 = v36; /*0x142fb40c3*/
        }
      }
      if ( (v13 & 1) != 0 ) /*0x142fb40cb*/
      {
        v13 &= ~1u; /*0x142fb40cd*/
        v36 = v13; /*0x142fb40d0*/
        if ( v48 != nullptr ) /*0x142fb40db*/
        {
          if ( _InterlockedExchangeAdd(v48 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb40e7*/
          {
            v15 = v48; /*0x142fb40e9*/
            (**(void (__fastcall ***)(volatile signed __int32 *))v48)(a1: v48); /*0x142fb40f3*/
            if ( _InterlockedExchangeAdd(v15 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb40ff*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v48 + 8LL))(a1: v48); /*0x142fb4108*/
          }
          v13 = v36; /*0x142fb410b*/
        }
      }
      __wind /*0xf1c00000000000dc*/
      {
        if ( Ptr == nullptr ) /*0x142fb4112*/
          RBXCRASH(reason: "Missing ClientReplicator", message: pass); /*0x142fb4122*/
        if ( rep._Rep != nullptr ) /*0x142fb412f*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&rep._Rep->_Uses); /*0x142fb4131*/
          v13 = v36; /*0x142fb4135*/
        }
        v52 = 0; /*0x142fb413c*/
        v16 = weakDM->_Rep; /*0x142fb4141*/
        if ( v16 != nullptr ) /*0x142fb4148*/
        {
          *(_QWORD *)&v52 = weakDM->_Ptr; /*0x142fb414e*/
          *((_QWORD *)&v52 + 1) = v16; /*0x142fb4152*/
          _InterlockedIncrement((volatile signed __int32 *)&v16->_Weaks); /*0x142fb4156*/
          v13 = v36; /*0x142fb415a*/
        }
        v53._Mystorage._Ptrs[0] = (std::_Func_base<void> *)std::_Func_impl_no_alloc__lambda_2e7e1270ed97f772e1a3b597110fe1e3__void_::_vftable_; /*0x142fb4165*/
        v53._Mystorage._Ptrs[1] = (std::_Func_base<void> *)Ptr; /*0x142fb4169*/
        v53._Mystorage._Ptrs[2] = (std::_Func_base<void> *)rep._Rep; /*0x142fb4172*/
        *(_OWORD *)&v53._Mystorage._Ptrs[3] = v52; /*0x142fb417a*/
        v53._Mystorage._Ptrs[7] = (std::_Func_base<void> *)&v53; /*0x142fb418a*/
        runInUIThread(label: CloudEditConnectionModel_0, func: &v53); /*0x142fb4197*/
        disconnectedConnection.weak_slot.p_ = nullptr; /*0x142fb419c*/
        __wind /*0xf1c00000000000a0*/
        {
          v49 = 0; /*0x142fb41a0*/
          __wind /*0xf1c00000000000e8*/
          {
            __wind /*0xf1c00000000000f0*/
            {
              parent = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x142fb41af*/
              v38.parent = parent; /*0x142fb41b1*/
              __wind /*0xf1c000000000007c*/
              {
                v17 = (rbx::signals::slot_base *)operator new(size: 0x30u); /*0x142fb41ba*/
                v18 = v17; /*0x142fb41bf*/
                p_gameLoadedSignal = (rbx::signals::signal_base *)v17; /*0x142fb41c2*/
                if ( v17 != nullptr ) /*0x142fb41ca*/
                {
                  v17->strong._Storage._Value = 0; /*0x142fb41ce*/
                  v17->weak._Storage._Value = 1; /*0x142fb41d0*/
                  v17->call = (void (__fastcall *)(rbx::signals::slot_base *))rbx::signals::slot_with_functor__lambda_59332115020db6271a27695451911e6a__std::basic_string_char_std::char_traits_char__std::allocator_char____bool_std::basic_string_char_std::char_traits_char__std::allocator_char____int_::do_call; /*0x142fb41de*/
                  v17->dtor = rbx::signals::slot_with_functor__lambda_59332115020db6271a27695451911e6a__std::basic_string_char_std::char_traits_char__std::allocator_char____bool_std::basic_string_char_std::char_traits_char__std::allocator_char____int_::do_dtor; /*0x142fb41e9*/
                  v17->next.px = nullptr; /*0x142fb41ed*/
                  v17->owner = &Ptr->disconnectionSignal; /*0x142fb41f8*/
                  v17[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = 0; /*0x142fb41fc*/
                  v49 = 0; /*0x142fb4200*/
                  rbx::signals::signal_base::insert(this: &Ptr->disconnectionSignal, item: v17); /*0x142fb420a*/
                  v50 = v18; /*0x142fb420f*/
                  _InterlockedIncrement(&v18->weak._Storage._Value); /*0x142fb4218*/
                  v13 = v36; /*0x142fb421d*/
                  parent = v38.parent; /*0x142fb4221*/
                }
                else
                {
                  v18 = nullptr; /*0x142fb4227*/
                  rbx::signals::signal_base::insert(this: &Ptr->disconnectionSignal, item: nullptr); /*0x142fb4233*/
                  v50 = nullptr; /*0x142fb4238*/
                }
                v20 = v13 | 8; /*0x142fb423c*/
                v36 = v20; /*0x142fb423f*/
              }
              __unwind
              {
                RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v38); /*0xf1c000000000008c*/
              }
              __wind /*0xf1c0000000000094*/
              {
                RBX::Memory::setCurrentCategory(category: parent); /*0x142fb4245*/
              }
              __unwind
              {
                __std_terminate(a1: v21, a2: v35); /*0x142f39fa8*/
              }
              disconnectedConnection.weak_slot.p_ = v18; /*0x142fb424b*/
              v22 = v20 & 0xFFFFFFF7; /*0x142fb424f*/
              v36 = v22; /*0x142fb4252*/
              p_gameLoadedSignal = &Ptr->gameLoadedSignal; /*0x142fb425d*/
              v44 = 0; /*0x142fb4265*/
              v23 = weakDM->_Rep; /*0x142fb426b*/
              v42 = nullptr; /*0x142fb4271*/
              v43 = nullptr; /*0x142fb4276*/
              if ( v23 != nullptr ) /*0x142fb427e*/
              {
                v42 = (RBX::DataModel *)weakDM->_Ptr; /*0x142fb4284*/
                v44._Ptr = (PluginPermissionsFetcher *)v42; /*0x142fb4289*/
                v44._Rep = v23; /*0x142fb428e*/
                _InterlockedIncrement((volatile signed __int32 *)&v23->_Weaks); /*0x142fb4293*/
                v43 = v23; /*0x142fb4297*/
                v22 = v36; /*0x142fb429c*/
              }
              v24 = RBX::Memory::InstanceSignal; /*0x142fb42a0*/
            }
            __unwind
            {
              if ( (v36 & 8) != 0 ) /*0x1432c9931*/
              {
                v36 &= ~8u; /*0x1432c9933*/
                rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v50); /*0x1432c993e*/
              }
            }
          }
          __unwind
          {
            rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v49); /*0xf1c000000000010c*/
          }
          __wind /*0xf1c0000000000114*/
          {
            __wind /*0xf1c000000000011c*/
            {
              v28 = RBX::Memory::setCurrentCategory(category: v24); /*0x142fb42ab*/
              v39.parent = v28; /*0x142fb42ad*/
              __wind /*0xf1c000000000004c*/
              {
                v25 = (rbx::signals::slot_base *)operator new(size: 0x38u); /*0x142fb42b6*/
                v26 = v25; /*0x142fb42bb*/
                v54 = v25; /*0x142fb42be*/
                if ( v25 != nullptr ) /*0x142fb42c5*/
                {
                  v25->strong._Storage._Value = 0; /*0x142fb42c9*/
                  v25->weak._Storage._Value = 1; /*0x142fb42cb*/
                  v25->call = rbx::signals::slot_with_functor__lambda_a06e8f96f45760f7bebd6c123f911573___::do_call; /*0x142fb42d9*/
                  v25->dtor = rbx::signals::slot_with_functor<_lambda_02bea08bba0646978ba16fbcdd5be226_,std::string const &,enum RBX::NotificationServiceConnection::ConnectionState,std::string const &,std::string const &>::do_dtor; /*0x142fb42e4*/
                  v25->next.px = nullptr; /*0x142fb42e8*/
                  v27 = p_gameLoadedSignal; /*0x142fb42ec*/
                  v25->owner = p_gameLoadedSignal; /*0x142fb42f1*/
                  v25[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)v42; /*0x142fb42fa*/
                  v25[1].call = (void (__fastcall *)(rbx::signals::slot_base *))v43; /*0x142fb4303*/
                  v44 = 0; /*0x142fb430a*/
                }
                else
                {
                  v26 = nullptr; /*0x142fb4312*/
                  v27 = p_gameLoadedSignal; /*0x142fb4315*/
                }
                rbx::signals::signal_base::insert(this: v27, item: v26); /*0x142fb431d*/
                other.weak_slot.p_ = v26; /*0x142fb4322*/
                if ( v26 != nullptr ) /*0x142fb432a*/
                {
                  _InterlockedIncrement(&v26->weak._Storage._Value); /*0x142fb432c*/
                  v22 = v36; /*0x142fb4331*/
                  v28 = v39.parent; /*0x142fb4335*/
                }
                v36 = v22 | 0x10; /*0x142fb433c*/
              }
              __unwind
              {
                RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v39); /*0xf1c000000000005c*/
              }
              __wind /*0xf1c0000000000064*/
              {
                RBX::Memory::setCurrentCategory(category: v28); /*0x142fb4342*/
              }
              __unwind
              {
                __std_terminate(a1: v29, a2: v35); /*0xf1c000000000002c*/
              }
              p_m_replicatorLoadedConnection = &this->m_replicatorLoadedConnection; /*0x142fb434c*/
              if ( rbx::signals::connection::operator!=(this: &this->m_replicatorLoadedConnection.con, &other) ) /*0x142fb435b*/
              {
                rbx::signals::connection::disconnect(this: &p_m_replicatorLoadedConnection->con); /*0x142fb4367*/
                rbx::signals::connection::operator=(this: &p_m_replicatorLoadedConnection->con, con: &other); /*0x142fb4374*/
              }
            }
            __unwind
            {
              if ( (v36 & 0x10) != 0 ) /*0x1432c9961*/
              {
                v36 &= ~0x10u; /*0x1432c9963*/
                rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&other); /*0x1432c996b*/
              }
            }
            p = other.weak_slot.p_; /*0x142fb437a*/
            if ( other.weak_slot.p_ != nullptr /*0x142fb438e*/
              && _InterlockedExchangeAdd(&other.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
            {
              operator delete(ptr: p); /*0x142fb4390*/
            }
            if ( v44._Rep != nullptr /*0x142fb43aa*/
              && _InterlockedExchangeAdd((volatile signed __int32 *)&v44._Rep->_Weaks, 0xFFFFFFFF) == 1 )
            {
              v44._Rep->_Delete_this(this: v44._Rep); /*0x142fb43b4*/
            }
            if ( v18 != nullptr && _InterlockedExchangeAdd(&v18->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x142fb43c8*/
              operator delete(ptr: v18); /*0x142fb43cd*/
            if ( rep._Rep != nullptr /*0x142fb43e7*/
              && _InterlockedExchangeAdd((volatile signed __int32 *)&rep._Rep->_Uses, 0xFFFFFFFF) == 1 )
            {
              v32 = rep._Rep; /*0x142fb43e9*/
              rep._Rep->_Destroy(this: rep._Rep); /*0x142fb43f4*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v32->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb4400*/
                rep._Rep->_Delete_this(this: rep._Rep); /*0x142fb440a*/
            }
            v33 = replicator->_Rep; /*0x142fb440e*/
            if ( v33 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v33->_Uses, 0xFFFFFFFF) == 1 ) /*0x142fb4422*/
            {
              v33->_Destroy(this: v33); /*0x142fb442a*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v33->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb4436*/
                v33->_Delete_this(this: v33); /*0x142fb443e*/
            }
            v34 = weakDM->_Rep; /*0x142fb4442*/
            if ( v34 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v34->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb4453*/
              v34->_Delete_this(this: v34); /*0x142fb4458*/
          }
          __unwind
          {
            std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: &v44); /*0xf1c000000000012c*/
          }
        }
        __unwind
        {
          rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&disconnectedConnection); /*0xf1c00000000000b0*/
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&rep); /*0xf1c00000000000bc*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: replicator); /*0xf1c00000000000c8*/
    }
  }
  __unwind
  {
    std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: weakDM); /*0xf1c00000000000d4*/
  }
}

// Address: 0x142fb4480 | Name: ?onLocalPlayerCreateInCloudEdit_deprecated@CloudEditConnectionModel@@AEAAXV?$shared_ptr@VEntityProperties@@@std@@@Z
void __fastcall CloudEditConnectionModel::onLocalPlayerCreateInCloudEdit_deprecated(
        CloudEditConnectionModel *this,
        std::shared_ptr<RBX::File> *config)
{
  std::shared_ptr<RBX::File> *v2; // r12
  QtSharedPointer::ExternalRefCountData *d; // rcx
  IPlaceSessionModel *value; // rcx
  RBX::DataModel *OriginalDataModel; // rax
  RBX::DataModel *v6; // r8
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v9; // ett
  RBX::Reflection::DescribedBase *Ptr; // rcx
  char *v11; // rdx
  __int16 v12; // di
  RBX::DataModel *p_Rep; // r13
  __int16 v14; // di
  volatile signed __int32 *v15; // rbx
  volatile signed __int32 *v16; // rbx
  std::_Ref_count_base *v17; // rbx
  RBX::Players *v18; // r14
  std::_Ref_count_base *v19; // rbx
  RBX::Graphics::DeviceD3D11 *v20; // rax
  std::optional<std::string > *v21; // rbx
  char *v22; // rcx
  char *v23; // rcx
  EntityProperties *v24; // rbx
  char *v25; // rax
  bool Has_value; // al
  const RBX::Reflection::Type *type; // rbx
  const RBX::Reflection::Type *v28; // rbx
  char *data; // rax
  const rbx::implementation::type_holder *holder; // rcx
  char v31; // bl
  char *v32; // rcx
  std::shared_ptr<RBX::Player> *v33; // rax
  std::shared_ptr<RBX::Player> *v34; // rbx
  RBX::Player *v35; // rax
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *v37; // rax
  RBX::Player *v38; // r14
  volatile signed __int32 *v39; // rax
  char *v40; // rcx
  __int16 v41; // di
  __int64 v42; // rdx
  __int16 v43; // di
  volatile signed __int32 *v44; // rbx
  volatile signed __int32 *v45; // rbx
  std::_Ref_count_base *v46; // rbx
  EntityProperties *v47; // rbx
  char *v48; // rax
  std::optional<std::string > *v49; // rax
  char *v50; // rcx
  EntityProperties *v51; // rbx
  char *v52; // rax
  std::optional<__int64> *v53; // rax
  char *v54; // rcx
  RBX::RunService *v55; // rax
  rbx::signals::signal_base *p_heartbeatSignal; // r15
  char *v57; // rax
  rbx::signals::slot_base *v58; // r14
  unsigned int parent; // ebx
  __int64 v60; // rcx
  volatile signed __int32 *v61; // rbx
  const char *v62; // rax
  _BYTE v63[32]; // [rsp+0h] [rbp-358h] BYREF
  QPointer<IPlaceSessionModel> placeSessionModel; // [rsp+30h] [rbp-328h] BYREF
  std::shared_ptr<RBX::DataModel> dataModel; // [rsp+40h] [rbp-318h] BYREF
  char *v66; // [rsp+50h] [rbp-308h]
  __int64 v67; // [rsp+58h] [rbp-300h]
  char v68; // [rsp+60h] [rbp-2F8h] BYREF
  volatile signed __int32 *v69; // [rsp+68h] [rbp-2F0h]
  char v70; // [rsp+70h] [rbp-2E8h] BYREF
  volatile signed __int32 *v71; // [rsp+78h] [rbp-2E0h]
  char v72; // [rsp+80h] [rbp-2D8h] BYREF
  volatile signed __int32 *v73; // [rsp+88h] [rbp-2D0h]
  char v74; // [rsp+90h] [rbp-2C8h] BYREF
  volatile signed __int32 *v75; // [rsp+98h] [rbp-2C0h]
  std::string v76; // [rsp+A0h] [rbp-2B8h] BYREF
  std::string v77; // [rsp+C0h] [rbp-298h] BYREF
  std::string v78; // [rsp+E0h] [rbp-278h] BYREF
  std::string fieldName; // [rsp+100h] [rbp-258h] BYREF
  std::shared_ptr<RBX::Player> player; // [rsp+120h] [rbp-238h] BYREF
  RBX::UserInfo userInfo; // [rsp+130h] [rbp-228h] BYREF
  rbx::signals::slot_base *v82; // [rsp+230h] [rbp-128h] BYREF
  const std::exception *e; // [rsp+238h] [rbp-120h] BYREF
  std::shared_ptr<RBX::Player> v84; // [rsp+240h] [rbp-118h] BYREF
  __int128 v85; // [rsp+250h] [rbp-108h]
  std::optional<RBX::Reflection::Variant> v86; // [rsp+260h] [rbp-F8h] BYREF
  std::optional<std::string > result; // [rsp+2C0h] [rbp-98h] BYREF
  Luau::FunctionDefinition v88; // [rsp+2E8h] [rbp-70h] BYREF
  __int16 v90; // [rsp+370h] [rbp+18h]
  __int16 v91; // [rsp+370h] [rbp+18h]
  __int16 v92; // [rsp+370h] [rbp+18h]
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v93; // [rsp+378h] [rbp+20h] BYREF

  __wind
  {
    __eh34_enter_try_state(0, 1); /*0xf1c00000000001a4*/
    v2 = config; /*0x142fb4497*/
    MDIManagerHost::getFocusedPlaceSessionModel( /*0x142fb44af*/
      this: SingletonTemplate<MDIManagerHost>::m_instance._Ptr,
      result: &placeSessionModel);
    d = placeSessionModel.wp.d; /*0x142fb44b5*/
    if ( placeSessionModel.wp.d != nullptr )
    {
      if ( placeSessionModel.wp.d->strongref._q_value._Storage._Value != 0 && placeSessionModel.wp.value != nullptr )
      {
        value = nullptr; /*0x142fb44dc*/
        if ( placeSessionModel.wp.d->strongref._q_value._Storage._Value != 0 ) /*0x142fb44e0*/
          value = (IPlaceSessionModel *)placeSessionModel.wp.value; /*0x142fb44e0*/
        __eh34_enter_wind_state(1, 2); /*0xf1c0000000000174*/
        OriginalDataModel = IPlaceSessionModel::getOriginalDataModel(this: value); /*0x142fb44e6*/
        v6 = OriginalDataModel; /*0x142fb44eb*/
        if ( OriginalDataModel != nullptr ) /*0x142fb44f1*/
        {
          Rep = OriginalDataModel->_Wptr._Rep; /*0x142fb44f3*/
          if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x142fb4505*/
LABEL_150:
            std::_Throw_bad_weak_ptr(); /*0x142fb5053*/
          while ( 1 ) /*0x142fb4513*/
          {
            v9 = Uses; /*0x142fb4513*/
            Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x142fb4513*/
            if ( v9 == Uses ) /*0x142fb4518*/
              break; /*0x142fb4518*/
            if ( Uses == 0 ) /*0x142fb451c*/
              goto LABEL_150; /*0x142fb451c*/
          }
          Ptr = v6->_Wptr._Ptr; /*0x142fb4524*/
          v71 = (volatile signed __int32 *)v6->_Wptr._Rep; /*0x142fb452c*/
          v11 = &v70; /*0x142fb4531*/
          v12 = 19; /*0x142fb4536*/
          p_Rep = (RBX::DataModel *)&Ptr[-1]._Wptr._Rep; /*0x142fb453b*/
          if ( Ptr == nullptr ) /*0x142fb4542*/
            p_Rep = nullptr; /*0x142fb4542*/
        }
        else
        {
          v69 = nullptr; /*0x142fb4548*/
          v11 = &v68; /*0x142fb454d*/
          v12 = 4; /*0x142fb4552*/
          p_Rep = nullptr; /*0x142fb4557*/
        }
        dataModel._Ptr = p_Rep; /*0x142fb455a*/
        dataModel._Rep = *((std::_Ref_count_base **)v11 + 1); /*0x142fb4563*/
        *(_QWORD *)v11 = 0; /*0x142fb4568*/
        *((_QWORD *)v11 + 1) = 0; /*0x142fb456b*/
        v14 = v12 | 8; /*0x142fb456f*/
        v90 = v14; /*0x142fb4572*/
        if ( (v14 & 4) != 0 ) /*0x142fb457d*/
        {
          v14 &= ~4u; /*0x142fb457f*/
          v90 = v14; /*0x142fb4582*/
          if ( v69 != nullptr && _InterlockedExchangeAdd(v69 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb45a2*/
          {
            v15 = v69; /*0x142fb45a4*/
            (**(void (__fastcall ***)(volatile signed __int32 *))v69)(a1: v69); /*0x142fb45af*/
            if ( _InterlockedExchangeAdd(v15 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb45bb*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v69 + 8LL))(a1: v69); /*0x142fb45c5*/
          }
        }
        if ( (v14 & 2) != 0 ) /*0x142fb45da*/
        {
          v14 &= ~2u; /*0x142fb45dc*/
          v90 = v14; /*0x142fb45df*/
          if ( v71 != nullptr && _InterlockedExchangeAdd(v71 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb45fa*/
          {
            v16 = v71; /*0x142fb45fc*/
            (**(void (__fastcall ***)(volatile signed __int32 *))v71)(a1: v71); /*0x142fb4607*/
            if ( _InterlockedExchangeAdd(v16 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb4613*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v71 + 8LL))(a1: v71); /*0x142fb461d*/
          }
        }
        if ( (v14 & 1) != 0 ) /*0x142fb462b*/
        {
          v14 &= ~1u; /*0x142fb462d*/
          v90 = v14; /*0x142fb4630*/
        }
        if ( p_Rep == nullptr )
        {
          if ( dataModel._Rep != nullptr /*0x142fb4650*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&dataModel._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v17 = dataModel._Rep; /*0x142fb4652*/
            dataModel._Rep->_Destroy(this: dataModel._Rep); /*0x142fb465d*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v17->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb4669*/
              dataModel._Rep->_Delete_this(this: dataModel._Rep); /*0x142fb4673*/
          }
          if ( placeSessionModel.wp.d != nullptr /*0x142fb4697*/
            && _InterlockedExchangeAdd(&placeSessionModel.wp.d->weakref._q_value._Storage._Value, 0xFFFFFFFF) == 1
            && placeSessionModel.wp.d != nullptr )
          {
            operator delete(ptr: placeSessionModel.wp.d); /*0x142fb4699*/
          }
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v2); /*0x142fb46a2*/
          if ( __eh34_unwind(2) ) /*0xf1c00000000001ac*/
          {
            QPointer<MassUpdateWindow>::~QPointer<MassUpdateWindow>(this: (QPointer<FindReplaceLockedScriptsDialog> *)&placeSessionModel); /*0xf1c00000000001b0*/
            __eh34_continue_unwinding(2, 1); /*0xf1c00000000001b4*/
          }
LABEL_213:
          __eh34_exit_wind_state(2, 1); /*0xf1c00000000001b8*/
          if ( __eh34_catch(1) )
          {
            if ( __eh34_catch_type(1, &std::exception `RTTI Type Descriptor', &e) )
            {
              v62 = e->what(this: e); /*0x1432c9a17*/
              RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "Error while creating local player: %s", v62);
              v2 = config; /*0x142fb5030*/
              __eh34_enter_try_state(0, 1); /*0xf1c00000000001d4*/
              __eh34_enter_wind_state(1, 2); /*0xf1c00000000001d8*/
              __eh34_enter_wind_state(2, 3); /*0xf1c00000000001dc*/
              __eh34_enter_wind_state(3, 4); /*0xf1c00000000001e0*/
              __eh34_enter_wind_state(4, 11); /*0xf1c00000000001e4*/
              goto LABEL_149; /*0xf1c000000000001c*/
            }
          }
LABEL_204:
          __eh34_exit_try_state(1, 0); /*0xf1c000000000018c*/
          return; /*0xf1c000000000018c*/
        }
        __eh34_enter_wind_state(2, 3); /*0xf1c000000000016c*/
        v18 = (RBX::Players *)RBX::ServiceProvider::refByClass<RBX::Players>(this: &p_Rep->RBX::Described<RBX::DataModel,RBX::ServiceProvider>)->_Ptr; /*0x142fb46b5*/
        if ( v18 == nullptr ) /*0x142fb46bb*/
        {
          if ( dataModel._Rep != nullptr /*0x142fb46d1*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&dataModel._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v19 = dataModel._Rep; /*0x142fb46d3*/
            dataModel._Rep->_Destroy(this: dataModel._Rep); /*0x142fb46de*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v19->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb46ea*/
              dataModel._Rep->_Delete_this(this: dataModel._Rep); /*0x142fb46f4*/
          }
          if ( placeSessionModel.wp.d != nullptr /*0x142fb4718*/
            && _InterlockedExchangeAdd(&placeSessionModel.wp.d->weakref._q_value._Storage._Value, 0xFFFFFFFF) == 1
            && placeSessionModel.wp.d != nullptr )
          {
            operator delete(ptr: placeSessionModel.wp.d); /*0x142fb471a*/
          }
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v2); /*0x142fb4723*/
          goto LABEL_216; /*0x142fb4728*/
        }
        __eh34_enter_wind_state(3, 4); /*0xf1c0000000000164*/
        userInfo.userId = 0; /*0x142fb472f*/
        userInfo.isUnder13 = true; /*0x142fb4737*/
        userInfo.username._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb473f*/
        *(__m128i *)&userInfo.username._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x142fb474f*/
        userInfo.displayName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb475f*/
        *(_OWORD *)&userInfo.displayName._Mypair._Myval2._Mysize = *(_OWORD *)&userInfo.username._Mypair._Myval2._Mysize; /*0x142fb4767*/
        userInfo.membershipType = MEMBERSHIP_NONE; /*0x142fb4777*/
        userInfo.robloxLocaleId._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb477e*/
        userInfo.robloxLocaleId._Mypair._Myval2._Mysize = 0; /*0x142fb4786*/
        userInfo.robloxLocaleId._Mypair._Myval2._Myres = 15; /*0x142fb478e*/
        userInfo.gameLocaleId._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb47a1*/
        userInfo.gameLocaleId._Mypair._Myval2._Mysize = 0; /*0x142fb47a9*/
        userInfo.gameLocaleId._Mypair._Myval2._Myres = 15; /*0x142fb47b1*/
        userInfo.theme._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb47c4*/
        userInfo.theme._Mypair._Myval2._Mysize = 0; /*0x142fb47cc*/
        userInfo.theme._Mypair._Myval2._Myres = 15; /*0x142fb47d4*/
        userInfo.alternateName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb47e7*/
        userInfo.alternateName._Mypair._Myval2._Mysize = 0; /*0x142fb47ef*/
        userInfo.alternateName._Mypair._Myval2._Myres = 15; /*0x142fb47f7*/
        userInfo.platformName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb480a*/
        userInfo.platformName._Mypair._Myval2._Mysize = 0; /*0x142fb4812*/
        userInfo.platformName._Mypair._Myval2._Myres = 15; /*0x142fb481a*/
        v20 = (RBX::Graphics::DeviceD3D11 *)DEPRECATED_RobloxUser::singleton(); /*0x142fb482d*/
        userInfo.userId = (__int64)PluginQWidgetRelay::getQWidget(this: v20); /*0x142fb483a*/
        fieldName._Mypair._Myval2._Myres = 15; /*0x142fb4842*/
        fieldName._Mypair._Myval2._Mysize = 8; /*0x142fb484e*/
        strcpy(fieldName._Mypair._Myval2._Bx._Buf, "UserName"); /*0x142fb4861*/
        __wind /*0xf1c0000000000158*/
        {
          v21 = EntityProperties::get<std::string>(this: (EntityProperties *)v2->_Ptr, &result, &fieldName); /*0x142fb488a*/
          if ( &userInfo.username != (std::string *)v21 ) /*0x142fb4898*/
          {
            if ( userInfo.username._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb48aa*/
            {
              v22 = userInfo.username._Mypair._Myval2._Bx._Ptr; /*0x142fb48af*/
              if ( userInfo.username._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb48c1*/
              {
                v22 = *((char **)userInfo.username._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb48c7*/
                if ( (unsigned __int64)(userInfo.username._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x142fb48d6*/
                  _invalid_parameter_noinfo_noreturn(); /*0x142fb48d8*/
              }
              operator delete(ptr: v22); /*0x142fb48df*/
            }
            *(__m128i *)&userInfo.username._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x142fb48ec*/
            userInfo.username._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb48f5*/
            userInfo.username = (std::string)v21->___u0; /*0x142fb4900*/
            v21->_Value._Mypair._Myval2._Mysize = 0; /*0x142fb4916*/
            v21->_Value._Mypair._Myval2._Myres = 15; /*0x142fb491a*/
            v21->_Value._Mypair._Myval2._Bx._Buf[0] = 0; /*0x142fb4922*/
          }
          if ( result._Has_value ) /*0x142fb492c*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0x142fb4936*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&fieldName); /*0xf1c0000000000150*/
        }
        if ( fieldName._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb4948*/
        {
          v23 = fieldName._Mypair._Myval2._Bx._Ptr; /*0x142fb494d*/
          if ( fieldName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb495f*/
          {
            v23 = *((char **)fieldName._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb4965*/
            if ( (unsigned __int64)(fieldName._Mypair._Myval2._Bx._Ptr - v23 - 8) > 0x1F ) /*0x142fb4974*/
              _invalid_parameter_noinfo_noreturn(); /*0x142fb4976*/
          }
          operator delete(ptr: v23); /*0x142fb497d*/
        }
        v24 = (EntityProperties *)v2->_Ptr; /*0x142fb4982*/
        v76._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb4988*/
        v76._Mypair._Myval2._Mysize = 0; /*0x142fb4990*/
        v76._Mypair._Myval2._Myres = 15; /*0x142fb4998*/
        v25 = (char *)operator new(size: 0x20u); /*0x142fb49ae*/
        v76._Mypair._Myval2._Mysize = 18; /*0x142fb49b3*/
        v76._Mypair._Myval2._Myres = 31; /*0x142fb49bf*/
        strcpy(v25, "IsUnknownOrUnder13"); /*0x142fb49d2*/
        v76._Mypair._Myval2._Bx._Ptr = v25; /*0x142fb49e4*/
        __wind /*0xf1c0000000000140*/
        {
          EntityProperties::getVariant(this: v24, result: &v86, fieldName: &v76); /*0x142fb49ff*/
          __eh34_enter_wind_state(6, 7); /*0xf1c0000000000138*/
          Has_value = v86._Has_value; /*0x142fb4a05*/
          if ( v86._Has_value ) /*0x142fb4a0f*/
          {
            type = v86._Value._type; /*0x142fb4a11*/
            if ( type == RBX::Reflection::Type::getSingleton<bool>() ) /*0x142fb4a21*/
            {
              v28 = v86._Value._type; /*0x142fb4a23*/
              if ( v28 != RBX::Reflection::Type::getSingleton<bool>() ) /*0x142fb4a33*/
                RBX::throw_runtime_error(fmt: "Variant cast failed"); /*0x142fb5060*/
              data = v86._Value.value.data; /*0x142fb4a39*/
              holder = v86._Value.value.holder; /*0x142fb4a41*/
              if ( v86._Value.value.holder == nullptr ) /*0x142fb4a51*/
                data = nullptr; /*0x142fb4a51*/
              v31 = *data; /*0x142fb4a55*/
              if ( __eh34_unwind(7) ) /*0xf1c000000000012c*/
                goto unwind_state_7; /*0xf1c000000000012c*/
              __eh34_exit_wind_state(7, 6); /*0xf1c0000000000130*/
              if ( v86._Has_value ) /*0x142fb4a5f*/
              {
                __wind /*0xf1c0000000000120*/
                {
                  if ( v86._Value.value.holder != nullptr ) /*0x142fb4a64*/
                    v86._Value.value.holder->destruct(a1: v86._Value.value.data); /*0x142fb4a72*/
                }
                __unwind
                {
                  __std_terminate(a1: holder, a2: v63); /*0x142f39fa8*/
                }
              }
LABEL_79:
              userInfo.isUnder13 = v31; /*0x142fb4aa7*/
              if ( v76._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb4aba*/
              {
                v32 = v76._Mypair._Myval2._Bx._Ptr; /*0x142fb4abf*/
                if ( v76._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb4ad1*/
                {
                  v32 = *((char **)v76._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb4ad7*/
                  if ( (unsigned __int64)(v76._Mypair._Myval2._Bx._Ptr - v32 - 8) > 0x1F ) /*0x142fb4ae6*/
                    _invalid_parameter_noinfo_noreturn(); /*0x142fb4ae8*/
                }
                operator delete(ptr: v32); /*0x142fb4aef*/
              }
              goto LABEL_184; /*0xf1c000000000022c*/
            }
            Has_value = v86._Has_value; /*0x142fb4a77*/
          }
          if ( Has_value && v86._Value.value.holder != nullptr ) /*0x142fb4a8e*/
            v86._Value.value.holder->destruct(a1: v86._Value.value.data); /*0x142fb4a9c*/
          if ( __eh34_unwind(7) ) /*0xf1c000000000010c*/
          {
unwind_state_7:
            std::optional<RBX::Reflection::Variant>::~optional<RBX::Reflection::Variant>(this: &v86); /*0xf1c0000000000110*/
            __eh34_continue_unwinding(7, 6); /*0xf1c0000000000114*/
          }
          __eh34_exit_wind_state(7, 6); /*0xf1c0000000000118*/
          v31 = v90; /*0x142fb4a9f*/
          goto LABEL_79; /*0xf1c000000000011c*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v76); /*0xf1c00000000000f8*/
        }
LABEL_184:
        LODWORD(v67) = RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2->storage.asRaw[0] /*0x142fb4aff*/
                     - LODWORD(RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2);
        HIDWORD(v67) = RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2->storage.asRaw[1] /*0x142fb4b08*/
                     - LODWORD(RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2);
        v33 = RBX::Players::createLocalPlayer( /*0x142fb4b30*/
                this: v18,
                result: &v84,
                &userInfo,
                teleportedIn: v67 > 0,
                previousUniverseId: 0);
        __wind /*0xf1c00000000000d4*/
        {
          v34 = v33; /*0x142fb4b35*/
          v35 = v33->_Ptr; /*0x142fb4b38*/
          if ( v35 != nullptr /*0x142fb4b63*/
            && (descriptor = v35->descriptor,
                v37 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(),
                descriptor->index - (unsigned int)v37->index <= v37->descendantCount) )
          {
            v38 = v34->_Ptr; /*0x142fb4b65*/
            v39 = (volatile signed __int32 *)v34->_Rep; /*0x142fb4b68*/
            if ( v39 != nullptr ) /*0x142fb4b6f*/
            {
              _InterlockedIncrement(v39 + 2); /*0x142fb4b71*/
              v39 = (volatile signed __int32 *)v34->_Rep; /*0x142fb4b75*/
              v14 = v90; /*0x142fb4b79*/
            }
            v75 = v39; /*0x142fb4b80*/
            v40 = &v74; /*0x142fb4b88*/
            v41 = v14 | 0x20; /*0x142fb4b90*/
            v42 = 0; /*0x142fb4b93*/
          }
          else
          {
            v42 = 0; /*0x142fb4b97*/
            v73 = nullptr; /*0x142fb4b99*/
            v40 = &v72; /*0x142fb4ba1*/
            v41 = v14 | 0x40; /*0x142fb4ba9*/
            v38 = nullptr; /*0x142fb4bac*/
          }
          player._Ptr = v38; /*0x142fb4baf*/
          player._Rep = *((std::_Ref_count_base **)v40 + 1); /*0x142fb4bbb*/
          *(_QWORD *)v40 = 0; /*0x142fb4bc3*/
          *((_QWORD *)v40 + 1) = 0; /*0x142fb4bc6*/
          v43 = v41 | 0x80; /*0x142fb4bca*/
          v91 = v43; /*0x142fb4bce*/
          if ( (v43 & 0x40) != 0 ) /*0x142fb4bd9*/
          {
            v43 &= ~0x40u; /*0x142fb4bdb*/
            v91 = v43; /*0x142fb4bde*/
            if ( v73 != nullptr && _InterlockedExchangeAdd(v73 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb4bfc*/
            {
              v44 = v73; /*0x142fb4bfe*/
              (**(void (__fastcall ***)(volatile signed __int32 *, _QWORD))v73)(a1: v73, a2: 0); /*0x142fb4c0c*/
              if ( _InterlockedExchangeAdd(v44 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb4c18*/
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v73 + 8LL))(a1: v73); /*0x142fb4c25*/
            }
          }
          if ( (v43 & 0x20) != 0 ) /*0x142fb4c33*/
          {
            v43 &= ~0x20u; /*0x142fb4c35*/
            v91 = v43; /*0x142fb4c38*/
            if ( v75 != nullptr && _InterlockedExchangeAdd(v75 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb4c56*/
            {
              v45 = v75; /*0x142fb4c58*/
              (**(void (__fastcall ***)(volatile signed __int32 *, __int64))v75)(a1: v75, a2: v42); /*0x142fb4c66*/
              if ( _InterlockedExchangeAdd(v45 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb4c72*/
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v75 + 8LL))(a1: v75); /*0x142fb4c7f*/
            }
          }
          v46 = v84._Rep; /*0x142fb4c89*/
          if ( v84._Rep != nullptr ) /*0x142fb4c94*/
          {
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v84._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x142fb4ca0*/
            {
              ((void (__fastcall *)(std::_Ref_count_base *, __int64))v46->_Destroy)(a1: v46, a2: v42); /*0x142fb4ca8*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v46->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb4cb4*/
                v46->_Delete_this(this: v46); /*0x142fb4cbc*/
            }
            v43 = v91; /*0x142fb4cbf*/
          }
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v84); /*0xf1c00000000000e4*/
        }
        __eh34_enter_wind_state(4, 11); /*0xf1c00000000000ec*/
        v47 = (EntityProperties *)v2->_Ptr; /*0x142fb4cc6*/
        v77._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb4ccc*/
        v77._Mypair._Myval2._Mysize = 0; /*0x142fb4cd4*/
        v77._Mypair._Myval2._Myres = 15; /*0x142fb4cdc*/
        v48 = (char *)operator new(size: 0x20u); /*0x142fb4cf2*/
        __wind /*0xf1c00000000000c8*/
        {
          v77._Mypair._Myval2._Mysize = 19; /*0x142fb4cf7*/
          v77._Mypair._Myval2._Myres = 31; /*0x142fb4d03*/
          strcpy(v48, "CharacterAppearance"); /*0x142fb4d16*/
          v77._Mypair._Myval2._Bx._Ptr = v48; /*0x142fb4d32*/
          v49 = EntityProperties::get<std::string>(this: v47, result: &v88.definitionModuleName, fieldName: &v77); /*0x142fb4d4d*/
          __wind /*0xf1c00000000000a4*/
          {
            RBX::Player::setCharacterAppearance(this: v38, value: (const std::string *)v49); /*0x142fb4d59*/
            if ( v88.definitionModuleName._Has_value ) /*0x142fb4d67*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v88); /*0x142fb4d71*/
            if ( v77._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb4d83*/
            {
              v50 = v77._Mypair._Myval2._Bx._Ptr; /*0x142fb4d88*/
              if ( v77._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb4d9a*/
              {
                v50 = *((char **)v77._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb4da0*/
                if ( (unsigned __int64)(v77._Mypair._Myval2._Bx._Ptr - v50 - 8) > 0x1F ) /*0x142fb4daf*/
                  _invalid_parameter_noinfo_noreturn(); /*0x142fb4db1*/
              }
              operator delete(ptr: v50); /*0x142fb4db8*/
            }
          }
          __unwind
          {
            std::optional<std::string>::~optional<std::string>(this: &v88); /*0xf1c00000000000b4*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v77); /*0xf1c00000000000c0*/
        }
        v51 = (EntityProperties *)v2->_Ptr; /*0x142fb4dbd*/
        v78._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142fb4dc3*/
        v78._Mypair._Myval2._Mysize = 0; /*0x142fb4dcb*/
        v78._Mypair._Myval2._Myres = 15; /*0x142fb4dd3*/
        v52 = (char *)operator new(size: 0x20u); /*0x142fb4de9*/
        __wind /*0xf1c0000000000098*/
        {
          v78._Mypair._Myval2._Mysize = 21; /*0x142fb4dee*/
          v78._Mypair._Myval2._Myres = 31; /*0x142fb4dfa*/
          strcpy(v52, "characterAppearanceId"); /*0x142fb4e0d*/
          v78._Mypair._Myval2._Bx._Ptr = v52; /*0x142fb4e27*/
          v53 = EntityProperties::getConverted<__int64>( /*0x142fb4e42*/
                  this: v51,
                  result: (std::optional<__int64> *)&v88.definitionLocation,
                  fieldName: &v78);
          RBX::Player::setCharacterAppearanceId(this: v38, value: v53->_Value); /*0x142fb4e4d*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v78); /*0xf1c0000000000090*/
        }
        if ( v78._Mypair._Myval2._Myres >= 0x10 ) /*0x142fb4e5f*/
        {
          v54 = v78._Mypair._Myval2._Bx._Ptr; /*0x142fb4e64*/
          if ( v78._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142fb4e76*/
          {
            v54 = *((char **)v78._Mypair._Myval2._Bx._Ptr - 1); /*0x142fb4e7c*/
            if ( (unsigned __int64)(v78._Mypair._Myval2._Bx._Ptr - v54 - 8) > 0x1F ) /*0x142fb4e8b*/
              _invalid_parameter_noinfo_noreturn(); /*0x142fb4e8d*/
          }
          operator delete(ptr: v54); /*0x142fb4e94*/
        }
        v55 = RBX::ServiceProvider::create<RBX::RunService>(this: &p_Rep->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x142fb4e9d*/
        if ( v55 != nullptr ) /*0x142fb4ea5*/
        {
          p_heartbeatSignal = &v55->heartbeatSignal; /*0x142fb4eab*/
          *((_QWORD *)&v85 + 1) = p_Rep; /*0x142fb4eb2*/
          __wind /*0xf1c0000000000080*/
          {
            parent = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x142fb4ec5*/
            v93.parent = parent; /*0x142fb4ec7*/
            __wind /*0xf1c0000000000044*/
            {
              v57 = (char *)operator new(size: 0x38u); /*0x142fb4ed3*/
              v58 = (rbx::signals::slot_base *)v57; /*0x142fb4ed8*/
              v66 = v57; /*0x142fb4edb*/
              if ( v57 != nullptr ) /*0x142fb4ee3*/
              {
                *(_DWORD *)v57 = 0; /*0x142fb4ee7*/
                *((_DWORD *)v57 + 1) = 1; /*0x142fb4ee9*/
                *((_QWORD *)v57 + 1) = rbx::signals::slot_with_functor_boost::_bi::bind_t_void__lambda_8d23873b4135370dc0983445c90d14c1__boost::_bi::list1_boost::_bi::value_RBX::DataModel________RBX::Heartbeat_const___::do_call; /*0x142fb4ef7*/
                *((_QWORD *)v57 + 2) = RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x142fb4f02*/
                *((_QWORD *)v57 + 3) = 0; /*0x142fb4f06*/
                *((_QWORD *)v57 + 4) = p_heartbeatSignal; /*0x142fb4f0a*/
                *(_OWORD *)(v57 + 40) = v85; /*0x142fb4f16*/
              }
              else
              {
                v58 = nullptr; /*0x142fb4f1d*/
              }
              rbx::signals::signal_base::insert(this: p_heartbeatSignal, item: v58); /*0x142fb4f26*/
              v82 = v58; /*0x142fb4f2b*/
              if ( v58 != nullptr ) /*0x142fb4f36*/
              {
                _InterlockedIncrement(&v58->weak._Storage._Value); /*0x142fb4f38*/
                v43 = v91; /*0x142fb4f3d*/
                parent = v93.parent; /*0x142fb4f44*/
              }
              v92 = v43 | 0x100; /*0x142fb4f4f*/
            }
            __unwind
            {
              RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v93); /*0xf1c0000000000054*/
            }
            __wind /*0xf1c000000000005c*/
            {
              RBX::Memory::setCurrentCategory(category: parent); /*0x142fb4f58*/
            }
            __unwind
            {
              __std_terminate(a1: v60, a2: v63); /*0xf1c000000000003c*/
            }
          }
          __unwind
          {
            if ( (v92 & 0x100) != 0 ) /*0x1432c99d6*/
              rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v82); /*0x1432c99e9*/
          }
          if ( v58 != nullptr && _InterlockedExchangeAdd(&v58->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x142fb4f6e*/
            operator delete(ptr: v58); /*0x142fb4f73*/
        }
        if ( player._Rep != nullptr ) /*0x142fb4f84*/
          std::_Ref_count_base::_Decref(this: player._Rep); /*0x142fb4f86*/
        RBX::UserInfo::~UserInfo(this: &userInfo); /*0x142fb4f94*/
        if ( dataModel._Rep != nullptr ) /*0x142fb4fa2*/
          std::_Ref_count_base::_Decref(this: dataModel._Rep); /*0x142fb4fa4*/
        if ( placeSessionModel.wp.d != nullptr ) /*0x142fb4fb2*/
        {
          if ( _InterlockedExchangeAdd(&placeSessionModel.wp.d->weakref._q_value._Storage._Value, 0xFFFFFFFF) != 1 ) /*0x142fb4fc0*/
            goto LABEL_149; /*0x142fb4fc0*/
          if ( placeSessionModel.wp.d == nullptr ) /*0x142fb4fca*/
            goto LABEL_149; /*0x142fb4fca*/
          operator delete(ptr: placeSessionModel.wp.d); /*0x142fb4fcc*/
        }
LABEL_149:
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v2); /*0x142fb5038*/
        if ( __eh34_unwind(11) ) /*0xf1c00000000001ec*/
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&player); /*0xf1c00000000001f0*/
          __eh34_continue_unwinding(11, 4); /*0xf1c00000000001f4*/
        }
        __eh34_exit_wind_state(11, 4); /*0xf1c00000000001f8*/
        if ( __eh34_unwind(4) ) /*0xf1c00000000001fc*/
        {
          RBX::UserInfo::~UserInfo(this: &userInfo); /*0xf1c0000000000200*/
          __eh34_continue_unwinding(4, 3); /*0xf1c0000000000204*/
        }
        __eh34_exit_wind_state(4, 3); /*0xf1c0000000000208*/
        if ( __eh34_unwind(3) ) /*0xf1c00000000001c0*/
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&dataModel); /*0xf1c00000000001c4*/
          __eh34_continue_unwinding(3, 2); /*0xf1c00000000001c8*/
        }
LABEL_216:
        __eh34_exit_wind_state(3, 2); /*0xf1c00000000001cc*/
        goto LABEL_213; /*0xf1c00000000001d0*/
      }
      d = placeSessionModel.wp.d; /*0x142fb4fd4*/
    }
    if ( d != nullptr /*0x142fb4ff5*/
      && _InterlockedAdd(&d->weakref._q_value._Storage._Value, 0xFFFFFFFF) == 0
      && placeSessionModel.wp.d != nullptr )
    {
      operator delete(ptr: placeSessionModel.wp.d); /*0x142fb4ff7*/
    }
    v61 = (volatile signed __int32 *)v2->_Rep; /*0x142fb4ffd*/
    if ( v61 != nullptr && _InterlockedExchangeAdd(v61 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb5011*/
    {
      (**(void (__fastcall ***)(volatile signed __int32 *))v61)(a1: v61); /*0x142fb5019*/
      if ( _InterlockedExchangeAdd(v61 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb5023*/
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v61 + 8LL))(a1: v61); /*0x142fb502b*/
    }
    goto LABEL_204; /*0x142fb502b*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: config); /*0xf1c0000000000194*/
  }
}

// Address: 0x142fb5070 | Name: ?onPlayerReceivedFromServerInCloudEdit@CloudEditConnectionModel@@AEAAXV?$shared_ptr@VPlayer@RBX@@@std@@@Z
void __fastcall CloudEditConnectionModel::onPlayerReceivedFromServerInCloudEdit(
        CloudEditConnectionModel *this,
        std::shared_ptr<RBX::File> *player)
{
  std::shared_ptr<RBX::File> *v2; // r15
  StudioTimingStatistics *Instance; // rbx
  QtSharedPointer::ExternalRefCountData *d; // rcx
  IPlaceSessionModel *value; // rcx
  RBX::DataModel *OriginalDataModel; // rax
  RBX::DataModel *v7; // r8
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v10; // ett
  RBX::Reflection::DescribedBase *Ptr; // rcx
  char *v12; // rdx
  char v13; // si
  RBX::DataModel *p_Rep; // r14
  char v15; // si
  volatile signed __int32 *v16; // rbx
  volatile signed __int32 *v17; // rbx
  std::_Ref_count_base *v18; // rbx
  RBX::RunService *v19; // rax
  rbx::signals::signal_base *p_heartbeatSignal; // r12
  unsigned int v21; // eax
  unsigned int parent; // ebx
  char *v23; // rax
  rbx::signals::slot_base *v24; // r14
  __int64 v25; // rcx
  std::_Ref_count_base *v26; // rbx
  volatile signed __int32 *v27; // rbx
  const char *v28; // rax
  __int64 v29; // [rsp+0h] [rbp-C8h] BYREF
  QPointer<IPlaceSessionModel> placeSessionModel; // [rsp+20h] [rbp-A8h] BYREF
  std::shared_ptr<RBX::DataModel> dataModel; // [rsp+30h] [rbp-98h] BYREF
  char v32; // [rsp+48h] [rbp-80h] BYREF
  volatile signed __int32 *v33; // [rsp+50h] [rbp-78h]
  char v34; // [rsp+58h] [rbp-70h] BYREF
  volatile signed __int32 *v35; // [rsp+60h] [rbp-68h]
  rbx::signals::slot_base *v36; // [rsp+68h] [rbp-60h] BYREF
  const std::exception *e; // [rsp+70h] [rbp-58h] BYREF
  __int128 v38; // [rsp+78h] [rbp-50h]
  char v40; // [rsp+E0h] [rbp+18h]
  char v41; // [rsp+E0h] [rbp+18h]
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v42; // [rsp+E8h] [rbp+20h] BYREF

  __wind
  {
    v2 = player; /*0x142fb5087*/
    Instance = StudioTimingStatistics::getInstance(); /*0x142fb509a*/
    Instance->teamPlayerConnectTime.stopTime = RBX::Time::nowFastSec(); /*0x142fb50a2*/
    __eh34_enter_try_state(0, 1); /*0xf1c000000000008c*/
    MDIManagerHost::getFocusedPlaceSessionModel( /*0x142fb50b3*/
      this: SingletonTemplate<MDIManagerHost>::m_instance._Ptr,
      result: &placeSessionModel);
    __eh34_enter_wind_state(1, 2); /*0xf1c0000000000084*/
    d = placeSessionModel.wp.d; /*0x142fb50b9*/
    if ( placeSessionModel.wp.d != nullptr )
    {
      if ( placeSessionModel.wp.d->strongref._q_value._Storage._Value != 0 && placeSessionModel.wp.value != nullptr )
      {
        value = nullptr; /*0x142fb50e0*/
        if ( placeSessionModel.wp.d->strongref._q_value._Storage._Value != 0 ) /*0x142fb50e5*/
          value = (IPlaceSessionModel *)placeSessionModel.wp.value; /*0x142fb50e5*/
        OriginalDataModel = IPlaceSessionModel::getOriginalDataModel(this: value); /*0x142fb50eb*/
        v7 = OriginalDataModel; /*0x142fb50f0*/
        if ( OriginalDataModel != nullptr )
        {
          Rep = OriginalDataModel->_Wptr._Rep; /*0x142fb50f8*/
          if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x142fb510a*/
LABEL_70:
            std::_Throw_bad_weak_ptr(); /*0x142fb5459*/
          while ( 1 )
          {
            v10 = Uses; /*0x142fb5113*/
            Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x142fb5113*/
            if ( v10 == Uses ) /*0x142fb5118*/
              break; /*0x142fb5118*/
            if ( Uses == 0 ) /*0x142fb511c*/
              goto LABEL_70; /*0x142fb511c*/
            if ( __eh34_unwind(2) ) /*0xf1c00000000000ac*/
            {
unwind_state_2:
              QPointer<MassUpdateWindow>::~QPointer<MassUpdateWindow>(this: (QPointer<FindReplaceLockedScriptsDialog> *)&placeSessionModel); /*0xf1c00000000000b0*/
              __eh34_continue_unwinding(2, 1); /*0xf1c00000000000b4*/
            }
            __eh34_exit_wind_state(2, 1); /*0xf1c00000000000b8*/
            if ( __eh34_catch(1) )
            {
catch_state_1:
              if ( __eh34_catch_type(1, &std::exception `RTTI Type Descriptor', &e) )
              {
                v28 = e->what(this: e); /*0x1432c9a84*/
                RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "Error while setting up local player: %s", v28);
                v2 = player; /*0x142fb5436*/
                __eh34_enter_try_state(0, 1); /*0xf1c00000000000f8*/
                __eh34_enter_wind_state(1, 2); /*0xf1c00000000000fc*/
                __eh34_enter_wind_state(2, 3); /*0xf1c0000000000100*/
                goto LABEL_69; /*0xf1c000000000001c*/
              }
LABEL_97:
              __eh34_exit_try_state(1, 0); /*0xf1c00000000000cc*/
              return; /*0xf1c00000000000d0*/
            }
            __eh34_exit_try_state(1, 0); /*0xf1c00000000000d4*/
            __eh34_enter_try_state(0, 1); /*0xf1c00000000000dc*/
            __eh34_enter_wind_state(1, 2); /*0xf1c00000000000e0*/
          }
          Ptr = v7->_Wptr._Ptr; /*0x142fb5124*/
          v35 = (volatile signed __int32 *)v7->_Wptr._Rep; /*0x142fb512c*/
          v12 = &v34; /*0x142fb5131*/
          v13 = 19; /*0x142fb5136*/
          p_Rep = (RBX::DataModel *)&Ptr[-1]._Wptr._Rep; /*0x142fb513b*/
          if ( Ptr == nullptr ) /*0x142fb5142*/
            p_Rep = nullptr; /*0x142fb5142*/
        }
        else
        {
          v33 = nullptr; /*0x142fb5148*/
          v12 = &v32; /*0x142fb514d*/
          v13 = 4; /*0x142fb5152*/
          p_Rep = nullptr; /*0x142fb5157*/
        }
        dataModel._Ptr = p_Rep; /*0x142fb515a*/
        dataModel._Rep = *((std::_Ref_count_base **)v12 + 1); /*0x142fb5163*/
        *(_QWORD *)v12 = 0; /*0x142fb5168*/
        *((_QWORD *)v12 + 1) = 0; /*0x142fb516b*/
        v15 = v13 | 8; /*0x142fb516f*/
        v40 = v15; /*0x142fb5172*/
        if ( (v15 & 4) != 0 ) /*0x142fb517d*/
        {
          v15 &= ~4u; /*0x142fb517f*/
          v40 = v15; /*0x142fb5182*/
          if ( v33 != nullptr && _InterlockedExchangeAdd(v33 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb51a2*/
          {
            v16 = v33; /*0x142fb51a4*/
            (**(void (__fastcall ***)(volatile signed __int32 *))v33)(a1: v33); /*0x142fb51af*/
            if ( _InterlockedExchangeAdd(v16 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb51bb*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v33 + 8LL))(a1: v33); /*0x142fb51c5*/
          }
        }
        if ( (v15 & 2) != 0 ) /*0x142fb51da*/
        {
          v15 &= ~2u; /*0x142fb51dc*/
          v40 = v15; /*0x142fb51df*/
          if ( v35 != nullptr && _InterlockedExchangeAdd(v35 + 2, 0xFFFFFFFF) == 1 ) /*0x142fb51fa*/
          {
            v17 = v35; /*0x142fb51fc*/
            (**(void (__fastcall ***)(volatile signed __int32 *))v35)(a1: v35); /*0x142fb5207*/
            if ( _InterlockedExchangeAdd(v17 + 3, 0xFFFFFFFF) == 1 ) /*0x142fb5213*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v35 + 8LL))(a1: v35); /*0x142fb521d*/
          }
        }
        if ( (v15 & 1) != 0 ) /*0x142fb522b*/
        {
          v15 &= ~1u; /*0x142fb522d*/
          v40 = v15; /*0x142fb5230*/
        }
        if ( p_Rep == nullptr ) /*0x142fb523a*/
        {
          if ( dataModel._Rep != nullptr /*0x142fb5250*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&dataModel._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v18 = dataModel._Rep; /*0x142fb5252*/
            dataModel._Rep->_Destroy(this: dataModel._Rep); /*0x142fb525d*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v18->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb5269*/
              dataModel._Rep->_Delete_this(this: dataModel._Rep); /*0x142fb5273*/
          }
          if ( placeSessionModel.wp.d != nullptr /*0x142fb5292*/
            && _InterlockedExchangeAdd(&placeSessionModel.wp.d->weakref._q_value._Storage._Value, 0xFFFFFFFF) == 1
            && placeSessionModel.wp.d != nullptr )
          {
            operator delete(ptr: placeSessionModel.wp.d); /*0x142fb5294*/
          }
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v2); /*0x142fb529d*/
          goto LABEL_99; /*0x142fb52a2*/
        }
        __eh34_enter_wind_state(2, 3); /*0xf1c000000000007c*/
        v19 = RBX::ServiceProvider::create<RBX::RunService>(this: &p_Rep->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x142fb52ab*/
        if ( v19 != nullptr ) /*0x142fb52b3*/
        {
          __wind /*0xf1c0000000000070*/
          {
            p_heartbeatSignal = &v19->heartbeatSignal; /*0x142fb52b9*/
            *((_QWORD *)&v38 + 1) = p_Rep; /*0x142fb52c0*/
            v21 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x142fb52ce*/
            __wind /*0xf1c0000000000034*/
            {
              parent = v21; /*0x142fb52d3*/
              v42.parent = v21; /*0x142fb52d5*/
              v23 = (char *)operator new(size: 0x38u); /*0x142fb52e1*/
              v24 = (rbx::signals::slot_base *)v23; /*0x142fb52e6*/
              if ( v23 != nullptr ) /*0x142fb52ec*/
              {
                *(_DWORD *)v23 = 0; /*0x142fb52ee*/
                *((_DWORD *)v23 + 1) = 1; /*0x142fb52f1*/
                *((_QWORD *)v23 + 1) = rbx::signals::slot_with_functor_boost::_bi::bind_t_void__lambda_8d23873b4135370dc0983445c90d14c1__boost::_bi::list1_boost::_bi::value_RBX::DataModel________RBX::Heartbeat_const___::do_call; /*0x142fb52ff*/
                *((_QWORD *)v23 + 2) = RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x142fb530a*/
                *((_QWORD *)v23 + 3) = 0; /*0x142fb530e*/
                *((_QWORD *)v23 + 4) = p_heartbeatSignal; /*0x142fb5312*/
                *(_OWORD *)(v23 + 40) = v38; /*0x142fb531b*/
              }
              else
              {
                v24 = nullptr; /*0x142fb5322*/
              }
              rbx::signals::signal_base::insert(this: p_heartbeatSignal, item: v24); /*0x142fb532b*/
              v36 = v24; /*0x142fb5330*/
              if ( v24 != nullptr ) /*0x142fb5338*/
              {
                _InterlockedIncrement(&v24->weak._Storage._Value); /*0x142fb533a*/
                v15 = v40; /*0x142fb533f*/
                parent = v42.parent; /*0x142fb5346*/
              }
              v41 = v15 | 0x20; /*0x142fb5350*/
            }
            __unwind
            {
              RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v42); /*0xf1c0000000000044*/
            }
            __wind /*0xf1c000000000004c*/
            {
              RBX::Memory::setCurrentCategory(category: parent); /*0x142fb5359*/
            }
            __unwind
            {
              __std_terminate(a1: v25, a2: &v29); /*0x142f39fa8*/
            }
          }
          __unwind
          {
            if ( (v41 & 0x20) != 0 ) /*0x1432c9a54*/
              rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v36); /*0x1432c9a61*/
          }
          if ( v24 != nullptr && _InterlockedExchangeAdd(&v24->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x142fb536f*/
            operator delete(ptr: v24); /*0x142fb5374*/
        }
        if ( dataModel._Rep != nullptr /*0x142fb538e*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&dataModel._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v26 = dataModel._Rep; /*0x142fb5390*/
          dataModel._Rep->_Destroy(this: dataModel._Rep); /*0x142fb539b*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v26->_Weaks, 0xFFFFFFFF) == 1 ) /*0x142fb53a7*/
            dataModel._Rep->_Delete_this(this: dataModel._Rep); /*0x142fb53b1*/
        }
        if ( placeSessionModel.wp.d != nullptr ) /*0x142fb53bd*/
        {
          if ( _InterlockedExchangeAdd(&placeSessionModel.wp.d->weakref._q_value._Storage._Value, 0xFFFFFFFF) != 1 ) /*0x142fb53c6*/
            goto LABEL_69; /*0x142fb53c6*/
          if ( placeSessionModel.wp.d == nullptr ) /*0x142fb53d0*/
            goto LABEL_69; /*0x142fb53d0*/
          operator delete(ptr: placeSessionModel.wp.d); /*0x142fb53d2*/
        }
LABEL_69:
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v2); /*0x142fb543e*/
        if ( __eh34_unwind(3) ) /*0xf1c0000000000108*/
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&dataModel); /*0xf1c000000000010c*/
          __eh34_continue_unwinding(3, 2); /*0xf1c0000000000110*/
        }
        __eh34_exit_wind_state(3, 2); /*0xf1c0000000000114*/
        if ( __eh34_unwind(2) ) /*0xf1c00000000000e8*/
          goto unwind_state_2; /*0xf1c00000000000e8*/
LABEL_99:
        __eh34_exit_wind_state(2, 1); /*0xf1c00000000000ec*/
        if ( __eh34_catch(1) ) /*0xf1c00000000000f0*/
          goto catch_state_1; /*0xf1c00000000000f0*/
        goto LABEL_97; /*0xf1c00000000000f0*/
      }
      d = placeSessionModel.wp.d; /*0x142fb53da*/
    }
    if ( d != nullptr /*0x142fb53fc*/
      && _InterlockedExchangeAdd(&d->weakref._q_value._Storage._Value, 0xFFFFFFFF) == 1
      && placeSessionModel.wp.d != nullptr )
    {
      operator delete(ptr: placeSessionModel.wp.d); /*0x142fb53fe*/
    }
    v27 = (volatile signed __int32 *)v2->_Rep; /*0x142fb5404*/
    if ( v27 == nullptr ) /*0x142fb540b*/
      goto LABEL_99; /*0x142fb540b*/
    if ( _InterlockedExchangeAdd(v27 + 2, 0xFFFFFFFF) != 1 ) /*0x142fb5417*/
      goto LABEL_99; /*0x142fb5417*/
    (**(void (__fastcall ***)(volatile signed __int32 *))v27)(a1: v27); /*0x142fb541f*/
    if ( _InterlockedExchangeAdd(v27 + 3, 0xFFFFFFFF) != 1 ) /*0x142fb5429*/
      goto LABEL_99; /*0x142fb5429*/
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 8LL))(a1: v27); /*0x142fb5431*/
    goto LABEL_99; /*0x142fb5431*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: player); /*0xf1c00000000000a4*/
  }
}

// Address: 0x142fb54e0 | Name: ?setInvisibleDMOnFailedSignalCallBack@CloudEditConnectionModel@@QEAAXV?$function@$$A6AXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@H0@Z@std@@@Z
void __fastcall CloudEditConnectionModel::setInvisibleDMOnFailedSignalCallBack(
        CloudEditConnectionModel *this,
        std::function<void __cdecl(std::string,int,std::string)> *onFailedSignalCallBack)
{
  std::function<void __cdecl(std::string,int,std::string)> *p_m_onFailedSignalCallBack; // rdi
  std::function<void __cdecl(std::string,int,std::string)> *v3; // rbx
  std::_Func_base<void,std::string,int,std::string > *v4; // rcx
  std::_Func_base<void,std::string,int,std::string > *v5; // rcx
  std::function<void __cdecl(std::string,int,std::string)> *v6; // rcx
  std::function<void __cdecl(std::string,int,std::string)> *v7; // rcx

  p_m_onFailedSignalCallBack = &this->m_onFailedSignalCallBack; /*0x142fb54ef*/
  v3 = onFailedSignalCallBack; /*0x142fb54f8*/
  if ( &this->m_onFailedSignalCallBack != onFailedSignalCallBack ) /*0x142fb54fe*/
  {
    v4 = this->m_onFailedSignalCallBack._Mystorage._Ptrs[7]; /*0x142fb5500*/
    if ( v4 != nullptr ) /*0x142fb5507*/
    {
      LOBYTE(onFailedSignalCallBack) = v4 != (std::_Func_base<void,std::string,int,std::string > *)p_m_onFailedSignalCallBack; /*0x142fb550f*/
      v4->_Delete_this(this: v4, a2: (bool)onFailedSignalCallBack); /*0x142fb5512*/
      p_m_onFailedSignalCallBack->_Mystorage._Ptrs[7] = nullptr; /*0x142fb5515*/
    }
    v5 = v3->_Mystorage._Ptrs[7]; /*0x142fb5519*/
    if ( v5 != nullptr ) /*0x142fb5520*/
    {
      if ( v5 == (std::_Func_base<void,std::string,int,std::string > *)v3 ) /*0x142fb5525*/
      {
        p_m_onFailedSignalCallBack->_Mystorage._Ptrs[7] = v5->_Move(this: v5, a2: p_m_onFailedSignalCallBack); /*0x142fb5530*/
        v6 = (std::function<void __cdecl(std::string,int,std::string)> *)v3->_Mystorage._Ptrs[7]; /*0x142fb5534*/
        if ( v6 == nullptr ) /*0x142fb553b*/
          goto LABEL_10; /*0x142fb553b*/
        LOBYTE(onFailedSignalCallBack) = v6 != v3; /*0x142fb5543*/
        ((void (__fastcall *)(std::function<void __cdecl(std::string,int,std::string)> *, std::function<void __cdecl(std::string,int,std::string)> *))v6->_Mystorage._Ptrs[0][4].__vftable)( /*0x142fb5546*/
          a1: v6,
          a2: onFailedSignalCallBack);
      }
      else
      {
        p_m_onFailedSignalCallBack->_Mystorage._Ptrs[7] = v5; /*0x142fb554b*/
      }
      v3->_Mystorage._Ptrs[7] = nullptr; /*0x142fb554f*/
    }
  }
LABEL_10:
  v7 = (std::function<void __cdecl(std::string,int,std::string)> *)v3->_Mystorage._Ptrs[7]; /*0x142fb5553*/
  if ( v7 != nullptr ) /*0x142fb555a*/
  {
    LOBYTE(onFailedSignalCallBack) = v7 != v3; /*0x142fb5562*/
    ((void (__fastcall *)(std::function<void __cdecl(std::string,int,std::string)> *, std::function<void __cdecl(std::string,int,std::string)> *))v7->_Mystorage._Ptrs[0][4].__vftable)( /*0x142fb5565*/
      a1: v7,
      a2: onFailedSignalCallBack);
    v3->_Mystorage._Ptrs[7] = nullptr; /*0x142fb5568*/
  }
}

// Address: 0x143147610 | Name: ?metaObject@CloudEditConnectionModel@@UEBAPEBUQMetaObject@@XZ
const QMetaObject *__fastcall CloudEditConnectionModel::metaObject(CloudEditConnectionModel *this)
{
  QObjectData *d; // rcx

  d = this->d_ptr.d; /*0x143147610*/
  if ( d->metaObject != nullptr ) /*0x143147619*/
    return QObjectData::dynamicMetaObject(this: d); /*0x14314761b*/
  else
    return &CloudEditConnectionModel::staticMetaObject; /*0x143147622*/
}

// Address: 0x143147630 | Name: ?qt_metacall@CloudEditConnectionModel@@UEAAHW4Call@QMetaObject@@HPEAPEAX@Z
// attributes: thunk
int __fastcall CloudEditConnectionModel::qt_metacall(
        CloudEditConnectionModel *this,
        QMetaObject::Call _c,
        int _id,
        void **_a)
{
  return ICloudEditConnectionModel::qt_metacall(this, _c, _id, _a);
}

// Address: 0x143147640 | Name: ?qt_metacast@CloudEditConnectionModel@@UEAAPEAXPEBD@Z
CloudEditConnectionModel *__fastcall CloudEditConnectionModel::qt_metacast(
        CloudEditConnectionModel *this,
        const char *_clname)
{
  if ( _clname == nullptr ) /*0x143147649*/
    return nullptr; /*0x14314764b*/
  if ( strcmp(_clname, qt_meta_stringdata_CloudEditConnectionModel.stringdata0) == 0 ) /*0x143147675*/
    return this; /*0x143147677*/
  return (CloudEditConnectionModel *)ICloudEditConnectionModel::qt_metacast(this, _clname); /*0x14314764d*/
}

// END CloudEditConnectionModel part 1/1, 21 functions
