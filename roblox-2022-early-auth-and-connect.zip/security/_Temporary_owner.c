// _Temporary_owner -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x14100fb10 | Name: ??1?$_Temporary_owner@UEarlyAuthData@Security@RBX@@@std@@QEAA@XZ
void __fastcall std::_Temporary_owner<RBX::Security::EarlyAuthData>::~_Temporary_owner<RBX::Security::EarlyAuthData>(
        std::_Temporary_owner<RBX::Security::EarlyAuthData> *this)
{
  RBX::Security::EarlyAuthData *Ptr; // rcx

  Ptr = this->_Ptr; /*0x14100fb10*/
  if ( Ptr != nullptr ) /*0x14100fb16*/
    RBX::Security::EarlyAuthData::`scalar deleting destructor'(this: Ptr, a2: 1); /*0x14100fb1d*/
}

// END _Temporary_owner part 1/1, 1 functions
