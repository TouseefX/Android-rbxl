// Security -- 2022 Studio + full PDB
// tier 3, 10 functions


// Address: 0x1401b7110 | Name: RBX::Security::_dynamic_initializer_for__kRakNetEarlyPublicKeyName__
int RBX::Security::_dynamic_initializer_for__kRakNetEarlyPublicKeyName__()
{
  char *v0; // rax

  v0 = (char *)operator new(size: 0x20u); /*0x1401b7119*/
  RBX::Security::kRakNetEarlyPublicKeyName._Mypair._Myval2._Mysize = 20; /*0x1401b7125*/
  RBX::Security::kRakNetEarlyPublicKeyName._Mypair._Myval2._Myres = 31; /*0x1401b7130*/
  strcpy(v0, "RakNetEarlyPublicKey"); /*0x1401b713b*/
  RBX::Security::kRakNetEarlyPublicKeyName._Mypair._Myval2._Bx._Ptr = v0; /*0x1401b7152*/
  return atexit(function: (void (__fastcall *)())RBX::Security::_dynamic_atexit_destructor_for__kRakNetEarlyPublicKeyName__); /*0x1401b7159*/
}

// Address: 0x1401b7170 | Name: RBX::Security::_dynamic_initializer_for__kRakNetEarlySecretKeyName__
int RBX::Security::_dynamic_initializer_for__kRakNetEarlySecretKeyName__()
{
  char *v0; // rax

  v0 = (char *)operator new(size: 0x20u); /*0x1401b7179*/
  RBX::Security::kRakNetEarlySecretKeyName._Mypair._Myval2._Mysize = 20; /*0x1401b7185*/
  RBX::Security::kRakNetEarlySecretKeyName._Mypair._Myval2._Myres = 31; /*0x1401b7190*/
  strcpy(v0, "RakNetEarlySecretKey"); /*0x1401b719b*/
  RBX::Security::kRakNetEarlySecretKeyName._Mypair._Myval2._Bx._Ptr = v0; /*0x1401b71b2*/
  return atexit(function: (void (__fastcall *)())RBX::Security::_dynamic_atexit_destructor_for__kRakNetEarlySecretKeyName__); /*0x1401b71b9*/
}

// Address: 0x14035fe40 | Name: RBX::Security::_dynamic_initializer_for__hackFlagVp__
int RBX::Security::_dynamic_initializer_for__hackFlagVp__()
{
  unsigned __int64 v0; // rdx
  unsigned __int64 v1; // r8

  v0 = (unsigned __int64)operator new(size: 4u); /*0x14035fe4e*/
  if ( v0 != 0 ) /*0x14035fe54*/
  {
    *(_DWORD *)v0 = 0; /*0x14035fe5b*/
    v1 = HIDWORD(v0); /*0x14035fe5d*/
  }
  else
  {
    LODWORD(v0) = 0; /*0x14035fe63*/
    LODWORD(v1) = 0; /*0x14035fe65*/
  }
  RBX::Security::hackFlagVp.ptr.storage.asRaw[1] = v1 ^ (unsigned int)&RBX::Security::hackFlagVp; /*0x14035fe76*/
  RBX::Security::hackFlagVp.ptr.storage.asRaw[0] = v0 ^ (unsigned int)&RBX::Security::hackFlagVp; /*0x14035fe83*/
  RBX::Security::hackFlagVp.savedPtr.storage.asRaw[0] = (unsigned int)&RBX::Security::hackFlagVp.savedPtr + v0; /*0x14035fe8c*/
  RBX::Security::hackFlagVp.savedPtr.storage.asRaw[1] = (unsigned int)&RBX::Security::hackFlagVp.savedPtr + v1; /*0x14035fe9d*/
  return atexit(function: (void (__fastcall *)())RBX::Security::_dynamic_atexit_destructor_for__hackFlagVp__); /*0x14035fea3*/
}

// Address: 0x1403b2b90 | Name: RBX::Security::_dynamic_initializer_for__gContext__
__int64 RBX::Security::_dynamic_initializer_for__gContext__()
{
  __int64 result; // rax
  __int128 v1; // [rsp+0h] [rbp-28h]

  *((_QWORD *)&v1 + 1) = 0; /*0x1403b2ba6*/
  LODWORD(v1) = 0; /*0x1403b2bb1*/
  result = *((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index); /*0x1403b2bb8*/
  *(_OWORD *)(result + 120) = v1; /*0x1403b2bc4*/
  *(long double *)(result + 136) = _mm_unpackhi_pd((__m128d)0LL, (__m128d)0LL).m128d_f64[0]; /*0x1403b2bc8*/
  return result; /*0x1403b2bce*/
}

// Address: 0x14100ba50 | Name: ?encodeVersionKey@Security@RBX@@YA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@AEBV34@E@Z
std::string *__fastcall RBX::Security::encodeVersionKey(
        std::string *result,
        const std::string *legacyKey,
        char ticketVersion)
{
  unsigned __int64 v6; // rbx
  int v7; // edx
  unsigned __int64 Mysize; // r8
  const std::string *v9; // rdx
  __int64 v10; // rdi
  __int64 v11; // rax
  __int64 v12; // rdi
  __int64 v13; // rax
  __int64 v14; // rdi
  __int64 v15; // rax
  __int64 v16; // rdi
  __int64 v17; // rax
  __int64 v18; // rdi
  __int64 v19; // rax
  __int64 v20; // rdi
  __int64 v21; // rax
  __int64 v22; // rdi
  __int64 v23; // rax
  __int64 v24; // rdi
  __int64 v25; // rax
  __int64 v26; // rdi
  __int64 v27; // rax
  int v29; // [rsp+2Ch] [rbp-D4h]
  std::basic_stringstream<char,std::char_traits<char>,std::allocator<char> > key; // [rsp+30h] [rbp-D0h] BYREF
  _BYTE v31[16]; // [rsp+130h] [rbp+30h] BYREF
  _BYTE v32[16]; // [rsp+140h] [rbp+40h] BYREF
  _BYTE v33[16]; // [rsp+150h] [rbp+50h] BYREF
  _BYTE v34[16]; // [rsp+160h] [rbp+60h] BYREF
  _BYTE v35[16]; // [rsp+170h] [rbp+70h] BYREF

  v6 = 0; /*0x14100ba7a*/
  *(_QWORD *)key.gap0 = &std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vftable'[1]; /*0x14100ba87*/
  *(_QWORD *)key.gap10 = &std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vbtable'{for `std::ostream'}; /*0x14100ba93*/
  std::ios::ios(a1: &key.gap90[8]); /*0x14100ba9c*/
  __wind /*0xf1c0000000000058*/
  {
    std::iostream::iostream(a1: &key, a2: &key.gap10[8], a3: 0); /*0x14100bab8*/
    *(_QWORD *)&key.gap0[*(int *)(*(_QWORD *)key.gap0 + 4LL)] = std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vftable'; /*0x14100bacf*/
    v7 = *(_DWORD *)(*(_QWORD *)key.gap0 + 4LL) - 152; /*0x14100badd*/
    *(int *)((char *)&v29 + *(int *)(*(_QWORD *)key.gap0 + 4LL)) = v7; /*0x14100bae3*/
    __wind /*0xf1c0000000000028*/
    {
      std::streambuf::streambuf(a1: &key.gap10[8]); /*0x14100baec*/
      *(_QWORD *)&key.gap10[8] = std::stringbuf::`vftable'; /*0x14100baf9*/
      *(_QWORD *)key._Stringbuffer = 0; /*0x14100bafe*/
      *(_DWORD *)&key._Stringbuffer[8] = 0; /*0x14100bb02*/
      Mysize = legacyKey->_Mypair._Myval2._Mysize; /*0x14100bb05*/
      if ( legacyKey->_Mypair._Myval2._Myres >= 0x10 ) /*0x14100bb0e*/
        legacyKey = (const std::string *)legacyKey->_Mypair._Myval2._Bx._Ptr; /*0x14100bb10*/
      v9 = legacyKey; /*0x14100bb13*/
    }
    __unwind
    {
      std::iostream::~iostream<char,std::char_traits<char>>(a1: &key.gap10[16]); /*0x143188aab*/
    }
  }
  __unwind
  {
    std::ios::~ios<char,std::char_traits<char>>(a1: &key.gap90[8]); /*0x143188a92*/
  }
  __wind /*0xf1c000000000004c*/
  {
    std::_Insert_string<char,std::char_traits<char>,unsigned __int64>( /*0x14100bb1b*/
      _Ostr: (std::ostream *)key.gap10,
      _Data: v9->_Mypair._Myval2._Bx._Buf,
      _Size: Mysize);
    if ( DFFlag::UseNewVersionFormat.value ) /*0x14100bb2c*/
    {
      std::operator<<<std::char_traits<char>>(_Ostr: (std::ostream *)key.gap10, _Val: "`"); /*0x14100bb39*/
      do /*0x14100bd05*/
      {
        v10 = std::ostream::operator<<(a1: key.gap10, a2: std::hex); /*0x14100bb52*/
        v11 = std::setw(a1: v35, a2: 2); /*0x14100bb5e*/
        (*(void (__fastcall **)(__int64, _QWORD))v11)( /*0x14100bb74*/
          a1: v10 + *(int *)(*(_QWORD *)v10 + 4LL),
          a2: *(_QWORD *)(v11 + 8));
        *(_BYTE *)(*(int *)(*(_QWORD *)v10 + 4LL) + v10 + 88) = 48; /*0x14100bb7e*/
        std::ostream::operator<<(a1: v10, a2: (unsigned __int8)(0x1096C3ECu >> v6)); /*0x14100bb93*/
        v12 = std::ostream::operator<<(a1: key.gap10, a2: std::hex); /*0x14100bbab*/
        v13 = std::setw(a1: v31, a2: 2); /*0x14100bbb7*/
        (*(void (__fastcall **)(__int64, _QWORD))v13)( /*0x14100bbcd*/
          a1: v12 + *(int *)(*(_QWORD *)v12 + 4LL),
          a2: *(_QWORD *)(v13 + 8));
        *(_BYTE *)(*(int *)(*(_QWORD *)v12 + 4LL) + v12 + 88) = 48; /*0x14100bbd7*/
        std::ostream::operator<<(a1: v12, a2: (unsigned __int8)(0x7317D97Bu >> v6)); /*0x14100bbec*/
        v14 = std::ostream::operator<<(a1: key.gap10, a2: std::hex); /*0x14100bc04*/
        v15 = std::setw(a1: v32, a2: 2); /*0x14100bc10*/
        (*(void (__fastcall **)(__int64, _QWORD))v15)( /*0x14100bc26*/
          a1: v14 + *(int *)(*(_QWORD *)v14 + 4LL),
          a2: *(_QWORD *)(v15 + 8));
        *(_BYTE *)(*(int *)(*(_QWORD *)v14 + 4LL) + v14 + 88) = 48; /*0x14100bc30*/
        std::ostream::operator<<(a1: v14, a2: (unsigned __int8)(0x31B5933Bu >> v6)); /*0x14100bc45*/
        v16 = std::ostream::operator<<(a1: key.gap10, a2: std::hex); /*0x14100bc5d*/
        v17 = std::setw(a1: v33, a2: 2); /*0x14100bc69*/
        (*(void (__fastcall **)(__int64, _QWORD))v17)( /*0x14100bc7f*/
          a1: v16 + *(int *)(*(_QWORD *)v16 + 4LL),
          a2: *(_QWORD *)(v17 + 8));
        *(_BYTE *)(*(int *)(*(_QWORD *)v16 + 4LL) + v16 + 88) = 48; /*0x14100bc89*/
        std::ostream::operator<<(a1: v16, a2: (unsigned __int8)(0xA1588F71 >> v6)); /*0x14100bc9e*/
        v18 = std::ostream::operator<<(a1: key.gap10, a2: std::hex); /*0x14100bcb6*/
        v19 = std::setw(a1: v34, a2: 2); /*0x14100bcc2*/
        (*(void (__fastcall **)(__int64, _QWORD))v19)( /*0x14100bcd8*/
          a1: v18 + *(int *)(*(_QWORD *)v18 + 4LL),
          a2: *(_QWORD *)(v19 + 8));
        *(_BYTE *)(*(int *)(*(_QWORD *)v18 + 4LL) + v18 + 88) = 48; /*0x14100bce2*/
        std::ostream::operator<<(a1: v18, a2: (unsigned __int8)(0x34D2665Fu >> v6)); /*0x14100bcf7*/
        v6 += 8LL; /*0x14100bcfd*/
      }
      while ( v6 < 0x20 ); /*0x14100bd05*/
    }
    else
    {
      std::operator<<<std::char_traits<char>>(_Ostr: (std::ostream *)key.gap10, _Val: "!"); /*0x14100bd17*/
      do /*0x14100be8c*/
      {
        v20 = std::ostream::operator<<(a1: key.gap10, a2: std::hex); /*0x14100bd32*/
        v21 = std::setw(a1: v34, a2: 2); /*0x14100bd3e*/
        (*(void (__fastcall **)(__int64, _QWORD))v21)( /*0x14100bd54*/
          a1: v20 + *(int *)(*(_QWORD *)v20 + 4LL),
          a2: *(_QWORD *)(v21 + 8));
        *(_BYTE *)(*(int *)(*(_QWORD *)v20 + 4LL) + v20 + 88) = 48; /*0x14100bd5e*/
        std::ostream::operator<<(a1: v20, a2: (unsigned __int8)(0x1096C3ECu >> v6)); /*0x14100bd73*/
        v22 = std::ostream::operator<<(a1: key.gap10, a2: std::hex); /*0x14100bd8b*/
        v23 = std::setw(a1: v33, a2: 2); /*0x14100bd97*/
        (*(void (__fastcall **)(__int64, _QWORD))v23)( /*0x14100bdad*/
          a1: v22 + *(int *)(*(_QWORD *)v22 + 4LL),
          a2: *(_QWORD *)(v23 + 8));
        *(_BYTE *)(*(int *)(*(_QWORD *)v22 + 4LL) + v22 + 88) = 48; /*0x14100bdb7*/
        std::ostream::operator<<(a1: v22, a2: (unsigned __int8)(0x7317D97Bu >> v6)); /*0x14100bdcc*/
        v24 = std::ostream::operator<<(a1: key.gap10, a2: std::hex); /*0x14100bde4*/
        v25 = std::setw(a1: v32, a2: 2); /*0x14100bdf0*/
        (*(void (__fastcall **)(__int64, _QWORD))v25)( /*0x14100be06*/
          a1: v24 + *(int *)(*(_QWORD *)v24 + 4LL),
          a2: *(_QWORD *)(v25 + 8));
        *(_BYTE *)(*(int *)(*(_QWORD *)v24 + 4LL) + v24 + 88) = 48; /*0x14100be10*/
        std::ostream::operator<<(a1: v24, a2: (unsigned __int8)(0x31B5933Bu >> v6)); /*0x14100be25*/
        v26 = std::ostream::operator<<(a1: key.gap10, a2: std::hex); /*0x14100be3d*/
        v27 = std::setw(a1: v31, a2: 2); /*0x14100be49*/
        (*(void (__fastcall **)(__int64, _QWORD))v27)( /*0x14100be5f*/
          a1: v26 + *(int *)(*(_QWORD *)v26 + 4LL),
          a2: *(_QWORD *)(v27 + 8));
        *(_BYTE *)(*(int *)(*(_QWORD *)v26 + 4LL) + v26 + 88) = 48; /*0x14100be69*/
        std::ostream::operator<<(a1: v26, a2: (unsigned __int8)(0x48DE04E9u >> v6)); /*0x14100be7e*/
        v6 += 8LL; /*0x14100be84*/
      }
      while ( v6 < 0x20 ); /*0x14100be8c*/
    }
    if ( ticketVersion != 0 ) /*0x14100be95*/
      std::operator<<<std::char_traits<char>>(_Ostr: (std::ostream *)key.gap10, _Ch: ticketVersion); /*0x14100bea0*/
    std::stringbuf::str(this: (std::stringbuf *)&key.gap10[8], result); /*0x14100bead*/
  }
  __unwind
  {
    std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vbase destructor'(this: &key); /*0xf1c0000000000020*/
  }
  *(_QWORD *)&key.gap0[*(int *)(*(_QWORD *)key.gap0 + 4LL)] = std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vftable'; /*0x14100bebc*/
  *(int *)((char *)&v29 + *(int *)(*(_QWORD *)key.gap0 + 4LL)) = *(_DWORD *)(*(_QWORD *)key.gap0 + 4LL) - 152; /*0x14100bed0*/
  std::stringbuf::~stringbuf(this: (std::stringbuf *)&key.gap10[8]); /*0x14100bed9*/
  std::iostream::~iostream<char,std::char_traits<char>>(a1: &key.gap10[16]); /*0x14100bee3*/
  std::ios::~ios<char,std::char_traits<char>>(a1: &key.gap90[8]); /*0x14100beed*/
  return result; /*0x14100bef6*/
}

// Address: 0x1410111c0 | Name: ??_GEarlyAuthData@Security@RBX@@QEAAPEAXI@Z
RBX::Security::EarlyAuthData *__fastcall RBX::Security::EarlyAuthData::`scalar deleting destructor'(
        RBX::Security::EarlyAuthData *this,
        char a2)
{
  unsigned __int64 Myres; // rdx
  char *Ptr; // rcx
  unsigned __int64 v6; // rdx
  char *v7; // rcx

  Myres = this->authBlob._Mypair._Myval2._Myres; /*0x1410111cf*/
  if ( Myres >= 0x10 ) /*0x1410111d7*/
  {
    Ptr = this->authBlob._Mypair._Myval2._Bx._Ptr; /*0x1410111d9*/
    if ( Myres + 1 >= 0x1000 ) /*0x1410111e7*/
    {
      if ( (unsigned __int64)&Ptr[-*((_QWORD *)Ptr - 1) - 8] > 0x1F ) /*0x1410111fc*/
        goto LABEL_14; /*0x1410111fc*/
      Ptr = *((char **)Ptr - 1); /*0x141011202*/
    }
    operator delete(ptr: Ptr); /*0x141011205*/
  }
  this->authBlob._Mypair._Myval2._Mysize = 0; /*0x14101120a*/
  this->authBlob._Mypair._Myval2._Myres = 15; /*0x141011212*/
  this->authBlob._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14101121a*/
  v6 = this->preauthBlob._Mypair._Myval2._Myres; /*0x14101121e*/
  if ( v6 >= 0x10 ) /*0x141011226*/
  {
    v7 = this->preauthBlob._Mypair._Myval2._Bx._Ptr; /*0x141011228*/
    if ( v6 + 1 >= 0x1000 ) /*0x141011235*/
    {
      if ( (unsigned __int64)&v7[-*((_QWORD *)v7 - 1) - 8] <= 0x1F ) /*0x14101124a*/
      {
        v7 = *((char **)v7 - 1); /*0x14101124c*/
        goto LABEL_10; /*0x14101124c*/
      }
LABEL_14:
      _invalid_parameter_noinfo_noreturn(); /*0x141011288*/
    }
LABEL_10:
    operator delete(ptr: v7); /*0x14101124f*/
  }
  this->preauthBlob._Mypair._Myval2._Mysize = 0; /*0x141011254*/
  this->preauthBlob._Mypair._Myval2._Myres = 15; /*0x14101125c*/
  this->preauthBlob._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141011264*/
  if ( (a2 & 1) != 0 ) /*0x14101126b*/
    operator delete(ptr: this); /*0x141011275*/
  return this; /*0x14101127d*/
}

// Address: 0x1410b8c80 | Name: ??_GSessionCrypto@Security@RBX@@UEAAPEAXI@Z
RBX::Security::SessionCrypto *__fastcall RBX::Security::SessionCrypto::`scalar deleting destructor'(
        RBX::Security::SessionCrypto *this,
        char a2)
{
  RBX::Security::SessionCrypto::~SessionCrypto(this); /*0x1410b8c8f*/
  if ( (a2 & 1) != 0 ) /*0x1410b8c97*/
    operator delete(ptr: this); /*0x1410b8ca1*/
  return this; /*0x1410b8ca6*/
}

// Address: 0x143308140 | Name: RBX::Security::_dynamic_atexit_destructor_for__kRakNetEarlyPublicKeyName__
void RBX::Security::_dynamic_atexit_destructor_for__kRakNetEarlyPublicKeyName__()
{
  char *Ptr; // rcx

  if ( RBX::Security::kRakNetEarlyPublicKeyName._Mypair._Myval2._Myres >= 0x10 ) /*0x14330814f*/
  {
    Ptr = RBX::Security::kRakNetEarlyPublicKeyName._Mypair._Myval2._Bx._Ptr; /*0x143308151*/
    if ( RBX::Security::kRakNetEarlyPublicKeyName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x143308165*/
    {
      Ptr = *((char **)RBX::Security::kRakNetEarlyPublicKeyName._Mypair._Myval2._Bx._Ptr - 1); /*0x143308167*/
      if ( (unsigned __int64)(RBX::Security::kRakNetEarlyPublicKeyName._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14330817a*/
        _invalid_parameter_noinfo_noreturn(); /*0x14330817c*/
    }
    operator delete(ptr: Ptr); /*0x143308183*/
  }
  RBX::Security::kRakNetEarlyPublicKeyName._Mypair._Myval2._Mysize = 0; /*0x143308188*/
  RBX::Security::kRakNetEarlyPublicKeyName._Mypair._Myval2._Myres = 15; /*0x143308193*/
  RBX::Security::kRakNetEarlyPublicKeyName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14330819e*/
}

// Address: 0x1433081b0 | Name: RBX::Security::_dynamic_atexit_destructor_for__kRakNetEarlySecretKeyName__
void RBX::Security::_dynamic_atexit_destructor_for__kRakNetEarlySecretKeyName__()
{
  char *Ptr; // rcx

  if ( RBX::Security::kRakNetEarlySecretKeyName._Mypair._Myval2._Myres >= 0x10 ) /*0x1433081bf*/
  {
    Ptr = RBX::Security::kRakNetEarlySecretKeyName._Mypair._Myval2._Bx._Ptr; /*0x1433081c1*/
    if ( RBX::Security::kRakNetEarlySecretKeyName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1433081d5*/
    {
      Ptr = *((char **)RBX::Security::kRakNetEarlySecretKeyName._Mypair._Myval2._Bx._Ptr - 1); /*0x1433081d7*/
      if ( (unsigned __int64)(RBX::Security::kRakNetEarlySecretKeyName._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1433081ea*/
        _invalid_parameter_noinfo_noreturn(); /*0x1433081ec*/
    }
    operator delete(ptr: Ptr); /*0x1433081f3*/
  }
  RBX::Security::kRakNetEarlySecretKeyName._Mypair._Myval2._Mysize = 0; /*0x1433081f8*/
  RBX::Security::kRakNetEarlySecretKeyName._Mypair._Myval2._Myres = 15; /*0x143308203*/
  RBX::Security::kRakNetEarlySecretKeyName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14330820e*/
}

// Address: 0x14335ac50 | Name: RBX::Security::_dynamic_atexit_destructor_for__hackFlagVp__
void RBX::Security::_dynamic_atexit_destructor_for__hackFlagVp__()
{
  void *ptr; // [rsp+8h] [rbp+8h]

  LODWORD(ptr) = RBX::Security::hackFlagVp.ptr.storage.asRaw[0] ^ (unsigned int)&RBX::Security::hackFlagVp; /*0x14335ac6a*/
  HIDWORD(ptr) = RBX::Security::hackFlagVp.ptr.storage.asRaw[1] ^ (unsigned int)&RBX::Security::hackFlagVp; /*0x14335ac6e*/
  operator delete(ptr); /*0x14335ac77*/
}

// END Security part 1/1, 10 functions
