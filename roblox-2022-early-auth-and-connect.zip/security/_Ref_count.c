// _Ref_count -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x1410136b0 | Name: ?_Destroy@?$_Ref_count@UEarlyAuthData@Security@RBX@@@std@@EEAAXXZ
void __fastcall std::_Ref_count<RBX::Security::EarlyAuthData>::_Destroy(
        std::_Ref_count<RBX::Security::EarlyAuthData> *this)
{
  RBX::Security::EarlyAuthData *Ptr; // rcx

  Ptr = this->_Ptr; /*0x1410136b0*/
  if ( Ptr != nullptr ) /*0x1410136b7*/
    RBX::Security::EarlyAuthData::`scalar deleting destructor'(this: Ptr, a2: 1); /*0x1410136be*/
}

// END _Ref_count part 1/1, 1 functions
