// PlayerConfigurer -- 2022 Studio + full PDB
// tier 3, 31 functions


// Address: 0x141033850 | Name: ??0PlayerConfigurer@RBX@@QEAA@XZ
RBX::PlayerConfigurer *__fastcall RBX::PlayerConfigurer::PlayerConfigurer(RBX::PlayerConfigurer *this)
{
  std::string *v2; // rbx
  std::string *v3; // rbx
  RBX::PlayerConfigurer *result; // rax

  this->_Wptr._Ptr = nullptr; /*0x141033869*/
  this->_Wptr._Rep = nullptr; /*0x14103386d*/
  this->parameters._Ptr = nullptr; /*0x141033871*/
  this->parameters._Rep = nullptr; /*0x141033875*/
  this->__vftable = (RBX::PlayerConfigurer_vtbl *)RBX::PlayerConfigurer::`vftable'; /*0x141033880*/
  *(_DWORD *)&this->testing = 1; /*0x141033883*/
  *(_DWORD *)&this->connectionFailed = 0x1000000; /*0x14103388a*/
  *(_WORD *)&this->waitingForCharacter = 0; /*0x141033891*/
  this->userId = 0; /*0x141033895*/
  this->userJoinDataOverrides._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033899*/
  this->userJoinDataOverrides._Mypair._Myval2._Mysize = 0; /*0x14103389d*/
  this->userJoinDataOverrides._Mypair._Myval2._Myres = 15; /*0x1410338a1*/
  this->userJoinDataOverrides._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410338a9*/
  this->sgs.userClickTime = 0.0; /*0x1410338ad*/
  this->sgs.videoAdFinishedTime = 0.0; /*0x1410338b1*/
  this->sgs.startGameTime = 0.0; /*0x1410338b5*/
  this->sgs.placelauncherStartTime = 0.0; /*0x1410338bc*/
  this->sgs.fetchedJoinScriptTime = 0.0; /*0x1410338c3*/
  this->sgs.playerConfigureTime = 0.0; /*0x1410338ca*/
  this->sgs.connectTime = 0.0; /*0x1410338d1*/
  this->sgs.receivedGlobalsTime = 0.0; /*0x1410338d8*/
  this->sgs.gameLoadTime = 0.0; /*0x1410338df*/
  this->sgs.gameJoinTime = 0.0; /*0x1410338e6*/
  this->sgs.avatarConfigureTime = 0.0; /*0x1410338ed*/
  this->sgs.avatarCreateTime = 0.0; /*0x1410338f4*/
  this->sgs.avatarClusterEndTime = 0.0; /*0x1410338fb*/
  this->sgs.avatarTextureEndTime = 0.0; /*0x141033902*/
  this->sgs.avatarLoadTime = 0.0; /*0x141033909*/
  this->sgs.defaultLoadingGuiRemovedTime = 0.0; /*0x141033910*/
  this->sgs.joinRequestType._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033917*/
  this->sgs.joinRequestType._Mypair._Myval2._Mysize = 0; /*0x14103391e*/
  this->sgs.joinRequestType._Mypair._Myval2._Myres = 15; /*0x141033925*/
  this->sgs.networkType._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033930*/
  this->sgs.networkType._Mypair._Myval2._Mysize = 0; /*0x141033937*/
  this->sgs.networkType._Mypair._Myval2._Myres = 15; /*0x14103393e*/
  this->sgs.device._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033949*/
  this->sgs.device._Mypair._Myval2._Mysize = 0; /*0x141033950*/
  this->sgs.device._Mypair._Myval2._Myres = 15; /*0x141033957*/
  this->sgs.dataCenterId = 0; /*0x141033962*/
  this->sgs.gameReceiveGlobalsBytesReceived = 0.0; /*0x141033968*/
  this->sgs.gameJoinBytesReceived = 0.0; /*0x14103396f*/
  this->sgs.gameLoadBytesReceived = 0.0; /*0x141033976*/
  *(_WORD *)&this->sgs.videoAdShown = 0; /*0x14103397d*/
  this->sgs.referralPage._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033984*/
  this->sgs.referralPage._Mypair._Myval2._Mysize = 0; /*0x14103398b*/
  this->sgs.referralPage._Mypair._Myval2._Myres = 15; /*0x141033992*/
  this->sgs.joinPhase = JoinPhase_NotStarted; /*0x14103399d*/
  this->joinPhaseStrings._Elems[0]._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410339a7*/
  this->joinPhaseStrings._Elems[0]._Mypair._Myval2._Myres = 15; /*0x1410339ae*/
  this->joinPhaseStrings._Elems[0]._Mypair._Myval2._Mysize = 0; /*0x1410339b9*/
  this->joinPhaseStrings._Elems[0]._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410339c0*/
  v2 = &this->joinPhaseStrings._Elems[1]; /*0x1410339c7*/
  this->joinPhaseStrings._Elems[1]._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410339ce*/
  this->joinPhaseStrings._Elems[1]._Mypair._Myval2._Myres = 15; /*0x1410339d1*/
  this->joinPhaseStrings._Elems[1]._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410339d9*/
  this->joinPhaseStrings._Elems[1]._Mypair._Myval2._Mysize = 10; /*0x1410339dc*/
  memmove_0(a1: &this->joinPhaseStrings._Elems[1], Src: "NotStarted", Size: 0xAu); /*0x1410339f2*/
  v2->_Mypair._Myval2._Bx._Buf[10] = 0; /*0x1410339f7*/
  this->joinPhaseStrings._Elems[2]._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033a02*/
  this->joinPhaseStrings._Elems[2]._Mypair._Myval2._Myres = 15; /*0x141033a05*/
  this->joinPhaseStrings._Elems[2]._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141033a0d*/
  this->joinPhaseStrings._Elems[2]._Mypair._Myval2._Mysize = 13; /*0x141033a10*/
  memmove_0(a1: &this->joinPhaseStrings._Elems[2], Src: "PlaceLaunched", Size: 0xDu); /*0x141033a26*/
  __wind /*0xf1c00000000000f4*/
  {
    __wind /*0xf1c00000000000fc*/
    {
      __wind /*0xf1c0000000000104*/
      {
        __wind /*0xf1c000000000010c*/
        {
          __wind /*0xf1c0000000000114*/
          {
            __wind /*0xf1c000000000011c*/
            {
              this->joinPhaseStrings._Elems[2]._Mypair._Myval2._Bx._Buf[13] = 0; /*0x141033a2b*/
              this->joinPhaseStrings._Elems[3]._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033a36*/
              this->joinPhaseStrings._Elems[3]._Mypair._Myval2._Mysize = 0; /*0x141033a39*/
              this->joinPhaseStrings._Elems[3]._Mypair._Myval2._Myres = 15; /*0x141033a3d*/
              this->joinPhaseStrings._Elems[3]._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141033a45*/
              std::string::assign(this: &this->joinPhaseStrings._Elems[3], _Ptr: "FetchedJoinScript", _Count: 0x11u); /*0x141033a53*/
              __wind /*0xf1c0000000000050*/
              {
                this->joinPhaseStrings._Elems[4]._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033a60*/
                this->joinPhaseStrings._Elems[4]._Mypair._Myval2._Mysize = 0; /*0x141033a63*/
                this->joinPhaseStrings._Elems[4]._Mypair._Myval2._Myres = 15; /*0x141033a67*/
                this->joinPhaseStrings._Elems[4]._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141033a6f*/
                std::string::assign(this: &this->joinPhaseStrings._Elems[4], _Ptr: "PlayerConfigured", _Count: 0x10u); /*0x141033a7d*/
                this->joinPhaseStrings._Elems[5]._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033a8a*/
                this->joinPhaseStrings._Elems[5]._Mypair._Myval2._Myres = 15; /*0x141033a8d*/
                this->joinPhaseStrings._Elems[5]._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141033a95*/
                this->joinPhaseStrings._Elems[5]._Mypair._Myval2._Mysize = 9; /*0x141033a98*/
                memmove_0(a1: &this->joinPhaseStrings._Elems[5], Src: "Connected", Size: 9u); /*0x141033aae*/
                this->joinPhaseStrings._Elems[5]._Mypair._Myval2._Bx._Buf[9] = 0; /*0x141033ab3*/
                this->joinPhaseStrings._Elems[6]._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033abe*/
                this->joinPhaseStrings._Elems[6]._Mypair._Myval2._Myres = 15; /*0x141033ac1*/
                this->joinPhaseStrings._Elems[6]._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141033ac9*/
                this->joinPhaseStrings._Elems[6]._Mypair._Myval2._Mysize = 15; /*0x141033acc*/
                memmove_0(a1: &this->joinPhaseStrings._Elems[6], Src: "ReceivedGlobals", Size: 0xFu); /*0x141033ae2*/
                this->joinPhaseStrings._Elems[6]._Mypair._Myval2._Bx._Buf[15] = 0; /*0x141033ae7*/
                this->joinPhaseStrings._Elems[7]._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033af2*/
                this->joinPhaseStrings._Elems[7]._Mypair._Myval2._Myres = 15; /*0x141033af5*/
                this->joinPhaseStrings._Elems[7]._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141033afd*/
                this->joinPhaseStrings._Elems[7]._Mypair._Myval2._Mysize = 10; /*0x141033b00*/
                memmove_0(a1: &this->joinPhaseStrings._Elems[7], Src: "GameLoaded", Size: 0xAu); /*0x141033b16*/
                this->joinPhaseStrings._Elems[7]._Mypair._Myval2._Bx._Buf[10] = 0; /*0x141033b1b*/
                this->joinPhaseStrings._Elems[8]._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033b26*/
                this->joinPhaseStrings._Elems[8]._Mypair._Myval2._Myres = 15; /*0x141033b29*/
                this->joinPhaseStrings._Elems[8]._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141033b31*/
                this->joinPhaseStrings._Elems[8]._Mypair._Myval2._Mysize = 10; /*0x141033b34*/
                memmove_0(a1: &this->joinPhaseStrings._Elems[8], Src: "GameJoined", Size: 0xAu); /*0x141033b4a*/
                this->joinPhaseStrings._Elems[8]._Mypair._Myval2._Bx._Buf[10] = 0; /*0x141033b4f*/
                v3 = &this->joinPhaseStrings._Elems[9]; /*0x141033b53*/
                this->joinPhaseStrings._Elems[9]._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141033b5a*/
                this->joinPhaseStrings._Elems[9]._Mypair._Myval2._Myres = 15; /*0x141033b5d*/
                this->joinPhaseStrings._Elems[9]._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141033b65*/
                this->joinPhaseStrings._Elems[9]._Mypair._Myval2._Mysize = 12; /*0x141033b68*/
                memmove_0(a1: &this->joinPhaseStrings._Elems[9], Src: "AvatarLoaded", Size: 0xCu); /*0x141033b7e*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->joinPhaseStrings._Elems[3]); /*0x1431e6bd2*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->joinPhaseStrings._Elems[2]); /*0x1431e6bb2*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->joinPhaseStrings._Elems[1]); /*0x1431e6b92*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->joinPhaseStrings); /*0x1431e6b6e*/
        }
        __wind /*0xf1c000000000008c*/
        {
          v3->_Mypair._Myval2._Bx._Buf[12] = 0; /*0x141033b83*/
          RBX::Analytics::InfluxDb::Points::Points( /*0x141033b97*/
            this: &this->analyticsPoints,
            throttleHundredthsPercentage: -1,
            categoryType: kStandardType,
            priorityHundredthsPercentage: 0);
          __wind /*0xf1c00000000000c8*/
          {
            __wind /*0xf1c00000000000d0*/
            {
              this->gamePerfMonitor._Ptr = nullptr; /*0x141033b9d*/
              this->gamePerfMonitor._Rep = nullptr; /*0x141033ba4*/
              if ( __TSS0__1____startup_V__SubsystemDefaultFactory_VTelemetryInformation_Analytics_RBX___RBX_____Subsystem_VTelemetryInformation_Analytics_RBX___0A__RBX__SA_AV__SubsystemHandle_VTelemetryInformation_Analytics_RBX___2_XZ_4HA > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x141033bcc*/
              {
                Init_thread_header(pOnce: &__TSS0__1____startup_V__SubsystemDefaultFactory_VTelemetryInformation_Analytics_RBX___RBX_____Subsystem_VTelemetryInformation_Analytics_RBX___0A__RBX__SA_AV__SubsystemHandle_VTelemetryInformation_Analytics_RBX___2_XZ_4HA); /*0x141033c48*/
                if ( __TSS0__1____startup_V__SubsystemDefaultFactory_VTelemetryInformation_Analytics_RBX___RBX_____Subsystem_VTelemetryInformation_Analytics_RBX___0A__RBX__SA_AV__SubsystemHandle_VTelemetryInformation_Analytics_RBX___2_XZ_4HA == -1 ) /*0x141033c54*/
                {
                  `RBX::Subsystem<RBX::Analytics::TelemetryInformation,0>::startup<RBX::SubsystemDefaultFactory<RBX::Analytics::TelemetryInformation>>'::`2'::storage_theHandle_ = (__int64)RBX::subsysDetail::SubsystemHandleImpl::`vftable'; /*0x141033c61*/
                  Mtx_init_in_situ_0(a1: (_Mtx_t)&unk_14557BE18, a2: 258); /*0x141033c74*/
                  qword_14557BE68 = 0; /*0x141033c79*/
                  dword_14557BE70 = 0; /*0x141033c80*/
                  `RBX::Subsystem<RBX::Analytics::TelemetryInformation,0>::startup<RBX::SubsystemDefaultFactory<RBX::Analytics::TelemetryInformation>>'::`2'::storage_theHandle_ = (__int64)`RBX::Subsystem<RBX::Analytics::TelemetryInformation,0>::startup<RBX::SubsystemDefaultFactory<RBX::Analytics::TelemetryInformation>>'::`2'::SubsystemHandleImplForT::`vftable'; /*0x141033c8d*/
                  RBX::Subsystem<RBX::Analytics::TelemetryInformation,0>::defaultHandle.impl = (RBX::subsysDetail::SubsystemHandleImpl *)&`RBX::Subsystem<RBX::Analytics::TelemetryInformation,0>::startup<RBX::SubsystemDefaultFactory<RBX::Analytics::TelemetryInformation>>'::`2'::storage_theHandle_; /*0x141033c9b*/
                  `RBX::Subsystem<RBX::Analytics::TelemetryInformation,0>::startup<RBX::SubsystemDefaultFactory<RBX::Analytics::TelemetryInformation>>'::`2'::theHandle = (__int64)&`RBX::Subsystem<RBX::Analytics::TelemetryInformation,0>::startup<RBX::SubsystemDefaultFactory<RBX::Analytics::TelemetryInformation>>'::`2'::storage_theHandle_; /*0x141033ca2*/
                  Init_thread_footer(pOnce: &__TSS0__1____startup_V__SubsystemDefaultFactory_VTelemetryInformation_Analytics_RBX___RBX_____Subsystem_VTelemetryInformation_Analytics_RBX___0A__RBX__SA_AV__SubsystemHandle_VTelemetryInformation_Analytics_RBX___2_XZ_4HA); /*0x141033cb0*/
                }
              }
              this->telemetryInformation.handle.impl = (RBX::subsysDetail::SubsystemHandleImpl *)(**(__int64 (__fastcall ***)(__int64))`RBX::Subsystem<RBX::Analytics::TelemetryInformation,0>::startup<RBX::SubsystemDefaultFactory<RBX::Analytics::TelemetryInformation>>'::`2'::theHandle)(a1: `RBX::Subsystem<RBX::Analytics::TelemetryInformation,0>::startup<RBX::SubsystemDefaultFactory<RBX::Analytics::TelemetryInformation>>'::`2'::theHandle); /*0x141033bda*/
              this->playerChangedConnection.con.weak_slot.p_ = nullptr; /*0x141033be1*/
              this->idlingConnection.con.weak_slot.p_ = nullptr; /*0x141033be8*/
              this->avatarClusterStartConnection.con.weak_slot.p_ = nullptr; /*0x141033bef*/
              this->avatarClusterEndConnection.con.weak_slot.p_ = nullptr; /*0x141033bf6*/
              this->avatarTextureStartConnection.con.weak_slot.p_ = nullptr; /*0x141033bfd*/
              this->avatarTextureEndConnection.con.weak_slot.p_ = nullptr; /*0x141033c04*/
              this->clientJoinFailureConnection.con.weak_slot.p_ = nullptr; /*0x141033c0b*/
              this->connections._Mypair._Myval2._Myfirst = nullptr; /*0x141033c12*/
              this->connections._Mypair._Myval2._Mylast = nullptr; /*0x141033c19*/
              this->connections._Mypair._Myval2._Myend = nullptr; /*0x141033c20*/
              this->defaultLoadingGuiRemovedConnection.weak_slot.p_ = nullptr; /*0x141033c27*/
              result = this; /*0x141033c2e*/
            }
            __unwind
            {
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->gamePerfMonitor); /*0x1431e6cce*/
            }
          }
          __unwind
          {
            RBX::Analytics::InfluxDb::Points::~Points(this: &this->analyticsPoints); /*0x1431e6cae*/
          }
        }
        __unwind
        {
          std::array<std::string,10>::~array<std::string,10>(this: &this->joinPhaseStrings); /*0x1431e6c8e*/
        }
      }
      __unwind
      {
        StartGameStatistics::~StartGameStatistics(this: &this->sgs); /*0x1431e6b5b*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->userJoinDataOverrides); /*0x143166e2b*/
    }
  }
  __unwind
  {
    RBX::GameConfigurer::~GameConfigurer(this); /*0xf1c00000000000c0*/
  }
  return result; /*0x141033c31*/
}

// Address: 0x141034130 | Name: ??1PlayerConfigurer@RBX@@UEAA@XZ
void __fastcall RBX::PlayerConfigurer::~PlayerConfigurer(RBX::PlayerConfigurer *this)
{
  char *Ptr; // rcx
  rbx::signals::connection *Mylast; // rsi
  rbx::signals::connection *i; // rbx
  rbx::signals::slot_base *p; // rcx
  rbx::signals::slot_base *v6; // rcx
  rbx::signals::slot_base *v7; // rcx
  rbx::signals::slot_base *v8; // rcx
  rbx::signals::slot_base *v9; // rcx
  rbx::signals::slot_base *v10; // rcx
  rbx::signals::slot_base *v11; // rcx
  rbx::signals::slot_base *v12; // rcx
  void *impl; // rcx
  std::_Ref_count_base *Rep; // rbx
  unsigned __int64 Myres; // rdx
  char *v16; // rcx
  __int64 v17; // [rsp+0h] [rbp-58h] BYREF
  std::string resource; // [rsp+20h] [rbp-38h] BYREF

  this->__vftable = (RBX::PlayerConfigurer_vtbl *)RBX::PlayerConfigurer::`vftable'; /*0x14103414c*/
  resource._Mypair._Myval2._Myres = 15; /*0x14103414f*/
  resource._Mypair._Myval2._Mysize = 14; /*0x141034158*/
  strcpy(resource._Mypair._Myval2._Bx._Buf, "ClientJoinFail"); /*0x141034169*/
  RBX::Analytics::InfluxDb::Points::report( /*0x1410341a0*/
    this: &this->analyticsPoints,
    &resource,
    throttleHundredthsPercentage: DFInt::JoinInfluxHundredthsPercentage,
    blocking: false);
  if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x1410341ae*/
  {
    Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x1410341b3*/
    if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410341c2*/
    {
      Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x1410341c8*/
      if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410341d7*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410341d9*/
    }
    operator delete(ptr: Ptr); /*0x1410341e0*/
  }
  Mylast = this->connections._Mypair._Myval2._Mylast; /*0x1410341e5*/
  for ( i = this->connections._Mypair._Myval2._Myfirst; i != Mylast; ++i ) /*0x1410341f6*/
    rbx::signals::connection::disconnect(this: i); /*0x1410341fb*/
  if ( DFFlag::ReportDefaultLoadingGuiRemovalTimeWithChildrenCheck.value ) /*0x141034210*/
    rbx::signals::connection::disconnect(this: &this->defaultLoadingGuiRemovedConnection); /*0x141034219*/
  p = this->defaultLoadingGuiRemovedConnection.weak_slot.p_; /*0x14103421e*/
  if ( p != nullptr && _InterlockedExchangeAdd(&p->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x141034239*/
    operator delete(ptr: p); /*0x14103423b*/
  std::vector<rbx::signals::connection>::~vector<rbx::signals::connection>(this: &this->connections); /*0x141034247*/
  __eh34_enter_wind_state(-1, 0); /*0xf1c000000000003c*/
  rbx::signals::connection::disconnect(this: &this->clientJoinFailureConnection.con); /*0x141034254*/
  v6 = this->clientJoinFailureConnection.con.weak_slot.p_; /*0x141034259*/
  if ( v6 != nullptr && _InterlockedExchangeAdd(&v6->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x14103426f*/
    operator delete(ptr: v6); /*0x141034271*/
  rbx::signals::connection::disconnect(this: &this->avatarTextureEndConnection.con); /*0x14103427e*/
  v7 = this->avatarTextureEndConnection.con.weak_slot.p_; /*0x141034283*/
  if ( v7 != nullptr && _InterlockedExchangeAdd(&v7->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x141034299*/
    operator delete(ptr: v7); /*0x14103429b*/
  rbx::signals::connection::disconnect(this: &this->avatarTextureStartConnection.con); /*0x1410342a8*/
  v8 = this->avatarTextureStartConnection.con.weak_slot.p_; /*0x1410342ad*/
  if ( v8 != nullptr && _InterlockedExchangeAdd(&v8->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x1410342c3*/
    operator delete(ptr: v8); /*0x1410342c5*/
  rbx::signals::connection::disconnect(this: &this->avatarClusterEndConnection.con); /*0x1410342d2*/
  v9 = this->avatarClusterEndConnection.con.weak_slot.p_; /*0x1410342d7*/
  if ( v9 != nullptr && _InterlockedExchangeAdd(&v9->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x1410342ed*/
    operator delete(ptr: v9); /*0x1410342ef*/
  rbx::signals::connection::disconnect(this: &this->avatarClusterStartConnection.con); /*0x1410342fc*/
  v10 = this->avatarClusterStartConnection.con.weak_slot.p_; /*0x141034301*/
  if ( v10 != nullptr && _InterlockedExchangeAdd(&v10->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x141034317*/
    operator delete(ptr: v10); /*0x141034319*/
  rbx::signals::connection::disconnect(this: &this->idlingConnection.con); /*0x141034326*/
  v11 = this->idlingConnection.con.weak_slot.p_; /*0x14103432b*/
  if ( v11 != nullptr && _InterlockedExchangeAdd(&v11->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x141034341*/
    operator delete(ptr: v11); /*0x141034343*/
  rbx::signals::connection::disconnect(this: &this->playerChangedConnection.con); /*0x141034350*/
  v12 = this->playerChangedConnection.con.weak_slot.p_; /*0x141034355*/
  if ( v12 != nullptr && _InterlockedExchangeAdd(&v12->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x14103436b*/
    operator delete(ptr: v12); /*0x14103436d*/
  impl = this->telemetryInformation.handle.impl; /*0x141034373*/
  if ( impl != nullptr ) /*0x14103437d*/
    (*(void (__fastcall **)(void *))(*(_QWORD *)impl + 16LL))(a1: impl); /*0x141034382*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000030*/
unwind_state_0:
    __std_terminate(a1: impl, a2: &v17); /*0xf1c0000000000018*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000034*/
  Rep = this->gamePerfMonitor._Rep; /*0x141034386*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14103439c*/
  {
    Rep->_Destroy(this: Rep); /*0x1410343a4*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410343ae*/
      Rep->_Delete_this(this: Rep); /*0x1410343b6*/
  }
  RBX::Analytics::InfluxDb::Points::~Points(this: &this->analyticsPoints); /*0x1410343c0*/
  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000028*/
  `eh vector destructor iterator'( /*0x1410343dd*/
    ptr: &this->joinPhaseStrings,
    size: 0x20u,
    count: 0xAu,
    destructor: (void (__fastcall *)(void *))RBX::Graphics::ProfilerAdorn::Item::~Item);
  StartGameStatistics::~StartGameStatistics(this: &this->sgs); /*0x1410343e7*/
  Myres = this->userJoinDataOverrides._Mypair._Myval2._Myres; /*0x1410343ec*/
  if ( Myres >= 0x10 ) /*0x1410343f4*/
  {
    v16 = this->userJoinDataOverrides._Mypair._Myval2._Bx._Ptr; /*0x1410343f9*/
    if ( Myres + 1 >= 0x1000 ) /*0x141034404*/
    {
      if ( (unsigned __int64)&v16[-*((_QWORD *)v16 - 1) - 8] > 0x1F ) /*0x141034419*/
        _invalid_parameter_noinfo_noreturn(); /*0x141034451*/
      v16 = *((char **)v16 - 1); /*0x14103441b*/
    }
    operator delete(ptr: v16); /*0x14103441e*/
  }
  this->userJoinDataOverrides._Mypair._Myval2._Mysize = 0; /*0x141034423*/
  this->userJoinDataOverrides._Mypair._Myval2._Myres = 15; /*0x14103442b*/
  this->userJoinDataOverrides._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141034433*/
  impl = this; /*0x141034437*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000014*/
    goto unwind_state_0; /*0xf1c0000000000014*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000020*/
  RBX::GameConfigurer::~GameConfigurer(this); /*0x14103444c*/
}

// Address: 0x1410353d0 | Name: ?buildAvatarMetrics@PlayerConfigurer@RBX@@AEAAXAEAUAvatarMetrics@2@PEAVHumanoid@2@_N@Z
void __fastcall RBX::PlayerConfigurer::buildAvatarMetrics(
        RBX::PlayerConfigurer *this,
        RBX::AvatarMetrics *metrics,
        RBX::ServiceProvider *humanoid,
        bool isLocalPlayer)
{
  RBX::AvatarMetrics *v7; // rbx
  long double *p_clusterEndTime; // r12
  std::string **p_Myfirst; // rbx
  RBX::AvatarMetrics *h; // rdx
  unsigned __int64 appearanceId; // r8
  long double v12; // xmm2_8
  long double v13; // xmm1_8
  double v14; // xmm0_8
  RBX::ServiceProvider *parent; // r14
  RBX::Instance *v16; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v18; // rax
  unsigned __int64 v19; // rax
  RBX::Described<RBX::Workspace,RBX::WorldRoot> *v20; // rcx
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v21; // r12
  const RBX::Name *v22; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *Rep; // rbx
  __int64 v25; // rax
  __m128 v26; // xmm4
  __m128 v27; // xmm3
  float v28; // xmm2_4
  RBX::Player *PlayerFromCharacter; // rax
  RBX::Player *v30; // rbx
  std::string *DisplayName; // rax
  char *Ptr; // rcx
  std::string *PlatformName; // rax
  char *v34; // rcx
  long double v35; // xmm1_8
  RBX::DataModel *dataModel; // rax
  RBX::ServiceProvider *v37; // rcx
  RBX::Instance *v38; // rcx
  RBX::DataModel *v39; // rax
  RBX::ServiceProvider *v40; // rcx
  RBX::ContentProvider *v41; // rdx
  RBX::ContentTracker *Myval2; // rcx
  std::function<void __cdecl(RBX::ContentTracker::Asset const &)> *p_v; // rdx
  std::shared_ptr<RBX::Instance> result; // [rsp+20h] [rbp-E0h] BYREF
  __int128 v45; // [rsp+30h] [rbp-D0h]
  std::function<void __cdecl(RBX::ContentTracker::Asset const &)> v; // [rsp+40h] [rbp-C0h] BYREF
  std::string v47; // [rsp+80h] [rbp-80h] BYREF
  std::string v48; // [rsp+A0h] [rbp-60h] BYREF
  RBX::CoordinateFrame v49; // [rsp+C0h] [rbp-40h]
  RBX::AvatarMetrics v50; // [rsp+F0h] [rbp-10h] BYREF
  double playerCreateTime; // [rsp+280h] [rbp+180h]

  memset_0(a1: &v50, Val: 0, Size: sizeof(v50)); /*0x141035409*/
  v7 = RBX::AvatarMetrics::AvatarMetrics(this: &v50); /*0x141035417*/
  metrics->humanoidAddr = v7->humanoidAddr; /*0x14103541d*/
  metrics->userId = v7->userId; /*0x141035424*/
  metrics->appearanceId = v7->appearanceId; /*0x14103542c*/
  std::string::operator=(this: &metrics->displayName, _Right: &v7->displayName); /*0x141035438*/
  std::string::operator=(this: &metrics->platformName, _Right: &v7->platformName); /*0x141035445*/
  std::string::operator=(this: &metrics->modelName, _Right: &v7->modelName); /*0x141035455*/
  metrics->autoSpawn = v7->autoSpawn; /*0x14103545e*/
  metrics->r15 = v7->r15; /*0x141035465*/
  metrics->localPlayer = v7->localPlayer; /*0x14103546c*/
  metrics->createTime = v7->createTime; /*0x141035476*/
  metrics->numPlayers = v7->numPlayers; /*0x141035484*/
  metrics->spawnPosition = v7->spawnPosition; /*0x141035493*/
  metrics->spawnDirection = v7->spawnDirection; /*0x1410354af*/
  metrics->cameraPosition = v7->cameraPosition; /*0x1410354cb*/
  metrics->cameraDirection = v7->cameraDirection; /*0x1410354e7*/
  metrics->clusterStartTime = v7->clusterStartTime; /*0x141035502*/
  p_clusterEndTime = &metrics->clusterEndTime; /*0x141035509*/
  metrics->clusterEndTime = v7->clusterEndTime; /*0x141035517*/
  metrics->clusterUpdateCnt = v7->clusterUpdateCnt; /*0x141035522*/
  metrics->textureStartTime = v7->textureStartTime; /*0x141035530*/
  metrics->textureEndTime = v7->textureEndTime; /*0x14103553e*/
  metrics->completionTime = v7->completionTime; /*0x14103554c*/
  metrics->netCompletionTime = v7->netCompletionTime; /*0x14103555a*/
  metrics->httpCacheHitCnt = v7->httpCacheHitCnt; /*0x141035568*/
  metrics->httpCacheMissCnt = v7->httpCacheMissCnt; /*0x141035576*/
  metrics->httpCacheHitBytes = v7->httpCacheHitBytes; /*0x141035584*/
  metrics->httpCacheMissBytes = v7->httpCacheMissBytes; /*0x141035592*/
  metrics->assetsByteSize = v7->assetsByteSize; /*0x1410355a0*/
  metrics->texturesByteSize = v7->texturesByteSize; /*0x1410355ae*/
  metrics->animationsByteSize = v7->animationsByteSize; /*0x1410355bc*/
  p_Myfirst = &v7->assetDescriptions._Mypair._Myval2._Myfirst; /*0x1410355c3*/
  if ( &metrics->assetDescriptions != (std::vector<std::string> *)p_Myfirst ) /*0x1410355d4*/
  {
    std::vector<RBX::Scripting::DAP::ExceptionOptions>::_Tidy(this: (std::vector<RBX::TextureId> *)&metrics->assetDescriptions); /*0x1410355d9*/
    metrics->assetDescriptions._Mypair._Myval2._Myfirst = *p_Myfirst; /*0x1410355e1*/
    metrics->assetDescriptions._Mypair._Myval2._Mylast = p_Myfirst[1]; /*0x1410355e8*/
    metrics->assetDescriptions._Mypair._Myval2._Myend = p_Myfirst[2]; /*0x1410355f0*/
    *p_Myfirst = nullptr; /*0x1410355f6*/
    p_Myfirst[1] = nullptr; /*0x1410355f9*/
    p_Myfirst[2] = nullptr; /*0x1410355fd*/
  }
  RBX::AvatarMetrics::~AvatarMetrics(this: &v50); /*0x141035605*/
  metrics->humanoidAddr = 0x85FDB20E1294309AuLL - 0x3AE910A3C8B9DB97LL * (_QWORD)humanoid; /*0x141035628*/
  metrics->localPlayer = isLocalPlayer; /*0x141035632*/
  metrics->r15 = HIDWORD(humanoid[2].propertyChangedSignal.head.px) != 0; /*0x14103563f*/
  h = (RBX::AvatarMetrics *)humanoid->parent->name.h.h; /*0x141035646*/
  if ( &metrics->modelName != (std::string *)h ) /*0x14103564d*/
  {
    appearanceId = h->appearanceId; /*0x14103564f*/
    if ( h->displayName._Mypair._Myval2._Bx._Ptr >= (char *)0x10 ) /*0x141035658*/
      h = (RBX::AvatarMetrics *)h->humanoidAddr; /*0x14103565a*/
    std::string::assign(this: &metrics->modelName, _Ptr: (const char *const)h, _Count: appearanceId); /*0x141035660*/
  }
  metrics->clusterStartTime = *(double *)&humanoid[8].serviceRemovingSignal.head.px - this->sgs.userClickTime; /*0x141035673*/
  v12 = *(double *)&humanoid[8].serviceRemovingSignal.slots._Ptr - this->sgs.userClickTime; /*0x141035683*/
  *p_clusterEndTime = v12; /*0x141035689*/
  metrics->clusterUpdateCnt = LODWORD(humanoid[8].serviceAddedSignal.slots._Rep); /*0x141035695*/
  metrics->textureStartTime = *(double *)&humanoid[8].serviceRemovingSignal.slots._Rep - this->sgs.userClickTime; /*0x1410356aa*/
  v13 = *(double *)&humanoid[9].__vftable - this->sgs.userClickTime; /*0x1410356ba*/
  metrics->textureEndTime = v13; /*0x1410356c7*/
  if ( v13 > v12 ) /*0x1410356cf*/
    p_clusterEndTime = &metrics->textureEndTime; /*0x1410356cf*/
  v14 = *p_clusterEndTime; /*0x1410356d3*/
  metrics->completionTime = *p_clusterEndTime; /*0x1410356d9*/
  metrics->netCompletionTime = v14 - this->sgs.receivedGlobalsTime; /*0x1410356ea*/
  if ( DFFlag::PlayerConfigurer2886.value ) /*0x1410356f9*/
  {
    parent = (RBX::ServiceProvider *)humanoid->parent; /*0x1410356ff*/
    if ( parent != nullptr ) /*0x141035706*/
    {
      v16 = parent->parent; /*0x141035708*/
      if ( v16 != nullptr ) /*0x14103570f*/
        parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v16); /*0x141035716*/
    }
    else
    {
      parent = humanoid; /*0x14103571b*/
    }
    if ( parent != nullptr ) /*0x141035721*/
    {
      descriptor = parent->descriptor; /*0x141035727*/
      v18 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(); /*0x14103572b*/
      if ( descriptor->index - (unsigned int)v18->index <= v18->descendantCount ) /*0x141035749*/
      {
        boost::call_once( /*0x14103575d*/
          flag: &`RBX::ServiceProvider::getClassIndex<RBX::Workspace>'::`2'::flag,
          f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Workspace>);
        v19 = RBX::ServiceProvider::doGetClassIndex<RBX::Workspace>(); /*0x141035762*/
        v21 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt( /*0x141035772*/
                                                                                   this: parent,
                                                                                   index: v19);
        if ( v21->_Ptr == nullptr ) /*0x141035779*/
        {
          v22 = RBX::Reflection::Class_getNamePtr<RBX::Workspace>(this: v20); /*0x14103577b*/
          ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName( /*0x14103578b*/
                                                                                                    this: parent,
                                                                                                    &result,
                                                                                                    className: v22);
          std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v21, _Right: ServiceByClassName); /*0x141035796*/
          Rep = result._Rep; /*0x14103579b*/
          if ( result._Rep != nullptr /*0x1410357b6*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&result._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            Rep->_Destroy(this: Rep); /*0x1410357be*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410357ca*/
              Rep->_Delete_this(this: Rep); /*0x1410357d2*/
          }
        }
        if ( v21->_Ptr != nullptr ) /*0x1410357dc*/
        {
          v25 = (*(__int64 (__fastcall **)(__int64))(*((_QWORD *)&v21->_Ptr[2].completeness + 1) + 16LL))(a1: (__int64)&v21->_Ptr[2].completeness + 8); /*0x1410357e8*/
          v26 = *(__m128 *)(v25 + 332); /*0x1410357eb*/
          v27 = *(__m128 *)(v25 + 348); /*0x1410357f2*/
          *(_OWORD *)&v49.rotation.elt[2][2] = *(_OWORD *)(v25 + 364); /*0x141035800*/
          v28 = v49.rotation.elt[2][2]; /*0x1410357f9*/
          metrics->cameraPosition = v49.translation; /*0x141035809*/
          *(float *)&result._Rep = -v28; /*0x14103583b*/
          *(_QWORD *)&metrics->cameraDirection.x = _mm_unpacklo_ps( /*0x141035847*/
                                                     _mm_xor_ps(_mm_shuffle_ps(v26, v26, 170), (__m128)0x80000000),
                                                     _mm_xor_ps(_mm_shuffle_ps(v27, v27, 85), (__m128)0x80000000)).m128_u64[0];
          metrics->cameraDirection.z = *(float *)&result._Rep; /*0x141035853*/
        }
      }
    }
    *(_QWORD *)&metrics->spawnPosition.x = humanoid[9]._Wptr._Ptr; /*0x141035861*/
    metrics->spawnPosition.z = *(float *)&humanoid[9]._Wptr._Rep; /*0x14103586f*/
    *(_QWORD *)&metrics->spawnDirection.x = *(std::_Ref_count_base **)((char *)&humanoid[9]._Wptr._Rep + 4); /*0x14103587d*/
    metrics->spawnDirection.z = *((float *)&humanoid[9].descriptor + 1); /*0x14103588b*/
  }
  PlayerFromCharacter = RBX::Players::getPlayerFromCharacter(character: humanoid->parent); /*0x141035895*/
  v30 = PlayerFromCharacter; /*0x14103589a*/
  if ( PlayerFromCharacter != nullptr ) /*0x1410358a0*/
  {
    playerCreateTime = PlayerFromCharacter->characterSpawnTime.sec; /*0x1410358ae*/
    metrics->userId = RBX::Player::getUserID(this: PlayerFromCharacter); /*0x1410358be*/
    metrics->appearanceId = v30->characterAppearanceId; /*0x1410358c9*/
    DisplayName = RBX::Player::getDisplayName(this: v30, result: &v47); /*0x1410358d4*/
    std::string::operator=(this: &metrics->displayName, _Right: DisplayName); /*0x1410358e0*/
    if ( v47._Mypair._Myval2._Myres >= 0x10 ) /*0x1410358ed*/
    {
      Ptr = v47._Mypair._Myval2._Bx._Ptr; /*0x1410358f2*/
      if ( v47._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141035900*/
      {
        Ptr = *((char **)v47._Mypair._Myval2._Bx._Ptr - 1); /*0x141035906*/
        if ( (unsigned __int64)(v47._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141035915*/
          _invalid_parameter_noinfo_noreturn(); /*0x141035917*/
      }
      operator delete(ptr: Ptr); /*0x14103591e*/
    }
    PlatformName = RBX::Player::getPlatformName(this: v30, result: &v48); /*0x14103592a*/
    std::string::operator=(this: &metrics->platformName, _Right: PlatformName); /*0x141035936*/
    if ( v48._Mypair._Myval2._Myres >= 0x10 ) /*0x141035943*/
    {
      v34 = v48._Mypair._Myval2._Bx._Ptr; /*0x141035948*/
      if ( v48._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141035956*/
      {
        v34 = *((char **)v48._Mypair._Myval2._Bx._Ptr - 1); /*0x14103595c*/
        if ( (unsigned __int64)(v48._Mypair._Myval2._Bx._Ptr - v34 - 8) > 0x1F ) /*0x14103596b*/
          _invalid_parameter_noinfo_noreturn(); /*0x14103596d*/
      }
      operator delete(ptr: v34); /*0x141035974*/
    }
    v35 = playerCreateTime - this->sgs.userClickTime; /*0x141035981*/
    metrics->createTime = v35; /*0x141035987*/
    metrics->netCompletionTime = metrics->completionTime - v35; /*0x14103599b*/
  }
  dataModel = this->dataModel; /*0x1410359a3*/
  v37 = &dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>; /*0x1410359a7*/
  if ( dataModel == nullptr ) /*0x1410359b3*/
    v37 = nullptr; /*0x1410359b3*/
  if ( v37 != nullptr ) /*0x1410359ba*/
  {
    v38 = RBX::ServiceProvider::refByClass<RBX::Players>(this: v37)->_Ptr; /*0x1410359c1*/
    if ( v38 != nullptr ) /*0x1410359c7*/
    {
      metrics->autoSpawn = BYTE1(v38[1].onDemandPtr._Mypair._Myval2); /*0x1410359d0*/
      if ( DFFlag::PlayerConfigurer2886.value ) /*0x1410359d9*/
        metrics->numPlayers = (int)(((__int64)v38[1].propertyChangedSignal.head.px->call /*0x1410359f0*/
                                   - *(_QWORD *)&v38[1].propertyChangedSignal.head.px->rbx::intrusive_ptr_target<rbx::signals::slot_base>) >> 4);
    }
  }
  v39 = this->dataModel; /*0x1410359f7*/
  v40 = &v39->RBX::Described<RBX::DataModel,RBX::ServiceProvider>; /*0x1410359fb*/
  if ( v39 == nullptr ) /*0x141035a02*/
    v40 = nullptr; /*0x141035a02*/
  if ( v40 != nullptr ) /*0x141035a09*/
  {
    v41 = (RBX::ContentProvider *)RBX::ServiceProvider::refByClass<RBX::ContentProvider>(this: v40)->_Ptr; /*0x141035a10*/
    if ( v41 != nullptr ) /*0x141035a16*/
    {
      Myval2 = (RBX::ContentTracker *)humanoid[9].xmlId._Mypair._Myval2; /*0x141035a18*/
      if ( Myval2 != nullptr ) /*0x141035a22*/
      {
        RBX::ContentTracker::resolve(this: Myval2, cp: v41); /*0x141035a24*/
        *(_QWORD *)&v45 = this; /*0x141035a29*/
        *((_QWORD *)&v45 + 1) = metrics; /*0x141035a2e*/
        v._Mystorage._Ptrs[0] = (std::_Func_base<void,RBX::ContentTracker::Asset const &> *)std::_Func_impl_no_alloc__lambda_711c03638e4ab79657e99341538a1253__void_RBX::ContentTracker::Asset_const___::_vftable_; /*0x141035a3a*/
        *(_OWORD *)&v._Mystorage._Ptrs[1] = v45; /*0x141035a44*/
        v._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::ContentTracker::Asset const &> *)&v; /*0x141035a4e*/
        __wind /*0xf1c0000000000010*/
        {
          RBX::ContentTracker::visit(this: (RBX::ContentTracker *)humanoid[9].xmlId._Mypair._Myval2, &v); /*0x141035a5f*/
        }
        __unwind
        {
          std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&v); /*0xf1c0000000000008*/
        }
        if ( v._Mystorage._Ptrs[7] != nullptr ) /*0x141035a6d*/
        {
          p_v = &v; /*0x141035a72*/
          LOBYTE(p_v) = v._Mystorage._Ptrs[7] != (std::_Func_base<void,RBX::ContentTracker::Asset const &> *)&v; /*0x141035a7a*/
          v._Mystorage._Ptrs[7]->_Delete_this(this: v._Mystorage._Ptrs[7], a2: (bool)p_v); /*0x141035a7d*/
        }
      }
    }
  }
}

// Address: 0x141035aa0 | Name: ?configure@PlayerConfigurer@RBX@@QEAAXW4Identities@Security@2@PEAVDataModel@2@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@PEBUStartGameStatistics@@@Z
void __fastcall RBX::PlayerConfigurer::configure(
        RBX::PlayerConfigurer *this,
        RBX::Security::Identities identity,
        RBX::DataModel *dm,
        const std::string *args,
        std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > *startProgress)
{
  const std::string *v5; // r13
  RBX::DataModel *v6; // rbx
  RBX::PlayerConfigurer *v7; // r14
  double v8; // xmm0_8
  double v9; // xmm7_8
  unsigned __int8 v10; // al
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > *v11; // rsi
  double v12; // xmm1_8
  double v13; // xmm0_8
  double v14; // xmm0_8
  double userClickTime; // xmm2_8
  double v16; // xmm1_8
  const char *v17; // rbx
  const char *v18; // rdx
  rbx::signals::signal_base *p_avatarClusterStartSignal; // r12
  std::shared_ptr<RBX::GlobalBasicSettings> v20; // xmm6
  char *v21; // rax
  rbx::signals::slot_base *v22; // rdi
  rbx::signals::signal_base *v23; // rcx
  unsigned int v24; // ebx
  __int64 v25; // rcx
  rbx::signals::slot_base *p; // rcx
  __int128 v27; // xmm6
  unsigned int v28; // eax
  unsigned int parent; // ebx
  _DWORD *v30; // rax
  _DWORD *v31; // rdi
  rbx::signals::signal_base *p_avatarClusterEndSignal; // rax
  __int64 v33; // rcx
  rbx::signals::slot_base *v34; // rcx
  __int128 v35; // xmm6
  unsigned int v36; // eax
  unsigned int v37; // ebx
  _DWORD *v38; // rax
  _DWORD *v39; // rdi
  rbx::signals::signal_base *p_avatarTextureStartSignal; // rax
  __int64 v41; // rcx
  rbx::signals::slot_base *v42; // rcx
  __int128 v43; // xmm6
  unsigned int v44; // eax
  unsigned int v45; // ebx
  _DWORD *v46; // rax
  _DWORD *v47; // rdi
  rbx::signals::signal_base *p_avatarTextureEndSignal; // rax
  __int64 v49; // rcx
  rbx::signals::slot_base *v50; // rcx
  rbx::signals::signal_base *p_clientJoinFailureSignal; // r12
  __int128 v52; // xmm6
  unsigned int v53; // eax
  unsigned int v54; // ebx
  char *v55; // rax
  rbx::signals::slot_base *v56; // rdi
  __int64 v57; // rcx
  rbx::signals::slot_base *v58; // rcx
  std::string *ParamString; // rbx
  char *v60; // rcx
  char *v61; // rcx
  void *v62; // rcx
  std::string *v63; // rbx
  char *v64; // rcx
  char *v65; // rcx
  char *v66; // rcx
  char *v67; // rcx
  char *v68; // rcx
  char *v69; // rcx
  char *v70; // rcx
  char *v71; // rcx
  std::string *v72; // rbx
  char *v73; // rcx
  char *v74; // rcx
  std::string *v75; // rbx
  char *v76; // rcx
  char *v77; // rcx
  RBX::DataModel *v78; // r13
  char *v79; // rcx
  std::string *v80; // rax
  char *v81; // rcx
  std::string *p_jobId; // rcx
  unsigned __int64 Mysize; // r8
  std::string *v84; // rdx
  RBX::Security::KeyRing *Instance; // rbx
  char *v86; // rcx
  bool v87; // al
  const char *v88; // r8
  const std::string *v89; // rax
  int ParamInt; // ebx
  const std::string *v91; // rax
  char *v92; // rcx
  char *v93; // rcx
  char *v94; // rcx
  std::string *v95; // rax
  const std::string *v96; // rax
  char *v97; // rcx
  char *v98; // rcx
  RBX::InferredCrash *v99; // rax
  RBX::DataModel *dataModel; // rdi
  int v101; // ebx
  __int64 ParamInt64; // rax
  char *v103; // rcx
  char *v104; // rcx
  char *v105; // rcx
  __int64 v106; // rax
  char *v107; // rcx
  RBX::UserInputService *v108; // rax
  std::string *v109; // rax
  const char *v110; // rbx
  __int64 v111; // rdi
  std::string *v112; // rax
  char *v113; // rcx
  char *v114; // rcx
  char *v115; // rcx
  std::string *v116; // rbx
  std::string *v117; // rax
  std::string *v118; // rax
  std::string *v119; // rax
  std::string *v120; // rax
  std::unordered_map<std::string,std::string> *v121; // rax
  std::unordered_map<std::string,std::string> *v122; // rsi
  std::string *v123; // rax
  std::string *v124; // rdi
  std::string *v125; // rax
  std::string *v126; // rbx
  std::string *v127; // rax
  unsigned __int8 v128; // si
  std::_List_node<std::pair<std::string const ,std::string >,void *> *Myhead; // rdi
  std::_List_node<std::pair<std::string const ,std::string >,void *> *Next; // rbx
  std::string *v131; // rax
  std::string *v132; // rax
  const std::string *v133; // rax
  const char *v134; // r8
  std::string *v135; // rax
  std::string *v136; // rax
  std::shared_ptr<RBX::SessionizedEventIngest> *v137; // rax
  RBX::SessionizedEventIngest *v138; // rdi
  void (__fastcall *sendEventDeferred)(struct RBX::SessionizedEventIngest *, const std::string *, const std::string *, const std::string *, const std::unordered_map<std::string,std::string> *); // rbx
  std::shared_ptr<RBX::SessionAppEventsHandler> *v140; // rax
  RBX::SessionAppEventsHandler *v141; // rsi
  const std::string *v142; // rdi
  const std::string *v143; // rbx
  const std::string *v144; // rax
  rbx::signal<void __cdecl(void)> *p_closingSignal; // rcx
  rbx::signals::connection *v146; // rax
  RBX::ChangeHistoryService *v147; // rax
  RBX::Reflection::EnumDesc<enum RBX::DataModelCreatorType> *v148; // rbx
  RBX::ContentId *v149; // rax
  const char *v150; // rax
  RBX::DataModel *v151; // rdi
  RBX::DataModelCreatorType v152; // ebx
  __int64 v153; // rax
  RBX::Players *v154; // r12
  RBX::Reflection::EnumDesc<enum RBX::DataModelCreatorType> *v155; // rbx
  RBX::ContentId *v156; // rax
  const char *v157; // rax
  rbx::signals::connection *v158; // rax
  rbx::signals::connection *v159; // rax
  const std::string *v160; // rax
  RBX::Analytics::TelemetryInformation *v161; // rbx
  RBX::Graphics::ProfilerAdorn::Item *v162; // rcx
  std::string *v163; // rax
  rbx::signals::connection *v164; // rax
  rbx::signals::connection *v165; // rax
  RBX::Reflection::Variant *v166; // rax
  RBX::Reflection::Variant *v167; // rax
  RBX::Reflection::Variant *v168; // rax
  std::string *v169; // rbx
  RBX::Reflection::Variant *v170; // rax
  std::string *v171; // rax
  std::string *v172; // rbx
  RBX::Reflection::Variant *v173; // rax
  unsigned __int64 v174; // rbx
  std::string *v175; // rax
  std::string *v176; // rbx
  RBX::Reflection::Variant *v177; // rax
  const std::shared_ptr<lm::StageResults> *v178; // rax
  RBX::GlobalBasicSettings *v179; // rbx
  RBX::Reflection::Variant *v180; // rax
  RBX::ContentId *v181; // rax
  const char *v182; // rax
  __int64 v183; // rdx
  int v184; // ebx
  int v185; // ebx
  RBX::Reflection::Variant *v186; // rax
  std::string *GameLocaleIdFromParams; // rax
  RBX::Reflection::Variant *v188; // rax
  RBX::Reflection::Variant *v189; // rax
  RBX::Graphics::ProfilerAdorn::Item *v190; // rcx
  RBX::DataModel *v191; // rax
  const RBX::ServiceProvider *v192; // rcx
  RBX::LocalizationService *v193; // rbx
  std::string *v194; // rax
  std::string *v195; // rdi
  const std::string *v196; // rax
  std::string *v197; // rdi
  RBX::Reflection::Variant *v198; // rax
  std::string *v199; // rax
  std::string *v200; // rdi
  RBX::Reflection::Variant *v201; // rax
  std::string *v202; // rax
  const RBX::ServiceProvider *v203; // rcx
  RBX::VRService *v204; // rax
  RBX::VRService *v205; // rbx
  std::string *VRDeviceName; // rdi
  RBX::Reflection::Variant *v207; // rax
  std::string *v208; // rax
  RBX::Reflection::Variant *v209; // rax
  std::string *v210; // rax
  std::string *v211; // rbx
  RBX::Reflection::Variant *v212; // rax
  RBX::Reflection::Variant *v213; // rax
  RBX::Reflection::Variant *v214; // rax
  std::string *UserAgent; // rbx
  RBX::Reflection::Variant *v216; // rax
  std::string *v217; // rbx
  RBX::Reflection::Variant *v218; // rax
  std::string *RobloxVersionSafe; // rax
  std::string *v220; // rbx
  RBX::Reflection::Variant *v221; // rax
  std::string *v222; // rbx
  RBX::Reflection::Variant *v223; // rax
  RBX::Graphics::ProfilerAdorn::Item *v224; // rcx
  bool isParamExist; // bl
  std::string *v226; // rax
  std::string *v227; // rbx
  RBX::Reflection::Variant *v228; // rax
  std::string *v229; // rax
  std::string *v230; // rbx
  RBX::Reflection::Variant *v231; // rax
  std::string *v232; // rax
  std::string *v233; // rbx
  RBX::Reflection::Variant *v234; // rax
  bool v235; // bl
  std::string *v236; // rax
  std::string *v237; // rbx
  RBX::Reflection::Variant *v238; // rax
  RBX::Graphics::ProfilerAdorn::Item *v239; // rcx
  bool v240; // bl
  std::string *v241; // rax
  std::string *v242; // rbx
  RBX::Reflection::Variant *v243; // rax
  RBX::Network::Client *v244; // r13
  RBX::Reflection::Variant *v245; // rax
  std::string *v246; // rax
  std::string *v247; // rbx
  RBX::Reflection::Variant *v248; // rax
  RBX::Reflection::Variant *v249; // rax
  const rtc::webrtc_checks_impl::ToStringVal *RawJoinData; // rax
  rtc::webrtc_checks_impl::ToStringVal *v251; // rax
  RBX::BinaryString *v252; // rbx
  RBX::Reflection::Variant *v253; // rax
  rtc::webrtc_checks_impl::ToStringVal *v254; // rax
  RBX::BinaryString *v255; // rax
  RBX::BinaryString *v256; // rbx
  RBX::Reflection::Variant *v257; // rax
  RBX::Reflection::Variant *v258; // rax
  RBX::Reflection::Variant *v259; // rax
  std::string *v260; // rax
  RBX::Reflection::Variant *Myfirst; // rdi
  RBX::Reflection::Variant *Mylast; // r12
  std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<Luau::Module>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<Luau::Module> > >,0> > *v263; // rbx
  std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<Luau::Module>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<Luau::Module> > >,0> > *v264; // rbx
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v265; // rdx
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > *v266; // rbx
  int v267; // esi
  std::string *v268; // rax
  RBX::Network::Client::ServerConnection *v269; // rax
  bool ParamBool; // di
  std::string *v271; // rax
  const char *v272; // rax
  const char *v273; // rcx
  int v274; // ebx
  const StartGameStatistics *v275; // rax
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v276; // rax
  int v277; // r12d
  int v278; // esi
  std::string *v279; // rax
  std::string *v280; // rbx
  __int64 v281; // rax
  bool v282; // bl
  long double v283; // xmm6_8
  const char *v284; // rax
  RBX::Visit *v285; // rbx
  std::string *v286; // rax
  RBX::DataModel *v287; // rax
  const RBX::ServiceProvider *v288; // rcx
  RBX::RunService *v289; // rax
  RBX::InferredCrash *v290; // rbx
  __int64 v291; // rax
  RBX::EngineStabilityStats *v292; // rbx
  __int64 v293; // rax
  const char *v294; // rax
  _BYTE v295[32]; // [rsp+0h] [rbp-2008h] BYREF
  bool sync[8]; // [rsp+20h] [rbp-1FE8h]
  int v297; // [rsp+70h] [rbp-1F98h]
  __int128 client; // [rsp+78h] [rbp-1F90h]
  __int64 rhs[2]; // [rsp+88h] [rbp-1F80h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v300; // [rsp+98h] [rbp-1F70h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v301; // [rsp+9Ch] [rbp-1F6Ch] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v302; // [rsp+A0h] [rbp-1F68h] BYREF
  rbx::signals::connection v303; // [rsp+A8h] [rbp-1F60h] BYREF
  rbx::signals::connection other; // [rsp+B0h] [rbp-1F58h] BYREF
  rbx::signals::connection con; // [rsp+B8h] [rbp-1F50h] BYREF
  rbx::signals::connection v306; // [rsp+C0h] [rbp-1F48h] BYREF
  rbx::signals::connection v307; // [rsp+C8h] [rbp-1F40h] BYREF
  __int64 universeId; // [rsp+D0h] [rbp-1F38h] BYREF
  std::_List_const_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > > portIter; // [rsp+D8h] [rbp-1F30h] BYREF
  std::unordered_map<std::string,RBX::Reflection::Variant> playerInfoTable; // [rsp+E0h] [rbp-1F28h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v311; // [rsp+120h] [rbp-1EE8h] BYREF
  RBX::DataModelCreatorType creatorType; // [rsp+124h] [rbp-1EE4h] BYREF
  RBX::Players::ChatOption chatOption; // [rsp+128h] [rbp-1EE0h] BYREF
  RBX::Players *players; // [rsp+130h] [rbp-1ED8h]
  std::shared_ptr<RBX::GlobalBasicSettings> basicSettings; // [rsp+138h] [rbp-1ED0h] BYREF
  unsigned __int64 clientSettingsGuidName_temp; // [rsp+148h] [rbp-1EC0h]
  __int64 v317; // [rsp+150h] [rbp-1EB8h]
  std::string v318; // [rsp+158h] [rbp-1EB0h] BYREF
  std::string v319; // [rsp+178h] [rbp-1E90h] BYREF
  std::string v320; // [rsp+198h] [rbp-1E70h] BYREF
  std::string v321; // [rsp+1B8h] [rbp-1E50h] BYREF
  std::string v322; // [rsp+1D8h] [rbp-1E30h] BYREF
  std::string v323; // [rsp+1F8h] [rbp-1E10h] BYREF
  std::string v324; // [rsp+218h] [rbp-1DF0h] BYREF
  std::string v325; // [rsp+238h] [rbp-1DD0h] BYREF
  std::string v326; // [rsp+258h] [rbp-1DB0h] BYREF
  std::string v327; // [rsp+278h] [rbp-1D90h] BYREF
  std::string name; // [rsp+298h] [rbp-1D70h] BYREF
  std::string v329; // [rsp+2B8h] [rbp-1D50h] BYREF
  std::string v330; // [rsp+2D8h] [rbp-1D30h] BYREF
  std::string v331; // [rsp+2F8h] [rbp-1D10h] BYREF
  std::string status; // [rsp+318h] [rbp-1CF0h] BYREF
  std::string v333; // [rsp+338h] [rbp-1CD0h] BYREF
  std::string v334; // [rsp+358h] [rbp-1CB0h] BYREF
  std::string v335; // [rsp+378h] [rbp-1C90h] BYREF
  std::string v336; // [rsp+398h] [rbp-1C70h] BYREF
  std::string v337; // [rsp+3B8h] [rbp-1C50h] BYREF
  std::string v338; // [rsp+3D8h] [rbp-1C30h] BYREF
  std::string v339; // [rsp+3F8h] [rbp-1C10h] BYREF
  std::string v340; // [rsp+418h] [rbp-1BF0h] BYREF
  _QWORD key[2]; // [rsp+438h] [rbp-1BD0h] BYREF
  __int64 key_16; // [rsp+448h] [rbp-1BC0h]
  unsigned __int64 key_24; // [rsp+450h] [rbp-1BB8h]
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > oneServerConnection; // [rsp+458h] [rbp-1BB0h] BYREF
  std::shared_ptr<std::vector<RBX::Reflection::Variant> const > serverConnectionsArray; // [rsp+470h] [rbp-1B98h] BYREF
  std::string v346; // [rsp+480h] [rbp-1B88h] BYREF
  RBX::AvatarProfiler::InitParams params; // [rsp+4A0h] [rbp-1B68h] BYREF
  __int64 value; // [rsp+580h] [rbp-1A88h] BYREF
  double v349; // [rsp+588h] [rbp-1A80h] BYREF
  __int64 v350; // [rsp+590h] [rbp-1A78h] BYREF
  __int64 v351; // [rsp+598h] [rbp-1A70h] BYREF
  __int64 v352; // [rsp+5A0h] [rbp-1A68h] BYREF
  std::vector<RBX::Network::Client::ServerConnection> serverConnections; // [rsp+5A8h] [rbp-1A60h] BYREF
  rbx::signals::connection v354; // [rsp+5C0h] [rbp-1A48h] BYREF
  rbx::signals::connection v355; // [rsp+5C8h] [rbp-1A40h] BYREF
  rbx::signals::connection v356; // [rsp+5D0h] [rbp-1A38h] BYREF
  rbx::signals::connection v357; // [rsp+5D8h] [rbp-1A30h] BYREF
  __int64 userId; // [rsp+5E0h] [rbp-1A28h] BYREF
  __int64 v359; // [rsp+5E8h] [rbp-1A20h] BYREF
  rbx::signals::connection v360; // [rsp+5F0h] [rbp-1A18h] BYREF
  std::string v361; // [rsp+5F8h] [rbp-1A10h] BYREF
  RBX::Network::Rupp::TokenTlv::Token token; // [rsp+618h] [rbp-19F0h] BYREF
  std::string analyticsSessionId; // [rsp+630h] [rbp-19D8h] BYREF
  std::string localeId; // [rsp+650h] [rbp-19B8h] BYREF
  std::vector<RBX::Network::Client::ServerConnection> udmuxEndpoint; // [rsp+670h] [rbp-1998h] BYREF
  std::string reportStr; // [rsp+688h] [rbp-1980h] BYREF
  std::string tokenValue; // [rsp+6A8h] [rbp-1960h] BYREF
  std::string v368; // [rsp+6C8h] [rbp-1940h] BYREF
  std::string v369; // [rsp+6E8h] [rbp-1920h] BYREF
  std::string countryCodeFromArgs; // [rsp+708h] [rbp-1900h] BYREF
  std::string v371; // [rsp+728h] [rbp-18E0h] BYREF
  std::string v372; // [rsp+748h] [rbp-18C0h] BYREF
  std::string v373; // [rsp+768h] [rbp-18A0h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > sharedTable; // [rsp+788h] [rbp-1880h] BYREF
  std::initializer_list<std::pair<std::string const ,std::string > > v375; // [rsp+7A0h] [rbp-1868h] BYREF
  std::initializer_list<std::pair<std::string const ,std::string > > v376; // [rsp+7B0h] [rbp-1858h] BYREF
  std::string v377; // [rsp+7C0h] [rbp-1848h] BYREF
  std::string result; // [rsp+7E0h] [rbp-1828h] BYREF
  std::string v379; // [rsp+800h] [rbp-1808h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v380; // [rsp+820h] [rbp-17E8h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v381; // [rsp+858h] [rbp-17B0h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::PlayerConfigurer,std::shared_ptr<RBX::Player> >,boost::_bi::list2<boost::_bi::value<RBX::PlayerConfigurer *>,boost::arg<1> > > v382; // [rsp+890h] [rbp-1778h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::PlayerConfigurer,std::string const &,std::shared_ptr<RBX::Instance> const &>,boost::_bi::list3<boost::_bi::value<RBX::PlayerConfigurer *>,boost::arg<1>,boost::arg<2> > > v383; // [rsp+8A8h] [rbp-1760h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::PlayerConfigurer>,boost::_bi::list1<boost::_bi::value<RBX::PlayerConfigurer *> > > function; // [rsp+8C0h] [rbp-1748h] BYREF
  RBX::Security::Identity v385; // [rsp+8E0h] [rbp-1728h] BYREF
  __int128 v386; // [rsp+900h] [rbp-1708h]
  RBX::PlayerConfigurer *v387; // [rsp+910h] [rbp-16F8h]
  __int128 v388; // [rsp+918h] [rbp-16F0h]
  RBX::PlayerConfigurer *v389; // [rsp+928h] [rbp-16E0h]
  std::shared_ptr<RBX::SessionizedEventIngest> v390; // [rsp+930h] [rbp-16D8h] BYREF
  std::string tokenValue64; // [rsp+940h] [rbp-16C8h] BYREF
  std::string machineAddress; // [rsp+960h] [rbp-16A8h] BYREF
  std::shared_ptr<lm::StageResults> v393; // [rsp+980h] [rbp-1688h] BYREF
  __int128 v394; // [rsp+990h] [rbp-1678h]
  RBX::PlayerConfigurer *v395; // [rsp+9A0h] [rbp-1668h]
  std::shared_ptr<RBX::SessionAppEventsHandler> v396; // [rsp+9A8h] [rbp-1660h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::PlayerConfigurer,std::string const &,int,std::string const &>,boost::_bi::list4<boost::_bi::value<RBX::PlayerConfigurer *>,boost::arg<1>,boost::arg<2>,boost::arg<3> > > v397; // [rsp+9B8h] [rbp-1650h] BYREF
  __int128 v398; // [rsp+9D0h] [rbp-1638h]
  RBX::PlayerConfigurer *v399; // [rsp+9E0h] [rbp-1628h]
  std::string vrDevice; // [rsp+9E8h] [rbp-1620h] BYREF
  std::string v401; // [rsp+A08h] [rbp-1600h] BYREF
  std::string v402; // [rsp+A28h] [rbp-15E0h] BYREF
  std::string v403; // [rsp+A48h] [rbp-15C0h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v404; // [rsp+A68h] [rbp-15A0h] BYREF
  _OSVERSIONINFOEXA osvi; // [rsp+AB0h] [rbp-1558h] BYREF
  std::string v406; // [rsp+B50h] [rbp-14B8h] BYREF
  std::string v407; // [rsp+B70h] [rbp-1498h] BYREF
  std::string v408; // [rsp+B90h] [rbp-1478h] BYREF
  std::string v409; // [rsp+BB0h] [rbp-1458h] BYREF
  std::string v410; // [rsp+BD0h] [rbp-1438h] BYREF
  std::string v411; // [rsp+BF0h] [rbp-1418h] BYREF
  std::string v412; // [rsp+C10h] [rbp-13F8h] BYREF
  std::string v413; // [rsp+C30h] [rbp-13D8h] BYREF
  std::string _Keyval; // [rsp+C50h] [rbp-13B8h] BYREF
  std::string v415; // [rsp+C70h] [rbp-1398h] BYREF
  std::string v416; // [rsp+C90h] [rbp-1378h] BYREF
  std::string v417; // [rsp+CB0h] [rbp-1358h] BYREF
  std::string v418; // [rsp+CD0h] [rbp-1338h] BYREF
  std::string v419; // [rsp+CF0h] [rbp-1318h] BYREF
  std::string v420; // [rsp+D10h] [rbp-12F8h] BYREF
  std::string v421; // [rsp+D30h] [rbp-12D8h] BYREF
  std::string counterName; // [rsp+D50h] [rbp-12B8h] BYREF
  std::string v423; // [rsp+D70h] [rbp-1298h] BYREF
  std::string v424; // [rsp+D90h] [rbp-1278h] BYREF
  std::string v425; // [rsp+DB0h] [rbp-1258h] BYREF
  std::string v426; // [rsp+DD0h] [rbp-1238h] BYREF
  std::string osVersion; // [rsp+DF0h] [rbp-1218h] BYREF
  std::string v428; // [rsp+E10h] [rbp-11F8h] BYREF
  std::string v429; // [rsp+E30h] [rbp-11D8h] BYREF
  std::string v430; // [rsp+E50h] [rbp-11B8h] BYREF
  std::string v431; // [rsp+E70h] [rbp-1198h] BYREF
  std::string v432; // [rsp+E90h] [rbp-1178h] BYREF
  std::string v433; // [rsp+EB0h] [rbp-1158h] BYREF
  std::string v434; // [rsp+ED0h] [rbp-1138h] BYREF
  std::string v435; // [rsp+EF0h] [rbp-1118h] BYREF
  std::string v436; // [rsp+F10h] [rbp-10F8h] BYREF
  std::string v437; // [rsp+F30h] [rbp-10D8h] BYREF
  std::string v438; // [rsp+F50h] [rbp-10B8h] BYREF
  std::string v439; // [rsp+F70h] [rbp-1098h] BYREF
  std::string v440; // [rsp+F90h] [rbp-1078h] BYREF
  std::string v441; // [rsp+FB0h] [rbp-1058h] BYREF
  std::string v442; // [rsp+FD0h] [rbp-1038h] BYREF
  std::string v443; // [rsp+FF0h] [rbp-1018h] BYREF
  std::string v444; // [rsp+1010h] [rbp-FF8h] BYREF
  std::string v445; // [rsp+1030h] [rbp-FD8h] BYREF
  std::string v446; // [rsp+1050h] [rbp-FB8h] BYREF
  std::string v447; // [rsp+1070h] [rbp-F98h] BYREF
  std::string v448; // [rsp+1090h] [rbp-F78h] BYREF
  std::string v449; // [rsp+10B0h] [rbp-F58h] BYREF
  std::string v450; // [rsp+10D0h] [rbp-F38h] BYREF
  std::string v451; // [rsp+10F0h] [rbp-F18h] BYREF
  std::string v452; // [rsp+1110h] [rbp-EF8h] BYREF
  std::string v453; // [rsp+1130h] [rbp-ED8h] BYREF
  std::string v454; // [rsp+1150h] [rbp-EB8h] BYREF
  std::string v455; // [rsp+1170h] [rbp-E98h] BYREF
  std::string v456; // [rsp+1190h] [rbp-E78h] BYREF
  std::string v457; // [rsp+11B0h] [rbp-E58h] BYREF
  std::string v458; // [rsp+11D0h] [rbp-E38h] BYREF
  std::string v459; // [rsp+11F0h] [rbp-E18h] BYREF
  std::string v460; // [rsp+1210h] [rbp-DF8h] BYREF
  std::string v461; // [rsp+1230h] [rbp-DD8h] BYREF
  std::string v462; // [rsp+1250h] [rbp-DB8h] BYREF
  std::string v463; // [rsp+1270h] [rbp-D98h] BYREF
  std::string v464; // [rsp+1290h] [rbp-D78h] BYREF
  std::string v465; // [rsp+12B0h] [rbp-D58h] BYREF
  std::string v466; // [rsp+12D0h] [rbp-D38h] BYREF
  std::string v467; // [rsp+12F0h] [rbp-D18h] BYREF
  std::string reportSequence; // [rsp+1310h] [rbp-CF8h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v469; // [rsp+1330h] [rbp-CD8h] BYREF
  std::string v470; // [rsp+1370h] [rbp-C98h] BYREF
  std::string v471; // [rsp+1390h] [rbp-C78h] BYREF
  std::string v472; // [rsp+13B0h] [rbp-C58h] BYREF
  std::string v473; // [rsp+13D0h] [rbp-C38h] BYREF
  std::string v474; // [rsp+13F0h] [rbp-C18h] BYREF
  std::string v475; // [rsp+1410h] [rbp-BF8h] BYREF
  std::string pubKeyData; // [rsp+1430h] [rbp-BD8h] BYREF
  std::string v477; // [rsp+1450h] [rbp-BB8h] BYREF
  std::string v478; // [rsp+1470h] [rbp-B98h] BYREF
  std::string v479; // [rsp+1490h] [rbp-B78h] BYREF
  std::string v480; // [rsp+14B0h] [rbp-B58h] BYREF
  std::string v481; // [rsp+14D0h] [rbp-B38h] BYREF
  std::string v482; // [rsp+14F0h] [rbp-B18h] BYREF
  std::string v483; // [rsp+1510h] [rbp-AF8h] BYREF
  RBX::Security::Impersonator impersonate; // [rsp+1530h] [rbp-AD8h] BYREF
  std::unordered_map<std::string,std::string> _Right; // [rsp+1550h] [rbp-AB8h] BYREF
  std::string v486; // [rsp+1590h] [rbp-A78h] BYREF
  std::string v487; // [rsp+15B0h] [rbp-A58h] BYREF
  std::string v488; // [rsp+15D0h] [rbp-A38h] BYREF
  std::string v489; // [rsp+15F0h] [rbp-A18h] BYREF
  std::string v490; // [rsp+1610h] [rbp-9F8h] BYREF
  std::string v491; // [rsp+1630h] [rbp-9D8h] BYREF
  std::string v492; // [rsp+1650h] [rbp-9B8h] BYREF
  std::string v493; // [rsp+1670h] [rbp-998h] BYREF
  std::string v494; // [rsp+1690h] [rbp-978h] BYREF
  std::string v495; // [rsp+16B0h] [rbp-958h] BYREF
  std::string v496; // [rsp+16D0h] [rbp-938h] BYREF
  std::string v497; // [rsp+16F0h] [rbp-918h] BYREF
  std::string v498; // [rsp+1710h] [rbp-8F8h] BYREF
  std::string v499; // [rsp+1730h] [rbp-8D8h] BYREF
  std::string v500; // [rsp+1750h] [rbp-8B8h] BYREF
  std::string v501; // [rsp+1770h] [rbp-898h] BYREF
  std::string v502; // [rsp+1790h] [rbp-878h] BYREF
  std::string v503; // [rsp+17B0h] [rbp-858h] BYREF
  std::string v504; // [rsp+17D0h] [rbp-838h] BYREF
  std::string v505; // [rsp+17F0h] [rbp-818h] BYREF
  std::string v506; // [rsp+1810h] [rbp-7F8h] BYREF
  std::string v507; // [rsp+1830h] [rbp-7D8h] BYREF
  std::string v508; // [rsp+1850h] [rbp-7B8h] BYREF
  std::string v509; // [rsp+1870h] [rbp-798h] BYREF
  std::string v510; // [rsp+1890h] [rbp-778h] BYREF
  std::string v511; // [rsp+18B0h] [rbp-758h] BYREF
  std::string v512; // [rsp+18D0h] [rbp-738h] BYREF
  std::string v513; // [rsp+18F0h] [rbp-718h] BYREF
  std::string v514; // [rsp+1910h] [rbp-6F8h] BYREF
  std::string v515; // [rsp+1930h] [rbp-6D8h] BYREF
  std::string v516; // [rsp+1950h] [rbp-6B8h] BYREF
  std::string v517; // [rsp+1970h] [rbp-698h] BYREF
  std::string v518; // [rsp+1990h] [rbp-678h] BYREF
  std::string v519; // [rsp+19B0h] [rbp-658h] BYREF
  std::string v520; // [rsp+19D0h] [rbp-638h] BYREF
  std::string v521; // [rsp+19F0h] [rbp-618h] BYREF
  std::string v522; // [rsp+1A10h] [rbp-5F8h] BYREF
  std::string v523; // [rsp+1A30h] [rbp-5D8h] BYREF
  std::string v524; // [rsp+1A50h] [rbp-5B8h] BYREF
  std::string v525; // [rsp+1A70h] [rbp-598h] BYREF
  std::string v526; // [rsp+1A90h] [rbp-578h] BYREF
  RBX::StringView v527; // [rsp+1AB0h] [rbp-558h] BYREF
  std::string v528; // [rsp+1AC0h] [rbp-548h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v529; // [rsp+1AE0h] [rbp-528h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v530; // [rsp+1B00h] [rbp-508h] BYREF
  std::string v531; // [rsp+1B40h] [rbp-4C8h] BYREF
  std::string v532; // [rsp+1B60h] [rbp-4A8h] BYREF
  std::string v533; // [rsp+1B80h] [rbp-488h] BYREF
  std::string v534; // [rsp+1BA0h] [rbp-468h] BYREF
  std::string v535; // [rsp+1BC0h] [rbp-448h] BYREF
  std::string countryRegionCode; // [rsp+1BE0h] [rbp-428h] BYREF
  std::string v537; // [rsp+1C00h] [rbp-408h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v538; // [rsp+1C20h] [rbp-3E8h] BYREF
  std::pair<std::string const ,std::string > item; // [rsp+1C40h] [rbp-3C8h] BYREF
  std::unordered_map<std::string,std::string> report; // [rsp+1C80h] [rbp-388h] BYREF
  std::string v541; // [rsp+1CC0h] [rbp-348h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v542; // [rsp+1CE0h] [rbp-328h] BYREF
  std::pair<std::string const ,std::string > v543; // [rsp+1D20h] [rbp-2E8h] BYREF
  std::pair<std::string const ,std::string > v544; // [rsp+1D60h] [rbp-2A8h] BYREF
  std::string ptr; // [rsp+1DA0h] [rbp-268h] BYREF
  RBX::BinaryString v546; // [rsp+1DC0h] [rbp-248h] BYREF
  std::pair<std::string const ,std::string > v547; // [rsp+1DE0h] [rbp-228h] BYREF
  std::pair<std::string const ,std::string > v548; // [rsp+1E20h] [rbp-1E8h] BYREF
  std::pair<std::string const ,std::string > v549; // [rsp+1E60h] [rbp-1A8h] BYREF
  std::pair<std::string const ,std::string > v550; // [rsp+1EA0h] [rbp-168h] BYREF
  std::pair<std::string const ,std::string > v551; // [rsp+1EE0h] [rbp-128h] BYREF
  std::unordered_map<std::string,std::string> v552; // [rsp+1F20h] [rbp-E8h] BYREF
  RBX::Network::Client::ServerConnection v553; // [rsp+1F60h] [rbp-A8h] BYREF
  RBX::DataModel *v556; // [rsp+2020h] [rbp+18h] BYREF
  unsigned __int64 clientOsVersion_temp; // [rsp+2028h] [rbp+20h] BYREF

  clientOsVersion_temp = (unsigned __int64)args; /*0x141035aa0*/
  v556 = dm; /*0x141035aa5*/
  v5 = args; /*0x141035adb*/
  v6 = dm; /*0x141035ade*/
  v7 = this; /*0x141035ae1*/
  v297 = 0; /*0x141035ae7*/
  v8 = RBX::Time::nowFastSec(); /*0x141035aec*/
  v9 = v8; /*0x141035af1*/
  v7->sgs.avatarConfigureTime = v8; /*0x141035af4*/
  v7->sgs.userClickTime = v8; /*0x141035afd*/
  if ( !FFlag::PlayerConfigurer2759.value ) /*0x141035b0a*/
    goto LABEL_7; /*0x141035b0a*/
  v10 = FLog::AvatarJoinMetrics; /*0x141035b10*/
  if ( FLog::AvatarJoinMetrics != 0 ) /*0x141035b19*/
  {
    FLog::FastLogFormatted(level: FLog::AvatarJoinMetrics, message: "[FLog::AvatarJoinMetrics] userClickTime = %g", v8); /*0x141035b30*/
    v10 = FLog::AvatarJoinMetrics; /*0x141035b35*/
    if ( FLog::AvatarJoinMetrics != 0 ) /*0x141035b3e*/
    {
      FLog::FastLogFormatted( /*0x141035b57*/
        level: FLog::AvatarJoinMetrics,
        message: "[FLog::AvatarJoinMetrics] FF DebugPlayerConfigurerOthersMetrics = %d",
        FFlag::DebugPlayerConfigurerOthersMetrics.value);
      v10 = FLog::AvatarJoinMetrics; /*0x141035b5c*/
      if ( FLog::AvatarJoinMetrics != 0 ) /*0x141035b65*/
      {
        FLog::FastLogFormatted( /*0x141035b7e*/
          level: FLog::AvatarJoinMetrics,
          message: "[FLog::AvatarJoinMetrics] FF PlayerConfigurer2759 = %d",
          FFlag::PlayerConfigurer2759.value);
        v10 = FLog::AvatarJoinMetrics; /*0x141035b83*/
        if ( FLog::AvatarJoinMetrics != 0 ) /*0x141035b8c*/
        {
          FLog::FastLogFormatted( /*0x141035b9a*/
            level: FLog::AvatarJoinMetrics,
            message: "[FLog::AvatarJoinMetrics] FF AvatarJoinMetrics = %d",
            FLog::AvatarJoinMetrics);
LABEL_7:
          v10 = FLog::AvatarJoinMetrics; /*0x141035b9f*/
        }
      }
    }
  }
  v11 = startProgress; /*0x141035ba6*/
  if ( startProgress == nullptr ) /*0x141035bb1*/
    goto LABEL_31; /*0x141035bb1*/
  if ( *(double *)&startProgress->_Ptr == 0.0 ) /*0x141035bc4*/
  {
    v12 = *(double *)&startProgress[1]._Ptr; /*0x141035bc6*/
    if ( v12 == 0.0 ) /*0x141035bd1*/
      goto LABEL_14; /*0x141035bd1*/
    v7->sgs.userClickTime = v12; /*0x141035bd3*/
  }
  else
  {
    *(_QWORD *)&v7->sgs.userClickTime = startProgress->_Ptr; /*0x141035bdb*/
  }
  v10 = FLog::AvatarJoinMetrics; /*0x141035be1*/
LABEL_14:
  if ( DFFlag::PlayerConfigurer2886.value && v10 != 0 ) /*0x141035bf3*/
    FLog::FastLogFormatted( /*0x141035c0a*/
      level: v10,
      message: "[FLog::AvatarJoinMetrics] startProgress/userClickTime = %g",
      v7->sgs.userClickTime);
  v13 = *(double *)&v11->_Rep; /*0x141035c0f*/
  if ( v13 != 0.0 ) /*0x141035c1a*/
    v7->sgs.videoAdFinishedTime = v13 - v7->sgs.userClickTime; /*0x141035c22*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141035c3e*/
    this: &v7->analyticsPoints,
    name: "VideoAdShown",
    value: (bool)v11[16]._Ptr);
  v7->sgs.videoAdShown = (bool)v11[16]._Ptr; /*0x141035c4a*/
  v14 = *(double *)&v11[1]._Ptr; /*0x141035c51*/
  if ( v14 != 0.0 ) /*0x141035c5c*/
    v7->sgs.startGameTime = v14 - v7->sgs.userClickTime; /*0x141035c64*/
  userClickTime = v7->sgs.userClickTime; /*0x141035c6d*/
  v7->sgs.placelauncherStartTime = *(double *)&v11[1]._Rep - userClickTime; /*0x141035c7c*/
  v16 = *(double *)&v11[2]._Ptr; /*0x141035c85*/
  if ( v16 != 0.0 ) /*0x141035c90*/
    v7->sgs.fetchedJoinScriptTime = v16 - userClickTime; /*0x141035c96*/
  if ( v11[9]._Ptr != nullptr ) /*0x141035ca6*/
  {
    v17 = (const char *)&v11[8]; /*0x141035ca8*/
    if ( &v7->sgs.joinRequestType != (std::string *)&v11[8] ) /*0x141035cb9*/
    {
      v18 = (const char *)&v11[8]; /*0x141035cbb*/
      if ( v11[9]._Rep >= (std::_Ref_count_base *)0x10 ) /*0x141035cc3*/
        v18 = *(const char **)v17; /*0x141035cc5*/
      std::string::assign(this: &v7->sgs.joinRequestType, _Ptr: v18, _Count: (const unsigned __int64)v11[9]._Ptr); /*0x141035ccc*/
    }
    if ( v11[9]._Rep >= (std::_Ref_count_base *)0x10 ) /*0x141035cd6*/
      v17 = *(const char **)v17; /*0x141035cd8*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: &v7->analyticsPoints, name: "JoinRequestType", value: v17); /*0x141035cec*/
    v6 = v556; /*0x141035cf1*/
  }
LABEL_31:
  v7->sgs.playerConfigureTime = v9 - v7->sgs.userClickTime; /*0x141035cf9*/
  if ( DFFlag::ReportFailuresInClientJoinAll2.value ) /*0x141035d12*/
    v7->sgs.joinPhase = JoinPhase_PlayerConfigured; /*0x141035d14*/
  if ( FFlag::LogClientLoadToAvatarLoad.value && FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x141035d31*/
  {
    FLog::FastLog( /*0x141035d3d*/
      level: FLog::LogStepTimeAndNetworkUsage,
      message: "[FLog::LogStepTimeAndNetworkUsage] Step Time, HTTP B/W, RakNet B/W, Overall B/W",
      arg0: nullptr);
    if ( FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x141035d4b*/
    {
      FLog::FastLog( /*0x141035d57*/
        level: FLog::LogStepTimeAndNetworkUsage,
        message: "[FLog::LogStepTimeAndNetworkUsage] Player Configured",
        arg0: nullptr);
      if ( FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x141035d65*/
        FLog::FastLogFormatted( /*0x141035d70*/
          level: FLog::LogStepTimeAndNetworkUsage,
          message: "[FLog::LogStepTimeAndNetworkUsage] 0, 0, 0, 0");
    }
  }
  v7->dataModel = v6; /*0x141035d75*/
  if ( FFlag::JoinTime_AvatarFastClusterSignal.value && FFlag::JoinTime_AvatarTextureCompositorSignal.value ) /*0x141035d8d*/
  {
    p_avatarClusterStartSignal = &v6->avatarClusterStartSignal; /*0x141035d93*/
    basicSettings._Ptr = (RBX::GlobalBasicSettings *)RBX::PlayerConfigurer::onAvatarClusterStarted; /*0x141035da1*/
    LODWORD(basicSettings._Rep) = 0; /*0x141035da9*/
    v20 = basicSettings; /*0x141035db1*/
    *(std::shared_ptr<RBX::GlobalBasicSettings> *)&v380.x = basicSettings; /*0x141035db9*/
    *(_QWORD *)&v380.color = v7; /*0x141035dc1*/
    __wind /*0xf1c00000000016fc*/
    {
      v24 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x141035dd4*/
      LODWORD(startProgress) = v24; /*0x141035dd6*/
      __wind /*0xf1c00000000016d8*/
      {
        v21 = (char *)operator new(size: 0x40u); /*0x141035de2*/
        v22 = (rbx::signals::slot_base *)v21; /*0x141035de7*/
        portIter._Ptr = (std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *)v21; /*0x141035dea*/
        if ( v21 != nullptr ) /*0x141035df5*/
        {
          *(_DWORD *)v21 = 0; /*0x141035df7*/
          *((_DWORD *)v21 + 1) = 1; /*0x141035dfa*/
          *((_QWORD *)v21 + 1) = rbx::signals::slot_with_functor<boost::_bi::bind_t<void,boost::_mfi::mf2<void,PropertiesWidget::InstanceSelectionEditor,RBX::Instance *,bool &>,boost::_bi::list3<boost::_bi::value<PropertiesWidget::InstanceSelectionEditor *>,boost::arg<1>,boost::arg<2>>>,RBX::Instance *,bool &>::do_call; /*0x141035e08*/
          *((_QWORD *)v21 + 2) = RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x141035e13*/
          *((_QWORD *)v21 + 3) = 0; /*0x141035e17*/
          v23 = &v556->avatarClusterStartSignal; /*0x141035e23*/
          *((_QWORD *)v21 + 4) = &v556->avatarClusterStartSignal; /*0x141035e2a*/
          *(std::shared_ptr<RBX::GlobalBasicSettings> *)(v21 + 40) = v20; /*0x141035e2e*/
          *((_QWORD *)v21 + 7) = *(_QWORD *)&v380.color; /*0x141035e3b*/
          rbx::signals::signal_base::insert(this: v23, item: (rbx::signals::slot_base *)v21); /*0x141035e43*/
          other.weak_slot.p_ = v22; /*0x141035e48*/
          _InterlockedIncrement(&v22->weak._Storage._Value); /*0x141035e55*/
          v24 = (unsigned int)startProgress; /*0x141035e59*/
        }
        else
        {
          rbx::signals::signal_base::insert(this: p_avatarClusterStartSignal, item: nullptr); /*0x141035e67*/
          other.weak_slot.p_ = nullptr; /*0x141035e6c*/
        }
        v297 = 1; /*0x141035e82*/
      }
      __unwind
      {
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&startProgress); /*0xf1c00000000016e8*/
      }
      __wind /*0xf1c00000000016f0*/
      {
        RBX::Memory::setCurrentCategory(category: v24); /*0x141035e8c*/
      }
      __unwind
      {
        __std_terminate(a1: v25, a2: v295); /*0x142f39fa8*/
      }
      if ( rbx::signals::connection::operator!=(this: &v7->avatarClusterStartConnection.con, &other) ) /*0x141035ea1*/
      {
        rbx::signals::connection::disconnect(this: &v7->avatarClusterStartConnection.con); /*0x141035eb1*/
        rbx::signals::connection::operator=(this: &v7->avatarClusterStartConnection.con, con: &other); /*0x141035ec5*/
      }
      v297 = 0; /*0x141035eca*/
    }
    __unwind
    {
    }
    p = other.weak_slot.p_; /*0x141035ecf*/
    if ( other.weak_slot.p_ != nullptr /*0x141035ee9*/
      && _InterlockedExchangeAdd(&other.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
    {
      operator delete(ptr: p); /*0x141035eeb*/
    }
    __wind /*0xf1c00000000016b4*/
    {
      *(_QWORD *)&client = RBX::PlayerConfigurer::onAvatarClusterEnded; /*0x141035ef7*/
      DWORD2(client) = 0; /*0x141035efc*/
      v27 = client; /*0x141035f04*/
      v388 = client; /*0x141035f09*/
      v389 = v7; /*0x141035f11*/
      v28 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x141035f1f*/
      __wind /*0xf1c0000000001690*/
      {
        parent = v28; /*0x141035f24*/
        v300.parent = v28; /*0x141035f26*/
        v30 = operator new(size: 0x40u); /*0x141035f32*/
        v31 = v30; /*0x141035f37*/
        *(_QWORD *)&client = v30; /*0x141035f3a*/
        if ( v30 != nullptr ) /*0x141035f42*/
        {
          *v30 = 0; /*0x141035f44*/
          v30[1] = 1; /*0x141035f47*/
          *((_QWORD *)v30 + 1) = rbx::signals::slot_with_functor<boost::_bi::bind_t<void,boost::_mfi::mf2<void,PropertiesWidget::InstanceSelectionEditor,RBX::Instance *,bool &>,boost::_bi::list3<boost::_bi::value<PropertiesWidget::InstanceSelectionEditor *>,boost::arg<1>,boost::arg<2>>>,RBX::Instance *,bool &>::do_call; /*0x141035f4e*/
          *((_QWORD *)v30 + 2) = RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x141035f52*/
          *((_QWORD *)v30 + 3) = 0; /*0x141035f56*/
          p_avatarClusterEndSignal = &v556->avatarClusterEndSignal; /*0x141035f62*/
          *((_QWORD *)v31 + 4) = &v556->avatarClusterEndSignal; /*0x141035f68*/
          *(_OWORD *)(v31 + 10) = v27; /*0x141035f6c*/
          *((_QWORD *)v31 + 7) = v389; /*0x141035f79*/
          rbx::signals::signal_base::insert(this: p_avatarClusterEndSignal, item: (rbx::signals::slot_base *)v31); /*0x141035f84*/
          con.weak_slot.p_ = (rbx::signals::slot_base *)v31; /*0x141035f89*/
          _InterlockedIncrement(v31 + 1); /*0x141035f96*/
          parent = v300.parent; /*0x141035f9a*/
        }
        else
        {
          rbx::signals::signal_base::insert(this: &v556->avatarClusterEndSignal, item: nullptr); /*0x141035fb4*/
          con.weak_slot.p_ = nullptr; /*0x141035fb9*/
        }
        v297 = 2; /*0x141035fc1*/
      }
      __unwind
      {
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v300); /*0xf1c00000000016a0*/
      }
      __wind /*0xf1c00000000016a8*/
      {
        RBX::Memory::setCurrentCategory(category: parent); /*0x141035fcb*/
      }
      __unwind
      {
        __std_terminate(a1: v33, a2: v295); /*0xf1c000000000009c*/
      }
      if ( rbx::signals::connection::operator!=(this: &v7->avatarClusterEndConnection.con, other: &con) ) /*0x141035fe0*/
      {
        rbx::signals::connection::disconnect(this: &v7->avatarClusterEndConnection.con); /*0x141035ff0*/
        rbx::signals::connection::operator=(this: &v7->avatarClusterEndConnection.con, &con); /*0x141036004*/
      }
      v297 = 0; /*0x141036009*/
    }
    __unwind
    {
    }
    v34 = con.weak_slot.p_; /*0x14103600e*/
    if ( con.weak_slot.p_ != nullptr /*0x141036028*/
      && _InterlockedExchangeAdd(&con.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
    {
      operator delete(ptr: v34); /*0x14103602a*/
    }
    __wind /*0xf1c000000000166c*/
    {
      *(_QWORD *)&client = RBX::PlayerConfigurer::onAvatarTextureStarted; /*0x141036036*/
      DWORD2(client) = 0; /*0x14103603b*/
      v35 = client; /*0x141036043*/
      v394 = client; /*0x141036048*/
      v395 = v7; /*0x141036050*/
      v36 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x14103605e*/
      __wind /*0xf1c0000000001648*/
      {
        v37 = v36; /*0x141036063*/
        v301.parent = v36; /*0x141036065*/
        v38 = operator new(size: 0x40u); /*0x141036071*/
        v39 = v38; /*0x141036076*/
        *(_QWORD *)&client = v38; /*0x141036079*/
        if ( v38 != nullptr ) /*0x141036081*/
        {
          *v38 = 0; /*0x141036083*/
          v38[1] = 1; /*0x141036086*/
          *((_QWORD *)v38 + 1) = rbx::signals::slot_with_functor<boost::_bi::bind_t<void,boost::_mfi::mf2<void,PropertiesWidget::InstanceSelectionEditor,RBX::Instance *,bool &>,boost::_bi::list3<boost::_bi::value<PropertiesWidget::InstanceSelectionEditor *>,boost::arg<1>,boost::arg<2>>>,RBX::Instance *,bool &>::do_call; /*0x14103608d*/
          *((_QWORD *)v38 + 2) = RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x141036091*/
          *((_QWORD *)v38 + 3) = 0; /*0x141036095*/
          p_avatarTextureStartSignal = &v556->avatarTextureStartSignal; /*0x1410360a1*/
          *((_QWORD *)v39 + 4) = &v556->avatarTextureStartSignal; /*0x1410360a7*/
          *(_OWORD *)(v39 + 10) = v35; /*0x1410360ab*/
          *((_QWORD *)v39 + 7) = v395; /*0x1410360b8*/
          rbx::signals::signal_base::insert(this: p_avatarTextureStartSignal, item: (rbx::signals::slot_base *)v39); /*0x1410360c3*/
          v306.weak_slot.p_ = (rbx::signals::slot_base *)v39; /*0x1410360c8*/
          _InterlockedIncrement(v39 + 1); /*0x1410360d5*/
          v37 = v301.parent; /*0x1410360d9*/
        }
        else
        {
          rbx::signals::signal_base::insert(this: &v556->avatarTextureStartSignal, item: nullptr); /*0x1410360f3*/
          v306.weak_slot.p_ = nullptr; /*0x1410360f8*/
        }
        v297 = 4; /*0x141036100*/
      }
      __unwind
      {
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v301); /*0xf1c0000000001658*/
      }
      __wind /*0xf1c0000000001660*/
      {
        RBX::Memory::setCurrentCategory(category: v37); /*0x14103610a*/
      }
      __unwind
      {
        __std_terminate(a1: v41, a2: v295); /*0xf1c00000000000a4*/
      }
      if ( rbx::signals::connection::operator!=(this: &v7->avatarTextureStartConnection.con, other: &v306) ) /*0x14103611f*/
      {
        rbx::signals::connection::disconnect(this: &v7->avatarTextureStartConnection.con); /*0x14103612f*/
        rbx::signals::connection::operator=(this: &v7->avatarTextureStartConnection.con, con: &v306); /*0x141036143*/
      }
      v297 = 0; /*0x141036148*/
    }
    __unwind
    {
    }
    v42 = v306.weak_slot.p_; /*0x14103614d*/
    if ( v306.weak_slot.p_ != nullptr /*0x141036167*/
      && _InterlockedExchangeAdd(&v306.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
    {
      operator delete(ptr: v42); /*0x141036169*/
    }
    __wind /*0xf1c0000000001624*/
    {
      *(_QWORD *)&client = RBX::PlayerConfigurer::onAvatarTextureEnded; /*0x141036175*/
      DWORD2(client) = 0; /*0x14103617a*/
      v43 = client; /*0x141036182*/
      v398 = client; /*0x141036187*/
      v399 = v7; /*0x14103618f*/
      v44 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x14103619d*/
      __wind /*0xf1c0000000001600*/
      {
        v45 = v44; /*0x1410361a2*/
        v302.parent = v44; /*0x1410361a4*/
        v46 = operator new(size: 0x40u); /*0x1410361b0*/
        v47 = v46; /*0x1410361b5*/
        *(_QWORD *)&client = v46; /*0x1410361b8*/
        if ( v46 != nullptr ) /*0x1410361c0*/
        {
          *v46 = 0; /*0x1410361c2*/
          v46[1] = 1; /*0x1410361c5*/
          *((_QWORD *)v46 + 1) = rbx::signals::slot_with_functor<boost::_bi::bind_t<void,boost::_mfi::mf2<void,PropertiesWidget::InstanceSelectionEditor,RBX::Instance *,bool &>,boost::_bi::list3<boost::_bi::value<PropertiesWidget::InstanceSelectionEditor *>,boost::arg<1>,boost::arg<2>>>,RBX::Instance *,bool &>::do_call; /*0x1410361cc*/
          *((_QWORD *)v46 + 2) = RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x1410361d0*/
          *((_QWORD *)v46 + 3) = 0; /*0x1410361d4*/
          p_avatarTextureEndSignal = &v556->avatarTextureEndSignal; /*0x1410361e0*/
          *((_QWORD *)v47 + 4) = &v556->avatarTextureEndSignal; /*0x1410361e6*/
          *(_OWORD *)(v47 + 10) = v43; /*0x1410361ea*/
          *((_QWORD *)v47 + 7) = v399; /*0x1410361f7*/
          rbx::signals::signal_base::insert(this: p_avatarTextureEndSignal, item: (rbx::signals::slot_base *)v47); /*0x141036202*/
          v307.weak_slot.p_ = (rbx::signals::slot_base *)v47; /*0x141036207*/
          _InterlockedIncrement(v47 + 1); /*0x141036214*/
          v45 = v302.parent; /*0x141036218*/
        }
        else
        {
          rbx::signals::signal_base::insert(this: &v556->avatarTextureEndSignal, item: nullptr); /*0x141036232*/
          v307.weak_slot.p_ = nullptr; /*0x141036237*/
        }
        v297 = 8; /*0x14103623f*/
      }
      __unwind
      {
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v302); /*0xf1c0000000001610*/
      }
      __wind /*0xf1c0000000001618*/
      {
        RBX::Memory::setCurrentCategory(category: v45); /*0x141036249*/
      }
      __unwind
      {
        __std_terminate(a1: v49, a2: v295); /*0xf1c00000000000ac*/
      }
      if ( rbx::signals::connection::operator!=(this: &v7->avatarTextureEndConnection.con, other: &v307) ) /*0x14103625e*/
      {
        rbx::signals::connection::disconnect(this: &v7->avatarTextureEndConnection.con); /*0x14103626e*/
        rbx::signals::connection::operator=(this: &v7->avatarTextureEndConnection.con, con: &v307); /*0x141036282*/
      }
      v297 = 0; /*0x141036287*/
    }
    __unwind
    {
    }
    v50 = v307.weak_slot.p_; /*0x14103628c*/
    if ( v307.weak_slot.p_ != nullptr /*0x1410362a6*/
      && _InterlockedExchangeAdd(&v307.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
    {
      operator delete(ptr: v50); /*0x1410362a8*/
    }
    v5 = (const std::string *)clientOsVersion_temp; /*0x1410362ad*/
    v6 = v556; /*0x1410362b5*/
  }
  if ( DFFlag::ReportFailuresInClientJoinAll2.value ) /*0x1410362c4*/
  {
    __wind /*0xf1c00000000015dc*/
    {
      p_clientJoinFailureSignal = &v6->clientJoinFailureSignal; /*0x1410362ca*/
      *(_QWORD *)&client = RBX::PlayerConfigurer::reportLocalJoinFailureMetrics; /*0x1410362d8*/
      DWORD2(client) = 0; /*0x1410362dd*/
      v52 = client; /*0x1410362e5*/
      v386 = client; /*0x1410362ea*/
      v387 = v7; /*0x1410362f2*/
      v53 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x141036300*/
      __wind /*0xf1c00000000015b8*/
      {
        v54 = v53; /*0x141036305*/
        v311.parent = v53; /*0x141036307*/
        v55 = (char *)operator new(size: 0x40u); /*0x141036313*/
        v56 = (rbx::signals::slot_base *)v55; /*0x141036318*/
        *(_QWORD *)&client = v55; /*0x14103631b*/
        if ( v55 != nullptr ) /*0x141036326*/
        {
          *(_DWORD *)v55 = 0; /*0x141036328*/
          *((_DWORD *)v55 + 1) = 1; /*0x14103632b*/
          *((_QWORD *)v55 + 1) = rbx::signals::slot_with_functor<boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::PlayerConfigurer,std::string,double>,boost::_bi::list3<boost::_bi::value<RBX::PlayerConfigurer *>,boost::arg<1>,boost::arg<2>>>,std::string,double>::do_call; /*0x141036339*/
          *((_QWORD *)v55 + 2) = RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x141036344*/
          *((_QWORD *)v55 + 3) = 0; /*0x141036348*/
          *((_QWORD *)v55 + 4) = p_clientJoinFailureSignal; /*0x14103634c*/
          *(_OWORD *)(v55 + 40) = v52; /*0x141036350*/
          *((_QWORD *)v55 + 7) = v387; /*0x14103635d*/
          rbx::signals::signal_base::insert(this: p_clientJoinFailureSignal, item: (rbx::signals::slot_base *)v55); /*0x141036365*/
          v303.weak_slot.p_ = v56; /*0x14103636a*/
          _InterlockedIncrement(&v56->weak._Storage._Value); /*0x141036377*/
          v54 = v311.parent; /*0x14103637b*/
        }
        else
        {
          rbx::signals::signal_base::insert(this: p_clientJoinFailureSignal, item: nullptr); /*0x141036386*/
          v303.weak_slot.p_ = nullptr; /*0x14103638b*/
        }
        v297 = 16; /*0x141036393*/
      }
      __unwind
      {
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v311); /*0xf1c00000000015c8*/
      }
      __wind /*0xf1c00000000015d0*/
      {
        RBX::Memory::setCurrentCategory(category: v54); /*0x14103639d*/
      }
      __unwind
      {
        __std_terminate(a1: v57, a2: v295); /*0xf1c00000000000b4*/
      }
      if ( rbx::signals::connection::operator!=(this: &v7->clientJoinFailureConnection.con, other: &v303) ) /*0x1410363b2*/
      {
        rbx::signals::connection::disconnect(this: &v7->clientJoinFailureConnection.con); /*0x1410363c2*/
        rbx::signals::connection::operator=(this: &v7->clientJoinFailureConnection.con, con: &v303); /*0x1410363d6*/
      }
      v297 = 0; /*0x1410363db*/
    }
    __unwind
    {
    }
    v58 = v303.weak_slot.p_; /*0x1410363e0*/
    if ( v303.weak_slot.p_ != nullptr /*0x1410363fa*/
      && _InterlockedExchangeAdd(&v303.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
    {
      operator delete(ptr: v58); /*0x1410363fc*/
    }
  }
  v385 = *RBX::Security::Identity::Identity( /*0x14103641e*/
            this: (RBX::Security::Identity *)&v542.x,
            type: identity,
            assetId: 0,
            scriptContext: nullptr);
  RBX::Security::Impersonator::Impersonator(this: &impersonate, identity: &v385); /*0x141036444*/
  __wind
  {
    if ( v5->_Mypair._Myval2._Mysize != 0 ) /*0x14103644f*/
      RBX::GameConfigurer::parseArgs(this: v7, args: v5); /*0x141036457*/
    if ( DFFlag::DebugAvatarProfilerCallers.value ) /*0x141036463*/
    {
      params.classnamesOfInterest._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141036469*/
      params.classnamesOfInterest._Mypair._Myval2._Mysize = 0; /*0x141036471*/
      params.classnamesOfInterest._Mypair._Myval2._Myres = 15; /*0x141036479*/
      params.userName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103648d*/
      *(__m128i *)&params.userName._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14103649d*/
      params.displayName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410364ae*/
      *(_OWORD *)&params.displayName._Mypair._Myval2._Mysize = *(_OWORD *)&params.userName._Mypair._Myval2._Mysize; /*0x1410364b6*/
      memset(&params.userId, 0, 20); /*0x1410364ca*/
      memset(&params.universeId, 0, 24); /*0x1410364db*/
      params.characterAppearance._Mypair._Myval2._Mysize = 0; /*0x1410364ef*/
      params.characterAppearance._Mypair._Myval2._Myres = 15; /*0x1410364f7*/
      params.characterAppearance._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036503*/
      params.countryCode._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103650b*/
      params.countryCode._Mypair._Myval2._Mysize = 0; /*0x141036513*/
      params.countryCode._Mypair._Myval2._Myres = 15; /*0x14103651b*/
      __wind /*0xf1c0000000001588*/
      {
        params.baseTime = v9; /*0x14103652f*/
        v78 = v556; /*0x141036538*/
        params.dataModel = v556; /*0x141036540*/
        key_24 = 15; /*0x141036548*/
        key_16 = 8; /*0x141036554*/
        strcpy((char *)key, "UserName"); /*0x14103656a*/
        __wind /*0xf1c000000000154c*/
        {
          ParamString = RBX::GameConfigurer::getParamString(this: v7, &result, (const std::string *)key); /*0x141036592*/
          if ( &params.userName != ParamString ) /*0x1410365a0*/
          {
            if ( params.userName._Mypair._Myval2._Myres >= 0x10 ) /*0x1410365ae*/
            {
              v60 = params.userName._Mypair._Myval2._Bx._Ptr; /*0x1410365b3*/
              if ( params.userName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410365c5*/
              {
                v60 = *((char **)params.userName._Mypair._Myval2._Bx._Ptr - 1); /*0x1410365cb*/
                if ( (unsigned __int64)(params.userName._Mypair._Myval2._Bx._Ptr - v60 - 8) > 0x1F ) /*0x1410365da*/
LABEL_108:
                  _invalid_parameter_noinfo_noreturn(); /*0x14103665a*/
              }
              operator delete(ptr: v60); /*0x1410365dc*/
            }
            *(__m128i *)&params.userName._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x1410365e9*/
            params.userName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410365f2*/
            params.userName = *ParamString; /*0x1410365fd*/
            ParamString->_Mypair._Myval2._Mysize = 0; /*0x141036611*/
            ParamString->_Mypair._Myval2._Myres = 15; /*0x141036615*/
            ParamString->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103661d*/
          }
          if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14103662c*/
          {
            v61 = result._Mypair._Myval2._Bx._Ptr; /*0x141036631*/
            if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141036643*/
            {
              v61 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x141036649*/
              if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v61 - 8) > 0x1F ) /*0x141036658*/
                goto LABEL_108; /*0x141036658*/
            }
            operator delete(ptr: v61); /*0x141036661*/
          }
          result._Mypair._Myval2._Mysize = 0; /*0x141036666*/
          result._Mypair._Myval2._Myres = 15; /*0x14103666e*/
          result._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103667a*/
          if ( key_24 >= 0x10 ) /*0x14103668e*/
          {
            v62 = (void *)key[0]; /*0x141036693*/
            if ( key_24 + 1 >= 0x1000 ) /*0x1410366a5*/
            {
              v62 = *(void **)(key[0] - 8LL); /*0x1410366ab*/
              if ( (unsigned __int64)(key[0] - (_QWORD)v62 - 8LL) > 0x1F ) /*0x1410366ba*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410366bc*/
            }
            operator delete(ptr: v62); /*0x1410366c3*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)key); /*0xf1c000000000155c*/
        }
        __wind /*0xf1c0000000001564*/
        {
          key_16 = 0; /*0x1410366c8*/
          key_24 = 15; /*0x1410366d0*/
          LOBYTE(key[0]) = 0; /*0x1410366dc*/
          v318._Mypair._Myval2._Myres = 15; /*0x1410366e4*/
          v318._Mypair._Myval2._Mysize = 11; /*0x1410366f0*/
          strcpy(v318._Mypair._Myval2._Bx._Buf, "DisplayName"); /*0x141036704*/
          v63 = RBX::GameConfigurer::getParamString(this: v7, result: &v379, key: &v318); /*0x14103674a*/
          if ( &params.displayName != v63 ) /*0x141036758*/
          {
            if ( params.displayName._Mypair._Myval2._Myres >= 0x10 ) /*0x141036766*/
            {
              v64 = params.displayName._Mypair._Myval2._Bx._Ptr; /*0x14103676b*/
              if ( params.displayName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103677d*/
              {
                v64 = *((char **)params.displayName._Mypair._Myval2._Bx._Ptr - 1); /*0x141036783*/
                if ( (unsigned __int64)(params.displayName._Mypair._Myval2._Bx._Ptr - v64 - 8) > 0x1F ) /*0x141036792*/
LABEL_124:
                  _invalid_parameter_noinfo_noreturn(); /*0x141036812*/
              }
              operator delete(ptr: v64); /*0x141036794*/
            }
            *(__m128i *)&params.displayName._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x1410367a1*/
            params.displayName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410367aa*/
            params.displayName = *v63; /*0x1410367b5*/
            v63->_Mypair._Myval2._Mysize = 0; /*0x1410367c9*/
            v63->_Mypair._Myval2._Myres = 15; /*0x1410367cd*/
            v63->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410367d5*/
          }
          if ( v379._Mypair._Myval2._Myres >= 0x10 ) /*0x1410367e4*/
          {
            v65 = v379._Mypair._Myval2._Bx._Ptr; /*0x1410367e9*/
            if ( v379._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410367fb*/
            {
              v65 = *((char **)v379._Mypair._Myval2._Bx._Ptr - 1); /*0x141036801*/
              if ( (unsigned __int64)(v379._Mypair._Myval2._Bx._Ptr - v65 - 8) > 0x1F ) /*0x141036810*/
                goto LABEL_124; /*0x141036810*/
            }
            operator delete(ptr: v65); /*0x141036819*/
          }
          v379._Mypair._Myval2._Mysize = 0; /*0x14103681e*/
          v379._Mypair._Myval2._Myres = 15; /*0x141036826*/
          v379._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036832*/
          if ( v318._Mypair._Myval2._Myres >= 0x10 ) /*0x141036846*/
          {
            v66 = v318._Mypair._Myval2._Bx._Ptr; /*0x14103684b*/
            if ( v318._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103685d*/
            {
              v66 = *((char **)v318._Mypair._Myval2._Bx._Ptr - 1); /*0x141036863*/
              if ( (unsigned __int64)(v318._Mypair._Myval2._Bx._Ptr - v66 - 8) > 0x1F ) /*0x141036872*/
                _invalid_parameter_noinfo_noreturn(); /*0x141036874*/
            }
            operator delete(ptr: v66); /*0x14103687b*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v318); /*0xf1c0000000001574*/
        }
        __wind /*0xf1c000000000157c*/
        {
          v318._Mypair._Myval2._Mysize = 0; /*0x141036880*/
          v318._Mypair._Myval2._Myres = 15; /*0x141036888*/
          v318._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036894*/
          v319._Mypair._Myval2._Myres = 15; /*0x1410368a4*/
          v319._Mypair._Myval2._Mysize = 6; /*0x1410368b0*/
          strcpy(v319._Mypair._Myval2._Bx._Buf, "UserId"); /*0x1410368c2*/
          v319._Mypair._Myval2._Bx._Buf[7] = 0; /*0x1410368d0*/
          params.userId = RBX::GameConfigurer::getParamInt64(this: v7, key: &v319); /*0x1410368f0*/
          if ( v319._Mypair._Myval2._Myres >= 0x10 ) /*0x141036904*/
          {
            v67 = v319._Mypair._Myval2._Bx._Ptr; /*0x141036909*/
            if ( v319._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103691b*/
            {
              v67 = *((char **)v319._Mypair._Myval2._Bx._Ptr - 1); /*0x141036921*/
              if ( (unsigned __int64)(v319._Mypair._Myval2._Bx._Ptr - v67 - 8) > 0x1F ) /*0x141036930*/
                _invalid_parameter_noinfo_noreturn(); /*0x141036932*/
            }
            operator delete(ptr: v67); /*0x141036939*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v319); /*0xf1c0000000001544*/
        }
        v319._Mypair._Myval2._Mysize = 0; /*0x14103693e*/
        v319._Mypair._Myval2._Myres = 15; /*0x141036946*/
        v319._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036952*/
        v327._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103695a*/
        v327._Mypair._Myval2._Mysize = 0; /*0x141036962*/
        v327._Mypair._Myval2._Myres = 15; /*0x14103696a*/
        std::string::assign(this: &v327, _Ptr: "PlaceId", _Count: 7u); /*0x141036993*/
        __wind /*0xf1c0000000001534*/
        {
          params.placeId = RBX::GameConfigurer::getParamInt64(this: v7, key: &v327); /*0x1410369a9*/
          if ( v327._Mypair._Myval2._Myres >= 0x10 ) /*0x1410369bd*/
          {
            v68 = v327._Mypair._Myval2._Bx._Ptr; /*0x1410369c2*/
            if ( v327._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410369d4*/
            {
              v68 = *((char **)v327._Mypair._Myval2._Bx._Ptr - 1); /*0x1410369da*/
              if ( (unsigned __int64)(v327._Mypair._Myval2._Bx._Ptr - v68 - 8) > 0x1F ) /*0x1410369e9*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410369eb*/
            }
            operator delete(ptr: v68); /*0x1410369f2*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v327); /*0xf1c000000000152c*/
        }
        v327._Mypair._Myval2._Mysize = 0; /*0x1410369f7*/
        v327._Mypair._Myval2._Myres = 15; /*0x1410369ff*/
        v327._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036a0b*/
        v321._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141036a13*/
        v321._Mypair._Myval2._Mysize = 0; /*0x141036a1b*/
        v321._Mypair._Myval2._Myres = 15; /*0x141036a23*/
        std::string::assign(this: &v321, _Ptr: "DataCenterId", _Count: 0xCu); /*0x141036a4c*/
        __wind /*0xf1c000000000151c*/
        {
          params.dataCenterId = RBX::GameConfigurer::getParamInt(this: v7, key: &v321); /*0x141036a62*/
          if ( v321._Mypair._Myval2._Myres >= 0x10 ) /*0x141036a75*/
          {
            v69 = v321._Mypair._Myval2._Bx._Ptr; /*0x141036a7a*/
            if ( v321._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141036a8c*/
            {
              v69 = *((char **)v321._Mypair._Myval2._Bx._Ptr - 1); /*0x141036a92*/
              if ( (unsigned __int64)(v321._Mypair._Myval2._Bx._Ptr - v69 - 8) > 0x1F ) /*0x141036aa1*/
                _invalid_parameter_noinfo_noreturn(); /*0x141036aa3*/
            }
            operator delete(ptr: v69); /*0x141036aaa*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v321); /*0xf1c0000000001514*/
        }
        v321._Mypair._Myval2._Mysize = 0; /*0x141036aaf*/
        v321._Mypair._Myval2._Myres = 15; /*0x141036ab7*/
        v321._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036ac3*/
        v326._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141036acb*/
        v326._Mypair._Myval2._Mysize = 0; /*0x141036ad3*/
        v326._Mypair._Myval2._Myres = 15; /*0x141036adb*/
        std::string::assign(this: &v326, _Ptr: "UniverseId", _Count: 0xAu); /*0x141036b04*/
        __wind /*0xf1c0000000001504*/
        {
          params.universeId = RBX::GameConfigurer::getParamInt64(this: v7, key: &v326); /*0x141036b1a*/
          if ( v326._Mypair._Myval2._Myres >= 0x10 ) /*0x141036b2e*/
          {
            v70 = v326._Mypair._Myval2._Bx._Ptr; /*0x141036b33*/
            if ( v326._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141036b45*/
            {
              v70 = *((char **)v326._Mypair._Myval2._Bx._Ptr - 1); /*0x141036b4b*/
              if ( (unsigned __int64)(v326._Mypair._Myval2._Bx._Ptr - v70 - 8) > 0x1F ) /*0x141036b5a*/
                _invalid_parameter_noinfo_noreturn(); /*0x141036b5c*/
            }
            operator delete(ptr: v70); /*0x141036b63*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v326); /*0xf1c00000000014fc*/
        }
        v326._Mypair._Myval2._Mysize = 0; /*0x141036b68*/
        v326._Mypair._Myval2._Myres = 15; /*0x141036b70*/
        v326._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036b7c*/
        v320._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141036b84*/
        v320._Mypair._Myval2._Mysize = 0; /*0x141036b8c*/
        v320._Mypair._Myval2._Myres = 15; /*0x141036b94*/
        std::string::assign(this: &v320, _Ptr: "characterAppearanceId", _Count: 0x15u); /*0x141036bbd*/
        __wind /*0xf1c00000000014ec*/
        {
          params.characterAppearanceId = RBX::GameConfigurer::getParamInt64(this: v7, key: &v320); /*0x141036bd3*/
          if ( v320._Mypair._Myval2._Myres >= 0x10 ) /*0x141036be7*/
          {
            v71 = v320._Mypair._Myval2._Bx._Ptr; /*0x141036bec*/
            if ( v320._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141036bfe*/
            {
              v71 = *((char **)v320._Mypair._Myval2._Bx._Ptr - 1); /*0x141036c04*/
              if ( (unsigned __int64)(v320._Mypair._Myval2._Bx._Ptr - v71 - 8) > 0x1F ) /*0x141036c13*/
                _invalid_parameter_noinfo_noreturn(); /*0x141036c15*/
            }
            operator delete(ptr: v71); /*0x141036c1c*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v320); /*0xf1c00000000014e4*/
        }
        v320._Mypair._Myval2._Mysize = 0; /*0x141036c21*/
        v320._Mypair._Myval2._Myres = 15; /*0x141036c29*/
        v320._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036c35*/
        v340._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141036c3d*/
        v340._Mypair._Myval2._Mysize = 0; /*0x141036c45*/
        v340._Mypair._Myval2._Myres = 15; /*0x141036c4d*/
        std::string::assign(this: &v340, _Ptr: "CharacterAppearance", _Count: 0x13u); /*0x141036c76*/
        __wind /*0xf1c00000000014d4*/
        {
          v72 = RBX::GameConfigurer::getParamString(this: v7, result: &v531, key: &v340); /*0x141036c94*/
          if ( &params.characterAppearance != v72 ) /*0x141036ca2*/
          {
            if ( params.characterAppearance._Mypair._Myval2._Myres >= 0x10 ) /*0x141036cb4*/
            {
              v73 = params.characterAppearance._Mypair._Myval2._Bx._Ptr; /*0x141036cb9*/
              if ( params.characterAppearance._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141036ccb*/
              {
                v73 = *((char **)params.characterAppearance._Mypair._Myval2._Bx._Ptr - 1); /*0x141036cd1*/
                if ( (unsigned __int64)(params.characterAppearance._Mypair._Myval2._Bx._Ptr - v73 - 8) > 0x1F ) /*0x141036ce0*/
                  _invalid_parameter_noinfo_noreturn(); /*0x141036ce2*/
              }
              operator delete(ptr: v73); /*0x141036ce9*/
            }
            params.characterAppearance._Mypair._Myval2._Mysize = 0; /*0x141036cee*/
            params.characterAppearance._Mypair._Myval2._Myres = 15; /*0x141036cf6*/
            params.characterAppearance._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036d02*/
            params.characterAppearance = *v72; /*0x141036d0d*/
            v72->_Mypair._Myval2._Mysize = 0; /*0x141036d21*/
            v72->_Mypair._Myval2._Myres = 15; /*0x141036d25*/
            v72->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036d2d*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v531); /*0x141036d38*/
          if ( v340._Mypair._Myval2._Myres >= 0x10 ) /*0x141036d4a*/
          {
            v74 = v340._Mypair._Myval2._Bx._Ptr; /*0x141036d4f*/
            if ( v340._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141036d61*/
            {
              v74 = *((char **)v340._Mypair._Myval2._Bx._Ptr - 1); /*0x141036d67*/
              if ( (unsigned __int64)(v340._Mypair._Myval2._Bx._Ptr - v74 - 8) > 0x1F ) /*0x141036d76*/
                _invalid_parameter_noinfo_noreturn(); /*0x141036d78*/
            }
            operator delete(ptr: v74); /*0x141036d7f*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v340); /*0xf1c00000000014cc*/
        }
        v340._Mypair._Myval2._Mysize = 0; /*0x141036d84*/
        v340._Mypair._Myval2._Myres = 15; /*0x141036d8c*/
        v340._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036d98*/
        v339._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141036da0*/
        v339._Mypair._Myval2._Mysize = 0; /*0x141036da8*/
        v339._Mypair._Myval2._Myres = 15; /*0x141036db0*/
        std::string::assign(this: &v339, _Ptr: aCountryc, _Count: 0xBu); /*0x141036dd9*/
        __wind /*0xf1c00000000014bc*/
        {
          v75 = RBX::GameConfigurer::getParamString(this: v7, result: &v537, key: &v339); /*0x141036df7*/
          if ( &params.countryCode != v75 ) /*0x141036e05*/
          {
            if ( params.countryCode._Mypair._Myval2._Myres >= 0x10 ) /*0x141036e17*/
            {
              v76 = params.countryCode._Mypair._Myval2._Bx._Ptr; /*0x141036e1c*/
              if ( params.countryCode._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141036e2e*/
              {
                v76 = *((char **)params.countryCode._Mypair._Myval2._Bx._Ptr - 1); /*0x141036e34*/
                if ( (unsigned __int64)(params.countryCode._Mypair._Myval2._Bx._Ptr - v76 - 8) > 0x1F ) /*0x141036e43*/
                  _invalid_parameter_noinfo_noreturn(); /*0x141036e45*/
              }
              operator delete(ptr: v76); /*0x141036e4c*/
            }
            params.countryCode._Mypair._Myval2._Mysize = 0; /*0x141036e51*/
            params.countryCode._Mypair._Myval2._Myres = 15; /*0x141036e59*/
            params.countryCode._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036e65*/
            params.countryCode = *v75; /*0x141036e70*/
            v75->_Mypair._Myval2._Mysize = 0; /*0x141036e84*/
            v75->_Mypair._Myval2._Myres = 15; /*0x141036e88*/
            v75->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036e90*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v537); /*0x141036e9b*/
          if ( v339._Mypair._Myval2._Myres >= 0x10 ) /*0x141036ead*/
          {
            v77 = v339._Mypair._Myval2._Bx._Ptr; /*0x141036eb2*/
            if ( v339._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141036ec4*/
            {
              v77 = *((char **)v339._Mypair._Myval2._Bx._Ptr - 1); /*0x141036eca*/
              if ( (unsigned __int64)(v339._Mypair._Myval2._Bx._Ptr - v77 - 8) > 0x1F ) /*0x141036ed9*/
                _invalid_parameter_noinfo_noreturn(); /*0x141036edb*/
            }
            operator delete(ptr: v77); /*0x141036ee2*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v339); /*0xf1c00000000014b4*/
        }
        v339._Mypair._Myval2._Mysize = 0; /*0x141036ee7*/
        v339._Mypair._Myval2._Myres = 15; /*0x141036eef*/
        v339._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036efb*/
        RBX::AvatarProfiler::init(&params); /*0x141036f0b*/
        RBX::AvatarProfiler::InitParams::~InitParams(this: &params); /*0x141036f19*/
      }
      __unwind
      {
        RBX::AvatarProfiler::InitParams::~InitParams(this: &params); /*0xf1c00000000014a8*/
      }
    }
    else
    {
      v78 = v556; /*0x141036f20*/
    }
    v333._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141036f28*/
    v333._Mypair._Myval2._Mysize = 0; /*0x141036f30*/
    v333._Mypair._Myval2._Myres = 15; /*0x141036f38*/
    std::string::assign(this: &v333, _Ptr: aCountryc, _Count: 0xBu); /*0x141036f61*/
    __wind /*0xf1c0000000001480*/
    {
      RBX::GameConfigurer::getParamString(this: v7, result: &countryCodeFromArgs, key: &v333); /*0x141036f7a*/
      if ( v333._Mypair._Myval2._Myres >= 0x10 ) /*0x141036f8c*/
      {
        v79 = v333._Mypair._Myval2._Bx._Ptr; /*0x141036f91*/
        if ( v333._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141036fa3*/
        {
          v79 = *((char **)v333._Mypair._Myval2._Bx._Ptr - 1); /*0x141036fa9*/
          if ( (unsigned __int64)(v333._Mypair._Myval2._Bx._Ptr - v79 - 8) > 0x1F ) /*0x141036fb8*/
            _invalid_parameter_noinfo_noreturn(); /*0x141036fba*/
        }
        operator delete(ptr: v79); /*0x141036fc1*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v333); /*0xf1c0000000001490*/
    }
    __wind
    {
      v333._Mypair._Myval2._Mysize = 0; /*0x141036fc6*/
      v333._Mypair._Myval2._Myres = 15; /*0x141036fce*/
      v333._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141036fda*/
      if ( countryCodeFromArgs._Mypair._Myval2._Mysize != 0 ) /*0x141036feb*/
        RBX::Analytics::setLocation(loc: &countryCodeFromArgs); /*0x141036ff5*/
      v338._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141036ffa*/
      v338._Mypair._Myval2._Mysize = 0; /*0x141037002*/
      v338._Mypair._Myval2._Myres = 15; /*0x14103700a*/
      std::string::assign(this: &v338, _Ptr: "GameId", _Count: 6u); /*0x141037033*/
      __wind /*0xf1c0000000001474*/
      {
        v80 = RBX::GameConfigurer::getParamString(this: v7, result: &v541, key: &v338); /*0x14103704c*/
        std::string::operator=(this: &RBX::Http::gameID, _Right: v80); /*0x14103705e*/
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v541); /*0x14103706b*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v338); /*0xf1c000000000146c*/
      }
      if ( v338._Mypair._Myval2._Myres >= 0x10 ) /*0x14103707d*/
      {
        v81 = v338._Mypair._Myval2._Bx._Ptr; /*0x141037082*/
        if ( v338._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141037094*/
        {
          v81 = *((char **)v338._Mypair._Myval2._Bx._Ptr - 1); /*0x14103709a*/
          if ( (unsigned __int64)(v338._Mypair._Myval2._Bx._Ptr - v81 - 8) > 0x1F ) /*0x1410370a9*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410370ab*/
        }
        operator delete(ptr: v81); /*0x1410370b2*/
      }
      v338._Mypair._Myval2._Mysize = 0; /*0x1410370b7*/
      v338._Mypair._Myval2._Myres = 15; /*0x1410370bf*/
      v338._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410370cb*/
      p_jobId = &v7->dataModel->jobId; /*0x1410370d7*/
      if ( FFlag::DebugLocalRccServerConnection.value ) /*0x1410370e5*/
      {
        Mysize = 4; /*0x1410370e7*/
        v84 = (std::string *)"Test"; /*0x1410370ed*/
      }
      else
      {
        if ( p_jobId == &RBX::Http::gameID ) /*0x1410370f9*/
          goto LABEL_209; /*0x1410370f9*/
        v84 = &RBX::Http::gameID; /*0x1410370fb*/
        if ( RBX::Http::gameID._Mypair._Myval2._Myres >= 0x10 ) /*0x141037106*/
          v84 = (std::string *)RBX::Http::gameID._Mypair._Myval2._Bx._Ptr; /*0x141037106*/
        Mysize = RBX::Http::gameID._Mypair._Myval2._Mysize; /*0x14103710e*/
      }
      std::string::assign(this: p_jobId, _Ptr: v84->_Mypair._Myval2._Bx._Buf, _Count: Mysize); /*0x141037115*/
LABEL_209:
      Instance = RBX::Security::KeyRing::getInstance(); /*0x14103711a*/
      RBX::Security::KeyRing::setJobId(this: Instance, newJobId: &RBX::Http::gameID); /*0x141037128*/
      if ( FFlag::KeyRingInitFile.value ) /*0x141037134*/
        RBX::Security::KeyRing::registerCounterFn( /*0x141037140*/
          this: Instance,
          callback: RBX::Analytics::EphemeralCounter::reportCounter);
      v337._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141037145*/
      v337._Mypair._Myval2._Mysize = 0; /*0x14103714d*/
      v337._Mypair._Myval2._Myres = 15; /*0x141037155*/
      std::string::assign(this: &v337, _Ptr: "ClientPublicKeyData", _Count: 0x13u); /*0x14103717e*/
      __wind /*0xf1c0000000001444*/
      {
        RBX::GameConfigurer::getParamString(this: v7, result: &pubKeyData, key: &v337); /*0x141037197*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v337); /*0xf1c0000000001454*/
      }
      __wind
      {
        if ( v337._Mypair._Myval2._Myres >= 0x10 ) /*0x1410371a9*/
        {
          v86 = v337._Mypair._Myval2._Bx._Ptr; /*0x1410371ae*/
          if ( v337._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410371c0*/
          {
            v86 = *((char **)v337._Mypair._Myval2._Bx._Ptr - 1); /*0x1410371c6*/
            if ( (unsigned __int64)(v337._Mypair._Myval2._Bx._Ptr - v86 - 8) > 0x1F ) /*0x1410371d5*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410371d7*/
          }
          operator delete(ptr: v86); /*0x1410371de*/
        }
        v337._Mypair._Myval2._Mysize = 0; /*0x1410371e3*/
        v337._Mypair._Myval2._Myres = 15; /*0x1410371eb*/
        v337._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410371f7*/
        v87 = RBX::Security::KeyRing::parseConfig(this: Instance, config: &pubKeyData, isDiagOnly: false); /*0x14103720d*/
        v88 = "Error"; /*0x141037219*/
        if ( v87 ) /*0x141037222*/
          v88 = "Loaded"; /*0x141037222*/
        v89 = RBX::format(result: &v542.text, fmt: "KeyRingClient%s", v88); /*0x141037235*/
        __wind /*0xf1c0000000001438*/
        {
          RBX::PlayerConfigurer::reportCounter(this: v7, counterNamesCSV: v89, blocking: false); /*0x141037244*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v542); /*0xf1c0000000001430*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v542); /*0x141037252*/
        v335._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141037257*/
        v335._Mypair._Myval2._Mysize = 0; /*0x14103725f*/
        v335._Mypair._Myval2._Myres = 15; /*0x141037267*/
        std::string::assign(this: &v335, _Ptr: "ServerPort", _Count: 0xAu); /*0x141037290*/
        __wind /*0xf1c0000000001420*/
        {
          ParamInt = RBX::GameConfigurer::getParamInt(this: v7, key: &v335); /*0x1410372a6*/
          v336._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410372a8*/
          v336._Mypair._Myval2._Mysize = 0; /*0x1410372b0*/
          v336._Mypair._Myval2._Myres = 15; /*0x1410372b8*/
          std::string::assign(this: &v336, _Ptr: "MachineAddress", _Count: 0xEu); /*0x1410372e1*/
          __wind /*0xf1c00000000013fc*/
          {
            v91 = RBX::GameConfigurer::getParamString(this: v7, result: (std::string *)&v530.x, key: &v336); /*0x1410372fa*/
            __wind /*0xf1c00000000013f0*/
            {
              RBX::Analytics::setServerAddress(machineIp: v91, port: ParamInt); /*0x141037305*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v530.x); /*0xf1c00000000013e8*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v530.x); /*0x141037313*/
            if ( v336._Mypair._Myval2._Myres >= 0x10 ) /*0x141037325*/
            {
              v92 = v336._Mypair._Myval2._Bx._Ptr; /*0x14103732a*/
              if ( v336._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103733c*/
              {
                v92 = *((char **)v336._Mypair._Myval2._Bx._Ptr - 1); /*0x141037342*/
                if ( (unsigned __int64)(v336._Mypair._Myval2._Bx._Ptr - v92 - 8) > 0x1F ) /*0x141037351*/
                  _invalid_parameter_noinfo_noreturn(); /*0x141037353*/
              }
              operator delete(ptr: v92); /*0x14103735a*/
            }
            v336._Mypair._Myval2._Mysize = 0; /*0x14103735f*/
            v336._Mypair._Myval2._Myres = 15; /*0x141037367*/
            v336._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141037373*/
            if ( v335._Mypair._Myval2._Myres >= 0x10 ) /*0x141037387*/
            {
              v93 = v335._Mypair._Myval2._Bx._Ptr; /*0x14103738c*/
              if ( v335._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103739e*/
              {
                v93 = *((char **)v335._Mypair._Myval2._Bx._Ptr - 1); /*0x1410373a4*/
                if ( (unsigned __int64)(v335._Mypair._Myval2._Bx._Ptr - v93 - 8) > 0x1F ) /*0x1410373b3*/
                  _invalid_parameter_noinfo_noreturn(); /*0x1410373b5*/
              }
              operator delete(ptr: v93); /*0x1410373bc*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v336); /*0xf1c000000000140c*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v335); /*0xf1c0000000001418*/
        }
        v335._Mypair._Myval2._Mysize = 0; /*0x1410373c1*/
        v335._Mypair._Myval2._Myres = 15; /*0x1410373c9*/
        v335._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410373d5*/
        v334._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410373dd*/
        v334._Mypair._Myval2._Mysize = 0; /*0x1410373e5*/
        v334._Mypair._Myval2._Myres = 15; /*0x1410373ed*/
        std::string::assign(this: &v334, _Ptr: aUser_9, _Count: 6u); /*0x141037416*/
        __wind /*0xf1c00000000013d8*/
        {
          v7->userId = RBX::GameConfigurer::getParamInt64(this: v7, key: &v334); /*0x14103742c*/
          if ( v334._Mypair._Myval2._Myres >= 0x10 ) /*0x14103743c*/
          {
            v94 = v334._Mypair._Myval2._Bx._Ptr; /*0x141037441*/
            if ( v334._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141037453*/
            {
              v94 = *((char **)v334._Mypair._Myval2._Bx._Ptr - 1); /*0x141037459*/
              if ( (unsigned __int64)(v334._Mypair._Myval2._Bx._Ptr - v94 - 8) > 0x1F ) /*0x141037468*/
                _invalid_parameter_noinfo_noreturn(); /*0x14103746a*/
            }
            operator delete(ptr: v94); /*0x141037471*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v334); /*0xf1c00000000013d0*/
        }
        v334._Mypair._Myval2._Mysize = 0; /*0x141037476*/
        v334._Mypair._Myval2._Myres = 15; /*0x14103747e*/
        v334._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103748a*/
        v95 = RBX::SystemUtil::osPlatform(result: &v487); /*0x14103749a*/
        __wind /*0xf1c00000000013c0*/
        {
          v96 = std::operator+<char>(result: &v486, _Left: "GameJoinStart,GameJoinStart", _Right: v95); /*0x1410374b2*/
          __wind /*0xf1c000000000139c*/
          {
            RBX::PlayerConfigurer::reportCounter(this: v7, counterNamesCSV: v96, blocking: false); /*0x1410374c1*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v486); /*0x1410374cf*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v487); /*0x1410374dd*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v486); /*0xf1c00000000013ac*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v487); /*0xf1c00000000013b8*/
        }
        RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1410374ff*/
          category: "Game",
          action: "GameJoin",
          label: aStar,
          value: 0,
          sync: false);
        status._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141037504*/
        status._Mypair._Myval2._Mysize = 0; /*0x14103750c*/
        status._Mypair._Myval2._Myres = 15; /*0x141037514*/
        std::string::assign(this: &status, _Ptr: "JoiningGame", _Count: 0xBu); /*0x14103753d*/
        __wind /*0xf1c0000000001390*/
        {
          RBX::Stats::reportGameStatus(&status, blocking: false); /*0x14103754d*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&status); /*0xf1c0000000001388*/
        }
        if ( status._Mypair._Myval2._Myres >= 0x10 ) /*0x14103755f*/
        {
          v97 = status._Mypair._Myval2._Bx._Ptr; /*0x141037564*/
          if ( status._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141037576*/
          {
            v97 = *((char **)status._Mypair._Myval2._Bx._Ptr - 1); /*0x14103757c*/
            if ( (unsigned __int64)(status._Mypair._Myval2._Bx._Ptr - v97 - 8) > 0x1F ) /*0x14103758b*/
              _invalid_parameter_noinfo_noreturn(); /*0x14103758d*/
          }
          operator delete(ptr: v97); /*0x141037594*/
        }
        status._Mypair._Myval2._Mysize = 0; /*0x141037599*/
        status._Mypair._Myval2._Myres = 15; /*0x1410375a1*/
        status._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410375ad*/
        v331._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410375b5*/
        v331._Mypair._Myval2._Mysize = 0; /*0x1410375bd*/
        v331._Mypair._Myval2._Myres = 15; /*0x1410375c5*/
        std::string::assign(this: &v331, _Ptr: "ClientTicket", _Count: 0xCu); /*0x1410375ee*/
        __wind /*0xf1c0000000001378*/
        {
          v7->testing = RBX::GameConfigurer::getParamString(this: v7, result: &v488, key: &v331)->_Mypair._Myval2._Mysize == 0; /*0x141037614*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v488); /*0x141037620*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v331); /*0xf1c0000000001370*/
        }
        if ( v331._Mypair._Myval2._Myres >= 0x10 ) /*0x141037632*/
        {
          v98 = v331._Mypair._Myval2._Bx._Ptr; /*0x141037637*/
          if ( v331._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141037649*/
          {
            v98 = *((char **)v331._Mypair._Myval2._Bx._Ptr - 1); /*0x14103764f*/
            if ( (unsigned __int64)(v331._Mypair._Myval2._Bx._Ptr - v98 - 8) > 0x1F ) /*0x14103765e*/
              _invalid_parameter_noinfo_noreturn(); /*0x141037660*/
          }
          operator delete(ptr: v98); /*0x141037667*/
        }
        v331._Mypair._Myval2._Mysize = 0; /*0x14103766c*/
        v331._Mypair._Myval2._Myres = 15; /*0x141037674*/
        v331._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141037680*/
        v7->logAnalytics = rand() % 100 == 1; /*0x1410376b0*/
        RBX::ServiceProvider::create<RBX::Network::Client>(this: &v7->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x1410376bc*/
        if ( DFFlag::SessionTelemetryTeleport.value ) /*0x1410376c8*/
        {
          LODWORD(v317) = RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2->storage.asRaw[0] /*0x1410376d5*/
                        - LODWORD(RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2);
          HIDWORD(v317) = RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2->storage.asRaw[1] /*0x1410376e1*/
                        - LODWORD(RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2);
          if ( v317 > 0 ) /*0x1410376f1*/
          {
            v99 = RBX::InferredCrash::getInstance(); /*0x1410376f3*/
            RBX::InferredCrash::onTeleport(this: v99); /*0x1410376fb*/
          }
        }
        dataModel = v7->dataModel; /*0x141037700*/
        v329._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141037704*/
        v329._Mypair._Myval2._Mysize = 0; /*0x14103770c*/
        v329._Mypair._Myval2._Myres = 15; /*0x141037714*/
        std::string::assign(this: &v329, _Ptr: "DataCenterId", _Count: 0xCu); /*0x14103773d*/
        __wind /*0xf1c0000000001360*/
        {
          v101 = RBX::GameConfigurer::getParamInt(this: v7, key: &v329); /*0x141037753*/
          v330._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141037755*/
          v330._Mypair._Myval2._Mysize = 0; /*0x14103775d*/
          v330._Mypair._Myval2._Myres = 15; /*0x141037765*/
          std::string::assign(this: &v330, _Ptr: "PlaceId", _Count: 7u); /*0x14103778e*/
          __wind /*0xf1c0000000001354*/
          {
            ParamInt64 = RBX::GameConfigurer::getParamInt64(this: v7, key: &v330); /*0x14103779f*/
            RBX::DataModel::setPlaceIdAndDataCenterId(this: dataModel, placeID: ParamInt64, centerId: v101); /*0x1410377ad*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v330); /*0xf1c000000000134c*/
          }
          if ( v330._Mypair._Myval2._Myres >= 0x10 ) /*0x1410377bf*/
          {
            v103 = v330._Mypair._Myval2._Bx._Ptr; /*0x1410377c4*/
            if ( v330._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410377d6*/
            {
              v103 = *((char **)v330._Mypair._Myval2._Bx._Ptr - 1); /*0x1410377dc*/
              if ( (unsigned __int64)(v330._Mypair._Myval2._Bx._Ptr - v103 - 8) > 0x1F ) /*0x1410377eb*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410377ed*/
            }
            operator delete(ptr: v103); /*0x1410377f4*/
          }
          v330._Mypair._Myval2._Mysize = 0; /*0x1410377f9*/
          v330._Mypair._Myval2._Myres = 15; /*0x141037801*/
          v330._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103780d*/
          if ( v329._Mypair._Myval2._Myres >= 0x10 ) /*0x141037821*/
          {
            v104 = v329._Mypair._Myval2._Bx._Ptr; /*0x141037826*/
            if ( v329._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141037838*/
            {
              v104 = *((char **)v329._Mypair._Myval2._Bx._Ptr - 1); /*0x14103783e*/
              if ( (unsigned __int64)(v329._Mypair._Myval2._Bx._Ptr - v104 - 8) > 0x1F ) /*0x14103784d*/
                _invalid_parameter_noinfo_noreturn(); /*0x14103784f*/
            }
            operator delete(ptr: v104); /*0x141037856*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v329); /*0xf1c0000000001340*/
        }
        v329._Mypair._Myval2._Mysize = 0; /*0x14103785b*/
        v329._Mypair._Myval2._Myres = 15; /*0x141037863*/
        v329._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103786f*/
        RBX::GameConfigurer::getParamString( /*0x141037889*/
          this: v7,
          result: &analyticsSessionId,
          key: &FString::AnalyticsSessionIdName);
        __wind
        {
          if ( analyticsSessionId._Mypair._Myval2._Mysize != 0 ) /*0x141037898*/
          {
            name._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103789e*/
            name._Mypair._Myval2._Mysize = 0; /*0x1410378a6*/
            name._Mypair._Myval2._Myres = 15; /*0x1410378ae*/
            std::string::assign(this: &name, _Ptr: "sid", _Count: 3u); /*0x1410378d7*/
            __wind /*0xf1c0000000001324*/
            {
              RBX::Analytics::EventIngest::addCommonArg(&name, value: &analyticsSessionId); /*0x1410378ed*/
              if ( name._Mypair._Myval2._Myres >= 0x10 ) /*0x1410378ff*/
              {
                v105 = name._Mypair._Myval2._Bx._Ptr; /*0x141037904*/
                if ( name._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141037916*/
                {
                  v105 = *((char **)name._Mypair._Myval2._Bx._Ptr - 1); /*0x14103791c*/
                  if ( (unsigned __int64)(name._Mypair._Myval2._Bx._Ptr - v105 - 8) > 0x1F ) /*0x14103792b*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14103792d*/
                }
                operator delete(ptr: v105); /*0x141037934*/
              }
              name._Mypair._Myval2._Mysize = 0; /*0x141037939*/
              name._Mypair._Myval2._Myres = 15; /*0x141037941*/
              name._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103794d*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&name); /*0xf1c000000000131c*/
            }
          }
          v323._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141037955*/
          v323._Mypair._Myval2._Mysize = 0; /*0x14103795d*/
          v323._Mypair._Myval2._Myres = 15; /*0x141037965*/
          std::string::assign(this: &v323, _Ptr: "UniverseId", _Count: 0xAu); /*0x14103798e*/
          __wind /*0xf1c000000000130c*/
          {
            v106 = RBX::GameConfigurer::getParamInt64(this: v7, key: &v323); /*0x14103799f*/
            universeId = v106; /*0x1410379a4*/
            if ( v323._Mypair._Myval2._Myres >= 0x10 ) /*0x1410379b8*/
            {
              v107 = v323._Mypair._Myval2._Bx._Ptr; /*0x1410379bd*/
              if ( v323._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410379cf*/
              {
                v107 = *((char **)v323._Mypair._Myval2._Bx._Ptr - 1); /*0x1410379d5*/
                if ( (unsigned __int64)(v323._Mypair._Myval2._Bx._Ptr - v107 - 8) > 0x1F ) /*0x1410379e4*/
                  _invalid_parameter_noinfo_noreturn(); /*0x1410379e6*/
              }
              operator delete(ptr: v107); /*0x1410379ed*/
              v106 = universeId; /*0x1410379f2*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v323); /*0xf1c0000000001304*/
          }
          v323._Mypair._Myval2._Mysize = 0; /*0x1410379fa*/
          v323._Mypair._Myval2._Myres = 15; /*0x141037a02*/
          v323._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141037a0e*/
          RBX::Analytics::setUniverseId(uid: v106); /*0x141037a19*/
          RBX::DataModel::setUniverseId(this: v7->dataModel, uId: universeId); /*0x141037a2a*/
          RBX::ServiceProvider::create<RBX::HttpService>(this: &v7->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x141037a37*/
          v108 = RBX::ServiceProvider::create<RBX::UserInputService>(this: &v78->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x141037a40*/
          v7->isTouchDevice = RBX::UserInputService::getTouchEnabled(this: v108); /*0x141037a4d*/
          if ( FLog::Output != 0 ) /*0x141037a58*/
          {
            v324._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141037a5e*/
            v324._Mypair._Myval2._Mysize = 0; /*0x141037a66*/
            v324._Mypair._Myval2._Myres = 15; /*0x141037a6e*/
            std::string::assign(this: &v324, _Ptr: "MachineAddress", _Count: 0xEu); /*0x141037a97*/
            __wind /*0xf1c00000000012f4*/
            {
              v109 = RBX::GameConfigurer::getParamString(this: v7, result: &v490, key: &v324); /*0x141037ab0*/
              v110 = (const char *)v109; /*0x141037ab5*/
              __wind /*0xf1c00000000012e8*/
              {
                if ( v109->_Mypair._Myval2._Myres >= 0x10 ) /*0x141037abd*/
                  v110 = v109->_Mypair._Myval2._Bx._Ptr; /*0x141037abf*/
                v325._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141037ac2*/
                v325._Mypair._Myval2._Mysize = 0; /*0x141037aca*/
                v325._Mypair._Myval2._Myres = 15; /*0x141037ad2*/
                std::string::assign(this: &v325, _Ptr: "PlaceId", _Count: 7u); /*0x141037afb*/
                __wind /*0xf1c00000000012dc*/
                {
                  v111 = RBX::GameConfigurer::getParamInt64(this: v7, key: &v325); /*0x141037b11*/
                  v322._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141037b14*/
                  v322._Mypair._Myval2._Mysize = 0; /*0x141037b1c*/
                  v322._Mypair._Myval2._Myres = 15; /*0x141037b24*/
                  std::string::assign(this: &v322, _Ptr: "GameId", _Count: 6u); /*0x141037b4d*/
                  __wind /*0xf1c00000000012a0*/
                  {
                    v112 = RBX::GameConfigurer::getParamString(this: v7, result: &v489, key: &v322); /*0x141037b66*/
                    __wind /*0xf1c0000000001294*/
                    {
                      if ( v112->_Mypair._Myval2._Myres >= 0x10 ) /*0x141037b71*/
                        v112 = (std::string *)v112->_Mypair._Myval2._Bx._Ptr; /*0x141037b73*/
                      FLog::FastLogFormatted( /*0x141037b8f*/
                        level: FLog::Output,
                        message: "[FLog::Output] ! Joining game '%s' place %lld at %s",
                        v112->_Mypair._Myval2._Bx._Buf,
                        v111,
                        v110);
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v489); /*0xf1c000000000128c*/
                    }
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v489); /*0x141037b9d*/
                    if ( v322._Mypair._Myval2._Myres >= 0x10 ) /*0x141037baf*/
                    {
                      v113 = v322._Mypair._Myval2._Bx._Ptr; /*0x141037bb4*/
                      if ( v322._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141037bc6*/
                      {
                        v113 = *((char **)v322._Mypair._Myval2._Bx._Ptr - 1); /*0x141037bcc*/
                        if ( (unsigned __int64)(v322._Mypair._Myval2._Bx._Ptr - v113 - 8) > 0x1F ) /*0x141037bdb*/
                          _invalid_parameter_noinfo_noreturn(); /*0x141037bdd*/
                      }
                      operator delete(ptr: v113); /*0x141037be4*/
                    }
                    v322._Mypair._Myval2._Mysize = 0; /*0x141037be9*/
                    v322._Mypair._Myval2._Myres = 15; /*0x141037bf1*/
                    v322._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141037bfd*/
                    if ( v325._Mypair._Myval2._Myres >= 0x10 ) /*0x141037c11*/
                    {
                      v114 = v325._Mypair._Myval2._Bx._Ptr; /*0x141037c16*/
                      if ( v325._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141037c28*/
                      {
                        v114 = *((char **)v325._Mypair._Myval2._Bx._Ptr - 1); /*0x141037c2e*/
                        if ( (unsigned __int64)(v325._Mypair._Myval2._Bx._Ptr - v114 - 8) > 0x1F ) /*0x141037c3d*/
                          _invalid_parameter_noinfo_noreturn(); /*0x141037c3f*/
                      }
                      operator delete(ptr: v114); /*0x141037c46*/
                    }
                    v325._Mypair._Myval2._Mysize = 0; /*0x141037c4b*/
                    v325._Mypair._Myval2._Myres = 15; /*0x141037c53*/
                    v325._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141037c5f*/
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v490); /*0x141037c6f*/
                    if ( v324._Mypair._Myval2._Myres >= 0x10 ) /*0x141037c81*/
                    {
                      v115 = v324._Mypair._Myval2._Bx._Ptr; /*0x141037c86*/
                      if ( v324._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141037c98*/
                      {
                        v115 = *((char **)v324._Mypair._Myval2._Bx._Ptr - 1); /*0x141037c9e*/
                        if ( (unsigned __int64)(v324._Mypair._Myval2._Bx._Ptr - v115 - 8) > 0x1F ) /*0x141037cad*/
                          _invalid_parameter_noinfo_noreturn(); /*0x141037caf*/
                      }
                      operator delete(ptr: v115); /*0x141037cb6*/
                    }
                    v324._Mypair._Myval2._Mysize = 0; /*0x141037cbb*/
                    v324._Mypair._Myval2._Myres = 15; /*0x141037cc3*/
                    v324._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141037ccf*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v322); /*0xf1c00000000012b0*/
                  }
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v325); /*0xf1c00000000012bc*/
                }
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v490); /*0xf1c00000000012c8*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v324); /*0xf1c00000000012d4*/
            }
          }
          if ( v11 != nullptr )
          {
            v380.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141037ce0*/
            *(__m128i *)&v380.text._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x141037cf0*/
            std::string::assign(this: &v380.text, _Ptr: "PlaceId", _Count: 7u); /*0x141037d16*/
            __wind /*0xf1c000000000127c*/
            {
              value = RBX::GameConfigurer::getParamInt64(this: v7, key: &v380.text); /*0x141037d2c*/
              v116 = RBX::StringConverter<__int64>::convertToString(result: &v495, &value); /*0x141037d49*/
              __wind /*0xf1c0000000001270*/
              {
                ptr._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141037d4c*/
                *(__m128i *)&ptr._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x141037d5c*/
                std::string::operator=(this: &ptr, _Ptr: "placeid"); /*0x141037d7c*/
                std::string::string(this: &v546, value: v116); /*0x141037d8c*/
                __wind /*0xf1c0000000001264*/
                {
                  v117 = RBX::StringConverter<__int64>::convertToString(result: &v494, value: &universeId); /*0x141037da2*/
                  __wind /*0xf1c0000000001258*/
                  {
                    std::pair<std::string const,std::string>::pair<std::string const,std::string>( /*0x141037dba*/
                      this: &v547,
                      _Val1: (const char (*)[7])"universeid",
                      _Val2: v117);
                    __wind /*0xf1c000000000124c*/
                    {
                      std::pair<std::string const,std::string>::pair<std::string const,std::string>( /*0x141037dd6*/
                        this: &v548,
                        _Val1: (const char (*)[14])"referral_page",
                        _Val2: (const std::string *)&v11[16]._Rep);
                      __wind /*0xf1c0000000001240*/
                      {
                        v118 = RBX::StringConverter<double>::convertToString( /*0x141037deb*/
                                 result: &v493,
                                 value: &v7->sgs.playerConfigureTime);
                        __wind /*0xf1c0000000001234*/
                        {
                          std::pair<std::string const,std::string>::pair<std::string const,std::string>( /*0x141037e03*/
                            this: &v549,
                            _Val1: (const char (*)[7])"join_time",
                            _Val2: v118);
                          __wind /*0xf1c0000000001228*/
                          {
                            v119 = RBX::StringConverter<__int64>::convertToString(result: &v492, value: &v7->userId); /*0x141037e15*/
                            __wind /*0xf1c000000000121c*/
                            {
                              std::pair<std::string const,std::string>::pair<std::string const,std::string>( /*0x141037e2d*/
                                this: &v550,
                                _Val1: (const char (*)[7])"userid",
                                _Val2: v119);
                              __wind /*0xf1c0000000001210*/
                              {
                                v349 = (double)(int)RBX::Time::epochTimeMs() / 1000.0; /*0x141037e48*/
                                v120 = RBX::StringConverter<double>::convertToString(result: &v491, value: &v349); /*0x141037e61*/
                                __wind /*0xf1c00000000010dc*/
                                {
                                  std::pair<std::string const,std::string>::pair<std::string const,std::string>( /*0x141037e79*/
                                    this: &v551,
                                    _Val1: (const char (*)[7])"clienttime",
                                    _Val2: v120);
                                }
                                __unwind
                                {
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v491); /*0xf1c00000000010ec*/
                                }
                              }
                              __unwind
                              {
                                std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>(this: (ScopedFlagOverrider::FlagItem *)&v550); /*0xf1c00000000010f8*/
                              }
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v492); /*0xf1c0000000001104*/
                            }
                          }
                          __unwind
                          {
                            std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>(this: (ScopedFlagOverrider::FlagItem *)&v549); /*0xf1c0000000001110*/
                          }
                        }
                        __unwind
                        {
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v493); /*0xf1c000000000111c*/
                        }
                      }
                      __unwind
                      {
                        std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>(this: (ScopedFlagOverrider::FlagItem *)&v548); /*0xf1c0000000001128*/
                      }
                    }
                    __unwind
                    {
                      std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>(this: (ScopedFlagOverrider::FlagItem *)&v547); /*0xf1c0000000001134*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v494); /*0xf1c0000000001140*/
                  }
                }
                __unwind
                {
                  std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>(this: (ScopedFlagOverrider::FlagItem *)&ptr); /*0xf1c000000000114c*/
                }
                __wind /*0xf1c0000000001154*/
                {
                  __wind /*0xf1c000000000115c*/
                  {
                    __wind /*0xf1c0000000001164*/
                    {
                      __wind /*0xf1c000000000116c*/
                      {
                        __wind /*0xf1c0000000001174*/
                        {
                          v376._First = (const std::pair<std::string const ,std::string > *)&ptr; /*0x141037e87*/
                          v376._Last = (const std::pair<std::string const ,std::string > *)&v552; /*0x141037e97*/
                          std::unordered_map<std::string,std::string>::unordered_map<std::string,std::string>( /*0x141037eaf*/
                            this: &_Right,
                            _Ilist: &v376);
                        }
                        __unwind
                        {
                          `eh vector destructor iterator'( /*0x1431e6e82*/
                            &ptr,
                            size: 0x40u,
                            count: 6u,
                            destructor: (void (__fastcall *)(void *))std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>);
                        }
                        __wind /*0xf1c000000000118c*/
                        {
                          `eh vector destructor iterator'( /*0x141037ecd*/
                            &ptr,
                            size: 0x40u,
                            count: 6u,
                            destructor: (void (__fastcall *)(void *))std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>);
                        }
                        __unwind
                        {
                          std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &_Right); /*0xf1c000000000119c*/
                        }
                      }
                      __unwind
                      {
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v491); /*0xf1c00000000011a8*/
                      }
                      __wind /*0xf1c00000000011b0*/
                      {
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v491); /*0x141037edb*/
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v492); /*0x141037ee9*/
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v493); /*0x141037ef7*/
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v494); /*0x141037f05*/
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v495); /*0x141037f13*/
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v380); /*0x141037f21*/
                      }
                      __unwind
                      {
                        std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &_Right); /*0xf1c00000000011c0*/
                      }
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v492); /*0xf1c00000000011cc*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v493); /*0xf1c00000000011d8*/
                  }
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v494); /*0xf1c00000000011e4*/
                }
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v495); /*0xf1c00000000011f0*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v380); /*0xf1c00000000011fc*/
            }
            __wind
            {
              std::string::string(this: &v440, _Ptr: "sid"); /*0x141037f35*/
              __wind /*0xf1c00000000010d0*/
              {
                RBX::Analytics::EventIngest::appendCommonArg(name: &v440, args: &_Right); /*0x141037f4b*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v440); /*0x141037f59*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v440); /*0xf1c00000000010c8*/
              }
              clientOsVersion_temp = (unsigned __int64)&v552; /*0x141037f66*/
              v121 = std::unordered_map<std::string,std::string>::unordered_map<std::string,std::string>( /*0x141037f7e*/
                       this: &v552,
                       &_Right);
              __wind /*0xf1c00000000010b8*/
              {
                v122 = v121; /*0x141037f83*/
                *(_QWORD *)&client = &v496; /*0x141037f8e*/
                v123 = std::string::string(this: &v496, _Ptr: "game_join_loadtime"); /*0x141037fa2*/
                __wind /*0xf1c00000000010ac*/
                {
                  v124 = v123; /*0x141037fa7*/
                  players = (RBX::Players *)&v497; /*0x141037fb2*/
                  v125 = std::string::string(this: &v497, _Ptr: "report"); /*0x141037fc9*/
                  __wind /*0xf1c000000000107c*/
                  {
                    v126 = v125; /*0x141037fce*/
                    v127 = std::string::string(this: &v498, _Ptr: "client"); /*0x141037fe0*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)players); /*0xf1c000000000108c*/
                  }
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)client); /*0xf1c0000000001098*/
                }
              }
              __unwind
              {
                std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: (void *)clientOsVersion_temp); /*0xf1c00000000010a4*/
              }
              RBX::Analytics::EventIngest::setRBXEventStream( /*0x141037ff2*/
                target: v127,
                eventContext: v126,
                eventName: v124,
                additionalArgs: v122);
              __wind
              {
                v128 = FLog::GameJoinLoadTime; /*0x141037ff7*/
                if ( FLog::GameJoinLoadTime != 0 )
                {
                  reportStr._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141038007*/
                  *(__m128i *)&reportStr._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x141038017*/
                  Myhead = _Right._List._Mypair._Myval2._Myhead; /*0x141038028*/
                  Next = _Right._List._Mypair._Myval2._Myhead->_Next; /*0x141038030*/
                  if ( _Right._List._Mypair._Myval2._Myhead->_Next != _Right._List._Mypair._Myval2._Myhead ) /*0x141038036*/
                  {
                    do /*0x1410380f1*/
                    {
                      std::pair<std::string const,std::string>::pair<std::string const,std::string>( /*0x14103804c*/
                        this: (RBX::GImage::Error *)&item,
                        __that: (const RBX::GImage::Error *)&Next->_Myval);
                      __wind /*0xf1c000000000104c*/
                      {
                        v131 = std::operator+<char>(result: &v501, _Left: &item.first, _Right: ":"); /*0x141038069*/
                        __wind /*0xf1c0000000001040*/
                        {
                          v132 = std::operator+<char>(result: &v500, _Left: v131, _Right: &item.second); /*0x141038082*/
                          __wind /*0xf1c0000000001034*/
                          {
                            v133 = std::operator+<char>(result: &v499, _Left: v132, _Right: ", "); /*0x14103809a*/
                            __wind /*0xf1c0000000000ff8*/
                            {
                              std::string::append(this: &reportStr, _Right: v133); /*0x1410380ab*/
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v499); /*0x1410380b9*/
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v500); /*0x1410380c7*/
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v501); /*0x1410380d5*/
                              std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>(this: (ScopedFlagOverrider::FlagItem *)&item); /*0x1410380e3*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v499); /*0xf1c0000000001008*/
                            }
                          }
                          __unwind
                          {
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v500); /*0xf1c0000000001014*/
                          }
                        }
                        __unwind
                        {
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v501); /*0xf1c0000000001020*/
                        }
                      }
                      __unwind
                      {
                        std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>(this: (ScopedFlagOverrider::FlagItem *)&item); /*0xf1c000000000102c*/
                      }
                      Next = Next->_Next; /*0x1410380eb*/
                    }
                    while ( Next != Myhead ); /*0x1410380f1*/
                    v128 = FLog::GameJoinLoadTime; /*0x1410380f7*/
                  }
                  if ( v128 != 0 )
                  {
                    v134 = std::string::c_str(this: (RBX::ContentId *)&reportStr); /*0x141038110*/
                    FLog::FastLogFormatted(
                      level: v128,
                      message: "[FLog::GameJoinLoadTime] Report game_join_loadtime: %s",
                      v134);
                  }
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&reportStr); /*0x14103812c*/
                }
                std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&_Right); /*0x14103813a*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&reportStr); /*0xf1c0000000001068*/
              }
            }
            __unwind
            {
              std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &_Right); /*0xf1c0000000001074*/
            }
          }
          std::string::string(this: &v442, _Ptr: "PlaceId"); /*0x14103814e*/
          __wind /*0xf1c0000000000fec*/
          {
            v350 = RBX::GameConfigurer::getParamInt64(this: v7, key: &v442); /*0x141038164*/
            v135 = RBX::StringConverter<__int64>::convertToString(result: &v503, value: &v350); /*0x14103817c*/
            __wind /*0xf1c0000000000fe0*/
            {
              std::pair<std::string const,std::string>::pair<std::string const,std::string>( /*0x141038194*/
                this: &v543,
                _Val1: (const char (*)[7])"placeid",
                _Val2: v135);
              __wind /*0xf1c0000000000fd4*/
              {
                v136 = RBX::StringConverter<__int64>::convertToString(result: &v502, value: &universeId); /*0x1410381aa*/
                __wind /*0xf1c0000000000f30*/
                {
                  std::pair<std::string const,std::string>::pair<std::string const,std::string>( /*0x1410381c2*/
                    this: &v544,
                    _Val1: (const char (*)[7])"universeid",
                    _Val2: v136);
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v502); /*0xf1c0000000000f40*/
                }
              }
              __unwind
              {
                std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>(this: (ScopedFlagOverrider::FlagItem *)&v543); /*0xf1c0000000000f4c*/
              }
              __wind /*0xf1c0000000000f54*/
              {
                __wind /*0xf1c0000000000f5c*/
                {
                  v375._First = &v543; /*0x1410381d0*/
                  v375._Last = (const std::pair<std::string const ,std::string > *)&ptr; /*0x1410381e0*/
                  std::unordered_map<std::string,std::string>::unordered_map<std::string,std::string>( /*0x1410381f8*/
                    this: &report,
                    _Ilist: &v375);
                }
                __unwind
                {
                  `eh vector destructor iterator'( /*0x1431e6f72*/
                    ptr: &v543,
                    size: 0x40u,
                    count: 2u,
                    destructor: (void (__fastcall *)(void *))std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>);
                }
                __wind /*0xf1c0000000000f74*/
                {
                  `eh vector destructor iterator'( /*0x141038216*/
                    ptr: &v543,
                    size: 0x40u,
                    count: 2u,
                    destructor: (void (__fastcall *)(void *))std::pair<RBX::ContentId const,std::string>::~pair<RBX::ContentId const,std::string>);
                }
                __unwind
                {
                  std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &report); /*0xf1c0000000000f84*/
                }
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v502); /*0xf1c0000000000f90*/
              }
              __wind /*0xf1c0000000000f98*/
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v502); /*0x141038224*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v503); /*0x141038232*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v442); /*0x141038240*/
              }
              __unwind
              {
                std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &report); /*0xf1c0000000000fa8*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v503); /*0xf1c0000000000fb4*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v442); /*0xf1c0000000000fc0*/
          }
          __wind /*0xf1c0000000000fc8*/
          {
            std::string::string(this: &v443, _Ptr: "sid"); /*0x141038254*/
            __wind /*0xf1c0000000000f24*/
            {
              RBX::Analytics::EventIngest::appendCommonArg(name: &v443, args: &report); /*0x14103826a*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v443); /*0x141038278*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v443); /*0xf1c0000000000f1c*/
            }
            v137 = RBX::SessionizedEventIngest::instance(result: &v390); /*0x141038285*/
            __wind /*0xf1c0000000000f0c*/
            {
              v138 = v137->_Ptr; /*0x14103828b*/
              sendEventDeferred = v137->_Ptr->sendEventDeferred; /*0x141038291*/
              std::string::string(this: &v456, _Ptr: "gameJoinPlaySession"); /*0x1410382a4*/
              __wind /*0xf1c0000000000f00*/
              {
                std::string::string(this: &v455, _Ptr: "report"); /*0x1410382b9*/
                __wind /*0xf1c0000000000ef4*/
                {
                  std::string::string(this: &v444, _Ptr: "client"); /*0x1410382ce*/
                  __wind /*0xf1c0000000000eb8*/
                  {
                    sendEventDeferred(this: v138, a2: &v444, a3: &v455, a4: &v456, a5: &report); /*0x1410382fc*/
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v444); /*0x141038307*/
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v455); /*0x141038315*/
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v456); /*0x141038323*/
                    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v390); /*0x141038331*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v444); /*0xf1c0000000000ec8*/
                  }
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v455); /*0xf1c0000000000ed4*/
                }
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v456); /*0xf1c0000000000ee0*/
              }
            }
            __unwind
            {
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v390); /*0xf1c0000000000eec*/
            }
            if ( FFlag::SessionGamePlayEvents3.value ) /*0x14103833d*/
            {
              v140 = RBX::SessionAppEventsHandler::instance(result: &v396); /*0x14103834b*/
              __wind /*0xf1c0000000000eac*/
              {
                v141 = v140->_Ptr; /*0x141038351*/
                std::string::string(this: &v479, _Ptr: aUser_9); /*0x141038363*/
                __wind /*0xf1c0000000000ea0*/
                {
                  v351 = RBX::GameConfigurer::getParamInt64(this: v7, key: &v479); /*0x141038379*/
                  v142 = RBX::StringConverter<__int64>::convertToString(result: &v506, value: &v351); /*0x141038396*/
                  __wind /*0xf1c0000000000e94*/
                  {
                    std::string::string(this: &v478, _Ptr: "PlaceId"); /*0x1410383a8*/
                    __wind /*0xf1c0000000000e88*/
                    {
                      v352 = RBX::GameConfigurer::getParamInt64(this: v7, key: &v478); /*0x1410383be*/
                      v143 = RBX::StringConverter<__int64>::convertToString(result: &v505, value: &v352); /*0x1410383db*/
                      __wind /*0xf1c0000000000e7c*/
                      {
                        std::string::string(this: &v477, _Ptr: "UniverseId"); /*0x1410383ed*/
                        __wind /*0xf1c0000000000e28*/
                        {
                          v359 = RBX::GameConfigurer::getParamInt64(this: v7, key: &v477); /*0x141038403*/
                          v144 = RBX::StringConverter<__int64>::convertToString(result: &v504, value: &v359); /*0x14103841b*/
                          __wind /*0xf1c0000000000e1c*/
                          {
                            RBX::SessionAppEventsHandler::onGameLoading( /*0x14103842d*/
                              this: v141,
                              universeId: v144,
                              placeId: v143,
                              userId: v142);
                          }
                          __unwind
                          {
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v504); /*0xf1c0000000000e14*/
                          }
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v504); /*0x14103843b*/
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v477); /*0x141038449*/
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v505); /*0x141038457*/
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v478); /*0x141038465*/
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v506); /*0x141038473*/
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v479); /*0x141038481*/
                          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v396); /*0x14103848f*/
                        }
                        __unwind
                        {
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v477); /*0xf1c0000000000e38*/
                        }
                      }
                      __unwind
                      {
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v505); /*0xf1c0000000000e44*/
                      }
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v478); /*0xf1c0000000000e50*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v506); /*0xf1c0000000000e5c*/
                  }
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v479); /*0xf1c0000000000e68*/
                }
              }
              __unwind
              {
                std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v396); /*0xf1c0000000000e74*/
              }
            }
            p_closingSignal = &v7->dataModel->closingSignal; /*0x141038498*/
            *(_QWORD *)&client = RBX::PlayerConfigurer::onGameClose; /*0x1410384a6*/
            DWORD2(client) = 0; /*0x1410384ab*/
            function.f_.f_ = client; /*0x1410384b8*/
            function.l_.a1_.t_ = v7; /*0x1410384c0*/
            v146 = rbx::signal<void (RBX::Reflection::PropertyDescriptor const *)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RobloxScriptDoc,RBX::Reflection::PropertyDescriptor const *>,boost::_bi::list2<boost::_bi::value<RobloxScriptDoc *>,boost::arg<1>>>>( /*0x1410384d8*/
                     this: p_closingSignal,
                     result: &v360,
                     &function);
            __wind /*0xf1c0000000000e04*/
            {
              std::vector<rbx::signals::connection>::push_back(this: &v7->connections, _Val: v146); /*0x1410384e8*/
              rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v360); /*0x1410384f6*/
            }
            __unwind
            {
              rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v360); /*0xf1c0000000000dfc*/
            }
            v147 = RBX::ServiceProvider::create<RBX::ChangeHistoryService>(this: &v7->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x141038503*/
            RBX::ChangeHistoryService::setEnabled(this: v147, state: false); /*0x14103850d*/
            RBX::ServiceProvider::create<RBX::ContentProvider>(this: &v7->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x14103851a*/
            RBX::ServiceProvider::create<RBX::InsertService>(this: &v7->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x141038527*/
            v148 = (RBX::Reflection::EnumDesc<enum RBX::DataModelCreatorType> *)RBX::Reflection::EnumDesc<enum RBX::DataModelCreatorType>::singleton(); /*0x141038531*/
            std::string::string(this: &v480, _Ptr: "CreatorTypeEnum"); /*0x141038543*/
            __wind /*0xf1c0000000000dec*/
            {
              v149 = (RBX::ContentId *)RBX::GameConfigurer::getParamString(this: v7, result: &v507, key: &v480); /*0x14103855c*/
              __wind /*0xf1c0000000000de0*/
              {
                v150 = std::string::c_str(this: v149); /*0x141038565*/
                RBX::Reflection::EnumDesc<enum RBX::Players::ChatOption>::convertToValue( /*0x141038578*/
                  this: v148,
                  text: v150,
                  value: &creatorType);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v507); /*0xf1c0000000000dd8*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v507); /*0x141038586*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v480); /*0x141038594*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v480); /*0xf1c0000000000dcc*/
            }
            v151 = v7->dataModel; /*0x141038599*/
            v152 = creatorType; /*0x14103859d*/
            std::string::string(this: &v481, _Ptr: "CreatorId"); /*0x1410385b3*/
            __wind /*0xf1c0000000000dbc*/
            {
              v153 = RBX::GameConfigurer::getParamInt64(this: v7, key: &v481); /*0x1410385c4*/
              RBX::DataModel::setCreatorID(this: v151, creatorID: v153, creatorType: v152); /*0x1410385d2*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v481); /*0xf1c0000000000db4*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v481); /*0x1410385e0*/
            v154 = RBX::ServiceProvider::create<RBX::Players>(this: &v7->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x1410385f2*/
            players = v154; /*0x1410385f5*/
            v155 = (RBX::Reflection::EnumDesc<enum RBX::DataModelCreatorType> *)RBX::Reflection::EnumDesc<enum RBX::Players::ChatOption>::singleton(); /*0x141038602*/
            std::string::string(this: &v482, _Ptr: "ChatStyle"); /*0x141038614*/
            __wind /*0xf1c0000000000da4*/
            {
              v156 = (RBX::ContentId *)RBX::GameConfigurer::getParamString(this: v7, result: &v508, key: &v482); /*0x14103862d*/
              __wind /*0xf1c0000000000d98*/
              {
                v157 = std::string::c_str(this: v156); /*0x141038636*/
                RBX::Reflection::EnumDesc<enum RBX::Players::ChatOption>::convertToValue( /*0x141038649*/
                  this: v155,
                  text: v157,
                  value: (RBX::DataModelCreatorType *)&chatOption);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v508); /*0xf1c0000000000d90*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v508); /*0x141038657*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v482); /*0x141038665*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v482); /*0xf1c0000000000d84*/
            }
            RBX::Players::setChatOption(this: v154, value: chatOption); /*0x141038674*/
            RBX::ServiceProvider::create<RBX::Visit>(this: &v7->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x141038681*/
            std::string::string(this: &v406, _Ptr: "Started join script"); /*0x141038695*/
            __wind /*0xf1c0000000000d5c*/
            {
              std::string::string(this: &v483, _Ptr: "SeleniumTest1"); /*0x1410386aa*/
              __wind /*0xf1c0000000000d50*/
              {
                RBX::PlayerConfigurer::ifSeleniumThenSetCookie(this: v7, key: &v483, value: &v406); /*0x1410386c3*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v483); /*0xf1c0000000000d48*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v483); /*0x1410386d1*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v406); /*0x1410386df*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v406); /*0xf1c0000000000d6c*/
            }
            try /*0xf1c0000000000d74*/
            {
              v244 = RBX::ServiceProvider::create<RBX::Network::Client>(this: &v78->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x1410386ee*/
              *(_QWORD *)&client = v244; /*0x1410386f1*/
              rhs[0] = (__int64)RBX::PlayerConfigurer::onConnectionAccepted; /*0x141038704*/
              LODWORD(rhs[1]) = 0; /*0x14103870c*/
              v383.f_.f_ = *(_OWORD *)rhs; /*0x14103871c*/
              v383.l_.a1_.t_ = v7; /*0x141038724*/
              v158 = rbx::signal<void (std::string,std::shared_ptr<RBX::Instance>)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::PlayerConfigurer,std::string const &,std::shared_ptr<RBX::Instance> const &>,boost::_bi::list3<boost::_bi::value<RBX::PlayerConfigurer *>,boost::arg<1>,boost::arg<2>>>>( /*0x14103873c*/
                       this: &v244->connectionAcceptedSignal,
                       result: &v354,
                       function: &v383);
              __wind /*0xf1c0000000000d38*/
              {
                std::vector<rbx::signals::connection>::push_back(this: &v7->connections, _Val: v158); /*0x14103874c*/
              }
              __unwind
              {
                rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v354); /*0xf1c0000000000d30*/
              }
              rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v354); /*0x14103875a*/
              rhs[0] = (__int64)RBX::PlayerConfigurer::onConnectionFailed; /*0x14103876d*/
              LODWORD(rhs[1]) = 0; /*0x141038775*/
              v397.f_.f_ = *(_OWORD *)rhs; /*0x141038785*/
              v397.l_.a1_.t_ = v7; /*0x14103878d*/
              v159 = rbx::signal<void (std::string,int,std::string)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::PlayerConfigurer,std::string const &,int,std::string const &>,boost::_bi::list4<boost::_bi::value<RBX::PlayerConfigurer *>,boost::arg<1>,boost::arg<2>,boost::arg<3>>>>( /*0x1410387a5*/
                       this: &v244->connectionFailedSignal,
                       result: &v356,
                       function: &v397);
              __wind /*0xf1c0000000000d20*/
              {
                std::vector<rbx::signals::connection>::push_back(this: &v7->connections, _Val: v159); /*0x1410387b5*/
              }
              __unwind
              {
                rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v356); /*0xf1c0000000000d18*/
              }
              rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v356); /*0x1410387c3*/
              if ( v7->isStudioToRcc ) /*0x1410387c8*/
                RBX::Network::Client::configureAsCloudTestClient(this: v244); /*0x1410387d2*/
              std::string::string(this: &v407, _Ptr: "ClientTicket"); /*0x1410387e6*/
              __wind /*0xf1c0000000000d08*/
              {
                v160 = RBX::GameConfigurer::getParamString(this: v7, result: &v509, key: &v407); /*0x1410387ff*/
                __wind /*0xf1c0000000000cfc*/
                {
                  RBX::Network::Client::setTicket(this: v244, t: v160); /*0x14103880b*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v509); /*0xf1c0000000000cf4*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v509); /*0x141038819*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v407); /*0x141038827*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v407); /*0xf1c0000000000ce8*/
              }
              RBX::Network::Client::setPlaySessionId(this: v244, pid: &analyticsSessionId); /*0x141038837*/
              if ( FFlag::TelemetryInformationAsSubsystem.value ) /*0x141038843*/
              {
                v161 = RBX::SubsystemScopedHandle<RBX::Analytics::TelemetryInformation>::operator->(this: &v7->telemetryInformation); /*0x141038851*/
                std::string::string(this: &v408, _Ptr: "playSessionId"); /*0x141038863*/
                __wind /*0xf1c0000000000cd8*/
                {
                  RBX::Analytics::TelemetryInformation::addGlobalPointsField( /*0x14103887c*/
                    this: v161,
                    key: &v408,
                    value: &analyticsSessionId);
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v408); /*0xf1c0000000000cd0*/
                }
                v162 = (RBX::Graphics::ProfilerAdorn::Item *)&v408; /*0x141038882*/
              }
              else
              {
                std::string::string(this: &v409, _Ptr: "playSessionId"); /*0x14103889b*/
                __wind /*0xf1c0000000000cc0*/
                {
                  RBX::Analytics::DEPRECATED_TelemetryInformation::addGlobalPointsField( /*0x1410388b1*/
                    key: &v409,
                    value: &analyticsSessionId);
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v409); /*0xf1c0000000000cb8*/
                }
                v162 = (RBX::Graphics::ProfilerAdorn::Item *)&v409; /*0x1410388b7*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: v162); /*0x1410388bf*/
              std::string::string(this: &v411, _Ptr: "Successfully connected to server"); /*0x1410388d3*/
              __wind /*0xf1c0000000000ca8*/
              {
                std::string::string(this: &v410, _Ptr: "SeleniumTest2"); /*0x1410388e8*/
                __wind /*0xf1c0000000000c9c*/
                {
                  RBX::PlayerConfigurer::ifSeleniumThenSetCookie(this: v7, key: &v410, value: &v411); /*0x141038901*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v410); /*0xf1c0000000000c94*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v410); /*0x14103890f*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v411); /*0x14103891d*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v411); /*0xf1c0000000000c88*/
              }
              std::string::string(this: &v412, _Ptr: "SessionId"); /*0x141038931*/
              __wind /*0xf1c0000000000c78*/
              {
                v163 = RBX::GameConfigurer::getParamString(this: v7, result: &v510, key: &v412); /*0x14103894a*/
                RBX::Network::Client::setGameSessionID(this: v244, value: v163); /*0x141038955*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v412); /*0xf1c0000000000c70*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v412); /*0x141038963*/
              if ( !DFFlag::DeprecateLocalPlayerCreatedSignal.value ) /*0x14103896f*/
              {
                rhs[0] = (__int64)RBX::PlayerConfigurer::createPlayer; /*0x141038980*/
                LODWORD(rhs[1]) = 0; /*0x141038988*/
                *(_OWORD *)&v381.x = *(_OWORD *)rhs; /*0x141038998*/
                *(_QWORD *)&v381.color = v7; /*0x1410389a0*/
                v164 = rbx::signal<void (RBX::Reflection::PropertyDescriptor const *)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RobloxScriptDoc,RBX::Reflection::PropertyDescriptor const *>,boost::_bi::list2<boost::_bi::value<RobloxScriptDoc *>,boost::arg<1>>>>( /*0x1410389b8*/
                         this: &v154->localPlayerCreate_deprecated,
                         result: &v357,
                         function: (boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::PlayerConfigurer>,boost::_bi::list1<boost::_bi::value<RBX::PlayerConfigurer *> > > *)&v381.x);
                __wind /*0xf1c0000000000c60*/
                {
                  std::vector<rbx::signals::connection>::push_back(this: &v7->connections, _Val: v164); /*0x1410389c8*/
                }
                __unwind
                {
                  rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v357); /*0xf1c0000000000c58*/
                }
                rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v357); /*0x1410389d6*/
              }
              std::unordered_map<std::string,RBX::Reflection::Variant>::unordered_map<std::string,RBX::Reflection::Variant>(this: &playerInfoTable); /*0x1410389e3*/
              __wind /*0xf1c0000000000c48*/
              {
                rhs[0] = (__int64)RBX::PlayerConfigurer::connectPlayerToSignals; /*0x1410389f8*/
                LODWORD(rhs[1]) = 0; /*0x141038a00*/
                v382.f_.f_ = *(_OWORD *)rhs; /*0x141038a10*/
                v382.l_.a1_.t_ = v7; /*0x141038a18*/
                v165 = rbx::signal<void (std::shared_ptr<RBX::Instance>)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RobloxIDEDoc,std::shared_ptr<RBX::Instance>>,boost::_bi::list2<boost::_bi::value<RobloxIDEDoc *>,boost::arg<1>>>>( /*0x141038a30*/
                         this: &v154->connectPlayerSignals,
                         result: &v355,
                         function: &v382);
                __wind /*0xf1c0000000000c3c*/
                {
                  std::vector<rbx::signals::connection>::push_back(this: &v7->connections, _Val: v165); /*0x141038a40*/
                }
                __unwind
                {
                  rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v355); /*0xf1c0000000000c34*/
                }
                rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v355); /*0x141038a4e*/
                std::string::string(this: &v413, _Ptr: aUser_9); /*0x141038a62*/
                __wind /*0xf1c0000000000c24*/
                {
                  userId = RBX::GameConfigurer::getParamInt64(this: v7, key: &v413); /*0x141038a78*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v413); /*0xf1c0000000000c1c*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v413); /*0x141038a88*/
                std::string::string(this: &_Keyval, _Ptr: aUser_9); /*0x141038a9c*/
                __wind /*0xf1c0000000000c0c*/
                {
                  v166 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141038ab2*/
                           this: &playerInfoTable,
                           &_Keyval);
                  RBX::Reflection::Variant::operator=<__int64 &,0>(this: v166, rhs: &userId); /*0x141038ac2*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&_Keyval); /*0xf1c0000000000c04*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&_Keyval); /*0x141038ad0*/
                LOBYTE(clientOsVersion_temp) = RBX::TeleportService::getPreviousPlaceId() > 0; /*0x141038add*/
                std::string::string(this: &v415, _Ptr: "IsTeleportedIn"); /*0x141038af4*/
                __wind /*0xf1c0000000000bf4*/
                {
                  v167 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141038b0a*/
                           this: &playerInfoTable,
                           _Keyval: &v415);
                  RBX::Reflection::Variant::operator=<bool,0>(this: v167, rhs: (bool *)&clientOsVersion_temp); /*0x141038b1a*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v415); /*0xf1c0000000000bec*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v415); /*0x141038b28*/
                rhs[0] = RBX::TeleportService::getPreviousUniverseId(); /*0x141038b32*/
                std::string::string(this: &v416, _Ptr: "PreviousUniverseId"); /*0x141038b49*/
                __wind /*0xf1c0000000000bdc*/
                {
                  v168 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141038b5f*/
                           this: &playerInfoTable,
                           _Keyval: &v416);
                  RBX::Reflection::Variant::operator=<__int64 const &,0>(this: v168, rhs); /*0x141038b6f*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v416); /*0xf1c0000000000bd4*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v416); /*0x141038b7d*/
                std::string::string(this: &v418, _Ptr: "UserName"); /*0x141038b91*/
                __wind /*0xf1c0000000000bc4*/
                {
                  v169 = RBX::GameConfigurer::getParamString(this: v7, result: &v511, key: &v418); /*0x141038baf*/
                  __wind /*0xf1c0000000000ba0*/
                  {
                    std::string::string(this: &v417, _Ptr: "UserName"); /*0x141038bc1*/
                    __wind /*0xf1c0000000000b94*/
                    {
                      v170 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141038bd7*/
                               this: &playerInfoTable,
                               _Keyval: &v417);
                      RBX::Reflection::Variant::operator=<std::string,0>(this: v170, rhs: v169); /*0x141038be2*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v417); /*0xf1c0000000000b8c*/
                    }
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v417); /*0x141038bf0*/
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v511); /*0x141038bfe*/
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v418); /*0x141038c0c*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v511); /*0xf1c0000000000bb0*/
                  }
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v418); /*0xf1c0000000000bbc*/
                }
                std::string::string(this: &v420, _Ptr: aDisplayn); /*0x141038c20*/
                __wind /*0xf1c0000000000b7c*/
                {
                  v171 = RBX::GameConfigurer::getParamString(this: v7, result: &v512, key: &v420); /*0x141038c39*/
                  __wind /*0xf1c0000000000b58*/
                  {
                    v172 = v171; /*0x141038c3e*/
                    std::string::string(this: &v419, _Ptr: aDisplayn); /*0x141038c50*/
                    __wind /*0xf1c0000000000b4c*/
                    {
                      v173 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141038c66*/
                               this: &playerInfoTable,
                               _Keyval: &v419);
                      RBX::Reflection::Variant::operator=<std::string,0>(this: v173, rhs: v172); /*0x141038c71*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v419); /*0xf1c0000000000b44*/
                    }
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v419); /*0x141038c7f*/
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v512); /*0x141038c8d*/
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v420); /*0x141038c9b*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v512); /*0xf1c0000000000b68*/
                  }
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v420); /*0xf1c0000000000b74*/
                }
                if ( FFlag::CLI56034.value ) /*0x141038ca7*/
                {
                  std::string::string(this: &v421, _Ptr: "RandomSeed1"); /*0x141038cbc*/
                  __wind /*0xf1c0000000000b34*/
                  {
                    v174 = RBX::GameConfigurer::getParamString(this: v7, result: &v513, key: &v421)->_Mypair._Myval2._Mysize; /*0x141038cda*/
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v513); /*0x141038ce6*/
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v421); /*0x141038cf4*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v421); /*0xf1c0000000000b2c*/
                  }
                  if ( v174 == 0 ) /*0x141038cfc*/
                  {
                    std::string::string(this: &counterName, _Ptr: "EncryptedUserScore_ClientNoReceive"); /*0x141038d0d*/
                    __wind /*0xf1c0000000000b1c*/
                    {
                      RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x141038d21*/
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0x141038d2f*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c0000000000b14*/
                    }
                  }
                }
                std::string::string(this: &v424, _Ptr: "RandomSeed1"); /*0x141038d43*/
                __wind /*0xf1c0000000000b04*/
                {
                  v175 = RBX::GameConfigurer::getParamString(this: v7, result: &v514, key: &v424); /*0x141038d5c*/
                  __wind /*0xf1c0000000000ae0*/
                  {
                    v176 = v175; /*0x141038d61*/
                    std::string::string(this: &v423, _Ptr: "RandomSeed1"); /*0x141038d73*/
                    __wind /*0xf1c0000000000ad4*/
                    {
                      v177 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141038d89*/
                               this: &playerInfoTable,
                               _Keyval: &v423);
                      RBX::Reflection::Variant::operator=<std::string,0>(this: v177, rhs: v176); /*0x141038d94*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v423); /*0xf1c0000000000acc*/
                    }
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v423); /*0x141038da2*/
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v514); /*0x141038db0*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v514); /*0xf1c0000000000af0*/
                  }
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v424); /*0xf1c0000000000afc*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v424); /*0x141038dbe*/
                v178 = (const std::shared_ptr<lm::StageResults> *)RBX::GlobalBasicSettings::singleton(); /*0x141038dc3*/
                std::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>( /*0x141038dd3*/
                  this: (std::shared_ptr<lm::StageResults> *)&basicSettings,
                  _Other: v178);
                __wind /*0xf1c0000000000abc*/
                {
                  if ( basicSettings._Ptr != nullptr ) /*0x141038de2*/
                  {
                    clientSettingsGuidName_temp = 0x1469C4FB8LL; /*0x141038deb*/
                    v179 = basicSettings._Ptr; /*0x141038e02*/
                    std::string::string(this: &v425, _Ptr: "Locale2IdRef"); /*0x141038e12*/
                    __wind /*0xf1c0000000000ab0*/
                    {
                      v180 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141038e28*/
                               this: &playerInfoTable,
                               _Keyval: &v425);
                      RBX::Reflection::Variant::operator=<std::string const &,0>(this: v180, rhs: &v179->referent); /*0x141038e37*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v425); /*0xf1c0000000000aa8*/
                    }
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v425); /*0x141038e45*/
                  }
                  v181 = (RBX::ContentId *)RBX::SystemUtil::osPlatform(result: &v515); /*0x141038e52*/
                  v182 = std::string::c_str(this: v181); /*0x141038e5a*/
                  v183 = 0; /*0x141038e5f*/
                  do /*0x141038e85*/
                  {
                    v184 = (unsigned __int8)v182[v183++]; /*0x141038e70*/
                    v185 = v184 - (unsigned __int8)aWin32[v183 - 1]; /*0x141038e7d*/
                  }
                  while ( v185 == 0 && v183 != 6 ); /*0x141038e85*/
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v515); /*0x141038e8f*/
                  if ( v185 == 0 ) /*0x141038e96*/
                  {
                    memset(&osvi.dwMajorVersion, 0, 152); /*0x141038ea1*/
                    osvi.dwOSVersionInfoSize = 156; /*0x141038ef1*/
                    GetVersionExA(lpVersionInformation: (LPOSVERSIONINFOA)&osvi); /*0x141038f04*/
                    *(_DWORD *)sync = osvi.wProductType; /*0x141038f12*/
                    RBX::format( /*0x141038f35*/
                      result: &osVersion,
                      fmt: "%ld.%ld.%c",
                      osvi.dwMajorVersion,
                      osvi.dwMinorVersion,
                      *(_QWORD *)sync);
                    __wind /*0xf1c0000000000a98*/
                    {
                      clientOsVersion_temp = 0x146A8E978LL; /*0x141038f42*/
                      std::string::string(this: &v426, _Ptr: "Locale2Info"); /*0x141038f61*/
                      __wind /*0xf1c0000000000a8c*/
                      {
                        v186 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141038f77*/
                                 this: &playerInfoTable,
                                 _Keyval: &v426);
                        RBX::Reflection::Variant::operator=<std::string const &,0>(this: v186, rhs: &osVersion); /*0x141038f87*/
                      }
                      __unwind
                      {
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v426); /*0xf1c0000000000a84*/
                      }
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v426); /*0x141038f95*/
                      v244->shortVer = osvi.wProductType & 3 /*0x141038fc1*/
                                     | (4 * ((4 * LOBYTE(osvi.dwMajorVersion)) | osvi.dwMinorVersion & 3));
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&osVersion); /*0x141038fd0*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&osVersion); /*0xf1c0000000000a78*/
                    }
                  }
                  std::string::string(this: &localeId, _Ptr: pass); /*0x141038fe4*/
                  __wind /*0xf1c0000000000a68*/
                  {
                    std::string::string(this: (std::string *)&v404.width, _Ptr: pass); /*0x141038ff9*/
                    __wind /*0xf1c0000000000a5c*/
                    {
                      std::string::string(this: &vrDevice, _Ptr: pass); /*0x14103900e*/
                      __wind /*0xf1c0000000000a50*/
                      {
                        std::string::string(this: &countryRegionCode, _Ptr: pass); /*0x141039023*/
                        __wind /*0xf1c0000000000a44*/
                        {
                          if ( FFlag::LocaleIdRefactor2.value ) /*0x141039030*/
                          {
                            GameLocaleIdFromParams = RBX::PlayerConfigurer::getGameLocaleIdFromParams( /*0x141039041*/
                                                       this: v7,
                                                       result: &v401);
                            std::string::operator=(this: &localeId, _Right: GameLocaleIdFromParams); /*0x141039051*/
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v401); /*0x14103905e*/
                            std::string::string(this: &v369, _Ptr: "LocaleId"); /*0x141039072*/
                            __wind /*0xf1c0000000000a38*/
                            {
                              v188 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039088*/
                                       this: &playerInfoTable,
                                       _Keyval: &v369);
                              RBX::Reflection::Variant::operator=<std::string const &,0>(this: v188, rhs: &localeId); /*0x141039098*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v369); /*0xf1c0000000000a30*/
                            }
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v369); /*0x1410390a6*/
                            std::string::string(this: &v368, _Ptr: "LocaleIdInternal"); /*0x1410390ba*/
                            __wind /*0xf1c0000000000a20*/
                            {
                              v189 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x1410390d0*/
                                       this: &playerInfoTable,
                                       _Keyval: &v368);
                              RBX::Reflection::Variant::operator=<std::string const &,0>(this: v189, rhs: &localeId); /*0x1410390e0*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v368); /*0xf1c0000000000a18*/
                            }
                            v190 = (RBX::Graphics::ProfilerAdorn::Item *)&v368; /*0x1410390e6*/
                          }
                          else
                          {
                            v191 = v7->dataModel; /*0x1410390f3*/
                            v192 = &v191->RBX::Described<RBX::DataModel,RBX::ServiceProvider>; /*0x1410390f7*/
                            if ( v191 == nullptr ) /*0x1410390fe*/
                              v192 = nullptr; /*0x1410390fe*/
                            v193 = RBX::ServiceProvider::find<RBX::LocalizationService>(serviceProvider: v192); /*0x141039107*/
                            clientOsVersion_temp = (unsigned __int64)&v401; /*0x141039112*/
                            v194 = std::string::string(this: &v401, _Ptr: "PlayerConfigurer::configure"); /*0x141039129*/
                            v195 = v194; /*0x14103912e*/
                            __wind /*0xf1c00000000009f0*/
                            {
                              v196 = RBX::PlayerConfigurer::getGameLocaleIdFromParams(this: v7, result: &v516); /*0x14103913c*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)clientOsVersion_temp); /*0xf1c0000000000a00*/
                            }
                            __wind /*0xf1c0000000000a08*/
                            {
                              RBX::LocalizationService::setGameLocaleId_deprecated( /*0x14103914b*/
                                this: v193,
                                localeId: v196,
                                callsite: v195);
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v516); /*0xf1c00000000009e8*/
                            }
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v516); /*0x141039159*/
                            v197 = RBX::LocalizationService::getInGameLocaleIdInternal_deprecated( /*0x14103916e*/
                                     this: v193,
                                     result: &v517);
                            __wind /*0xf1c00000000009d8*/
                            {
                              std::string::string(this: &v368, _Ptr: "LocaleIdInternal"); /*0x141039180*/
                              __wind /*0xf1c00000000009cc*/
                              {
                                v198 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039196*/
                                         this: &playerInfoTable,
                                         _Keyval: &v368);
                                RBX::Reflection::Variant::operator=<std::string,0>(this: v198, rhs: v197); /*0x1410391a1*/
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v368); /*0xf1c00000000009c4*/
                              }
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v368); /*0x1410391af*/
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v517); /*0x1410391bd*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v517); /*0xf1c00000000009b8*/
                            }
                            v199 = RBX::LocalizationService::getInGameLocaleIdInternal_deprecated( /*0x1410391cd*/
                                     this: v193,
                                     result: &v518);
                            std::string::operator=(this: (std::string *)&v404.width, _Right: v199); /*0x1410391dd*/
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v518); /*0x1410391ea*/
                            v200 = RBX::LocalizationService::getInGameLocaleId_deprecated(this: v193, result: &v519); /*0x1410391ff*/
                            __wind /*0xf1c00000000009a8*/
                            {
                              std::string::string(this: &v369, _Ptr: "LocaleId"); /*0x141039211*/
                              __wind /*0xf1c000000000099c*/
                              {
                                v201 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039227*/
                                         this: &playerInfoTable,
                                         _Keyval: &v369);
                                RBX::Reflection::Variant::operator=<std::string,0>(this: v201, rhs: v200); /*0x141039232*/
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v369); /*0xf1c0000000000994*/
                              }
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v369); /*0x141039240*/
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v519); /*0x14103924e*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v519); /*0xf1c0000000000988*/
                            }
                            v202 = RBX::LocalizationService::getInGameLocaleId_deprecated(this: v193, result: &v520); /*0x14103925e*/
                            std::string::operator=(this: &localeId, _Right: v202); /*0x14103926e*/
                            v190 = (RBX::Graphics::ProfilerAdorn::Item *)&v520; /*0x141039273*/
                          }
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: v190); /*0x14103927b*/
                          v203 = &v556->RBX::Described<RBX::DataModel,RBX::ServiceProvider>; /*0x14103928b*/
                          if ( v556 == nullptr ) /*0x14103928f*/
                            v203 = nullptr; /*0x14103928f*/
                          v204 = RBX::ServiceProvider::find<RBX::VRService>(serviceProvider: v203); /*0x141039293*/
                          v205 = v204; /*0x141039298*/
                          if ( v204 != nullptr ) /*0x14103929e*/
                          {
                            VRDeviceName = RBX::VRService::getVRDeviceName(this: v204, result: &v521); /*0x1410392b4*/
                            __wind /*0xf1c0000000000978*/
                            {
                              std::string::string(this: &v428, _Ptr: "VrDevice"); /*0x1410392c6*/
                              __wind /*0xf1c000000000096c*/
                              {
                                v207 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x1410392dc*/
                                         this: &playerInfoTable,
                                         _Keyval: &v428);
                                RBX::Reflection::Variant::operator=<std::string,0>(this: v207, rhs: VRDeviceName); /*0x1410392e7*/
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v428); /*0xf1c0000000000964*/
                              }
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v428); /*0x1410392f5*/
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v521); /*0x141039303*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v521); /*0xf1c0000000000958*/
                            }
                            v208 = RBX::VRService::getVRDeviceName(this: v205, result: &v522); /*0x141039313*/
                            std::string::operator=(this: &vrDevice, _Right: v208); /*0x141039323*/
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v522); /*0x141039330*/
                          }
                          std::string::string(this: &v430, _Ptr: "SuperSafeChat"); /*0x141039344*/
                          __wind /*0xf1c0000000000948*/
                          {
                            LOBYTE(v556) = RBX::GameConfigurer::getParamBool(this: v7, key: &v430); /*0x14103935a*/
                            std::string::string(this: &v429, _Ptr: "SuperSafeChat"); /*0x141039370*/
                            __wind /*0xf1c000000000093c*/
                            {
                              v209 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039386*/
                                       this: &playerInfoTable,
                                       _Keyval: &v429);
                              RBX::Reflection::Variant::operator=<bool,0>(this: v209, rhs: (bool *)&v556); /*0x141039396*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v429); /*0xf1c0000000000934*/
                            }
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v429); /*0x1410393a4*/
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v430); /*0x1410393b2*/
                          }
                          __unwind
                          {
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v430); /*0xf1c0000000000928*/
                          }
                          std::string::string(this: &v432, _Ptr: "MembershipType"); /*0x1410393c6*/
                          __wind /*0xf1c0000000000918*/
                          {
                            v210 = RBX::GameConfigurer::getParamString(this: v7, result: &v523, key: &v432); /*0x1410393df*/
                            __wind /*0xf1c00000000008f4*/
                            {
                              v211 = v210; /*0x1410393e4*/
                              std::string::string(this: &v431, _Ptr: "MembershipType"); /*0x1410393f6*/
                              __wind /*0xf1c00000000008e8*/
                              {
                                v212 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x14103940c*/
                                         this: &playerInfoTable,
                                         _Keyval: &v431);
                                RBX::Reflection::Variant::operator=<std::string,0>(this: v212, rhs: v211); /*0x141039417*/
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v431); /*0xf1c00000000008e0*/
                              }
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v431); /*0x141039425*/
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v523); /*0x141039433*/
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v432); /*0x141039441*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v523); /*0xf1c0000000000904*/
                            }
                          }
                          __unwind
                          {
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v432); /*0xf1c0000000000910*/
                          }
                          std::string::string(this: &v434, _Ptr: "AccountAge"); /*0x141039455*/
                          __wind /*0xf1c00000000008d0*/
                          {
                            LODWORD(v556) = RBX::GameConfigurer::getParamInt(this: v7, key: &v434); /*0x14103946b*/
                            std::string::string(this: &v433, _Ptr: "AccountAge"); /*0x141039481*/
                            __wind /*0xf1c00000000008c4*/
                            {
                              v213 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039497*/
                                       this: &playerInfoTable,
                                       _Keyval: &v433);
                              RBX::Reflection::Variant::operator=<int,0>(this: v213, rhs: (int *)&v556); /*0x1410394a7*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v433); /*0xf1c00000000008bc*/
                            }
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v433); /*0x1410394b5*/
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v434); /*0x1410394c3*/
                          }
                          __unwind
                          {
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v434); /*0xf1c00000000008b0*/
                          }
                          std::string::string(this: &v435, _Ptr: "CountryRegionCode"); /*0x1410394d7*/
                          __wind /*0xf1c00000000008a0*/
                          {
                            v214 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x1410394ed*/
                                     this: &playerInfoTable,
                                     _Keyval: &v435);
                            RBX::Reflection::Variant::operator=<std::string const &,0>( /*0x1410394fd*/
                              this: v214,
                              rhs: &countryCodeFromArgs);
                          }
                          __unwind
                          {
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v435); /*0xf1c0000000000898*/
                          }
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v435); /*0x14103950b*/
                          UserAgent = (std::string *)RBX::Http::getUserAgent(); /*0x141039515*/
                          std::string::string(this: &v436, _Ptr: "UserAgentStr"); /*0x141039527*/
                          __wind /*0xf1c0000000000888*/
                          {
                            v216 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x14103953d*/
                                     this: &playerInfoTable,
                                     _Keyval: &v436);
                            RBX::Reflection::Variant::operator=<std::string const &,0>(this: v216, rhs: UserAgent); /*0x141039548*/
                          }
                          __unwind
                          {
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v436); /*0xf1c0000000000880*/
                          }
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v436); /*0x141039556*/
                          v217 = RBX::SystemUtil::osPlatform(result: &v524); /*0x141039568*/
                          __wind /*0xf1c0000000000870*/
                          {
                            std::string::string(this: &v437, _Ptr: "OsPlatform"); /*0x14103957a*/
                            __wind /*0xf1c0000000000864*/
                            {
                              v218 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039590*/
                                       this: &playerInfoTable,
                                       _Keyval: &v437);
                              RBX::Reflection::Variant::operator=<std::string,0>(this: v218, rhs: v217); /*0x14103959b*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v437); /*0xf1c000000000085c*/
                            }
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v437); /*0x1410395a9*/
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v524); /*0x1410395b7*/
                          }
                          __unwind
                          {
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v524); /*0xf1c0000000000850*/
                          }
                          RobloxVersionSafe = RBX::DebugSettings::getRobloxVersionSafe(result: &v525); /*0x1410395c4*/
                          __wind /*0xf1c0000000000840*/
                          {
                            v220 = RobloxVersionSafe; /*0x1410395c9*/
                            std::string::string(this: &v438, _Ptr: "ClientRobloxVersion"); /*0x1410395db*/
                            __wind /*0xf1c0000000000834*/
                            {
                              v221 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x1410395f1*/
                                       this: &playerInfoTable,
                                       _Keyval: &v438);
                              RBX::Reflection::Variant::operator=<std::string,0>(this: v221, rhs: v220); /*0x1410395fc*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v438); /*0xf1c000000000082c*/
                            }
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v438); /*0x14103960a*/
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v525); /*0x141039618*/
                          }
                          __unwind
                          {
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v525); /*0xf1c0000000000820*/
                          }
                          if ( FFlag::DebugForceChatDisabled.value ) /*0x141039624*/
                          {
                            __eh34_enter_wind_state(155, 180); /*0xf1c0000000000814*/
                            v222 = std::string::string(this: &v361, _Ptr: "NoOne"); /*0x14103963a*/
                            std::string::string(this: &v377, _Ptr: "GameChatType"); /*0x14103964c*/
                            __wind /*0xf1c0000000000808*/
                            {
                              v223 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039662*/
                                       this: &playerInfoTable,
                                       _Keyval: &v377);
                              RBX::Reflection::Variant::operator=<std::string,0>(this: v223, rhs: v222); /*0x14103966d*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v377); /*0xf1c0000000000800*/
                            }
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v377); /*0x14103967b*/
                            v224 = (RBX::Graphics::ProfilerAdorn::Item *)&v361; /*0x141039681*/
                          }
                          else
                          {
                            std::string::string(this: &v377, _Ptr: "GameChatType"); /*0x14103969d*/
                            __wind /*0xf1c00000000007f0*/
                            {
                              isParamExist = RBX::GameConfigurer::isParamExist(this: v7, key: &v377); /*0x1410396b3*/
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v377); /*0x1410396be*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v377); /*0xf1c00000000007e8*/
                            }
                            if ( !isParamExist ) /*0x1410396c5*/
                            {
                              v229 = std::string::string(this: &v402, _Ptr: "AllUsers"); /*0x141039766*/
                              __wind /*0xf1c00000000007a0*/
                              {
                                v230 = v229; /*0x14103976b*/
                                std::string::string(this: &v361, _Ptr: "GameChatType"); /*0x14103977d*/
                                __wind /*0xf1c0000000000794*/
                                {
                                  v231 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039793*/
                                           this: &playerInfoTable,
                                           _Keyval: &v361);
                                  RBX::Reflection::Variant::operator=<std::string,0>(this: v231, rhs: v230); /*0x14103979e*/
                                }
                                __unwind
                                {
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v361); /*0xf1c000000000078c*/
                                }
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v361); /*0x1410397ac*/
                                v224 = (RBX::Graphics::ProfilerAdorn::Item *)&v402; /*0x1410397b2*/
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v402); /*0xf1c0000000000780*/
                              }
LABEL_410:
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: v224); /*0x1410397ba*/
                              if ( !v7->isStudioToRcc ) /*0x1410397c4*/
                              {
                                v232 = std::string::string(this: &v526, _Ptr: "AllUsers"); /*0x1410397d5*/
                                __wind /*0xf1c0000000000750*/
                                {
                                  v233 = v232; /*0x1410397da*/
                                  std::string::string(this: &v441, _Ptr: "GameChatType"); /*0x1410397ec*/
                                  __wind /*0xf1c0000000000744*/
                                  {
                                    v234 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039802*/
                                             this: &playerInfoTable,
                                             _Keyval: &v441);
                                    RBX::Reflection::Variant::operator=<std::string,0>(this: v234, rhs: v233); /*0x14103980d*/
                                  }
                                  __unwind
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v441); /*0xf1c000000000073c*/
                                  }
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v441); /*0x14103981b*/
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v526); /*0x141039829*/
                                }
                                __unwind
                                {
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v526); /*0xf1c0000000000760*/
                                }
                              }
                              try /*0xf1c000000000072c*/
                              {
                                if ( DFFlag::ConsumePlatformNameOverAlternateName.value ) /*0x141039836*/
                                {
                                  std::string::string(this: &v371, _Ptr: "PlatformName"); /*0x14103984b*/
                                  __eh34_enter_wind_state(189, 190); /*0xf1c0000000000724*/
                                  v235 = RBX::GameConfigurer::isParamExist(this: v7, key: &v371); /*0x141039861*/
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v371); /*0x14103986c*/
                                  if ( __eh34_unwind(190) ) /*0xf1c0000000000718*/
                                    goto unwind_state_190; /*0xf1c0000000000718*/
                                  __eh34_exit_wind_state(190, 189); /*0xf1c000000000071c*/
                                  if ( !v235 ) /*0x141039873*/
                                    goto LABEL_726; /*0x141039873*/
                                  std::string::string(this: &v373, _Ptr: "PlatformName"); /*0x141039888*/
                                  __eh34_enter_wind_state(189, 191); /*0xf1c0000000000710*/
                                  v236 = RBX::GameConfigurer::getParamString(this: v7, result: &v403, key: &v373); /*0x1410398a1*/
                                  __wind /*0xf1c00000000006ec*/
                                  {
                                    v237 = v236; /*0x1410398a6*/
                                    std::string::string(this: &v372, _Ptr: "PlatformName"); /*0x1410398b8*/
                                    __wind /*0xf1c00000000006e0*/
                                    {
                                      v238 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x1410398ce*/
                                               this: &playerInfoTable,
                                               _Keyval: &v372);
                                      RBX::Reflection::Variant::operator=<std::string,0>(this: v238, rhs: v237); /*0x1410398d9*/
                                    }
                                    __unwind
                                    {
                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v372); /*0xf1c00000000006d8*/
                                    }
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v372); /*0x1410398e7*/
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v403); /*0x1410398f5*/
                                    v239 = (RBX::Graphics::ProfilerAdorn::Item *)&v373; /*0x1410398fb*/
                                  }
                                  __unwind
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v403); /*0xf1c00000000006fc*/
                                  }
                                  if ( __eh34_unwind(191) ) /*0xf1c0000000000704*/
                                    goto unwind_state_191; /*0xf1c0000000000704*/
                                  __eh34_exit_wind_state(191, 189); /*0xf1c0000000000708*/
                                }
                                else
                                {
                                  std::string::string(this: &v373, _Ptr: "AlternateName"); /*0x141039917*/
                                  __eh34_enter_wind_state(189, 191); /*0xf1c00000000006cc*/
                                  v240 = RBX::GameConfigurer::isParamExist(this: v7, key: &v373); /*0x14103992d*/
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v373); /*0x141039938*/
                                  if ( __eh34_unwind(191) ) /*0xf1c00000000006b8*/
                                  {
unwind_state_191:
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v373); /*0xf1c00000000006bc*/
                                    __eh34_continue_unwinding(191, 189); /*0xf1c00000000006c0*/
                                  }
                                  __eh34_exit_wind_state(191, 189); /*0xf1c00000000006c4*/
                                  if ( !v240 ) /*0x14103993f*/
                                    goto LABEL_726; /*0x14103993f*/
                                  std::string::string(this: &v371, _Ptr: "AlternateName"); /*0x141039954*/
                                  __eh34_enter_wind_state(189, 190); /*0xf1c00000000006b0*/
                                  v241 = RBX::GameConfigurer::getParamString(this: v7, result: &v403, key: &v371); /*0x14103996d*/
                                  __wind /*0xf1c0000000000684*/
                                  {
                                    v242 = v241; /*0x141039972*/
                                    std::string::string(this: &v372, _Ptr: "AlternateName"); /*0x141039984*/
                                    __wind /*0xf1c0000000000678*/
                                    {
                                      v243 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x14103999a*/
                                               this: &playerInfoTable,
                                               _Keyval: &v372);
                                      RBX::Reflection::Variant::operator=<std::string,0>(this: v243, rhs: v242); /*0x1410399a5*/
                                    }
                                    __unwind
                                    {
                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v372); /*0xf1c0000000000670*/
                                    }
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v372); /*0x1410399b3*/
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v403); /*0x1410399c1*/
                                    v239 = (RBX::Graphics::ProfilerAdorn::Item *)&v371; /*0x1410399c7*/
                                  }
                                  __unwind
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v403); /*0xf1c0000000000694*/
                                  }
                                  if ( __eh34_unwind(190) ) /*0xf1c000000000069c*/
                                  {
unwind_state_190:
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v371); /*0xf1c00000000006a0*/
                                    __eh34_continue_unwinding(190, 189); /*0xf1c00000000006a4*/
                                  }
                                  __eh34_exit_wind_state(190, 189); /*0xf1c00000000006a8*/
                                }
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: v239); /*0x1410399cf*/
                              }
                              catch ( std::exception )
                              {
                                v7 = this; /*0x1410399da*/
                                v154 = players; /*0x1410399e2*/
                                v244 = (RBX::Network::Client *)client; /*0x1410399ea*/
                              }
LABEL_726:
                              std::string::string(this: &v446, _Ptr: "characterAppearanceId"); /*0x1410399ef*/
                              __wind /*0xf1c0000000000650*/
                              {
                                v556 = (RBX::DataModel *)RBX::GameConfigurer::getParamInt64(this: v7, key: &v446); /*0x141039a14*/
                                std::string::string(this: &v445, _Ptr: "CharacterAppearanceId"); /*0x141039a2b*/
                                __wind /*0xf1c0000000000644*/
                                {
                                  v245 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039a41*/
                                           this: &playerInfoTable,
                                           _Keyval: &v445);
                                  RBX::Reflection::Variant::operator=<__int64 const &,0>( /*0x141039a51*/
                                    this: v245,
                                    rhs: (const __int64 *)&v556);
                                }
                                __unwind
                                {
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v445); /*0xf1c000000000063c*/
                                }
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v445); /*0x141039a5f*/
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v446); /*0x141039a6d*/
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v446); /*0xf1c0000000000630*/
                              }
                              std::string::string(this: &v448, _Ptr: "CharacterAppearance"); /*0x141039a81*/
                              __wind /*0xf1c0000000000620*/
                              {
                                v246 = RBX::GameConfigurer::getParamString(this: v7, result: &v528, key: &v448); /*0x141039a9a*/
                                __wind /*0xf1c00000000005fc*/
                                {
                                  v247 = v246; /*0x141039a9f*/
                                  std::string::string(this: &v447, _Ptr: "CharacterAppearance"); /*0x141039ab1*/
                                  __wind /*0xf1c00000000005f0*/
                                  {
                                    v248 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039ac7*/
                                             this: &playerInfoTable,
                                             _Keyval: &v447);
                                    RBX::Reflection::Variant::operator=<std::string,0>(this: v248, rhs: v247); /*0x141039ad2*/
                                  }
                                  __unwind
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v447); /*0xf1c00000000005e8*/
                                  }
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v447); /*0x141039ae0*/
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v528); /*0x141039aee*/
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v448); /*0x141039afc*/
                                }
                                __unwind
                                {
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v528); /*0xf1c000000000060c*/
                                }
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v448); /*0xf1c0000000000618*/
                              }
                              std::string::string(this: &v450, _Ptr: "FollowUserId"); /*0x141039b10*/
                              __wind /*0xf1c00000000005d8*/
                              {
                                v556 = (RBX::DataModel *)RBX::GameConfigurer::getParamInt64(this: v7, key: &v450); /*0x141039b26*/
                                std::string::string(this: &v449, _Ptr: "FollowUserId"); /*0x141039b3d*/
                                __wind /*0xf1c00000000005cc*/
                                {
                                  v249 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039b53*/
                                           this: &playerInfoTable,
                                           _Keyval: &v449);
                                  RBX::Reflection::Variant::operator=<__int64 const &,0>( /*0x141039b63*/
                                    this: v249,
                                    rhs: (const __int64 *)&v556);
                                }
                                __unwind
                                {
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v449); /*0xf1c00000000005c4*/
                                }
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v449); /*0x141039b71*/
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v450); /*0xf1c00000000005b8*/
                              }
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v450); /*0x141039b7f*/
                              RawJoinData = (const rtc::webrtc_checks_impl::ToStringVal *)RBX::TeleportService::getRawJoinData(); /*0x141039b84*/
                              v251 = std::string::string(this: &v529, __that: RawJoinData); /*0x141039b94*/
                              v252 = std::string::string(this: (RBX::BinaryString *)&v530, value: &v251->val); /*0x141039ba9*/
                              __wind /*0xf1c00000000005a8*/
                              {
                                std::string::string(this: &v451, _Ptr: "RawJoinData"); /*0x141039bbb*/
                                __wind /*0xf1c000000000059c*/
                                {
                                  v253 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039bd1*/
                                           this: &playerInfoTable,
                                           _Keyval: &v451);
                                  RBX::Reflection::Variant::operator=<RBX::BinaryString,0>(this: v253, rhs: v252); /*0x141039bdc*/
                                }
                                __unwind
                                {
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v451); /*0xf1c0000000000594*/
                                }
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v451); /*0x141039bea*/
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v530); /*0x141039bf8*/
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v530); /*0xf1c0000000000588*/
                              }
                              if ( FFlag::LaunchData.value ) /*0x141039c04*/
                              {
                                v254 = std::string::string( /*0x141039c12*/
                                         this: &v538,
                                         __that: (const rtc::webrtc_checks_impl::ToStringVal *)&v7->userJoinDataOverrides);
                                v255 = std::string::string(this: (RBX::BinaryString *)&v404, value: &v254->val); /*0x141039c22*/
                                __wind /*0xf1c0000000000578*/
                                {
                                  v256 = v255; /*0x141039c27*/
                                  std::string::string(this: &v452, _Ptr: "ClientJoinData"); /*0x141039c39*/
                                  __wind /*0xf1c000000000056c*/
                                  {
                                    v257 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039c4f*/
                                             this: &playerInfoTable,
                                             _Keyval: &v452);
                                    RBX::Reflection::Variant::operator=<RBX::BinaryString,0>(this: v257, rhs: v256); /*0x141039c5a*/
                                  }
                                  __unwind
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v452); /*0xf1c0000000000564*/
                                  }
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v452); /*0x141039c68*/
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v404); /*0x141039c76*/
                                }
                                __unwind
                                {
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v404); /*0xf1c0000000000558*/
                                }
                              }
                              if ( FFlag::DebugLocalRccTicketTesting.value ) /*0x141039c82*/
                              {
                                std::string::string(this: &v453, _Ptr: "DebugGameId"); /*0x141039c93*/
                                __wind /*0xf1c0000000000548*/
                                {
                                  v258 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039ca9*/
                                           this: &playerInfoTable,
                                           _Keyval: &v453);
                                  RBX::Reflection::Variant::operator=<std::string const &,0>( /*0x141039cb8*/
                                    this: v258,
                                    rhs: &RBX::Http::gameID);
                                }
                                __unwind
                                {
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v453); /*0xf1c0000000000540*/
                                }
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v453); /*0x141039cc6*/
                              }
                              std::string::string(this: &v346, _Ptr: "IsUnknownOrUnder13"); /*0x141039cda*/
                              __wind /*0xf1c0000000000530*/
                              {
                                LOBYTE(v556) = RBX::GameConfigurer::getParamBool(this: v7, key: &v346); /*0x141039cf0*/
                                std::string::string(this: &v454, _Ptr: aIsunder1); /*0x141039d06*/
                                __wind /*0xf1c0000000000524*/
                                {
                                  v259 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039d1c*/
                                           this: &playerInfoTable,
                                           _Keyval: &v454);
                                  RBX::Reflection::Variant::operator=<bool,0>(this: v259, rhs: (bool *)&v556); /*0x141039d2c*/
                                }
                                __unwind
                                {
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v454); /*0xf1c000000000051c*/
                                }
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v454); /*0x141039d3a*/
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v346); /*0x141039d48*/
                                std::string::operator=( /*0x141039d5d*/
                                  this: &v154->confidentialLocalPlayerProperties.localeId,
                                  _Right: &localeId);
                                if ( !FFlag::LocaleIdRefactor2.value ) /*0x141039d69*/
                                  std::string::operator=( /*0x141039d7b*/
                                    this: &v154->confidentialLocalPlayerProperties.localeIdInternal,
                                    _Right: (std::string *)&v404.width);
                                std::string::operator=( /*0x141039d90*/
                                  this: &v154->confidentialLocalPlayerProperties.vrDevice,
                                  _Right: &vrDevice);
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v346); /*0xf1c0000000000510*/
                              }
                              std::string::operator=( /*0x141039da5*/
                                this: (RBX::ContentId *)&v154->confidentialLocalPlayerProperties.countryRegionCode,
                                __that: (const RBX::ContentId *)&countryCodeFromArgs);
                              std::make_shared<std::unordered_map<std::string,RBX::Reflection::Variant> const,std::unordered_map<std::string,RBX::Reflection::Variant> &>( /*0x141039dba*/
                                result: &sharedTable,
                                <_Args_0>: &playerInfoTable);
                              __wind /*0xf1c000000000049c*/
                              {
                                memset(&serverConnections, 0, sizeof(serverConnections)); /*0x141039dc3*/
                                if ( DFFlag::RuppHeaderFromClientEnabled3.value ) /*0x141039dea*/
                                {
                                  __eh34_enter_wind_state(211, 212); /*0xf1c0000000000494*/
                                  v260 = std::string::string(this: &v381.text, _Ptr: "ServerConnections"); /*0x141039dec*/
                                  RBX::PlayerConfigurer::fillServerConnectionsArrayFromConfig( /*0x141039dff*/
                                    this: v7,
                                    endpoints: &serverConnections,
                                    key: v260);
                                  __eh34_enter_wind_state(212, 218); /*0xf1c000000000041c*/
                                }
                                else
                                {
                                  __eh34_enter_wind_state(211, 212); /*0xf1c000000000048c*/
                                  std::string::string(this: &v381.text, _Ptr: "ServerConnections"); /*0x141039e09*/
                                  __wind /*0xf1c0000000000454*/
                                  {
                                    RBX::GameConfigurer::getValueArray( /*0x141039e22*/
                                      this: v7,
                                      result: &serverConnectionsArray,
                                      key: &v381.text);
                                  }
                                  __unwind
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v381); /*0xf1c0000000000464*/
                                  }
                                  __wind /*0xf1c000000000046c*/
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v381); /*0x141039e30*/
                                    if ( serverConnectionsArray._Ptr != nullptr ) /*0x141039e40*/
                                    {
                                      Myfirst = serverConnectionsArray._Ptr->_Mypair._Myval2._Myfirst; /*0x141039e46*/
                                      Mylast = serverConnectionsArray._Ptr->_Mypair._Myval2._Mylast; /*0x141039e49*/
                                      while ( Myfirst != Mylast ) /*0x141039e53*/
                                      {
                                        RBX::Reflection::Variant::get<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>( /*0x141039e64*/
                                          this: Myfirst,
                                          result: &oneServerConnection);
                                        __wind /*0xf1c000000000043c*/
                                        {
                                          v263 = (std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<Luau::Module>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<Luau::Module> > >,0> > *)oneServerConnection._Ptr; /*0x141039e6a*/
                                          std::string::string(this: &v346, _Ptr: "Address"); /*0x141039e81*/
                                          std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::find<void>( /*0x141039e99*/
                                            this: v263,
                                            result: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<Luau::Module> > > > > *)&startProgress,
                                            _Keyval: &v346);
                                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v346); /*0x141039ea6*/
                                          v264 = (std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<Luau::Module>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<Luau::Module> > >,0> > *)oneServerConnection._Ptr; /*0x141039eab*/
                                          std::string::string(this: &v346, _Ptr: "Port"); /*0x141039ec2*/
                                          std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::find<void>( /*0x141039eda*/
                                            this: v264,
                                            result: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<Luau::Module> > > > > *)&portIter,
                                            _Keyval: &v346);
                                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v346); /*0x141039ee7*/
                                          v265 = oneServerConnection._Ptr->_List._Mypair._Myval2._Myhead; /*0x141039ef4*/
                                          v266 = startProgress; /*0x141039ef8*/
                                          if ( startProgress != (std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > *)v265 /*0x141039f10*/
                                            && portIter._Ptr != v265 )
                                          {
                                            v267 = RBX::Reflection::Variant::get<int>(this: &portIter._Ptr->_Myval.second); /*0x141039f1b*/
                                            v268 = RBX::Reflection::Variant::get<std::string>( /*0x141039f29*/
                                                     this: (RBX::Reflection::Variant *)&v266[3],
                                                     result: &v404.text);
                                            v269 = RBX::Network::Client::ServerConnection::ServerConnection( /*0x141039f3c*/
                                                     this: &v553,
                                                     a: v268,
                                                     p: v267);
                                            __wind /*0xf1c0000000000430*/
                                            {
                                              std::vector<RBX::Network::Client::ServerConnection>::push_back( /*0x141039f4d*/
                                                this: &serverConnections,
                                                _Val: v269);
                                            }
                                            __unwind
                                            {
                                              RBX::Network::Client::ServerConnection::~ServerConnection(this: &v553); /*0xf1c0000000000428*/
                                            }
                                            RBX::Network::Client::ServerConnection::~ServerConnection(this: &v553); /*0x141039f5b*/
                                          }
                                          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&oneServerConnection); /*0x141039f69*/
                                          ++Myfirst; /*0x141039f6e*/
                                        }
                                        __unwind
                                        {
                                          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&oneServerConnection); /*0xf1c000000000044c*/
                                        }
                                      }
                                    }
                                  }
                                  __unwind
                                  {
                                    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&serverConnectionsArray); /*0xf1c000000000047c*/
                                  }
                                  __eh34_enter_wind_state(212, 218); /*0xf1c0000000000484*/
                                  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&serverConnectionsArray); /*0x141039f7f*/
                                }
                                memset(&udmuxEndpoint, 0, sizeof(udmuxEndpoint)); /*0x141039f87*/
                                RBX::Network::Rupp::TokenTlv::Token::Token(this: &token); /*0x141039fa0*/
                                ParamBool = false; /*0x141039fa5*/
                                if ( DFFlag::RuppHeaderFromClientEnabled3.value ) /*0x141039faf*/
                                {
                                  v271 = std::string::string(this: &v532, _Ptr: "UdmuxEndpoints"); /*0x141039fc4*/
                                  RBX::PlayerConfigurer::fillServerConnectionsArrayFromConfig( /*0x141039fd7*/
                                    this: v7,
                                    endpoints: &udmuxEndpoint,
                                    key: v271);
                                  std::string::string(this: &v457, _Ptr: "DirectServerReturn"); /*0x141039feb*/
                                  __wind /*0xf1c0000000000410*/
                                  {
                                    ParamBool = RBX::GameConfigurer::getParamBool(this: v7, key: &v457); /*0x14103a001*/
                                  }
                                  __unwind
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v457); /*0xf1c0000000000408*/
                                  }
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v457); /*0x14103a00c*/
                                  if ( FFlag::RuppTokEn4.value ) /*0x14103a018*/
                                  {
                                    std::string::string(this: &v458, _Ptr: "TokenValue"); /*0x14103a02d*/
                                    __wind /*0xf1c00000000003e0*/
                                    {
                                      RBX::GameConfigurer::getParamString(this: v7, result: &tokenValue64, key: &v458); /*0x14103a046*/
                                    }
                                    __unwind
                                    {
                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v458); /*0xf1c00000000003f0*/
                                    }
                                    __wind /*0xf1c00000000003f8*/
                                    {
                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v458); /*0x14103a054*/
                                      tokenValue._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103a059*/
                                      *(__m128i *)&tokenValue._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14103a069*/
                                      v272 = std::string::c_str(this: (RBX::ContentId *)&tokenValue64); /*0x14103a082*/
                                      __wind /*0xf1c00000000003d4*/
                                      {
                                        base64<unsigned char,std::char_traits<unsigned char>>::decode( /*0x14103a09a*/
                                          input: v272,
                                          length: tokenValue64._Mypair._Myval2._Mysize,
                                          output: &tokenValue);
                                        serverConnectionsArray = (std::shared_ptr<std::vector<RBX::Reflection::Variant> const >)*RBX::StringView::StringView(this: &v527, Str: &tokenValue); /*0x14103a0b7*/
                                        token = *RBX::Network::Rupp::TokenTlv::Token::Token( /*0x14103a0d9*/
                                                   this: (RBX::Network::Rupp::TokenTlv::Token *)&v380.x,
                                                   setType: GameService,
                                                   setToken: (RBX::StringView *)&serverConnectionsArray);
                                      }
                                      __unwind
                                      {
                                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&tokenValue); /*0xf1c00000000003cc*/
                                      }
                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&tokenValue); /*0x14103a0f4*/
                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&tokenValue64); /*0x14103a102*/
                                    }
                                    __unwind
                                    {
                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&tokenValue64); /*0xf1c00000000003c0*/
                                    }
                                  }
                                }
                                if ( FFlag::DebugLocalRccServerConnection.value && FFlag::DebugLocalRccRuppToken.value ) /*0x14103a11b*/
                                {
                                  std::string::string(this: &v459, _Ptr: "MachineAddress"); /*0x14103a130*/
                                  __wind /*0xf1c0000000000398*/
                                  {
                                    RBX::GameConfigurer::getParamString(this: v7, result: &machineAddress, key: &v459); /*0x14103a149*/
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v459); /*0x14103a157*/
                                  }
                                  __unwind
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v459); /*0xf1c00000000003a8*/
                                  }
                                  __wind /*0xf1c00000000003b0*/
                                  {
                                    if ( machineAddress._Mypair._Myval2._Mysize != 0 ) /*0x14103a165*/
                                    {
                                      v273 = std::string::c_str(this: (RBX::ContentId *)&machineAddress); /*0x14103a174*/
                                      RBX::RbxDbgInfo::SetServerIP(s: v273); /*0x14103a177*/
                                    }
                                    std::string::string(this: &v460, _Ptr: "ServerPort"); /*0x14103a18b*/
                                    __wind /*0xf1c000000000038c*/
                                    {
                                      v274 = RBX::GameConfigurer::getParamInt(this: v7, key: &v460); /*0x14103a1a1*/
                                    }
                                    __unwind
                                    {
                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v460); /*0xf1c0000000000384*/
                                    }
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v460); /*0x14103a1ab*/
                                    if ( v274 != 0 ) /*0x14103a1b2*/
                                      RBX::RbxDbgInfo::SetDebugServerPort(port: v274); /*0x14103a1b6*/
                                  }
                                  __unwind
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&machineAddress); /*0xf1c0000000000378*/
                                  }
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&machineAddress); /*0x14103a1c4*/
                                }
                                *(_QWORD *)&client = &v393; /*0x14103a1d1*/
                                v275 = (const StartGameStatistics *)std::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>::shared_ptr<RBX::GameJoinUtil::TeleportJoinGameState>( /*0x14103a1e6*/
                                                                      this: &v393,
                                                                      _Other: (const std::shared_ptr<lm::StageResults> *)&sharedTable);
                                __wind /*0xf1c0000000000368*/
                                {
                                  startProgress = (std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > *)v275; /*0x14103a1eb*/
                                  std::string::string(this: &v467, _Ptr: "IsUnknownOrUnder13"); /*0x14103a202*/
                                  __wind /*0xf1c000000000035c*/
                                  {
                                    LOBYTE(v556) = RBX::GameConfigurer::getParamBool(this: v7, key: &v467); /*0x14103a218*/
                                    players = (RBX::Players *)&v533; /*0x14103a227*/
                                    std::string::string(this: &v466, _Ptr: "UserName"); /*0x14103a23e*/
                                    __wind /*0xf1c0000000000350*/
                                    {
                                      v276 = (std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *)RBX::GameConfigurer::getParamString(this: v7, result: &v533, key: &v466); /*0x14103a257*/
                                      portIter._Ptr = v276; /*0x14103a25c*/
                                      __wind /*0xf1c0000000000344*/
                                      {
                                        std::string::string(this: &v465, _Ptr: "DataCenterId"); /*0x14103a273*/
                                        __wind /*0xf1c0000000000338*/
                                        {
                                          LODWORD(clientOsVersion_temp) = RBX::GameConfigurer::getParamInt( /*0x14103a289*/
                                                                            this: v7,
                                                                            key: &v465);
                                          std::string::string(this: &v464, _Ptr: "ClientPort"); /*0x14103a29f*/
                                          __wind /*0xf1c000000000032c*/
                                          {
                                            v277 = RBX::GameConfigurer::getParamInt(this: v7, key: &v464); /*0x14103a2b5*/
                                            std::string::string(this: &v463, _Ptr: "ServerPort"); /*0x14103a2c7*/
                                            __wind /*0xf1c0000000000320*/
                                            {
                                              v278 = RBX::GameConfigurer::getParamInt(this: v7, key: &v463); /*0x14103a2dd*/
                                              rhs[0] = (__int64)&v534; /*0x14103a2e7*/
                                              std::string::string(this: &v462, _Ptr: "MachineAddress"); /*0x14103a2fe*/
                                              __wind /*0xf1c0000000000314*/
                                              {
                                                v279 = RBX::GameConfigurer::getParamString( /*0x14103a317*/
                                                         this: v7,
                                                         result: &v534,
                                                         key: &v462);
                                                v280 = v279; /*0x14103a31c*/
                                                __wind /*0xf1c0000000000308*/
                                                {
                                                  std::string::string(this: &v461, _Ptr: aUser_9); /*0x14103a32e*/
                                                  __wind /*0xf1c0000000000200*/
                                                  {
                                                    v281 = RBX::GameConfigurer::getParamInt64(this: v7, key: &v461); /*0x14103a33f*/
                                                  }
                                                  __unwind
                                                  {
                                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v461); /*0xf1c0000000000210*/
                                                  }
                                                }
                                                __unwind
                                                {
                                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)rhs[0]); /*0xf1c000000000021c*/
                                                }
                                              }
                                              __unwind
                                              {
                                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v462); /*0xf1c0000000000228*/
                                              }
                                            }
                                            __unwind
                                            {
                                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v463); /*0xf1c0000000000234*/
                                            }
                                          }
                                          __unwind
                                          {
                                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v464); /*0xf1c0000000000240*/
                                          }
                                        }
                                        __unwind
                                        {
                                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v465); /*0xf1c000000000024c*/
                                        }
                                      }
                                      __unwind
                                      {
                                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)players); /*0xf1c0000000000258*/
                                      }
                                    }
                                    __unwind
                                    {
                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v466); /*0xf1c0000000000264*/
                                    }
                                  }
                                  __unwind
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v467); /*0xf1c0000000000270*/
                                  }
                                }
                                __unwind
                                {
                                  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)client); /*0xf1c000000000027c*/
                                }
                                __wind /*0xf1c0000000000284*/
                                {
                                  __wind /*0xf1c000000000028c*/
                                  {
                                    __wind /*0xf1c0000000000294*/
                                    {
                                      __wind /*0xf1c000000000029c*/
                                      {
                                        __wind /*0xf1c00000000002a4*/
                                        {
                                          __wind /*0xf1c00000000002ac*/
                                          {
                                            __wind /*0xf1c00000000002b4*/
                                            {
                                              RBX::Network::Client::playerConnect( /*0x14103a3bb*/
                                                this: v244,
                                                userId: v281,
                                                server_deprecated: v280,
                                                serverPort: v278,
                                                clientPort: v277,
                                                threadSleepTime: -1,
                                                dataCenterId: clientOsVersion_temp,
                                                userName: (std::string *)portIter._Ptr,
                                                isUnder13: (bool)v556,
                                                playerInfoTable: startProgress,
                                                serverConnectionsArg: &serverConnections,
                                                udmuxEndpointsArg: &udmuxEndpoint,
                                                &token,
                                                directServerReturn: ParamBool);
                                            }
                                            __unwind
                                            {
                                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v461); /*0xf1c00000000001f8*/
                                            }
                                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v461); /*0x14103a3c9*/
                                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v462); /*0x14103a3d7*/
                                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v463); /*0x14103a3e5*/
                                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v464); /*0x14103a3f3*/
                                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v465); /*0x14103a401*/
                                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v466); /*0x14103a40f*/
                                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v467); /*0x14103a41d*/
                                          }
                                          __unwind
                                          {
                                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v462); /*0xf1c00000000002c4*/
                                          }
                                        }
                                        __unwind
                                        {
                                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v463); /*0xf1c00000000002d0*/
                                        }
                                      }
                                      __unwind
                                      {
                                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v464); /*0xf1c00000000002dc*/
                                      }
                                    }
                                    __unwind
                                    {
                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v465); /*0xf1c00000000002e8*/
                                    }
                                  }
                                  __unwind
                                  {
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v466); /*0xf1c00000000002f4*/
                                  }
                                }
                                __unwind
                                {
                                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v467); /*0xf1c0000000000300*/
                                }
                                if ( FFlag::DebugSendAttemptsToDiagCase1.value ) /*0x14103a429*/
                                {
                                  v282 = RBX::Name::operator==(this: (RBX::Name *)&RBX::Analytics::location, name: "US") /*0x14103a444*/
                                      && v7->sgs.avatarR15
                                      && RBX::Name::operator==(this: (RBX::Name *)&v7->sgs.networkType, name: "4G")
                                      && isCoreCase1Devices();
                                  v283 = RBX::Time::nowFastSec() - v7->sgs.userClickTime; /*0x14103a47e*/
                                  if ( v282 ) /*0x14103a486*/
                                  {
                                    v284 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::placeId); /*0x14103a48f*/
                                    RBX::format(result: &reportSequence, fmt: "JoinTime_Case1_Attempt_%s", v284); /*0x14103a4a6*/
                                    __wind /*0xf1c00000000001e8*/
                                    {
                                      RBX::Analytics::EphemeralCounter::reportStats( /*0x14103a4ba*/
                                        category: &reportSequence,
                                        value: v283,
                                        blocking: false);
                                    }
                                    __unwind
                                    {
                                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&reportSequence); /*0xf1c00000000001e0*/
                                    }
                                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&reportSequence); /*0x14103a4c8*/
                                  }
                                }
                                if ( !v7->testing ) /*0x14103a4d2*/
                                {
                                  v285 = RBX::ServiceProvider::create<RBX::Visit>(this: &v7->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x14103a4e1*/
                                  v286 = std::string::string(this: &v535, _Ptr: pass); /*0x14103a4f3*/
                                  RBX::Visit::setUploadUrl(this: v285, value: v286); /*0x14103a4fe*/
                                }
                                v287 = v7->dataModel; /*0x14103a503*/
                                v288 = &v287->RBX::Described<RBX::DataModel,RBX::ServiceProvider>; /*0x14103a507*/
                                if ( v287 == nullptr ) /*0x14103a50e*/
                                  v288 = nullptr; /*0x14103a50e*/
                                v289 = RBX::ServiceProvider::create<RBX::RunService>(serviceProvider: v288); /*0x14103a512*/
                                RBX::RunService::setRunState(this: v289, newState: RS_RUNNING); /*0x14103a51f*/
                                if ( __eh34_unwind(218) ) /*0xf1c00000000001c8*/
                                {
                                  std::vector<RBX::Network::Client::ServerConnection>::~vector<RBX::Network::Client::ServerConnection>(this: &udmuxEndpoint); /*0xf1c00000000001cc*/
                                  __eh34_continue_unwinding(218, 212); /*0xf1c00000000001d0*/
                                }
                                __eh34_exit_wind_state(218, 212); /*0xf1c00000000001d4*/
                                std::vector<RBX::Network::Client::ServerConnection>::~vector<RBX::Network::Client::ServerConnection>(this: &udmuxEndpoint); /*0x14103a52d*/
                                std::vector<RBX::Network::Client::ServerConnection>::~vector<RBX::Network::Client::ServerConnection>(this: &serverConnections); /*0x14103a53b*/
                                std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&sharedTable); /*0x14103a549*/
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&countryRegionCode); /*0x14103a557*/
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&vrDevice); /*0x14103a565*/
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v404.width); /*0x14103a573*/
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&localeId); /*0x14103a581*/
                                std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&basicSettings); /*0x14103a58f*/
                                std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::~_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>(this: &playerInfoTable); /*0x14103a59d*/
                                if ( __eh34_unwind(212) ) /*0xf1c0000000001708*/
                                {
                                  std::vector<RBX::Network::Client::ServerConnection>::~vector<RBX::Network::Client::ServerConnection>(this: &serverConnections); /*0xf1c000000000170c*/
                                  __eh34_continue_unwinding(212, 211); /*0xf1c0000000001710*/
                                }
                                __eh34_exit_wind_state(212, 211); /*0xf1c0000000001714*/
                              }
                              __unwind
                              {
                                std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&sharedTable); /*0xf1c00000000004ac*/
                              }
                              goto LABEL_667; /*0xf1c00000000004a8*/
                            }
                            std::string::string(this: &v361, _Ptr: "GameChatType"); /*0x1410396da*/
                            __eh34_enter_wind_state(155, 180); /*0xf1c00000000007dc*/
                            v226 = RBX::GameConfigurer::getParamString(this: v7, result: &v402, key: &v361); /*0x1410396f3*/
                            __wind /*0xf1c00000000007c4*/
                            {
                              v227 = v226; /*0x1410396f8*/
                              std::string::string(this: &v439, _Ptr: "GameChatType"); /*0x14103970a*/
                              __wind /*0xf1c00000000007b8*/
                              {
                                v228 = std::unordered_map<std::string,RBX::Reflection::Variant>::operator[]( /*0x141039720*/
                                         this: &playerInfoTable,
                                         _Keyval: &v439);
                                RBX::Reflection::Variant::operator=<std::string,0>(this: v228, rhs: v227); /*0x14103972b*/
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v439); /*0xf1c00000000007b0*/
                              }
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v439); /*0x141039739*/
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v402); /*0x141039747*/
                              v224 = (RBX::Graphics::ProfilerAdorn::Item *)&v361; /*0x14103974d*/
                            }
                            __unwind
                            {
                              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v402); /*0xf1c00000000007d4*/
                            }
                          }
                          if ( __eh34_unwind(180) ) /*0xf1c0000000000768*/
                          {
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v361); /*0xf1c000000000076c*/
                            __eh34_continue_unwinding(180, 155); /*0xf1c0000000000770*/
                          }
                          __eh34_exit_wind_state(180, 155); /*0xf1c0000000000774*/
                          goto LABEL_410; /*0xf1c0000000000778*/
                        }
                        __unwind
                        {
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&countryRegionCode); /*0xf1c00000000004b8*/
                        }
                      }
                      __unwind
                      {
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&vrDevice); /*0xf1c00000000004c4*/
                      }
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v404.width); /*0xf1c00000000004d0*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&localeId); /*0xf1c00000000004dc*/
                  }
                }
                __unwind
                {
                  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&basicSettings); /*0xf1c00000000004e8*/
                }
              }
              __unwind
              {
                std::unordered_map<std::string,RBX::Reflection::Variant>::~unordered_map<std::string,RBX::Reflection::Variant>(this: &playerInfoTable); /*0xf1c00000000004f4*/
              }
            }
            catch ( std::exception *&v404.x )
            {
              std::string::string(this: (std::string *)&v469.x, _Ptr: "CreatePlayer"); /*0x1431e785b*/
              __wind /*0xf1c00000000000e0*/
              {
                v294 = (const char *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)&v404.x + 8LL))(a1: *(_QWORD *)&v404.x); /*0x1431e786b*/
                std::string::string(this: &v469.text, _Ptr: v294); /*0x1431e7878*/
                __wind /*0xf1c00000000000d4*/
                {
                  RBX::PlayerConfigurer::reportError(this, error: &v469.text, msg: (const std::string *)&v469.x); /*0x1431e7893*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v469); /*0xf1c00000000000cc*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v469); /*0x1431e78a0*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v469.x); /*0x1431e78ad*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v469.x); /*0xf1c00000000000c0*/
              }
              v7 = this; /*0x14103a5a5*/
            }
LABEL_667:
            v290 = RBX::InferredCrash::getInstance(); /*0x14103a5ad*/
            std::string::string(this: &v470, _Ptr: aUser_9); /*0x14103a5c4*/
            __wind /*0xf1c00000000001bc*/
            {
              v291 = RBX::GameConfigurer::getParamInt64(this: v7, key: &v470); /*0x14103a5d5*/
              RBX::InferredCrash::onGameStart(this: v290, userId: v291); /*0x14103a5e0*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v470); /*0xf1c00000000001b4*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v470); /*0x14103a5ee*/
            if ( DFFlag::UseNewEngineStabilityMetrics.value ) /*0x14103a5fa*/
            {
              v292 = RBX::EngineStabilityStats::getInstance(); /*0x14103a601*/
              std::string::string(this: &v471, _Ptr: aUser_9); /*0x14103a613*/
              __wind /*0xf1c00000000001a4*/
              {
                v293 = RBX::GameConfigurer::getParamInt64(this: v7, key: &v471); /*0x14103a624*/
                RBX::EngineStabilityStats::updateUserId(this: v292, newUserId: v293); /*0x14103a62f*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v471); /*0xf1c000000000019c*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v471); /*0x14103a63d*/
            }
            std::string::string(this: &v473, _Ptr: "Successfully created player"); /*0x14103a651*/
            __wind /*0xf1c000000000018c*/
            {
              std::string::string(this: &v472, _Ptr: "SeleniumTest3"); /*0x14103a666*/
              __wind /*0xf1c0000000000180*/
              {
                RBX::PlayerConfigurer::ifSeleniumThenSetCookie(this: v7, key: &v472, value: &v473); /*0x14103a67f*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v472); /*0xf1c0000000000178*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v472); /*0x14103a68d*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v473); /*0x14103a69b*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v473); /*0xf1c000000000016c*/
            }
            std::string::string(this: &v475, _Ptr: "Finished join"); /*0x14103a6af*/
            __wind /*0xf1c000000000015c*/
            {
              std::string::string(this: &v474, _Ptr: "SeleniumTest4"); /*0x14103a6c4*/
              __wind /*0xf1c00000000000fc*/
              {
                RBX::PlayerConfigurer::ifSeleniumThenSetCookie(this: v7, key: &v474, value: &v475); /*0x14103a6dd*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v474); /*0x14103a6eb*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v475); /*0x14103a6f9*/
                std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&report); /*0x14103a707*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&analyticsSessionId); /*0x14103a715*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&pubKeyData); /*0x14103a723*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&countryCodeFromArgs); /*0x14103a731*/
                RBX::Security::Impersonator::~Impersonator(this: &impersonate); /*0x14103a73f*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v474); /*0xf1c000000000010c*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v475); /*0xf1c0000000000118*/
            }
          }
          __unwind
          {
            std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &report); /*0xf1c0000000000124*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&analyticsSessionId); /*0xf1c0000000000130*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&pubKeyData); /*0xf1c000000000013c*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&countryCodeFromArgs); /*0xf1c0000000000148*/
    }
  }
  __unwind
  {
    RBX::Security::Impersonator::~Impersonator(this: &impersonate); /*0xf1c0000000000154*/
  }
}

// Address: 0x14103a770 | Name: ?connectPlayerToSignals@PlayerConfigurer@RBX@@AEAAXV?$shared_ptr@VPlayer@RBX@@@std@@@Z
void __fastcall RBX::PlayerConfigurer::connectPlayerToSignals(
        RBX::PlayerConfigurer *this,
        std::shared_ptr<RBX::File> *player)
{
  rbx::signal<void __cdecl(RBX::Reflection::PropertyDescriptor const *)> *p_propertyChangedSignal; // r14
  std::_String_val<std::_Simple_types<char> >::_Bxty v5; // xmm6
  unsigned int v6; // eax
  unsigned int parent; // ebx
  char *v8; // rax
  rbx::signals::slot_base *v9; // rdi
  __int64 v10; // rcx
  rbx::signals::slot_base *p; // rcx
  __int64 ParamInt64; // rdi
  __int64 v13; // rbx
  _WORD *v14; // rax
  const std::string *ParamString; // rax
  char *Ptr; // rcx
  char *v17; // rcx
  char *v18; // rcx
  char *v19; // rcx
  RBX::TimerService *v20; // r13
  std::_Func_base<void> *v21; // rax
  std::_Func_base<void> *v22; // rcx
  std::_Ref_count_base *Rep; // rbx
  __int64 v24; // rax
  boost::_bi::value<__int64> v25; // rdi
  boost::_bi::value<__int64> v26; // rbx
  char *v27; // rax
  const rtc::webrtc_checks_impl::ToStringVal *v28; // r15
  boost::_bi::list4<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string >,boost::_bi::value<__int64>,boost::_bi::value<__int64> > *v29; // rax
  boost::_bi::list4<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string >,boost::_bi::value<__int64>,boost::_bi::value<__int64> > *v30; // rbx
  char *v31; // rcx
  unsigned __int64 Myres; // rdx
  char *v33; // rcx
  char *v34; // rax
  char *v35; // rcx
  char *v36; // rcx
  char *v37; // rcx
  rbx::signal<void __cdecl(double)> *p_slots; // r15
  __int128 v39; // xmm6
  unsigned int v40; // eax
  unsigned int v41; // ebx
  char *v42; // rax
  rbx::signals::slot_base *v43; // rdi
  __int64 v44; // rcx
  rbx::signals::slot_base *v45; // rcx
  RBX::Player *v46; // rbx
  bool ParamBool; // al
  char *v48; // rcx
  std::shared_ptr<RBX::File> *v49; // rcx
  _BYTE v50[32]; // [rsp+0h] [rbp-100h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf1<void,ScriptRecoveryWidget,std::string const &>,boost::_bi::list2<boost::_bi::value<ScriptRecoveryWidget *>,boost::_bi::value<std::string > > > *v51; // [rsp+30h] [rbp-D0h]
  rbx::signals::connection other; // [rsp+38h] [rbp-C8h] BYREF
  rbx::signals::connection con; // [rsp+40h] [rbp-C0h] BYREF
  std::_String_val<std::_Simple_types<char> >::_Bxty v54; // [rsp+48h] [rbp-B8h]
  std::string v55; // [rsp+58h] [rbp-A8h] BYREF
  std::string v56; // [rsp+78h] [rbp-88h] BYREF
  __int128 v57; // [rsp+98h] [rbp-68h]
  std::string v58; // [rsp+A8h] [rbp-58h] BYREF
  std::string v59; // [rsp+C8h] [rbp-38h] BYREF
  std::string v60; // [rsp+E8h] [rbp-18h] BYREF
  std::weak_ptr<RBX::PlayerConfigurer> weakThis; // [rsp+108h] [rbp+8h] BYREF
  std::string key; // [rsp+118h] [rbp+18h] BYREF
  std::string v63; // [rsp+138h] [rbp+38h] BYREF
  __int128 v64; // [rsp+158h] [rbp+58h] BYREF
  std::pair<__int64 const ,PluginVersionDetails> v65; // [rsp+168h] [rbp+68h] BYREF
  __int64 t; // [rsp+198h] [rbp+98h]
  RBX::Graphics::ProfilerAdorn::Item result; // [rsp+1A0h] [rbp+A0h] BYREF
  std::function<void __cdecl(void)> v68; // [rsp+1D8h] [rbp+D8h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v69; // [rsp+218h] [rbp+118h] BYREF
  boost::_bi::list4<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string >,boost::_bi::value<__int64>,boost::_bi::value<__int64> > v70; // [rsp+238h] [rbp+138h] BYREF
  std::string v71; // [rsp+270h] [rbp+170h] BYREF
  std::function<void __cdecl(void)> v72; // [rsp+290h] [rbp+190h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *v73; // [rsp+330h] [rbp+230h]
  char v74; // [rsp+330h] [rbp+230h]
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v76; // [rsp+340h] [rbp+240h] BYREF
  std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *v77; // [rsp+348h] [rbp+248h] BYREF

  __wind /*0xf1c00000000001f8*/
  {
    __wind /*0xf1c0000000000200*/
    {
      p_propertyChangedSignal = &player->_Ptr->propertyChangedSignal; /*0x14103a7ab*/
      v54._Ptr = (char *)RBX::PlayerConfigurer::onPlayerChanged; /*0x14103a7b9*/
      *(_DWORD *)&v54._Alias[8] = 0; /*0x14103a7be*/
      v5 = v54; /*0x14103a7c3*/
      v60._Mypair._Myval2._Bx = v54; /*0x14103a7c8*/
      v60._Mypair._Myval2._Mysize = (unsigned __int64)this; /*0x14103a7cc*/
      v6 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x14103a7d6*/
      __wind /*0xf1c00000000001a8*/
      {
        parent = v6; /*0x14103a7db*/
        v76.parent = v6; /*0x14103a7dd*/
        v8 = (char *)operator new(size: 0x40u); /*0x14103a7e7*/
        v9 = (rbx::signals::slot_base *)v8; /*0x14103a7ec*/
        v77 = (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)v8; /*0x14103a7ef*/
        if ( v8 != nullptr ) /*0x14103a7fc*/
        {
          *(_DWORD *)v8 = 0; /*0x14103a7fe*/
          *((_DWORD *)v8 + 1) = 1; /*0x14103a801*/
          *((_QWORD *)v8 + 1) = rbx::signals::slot_with_functor<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Graphics::LightObject,bool>,boost::_bi::list2<boost::_bi::value<RBX::Graphics::LightObject *>,boost::arg<1>>>,bool>::do_call; /*0x14103a80f*/
          *((_QWORD *)v8 + 2) = RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x14103a81a*/
          *((_QWORD *)v8 + 3) = 0; /*0x14103a81e*/
          *((_QWORD *)v8 + 4) = p_propertyChangedSignal; /*0x14103a822*/
          *(std::_String_val<std::_Simple_types<char> >::_Bxty *)(v8 + 40) = v5; /*0x14103a826*/
          *((_QWORD *)v8 + 7) = v60._Mypair._Myval2._Mysize; /*0x14103a82f*/
          rbx::signals::signal_base::insert(this: p_propertyChangedSignal, item: (rbx::signals::slot_base *)v8); /*0x14103a837*/
          other.weak_slot.p_ = v9; /*0x14103a83c*/
          _InterlockedIncrement(&v9->weak._Storage._Value); /*0x14103a846*/
          parent = v76.parent; /*0x14103a84a*/
        }
        else
        {
          rbx::signals::signal_base::insert(this: p_propertyChangedSignal, item: nullptr); /*0x14103a854*/
          other.weak_slot.p_ = nullptr; /*0x14103a859*/
        }
      }
      __unwind
      {
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v76); /*0xf1c00000000001b8*/
      }
      __wind /*0xf1c00000000001c0*/
      {
        RBX::Memory::setCurrentCategory(category: parent); /*0x14103a86a*/
      }
      __unwind
      {
        __std_terminate(a1: v10, a2: v50); /*0x142f39fa8*/
      }
      if ( rbx::signals::connection::operator!=(this: &this->playerChangedConnection.con, &other) ) /*0x14103a87c*/
      {
        rbx::signals::connection::disconnect(this: &this->playerChangedConnection.con); /*0x14103a88c*/
        rbx::signals::connection::operator=(this: &this->playerChangedConnection.con, con: &other); /*0x14103a89d*/
      }
      LOBYTE(v73) = 0; /*0x14103a8a2*/
    }
    __unwind
    {
    }
    p = other.weak_slot.p_; /*0x14103a8af*/
    if ( other.weak_slot.p_ != nullptr /*0x14103a8c4*/
      && _InterlockedExchangeAdd(&other.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
    {
      operator delete(ptr: p); /*0x14103a8c6*/
    }
    this->sgs.avatarCreateTime = RBX::Time::nowFastSec() - this->sgs.userClickTime; /*0x14103a8d5*/
    key._Mypair._Myval2._Myres = 15; /*0x14103a8e1*/
    key._Mypair._Myval2._Mysize = 7; /*0x14103a8e9*/
    qmemcpy(&key, "PlaceI", 6); /*0x14103a8f7*/
    *(_WORD *)&key._Mypair._Myval2._Bx._Alias[6] = (unsigned __int8)aPlaceid_16[6]; /*0x14103a90c*/
    __wind /*0xf1c0000000000184*/
    {
      ParamInt64 = RBX::GameConfigurer::getParamInt64(this, &key); /*0x14103a91f*/
      v58._Mypair._Myval2._Myres = 15; /*0x14103a926*/
      v58._Mypair._Myval2._Mysize = 6; /*0x14103a92e*/
      strcpy(v58._Mypair._Myval2._Bx._Buf, "UserId"); /*0x14103a93c*/
      v58._Mypair._Myval2._Bx._Buf[7] = 0; /*0x14103a946*/
      __wind /*0xf1c0000000000178*/
      {
        v13 = RBX::GameConfigurer::getParamInt64(this, key: &v58); /*0x14103a95a*/
        v55._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103a95d*/
        v55._Mypair._Myval2._Mysize = 0; /*0x14103a962*/
        v55._Mypair._Myval2._Myres = 15; /*0x14103a967*/
        v14 = operator new(size: 0x20u); /*0x14103a97a*/
        v55._Mypair._Myval2._Mysize = 27; /*0x14103a97f*/
        v55._Mypair._Myval2._Myres = 31; /*0x14103a988*/
        qmemcpy(v14, "CookieStoreFirstTimePlayKe", 26); /*0x14103a998*/
        v14[13] = (unsigned __int8)aCookiestorefir[26]; /*0x14103a9ba*/
        v55._Mypair._Myval2._Bx._Ptr = (char *)v14; /*0x14103a9c1*/
        __wind /*0xf1c0000000000148*/
        {
          ParamString = RBX::GameConfigurer::getParamString(this, result: &result.text, key: &v55); /*0x14103a9d5*/
          __wind /*0xf1c000000000013c*/
          {
            RBX::GameConfigurer::registerPlay(this, key: ParamString, userId: v13, placeId: ParamInt64); /*0x14103a9e7*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: &result); /*0xf1c0000000000134*/
          }
          if ( result.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14103a9f8*/
          {
            Ptr = result.text._Mypair._Myval2._Bx._Ptr; /*0x14103a9fd*/
            if ( result.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103aa0e*/
            {
              Ptr = *((char **)result.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14103aa14*/
              if ( (unsigned __int64)(result.text._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14103aa23*/
                _invalid_parameter_noinfo_noreturn(); /*0x14103aa25*/
            }
            operator delete(ptr: Ptr); /*0x14103aa2c*/
          }
          result.text._Mypair._Myval2._Mysize = 0; /*0x14103aa31*/
          result.text._Mypair._Myval2._Myres = 15; /*0x14103aa38*/
          result.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103aa43*/
          if ( v55._Mypair._Myval2._Myres >= 0x10 ) /*0x14103aa53*/
          {
            v17 = v55._Mypair._Myval2._Bx._Ptr; /*0x14103aa58*/
            if ( v55._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103aa67*/
            {
              v17 = *((char **)v55._Mypair._Myval2._Bx._Ptr - 1); /*0x14103aa6d*/
              if ( (unsigned __int64)(v55._Mypair._Myval2._Bx._Ptr - v17 - 8) > 0x1F ) /*0x14103aa7c*/
                _invalid_parameter_noinfo_noreturn(); /*0x14103aa7e*/
            }
            operator delete(ptr: v17); /*0x14103aa85*/
          }
          v55._Mypair._Myval2._Mysize = 0; /*0x14103aa8a*/
          v55._Mypair._Myval2._Myres = 15; /*0x14103aa8f*/
          v55._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103aa98*/
          if ( v58._Mypair._Myval2._Myres >= 0x10 ) /*0x14103aaa5*/
          {
            v18 = v58._Mypair._Myval2._Bx._Ptr; /*0x14103aaaa*/
            if ( v58._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103aab8*/
            {
              v18 = *((char **)v58._Mypair._Myval2._Bx._Ptr - 1); /*0x14103aabe*/
              if ( (unsigned __int64)(v58._Mypair._Myval2._Bx._Ptr - v18 - 8) > 0x1F ) /*0x14103aacd*/
                _invalid_parameter_noinfo_noreturn(); /*0x14103aacf*/
            }
            operator delete(ptr: v18); /*0x14103aad6*/
          }
          v58._Mypair._Myval2._Mysize = 0; /*0x14103aadb*/
          v58._Mypair._Myval2._Myres = 15; /*0x14103aadf*/
          v58._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103aae7*/
          if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x14103aaf3*/
          {
            v19 = key._Mypair._Myval2._Bx._Ptr; /*0x14103aaf8*/
            if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103ab06*/
            {
              v19 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x14103ab0c*/
              if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v19 - 8) > 0x1F ) /*0x14103ab1b*/
                _invalid_parameter_noinfo_noreturn(); /*0x14103ab1d*/
            }
            operator delete(ptr: v19); /*0x14103ab24*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v55); /*0xf1c0000000000158*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v58); /*0xf1c0000000000164*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key); /*0xf1c0000000000170*/
    }
    v20 = RBX::ServiceProvider::create<RBX::TimerService>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x14103ab36*/
    if ( v20 != nullptr ) /*0x14103ab3c*/
    {
      if ( FFlag::AppBridgeRewrite.value ) /*0x14103ab49*/
      {
        RBX::weak_from<RBX::Studio::DebuggerUIService>( /*0x14103ab56*/
          result: (std::weak_ptr<UserPluginsModel> *)&weakThis,
          r: (UserPluginsModel *)this);
        __wind /*0xf1c0000000000124*/
        {
          v21 = nullptr; /*0x14103ab5c*/
          v54._Ptr = nullptr; /*0x14103ab5f*/
          v22 = nullptr; /*0x14103ab64*/
          Rep = weakThis._Rep; /*0x14103ab67*/
          if ( weakThis._Rep != nullptr ) /*0x14103ab6e*/
          {
            v54._Ptr = (char *)weakThis._Ptr; /*0x14103ab74*/
            _InterlockedIncrement((volatile signed __int32 *)&weakThis._Rep->_Weaks); /*0x14103ab79*/
            Rep = weakThis._Rep; /*0x14103ab7d*/
            v22 = (std::_Func_base<void> *)weakThis._Rep; /*0x14103ab81*/
            v21 = (std::_Func_base<void> *)v54._Ptr; /*0x14103ab84*/
          }
          v68._Mystorage._Ptrs[0] = (std::_Func_base<void> *)std::_Func_impl_no_alloc__lambda_4f780de36c800357f1241d4e2411762a__void_::_vftable_; /*0x14103ab90*/
          v68._Mystorage._Ptrs[1] = v21; /*0x14103ab97*/
          v68._Mystorage._Ptrs[2] = v22; /*0x14103ab9e*/
          v68._Mystorage._Ptrs[7] = (std::_Func_base<void> *)&v68; /*0x14103abac*/
          RBX::TimerService::delay(this: v20, func: &v68, seconds: 300.0); /*0x14103abc5*/
        }
        __unwind
        {
          std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)&weakThis); /*0xf1c000000000011c*/
        }
        if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14103abdf*/
          weakThis._Rep->_Delete_this(this: weakThis._Rep); /*0x14103abec*/
      }
      else
      {
        __wind /*0xf1c000000000010c*/
        {
          v77 = (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&v72; /*0x14103abfb*/
          v63._Mypair._Myval2._Myres = 15; /*0x14103ac06*/
          v63._Mypair._Myval2._Mysize = 7; /*0x14103ac0e*/
          qmemcpy(&v63, "PlaceI", 6); /*0x14103ac1c*/
          *(_WORD *)&v63._Mypair._Myval2._Bx._Alias[6] = (unsigned __int8)aPlaceid_16[6]; /*0x14103ac31*/
          v24 = RBX::GameConfigurer::getParamInt64(this, key: &v63); /*0x14103ac3f*/
          __wind /*0xf1c0000000000100*/
          {
            v25.t_ = v24; /*0x14103ac44*/
            v59._Mypair._Myval2._Myres = 15; /*0x14103ac4b*/
            v59._Mypair._Myval2._Mysize = 6; /*0x14103ac53*/
            strcpy(v59._Mypair._Myval2._Bx._Buf, "UserId"); /*0x14103ac61*/
            v59._Mypair._Myval2._Bx._Buf[7] = 0; /*0x14103ac6b*/
            v26.t_ = RBX::GameConfigurer::getParamInt64(this, key: &v59); /*0x14103ac7f*/
            v56._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103ac82*/
            v56._Mypair._Myval2._Mysize = 0; /*0x14103ac87*/
            v56._Mypair._Myval2._Myres = 15; /*0x14103ac8b*/
            v27 = (char *)operator new(size: 0x20u); /*0x14103ac9d*/
            v56._Mypair._Myval2._Mysize = 28; /*0x14103aca2*/
            v56._Mypair._Myval2._Myres = 31; /*0x14103acaa*/
            strcpy(v27, "CookieStoreFiveMinutePlayKey"); /*0x14103acb9*/
            v56._Mypair._Myval2._Bx._Ptr = v27; /*0x14103acd6*/
            __wind /*0xf1c00000000000d0*/
            {
              v28 = (const rtc::webrtc_checks_impl::ToStringVal *)RBX::GameConfigurer::getParamString( /*0x14103acef*/
                                                                    this,
                                                                    result: &v71,
                                                                    key: &v56);
              HIDWORD(v73) = HIDWORD(v28); /*0x14103acf2*/
              *(_QWORD *)&v57 = RBX::GameConfigurer::registerPlay; /*0x14103ad00*/
              DWORD2(v57) = 0; /*0x14103ad04*/
              __wind /*0xf1c00000000000c4*/
              {
                std::string::string(this: &v69, __that: v28); /*0x14103ad15*/
                v29 = boost::_bi::list4<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string>,boost::_bi::value<__int64>,boost::_bi::value<__int64>>::list4<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string>,boost::_bi::value<__int64>,boost::_bi::value<__int64>>( /*0x14103ad33*/
                        this: &v70,
                        a1: (boost::_bi::value<RBX::PlayerConfigurer *>)this,
                        a2: (boost::_bi::value<std::string > *)&v69,
                        a3: v26,
                        a4: v25);
                v30 = v29; /*0x14103ad38*/
                __wind /*0xf1c00000000000b8*/
                {
                  v64 = v57; /*0x14103ad3f*/
                  v65.first = (const __int64)v29->a1_.t_; /*0x14103ad46*/
                  std::string::string( /*0x14103ad52*/
                    this: (rtc::webrtc_checks_impl::ToStringVal *)&v65.second,
                    __that: (const rtc::webrtc_checks_impl::ToStringVal *)&v29->a2_);
                  v65.second.latestVersion = v30->a3_.t_; /*0x14103ad5b*/
                  t = v30->a4_.t_; /*0x14103ad66*/
                  LODWORD(v73) = 2; /*0x14103ad6d*/
                }
                __unwind
                {
                  RBX::Studio::DebuggerResponseArg<RBX::Scripting::DAP::StepOutResponseBody>::~DebuggerResponseArg<RBX::Scripting::DAP::StepOutResponseBody>(this: (boost::_bi::storage3<boost::_bi::value<ScriptRecoveryWidget *>,boost::_bi::value<std::string >,boost::arg<1> > *)&v70); /*0xf1c00000000000b0*/
                }
                if ( v70.a2_.t_._Mypair._Myval2._Myres >= 0x10 ) /*0x14103ad82*/
                {
                  v31 = v70.a2_.t_._Mypair._Myval2._Bx._Ptr; /*0x14103ad87*/
                  if ( v70.a2_.t_._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103ad98*/
                  {
                    v31 = *((char **)v70.a2_.t_._Mypair._Myval2._Bx._Ptr - 1); /*0x14103ad9e*/
                    if ( (unsigned __int64)(v70.a2_.t_._Mypair._Myval2._Bx._Ptr - v31 - 8) > 0x1F ) /*0x14103adad*/
                      _invalid_parameter_noinfo_noreturn(); /*0x14103adaf*/
                  }
                  operator delete(ptr: v31); /*0x14103adb6*/
                }
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: v73); /*0xf1c00000000000a4*/
              }
              *(__m128i *)&v70.a2_.t_._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14103adc3*/
              v70.a2_.t_._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103adcb*/
              Myres = v28->val._Mypair._Myval2._Myres; /*0x14103add2*/
              if ( Myres >= 0x10 ) /*0x14103adda*/
              {
                v33 = v28->val._Mypair._Myval2._Bx._Ptr; /*0x14103addc*/
                if ( Myres + 1 >= 0x1000 ) /*0x14103ade9*/
                {
                  if ( (unsigned __int64)&v33[-*((_QWORD *)v33 - 1) - 8] > 0x1F ) /*0x14103adfe*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14103aeff*/
                  v33 = *((char **)v33 - 1); /*0x14103ae04*/
                }
                operator delete(ptr: v33); /*0x14103ae07*/
              }
              __wind /*0xf1c00000000001e4*/
              {
                __wind /*0xf1c00000000001ec*/
                {
                  v28->val._Mypair._Myval2._Mysize = 0; /*0x14103ae0c*/
                  v28->val._Mypair._Myval2._Myres = 15; /*0x14103ae14*/
                  v28->val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103ae1c*/
                  v51 = (boost::_bi::bind_t<void,boost::_mfi::mf1<void,ScriptRecoveryWidget,std::string const &>,boost::_bi::list2<boost::_bi::value<ScriptRecoveryWidget *>,boost::_bi::value<std::string > > > *)&v64; /*0x14103ae24*/
                  v72._Mystorage._Ptrs[7] = nullptr; /*0x14103ae2c*/
                  v34 = (char *)operator new(size: 0x50u); /*0x14103ae37*/
                  *(_QWORD *)v34 = std::_Func_impl_no_alloc<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::GameConfigurer,std::string const &,__int64,__int64>,boost::_bi::list4<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string>,boost::_bi::value<__int64>,boost::_bi::value<__int64>>>,void,>::`vftable'; /*0x14103ae43*/
                  *(_OWORD *)(v34 + 8) = v64; /*0x14103ae4a*/
                  *((_QWORD *)v34 + 3) = v65.first; /*0x14103ae52*/
                  *((_QWORD *)v34 + 6) = 0; /*0x14103ae56*/
                  *((_QWORD *)v34 + 7) = 0; /*0x14103ae5a*/
                  *((_OWORD *)v34 + 2) = v65.second.name._Mypair._Myval2._Bx; /*0x14103ae62*/
                  *((_OWORD *)v34 + 3) = *(_OWORD *)&v65.second.name._Mypair._Myval2._Mysize; /*0x14103ae6d*/
                  v65.second.name._Mypair._Myval2._Mysize = 0; /*0x14103ae71*/
                  v65.second.name._Mypair._Myval2._Myres = 15; /*0x14103ae78*/
                  v65.second.name._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103ae83*/
                  *((_QWORD *)v34 + 8) = v65.second.latestVersion; /*0x14103ae8e*/
                  *((_QWORD *)v34 + 9) = t; /*0x14103ae99*/
                  v72._Mystorage._Ptrs[7] = (std::_Func_base<void> *)v34; /*0x14103ae9d*/
                  std::pair<enum CmdArgCLIFormat const,std::string>::~pair<enum CmdArgCLIFormat const,std::string>(this: &v65); /*0x14103aea8*/
                }
                __unwind
                {
                  std::function<void (__int64)>::~function<void (__int64)>(this: v77); /*0xf1c00000000001d0*/
                }
              }
              __unwind
              {
                RBX::LSP::HoverData::~HoverData(this: v51); /*0xf1c00000000001dc*/
              }
              RBX::TimerService::delay(this: v20, func: &v72, seconds: 300.0); /*0x14103aebf*/
              if ( v56._Mypair._Myval2._Myres >= 0x10 ) /*0x14103aecd*/
              {
                v35 = v56._Mypair._Myval2._Bx._Ptr; /*0x14103aed2*/
                if ( v56._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103aee1*/
                {
                  v35 = *((char **)v56._Mypair._Myval2._Bx._Ptr - 1); /*0x14103aee7*/
                  if ( (unsigned __int64)(v56._Mypair._Myval2._Bx._Ptr - v35 - 8) > 0x1F ) /*0x14103aef6*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14103aef8*/
                }
                operator delete(ptr: v35); /*0x14103af06*/
              }
              v56._Mypair._Myval2._Mysize = 0; /*0x14103af0b*/
              v56._Mypair._Myval2._Myres = 15; /*0x14103af0f*/
              v56._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103af17*/
              if ( v59._Mypair._Myval2._Myres >= 0x10 ) /*0x14103af24*/
              {
                v36 = v59._Mypair._Myval2._Bx._Ptr; /*0x14103af29*/
                if ( v59._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103af37*/
                {
                  v36 = *((char **)v59._Mypair._Myval2._Bx._Ptr - 1); /*0x14103af3d*/
                  if ( (unsigned __int64)(v59._Mypair._Myval2._Bx._Ptr - v36 - 8) > 0x1F ) /*0x14103af4c*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14103af4e*/
                }
                operator delete(ptr: v36); /*0x14103af55*/
              }
              v59._Mypair._Myval2._Mysize = 0; /*0x14103af5a*/
              v59._Mypair._Myval2._Myres = 15; /*0x14103af5e*/
              v59._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103af66*/
              if ( v63._Mypair._Myval2._Myres >= 0x10 ) /*0x14103af72*/
              {
                v37 = v63._Mypair._Myval2._Bx._Ptr; /*0x14103af77*/
                if ( v63._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103af85*/
                {
                  v37 = *((char **)v63._Mypair._Myval2._Bx._Ptr - 1); /*0x14103af8b*/
                  if ( (unsigned __int64)(v63._Mypair._Myval2._Bx._Ptr - v37 - 8) > 0x1F ) /*0x14103af9a*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14103af9c*/
                }
                operator delete(ptr: v37); /*0x14103afa3*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v56); /*0xf1c00000000000e0*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v59); /*0xf1c00000000000ec*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v63); /*0xf1c00000000000f8*/
        }
      }
    }
    __wind /*0xf1c0000000000094*/
    {
      p_slots = (rbx::signal<void __cdecl(double)> *)&player->_Ptr[6].propertyChangedSignal.slots; /*0x14103afac*/
      *(_QWORD *)&v57 = RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x14103afba*/
      DWORD2(v57) = 0; /*0x14103afc1*/
      v39 = v57; /*0x14103afc5*/
      *(_OWORD *)&result.x = v57; /*0x14103afc9*/
      *(_QWORD *)&result.color = this; /*0x14103afd0*/
      v40 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x14103afdd*/
      __wind /*0xf1c0000000000070*/
      {
        v41 = v40; /*0x14103afe2*/
        LODWORD(v77) = v40; /*0x14103afe4*/
        v42 = (char *)operator new(size: 0x40u); /*0x14103afee*/
        v43 = (rbx::signals::slot_base *)v42; /*0x14103aff3*/
        v51 = (boost::_bi::bind_t<void,boost::_mfi::mf1<void,ScriptRecoveryWidget,std::string const &>,boost::_bi::list2<boost::_bi::value<ScriptRecoveryWidget *>,boost::_bi::value<std::string > > > *)v42; /*0x14103aff6*/
        if ( v42 != nullptr ) /*0x14103b001*/
        {
          *(_DWORD *)v42 = 0; /*0x14103b003*/
          *((_DWORD *)v42 + 1) = 1; /*0x14103b006*/
          *((_QWORD *)v42 + 1) = rbx::signals::slot_with_functor<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Graphics::LightObject,bool>,boost::_bi::list2<boost::_bi::value<RBX::Graphics::LightObject *>,boost::arg<1>>>,bool>::do_call; /*0x14103b014*/
          *((_QWORD *)v42 + 2) = RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x14103b01f*/
          *((_QWORD *)v42 + 3) = 0; /*0x14103b023*/
          *((_QWORD *)v42 + 4) = p_slots; /*0x14103b027*/
          *(_OWORD *)(v42 + 40) = v39; /*0x14103b02b*/
          *((_QWORD *)v42 + 7) = *(_QWORD *)&result.color; /*0x14103b037*/
          rbx::signals::signal_base::insert(this: p_slots, item: (rbx::signals::slot_base *)v42); /*0x14103b03f*/
          con.weak_slot.p_ = v43; /*0x14103b044*/
          _InterlockedIncrement(&v43->weak._Storage._Value); /*0x14103b04e*/
          v41 = (unsigned int)v77; /*0x14103b052*/
        }
        else
        {
          rbx::signals::signal_base::insert(this: p_slots, item: nullptr); /*0x14103b05c*/
          con.weak_slot.p_ = nullptr; /*0x14103b061*/
        }
        v74 = (unsigned __int8)v73 | 4; /*0x14103b066*/
      }
      __unwind
      {
        RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&v77); /*0xf1c0000000000080*/
      }
      __wind /*0xf1c0000000000088*/
      {
        RBX::Memory::setCurrentCategory(category: v41); /*0x14103b06f*/
      }
      __unwind
      {
        __std_terminate(a1: v44, a2: v50); /*0xf1c000000000002c*/
      }
      if ( rbx::signals::connection::operator!=(this: &this->idlingConnection.con, other: &con) ) /*0x14103b081*/
      {
        rbx::signals::connection::disconnect(this: &this->idlingConnection.con); /*0x14103b091*/
        rbx::signals::connection::operator=(this: &this->idlingConnection.con, &con); /*0x14103b0a2*/
      }
    }
    __unwind
    {
      if ( (v74 & 4) != 0 ) /*0x1431e7974*/
        rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&con); /*0x1431e7981*/
    }
    v45 = con.weak_slot.p_; /*0x14103b0a8*/
    if ( con.weak_slot.p_ != nullptr /*0x14103b0bc*/
      && _InterlockedExchangeAdd(&con.weak_slot.p_->weak._Storage._Value, 0xFFFFFFFF) == 1 )
    {
      operator delete(ptr: v45); /*0x14103b0be*/
    }
    v46 = (RBX::Player *)player->_Ptr; /*0x14103b0c3*/
    v60._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b0c7*/
    v60._Mypair._Myval2._Mysize = 0; /*0x14103b0cb*/
    v60._Mypair._Myval2._Myres = 15; /*0x14103b0cf*/
    std::string::assign(this: &v60, _Ptr: "IsUnknownOrUnder13", _Count: 0x12u); /*0x14103b0ec*/
    __wind /*0xf1c000000000004c*/
    {
      ParamBool = RBX::GameConfigurer::getParamBool(this, key: &v60); /*0x14103b0f9*/
      RBX::Player::setUnder13(this: v46, value: ParamBool); /*0x14103b104*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v60); /*0xf1c0000000000044*/
    }
    if ( v60._Mypair._Myval2._Myres >= 0x10 ) /*0x14103b112*/
    {
      v48 = v60._Mypair._Myval2._Bx._Ptr; /*0x14103b117*/
      if ( v60._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103b125*/
      {
        v48 = *((char **)v60._Mypair._Myval2._Bx._Ptr - 1); /*0x14103b12b*/
        if ( (unsigned __int64)(v60._Mypair._Myval2._Bx._Ptr - v48 - 8) > 0x1F ) /*0x14103b13a*/
          _invalid_parameter_noinfo_noreturn(); /*0x14103b13c*/
      }
      operator delete(ptr: v48); /*0x14103b143*/
    }
    v49 = player; /*0x14103b149*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: player); /*0xf1c0000000000038*/
  }
  std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v49); /*0x14103b167*/
}

// Address: 0x14103b2b0 | Name: ?createPlayer@PlayerConfigurer@RBX@@AEAAXXZ
void __fastcall RBX::PlayerConfigurer::createPlayer(RBX::PlayerConfigurer *this)
{
  RBX::Players **v2; // rax
  RBX::Players *v3; // rsi
  char *v4; // rcx
  std::string *ParamString; // rbx
  char *v6; // rcx
  char *v7; // rcx
  char *v8; // rcx
  char *v9; // rax
  char *v10; // rcx
  bool isParamExist; // al
  std::string *v12; // rbx
  __int16 v13; // di
  char *v14; // rcx
  void *v15; // rcx
  char *v16; // rcx
  char *v17; // rcx
  char *v18; // rcx
  std::string *v19; // rbx
  __int16 v20; // di
  char *v21; // rcx
  char *v22; // rcx
  char *v23; // rcx
  char *v24; // rcx
  std::string *v25; // rbx
  char *v26; // rcx
  char *v27; // rcx
  char *v28; // rcx
  std::string *GameLocaleIdFromParams; // rbx
  char *v30; // rcx
  std::shared_ptr<RBX::Player> *v31; // rax
  std::shared_ptr<RBX::Player> *v32; // rsi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v34; // rax
  RBX::Player *v35; // rbx
  std::_Ref_count_base *Rep; // rax
  _QWORD *p_color; // rax
  __int16 v38; // di
  std::_Ref_count_base *v39; // rsi
  __int16 v40; // di
  RBX::DataModel *dataModel; // rax
  const RBX::ServiceProvider *v42; // rcx
  RBX::VRService *v43; // rax
  bool ParamBool; // al
  char *v45; // rcx
  _DWORD *v46; // rdi
  std::string *v47; // rax
  char *v48; // rcx
  int ParamInt; // eax
  char *v50; // rcx
  const std::string *v51; // rax
  char *v52; // rcx
  RBX::Player::ChatPrivacyMode v53; // edx
  std::string *v54; // rax
  bool v55; // di
  char *v56; // rcx
  __int64 ParamInt64; // rax
  char *v58; // rcx
  const std::string *v59; // rax
  char *v60; // rcx
  char *v61; // rcx
  std::string v62; // [rsp+30h] [rbp-D0h] BYREF
  std::string v63; // [rsp+50h] [rbp-B0h] BYREF
  std::shared_ptr<RBX::File> v64; // [rsp+70h] [rbp-90h] BYREF
  std::string v65; // [rsp+80h] [rbp-80h] BYREF
  std::string v66; // [rsp+A0h] [rbp-60h] BYREF
  std::string v67; // [rsp+C0h] [rbp-40h] BYREF
  RBX::UserInfo userInfo; // [rsp+E0h] [rbp-20h] BYREF
  std::string key; // [rsp+1E0h] [rbp+E0h] BYREF
  std::string v70; // [rsp+200h] [rbp+100h] BYREF
  std::string v71; // [rsp+220h] [rbp+120h] BYREF
  std::string v72; // [rsp+240h] [rbp+140h] BYREF
  std::string v73; // [rsp+260h] [rbp+160h] BYREF
  std::string v74; // [rsp+280h] [rbp+180h] BYREF
  std::string v75; // [rsp+2A0h] [rbp+1A0h] BYREF
  std::string v76; // [rsp+2C0h] [rbp+1C0h] BYREF
  std::string v77; // [rsp+2E0h] [rbp+1E0h] BYREF
  std::string v78; // [rsp+300h] [rbp+200h] BYREF
  std::string v79; // [rsp+320h] [rbp+220h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v80; // [rsp+340h] [rbp+240h] BYREF
  std::_Ref_count_base *v81; // [rsp+378h] [rbp+278h]
  std::shared_ptr<RBX::Player> player; // [rsp+380h] [rbp+280h] BYREF
  std::string result; // [rsp+390h] [rbp+290h] BYREF
  void *ptr[3]; // [rsp+3B0h] [rbp+2B0h] BYREF
  unsigned __int64 v85; // [rsp+3C8h] [rbp+2C8h]
  std::string v86; // [rsp+3D0h] [rbp+2D0h] BYREF
  std::shared_ptr<RBX::Player> v87; // [rsp+3F0h] [rbp+2F0h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v88; // [rsp+400h] [rbp+300h] BYREF
  std::string v89; // [rsp+420h] [rbp+320h] BYREF
  std::string v90; // [rsp+440h] [rbp+340h] BYREF
  std::string v91; // [rsp+460h] [rbp+360h] BYREF
  std::string v92; // [rsp+480h] [rbp+380h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v93; // [rsp+4A0h] [rbp+3A0h] BYREF
  char v94; // [rsp+500h] [rbp+400h]
  __int16 v95; // [rsp+500h] [rbp+400h]
  RBX::MembershipType membershipType; // [rsp+508h] [rbp+408h] BYREF
  RBX::Player::ChatPrivacyMode chatPrivacyMode; // [rsp+510h] [rbp+410h] BYREF
  __int64 v98; // [rsp+518h] [rbp+418h]

  v2 = (RBX::Players **)RBX::ServiceProvider::refByClass<RBX::Players>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x14103b2dd*/
  __wind /*0xf1c00000000002ec*/
  {
    __wind /*0xf1c00000000002f4*/
    {
      v3 = *v2; /*0x14103b2e2*/
      userInfo.isUnder13 = true; /*0x14103b2e9*/
      userInfo.username._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b2ed*/
      *(__m128i *)&userInfo.username._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14103b2f9*/
      userInfo.displayName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b302*/
      *(_OWORD *)&userInfo.displayName._Mypair._Myval2._Mysize = *(_OWORD *)&userInfo.username._Mypair._Myval2._Mysize; /*0x14103b306*/
      userInfo.membershipType = MEMBERSHIP_NONE; /*0x14103b30f*/
      userInfo.robloxLocaleId._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b313*/
      userInfo.robloxLocaleId._Mypair._Myval2._Mysize = 0; /*0x14103b317*/
      userInfo.robloxLocaleId._Mypair._Myval2._Myres = 15; /*0x14103b31b*/
      userInfo.gameLocaleId._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b327*/
      userInfo.gameLocaleId._Mypair._Myval2._Mysize = 0; /*0x14103b32b*/
      userInfo.gameLocaleId._Mypair._Myval2._Myres = 15; /*0x14103b32f*/
      userInfo.theme._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b33b*/
      userInfo.theme._Mypair._Myval2._Mysize = 0; /*0x14103b33f*/
      userInfo.theme._Mypair._Myval2._Myres = 15; /*0x14103b346*/
      userInfo.alternateName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b355*/
      userInfo.alternateName._Mypair._Myval2._Mysize = 0; /*0x14103b35c*/
      userInfo.alternateName._Mypair._Myval2._Myres = 15; /*0x14103b363*/
      userInfo.platformName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b375*/
      userInfo.platformName._Mypair._Myval2._Mysize = 0; /*0x14103b37c*/
      userInfo.platformName._Mypair._Myval2._Myres = 15; /*0x14103b383*/
      key._Mypair._Myval2._Myres = 15; /*0x14103b39c*/
      key._Mypair._Myval2._Mysize = 6; /*0x14103b3a7*/
      strcpy(key._Mypair._Myval2._Bx._Buf, "UserId"); /*0x14103b3b8*/
      key._Mypair._Myval2._Bx._Buf[7] = 0; /*0x14103b3c5*/
      userInfo.userId = RBX::GameConfigurer::getParamInt64(this, &key); /*0x14103b3e2*/
      if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x14103b3f1*/
      {
        v4 = key._Mypair._Myval2._Bx._Ptr; /*0x14103b3f6*/
        if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103b407*/
        {
          v4 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x14103b40d*/
          if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v4 - 8) > 0x1F ) /*0x14103b41c*/
            _invalid_parameter_noinfo_noreturn(); /*0x14103b41e*/
        }
        operator delete(ptr: v4); /*0x14103b425*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key); /*0xf1c00000000002d8*/
    }
    __wind /*0xf1c00000000002e0*/
    {
      v80.text._Mypair._Myval2._Myres = 15; /*0x14103b42a*/
      v80.text._Mypair._Myval2._Mysize = 8; /*0x14103b435*/
      strcpy(v80.text._Mypair._Myval2._Bx._Buf, "UserName"); /*0x14103b44a*/
      ParamString = RBX::GameConfigurer::getParamString(this, &result, key: &v80.text); /*0x14103b46e*/
      if ( &userInfo.username != ParamString ) /*0x14103b478*/
      {
        if ( userInfo.username._Mypair._Myval2._Myres >= 0x10 ) /*0x14103b482*/
        {
          v6 = userInfo.username._Mypair._Myval2._Bx._Ptr; /*0x14103b487*/
          if ( userInfo.username._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103b495*/
          {
            v6 = *((char **)userInfo.username._Mypair._Myval2._Bx._Ptr - 1); /*0x14103b49b*/
            if ( (unsigned __int64)(userInfo.username._Mypair._Myval2._Bx._Ptr - v6 - 8) > 0x1F ) /*0x14103b4aa*/
LABEL_16:
              _invalid_parameter_noinfo_noreturn(); /*0x14103b518*/
          }
          operator delete(ptr: v6); /*0x14103b4ac*/
        }
        *(__m128i *)&userInfo.username._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14103b4b9*/
        userInfo.username._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103b4be*/
        userInfo.username = *ParamString; /*0x14103b4c5*/
        ParamString->_Mypair._Myval2._Mysize = 0; /*0x14103b4d1*/
        ParamString->_Mypair._Myval2._Myres = 15; /*0x14103b4d5*/
        ParamString->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103b4dd*/
      }
      if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14103b4eb*/
      {
        v7 = result._Mypair._Myval2._Bx._Ptr; /*0x14103b4f0*/
        if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103b501*/
        {
          v7 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14103b507*/
          if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v7 - 8) > 0x1F ) /*0x14103b516*/
            goto LABEL_16; /*0x14103b516*/
        }
        operator delete(ptr: v7); /*0x14103b51f*/
      }
      result._Mypair._Myval2._Mysize = 0; /*0x14103b524*/
      result._Mypair._Myval2._Myres = 15; /*0x14103b52b*/
      result._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103b536*/
      if ( v80.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14103b548*/
      {
        v8 = v80.text._Mypair._Myval2._Bx._Ptr; /*0x14103b54d*/
        if ( v80.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103b55e*/
        {
          v8 = *((char **)v80.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14103b564*/
          if ( (unsigned __int64)(v80.text._Mypair._Myval2._Bx._Ptr - v8 - 8) > 0x1F ) /*0x14103b573*/
            _invalid_parameter_noinfo_noreturn(); /*0x14103b575*/
        }
        operator delete(ptr: v8); /*0x14103b57c*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v80); /*0xf1c000000000025c*/
    }
    v67._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b581*/
    v67._Mypair._Myval2._Mysize = 0; /*0x14103b585*/
    v67._Mypair._Myval2._Myres = 15; /*0x14103b589*/
    v9 = (char *)operator new(size: 0x20u); /*0x14103b59a*/
    __wind /*0xf1c0000000000234*/
    {
      v67._Mypair._Myval2._Mysize = 18; /*0x14103b59f*/
      v67._Mypair._Myval2._Myres = 31; /*0x14103b5a7*/
      strcpy(v9, "IsUnknownOrUnder13"); /*0x14103b5b6*/
      v67._Mypair._Myval2._Bx._Ptr = v9; /*0x14103b5c8*/
      userInfo.isUnder13 = RBX::GameConfigurer::getParamBool(this, key: &v67); /*0x14103b5d8*/
      if ( v67._Mypair._Myval2._Myres >= 0x10 ) /*0x14103b5e3*/
      {
        v10 = v67._Mypair._Myval2._Bx._Ptr; /*0x14103b5e8*/
        if ( v67._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103b5f6*/
        {
          v10 = *((char **)v67._Mypair._Myval2._Bx._Ptr - 1); /*0x14103b5fc*/
          if ( (unsigned __int64)(v67._Mypair._Myval2._Bx._Ptr - v10 - 8) > 0x1F ) /*0x14103b60b*/
            _invalid_parameter_noinfo_noreturn(); /*0x14103b60d*/
        }
        operator delete(ptr: v10); /*0x14103b614*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v67); /*0xf1c0000000000244*/
    }
    __wind /*0xf1c000000000024c*/
    {
      v70._Mypair._Myval2._Myres = 15; /*0x14103b619*/
      v70._Mypair._Myval2._Mysize = 13; /*0x14103b624*/
      qmemcpy(&v70, "AlternateNam", 12); /*0x14103b637*/
      *(_WORD *)&v70._Mypair._Myval2._Bx._Alias[12] = (unsigned __int8)aAlternatename[12]; /*0x14103b652*/
      isParamExist = RBX::GameConfigurer::isParamExist(this, key: &v70); /*0x14103b669*/
      __wind /*0xf1c0000000000210*/
      {
        if ( isParamExist ) /*0x14103b670*/
        {
          v66._Mypair._Myval2._Myres = 15; /*0x14103b672*/
          v66._Mypair._Myval2._Mysize = 13; /*0x14103b67a*/
          qmemcpy(&v66, "AlternateNam", 12); /*0x14103b68a*/
          *(_WORD *)&v66._Mypair._Myval2._Bx._Alias[12] = (unsigned __int8)aAlternatename[12]; /*0x14103b69f*/
          v12 = RBX::GameConfigurer::getParamString(this, result: &v86, key: &v66); /*0x14103b6c3*/
          v13 = 3; /*0x14103b6c6*/
          v94 = 3; /*0x14103b6cb*/
          if ( &userInfo.alternateName == v12 ) /*0x14103b6db*/
          {
LABEL_38:
            if ( (v13 & 4) != 0 ) /*0x14103b790*/
            {
              v13 &= ~4u; /*0x14103b792*/
              v94 = v13; /*0x14103b795*/
              if ( v85 >= 0x10 ) /*0x14103b7a6*/
              {
                v15 = ptr[0]; /*0x14103b7ab*/
                if ( v85 + 1 >= 0x1000 ) /*0x14103b7bc*/
                {
                  v15 = *((void **)ptr[0] - 1); /*0x14103b7c2*/
                  if ( (unsigned __int64)((char *)ptr[0] - (char *)v15 - 8) > 0x1F ) /*0x14103b7d1*/
                    goto LABEL_42; /*0x14103b7d1*/
                }
                operator delete(ptr: v15); /*0x14103b7da*/
              }
            }
            if ( (v13 & 2) != 0 ) /*0x14103b7e4*/
            {
              v13 &= ~2u; /*0x14103b7e6*/
              v94 = v13; /*0x14103b7e9*/
              if ( v86._Mypair._Myval2._Myres >= 0x10 ) /*0x14103b7fa*/
              {
                v16 = v86._Mypair._Myval2._Bx._Ptr; /*0x14103b7ff*/
                if ( v86._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103b810*/
                {
                  v16 = *((char **)v86._Mypair._Myval2._Bx._Ptr - 1); /*0x14103b816*/
                  if ( (unsigned __int64)(v86._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x14103b825*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14103b827*/
                }
                operator delete(ptr: v16); /*0x14103b82e*/
              }
              v86._Mypair._Myval2._Mysize = 0; /*0x14103b833*/
              v86._Mypair._Myval2._Myres = 15; /*0x14103b83a*/
              v86._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103b845*/
            }
            if ( (v13 & 1) != 0 ) /*0x14103b850*/
            {
              v13 &= ~1u; /*0x14103b852*/
              v94 = v13; /*0x14103b855*/
              if ( v66._Mypair._Myval2._Myres >= 0x10 ) /*0x14103b863*/
              {
                v17 = v66._Mypair._Myval2._Bx._Ptr; /*0x14103b868*/
                if ( v66._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103b876*/
                {
                  v17 = *((char **)v66._Mypair._Myval2._Bx._Ptr - 1); /*0x14103b87c*/
                  if ( (unsigned __int64)(v66._Mypair._Myval2._Bx._Ptr - v17 - 8) > 0x1F ) /*0x14103b88b*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14103b88d*/
                }
                operator delete(ptr: v17); /*0x14103b894*/
              }
              v66._Mypair._Myval2._Mysize = 0; /*0x14103b899*/
              v66._Mypair._Myval2._Myres = 15; /*0x14103b89d*/
              v66._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103b8a5*/
            }
            if ( v70._Mypair._Myval2._Myres >= 0x10 ) /*0x14103b8b4*/
            {
              v18 = v70._Mypair._Myval2._Bx._Ptr; /*0x14103b8b9*/
              if ( v70._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103b8ca*/
              {
                v18 = *((char **)v70._Mypair._Myval2._Bx._Ptr - 1); /*0x14103b8d0*/
                if ( (unsigned __int64)(v70._Mypair._Myval2._Bx._Ptr - v18 - 8) > 0x1F ) /*0x14103b8df*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14103b8e1*/
              }
              operator delete(ptr: v18); /*0x14103b8e8*/
            }
            goto LABEL_308; /*0xf1c0000000000394*/
          }
        }
        else
        {
          ptr[0] = nullptr; /*0x14103b6e3*/
          v85 = 15; /*0x14103b6ea*/
          ptr[2] = nullptr; /*0x14103b6f5*/
          v12 = (std::string *)ptr; /*0x14103b6fc*/
          v13 = 4; /*0x14103b703*/
          v94 = 4; /*0x14103b708*/
        }
        if ( userInfo.alternateName._Mypair._Myval2._Myres >= 0x10 ) /*0x14103b719*/
        {
          v14 = userInfo.alternateName._Mypair._Myval2._Bx._Ptr; /*0x14103b71e*/
          if ( userInfo.alternateName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103b72f*/
          {
            v14 = *((char **)userInfo.alternateName._Mypair._Myval2._Bx._Ptr - 1); /*0x14103b735*/
            if ( (unsigned __int64)(userInfo.alternateName._Mypair._Myval2._Bx._Ptr - v14 - 8) > 0x1F ) /*0x14103b744*/
LABEL_42:
              _invalid_parameter_noinfo_noreturn(); /*0x14103b7d3*/
          }
          operator delete(ptr: v14); /*0x14103b74a*/
        }
        userInfo.alternateName._Mypair._Myval2._Mysize = 0; /*0x14103b74f*/
        userInfo.alternateName._Mypair._Myval2._Myres = 15; /*0x14103b756*/
        userInfo.alternateName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103b761*/
        userInfo.alternateName = *v12; /*0x14103b76b*/
        v12->_Mypair._Myval2._Mysize = 0; /*0x14103b77d*/
        v12->_Mypair._Myval2._Myres = 15; /*0x14103b781*/
        v12->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103b789*/
        goto LABEL_38; /*0x14103b789*/
      }
      __unwind
      {
        if ( (v94 & 1) != 0 ) /*0x1431e79b4*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v66); /*0x1431e79c4*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v70); /*0xf1c000000000022c*/
    }
LABEL_308:
    v63._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b8ed*/
    v63._Mypair._Myval2._Mysize = 0; /*0x14103b8f2*/
    v63._Mypair._Myval2._Myres = 15; /*0x14103b8f7*/
    if ( DFFlag::ConsumePlatformNameOverAlternateName.value ) /*0x14103b911*/
    {
      std::string::assign(this: &v63, _Ptr: "PlatformName", _Count: 0xCu); /*0x14103b924*/
      __eh34_enter_wind_state(0, 7); /*0xf1c0000000000208*/
      if ( RBX::GameConfigurer::isParamExist(this, key: &v63) ) /*0x14103b932*/
      {
        v62._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b93b*/
        v62._Mypair._Myval2._Mysize = 0; /*0x14103b940*/
        v62._Mypair._Myval2._Myres = 15; /*0x14103b945*/
        std::string::assign(this: &v62, _Ptr: "PlatformName", _Count: 0xCu); /*0x14103b965*/
        __eh34_enter_wind_state(7, 8); /*0xf1c0000000000200*/
        v19 = RBX::GameConfigurer::getParamString(this, result: &v65, key: &v62); /*0x14103b985*/
        __eh34_enter_wind_state(8, 9); /*0xf1c00000000001f8*/
        v20 = v13 | 0x18; /*0x14103b988*/
        v95 = v20; /*0x14103b98b*/
        if ( &userInfo.platformName == v19 ) /*0x14103b99b*/
        {
          if ( __eh34_unwind(9) ) /*0xf1c000000000029c*/
          {
_RBX__PlayerConfigurer__createPlayer____1___dtor$11:
            if ( (v20 & 0x10) != 0 ) /*0x1431e7a44*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v65); /*0x1431e7a54*/
            __eh34_continue_unwinding(9, 8); /*0xf1c00000000002a4*/
          }
          __eh34_exit_wind_state(9, 8); /*0xf1c00000000002a8*/
          if ( __eh34_unwind(8) ) /*0xf1c00000000002ac*/
          {
_RBX__PlayerConfigurer__createPlayer____1___dtor$10:
            if ( (v20 & 8) != 0 ) /*0x1431e7a14*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v62); /*0x1431e7a21*/
            __eh34_continue_unwinding(8, 7); /*0xf1c00000000002b4*/
          }
          __eh34_exit_wind_state(8, 7); /*0xf1c00000000002b8*/
LABEL_73:
          if ( (v20 & 0x20) != 0 ) /*0x14103ba64*/
          {
            v20 &= ~0x20u; /*0x14103ba66*/
            v95 = v20; /*0x14103ba69*/
            if ( v71._Mypair._Myval2._Myres >= 0x10 ) /*0x14103ba7a*/
            {
              v22 = v71._Mypair._Myval2._Bx._Ptr; /*0x14103ba7f*/
              if ( v71._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103ba90*/
              {
                v22 = *((char **)v71._Mypair._Myval2._Bx._Ptr - 1); /*0x14103ba96*/
                if ( (unsigned __int64)(v71._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x14103baa5*/
                  goto LABEL_77; /*0x14103baa5*/
              }
              operator delete(ptr: v22); /*0x14103baae*/
            }
          }
          if ( (v20 & 0x10) != 0 ) /*0x14103bab8*/
          {
            v20 &= ~0x10u; /*0x14103baba*/
            v95 = v20; /*0x14103babd*/
            if ( v65._Mypair._Myval2._Myres >= 0x10 ) /*0x14103bacb*/
              std::allocator<RBX::Voxel2::Mesher::Quad>::deallocate( /*0x14103bad8*/
                this: (std::allocator<signed char> *)&v65,
                _Ptr: v65._Mypair._Myval2._Bx._Ptr,
                _Count: v65._Mypair._Myval2._Myres + 1);
            v65._Mypair._Myval2._Mysize = 0; /*0x14103badd*/
            v65._Mypair._Myval2._Myres = 15; /*0x14103bae1*/
            v65._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103bae9*/
          }
          if ( (v20 & 8) != 0 ) /*0x14103baf1*/
          {
            v20 &= ~8u; /*0x14103baf3*/
            v95 = v20; /*0x14103baf6*/
            if ( v62._Mypair._Myval2._Myres >= 0x10 ) /*0x14103bb05*/
            {
              v23 = v62._Mypair._Myval2._Bx._Ptr; /*0x14103bb0a*/
              if ( v62._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103bb19*/
              {
                v23 = *((char **)v62._Mypair._Myval2._Bx._Ptr - 1); /*0x14103bb1f*/
                if ( (unsigned __int64)(v62._Mypair._Myval2._Bx._Ptr - v23 - 8) > 0x1F ) /*0x14103bb2e*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14103bb30*/
              }
              operator delete(ptr: v23); /*0x14103bb37*/
            }
            v62._Mypair._Myval2._Mysize = 0; /*0x14103bb3c*/
            v62._Mypair._Myval2._Myres = 15; /*0x14103bb41*/
            v62._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103bb4a*/
          }
          if ( v63._Mypair._Myval2._Myres < 0x10 ) /*0x14103bb58*/
            goto LABEL_301; /*0x14103bb58*/
          v24 = v63._Mypair._Myval2._Bx._Ptr; /*0x14103bb61*/
          if ( v63._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103bb70*/
          {
            v24 = *((char **)v63._Mypair._Myval2._Bx._Ptr - 1); /*0x14103bb7a*/
            if ( (unsigned __int64)(v63._Mypair._Myval2._Bx._Ptr - v24 - 8) > 0x1F ) /*0x14103bb89*/
              _invalid_parameter_noinfo_noreturn(); /*0x14103bb8f*/
          }
          goto LABEL_122; /*0x14103bb89*/
        }
        if ( __eh34_unwind(9) ) /*0xf1c00000000002c0*/
          goto _RBX__PlayerConfigurer__createPlayer____1___dtor$11; /*0xf1c00000000002c0*/
        __eh34_exit_wind_state(9, 8); /*0xf1c00000000002c4*/
        if ( __eh34_unwind(8) ) /*0xf1c00000000002c8*/
          goto _RBX__PlayerConfigurer__createPlayer____1___dtor$10; /*0xf1c00000000002c8*/
        __eh34_exit_wind_state(8, 7); /*0xf1c00000000002cc*/
      }
      else
      {
        v71._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103b9a3*/
        v71._Mypair._Myval2._Mysize = 0; /*0x14103b9aa*/
        v71._Mypair._Myval2._Myres = 15; /*0x14103b9b1*/
        std::string::assign(this: &v71, _Ptr: pass, _Count: 0); /*0x14103b9cd*/
        v19 = &v71; /*0x14103b9d2*/
        v20 = v13 | 0x20; /*0x14103b9d9*/
        v95 = v20; /*0x14103b9dc*/
      }
      if ( userInfo.platformName._Mypair._Myval2._Myres >= 0x10 ) /*0x14103b9ed*/
      {
        v21 = userInfo.platformName._Mypair._Myval2._Bx._Ptr; /*0x14103b9f2*/
        if ( userInfo.platformName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103ba03*/
        {
          v21 = *((char **)userInfo.platformName._Mypair._Myval2._Bx._Ptr - 1); /*0x14103ba09*/
          if ( (unsigned __int64)(userInfo.platformName._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x14103ba18*/
LABEL_77:
            _invalid_parameter_noinfo_noreturn(); /*0x14103baa7*/
        }
        operator delete(ptr: v21); /*0x14103ba1e*/
      }
      userInfo.platformName._Mypair._Myval2._Mysize = 0; /*0x14103ba23*/
      userInfo.platformName._Mypair._Myval2._Myres = 15; /*0x14103ba2a*/
      userInfo.platformName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103ba35*/
      userInfo.platformName = *v19; /*0x14103ba3f*/
      v19->_Mypair._Myval2._Mysize = 0; /*0x14103ba51*/
      v19->_Mypair._Myval2._Myres = 15; /*0x14103ba55*/
      v19->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103ba5d*/
      goto LABEL_73; /*0x14103ba5d*/
    }
    std::string::assign(this: &v63, _Ptr: "AlternateName", _Count: 0xDu); /*0x14103bba3*/
    __eh34_enter_wind_state(0, 7); /*0xf1c00000000001f0*/
    if ( RBX::GameConfigurer::isParamExist(this, key: &v63) ) /*0x14103bbb1*/
    {
      v62._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103bbba*/
      v62._Mypair._Myval2._Mysize = 0; /*0x14103bbbf*/
      v62._Mypair._Myval2._Myres = 15; /*0x14103bbc4*/
      std::string::assign(this: &v62, _Ptr: "AlternateName", _Count: 0xDu); /*0x14103bbe4*/
      __eh34_enter_wind_state(7, 10); /*0xf1c00000000001e8*/
      v25 = RBX::GameConfigurer::getParamString(this, result: &v71, key: &v62); /*0x14103bc07*/
      __eh34_enter_wind_state(10, 11); /*0xf1c00000000001e0*/
      v20 = v13 | 0xC0; /*0x14103bc0a*/
      v95 = v20; /*0x14103bc0e*/
      if ( &userInfo.platformName == v25 ) /*0x14103bc1e*/
      {
        if ( __eh34_unwind(11) ) /*0xf1c0000000000264*/
        {
_RBX__PlayerConfigurer__createPlayer____1___dtor$15:
          if ( (v20 & 0x80) != 0 ) /*0x1431e7aa6*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v71); /*0x1431e7ab9*/
          __eh34_continue_unwinding(11, 10); /*0xf1c000000000026c*/
        }
        __eh34_exit_wind_state(11, 10); /*0xf1c0000000000270*/
        if ( __eh34_unwind(10) ) /*0xf1c0000000000274*/
        {
_RBX__PlayerConfigurer__createPlayer____1___dtor$14:
          if ( (v20 & 0x40) != 0 ) /*0x1431e7a74*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v62); /*0x1431e7a81*/
          __eh34_continue_unwinding(10, 7); /*0xf1c000000000027c*/
        }
        __eh34_exit_wind_state(10, 7); /*0xf1c0000000000280*/
        goto LABEL_103; /*0xf1c0000000000284*/
      }
      if ( __eh34_unwind(11) ) /*0xf1c0000000000288*/
        goto _RBX__PlayerConfigurer__createPlayer____1___dtor$15; /*0xf1c0000000000288*/
      __eh34_exit_wind_state(11, 10); /*0xf1c000000000028c*/
      if ( __eh34_unwind(10) ) /*0xf1c0000000000290*/
        goto _RBX__PlayerConfigurer__createPlayer____1___dtor$14; /*0xf1c0000000000290*/
      __eh34_exit_wind_state(10, 7); /*0xf1c0000000000294*/
    }
    else
    {
      v65._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103bc26*/
      v65._Mypair._Myval2._Mysize = 0; /*0x14103bc2a*/
      v65._Mypair._Myval2._Myres = 15; /*0x14103bc2e*/
      std::string::assign(this: &v65, _Ptr: pass, _Count: 0); /*0x14103bc44*/
      v25 = &v65; /*0x14103bc49*/
      v20 = v13 | 0x100; /*0x14103bc4d*/
      v95 = v20; /*0x14103bc51*/
    }
    if ( userInfo.platformName._Mypair._Myval2._Myres >= 0x10 ) /*0x14103bc62*/
    {
      v26 = userInfo.platformName._Mypair._Myval2._Bx._Ptr; /*0x14103bc67*/
      if ( userInfo.platformName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103bc78*/
      {
        v26 = *((char **)userInfo.platformName._Mypair._Myval2._Bx._Ptr - 1); /*0x14103bc7e*/
        if ( (unsigned __int64)(userInfo.platformName._Mypair._Myval2._Bx._Ptr - v26 - 8) > 0x1F ) /*0x14103bc8d*/
LABEL_107:
          _invalid_parameter_noinfo_noreturn(); /*0x14103bd17*/
      }
      operator delete(ptr: v26); /*0x14103bc93*/
    }
    userInfo.platformName._Mypair._Myval2._Mysize = 0; /*0x14103bc98*/
    userInfo.platformName._Mypair._Myval2._Myres = 15; /*0x14103bc9f*/
    userInfo.platformName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103bcaa*/
    userInfo.platformName = *v25; /*0x14103bcb4*/
    v25->_Mypair._Myval2._Mysize = 0; /*0x14103bcc6*/
    v25->_Mypair._Myval2._Myres = 15; /*0x14103bcca*/
    v25->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103bcd2*/
LABEL_103:
    if ( (v20 & 0x100) != 0 ) /*0x14103bcd9*/
    {
      v20 &= ~0x100u; /*0x14103bcdb*/
      v95 = v20; /*0x14103bcdf*/
      if ( v65._Mypair._Myval2._Myres >= 0x10 ) /*0x14103bced*/
      {
        v27 = v65._Mypair._Myval2._Bx._Ptr; /*0x14103bcf2*/
        if ( v65._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103bd00*/
        {
          v27 = *((char **)v65._Mypair._Myval2._Bx._Ptr - 1); /*0x14103bd06*/
          if ( (unsigned __int64)(v65._Mypair._Myval2._Bx._Ptr - v27 - 8) > 0x1F ) /*0x14103bd15*/
            goto LABEL_107; /*0x14103bd15*/
        }
        operator delete(ptr: v27); /*0x14103bd1e*/
      }
    }
    if ( (v20 & 0x80u) != 0 ) /*0x14103bd27*/
    {
      v20 &= ~0x80u; /*0x14103bd29*/
      v95 = v20; /*0x14103bd2d*/
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v71); /*0x14103bd3a*/
    }
    if ( (v20 & 0x40) != 0 ) /*0x14103bd44*/
    {
      v20 &= ~0x40u; /*0x14103bd46*/
      v95 = v20; /*0x14103bd49*/
      if ( v62._Mypair._Myval2._Myres >= 0x10 ) /*0x14103bd58*/
      {
        v28 = v62._Mypair._Myval2._Bx._Ptr; /*0x14103bd5d*/
        if ( v62._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103bd6c*/
        {
          v28 = *((char **)v62._Mypair._Myval2._Bx._Ptr - 1); /*0x14103bd72*/
          if ( (unsigned __int64)(v62._Mypair._Myval2._Bx._Ptr - v28 - 8) > 0x1F ) /*0x14103bd81*/
            _invalid_parameter_noinfo_noreturn(); /*0x14103bd83*/
        }
        operator delete(ptr: v28); /*0x14103bd8a*/
      }
      v62._Mypair._Myval2._Mysize = 0; /*0x14103bd8f*/
      v62._Mypair._Myval2._Myres = 15; /*0x14103bd94*/
      v62._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103bd9d*/
    }
    if ( v63._Mypair._Myval2._Myres >= 0x10 ) /*0x14103bdab*/
    {
      v24 = v63._Mypair._Myval2._Bx._Ptr; /*0x14103bdb0*/
      if ( v63._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103bdbf*/
      {
        v24 = *((char **)v63._Mypair._Myval2._Bx._Ptr - 1); /*0x14103bdc5*/
        if ( (unsigned __int64)(v63._Mypair._Myval2._Bx._Ptr - v24 - 8) > 0x1F ) /*0x14103bdd4*/
          _invalid_parameter_noinfo_noreturn(); /*0x14103bdd6*/
      }
LABEL_122:
      operator delete(ptr: v24); /*0x14103bddd*/
    }
    if ( __eh34_unwind(7) ) /*0xf1c00000000001cc*/
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v63); /*0xf1c00000000001d0*/
      __eh34_continue_unwinding(7, 0); /*0xf1c00000000001d4*/
    }
LABEL_301:
    __eh34_exit_wind_state(7, 0); /*0xf1c00000000001d8*/
    GameLocaleIdFromParams = RBX::PlayerConfigurer::getGameLocaleIdFromParams(this, result: &v89); /*0x14103bdf1*/
    if ( &userInfo.gameLocaleId != GameLocaleIdFromParams ) /*0x14103bdfb*/
    {
      if ( userInfo.gameLocaleId._Mypair._Myval2._Myres >= 0x10 ) /*0x14103be05*/
      {
        v30 = userInfo.gameLocaleId._Mypair._Myval2._Bx._Ptr; /*0x14103be0a*/
        if ( userInfo.gameLocaleId._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103be18*/
        {
          v30 = *((char **)userInfo.gameLocaleId._Mypair._Myval2._Bx._Ptr - 1); /*0x14103be1e*/
          if ( (unsigned __int64)(userInfo.gameLocaleId._Mypair._Myval2._Bx._Ptr - v30 - 8) > 0x1F ) /*0x14103be2d*/
            _invalid_parameter_noinfo_noreturn(); /*0x14103be2f*/
        }
        operator delete(ptr: v30); /*0x14103be36*/
      }
      userInfo.gameLocaleId._Mypair._Myval2._Mysize = 0; /*0x14103be3b*/
      userInfo.gameLocaleId._Mypair._Myval2._Myres = 15; /*0x14103be3f*/
      userInfo.gameLocaleId._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103be47*/
      userInfo.gameLocaleId = *GameLocaleIdFromParams; /*0x14103be4e*/
      GameLocaleIdFromParams->_Mypair._Myval2._Mysize = 0; /*0x14103be5a*/
      GameLocaleIdFromParams->_Mypair._Myval2._Myres = 15; /*0x14103be5e*/
      GameLocaleIdFromParams->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103be66*/
    }
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v89); /*0x14103be70*/
    LODWORD(v98) = RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2->storage.asRaw[0] /*0x14103be80*/
                 - LODWORD(RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2);
    HIDWORD(v98) = RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2->storage.asRaw[1] /*0x14103be8b*/
                 - LODWORD(RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2);
    v31 = RBX::Players::createLocalPlayer( /*0x14103beb0*/
            this: v3,
            result: &v87,
            &userInfo,
            teleportedIn: v98 > 0,
            previousUniverseId: 0);
    v32 = v31; /*0x14103beb5*/
    __wind /*0xf1c0000000000190*/
    {
      if ( v31->_Ptr != nullptr /*0x14103bee2*/
        && (descriptor = v31->_Ptr->descriptor,
            v34 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(),
            descriptor->index - (unsigned int)v34->index <= v34->descendantCount) )
      {
        v35 = v32->_Ptr; /*0x14103bee4*/
        Rep = v32->_Rep; /*0x14103bee7*/
        if ( Rep != nullptr ) /*0x14103beee*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x14103bef0*/
          Rep = v32->_Rep; /*0x14103bef4*/
          v20 = v95; /*0x14103bef8*/
        }
        v81 = Rep; /*0x14103befe*/
        p_color = &v80.color; /*0x14103bf05*/
        v38 = v20 | 0x200; /*0x14103bf0c*/
      }
      else
      {
        *(_QWORD *)&v80.width = 0; /*0x14103bf12*/
        p_color = &v80.x; /*0x14103bf19*/
        v38 = v20 | 0x400; /*0x14103bf20*/
        v35 = nullptr; /*0x14103bf24*/
      }
      player._Ptr = v35; /*0x14103bf27*/
      v39 = (std::_Ref_count_base *)p_color[1]; /*0x14103bf2e*/
      player._Rep = v39; /*0x14103bf32*/
      *p_color = 0; /*0x14103bf39*/
      p_color[1] = 0; /*0x14103bf3c*/
      v40 = v38 | 0x800; /*0x14103bf40*/
      if ( (v40 & 0x400) != 0 ) /*0x14103bf4e*/
      {
        v40 &= ~0x400u; /*0x14103bf50*/
        if ( *(_QWORD *)&v80.width != 0 ) /*0x14103bf64*/
          std::_Ref_count_base::_Decref(this: *(std::_Ref_count_base **)&v80.width); /*0x14103bf66*/
      }
      if ( (v40 & 0x200) != 0 && v81 != nullptr ) /*0x14103bf7b*/
        std::_Ref_count_base::_Decref(this: v81); /*0x14103bf7d*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v87); /*0xf1c00000000001a0*/
    }
    __wind /*0xf1c00000000001a8*/
    {
      if ( v87._Rep != nullptr ) /*0x14103bf8d*/
        std::_Ref_count_base::_Decref(this: v87._Rep); /*0x14103bf8f*/
      dataModel = this->dataModel; /*0x14103bf94*/
      v42 = &dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>; /*0x14103bf98*/
      if ( dataModel == nullptr ) /*0x14103bf9f*/
        v42 = nullptr; /*0x14103bf9f*/
      v43 = RBX::ServiceProvider::find<RBX::VRService>(serviceProvider: v42); /*0x14103bfa3*/
      if ( v43 != nullptr ) /*0x14103bfab*/
      {
        std::string::string(this: &v88, __that: (const rtc::webrtc_checks_impl::ToStringVal *)&v43->vrDeviceName); /*0x14103bfbb*/
        RBX::Player::setVRDevice(this: v35, value: &v88.val); /*0x14103bfca*/
      }
      v72._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103bfcf*/
      v72._Mypair._Myval2._Mysize = 0; /*0x14103bfd6*/
      v72._Mypair._Myval2._Myres = 15; /*0x14103bfdd*/
      std::string::assign(this: &v72, _Ptr: "SuperSafeChat", _Count: 0xDu); /*0x14103c003*/
      __wind /*0xf1c0000000000184*/
      {
        ParamBool = RBX::GameConfigurer::getParamBool(this, key: &v72); /*0x14103c013*/
        RBX::Player::setSuperSafeChat(this: v35, value: ParamBool); /*0x14103c01e*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v72); /*0xf1c000000000017c*/
      }
      if ( v72._Mypair._Myval2._Myres >= 0x10 ) /*0x14103c02f*/
      {
        v45 = v72._Mypair._Myval2._Bx._Ptr; /*0x14103c034*/
        if ( v72._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103c045*/
        {
          v45 = *((char **)v72._Mypair._Myval2._Bx._Ptr - 1); /*0x14103c04b*/
          if ( (unsigned __int64)(v72._Mypair._Myval2._Bx._Ptr - v45 - 8) > 0x1F ) /*0x14103c05a*/
            _invalid_parameter_noinfo_noreturn(); /*0x14103c05c*/
        }
        operator delete(ptr: v45); /*0x14103c063*/
      }
      v46 = (_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL); /*0x14103c080*/
      if ( __TSS0__1__singleton___EnumDesc_W4MembershipType_RBX___Reflection_RBX__SAAEBV234_XZ_4HA > *v46 ) /*0x14103c08b*/
      {
        __wind /*0xf1c0000000000040*/
        {
          Init_thread_header(pOnce: &__TSS0__1__singleton___EnumDesc_W4MembershipType_RBX___Reflection_RBX__SAAEBV234_XZ_4HA); /*0x14103c633*/
          if ( __TSS0__1__singleton___EnumDesc_W4MembershipType_RBX___Reflection_RBX__SAAEBV234_XZ_4HA == -1 ) /*0x14103c63f*/
          {
            RBX::Reflection::EnumDesc<enum RBX::MembershipType>::EnumDesc<enum RBX::MembershipType>(this: &`RBX::Reflection::EnumDesc<enum RBX::MembershipType>::singleton'::`2'::obj); /*0x14103c64c*/
            atexit(function: `RBX::Reflection::EnumDesc<enum RBX::MembershipType>::singleton'::`2'::`dynamic atexit destructor for 'obj''); /*0x14103c658*/
            Init_thread_footer(pOnce: &__TSS0__1__singleton___EnumDesc_W4MembershipType_RBX___Reflection_RBX__SAAEBV234_XZ_4HA); /*0x14103c665*/
          }
        }
        __unwind
        {
          Init_thread_abort(pOnce: &__TSS0__1__singleton___EnumDesc_W4MembershipType_RBX___Reflection_RBX__SAAEBV234_XZ_4HA); /*0x1431e5167*/
        }
      }
      v73._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103c091*/
      v73._Mypair._Myval2._Mysize = 0; /*0x14103c098*/
      v73._Mypair._Myval2._Myres = 15; /*0x14103c09f*/
      std::string::assign(this: &v73, _Ptr: "MembershipType", _Count: 0xEu); /*0x14103c0c5*/
      __wind /*0xf1c000000000016c*/
      {
        v47 = RBX::GameConfigurer::getParamString(this, result: &v90, key: &v73); /*0x14103c0dc*/
        __wind /*0xf1c0000000000160*/
        {
          if ( v47->_Mypair._Myval2._Myres >= 0x10 ) /*0x14103c0e7*/
            v47 = (std::string *)v47->_Mypair._Myval2._Bx._Ptr; /*0x14103c0e9*/
          RBX::Reflection::EnumDescriptor::_convertToValue( /*0x14103c0fd*/
            this: &`RBX::Reflection::EnumDesc<enum RBX::MembershipType>::singleton'::`2'::obj,
            text: v47->_Mypair._Myval2._Bx._Buf,
            value: (int *)&membershipType);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v90); /*0xf1c0000000000158*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v90); /*0x14103c10a*/
        if ( v73._Mypair._Myval2._Myres >= 0x10 ) /*0x14103c11b*/
        {
          v48 = v73._Mypair._Myval2._Bx._Ptr; /*0x14103c120*/
          if ( v73._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103c131*/
          {
            v48 = *((char **)v73._Mypair._Myval2._Bx._Ptr - 1); /*0x14103c137*/
            if ( (unsigned __int64)(v73._Mypair._Myval2._Bx._Ptr - v48 - 8) > 0x1F ) /*0x14103c146*/
              _invalid_parameter_noinfo_noreturn(); /*0x14103c148*/
          }
          operator delete(ptr: v48); /*0x14103c14f*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v73); /*0xf1c000000000014c*/
      }
      RBX::Player::setMembershipType(this: v35, value: membershipType); /*0x14103c15d*/
      v74._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103c162*/
      v74._Mypair._Myval2._Mysize = 0; /*0x14103c169*/
      v74._Mypair._Myval2._Myres = 15; /*0x14103c170*/
      std::string::assign(this: &v74, _Ptr: "AccountAge", _Count: 0xAu); /*0x14103c196*/
      __wind /*0xf1c000000000013c*/
      {
        ParamInt = RBX::GameConfigurer::getParamInt(this, key: &v74); /*0x14103c1a6*/
        RBX::Player::setAccountAge(this: v35, value: ParamInt); /*0x14103c1b0*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v74); /*0xf1c0000000000134*/
      }
      if ( v74._Mypair._Myval2._Myres >= 0x10 ) /*0x14103c1c1*/
      {
        v50 = v74._Mypair._Myval2._Bx._Ptr; /*0x14103c1c6*/
        if ( v74._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103c1d7*/
        {
          v50 = *((char **)v74._Mypair._Myval2._Bx._Ptr - 1); /*0x14103c1dd*/
          if ( (unsigned __int64)(v74._Mypair._Myval2._Bx._Ptr - v50 - 8) > 0x1F ) /*0x14103c1ec*/
            _invalid_parameter_noinfo_noreturn(); /*0x14103c1ee*/
        }
        operator delete(ptr: v50); /*0x14103c1f5*/
      }
      v75._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103c1fa*/
      v75._Mypair._Myval2._Mysize = 0; /*0x14103c201*/
      v75._Mypair._Myval2._Myres = 15; /*0x14103c208*/
      std::string::assign(this: &v75, _Ptr: aCountryc, _Count: 0xBu); /*0x14103c22e*/
      __wind /*0xf1c0000000000124*/
      {
        v51 = RBX::GameConfigurer::getParamString(this, result: &v91, key: &v75); /*0x14103c245*/
        __wind /*0xf1c0000000000118*/
        {
          RBX::Player::setCountryRegionCode(this: v35, countryRegion: v51); /*0x14103c251*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v91); /*0xf1c0000000000110*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v91); /*0x14103c25e*/
        if ( v75._Mypair._Myval2._Myres >= 0x10 ) /*0x14103c26f*/
        {
          v52 = v75._Mypair._Myval2._Bx._Ptr; /*0x14103c274*/
          if ( v75._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103c285*/
          {
            v52 = *((char **)v75._Mypair._Myval2._Bx._Ptr - 1); /*0x14103c28b*/
            if ( (unsigned __int64)(v75._Mypair._Myval2._Bx._Ptr - v52 - 8) > 0x1F ) /*0x14103c29a*/
              _invalid_parameter_noinfo_noreturn(); /*0x14103c29c*/
          }
          operator delete(ptr: v52); /*0x14103c2a3*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v75); /*0xf1c0000000000104*/
      }
      if ( FFlag::DebugForceChatDisabled.value ) /*0x14103c2af*/
      {
        v53 = NoOne; /*0x14103c2b1*/
      }
      else
      {
        if ( __TSS0__1__singleton___EnumDesc_W4ChatPrivacyMode_Player_RBX___Reflection_RBX__SAAEBV234_XZ_4HA > *v46 ) /*0x14103c2c3*/
        {
          Init_thread_header(pOnce: &__TSS0__1__singleton___EnumDesc_W4ChatPrivacyMode_Player_RBX___Reflection_RBX__SAAEBV234_XZ_4HA); /*0x14103c5f0*/
          if ( __TSS0__1__singleton___EnumDesc_W4ChatPrivacyMode_Player_RBX___Reflection_RBX__SAAEBV234_XZ_4HA == -1 ) /*0x14103c5fc*/
          {
            __wind /*0xf1c0000000000058*/
            {
              RBX::Reflection::EnumDesc<enum RBX::Player::ChatPrivacyMode>::EnumDesc<enum RBX::Player::ChatPrivacyMode>(this: &`RBX::Reflection::EnumDesc<enum RBX::Player::ChatPrivacyMode>::singleton'::`2'::obj); /*0x14103c609*/
              atexit(function: `RBX::Reflection::EnumDesc<enum RBX::Player::ChatPrivacyMode>::singleton'::`2'::`dynamic atexit destructor for 'obj''); /*0x14103c615*/
              Init_thread_footer(pOnce: &__TSS0__1__singleton___EnumDesc_W4ChatPrivacyMode_Player_RBX___Reflection_RBX__SAAEBV234_XZ_4HA); /*0x14103c622*/
            }
            __unwind
            {
              Init_thread_abort(pOnce: &__TSS0__1__singleton___EnumDesc_W4ChatPrivacyMode_Player_RBX___Reflection_RBX__SAAEBV234_XZ_4HA); /*0x1431e5147*/
            }
          }
        }
        v76._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103c2c9*/
        v76._Mypair._Myval2._Mysize = 0; /*0x14103c2d0*/
        v76._Mypair._Myval2._Myres = 15; /*0x14103c2d7*/
        std::string::assign(this: &v76, _Ptr: "GameChatType", _Count: 0xCu); /*0x14103c2fd*/
        __wind /*0xf1c00000000000f4*/
        {
          v54 = RBX::GameConfigurer::getParamString(this, result: &v92, key: &v76); /*0x14103c314*/
          if ( v54->_Mypair._Myval2._Myres >= 0x10 ) /*0x14103c31f*/
            v54 = (std::string *)v54->_Mypair._Myval2._Bx._Ptr; /*0x14103c321*/
          __wind /*0xf1c00000000000d0*/
          {
            v55 = RBX::Reflection::EnumDescriptor::_convertToValue( /*0x14103c33a*/
                    this: &`RBX::Reflection::EnumDesc<enum RBX::Player::ChatPrivacyMode>::singleton'::`2'::obj,
                    text: v54->_Mypair._Myval2._Bx._Buf,
                    value: (int *)&chatPrivacyMode);
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v92); /*0x14103c344*/
            if ( v76._Mypair._Myval2._Myres >= 0x10 ) /*0x14103c355*/
            {
              v56 = v76._Mypair._Myval2._Bx._Ptr; /*0x14103c35a*/
              if ( v76._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103c36b*/
              {
                v56 = *((char **)v76._Mypair._Myval2._Bx._Ptr - 1); /*0x14103c371*/
                if ( (unsigned __int64)(v76._Mypair._Myval2._Bx._Ptr - v56 - 8) > 0x1F ) /*0x14103c380*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14103c382*/
              }
              operator delete(ptr: v56); /*0x14103c389*/
            }
            if ( v55 ) /*0x14103c391*/
              v53 = chatPrivacyMode; /*0x14103c393*/
            else
              v53 = AllUsers; /*0x14103c39b*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v92); /*0xf1c00000000000e0*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v76); /*0xf1c00000000000ec*/
        }
      }
      RBX::Player::setChatPrivacyMode(this: v35, value: v53); /*0x14103c3a0*/
      if ( !this->isStudioToRcc ) /*0x14103c3aa*/
        RBX::Player::setChatPrivacyMode(this: v35, value: AllUsers); /*0x14103c3b1*/
      v77._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103c3b6*/
      v77._Mypair._Myval2._Mysize = 0; /*0x14103c3bd*/
      v77._Mypair._Myval2._Myres = 15; /*0x14103c3c4*/
      std::string::assign(this: &v77, _Ptr: "characterAppearanceId", _Count: 0x15u); /*0x14103c3ea*/
      __wind /*0xf1c00000000000c4*/
      {
        ParamInt64 = RBX::GameConfigurer::getParamInt64(this, key: &v77); /*0x14103c3fa*/
        RBX::Player::setCharacterAppearanceId(this: v35, value: ParamInt64); /*0x14103c405*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v77); /*0xf1c00000000000bc*/
      }
      if ( v77._Mypair._Myval2._Myres >= 0x10 ) /*0x14103c416*/
      {
        v58 = v77._Mypair._Myval2._Bx._Ptr; /*0x14103c41b*/
        if ( v77._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103c42c*/
        {
          v58 = *((char **)v77._Mypair._Myval2._Bx._Ptr - 1); /*0x14103c432*/
          if ( (unsigned __int64)(v77._Mypair._Myval2._Bx._Ptr - v58 - 8) > 0x1F ) /*0x14103c441*/
            _invalid_parameter_noinfo_noreturn(); /*0x14103c443*/
        }
        operator delete(ptr: v58); /*0x14103c44a*/
      }
      v78._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103c44f*/
      v78._Mypair._Myval2._Mysize = 0; /*0x14103c456*/
      v78._Mypair._Myval2._Myres = 15; /*0x14103c45d*/
      std::string::assign(this: &v78, _Ptr: "CharacterAppearance", _Count: 0x13u); /*0x14103c483*/
      __wind /*0xf1c00000000000ac*/
      {
        v59 = RBX::GameConfigurer::getParamString(this, result: &v93.text, key: &v78); /*0x14103c49a*/
        __wind /*0xf1c00000000000a0*/
        {
          RBX::Player::setCharacterAppearance(this: v35, value: v59); /*0x14103c4a6*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v93); /*0xf1c0000000000098*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v93); /*0x14103c4b3*/
        if ( v78._Mypair._Myval2._Myres >= 0x10 ) /*0x14103c4c4*/
        {
          v60 = v78._Mypair._Myval2._Bx._Ptr; /*0x14103c4c9*/
          if ( v78._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103c4da*/
          {
            v60 = *((char **)v78._Mypair._Myval2._Bx._Ptr - 1); /*0x14103c4e0*/
            if ( (unsigned __int64)(v78._Mypair._Myval2._Bx._Ptr - v60 - 8) > 0x1F ) /*0x14103c4ef*/
              _invalid_parameter_noinfo_noreturn(); /*0x14103c4f1*/
          }
          operator delete(ptr: v60); /*0x14103c4f8*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v78); /*0xf1c000000000008c*/
      }
      v79._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103c4fd*/
      v79._Mypair._Myval2._Mysize = 0; /*0x14103c504*/
      v79._Mypair._Myval2._Myres = 15; /*0x14103c50b*/
      std::string::assign(this: &v79, _Ptr: "FollowUserId", _Count: 0xCu); /*0x14103c531*/
      __wind /*0xf1c000000000007c*/
      {
        v35->followUserId = RBX::GameConfigurer::getParamInt64(this, key: &v79); /*0x14103c546*/
        if ( v79._Mypair._Myval2._Myres >= 0x10 ) /*0x14103c558*/
        {
          v61 = v79._Mypair._Myval2._Bx._Ptr; /*0x14103c55d*/
          if ( v79._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103c56e*/
          {
            v61 = *((char **)v79._Mypair._Myval2._Bx._Ptr - 1); /*0x14103c574*/
            if ( (unsigned __int64)(v79._Mypair._Myval2._Bx._Ptr - v61 - 8) > 0x1F ) /*0x14103c583*/
              _invalid_parameter_noinfo_noreturn(); /*0x14103c585*/
          }
          operator delete(ptr: v61); /*0x14103c58c*/
        }
        v64 = 0; /*0x14103c594*/
        if ( v39 != nullptr ) /*0x14103c59d*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v39->_Uses); /*0x14103c59f*/
          v39 = player._Rep; /*0x14103c5a3*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v79); /*0xf1c0000000000074*/
      }
      v64._Ptr = (RBX::File *)v35; /*0x14103c5aa*/
      v64._Rep = v39; /*0x14103c5af*/
      RBX::PlayerConfigurer::connectPlayerToSignals(this, player: &v64); /*0x14103c5bc*/
      if ( v39 != nullptr ) /*0x14103c5c5*/
        std::_Ref_count_base::_Decref(this: v39); /*0x14103c5ca*/
      RBX::UserInfo::~UserInfo(this: &userInfo); /*0x14103c5d4*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&player); /*0xf1c00000000001b8*/
    }
  }
  __unwind
  {
    RBX::UserInfo::~UserInfo(this: &userInfo); /*0xf1c00000000001c4*/
  }
}

// Address: 0x14103cb70 | Name: ?fillServerConnectionsArrayFromConfig@PlayerConfigurer@RBX@@AEAAXAEAV?$vector@UServerConnection@Client@Network@RBX@@V?$allocator@UServerConnection@Client@Network@RBX@@@std@@@std@@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@4@@Z
void __fastcall RBX::PlayerConfigurer::fillServerConnectionsArrayFromConfig(
        RBX::PlayerConfigurer *this,
        std::vector<RBX::Network::Client::ServerConnection> *endpoints,
        RBX::Graphics::ProfilerAdorn::Item *key)
{
  RBX::Reflection::Variant *Myfirst; // r12
  __int64 v4; // rcx
  unsigned __int64 i; // rdx
  const std::unordered_map<std::string,RBX::Reflection::Variant> *Ptr; // r15
  unsigned __int64 v7; // rcx
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > > *v8; // rax
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v9; // rsi
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *Myhead; // r14
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v11; // rdi
  char **p_Myval; // rdx
  __int64 v13; // rcx
  unsigned __int64 j; // rdx
  __int64 v15; // rcx
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > > *v16; // rax
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v17; // r8
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v18; // r10
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v19; // r9
  char **v20; // rdx
  __int64 v21; // rax
  unsigned __int8 v22; // cl
  int v23; // eax
  int v24; // ebx
  std::string *v25; // rax
  RBX::Network::Client::ServerConnection *v26; // rax
  std::_Ref_count_base *Rep; // rbx
  RBX::Graphics::ProfilerAdorn::Item *v28; // rdi
  std::_Ref_count_base *v29; // rbx
  unsigned __int64 Myres; // rdx
  char *v31; // rcx
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > oneEndpoint; // [rsp+20h] [rbp-B9h] BYREF
  _WORD Buf1[16]; // [rsp+30h] [rbp-A9h] BYREF
  _QWORD v34[4]; // [rsp+50h] [rbp-89h]
  std::shared_ptr<std::vector<RBX::Reflection::Variant> const > endpointsArray; // [rsp+70h] [rbp-69h] BYREF
  std::string result; // [rsp+88h] [rbp-51h] BYREF
  RBX::Network::Client::ServerConnection v37; // [rsp+A8h] [rbp-31h] BYREF
  RBX::Reflection::Variant *Mylast; // [rsp+158h] [rbp+7Fh]

  __wind
  {
    v28 = key; /*0x14103cb96*/
    RBX::GameConfigurer::getValueArray(this, result: &endpointsArray, key: &key->text); /*0x14103cb9d*/
    __wind
    {
      __eh34_enter_wind_state(1, 2); /*0xf1c0000000000058*/
      if ( endpointsArray._Ptr != nullptr )
      {
        Myfirst = endpointsArray._Ptr->_Mypair._Myval2._Myfirst; /*0x14103cbbb*/
        Mylast = endpointsArray._Ptr->_Mypair._Myval2._Mylast; /*0x14103cbc2*/
        if ( endpointsArray._Ptr->_Mypair._Myval2._Myfirst != Mylast )
        {
          do
          {
            if ( __eh34_unwind(2) ) /*0xf1c0000000000024*/
            {
unwind_state_2:
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&oneEndpoint); /*0xf1c0000000000028*/
              __eh34_continue_unwinding(2, 1); /*0xf1c000000000002c*/
            }
            __eh34_exit_wind_state(2, 1); /*0xf1c0000000000030*/
            RBX::Reflection::Variant::get<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>( /*0x14103cbeb*/
              this: Myfirst,
              result: &oneEndpoint);
            *(_QWORD *)&Buf1[12] = 15; /*0x14103cbfc*/
            *(_QWORD *)&Buf1[8] = 7; /*0x14103cc07*/
            qmemcpy(Buf1, "Addres", 6); /*0x14103cc12*/
            Buf1[3] = (unsigned __int8)aAddress[6]; /*0x14103cc29*/
            v4 = 0xCBF29CE484222325uLL; /*0x14103cc3c*/
            for ( i = 0; i < 7; ++i ) /*0x14103cc3f*/
              v4 = 0x100000001B3LL * (*((unsigned __int8 *)Buf1 + i) ^ (unsigned __int64)v4); /*0x14103cc58*/
            Ptr = oneEndpoint._Ptr; /*0x14103cc64*/
            v7 = 2 * (oneEndpoint._Ptr->_Mask & v4); /*0x14103cc6d*/
            v8 = oneEndpoint._Ptr->_Vec._Mypair._Myval2._Myfirst; /*0x14103cc70*/
            v9 = v8[v7 + 1]._Ptr; /*0x14103cc74*/
            Myhead = oneEndpoint._Ptr->_List._Mypair._Myval2._Myhead; /*0x14103cc79*/
            if ( v9 == Myhead ) /*0x14103cc80*/
              goto LABEL_15; /*0x14103cc80*/
            v11 = v8[v7]._Ptr; /*0x14103cc82*/
            while ( 1 ) /*0x14103cc90*/
            {
              p_Myval = (char **)&v9->_Myval; /*0x14103cc90*/
              if ( v9->_Myval.first._Mypair._Myval2._Myres >= 0x10 ) /*0x14103cc9d*/
                p_Myval = (char **)*p_Myval; /*0x14103cc9f*/
              if ( v9->_Myval.first._Mypair._Myval2._Mysize == 7 && memcmp_0(Buf1, Buf2: p_Myval, Size: 7u) == 0 ) /*0x14103ccbe*/
                break; /*0x14103ccbe*/
              if ( v9 == v11 ) /*0x14103cccd*/
                goto LABEL_15; /*0x14103cccd*/
              v9 = v9->_Prev; /*0x14103cccf*/
            }
            if ( v9 == nullptr ) /*0x14103ccd8*/
LABEL_15:
              v9 = Myhead; /*0x14103ccda*/
            v34[3] = 15; /*0x14103ccea*/
            v34[2] = 4; /*0x14103ccee*/
            v34[0] = 1953656656; /*0x14103ccf6*/
            v13 = 0xCBF29CE484222325uLL; /*0x14103cd03*/
            for ( j = 0; j < 4; ++j ) /*0x14103cd0d*/
              v13 = 0x100000001B3LL * (*((unsigned __int8 *)v34 + j) ^ (unsigned __int64)v13); /*0x14103cd28*/
            v15 = 2 * (Ptr->_Mask & v13); /*0x14103cd39*/
            v16 = Ptr->_Vec._Mypair._Myval2._Myfirst; /*0x14103cd3c*/
            v17 = v16[v15 + 1]._Ptr; /*0x14103cd40*/
            v18 = Ptr->_List._Mypair._Myval2._Myhead; /*0x14103cd45*/
            if ( v17 == v18 ) /*0x14103cd4c*/
              goto LABEL_32; /*0x14103cd4c*/
            v19 = v16[v15]._Ptr; /*0x14103cd4e*/
            while ( 1 )
            {
              v20 = (char **)&v17->_Myval; /*0x14103cd60*/
              if ( v17->_Myval.first._Mypair._Myval2._Myres >= 0x10 ) /*0x14103cd6d*/
                v20 = (char **)*v20; /*0x14103cd6f*/
              if ( v17->_Myval.first._Mypair._Myval2._Mysize == 4 )
              {
                v21 = 0; /*0x14103cd78*/
                while ( 1 ) /*0x14103cd80*/
                {
                  v22 = *((_BYTE *)v34 + v21++); /*0x14103cd80*/
                  if ( v22 != *((_BYTE *)v20 + v21 - 1) ) /*0x14103cd8c*/
                    break; /*0x14103cd8c*/
                  if ( v21 == 4 ) /*0x14103cd92*/
                  {
                    v23 = 0; /*0x14103cd94*/
                    goto LABEL_28; /*0x14103cd97*/
                  }
                }
                v23 = v22 < *((_BYTE *)v20 + v21 - 1) ? -1 : 1;
LABEL_28:
                if ( v23 == 0 ) /*0x14103cda0*/
                  break; /*0x14103cda0*/
              }
              if ( v17 == v19 ) /*0x14103cda5*/
                goto LABEL_32; /*0x14103cda5*/
              v17 = v17->_Prev; /*0x14103cda7*/
            }
            if ( v17 == nullptr ) /*0x14103cdb0*/
LABEL_32:
              v17 = Ptr->_List._Mypair._Myval2._Myhead; /*0x14103cdb2*/
            __eh34_enter_wind_state(1, 2); /*0xf1c000000000001c*/
            if ( v9 != v18 && v17 != v18 ) /*0x14103cdbd*/
            {
              v24 = RBX::Reflection::Variant::get<int>(this: &v17->_Myval.second); /*0x14103cdc8*/
              v25 = RBX::Reflection::Variant::get<std::string>(this: &v9->_Myval.second, &result); /*0x14103cdd2*/
              v26 = RBX::Network::Client::ServerConnection::ServerConnection(this: &v37, a: v25, p: v24); /*0x14103cde1*/
              __wind /*0xf1c0000000000010*/
              {
                std::vector<RBX::Network::Client::ServerConnection>::push_back(this: endpoints, _Val: v26); /*0x14103cdee*/
              }
              __unwind
              {
                RBX::Network::Client::ServerConnection::~ServerConnection(this: &v37); /*0xf1c0000000000008*/
              }
              RBX::Network::Client::ServerConnection::~ServerConnection(this: &v37); /*0x14103cdf8*/
            }
            if ( oneEndpoint._Rep != nullptr /*0x14103ce13*/
              && _InterlockedExchangeAdd((volatile signed __int32 *)&oneEndpoint._Rep->_Uses, 0xFFFFFFFF) == 1 )
            {
              Rep = oneEndpoint._Rep; /*0x14103ce15*/
              oneEndpoint._Rep->_Destroy(this: oneEndpoint._Rep); /*0x14103ce20*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14103ce2d*/
                oneEndpoint._Rep->_Delete_this(this: oneEndpoint._Rep); /*0x14103ce37*/
            }
            ++Myfirst; /*0x14103ce3a*/
          }
          while ( Myfirst != Mylast );
          v28 = key; /*0x14103ce48*/
        }
      }
      v29 = endpointsArray._Rep; /*0x14103ce51*/
      if ( endpointsArray._Rep != nullptr /*0x14103ce65*/
        && _InterlockedExchangeAdd((volatile signed __int32 *)&endpointsArray._Rep->_Uses, 0xFFFFFFFF) == 1 )
      {
        v29->_Destroy(this: v29); /*0x14103ce6d*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v29->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14103ce79*/
          v29->_Delete_this(this: v29); /*0x14103ce81*/
      }
      Myres = v28->text._Mypair._Myval2._Myres; /*0x14103ce85*/
      if ( Myres >= 0x10 ) /*0x14103ce8d*/
      {
        v31 = v28->text._Mypair._Myval2._Bx._Ptr; /*0x14103ce92*/
        if ( Myres + 1 >= 0x1000 ) /*0x14103ce9c*/
        {
          if ( (unsigned __int64)&v31[-*((_QWORD *)v31 - 1) - 8] > 0x1F ) /*0x14103ceb1*/
            _invalid_parameter_noinfo_noreturn(); /*0x14103cee1*/
          v31 = *((char **)v31 - 1); /*0x14103ceb3*/
        }
        operator delete(ptr: v31); /*0x14103ceb6*/
      }
      v28->text._Mypair._Myval2._Mysize = 0; /*0x14103cebb*/
      v28->text._Mypair._Myval2._Myres = 15; /*0x14103cebf*/
      v28->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103cec3*/
      if ( __eh34_unwind(2) ) /*0xf1c000000000006c*/
        goto unwind_state_2; /*0xf1c000000000006c*/
      __eh34_exit_wind_state(2, 1); /*0xf1c0000000000070*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&endpointsArray); /*0xf1c0000000000064*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: key); /*0xf1c0000000000048*/
  }
}

// Address: 0x14103deb0 | Name: ?getGameLocaleIdFromParams@PlayerConfigurer@RBX@@QEAA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@XZ
std::string *__fastcall RBX::PlayerConfigurer::getGameLocaleIdFromParams(
        RBX::PlayerConfigurer *this,
        std::string *result)
{
  std::string *v4; // rax
  char *Ptr; // rcx
  char *v6; // rcx
  std::string key; // [rsp+20h] [rbp-48h] BYREF
  std::string gameLocaleId; // [rsp+40h] [rbp-28h] BYREF

  if ( FFlag::NeverUseJoinBlobRobloxLocaleEvenAsDefault.value ) /*0x14103dece*/
  {
    RBX::GameConfigurer::getParamString(this, result, key: &FString::GameLocaleIdName); /*0x14103ded0*/
    return result; /*0x14103dee2*/
  }
  RBX::GameConfigurer::getParamString(this, result: &gameLocaleId, key: &FString::GameLocaleIdName); /*0x14103dee8*/
  __eh34_enter_wind_state(-1, 0); /*0xf1c000000000003c*/
  if ( gameLocaleId._Mypair._Myval2._Mysize != 0 ) /*0x14103def4*/
  {
    *result = gameLocaleId; /*0x14103dfe1*/
LABEL_16:
    v4 = result; /*0x14103dfed*/
    if ( __eh34_unwind(0) ) /*0xf1c0000000000004*/
    {
unwind_state_0:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&gameLocaleId); /*0xf1c0000000000008*/
      __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000000c*/
    }
    goto LABEL_19; /*0xf1c0000000000004*/
  }
  __wind /*0xf1c0000000000030*/
  {
    key._Mypair._Myval2._Myres = 15; /*0x14103defa*/
    key._Mypair._Myval2._Mysize = 12; /*0x14103df03*/
    strcpy(key._Mypair._Myval2._Bx._Buf, "RobloxLocale"); /*0x14103df14*/
    RBX::GameConfigurer::getParamString(this, result, &key); /*0x14103df34*/
    if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x14103df43*/
    {
      Ptr = key._Mypair._Myval2._Bx._Ptr; /*0x14103df48*/
      if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103df57*/
      {
        Ptr = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x14103df5d*/
        if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14103df6c*/
          _invalid_parameter_noinfo_noreturn(); /*0x14103df6e*/
      }
      operator delete(ptr: Ptr); /*0x14103df75*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key); /*0xf1c0000000000028*/
  }
  key._Mypair._Myval2._Mysize = 0; /*0x14103df7c*/
  key._Mypair._Myval2._Myres = 15; /*0x14103df81*/
  key._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103df8a*/
  if ( gameLocaleId._Mypair._Myval2._Myres < 0x10 ) /*0x14103df97*/
    goto LABEL_16; /*0x14103df97*/
  v6 = gameLocaleId._Mypair._Myval2._Bx._Ptr; /*0x14103df9c*/
  if ( gameLocaleId._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103dfab*/
  {
    v6 = *((char **)gameLocaleId._Mypair._Myval2._Bx._Ptr - 1); /*0x14103dfb1*/
    if ( (unsigned __int64)(gameLocaleId._Mypair._Myval2._Bx._Ptr - v6 - 8) > 0x1F ) /*0x14103dfc0*/
      _invalid_parameter_noinfo_noreturn(); /*0x14103dfc2*/
  }
  operator delete(ptr: v6); /*0x14103dfc9*/
  v4 = result; /*0x14103dfce*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000018*/
    goto unwind_state_0; /*0xf1c0000000000018*/
LABEL_19:
  __eh34_exit_wind_state(0, -1); /*0xf1c000000000001c*/
  return v4; /*0x14103ded8*/
}

// Address: 0x14103e050 | Name: ?ifSeleniumThenSetCookie@PlayerConfigurer@RBX@@AEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@0@Z
void __fastcall RBX::PlayerConfigurer::ifSeleniumThenSetCookie(
        RBX::PlayerConfigurer *this,
        const rtc::webrtc_checks_impl::ToStringVal *key,
        const rtc::webrtc_checks_impl::ToStringVal *value)
{
  char *v6; // rax
  bool ParamBool; // di
  char *Ptr; // rcx
  RBX::CookiesService *v9; // rdi
  rtc::webrtc_checks_impl::ToStringVal *v10; // rax
  std::string *p_val; // rbx
  rtc::webrtc_checks_impl::ToStringVal *v12; // rax
  std::string v13; // [rsp+28h] [rbp-50h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v14; // [rsp+48h] [rbp-30h] BYREF

  v13._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103e06f*/
  v13._Mypair._Myval2._Mysize = 0; /*0x14103e074*/
  v13._Mypair._Myval2._Myres = 15; /*0x14103e079*/
  v6 = (char *)operator new(size: 0x20u); /*0x14103e089*/
  __wind /*0xf1c0000000000028*/
  {
    v13._Mypair._Myval2._Mysize = 16; /*0x14103e08e*/
    v13._Mypair._Myval2._Myres = 31; /*0x14103e097*/
    strcpy(v6, "SeleniumTestMode"); /*0x14103e0a7*/
    v13._Mypair._Myval2._Bx._Ptr = v6; /*0x14103e0ae*/
    ParamBool = RBX::GameConfigurer::getParamBool(this, key: &v13); /*0x14103e0c0*/
    if ( v13._Mypair._Myval2._Myres >= 0x10 ) /*0x14103e0cc*/
    {
      Ptr = v13._Mypair._Myval2._Bx._Ptr; /*0x14103e0d1*/
      if ( v13._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103e0e0*/
      {
        Ptr = *((char **)v13._Mypair._Myval2._Bx._Ptr - 1); /*0x14103e0e6*/
        if ( (unsigned __int64)(v13._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14103e0f5*/
          _invalid_parameter_noinfo_noreturn(); /*0x14103e0f7*/
      }
      operator delete(ptr: Ptr); /*0x14103e0fe*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v13); /*0xf1c0000000000020*/
  }
  if ( ParamBool ) /*0x14103e106*/
  {
    v9 = RBX::ServiceProvider::create<RBX::CookiesService>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x14103e115*/
    if ( v9 != nullptr ) /*0x14103e11b*/
    {
      v10 = std::string::string(this: (rtc::webrtc_checks_impl::ToStringVal *)&v13, __that: value); /*0x14103e132*/
      p_val = &v10->val; /*0x14103e137*/
      __wind /*0xf1c0000000000010*/
      {
        v12 = std::string::string(this: &v14, __that: key); /*0x14103e142*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v13); /*0xf1c0000000000008*/
      }
      RBX::CookiesService::SetValue(this: v9, key: &v12->val, value: p_val); /*0x14103e151*/
    }
  }
}

// Address: 0x14103e8b0 | Name: ?logAvatarMetrics@PlayerConfigurer@RBX@@AEAAXAEAUAvatarMetrics@2@@Z
void __fastcall RBX::PlayerConfigurer::logAvatarMetrics(RBX::PlayerConfigurer *this, RBX::AvatarMetrics *metrics)
{
  unsigned __int64 v4; // r8
  const void *humanoidAddr; // r9
  unsigned __int8 v6; // cl
  const char *v7; // rdx
  __int64 userId; // r8
  std::string *p_modelName; // r8
  std::string *p_displayName; // r8
  std::string *Ptr; // r8
  std::string *Mylast; // rsi
  std::string *i; // rdi
  const char *v14; // r8
  RBX::DataModel *dataModel; // rax
  RBX::ServiceProvider *v16; // rdx
  RBX::Instance *v17; // rax

  if ( FLog::AvatarJoinMetrics == 0 ) /*0x14103e8cb*/
    return; /*0x14103e8cb*/
  v4 = logCounter; /*0x14103e8d1*/
  humanoidAddr = (const void *)metrics->humanoidAddr; /*0x14103e8db*/
  ++logCounter; /*0x14103e8f3*/
  FLog::FastLogFormatted( /*0x14103e8fa*/
    level: FLog::AvatarJoinMetrics,
    message: "[FLog::AvatarJoinMetrics] >>> Avatar Metrics #%lld, %p",
    v4,
    humanoidAddr);
  v6 = FLog::AvatarJoinMetrics; /*0x14103e904*/
  if ( metrics->userId != 0 ) /*0x14103e90b*/
  {
    if ( metrics->localPlayer ) /*0x14103e90d*/
    {
      if ( FLog::AvatarJoinMetrics == 0 ) /*0x14103e915*/
        goto LABEL_11; /*0x14103e915*/
      v7 = "[FLog::AvatarJoinMetrics] > LocalPlayer"; /*0x14103e917*/
    }
    else
    {
      if ( FLog::AvatarJoinMetrics == 0 ) /*0x14103e922*/
        goto LABEL_11; /*0x14103e922*/
      v7 = "[FLog::AvatarJoinMetrics] > OtherPlayer"; /*0x14103e924*/
    }
  }
  else
  {
    if ( FLog::AvatarJoinMetrics == 0 ) /*0x14103e92f*/
      goto LABEL_11; /*0x14103e92f*/
    v7 = "[FLog::AvatarJoinMetrics] > NonPlayer"; /*0x14103e931*/
  }
  FLog::FastLog(level: FLog::AvatarJoinMetrics, message: v7, arg0: nullptr); /*0x14103e93b*/
  v6 = FLog::AvatarJoinMetrics; /*0x14103e940*/
LABEL_11:
  userId = metrics->userId; /*0x14103e947*/
  if ( userId != 0 ) /*0x14103e94e*/
  {
    if ( v6 == 0 ) /*0x14103e956*/
      goto LABEL_43; /*0x14103e956*/
    FLog::FastLogFormatted(level: v6, message: "[FLog::AvatarJoinMetrics]   userId = %lld", userId); /*0x14103e966*/
    v6 = FLog::AvatarJoinMetrics; /*0x14103e96b*/
    if ( FLog::AvatarJoinMetrics == 0 ) /*0x14103e974*/
      goto LABEL_43; /*0x14103e974*/
    FLog::FastLogFormatted( /*0x14103e985*/
      level: FLog::AvatarJoinMetrics,
      message: "[FLog::AvatarJoinMetrics]   appearanceId = %lld",
      metrics->appearanceId);
    v6 = FLog::AvatarJoinMetrics; /*0x14103e98a*/
    if ( FLog::AvatarJoinMetrics == 0 ) /*0x14103e993*/
      goto LABEL_43; /*0x14103e993*/
    FLog::FastLogFormatted( /*0x14103e9ad*/
      level: FLog::AvatarJoinMetrics,
      message: "[FLog::AvatarJoinMetrics]   createTime = %g",
      metrics->createTime);
    v6 = FLog::AvatarJoinMetrics; /*0x14103e9b2*/
    if ( FLog::AvatarJoinMetrics == 0 ) /*0x14103e9bb*/
      goto LABEL_43; /*0x14103e9bb*/
    p_modelName = &metrics->modelName; /*0x14103e9c6*/
    if ( metrics->modelName._Mypair._Myval2._Myres >= 0x10 ) /*0x14103e9ca*/
      p_modelName = (std::string *)p_modelName->_Mypair._Myval2._Bx._Ptr; /*0x14103e9cc*/
    FLog::FastLogFormatted( /*0x14103e9d6*/
      level: FLog::AvatarJoinMetrics,
      message: "[FLog::AvatarJoinMetrics]   modelName = %s",
      p_modelName->_Mypair._Myval2._Bx._Buf);
    v6 = FLog::AvatarJoinMetrics; /*0x14103e9db*/
    if ( FLog::AvatarJoinMetrics == 0 ) /*0x14103e9e4*/
      goto LABEL_43; /*0x14103e9e4*/
    p_displayName = &metrics->displayName; /*0x14103e9ef*/
    if ( metrics->displayName._Mypair._Myval2._Myres >= 0x10 ) /*0x14103e9f3*/
      p_displayName = (std::string *)p_displayName->_Mypair._Myval2._Bx._Ptr; /*0x14103e9f5*/
    FLog::FastLogFormatted( /*0x14103e9ff*/
      level: FLog::AvatarJoinMetrics,
      message: "[FLog::AvatarJoinMetrics]   displayName = %s",
      p_displayName);
    goto LABEL_26; /*0x14103e9ff*/
  }
  if ( v6 != 0 ) /*0x14103ea03*/
  {
    Ptr = &metrics->modelName; /*0x14103ea0e*/
    if ( metrics->modelName._Mypair._Myval2._Myres >= 0x10 ) /*0x14103ea12*/
      Ptr = (std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x14103ea14*/
    FLog::FastLogFormatted(level: v6, message: "[FLog::AvatarJoinMetrics]   modelName = %s", Ptr); /*0x14103ea21*/
LABEL_26:
    v6 = FLog::AvatarJoinMetrics; /*0x14103ea26*/
    if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ea2f*/
    {
      FLog::FastLog(level: FLog::AvatarJoinMetrics, message: "[FLog::AvatarJoinMetrics] > FC/TC", arg0: nullptr); /*0x14103ea3f*/
      v6 = FLog::AvatarJoinMetrics; /*0x14103ea44*/
      if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ea4d*/
      {
        FLog::FastLogFormatted( /*0x14103ea67*/
          level: FLog::AvatarJoinMetrics,
          message: "[FLog::AvatarJoinMetrics]   clusterStartTime = %g",
          metrics->clusterStartTime);
        v6 = FLog::AvatarJoinMetrics; /*0x14103ea6c*/
        if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ea75*/
        {
          FLog::FastLogFormatted( /*0x14103ea8f*/
            level: FLog::AvatarJoinMetrics,
            message: "[FLog::AvatarJoinMetrics]   clusterEndTime = %g",
            metrics->clusterEndTime);
          v6 = FLog::AvatarJoinMetrics; /*0x14103ea94*/
          if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ea9d*/
          {
            FLog::FastLogFormatted( /*0x14103eab1*/
              level: FLog::AvatarJoinMetrics,
              message: "[FLog::AvatarJoinMetrics]   clusterUpdateCnt = %lld",
              metrics->clusterUpdateCnt);
            v6 = FLog::AvatarJoinMetrics; /*0x14103eab6*/
            if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103eabf*/
            {
              FLog::FastLogFormatted( /*0x14103ead9*/
                level: FLog::AvatarJoinMetrics,
                message: "[FLog::AvatarJoinMetrics]   textureStartTime = %g",
                metrics->textureStartTime);
              v6 = FLog::AvatarJoinMetrics; /*0x14103eade*/
              if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103eae7*/
              {
                FLog::FastLogFormatted( /*0x14103eb01*/
                  level: FLog::AvatarJoinMetrics,
                  message: "[FLog::AvatarJoinMetrics]   textureEndTime = %g",
                  metrics->textureEndTime);
                v6 = FLog::AvatarJoinMetrics; /*0x14103eb06*/
                if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103eb0f*/
                {
                  FLog::FastLog( /*0x14103eb1f*/
                    level: FLog::AvatarJoinMetrics,
                    message: "[FLog::AvatarJoinMetrics] > Http",
                    arg0: nullptr);
                  v6 = FLog::AvatarJoinMetrics; /*0x14103eb24*/
                  if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103eb2d*/
                  {
                    FLog::FastLogFormatted( /*0x14103eb41*/
                      level: FLog::AvatarJoinMetrics,
                      message: "[FLog::AvatarJoinMetrics]   cacheHitCnt = %lld",
                      metrics->httpCacheHitCnt);
                    v6 = FLog::AvatarJoinMetrics; /*0x14103eb46*/
                    if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103eb4f*/
                    {
                      FLog::FastLogFormatted( /*0x14103eb63*/
                        level: FLog::AvatarJoinMetrics,
                        message: "[FLog::AvatarJoinMetrics]   cacheMissCnt = %lld",
                        metrics->httpCacheMissCnt);
                      v6 = FLog::AvatarJoinMetrics; /*0x14103eb68*/
                      if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103eb71*/
                      {
                        FLog::FastLogFormatted( /*0x14103eb85*/
                          level: FLog::AvatarJoinMetrics,
                          message: "[FLog::AvatarJoinMetrics]   cacheHitBytes = %lld",
                          metrics->httpCacheHitBytes);
                        v6 = FLog::AvatarJoinMetrics; /*0x14103eb8a*/
                        if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103eb93*/
                        {
                          FLog::FastLogFormatted( /*0x14103eba7*/
                            level: FLog::AvatarJoinMetrics,
                            message: "[FLog::AvatarJoinMetrics]   cacheMissBytes = %lld",
                            metrics->httpCacheMissBytes);
                          v6 = FLog::AvatarJoinMetrics; /*0x14103ebac*/
                          if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ebb5*/
                          {
                            FLog::FastLog( /*0x14103ebc5*/
                              level: FLog::AvatarJoinMetrics,
                              message: "[FLog::AvatarJoinMetrics] > Categories",
                              arg0: nullptr);
                            v6 = FLog::AvatarJoinMetrics; /*0x14103ebca*/
                            if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ebd3*/
                            {
                              FLog::FastLogFormatted( /*0x14103ebe3*/
                                level: FLog::AvatarJoinMetrics,
                                message: "[FLog::AvatarJoinMetrics]   assetsByteSize = %lld",
                                metrics->assetsByteSize);
                              v6 = FLog::AvatarJoinMetrics; /*0x14103ebe8*/
                              if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ebf1*/
                              {
                                FLog::FastLogFormatted( /*0x14103ec01*/
                                  level: FLog::AvatarJoinMetrics,
                                  message: "[FLog::AvatarJoinMetrics]   texturesByteSize = %lld",
                                  metrics->texturesByteSize);
                                v6 = FLog::AvatarJoinMetrics; /*0x14103ec06*/
                                if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ec0f*/
                                {
                                  FLog::FastLogFormatted( /*0x14103ec1f*/
                                    level: FLog::AvatarJoinMetrics,
                                    message: "[FLog::AvatarJoinMetrics]   animationsByteSize = %lld",
                                    metrics->animationsByteSize);
                                  v6 = FLog::AvatarJoinMetrics; /*0x14103ec24*/
                                  if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ec2d*/
                                  {
                                    FLog::FastLog( /*0x14103ec39*/
                                      level: FLog::AvatarJoinMetrics,
                                      message: "[FLog::AvatarJoinMetrics] > Assets",
                                      arg0: nullptr);
                                    v6 = FLog::AvatarJoinMetrics; /*0x14103ec3e*/
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
LABEL_43:
  Mylast = metrics->assetDescriptions._Mypair._Myval2._Mylast; /*0x14103ec45*/
  for ( i = metrics->assetDescriptions._Mypair._Myval2._Myfirst; i != Mylast; ++i ) /*0x14103ec56*/
  {
    if ( v6 != 0 ) /*0x14103ec5a*/
    {
      v14 = (const char *)i; /*0x14103ec61*/
      if ( i->_Mypair._Myval2._Myres >= 0x10 ) /*0x14103ec64*/
        v14 = i->_Mypair._Myval2._Bx._Ptr; /*0x14103ec66*/
      FLog::FastLogFormatted(level: v6, message: "[FLog::AvatarJoinMetrics]   %s", v14); /*0x14103ec73*/
      v6 = FLog::AvatarJoinMetrics; /*0x14103ec78*/
    }
  }
  if ( v6 != 0 ) /*0x14103ec94*/
  {
    FLog::FastLog(level: v6, message: "[FLog::AvatarJoinMetrics] > Misc", arg0: nullptr); /*0x14103eca0*/
    v6 = FLog::AvatarJoinMetrics; /*0x14103eca5*/
    if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ecae*/
    {
      FLog::FastLogFormatted( /*0x14103ecc1*/
        level: FLog::AvatarJoinMetrics,
        message: "[FLog::AvatarJoinMetrics]   baseTime = %g",
        this->sgs.userClickTime);
      v6 = FLog::AvatarJoinMetrics; /*0x14103ecc6*/
    }
  }
  if ( !DFFlag::PlayerConfigurer2886.value ) /*0x14103ecd4*/
  {
    dataModel = this->dataModel; /*0x14103ee32*/
    v16 = &dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>; /*0x14103ee3c*/
    if ( dataModel == nullptr ) /*0x14103ee40*/
      v16 = nullptr; /*0x14103ee40*/
    if ( v16 != nullptr ) /*0x14103ee47*/
    {
      v17 = RBX::ServiceProvider::refByClass<RBX::Players>(this: v16)->_Ptr; /*0x14103ee51*/
      if ( v17 != nullptr ) /*0x14103ee57*/
      {
        if ( FLog::AvatarJoinMetrics == 0 ) /*0x14103ee64*/
          return; /*0x14103ee64*/
        FLog::FastLogFormatted( /*0x14103ee85*/
          level: FLog::AvatarJoinMetrics,
          message: "[FLog::AvatarJoinMetrics]   #players = %lld",
          (int)(((__int64)v17[1].propertyChangedSignal.head.px->call
               - *(_QWORD *)&v17[1].propertyChangedSignal.head.px->rbx::intrusive_ptr_target<rbx::signals::slot_base>) >> 4));
      }
LABEL_65:
      v6 = FLog::AvatarJoinMetrics; /*0x14103ee8a*/
    }
    if ( v6 != 0 ) /*0x14103ee93*/
      FLog::FastLogFormatted(level: v6, message: "[FLog::AvatarJoinMetrics] <<<"); /*0x14103ee9f*/
    return; /*0x14103ee9f*/
  }
  if ( v6 != 0 ) /*0x14103ecdc*/
  {
    FLog::FastLogFormatted(level: v6, message: "[FLog::AvatarJoinMetrics]   #players = %lld", metrics->numPlayers); /*0x14103ecf3*/
    if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ed01*/
    {
      FLog::FastLogFormatted( /*0x14103ed41*/
        level: FLog::AvatarJoinMetrics,
        message: "[FLog::AvatarJoinMetrics]   spawnPosition = %g %g %g",
        metrics->spawnPosition.x,
        metrics->spawnPosition.y,
        metrics->spawnPosition.z);
      if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ed4f*/
      {
        FLog::FastLogFormatted( /*0x14103ed8f*/
          level: FLog::AvatarJoinMetrics,
          message: "[FLog::AvatarJoinMetrics]   spawnDirection = %g %g %g",
          metrics->spawnDirection.x,
          metrics->spawnDirection.y,
          metrics->spawnDirection.z);
        if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ed9d*/
        {
          FLog::FastLogFormatted( /*0x14103eddd*/
            level: FLog::AvatarJoinMetrics,
            message: "[FLog::AvatarJoinMetrics]   cameraPosition = %g %g %g",
            metrics->cameraPosition.x,
            metrics->cameraPosition.y,
            metrics->cameraPosition.z);
          if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103edeb*/
          {
            FLog::FastLogFormatted( /*0x14103ee2b*/
              level: FLog::AvatarJoinMetrics,
              message: "[FLog::AvatarJoinMetrics]   cameraDirection = %g %g %g",
              metrics->cameraDirection.x,
              metrics->cameraDirection.y,
              metrics->cameraDirection.z);
            goto LABEL_65; /*0x14103ee30*/
          }
        }
      }
    }
  }
}

// Address: 0x14103ef10 | Name: ?onAvatarClusterEnded@PlayerConfigurer@RBX@@AEAAXPEAVHumanoid@2@N@Z
void __fastcall RBX::PlayerConfigurer::onAvatarClusterEnded(
        RBX::PlayerConfigurer *this,
        RBX::Humanoid *humanoid,
        long double time)
{
  RBX::ModelInstance *LocalCharacter; // rax
  bool v7; // r12
  __int64 v8; // rbx
  unsigned __int64 v9; // r14
  unsigned __int64 v10; // r15
  __int64 UserId; // rbx
  RBX::Graphics::ProfilerAdorn::Item *Ptr; // r8
  char *v13; // rcx
  __int64 v14; // rcx
  __int64 v15; // [rsp+0h] [rbp-B8h] BYREF
  RBX::Profiler::Scope profscope1975; // [rsp+40h] [rbp-78h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v17; // [rsp+50h] [rbp-68h] BYREF
  bool v18; // [rsp+C8h] [rbp+10h]

  if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103ef49*/
    FLog::FastLogFormatted( /*0x14103ef57*/
      level: FLog::AvatarJoinMetrics,
      message: "[FLog::AvatarJoinMetrics] FC ended on humanoid %p",
      humanoid);
  v18 = humanoid->textureCompositionTimes[1] > 0.0; /*0x14103ef6b*/
  LocalCharacter = RBX::Players::findLocalCharacter(context: humanoid); /*0x14103ef76*/
  v7 = humanoid->parent == LocalCharacter; /*0x14103ef7f*/
  if ( (humanoid->parent == LocalCharacter /*0x14103efb1*/
     || FFlag::PlayerConfigurer2759.value && FFlag::DebugPlayerConfigurerOthersMetrics.value)
    && humanoid->clusterCreationTimes[1] == 0.0 )
  {
    v8 = *((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index); /*0x14103efcb*/
    if ( _TSS0_524 > *(_DWORD *)(v8 + 260) ) /*0x14103efd8*/
    {
      __wind /*0xf1c0000000000024*/
      {
        Init_thread_header(pOnce: &_TSS0_524); /*0x14103f15f*/
        if ( _TSS0_524 == -1 ) /*0x14103f16b*/
        {
          proftoken1975 = RBX::Profiler::getToken(group: "Avatar", name: "onAvatarClusterEnded", color: -1); /*0x14103f18a*/
          Init_thread_footer(pOnce: &_TSS0_524); /*0x14103f198*/
        }
      }
      __unwind
      {
        Init_thread_abort(pOnce: &_TSS0_524); /*0x1431e7be7*/
      }
    }
    v9 = proftoken1975; /*0x14103efde*/
    profscope1975.region.token = proftoken1975; /*0x14103efe5*/
    v10 = RBX::Profiler::enterRegion(token: proftoken1975); /*0x14103eff2*/
    profscope1975.region.timestamp = v10; /*0x14103eff5*/
    __wind /*0xf1c0000000000078*/
    {
      if ( _TSS1_108 > *(_DWORD *)(v8 + 260) ) /*0x14103f003*/
      {
        __wind /*0xf1c000000000003c*/
        {
          Init_thread_header(pOnce: &_TSS1_108); /*0x14103f122*/
          if ( _TSS1_108 == -1 ) /*0x14103f12e*/
          {
            proflabeltoken_38 = RBX::Profiler::getLabelToken(group: "Avatar"); /*0x14103f140*/
            Init_thread_footer(pOnce: &_TSS1_108); /*0x14103f14e*/
          }
        }
        __unwind
        {
          Init_thread_abort(pOnce: &_TSS1_108); /*0x1431e7bf7*/
        }
      }
      UserId = RBX::Humanoid::getUserId(this: humanoid, forceUpdate: false); /*0x14103f031*/
      std::string::string( /*0x14103f044*/
        this: (rtc::webrtc_checks_impl::ToStringVal *)&v17,
        __that: (const rtc::webrtc_checks_impl::ToStringVal *)&humanoid->displayName);
      __wind /*0xf1c000000000006c*/
      {
        Ptr = &v17; /*0x14103f04a*/
        if ( v17.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f055*/
          Ptr = (RBX::Graphics::ProfilerAdorn::Item *)v17.text._Mypair._Myval2._Bx._Ptr; /*0x14103f055*/
        RBX::Profiler::addLabelFormat( /*0x14103f07c*/
          token: proflabeltoken_38,
          name: "Player:%s,local:%d,id:%lld,time:%.3f,key:%p",
          Ptr->text._Mypair._Myval2._Bx._Buf,
          v7,
          UserId,
          (double)time,
          (const void *)(0x85FDB20E1294309AuLL - 0x3AE910A3C8B9DB97LL * (_QWORD)humanoid));
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v17); /*0xf1c0000000000064*/
      }
      if ( v17.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f08b*/
      {
        v13 = v17.text._Mypair._Myval2._Bx._Ptr; /*0x14103f090*/
        if ( v17.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103f09f*/
        {
          v13 = *((char **)v17.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14103f0a5*/
          if ( (unsigned __int64)(v17.text._Mypair._Myval2._Bx._Ptr - v13 - 8) > 0x1F ) /*0x14103f0b4*/
            _invalid_parameter_noinfo_noreturn(); /*0x14103f0b6*/
        }
        operator delete(ptr: v13); /*0x14103f0bd*/
      }
    }
    __unwind
    {
      RBX::Profiler::Scope::~Scope(this: &profscope1975); /*0xf1c0000000000088*/
    }
    __wind /*0xf1c0000000000090*/
    {
      RBX::Profiler::leaveRegion(token: v9, enterTimestamp: v10); /*0x14103f0c9*/
    }
    __unwind
    {
      __std_terminate(a1: v14, a2: &v15); /*0x142f39fa8*/
    }
    humanoid->clusterCreationTimes[1] = time; /*0x14103f0cf*/
    if ( v18 ) /*0x14103f0df*/
      RBX::PlayerConfigurer::onAvatarCompletion(this, humanoid, isLocalPlayer: v7); /*0x14103f0eb*/
  }
}

// Address: 0x14103f1b0 | Name: ?onAvatarClusterStarted@PlayerConfigurer@RBX@@AEAAXPEAVHumanoid@2@N@Z
void __fastcall RBX::PlayerConfigurer::onAvatarClusterStarted(
        RBX::PlayerConfigurer *this,
        RBX::Humanoid *humanoid,
        long double time)
{
  RBX::ModelInstance *LocalCharacter; // rax
  bool v6; // di
  __int64 v7; // rbx
  unsigned __int64 v8; // r14
  unsigned __int64 v9; // r15
  __int64 UserId; // rbx
  RBX::Graphics::ProfilerAdorn::Item *Ptr; // r8
  char *v12; // rcx
  __int64 v13; // rcx
  __int64 v14; // [rsp+0h] [rbp-98h] BYREF
  RBX::Profiler::Scope profscope1952; // [rsp+40h] [rbp-58h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v16; // [rsp+50h] [rbp-48h] BYREF

  if ( FLog::AvatarJoinMetrics != 0 ) /*0x14103f1df*/
    FLog::FastLogFormatted( /*0x14103f1ed*/
      level: FLog::AvatarJoinMetrics,
      message: "[FLog::AvatarJoinMetrics] FC started on humanoid %p",
      humanoid);
  LocalCharacter = RBX::Players::findLocalCharacter(context: humanoid); /*0x14103f1f5*/
  v6 = humanoid->parent == LocalCharacter; /*0x14103f1fe*/
  if ( (humanoid->parent == LocalCharacter /*0x14103f233*/
     || FFlag::PlayerConfigurer2759.value && FFlag::DebugPlayerConfigurerOthersMetrics.value)
    && humanoid->clusterCreationTimes[0] == 0.0 )
  {
    v7 = *((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index); /*0x14103f24d*/
    if ( _TSS0_523 > *(_DWORD *)(v7 + 260) ) /*0x14103f25a*/
    {
      __wind /*0xf1c0000000000024*/
      {
        Init_thread_header(pOnce: &_TSS0_523); /*0x14103f3d8*/
        if ( _TSS0_523 == -1 ) /*0x14103f3e4*/
        {
          proftoken1952 = RBX::Profiler::getToken(group: "Avatar", name: "onAvatarClusterStarted", color: -1); /*0x14103f403*/
          Init_thread_footer(pOnce: &_TSS0_523); /*0x14103f411*/
        }
      }
      __unwind
      {
        Init_thread_abort(pOnce: &_TSS0_523); /*0x1431e7c07*/
      }
    }
    v8 = proftoken1952; /*0x14103f260*/
    profscope1952.region.token = proftoken1952; /*0x14103f267*/
    v9 = RBX::Profiler::enterRegion(token: proftoken1952); /*0x14103f274*/
    profscope1952.region.timestamp = v9; /*0x14103f277*/
    __wind /*0xf1c0000000000078*/
    {
      if ( _TSS1_107 > *(_DWORD *)(v7 + 260) ) /*0x14103f285*/
      {
        Init_thread_header(pOnce: &_TSS1_107); /*0x14103f39b*/
        if ( _TSS1_107 == -1 ) /*0x14103f3a7*/
        {
          __wind /*0xf1c000000000003c*/
          {
            proflabeltoken_37 = RBX::Profiler::getLabelToken(group: "Avatar"); /*0x14103f3b9*/
            Init_thread_footer(pOnce: &_TSS1_107); /*0x14103f3c7*/
          }
          __unwind
          {
            Init_thread_abort(pOnce: &_TSS1_107); /*0x1431e7c17*/
          }
        }
      }
      UserId = RBX::Humanoid::getUserId(this: humanoid, forceUpdate: false); /*0x14103f2b3*/
      std::string::string( /*0x14103f2c6*/
        this: (rtc::webrtc_checks_impl::ToStringVal *)&v16,
        __that: (const rtc::webrtc_checks_impl::ToStringVal *)&humanoid->displayName);
      __wind /*0xf1c000000000006c*/
      {
        Ptr = &v16; /*0x14103f2cc*/
        if ( v16.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f2d7*/
          Ptr = (RBX::Graphics::ProfilerAdorn::Item *)v16.text._Mypair._Myval2._Bx._Ptr; /*0x14103f2d7*/
        RBX::Profiler::addLabelFormat( /*0x14103f2fe*/
          token: proflabeltoken_37,
          name: "Player:%s,local:%d,id:%lld,time:%.3f,key:%p",
          Ptr->text._Mypair._Myval2._Bx._Buf,
          v6,
          UserId,
          (double)time,
          (const void *)(0x85FDB20E1294309AuLL - 0x3AE910A3C8B9DB97LL * (_QWORD)humanoid));
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v16); /*0xf1c0000000000064*/
      }
      if ( v16.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f30d*/
      {
        v12 = v16.text._Mypair._Myval2._Bx._Ptr; /*0x14103f312*/
        if ( v16.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103f321*/
        {
          v12 = *((char **)v16.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14103f327*/
          if ( (unsigned __int64)(v16.text._Mypair._Myval2._Bx._Ptr - v12 - 8) > 0x1F ) /*0x14103f336*/
            _invalid_parameter_noinfo_noreturn(); /*0x14103f338*/
        }
        operator delete(ptr: v12); /*0x14103f33f*/
      }
    }
    __unwind
    {
      RBX::Profiler::Scope::~Scope(this: &profscope1952); /*0xf1c0000000000088*/
    }
    __wind /*0xf1c0000000000090*/
    {
      RBX::Profiler::leaveRegion(token: v8, enterTimestamp: v9); /*0x14103f34b*/
    }
    __unwind
    {
      __std_terminate(a1: v13, a2: &v14); /*0x142f39fa8*/
    }
    humanoid->clusterCreationTimes[0] = time; /*0x14103f351*/
    RBX::Humanoid::enableAssetTracking(this: humanoid); /*0x14103f35c*/
    if ( DFFlag::PlayerConfigurer2886.value ) /*0x14103f368*/
      RBX::Humanoid::initSpawn(this: humanoid); /*0x14103f36d*/
  }
}

// Address: 0x14103f420 | Name: ?onAvatarCompletion@PlayerConfigurer@RBX@@AEAAXPEAVHumanoid@2@_N@Z
void __fastcall RBX::PlayerConfigurer::onAvatarCompletion(
        RBX::PlayerConfigurer *this,
        RBX::ServiceProvider *humanoid,
        bool isLocalPlayer)
{
  long double *p_avatarLoadTime; // rdi
  char *v7; // rax
  char *Ptr; // rcx
  char *v9; // rcx
  std::string *p_joinRequestType; // rcx
  std::string *v11; // r15
  std::string *v12; // rdx
  __int64 v13; // rcx
  unsigned __int8 v14; // al
  int v15; // eax
  std::string *v16; // rax
  bool v17; // cf
  int v18; // eax
  bool v19; // r14
  std::string *p_networkType; // rax
  bool v21; // cf
  int v22; // eax
  bool isCase1; // bl
  long double videoAdFinishedTime; // xmm6_8
  std::string *v25; // r9
  std::string *v26; // rax
  std::pair<std::string,double> *Mylast; // rdx
  char *v28; // rcx
  __int64 v29; // rcx
  unsigned __int8 v30; // al
  int v31; // eax
  int v32; // ebx
  int PairIntValue; // r14d
  char *v34; // rcx
  bool isRobloxChineseDomain; // r15
  const std::string *BaseURL; // rax
  unsigned __int64 Mysize; // rcx
  const RBX::Url *v38; // rax
  std::string *v39; // r8
  std::string *v40; // rax
  long double *p_startGameTime; // r14
  std::pair<std::string,double> *v42; // rdx
  double v43; // xmm6_8
  std::string *v44; // r8
  std::string *v45; // rax
  std::pair<std::string,double> *v46; // rdx
  double v47; // xmm6_8
  std::string *v48; // r8
  std::string *v49; // rax
  std::pair<std::string,double> *v50; // rdx
  double v51; // xmm6_8
  std::string *v52; // r8
  std::string *v53; // rax
  std::pair<std::string,double> *v54; // rdx
  double v55; // xmm6_8
  std::string *v56; // r8
  std::string *v57; // rax
  std::pair<std::string,double> *v58; // rdx
  double v59; // xmm6_8
  std::string *v60; // r8
  std::string *v61; // rax
  std::pair<std::string,double> *v62; // rdx
  double v63; // xmm6_8
  std::string *v64; // r8
  std::string *v65; // rax
  std::pair<std::string,double> *v66; // rdx
  double v67; // xmm6_8
  std::string *v68; // r8
  std::string *v69; // rax
  std::pair<std::string,double> *v70; // rdx
  const char *v71; // rax
  std::string *v72; // rax
  const char *v73; // rax
  std::string *v74; // rax
  const char *v75; // rbx
  const char *v76; // rax
  std::string *v77; // rax
  const char *v78; // rbx
  const char *v79; // rax
  std::string *v80; // rax
  const char *v81; // rbx
  const char *v82; // rax
  std::string *v83; // rax
  const char *v84; // rbx
  const char *v85; // rax
  std::string *v86; // rax
  const char *v87; // rbx
  const char *v88; // rax
  std::string *v89; // rax
  const char *v90; // rbx
  const char *v91; // rax
  std::string *v92; // rax
  const char *v93; // rbx
  const char *v94; // rax
  std::string *v95; // rax
  const char *v96; // rbx
  const char *v97; // rax
  std::string *v98; // rax
  const char *v99; // rbx
  const char *v100; // rax
  std::string *v101; // rax
  const char *v102; // rax
  std::string *v103; // rax
  const char *v104; // rax
  std::string *v105; // rax
  const char *v106; // rax
  std::string *v107; // rax
  const char *v108; // rax
  std::string *v109; // rax
  const char *v110; // rax
  std::string *v111; // rax
  const char *v112; // rax
  std::string *v113; // rax
  const char *v114; // rax
  std::string *v115; // rax
  const char *v116; // rax
  std::string *v117; // rax
  const char *v118; // rax
  std::string *v119; // rax
  int v120; // r14d
  const std::string *v121; // rax
  int v122; // ebx
  bool v123; // bl
  const std::string *v124; // rax
  const RBX::Url *v125; // rax
  float v126; // xmm0_4
  std::string *v127; // rax
  float v128; // xmm0_4
  float v129; // xmm1_4
  float v130; // xmm0_4
  float v131; // xmm1_4
  float v132; // xmm0_4
  std::string *v133; // rax
  float v134; // xmm0_4
  float v135; // xmm0_4
  std::string *v136; // rax
  float v137; // xmm1_4
  float v138; // xmm0_4
  float v139; // xmm1_4
  float v140; // xmm0_4
  std::string *v141; // rax
  bool value; // bl
  long double v143; // xmm6_8
  std::string *v144; // rax
  long double startGameTime; // xmm6_8
  std::string *v146; // rax
  long double placelauncherStartTime; // xmm6_8
  std::string *v148; // rax
  long double fetchedJoinScriptTime; // xmm6_8
  std::string *v150; // rax
  long double playerConfigureTime; // xmm6_8
  std::string *v152; // rax
  long double connectTime; // xmm6_8
  std::string *v154; // rax
  long double receivedGlobalsTime; // xmm6_8
  std::string *v156; // rax
  long double gameLoadTime; // xmm6_8
  std::string *v158; // rax
  long double v159; // xmm6_8
  std::string *v160; // rax
  long double v161; // xmm6_8
  std::string *v162; // rax
  long double v163; // xmm6_8
  std::string *v164; // rax
  long double v165; // xmm6_8
  std::string *v166; // rax
  long double v167; // xmm6_8
  std::string *v168; // rax
  long double v169; // xmm6_8
  std::string *v170; // rax
  long double v171; // xmm6_8
  std::string *v172; // rax
  long double v173; // xmm6_8
  std::string *v174; // rax
  long double v175; // xmm6_8
  std::string *v176; // rax
  long double v177; // xmm6_8
  std::string *v178; // rax
  long double v179; // xmm6_8
  std::string *v180; // rax
  __int64 NumOfDownloadedBytes; // rax
  double v182; // xmm6_8
  std::string *v183; // rax
  const std::string *v184; // rax
  __int64 NumOfNonCachedDownloadedBytes; // rax
  double v186; // xmm6_8
  std::string *v187; // rax
  const std::string *v188; // rax
  int v189; // r14d
  const std::string *v190; // rax
  int v191; // ebx
  float v192; // xmm2_4
  float v193; // xmm2_4
  float v194; // xmm2_4
  float v195; // xmm2_4
  float v196; // xmm2_4
  float v197; // xmm2_4
  float v198; // xmm2_4
  float v199; // xmm2_4
  float v200; // xmm2_4
  float v201; // xmm2_4
  float v202; // xmm2_4
  float v203; // xmm0_4
  float v204; // xmm2_4
  float v205; // xmm2_4
  float v206; // xmm2_4
  float v207; // xmm2_4
  float v208; // xmm2_4
  float v209; // xmm2_4
  float v210; // xmm2_4
  float v211; // xmm2_4
  float v212; // xmm2_4
  std::vector<std::pair<std::string,double>> stats; // [rsp+30h] [rbp-D0h] BYREF
  std::vector<std::pair<std::string,double>> v214; // [rsp+48h] [rbp-B8h] BYREF
  RBX::StringView v215; // [rsp+60h] [rbp-A0h] BYREF
  std::string platform; // [rsp+70h] [rbp-90h] BYREF
  std::string resource; // [rsp+90h] [rbp-70h] BYREF
  RBX::Graphics::ProfilerAdorn::Item delimiters; // [rsp+B0h] [rbp-50h] BYREF
  __int64 v219; // [rsp+E8h] [rbp-18h]
  std::string result; // [rsp+F0h] [rbp-10h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+110h] [rbp+10h] BYREF
  std::string v222; // [rsp+180h] [rbp+80h] BYREF
  std::string v223; // [rsp+1A0h] [rbp+A0h] BYREF
  std::string v224; // [rsp+1C0h] [rbp+C0h] BYREF
  std::string v225; // [rsp+1E0h] [rbp+E0h] BYREF
  std::string v226; // [rsp+200h] [rbp+100h] BYREF
  std::string v227; // [rsp+220h] [rbp+120h] BYREF
  std::string v228; // [rsp+240h] [rbp+140h] BYREF
  std::string v229; // [rsp+260h] [rbp+160h] BYREF
  std::string v230; // [rsp+280h] [rbp+180h] BYREF
  std::string v231; // [rsp+2A0h] [rbp+1A0h] BYREF
  std::string v232; // [rsp+2C0h] [rbp+1C0h] BYREF
  std::string v233; // [rsp+2E0h] [rbp+1E0h] BYREF
  std::string v234; // [rsp+300h] [rbp+200h] BYREF
  std::string v235; // [rsp+320h] [rbp+220h] BYREF
  std::string v236; // [rsp+340h] [rbp+240h] BYREF
  std::string v237; // [rsp+360h] [rbp+260h] BYREF
  std::string v238; // [rsp+380h] [rbp+280h] BYREF
  std::string v239; // [rsp+3A0h] [rbp+2A0h] BYREF
  std::string v240; // [rsp+3C0h] [rbp+2C0h] BYREF
  std::string v241; // [rsp+3E0h] [rbp+2E0h] BYREF
  std::string v242; // [rsp+400h] [rbp+300h] BYREF
  std::string v243; // [rsp+420h] [rbp+320h] BYREF
  std::string v244; // [rsp+440h] [rbp+340h] BYREF
  std::string v245; // [rsp+460h] [rbp+360h] BYREF
  std::string v246; // [rsp+480h] [rbp+380h] BYREF
  std::string v247; // [rsp+4A0h] [rbp+3A0h] BYREF
  std::string v248; // [rsp+4C0h] [rbp+3C0h] BYREF
  std::string v249; // [rsp+4E0h] [rbp+3E0h] BYREF
  std::string v250; // [rsp+500h] [rbp+400h] BYREF
  std::string v251; // [rsp+520h] [rbp+420h] BYREF
  std::string v252; // [rsp+540h] [rbp+440h] BYREF
  std::string v253; // [rsp+560h] [rbp+460h] BYREF
  std::string v254; // [rsp+580h] [rbp+480h] BYREF
  std::string v255; // [rsp+5A0h] [rbp+4A0h] BYREF
  std::string v256; // [rsp+5C0h] [rbp+4C0h] BYREF
  std::string v257; // [rsp+5E0h] [rbp+4E0h] BYREF
  std::string v258; // [rsp+600h] [rbp+500h] BYREF
  std::string v259; // [rsp+620h] [rbp+520h] BYREF
  std::string v260; // [rsp+640h] [rbp+540h] BYREF
  std::string v261; // [rsp+660h] [rbp+560h] BYREF
  std::string v262; // [rsp+680h] [rbp+580h] BYREF
  std::string v263; // [rsp+6A0h] [rbp+5A0h] BYREF
  std::string v264; // [rsp+6C0h] [rbp+5C0h] BYREF
  std::string v265; // [rsp+6E0h] [rbp+5E0h] BYREF
  std::string v266; // [rsp+700h] [rbp+600h] BYREF
  std::string v267; // [rsp+720h] [rbp+620h] BYREF
  std::string v268; // [rsp+740h] [rbp+640h] BYREF
  std::string v269; // [rsp+760h] [rbp+660h] BYREF
  std::string v270; // [rsp+780h] [rbp+680h] BYREF
  std::string v271; // [rsp+7A0h] [rbp+6A0h] BYREF
  std::string v272; // [rsp+7C0h] [rbp+6C0h] BYREF
  std::string v273; // [rsp+7E0h] [rbp+6E0h] BYREF
  std::string v274; // [rsp+800h] [rbp+700h] BYREF
  std::string v275; // [rsp+820h] [rbp+720h] BYREF
  std::string v276; // [rsp+840h] [rbp+740h] BYREF
  std::string v277; // [rsp+860h] [rbp+760h] BYREF
  std::string v278; // [rsp+880h] [rbp+780h] BYREF
  RBX::StringView v279; // [rsp+8A0h] [rbp+7A0h] BYREF
  RBX::AvatarMetrics metrics; // [rsp+8B0h] [rbp+7B0h] BYREF
  RBX::PluginDragImpl v281; // [rsp+A00h] [rbp+900h] BYREF
  float gameJoinTime; // [rsp+BA0h] [rbp+AA0h] BYREF
  long double v283; // [rsp+BA8h] [rbp+AA8h] BYREF

  RBX::AvatarMetrics::AvatarMetrics(this: &metrics); /*0x14103f458*/
  __wind
  {
    RBX::PlayerConfigurer::buildAvatarMetrics(this, &metrics, humanoid, isLocalPlayer); /*0x14103f46f*/
    RBX::PlayerConfigurer::logAvatarMetrics(this, &metrics); /*0x14103f47e*/
    if ( !isLocalPlayer ) /*0x14103f486*/
      goto LABEL_252; /*0x14103f486*/
    if ( !FFlag::DebugPlayerConfigurerOthersMetrics.value ) /*0x14103f493*/
    {
      rbx::signals::connection::disconnect(this: &this->avatarClusterStartConnection.con); /*0x14103f49c*/
      rbx::signals::connection::disconnect(this: &this->avatarClusterEndConnection.con); /*0x14103f4a8*/
      rbx::signals::connection::disconnect(this: &this->avatarTextureStartConnection.con); /*0x14103f4b4*/
      rbx::signals::connection::disconnect(this: &this->avatarTextureEndConnection.con); /*0x14103f4c0*/
    }
    if ( FFlag::LogClientLoadToAvatarLoad.value && FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x14103f4d7*/
    {
      FLog::FastLog( /*0x14103f4e3*/
        level: FLog::LogStepTimeAndNetworkUsage,
        message: "[FLog::LogStepTimeAndNetworkUsage] Avatar Load",
        arg0: nullptr);
      if ( FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x14103f4f1*/
        FLog::FastLogFormatted( /*0x14103f4fc*/
          level: FLog::LogStepTimeAndNetworkUsage,
          message: "[FLog::LogStepTimeAndNetworkUsage] 0, 0, 0, 0");
    }
    p_avatarLoadTime = &this->sgs.avatarLoadTime; /*0x14103f501*/
    this->sgs.avatarLoadTime = RBX::Time::nowFastSec() - this->sgs.userClickTime; /*0x14103f512*/
    if ( RBX::globalRand() % 0x2710 < DFInt::ReportSyncWriteCachePhaseHundredthsPercentage ) /*0x14103f53c*/
    {
      RBX::Analytics::InfluxDb::Points::Points( /*0x14103f550*/
        this: &points,
        throttleHundredthsPercentage: -1,
        categoryType: kStandardType,
        priorityHundredthsPercentage: 0);
      __wind /*0xf1c000000000046c*/
      {
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14103f569*/
          this: &points,
          name: "AvatarLoadPhaseSyncCacheWriteTime",
          value: RBX::Http::syncCacheWriteTime._Storage._Value);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14103f58d*/
          this: &points,
          name: "AssetOnlyLoadTime",
          value: (*p_avatarLoadTime - this->sgs.gameJoinTime) * 1000.0);
        v7 = (char *)operator new(size: 0x20u); /*0x14103f5aa*/
        resource._Mypair._Myval2._Mysize = 25; /*0x14103f5af*/
        resource._Mypair._Myval2._Myres = 31; /*0x14103f5b7*/
        strcpy(v7, "HttpSynchronousWriteCache"); /*0x14103f5c6*/
        resource._Mypair._Myval2._Bx._Ptr = v7; /*0x14103f5e4*/
        __wind /*0xf1c0000000000460*/
        {
          RBX::Analytics::InfluxDb::Points::report( /*0x14103f5f9*/
            this: &points,
            &resource,
            throttleHundredthsPercentage: 10000,
            blocking: false);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000458*/
        }
        if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f607*/
        {
          Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x14103f60c*/
          if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103f61a*/
          {
            Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x14103f620*/
            if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14103f62f*/
              _invalid_parameter_noinfo_noreturn(); /*0x14103f631*/
          }
          operator delete(ptr: Ptr); /*0x14103f638*/
        }
        if ( points.userIdOverride._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f646*/
        {
          v9 = points.userIdOverride._Mypair._Myval2._Bx._Ptr; /*0x14103f64b*/
          if ( points.userIdOverride._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103f659*/
          {
            v9 = *((char **)points.userIdOverride._Mypair._Myval2._Bx._Ptr - 1); /*0x14103f65f*/
            if ( (unsigned __int64)(points.userIdOverride._Mypair._Myval2._Bx._Ptr - v9 - 8) > 0x1F ) /*0x14103f66e*/
              _invalid_parameter_noinfo_noreturn(); /*0x14103f670*/
          }
          operator delete(ptr: v9); /*0x14103f677*/
        }
        *(__m128i *)&points.userIdOverride._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14103f684*/
        points.userIdOverride._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103f689*/
        std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&points); /*0x14103f691*/
      }
      __unwind
      {
        RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c000000000044c*/
      }
    }
    if ( DFFlag::ReportFailuresInClientJoinAll2.value ) /*0x14103f69d*/
      this->sgs.joinPhase = JoinPhase_AvatarLoaded; /*0x14103f69f*/
    this->sgs.avatarClusterEndTime = metrics.clusterEndTime; /*0x14103f6b1*/
    this->sgs.avatarTextureEndTime = metrics.textureEndTime; /*0x14103f6c1*/
    *(_QWORD *)&delimiters.x = 0; /*0x14103f6c9*/
    v219 = 15; /*0x14103f6cd*/
    *(_QWORD *)&delimiters.color = 0; /*0x14103f6d5*/
    RBX::PlayerConfigurer::reportLocalAvatarMetrics( /*0x14103f6ea*/
      this,
      &metrics,
      joinFailureError: (std::string *)&delimiters.x,
      timeOfFailure: 0.0);
    __wind
    {
      if ( FFlag::JoinTimeCounters.value
        && FFlag::JoinTime_AvatarFastClusterSignal.value
        && FFlag::JoinTime_AvatarTextureCompositorSignal.value )
      {
        memset(&stats, 0, sizeof(stats)); /*0x14103f719*/
        p_joinRequestType = &this->sgs.joinRequestType; /*0x14103f724*/
        if ( this->sgs.joinRequestType._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f734*/
          p_joinRequestType = (std::string *)p_joinRequestType->_Mypair._Myval2._Bx._Ptr; /*0x14103f736*/
        if ( this->sgs.joinRequestType._Mypair._Myval2._Mysize != 11 /*0x14103f754*/
          || memcmp_0(Buf1: p_joinRequestType, Buf2: "RequestGame", Size: 0xBu) != 0 )
        {
          goto LABEL_90; /*0x14103f754*/
        }
        v11 = &RBX::Analytics::placeId; /*0x14103f75a*/
        v12 = &RBX::Analytics::placeId; /*0x14103f761*/
        if ( RBX::Analytics::placeId._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f76c*/
          v12 = (std::string *)RBX::Analytics::placeId._Mypair._Myval2._Bx._Ptr; /*0x14103f76c*/
        if ( RBX::Analytics::placeId._Mypair._Myval2._Mysize != 6 ) /*0x14103f783*/
          goto LABEL_41; /*0x14103f783*/
        v13 = 0; /*0x14103f785*/
        while ( 1 ) /*0x14103f790*/
        {
          v14 = v12->_Mypair._Myval2._Bx._Buf[v13++]; /*0x14103f790*/
          if ( v14 != a189707[v13 - 1] ) /*0x14103f79c*/
            break; /*0x14103f79c*/
          if ( v13 == 6 ) /*0x14103f7a2*/
          {
            v15 = 0; /*0x14103f7a4*/
            goto LABEL_40; /*0x14103f7a7*/
          }
        }
        v15 = v14 < (unsigned __int8)a189707[v13 - 1] ? -1 : 1;
LABEL_40:
        if ( v15 != 0 ) /*0x14103f7b0*/
        {
LABEL_41:
          if ( !FFlag::SendJoinTimesToDiag.value ) /*0x14103f7b9*/
            goto LABEL_90; /*0x14103f7b9*/
        }
        if ( this->sgs.videoAdShown ) /*0x14103f7bf*/
          goto LABEL_90; /*0x14103f7c6*/
        v16 = &RBX::Analytics::location; /*0x14103f7cc*/
        if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f7db*/
          v16 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x14103f7db*/
        if ( RBX::Analytics::location._Mypair._Myval2._Mysize != 2
          || ((v17 = v16->_Mypair._Myval2._Bx._Buf[0] < 0x55u, v16->_Mypair._Myval2._Bx._Buf[0] != 85)
           || (v17 = v16->_Mypair._Myval2._Bx._Buf[1] < 0x53u, v16->_Mypair._Myval2._Bx._Buf[1] != 83)
            ? (v18 = v17 ? -1 : 1)
            : (v18 = 0),
              v18 != 0) )
        {
          v19 = false; /*0x14103f854*/
        }
        else
        {
          v19 = true; /*0x14103f806*/
          if ( this->sgs.avatarR15 )
          {
            p_networkType = &this->sgs.networkType; /*0x14103f811*/
            if ( this->sgs.networkType._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f821*/
              p_networkType = (std::string *)p_networkType->_Mypair._Myval2._Bx._Ptr; /*0x14103f823*/
            if ( this->sgs.networkType._Mypair._Myval2._Mysize == 2 )
            {
              v21 = p_networkType->_Mypair._Myval2._Bx._Buf[0] < 0x34u; /*0x14103f82c*/
              if ( p_networkType->_Mypair._Myval2._Bx._Buf[0] == 52
                && (v21 = p_networkType->_Mypair._Myval2._Bx._Buf[1] < 0x47u,
                    p_networkType->_Mypair._Myval2._Bx._Buf[1] == 71) )
              {
                v22 = 0; /*0x14103f837*/
              }
              else
              {
                v22 = v21 ? -1 : 1;
              }
              if ( v22 == 0 && isIPhone5s_6s() ) /*0x14103f845*/
              {
                isCase1 = true; /*0x14103f84e*/
                goto LABEL_64; /*0x14103f852*/
              }
            }
          }
        }
        isCase1 = false; /*0x14103f857*/
LABEL_64:
        videoAdFinishedTime = this->sgs.videoAdFinishedTime; /*0x14103f859*/
        if ( FFlag::SendJoinTimesToDiag.value /*0x14103f89e*/
          && rand() % 10000 < DFInt::SendJoinTimesToDiag_HundredthsPercentage
          && isCase1 )
        {
          v25 = &RBX::Analytics::placeId; /*0x14103f8a4*/
          if ( RBX::Analytics::placeId._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f8af*/
            v25 = (std::string *)RBX::Analytics::placeId._Mypair._Myval2._Bx._Ptr; /*0x14103f8af*/
          v283 = videoAdFinishedTime; /*0x14103f8b7*/
          v26 = RBX::format(&result, fmt: "JoinTime_Case1_%s_%s", "VideoAdFinishedTime", v25->_Mypair._Myval2._Bx._Buf); /*0x14103f8d1*/
          __wind /*0xf1c0000000000430*/
          {
            Mylast = stats._Mypair._Myval2._Mylast; /*0x14103f8d7*/
            if ( stats._Mypair._Myval2._Mylast == stats._Mypair._Myval2._Myend ) /*0x14103f8e1*/
            {
              std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double &>( /*0x14103f927*/
                this: &stats,
                _Whereptr: stats._Mypair._Myval2._Mylast,
                <_Val_0>: v26,
                <_Val_1>: &v283);
            }
            else
            {
              *(_QWORD *)stats._Mypair._Myval2._Mylast = 0; /*0x14103f8e3*/
              Mylast->first._Mypair._Myval2._Mysize = 0; /*0x14103f8e6*/
              Mylast->first._Mypair._Myval2._Myres = 0; /*0x14103f8ea*/
              Mylast->first._Mypair._Myval2._Bx = v26->_Mypair._Myval2._Bx; /*0x14103f8f1*/
              *(_OWORD *)&Mylast->first._Mypair._Myval2._Mysize = *(_OWORD *)&v26->_Mypair._Myval2._Mysize; /*0x14103f8f8*/
              v26->_Mypair._Myval2._Mysize = 0; /*0x14103f8fc*/
              v26->_Mypair._Myval2._Myres = 15; /*0x14103f900*/
              v26->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103f908*/
              Mylast->second = videoAdFinishedTime; /*0x14103f90b*/
              ++stats._Mypair._Myval2._Mylast; /*0x14103f910*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000428*/
          }
          if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f935*/
          {
            v28 = result._Mypair._Myval2._Bx._Ptr; /*0x14103f93a*/
            if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103f948*/
            {
              v28 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14103f94e*/
              if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v28 - 8) > 0x1F ) /*0x14103f95d*/
                _invalid_parameter_noinfo_noreturn(); /*0x14103f95f*/
            }
            operator delete(ptr: v28); /*0x14103f966*/
          }
        }
        if ( RBX::Analytics::placeId._Mypair._Myval2._Myres >= 0x10 ) /*0x14103f973*/
          v11 = (std::string *)RBX::Analytics::placeId._Mypair._Myval2._Bx._Ptr; /*0x14103f973*/
        if ( RBX::Analytics::placeId._Mypair._Myval2._Mysize == 6 )
        {
          v29 = 0; /*0x14103f985*/
          while ( 1 ) /*0x14103f990*/
          {
            v30 = v11->_Mypair._Myval2._Bx._Buf[v29++]; /*0x14103f990*/
            if ( v30 != a189707[v29 - 1] ) /*0x14103f99c*/
              break; /*0x14103f99c*/
            if ( v29 == 6 ) /*0x14103f9a2*/
            {
              v31 = 0; /*0x14103f9a4*/
              goto LABEL_86; /*0x14103f9a7*/
            }
          }
          v31 = v30 < (unsigned __int8)a189707[v29 - 1] ? -1 : 1;
LABEL_86:
          if ( v31 == 0 && isCase1 ) /*0x14103f9b4*/
            reportJoinStats_0(&stats, fmt: "JoinTime_Case1_%s", name: "VideoAdFinishedTime", value: videoAdFinishedTime); /*0x14103f9cc*/
        }
        reportJoinStats_1( /*0x14103f9f2*/
          &stats,
          name: "StartGameTime",
          value: this->sgs.startGameTime,
          isUS: v19,
          isCase1,
          isCase1Case2Only: true);
        reportJoinStats_1( /*0x14103fa18*/
          &stats,
          name: "PlaceLauncherStartTime",
          value: this->sgs.placelauncherStartTime,
          isUS: v19,
          isCase1,
          isCase1Case2Only: true);
        reportJoinStats_1( /*0x14103fa3e*/
          &stats,
          name: "FetchedJoinScriptTime",
          value: this->sgs.fetchedJoinScriptTime,
          isUS: v19,
          isCase1,
          isCase1Case2Only: false);
        reportJoinStats_1( /*0x14103fa64*/
          &stats,
          name: "PlayerConfigureTime",
          value: this->sgs.playerConfigureTime,
          isUS: v19,
          isCase1,
          isCase1Case2Only: false);
        reportJoinStats_1( /*0x14103fa8a*/
          &stats,
          name: "ConnectTime",
          value: this->sgs.connectTime,
          isUS: v19,
          isCase1,
          isCase1Case2Only: false);
        reportJoinStats_1( /*0x14103fab0*/
          &stats,
          name: "ReceivedGlobalsTime",
          value: this->sgs.receivedGlobalsTime,
          isUS: v19,
          isCase1,
          isCase1Case2Only: false);
        reportJoinStats_1( /*0x14103fad6*/
          &stats,
          name: "GameLoadTime",
          value: this->sgs.gameLoadTime,
          isUS: v19,
          isCase1,
          isCase1Case2Only: false);
        reportJoinStats_1( /*0x14103fafc*/
          &stats,
          name: "GameJoinTime",
          value: this->sgs.gameJoinTime,
          isUS: v19,
          isCase1,
          isCase1Case2Only: false);
        reportJoinStats_1( /*0x14103fb1e*/
          &stats,
          name: "AvatarLoadTime",
          value: *p_avatarLoadTime,
          isUS: v19,
          isCase1,
          isCase1Case2Only: false);
LABEL_90:
        v32 = DFInt::SendJoinTimeDeltasToDiag_HundredthsPercentage; /*0x14103fb23*/
        delimiters.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14103fb29*/
        delimiters.text._Mypair._Myval2._Mysize = 0; /*0x14103fb2d*/
        delimiters.text._Mypair._Myval2._Myres = 15; /*0x14103fb31*/
        std::string::assign(this: &delimiters.text, _Ptr: ",", _Count: 1u); /*0x14103fb4e*/
        __wind /*0xf1c0000000000418*/
        {
          PairIntValue = RBX::Network::getPairIntValue( /*0x14103fb6b*/
                           target: &RBX::Analytics::location,
                           from: &DFString::SendJoinTimeDeltasHundPrecCountryOverride,
                           delimiters: &delimiters.text);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &delimiters); /*0xf1c0000000000410*/
        }
        if ( delimiters.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14103fb76*/
        {
          v34 = delimiters.text._Mypair._Myval2._Bx._Ptr; /*0x14103fb7b*/
          if ( delimiters.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14103fb89*/
          {
            v34 = *((char **)delimiters.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14103fb8f*/
            if ( (unsigned __int64)(delimiters.text._Mypair._Myval2._Bx._Ptr - v34 - 8) > 0x1F ) /*0x14103fb9e*/
              _invalid_parameter_noinfo_noreturn(); /*0x14103fba0*/
          }
          operator delete(ptr: v34); /*0x14103fba7*/
        }
        if ( PairIntValue != -1 ) /*0x14103fbb0*/
          v32 = PairIntValue; /*0x14103fbb0*/
        isRobloxChineseDomain = false; /*0x14103fbb4*/
        if ( DFFlag::SendLuobuSpecificJoinTimeStats.value ) /*0x14103fbbe*/
        {
          BaseURL = RBX::GetBaseURL(); /*0x14103fbc0*/
          Mysize = BaseURL->_Mypair._Myval2._Mysize; /*0x14103fbc5*/
          if ( BaseURL->_Mypair._Myval2._Myres >= 0x10 ) /*0x14103fbce*/
            BaseURL = (const std::string *)BaseURL->_Mypair._Myval2._Bx._Ptr; /*0x14103fbd0*/
          v215.Data = (const char *)BaseURL; /*0x14103fbd3*/
          v215.Length = Mysize; /*0x14103fbd8*/
          v38 = RBX::Url::fromString(result: (RBX::Url *)&v281, str: &v215); /*0x14103fbf4*/
          __wind /*0xf1c0000000000400*/
          {
            isRobloxChineseDomain = RBX::Http::isRobloxChineseDomain(url: v38); /*0x14103fc02*/
          }
          __unwind
          {
            RBX::Url::~Url(this: &v281); /*0xf1c00000000003f8*/
          }
          RBX::Url::~Url(this: &v281); /*0x14103fc0d*/
          if ( isRobloxChineseDomain && DFInt::SendJoinTimeDeltasToDiagLuobu_HundredthsPercentage != -1 ) /*0x14103fc1e*/
            v32 = DFInt::SendJoinTimeDeltasToDiagLuobu_HundredthsPercentage; /*0x14103fc1e*/
        }
        if ( rand() % 10000 < v32 ) /*0x14103fc4c*/
        {
          v39 = &RBX::Analytics::location; /*0x14103fc59*/
          if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x14103fc64*/
            v39 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x14103fc64*/
          v40 = RBX::format(result: &v222, fmt: "UserClickToStartGameTime_Country_%s", v39->_Mypair._Myval2._Bx._Buf); /*0x14103fc7a*/
          __wind /*0xf1c00000000003e8*/
          {
            p_startGameTime = &this->sgs.startGameTime; /*0x14103fc80*/
            v42 = stats._Mypair._Myval2._Mylast; /*0x14103fc87*/
            if ( stats._Mypair._Myval2._Mylast == stats._Mypair._Myval2._Myend ) /*0x14103fc91*/
            {
              std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double &>( /*0x14103fcd5*/
                this: &stats,
                _Whereptr: stats._Mypair._Myval2._Mylast,
                <_Val_0>: v40,
                <_Val_1>: &this->sgs.startGameTime);
            }
            else
            {
              *(_QWORD *)stats._Mypair._Myval2._Mylast = 0; /*0x14103fc93*/
              v42->first._Mypair._Myval2._Mysize = 0; /*0x14103fc96*/
              v42->first._Mypair._Myval2._Myres = 0; /*0x14103fc9a*/
              v42->first._Mypair._Myval2._Bx = v40->_Mypair._Myval2._Bx; /*0x14103fca1*/
              *(_OWORD *)&v42->first._Mypair._Myval2._Mysize = *(_OWORD *)&v40->_Mypair._Myval2._Mysize; /*0x14103fca8*/
              v40->_Mypair._Myval2._Mysize = 0; /*0x14103fcac*/
              v40->_Mypair._Myval2._Myres = 15; /*0x14103fcb0*/
              v40->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103fcb8*/
              v42->second = *p_startGameTime; /*0x14103fcbe*/
              ++stats._Mypair._Myval2._Mylast; /*0x14103fcc2*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v222); /*0xf1c00000000003e0*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v222); /*0x14103fce2*/
          v43 = this->sgs.placelauncherStartTime - *p_startGameTime; /*0x14103fcef*/
          v283 = v43; /*0x14103fcf4*/
          v44 = &RBX::Analytics::location; /*0x14103fcfc*/
          if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x14103fd07*/
            v44 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x14103fd07*/
          v45 = RBX::format( /*0x14103fd1d*/
                  result: &v223,
                  fmt: "StartGameToPlaceLauncherStartTime_Country_%s",
                  v44->_Mypair._Myval2._Bx._Buf);
          __wind /*0xf1c00000000003d0*/
          {
            v46 = stats._Mypair._Myval2._Mylast; /*0x14103fd23*/
            if ( stats._Mypair._Myval2._Mylast == stats._Mypair._Myval2._Myend ) /*0x14103fd2d*/
            {
              std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x14103fd73*/
                this: &stats,
                _Whereptr: stats._Mypair._Myval2._Mylast,
                <_Val_0>: v45,
                <_Val_1>: &v283);
            }
            else
            {
              *(_QWORD *)stats._Mypair._Myval2._Mylast = 0; /*0x14103fd2f*/
              v46->first._Mypair._Myval2._Mysize = 0; /*0x14103fd32*/
              v46->first._Mypair._Myval2._Myres = 0; /*0x14103fd36*/
              v46->first._Mypair._Myval2._Bx = v45->_Mypair._Myval2._Bx; /*0x14103fd3d*/
              *(_OWORD *)&v46->first._Mypair._Myval2._Mysize = *(_OWORD *)&v45->_Mypair._Myval2._Mysize; /*0x14103fd44*/
              v45->_Mypair._Myval2._Mysize = 0; /*0x14103fd48*/
              v45->_Mypair._Myval2._Myres = 15; /*0x14103fd4c*/
              v45->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103fd54*/
              v46->second = v43; /*0x14103fd57*/
              ++stats._Mypair._Myval2._Mylast; /*0x14103fd5c*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v223); /*0xf1c00000000003c8*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v223); /*0x14103fd80*/
          v47 = this->sgs.fetchedJoinScriptTime - this->sgs.placelauncherStartTime; /*0x14103fd8d*/
          v283 = v47; /*0x14103fd95*/
          v48 = &RBX::Analytics::location; /*0x14103fd9d*/
          if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x14103fda8*/
            v48 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x14103fda8*/
          v49 = RBX::format( /*0x14103fdbe*/
                  result: &v224,
                  fmt: "PlaceLauncherStartToFetchedScriptTime_Country_%s",
                  v48->_Mypair._Myval2._Bx._Buf);
          __wind /*0xf1c00000000003b8*/
          {
            v50 = stats._Mypair._Myval2._Mylast; /*0x14103fdc4*/
            if ( stats._Mypair._Myval2._Mylast == stats._Mypair._Myval2._Myend ) /*0x14103fdce*/
            {
              std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x14103fe14*/
                this: &stats,
                _Whereptr: stats._Mypair._Myval2._Mylast,
                <_Val_0>: v49,
                <_Val_1>: &v283);
            }
            else
            {
              *(_QWORD *)stats._Mypair._Myval2._Mylast = 0; /*0x14103fdd0*/
              v50->first._Mypair._Myval2._Mysize = 0; /*0x14103fdd3*/
              v50->first._Mypair._Myval2._Myres = 0; /*0x14103fdd7*/
              v50->first._Mypair._Myval2._Bx = v49->_Mypair._Myval2._Bx; /*0x14103fdde*/
              *(_OWORD *)&v50->first._Mypair._Myval2._Mysize = *(_OWORD *)&v49->_Mypair._Myval2._Mysize; /*0x14103fde5*/
              v49->_Mypair._Myval2._Mysize = 0; /*0x14103fde9*/
              v49->_Mypair._Myval2._Myres = 15; /*0x14103fded*/
              v49->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103fdf5*/
              v50->second = v47; /*0x14103fdf8*/
              ++stats._Mypair._Myval2._Mylast; /*0x14103fdfd*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v224); /*0xf1c00000000003b0*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v224); /*0x14103fe21*/
          v51 = this->sgs.playerConfigureTime - this->sgs.fetchedJoinScriptTime; /*0x14103fe2e*/
          v283 = v51; /*0x14103fe36*/
          v52 = &RBX::Analytics::location; /*0x14103fe3e*/
          if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x14103fe49*/
            v52 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x14103fe49*/
          v53 = RBX::format( /*0x14103fe5f*/
                  result: &v225,
                  fmt: "FetchedScriptToPlayerConfTime_Country_%s",
                  v52->_Mypair._Myval2._Bx._Buf);
          __wind /*0xf1c00000000003a0*/
          {
            v54 = stats._Mypair._Myval2._Mylast; /*0x14103fe65*/
            if ( stats._Mypair._Myval2._Mylast == stats._Mypair._Myval2._Myend ) /*0x14103fe6f*/
            {
              std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x14103feb5*/
                this: &stats,
                _Whereptr: stats._Mypair._Myval2._Mylast,
                <_Val_0>: v53,
                <_Val_1>: &v283);
            }
            else
            {
              *(_QWORD *)stats._Mypair._Myval2._Mylast = 0; /*0x14103fe71*/
              v54->first._Mypair._Myval2._Mysize = 0; /*0x14103fe74*/
              v54->first._Mypair._Myval2._Myres = 0; /*0x14103fe78*/
              v54->first._Mypair._Myval2._Bx = v53->_Mypair._Myval2._Bx; /*0x14103fe7f*/
              *(_OWORD *)&v54->first._Mypair._Myval2._Mysize = *(_OWORD *)&v53->_Mypair._Myval2._Mysize; /*0x14103fe86*/
              v53->_Mypair._Myval2._Mysize = 0; /*0x14103fe8a*/
              v53->_Mypair._Myval2._Myres = 15; /*0x14103fe8e*/
              v53->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103fe96*/
              v54->second = v51; /*0x14103fe99*/
              ++stats._Mypair._Myval2._Mylast; /*0x14103fe9e*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v225); /*0xf1c0000000000398*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v225); /*0x14103fec2*/
          v55 = this->sgs.connectTime - this->sgs.playerConfigureTime; /*0x14103fecf*/
          v283 = v55; /*0x14103fed7*/
          v56 = &RBX::Analytics::location; /*0x14103fedf*/
          if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x14103feea*/
            v56 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x14103feea*/
          v57 = RBX::format(result: &v226, fmt: "PlayerConfigToConnectTime_Country_%s", v56->_Mypair._Myval2._Bx._Buf); /*0x14103ff00*/
          __wind /*0xf1c0000000000388*/
          {
            v58 = stats._Mypair._Myval2._Mylast; /*0x14103ff06*/
            if ( stats._Mypair._Myval2._Mylast == stats._Mypair._Myval2._Myend ) /*0x14103ff10*/
            {
              std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x14103ff56*/
                this: &stats,
                _Whereptr: stats._Mypair._Myval2._Mylast,
                <_Val_0>: v57,
                <_Val_1>: &v283);
            }
            else
            {
              *(_QWORD *)stats._Mypair._Myval2._Mylast = 0; /*0x14103ff12*/
              v58->first._Mypair._Myval2._Mysize = 0; /*0x14103ff15*/
              v58->first._Mypair._Myval2._Myres = 0; /*0x14103ff19*/
              v58->first._Mypair._Myval2._Bx = v57->_Mypair._Myval2._Bx; /*0x14103ff20*/
              *(_OWORD *)&v58->first._Mypair._Myval2._Mysize = *(_OWORD *)&v57->_Mypair._Myval2._Mysize; /*0x14103ff27*/
              v57->_Mypair._Myval2._Mysize = 0; /*0x14103ff2b*/
              v57->_Mypair._Myval2._Myres = 15; /*0x14103ff2f*/
              v57->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103ff37*/
              v58->second = v55; /*0x14103ff3a*/
              ++stats._Mypair._Myval2._Mylast; /*0x14103ff3f*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v226); /*0xf1c0000000000380*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v226); /*0x14103ff63*/
          v59 = this->sgs.receivedGlobalsTime - this->sgs.connectTime; /*0x14103ff70*/
          v283 = v59; /*0x14103ff78*/
          v60 = &RBX::Analytics::location; /*0x14103ff80*/
          if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x14103ff8b*/
            v60 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x14103ff8b*/
          v61 = RBX::format( /*0x14103ffa1*/
                  result: &v227,
                  fmt: "ConnectToReceivedGlobalsTime_Country_%s",
                  v60->_Mypair._Myval2._Bx._Buf);
          __wind /*0xf1c0000000000370*/
          {
            v62 = stats._Mypair._Myval2._Mylast; /*0x14103ffa7*/
            if ( stats._Mypair._Myval2._Mylast == stats._Mypair._Myval2._Myend ) /*0x14103ffb1*/
            {
              std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x14103fff7*/
                this: &stats,
                _Whereptr: stats._Mypair._Myval2._Mylast,
                <_Val_0>: v61,
                <_Val_1>: &v283);
            }
            else
            {
              *(_QWORD *)stats._Mypair._Myval2._Mylast = 0; /*0x14103ffb3*/
              v62->first._Mypair._Myval2._Mysize = 0; /*0x14103ffb6*/
              v62->first._Mypair._Myval2._Myres = 0; /*0x14103ffba*/
              v62->first._Mypair._Myval2._Bx = v61->_Mypair._Myval2._Bx; /*0x14103ffc1*/
              *(_OWORD *)&v62->first._Mypair._Myval2._Mysize = *(_OWORD *)&v61->_Mypair._Myval2._Mysize; /*0x14103ffc8*/
              v61->_Mypair._Myval2._Mysize = 0; /*0x14103ffcc*/
              v61->_Mypair._Myval2._Myres = 15; /*0x14103ffd0*/
              v61->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14103ffd8*/
              v62->second = v59; /*0x14103ffdb*/
              ++stats._Mypair._Myval2._Mylast; /*0x14103ffe0*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v227); /*0xf1c0000000000368*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v227); /*0x141040004*/
          v63 = this->sgs.gameLoadTime - this->sgs.receivedGlobalsTime; /*0x141040011*/
          v283 = v63; /*0x141040019*/
          v64 = &RBX::Analytics::location; /*0x141040021*/
          if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x14104002c*/
            v64 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x14104002c*/
          v65 = RBX::format( /*0x141040042*/
                  result: &v228,
                  fmt: "ReceivedGlobalToGameLoadTime_Country_%s",
                  v64->_Mypair._Myval2._Bx._Buf);
          __wind /*0xf1c0000000000358*/
          {
            v66 = stats._Mypair._Myval2._Mylast; /*0x141040048*/
            if ( stats._Mypair._Myval2._Mylast == stats._Mypair._Myval2._Myend ) /*0x141040052*/
            {
              std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x141040098*/
                this: &stats,
                _Whereptr: stats._Mypair._Myval2._Mylast,
                <_Val_0>: v65,
                <_Val_1>: &v283);
            }
            else
            {
              *(_QWORD *)stats._Mypair._Myval2._Mylast = 0; /*0x141040054*/
              v66->first._Mypair._Myval2._Mysize = 0; /*0x141040057*/
              v66->first._Mypair._Myval2._Myres = 0; /*0x14104005b*/
              v66->first._Mypair._Myval2._Bx = v65->_Mypair._Myval2._Bx; /*0x141040062*/
              *(_OWORD *)&v66->first._Mypair._Myval2._Mysize = *(_OWORD *)&v65->_Mypair._Myval2._Mysize; /*0x141040069*/
              v65->_Mypair._Myval2._Mysize = 0; /*0x14104006d*/
              v65->_Mypair._Myval2._Myres = 15; /*0x141040071*/
              v65->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141040079*/
              v66->second = v63; /*0x14104007c*/
              ++stats._Mypair._Myval2._Mylast; /*0x141040081*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v228); /*0xf1c0000000000350*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v228); /*0x1410400a5*/
          v67 = this->sgs.gameJoinTime - this->sgs.gameLoadTime; /*0x1410400b2*/
          v283 = v67; /*0x1410400ba*/
          v68 = &RBX::Analytics::location; /*0x1410400c2*/
          if ( RBX::Analytics::location._Mypair._Myval2._Myres >= 0x10 ) /*0x1410400cd*/
            v68 = (std::string *)RBX::Analytics::location._Mypair._Myval2._Bx._Ptr; /*0x1410400cd*/
          v69 = RBX::format(result: &v229, fmt: "GameLoadToGameJoinTime_Country_%s", v68->_Mypair._Myval2._Bx._Buf); /*0x1410400e3*/
          __wind /*0xf1c0000000000340*/
          {
            v70 = stats._Mypair._Myval2._Mylast; /*0x1410400e9*/
            if ( stats._Mypair._Myval2._Mylast == stats._Mypair._Myval2._Myend ) /*0x1410400f3*/
            {
              std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::string,double>( /*0x141040139*/
                this: &stats,
                _Whereptr: stats._Mypair._Myval2._Mylast,
                <_Val_0>: v69,
                <_Val_1>: &v283);
            }
            else
            {
              *(_QWORD *)stats._Mypair._Myval2._Mylast = 0; /*0x1410400f5*/
              v70->first._Mypair._Myval2._Mysize = 0; /*0x1410400f8*/
              v70->first._Mypair._Myval2._Myres = 0; /*0x1410400fc*/
              v70->first._Mypair._Myval2._Bx = v69->_Mypair._Myval2._Bx; /*0x141040103*/
              *(_OWORD *)&v70->first._Mypair._Myval2._Mysize = *(_OWORD *)&v69->_Mypair._Myval2._Mysize; /*0x14104010a*/
              v69->_Mypair._Myval2._Mysize = 0; /*0x14104010e*/
              v69->_Mypair._Myval2._Myres = 15; /*0x141040112*/
              v69->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104011a*/
              v70->second = v67; /*0x14104011d*/
              ++stats._Mypair._Myval2._Mylast; /*0x141040122*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v229); /*0xf1c0000000000338*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v229); /*0x141040146*/
          v283 = *p_avatarLoadTime - this->sgs.gameJoinTime; /*0x141040157*/
          v71 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x141040162*/
          v72 = RBX::format(result: &v230, fmt: "GameJoinToAvatarLoadTime_Country_%s", v71); /*0x141040178*/
          __wind /*0xf1c0000000000328*/
          {
            std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x14104018d*/
              this: &stats,
              <_Val_0>: v72,
              <_Val_1>: &v283);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v230); /*0xf1c0000000000320*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v230); /*0x14104019a*/
          if ( isRobloxChineseDomain ) /*0x1410401a2*/
          {
            std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[42],double &>( /*0x1410401b7*/
              this: &stats,
              <_Val_0>: (const char (*)[44])"UserClickToStartGameTime_Luobu",
              <_Val_1>: p_startGameTime);
            v283 = this->sgs.placelauncherStartTime - *p_startGameTime; /*0x1410401c9*/
            std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[42],double &>( /*0x1410401e4*/
              this: &stats,
              <_Val_0>: (const char (*)[44])"StartGameToPlaceLauncherStartTime_Luobu",
              <_Val_1>: &v283);
            v283 = this->sgs.fetchedJoinScriptTime - this->sgs.placelauncherStartTime; /*0x1410401f9*/
            std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[42],double &>( /*0x141040214*/
              this: &stats,
              <_Val_0>: (const char (*)[44])"PlaceLauncherStartToFetchedScriptTime_Luobu",
              <_Val_1>: &v283);
            v283 = this->sgs.playerConfigureTime - this->sgs.fetchedJoinScriptTime; /*0x141040229*/
            std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[42],double &>( /*0x141040244*/
              this: &stats,
              <_Val_0>: (const char (*)[44])"FetchedScriptToPlayerConfTime_Luobu",
              <_Val_1>: &v283);
            v283 = this->sgs.connectTime - this->sgs.playerConfigureTime; /*0x141040259*/
            std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[42],double &>( /*0x141040274*/
              this: &stats,
              <_Val_0>: (const char (*)[44])"PlayerConfigToConnectTime_Luobu",
              <_Val_1>: &v283);
            v283 = this->sgs.receivedGlobalsTime - this->sgs.connectTime; /*0x141040289*/
            std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[42],double &>( /*0x1410402a4*/
              this: &stats,
              <_Val_0>: (const char (*)[44])"ConnectToReceivedGlobalsTime_Luobu",
              <_Val_1>: &v283);
            v283 = this->sgs.gameLoadTime - this->sgs.receivedGlobalsTime; /*0x1410402b9*/
            std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[42],double &>( /*0x1410402d4*/
              this: &stats,
              <_Val_0>: (const char (*)[44])"ReceivedGlobalToGameLoadTime_Luobu",
              <_Val_1>: &v283);
            v283 = this->sgs.gameJoinTime - this->sgs.gameLoadTime; /*0x1410402e9*/
            std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[42],double &>( /*0x141040304*/
              this: &stats,
              <_Val_0>: (const char (*)[44])"GameLoadToGameJoinTime_Luobu",
              <_Val_1>: &v283);
            v283 = *p_avatarLoadTime - this->sgs.gameJoinTime; /*0x141040315*/
            std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[42],double &>( /*0x141040330*/
              this: &stats,
              <_Val_0>: (const char (*)[44])"GameJoinToAvatarLoadTime_Luobu",
              <_Val_1>: &v283);
          }
          v73 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x141040338*/
          v74 = RBX::format(result: &v231, fmt: "AvatarLoadTime_Country_%s", v73); /*0x14104034e*/
          __wind /*0xf1c0000000000310*/
          {
            std::vector<std::pair<std::string,double>>::emplace_back<std::string,double &>( /*0x14104035f*/
              this: &stats,
              <_Val_0>: v74,
              <_Val_1>: &this->sgs.avatarLoadTime);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v231); /*0xf1c0000000000308*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v231); /*0x14104036c*/
          if ( isRobloxChineseDomain ) /*0x141040374*/
            std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[42],double &>( /*0x141040385*/
              this: &stats,
              <_Val_0>: (const char (*)[44])"AvatarLoadTime_Luobu",
              <_Val_1>: &this->sgs.avatarLoadTime);
          RBX::SystemUtil::osPlatform(result: &platform); /*0x14104038f*/
          __wind /*0xf1c00000000002f8*/
          {
            v283 = this->sgs.placelauncherStartTime - *p_startGameTime; /*0x1410403a2*/
            v75 = std::string::c_str(this: (RBX::ContentId *)&platform); /*0x1410403b4*/
            v76 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x1410403be*/
            v77 = RBX::format(result: &v232, fmt: "StartGameToPlaceLauncherStartTime_Country_%s_%s", v76, v75); /*0x1410403d7*/
            __wind /*0xf1c00000000002ec*/
            {
              std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x1410403ec*/
                this: &stats,
                <_Val_0>: v77,
                <_Val_1>: &v283);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v232); /*0xf1c00000000002e4*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v232); /*0x1410403f9*/
            v283 = this->sgs.fetchedJoinScriptTime - this->sgs.placelauncherStartTime; /*0x14104040e*/
            v78 = std::string::c_str(this: (RBX::ContentId *)&platform); /*0x141040420*/
            v79 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x14104042a*/
            v80 = RBX::format(result: &v233, fmt: "PlaceLauncherStartToFetchedScriptTime_Country_%s_%s", v79, v78); /*0x141040443*/
            __wind /*0xf1c00000000002d4*/
            {
              std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x141040458*/
                this: &stats,
                <_Val_0>: v80,
                <_Val_1>: &v283);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v233); /*0xf1c00000000002cc*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v233); /*0x141040465*/
            v283 = this->sgs.playerConfigureTime - this->sgs.fetchedJoinScriptTime; /*0x14104047a*/
            v81 = std::string::c_str(this: (RBX::ContentId *)&platform); /*0x14104048c*/
            v82 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x141040496*/
            v83 = RBX::format(result: &v234, fmt: "FetchedScriptToPlayerConfTime_Country_%s_%s", v82, v81); /*0x1410404af*/
            __wind /*0xf1c00000000002bc*/
            {
              std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x1410404c4*/
                this: &stats,
                <_Val_0>: v83,
                <_Val_1>: &v283);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v234); /*0xf1c00000000002b4*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v234); /*0x1410404d1*/
            v283 = this->sgs.connectTime - this->sgs.playerConfigureTime; /*0x1410404e6*/
            v84 = std::string::c_str(this: (RBX::ContentId *)&platform); /*0x1410404f8*/
            v85 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x141040502*/
            v86 = RBX::format(result: &v235, fmt: "PlayerConfigToConnectTime_Country_%s_%s", v85, v84); /*0x14104051b*/
            __wind /*0xf1c00000000002a4*/
            {
              std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x141040530*/
                this: &stats,
                <_Val_0>: v86,
                <_Val_1>: &v283);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v235); /*0xf1c000000000029c*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v235); /*0x14104053d*/
            v283 = this->sgs.receivedGlobalsTime - this->sgs.connectTime; /*0x141040552*/
            v87 = std::string::c_str(this: (RBX::ContentId *)&platform); /*0x141040564*/
            v88 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x14104056e*/
            v89 = RBX::format(result: &v236, fmt: "ConnectToReceivedGlobalsTime_Country_%s_%s", v88, v87); /*0x141040587*/
            __wind /*0xf1c000000000028c*/
            {
              std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x14104059c*/
                this: &stats,
                <_Val_0>: v89,
                <_Val_1>: &v283);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v236); /*0xf1c0000000000284*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v236); /*0x1410405a9*/
            v283 = this->sgs.gameLoadTime - this->sgs.receivedGlobalsTime; /*0x1410405be*/
            v90 = std::string::c_str(this: (RBX::ContentId *)&platform); /*0x1410405d0*/
            v91 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x1410405da*/
            v92 = RBX::format(result: &v237, fmt: "ReceivedGlobalToGameLoadTime_Country_%s_%s", v91, v90); /*0x1410405f3*/
            __wind /*0xf1c0000000000274*/
            {
              std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x141040608*/
                this: &stats,
                <_Val_0>: v92,
                <_Val_1>: &v283);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v237); /*0xf1c000000000026c*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v237); /*0x141040615*/
            v283 = this->sgs.gameJoinTime - this->sgs.gameLoadTime; /*0x14104062a*/
            v93 = std::string::c_str(this: (RBX::ContentId *)&platform); /*0x14104063c*/
            v94 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x141040646*/
            v95 = RBX::format(result: &v238, fmt: "GameLoadToGameJoinTime_Country_%s_%s", v94, v93); /*0x14104065f*/
            __wind /*0xf1c000000000025c*/
            {
              std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x141040674*/
                this: &stats,
                <_Val_0>: v95,
                <_Val_1>: &v283);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v238); /*0xf1c0000000000254*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v238); /*0x141040681*/
            v283 = *p_avatarLoadTime - this->sgs.gameJoinTime; /*0x141040692*/
            v96 = std::string::c_str(this: (RBX::ContentId *)&platform); /*0x1410406a4*/
            v97 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x1410406ae*/
            v98 = RBX::format(result: &v239, fmt: "GameJoinToAvatarLoadTime_Country_%s_%s", v97, v96); /*0x1410406c7*/
            __wind /*0xf1c0000000000244*/
            {
              std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x1410406dc*/
                this: &stats,
                <_Val_0>: v98,
                <_Val_1>: &v283);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v239); /*0xf1c000000000023c*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v239); /*0x1410406e9*/
            v99 = std::string::c_str(this: (RBX::ContentId *)&platform); /*0x1410406f8*/
            v100 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x141040702*/
            v101 = RBX::format(result: &v240, fmt: "AvatarLoadTime_Country_%s_%s", v100, v99); /*0x14104071b*/
            __wind /*0xf1c000000000022c*/
            {
              std::vector<std::pair<std::string,double>>::emplace_back<std::string,double &>( /*0x14104072c*/
                this: &stats,
                <_Val_0>: v101,
                <_Val_1>: &this->sgs.avatarLoadTime);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v240); /*0xf1c0000000000224*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v240); /*0x141040739*/
            if ( isMobile() ) /*0x14104073e*/
            {
              v283 = this->sgs.placelauncherStartTime - *p_startGameTime; /*0x141040758*/
              v102 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x141040767*/
              v103 = RBX::format(result: &v241, fmt: "StartGameToPlaceLauncherStartTime_Country_%s_Mobile", v102); /*0x14104077d*/
              __wind /*0xf1c0000000000214*/
              {
                std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x141040792*/
                  this: &stats,
                  <_Val_0>: v103,
                  <_Val_1>: &v283);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v241); /*0xf1c000000000020c*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v241); /*0x14104079f*/
              v283 = this->sgs.fetchedJoinScriptTime - this->sgs.placelauncherStartTime; /*0x1410407b4*/
              v104 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x1410407c3*/
              v105 = RBX::format(result: &v242, fmt: "PlaceLauncherStartToFetchedScriptTime_Country_%s_Mobile", v104); /*0x1410407d9*/
              __wind /*0xf1c00000000001fc*/
              {
                std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x1410407ee*/
                  this: &stats,
                  <_Val_0>: v105,
                  <_Val_1>: &v283);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v242); /*0xf1c00000000001f4*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v242); /*0x1410407fb*/
              v283 = this->sgs.playerConfigureTime - this->sgs.fetchedJoinScriptTime; /*0x141040810*/
              v106 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x14104081f*/
              v107 = RBX::format(result: &v243, fmt: "FetchedScriptToPlayerConfTime_Country_%s_Mobile", v106); /*0x141040835*/
              __wind /*0xf1c00000000001e4*/
              {
                std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x14104084a*/
                  this: &stats,
                  <_Val_0>: v107,
                  <_Val_1>: &v283);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v243); /*0xf1c00000000001dc*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v243); /*0x141040857*/
              v283 = this->sgs.connectTime - this->sgs.playerConfigureTime; /*0x14104086c*/
              v108 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x14104087b*/
              v109 = RBX::format(result: &v244, fmt: "PlayerConfigToConnectTime_Country_%s_Mobile", v108); /*0x141040891*/
              __wind /*0xf1c00000000001cc*/
              {
                std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x1410408a6*/
                  this: &stats,
                  <_Val_0>: v109,
                  <_Val_1>: &v283);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v244); /*0xf1c00000000001c4*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v244); /*0x1410408b3*/
              v283 = this->sgs.receivedGlobalsTime - this->sgs.connectTime; /*0x1410408c8*/
              v110 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x1410408d7*/
              v111 = RBX::format(result: &v245, fmt: "ConnectToReceivedGlobalsTime_Country_%s_Mobile", v110); /*0x1410408ed*/
              __wind /*0xf1c00000000001b4*/
              {
                std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x141040902*/
                  this: &stats,
                  <_Val_0>: v111,
                  <_Val_1>: &v283);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v245); /*0xf1c00000000001ac*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v245); /*0x14104090f*/
              v283 = this->sgs.gameLoadTime - this->sgs.receivedGlobalsTime; /*0x141040924*/
              v112 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x141040933*/
              v113 = RBX::format(result: &v246, fmt: "ReceivedGlobalToGameLoadTime_Country_%s_Mobile", v112); /*0x141040949*/
              __wind /*0xf1c000000000019c*/
              {
                std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x14104095e*/
                  this: &stats,
                  <_Val_0>: v113,
                  <_Val_1>: &v283);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v246); /*0xf1c0000000000194*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v246); /*0x14104096b*/
              v283 = this->sgs.gameJoinTime - this->sgs.gameLoadTime; /*0x141040980*/
              v114 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x14104098f*/
              v115 = RBX::format(result: &v247, fmt: "GameLoadToGameJoinTime_Country_%s_Mobile", v114); /*0x1410409a5*/
              __wind /*0xf1c0000000000184*/
              {
                std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x1410409ba*/
                  this: &stats,
                  <_Val_0>: v115,
                  <_Val_1>: &v283);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v247); /*0xf1c000000000017c*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v247); /*0x1410409c7*/
              v283 = *p_avatarLoadTime - this->sgs.gameJoinTime; /*0x1410409d8*/
              v116 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x1410409e7*/
              v117 = RBX::format(result: &v248, fmt: "GameJoinToAvatarLoadTime_Country_%s_Mobile", v116); /*0x1410409fd*/
              __wind /*0xf1c000000000016c*/
              {
                std::vector<std::pair<std::string,double>>::emplace_back<std::string,double>( /*0x141040a12*/
                  this: &stats,
                  <_Val_0>: v117,
                  <_Val_1>: &v283);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v248); /*0xf1c0000000000164*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v248); /*0x141040a1f*/
              v118 = std::string::c_str(this: (RBX::ContentId *)&RBX::Analytics::location); /*0x141040a2b*/
              v119 = RBX::format(result: &v249, fmt: "AvatarLoadTime_Country_%s_Mobile", v118); /*0x141040a41*/
              __wind /*0xf1c0000000000154*/
              {
                std::vector<std::pair<std::string,double>>::emplace_back<std::string,double &>( /*0x141040a52*/
                  this: &stats,
                  <_Val_0>: v119,
                  <_Val_1>: &this->sgs.avatarLoadTime);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v249); /*0xf1c000000000014c*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v249); /*0x141040a5f*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&platform); /*0x141040a6a*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&platform); /*0xf1c0000000000140*/
          }
        }
        if ( stats._Mypair._Myval2._Myfirst != stats._Mypair._Myval2._Mylast ) /*0x141040a79*/
          RBX::Analytics::EphemeralCounter::bulkReportStats(&stats, blocking: false); /*0x141040a82*/
        std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)&stats); /*0x141040a8d*/
      }
    }
    __unwind
    {
      std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)&stats); /*0xf1c0000000000134*/
    }
    v120 = DFInt::SendJoinTimeStatsToDiag_HundredthsPercentage; /*0x141040a92*/
    if ( DFString::SendJoinTimeStatsHundPrecCountryOverride._Mypair._Myval2._Mysize != 0 ) /*0x141040aa1*/
    {
      v121 = std::string::string(this: &v250, _Ptr: ","); /*0x141040ab1*/
      __wind /*0xf1c0000000000124*/
      {
        v122 = RBX::Network::getPairIntValue( /*0x141040acd*/
                 target: &RBX::Analytics::location,
                 from: &DFString::SendJoinTimeStatsHundPrecCountryOverride,
                 delimiters: v121);
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v250); /*0x141040ad6*/
        if ( v122 != -1 ) /*0x141040ade*/
          v120 = v122; /*0x141040ade*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v250); /*0xf1c000000000011c*/
      }
    }
    v123 = false; /*0x141040ae2*/
    if ( DFFlag::SendLuobuSpecificJoinTimeStats.value ) /*0x141040aea*/
    {
      v124 = RBX::GetBaseURL(); /*0x141040aec*/
      v215 = *RBX::StringView::StringView(this: &v279, Str: v124); /*0x141040b03*/
      v125 = RBX::Url::fromString(result: (RBX::Url *)&v281.hotSpot, str: &v215); /*0x141040b14*/
      __wind /*0xf1c000000000010c*/
      {
        v123 = RBX::Http::isRobloxChineseDomain(url: v125); /*0x141040b22*/
      }
      __unwind
      {
        RBX::Url::~Url(this: (RBX::PluginDragImpl *)&v281.hotSpot); /*0xf1c0000000000104*/
      }
      RBX::Url::~Url(this: (RBX::PluginDragImpl *)&v281.hotSpot); /*0x141040b2c*/
      if ( v123 && DFInt::SendJoinTimeStatsHundPrecLuobuOverride != -1 ) /*0x141040b3c*/
        v120 = DFInt::SendJoinTimeStatsHundPrecLuobuOverride; /*0x141040b3c*/
    }
    if ( rand() % 10000 < v120 ) /*0x141040b6b*/
    {
      __wind /*0xf1c00000000000f4*/
      {
        memset(&v214, 0, sizeof(v214)); /*0x141040b74*/
        gameJoinTime = this->sgs.gameJoinTime; /*0x141040b8b*/
        std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[11],float>( /*0x141040ba6*/
          this: &v214,
          <_Val_0>: (const char (*)[11])"LaunchTime",
          <_Val_1>: &gameJoinTime);
        v126 = this->sgs.gameJoinTime; /*0x141040bb3*/
        gameJoinTime = v126; /*0x141040bb7*/
        v127 = std::operator+<char>(result: &v251, _Left: "LaunchTime_Country_", _Right: &RBX::Analytics::location); /*0x141040bd4*/
        __wind /*0xf1c00000000000e8*/
        {
          std::vector<std::pair<std::string,double>>::emplace_back<std::string,float>( /*0x141040be9*/
            this: &v214,
            <_Val_0>: v127,
            <_Val_1>: &gameJoinTime);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v251); /*0xf1c00000000000e0*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v251); /*0x141040bf6*/
        if ( v123 ) /*0x141040bfd*/
        {
          v128 = this->sgs.gameJoinTime; /*0x141040c07*/
          gameJoinTime = v128; /*0x141040c0b*/
          std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[11],float>( /*0x141040c26*/
            this: &v214,
            <_Val_0>: (const char (*)[11])"LaunchTime_Luobu",
            <_Val_1>: &gameJoinTime);
        }
        v129 = *p_avatarLoadTime; /*0x141040c2f*/
        v130 = this->sgs.gameJoinTime; /*0x141040c3b*/
        gameJoinTime = v129 - v130; /*0x141040c43*/
        std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[11],float>( /*0x141040c5e*/
          this: &v214,
          <_Val_0>: (const char (*)[11])"AssetOnlyLoadTime",
          <_Val_1>: &gameJoinTime);
        v131 = *p_avatarLoadTime; /*0x141040c67*/
        v132 = this->sgs.gameJoinTime; /*0x141040c73*/
        gameJoinTime = v131 - v132; /*0x141040c7b*/
        v133 = std::operator+<char>( /*0x141040c98*/
                 result: &v252,
                 _Left: "AssetOnlyLoadTime_Country_",
                 _Right: &RBX::Analytics::location);
        __wind /*0xf1c00000000000d0*/
        {
          std::vector<std::pair<std::string,double>>::emplace_back<std::string,float>( /*0x141040cad*/
            this: &v214,
            <_Val_0>: v133,
            <_Val_1>: &gameJoinTime);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v252); /*0xf1c00000000000c8*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v252); /*0x141040cba*/
        gameJoinTime = (float)*p_avatarLoadTime - (float)this->sgs.gameJoinTime; /*0x141040cd7*/
        if ( v123 ) /*0x141040ced*/
          std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[11],float>( /*0x141040cf6*/
            this: &v214,
            <_Val_0>: (const char (*)[11])"AssetOnlyLoadTime_Luobu",
            <_Val_1>: &gameJoinTime);
        else
          std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[11],float>( /*0x141040d04*/
            this: &v214,
            <_Val_0>: (const char (*)[11])"AssetOnlyLoadTime_NonLuobu",
            <_Val_1>: &gameJoinTime);
        if ( isMobile() ) /*0x141040d09*/
        {
          v134 = this->sgs.gameJoinTime; /*0x141040d1e*/
          gameJoinTime = v134; /*0x141040d22*/
          std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[11],float>( /*0x141040d3d*/
            this: &v214,
            <_Val_0>: (const char (*)[11])"LaunchTime_Mobile",
            <_Val_1>: &gameJoinTime);
          v135 = this->sgs.gameJoinTime; /*0x141040d4a*/
          gameJoinTime = v135; /*0x141040d4e*/
          v136 = std::operator+<char>( /*0x141040d6b*/
                   result: &v253,
                   _Left: "LaunchTime_Mobile_Country_",
                   _Right: &RBX::Analytics::location);
          __wind /*0xf1c00000000000b8*/
          {
            std::vector<std::pair<std::string,double>>::emplace_back<std::string,float>( /*0x141040d80*/
              this: &v214,
              <_Val_0>: v136,
              <_Val_1>: &gameJoinTime);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v253); /*0xf1c00000000000b0*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v253); /*0x141040d8d*/
          v137 = *p_avatarLoadTime; /*0x141040d96*/
          v138 = this->sgs.gameJoinTime; /*0x141040da2*/
          gameJoinTime = v137 - v138; /*0x141040daa*/
          std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[11],float>( /*0x141040dc5*/
            this: &v214,
            <_Val_0>: (const char (*)[11])"AssetOnlyLoadTime_Mobile",
            <_Val_1>: &gameJoinTime);
          v139 = *p_avatarLoadTime; /*0x141040dce*/
          v140 = this->sgs.gameJoinTime; /*0x141040dda*/
          gameJoinTime = v139 - v140; /*0x141040de2*/
          v141 = std::operator+<char>( /*0x141040dff*/
                   result: &v254,
                   _Left: "AssetOnlyLoadTime_Mobile_Country_",
                   _Right: &RBX::Analytics::location);
          __wind /*0xf1c00000000000a0*/
          {
            std::vector<std::pair<std::string,double>>::emplace_back<std::string,float>( /*0x141040e14*/
              this: &v214,
              <_Val_0>: v141,
              <_Val_1>: &gameJoinTime);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v254); /*0xf1c0000000000098*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v254); /*0x141040e21*/
        }
        if ( DFFlag::DebugLaunchTimeByCountryPlaceSpecific.value ) /*0x141040e2d*/
        {
          value = DFFlag::DebugLaunchTimeByCountryPlaceSpecificAddPlatform.value; /*0x141040e33*/
          v143 = this->sgs.gameJoinTime; /*0x141040e3a*/
          v144 = std::string::string(this: &v255, _Ptr: "LaunchTime"); /*0x141040e50*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141040e69*/
            stats: &v214,
            metric: v144,
            value: v143,
            wantPlatform: value,
            wantMobile: true);
          startGameTime = this->sgs.startGameTime; /*0x141040e6e*/
          v146 = std::string::string(this: &v256, _Ptr: "StartGameTime"); /*0x141040e84*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141040e9d*/
            stats: &v214,
            metric: v146,
            value: startGameTime,
            wantPlatform: value,
            wantMobile: true);
          placelauncherStartTime = this->sgs.placelauncherStartTime; /*0x141040ea2*/
          v148 = std::string::string(this: &v257, _Ptr: "PlaceLauncherStart"); /*0x141040eb8*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141040ed1*/
            stats: &v214,
            metric: v148,
            value: placelauncherStartTime,
            wantPlatform: value,
            wantMobile: true);
          fetchedJoinScriptTime = this->sgs.fetchedJoinScriptTime; /*0x141040ed6*/
          v150 = std::string::string(this: &v258, _Ptr: "FetchedJoinScriptTime"); /*0x141040eec*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141040f05*/
            stats: &v214,
            metric: v150,
            value: fetchedJoinScriptTime,
            wantPlatform: value,
            wantMobile: true);
          playerConfigureTime = this->sgs.playerConfigureTime; /*0x141040f0a*/
          v152 = std::string::string(this: &v259, _Ptr: "PlayerConfigureTime"); /*0x141040f20*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141040f39*/
            stats: &v214,
            metric: v152,
            value: playerConfigureTime,
            wantPlatform: value,
            wantMobile: true);
          connectTime = this->sgs.connectTime; /*0x141040f3e*/
          v154 = std::string::string(this: &v260, _Ptr: "ConnectTime"); /*0x141040f54*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141040f6d*/
            stats: &v214,
            metric: v154,
            value: connectTime,
            wantPlatform: value,
            wantMobile: true);
          receivedGlobalsTime = this->sgs.receivedGlobalsTime; /*0x141040f72*/
          v156 = std::string::string(this: &v261, _Ptr: "ReceivedGlobasTime"); /*0x141040f88*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141040fa1*/
            stats: &v214,
            metric: v156,
            value: receivedGlobalsTime,
            wantPlatform: value,
            wantMobile: true);
          gameLoadTime = this->sgs.gameLoadTime; /*0x141040fa6*/
          v158 = std::string::string(this: &v262, _Ptr: "GameLoadTime"); /*0x141040fbc*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141040fd5*/
            stats: &v214,
            metric: v158,
            value: gameLoadTime,
            wantPlatform: value,
            wantMobile: true);
          v159 = this->sgs.gameJoinTime; /*0x141040fda*/
          v160 = std::string::string(this: &v263, _Ptr: "GameJoinTime"); /*0x141040ff0*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141041009*/
            stats: &v214,
            metric: v160,
            value: v159,
            wantPlatform: value,
            wantMobile: true);
          v161 = *p_avatarLoadTime; /*0x14104100e*/
          v162 = std::string::string(this: &v264, _Ptr: "AvatarLoadTime"); /*0x141041020*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141041039*/
            stats: &v214,
            metric: v162,
            value: v161,
            wantPlatform: value,
            wantMobile: true);
          v163 = this->sgs.startGameTime; /*0x14104103e*/
          v164 = std::string::string(this: &v265, _Ptr: "UserClickToStartGameTime"); /*0x141041054*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x14104106d*/
            stats: &v214,
            metric: v164,
            value: v163,
            wantPlatform: value,
            wantMobile: true);
          v165 = this->sgs.placelauncherStartTime - this->sgs.startGameTime; /*0x14104107a*/
          v166 = std::string::string(this: &v266, _Ptr: "StartGameToPlaceLauncherStartTime"); /*0x141041090*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1410410a9*/
            stats: &v214,
            metric: v166,
            value: v165,
            wantPlatform: value,
            wantMobile: true);
          v167 = this->sgs.fetchedJoinScriptTime - this->sgs.placelauncherStartTime; /*0x1410410b6*/
          v168 = std::string::string(this: &v267, _Ptr: "PlaceLauncherStartToFetchedScriptTime"); /*0x1410410cc*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1410410e5*/
            stats: &v214,
            metric: v168,
            value: v167,
            wantPlatform: value,
            wantMobile: true);
          v169 = this->sgs.playerConfigureTime - this->sgs.fetchedJoinScriptTime; /*0x1410410f2*/
          v170 = std::string::string(this: &v268, _Ptr: "FetchedScriptToPlayerConfTime"); /*0x141041108*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141041121*/
            stats: &v214,
            metric: v170,
            value: v169,
            wantPlatform: value,
            wantMobile: true);
          v171 = this->sgs.connectTime - this->sgs.playerConfigureTime; /*0x14104112e*/
          v172 = std::string::string(this: &v269, _Ptr: "PlayerConfigToConnectTime"); /*0x141041144*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x14104115d*/
            stats: &v214,
            metric: v172,
            value: v171,
            wantPlatform: value,
            wantMobile: true);
          v173 = this->sgs.receivedGlobalsTime - this->sgs.connectTime; /*0x14104116a*/
          v174 = std::string::string(this: &v270, _Ptr: "ConnectToReceivedGlobalsTime"); /*0x141041180*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141041199*/
            stats: &v214,
            metric: v174,
            value: v173,
            wantPlatform: value,
            wantMobile: true);
          v175 = this->sgs.gameLoadTime - this->sgs.receivedGlobalsTime; /*0x1410411a6*/
          v176 = std::string::string(this: &v271, _Ptr: "ReceivedGlobalToGameLoadTime"); /*0x1410411bc*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1410411d5*/
            stats: &v214,
            metric: v176,
            value: v175,
            wantPlatform: value,
            wantMobile: true);
          v177 = this->sgs.gameJoinTime - this->sgs.gameLoadTime; /*0x1410411e2*/
          v178 = std::string::string(this: &v272, _Ptr: "GameLoadToGameJoinTime_Country"); /*0x1410411f8*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141041211*/
            stats: &v214,
            metric: v178,
            value: v177,
            wantPlatform: value,
            wantMobile: true);
          v179 = *p_avatarLoadTime - this->sgs.gameJoinTime; /*0x14104121a*/
          v180 = std::string::string(this: &v273, _Ptr: "GameJoinToAvatarLoadTime_Country"); /*0x141041230*/
          generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x141041249*/
            stats: &v214,
            metric: v180,
            value: v179,
            wantPlatform: value,
            wantMobile: true);
        }
        RBX::Analytics::EphemeralCounter::bulkReportStats(stats: &v214, blocking: false); /*0x141041255*/
      }
      __unwind
      {
        std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)&v214); /*0xf1c000000000008c*/
      }
      std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)&v214); /*0x141041260*/
    }
    if ( rand() % 10000 < DFInt::SendJoinHttpBytesToDiag_HundredthsPercentage ) /*0x141041290*/
    {
      NumOfDownloadedBytes = RBX::Http::getNumOfDownloadedBytes(); /*0x141041296*/
      if ( NumOfDownloadedBytes < 0 ) /*0x1410412a4*/
        v182 = (double)(int)(NumOfDownloadedBytes & 1 | ((unsigned __int64)NumOfDownloadedBytes >> 1)) /*0x1410412bb*/
             + (double)(int)(NumOfDownloadedBytes & 1 | ((unsigned __int64)NumOfDownloadedBytes >> 1));
      else
        v182 = (double)(int)NumOfDownloadedBytes; /*0x1410412a6*/
      v183 = RBX::SystemUtil::osPlatform(result: &v275); /*0x1410412c6*/
      __wind /*0xf1c000000000007c*/
      {
        v184 = std::operator+<char>(result: &v274, _Left: "HTTPBytesInJoin-", _Right: v183); /*0x1410412dd*/
        __wind /*0xf1c0000000000070*/
        {
          RBX::Analytics::EphemeralCounter::reportStats(category: v184, value: v182, blocking: false); /*0x1410412ec*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v274); /*0xf1c0000000000068*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v274); /*0x1410412f9*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v275); /*0xf1c000000000005c*/
      }
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v275); /*0x141041306*/
      NumOfNonCachedDownloadedBytes = RBX::Http::getNumOfNonCachedDownloadedBytes(); /*0x14104130b*/
      if ( NumOfNonCachedDownloadedBytes < 0 ) /*0x141041319*/
        v186 = (double)(int)(NumOfNonCachedDownloadedBytes & 1 | ((unsigned __int64)NumOfNonCachedDownloadedBytes >> 1)) /*0x141041330*/
             + (double)(int)(NumOfNonCachedDownloadedBytes & 1 | ((unsigned __int64)NumOfNonCachedDownloadedBytes >> 1));
      else
        v186 = (double)(int)NumOfNonCachedDownloadedBytes; /*0x14104131b*/
      v187 = RBX::SystemUtil::osPlatform(result: &v277); /*0x14104133b*/
      __wind /*0xf1c000000000004c*/
      {
        v188 = std::operator+<char>(result: &v276, _Left: "HTTPNonCachedBytesInJoin-", _Right: v187); /*0x141041352*/
        __wind /*0xf1c0000000000040*/
        {
          RBX::Analytics::EphemeralCounter::reportStats(category: v188, value: v186, blocking: false); /*0x141041361*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v276); /*0xf1c0000000000038*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v276); /*0x14104136e*/
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v277); /*0x14104137b*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v277); /*0xf1c000000000002c*/
      }
    }
    if ( DFFlag::DebugLogAvatarLoadTimeStatsByPlace.value ) /*0x141041387*/
    {
      v189 = DFInt::SendAvatarLoadTimeStats_HundredthsPercentage; /*0x14104138d*/
      if ( DFString::SendAvatarLoadTimeStatsHundPrecCountryOverride._Mypair._Myval2._Mysize != 0 ) /*0x14104139c*/
      {
        v190 = std::string::string(this: &v278, _Ptr: ","); /*0x1410413ac*/
        __wind /*0xf1c000000000001c*/
        {
          v191 = RBX::Network::getPairIntValue( /*0x1410413c8*/
                   target: &RBX::Analytics::location,
                   from: &DFString::SendAvatarLoadTimeStatsHundPrecCountryOverride,
                   delimiters: v190);
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v278); /*0x1410413d1*/
          if ( v191 != -1 ) /*0x1410413d9*/
            v189 = v191; /*0x1410413d9*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v278); /*0xf1c0000000000014*/
        }
      }
      if ( rand() % 10000 < v189 ) /*0x141041407*/
        reportPlaceSpecificAvatarLoadTimeStats(sgs: &this->sgs); /*0x14104140d*/
    }
    if ( FFlag::LogJoinTime.value && FLog::JoinTimeLog != 0 )
    {
      FLog::FastLog(level: FLog::JoinTimeLog, message: "[FLog::JoinTimeLog] ======== Join Times =======", arg0: nullptr); /*0x141041438*/
      if ( FLog::JoinTimeLog != 0 )
      {
        v192 = this->sgs.videoAdFinishedTime; /*0x141041451*/
        FLog::FastLogF(
          channel: FLog::JoinTimeLog,
          message: "[FLog::JoinTimeLog] VideoAdFinishedTime   : %.4f",
          arg1: v192,
          arg2: 0.0,
          arg3: 0.0,
          arg4: 0.0);
        if ( FLog::JoinTimeLog != 0 )
        {
          v193 = this->sgs.startGameTime; /*0x14104148a*/
          FLog::FastLogF(
            channel: FLog::JoinTimeLog,
            message: "[FLog::JoinTimeLog] StartGameTime         : %.4f",
            arg1: v193,
            arg2: 0.0,
            arg3: 0.0,
            arg4: 0.0);
          if ( FLog::JoinTimeLog != 0 )
          {
            v194 = this->sgs.placelauncherStartTime; /*0x1410414c0*/
            FLog::FastLogF(
              channel: FLog::JoinTimeLog,
              message: "[FLog::JoinTimeLog] PlacelauncherStartTime: %.4f",
              arg1: v194,
              arg2: 0.0,
              arg3: 0.0,
              arg4: 0.0);
            if ( FLog::JoinTimeLog != 0 )
            {
              v195 = this->sgs.fetchedJoinScriptTime; /*0x1410414f6*/
              FLog::FastLogF(
                channel: FLog::JoinTimeLog,
                message: "[FLog::JoinTimeLog] FetchedJoinScriptTime : %.4f",
                arg1: v195,
                arg2: 0.0,
                arg3: 0.0,
                arg4: 0.0);
              if ( FLog::JoinTimeLog != 0 )
              {
                v196 = this->sgs.playerConfigureTime; /*0x14104152c*/
                FLog::FastLogF(
                  channel: FLog::JoinTimeLog,
                  message: "[FLog::JoinTimeLog] PlayerConfigureTime   : %.4f",
                  arg1: v196,
                  arg2: 0.0,
                  arg3: 0.0,
                  arg4: 0.0);
                if ( FLog::JoinTimeLog != 0 )
                {
                  v197 = this->sgs.connectTime; /*0x141041562*/
                  FLog::FastLogF(
                    channel: FLog::JoinTimeLog,
                    message: "[FLog::JoinTimeLog] ConnectTime           : %.4f",
                    arg1: v197,
                    arg2: 0.0,
                    arg3: 0.0,
                    arg4: 0.0);
                  if ( FLog::JoinTimeLog != 0 )
                  {
                    v198 = this->sgs.receivedGlobalsTime; /*0x141041598*/
                    FLog::FastLogF(
                      channel: FLog::JoinTimeLog,
                      message: "[FLog::JoinTimeLog] ReceivedGlobalsTime   : %.4f",
                      arg1: v198,
                      arg2: 0.0,
                      arg3: 0.0,
                      arg4: 0.0);
                    if ( FLog::JoinTimeLog != 0 )
                    {
                      v199 = this->sgs.gameLoadTime; /*0x1410415ce*/
                      FLog::FastLogF(
                        channel: FLog::JoinTimeLog,
                        message: "[FLog::JoinTimeLog] GameLoadTime          : %.4f",
                        arg1: v199,
                        arg2: 0.0,
                        arg3: 0.0,
                        arg4: 0.0);
                      if ( FLog::JoinTimeLog != 0 )
                      {
                        v200 = this->sgs.gameJoinTime; /*0x141041604*/
                        FLog::FastLogF(
                          channel: FLog::JoinTimeLog,
                          message: "[FLog::JoinTimeLog] GameJoinTime          : %.4f",
                          arg1: v200,
                          arg2: 0.0,
                          arg3: 0.0,
                          arg4: 0.0);
                        if ( FLog::JoinTimeLog != 0 )
                        {
                          v201 = *p_avatarLoadTime; /*0x141041636*/
                          FLog::FastLogF(
                            channel: FLog::JoinTimeLog,
                            message: "[FLog::JoinTimeLog] AvatarLoadTime        : %.4f",
                            arg1: v201,
                            arg2: 0.0,
                            arg3: 0.0,
                            arg4: 0.0);
                          if ( FLog::JoinTimeLog != 0 )
                          {
                            v202 = *p_avatarLoadTime; /*0x141041668*/
                            v203 = this->sgs.connectTime; /*0x141041674*/
                            FLog::FastLogF(
                              channel: FLog::JoinTimeLog,
                              message: "[FLog::JoinTimeLog] Connect-Ava           : %.4f",
                              arg1: v202 - v203,
                              arg2: 0.0,
                              arg3: 0.0,
                              arg4: 0.0);
                            if ( FLog::JoinTimeLog != 0 )
                            {
                              FLog::FastLog( /*0x1410416b0*/
                                level: FLog::JoinTimeLog,
                                message: "[FLog::JoinTimeLog] ======== Join Times (Delta) =======",
                                arg0: nullptr);
                              if ( FLog::JoinTimeLog != 0 )
                              {
                                v204 = this->sgs.startGameTime; /*0x1410416cc*/
                                FLog::FastLogF(
                                  channel: FLog::JoinTimeLog,
                                  message: "[FLog::JoinTimeLog] UserClickToStartGameTime        : %.4f",
                                  arg1: v204,
                                  arg2: 0.0,
                                  arg3: 0.0,
                                  arg4: 0.0);
                                if ( FLog::JoinTimeLog != 0 )
                                {
                                  v205 = this->sgs.placelauncherStartTime - this->sgs.startGameTime; /*0x14104170a*/
                                  FLog::FastLogF(
                                    channel: FLog::JoinTimeLog,
                                    message: "[FLog::JoinTimeLog] StartGameToPlacelauncherStart   : %.4f",
                                    arg1: v205,
                                    arg2: 0.0,
                                    arg3: 0.0,
                                    arg4: 0.0);
                                  if ( FLog::JoinTimeLog != 0 )
                                  {
                                    v206 = this->sgs.fetchedJoinScriptTime - this->sgs.placelauncherStartTime; /*0x141041748*/
                                    FLog::FastLogF(
                                      channel: FLog::JoinTimeLog,
                                      message: "[FLog::JoinTimeLog] PlacelauncherStartToJoinScript  : %.4f",
                                      arg1: v206,
                                      arg2: 0.0,
                                      arg3: 0.0,
                                      arg4: 0.0);
                                    if ( FLog::JoinTimeLog != 0 )
                                    {
                                      v207 = this->sgs.playerConfigureTime - this->sgs.fetchedJoinScriptTime; /*0x141041786*/
                                      FLog::FastLogF(
                                        channel: FLog::JoinTimeLog,
                                        message: "[FLog::JoinTimeLog] FetchedScriptToPlayerConfTime   : %.4f",
                                        arg1: v207,
                                        arg2: 0.0,
                                        arg3: 0.0,
                                        arg4: 0.0);
                                      if ( FLog::JoinTimeLog != 0 )
                                      {
                                        v208 = this->sgs.connectTime - this->sgs.playerConfigureTime; /*0x1410417c4*/
                                        FLog::FastLogF(
                                          channel: FLog::JoinTimeLog,
                                          message: "[FLog::JoinTimeLog] PlayerConfigToConnectTime       : %.4f",
                                          arg1: v208,
                                          arg2: 0.0,
                                          arg3: 0.0,
                                          arg4: 0.0);
                                        if ( FLog::JoinTimeLog != 0 )
                                        {
                                          v209 = this->sgs.receivedGlobalsTime - this->sgs.connectTime; /*0x141041802*/
                                          FLog::FastLogF(
                                            channel: FLog::JoinTimeLog,
                                            message: "[FLog::JoinTimeLog] ConnectToReceivedGlobalsTime    : %.4f",
                                            arg1: v209,
                                            arg2: 0.0,
                                            arg3: 0.0,
                                            arg4: 0.0);
                                          if ( FLog::JoinTimeLog != 0 )
                                          {
                                            v210 = this->sgs.gameLoadTime - this->sgs.receivedGlobalsTime; /*0x141041840*/
                                            FLog::FastLogF(
                                              channel: FLog::JoinTimeLog,
                                              message: "[FLog::JoinTimeLog] ReceivedGlobalToGameLoadTime    : %.4f",
                                              arg1: v210,
                                              arg2: 0.0,
                                              arg3: 0.0,
                                              arg4: 0.0);
                                            if ( FLog::JoinTimeLog != 0 )
                                            {
                                              v211 = this->sgs.gameJoinTime - this->sgs.gameLoadTime; /*0x14104187a*/
                                              FLog::FastLogF(
                                                channel: FLog::JoinTimeLog,
                                                message: "[FLog::JoinTimeLog] GameLoadToGameJoinTime          : %.4f",
                                                arg1: v211,
                                                arg2: 0.0,
                                                arg3: 0.0,
                                                arg4: 0.0);
                                              if ( FLog::JoinTimeLog != 0 )
                                              {
                                                v212 = *p_avatarLoadTime - this->sgs.gameJoinTime; /*0x1410418b0*/
                                                FLog::FastLogF(
                                                  channel: FLog::JoinTimeLog,
                                                  message: "[FLog::JoinTimeLog] GameJoinToAvatarLoadTime        : %.4f",
                                                  arg1: v212,
                                                  arg2: 0.0,
                                                  arg3: 0.0,
                                                  arg4: 0.0);
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  __unwind
  {
    RBX::AvatarMetrics::~AvatarMetrics(this: &metrics); /*0xf1c0000000000008*/
  }
LABEL_252:
  RBX::AvatarMetrics::~AvatarMetrics(this: &metrics); /*0x1410418d7*/
}

// Address: 0x141041900 | Name: ?onAvatarTextureEnded@PlayerConfigurer@RBX@@AEAAXPEAVHumanoid@2@N@Z
void __fastcall RBX::PlayerConfigurer::onAvatarTextureEnded(
        RBX::PlayerConfigurer *this,
        RBX::Humanoid *humanoid,
        long double time)
{
  RBX::ModelInstance *LocalCharacter; // rax
  bool v7; // r12
  __int64 v8; // rbx
  unsigned __int64 v9; // r14
  unsigned __int64 v10; // r15
  __int64 UserId; // rbx
  RBX::Graphics::ProfilerAdorn::Item *Ptr; // r8
  char *v13; // rcx
  __int64 v14; // rcx
  __int64 v15; // [rsp+0h] [rbp-B8h] BYREF
  RBX::Profiler::Scope profscope1931; // [rsp+40h] [rbp-78h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v17; // [rsp+50h] [rbp-68h] BYREF
  bool v18; // [rsp+C8h] [rbp+10h]

  if ( FLog::AvatarJoinMetrics != 0 ) /*0x141041939*/
    FLog::FastLogFormatted( /*0x141041947*/
      level: FLog::AvatarJoinMetrics,
      message: "[FLog::AvatarJoinMetrics] TC ended on humanoid %p",
      humanoid);
  v18 = humanoid->clusterCreationTimes[1] > 0.0; /*0x14104195b*/
  LocalCharacter = RBX::Players::findLocalCharacter(context: humanoid); /*0x141041966*/
  v7 = humanoid->parent == LocalCharacter; /*0x14104196f*/
  if ( (humanoid->parent == LocalCharacter /*0x1410419a1*/
     || FFlag::PlayerConfigurer2759.value && FFlag::DebugPlayerConfigurerOthersMetrics.value)
    && humanoid->textureCompositionTimes[1] == 0.0 )
  {
    v8 = *((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index); /*0x1410419bb*/
    if ( _TSS0_522 > *(_DWORD *)(v8 + 260) ) /*0x1410419c8*/
    {
      __wind /*0xf1c0000000000024*/
      {
        Init_thread_header(pOnce: &_TSS0_522); /*0x141041b4f*/
        if ( _TSS0_522 == -1 ) /*0x141041b5b*/
        {
          proftoken1931 = RBX::Profiler::getToken(group: "Avatar", name: "onAvatarTextureEnded", color: -1); /*0x141041b7a*/
          Init_thread_footer(pOnce: &_TSS0_522); /*0x141041b88*/
        }
      }
      __unwind
      {
        Init_thread_abort(pOnce: &_TSS0_522); /*0x1431e7c77*/
      }
    }
    v9 = proftoken1931; /*0x1410419ce*/
    profscope1931.region.token = proftoken1931; /*0x1410419d5*/
    v10 = RBX::Profiler::enterRegion(token: proftoken1931); /*0x1410419e2*/
    profscope1931.region.timestamp = v10; /*0x1410419e5*/
    __wind /*0xf1c0000000000078*/
    {
      if ( _TSS1_106 > *(_DWORD *)(v8 + 260) ) /*0x1410419f3*/
      {
        __wind /*0xf1c000000000003c*/
        {
          Init_thread_header(pOnce: &_TSS1_106); /*0x141041b12*/
          if ( _TSS1_106 == -1 ) /*0x141041b1e*/
          {
            proflabeltoken_36 = RBX::Profiler::getLabelToken(group: "Avatar"); /*0x141041b30*/
            Init_thread_footer(pOnce: &_TSS1_106); /*0x141041b3e*/
          }
        }
        __unwind
        {
          Init_thread_abort(pOnce: &_TSS1_106); /*0x1431e7c87*/
        }
      }
      UserId = RBX::Humanoid::getUserId(this: humanoid, forceUpdate: false); /*0x141041a21*/
      std::string::string( /*0x141041a34*/
        this: (rtc::webrtc_checks_impl::ToStringVal *)&v17,
        __that: (const rtc::webrtc_checks_impl::ToStringVal *)&humanoid->displayName);
      __wind /*0xf1c000000000006c*/
      {
        Ptr = &v17; /*0x141041a3a*/
        if ( v17.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141041a45*/
          Ptr = (RBX::Graphics::ProfilerAdorn::Item *)v17.text._Mypair._Myval2._Bx._Ptr; /*0x141041a45*/
        RBX::Profiler::addLabelFormat( /*0x141041a6c*/
          token: proflabeltoken_36,
          name: "Player:%s,local:%d,id:%lld,time:%.3f,key:%p",
          Ptr->text._Mypair._Myval2._Bx._Buf,
          v7,
          UserId,
          (double)time,
          (const void *)(0x85FDB20E1294309AuLL - 0x3AE910A3C8B9DB97LL * (_QWORD)humanoid));
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v17); /*0xf1c0000000000064*/
      }
      if ( v17.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141041a7b*/
      {
        v13 = v17.text._Mypair._Myval2._Bx._Ptr; /*0x141041a80*/
        if ( v17.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141041a8f*/
        {
          v13 = *((char **)v17.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141041a95*/
          if ( (unsigned __int64)(v17.text._Mypair._Myval2._Bx._Ptr - v13 - 8) > 0x1F ) /*0x141041aa4*/
            _invalid_parameter_noinfo_noreturn(); /*0x141041aa6*/
        }
        operator delete(ptr: v13); /*0x141041aad*/
      }
    }
    __unwind
    {
      RBX::Profiler::Scope::~Scope(this: &profscope1931); /*0xf1c0000000000088*/
    }
    __wind /*0xf1c0000000000090*/
    {
      RBX::Profiler::leaveRegion(token: v9, enterTimestamp: v10); /*0x141041ab9*/
    }
    __unwind
    {
      __std_terminate(a1: v14, a2: &v15); /*0x142f39fa8*/
    }
    humanoid->textureCompositionTimes[1] = time; /*0x141041abf*/
    if ( v18 ) /*0x141041acf*/
      RBX::PlayerConfigurer::onAvatarCompletion(this, (RBX::ServiceProvider *)humanoid, isLocalPlayer: v7); /*0x141041adb*/
  }
}

// Address: 0x141041ba0 | Name: ?onAvatarTextureStarted@PlayerConfigurer@RBX@@AEAAXPEAVHumanoid@2@N@Z
void __fastcall RBX::PlayerConfigurer::onAvatarTextureStarted(
        RBX::PlayerConfigurer *this,
        RBX::Humanoid *humanoid,
        long double time)
{
  RBX::ModelInstance *LocalCharacter; // rax
  bool v6; // di
  __int64 v7; // rbx
  unsigned __int64 v8; // r14
  unsigned __int64 v9; // r15
  __int64 UserId; // rbx
  RBX::Graphics::ProfilerAdorn::Item *Ptr; // r8
  char *v12; // rcx
  __int64 v13; // rcx
  __int64 v14; // [rsp+0h] [rbp-98h] BYREF
  RBX::Profiler::Scope profscope1911; // [rsp+40h] [rbp-58h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v16; // [rsp+50h] [rbp-48h] BYREF

  if ( FLog::AvatarJoinMetrics != 0 ) /*0x141041bcf*/
    FLog::FastLogFormatted( /*0x141041bdd*/
      level: FLog::AvatarJoinMetrics,
      message: "[FLog::AvatarJoinMetrics] TC started on humanoid %p",
      humanoid);
  LocalCharacter = RBX::Players::findLocalCharacter(context: humanoid); /*0x141041be5*/
  v6 = humanoid->parent == LocalCharacter; /*0x141041bee*/
  if ( (humanoid->parent == LocalCharacter /*0x141041c23*/
     || FFlag::PlayerConfigurer2759.value && FFlag::DebugPlayerConfigurerOthersMetrics.value)
    && humanoid->textureCompositionTimes[0] == 0.0 )
  {
    v7 = *((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index); /*0x141041c3d*/
    if ( _TSS0_521 > *(_DWORD *)(v7 + 260) ) /*0x141041c4a*/
    {
      __wind /*0xf1c0000000000024*/
      {
        Init_thread_header(pOnce: &_TSS0_521); /*0x141041daf*/
        if ( _TSS0_521 == -1 ) /*0x141041dbb*/
        {
          proftoken1911 = RBX::Profiler::getToken(group: "Avatar", name: "onAvatarTextureStarted", color: -1); /*0x141041dda*/
          Init_thread_footer(pOnce: &_TSS0_521); /*0x141041de8*/
        }
      }
      __unwind
      {
        Init_thread_abort(pOnce: &_TSS0_521); /*0x1431e7c97*/
      }
    }
    v8 = proftoken1911; /*0x141041c50*/
    profscope1911.region.token = proftoken1911; /*0x141041c57*/
    v9 = RBX::Profiler::enterRegion(token: proftoken1911); /*0x141041c64*/
    profscope1911.region.timestamp = v9; /*0x141041c67*/
    __wind /*0xf1c0000000000078*/
    {
      if ( _TSS1_105 > *(_DWORD *)(v7 + 260) ) /*0x141041c75*/
      {
        __wind /*0xf1c000000000003c*/
        {
          Init_thread_header(pOnce: &_TSS1_105); /*0x141041d72*/
          if ( _TSS1_105 == -1 ) /*0x141041d7e*/
          {
            proflabeltoken_35 = RBX::Profiler::getLabelToken(group: "Avatar"); /*0x141041d90*/
            Init_thread_footer(pOnce: &_TSS1_105); /*0x141041d9e*/
          }
        }
        __unwind
        {
          Init_thread_abort(pOnce: &_TSS1_105); /*0x1431e7ca7*/
        }
      }
      UserId = RBX::Humanoid::getUserId(this: humanoid, forceUpdate: false); /*0x141041ca3*/
      std::string::string( /*0x141041cb6*/
        this: (rtc::webrtc_checks_impl::ToStringVal *)&v16,
        __that: (const rtc::webrtc_checks_impl::ToStringVal *)&humanoid->displayName);
      __wind /*0xf1c000000000006c*/
      {
        Ptr = &v16; /*0x141041cbc*/
        if ( v16.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141041cc7*/
          Ptr = (RBX::Graphics::ProfilerAdorn::Item *)v16.text._Mypair._Myval2._Bx._Ptr; /*0x141041cc7*/
        RBX::Profiler::addLabelFormat( /*0x141041cee*/
          token: proflabeltoken_35,
          name: "Player:%s,local:%d,id:%lld,time:%.3f,key:%p",
          Ptr->text._Mypair._Myval2._Bx._Buf,
          v6,
          UserId,
          (double)time,
          (const void *)(0x85FDB20E1294309AuLL - 0x3AE910A3C8B9DB97LL * (_QWORD)humanoid));
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v16); /*0xf1c0000000000064*/
      }
      if ( v16.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141041cfd*/
      {
        v12 = v16.text._Mypair._Myval2._Bx._Ptr; /*0x141041d02*/
        if ( v16.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141041d11*/
        {
          v12 = *((char **)v16.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141041d17*/
          if ( (unsigned __int64)(v16.text._Mypair._Myval2._Bx._Ptr - v12 - 8) > 0x1F ) /*0x141041d26*/
            _invalid_parameter_noinfo_noreturn(); /*0x141041d28*/
        }
        operator delete(ptr: v12); /*0x141041d2f*/
      }
    }
    __unwind
    {
      RBX::Profiler::Scope::~Scope(this: &profscope1911); /*0xf1c0000000000088*/
    }
    __wind /*0xf1c0000000000090*/
    {
      RBX::Profiler::leaveRegion(token: v8, enterTimestamp: v9); /*0x141041d3b*/
      humanoid->textureCompositionTimes[0] = time; /*0x141041d41*/
    }
    __unwind
    {
      __std_terminate(a1: v13, a2: &v14); /*0x142f39fa8*/
    }
  }
}

// Address: 0x141041e00 | Name: ?onConnectionAccepted@PlayerConfigurer@RBX@@AEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@AEBV?$shared_ptr@VInstance@RBX@@@4@@Z
void __fastcall RBX::PlayerConfigurer::onConnectionAccepted(
        RBX::PlayerConfigurer *this,
        const std::string *__formal,
        const std::shared_ptr<RBX::Instance> *replicator)
{
  RBX::PlayerConfigurer *v4; // r14
  double v5; // xmm0_8
  double v6; // xmm6_8
  long double v7; // xmm3_8
  void *v8; // rcx
  char *Ptr; // rcx
  RBX::InferredCrash *Instance; // rax
  bool *v11; // rax
  bool *v12; // r13
  RBX::File *v13; // rax
  RBX::File *v14; // rdi
  RBX::Visit *v15; // rax
  RBX::Visit *v16; // rsi
  int ParamInt; // eax
  int v18; // r15d
  std::string *ParamString; // rax
  char *v20; // rcx
  char *v21; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rsi
  RBX::Reflection::ClassDescriptor *v23; // rax
  unsigned int v24; // edx
  RBX::Network::ClientReplicator *v25; // r12
  std::_Ref_count_base *v26; // rax
  unsigned int *p_color; // rcx
  signed __int32 v28; // eax
  volatile signed __int32 *v29; // rbx
  signed __int32 v30; // eax
  signed __int32 v31; // eax
  volatile signed __int32 *v32; // rbx
  signed __int32 v33; // eax
  std::vector<rbx::signals::connection> *p_connections; // rsi
  __int128 v35; // xmm6
  unsigned int v36; // eax
  unsigned int parent; // ebx
  char *v38; // rax
  rbx::signals::slot_base *v39; // r12
  rbx::signals::signal_base *v40; // rcx
  __int64 v41; // rcx
  rbx::signals::connection *Mylast; // rdx
  rbx::signals::slot_base *p; // rax
  rbx::signals::slot_base *v44; // rbx
  rbx::signals::connection *v45; // rax
  rbx::signals::connection *v46; // rdx
  void *v47; // rcx
  rbx::signals::connection *v48; // rax
  rbx::signals::connection *v49; // rdx
  void *v50; // rcx
  RBX::Graphics::ProfilerAdorn::Item *v51; // rax
  unsigned int v52; // eax
  unsigned int v53; // ebx
  char *v54; // rax
  rbx::signals::slot_base *v55; // r12
  rbx::signals::signal_base *v56; // rcx
  RBX::Graphics::ProfilerAdorn::Item *v57; // rdx
  __int64 v58; // rcx
  rbx::signals::connection *v59; // rdx
  rbx::signals::slot_base *v60; // rax
  std::_Ref_count_base *v61; // rbx
  RBX::ReplicatedFirst *v62; // rax
  rbx::signals::signal_base *p_defaultLoadingGuiRemovedSignal; // r12
  unsigned int v64; // eax
  unsigned int v65; // ebx
  rbx::signals::slot_base *v66; // rax
  rbx::signals::slot_base *v67; // rsi
  __int64 v68; // rcx
  volatile signed __int32 *v69; // rcx
  RBX::TimerService *v70; // rax
  RBX::TimerService *v71; // rbx
  std::weak_ptr<RBX::DataModel> *v72; // rax
  boost::_bi::bind_t<void,void (__cdecl*)(std::weak_ptr<RBX::DataModel>,std::shared_ptr<bool>),boost::_bi::list2<boost::_bi::value<std::weak_ptr<RBX::DataModel> >,boost::_bi::value<std::shared_ptr<bool> > > > *v73; // rax
  std::function<void __cdecl(void)> *v74; // rax
  std::exception *v75; // rdi
  const char *v76; // rax
  std::string *v77; // rbx
  const char *v78; // rax
  const char *v79; // rax
  unsigned __int64 v80; // r8
  char *v81; // rcx
  void *v82; // rcx
  _BYTE v83[32]; // [rsp+0h] [rbp-3C8h] BYREF
  rbx::signals::signal_base *p_disconnectionSignal; // [rsp+20h] [rbp-3A8h]
  rbx::signals::connection v85; // [rsp+28h] [rbp-3A0h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *v86; // [rsp+30h] [rbp-398h]
  __int128 v87; // [rsp+40h] [rbp-388h]
  rbx::signals::connection v88; // [rsp+50h] [rbp-378h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v89; // [rsp+58h] [rbp-370h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v90; // [rsp+5Ch] [rbp-36Ch] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v91; // [rsp+60h] [rbp-368h] BYREF
  std::shared_ptr<RBX::File> v92; // [rsp+68h] [rbp-360h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v93; // [rsp+78h] [rbp-350h] BYREF
  unsigned __int64 category_24; // [rsp+B0h] [rbp-318h]
  RBX::Graphics::ProfilerAdorn::Item category_32; // [rsp+B8h] [rbp-310h] BYREF
  volatile signed __int32 *v96; // [rsp+F0h] [rbp-2D8h]
  char v97; // [rsp+F8h] [rbp-2D0h] BYREF
  volatile signed __int32 *v98; // [rsp+100h] [rbp-2C8h]
  RBX::Graphics::ProfilerAdorn::Item result; // [rsp+108h] [rbp-2C0h] BYREF
  RBX::File *v100; // [rsp+140h] [rbp-288h]
  RBX::Graphics::ProfilerAdorn::Item key; // [rsp+148h] [rbp-280h] BYREF
  unsigned __int64 v102; // [rsp+180h] [rbp-248h]
  std::string v103; // [rsp+188h] [rbp-240h] BYREF
  std::string v104; // [rsp+1A8h] [rbp-220h] BYREF
  std::shared_ptr<RBX::Network::ClientReplicator> rep; // [rsp+1C8h] [rbp-200h] BYREF
  std::string v106; // [rsp+1D8h] [rbp-1F0h] BYREF
  std::string v107; // [rsp+1F8h] [rbp-1D0h] BYREF
  std::string v108; // [rsp+218h] [rbp-1B0h] BYREF
  std::shared_ptr<bool> waitingForMarker; // [rsp+238h] [rbp-190h] BYREF
  __int128 v110[2]; // [rsp+250h] [rbp-178h] BYREF
  RBX::PlayerConfigurer *v111; // [rsp+270h] [rbp-158h]
  boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::PlayerConfigurer>,boost::_bi::list1<boost::_bi::value<RBX::PlayerConfigurer *> > > function; // [rsp+278h] [rbp-150h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::PlayerConfigurer>,boost::_bi::list1<boost::_bi::value<RBX::PlayerConfigurer *> > > v113; // [rsp+290h] [rbp-138h] BYREF
  std::_Temporary_owner<bool> v114; // [rsp+2A8h] [rbp-120h] BYREF
  rbx::signals::slot_base *v115; // [rsp+2B0h] [rbp-118h] BYREF
  std::exception *e; // [rsp+2B8h] [rbp-110h] BYREF
  std::string v117; // [rsp+2C0h] [rbp-108h] BYREF
  std::string v118; // [rsp+2E0h] [rbp-E8h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::PlayerConfigurer,std::shared_ptr<bool> >,boost::_bi::list2<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::shared_ptr<bool> > > > v119; // [rsp+300h] [rbp-C8h] BYREF
  boost::_bi::bind_t<void,void (__cdecl*)(std::weak_ptr<RBX::DataModel>,std::shared_ptr<bool>),boost::_bi::list2<boost::_bi::value<std::weak_ptr<RBX::DataModel> >,boost::_bi::value<std::shared_ptr<bool> > > > v120; // [rsp+328h] [rbp-A0h] BYREF
  std::function<void __cdecl(void)> v121; // [rsp+350h] [rbp-78h] BYREF
  char v123; // [rsp+3E8h] [rbp+20h]
  char v124; // [rsp+3E8h] [rbp+20h]
  char v125; // [rsp+3E8h] [rbp+20h]
  char v126; // [rsp+3E8h] [rbp+20h]
  char v127; // [rsp+3E8h] [rbp+20h]
  char v128; // [rsp+3E8h] [rbp+20h]

  v4 = this; /*0x141041e26*/
  this->connectResolved = true; /*0x141041e30*/
  v5 = RBX::Time::nowFastSec(); /*0x141041e34*/
  __wind /*0xf1c00000000002e8*/
  {
    __wind /*0xf1c00000000002f0*/
    {
      v6 = v5; /*0x141041e39*/
      v7 = v5 - v4->sgs.avatarConfigureTime; /*0x141041e3f*/
      result.text._Mypair._Myval2._Myres = 15; /*0x141041e50*/
      result.text._Mypair._Myval2._Mysize = 7; /*0x141041e5c*/
      strcpy(result.text._Mypair._Myval2._Bx._Buf, "Success"); /*0x141041e6e*/
      category_24 = 15; /*0x141041e9a*/
      *(_QWORD *)&v93.color = 11; /*0x141041ea6*/
      qmemcpy(&v93.x, "GameConnec", 10); /*0x141041eba*/
      HIWORD(v93.width) = (unsigned __int8)aGameconnect[10]; /*0x141041ed9*/
      RBX::PlayerConfigurer::reportDuration( /*0x141041efb*/
        this: v4,
        category: (const std::string *)&v93.x,
        result: &result.text,
        duration: v7);
      if ( category_24 >= 0x10 ) /*0x141041f0d*/
      {
        v8 = *(void **)&v93.x; /*0x141041f12*/
        if ( category_24 + 1 >= 0x1000 ) /*0x141041f24*/
        {
          v8 = *(void **)(*(_QWORD *)&v93.x - 8LL); /*0x141041f2a*/
          if ( (unsigned __int64)(*(_QWORD *)&v93.x - (_QWORD)v8 - 8LL) > 0x1F ) /*0x141041f39*/
            _invalid_parameter_noinfo_noreturn(); /*0x141041f3b*/
        }
        operator delete(ptr: v8); /*0x141041f42*/
      }
      *(_QWORD *)&v93.color = 0; /*0x141041f47*/
      category_24 = 15; /*0x141041f4f*/
      LOBYTE(v93.x) = 0; /*0x141041f5b*/
      if ( result.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141041f6f*/
      {
        Ptr = result.text._Mypair._Myval2._Bx._Ptr; /*0x141041f74*/
        if ( result.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141041f86*/
        {
          Ptr = *((char **)result.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141041f8c*/
          if ( (unsigned __int64)(result.text._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141041f9b*/
            _invalid_parameter_noinfo_noreturn(); /*0x141041f9d*/
        }
        operator delete(ptr: Ptr); /*0x141041fa4*/
      }
      v4->sgs.connectTime = v6 - v4->sgs.userClickTime; /*0x141041faf*/
      if ( DFFlag::ReportFailuresInClientJoinAll2.value ) /*0x141041fbf*/
        v4->sgs.joinPhase = JoinPhase_Connected; /*0x141041fc1*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v93.x); /*0xf1c00000000002d4*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: &result); /*0xf1c00000000002e0*/
  }
  if ( DFFlag::SessionTrackingFlushAtImportantCheckpoints.value ) /*0x141041fd3*/
  {
    Instance = RBX::InferredCrash::getInstance(); /*0x141041fd5*/
    RBX::InferredCrash::onGameConnected(this: Instance, gameConnectedTime: v4->sgs.connectTime); /*0x141041fe6*/
  }
  v11 = (bool *)operator new(size: 1u); /*0x141041ff0*/
  v12 = v11; /*0x141041ff5*/
  if ( v11 != nullptr ) /*0x141041ffb*/
    *v11 = true; /*0x141041ffd*/
  else
    v12 = nullptr; /*0x141042002*/
  *(_QWORD *)&category_32.x = v12; /*0x141042005*/
  v114._Ptr = v12; /*0x14104200d*/
  __wind /*0xf1c000000000026c*/
  {
    v13 = (RBX::File *)operator new(size: 0x18u); /*0x14104201a*/
    v14 = v13; /*0x14104201f*/
    v86 = (RBX::Graphics::ProfilerAdorn::Item *)v13; /*0x141042022*/
    if ( v13 != nullptr ) /*0x14104202a*/
    {
      *(_OWORD *)&v13->__vftable = 0; /*0x14104202f*/
      LODWORD(v13->_Wptr._Ptr) = 1; /*0x141042032*/
      HIDWORD(v13->_Wptr._Ptr) = 1; /*0x141042039*/
      v13->__vftable = (RBX::File_vtbl *)std::_Ref_count<bool>::`vftable'; /*0x141042047*/
      v13->_Wptr._Rep = (std::_Ref_count_base *)v12; /*0x14104204a*/
    }
    else
    {
      v14 = nullptr; /*0x141042050*/
    }
    v92._Ptr = v14; /*0x141042053*/
    waitingForMarker._Ptr = v12; /*0x141042058*/
    waitingForMarker._Rep = (std::_Ref_count_base *)v14; /*0x141042060*/
  }
  __unwind
  {
    std::_Temporary_owner<RBX::LinkingProtocol::ImplData>::~_Temporary_owner<RBX::LinkingProtocol::ImplData>(this: &v114); /*0xf1c0000000000264*/
  }
  operator delete(ptr: nullptr); /*0x14104206f*/
  __wind
  {
    try
    {
      if ( !v4->testing ) /*0x14104207a*/
      {
        v15 = RBX::ServiceProvider::create<RBX::Visit>(this: &v4->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x141042088*/
        __wind /*0xf1c0000000000254*/
        {
          v16 = v15; /*0x14104208d*/
          key.text._Mypair._Myval2._Myres = 15; /*0x141042090*/
          key.text._Mypair._Myval2._Mysize = 12; /*0x14104209c*/
          strcpy(key.text._Mypair._Myval2._Bx._Buf, "PingInterval"); /*0x1410420b0*/
          ParamInt = RBX::GameConfigurer::getParamInt(this: v4, key: &key.text); /*0x1410420d9*/
          __wind /*0xf1c0000000000248*/
          {
            v18 = ParamInt; /*0x1410420de*/
            v93.text._Mypair._Myval2._Myres = 15; /*0x1410420ea*/
            v93.text._Mypair._Myval2._Mysize = 7; /*0x1410420f6*/
            qmemcpy(&v93, "PingUr", 6); /*0x141042108*/
            *(_WORD *)&v93.text._Mypair._Myval2._Bx._Alias[6] = (unsigned __int8)aPingurl[6]; /*0x14104211f*/
            ParamString = RBX::GameConfigurer::getParamString(this: v4, result: &v117, key: &v93.text); /*0x141042138*/
            RBX::Visit::setPing(this: v16, url: ParamString, interval: v18); /*0x141042146*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v93); /*0xf1c0000000000240*/
          }
          if ( v93.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141042158*/
          {
            v20 = v93.text._Mypair._Myval2._Bx._Ptr; /*0x14104215d*/
            if ( v93.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104216c*/
            {
              v20 = *((char **)v93.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141042172*/
              if ( (unsigned __int64)(v93.text._Mypair._Myval2._Bx._Ptr - v20 - 8) > 0x1F ) /*0x141042181*/
                _invalid_parameter_noinfo_noreturn(); /*0x141042183*/
            }
            operator delete(ptr: v20); /*0x14104218a*/
          }
          v93.text._Mypair._Myval2._Mysize = 0; /*0x141042192*/
          v93.text._Mypair._Myval2._Myres = 15; /*0x14104219a*/
          v93.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410421a6*/
          if ( key.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410421b7*/
          {
            v21 = key.text._Mypair._Myval2._Bx._Ptr; /*0x1410421bc*/
            if ( key.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410421ce*/
            {
              v21 = *((char **)key.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410421d4*/
              if ( (unsigned __int64)(key.text._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x1410421e3*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410421e5*/
            }
            operator delete(ptr: v21); /*0x1410421ec*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &key); /*0xf1c0000000000234*/
        }
      }
      if ( replicator->_Ptr != nullptr /*0x14104221b*/
        && (descriptor = replicator->_Ptr->descriptor,
            v23 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(),
            v24 = descriptor->index - v23->index,
            LODWORD(v23) = v23->descendantCount,
            v24 <= (unsigned int)v23) )
      {
        v25 = (RBX::Network::ClientReplicator *)replicator->_Ptr; /*0x14104221d*/
        v85.weak_slot.p_ = (rbx::signals::slot_base *)replicator->_Ptr; /*0x141042220*/
        v26 = replicator->_Rep; /*0x141042225*/
        if ( v26 != nullptr ) /*0x14104222c*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v26->_Uses); /*0x14104222e*/
          v26 = replicator->_Rep; /*0x141042232*/
        }
        v96 = (volatile signed __int32 *)v26; /*0x141042236*/
        p_color = &category_32.color; /*0x14104223e*/
        v123 = 1; /*0x141042246*/
      }
      else
      {
        v98 = nullptr; /*0x141042253*/
        p_color = (unsigned int *)&v97; /*0x14104225b*/
        v123 = 2; /*0x141042263*/
        v25 = nullptr; /*0x14104226e*/
        v85.weak_slot.p_ = nullptr; /*0x141042271*/
      }
      rep._Ptr = v25; /*0x141042276*/
      rep._Rep = *((std::_Ref_count_base **)p_color + 1); /*0x141042282*/
      *(_QWORD *)p_color = 0; /*0x14104228a*/
      *((_QWORD *)p_color + 1) = 0; /*0x14104228d*/
      v124 = v123 | 4; /*0x14104229b*/
      if ( (v124 & 2) != 0 ) /*0x1410422a4*/
      {
        v124 &= ~2u; /*0x1410422a6*/
        if ( v98 != nullptr ) /*0x1410422b9*/
        {
          v28 = _InterlockedExchangeAdd(v98 + 2, 0xFFFFFFFF); /*0x1410422c4*/
          if ( v28 == 1 ) /*0x1410422cc*/
          {
            v29 = v98; /*0x1410422ce*/
            (**(void (__fastcall ***)(volatile signed __int32 *))v98)(a1: v98); /*0x1410422dc*/
            v30 = _InterlockedExchangeAdd(v29 + 3, 0xFFFFFFFF); /*0x1410422e1*/
            if ( v30 == 1 ) /*0x1410422e9*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v98 + 8LL))(a1: v98); /*0x1410422f6*/
          }
        }
      }
      if ( (v124 & 1) != 0 ) /*0x14104230a*/
      {
        v124 &= ~1u; /*0x14104230c*/
        if ( v96 != nullptr ) /*0x14104231f*/
        {
          v31 = _InterlockedExchangeAdd(v96 + 2, 0xFFFFFFFF); /*0x141042324*/
          if ( v31 == 1 ) /*0x14104232c*/
          {
            v32 = v96; /*0x14104232e*/
            (**(void (__fastcall ***)(volatile signed __int32 *))v96)(a1: v96); /*0x14104233c*/
            v33 = _InterlockedExchangeAdd(v32 + 3, 0xFFFFFFFF); /*0x141042341*/
            if ( v33 == 1 ) /*0x141042349*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v96 + 8LL))(a1: v96); /*0x141042356*/
          }
        }
      }
      __wind /*0xf1c00000000002a8*/
      {
        __wind /*0xf1c00000000002b0*/
        {
          p_connections = &v4->connections; /*0x14104235a*/
          p_disconnectionSignal = &v25->disconnectionSignal; /*0x141042369*/
          *(_QWORD *)&v87 = RBX::PlayerConfigurer::onDisconnection; /*0x141042375*/
          DWORD2(v87) = 0; /*0x14104237a*/
          v35 = v87; /*0x141042382*/
          v110[1] = v87; /*0x141042387*/
          v111 = v4; /*0x14104238f*/
          v36 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x14104239d*/
          __wind /*0xf1c000000000020c*/
          {
            parent = v36; /*0x1410423a2*/
            v89.parent = v36; /*0x1410423a4*/
            v38 = (char *)operator new(size: 0x40u); /*0x1410423ad*/
            v39 = (rbx::signals::slot_base *)v38; /*0x1410423b2*/
            v86 = (RBX::Graphics::ProfilerAdorn::Item *)v38; /*0x1410423b5*/
            if ( v38 != nullptr ) /*0x1410423bd*/
            {
              *(_DWORD *)v38 = 0; /*0x1410423c1*/
              *((_DWORD *)v38 + 1) = 1; /*0x1410423c3*/
              *((_QWORD *)v38 + 1) = rbx::signals::slot_with_functor<boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::PlayerConfigurer,std::string const &,bool,std::string,int>,boost::_bi::list5<boost::_bi::value<RBX::PlayerConfigurer *>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>>>,std::string,bool,std::string,int>::do_call; /*0x1410423d1*/
              *((_QWORD *)v38 + 2) = RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x1410423dd*/
              *((_QWORD *)v38 + 3) = 0; /*0x1410423e2*/
              v40 = p_disconnectionSignal; /*0x1410423e7*/
              *((_QWORD *)v38 + 4) = p_disconnectionSignal; /*0x1410423ec*/
              *(_OWORD *)(v38 + 40) = v35; /*0x1410423f1*/
              *((_QWORD *)v38 + 7) = v111; /*0x141042400*/
            }
            else
            {
              v40 = p_disconnectionSignal; /*0x141042409*/
            }
            rbx::signals::signal_base::insert(this: v40, item: (rbx::signals::slot_base *)v38); /*0x141042411*/
            v88.weak_slot.p_ = v39; /*0x141042416*/
            if ( v39 != nullptr ) /*0x14104241e*/
            {
              _InterlockedIncrement(&v39->weak._Storage._Value); /*0x141042420*/
              parent = v89.parent; /*0x141042426*/
            }
            v125 = v124 | 8; /*0x14104242a*/
          }
          __unwind
          {
            RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v89); /*0xf1c000000000021c*/
          }
          __wind /*0xf1c0000000000224*/
          {
            RBX::Memory::setCurrentCategory(category: parent); /*0x141042434*/
          }
          __unwind
          {
            __std_terminate(a1: v41, a2: v83); /*0x142f39fa8*/
          }
          Mylast = v4->connections._Mypair._Myval2._Mylast; /*0x14104243a*/
          if ( Mylast == v4->connections._Mypair._Myval2._Myend ) /*0x141042442*/
          {
            std::vector<rbx::signals::connection>::_Emplace_reallocate<rbx::signals::connection>( /*0x141042461*/
              this: &v4->connections,
              _Whereptr: Mylast,
              <_Val_0>: &v88);
            p = v88.weak_slot.p_; /*0x141042466*/
          }
          else
          {
            Mylast->weak_slot.p_ = v39; /*0x141042444*/
            p = nullptr; /*0x14104244a*/
            v88.weak_slot.p_ = nullptr; /*0x14104244d*/
            ++v4->connections._Mypair._Myval2._Mylast; /*0x141042452*/
          }
          v126 = v125 & 0xF7; /*0x14104246e*/
        }
        __unwind
        {
          if ( (v126 & 8) != 0 ) /*0x1431e7d14*/
            rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v88); /*0x1431e7d21*/
        }
        if ( p != nullptr && _InterlockedExchangeAdd(&p->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x141042486*/
          operator delete(ptr: v88.weak_slot.p_); /*0x14104248d*/
        v44 = v85.weak_slot.p_; /*0x141042492*/
        *(_QWORD *)&v87 = RBX::PlayerConfigurer::onReceivedGlobals; /*0x1410424a5*/
        DWORD2(v87) = 0; /*0x1410424aa*/
        function.f_.f_ = v87; /*0x1410424b4*/
        function.l_.a1_.t_ = v4; /*0x1410424bc*/
        v45 = rbx::signal<void (RBX::Reflection::PropertyDescriptor const *)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RobloxScriptDoc,RBX::Reflection::PropertyDescriptor const *>,boost::_bi::list2<boost::_bi::value<RobloxScriptDoc *>,boost::arg<1>>>>( /*0x1410424d4*/
                this: (rbx::signal<void __cdecl(void)> *)&v85.weak_slot.p_[369].call,
                result: (rbx::signals::connection *)&result.x,
                &function);
        __wind /*0xf1c00000000001e8*/
        {
          v46 = p_connections->_Mypair._Myval2._Mylast; /*0x1410424dc*/
          if ( v46 == p_connections->_Mypair._Myval2._Myend ) /*0x1410424e4*/
          {
            std::vector<rbx::signals::connection>::_Emplace_reallocate<rbx::signals::connection>( /*0x1410424f9*/
              this: p_connections,
              _Whereptr: v46,
              <_Val_0>: v45);
          }
          else
          {
            v46->weak_slot.p_ = v45->weak_slot.p_; /*0x1410424e9*/
            v45->weak_slot.p_ = nullptr; /*0x1410424ec*/
            ++p_connections->_Mypair._Myval2._Mylast; /*0x1410424ef*/
          }
        }
        __unwind
        {
          rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&result.x); /*0xf1c00000000001e0*/
        }
        v47 = *(void **)&result.x; /*0x1410424ff*/
        if ( *(_QWORD *)&result.x != 0 /*0x141042517*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)&result.x + 4LL), 0xFFFFFFFF) == 1 )
        {
          operator delete(ptr: v47); /*0x141042519*/
        }
        p_disconnectionSignal = (rbx::signals::signal_base *)&v44[369].owner; /*0x141042525*/
        if ( FFlag::RemovePeriodicallyZoomExtents.value ) /*0x141042531*/
        {
          *(_QWORD *)&v87 = RBX::PlayerConfigurer::onGameLoaded; /*0x14104253e*/
          DWORD2(v87) = 0; /*0x141042543*/
          v113.f_.f_ = v87; /*0x14104254d*/
          v113.l_.a1_.t_ = v4; /*0x141042555*/
          v48 = rbx::signal<void (RBX::Reflection::PropertyDescriptor const *)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RobloxScriptDoc,RBX::Reflection::PropertyDescriptor const *>,boost::_bi::list2<boost::_bi::value<RobloxScriptDoc *>,boost::arg<1>>>>( /*0x141042570*/
                  this: (rbx::signal<void __cdecl(void)> *)&v44[369].owner,
                  result: (rbx::signals::connection *)&result.width,
                  function: &v113);
          __wind /*0xf1c00000000001d0*/
          {
            v49 = p_connections->_Mypair._Myval2._Mylast; /*0x141042578*/
            if ( v49 == p_connections->_Mypair._Myval2._Myend ) /*0x141042580*/
            {
              std::vector<rbx::signals::connection>::_Emplace_reallocate<rbx::signals::connection>( /*0x141042595*/
                this: p_connections,
                _Whereptr: v49,
                <_Val_0>: v48);
            }
            else
            {
              v49->weak_slot.p_ = v48->weak_slot.p_; /*0x141042585*/
              v48->weak_slot.p_ = nullptr; /*0x141042588*/
              ++p_connections->_Mypair._Myval2._Mylast; /*0x14104258b*/
            }
          }
          __unwind
          {
            rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&result.width); /*0xf1c00000000001c8*/
          }
          v50 = *(void **)&result.width; /*0x14104259b*/
          if ( *(_QWORD *)&result.width != 0 /*0x1410425b7*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)&result.width + 4LL), 0xFFFFFFFF) == 1 )
          {
            operator delete(ptr: v50); /*0x1410425bd*/
          }
        }
        else
        {
          if ( v14 != nullptr ) /*0x1410425ca*/
            _InterlockedIncrement((volatile signed __int32 *)&v14->std::enable_shared_from_this<RBX::Reflection::DescribedBase>); /*0x1410425cc*/
          *(_QWORD *)&result.color = v12; /*0x1410425d0*/
          v100 = v14; /*0x1410425d8*/
          *(_QWORD *)&v87 = RBX::PlayerConfigurer::onGameLoaded; /*0x1410425e7*/
          DWORD2(v87) = 0; /*0x1410425ec*/
          v110[0] = v87; /*0x1410425f6*/
          v51 = (RBX::Graphics::ProfilerAdorn::Item *)boost::bind<void,RBX::PlayerConfigurer,std::shared_ptr<bool>,RBX::PlayerConfigurer *,std::shared_ptr<bool>>( /*0x14104261a*/
                                                        result: &v119,
                                                        f: v110,
                                                        a1: v4,
                                                        a2: (std::shared_ptr<bool> *)&result.color);
          __wind /*0xf1c0000000000294*/
          {
            __wind /*0xf1c000000000029c*/
            {
              v86 = v51; /*0x14104261f*/
              v52 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x14104262a*/
              __wind /*0xf1c00000000001a0*/
              {
                v53 = v52; /*0x14104262f*/
                v90.parent = v52; /*0x141042631*/
                v54 = (char *)operator new(size: 0x50u); /*0x14104263a*/
                v55 = (rbx::signals::slot_base *)v54; /*0x14104263f*/
                *(_QWORD *)&v87 = v54; /*0x141042642*/
                v56 = p_disconnectionSignal; /*0x141042647*/
                if ( v54 != nullptr ) /*0x14104264f*/
                {
                  *(_DWORD *)v54 = 0; /*0x141042654*/
                  *((_DWORD *)v54 + 1) = 1; /*0x141042657*/
                  *((_QWORD *)v54 + 1) = rbx::signals::slot_with_functor<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::PlayerConfigurer,std::shared_ptr<bool>>,boost::_bi::list2<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::shared_ptr<bool>>>>,>::do_call; /*0x141042665*/
                  *((_QWORD *)v54 + 2) = rbx::signals::slot_with_functor<std::_Binder<std::_Unforced,void (RBX::Humanoid::*)(std::shared_ptr<RBX::Instance>,std::shared_ptr<RBX::Instance>),RBX::Humanoid *,std::shared_ptr<RBX::Attachment>,std::_Ph<1> const &>,std::shared_ptr<RBX::Instance>>::do_dtor; /*0x141042671*/
                  *((_QWORD *)v54 + 3) = 0; /*0x141042676*/
                  *((_QWORD *)v54 + 4) = v56; /*0x14104267b*/
                  v57 = v86; /*0x141042680*/
                  *(std::_String_val<std::_Simple_types<char> >::_Bxty *)(v54 + 40) = v86->text._Mypair._Myval2._Bx; /*0x141042688*/
                  *((_QWORD *)v54 + 7) = v57->text._Mypair._Myval2._Mysize; /*0x141042692*/
                  *((_QWORD *)v54 + 8) = 0; /*0x141042697*/
                  *((_QWORD *)v54 + 9) = 0; /*0x14104269c*/
                  *((_QWORD *)v54 + 8) = v57->text._Mypair._Myval2._Myres; /*0x1410426a5*/
                  *((_QWORD *)v54 + 9) = *(_QWORD *)&v57->x; /*0x1410426ae*/
                  v57->text._Mypair._Myval2._Myres = 0; /*0x1410426b3*/
                  *(_QWORD *)&v57->x = 0; /*0x1410426b7*/
                }
                rbx::signals::signal_base::insert(this: v56, item: (rbx::signals::slot_base *)v54); /*0x1410426be*/
                v85.weak_slot.p_ = v55; /*0x1410426c3*/
                if ( v55 != nullptr ) /*0x1410426cb*/
                {
                  _InterlockedIncrement(&v55->weak._Storage._Value); /*0x1410426cd*/
                  v53 = v90.parent; /*0x1410426d3*/
                }
                v127 = v126 | 0x10; /*0x1410426d7*/
              }
              __unwind
              {
                RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v90); /*0xf1c00000000001b0*/
              }
              __wind /*0xf1c00000000001b8*/
              {
                RBX::Memory::setCurrentCategory(category: v53); /*0x1410426e1*/
              }
              __unwind
              {
                __std_terminate(a1: v58, a2: v83); /*0xf1c0000000000054*/
              }
              v59 = p_connections->_Mypair._Myval2._Mylast; /*0x1410426e7*/
              if ( v59 == p_connections->_Mypair._Myval2._Myend ) /*0x1410426ef*/
              {
                std::vector<rbx::signals::connection>::_Emplace_reallocate<rbx::signals::connection>( /*0x14104270a*/
                  this: p_connections,
                  _Whereptr: v59,
                  <_Val_0>: &v85);
                v60 = v85.weak_slot.p_; /*0x14104270f*/
              }
              else
              {
                v59->weak_slot.p_ = v55; /*0x1410426f1*/
                v60 = nullptr; /*0x1410426f4*/
                v85.weak_slot.p_ = nullptr; /*0x1410426f6*/
                ++p_connections->_Mypair._Myval2._Mylast; /*0x1410426fb*/
              }
              v126 = v127 & 0xEF; /*0x141042714*/
            }
            __unwind
            {
              if ( (v126 & 0x10) != 0 ) /*0x1431e7d44*/
                rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v85); /*0x1431e7d51*/
            }
            if ( v60 != nullptr && _InterlockedExchangeAdd(&v60->weak._Storage._Value, 0xFFFFFFFF) == 1 ) /*0x14104272c*/
              operator delete(ptr: v85.weak_slot.p_); /*0x141042733*/
            v61 = v119.l_.a2_.t_._Rep; /*0x141042739*/
            if ( v119.l_.a2_.t_._Rep != nullptr /*0x141042751*/
              && _InterlockedExchangeAdd((volatile signed __int32 *)&v119.l_.a2_.t_._Rep->_Uses, 0xFFFFFFFF) == 1 )
            {
              v61->_Destroy(this: v61); /*0x141042759*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v61->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141042766*/
                v61->_Delete_this(this: v61); /*0x14104276e*/
            }
          }
          __unwind
          {
            boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::SoundJobStudio,std::shared_ptr<RBX::Soundscape::Sound>,std::shared_ptr<RBX::Instance>>,boost::_bi::list3<boost::_bi::value<RBX::SoundJobStudio *>,boost::_bi::value<std::shared_ptr<RBX::Soundscape::Sound>>,boost::arg<2>>>::~bind_t<void,boost::_mfi::mf2<void,RBX::SoundJobStudio,std::shared_ptr<RBX::Soundscape::Sound>,std::shared_ptr<RBX::Instance>>,boost::_bi::list3<boost::_bi::value<RBX::SoundJobStudio *>,boost::_bi::value<std::shared_ptr<RBX::Soundscape::Sound>>,boost::arg<2>>>(this: (std::_Binder<std::_Unforced,void (__cdecl RBX::ChatService::*)(std::shared_ptr<RBX::Instance>,std::string,bool,std::string,std::string,std::string),std::shared_ptr<RBX::ChatService>,std::_Ph<1> const &,std::_Ph<2> const &,std::_Ph<3> const &,std::_Ph<4> const &,std::_Ph<5> const &,std::_Ph<6> const &> *)&v119); /*0xf1c0000000000180*/
          }
        }
        if ( DFFlag::ReportDefaultLoadingGuiRemovalTimeWithChildrenCheck.value ) /*0x141042778*/
        {
          v62 = RBX::ServiceProvider::find<RBX::ReplicatedFirst>(this: &v4->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x141042786*/
          if ( v62 != nullptr ) /*0x14104278e*/
          {
            __wind /*0xf1c0000000000164*/
            {
              p_defaultLoadingGuiRemovedSignal = &v62->defaultLoadingGuiRemovedSignal; /*0x141042794*/
              v64 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x1410427a1*/
              __wind /*0xf1c0000000000140*/
              {
                v65 = v64; /*0x1410427a6*/
                v91.parent = v64; /*0x1410427a8*/
                v66 = (rbx::signals::slot_base *)operator new(size: 0x30u); /*0x1410427b1*/
                v67 = v66; /*0x1410427b6*/
                *(_QWORD *)&v87 = v66; /*0x1410427b9*/
                if ( v66 != nullptr ) /*0x1410427c1*/
                {
                  v66->strong._Storage._Value = 0; /*0x1410427c5*/
                  v66->weak._Storage._Value = 1; /*0x1410427c7*/
                  v66->call = rbx::signals::slot_with_functor__lambda_dc59d60acd64f63de34607de49737e8f___::do_call; /*0x1410427d5*/
                  v66->dtor = (void (__fastcall *)(rbx::signals::slot_base *))RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x1410427e0*/
                  v66->next.px = nullptr; /*0x1410427e4*/
                  v66->owner = p_defaultLoadingGuiRemovedSignal; /*0x1410427e8*/
                  v66[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)v4; /*0x1410427ec*/
                }
                rbx::signals::signal_base::insert(this: p_defaultLoadingGuiRemovedSignal, item: v66); /*0x1410427f6*/
                v115 = v67; /*0x1410427fb*/
                if ( v67 != nullptr ) /*0x141042806*/
                {
                  _InterlockedIncrement(&v67->weak._Storage._Value); /*0x141042808*/
                  v65 = v91.parent; /*0x14104280c*/
                }
                v128 = v126 | 0x20; /*0x141042810*/
              }
              __unwind
              {
                RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v91); /*0xf1c0000000000150*/
              }
              __wind /*0xf1c0000000000158*/
              {
                RBX::Memory::setCurrentCategory(category: v65); /*0x14104281a*/
              }
              __unwind
              {
                __std_terminate(a1: v68, a2: v83); /*0xf1c000000000005c*/
              }
              v69 = (volatile signed __int32 *)&v4->defaultLoadingGuiRemovedConnection.weak_slot.p_->rbx::intrusive_ptr_target<rbx::signals::slot_base>; /*0x141042820*/
              v4->defaultLoadingGuiRemovedConnection.weak_slot.p_ = v67; /*0x141042827*/
              if ( v69 != nullptr && _InterlockedExchangeAdd(v69 + 1, 0xFFFFFFFF) == 1 ) /*0x14104283d*/
                operator delete(ptr: (void *)v69); /*0x14104283f*/
            }
            __unwind
            {
              if ( (v128 & 0x20) != 0 ) /*0x1431e7d74*/
                rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: (char *)&v115); /*0x1431e7d84*/
            }
          }
        }
        __wind /*0xf1c0000000000128*/
        {
          *(_QWORD *)&v87 = &v108; /*0x14104284c*/
          v108._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141042853*/
          v108._Mypair._Myval2._Myres = 15; /*0x14104285b*/
          v108._Mypair._Myval2._Mysize = 0; /*0x141042867*/
          v86 = (RBX::Graphics::ProfilerAdorn::Item *)&v106; /*0x141042877*/
          v106._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14104287c*/
          v106._Mypair._Myval2._Mysize = 0; /*0x141042884*/
          v106._Mypair._Myval2._Myres = 15; /*0x14104288c*/
          std::string::assign(this: &v106, _Ptr: aSucc_0, _Count: 7u); /*0x1410428ab*/
          __wind /*0xf1c0000000000104*/
          {
            v107._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410428b1*/
            v107._Mypair._Myval2._Mysize = 0; /*0x1410428b9*/
            v107._Mypair._Myval2._Myres = 15; /*0x1410428c1*/
            std::string::assign(this: &v107, _Ptr: "ClientConnectResult", _Count: 0x13u); /*0x1410428e0*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: v86); /*0xf1c0000000000114*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)v87); /*0xf1c0000000000120*/
        }
        RBX::TeleportService::logClientGroupTeleportInfluxDB(event: &v107, status: &v106, response: &v108); /*0x1410428fe*/
        if ( rep._Rep != nullptr ) /*0x14104290f*/
          std::_Ref_count_base::_Decref(this: rep._Rep); /*0x141042911*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&rep); /*0xf1c000000000027c*/
      }
    }
    catch ( std::exception *e )
    {
      *(_QWORD *)&v87 = &v118; /*0x1431e7da6*/
      v75 = e; /*0x1431e7daa*/
      if ( e->what(this: e) != nullptr ) /*0x1431e7dbd*/
        v76 = v75->what(this: v75); /*0x1431e7dce*/
      else
        v76 = pass; /*0x1431e7dbf*/
      v77 = std::string::string(this: &v118, _Ptr: v76); /*0x1431e7de0*/
      __wind /*0xf1c00000000000b8*/
      {
        v86 = (RBX::Graphics::ProfilerAdorn::Item *)&v103; /*0x1431e7dea*/
        v103._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1431e7dee*/
        v103._Mypair._Myval2._Mysize = 0; /*0x1431e7df9*/
        v103._Mypair._Myval2._Myres = 15; /*0x1431e7e04*/
        std::string::assign(this: &v103, _Ptr: "FailureOnAccept", _Count: 0xFu); /*0x1431e7e2a*/
        __wind /*0xf1c0000000000094*/
        {
          v104._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1431e7e30*/
          v104._Mypair._Myval2._Mysize = 0; /*0x1431e7e3b*/
          v104._Mypair._Myval2._Myres = 15; /*0x1431e7e46*/
          std::string::assign(this: &v104, _Ptr: "ClientConnectResult", _Count: 0x13u); /*0x1431e7e6c*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: v86); /*0xf1c00000000000a4*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)v87); /*0xf1c00000000000b0*/
      }
      RBX::TeleportService::logClientGroupTeleportInfluxDB(event: &v104, status: &v103, response: v77); /*0x1431e7e83*/
      v78 = v75->what(this: v75); /*0x1431e7e8e*/
      RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "onConnectionAccepted failed: %s", v78);
      *(_QWORD *)&key.x = 0; /*0x1431e7ea5*/
      *(_QWORD *)&key.color = 0; /*0x1431e7eb0*/
      v102 = 15; /*0x1431e7ebb*/
      std::string::assign(this: (std::string *)&key.x, _Ptr: "ConnectionAccepted", _Count: 0x12u); /*0x1431e7ee1*/
      __wind /*0xf1c0000000000088*/
      {
        v79 = v75->what(this: v75); /*0x1431e7eed*/
        category_32.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1431e7ef0*/
        category_32.text._Mypair._Myval2._Mysize = 0; /*0x1431e7efb*/
        category_32.text._Mypair._Myval2._Myres = 15; /*0x1431e7f06*/
        v80 = -1; /*0x1431e7f18*/
        do /*0x1431e7f28*/
          ++v80; /*0x1431e7f20*/
        while ( v79[v80] != 0 ); /*0x1431e7f28*/
        std::string::assign(this: &category_32.text, _Ptr: v79, _Count: v80); /*0x1431e7f34*/
        __wind /*0xf1c000000000007c*/
        {
          RBX::PlayerConfigurer::reportError(this, error: &category_32.text, msg: (const std::string *)&key.x); /*0x1431e7f4f*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &category_32); /*0xf1c0000000000074*/
        }
        if ( category_32.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1431e7f65*/
        {
          v81 = category_32.text._Mypair._Myval2._Bx._Ptr; /*0x1431e7f6a*/
          if ( category_32.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1431e7f78*/
          {
            if ( (unsigned __int64)&category_32.text._Mypair._Myval2._Bx._Ptr[-*((_QWORD *)category_32.text._Mypair._Myval2._Bx._Ptr /*0x1431e7f8d*/
                                                                               - 1)
                                                                            - 8] > 0x1F )
              _invalid_parameter_noinfo_noreturn(); /*0x1431e7f94*/
            v81 = *((char **)category_32.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1431e7f8f*/
          }
          operator delete(ptr: v81); /*0x1431e7f9b*/
        }
        category_32.text._Mypair._Myval2._Mysize = 0; /*0x1431e7fa0*/
        category_32.text._Mypair._Myval2._Myres = 15; /*0x1431e7fab*/
        category_32.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1431e7fb6*/
        if ( v102 >= 0x10 ) /*0x1431e7fcd*/
        {
          v82 = *(void **)&key.x; /*0x1431e7fd2*/
          if ( v102 + 1 >= 0x1000 ) /*0x1431e7fe0*/
          {
            if ( (unsigned __int64)(*(_QWORD *)&key.x - *(_QWORD *)(*(_QWORD *)&key.x - 8LL) - 8LL) > 0x1F ) /*0x1431e7ff5*/
              _invalid_parameter_noinfo_noreturn(); /*0x1431e7ffc*/
            v82 = *(void **)(*(_QWORD *)&key.x - 8LL); /*0x1431e7ff7*/
          }
          operator delete(ptr: v82); /*0x1431e8003*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key.x); /*0xf1c0000000000068*/
      }
      v4 = this; /*0x141042919*/
      v12 = *(bool **)&category_32.x; /*0x141042921*/
      v14 = v92._Ptr; /*0x141042929*/
    }
    if ( !FFlag::RemovePeriodicallyZoomExtents.value ) /*0x141042935*/
    {
      v70 = RBX::ServiceProvider::create<RBX::TimerService>(this: &v4->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x141042943*/
      v71 = v70; /*0x141042948*/
      v92 = 0; /*0x14104295b*/
      if ( v14 != nullptr ) /*0x141042964*/
        _InterlockedIncrement((volatile signed __int32 *)&v14->std::enable_shared_from_this<RBX::Reflection::DescribedBase>); /*0x141042966*/
      __wind /*0xf1c00000000000f8*/
      {
        v92._Ptr = (RBX::File *)v12; /*0x14104296a*/
        v92._Rep = (std::_Ref_count_base *)v14; /*0x14104296f*/
        v72 = (std::weak_ptr<RBX::DataModel> *)RBX::weak_from<RBX::DataModel>( /*0x141042980*/
                                                 result: (std::weak_ptr<RBX::DataModel const > *)&category_32.x,
                                                 r: v4->dataModel);
        v73 = boost::bind<void,std::weak_ptr<RBX::DataModel>,std::shared_ptr<bool>,std::weak_ptr<RBX::DataModel>,std::shared_ptr<bool>>( /*0x14104299d*/
                result: &v120,
                f: periodicallyZoomExtents,
                a1: v72,
                a2: (std::shared_ptr<bool> *)&v92);
        v74 = std::function<void (void)>::function<void (void)>(this: &v121, _Func: v73); /*0x1410429ad*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v92); /*0xf1c00000000000f0*/
      }
      RBX::TimerService::delay(this: v71, func: v74, seconds: 0.0); /*0x1410429bb*/
    }
    if ( v14 != nullptr ) /*0x1410429c4*/
      std::_Ref_count_base::_Decref(this: (std::_Ref_count_base *)v14); /*0x1410429c9*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&waitingForMarker); /*0xf1c00000000000e4*/
  }
}

// Address: 0x1410429f0 | Name: ?onConnectionFailed@PlayerConfigurer@RBX@@AEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@H0@Z
void __fastcall RBX::PlayerConfigurer::onConnectionFailed(
        RBX::PlayerConfigurer *this,
        const std::string *remoteAddress,
        int errorCode,
        const std::string *errorMsg)
{
  const std::string *Ptr; // r8
  int ParamInt; // eax
  char *v9; // rcx
  std::string *ParamString; // rax
  char *v11; // rcx
  char *v12; // rcx
  long double v13; // xmm0_8
  char *v14; // rcx
  char *v15; // rcx
  char *v16; // rcx
  char *v17; // rcx
  char *v18; // rcx
  std::string key; // [rsp+30h] [rbp-D0h] BYREF
  std::string result; // [rsp+50h] [rbp-B0h] BYREF
  std::string errorType; // [rsp+70h] [rbp-90h] BYREF
  RBX::Analytics::InfluxDb::Points pts; // [rsp+90h] [rbp-70h] BYREF
  std::string v23; // [rsp+100h] [rbp+0h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *p_key; // [rsp+120h] [rbp+20h]
  std::string msg; // [rsp+130h] [rbp+30h] BYREF

  this->connectionFailed = true; /*0x141042a13*/
  if ( FInt::DisconnectInfluxHundredthsPercentage > 0 ) /*0x141042a21*/
  {
    RBX::Analytics::InfluxDb::Points::Points( /*0x141042a35*/
      this: &pts,
      throttleHundredthsPercentage: -1,
      categoryType: kStandardType,
      priorityHundredthsPercentage: 0);
    Ptr = errorMsg; /*0x141042a3b*/
    if ( errorMsg->_Mypair._Myval2._Myres >= 0x10 ) /*0x141042a43*/
      Ptr = (const std::string *)errorMsg->_Mypair._Myval2._Bx._Ptr; /*0x141042a45*/
    __wind /*0xf1c0000000000084*/
    {
      RBX::Analytics::InfluxDb::Points::addPoint(this: &pts, name: aMess_0, value: Ptr->_Mypair._Myval2._Bx._Buf); /*0x141042a53*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &pts, name: "errorCode", value: errorCode); /*0x141042a66*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &pts, name: "loaded", value: this->loadResolved); /*0x141042a7b*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &pts, name: "joined", value: this->joinResolved); /*0x141042a90*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &pts, name: "played", value: this->playResolved); /*0x141042aa5*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &pts, name: "waiting4char", value: this->waitingForCharacter); /*0x141042aba*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &pts, name: "launchmode", value: -1); /*0x141042ad0*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &pts, name: "studio2rcc", value: this->isStudioToRcc); /*0x141042ae5*/
      key._Mypair._Myval2._Myres = 15; /*0x141042aea*/
      key._Mypair._Myval2._Mysize = 12; /*0x141042af3*/
      strcpy(key._Mypair._Myval2._Bx._Buf, "DataCenterId"); /*0x141042b04*/
      __eh34_enter_wind_state(0, 1); /*0xf1c000000000007c*/
      ParamInt = RBX::GameConfigurer::getParamInt(this, &key); /*0x141042b21*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &pts, name: "datacenter", value: ParamInt); /*0x141042b34*/
      if ( __eh34_unwind(1) ) /*0xf1c0000000000070*/
      {
unwind_state_1:
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key); /*0xf1c000000000002c*/
        __eh34_continue_unwinding(1, 0); /*0xf1c0000000000030*/
      }
      __eh34_exit_wind_state(1, 0); /*0xf1c0000000000074*/
      if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x141042b43*/
      {
        v9 = key._Mypair._Myval2._Bx._Ptr; /*0x141042b48*/
        if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141042b57*/
        {
          v9 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x141042b5d*/
          if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v9 - 8) > 0x1F ) /*0x141042b6c*/
            _invalid_parameter_noinfo_noreturn(); /*0x141042b6e*/
        }
        operator delete(ptr: v9); /*0x141042b75*/
      }
      __eh34_enter_wind_state(0, 1); /*0xf1c0000000000068*/
      key._Mypair._Myval2._Myres = 15; /*0x141042b7a*/
      key._Mypair._Myval2._Mysize = 14; /*0x141042b83*/
      strcpy(key._Mypair._Myval2._Bx._Buf, "MachineAddress"); /*0x141042b94*/
      ParamString = RBX::GameConfigurer::getParamString(this, &result, &key); /*0x141042bc2*/
      if ( ParamString->_Mypair._Myval2._Myres >= 0x10 ) /*0x141042bcd*/
        ParamString = (std::string *)ParamString->_Mypair._Myval2._Bx._Ptr; /*0x141042bcf*/
      __wind /*0xf1c0000000000044*/
      {
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x141042be0*/
          this: &pts,
          name: "remoteaddr",
          value: ParamString->_Mypair._Myval2._Bx._Buf);
        if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141042bef*/
        {
          v11 = result._Mypair._Myval2._Bx._Ptr; /*0x141042bf4*/
          if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141042c03*/
          {
            v11 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x141042c09*/
            if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v11 - 8) > 0x1F ) /*0x141042c18*/
              _invalid_parameter_noinfo_noreturn(); /*0x141042c1a*/
          }
          operator delete(ptr: v11); /*0x141042c21*/
        }
        result._Mypair._Myval2._Mysize = 0; /*0x141042c26*/
        result._Mypair._Myval2._Myres = 15; /*0x141042c2b*/
        result._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141042c34*/
        if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x141042c42*/
        {
          v12 = key._Mypair._Myval2._Bx._Ptr; /*0x141042c47*/
          if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141042c56*/
          {
            v12 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x141042c5c*/
            if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v12 - 8) > 0x1F ) /*0x141042c6b*/
              _invalid_parameter_noinfo_noreturn(); /*0x141042c6d*/
          }
          operator delete(ptr: v12); /*0x141042c74*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000054*/
      }
      if ( __eh34_unwind(1) ) /*0xf1c000000000005c*/
        goto unwind_state_1; /*0xf1c000000000005c*/
      __eh34_exit_wind_state(1, 0); /*0xf1c0000000000060*/
      v13 = RBX::Time::nowFastSec(); /*0x141042c79*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x141042c94*/
        this: &pts,
        name: "duration",
        value: v13 - this->sgs.avatarConfigureTime);
      key._Mypair._Myval2._Myres = 15; /*0x141042c99*/
      key._Mypair._Myval2._Mysize = 10; /*0x141042ca2*/
      strcpy(key._Mypair._Myval2._Bx._Buf, "Disconnect"); /*0x141042cb3*/
      __eh34_enter_wind_state(0, 1); /*0xf1c000000000003c*/
      RBX::Analytics::InfluxDb::Points::report( /*0x141042cdd*/
        this: &pts,
        resource: &key,
        throttleHundredthsPercentage: FInt::DisconnectInfluxHundredthsPercentage,
        blocking: false);
      if ( __eh34_unwind(1) ) /*0xf1c0000000000028*/
        goto unwind_state_1; /*0xf1c0000000000028*/
      __eh34_exit_wind_state(1, 0); /*0xf1c0000000000034*/
      if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x141042cec*/
      {
        v14 = key._Mypair._Myval2._Bx._Ptr; /*0x141042cf1*/
        if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141042d00*/
        {
          v14 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x141042d06*/
          if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v14 - 8) > 0x1F ) /*0x141042d15*/
            _invalid_parameter_noinfo_noreturn(); /*0x141042d17*/
        }
        operator delete(ptr: v14); /*0x141042d1e*/
      }
      if ( pts.userIdOverride._Mypair._Myval2._Myres >= 0x10 ) /*0x141042d2c*/
      {
        v15 = pts.userIdOverride._Mypair._Myval2._Bx._Ptr; /*0x141042d31*/
        if ( pts.userIdOverride._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141042d3f*/
        {
          v15 = *((char **)pts.userIdOverride._Mypair._Myval2._Bx._Ptr - 1); /*0x141042d45*/
          if ( (unsigned __int64)(pts.userIdOverride._Mypair._Myval2._Bx._Ptr - v15 - 8) > 0x1F ) /*0x141042d54*/
            _invalid_parameter_noinfo_noreturn(); /*0x141042d56*/
        }
        operator delete(ptr: v15); /*0x141042d5d*/
      }
      *(__m128i *)&pts.userIdOverride._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x141042d6a*/
      pts.userIdOverride._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141042d6f*/
      std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&pts); /*0x141042d77*/
    }
    __unwind
    {
      RBX::Analytics::InfluxDb::Points::~Points(this: &pts); /*0xf1c0000000000020*/
    }
  }
  if ( errorMsg->_Mypair._Myval2._Myres >= 0x10 ) /*0x141042d81*/
    errorMsg = (const std::string *)errorMsg->_Mypair._Myval2._Bx._Ptr; /*0x141042d83*/
  RBX::format(
    result: &msg,
    fmt: "Failed to connect to the Game. (ID = %d: %s)",
    errorCode,
    errorMsg->_Mypair._Myval2._Bx._Buf);
  __wind /*0xf1c0000000000004*/
  {
    RBX::format(result: &errorType, fmt: "ID%d", errorCode); /*0x141042dac*/
    __wind /*0xf1c00000000000b4*/
    {
      __wind /*0xf1c00000000000bc*/
      {
        key._Mypair._Myval2._Myres = 15; /*0x141042db7*/
        key._Mypair._Myval2._Mysize = 5; /*0x141042dc0*/
        *(_DWORD *)key._Mypair._Myval2._Bx._Buf = *(_DWORD *)"Other"; /*0x141042dcf*/
        *(_DWORD *)&key._Mypair._Myval2._Bx._Alias[4] = (unsigned __int8)aOther_0[4]; /*0x141042dda*/
        RBX::PlayerConfigurer::showErrorWindow(this, message: &msg, &errorType, errorCategory: &key, errorCode: 279); /*0x141042dfc*/
        if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x141042e0b*/
        {
          v16 = key._Mypair._Myval2._Bx._Ptr; /*0x141042e10*/
          if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141042e1f*/
          {
            v16 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x141042e25*/
            if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x141042e34*/
              _invalid_parameter_noinfo_noreturn(); /*0x141042e36*/
          }
          operator delete(ptr: v16); /*0x141042e3d*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key); /*0xf1c00000000000cc*/
      }
      __wind /*0xf1c00000000000d4*/
      {
        __wind /*0xf1c00000000000dc*/
        {
          v23._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141042e4a*/
          v23._Mypair._Myval2._Myres = 15; /*0x141042e4e*/
          v23._Mypair._Myval2._Mysize = 0; /*0x141042e56*/
          p_key = (RBX::Graphics::ProfilerAdorn::Item *)&key; /*0x141042e5f*/
          key._Mypair._Myval2._Myres = 15; /*0x141042e68*/
          key._Mypair._Myval2._Mysize = 7; /*0x141042e71*/
          qmemcpy(&key, "Failur", 6); /*0x141042e80*/
          *(_WORD *)&key._Mypair._Myval2._Bx._Alias[6] = (unsigned __int8)aFailure_0[6]; /*0x141042e97*/
          result._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141042ea0*/
          result._Mypair._Myval2._Mysize = 0; /*0x141042ea5*/
          result._Mypair._Myval2._Myres = 15; /*0x141042eaa*/
          std::string::assign(this: &result, _Ptr: "ClientConnectResult", _Count: 0x13u); /*0x141042ec5*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: p_key); /*0xf1c00000000000a0*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v23); /*0xf1c00000000000ac*/
      }
      RBX::TeleportService::logClientGroupTeleportInfluxDB(event: &result, status: &key, response: &v23); /*0x141042ed9*/
      if ( errorType._Mypair._Myval2._Myres >= 0x10 ) /*0x141042ee7*/
      {
        v17 = errorType._Mypair._Myval2._Bx._Ptr; /*0x141042eec*/
        if ( errorType._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141042efb*/
        {
          v17 = *((char **)errorType._Mypair._Myval2._Bx._Ptr - 1); /*0x141042f01*/
          if ( (unsigned __int64)(errorType._Mypair._Myval2._Bx._Ptr - v17 - 8) > 0x1F ) /*0x141042f10*/
            _invalid_parameter_noinfo_noreturn(); /*0x141042f12*/
        }
        operator delete(ptr: v17); /*0x141042f19*/
      }
      errorType._Mypair._Myval2._Mysize = 0; /*0x141042f1e*/
      errorType._Mypair._Myval2._Myres = 15; /*0x141042f22*/
      errorType._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141042f2a*/
      if ( msg._Mypair._Myval2._Myres >= 0x10 ) /*0x141042f37*/
      {
        v18 = msg._Mypair._Myval2._Bx._Ptr; /*0x141042f3c*/
        if ( msg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141042f4a*/
        {
          v18 = *((char **)msg._Mypair._Myval2._Bx._Ptr - 1); /*0x141042f50*/
          if ( (unsigned __int64)(msg._Mypair._Myval2._Bx._Ptr - v18 - 8) > 0x1F ) /*0x141042f5f*/
            _invalid_parameter_noinfo_noreturn(); /*0x141042f61*/
        }
        operator delete(ptr: v18); /*0x141042f68*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&errorType); /*0xf1c0000000000094*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&msg); /*0xf1c0000000000014*/
  }
}

// Address: 0x141042f90 | Name: ?onDefaultLoadingScreenRemoved@PlayerConfigurer@RBX@@AEAAXXZ
void __fastcall RBX::PlayerConfigurer::onDefaultLoadingScreenRemoved(RBX::PlayerConfigurer *this)
{
  long double v2; // xmm0_8
  float v3; // xmm6_4
  unsigned __int64 v4; // rbx
  char *v5; // rax
  char *Ptr; // rcx
  RBX::ReplicatedFirst *v7; // rax
  char *v8; // rcx
  volatile signed __int32 *v9; // rbx
  void *v10; // rcx
  std::string category; // [rsp+28h] [rbp-79h] BYREF
  std::string resource; // [rsp+48h] [rbp-59h] BYREF
  _QWORD *v13; // [rsp+68h] [rbp-39h] BYREF
  RBX::Analytics::InfluxDb::Points durationAnalyticsPoint; // [rsp+70h] [rbp-31h] BYREF

  rbx::signals::connection::disconnect(this: &this->defaultLoadingGuiRemovedConnection); /*0x141042fb9*/
  if ( DFFlag::ReportDefaultLoadingGuiRemovalTimeWithChildrenCheck.value ) /*0x141042fc5*/
  {
    v2 = RBX::Time::nowFastSec() - this->sgs.avatarConfigureTime; /*0x141042fd0*/
    this->sgs.defaultLoadingGuiRemovedTime = v2; /*0x141042fd8*/
    v3 = v2 * 1000.0; /*0x141042feb*/
    v4 = 0; /*0x141042fef*/
    v5 = (char *)operator new(size: 0x30u); /*0x141043007*/
    category._Mypair._Myval2._Mysize = 36; /*0x14104300c*/
    category._Mypair._Myval2._Myres = 47; /*0x141043014*/
    strcpy(v5, "DefaultLoadingScreenRemoved_Duration"); /*0x141043023*/
    category._Mypair._Myval2._Bx._Ptr = v5; /*0x14104303d*/
    __wind /*0xf1c0000000000058*/
    {
      RBX::Analytics::EphemeralCounter::reportStats(&category, value: v3, blocking: false); /*0x14104304b*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&category); /*0xf1c0000000000050*/
    }
    if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x141043059*/
    {
      Ptr = category._Mypair._Myval2._Bx._Ptr; /*0x14104305e*/
      if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104306c*/
      {
        Ptr = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x141043072*/
        if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141043081*/
          _invalid_parameter_noinfo_noreturn(); /*0x141043083*/
      }
      operator delete(ptr: Ptr); /*0x14104308a*/
    }
    if ( RBX::Analytics::InfluxDb::canSend(throttleHundredthsPercentage: DFInt::JoinInfluxHundredthsPercentage) ) /*0x141043095*/
    {
      RBX::Analytics::InfluxDb::Points::Points( /*0x1410430b3*/
        this: (RBX::Analytics::InfluxDb::Points *)&durationAnalyticsPoint.pointList._List,
        throttleHundredthsPercentage: -1,
        categoryType: kStandardType,
        priorityHundredthsPercentage: 0);
      __wind /*0xf1c0000000000040*/
      {
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410430cb*/
          this: (RBX::Analytics::InfluxDb::Points *)&durationAnalyticsPoint.pointList._List,
          name: "Category",
          value: "DefaultLoadingScreenRemoved");
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410430e3*/
          this: (RBX::Analytics::InfluxDb::Points *)&durationAnalyticsPoint.pointList._List,
          name: "Duration",
          value: this->sgs.defaultLoadingGuiRemovedTime);
        v7 = RBX::ServiceProvider::find<RBX::ReplicatedFirst>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x1410430f0*/
        v7->getChildren2(this: v7, result: (std::shared_ptr<std::vector<std::shared_ptr<RBX::Instance>> const > *)&v13); /*0x141043106*/
        __wind /*0xf1c000000000001c*/
        {
          if ( v13 != nullptr ) /*0x141043111*/
            v4 = (__int64)(v13[1] - *v13) >> 4; /*0x14104311a*/
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x14104312c*/
            this: (RBX::Analytics::InfluxDb::Points *)&durationAnalyticsPoint.pointList._List,
            name: "ReplicatedFirstChildrenCount",
            value: v4);
          resource._Mypair._Myval2._Myres = 15; /*0x141043131*/
          resource._Mypair._Myval2._Mysize = 12; /*0x141043139*/
          strcpy(resource._Mypair._Myval2._Bx._Buf, "GameDuration"); /*0x141043149*/
          __wind /*0xf1c0000000000010*/
          {
            RBX::Analytics::InfluxDb::Points::report( /*0x14104316d*/
              this: (RBX::Analytics::InfluxDb::Points *)&durationAnalyticsPoint.pointList._List,
              &resource,
              throttleHundredthsPercentage: DFInt::JoinInfluxHundredthsPercentage,
              blocking: false);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000008*/
          }
          if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x14104317b*/
          {
            v8 = resource._Mypair._Myval2._Bx._Ptr; /*0x141043180*/
            if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104318e*/
            {
              v8 = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x141043194*/
              if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - v8 - 8) > 0x1F ) /*0x1410431a3*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410431a5*/
            }
            operator delete(ptr: v8); /*0x1410431ac*/
          }
          v9 = *(volatile signed __int32 **)&durationAnalyticsPoint.pointList._Traitsobj._Mypair._Myval2._Myval2; /*0x1410431b2*/
          if ( *(_QWORD *)&durationAnalyticsPoint.pointList._Traitsobj._Mypair._Myval2._Myval2 != 0 /*0x1410431c5*/
            && _InterlockedExchangeAdd(
                 (volatile signed __int32 *)(*(_QWORD *)&durationAnalyticsPoint.pointList._Traitsobj._Mypair._Myval2._Myval2
                                           + 8LL),
                 0xFFFFFFFF) == 1 )
          {
            (**(void (__fastcall ***)(volatile signed __int32 *))v9)(a1: v9); /*0x1410431cd*/
            if ( _InterlockedExchangeAdd(v9 + 3, 0xFFFFFFFF) == 1 ) /*0x1410431d7*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 8LL))(a1: v9); /*0x1410431df*/
          }
          if ( *(_QWORD *)&durationAnalyticsPoint.category >= 0x10u ) /*0x1410431eb*/
          {
            v10 = *(void **)&durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Bx._Alias[8]; /*0x1410431f0*/
            if ( (unsigned __int64)(*(_QWORD *)&durationAnalyticsPoint.category + 1LL) >= 0x1000 ) /*0x1410431fe*/
            {
              v10 = *(void **)(*(_QWORD *)&durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Bx._Alias[8] - 8LL); /*0x141043204*/
              if ( (unsigned __int64)(*(_QWORD *)&durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Bx._Alias[8] /*0x141043213*/
                                    - (_QWORD)v10
                                    - 8LL) > 0x1F )
                _invalid_parameter_noinfo_noreturn(); /*0x141043215*/
            }
            operator delete(ptr: v10); /*0x14104321c*/
          }
          *(__m128i *)&durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Myres = _mm_load_si128((const __m128i *)&_xmm); /*0x141043229*/
          durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Bx._Buf[8] = 0; /*0x14104322e*/
          std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&durationAnalyticsPoint.pointList._List); /*0x141043236*/
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v13); /*0xf1c000000000002c*/
        }
      }
      __unwind
      {
        RBX::Analytics::InfluxDb::Points::~Points(this: (RBX::Analytics::InfluxDb::Points *)&durationAnalyticsPoint.pointList._List); /*0xf1c0000000000038*/
      }
    }
  }
}

// Address: 0x141043260 | Name: ?onDisconnection@PlayerConfigurer@RBX@@AEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@_NV34@H@Z
void __fastcall RBX::PlayerConfigurer::onDisconnection(
        RBX::PlayerConfigurer *this,
        const std::string *peer,
        bool lostConnection,
        RBX::Graphics::ProfilerAdorn::Item *reason,
        int errorCode)
{
  RBX::Graphics::ProfilerAdorn::Item *v5; // rsi
  bool connectionFailed; // al
  unsigned __int64 v8; // r9
  unsigned __int64 Mysize; // r10
  RBX::Graphics::ProfilerAdorn::Item *v10; // r8
  unsigned __int64 Myres; // r11
  __int64 v12; // rcx
  unsigned __int8 v13; // al
  int v14; // eax
  const char *v15; // rdx
  _WORD *v16; // rax
  int v17; // ebx
  std::string *p_userMessage; // rdx
  unsigned __int64 v19; // r8
  char *v20; // rcx
  char *v21; // rcx
  char *v22; // rcx
  char *v23; // rcx
  unsigned __int64 v24; // r9
  unsigned __int64 v25; // r10
  RBX::Graphics::ProfilerAdorn::Item *v26; // r8
  unsigned __int64 v27; // r11
  __int64 v28; // rcx
  unsigned __int8 v29; // al
  int v30; // eax
  const char *v31; // rdx
  char *v32; // rax
  std::string *v33; // rdx
  unsigned __int64 v34; // r8
  char *v35; // rcx
  char *v36; // rcx
  RBX::DataModel *dataModel; // rax
  RBX::ServiceProvider *v38; // r14
  unsigned __int64 v39; // rax
  RBX::DescribedCreatable<RBX::MouseService,RBX::ServiceInstance> *v40; // rcx
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v41; // rbx
  const RBX::Name *v42; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::shared_ptr<RBX::Instance> *v44; // rax
  RBX::Instance *v45; // rcx
  RBX::Instance *FirstChildByName; // rbx
  char *v47; // rcx
  RBX::Visit *v48; // r14
  int ParamInt; // ebx
  char *Ptr; // rcx
  char *v51; // rcx
  std::string *p_pingUrl; // r8
  char *v53; // rcx
  std::string errorType; // [rsp+30h] [rbp-118h] BYREF
  std::string userMessage; // [rsp+50h] [rbp-F8h] BYREF
  std::string url; // [rsp+70h] [rbp-D8h] BYREF
  std::string errorCategory; // [rsp+90h] [rbp-B8h] BYREF
  std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > > _Parg; // [rsp+B0h] [rbp-98h] BYREF
  std::string pingUrl; // [rsp+B8h] [rbp-90h] BYREF
  RBX::HttpOptions v60; // [rsp+D8h] [rbp-70h] BYREF
  std::allocator<std::pair<std::string const ,std::string > > _Al; // [rsp+158h] [rbp+10h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *v62; // [rsp+168h] [rbp+20h]

  v62 = reason; /*0x14104326a*/
  __wind
  {
    v5 = reason; /*0x14104327b*/
    if ( peer->_Mypair._Myval2._Mysize == 0 ) /*0x141043286*/
    {
LABEL_97:
      if ( !this->testing ) /*0x1410439d1*/
      {
        v48 = RBX::ServiceProvider::create<RBX::Visit>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x1410439e4*/
        if ( RBX::Visit::hasPingThread(this: v48) ) /*0x1410439ea*/
        {
          url._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410439f7*/
          url._Mypair._Myval2._Mysize = 0; /*0x1410439fc*/
          url._Mypair._Myval2._Myres = 15; /*0x141043a04*/
          std::string::assign(this: &url, _Ptr: "PingInterval", _Count: 0xCu); /*0x141043a27*/
          __wind /*0xf1c00000000000ac*/
          {
            ParamInt = RBX::GameConfigurer::getParamInt(this, key: &url); /*0x141043a3a*/
            errorCategory._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141043a3c*/
            errorCategory._Mypair._Myval2._Mysize = 0; /*0x141043a44*/
            errorCategory._Mypair._Myval2._Myres = 15; /*0x141043a4c*/
            std::string::assign(this: &errorCategory, _Ptr: pass, _Count: 0); /*0x141043a6a*/
            RBX::Visit::setPing(this: v48, url: &errorCategory, interval: ParamInt); /*0x141043a7d*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&url); /*0xf1c00000000000a4*/
          }
          if ( url._Mypair._Myval2._Myres >= 0x10 ) /*0x141043a8f*/
          {
            Ptr = url._Mypair._Myval2._Bx._Ptr; /*0x141043a94*/
            if ( url._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141043aa3*/
            {
              Ptr = *((char **)url._Mypair._Myval2._Bx._Ptr - 1); /*0x141043aa9*/
              if ( (unsigned __int64)(url._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141043ab8*/
                _invalid_parameter_noinfo_noreturn(); /*0x141043aba*/
            }
            operator delete(ptr: Ptr); /*0x141043ac1*/
          }
        }
      }
      errorType._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141043ac6*/
      errorType._Mypair._Myval2._Mysize = 0; /*0x141043acb*/
      errorType._Mypair._Myval2._Myres = 15; /*0x141043ad0*/
      std::string::assign(this: &errorType, _Ptr: "PingUrl", _Count: 7u); /*0x141043af0*/
      __eh34_enter_wind_state(0, 5); /*0xf1c0000000000098*/
      RBX::GameConfigurer::getParamString(this, result: &pingUrl, key: &errorType); /*0x141043b06*/
      if ( __eh34_unwind(5) ) /*0xf1c0000000000118*/
        goto unwind_state_5; /*0xf1c0000000000118*/
      __eh34_exit_wind_state(5, 0); /*0xf1c000000000011c*/
      __eh34_enter_wind_state(0, 8); /*0xf1c0000000000120*/
      if ( errorType._Mypair._Myval2._Myres >= 0x10 ) /*0x141043b15*/
      {
        v51 = errorType._Mypair._Myval2._Bx._Ptr; /*0x141043b1a*/
        if ( errorType._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141043b29*/
        {
          v51 = *((char **)errorType._Mypair._Myval2._Bx._Ptr - 1); /*0x141043b2f*/
          if ( (unsigned __int64)(errorType._Mypair._Myval2._Bx._Ptr - v51 - 8) > 0x1F ) /*0x141043b3e*/
            _invalid_parameter_noinfo_noreturn(); /*0x141043b40*/
        }
        operator delete(ptr: v51); /*0x141043b47*/
      }
      errorType._Mypair._Myval2._Mysize = 0; /*0x141043b4c*/
      errorType._Mypair._Myval2._Myres = 15; /*0x141043b51*/
      errorType._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141043b5a*/
      if ( pingUrl._Mypair._Myval2._Mysize == 0 ) /*0x141043b68*/
      {
        if ( pingUrl._Mypair._Myval2._Myres >= 0x10 ) /*0x141043b76*/
          std::allocator<RBX::Voxel2::Mesher::Quad>::deallocate( /*0x141043b8f*/
            this: (std::allocator<signed char> *)&pingUrl,
            _Ptr: pingUrl._Mypair._Myval2._Bx._Ptr,
            _Count: pingUrl._Mypair._Myval2._Myres + 1);
        if ( __eh34_unwind(8) ) /*0xf1c000000000002c*/
          goto unwind_state_8; /*0xf1c000000000002c*/
        __eh34_exit_wind_state(8, 0); /*0xf1c0000000000038*/
        goto LABEL_121; /*0xf1c000000000003c*/
      }
      p_pingUrl = &pingUrl; /*0x141043b99*/
      if ( pingUrl._Mypair._Myval2._Myres >= 0x10 ) /*0x141043baa*/
        p_pingUrl = (std::string *)pingUrl._Mypair._Myval2._Bx._Ptr; /*0x141043baa*/
      try /*0xf1c000000000008c*/
      {
        RBX::format(result: &url, fmt: "%s&disconnect=true", p_pingUrl->_Mypair._Myval2._Bx._Buf); /*0x141043bbf*/
        __wind /*0xf1c0000000000080*/
        {
          LODWORD(_Parg._Mypair._Myval2._Myval2) = 0; /*0x141043bc8*/
          std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>( /*0x141043be9*/
            this: &v60.headers,
            &_Parg,
            &_Al);
          __wind /*0xf1c000000000004c*/
          {
            *(_QWORD *)&v60.cachePolicy = 0; /*0x141043bee*/
            v60.external = false; /*0x141043bfa*/
            RBX::HttpAsync::get(result: (boost::shared_future<std::string > *)&userMessage, &url, options: &v60); /*0x141043c14*/
            boost::detail::shared_count::~shared_count(this: (boost::detail::shared_count *)&userMessage._Mypair._Myval2._Bx._Alias[8]); /*0x141043c1e*/
            std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&v60); /*0x141043c2c*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&url); /*0x141043c37*/
          }
          __unwind
          {
            std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &v60); /*0xf1c000000000005c*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&url); /*0xf1c0000000000068*/
        }
      }
      catch ( std::exception )
      {
        v5 = v62; /*0x141043c41*/
      }
      if ( __eh34_unwind(8) ) /*0xf1c0000000000040*/
      {
unwind_state_8:
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&pingUrl); /*0xf1c0000000000030*/
        __eh34_continue_unwinding(8, 0); /*0xf1c0000000000034*/
      }
      __eh34_exit_wind_state(8, 0); /*0xf1c0000000000044*/
      if ( pingUrl._Mypair._Myval2._Myres < 0x10 ) /*0x141043c55*/
        goto LABEL_121; /*0x141043c55*/
      v53 = pingUrl._Mypair._Myval2._Bx._Ptr; /*0x141043c5a*/
      if ( pingUrl._Mypair._Myval2._Myres + 1 < 0x1000 /*0x141043c81*/
        || (v53 = *((char **)pingUrl._Mypair._Myval2._Bx._Ptr - 1),
            (unsigned __int64)(pingUrl._Mypair._Myval2._Bx._Ptr - v53 - 8) <= 0x1F) )
      {
        operator delete(ptr: v53); /*0x141043c8a*/
LABEL_121:
        pingUrl._Mypair._Myval2._Mysize = 0; /*0x141043c8f*/
        pingUrl._Mypair._Myval2._Myres = 15; /*0x141043c97*/
        pingUrl._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141043ca3*/
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: v5); /*0x141043cae*/
        return; /*0x141043cae*/
      }
LABEL_119:
      _invalid_parameter_noinfo_noreturn(); /*0x141043c83*/
    }
    __eh34_enter_wind_state(0, 1); /*0xf1c0000000000104*/
    connectionFailed = this->connectionFailed; /*0x14104328c*/
    if ( lostConnection )
    {
      if ( !connectionFailed )
      {
        userMessage._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410432a3*/
        userMessage._Mypair._Myval2._Mysize = 0; /*0x1410432a8*/
        v8 = 15; /*0x1410432ad*/
        userMessage._Mypair._Myval2._Myres = 15; /*0x1410432b3*/
        Mysize = v5->text._Mypair._Myval2._Mysize; /*0x1410432bd*/
        if ( Mysize == 0 ) /*0x1410432c4*/
          goto LABEL_19; /*0x1410432c4*/
        v10 = v5; /*0x1410432c6*/
        Myres = v5->text._Mypair._Myval2._Myres; /*0x1410432c9*/
        if ( Myres >= 0x10 ) /*0x1410432d1*/
          v10 = (RBX::Graphics::ProfilerAdorn::Item *)v5->text._Mypair._Myval2._Bx._Ptr; /*0x1410432d3*/
        if ( Mysize != 4 ) /*0x1410432da*/
          goto LABEL_15; /*0x1410432da*/
        v12 = 0; /*0x1410432dc*/
        while ( 1 ) /*0x1410432f0*/
        {
          v13 = v10->text._Mypair._Myval2._Bx._Buf[v12++]; /*0x1410432f0*/
          if ( v13 != aNone_7[v12 - 1] ) /*0x1410432fc*/
            break; /*0x1410432fc*/
          if ( v12 == 4 ) /*0x141043302*/
          {
            v14 = 0; /*0x141043304*/
            goto LABEL_14; /*0x141043306*/
          }
        }
        v14 = v13 < (unsigned int)aNone_7[v12 - 1] ? -1 : 1;
LABEL_14:
        if ( v14 != 0 ) /*0x14104330f*/
        {
LABEL_15:
          if ( &userMessage != (std::string *)v5 ) /*0x141043319*/
          {
            v15 = (const char *)v5; /*0x14104331f*/
            if ( Myres >= 0x10 ) /*0x141043326*/
              v15 = v5->text._Mypair._Myval2._Bx._Ptr; /*0x141043328*/
            std::string::assign(this: &userMessage, _Ptr: v15, _Count: v5->text._Mypair._Myval2._Mysize); /*0x141043333*/
            v8 = userMessage._Mypair._Myval2._Myres; /*0x141043338*/
          }
        }
        else
        {
LABEL_19:
          v16 = operator new(size: 0x70u); /*0x141043347*/
          userMessage._Mypair._Myval2._Mysize = 109; /*0x14104334f*/
          v8 = 111; /*0x141043358*/
          userMessage._Mypair._Myval2._Myres = 111; /*0x14104335e*/
          qmemcpy( /*0x14104336a*/
            v16,
            "You have lost connection to the game server, please close the Window and click \"Play\" again on the game page",
            108);
          v16[54] = (unsigned __int8)aYouHaveLostCon[108]; /*0x1410433c1*/
          userMessage._Mypair._Myval2._Bx._Ptr = (char *)v16; /*0x1410433c8*/
        }
        v17 = 256; /*0x1410433cd*/
        if ( errorCode > 0 ) /*0x1410433db*/
          v17 = errorCode; /*0x1410433db*/
        errorCategory._Mypair._Myval2._Myres = 15; /*0x1410433de*/
        errorCategory._Mypair._Myval2._Mysize = 14; /*0x1410433ea*/
        strcpy(errorCategory._Mypair._Myval2._Bx._Buf, "LostConnection"); /*0x1410433fe*/
        __eh34_enter_wind_state(1, 2); /*0xf1c00000000000fc*/
        errorType._Mypair._Myval2._Myres = 15; /*0x14104342b*/
        errorType._Mypair._Myval2._Mysize = 14; /*0x141043434*/
        strcpy(errorType._Mypair._Myval2._Bx._Buf, "LostConnection"); /*0x14104343d*/
        p_userMessage = &userMessage; /*0x141043451*/
        if ( v8 >= 0x10 ) /*0x14104345a*/
          p_userMessage = (std::string *)userMessage._Mypair._Myval2._Bx._Ptr; /*0x14104345a*/
        url._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141043460*/
        url._Mypair._Myval2._Mysize = 0; /*0x141043465*/
        url._Mypair._Myval2._Myres = 15; /*0x14104346d*/
        v19 = -1; /*0x14104347e*/
        do /*0x14104348d*/
          ++v19; /*0x141043485*/
        while ( p_userMessage->_Mypair._Myval2._Bx._Buf[v19] != 0 ); /*0x14104348d*/
        __eh34_enter_wind_state(2, 3); /*0xf1c00000000000f4*/
        std::string::assign(this: &url, _Ptr: p_userMessage->_Mypair._Myval2._Bx._Buf, _Count: v19); /*0x141043494*/
        __eh34_enter_wind_state(3, 4); /*0xf1c00000000000ec*/
        RBX::PlayerConfigurer::showErrorWindow(this, message: &url, &errorType, &errorCategory, errorCode: v17); /*0x1410434b3*/
        if ( url._Mypair._Myval2._Myres >= 0x10 ) /*0x1410434c5*/
        {
          v20 = url._Mypair._Myval2._Bx._Ptr; /*0x1410434ca*/
          if ( url._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410434d9*/
          {
            v20 = *((char **)url._Mypair._Myval2._Bx._Ptr - 1); /*0x1410434df*/
            if ( (unsigned __int64)(url._Mypair._Myval2._Bx._Ptr - v20 - 8) > 0x1F ) /*0x1410434ee*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410434f0*/
          }
          operator delete(ptr: v20); /*0x1410434f7*/
        }
        if ( errorType._Mypair._Myval2._Myres >= 0x10 ) /*0x141043506*/
        {
          v21 = errorType._Mypair._Myval2._Bx._Ptr; /*0x14104350b*/
          if ( errorType._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104351a*/
          {
            v21 = *((char **)errorType._Mypair._Myval2._Bx._Ptr - 1); /*0x141043520*/
            if ( (unsigned __int64)(errorType._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x14104352f*/
              _invalid_parameter_noinfo_noreturn(); /*0x141043531*/
          }
          operator delete(ptr: v21); /*0x141043538*/
        }
        errorType._Mypair._Myval2._Mysize = 0; /*0x14104353d*/
        errorType._Mypair._Myval2._Myres = 15; /*0x141043542*/
        errorType._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104354b*/
        if ( errorCategory._Mypair._Myval2._Myres >= 0x10 ) /*0x14104355c*/
        {
          v22 = errorCategory._Mypair._Myval2._Bx._Ptr; /*0x141043561*/
          if ( errorCategory._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141043573*/
          {
            v22 = *((char **)errorCategory._Mypair._Myval2._Bx._Ptr - 1); /*0x141043579*/
            if ( (unsigned __int64)(errorCategory._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x141043588*/
              _invalid_parameter_noinfo_noreturn(); /*0x14104358a*/
          }
LABEL_40:
          operator delete(ptr: v22); /*0x141043591*/
          goto LABEL_41; /*0x141043591*/
        }
        goto LABEL_41; /*0x14104355c*/
      }
    }
    else if ( !connectionFailed )
    {
      userMessage._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410435e7*/
      userMessage._Mypair._Myval2._Mysize = 0; /*0x1410435ec*/
      v24 = 15; /*0x1410435f1*/
      userMessage._Mypair._Myval2._Myres = 15; /*0x1410435f7*/
      v25 = v5->text._Mypair._Myval2._Mysize; /*0x141043601*/
      if ( v25 == 0 ) /*0x141043608*/
        goto LABEL_61; /*0x141043608*/
      v26 = v5; /*0x14104360a*/
      v27 = v5->text._Mypair._Myval2._Myres; /*0x14104360d*/
      if ( v27 >= 0x10 ) /*0x141043615*/
        v26 = (RBX::Graphics::ProfilerAdorn::Item *)v5->text._Mypair._Myval2._Bx._Ptr; /*0x141043617*/
      if ( v25 != 4 ) /*0x14104361e*/
        goto LABEL_57; /*0x14104361e*/
      v28 = 0; /*0x141043620*/
      while ( 1 ) /*0x141043630*/
      {
        v29 = v26->text._Mypair._Myval2._Bx._Buf[v28++]; /*0x141043630*/
        if ( v29 != aNone_7[v28 - 1] ) /*0x14104363c*/
          break; /*0x14104363c*/
        if ( v28 == 4 ) /*0x141043642*/
        {
          v30 = 0; /*0x141043644*/
          goto LABEL_56; /*0x141043646*/
        }
      }
      v30 = v29 < (unsigned int)aNone_7[v28 - 1] ? -1 : 1;
LABEL_56:
      if ( v30 != 0 ) /*0x14104364f*/
      {
LABEL_57:
        if ( &userMessage != (std::string *)v5 ) /*0x141043659*/
        {
          v31 = (const char *)v5; /*0x14104365b*/
          if ( v27 >= 0x10 ) /*0x141043662*/
            v31 = v5->text._Mypair._Myval2._Bx._Ptr; /*0x141043664*/
          std::string::assign(this: &userMessage, _Ptr: v31, _Count: v5->text._Mypair._Myval2._Mysize); /*0x14104366f*/
          v24 = userMessage._Mypair._Myval2._Myres; /*0x141043674*/
        }
      }
      else
      {
LABEL_61:
        v32 = (char *)operator new(size: 0x40u); /*0x141043680*/
        userMessage._Mypair._Myval2._Mysize = 48; /*0x141043685*/
        v24 = 63; /*0x14104368e*/
        userMessage._Mypair._Myval2._Myres = 63; /*0x141043694*/
        strcpy(v32, "This game server has shut down, please reconnect"); /*0x1410436a0*/
        userMessage._Mypair._Myval2._Bx._Ptr = v32; /*0x1410436bd*/
      }
      errorCategory._Mypair._Myval2._Myres = 15; /*0x1410436ca*/
      errorCategory._Mypair._Myval2._Mysize = 4; /*0x1410436d6*/
      errorCategory._Mypair._Myval2._Bx._Ptr = (char *)1801677131; /*0x1410436e2*/
      __eh34_enter_wind_state(1, 2); /*0xf1c00000000000e4*/
      errorType._Mypair._Myval2._Myres = 15; /*0x1410436fa*/
      errorType._Mypair._Myval2._Mysize = 4; /*0x141043703*/
      errorType._Mypair._Myval2._Bx._Ptr = (char *)1801677131; /*0x14104370c*/
      v33 = &userMessage; /*0x141043719*/
      if ( v24 >= 0x10 ) /*0x141043722*/
        v33 = (std::string *)userMessage._Mypair._Myval2._Bx._Ptr; /*0x141043722*/
      url._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141043728*/
      url._Mypair._Myval2._Mysize = 0; /*0x14104372d*/
      url._Mypair._Myval2._Myres = 15; /*0x141043735*/
      v34 = -1; /*0x141043746*/
      do /*0x141043758*/
        ++v34; /*0x141043750*/
      while ( v33->_Mypair._Myval2._Bx._Buf[v34] != 0 ); /*0x141043758*/
      __eh34_enter_wind_state(2, 3); /*0xf1c00000000000dc*/
      std::string::assign(this: &url, _Ptr: v33->_Mypair._Myval2._Bx._Buf, _Count: v34); /*0x14104375f*/
      __eh34_enter_wind_state(3, 4); /*0xf1c00000000000d4*/
      RBX::PlayerConfigurer::showErrorWindow(this, message: &url, &errorType, &errorCategory, errorCode); /*0x141043785*/
      if ( url._Mypair._Myval2._Myres >= 0x10 ) /*0x141043797*/
      {
        v35 = url._Mypair._Myval2._Bx._Ptr; /*0x14104379c*/
        if ( url._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410437ab*/
        {
          v35 = *((char **)url._Mypair._Myval2._Bx._Ptr - 1); /*0x1410437b1*/
          if ( (unsigned __int64)(url._Mypair._Myval2._Bx._Ptr - v35 - 8) > 0x1F ) /*0x1410437c0*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410437c2*/
        }
        operator delete(ptr: v35); /*0x1410437c9*/
      }
      if ( errorType._Mypair._Myval2._Myres >= 0x10 ) /*0x1410437d8*/
      {
        v36 = errorType._Mypair._Myval2._Bx._Ptr; /*0x1410437dd*/
        if ( errorType._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410437ec*/
        {
          v36 = *((char **)errorType._Mypair._Myval2._Bx._Ptr - 1); /*0x1410437f2*/
          if ( (unsigned __int64)(errorType._Mypair._Myval2._Bx._Ptr - v36 - 8) > 0x1F ) /*0x141043801*/
            _invalid_parameter_noinfo_noreturn(); /*0x141043803*/
        }
        operator delete(ptr: v36); /*0x14104380a*/
      }
      errorType._Mypair._Myval2._Mysize = 0; /*0x14104380f*/
      errorType._Mypair._Myval2._Myres = 15; /*0x141043814*/
      errorType._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104381d*/
      if ( errorCategory._Mypair._Myval2._Myres >= 0x10 ) /*0x14104382e*/
      {
        v22 = errorCategory._Mypair._Myval2._Bx._Ptr; /*0x141043833*/
        if ( errorCategory._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141043845*/
        {
          v22 = *((char **)errorCategory._Mypair._Myval2._Bx._Ptr - 1); /*0x14104384b*/
          if ( (unsigned __int64)(errorCategory._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x14104385a*/
            _invalid_parameter_noinfo_noreturn(); /*0x14104385c*/
        }
        goto LABEL_40; /*0x14104385a*/
      }
LABEL_41:
      if ( userMessage._Mypair._Myval2._Myres >= 0x10 ) /*0x1410435a0*/
      {
        if ( __eh34_unwind(4) ) /*0xf1c000000000017c*/
          goto unwind_state_4; /*0xf1c000000000017c*/
        __eh34_exit_wind_state(4, 3); /*0xf1c0000000000180*/
        if ( __eh34_unwind(3) ) /*0xf1c0000000000184*/
          goto unwind_state_3; /*0xf1c0000000000184*/
        __eh34_exit_wind_state(3, 2); /*0xf1c0000000000188*/
        if ( __eh34_unwind(2) ) /*0xf1c000000000018c*/
          goto unwind_state_2; /*0xf1c000000000018c*/
        __eh34_exit_wind_state(2, 1); /*0xf1c0000000000190*/
        if ( __eh34_unwind(1) ) /*0xf1c0000000000194*/
          goto unwind_state_1; /*0xf1c0000000000194*/
        __eh34_exit_wind_state(1, 0); /*0xf1c0000000000198*/
        v23 = userMessage._Mypair._Myval2._Bx._Ptr; /*0x1410435a9*/
        if ( userMessage._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410435b8*/
        {
          v23 = *((char **)userMessage._Mypair._Myval2._Bx._Ptr - 1); /*0x1410435be*/
          if ( (unsigned __int64)(userMessage._Mypair._Myval2._Bx._Ptr - v23 - 8) > 0x1F ) /*0x1410435cd*/
            goto LABEL_119; /*0x1410435cd*/
        }
        operator delete(ptr: v23); /*0x1410435d3*/
        goto LABEL_80; /*0x1410435d8*/
      }
      if ( __eh34_unwind(4) ) /*0xf1c0000000000138*/
      {
unwind_state_4:
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&url); /*0xf1c000000000013c*/
        __eh34_continue_unwinding(4, 3); /*0xf1c0000000000140*/
      }
LABEL_154:
      __eh34_exit_wind_state(4, 3); /*0xf1c0000000000144*/
      if ( __eh34_unwind(3) ) /*0xf1c0000000000148*/
      {
unwind_state_3:
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&errorType); /*0xf1c000000000014c*/
        __eh34_continue_unwinding(3, 2); /*0xf1c0000000000150*/
      }
      __eh34_exit_wind_state(3, 2); /*0xf1c0000000000154*/
      if ( __eh34_unwind(2) ) /*0xf1c0000000000158*/
      {
unwind_state_2:
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&errorCategory); /*0xf1c000000000015c*/
        __eh34_continue_unwinding(2, 1); /*0xf1c0000000000160*/
      }
      __eh34_exit_wind_state(2, 1); /*0xf1c0000000000164*/
      if ( __eh34_unwind(1) ) /*0xf1c0000000000168*/
      {
unwind_state_1:
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&userMessage); /*0xf1c000000000016c*/
        __eh34_continue_unwinding(1, 0); /*0xf1c0000000000170*/
      }
      __eh34_exit_wind_state(1, 0); /*0xf1c0000000000174*/
LABEL_80:
      dataModel = this->dataModel; /*0x141043870*/
      if ( dataModel != nullptr ) /*0x141043877*/
      {
        if ( FFlag::UnlockMouseIfKicked.value ) /*0x141043884*/
        {
          v38 = &dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>; /*0x141043886*/
          boost::call_once( /*0x141043898*/
            flag: &`RBX::ServiceProvider::getClassIndex<RBX::MouseService>'::`2'::flag,
            f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::MouseService>);
          v39 = RBX::ServiceProvider::doGetClassIndex<RBX::MouseService>(); /*0x14104389d*/
          v41 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt( /*0x1410438ad*/
                                                                                     this: v38,
                                                                                     index: v39);
          if ( v41->_Ptr == nullptr ) /*0x1410438b4*/
          {
            v42 = RBX::Reflection::Class_getNamePtr<RBX::MouseService>(this: v40); /*0x1410438b6*/
            ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName(this: v38, result: (std::shared_ptr<RBX::Instance> *)&userMessage, className: v42); /*0x1410438c6*/
            std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v41, _Right: ServiceByClassName); /*0x1410438d1*/
            if ( *(_QWORD *)&userMessage._Mypair._Myval2._Bx._Alias[8] != 0 ) /*0x1410438de*/
              std::_Ref_count_base::_Decref(this: *(std::_Ref_count_base **)&userMessage._Mypair._Myval2._Bx._Alias[8]); /*0x1410438e0*/
          }
          if ( v41->_Ptr != nullptr ) /*0x1410438eb*/
            RBX::MouseService::setMouseType(this: (RBX::MouseService *)v41->_Ptr, value: MOUSETYPE_DEFAULT); /*0x1410438ef*/
        }
        v44 = RBX::ServiceProvider::refByClass<RBX::Players>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x1410438fc*/
        if ( v44->_Ptr != nullptr ) /*0x141043907*/
        {
          v45 = *(RBX::Instance **)&v44->_Ptr[2].completeness.numLocalReplicatedChildren; /*0x14104390d*/
          if ( v45 != nullptr ) /*0x141043917*/
          {
            errorType._Mypair._Myval2._Myres = 15; /*0x14104391d*/
            errorType._Mypair._Myval2._Mysize = 13; /*0x141043926*/
            qmemcpy(&errorType, "PlayerScript", 12); /*0x141043937*/
            *(_WORD *)&errorType._Mypair._Myval2._Bx._Alias[12] = (unsigned __int8)aPlayerscripts[12]; /*0x14104394e*/
            __eh34_enter_wind_state(0, 5); /*0xf1c00000000000cc*/
            FirstChildByName = RBX::Instance::findFirstChildByName( /*0x141043964*/
                                 this: v45,
                                 findName: &errorType,
                                 doSecurityCheck: false);
            if ( __eh34_unwind(5) ) /*0xf1c00000000000b8*/
            {
unwind_state_5:
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&errorType); /*0xf1c00000000000bc*/
              __eh34_continue_unwinding(5, 0); /*0xf1c00000000000c0*/
            }
            __eh34_exit_wind_state(5, 0); /*0xf1c00000000000c4*/
            if ( errorType._Mypair._Myval2._Myres >= 0x10 ) /*0x141043970*/
            {
              v47 = errorType._Mypair._Myval2._Bx._Ptr; /*0x141043975*/
              if ( errorType._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141043984*/
              {
                v47 = *((char **)errorType._Mypair._Myval2._Bx._Ptr - 1); /*0x14104398a*/
                if ( (unsigned __int64)(errorType._Mypair._Myval2._Bx._Ptr - v47 - 8) > 0x1F ) /*0x141043999*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14104399b*/
              }
              operator delete(ptr: v47); /*0x1410439a2*/
            }
            errorType._Mypair._Myval2._Mysize = 0; /*0x1410439a7*/
            errorType._Mypair._Myval2._Myres = 15; /*0x1410439ac*/
            errorType._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410439b5*/
            if ( FirstChildByName != nullptr ) /*0x1410439bd*/
              FirstChildByName->destroy(this: FirstChildByName); /*0x1410439c5*/
          }
        }
      }
      goto LABEL_97; /*0x1410439c5*/
    }
    __eh34_enter_wind_state(1, 2); /*0xf1c0000000000128*/
    __eh34_enter_wind_state(2, 3); /*0xf1c000000000012c*/
    __eh34_enter_wind_state(3, 4); /*0xf1c0000000000130*/
    goto LABEL_154; /*0xf1c0000000000130*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: v62); /*0xf1c0000000000024*/
  }
}

// Address: 0x141043cd0 | Name: ?onGameClose@PlayerConfigurer@RBX@@AEAAXXZ
void __fastcall RBX::PlayerConfigurer::onGameClose(RBX::PlayerConfigurer *this)
{
  long double v2; // xmm3_8
  char *v3; // rcx
  char *v4; // rcx
  long double v5; // xmm6_8
  char *Ptr; // rcx
  char *v7; // rcx
  std::string *v8; // r8
  const std::string *v9; // rax
  char *v10; // rcx
  char *v11; // rcx
  __int64 userId; // rcx
  std::unordered_set<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<std::string,std::string > > > *v13; // rax
  std::unordered_map<std::string,std::string> *v14; // rbx
  double v15; // xmm0_8
  long double v16; // xmm6_8
  char *v17; // rcx
  char *v18; // rcx
  char *v19; // rcx
  char *v20; // rcx
  std::_List_node<std::pair<std::string const ,std::string >,void *> *v21; // rax
  const char *v22; // r14
  const char *v23; // r15
  std::string *p_second; // rcx
  unsigned __int64 v25; // r8
  char *v26; // rcx
  std::string *v27; // rcx
  unsigned __int64 v28; // rsi
  char *v29; // rcx
  std::string result; // [rsp+30h] [rbp-D0h] BYREF
  std::string category; // [rsp+50h] [rbp-B0h] BYREF
  std::string v32; // [rsp+70h] [rbp-90h] BYREF
  std::unordered_map<std::string,std::string> eventArgs; // [rsp+90h] [rbp-70h] BYREF
  std::unordered_set<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<std::string,std::string > > > v34; // [rsp+D0h] [rbp-30h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *_Al; // [rsp+160h] [rbp+60h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *_Parg; // [rsp+168h] [rbp+68h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *p_category; // [rsp+170h] [rbp+70h]

  if ( this->connectResolved ) /*0x141043cf2*/
  {
    if ( this->loadResolved && this->joinResolved ) /*0x141043e5e*/
    {
      if ( !this->playResolved ) /*0x141043e6c*/
      {
        v5 = RBX::Time::nowFastSec() - this->sgs.userClickTime - this->sgs.gameJoinTime; /*0x141043e7f*/
        this->playResolved = true; /*0x141043e87*/
        result._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141043e8d*/
        result._Mypair._Myval2._Mysize = 0; /*0x141043e92*/
        result._Mypair._Myval2._Myres = 15; /*0x141043e97*/
        std::string::assign(this: &result, _Ptr: aSucc_0, _Count: 7u); /*0x141043eb5*/
        __eh34_enter_wind_state(-1, 0); /*0xf1c000000000018c*/
        category._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141043ebb*/
        category._Mypair._Myval2._Mysize = 0; /*0x141043ec0*/
        category._Mypair._Myval2._Myres = 15; /*0x141043ec5*/
        std::string::assign(this: &category, _Ptr: "GameDuration", _Count: 0xCu); /*0x141043ee3*/
        __eh34_enter_wind_state(0, 1); /*0xf1c0000000000184*/
        RBX::PlayerConfigurer::reportDuration(this, &category, &result, duration: v5); /*0x141043ef9*/
        if ( __eh34_unwind(1) ) /*0xf1c0000000000178*/
        {
unwind_state_1:
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&category); /*0xf1c0000000000144*/
          __eh34_continue_unwinding(1, 0); /*0xf1c0000000000148*/
        }
        __eh34_exit_wind_state(1, 0); /*0xf1c000000000017c*/
        if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x141043f08*/
        {
          Ptr = category._Mypair._Myval2._Bx._Ptr; /*0x141043f0d*/
          if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141043f1c*/
          {
            Ptr = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x141043f22*/
            if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141043f31*/
              _invalid_parameter_noinfo_noreturn(); /*0x141043f33*/
          }
          operator delete(ptr: Ptr); /*0x141043f3a*/
        }
        category._Mypair._Myval2._Mysize = 0; /*0x141043f3f*/
        category._Mypair._Myval2._Myres = 15; /*0x141043f44*/
        category._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141043f4d*/
        if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141043f5b*/
        {
          v7 = result._Mypair._Myval2._Bx._Ptr; /*0x141043f60*/
          if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141043f6f*/
          {
            v7 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x141043f75*/
            if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v7 - 8) > 0x1F ) /*0x141043f84*/
              _invalid_parameter_noinfo_noreturn(); /*0x141043f86*/
          }
          operator delete(ptr: v7); /*0x141043f8d*/
        }
        if ( __eh34_unwind(0) ) /*0xf1c000000000016c*/
        {
unwind_state_0:
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000110*/
          __eh34_propagate_exception_into_caller(0, -1); /*0xf1c0000000000114*/
        }
        __eh34_exit_wind_state(0, -1); /*0xf1c0000000000170*/
        result._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141043f92*/
        result._Mypair._Myval2._Mysize = 0; /*0x141043f97*/
        result._Mypair._Myval2._Myres = 15; /*0x141043f9c*/
        std::string::assign(this: &result, _Ptr: aSucc_0, _Count: 7u); /*0x141043fbc*/
        __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000164*/
        __eh34_enter_wind_state(0, 1); /*0xf1c000000000015c*/
        v8 = RBX::SystemUtil::osPlatform(result: &category); /*0x141043fcd*/
        v9 = std::operator+<char>(result: &v32, _Left: "GameDuration_", _Right: v8); /*0x141043fdc*/
        __wind /*0xf1c0000000000128*/
        {
          RBX::PlayerConfigurer::reportDuration(this, category: v9, &result, duration: v5); /*0x141043ff0*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v32); /*0x141043ffb*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&category); /*0x141044006*/
          if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141044015*/
          {
            v10 = result._Mypair._Myval2._Bx._Ptr; /*0x14104401a*/
            if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141044029*/
            {
              v10 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14104402f*/
              if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v10 - 8) > 0x1F ) /*0x14104403e*/
                _invalid_parameter_noinfo_noreturn(); /*0x141044040*/
            }
            operator delete(ptr: v10); /*0x141044047*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v32); /*0xf1c0000000000138*/
        }
        if ( __eh34_unwind(1) ) /*0xf1c0000000000140*/
          goto unwind_state_1; /*0xf1c0000000000140*/
        __eh34_exit_wind_state(1, 0); /*0xf1c000000000014c*/
        if ( __eh34_unwind(0) ) /*0xf1c0000000000150*/
          goto unwind_state_0; /*0xf1c0000000000150*/
        __eh34_exit_wind_state(0, -1); /*0xf1c0000000000154*/
        result._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14104404c*/
        result._Mypair._Myval2._Mysize = 0; /*0x141044051*/
        result._Mypair._Myval2._Myres = 15; /*0x141044056*/
        std::string::assign(this: &result, _Ptr: "LeftGame", _Count: 8u); /*0x141044076*/
        __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000120*/
        RBX::Stats::reportGameStatus(status: &result, blocking: false); /*0x141044083*/
        if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141044092*/
        {
          v11 = result._Mypair._Myval2._Bx._Ptr; /*0x141044097*/
          if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410440a6*/
          {
            v11 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x1410440ac*/
            if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v11 - 8) > 0x1F ) /*0x1410440bb*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410440bd*/
          }
          operator delete(ptr: v11); /*0x1410440c4*/
        }
        if ( __eh34_unwind(0) ) /*0xf1c000000000010c*/
          goto unwind_state_0; /*0xf1c000000000010c*/
        __eh34_exit_wind_state(0, -1); /*0xf1c0000000000118*/
        userId = this->userId; /*0x1410440c9*/
        if ( userId > 0 && userId % 1000 < DFInt::ClientJoinProcessPositiveSamplesThousandths ) /*0x141044105*/
        {
          _Al = (RBX::Graphics::ProfilerAdorn::Item *)&v34; /*0x14104410f*/
          v13 = std::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>(this: &v34); /*0x141044117*/
          __wind /*0xf1c0000000000100*/
          {
            v14 = (std::unordered_map<std::string,std::string> *)v13; /*0x14104411c*/
            _Parg = (RBX::Graphics::ProfilerAdorn::Item *)&result; /*0x141044124*/
            result._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141044128*/
            result._Mypair._Myval2._Mysize = 0; /*0x14104412d*/
            result._Mypair._Myval2._Myres = 15; /*0x141044132*/
            std::string::assign(this: &result, _Ptr: "GameLeaving", _Count: 0xBu); /*0x14104414d*/
            __wind /*0xf1c00000000000f4*/
            {
              p_category = (RBX::Graphics::ProfilerAdorn::Item *)&category; /*0x141044158*/
              category._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14104415c*/
              category._Mypair._Myval2._Mysize = 0; /*0x141044161*/
              category._Mypair._Myval2._Myres = 15; /*0x141044166*/
              std::string::assign(this: &category, _Ptr: "report", _Count: 6u); /*0x141044181*/
              __wind /*0xf1c00000000000c4*/
              {
                v32._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141044187*/
                v32._Mypair._Myval2._Mysize = 0; /*0x14104418c*/
                v32._Mypair._Myval2._Myres = 15; /*0x141044190*/
                std::string::assign(this: &v32, _Ptr: "client", _Count: 6u); /*0x1410441aa*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: p_category); /*0xf1c00000000000d4*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: _Parg); /*0xf1c00000000000e0*/
            }
          }
          __unwind
          {
            std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: _Al); /*0xf1c00000000000ec*/
          }
          RBX::Analytics::EventIngest::setRBXEvent( /*0x1410441c2*/
            target: &v32,
            eventContext: &category,
            eventName: &result,
            additionalArgs: v14);
        }
      }
    }
    else
    {
      v15 = RBX::Time::nowFastSec(); /*0x1410441cc*/
      __wind /*0xf1c00000000000b8*/
      {
        v16 = v15 - this->sgs.avatarConfigureTime; /*0x1410441d4*/
        if ( !this->loadResolved ) /*0x1410441e2*/
        {
          this->loadResolved = true; /*0x1410441e8*/
          category._Mypair._Myval2._Myres = 15; /*0x1410441f1*/
          category._Mypair._Myval2._Mysize = 6; /*0x1410441fa*/
          *(_DWORD *)category._Mypair._Myval2._Bx._Buf = *(_DWORD *)"Cancel"; /*0x141044209*/
          *(_DWORD *)&category._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"el"; /*0x141044214*/
          result._Mypair._Myval2._Myres = 15; /*0x14104421e*/
          result._Mypair._Myval2._Mysize = 8; /*0x141044227*/
          strcpy(result._Mypair._Myval2._Bx._Buf, "GameLoad"); /*0x14104423a*/
          __wind /*0xf1c00000000000ac*/
          {
            RBX::PlayerConfigurer::reportDuration(this, category: &result, result: &category, duration: v16); /*0x141044254*/
            if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141044263*/
            {
              v17 = result._Mypair._Myval2._Bx._Ptr; /*0x141044268*/
              if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141044277*/
              {
                v17 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14104427d*/
                if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v17 - 8) > 0x1F ) /*0x14104428c*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14104428e*/
              }
              operator delete(ptr: v17); /*0x141044295*/
            }
            result._Mypair._Myval2._Mysize = 0; /*0x14104429a*/
            result._Mypair._Myval2._Myres = 15; /*0x14104429f*/
            result._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410442a8*/
            if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x1410442b6*/
            {
              v18 = category._Mypair._Myval2._Bx._Ptr; /*0x1410442bb*/
              if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410442ca*/
              {
                v18 = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x1410442d0*/
                if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - v18 - 8) > 0x1F ) /*0x1410442df*/
                  _invalid_parameter_noinfo_noreturn(); /*0x1410442e1*/
              }
              operator delete(ptr: v18); /*0x1410442e8*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c00000000000a4*/
          }
        }
        if ( !this->joinResolved ) /*0x1410442f1*/
        {
          this->joinResolved = true; /*0x1410442f7*/
          category._Mypair._Myval2._Myres = 15; /*0x141044300*/
          category._Mypair._Myval2._Mysize = 6; /*0x141044309*/
          *(_DWORD *)category._Mypair._Myval2._Bx._Buf = *(_DWORD *)"Cancel"; /*0x141044318*/
          *(_DWORD *)&category._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"el"; /*0x141044323*/
          result._Mypair._Myval2._Myres = 15; /*0x14104432d*/
          result._Mypair._Myval2._Mysize = 8; /*0x141044336*/
          strcpy(result._Mypair._Myval2._Bx._Buf, "GameJoin"); /*0x141044349*/
          RBX::PlayerConfigurer::reportDuration(this, category: &result, result: &category, duration: v16); /*0x141044363*/
          if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141044372*/
          {
            v19 = result._Mypair._Myval2._Bx._Ptr; /*0x141044377*/
            if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141044386*/
            {
              v19 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14104438c*/
              if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v19 - 8) > 0x1F ) /*0x14104439b*/
                _invalid_parameter_noinfo_noreturn(); /*0x14104439d*/
            }
            operator delete(ptr: v19); /*0x1410443a4*/
          }
          result._Mypair._Myval2._Mysize = 0; /*0x1410443a9*/
          result._Mypair._Myval2._Myres = 15; /*0x1410443ae*/
          result._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410443b7*/
          if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x1410443c5*/
          {
            v20 = category._Mypair._Myval2._Bx._Ptr; /*0x1410443ca*/
            if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410443d9*/
            {
              v20 = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x1410443df*/
              if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - v20 - 8) > 0x1F ) /*0x1410443ee*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410443f0*/
            }
            operator delete(ptr: v20); /*0x1410443f7*/
          }
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&category); /*0xf1c0000000000098*/
      }
      eventArgs._Traitsobj._Mypair._Myval2._Myval2 = 0.0; /*0x1410443fc*/
      eventArgs._List._Mypair._Myval2._Myhead = nullptr; /*0x141044403*/
      eventArgs._List._Mypair._Myval2._Mysize = 0; /*0x141044407*/
      v21 = (std::_List_node<std::pair<std::string const ,std::string >,void *> *)operator new(size: 0x50u); /*0x141044410*/
      __wind /*0xf1c0000000000194*/
      {
        __wind /*0xf1c000000000019c*/
        {
          v21->_Next = v21; /*0x141044415*/
          v21->_Prev = v21; /*0x141044418*/
          eventArgs._List._Mypair._Myval2._Myhead = v21; /*0x14104441c*/
          memset(&eventArgs._Vec, 0, sizeof(eventArgs._Vec)); /*0x141044420*/
          eventArgs._Mask = 7; /*0x14104442c*/
          eventArgs._Maxidx = 8; /*0x141044434*/
          eventArgs._Traitsobj._Mypair._Myval2._Myval2 = 1.0; /*0x141044444*/
          std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::shared_ptr<RBX::Graphics::Shader>>>>>>>::_Assign_grow( /*0x141044455*/
            this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > > > > *)&eventArgs._Vec,
            _Cells: 0x10u,
            _Val: (const std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > >)v21);
          v22 = "no"; /*0x141044462*/
          v23 = "no"; /*0x141044469*/
          if ( this->loadResolved ) /*0x14104446c*/
            v23 = "yes"; /*0x141044470*/
        }
        __unwind
        {
          std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&eventArgs._Vec); /*0x14315d98b*/
        }
      }
      __unwind
      {
        std::list<std::pair<std::string const,std::string>>::~list<std::pair<std::string const,std::string>>(this: (std::list<std::pair<std::string,std::string >> *)&eventArgs._List); /*0x14318275b*/
      }
      __wind /*0xf1c00000000001c0*/
      {
        __eh34_enter_wind_state(6, 7); /*0xf1c00000000001c8*/
        result._Mypair._Myval2._Myres = 15; /*0x141044474*/
        result._Mypair._Myval2._Mysize = 12; /*0x14104447d*/
        strcpy(result._Mypair._Myval2._Bx._Buf, "loadResolved"); /*0x14104448e*/
        p_second = &std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Try_emplace<std::string,>( /*0x1410444b9*/
                      this: &eventArgs,
                      result: (std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *)&category,
                      _Keyval_arg: &result)->first->_Myval.second;
        v28 = -1; /*0x1410444bd*/
        v25 = -1; /*0x1410444c4*/
        do /*0x1410444d8*/
          ++v25; /*0x1410444d0*/
        while ( v23[v25] != 0 ); /*0x1410444d8*/
        std::string::assign(this: p_second, _Ptr: v23, _Count: v25); /*0x1410444dd*/
        if ( __eh34_unwind(7) ) /*0xf1c0000000000088*/
        {
unwind_state_7:
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000070*/
          __eh34_continue_unwinding(7, 6); /*0xf1c0000000000074*/
        }
        __eh34_exit_wind_state(7, 6); /*0xf1c000000000008c*/
        if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x1410444ec*/
        {
          v26 = result._Mypair._Myval2._Bx._Ptr; /*0x1410444f1*/
          if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141044500*/
          {
            v26 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x141044506*/
            if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v26 - 8) > 0x1F ) /*0x141044515*/
              _invalid_parameter_noinfo_noreturn(); /*0x141044517*/
          }
          operator delete(ptr: v26); /*0x14104451e*/
        }
        if ( this->joinResolved ) /*0x141044523*/
          v22 = "yes"; /*0x141044527*/
        __eh34_enter_wind_state(6, 7); /*0xf1c0000000000080*/
        result._Mypair._Myval2._Myres = 15; /*0x14104452b*/
        result._Mypair._Myval2._Mysize = 12; /*0x141044534*/
        strcpy(result._Mypair._Myval2._Bx._Buf, "joinResolved"); /*0x141044545*/
        v27 = &std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Try_emplace<std::string,>( /*0x141044570*/
                 this: &eventArgs,
                 result: (std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *)&category,
                 _Keyval_arg: &result)->first->_Myval.second;
        do /*0x14104457c*/
          ++v28; /*0x141044574*/
        while ( v22[v28] != 0 ); /*0x14104457c*/
        std::string::assign(this: v27, _Ptr: v22, _Count: v28); /*0x141044584*/
        if ( __eh34_unwind(7) ) /*0xf1c000000000006c*/
          goto unwind_state_7; /*0xf1c000000000006c*/
        __eh34_exit_wind_state(7, 6); /*0xf1c0000000000078*/
        if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141044593*/
        {
          v29 = result._Mypair._Myval2._Bx._Ptr; /*0x141044598*/
          if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410445a7*/
          {
            v29 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x1410445ad*/
            if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v29 - 8) > 0x1F ) /*0x1410445bc*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410445be*/
          }
          operator delete(ptr: v29); /*0x1410445c5*/
        }
        p_category = (RBX::Graphics::ProfilerAdorn::Item *)&v34; /*0x1410445ce*/
        LODWORD(_Parg) = 0; /*0x1410445d2*/
        std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>( /*0x1410445e5*/
          this: (std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::string > >,0> > *)&v34,
          (const std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > > *)&_Parg,
          (const std::allocator<std::pair<std::string const ,std::string > > *)&_Al);
        __wind /*0xf1c0000000000060*/
        {
          _Al = (RBX::Graphics::ProfilerAdorn::Item *)&v32; /*0x1410445f0*/
          v32._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410445f4*/
          v32._Mypair._Myval2._Mysize = 0; /*0x1410445f9*/
          v32._Mypair._Myval2._Myres = 15; /*0x1410445fd*/
          std::string::assign(this: &v32, _Ptr: "GameLoadCanceled", _Count: 0x10u); /*0x141044617*/
          __wind /*0xf1c0000000000054*/
          {
            _Parg = (RBX::Graphics::ProfilerAdorn::Item *)&result; /*0x141044622*/
            result._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141044626*/
            result._Mypair._Myval2._Mysize = 0; /*0x14104462b*/
            result._Mypair._Myval2._Myres = 15; /*0x141044630*/
            std::string::assign(this: &result, _Ptr: "report", _Count: 6u); /*0x14104464b*/
            __wind /*0xf1c0000000000024*/
            {
              category._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141044651*/
              category._Mypair._Myval2._Mysize = 0; /*0x141044656*/
              category._Mypair._Myval2._Myres = 15; /*0x14104465b*/
              std::string::assign(this: &category, _Ptr: "client", _Count: 6u); /*0x141044676*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: _Parg); /*0xf1c0000000000034*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: _Al); /*0xf1c0000000000040*/
          }
        }
        __unwind
        {
          std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: p_category); /*0xf1c000000000004c*/
        }
        RBX::Analytics::EventIngest::setRBXEvent( /*0x14104468f*/
          target: &category,
          eventContext: &result,
          eventName: &v32,
          additionalArgs: (std::unordered_map<std::string,std::string> *)&v34);
        RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1410446b1*/
          category: "Game",
          action: "GameJoin",
          label: "Cancel",
          value: 0,
          sync: false);
      }
      __unwind
      {
        std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &eventArgs); /*0xf1c000000000001c*/
      }
      std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&eventArgs._Vec); /*0x1410446bb*/
      std::_List_node<std::pair<std::string const,std::string>,void *>::_Free_non_head<std::allocator<std::_List_node<std::pair<std::string const,std::string>,void *>>>( /*0x1410446c8*/
        _Al: (std::allocator<std::_List_node<std::pair<std::string const ,std::string >,void *> > *)&eventArgs._List,
        _Head: eventArgs._List._Mypair._Myval2._Myhead);
      operator delete(ptr: eventArgs._List._Mypair._Myval2._Myhead); /*0x1410446d6*/
    }
  }
  else
  {
    __eh34_enter_wind_state(-1, 0); /*0xf1c00000000001e4*/
    __eh34_enter_wind_state(0, 1); /*0xf1c00000000001e8*/
    v2 = RBX::Time::nowFastSec() - this->sgs.avatarConfigureTime; /*0x141043d04*/
    result._Mypair._Myval2._Myres = 15; /*0x141043d13*/
    result._Mypair._Myval2._Mysize = 7; /*0x141043d1c*/
    qmemcpy(&result, "Failur", 6); /*0x141043d2b*/
    *(_WORD *)&result._Mypair._Myval2._Bx._Alias[6] = (unsigned __int8)aFailure_0[6]; /*0x141043d42*/
    category._Mypair._Myval2._Myres = 15; /*0x141043d4b*/
    category._Mypair._Myval2._Mysize = 11; /*0x141043d54*/
    qmemcpy(&category, "GameConnec", 10); /*0x141043d65*/
    *(_WORD *)&category._Mypair._Myval2._Bx._Alias[10] = (unsigned __int8)aGameconnect[10]; /*0x141043d7e*/
    RBX::PlayerConfigurer::reportDuration(this, &category, &result, duration: v2); /*0x141043d94*/
    if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x141043da3*/
    {
      v3 = category._Mypair._Myval2._Bx._Ptr; /*0x141043da8*/
      if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141043db7*/
      {
        v3 = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x141043dbd*/
        if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - v3 - 8) > 0x1F ) /*0x141043dcc*/
          _invalid_parameter_noinfo_noreturn(); /*0x141043dce*/
      }
      operator delete(ptr: v3); /*0x141043dd5*/
    }
    category._Mypair._Myval2._Mysize = 0; /*0x141043dda*/
    category._Mypair._Myval2._Myres = 15; /*0x141043ddf*/
    category._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141043de8*/
    if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141043df6*/
    {
      v4 = result._Mypair._Myval2._Bx._Ptr; /*0x141043dfb*/
      if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141043e0a*/
      {
        v4 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x141043e10*/
        if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v4 - 8) > 0x1F ) /*0x141043e1f*/
          _invalid_parameter_noinfo_noreturn(); /*0x141043e21*/
      }
      operator delete(ptr: v4); /*0x141043e28*/
    }
    if ( __eh34_unwind(1) ) /*0xf1c00000000001d0*/
      goto unwind_state_1; /*0xf1c00000000001d0*/
    __eh34_exit_wind_state(1, 0); /*0xf1c00000000001d4*/
    if ( __eh34_unwind(0) ) /*0xf1c00000000001d8*/
      goto unwind_state_0; /*0xf1c00000000001d8*/
    __eh34_exit_wind_state(0, -1); /*0xf1c00000000001dc*/
    RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x141043e4a*/
      category: "Game",
      action: "GameJoin",
      label: "Failure",
      value: 0,
      sync: false);
  }
}

// Address: 0x141044700 | Name: ?onGameLoaded@PlayerConfigurer@RBX@@AEAAXV?$shared_ptr@_N@std@@@Z
void __fastcall RBX::PlayerConfigurer::onGameLoaded(RBX::PlayerConfigurer *this, std::shared_ptr<RBX::File> *isWaiting)
{
  double v4; // xmm0_8
  double v5; // xmm6_8
  long double v6; // xmm3_8
  char *Ptr; // rcx
  char *v8; // rcx
  __int64 userId; // rcx
  long double v10; // xmm6_8
  RBX::InferredCrash *Instance; // rax
  std::_Ref_count_base *Rep; // rbx
  std::function<void __cdecl(RBX::SimpleTimer &)> *p_callback; // rdx
  std::_Ref_count_base *v14; // rbx
  std::function<void __cdecl(RBX::SimpleTimer &)> *v15; // rdx
  RBX::Plugin **v16; // rax
  RBX::Plugin *v17; // rbx
  std::string *p_gitHash; // rcx
  std::string *v19; // r8
  std::string *ServerLogPrefix; // rax
  char *v21; // rcx
  char *v22; // rcx
  __int64 ParamInt64; // r14
  char *v24; // rcx
  std::shared_ptr<RBX::SessionAppEventsHandler> *v25; // rax
  RBX::SessionAppEventsHandler *v26; // rbx
  const std::string *v27; // rax
  char *v28; // rcx
  std::_Ref_count_base *v29; // rbx
  RBX::DataModel *dataModel; // rax
  const RBX::ServiceProvider *v31; // rcx
  std::_Func_base<void,RBX::DataModel *> *v32; // rax
  std::_Ref_count_base *v33; // rbx
  std::string category; // [rsp+20h] [rbp-E0h] BYREF
  std::string result; // [rsp+40h] [rbp-C0h] BYREF
  std::string key; // [rsp+60h] [rbp-A0h] BYREF
  std::string gitHash; // [rsp+80h] [rbp-80h] BYREF
  std::shared_ptr<RBX::ClientSessionTracker::ClientSessionMetricKey<double,0> const > v38; // [rsp+A0h] [rbp-60h] BYREF
  std::string v39; // [rsp+B0h] [rbp-50h] BYREF
  std::string v40; // [rsp+D0h] [rbp-30h] BYREF
  std::string v41; // [rsp+F0h] [rbp-10h] BYREF
  __int128 v42; // [rsp+110h] [rbp+10h]
  std::_Func_base<void,RBX::DataModel *> *v43; // [rsp+120h] [rbp+20h]
  std::string v44; // [rsp+128h] [rbp+28h] BYREF
  RBX::SimpleTimer v45; // [rsp+148h] [rbp+48h] BYREF
  RBX::SimpleTimer v46; // [rsp+158h] [rbp+58h] BYREF
  std::shared_ptr<RBX::SessionAppEventsHandler> v47; // [rsp+168h] [rbp+68h] BYREF
  std::function<void __cdecl(RBX::DataModel *)> v48; // [rsp+178h] [rbp+78h] BYREF
  std::string v49; // [rsp+1B8h] [rbp+B8h] BYREF
  std::function<void __cdecl(RBX::SimpleTimer &)> callback; // [rsp+1D8h] [rbp+D8h] BYREF
  std::function<void __cdecl(RBX::SimpleTimer &)> v51; // [rsp+218h] [rbp+118h] BYREF
  std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::string > >,0> > v52; // [rsp+258h] [rbp+158h] BYREF
  std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::string > >,0> > *_Al; // [rsp+2F0h] [rbp+1F0h] BYREF
  std::shared_ptr<RBX::File> *v54; // [rsp+2F8h] [rbp+1F8h]
  std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > > _Parg; // [rsp+300h] [rbp+200h] BYREF
  std::string *v56; // [rsp+308h] [rbp+208h]

  v54 = isWaiting; /*0x141044700*/
  __wind
  {
    LOBYTE(isWaiting->_Ptr->__vftable) = 0; /*0x14104472f*/
    if ( !this->loadResolved ) /*0x141044739*/
    {
      this->loadResolved = true; /*0x14104473f*/
      v4 = RBX::Time::nowFastSec(); /*0x141044743*/
      __wind /*0xf1c00000000000dc*/
      {
        __wind /*0xf1c00000000000e4*/
        {
          v5 = v4; /*0x141044748*/
          v6 = v4 - this->sgs.avatarConfigureTime; /*0x14104474e*/
          result._Mypair._Myval2._Myres = 15; /*0x14104475b*/
          result._Mypair._Myval2._Mysize = 7; /*0x141044764*/
          strcpy(result._Mypair._Myval2._Bx._Buf, "Success"); /*0x141044773*/
          category._Mypair._Myval2._Myres = 15; /*0x141044793*/
          category._Mypair._Myval2._Mysize = 8; /*0x14104479c*/
          strcpy(category._Mypair._Myval2._Bx._Buf, "GameLoad"); /*0x1410447af*/
          RBX::PlayerConfigurer::reportDuration(this, &category, &result, duration: v6); /*0x1410447c6*/
          if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x1410447d5*/
          {
            Ptr = category._Mypair._Myval2._Bx._Ptr; /*0x1410447da*/
            if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410447e9*/
            {
              Ptr = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x1410447ef*/
              if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410447fe*/
                _invalid_parameter_noinfo_noreturn(); /*0x141044800*/
            }
            operator delete(ptr: Ptr); /*0x141044807*/
          }
          category._Mypair._Myval2._Mysize = 0; /*0x14104480c*/
          category._Mypair._Myval2._Myres = 15; /*0x141044811*/
          category._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104481a*/
          if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141044828*/
          {
            v8 = result._Mypair._Myval2._Bx._Ptr; /*0x14104482d*/
            if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104483c*/
            {
              v8 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x141044842*/
              if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v8 - 8) > 0x1F ) /*0x141044851*/
                _invalid_parameter_noinfo_noreturn(); /*0x141044853*/
            }
            operator delete(ptr: v8); /*0x14104485a*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&category); /*0xf1c00000000000c8*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c00000000000d4*/
      }
      userId = this->userId; /*0x14104485f*/
      if ( userId > 0 && userId % 1000 < DFInt::ClientJoinProcessPositiveSamplesThousandths ) /*0x14104489b*/
      {
        _Al = &v52; /*0x1410448a8*/
        LODWORD(_Parg._Mypair._Myval2._Myval2) = 0; /*0x1410448b2*/
        std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>( /*0x1410448cf*/
          this: &v52,
          &_Parg,
          (const std::allocator<std::pair<std::string const ,std::string > > *)&_Al);
        v39._Mypair._Myval2._Myres = 15; /*0x1410448e0*/
        v39._Mypair._Myval2._Mysize = 14; /*0x1410448e8*/
        strcpy(v39._Mypair._Myval2._Bx._Buf, "GameLoadSucess"); /*0x1410448f8*/
        v56 = &v40; /*0x141044919*/
        v40._Mypair._Myval2._Myres = 15; /*0x141044924*/
        v40._Mypair._Myval2._Mysize = 6; /*0x14104492c*/
        *(_DWORD *)v40._Mypair._Myval2._Bx._Buf = *(_DWORD *)"report"; /*0x14104493a*/
        *(_DWORD *)&v40._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"rt"; /*0x141044944*/
        v41._Mypair._Myval2._Myres = 15; /*0x141044950*/
        v41._Mypair._Myval2._Mysize = 6; /*0x141044958*/
        *(_DWORD *)v41._Mypair._Myval2._Bx._Buf = *(_DWORD *)"client"; /*0x141044966*/
        *(_DWORD *)&v41._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"nt"; /*0x141044970*/
        RBX::Analytics::EventIngest::setRBXEvent( /*0x14104498b*/
          target: &v41,
          eventContext: &v40,
          eventName: &v39,
          additionalArgs: (std::unordered_map<std::string,std::string> *)&v52);
      }
      v10 = v5 - this->sgs.userClickTime; /*0x141044990*/
      this->sgs.gameLoadTime = v10; /*0x141044995*/
      if ( DFFlag::SessionTrackingFlushAtImportantCheckpoints.value ) /*0x1410449a4*/
      {
        Instance = RBX::InferredCrash::getInstance(); /*0x1410449a6*/
        RBX::InferredCrash::onGameLoaded(this: Instance, gameLoadedTime: this->sgs.gameLoadTime); /*0x1410449b6*/
      }
      else
      {
        v38 = 0; /*0x1410449c0*/
        if ( RBX::ClientSessionTrackerKeys::GameLoadTime._Rep != nullptr ) /*0x1410449cf*/
          _InterlockedIncrement((volatile signed __int32 *)&RBX::ClientSessionTrackerKeys::GameLoadTime._Rep->_Uses); /*0x1410449d1*/
        v38 = RBX::ClientSessionTrackerKeys::GameLoadTime; /*0x1410449dc*/
        RBX::updateClientSessionMetric_double_0_(metricKey: &v38, value: v10, bFlush: true); /*0x1410449ea*/
      }
      if ( DFFlag::ReportFailuresInClientJoinAll2.value ) /*0x1410449f6*/
        this->sgs.joinPhase = JoinPhase_GameLoaded; /*0x1410449f8*/
      if ( FLog::AvatarJoinMetrics != 0 ) /*0x141044a0b*/
        FLog::FastLogFormatted( /*0x141044a23*/
          level: FLog::AvatarJoinMetrics,
          message: "[FLog::AvatarJoinMetrics] gameLoadTime = %g",
          this->sgs.gameLoadTime);
      if ( FFlag::LogClientLoadToAvatarLoad.value && FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x141044a3a*/
      {
        FLog::FastLog( /*0x141044a46*/
          level: FLog::LogStepTimeAndNetworkUsage,
          message: "[FLog::LogStepTimeAndNetworkUsage] Game Loaded",
          arg0: nullptr);
        if ( FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x141044a54*/
          FLog::FastLogFormatted( /*0x141044a5f*/
            level: FLog::LogStepTimeAndNetworkUsage,
            message: "[FLog::LogStepTimeAndNetworkUsage] 0, 0, 0, 0");
      }
    }
    this->waitingForCharacter = true; /*0x141044a64*/
    if ( DFFlag::PlayerConfigurerDoCDNProbe2.value ) /*0x141044a7c*/
    {
      callback._Mystorage._Ptrs[0] = (std::_Func_base<void,RBX::SimpleTimer &> *)std::_Func_impl_no_alloc__lambda_b0447d5fc9cee76652e3d58393ce4b2e__void_RBX::SimpleTimer___::_vftable_; /*0x141044a89*/
      callback._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::SimpleTimer &> *)&callback; /*0x141044a97*/
      __wind /*0xf1c00000000000ac*/
      {
        RBX::SimpleTimer::callIn( /*0x141044ab9*/
          result: &v45,
          &callback,
          period: (double)DFInt::PlayerConfigurerCDNProbeDelayMs / 1000.0);
        Rep = v45.timerData._Rep; /*0x141044abe*/
        if ( v45.timerData._Rep != nullptr /*0x141044ad1*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&v45.timerData._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          Rep->_Destroy(this: Rep); /*0x141044ad9*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141044ae5*/
            Rep->_Delete_this(this: Rep); /*0x141044aed*/
        }
      }
      __unwind
      {
        std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&callback); /*0xf1c00000000000a4*/
      }
      if ( callback._Mystorage._Ptrs[7] != nullptr ) /*0x141044afb*/
      {
        p_callback = &callback; /*0x141044b00*/
        LOBYTE(p_callback) = callback._Mystorage._Ptrs[7] != (std::_Func_base<void,RBX::SimpleTimer &> *)&callback; /*0x141044b0a*/
        callback._Mystorage._Ptrs[7]->_Delete_this(this: callback._Mystorage._Ptrs[7], a2: (bool)p_callback); /*0x141044b0d*/
      }
    }
    if ( DFFlag::PlayerConfigurerRunLMSTest.value ) /*0x141044b17*/
    {
      __wind /*0xf1c0000000000094*/
      {
        v51._Mystorage._Ptrs[0] = (std::_Func_base<void,RBX::SimpleTimer &> *)std::_Func_impl_no_alloc__lambda_cb96388c95f25f2d5f1b19778ce6353e__void_RBX::SimpleTimer___::_vftable_; /*0x141044b24*/
        v51._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::SimpleTimer &> *)&v51; /*0x141044b32*/
        RBX::SimpleTimer::callIn( /*0x141044b54*/
          result: &v46,
          callback: &v51,
          period: (double)DFInt::PlayerConfigurerLMSTestDelayMs / 1000.0);
        v14 = v46.timerData._Rep; /*0x141044b59*/
        if ( v46.timerData._Rep != nullptr /*0x141044b6c*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&v46.timerData._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v14->_Destroy(this: v14); /*0x141044b74*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v14->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141044b80*/
            v14->_Delete_this(this: v14); /*0x141044b88*/
        }
        if ( v51._Mystorage._Ptrs[7] != nullptr ) /*0x141044b96*/
        {
          v15 = &v51; /*0x141044b9b*/
          LOBYTE(v15) = v51._Mystorage._Ptrs[7] != (std::_Func_base<void,RBX::SimpleTimer &> *)&v51; /*0x141044ba5*/
          v51._Mystorage._Ptrs[7]->_Delete_this(this: v51._Mystorage._Ptrs[7], a2: (bool)v15); /*0x141044ba8*/
        }
      }
      __unwind
      {
        std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&v51); /*0xf1c000000000008c*/
      }
    }
    v16 = (RBX::Plugin **)RBX::ServiceProvider::refByClass<RBX::Players>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x141044bb3*/
    v17 = *v16; /*0x141044bb8*/
    if ( *v16 != nullptr )
    {
      RBX::Players::getServerGitHash(this: *v16, result: &gitHash); /*0x141044bcb*/
      __wind
      {
        p_gitHash = &gitHash; /*0x141044bd1*/
        if ( gitHash._Mypair._Myval2._Myres >= 0x10 ) /*0x141044bda*/
          p_gitHash = (std::string *)gitHash._Mypair._Myval2._Bx._Ptr; /*0x141044bda*/
        RBX::RbxDbgInfo::SetServerGitHash(s: p_gitHash->_Mypair._Myval2._Bx._Buf); /*0x141044bdf*/
        if ( FLog::Output != 0 )
        {
          v19 = &gitHash; /*0x141044bf3*/
          if ( gitHash._Mypair._Myval2._Myres >= 0x10 ) /*0x141044bfc*/
            v19 = (std::string *)gitHash._Mypair._Myval2._Bx._Ptr; /*0x141044bfc*/
          FLog::FastLogS(
            level: FLog::Output,
            message: "[FLog::Output] Server RobloxGitHash: %s",
            sarg: v19->_Mypair._Myval2._Bx._Buf);
          if ( FLog::Output != 0 )
          {
            ServerLogPrefix = RBX::Players::getServerLogPrefix(this: (RBX::Players *)v17, result: &v49); /*0x141044c20*/
            __wind
            {
              if ( ServerLogPrefix->_Mypair._Myval2._Myres >= 0x10 ) /*0x141044c2b*/
                ServerLogPrefix = (std::string *)ServerLogPrefix->_Mypair._Myval2._Bx._Ptr; /*0x141044c2d*/
              FLog::FastLogS(
                level: FLog::Output,
                message: "[FLog::Output] Server Prefix: %s",
                sarg: ServerLogPrefix->_Mypair._Myval2._Bx._Buf);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v49); /*0xf1c0000000000068*/
            }
            if ( v49._Mypair._Myval2._Myres >= 0x10 ) /*0x141044c52*/
            {
              v21 = v49._Mypair._Myval2._Bx._Ptr; /*0x141044c57*/
              if ( v49._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141044c68*/
              {
                v21 = *((char **)v49._Mypair._Myval2._Bx._Ptr - 1); /*0x141044c6e*/
                if ( (unsigned __int64)(v49._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x141044c7d*/
                  _invalid_parameter_noinfo_noreturn(); /*0x141044c7f*/
              }
              operator delete(ptr: v21); /*0x141044c86*/
            }
          }
        }
        if ( gitHash._Mypair._Myval2._Myres >= 0x10 ) /*0x141044c94*/
        {
          v22 = gitHash._Mypair._Myval2._Bx._Ptr; /*0x141044c99*/
          if ( gitHash._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141044ca7*/
          {
            v22 = *((char **)gitHash._Mypair._Myval2._Bx._Ptr - 1); /*0x141044cad*/
            if ( (unsigned __int64)(gitHash._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x141044cbc*/
              _invalid_parameter_noinfo_noreturn(); /*0x141044cbe*/
          }
          operator delete(ptr: v22); /*0x141044cc5*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&gitHash); /*0xf1c000000000005c*/
      }
    }
    if ( FFlag::SessionGamePlayEvents3.value ) /*0x141044cd1*/
    {
      __wind /*0xf1c000000000004c*/
      {
        key._Mypair._Myval2._Myres = 15; /*0x141044cdc*/
        key._Mypair._Myval2._Mysize = 7; /*0x141044ce5*/
        qmemcpy(&key, "PlaceI", 6); /*0x141044cf4*/
        *(_WORD *)&key._Mypair._Myval2._Bx._Alias[6] = (unsigned __int8)aPlaceid_16[6]; /*0x141044d0b*/
        ParamInt64 = RBX::GameConfigurer::getParamInt64(this, &key); /*0x141044d21*/
        if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x141044d2d*/
        {
          v24 = key._Mypair._Myval2._Bx._Ptr; /*0x141044d32*/
          if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141044d41*/
          {
            v24 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x141044d47*/
            if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v24 - 8) > 0x1F ) /*0x141044d56*/
              _invalid_parameter_noinfo_noreturn(); /*0x141044d58*/
          }
          operator delete(ptr: v24); /*0x141044d5f*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key); /*0xf1c0000000000044*/
      }
      v25 = RBX::SessionAppEventsHandler::instance(result: &v47); /*0x141044d68*/
      __wind /*0xf1c0000000000034*/
      {
        v26 = v25->_Ptr; /*0x141044d6e*/
        v27 = std::to_string(result: &v44, value: ParamInt64); /*0x141044d78*/
        __wind /*0xf1c0000000000010*/
        {
          RBX::SessionAppEventsHandler::onGameLoaded(this: v26, placeId: v27); /*0x141044d84*/
          if ( v44._Mypair._Myval2._Myres >= 0x10 ) /*0x141044d92*/
          {
            v28 = v44._Mypair._Myval2._Bx._Ptr; /*0x141044d97*/
            if ( v44._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141044da5*/
            {
              v28 = *((char **)v44._Mypair._Myval2._Bx._Ptr - 1); /*0x141044dab*/
              if ( (unsigned __int64)(v44._Mypair._Myval2._Bx._Ptr - v28 - 8) > 0x1F ) /*0x141044dba*/
                _invalid_parameter_noinfo_noreturn(); /*0x141044dbc*/
            }
            operator delete(ptr: v28); /*0x141044dc3*/
          }
          v44._Mypair._Myval2._Mysize = 0; /*0x141044dc8*/
          v44._Mypair._Myval2._Myres = 15; /*0x141044dcc*/
          v44._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141044dd4*/
          v29 = v47._Rep; /*0x141044dd8*/
          if ( v47._Rep != nullptr /*0x141044deb*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&v47._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v29->_Destroy(this: v29); /*0x141044df3*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v29->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141044dff*/
              v29->_Delete_this(this: v29); /*0x141044e07*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v44); /*0xf1c0000000000020*/
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v47); /*0xf1c000000000002c*/
      }
    }
    if ( FFlag::DebugEnableClientTestService.value ) /*0x141044e11*/
    {
      dataModel = this->dataModel; /*0x141044e13*/
      v31 = &dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>; /*0x141044e17*/
      if ( dataModel == nullptr ) /*0x141044e1e*/
        v31 = nullptr; /*0x141044e1e*/
      v32 = (std::_Func_base<void,RBX::DataModel *> *)RBX::ServiceProvider::find<RBX::TestService>(serviceProvider: v31); /*0x141044e22*/
      if ( v32[9].__vftable != nullptr ) /*0x141044e2c*/
      {
        *(_QWORD *)&v42 = RBX::TestService::run; /*0x141044e35*/
        DWORD2(v42) = 0; /*0x141044e39*/
        v43 = v32; /*0x141044e41*/
        v48._Mystorage._Ptrs[0] = (std::_Func_base<void,RBX::DataModel *> *)std::_Func_impl_no_alloc<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::TestService>,boost::_bi::list1<boost::_bi::value<RBX::TestService *>>>,void,RBX::DataModel *>::`vftable'; /*0x141044e4c*/
        *(_OWORD *)&v48._Mystorage._Ptrs[1] = v42; /*0x141044e50*/
        v48._Mystorage._Ptrs[3] = v32; /*0x141044e5c*/
        v48._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::DataModel *> *)&v48; /*0x141044e68*/
        RBX::DataModel::submitTask(this: this->dataModel, task: &v48, taskType: (RBX::DMTaskType)1); /*0x141044e7d*/
      }
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v54); /*0xf1c0000000000008*/
  }
  v33 = isWaiting->_Rep; /*0x141044e83*/
  if ( v33 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v33->_Uses, 0xFFFFFFFF) == 1 ) /*0x141044e96*/
  {
    v33->_Destroy(this: v33); /*0x141044e9e*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v33->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141044ea8*/
      v33->_Delete_this(this: v33); /*0x141044eb0*/
  }
}

// Address: 0x141044ed0 | Name: ?onGameLoaded@PlayerConfigurer@RBX@@AEAAXXZ
void __fastcall RBX::PlayerConfigurer::onGameLoaded(RBX::PlayerConfigurer *this)
{
  double v2; // xmm0_8
  double v3; // xmm6_8
  long double v4; // xmm3_8
  char *Ptr; // rcx
  char *v6; // rcx
  __int64 userId; // rcx
  long double v8; // xmm6_8
  RBX::InferredCrash *Instance; // rax
  std::_Ref_count_base *Rep; // rbx
  std::function<void __cdecl(RBX::SimpleTimer &)> *p_callback; // rdx
  std::_Ref_count_base *v12; // rbx
  std::function<void __cdecl(RBX::SimpleTimer &)> *v13; // rdx
  RBX::Plugin **v14; // rax
  RBX::Plugin *v15; // rbx
  std::string *p_gitHash; // rcx
  std::string *v17; // r8
  std::string *ServerLogPrefix; // rax
  char *v19; // rcx
  char *v20; // rcx
  __int64 ParamInt64; // r14
  char *v22; // rcx
  std::shared_ptr<RBX::SessionAppEventsHandler> *v23; // rax
  RBX::SessionAppEventsHandler *v24; // rbx
  const std::string *v25; // rax
  char *v26; // rcx
  volatile signed __int32 *v27; // rbx
  RBX::DataModel *dataModel; // rax
  const RBX::ServiceProvider *v29; // rcx
  std::_Func_base<void,RBX::DataModel *> *v30; // rax
  std::shared_ptr<RBX::ClientSessionTracker::ClientSessionMetricKey<double,0> const > v31; // [rsp+20h] [rbp-E0h] BYREF
  std::string category; // [rsp+30h] [rbp-D0h] BYREF
  std::string result; // [rsp+50h] [rbp-B0h] BYREF
  std::string key; // [rsp+70h] [rbp-90h] BYREF
  std::string gitHash; // [rsp+90h] [rbp-70h] BYREF
  std::string v36; // [rsp+B0h] [rbp-50h] BYREF
  std::string v37; // [rsp+D0h] [rbp-30h] BYREF
  std::function<void __cdecl(RBX::DataModel *)> v38; // [rsp+F0h] [rbp-10h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v39; // [rsp+130h] [rbp+30h] BYREF
  RBX::SimpleTimer v40; // [rsp+168h] [rbp+68h] BYREF
  RBX::SimpleTimer v41; // [rsp+178h] [rbp+78h] BYREF
  std::string v42; // [rsp+188h] [rbp+88h] BYREF
  std::function<void __cdecl(RBX::SimpleTimer &)> callback; // [rsp+1A8h] [rbp+A8h] BYREF
  std::function<void __cdecl(RBX::SimpleTimer &)> v44; // [rsp+1E8h] [rbp+E8h] BYREF
  std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::string > >,0> > v45; // [rsp+228h] [rbp+128h] BYREF
  std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::string > >,0> > *_Al; // [rsp+2B0h] [rbp+1B0h] BYREF
  std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > > _Parg; // [rsp+2B8h] [rbp+1B8h] BYREF
  std::string *v48; // [rsp+2C0h] [rbp+1C0h]

  if ( !this->loadResolved ) /*0x141044efd*/
  {
    this->loadResolved = true; /*0x141044f03*/
    v2 = RBX::Time::nowFastSec(); /*0x141044f07*/
    __wind /*0xf1c00000000000c4*/
    {
      __wind /*0xf1c00000000000cc*/
      {
        v3 = v2; /*0x141044f0c*/
        v4 = v2 - this->sgs.avatarConfigureTime; /*0x141044f12*/
        result._Mypair._Myval2._Myres = 15; /*0x141044f1f*/
        result._Mypair._Myval2._Mysize = 7; /*0x141044f28*/
        strcpy(result._Mypair._Myval2._Bx._Buf, "Success"); /*0x141044f37*/
        category._Mypair._Myval2._Myres = 15; /*0x141044f57*/
        category._Mypair._Myval2._Mysize = 8; /*0x141044f60*/
        strcpy(category._Mypair._Myval2._Bx._Buf, "GameLoad"); /*0x141044f73*/
        RBX::PlayerConfigurer::reportDuration(this, &category, &result, duration: v4); /*0x141044f8a*/
        if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x141044f99*/
        {
          Ptr = category._Mypair._Myval2._Bx._Ptr; /*0x141044f9e*/
          if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141044fad*/
          {
            Ptr = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x141044fb3*/
            if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141044fc2*/
              _invalid_parameter_noinfo_noreturn(); /*0x141044fc4*/
          }
          operator delete(ptr: Ptr); /*0x141044fcb*/
        }
        category._Mypair._Myval2._Mysize = 0; /*0x141044fd0*/
        category._Mypair._Myval2._Myres = 15; /*0x141044fd5*/
        category._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141044fde*/
        if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141044fec*/
        {
          v6 = result._Mypair._Myval2._Bx._Ptr; /*0x141044ff1*/
          if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045000*/
          {
            v6 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x141045006*/
            if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v6 - 8) > 0x1F ) /*0x141045015*/
              _invalid_parameter_noinfo_noreturn(); /*0x141045017*/
          }
          operator delete(ptr: v6); /*0x14104501e*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&category); /*0xf1c00000000000b0*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c00000000000bc*/
    }
    userId = this->userId; /*0x141045023*/
    if ( userId > 0 && userId % 1000 < DFInt::ClientJoinProcessPositiveSamplesThousandths ) /*0x14104505f*/
    {
      _Al = &v45; /*0x14104506c*/
      LODWORD(_Parg._Mypair._Myval2._Myval2) = 0; /*0x141045076*/
      std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>( /*0x141045093*/
        this: &v45,
        &_Parg,
        (const std::allocator<std::pair<std::string const ,std::string > > *)&_Al);
      v36._Mypair._Myval2._Myres = 15; /*0x1410450a4*/
      v36._Mypair._Myval2._Mysize = 14; /*0x1410450ac*/
      strcpy(v36._Mypair._Myval2._Bx._Buf, "GameLoadSucess"); /*0x1410450bc*/
      v48 = &v37; /*0x1410450dd*/
      v37._Mypair._Myval2._Myres = 15; /*0x1410450e8*/
      v37._Mypair._Myval2._Mysize = 6; /*0x1410450f0*/
      *(_DWORD *)v37._Mypair._Myval2._Bx._Buf = *(_DWORD *)"report"; /*0x1410450fe*/
      *(_DWORD *)&v37._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"rt"; /*0x141045108*/
      v38._Mystorage._Ptrs[3] = (std::_Func_base<void,RBX::DataModel *> *)15; /*0x141045114*/
      v38._Mystorage._Ptrs[2] = (std::_Func_base<void,RBX::DataModel *> *)6; /*0x14104511c*/
      LODWORD(v38._Mystorage._Dummy1) = *(_DWORD *)"client"; /*0x14104512a*/
      HIDWORD(v38._Mystorage._Ptrs[0]) = *(unsigned __int16 *)"nt"; /*0x141045134*/
      RBX::Analytics::EventIngest::setRBXEvent( /*0x14104514f*/
        target: (std::string *)&v38,
        eventContext: &v37,
        eventName: &v36,
        additionalArgs: (std::unordered_map<std::string,std::string> *)&v45);
    }
    v8 = v3 - this->sgs.userClickTime; /*0x141045154*/
    this->sgs.gameLoadTime = v8; /*0x141045159*/
    if ( DFFlag::SessionTrackingFlushAtImportantCheckpoints.value ) /*0x141045168*/
    {
      Instance = RBX::InferredCrash::getInstance(); /*0x14104516a*/
      RBX::InferredCrash::onGameLoaded(this: Instance, gameLoadedTime: this->sgs.gameLoadTime); /*0x14104517a*/
    }
    else
    {
      v31 = 0; /*0x141045184*/
      if ( RBX::ClientSessionTrackerKeys::GameLoadTime._Rep != nullptr ) /*0x141045194*/
        _InterlockedIncrement((volatile signed __int32 *)&RBX::ClientSessionTrackerKeys::GameLoadTime._Rep->_Uses); /*0x141045196*/
      v31 = RBX::ClientSessionTrackerKeys::GameLoadTime; /*0x1410451a1*/
      RBX::updateClientSessionMetric_double_0_(metricKey: &v31, value: v8, bFlush: true); /*0x1410451b1*/
    }
    if ( DFFlag::ReportFailuresInClientJoinAll2.value ) /*0x1410451bd*/
      this->sgs.joinPhase = JoinPhase_GameLoaded; /*0x1410451bf*/
    if ( FLog::AvatarJoinMetrics != 0 ) /*0x1410451d2*/
      FLog::FastLogFormatted( /*0x1410451ea*/
        level: FLog::AvatarJoinMetrics,
        message: "[FLog::AvatarJoinMetrics] gameLoadTime = %g",
        this->sgs.gameLoadTime);
    if ( FFlag::LogClientLoadToAvatarLoad.value && FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x141045201*/
    {
      FLog::FastLog( /*0x14104520d*/
        level: FLog::LogStepTimeAndNetworkUsage,
        message: "[FLog::LogStepTimeAndNetworkUsage] Game Loaded",
        arg0: nullptr);
      if ( FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x14104521b*/
        FLog::FastLogFormatted( /*0x141045226*/
          level: FLog::LogStepTimeAndNetworkUsage,
          message: "[FLog::LogStepTimeAndNetworkUsage] 0, 0, 0, 0");
    }
  }
  this->waitingForCharacter = true; /*0x14104522b*/
  if ( DFFlag::PlayerConfigurerDoCDNProbe2.value ) /*0x141045243*/
  {
    callback._Mystorage._Ptrs[0] = (std::_Func_base<void,RBX::SimpleTimer &> *)std::_Func_impl_no_alloc__lambda_8f6b7c2775b77940f6f7ee8eb6ef3468__void_RBX::SimpleTimer___::_vftable_; /*0x141045250*/
    callback._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::SimpleTimer &> *)&callback; /*0x14104525e*/
    __wind /*0xf1c00000000000a0*/
    {
      RBX::SimpleTimer::callIn(result: &v40, &callback, period: (double)DFInt::PlayerConfigurerCDNProbeDelayMs / 1000.0); /*0x141045280*/
      Rep = v40.timerData._Rep; /*0x141045285*/
      if ( v40.timerData._Rep != nullptr /*0x141045298*/
        && _InterlockedExchangeAdd((volatile signed __int32 *)&v40.timerData._Rep->_Uses, 0xFFFFFFFF) == 1 )
      {
        Rep->_Destroy(this: Rep); /*0x1410452a0*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410452ac*/
          Rep->_Delete_this(this: Rep); /*0x1410452b4*/
      }
    }
    __unwind
    {
      std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&callback); /*0xf1c0000000000098*/
    }
    if ( callback._Mystorage._Ptrs[7] != nullptr ) /*0x1410452c2*/
    {
      p_callback = &callback; /*0x1410452c7*/
      LOBYTE(p_callback) = callback._Mystorage._Ptrs[7] != (std::_Func_base<void,RBX::SimpleTimer &> *)&callback; /*0x1410452d1*/
      callback._Mystorage._Ptrs[7]->_Delete_this(this: callback._Mystorage._Ptrs[7], a2: (bool)p_callback); /*0x1410452d4*/
    }
  }
  if ( DFFlag::PlayerConfigurerRunLMSTest.value ) /*0x1410452de*/
  {
    __wind /*0xf1c0000000000088*/
    {
      v44._Mystorage._Ptrs[0] = (std::_Func_base<void,RBX::SimpleTimer &> *)std::_Func_impl_no_alloc__lambda_4f54bf11961596b4b2a95b7944918d5c__void_RBX::SimpleTimer___::_vftable_; /*0x1410452eb*/
      v44._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::SimpleTimer &> *)&v44; /*0x1410452f9*/
      RBX::SimpleTimer::callIn( /*0x14104531b*/
        result: &v41,
        callback: &v44,
        period: (double)DFInt::PlayerConfigurerLMSTestDelayMs / 1000.0);
      v12 = v41.timerData._Rep; /*0x141045320*/
      if ( v41.timerData._Rep != nullptr /*0x141045336*/
        && _InterlockedExchangeAdd((volatile signed __int32 *)&v41.timerData._Rep->_Uses, 0xFFFFFFFF) == 1 )
      {
        v12->_Destroy(this: v12); /*0x14104533e*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v12->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14104534a*/
          v12->_Delete_this(this: v12); /*0x141045352*/
      }
      if ( v44._Mystorage._Ptrs[7] != nullptr ) /*0x141045360*/
      {
        v13 = &v44; /*0x141045365*/
        LOBYTE(v13) = v44._Mystorage._Ptrs[7] != (std::_Func_base<void,RBX::SimpleTimer &> *)&v44; /*0x14104536f*/
        v44._Mystorage._Ptrs[7]->_Delete_this(this: v44._Mystorage._Ptrs[7], a2: (bool)v13); /*0x141045372*/
      }
    }
    __unwind
    {
      std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&v44); /*0xf1c0000000000080*/
    }
  }
  v14 = (RBX::Plugin **)RBX::ServiceProvider::refByClass<RBX::Players>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x14104537d*/
  v15 = *v14; /*0x141045382*/
  if ( *v14 != nullptr )
  {
    RBX::Players::getServerGitHash(this: *v14, result: &gitHash); /*0x141045395*/
    __wind
    {
      p_gitHash = &gitHash; /*0x14104539b*/
      if ( gitHash._Mypair._Myval2._Myres >= 0x10 ) /*0x1410453a4*/
        p_gitHash = (std::string *)gitHash._Mypair._Myval2._Bx._Ptr; /*0x1410453a4*/
      RBX::RbxDbgInfo::SetServerGitHash(s: p_gitHash->_Mypair._Myval2._Bx._Buf); /*0x1410453a9*/
      if ( FLog::Output != 0 )
      {
        v17 = &gitHash; /*0x1410453bd*/
        if ( gitHash._Mypair._Myval2._Myres >= 0x10 ) /*0x1410453c6*/
          v17 = (std::string *)gitHash._Mypair._Myval2._Bx._Ptr; /*0x1410453c6*/
        FLog::FastLogS(
          level: FLog::Output,
          message: "[FLog::Output] Server RobloxGitHash: %s",
          sarg: v17->_Mypair._Myval2._Bx._Buf);
        if ( FLog::Output != 0 )
        {
          ServerLogPrefix = RBX::Players::getServerLogPrefix(this: (RBX::Players *)v15, result: &v42); /*0x1410453ea*/
          __wind
          {
            if ( ServerLogPrefix->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410453f5*/
              ServerLogPrefix = (std::string *)ServerLogPrefix->_Mypair._Myval2._Bx._Ptr; /*0x1410453f7*/
            FLog::FastLogS(
              level: FLog::Output,
              message: "[FLog::Output] Server Prefix: %s",
              sarg: ServerLogPrefix->_Mypair._Myval2._Bx._Buf);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v42); /*0xf1c000000000005c*/
          }
          if ( v42._Mypair._Myval2._Myres >= 0x10 ) /*0x14104541c*/
          {
            v19 = v42._Mypair._Myval2._Bx._Ptr; /*0x141045421*/
            if ( v42._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045432*/
            {
              v19 = *((char **)v42._Mypair._Myval2._Bx._Ptr - 1); /*0x141045438*/
              if ( (unsigned __int64)(v42._Mypair._Myval2._Bx._Ptr - v19 - 8) > 0x1F ) /*0x141045447*/
                _invalid_parameter_noinfo_noreturn(); /*0x141045449*/
            }
            operator delete(ptr: v19); /*0x141045450*/
          }
        }
      }
      if ( gitHash._Mypair._Myval2._Myres >= 0x10 ) /*0x14104545e*/
      {
        v20 = gitHash._Mypair._Myval2._Bx._Ptr; /*0x141045463*/
        if ( gitHash._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045471*/
        {
          v20 = *((char **)gitHash._Mypair._Myval2._Bx._Ptr - 1); /*0x141045477*/
          if ( (unsigned __int64)(gitHash._Mypair._Myval2._Bx._Ptr - v20 - 8) > 0x1F ) /*0x141045486*/
            _invalid_parameter_noinfo_noreturn(); /*0x141045488*/
        }
        operator delete(ptr: v20); /*0x14104548f*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&gitHash); /*0xf1c0000000000050*/
    }
  }
  if ( FFlag::SessionGamePlayEvents3.value ) /*0x14104549b*/
  {
    __wind /*0xf1c0000000000040*/
    {
      key._Mypair._Myval2._Myres = 15; /*0x1410454a6*/
      key._Mypair._Myval2._Mysize = 7; /*0x1410454ae*/
      qmemcpy(&key, "PlaceI", 6); /*0x1410454bc*/
      *(_WORD *)&key._Mypair._Myval2._Bx._Alias[6] = (unsigned __int8)aPlaceid_16[6]; /*0x1410454d3*/
      ParamInt64 = RBX::GameConfigurer::getParamInt64(this, &key); /*0x1410454e9*/
      if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x1410454f4*/
      {
        v22 = key._Mypair._Myval2._Bx._Ptr; /*0x1410454f9*/
        if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045508*/
        {
          v22 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x14104550e*/
          if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x14104551d*/
            _invalid_parameter_noinfo_noreturn(); /*0x14104551f*/
        }
        operator delete(ptr: v22); /*0x141045526*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key); /*0xf1c0000000000038*/
    }
    v23 = RBX::SessionAppEventsHandler::instance(result: (std::shared_ptr<RBX::SessionAppEventsHandler> *)&v39.x); /*0x14104552f*/
    __wind /*0xf1c0000000000028*/
    {
      v24 = v23->_Ptr; /*0x141045535*/
      v25 = std::to_string(result: &v39.text, value: ParamInt64); /*0x14104553f*/
      __wind /*0xf1c0000000000004*/
      {
        RBX::SessionAppEventsHandler::onGameLoaded(this: v24, placeId: v25); /*0x14104554b*/
        if ( v39.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141045559*/
        {
          v26 = v39.text._Mypair._Myval2._Bx._Ptr; /*0x14104555e*/
          if ( v39.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104556c*/
          {
            v26 = *((char **)v39.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141045572*/
            if ( (unsigned __int64)(v39.text._Mypair._Myval2._Bx._Ptr - v26 - 8) > 0x1F ) /*0x141045581*/
              _invalid_parameter_noinfo_noreturn(); /*0x141045583*/
          }
          operator delete(ptr: v26); /*0x14104558a*/
        }
        v39.text._Mypair._Myval2._Mysize = 0; /*0x14104558f*/
        v39.text._Mypair._Myval2._Myres = 15; /*0x141045593*/
        v39.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104559b*/
        v27 = *(volatile signed __int32 **)&v39.width; /*0x14104559f*/
        if ( *(_QWORD *)&v39.width != 0 /*0x1410455b2*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)&v39.width + 8LL), 0xFFFFFFFF) == 1 )
        {
          (**(void (__fastcall ***)(volatile signed __int32 *))v27)(a1: v27); /*0x1410455ba*/
          if ( _InterlockedExchangeAdd(v27 + 3, 0xFFFFFFFF) == 1 ) /*0x1410455c4*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 8LL))(a1: v27); /*0x1410455cc*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v39); /*0xf1c0000000000014*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v39.x); /*0xf1c0000000000020*/
    }
  }
  if ( FFlag::DebugEnableClientTestService.value ) /*0x1410455d6*/
  {
    dataModel = this->dataModel; /*0x1410455d8*/
    v29 = &dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>; /*0x1410455dc*/
    if ( dataModel == nullptr ) /*0x1410455e3*/
      v29 = nullptr; /*0x1410455e3*/
    v30 = (std::_Func_base<void,RBX::DataModel *> *)RBX::ServiceProvider::find<RBX::TestService>(serviceProvider: v29); /*0x1410455e7*/
    if ( v30[9].__vftable != nullptr ) /*0x1410455f1*/
    {
      v31._Ptr = (const RBX::ClientSessionTracker::ClientSessionMetricKey<double,0> *)RBX::TestService::run; /*0x1410455fa*/
      LODWORD(v31._Rep) = 0; /*0x1410455ff*/
      *(_QWORD *)&v39.color = v30; /*0x141045609*/
      v38._Mystorage._Ptrs[0] = (std::_Func_base<void,RBX::DataModel *> *)std::_Func_impl_no_alloc<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::TestService>,boost::_bi::list1<boost::_bi::value<RBX::TestService *>>>,void,RBX::DataModel *>::`vftable'; /*0x141045614*/
      *(std::shared_ptr<RBX::ClientSessionTracker::ClientSessionMetricKey<double,0> const > *)&v38._Mystorage._Ptrs[1] = v31; /*0x141045618*/
      v38._Mystorage._Ptrs[3] = v30; /*0x141045621*/
      v38._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::DataModel *> *)&v38; /*0x14104562a*/
      RBX::DataModel::submitTask(this: this->dataModel, task: &v38, taskType: (RBX::DMTaskType)1); /*0x14104563c*/
    }
  }
}

// Address: 0x141045660 | Name: ?onPlayerChanged@PlayerConfigurer@RBX@@AEAAXPEBVPropertyDescriptor@Reflection@2@@Z
void __fastcall RBX::PlayerConfigurer::onPlayerChanged(
        RBX::PlayerConfigurer *this,
        const RBX::Reflection::PropertyDescriptor *propertyDescriptor)
{
  const RBX::Name *name; // rcx
  unsigned __int64 Mysize; // rax
  double v5; // xmm6_8
  long double v6; // xmm3_8
  char *Ptr; // rcx
  char *v8; // rcx
  long double v9; // xmm6_8
  RBX::InferredCrash *Instance; // rax
  std::string *v11; // rax
  char *v12; // rcx
  std::string *v13; // rax
  unsigned __int64 v14; // rdx
  unsigned __int64 Myres; // r8
  std::string *v16; // rax
  std::string *v17; // rcx
  std::string *p_successCounterByOsAndLaunchType; // rdx
  std::string *v19; // rax
  char *v20; // rcx
  char *v21; // rcx
  char *v22; // rcx
  char *v23; // rcx
  char *v24; // rcx
  char v25; // bl
  std::shared_ptr<RBX::Instance> *v26; // rax
  __int64 Terrain; // rax
  RBX::MegaClusterInstance *v28; // r14
  __int64 v29; // rbx
  RBX::Reflection::ClassDescriptor *v30; // rax
  bool v31; // r8
  std::string *p_networkType; // rdx
  std::string *v33; // r8
  int ParamInt; // ebx
  char *v35; // rcx
  char *v36; // rcx
  char *v37; // rcx
  __int64 ParamInt64; // rbx
  std::weak_ptr<RBX::DataModel> *v39; // rax
  char *v40; // rcx
  std::weak_ptr<RBX::DataModel> *v41; // rax
  std::string result; // [rsp+30h] [rbp-D0h] BYREF
  std::string category; // [rsp+50h] [rbp-B0h] BYREF
  std::string networkType; // [rsp+70h] [rbp-90h] BYREF
  std::string status; // [rsp+90h] [rbp-70h] BYREF
  std::string v46; // [rsp+B0h] [rbp-50h] BYREF
  std::shared_ptr<RBX::ClientSessionTracker::ClientSessionMetricKey<double,0> const > v47; // [rsp+D0h] [rbp-30h] BYREF
  std::string key; // [rsp+E0h] [rbp-20h] BYREF
  std::string successCounterByOsAndLaunchType; // [rsp+100h] [rbp+0h] BYREF
  std::string v50; // [rsp+120h] [rbp+20h] BYREF
  std::string v51; // [rsp+140h] [rbp+40h] BYREF
  std::weak_ptr<RBX::DataModel const > v52; // [rsp+160h] [rbp+60h] BYREF
  std::weak_ptr<RBX::DataModel const > v53; // [rsp+170h] [rbp+70h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v54; // [rsp+180h] [rbp+80h] BYREF
  __int64 v55; // [rsp+1E8h] [rbp+E8h]

  name = propertyDescriptor->name; /*0x141045686*/
  Mysize = name->str._Mypair._Myval2._Mysize; /*0x14104568a*/
  if ( name->str._Mypair._Myval2._Myres >= 0x10 ) /*0x141045693*/
    name = (const RBX::Name *)name->str._Mypair._Myval2._Bx._Ptr; /*0x141045695*/
  if ( Mysize == 9 && memcmp_0(Buf1: name, Buf2: "Character", Size: 9u) == 0 ) /*0x1410456b3*/
  {
    this->waitingForCharacter = false; /*0x1410456b9*/
    rbx::signals::connection::disconnect(this: &this->playerChangedConnection.con); /*0x1410456c3*/
    if ( !this->joinResolved ) /*0x1410456cf*/
    {
      this->joinResolved = true; /*0x1410456d5*/
      v5 = RBX::Time::nowFastSec(); /*0x1410456de*/
      v6 = v5 - this->sgs.avatarConfigureTime; /*0x1410456e4*/
      result._Mypair._Myval2._Myres = 15; /*0x1410456f1*/
      result._Mypair._Myval2._Mysize = 7; /*0x1410456fa*/
      strcpy(result._Mypair._Myval2._Bx._Buf, "Success"); /*0x141045709*/
      __wind /*0xf1c0000000000118*/
      {
        category._Mypair._Myval2._Myres = 15; /*0x141045729*/
        category._Mypair._Myval2._Mysize = 8; /*0x141045732*/
        strcpy(category._Mypair._Myval2._Bx._Buf, "GameJoin"); /*0x141045745*/
        __wind /*0xf1c00000000000f4*/
        {
          RBX::PlayerConfigurer::reportDuration(this, &category, &result, duration: v6); /*0x14104575c*/
          if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x14104576b*/
          {
            Ptr = category._Mypair._Myval2._Bx._Ptr; /*0x141045770*/
            if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104577f*/
            {
              Ptr = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x141045785*/
              if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141045794*/
                _invalid_parameter_noinfo_noreturn(); /*0x141045796*/
            }
            operator delete(ptr: Ptr); /*0x14104579d*/
          }
          category._Mypair._Myval2._Mysize = 0; /*0x1410457a2*/
          category._Mypair._Myval2._Myres = 15; /*0x1410457a7*/
          category._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410457b0*/
          if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x1410457be*/
          {
            v8 = result._Mypair._Myval2._Bx._Ptr; /*0x1410457c3*/
            if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410457d2*/
            {
              v8 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x1410457d8*/
              if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v8 - 8) > 0x1F ) /*0x1410457e7*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410457e9*/
            }
            operator delete(ptr: v8); /*0x1410457f0*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&category); /*0xf1c0000000000104*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000110*/
      }
      if ( FFlag::LogClientLoadToAvatarLoad.value && FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x141045807*/
      {
        FLog::FastLog( /*0x141045813*/
          level: FLog::LogStepTimeAndNetworkUsage,
          message: "[FLog::LogStepTimeAndNetworkUsage] Game Join",
          arg0: nullptr);
        if ( FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x141045821*/
          FLog::FastLogFormatted( /*0x14104582c*/
            level: FLog::LogStepTimeAndNetworkUsage,
            message: "[FLog::LogStepTimeAndNetworkUsage] 0, 0, 0, 0");
      }
      if ( DFFlag::HttpTrackSyncWriteCachePhase.value ) /*0x141045838*/
        _InterlockedExchange64(&RBX::Http::syncCacheWriteTime._Storage._Value, 0); /*0x14104583d*/
      v9 = v5 - this->sgs.userClickTime; /*0x141045844*/
      this->sgs.gameJoinTime = v9; /*0x141045849*/
      if ( DFFlag::SessionTrackingFlushAtImportantCheckpoints.value ) /*0x141045858*/
      {
        Instance = RBX::InferredCrash::getInstance(); /*0x14104585a*/
        RBX::InferredCrash::onPlayerJoined(this: Instance, playerJoinedTime: this->sgs.gameJoinTime); /*0x14104586a*/
      }
      else
      {
        v47 = 0; /*0x141045874*/
        if ( RBX::ClientSessionTrackerKeys::GameJoinTime._Rep != nullptr ) /*0x141045883*/
          _InterlockedIncrement((volatile signed __int32 *)&RBX::ClientSessionTrackerKeys::GameJoinTime._Rep->_Uses); /*0x141045885*/
        v47 = RBX::ClientSessionTrackerKeys::GameJoinTime; /*0x141045890*/
        RBX::updateClientSessionMetric_double_0_(metricKey: &v47, value: v9, bFlush: true); /*0x14104589e*/
      }
      if ( DFFlag::ReportFailuresInClientJoinAll2.value ) /*0x1410458aa*/
        this->sgs.joinPhase = JoinPhase_GameJoined; /*0x1410458ac*/
      v11 = RBX::SystemUtil::osPlatform(result: &v50); /*0x1410458ba*/
      __wind /*0xf1c00000000000d0*/
      {
        std::operator+<char>(result: &successCounterByOsAndLaunchType, _Left: "GameJoinSuccess_", _Right: v11); /*0x1410458ce*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v50); /*0xf1c00000000000e0*/
      }
      __wind /*0xf1c00000000000e8*/
      {
        if ( v50._Mypair._Myval2._Myres >= 0x10 ) /*0x1410458dc*/
        {
          v12 = v50._Mypair._Myval2._Bx._Ptr; /*0x1410458e1*/
          if ( v50._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410458ef*/
          {
            v12 = *((char **)v50._Mypair._Myval2._Bx._Ptr - 1); /*0x1410458f5*/
            if ( (unsigned __int64)(v50._Mypair._Myval2._Bx._Ptr - v12 - 8) > 0x1F ) /*0x141045904*/
              _invalid_parameter_noinfo_noreturn(); /*0x141045906*/
          }
          operator delete(ptr: v12); /*0x14104590d*/
        }
        v50._Mypair._Myval2._Mysize = 0; /*0x141045912*/
        v50._Mypair._Myval2._Myres = 15; /*0x141045916*/
        v50._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104591e*/
        v13 = RBX::SystemUtil::osPlatform(result: &v54.text); /*0x141045929*/
        __wind /*0xf1c00000000000c4*/
        {
          v16 = std::operator+<char>(result: &v51, _Left: "GameJoinSuccess,GameJoin", _Right: v13); /*0x14104593d*/
          v17 = v16; /*0x141045942*/
          __wind /*0xf1c00000000000b8*/
          {
            v14 = v16->_Mypair._Myval2._Mysize; /*0x141045945*/
            Myres = v16->_Mypair._Myval2._Myres; /*0x141045949*/
            if ( Myres == v14 ) /*0x141045950*/
            {
              v17 = std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x141045991*/
                      this: v16,
                      _Size_increase: 1u,
                      _Fn: 0,
                      <_Args_0>: ",",
                      <_Args_1>: 1u);
            }
            else
            {
              v16->_Mypair._Myval2._Mysize = v14 + 1; /*0x14104595d*/
              if ( Myres >= 0x10 ) /*0x141045968*/
                v16 = (std::string *)v16->_Mypair._Myval2._Bx._Ptr; /*0x14104596a*/
              *(_WORD *)&v16->_Mypair._Myval2._Bx._Buf[v14] = 44; /*0x14104596d*/
            }
            category._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141045994*/
            category._Mypair._Myval2._Mysize = 0; /*0x141045999*/
            category._Mypair._Myval2._Myres = 0; /*0x14104599e*/
            category = *v17; /*0x1410459a6*/
            v17->_Mypair._Myval2._Mysize = 0; /*0x1410459b4*/
            v17->_Mypair._Myval2._Myres = 15; /*0x1410459b8*/
            v17->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410459c0*/
            __wind /*0xf1c000000000007c*/
            {
              p_successCounterByOsAndLaunchType = &successCounterByOsAndLaunchType; /*0x1410459c3*/
              if ( successCounterByOsAndLaunchType._Mypair._Myval2._Myres >= 0x10 ) /*0x1410459cc*/
                p_successCounterByOsAndLaunchType = (std::string *)successCounterByOsAndLaunchType._Mypair._Myval2._Bx._Ptr; /*0x1410459cc*/
              v19 = std::string::append( /*0x1410459da*/
                      this: &category,
                      _Ptr: p_successCounterByOsAndLaunchType->_Mypair._Myval2._Bx._Buf,
                      _Count: successCounterByOsAndLaunchType._Mypair._Myval2._Mysize);
              result._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410459df*/
              result._Mypair._Myval2._Mysize = 0; /*0x1410459e4*/
              result._Mypair._Myval2._Myres = 0; /*0x1410459e9*/
              result = *v19; /*0x1410459f1*/
              v19->_Mypair._Myval2._Mysize = 0; /*0x1410459ff*/
              v19->_Mypair._Myval2._Myres = 15; /*0x141045a03*/
              v19->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141045a0b*/
              __wind /*0xf1c0000000000070*/
              {
                RBX::PlayerConfigurer::reportCounter(this, counterNamesCSV: &result, blocking: false); /*0x141045a19*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000068*/
              }
              if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141045a28*/
              {
                v20 = result._Mypair._Myval2._Bx._Ptr; /*0x141045a2d*/
                if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045a3c*/
                {
                  v20 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x141045a42*/
                  if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v20 - 8) > 0x1F ) /*0x141045a51*/
                    _invalid_parameter_noinfo_noreturn(); /*0x141045a53*/
                }
                operator delete(ptr: v20); /*0x141045a5a*/
              }
              result._Mypair._Myval2._Mysize = 0; /*0x141045a5f*/
              result._Mypair._Myval2._Myres = 15; /*0x141045a64*/
              result._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141045a6d*/
              if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x141045a7b*/
              {
                v21 = category._Mypair._Myval2._Bx._Ptr; /*0x141045a80*/
                if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045a8f*/
                {
                  v21 = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x141045a95*/
                  if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x141045aa4*/
                    _invalid_parameter_noinfo_noreturn(); /*0x141045aa6*/
                }
                operator delete(ptr: v21); /*0x141045aad*/
              }
              category._Mypair._Myval2._Mysize = 0; /*0x141045ab2*/
              category._Mypair._Myval2._Myres = 15; /*0x141045ab7*/
              category._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141045ac0*/
              if ( v51._Mypair._Myval2._Myres >= 0x10 ) /*0x141045acd*/
              {
                v22 = v51._Mypair._Myval2._Bx._Ptr; /*0x141045ad2*/
                if ( v51._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045ae0*/
                {
                  v22 = *((char **)v51._Mypair._Myval2._Bx._Ptr - 1); /*0x141045ae6*/
                  if ( (unsigned __int64)(v51._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x141045af5*/
                    _invalid_parameter_noinfo_noreturn(); /*0x141045af7*/
                }
                operator delete(ptr: v22); /*0x141045afe*/
              }
              v51._Mypair._Myval2._Mysize = 0; /*0x141045b03*/
              v51._Mypair._Myval2._Myres = 15; /*0x141045b07*/
              v51._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141045b0f*/
              if ( v54.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141045b1e*/
              {
                v23 = v54.text._Mypair._Myval2._Bx._Ptr; /*0x141045b23*/
                if ( v54.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045b34*/
                {
                  v23 = *((char **)v54.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141045b3a*/
                  if ( (unsigned __int64)(v54.text._Mypair._Myval2._Bx._Ptr - v23 - 8) > 0x1F ) /*0x141045b49*/
                    _invalid_parameter_noinfo_noreturn(); /*0x141045b4b*/
                }
                operator delete(ptr: v23); /*0x141045b52*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&category); /*0xf1c000000000008c*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v51); /*0xf1c0000000000098*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v54); /*0xf1c00000000000a4*/
        }
        __wind /*0xf1c00000000000ac*/
        {
          status._Mypair._Myval2._Myres = 15; /*0x141045b5b*/
          status._Mypair._Myval2._Mysize = 6; /*0x141045b63*/
          *(_DWORD *)status._Mypair._Myval2._Bx._Buf = *(_DWORD *)"InGame"; /*0x141045b71*/
          *(_DWORD *)&status._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"me"; /*0x141045b7b*/
          RBX::Stats::reportGameStatus(&status, blocking: false); /*0x141045b89*/
          if ( status._Mypair._Myval2._Myres >= 0x10 ) /*0x141045b97*/
          {
            v24 = status._Mypair._Myval2._Bx._Ptr; /*0x141045b9c*/
            if ( status._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045baa*/
            {
              v24 = *((char **)status._Mypair._Myval2._Bx._Ptr - 1); /*0x141045bb0*/
              if ( (unsigned __int64)(status._Mypair._Myval2._Bx._Ptr - v24 - 8) > 0x1F ) /*0x141045bbf*/
                _invalid_parameter_noinfo_noreturn(); /*0x141045bc1*/
            }
            operator delete(ptr: v24); /*0x141045bc8*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&status); /*0xf1c000000000005c*/
        }
        v25 = 0; /*0x141045bcd*/
        v26 = RBX::ServiceProvider::refByClass<RBX::Players>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x141045bd7*/
        if ( v26->_Ptr != nullptr ) /*0x141045be2*/
          v25 = BYTE1(v26->_Ptr[1].onDemandPtr._Mypair._Myval2); /*0x141045be4*/
        RBX::Analytics::InfluxDb::Points::addPoint(this: &this->analyticsPoints, name: "CharacterAutoSpawn", value: v25); /*0x141045c00*/
        Terrain = RBX::WorldRoot::getTerrain(this: (RBX::HumanoidDescription *)this->dataModel->workspace._Ptr); /*0x141045c10*/
        v28 = (RBX::MegaClusterInstance *)Terrain; /*0x141045c15*/
        v31 = false; /*0x141045c4d*/
        if ( Terrain != 0 ) /*0x141045c1b*/
        {
          v29 = *(_QWORD *)(Terrain + 24); /*0x141045c1d*/
          v30 = RBX::Reflection::Class_getDescriptorPtr<RBX::MegaClusterInstance>(); /*0x141045c21*/
          if ( *(unsigned __int16 *)(v29 + 888) - (unsigned int)v30->index <= v30->descendantCount /*0x141045c44*/
            && RBX::MegaClusterInstance::isAllocated(this: v28) )
          {
            v31 = true; /*0x141045c1b*/
          }
        }
        RBX::Analytics::InfluxDb::Points::addPoint(this: &this->analyticsPoints, name: "HasTerrain", value: v31); /*0x141045c5f*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x141045c81*/
          this: &this->analyticsPoints,
          name: "StreamingEnabled",
          value: BYTE1(this->dataModel->workspace._Ptr->statsJoinAllTime));
        LODWORD(v55) = RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2->storage.asRaw[0] /*0x141045c91*/
                     - LODWORD(RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2);
        HIDWORD(v55) = RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2->storage.asRaw[1] /*0x141045c9c*/
                     - LODWORD(RBX::TeleportService::previousPlaceId.storage._Mypair._Myval2);
        if ( v55 > 0 ) /*0x141045caa*/
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x141045cc0*/
            this: &this->analyticsPoints,
            name: "Mode",
            value: "Teleport",
            updateExisting: true);
        LuaVM::compile(result: &networkType); /*0x141045cca*/
        __wind /*0xf1c000000000004c*/
        {
          if ( networkType._Mypair._Myval2._Mysize != 0 ) /*0x141045cd7*/
          {
            if ( &this->sgs.networkType != &networkType ) /*0x141045ce8*/
            {
              p_networkType = &networkType; /*0x141045cea*/
              if ( networkType._Mypair._Myval2._Myres >= 0x10 ) /*0x141045cf4*/
                p_networkType = (std::string *)networkType._Mypair._Myval2._Bx._Ptr; /*0x141045cf4*/
              std::string::assign( /*0x141045cfa*/
                this: &this->sgs.networkType,
                _Ptr: p_networkType->_Mypair._Myval2._Bx._Buf,
                _Count: networkType._Mypair._Myval2._Mysize);
            }
            v33 = &networkType; /*0x141045cff*/
            if ( networkType._Mypair._Myval2._Myres >= 0x10 ) /*0x141045d09*/
              v33 = (std::string *)networkType._Mypair._Myval2._Bx._Ptr; /*0x141045d09*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141045d19*/
              this: &this->analyticsPoints,
              name: "NetworkType",
              value: v33->_Mypair._Myval2._Bx._Buf);
          }
          key._Mypair._Myval2._Myres = 15; /*0x141045d1e*/
          key._Mypair._Myval2._Mysize = 12; /*0x141045d26*/
          strcpy(key._Mypair._Myval2._Bx._Buf, "DataCenterId"); /*0x141045d36*/
          __wind /*0xf1c0000000000040*/
          {
            ParamInt = RBX::GameConfigurer::getParamInt(this, &key); /*0x141045d54*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key); /*0xf1c0000000000038*/
          }
          if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x141045d5e*/
          {
            v35 = key._Mypair._Myval2._Bx._Ptr; /*0x141045d63*/
            if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045d71*/
            {
              v35 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x141045d77*/
              if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v35 - 8) > 0x1F ) /*0x141045d86*/
                _invalid_parameter_noinfo_noreturn(); /*0x141045d88*/
            }
            operator delete(ptr: v35); /*0x141045d8f*/
          }
          if ( ParamInt != 0 ) /*0x141045d96*/
          {
            this->sgs.dataCenterId = ParamInt; /*0x141045d98*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x141045dab*/
              this: &this->analyticsPoints,
              name: "DataCenterId",
              value: ParamInt);
          }
          this->playStartTime = RBX::Time::nowFastSec(); /*0x141045db5*/
          this->playResolved = false; /*0x141045dba*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&networkType); /*0xf1c000000000002c*/
        }
        if ( networkType._Mypair._Myval2._Myres >= 0x10 ) /*0x141045dc6*/
        {
          v36 = networkType._Mypair._Myval2._Bx._Ptr; /*0x141045dcb*/
          if ( networkType._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045dda*/
          {
            v36 = *((char **)networkType._Mypair._Myval2._Bx._Ptr - 1); /*0x141045de0*/
            if ( (unsigned __int64)(networkType._Mypair._Myval2._Bx._Ptr - v36 - 8) > 0x1F ) /*0x141045def*/
              _invalid_parameter_noinfo_noreturn(); /*0x141045df1*/
          }
          operator delete(ptr: v36); /*0x141045df8*/
        }
        networkType._Mypair._Myval2._Mysize = 0; /*0x141045dfd*/
        networkType._Mypair._Myval2._Myres = 15; /*0x141045e01*/
        networkType._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141045e09*/
        if ( successCounterByOsAndLaunchType._Mypair._Myval2._Myres >= 0x10 ) /*0x141045e16*/
        {
          v37 = successCounterByOsAndLaunchType._Mypair._Myval2._Bx._Ptr; /*0x141045e1b*/
          if ( successCounterByOsAndLaunchType._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045e29*/
          {
            v37 = *((char **)successCounterByOsAndLaunchType._Mypair._Myval2._Bx._Ptr - 1); /*0x141045e2f*/
            if ( (unsigned __int64)(successCounterByOsAndLaunchType._Mypair._Myval2._Bx._Ptr - v37 - 8) > 0x1F ) /*0x141045e3e*/
              _invalid_parameter_noinfo_noreturn(); /*0x141045e40*/
          }
          operator delete(ptr: v37); /*0x141045e47*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&successCounterByOsAndLaunchType); /*0xf1c0000000000020*/
      }
    }
    if ( !this->testing ) /*0x141045e50*/
    {
      __wind /*0xf1c0000000000010*/
      {
        v46._Mypair._Myval2._Myres = 15; /*0x141045e5a*/
        v46._Mypair._Myval2._Mysize = 6; /*0x141045e62*/
        strcpy(v46._Mypair._Myval2._Bx._Buf, "UserId"); /*0x141045e70*/
        v46._Mypair._Myval2._Bx._Buf[7] = 0; /*0x141045e7a*/
        ParamInt64 = RBX::GameConfigurer::getParamInt64(this, key: &v46); /*0x141045e8e*/
        v39 = (std::weak_ptr<RBX::DataModel> *)RBX::weak_from<RBX::DataModel>(result: &v52, r: this->dataModel); /*0x141045e99*/
        RBX::GamePerfMonitor::start(weakDataModel: v39, userId: ParamInt64); /*0x141045ea4*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v46); /*0xf1c0000000000008*/
      }
      if ( v46._Mypair._Myval2._Myres >= 0x10 ) /*0x141045eb2*/
      {
        v40 = v46._Mypair._Myval2._Bx._Ptr; /*0x141045eb7*/
        if ( v46._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141045ec5*/
        {
          v40 = *((char **)v46._Mypair._Myval2._Bx._Ptr - 1); /*0x141045ecb*/
          if ( (unsigned __int64)(v46._Mypair._Myval2._Bx._Ptr - v40 - 8) > 0x1F ) /*0x141045eda*/
            _invalid_parameter_noinfo_noreturn(); /*0x141045edc*/
        }
        operator delete(ptr: v40); /*0x141045ee3*/
      }
      v41 = (std::weak_ptr<RBX::DataModel> *)RBX::weak_from<RBX::DataModel>(result: &v53, r: this->dataModel); /*0x141045ef0*/
      RBX::HardwareTelemetry::start(weakDataModel: v41); /*0x141045ef8*/
    }
  }
}

// Address: 0x141045f20 | Name: ?onReceivedGlobals@PlayerConfigurer@RBX@@AEAAXXZ
void __fastcall RBX::PlayerConfigurer::onReceivedGlobals(RBX::PlayerConfigurer *this)
{
  double v2; // xmm0_8
  std::vector<std::shared_ptr<RBX::Instance>> *v3; // rax
  RBX::Instance *v4; // rdi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v6; // rax
  double (__fastcall *v7)(const RBX::Reflection::ClassDescriptor **, _BYTE *); // rbx
  char *v8; // rax
  void *v9; // rcx
  _BYTE ptr[40]; // [rsp+20h] [rbp-28h] BYREF

  v2 = RBX::Time::nowFastSec() - this->sgs.userClickTime; /*0x141045f37*/
  this->sgs.receivedGlobalsTime = v2; /*0x141045f3c*/
  if ( DFFlag::ReportFailuresInClientJoinAll2.value ) /*0x141045f4b*/
    this->sgs.joinPhase = JoinPhase_ReceivedGlobals; /*0x141045f4d*/
  if ( FLog::AvatarJoinMetrics != 0 ) /*0x141045f60*/
    FLog::FastLogFormatted( /*0x141045f73*/
      level: FLog::AvatarJoinMetrics,
      message: "[FLog::AvatarJoinMetrics] receivedGlobalsTime = %g",
      v2);
  v3 = RBX::ServiceProvider::create<RBX::Network::Client>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>)->children.object._Ptr; /*0x141045f85*/
  if ( v3 != nullptr && v3->_Mypair._Myval2._Mylast - v3->_Mypair._Myval2._Myfirst != 0 ) /*0x141045fa3*/
  {
    v4 = v3->_Mypair._Myval2._Myfirst->_Ptr; /*0x141045fa9*/
    if ( v4 != nullptr ) /*0x141045faf*/
    {
      descriptor = v4->descriptor; /*0x141045fb5*/
      v6 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(); /*0x141045fb9*/
      if ( descriptor->index - (unsigned int)v6->index <= v6->descendantCount ) /*0x141045fd7*/
      {
        v7 = *(double (__fastcall **)(const RBX::Reflection::ClassDescriptor **, _BYTE *))&v4[1].descriptor->attributes.isDeprecated; /*0x141045fe4*/
        v8 = (char *)operator new(size: 0x20u); /*0x141046004*/
        *(_QWORD *)&ptr[16] = 20; /*0x141046009*/
        *(_QWORD *)&ptr[24] = 31; /*0x141046012*/
        strcpy(v8, "Total Bytes Received"); /*0x141046022*/
        *(_QWORD *)ptr = v8; /*0x141046032*/
        __wind /*0xf1c0000000000010*/
        {
          this->sgs.gameReceiveGlobalsBytesReceived = v7(a1: &v4[1].descriptor, a2: ptr); /*0x141046045*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)ptr); /*0xf1c0000000000008*/
        }
        if ( *(_QWORD *)&ptr[24] >= 0x10u ) /*0x141046056*/
        {
          v9 = *(void **)ptr; /*0x14104605b*/
          if ( (unsigned __int64)(*(_QWORD *)&ptr[24] + 1LL) >= 0x1000 ) /*0x14104606a*/
          {
            v9 = *(void **)(*(_QWORD *)ptr - 8LL); /*0x141046070*/
            if ( (unsigned __int64)(*(_QWORD *)ptr - (_QWORD)v9 - 8LL) > 0x1F ) /*0x14104607f*/
              _invalid_parameter_noinfo_noreturn(); /*0x141046081*/
          }
          operator delete(ptr: v9); /*0x141046088*/
        }
      }
    }
  }
  if ( FFlag::LogClientLoadToAvatarLoad.value && FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x14104609f*/
  {
    FLog::FastLog( /*0x1410460ab*/
      level: FLog::LogStepTimeAndNetworkUsage,
      message: "[FLog::LogStepTimeAndNetworkUsage] Received Globals",
      arg0: nullptr);
    if ( FLog::LogStepTimeAndNetworkUsage != 0 ) /*0x1410460b9*/
      FLog::FastLogFormatted( /*0x1410460c4*/
        level: FLog::LogStepTimeAndNetworkUsage,
        message: "[FLog::LogStepTimeAndNetworkUsage] 0, 0, 0, 0");
  }
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410460ee*/
    this: &this->analyticsPoints,
    name: "ReceivedGlobalsTime",
    value: this->sgs.receivedGlobalsTime);
}

// Address: 0x1410469a0 | Name: ?reportCounter@PlayerConfigurer@RBX@@AEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@_N@Z
void __fastcall RBX::PlayerConfigurer::reportCounter(
        RBX::PlayerConfigurer *this,
        const std::string *counterNamesCSV,
        bool blocking)
{
  const char *v3; // rax
  std::exception *e; // [rsp+20h] [rbp-18h] BYREF

  try
  {
    RBX::Analytics::EphemeralCounter::reportCountersCSV(counterNamesCSV, blocking); /*0x1410469ae*/
  }
  catch ( std::exception *e )
  {
    v3 = e->what(this: e); /*0x1431e8094*/
    RBX::StandardOut::printf(type: MESSAGE_INFO, format: "reportCounter failed: %s", v3);
  }
}

// Address: 0x1410469c0 | Name: ?reportDuration@PlayerConfigurer@RBX@@AEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@0N@Z
void __fastcall RBX::PlayerConfigurer::reportDuration(
        RBX::PlayerConfigurer *this,
        const std::string *category,
        const std::string *result,
        long double duration)
{
  RBX::PlayerConfigurer *v7; // r13
  float v8; // xmm6_4
  double v9; // xmm8_8
  std::vector<std::shared_ptr<RBX::Instance>> *v10; // rax
  RBX::Instance *v11; // rdi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v13; // rax
  double (__fastcall *v14)(const RBX::Reflection::ClassDescriptor **, std::string *); // rbx
  char *v15; // rax
  char *v16; // rcx
  unsigned __int64 _Left_size; // rcx
  const std::string *v18; // r9
  const std::string *v19; // rdx
  std::string *v20; // rax
  unsigned __int64 Mysize; // rcx
  std::string *v22; // rbx
  char *v23; // rbx
  std::string *v24; // rax
  long double v25; // xmm6_8
  char *v26; // rcx
  char *v27; // rcx
  char *v28; // rcx
  unsigned __int64 v29; // rcx
  const std::string *v30; // r9
  const std::string *v31; // rdx
  std::string *v32; // rax
  unsigned __int64 v33; // rcx
  std::string *v34; // rbx
  char *v35; // rbx
  std::string *v36; // rax
  float v37; // xmm0_4
  char *v38; // rcx
  char *v39; // rcx
  char *v40; // rcx
  const std::string *v41; // r8
  const std::string *v42; // r8
  char *v43; // rcx
  char *v44; // rcx
  int ParamInt; // eax
  char *v46; // rcx
  const std::string *v47; // rcx
  const std::string *v48; // rdx
  __int64 v49; // rcx
  unsigned __int8 v50; // al
  int v51; // eax
  size_t v52; // r13
  std::string *v53; // rdx
  unsigned __int64 v54; // r12
  unsigned __int64 v55; // rbx
  char *v56; // rdi
  unsigned __int64 v57; // rax
  void *v58; // rax
  char *v59; // rcx
  unsigned __int64 v60; // rbx
  const std::string *v61; // rcx
  unsigned __int64 Myres; // rdi
  const std::string *v63; // rcx
  unsigned __int64 v64; // rax
  const std::string *v65; // r9
  std::string *p_dataCenterId; // rdx
  std::string *v67; // rax
  char *v68; // rcx
  char *v69; // rcx
  unsigned __int64 v70; // rax
  const std::string *v71; // r9
  std::string *v72; // rdx
  char *v73; // rcx
  unsigned __int64 v74; // rbx
  const std::string *v75; // rcx
  unsigned __int64 v76; // rdi
  const char *v77; // rax
  std::string v78; // [rsp+40h] [rbp-158h] BYREF
  std::string ptr; // [rsp+60h] [rbp-138h] BYREF
  std::string dataCenterId; // [rsp+80h] [rbp-118h] BYREF
  std::string v81; // [rsp+A0h] [rbp-F8h] BYREF
  std::exception *e; // [rsp+C0h] [rbp-D8h] BYREF
  RBX::Analytics::InfluxDb::Points durationAnalyticsPoint; // [rsp+D0h] [rbp-C8h] BYREF
  std::string *v85; // [rsp+1B8h] [rbp+20h]

  v7 = this; /*0x1410469f5*/
  v8 = duration * 1000.0; /*0x141046a06*/
  v9 = -1.0; /*0x141046a0a*/
  v10 = RBX::ServiceProvider::create<RBX::Network::Client>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>)->children.object._Ptr; /*0x141046a20*/
  if ( v10 != nullptr && v10->_Mypair._Myval2._Mylast - v10->_Mypair._Myval2._Myfirst != 0 ) /*0x141046a3e*/
  {
    v11 = v10->_Mypair._Myval2._Myfirst->_Ptr; /*0x141046a44*/
    if ( v11 != nullptr ) /*0x141046a4a*/
    {
      descriptor = v11->descriptor; /*0x141046a50*/
      v13 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(); /*0x141046a54*/
      if ( descriptor->index - (unsigned int)v13->index <= v13->descendantCount ) /*0x141046a72*/
      {
        v14 = *(double (__fastcall **)(const RBX::Reflection::ClassDescriptor **, std::string *))&v11[1].descriptor->attributes.isDeprecated; /*0x141046a7f*/
        v15 = (char *)operator new(size: 0x20u); /*0x141046aa2*/
        ptr._Mypair._Myval2._Mysize = 20; /*0x141046aa7*/
        ptr._Mypair._Myval2._Myres = 31; /*0x141046ab0*/
        strcpy(v15, "Total Bytes Received"); /*0x141046ac0*/
        ptr._Mypair._Myval2._Bx._Ptr = v15; /*0x141046ad0*/
        __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000110*/
        v9 = v14(a1: &v11[1].descriptor, a2: &ptr); /*0x141046ae3*/
        if ( __eh34_unwind(0) ) /*0xf1c00000000000fc*/
        {
unwind_state_0:
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&ptr); /*0xf1c0000000000100*/
          __eh34_propagate_exception_into_caller(0, -1); /*0xf1c0000000000104*/
        }
        __eh34_exit_wind_state(0, -1); /*0xf1c0000000000108*/
        if ( ptr._Mypair._Myval2._Myres >= 0x10 ) /*0x141046af0*/
        {
          v16 = ptr._Mypair._Myval2._Bx._Ptr; /*0x141046af5*/
          if ( ptr._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141046b04*/
          {
            v16 = *((char **)ptr._Mypair._Myval2._Bx._Ptr - 1); /*0x141046b0a*/
            if ( (unsigned __int64)(ptr._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x141046b19*/
              _invalid_parameter_noinfo_noreturn(); /*0x141046b1b*/
          }
          operator delete(ptr: v16); /*0x141046b22*/
        }
      }
    }
  }
  __eh34_enter_try_state(-1, 1); /*0xf1c00000000000f4*/
  _Left_size = category->_Mypair._Myval2._Mysize; /*0x141046b2c*/
  if ( _Left_size == 0x7FFFFFFFFFFFFFFFLL ) /*0x141046b44*/
    std::_Xlen_string(); /*0x141047725*/
  v18 = category; /*0x141046b4a*/
  if ( category->_Mypair._Myval2._Myres >= 0x10 ) /*0x141046b52*/
    v18 = (const std::string *)category->_Mypair._Myval2._Bx._Ptr; /*0x141046b54*/
  std::string::string( /*0x141046b84*/
    this: &v81,
    __formal: (std::_String_constructor_concat_tag)this,
    _Source_of_al: category,
    _Left_ptr: v18->_Mypair._Myval2._Bx._Buf,
    _Left_size,
    _Right_ptr: "_",
    _Right_size: 1u);
  v19 = result; /*0x141046b8a*/
  if ( result->_Mypair._Myval2._Myres >= 0x10 ) /*0x141046b92*/
    v19 = (const std::string *)result->_Mypair._Myval2._Bx._Ptr; /*0x141046b94*/
  __eh34_enter_wind_state(1, 2); /*0xf1c00000000000ec*/
  v20 = std::string::append(this: &v81, _Ptr: v19->_Mypair._Myval2._Bx._Buf, _Count: result->_Mypair._Myval2._Mysize); /*0x141046ba3*/
  __eh34_enter_wind_state(2, 3); /*0xf1c00000000000e4*/
  v78._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141046ba8*/
  v78._Mypair._Myval2._Mysize = 0; /*0x141046bad*/
  v78._Mypair._Myval2._Myres = 0; /*0x141046bb2*/
  v78 = *v20; /*0x141046bba*/
  v20->_Mypair._Myval2._Mysize = 0; /*0x141046bc8*/
  v20->_Mypair._Myval2._Myres = 15; /*0x141046bcc*/
  v20->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141046bd4*/
  Mysize = v78._Mypair._Myval2._Mysize; /*0x141046bd7*/
  if ( v78._Mypair._Myval2._Myres - v78._Mypair._Myval2._Mysize < 9 ) /*0x141046beb*/
  {
    v24 = std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x141046c44*/
            this: &v78,
            _Size_increase: 9u,
            _Fn: 0,
            <_Args_0>: "_Duration",
            <_Args_1>: 9u);
  }
  else
  {
    v78._Mypair._Myval2._Mysize += 9LL; /*0x141046bf1*/
    v22 = &v78; /*0x141046bf6*/
    if ( v78._Mypair._Myval2._Myres >= 0x10 ) /*0x141046bff*/
      v22 = (std::string *)v78._Mypair._Myval2._Bx._Ptr; /*0x141046bff*/
    v23 = &v22->_Mypair._Myval2._Bx._Buf[Mysize]; /*0x141046c05*/
    memmove_0(a1: v23, Src: "_Duration", Size: 9u); /*0x141046c18*/
    v23[9] = 0; /*0x141046c1d*/
    v24 = &v78; /*0x141046c21*/
  }
  __eh34_enter_wind_state(3, 4); /*0xf1c00000000000dc*/
  ptr._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141046c49*/
  *(_OWORD *)&ptr._Mypair._Myval2._Mysize = 0u; /*0x141046c4e*/
  ptr = *v24; /*0x141046c5b*/
  v24->_Mypair._Myval2._Mysize = 0; /*0x141046c69*/
  v24->_Mypair._Myval2._Myres = 15; /*0x141046c6d*/
  v24->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141046c75*/
  v25 = v8; /*0x141046c78*/
  RBX::Analytics::EphemeralCounter::reportStats(category: &ptr, value: v25, blocking: false); /*0x141046c86*/
  if ( ptr._Mypair._Myval2._Myres >= 0x10 ) /*0x141046c95*/
  {
    v26 = ptr._Mypair._Myval2._Bx._Ptr; /*0x141046c9a*/
    if ( ptr._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141046ca9*/
    {
      v26 = *((char **)ptr._Mypair._Myval2._Bx._Ptr - 1); /*0x141046caf*/
      if ( (unsigned __int64)(ptr._Mypair._Myval2._Bx._Ptr - v26 - 8) > 0x1F ) /*0x141046cbe*/
        _invalid_parameter_noinfo_noreturn(); /*0x141046cc0*/
    }
    operator delete(ptr: v26); /*0x141046cc7*/
  }
  ptr._Mypair._Myval2._Mysize = 0; /*0x141046ccc*/
  ptr._Mypair._Myval2._Myres = 15; /*0x141046cd1*/
  ptr._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141046cda*/
  if ( v78._Mypair._Myval2._Myres >= 0x10 ) /*0x141046ce8*/
  {
    v27 = v78._Mypair._Myval2._Bx._Ptr; /*0x141046ced*/
    if ( v78._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141046cfc*/
    {
      v27 = *((char **)v78._Mypair._Myval2._Bx._Ptr - 1); /*0x141046d02*/
      if ( (unsigned __int64)(v78._Mypair._Myval2._Bx._Ptr - v27 - 8) > 0x1F ) /*0x141046d11*/
        _invalid_parameter_noinfo_noreturn(); /*0x141046d13*/
    }
    operator delete(ptr: v27); /*0x141046d1a*/
  }
  v78._Mypair._Myval2._Mysize = 0; /*0x141046d1f*/
  v78._Mypair._Myval2._Myres = 15; /*0x141046d24*/
  v78._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141046d2d*/
  if ( v81._Mypair._Myval2._Myres >= 0x10 ) /*0x141046d3e*/
  {
    v28 = v81._Mypair._Myval2._Bx._Ptr; /*0x141046d43*/
    if ( v81._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141046d55*/
    {
      v28 = *((char **)v81._Mypair._Myval2._Bx._Ptr - 1); /*0x141046d5b*/
      if ( (unsigned __int64)(v81._Mypair._Myval2._Bx._Ptr - v28 - 8) > 0x1F ) /*0x141046d6a*/
        _invalid_parameter_noinfo_noreturn(); /*0x141046d6c*/
    }
    operator delete(ptr: v28); /*0x141046d73*/
  }
  v29 = category->_Mypair._Myval2._Mysize; /*0x141046d78*/
  if ( v29 == 0x7FFFFFFFFFFFFFFFLL ) /*0x141046d86*/
    std::_Xlen_string(); /*0x14104772b*/
  v30 = category; /*0x141046d8c*/
  if ( category->_Mypair._Myval2._Myres >= 0x10 ) /*0x141046d94*/
    v30 = (const std::string *)category->_Mypair._Myval2._Bx._Ptr; /*0x141046d96*/
  if ( __eh34_unwind(4) ) /*0xf1c00000000001ac*/
  {
unwind_state_4:
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&ptr); /*0xf1c000000000017c*/
    __eh34_continue_unwinding(4, 3); /*0xf1c0000000000180*/
  }
  __eh34_exit_wind_state(4, 3); /*0xf1c00000000001b0*/
  if ( __eh34_unwind(3) ) /*0xf1c00000000001b4*/
  {
unwind_state_3:
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v78); /*0xf1c000000000018c*/
    __eh34_continue_unwinding(3, 2); /*0xf1c0000000000190*/
  }
  __eh34_exit_wind_state(3, 2); /*0xf1c00000000001b8*/
  if ( __eh34_unwind(2) ) /*0xf1c00000000001bc*/
  {
unwind_state_2:
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v81); /*0xf1c000000000019c*/
    __eh34_continue_unwinding(2, 1); /*0xf1c00000000001a0*/
  }
  __eh34_exit_wind_state(2, 1); /*0xf1c00000000001c0*/
  std::string::string( /*0x141046dbf*/
    this: &v81,
    __formal: (std::_String_constructor_concat_tag)this,
    _Source_of_al: category,
    _Left_ptr: v30->_Mypair._Myval2._Bx._Buf,
    _Left_size: v29,
    _Right_ptr: "_",
    _Right_size: 1u);
  v31 = result; /*0x141046dc5*/
  if ( result->_Mypair._Myval2._Myres >= 0x10 ) /*0x141046dcd*/
    v31 = (const std::string *)result->_Mypair._Myval2._Bx._Ptr; /*0x141046dcf*/
  __eh34_enter_wind_state(1, 2); /*0xf1c00000000000d4*/
  v32 = std::string::append(this: &v81, _Ptr: v31->_Mypair._Myval2._Bx._Buf, _Count: result->_Mypair._Myval2._Mysize); /*0x141046dde*/
  __eh34_enter_wind_state(2, 3); /*0xf1c00000000000cc*/
  v78._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141046de3*/
  v78._Mypair._Myval2._Mysize = 0; /*0x141046de8*/
  v78._Mypair._Myval2._Myres = 0; /*0x141046ded*/
  v78 = *v32; /*0x141046df5*/
  v32->_Mypair._Myval2._Mysize = 0; /*0x141046e03*/
  v32->_Mypair._Myval2._Myres = 15; /*0x141046e07*/
  v32->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141046e0f*/
  v33 = v78._Mypair._Myval2._Mysize; /*0x141046e12*/
  if ( v78._Mypair._Myval2._Myres - v78._Mypair._Myval2._Mysize < 0xE ) /*0x141046e26*/
  {
    v36 = std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x141046e7f*/
            this: &v78,
            _Size_increase: 0xEu,
            _Fn: 0,
            <_Args_0>: "_BytesReceived",
            <_Args_1>: 0xEu);
  }
  else
  {
    v78._Mypair._Myval2._Mysize += 14LL; /*0x141046e2c*/
    v34 = &v78; /*0x141046e31*/
    if ( v78._Mypair._Myval2._Myres >= 0x10 ) /*0x141046e3a*/
      v34 = (std::string *)v78._Mypair._Myval2._Bx._Ptr; /*0x141046e3a*/
    v35 = &v34->_Mypair._Myval2._Bx._Buf[v33]; /*0x141046e40*/
    memmove_0(a1: v35, Src: "_BytesReceived", Size: 0xEu); /*0x141046e53*/
    v35[14] = 0; /*0x141046e58*/
    v36 = &v78; /*0x141046e5c*/
  }
  __eh34_enter_wind_state(3, 4); /*0xf1c00000000000c4*/
  ptr._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141046e84*/
  *(_OWORD *)&ptr._Mypair._Myval2._Mysize = 0u; /*0x141046e89*/
  ptr = *v36; /*0x141046e96*/
  v36->_Mypair._Myval2._Mysize = 0; /*0x141046ea4*/
  v36->_Mypair._Myval2._Myres = 15; /*0x141046ea8*/
  v36->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141046eb0*/
  v37 = v9; /*0x141046eb6*/
  RBX::Analytics::EphemeralCounter::reportStats(category: &ptr, value: v37, blocking: false); /*0x141046ec6*/
  if ( ptr._Mypair._Myval2._Myres >= 0x10 ) /*0x141046ed5*/
  {
    v38 = ptr._Mypair._Myval2._Bx._Ptr; /*0x141046eda*/
    if ( ptr._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141046ee9*/
    {
      v38 = *((char **)ptr._Mypair._Myval2._Bx._Ptr - 1); /*0x141046eef*/
      if ( (unsigned __int64)(ptr._Mypair._Myval2._Bx._Ptr - v38 - 8) > 0x1F ) /*0x141046efe*/
        _invalid_parameter_noinfo_noreturn(); /*0x141046f00*/
    }
    operator delete(ptr: v38); /*0x141046f07*/
  }
  ptr._Mypair._Myval2._Mysize = 0; /*0x141046f0c*/
  ptr._Mypair._Myval2._Myres = 15; /*0x141046f11*/
  ptr._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141046f1a*/
  if ( v78._Mypair._Myval2._Myres >= 0x10 ) /*0x141046f28*/
  {
    v39 = v78._Mypair._Myval2._Bx._Ptr; /*0x141046f2d*/
    if ( v78._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141046f3c*/
    {
      v39 = *((char **)v78._Mypair._Myval2._Bx._Ptr - 1); /*0x141046f42*/
      if ( (unsigned __int64)(v78._Mypair._Myval2._Bx._Ptr - v39 - 8) > 0x1F ) /*0x141046f51*/
        _invalid_parameter_noinfo_noreturn(); /*0x141046f53*/
    }
    operator delete(ptr: v39); /*0x141046f5a*/
  }
  v78._Mypair._Myval2._Mysize = 0; /*0x141046f5f*/
  v78._Mypair._Myval2._Myres = 15; /*0x141046f64*/
  v78._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141046f6d*/
  if ( v81._Mypair._Myval2._Myres >= 0x10 ) /*0x141046f7e*/
  {
    v40 = v81._Mypair._Myval2._Bx._Ptr; /*0x141046f83*/
    if ( v81._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141046f95*/
    {
      v40 = *((char **)v81._Mypair._Myval2._Bx._Ptr - 1); /*0x141046f9b*/
      if ( (unsigned __int64)(v81._Mypair._Myval2._Bx._Ptr - v40 - 8) > 0x1F ) /*0x141046faa*/
        _invalid_parameter_noinfo_noreturn(); /*0x141046fac*/
    }
    operator delete(ptr: v40); /*0x141046fb3*/
  }
  if ( __eh34_unwind(4) ) /*0xf1c0000000000178*/
    goto unwind_state_4; /*0xf1c0000000000178*/
  __eh34_exit_wind_state(4, 3); /*0xf1c0000000000184*/
  if ( __eh34_unwind(3) ) /*0xf1c0000000000188*/
    goto unwind_state_3; /*0xf1c0000000000188*/
  __eh34_exit_wind_state(3, 2); /*0xf1c0000000000194*/
  if ( __eh34_unwind(2) ) /*0xf1c0000000000198*/
    goto unwind_state_2; /*0xf1c0000000000198*/
  __eh34_exit_wind_state(2, 1); /*0xf1c00000000001a4*/
  if ( DFInt::JoinInfluxHundredthsPercentage > 0 ) /*0x141046fbf*/
  {
    RBX::Analytics::InfluxDb::Points::Points( /*0x141046fd7*/
      this: &durationAnalyticsPoint,
      throttleHundredthsPercentage: -1,
      categoryType: kStandardType,
      priorityHundredthsPercentage: 0);
    v41 = category; /*0x141046fdd*/
    if ( category->_Mypair._Myval2._Myres >= 0x10 ) /*0x141046fe5*/
      v41 = (const std::string *)category->_Mypair._Myval2._Bx._Ptr; /*0x141046fe7*/
    __wind /*0xf1c00000000000ac*/
    {
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x141046ff9*/
        this: &durationAnalyticsPoint,
        name: "Category",
        value: v41->_Mypair._Myval2._Bx._Buf);
      v42 = result; /*0x141046ffe*/
      if ( result->_Mypair._Myval2._Myres >= 0x10 ) /*0x141047006*/
        v42 = (const std::string *)result->_Mypair._Myval2._Bx._Ptr; /*0x141047008*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14104701a*/
        this: &durationAnalyticsPoint,
        name: "Result",
        value: v42->_Mypair._Myval2._Bx._Buf);
      RBX::Analytics::InfluxDb::Points::addPoint(this: &durationAnalyticsPoint, name: "Duration", value: duration); /*0x141047031*/
      ptr._Mypair._Myval2._Myres = 15; /*0x141047036*/
      ptr._Mypair._Myval2._Mysize = 12; /*0x14104703f*/
      strcpy(ptr._Mypair._Myval2._Bx._Buf, "GameDuration"); /*0x141047050*/
      __wind /*0xf1c00000000000a0*/
      {
        RBX::Analytics::InfluxDb::Points::report( /*0x14104707c*/
          this: &durationAnalyticsPoint,
          resource: &ptr,
          throttleHundredthsPercentage: DFInt::JoinInfluxHundredthsPercentage,
          blocking: false);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&ptr); /*0xf1c0000000000098*/
      }
      if ( ptr._Mypair._Myval2._Myres >= 0x10 ) /*0x14104708b*/
      {
        v43 = ptr._Mypair._Myval2._Bx._Ptr; /*0x141047090*/
        if ( ptr._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104709f*/
        {
          v43 = *((char **)ptr._Mypair._Myval2._Bx._Ptr - 1); /*0x1410470a5*/
          if ( (unsigned __int64)(ptr._Mypair._Myval2._Bx._Ptr - v43 - 8) > 0x1F ) /*0x1410470b4*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410470b6*/
        }
        operator delete(ptr: v43); /*0x1410470bd*/
      }
      if ( durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Myres >= 0x10 ) /*0x1410470cf*/
      {
        v44 = durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Bx._Ptr; /*0x1410470d4*/
        if ( durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410470e6*/
        {
          v44 = *((char **)durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Bx._Ptr - 1); /*0x1410470ec*/
          if ( (unsigned __int64)(durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Bx._Ptr - v44 - 8) > 0x1F ) /*0x1410470fb*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410470fd*/
        }
        operator delete(ptr: v44); /*0x141047104*/
      }
      *(__m128i *)&durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x141047111*/
      durationAnalyticsPoint.userIdOverride._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104711a*/
      std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&durationAnalyticsPoint); /*0x14104712a*/
    }
    __unwind
    {
      RBX::Analytics::InfluxDb::Points::~Points(this: &durationAnalyticsPoint); /*0xf1c00000000000bc*/
    }
  }
  __wind /*0xf1c0000000000074*/
  {
    ptr._Mypair._Myval2._Myres = 15; /*0x14104712f*/
    ptr._Mypair._Myval2._Mysize = 12; /*0x141047138*/
    strcpy(ptr._Mypair._Myval2._Bx._Buf, "DataCenterId"); /*0x141047149*/
    ParamInt = RBX::GameConfigurer::getParamInt(this: v7, key: &ptr); /*0x141047166*/
    RBX::format(result: &dataCenterId, fmt: "%d", ParamInt); /*0x14104717d*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&ptr); /*0xf1c0000000000084*/
  }
  __eh34_enter_wind_state(1, 9); /*0xf1c000000000008c*/
  if ( ptr._Mypair._Myval2._Myres >= 0x10 ) /*0x14104718c*/
  {
    v46 = ptr._Mypair._Myval2._Bx._Ptr; /*0x141047191*/
    if ( ptr._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410471a0*/
    {
      v46 = *((char **)ptr._Mypair._Myval2._Bx._Ptr - 1); /*0x1410471a6*/
      if ( (unsigned __int64)(ptr._Mypair._Myval2._Bx._Ptr - v46 - 8) > 0x1F ) /*0x1410471b5*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410471b7*/
    }
    operator delete(ptr: v46); /*0x1410471be*/
  }
  ptr._Mypair._Myval2._Mysize = 0; /*0x1410471c3*/
  ptr._Mypair._Myval2._Myres = 15; /*0x1410471c8*/
  ptr._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410471d1*/
  v47 = category; /*0x1410471d6*/
  if ( category->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410471de*/
    v47 = (const std::string *)category->_Mypair._Myval2._Bx._Ptr; /*0x1410471e0*/
  if ( category->_Mypair._Myval2._Mysize != 12 || memcmp_0(Buf1: v47, Buf2: "GameDuration", Size: 0xCu) != 0 ) /*0x141047202*/
    goto LABEL_120; /*0x141047202*/
  v48 = result; /*0x141047208*/
  if ( result->_Mypair._Myval2._Myres >= 0x10 ) /*0x141047210*/
    v48 = (const std::string *)result->_Mypair._Myval2._Bx._Ptr; /*0x141047212*/
  if ( result->_Mypair._Myval2._Mysize != 4 ) /*0x14104721a*/
    goto LABEL_120; /*0x14104721a*/
  v49 = 0; /*0x141047220*/
  while ( 1 ) /*0x141047230*/
  {
    v50 = v48->_Mypair._Myval2._Bx._Buf[v49++]; /*0x141047230*/
    if ( v50 != aKick[v49 - 1] ) /*0x14104723c*/
      break; /*0x14104723c*/
    if ( v49 == 4 ) /*0x141047242*/
    {
      v51 = 0; /*0x141047244*/
      goto LABEL_95; /*0x141047247*/
    }
  }
  v51 = v50 < (unsigned __int8)aKick[v49 - 1] ? -1 : 1;
LABEL_95:
  if ( v51 != 0 ) /*0x141047250*/
  {
LABEL_120:
    v60 = category->_Mypair._Myval2._Mysize; /*0x1410473d9*/
    v61 = category; /*0x1410473dd*/
    Myres = category->_Mypair._Myval2._Myres; /*0x1410473e0*/
    if ( Myres >= 0x10 ) /*0x1410473e8*/
      v61 = (const std::string *)category->_Mypair._Myval2._Bx._Ptr; /*0x1410473ea*/
    if ( v60 == 8 && memcmp_0(Buf1: v61, Buf2: "GameJoin", Size: 8u) == 0 ) /*0x141047404*/
      goto LABEL_128; /*0x141047404*/
    v63 = category; /*0x141047406*/
    if ( Myres >= 0x10 ) /*0x14104740d*/
      v63 = (const std::string *)category->_Mypair._Myval2._Bx._Ptr; /*0x14104740f*/
    if ( v60 == 8 && memcmp_0(Buf1: v63, Buf2: "GameLoad", Size: 8u) == 0 ) /*0x14104742d*/
    {
LABEL_128:
      v64 = result->_Mypair._Myval2._Mysize; /*0x141047433*/
      if ( result->_Mypair._Myval2._Myres >= 0x10 ) /*0x14104743c*/
        result = (const std::string *)result->_Mypair._Myval2._Bx._Ptr; /*0x14104743e*/
      if ( v64 == 7 && memcmp_0(Buf1: result, Buf2: aSucc_0, Size: 7u) == 0 ) /*0x14104745f*/
      {
        v65 = category; /*0x141047475*/
        if ( Myres >= 0x10 ) /*0x14104747c*/
          v65 = (const std::string *)category->_Mypair._Myval2._Bx._Ptr; /*0x14104747e*/
        std::string::string( /*0x1410474ae*/
          this: &v81,
          __formal: (std::_String_constructor_concat_tag)this,
          _Source_of_al: category,
          _Left_ptr: v65->_Mypair._Myval2._Bx._Buf,
          _Left_size: 8u,
          _Right_ptr: "ByDatacenter_",
          _Right_size: 0xDu);
        p_dataCenterId = &dataCenterId; /*0x1410474b4*/
        if ( dataCenterId._Mypair._Myval2._Myres >= 0x10 ) /*0x1410474c5*/
          p_dataCenterId = (std::string *)dataCenterId._Mypair._Myval2._Bx._Ptr; /*0x1410474c5*/
        __wind /*0xf1c000000000004c*/
        {
          v67 = std::string::append( /*0x1410474de*/
                  this: &v81,
                  _Ptr: p_dataCenterId->_Mypair._Myval2._Bx._Buf,
                  _Count: dataCenterId._Mypair._Myval2._Mysize);
          __wind /*0xf1c0000000000028*/
          {
            v78._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410474e3*/
            v78._Mypair._Myval2._Mysize = 0; /*0x1410474e8*/
            v78._Mypair._Myval2._Myres = 0; /*0x1410474ed*/
            v78 = *v67; /*0x1410474f5*/
            v67->_Mypair._Myval2._Mysize = 0; /*0x141047503*/
            v67->_Mypair._Myval2._Myres = 15; /*0x141047507*/
            v67->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104750f*/
            RBX::Analytics::EphemeralCounter::reportStats(category: &v78, value: v25, blocking: false); /*0x14104751d*/
            if ( v78._Mypair._Myval2._Myres >= 0x10 ) /*0x14104752c*/
            {
              v68 = v78._Mypair._Myval2._Bx._Ptr; /*0x141047531*/
              if ( v78._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141047540*/
              {
                v68 = *((char **)v78._Mypair._Myval2._Bx._Ptr - 1); /*0x141047546*/
                if ( (unsigned __int64)(v78._Mypair._Myval2._Bx._Ptr - v68 - 8) > 0x1F ) /*0x141047555*/
                  _invalid_parameter_noinfo_noreturn(); /*0x141047557*/
              }
              operator delete(ptr: v68); /*0x14104755e*/
            }
            v78._Mypair._Myval2._Mysize = 0; /*0x141047563*/
            v78._Mypair._Myval2._Myres = 15; /*0x141047568*/
            v78._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141047571*/
            if ( v81._Mypair._Myval2._Myres >= 0x10 ) /*0x141047582*/
            {
              v69 = v81._Mypair._Myval2._Bx._Ptr; /*0x141047587*/
              if ( v81._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141047599*/
              {
                v69 = *((char **)v81._Mypair._Myval2._Bx._Ptr - 1); /*0x14104759f*/
                if ( (unsigned __int64)(v81._Mypair._Myval2._Bx._Ptr - v69 - 8) > 0x1F ) /*0x1410475ae*/
                  _invalid_parameter_noinfo_noreturn(); /*0x1410475b0*/
              }
              operator delete(ptr: v69); /*0x1410475b7*/
            }
            v70 = category->_Mypair._Myval2._Mysize; /*0x1410475bc*/
            if ( 0x7FFFFFFFFFFFFFFFLL - v70 < 0xD ) /*0x1410475c7*/
              std::_Xlen_string(); /*0x141047740*/
            v71 = category; /*0x1410475cd*/
            if ( category->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410475d5*/
              v71 = (const std::string *)category->_Mypair._Myval2._Bx._Ptr; /*0x1410475d7*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v78); /*0xf1c0000000000038*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v81); /*0xf1c0000000000044*/
        }
        std::string::string( /*0x141047604*/
          this: &v78,
          __formal: (std::_String_constructor_concat_tag)this,
          _Source_of_al: category,
          _Left_ptr: v71->_Mypair._Myval2._Bx._Buf,
          _Left_size: v70,
          _Right_ptr: "BytesReceived",
          _Right_size: 0xDu);
        v72 = &v78; /*0x14104760a*/
        if ( v78._Mypair._Myval2._Myres >= 0x10 ) /*0x141047615*/
          v72 = (std::string *)v78._Mypair._Myval2._Bx._Ptr; /*0x141047615*/
        __eh34_enter_wind_state(9, 10); /*0xf1c0000000000020*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x141047626*/
          this: &v7->analyticsPoints,
          name: v72->_Mypair._Myval2._Bx._Buf,
          value: v9);
        if ( v78._Mypair._Myval2._Myres >= 0x10 ) /*0x141047635*/
        {
          v73 = v78._Mypair._Myval2._Bx._Ptr; /*0x14104763a*/
          if ( v78._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141047649*/
          {
            v73 = *((char **)v78._Mypair._Myval2._Bx._Ptr - 1); /*0x14104764f*/
            if ( (unsigned __int64)(v78._Mypair._Myval2._Bx._Ptr - v73 - 8) > 0x1F ) /*0x14104765e*/
              _invalid_parameter_noinfo_noreturn(); /*0x141047660*/
          }
          operator delete(ptr: v73); /*0x141047667*/
        }
        v74 = category->_Mypair._Myval2._Mysize; /*0x14104766c*/
        v75 = category; /*0x141047670*/
        v76 = category->_Mypair._Myval2._Myres; /*0x141047673*/
        if ( v76 >= 0x10 ) /*0x14104767b*/
          v75 = (const std::string *)category->_Mypair._Myval2._Bx._Ptr; /*0x14104767d*/
        if ( v74 == 8 && memcmp_0(Buf1: v75, Buf2: "GameLoad", Size: 8u) == 0 ) /*0x141047697*/
        {
          v7->sgs.gameLoadBytesReceived = v9; /*0x141047699*/
        }
        else
        {
          if ( v76 >= 0x10 ) /*0x1410476a8*/
            category = (const std::string *)category->_Mypair._Myval2._Bx._Ptr; /*0x1410476aa*/
          if ( v74 == 8 && memcmp_0(Buf1: category, Buf2: "GameJoin", Size: 8u) == 0 ) /*0x1410476c7*/
            v7->sgs.gameJoinBytesReceived = v9; /*0x1410476c9*/
        }
        if ( __eh34_unwind(10) ) /*0xf1c0000000000140*/
          goto unwind_state_10; /*0xf1c0000000000140*/
        __eh34_exit_wind_state(10, 9); /*0xf1c0000000000144*/
      }
    }
    if ( __eh34_unwind(9) ) /*0xf1c0000000000118*/
      goto unwind_state_9; /*0xf1c0000000000118*/
    __eh34_exit_wind_state(9, 1); /*0xf1c0000000000124*/
    if ( __eh34_catch(1) ) /*0xf1c0000000000128*/
      goto catch_state_1; /*0xf1c0000000000128*/
    goto LABEL_212; /*0xf1c0000000000128*/
  }
  v52 = dataCenterId._Mypair._Myval2._Mysize; /*0x141047256*/
  if ( 0x7FFFFFFFFFFFFFFFLL - dataCenterId._Mypair._Myval2._Mysize < 0x11 ) /*0x141047268*/
    std::_Xlen_string(); /*0x141047731*/
  v53 = &dataCenterId; /*0x14104726e*/
  if ( dataCenterId._Mypair._Myval2._Myres >= 0x10 ) /*0x14104727f*/
    v53 = (std::string *)dataCenterId._Mypair._Myval2._Bx._Ptr; /*0x14104727f*/
  v85 = v53; /*0x141047288*/
  v78._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141047290*/
  v78._Mypair._Myval2._Mysize = 0; /*0x141047295*/
  v78._Mypair._Myval2._Myres = 0; /*0x14104729a*/
  v54 = dataCenterId._Mypair._Myval2._Mysize + 17; /*0x14104729f*/
  v55 = 15; /*0x1410472a3*/
  v56 = (char *)&v78; /*0x1410472a8*/
  if ( dataCenterId._Mypair._Myval2._Mysize + 17 <= 0xF ) /*0x1410472b0*/
  {
LABEL_113:
    v78._Mypair._Myval2._Mysize = v52 + 17; /*0x141047347*/
    v78._Mypair._Myval2._Myres = v55; /*0x14104734c*/
    qmemcpy(v56, "KickByDatacenter_", 17); /*0x141047358*/
    memcpy_0(a1: v56 + 17, Src: v53, Size: v52); /*0x14104736c*/
    __eh34_enter_wind_state(9, 10); /*0xf1c000000000006c*/
    v56[v54] = 0; /*0x141047371*/
    RBX::Analytics::EphemeralCounter::reportStats(category: &v78, value: v25, blocking: false); /*0x141047381*/
    if ( __eh34_unwind(10) ) /*0xf1c0000000000058*/
    {
unwind_state_10:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v78); /*0xf1c000000000005c*/
      __eh34_continue_unwinding(10, 9); /*0xf1c0000000000060*/
    }
    __eh34_exit_wind_state(10, 9); /*0xf1c0000000000064*/
    if ( v78._Mypair._Myval2._Myres >= 0x10 ) /*0x141047390*/
    {
      v59 = v78._Mypair._Myval2._Bx._Ptr; /*0x141047395*/
      if ( v78._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410473a4*/
      {
        v59 = *((char **)v78._Mypair._Myval2._Bx._Ptr - 1); /*0x1410473aa*/
        if ( (unsigned __int64)(v78._Mypair._Myval2._Bx._Ptr - v59 - 8) > 0x1F ) /*0x1410473b9*/
LABEL_117:
          _invalid_parameter_noinfo_noreturn(); /*0x1410473bb*/
      }
      operator delete(ptr: v59); /*0x1410473c2*/
    }
    v7 = this; /*0x1410473c7*/
    goto LABEL_120; /*0x1410473c7*/
  }
  v55 = v54 | 0xF; /*0x1410472b9*/
  if ( (v54 | 0xF) <= 0x7FFFFFFFFFFFFFFFLL )
  {
    if ( v55 < 0x16 ) /*0x141047308*/
      v55 = 22; /*0x141047308*/
    if ( v55 + 1 < 0x1000 ) /*0x141047317*/
    {
      if ( v55 == -1 ) /*0x14104732b*/
      {
        v56 = nullptr; /*0x14104733f*/
      }
      else
      {
        v56 = (char *)operator new(size: v55 + 1); /*0x141047332*/
        v53 = v85; /*0x141047335*/
      }
LABEL_112:
      v78._Mypair._Myval2._Bx._Ptr = v56; /*0x141047342*/
      goto LABEL_113; /*0x141047342*/
    }
    v57 = v55 + 40; /*0x141047319*/
    if ( v55 + 40 < v55 + 1 ) /*0x141047320*/
      std::_Throw_bad_array_new_length(); /*0x141047736*/
    if ( __eh34_unwind(9) ) /*0xf1c000000000014c*/
    {
unwind_state_9:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&dataCenterId); /*0xf1c000000000011c*/
      __eh34_continue_unwinding(9, 1); /*0xf1c0000000000120*/
    }
    __eh34_exit_wind_state(9, 1); /*0xf1c0000000000150*/
    if ( __eh34_catch(1) )
    {
catch_state_1:
      if ( __eh34_catch_type(1, &std::exception `RTTI Type Descriptor', &e) )
      {
        v77 = e->what(this: e); /*0x1431e80d7*/
        RBX::StandardOut::printf(type: MESSAGE_INFO, format: "reportDuration failed: %s", v77);
        return; /*0xf1c000000000001c*/
      }
LABEL_212:
      __eh34_exit_try_state(1, -1); /*0xf1c0000000000138*/
      if ( dataCenterId._Mypair._Myval2._Myres >= 0x10 ) /*0x1410476de*/
        std::allocator<RBX::Voxel2::Mesher::Quad>::deallocate( /*0x1410476f3*/
          this: (std::allocator<signed char> *)&dataCenterId,
          _Ptr: dataCenterId._Mypair._Myval2._Bx._Ptr,
          _Count: dataCenterId._Mypair._Myval2._Myres + 1);
      return; /*0x1410476f9*/
    }
    __eh34_exit_try_state(1, -1); /*0xf1c0000000000158*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000015c*/
    if ( __eh34_unwind(0) ) /*0xf1c0000000000164*/
      goto unwind_state_0; /*0xf1c0000000000164*/
    __eh34_exit_wind_state(0, -1); /*0xf1c0000000000168*/
    __eh34_enter_try_state(-1, 1); /*0xf1c000000000016c*/
    __eh34_enter_wind_state(1, 9); /*0xf1c0000000000170*/
  }
  else
  {
    v55 = 0x7FFFFFFFFFFFFFFFLL; /*0x1410472cc*/
    v57 = 0x8000000000000027uLL; /*0x1410472cf*/
  }
  v58 = operator new(size: v57); /*0x1410472dc*/
  if ( v58 == nullptr ) /*0x1410472e4*/
    goto LABEL_117; /*0x1410472e4*/
  v56 = (char *)(((unsigned __int64)v58 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x1410472ee*/
  *((_QWORD *)v56 - 1) = v58; /*0x1410472f2*/
  v53 = v85; /*0x1410472f6*/
  goto LABEL_112; /*0x1410472fe*/
}

// Address: 0x141047750 | Name: ?reportError@PlayerConfigurer@RBX@@AEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@0@Z
void __fastcall RBX::PlayerConfigurer::reportError(
        RBX::PlayerConfigurer *this,
        const std::string *error,
        const rtc::webrtc_checks_impl::ToStringVal *msg)
{
  const std::string *v4; // rsi
  const std::string *p_val; // r9
  const std::string *Ptr; // r8
  RBX::Visit *v8; // rax
  RBX::Network::Client *v9; // rax
  RBX::Network::Client *v10; // r13
  const char *LoadStateSuffix; // rax
  unsigned __int64 v12; // rdi
  unsigned __int64 Mysize; // rcx
  char *v14; // rbx
  std::string *p_serverAddress; // r9
  std::string *p_metric; // rdx
  RBX::TimerService *v17; // r13
  std::_Ref_count_base *Rep; // rdi
  _QWORD *v19; // rax
  std::_Func_base<void> *v20; // rbx
  rtc::webrtc_checks_impl::ToStringVal *v21; // rax
  std::string *v22; // rbx
  rtc::webrtc_checks_impl::ToStringVal *v23; // rax
  boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::PlayerConfigurer,std::string const &,std::string const &,std::string const &,int>,boost::_bi::list5<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string >,boost::_bi::value<std::string >,boost::_bi::value<char const *>,boost::_bi::value<int> > > *v24; // rax
  boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::PlayerConfigurer,std::string const &,std::string const &,std::string const &,int>,boost::_bi::list5<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string >,boost::_bi::value<std::string >,boost::_bi::value<char const *>,boost::_bi::value<int> > > *v25; // rbx
  char *v26; // rax
  char *v27; // rcx
  char *v28; // rcx
  char *v29; // rcx
  std::weak_ptr<RBX::PlayerConfigurer> weakThis; // [rsp+40h] [rbp-C0h] BYREF
  std::string metric; // [rsp+50h] [rbp-B0h] BYREF
  std::string serverAddress; // [rsp+70h] [rbp-90h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v33; // [rsp+90h] [rbp-70h] BYREF
  std::weak_ptr<RBX::PlayerConfigurer> v34; // [rsp+B0h] [rbp-50h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v35; // [rsp+C0h] [rbp-40h] BYREF
  rtc::webrtc_checks_impl::ToStringVal __that; // [rsp+E0h] [rbp-20h] BYREF
  std::string errorMsg; // [rsp+100h] [rbp+0h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v38; // [rsp+120h] [rbp+20h] BYREF
  std::function<void __cdecl(void)> v39; // [rsp+140h] [rbp+40h] BYREF
  std::function<void __cdecl(void)> v40; // [rsp+180h] [rbp+80h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::PlayerConfigurer,std::string const &,std::string const &,std::string const &,int>,boost::_bi::list5<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string >,boost::_bi::value<std::string >,boost::_bi::value<char const *>,boost::_bi::value<int> > > v41; // [rsp+1C0h] [rbp+C0h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf3<void,ScriptRecoveryWidget,std::string const &,std::string const &,std::string const &>,boost::_bi::list4<boost::_bi::value<ScriptRecoveryWidget *>,boost::_bi::value<std::string >,boost::arg<1>,boost::_bi::value<std::string > > > *v42; // [rsp+288h] [rbp+188h]
  std::_Global_new::__l2::_Guard_type v43; // [rsp+290h] [rbp+190h] BYREF
  std::weak_ptr<PluginPermissionsFetcher> *v44; // [rsp+298h] [rbp+198h]

  v4 = error; /*0x14104776f*/
  p_val = &msg->val; /*0x141047775*/
  if ( msg->val._Mypair._Myval2._Myres >= 0x10 ) /*0x14104777d*/
    p_val = (const std::string *)msg->val._Mypair._Myval2._Bx._Ptr; /*0x14104777f*/
  Ptr = error; /*0x141047782*/
  if ( error->_Mypair._Myval2._Myres >= 0x10 ) /*0x14104778a*/
    Ptr = (const std::string *)error->_Mypair._Myval2._Bx._Ptr; /*0x14104778c*/
  RBX::StandardOut::printf( /*0x14104779b*/
    type: MESSAGE_INFO,
    format: "***ERROR*** %s %s",
    Ptr->_Mypair._Myval2._Bx._Buf,
    p_val->_Mypair._Myval2._Bx._Buf);
  if ( !this->testing ) /*0x1410477a6*/
  {
    v8 = RBX::ServiceProvider::create<RBX::Visit>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x1410477b0*/
    v33.val._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410477b5*/
    v33.val._Mypair._Myval2._Myres = 15; /*0x1410477b9*/
    v33.val._Mypair._Myval2._Mysize = 0; /*0x1410477c1*/
    RBX::Visit::setUploadUrl(this: v8, value: &v33.val); /*0x1410477cc*/
  }
  v9 = RBX::ServiceProvider::create<RBX::Network::Client>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x1410477d9*/
  v10 = v9; /*0x1410477de*/
  metric._Mypair._Myval2._Myres = 15; /*0x1410477e1*/
  metric._Mypair._Myval2._Mysize = 9; /*0x1410477ea*/
  metric._Mypair._Myval2._Bx._Ptr = *(char **)"Exception"; /*0x1410477fb*/
  *(_WORD *)&metric._Mypair._Myval2._Bx._Alias[8] = (unsigned __int8)aException_2[8]; /*0x141047808*/
  __wind
  {
    RBX::Network::Client::getConnectedServer(this: v9, result: &serverAddress); /*0x141047818*/
    __wind
    {
      LoadStateSuffix = RBX::Network::Client::getLoadStateSuffix(this: v10); /*0x141047821*/
      v12 = -1; /*0x141047830*/
      do /*0x14104783a*/
        ++v12; /*0x141047833*/
      while ( LoadStateSuffix[v12] != 0 ); /*0x14104783a*/
      Mysize = metric._Mypair._Myval2._Mysize; /*0x14104783c*/
      if ( v12 > metric._Mypair._Myval2._Myres - metric._Mypair._Myval2._Mysize ) /*0x14104784f*/
      {
        std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x141047890*/
          this: &metric,
          _Size_increase: v12,
          _Fn: 0,
          <_Args_0>: LoadStateSuffix,
          <_Args_1>: v12);
      }
      else
      {
        metric._Mypair._Myval2._Mysize += v12; /*0x141047855*/
        v14 = &metric._Mypair._Myval2._Bx._Buf[Mysize]; /*0x141047869*/
        memmove_0(a1: &metric._Mypair._Myval2._Bx._Buf[Mysize], Src: LoadStateSuffix, Size: v12); /*0x141047875*/
        v14[v12] = 0; /*0x14104787a*/
      }
      p_serverAddress = &serverAddress; /*0x141047895*/
      if ( serverAddress._Mypair._Myval2._Myres >= 0x10 ) /*0x14104789f*/
        p_serverAddress = (std::string *)serverAddress._Mypair._Myval2._Bx._Ptr; /*0x14104789f*/
      p_metric = &metric; /*0x1410478a5*/
      if ( metric._Mypair._Myval2._Myres >= 0x10 ) /*0x1410478b0*/
        p_metric = (std::string *)metric._Mypair._Myval2._Bx._Ptr; /*0x1410478b0*/
      RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1410478c9*/
        this: v10,
        metric: p_metric->_Mypair._Myval2._Bx._Buf,
        connectionFailed: true,
        serverAddress: p_serverAddress->_Mypair._Myval2._Bx._Buf,
        state: ConnectionState_Failed,
        takeLock: true);
      RBX::Network::Client::disconnect(this: v10); /*0x1410478d1*/
      v17 = RBX::ServiceProvider::create<RBX::TimerService>(this: &this->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x1410478e3*/
      if ( v17 != nullptr )
      {
        if ( v4->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410478f4*/
          v4 = (const std::string *)v4->_Mypair._Myval2._Bx._Ptr; /*0x1410478f6*/
        RBX::format(result: &errorMsg, fmt: "Error: %s", v4->_Mypair._Myval2._Bx._Buf);
        __wind /*0xf1c00000000000a4*/
        {
          if ( FFlag::AppBridgeRewrite.value ) /*0x141047914*/
          {
            RBX::weak_from<RBX::Studio::DebuggerUIService>( /*0x141047922*/
              result: (std::weak_ptr<UserPluginsModel> *)&weakThis,
              r: (UserPluginsModel *)this);
            __wind /*0xf1c0000000000098*/
            {
              v34 = 0; /*0x141047941*/
              Rep = weakThis._Rep; /*0x141047946*/
              if ( weakThis._Rep != nullptr ) /*0x14104794e*/
              {
                v34 = weakThis; /*0x141047955*/
                _InterlockedIncrement((volatile signed __int32 *)&weakThis._Rep->_Weaks); /*0x14104795d*/
                Rep = weakThis._Rep; /*0x141047961*/
              }
              __wind /*0xf1c000000000008c*/
              {
                std::string::string(this: &v35, __that: (const rtc::webrtc_checks_impl::ToStringVal *)&errorMsg); /*0x14104796e*/
                __wind /*0xf1c000000000003c*/
                {
                  std::string::string(this: &__that, __that: msg); /*0x14104797b*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v35); /*0x1431e811b*/
                }
              }
              __unwind
              {
                std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)&v34); /*0xf1c0000000000058*/
              }
              __wind /*0xf1c0000000000060*/
              {
                __wind /*0xf1c0000000000068*/
                {
                  v39._Mystorage._Ptrs[7] = nullptr; /*0x14104798e*/
                  v19 = operator new(size: 0x58u); /*0x141047995*/
                  __wind /*0xf1c0000000000118*/
                  {
                    __wind /*0xf1c0000000000120*/
                    {
                      __wind /*0xf1c0000000000128*/
                      {
                        v20 = (std::_Func_base<void> *)v19; /*0x14104799a*/
                        v43._Result = v19; /*0x14104799d*/
                        *v19 = std::_Func_impl_no_alloc__lambda_876a11e0421f2df8485d15d0409da3d0__void_::_vftable_; /*0x1410479ab*/
                        v44 = (std::weak_ptr<PluginPermissionsFetcher> *)(v19 + 1); /*0x1410479b2*/
                        v19[1] = 0; /*0x1410479b9*/
                        v19[2] = 0; /*0x1410479bc*/
                        *(std::weak_ptr<RBX::PlayerConfigurer> *)(v19 + 1) = v34; /*0x1410479c4*/
                        v34 = 0; /*0x1410479d2*/
                        v19[3] = 0; /*0x1410479d7*/
                        v19[5] = 0; /*0x1410479db*/
                        v19[6] = 0; /*0x1410479df*/
                        *(rtc::webrtc_checks_impl::ToStringVal *)(v19 + 3) = v35; /*0x1410479e7*/
                        v35.val._Mypair._Myval2._Mysize = 0; /*0x1410479f3*/
                        v35.val._Mypair._Myval2._Myres = 15; /*0x1410479f7*/
                        v35.val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410479ff*/
                        std::string::string(this: (rtc::webrtc_checks_impl::ToStringVal *)(v19 + 7), &__that); /*0x141047a0b*/
                        v39._Mystorage._Ptrs[7] = v20; /*0x141047a11*/
                        lambda_1c05865434f5aab6b8b4eefa09f22da6_::__lambda_1c05865434f5aab6b8b4eefa09f22da6_(a1: &v34); /*0x141047a19*/
                      }
                      __unwind
                      {
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v44[1]); /*0x1431e815b*/
                      }
                    }
                    __unwind
                    {
                      std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: v44); /*0xf1c0000000000144*/
                    }
                  }
                  __unwind
                  {
                    `std::_Global_new<std::_Func_impl_no_alloc<_lambda_d9167347c78cd8555d2baf09be40565a_,void,>,_lambda_d9167347c78cd8555d2baf09be40565a_ const &>'::`2'::_Guard_type::~_Guard_type(this: &v43); /*0xf1c0000000000150*/
                  }
                }
                __unwind
                {
                  std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&v39); /*0xf1c0000000000078*/
                }
              }
              __unwind
              {
                lambda_1c05865434f5aab6b8b4eefa09f22da6_::__lambda_1c05865434f5aab6b8b4eefa09f22da6_(a1: &v34); /*0xf1c0000000000084*/
              }
              RBX::TimerService::delay(this: v17, func: &v39, seconds: 4.0); /*0x141047a2d*/
              if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141047a46*/
                weakThis._Rep->_Delete_this(this: weakThis._Rep); /*0x141047a54*/
            }
            __unwind
            {
              std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)&weakThis); /*0xf1c000000000001c*/
            }
          }
          else
          {
            v21 = std::string::string(this: &v33, __that: msg); /*0x141047a7c*/
            __wind /*0xf1c0000000000030*/
            {
              v22 = &v21->val; /*0x141047a81*/
              v23 = std::string::string(this: &v38, __that: (const rtc::webrtc_checks_impl::ToStringVal *)&errorMsg); /*0x141047a8c*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v33); /*0xf1c0000000000028*/
            }
            weakThis._Ptr = (RBX::PlayerConfigurer *)RBX::PlayerConfigurer::showErrorWindow; /*0x141047a98*/
            LODWORD(weakThis._Rep) = 0; /*0x141047a9f*/
            v24 = boost::bind<void,RBX::PlayerConfigurer,std::string const &,std::string const &,std::string const &,int,RBX::PlayerConfigurer *,std::string,std::string,char const *,int>( /*0x141047ad6*/
                    result: &v41,
                    f: (__int128 *)&weakThis,
                    a1: this,
                    a2: &v23->val,
                    a3: v22,
                    a4: "Other",
                    a5: -1);
            __wind /*0xf1c0000000000104*/
            {
              __wind /*0xf1c000000000010c*/
              {
                v25 = v24; /*0x141047adb*/
                v42 = (boost::_bi::bind_t<void,boost::_mfi::mf3<void,ScriptRecoveryWidget,std::string const &,std::string const &,std::string const &>,boost::_bi::list4<boost::_bi::value<ScriptRecoveryWidget *>,boost::_bi::value<std::string >,boost::arg<1>,boost::_bi::value<std::string > > > *)v24; /*0x141047ade*/
                v40._Mystorage._Ptrs[7] = nullptr; /*0x141047ae5*/
                v26 = (char *)operator new(size: 0x70u); /*0x141047aef*/
                *(_QWORD *)v26 = std::_Func_impl_no_alloc<boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::PlayerConfigurer,std::string const &,std::string const &,std::string const &,int>,boost::_bi::list5<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string>,boost::_bi::value<std::string>,boost::_bi::value<char const *>,boost::_bi::value<int>>>,void,>::`vftable'; /*0x141047afb*/
                *(_OWORD *)(v26 + 8) = v25->f_.f_; /*0x141047b01*/
                *((_QWORD *)v26 + 3) = v25->l_.a1_.t_; /*0x141047b09*/
                *((_QWORD *)v26 + 4) = 0; /*0x141047b0d*/
                *((_QWORD *)v26 + 6) = 0; /*0x141047b11*/
                *((_QWORD *)v26 + 7) = 0; /*0x141047b15*/
                *((_OWORD *)v26 + 2) = v25->l_.a2_.t_._Mypair._Myval2._Bx; /*0x141047b1d*/
                *((_OWORD *)v26 + 3) = *(_OWORD *)&v25->l_.a2_.t_._Mypair._Myval2._Mysize; /*0x141047b25*/
                v25->l_.a2_.t_._Mypair._Myval2._Mysize = 0; /*0x141047b29*/
                v25->l_.a2_.t_._Mypair._Myval2._Myres = 15; /*0x141047b2d*/
                v25->l_.a2_.t_._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141047b35*/
                *((_QWORD *)v26 + 8) = 0; /*0x141047b39*/
                *((_QWORD *)v26 + 10) = 0; /*0x141047b3d*/
                *((_QWORD *)v26 + 11) = 0; /*0x141047b41*/
                *((_OWORD *)v26 + 4) = v25->l_.a3_.t_._Mypair._Myval2._Bx; /*0x141047b49*/
                *((_OWORD *)v26 + 5) = *(_OWORD *)&v25->l_.a3_.t_._Mypair._Myval2._Mysize; /*0x141047b51*/
                v25->l_.a3_.t_._Mypair._Myval2._Mysize = 0; /*0x141047b55*/
                v25->l_.a3_.t_._Mypair._Myval2._Myres = 15; /*0x141047b59*/
                v25->l_.a3_.t_._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141047b61*/
                *((_QWORD *)v26 + 12) = v25->l_.a4_.t_; /*0x141047b69*/
                *((_DWORD *)v26 + 26) = v25->l_.a5_.t_; /*0x141047b70*/
                v40._Mystorage._Ptrs[7] = (std::_Func_base<void> *)v26; /*0x141047b73*/
                std::tuple<std::string,std::string,int>::~tuple<std::string,std::string,int>(this: (boost::_bi::storage4<boost::_bi::value<ScriptRecoveryWidget *>,boost::_bi::value<std::string >,boost::arg<1>,boost::_bi::value<std::string > > *)&v25->l_); /*0x141047b7e*/
              }
              __unwind
              {
                std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&v40); /*0xf1c00000000000f0*/
              }
            }
            __unwind
            {
              boost::_bi::bind_t<void,boost::_mfi::mf3<void,ScriptRecoveryWidget,std::string const &,std::string const &,std::string const &>,boost::_bi::list4<boost::_bi::value<ScriptRecoveryWidget *>,boost::_bi::value<std::string>,boost::arg<1>,boost::_bi::value<std::string>>>::~bind_t<void,boost::_mfi::mf3<void,ScriptRecoveryWidget,std::string const &,std::string const &,std::string const &>,boost::_bi::list4<boost::_bi::value<ScriptRecoveryWidget *>,boost::_bi::value<std::string>,boost::arg<1>,boost::_bi::value<std::string>>>(this: v42); /*0xf1c00000000000fc*/
            }
            RBX::TimerService::delay(this: v17, func: &v40, seconds: 4.0); /*0x141047b95*/
          }
          if ( errorMsg._Mypair._Myval2._Myres >= 0x10 ) /*0x141047ba3*/
          {
            v27 = errorMsg._Mypair._Myval2._Bx._Ptr; /*0x141047ba8*/
            if ( errorMsg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141047bb6*/
            {
              v27 = *((char **)errorMsg._Mypair._Myval2._Bx._Ptr - 1); /*0x141047bbc*/
              if ( (unsigned __int64)(errorMsg._Mypair._Myval2._Bx._Ptr - v27 - 8) > 0x1F ) /*0x141047bcb*/
                _invalid_parameter_noinfo_noreturn(); /*0x141047bcd*/
            }
            operator delete(ptr: v27); /*0x141047bd4*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&errorMsg); /*0xf1c00000000000b4*/
        }
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&serverAddress); /*0xf1c00000000000c0*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&metric); /*0xf1c00000000000cc*/
  }
  if ( serverAddress._Mypair._Myval2._Myres >= 0x10 ) /*0x141047be2*/
  {
    v28 = serverAddress._Mypair._Myval2._Bx._Ptr; /*0x141047be7*/
    if ( serverAddress._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141047bf6*/
    {
      v28 = *((char **)serverAddress._Mypair._Myval2._Bx._Ptr - 1); /*0x141047bfc*/
      if ( (unsigned __int64)(serverAddress._Mypair._Myval2._Bx._Ptr - v28 - 8) > 0x1F ) /*0x141047c0b*/
        _invalid_parameter_noinfo_noreturn(); /*0x141047c0d*/
    }
    operator delete(ptr: v28); /*0x141047c14*/
  }
  serverAddress._Mypair._Myval2._Mysize = 0; /*0x141047c19*/
  serverAddress._Mypair._Myval2._Myres = 15; /*0x141047c21*/
  serverAddress._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141047c29*/
  if ( metric._Mypair._Myval2._Myres >= 0x10 ) /*0x141047c37*/
  {
    v29 = metric._Mypair._Myval2._Bx._Ptr; /*0x141047c3c*/
    if ( metric._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141047c4b*/
    {
      v29 = *((char **)metric._Mypair._Myval2._Bx._Ptr - 1); /*0x141047c51*/
      if ( (unsigned __int64)(metric._Mypair._Myval2._Bx._Ptr - v29 - 8) > 0x1F ) /*0x141047c60*/
        _invalid_parameter_noinfo_noreturn(); /*0x141047c62*/
    }
    operator delete(ptr: v29); /*0x141047c69*/
  }
}

// Address: 0x141047fa0 | Name: ?reportLocalAvatarMetrics@PlayerConfigurer@RBX@@AEAAXAEAUAvatarMetrics@2@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@N@Z
void __fastcall RBX::PlayerConfigurer::reportLocalAvatarMetrics(
        RBX::PlayerConfigurer *this,
        RBX::AvatarMetrics *metrics,
        rtc::webrtc_checks_impl::ToStringVal *joinFailureError,
        long double timeOfFailure)
{
  rtc::webrtc_checks_impl::ToStringVal *v5; // r14
  RBX::Analytics::InfluxDb::Points *p_analyticsPoints; // rbx
  long double gameJoinTime; // xmm2_8
  double gameLoadTime; // xmm0_8
  double v11; // xmm0_8
  long double v12; // xmm2_8
  long double connectTime; // xmm2_8
  long double startGameTime; // xmm2_8
  long double fetchedJoinScriptTime; // xmm2_8
  long double placelauncherStartTime; // xmm2_8
  long double videoAdFinishedTime; // xmm2_8
  long double receivedGlobalsTime; // xmm2_8
  long double createTime; // xmm2_8
  long double completionTime; // xmm2_8
  long double clusterStartTime; // xmm2_8
  long double clusterEndTime; // xmm2_8
  double clusterUpdateCnt; // xmm2_8
  long double textureStartTime; // xmm2_8
  long double textureEndTime; // xmm2_8
  double httpCacheHitCnt; // xmm2_8
  double httpCacheMissCnt; // xmm2_8
  double httpCacheHitBytes; // xmm2_8
  double httpCacheMissBytes; // xmm2_8
  double assetsByteSize; // xmm2_8
  double texturesByteSize; // xmm2_8
  double animationsByteSize; // xmm2_8
  unsigned __int64 v33; // r15
  unsigned __int64 Ptr; // r13
  JoinPhase joinPhase; // ecx
  char *v36; // rdx
  unsigned __int64 v37; // r8
  std::string *v38; // rdx
  unsigned __int64 Mysize; // r8
  rtc::webrtc_checks_impl::ToStringVal *v40; // rdi
  unsigned __int64 Myres; // rdx
  char *v42; // rcx
  std::_String_val<std::_Simple_types<char> >::_Bxty *v43; // r12
  char *v44; // r14
  unsigned __int64 v45; // rdi
  void *v46; // rax
  void *v47; // rcx
  char *v48; // rax
  char *v49; // rcx
  rtc::webrtc_checks_impl::ToStringVal *v50; // rdi
  unsigned __int64 v51; // rdx
  char *v52; // rcx
  rtc::webrtc_checks_impl::ToStringVal *v53; // rdi
  unsigned __int64 v54; // rdx
  char *v55; // rcx
  long double v56; // xmm7_8
  char *v57; // rax
  void *v58; // rcx
  int v59; // edi
  unsigned __int64 v60; // r8
  void *v61; // rcx
  unsigned __int64 v62; // rdx
  char *v63; // rcx
  rtc::webrtc_checks_impl::ToStringVal v64; // [rsp+28h] [rbp-79h] BYREF
  _QWORD v65[2]; // [rsp+48h] [rbp-59h] BYREF
  unsigned __int64 v66; // [rsp+58h] [rbp-49h]
  std::string current; // [rsp+60h] [rbp-41h] BYREF
  unsigned __int64 v68; // [rsp+80h] [rbp-21h]
  rtc::webrtc_checks_impl::ToStringVal v69; // [rsp+88h] [rbp-19h] BYREF
  rtc::webrtc_checks_impl::ToStringVal *v70; // [rsp+108h] [rbp+67h]

  __wind /*0xf1c00000000000b8*/
  {
    v5 = joinFailureError; /*0x141047fcc*/
    p_analyticsPoints = &this->analyticsPoints; /*0x141047fd5*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141047fee*/
      this: &this->analyticsPoints,
      name: "PlayerConfigureTime",
      value: this->sgs.playerConfigureTime);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141048005*/
      this: p_analyticsPoints,
      name: "AvatarConfigureTime",
      value: this->sgs.avatarConfigureTime);
    RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "AvatarR15", value: (double)metrics->r15); /*0x141048020*/
    gameJoinTime = this->sgs.gameJoinTime; /*0x141048025*/
    if ( gameJoinTime > 0.0 ) /*0x141048034*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "GameJoinTime", value: gameJoinTime); /*0x141048040*/
    gameLoadTime = this->sgs.gameLoadTime; /*0x141048045*/
    if ( gameLoadTime > 0.0 ) /*0x141048051*/
    {
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x141048060*/
        this: p_analyticsPoints,
        name: "GameLoadTime",
        value: this->sgs.gameLoadTime);
      gameLoadTime = this->sgs.gameLoadTime; /*0x141048065*/
    }
    v11 = gameLoadTime - this->sgs.receivedGlobalsTime; /*0x14104806d*/
    if ( v11 > 0.0 ) /*0x141048079*/
    {
      v12 = (this->sgs.gameLoadBytesReceived - this->sgs.gameReceiveGlobalsBytesReceived) / v11; /*0x14104808b*/
      if ( v12 > 0.0 ) /*0x141048093*/
        RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "GameLoadBandwidth", value: v12); /*0x14104809f*/
    }
    connectTime = this->sgs.connectTime; /*0x1410480a4*/
    if ( connectTime > 0.0 ) /*0x1410480b0*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "ConnectTime", value: connectTime); /*0x1410480bc*/
    startGameTime = this->sgs.startGameTime; /*0x1410480c1*/
    if ( startGameTime > 0.0 ) /*0x1410480cd*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "StartGameTime", value: startGameTime); /*0x1410480d9*/
    fetchedJoinScriptTime = this->sgs.fetchedJoinScriptTime; /*0x1410480de*/
    if ( fetchedJoinScriptTime > 0.0 ) /*0x1410480ea*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410480f6*/
        this: p_analyticsPoints,
        name: "FetchedJoinScriptTime",
        value: fetchedJoinScriptTime);
    placelauncherStartTime = this->sgs.placelauncherStartTime; /*0x1410480fb*/
    if ( placelauncherStartTime > 0.0 ) /*0x141048107*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x141048113*/
        this: p_analyticsPoints,
        name: "PlaceLauncherStartTime",
        value: placelauncherStartTime);
    videoAdFinishedTime = this->sgs.videoAdFinishedTime; /*0x141048118*/
    if ( videoAdFinishedTime > 0.0 ) /*0x141048121*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14104812d*/
        this: p_analyticsPoints,
        name: "VideoAdFinishedTime",
        value: videoAdFinishedTime);
    receivedGlobalsTime = this->sgs.receivedGlobalsTime; /*0x141048132*/
    if ( receivedGlobalsTime > 0.0 ) /*0x14104813e*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14104814a*/
        this: p_analyticsPoints,
        name: "ReceivedGlobalsTime",
        value: receivedGlobalsTime);
    createTime = metrics->createTime; /*0x14104814f*/
    if ( createTime > 0.0 ) /*0x14104815b*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "AvatarCreateTime", value: createTime); /*0x141048167*/
    completionTime = metrics->completionTime; /*0x14104816c*/
    if ( completionTime > 0.0 ) /*0x141048178*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "AvatarLoadTime", value: completionTime); /*0x141048184*/
    clusterStartTime = metrics->clusterStartTime; /*0x141048189*/
    if ( clusterStartTime > 0.0 ) /*0x141048195*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410481a1*/
        this: p_analyticsPoints,
        name: "AvatarClusterStartTime",
        value: clusterStartTime);
    clusterEndTime = metrics->clusterEndTime; /*0x1410481a6*/
    if ( clusterEndTime > 0.0 ) /*0x1410481b2*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410481be*/
        this: p_analyticsPoints,
        name: "AvatarClusterEndTime",
        value: clusterEndTime);
    clusterUpdateCnt = (double)(int)metrics->clusterUpdateCnt; /*0x1410481c6*/
    if ( clusterUpdateCnt > 0.0 ) /*0x1410481d3*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410481df*/
        this: p_analyticsPoints,
        name: "AvatarClusterUpdateCnt",
        value: clusterUpdateCnt);
    textureStartTime = metrics->textureStartTime; /*0x1410481e4*/
    if ( textureStartTime > 0.0 ) /*0x1410481f0*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410481fc*/
        this: p_analyticsPoints,
        name: "AvatarTextureStartTime",
        value: textureStartTime);
    textureEndTime = metrics->textureEndTime; /*0x141048201*/
    if ( textureEndTime > 0.0 ) /*0x14104820d*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x141048219*/
        this: p_analyticsPoints,
        name: "AvatarTextureEndTime",
        value: textureEndTime);
    httpCacheHitCnt = (double)(int)metrics->httpCacheHitCnt; /*0x141048221*/
    if ( httpCacheHitCnt > 0.0 ) /*0x14104822e*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14104823a*/
        this: p_analyticsPoints,
        name: "AvatarHttpCacheHitCnt",
        value: httpCacheHitCnt);
    httpCacheMissCnt = (double)(int)metrics->httpCacheMissCnt; /*0x141048242*/
    if ( httpCacheMissCnt > 0.0 ) /*0x14104824f*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14104825b*/
        this: p_analyticsPoints,
        name: "AvatarHttpCacheMissCnt",
        value: httpCacheMissCnt);
    httpCacheHitBytes = (double)(int)metrics->httpCacheHitBytes; /*0x141048263*/
    if ( httpCacheHitBytes > 0.0 ) /*0x141048270*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14104827c*/
        this: p_analyticsPoints,
        name: "AvatarHttpCacheHitBytes",
        value: httpCacheHitBytes);
    httpCacheMissBytes = (double)(int)metrics->httpCacheMissBytes; /*0x141048284*/
    if ( httpCacheMissBytes > 0.0 ) /*0x141048291*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14104829d*/
        this: p_analyticsPoints,
        name: "AvatarHttpCacheMissBytes",
        value: httpCacheMissBytes);
    assetsByteSize = (double)(int)metrics->assetsByteSize; /*0x1410482a5*/
    if ( assetsByteSize > 0.0 ) /*0x1410482b2*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410482be*/
        this: p_analyticsPoints,
        name: "AvatarAssetsByteSize",
        value: assetsByteSize);
    texturesByteSize = (double)(int)metrics->texturesByteSize; /*0x1410482c6*/
    if ( texturesByteSize > 0.0 ) /*0x1410482d3*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410482df*/
        this: p_analyticsPoints,
        name: "AvatarTexturesByteSize",
        value: texturesByteSize);
    animationsByteSize = (double)(int)metrics->animationsByteSize; /*0x1410482e7*/
    if ( animationsByteSize > 0.0 ) /*0x1410482f4*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x141048300*/
        this: p_analyticsPoints,
        name: "AvatarAnimationsByteSize",
        value: animationsByteSize);
    __eh34_enter_wind_state(0, 1); /*0xf1c00000000000b0*/
    if ( !DFFlag::ReportFailuresInClientJoinAll2.value ) /*0x14104830f*/
      goto LABEL_114; /*0x14104830f*/
    current._Mypair._Myval2._Myres = 0; /*0x141048319*/
    v68 = 15; /*0x14104831d*/
    v65[0] = 0; /*0x141048329*/
    v33 = 0; /*0x14104832d*/
    v66 = 0; /*0x141048330*/
    Ptr = 15; /*0x141048334*/
    current._Mypair._Myval2._Bx = (std::_String_val<std::_Simple_types<char> >::_Bxty)0xFuLL; /*0x14104833a*/
    joinPhase = this->sgs.joinPhase; /*0x141048342*/
    v36 = &this->sgs.referralPage._Mypair._Myval2._Bx._Buf[32 * joinPhase + 8]; /*0x141048357*/
    if ( v65 == (_QWORD *)v36 ) /*0x141048361*/
    {
      __eh34_enter_wind_state(1, 2); /*0xf1c00000000000a0*/
    }
    else
    {
      v37 = *((_QWORD *)v36 + 2); /*0x141048363*/
      if ( *((_QWORD *)v36 + 3) >= 0x10u ) /*0x14104836c*/
        v36 = *(char **)v36; /*0x14104836e*/
      __eh34_enter_wind_state(1, 2); /*0xf1c00000000000a8*/
      std::string::assign(this: (std::string *)v65, _Ptr: v36, _Count: v37); /*0x141048375*/
      joinPhase = this->sgs.joinPhase; /*0x14104837a*/
      Ptr = (unsigned __int64)current._Mypair._Myval2._Bx._Ptr; /*0x141048380*/
      v33 = v66; /*0x141048384*/
    }
    v38 = &this->joinPhaseStrings._Elems[joinPhase]; /*0x141048396*/
    if ( &current._Mypair._Myval2._Bx._Alias[8] != (char *)v38 ) /*0x1410483a0*/
    {
      Mysize = v38->_Mypair._Myval2._Mysize; /*0x1410483a2*/
      if ( v38->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410483ab*/
        v38 = (std::string *)v38->_Mypair._Myval2._Bx._Ptr; /*0x1410483ad*/
      std::string::assign( /*0x1410483b4*/
        this: (std::string *)&current._Mypair._Myval2._Bx._Alias[8],
        _Ptr: v38->_Mypair._Myval2._Bx._Buf,
        _Count: Mysize);
    }
    v40 = std::string::string( /*0x1410483c6*/
            this: &v64,
            __that: (const rtc::webrtc_checks_impl::ToStringVal *)&current._Mypair._Myval2._Bx._Alias[8]);
    v70 = v40; /*0x1410483c9*/
    __eh34_enter_wind_state(2, 3); /*0xf1c0000000000098*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "CurrentJoinPhase", value: &v40->val); /*0x1410483da*/
    if ( __eh34_unwind(3) ) /*0xf1c000000000008c*/
    {
unwind_state_3:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)v70); /*0xf1c000000000004c*/
      __eh34_continue_unwinding(3, 2); /*0xf1c0000000000050*/
    }
    __eh34_exit_wind_state(3, 2); /*0xf1c0000000000090*/
    Myres = v40->val._Mypair._Myval2._Myres; /*0x1410483e0*/
    if ( Myres >= 0x10 ) /*0x1410483e8*/
    {
      v42 = v40->val._Mypair._Myval2._Bx._Ptr; /*0x1410483ea*/
      if ( Myres + 1 >= 0x1000 ) /*0x1410483f7*/
      {
        if ( (unsigned __int64)&v42[-*((_QWORD *)v42 - 1) - 8] > 0x1F ) /*0x14104840c*/
          _invalid_parameter_noinfo_noreturn(); /*0x141048457*/
        v42 = *((char **)v42 - 1); /*0x14104840e*/
      }
      operator delete(ptr: v42); /*0x141048411*/
    }
    v40->val._Mypair._Myval2._Mysize = 0; /*0x141048416*/
    v40->val._Mypair._Myval2._Myres = 15; /*0x14104841a*/
    v40->val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141048422*/
    v64.val._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141048425*/
    v64.val._Mypair._Myval2._Mysize = 0; /*0x141048429*/
    v64.val._Mypair._Myval2._Myres = 0; /*0x14104842d*/
    v43 = (std::_String_val<std::_Simple_types<char> >::_Bxty *)v65; /*0x141048431*/
    v44 = (char *)v65[0]; /*0x141048435*/
    if ( Ptr >= 0x10 ) /*0x14104843d*/
      v43 = (std::_String_val<std::_Simple_types<char> >::_Bxty *)v65[0]; /*0x14104843d*/
    if ( v33 >= 0x10 ) /*0x141048445*/
    {
      v45 = v33 | 0xF; /*0x141048461*/
      if ( (v33 | 0xF) > 0x7FFFFFFFFFFFFFFFLL ) /*0x141048472*/
        v45 = 0x7FFFFFFFFFFFFFFFLL; /*0x141048472*/
      if ( v45 + 1 < 0x1000 ) /*0x141048481*/
      {
        if ( v45 == -1 ) /*0x1410484b5*/
          v48 = nullptr; /*0x1410484be*/
        else
          v48 = (char *)operator new(size: v45 + 1); /*0x1410484b7*/
      }
      else
      {
        if ( v45 + 40 < v45 + 1 ) /*0x14104848a*/
          std::_Throw_bad_array_new_length(); /*0x1410487db*/
        v46 = operator new(size: v45 + 40); /*0x141048493*/
        v47 = v46; /*0x141048498*/
        if ( v46 == nullptr ) /*0x14104849e*/
LABEL_82:
          _invalid_parameter_noinfo_noreturn(); /*0x141048529*/
        v48 = (char *)(((unsigned __int64)v46 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x1410484a8*/
        *((_QWORD *)v48 - 1) = v47; /*0x1410484ac*/
      }
      v64.val._Mypair._Myval2._Bx._Ptr = v48; /*0x1410484c0*/
      memcpy_0(a1: v48, Src: v43, Size: v33 + 1); /*0x1410484ce*/
    }
    else
    {
      v64.val._Mypair._Myval2._Bx = *v43; /*0x14104844c*/
      v45 = 15; /*0x141048450*/
    }
    v64.val._Mypair._Myval2._Mysize = v33; /*0x1410484d3*/
    v64.val._Mypair._Myval2._Myres = v45; /*0x1410484d7*/
    v70 = &v64; /*0x1410484df*/
    __eh34_enter_wind_state(2, 3); /*0xf1c0000000000084*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "LastCompleteJoinPhase", value: &v64.val); /*0x1410484f1*/
    if ( __eh34_unwind(3) ) /*0xf1c0000000000078*/
      goto unwind_state_3; /*0xf1c0000000000078*/
    __eh34_exit_wind_state(3, 2); /*0xf1c000000000007c*/
    if ( v64.val._Mypair._Myval2._Myres >= 0x10 ) /*0x1410484ff*/
    {
      v49 = v64.val._Mypair._Myval2._Bx._Ptr; /*0x141048504*/
      if ( v64.val._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141048512*/
      {
        v49 = *((char **)v64.val._Mypair._Myval2._Bx._Ptr - 1); /*0x141048518*/
        if ( (unsigned __int64)(v64.val._Mypair._Myval2._Bx._Ptr - v49 - 8) > 0x1F ) /*0x141048527*/
          goto LABEL_82; /*0x141048527*/
      }
      operator delete(ptr: v49); /*0x141048530*/
    }
    if ( !DFFlag::ReportFailuresInClientJoinAllNonZero.value || timeOfFailure == 0.0 ) /*0x141048548*/
    {
      v53 = std::string::string(this: &v69, __that: joinFailureError); /*0x1410485cf*/
      v70 = v53; /*0x1410485d2*/
      __eh34_enter_wind_state(2, 3); /*0xf1c000000000005c*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "JoinFailureError", value: &v53->val); /*0x1410485e3*/
      if ( __eh34_unwind(3) ) /*0xf1c0000000000048*/
        goto unwind_state_3; /*0xf1c0000000000048*/
      __eh34_exit_wind_state(3, 2); /*0xf1c0000000000054*/
      v54 = v53->val._Mypair._Myval2._Myres; /*0x1410485e9*/
      if ( v54 >= 0x10 ) /*0x1410485f1*/
      {
        v55 = v53->val._Mypair._Myval2._Bx._Ptr; /*0x1410485f3*/
        if ( v54 + 1 >= 0x1000 ) /*0x141048600*/
        {
          if ( (unsigned __int64)&v55[-*((_QWORD *)v55 - 1) - 8] > 0x1F ) /*0x141048615*/
          {
            if ( __eh34_unwind(2) ) /*0xf1c0000000000020*/
            {
unwind_state_2:
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)v65); /*0xf1c0000000000024*/
              __eh34_continue_unwinding(2, 1); /*0xf1c0000000000028*/
            }
            __eh34_exit_wind_state(2, 1); /*0xf1c000000000002c*/
            _invalid_parameter_noinfo_noreturn(); /*0x141048689*/
          }
          v55 = *((char **)v55 - 1); /*0x141048617*/
        }
        operator delete(ptr: v55); /*0x14104861a*/
      }
      v53->val._Mypair._Myval2._Mysize = 0; /*0x141048622*/
      v53->val._Mypair._Myval2._Myres = 15; /*0x141048626*/
      v53->val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104862e*/
      if ( timeOfFailure == 0.0 ) /*0x141048637*/
        goto LABEL_136; /*0x141048637*/
    }
    else
    {
      v50 = std::string::string(this: &v64, __that: joinFailureError); /*0x141048557*/
      v70 = v50; /*0x14104855a*/
      __eh34_enter_wind_state(2, 3); /*0xf1c0000000000070*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "JoinFailureError", value: &v50->val); /*0x14104856b*/
      if ( __eh34_unwind(3) ) /*0xf1c0000000000064*/
        goto unwind_state_3; /*0xf1c0000000000064*/
      __eh34_exit_wind_state(3, 2); /*0xf1c0000000000068*/
      v51 = v50->val._Mypair._Myval2._Myres; /*0x141048571*/
      if ( v51 >= 0x10 ) /*0x141048579*/
      {
        v52 = v50->val._Mypair._Myval2._Bx._Ptr; /*0x14104857b*/
        if ( v51 + 1 >= 0x1000 ) /*0x141048588*/
        {
          if ( (unsigned __int64)&v52[-*((_QWORD *)v52 - 1) - 8] > 0x1F ) /*0x14104859d*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410485bb*/
          v52 = *((char **)v52 - 1); /*0x14104859f*/
        }
        operator delete(ptr: v52); /*0x1410485a2*/
      }
      v50->val._Mypair._Myval2._Mysize = 0; /*0x1410485aa*/
      v50->val._Mypair._Myval2._Myres = 15; /*0x1410485ae*/
      v50->val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410485b6*/
    }
    v56 = timeOfFailure - this->sgs.userClickTime; /*0x141048639*/
    if ( v56 > 0.0 ) /*0x141048642*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: p_analyticsPoints, name: "TimeToFailure", value: v56); /*0x141048651*/
    if ( __eh34_unwind(2) ) /*0xf1c0000000000034*/
      goto unwind_state_2; /*0xf1c0000000000034*/
LABEL_136:
    __eh34_exit_wind_state(2, 1); /*0xf1c0000000000038*/
    if ( Ptr >= 0x10 ) /*0x14104865b*/
    {
      v57 = v44; /*0x141048661*/
      if ( Ptr + 1 >= 0x1000 ) /*0x14104866b*/
      {
        v44 = *((char **)v44 - 1); /*0x141048671*/
        if ( (unsigned __int64)(v57 - v44 - 8) > 0x1F ) /*0x141048680*/
          _invalid_parameter_noinfo_noreturn(); /*0x141048682*/
      }
      operator delete(ptr: v44); /*0x141048693*/
    }
    if ( v68 >= 0x10 ) /*0x1410486a1*/
    {
      v58 = *(void **)&current._Mypair._Myval2._Bx._Alias[8]; /*0x1410486a6*/
      if ( v68 + 1 >= 0x1000 ) /*0x1410486b4*/
      {
        v58 = *(void **)(*(_QWORD *)&current._Mypair._Myval2._Bx._Alias[8] - 8LL); /*0x1410486ba*/
        if ( (unsigned __int64)(*(_QWORD *)&current._Mypair._Myval2._Bx._Alias[8] - (_QWORD)v58 - 8LL) > 0x1F ) /*0x1410486c9*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410486cb*/
      }
      operator delete(ptr: v58); /*0x1410486d2*/
    }
    v5 = joinFailureError; /*0x1410486d7*/
LABEL_114:
    v59 = DFInt::JoinInfluxHundredthsPercentage; /*0x1410486db*/
    *(_QWORD *)&current._Mypair._Myval2._Bx._Alias[8] = 0; /*0x1410486e1*/
    current._Mypair._Myval2._Myres = 0; /*0x1410486e5*/
    v68 = 15; /*0x1410486e9*/
    v60 = -1; /*0x1410486fc*/
    do /*0x14104870b*/
      ++v60; /*0x141048703*/
    while ( clientJoin_All[v60] != 0 ); /*0x14104870b*/
    if ( __eh34_unwind(1) ) /*0xf1c000000000000c*/
    {
unwind_state_1:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&current._Mypair._Myval2._Bx._Alias[8]); /*0xf1c0000000000010*/
      __eh34_continue_unwinding(1, 0); /*0xf1c0000000000014*/
    }
    __eh34_exit_wind_state(1, 0); /*0xf1c0000000000018*/
    std::string::assign(this: (std::string *)&current._Mypair._Myval2._Bx._Alias[8], _Ptr: clientJoin_All, _Count: v60); /*0x141048711*/
    __eh34_enter_wind_state(0, 1); /*0xf1c0000000000004*/
    RBX::Analytics::InfluxDb::Points::report( /*0x141048724*/
      this: p_analyticsPoints,
      resource: (const std::string *)&current._Mypair._Myval2._Bx._Alias[8],
      throttleHundredthsPercentage: v59,
      blocking: false);
    if ( v68 >= 0x10 ) /*0x141048732*/
    {
      v61 = *(void **)&current._Mypair._Myval2._Bx._Alias[8]; /*0x141048737*/
      if ( v68 + 1 >= 0x1000 ) /*0x141048745*/
      {
        v61 = *(void **)(*(_QWORD *)&current._Mypair._Myval2._Bx._Alias[8] - 8LL); /*0x14104874b*/
        if ( (unsigned __int64)(*(_QWORD *)&current._Mypair._Myval2._Bx._Alias[8] - (_QWORD)v61 - 8LL) > 0x1F ) /*0x14104875a*/
          _invalid_parameter_noinfo_noreturn(); /*0x14104875c*/
      }
      operator delete(ptr: v61); /*0x141048763*/
    }
    v62 = v5->val._Mypair._Myval2._Myres; /*0x141048769*/
    if ( v62 >= 0x10 ) /*0x141048771*/
    {
      v63 = v5->val._Mypair._Myval2._Bx._Ptr; /*0x141048776*/
      if ( v62 + 1 >= 0x1000 ) /*0x141048780*/
      {
        if ( (unsigned __int64)&v63[-*((_QWORD *)v63 - 1) - 8] > 0x1F ) /*0x141048795*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410487d4*/
        v63 = *((char **)v63 - 1); /*0x141048797*/
      }
      operator delete(ptr: v63); /*0x14104879a*/
    }
    v5->val._Mypair._Myval2._Mysize = 0; /*0x14104879f*/
    v5->val._Mypair._Myval2._Myres = 15; /*0x1410487a3*/
    v5->val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410487ab*/
    if ( __eh34_unwind(1) ) /*0xf1c00000000000d0*/
      goto unwind_state_1; /*0xf1c00000000000d0*/
    __eh34_exit_wind_state(1, 0); /*0xf1c00000000000d4*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)joinFailureError); /*0xf1c00000000000c8*/
  }
}

// Address: 0x1410487f0 | Name: ?reportLocalJoinFailureMetrics@PlayerConfigurer@RBX@@AEAAXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@N@Z
void __fastcall RBX::PlayerConfigurer::reportLocalJoinFailureMetrics(
        RBX::PlayerConfigurer *this,
        rtc::webrtc_checks_impl::ToStringVal *state,
        long double time)
{
  rtc::webrtc_checks_impl::ToStringVal *v6; // rax
  unsigned __int64 Myres; // rdx
  char *Ptr; // rcx
  rtc::webrtc_checks_impl::ToStringVal v9; // [rsp+20h] [rbp-188h] BYREF
  RBX::AvatarMetrics am; // [rsp+40h] [rbp-168h] BYREF

  RBX::AvatarMetrics::AvatarMetrics(this: &am); /*0x141048818*/
  __wind /*0xf1c000000000001c*/
  {
    __wind /*0xf1c0000000000024*/
    {
      v6 = std::string::string(this: &v9, __that: state); /*0x141048826*/
      RBX::PlayerConfigurer::reportLocalAvatarMetrics(this, metrics: &am, joinFailureError: v6, timeOfFailure: time); /*0x141048839*/
    }
    __unwind
    {
      RBX::AvatarMetrics::~AvatarMetrics(this: &am); /*0xf1c0000000000014*/
    }
    RBX::AvatarMetrics::~AvatarMetrics(this: &am); /*0x141048844*/
    Myres = state->val._Mypair._Myval2._Myres; /*0x14104884a*/
    if ( Myres >= 0x10 ) /*0x141048852*/
    {
      Ptr = state->val._Mypair._Myval2._Bx._Ptr; /*0x141048857*/
      if ( Myres + 1 >= 0x1000 ) /*0x141048861*/
      {
        if ( (unsigned __int64)&Ptr[-*((_QWORD *)Ptr - 1) - 8] > 0x1F ) /*0x141048876*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410488ac*/
        Ptr = *((char **)Ptr - 1); /*0x141048878*/
      }
      operator delete(ptr: Ptr); /*0x14104887b*/
    }
    state->val._Mypair._Myval2._Mysize = 0; /*0x141048880*/
    state->val._Mypair._Myval2._Myres = 15; /*0x141048888*/
    state->val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141048890*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)state); /*0xf1c0000000000008*/
  }
}

// Address: 0x141048be0 | Name: ?setIsStudioToRcc@PlayerConfigurer@RBX@@QEAAX_N@Z
void __fastcall RBX::PlayerConfigurer::setIsStudioToRcc(RBX::PlayerConfigurer *this, bool isStudioToRcc)
{
  this->isStudioToRcc = isStudioToRcc; /*0x141048be0*/
}

// Address: 0x141048bf0 | Name: ?showErrorWindow@PlayerConfigurer@RBX@@AEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@00H@Z
void __fastcall RBX::PlayerConfigurer::showErrorWindow(
        RBX::PlayerConfigurer *this,
        const rtc::webrtc_checks_impl::ToStringVal *message,
        const std::string *errorType,
        const std::string *errorCategory,
        int errorCode)
{
  const std::string *v6; // rbx
  RBX::PlayerConfigurer *v7; // rdi
  char v8; // r14
  __int64 v9; // rsi
  RBX::ClientSessionTracker::ClientSessionTrackerContext *Instance; // rax
  volatile signed __int32 *Rep; // rsi
  int v12; // esi
  bool joinResolved; // al
  RBX::InferredCrash *v14; // rax
  long double v15; // xmm3_8
  char *Ptr; // rcx
  const char *_Right_ptr; // rax
  RBX::GuiService *v18; // rdi
  unsigned __int64 Mysize; // rax
  bool v20; // bl
  long double v21; // xmm6_8
  char *v22; // rcx
  char *v23; // rcx
  char *v24; // rcx
  __int64 ParamInt64; // rax
  const char *v26; // r8
  std::string *v27; // rax
  char *v28; // rcx
  char *v29; // rcx
  std::string *ParamString; // rax
  const char *v31; // r8
  std::string *v32; // rax
  char *v33; // rcx
  char *v34; // rcx
  char *v35; // rcx
  int ParamInt; // eax
  const char *v37; // r8
  std::string *v38; // rax
  void *v39; // rcx
  char *v40; // rcx
  const char *v41; // rax
  char *v42; // rcx
  rtc::webrtc_checks_impl::ToStringVal *v43; // rax
  const char *v44; // rax
  const char *v45; // rax
  RBX::InferredCrash::ErrorInfo errInfo; // [rsp+40h] [rbp-228h] BYREF
  int v47; // [rsp+48h] [rbp-220h]
  std::string category; // [rsp+50h] [rbp-218h] BYREF
  std::shared_ptr<RBX::ClientSessionTracker::ClientSessionMetricKey<__int64,0> const > v49; // [rsp+70h] [rbp-1F8h] BYREF
  std::shared_ptr<RBX::ClientSessionTracker::ClientSessionMetricKey<__int64,0> const > v50; // [rsp+80h] [rbp-1E8h] BYREF
  std::string v51; // [rsp+90h] [rbp-1D8h] BYREF
  std::string v52; // [rsp+B0h] [rbp-1B8h] BYREF
  std::string key; // [rsp+D0h] [rbp-198h] BYREF
  std::string v54; // [rsp+F0h] [rbp-178h] BYREF
  std::string v55; // [rsp+110h] [rbp-158h] BYREF
  std::string counterName; // [rsp+130h] [rbp-138h] BYREF
  std::string v57; // [rsp+150h] [rbp-118h] BYREF
  std::string v58; // [rsp+170h] [rbp-F8h] BYREF
  std::string v59; // [rsp+190h] [rbp-D8h] BYREF
  _QWORD v60[3]; // [rsp+1B0h] [rbp-B8h] BYREF
  unsigned __int64 v61; // [rsp+1C8h] [rbp-A0h]
  std::shared_ptr<RBX::File> *v62; // [rsp+1D0h] [rbp-98h]
  std::exception *v63; // [rsp+1D8h] [rbp-90h] BYREF
  std::exception *e; // [rsp+1E0h] [rbp-88h] BYREF
  std::string result; // [rsp+1E8h] [rbp-80h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v66; // [rsp+208h] [rbp-60h] BYREF

  v6 = errorType; /*0x141048c19*/
  v7 = this; /*0x141048c1c*/
  v8 = 0; /*0x141048c1f*/
  v47 = 0; /*0x141048c22*/
  if ( DFFlag::PredictedOOMTelemetryFix.value ) /*0x141048c2e*/
  {
    if ( DFFlag::EngineStabilityMetrics.value ) /*0x141048c3b*/
    {
      v9 = RBX::Time::epochTime(); /*0x141048c46*/
      v49 = 0; /*0x141048c4c*/
      if ( RBX::ClientSessionTrackerKeys::LastGameErrorTime._Rep != nullptr ) /*0x141048c5c*/
        _InterlockedIncrement((volatile signed __int32 *)&RBX::ClientSessionTrackerKeys::LastGameErrorTime._Rep->_Uses); /*0x141048c5e*/
      __wind /*0xf1c00000000001ac*/
      {
        v49 = RBX::ClientSessionTrackerKeys::LastGameErrorTime; /*0x141048c69*/
        v62 = (std::shared_ptr<RBX::File> *)&v49; /*0x141048c73*/
        Instance = RBX::ClientSessionTracker::ClientSessionTrackerContext::getInstance(); /*0x141048c7b*/
        v50 = 0; /*0x141048c83*/
        if ( v49._Rep != nullptr ) /*0x141048c94*/
          _InterlockedIncrement((volatile signed __int32 *)&v49._Rep->_Uses); /*0x141048c96*/
        v50 = v49; /*0x141048c9f*/
        RBX::ClientSessionTracker::ClientSessionTrackerContext::updateClientSessionMetric<__int64,0>( /*0x141048cb9*/
          this: Instance,
          metricKey: (std::shared_ptr<RBX::File> *)&v50,
          value: v9,
          bFlush: false);
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v62); /*0xf1c00000000001a4*/
      }
      Rep = (volatile signed __int32 *)v49._Rep; /*0x141048cbf*/
      if ( v49._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v49._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141048cda*/
      {
        (**(void (__fastcall ***)(volatile signed __int32 *))Rep)(a1: Rep); /*0x141048ce2*/
        if ( _InterlockedExchangeAdd(Rep + 3, 0xFFFFFFFF) == 1 ) /*0x141048cee*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)Rep + 8LL))(a1: Rep); /*0x141048cf6*/
      }
    }
    v12 = errorCode; /*0x141048cf9*/
    if ( (unsigned int)(errorCode - 288) > 1 ) /*0x141048d09*/
    {
      errInfo.playerConnected = v7->connectResolved; /*0x141048d0f*/
      errInfo.gameLoaded = v7->loadResolved; /*0x141048d17*/
      joinResolved = v7->joinResolved; /*0x141048d1b*/
LABEL_16:
      errInfo.playerJoined = joinResolved; /*0x141048d44*/
      errInfo.errorCode = v12; /*0x141048d48*/
      v14 = RBX::InferredCrash::getInstance(); /*0x141048d4c*/
      RBX::InferredCrash::onGameError(this: v14, &errInfo); /*0x141048d59*/
    }
  }
  else
  {
    v12 = errorCode; /*0x141048d21*/
    if ( errorCode != 288 ) /*0x141048d2e*/
    {
      errInfo.playerConnected = this->connectResolved; /*0x141048d34*/
      errInfo.gameLoaded = this->loadResolved; /*0x141048d3c*/
      joinResolved = this->joinResolved; /*0x141048d40*/
      goto LABEL_16; /*0x141048d40*/
    }
  }
  if ( v7->loadResolved && v7->joinResolved )
  {
    if ( !v7->playResolved )
    {
      v15 = RBX::Time::nowFastSec() - v7->sgs.userClickTime - v7->sgs.gameJoinTime; /*0x141048d89*/
      category._Mypair._Myval2._Myres = 15; /*0x141048d91*/
      category._Mypair._Myval2._Mysize = 12; /*0x141048d9a*/
      strcpy(category._Mypair._Myval2._Bx._Buf, "GameDuration"); /*0x141048dab*/
      __eh34_enter_wind_state(-1, 6); /*0xf1c0000000000198*/
      RBX::PlayerConfigurer::reportDuration(this: v7, &category, result: errorCategory, duration: v15); /*0x141048dcb*/
      if ( __eh34_unwind(6) ) /*0xf1c000000000018c*/
        goto unwind_state_6; /*0xf1c000000000018c*/
      __eh34_exit_wind_state(6, -1); /*0xf1c0000000000190*/
      if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x141048dda*/
      {
        Ptr = category._Mypair._Myval2._Bx._Ptr; /*0x141048ddf*/
        if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141048dee*/
        {
          Ptr = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x141048df4*/
          if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141048e03*/
            _invalid_parameter_noinfo_noreturn(); /*0x141048e05*/
        }
        operator delete(ptr: Ptr); /*0x141048e0c*/
      }
      try
      {
        v7->playResolved = true; /*0x141048e11*/
        if ( 0x7FFFFFFFFFFFFFFFLL - v6->_Mypair._Myval2._Mysize < 0xF ) /*0x141048e2a*/
          std::_Xlen_string(); /*0x1410496b1*/
        _Right_ptr = (const char *)v6; /*0x141048e30*/
        if ( v6->_Mypair._Myval2._Myres >= 0x10 ) /*0x141048e38*/
          _Right_ptr = v6->_Mypair._Myval2._Bx._Ptr; /*0x141048e3a*/
        std::string::string( /*0x141048e6a*/
          this: &counterName,
          __formal: (std::_String_constructor_concat_tag)this,
          _Source_of_al: v6,
          _Left_ptr: "GameDisconnect-",
          _Left_size: 0xFu,
          _Right_ptr,
          _Right_size: v6->_Mypair._Myval2._Mysize);
        __wind /*0xf1c0000000000158*/
        {
          v8 = 4; /*0x141048e6f*/
          v47 = 4; /*0x141048e75*/
          RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x141048e89*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0x141048e97*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c0000000000168*/
        }
      }
      catch ( std::exception *v63 )
      {
        v44 = v63->what(this: v63); /*0x1431e8197*/
        RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "http failed in showErrorWindow: %s", v44);
        v8 = v47; /*0x141048ea1*/
        v6 = errorType; /*0x141048ea6*/
        v12 = errorCode; /*0x141048eae*/
        v7 = this; /*0x141048eb5*/
      }
    }
  }
  else
  {
    v21 = RBX::Time::nowFastSec() - v7->sgs.avatarConfigureTime; /*0x141048f28*/
    if ( !v7->loadResolved ) /*0x141048f34*/
    {
      v7->loadResolved = true; /*0x141048f3a*/
      v52._Mypair._Myval2._Myres = 15; /*0x141048f46*/
      v52._Mypair._Myval2._Mysize = 7; /*0x141048f52*/
      qmemcpy(&v52, "Failur", 6); /*0x141048f64*/
      *(_WORD *)&v52._Mypair._Myval2._Bx._Alias[6] = (unsigned __int8)aFailure_0[6]; /*0x141048f81*/
      __wind /*0xf1c000000000014c*/
      {
        v51._Mypair._Myval2._Myres = 15; /*0x141048f90*/
        v51._Mypair._Myval2._Mysize = 8; /*0x141048f9c*/
        strcpy(v51._Mypair._Myval2._Bx._Buf, "GameLoad"); /*0x141048fb2*/
        __wind /*0xf1c0000000000128*/
        {
          RBX::PlayerConfigurer::reportDuration(this: v7, category: &v51, result: &v52, duration: v21); /*0x141048fd8*/
          if ( v51._Mypair._Myval2._Myres >= 0x10 ) /*0x141048fea*/
          {
            v22 = v51._Mypair._Myval2._Bx._Ptr; /*0x141048fef*/
            if ( v51._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141049001*/
            {
              v22 = *((char **)v51._Mypair._Myval2._Bx._Ptr - 1); /*0x141049007*/
              if ( (unsigned __int64)(v51._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x141049016*/
                _invalid_parameter_noinfo_noreturn(); /*0x141049018*/
            }
            operator delete(ptr: v22); /*0x14104901f*/
          }
          v51._Mypair._Myval2._Mysize = 0; /*0x141049024*/
          v51._Mypair._Myval2._Myres = 15; /*0x14104902c*/
          v51._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141049038*/
          if ( v52._Mypair._Myval2._Myres >= 0x10 ) /*0x14104904c*/
          {
            v23 = v52._Mypair._Myval2._Bx._Ptr; /*0x141049051*/
            if ( v52._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141049063*/
            {
              v23 = *((char **)v52._Mypair._Myval2._Bx._Ptr - 1); /*0x141049069*/
              if ( (unsigned __int64)(v52._Mypair._Myval2._Bx._Ptr - v23 - 8) > 0x1F ) /*0x141049078*/
                _invalid_parameter_noinfo_noreturn(); /*0x14104907a*/
            }
            operator delete(ptr: v23); /*0x141049081*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v51); /*0xf1c0000000000138*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v52); /*0xf1c0000000000144*/
      }
    }
    __wind /*0xf1c00000000000f0*/
    {
      if ( !v7->joinResolved ) /*0x14104908a*/
      {
        v7->joinResolved = true; /*0x141049090*/
        v55._Mypair._Myval2._Myres = 15; /*0x141049094*/
        v55._Mypair._Myval2._Mysize = 8; /*0x1410490a0*/
        strcpy(v55._Mypair._Myval2._Bx._Buf, "GameJoin"); /*0x1410490b6*/
        RBX::PlayerConfigurer::reportDuration(this: v7, category: &v55, result: errorCategory, duration: v21); /*0x1410490d7*/
        if ( v55._Mypair._Myval2._Myres >= 0x10 ) /*0x1410490e9*/
        {
          v24 = v55._Mypair._Myval2._Bx._Ptr; /*0x1410490ee*/
          if ( v55._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141049100*/
          {
            v24 = *((char **)v55._Mypair._Myval2._Bx._Ptr - 1); /*0x141049106*/
            if ( (unsigned __int64)(v55._Mypair._Myval2._Bx._Ptr - v24 - 8) > 0x1F ) /*0x141049115*/
              _invalid_parameter_noinfo_noreturn(); /*0x141049117*/
          }
          operator delete(ptr: v24); /*0x14104911e*/
        }
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v55); /*0xf1c0000000000100*/
    }
    __wind /*0xf1c0000000000108*/
    {
      key._Mypair._Myval2._Myres = 15; /*0x14104912b*/
      key._Mypair._Myval2._Mysize = 7; /*0x141049137*/
      qmemcpy(&key, "PlaceI", 6); /*0x141049149*/
      *(_WORD *)&key._Mypair._Myval2._Bx._Alias[6] = (unsigned __int8)aPlaceid_16[6]; /*0x141049166*/
      ParamInt64 = RBX::GameConfigurer::getParamInt64(this: v7, &key); /*0x141049180*/
      v26 = (const char *)v6; /*0x141049185*/
      if ( v6->_Mypair._Myval2._Myres >= 0x10 ) /*0x14104918d*/
        v26 = v6->_Mypair._Myval2._Bx._Ptr; /*0x14104918f*/
      v27 = RBX::format(result: &v57, fmt: "%s_%lld", v26, ParamInt64); /*0x1410491a4*/
      __wind /*0xf1c00000000000e4*/
      {
        if ( v27->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410491af*/
          v27 = (std::string *)v27->_Mypair._Myval2._Bx._Ptr; /*0x1410491b1*/
        RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1410491cd*/
          category: "Game",
          action: "JoinFailurePlace",
          label: v27->_Mypair._Myval2._Bx._Buf,
          value: 0,
          sync: false);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v57); /*0xf1c00000000000dc*/
      }
      if ( v57._Mypair._Myval2._Myres >= 0x10 ) /*0x1410491df*/
      {
        v28 = v57._Mypair._Myval2._Bx._Ptr; /*0x1410491e4*/
        if ( v57._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410491f6*/
        {
          v28 = *((char **)v57._Mypair._Myval2._Bx._Ptr - 1); /*0x1410491fc*/
          if ( (unsigned __int64)(v57._Mypair._Myval2._Bx._Ptr - v28 - 8) > 0x1F ) /*0x14104920b*/
            _invalid_parameter_noinfo_noreturn(); /*0x14104920d*/
        }
        operator delete(ptr: v28); /*0x141049214*/
      }
      v57._Mypair._Myval2._Mysize = 0; /*0x141049219*/
      v57._Mypair._Myval2._Myres = 15; /*0x141049221*/
      v57._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104922d*/
      if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x141049241*/
      {
        v29 = key._Mypair._Myval2._Bx._Ptr; /*0x141049246*/
        if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141049258*/
        {
          v29 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x14104925e*/
          if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v29 - 8) > 0x1F ) /*0x14104926d*/
            _invalid_parameter_noinfo_noreturn(); /*0x14104926f*/
        }
        operator delete(ptr: v29); /*0x141049276*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key); /*0xf1c0000000000118*/
    }
    __eh34_enter_wind_state(-1, 6); /*0xf1c0000000000120*/
    category._Mypair._Myval2._Myres = 15; /*0x14104927b*/
    category._Mypair._Myval2._Mysize = 14; /*0x141049284*/
    strcpy(category._Mypair._Myval2._Bx._Buf, "MachineAddress"); /*0x141049295*/
    ParamString = RBX::GameConfigurer::getParamString(this: v7, result: &v59, key: &category); /*0x1410492c6*/
    if ( ParamString->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410492d1*/
      ParamString = (std::string *)ParamString->_Mypair._Myval2._Bx._Ptr; /*0x1410492d3*/
    v31 = (const char *)v6; /*0x1410492d6*/
    if ( v6->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410492de*/
      v31 = v6->_Mypair._Myval2._Bx._Ptr; /*0x1410492e0*/
    __wind /*0xf1c00000000000cc*/
    {
      v32 = RBX::format(result: &v58, fmt: "%s_%s", v31, ParamString->_Mypair._Myval2._Bx._Buf); /*0x1410492f5*/
      if ( v32->_Mypair._Myval2._Myres >= 0x10 ) /*0x141049300*/
        v32 = (std::string *)v32->_Mypair._Myval2._Bx._Ptr; /*0x141049302*/
      __wind /*0xf1c000000000008c*/
      {
        RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x14104931e*/
          category: "Game",
          action: "JoinFailureIP",
          label: v32->_Mypair._Myval2._Bx._Buf,
          value: 0,
          sync: false);
        if ( v58._Mypair._Myval2._Myres >= 0x10 ) /*0x141049330*/
        {
          v33 = v58._Mypair._Myval2._Bx._Ptr; /*0x141049335*/
          if ( v58._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141049347*/
          {
            v33 = *((char **)v58._Mypair._Myval2._Bx._Ptr - 1); /*0x14104934d*/
            if ( (unsigned __int64)(v58._Mypair._Myval2._Bx._Ptr - v33 - 8) > 0x1F ) /*0x14104935c*/
              _invalid_parameter_noinfo_noreturn(); /*0x14104935e*/
          }
          operator delete(ptr: v33); /*0x141049365*/
        }
        v58._Mypair._Myval2._Mysize = 0; /*0x14104936a*/
        v58._Mypair._Myval2._Myres = 15; /*0x141049372*/
        v58._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14104937e*/
        if ( v59._Mypair._Myval2._Myres >= 0x10 ) /*0x141049392*/
        {
          v34 = v59._Mypair._Myval2._Bx._Ptr; /*0x141049397*/
          if ( v59._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410493a9*/
          {
            v34 = *((char **)v59._Mypair._Myval2._Bx._Ptr - 1); /*0x1410493af*/
            if ( (unsigned __int64)(v59._Mypair._Myval2._Bx._Ptr - v34 - 8) > 0x1F ) /*0x1410493be*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410493c0*/
          }
          operator delete(ptr: v34); /*0x1410493c7*/
        }
        v59._Mypair._Myval2._Mysize = 0; /*0x1410493cc*/
        v59._Mypair._Myval2._Myres = 15; /*0x1410493d4*/
        v59._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410493e0*/
        if ( category._Mypair._Myval2._Myres >= 0x10 ) /*0x1410493f1*/
        {
          v35 = category._Mypair._Myval2._Bx._Ptr; /*0x1410493f6*/
          if ( category._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141049405*/
          {
            v35 = *((char **)category._Mypair._Myval2._Bx._Ptr - 1); /*0x14104940b*/
            if ( (unsigned __int64)(category._Mypair._Myval2._Bx._Ptr - v35 - 8) > 0x1F ) /*0x14104941a*/
              _invalid_parameter_noinfo_noreturn(); /*0x14104941c*/
          }
          operator delete(ptr: v35); /*0x141049423*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v58); /*0xf1c000000000009c*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v59); /*0xf1c00000000000a8*/
    }
    if ( __eh34_unwind(6) ) /*0xf1c00000000000b0*/
    {
unwind_state_6:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&category); /*0xf1c00000000000b4*/
      __eh34_propagate_exception_into_caller(6, -1); /*0xf1c00000000000b8*/
    }
    __eh34_exit_wind_state(6, -1); /*0xf1c00000000000bc*/
    __wind /*0xf1c00000000000c0*/
    {
      v54._Mypair._Myval2._Myres = 15; /*0x141049428*/
      v54._Mypair._Myval2._Mysize = 12; /*0x141049434*/
      strcpy(v54._Mypair._Myval2._Bx._Buf, "DataCenterId"); /*0x141049448*/
      ParamInt = RBX::GameConfigurer::getParamInt(this: v7, key: &v54); /*0x141049471*/
      v37 = (const char *)v6; /*0x141049476*/
      if ( v6->_Mypair._Myval2._Myres >= 0x10 ) /*0x14104947e*/
        v37 = v6->_Mypair._Myval2._Bx._Ptr; /*0x141049480*/
      v38 = RBX::format(result: (std::string *)v60, fmt: "%s_%d", v37, ParamInt); /*0x141049495*/
      __wind /*0xf1c0000000000080*/
      {
        if ( v38->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410494a0*/
          v38 = (std::string *)v38->_Mypair._Myval2._Bx._Ptr; /*0x1410494a2*/
        RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1410494be*/
          category: "Game",
          action: "JoinFailureDataCenter",
          label: v38->_Mypair._Myval2._Bx._Buf,
          value: 0,
          sync: false);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)v60); /*0xf1c0000000000078*/
      }
      if ( v61 >= 0x10 ) /*0x1410494d0*/
      {
        v39 = (void *)v60[0]; /*0x1410494d5*/
        if ( v61 + 1 >= 0x1000 ) /*0x1410494e7*/
        {
          v39 = *(void **)(v60[0] - 8LL); /*0x1410494ed*/
          if ( (unsigned __int64)(v60[0] - (_QWORD)v39 - 8LL) > 0x1F ) /*0x1410494fc*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410494fe*/
        }
        operator delete(ptr: v39); /*0x141049505*/
      }
      v60[2] = 0; /*0x14104950a*/
      v61 = 15; /*0x141049512*/
      LOBYTE(v60[0]) = 0; /*0x14104951e*/
      if ( v54._Mypair._Myval2._Myres >= 0x10 ) /*0x141049532*/
      {
        v40 = v54._Mypair._Myval2._Bx._Ptr; /*0x141049537*/
        if ( v54._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141049549*/
        {
          v40 = *((char **)v54._Mypair._Myval2._Bx._Ptr - 1); /*0x14104954f*/
          if ( (unsigned __int64)(v54._Mypair._Myval2._Bx._Ptr - v40 - 8) > 0x1F ) /*0x14104955e*/
            _invalid_parameter_noinfo_noreturn(); /*0x141049560*/
        }
        operator delete(ptr: v40); /*0x141049567*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v54); /*0xf1c000000000006c*/
    }
    RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x141049589*/
      category: "Game",
      action: "GameJoin",
      label: "Failure",
      value: 0,
      sync: false);
    try
    {
      if ( 0x7FFFFFFFFFFFFFFFLL - v6->_Mypair._Myval2._Mysize < 0xC ) /*0x1410495a4*/
        std::_Xlen_string(); /*0x1410496b7*/
      v41 = (const char *)v6; /*0x1410495aa*/
      if ( v6->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410495b2*/
        v41 = v6->_Mypair._Myval2._Bx._Ptr; /*0x1410495b4*/
      std::string::string( /*0x1410495e4*/
        this: &counterName,
        __formal: (std::_String_constructor_concat_tag)this,
        _Source_of_al: v6,
        _Left_ptr: "JoinFailure-",
        _Left_size: 0xCu,
        _Right_ptr: v41,
        _Right_size: v6->_Mypair._Myval2._Mysize);
      __wind /*0xf1c0000000000034*/
      {
        v8 = 2; /*0x1410495e9*/
        v47 = 2; /*0x1410495ef*/
        RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x141049603*/
        if ( counterName._Mypair._Myval2._Myres >= 0x10 ) /*0x141049615*/
        {
          v42 = counterName._Mypair._Myval2._Bx._Ptr; /*0x14104961a*/
          if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14104962c*/
          {
            v42 = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x141049632*/
            if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - v42 - 8) > 0x1F ) /*0x141049641*/
              _invalid_parameter_noinfo_noreturn(); /*0x141049643*/
          }
          operator delete(ptr: v42); /*0x14104964a*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c0000000000044*/
      }
    }
    catch ( std::exception *e )
    {
      v45 = e->what(this: e); /*0x1431e81d7*/
      RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "http failed in showErrorWindow: %s", v45);
      v8 = v47; /*0x141048ea1*/
      v6 = errorType; /*0x141048ea6*/
      v12 = errorCode; /*0x141048eae*/
      v7 = this; /*0x141048eb5*/
    }
  }
  v18 = RBX::ServiceProvider::create<RBX::GuiService>(this: &v7->dataModel->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x141048ebd*/
  if ( v18 != nullptr ) /*0x141048ed0*/
  {
    Mysize = v6->_Mypair._Myval2._Mysize; /*0x141048ed6*/
    if ( v6->_Mypair._Myval2._Myres >= 0x10 ) /*0x141048edf*/
      v6 = (const std::string *)v6->_Mypair._Myval2._Bx._Ptr; /*0x141048ee1*/
    v20 = true; /*0x141048f19*/
    if ( Mysize == 4 && *(_DWORD *)v6->_Mypair._Myval2._Bx._Buf == 1801677131 ) /*0x141048ef4*/
    {
      v8 |= 1u; /*0x141048f0a*/
      if ( RBX::GuiService::getErrorMessage(this: v18, &result)->_Mypair._Myval2._Mysize != 0 ) /*0x141048f13*/
        v20 = false; /*0x141048ee8*/
    }
    if ( (v8 & 1) != 0 ) /*0x14104965b*/
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0x141049665*/
    if ( v20 ) /*0x14104966c*/
    {
      v43 = std::string::string(this: &v66, __that: message); /*0x14104967e*/
      RBX::GuiService::setErrorMessage(this: v18, newErrorMessage: &v43->val, errorCode: v12); /*0x14104968c*/
    }
  }
}

// END PlayerConfigurer part 1/1, 31 functions
