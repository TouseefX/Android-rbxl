// RuppTokenProcessor -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 16 functions

// Field names below come from the 2022 PDB, which is the only
// build that has them. Each is marked: bare `this->x` was
// corroborated by a store of matching width in that same
// function; UNVERIFIED means the 2022 layout says so and
// nothing target-era has confirmed it.


// Address: 0x1037b8edc | Name: __ZN3RBX4Rupp18RuppTokenProcessorC2EPKc
void (__fastcall **__fastcall RBX::Rupp::RuppTokenProcessor::RuppTokenProcessor(
        RBX::Rupp::RuppTokenProcessor *this,
        const char *a2))(RBX::Rupp::RuppTokenProcessor *__hidden this)
{
  this->ptr /* +0 */= off_10C8EC380; /*0x1037b8ee7*/
  return off_10C8EC380; /*0x1037b8eea*/
}

// Address: 0x1037b8eec | Name: __ZN3RBX4Rupp18RuppTokenProcessorC1EPKc
void (__fastcall **__fastcall RBX::Rupp::RuppTokenProcessor::RuppTokenProcessor(
        RBX::Rupp::RuppTokenProcessor *this,
        const char *a2))(RBX::Rupp::RuppTokenProcessor *__hidden this)
{
  this->ptr /* +0 */= off_10C8EC380; /*0x1037b8ef7*/
  return off_10C8EC380; /*0x1037b8efa*/
}

// Address: 0x1037b8efc | Name: __ZN3RBX4Rupp18RuppTokenProcessorD2Ev
void __fastcall RBX::Rupp::RuppTokenProcessor::~RuppTokenProcessor(RBX::Rupp::RuppTokenProcessor *this)
{
  ; /*0x1037b8efc*/
}

// Address: 0x1037b8f02 | Name: __ZN3RBX4Rupp18RuppTokenProcessorD1Ev
void __fastcall RBX::Rupp::RuppTokenProcessor::~RuppTokenProcessor(RBX::Rupp::RuppTokenProcessor *this)
{
  ; /*0x1037b8f02*/
}

// Address: 0x1037b8f08 | Name: __ZN3RBX4Rupp18RuppTokenProcessorD0Ev
void __fastcall RBX::Rupp::RuppTokenProcessor::~RuppTokenProcessor(RBX::Rupp::RuppTokenProcessor *this)
{
  operator delete(a1: this); /*0x1037b8f0d*/
}

// Address: 0x1037b8f12 | Name: __ZN3RBX4Rupp18RuppTokenProcessor17verify_DEPRECATEDEPKhNS0_21UdmuxTokenContextViewEPj
char RBX::Rupp::RuppTokenProcessor::verify_DEPRECATED()
{
  return 1; /*0x1037b8f18*/
}

// Address: 0x1037b8f1a | Name: __ZN3RBX4Rupp18RuppTokenProcessor6verifyEPKhNS0_21UdmuxTokenContextViewEPjRj
char RBX::Rupp::RuppTokenProcessor::verify()
{
  return 1; /*0x1037b8f20*/
}

// Address: 0x1037b8f22 | Name: __ZN3RBX4Rupp18RuppTokenProcessor19generate_DEPRECATEDEPhNS0_21UdmuxTokenContextViewEjb
char RBX::Rupp::RuppTokenProcessor::generate_DEPRECATED()
{
  return 1; /*0x1037b8f28*/
}

// Address: 0x1037b8f2a | Name: __ZN3RBX4Rupp18RuppTokenProcessor8generateEPhNS0_21UdmuxTokenContextViewEjbRj
char RBX::Rupp::RuppTokenProcessor::generate()
{
  return 1; /*0x1037b8f30*/
}

// Address: 0x1037b8f32 | Name: __ZN3RBX4Rupp18RuppTokenProcessor18getUdmuxTDbgStringEPKctPKh
RBX::Rupp::RuppTokenProcessor *__fastcall RBX::Rupp::RuppTokenProcessor::getUdmuxTDbgString(
        RBX::Rupp::RuppTokenProcessor *this,
        const char *a2,
        unsigned __int16 a3,
        const unsigned __int8 *a4)
{
  *(_OWORD *)this = 0; /*0x1037b8f3c*/
  *((_QWORD *)this + 2) /* +16: NO 2022 FIELD */ = 0; /*0x1037b8f3f*/
  return this; /*0x1037b8f47*/
}

// Address: 0x1037b8f4a | Name: __ZN3RBX4Rupp18RuppTokenProcessor19generateTtDbgStringENS0_21UdmuxTokenContextViewEj
__int64 __fastcall RBX::Rupp::RuppTokenProcessor::generateTtDbgString(__int64 a1)
{
  *(_OWORD *)a1 = 0; /*0x1037b8f54*/
  *(_QWORD *)(a1 + 16) = 0; /*0x1037b8f57*/
  return a1; /*0x1037b8f5f*/
}

// Address: 0x1037b8f62 | Name: __ZN3RBX4Rupp18RuppTokenProcessor15debugGetOptionsEPKh
__int64 __fastcall RBX::Rupp::RuppTokenProcessor::debugGetOptions(
        RBX::Rupp::RuppTokenProcessor *this,
        const unsigned __int8 *a2)
{
  return 0; /*0x1037b8f68*/
}

// Address: 0x1037b8f6a | Name: __ZNK3RBX4Rupp18RuppTokenProcessor8isActiveEv
__int64 __fastcall RBX::Rupp::RuppTokenProcessor::isActive(RBX::Rupp::RuppTokenProcessor *this)
{
  return 0; /*0x1037b8f70*/
}

// Address: 0x1037b8f72 | Name: __ZN3RBX4Rupp18RuppTokenProcessor10isAltTokenEPKh
__int64 __fastcall RBX::Rupp::RuppTokenProcessor::isAltToken(
        RBX::Rupp::RuppTokenProcessor *this,
        const unsigned __int8 *a2)
{
  return 0; /*0x1037b8f78*/
}

// Address: 0x1037b8f7a | Name: __ZNK3RBX4Rupp18RuppTokenProcessor11hasAltTokenEv
__int64 __fastcall RBX::Rupp::RuppTokenProcessor::hasAltToken(RBX::Rupp::RuppTokenProcessor *this)
{
  return 0; /*0x1037b8f80*/
}

// Address: 0x1037b8f82 | Name: __ZNK3RBX4Rupp18RuppTokenProcessor20getAltTokenPreferredEv
__int64 __fastcall RBX::Rupp::RuppTokenProcessor::getAltTokenPreferred(RBX::Rupp::RuppTokenProcessor *this)
{
  return 0; /*0x1037b8f88*/
}

// END RuppTokenProcessor part 1/1, 16 functions
