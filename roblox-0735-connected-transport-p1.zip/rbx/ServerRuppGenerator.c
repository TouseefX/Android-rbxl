// ServerRuppGenerator -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 19 functions


// Address: 0x1037b9062 | Name: __ZN3RBX4Rupp19ServerRuppGeneratorC2ERKNS0_23ServerRuppConfigurationE
__int64 __fastcall RBX::Rupp::ServerRuppGenerator::ServerRuppGenerator(
        RBX::Rupp::ServerRuppGenerator *this,
        const RBX::Rupp::ServerRuppConfiguration *a2)
{
  __int64 v4; // xmm0_8
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // r9
  const char *v9; // r13
  RBX::Rupp::RuppTokenProcessor *v10; // r15
  __int64 v11; // rdi
  _BYTE v13[32]; // [rsp+10h] [rbp-50h] BYREF

  *(_QWORD *)this = off_10C8EC430; /*0x1037b908e*/
  *(_OWORD *)((char *)this + 8) = 0; /*0x1037b9094*/
  *(_OWORD *)((char *)this + 17) = 0; /*0x1037b9098*/
  RBX::Time::nowFast(this); /*0x1037b909c*/
  *((_QWORD *)this + 5) = v4; /*0x1037b90a1*/
  *(_QWORD *)this = off_10C8EC3D0; /*0x1037b90ae*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1037b90ba*/
  {
    std::string::__init_copy_ctor_external(a1: (char *)this + 48, a2: *((_QWORD *)a2 + 2), a3: *((_QWORD *)a2 + 1)); /*0x1037b90da*/
  }
  else
  {
    *((_QWORD *)this + 8) = *((_QWORD *)a2 + 2); /*0x1037b90c0*/
    *((_OWORD *)this + 3) = *(_OWORD *)a2; /*0x1037b90c9*/
  }
  RBX::RbxTransport::Io::EndpointAddr::EndpointAddr( /*0x1037b90ea*/
    this: (RBX::Rupp::ServerRuppGenerator *)((char *)this + 72),
    a2: (const RBX::Rupp::ServerRuppConfiguration *)((char *)a2 + 24));
  RBX::RbxTransport::Io::EndpointAddr::getHostString(this: (RBX::Rupp::ServerRuppGenerator *)((char *)this + 104)); /*0x1037b90fe*/
  *((_BYTE *)this + 128) = 0; /*0x1037b9105*/
  *((_BYTE *)this + 156) = 0; /*0x1037b910c*/
  *((_DWORD *)this + 40) = 0; /*0x1037b9113*/
  RBX::Rupp::Rupp::Rupp(a1: (char *)this + 176, a2: 1, a3: 0); /*0x1037b912f*/
  *((_BYTE *)this + 352) = 9; /*0x1037b9134*/
  *((_QWORD *)this + 45) = 0; /*0x1037b913c*/
  RBX::RbxTransport::Io::EndpointAddr::EndpointAddr(this: (RBX::Rupp::ServerRuppGenerator *)((char *)this + 368)); /*0x1037b9151*/
  *((_OWORD *)this + 25) = 0; /*0x1037b9159*/
  *((_QWORD *)this + 52) = 0; /*0x1037b9161*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1037b9172*/
  {
    if ( *((_QWORD *)a2 + 1) == 0 ) /*0x1037b9182*/
      goto LABEL_11; /*0x1037b9182*/
    v9 = *((const char **)a2 + 2); /*0x1037b9184*/
  }
  else
  {
    if ( *(_BYTE *)a2 == 0 ) /*0x1037b9176*/
      goto LABEL_11; /*0x1037b9176*/
    v9 = (char *)a2 + 1; /*0x1037b9178*/
  }
  v10 = (RBX::Rupp::RuppTokenProcessor *)operator new(a1: 0x10u); /*0x1037b9192*/
  RBX::Rupp::RuppTokenProcessor::RuppTokenProcessor(this: v10, a2: v9); /*0x1037b919b*/
  v11 = *((_QWORD *)this + 45); /*0x1037b91a0*/
  *((_QWORD *)this + 45) = v10; /*0x1037b91a7*/
  if ( v11 != 0 ) /*0x1037b91b1*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v11 + 8LL))(a1: v11); /*0x1037b91b6*/
LABEL_11:
  memset(v13, 0, 17); /*0x1037b91b9*/
  ((void (__fastcall *)(char *, _BYTE *, __int64, __int64, __int64, __int64, char *, char *))RBX::Rupp::Rupp::addTokenTlv)( /*0x1037b91ca*/
    a1: (char *)this + 176,
    a2: v13,
    a3: v5,
    a4: v6,
    a5: v7,
    a6: v8,
    a7: (char *)this + 48,
    a8: (char *)this + 104);
  return __stack_chk_guard; /*0x1037b91df*/
}

// Address: 0x1037b92a6 | Name: __ZN3RBX4Rupp19ServerRuppGeneratorC1ERKNS0_23ServerRuppConfigurationE
__int64 __fastcall RBX::Rupp::ServerRuppGenerator::ServerRuppGenerator(
        RBX::Rupp::ServerRuppGenerator *this,
        const RBX::Rupp::ServerRuppConfiguration *a2)
{
  return RBX::Rupp::ServerRuppGenerator::ServerRuppGenerator(this, a2); /*0x1037b92aa*/
}

// Address: 0x1037b92b0 | Name: __ZN3RBX4Rupp19ServerRuppGenerator12setLocalAddrERKNS_12RbxTransport2Io12EndpointAddrE
__int64 __fastcall RBX::Rupp::ServerRuppGenerator::setLocalAddr(
        RBX::Rupp::ServerRuppGenerator *this,
        const RBX::RbxTransport::Io::EndpointAddr *a2)
{
  return std::optional<RBX::RbxTransport::Io::EndpointAddr>::operator=[abi:ne200100]<RBX::RbxTransport::Io::EndpointAddr const&,void>(this: (RBX::Rupp::ServerRuppGenerator *)((char *)this + 128)); /*0x1037b92b8*/
}

// Address: 0x1037b92be | Name: __ZN3RBX4Rupp19ServerRuppGenerator3getEv
__int64 __fastcall RBX::Rupp::ServerRuppGenerator::get(RBX::Rupp::ServerRuppGenerator *this)
{
  return (__int64)this + 176; /*0x1037b92c9*/
}

// Address: 0x1037b92cc | Name: __ZN3RBX4Rupp19ServerRuppGenerator20onPeerPacketReceivedERKNS0_21DeserializationResultERKNS_12RbxTransport2Io12EndpointAddrEy
__int64 RBX::Rupp::ServerRuppGenerator::onPeerPacketReceived()
{
  return 12; /*0x1037b92d5*/
}

// Address: 0x1037b92d8 | Name: __ZN3RBX4Rupp19ServerRuppGenerator14updatePeerAddrERKNS_12RbxTransport2Io12EndpointAddrE
__int64 __fastcall RBX::Rupp::ServerRuppGenerator::updatePeerAddr(
        void **this,
        const RBX::RbxTransport::Io::EndpointAddr *a2)
{
  int v4; // r15d
  int v5; // r12d
  unsigned __int8 v7[16]; // [rsp+8h] [rbp-58h] BYREF
  void *v8; // [rsp+18h] [rbp-48h]
  __int128 v9; // [rsp+20h] [rbp-40h] BYREF
  void *v10; // [rsp+30h] [rbp-30h]

  v4 = DFLog::ServerRuppGenerator; /*0x1037b92ef*/
  if ( (unsigned __int8)DFLog::ServerRuppGenerator >= 6u && BYTE1(DFLog::ServerRuppGenerator) >= 5u ) /*0x1037b9305*/
  {
    v5 = qword_10D7B4920; /*0x1037b930c*/
    RBX::RbxTransport::Io::EndpointAddr::toString(this: (RBX::RbxTransport::Io::EndpointAddr *)&v9); /*0x1037b931e*/
    RBX::RbxTransport::Io::EndpointAddr::toString(this: (RBX::RbxTransport::Io::EndpointAddr *)v7); /*0x1037b932d*/
    FLog::FastLogSafeFormatted<std::string,std::string>( /*0x1037b9352*/
      a1: v4,
      a2: v5,
      a3: 5,
      a4: (int)"[DFLog::ServerRuppGenerator] Updating peer from {} to {}",
      a5: 56,
      a6: (unsigned __int8 *)&v9,
      a7: v7);
    if ( (v7[0] & 1) != 0 ) /*0x1037b935b*/
      operator delete(a1: v8); /*0x1037b9361*/
    if ( (v9 & 1) != 0 ) /*0x1037b936a*/
      operator delete(a1: v10); /*0x1037b9370*/
  }
  RBX::RbxTransport::Io::EndpointAddr::operator=(a1: this + 46, a2); /*0x1037b9382*/
  RBX::RbxTransport::Io::EndpointAddr::getHostAsIpv6Str(this: (RBX::RbxTransport::Io::EndpointAddr *)&v9); /*0x1037b938e*/
  if ( (*(_BYTE *)(this + 50) & 1) != 0 ) /*0x1037b93a1*/
    operator delete(a1: *(this + 52)); /*0x1037b93aa*/
  *(this + 52) = v10; /*0x1037b93b3*/
  *((_OWORD *)this + 25) = v9; /*0x1037b93bb*/
  return RBX::Rupp::Rupp::requestImmediateTokenRegeneration(this: (RBX::Rupp::Rupp *)(this + 22)); /*0x1037b93ce*/
}

// Address: 0x1037b940c | Name: __ZN3RBX4Rupp19ServerRuppGenerator24generateGameServiceTokenEv
RBX::Rupp::ServerRuppGenerator *__fastcall RBX::Rupp::ServerRuppGenerator::generateGameServiceToken(
        RBX::Rupp::ServerRuppGenerator *this,
        RBX::Rupp::ServerRuppGenerator *a2)
{
  char v3; // al
  unsigned __int8 v5[17]; // [rsp+Fh] [rbp-21h] BYREF

  *(_OWORD *)&v5[1] = 0; /*0x1037b9430*/
  v5[0] = 1; /*0x1037b9433*/
  if ( (unsigned __int8)RBX::Rupp::ServerRuppGenerator::generateTokenValue(this: a2, a2: &v5[1], a3: "", a4: 0) != 0 ) /*0x1037b944a*/
  {
    qmemcpy(this, v5, 17); /*0x1037b944f*/
    v3 = 1; /*0x1037b9459*/
  }
  else
  {
    *(_BYTE *)this = 0; /*0x1037b945d*/
    v3 = 0; /*0x1037b9460*/
  }
  *((_BYTE *)this + 17) = v3; /*0x1037b9462*/
  return this; /*0x1037b9478*/
}

// Address: 0x1037b9484 | Name: __ZN3RBX4Rupp19ServerRuppGenerator28generateGameServiceTokenPrivERNS0_8TokenTlv5TokenE
__int64 __fastcall RBX::Rupp::ServerRuppGenerator::generateGameServiceTokenPriv(
        RBX::Rupp::ServerRuppGenerator *a1,
        _BYTE *a2)
{
  *a2 = 1; /*0x1037b9488*/
  return RBX::Rupp::ServerRuppGenerator::generateTokenValue(this: a1, a2: a2 + 1, a3: "", a4: 0); /*0x1037b9497*/
}

// Address: 0x1037b949e | Name: __ZN3RBX4Rupp19ServerRuppGenerator4initERKNS0_21DeserializationResultERKNS_12RbxTransport2Io12EndpointAddrE
__int64 __fastcall RBX::Rupp::ServerRuppGenerator::init(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v5; // rax
  __int64 result; // rax
  __int128 v7; // [rsp+8h] [rbp-78h] BYREF
  __int64 v8; // [rsp+18h] [rbp-68h]
  _QWORD v9[4]; // [rsp+20h] [rbp-60h] BYREF
  _QWORD *v10; // [rsp+40h] [rbp-40h]

  if ( *(_QWORD *)(a1 + 360) == 0 ) /*0x1037b94c3*/
    return 12; /*0x1037b955e*/
  RBX::RbxTransport::Io::EndpointAddr::operator=(a1: a1 + 368, a2: a3); /*0x1037b94dc*/
  RBX::RbxTransport::Io::EndpointAddr::getHostAsIpv6Str(this: (RBX::RbxTransport::Io::EndpointAddr *)&v7); /*0x1037b94e8*/
  if ( (*(_BYTE *)(a1 + 400) & 1) != 0 ) /*0x1037b94fb*/
    operator delete(a1: *(void **)(a1 + 416)); /*0x1037b9504*/
  *(_QWORD *)(a1 + 416) = v8; /*0x1037b950d*/
  *(_OWORD *)(a1 + 400) = v7; /*0x1037b9515*/
  v9[0] = off_10C8EC468; /*0x1037b952b*/
  v9[1] = a1; /*0x1037b952f*/
  v10 = v9; /*0x1037b9534*/
  RBX::Rupp::Rupp::addTokenGenerator(a1: a1 + 176, a2: v9); /*0x1037b953f*/
  if ( v10 == v9 ) /*0x1037b954b*/
  {
    v5 = 32; /*0x1037b9560*/
  }
  else
  {
    v5 = 40; /*0x1037b954d*/
    if ( v10 == nullptr ) /*0x1037b9555*/
      goto LABEL_10; /*0x1037b9555*/
  }
  (*(void (**)(void))(*v10 + v5))(); /*0x1037b9568*/
LABEL_10:
  *(_DWORD *)(a1 + 160) = RBX::Rupp::ServerRuppGenerator::calcTokenOptions( /*0x1037b956b*/
                            a1,
                            a2: *(_QWORD *)(a2 + 8),
                            a3: *(_QWORD *)(a2 + 16));
  if ( (*(_BYTE *)(a2 + 3) & 1) == 0 /*0x1037b959e*/
    || (_DWORD)(result = RBX::Rupp::Rupp::addIpv4ReverseEndpointTlv(
                           this: (RBX::Rupp::Rupp *)(a1 + 176),
                           a2: (const char *)(a2 + 24),
                           a3: *(_WORD *)(a2 + 70))) == 0 )
  {
    result = 0; /*0x1037b95a7*/
    if ( DFFlag::RuppTokenOneBeeRcc == 0 ) /*0x1037b95ac*/
      *(_BYTE *)(a1 + 352) = 9; /*0x1037b95ae*/
  }
  return result; /*0x1037b95c5*/
}

// Address: 0x1037b9606 | Name: __ZN3RBX4Rupp19ServerRuppGenerator16calcTokenOptionsENS_9ArrayViewIhEE
__int64 __fastcall RBX::Rupp::ServerRuppGenerator::calcTokenOptions(__int64 a1, unsigned __int8 *a2, __int64 a3)
{
  __int64 v5; // r15
  __int16 Port; // ax
  __int64 v8; // rcx
  __int64 v9; // r8
  __int64 v10; // r9
  const unsigned __int8 *v11; // rsi
  unsigned __int8 v12; // r15
  unsigned int v13; // r12d
  unsigned __int8 isAltToken; // al
  _DWORD v15[11]; // [rsp+4Ch] [rbp-2Ch] BYREF

  if ( *(_QWORD *)(a1 + 360) == 0 ) /*0x1037b960e*/
    return 0; /*0x1037b963b*/
  if ( a3 == 16 ) /*0x1037b9626*/
  {
    if ( (*(_BYTE *)(a1 + 104) & 1) != 0 ) /*0x1037b9633*/
      v5 = *(_QWORD *)(a1 + 120); /*0x1037b963e*/
    else
      v5 = a1 + 105; /*0x1037b9635*/
    Port = RBX::RbxTransport::Io::EndpointAddr::getPort(this: (RBX::RbxTransport::Io::EndpointAddr *)(a1 + 72)); /*0x1037b9646*/
    if ( DFFlag::RuppTokenAlgoTelemetry == 1 ) /*0x1037b9652*/
    {
      v15[0] = 0; /*0x1037b965c*/
      v12 = (*(__int64 (__fastcall **)(_QWORD, unsigned __int8 *, __int64, _DWORD *, __int64, __int64, __int64, __int16, _QWORD, _WORD))(**(_QWORD **)(a1 + 360) + 24LL))( /*0x1037b96a0*/
              a1: *(_QWORD *)(a1 + 360),
              a2,
              a3: a1 + 160,
              a4: v15,
              a5: v9,
              a6: v10,
              a7: v5,
              a8: Port,
              a9: 0,
              a10: 0);
      if ( v12 == 0 ) /*0x1037b96a5*/
        *(_DWORD *)(a1 + 160) = RBX::Rupp::RuppTokenProcessor::debugGetOptions( /*0x1037b96b6*/
                                  this: *(RBX::Rupp::RuppTokenProcessor **)(a1 + 360),
                                  a2);
      v13 = v15[0]; /*0x1037b96bc*/
      isAltToken = RBX::Rupp::RuppTokenProcessor::isAltToken(this: (RBX::Rupp::RuppTokenProcessor *)a2, a2: v11); /*0x1037b96c3*/
      RBX::Rupp::reportRuppTokenAlgo(a1: 0, a2: v13, a3: isAltToken, a4: v12, a5: 1); /*0x1037b96da*/
    }
    else if ( (*(unsigned __int8 (__fastcall **)(_QWORD, unsigned __int8 *, __int64, __int64, __int64, __int64, __int64, __int16, _QWORD, _WORD))(**(_QWORD **)(a1 + 360) + 16LL))( /*0x1037b9721*/
                a1: *(_QWORD *)(a1 + 360),
                a2,
                a3: a1 + 160,
                a4: v8,
                a5: v9,
                a6: v10,
                a7: v5,
                a8: Port,
                a9: 0,
                a10: 0) == 0 )
    {
      *(_DWORD *)(a1 + 160) = RBX::Rupp::RuppTokenProcessor::debugGetOptions( /*0x1037b9732*/
                                this: *(RBX::Rupp::RuppTokenProcessor **)(a1 + 360),
                                a2);
    }
  }
  return *(unsigned int *)(a1 + 160); /*0x1037b963d*/
}

// Address: 0x1037b974c | Name: __ZN3RBX4Rupp19ServerRuppGenerator22selectRuppTokenLineageEPKh
__int64 __fastcall RBX::Rupp::ServerRuppGenerator::selectRuppTokenLineage(
        RBX::Rupp::ServerRuppGenerator *this,
        RBX::Rupp::RuppTokenProcessor *a2)
{
  __int64 result; // rax

  LOBYTE(result) = 9; /*0x1037b9753*/
  if ( DFFlag::RuppTokenOneBeeRcc == 1 ) /*0x1037b9758*/
    LOBYTE(result) = RBX::Rupp::RuppTokenProcessor::isAltToken(this: a2, (const unsigned __int8 *)a2) + 9; /*0x1037b9766*/
  return (unsigned __int8)result; /*0x1037b976c*/
}

// Address: 0x1037b976e | Name: __ZN3RBX4Rupp19ServerRuppGenerator14buildProbeRuppERKNS0_21DeserializationResultERKNS_12RbxTransport2Io12EndpointAddrERKNS_7Guid128E
RBX::Rupp::Rupp *__fastcall RBX::Rupp::ServerRuppGenerator::buildProbeRupp(
        RBX::Rupp::Rupp *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        const __m128i *a5)
{
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // r8
  __int64 v13; // r9
  __int64 v14; // rdx
  __int64 v15; // rcx
  __int64 v16; // r8
  __int64 v17; // r9
  __m128i v18; // xmm0
  __m128i v19; // xmm0
  __m128i v21; // [rsp+10h] [rbp-70h] BYREF
  __int64 v22; // [rsp+20h] [rbp-60h]
  unsigned __int8 v23[16]; // [rsp+30h] [rbp-50h] BYREF
  char v24; // [rsp+40h] [rbp-40h]

  RBX::Rupp::Rupp::Rupp(a1: this, a2: 4, a3: 0); /*0x1037b97a3*/
  *(_OWORD *)v23 = 0; /*0x1037b97ac*/
  v24 = 0; /*0x1037b97b1*/
  if ( *(_QWORD *)(a2 + 360) != 0 ) /*0x1037b97be*/
  {
    RBX::RbxTransport::Io::EndpointAddr::operator=(a1: a2 + 368, a2: a4); /*0x1037b97d6*/
    RBX::RbxTransport::Io::EndpointAddr::getHostAsIpv6Str(this: (RBX::RbxTransport::Io::EndpointAddr *)&v21); /*0x1037b97e2*/
    if ( (*(_BYTE *)(a2 + 400) & 1) != 0 ) /*0x1037b97f8*/
      operator delete(a1: *(void **)(a2 + 416)); /*0x1037b9802*/
    *(_QWORD *)(a2 + 416) = v22; /*0x1037b980b*/
    *(__m128i *)(a2 + 400) = _mm_loadu_si128(&v21); /*0x1037b9814*/
    *(_DWORD *)(a2 + 160) = RBX::Rupp::ServerRuppGenerator::calcTokenOptions( /*0x1037b9829*/
                              a1: a2,
                              a2: *(unsigned __int8 **)(a3 + 8),
                              a3: *(_QWORD *)(a3 + 16));
    if ( DFFlag::RuppTokenOneBeeRcc == 0 ) /*0x1037b983b*/
      *(_BYTE *)(a2 + 352) = 9; /*0x1037b983d*/
    if ( DFFlag::RbxTransportDeprecateGenerateRccToken == 1 ) /*0x1037b984d*/
    {
      if ( (unsigned __int8)RBX::Rupp::ServerRuppGenerator::generateRccTokenPriv(this: (RBX::Rupp::ServerRuppGenerator *)a2) == 0 ) /*0x1037b985d*/
        v23[0] = 0; /*0x1037b985f*/
    }
    else
    {
      v23[0] = 2; /*0x1037b98b2*/
      RBX::Rupp::ServerRuppGenerator::generateUdmuxToken_DEPRECATED( /*0x1037b98b9*/
        this: (RBX::Rupp::ServerRuppGenerator *)a2,
        a2: &v23[1]);
    }
    RBX::Rupp::Rupp::addTokenTlv(a1: this, a2: v23, a3: v14, a4: v15, a5: v16, a6: v17); /*0x1037b98c5*/
    if ( (*(_BYTE *)(a3 + 3) & 1) != 0 ) /*0x1037b98d3*/
      RBX::Rupp::Rupp::addIpv4ReverseEndpointTlv(this, a2: (const char *)(a3 + 24), a3: *(_WORD *)(a3 + 70)); /*0x1037b98e4*/
    v21 = 0; /*0x1037b98ed*/
    v19 = _mm_loadu_si128(a5); /*0x1037b98f2*/
    if ( !_mm_testz_si128(v19, v19) ) /*0x1037b98fc*/
      RBX::Rupp::Rupp::addTraceIdTlv(a1: this, a2: a5); /*0x1037b9904*/
  }
  else
  {
    RBX::Rupp::Rupp::addTokenTlv(a1: this, a2: v23, a3: v10, a4: v11, a5: v12, a6: v13); /*0x1037b986c*/
    if ( (*(_BYTE *)(a3 + 3) & 1) != 0 ) /*0x1037b9876*/
      RBX::Rupp::Rupp::addIpv4ReverseEndpointTlv(this, a2: (const char *)(a3 + 24), a3: *(_WORD *)(a3 + 70)); /*0x1037b9887*/
    v21 = 0; /*0x1037b9890*/
    v18 = _mm_loadu_si128(a5); /*0x1037b9895*/
    if ( !_mm_testz_si128(v18, v18) ) /*0x1037b989f*/
      RBX::Rupp::Rupp::addTraceIdTlv(a1: this, a2: a5); /*0x1037b98a7*/
  }
  return this; /*0x1037b991c*/
}

// Address: 0x1037b9952 | Name: __ZN3RBX4Rupp19ServerRuppGenerator20generateRccTokenPrivERNS0_8TokenTlv5TokenE
__int64 __fastcall RBX::Rupp::ServerRuppGenerator::generateRccTokenPriv(
        RBX::Rupp::ServerRuppGenerator *this,
        _BYTE *a2)
{
  const char *v3; // r15
  unsigned __int8 *v4; // rbx
  unsigned __int16 Port; // ax

  *a2 = 2; /*0x1037b9962*/
  if ( (*((_BYTE *)this + 400) & 1) != 0 ) /*0x1037b996c*/
    v3 = *((const char **)this + 52); /*0x1037b9977*/
  else
    v3 = (char *)this + 401; /*0x1037b996e*/
  v4 = a2 + 1; /*0x1037b997e*/
  Port = RBX::RbxTransport::Io::EndpointAddr::getPort(this: (RBX::Rupp::ServerRuppGenerator *)((char *)this + 368)); /*0x1037b9988*/
  return RBX::Rupp::ServerRuppGenerator::generateTokenValue(this, a2: v4, a3: v3, a4: Port); /*0x1037b999d*/
}

// Address: 0x1037b99a8 | Name: __ZN3RBX4Rupp19ServerRuppGenerator29generateUdmuxToken_DEPRECATEDEPh
void __fastcall RBX::Rupp::ServerRuppGenerator::generateUdmuxToken_DEPRECATED(
        RBX::Rupp::ServerRuppGenerator *this,
        unsigned __int8 *a2)
{
  RBX::Rupp::RuppTokenProcessor *v3; // rdi
  int AltTokenPreferred; // eax
  char *v6; // r15
  RBX::RbxTransport::Io::EndpointAddr *v7; // rdi
  __int16 Port; // r12
  char *v9; // rbx
  __int16 v10; // ax
  __int64 v11; // r8
  __int64 v12; // r9
  __int64 v13; // rdi
  __int64 v14; // rdx
  unsigned int v15; // r14d
  __int64 v16; // rdi
  unsigned int v17; // [rsp+2Ch] [rbp-54h] BYREF
  char *v18; // [rsp+30h] [rbp-50h]
  __int64 v19; // [rsp+38h] [rbp-48h]
  char *v20; // [rsp+40h] [rbp-40h]
  __int64 v21; // [rsp+48h] [rbp-38h]
  int v22; // [rsp+54h] [rbp-2Ch]

  v3 = *((RBX::Rupp::RuppTokenProcessor **)this + 45); /*0x1037b99bc*/
  if ( v3 == nullptr ) /*0x1037b99c6*/
    return; /*0x1037b99c6*/
  AltTokenPreferred = *((unsigned __int8 *)this + 352); /*0x1037b99cf*/
  if ( (unsigned int)(AltTokenPreferred - 9) >= 2 ) /*0x1037b99dd*/
  {
    if ( AltTokenPreferred != 6 ) /*0x1037b99e9*/
    {
      v22 = 0; /*0x1037b99f2*/
      goto LABEL_8; /*0x1037b99f2*/
    }
    LOBYTE(AltTokenPreferred) = 1; /*0x1037b99eb*/
  }
  else
  {
    AltTokenPreferred = RBX::Rupp::RuppTokenProcessor::getAltTokenPreferred(this: v3); /*0x1037b99df*/
  }
  v22 = AltTokenPreferred; /*0x1037b99ed*/
LABEL_8:
  if ( (*((_BYTE *)this + 104) & 1) != 0 ) /*0x1037b99fe*/
    v6 = *((char **)this + 15); /*0x1037b9a06*/
  else
    v6 = (char *)this + 105; /*0x1037b9a00*/
  v7 = (RBX::Rupp::ServerRuppGenerator *)((char *)this + 72); /*0x1037b9a0a*/
  if ( *((_BYTE *)this + 156) != 0 ) /*0x1037b9a1d*/
    v7 = (RBX::Rupp::ServerRuppGenerator *)((char *)this + 128); /*0x1037b9a1d*/
  Port = RBX::RbxTransport::Io::EndpointAddr::getPort(this: v7); /*0x1037b9a26*/
  if ( (*((_BYTE *)this + 400) & 1) != 0 ) /*0x1037b9a31*/
    v9 = *((char **)this + 52); /*0x1037b9a3c*/
  else
    v9 = (char *)this + 401; /*0x1037b9a33*/
  v10 = RBX::RbxTransport::Io::EndpointAddr::getPort(this: (RBX::Rupp::ServerRuppGenerator *)((char *)this + 368)); /*0x1037b9a4a*/
  if ( DFFlag::RuppTokenAlgoTelemetry == 1 ) /*0x1037b9a56*/
  {
    v17 = 0; /*0x1037b9a5f*/
    v13 = *((_QWORD *)this + 45); /*0x1037b9a67*/
    v18 = v6; /*0x1037b9a6e*/
    LOWORD(v19) = Port; /*0x1037b9a72*/
    v20 = v9; /*0x1037b9a77*/
    LOWORD(v21) = v10; /*0x1037b9a7b*/
    v14 = *((unsigned int *)this + 40); /*0x1037b9a7f*/
    v15 = (unsigned __int8)v22; /*0x1037b9a9a*/
    (*(void (__fastcall **)(__int64, unsigned __int8 *, __int64, _QWORD, unsigned int *, __int64, char *, __int64, char *, __int64))(*(_QWORD *)v13 + 40LL))( /*0x1037b9aa5*/
      a1: v13,
      a2,
      a3: v14,
      a4: (unsigned __int8)v22,
      a5: &v17,
      a6: v12,
      a7: v6,
      a8: v19,
      a9: v9,
      a10: v21);
    RBX::Rupp::reportRuppTokenAlgo(a1: 1, a2: v17, a3: v15, a4: 1, a5: 1); /*0x1037b9abf*/
  }
  else
  {
    v16 = *((_QWORD *)this + 45); /*0x1037b9ac6*/
    LOWORD(v19) = Port; /*0x1037b9ad1*/
    LOWORD(v21) = v10; /*0x1037b9ada*/
    (*(void (__fastcall **)(__int64, unsigned __int8 *, _QWORD, _QWORD, __int64, __int64, char *, __int64, char *, __int64))(*(_QWORD *)v16 + 32LL))( /*0x1037b9b00*/
      a1: v16,
      a2,
      a3: *((unsigned int *)this + 40),
      a4: (unsigned __int8)v22,
      a5: v11,
      a6: v12,
      a7: v6,
      a8: v19,
      a9: v9,
      a10: v21);
  }
}

// Address: 0x1037b9b12 | Name: __ZN3RBX4Rupp19ServerRuppGenerator27generateRccToken_DEPRECATEDERNS0_8TokenTlv5TokenE
void __fastcall RBX::Rupp::ServerRuppGenerator::generateRccToken_DEPRECATED(
        RBX::Rupp::ServerRuppGenerator *a1,
        _BYTE *a2)
{
  *a2 = 2; /*0x1037b9b16*/
  RBX::Rupp::ServerRuppGenerator::generateUdmuxToken_DEPRECATED(this: a1, a2: a2 + 1); /*0x1037b9b1d*/
}

// Address: 0x1037b9b22 | Name: __ZN3RBX4Rupp19ServerRuppGenerator18generateTokenValueEPhPKct
__int64 __fastcall RBX::Rupp::ServerRuppGenerator::generateTokenValue(
        RBX::Rupp::ServerRuppGenerator *this,
        unsigned __int8 *a2,
        const char *a3,
        __int16 a4)
{
  RBX::Rupp::RuppTokenProcessor *v5; // rdi
  int AltTokenPreferred; // eax
  unsigned int v10; // ebx
  char *v11; // r13
  RBX::RbxTransport::Io::EndpointAddr *v12; // rdi
  __int16 Port; // ax
  __int64 v14; // r8
  __int64 v15; // r9
  __int64 v16; // rdi
  unsigned int v17; // r14d
  __int64 v19; // rdi
  unsigned int v20; // [rsp+2Ch] [rbp-54h] BYREF
  char *v21; // [rsp+30h] [rbp-50h]
  __int64 v22; // [rsp+38h] [rbp-48h]
  const char *v23; // [rsp+40h] [rbp-40h]
  __int64 v24; // [rsp+48h] [rbp-38h]
  int v25; // [rsp+54h] [rbp-2Ch]

  v5 = *((RBX::Rupp::RuppTokenProcessor **)this + 45); /*0x1037b9b36*/
  if ( v5 == nullptr ) /*0x1037b9b40*/
    return 0; /*0x1037b9c20*/
  AltTokenPreferred = *((unsigned __int8 *)this + 352); /*0x1037b9b4b*/
  if ( (unsigned int)(AltTokenPreferred - 9) < 2 ) /*0x1037b9b59*/
  {
    AltTokenPreferred = RBX::Rupp::RuppTokenProcessor::getAltTokenPreferred(this: v5); /*0x1037b9b5b*/
LABEL_7:
    v25 = AltTokenPreferred; /*0x1037b9b70*/
    goto LABEL_9; /*0x1037b9b73*/
  }
  if ( AltTokenPreferred == 6 ) /*0x1037b9b6c*/
  {
    LOBYTE(AltTokenPreferred) = 1; /*0x1037b9b6e*/
    goto LABEL_7; /*0x1037b9b6e*/
  }
  v25 = 0; /*0x1037b9b75*/
LABEL_9:
  if ( (*((_BYTE *)this + 104) & 1) != 0 ) /*0x1037b9b81*/
    v11 = *((char **)this + 15); /*0x1037b9b89*/
  else
    v11 = (char *)this + 105; /*0x1037b9b83*/
  v12 = (RBX::Rupp::ServerRuppGenerator *)((char *)this + 72); /*0x1037b9b8d*/
  if ( *((_BYTE *)this + 156) != 0 ) /*0x1037b9ba0*/
    v12 = (RBX::Rupp::ServerRuppGenerator *)((char *)this + 128); /*0x1037b9ba0*/
  Port = RBX::RbxTransport::Io::EndpointAddr::getPort(this: v12); /*0x1037b9ba4*/
  if ( DFFlag::RuppTokenAlgoTelemetry == 1 ) /*0x1037b9bb0*/
  {
    v20 = 0; /*0x1037b9bb6*/
    v16 = *((_QWORD *)this + 45); /*0x1037b9bbf*/
    v21 = v11; /*0x1037b9bc6*/
    LOWORD(v22) = Port; /*0x1037b9bca*/
    v23 = a3; /*0x1037b9bce*/
    LOWORD(v24) = a4; /*0x1037b9bd2*/
    v17 = (unsigned __int8)v25; /*0x1037b9bf2*/
    v10 = (*(__int64 (__fastcall **)(__int64, unsigned __int8 *, _QWORD, _QWORD, unsigned int *, __int64, char *, __int64, const char *, __int64))(*(_QWORD *)v16 + 40LL))( /*0x1037b9c03*/
            a1: v16,
            a2,
            a3: *((unsigned int *)this + 40),
            a4: (unsigned __int8)v25,
            a5: &v20,
            a6: v15,
            a7: v11,
            a8: v22,
            a9: a3,
            a10: v24);
    RBX::Rupp::reportRuppTokenAlgo(a1: 1, a2: v20, a3: v17, a4: (unsigned __int8)v10, a5: 1); /*0x1037b9c19*/
    return v10; /*0x1037b9c19*/
  }
  v19 = *((_QWORD *)this + 45); /*0x1037b9c22*/
  LOWORD(v22) = Port; /*0x1037b9c2d*/
  LOWORD(v24) = a4; /*0x1037b9c35*/
  return (*(__int64 (__fastcall **)(__int64, unsigned __int8 *, _QWORD, _QWORD, __int64, __int64, char *, __int64, const char *, __int64))(*(_QWORD *)v19 + 32LL))( /*0x1037b9c5f*/
           a1: v19,
           a2,
           a3: *((unsigned int *)this + 40),
           a4: (unsigned __int8)v25,
           a5: v14,
           a6: v15,
           a7: v11,
           a8: v22,
           a9: a3,
           a10: v24);
}

// Address: 0x1037b9c6e | Name: __ZN3RBX4Rupp19ServerRuppGeneratorD1Ev
void __fastcall RBX::Rupp::ServerRuppGenerator::~ServerRuppGenerator(RBX::Rupp::ServerRuppGenerator *this)
{
  RBX::Rupp::ServerRuppGenerator::~ServerRuppGenerator(this); /*0x1037b9c73*/
}

// Address: 0x1037b9c78 | Name: __ZN3RBX4Rupp19ServerRuppGeneratorD0Ev
void __fastcall RBX::Rupp::ServerRuppGenerator::~ServerRuppGenerator(RBX::Rupp::ServerRuppGenerator *this)
{
  RBX::Rupp::ServerRuppGenerator::~ServerRuppGenerator(this); /*0x1037b9c81*/
  operator delete(a1: this); /*0x1037b9c8f*/
}

// Address: 0x1037b9c94 | Name: __ZN3RBX4Rupp19ServerRuppGeneratorD2Ev
void __fastcall RBX::Rupp::ServerRuppGenerator::~ServerRuppGenerator(void **this)
{
  char *v1; // rax
  __int64 v3; // rdi
  void **v4; // rdi
  RBX::Rupp::ServerRuppGenerator *v5; // rdi
  __int64 v6; // rax
  char *v7; // [rsp+0h] [rbp-10h] BYREF

  v7 = v1; /*0x1037b9c99*/
  *this = off_10C8EC3D0; /*0x1037b9ca4*/
  if ( (*(_BYTE *)(this + 50) & 1) != 0 ) /*0x1037b9cae*/
    operator delete(a1: *(this + 52)); /*0x1037b9cb7*/
  RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)(this + 46)); /*0x1037b9cc3*/
  v3 = (__int64)*(this + 45); /*0x1037b9cc8*/
  *(this + 45) = nullptr; /*0x1037b9ccf*/
  if ( v3 != 0 ) /*0x1037b9cdd*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 8LL))(a1: v3); /*0x1037b9ce2*/
  v4 = (void **)*(this + 36); /*0x1037b9ce5*/
  if ( v4 != this + 39 ) /*0x1037b9cf6*/
    operator delete(a1: v4); /*0x1037b9cf8*/
  v7 = (char *)(this + 33); /*0x1037b9d08*/
  std::vector<std::unique_ptr<RBX::Rupp::TypeLengthValue>>::__destroy_vector::operator()[abi:ne200100](a1: &v7); /*0x1037b9d0b*/
  v5 = (RBX::Rupp::ServerRuppGenerator *)*(this + 28); /*0x1037b9d17*/
  if ( v5 == (RBX::Rupp::ServerRuppGenerator *)(this + 24) ) /*0x1037b9d21*/
  {
    v6 = 32; /*0x1037b9d2f*/
    goto LABEL_11; /*0x1037b9d2f*/
  }
  v6 = 40; /*0x1037b9d23*/
  if ( v5 != nullptr ) /*0x1037b9d2b*/
LABEL_11:
    (*(void (**)(void))(*(_QWORD *)v5 + v6))(); /*0x1037b9d34*/
  if ( *((_BYTE *)this + 156) == 1 ) /*0x1037b9d41*/
    RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)(this + 16)); /*0x1037b9d4a*/
  if ( (*(_BYTE *)(this + 13) & 1) != 0 ) /*0x1037b9d53*/
    operator delete(a1: *(this + 15)); /*0x1037b9d59*/
  RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)(this + 9)); /*0x1037b9d62*/
  if ( (*(_BYTE *)(this + 6) & 1) != 0 ) /*0x1037b9d6b*/
    operator delete(a1: *(this + 8)); /*0x1037b9d71*/
}

// END ServerRuppGenerator part 1/1, 19 functions
