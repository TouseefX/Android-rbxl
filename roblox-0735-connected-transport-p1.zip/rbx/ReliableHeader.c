// ReliableHeader -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 5 functions


// Address: 0x10376cb5e | Name: __ZN3RBX12RbxTransport8Protocol14ReliableHeaderC2Ey
void __fastcall RBX::RbxTransport::Protocol::ReliableHeader::ReliableHeader(
        RBX::RbxTransport::Protocol::ReliableHeader *this,
        __int64 a2)
{
  *(_QWORD *)this = a2; /*0x10376cb62*/
}

// Address: 0x10376cb68 | Name: __ZN3RBX12RbxTransport8Protocol14ReliableHeaderC1Ey
void __fastcall RBX::RbxTransport::Protocol::ReliableHeader::ReliableHeader(
        RBX::RbxTransport::Protocol::ReliableHeader *this,
        __int64 a2)
{
  *(_QWORD *)this = a2; /*0x10376cb6c*/
}

// Address: 0x10376cb72 | Name: __ZN3RBX12RbxTransport8Protocol14ReliableHeader14serializedSizeEy
__int64 __fastcall RBX::RbxTransport::Protocol::ReliableHeader::serializedSize(
        RBX::RbxTransport::Protocol::ReliableHeader *this,
        unsigned __int64 a2)
{
  return RBX::RbxTransport::QuicVarInt::varIntMinSize(this, a2); /*0x10376cb76*/
}

// Address: 0x10376cb7c | Name: __ZNK3RBX12RbxTransport8Protocol14ReliableHeader9serializeENS_16MutableArrayViewIhEE
__int64 __fastcall RBX::RbxTransport::Protocol::ReliableHeader::serialize(_QWORD *a1)
{
  return RBX::RbxTransport::QuicVarInt::writeNetOrderVarInt(a1: *a1); /*0x10376cb83*/
}

// Address: 0x10376cb8a | Name: __ZN3RBX12RbxTransport8Protocol14ReliableHeader5parseENS_9ArrayViewIhEERm
__int64 __fastcall RBX::RbxTransport::Protocol::ReliableHeader::parse(void *a1, __int64 a2, __int64 *a3)
{
  __int64 result; // rax

  result = RBX::RbxTransport::QuicVarInt::readNetOrderVarInt(__src: a1); /*0x10376cb9e*/
  *a3 = result; /*0x10376cba3*/
  if ( result != 0 ) /*0x10376cbac*/
    return 0; /*0x10376cbae*/
  return result; /*0x10376cbb6*/
}

// END ReliableHeader part 1/1, 5 functions
