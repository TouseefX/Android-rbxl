// TraceIdTlv -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 8 functions


// Address: 0x1037ba452 | Name: __ZN3RBX4Rupp10TraceIdTlvC2ERKNS_7Guid128E
void (__fastcall **__fastcall RBX::Rupp::TraceIdTlv::TraceIdTlv(
        __int64 a1,
        _OWORD *a2))(RBX::Rupp::TraceIdTlv *__hidden this)
{
  *(_QWORD *)a1 = off_10C8EC600; /*0x1037ba45d*/
  *(_OWORD *)(a1 + 8) = *a2; /*0x1037ba463*/
  return off_10C8EC600; /*0x1037ba467*/
}

// Address: 0x1037ba46a | Name: __ZN3RBX4Rupp10TraceIdTlvC1ERKNS_7Guid128E
void (__fastcall **__fastcall RBX::Rupp::TraceIdTlv::TraceIdTlv(
        __int64 a1,
        _OWORD *a2))(RBX::Rupp::TraceIdTlv *__hidden this)
{
  *(_QWORD *)a1 = off_10C8EC600; /*0x1037ba475*/
  *(_OWORD *)(a1 + 8) = *a2; /*0x1037ba47b*/
  return off_10C8EC600; /*0x1037ba47f*/
}

// Address: 0x1037ba482 | Name: __ZNK3RBX4Rupp10TraceIdTlv9serializeENS_16MutableArrayViewIhEE
__int64 __fastcall RBX::Rupp::TraceIdTlv::serialize(__int64 a1, _OWORD *a2, unsigned __int64 a3)
{
  __int64 v5; // rsi

  if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)a1 + 24LL))(a1) > a3 ) /*0x1037ba4a3*/
    return 11; /*0x1037ba4a5*/
  *a2 = *(_OWORD *)(a1 + 8); /*0x1037ba4b0*/
  (*(void (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)a1 + 24LL))(a1, a2: v5, a3: 0); /*0x1037ba4ba*/
  return 0; /*0x1037ba4c6*/
}

// Address: 0x1037ba4ce | Name: __ZN3RBX4Rupp10TraceIdTlv11deserializeERNS0_21DeserializationResultENS_9ArrayViewIhEE
__int64 __fastcall RBX::Rupp::TraceIdTlv::deserialize(__int64 a1, _OWORD *a2, __int64 a3)
{
  __int64 result; // rax

  result = 1; /*0x1037ba4d2*/
  if ( a3 == 16 ) /*0x1037ba4db*/
  {
    *(_OWORD *)(a1 + 73) = *a2; /*0x1037ba4e0*/
    return 0; /*0x1037ba4e4*/
  }
  return result; /*0x1037ba4e6*/
}

// Address: 0x1037ba554 | Name: __ZN3RBX4Rupp10TraceIdTlvD1Ev
void __fastcall RBX::Rupp::TraceIdTlv::~TraceIdTlv(RBX::Rupp::TraceIdTlv *this)
{
  ; /*0x1037ba554*/
}

// Address: 0x1037ba55a | Name: __ZN3RBX4Rupp10TraceIdTlvD0Ev
void __fastcall RBX::Rupp::TraceIdTlv::~TraceIdTlv(RBX::Rupp::TraceIdTlv *this)
{
  operator delete(a1: this); /*0x1037ba55f*/
}

// Address: 0x1037ba564 | Name: __ZNK3RBX4Rupp10TraceIdTlv10getTlvTypeEv
__int64 __fastcall RBX::Rupp::TraceIdTlv::getTlvType(RBX::Rupp::TraceIdTlv *this)
{
  return 8; /*0x1037ba56d*/
}

// Address: 0x1037ba570 | Name: __ZNK3RBX4Rupp10TraceIdTlv18getValueByteLengthEv
__int64 __fastcall RBX::Rupp::TraceIdTlv::getValueByteLength(RBX::Rupp::TraceIdTlv *this)
{
  return 16; /*0x1037ba579*/
}

// END TraceIdTlv part 1/1, 8 functions
