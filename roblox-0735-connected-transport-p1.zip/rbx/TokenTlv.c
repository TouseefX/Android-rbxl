// TokenTlv -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 11 functions


// Address: 0x1037ba252 | Name: __ZN3RBX4Rupp8TokenTlvC2ENS1_5TokenE
char __fastcall RBX::Rupp::TokenTlv::TokenTlv(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int128 a7,
        char a8)
{
  *(_QWORD *)a1 = off_10C8EC5C8; /*0x1037ba25d*/
  *(_OWORD *)(a1 + 8) = a7; /*0x1037ba264*/
  *(_BYTE *)(a1 + 24) = a8; /*0x1037ba26b*/
  return a8; /*0x1037ba26e*/
}

// Address: 0x1037ba270 | Name: __ZN3RBX4Rupp8TokenTlvC1ENS1_5TokenE
char __fastcall RBX::Rupp::TokenTlv::TokenTlv(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int128 a7,
        char a8)
{
  *(_QWORD *)a1 = off_10C8EC5C8; /*0x1037ba27b*/
  *(_OWORD *)(a1 + 8) = a7; /*0x1037ba282*/
  *(_BYTE *)(a1 + 24) = a8; /*0x1037ba289*/
  return a8; /*0x1037ba28c*/
}

// Address: 0x1037ba28e | Name: __ZN3RBX4Rupp8TokenTlv13setTokenValueENS_10StringViewE
__int64 __fastcall RBX::Rupp::TokenTlv::setTokenValue(__int64 a1, _OWORD *a2, __int64 a3)
{
  unsigned int v3; // ebx
  __int64 v4; // rdi
  _BYTE v6[24]; // [rsp+10h] [rbp-30h] BYREF
  __int64 v7; // [rsp+28h] [rbp-18h]
  _BYTE *v8; // [rsp+30h] [rbp-10h]

  if ( *(_BYTE *)(a1 + 8) != 0 && a3 == 16 ) /*0x1037ba2a2*/
  {
    *(_OWORD *)(a1 + 9) = *a2; /*0x1037ba2af*/
    v3 = 0; /*0x1037ba2cf*/
    if ( (unsigned __int8)DFLog::RuppTokenClientLog2 >= 6u && BYTE1(DFLog::RuppTokenClientLog2) >= 6u ) /*0x1037ba2cc*/
    {
      v7 = 0; /*0x1037ba2d9*/
      v8 = v6; /*0x1037ba2e5*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x1037ba309*/
        a1: DFLog::RuppTokenClientLog2,
        a2: qword_10D7B46D8,
        a3: 6,
        a4: (unsigned int)"[DFLog::RuppTokenClientLog2] Rupp token value updated.",
        a5: 54,
        a6: 1,
        0,
        v6);
    }
  }
  else
  {
    v4 = a1 + 8; /*0x1037ba310*/
    *(_OWORD *)v4 = 0; /*0x1037ba317*/
    *(_BYTE *)(v4 + 16) = 0; /*0x1037ba31a*/
    return 9; /*0x1037ba31e*/
  }
  return v3; /*0x1037ba325*/
}

// Address: 0x1037ba32c | Name: __ZNK3RBX4Rupp8TokenTlv18getValueByteLengthEv
__int64 __fastcall RBX::Rupp::TokenTlv::getValueByteLength(RBX::Rupp::TokenTlv *this)
{
  return 17; /*0x1037ba335*/
}

// Address: 0x1037ba338 | Name: __ZNK3RBX4Rupp8TokenTlv9serializeENS_16MutableArrayViewIhEE
__int64 __fastcall RBX::Rupp::TokenTlv::serialize(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  __int64 v5; // rsi

  if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)a1 + 24LL))(a1) > a3 ) /*0x1037ba359*/
    return 11; /*0x1037ba35b*/
  *(_BYTE *)a2 = *(_BYTE *)(a1 + 8); /*0x1037ba365*/
  *(_OWORD *)(a2 + 1) = *(_OWORD *)(a1 + 9); /*0x1037ba36c*/
  (*(void (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)a1 + 24LL))(a1, a2: v5, a3: 0); /*0x1037ba377*/
  return 0; /*0x1037ba383*/
}

// Address: 0x1037ba38a | Name: __ZN3RBX4Rupp8TokenTlv11deserializeERNS0_21DeserializationResultENS_9ArrayViewIhEE
__int64 __fastcall RBX::Rupp::TokenTlv::deserialize(__int64 a1, _BYTE *a2, __int64 a3)
{
  __int64 result; // rax

  result = 1; /*0x1037ba38e*/
  if ( a3 == 17 ) /*0x1037ba397*/
  {
    *(_BYTE *)(a1 + 4) = *a2; /*0x1037ba39b*/
    *(_QWORD *)(a1 + 8) = a2 + 1; /*0x1037ba3a1*/
    *(_QWORD *)(a1 + 16) = 16; /*0x1037ba3a5*/
    return 0; /*0x1037ba3ad*/
  }
  return result; /*0x1037ba3af*/
}

// Address: 0x1037ba3b2 | Name: __ZN3RBX4Rupp8TokenTlv24findTokenInBufferIfFirstENS_9ArrayViewIhEE
__int64 __fastcall RBX::Rupp::TokenTlv::findTokenInBufferIfFirst(__int64 a1, _BYTE *a2, unsigned __int64 a3)
{
  __int64 result; // rax
  unsigned __int8 v4; // cl

  result = a1; /*0x1037ba3b6*/
  if ( a3 > 0x16 && a2[5] == 17 && ((unsigned int)(v4 = a2[6]) - 1 < 2 || v4 == 255) && a2[4] == 1 ) /*0x1037ba3e3*/
  {
    *(_BYTE *)a1 = v4; /*0x1037ba3e9*/
    *(_QWORD *)(a1 + 8) = a2 + 7; /*0x1037ba3eb*/
    *(_QWORD *)(a1 + 16) = 16; /*0x1037ba3ef*/
  }
  else
  {
    *(_BYTE *)a1 = 0; /*0x1037ba3f9*/
    *(_OWORD *)(a1 + 8) = 0; /*0x1037ba3ff*/
  }
  return result; /*0x1037ba403*/
}

// Address: 0x1037ba42c | Name: __ZN3RBX4Rupp8TokenTlv12compareEqualENS_10StringViewE
unsigned __int8 __fastcall RBX::Rupp::TokenTlv::compareEqual(__int64 a1, const __m128i *a2, __int64 a3)
{
  __m128i v3; // xmm1

  if ( a3 != 16 ) /*0x1037ba434*/
    return 0; /*0x1037ba44d*/
  v3 = _mm_xor_si128(_mm_loadu_si128(a2), _mm_loadu_si128((const __m128i *)(a1 + 9))); /*0x1037ba43f*/
  return _mm_testz_si128(v3, v3); /*0x1037ba44f*/
}

// Address: 0x1037ba538 | Name: __ZN3RBX4Rupp8TokenTlvD1Ev
void __fastcall RBX::Rupp::TokenTlv::~TokenTlv(RBX::Rupp::TokenTlv *this)
{
  ; /*0x1037ba538*/
}

// Address: 0x1037ba53e | Name: __ZN3RBX4Rupp8TokenTlvD0Ev
void __fastcall RBX::Rupp::TokenTlv::~TokenTlv(RBX::Rupp::TokenTlv *this)
{
  operator delete(a1: this); /*0x1037ba543*/
}

// Address: 0x1037ba548 | Name: __ZNK3RBX4Rupp8TokenTlv10getTlvTypeEv
__int64 __fastcall RBX::Rupp::TokenTlv::getTlvType(RBX::Rupp::TokenTlv *this)
{
  return 1; /*0x1037ba551*/
}

// END TokenTlv part 1/1, 11 functions
