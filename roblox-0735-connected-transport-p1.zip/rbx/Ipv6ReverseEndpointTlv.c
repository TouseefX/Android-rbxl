// Ipv6ReverseEndpointTlv -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 6 functions


// Address: 0x1037ba160 | Name: __ZN3RBX4Rupp22Ipv6ReverseEndpointTlvC2E8in6_addrt
void (__fastcall **__fastcall RBX::Rupp::Ipv6ReverseEndpointTlv::Ipv6ReverseEndpointTlv(
        RBX::Rupp::Ipv6ReverseEndpointTlv *this,
        in6_addr a2,
        __int16 a3))(RBX::Rupp::Ipv6ReverseEndpointTlv *__hidden this)
{
  *((_QWORD *)this + 1) = *(_QWORD *)a2.__u6_addr8; /*0x1037ba164*/
  *((_QWORD *)this + 2) = *(_QWORD *)&a2.__u6_addr32[2]; /*0x1037ba168*/
  *((_WORD *)this + 12) = a3; /*0x1037ba16c*/
  *(_QWORD *)this = off_10C8EC590; /*0x1037ba177*/
  return off_10C8EC590; /*0x1037ba17a*/
}

// Address: 0x1037ba17c | Name: __ZN3RBX4Rupp22Ipv6ReverseEndpointTlvC1E8in6_addrt
void (__fastcall **__fastcall RBX::Rupp::Ipv6ReverseEndpointTlv::Ipv6ReverseEndpointTlv(
        RBX::Rupp::Ipv6ReverseEndpointTlv *this,
        in6_addr a2,
        __int16 a3))(RBX::Rupp::Ipv6ReverseEndpointTlv *__hidden this)
{
  *((_QWORD *)this + 1) = *(_QWORD *)a2.__u6_addr8; /*0x1037ba180*/
  *((_QWORD *)this + 2) = *(_QWORD *)&a2.__u6_addr32[2]; /*0x1037ba184*/
  *((_WORD *)this + 12) = a3; /*0x1037ba188*/
  *(_QWORD *)this = off_10C8EC590; /*0x1037ba193*/
  return off_10C8EC590; /*0x1037ba196*/
}

// Address: 0x1037ba198 | Name: __ZN3RBX4Rupp22Ipv6ReverseEndpointTlv11deserializeERNS0_21DeserializationResultENS_9ArrayViewIhEE
__int64 RBX::Rupp::Ipv6ReverseEndpointTlv::deserialize()
{
  return RBX::Rupp::Ipv6Tlv::deserialize(); /*0x1037ba19c*/
}

// Address: 0x1037ba598 | Name: __ZN3RBX4Rupp22Ipv6ReverseEndpointTlvD1Ev
void __fastcall RBX::Rupp::Ipv6ReverseEndpointTlv::~Ipv6ReverseEndpointTlv(RBX::Rupp::Ipv6ReverseEndpointTlv *this)
{
  ; /*0x1037ba598*/
}

// Address: 0x1037ba59e | Name: __ZN3RBX4Rupp22Ipv6ReverseEndpointTlvD0Ev
void __fastcall RBX::Rupp::Ipv6ReverseEndpointTlv::~Ipv6ReverseEndpointTlv(RBX::Rupp::Ipv6ReverseEndpointTlv *this)
{
  operator delete(a1: this); /*0x1037ba5a3*/
}

// Address: 0x1037ba5a8 | Name: __ZNK3RBX4Rupp22Ipv6ReverseEndpointTlv10getTlvTypeEv
__int64 __fastcall RBX::Rupp::Ipv6ReverseEndpointTlv::getTlvType(RBX::Rupp::Ipv6ReverseEndpointTlv *this)
{
  return 7; /*0x1037ba5b1*/
}

// END Ipv6ReverseEndpointTlv part 1/1, 6 functions
