// ClientRuppGenerator -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 11 functions


// Address: 0x1037b49e6 | Name: __ZN3RBX4Rupp19ClientRuppGeneratorC2ERKNS0_23ClientRuppConfigurationE
char *__fastcall RBX::Rupp::ClientRuppGenerator::ClientRuppGenerator(
        RBX::Rupp::ClientRuppGenerator *this,
        const RBX::Rupp::ClientRuppConfiguration *a2)
{
  __int64 v4; // xmm0_8

  *(_QWORD *)this = off_10C8EC430; /*0x1037b49fd*/
  *(_OWORD *)((char *)this + 8) = 0; /*0x1037b4a03*/
  *(_OWORD *)((char *)this + 17) = 0; /*0x1037b4a07*/
  RBX::Time::nowFast(this); /*0x1037b4a0b*/
  *((_QWORD *)this + 5) = v4; /*0x1037b4a10*/
  *(_QWORD *)this = off_10C8EC330; /*0x1037b4a1c*/
  *((_OWORD *)this + 3) = *(_OWORD *)a2; /*0x1037b4a23*/
  *((_WORD *)this + 32) = *((_WORD *)a2 + 8); /*0x1037b4a2c*/
  RBX::RbxTransport::Io::EndpointAddr::EndpointAddr( /*0x1037b4a3e*/
    this: (RBX::Rupp::ClientRuppGenerator *)((char *)this + 66),
    a2: (const RBX::Rupp::ClientRuppConfiguration *)((char *)a2 + 18));
  RBX::Rupp::Rupp::Rupp(a1: (char *)this + 96, a2: 1, a3: 0); /*0x1037b4a4e*/
  *((_QWORD *)this + 34) = (char *)this + 296; /*0x1037b4a5a*/
  *((_QWORD *)this + 35) = 0; /*0x1037b4a61*/
  *((_QWORD *)this + 36) = 40; /*0x1037b4a6c*/
  *((_BYTE *)this + 336) = 0; /*0x1037b4a77*/
  return (char *)this + 296; /*0x1037b4a82*/
}

// Address: 0x1037b4a9c | Name: __ZN3RBX4Rupp19ClientRuppGeneratorC1ERKNS0_23ClientRuppConfigurationE
char *__fastcall RBX::Rupp::ClientRuppGenerator::ClientRuppGenerator(
        RBX::Rupp::ClientRuppGenerator *this,
        const RBX::Rupp::ClientRuppConfiguration *a2)
{
  return RBX::Rupp::ClientRuppGenerator::ClientRuppGenerator(this, a2); /*0x1037b4aa0*/
}

// Address: 0x1037b4aa6 | Name: __ZN3RBX4Rupp19ClientRuppGenerator4initEv
__int64 __fastcall RBX::Rupp::ClientRuppGenerator::init(RBX::Rupp::ClientRuppGenerator *this)
{
  return RBX::Rupp::ClientRuppGenerator::generateHeader(a1: this, a2: (char *)this + 49); /*0x1037b4aae*/
}

// Address: 0x1037b4ab4 | Name: __ZN3RBX4Rupp19ClientRuppGenerator14generateHeaderERKNS0_8TokenTlv5TokenE
__int64 __fastcall RBX::Rupp::ClientRuppGenerator::generateHeader(__int64 a1, _BYTE *a2)
{
  RBX::Rupp::Rupp *v4; // r14
  __int64 v5; // rax
  RBX::RbxTransport::Io::EndpointAddr *v6; // rbx
  in_addr v7; // r15d
  unsigned __int16 Port; // ax
  __int64 result; // rax
  __int64 Sockaddr; // rax
  unsigned __int64 v11; // r15
  unsigned __int64 v12; // r12
  unsigned __int16 v13; // ax
  _WORD v14[8]; // [rsp+10h] [rbp-E0h] BYREF
  _BYTE v15[32]; // [rsp+20h] [rbp-D0h] BYREF
  _BYTE *v16; // [rsp+40h] [rbp-B0h]
  __int128 v17; // [rsp+50h] [rbp-A0h]
  __int64 v18; // [rsp+60h] [rbp-90h]
  __int128 v19; // [rsp+68h] [rbp-88h]
  __int64 v20; // [rsp+78h] [rbp-78h]
  char *v21; // [rsp+80h] [rbp-70h] BYREF
  char v22; // [rsp+98h] [rbp-58h] BYREF
  int v23; // [rsp+B8h] [rbp-38h]
  char v24; // [rsp+BCh] [rbp-34h]

  RBX::Rupp::Rupp::Rupp(a1: v14, a2: 1, a3: 0); /*0x1037b4aea*/
  *(_WORD *)(a1 + 96) = v14[0]; /*0x1037b4afc*/
  std::__function::__value_func<void ()(RBX::Rupp::TokenTlv::Token &)>::operator=[abi:ne200100](a1: a1 + 112, a2: v15); /*0x1037b4b07*/
  *(_QWORD *)(a1 + 176) = v18; /*0x1037b4b14*/
  *(_OWORD *)(a1 + 160) = v17; /*0x1037b4b20*/
  std::vector<std::unique_ptr<RBX::Rupp::TypeLengthValue>>::__vdeallocate(a1: a1 + 184); /*0x1037b4b2e*/
  *(_OWORD *)(a1 + 184) = v19; /*0x1037b4b38*/
  *(_QWORD *)(a1 + 200) = v20; /*0x1037b4b43*/
  v19 = 0; /*0x1037b4b4d*/
  v20 = 0; /*0x1037b4b52*/
  RBX::SmallVectorImpl<unsigned char>::operator=(a1: a1 + 208, a2: &v21); /*0x1037b4b64*/
  *(_BYTE *)(a1 + 268) = v24; /*0x1037b4b74*/
  *(_DWORD *)(a1 + 264) = v23; /*0x1037b4b7e*/
  if ( v21 != &v22 ) /*0x1037b4b8f*/
    operator delete(a1: v21); /*0x1037b4b91*/
  v4 = (RBX::Rupp::Rupp *)(a1 + 96); /*0x1037b4b96*/
  std::vector<std::unique_ptr<RBX::Rupp::TypeLengthValue>>::__destroy_vector::operator()[abi:ne200100](); /*0x1037b4ba4*/
  if ( v16 == v15 ) /*0x1037b4bb3*/
  {
    v5 = 32; /*0x1037b4bc1*/
    goto LABEL_7; /*0x1037b4bc1*/
  }
  v5 = 40; /*0x1037b4bb5*/
  if ( v16 != nullptr ) /*0x1037b4bbd*/
LABEL_7:
    (*(void (**)(void))(*(_QWORD *)v16 + v5))(); /*0x1037b4bc6*/
  RBX::Rupp::Rupp::setFlag(a1: a1 + 96, a2: 0, a3: *(unsigned __int8 *)(a1 + 48)); /*0x1037b4bcc*/
  RBX::Rupp::Rupp::addTokenTlv(a1: a1 + 96, a2); /*0x1037b4be0*/
  *(_QWORD *)(a1 + 280) = 0; /*0x1037b4bf4*/
  RBX::SmallVectorImpl<unsigned char>::append<unsigned char const*,void>(a1: a1 + 272, a2: a2 + 1, a3: a2 + 17); /*0x1037b4bff*/
  *(_BYTE *)(a1 + 336) = *a2; /*0x1037b4c07*/
  v6 = (RBX::RbxTransport::Io::EndpointAddr *)(a1 + 66); /*0x1037b4c0d*/
  if ( (unsigned int)RBX::RbxTransport::Io::EndpointAddr::family(this: v6) == 1 ) /*0x1037b4c1c*/
  {
    v7.s_addr = *(_DWORD *)(RBX::RbxTransport::Io::EndpointAddr::getSockaddr(this: v6) + 4); /*0x1037b4c26*/
    Port = RBX::RbxTransport::Io::EndpointAddr::getPort(this: v6); /*0x1037b4c2d*/
    result = RBX::Rupp::Rupp::addIpv4EndpointTlv(this: v4, a2: v7, a3: Port); /*0x1037b4c3b*/
    goto LABEL_12; /*0x1037b4c40*/
  }
  if ( (unsigned int)RBX::RbxTransport::Io::EndpointAddr::family(this: v6) == 2 ) /*0x1037b4c4d*/
  {
    Sockaddr = RBX::RbxTransport::Io::EndpointAddr::getSockaddr(this: v6); /*0x1037b4c52*/
    v11 = *(_QWORD *)(Sockaddr + 8); /*0x1037b4c57*/
    v12 = *(_QWORD *)(Sockaddr + 16); /*0x1037b4c5b*/
    v13 = RBX::RbxTransport::Io::EndpointAddr::getPort(this: v6); /*0x1037b4c62*/
    result = RBX::Rupp::Rupp::addIpv6EndpointTlv(this: v4, a2: (in6_addr)__PAIR128__(v12, v11), a3: v13); /*0x1037b4c73*/
LABEL_12:
    if ( (_DWORD)result != 0 ) /*0x1037b4c7a*/
      return result; /*0x1037b4c7a*/
  }
  return 0; /*0x1037b4c8e*/
}

// Address: 0x1037b4cd0 | Name: __ZN3RBX4Rupp19ClientRuppGenerator12setLocalAddrERKNS_12RbxTransport2Io12EndpointAddrE
void __fastcall RBX::Rupp::ClientRuppGenerator::setLocalAddr(
        RBX::Rupp::ClientRuppGenerator *this,
        const RBX::RbxTransport::Io::EndpointAddr *a2)
{
  ; /*0x1037b4cd0*/
}

// Address: 0x1037b4cd6 | Name: __ZN3RBX4Rupp19ClientRuppGenerator3getEv
__int64 __fastcall RBX::Rupp::ClientRuppGenerator::get(RBX::Rupp::ClientRuppGenerator *this)
{
  return (__int64)this + 96; /*0x1037b4cde*/
}

// Address: 0x1037b4ce0 | Name: __ZN3RBX4Rupp19ClientRuppGenerator20onPeerPacketReceivedERKNS0_21DeserializationResultERKNS_12RbxTransport2Io12EndpointAddrEy
__int64 __fastcall RBX::Rupp::ClientRuppGenerator::onPeerPacketReceived(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  const void **v7; // r15
  size_t v8; // rdx
  int v9; // r15d
  __int64 result; // rax
  __int64 v11; // rsi
  __int64 v12; // rdx
  unsigned __int8 v13[16]; // [rsp+0h] [rbp-50h] BYREF
  void *v14; // [rsp+10h] [rbp-40h]
  const void **v15; // [rsp+18h] [rbp-38h]
  __int64 v16; // [rsp+20h] [rbp-30h]

  if ( *(_BYTE *)(a2 + 4) == 0 ) /*0x1037b4cf7*/
    return 9; /*0x1037b4deb*/
  if ( *(_BYTE *)(a2 + 4) != 2 ) /*0x1037b4d00*/
    return 12; /*0x1037b4d00*/
  v7 = (const void **)(a1 + 272); /*0x1037b4d12*/
  v8 = *(_QWORD *)(a1 + 280); /*0x1037b4d19*/
  if ( v8 == *(_QWORD *)(a2 + 16) && memcmp(__s1: *v7, __s2: *(const void **)(a2 + 8), __n: v8) == 0 ) /*0x1037b4d34*/
    return 12; /*0x1037b4de4*/
  v15 = v7; /*0x1037b4d3a*/
  v9 = DFLog::RuppTokenLog; /*0x1037b4d45*/
  if ( (unsigned __int8)DFLog::RuppTokenLog >= 6u && BYTE1(DFLog::RuppTokenLog) >= 6u ) /*0x1037b4d58*/
  {
    v16 = qword_10D7B48E0; /*0x1037b4d63*/
    RBX::RbxTransport::Io::EndpointAddr::toString(this: (RBX::RbxTransport::Io::EndpointAddr *)v13); /*0x1037b4d6e*/
    FLog::FastLogSafeFormatted<std::string>( /*0x1037b4d90*/
      a1: v9,
      a2: v16,
      a3: 6,
      a4: (int)"[DFLog::RuppTokenLog] Switching to new TT token received from RCC {}",
      a5: 68,
      a6: v13);
    if ( (v13[0] & 1) != 0 ) /*0x1037b4d99*/
      operator delete(a1: v14); /*0x1037b4d9f*/
  }
  result = RBX::Rupp::Rupp::updateTokenFromDeserializationResult(a1: a1 + 96, a2, a3: a4); /*0x1037b4dae*/
  if ( (_DWORD)result == 0 ) /*0x1037b4db5*/
  {
    v11 = *(_QWORD *)(a2 + 8); /*0x1037b4db7*/
    v12 = v11 + *(_QWORD *)(a2 + 16); /*0x1037b4dbf*/
    *(_QWORD *)(a1 + 280) = 0; /*0x1037b4dc2*/
    RBX::SmallVectorImpl<unsigned char>::append<unsigned char const*,void>(a1: v15, a2: v11, a3: v12); /*0x1037b4dd1*/
    *(_BYTE *)(a1 + 336) = *(_BYTE *)(a2 + 4); /*0x1037b4dda*/
    return 0; /*0x1037b4de0*/
  }
  return result; /*0x1037b4df0*/
}

// Address: 0x1037b4e1a | Name: __ZN3RBX4Rupp19ClientRuppGenerator19setGameServiceTokenENS_9ArrayViewIhEE
__int64 __fastcall RBX::Rupp::ClientRuppGenerator::setGameServiceToken(__int64 a1, __int64 a2, __int64 a3)
{
  unsigned int v6; // r12d

  v6 = RBX::Rupp::Rupp::setMigrationToken(a1: a1 + 96, a2: 1, a3: a2, a4: a3); /*0x1037b4e42*/
  if ( v6 == 0 ) /*0x1037b4e47*/
  {
    *(_QWORD *)(a1 + 280) = 0; /*0x1037b4e53*/
    RBX::SmallVectorImpl<unsigned char>::append<unsigned char const*,void>(a1: a1 + 272, a2, a3: a2 + a3); /*0x1037b4e64*/
    *(_BYTE *)(a1 + 336) = 1; /*0x1037b4e69*/
  }
  return v6; /*0x1037b4e73*/
}

// Address: 0x1037b4e7c | Name: __ZNK3RBX4Rupp19ClientRuppGenerator14buildProbeRuppERKNS_7Guid128E
RBX::Rupp::Rupp *__fastcall RBX::Rupp::ClientRuppGenerator::buildProbeRupp(
        RBX::Rupp::Rupp *this,
        __int64 a2,
        __int64 a3)
{
  RBX::RbxTransport::Io::EndpointAddr *v6; // r15
  in_addr v7; // r12d
  unsigned __int16 Port; // ax
  __int64 Sockaddr; // rax
  unsigned __int64 v10; // r12
  unsigned __int64 v11; // r13
  unsigned __int16 v12; // ax
  _BYTE v14[17]; // [rsp+Fh] [rbp-41h] BYREF

  RBX::Rupp::Rupp::Rupp(a1: this, a2: 4, a3: 0); /*0x1037b4eab*/
  RBX::Rupp::Rupp::setFlag(a1: this, a2: 0, a3: *(unsigned __int8 *)(a2 + 48)); /*0x1037b4eba*/
  RBX::Rupp::TokenTlv::Token::Token( /*0x1037b4ed9*/
    a1: v14,
    a2: *(unsigned __int8 *)(a2 + 336),
    a3: *(_QWORD *)(a2 + 272),
    a4: *(_QWORD *)(a2 + 280));
  RBX::Rupp::Rupp::addTokenTlv(a1: this, a2: v14); /*0x1037b4ee5*/
  v6 = (RBX::RbxTransport::Io::EndpointAddr *)(a2 + 66); /*0x1037b4eea*/
  if ( (unsigned int)RBX::RbxTransport::Io::EndpointAddr::family(this: v6) == 1 ) /*0x1037b4ef9*/
  {
    v7.s_addr = *(_DWORD *)(RBX::RbxTransport::Io::EndpointAddr::getSockaddr(this: v6) + 4); /*0x1037b4f03*/
    Port = RBX::RbxTransport::Io::EndpointAddr::getPort(this: v6); /*0x1037b4f0a*/
    RBX::Rupp::Rupp::addIpv4EndpointTlv(this, a2: v7, a3: Port); /*0x1037b4f18*/
  }
  else if ( (unsigned int)RBX::RbxTransport::Io::EndpointAddr::family(this: v6) == 2 ) /*0x1037b4f2a*/
  {
    Sockaddr = RBX::RbxTransport::Io::EndpointAddr::getSockaddr(this: v6); /*0x1037b4f2f*/
    v10 = *(_QWORD *)(Sockaddr + 8); /*0x1037b4f34*/
    v11 = *(_QWORD *)(Sockaddr + 16); /*0x1037b4f38*/
    v12 = RBX::RbxTransport::Io::EndpointAddr::getPort(this: v6); /*0x1037b4f3f*/
    RBX::Rupp::Rupp::addIpv6EndpointTlv(this, a2: (in6_addr)__PAIR128__(v11, v10), a3: v12); /*0x1037b4f50*/
  }
  RBX::Rupp::Rupp::addTraceIdTlv(a1: this, a2: a3); /*0x1037b4f5b*/
  return this; /*0x1037b4f73*/
}

// Address: 0x1037b4fa4 | Name: __ZN3RBX4Rupp19ClientRuppGeneratorD1Ev
void __fastcall RBX::Rupp::ClientRuppGenerator::~ClientRuppGenerator(RBX::Rupp::ClientRuppGenerator *this)
{
  char *v1; // rax
  char *v3; // rdi
  char *v4; // rdi
  RBX::Rupp::ClientRuppGenerator *v5; // rdi
  __int64 v6; // rax
  char *v7; // [rsp+0h] [rbp-10h] BYREF

  v7 = v1; /*0x1037b4fa9*/
  *(_QWORD *)this = off_10C8EC330; /*0x1037b4fb4*/
  v3 = *((char **)this + 34); /*0x1037b4fb7*/
  if ( v3 != (char *)this + 296 ) /*0x1037b4fc8*/
    operator delete(a1: v3); /*0x1037b4fca*/
  v4 = *((char **)this + 26); /*0x1037b4fcf*/
  if ( v4 != (char *)this + 232 ) /*0x1037b4fe0*/
    operator delete(a1: v4); /*0x1037b4fe2*/
  v7 = (char *)this + 184; /*0x1037b4ff2*/
  std::vector<std::unique_ptr<RBX::Rupp::TypeLengthValue>>::__destroy_vector::operator()[abi:ne200100](a1: &v7); /*0x1037b4ff5*/
  v5 = *((RBX::Rupp::ClientRuppGenerator **)this + 18); /*0x1037b4ffe*/
  if ( v5 == (RBX::Rupp::ClientRuppGenerator *)((char *)this + 112) ) /*0x1037b5008*/
  {
    v6 = 32; /*0x1037b5016*/
  }
  else
  {
    v6 = 40; /*0x1037b500a*/
    if ( v5 == nullptr ) /*0x1037b5012*/
      goto LABEL_10; /*0x1037b5012*/
  }
  (*(void (**)(void))(*(_QWORD *)v5 + v6))(); /*0x1037b501e*/
LABEL_10:
  RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::Rupp::ClientRuppGenerator *)((char *)this + 66)); /*0x1037b5021*/
}

// Address: 0x1037b5034 | Name: __ZN3RBX4Rupp19ClientRuppGeneratorD0Ev
void __fastcall RBX::Rupp::ClientRuppGenerator::~ClientRuppGenerator(RBX::Rupp::ClientRuppGenerator *this)
{
  char *v1; // rax
  char *v3; // rdi
  char *v4; // rdi
  RBX::Rupp::ClientRuppGenerator *v5; // rdi
  __int64 v6; // rax
  char *v7; // [rsp+0h] [rbp-10h] BYREF

  v7 = v1; /*0x1037b5039*/
  *(_QWORD *)this = off_10C8EC330; /*0x1037b5044*/
  v3 = *((char **)this + 34); /*0x1037b5047*/
  if ( v3 != (char *)this + 296 ) /*0x1037b5058*/
    operator delete(a1: v3); /*0x1037b505a*/
  v4 = *((char **)this + 26); /*0x1037b505f*/
  if ( v4 != (char *)this + 232 ) /*0x1037b5070*/
    operator delete(a1: v4); /*0x1037b5072*/
  v7 = (char *)this + 184; /*0x1037b5082*/
  std::vector<std::unique_ptr<RBX::Rupp::TypeLengthValue>>::__destroy_vector::operator()[abi:ne200100](a1: &v7); /*0x1037b5085*/
  v5 = *((RBX::Rupp::ClientRuppGenerator **)this + 18); /*0x1037b508e*/
  if ( v5 == (RBX::Rupp::ClientRuppGenerator *)((char *)this + 112) ) /*0x1037b5098*/
  {
    v6 = 32; /*0x1037b50a6*/
  }
  else
  {
    v6 = 40; /*0x1037b509a*/
    if ( v5 == nullptr ) /*0x1037b50a2*/
      goto LABEL_10; /*0x1037b50a2*/
  }
  (*(void (**)(void))(*(_QWORD *)v5 + v6))(); /*0x1037b50ae*/
LABEL_10:
  RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::Rupp::ClientRuppGenerator *)((char *)this + 66)); /*0x1037b50b1*/
  operator delete(a1: this); /*0x1037b50bd*/
}

// END ClientRuppGenerator part 1/1, 11 functions
