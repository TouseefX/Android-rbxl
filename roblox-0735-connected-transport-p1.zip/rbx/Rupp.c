// Rupp -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 45 functions


// Address: 0x1037b5130 | Name: __ZN3RBX4Rupp12parseQuicSniERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
_BYTE *__fastcall RBX::Rupp::parseQuicSni(_BYTE *a1, __int128 *a2)
{
  char v3; // r14
  char v4; // r15
  __int64 v5; // rax
  char v7; // al
  __int64 v8; // rcx
  __int64 v9; // rsi
  char *v10; // rdx
  __int64 v11; // rsi
  int v12; // r8d
  int v13; // r8d
  unsigned __int8 v14; // r9
  int v15; // r9d
  int v16; // r9d
  unsigned __int8 v17; // r10
  __int64 v18; // rsi
  char *v19; // rdx
  __int64 v20; // rsi
  int v21; // r8d
  int v22; // r8d
  unsigned __int8 v23; // r9
  int v24; // r9d
  int v25; // r9d
  unsigned __int8 v26; // r10
  char *v27; // rcx
  char v28; // dl
  __int64 v29; // rsi
  int v30; // r8d
  int v31; // r8d
  unsigned __int8 v32; // r9
  int v33; // r9d
  int v34; // r9d
  unsigned __int8 v35; // r10
  bool v36; // zf
  char v37; // cl
  __int128 v38; // [rsp+8h] [rbp-D8h] BYREF
  void *v39; // [rsp+18h] [rbp-C8h]
  unsigned __int8 v40; // [rsp+20h] [rbp-C0h] BYREF
  char v41; // [rsp+21h] [rbp-BFh] BYREF
  __int64 v42; // [rsp+28h] [rbp-B8h]
  void *v43; // [rsp+30h] [rbp-B0h]
  char v44; // [rsp+38h] [rbp-A8h]
  unsigned __int8 v45; // [rsp+40h] [rbp-A0h] BYREF
  char v46; // [rsp+41h] [rbp-9Fh] BYREF
  __int64 v47; // [rsp+48h] [rbp-98h]
  void *v48; // [rsp+50h] [rbp-90h]
  char v49; // [rsp+58h] [rbp-88h]
  __int128 v50; // [rsp+60h] [rbp-80h] BYREF
  void *v51; // [rsp+70h] [rbp-70h]
  __int128 v52; // [rsp+80h] [rbp-60h] BYREF
  void *v53; // [rsp+90h] [rbp-50h]
  _BYTE v54[33]; // [rsp+9Fh] [rbp-41h] BYREF

  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1037b5154*/
  {
    std::string::__init_copy_ctor_external(a1: &v52, a2: *((_QWORD *)a2 + 2), a3: *((_QWORD *)a2 + 1)); /*0x1037b5173*/
  }
  else
  {
    v53 = *((void **)a2 + 2); /*0x1037b515a*/
    v52 = *a2; /*0x1037b5161*/
  }
  memset(&v54[1], 0, 22); /*0x1037b517b*/
  RBX::Rupp::`anonymous namespace'::takeField(a1: &v45, a2: &v52); /*0x1037b5192*/
  RBX::Rupp::`anonymous namespace'::takeField(a1: &v40, a2: &v52); /*0x1037b51a2*/
  v3 = v49; /*0x1037b51a7*/
  v4 = v44; /*0x1037b51ae*/
  if ( v49 == 1 && (v44 & 1) != 0 )
  {
    v5 = std::string::find(a1: &v52, a2: 46, a3: 0); /*0x1037b51cc*/
    if ( v5 == -1 ) /*0x1037b51d5*/
    {
      v51 = v53; /*0x1037b5283*/
      v50 = v52; /*0x1037b528b*/
      LOWORD(v52) = 0; /*0x1037b528f*/
    }
    else
    {
      std::string::basic_string(a1: &v38, a2: &v52, a3: 0, a4: v5, a5: v54); /*0x1037b51ef*/
      v50 = v38; /*0x1037b51fb*/
      v51 = v39; /*0x1037b5206*/
    }
    v7 = v50; /*0x1037b5295*/
    if ( (v50 & 1) != 0 ) /*0x1037b529b*/
      v8 = *((_QWORD *)&v50 + 1); /*0x1037b529d*/
    else
      v8 = (unsigned __int8)v50 >> 1; /*0x1037b52a5*/
    if ( v8 != 0 )
    {
      v9 = (v45 & 1) != 0 ? v47 : v45 >> 1;
      if ( v9 == 32 ) /*0x1037b52cd*/
      {
        if ( (v45 & 1) != 0 ) /*0x1037b52d6*/
          v10 = (char *)v48; /*0x1037b52d8*/
        else
          v10 = &v46; /*0x1037b52e1*/
        v11 = 0; /*0x1037b52e8*/
        while ( 1 ) /*0x1037b52ef*/
        {
          v12 = v10[2 * v11]; /*0x1037b52ef*/
          if ( (unsigned __int8)(v10[2 * v11] - 48) > 9u ) /*0x1037b52fc*/
          {
            if ( (unsigned __int8)(v12 - 97) > 5u ) /*0x1037b530c*/
            {
              v14 = v12 - 65; /*0x1037b5314*/
              v13 = v12 - 55; /*0x1037b5318*/
              if ( v14 >= 6u ) /*0x1037b5320*/
                v13 = -1; /*0x1037b5320*/
            }
            else
            {
              v13 = v12 - 87; /*0x1037b530e*/
            }
          }
          else
          {
            v13 = v12 - 48; /*0x1037b52fe*/
          }
          v15 = v10[2 * v11 + 1]; /*0x1037b5324*/
          if ( (unsigned __int8)(v10[2 * v11 + 1] - 48) > 9u ) /*0x1037b5332*/
          {
            if ( (unsigned __int8)(v15 - 97) > 5u ) /*0x1037b5342*/
            {
              v17 = v15 - 65; /*0x1037b534a*/
              v16 = v15 - 55; /*0x1037b534e*/
              if ( v17 >= 6u ) /*0x1037b5356*/
                v16 = -1; /*0x1037b5356*/
            }
            else
            {
              v16 = v15 - 87; /*0x1037b5344*/
            }
          }
          else
          {
            v16 = v15 - 48; /*0x1037b5334*/
          }
          if ( v13 < 0 || v16 < 0 ) /*0x1037b5366*/
            break; /*0x1037b5366*/
          v54[++v11] = (16 * v13) | v16; /*0x1037b5373*/
          if ( v11 == 16 ) /*0x1037b537f*/
          {
            if ( (v40 & 1) != 0 ) /*0x1037b538f*/
              v18 = v42; /*0x1037b5391*/
            else
              v18 = v40 >> 1; /*0x1037b539c*/
            if ( v18 == 8 ) /*0x1037b53a2*/
            {
              if ( (v40 & 1) != 0 ) /*0x1037b53ab*/
                v19 = (char *)v43; /*0x1037b53ad*/
              else
                v19 = &v41; /*0x1037b53b6*/
              v20 = 0; /*0x1037b53bd*/
              while ( 1 ) /*0x1037b53c4*/
              {
                v21 = v19[2 * v20]; /*0x1037b53c4*/
                if ( (unsigned __int8)(v19[2 * v20] - 48) > 9u ) /*0x1037b53d1*/
                {
                  if ( (unsigned __int8)(v21 - 97) > 5u ) /*0x1037b53e1*/
                  {
                    v23 = v21 - 65; /*0x1037b53e9*/
                    v22 = v21 - 55; /*0x1037b53ed*/
                    if ( v23 >= 6u ) /*0x1037b53f5*/
                      v22 = -1; /*0x1037b53f5*/
                  }
                  else
                  {
                    v22 = v21 - 87; /*0x1037b53e3*/
                  }
                }
                else
                {
                  v22 = v21 - 48; /*0x1037b53d3*/
                }
                v24 = v19[2 * v20 + 1]; /*0x1037b53f9*/
                if ( (unsigned __int8)(v19[2 * v20 + 1] - 48) > 9u ) /*0x1037b5407*/
                {
                  if ( (unsigned __int8)(v24 - 97) > 5u ) /*0x1037b5417*/
                  {
                    v26 = v24 - 65; /*0x1037b541f*/
                    v25 = v24 - 55; /*0x1037b5423*/
                    if ( v26 >= 6u ) /*0x1037b542b*/
                      v25 = -1; /*0x1037b542b*/
                  }
                  else
                  {
                    v25 = v24 - 87; /*0x1037b5419*/
                  }
                }
                else
                {
                  v25 = v24 - 48; /*0x1037b5409*/
                }
                if ( v22 < 0 || v25 < 0 ) /*0x1037b543b*/
                  break; /*0x1037b543b*/
                v54[v20++ + 17] = (16 * v22) | v25; /*0x1037b5448*/
                if ( v20 == 4 ) /*0x1037b5454*/
                {
                  if ( v8 == 4 ) /*0x1037b545e*/
                  {
                    if ( (v7 & 1) != 0 ) /*0x1037b5466*/
                      v27 = (char *)v51; /*0x1037b5468*/
                    else
                      v27 = (char *)&v50 + 1; /*0x1037b546e*/
                    v28 = 1; /*0x1037b5472*/
                    v29 = 0; /*0x1037b5474*/
                    while ( 1 ) /*0x1037b547b*/
                    {
                      v30 = v27[2 * v29]; /*0x1037b547b*/
                      if ( (unsigned __int8)(v27[2 * v29] - 48) > 9u ) /*0x1037b5488*/
                      {
                        if ( (unsigned __int8)(v30 - 97) > 5u ) /*0x1037b5498*/
                        {
                          v32 = v30 - 65; /*0x1037b54a0*/
                          v31 = v30 - 55; /*0x1037b54a4*/
                          if ( v32 >= 6u ) /*0x1037b54ac*/
                            v31 = -1; /*0x1037b54ac*/
                        }
                        else
                        {
                          v31 = v30 - 87; /*0x1037b549a*/
                        }
                      }
                      else
                      {
                        v31 = v30 - 48; /*0x1037b548a*/
                      }
                      v33 = v27[2 * v29 + 1]; /*0x1037b54b4*/
                      if ( (unsigned __int8)(v27[2 * v29 + 1] - 48) > 9u ) /*0x1037b54c2*/
                      {
                        if ( (unsigned __int8)(v33 - 97) > 5u ) /*0x1037b54d2*/
                        {
                          v35 = v33 - 65; /*0x1037b54da*/
                          v34 = v33 - 55; /*0x1037b54de*/
                          if ( v35 >= 6u ) /*0x1037b54e6*/
                            v34 = -1; /*0x1037b54e6*/
                        }
                        else
                        {
                          v34 = v33 - 87; /*0x1037b54d4*/
                        }
                      }
                      else
                      {
                        v34 = v33 - 48; /*0x1037b54c4*/
                      }
                      if ( v31 < 0 || v34 < 0 ) /*0x1037b54f2*/
                        break; /*0x1037b54f2*/
                      v54[v29 + 21] = (16 * v31) | v34; /*0x1037b54fb*/
                      v29 = 1; /*0x1037b5500*/
                      v36 = (v28 & 1) == 0; /*0x1037b5505*/
                      v28 = 0; /*0x1037b5508*/
                      if ( v36 ) /*0x1037b550d*/
                      {
                        qmemcpy(a1, &v54[1], 22); /*0x1037b5517*/
                        v37 = 1; /*0x1037b5522*/
                        goto LABEL_91; /*0x1037b5524*/
                      }
                    }
                  }
                  goto LABEL_90; /*0x1037b54f2*/
                }
              }
            }
            break; /*0x1037b543b*/
          }
        }
      }
    }
LABEL_90:
    *a1 = 0; /*0x1037b5526*/
    v37 = 0; /*0x1037b5529*/
LABEL_91:
    a1[22] = v37; /*0x1037b552b*/
    if ( (v7 & 1) != 0 ) /*0x1037b5530*/
      operator delete(a1: v51); /*0x1037b553a*/
  }
  else
  {
    *a1 = 0; /*0x1037b5211*/
    a1[22] = 0; /*0x1037b5213*/
  }
  if ( (v4 & 1) != 0 && (v40 & 1) != 0 ) /*0x1037b5223*/
    operator delete(a1: v43); /*0x1037b522c*/
  if ( v3 != 0 && (v45 & 1) != 0 ) /*0x1037b523d*/
    operator delete(a1: v48); /*0x1037b5246*/
  if ( (v52 & 1) != 0 ) /*0x1037b524f*/
    operator delete(a1: v53); /*0x1037b5255*/
  return a1; /*0x1037b5271*/
}

// Address: 0x1037b563d | Name: __ZN3RBX4Rupp24generateQuicConnectionIdERNS0_16QuicConnectionIdERKNS0_23ServerRuppConfigurationERKNS0_11QuicSniDataERKNS_12RbxTransport2Io12EndpointAddrE
__int64 __fastcall RBX::Rupp::generateQuicConnectionId(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  unsigned int v5; // ebx
  _BYTE v7[24]; // [rsp+0h] [rbp-50h] BYREF
  __int64 v8; // [rsp+18h] [rbp-38h]
  char v9; // [rsp+20h] [rbp-30h]
  __int64 v10; // [rsp+28h] [rbp-28h]

  memset(v7, 0, 22); /*0x1037b5666*/
  v8 = 0; /*0x1037b5669*/
  v9 = 0; /*0x1037b566d*/
  v10 = 1; /*0x1037b5671*/
  v5 = RBX::Rupp::QuicConnectionIdGenerator::init(a1: v7, a2, a3, a4); /*0x1037b567e*/
  if ( v5 == 0 || v5 == 12 ) /*0x1037b5687*/
    v5 = RBX::Rupp::QuicConnectionIdGenerator::generate(a1: v7, a2: a1); /*0x1037b5695*/
  if ( v8 != 0 ) /*0x1037b569e*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 8LL))(a1: v8); /*0x1037b56a3*/
  return v5; /*0x1037b56b8*/
}

// Address: 0x1037b5b00 | Name: __ZN3RBX4Rupp4RuppC2ENS0_12ProtocolTypeENS0_9RuppFlagsE
__int64 __fastcall RBX::Rupp::Rupp::Rupp(__int64 a1, char a2, char a3)
{
  *(_BYTE *)a1 = a2; /*0x1037b5b04*/
  *(_BYTE *)(a1 + 1) = a3; /*0x1037b5b07*/
  *(_QWORD *)(a1 + 48) = 0; /*0x1037b5b0c*/
  *(_DWORD *)(a1 + 64) = 0; /*0x1037b5b10*/
  *(_OWORD *)(a1 + 72) = 0; /*0x1037b5b21*/
  *(_OWORD *)(a1 + 88) = 0; /*0x1037b5b25*/
  *(_QWORD *)(a1 + 104) = 0; /*0x1037b5b29*/
  *(_QWORD *)(a1 + 112) = a1 + 136; /*0x1037b5b2d*/
  *(_QWORD *)(a1 + 120) = 0; /*0x1037b5b31*/
  *(_QWORD *)(a1 + 128) = 32; /*0x1037b5b35*/
  *(_DWORD *)(a1 + 168) = -1; /*0x1037b5b40*/
  *(_BYTE *)(a1 + 172) = 0; /*0x1037b5b4a*/
  return 0; /*0x1037b5b51*/
}

// Address: 0x1037b5b54 | Name: __ZN3RBX4Rupp4RuppC1ENS0_12ProtocolTypeENS0_9RuppFlagsE
__int64 __fastcall RBX::Rupp::Rupp::Rupp(__int64 a1, char a2, char a3)
{
  *(_BYTE *)a1 = a2; /*0x1037b5b58*/
  *(_BYTE *)(a1 + 1) = a3; /*0x1037b5b5b*/
  *(_QWORD *)(a1 + 48) = 0; /*0x1037b5b60*/
  *(_DWORD *)(a1 + 64) = 0; /*0x1037b5b64*/
  *(_OWORD *)(a1 + 72) = 0; /*0x1037b5b75*/
  *(_OWORD *)(a1 + 88) = 0; /*0x1037b5b79*/
  *(_QWORD *)(a1 + 104) = 0; /*0x1037b5b7d*/
  *(_QWORD *)(a1 + 112) = a1 + 136; /*0x1037b5b81*/
  *(_QWORD *)(a1 + 120) = 0; /*0x1037b5b85*/
  *(_QWORD *)(a1 + 128) = 32; /*0x1037b5b89*/
  *(_DWORD *)(a1 + 168) = -1; /*0x1037b5b94*/
  *(_BYTE *)(a1 + 172) = 0; /*0x1037b5b9e*/
  return 0; /*0x1037b5ba5*/
}

// Address: 0x1037b5ba8 | Name: __ZNK3RBX4Rupp4Rupp11getTlvIndexENS0_7TlvTypeE
__int64 __fastcall RBX::Rupp::Rupp::getTlvIndex(__int64 a1, char a2)
{
  _QWORD *v2; // r12
  unsigned int v3; // ebx
  __int64 v6; // r13

  v2 = *(_QWORD **)(a1 + 88); /*0x1037b5bb6*/
  v3 = -1; /*0x1037b5bba*/
  if ( (unsigned __int64)v2 < *(_QWORD *)(a1 + 96) ) /*0x1037b5bc3*/
  {
    v6 = *(_QWORD *)(a1 + 88); /*0x1037b5bcb*/
    while ( (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v2 + 16LL))(a1: *v2) != a2 ) /*0x1037b5bdb*/
    {
      ++v2; /*0x1037b5bdd*/
      v6 += 8; /*0x1037b5be1*/
      if ( (unsigned __int64)v2 >= *(_QWORD *)(a1 + 96) ) /*0x1037b5be9*/
        return v3; /*0x1037b5be9*/
    }
    return (unsigned int)((unsigned __int64)(v6 - *(_QWORD *)(a1 + 88)) >> 3); /*0x1037b5bf5*/
  }
  return v3; /*0x1037b5bfe*/
}

// Address: 0x1037b5c0a | Name: __ZN3RBX4Rupp4Rupp7setFlagENS0_9RuppFlagsEb
__int64 __fastcall RBX::Rupp::Rupp::setFlag(__int64 a1, char a2, int a3)
{
  char v3; // al
  char v4; // cl
  __int64 result; // rax

  v3 = *(_BYTE *)(a1 + 1); /*0x1037b5c0e*/
  v4 = v3 & ~a2; /*0x1037b5c15*/
  result = (unsigned __int8)(a2 | v3); /*0x1037b5c1a*/
  if ( a3 != 0 ) /*0x1037b5c22*/
    v4 = result; /*0x1037b5c22*/
  *(_BYTE *)(a1 + 1) = v4; /*0x1037b5c25*/
  *(_QWORD *)(a1 + 120) = 0; /*0x1037b5c28*/
  return result; /*0x1037b5c30*/
}

// Address: 0x1037b5c32 | Name: __ZN3RBX4Rupp4Rupp29invalidateCachedSerializationEv
void __fastcall RBX::Rupp::Rupp::invalidateCachedSerialization(RBX::Rupp::Rupp *this)
{
  *((_QWORD *)this + 15) = 0; /*0x1037b5c36*/
}

// Address: 0x1037b5c40 | Name: __ZN3RBX4Rupp4Rupp6addTlvENSt3__110unique_ptrINS0_15TypeLengthValueENS2_14default_deleteIS4_EEEE
__int64 __fastcall RBX::Rupp::Rupp::addTlv(_QWORD *a1, _QWORD *a2)
{
  char v4; // r12
  _QWORD *v5; // r13
  __int64 v6; // r15
  __int64 result; // rax
  _QWORD *v8; // [rsp+0h] [rbp-30h]

  v4 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*a2 + 16LL))(a1: *a2); /*0x1037b5c5d*/
  v8 = a1 + 11; /*0x1037b5c64*/
  v5 = (_QWORD *)a1[11]; /*0x1037b5c68*/
  if ( (unsigned __int64)v5 >= a1[12] ) /*0x1037b5c70*/
    goto LABEL_7; /*0x1037b5c70*/
  v6 = a1[11]; /*0x1037b5c72*/
  while ( (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v5 + 16LL))(a1: *v5) != v4 ) /*0x1037b5c82*/
  {
    ++v5; /*0x1037b5c84*/
    v6 += 8; /*0x1037b5c88*/
    if ( (unsigned __int64)v5 >= a1[12] ) /*0x1037b5c90*/
      goto LABEL_7; /*0x1037b5c90*/
  }
  result = 7; /*0x1037b5ca2*/
  if ( (unsigned int)((unsigned __int64)~(v6 - *v8) >> 3) == 0 ) /*0x1037b5caa*/
  {
LABEL_7:
    a1[15] = 0; /*0x1037b5cac*/
    std::vector<std::unique_ptr<RBX::Rupp::TypeLengthValue>>::push_back[abi:ne200100](a1: v8, a2); /*0x1037b5cbb*/
    return 0; /*0x1037b5cc0*/
  }
  return result; /*0x1037b5cc6*/
}

// Address: 0x1037b5e0a | Name: __ZN3RBX4Rupp4Rupp9removeTlvENS0_7TlvTypeE
__int64 __fastcall RBX::Rupp::Rupp::removeTlv(_QWORD *a1, char a2)
{
  _QWORD *v2; // r13
  unsigned int v3; // r14d
  __int64 v6; // r12
  __int64 v7; // r15
  __int64 v8; // r12
  __int64 v9; // r12
  __int64 *v10; // r13
  __int64 *v11; // r14
  __int64 *v12; // r15
  __int64 v13; // rdi
  __int64 v14; // rax
  __int64 v15; // rdi

  v2 = (_QWORD *)a1[11]; /*0x1037b5e18*/
  v3 = 8; /*0x1037b5e1c*/
  if ( (unsigned __int64)v2 < a1[12] ) /*0x1037b5e26*/
  {
    v6 = a1[11]; /*0x1037b5e32*/
    while ( (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v2 + 16LL))(a1: *v2) != a2 ) /*0x1037b5e42*/
    {
      ++v2; /*0x1037b5e44*/
      v6 += 8; /*0x1037b5e48*/
      if ( (unsigned __int64)v2 >= a1[12] ) /*0x1037b5e50*/
        return v3; /*0x1037b5e50*/
    }
    v7 = a1[11]; /*0x1037b5e57*/
    v8 = v6 - v7; /*0x1037b5e5b*/
    if ( (v8 & 0x400000000LL) == 0 ) /*0x1037b5e63*/
    {
      a1[15] = 0; /*0x1037b5e69*/
      v9 = v8 & 0x3FFFFFFF8LL; /*0x1037b5e7b*/
      v10 = (__int64 *)(v7 + v9 + 8); /*0x1037b5e82*/
      v11 = (__int64 *)a1[12]; /*0x1037b5e86*/
      v12 = (__int64 *)(v9 + v7); /*0x1037b5e8a*/
      if ( v10 != v11 ) /*0x1037b5e90*/
      {
        do /*0x1037b5ebc*/
        {
          v13 = *(v10 - 1); /*0x1037b5e92*/
          v14 = *v10; /*0x1037b5e96*/
          *v10 = 0; /*0x1037b5e9a*/
          *(v10 - 1) = v14; /*0x1037b5ea2*/
          if ( v13 != 0 ) /*0x1037b5ea9*/
            (*(void (__fastcall **)(__int64))(*(_QWORD *)v13 + 8LL))(a1: v13); /*0x1037b5eae*/
          ++v10; /*0x1037b5eb1*/
          ++v12; /*0x1037b5eb5*/
        }
        while ( v10 != v11 ); /*0x1037b5ebc*/
        v11 = (__int64 *)a1[12]; /*0x1037b5ebe*/
      }
      while ( v11 != v12 ) /*0x1037b5ee2*/
      {
        v15 = *(v11 - 1); /*0x1037b5ec4*/
        *(v11 - 1) = 0; /*0x1037b5ec8*/
        if ( v15 != 0 ) /*0x1037b5ed3*/
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 8LL))(a1: v15); /*0x1037b5ed8*/
        --v11; /*0x1037b5edb*/
      }
      a1[12] = v12; /*0x1037b5ee4*/
      return 0; /*0x1037b5ee8*/
    }
  }
  return v3; /*0x1037b5ef2*/
}

// Address: 0x1037b5efe | Name: __ZNK3RBX4Rupp4Rupp24getHeaderTotalByteLengthEv
__int64 __fastcall RBX::Rupp::Rupp::getHeaderTotalByteLength(RBX::Rupp::Rupp *this)
{
  int v1; // ebx
  _QWORD *v2; // r14
  _QWORD *v3; // r15

  v2 = *((_QWORD **)this + 11); /*0x1037b5f08*/
  v3 = *((_QWORD **)this + 12); /*0x1037b5f0c*/
  LOWORD(v1) = 4; /*0x1037b5f10*/
  while ( v2 != v3 ) /*0x1037b5f17*/
  {
    v1 += (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v2 + 24LL))(a1: *v2) + 2; /*0x1037b5f27*/
    ++v2; /*0x1037b5f2a*/
  }
  return (unsigned __int16)v1; /*0x1037b5f37*/
}

// Address: 0x1037b5f3e | Name: __ZN3RBX4Rupp4Rupp17isValidRuppLengthEt
bool __fastcall RBX::Rupp::Rupp::isValidRuppLength(RBX::Rupp::Rupp *this)
{
  __int64 v1; // rax

  v1 = 0; /*0x1037b5f42*/
  while ( *(_WORD *)((char *)&RBX::Rupp::Rupp::isValidRuppLength(unsigned short)::validLengths + v1) != (_WORD)this ) /*0x1037b5f4f*/
  {
    v1 += 2; /*0x1037b5f51*/
    if ( v1 == 12 ) /*0x1037b5f59*/
      return false; /*0x1037b5f5d*/
  }
  return v1 != 12; /*0x1037b5f66*/
}

// Address: 0x1037b5f68 | Name: __ZNK3RBX4Rupp4Rupp10getNumTlvsEv
__int64 __fastcall RBX::Rupp::Rupp::getNumTlvs(RBX::Rupp::Rupp *this)
{
  return (__int64)(*((_QWORD *)this + 12) - *((_QWORD *)this + 11)) >> 3; /*0x1037b5f78*/
}

// Address: 0x1037b5f7a | Name: __ZN3RBX4Rupp4Rupp15autoUpdateTokenEv
__int64 __fastcall RBX::Rupp::Rupp::autoUpdateToken(RBX::Rupp::Rupp *this)
{
  __int64 v2; // rdi
  _BYTE v4[16]; // [rsp+10h] [rbp-40h] BYREF
  __int128 v5; // [rsp+20h] [rbp-30h] BYREF
  char v6; // [rsp+30h] [rbp-20h]

  v2 = *((_QWORD *)this + 6); /*0x1037b5f96*/
  if ( v2 == 0 ) /*0x1037b5f9d*/
    return 12; /*0x1037b6012*/
  if ( BYTE1(DFLog::RuppTokenClientLog2) >= 6u && (unsigned __int8)DFLog::RuppTokenClientLog2 >= 6u ) /*0x1037b5fad*/
  {
    *(_QWORD *)&v5 = 0; /*0x1037b5fc1*/
    *((_QWORD *)&v5 + 1) = v4; /*0x1037b5fcd*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x1037b5ff4*/
      a1: DFLog::RuppTokenClientLog2,
      a2: qword_10D7B46D8,
      a3: 6,
      a4: (unsigned int)"[DFLog::RuppTokenClientLog2] Generating new Rupp token.",
      a5: 55,
      a6: 1,
      0,
      v4);
    v2 = *((_QWORD *)this + 6); /*0x1037b5ff9*/
    v5 = 0; /*0x1037b6000*/
    v6 = 0; /*0x1037b6004*/
    if ( v2 == 0 ) /*0x1037b600b*/
      std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x1037b600d*/
  }
  else
  {
    v5 = 0; /*0x1037b601c*/
    v6 = 0; /*0x1037b6020*/
  }
  (*(void (__fastcall **)(__int64, __int128 *))(*(_QWORD *)v2 + 48LL))(a1: v2, a2: &v5); /*0x1037b602e*/
  if ( (_BYTE)v5 != 0 ) /*0x1037b6036*/
    return RBX::Rupp::Rupp::updateTokenTlv(a1: this, a2: (unsigned __int8)v5, a3: (char *)&v5 + 1, a4: 16); /*0x1037b6047*/
  else
    return 9; /*0x1037b604e*/
}

// Address: 0x1037b6072 | Name: __ZN3RBX4Rupp4Rupp14updateTokenTlvENS0_9TokenTypeENS_10StringViewE
__int64 __fastcall RBX::Rupp::Rupp::updateTokenTlv(__int64 a1, int a2, __int64 a3, __int64 a4)
{
  _QWORD *v4; // rbx
  unsigned int v5; // r13d
  _QWORD *v8; // r14
  __int64 v9; // rax
  unsigned __int64 v10; // r14
  __int64 v11; // r12
  char v12; // bl
  char v13; // al
  _BYTE v15[24]; // [rsp+10h] [rbp-60h] BYREF
  __int64 v16; // [rsp+28h] [rbp-48h]
  _BYTE *v17; // [rsp+30h] [rbp-40h]
  __int64 v18; // [rsp+38h] [rbp-38h]
  int v19; // [rsp+44h] [rbp-2Ch]

  v4 = *(_QWORD **)(a1 + 88); /*0x1037b6083*/
  v5 = 8; /*0x1037b6087*/
  if ( (unsigned __int64)v4 < *(_QWORD *)(a1 + 96) ) /*0x1037b6091*/
  {
    v19 = a2; /*0x1037b609d*/
    v18 = a3; /*0x1037b60a0*/
    v8 = v4; /*0x1037b60a4*/
    while ( (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v4 + 16LL))(a1: *v4) != 1 ) /*0x1037b60b2*/
    {
      ++v4; /*0x1037b60b4*/
      ++v8; /*0x1037b60b8*/
      if ( (unsigned __int64)v4 >= *(_QWORD *)(a1 + 96) ) /*0x1037b60c0*/
        return v5; /*0x1037b60c0*/
    }
    v9 = *(_QWORD *)(a1 + 88); /*0x1037b60c7*/
    v10 = (unsigned __int64)v8 - v9; /*0x1037b60cb*/
    if ( (v10 & 0x400000000LL) == 0 ) /*0x1037b60d3*/
    {
      v5 = 9; /*0x1037b60d9*/
      if ( a4 == 16 ) /*0x1037b60e3*/
      {
        v11 = *(_QWORD *)(v9 + 8 * ((v10 >> 3) & 0x7FFFFFFF)); /*0x1037b60f4*/
        v12 = *(_BYTE *)(v11 + 8); /*0x1037b60f8*/
        v13 = RBX::Rupp::TokenTlv::compareEqual(a1: v11, a2: v18, a3: 16); /*0x1037b6109*/
        if ( v12 != (_BYTE)v19 || (v5 = 12, v13 == 0) ) /*0x1037b611b*/
        {
          if ( (unsigned __int8)DFLog::RuppTokenClientLog2 >= 6u && BYTE1(DFLog::RuppTokenClientLog2) >= 6u ) /*0x1037b6136*/
          {
            v16 = 0; /*0x1037b6144*/
            v17 = v15; /*0x1037b6150*/
            FLog::detail::FastLogSafeFormattedInternal( /*0x1037b6174*/
              a1: DFLog::RuppTokenClientLog2,
              a2: qword_10D7B46D8,
              a3: 6,
              a4: (unsigned int)"[DFLog::RuppTokenClientLog2] Updating Rupp token in header.",
              a5: 59,
              a6: 1,
              0,
              v15);
          }
          ++*(_DWORD *)(a1 + 64); /*0x1037b6179*/
          *(_QWORD *)(a1 + 120) = 0; /*0x1037b617d*/
          *(_BYTE *)(v11 + 8) = v19; /*0x1037b6188*/
          return (unsigned int)RBX::Rupp::TokenTlv::setTokenValue(a1: v11, a2: v18, a3: 16); /*0x1037b619e*/
        }
      }
    }
  }
  return v5; /*0x1037b61a4*/
}

// Address: 0x1037b61b4 | Name: __ZN3RBX4Rupp4Rupp9serializeENS_16MutableArrayViewIhEEy
__int64 __fastcall RBX::Rupp::Rupp::serialize(__int64 a1, __int64 a2, void *a3, size_t a4, unsigned __int64 a5)
{
  __int64 v8; // r14
  __int64 v9; // rax
  size_t v10; // rbx
  int updated; // ecx
  unsigned __int64 *v12; // rsi
  unsigned __int64 v13; // rdx
  bool v14; // zf
  unsigned __int64 *v15; // rbx
  int v16; // eax
  unsigned __int64 v17; // rdx
  size_t v18; // rdx
  int v19; // eax
  const void **v20; // r15
  __int64 v21; // r14
  _QWORD *v22; // rbx
  _QWORD *v23; // r13
  __int64 v24; // r14
  __int64 v25; // r12
  __int64 v27; // [rsp+8h] [rbp-48h]
  void *v28; // [rsp+10h] [rbp-40h]
  size_t v29; // [rsp+20h] [rbp-30h]
  unsigned __int64 v30; // [rsp+20h] [rbp-30h]

  v8 = a1; /*0x1037b61ce*/
  *(_DWORD *)(a1 + 4) = 12; /*0x1037b61d1*/
  *(_QWORD *)(a1 + 8) = 0; /*0x1037b61da*/
  *(_BYTE *)(a1 + 16) = 0; /*0x1037b61de*/
  *(_QWORD *)(a1 + 24) = 0; /*0x1037b61e2*/
  v9 = *(_QWORD *)(a2 + 48); /*0x1037b61e6*/
  if ( DFFlag::RuppAllowImmediateTokenRegeneration == 1 ) /*0x1037b61f1*/
  {
    if ( v9 != 0 && (*(_BYTE *)(a2 + 172) != 0 || *(_QWORD *)(a2 + 72) + 1000LL * DFInt::RuppTokenUpdatePeriodMs < a5) ) /*0x1037b621f*/
    {
      v10 = a4; /*0x1037b6225*/
      *(_BYTE *)(a2 + 172) = 0; /*0x1037b6228*/
      updated = RBX::Rupp::Rupp::autoUpdateToken(this: (RBX::Rupp::Rupp *)a2); /*0x1037b6238*/
      v12 = (unsigned __int64 *)(a2 + 72); /*0x1037b623a*/
      v13 = *(_QWORD *)(a2 + 72); /*0x1037b623e*/
      if ( v13 == 0 ) /*0x1037b6245*/
      {
        *v12 = a5; /*0x1037b6247*/
        v13 = a5; /*0x1037b624a*/
      }
      *(_DWORD *)(v8 + 4) = updated; /*0x1037b624d*/
      *(_QWORD *)(v8 + 8) = (a5 - v13) / 0x3E8; /*0x1037b626c*/
      v14 = updated == 0; /*0x1037b6270*/
      a4 = v10; /*0x1037b6272*/
      if ( v14 ) /*0x1037b6275*/
LABEL_14:
        *v12 = a5; /*0x1037b62e4*/
    }
  }
  else if ( v9 != 0 && *(_QWORD *)(a2 + 72) + 1000LL * DFInt::RuppTokenUpdatePeriodMs < a5 ) /*0x1037b6293*/
  {
    v29 = a4; /*0x1037b6295*/
    v15 = (unsigned __int64 *)(a2 + 72); /*0x1037b6299*/
    v16 = RBX::Rupp::Rupp::autoUpdateToken(this: (RBX::Rupp::Rupp *)a2); /*0x1037b62a0*/
    v12 = (unsigned __int64 *)(a2 + 72); /*0x1037b62a5*/
    v17 = *(_QWORD *)(a2 + 72); /*0x1037b62aa*/
    if ( v17 == 0 ) /*0x1037b62b1*/
    {
      *v15 = a5; /*0x1037b62b3*/
      v17 = a5; /*0x1037b62b6*/
    }
    *(_DWORD *)(v8 + 4) = v16; /*0x1037b62b9*/
    *(_QWORD *)(v8 + 8) = (a5 - v17) / 0x3E8; /*0x1037b62d8*/
    a4 = v29; /*0x1037b62de*/
    if ( v16 == 0 ) /*0x1037b62e2*/
      goto LABEL_14; /*0x1037b62e2*/
  }
  v18 = *(_QWORD *)(a2 + 120); /*0x1037b62e7*/
  if ( v18 != 0 ) /*0x1037b62ee*/
  {
    v19 = 11; /*0x1037b62f0*/
    if ( v18 <= a4 ) /*0x1037b62f8*/
    {
      v20 = (const void **)(a2 + 112); /*0x1037b62fe*/
LABEL_27:
      memcpy(__dst: a3, __src: *v20, __n: v18); /*0x1037b6420*/
      v19 = 0; /*0x1037b642b*/
    }
  }
  else
  {
    v30 = a4; /*0x1037b6307*/
    v28 = a3; /*0x1037b630b*/
    v27 = v8; /*0x1037b630f*/
    RBX::SmallVectorImpl<unsigned char>::resizeImpl<false>(a1: a2 + 112, a2: 4); /*0x1037b6320*/
    v21 = *(_QWORD *)(a2 + 112); /*0x1037b6325*/
    *(_BYTE *)v21 = *(_BYTE *)a2; /*0x1037b632c*/
    *(_BYTE *)(v21 + 1) = *(_BYTE *)(a2 + 1); /*0x1037b6333*/
    v22 = *(_QWORD **)(a2 + 88); /*0x1037b6337*/
    v23 = *(_QWORD **)(a2 + 96); /*0x1037b633b*/
    LOWORD(a3) = 4; /*0x1037b633f*/
    if ( v22 != v23 ) /*0x1037b6347*/
    {
      do /*0x1037b6363*/
      {
        LODWORD(a3) = (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v22 + 24LL))(a1: *v22) + (_DWORD)a3 + 2; /*0x1037b6358*/
        ++v22; /*0x1037b635c*/
      }
      while ( v22 != v23 ); /*0x1037b6363*/
      v22 = *(_QWORD **)(a2 + 88); /*0x1037b6365*/
      v23 = *(_QWORD **)(a2 + 96); /*0x1037b6369*/
    }
    *(_WORD *)(v21 + 2) = __ROL2__((_WORD)a3, 8); /*0x1037b6372*/
    while ( v22 != v23 ) /*0x1037b637a*/
    {
      v24 = (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v22 + 24LL))(a1: *v22); /*0x1037b6389*/
      RBX::SmallVectorImpl<unsigned char>::resizeImpl<false>(a1: a2 + 112, a2: v24 + *(_QWORD *)(a2 + 120) + 2); /*0x1037b639d*/
      v25 = *(_QWORD *)(a2 + 120) + *(_QWORD *)(a2 + 112) - v24; /*0x1037b63aa*/
      *(_BYTE *)(v25 - 2) = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v22 + 16LL))(a1: *v22); /*0x1037b63b6*/
      *(_BYTE *)(v25 - 1) = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v22 + 24LL))(a1: *v22); /*0x1037b63c4*/
      if ( (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v22 + 16LL))(a1: *v22) == 1 ) /*0x1037b63d4*/
        *(_DWORD *)(a2 + 168) = v25 - 2 - *(_DWORD *)(a2 + 112) + 10; /*0x1037b63e2*/
      (*(void (__fastcall **)(_QWORD, __int64, __int64))(*(_QWORD *)*v22 + 32LL))(a1: *v22, a2: v25, a3: v24); /*0x1037b63f5*/
      ++v22; /*0x1037b63f8*/
    }
    v18 = *(_QWORD *)(a2 + 120); /*0x1037b6401*/
    v19 = 11; /*0x1037b6409*/
    v8 = v27; /*0x1037b6412*/
    a3 = v28; /*0x1037b6416*/
    v20 = (const void **)(a2 + 112); /*0x1037b641a*/
    if ( v18 - 1 < v30 ) /*0x1037b641e*/
      goto LABEL_27; /*0x1037b641e*/
  }
  *(_DWORD *)v8 = v19; /*0x1037b642d*/
  return v8; /*0x1037b6433*/
}

// Address: 0x1037b6442 | Name: __ZNK3RBX4Rupp4Rupp26isCachedSerializationValidEv
bool __fastcall RBX::Rupp::Rupp::isCachedSerializationValid(RBX::Rupp::Rupp *this)
{
  return *((_QWORD *)this + 15) != 0; /*0x1037b644e*/
}

// Address: 0x1037b6450 | Name: __ZNK3RBX4Rupp4Rupp15dumpCachedValueENS_16MutableArrayViewIhEE
__int64 __fastcall RBX::Rupp::Rupp::dumpCachedValue(__int64 a1, void *a2, size_t a3)
{
  size_t v4; // rdx
  __int64 result; // rax

  v4 = *(_QWORD *)(a1 + 120); /*0x1037b6453*/
  result = 11; /*0x1037b6457*/
  if ( v4 <= a3 ) /*0x1037b645f*/
  {
    memcpy(__dst: a2, __src: *(const void **)(a1 + 112), __n: v4); /*0x1037b646f*/
    return 0; /*0x1037b6474*/
  }
  return result; /*0x1037b6477*/
}

// Address: 0x1037b6478 | Name: __ZN3RBX4Rupp4Rupp36updateTokenFromDeserializationResultERKNS0_21DeserializationResultEy
__int64 __fastcall RBX::Rupp::Rupp::updateTokenFromDeserializationResult(__int64 a1, __int64 a2, __int64 a3)
{
  unsigned __int8 v3; // cl
  __int64 result; // rax

  v3 = *(_BYTE *)(a2 + 4); /*0x1037b647c*/
  if ( v3 == 0 ) /*0x1037b6481*/
    return 9; /*0x1037b64a5*/
  result = 12; /*0x1037b6483*/
  if ( *(_QWORD *)(a1 + 48) == 0 ) /*0x1037b648d*/
  {
    *(_QWORD *)(a1 + 80) = a3; /*0x1037b648f*/
    return RBX::Rupp::Rupp::updateTokenTlv(a1, a2: v3, a3: *(_QWORD *)(a2 + 8), a4: 16); /*0x1037b64a0*/
  }
  return result; /*0x1037b649f*/
}

// Address: 0x1037b64ac | Name: __ZN3RBX4Rupp4Rupp11deserializeERNS0_21DeserializationResultENS_9ArrayViewIhEE
__int64 __fastcall RBX::Rupp::Rupp::deserialize(__int64 a1, unsigned __int8 *a2, unsigned __int64 a3)
{
  __int64 result; // rax
  unsigned int v4; // r9d
  __int16 v5; // r8
  unsigned __int16 v6; // cx
  int v7; // r10d

  result = 1; /*0x1037b64b0*/
  if ( a3 >= 4 ) /*0x1037b64b9*/
  {
    v4 = *a2; /*0x1037b64bb*/
    *(_BYTE *)(a1 + 2) = v4; /*0x1037b64bf*/
    *(_BYTE *)(a1 + 3) = a2[1]; /*0x1037b64c6*/
    v5 = *((_WORD *)a2 + 1); /*0x1037b64c9*/
    v6 = __ROL2__(v5, 8); /*0x1037b64d1*/
    *(_WORD *)a1 = v6; /*0x1037b64d5*/
    result = 2; /*0x1037b64d8*/
    if ( v4 <= 4 ) /*0x1037b64e1*/
    {
      v7 = 26; /*0x1037b64e3*/
      if ( _bittest(&v7, v4) ) /*0x1037b64e9*/
      {
        result = 4; /*0x1037b64ef*/
        if ( v6 >= 4u ) /*0x1037b64f8*/
        {
          result = 0; /*0x1037b64fe*/
          if ( v5 != 1024 ) /*0x1037b6507*/
          {
            result = 1; /*0x1037b650c*/
            if ( v6 <= a3 ) /*0x1037b6514*/
              return RBX::Rupp::Rupp::deserializeTlvs(a1, a2: a2 + 4, a3: v6 - 4LL); /*0x1037b6524*/
          }
        }
      }
    }
  }
  return result; /*0x1037b6516*/
}

// Address: 0x1037b652a | Name: __ZN3RBX4Rupp4Rupp15deserializeTlvsERNS0_21DeserializationResultENS_9ArrayViewIhEE
__int64 __fastcall RBX::Rupp::Rupp::deserializeTlvs(__int64 a1, _BYTE *a2, __int64 a3)
{
  _BYTE *v3; // r14
  unsigned __int64 v5; // rbx
  __int64 result; // rax
  unsigned __int64 v7; // rdx
  _BYTE *v8; // rsi
  __int64 v9; // r12
  __int64 v10; // [rsp-38h] [rbp-38h]

  if ( a3 <= 0 ) /*0x1037b652d*/
    return 0; /*0x1037b6617*/
  v3 = a2; /*0x1037b6544*/
  v5 = (unsigned __int64)&a2[a3]; /*0x1037b654a*/
  v10 = (__int64)&a2[a3 - 2]; /*0x1037b6551*/
  while ( 2 ) /*0x1037b6565*/
  {
    if ( DFFlag::RuppTlvBoundsCheck == 1 ) /*0x1037b6565*/
    {
      result = 1; /*0x1037b656d*/
      if ( v5 - (unsigned __int64)v3 <= 1 ) /*0x1037b6576*/
        return result; /*0x1037b6576*/
      v7 = (unsigned __int8)v3[1]; /*0x1037b657c*/
      if ( v10 - (__int64)v3 < v7 ) /*0x1037b658b*/
        return result; /*0x1037b658b*/
    }
    else
    {
      LOBYTE(v7) = v3[1]; /*0x1037b658f*/
    }
    result = 1; /*0x1037b6597*/
    v8 = v3 + 2; /*0x1037b65a3*/
    v9 = (unsigned __int8)v7; /*0x1037b65af*/
    switch ( *v3 ) /*0x1037b65b3*/
    {
      case 1: /*0x1037b65b3*/
        if ( DFFlag::RuppTlvBoundsCheck == 0 || (unsigned __int8)v7 >= 0x11u ) /*0x1037b65bc*/
        {
          result = RBX::Rupp::TokenTlv::deserialize(a1, a2: v8, a3: 17); /*0x1037b65c6*/
          goto LABEL_15; /*0x1037b65cb*/
        }
        return result; /*0x1037b65bc*/
      case 2: /*0x1037b65b3*/
      case 3: /*0x1037b65b3*/
        goto LABEL_16;
      case 6: /*0x1037b65b3*/
        result = RBX::Rupp::Ipv4ReverseEndpointTlv::deserialize(a1, a2: v8, a3: (unsigned __int8)v7); /*0x1037b65e0*/
        goto LABEL_15; /*0x1037b65e5*/
      case 7: /*0x1037b65b3*/
        result = RBX::Rupp::Ipv6ReverseEndpointTlv::deserialize(a1, a2: v8, a3: (unsigned __int8)v7); /*0x1037b65ed*/
        goto LABEL_15; /*0x1037b65ed*/
      case 8: /*0x1037b65b3*/
        result = RBX::Rupp::TraceIdTlv::deserialize(a1, a2: v8, a3: (unsigned __int8)v7); /*0x1037b65d3*/
LABEL_15:
        if ( (_DWORD)result != 0 ) /*0x1037b65f4*/
          return result; /*0x1037b65f4*/
LABEL_16:
        v3 += v9 + 2; /*0x1037b65f6*/
        if ( (unsigned __int64)v3 < v5 ) /*0x1037b6600*/
          continue; /*0x1037b6600*/
        result = 0; /*0x1037b6606*/
        break; /*0x1037b6606*/
      default:
        return result;
    }
    return result; /*0x1037b6616*/
  }
}

// Address: 0x1037b663c | Name: __ZN3RBX4Rupp4Rupp18addIpv4EndpointTlvE7in_addrt
__int64 __fastcall RBX::Rupp::Rupp::addIpv4EndpointTlv(RBX::Rupp::Rupp *this, in_addr a2, unsigned __int16 a3)
{
  RBX::Rupp::Ipv4Tlv *v6; // r14
  unsigned int v7; // ebx
  RBX::Rupp::Ipv4Tlv *v8; // rdi
  RBX::Rupp::Ipv4Tlv *v10; // [rsp+8h] [rbp-28h] BYREF

  v6 = (RBX::Rupp::Ipv4Tlv *)operator new(a1: 0x10u); /*0x1037b665e*/
  RBX::Rupp::Ipv4Tlv::Ipv4Tlv(this: v6, a2, a3); /*0x1037b666a*/
  v10 = v6; /*0x1037b6673*/
  v7 = RBX::Rupp::Rupp::addTlv(a1: this, a2: &v10); /*0x1037b667e*/
  v8 = v10; /*0x1037b6680*/
  v10 = nullptr; /*0x1037b6684*/
  if ( v8 != nullptr ) /*0x1037b668f*/
    (*(void (__fastcall **)(RBX::Rupp::Ipv4Tlv *))(*(_QWORD *)v8 + 8LL))(a1: v8); /*0x1037b6694*/
  return v7; /*0x1037b6699*/
}

// Address: 0x1037b66d6 | Name: __ZN3RBX4Rupp4Rupp11addTokenTlvERKNS0_8TokenTlv5TokenE
__int64 __fastcall RBX::Rupp::Rupp::addTokenTlv(_QWORD *a1, __int64 a2)
{
  __int64 v4; // r14
  int v5; // edx
  int v6; // ecx
  int v7; // esi
  int v8; // r8d
  int v9; // r9d
  unsigned int v10; // ebx
  __int64 v11; // rdi
  __int64 v13; // [rsp+18h] [rbp-48h] BYREF
  __int128 v14; // [rsp+20h] [rbp-40h]
  char v15; // [rsp+30h] [rbp-30h]

  v4 = operator new(a1: 0x20u); /*0x1037b6701*/
  v15 = *(_BYTE *)(a2 + 16); /*0x1037b6708*/
  v14 = *(_OWORD *)a2; /*0x1037b670f*/
  RBX::Rupp::TokenTlv::TokenTlv(a1: v4, a2: v7, a3: v5, a4: v6, a5: v8, a6: v9, a7: v14, a8: v15); /*0x1037b6725*/
  v13 = v4; /*0x1037b672e*/
  v10 = RBX::Rupp::Rupp::addTlv(a1, a2: &v13); /*0x1037b6739*/
  v11 = v13; /*0x1037b673b*/
  v13 = 0; /*0x1037b673f*/
  if ( v11 != 0 ) /*0x1037b674a*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v11 + 8LL))(a1: v11); /*0x1037b674f*/
  return v10; /*0x1037b6764*/
}

// Address: 0x1037b67a4 | Name: __ZN3RBX4Rupp4Rupp17setMigrationTokenENS0_9TokenTypeENS_9ArrayViewIhEE
__int64 __fastcall RBX::Rupp::Rupp::setMigrationToken(__int64 a1, int a2, __int64 a3, __int64 a4)
{
  return RBX::Rupp::Rupp::updateTokenTlv(a1, a2, a3, a4); /*0x1037b67a8*/
}

// Address: 0x1037b67ae | Name: __ZN3RBX4Rupp4Rupp33requestImmediateTokenRegenerationEv
void __fastcall RBX::Rupp::Rupp::requestImmediateTokenRegeneration(RBX::Rupp::Rupp *this)
{
  *((_BYTE *)this + 172) = 1; /*0x1037b67b2*/
}

// Address: 0x1037b67bc | Name: __ZN3RBX4Rupp4Rupp17addTokenGeneratorENSt3__18functionIFvRNS0_8TokenTlv5TokenEEEE
__int64 __fastcall RBX::Rupp::Rupp::addTokenGenerator(__int64 a1)
{
  std::__function::__value_func<void ()(RBX::Rupp::TokenTlv::Token &)>::operator=[abi:ne200100](a1: a1 + 16); /*0x1037b67c4*/
  return 0; /*0x1037b67cb*/
}

// Address: 0x1037b67d6 | Name: __ZNK3RBX4Rupp4Rupp18getIpv4EndpointTlvER7in_addrRt
__int64 __fastcall RBX::Rupp::Rupp::getIpv4EndpointTlv(RBX::Rupp::Rupp *this, in_addr *a2, unsigned __int16 *a3)
{
  _QWORD *v3; // r13
  unsigned int v4; // r14d
  __int64 v7; // rbx
  __int64 v8; // rax
  __int64 v9; // rbx
  __int64 v10; // rax

  v3 = *((_QWORD **)this + 11); /*0x1037b67e4*/
  v4 = 8; /*0x1037b67e8*/
  if ( (unsigned __int64)v3 < *((_QWORD *)this + 12) ) /*0x1037b67f2*/
  {
    v7 = *((_QWORD *)this + 11); /*0x1037b67fe*/
    while ( (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 16LL))(a1: *v3) != 2 ) /*0x1037b680d*/
    {
      ++v3; /*0x1037b680f*/
      v7 += 8; /*0x1037b6813*/
      if ( (unsigned __int64)v3 >= *((_QWORD *)this + 12) ) /*0x1037b681c*/
        return v4; /*0x1037b681c*/
    }
    v8 = *((_QWORD *)this + 11); /*0x1037b6820*/
    v9 = v7 - v8; /*0x1037b6825*/
    if ( (v9 & 0x400000000LL) == 0 ) /*0x1037b682d*/
    {
      v10 = *(_QWORD *)(v8 + (v9 & 0x3FFFFFFF8LL)); /*0x1037b683c*/
      a2->s_addr = *(in_addr_t *)(v10 + 8); /*0x1037b6843*/
      *a3 = *(_WORD *)(v10 + 12); /*0x1037b684e*/
      return 0; /*0x1037b6851*/
    }
  }
  return v4; /*0x1037b685b*/
}

// Address: 0x1037b6866 | Name: __ZN3RBX4Rupp4Rupp13addTraceIdTlvERKNS_7Guid128E
__int64 __fastcall RBX::Rupp::Rupp::addTraceIdTlv(_QWORD *a1, __int64 a2)
{
  __int64 v4; // r14
  unsigned int v5; // ebx
  __int64 v6; // rdi
  __int64 v8[4]; // [rsp+0h] [rbp-20h] BYREF

  v4 = operator new(a1: 0x18u); /*0x1037b6880*/
  RBX::Rupp::TraceIdTlv::TraceIdTlv(a1: v4, a2); /*0x1037b6889*/
  v8[0] = v4; /*0x1037b6892*/
  v5 = RBX::Rupp::Rupp::addTlv(a1, a2: v8); /*0x1037b689d*/
  v6 = v8[0]; /*0x1037b689f*/
  v8[0] = 0; /*0x1037b68a3*/
  if ( v6 != 0 ) /*0x1037b68ae*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v6 + 8LL))(a1: v6); /*0x1037b68b3*/
  return v5; /*0x1037b68bc*/
}

// Address: 0x1037b68f2 | Name: __ZNK3RBX4Rupp4Rupp13getTraceIdTlvERNS_7Guid128E
__int64 __fastcall RBX::Rupp::Rupp::getTraceIdTlv(__int64 a1, _OWORD *a2)
{
  _QWORD *v2; // r13
  unsigned int v3; // ebx
  __int64 v6; // r12
  __int64 v7; // rax
  __int64 v8; // r12

  v2 = *(_QWORD **)(a1 + 88); /*0x1037b6900*/
  v3 = 8; /*0x1037b6904*/
  if ( (unsigned __int64)v2 < *(_QWORD *)(a1 + 96) ) /*0x1037b690d*/
  {
    v6 = *(_QWORD *)(a1 + 88); /*0x1037b6915*/
    while ( (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v2 + 16LL))(a1: *v2) != 8 ) /*0x1037b6924*/
    {
      ++v2; /*0x1037b6926*/
      v6 += 8; /*0x1037b692a*/
      if ( (unsigned __int64)v2 >= *(_QWORD *)(a1 + 96) ) /*0x1037b6932*/
        return v3; /*0x1037b6932*/
    }
    v7 = *(_QWORD *)(a1 + 88); /*0x1037b6936*/
    v8 = v6 - v7; /*0x1037b693a*/
    if ( (v8 & 0x400000000LL) == 0 ) /*0x1037b6942*/
    {
      *a2 = *(_OWORD *)(*(_QWORD *)(v7 + (v8 & 0x3FFFFFFF8LL)) + 8LL); /*0x1037b6959*/
      return 0; /*0x1037b695d*/
    }
  }
  return v3; /*0x1037b6965*/
}

// Address: 0x1037b6970 | Name: __ZN3RBX4Rupp4Rupp25addIpv4ReverseEndpointTlvEPKct
__int64 __fastcall RBX::Rupp::Rupp::addIpv4ReverseEndpointTlv(
        RBX::Rupp::Rupp *this,
        const char *a2,
        unsigned __int16 a3)
{
  unsigned int v5; // r15d
  RBX::Rupp::Ipv4ReverseEndpointTlv *v6; // r15
  RBX::Rupp::Ipv4ReverseEndpointTlv *v7; // rdi
  in_addr v9; // [rsp+Ch] [rbp-24h] BYREF
  RBX::Rupp::Ipv4ReverseEndpointTlv *v10; // [rsp+10h] [rbp-20h] BYREF

  v9.s_addr = 0; /*0x1037b6987*/
  v5 = 10; /*0x1037b6997*/
  if ( inet_pton(a1: 2, a2, a3: &v9) == 1 ) /*0x1037b69a0*/
  {
    v6 = (RBX::Rupp::Ipv4ReverseEndpointTlv *)operator new(a1: 0x10u); /*0x1037b69ac*/
    RBX::Rupp::Ipv4ReverseEndpointTlv::Ipv4ReverseEndpointTlv(this: v6, a2: v9, a3); /*0x1037b69b9*/
    v10 = v6; /*0x1037b69c2*/
    v5 = RBX::Rupp::Rupp::addTlv(a1: this, a2: &v10); /*0x1037b69cd*/
    v7 = v10; /*0x1037b69d0*/
    v10 = nullptr; /*0x1037b69d4*/
    if ( v7 != nullptr ) /*0x1037b69df*/
      (*(void (__fastcall **)(RBX::Rupp::Ipv4ReverseEndpointTlv *))(*(_QWORD *)v7 + 8LL))(a1: v7); /*0x1037b69e4*/
  }
  return v5; /*0x1037b69ea*/
}

// Address: 0x1037b6a24 | Name: __ZN3RBX4Rupp4Rupp18addIpv6EndpointTlvE8in6_addrt
__int64 __fastcall RBX::Rupp::Rupp::addIpv6EndpointTlv(RBX::Rupp::Rupp *this, in6_addr a2, unsigned __int16 a3)
{
  unsigned __int64 v4; // r12
  unsigned __int64 v5; // r13
  RBX::Rupp::Ipv6Tlv *v7; // r14
  unsigned int v8; // ebx
  RBX::Rupp::Ipv6Tlv *v9; // rdi
  RBX::Rupp::Ipv6Tlv *v11; // [rsp+0h] [rbp-30h] BYREF

  v4 = *(_QWORD *)&a2.__u6_addr32[2]; /*0x1037b6a35*/
  v5 = *(_QWORD *)a2.__u6_addr8; /*0x1037b6a38*/
  v7 = (RBX::Rupp::Ipv6Tlv *)operator new(a1: 0x20u); /*0x1037b6a48*/
  RBX::Rupp::Ipv6Tlv::Ipv6Tlv(this: v7, a2: (in6_addr)__PAIR128__(v4, v5), a3); /*0x1037b6a57*/
  v11 = v7; /*0x1037b6a60*/
  v8 = RBX::Rupp::Rupp::addTlv(a1: this, a2: &v11); /*0x1037b6a6b*/
  v9 = v11; /*0x1037b6a6d*/
  v11 = nullptr; /*0x1037b6a71*/
  if ( v9 != nullptr ) /*0x1037b6a7c*/
    (*(void (__fastcall **)(RBX::Rupp::Ipv6Tlv *))(*(_QWORD *)v9 + 8LL))(a1: v9); /*0x1037b6a81*/
  return v8; /*0x1037b6a8a*/
}

// Address: 0x1037b6ac4 | Name: __ZNK3RBX4Rupp4Rupp18getIpv6EndpointTlvER8in6_addrRt
__int64 __fastcall RBX::Rupp::Rupp::getIpv6EndpointTlv(RBX::Rupp::Rupp *this, in6_addr *a2, unsigned __int16 *a3)
{
  _QWORD *v3; // r13
  unsigned int v4; // r14d
  __int64 v7; // rbx
  __int64 v8; // rax
  __int64 v9; // rbx
  __int64 v10; // rax

  v3 = *((_QWORD **)this + 11); /*0x1037b6ad2*/
  v4 = 8; /*0x1037b6ad6*/
  if ( (unsigned __int64)v3 < *((_QWORD *)this + 12) ) /*0x1037b6ae0*/
  {
    v7 = *((_QWORD *)this + 11); /*0x1037b6aec*/
    while ( (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 16LL))(a1: *v3) != 3 ) /*0x1037b6afb*/
    {
      ++v3; /*0x1037b6afd*/
      v7 += 8; /*0x1037b6b01*/
      if ( (unsigned __int64)v3 >= *((_QWORD *)this + 12) ) /*0x1037b6b0a*/
        return v4; /*0x1037b6b0a*/
    }
    v8 = *((_QWORD *)this + 11); /*0x1037b6b0e*/
    v9 = v7 - v8; /*0x1037b6b13*/
    if ( (v9 & 0x400000000LL) == 0 ) /*0x1037b6b1b*/
    {
      v10 = *(_QWORD *)(v8 + (v9 & 0x3FFFFFFF8LL)); /*0x1037b6b2a*/
      *a2 = *(in6_addr *)(v10 + 8); /*0x1037b6b32*/
      *a3 = *(_WORD *)(v10 + 24); /*0x1037b6b3e*/
      return 0; /*0x1037b6b41*/
    }
  }
  return v4; /*0x1037b6b4b*/
}

// Address: 0x1037b6b56 | Name: __ZN3RBX4Rupp4Rupp25addIpv6ReverseEndpointTlvEPKct
__int64 __fastcall RBX::Rupp::Rupp::addIpv6ReverseEndpointTlv(
        RBX::Rupp::Rupp *this,
        const char *a2,
        unsigned __int16 a3)
{
  unsigned int v5; // r15d
  RBX::Rupp::Ipv6ReverseEndpointTlv *v6; // r15
  RBX::Rupp::Ipv6ReverseEndpointTlv *v7; // rdi
  in6_addr v9; // [rsp+0h] [rbp-30h] BYREF
  RBX::Rupp::Ipv6ReverseEndpointTlv *v10; // [rsp+10h] [rbp-20h] BYREF

  v9 = 0; /*0x1037b6b70*/
  v5 = 10; /*0x1037b6b7d*/
  if ( inet_pton(a1: 30, a2, a3: &v9) == 1 ) /*0x1037b6b86*/
  {
    v6 = (RBX::Rupp::Ipv6ReverseEndpointTlv *)operator new(a1: 0x20u); /*0x1037b6b92*/
    RBX::Rupp::Ipv6ReverseEndpointTlv::Ipv6ReverseEndpointTlv(this: v6, a2: v9, a3); /*0x1037b6ba4*/
    v10 = v6; /*0x1037b6bad*/
    v5 = RBX::Rupp::Rupp::addTlv(a1: this, a2: &v10); /*0x1037b6bb8*/
    v7 = v10; /*0x1037b6bbb*/
    v10 = nullptr; /*0x1037b6bbf*/
    if ( v7 != nullptr ) /*0x1037b6bca*/
      (*(void (__fastcall **)(RBX::Rupp::Ipv6ReverseEndpointTlv *))(*(_QWORD *)v7 + 8LL))(a1: v7); /*0x1037b6bcf*/
  }
  return v5; /*0x1037b6bd5*/
}

// Address: 0x1037b6c10 | Name: __ZNK3RBX4Rupp4Rupp6hasTlvENS0_7TlvTypeE
bool __fastcall RBX::Rupp::Rupp::hasTlv(__int64 a1, char a2)
{
  _QWORD *v2; // r15
  __int64 v5; // r12

  v2 = *(_QWORD **)(a1 + 88); /*0x1037b6c1b*/
  if ( (unsigned __int64)v2 >= *(_QWORD *)(a1 + 96) ) /*0x1037b6c23*/
    return false; /*0x1037b6c4a*/
  v5 = *(_QWORD *)(a1 + 88); /*0x1037b6c2b*/
  while ( (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)*v2 + 16LL))(a1: *v2) != a2 ) /*0x1037b6c3a*/
  {
    ++v2; /*0x1037b6c3c*/
    v5 += 8; /*0x1037b6c40*/
    if ( (unsigned __int64)v2 >= *(_QWORD *)(a1 + 96) ) /*0x1037b6c48*/
      return false; /*0x1037b6c48*/
  }
  return ((v5 - *(_QWORD *)(a1 + 88)) & 0x400000000LL) == 0; /*0x1037b6c5a*/
}

// Address: 0x1037b6f66 | Name: __ZN3RBX4Rupp30reportRuppInitStats_deprecatedENS0_9RuppError9ErrorCodeEb
void __fastcall RBX::Rupp::reportRuppInitStats_deprecated(unsigned int a1, unsigned __int8 a2)
{
  __int64 v4; // rax
  void *v5[9]; // [rsp+8h] [rbp-238h] BYREF
  _BYTE v6[496]; // [rsp+50h] [rbp-1F0h] BYREF

  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter(a1: v5, a2: (__int64)&RBX::Telemetry::kRuppInitResult); /*0x1037b6f8a*/
  RBX::Telemetry::FieldsContainer::addField(a1: v6, a2: "errorCode", a3: 9, a4: (int)a1, a5: 1); /*0x1037b6fae*/
  v4 = RBX::Rupp::RuppError::toString(a1); /*0x1037b6fb6*/
  RBX::Telemetry::FieldsContainer::addField(a1: v6, a2: "errorMessage", a3: 12, a4: v4, a5: 1); /*0x1037b6fd3*/
  RBX::Telemetry::FieldsContainer::addField(a1: v6, a2: "directServerReturn", a3: 18, a4: a2, a5: 1); /*0x1037b6ff1*/
  RBX::Telemetry::FieldsContainer::addDatacenterId(this: (RBX::Telemetry::FieldsContainer *)v6); /*0x1037b6ff9*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v5); /*0x1037b7005*/
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v6); /*0x1037b7018*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v5, a2: (void **)off_10C8C7EB0); /*0x1037b702b*/
}

// Address: 0x1037b7057 | Name: __ZN3RBX4Rupp32reportRuppMissingTlvs_deprecatedEbb
void __fastcall RBX::Rupp::reportRuppMissingTlvs_deprecated(RBX::Rupp *this, unsigned __int8 a2)
{
  unsigned int v3; // r14d
  RBX *v4; // rdi
  _BYTE v5[72]; // [rsp+8h] [rbp-498h] BYREF
  _BYTE v6[528]; // [rsp+50h] [rbp-450h] BYREF
  void *v7[9]; // [rsp+260h] [rbp-240h] BYREF
  _BYTE v8[504]; // [rsp+2A8h] [rbp-1F8h] BYREF

  v3 = (unsigned int)this; /*0x1037b706c*/
  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1037b707d*/
    a1: v7,
    a2: (__int64)&RBX::Telemetry::kRuppMissingTlvsCounter);
  RBX::Telemetry::FieldsContainer::addField(a1: v8, a2: "missingTokenTlv", a3: 15, a4: v3, a5: 1); /*0x1037b70a1*/
  RBX::Telemetry::FieldsContainer::addField(a1: v8, a2: "missingEndpointTlv", a3: 18, a4: a2, a5: 1); /*0x1037b70c2*/
  RBX::Telemetry::FieldsContainer::addDatacenterId(this: (RBX::Telemetry::FieldsContainer *)v8); /*0x1037b70ca*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v7); /*0x1037b70d6*/
  if ( (unsigned int)RBX::globalRand(this: v4) % 0x2710 < DFInt::RuppMissingTlvsPointsThrottleHundredthsPercent ) /*0x1037b70fd*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1037b710d*/
      a1: (__int64)v5,
      a2: (__int64)&RBX::Telemetry::kRuppMissingTlvsPoints);
    RBX::Telemetry::FieldsContainer::addField(a1: v6, a2: "missingTokenTlv", a3: 15, a4: (unsigned __int8)v3, a5: 1); /*0x1037b7132*/
    RBX::Telemetry::FieldsContainer::addField(a1: v6, a2: "missingEndpointTlv", a3: 18, a4: a2, a5: 1); /*0x1037b714f*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v5); /*0x1037b715b*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent( /*0x1037b716e*/
      this: (RBX::Telemetry::RobloxTelemetryEvent *)v5,
      a2: (void **)`VTT for'RBX::Telemetry::RobloxTelemetryEvent);
  }
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v8); /*0x1037b7181*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v7, a2: (void **)off_10C8C7EB0); /*0x1037b7194*/
}

// Address: 0x1037b71db | Name: __ZN3RBX4Rupp43reportRuppDeserializationFailure_deprecatedENS0_9RuppError9ErrorCodeEyb
void __fastcall RBX::Rupp::reportRuppDeserializationFailure_deprecated(unsigned int a1, __int64 a2, char a3)
{
  __int64 v6; // rax
  __int64 v7; // rax
  _BYTE v8[72]; // [rsp+0h] [rbp-4A0h] BYREF
  _BYTE v9[528]; // [rsp+48h] [rbp-458h] BYREF
  void *v10[9]; // [rsp+258h] [rbp-248h] BYREF
  _BYTE v11[512]; // [rsp+2A0h] [rbp-200h] BYREF

  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1037b7206*/
    a1: v10,
    a2: (__int64)&RBX::Telemetry::kRuppDeserializationFailureCounter);
  RBX::Telemetry::FieldsContainer::addField(a1: v11, a2: "errorCode", a3: 9, a4: (int)a1, a5: 1); /*0x1037b722d*/
  v6 = RBX::Rupp::RuppError::toString(a1); /*0x1037b7235*/
  RBX::Telemetry::FieldsContainer::addField(a1: v11, a2: "errorMessage", a3: 12, a4: v6, a5: 1); /*0x1037b7252*/
  RBX::Telemetry::FieldsContainer::addField(a1: v11, a2: "fromConnectedSystem", a3: 19, a4: a2 != 0, a5: 1); /*0x1037b7274*/
  RBX::Telemetry::FieldsContainer::addDatacenterId(this: (RBX::Telemetry::FieldsContainer *)v11); /*0x1037b727c*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v10); /*0x1037b7288*/
  if ( a3 != 0 ) /*0x1037b7290*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1037b72a4*/
      a1: (__int64)v8,
      a2: (__int64)&RBX::Telemetry::kRuppDeserializationFailurePoints);
    RBX::Telemetry::FieldsContainer::addField(a1: v9, a2: "errorCode", a3: 9, a4: (int)a1, a5: 1); /*0x1037b72c8*/
    v7 = RBX::Rupp::RuppError::toString(a1); /*0x1037b72d0*/
    RBX::Telemetry::FieldsContainer::addField(a1: v9, a2: "errorMessage", a3: 12, a4: v7, a5: 1); /*0x1037b72ed*/
    RBX::Telemetry::FieldsContainer::addField(a1: v9, a2: "connectionAgeMs", a3: 15, a4: a2, a5: 1); /*0x1037b730a*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v8); /*0x1037b7316*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent( /*0x1037b7329*/
      this: (RBX::Telemetry::RobloxTelemetryEvent *)v8,
      a2: (void **)`VTT for'RBX::Telemetry::RobloxTelemetryEvent);
  }
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v11); /*0x1037b733c*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v10, a2: (void **)off_10C8C7EB0); /*0x1037b734f*/
}

// Address: 0x1037b7397 | Name: __ZN3RBX4Rupp41reportRuppSerializationFailure_deprecatedERKNS0_4RuppERKNS0_19SerializationResultEyyb
void __fastcall RBX::Rupp::reportRuppSerializationFailure_deprecated(
        RBX::Rupp::Rupp *a1,
        unsigned int *a2,
        __int64 a3,
        __int64 a4,
        int a5)
{
  unsigned __int16 HeaderTotalByteLength; // r15
  __int64 v9; // rax
  bool isValidRuppLength; // al
  __int64 v11; // rcx
  unsigned int v12; // r15d
  __int64 v13; // rbx
  _BYTE *v14; // r14
  bool hasTlv; // al
  unsigned int v16; // r12d
  __int64 v17; // rbx
  _BYTE *v18; // r14
  bool v19; // al
  unsigned int v20; // r12d
  __int64 v21; // rbx
  _BYTE *v22; // r14
  bool v23; // al
  char v24; // r13
  unsigned int *v25; // rbx
  __int64 v26; // r14
  __int64 v27; // r15
  _BYTE *v28; // r12
  __int64 v29; // rax
  int i; // r15d
  _BYTE *v31; // rbx
  unsigned int v32; // r12d
  __int64 (__fastcall *v33)(_BYTE *, __int64, __int64 *); // r14
  char *v34; // r13
  bool v35; // al
  void *v36[9]; // [rsp+8h] [rbp-508h] BYREF
  _BYTE v37[472]; // [rsp+50h] [rbp-4C0h] BYREF
  unsigned __int8 v38; // [rsp+228h] [rbp-2E8h] BYREF
  _BYTE v39[7]; // [rsp+229h] [rbp-2E7h] BYREF
  __int64 v40; // [rsp+230h] [rbp-2E0h]
  void *v41; // [rsp+238h] [rbp-2D8h]
  _BYTE v42[528]; // [rsp+270h] [rbp-2A0h] BYREF
  __int64 v43; // [rsp+480h] [rbp-90h]
  __int64 v44; // [rsp+488h] [rbp-88h]
  unsigned int *v45; // [rsp+490h] [rbp-80h]
  __int64 v46; // [rsp+498h] [rbp-78h]
  _QWORD v47[3]; // [rsp+4A0h] [rbp-70h] BYREF
  int v48; // [rsp+4BCh] [rbp-54h]
  _QWORD *v49; // [rsp+4C0h] [rbp-50h] BYREF
  __int64 (__fastcall *v50)(_BYTE *, __int64, __int64 *); // [rsp+4C8h] [rbp-48h]
  void *v51; // [rsp+4D0h] [rbp-40h]
  RBX::Rupp::Rupp *v52; // [rsp+4D8h] [rbp-38h]
  char v53; // [rsp+4E7h] [rbp-29h] BYREF

  v46 = a4; /*0x1037b73ae*/
  v52 = a1; /*0x1037b73b8*/
  HeaderTotalByteLength = RBX::Rupp::Rupp::getHeaderTotalByteLength(this: a1); /*0x1037b73c1*/
  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1037b73d2*/
    a1: v36,
    a2: (__int64)&RBX::Telemetry::kRuppSerializationFailureCounter);
  RBX::Telemetry::FieldsContainer::addField(a1: v37, a2: "errorCode", a3: 9, a4: (int)*a2, a5: 1); /*0x1037b73f7*/
  v9 = RBX::Rupp::RuppError::toString(a1: *a2); /*0x1037b7400*/
  RBX::Telemetry::FieldsContainer::addField(a1: v37, a2: "errorMessage", a3: 12, a4: v9, a5: 1); /*0x1037b741d*/
  RBX::Telemetry::FieldsContainer::addField(a1: v37, a2: "fromConnectedSystem", a3: 19, a4: a3 != 0, a5: 1); /*0x1037b743f*/
  RBX::Telemetry::FieldsContainer::addField(a1: v37, a2: "tokenGenerated", a3: 14, a4: a2[1] == 0, a5: 1); /*0x1037b7464*/
  isValidRuppLength = RBX::Rupp::Rupp::isValidRuppLength(this: (RBX::Rupp::Rupp *)HeaderTotalByteLength); /*0x1037b7470*/
  v11 = -1; /*0x1037b7477*/
  if ( isValidRuppLength ) /*0x1037b747e*/
    v11 = HeaderTotalByteLength; /*0x1037b747e*/
  RBX::Telemetry::FieldsContainer::addField(a1: v37, a2: "ruppHeaderLength", a3: 16, a4: v11, a5: 1); /*0x1037b7497*/
  v48 = a5; /*0x1037b749c*/
  v44 = HeaderTotalByteLength; /*0x1037b74a0*/
  v43 = a3; /*0x1037b74a7*/
  LOBYTE(v47[0]) = 1; /*0x1037b74b2*/
  v49 = v47; /*0x1037b74bb*/
  v50 = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Rupp::TlvType,fmt::v8::formatter<RBX::Rupp::TlvType,char,void>>; /*0x1037b74c5*/
  fmt::v8::vformat(a1: &v38, a2: "has{}", a3: 5, a4: 15, a5: &v49); /*0x1037b74e1*/
  v12 = v38; /*0x1037b74e6*/
  v13 = v40; /*0x1037b74ee*/
  v14 = v41; /*0x1037b74f5*/
  hasTlv = RBX::Rupp::Rupp::hasTlv(a1: (__int64)v52, a2: 1); /*0x1037b7505*/
  if ( (v12 & 1) == 0 ) /*0x1037b7513*/
  {
    v13 = v12 >> 1; /*0x1037b7513*/
    v14 = v39; /*0x1037b751e*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v37, a2: v14, a3: v13, a4: hasTlv, a5: 1); /*0x1037b7538*/
  if ( (v38 & 1) != 0 ) /*0x1037b7544*/
    operator delete(a1: v41); /*0x1037b754d*/
  v45 = a2; /*0x1037b7552*/
  LOBYTE(v47[0]) = 2; /*0x1037b7556*/
  v49 = v47; /*0x1037b755e*/
  v50 = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Rupp::TlvType,fmt::v8::formatter<RBX::Rupp::TlvType,char,void>>; /*0x1037b7568*/
  fmt::v8::vformat(a1: &v38, a2: "has{}", a3: 5, a4: 15, a5: &v49); /*0x1037b7584*/
  v16 = v38; /*0x1037b7589*/
  v17 = v40; /*0x1037b7591*/
  v18 = v41; /*0x1037b7598*/
  v19 = RBX::Rupp::Rupp::hasTlv(a1: (__int64)v52, a2: 2); /*0x1037b75a8*/
  if ( (v16 & 1) == 0 ) /*0x1037b75b6*/
  {
    v17 = v16 >> 1; /*0x1037b75b6*/
    v18 = v39; /*0x1037b75ba*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v37, a2: v18, a3: v17, a4: v19, a5: 1); /*0x1037b75d4*/
  if ( (v38 & 1) != 0 ) /*0x1037b75e0*/
    operator delete(a1: v41); /*0x1037b75e9*/
  LOBYTE(v47[0]) = 6; /*0x1037b75ee*/
  v49 = v47; /*0x1037b75f6*/
  v50 = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Rupp::TlvType,fmt::v8::formatter<RBX::Rupp::TlvType,char,void>>; /*0x1037b7600*/
  fmt::v8::vformat(a1: &v38, a2: "has{}", a3: 5, a4: 15, a5: &v49); /*0x1037b761c*/
  v20 = v38; /*0x1037b7621*/
  v21 = v40; /*0x1037b7629*/
  v22 = v41; /*0x1037b7630*/
  v23 = RBX::Rupp::Rupp::hasTlv(a1: (__int64)v52, a2: 6); /*0x1037b7640*/
  v24 = v48; /*0x1037b7645*/
  if ( (v20 & 1) == 0 ) /*0x1037b7652*/
  {
    v21 = v20 >> 1; /*0x1037b7652*/
    v22 = v39; /*0x1037b7656*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v37, a2: v22, a3: v21, a4: v23, a5: 1); /*0x1037b7670*/
  if ( (v38 & 1) != 0 ) /*0x1037b767c*/
    operator delete(a1: v41); /*0x1037b7685*/
  RBX::Telemetry::FieldsContainer::addDatacenterId(this: (RBX::Telemetry::FieldsContainer *)v37); /*0x1037b7691*/
  v25 = v45; /*0x1037b7696*/
  v26 = v43; /*0x1037b769a*/
  v27 = v44; /*0x1037b76a1*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v36); /*0x1037b76af*/
  if ( v24 != 0 ) /*0x1037b76b7*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1037b76cb*/
      a1: (__int64)&v38,
      a2: (__int64)&RBX::Telemetry::kRuppSerializationFailurePoints);
    v28 = v42; /*0x1037b76d0*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "errorCode", a3: 9, a4: (int)*v25, a5: 1); /*0x1037b76ef*/
    v29 = RBX::Rupp::RuppError::toString(a1: *v25); /*0x1037b76f6*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "errorMessage", a3: 12, a4: v29, a5: 1); /*0x1037b7713*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "connectionAgeMs", a3: 15, a4: v26, a5: 1); /*0x1037b7730*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "fromConnectedSystem", a3: 19, a4: v26 != 0, a5: 1); /*0x1037b7752*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "tokenGenerated", a3: 14, a4: v25[1] == 0, a5: 1); /*0x1037b7775*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "timeSinceLastTokenGenerationMs", a3: 30, a4: v46, a5: 1); /*0x1037b7793*/
    RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "ruppHeaderLength", a3: 16, a4: v27, a5: 1); /*0x1037b77b0*/
    for ( i = -8; i != 0; ++i ) /*0x1037b77b5*/
    {
      v31 = v28; /*0x1037b77bb*/
      v53 = i + 9; /*0x1037b77c2*/
      v47[0] = &v53; /*0x1037b77c9*/
      v47[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Rupp::TlvType,fmt::v8::formatter<RBX::Rupp::TlvType,char,void>>; /*0x1037b77d4*/
      fmt::v8::vformat(a1: &v49, a2: "has{}", a3: 5, a4: 15, a5: v47); /*0x1037b77f1*/
      v32 = (unsigned __int8)v49; /*0x1037b77f6*/
      v33 = v50; /*0x1037b77fb*/
      v34 = (char *)v51; /*0x1037b77ff*/
      v35 = RBX::Rupp::Rupp::hasTlv(a1: (__int64)v52, a2: v53); /*0x1037b780b*/
      if ( (v32 & 1) == 0 ) /*0x1037b7819*/
      {
        v33 = (__int64 (__fastcall *)(_BYTE *, __int64, __int64 *))(v32 >> 1); /*0x1037b7819*/
        v34 = (char *)&v49 + 1; /*0x1037b7821*/
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v31, a2: v34, a3: v33, a4: v35, a5: 1); /*0x1037b7837*/
      if ( ((unsigned __int8)v49 & 1) != 0 ) /*0x1037b7840*/
        operator delete(a1: v51); /*0x1037b7846*/
      v28 = v31; /*0x1037b784e*/
    }
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)&v38); /*0x1037b785e*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent( /*0x1037b7871*/
      this: (RBX::Telemetry::RobloxTelemetryEvent *)&v38,
      a2: (void **)`VTT for'RBX::Telemetry::RobloxTelemetryEvent);
  }
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v37); /*0x1037b7888*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v36, a2: (void **)off_10C8C7EB0); /*0x1037b789b*/
}

// Address: 0x1037b791f | Name: __ZN3RBX4Rupp36reportLateRuppTokenUpdate_deprecatedENS0_9RuppError9ErrorCodeEyjy
void __fastcall RBX::Rupp::reportLateRuppTokenUpdate_deprecated(
        unsigned int a1,
        __int64 a2,
        unsigned int a3,
        __int64 a4)
{
  __int64 v7; // rax
  RBX *v8; // rdi
  _BYTE v9[72]; // [rsp+8h] [rbp-4A8h] BYREF
  _BYTE v10[528]; // [rsp+50h] [rbp-460h] BYREF
  void *v11[9]; // [rsp+260h] [rbp-250h] BYREF
  _BYTE v12[476]; // [rsp+2A8h] [rbp-208h] BYREF
  unsigned int v13; // [rsp+484h] [rbp-2Ch]

  v13 = a3; /*0x1037b7936*/
  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1037b794d*/
    a1: v11,
    a2: (__int64)&RBX::Telemetry::kRuppLateTTCounter);
  RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "errorCode", a3: 9, a4: (int)a1, a5: 1); /*0x1037b7974*/
  v7 = RBX::Rupp::RuppError::toString(a1); /*0x1037b797c*/
  RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "errorMessage", a3: 12, a4: v7, a5: 1); /*0x1037b7999*/
  RBX::Telemetry::FieldsContainer::addDatacenterId(this: (RBX::Telemetry::FieldsContainer *)v12); /*0x1037b79a1*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v11); /*0x1037b79ad*/
  if ( (unsigned int)RBX::globalRand(this: v8) % 0x2710 < DFInt::RuppLateTTPointsThrottleHundredthsPercent ) /*0x1037b79d4*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1037b79e8*/
      a1: (__int64)v9,
      a2: (__int64)&RBX::Telemetry::kRuppLateTTPoints);
    RBX::Telemetry::FieldsContainer::addField(a1: v10, a2: "errorCode", a3: 9, a4: (int)a1, a5: 1); /*0x1037b7a0c*/
    RBX::Telemetry::FieldsContainer::addField(a1: v10, a2: "timeSinceLastTokenUpdateMs", a3: 26, a4: a2, a5: 1); /*0x1037b7a29*/
    RBX::Telemetry::FieldsContainer::addField(a1: v10, a2: "connectionAgeMs", a3: 15, a4, a5: 1); /*0x1037b7a46*/
    RBX::Telemetry::FieldsContainer::addField(a1: v10, a2: "totalNumberOfUpdates", a3: 20, a4: v13, a5: 1); /*0x1037b7a63*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v9); /*0x1037b7a6f*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent( /*0x1037b7a82*/
      this: (RBX::Telemetry::RobloxTelemetryEvent *)v9,
      a2: (void **)`VTT for'RBX::Telemetry::RobloxTelemetryEvent);
  }
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v12); /*0x1037b7a95*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v11, a2: (void **)off_10C8C7EB0); /*0x1037b7aa8*/
}

// Address: 0x1037b7af0 | Name: __ZN3RBX4Rupp19reportRuppInitStatsENS0_9RuppError9ErrorCodeEbNS0_12NetworkStackE
void __fastcall RBX::Rupp::reportRuppInitStats(unsigned int a1, unsigned __int8 a2, char a3)
{
  __int64 v6; // rax
  const char *v7; // rcx
  __int64 v8; // r8
  void *v9[9]; // [rsp+0h] [rbp-240h] BYREF
  _BYTE v10[504]; // [rsp+48h] [rbp-1F8h] BYREF

  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter(a1: v9, a2: (__int64)&RBX::Telemetry::kRuppInitResult); /*0x1037b7b19*/
  RBX::Telemetry::FieldsContainer::addField(a1: v10, a2: "errorCode", a3: 9, a4: (int)a1, a5: 1); /*0x1037b7b3d*/
  v6 = RBX::Rupp::RuppError::toString(a1); /*0x1037b7b45*/
  RBX::Telemetry::FieldsContainer::addField(a1: v10, a2: "errorMessage", a3: 12, a4: v6, a5: 1); /*0x1037b7b62*/
  RBX::Telemetry::FieldsContainer::addField(a1: v10, a2: "directServerReturn", a3: 18, a4: a2, a5: 1); /*0x1037b7b80*/
  if ( a3 != 0 ) /*0x1037b7b88*/
  {
    if ( a3 == 1 ) /*0x1037b7b91*/
    {
      v7 = "RbxTransport"; /*0x1037b7b93*/
      v8 = 12; /*0x1037b7b9a*/
    }
    else
    {
      v7 = "Unknown"; /*0x1037b7bb1*/
      v8 = 7; /*0x1037b7bb8*/
    }
  }
  else
  {
    v7 = "RakNet"; /*0x1037b7ba2*/
    v8 = 6; /*0x1037b7ba9*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v10, a2: "networkStack", a3: 12, a4: v7, a5: v8, a6: 1); /*0x1037b7bd3*/
  RBX::Telemetry::FieldsContainer::addDatacenterId(this: (RBX::Telemetry::FieldsContainer *)v10); /*0x1037b7bdb*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v9); /*0x1037b7be7*/
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v10); /*0x1037b7bfa*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v9, a2: (void **)off_10C8C7EB0); /*0x1037b7c0d*/
}

// Address: 0x1037b7c3b | Name: __ZN3RBX4Rupp21reportRuppMissingTlvsEbbNS0_12NetworkStackE
void __fastcall RBX::Rupp::reportRuppMissingTlvs(unsigned int a1, unsigned __int8 a2, char a3)
{
  const char *v6; // rcx
  __int64 v7; // r8
  RBX *v8; // rdi
  const char *v9; // rcx
  __int64 v10; // r8
  _BYTE v11[72]; // [rsp+0h] [rbp-4A0h] BYREF
  _BYTE v12[528]; // [rsp+48h] [rbp-458h] BYREF
  void *v13[9]; // [rsp+258h] [rbp-248h] BYREF
  _BYTE v14[512]; // [rsp+2A0h] [rbp-200h] BYREF

  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1037b7c66*/
    a1: v13,
    a2: (__int64)&RBX::Telemetry::kRuppMissingTlvsCounter);
  RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "missingTokenTlv", a3: 15, a4: a1, a5: 1); /*0x1037b7c8a*/
  RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "missingEndpointTlv", a3: 18, a4: a2, a5: 1); /*0x1037b7cab*/
  if ( a3 != 0 ) /*0x1037b7cb7*/
  {
    if ( a3 == 1 ) /*0x1037b7cbd*/
    {
      v6 = "RbxTransport"; /*0x1037b7cbf*/
      v7 = 12; /*0x1037b7cc6*/
    }
    else
    {
      v6 = "Unknown"; /*0x1037b7cdd*/
      v7 = 7; /*0x1037b7ce4*/
    }
  }
  else
  {
    v6 = "RakNet"; /*0x1037b7cce*/
    v7 = 6; /*0x1037b7cd5*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "networkStack", a3: 12, a4: v6, a5: v7, a6: 1); /*0x1037b7cff*/
  RBX::Telemetry::FieldsContainer::addDatacenterId(this: (RBX::Telemetry::FieldsContainer *)v14); /*0x1037b7d07*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v13); /*0x1037b7d13*/
  if ( (unsigned int)RBX::globalRand(this: v8) % 0x2710 < DFInt::RuppMissingTlvsPointsThrottleHundredthsPercent ) /*0x1037b7d3a*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1037b7d4e*/
      a1: (__int64)v11,
      a2: (__int64)&RBX::Telemetry::kRuppMissingTlvsPoints);
    RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "missingTokenTlv", a3: 15, a4: (unsigned __int8)a1, a5: 1); /*0x1037b7d76*/
    RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "missingEndpointTlv", a3: 18, a4: a2, a5: 1); /*0x1037b7d93*/
    if ( a3 != 0 ) /*0x1037b7d9b*/
    {
      if ( a3 == 1 ) /*0x1037b7da1*/
      {
        v9 = "RbxTransport"; /*0x1037b7da3*/
        v10 = 12; /*0x1037b7daa*/
      }
      else
      {
        v9 = "Unknown"; /*0x1037b7dc1*/
        v10 = 7; /*0x1037b7dc8*/
      }
    }
    else
    {
      v9 = "RakNet"; /*0x1037b7db2*/
      v10 = 6; /*0x1037b7db9*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "networkStack", a3: 12, a4: v9, a5: v10, a6: 1); /*0x1037b7de3*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v11); /*0x1037b7def*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent( /*0x1037b7e02*/
      this: (RBX::Telemetry::RobloxTelemetryEvent *)v11,
      a2: (void **)`VTT for'RBX::Telemetry::RobloxTelemetryEvent);
  }
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v14); /*0x1037b7e15*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v13, a2: (void **)off_10C8C7EB0); /*0x1037b7e28*/
}

// Address: 0x1037b7e74 | Name: __ZN3RBX4Rupp32reportRuppDeserializationFailureENS0_9RuppError9ErrorCodeEybNS0_12NetworkStackE
void __fastcall RBX::Rupp::reportRuppDeserializationFailure(unsigned int a1, __int64 a2, char a3, int a4)
{
  __int64 v6; // rax
  int v7; // r15d
  const char *v8; // rcx
  __int64 v9; // r8
  __int64 v10; // rax
  const char *v11; // rcx
  __int64 v12; // r8
  _BYTE v13[72]; // [rsp+0h] [rbp-4B0h] BYREF
  _BYTE v14[528]; // [rsp+48h] [rbp-468h] BYREF
  void *v15[9]; // [rsp+258h] [rbp-258h] BYREF
  _BYTE v16[472]; // [rsp+2A0h] [rbp-210h] BYREF
  __int64 v17; // [rsp+478h] [rbp-38h]
  int v18; // [rsp+484h] [rbp-2Ch]

  v18 = a4; /*0x1037b7e88*/
  v17 = a2; /*0x1037b7e8e*/
  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1037b7ea3*/
    a1: v15,
    a2: (__int64)&RBX::Telemetry::kRuppDeserializationFailureCounter);
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "errorCode", a3: 9, a4: (int)a1, a5: 1); /*0x1037b7eca*/
  v6 = RBX::Rupp::RuppError::toString(a1); /*0x1037b7ed2*/
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "errorMessage", a3: 12, a4: v6, a5: 1); /*0x1037b7eef*/
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "fromConnectedSystem", a3: 19, a4: v17 != 0, a5: 1); /*0x1037b7f13*/
  v7 = (unsigned __int8)v18; /*0x1037b7f18*/
  if ( (_BYTE)v18 != 0 ) /*0x1037b7f20*/
  {
    if ( (unsigned __int8)v18 == 1 ) /*0x1037b7f26*/
    {
      v8 = "RbxTransport"; /*0x1037b7f28*/
      v9 = 12; /*0x1037b7f2f*/
    }
    else
    {
      v8 = "Unknown"; /*0x1037b7f46*/
      v9 = 7; /*0x1037b7f4d*/
    }
  }
  else
  {
    v8 = "RakNet"; /*0x1037b7f37*/
    v9 = 6; /*0x1037b7f3e*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "networkStack", a3: 12, a4: v8, a5: v9, a6: 1); /*0x1037b7f68*/
  RBX::Telemetry::FieldsContainer::addDatacenterId(this: (RBX::Telemetry::FieldsContainer *)v16); /*0x1037b7f70*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v15); /*0x1037b7f7c*/
  if ( a3 != 0 ) /*0x1037b7f84*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1037b7f98*/
      a1: (__int64)v13,
      a2: (__int64)&RBX::Telemetry::kRuppDeserializationFailurePoints);
    RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "errorCode", a3: 9, a4: (int)a1, a5: 1); /*0x1037b7fbc*/
    v10 = RBX::Rupp::RuppError::toString(a1); /*0x1037b7fc4*/
    RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "errorMessage", a3: 12, a4: v10, a5: 1); /*0x1037b7fe1*/
    RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "connectionAgeMs", a3: 15, a4: v17, a5: 1); /*0x1037b7fff*/
    if ( (_BYTE)v18 != 0 ) /*0x1037b8008*/
    {
      if ( v7 == 1 ) /*0x1037b800e*/
      {
        v11 = "RbxTransport"; /*0x1037b8010*/
        v12 = 12; /*0x1037b8017*/
      }
      else
      {
        v11 = "Unknown"; /*0x1037b802e*/
        v12 = 7; /*0x1037b8035*/
      }
    }
    else
    {
      v11 = "RakNet"; /*0x1037b801f*/
      v12 = 6; /*0x1037b8026*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "networkStack", a3: 12, a4: v11, a5: v12, a6: 1); /*0x1037b8050*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v13); /*0x1037b805c*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent( /*0x1037b806f*/
      this: (RBX::Telemetry::RobloxTelemetryEvent *)v13,
      a2: (void **)`VTT for'RBX::Telemetry::RobloxTelemetryEvent);
  }
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v16); /*0x1037b8082*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v15, a2: (void **)off_10C8C7EB0); /*0x1037b8095*/
}

// Address: 0x1037b80e1 | Name: __ZN3RBX4Rupp30reportRuppSerializationFailureERKNS0_4RuppERKNS0_19SerializationResultEyybNS0_12NetworkStackE
void __fastcall RBX::Rupp::reportRuppSerializationFailure(
        RBX::Rupp::Rupp *a1,
        unsigned int *a2,
        __int64 a3,
        __int64 a4,
        int a5,
        int a6)
{
  unsigned __int16 HeaderTotalByteLength; // r14
  __int64 v10; // rax
  bool isValidRuppLength; // al
  __int64 v12; // rcx
  unsigned int v13; // r14d
  __int64 v14; // rbx
  _BYTE *v15; // r15
  bool hasTlv; // al
  unsigned int *v17; // r14
  unsigned int v18; // r13d
  __int64 v19; // rbx
  _BYTE *v20; // r15
  bool v21; // al
  unsigned int *v22; // r13
  unsigned int v23; // r12d
  __int64 v24; // rbx
  _BYTE *v25; // r15
  bool v26; // al
  __int64 v27; // r14
  __int64 v28; // r15
  char v29; // r12
  const char *v30; // rcx
  __int64 v31; // r8
  __int64 v32; // rax
  int i; // r14d
  unsigned int v34; // r13d
  __int64 (__fastcall *v35)(_BYTE *, __int64, __int64 *); // r15
  char *v36; // r12
  bool v37; // al
  int v38; // r15d
  const char *v39; // rcx
  __int64 v40; // r8
  void *v41[9]; // [rsp+0h] [rbp-500h] BYREF
  _BYTE v42[472]; // [rsp+48h] [rbp-4B8h] BYREF
  unsigned __int8 v43; // [rsp+220h] [rbp-2E0h] BYREF
  _BYTE v44[7]; // [rsp+221h] [rbp-2DFh] BYREF
  __int64 v45; // [rsp+228h] [rbp-2D8h]
  void *v46; // [rsp+230h] [rbp-2D0h]
  _BYTE v47[528]; // [rsp+268h] [rbp-298h] BYREF
  __int64 v48; // [rsp+478h] [rbp-88h]
  __int64 v49; // [rsp+480h] [rbp-80h]
  __int64 v50; // [rsp+488h] [rbp-78h]
  _QWORD v51[3]; // [rsp+490h] [rbp-70h] BYREF
  int v52; // [rsp+4A8h] [rbp-58h]
  int v53; // [rsp+4ACh] [rbp-54h]
  _QWORD *v54; // [rsp+4B0h] [rbp-50h] BYREF
  __int64 (__fastcall *v55)(_BYTE *, __int64, __int64 *); // [rsp+4B8h] [rbp-48h]
  void *v56; // [rsp+4C0h] [rbp-40h]
  RBX::Rupp::Rupp *v57; // [rsp+4C8h] [rbp-38h]
  int v58; // [rsp+4D0h] [rbp-30h]
  char v59; // [rsp+4D7h] [rbp-29h] BYREF

  v58 = a6; /*0x1037b80f5*/
  v50 = a4; /*0x1037b80fc*/
  v57 = a1; /*0x1037b8106*/
  HeaderTotalByteLength = RBX::Rupp::Rupp::getHeaderTotalByteLength(this: a1); /*0x1037b810f*/
  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1037b8120*/
    a1: v41,
    a2: (__int64)&RBX::Telemetry::kRuppSerializationFailureCounter);
  RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "errorCode", a3: 9, a4: (int)*a2, a5: 1); /*0x1037b8145*/
  v10 = RBX::Rupp::RuppError::toString(a1: *a2); /*0x1037b814e*/
  RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "errorMessage", a3: 12, a4: v10, a5: 1); /*0x1037b816b*/
  RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "fromConnectedSystem", a3: 19, a4: a3 != 0, a5: 1); /*0x1037b818d*/
  RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "tokenGenerated", a3: 14, a4: a2[1] == 0, a5: 1); /*0x1037b81b1*/
  isValidRuppLength = RBX::Rupp::Rupp::isValidRuppLength(this: (RBX::Rupp::Rupp *)HeaderTotalByteLength); /*0x1037b81bd*/
  v12 = -1; /*0x1037b81c4*/
  if ( isValidRuppLength ) /*0x1037b81cb*/
    v12 = HeaderTotalByteLength; /*0x1037b81cb*/
  RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "ruppHeaderLength", a3: 16, a4: v12, a5: 1); /*0x1037b81e4*/
  v53 = a5; /*0x1037b81e9*/
  v49 = HeaderTotalByteLength; /*0x1037b81ed*/
  v48 = a3; /*0x1037b81f1*/
  LOBYTE(v51[0]) = 1; /*0x1037b81fc*/
  v54 = v51; /*0x1037b8205*/
  v55 = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Rupp::TlvType,fmt::v8::formatter<RBX::Rupp::TlvType,char,void>>; /*0x1037b820f*/
  fmt::v8::vformat(a1: &v43, a2: "has{}", a3: 5, a4: 15, a5: &v54); /*0x1037b822b*/
  v13 = v43; /*0x1037b8230*/
  v14 = v45; /*0x1037b8238*/
  v15 = v46; /*0x1037b823f*/
  hasTlv = RBX::Rupp::Rupp::hasTlv(a1: (__int64)v57, a2: 1); /*0x1037b824f*/
  if ( (v13 & 1) == 0 ) /*0x1037b825d*/
  {
    v14 = v13 >> 1; /*0x1037b825d*/
    v15 = v44; /*0x1037b8268*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: v15, a3: v14, a4: hasTlv, a5: 1); /*0x1037b8282*/
  if ( (v43 & 1) != 0 ) /*0x1037b828e*/
    operator delete(a1: v46); /*0x1037b8297*/
  v17 = a2; /*0x1037b829c*/
  LOBYTE(v51[0]) = 2; /*0x1037b829f*/
  v54 = v51; /*0x1037b82a7*/
  v55 = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Rupp::TlvType,fmt::v8::formatter<RBX::Rupp::TlvType,char,void>>; /*0x1037b82b1*/
  fmt::v8::vformat(a1: &v43, a2: "has{}", a3: 5, a4: 15, a5: &v54); /*0x1037b82cd*/
  v18 = v43; /*0x1037b82d2*/
  v19 = v45; /*0x1037b82da*/
  v20 = v46; /*0x1037b82e1*/
  v21 = RBX::Rupp::Rupp::hasTlv(a1: (__int64)v57, a2: 2); /*0x1037b82f1*/
  if ( (v18 & 1) == 0 ) /*0x1037b82ff*/
  {
    v19 = v18 >> 1; /*0x1037b82ff*/
    v20 = v44; /*0x1037b830a*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: v20, a3: v19, a4: v21, a5: 1); /*0x1037b8324*/
  if ( (v43 & 1) != 0 ) /*0x1037b8330*/
    operator delete(a1: v46); /*0x1037b8339*/
  LOBYTE(v51[0]) = 6; /*0x1037b833e*/
  v54 = v51; /*0x1037b8346*/
  v55 = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Rupp::TlvType,fmt::v8::formatter<RBX::Rupp::TlvType,char,void>>; /*0x1037b8350*/
  fmt::v8::vformat(a1: &v43, a2: "has{}", a3: 5, a4: 15, a5: &v54); /*0x1037b836c*/
  v22 = v17; /*0x1037b8371*/
  v23 = v43; /*0x1037b8374*/
  v24 = v45; /*0x1037b837c*/
  v25 = v46; /*0x1037b8383*/
  v26 = RBX::Rupp::Rupp::hasTlv(a1: (__int64)v57, a2: 6); /*0x1037b8393*/
  if ( (v23 & 1) == 0 ) /*0x1037b83a1*/
  {
    v24 = v23 >> 1; /*0x1037b83a1*/
    v25 = v44; /*0x1037b83ac*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: v25, a3: v24, a4: v26, a5: 1); /*0x1037b83c6*/
  if ( (v43 & 1) != 0 ) /*0x1037b83d2*/
    operator delete(a1: v46); /*0x1037b83db*/
  v27 = v48; /*0x1037b83ed*/
  v28 = v49; /*0x1037b83f4*/
  v29 = v53; /*0x1037b83f8*/
  v52 = (unsigned __int8)v58; /*0x1037b83fc*/
  if ( (_BYTE)v58 != 0 ) /*0x1037b83ff*/
  {
    if ( (unsigned __int8)v58 == 1 ) /*0x1037b8404*/
    {
      v30 = "RbxTransport"; /*0x1037b8406*/
      v31 = 12; /*0x1037b840d*/
    }
    else
    {
      v30 = "Unknown"; /*0x1037b8424*/
      v31 = 7; /*0x1037b842b*/
    }
  }
  else
  {
    v30 = "RakNet"; /*0x1037b8415*/
    v31 = 6; /*0x1037b841c*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v42, a2: "networkStack", a3: 12, a4: v30, a5: v31, a6: 1); /*0x1037b8446*/
  RBX::Telemetry::FieldsContainer::addDatacenterId(this: (RBX::Telemetry::FieldsContainer *)v42); /*0x1037b844e*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v41); /*0x1037b845a*/
  if ( v29 != 0 ) /*0x1037b8462*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1037b8476*/
      a1: (__int64)&v43,
      a2: (__int64)&RBX::Telemetry::kRuppSerializationFailurePoints);
    RBX::Telemetry::FieldsContainer::addField(a1: v47, a2: "errorCode", a3: 9, a4: (int)*v22, a5: 1); /*0x1037b849b*/
    v32 = RBX::Rupp::RuppError::toString(a1: *v22); /*0x1037b84a4*/
    RBX::Telemetry::FieldsContainer::addField(a1: v47, a2: "errorMessage", a3: 12, a4: v32, a5: 1); /*0x1037b84c1*/
    RBX::Telemetry::FieldsContainer::addField(a1: v47, a2: "connectionAgeMs", a3: 15, a4: v27, a5: 1); /*0x1037b84de*/
    RBX::Telemetry::FieldsContainer::addField(a1: v47, a2: "fromConnectedSystem", a3: 19, a4: v27 != 0, a5: 1); /*0x1037b8500*/
    RBX::Telemetry::FieldsContainer::addField(a1: v47, a2: "tokenGenerated", a3: 14, a4: v22[1] == 0, a5: 1); /*0x1037b8524*/
    RBX::Telemetry::FieldsContainer::addField(a1: v47, a2: "timeSinceLastTokenGenerationMs", a3: 30, a4: v50, a5: 1); /*0x1037b8542*/
    RBX::Telemetry::FieldsContainer::addField(a1: v47, a2: "ruppHeaderLength", a3: 16, a4: v28, a5: 1); /*0x1037b855f*/
    for ( i = -8; i != 0; ++i ) /*0x1037b8564*/
    {
      v59 = i + 9; /*0x1037b8572*/
      v51[0] = &v59; /*0x1037b8579*/
      v51[1] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::Rupp::TlvType,fmt::v8::formatter<RBX::Rupp::TlvType,char,void>>; /*0x1037b8584*/
      fmt::v8::vformat(a1: &v54, a2: "has{}", a3: 5, a4: 15, a5: v51); /*0x1037b85a0*/
      v34 = (unsigned __int8)v54; /*0x1037b85a5*/
      v35 = v55; /*0x1037b85aa*/
      v36 = (char *)v56; /*0x1037b85ae*/
      v37 = RBX::Rupp::Rupp::hasTlv(a1: (__int64)v57, a2: v59); /*0x1037b85ba*/
      if ( (v34 & 1) == 0 ) /*0x1037b85c8*/
      {
        v35 = (__int64 (__fastcall *)(_BYTE *, __int64, __int64 *))(v34 >> 1); /*0x1037b85c8*/
        v36 = (char *)&v54 + 1; /*0x1037b85d0*/
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v47, a2: v36, a3: v35, a4: v37, a5: 1); /*0x1037b85ea*/
      v38 = v52; /*0x1037b85f3*/
      if ( ((unsigned __int8)v54 & 1) != 0 ) /*0x1037b85f7*/
        operator delete(a1: v56); /*0x1037b85fd*/
    }
    if ( (_BYTE)v58 != 0 ) /*0x1037b860f*/
    {
      if ( v38 == 1 ) /*0x1037b861c*/
      {
        v39 = "RbxTransport"; /*0x1037b861e*/
        v40 = 12; /*0x1037b8625*/
      }
      else
      {
        v39 = "Unknown"; /*0x1037b8643*/
        v40 = 7; /*0x1037b864a*/
      }
    }
    else
    {
      v39 = "RakNet"; /*0x1037b862d*/
      v40 = 6; /*0x1037b8634*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v47, a2: "networkStack", a3: 12, a4: v39, a5: v40, a6: 1); /*0x1037b8662*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)&v43); /*0x1037b866e*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent( /*0x1037b8681*/
      this: (RBX::Telemetry::RobloxTelemetryEvent *)&v43,
      a2: (void **)`VTT for'RBX::Telemetry::RobloxTelemetryEvent);
  }
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v42); /*0x1037b8698*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v41, a2: (void **)off_10C8C7EB0); /*0x1037b86ab*/
}

// Address: 0x1037b8733 | Name: __ZN3RBX4Rupp25reportLateRuppTokenUpdateENS0_9RuppError9ErrorCodeEyjyNS0_12NetworkStackE
void __fastcall RBX::Rupp::reportLateRuppTokenUpdate(unsigned int a1, __int64 a2, unsigned int a3, __int64 a4, char a5)
{
  __int64 v7; // rax
  const char *v8; // rcx
  __int64 v9; // r8
  RBX *v10; // rdi
  const char *v11; // rcx
  __int64 v12; // r8
  _BYTE v13[72]; // [rsp+8h] [rbp-4B8h] BYREF
  _BYTE v14[528]; // [rsp+50h] [rbp-470h] BYREF
  void *v15[9]; // [rsp+260h] [rbp-260h] BYREF
  _BYTE v16[472]; // [rsp+2A8h] [rbp-218h] BYREF
  __int64 v17; // [rsp+480h] [rbp-40h]
  __int64 v18; // [rsp+488h] [rbp-38h]
  unsigned int v19; // [rsp+494h] [rbp-2Ch]

  v18 = a4; /*0x1037b874a*/
  v19 = a3; /*0x1037b874e*/
  v17 = a2; /*0x1037b8751*/
  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1037b8766*/
    a1: v15,
    a2: (__int64)&RBX::Telemetry::kRuppLateTTCounter);
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "errorCode", a3: 9, a4: (int)a1, a5: 1); /*0x1037b878d*/
  v7 = RBX::Rupp::RuppError::toString(a1); /*0x1037b8795*/
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "errorMessage", a3: 12, a4: v7, a5: 1); /*0x1037b87b2*/
  if ( a5 != 0 ) /*0x1037b87be*/
  {
    if ( a5 == 1 ) /*0x1037b87c4*/
    {
      v8 = "RbxTransport"; /*0x1037b87c6*/
      v9 = 12; /*0x1037b87cd*/
    }
    else
    {
      v8 = "Unknown"; /*0x1037b87e4*/
      v9 = 7; /*0x1037b87eb*/
    }
  }
  else
  {
    v8 = "RakNet"; /*0x1037b87d5*/
    v9 = 6; /*0x1037b87dc*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "networkStack", a3: 12, a4: v8, a5: v9, a6: 1); /*0x1037b8806*/
  RBX::Telemetry::FieldsContainer::addDatacenterId(this: (RBX::Telemetry::FieldsContainer *)v16); /*0x1037b880e*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v15); /*0x1037b881a*/
  if ( (unsigned int)RBX::globalRand(this: v10) % 0x2710 < DFInt::RuppLateTTPointsThrottleHundredthsPercent ) /*0x1037b8841*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1037b8855*/
      a1: (__int64)v13,
      a2: (__int64)&RBX::Telemetry::kRuppLateTTPoints);
    RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "errorCode", a3: 9, a4: (int)a1, a5: 1); /*0x1037b8879*/
    RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "timeSinceLastTokenUpdateMs", a3: 26, a4: v17, a5: 1); /*0x1037b8897*/
    RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "connectionAgeMs", a3: 15, a4: v18, a5: 1); /*0x1037b88b5*/
    RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "totalNumberOfUpdates", a3: 20, a4: v19, a5: 1); /*0x1037b88d2*/
    if ( a5 != 0 ) /*0x1037b88da*/
    {
      if ( a5 == 1 ) /*0x1037b88e0*/
      {
        v11 = "RbxTransport"; /*0x1037b88e2*/
        v12 = 12; /*0x1037b88e9*/
      }
      else
      {
        v11 = "Unknown"; /*0x1037b8900*/
        v12 = 7; /*0x1037b8907*/
      }
    }
    else
    {
      v11 = "RakNet"; /*0x1037b88f1*/
      v12 = 6; /*0x1037b88f8*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v14, a2: "networkStack", a3: 12, a4: v11, a5: v12, a6: 1); /*0x1037b8922*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v13); /*0x1037b892e*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent( /*0x1037b8941*/
      this: (RBX::Telemetry::RobloxTelemetryEvent *)v13,
      a2: (void **)`VTT for'RBX::Telemetry::RobloxTelemetryEvent);
  }
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v16); /*0x1037b8954*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v15, a2: (void **)off_10C8C7EB0); /*0x1037b8967*/
}

// Address: 0x1037b89b3 | Name: __ZN3RBX4Rupp19reportRuppTokenAlgoEbjbbNS0_12NetworkStackE
void __fastcall RBX::Rupp::reportRuppTokenAlgo(unsigned int a1, unsigned int a2, unsigned __int8 a3, int a4, char a5)
{
  const char *v9; // rcx
  __int64 v10; // r8
  void *v11[9]; // [rsp+0h] [rbp-250h] BYREF
  _BYTE v12[476]; // [rsp+48h] [rbp-208h] BYREF
  int v13; // [rsp+224h] [rbp-2Ch]

  v13 = a4; /*0x1037b89ca*/
  RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1037b89e4*/
    a1: v11,
    a2: (__int64)&RBX::Telemetry::kRuppTokenAlgoCounter);
  RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "isGeneration", a3: 12, a4: a1, a5: 1); /*0x1037b8a08*/
  RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "algorithmId", a3: 11, a4: a2, a5: 1); /*0x1037b8a25*/
  RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "isAltLineage", a3: 12, a4: a3, a5: 1); /*0x1037b8a43*/
  RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "succeeded", a3: 9, a4: (unsigned __int8)v13, a5: 1); /*0x1037b8a61*/
  if ( a5 != 0 ) /*0x1037b8a69*/
  {
    if ( a5 == 1 ) /*0x1037b8a72*/
    {
      v9 = "RbxTransport"; /*0x1037b8a74*/
      v10 = 12; /*0x1037b8a7b*/
    }
    else
    {
      v9 = "Unknown"; /*0x1037b8a92*/
      v10 = 7; /*0x1037b8a99*/
    }
  }
  else
  {
    v9 = "RakNet"; /*0x1037b8a83*/
    v10 = 6; /*0x1037b8a8a*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v12, a2: "networkStack", a3: 12, a4: v9, a5: v10, a6: 1); /*0x1037b8ab4*/
  RBX::Telemetry::FieldsContainer::addDatacenterId(this: (RBX::Telemetry::FieldsContainer *)v12); /*0x1037b8abc*/
  RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v11); /*0x1037b8ac8*/
  RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v12); /*0x1037b8adb*/
  RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v11, a2: (void **)off_10C8C7EB0); /*0x1037b8aee*/
}

// Address: 0x1039d0ada | Name: __ZN3RBX4Rupp4RuppD1Ev
void __fastcall RBX::Rupp::Rupp::~Rupp(RBX::Rupp::Rupp *this)
{
  char *v1; // rax
  char *v3; // rdi
  RBX::Rupp::Rupp *v4; // rdi
  __int64 v5; // rax
  char *v6; // [rsp+0h] [rbp-10h] BYREF

  v6 = v1; /*0x1039d0adf*/
  v3 = *((char **)this + 14); /*0x1039d0ae3*/
  if ( v3 != (char *)this + 136 ) /*0x1039d0af1*/
    operator delete(a1: v3); /*0x1039d0af3*/
  v6 = (char *)this + 88; /*0x1039d0b00*/
  std::vector<std::unique_ptr<RBX::Rupp::TypeLengthValue>>::__destroy_vector::operator()[abi:ne200100](a1: &v6); /*0x1039d0b03*/
  v4 = *((RBX::Rupp::Rupp **)this + 6); /*0x1039d0b08*/
  if ( v4 == (RBX::Rupp::Rupp *)((char *)this + 16) ) /*0x1039d0b13*/
  {
    v5 = 32; /*0x1039d0b21*/
    goto LABEL_7; /*0x1039d0b21*/
  }
  v5 = 40; /*0x1039d0b15*/
  if ( v4 != nullptr ) /*0x1039d0b1d*/
LABEL_7:
    (*(void (**)(void))(*(_QWORD *)v4 + v5))(); /*0x1039d0b26*/
}

// END Rupp part 1/1, 45 functions
