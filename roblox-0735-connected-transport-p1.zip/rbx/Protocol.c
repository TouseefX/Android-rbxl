// Protocol -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 49 functions


// Address: 0x10376f102 | Name: __ZN3RBX12RbxTransport8Protocol26calculateFlowBytesReliableEy
__int64 __fastcall RBX::RbxTransport::Protocol::calculateFlowBytesReliable(
        RBX::RbxTransport::Protocol *this,
        unsigned __int64 a2)
{
  return (__int64)this + RBX::RbxTransport::Protocol::ReliableHeader::serializedSize(this, a2); /*0x10376f117*/
}

// Address: 0x10376f11a | Name: __ZN3RBX12RbxTransport8Protocol26calculateFlowBytesReliableERKNS0_9NetStreamE
__int64 __fastcall RBX::RbxTransport::Protocol::calculateFlowBytesReliable(
        RBX::RbxTransport::Protocol *this,
        const RBX::RbxTransport::NetStream *a2)
{
  __int64 v2; // rbx
  RBX::RbxTransport::Protocol::ReliableHeader *v3; // rbx

  if ( *((_BYTE *)this + 64) != 0 ) /*0x10376f124*/
    v2 = *((_QWORD *)this + 5); /*0x10376f126*/
  else
    v2 = *((_QWORD *)this + 2) - *((_QWORD *)this + 1); /*0x10376f130*/
  v3 = (RBX::RbxTransport::Protocol::ReliableHeader *)(v2 - *((_QWORD *)this + 9)); /*0x10376f134*/
  return (__int64)v3 + RBX::RbxTransport::Protocol::ReliableHeader::serializedSize(this: v3, (unsigned __int64)a2); /*0x10376f147*/
}

// Address: 0x10376f169 | Name: __ZN3RBX12RbxTransport8Protocol14createListenerEPNS0_2Io10LibContextERKNS0_19ListenConfigurationE
RBX::RbxTransport::Protocol *__fastcall RBX::RbxTransport::Protocol::createListener(
        RBX::RbxTransport::Protocol *this,
        RBX::RbxTransport::Io::LibContext *a2,
        const RBX::RbxTransport::ListenConfiguration *a3)
{
  __int64 v4; // rax
  __int64 v6; // [rsp+0h] [rbp-30h] BYREF
  RBX::RbxTransport::Io::LibContext *v7; // [rsp+8h] [rbp-28h] BYREF

  v7 = a2; /*0x10376f17b*/
  if ( *((_DWORD *)a3 + 1) == 1 ) /*0x10376f183*/
  {
    std::make_unique[abi:ne200100]<RBX::RbxTransport::Protocol::QuicListener,RBX::RbxTransport::Io::LibContext *&,std::string const&,unsigned short const&,boost::filesystem::path const&,boost::filesystem::path const&,std::vector<unsigned char> const&,std::vector<unsigned char> const&,std::optional<RBX::Rupp::ServerRuppConfiguration> const&,std::optional<std::string> const&,RBX::RbxTransport::Capabilities const&,0>( /*0x10376f1cd*/
      a1: (unsigned int)&v6,
      a2: (unsigned int)&v7,
      a3: (_DWORD)a3 + 8,
      a4: (_DWORD)a3 + 32,
      a5: (_DWORD)a3 + 40,
      a6: (_DWORD)a3 + 168,
      a7: (__int64)a3 + 64,
      a8: (__int64)a3 + 192,
      a9: (__int64)a3 + 104,
      a10: (__int64)a3 + 216,
      a11: (__int64)a3 + 88);
    v4 = v6; /*0x10376f1d6*/
  }
  else
  {
    v4 = 0; /*0x10376f1db*/
  }
  *(_QWORD *)this = v4; /*0x10376f1dd*/
  return this; /*0x10376f1e3*/
}

// Address: 0x10376f3c0 | Name: __ZN3RBX12RbxTransport8Protocol10createPeerEPNS0_2Io10LibContextERKNS0_20ConnectConfigurationE
_QWORD *__fastcall RBX::RbxTransport::Protocol::createPeer(_QWORD *a1, __int64 a2, __int64 a3)
{
  RBX::Rupp::ClientRuppGenerator *v5; // r14
  const RBX::Rupp::ClientRuppConfiguration *v6; // r15
  __int64 v7; // r12
  __int64 v9; // rdi
  __int64 v10; // [rsp+18h] [rbp-38h] BYREF
  RBX::Rupp::ClientRuppGenerator *v11; // [rsp+20h] [rbp-30h]
  __int64 v12; // [rsp+28h] [rbp-28h] BYREF

  v10 = a2; /*0x10376f3d2*/
  if ( *(_DWORD *)(a3 + 4) != 1 ) /*0x10376f3da*/
  {
    *a1 = 0; /*0x10376f48b*/
    return a1; /*0x10376f492*/
  }
  std::make_unique[abi:ne200100]<RBX::RbxTransport::Protocol::QuicClientPeer,RBX::RbxTransport::Io::LibContext *&,std::string const&,unsigned short const&,boost::filesystem::path const&,std::vector<unsigned char> const&,bool const&,RBX::RbxTransport::Capabilities const&,0>( /*0x10376f40f*/
    a1: (unsigned int)&v12,
    a2: (unsigned int)&v10,
    a3: a3 + 8,
    a4: a3 + 32,
    a5: a3 + 40,
    a6: a3 + 64,
    a7: a3 + 200,
    a8: a3 + 88);
  if ( *(_BYTE *)(a3 + 146) != 1 ) /*0x10376f41c*/
  {
LABEL_12:
    *a1 = v12; /*0x10376f4af*/
    return a1; /*0x10376f4b3*/
  }
  v5 = (RBX::Rupp::ClientRuppGenerator *)operator new(a1: 0x160u); /*0x10376f42c*/
  v6 = (const RBX::Rupp::ClientRuppConfiguration *)(a3 + 100); /*0x10376f42f*/
  RBX::Rupp::ClientRuppGenerator::ClientRuppGenerator(this: v5, a2: v6); /*0x10376f439*/
  v7 = (unsigned int)RBX::Rupp::ClientRuppGenerator::init(this: v5); /*0x10376f446*/
  RBX::Rupp::reportRuppInitStats(a1: v7, a2: *(unsigned __int8 *)v6, a3: 1); /*0x10376f454*/
  if ( (_DWORD)v7 != 0 && (_DWORD)v7 != 12 ) /*0x10376f462*/
  {
    *a1 = 0; /*0x10376f494*/
    goto LABEL_9; /*0x10376f494*/
  }
  v11 = v5; /*0x10376f46c*/
  (*(void (__fastcall **)(__int64))(*(_QWORD *)v12 + 168LL))(a1: v12); /*0x10376f472*/
  v5 = v11; /*0x10376f478*/
  v11 = nullptr; /*0x10376f47c*/
  if ( v5 != nullptr ) /*0x10376f487*/
LABEL_9:
    (*(void (__fastcall **)(RBX::Rupp::ClientRuppGenerator *))(*(_QWORD *)v5 + 8LL))(a1: v5); /*0x10376f49b*/
  if ( (_DWORD)v7 == 0 || (_DWORD)v7 == 12 ) /*0x10376f4ad*/
    goto LABEL_12; /*0x10376f4ad*/
  v9 = v12; /*0x10376f4c6*/
  v12 = 0; /*0x10376f4ca*/
  if ( v9 != 0 ) /*0x10376f4d5*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v9 + 8LL))(a1: v9); /*0x10376f4da*/
  return a1; /*0x10376f4b9*/
}

// Address: 0x10376f6e9 | Name: __ZN3RBX12RbxTransport8Protocol31protocolReasonCodeToStateReasonENS1_18ProtocolReasonCodeE
__int64 __fastcall RBX::RbxTransport::Protocol::protocolReasonCodeToStateReason(
        __int64 a1,
        unsigned int a2,
        __int64 a3,
        int *a4)
{
  unsigned int v6; // r15d
  const char *v7; // rsi
  _BYTE v9[16]; // [rsp+8h] [rbp-38h] BYREF
  void *v10; // [rsp+18h] [rbp-28h]

  v6 = 4 * (a2 == 1) + 64; /*0x10376f706*/
  if ( a2 > 0x10 ) /*0x10376f711*/
  {
    v7 = "InvalidProtocolReasonCode"; /*0x10376f726*/
  }
  else
  {
    a4 = dword_109570770; /*0x10376f716*/
    v7 = (char *)dword_109570770 + dword_109570770[a2]; /*0x10376f721*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v9, a2: v7, a3, a4); /*0x10376f734*/
  RBX::Network::StateReason::StateReason(a1, a2: v6, a3: a2, a4: v9); /*0x10376f745*/
  if ( (v9[0] & 1) != 0 ) /*0x10376f74e*/
    operator delete(a1: v10); /*0x10376f754*/
  return a1; /*0x10376f75c*/
}

// Address: 0x10376f783 | Name: __ZN3RBX12RbxTransport8Protocol30channelReasonCodeToStateReasonENS_7Network11ReasonClassENS1_22ChannelStateReasonCodeE
__int64 __fastcall RBX::RbxTransport::Protocol::channelReasonCodeToStateReason(
        __int64 a1,
        unsigned int a2,
        __int64 a3,
        int *a4)
{
  unsigned int v4; // r14d
  const char *v7; // rsi
  _BYTE v9[16]; // [rsp+8h] [rbp-38h] BYREF
  void *v10; // [rsp+18h] [rbp-28h]

  v4 = a3; /*0x10376f792*/
  if ( (unsigned int)(a3 - 1) > 4 ) /*0x10376f7a2*/
  {
    v7 = "InvalidChannelStateReasonCode"; /*0x10376f7b6*/
  }
  else
  {
    a4 = dword_1095707B4; /*0x10376f7a6*/
    v7 = (char *)dword_1095707B4 + dword_1095707B4[(unsigned int)(a3 - 1)]; /*0x10376f7b1*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v9, a2: v7, a3, a4); /*0x10376f7c4*/
  RBX::Network::StateReason::StateReason(a1, a2, a3: v4, a4: v9); /*0x10376f7d5*/
  if ( (v9[0] & 1) != 0 ) /*0x10376f7de*/
    operator delete(a1: v10); /*0x10376f7e4*/
  return a1; /*0x10376f7ec*/
}

// Address: 0x1037704bb | Name: __ZN3RBX12RbxTransport8Protocol24ngtcp2ErrorToStateReasonERK12ngtcp2_ccerr
RBX::Network *__fastcall RBX::RbxTransport::Protocol::ngtcp2ErrorToStateReason(
        RBX::Network *this,
        int *a2,
        __int64 a3,
        __int64 a4)
{
  unsigned int v5; // r14d
  __int64 v6; // rax
  __int64 v7; // rdx
  __int64 v8; // rcx
  void *v9; // rdi
  unsigned int v10; // r14d
  __int64 v11; // rax
  __int64 v12; // rdx
  __int64 v13; // rcx
  _BYTE v15[16]; // [rsp+8h] [rbp-68h] BYREF
  void *v16; // [rsp+18h] [rbp-58h]
  _BYTE v17[16]; // [rsp+20h] [rbp-50h] BYREF
  void *v18; // [rsp+30h] [rbp-40h]
  _BYTE v19[16]; // [rsp+38h] [rbp-38h] BYREF
  void *v20; // [rsp+48h] [rbp-28h]

  v5 = *a2; /*0x1037704cd*/
  if ( (unsigned int)(*a2 - 2) >= 4 ) /*0x1037704d7*/
  {
    if ( v5 != 0 ) /*0x103770522*/
    {
      if ( v5 == 1 ) /*0x103770528*/
      {
        RBX::Network::deserializeStateReason(this, a2: *((_QWORD *)a2 + 1)); /*0x103770531*/
        return this; /*0x103770536*/
      }
      std::string::basic_string[abi:ne200100]<0>(a1: v19, a2: "Unknown ngtcp2_ccerr type", a3, a4); /*0x103770588*/
      RBX::Network::StateReason::StateReason(a1: this, a2: 0, a3: 0, a4: v19); /*0x103770597*/
      if ( (v19[0] & 1) == 0 ) /*0x1037705a0*/
        return this; /*0x1037705a0*/
      v9 = v20; /*0x1037705b2*/
    }
    else
    {
      v10 = a2[2]; /*0x10377053c*/
      v11 = RBX::RbxTransport::Protocol::ngtcp2ErrorToString(a1: a2); /*0x103770543*/
      std::string::basic_string[abi:ne200100]<0>(a1: v17, a2: v11, a3: v12, a4: v13); /*0x103770552*/
      RBX::Network::StateReason::StateReason(a1: this, a2: 66, a3: v10, a4: v17); /*0x103770565*/
      if ( (v17[0] & 1) == 0 ) /*0x10377056e*/
        return this; /*0x10377056e*/
      v9 = v18; /*0x103770570*/
    }
    goto LABEL_4; /*0x1037705b6*/
  }
  v6 = RBX::RbxTransport::Protocol::ngtcp2ErrorToString(a1: a2); /*0x1037704e0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v15, a2: v6, a3: v7, a4: v8); /*0x1037704ef*/
  RBX::Network::StateReason::StateReason(a1: this, a2: 65, a3: v5, a4: v15); /*0x103770502*/
  if ( (v15[0] & 1) != 0 ) /*0x10377050b*/
  {
    v9 = v16; /*0x103770511*/
LABEL_4:
    operator delete(a1: v9); /*0x103770515*/
  }
  return this; /*0x1037705a5*/
}

// Address: 0x1037705eb | Name: __ZN3RBX12RbxTransport8Protocol19ngtcp2ErrorToStringERK12ngtcp2_ccerr
const char *__fastcall RBX::RbxTransport::Protocol::ngtcp2ErrorToString(__int64 a1, int a2)
{
  RBX::RbxTransport::Protocol *v2; // rdi
  const char *result; // rax

  switch ( *(_DWORD *)a1 ) /*0x103770606*/
  {
    case 0: /*0x103770606*/
      v2 = *(RBX::RbxTransport::Protocol **)(a1 + 8); /*0x10377060c*/
      if ( (unsigned __int64)v2 < 0x100 ) /*0x103770617*/
        result = (const char *)RBX::RbxTransport::Protocol::quicErrorToString(this: v2, a2); /*0x103770661*/
      else
        result = (const char *)RBX::RbxTransport::Protocol::tlsErrorToString(this: v2, a2); /*0x103770619*/
      break; /*0x10377061e*/
    case 1: /*0x103770606*/
      result = ""; /*0x103770642*/
      break; /*0x10377064b*/
    case 2: /*0x103770606*/
      result = "Version Negotiation Error"; /*0x10377062d*/
      break; /*0x103770634*/
    case 3: /*0x103770606*/
      result = "Idle Timeout"; /*0x103770635*/
      break; /*0x103770641*/
    case 4: /*0x103770606*/
      result = "Connection Dropped"; /*0x103770620*/
      break; /*0x10377062c*/
    case 5: /*0x103770606*/
      result = "Retry Error"; /*0x10377064c*/
      break; /*0x103770658*/
    default:
      result = "Unknown ngtcp2_ccerr type"; /*0x103770659*/
      break; /*0x103770660*/
  }
  return result; /*0x10377062c*/
}

// Address: 0x103770680 | Name: __ZN3RBX12RbxTransport8Protocol17quicErrorToStringEi
const char *__fastcall RBX::RbxTransport::Protocol::quicErrorToString(RBX::RbxTransport::Protocol *this)
{
  if ( (unsigned int)this > 0x11 ) /*0x103770687*/
    return "Unknown QUIC transport error code"; /*0x1037706a6*/
  else
    return (char *)dword_109570858 + dword_109570858[(unsigned int)this]; /*0x1037706a1*/
}

// Address: 0x1037706b4 | Name: __ZN3RBX12RbxTransport8Protocol16tlsErrorToStringEi
const char *__fastcall RBX::RbxTransport::Protocol::tlsErrorToString(RBX::RbxTransport::Protocol *this)
{
  const char *result; // rax

  if ( (int)this > 325 ) /*0x1037706be*/
  {
    if ( (int)this > 345 ) /*0x1037706f2*/
    {
      switch ( (_DWORD)this ) /*0x103770726*/
      {
        case 0x15A: /*0x103770726*/
          return "User Canceled"; /*0x103770845*/
        case 0x164: /*0x103770726*/
          return "No Renegotiation"; /*0x103770861*/
        case 0x16E: /*0x103770726*/
          return "Unsupported Extension"; /*0x103770747*/
        default:
          break; /*0x103770726*/
      }
    }
    else
    {
      switch ( (_DWORD)this ) /*0x1037706fa*/
      {
        case 0x146: /*0x1037706fa*/
          return "Protocol Version"; /*0x103770843*/
        case 0x147: /*0x1037706fa*/
          return "Insufficient Security"; /*0x103770853*/
        case 0x148: /*0x1037706fa*/
          return "Internal Error"; /*0x10377071b*/
        default:
          break; /*0x1037706fa*/
      }
    }
    return "Unknown TLS alert code"; /*0x103770778*/
  }
  switch ( (int)this ) /*0x1037706de*/
  {
    case 276: /*0x1037706de*/
      return "Bad Record MAC"; /*0x1037706e7*/
    case 277: /*0x1037706de*/
      return "Decryption Failed"; /*0x1037707e9*/
    case 278: /*0x1037706de*/
      return "Record Overflow"; /*0x103770807*/
    case 279: /*0x1037706de*/
    case 280: /*0x1037706de*/
    case 281: /*0x1037706de*/
    case 282: /*0x1037706de*/
    case 283: /*0x1037706de*/
    case 284: /*0x1037706de*/
    case 285: /*0x1037706de*/
    case 287: /*0x1037706de*/
    case 288: /*0x1037706de*/
    case 289: /*0x1037706de*/
    case 290: /*0x1037706de*/
    case 291: /*0x1037706de*/
    case 292: /*0x1037706de*/
    case 293: /*0x1037706de*/
    case 294: /*0x1037706de*/
    case 295: /*0x1037706de*/
    case 308: /*0x1037706de*/
    case 309: /*0x1037706de*/
    case 310: /*0x1037706de*/
    case 311: /*0x1037706de*/
    case 312: /*0x1037706de*/
    case 313: /*0x1037706de*/
    case 314: /*0x1037706de*/
    case 315: /*0x1037706de*/
      return "Unknown TLS alert code";
    case 286: /*0x1037706de*/
      return "Decompression Failure"; /*0x1037707e7*/
    case 296: /*0x1037706de*/
      return "Handshake Failure"; /*0x1037707de*/
    case 297: /*0x1037706de*/
      return "No Certificate"; /*0x103770809*/
    case 298: /*0x1037706de*/
      return "Bad Certificate"; /*0x10377082e*/
    case 299: /*0x1037706de*/
      return "Unsupported Certificate"; /*0x1037707c0*/
    case 300: /*0x1037706de*/
      return "Certificate Revoked"; /*0x103770820*/
    case 301: /*0x1037706de*/
      return "Certificate Expired"; /*0x1037707fe*/
    case 302: /*0x1037706de*/
      return "Certificate Unknown"; /*0x1037707b2*/
    case 303: /*0x1037706de*/
      return "Illegal Parameter"; /*0x1037707d5*/
    case 304: /*0x1037706de*/
      return "Unknown CA"; /*0x103770789*/
    case 305: /*0x1037706de*/
      return "Access Denied"; /*0x103770795*/
    case 306: /*0x1037706de*/
      return "Decode Error"; /*0x10377081e*/
    case 307: /*0x1037706de*/
      return "Decrypt Error"; /*0x1037707cc*/
    case 316: /*0x1037706de*/
      return "Export Restriction"; /*0x1037707a6*/
    default:
      if ( (_DWORD)this == 256 ) /*0x103770752*/
      {
        result = "Close Notify"; /*0x10377086f*/
      }
      else
      {
        if ( (_DWORD)this != 266 ) /*0x10377075e*/
          return "Unknown TLS alert code"; /*0x10377075e*/
        result = "Unexpected Messages"; /*0x103770760*/
      }
      break; /*0x103770767*/
  }
  return result; /*0x103770876*/
}

// Address: 0x103770958 | Name: __ZN3RBX12RbxTransport8Protocol16BasePacketSenderINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEEC2ERNS0_2Io14AsyncUdpSocketEPNS1_22SocketSendStatsTrackerE
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::BasePacketSender(
        __int64 a1,
        __int64 a2,
        __int64 a3)
{
  __int64 v4; // rbx
  __int64 DefaultArena; // rax
  RSL::Arena *v6; // rdi
  __int64 v7; // rax

  *(_QWORD *)a1 = &off_10C8EAD50; /*0x103770971*/
  *(_QWORD *)(a1 + 8) = a2; /*0x103770974*/
  *(_QWORD *)(a1 + 16) = a3; /*0x103770978*/
  v4 = a1 + 24; /*0x10377097c*/
  DefaultArena = RSL::Arena::getDefaultArena(this: (RSL::Arena *)a1); /*0x103770980*/
  *(_OWORD *)(a1 + 24) = 0; /*0x103770988*/
  *(_QWORD *)(a1 + 40) = 0; /*0x103770990*/
  *(_QWORD *)(a1 + 48) = DefaultArena; /*0x103770994*/
  v7 = RSL::Arena::getDefaultArena(this: v6); /*0x10377099c*/
  *(_OWORD *)(a1 + 56) = 0; /*0x1037709a4*/
  *(_QWORD *)(a1 + 72) = 0; /*0x1037709a9*/
  *(_QWORD *)(a1 + 80) = v7; /*0x1037709ad*/
  *(_QWORD *)(a1 + 88) = 0; /*0x1037709b1*/
  std::vector<RBX::RbxTransport::Protocol::TxItem,RSL::Detail::Allocator<RBX::RbxTransport::Protocol::TxItem>>::reserve( /*0x1037709bd*/
    a1: v4,
    a2: 64);
  return std::vector<RBX::RbxTransport::Io::UdpMsg,RSL::Detail::Allocator<RBX::RbxTransport::Io::UdpMsg>>::reserve( /*0x1037709cf*/
           a1: a1 + 56,
           a2: 64);
}

// Address: 0x103770be6 | Name: __ZN3RBX12RbxTransport8Protocol16BasePacketSenderINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEEC1ERNS0_2Io14AsyncUdpSocketEPNS1_22SocketSendStatsTrackerE
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::BasePacketSender(
        __int64 a1,
        __int64 a2,
        __int64 a3)
{
  return RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::BasePacketSender( /*0x103770bea*/
           a1,
           a2,
           a3);
}

// Address: 0x103770bf0 | Name: __ZN3RBX12RbxTransport8Protocol16BasePacketSenderINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE16processPendingTxERN3RSL6VectorINS5_4pairIPSA_mEEEE
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(
        __int64 a1,
        __int64 a2,
        __int64 a3)
{
  RBX::Profiler::PerFrameTelemetry *v6; // r12
  RBX::Profiler::PerFrameTelemetry *Token; // r12
  _QWORD v9[13]; // [rsp+0h] [rbp-A0h] BYREF
  uint64_t v10[7]; // [rsp+68h] [rbp-38h] BYREF

  if ( (_BYTE)`guard variable for'RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(RSL::Vector<std::pair<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>*,unsigned long>> &)::proftoken40 == 0 /*0x103770ca6*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(RSL::Vector<std::pair<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>*,unsigned long>> &)::proftoken40) != 0 )
  {
    v9[0] = "DisableDRS"; /*0x103770ccf*/
    Token = (RBX::Profiler::PerFrameTelemetry *)RBX::Profiler::getToken( /*0x103770cf3*/
                                                  this: (RBX::Profiler *)&aFlogBackendcon_50[-874749],
                                                  a2: &aDebugdisabledr[-505766],
                                                  a3: (const char *)0xFFFFFFFFLL);
    RBX::Profiler::PerFrameTelemetry::activateForTelemetry(a1: Token); /*0x103770cf9*/
    RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(RSL::Vector<std::pair<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>*,unsigned long>> &)::proftoken40 = (__int64)Token; /*0x103770cfe*/
    __cxa_guard_release(a1: &`guard variable for'RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(RSL::Vector<std::pair<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>*,unsigned long>> &)::proftoken40); /*0x103770d0c*/
  }
  v6 = (RBX::Profiler::PerFrameTelemetry *)RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(RSL::Vector<std::pair<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>*,unsigned long>> &)::proftoken40; /*0x103770c18*/
  *(_OWORD *)v9 = 0; /*0x103770c29*/
  v9[3] = -1; /*0x103770c2c*/
  memset(&v9[4], 0, 52); /*0x103770c34*/
  *(_OWORD *)&v9[11] = 0; /*0x103770c47*/
  v9[2] = RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(RSL::Vector<std::pair<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>*,unsigned long>> &)::proftoken40; /*0x103770c4b*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v9); /*0x103770c4f*/
  v9[3] = RBX::Profiler::PerFrameTelemetry::enterTelemetryRegion(a1: v6, a2: v10, a3: 1); /*0x103770c68*/
  RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTxPriv( /*0x103770c75*/
    a1,
    a2,
    a3);
  RBX::Profiler::TelemetryScope::~TelemetryScope(this: (RBX::Profiler::TelemetryScope *)v9); /*0x103770c81*/
  return a1; /*0x103770c89*/
}

// Address: 0x103770d3e | Name: __ZN3RBX12RbxTransport8Protocol16BasePacketSenderINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE20processPendingTxPrivERN3RSL6VectorINS5_4pairIPSA_mEEEE
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTxPriv(
        __int64 a1,
        _QWORD *a2,
        _QWORD *a3)
{
  __int64 v4; // rax
  char v5; // r12
  bool v6; // al
  char v7; // cl
  unsigned __int64 v8; // r13
  __int64 v9; // r12
  __int64 v10; // rax
  __int64 *v11; // r12
  __int64 v12; // rcx
  __int64 v13; // rdx
  char v14; // r15
  bool v15; // zf
  __int64 v16; // rbx
  __int128 *v17; // r15
  _QWORD *v18; // r14
  __int64 v19; // rax
  __int64 v20; // rcx
  _QWORD v22[4]; // [rsp+0h] [rbp-110h] BYREF
  _QWORD *v23; // [rsp+20h] [rbp-F0h]
  __int64 v24; // [rsp+28h] [rbp-E8h]
  int v25; // [rsp+30h] [rbp-E0h] BYREF
  __int128 v26; // [rsp+38h] [rbp-D8h] BYREF
  void *v27; // [rsp+48h] [rbp-C8h]
  unsigned __int64 v28; // [rsp+50h] [rbp-C0h]
  _QWORD *v29; // [rsp+58h] [rbp-B8h]
  int v30; // [rsp+60h] [rbp-B0h]
  char v31; // [rsp+67h] [rbp-A9h]
  int v32; // [rsp+68h] [rbp-A8h] BYREF
  __int128 v33; // [rsp+70h] [rbp-A0h]
  void *v34; // [rsp+80h] [rbp-90h]
  _BYTE v35[28]; // [rsp+98h] [rbp-78h] BYREF
  char v36; // [rsp+B4h] [rbp-5Ch]
  _BYTE v37[32]; // [rsp+B8h] [rbp-58h] BYREF
  char v38; // [rsp+D8h] [rbp-38h]

  v24 = a1; /*0x103770d55*/
  v25 = 0; /*0x103770d71*/
  v26 = 0; /*0x103770d7b*/
  v27 = nullptr; /*0x103770d7e*/
  v4 = a2[8]; /*0x103770d86*/
  v29 = a2; /*0x103770d8a*/
  v5 = 1; /*0x103770da7*/
  if ( 0xCCCCCCCCCCCCCCCDLL * ((v4 - a2[7]) >> 3) >= 0x40 ) /*0x103770dae*/
  {
    RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::sendBatch( /*0x103770dbe*/
      a1: &v32,
      a2: v29);
    v25 = v32; /*0x103770dc9*/
    if ( (v26 & 1) != 0 ) /*0x103770dd6*/
      operator delete(a1: v27); /*0x103770ddf*/
    v27 = v34; /*0x103770deb*/
    v26 = v33; /*0x103770df6*/
    v5 = RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v25); /*0x103770e05*/
  }
  v6 = a3[1] != *a3; /*0x103770e0f*/
  v28 = (__int64)(a3[1] - *a3) >> 4; /*0x103770e16*/
  if ( ((unsigned __int8)v5 & v6) == 1 ) /*0x103770e22*/
  {
    v7 = 1; /*0x103770e28*/
    v8 = 0; /*0x103770e31*/
    v30 = 0; /*0x103770e34*/
    v23 = a3; /*0x103770e3e*/
    while ( 1 ) /*0x103770feb*/
    {
      v31 = v7; /*0x103770e45*/
      RBX::RbxTransport::Packet::Packet(a1: &v32, a2: 0); /*0x103770e50*/
      v35[0] = 0; /*0x103770e57*/
      v36 = 0; /*0x103770e5a*/
      v37[0] = 0; /*0x103770e5d*/
      v38 = 0; /*0x103770e60*/
      v9 = 16 * v8; /*0x103770e69*/
      if ( (unsigned __int8)RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>::read( /*0x103770e7e*/
                              a1: *(_QWORD *)(*a3 + 16 * v8),
                              a2: &v32) != 0 )
      {
        RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::addToBatch( /*0x103770e8a*/
          a1: v29,
          a2: &v32);
        ++v30; /*0x103770e8f*/
        v10 = *a3; /*0x103770e95*/
        --*(_QWORD *)(*a3 + v9 + 8); /*0x103770e98*/
      }
      else
      {
        v10 = *a3; /*0x103770e9f*/
        *(_QWORD *)(*a3 + v9 + 8) = 0; /*0x103770ea2*/
      }
      if ( *(_QWORD *)(v10 + v9 + 8) == 0 ) /*0x103770eb1*/
      {
        v11 = (__int64 *)(v10 + v9); /*0x103770eb3*/
        --v28; /*0x103770ec0*/
        v12 = 16 * v28; /*0x103770ec7*/
        v13 = *v11; /*0x103770ecb*/
        *v11 = *(_QWORD *)(v10 + 16 * v28); /*0x103770ed3*/
        *(_QWORD *)(v10 + v12) = v13; /*0x103770ed7*/
        v11[1] = *(_QWORD *)(v10 + v12 + 8); /*0x103770ee0*/
        *(_QWORD *)(v10 + v12 + 8) = 0; /*0x103770ee5*/
        --v8; /*0x103770eee*/
      }
      if ( 0xCCCCCCCCCCCCCCCDLL * ((__int64)(v29[8] - v29[7]) >> 3) < 0x40 ) /*0x103770f16*/
        goto LABEL_16; /*0x103770f16*/
      RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::sendBatch( /*0x103770f26*/
        a1: v22,
        a2: v29);
      v25 = v22[0]; /*0x103770f31*/
      if ( (v26 & 1) != 0 ) /*0x103770f3e*/
        operator delete(a1: v27); /*0x103770f47*/
      v27 = (void *)v22[3]; /*0x103770f5e*/
      v26 = *(_OWORD *)&v22[1]; /*0x103770f65*/
      if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v25) != 0 ) /*0x103770f76*/
      {
LABEL_16:
        v14 = 1; /*0x103770f78*/
        v5 = v31; /*0x103770f81*/
      }
      else
      {
        v5 = 0; /*0x103770f86*/
        v14 = 0; /*0x103770f89*/
      }
      if ( v38 == 1 ) /*0x103770f93*/
        RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v37); /*0x103770f99*/
      if ( v36 == 1 ) /*0x103770fa2*/
        RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v35); /*0x103770fa8*/
      RBX::RbxTransport::Packet::~Packet(this: (RBX::RbxTransport::Packet *)&v32); /*0x103770fb0*/
      ++v8; /*0x103770fb5*/
      v7 = v5; /*0x103770fc2*/
      v15 = ((v8 < v28) & (unsigned __int8)v14) == 0; /*0x103770fc5*/
      a3 = v23; /*0x103770fc8*/
      if ( v15 ) /*0x103770fcf*/
      {
        v8 = 0; /*0x103770fe0*/
        v7 = 1; /*0x103770fe6*/
        if ( ((v28 != 0) & (unsigned __int8)v5) == 0 ) /*0x103770feb*/
          break; /*0x103770feb*/
      }
    }
  }
  else
  {
    v30 = 0; /*0x103770ff3*/
  }
  v16 = v24; /*0x103771001*/
  v17 = &v26; /*0x103771008*/
  if ( (v5 & 1) != 0 ) /*0x10377100f*/
  {
    v18 = v29; /*0x103771015*/
    v19 = v29[7]; /*0x10377101c*/
    v20 = v29[8]; /*0x103771020*/
    if ( v29[11] < 0xCCCCCCCCCCCCCCCDLL * ((v20 - v19) >> 3) ) /*0x103771040*/
    {
      RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::sendBatch( /*0x10377104c*/
        a1: &v32,
        a2: v29);
      v25 = v32; /*0x103771057*/
      if ( (v26 & 1) != 0 ) /*0x103771064*/
        operator delete(a1: v27); /*0x10377106d*/
      v27 = v34; /*0x103771079*/
      v26 = v33; /*0x103771084*/
      v19 = v18[7]; /*0x103771088*/
      v20 = v18[8]; /*0x10377108c*/
    }
    if ( v19 == v20 /*0x1037710a3*/
      && (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v25) != 0 )
    {
      *(_DWORD *)v16 = 0; /*0x1037710a5*/
LABEL_37:
      v17 = (__int128 *)(v16 + 8); /*0x1037710d4*/
      goto LABEL_39; /*0x1037710d8*/
    }
  }
  if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v25) != 0 /*0x1037710cc*/
    || (unsigned int)RBX::RbxTransport::Io::Error::getCode(this: (RBX::RbxTransport::Io::Error *)&v25) == 3 )
  {
    *(_DWORD *)v16 = 3; /*0x1037710ce*/
    goto LABEL_37; /*0x1037710ce*/
  }
  *(_DWORD *)v16 = v25; /*0x1037710e0*/
  *(_OWORD *)(v16 + 8) = v26; /*0x1037710e6*/
  *(_QWORD *)(v16 + 24) = v27; /*0x1037710ee*/
LABEL_39:
  *v17 = 0; /*0x1037710f2*/
  *((_QWORD *)v17 + 2) = 0; /*0x1037710f9*/
  *(_DWORD *)(v16 + 32) = v30; /*0x103771107*/
  *(_QWORD *)(v16 + 40) = v28; /*0x103771111*/
  if ( (v26 & 1) != 0 ) /*0x10377111c*/
    operator delete(a1: v27); /*0x103771125*/
  return v16; /*0x10377113d*/
}

// Address: 0x103771190 | Name: __ZN3RBX12RbxTransport8Protocol16BasePacketSenderINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE7getSockEv
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::getSock(
        __int64 a1)
{
  return *(_QWORD *)(a1 + 8); /*0x103771198*/
}

// Address: 0x10377119a | Name: __ZN3RBX12RbxTransport8Protocol16BasePacketSenderINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE9sendBatchEv
int *__fastcall RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::sendBatch(
        int *a1,
        unsigned __int64 a2)
{
  _QWORD *v2; // r15
  char v3; // r14
  __int64 v4; // rax
  unsigned __int64 v5; // rcx
  unsigned __int64 v6; // rdx
  bool v7; // cc
  unsigned __int64 v8; // rcx
  RBX::RbxTransport::Protocol::SocketSendStatsTracker *v9; // rdi
  __int64 v10; // rdx
  __int64 v11; // rsi
  int v12; // r12d
  __int128 *v13; // rcx
  _OWORD *v14; // rdx
  char v15; // bl
  int Code; // eax
  bool v17; // zf
  int *v18; // rbx
  __int64 v19; // rax
  __int64 v20; // rcx
  unsigned __int64 v21; // rdx
  _DWORD *v22; // rax
  int v23; // eax
  _OWORD *v24; // rdx
  int v26; // [rsp+8h] [rbp-88h] BYREF
  char v27[16]; // [rsp+10h] [rbp-80h] BYREF
  void *v28; // [rsp+20h] [rbp-70h]
  unsigned __int64 v29; // [rsp+28h] [rbp-68h]
  int v30; // [rsp+30h] [rbp-60h] BYREF
  __int128 v31; // [rsp+38h] [rbp-58h] BYREF
  void *v32; // [rsp+48h] [rbp-48h]
  int *v33; // [rsp+50h] [rbp-40h]
  _DWORD *v34; // [rsp+58h] [rbp-38h]
  int v35; // [rsp+64h] [rbp-2Ch]

  v2 = (_QWORD *)a2; /*0x1037711ab*/
  v30 = 0; /*0x1037711b2*/
  v31 = 0; /*0x1037711bc*/
  v32 = nullptr; /*0x1037711bf*/
  v35 = *a1; /*0x1037711c9*/
  v33 = a1; /*0x1037711cc*/
  v34 = a1 + 2; /*0x1037711d4*/
  v3 = 1; /*0x1037711d8*/
  while ( 1 ) /*0x1037711e2*/
  {
    v4 = v2[7]; /*0x1037711e2*/
    v5 = 0xCCCCCCCCCCCCCCCDLL * ((v2[8] - v4) >> 3); /*0x1037711fb*/
    v6 = v2[11]; /*0x1037711ff*/
    v7 = v5 <= v6; /*0x103771203*/
    v8 = v5 - v6; /*0x103771203*/
    if ( v7 ) /*0x103771206*/
    {
      RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::clearBatch( /*0x1037713b4*/
        a1: v2,
        a2,
        a3: v6,
        a4: v8);
      v23 = v30; /*0x1037713b9*/
      v18 = v33; /*0x1037713bc*/
LABEL_29:
      *v18 = v23; /*0x1037713c5*/
      v24 = v34; /*0x1037713cf*/
      *((_QWORD *)v34 + 2) = v32; /*0x1037713d3*/
      *v24 = v31; /*0x1037713da*/
      v31 = 0; /*0x1037713e0*/
      v32 = nullptr; /*0x1037713e3*/
      goto LABEL_31; /*0x1037713eb*/
    }
    RBX::RbxTransport::Io::AsyncUdpSocket::trySendMmsg(a1: &v26, a2: v2[1], a3: v4 + 40 * v6, a4: v8); /*0x10377121b*/
    v9 = (RBX::RbxTransport::Protocol::SocketSendStatsTracker *)v2[2]; /*0x103771220*/
    if ( v9 != nullptr ) /*0x103771227*/
      RBX::RbxTransport::Protocol::SocketSendStatsTracker::trackSocketSendResult( /*0x103771230*/
        this: v9,
        a2: (const RBX::RbxTransport::Io::Error *)&v26,
        a3: v29);
    if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v26) != 0 /*0x103771263*/
      && v29 == 0xCCCCCCCCCCCCCCCDLL * ((__int64)(v2[8] - v2[7]) >> 3) - v2[11] )
    {
      RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::clearBatch( /*0x103771268*/
        a1: v2,
        a2: v11,
        a3: v10,
        a4: 0xCCCCCCCCCCCCCCCDLL);
      v12 = v30; /*0x10377126d*/
      v13 = &v31; /*0x103771271*/
      v14 = v34; /*0x103771279*/
      *((_QWORD *)v34 + 2) = v32; /*0x10377127d*/
      *v14 = v31; /*0x103771284*/
    }
    else
    {
      if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v26) != 0 ) /*0x103771293*/
      {
        a2 = v29; /*0x103771295*/
        if ( v29 != 0 ) /*0x10377129c*/
        {
          v15 = 0; /*0x10377129e*/
          RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::popFromBatch( /*0x1037712a3*/
            a1: v2,
            a2: v29);
          goto LABEL_17; /*0x1037712a8*/
        }
        v12 = 3; /*0x1037712f8*/
LABEL_15:
        v13 = (__int128 *)v34; /*0x1037712fe*/
        goto LABEL_16; /*0x1037712fe*/
      }
      v12 = 3; /*0x1037712b2*/
      if ( (unsigned int)RBX::RbxTransport::Io::Error::getCode(this: (RBX::RbxTransport::Io::Error *)&v26) == 3 ) /*0x1037712bb*/
        goto LABEL_15; /*0x1037712bb*/
      Code = RBX::RbxTransport::Io::Error::getCode(this: (RBX::RbxTransport::Io::Error *)&v26); /*0x1037712c0*/
      v13 = (__int128 *)v34; /*0x1037712c5*/
      if ( Code != 6 ) /*0x1037712cc*/
      {
        v30 = v26; /*0x1037712d4*/
        std::string::operator=(a1: &v31, a2: v27); /*0x1037712df*/
        v15 = 4; /*0x1037712e4*/
        RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::popFromBatch( /*0x1037712f1*/
          a1: v2,
          a2: 1);
        goto LABEL_17; /*0x1037712f6*/
      }
    }
LABEL_16:
    *v13 = 0; /*0x103771305*/
    *((_QWORD *)v13 + 2) = 0; /*0x103771308*/
    v15 = 1; /*0x103771310*/
    v35 = v12; /*0x103771315*/
LABEL_17:
    if ( (v27[0] & 1) != 0 ) /*0x10377131d*/
      operator delete(a1: v28); /*0x103771323*/
    if ( (v15 & 3) != 0 ) /*0x10377132b*/
      break; /*0x10377132b*/
    v17 = (v3 & 1) == 0; /*0x103771331*/
    v3 = 0; /*0x103771335*/
    if ( v17 ) /*0x10377133b*/
    {
      v18 = v33; /*0x103771341*/
      *v33 = v35; /*0x103771348*/
      v19 = v2[7]; /*0x10377134a*/
      v20 = v2[8]; /*0x10377134e*/
      if ( v19 != v20 ) /*0x103771355*/
      {
        v21 = 0xCCCCCCCCCCCCCCCDLL * ((v20 - v19) >> 3); /*0x10377136b*/
        if ( v2[11] >= v21 ) /*0x103771373*/
        {
          RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::clearBatch( /*0x103771378*/
            a1: v2,
            a2: 0xCCCCCCCCCCCCCCCDLL,
            a3: v21,
            a4: v20);
          v19 = v2[7]; /*0x10377137d*/
          v20 = v2[8]; /*0x103771381*/
        }
        if ( v19 != v20 /*0x103771395*/
          && (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v30) != 0 )
        {
          *v18 = 3; /*0x103771397*/
          v22 = v34; /*0x1037713a0*/
          *(_OWORD *)v34 = 0; /*0x1037713a4*/
          *((_QWORD *)v22 + 2) = 0; /*0x1037713a7*/
          goto LABEL_31; /*0x1037713af*/
        }
      }
      v23 = v30; /*0x1037713c2*/
      goto LABEL_29; /*0x1037713c2*/
    }
  }
  v18 = v33; /*0x1037713ed*/
  *v33 = v35; /*0x1037713f4*/
LABEL_31:
  if ( (v31 & 1) != 0 ) /*0x1037713fa*/
    operator delete(a1: v32); /*0x103771400*/
  return v18; /*0x103771408*/
}

// Address: 0x10377153c | Name: __ZN3RBX12RbxTransport8Protocol16BasePacketSenderINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE10addToBatchEOS4_
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::addToBatch(
        __int64 a1)
{
  __int64 v2; // r12
  _QWORD v4[2]; // [rsp+0h] [rbp-50h] BYREF
  __int128 v5; // [rsp+10h] [rbp-40h]
  __int64 v6; // [rsp+20h] [rbp-30h]

  std::vector<RBX::RbxTransport::Protocol::TxItem,RSL::Detail::Allocator<RBX::RbxTransport::Protocol::TxItem>>::push_back[abi:ne200100](a1: a1 + 24); /*0x103771552*/
  v2 = *(_QWORD *)(a1 + 32); /*0x103771557*/
  v5 = 0; /*0x103771563*/
  v4[0] = 0; /*0x103771567*/
  v6 = 0; /*0x10377156b*/
  v4[1] = RBX::RbxTransport::Packet::data(this: (RBX::RbxTransport::Packet *)(v2 - 120)); /*0x103771586*/
  *(_QWORD *)&v5 = RBX::RbxTransport::Packet::size(this: (RBX::RbxTransport::Packet *)(v2 - 120)); /*0x10377158a*/
  if ( *(_BYTE *)(v2 - 44) == 1 ) /*0x103771594*/
    v4[0] = v2 - 72; /*0x10377159b*/
  if ( *(_BYTE *)(v2 - 8) == 1 ) /*0x1037715a5*/
    *((_QWORD *)&v5 + 1) = v2 - 40; /*0x1037715ab*/
  return ((__int64 (__fastcall *)(__int64, _QWORD *))std::vector<RBX::RbxTransport::Io::UdpMsg,RSL::Detail::Allocator<RBX::RbxTransport::Io::UdpMsg>>::push_back[abi:ne200100])( /*0x1037715bf*/
           a1: a1 + 56,
           a2: v4);
}

// Address: 0x10377177a | Name: __ZN3RBX12RbxTransport8Protocol16BasePacketSenderINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE12popFromBatchEm
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::popFromBatch(
        __int64 a1,
        __int64 a2)
{
  RBX::RbxTransport::Packet *v3; // r15
  RBX::RbxTransport::Packet *v4; // rsi
  __int64 v5; // rbx
  __int64 v6; // r15
  RBX::RbxTransport::Packet *v7; // r14
  __int64 v8; // rax
  __int64 v9; // rcx
  __int64 v11; // [rsp+0h] [rbp-B0h]
  char v12; // [rsp+8h] [rbp-A8h] BYREF
  _BYTE v13[28]; // [rsp+38h] [rbp-78h] BYREF
  char v14; // [rsp+54h] [rbp-5Ch]
  _BYTE v15[32]; // [rsp+58h] [rbp-58h] BYREF
  char v16; // [rsp+78h] [rbp-38h]

  if ( a2 != 0 ) /*0x10377179f*/
  {
    v3 = (RBX::RbxTransport::Packet *)&v12; /*0x1037717a8*/
    do /*0x103771868*/
    {
      v11 = a2; /*0x1037717af*/
      RBX::RbxTransport::Packet::Packet(a1: v3, a2: 0); /*0x1037717bb*/
      v4 = v3; /*0x1037717c0*/
      v13[0] = 0; /*0x1037717c5*/
      v14 = 0; /*0x1037717c8*/
      v15[0] = 0; /*0x1037717cb*/
      v16 = 0; /*0x1037717ce*/
      v5 = a1; /*0x1037717d5*/
      v6 = 120LL * *(_QWORD *)(a1 + 88) + *(_QWORD *)(a1 + 24); /*0x1037717dd*/
      v7 = v4; /*0x1037717e4*/
      RBX::RbxTransport::Packet::operator=(this: (RBX::RbxTransport::Packet *)v6); /*0x1037717e7*/
      std::__optional_storage_base<RBX::RbxTransport::Io::EndpointAddr,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::RbxTransport::Io::EndpointAddr,false>>(this: (RBX::RbxTransport::Io::EndpointAddr *)(v6 + 48)); /*0x1037717f8*/
      std::__optional_storage_base<RBX::RbxTransport::Io::UdpDatagramAttrs,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::RbxTransport::Io::UdpDatagramAttrs,false>>(this: (RBX::RbxTransport::Io::EndpointAddr *)(v6 + 80)); /*0x103771808*/
      v3 = v7; /*0x103771811*/
      if ( v16 == 1 ) /*0x103771814*/
        RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v15); /*0x10377181a*/
      a1 = v5; /*0x103771823*/
      if ( v14 == 1 ) /*0x103771826*/
        RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v13); /*0x10377182c*/
      RBX::RbxTransport::Packet::~Packet(this: v3); /*0x103771834*/
      v8 = *(_QWORD *)(v5 + 56); /*0x103771839*/
      v9 = 5LL * *(_QWORD *)(v5 + 88); /*0x103771841*/
      *(_OWORD *)(v8 + 8 * v9 + 16) = 0; /*0x103771848*/
      *(_OWORD *)(v8 + 8 * v9) = 0; /*0x10377184d*/
      *(_QWORD *)(v8 + 8 * v9 + 32) = 0; /*0x103771851*/
      ++*(_QWORD *)(v5 + 88); /*0x10377185a*/
      a2 = v11 - 1; /*0x103771865*/
    }
    while ( v11 != 1 ); /*0x103771868*/
  }
  return __stack_chk_guard; /*0x10377187e*/
}

// Address: 0x1037718ae | Name: __ZN3RBX12RbxTransport8Protocol16BasePacketSenderINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE10clearBatchEv
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::clearBatch(
        _QWORD *a1)
{
  __int64 result; // rax
  RBX::RbxTransport::Packet *v3; // r15
  RBX::RbxTransport::Packet *i; // r14

  a1[11] = 0; /*0x1037718bb*/
  result = a1[7]; /*0x1037718c3*/
  a1[8] = result; /*0x1037718c7*/
  v3 = (RBX::RbxTransport::Packet *)a1[3]; /*0x1037718cb*/
  for ( i = (RBX::RbxTransport::Packet *)a1[4]; /*0x1037718cf*/
        i != v3;
        result = std::__destroy_at[abi:ne200100]<RBX::RbxTransport::Protocol::TxItem,0>(this: i) )
  {
    i = (RBX::RbxTransport::Packet *)((char *)i - 120); /*0x1037718d8*/
  }
  a1[4] = v3; /*0x1037718e6*/
  return result; /*0x1037718ee*/
}

// Address: 0x1037735e6 | Name: __ZN3RBX12RbxTransport8Protocol16BasePacketSenderINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEED1Ev
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::~BasePacketSender(
        _QWORD *a1)
{
  _QWORD v3[3]; // [rsp+8h] [rbp-18h] BYREF

  *a1 = &off_10C8EAD50; /*0x1037735fb*/
  v3[0] = a1 + 7; /*0x103773606*/
  std::vector<RBX::RbxTransport::Io::UdpMsg,RSL::Detail::Allocator<RBX::RbxTransport::Io::UdpMsg>>::__destroy_vector::operator()[abi:ne200100](a1: v3); /*0x10377360c*/
  v3[0] = a1 + 3; /*0x103773615*/
  return std::vector<RBX::RbxTransport::Protocol::TxItem,RSL::Detail::Allocator<RBX::RbxTransport::Protocol::TxItem>>::__destroy_vector::operator()[abi:ne200100](a1: v3); /*0x103773621*/
}

// Address: 0x10377362a | Name: __ZN3RBX12RbxTransport8Protocol16BasePacketSenderINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEED0Ev
void __fastcall RBX::RbxTransport::Protocol::BasePacketSender<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::~BasePacketSender(
        char *a1)
{
  _QWORD v2[3]; // [rsp+8h] [rbp-18h] BYREF

  *(_QWORD *)a1 = &off_10C8EAD50; /*0x10377363f*/
  v2[0] = a1 + 56; /*0x10377364a*/
  std::vector<RBX::RbxTransport::Io::UdpMsg,RSL::Detail::Allocator<RBX::RbxTransport::Io::UdpMsg>>::__destroy_vector::operator()[abi:ne200100](a1: v2); /*0x103773650*/
  v2[0] = a1 + 24; /*0x103773659*/
  std::vector<RBX::RbxTransport::Protocol::TxItem,RSL::Detail::Allocator<RBX::RbxTransport::Protocol::TxItem>>::__destroy_vector::operator()[abi:ne200100](a1: v2); /*0x103773660*/
  operator delete(a1); /*0x103773668*/
}

// Address: 0x10377a4df | Name: __ZN3RBX12RbxTransport8Protocol23ngtcp2cidToConnectionIdERK10ngtcp2_cid
RBX::RbxTransport::Protocol::ConnectionId *__fastcall RBX::RbxTransport::Protocol::ngtcp2cidToConnectionId(
        RBX::RbxTransport::Protocol::ConnectionId *a1,
        __int64 a2)
{
  RBX::RbxTransport::Protocol::ConnectionId::ConnectionId( /*0x10377a4ef*/
    this: a1,
    a2: (const unsigned __int8 *)(a2 + 8),
    a3: *(_QWORD *)a2);
  return a1; /*0x10377a4fb*/
}

// Address: 0x10377f244 | Name: __ZN3RBX12RbxTransport8Protocol6RxItemaSEOS2_
__int64 __fastcall RBX::RbxTransport::Protocol::RxItem::operator=(__int64 a1, __int64 a2)
{
  __int128 v4; // xmm0
  _OWORD *v5; // rax
  __int128 *v6; // rcx
  char v7; // dl
  __int128 v8; // xmm0
  __int128 v9; // xmm1
  __int128 v10; // xmm2
  __int128 v11; // xmm0
  __int64 v12; // rax

  std::__optional_storage_base<RBX::RbxTransport::Packet,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::RbxTransport::Packet,false>>(this: (RBX::RbxTransport::Packet *)a1); /*0x10377f251*/
  v4 = *(_OWORD *)(a2 + 56); /*0x10377f256*/
  *(_OWORD *)(a1 + 72) = *(_OWORD *)(a2 + 72); /*0x10377f260*/
  *(_OWORD *)(a1 + 56) = v4; /*0x10377f264*/
  RBX::RbxTransport::Io::EndpointAddr::operator=(a1: a1 + 88, a2: a2 + 88); /*0x10377f270*/
  std::__optional_storage_base<RBX::RbxTransport::Io::UdpRecvAttrs,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::RbxTransport::Io::UdpRecvAttrs,false>>(this: (RBX::RbxTransport::Io::EndpointAddr *)(a1 + 120)); /*0x10377f27d*/
  if ( a1 != a2 ) /*0x10377f285*/
  {
    v5 = (_OWORD *)(a1 + 184); /*0x10377f28c*/
    v6 = (__int128 *)(a2 + 184); /*0x10377f290*/
    v7 = *(_BYTE *)(a2 + 280); /*0x10377f293*/
    *(_BYTE *)(a1 + 280) = v7; /*0x10377f29a*/
    if ( v7 == 1 ) /*0x10377f2a3*/
    {
      *(_OWORD *)(a1 + 264) = *(_OWORD *)(a2 + 264); /*0x10377f2a9*/
      *(_OWORD *)(a1 + 248) = *(_OWORD *)(a2 + 248); /*0x10377f2b1*/
      v8 = *v6; /*0x10377f2b5*/
      v9 = *(_OWORD *)(a2 + 200); /*0x10377f2b8*/
      v10 = *(_OWORD *)(a2 + 216); /*0x10377f2bc*/
      *(_OWORD *)(a1 + 232) = *(_OWORD *)(a2 + 232); /*0x10377f2c4*/
      *(_OWORD *)(a1 + 216) = v10; /*0x10377f2c8*/
      *(_OWORD *)(a1 + 200) = v9; /*0x10377f2cc*/
      *v5 = v8; /*0x10377f2d0*/
    }
    else
    {
      *(_DWORD *)v5 = *(_DWORD *)v6; /*0x10377f2d7*/
    }
  }
  std::__optional_storage_base<RBX::RbxTransport::Io::Error,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::RbxTransport::Io::Error,false>>( /*0x10377f2e5*/
    a1: a1 + 288,
    a2: a2 + 288);
  v11 = *(_OWORD *)(a2 + 328); /*0x10377f2ea*/
  *(_OWORD *)(a1 + 338) = *(_OWORD *)(a2 + 338); /*0x10377f2fa*/
  *(_OWORD *)(a1 + 328) = v11; /*0x10377f301*/
  if ( a1 != a2 ) /*0x10377f30b*/
  {
    v12 = *(_QWORD *)(a2 + 360); /*0x10377f30d*/
    *(_QWORD *)(a2 + 360) = 0; /*0x10377f314*/
    *(_QWORD *)(a1 + 360) = v12; /*0x10377f31f*/
  }
  return a1; /*0x10377f329*/
}

// Address: 0x103784084 | Name: __ZN3RBX12RbxTransport8Protocol12ngtcp2MallocEmPv
__int64 __fastcall RBX::RbxTransport::Protocol::ngtcp2Malloc(
        RBX::RbxTransport::Protocol *this,
        unsigned __int64 a2,
        void *a3)
{
  return RBX::Memory::allocate(this, a2); /*0x103784088*/
}

// Address: 0x10378408e | Name: __ZN3RBX12RbxTransport8Protocol10ngtcp2FreeEPvS2_
__int64 __fastcall RBX::RbxTransport::Protocol::ngtcp2Free(RBX::RbxTransport::Protocol *this, void *a2, void *a3)
{
  return RBX::Memory::deallocate(this, a2); /*0x103784092*/
}

// Address: 0x103784098 | Name: __ZN3RBX12RbxTransport8Protocol12ngtcp2CallocEmmPv
__int64 __fastcall RBX::RbxTransport::Protocol::ngtcp2Calloc(
        RBX::RbxTransport::Protocol *this,
        unsigned __int64 a2,
        unsigned __int64 a3,
        void *a4)
{
  return RBX::Memory::callocate(this, a2, a3); /*0x10378409c*/
}

// Address: 0x1037840a2 | Name: __ZN3RBX12RbxTransport8Protocol13ngtcp2ReallocEPvmS2_
__int64 __fastcall RBX::RbxTransport::Protocol::ngtcp2Realloc(
        RBX::RbxTransport::Protocol *this,
        void *a2,
        unsigned __int64 a3,
        void *a4)
{
  return RBX::Memory::reallocate(this, a2, a3); /*0x1037840a6*/
}

// Address: 0x10378ac0c | Name: __ZNK3RBX12RbxTransport8Protocol12ConnectionIdeqERKS2_
bool __fastcall RBX::RbxTransport::Protocol::ConnectionId::operator==(_QWORD *a1, _QWORD *a2)
{
  size_t v2; // rdx

  v2 = a1[3]; /*0x10378ac0c*/
  return v2 == a2[3] && memcmp(__s1: a1, __s2: a2, __n: v2) == 0; /*0x10378ac25*/
}

// Address: 0x10378ac2a | Name: __ZNK3RBX12RbxTransport8Protocol12ConnectionIdneERKS2_
bool __fastcall RBX::RbxTransport::Protocol::ConnectionId::operator!=(_QWORD *a1, _QWORD *a2)
{
  size_t v2; // rdx
  bool result; // al

  v2 = a1[3]; /*0x10378ac2a*/
  result = true; /*0x10378ac2e*/
  if ( v2 == a2[3] ) /*0x10378ac34*/
    return memcmp(__s1: a1, __s2: a2, __n: v2) != 0; /*0x10378ac41*/
  return result; /*0x10378ac45*/
}

// Address: 0x1037a71c4 | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEEC2ERNS0_2Io14AsyncUdpSocketEPNS1_22SocketSendStatsTrackerE
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::BasePacketSenderDeprecated(
        __int64 a1,
        __int64 a2,
        __int64 a3)
{
  __int64 DefaultArena; // rax
  RSL::Arena *v5; // rdi
  __int64 v6; // rax
  RSL::Arena *v7; // rdi
  __int64 v8; // rax
  RSL::Arena *v9; // rdi
  __int64 v10; // rax
  RSL::Arena *v11; // rdi
  __int64 v12; // rax
  RSL::Arena *v13; // rdi
  __int64 v14; // rax

  *(_QWORD *)a1 = a2; /*0x1037a71d8*/
  *(_QWORD *)(a1 + 8) = a3; /*0x1037a71db*/
  *(_QWORD *)(a1 + 16) = 0; /*0x1037a71e2*/
  DefaultArena = RSL::Arena::getDefaultArena(this: (RSL::Arena *)a1); /*0x1037a71ee*/
  *(_OWORD *)(a1 + 24) = 0; /*0x1037a71f6*/
  *(_QWORD *)(a1 + 40) = 0; /*0x1037a71fb*/
  *(_QWORD *)(a1 + 48) = DefaultArena; /*0x1037a71ff*/
  v6 = RSL::Arena::getDefaultArena(this: v5); /*0x1037a720b*/
  *(_OWORD *)(a1 + 56) = 0; /*0x1037a7213*/
  *(_QWORD *)(a1 + 72) = 0; /*0x1037a7218*/
  *(_QWORD *)(a1 + 80) = v6; /*0x1037a721c*/
  v8 = RSL::Arena::getDefaultArena(this: v7); /*0x1037a7224*/
  *(_OWORD *)(a1 + 88) = 0; /*0x1037a722c*/
  *(_QWORD *)(a1 + 104) = 0; /*0x1037a7231*/
  *(_QWORD *)(a1 + 112) = v8; /*0x1037a7235*/
  v10 = RSL::Arena::getDefaultArena(this: v9); /*0x1037a723d*/
  *(_OWORD *)(a1 + 120) = 0; /*0x1037a7245*/
  *(_QWORD *)(a1 + 136) = 0; /*0x1037a724a*/
  *(_QWORD *)(a1 + 144) = v10; /*0x1037a7251*/
  *(_QWORD *)(a1 + 152) = 0; /*0x1037a7258*/
  v12 = RSL::Arena::getDefaultArena(this: v11); /*0x1037a7266*/
  *(_OWORD *)(a1 + 160) = 0; /*0x1037a726e*/
  *(_QWORD *)(a1 + 176) = 0; /*0x1037a7276*/
  *(_QWORD *)(a1 + 184) = v12; /*0x1037a727d*/
  *(_OWORD *)(a1 + 192) = 0; /*0x1037a7284*/
  *(_QWORD *)(a1 + 208) = 0; /*0x1037a728c*/
  *(_QWORD *)(a1 + 216) = v12; /*0x1037a7293*/
  *(_OWORD *)(a1 + 224) = 0; /*0x1037a729a*/
  *(_QWORD *)(a1 + 240) = 0; /*0x1037a72a2*/
  *(_QWORD *)(a1 + 248) = v12; /*0x1037a72a9*/
  *(_QWORD *)(a1 + 256) = -1; /*0x1037a72b0*/
  *(_BYTE *)(a1 + 264) = 0; /*0x1037a72bb*/
  v14 = RSL::Arena::getDefaultArena(this: v13); /*0x1037a72ca*/
  RSL::SmallVector<unsigned long,4ul>::SmallVector(a1: a1 + 272, a2: v14); /*0x1037a72d5*/
  std::vector<RBX::RbxTransport::Protocol::TxItem,RSL::Detail::Allocator<RBX::RbxTransport::Protocol::TxItem>>::reserve( /*0x1037a72e2*/
    a1: a1 + 88,
    a2: 64);
  return std::vector<RBX::RbxTransport::Io::UdpMsg,RSL::Detail::Allocator<RBX::RbxTransport::Io::UdpMsg>>::reserve( /*0x1037a72f4*/
           a1: a1 + 120,
           a2: 64);
}

// Address: 0x1037a73ae | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEEC1ERNS0_2Io14AsyncUdpSocketEPNS1_22SocketSendStatsTrackerE
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::BasePacketSenderDeprecated(
        __int64 a1,
        __int64 a2,
        __int64 a3)
{
  return RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::BasePacketSenderDeprecated( /*0x1037a73b2*/
           a1,
           a2,
           a3);
}

// Address: 0x1037a73b8 | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE15allocateQueueIdEv
signed __int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::allocateQueueId(
        __int64 a1)
{
  return _InterlockedExchangeAdd64((volatile signed __int64 *)(a1 + 16), 1u); /*0x1037a73c7*/
}

// Address: 0x1037a73ca | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE13registerQueueEmPSA_
unsigned __int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::registerQueue(
        __int64 a1,
        __int64 a2,
        __int64 a3)
{
  _QWORD *v6; // r13
  unsigned __int64 result; // rax
  _QWORD *v8; // r13
  __int64 v9; // rdi
  __int64 v10; // rcx
  __int64 v11; // r13
  __int64 v12; // rax
  __int64 v13; // r12
  __int64 v14; // rax
  _QWORD *v15; // rax
  __int64 v16; // [rsp+8h] [rbp-58h] BYREF
  _QWORD *v17; // [rsp+10h] [rbp-50h]
  _QWORD *v18; // [rsp+18h] [rbp-48h]
  __int64 v19; // [rsp+20h] [rbp-40h]
  __int64 v20; // [rsp+28h] [rbp-38h]
  __int64 v21; // [rsp+30h] [rbp-30h]

  v6 = *(_QWORD **)(a1 + 32); /*0x1037a73e4*/
  result = *(_QWORD *)(a1 + 40); /*0x1037a73e8*/
  if ( (unsigned __int64)v6 >= result ) /*0x1037a73ef*/
  {
    v9 = a1 + 24; /*0x1037a7406*/
    v10 = *(_QWORD *)(a1 + 24); /*0x1037a740a*/
    v11 = ((__int64)v6 - v10) >> 4; /*0x1037a7410*/
    if ( (unsigned __int64)(v11 + 1) >> 60 != 0 ) /*0x1037a741f*/
      std::vector<RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::QueueCtx,RSL::Detail::Allocator<RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::QueueCtx>>::__throw_length_error[abi:ne200100]( /*0x1037a74d5*/
        a1: v9,
        a2: (unsigned __int64)(v11 + 1) >> 60);
    v12 = result - v10; /*0x1037a742f*/
    v13 = v12 >> 3; /*0x1037a7435*/
    if ( v12 >> 3 <= (unsigned __int64)(v11 + 1) ) /*0x1037a743c*/
      v13 = v11 + 1; /*0x1037a743c*/
    if ( (unsigned __int64)v12 >= 0x7FFFFFFFFFFFFFF0LL ) /*0x1037a744d*/
      v13 = 0xFFFFFFFFFFFFFFFLL; /*0x1037a744d*/
    v20 = a1 + 48; /*0x1037a7455*/
    if ( v13 != 0 ) /*0x1037a745c*/
    {
      v21 = a1 + 24; /*0x1037a745e*/
      v14 = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64))(**(_QWORD **)(a1 + 48) + 16LL))( /*0x1037a7474*/
              a1: *(_QWORD *)(a1 + 48),
              a2: 16 * v13,
              a3: 8);
      v9 = a1 + 24; /*0x1037a7477*/
    }
    else
    {
      v14 = 0; /*0x1037a747d*/
    }
    v16 = v14; /*0x1037a7483*/
    v17 = (_QWORD *)(v14 + 16 * v11); /*0x1037a748e*/
    v19 = v14 + 16 * v13; /*0x1037a7499*/
    v15 = v17 + 2; /*0x1037a74a0*/
    *v17 = a2; /*0x1037a74a4*/
    *(v15 - 1) = a3; /*0x1037a74a8*/
    v18 = v15; /*0x1037a74ac*/
    std::vector<RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::QueueCtx,RSL::Detail::Allocator<RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::QueueCtx>>::__swap_out_circular_buffer(a1: v9); /*0x1037a74b0*/
    v8 = *(_QWORD **)(a1 + 32); /*0x1037a74b5*/
    result = std::__split_buffer<RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::QueueCtx,RSL::Detail::Allocator<RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::QueueCtx> &>::~__split_buffer(a1: &v16); /*0x1037a74bd*/
  }
  else
  {
    *v6 = a2; /*0x1037a73f1*/
    v6[1] = a3; /*0x1037a73f5*/
    v8 = v6 + 2; /*0x1037a73f9*/
    *(_QWORD *)(a1 + 32) = v8; /*0x1037a73fd*/
  }
  *(_QWORD *)(a1 + 32) = v8; /*0x1037a74c2*/
  return result; /*0x1037a74c6*/
}

// Address: 0x1037a74ee | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE15unregisterQueueEm
void __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::unregisterQueue(
        _QWORD *a1,
        __int64 a2)
{
  char *v3; // r14
  char *v4; // r15
  __int64 v5; // r12
  size_t v6; // r15
  __int64 v7; // rax

  v3 = (char *)a1[3]; /*0x1037a74fc*/
  v4 = (char *)a1[4]; /*0x1037a7500*/
  while ( v3 != v4 && *(_QWORD *)v3 != a2 ) /*0x1037a750c*/
    v3 += 16; /*0x1037a750e*/
  if ( v3 != v4 ) /*0x1037a7517*/
  {
    v5 = *((_QWORD *)v3 + 1); /*0x1037a7519*/
    v6 = v4 - (v3 + 16); /*0x1037a7521*/
    if ( v6 != 0 ) /*0x1037a7524*/
      memmove(__dst: v3, __src: v3 + 16, __len: v6); /*0x1037a752c*/
    a1[4] = &v3[v6]; /*0x1037a7534*/
    v7 = std::remove_if[abi:ne200100]<std::__wrap_iter<std::pair<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>> *,unsigned long> *>,RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::unregisterQueue(unsigned long)::{lambda(std::__wrap_iter<std::pair<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>> *,unsigned long> *> const&)#2}>( /*0x1037a7543*/
           a1: a1[7],
           a2: a1[8],
           a3: v5);
    if ( v7 != a1[8] ) /*0x1037a754f*/
      a1[8] = v7; /*0x1037a758b*/
  }
}

// Address: 0x1037a75ec | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE16processPendingTxEv
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(
        __int64 a1,
        __int64 a2)
{
  RBX::Profiler::PerFrameTelemetry *v4; // r15
  RBX::Profiler::PerFrameTelemetry *Token; // r15
  _QWORD v7[13]; // [rsp+0h] [rbp-90h] BYREF
  uint64_t v8[5]; // [rsp+68h] [rbp-28h] BYREF

  if ( (_BYTE)`guard variable for'RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(void)::proftoken68 == 0 /*0x1037a76a5*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(void)::proftoken68) != 0 )
  {
    v7[0] = "ntOfType(offer_content, MediaType::DATA)"; /*0x1037a76ce*/
    Token = (RBX::Profiler::PerFrameTelemetry *)RBX::Profiler::getToken( /*0x1037a76f2*/
                                                  this: (RBX::Profiler *)&aNotAuthorizedT_1[-617464],
                                                  a2: &aIsmediacontent_1[-228473],
                                                  a3: (const char *)0xFFFFFFFFLL);
    RBX::Profiler::PerFrameTelemetry::activateForTelemetry(a1: Token); /*0x1037a76f8*/
    RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(void)::proftoken68 = (__int64)Token; /*0x1037a76fd*/
    __cxa_guard_release(a1: &`guard variable for'RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(void)::proftoken68); /*0x1037a770b*/
  }
  v4 = (RBX::Profiler::PerFrameTelemetry *)RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(void)::proftoken68; /*0x1037a760f*/
  *(_OWORD *)v7 = 0; /*0x1037a7620*/
  v7[3] = -1; /*0x1037a7623*/
  memset(&v7[4], 0, 52); /*0x1037a762b*/
  *(_OWORD *)&v7[11] = 0; /*0x1037a763e*/
  v7[2] = RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTx(void)::proftoken68; /*0x1037a7642*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v7); /*0x1037a7646*/
  v7[3] = RBX::Profiler::PerFrameTelemetry::enterTelemetryRegion(a1: v4, a2: v8, a3: 1); /*0x1037a765f*/
  RBX::RbxTransport::CallbackCollection<void ()(void)>::invoke<>(a1: a2 + 160); /*0x1037a766b*/
  RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTxPriv( /*0x1037a7676*/
    a1,
    a2);
  RBX::Profiler::TelemetryScope::~TelemetryScope(this: (RBX::Profiler::TelemetryScope *)v7); /*0x1037a7682*/
  return a1; /*0x1037a768a*/
}

// Address: 0x1037a773e | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE20processPendingTxPrivEv
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::processPendingTxPriv(
        __int64 a1,
        _QWORD *a2)
{
  __int64 v3; // rbx
  __int64 v4; // r12
  __int64 v5; // rbx
  unsigned __int64 v6; // rcx
  unsigned __int64 v7; // rax
  unsigned __int64 v8; // rax
  unsigned __int64 v9; // rcx
  unsigned __int64 *v10; // rdx
  bool v11; // zf
  char v12; // al
  __int64 v13; // rax
  unsigned __int64 v14; // rbx
  __int64 v15; // r12
  __int64 v16; // rax
  _QWORD *v17; // rax
  __int64 v18; // rcx
  char v19; // r12
  __int64 v20; // rbx
  __int128 *v21; // r15
  __int64 v22; // rax
  __int64 v23; // rcx
  _QWORD v25[4]; // [rsp+0h] [rbp-100h] BYREF
  __int64 v26; // [rsp+20h] [rbp-E0h]
  int v27; // [rsp+2Ch] [rbp-D4h]
  unsigned __int64 v28; // [rsp+30h] [rbp-D0h] BYREF
  __int128 v29; // [rsp+38h] [rbp-C8h] BYREF
  void *v30; // [rsp+48h] [rbp-B8h]
  int v31; // [rsp+54h] [rbp-ACh]
  unsigned __int64 v32; // [rsp+58h] [rbp-A8h] BYREF
  __int128 v33; // [rsp+60h] [rbp-A0h]
  void *v34; // [rsp+70h] [rbp-90h]
  char v35[28]; // [rsp+88h] [rbp-78h] BYREF
  char v36; // [rsp+A4h] [rbp-5Ch]
  char v37[32]; // [rsp+A8h] [rbp-58h] BYREF
  char v38; // [rsp+C8h] [rbp-38h]

  v26 = a1; /*0x1037a7755*/
  v3 = a2[3]; /*0x1037a776a*/
  v4 = a2[4]; /*0x1037a776e*/
  if ( v3 != v4 ) /*0x1037a7775*/
  {
    v5 = v3 + 8; /*0x1037a777f*/
    do /*0x1037a7805*/
    {
      v6 = *(_QWORD *)(*(_QWORD *)v5 + 24LL); /*0x1037a778d*/
      v7 = *(_QWORD *)(*(_QWORD *)v5 + 32LL); /*0x1037a7791*/
      if ( v7 < v6 ) /*0x1037a7798*/
        v7 += 0xEEEEEEEEEEEEEEEFLL * ((__int64)(*(_QWORD *)(*(_QWORD *)v5 + 8LL) - **(_QWORD **)v5) >> 3); /*0x1037a77b3*/
      v8 = v7 - v6; /*0x1037a77b6*/
      v32 = v8; /*0x1037a77b9*/
      if ( v8 != 0 ) /*0x1037a77c0*/
      {
        v9 = (unsigned int)DFInt::RbxTransportConnectionTxMaxPacketsToSendPerIteration; /*0x1037a77c9*/
        if ( DFInt::RbxTransportConnectionTxMaxPacketsToSendPerIteration < 2 ) /*0x1037a77d3*/
          v9 = 1; /*0x1037a77d3*/
        v28 = v9; /*0x1037a77d6*/
        v10 = &v28; /*0x1037a77dd*/
        if ( v8 <= v9 ) /*0x1037a77e3*/
          v10 = &v32; /*0x1037a77e5*/
        std::vector<std::pair<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>> *,unsigned long>,RSL::Detail::Allocator<std::pair<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>> *,unsigned long>>>::emplace_back<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>> *&,unsigned long const&>( /*0x1037a77f2*/
          a1: a2 + 7,
          a2: v5,
          a3: v10);
      }
      v11 = v5 + 8 == v4; /*0x1037a77ff*/
      v5 += 16; /*0x1037a7802*/
    }
    while ( !v11 ); /*0x1037a7805*/
  }
  LODWORD(v28) = 0; /*0x1037a780e*/
  v29 = 0; /*0x1037a7818*/
  v30 = nullptr; /*0x1037a781b*/
  if ( 0xCCCCCCCCCCCCCCCDLL * ((__int64)(a2[16] - a2[15]) >> 3) <= 0x3F ) /*0x1037a7844*/
    goto LABEL_16; /*0x1037a7844*/
  RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::sendBatch( /*0x1037a7850*/
    a1: &v32,
    a2);
  LODWORD(v28) = v32; /*0x1037a785b*/
  if ( (v29 & 1) != 0 ) /*0x1037a786f*/
    operator delete(a1: v30); /*0x1037a7878*/
  v30 = v34; /*0x1037a7884*/
  v29 = v33; /*0x1037a788f*/
  v12 = RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v28); /*0x1037a7899*/
  v31 = 0; /*0x1037a789e*/
  if ( v12 != 0 ) /*0x1037a78aa*/
  {
LABEL_16:
    v31 = 0; /*0x1037a78ba*/
    while ( 1 ) /*0x1037a78c4*/
    {
      v13 = a2[7]; /*0x1037a78c4*/
      if ( v13 == a2[8] ) /*0x1037a78cc*/
        break; /*0x1037a78cc*/
      LOBYTE(v13) = 1; /*0x1037a78d2*/
      v27 = v13; /*0x1037a78d4*/
      v14 = 0; /*0x1037a78da*/
      do /*0x1037a7a31*/
      {
        RBX::RbxTransport::Packet::Packet(a1: &v32, a2: 0); /*0x1037a78e1*/
        v35[0] = 0; /*0x1037a78e6*/
        v36 = 0; /*0x1037a78ea*/
        v37[0] = 0; /*0x1037a78ee*/
        v38 = 0; /*0x1037a78f2*/
        v15 = 16 * v14; /*0x1037a78fd*/
        if ( (unsigned __int8)RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>::read( /*0x1037a790f*/
                                a1: *(_QWORD *)(a2[7] + 16 * v14),
                                a2: &v32) != 0 )
        {
          RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::addToBatch( /*0x1037a7917*/
            a1: a2,
            a2: &v32);
          ++v31; /*0x1037a791c*/
          v16 = a2[7]; /*0x1037a7922*/
          --*(_QWORD *)(v16 + v15 + 8); /*0x1037a7926*/
        }
        else
        {
          v16 = a2[7]; /*0x1037a792d*/
          *(_QWORD *)(v16 + v15 + 8) = 0; /*0x1037a7931*/
        }
        if ( *(_QWORD *)(v16 + v15 + 8) == 0 ) /*0x1037a7940*/
        {
          v17 = (_QWORD *)(v15 + v16); /*0x1037a7942*/
          v18 = a2[8]; /*0x1037a7945*/
          *v17 = *(_QWORD *)(v18 - 16); /*0x1037a7951*/
          v17[1] = *(_QWORD *)(v18 - 8); /*0x1037a7958*/
          a2[8] = v18 - 16; /*0x1037a795c*/
          --v14; /*0x1037a7960*/
        }
        if ( 0xCCCCCCCCCCCCCCCDLL * ((__int64)(a2[16] - a2[15]) >> 3) < 0x40 ) /*0x1037a7984*/
          goto LABEL_28; /*0x1037a7984*/
        RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::sendBatch( /*0x1037a7990*/
          a1: v25,
          a2);
        LODWORD(v28) = v25[0]; /*0x1037a799b*/
        if ( (v29 & 1) != 0 ) /*0x1037a79a8*/
          operator delete(a1: v30); /*0x1037a79b1*/
        v30 = (void *)v25[3]; /*0x1037a79c8*/
        v29 = *(_OWORD *)&v25[1]; /*0x1037a79cf*/
        if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v28) != 0 ) /*0x1037a79e0*/
        {
LABEL_28:
          v19 = 1; /*0x1037a79e2*/
        }
        else
        {
          v27 = 0; /*0x1037a79e7*/
          v19 = 0; /*0x1037a79f1*/
        }
        if ( v38 == 1 ) /*0x1037a79f8*/
          RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v37); /*0x1037a79fe*/
        if ( v36 == 1 ) /*0x1037a7a07*/
          RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v35); /*0x1037a7a0d*/
        RBX::RbxTransport::Packet::~Packet(this: (RBX::RbxTransport::Packet *)&v32); /*0x1037a7a15*/
        if ( v19 == 0 ) /*0x1037a7a1d*/
          break; /*0x1037a7a1d*/
        ++v14; /*0x1037a7a1f*/
      }
      while ( v14 < (__int64)(a2[8] - a2[7]) >> 4 ); /*0x1037a7a31*/
      if ( (v27 & 1) == 0 ) /*0x1037a7a3e*/
        goto LABEL_37; /*0x1037a7a3e*/
    }
    v22 = a2[15]; /*0x1037a7a5f*/
    v23 = a2[16]; /*0x1037a7a63*/
    v20 = v26; /*0x1037a7a89*/
    v21 = &v29; /*0x1037a7a90*/
    if ( a2[19] < 0xCCCCCCCCCCCCCCCDLL * ((v23 - v22) >> 3) ) /*0x1037a7a97*/
    {
      RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::sendBatch( /*0x1037a7aa3*/
        a1: &v32,
        a2);
      LODWORD(v28) = v32; /*0x1037a7aae*/
      if ( (v29 & 1) != 0 ) /*0x1037a7abb*/
        operator delete(a1: v30); /*0x1037a7ac4*/
      v30 = v34; /*0x1037a7ad0*/
      v29 = v33; /*0x1037a7adb*/
      v22 = a2[15]; /*0x1037a7adf*/
      v23 = a2[16]; /*0x1037a7ae3*/
    }
    if ( v22 == v23 /*0x1037a7afd*/
      && (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v28) != 0 )
    {
      *(_DWORD *)v20 = 0; /*0x1037a7aff*/
LABEL_48:
      v21 = (__int128 *)(v20 + 8); /*0x1037a7b2e*/
      goto LABEL_50; /*0x1037a7b32*/
    }
  }
  else
  {
LABEL_37:
    a2[8] = a2[7]; /*0x1037a7a44*/
    v20 = v26; /*0x1037a7a4c*/
    v21 = &v29; /*0x1037a7a53*/
  }
  if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v28) != 0 /*0x1037a7b26*/
    || (unsigned int)RBX::RbxTransport::Io::Error::getCode(this: (RBX::RbxTransport::Io::Error *)&v28) == 3 )
  {
    *(_DWORD *)v20 = 3; /*0x1037a7b28*/
    goto LABEL_48; /*0x1037a7b28*/
  }
  *(_DWORD *)v20 = v28; /*0x1037a7b3a*/
  *(_OWORD *)(v20 + 8) = v29; /*0x1037a7b40*/
  *(_QWORD *)(v20 + 24) = v30; /*0x1037a7b48*/
LABEL_50:
  *v21 = 0; /*0x1037a7b4c*/
  *((_QWORD *)v21 + 2) = 0; /*0x1037a7b53*/
  *(_DWORD *)(v20 + 32) = v31; /*0x1037a7b61*/
  if ( (v29 & 1) != 0 ) /*0x1037a7b6b*/
    operator delete(a1: v30); /*0x1037a7b74*/
  return v20; /*0x1037a7b8c*/
}

// Address: 0x1037a7be4 | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE22unregisterOnBeforeSendEm
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::unregisterOnBeforeSend(
        __int64 a1)
{
  return RBX::RbxTransport::CallbackCollection<void ()(void)>::erase(a1: a1 + 160); /*0x1037a7bef*/
}

// Address: 0x1037a7bf6 | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE7getSockEv
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::getSock(
        __int64 a1)
{
  return *(_QWORD *)a1; /*0x1037a7bfd*/
}

// Address: 0x1037a7c00 | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE8QueueCtxC2EmPSA_
void __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::QueueCtx::QueueCtx(
        _QWORD *a1,
        __int64 a2,
        __int64 a3)
{
  *a1 = a2; /*0x1037a7c04*/
  a1[1] = a3; /*0x1037a7c07*/
}

// Address: 0x1037a7c0e | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE8QueueCtxC1EmPSA_
void __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::QueueCtx::QueueCtx(
        _QWORD *a1,
        __int64 a2,
        __int64 a3)
{
  *a1 = a2; /*0x1037a7c12*/
  a1[1] = a3; /*0x1037a7c15*/
}

// Address: 0x1037a7c1c | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE9sendBatchEv
int *__fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::sendBatch(
        int *a1,
        unsigned __int64 a2)
{
  _QWORD *v2; // r15
  char v3; // r14
  __int64 v4; // rax
  unsigned __int64 v5; // rcx
  unsigned __int64 v6; // rdx
  bool v7; // cc
  unsigned __int64 v8; // rcx
  RBX::RbxTransport::Protocol::SocketSendStatsTracker *v9; // rdi
  __int64 v10; // rdx
  __int64 v11; // rsi
  int v12; // r12d
  __int128 *v13; // rcx
  _OWORD *v14; // rdx
  char v15; // bl
  int Code; // eax
  bool v17; // zf
  int *v18; // rbx
  __int64 v19; // rax
  __int64 v20; // rcx
  unsigned __int64 v21; // rdx
  _DWORD *v22; // rax
  int v23; // eax
  _OWORD *v24; // rdx
  int v26; // [rsp+8h] [rbp-88h] BYREF
  char v27[16]; // [rsp+10h] [rbp-80h] BYREF
  void *v28; // [rsp+20h] [rbp-70h]
  unsigned __int64 v29; // [rsp+28h] [rbp-68h]
  int v30; // [rsp+30h] [rbp-60h] BYREF
  __int128 v31; // [rsp+38h] [rbp-58h] BYREF
  void *v32; // [rsp+48h] [rbp-48h]
  int *v33; // [rsp+50h] [rbp-40h]
  _DWORD *v34; // [rsp+58h] [rbp-38h]
  int v35; // [rsp+64h] [rbp-2Ch]

  v2 = (_QWORD *)a2; /*0x1037a7c2d*/
  v30 = 0; /*0x1037a7c34*/
  v31 = 0; /*0x1037a7c3e*/
  v32 = nullptr; /*0x1037a7c41*/
  v35 = *a1; /*0x1037a7c4b*/
  v33 = a1; /*0x1037a7c4e*/
  v34 = a1 + 2; /*0x1037a7c56*/
  v3 = 1; /*0x1037a7c5a*/
  while ( 1 ) /*0x1037a7c64*/
  {
    v4 = v2[15]; /*0x1037a7c64*/
    v5 = 0xCCCCCCCCCCCCCCCDLL * ((v2[16] - v4) >> 3); /*0x1037a7c80*/
    v6 = v2[19]; /*0x1037a7c84*/
    v7 = v5 <= v6; /*0x1037a7c8b*/
    v8 = v5 - v6; /*0x1037a7c8b*/
    if ( v7 ) /*0x1037a7c8e*/
    {
      RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::clearBatch( /*0x1037a7e4a*/
        a1: v2,
        a2,
        a3: v6,
        a4: v8);
      v23 = v30; /*0x1037a7e4f*/
      v18 = v33; /*0x1037a7e52*/
LABEL_29:
      *v18 = v23; /*0x1037a7e5b*/
      v24 = v34; /*0x1037a7e65*/
      *((_QWORD *)v34 + 2) = v32; /*0x1037a7e69*/
      *v24 = v31; /*0x1037a7e70*/
      v31 = 0; /*0x1037a7e76*/
      v32 = nullptr; /*0x1037a7e79*/
      goto LABEL_31; /*0x1037a7e81*/
    }
    RBX::RbxTransport::Io::AsyncUdpSocket::trySendMmsg(a1: &v26, a2: *v2, a3: v4 + 40 * v6, a4: v8); /*0x1037a7ca2*/
    v9 = (RBX::RbxTransport::Protocol::SocketSendStatsTracker *)v2[1]; /*0x1037a7ca7*/
    if ( v9 != nullptr ) /*0x1037a7cae*/
      RBX::RbxTransport::Protocol::SocketSendStatsTracker::trackSocketSendResult( /*0x1037a7cb7*/
        this: v9,
        a2: (const RBX::RbxTransport::Io::Error *)&v26,
        a3: v29);
    if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v26) != 0 /*0x1037a7cf0*/
      && v29 == 0xCCCCCCCCCCCCCCCDLL * ((__int64)(v2[16] - v2[15]) >> 3) - v2[19] )
    {
      RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::clearBatch( /*0x1037a7cf5*/
        a1: v2,
        a2: v11,
        a3: v10,
        a4: 0xCCCCCCCCCCCCCCCDLL);
      v12 = v30; /*0x1037a7cfa*/
      v13 = &v31; /*0x1037a7cfe*/
      v14 = v34; /*0x1037a7d06*/
      *((_QWORD *)v34 + 2) = v32; /*0x1037a7d0a*/
      *v14 = v31; /*0x1037a7d11*/
    }
    else
    {
      if ( (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v26) != 0 ) /*0x1037a7d20*/
      {
        a2 = v29; /*0x1037a7d22*/
        if ( v29 != 0 ) /*0x1037a7d29*/
        {
          v15 = 0; /*0x1037a7d2b*/
          RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::popFromBatch( /*0x1037a7d30*/
            a1: v2,
            a2: v29);
          goto LABEL_17; /*0x1037a7d35*/
        }
        v12 = 3; /*0x1037a7d85*/
LABEL_15:
        v13 = (__int128 *)v34; /*0x1037a7d8b*/
        goto LABEL_16; /*0x1037a7d8b*/
      }
      v12 = 3; /*0x1037a7d3f*/
      if ( (unsigned int)RBX::RbxTransport::Io::Error::getCode(this: (RBX::RbxTransport::Io::Error *)&v26) == 3 ) /*0x1037a7d48*/
        goto LABEL_15; /*0x1037a7d48*/
      Code = RBX::RbxTransport::Io::Error::getCode(this: (RBX::RbxTransport::Io::Error *)&v26); /*0x1037a7d4d*/
      v13 = (__int128 *)v34; /*0x1037a7d52*/
      if ( Code != 6 ) /*0x1037a7d59*/
      {
        v30 = v26; /*0x1037a7d61*/
        std::string::operator=(a1: &v31, a2: v27); /*0x1037a7d6c*/
        v15 = 4; /*0x1037a7d71*/
        RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::popFromBatch( /*0x1037a7d7e*/
          a1: v2,
          a2: 1);
        goto LABEL_17; /*0x1037a7d83*/
      }
    }
LABEL_16:
    *v13 = 0; /*0x1037a7d92*/
    *((_QWORD *)v13 + 2) = 0; /*0x1037a7d95*/
    v15 = 1; /*0x1037a7d9d*/
    v35 = v12; /*0x1037a7da2*/
LABEL_17:
    if ( (v27[0] & 1) != 0 ) /*0x1037a7daa*/
      operator delete(a1: v28); /*0x1037a7db0*/
    if ( (v15 & 3) != 0 ) /*0x1037a7db8*/
      break; /*0x1037a7db8*/
    v17 = (v3 & 1) == 0; /*0x1037a7dbe*/
    v3 = 0; /*0x1037a7dc2*/
    if ( v17 ) /*0x1037a7dc8*/
    {
      v18 = v33; /*0x1037a7dce*/
      *v33 = v35; /*0x1037a7dd5*/
      v19 = v2[15]; /*0x1037a7dd7*/
      v20 = v2[16]; /*0x1037a7ddb*/
      if ( v19 != v20 ) /*0x1037a7de5*/
      {
        v21 = 0xCCCCCCCCCCCCCCCDLL * ((v20 - v19) >> 3); /*0x1037a7dfb*/
        if ( v2[19] >= v21 ) /*0x1037a7e06*/
        {
          RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::clearBatch( /*0x1037a7e0b*/
            a1: v2,
            a2: 0xCCCCCCCCCCCCCCCDLL,
            a3: v21,
            a4: v20);
          v19 = v2[15]; /*0x1037a7e10*/
          v20 = v2[16]; /*0x1037a7e14*/
        }
        if ( v19 != v20 /*0x1037a7e2b*/
          && (unsigned __int8)RBX::RbxTransport::Io::Error::ok(this: (RBX::RbxTransport::Io::Error *)&v30) != 0 )
        {
          *v18 = 3; /*0x1037a7e2d*/
          v22 = v34; /*0x1037a7e36*/
          *(_OWORD *)v34 = 0; /*0x1037a7e3a*/
          *((_QWORD *)v22 + 2) = 0; /*0x1037a7e3d*/
          goto LABEL_31; /*0x1037a7e45*/
        }
      }
      v23 = v30; /*0x1037a7e58*/
      goto LABEL_29; /*0x1037a7e58*/
    }
  }
  v18 = v33; /*0x1037a7e83*/
  *v33 = v35; /*0x1037a7e8a*/
LABEL_31:
  if ( (v31 & 1) != 0 ) /*0x1037a7e90*/
    operator delete(a1: v32); /*0x1037a7e96*/
  return v18; /*0x1037a7e9e*/
}

// Address: 0x1037a7ef2 | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE10addToBatchEOS4_
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::addToBatch(
        __int64 a1)
{
  __int64 v2; // r12
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // r8
  __int64 v6; // r9
  _QWORD v8[2]; // [rsp+0h] [rbp-50h] BYREF
  __int128 v9; // [rsp+10h] [rbp-40h]
  __int64 v10; // [rsp+20h] [rbp-30h]

  std::vector<RBX::RbxTransport::Protocol::TxItem,RSL::Detail::Allocator<RBX::RbxTransport::Protocol::TxItem>>::push_back[abi:ne200100](a1: a1 + 88); /*0x1037a7f08*/
  v2 = *(_QWORD *)(a1 + 96); /*0x1037a7f0d*/
  v9 = 0; /*0x1037a7f19*/
  v8[0] = 0; /*0x1037a7f1d*/
  v10 = 0; /*0x1037a7f21*/
  v8[1] = RBX::RbxTransport::Packet::data(this: (RBX::RbxTransport::Packet *)(v2 - 120)); /*0x1037a7f3c*/
  *(_QWORD *)&v9 = RBX::RbxTransport::Packet::size(this: (RBX::RbxTransport::Packet *)(v2 - 120)); /*0x1037a7f40*/
  if ( *(_BYTE *)(v2 - 44) == 1 ) /*0x1037a7f4a*/
    v8[0] = v2 - 72; /*0x1037a7f51*/
  if ( *(_BYTE *)(v2 - 8) == 1 ) /*0x1037a7f5b*/
    *((_QWORD *)&v9 + 1) = v2 - 40; /*0x1037a7f61*/
  return ((__int64 (__fastcall *)(__int64, _QWORD *, __int64, __int64, __int64, __int64))std::vector<RBX::RbxTransport::Io::UdpMsg,RSL::Detail::Allocator<RBX::RbxTransport::Io::UdpMsg>>::push_back[abi:ne200100])( /*0x1037a7f75*/
           a1: a1 + 120,
           a2: v8,
           a3: v3,
           a4: v4,
           a5: v5,
           a6: v6);
}

// Address: 0x1037a7f82 | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE12popFromBatchEm
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::popFromBatch(
        __int64 a1,
        __int64 a2)
{
  RBX::RbxTransport::Packet *v3; // r15
  RBX::RbxTransport::Packet *v4; // rsi
  __int64 v5; // rbx
  __int64 v6; // r15
  RBX::RbxTransport::Packet *v7; // r14
  __int64 v8; // rax
  __int64 v9; // rcx
  __int64 v11; // [rsp+0h] [rbp-B0h]
  char v12; // [rsp+8h] [rbp-A8h] BYREF
  _BYTE v13[28]; // [rsp+38h] [rbp-78h] BYREF
  char v14; // [rsp+54h] [rbp-5Ch]
  _BYTE v15[32]; // [rsp+58h] [rbp-58h] BYREF
  char v16; // [rsp+78h] [rbp-38h]

  if ( a2 != 0 ) /*0x1037a7fa7*/
  {
    v3 = (RBX::RbxTransport::Packet *)&v12; /*0x1037a7fb0*/
    do /*0x1037a8079*/
    {
      v11 = a2; /*0x1037a7fb7*/
      RBX::RbxTransport::Packet::Packet(a1: v3, a2: 0); /*0x1037a7fc3*/
      v4 = v3; /*0x1037a7fc8*/
      v13[0] = 0; /*0x1037a7fcd*/
      v14 = 0; /*0x1037a7fd0*/
      v15[0] = 0; /*0x1037a7fd3*/
      v16 = 0; /*0x1037a7fd6*/
      v5 = a1; /*0x1037a7fdd*/
      v6 = 120LL * *(_QWORD *)(a1 + 152) + *(_QWORD *)(a1 + 88); /*0x1037a7fe8*/
      v7 = v4; /*0x1037a7fef*/
      RBX::RbxTransport::Packet::operator=(this: (RBX::RbxTransport::Packet *)v6); /*0x1037a7ff2*/
      std::__optional_storage_base<RBX::RbxTransport::Io::EndpointAddr,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::RbxTransport::Io::EndpointAddr,false>>(this: (RBX::RbxTransport::Io::EndpointAddr *)(v6 + 48)); /*0x1037a8003*/
      std::__optional_storage_base<RBX::RbxTransport::Io::UdpDatagramAttrs,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::RbxTransport::Io::UdpDatagramAttrs,false>>(this: (RBX::RbxTransport::Io::EndpointAddr *)(v6 + 80)); /*0x1037a8013*/
      v3 = v7; /*0x1037a801c*/
      if ( v16 == 1 ) /*0x1037a801f*/
        RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v15); /*0x1037a8025*/
      a1 = v5; /*0x1037a802e*/
      if ( v14 == 1 ) /*0x1037a8031*/
        RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)v13); /*0x1037a8037*/
      RBX::RbxTransport::Packet::~Packet(this: v3); /*0x1037a803f*/
      v8 = *(_QWORD *)(v5 + 120); /*0x1037a8044*/
      v9 = 5LL * *(_QWORD *)(v5 + 152); /*0x1037a804f*/
      *(_OWORD *)(v8 + 8 * v9 + 16) = 0; /*0x1037a8056*/
      *(_OWORD *)(v8 + 8 * v9) = 0; /*0x1037a805b*/
      *(_QWORD *)(v8 + 8 * v9 + 32) = 0; /*0x1037a805f*/
      ++*(_QWORD *)(v5 + 152); /*0x1037a8068*/
      a2 = v11 - 1; /*0x1037a8076*/
    }
    while ( v11 != 1 ); /*0x1037a8079*/
  }
  return __stack_chk_guard; /*0x1037a808f*/
}

// Address: 0x1037a80be | Name: __ZN3RBX12RbxTransport8Protocol26BasePacketSenderDeprecatedINS_9SPSCQueueINS1_6TxItemENSt3__16vectorIS4_NS5_9allocatorIS4_EEEEEEE10clearBatchEv
__int64 __fastcall RBX::RbxTransport::Protocol::BasePacketSenderDeprecated<RBX::SPSCQueue<RBX::RbxTransport::Protocol::TxItem,std::vector<RBX::RbxTransport::Protocol::TxItem>>>::clearBatch(
        _QWORD *a1)
{
  __int64 result; // rax
  RBX::RbxTransport::Packet *v3; // r15
  RBX::RbxTransport::Packet *i; // r14

  a1[19] = 0; /*0x1037a80cb*/
  result = a1[15]; /*0x1037a80d6*/
  a1[16] = result; /*0x1037a80da*/
  v3 = (RBX::RbxTransport::Packet *)a1[11]; /*0x1037a80e1*/
  for ( i = (RBX::RbxTransport::Packet *)a1[12]; /*0x1037a80e5*/
        i != v3;
        result = std::__destroy_at[abi:ne200100]<RBX::RbxTransport::Protocol::TxItem,0>(this: i) )
  {
    i = (RBX::RbxTransport::Packet *)((char *)i - 120); /*0x1037a80ee*/
  }
  a1[12] = v3; /*0x1037a80fc*/
  return result; /*0x1037a8104*/
}

// Address: 0x1037aa934 | Name: __ZN3RBX12RbxTransport8Protocol15writeRuppHeaderERNS_4Rupp22RuppGeneratorInterfaceERNS0_6PacketENS_4TimeE
unsigned __int64 __fastcall RBX::RbxTransport::Protocol::writeRuppHeader(
        __int64 a1,
        RBX::RbxTransport::Packet *a2,
        __m128 a3)
{
  RBX::Rupp::Rupp *v5; // r14
  unsigned __int64 HeaderTotalByteLength; // r15
  unsigned __int8 v7; // r13
  unsigned __int8 v8; // al
  unsigned __int64 v9; // rcx
  __int64 v10; // r12
  RBX::Time *v11; // rdi
  __int64 v12; // rax
  __int64 v13; // rdx
  __int64 v14; // rcx
  unsigned __int64 v15; // rax
  _QWORD v17[4]; // [rsp+0h] [rbp-60h] BYREF
  __m128 v18; // [rsp+20h] [rbp-40h]

  v18 = a3; /*0x1037aa945*/
  v5 = (RBX::Rupp::Rupp *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 24LL))(a1); /*0x1037aa956*/
  HeaderTotalByteLength = (unsigned __int16)RBX::Rupp::Rupp::getHeaderTotalByteLength(this: v5); /*0x1037aa961*/
  if ( RBX::RbxTransport::Packet::size(this: a2) < HeaderTotalByteLength ) /*0x1037aa970*/
    RBX::RbxTransport::Packet::resize(this: a2, a2: HeaderTotalByteLength); /*0x1037aa978*/
  v7 = RBX::Rupp::Rupp::hasTlv(a1: v5, a2: 1) ^ 1; /*0x1037aa98d*/
  if ( *((_QWORD *)v5 + 6) != 0 ) /*0x1037aa996*/
    v8 = 0; /*0x1037aa998*/
  else
    v8 = RBX::Rupp::Rupp::hasTlv(a1: v5, a2: 2) ^ 1; /*0x1037aa9a9*/
  if ( ((v8 | v7) & 1) != 0 ) /*0x1037aa9b3*/
  {
    v9 = *(_QWORD *)(a1 + 24); /*0x1037aa9b5*/
    *(_QWORD *)(a1 + 24) = v9 + 1; /*0x1037aa9bd*/
    if ( v9 < DFInt::RbxTransportMaxRuppMissingTlvReports ) /*0x1037aa9cb*/
      RBX::Rupp::reportRuppMissingTlvs(a1: v7, a2: v8, a3: 1); /*0x1037aa9d9*/
  }
  v10 = RBX::RbxTransport::Packet::data(this: a2); /*0x1037aa9e6*/
  v12 = RBX::Time::epochTimeNs(this: v11); /*0x1037aa9e9*/
  RBX::Rupp::Rupp::serialize(a1: v17, a2: v5, a3: v10, a4: HeaderTotalByteLength, a5: v12 / 1000); /*0x1037aaa19*/
  if ( LODWORD(v17[0]) != 0 ) /*0x1037aaa23*/
  {
    v13 = (unsigned int)(int)((*(double *)v18.i64 - *(double *)(a1 + 40)) * 1000.0); /*0x1037aaa53*/
    v14 = v17[1]; /*0x1037aaa5a*/
    v15 = *(_QWORD *)(a1 + 8); /*0x1037aaa5e*/
    *(_QWORD *)(a1 + 8) = v15 + 1; /*0x1037aaa66*/
    RBX::Rupp::reportRuppSerializationFailure( /*0x1037aaa84*/
      a1: v5,
      a2: v17,
      a3: v13,
      a4: v14,
      a5: v15 < DFInt::RbxTransportMaxRuppSerializationFailureReportsToPoints,
      a6: 1);
  }
  if ( *((_QWORD *)v5 + 6) != 0 ) /*0x1037aaa8e*/
    RBX::RbxTransport::Protocol::reportLateRuppTokenUpdate( /*0x1037aaaa4*/
      a1: LODWORD(v17[0]),
      a2: a1 + 8,
      a3: v5,
      a4: DFInt::RbxTransportReportTimeBetweenTTServerThresholdMs);
  return HeaderTotalByteLength; /*0x1037aaaac*/
}

// Address: 0x1037aaabb | Name: __ZN3RBX12RbxTransport8ProtocolL25reportLateRuppTokenUpdateENS_4Rupp9RuppError9ErrorCodeERNS2_18RuppGeneratorStateERNS2_4RuppEy
__int64 __fastcall RBX::RbxTransport::Protocol::reportLateRuppTokenUpdate(
        RBX::Time *a1,
        __int64 a2,
        __int64 a3,
        unsigned __int64 a4)
{
  unsigned int v7; // r14d
  __int64 v8; // r13
  __int64 v9; // rax
  RBX::Time *v10; // rdi
  unsigned __int128 v11; // rax
  __int64 v12; // r13
  double v13; // xmm0_8

  v7 = (unsigned int)a1; /*0x1037aaad2*/
  if ( (_DWORD)a1 != 0 ) /*0x1037aaad7*/
  {
    if ( (*(_BYTE *)(a2 + 24) & 1) != 0 ) /*0x1037aaade*/
      return v11; /*0x1037aaade*/
  }
  else
  {
    *(_BYTE *)(a2 + 24) = 0; /*0x1037aaae2*/
  }
  v8 = *(_QWORD *)(a3 + 80); /*0x1037aaae7*/
  v9 = RBX::Time::epochTimeNs(this: a1); /*0x1037aaaeb*/
  v11 = 0x20C49BA5E353F7CFLL /*0x1037aab12*/
      * (unsigned __int128)((v9 / 1000
                           + ((unsigned __int64)((unsigned __int128)(0x20C49BA5E353F7CFLL * (__int128)v9) >> 64) >> 63)
                           - v8) >> 3);
  v12 = *((_QWORD *)&v11 + 1) >> 4; /*0x1037aab18*/
  if ( *((_QWORD *)&v11 + 1) >> 4 >= a4 ) /*0x1037aab1f*/
  {
    *(_BYTE *)(a2 + 24) = 1; /*0x1037aab30*/
    RBX::Time::nowFast(this: v10); /*0x1037aab35*/
    *(_QWORD *)&v11 = RBX::Rupp::reportLateRuppTokenUpdate( /*0x1037aab84*/
                        a1: v7,
                        a2: v12,
                        a3: *(unsigned int *)(a3 + 64),
                        a4: (unsigned int)(int)((v13 - *(double *)(a2 + 32)) * 1000.0),
                        a5: 1);
  }
  return v11; /*0x1037aab25*/
}

// Address: 0x1037aab89 | Name: __ZN3RBX12RbxTransport8Protocol21parseRuppHeaderOnRecvERNS_9ArrayViewIhEE
_BYTE *__fastcall RBX::RbxTransport::Protocol::parseRuppHeaderOnRecv(_BYTE *a1, _QWORD *a2)
{
  int v4; // eax
  unsigned __int64 v5; // rdx
  bool v6; // cf
  unsigned __int64 v7; // rdx
  _QWORD v9[12]; // [rsp+8h] [rbp-78h] BYREF

  LODWORD(v9[0]) = 0x10000; /*0x1037aabac*/
  BYTE4(v9[0]) = 0; /*0x1037aabb2*/
  memset(&v9[1], 0, 64); /*0x1037aabb9*/
  LOBYTE(v9[9]) = 1; /*0x1037aabc9*/
  *(_OWORD *)((char *)&v9[9] + 1) = 0; /*0x1037aabcd*/
  v4 = RBX::Rupp::Rupp::deserialize(a1: v9, a2: *a2, a3: a2[1]); /*0x1037aabd8*/
  if ( v4 != 0 || (v5 = a2[1], v4 = 4, v6 = v5 < LOWORD(v9[0]), v7 = v5 - LOWORD(v9[0]), v6) ) /*0x1037aabf1*/
  {
    a1[96] = 0; /*0x1037aabf3*/
    *(_DWORD *)a1 = v4; /*0x1037aabf7*/
  }
  else
  {
    *a2 += LOWORD(v9[0]); /*0x1037aac15*/
    a2[1] = v7; /*0x1037aac18*/
    a1[96] = 1; /*0x1037aac1c*/
    qmemcpy(a1, v9, 96); /*0x1037aac30*/
  }
  return a1; /*0x1037aac0c*/
}

// Address: 0x1037aac5e | Name: __ZN3RBX12RbxTransport8Protocol32parseRuppHeaderOnRecv_DEPRECATEDERNS0_6PacketE
RBX::RbxTransport::Protocol *__fastcall RBX::RbxTransport::Protocol::parseRuppHeaderOnRecv_DEPRECATED(
        RBX::RbxTransport::Protocol *this,
        RBX::RbxTransport::Packet *a2)
{
  __int64 v4; // r12
  __int64 v5; // rax
  int v6; // eax
  unsigned __int64 v7; // r15
  unsigned __int64 v8; // rcx
  _QWORD v10[12]; // [rsp+8h] [rbp-88h] BYREF

  LODWORD(v10[0]) = 0x10000; /*0x1037aac88*/
  BYTE4(v10[0]) = 0; /*0x1037aac8f*/
  memset(&v10[1], 0, 64); /*0x1037aac97*/
  LOBYTE(v10[9]) = 1; /*0x1037aacab*/
  *(_OWORD *)((char *)&v10[9] + 1) = 0; /*0x1037aacb0*/
  v4 = RBX::RbxTransport::Packet::data(this: a2); /*0x1037aacbd*/
  v5 = RBX::RbxTransport::Packet::size(this: a2); /*0x1037aacc3*/
  v6 = RBX::Rupp::Rupp::deserialize(a1: v10, a2: v4, a3: v5); /*0x1037aacd1*/
  if ( v6 != 0 || (v7 = LOWORD(v10[0]), v8 = RBX::RbxTransport::Packet::size(this: a2), v6 = 4, v8 < v7) ) /*0x1037aacf5*/
  {
    *((_BYTE *)this + 96) = 0; /*0x1037aacf7*/
    *(_DWORD *)this = v6; /*0x1037aacfb*/
  }
  else
  {
    RBX::RbxTransport::Packet::pop_front(this: a2, a2: LOWORD(v10[0])); /*0x1037aad27*/
    *((_BYTE *)this + 96) = 1; /*0x1037aad2c*/
    qmemcpy(this, v10, 96); /*0x1037aad43*/
  }
  return this; /*0x1037aad10*/
}

// Address: 0x1037aad71 | Name: __ZN3RBX12RbxTransport8Protocol17processRuppHeaderERNS_4Rupp22RuppGeneratorInterfaceERKNS0_2Io12EndpointAddrERKN3RSL8ExpectedINS2_21DeserializationResultENS2_9RuppError9ErrorCodeEEE
__int64 __fastcall RBX::RbxTransport::Protocol::processRuppHeader(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  __int64 v7; // r15
  __int64 v8; // r12
  RBX::Time *v9; // rdi
  __int64 v10; // rax
  unsigned int v11; // eax
  unsigned int v12; // r14d
  RBX::Time *v13; // rdi
  double v14; // xmm0_8
  __int64 v15; // rsi
  unsigned __int64 v16; // rax

  if ( *(_BYTE *)(a3 + 96) != 0 ) /*0x1037aad86*/
  {
    result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 24LL))(a1); /*0x1037aad91*/
    if ( *(_QWORD *)(result + 48) == 0 ) /*0x1037aad99*/
    {
      v7 = result; /*0x1037aad9f*/
      v8 = RSL::Expected<RBX::Rupp::DeserializationResult,RBX::Rupp::RuppError::ErrorCode>::value(a1: a3); /*0x1037aadaa*/
      v10 = RBX::Time::epochTimeNs(this: v9); /*0x1037aadad*/
      v11 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, __int64))(*(_QWORD *)a1 + 32LL))( /*0x1037aadd9*/
              a1,
              a2: v8,
              a3: a2,
              a4: v10 / 1000);
      return RBX::RbxTransport::Protocol::reportLateRuppTokenUpdate( /*0x1037aadf7*/
               a1: (RBX::Time *)v11,
               a2: a1 + 8,
               a3: v7,
               a4: DFInt::RbxTransportReportTimeBetweenTTClientThresholdMs);
    }
  }
  else
  {
    result = RSL::Expected<RBX::Rupp::DeserializationResult,RBX::Rupp::RuppError::ErrorCode>::error(a1: a3); /*0x1037aadff*/
    if ( *(_DWORD *)result != 0 ) /*0x1037aae07*/
    {
      v12 = *(_DWORD *)RSL::Expected<RBX::Rupp::DeserializationResult,RBX::Rupp::RuppError::ErrorCode>::error(a1: a3); /*0x1037aae11*/
      RBX::Time::nowFast(this: v13); /*0x1037aae14*/
      v15 = (unsigned int)(int)((v14 - *(double *)(a1 + 40)) * 1000.0); /*0x1037aae42*/
      v16 = *(_QWORD *)(a1 + 16); /*0x1037aae45*/
      *(_QWORD *)(a1 + 16) = v16 + 1; /*0x1037aae4d*/
      return RBX::Rupp::reportRuppDeserializationFailure( /*0x1037aae70*/
               a1: v12,
               a2: v15,
               a3: v16 < DFInt::RbxTransportMaxRuppDeserializationFailureReportsToPoints,
               a4: 1);
    }
  }
  return result; /*0x1037aadef*/
}

// END Protocol part 1/1, 49 functions
