// ServerRuppConfiguration -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 1 functions


// Address: 0x10687ba66 | Name: __ZN3RBX4Rupp23ServerRuppConfigurationD1Ev
void __fastcall RBX::Rupp::ServerRuppConfiguration::~ServerRuppConfiguration(void **this)
{
  RBX::RbxTransport::Io::EndpointAddr::~EndpointAddr(this: (RBX::RbxTransport::Io::EndpointAddr *)(this + 3)); /*0x10687ba73*/
  if ( (*(_BYTE *)this & 1) != 0 ) /*0x10687ba7b*/
    operator delete(a1: *(this + 2)); /*0x10687ba8e*/
}

// END ServerRuppConfiguration part 1/1, 1 functions
