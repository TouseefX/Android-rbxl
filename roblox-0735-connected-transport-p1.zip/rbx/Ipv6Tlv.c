// Ipv6Tlv -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 8 functions


// Address: 0x1037ba064 | Name: __ZN3RBX4Rupp7Ipv6TlvC2E8in6_addrt
void (__fastcall **__fastcall RBX::Rupp::Ipv6Tlv::Ipv6Tlv(
        RBX::Rupp::Ipv6Tlv *this,
        in6_addr a2,
        __int16 a3))(RBX::Rupp::Ipv6Tlv *__hidden this)
{
  *(_QWORD *)this = off_10C8EC558; /*0x1037ba06f*/
  *((_QWORD *)this + 1) = *(_QWORD *)a2.__u6_addr8; /*0x1037ba072*/
  *((_QWORD *)this + 2) = *(_QWORD *)&a2.__u6_addr32[2]; /*0x1037ba076*/
  *((_WORD *)this + 12) = a3; /*0x1037ba07a*/
  return off_10C8EC558; /*0x1037ba07e*/
}

// Address: 0x1037ba080 | Name: __ZN3RBX4Rupp7Ipv6TlvC1E8in6_addrt
void (__fastcall **__fastcall RBX::Rupp::Ipv6Tlv::Ipv6Tlv(
        RBX::Rupp::Ipv6Tlv *this,
        in6_addr a2,
        __int16 a3))(RBX::Rupp::Ipv6Tlv *__hidden this)
{
  *(_QWORD *)this = off_10C8EC558; /*0x1037ba08b*/
  *((_QWORD *)this + 1) = *(_QWORD *)a2.__u6_addr8; /*0x1037ba08e*/
  *((_QWORD *)this + 2) = *(_QWORD *)&a2.__u6_addr32[2]; /*0x1037ba092*/
  *((_WORD *)this + 12) = a3; /*0x1037ba096*/
  return off_10C8EC558; /*0x1037ba09a*/
}

// Address: 0x1037ba09c | Name: __ZNK3RBX4Rupp7Ipv6Tlv9serializeENS_16MutableArrayViewIhEE
__int64 __fastcall RBX::Rupp::Ipv6Tlv::serialize(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  __int64 v5; // rsi

  if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)a1 + 24LL))(a1) > a3 ) /*0x1037ba0bd*/
    return 11; /*0x1037ba0bf*/
  *(_OWORD *)a2 = *(_OWORD *)(a1 + 8); /*0x1037ba0ca*/
  *(_WORD *)(a2 + 16) = __ROL2__(*(_WORD *)(a1 + 24), 8); /*0x1037ba0d6*/
  (*(void (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)a1 + 24LL))(a1, a2: v5, a3: 0); /*0x1037ba0e1*/
  return 0; /*0x1037ba0ed*/
}

// Address: 0x1037ba0f4 | Name: __ZN3RBX4Rupp7Ipv6Tlv11deserializeERNS0_21DeserializationResultENS_9ArrayViewIhEE
__int64 __fastcall RBX::Rupp::Ipv6Tlv::deserialize(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  _BYTE v5[28]; // [rsp-38h] [rbp-38h] BYREF

  result = 1; /*0x1037ba0f4*/
  if ( a3 == 18 ) /*0x1037ba0fd*/
  {
    *(_OWORD *)&v5[12] = 0; /*0x1037ba114*/
    *(_OWORD *)v5 = 0; /*0x1037ba119*/
    *(_OWORD *)&v5[8] = *(_OWORD *)a2; /*0x1037ba121*/
    *(_WORD *)&v5[2] = *(_WORD *)(a2 + 16); /*0x1037ba129*/
    *(_BYTE *)(a1 + 72) = 0; /*0x1037ba12e*/
    inet_ntop(a1: 30, a2: &v5[8], a3: (char *)(a1 + 24), a4: 0x2Eu); /*0x1037ba143*/
    *(_WORD *)(a1 + 70) = __ROL2__(*(_WORD *)&v5[2], 8); /*0x1037ba151*/
    return 0; /*0x1037ba155*/
  }
  return result; /*0x1037ba15f*/
}

// Address: 0x1037ba510 | Name: __ZN3RBX4Rupp7Ipv6TlvD1Ev
void __fastcall RBX::Rupp::Ipv6Tlv::~Ipv6Tlv(RBX::Rupp::Ipv6Tlv *this)
{
  ; /*0x1037ba510*/
}

// Address: 0x1037ba516 | Name: __ZN3RBX4Rupp7Ipv6TlvD0Ev
void __fastcall RBX::Rupp::Ipv6Tlv::~Ipv6Tlv(RBX::Rupp::Ipv6Tlv *this)
{
  operator delete(a1: this); /*0x1037ba51b*/
}

// Address: 0x1037ba520 | Name: __ZNK3RBX4Rupp7Ipv6Tlv10getTlvTypeEv
__int64 __fastcall RBX::Rupp::Ipv6Tlv::getTlvType(RBX::Rupp::Ipv6Tlv *this)
{
  return 3; /*0x1037ba529*/
}

// Address: 0x1037ba52c | Name: __ZNK3RBX4Rupp7Ipv6Tlv18getValueByteLengthEv
__int64 __fastcall RBX::Rupp::Ipv6Tlv::getValueByteLength(RBX::Rupp::Ipv6Tlv *this)
{
  return 18; /*0x1037ba535*/
}

// END Ipv6Tlv part 1/1, 8 functions
