// Ipv4ReverseEndpointTlv -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 6 functions


// Address: 0x1037ba02a | Name: __ZN3RBX4Rupp22Ipv4ReverseEndpointTlvC2E7in_addrt
void (__fastcall **__fastcall RBX::Rupp::Ipv4ReverseEndpointTlv::Ipv4ReverseEndpointTlv(
        in_addr *this,
        in_addr a2,
        __int16 a3))(RBX::Rupp::Ipv4ReverseEndpointTlv *__hidden this)
{
  *(this + 2) = a2; /*0x1037ba02e*/
  *((_WORD *)this + 6) = a3; /*0x1037ba031*/
  *(_QWORD *)&this->s_addr = off_10C8EC520; /*0x1037ba03c*/
  return off_10C8EC520; /*0x1037ba03f*/
}

// Address: 0x1037ba042 | Name: __ZN3RBX4Rupp22Ipv4ReverseEndpointTlvC1E7in_addrt
void (__fastcall **__fastcall RBX::Rupp::Ipv4ReverseEndpointTlv::Ipv4ReverseEndpointTlv(
        in_addr *this,
        in_addr a2,
        __int16 a3))(RBX::Rupp::Ipv4ReverseEndpointTlv *__hidden this)
{
  *(this + 2) = a2; /*0x1037ba046*/
  *((_WORD *)this + 6) = a3; /*0x1037ba049*/
  *(_QWORD *)&this->s_addr = off_10C8EC520; /*0x1037ba054*/
  return off_10C8EC520; /*0x1037ba057*/
}

// Address: 0x1037ba05a | Name: __ZN3RBX4Rupp22Ipv4ReverseEndpointTlv11deserializeERNS0_21DeserializationResultENS_9ArrayViewIhEE
__int64 RBX::Rupp::Ipv4ReverseEndpointTlv::deserialize()
{
  return RBX::Rupp::Ipv4Tlv::deserialize(); /*0x1037ba05e*/
}

// Address: 0x1037ba57c | Name: __ZN3RBX4Rupp22Ipv4ReverseEndpointTlvD1Ev
void __fastcall RBX::Rupp::Ipv4ReverseEndpointTlv::~Ipv4ReverseEndpointTlv(RBX::Rupp::Ipv4ReverseEndpointTlv *this)
{
  ; /*0x1037ba57c*/
}

// Address: 0x1037ba582 | Name: __ZN3RBX4Rupp22Ipv4ReverseEndpointTlvD0Ev
void __fastcall RBX::Rupp::Ipv4ReverseEndpointTlv::~Ipv4ReverseEndpointTlv(RBX::Rupp::Ipv4ReverseEndpointTlv *this)
{
  operator delete(a1: this); /*0x1037ba587*/
}

// Address: 0x1037ba58c | Name: __ZNK3RBX4Rupp22Ipv4ReverseEndpointTlv10getTlvTypeEv
__int64 __fastcall RBX::Rupp::Ipv4ReverseEndpointTlv::getTlvType(RBX::Rupp::Ipv4ReverseEndpointTlv *this)
{
  return 6; /*0x1037ba595*/
}

// END Ipv4ReverseEndpointTlv part 1/1, 6 functions
