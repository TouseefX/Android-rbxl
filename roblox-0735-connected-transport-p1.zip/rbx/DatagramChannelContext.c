// DatagramChannelContext -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 2 functions


// Address: 0x1036d7f28 | Name: __ZN3RBX12RbxTransport4Impl19RtcIoBaseConnection22DatagramChannelContextC2ENS0_11ApplicationENS1_17InternalChannelIdE
__int64 __fastcall RBX::RbxTransport::Impl::RtcIoBaseConnection::DatagramChannelContext::DatagramChannelContext(
        __int64 a1,
        __int64 a2,
        __int64 a3)
{
  __int64 result; // rax

  result = RBX::RbxTransport::Impl::RtcIoBaseConnection::BaseChannelContext::BaseChannelContext(a1, a2, a3, a4: 1); /*0x1036d7f36*/
  *(_DWORD *)(a1 + 152) = 0x80000000; /*0x1036d7f3b*/
  *(_OWORD *)(a1 + 160) = 0; /*0x1036d7f48*/
  *(_OWORD *)(a1 + 176) = 0; /*0x1036d7f4f*/
  return result; /*0x1036d7f5a*/
}

// Address: 0x1036d7f5e | Name: __ZN3RBX12RbxTransport4Impl19RtcIoBaseConnection22DatagramChannelContextC1ENS0_11ApplicationENS1_17InternalChannelIdE
__int64 __fastcall RBX::RbxTransport::Impl::RtcIoBaseConnection::DatagramChannelContext::DatagramChannelContext(
        __int64 a1,
        __int64 a2,
        __int64 a3)
{
  __int64 result; // rax

  result = RBX::RbxTransport::Impl::RtcIoBaseConnection::BaseChannelContext::BaseChannelContext(a1, a2, a3, a4: 1); /*0x1036d7f6c*/
  *(_DWORD *)(a1 + 152) = 0x80000000; /*0x1036d7f71*/
  *(_OWORD *)(a1 + 160) = 0; /*0x1036d7f7e*/
  *(_OWORD *)(a1 + 176) = 0; /*0x1036d7f85*/
  return result; /*0x1036d7f90*/
}

// END DatagramChannelContext part 1/1, 2 functions
