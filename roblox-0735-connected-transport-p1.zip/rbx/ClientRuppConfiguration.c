// ClientRuppConfiguration -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 1 functions


// Address: 0x1037b4944 | Name: __ZNK3RBX4Rupp23ClientRuppConfiguration8toStringEv
RBX::Rupp::ClientRuppConfiguration *__fastcall RBX::Rupp::ClientRuppConfiguration::toString(
        RBX::Rupp::ClientRuppConfiguration *this,
        unsigned __int8 *a2)
{
  __int64 v4; // rcx
  _BYTE *v5; // rdx
  _QWORD v7[4]; // [rsp+0h] [rbp-50h] BYREF
  unsigned __int8 v8; // [rsp+20h] [rbp-30h] BYREF
  _BYTE v9[15]; // [rsp+21h] [rbp-2Fh] BYREF
  void *v10; // [rsp+30h] [rbp-20h]

  RBX::RbxTransport::Io::EndpointAddr::toString(this: (RBX::RbxTransport::Io::EndpointAddr *)&v8); /*0x1037b4962*/
  v4 = v8 >> 1; /*0x1037b496d*/
  v5 = v10; /*0x1037b4975*/
  if ( (v8 & 1) != 0 ) /*0x1037b4979*/
    v4 = *(_QWORD *)&v9[7]; /*0x1037b4981*/
  else
    v5 = v9; /*0x1037b4979*/
  v7[0] = *a2; /*0x1037b498a*/
  v7[2] = v5; /*0x1037b498d*/
  v7[3] = v4; /*0x1037b4991*/
  fmt::v8::vformat(a1: this, a2: "directServerReturn = {}, rccAddr = {}", a3: 37, a4: 215, a5: v7); /*0x1037b49a9*/
  if ( (v8 & 1) != 0 ) /*0x1037b49b2*/
    operator delete(a1: v10); /*0x1037b49b8*/
  return this; /*0x1037b49c0*/
}

// END ClientRuppConfiguration part 1/1, 1 functions
