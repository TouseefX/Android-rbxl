// DatagramId -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 4 functions


// Address: 0x10376c9d0 | Name: __ZN3RBX12RbxTransport8Protocol10DatagramIdC2ENS1_13WireChannelIdEj
__int64 __fastcall RBX::RbxTransport::Protocol::DatagramId::DatagramId(__int64 *a1, int a2, unsigned int a3)
{
  __int64 v5; // rax
  __int64 result; // rax
  int v7[5]; // [rsp+Ch] [rbp-14h] BYREF

  v7[0] = a2; /*0x10376c9e5*/
  v5 = (unsigned int)-a2; /*0x10376c9e9*/
  if ( a2 > 0 ) /*0x10376c9eb*/
    v5 = (unsigned int)a2; /*0x10376c9eb*/
  *a1 = (v5 << 32) | a3; /*0x10376c9f7*/
  result = RBX::RbxTransport::Protocol::WireChannelId::valid(this: (RBX::RbxTransport::Protocol::WireChannelId *)v7); /*0x10376c9fa*/
  if ( ((unsigned __int8)result & (a3 != 0)) == 0 ) /*0x10376ca07*/
    *a1 = 0; /*0x10376ca09*/
  return result; /*0x10376ca10*/
}

// Address: 0x10376ca1a | Name: __ZN3RBX12RbxTransport8Protocol10DatagramIdC1ENS1_13WireChannelIdEj
__int64 __fastcall RBX::RbxTransport::Protocol::DatagramId::DatagramId(__int64 *a1, int a2, unsigned int a3)
{
  __int64 v5; // rax
  __int64 result; // rax
  int v7[5]; // [rsp+Ch] [rbp-14h] BYREF

  v7[0] = a2; /*0x10376ca2f*/
  v5 = (unsigned int)-a2; /*0x10376ca33*/
  if ( a2 > 0 ) /*0x10376ca35*/
    v5 = (unsigned int)a2; /*0x10376ca35*/
  *a1 = (v5 << 32) | a3; /*0x10376ca41*/
  result = RBX::RbxTransport::Protocol::WireChannelId::valid(this: (RBX::RbxTransport::Protocol::WireChannelId *)v7); /*0x10376ca44*/
  if ( ((unsigned __int8)result & (a3 != 0)) == 0 ) /*0x10376ca51*/
    *a1 = 0; /*0x10376ca53*/
  return result; /*0x10376ca5a*/
}

// Address: 0x10376ca64 | Name: __ZNK3RBX12RbxTransport8Protocol10DatagramId8toStringEv
RBX::RbxTransport::Protocol::DatagramId *__fastcall RBX::RbxTransport::Protocol::DatagramId::toString(
        RBX::RbxTransport::Protocol::DatagramId *this,
        unsigned int *a2)
{
  int Unreliable; // eax
  __int64 v5; // rcx
  __int64 v6; // rcx
  _BYTE *v7; // rdx
  __int64 v8; // rax
  _QWORD v10[5]; // [rsp+0h] [rbp-70h] BYREF
  unsigned int v11; // [rsp+2Ch] [rbp-44h] BYREF
  unsigned __int8 v12; // [rsp+30h] [rbp-40h] BYREF
  _BYTE v13[15]; // [rsp+31h] [rbp-3Fh] BYREF
  void *v14; // [rsp+40h] [rbp-30h]

  Unreliable = RBX::RbxTransport::Protocol::WireChannelId::createUnreliable( /*0x10376ca7e*/
                 this: (RBX::RbxTransport::Protocol::WireChannelId *)a2[1],
                 (unsigned int)a2);
  v5 = (unsigned int)-Unreliable; /*0x10376ca85*/
  if ( Unreliable > 0 ) /*0x10376ca87*/
    v5 = (unsigned int)Unreliable; /*0x10376ca87*/
  v11 = (unsigned int)Unreliable >> 31; /*0x10376ca91*/
  v10[0] = v5; /*0x10376ca97*/
  v10[2] = &v11; /*0x10376ca9b*/
  v10[3] = fmt::v8::detail::value<fmt::v8::basic_format_context<fmt::v8::appender,char>>::format_custom_arg<RBX::RbxTransport::ChannelReliability,fmt::v8::formatter<RBX::RbxTransport::ChannelReliability,char,void>>; /*0x10376caa7*/
  fmt::v8::vformat(a1: &v12, a2: "{}:{}", a3: 5, a4: 241, a5: v10); /*0x10376caca*/
  v6 = v12 >> 1; /*0x10376cad6*/
  v7 = v14; /*0x10376cade*/
  if ( (v12 & 1) != 0 ) /*0x10376cae2*/
    v6 = *(_QWORD *)&v13[7]; /*0x10376cae6*/
  else
    v7 = v13; /*0x10376cae2*/
  v8 = *a2; /*0x10376caeb*/
  v10[0] = v7; /*0x10376caee*/
  v10[1] = v6; /*0x10376caf2*/
  v10[2] = v8; /*0x10376caf7*/
  fmt::v8::vformat(a1: this, a2: "{}:{}", a3: 5, a4: 45, a5: v10); /*0x10376cb10*/
  if ( (v12 & 1) != 0 ) /*0x10376cb19*/
    operator delete(a1: v14); /*0x10376cb1f*/
  return this; /*0x10376cb27*/
}

// Address: 0x10376cb50 | Name: __ZNK3RBX12RbxTransport8Protocol10DatagramId12getChannelIdEv
__int64 __fastcall RBX::RbxTransport::Protocol::DatagramId::getChannelId(
        RBX::RbxTransport::Protocol::DatagramId *this,
        unsigned int a2)
{
  return RBX::RbxTransport::Protocol::WireChannelId::createUnreliable( /*0x10376cb57*/
           this: (RBX::RbxTransport::Protocol::WireChannelId *)*((unsigned int *)this + 1),
           a2);
}

// END DatagramId part 1/1, 4 functions
