// RuppError -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 1 functions


// Address: 0x1037b9ef8 | Name: __ZN3RBX4Rupp9RuppError8toStringENS1_9ErrorCodeE
const char *__fastcall RBX::Rupp::RuppError::toString(unsigned int a1)
{
  if ( a1 > 0xC ) /*0x1037b9eff*/
    return "Unknown RuppError"; /*0x1037b9f13*/
  else
    return (char *)dword_109571F64 + dword_109571F64[a1]; /*0x1037b9f0e*/
}

// END RuppError part 1/1, 1 functions
