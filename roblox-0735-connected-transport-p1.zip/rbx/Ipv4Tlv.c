// Ipv4Tlv -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 8 functions


// Address: 0x1037b9f1c | Name: __ZN3RBX4Rupp7Ipv4TlvC2E7in_addrt
void (__fastcall **__fastcall RBX::Rupp::Ipv4Tlv::Ipv4Tlv(
        in_addr *this,
        in_addr a2,
        __int16 a3))(RBX::Rupp::Ipv4Tlv *__hidden this)
{
  *(_QWORD *)&this->s_addr = off_10C8EC4E8; /*0x1037b9f27*/
  *(this + 2) = a2; /*0x1037b9f2a*/
  *((_WORD *)this + 6) = a3; /*0x1037b9f2d*/
  return off_10C8EC4E8; /*0x1037b9f31*/
}

// Address: 0x1037b9f34 | Name: __ZN3RBX4Rupp7Ipv4TlvC1E7in_addrt
void (__fastcall **__fastcall RBX::Rupp::Ipv4Tlv::Ipv4Tlv(
        in_addr *this,
        in_addr a2,
        __int16 a3))(RBX::Rupp::Ipv4Tlv *__hidden this)
{
  *(_QWORD *)&this->s_addr = off_10C8EC4E8; /*0x1037b9f3f*/
  *(this + 2) = a2; /*0x1037b9f42*/
  *((_WORD *)this + 6) = a3; /*0x1037b9f45*/
  return off_10C8EC4E8; /*0x1037b9f49*/
}

// Address: 0x1037b9f4c | Name: __ZNK3RBX4Rupp7Ipv4Tlv9serializeENS_16MutableArrayViewIhEE
__int64 __fastcall RBX::Rupp::Ipv4Tlv::serialize(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  __int64 v5; // rsi

  if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)a1 + 24LL))(a1) > a3 ) /*0x1037b9f6d*/
    return 11; /*0x1037b9f6f*/
  *(_DWORD *)a2 = *(_DWORD *)(a1 + 8); /*0x1037b9f79*/
  *(_WORD *)(a2 + 4) = __ROL2__(*(_WORD *)(a1 + 12), 8); /*0x1037b9f84*/
  (*(void (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)a1 + 24LL))(a1, a2: v5, a3: 0); /*0x1037b9f8f*/
  return 0; /*0x1037b9f9b*/
}

// Address: 0x1037b9fa2 | Name: __ZN3RBX4Rupp7Ipv4Tlv11deserializeERNS0_21DeserializationResultENS_9ArrayViewIhEE
__int64 __fastcall RBX::Rupp::Ipv4Tlv::deserialize(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  __int128 v5; // [rsp+0h] [rbp-30h] BYREF

  result = 1; /*0x1037b9fbb*/
  if ( a3 == 6 ) /*0x1037b9fc4*/
  {
    v5 = 0; /*0x1037b9fd0*/
    DWORD1(v5) = *(_DWORD *)a2; /*0x1037b9fd7*/
    WORD1(v5) = *(_WORD *)(a2 + 4); /*0x1037b9fde*/
    *(_BYTE *)(a1 + 72) = 1; /*0x1037b9fe3*/
    inet_ntop(a1: 2, a2: (char *)&v5 + 4, a3: (char *)(a1 + 24), a4: 0x2Eu); /*0x1037b9ff8*/
    *(_WORD *)(a1 + 70) = __ROL2__(WORD1(v5), 8); /*0x1037ba006*/
    return 0; /*0x1037ba00a*/
  }
  return result; /*0x1037ba01c*/
}

// Address: 0x1037ba4e8 | Name: __ZN3RBX4Rupp7Ipv4TlvD1Ev
void __fastcall RBX::Rupp::Ipv4Tlv::~Ipv4Tlv(RBX::Rupp::Ipv4Tlv *this)
{
  ; /*0x1037ba4e8*/
}

// Address: 0x1037ba4ee | Name: __ZN3RBX4Rupp7Ipv4TlvD0Ev
void __fastcall RBX::Rupp::Ipv4Tlv::~Ipv4Tlv(RBX::Rupp::Ipv4Tlv *this)
{
  operator delete(a1: this); /*0x1037ba4f3*/
}

// Address: 0x1037ba4f8 | Name: __ZNK3RBX4Rupp7Ipv4Tlv10getTlvTypeEv
__int64 __fastcall RBX::Rupp::Ipv4Tlv::getTlvType(RBX::Rupp::Ipv4Tlv *this)
{
  return 2; /*0x1037ba501*/
}

// Address: 0x1037ba504 | Name: __ZNK3RBX4Rupp7Ipv4Tlv18getValueByteLengthEv
__int64 __fastcall RBX::Rupp::Ipv4Tlv::getValueByteLength(RBX::Rupp::Ipv4Tlv *this)
{
  return 6; /*0x1037ba50d*/
}

// END Ipv4Tlv part 1/1, 8 functions
