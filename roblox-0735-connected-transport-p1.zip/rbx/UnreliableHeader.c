// UnreliableHeader -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 5 functions


// Address: 0x10376cbba | Name: __ZN3RBX12RbxTransport8Protocol16UnreliableHeaderC2ENS1_13WireChannelIdEyyy
void __fastcall RBX::RbxTransport::Protocol::UnreliableHeader::UnreliableHeader(
        __int64 a1,
        int a2,
        __int64 a3,
        __int64 a4,
        __int64 a5)
{
  *(_DWORD *)a1 = a2; /*0x10376cbbe*/
  *(_QWORD *)(a1 + 8) = a3; /*0x10376cbc0*/
  *(_QWORD *)(a1 + 16) = a4; /*0x10376cbc4*/
  *(_QWORD *)(a1 + 24) = a5; /*0x10376cbc8*/
}

// Address: 0x10376cbce | Name: __ZN3RBX12RbxTransport8Protocol16UnreliableHeaderC1ENS1_13WireChannelIdEyyy
void __fastcall RBX::RbxTransport::Protocol::UnreliableHeader::UnreliableHeader(
        __int64 a1,
        int a2,
        __int64 a3,
        __int64 a4,
        __int64 a5)
{
  *(_DWORD *)a1 = a2; /*0x10376cbd2*/
  *(_QWORD *)(a1 + 8) = a3; /*0x10376cbd4*/
  *(_QWORD *)(a1 + 16) = a4; /*0x10376cbd8*/
  *(_QWORD *)(a1 + 24) = a5; /*0x10376cbdc*/
}

// Address: 0x10376cbe2 | Name: __ZNK3RBX12RbxTransport8Protocol16UnreliableHeader14serializedSizeEv
__int64 __fastcall RBX::RbxTransport::Protocol::UnreliableHeader::serializedSize(
        RBX::RbxTransport::QuicVarInt **this,
        unsigned __int64 a2)
{
  unsigned int v3; // eax
  unsigned __int64 v4; // rdi
  __int64 v5; // r15
  unsigned __int64 v6; // rsi
  __int64 v7; // r12
  unsigned __int64 v8; // rsi
  unsigned __int64 v9; // rsi
  __int64 v10; // r14

  v3 = *(_DWORD *)this; /*0x10376cbf0*/
  v4 = (unsigned int)-*(_DWORD *)this; /*0x10376cbf4*/
  if ( (v4 & 0x80000000) != 0LL ) /*0x10376cbf6*/
    v4 = v3; /*0x10376cbf6*/
  v5 = RBX::RbxTransport::QuicVarInt::varIntMinSize(this: (RBX::RbxTransport::QuicVarInt *)v4, a2); /*0x10376cbfe*/
  v7 = RBX::RbxTransport::QuicVarInt::varIntMinSize(this: *(this + 1), a2: v6); /*0x10376cc0a*/
  v10 = v5 + v7 + RBX::RbxTransport::QuicVarInt::varIntMinSize(this: *(this + 2), a2: v8); /*0x10376cc1c*/
  if ( *(this + 2) != nullptr ) /*0x10376cc24*/
    v10 += RBX::RbxTransport::QuicVarInt::varIntMinSize(this: *(this + 3), a2: v9); /*0x10376cc2f*/
  return v10; /*0x10376cc35*/
}

// Address: 0x10376cc3e | Name: __ZNK3RBX12RbxTransport8Protocol16UnreliableHeader9serializeENS_16MutableArrayViewIhEE
__int64 __fastcall RBX::RbxTransport::Protocol::UnreliableHeader::serialize(
        unsigned int *a1,
        unsigned __int64 a2,
        unsigned __int64 a3)
{
  __int64 v6; // r12
  __int64 v7; // rdi
  __int64 v8; // r12
  unsigned __int64 v9; // rbx
  unsigned __int64 v10; // r14
  __int64 v11; // rax
  __int64 v12; // r12
  unsigned __int64 v13; // rbx
  unsigned __int64 v14; // r14
  __int64 v15; // rax

  if ( RBX::RbxTransport::Protocol::UnreliableHeader::serializedSize(this: (RBX::RbxTransport::QuicVarInt **)a1, a2) > a3 ) /*0x10376cc5a*/
    return 0; /*0x10376cc5c*/
  v7 = -*a1; /*0x10376cc66*/
  if ( (int)*a1 > 0 ) /*0x10376cc68*/
    v7 = *a1; /*0x10376cc68*/
  v8 = RBX::RbxTransport::QuicVarInt::writeNetOrderVarInt(a1: v7, a2, a3); /*0x10376cc76*/
  v9 = a3 - v8; /*0x10376cc79*/
  v10 = v8 + a2; /*0x10376cc7c*/
  v11 = RBX::RbxTransport::QuicVarInt::writeNetOrderVarInt(a1: *((_QWORD *)a1 + 1), a2: v10, a3: v9); /*0x10376cc89*/
  v12 = v11 + v8; /*0x10376cc8e*/
  v13 = v9 - v11; /*0x10376cc91*/
  v14 = v11 + v10; /*0x10376cc94*/
  v15 = RBX::RbxTransport::QuicVarInt::writeNetOrderVarInt(a1: *((_QWORD *)a1 + 2), a2: v14, a3: v13); /*0x10376cca1*/
  v6 = v15 + v12; /*0x10376cca6*/
  if ( *((_QWORD *)a1 + 2) != 0 ) /*0x10376ccae*/
    v6 += RBX::RbxTransport::QuicVarInt::writeNetOrderVarInt(a1: *((_QWORD *)a1 + 3), a2: v15 + v14, a3: v13 - v15); /*0x10376ccc5*/
  return v6; /*0x10376cccb*/
}

// Address: 0x10376ccd4 | Name: __ZN3RBX12RbxTransport8Protocol16UnreliableHeader5parseENS_9ArrayViewIhEERm
__int64 __fastcall RBX::RbxTransport::Protocol::UnreliableHeader::parse(__int64 a1, char *a2, __int64 a3, _QWORD *a4)
{
  __int64 NetOrderVarInt; // rax
  __int64 v8; // r14
  char *v9; // r12
  __int64 v10; // rax
  __int64 v11; // r13
  __int64 v12; // rax
  unsigned int v13; // esi
  char v14; // al
  _QWORD *v16; // [rsp+10h] [rbp-40h]

  *a4 = 0; /*0x10376ccf3*/
  NetOrderVarInt = RBX::RbxTransport::QuicVarInt::readNetOrderVarInt(__src: a2); /*0x10376cd03*/
  if ( NetOrderVarInt != 0 /*0x10376cd5f*/
    && (v8 = NetOrderVarInt,
        v16 = a4,
        v9 = &a2[NetOrderVarInt],
        (v10 = RBX::RbxTransport::QuicVarInt::readNetOrderVarInt(__src: v9)) != 0)
    && (v11 = v10, (v12 = RBX::RbxTransport::QuicVarInt::readNetOrderVarInt(__src: &v9[v10])) != 0) )
  {
    *v16 = v12 + v8 + v11; /*0x10376cd97*/
    *(_DWORD *)a1 = RBX::RbxTransport::Protocol::WireChannelId::createUnreliable(this: nullptr, a2: v13); /*0x10376cdae*/
    *(_QWORD *)(a1 + 8) = 0; /*0x10376cdb0*/
    *(_QWORD *)(a1 + 16) = 0; /*0x10376cdb4*/
    *(_QWORD *)(a1 + 24) = 0; /*0x10376cdb8*/
    v14 = 1; /*0x10376cdbc*/
  }
  else
  {
    v14 = 0; /*0x10376cdc0*/
    *(_BYTE *)a1 = 0; /*0x10376cdc2*/
  }
  *(_BYTE *)(a1 + 32) = v14; /*0x10376cdc4*/
  return a1; /*0x10376cdca*/
}

// END UnreliableHeader part 1/1, 5 functions
