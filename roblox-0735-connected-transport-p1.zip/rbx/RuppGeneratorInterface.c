// RuppGeneratorInterface -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 2 functions


// Address: 0x108669110 | Name: __ZN3RBX4Rupp22RuppGeneratorInterfaceD1Ev
void __fastcall __noreturn RBX::Rupp::RuppGeneratorInterface::~RuppGeneratorInterface(
        RBX::Rupp::RuppGeneratorInterface *this)
{
  BUG(); /*0x108669114*/
}

// Address: 0x108669116 | Name: __ZN3RBX4Rupp22RuppGeneratorInterfaceD0Ev
void __fastcall __noreturn RBX::Rupp::RuppGeneratorInterface::~RuppGeneratorInterface(
        RBX::Rupp::RuppGeneratorInterface *this)
{
  BUG(); /*0x10866911a*/
}

// END RuppGeneratorInterface part 1/1, 2 functions
