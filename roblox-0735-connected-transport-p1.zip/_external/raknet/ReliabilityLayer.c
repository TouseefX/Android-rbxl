// ReliabilityLayer -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 105 functions


// Address: 0x1039da6ca | Name: __ZN6RakNet16ReliabilityLayerC2Ev
__int64 __fastcall RakNet::ReliabilityLayer::ReliabilityLayer(RakNet::ReliabilityLayer *this)
{
  __int64 i; // rcx
  char *v3; // rax
  __int64 j; // rcx
  __int64 k; // rax
  RakNet::BPSTracker *v6; // r15
  __int64 m; // r12
  RakNet::CCRakNetSlidingWindow2 *v8; // r15
  __int64 result; // rax
  char *v10; // [rsp+60h] [rbp-40h]

  *((_DWORD *)this + 18) = 0; /*0x1039da6e8*/
  *(_OWORD *)((char *)this + 56) = 0; /*0x1039da6ee*/
  *((_QWORD *)this + 12) = 0; /*0x1039da6f2*/
  *(_OWORD *)this = 0; /*0x1039da6f6*/
  *((_OWORD *)this + 1) = 0; /*0x1039da6f9*/
  *((_DWORD *)this + 8) = 0; /*0x1039da6fd*/
  *((_DWORD *)this + 26) = 0x4000; /*0x1039da705*/
  *(_OWORD *)((char *)this + 120) = 0; /*0x1039da710*/
  *((_QWORD *)this + 20) = 0; /*0x1039da714*/
  *((_DWORD *)this + 42) = 0x4000; /*0x1039da71b*/
  v10 = (char *)this + 176; /*0x1039da728*/
  *((_OWORD *)this + 11) = 0; /*0x1039da72c*/
  *((_QWORD *)this + 24) = 0; /*0x1039da733*/
  *((_OWORD *)this + 14) = 0; /*0x1039da74f*/
  *((_QWORD *)this + 27) = (char *)this + 224; /*0x1039da75d*/
  *((_OWORD *)this + 22) = 0; /*0x1039da76f*/
  *((_BYTE *)this + 368) = 0; /*0x1039da776*/
  *(_OWORD *)((char *)this + 408) = 0; /*0x1039da788*/
  *(_OWORD *)((char *)this + 316) = 0; /*0x1039da78f*/
  *(_OWORD *)((char *)this + 300) = 0; /*0x1039da796*/
  *(_OWORD *)((char *)this + 284) = 0; /*0x1039da79d*/
  *(_OWORD *)((char *)this + 268) = 0; /*0x1039da7a4*/
  *(_OWORD *)((char *)this + 252) = 0; /*0x1039da7ab*/
  for ( i = 468; i != 500; i += 8 ) /*0x1039da7b2*/
  {
    *((_BYTE *)this + i - 4) = 0; /*0x1039da7b7*/
    *((_BYTE *)this + i) = 0; /*0x1039da7bb*/
  }
  *((_BYTE *)this + 496) = 0; /*0x1039da7d8*/
  *((_BYTE *)this + 500) = 0; /*0x1039da7de*/
  *((_BYTE *)this + 504) = 0; /*0x1039da7e4*/
  *((_BYTE *)this + 508) = 0; /*0x1039da7ea*/
  *((_BYTE *)this + 512) = 0; /*0x1039da7f0*/
  *((_BYTE *)this + 516) = 0; /*0x1039da7f6*/
  *((_BYTE *)this + 520) = 0; /*0x1039da7fc*/
  *((_BYTE *)this + 524) = 0; /*0x1039da802*/
  v3 = (char *)this + 552; /*0x1039da808*/
  for ( j = 128; j != 0; j -= 32 ) /*0x1039da80f*/
  {
    *((_QWORD *)v3 - 3) = v3; /*0x1039da814*/
    *((_QWORD *)v3 - 2) = 0; /*0x1039da818*/
    *((_QWORD *)v3 - 1) = 4; /*0x1039da820*/
    v3 += 32; /*0x1039da828*/
  }
  *(_OWORD *)((char *)this + 1048) = 0; /*0x1039da835*/
  *(_OWORD *)((char *)this + 1032) = 0; /*0x1039da83c*/
  *(_OWORD *)((char *)this + 1016) = 0; /*0x1039da843*/
  *(_OWORD *)((char *)this + 1000) = 0; /*0x1039da84a*/
  *(_OWORD *)((char *)this + 984) = 0; /*0x1039da851*/
  *((_OWORD *)this + 41) = 0; /*0x1039da858*/
  *((_OWORD *)this + 42) = 0; /*0x1039da85f*/
  *((_OWORD *)this + 43) = 0; /*0x1039da866*/
  *((_OWORD *)this + 44) = 0; /*0x1039da86d*/
  *((_OWORD *)this + 56) = 0; /*0x1039da874*/
  *(_OWORD *)((char *)this + 908) = 0; /*0x1039da87b*/
  *((_OWORD *)this + 58) = 0; /*0x1039da882*/
  *((_OWORD *)this + 59) = 0; /*0x1039da889*/
  *((_OWORD *)this + 60) = 0; /*0x1039da890*/
  *((_DWORD *)this + 244) = 0; /*0x1039da899*/
  *((_OWORD *)this + 76) = 0; /*0x1039da89f*/
  *((_OWORD *)this + 75) = 0; /*0x1039da8a6*/
  *((_OWORD *)this + 74) = 0; /*0x1039da8ad*/
  *((_OWORD *)this + 73) = 0; /*0x1039da8b4*/
  *((_OWORD *)this + 72) = 0; /*0x1039da8bb*/
  *((_OWORD *)this + 71) = 0; /*0x1039da8c2*/
  *((_OWORD *)this + 70) = 0; /*0x1039da8c9*/
  *((_OWORD *)this + 69) = 0; /*0x1039da8d0*/
  *((_OWORD *)this + 68) = 0; /*0x1039da8d7*/
  *((_OWORD *)this + 67) = 0; /*0x1039da8de*/
  *((_DWORD *)this + 322) = 0; /*0x1039da8e5*/
  *(_OWORD *)((char *)this + 1272) = 0; /*0x1039da8eb*/
  *(_OWORD *)((char *)this + 1256) = 0; /*0x1039da8f2*/
  *(_OWORD *)((char *)this + 1240) = 0; /*0x1039da8f9*/
  *(_OWORD *)((char *)this + 1418) = 0; /*0x1039da900*/
  *((_OWORD *)this + 88) = 0; /*0x1039da907*/
  *((_OWORD *)this + 87) = 0; /*0x1039da90e*/
  *((_OWORD *)this + 86) = 0; /*0x1039da915*/
  *((_OWORD *)this + 85) = 0; /*0x1039da91c*/
  *((_OWORD *)this + 84) = 0; /*0x1039da923*/
  *((_OWORD *)this + 83) = 0; /*0x1039da92a*/
  *((_OWORD *)this + 82) = 0; /*0x1039da931*/
  *((_OWORD *)this + 81) = 0; /*0x1039da938*/
  for ( k = 1952; k != 2720; k += 24 ) /*0x1039da93f*/
  {
    *(_OWORD *)((char *)this + k) = 0; /*0x1039da944*/
    *((_BYTE *)this + k + 16) = 0; /*0x1039da948*/
  }
  *((_OWORD *)this + 178) = 0; /*0x1039da972*/
  *((_DWORD *)this + 716) = 0; /*0x1039da979*/
  *((_QWORD *)this + 402) = 0; /*0x1039da9b2*/
  *(_OWORD *)((char *)this + 3048) = 0; /*0x1039da9bd*/
  *(_OWORD *)((char *)this + 3064) = 0; /*0x1039da9c4*/
  *(_OWORD *)((char *)this + 3080) = 0; /*0x1039da9cb*/
  *(_OWORD *)((char *)this + 3096) = 0; /*0x1039da9d2*/
  *(_OWORD *)((char *)this + 3144) = 0; /*0x1039da9d9*/
  *(_OWORD *)((char *)this + 3160) = 0; /*0x1039da9e0*/
  *(_OWORD *)((char *)this + 3176) = 0; /*0x1039da9e7*/
  *((_DWORD *)this + 806) = 0x4000; /*0x1039da9ee*/
  v6 = (RakNet::ReliabilityLayer *)((char *)this + 3232); /*0x1039da9f8*/
  for ( m = 0; m != -832; m -= 104 ) /*0x1039da9ff*/
  {
    RakNet::BPSTracker::BPSTracker(this: v6); /*0x1039daa05*/
    v6 = (RakNet::BPSTracker *)((char *)v6 + 104); /*0x1039daa0e*/
  }
  *((_QWORD *)this + 509) = 0x3FA999999999999ALL; /*0x1039daa25*/
  *((_OWORD *)this + 255) = 0; /*0x1039daa2f*/
  *((_QWORD *)this + 512) = 0; /*0x1039daa38*/
  *((_BYTE *)this + 4104) = 1; /*0x1039daa3f*/
  *((_DWORD *)this + 1038) = 0; /*0x1039daa46*/
  *((_BYTE *)this + 4156) = 0; /*0x1039daa50*/
  *((_OWORD *)this + 257) = 0; /*0x1039daa57*/
  *((_OWORD *)this + 258) = 0; /*0x1039daa5e*/
  *((_OWORD *)this + 260) = RakNet::UNASSIGNED_SYSTEM_ADDRESS; /*0x1039daa6c*/
  *((_OWORD *)this + 261) = *(&RakNet::UNASSIGNED_SYSTEM_ADDRESS + 1); /*0x1039daa7a*/
  *((_QWORD *)this + 524) = 0; /*0x1039daa81*/
  *((_WORD *)this + 2100) = 0; /*0x1039daa88*/
  *((_QWORD *)this + 526) = 0; /*0x1039daa91*/
  if ( DFFlag::RakNetUseSlidingWindow4 == 1 ) /*0x1039daa9f*/
  {
    v8 = (RakNet::CCRakNetSlidingWindow2 *)operator new(a1: 0x1D0u); /*0x1039daaab*/
    RakNet::CCRakNetSlidingWindow2::CCRakNetSlidingWindow2(this: v8); /*0x1039daab1*/
  }
  else
  {
    v8 = (RakNet::CCRakNetSlidingWindow2 *)operator new(a1: 0x48u); /*0x1039daac2*/
    RakNet::CCRakNetSlidingWindow::CCRakNetSlidingWindow(this: v8); /*0x1039daac8*/
  }
  *((_QWORD *)this + 379) = v8; /*0x1039daacd*/
  std::vector<RakNet::InternalPacket *>::resize(a1: v10, a2: FInt::RakNetResendBufferArrayLength); /*0x1039daadf*/
  *((_DWORD *)this + 112) = 10000; /*0x1039daae4*/
  *((_QWORD *)this + 57) = &DFInt::MaxDataPayloadSize; /*0x1039daaf5*/
  *(_OWORD *)((char *)this + 3000) = 0; /*0x1039daaff*/
  result = RakNet::ReliabilityLayer::InitializeVariables(this); /*0x1039dab09*/
  *((_DWORD *)this + 26) = 2048; /*0x1039dab0e*/
  *((_DWORD *)this + 42) = 2176; /*0x1039dab15*/
  *((_DWORD *)this + 806) = 512; /*0x1039dab1f*/
  *((_QWORD *)this + 154) = 0; /*0x1039dab29*/
  return result; /*0x1039dab34*/
}

// Address: 0x1039dadb2 | Name: __ZN6RakNet16ReliabilityLayer19InitializeVariablesEv
__int64 __fastcall RakNet::ReliabilityLayer::InitializeVariables(RakNet::ReliabilityLayer *this)
{
  char *v2; // r14
  __int64 v3; // r14
  bool v4; // si
  unsigned __int64 TimeUS; // rax
  const char *v6; // rsi
  unsigned __int64 v7; // rdx
  __int64 i; // r15
  __int64 result; // rax

  v2 = (char *)this + 1436; /*0x1039dadbf*/
  __bzero(a1: (char *)this + 464, a2: 608); /*0x1039dadd2*/
  *((_OWORD *)this + 177) = 0; /*0x1039dadda*/
  *((_OWORD *)this + 176) = 0; /*0x1039dade1*/
  *((_OWORD *)this + 175) = 0; /*0x1039dade8*/
  *((_OWORD *)this + 174) = 0; /*0x1039dadef*/
  *((_OWORD *)this + 173) = 0; /*0x1039dadf6*/
  *((_OWORD *)this + 172) = 0; /*0x1039dadfd*/
  *((_OWORD *)this + 171) = 0; /*0x1039dae04*/
  *((_OWORD *)this + 170) = 0; /*0x1039dae0b*/
  __bzero(a1: v2, a2: 512); /*0x1039dae1a*/
  v3 = 0; /*0x1039dae1f*/
  TimeUS = RakNet::GetTimeUS(this: nullptr, a2: v4); /*0x1039dae24*/
  v7 = TimeUS / 0x3E8; /*0x1039dae3d*/
  *((_QWORD *)this + 98) = TimeUS; /*0x1039dae41*/
  *((_WORD *)this + 222) = 0; /*0x1039dae48*/
  *((_QWORD *)this + 377) = 0; /*0x1039dae50*/
  *((_QWORD *)this + 373) = 0; /*0x1039dae57*/
  *((_DWORD *)this + 108) = 0; /*0x1039dae5e*/
  *((_QWORD *)this + 26) = 0; /*0x1039dae65*/
  *((_QWORD *)this + 360) = TimeUS; /*0x1039dae6c*/
  *((_QWORD *)this + 6) = 0; /*0x1039dae73*/
  *((_QWORD *)this + 508) = 0; /*0x1039dae77*/
  *((_WORD *)this + 218) = 0; /*0x1039dae7e*/
  *(_OWORD *)((char *)this + 3128) = 0; /*0x1039dae89*/
  *((_OWORD *)this + 185) = 0; /*0x1039dae90*/
  *((_BYTE *)this + 2976) = 0; /*0x1039dae9a*/
  *((_DWORD *)this + 62) = TimeUS / 0x3E8; /*0x1039daea1*/
  *((_QWORD *)this + 53) = 0; /*0x1039daea7*/
  *((_DWORD *)this + 83) = TimeUS; /*0x1039daeae*/
  *((_QWORD *)this + 42) = TimeUS; /*0x1039daeb4*/
  *((_QWORD *)this + 43) = TimeUS; /*0x1039daebb*/
  *((_DWORD *)this + 65) = TimeUS / 0x3E8; /*0x1039daec2*/
  *((__m128i *)this + 19) = _mm_shuffle_epi32(_mm_cvtsi32_si128(TimeUS / 0x3E8), 0); /*0x1039daed1*/
  *((_DWORD *)this + 80) = TimeUS / 0x3E8; /*0x1039daed9*/
  *((_DWORD *)this + 81) = TimeUS / 0x3E8; /*0x1039daedf*/
  *((_DWORD *)this + 82) = TimeUS / 0x3E8; /*0x1039daee5*/
  *((_DWORD *)this + 218) = 0; /*0x1039daeeb*/
  *((_QWORD *)this + 110) = 0; /*0x1039daef2*/
  *((_DWORD *)this + 718) = 0; /*0x1039daef9*/
  *((_BYTE *)this + 2876) = 1; /*0x1039daf00*/
  *((_DWORD *)this + 748) = 0; /*0x1039daf07*/
  *((_QWORD *)this + 361) = 350000; /*0x1039daf0e*/
  *(_OWORD *)((char *)this + 2937) = 0; /*0x1039daf19*/
  *((_OWORD *)this + 183) = 0; /*0x1039daf20*/
  *((_OWORD *)this + 182) = 0; /*0x1039daf27*/
  *((_QWORD *)this + 362) = TimeUS; /*0x1039daf2e*/
  *((_DWORD *)this + 760) = 0; /*0x1039daf35*/
  *((_QWORD *)this + 25) = 0; /*0x1039daf3c*/
  *((_QWORD *)this + 30) = 0; /*0x1039daf43*/
  *((_QWORD *)this + 390) = 0; /*0x1039daf4a*/
  *((_DWORD *)this + 34) = 0; /*0x1039daf51*/
  *((_DWORD *)this + 28) = 0; /*0x1039daf58*/
  *((_DWORD *)this + 1038) = 0; /*0x1039daf5c*/
  *((_BYTE *)this + 4156) = 0; /*0x1039daf63*/
  *((_QWORD *)this + 524) = 0; /*0x1039daf6a*/
  do /*0x1039daf8b*/
  {
    *((_QWORD *)this + v3 + 47) = v3 + (unsigned int)((_DWORD)v3 << v3); /*0x1039daf7c*/
    ++v3; /*0x1039daf84*/
  }
  while ( v3 != 4 ); /*0x1039daf8b*/
  *(_OWORD *)((char *)this + 856) = 0; /*0x1039daf98*/
  *(_OWORD *)((char *)this + 840) = 0; /*0x1039dafa0*/
  *(_OWORD *)((char *)this + 824) = 0; /*0x1039dafa8*/
  for ( i = 0; i != 832; i += 104 ) /*0x1039dafb0*/
    result = RakNet::BPSTracker::Reset(this: (RakNet::ReliabilityLayer *)((char *)this + i + 3232), a2: v6, a3: v7); /*0x1039dafb7*/
  *((_DWORD *)this + 110) = 1; /*0x1039dafc9*/
  return result; /*0x1039dafd7*/
}

// Address: 0x1039dafde | Name: __ZN6RakNet16ReliabilityLayerC1Ev
__int64 __fastcall RakNet::ReliabilityLayer::ReliabilityLayer(RakNet::ReliabilityLayer *this)
{
  return RakNet::ReliabilityLayer::ReliabilityLayer(this); /*0x1039dafe2*/
}

// Address: 0x1039dafe8 | Name: __ZN6RakNet16ReliabilityLayerD2Ev
void __fastcall RakNet::ReliabilityLayer::~ReliabilityLayer(RakNet::ReliabilityLayer *this)
{
  __int64 v2; // rdi
  void *v3; // rdi
  __int64 i; // r14
  void *v5; // rdi
  void *v6; // rdi
  void *v7; // rdi
  void *v8; // rdi
  void *v9; // rdi
  __int64 j; // r14
  void *v11; // rdi
  __int64 k; // r15
  char *v13; // rdi
  void *v14; // rdi
  void *v15; // rdi
  void *v16; // rdi
  void *v17; // rdi
  void *v18; // rdi
  void *v19; // rdi

  RakNet::ReliabilityLayer::FreeThreadSafeMemory(this); /*0x1039daff5*/
  v2 = *((_QWORD *)this + 379); /*0x1039daffa*/
  if ( v2 != 0 ) /*0x1039db004*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 8LL))(a1: v2); /*0x1039db009*/
  v3 = *((void **)this + 515); /*0x1039db00c*/
  if ( v3 != nullptr ) /*0x1039db016*/
  {
    *((_QWORD *)this + 516) = v3; /*0x1039db018*/
    operator delete(a1: v3); /*0x1039db01f*/
  }
  for ( i = 3960; i != 3128; i -= 104 ) /*0x1039db024*/
    RakNet::BPSTracker::~BPSTracker(this: (RakNet::ReliabilityLayer *)((char *)this + i)); /*0x1039db02e*/
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::~MemoryPool(a1: (__int64)this + 3200); /*0x1039db047*/
  DataStructures::RangeList<RakNet::uint24_t>::~RangeList(a1: (__int64)this + 3176); /*0x1039db053*/
  DataStructures::RangeList<RakNet::uint24_t>::~RangeList(a1: (__int64)this + 3160); /*0x1039db05f*/
  DataStructures::RangeList<RakNet::uint24_t>::~RangeList(a1: (__int64)this + 3144); /*0x1039db06b*/
  if ( *((_DWORD *)this + 777) != 0 ) /*0x1039db077*/
  {
    v5 = *((void **)this + 387); /*0x1039db079*/
    if ( v5 != nullptr ) /*0x1039db083*/
      operator delete[](a1: v5); /*0x1039db085*/
  }
  if ( *((_DWORD *)this + 773) != 0 ) /*0x1039db091*/
  {
    v6 = *((void **)this + 385); /*0x1039db093*/
    if ( v6 != nullptr ) /*0x1039db09d*/
      operator delete[](a1: v6); /*0x1039db09f*/
  }
  if ( *((_DWORD *)this + 769) != 0 ) /*0x1039db0ab*/
  {
    v7 = *((void **)this + 383); /*0x1039db0ad*/
    if ( v7 != nullptr ) /*0x1039db0b7*/
      operator delete[](a1: v7); /*0x1039db0b9*/
  }
  if ( *((_DWORD *)this + 765) != 0 ) /*0x1039db0c5*/
  {
    v8 = *((void **)this + 381); /*0x1039db0c7*/
    if ( v8 != nullptr ) /*0x1039db0d1*/
      operator delete[](a1: v8); /*0x1039db0d3*/
  }
  if ( *((_DWORD *)this + 716) != 0 ) /*0x1039db0df*/
  {
    v9 = *((void **)this + 356); /*0x1039db0e1*/
    if ( v9 != nullptr ) /*0x1039db0eb*/
      operator delete[](a1: v9); /*0x1039db0ed*/
  }
  for ( j = 2696; j != 1928; j -= 24 ) /*0x1039db0f2*/
  {
    if ( *(_DWORD *)((char *)this + j + 12) != 0 ) /*0x1039db0fe*/
    {
      v11 = *(void **)((char *)this + j); /*0x1039db100*/
      if ( v11 != nullptr ) /*0x1039db107*/
        operator delete[](a1: v11); /*0x1039db109*/
    }
  }
  for ( k = 0; k != -128; k -= 32 ) /*0x1039db122*/
  {
    v13 = *(char **)((char *)this + k + 624); /*0x1039db125*/
    if ( (char *)this + k + 648 != v13 ) /*0x1039db134*/
      operator delete(a1: v13); /*0x1039db136*/
  }
  if ( *((_DWORD *)this + 105) != 0 ) /*0x1039db14c*/
  {
    v14 = *((void **)this + 51); /*0x1039db155*/
    if ( v14 != nullptr ) /*0x1039db15b*/
      operator delete[](a1: v14); /*0x1039db15d*/
    *(_OWORD *)((char *)this + 408) = 0; /*0x1039db165*/
  }
  if ( *((_DWORD *)this + 91) != 0 ) /*0x1039db170*/
  {
    v15 = *((void **)this + 44); /*0x1039db172*/
    if ( v15 != nullptr ) /*0x1039db17c*/
      operator delete[](a1: v15); /*0x1039db17e*/
  }
  std::__tree<std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>,std::__map_value_compare<RakNet::uint24_t,std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>,std::less<RakNet::uint24_t>,true>,std::allocator<std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>>>::destroy( /*0x1039db191*/
    a1: (char *)this + 216,
    a2: *((_QWORD *)this + 28));
  v16 = *((void **)this + 22); /*0x1039db196*/
  if ( v16 != nullptr ) /*0x1039db1a0*/
  {
    *((_QWORD *)this + 23) = v16; /*0x1039db1a2*/
    operator delete(a1: v16); /*0x1039db1a9*/
  }
  DataStructures::MemoryPool<RakNet::InternalPacket>::~MemoryPool(a1: (__int64)this + 144); /*0x1039db1b5*/
  if ( *((_DWORD *)this + 33) != 0 ) /*0x1039db1c1*/
  {
    v17 = *((void **)this + 15); /*0x1039db1c3*/
    if ( v17 != nullptr ) /*0x1039db1ca*/
      operator delete[](a1: v17); /*0x1039db1cc*/
  }
  DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::~MemoryPool(a1: (__int64)this + 80); /*0x1039db1d5*/
  if ( *((_DWORD *)this + 18) != 0 ) /*0x1039db1de*/
  {
    v18 = *((void **)this + 7); /*0x1039db1e0*/
    if ( v18 != nullptr ) /*0x1039db1e7*/
      operator delete[](a1: v18); /*0x1039db1e9*/
  }
  if ( *((_DWORD *)this + 8) != 0 ) /*0x1039db1f2*/
  {
    v19 = *((void **)this + 2); /*0x1039db1f4*/
    if ( v19 != nullptr ) /*0x1039db1fb*/
      operator delete[](a1: v19); /*0x1039db1fd*/
  }
  std::shared_ptr<RBX::Security::RakPeerCrypto>::~shared_ptr[abi:ne200100](a1: this); /*0x1039db20f*/
}

// Address: 0x1039db21c | Name: __ZN6RakNet16ReliabilityLayer10FreeMemoryEb
__int64 __fastcall RakNet::ReliabilityLayer::FreeMemory(RakNet::ReliabilityLayer *this)
{
  return RakNet::ReliabilityLayer::FreeThreadSafeMemory(this); /*0x1039db220*/
}

// Address: 0x1039db226 | Name: __ZN6RakNet16ReliabilityLayerD1Ev
void __fastcall RakNet::ReliabilityLayer::~ReliabilityLayer(RakNet::ReliabilityLayer *this)
{
  RakNet::ReliabilityLayer::~ReliabilityLayer(this); /*0x1039db22b*/
}

// Address: 0x1039db230 | Name: __ZN6RakNet16ReliabilityLayer5ResetEbib
__int64 __fastcall RakNet::ReliabilityLayer::Reset(RakNet::ReliabilityLayer *this, int a2, int a3)
{
  __int64 result; // rax
  bool v7; // si
  __int64 v8; // r14
  __int64 TimeUS; // rax

  result = RakNet::ReliabilityLayer::FreeThreadSafeMemory(this); /*0x1039db242*/
  if ( a2 != 0 ) /*0x1039db24a*/
  {
    RakNet::ReliabilityLayer::InitializeVariables(this); /*0x1039db24f*/
  }
  else if ( DFFlag::RakNetUseSlidingWindow4 != 1 ) /*0x1039db25d*/
  {
    return result; /*0x1039db25d*/
  }
  v8 = *((_QWORD *)this + 379); /*0x1039db25f*/
  TimeUS = RakNet::GetTimeUS(this: nullptr, a2: v7); /*0x1039db268*/
  return (*(__int64 (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)v8 + 24LL))( /*0x1039db284*/
           a1: v8,
           a2: TimeUS,
           a3: (unsigned int)(a3 - 58));
}

// Address: 0x1039db296 | Name: __ZN6RakNet16ReliabilityLayer10ResetCCWndEi
__int64 __fastcall RakNet::ReliabilityLayer::ResetCCWnd(RakNet::ReliabilityLayer *this, int a2)
{
  return (*(__int64 (__fastcall **)(_QWORD, _QWORD))(**((_QWORD **)this + 379) + 32LL))(
           a1: *((_QWORD *)this + 379),
           a2: (unsigned int)(a2 - 58));
}

// Address: 0x1039db2ae | Name: __ZN6RakNet16ReliabilityLayer14SetTimeoutTimeEj
void __fastcall RakNet::ReliabilityLayer::SetTimeoutTime(RakNet::ReliabilityLayer *this, int a2)
{
  *((_DWORD *)this + 112) = a2; /*0x1039db2b2*/
}

// Address: 0x1039db2ba | Name: __ZN6RakNet16ReliabilityLayer22SetMaxRxPayloadSizePtrEPN4FInt5ValueE
void __fastcall RakNet::ReliabilityLayer::SetMaxRxPayloadSizePtr(RakNet::ReliabilityLayer *this, FInt::Value *a2)
{
  *((_QWORD *)this + 57) = a2; /*0x1039db2be*/
}

// Address: 0x1039db2c8 | Name: __ZN6RakNet16ReliabilityLayer14GetTimeoutTimeEv
__int64 __fastcall RakNet::ReliabilityLayer::GetTimeoutTime(RakNet::ReliabilityLayer *this)
{
  return *((unsigned int *)this + 112); /*0x1039db2d2*/
}

// Address: 0x1039db2d4 | Name: __ZN6RakNet16ReliabilityLayer15InitHeapWeightsEv
__int64 __fastcall RakNet::ReliabilityLayer::InitHeapWeights(RakNet::ReliabilityLayer *this)
{
  __int64 i; // rcx
  __int64 result; // rax

  for ( i = 0; i != 4; ++i ) /*0x1039db2d8*/
  {
    result = i + (unsigned int)((_DWORD)i << i); /*0x1039db2de*/
    *((_QWORD *)this + i + 47) = result; /*0x1039db2e1*/
  }
  return result; /*0x1039db2f2*/
}

// Address: 0x1039db2f4 | Name: __ZN6RakNet16ReliabilityLayer20FreeThreadSafeMemoryEv
void __fastcall RakNet::ReliabilityLayer::FreeThreadSafeMemory(RakNet::ReliabilityLayer *this)
{
  RakNet::ReliabilityLayer *v1; // rbx
  unsigned int v2; // eax
  unsigned int v3; // edx
  bool v4; // cf
  int v5; // edx
  unsigned int v6; // eax
  unsigned int v7; // ecx
  _QWORD *v8; // r13
  unsigned __int64 v9; // rsi
  RBX::Network::NetworkTracer *v10; // rdi
  __int64 v11; // r12
  char *v12; // r12
  __int64 v13; // r13
  __int64 v14; // r14
  unsigned __int64 v15; // rbx
  unsigned int v16; // eax
  __int64 v17; // r14
  __int64 v18; // rsi
  __int64 v19; // rbx
  _QWORD *v20; // r12
  __int64 v21; // r13
  _QWORD *v22; // rbx
  _QWORD *v23; // r14
  bool v24; // zf
  __int64 v25; // r15
  _QWORD *v26; // r14
  _QWORD *v27; // r13
  _QWORD *v28; // rcx
  _QWORD *v29; // rax
  __int64 v30; // r12
  unsigned __int64 v31; // r13
  _QWORD *v32; // rsi
  unsigned int v33; // eax
  void *v34; // rdi
  void **v35; // rbx
  void **v36; // r15
  void **v37; // r15
  void **v38; // r15
  void **v39; // r15
  unsigned int v40; // eax
  unsigned int v41; // edx
  int v42; // edx
  int v43; // ecx
  __int64 v44; // [rsp+0h] [rbp-50h] BYREF
  __int64 v45; // [rsp+8h] [rbp-48h]
  int v46; // [rsp+14h] [rbp-3Ch] BYREF
  char *v47; // [rsp+18h] [rbp-38h]
  __int64 v48; // [rsp+20h] [rbp-30h]

  v1 = this; /*0x1039db305*/
  RakNet::ReliabilityLayer::ClearPacketsAndDatagrams(this); /*0x1039db308*/
  RakNet::ReliabilityLayer::FreeAllPacketFragmentsInChannels(this: v1); /*0x1039db310*/
  v48 = (__int64)v1 + 16; /*0x1039db319*/
  while ( 1 ) /*0x1039db32e*/
  {
    v2 = *((_DWORD *)v1 + 6); /*0x1039db32e*/
    v3 = *((_DWORD *)v1 + 7); /*0x1039db334*/
    v4 = v3 < v2; /*0x1039db336*/
    v5 = v3 - v2; /*0x1039db336*/
    if ( v4 ) /*0x1039db338*/
      v5 = *((_DWORD *)v1 + 8) + *((_DWORD *)v1 + 7) - v2; /*0x1039db33f*/
    if ( v5 == 0 ) /*0x1039db343*/
      break; /*0x1039db343*/
    v6 = v2 + 1; /*0x1039db345*/
    v7 = *((_DWORD *)v1 + 8); /*0x1039db347*/
    if ( v6 == v7 ) /*0x1039db34c*/
      v6 = 0; /*0x1039db34c*/
    *((_DWORD *)v1 + 6) = v6; /*0x1039db350*/
    if ( v6 == 0 ) /*0x1039db359*/
      v6 = v7; /*0x1039db359*/
    v8 = *(_QWORD **)(*((_QWORD *)v1 + 2) + 8LL * (v6 - 1)); /*0x1039db35e*/
    v9 = v8[33]; /*0x1039db362*/
    if ( v9 != 0 ) /*0x1039db36c*/
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039db378*/
        v10 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039db37a*/
      else
        v10 = nullptr; /*0x1039db380*/
      RBX::Network::NetworkTracer::removeTracerObject(this: v10, a2: v9); /*0x1039db382*/
      v8[33] = 0; /*0x1039db387*/
    }
    RakNet::ReliabilityLayer::FreeInternalPacketData(a1: v1, a2: v8, a3: "", a4: 0); /*0x1039db39d*/
    DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: (__int64)v1 + 144, a2: v8); /*0x1039db3ad*/
  }
  v11 = 0; /*0x1039db3be*/
  DataStructures::Queue<RakNet::InternalPacket *>::ClearAndForceAllocation(a1: v48, a2: 32); /*0x1039db3cf*/
  v47 = (char *)v1 + 1952; /*0x1039db3db*/
  v45 = (__int64)v1 + 144; /*0x1039db3df*/
  do /*0x1039db48c*/
  {
    v48 = v11; /*0x1039db3e3*/
    v12 = &v47[24 * v11]; /*0x1039db3ef*/
    v13 = (__int64)v1; /*0x1039db3f9*/
    if ( *((_DWORD *)v12 + 2) != 0 ) /*0x1039db3fc*/
    {
      v14 = 8; /*0x1039db3fe*/
      v15 = 0; /*0x1039db404*/
      do /*0x1039db440*/
      {
        RakNet::ReliabilityLayer::FreeInternalPacketData(a1: v13, a2: *(_QWORD *)(*(_QWORD *)v12 + v14), a3: "", a4: 0); /*0x1039db416*/
        DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: v45, a2: *(_QWORD **)(*(_QWORD *)v12 + v14)); /*0x1039db42c*/
        ++v15; /*0x1039db431*/
        v14 += 16; /*0x1039db439*/
      }
      while ( v15 < *((unsigned int *)v12 + 2) ); /*0x1039db440*/
    }
    v16 = *((_DWORD *)v12 + 3); /*0x1039db442*/
    v1 = (RakNet::ReliabilityLayer *)v13; /*0x1039db449*/
    v17 = v45; /*0x1039db44c*/
    if ( v16 != 0 ) /*0x1039db450*/
    {
      if ( v16 >= 0x201 ) /*0x1039db457*/
      {
        if ( *(_QWORD *)v12 != 0 ) /*0x1039db460*/
          operator delete[](a1: *(void **)v12); /*0x1039db462*/
        *((_DWORD *)v12 + 3) = 0; /*0x1039db467*/
        *(_QWORD *)v12 = 0; /*0x1039db470*/
      }
      *((_DWORD *)v12 + 2) = 0; /*0x1039db478*/
    }
    v11 = v48 + 1; /*0x1039db485*/
  }
  while ( v48 != 31 ); /*0x1039db48c*/
  v18 = (__int64)(*(_QWORD *)(v13 + 184) - *(_QWORD *)(v13 + 176)) >> 3; /*0x1039db4a7*/
  v48 = v13; /*0x1039db4ab*/
  v44 = 0; /*0x1039db4b5*/
  std::vector<RakNet::InternalPacket *>::assign(a1: v13 + 176, a2: v18, a3: &v44); /*0x1039db4b8*/
  *(_DWORD *)(v48 + 872) = 0; /*0x1039db4c1*/
  *(_QWORD *)(v48 + 880) = 0; /*0x1039db4cf*/
  v19 = v48; /*0x1039db4d6*/
  v20 = *(_QWORD **)(v48 + 200); /*0x1039db4da*/
  if ( v20 != nullptr ) /*0x1039db4e4*/
  {
    v21 = v17; /*0x1039db4e6*/
    do /*0x1039db532*/
    {
      if ( v20[8] != 0 ) /*0x1039db4f6*/
        RakNet::ReliabilityLayer::FreeInternalPacketData(a1: v19, a2: v20, a3: "", a4: 0); /*0x1039db503*/
      v22 = (_QWORD *)v20[14]; /*0x1039db508*/
      v23 = *(_QWORD **)(v48 + 200); /*0x1039db511*/
      DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: v21, a2: v20); /*0x1039db523*/
      v20 = v22; /*0x1039db528*/
      v24 = v22 == v23; /*0x1039db52b*/
      v19 = v48; /*0x1039db52e*/
    }
    while ( !v24 ); /*0x1039db532*/
    *(_QWORD *)(v48 + 200) = 0; /*0x1039db534*/
    v17 = v21; /*0x1039db53f*/
  }
  if ( DFFlag::GameLoadDataStatistics == 1 ) /*0x1039db549*/
  {
    v25 = v17; /*0x1039db54f*/
    v47 = (char *)(v19 + 216); /*0x1039db559*/
    v26 = *(_QWORD **)(v19 + 216); /*0x1039db55d*/
    v27 = (_QWORD *)(v19 + 224); /*0x1039db564*/
    if ( v26 != (_QWORD *)(v19 + 224) ) /*0x1039db56e*/
    {
      do /*0x1039db5b0*/
      {
        DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: v25, a2: (_QWORD *)v26[5]); /*0x1039db583*/
        v28 = (_QWORD *)v26[1]; /*0x1039db588*/
        if ( v28 != nullptr ) /*0x1039db58f*/
        {
          do /*0x1039db59a*/
          {
            v29 = v28; /*0x1039db591*/
            v28 = (_QWORD *)*v28; /*0x1039db594*/
          }
          while ( v28 != nullptr ); /*0x1039db59a*/
        }
        else
        {
          do /*0x1039db5a8*/
          {
            v29 = (_QWORD *)v26[2]; /*0x1039db59e*/
            v24 = *v29 == (_QWORD)v26; /*0x1039db5a2*/
            v26 = v29; /*0x1039db5a5*/
          }
          while ( !v24 ); /*0x1039db5a8*/
        }
        v26 = v29; /*0x1039db5aa*/
      }
      while ( v29 != v27 ); /*0x1039db5b0*/
    }
    std::__tree<std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>,std::__map_value_compare<RakNet::uint24_t,std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>,std::less<RakNet::uint24_t>,true>,std::allocator<std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>>>::destroy( /*0x1039db5bd*/
      a1: v47,
      a2: *(_QWORD *)(v19 + 224));
    *(_QWORD *)(v19 + 216) = v27; /*0x1039db5c2*/
    *(_OWORD *)(v19 + 224) = 0; /*0x1039db5cc*/
    *(_QWORD *)(v19 + 240) = 0; /*0x1039db5d3*/
    v17 = v25; /*0x1039db5de*/
  }
  *(_DWORD *)(v19 + 3040) = 0; /*0x1039db5e1*/
  if ( *(_DWORD *)(v19 + 360) != 0 ) /*0x1039db5f2*/
  {
    v30 = 8; /*0x1039db5f4*/
    v31 = 0; /*0x1039db5fa*/
    do /*0x1039db64b*/
    {
      v32 = *(_QWORD **)(*(_QWORD *)(v19 + 352) + v30); /*0x1039db60b*/
      if ( v32[8] != 0 ) /*0x1039db614*/
      {
        RakNet::ReliabilityLayer::FreeInternalPacketData(a1: v19, a2: v32, a3: "", a4: 0); /*0x1039db61e*/
        v32 = *(_QWORD **)(*(_QWORD *)(v19 + 352) + v30); /*0x1039db62a*/
      }
      DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: v17, a2: v32); /*0x1039db636*/
      ++v31; /*0x1039db63b*/
      v30 += 16; /*0x1039db644*/
    }
    while ( v31 < *(unsigned int *)(v19 + 360) ); /*0x1039db64b*/
  }
  v33 = *(_DWORD *)(v19 + 364); /*0x1039db64d*/
  if ( v33 != 0 ) /*0x1039db655*/
  {
    if ( v33 >= 0x201 ) /*0x1039db65c*/
    {
      v34 = *(void **)(v19 + 352); /*0x1039db65e*/
      if ( v34 != nullptr ) /*0x1039db668*/
        operator delete[](a1: v34); /*0x1039db66a*/
      *(_DWORD *)(v19 + 364) = 0; /*0x1039db66f*/
      *(_QWORD *)(v19 + 352) = 0; /*0x1039db679*/
    }
    *(_DWORD *)(v19 + 360) = 0; /*0x1039db684*/
  }
  if ( *(_DWORD *)(v19 + 132) != 0 ) /*0x1039db695*/
  {
    v35 = (void **)(v19 + 120); /*0x1039db697*/
    if ( *v35 != nullptr ) /*0x1039db6a1*/
      operator delete[](a1: *v35); /*0x1039db6a3*/
    *(_OWORD *)v35 = 0; /*0x1039db6ab*/
    v19 = v48; /*0x1039db6ae*/
  }
  v36 = (void **)(v19 + 3048); /*0x1039db6b2*/
  if ( *(_DWORD *)(v19 + 3060) != 0 ) /*0x1039db6c0*/
  {
    if ( *v36 != nullptr ) /*0x1039db6c8*/
      operator delete[](a1: *v36); /*0x1039db6ca*/
    *(_OWORD *)v36 = 0; /*0x1039db6d2*/
  }
  DataStructures::List<RakNet::InternalPacket *>::Preallocate(a1: v19 + 3048, a2: 0x200u); /*0x1039db6e7*/
  v37 = (void **)(v19 + 3064); /*0x1039db6ec*/
  if ( *(_DWORD *)(v19 + 3076) != 0 ) /*0x1039db6fa*/
  {
    if ( *v37 != nullptr ) /*0x1039db702*/
      operator delete[](a1: *v37); /*0x1039db704*/
    *(_OWORD *)v37 = 0; /*0x1039db70c*/
  }
  DataStructures::List<bool>::Preallocate(a1: v19 + 3064, a2: 0x200u); /*0x1039db721*/
  v38 = (void **)(v19 + 3080); /*0x1039db726*/
  if ( *(_DWORD *)(v19 + 3092) != 0 ) /*0x1039db734*/
  {
    if ( *v38 != nullptr ) /*0x1039db73c*/
      operator delete[](a1: *v38); /*0x1039db73e*/
    *(_OWORD *)v38 = 0; /*0x1039db746*/
  }
  DataStructures::List<unsigned int>::Preallocate(a1: v19 + 3080, a2: 0x80u); /*0x1039db75b*/
  v39 = (void **)(v19 + 3096); /*0x1039db760*/
  if ( *(_DWORD *)(v19 + 3108) != 0 ) /*0x1039db76e*/
  {
    if ( *v39 != nullptr ) /*0x1039db776*/
      operator delete[](a1: *v39); /*0x1039db778*/
    *(_OWORD *)v39 = 0; /*0x1039db780*/
  }
  DataStructures::List<unsigned int>::Preallocate(a1: v19 + 3096, a2: 0x80u); /*0x1039db798*/
  DataStructures::MemoryPool<RakNet::InternalPacket>::Clear(a1: v17, a2: ""); /*0x1039db7a5*/
  DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Clear(a1: v19 + 3200, a2: ""); /*0x1039db7b6*/
  v40 = *(_DWORD *)(v19 + 64); /*0x1039db7bb*/
  while ( 1 ) /*0x1039db7c5*/
  {
    v41 = *(_DWORD *)(v19 + 68); /*0x1039db7c5*/
    v4 = v41 < v40; /*0x1039db7c7*/
    v42 = v41 - v40; /*0x1039db7c7*/
    if ( v4 ) /*0x1039db7c9*/
      v42 = *(_DWORD *)(v19 + 72) + *(_DWORD *)(v19 + 68) - v40; /*0x1039db7d0*/
    if ( v42 == 0 ) /*0x1039db7d4*/
      break; /*0x1039db7d4*/
    v46 = *(_DWORD *)(v19 + 136); /*0x1039db7dc*/
    RakNet::ReliabilityLayer::RemoveFromDatagramHistory(a1: v19, a2: &v46); /*0x1039db7e5*/
    v40 = 0; /*0x1039db7ef*/
    if ( *(_DWORD *)(v19 + 64) + 1 != *(_DWORD *)(v19 + 72) ) /*0x1039db7f4*/
      v40 = *(_DWORD *)(v19 + 64) + 1; /*0x1039db7f6*/
    v43 = *(_DWORD *)(v19 + 136); /*0x1039db7f8*/
    *(_DWORD *)(v19 + 64) = v40; /*0x1039db7fe*/
    *(_DWORD *)(v19 + 136) = (v43 + 1) & 0xFFFFFF; /*0x1039db809*/
  }
  DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Clear(a1: v19 + 80, a2: ""); /*0x1039db823*/
  *(_DWORD *)(v19 + 136) = 0; /*0x1039db828*/
  *(_DWORD *)(v19 + 112) = 0; /*0x1039db82f*/
  DataStructures::RangeList<RakNet::uint24_t>::Clear(a1: (__int64 *)(v19 + 3160)); /*0x1039db83a*/
  DataStructures::RangeList<RakNet::uint24_t>::Clear(a1: (__int64 *)(v19 + 3176)); /*0x1039db846*/
  *(_QWORD *)(v19 + 208) = 0; /*0x1039db84b*/
}

// Address: 0x1039db866 | Name: __ZN6RakNet16ReliabilityLayer32FreeAllPacketFragmentsInChannelsEv
unsigned __int64 __fastcall RakNet::ReliabilityLayer::FreeAllPacketFragmentsInChannels(RakNet::ReliabilityLayer *this)
{
  unsigned __int64 result; // rax
  unsigned __int64 v3; // r13
  _QWORD *v4; // rax
  __int64 v5; // r12
  int v6; // r14d
  unsigned __int64 v7; // r15
  __int64 v8; // rcx
  __int64 v9; // rsi
  __int64 v10; // rcx
  __int64 v11; // rax
  void *v12; // rdi
  char *v13; // [rsp+8h] [rbp-38h]
  void **v14; // [rsp+10h] [rbp-30h]

  result = (unsigned __int64)this + 408; /*0x1039db87a*/
  v14 = (void **)((char *)this + 408); /*0x1039db881*/
  if ( *((_DWORD *)this + 104) != 0 ) /*0x1039db88c*/
  {
    v13 = (char *)this + 144; /*0x1039db899*/
    v3 = 0; /*0x1039db89d*/
    do /*0x1039db985*/
    {
      v4 = *v14; /*0x1039db8a4*/
      v5 = *((_QWORD *)*v14 + v3); /*0x1039db8a7*/
      v6 = *(_DWORD *)(v5 + 32); /*0x1039db8ab*/
      if ( *(_DWORD *)(v5 + 36) != 0 && v6 > 0 ) /*0x1039db8bc*/
      {
        v7 = 0; /*0x1039db8ca*/
        do /*0x1039db957*/
        {
          v8 = *(_QWORD *)(v5 + 8); /*0x1039db8cd*/
          if ( (*(_QWORD *)(v5 + 16) - v8) >> 3 <= v7 ) /*0x1039db8e1*/
LABEL_19:
            std::vector<RakNet::InternalPacket *>::__throw_out_of_range[abi:ne200100](); /*0x1039db9be*/
          v9 = *(_QWORD *)(v8 + 8 * v7); /*0x1039db8e7*/
          if ( v9 != 0 ) /*0x1039db8ee*/
          {
            RakNet::ReliabilityLayer::FreeInternalPacketData(a1: this, a2: v9, a3: "", a4: 0); /*0x1039db8ff*/
            v10 = *(_QWORD *)(*((_QWORD *)this + 51) + 8 * v3); /*0x1039db90b*/
            v11 = *(_QWORD *)(v10 + 8); /*0x1039db90f*/
            if ( (*(_QWORD *)(v10 + 16) - v11) >> 3 <= v7 ) /*0x1039db921*/
              goto LABEL_19; /*0x1039db921*/
            --v6; /*0x1039db927*/
            DataStructures::MemoryPool<RakNet::InternalPacket>::Release( /*0x1039db937*/
              a1: (__int64)v13,
              a2: *(_QWORD **)(v11 + 8 * v7));
            v4 = *v14; /*0x1039db940*/
          }
          ++v7; /*0x1039db943*/
          v5 = v4[v3]; /*0x1039db946*/
        }
        while ( v7 < *(unsigned int *)(v5 + 36) && v6 > 0 ); /*0x1039db957*/
      }
      v12 = *(void **)(v5 + 8); /*0x1039db95d*/
      if ( v12 != nullptr ) /*0x1039db965*/
      {
        *(_QWORD *)(v5 + 16) = v12; /*0x1039db967*/
        operator delete(a1: v12); /*0x1039db96c*/
      }
      operator delete(a1: (void *)v5); /*0x1039db974*/
      ++v3; /*0x1039db979*/
      result = *((unsigned int *)this + 104); /*0x1039db97c*/
    }
    while ( v3 < result ); /*0x1039db985*/
  }
  if ( *((_DWORD *)this + 105) != 0 ) /*0x1039db992*/
  {
    if ( *v14 != nullptr ) /*0x1039db99e*/
      operator delete[](a1: *v14); /*0x1039db9a0*/
    result = (unsigned __int64)v14; /*0x1039db9a8*/
    *(_OWORD *)v14 = 0; /*0x1039db9ac*/
  }
  return result; /*0x1039db9af*/
}

// Address: 0x1039db9c4 | Name: __ZN6RakNet16ReliabilityLayer22FreeInternalPacketDataEPNS_14InternalPacketEPKcj
void __fastcall RakNet::ReliabilityLayer::FreeInternalPacketData(__int64 a1, __int64 a2)
{
  void *v4; // rsi
  RBX::Network::NetworkTracer *v5; // rdi
  int v6; // eax
  __int64 v7; // rax
  _QWORD **v9; // rbx
  _QWORD *v10; // rsi
  RBX::Memory *v11; // rdi

  if ( a2 != 0 ) /*0x1039db9c7*/
  {
    v4 = *(void **)(a2 + 264); /*0x1039db9e4*/
    if ( v4 != nullptr && RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039db9fa*/
    {
      v5 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039db9fc*/
      if ( v5 != nullptr ) /*0x1039dba03*/
        RBX::Network::NetworkTracer::removeTracerObject(this: v5, a2: (unsigned __int64)v4); /*0x1039dba05*/
    }
    v6 = *(_DWORD *)(a2 + 72); /*0x1039dba0a*/
    if ( v6 == 0 ) /*0x1039dba0f*/
    {
      v11 = *(RBX::Memory **)(a2 + 64); /*0x1039dba51*/
      if ( v11 == nullptr ) /*0x1039dba58*/
        return; /*0x1039dba58*/
      v9 = (_QWORD **)(a2 + 64); /*0x1039dba5a*/
      RBX::Memory::deallocate(this: v11, a2: v4); /*0x1039dba5e*/
      goto LABEL_14; /*0x1039dba63*/
    }
    if ( v6 != 1 ) /*0x1039dba14*/
    {
      v9 = (_QWORD **)(a2 + 64); /*0x1039dba65*/
      goto LABEL_14; /*0x1039dba65*/
    }
    v7 = *(_QWORD *)(a2 + 80); /*0x1039dba16*/
    if ( v7 != 0 && (*(_DWORD *)(v7 + 8))-- == 1 ) /*0x1039dba1f*/
    {
      v9 = (_QWORD **)(a2 + 80); /*0x1039dba24*/
      RBX::Memory::deallocate(this: *(RBX::Memory **)v7, a2: v4); /*0x1039dba2b*/
      v10 = *v9; /*0x1039dba30*/
      *v10 = 0; /*0x1039dba33*/
      DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Release(a1: a1 + 3200, a2: v10); /*0x1039dba4a*/
LABEL_14:
      *v9 = nullptr; /*0x1039dba69*/
    }
  }
}

// Address: 0x1039dba7a | Name: __ZN6RakNet16ReliabilityLayer27ReleaseToInternalPacketPoolEPNS_14InternalPacketE
unsigned __int64 __fastcall RakNet::ReliabilityLayer::ReleaseToInternalPacketPool(__int64 a1, _QWORD *a2)
{
  return DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: a1 + 144, a2); /*0x1039dba8e*/
}

// Address: 0x1039dba94 | Name: __ZN6RakNet16ReliabilityLayer24ClearPacketsAndDatagramsEv
void __fastcall RakNet::ReliabilityLayer::ClearPacketsAndDatagrams(RakNet::ReliabilityLayer *this)
{
  unsigned int v2; // eax
  unsigned __int64 v3; // r12
  int v4; // r13d
  __int64 v5; // rax
  __int64 v6; // rcx
  unsigned int v7; // edx
  __int64 v8; // rdx
  __int64 v9; // rsi
  __int64 v10; // rdx
  bool v11; // zf
  __int64 v12; // rcx
  unsigned int v13; // eax
  void *v14; // rdi

  v2 = *((_DWORD *)this + 768); /*0x1039dbaa5*/
  if ( v2 != 0 ) /*0x1039dbaad*/
  {
    v3 = 0; /*0x1039dbaba*/
    v4 = 35; /*0x1039dbac4*/
    do /*0x1039dbb73*/
    {
      if ( *(_BYTE *)(*((_QWORD *)this + 383) + v3) == 1 ) /*0x1039dbad6*/
      {
        v5 = *((_QWORD *)this + 381); /*0x1039dbadc*/
        v6 = *(_QWORD *)(v5 + 8 * v3); /*0x1039dbae3*/
        v7 = *(_DWORD *)(v6 + 28); /*0x1039dbae7*/
        if ( v7 <= 5 && _bittest(&v4, v7) ) /*0x1039dbaef*/
        {
          v8 = *(_QWORD *)(v6 + 120); /*0x1039dbaf5*/
          v9 = *(_QWORD *)(v6 + 128); /*0x1039dbaf9*/
          *(_QWORD *)(v8 + 128) = v9; /*0x1039dbb00*/
          *(_QWORD *)(v9 + 120) = v8; /*0x1039dbb07*/
          v10 = *((_QWORD *)this + 26); /*0x1039dbb0b*/
          v11 = v10 == v6; /*0x1039dbb12*/
          if ( v10 == v6 ) /*0x1039dbb15*/
            v10 = v9; /*0x1039dbb15*/
          if ( v10 == v6 || v11 ) /*0x1039dbb19*/
          {
            v11 = v10 == v6; /*0x1039dbb29*/
            v12 = 0; /*0x1039dbb2c*/
            if ( !v11 ) /*0x1039dbb31*/
              v12 = v10; /*0x1039dbb31*/
            *((_QWORD *)this + 26) = v12; /*0x1039dbb35*/
          }
        }
        RakNet::ReliabilityLayer::FreeInternalPacketData(a1: (__int64)this, a2: *(_QWORD *)(v5 + 8 * v3)); /*0x1039dbb48*/
        DataStructures::MemoryPool<RakNet::InternalPacket>::Release( /*0x1039dbb60*/
          a1: (__int64)this + 144,
          a2: *(_QWORD **)(*((_QWORD *)this + 381) + 8 * v3));
        v2 = *((_DWORD *)this + 768); /*0x1039dbb65*/
      }
      ++v3; /*0x1039dbb6b*/
    }
    while ( v3 < v2 ); /*0x1039dbb73*/
  }
  v13 = *((_DWORD *)this + 769); /*0x1039dbb79*/
  if ( v13 != 0 ) /*0x1039dbb81*/
  {
    if ( v13 >= 0x201 ) /*0x1039dbb88*/
    {
      v14 = *((void **)this + 383); /*0x1039dbb8a*/
      if ( v14 != nullptr ) /*0x1039dbb94*/
        operator delete[](a1: v14); /*0x1039dbb96*/
      *((_DWORD *)this + 769) = 0; /*0x1039dbb9b*/
      *((_QWORD *)this + 383) = 0; /*0x1039dbba5*/
    }
    *((_DWORD *)this + 768) = 0; /*0x1039dbbb0*/
  }
}

// Address: 0x1039dc1e4 | Name: __ZN6RakNet16ReliabilityLayer25RemoveFromDatagramHistoryENS_8uint24_tE
__int64 __fastcall RakNet::ReliabilityLayer::RemoveFromDatagramHistory(__int64 a1, _DWORD *a2)
{
  int v3; // r13d
  unsigned int v4; // eax
  unsigned int v5; // edx
  unsigned int v6; // r8d
  __int64 v7; // rcx
  unsigned int v8; // esi
  _QWORD *v9; // rsi
  _QWORD *v10; // r12
  __int64 result; // rax

  v3 = (*a2 - *(_DWORD *)(a1 + 136)) & 0xFFFFFF; /*0x1039dc1ff*/
  v4 = v3 + *(_DWORD *)(a1 + 64); /*0x1039dc209*/
  v5 = *(_DWORD *)(a1 + 72); /*0x1039dc20c*/
  v6 = 0; /*0x1039dc20f*/
  v7 = *(_QWORD *)(a1 + 56); /*0x1039dc214*/
  v8 = v5; /*0x1039dc218*/
  if ( v4 < v5 ) /*0x1039dc21a*/
    v8 = 0; /*0x1039dc21a*/
  v9 = *(_QWORD **)(v7 + 24LL * (v4 - v8)); /*0x1039dc226*/
  if ( v9 != nullptr ) /*0x1039dc22d*/
  {
    do /*0x1039dc251*/
    {
      v10 = (_QWORD *)v9[1]; /*0x1039dc23a*/
      DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Release(a1: a1 + 80, a2: v9); /*0x1039dc246*/
      v9 = v10; /*0x1039dc24b*/
    }
    while ( v10 != nullptr ); /*0x1039dc251*/
    v5 = *(_DWORD *)(a1 + 72); /*0x1039dc253*/
    v7 = *(_QWORD *)(a1 + 56); /*0x1039dc256*/
    v4 = *(_DWORD *)(a1 + 64) + v3; /*0x1039dc25e*/
    v6 = 0; /*0x1039dc261*/
  }
  if ( v4 >= v5 ) /*0x1039dc266*/
    v6 = v5; /*0x1039dc266*/
  result = 3LL * (v4 - v6); /*0x1039dc26d*/
  *(_QWORD *)(v7 + 8 * result) = 0; /*0x1039dc271*/
  return result; /*0x1039dc27d*/
}

// Address: 0x1039dc3a0 | Name: __ZN6RakNet16ReliabilityLayer38HandleSocketReceiveFromConnectedPlayerEPKcjRKNS_13SystemAddressEiNSt3__110shared_ptrINS_12RakNetSocketEEEyRNS_9BitStreamEbRKNS7_IN3RBX4Rupp4RuppEEES5_i
__int64 __fastcall RakNet::ReliabilityLayer::HandleSocketReceiveFromConnectedPlayer(
        RakNet::ReliabilityLayer *a1,
        unsigned __int8 *a2,
        unsigned int a3,
        RakNet::SystemAddress *a4,
        __int64 a5,
        __int64 *a6,
        unsigned __int64 a7,
        __int64 a8,
        char a9,
        __int64 a10,
        __int64 a11,
        int a12)
{
  RakNet *v16; // rdi
  int v17; // r9d
  char v18; // al
  char v19; // al
  char *v20; // rbx
  char v21; // al
  int v22; // r9d
  __int64 v23; // rcx
  unsigned __int64 v24; // rdx
  __m128i inserted; // xmm0
  RakNet::BPSTracker *v27; // rbx
  std::mutex *v28; // r14
  __int64 v29; // r15
  float v30; // xmm0_4
  __m128i v31; // xmm0
  __int64 BPSAndTotal; // rax
  float v33; // xmm0_4
  __int64 v34; // rcx
  unsigned int v35; // eax
  unsigned int v36; // esi
  char v37; // al
  int v38; // r9d
  unsigned int v39; // r12d
  __int64 v40; // rax
  unsigned int v41; // r14d
  __int64 v42; // rdi
  __int64 v43; // rax
  __int64 v44; // r15
  unsigned int v45; // eax
  __int64 v46; // rcx
  unsigned __int64 v47; // rsi
  unsigned int v48; // edx
  __int64 v49; // r13
  unsigned int v50; // ecx
  unsigned __int64 v51; // rdx
  unsigned __int64 v52; // rdx
  int v53; // eax
  __int64 v54; // rdi
  int v55; // r9d
  int v56; // r15d
  char v57; // al
  int v58; // ecx
  int v59; // r9d
  __int64 *v60; // r13
  __int64 v61; // rax
  unsigned __int64 v62; // rdx
  unsigned int v63; // r15d
  unsigned int v64; // ecx
  unsigned int v65; // eax
  unsigned int v66; // r14d
  __int64 v67; // rbx
  __int64 v68; // r12
  unsigned __int64 v69; // rsi
  _QWORD *v70; // rax
  __int64 MessageNumberNodeByDatagramNumber; // r14
  unsigned __int64 v72; // rbx
  char v73; // al
  unsigned __int64 v74; // rdx
  RakNet::ReliabilityLayer *v75; // rsi
  __int64 v76; // rax
  __int64 v77; // rdi
  double v78; // xmm2_8
  __int64 v79; // r8
  char v80; // al
  RakNet::ReliabilityLayer *v81; // rbx
  _QWORD *InternalPacketFromBitStream; // rax
  int v83; // r9d
  unsigned int v84; // ecx
  int v85; // edx
  _QWORD *v86; // rsi
  int v87; // ecx
  unsigned int v88; // eax
  unsigned int v89; // edx
  int v90; // esi
  unsigned int v91; // eax
  unsigned int v92; // esi
  unsigned int v93; // ecx
  unsigned int v94; // esi
  unsigned int v95; // edi
  __int64 v96; // rcx
  __int64 v97; // rsi
  unsigned int v98; // eax
  unsigned int i; // eax
  int v100; // ecx
  unsigned int v101; // eax
  unsigned int v102; // ecx
  unsigned int v103; // eax
  unsigned int v104; // ecx
  unsigned int v105; // edx
  int v106; // esi
  unsigned int v107; // eax
  int v108; // ecx
  __int64 v109; // rax
  __int64 v110; // rdx
  int v111; // r9d
  unsigned int v112; // ecx
  int v113; // eax
  __int64 v114; // rax
  unsigned int v115; // edx
  unsigned int v116; // edi
  unsigned int v117; // ecx
  unsigned int v118; // edx
  unsigned int v119; // edx
  unsigned int v120; // r8d
  __int64 v121; // rax
  __int64 v122; // rcx
  int v123; // r8d
  RBX::Network *v124; // rdi
  __int64 v125; // rdx
  __int64 v126; // rsi
  __int64 v127; // rax
  char *v128; // rdi
  unsigned __int64 v129; // rdx
  __int64 v130; // rdx
  __int64 v131; // r14
  unsigned __int8 v132; // al
  __int64 v133; // r14
  RakNet *v134; // rdi
  unsigned int TimeMS; // eax
  int v136; // ebx
  _QWORD *v137; // rsi
  __int64 v138; // rdx
  __int64 v139; // rcx
  __m128i v140; // [rsp+10h] [rbp-620h] BYREF
  __int64 v141; // [rsp+20h] [rbp-610h]
  RakNet::BPSTracker *v142; // [rsp+28h] [rbp-608h]
  unsigned int v143; // [rsp+34h] [rbp-5FCh] BYREF
  RBX::Network *v144; // [rsp+38h] [rbp-5F8h]
  __int64 v145; // [rsp+40h] [rbp-5F0h] BYREF
  __int64 *v146; // [rsp+48h] [rbp-5E8h]
  char v147; // [rsp+50h] [rbp-5E0h]
  char v148; // [rsp+51h] [rbp-5DFh]
  unsigned __int8 v149; // [rsp+52h] [rbp-5DEh]
  unsigned __int8 v150; // [rsp+53h] [rbp-5DDh]
  char v151; // [rsp+54h] [rbp-5DCh]
  char v152; // [rsp+55h] [rbp-5DBh]
  char v153; // [rsp+56h] [rbp-5DAh]
  unsigned __int16 v154; // [rsp+58h] [rbp-5D8h]
  __int16 v155; // [rsp+5Ah] [rbp-5D6h]
  __m128i *v156; // [rsp+60h] [rbp-5D0h]
  _QWORD *v157; // [rsp+68h] [rbp-5C8h]
  unsigned __int64 v158; // [rsp+70h] [rbp-5C0h]
  unsigned __int64 v159; // [rsp+78h] [rbp-5B8h]
  __int128 v160; // [rsp+80h] [rbp-5B0h] BYREF
  void *v161; // [rsp+90h] [rbp-5A0h]
  unsigned int v162; // [rsp+A4h] [rbp-58Ch] BYREF
  RakNet::ReliabilityLayer *v163; // [rsp+A8h] [rbp-588h]
  unsigned int v164; // [rsp+B4h] [rbp-57Ch]
  _QWORD *v165; // [rsp+B8h] [rbp-578h] BYREF
  __int64 v166; // [rsp+C0h] [rbp-570h] BYREF
  unsigned int v167; // [rsp+CCh] [rbp-564h]
  __int64 v168; // [rsp+D0h] [rbp-560h]
  char v169[1040]; // [rsp+1F0h] [rbp-440h] BYREF

  v156 = (__m128i *)a6; /*0x1039dc3b4*/
  if ( (_BYTE)DFLog::NetworkTrace != 0 ) /*0x1039dc3df*/
    RakNet::SystemAddress::ToStringN(this: a4, a2: true, a3: v169, a4: 1025, a5: 124); /*0x1039dc3fb*/
  *((_QWORD *)a1 + 114) += a3; /*0x1039dc407*/
  RakNet::BPSTracker::Push1(this: (RakNet::ReliabilityLayer *)((char *)a1 + 3856), a2: a7, a3); /*0x1039dc418*/
  if ( a9 != 0 ) /*0x1039dc421*/
    *((_QWORD *)a1 + 155) = _mm_add_epi32( /*0x1039dc440*/
                              _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), a3, 0),
                              _mm_loadl_epi64((const __m128i *)((char *)a1 + 1240))).u64[0];
  if ( a3 < 3 || a2 == nullptr )
  {
    if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
      FLog::FastLogFormatted(
        a1: DFLog::NetworkTrace,
        a2: qword_10D7BB068,
        a3: (unsigned int)"[DFLog::NetworkTrace] Incoming packet error: length <= 2 || buffer == 0, length=%d, address=%s",
        a4: 8 * a3,
        a5: (unsigned int)v169,
        a6: v17);
    v18 = RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 0); /*0x1039dc4a2*/
LABEL_9:
    if ( v18 != 0 ) /*0x1039dc4a9*/
    {
      *((_BYTE *)a1 + 436) = 1; /*0x1039dc4af*/
      *((_DWORD *)a1 + 110) = 303; /*0x1039dc4b7*/
    }
    goto LABEL_22; /*0x1039dc4c2*/
  }
  *((_DWORD *)a1 + 62) = RakNet::GetTimeMS(this: v16); /*0x1039dc4cc*/
  if ( *(_QWORD *)a1 != 0
    && (unsigned __int8)RBX::Security::SessionCrypto::getEnabledForRaknet(this: *(RBX::Security::SessionCrypto **)a1) != 0 )
  {
    v19 = RBX::Security::SessionCrypto::decryptRakDataInPlace(a1: *(_QWORD *)a1, a2, a3); /*0x1039dc4f5*/
    v163 = a1; /*0x1039dc4fc*/
    if ( v19 == 0 )
    {
      *((_DWORD *)a1 + 65) = *((_DWORD *)a1 + 62); /*0x1039dc67e*/
      *(__m128i *)((char *)a1 + 264) = _mm_sub_epi64( /*0x1039dc696*/
                                         _mm_loadu_si128((const __m128i *)((char *)a1 + 264)),
                                         (__m128i)-1LL);
      v27 = (RakNet::ReliabilityLayer *)((char *)a1 + 3960); /*0x1039dc69f*/
      RakNet::BPSTracker::Push1(this: (RakNet::ReliabilityLayer *)((char *)a1 + 3960), a2: a7, a3); /*0x1039dc6b0*/
      if ( *((_QWORD *)a1 + 34) > (unsigned __int64)DFInt::DecryptionFailDisconnectThreshold )
      {
        v28 = (RakNet::ReliabilityLayer *)((char *)a1 + 3872); /*0x1039dc6cc*/
        std::mutex::lock(this: (RakNet::ReliabilityLayer *)((char *)a1 + 3872)); /*0x1039dc6d6*/
        v29 = *((_QWORD *)a1 + 483); /*0x1039dc6db*/
        std::mutex::unlock(this: v28); /*0x1039dc6e5*/
        if ( v29 != 0 ) /*0x1039dc6ed*/
        {
          if ( v29 < 0 ) /*0x1039dc6ef*/
            v30 = (float)(int)(((unsigned __int64)v29 >> 1) | v29 & 1) /*0x1039dc71d*/
                + (float)(int)(((unsigned __int64)v29 >> 1) | v29 & 1);
          else
            v30 = (float)(int)v29; /*0x1039dc6f4*/
          *(float *)&v156 = v30; /*0x1039dc721*/
          BPSAndTotal = RakNet::BPSTracker::GetBPSAndTotal(this: v27); /*0x1039dc72c*/
          a1 = v163; /*0x1039dc731*/
          v31 = 0; /*0x1039dc73d*/
          if ( BPSAndTotal < 0 ) /*0x1039dc73b*/
            v33 = (float)(int)(((unsigned __int64)BPSAndTotal >> 1) | BPSAndTotal & 1) /*0x1039dc75b*/
                + (float)(int)(((unsigned __int64)BPSAndTotal >> 1) | BPSAndTotal & 1);
          else
            v33 = (float)(int)BPSAndTotal; /*0x1039dc740*/
          *(float *)v31.i32 = v33 / *(float *)&v156; /*0x1039dc75f*/
        }
        else
        {
          v31 = 0; /*0x1039dc6fb*/
          a1 = v163; /*0x1039dc6ff*/
        }
        if ( (unsigned __int8)DFLog::RakNetMissingPingPong >= 6u && BYTE1(DFLog::RakNetMissingPingPong) >= 6u )
        {
          LODWORD(v163) = v31.i32[0]; /*0x1039dc78b*/
          v34 = *((_QWORD *)a1 + 34); /*0x1039dc797*/
          v166 = (unsigned int)_mm_cvtsi128_si32(v31); /*0x1039dc7a5*/
          v168 = v34; /*0x1039dc7a8*/
          v145 = 73; /*0x1039dc7ac*/
          v146 = &v166; /*0x1039dc7b7*/
          FLog::detail::FastLogSafeFormattedInternal(
            a1: DFLog::RakNetMissingPingPong,
            a2: qword_10D7BB088,
            a3: 6,
            a4: (unsigned int)"[DFLog::RakNetMissingPingPong] Decryption failure rate: {}, failed to decrypt last {} packets",
            a5: 93,
            a6: 1,
            73,
            &v166);
          v31.i32[0] = (int)v163; /*0x1039dc7e8*/
        }
        *((_BYTE *)a1 + 436) = 1; /*0x1039dc7f3*/
        *((_DWORD *)a1 + 110) = 303; /*0x1039dc7fb*/
        RakNet::ReliabilityLayer::reportDecryptionFailure( /*0x1039dc818*/
          this: a1,
          a2: a4,
          a3: (int)(float)(*(float *)v31.i32 * 100.0),
          a4: a12);
      }
      v18 = RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 2); /*0x1039dc829*/
      goto LABEL_9; /*0x1039dc82e*/
    }
    v164 = a3 - 18; /*0x1039dc517*/
    RakNet::BitStream::BitStream(this: (RakNet::BitStream *)&v166, a2, a3: a3 - 18, a4: false); /*0x1039dc523*/
    v20 = *((char **)a1 + 514); /*0x1039dc528*/
    v155 = 0; /*0x1039dc52f*/
    v21 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)a1 + 379) + 232LL))(a1: *((_QWORD *)a1 + 379)); /*0x1039dc542*/
    RakNet::DatagramHeaderFormat::Deserialize( /*0x1039dc57a*/
      this: (RakNet::DatagramHeaderFormat *)&v145,
      a2: (RakNet::BitStream *)&v166,
      a3: v21,
      a4: (*((_DWORD *)a1 + 1028) & 0x200000) != 0,
      a5: (*((_DWORD *)a1 + 1028) & 0x800000) != 0,
      a6: (char)v20 >= 0);
    v23 = *((_QWORD *)a1 + 514); /*0x1039dc57f*/
    if ( (v23 & 0x200000) != 0 && (_BYTE)v155 == 1 ) /*0x1039dc597*/
    {
      v24 = a7 / 0x3E8; /*0x1039dc5b2*/
      if ( *((_DWORD *)a1 + 320) == 0 ) /*0x1039dc5be*/
        *((_DWORD *)a1 + 320) = v24; /*0x1039dc5c0*/
      *((_DWORD *)a1 + 321) = v24; /*0x1039dc5c7*/
      inserted = _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v164, 0); /*0x1039dc5d7*/
      *((_QWORD *)a1 + 157) = _mm_add_epi32(_mm_loadl_epi64((const __m128i *)((char *)a1 + 1256)), inserted).u64[0]; /*0x1039dc5ee*/
      if ( (v23 & 0x800000) != 0 ) /*0x1039dc5fb*/
      {
        if ( HIBYTE(v155) == 1 ) /*0x1039dc608*/
          *((_QWORD *)a1 + 158) = _mm_add_epi32(_mm_loadl_epi64((const __m128i *)a1 + 79), inserted).u64[0]; /*0x1039dc61b*/
        else
          *((_DWORD *)a1 + 322) = v24; /*0x1039dc833*/
      }
    }
    if ( (char)v20 >= 0 ) /*0x1039dc83c*/
    {
      if ( DFFlag::RakNetValidateExtraPadding != 0 ) /*0x1039dc845*/
      {
        v35 = 8 * v154; /*0x1039dc84e*/
        v36 = v167; /*0x1039dc851*/
        if ( v35 > v167 ) /*0x1039dc859*/
        {
          v37 = RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 5); /*0x1039dc867*/
LABEL_125:
          if ( v37 != 0 ) /*0x1039dd131*/
          {
            *((_BYTE *)a1 + 436) = 1; /*0x1039dd137*/
            *((_DWORD *)a1 + 110) = 303; /*0x1039dd13f*/
          }
LABEL_265:
          LODWORD(v20) = 0; /*0x1039ddd17*/
          goto LABEL_266; /*0x1039ddd17*/
        }
      }
      else
      {
        v36 = v167; /*0x1039dc871*/
        v35 = 8 * v154; /*0x1039dc87e*/
      }
      RakNet::BitStream::SetWriteOffset(this: (RakNet::BitStream *)&v166, a2: v36 - v35, a3: false); /*0x1039dc88c*/
      v164 -= v154; /*0x1039dc898*/
    }
    if ( v152 == 0 )
    {
      if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
        FLog::FastLogFormatted(
          a1: DFLog::NetworkTrace,
          a2: qword_10D7BB068,
          a3: (unsigned int)"[DFLog::NetworkTrace] Incoming packet error: dhf.isValid==false, length=%d, address=%s",
          a4: 8 * v164,
          a5: (unsigned int)v169,
          a6: v22);
      *((_DWORD *)a1 + 76) = *((_DWORD *)a1 + 62); /*0x1039dc985*/
      v37 = RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 5); /*0x1039dc998*/
      goto LABEL_125; /*0x1039dc99d*/
    }
    if ( v147 == 1 )
    {
      *((_QWORD *)a1 + 42) = a7; /*0x1039dc8bc*/
      if ( (*(unsigned __int8 (__fastcall **)(_QWORD))(**((_QWORD **)a1 + 379) + 232LL))(a1: *((_QWORD *)a1 + 379)) != 0 ) /*0x1039dc8d5*/
      {
        v159 = (unsigned int)a7 - v145; /*0x1039dc8e8*/
        if ( v159 >= 0x989681 ) /*0x1039dc8f5*/
          v159 = (unsigned int)(int)(*(double (__fastcall **)(_QWORD))(**((_QWORD **)a1 + 379) + 208LL))(a1: *((_QWORD *)a1 + 379)); /*0x1039dc92a*/
      }
      else
      {
        v159 = 0; /*0x1039dcc7e*/
      }
      LODWORD(v20) = (_DWORD)a1 + 3144; /*0x1039dcc89*/
      DataStructures::RangeList<RakNet::uint24_t>::Clear(a1: (__int64 *)a1 + 393); /*0x1039dcc93*/
      if ( DataStructures::RangeList<RakNet::uint24_t>::Deserialize(a1: (__int64)a1 + 3144, a2: (__int64)&v166) == 0 )
      {
        if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
          FLog::FastLogFormatted(
            a1: DFLog::NetworkTrace,
            a2: qword_10D7BB068,
            a3: (unsigned int)"[DFLog::NetworkTrace] Incoming packet error: incomingAcks.Deserialize failed, length=%d, address=%s",
            a4: 8 * v164,
            a5: (unsigned int)v169,
            a6: v59);
        *((_DWORD *)a1 + 77) = *((_DWORD *)a1 + 62); /*0x1039dd03f*/
        v37 = RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 6); /*0x1039dd052*/
        goto LABEL_125; /*0x1039dd057*/
      }
      v162 = 0; /*0x1039dccb1*/
      v143 = 0; /*0x1039dccb7*/
      if ( v153 == 1 ) /*0x1039dccc4*/
      {
        RakNet::BitStream::Read<RakNet::uint24_t>(a1: &v166, a2: &v162); /*0x1039dccd4*/
        RakNet::BitStream::Read<RakNet::uint24_t>(a1: &v166, a2: &v143); /*0x1039dcce7*/
      }
      if ( *((_DWORD *)a1 + 788) != 0 )
      {
        v60 = (__int64 *)((char *)a1 + 120); /*0x1039dccfa*/
        v156 = (__m128i *)((char *)a1 + 144); /*0x1039dcd05*/
        v157 = (_QWORD *)((char *)a1 + 16); /*0x1039dcd10*/
        v61 = *((_QWORD *)a1 + 393); /*0x1039dcd17*/
        LODWORD(v62) = 0; /*0x1039dcd1e*/
        v144 = (RakNet::ReliabilityLayer *)((char *)a1 + 3144); /*0x1039dcd20*/
        while ( 1 ) /*0x1039dcd27*/
        {
          v62 = (unsigned int)v62; /*0x1039dcd27*/
          v63 = *(_DWORD *)(v61 + 8LL * (unsigned int)v62); /*0x1039dcd29*/
          v64 = *(_DWORD *)(v61 + 8LL * (unsigned int)v62 + 4); /*0x1039dcd2d*/
          if ( v63 > v64 ) /*0x1039dcd34*/
            break; /*0x1039dcd34*/
          v158 = (unsigned int)v62; /*0x1039dcd40*/
          if ( v64 == 0xFFFFFF ) /*0x1039dcd47*/
            break; /*0x1039dcd47*/
          do /*0x1039dcfb3*/
          {
            if ( v63 > *(_DWORD *)(v61 + 8 * v62 + 4) ) /*0x1039dcd52*/
              break; /*0x1039dcd52*/
            *(_QWORD *)&v160 = 0; /*0x1039dcd58*/
            v65 = *((_DWORD *)v163 + 32); /*0x1039dcd6a*/
            if ( v65 != 0 ) /*0x1039dcd72*/
            {
              v66 = 0; /*0x1039dcd78*/
              do /*0x1039dce5b*/
              {
                v67 = 16LL * v66; /*0x1039dcd82*/
                if ( *(_DWORD *)(*v60 + v67) == v63 ) /*0x1039dcd8a*/
                {
                  v68 = DataStructures::MemoryPool<RakNet::InternalPacket>::Allocate( /*0x1039dcda5*/
                          a1: v156->i64,
                          a2: (unsigned __int64)"",
                          a3: 0);
                  *(_DWORD *)v68 = 0xFFFFFF; /*0x1039dcda8*/
                  *(_BYTE *)(v68 + 36) = 0; /*0x1039dcdb0*/
                  *(_QWORD *)(v68 + 48) = 0; /*0x1039dcdb5*/
                  *(_DWORD *)(v68 + 20) = 0; /*0x1039dcdba*/
                  *(_QWORD *)(v68 + 64) = 0; /*0x1039dcdbf*/
                  *(_WORD *)(v68 + 88) = 0; /*0x1039dcdc4*/
                  *(_BYTE *)(v68 + 90) = 0; /*0x1039dcdcc*/
                  *(_QWORD *)(v68 + 264) = 0; /*0x1039dcdd1*/
                  v165 = (_QWORD *)v68; /*0x1039dcdd9*/
                  *(_DWORD *)(v68 + 72) = 0; /*0x1039dcde0*/
                  *(_QWORD *)(v68 + 64) = RBX::Memory::allocateOrCrash(this: (RBX::Memory *)5, a2: v69); /*0x1039dcdef*/
                  v70 = v165; /*0x1039dcdf4*/
                  *((_DWORD *)v165 + 6) = 40; /*0x1039dcdfb*/
                  *(_BYTE *)v70[8] = 14; /*0x1039dce06*/
                  *(_DWORD *)(v165[8] + 1LL) = *(_DWORD *)(*v60 + v67 + 4); /*0x1039dce1c*/
                  DataStructures::Queue<RakNet::InternalPacket *>::Push(a1: (__int64)v157, a2: (__int64 *)&v165); /*0x1039dce36*/
                  DataStructures::List<RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode>::RemoveAtIndex( /*0x1039dce41*/
                    a1: v60,
                    a2: v66);
                  v65 = *((_DWORD *)v163 + 32); /*0x1039dce4d*/
                }
                else
                {
                  ++v66; /*0x1039dce55*/
                }
              }
              while ( v66 < v65 ); /*0x1039dce5b*/
            }
            LODWORD(v165) = v63; /*0x1039dce61*/
            MessageNumberNodeByDatagramNumber = RakNet::ReliabilityLayer::GetMessageNumberNodeByDatagramNumber( /*0x1039dce82*/
                                                  a1: v163,
                                                  a2: &v165,
                                                  a3: &v160);
            v72 = v160; /*0x1039dce85*/
            if ( ((unsigned __int64)v160 | MessageNumberNodeByDatagramNumber) != 0 ) /*0x1039dce8f*/
            {
              v73 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v163 + 379) + 232LL))(a1: *((_QWORD *)v163 + 379)); /*0x1039dcea6*/
              v74 = 0; /*0x1039dceb3*/
              if ( a7 >= v72 ) /*0x1039dceb8*/
                v74 = a7 - v72; /*0x1039dceb8*/
              if ( v73 != 0 ) /*0x1039dcebe*/
                v74 = v159; /*0x1039dcebe*/
              v75 = v163; /*0x1039dcec9*/
              if ( v74 != 0 ) /*0x1039dced0*/
              {
                *((_QWORD *)v163 + 363) = v74; /*0x1039dced2*/
                v76 = *((unsigned __int8 *)v75 + 2952); /*0x1039dced9*/
                *((_QWORD *)v75 + v76 + 364) = v74; /*0x1039dcee0*/
                *((_BYTE *)v75 + 2952) = -5 * ((unsigned int)(13108 * (v76 + 1)) >> 16) + v76 + 1; /*0x1039dcefe*/
              }
              v77 = *((_QWORD *)v75 + 379); /*0x1039dcf04*/
              v78 = *((double *)v75 + 390); /*0x1039dcf12*/
              v79 = *((unsigned __int8 *)v75 + 2976); /*0x1039dcf1a*/
              LODWORD(v165) = v63; /*0x1039dcf2d*/
              (*(void (__fastcall **)(__int64, unsigned __int64, unsigned __int64, _QWORD, __int64, _QWORD **, double, double, double))(*(_QWORD *)v77 + 128LL))( /*0x1039dcf46*/
                a1: v77,
                a2: a7,
                a3: v74,
                a4: v149,
                a5: v79,
                a6: &v165,
                a7: 0.0,
                a8: *((float *)&v146 + 1),
                a9: v78);
              if ( MessageNumberNodeByDatagramNumber != 0 ) /*0x1039dcf4f*/
              {
                do /*0x1039dcf78*/
                {
                  LODWORD(v165) = *(_DWORD *)MessageNumberNodeByDatagramNumber; /*0x1039dcf54*/
                  RakNet::ReliabilityLayer::RemovePacketFromResendListAndDeleteOlderReliableSequenced( /*0x1039dcf6c*/
                    a1: v163,
                    a2: &v165,
                    a3: a7);
                  MessageNumberNodeByDatagramNumber = *(_QWORD *)(MessageNumberNodeByDatagramNumber + 8); /*0x1039dcf71*/
                }
                while ( MessageNumberNodeByDatagramNumber != 0 ); /*0x1039dcf78*/
                LODWORD(v165) = v63; /*0x1039dcf7a*/
                RakNet::ReliabilityLayer::RemoveFromDatagramHistory(a1: (__int64)v163, a2: &v165); /*0x1039dcf8f*/
              }
            }
            v63 = (v63 + 1) & 0xFFFFFF; /*0x1039dcf97*/
            LODWORD(v20) = (_DWORD)v144; /*0x1039dcf9e*/
            v61 = *(_QWORD *)v144; /*0x1039dcfa5*/
            v62 = v158; /*0x1039dcfa8*/
          }
          while ( v63 >= *(_DWORD *)(*(_QWORD *)v144 + 8 * v158) ); /*0x1039dcfb3*/
          LODWORD(v62) = v62 + 1; /*0x1039dcfb9*/
          a1 = v163; /*0x1039dcfbb*/
          if ( (unsigned int)v62 >= *((_DWORD *)v163 + 788) ) /*0x1039dcfc9*/
            goto LABEL_115; /*0x1039dcfc9*/
        }
        v81 = v163; /*0x1039dd16c*/
        if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
          FLog::FastLogFormatted(
            a1: DFLog::NetworkTrace,
            a2: qword_10D7BB068,
            a3: (unsigned int)"[DFLog::NetworkTrace] Incoming packet error: incomingAcks minIndex > maxIndex, length=%d, address=%s",
            a4: 8 * v164,
            a5: (unsigned int)v169,
            a6: v59);
        *((_DWORD *)v81 + 78) = *((_DWORD *)v81 + 62); /*0x1039dd19d*/
        if ( (unsigned __int8)RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)v81 + 1312, a2: 7) != 0 ) /*0x1039dd1b6*/
        {
          *((_BYTE *)v81 + 436) = 1; /*0x1039dd1bc*/
          *((_DWORD *)v81 + 110) = 303; /*0x1039dd1c3*/
        }
        goto LABEL_265; /*0x1039dd1cd*/
      }
LABEL_115:
      (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(**((_QWORD **)a1 + 379) + 136LL))( /*0x1039dcfcf*/
        a1: *((_QWORD *)a1 + 379),
        a2: v162,
        a3: v143);
LABEL_254:
      *((_DWORD *)a1 + 75) = *((_DWORD *)a1 + 62); /*0x1039ddbe8*/
      *((_QWORD *)a1 + 34) = 0; /*0x1039ddbf6*/
      RakNet::ReceiveFailureTracking::resetAll(this: (RakNet::ReliabilityLayer *)((char *)a1 + 1312)); /*0x1039ddc08*/
      ++*((_DWORD *)a1 + 748); /*0x1039ddc0d*/
      LOBYTE(v20) = 1; /*0x1039ddc14*/
LABEL_266:
      RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)&v166); /*0x1039ddd19*/
      return (unsigned int)v20; /*0x1039ddd25*/
    }
    if ( v148 == 1 )
    {
      v160 = 0; /*0x1039dc9ba*/
      if ( DataStructures::RangeList<RakNet::uint24_t>::Deserialize(a1: (__int64)&v160, a2: (__int64)&v166) != 0 )
      {
        if ( DWORD2(v160) == 0 ) /*0x1039dc9d9*/
        {
LABEL_81:
          DataStructures::RangeList<RakNet::uint24_t>::~RangeList(a1: (__int64)&v160); /*0x1039dcb8e*/
          goto LABEL_254; /*0x1039dcb9a*/
        }
        v39 = 0; /*0x1039dc9df*/
        v40 = v160; /*0x1039dc9e2*/
        v20 = (char *)&v165; /*0x1039dc9e9*/
        while ( 1 ) /*0x1039dc9f3*/
        {
          v41 = *(_DWORD *)(v40 + 8LL * v39); /*0x1039dc9f3*/
          if ( v41 > *(_DWORD *)(v40 + 8LL * v39 + 4) ) /*0x1039dc9fc*/
            break; /*0x1039dc9fc*/
          while ( v41 <= *(_DWORD *)(v40 + 8LL * v39 + 4) ) /*0x1039dca07*/
          {
            v42 = *((_QWORD *)a1 + 379); /*0x1039dca0d*/
            LODWORD(v165) = v41; /*0x1039dca14*/
            (*(void (__fastcall **)(__int64, unsigned __int64, _QWORD **))(*(_QWORD *)v42 + 120LL))( /*0x1039dca25*/
              a1: v42,
              a2: a7,
              a3: &v165);
            v162 = v41; /*0x1039dca28*/
            v43 = RakNet::ReliabilityLayer::GetMessageNumberNodeByDatagramNumber(a1, a2: &v162, a3: &v165); /*0x1039dca3c*/
            if ( v43 != 0 ) /*0x1039dca44*/
            {
              v44 = v43; /*0x1039dca4a*/
              while ( 2 ) /*0x1039dca4d*/
              {
                v45 = *(_DWORD *)v44; /*0x1039dca4d*/
                v46 = *((_QWORD *)v163 + 22); /*0x1039dca57*/
                v47 = (unsigned __int64)(*((_QWORD *)v163 + 23) - v46) >> 3; /*0x1039dca68*/
                if ( (((_DWORD)v47 - 1) & (unsigned int)v47) != 0 ) /*0x1039dca71*/
                  v48 = v45 % (unsigned int)v47; /*0x1039dca79*/
                else
                  v48 = v45 & (v47 - 1); /*0x1039dca73*/
                v49 = *(_QWORD *)(v46 + 8LL * v48); /*0x1039dca7d*/
                if ( v49 == 0 || *(_QWORD *)(v49 + 48) == 0 ) /*0x1039dca8f*/
                  goto LABEL_78; /*0x1039dca8f*/
                v50 = DFInt::RakNetNakResendDelayRttPercent; /*0x1039dca9b*/
                v51 = a7; /*0x1039dcaa5*/
                if ( (DFInt::RakNetNakResendDelayRttPercent | DFInt::RakNetNakResendDelayMs) != 0 ) /*0x1039dcaa9*/
                {
                  if ( DFInt::RakNetNakResendDelayMs != -1 ) /*0x1039dcab2*/
                  {
                    if ( DFInt::RakNetNakResendDelayMs == 0 && DFInt::RakNetNakResendDelayRttPercent > 0 ) /*0x1039dcac1*/
                    {
                      v52 = v50 /*0x1039dcb16*/
                          * (unsigned __int64)(unsigned int)(int)(*(double (__fastcall **)(_QWORD))(**((_QWORD **)v163 + 379)
                                                                                                  + 208LL))(a1: *((_QWORD *)v163 + 379))
                          / 0x64;
                      v53 = 1000 * DFInt::RakNetNakResendDelayMsMax; /*0x1039dcb20*/
                      if ( 1000 * DFInt::RakNetNakResendDelayMsMax >= (int)v52 ) /*0x1039dcb28*/
                        v53 = v52; /*0x1039dcb28*/
                      if ( DFInt::RakNetNakResendDelayMsMax == 0 ) /*0x1039dcb2d*/
                        v53 = v52; /*0x1039dcb2d*/
                    }
                    else
                    {
                      v53 = 1000 * DFInt::RakNetNakResendDelayMs; /*0x1039dcb32*/
                    }
                    v51 = a7 + v53; /*0x1039dcb3b*/
                    goto LABEL_76; /*0x1039dcb3b*/
                  }
                }
                else
                {
LABEL_76:
                  *(_QWORD *)(v49 + 48) = v51; /*0x1039dcb3f*/
                }
                *(_BYTE *)(v49 + 56) = 1; /*0x1039dcb43*/
LABEL_78:
                v44 = *(_QWORD *)(v44 + 8); /*0x1039dcb48*/
                if ( v44 == 0 ) /*0x1039dcb4f*/
                  break; /*0x1039dcb4f*/
                continue; /*0x1039dcb4f*/
              }
            }
            v41 = (v41 + 1) & 0xFFFFFF; /*0x1039dcb55*/
            v40 = v160; /*0x1039dcb5f*/
            a1 = v163; /*0x1039dcb6a*/
            v20 = (char *)&v165; /*0x1039dcb71*/
            if ( v41 < *(_DWORD *)(v160 + 8LL * v39) ) /*0x1039dcb78*/
              break; /*0x1039dcb78*/
          }
          if ( ++v39 >= DWORD2(v160) ) /*0x1039dcb88*/
            goto LABEL_81; /*0x1039dcb88*/
        }
        if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
          FLog::FastLogFormatted(
            a1: DFLog::NetworkTrace,
            a2: qword_10D7BB068,
            a3: (unsigned int)"[DFLog::NetworkTrace] Incoming packet error: incomingNAKs minIndex>maxIndex, length=%d, address=%s",
            a4: 8 * v164,
            a5: (unsigned int)v169,
            a6: v38);
        *((_DWORD *)a1 + 80) = *((_DWORD *)a1 + 62); /*0x1039ddcdc*/
        v80 = RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 10); /*0x1039ddcef*/
      }
      else
      {
        if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
          FLog::FastLogFormatted(
            a1: DFLog::NetworkTrace,
            a2: qword_10D7BB068,
            a3: (unsigned int)"[DFLog::NetworkTrace] Incoming packet error: incomingNAKs.Deserialize failed, length=%d, address=%s",
            a4: 8 * v164,
            a5: (unsigned int)v169,
            a6: v38);
        *((_DWORD *)a1 + 79) = *((_DWORD *)a1 + 62); /*0x1039dd0ab*/
        v80 = RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 9); /*0x1039dd0be*/
      }
      if ( v80 != 0 ) /*0x1039ddcf6*/
      {
        *((_BYTE *)a1 + 436) = 1; /*0x1039ddcf8*/
        *((_DWORD *)a1 + 110) = 303; /*0x1039ddd00*/
      }
      DataStructures::RangeList<RakNet::uint24_t>::~RangeList(a1: (__int64)&v160); /*0x1039ddd12*/
      goto LABEL_265; /*0x1039ddd12*/
    }
    v54 = *((_QWORD *)a1 + 379); /*0x1039dcb9f*/
    LODWORD(v160) = (_DWORD)v146; /*0x1039dcbb3*/
    if ( (*(unsigned __int8 (__fastcall **)(__int64, __int128 *, _QWORD, unsigned __int64, _QWORD, unsigned int *))(*(_QWORD *)v54 + 104LL))(
           a1: v54,
           a2: &v160,
           a3: v150,
           a4: a7,
           a5: v164,
           a6: &v162) == 0 )
    {
      if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
        FLog::FastLogFormatted(
          a1: DFLog::NetworkTrace,
          a2: qword_10D7BB068,
          a3: (unsigned int)"[DFLog::NetworkTrace] Incoming packet error: congestionManager->OnGotPacket failed, length=%d, address=%s",
          a4: 8 * v164,
          a5: (unsigned int)v169,
          a6: v55);
      *((_DWORD *)a1 + 81) = *((_DWORD *)a1 + 62); /*0x1039dd117*/
      v37 = RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 11); /*0x1039dd12a*/
      goto LABEL_125; /*0x1039dd12a*/
    }
    if ( v162 != 0 ) /*0x1039dcbe6*/
    {
      v20 = (char *)v163 + 3176; /*0x1039dcbef*/
      v56 = -v162; /*0x1039dcbf6*/
      do /*0x1039dcc22*/
      {
        LODWORD(v160) = (v56 + (_DWORD)v146) & 0xFFFFFF; /*0x1039dcc0e*/
        DataStructures::RangeList<RakNet::uint24_t>::Insert(a1: (__int64)v20, a2: (unsigned int *)&v160); /*0x1039dcc1a*/
        ++v56; /*0x1039dcc1f*/
      }
      while ( v56 != 0 ); /*0x1039dcc22*/
    }
    a1 = v163; /*0x1039dcc2a*/
    *((_BYTE *)v163 + 3192) = v151; /*0x1039dcc31*/
    v57 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)a1 + 379) + 232LL))(a1: *((_QWORD *)a1 + 379)); /*0x1039dcc42*/
    v58 = (int)v146; /*0x1039dcc48*/
    if ( v57 != 0 ) /*0x1039dcc50*/
      *((_QWORD *)a1 + 378) = v145; /*0x1039dcc5d*/
    else
      *((_QWORD *)a1 + 378) = 0; /*0x1039dd1d2*/
    LODWORD(v160) = v58; /*0x1039dcc72*/
    DataStructures::RangeList<RakNet::uint24_t>::Insert(a1: (__int64)a1 + 3160, a2: (unsigned int *)&v160); /*0x1039dcc74*/
    InternalPacketFromBitStream = (_QWORD *)RakNet::ReliabilityLayer::CreateInternalPacketFromBitStream( /*0x1039dd200*/
                                              this: a1,
                                              a2: (RakNet::BitStream *)&v166,
                                              a3: a7);
    v165 = InternalPacketFromBitStream; /*0x1039dd205*/
    if ( InternalPacketFromBitStream == nullptr )
    {
      if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
        FLog::FastLogFormatted(
          a1: DFLog::NetworkTrace,
          a2: qword_10D7BB068,
          a3: (unsigned int)"[DFLog::NetworkTrace] Incoming packet error: CreateInternalPacketFromBitStream failed, length=%d, address=%s",
          a4: 8 * v164,
          a5: (unsigned int)v169,
          a6: v83);
      *((_DWORD *)a1 + 82) = *((_DWORD *)a1 + 62); /*0x1039ddc6a*/
      v136 = 303; /*0x1039ddc82*/
      if ( (unsigned __int8)RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 12) != 0 ) /*0x1039ddc89*/
      {
LABEL_284:
        *((_BYTE *)a1 + 436) = 1; /*0x1039ddf38*/
        *((_DWORD *)a1 + 110) = v136; /*0x1039ddf40*/
      }
      goto LABEL_265; /*0x1039ddf47*/
    }
    v157 = (_QWORD *)((char *)a1 + 2848); /*0x1039dd21c*/
    v164 *= 8; /*0x1039dd223*/
    v142 = (RakNet::ReliabilityLayer *)((char *)a1 + 3648); /*0x1039dd231*/
    v158 = (unsigned __int64)a1 + 1952; /*0x1039dd246*/
    v144 = (RakNet::ReliabilityLayer *)((char *)a1 + 3544); /*0x1039dd254*/
    v159 = (unsigned __int64)a1 + 16; /*0x1039dd25f*/
    while ( 1 )
    {
      if ( *((_BYTE *)a1 + 2876) == 1 ) /*0x1039dd26e*/
      {
        DataStructures::Queue<bool>::ClearAndForceAllocation(a1: (__int64)v157, a2: 512); /*0x1039dd285*/
        *((_DWORD *)a1 + 718) = 0; /*0x1039dd28a*/
        *((_BYTE *)a1 + 2876) = 0; /*0x1039dd295*/
        InternalPacketFromBitStream = v165; /*0x1039dd29d*/
      }
      v84 = *((_DWORD *)InternalPacketFromBitStream + 7); /*0x1039dd2a4*/
      if ( v84 <= 4 )
      {
        v85 = 26; /*0x1039dd2b0*/
        if ( _bittest(&v85, v84) )
        {
          if ( *((_BYTE *)InternalPacketFromBitStream + 12) >= 0x20u )
          {
            if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
            {
              FLog::FastLogFormatted(
                a1: DFLog::NetworkTrace,
                a2: qword_10D7BB068,
                a3: (unsigned int)"[DFLog::NetworkTrace] Incoming packet error: internalPacket->orderingChannel >= NUMBER_OF_"
                              "ORDERED_STREAMS, length=%d, address=%s",
                a4: v164,
                a5: (unsigned int)v169,
                a6: v83);
              InternalPacketFromBitStream = v165; /*0x1039dd30e*/
            }
            RakNet::BPSTracker::Push1( /*0x1039dd329*/
              this: v142,
              a2: a7,
              a3: (unsigned int)(*((_DWORD *)InternalPacketFromBitStream + 6) + 7) >> 3);
            if ( a9 != 0 ) /*0x1039dd332*/
              *((_QWORD *)a1 + 156) = _mm_add_epi32( /*0x1039dd360*/
                                        _mm_insert_epi32(
                                          _mm_cvtepi8_epi32(16843009),
                                          (unsigned int)(*((_DWORD *)v165 + 6) + 7) >> 3,
                                          0),
                                        _mm_loadl_epi64((const __m128i *)a1 + 78)).u64[0];
            if ( (*((_BYTE *)a1 + 4114) & 0x20) != 0 ) /*0x1039dd371*/
            {
              v86 = v165; /*0x1039dd42b*/
              if ( (_BYTE)v155 == 1 ) /*0x1039dd439*/
                *((_QWORD *)a1 + 159) = _mm_add_epi32( /*0x1039dd460*/
                                          _mm_insert_epi32(
                                            _mm_cvtepi8_epi32(16843009),
                                            (unsigned int)(*((_DWORD *)v165 + 6) + 7) >> 3,
                                            0),
                                          _mm_loadl_epi64((const __m128i *)((char *)a1 + 1272))).u64[0];
            }
            else
            {
              v86 = v165; /*0x1039dd377*/
            }
            goto LABEL_171; /*0x1039dd37e*/
          }
        }
      }
      if ( v84 - 2 <= 2 )
      {
        *((_QWORD *)a1 + 43) = a7; /*0x1039dd393*/
        v87 = *((_DWORD *)a1 + 718); /*0x1039dd39c*/
        LODWORD(v20) = (*(_DWORD *)InternalPacketFromBitStream - v87) & 0xFFFFFF; /*0x1039dd3a5*/
        if ( (_DWORD)v20 != 0 )
        {
          if ( (unsigned int)v20 >= 0x800000 ) /*0x1039dd3b7*/
            goto LABEL_148; /*0x1039dd3b7*/
          v92 = *((_DWORD *)a1 + 714); /*0x1039dd4ce*/
          v89 = *((_DWORD *)a1 + 715); /*0x1039dd4d5*/
          v93 = v89 - v92; /*0x1039dd4de*/
          if ( v89 < v92 ) /*0x1039dd4e0*/
            v93 = *((_DWORD *)a1 + 716) + v89 - v92; /*0x1039dd4e6*/
          if ( (unsigned int)v20 >= v93 )
          {
            if ( (unsigned int)v20 > (DFInt::CLI71353H & 0xFFFFFFu) )
            {
              if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && BYTE1(DFLog::NetworkTrace) >= 3u )
              {
                FLog::FastLogFormatted(
                  a1: DFLog::NetworkTrace,
                  a2: qword_10D7BB068,
                  a3: (unsigned int)"[DFLog::NetworkTrace] Incoming packet error: holeCount > %d, length=%d, address=%s",
                  a4: DFInt::CLI71353H,
                  a5: v164,
                  a6: (unsigned int)v169);
                InternalPacketFromBitStream = v165; /*0x1039dde12*/
              }
              RakNet::BPSTracker::Push1( /*0x1039dde2d*/
                this: v142,
                a2: a7,
                a3: (unsigned int)(*((_DWORD *)InternalPacketFromBitStream + 6) + 7) >> 3);
              if ( a9 != 0 ) /*0x1039dde36*/
                *((_QWORD *)a1 + 156) = _mm_add_epi32( /*0x1039dde64*/
                                          _mm_insert_epi32(
                                            _mm_cvtepi8_epi32(16843009),
                                            (unsigned int)(*((_DWORD *)v165 + 6) + 7) >> 3,
                                            0),
                                          _mm_loadl_epi64((const __m128i *)a1 + 78)).u64[0];
              if ( (*((_BYTE *)a1 + 4114) & 0x20) != 0 ) /*0x1039dde75*/
              {
                v137 = v165; /*0x1039dde80*/
                if ( (_BYTE)v155 == 1 ) /*0x1039dde8e*/
                  *((_QWORD *)a1 + 159) = _mm_add_epi32( /*0x1039ddeb5*/
                                            _mm_insert_epi32(
                                              _mm_cvtepi8_epi32(16843009),
                                              (unsigned int)(*((_DWORD *)v165 + 6) + 7) >> 3,
                                              0),
                                            _mm_loadl_epi64((const __m128i *)((char *)a1 + 1272))).u64[0];
              }
              else
              {
                v137 = v165; /*0x1039dde77*/
              }
              RakNet::ReliabilityLayer::FreeInternalPacketData((__int64)a1, a2: (__int64)v137); /*0x1039ddeca*/
              DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: (__int64)a1 + 144, a2: v165); /*0x1039ddee2*/
              std::string::basic_string[abi:ne200100]<0>( /*0x1039ddef5*/
                a1: &v160,
                a2: "RakNetRxHoleCountCapExceeded",
                a3: v138,
                a4: v139);
              RBX::Analytics::EphemeralCounter::reportCounter(a1: &v160, a2: 1, a3: 0); /*0x1039ddf08*/
              if ( (v160 & 1) != 0 ) /*0x1039ddf14*/
                operator delete(a1: v161); /*0x1039ddf1d*/
              v136 = 299; /*0x1039ddf29*/
              RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 13); /*0x1039ddf33*/
              goto LABEL_284; /*0x1039ddf33*/
            }
            while ( 1 ) /*0x1039dd5a8*/
            {
              v98 = v89 - v92; /*0x1039dd5a8*/
              if ( v89 < v92 ) /*0x1039dd5aa*/
                v98 = *((_DWORD *)a1 + 716) + v89 - v92; /*0x1039dd5b5*/
              if ( (unsigned int)v20 <= v98 ) /*0x1039dd5b9*/
                break; /*0x1039dd5b9*/
              LOBYTE(v160) = 1; /*0x1039dd5bb*/
              DataStructures::Queue<bool>::Push(a1: (__int64)v157, a2: (char *)&v160); /*0x1039dd5d9*/
              v92 = *((_DWORD *)a1 + 714); /*0x1039dd5de*/
              v89 = *((_DWORD *)a1 + 715); /*0x1039dd5e5*/
            }
            LOBYTE(v160) = 0; /*0x1039dd5ee*/
            DataStructures::Queue<bool>::Push(a1: (__int64)v157, a2: (char *)&v160); /*0x1039dd60c*/
            v89 = *((_DWORD *)a1 + 715); /*0x1039dd611*/
          }
          else
          {
            v94 = (_DWORD)v20 + v92; /*0x1039dd4f5*/
            v95 = *((_DWORD *)a1 + 716); /*0x1039dd4f7*/
            if ( v94 < v95 ) /*0x1039dd505*/
              v95 = 0; /*0x1039dd505*/
            v96 = *((_QWORD *)a1 + 356); /*0x1039dd508*/
            v97 = v94 - v95; /*0x1039dd50f*/
            if ( *(_BYTE *)(v96 + v97) != 1 ) /*0x1039dd515*/
            {
LABEL_148:
              RakNet::BPSTracker::Push1( /*0x1039dd3bd*/
                this: v142,
                a2: a7,
                a3: (unsigned int)(*((_DWORD *)InternalPacketFromBitStream + 6) + 7) >> 3);
              if ( a9 != 0 ) /*0x1039dd3da*/
                *((_QWORD *)a1 + 156) = _mm_add_epi32( /*0x1039dd408*/
                                          _mm_insert_epi32(
                                            _mm_cvtepi8_epi32(16843009),
                                            (unsigned int)(*((_DWORD *)v165 + 6) + 7) >> 3,
                                            0),
                                          _mm_loadl_epi64((const __m128i *)a1 + 78)).u64[0];
              if ( (*((_BYTE *)a1 + 4114) & 0x20) != 0 ) /*0x1039dd419*/
              {
                v86 = v165; /*0x1039dd524*/
                if ( (_BYTE)v155 == 1 ) /*0x1039dd532*/
                  *((_QWORD *)a1 + 159) = _mm_add_epi32( /*0x1039dd559*/
                                            _mm_insert_epi32(
                                              _mm_cvtepi8_epi32(16843009),
                                              (unsigned int)(*((_DWORD *)v165 + 6) + 7) >> 3,
                                              0),
                                            _mm_loadl_epi64((const __m128i *)((char *)a1 + 1272))).u64[0];
              }
              else
              {
                v86 = v165; /*0x1039dd41f*/
              }
              goto LABEL_171; /*0x1039dd426*/
            }
            *(_BYTE *)(v96 + v97) = 0; /*0x1039dd51b*/
          }
        }
        else
        {
          v88 = *((_DWORD *)a1 + 714); /*0x1039dd47f*/
          v89 = *((_DWORD *)a1 + 715); /*0x1039dd486*/
          v90 = v89 - v88; /*0x1039dd48f*/
          if ( v89 < v88 ) /*0x1039dd491*/
            v90 = *((_DWORD *)a1 + 716) + v89 - v88; /*0x1039dd497*/
          if ( v90 != 0 ) /*0x1039dd4a0*/
          {
            v91 = v88 + 1; /*0x1039dd4a2*/
            if ( v91 == *((_DWORD *)a1 + 716) ) /*0x1039dd4b0*/
              v91 = 0; /*0x1039dd4b0*/
            *((_DWORD *)a1 + 714) = v91; /*0x1039dd4b3*/
          }
          *((_DWORD *)a1 + 718) = (v87 + 1) & 0xFFFFFF; /*0x1039dd4c2*/
        }
        for ( i = *((_DWORD *)a1 + 714); ; i = v102 ) /*0x1039dd618*/
        {
          v100 = v89 - i; /*0x1039dd621*/
          if ( v89 < i ) /*0x1039dd623*/
            v100 = *((_DWORD *)a1 + 716) + v89 - i; /*0x1039dd629*/
          if ( v100 == 0 || *(_BYTE *)(*v157 + i) != 0 ) /*0x1039dd644*/
            break; /*0x1039dd644*/
          v101 = i + 1; /*0x1039dd646*/
          v102 = 0; /*0x1039dd648*/
          if ( v101 != *((_DWORD *)a1 + 716) ) /*0x1039dd651*/
            v102 = v101; /*0x1039dd653*/
          *((_DWORD *)a1 + 714) = v102; /*0x1039dd655*/
          *((_DWORD *)a1 + 718) = (*((_DWORD *)a1 + 718) + 1) & 0xFFFFFF; /*0x1039dd66a*/
        }
      }
      v103 = *((_DWORD *)a1 + 716); /*0x1039dd675*/
      if ( v103 >= 0x201 ) /*0x1039dd681*/
      {
        v104 = *((_DWORD *)a1 + 714); /*0x1039dd683*/
        v105 = *((_DWORD *)a1 + 715); /*0x1039dd68a*/
        v106 = 0; /*0x1039dd693*/
        if ( v104 > v105 ) /*0x1039dd698*/
          v106 = *((_DWORD *)a1 + 716); /*0x1039dd698*/
        if ( v103 > 3 * (v105 + v106 - v104) ) /*0x1039dd6a4*/
          DataStructures::Queue<bool>::Compress(a1: (__int64)v157); /*0x1039dd6b6*/
      }
      v86 = v165; /*0x1039dd6bb*/
      if ( *((_DWORD *)v165 + 5) == 0 ) /*0x1039dd6c6*/
        goto LABEL_199; /*0x1039dd6c6*/
      v107 = *((_DWORD *)v165 + 7); /*0x1039dd6cc*/
      if ( v107 > 4 || (v108 = 26, !_bittest(&v108, v107)) ) /*0x1039dd6dc*/
        *((_BYTE *)v165 + 12) = -1; /*0x1039dd6de*/
      LODWORD(v20) = *((_DWORD *)v86 + 6); /*0x1039dd6e2*/
      RakNet::ReliabilityLayer::InsertIntoSplitPacketList(this: a1); /*0x1039dd6f1*/
      v109 = v156->i64[1]; /*0x1039dd712*/
      v140 = _mm_loadu_si128(v156); /*0x1039dd71a*/
      if ( v109 != 0 ) /*0x1039dd725*/
        _InterlockedIncrement64((volatile signed __int64 *)(v109 + 8)); /*0x1039dd727*/
      v165 = (_QWORD *)RakNet::ReliabilityLayer::BuildPacketFromSplitPacketList(this: a1, a2: a10, a3: a11); /*0x1039dd75e*/
      std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: &v140); /*0x1039dd768*/
      v86 = v165; /*0x1039dd76d*/
      if ( v165 != nullptr ) /*0x1039dd777*/
        break; /*0x1039dd777*/
      LODWORD(v20) = *((_DWORD *)a1 + 1038) + ((unsigned int)((_DWORD)v20 + 7) >> 3); /*0x1039dd81a*/
      *((_DWORD *)a1 + 1038) = (_DWORD)v20; /*0x1039dd821*/
      v121 = *((_QWORD *)a1 + 518); /*0x1039dd828*/
      v122 = *(unsigned int *)(v121 + 148); /*0x1039dd82f*/
      if ( (int)v122 <= (int)v20 ) /*0x1039dd837*/
        v122 = (unsigned int)v20; /*0x1039dd837*/
      *(_DWORD *)(v121 + 148) = v122; /*0x1039dd83a*/
      v123 = DFInt::CLI57133B; /*0x1039dd840*/
      if ( (int)v20 >= DFInt::CLI57133B )
      {
        ++*(_DWORD *)(v121 + 152); /*0x1039ddd2a*/
        if ( *((_BYTE *)a1 + 4156) == 0 )
        {
          *((_BYTE *)a1 + 4156) = 1; /*0x1039ddd3a*/
          LOBYTE(v122) = (unsigned __int8)FLog::Network < 6u; /*0x1039ddd52*/
          if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
            FLog::FastLogFormatted(
              a1: FLog::Network,
              a2: qword_10D7BBAA8,
              a3: (unsigned int)"[FLog::Network] Rx: Peer %s exceeded total incomplete datagram byte cap of %d",
              a4: (unsigned int)v169,
              a5: v123,
              a6: v111);
          std::string::basic_string[abi:ne200100]<0>( /*0x1039ddd88*/
            a1: &v160,
            a2: "RakNetRxIncompleteDatagramByteCapExceeded",
            a3: v110,
            a4: v122);
          RBX::Analytics::EphemeralCounter::reportCounter(a1: &v160, a2: 1, a3: 0); /*0x1039ddd9b*/
          if ( (v160 & 1) != 0 ) /*0x1039ddda7*/
            operator delete(a1: v161); /*0x1039dddb0*/
        }
        v136 = 299; /*0x1039dddbc*/
        RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 14); /*0x1039dddc6*/
        goto LABEL_284; /*0x1039dddcb*/
      }
LABEL_253:
      InternalPacketFromBitStream = (_QWORD *)RakNet::ReliabilityLayer::CreateInternalPacketFromBitStream( /*0x1039ddbc5*/
                                                this: a1,
                                                a2: (RakNet::BitStream *)&v166,
                                                a3: a7);
      v165 = InternalPacketFromBitStream; /*0x1039ddbd8*/
      if ( InternalPacketFromBitStream == nullptr ) /*0x1039ddbe2*/
        goto LABEL_254; /*0x1039ddbe2*/
    }
    *((_DWORD *)a1 + 1038) -= (unsigned int)(*((_DWORD *)v165 + 6) + 7) >> 3; /*0x1039dd786*/
LABEL_199:
    v112 = *((_DWORD *)v86 + 7); /*0x1039dd78d*/
    if ( v112 > 4 ) /*0x1039dd793*/
      goto LABEL_224; /*0x1039dd793*/
    v113 = 26; /*0x1039dd799*/
    if ( !_bittest(&v113, v112) ) /*0x1039dd79e*/
      goto LABEL_224; /*0x1039dd7a1*/
    v114 = *((unsigned __int8 *)v86 + 12); /*0x1039dd7a7*/
    v115 = *((_DWORD *)v86 + 1); /*0x1039dd7ab*/
    v116 = *((_DWORD *)a1 + v114 + 423); /*0x1039dd7ae*/
    if ( v115 == v116 ) /*0x1039dd7b8*/
    {
      if ( v112 != 4 && v112 != 1 ) /*0x1039dd7c2*/
      {
        RakNet::BPSTracker::Push1(this: v144, a2: a7, a3: (unsigned int)(*((_DWORD *)v86 + 6) + 7) >> 3); /*0x1039dd960*/
        DataStructures::Queue<RakNet::InternalPacket *>::Push(a1: v159, a2: (__int64 *)&v165); /*0x1039dd97c*/
        v127 = *((unsigned __int8 *)v165 + 12); /*0x1039dd988*/
        *((_DWORD *)a1 + v127 + 423) = (*((_DWORD *)a1 + v127 + 423) + 1) & 0xFFFFFF; /*0x1039dd99c*/
        *((_DWORD *)a1 + v127 + 455) = 0; /*0x1039dd9a4*/
        if ( *(_DWORD *)(v158 + 24 * v127 + 8) != 0 ) /*0x1039dd9c0*/
        {
          v128 = (char *)(v158 + 24 * v127); /*0x1039dd9cd*/
          do /*0x1039dda79*/
          {
            if ( *(_DWORD *)(*(_QWORD *)(*(_QWORD *)v128 + 8LL) + 4LL) != *((_DWORD *)a1 + v127 + 423) ) /*0x1039dd9e3*/
              break; /*0x1039dd9e3*/
            v165 = (_QWORD *)DataStructures::Heap<unsigned long long,RakNet::InternalPacket *,false>::Pop( /*0x1039dd9f0*/
                               a1: (__int64 *)v128,
                               a2: 0);
            RakNet::BPSTracker::Push1(this: v144, a2: a7, a3: (unsigned int)(*((_DWORD *)v165 + 6) + 7) >> 3); /*0x1039dda0b*/
            DataStructures::Queue<RakNet::InternalPacket *>::Push(a1: v159, a2: (__int64 *)&v165); /*0x1039dda27*/
            v127 = *((unsigned __int8 *)v165 + 12); /*0x1039dda39*/
            if ( *((_DWORD *)v165 + 7) == 3 ) /*0x1039dda37*/
              *((_DWORD *)a1 + v127 + 423) = (*((_DWORD *)a1 + v127 + 423) + 1) & 0xFFFFFF; /*0x1039dda4d*/
            else
              *((_DWORD *)a1 + v127 + 455) = *((_DWORD *)v165 + 2); /*0x1039dda5e*/
            v128 = (char *)(v158 + 24 * v127); /*0x1039dda71*/
          }
          while ( *((_DWORD *)v128 + 2) != 0 ); /*0x1039dda79*/
        }
        goto LABEL_253; /*0x1039dda79*/
      }
      v117 = *((_DWORD *)v86 + 2); /*0x1039dd7c8*/
      v118 = *((_DWORD *)a1 + v114 + 455); /*0x1039dd7cb*/
      if ( v118 >= 0x800000 ) /*0x1039dd7d9*/
      {
        if ( v117 >= v118 ) /*0x1039dd7e1*/
          goto LABEL_223; /*0x1039dd7e1*/
        v119 = (v118 + 8388610) & 0xFFFFFF; /*0x1039dd7ed*/
        goto LABEL_221; /*0x1039dd7f3*/
      }
      if ( v117 >= v118 ) /*0x1039dd88e*/
      {
        v119 = v118 | 0x800000; /*0x1039dd890*/
LABEL_221:
        if ( v117 < v119 ) /*0x1039dd898*/
        {
LABEL_223:
          *((_DWORD *)a1 + v114 + 455) = v117; /*0x1039dd8c8*/
LABEL_224:
          RakNet::BPSTracker::Push1(this: v144, a2: a7, a3: (unsigned int)(*((_DWORD *)v86 + 6) + 7) >> 3); /*0x1039dd8d0*/
          if ( (DFFlag::EnablePingPongPerformanceTraceCLI != 0 /*0x1039dd920*/
             || DFFlag::RakNetPingTrace != 0
             || DFFlag::DataPingTrace == 1)
            && v165[33] != 0 )
          {
            if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v124) != 0 ) /*0x1039dd934*/
            {
              if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039dd93d*/
                v20 = *(char **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039dd943*/
              else
                v20 = nullptr; /*0x1039ddb1f*/
              v131 = v165[33]; /*0x1039ddb28*/
              v132 = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, __int64))(**((_QWORD **)a1 + 518) + 200LL))( /*0x1039ddb39*/
                       a1: *((_QWORD *)a1 + 518),
                       a2: v126,
                       a3: v125,
                       a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
              RBX::Network::NetworkTracer::addCheckpointToTracer(a1: v20, a2: v131, a3: v132, a4: 70); /*0x1039ddb4d*/
            }
            else
            {
              if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039dda87*/
                v141 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039dda91*/
              else
                v141 = 0; /*0x1039ddb54*/
              v133 = v165[33]; /*0x1039ddb66*/
              LODWORD(v20) = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, __int64))(**((_QWORD **)a1 + 518) /*0x1039ddb7d*/
                                                                                          + 200LL))(
                               a1: *((_QWORD *)a1 + 518),
                               a2: v126,
                               a3: v125,
                               a4: RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle);
              TimeMS = RakNet::GetTimeMS(this: v134); /*0x1039ddb7f*/
              RBX::Network::NetworkTracer::addCheckpointToTracer_deprecated( /*0x1039ddb99*/
                a1: v141,
                a2: v133,
                a3: (unsigned __int8)v20,
                a4: 70,
                a5: TimeMS);
            }
          }
          DataStructures::Queue<RakNet::InternalPacket *>::Push(a1: v159, a2: (__int64 *)&v165); /*0x1039ddbb5*/
          v165 = nullptr; /*0x1039ddbba*/
          goto LABEL_253; /*0x1039ddbba*/
        }
      }
LABEL_171:
      RakNet::ReliabilityLayer::FreeInternalPacketData((__int64)a1, a2: (__int64)v86); /*0x1039dd562*/
      DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: (__int64)a1 + 144, a2: v165); /*0x1039dd586*/
      goto LABEL_253; /*0x1039dd58b*/
    }
    if ( v116 < 0x800000 ) /*0x1039dd7fe*/
    {
      if ( v115 < v116 ) /*0x1039dd857*/
        goto LABEL_171; /*0x1039dd857*/
      v120 = v116 | 0x800000; /*0x1039dd85c*/
    }
    else
    {
      if ( v115 >= v116 ) /*0x1039dd802*/
        goto LABEL_217; /*0x1039dd802*/
      v120 = (v116 + 8388610) & 0xFFFFFF; /*0x1039dd80b*/
    }
    if ( v115 < v120 ) /*0x1039dd866*/
    {
LABEL_217:
      if ( *(_DWORD *)(v158 + 24 * v114 + 8) != 0 ) /*0x1039dd879*/
      {
        v116 = *((_DWORD *)a1 + v114 + 680); /*0x1039dd87f*/
      }
      else
      {
        *((_DWORD *)a1 + v114 + 680) = v116; /*0x1039dda9d*/
        v115 = *((_DWORD *)v86 + 1); /*0x1039ddaa5*/
      }
      v129 = (unsigned __int64)((v115 - v116) & 0xFFFFFF) << 20; /*0x1039ddab0*/
      if ( v112 == 4 || v112 == 1 ) /*0x1039ddabc*/
        v130 = *((unsigned int *)v86 + 2) + v129; /*0x1039ddac1*/
      else
        v130 = v129 | 0xFFFFF; /*0x1039ddae4*/
      *(_QWORD *)&v160 = v130; /*0x1039ddaf6*/
      DataStructures::Heap<unsigned long long,RakNet::InternalPacket *,false>::Push( /*0x1039ddb15*/
        a1: (__int64 *)(v158 + 24 * v114),
        a2: &v160,
        a3: &v165,
        a4: (__int64)"",
        a5: 0);
      goto LABEL_253; /*0x1039ddb1a*/
    }
    goto LABEL_171; /*0x1039dd866*/
  }
  RakNet::ReceiveFailureTracking::trackFailure(a1: (char *)a1 + 1312, a2: 3); /*0x1039dc635*/
  *((_BYTE *)a1 + 436) = 1; /*0x1039dc63a*/
  *((_DWORD *)a1 + 110) = 300; /*0x1039dc642*/
LABEL_22:
  LODWORD(v20) = 0; /*0x1039dc64d*/
  return (unsigned int)v20; /*0x1039dc665*/
}

// Address: 0x1039ddfe2 | Name: __ZN6RakNet16ReliabilityLayer14KillConnectionEj
void __fastcall RakNet::ReliabilityLayer::KillConnection(RakNet::ReliabilityLayer *this, int a2)
{
  *((_BYTE *)this + 436) = 1; /*0x1039ddfe6*/
  *((_DWORD *)this + 110) = a2; /*0x1039ddfed*/
}

// Address: 0x1039ddff6 | Name: __ZNK6RakNet16ReliabilityLayer23reportDecryptionFailureERKNS_13SystemAddressEii
void __fastcall RakNet::ReliabilityLayer::reportDecryptionFailure(
        RakNet::ReliabilityLayer *this,
        const RakNet::SystemAddress *a2,
        int a3,
        int a4)
{
  __int64 v7; // rbx
  __int64 RemoteSystem; // rbx
  RakNet *v9; // rdi
  unsigned int TimeMS; // eax
  unsigned int v11; // r13d
  unsigned __int8 IsAesGcm; // al
  __int64 TxNonce; // rax
  __int64 RxNonce; // rax
  _BYTE v15[72]; // [rsp+8h] [rbp-2B8h] BYREF
  _BYTE v16[528]; // [rsp+50h] [rbp-270h] BYREF
  _BYTE v17[52]; // [rsp+260h] [rbp-60h] BYREF
  int v18; // [rsp+294h] [rbp-2Ch]

  v18 = a4; /*0x1039de00a*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1039de024*/
    a1: (__int64)v15,
    a2: (__int64)&RBX::Telemetry::kRakNetDecryptionFailure);
  RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v16); /*0x1039de033*/
  RBX::Telemetry::FieldsContainer::addArchitectureInfo(this: (RBX::Telemetry::FieldsContainer *)v16); /*0x1039de03b*/
  v7 = *((_QWORD *)this + 518); /*0x1039de040*/
  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v17, a2); /*0x1039de04e*/
  RemoteSystem = RakNet::RakPeer::GetRemoteSystem(a1: v7, a2: (__int64)v17, a3: 1, a4: 1u); /*0x1039de069*/
  TimeMS = RakNet::GetTimeMS(this: v9); /*0x1039de06c*/
  v11 = TimeMS; /*0x1039de071*/
  if ( RemoteSystem != 0 ) /*0x1039de077*/
    RBX::Telemetry::FieldsContainer::addField( /*0x1039de098*/
      a1: v16,
      a2: "connectionTime",
      a3: 14,
      a4: TimeMS - *(_QWORD *)(RemoteSystem + 5184),
      a5: 1);
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "failureRate", a3: 11, a4: a3, a5: 1); /*0x1039de0b5*/
  RBX::Telemetry::FieldsContainer::addField( /*0x1039de0d9*/
    a1: v16,
    a2: "timeSinceLastSuccessfulRx",
    a3: 25,
    a4: v11 - *((_DWORD *)this + 75),
    a5: 1);
  RBX::Telemetry::FieldsContainer::addField( /*0x1039de0fa*/
    a1: v16,
    a2: "numFailedDecryptionsTotal",
    a3: 25,
    a4: *((_QWORD *)this + 33),
    a5: 1);
  RBX::Telemetry::FieldsContainer::addField( /*0x1039de11b*/
    a1: v16,
    a2: "numFailedDecryptionsContiguous",
    a3: 30,
    a4: *((_QWORD *)this + 34),
    a5: 1);
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "userId", a3: 6, a4: *((_QWORD *)this + 526), a5: 1); /*0x1039de13c*/
  IsAesGcm = RBX::Security::SessionCrypto::rakIsAesGcm(this: *(RBX::Security::SessionCrypto **)this); /*0x1039de144*/
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "rakIsAesGcm", a3: 11, a4: IsAesGcm, a5: 1); /*0x1039de161*/
  TxNonce = RBX::Security::RakPeerCrypto::unitTestGetTxNonce(this: *(RBX::Security::RakPeerCrypto **)this); /*0x1039de169*/
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "txNonce", a3: 7, a4: TxNonce, a5: 1); /*0x1039de186*/
  RxNonce = RBX::Security::RakPeerCrypto::unitTestGetRxNonce(this: *(RBX::Security::RakPeerCrypto **)this); /*0x1039de18e*/
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "rxNonce", a3: 7, a4: RxNonce, a5: 1); /*0x1039de1ab*/
  RBX::Telemetry::FieldsContainer::addField(a1: v16, a2: "ruppLength", a3: 10, a4: v18, a5: 1); /*0x1039de1c9*/
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v15); /*0x1039de1d5*/
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v15); /*0x1039de1e8*/
}

// Address: 0x1039de540 | Name: __ZN6RakNet16ReliabilityLayer30AllocateFromInternalPacketPoolEv
__int64 __fastcall RakNet::ReliabilityLayer::AllocateFromInternalPacketPool(RakNet::ReliabilityLayer *this)
{
  __int64 result; // rax

  result = DataStructures::MemoryPool<RakNet::InternalPacket>::Allocate( /*0x1039de558*/
             a1: (__int64 *)this + 18,
             a2: (unsigned __int64)"",
             a3: 0);
  *(_DWORD *)result = 0xFFFFFF; /*0x1039de55d*/
  *(_BYTE *)(result + 36) = 0; /*0x1039de563*/
  *(_QWORD *)(result + 48) = 0; /*0x1039de566*/
  *(_DWORD *)(result + 20) = 0; /*0x1039de56a*/
  *(_DWORD *)(result + 72) = 0; /*0x1039de56d*/
  *(_QWORD *)(result + 64) = 0; /*0x1039de570*/
  *(_WORD *)(result + 88) = 0; /*0x1039de574*/
  *(_BYTE *)(result + 90) = 0; /*0x1039de57a*/
  *(_QWORD *)(result + 264) = 0; /*0x1039de57d*/
  return result; /*0x1039de588*/
}

// Address: 0x1039de58c | Name: __ZN6RakNet16ReliabilityLayer23AllocInternalPacketDataEPNS_14InternalPacketEjbPKcj
__int64 __fastcall RakNet::ReliabilityLayer::AllocInternalPacketData(
        __int64 a1,
        unsigned __int64 a2,
        unsigned int a3,
        unsigned __int8 a4)
{
  __int64 result; // rax

  if ( (a4 ^ 1 | (a3 >= 0x81)) != 0 ) /*0x1039de5a3*/
  {
    *(_DWORD *)(a2 + 72) = 0; /*0x1039de5b7*/
    result = RBX::Memory::allocateOrCrash(this: (RBX::Memory *)a3, a2); /*0x1039de5be*/
  }
  else
  {
    *(_DWORD *)(a2 + 72) = 2; /*0x1039de5a5*/
    result = a2 + 136; /*0x1039de5ac*/
  }
  *(_QWORD *)(a2 + 64) = result; /*0x1039de5c3*/
  return result; /*0x1039de5cb*/
}

// Address: 0x1039de702 | Name: __ZN6RakNet16ReliabilityLayer36GetMessageNumberNodeByDatagramNumberENS_8uint24_tEPy
__int64 __fastcall RakNet::ReliabilityLayer::GetMessageNumberNodeByDatagramNumber(__int64 a1, _DWORD *a2, _QWORD *a3)
{
  unsigned int v3; // r8d
  unsigned int v4; // eax
  int v5; // r9d
  __int64 result; // rax
  unsigned int v7; // ecx
  unsigned int v8; // esi
  unsigned int v9; // ecx
  unsigned int v10; // esi
  __int64 v11; // rdi
  unsigned int v12; // ecx

  v3 = *(_DWORD *)(a1 + 64); /*0x1039de702*/
  v4 = *(_DWORD *)(a1 + 68); /*0x1039de706*/
  if ( v4 == v3 ) /*0x1039de70c*/
    return 0; /*0x1039de70c*/
  v5 = *(_DWORD *)(a1 + 136) - *a2; /*0x1039de719*/
  if ( v5 != 0 && (v5 & 0xFFFFFFu) < 0x7FFFFF ) /*0x1039de72c*/
    return 0; /*0x1039de72e*/
  v7 = (*a2 - *(_DWORD *)(a1 + 136)) & 0xFFFFFF; /*0x1039de733*/
  v8 = v4 - v3; /*0x1039de73b*/
  if ( v4 < v3 ) /*0x1039de73e*/
    v8 = *(_DWORD *)(a1 + 72) + v4 - v3; /*0x1039de746*/
  result = 0; /*0x1039de748*/
  if ( v7 < v8 ) /*0x1039de74c*/
  {
    v9 = v3 + v7; /*0x1039de752*/
    v10 = *(_DWORD *)(a1 + 72); /*0x1039de755*/
    v11 = *(_QWORD *)(a1 + 56); /*0x1039de75a*/
    if ( v9 >= v10 ) /*0x1039de75e*/
      LODWORD(result) = v10; /*0x1039de75e*/
    v12 = v9 - result; /*0x1039de761*/
    *a3 = *(_QWORD *)(v11 + 24LL * v12 + 8); /*0x1039de76c*/
    return *(_QWORD *)(v11 + 24LL * v12); /*0x1039de76f*/
  }
  return result; /*0x1039de730*/
}

// Address: 0x1039de776 | Name: __ZN6RakNet16ReliabilityLayer16newAckPingSampleEy
__int64 __fastcall RakNet::ReliabilityLayer::newAckPingSample(RakNet::ReliabilityLayer *this, __int64 a2)
{
  __int64 v2; // rax
  __int64 result; // rax

  if ( a2 != 0 ) /*0x1039de77d*/
  {
    *((_QWORD *)this + 363) = a2; /*0x1039de77f*/
    v2 = *((unsigned __int8 *)this + 2952); /*0x1039de786*/
    *((_QWORD *)this + v2 + 364) = a2; /*0x1039de78d*/
    result = -5 * ((unsigned int)(13108 * (v2 + 1)) >> 16) + (unsigned int)v2 + 1; /*0x1039de7a9*/
    *((_BYTE *)this + 2952) = result; /*0x1039de7ab*/
  }
  return result; /*0x1039de7b1*/
}

// Address: 0x1039de7b4 | Name: __ZN6RakNet16ReliabilityLayer57RemovePacketFromResendListAndDeleteOlderReliableSequencedENS_8uint24_tEyRKNS_13SystemAddressE
__int64 __fastcall RakNet::ReliabilityLayer::RemovePacketFromResendListAndDeleteOlderReliableSequenced(
        __int64 a1,
        unsigned int *a2,
        __int64 a3)
{
  unsigned int v6; // ecx
  __int64 v7; // rsi
  unsigned __int64 v8; // rdi
  unsigned int v9; // edx
  __int64 v10; // r15
  unsigned __int64 v11; // rsi
  RBX::Network::NetworkTracer *v12; // rdi
  unsigned int v13; // r12d
  __int64 v14; // rax
  __int64 v15; // r15
  __int64 v16; // r14
  char v17; // al
  __int64 v18; // rax
  __int64 v19; // rcx
  __int64 v20; // rax
  bool v21; // zf
  __int64 v22; // rcx
  __int64 v23; // rdi
  _QWORD *v24; // rsi
  unsigned int v25; // ecx
  __int64 v26; // rsi
  unsigned __int64 v27; // rdi
  unsigned int v28; // edx
  __int64 v29; // rsi
  unsigned __int64 v30; // rdi
  unsigned int v31; // edx
  unsigned int v32; // eax
  int v33; // ecx
  int v34; // eax
  __int64 v35; // r13
  unsigned __int64 v36; // rsi
  _BYTE *v37; // rax
  __int64 v38; // r13
  __int64 v39; // rax
  __int64 v40; // rcx
  __int64 v41; // rdx
  __int64 v42; // rcx
  bool v43; // zf
  __int64 v44; // rdx
  __int64 v45; // rax
  __int64 v46; // rbx
  __int64 v47; // rax
  __int64 v49; // [rsp+8h] [rbp-38h] BYREF
  char v50[41]; // [rsp+17h] [rbp-29h] BYREF

  v6 = *a2; /*0x1039de7ce*/
  v7 = *(_QWORD *)(a1 + 176); /*0x1039de7d0*/
  v8 = (unsigned __int64)(*(_QWORD *)(a1 + 184) - v7) >> 3; /*0x1039de7e1*/
  if ( (((_DWORD)v8 - 1) & (unsigned int)v8) != 0 ) /*0x1039de7ea*/
    v9 = v6 % (unsigned int)v8; /*0x1039de7f4*/
  else
    v9 = v6 & (v8 - 1); /*0x1039de7ec*/
  v10 = *(_QWORD *)(v7 + 8LL * v9); /*0x1039de7f8*/
  if ( v10 != 0 && *(_DWORD *)v10 == v6 ) /*0x1039de804*/
  {
    v11 = *(_QWORD *)(v10 + 264); /*0x1039de806*/
    if ( v11 != 0 ) /*0x1039de810*/
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039de820*/
        v12 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039de826*/
      else
        v12 = nullptr; /*0x1039de908*/
      RBX::Network::NetworkTracer::removeTracerObject(this: v12, a2: v11); /*0x1039de90a*/
      *(_QWORD *)(v10 + 264) = 0; /*0x1039de90f*/
    }
    ++*(_BYTE *)(v10 + 89); /*0x1039de91a*/
    if ( *(_BYTE *)(v10 + 90) == 1 ) /*0x1039de923*/
      --*(_DWORD *)(a1 + 920); /*0x1039de925*/
    v25 = *a2; /*0x1039de92b*/
    v26 = *(_QWORD *)(a1 + 176); /*0x1039de92f*/
    v27 = (unsigned __int64)(*(_QWORD *)(a1 + 184) - v26) >> 3; /*0x1039de940*/
    if ( (((_DWORD)v27 - 1) & (unsigned int)v27) != 0 ) /*0x1039de949*/
      v28 = v25 % (unsigned int)v27; /*0x1039de953*/
    else
      v28 = v25 & (v27 - 1); /*0x1039de94b*/
    *(_QWORD *)(v26 + 8LL * v28) = 0; /*0x1039de957*/
    if ( *(_DWORD *)(a1 + 424) == v25 ) /*0x1039de965*/
    {
      v29 = *(_QWORD *)(a1 + 176); /*0x1039de96b*/
      v30 = (unsigned __int64)(*(_QWORD *)(a1 + 184) - v29) >> 3; /*0x1039de97c*/
      do /*0x1039de9eb*/
      {
        if ( (16843009 /*0x1039de9bf*/
            * (((((_DWORD)v30 - (((unsigned int)v30 >> 1) & 0x55555555)) & 0x33333333)
              + ((((unsigned int)v30 - (((unsigned int)v30 >> 1) & 0x55555555)) >> 2) & 0x33333333)
              + (((((_DWORD)v30 - (((unsigned int)v30 >> 1) & 0x55555555)) & 0x33333333)
                + ((((unsigned int)v30 - (((unsigned int)v30 >> 1) & 0x55555555)) >> 2) & 0x33333333)) >> 4))
             & 0xF0F0F0F)) >> 24 > 1 )
          v31 = v25 % (unsigned int)v30; /*0x1039de9cc*/
        else
          v31 = v25 & (v30 - 1); /*0x1039de9c4*/
        if ( *(_QWORD *)(v29 + 8LL * v31) != 0 ) /*0x1039de9d5*/
          break; /*0x1039de9d5*/
        v25 = (v25 + 1) & 0xFFFFFF; /*0x1039de9d9*/
        *(_DWORD *)(a1 + 424) = v25; /*0x1039de9df*/
      }
      while ( v25 < *(_DWORD *)(a1 + 428) ); /*0x1039de9eb*/
    }
    --*(_DWORD *)(a1 + 872); /*0x1039de9ed*/
    v32 = *(_DWORD *)(v10 + 24) + 7; /*0x1039de9f7*/
    *(_QWORD *)(a1 + 880) -= v32 >> 3; /*0x1039de9ff*/
    *(double *)(a1 + 3120) = (double)((*(_DWORD *)(v10 + 60) + v32) >> 3) + *(double *)(a1 + 3120); /*0x1039dea19*/
    v33 = *(_DWORD *)(v10 + 28); /*0x1039dea21*/
    if ( v33 >= 6 ) /*0x1039dea28*/
    {
      v34 = *(_DWORD *)(v10 + 20); /*0x1039dea2e*/
      if ( v34 == 0 || *(_DWORD *)(v10 + 16) + 1 == v34 ) /*0x1039dea3e*/
      {
        v35 = DataStructures::MemoryPool<RakNet::InternalPacket>::Allocate( /*0x1039dea5f*/
                a1: (__int64 *)(a1 + 144),
                a2: (unsigned __int64)"",
                a3: 0);
        *(_DWORD *)v35 = 0xFFFFFF; /*0x1039dea62*/
        *(_BYTE *)(v35 + 36) = 0; /*0x1039dea68*/
        *(_QWORD *)(v35 + 48) = 0; /*0x1039dea6c*/
        *(_DWORD *)(v35 + 20) = 0; /*0x1039dea70*/
        *(_QWORD *)(v35 + 64) = 0; /*0x1039dea74*/
        *(_WORD *)(v35 + 88) = 0; /*0x1039dea78*/
        *(_BYTE *)(v35 + 90) = 0; /*0x1039dea7e*/
        *(_QWORD *)(v35 + 264) = 0; /*0x1039dea82*/
        v49 = v35; /*0x1039dea8d*/
        *(_DWORD *)(v35 + 72) = 0; /*0x1039dea90*/
        v37 = (_BYTE *)RBX::Memory::allocateOrCrash(this: (RBX::Memory *)5, a2: v36); /*0x1039dea9c*/
        *(_QWORD *)(v35 + 64) = v37; /*0x1039deaa1*/
        *(_DWORD *)(v35 + 24) = 40; /*0x1039deaa5*/
        *v37 = 14; /*0x1039deaad*/
        *(_DWORD *)(*(_QWORD *)(v35 + 64) + 1LL) = *(_DWORD *)(v10 + 96); /*0x1039deab8*/
        DataStructures::Queue<RakNet::InternalPacket *>::Push(a1: a1 + 16, a2: &v49); /*0x1039deacc*/
        v33 = *(_DWORD *)(v10 + 28); /*0x1039dead1*/
      }
    }
    RakNet::ReliabilityLayer::ResendListRemove( /*0x1039deaea*/
      a1,
      a2: v10,
      a3: ((unsigned int)v33 < 8) & (unsigned __int8)(0xDCu >> v33));
    v13 = 0; /*0x1039deaf6*/
    RakNet::ReliabilityLayer::FreeInternalPacketData(a1, a2: v10); /*0x1039deb01*/
    if ( DFFlag::GameLoadDataStatistics != 1 || *(_BYTE *)(v10 + 89) == *(_BYTE *)(v10 + 88) ) /*0x1039deb17*/
    {
      v23 = a1 + 144; /*0x1039deb27*/
      v24 = (_QWORD *)v10; /*0x1039deb2a*/
LABEL_46:
      DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: v23, a2: v24); /*0x1039deb2d*/
      return v13; /*0x1039deb34*/
    }
    v49 = v10; /*0x1039deb44*/
    v38 = std::__tree<std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>,std::__map_value_compare<RakNet::uint24_t,std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>,std::less<RakNet::uint24_t>,true>,std::allocator<std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>>>::__emplace_unique_key_args<RakNet::uint24_t,std::piecewise_construct_t const&,std::tuple<RakNet::uint24_t const&>,std::tuple<>>( /*0x1039deb5a*/
            a1: a1 + 216,
            a2: v10,
            a3: std::piecewise_construct,
            a4: &v49,
            a5: v50);
    v39 = *(_QWORD *)(v38 + 40); /*0x1039deb5d*/
    if ( v39 != 0 ) /*0x1039deb64*/
    {
      v40 = *(_QWORD *)(v39 + 104); /*0x1039deb66*/
      v41 = *(_QWORD *)(v39 + 112); /*0x1039deb6a*/
      *(_QWORD *)(v40 + 112) = v41; /*0x1039deb6e*/
      *(_QWORD *)(v41 + 104) = v40; /*0x1039deb72*/
      v42 = *(_QWORD *)(a1 + 240); /*0x1039deb76*/
      v43 = v42 == v39; /*0x1039deb7d*/
      if ( v42 == v39 ) /*0x1039deb80*/
        v42 = v41; /*0x1039deb80*/
      if ( v42 == v39 || v43 ) /*0x1039deb84*/
      {
        v44 = 0; /*0x1039deb93*/
        if ( v42 != v39 ) /*0x1039deb98*/
          v44 = v42; /*0x1039deb98*/
        *(_QWORD *)(a1 + 240) = v44; /*0x1039deb9c*/
      }
      DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: a1 + 144, a2: *(_QWORD **)(v38 + 40)); /*0x1039debb7*/
    }
    *(_QWORD *)(v38 + 40) = v10; /*0x1039debbc*/
    *(_QWORD *)(v10 + 48) = a3 /*0x1039debd4*/
                          + 2
                          * (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a1 + 3032) + 184LL))(a1: *(_QWORD *)(a1 + 3032));
    v45 = *(_QWORD *)(a1 + 240); /*0x1039debd8*/
    v46 = a1 + 240; /*0x1039debdf*/
    if ( v45 != 0 ) /*0x1039debe9*/
    {
      *(_QWORD *)(v10 + 112) = v45; /*0x1039debeb*/
      v47 = *(_QWORD *)(*(_QWORD *)v46 + 104LL); /*0x1039debf2*/
      *(_QWORD *)(v10 + 104) = v47; /*0x1039debf6*/
      *(_QWORD *)(v47 + 112) = v10; /*0x1039debfa*/
      v46 = *(_QWORD *)v46 + 104LL; /*0x1039dec01*/
    }
    else
    {
      *(_QWORD *)(v10 + 112) = v10; /*0x1039dec07*/
      *(_QWORD *)(v10 + 104) = v10; /*0x1039dec0b*/
    }
    *(_QWORD *)v46 = v10; /*0x1039dec0f*/
  }
  else
  {
    v13 = -1; /*0x1039de82f*/
    if ( DFFlag::GameLoadDataStatistics == 1 ) /*0x1039de83c*/
    {
      v14 = *(_QWORD *)(a1 + 224); /*0x1039de842*/
      if ( v14 != 0 ) /*0x1039de84c*/
      {
        v15 = a1 + 224; /*0x1039de860*/
        do /*0x1039de877*/
        {
          if ( *(_DWORD *)(v14 + 32) >= v6 ) /*0x1039de86c*/
            v15 = v14; /*0x1039de86c*/
          v14 = *(_QWORD *)(v14 + 8LL * (*(_DWORD *)(v14 + 32) < v6)); /*0x1039de870*/
        }
        while ( v14 != 0 ); /*0x1039de877*/
        if ( v15 != a1 + 224 && v6 >= *(_DWORD *)(v15 + 32) ) /*0x1039de886*/
        {
          v16 = *(_QWORD *)(v15 + 40); /*0x1039de88c*/
          v17 = *(_BYTE *)(v16 + 89) + 1; /*0x1039de894*/
          *(_BYTE *)(v16 + 89) = v17; /*0x1039de896*/
          if ( v17 == *(_BYTE *)(v16 + 88) ) /*0x1039de89e*/
          {
            std::__tree<std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>,std::__map_value_compare<RakNet::uint24_t,std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>,std::less<RakNet::uint24_t>,true>,std::allocator<std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>>>::__remove_node_pointer( /*0x1039de8a7*/
              a1: a1 + 216,
              a2: v15);
            operator delete(a1: (void *)v15); /*0x1039de8af*/
            v18 = *(_QWORD *)(v16 + 104); /*0x1039de8b4*/
            v19 = *(_QWORD *)(v16 + 112); /*0x1039de8b8*/
            *(_QWORD *)(v18 + 112) = v19; /*0x1039de8bc*/
            *(_QWORD *)(v19 + 104) = v18; /*0x1039de8c0*/
            v20 = *(_QWORD *)(a1 + 240); /*0x1039de8c4*/
            v21 = v20 == v16; /*0x1039de8cb*/
            if ( v20 == v16 ) /*0x1039de8ce*/
              v20 = v19; /*0x1039de8ce*/
            if ( v20 == v16 || v21 ) /*0x1039de8d2*/
            {
              v22 = 0; /*0x1039de8df*/
              if ( v20 != v16 ) /*0x1039de8e4*/
                v22 = v20; /*0x1039de8e4*/
              *(_QWORD *)(a1 + 240) = v22; /*0x1039de8e8*/
            }
            v23 = a1 + 144; /*0x1039de8fd*/
            v24 = (_QWORD *)v16; /*0x1039de900*/
            goto LABEL_46; /*0x1039de903*/
          }
        }
      }
    }
  }
  return v13; /*0x1039dec15*/
}

// Address: 0x1039dec24 | Name: __ZNK6RakNet16ReliabilityLayer17ResendBufferIndexENS_8uint24_tE
__int64 __fastcall RakNet::ReliabilityLayer::ResendBufferIndex(__int64 a1, unsigned int *a2)
{
  unsigned int v2; // ecx
  __int64 v3; // r8

  v2 = *a2; /*0x1039dec36*/
  v3 = (*(_QWORD *)(a1 + 184) - *(_QWORD *)(a1 + 176)) >> 3; /*0x1039dec38*/
  if ( (((_DWORD)v3 - 1) & (unsigned int)v3) != 0 ) /*0x1039dec43*/
    return v2 % (unsigned int)v3; /*0x1039dec50*/
  else
    return v2 & ((_DWORD)v3 - 1); /*0x1039dec45*/
}

// Address: 0x1039dede4 | Name: __ZN6RakNet16ReliabilityLayer25SendAcknowledgementPacketENS_8uint24_tEy
__int64 __fastcall RakNet::ReliabilityLayer::SendAcknowledgementPacket(__int64 a1, unsigned int *a2, __int64 a3)
{
  unsigned int v4; // [rsp+Ch] [rbp-4h] BYREF

  *(_QWORD *)(a1 + 3024) = a3; /*0x1039dedec*/
  v4 = *a2; /*0x1039dee00*/
  return DataStructures::RangeList<RakNet::uint24_t>::Insert(a1: a1 + 3160, a2: &v4); /*0x1039dee07*/
}

// Address: 0x1039dee0e | Name: __ZN6RakNet16ReliabilityLayer33CreateInternalPacketFromBitStreamEPNS_9BitStreamEy
__int64 __fastcall RakNet::ReliabilityLayer::CreateInternalPacketFromBitStream(
        RakNet::ReliabilityLayer *this,
        RakNet::BitStream *a2,
        unsigned __int64 a3)
{
  unsigned int v3; // r15d
  __int64 v6; // rbx
  unsigned int v7; // edx
  unsigned int v8; // ecx
  unsigned int v9; // eax
  char AlignedVar8; // r13
  int v11; // edx
  __int64 v12; // rax
  RBX::Network::NetworkTracerStream *v13; // rsi
  RBX::Network *v14; // rdi
  unsigned __int8 v15; // al
  RakNet::ReliabilityLayer *v16; // rax
  unsigned __int8 v17; // al
  char v18; // al
  RBX::Network *v19; // r14
  __int64 (*v20)(void); // rcx
  unsigned __int8 v21; // al
  RakNet *v22; // rdi
  unsigned int TimeMS; // eax
  unsigned int v24; // eax
  int v25; // ecx
  char *v26; // rsi
  int v27; // eax
  unsigned int v28; // eax
  __int64 v29; // rax
  __int64 v30; // rdx
  unsigned __int16 v32[32]; // [rsp+0h] [rbp-A0h] BYREF
  __int64 v33; // [rsp+40h] [rbp-60h] BYREF
  RBX::Network *v34; // [rsp+48h] [rbp-58h]
  int v35; // [rsp+50h] [rbp-50h]
  __int64 v36; // [rsp+58h] [rbp-48h]
  RBX::Network *v37; // [rsp+60h] [rbp-40h]
  unsigned __int8 v38; // [rsp+6Fh] [rbp-31h] BYREF
  RakNet::ReliabilityLayer *v39; // [rsp+70h] [rbp-30h]

  LOBYTE(v3) = 0; /*0x1039dee25*/
  if ( (unsigned int)(*((_DWORD *)a2 + 3) - *((_DWORD *)a2 + 5)) < 0x20 ) /*0x1039dee2b*/
    return 0; /*0x1039dee2b*/
  v39 = this; /*0x1039dee37*/
  v36 = (__int64)this + 144; /*0x1039dee49*/
  v6 = DataStructures::MemoryPool<RakNet::InternalPacket>::Allocate( /*0x1039dee54*/
         a1: (__int64 *)this + 18,
         a2: (unsigned __int64)"",
         a3: 0);
  *(_DWORD *)v6 = 0xFFFFFF; /*0x1039dee57*/
  *(_BYTE *)(v6 + 36) = 0; /*0x1039dee5d*/
  *(_QWORD *)(v6 + 48) = 0; /*0x1039dee61*/
  *(_DWORD *)(v6 + 20) = 0; /*0x1039dee65*/
  *(_DWORD *)(v6 + 72) = 0; /*0x1039dee69*/
  *(_QWORD *)(v6 + 64) = 0; /*0x1039dee6d*/
  *(_WORD *)(v6 + 88) = 0; /*0x1039dee71*/
  *(_BYTE *)(v6 + 90) = 0; /*0x1039dee77*/
  *(_QWORD *)(v6 + 264) = 0; /*0x1039dee7b*/
  *(_QWORD *)(v6 + 40) = a3; /*0x1039dee82*/
  *((_DWORD *)a2 + 5) += -*((_DWORD *)a2 + 5) & 7; /*0x1039dee94*/
  RakNet::BitStream::ReadBits(this: a2, a2: &v38, a3: 3u, a4: true); /*0x1039deead*/
  *(_DWORD *)(v6 + 28) = v38; /*0x1039deeb7*/
  v7 = *((_DWORD *)a2 + 3); /*0x1039deeba*/
  v8 = *((_DWORD *)a2 + 5); /*0x1039deebf*/
  v9 = v8 + 1; /*0x1039deec4*/
  AlignedVar8 = v8 + 1 <= v7; /*0x1039deec9*/
  if ( v8 + 1 > v7 ) /*0x1039deecd*/
  {
    v9 = *((_DWORD *)a2 + 5); /*0x1039deeef*/
  }
  else
  {
    v3 = (unsigned int)(*(unsigned __int8 *)(*((_QWORD *)a2 + 3) + (v8 >> 3)) << (v8 & 7)) >> 7; /*0x1039deee1*/
    *((_DWORD *)a2 + 5) = v9; /*0x1039deee8*/
  }
  if ( (*((_BYTE *)v39 + 4114) & 8) != 0 ) /*0x1039deefc*/
  {
    if ( v9 + 1 <= v7 ) /*0x1039def16*/
    {
      v11 = *(unsigned __int8 *)(*((_QWORD *)a2 + 3) + (v9 >> 3)) << (v9 & 7); /*0x1039def41*/
      *((_DWORD *)a2 + 5) = v9 - (v9 | 0xFFFFFFF8); /*0x1039def4a*/
      AlignedVar8 = 1; /*0x1039def4f*/
      if ( (v11 & 0x80u) != 0 ) /*0x1039def54*/
      {
        v12 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1039def61*/
        RBX::Network::NetworkStream::NetworkStream( /*0x1039def87*/
          this: (RBX::Network::NetworkStream *)v32,
          a2: (unsigned __int8 *)(v12 + (*((_DWORD *)a2 + 5) >> 3)),
          a3: (unsigned int)(*((_DWORD *)a2 + 3) - *((_DWORD *)a2 + 5)) >> 3,
          a4: true);
        if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039def96*/
          v13 = *(RBX::Network::NetworkTracerStream **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle /*0x1039def98*/
                                                      + 24);
        else
          v13 = nullptr; /*0x1039def9e*/
        RBX::Network::NetworkTracer::createTracerObjectFromStream(this: (RBX::Network::NetworkTracer *)&v33, a2: v13); /*0x1039defab*/
        if ( v35 == 0 ) /*0x1039defb4*/
        {
          RakNet::ReliabilityLayer::FreeInternalPacketData(a1: (__int64)v39, a2: v6); /*0x1039defe2*/
          DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: v36, a2: (_QWORD *)v6); /*0x1039deff7*/
          v16 = v39; /*0x1039deffc*/
          *((_BYTE *)v39 + 436) = 1; /*0x1039df000*/
          *((_DWORD *)v16 + 110) = 261; /*0x1039df007*/
          RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v32); /*0x1039df018*/
          return 0; /*0x1039df2c4*/
        }
        if ( DFFlag::EnablePingPongPerformanceTraceCLI != 0 || DFFlag::RakNetPingTrace != 0 ) /*0x1039defcc*/
          v15 = 0; /*0x1039defce*/
        else
          v15 = DFFlag::DataPingTrace ^ 1; /*0x1039df02b*/
        if ( (v15 | (v34 == nullptr)) == 0 ) /*0x1039df039*/
        {
          if ( DFFlag::AddRecieveCheckpointToNetworkTracer == 1 ) /*0x1039df046*/
          {
            v37 = v34; /*0x1039df04c*/
            v17 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)v39 + 518) + 200LL))(a1: *((_QWORD *)v39 + 518)); /*0x1039df05a*/
            RBX::Network::NetworkTracerObject::addCheckpoint_deprecated(a1: v37, a2: v17, a3: 76, a4: a3 / 0x3E8); /*0x1039df08a*/
          }
          v18 = RBX::Network::flagsSendsGoThroughConnection(this: v14); /*0x1039df08f*/
          v19 = v34; /*0x1039df094*/
          v20 = *(__int64 (**)(void))(**((_QWORD **)v39 + 518) + 200LL); /*0x1039df0a6*/
          if ( v18 != 0 ) /*0x1039df0af*/
          {
            v21 = v20(); /*0x1039df0b1*/
            RBX::Network::NetworkTracerObject::addCheckpoint(a1: v19, a2: v21, a3: 68); /*0x1039df0be*/
          }
          else
          {
            LOBYTE(v37) = v20(); /*0x1039df0c7*/
            TimeMS = RakNet::GetTimeMS(this: v22); /*0x1039df0ca*/
            RBX::Network::NetworkTracerObject::addCheckpoint_deprecated( /*0x1039df0dd*/
              a1: v19,
              a2: (unsigned __int8)v37,
              a3: 68,
              a4: TimeMS);
          }
        }
        *(_QWORD *)(v6 + 264) = v33; /*0x1039df0e6*/
        *((_DWORD *)a2 + 5) += 8 * v35 + (-*((_DWORD *)a2 + 5) & 7); /*0x1039df0ff*/
        RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v32); /*0x1039df10b*/
      }
    }
    else
    {
      *((_DWORD *)a2 + 5) = v9 + (-v9 & 7); /*0x1039def21*/
      AlignedVar8 = 0; /*0x1039def26*/
    }
  }
  else
  {
    *((_DWORD *)a2 + 5) = v9 + (-v9 & 7); /*0x1039def07*/
  }
  RakNet::BitStream::ReadAlignedVar16(this: a2, a2: (char *)v32); /*0x1039df11d*/
  *(_DWORD *)(v6 + 24) = v32[0]; /*0x1039df126*/
  v24 = *(_DWORD *)(v6 + 28); /*0x1039df129*/
  if ( v24 - 2 > 2 ) /*0x1039df132*/
  {
    *(_DWORD *)v6 = 0xFFFFFF; /*0x1039df144*/
  }
  else
  {
    RakNet::BitStream::Read<RakNet::uint24_t>(a1: a2, a2: v6); /*0x1039df13a*/
    v24 = *(_DWORD *)(v6 + 28); /*0x1039df13f*/
  }
  *((_DWORD *)a2 + 5) += -*((_DWORD *)a2 + 5) & 7; /*0x1039df158*/
  if ( v24 == 4 || v24 == 1 ) /*0x1039df165*/
  {
    RakNet::BitStream::Read<RakNet::uint24_t>(a1: a2, a2: v6 + 8); /*0x1039df16e*/
    v24 = *(_DWORD *)(v6 + 28); /*0x1039df173*/
  }
  if ( v24 <= 7 && (v25 = 154, _bittest(&v25, v24)) ) /*0x1039df184*/
  {
    RakNet::BitStream::Read<RakNet::uint24_t>(a1: a2, a2: v6 + 4); /*0x1039df194*/
    AlignedVar8 = RakNet::BitStream::ReadAlignedVar8(this: a2, a2: (char *)(v6 + 12)); /*0x1039df1a5*/
  }
  else
  {
    *(_BYTE *)(v6 + 12) = 0; /*0x1039df295*/
  }
  v26 = (char *)(v6 + 20); /*0x1039df1a8*/
  if ( (_BYTE)v3 != 0 ) /*0x1039df1af*/
  {
    RakNet::BitStream::ReadAlignedVar32(this: a2, a2: v26); /*0x1039df1b4*/
    RakNet::BitStream::ReadAlignedVar16(this: a2, a2: (char *)(v6 + 14)); /*0x1039df1c0*/
    if ( (unsigned __int8)RakNet::BitStream::ReadAlignedVar32(this: a2, a2: (char *)(v6 + 16)) == 0 ) /*0x1039df1d6*/
      goto LABEL_50; /*0x1039df1d6*/
  }
  else
  {
    *(_DWORD *)v26 = 0; /*0x1039df1dd*/
    if ( AlignedVar8 == 0 ) /*0x1039df1e6*/
    {
LABEL_50:
      DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: v36, a2: (_QWORD *)v6); /*0x1039df2af*/
      return 0; /*0x1039df2bf*/
    }
  }
  v27 = *(_DWORD *)(v6 + 24); /*0x1039df1ec*/
  if ( v27 == 0 /*0x1039df21f*/
    || *(int *)(v6 + 28) > 7
    || *(_BYTE *)(v6 + 12) > 0x1Fu
    || (_BYTE)v3 != 0 && (*(_DWORD *)(v6 + 16) >= *(_DWORD *)(v6 + 20) || *(_DWORD *)(v6 + 20) >= 0x7A121u) )
  {
    goto LABEL_50; /*0x1039df224*/
  }
  v28 = (unsigned int)(v27 + 7) >> 3; /*0x1039df22d*/
  if ( v28 > **((_DWORD **)v39 + 57) ) /*0x1039df23d*/
    goto LABEL_50; /*0x1039df23d*/
  *(_DWORD *)(v6 + 72) = 0; /*0x1039df241*/
  v29 = RBX::Memory::allocateOrCrash(this: (RBX::Memory *)v28, a2: (unsigned __int64)v26); /*0x1039df248*/
  *(_QWORD *)(v6 + 64) = v29; /*0x1039df24d*/
  if ( v29 == 0 ) /*0x1039df254*/
  {
    RakNet::notifyOutOfMemory(this: (RakNet *)"", a2: (const char *)2, a3: v30); /*0x1039df2aa*/
    goto LABEL_50; /*0x1039df2aa*/
  }
  *(_BYTE *)(v29 + ((unsigned int)(*(_DWORD *)(v6 + 24) + 7) >> 3) - 1) = 0; /*0x1039df261*/
  if ( (unsigned __int8)RakNet::BitStream::ReadAlignedBytes( /*0x1039df27c*/
                          this: a2,
                          a2: *(unsigned __int8 **)(v6 + 64),
                          a3: (unsigned int)(*(_DWORD *)(v6 + 24) + 7) >> 3) == 0 )
  {
    RakNet::ReliabilityLayer::FreeInternalPacketData(a1: (__int64)v39, a2: v6); /*0x1039df28e*/
    goto LABEL_50; /*0x1039df293*/
  }
  return v6; /*0x1039df2c9*/
}

// Address: 0x1039df4c4 | Name: __ZN6RakNet16ReliabilityLayer25InsertIntoSplitPacketListEPNS_14InternalPacketEy
void __fastcall RakNet::ReliabilityLayer::InsertIntoSplitPacketList(
        RakNet::ReliabilityLayer *this,
        __int64 a2,
        _QWORD *a3)
{
  __int64 *v5; // r12
  unsigned __int16 *v6; // r13
  unsigned int v7; // eax
  signed int v8; // ecx
  unsigned int v9; // r8d
  unsigned int v10; // esi
  int v11; // edi
  __int64 v12; // r15
  __int64 v13; // r8
  unsigned int v14; // r9d
  signed int v15; // r8d
  int v16; // r15d
  __int64 v17; // rax
  __int64 v18; // r15
  __int64 v19; // rax
  __int64 v20; // rax
  unsigned int v21; // ecx
  __int64 v22; // rcx
  __int64 v23; // rsi
  __int64 v24; // rcx
  unsigned int v25; // esi
  __int64 v26; // rax
  unsigned int v27; // r12d
  unsigned int v28; // r13d
  unsigned __int64 v29; // rsi
  _BYTE *v30; // rax
  _QWORD *v31; // rdx
  __int64 v32; // rax
  __int64 v33; // [rsp+10h] [rbp-60h] BYREF
  void *v34; // [rsp+18h] [rbp-58h] BYREF
  _BYTE *v35; // [rsp+20h] [rbp-50h]
  __int64 v36; // [rsp+30h] [rbp-40h]
  unsigned int v37; // [rsp+3Ch] [rbp-34h]
  _QWORD *v38; // [rsp+40h] [rbp-30h]

  v5 = (__int64 *)((char *)this + 408); /*0x1039df4db*/
  v6 = (unsigned __int16 *)(a2 + 14); /*0x1039df4e2*/
  v7 = *((_DWORD *)this + 104); /*0x1039df4e6*/
  if ( v7 != 0 ) /*0x1039df4ee*/
  {
    v8 = v7 - 1; /*0x1039df4f4*/
    v9 = (int)v7 / 2; /*0x1039df501*/
    v10 = *v6; /*0x1039df508*/
    v11 = 0; /*0x1039df50d*/
    while ( 1 ) /*0x1039df50f*/
    {
      v12 = v9; /*0x1039df50f*/
      v13 = *(_QWORD *)(*v5 + 8LL * v9); /*0x1039df512*/
      v14 = *(_DWORD *)(v13 + 40); /*0x1039df516*/
      if ( v14 == v10 ) /*0x1039df51d*/
        break; /*0x1039df51d*/
      v15 = v12 - 1; /*0x1039df523*/
      v16 = v12 + 1; /*0x1039df527*/
      if ( v14 <= v10 ) /*0x1039df52d*/
        v11 = v16; /*0x1039df531*/
      else
        v8 = v15; /*0x1039df52d*/
      v9 = v11 + (v8 - v11) / 2; /*0x1039df548*/
      if ( v8 < v11 ) /*0x1039df54d*/
      {
        if ( v7 >= 0x40 && DFFlag::RakNetCapSplitPacketAllocation != 0 ) /*0x1039df55b*/
        {
          RakNet::ReliabilityLayer::FreeInternalPacketData(a1: (__int64)this, a2); /*0x1039df56f*/
          DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: (__int64)this + 144, (_QWORD *)a2); /*0x1039df583*/
          if ( DFFlag::RakNetCapSplitPacketAllocationV2 == 1 ) /*0x1039df58f*/
          {
            *((_BYTE *)this + 436) = 1; /*0x1039df595*/
            *((_DWORD *)this + 110) = 299; /*0x1039df59c*/
          }
          return; /*0x1039df5a6*/
        }
        goto LABEL_12; /*0x1039df55b*/
      }
    }
  }
  else
  {
LABEL_12:
    v38 = a3; /*0x1039df5ab*/
    v17 = operator new(a1: 0x38u); /*0x1039df5b4*/
    *(_OWORD *)(v17 + 8) = 0; /*0x1039df5bc*/
    *(_OWORD *)(v17 + 24) = 0; /*0x1039df5c0*/
    v33 = v17; /*0x1039df5c8*/
    *(_QWORD *)(v17 + 48) = 0; /*0x1039df5cb*/
    v37 = DataStructures::OrderedList<unsigned short,RakNet::SplitPacketChannel *,&RakNet::SplitPacketChannelComp>::Insert( /*0x1039df5fe*/
            a1: (__int64)v5,
            a2: (__int64)v6,
            a3: &v33,
            a4: 1,
            a5: (__int64)"ReliabilityLayer.cpp",
            a6: 3980,
            a7: (__int64 (__fastcall *)(__int64, __int64))RakNet::SplitPacketChannelComp);
    RakNet::SplitPacketList::SplitPacketList(this: (RakNet::SplitPacketList *)&v34, a2: *(_DWORD *)(a2 + 20)); /*0x1039df60c*/
    v18 = v33; /*0x1039df611*/
    v19 = v33; /*0x1039df618*/
    if ( (void **)(v33 + 8) != &v34 ) /*0x1039df61e*/
    {
      std::vector<RakNet::InternalPacket *>::__assign_with_size[abi:ne200100]<RakNet::InternalPacket **,RakNet::InternalPacket **>( /*0x1039df632*/
        a1: v33 + 8,
        a2: v34,
        a3: v35,
        a4: (v35 - (_BYTE *)v34) >> 3);
      v19 = v33; /*0x1039df637*/
    }
    *(_QWORD *)(v18 + 32) = v36; /*0x1039df63f*/
    *(_DWORD *)(v19 + 40) = *(unsigned __int16 *)(a2 + 14); /*0x1039df648*/
    *(_DWORD *)(v19 + 44) = *(_DWORD *)(a2 + 20); /*0x1039df64f*/
    if ( v34 != nullptr ) /*0x1039df659*/
    {
      v35 = v34; /*0x1039df65b*/
      operator delete(a1: v34); /*0x1039df65f*/
    }
    v12 = v37; /*0x1039df668*/
    v13 = *(_QWORD *)(*v5 + 8LL * v37); /*0x1039df66c*/
    a3 = v38; /*0x1039df670*/
  }
  v20 = *(unsigned int *)(a2 + 16); /*0x1039df674*/
  v21 = *(_DWORD *)(v13 + 36); /*0x1039df678*/
  if ( (unsigned int)v20 < v21 && *(_DWORD *)(a2 + 20) == v21 ) /*0x1039df688*/
  {
    v22 = *(_QWORD *)(v13 + 8); /*0x1039df68e*/
    if ( *(_QWORD *)(v22 + 8 * v20) == 0 ) /*0x1039df697*/
      ++*(_DWORD *)(v13 + 32); /*0x1039df699*/
    *(_QWORD *)(v22 + 8 * v20) = a2; /*0x1039df69d*/
    v23 = *v5; /*0x1039df6a1*/
    v24 = *(_QWORD *)(*v5 + 8 * v12); /*0x1039df6a5*/
    *(_QWORD *)v24 = a3; /*0x1039df6a9*/
    if ( v20 == 0 ) /*0x1039df6af*/
    {
      *(_QWORD *)(v24 + 48) = a2; /*0x1039df6b1*/
      v24 = *(_QWORD *)(v23 + 8 * v12); /*0x1039df6b5*/
    }
    v25 = *((_DWORD *)this + 10); /*0x1039df6b9*/
    if ( v25 != 0 ) /*0x1039df6be*/
    {
      v26 = *(_QWORD *)(v24 + 48); /*0x1039df6c4*/
      if ( v26 != 0 ) /*0x1039df6cb*/
      {
        v27 = *(_DWORD *)(v24 + 32); /*0x1039df6d1*/
        if ( v27 != *(_DWORD *)(v26 + 20) && v27 % v25 == 0 ) /*0x1039df6e8*/
        {
          v34 = (void *)RakNet::ReliabilityLayer::AllocateFromInternalPacketPool(this); /*0x1039df6fa*/
          v38 = v34; /*0x1039df700*/
          v28 = (unsigned int)(*(_DWORD *)(*(_QWORD *)(*(_QWORD *)(*((_QWORD *)this + 51) + 8 * v12) + 48LL) + 24LL) + 7) >> 3; /*0x1039df71b*/
          *((_DWORD *)v34 + 18) = 0; /*0x1039df723*/
          v30 = (_BYTE *)RBX::Memory::allocateOrCrash(this: (RBX::Memory *)(v28 + 13), a2: v29); /*0x1039df72a*/
          v31 = v38; /*0x1039df72f*/
          v38[8] = v30; /*0x1039df733*/
          *((_DWORD *)v31 + 6) = 8 * v28 + 104; /*0x1039df73f*/
          *v30 = 30; /*0x1039df742*/
          *(_DWORD *)(v31[8] + 1LL) = v27; /*0x1039df749*/
          *(_DWORD *)(v31[8] + 5LL) = *(_DWORD *)(a2 + 20); /*0x1039df755*/
          *(_DWORD *)(v31[8] + 9LL) = (unsigned int)(*(_DWORD *)(*(_QWORD *)(*(_QWORD *)(*((_QWORD *)this + 51) + 8 * v12) /*0x1039df774*/
                                                                           + 48LL)
                                                               + 24LL)
                                                   + 7) >> 3;
          v32 = *(_QWORD *)(*(_QWORD *)(*((_QWORD *)this + 51) + 8 * v12) + 48LL); /*0x1039df78a*/
          memcpy( /*0x1039df79b*/
            __dst: (void *)(v31[8] + 13LL),
            __src: *(const void **)(v32 + 64),
            __n: (unsigned int)(*(_DWORD *)(v32 + 24) + 7) >> 3);
          DataStructures::Queue<RakNet::InternalPacket *>::Push(a1: (__int64)this + 16, a2: (__int64 *)&v34); /*0x1039df7b7*/
        }
      }
    }
  }
  else
  {
    RakNet::ReliabilityLayer::FreeInternalPacketData(a1: (__int64)this, a2); /*0x1039df7d0*/
    DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: (__int64)this + 144, (_QWORD *)a2); /*0x1039df7e7*/
  }
}

// Address: 0x1039df818 | Name: __ZN6RakNet16ReliabilityLayer30BuildPacketFromSplitPacketListEtyNSt3__110shared_ptrINS_12RakNetSocketEEERKNS_13SystemAddressERNS_9BitStreamERKNS2_IN3RBX4Rupp4RuppEEES7_
__int64 __fastcall RakNet::ReliabilityLayer::BuildPacketFromSplitPacketList(
        RakNet::ReliabilityLayer *this,
        unsigned __int16 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int64 a7,
        __int64 a8)
{
  int v10; // edi
  signed int v11; // eax
  unsigned int v12; // edx
  unsigned int v13; // r10d
  signed int v14; // esi
  unsigned int v15; // r11d
  __int64 v16; // r13
  __int64 v17; // r15
  volatile signed __int64 *v18; // r12
  __int64 result; // rax
  unsigned int v20; // ecx
  unsigned int v21; // ecx

  v10 = *((_DWORD *)this + 104); /*0x1039df82f*/
  if ( v10 != 0 ) /*0x1039df837*/
  {
    v11 = v10 - 1; /*0x1039df839*/
    v12 = v10 / 2; /*0x1039df843*/
    v13 = a2; /*0x1039df84c*/
    v14 = 0; /*0x1039df850*/
    while ( 1 ) /*0x1039df859*/
    {
      v15 = *(_DWORD *)(*(_QWORD *)(*((_QWORD *)this + 51) + 8LL * v12) + 40LL); /*0x1039df859*/
      if ( v15 == v13 ) /*0x1039df860*/
        break; /*0x1039df860*/
      if ( v15 > v13 ) /*0x1039df862*/
        v11 = v12 - 1; /*0x1039df86c*/
      else
        v14 = v12 + 1; /*0x1039df866*/
      v12 = v14 + (v11 - v14) / 2; /*0x1039df87e*/
      if ( v11 < v14 ) /*0x1039df882*/
        goto LABEL_10; /*0x1039df882*/
    }
  }
  else
  {
    v14 = 0; /*0x1039df886*/
LABEL_10:
    v12 = v14; /*0x1039df888*/
    if ( DFFlag::RakNetCapSplitPacketAllocationV2 != 0 ) /*0x1039df891*/
      return 0; /*0x1039df891*/
  }
  v16 = v12; /*0x1039df89e*/
  v17 = *(_QWORD *)(*((_QWORD *)this + 51) + 8LL * v12); /*0x1039df8a1*/
  if ( *(_DWORD *)(v17 + 32) != *(_DWORD *)(v17 + 44) ) /*0x1039df8ad*/
    return 0; /*0x1039df95d*/
  v18 = *(volatile signed __int64 **)(a4 + 8); /*0x1039df8bb*/
  if ( v18 != nullptr ) /*0x1039df8c9*/
    _InterlockedIncrement64(v18 + 1); /*0x1039df8cb*/
  RakNet::ReliabilityLayer::SendACKs(this, a2: a8); /*0x1039df8e8*/
  if ( v18 != nullptr && _InterlockedExchangeAdd64(v18 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039df903*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v18 + 16))(a1: v18); /*0x1039df90c*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v18); /*0x1039df912*/
  }
  result = RakNet::ReliabilityLayer::BuildPacketFromSplitPacketList(a1: this, a2: v17, a3); /*0x1039df920*/
  v20 = *((_DWORD *)this + 104); /*0x1039df925*/
  if ( v20 > (unsigned int)v16 ) /*0x1039df92e*/
  {
    v21 = v20 - 1; /*0x1039df930*/
    if ( v21 > (unsigned int)v16 ) /*0x1039df935*/
    {
      do /*0x1039df953*/
      {
        *(_QWORD *)(*((_QWORD *)this + 51) + 8 * v16) = *(_QWORD *)(*((_QWORD *)this + 51) + 8 * v16 + 8); /*0x1039df945*/
        ++v16; /*0x1039df94d*/
      }
      while ( v21 != v16 ); /*0x1039df953*/
    }
    *((_DWORD *)this + 104) = v21; /*0x1039df955*/
  }
  return result; /*0x1039df95f*/
}

// Address: 0x1039df982 | Name: __ZN6RakNet16ReliabilityLayer20IsOlderOrderedPacketENS_8uint24_tES1_
char __fastcall RakNet::ReliabilityLayer::IsOlderOrderedPacket(__int64 a1, unsigned int *a2, unsigned int *a3)
{
  unsigned int v3; // eax
  unsigned int v4; // ecx
  bool v5; // dl
  bool v6; // cl
  char result; // al
  bool v8; // zf

  v3 = *a3; /*0x1039df986*/
  v4 = *a2; /*0x1039df988*/
  if ( *a3 < 0x800000 ) /*0x1039df98f*/
  {
    v8 = v4 < (v3 | 0x800000) && v4 >= v3; /*0x1039df9c1*/
    result = 1; /*0x1039df9c3*/
    if ( !v8 ) /*0x1039df9c5*/
      return result; /*0x1039df9c5*/
    return 0; /*0x1039df9c5*/
  }
  v5 = v4 >= ((v3 + 8388610) & 0xFFFFFF); /*0x1039df99f*/
  v6 = v4 < v3; /*0x1039df9a4*/
  result = 1; /*0x1039df9a7*/
  if ( !v6 || !v5 ) /*0x1039df9a9*/
    return 0; /*0x1039df9c7*/
  return result; /*0x1039df9c9*/
}

// Address: 0x1039dfb7a | Name: __ZN6RakNet16ReliabilityLayer7ReceiveEPPhRiPy
__int64 __fastcall RakNet::ReliabilityLayer::Receive(
        RakNet::ReliabilityLayer *this,
        unsigned __int8 **a2,
        int *a3,
        unsigned __int64 *a4)
{
  unsigned int v4; // eax
  unsigned int v5; // r9d
  bool v6; // cf
  int v7; // r9d
  unsigned int v8; // eax
  unsigned int v9; // r8d
  __int64 v10; // rax
  unsigned int v11; // ebx

  v4 = *((_DWORD *)this + 6); /*0x1039dfb7a*/
  v5 = *((_DWORD *)this + 7); /*0x1039dfb81*/
  v6 = v5 < v4; /*0x1039dfb84*/
  v7 = v5 - v4; /*0x1039dfb84*/
  if ( v6 ) /*0x1039dfb87*/
    v7 = *((_DWORD *)this + 8) + *((_DWORD *)this + 7) - v4; /*0x1039dfb90*/
  if ( v7 != 0 ) /*0x1039dfb9c*/
  {
    v8 = v4 + 1; /*0x1039dfb9e*/
    v9 = *((_DWORD *)this + 8); /*0x1039dfba0*/
    if ( v8 == v9 ) /*0x1039dfbaa*/
      v8 = 0; /*0x1039dfbaa*/
    *((_DWORD *)this + 6) = v8; /*0x1039dfbae*/
    if ( v8 == 0 ) /*0x1039dfbb7*/
      v8 = v9; /*0x1039dfbb7*/
    v10 = *(_QWORD *)(*((_QWORD *)this + 2) + 8LL * (v8 - 1)); /*0x1039dfbbd*/
    *a3 = *(unsigned __int8 *)(v10 + 12); /*0x1039dfbc6*/
    *a2 = *(unsigned __int8 **)(v10 + 64); /*0x1039dfbcd*/
    v11 = *(_DWORD *)(v10 + 24); /*0x1039dfbd0*/
    *a4 = *(_QWORD *)(v10 + 264); /*0x1039dfbda*/
    DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: (__int64)this + 144, a2: (_QWORD *)v10); /*0x1039dfbf0*/
  }
  else
  {
    return 0; /*0x1039dfbf7*/
  }
  return v11; /*0x1039dfc01*/
}

// Address: 0x1039dfc02 | Name: __ZN6RakNet16ReliabilityLayer4SendEPcj14PacketPriority17PacketReliabilityhbiyjiyb
bool __fastcall RakNet::ReliabilityLayer::Send(
        RakNet::ReliabilityLayer *this,
        void *a2,
        __int64 a3,
        unsigned int a4,
        unsigned int a5,
        int a6,
        char a7,
        int a8,
        unsigned __int64 a9,
        int a10,
        unsigned int a11,
        unsigned __int64 a12,
        char a13)
{
  int v13; // eax
  int v14; // r12d
  unsigned int v16; // r14d
  __int64 v17; // r15
  unsigned __int64 v18; // rbx
  RakNet::ReliabilityLayer *v19; // r14
  unsigned __int64 v20; // rsi
  void *v21; // rdi
  void *v22; // rsi
  int v23; // edx
  RBX::Network::NetworkTracer *v24; // rdi
  int MaxDatagramSizeExcludingMessageHeaderBytes; // r13d
  unsigned int v26; // r13d
  unsigned int v27; // eax
  unsigned int v28; // r8d
  int v29; // eax
  unsigned __int8 v30; // cl
  int v31; // edi
  unsigned __int8 v32; // cl
  int v33; // edi
  int v34; // ecx
  __int64 v35; // rax
  __int64 *v36; // rcx
  __int64 v37; // rdx
  __int64 *v38; // rdx
  __int64 v39; // rax
  __int64 v40; // rcx
  __int64 NextWeight; // [rsp+0h] [rbp-60h] BYREF
  __int64 v43; // [rsp+8h] [rbp-58h] BYREF
  unsigned int v44; // [rsp+14h] [rbp-4Ch]
  int v45; // [rsp+18h] [rbp-48h]
  unsigned int v46; // [rsp+1Ch] [rbp-44h]
  __int64 v47; // [rsp+20h] [rbp-40h]
  void *__src; // [rsp+28h] [rbp-38h]
  int v49; // [rsp+34h] [rbp-2Ch]

  v13 = 2; /*0x1039dfc17*/
  if ( a5 < 8 ) /*0x1039dfc1c*/
    v13 = a5; /*0x1039dfc1c*/
  v14 = 1; /*0x1039dfc23*/
  if ( a4 < 5 ) /*0x1039dfc29*/
    v14 = a4; /*0x1039dfc29*/
  if ( (unsigned __int8)a6 >= 0x20u ) /*0x1039dfc33*/
    a6 = 0; /*0x1039dfc33*/
  if ( (_DWORD)a3 != 0 ) /*0x1039dfc39*/
  {
    __src = a2; /*0x1039dfc3f*/
    v45 = v13; /*0x1039dfc43*/
    v49 = a6; /*0x1039dfc46*/
    v47 = a3; /*0x1039dfc4a*/
    v46 = a3 + 7; /*0x1039dfc55*/
    v16 = (unsigned int)(a3 + 7) >> 3; /*0x1039dfc59*/
    v17 = DataStructures::MemoryPool<RakNet::InternalPacket>::Allocate( /*0x1039dfc72*/
            a1: (__int64 *)this + 18,
            a2: (unsigned __int64)"",
            a3: 0);
    *(_DWORD *)v17 = 0xFFFFFF; /*0x1039dfc75*/
    *(_BYTE *)(v17 + 36) = 0; /*0x1039dfc7b*/
    *(_QWORD *)(v17 + 48) = 0; /*0x1039dfc7e*/
    *(_DWORD *)(v17 + 20) = 0; /*0x1039dfc82*/
    *(_DWORD *)(v17 + 72) = 0; /*0x1039dfc85*/
    *(_QWORD *)(v17 + 64) = 0; /*0x1039dfc88*/
    *(_WORD *)(v17 + 88) = 0; /*0x1039dfc8c*/
    *(_BYTE *)(v17 + 90) = 0; /*0x1039dfc92*/
    *(_QWORD *)(v17 + 264) = 0; /*0x1039dfc95*/
    v43 = v17; /*0x1039dfc9c*/
    v44 = v16; /*0x1039dfca0*/
    v18 = v16; /*0x1039dfca4*/
    v19 = this; /*0x1039dfca7*/
    if ( a13 != 0 ) /*0x1039dfcae*/
      *((_QWORD *)this + 116) += v18; /*0x1039dfcb0*/
    *((_QWORD *)this + 112) += v18; /*0x1039dfcb7*/
    RakNet::BPSTracker::Push1(this: (RakNet::ReliabilityLayer *)((char *)this + 3232), a2: a9, a3: v18); /*0x1039dfccf*/
    *(_QWORD *)(v17 + 40) = a9; /*0x1039dfcd4*/
    if ( a7 != 0 ) /*0x1039dfcdc*/
    {
      if ( v46 > 0x407 ) /*0x1039dfce5*/
      {
        *(_DWORD *)(v17 + 72) = 0; /*0x1039dfd0a*/
        v21 = (void *)RBX::Memory::allocateOrCrash(this: (RBX::Memory *)v18, a2: v20); /*0x1039dfd1a*/
      }
      else
      {
        *(_DWORD *)(v17 + 72) = 2; /*0x1039dfce7*/
        v21 = (void *)(v17 + 136); /*0x1039dfcef*/
      }
      v22 = __src; /*0x1039dfd1d*/
      *(_QWORD *)(v17 + 64) = v21; /*0x1039dfd21*/
      memcpy(__dst: v21, __src: v22, __n: v18); /*0x1039dfd28*/
    }
    else
    {
      *(_DWORD *)(v17 + 72) = 0; /*0x1039dfcf8*/
      *(_QWORD *)(v17 + 64) = __src; /*0x1039dfd04*/
    }
    *(_DWORD *)(v17 + 24) = v47; /*0x1039dfd39*/
    v23 = *((_DWORD *)this + 108) & 0xFFFFFF; /*0x1039dfd4b*/
    *((_DWORD *)this + 108) = (*((_DWORD *)this + 108) + 1) & 0xFFFFFF; /*0x1039dfd51*/
    *(_DWORD *)(v17 + 32) = v23; /*0x1039dfd58*/
    *(_DWORD *)(v17 + 92) = v14; /*0x1039dfd5c*/
    *(_DWORD *)(v17 + 28) = v45; /*0x1039dfd63*/
    *(_DWORD *)(v17 + 96) = a10; /*0x1039dfd6a*/
    *(_BYTE *)(v17 + 90) = a13; /*0x1039dfd71*/
    if ( (*(unsigned int (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 200LL))(a1: *((_QWORD *)this + 379)) <= DFInt::RakNetPacketTracingMinMTUSize ) /*0x1039dfd8b*/
    {
      *(_QWORD *)(v17 + 264) = 0; /*0x1039dfd96*/
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039dfdab*/
        v24 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039dfdad*/
      else
        v24 = nullptr; /*0x1039dfdb3*/
      RBX::Network::NetworkTracer::removeTracerObject(this: v24, a2: a12); /*0x1039dfdb8*/
    }
    else
    {
      *(_QWORD *)(v17 + 264) = a12; /*0x1039dfd8d*/
    }
    MaxDatagramSizeExcludingMessageHeaderBytes = RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes( /*0x1039dfdcb*/
                                                   this,
                                                   a2: a11);
    v26 = MaxDatagramSizeExcludingMessageHeaderBytes - (((unsigned int)GetMaxMessageHeaderLengthBits() + 7) >> 3); /*0x1039dfdd9*/
    v27 = *(_DWORD *)(v17 + 28); /*0x1039dfddc*/
    v28 = v44; /*0x1039dfde0*/
    if ( v44 <= v26 ) /*0x1039dfde7*/
    {
      switch ( v27 ) /*0x1039dfe25*/
      {
        case 1u: /*0x1039dfe25*/
        case 4u: /*0x1039dfe25*/
LABEL_30:
          v32 = v49; /*0x1039dfe78*/
          *(_BYTE *)(v17 + 12) = v49; /*0x1039dfe7b*/
          *(_DWORD *)(v17 + 4) = *((_DWORD *)v19 + v32 + 359); /*0x1039dfe8a*/
          v33 = *((_DWORD *)v19 + v32 + 391) & 0xFFFFFF; /*0x1039dfe9d*/
          *((_DWORD *)v19 + v32 + 391) = (*((_DWORD *)v19 + v32 + 391) + 1) & 0xFFFFFF; /*0x1039dfea3*/
          *(_DWORD *)(v17 + 8) = v33; /*0x1039dfeab*/
          break; /*0x1039dfeab*/
        case 3u: /*0x1039dfe25*/
        case 7u: /*0x1039dfe25*/
LABEL_26:
          v30 = v49; /*0x1039dfe27*/
          *(_BYTE *)(v17 + 12) = v49; /*0x1039dfe2a*/
          v31 = *((_DWORD *)v19 + v30 + 359) & 0xFFFFFF; /*0x1039dfe40*/
          *((_DWORD *)v19 + v30 + 359) = (*((_DWORD *)v19 + v30 + 359) + 1) & 0xFFFFFF; /*0x1039dfe46*/
          *(_DWORD *)(v17 + 4) = v31; /*0x1039dfe4e*/
          *((_DWORD *)v19 + v30 + 391) = 0; /*0x1039dfe52*/
          break; /*0x1039dfe5e*/
        default:
          break;
      }
LABEL_31:
      if ( v28 <= v26 ) /*0x1039dfeb2*/
      {
        if ( v27 <= 5 ) /*0x1039dfec9*/
        {
          v34 = 35; /*0x1039dfecb*/
          if ( _bittest(&v34, v27) ) /*0x1039dfed0*/
          {
            v35 = *((_QWORD *)v19 + 26); /*0x1039dfed5*/
            if ( v35 != 0 ) /*0x1039dfedf*/
            {
              v36 = (__int64 *)(v35 + 120); /*0x1039dfee1*/
              v37 = *(_QWORD *)(v35 + 120); /*0x1039dfee5*/
              *(_QWORD *)(v17 + 120) = v37; /*0x1039dfee9*/
              v38 = (__int64 *)(v37 + 128); /*0x1039dfeed*/
            }
            else
            {
              v36 = (__int64 *)((char *)v19 + 208); /*0x1039dfef3*/
              v38 = (__int64 *)(v17 + 120); /*0x1039dfefd*/
              v35 = v17; /*0x1039dff01*/
            }
            *(_QWORD *)(v17 + 128) = v35; /*0x1039dff04*/
            *v38 = v17; /*0x1039dff0b*/
            *v36 = v17; /*0x1039dff0e*/
          }
        }
        NextWeight = RakNet::ReliabilityLayer::GetNextWeight(this: v19, a2: *(_DWORD *)(v17 + 92)); /*0x1039dff28*/
        DataStructures::Heap<unsigned long long,RakNet::InternalPacket *,false>::Push( /*0x1039dff3f*/
          a1: (__int64 *)v19 + 44,
          a2: &NextWeight,
          a3: &v43,
          a4: (__int64)"",
          a5: 0);
        v39 = v43; /*0x1039dff44*/
        v40 = *(int *)(v43 + 92); /*0x1039dff47*/
        ++*((_DWORD *)v19 + v40 + 206); /*0x1039dff4b*/
        *((double *)v19 + v40 + 105) = (double)((unsigned int)(*(_DWORD *)(v39 + 24) + 7) >> 3) /*0x1039dff6a*/
                                     + *((double *)v19 + v40 + 105);
        goto LABEL_40; /*0x1039dff6a*/
      }
    }
    else
    {
      switch ( v27 ) /*0x1039dfe02*/
      {
        case 0u: /*0x1039dfe02*/
          v29 = 2; /*0x1039dfe04*/
          break; /*0x1039dfe09*/
        case 1u: /*0x1039dfe02*/
          *(_DWORD *)(v17 + 28) = 4; /*0x1039dfe6b*/
          v27 = 4; /*0x1039dfe73*/
          goto LABEL_30; /*0x1039dfe73*/
        case 3u: /*0x1039dfe02*/
        case 7u: /*0x1039dfe02*/
          goto LABEL_26;
        case 4u: /*0x1039dfe02*/
          goto LABEL_30;
        case 5u: /*0x1039dfe02*/
          v29 = 6; /*0x1039dfe60*/
          break; /*0x1039dfe60*/
        default:
          goto LABEL_31;
      }
      *(_DWORD *)(v17 + 28) = v29; /*0x1039dfe65*/
    }
    RakNet::ReliabilityLayer::SplitPacket(this: v19); /*0x1039dfebc*/
LABEL_40:
    LODWORD(a3) = v47; /*0x1039dff74*/
  }
  return (_DWORD)a3 != 0; /*0x1039dff7d*/
}

// Address: 0x1039dffc8 | Name: __ZN6RakNet16ReliabilityLayer23AllocInternalPacketDataEPNS_14InternalPacketEPh
void __fastcall RakNet::ReliabilityLayer::AllocInternalPacketData(__int64 a1, __int64 a2, __int64 a3)
{
  *(_DWORD *)(a2 + 72) = 0; /*0x1039dffcc*/
  *(_QWORD *)(a2 + 64) = a3; /*0x1039dffd3*/
}

// Address: 0x1039dffda | Name: __ZN6RakNet16ReliabilityLayer45GetMaxDatagramSizeExcludingMessageHeaderBytesEj
__int64 __fastcall RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes(
        RakNet::ReliabilityLayer *this,
        int a2)
{
  int v4; // r15d
  unsigned int v5; // ebx
  char EnabledForRaknet; // al
  unsigned int v7; // ecx

  v4 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 200LL))(a1: *((_QWORD *)this + 379)); /*0x1039dfff9*/
  v5 = v4 /*0x1039e0018*/
     - a2
     + 4
     * ((*(unsigned __int8 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 232LL))(a1: *((_QWORD *)this + 379)) ^ 1)
     - 13;
  if ( *(_QWORD *)this != 0 ) /*0x1039e0021*/
  {
    EnabledForRaknet = RBX::Security::SessionCrypto::getEnabledForRaknet(this: *(RBX::Security::SessionCrypto **)this); /*0x1039e0023*/
    v7 = v5 - 18; /*0x1039e0028*/
    if ( EnabledForRaknet == 0 ) /*0x1039e002d*/
      return v5; /*0x1039e002d*/
    return v7; /*0x1039e0030*/
  }
  return v5; /*0x1039e0038*/
}

// Address: 0x1039e0068 | Name: __ZN6RakNet16ReliabilityLayer11SplitPacketEPNS_14InternalPacketEi
__int64 __fastcall RakNet::ReliabilityLayer::SplitPacket(RakNet::ReliabilityLayer *this, _DWORD *a2, int a3)
{
  unsigned int v6; // r15d
  unsigned __int64 v7; // rsi
  unsigned int v8; // ecx
  __int64 v9; // rax
  RBX::Memory *v10; // rdi
  char *v11; // rsi
  RBX::Memory *v12; // r15
  RakNet::ReliabilityLayer *v13; // rbx
  char *v14; // r14
  __int64 v15; // r13
  __int64 v16; // rax
  int v17; // ecx
  int v18; // r11d
  int v19; // r9d
  int v20; // r12d
  int v21; // r14d
  __int64 v22; // r13
  __int64 v23; // rax
  unsigned __int64 v24; // r8
  int v25; // r10d
  int v26; // ebx
  __int64 v27; // r15
  __int64 *v28; // rdx
  int v29; // ebx
  __int64 v30; // rdi
  RakNet::ReliabilityLayer *v31; // rbx
  __int16 v32; // dx
  int v33; // ecx
  int v34; // r14d
  __int64 v35; // r15
  RBX::Memory *v36; // r13
  __int64 v37; // rax
  unsigned int v38; // ecx
  int v39; // edx
  _QWORD *v40; // rsi
  __int64 v41; // rcx
  __int64 v42; // rdx
  _QWORD *v43; // rdx
  __int64 v44; // rax
  __int64 v45; // rcx
  void *v46; // rsi
  __int64 NextWeight; // [rsp+0h] [rbp-90h] BYREF
  __int64 v49; // [rsp+8h] [rbp-88h]
  __int64 MaxDatagramSizeExcludingMessageHeaderBytes; // [rsp+10h] [rbp-80h]
  RakNet::ReliabilityLayer *v51; // [rsp+18h] [rbp-78h]
  int v52; // [rsp+20h] [rbp-70h]
  int MessageHeaderLengthBits; // [rsp+24h] [rbp-6Ch]
  __int64 *v54; // [rsp+28h] [rbp-68h]
  void *__src; // [rsp+30h] [rbp-60h]
  __int64 v56; // [rsp+38h] [rbp-58h]
  RBX::Memory *v57; // [rsp+40h] [rbp-50h]
  int v58; // [rsp+4Ch] [rbp-44h]
  _QWORD *v59; // [rsp+50h] [rbp-40h]
  void *v60; // [rsp+58h] [rbp-38h]

  a2[5] = 1; /*0x1039e0090*/
  MessageHeaderLengthBits = GetMessageHeaderLengthBits(a1: a2); /*0x1039e009f*/
  v6 = (unsigned int)(a2[6] + 7) >> 3; /*0x1039e00aa*/
  v51 = this; /*0x1039e00ae*/
  MaxDatagramSizeExcludingMessageHeaderBytes = (unsigned int)RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes( /*0x1039e00cb*/
                                                               this,
                                                               a2: a3);
  v56 = ((unsigned int)GetMaxMessageHeaderLengthBits() + 7) >> 3; /*0x1039e00d2*/
  v8 = MaxDatagramSizeExcludingMessageHeaderBytes - v56; /*0x1039e00d6*/
  v59 = (_QWORD *)v6; /*0x1039e00d8*/
  v58 = MaxDatagramSizeExcludingMessageHeaderBytes - v56; /*0x1039e00e2*/
  v9 = (v6 - 1) / ((int)MaxDatagramSizeExcludingMessageHeaderBytes - (int)v56) + 1; /*0x1039e00e7*/
  a2[5] = v9; /*0x1039e00e9*/
  v10 = (RBX::Memory *)(8 * v9); /*0x1039e00ec*/
  v60 = a2; /*0x1039e00f9*/
  v49 = (v6 - 1) / v8 + 1; /*0x1039e00fd*/
  if ( (unsigned int)v9 <= 0x30D3 ) /*0x1039e0104*/
  {
    v11 = (char *)a2; /*0x1039e0117*/
    v12 = (RBX::Memory *)((char *)&NextWeight - (((unsigned __int64)v10 + 15) & 0xFFFFFFFFFFFFFFF0LL)); /*0x1039e0125*/
  }
  else
  {
    v9 = RBX::Memory::allocateOrCrash(this: v10, a2: v7); /*0x1039e0106*/
    v11 = (char *)v60; /*0x1039e010b*/
    v12 = (RBX::Memory *)v9; /*0x1039e010f*/
    LODWORD(v9) = *((_DWORD *)v60 + 5); /*0x1039e0112*/
  }
  v13 = v51; /*0x1039e012d*/
  if ( (int)v9 > 0 ) /*0x1039e0131*/
  {
    v54 = (__int64 *)((char *)v51 + 144); /*0x1039e013e*/
    v14 = v11 + 12; /*0x1039e0142*/
    __src = v11 + 36; /*0x1039e014a*/
    v15 = 0; /*0x1039e0151*/
    do /*0x1039e0215*/
    {
      v16 = DataStructures::MemoryPool<RakNet::InternalPacket>::Allocate(a1: v54, a2: (unsigned __int64)"", a3: 0); /*0x1039e0161*/
      *(_DWORD *)v16 = 0xFFFFFF; /*0x1039e0166*/
      *(_BYTE *)(v16 + 36) = 0; /*0x1039e0170*/
      *(_QWORD *)(v16 + 48) = 0; /*0x1039e0174*/
      *(_DWORD *)(v16 + 20) = 0; /*0x1039e0178*/
      *(_DWORD *)(v16 + 72) = 0; /*0x1039e017c*/
      *(_QWORD *)(v16 + 64) = 0; /*0x1039e0180*/
      *(_WORD *)(v16 + 88) = 0; /*0x1039e0184*/
      *(_BYTE *)(v16 + 90) = 0; /*0x1039e018a*/
      *(_QWORD *)(v16 + 264) = 0; /*0x1039e018e*/
      *((_QWORD *)v12 + v15) = v16; /*0x1039e0195*/
      *(_DWORD *)v16 = *(_DWORD *)v60; /*0x1039e019f*/
      *(_DWORD *)(v16 + 4) = *((_DWORD *)v60 + 1); /*0x1039e01a8*/
      *(_DWORD *)(v16 + 8) = *((_DWORD *)v60 + 2); /*0x1039e01b2*/
      *(_DWORD *)(v16 + 28) = *((_DWORD *)v14 + 4); /*0x1039e01b9*/
      *(_OWORD *)(v16 + 12) = *(_OWORD *)v14; /*0x1039e01c1*/
      *(_DWORD *)(v16 + 32) = *((_DWORD *)v60 + 8); /*0x1039e01cd*/
      memcpy(__dst: (void *)(v16 + 36), __src, __n: 0xECu); /*0x1039e01d9*/
      v11 = (char *)v60; /*0x1039e01de*/
      *(_BYTE *)(*((_QWORD *)v12 + v15) + 36LL) = 0; /*0x1039e01e6*/
      if ( v15 != 0 ) /*0x1039e01ed*/
      {
        v17 = *((_DWORD *)v13 + 108) & 0xFFFFFF; /*0x1039e01fc*/
        *((_DWORD *)v13 + 108) = (*((_DWORD *)v13 + 108) + 1) & 0xFFFFFF; /*0x1039e0202*/
        *((_DWORD *)v11 + 8) = v17; /*0x1039e0208*/
      }
      ++v15; /*0x1039e020b*/
    }
    while ( v15 < *((int *)v11 + 5) ); /*0x1039e0215*/
  }
  __src = (char *)v13 + 3200; /*0x1039e0222*/
  v18 = 8 * v56 - 8 * MaxDatagramSizeExcludingMessageHeaderBytes; /*0x1039e023d*/
  v19 = v56 - MaxDatagramSizeExcludingMessageHeaderBytes; /*0x1039e0240*/
  v20 = 0; /*0x1039e0243*/
  v21 = 0; /*0x1039e0246*/
  v22 = 0; /*0x1039e0249*/
  v23 = 0; /*0x1039e024c*/
  v24 = (unsigned __int64)v59; /*0x1039e024e*/
  v25 = v58; /*0x1039e0252*/
  v57 = v12; /*0x1039e0256*/
  v56 = (unsigned int)(v56 - MaxDatagramSizeExcludingMessageHeaderBytes); /*0x1039e025a*/
  v52 = v18; /*0x1039e025e*/
  do /*0x1039e0313*/
  {
    v26 = v25; /*0x1039e0265*/
    if ( (int)v24 < v25 ) /*0x1039e0268*/
      v26 = v24; /*0x1039e0268*/
    v27 = *((_QWORD *)v12 + v22); /*0x1039e026c*/
    v28 = *((__int64 **)v11 + 8); /*0x1039e0270*/
    *(_DWORD *)(v27 + 72) = 1; /*0x1039e027a*/
    *(_QWORD *)(v27 + 64) = (char *)v28 + v20; /*0x1039e0282*/
    if ( v23 != 0 ) /*0x1039e0289*/
    {
      ++*(_DWORD *)(v23 + 8); /*0x1039e028b*/
    }
    else
    {
      v54 = v28; /*0x1039e029b*/
      v59 = (_QWORD *)v24; /*0x1039e02a1*/
      v23 = DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Allocate( /*0x1039e02a5*/
              a1: (__int64 *)__src,
              a2: (unsigned __int64)"",
              a3: 0);
      v18 = v52; /*0x1039e02aa*/
      v25 = v58; /*0x1039e02ae*/
      v19 = v56; /*0x1039e02b2*/
      LODWORD(v24) = (_DWORD)v59; /*0x1039e02b6*/
      v11 = (char *)v60; /*0x1039e02ba*/
      *(_DWORD *)(v23 + 8) = 1; /*0x1039e02be*/
      *(_QWORD *)v23 = v54; /*0x1039e02c9*/
    }
    *(_QWORD *)(v27 + 80) = v23; /*0x1039e02cc*/
    if ( v25 <= (int)v24 ) /*0x1039e02d3*/
      v29 = 8 * v26; /*0x1039e02dd*/
    else
      v29 = v21 + *((_DWORD *)v11 + 6); /*0x1039e02d8*/
    v12 = v57; /*0x1039e02e0*/
    v30 = *((_QWORD *)v57 + v22); /*0x1039e02e4*/
    *(_DWORD *)(v30 + 24) = v29; /*0x1039e02e8*/
    *(_DWORD *)(v30 + 16) = v22; /*0x1039e02eb*/
    v31 = v51; /*0x1039e02ef*/
    v32 = *((_WORD *)v51 + 222); /*0x1039e02f3*/
    *(_WORD *)(v30 + 14) = v32; /*0x1039e02fa*/
    v33 = *((_DWORD *)v11 + 5); /*0x1039e02fe*/
    *(_DWORD *)(v30 + 20) = v33; /*0x1039e0301*/
    ++v22; /*0x1039e0304*/
    v21 += v18; /*0x1039e0307*/
    v24 = (unsigned int)(v19 + v24); /*0x1039e030a*/
    v20 += v25; /*0x1039e030d*/
  }
  while ( (unsigned int)v22 < v33 ); /*0x1039e0313*/
  *((_WORD *)v31 + 222) = v32 + 1; /*0x1039e031b*/
  *((_BYTE *)v31 + 368) = 0; /*0x1039e0322*/
  v34 = MessageHeaderLengthBits; /*0x1039e032b*/
  if ( v33 > 0 ) /*0x1039e032f*/
  {
    v59 = (_QWORD *)((char *)v31 + 208); /*0x1039e0343*/
    v35 = 0; /*0x1039e0347*/
    v36 = v57; /*0x1039e034a*/
    do /*0x1039e040f*/
    {
      v37 = *(_QWORD *)v36; /*0x1039e034e*/
      *(_DWORD *)(v37 + 60) = v34; /*0x1039e0352*/
      v38 = *(_DWORD *)(v37 + 28); /*0x1039e0356*/
      if ( v38 <= 5 ) /*0x1039e035c*/
      {
        v39 = 35; /*0x1039e035e*/
        if ( _bittest(&v39, v38) ) /*0x1039e0363*/
        {
          v40 = v59; /*0x1039e0368*/
          v41 = *v59; /*0x1039e036c*/
          if ( *v59 != 0 ) /*0x1039e0372*/
          {
            v40 = (_QWORD *)(v41 + 120); /*0x1039e0374*/
            v42 = *(_QWORD *)(v41 + 120); /*0x1039e0378*/
            *(_QWORD *)(v37 + 120) = v42; /*0x1039e037c*/
            v43 = (_QWORD *)(v42 + 128); /*0x1039e0380*/
          }
          else
          {
            v43 = (_QWORD *)(v37 + 120); /*0x1039e0386*/
            v41 = v37; /*0x1039e038a*/
          }
          *(_QWORD *)(v37 + 128) = v41; /*0x1039e038d*/
          *v43 = v37; /*0x1039e0394*/
          *v40 = v37; /*0x1039e0397*/
          v37 = *(_QWORD *)v36; /*0x1039e039a*/
        }
      }
      NextWeight = RakNet::ReliabilityLayer::GetNextWeight(this: v31, a2: *(_DWORD *)(v37 + 92)); /*0x1039e03a9*/
      DataStructures::Heap<unsigned long long,RakNet::InternalPacket *,false>::PushSeries( /*0x1039e03c7*/
        a1: (__int64)v31 + 352,
        a2: (unsigned __int64 *)&NextWeight,
        a3: v36,
        a4: (__int64)"",
        a5: 0);
      v44 = *(_QWORD *)v36; /*0x1039e03cc*/
      v45 = *(int *)(*(_QWORD *)v36 + 92LL); /*0x1039e03d0*/
      ++*((_DWORD *)v31 + v45 + 206); /*0x1039e03d4*/
      *((double *)v31 + v45 + 105) = (double)((unsigned int)(*(_DWORD *)(v44 + 24) + 7) >> 3) /*0x1039e03f4*/
                                   + *((double *)v31 + v45 + 105);
      ++v35; /*0x1039e03fd*/
      v11 = (char *)v60; /*0x1039e0400*/
      v36 = (RBX::Memory *)((char *)v36 + 8); /*0x1039e0408*/
    }
    while ( v35 < *((int *)v60 + 5) ); /*0x1039e040f*/
  }
  DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: (__int64)v31 + 144, a2: v11); /*0x1039e0428*/
  if ( (unsigned int)v49 >= 0x30D4 ) /*0x1039e0437*/
    RBX::Memory::deallocate(this: v57, a2: v46); /*0x1039e043d*/
  return __stack_chk_guard; /*0x1039e0452*/
}

// Address: 0x1039e0466 | Name: __ZN6RakNet16ReliabilityLayer25AddToUnreliableLinkedListEPNS_14InternalPacketE
__int64 __fastcall RakNet::ReliabilityLayer::AddToUnreliableLinkedList(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  int v3; // ecx
  __int64 v4; // rcx
  __int64 v5; // rax
  _QWORD *v6; // rdi

  result = *(unsigned int *)(a2 + 28); /*0x1039e0466*/
  if ( (unsigned int)result <= 5 ) /*0x1039e046c*/
  {
    v3 = 35; /*0x1039e046e*/
    if ( _bittest(&v3, result) ) /*0x1039e0473*/
    {
      v4 = *(_QWORD *)(a1 + 208); /*0x1039e047c*/
      if ( v4 != 0 ) /*0x1039e0486*/
      {
        *(_QWORD *)(a2 + 128) = v4; /*0x1039e0488*/
        v5 = *(_QWORD *)(v4 + 120); /*0x1039e048f*/
        *(_QWORD *)(a2 + 120) = v5; /*0x1039e0497*/
        result = v5 + 128; /*0x1039e049b*/
        v6 = (_QWORD *)(v4 + 120); /*0x1039e04a1*/
      }
      else
      {
        v6 = (_QWORD *)(a1 + 208); /*0x1039e04a6*/
        *(_QWORD *)(a2 + 128) = a2; /*0x1039e04ad*/
        result = a2 + 120; /*0x1039e04b4*/
      }
      *(_QWORD *)result = a2; /*0x1039e04b8*/
      *v6 = a2; /*0x1039e04bb*/
    }
  }
  return result; /*0x1039e04bf*/
}

// Address: 0x1039e04c0 | Name: __ZN6RakNet16ReliabilityLayer13GetNextWeightEi
unsigned __int64 __fastcall RakNet::ReliabilityLayer::GetNextWeight(RakNet::ReliabilityLayer *this, int a2)
{
  __int64 v2; // rdx
  unsigned __int64 result; // rax
  _QWORD *v4; // r8
  __int64 v5; // rsi
  unsigned __int64 v6; // r8
  __int64 i; // rcx

  v2 = a2; /*0x1039e04c0*/
  result = *((_QWORD *)this + a2 + 47); /*0x1039e04c3*/
  if ( *((_DWORD *)this + 90) != 0 ) /*0x1039e04d2*/
  {
    v4 = *((_QWORD **)this + 44); /*0x1039e04d8*/
    v5 = *(int *)(v4[1] + 92LL); /*0x1039e04e3*/
    v6 = v5 + *v4 - (int)((_DWORD)v5 << *(_DWORD *)(v4[1] + 92LL)); /*0x1039e0500*/
    if ( result < v6 ) /*0x1039e050f*/
      result = v6 + v2 + (int)((_DWORD)v2 << v2); /*0x1039e050f*/
    *((_QWORD *)this + v2 + 47) = result + v2 + (((int)v2 + 1) << v2); /*0x1039e0523*/
  }
  else
  {
    for ( i = 0; i != 4; ++i ) /*0x1039e052d*/
      *((_QWORD *)this + i + 47) = i + (unsigned int)((_DWORD)i << i); /*0x1039e0536*/
  }
  return result; /*0x1039e052c*/
}

// Address: 0x1039e0548 | Name: __ZN6RakNet16ReliabilityLayer16SnapshotTxBwDataEj
__int64 __fastcall RakNet::ReliabilityLayer::SnapshotTxBwData(
        RakNet::ReliabilityLayer *this,
        int a2,
        __int64 a3,
        __int64 a4,
        int a5,
        int a6)
{
  int v8; // eax
  _OWORD *v9; // r15
  __int128 v10; // xmm0
  __int128 v11; // xmm1
  __int128 v12; // xmm2
  unsigned int *v13; // r12
  int v14; // eax
  double v15; // xmm0_8
  double v16; // xmm0_8
  __int64 v17; // rdx
  __int64 v18; // rcx
  double v19; // xmm13_8
  int v20; // edi
  unsigned int v21; // eax
  int v22; // r11d
  int v23; // r8d
  int v24; // r9d
  _BYTE v26[16]; // [rsp+60h] [rbp-230h] BYREF
  void *v27; // [rsp+70h] [rbp-220h]
  double v28; // [rsp+78h] [rbp-218h]
  double v29; // [rsp+80h] [rbp-210h]
  void *v30[59]; // [rsp+88h] [rbp-208h] BYREF

  v8 = *((_DWORD *)this + 308); /*0x1039e056f*/
  if ( v8 != 0 )
  {
    if ( (unsigned int)(a2 - v8) >= 0x3E8 && *((_DWORD *)this + 277) != 0 )
    {
      v9 = (_OWORD *)((char *)this + 1072); /*0x1039e059b*/
      *(_OWORD *)((char *)this + 1048) = *((_OWORD *)this + 71); /*0x1039e05a7*/
      v10 = *((_OWORD *)this + 67); /*0x1039e05af*/
      v11 = *((_OWORD *)this + 68); /*0x1039e05b4*/
      v12 = *((_OWORD *)this + 69); /*0x1039e05ba*/
      *(_OWORD *)((char *)this + 1032) = *((_OWORD *)this + 70); /*0x1039e05c6*/
      *(_OWORD *)((char *)this + 1016) = v12; /*0x1039e05cf*/
      *(_OWORD *)((char *)this + 1000) = v11; /*0x1039e05d8*/
      *(_OWORD *)((char *)this + 984) = v10; /*0x1039e05e1*/
      if ( DFInt::RaknetInfluxHundredthsPercentage != 0 ) /*0x1039e05f1*/
      {
        v13 = (unsigned int *)((char *)this + 1152); /*0x1039e05f7*/
        RakNet::TxBwData::operator+=(a1: (char *)this + 1152, a2: (char *)this + 1072); /*0x1039e0604*/
        if ( DFInt::RaknetBwStatsInfluxReportDurationInSeconds > 0 /*0x1039e0628*/
          && a2 - *((_DWORD *)this + 309) >= (unsigned int)(1000 * DFInt::RaknetBwStatsInfluxReportDurationInSeconds) )
        {
          if ( rand() % 10000 < DFInt::RaknetInfluxHundredthsPercentage ) /*0x1039e0657*/
          {
            RBX::Analytics::InfluxDb::Points::Points(a1: v30, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1039e066d*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0684*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "availableCapacity",
              a3: *v13);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e069e*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "totalAvailableCapacity",
              a3: *((_DWORD *)this + 289));
            v14 = *((_DWORD *)this + 288); /*0x1039e06b4*/
            v29 = (double)(a2 - *((_DWORD *)this + 309)); /*0x1039e06c3*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e06dd*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "availableCapacityKBps",
              a3: (double)v14 / v29);
            v15 = (double)*((int *)this + 289) / v29; /*0x1039e06f1*/
            *((double *)this + 162) = fmax(v15, *((double *)this + 162)); /*0x1039e0706*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e071d*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "totalAvailableCapacityKBps",
              a3: v15);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0739*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "highWaterMarkFortotalAvailableCapacityKBps",
              a3: *((double *)this + 162));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0763*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "actualRawBwUsedKBps",
              a3: (double)*((int *)this + 290) / v29);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e079b*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "actualBwUsedForAllTransmissionsKBps",
              a3: (double)(*((_DWORD *)this + 295) + *((_DWORD *)this + 291) + *((_DWORD *)this + 293)) / v29);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e07cc*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "actualBwUsedForNewTransmissionsKBps",
              a3: (double)(*((_DWORD *)this + 291) + *((_DWORD *)this + 295)) / v29);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e07f6*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "actualBwUsedForReTransmissionKBps",
              a3: (double)*((int *)this + 293) / v29);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0837*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "unusedAvailableBwKBps",
              a3: (double)(*((_DWORD *)this + 289)
                     - (*((_DWORD *)this + 295)
                      + *((_DWORD *)this + 293)
                      + *((_DWORD *)this + 291)))
            / v29);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e085a*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "collectionDurationInSeconds",
              a3: v29 / 1000.0);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0874*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "allBytes",
              a3: *((_DWORD *)this + 290));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e088e*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "reliablePacketBytes",
              a3: *((_DWORD *)this + 291));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e08a8*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "reliablePackets",
              a3: *((_DWORD *)this + 292));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e08c2*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "reliablePacketBytesRe",
              a3: *((_DWORD *)this + 293));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e08dc*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "reliablePacketsRe",
              a3: *((_DWORD *)this + 294));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e08f6*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "unreliablePacketBytes",
              a3: *((_DWORD *)this + 295));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0910*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "unreliablePackets",
              a3: *((_DWORD *)this + 296));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e092a*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "actualTotalGetTxBwCount",
              a3: *((_DWORD *)this + 297));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e095c*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "bwLimitedByAppCountToTotalCount",
              a3: (double)*((int *)this + 298) / (double)*((int *)this + 297));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0991*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "zeroTargetSpeedStartTimeCountToTotalCount",
              a3: (double)*((int *)this + 299) / (double)*((int *)this + 297));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e09c6*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "nonZeroTargetSpeedStartTimeCountToTotalCount",
              a3: (double)*((int *)this + 300) / (double)*((int *)this + 297));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e09f0*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "uncappedByteAllowanceFromTargetSpeedInKBps",
              a3: (double)*((int *)this + 301) / v29);
            v16 = (double)*((int *)this + 302) / v29; /*0x1039e0a04*/
            *((double *)this + 163) = fmax(v16, *((double *)this + 163)); /*0x1039e0a19*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0a30*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "bwGivenByTargetSpeedKBps",
              a3: v16);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0a4c*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "highWaterMarkForBwFromTargetSpeedKBps",
              a3: *((double *)this + 163));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0a81*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "bwCappedDueToTargetSpeedCountToTotalCount",
              a3: (double)*((int *)this + 303) / (double)*((int *)this + 297));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0ab6*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "bwCappedDueTo2xTargetSpeedCountToTotalCount",
              a3: (double)*((int *)this + 304) / (double)*((int *)this + 297));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0aeb*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "bwcappedDueToMaxBytesInFlightCountToTotalCount",
              a3: (double)*((int *)this + 305) / (double)*((int *)this + 297));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0b20*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "bwCappedDueToMaxPacketsInFlightCountToTotalCount",
              a3: (double)*((int *)this + 306) / (double)*((int *)this + 297));
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x1039e0b55*/
              this: (RBX::Analytics::InfluxDb::Points *)v30,
              a2: "bwCappedDueToAllBytesInFlightLostCountToTotalCount",
              a3: (double)*((int *)this + 307) / (double)*((int *)this + 297));
            std::string::basic_string[abi:ne200100]<0>(a1: v26, a2: "RccRakPeerTxBw", a3: v17, a4: v18); /*0x1039e0b68*/
            RBX::Analytics::InfluxDb::Points::report(a1: v30, a2: v26, a3: 10000, a4: 0); /*0x1039e0b82*/
            if ( (v26[0] & 1) != 0 ) /*0x1039e0b8e*/
              operator delete(a1: v27); /*0x1039e0b97*/
            RBX::Analytics::InfluxDb::Points::~Points(this: v30); /*0x1039e0ba3*/
          }
          *((_OWORD *)this + 76) = 0; /*0x1039e0bac*/
          *((_OWORD *)this + 75) = 0; /*0x1039e0bb3*/
          *((_OWORD *)this + 74) = 0; /*0x1039e0bba*/
          *((_OWORD *)this + 73) = 0; /*0x1039e0bc1*/
          *(_OWORD *)v13 = 0; /*0x1039e0bc8*/
          *((_DWORD *)this + 309) = a2; /*0x1039e0bce*/
        }
      }
      *((_OWORD *)this + 71) = 0; /*0x1039e0bd9*/
      *((_OWORD *)this + 70) = 0; /*0x1039e0bdf*/
      *((_OWORD *)this + 69) = 0; /*0x1039e0be5*/
      *((_OWORD *)this + 68) = 0; /*0x1039e0beb*/
      *v9 = 0; /*0x1039e0bf1*/
      v19 = (double)(a2 - *((_DWORD *)this + 308)); /*0x1039e0bff*/
      v20 = DFLog::TxBwStatLog; /*0x1039e0c04*/
      v21 = (unsigned int)DFLog::TxBwStatLog >> 8; /*0x1039e0c0d*/
      if ( (unsigned __int8)DFLog::TxBwStatLog >= 6u && BYTE1(DFLog::TxBwStatLog) >= 3u )
      {
        v29 = *(double *)&qword_10D7BBAC8; /*0x1039e0c2b*/
        v22 = *((_DWORD *)this + 246); /*0x1039e0c32*/
        v23 = *((_DWORD *)this + 247); /*0x1039e0c39*/
        v24 = *((_DWORD *)this + 248); /*0x1039e0c63*/
        v28 = v19; /*0x1039e0d34*/
        FLog::FastLogFormatted(
          a1: DFLog::TxBwStatLog,
          a2: qword_10D7BBAC8,
          a3: (unsigned int)"[DFLog::TxBwStatLog] TxBwStats#1 : availableCapacity = %d; totalAvailableCapacity = %d; availabl"
                        "eCapacityKBps=%.2f; totalAvailableCapacityKBps=%.2f; highWaterMarkFortotalAvailableCapacityKBps="
                        "%.2f; allBytes = %d; reliablePacketBytes = %d; reliablePackets = %d; reliablePacketBytesRe = %d;"
                        " reliablePacketsRe = %d; unreliablePacketBytes = %d; unreliablePackets = %d; actualRawBwUsedKBps"
                        " = %.2f; actualBwUsedForAllTransmissionKBps = %.2f; actualBwUsedForNewTransmissionsKBps = %.2f; "
                        "actualBwUsedForReTransmissionKBps = %.2f; collectionDurationInSeconds = %.2f; unusedAvailableBwK"
                        "Bps = %.2f actualTotalGetTxBwCount=%d; bwLimitedByAppCountToTotalCount=%.2f zeroTargetSpeedStart"
                        "TimeCountToTotalCount=%.2f; nonZeroTargetSpeedStartTimeCountToTotalCount=%.2f; uncappedByteAllow"
                        "anceFromTargetSpeedInKBps=%.2f;",
          a4: v22,
          a5: v23,
          a6: v24);
        v20 = DFLog::TxBwStatLog; /*0x1039e0d9b*/
        v21 = (unsigned int)DFLog::TxBwStatLog >> 8; /*0x1039e0da4*/
      }
      if ( (unsigned __int8)v20 >= 6u && (unsigned __int8)v21 >= 3u )
        FLog::FastLogFormatted(
          a1: v20,
          a2: qword_10D7BBAC8,
          a3: (unsigned int)"[DFLog::TxBwStatLog] TxBwStats#2 : bwGivenByTargetSpeedKBps=%.2f; highWaterMarkForBwFromTargetSp"
                        "eedKBps=%.2f; bwCappedDueToTargetSpeedCountToTotalCount=%.2f; bwCappedDueTo2xTargetSpeedCountToT"
                        "otalCount=%.2f; bwcappedDueToMaxBytesInFlightCountToTotalCount=%.2f; bwCappedDueToMaxPacketsInFl"
                        "ightCountToTotalCount=%.2f; bwCappedDueToAllBytesInFlightLostCountToTotalCount=%.2f",
          a4: *((_DWORD *)this + 261),
          a5,
          a6);
      *((_DWORD *)this + 308) = a2; /*0x1039e0e5b*/
    }
  }
  else
  {
    *((_DWORD *)this + 308) = a2; /*0x1039e0e64*/
    *((_DWORD *)this + 309) = a2; /*0x1039e0e6b*/
  }
  return __stack_chk_guard; /*0x1039e0e82*/
}

// Address: 0x1039e0f20 | Name: __ZN6RakNet16ReliabilityLayer22cleanExpiredUnreliableEyy
unsigned __int64 __fastcall RakNet::ReliabilityLayer::cleanExpiredUnreliable(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 a2,
        unsigned __int64 a3)
{
  unsigned __int64 result; // rax
  unsigned __int64 v4; // rcx
  unsigned __int64 v6; // rax
  bool v7; // cc
  __int64 v8; // rax
  __int64 v10; // r13
  __int64 v11; // r12
  unsigned int v12; // ecx
  int v13; // edx
  __int64 v14; // rcx
  __int64 v15; // rcx
  bool v16; // zf
  __int64 v17; // rdx

  v4 = *((_QWORD *)this + 6); /*0x1039e0f20*/
  if ( v4 != 0 ) /*0x1039e0f27*/
  {
    v6 = *((_QWORD *)this + 392); /*0x1039e0f3e*/
    v7 = v6 <= a3; /*0x1039e0f45*/
    result = v6 - a3; /*0x1039e0f45*/
    if ( v7 ) /*0x1039e0f48*/
    {
      v8 = *((_QWORD *)this + 26); /*0x1039e0f4e*/
      if ( v8 != 0 ) /*0x1039e0f58*/
      {
        v10 = *(_QWORD *)(v8 + 120); /*0x1039e0f61*/
        while ( 1 ) /*0x1039e0f6c*/
        {
          v11 = v8; /*0x1039e0f6c*/
          v4 = *((_QWORD *)this + 6); /*0x1039e0f6f*/
          if ( v4 + *(_QWORD *)(v8 + 40) >= a2 ) /*0x1039e0f7d*/
            break; /*0x1039e0f7d*/
          RakNet::ReliabilityLayer::FreeInternalPacketData(a1: (__int64)this, a2: v8); /*0x1039e0f8e*/
          *(_QWORD *)(v11 + 64) = 0; /*0x1039e0f93*/
          v8 = *(_QWORD *)(v11 + 128); /*0x1039e0f9c*/
          v12 = *(_DWORD *)(v11 + 28); /*0x1039e0fa4*/
          if ( v12 <= 5 ) /*0x1039e0fac*/
          {
            v13 = 35; /*0x1039e0fae*/
            if ( _bittest(&v13, v12) ) /*0x1039e0fb3*/
            {
              v14 = *(_QWORD *)(v11 + 120); /*0x1039e0fb8*/
              *(_QWORD *)(v14 + 128) = v8; /*0x1039e0fbd*/
              *(_QWORD *)(v8 + 120) = v14; /*0x1039e0fc4*/
              v15 = *((_QWORD *)this + 26); /*0x1039e0fc8*/
              v16 = v15 == v11; /*0x1039e0fcf*/
              if ( v15 == v11 ) /*0x1039e0fd2*/
                v15 = v8; /*0x1039e0fd2*/
              if ( v15 == v11 || v16 ) /*0x1039e0fd6*/
              {
                v17 = 0; /*0x1039e0fe8*/
                if ( v15 != v11 ) /*0x1039e0fed*/
                  v17 = v15; /*0x1039e0fed*/
                *((_QWORD *)this + 26) = v17; /*0x1039e0ff1*/
              }
            }
          }
          if ( v11 == v10 ) /*0x1039e0ffb*/
          {
            v4 = *((_QWORD *)this + 6); /*0x1039e1001*/
            break; /*0x1039e1001*/
          }
        }
      }
      result = v4 >> 1; /*0x1039e1005*/
    }
    *((_QWORD *)this + 392) = result; /*0x1039e100b*/
  }
  return result; /*0x1039e1020*/
}

// Address: 0x1039e1022 | Name: __ZN6RakNet16ReliabilityLayer30RemoveFromUnreliableLinkedListEPNS_14InternalPacketE
__int64 __fastcall RakNet::ReliabilityLayer::RemoveFromUnreliableLinkedList(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  int v3; // ecx
  __int64 v4; // rax
  __int64 v5; // rcx
  bool v6; // zf
  __int64 v7; // rcx

  result = *(unsigned int *)(a2 + 28); /*0x1039e1022*/
  if ( (unsigned int)result <= 5 ) /*0x1039e1028*/
  {
    v3 = 35; /*0x1039e102a*/
    if ( _bittest(&v3, result) ) /*0x1039e102f*/
    {
      v4 = *(_QWORD *)(a2 + 120); /*0x1039e1038*/
      v5 = *(_QWORD *)(a2 + 128); /*0x1039e103c*/
      *(_QWORD *)(v4 + 128) = v5; /*0x1039e1043*/
      *(_QWORD *)(v5 + 120) = v4; /*0x1039e104a*/
      result = *(_QWORD *)(a1 + 208); /*0x1039e104e*/
      v6 = result == a2; /*0x1039e1055*/
      if ( result == a2 ) /*0x1039e1058*/
        result = v5; /*0x1039e1058*/
      if ( result == a2 || v6 ) /*0x1039e105c*/
      {
        v7 = 0; /*0x1039e1069*/
        if ( result != a2 ) /*0x1039e106e*/
          v7 = result; /*0x1039e106e*/
        *(_QWORD *)(a1 + 208) = v7; /*0x1039e1072*/
      }
    }
  }
  return result; /*0x1039e107a*/
}

// Address: 0x1039e107c | Name: __ZN6RakNet16ReliabilityLayer16isConnectionDeadEy
char __fastcall RakNet::ReliabilityLayer::isConnectionDead(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 a2,
        __int64 a3,
        __int64 a4,
        int a5,
        int a6)
{
  __int64 v7; // rdx
  __int64 v8; // rax

  if ( *((_DWORD *)this + 218) == 0 ) /*0x1039e1083*/
    return 0; /*0x1039e1126*/
  v7 = (unsigned int)(a2 / 0x3E8); /*0x1039e10ad*/
  v8 = *((unsigned int *)this + 62); /*0x1039e10af*/
  if ( (unsigned __int64)(v8 - v7) < 0x2711 || v7 - v8 <= (unsigned __int64)*((unsigned int *)this + 112) ) /*0x1039e10d0*/
    return 0; /*0x1039e111d*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
    FLog::FastLogFormatted(
      a1: FLog::Network,
      a2: qword_10D7BBAA8,
      a3: (unsigned int)"[FLog::Network] AckTimeout: Last Packet received time: %d ms",
      a4: a2 / 0x3E8 - v8,
      a5,
      a6);
  *((_BYTE *)this + 436) = 1; /*0x1039e1108*/
  *((_DWORD *)this + 110) = 298; /*0x1039e110f*/
  return 1; /*0x1039e1125*/
}

// Address: 0x1039e112a | Name: __ZN6RakNet16ReliabilityLayer10AckTimeoutEy
bool __fastcall RakNet::ReliabilityLayer::AckTimeout(RakNet::ReliabilityLayer *this, __int64 a2)
{
  return (unsigned __int64)*((unsigned int *)this + 62) - a2 >= 0x2711 /*0x1039e1156*/
      && a2 - (unsigned __int64)*((unsigned int *)this + 62) > *((unsigned int *)this + 112);
}

// Address: 0x1039e1158 | Name: __ZNK6RakNet16ReliabilityLayer20startOnlineBitStreamERKNS_13SystemAddressERNS_9BitStreamEPN3RBX4Rupp4RuppEy
__int64 __fastcall RakNet::ReliabilityLayer::startOnlineBitStream(
        RakNet::ReliabilityLayer *this,
        const RakNet::SystemAddress *a2,
        RakNet::BitStream *a3,
        RBX::Rupp::Rupp *a4,
        unsigned __int64 a5)
{
  __int64 result; // rax
  __int64 HeaderTotalByteLength; // r13
  unsigned __int64 v12; // rbx
  __int64 v13; // rax
  RakNet::ReliabilityLayer *v14; // rbx
  unsigned int v15[2]; // [rsp+0h] [rbp-60h] BYREF
  unsigned __int64 v16; // [rsp+8h] [rbp-58h]
  const RakNet::SystemAddress *v17; // [rsp+20h] [rbp-40h]
  RakNet::ReliabilityLayer *v18; // [rsp+28h] [rbp-38h]
  unsigned __int64 v19; // [rsp+30h] [rbp-30h]

  result = RakNet::BitStream::Reset(this: a3); /*0x1039e117b*/
  if ( a4 != nullptr ) /*0x1039e1183*/
  {
    v19 = a5; /*0x1039e1189*/
    v17 = a2; /*0x1039e118d*/
    HeaderTotalByteLength = (unsigned __int16)RBX::Rupp::Rupp::getHeaderTotalByteLength(this: a4); /*0x1039e1199*/
    if ( ((unsigned int)RakNet::BitStream::GetNumberOfBitsAllocated(this: a3) + 7) >> 3 < (unsigned int)HeaderTotalByteLength ) /*0x1039e11ae*/
      RakNet::BitStream::AddBitsAndReallocate(this: a3, a2: 8 * HeaderTotalByteLength); /*0x1039e11bb*/
    RakNet::ReliabilityLayer::reportRuppMissingTlvs(this, a2: a4); /*0x1039e11c6*/
    v18 = this; /*0x1039e11e6*/
    v12 = v19 / 0x3E8; /*0x1039e11ed*/
    v13 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a3 + 16LL))(a1: a3); /*0x1039e11f8*/
    RBX::Rupp::Rupp::serialize(a1: v15, a2: a4, a3: v13, a4: HeaderTotalByteLength, a5: v19); /*0x1039e120b*/
    if ( v15[0] != 0 ) /*0x1039e121b*/
      RakNet::ReliabilityLayer::reportRuppSerializationFailure(a1: v18, a2: a4, a3: v17, a4: v15, a5: (unsigned int)v12); /*0x1039e122e*/
    v19 = v12; /*0x1039e1233*/
    v14 = v18; /*0x1039e1237*/
    result = RakNet::BitStream::SetWriteOffset(this: a3, a2: 8 * (int)HeaderTotalByteLength, a3: false); /*0x1039e1247*/
    if ( *((_QWORD *)a4 + 6) != 0 ) /*0x1039e1251*/
      return RakNet::RakPeer::reportLateRuppTokenUpdate( /*0x1039e1269*/
               a1: *((_QWORD *)v14 + 518),
               a2: v17,
               a3: v15[1],
               a4: v16,
               a5: v19);
  }
  return result; /*0x1039e126e*/
}

// Address: 0x1039e127e | Name: __ZNK6RakNet16ReliabilityLayer21reportRuppMissingTlvsERKN3RBX4Rupp4RuppE
__int64 __fastcall RakNet::ReliabilityLayer::reportRuppMissingTlvs(
        RakNet::ReliabilityLayer *this,
        const RBX::Rupp::Rupp *a2)
{
  __int64 result; // rax
  char hasTlv; // r14
  unsigned __int8 v6; // r12
  bool v7; // dl
  unsigned __int8 v8; // r14

  result = DFInt::MaxRuppMissingTlvReports; /*0x1039e127e*/
  if ( *((_QWORD *)this + 524) < (unsigned __int64)DFInt::MaxRuppMissingTlvReports ) /*0x1039e128c*/
  {
    hasTlv = RBX::Rupp::Rupp::hasTlv(a1: a2, a2: 1); /*0x1039e12b0*/
    if ( *(_BYTE *)(*((_QWORD *)this + 518) + 3728LL) != 0 ) /*0x1039e12c1*/
      v6 = 0; /*0x1039e12c3*/
    else
      v6 = RBX::Rupp::Rupp::hasTlv(a1: a2, a2: 2) ^ 1; /*0x1039e12d8*/
    result = RakNet::SystemAddress::operator!=(a1: (char *)this + 4160, a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS); /*0x1039e12ea*/
    if ( (_BYTE)result != 0 ) /*0x1039e12f1*/
    {
      result = RBX::Rupp::Rupp::hasTlv(a1: a2, a2: 6); /*0x1039e12fb*/
      v6 = result ^ 1; /*0x1039e1303*/
    }
    if ( hasTlv == 0 || v6 != 0 ) /*0x1039e130f*/
    {
      v8 = hasTlv ^ 1; /*0x1039e1311*/
      if ( DFFlag::RakNetRuppTelemetryReportNetworkStack == 1 ) /*0x1039e131c*/
        result = RBX::Rupp::reportRuppMissingTlvs(a1: v8, a2: v6, a3: 0); /*0x1039e1328*/
      else
        result = RBX::Rupp::reportRuppMissingTlvs_deprecated(this: (RBX::Rupp *)v8, a2: v6, a3: v7); /*0x1039e1337*/
      ++*((_QWORD *)this + 524); /*0x1039e133c*/
    }
  }
  return result; /*0x1039e134b*/
}

// Address: 0x1039e134c | Name: __ZNK6RakNet16ReliabilityLayer30reportRuppSerializationFailureERKN3RBX4Rupp4RuppERKNS_13SystemAddressERKNS2_19SerializationResultEj
void __fastcall RakNet::ReliabilityLayer::reportRuppSerializationFailure(
        __int64 a1,
        __int64 a2,
        RakNet::SystemAddress *a3,
        int *a4,
        unsigned int a5)
{
  __int64 v8; // r12
  __int64 RemoteSystem; // rax
  __int64 v10; // rdx
  unsigned __int64 v11; // rcx
  bool v12; // al
  unsigned int v13; // r12d
  __int64 v14; // r15
  __int64 v15; // rax
  _BYTE v16[72]; // [rsp+0h] [rbp-520h] BYREF
  _BYTE v17[528]; // [rsp+48h] [rbp-4D8h] BYREF
  _BYTE v18[72]; // [rsp+258h] [rbp-2C8h] BYREF
  _BYTE v19[528]; // [rsp+2A0h] [rbp-280h] BYREF
  _BYTE v20[48]; // [rsp+4B0h] [rbp-70h] BYREF
  RakNet::SystemAddress *v21; // [rsp+4E0h] [rbp-40h]
  __int64 v22; // [rsp+4E8h] [rbp-38h]
  __int64 v23; // [rsp+4F0h] [rbp-30h]

  v23 = a2; /*0x1039e1363*/
  v22 = *((_QWORD *)a4 + 1); /*0x1039e136e*/
  v8 = *(_QWORD *)(a1 + 4144); /*0x1039e1375*/
  v21 = a3; /*0x1039e1386*/
  RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v18, a2: a3); /*0x1039e138d*/
  RemoteSystem = RakNet::RakPeer::GetRemoteSystem(a1: v8, a2: (__int64)v18, a3: 1, a4: 1u); /*0x1039e13a2*/
  if ( RemoteSystem != 0 ) /*0x1039e13aa*/
  {
    v10 = a5 - *(_QWORD *)(RemoteSystem + 5184); /*0x1039e13af*/
    v11 = *(_QWORD *)(RemoteSystem + 5328); /*0x1039e13b6*/
    *(_QWORD *)(RemoteSystem + 5328) = v11 + 1; /*0x1039e13c1*/
    v12 = v11 < DFInt::MaxRuppSerializationFailureReportsToPoints; /*0x1039e13d5*/
  }
  else
  {
    v12 = false; /*0x1039e13da*/
    v10 = 0; /*0x1039e13dc*/
  }
  v13 = a5; /*0x1039e13de*/
  if ( DFFlag::RakNetRuppTelemetryReportNetworkStack == 1 ) /*0x1039e13ef*/
    RBX::Rupp::reportRuppSerializationFailure(a1: v23, a2: a4, a3: v10, a4: v22, a5: v12, a6: 0); /*0x1039e1402*/
  else
    RBX::Rupp::reportRuppSerializationFailure_deprecated(a1: v23, a2: a4, a3: v10, a4: v22, a5: v12); /*0x1039e1417*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)4,std::enable_if<false,void>>( /*0x1039e142a*/
    a1: v18,
    a2: &RBX::Telemetry::kRuppSerializationResultCounter);
  RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v19); /*0x1039e1439*/
  RBX::Telemetry::FieldsContainer::addArchitectureInfo(this: (RBX::Telemetry::FieldsContainer *)v19); /*0x1039e1441*/
  RBX::Telemetry::FieldsContainer::addField(a1: v19, a2: "errorCode", a3: 9, a4: *a4, a5: 1); /*0x1039e145e*/
  RBX::Telemetry::FieldsContainer::addField(a1: v19, a2: "tokenGenerated", a3: 14, a4: a4[1] == 0, a5: 1); /*0x1039e1482*/
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v18); /*0x1039e148e*/
  if ( *(_BYTE *)(a1 + 4201) != 0 ) /*0x1039e149a*/
  {
    *(_BYTE *)(a1 + 4201) = 1; /*0x1039e14a0*/
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1039e14b5*/
      a1: (__int64)v16,
      a2: (__int64)&RBX::Telemetry::kRuppSerializationResultKibana);
    RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v17); /*0x1039e14c4*/
    RBX::Telemetry::FieldsContainer::addArchitectureInfo(this: (RBX::Telemetry::FieldsContainer *)v17); /*0x1039e14cc*/
    v14 = *(_QWORD *)(a1 + 4144); /*0x1039e14d1*/
    RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v20, a2: v21); /*0x1039e14e0*/
    v15 = RakNet::RakPeer::GetRemoteSystem(a1: v14, a2: (__int64)v20, a3: 1, a4: 1u); /*0x1039e14f6*/
    if ( v15 != 0 ) /*0x1039e14fe*/
      RBX::Telemetry::FieldsContainer::addField( /*0x1039e151f*/
        a1: v17,
        a2: "connectionTime",
        a3: 14,
        a4: v13 - *(_QWORD *)(v15 + 5184),
        a5: 1);
    RBX::Telemetry::FieldsContainer::addField(a1: v17, a2: "errorCode", a3: 9, a4: *a4, a5: 1); /*0x1039e153c*/
    RBX::Telemetry::FieldsContainer::addField(a1: v17, a2: "tokenGenerated", a3: 14, a4: a4[1] == 0, a5: 1); /*0x1039e1560*/
    RBX::Telemetry::FieldsContainer::addField( /*0x1039e157e*/
      a1: v17,
      a2: "timeSinceLastTokenGenerationMs",
      a3: 30,
      a4: *((_QWORD *)a4 + 1),
      a5: 1);
    RBX::Telemetry::FieldsContainer::addField(a1: v17, a2: "userId", a3: 6, a4: *(_QWORD *)(a1 + 4208), a5: 1); /*0x1039e159f*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v16); /*0x1039e15ab*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v16); /*0x1039e15be*/
  }
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v18); /*0x1039e15d1*/
}

// Address: 0x1039e1622 | Name: __ZN6RakNet16ReliabilityLayer12checkSendNakENSt3__110shared_ptrINS_12RakNetSocketEEERNS_13SystemAddressEyRNS_9BitStreamERKNS2_IN3RBX4Rupp4RuppEEERKS5_i
void __fastcall RakNet::ReliabilityLayer::checkSendNak(
        RakNet::ReliabilityLayer *this,
        __int128 *a2,
        const RakNet::SystemAddress *a3,
        unsigned __int64 a4,
        RakNet::BitStream *a5,
        RBX::Rupp::Rupp **a6,
        __int64 a7,
        unsigned int a8)
{
  RBX::Rupp::Rupp *v12; // rcx
  bool v13; // r12
  char v14; // al
  int MaxDatagramSizeExcludingMessageHeaderBytes; // eax
  volatile signed __int64 *v16; // r14
  _WORD v17[16]; // [rsp+20h] [rbp-80h] BYREF
  __int128 v18; // [rsp+40h] [rbp-60h]
  RBX::Rupp::Rupp **v19; // [rsp+50h] [rbp-50h]
  unsigned __int64 v20; // [rsp+58h] [rbp-48h]
  const RakNet::SystemAddress *v21; // [rsp+60h] [rbp-40h]
  __int64 *v22; // [rsp+68h] [rbp-38h]
  unsigned int v23[11]; // [rsp+74h] [rbp-2Ch] BYREF

  if ( *((_DWORD *)this + 796) != 0 ) /*0x1039e163a*/
  {
    v22 = (__int64 *)((char *)this + 3176); /*0x1039e1653*/
    v19 = a6; /*0x1039e1657*/
    v12 = *a6; /*0x1039e165b*/
    v21 = a3; /*0x1039e165e*/
    v20 = a4; /*0x1039e1668*/
    RakNet::ReliabilityLayer::startOnlineBitStream(this, a2: a3, a3: a5, a4: v12, a5: a4); /*0x1039e166f*/
    v17[13] = 0; /*0x1039e1678*/
    v17[8] = 256; /*0x1039e167f*/
    v13 = *((_BYTE *)this + 4112) >= 0; /*0x1039e1691*/
    v14 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 232LL))(a1: *((_QWORD *)this + 379)); /*0x1039e169f*/
    RakNet::DatagramHeaderFormat::Serialize( /*0x1039e16d0*/
      this: (RakNet::DatagramHeaderFormat *)v17,
      a2: a5,
      a3: v14,
      a4: v23,
      a5: (*((_DWORD *)this + 1028) & 0x200000) != 0,
      a6: (*((_DWORD *)this + 1028) & 0x800000) != 0,
      a7: v13);
    MaxDatagramSizeExcludingMessageHeaderBytes = RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes( /*0x1039e16db*/
                                                   this,
                                                   a2: a8);
    DataStructures::RangeList<RakNet::uint24_t>::Serialize( /*0x1039e16f3*/
      a1: v22,
      a2: a5,
      a3: 8 * MaxDatagramSizeExcludingMessageHeaderBytes,
      a4: 1u);
    v16 = *((volatile signed __int64 **)a2 + 1); /*0x1039e16f8*/
    v18 = *a2; /*0x1039e16ff*/
    if ( v16 != nullptr ) /*0x1039e1706*/
      _InterlockedIncrement64(v16 + 1); /*0x1039e1708*/
    RakNet::ReliabilityLayer::SendBitStream(this, a2: a7, a3: v23[0]); /*0x1039e1732*/
    if ( v16 != nullptr && _InterlockedExchangeAdd64(v16 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039e174c*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v16 + 16))(a1: v16); /*0x1039e1754*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v16); /*0x1039e175a*/
    }
  }
}

// Address: 0x1039e1a00 | Name: __ZN6RakNet16ReliabilityLayer44GetMaxDatagramSizeExcludingMessageHeaderBitsEj
__int64 __fastcall RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBits(
        RakNet::ReliabilityLayer *this,
        int a2)
{
  return 8 * (unsigned int)RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes(this, a2); /*0x1039e1a0c*/
}

// Address: 0x1039e1a0e | Name: __ZN6RakNet16ReliabilityLayer13SendBitStreamENSt3__110shared_ptrINS_12RakNetSocketEEERKNS_13SystemAddressEPNS_9BitStreamEyRKNS2_IN3RBX4Rupp4RuppEEES7_jy
char __fastcall RakNet::ReliabilityLayer::SendBitStream(
        RakNet::ReliabilityLayer *this,
        const __m128i *a2,
        const __m128i *a3,
        RakNet::BitStream *a4,
        unsigned __int64 a5,
        RBX::Rupp::Rupp **a6,
        __int64 a7,
        int a8)
{
  unsigned int HeaderTotalByteLength; // eax
  unsigned int v12; // r12d
  unsigned int v13; // r14d
  RBX::Security::SessionCrypto *v14; // rdi
  bool v15; // zf
  int v16; // eax
  int v17; // eax
  double v18; // xmm0_8
  _QWORD *v19; // r14
  __int64 v20; // r13
  __int64 v21; // rdx
  __int64 v22; // rax
  _QWORD *v23; // rdi
  unsigned __int64 v24; // rdx
  __int64 v25; // rax
  __m128i v26; // xmm0
  __int64 v27; // rax
  __int64 v28; // rax
  int v29; // r13d
  std::__shared_weak_count *v30; // r14
  char result; // al
  __int64 v32; // r14
  __int64 v33; // rax
  unsigned int v34; // eax
  unsigned int v35; // r13d
  _QWORD v36[4]; // [rsp+30h] [rbp-90h] BYREF
  const __m128i *v37; // [rsp+50h] [rbp-70h]
  __int64 v38; // [rsp+58h] [rbp-68h]
  __m128i v39; // [rsp+60h] [rbp-60h] BYREF
  const __m128i *v40; // [rsp+78h] [rbp-48h]
  __int64 v41; // [rsp+80h] [rbp-40h]
  unsigned __int64 v42; // [rsp+88h] [rbp-38h]
  unsigned int v43; // [rsp+94h] [rbp-2Ch]

  v42 = a5; /*0x1039e1a25*/
  v40 = a3; /*0x1039e1a2c*/
  v37 = a2; /*0x1039e1a30*/
  v38 = a7; /*0x1039e1a3f*/
  HeaderTotalByteLength = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a4 + 24LL))(a1: a4); /*0x1039e1a49*/
  v12 = HeaderTotalByteLength; /*0x1039e1a4c*/
  if ( *a6 != nullptr ) /*0x1039e1a55*/
  {
    HeaderTotalByteLength = RBX::Rupp::Rupp::getHeaderTotalByteLength(this: *a6); /*0x1039e1a57*/
    v13 = (unsigned __int16)HeaderTotalByteLength; /*0x1039e1a5c*/
  }
  else
  {
    v13 = 0; /*0x1039e1a62*/
  }
  v14 = *(RBX::Security::SessionCrypto **)this; /*0x1039e1a65*/
  v15 = *(_QWORD *)this == 0; /*0x1039e1a68*/
  v43 = v13; /*0x1039e1a6b*/
  if ( v15 || (_BYTE)(HeaderTotalByteLength = RBX::Security::SessionCrypto::getEnabledForRaknet(this: v14)) == 0 ) /*0x1039e1a7c*/
  {
    *((_BYTE *)this + 436) = 1; /*0x1039e1b34*/
    LOBYTE(HeaderTotalByteLength) = 1; /*0x1039e1b3b*/
    LODWORD(v41) = HeaderTotalByteLength; /*0x1039e1b3d*/
    LODWORD(v24) = 300; /*0x1039e1b40*/
    v25 = 440; /*0x1039e1b45*/
  }
  else
  {
    v41 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a4 + 16LL))(a1: a4); /*0x1039e1a8b*/
    RakNet::BitStream::PadWithZeroToByteLength(this: a4, a2: v12 + 18); /*0x1039e1a99*/
    if ( *((char *)this + 4112) >= 0 ) /*0x1039e1aa5*/
    {
      v16 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 200LL))(a1: *((_QWORD *)this + 379)); /*0x1039e1ab1*/
      v17 = RakNet::ReliabilityLayer::modifyForAvoidedPacketSizes(this, a2: a4, a3: v16, a4: a8); /*0x1039e1ac2*/
      v18 = 0.0; /*0x1039e1ace*/
      if ( v17 != 0 ) /*0x1039e1ad3*/
        v18 = 1.0; /*0x1039e1ad5*/
      RBX::RunningAverage<double,double>::sample(a1: (__int64)this + 4072, a2: v18); /*0x1039e1add*/
    }
    v12 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a4 + 24LL))(a1: a4); /*0x1039e1aeb*/
    if ( DFFlag::RakNetUseSlidingWindow4 != 0 ) /*0x1039e1af5*/
    {
      v19 = *((_QWORD **)this + 379); /*0x1039e1afb*/
      v20 = v43; /*0x1039e1b0b*/
      v21 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a4 + 16LL))(a1: a4) + v43; /*0x1039e1b0f*/
      v22 = *v19; /*0x1039e1b18*/
      v23 = v19; /*0x1039e1b1b*/
      v13 = v43; /*0x1039e1b1e*/
      (*(void (__fastcall **)(_QWORD *, unsigned __int64, __int64, _QWORD, __int64))(v22 + 96))( /*0x1039e1b2c*/
        a1: v23,
        a2: v42,
        a3: v21,
        a4: v12 - 18,
        a5: 1);
    }
    else
    {
      v20 = v13; /*0x1039e1cd6*/
    }
    v34 = RBX::Security::SessionCrypto::encryptRakDataInPlace(a1: *(_QWORD *)this, a2: v20 + v41, a3: v12 - v13); /*0x1039e1ce9*/
    if ( v34 != 0 ) /*0x1039e1cf0*/
    {
      v35 = v34; /*0x1039e1cf2*/
      *(__m128i *)((char *)this + 280) = _mm_sub_epi64( /*0x1039e1d05*/
                                           _mm_loadu_si128((const __m128i *)((char *)this + 280)),
                                           (__m128i)-1LL);
      RakNet::ReliabilityLayer::reportEncryptionFailureCounter(a1: this, a2: v34); /*0x1039e1d12*/
      result = DFInt::EncryptionFailThreshold; /*0x1039e1d17*/
      if ( *((_QWORD *)this + 36) > (unsigned __int64)DFInt::EncryptionFailThreshold ) /*0x1039e1d25*/
        return RakNet::ReliabilityLayer::reportEncryptionFailureKibana(a1: this, a2: v40, a3: v35, a4: v42 / 0x3E8); /*0x1039e1d5e*/
      return result; /*0x1039e1d5e*/
    }
    *((_QWORD *)this + 36) = 0; /*0x1039e1d63*/
    v24 = v42 / 0x3E8; /*0x1039e1d83*/
    v25 = 296; /*0x1039e1d87*/
    LODWORD(v41) = 0; /*0x1039e1d8c*/
  }
  *(_DWORD *)((char *)this + v25) = v24; /*0x1039e1b4a*/
  RakNet::BPSTracker::Push1(this: (RakNet::ReliabilityLayer *)((char *)this + 3752), a2: v42, a3: v12); /*0x1039e1b61*/
  *((_DWORD *)this + 83) = v42; /*0x1039e1b66*/
  v26 = *v40; /*0x1039e1b71*/
  *(__m128i *)&v36[2] = _mm_loadu_si128(v40 + 1); /*0x1039e1b79*/
  *(__m128i *)v36 = v26; /*0x1039e1b7e*/
  if ( (unsigned __int8)RakNet::SystemAddress::operator!=( /*0x1039e1b9d*/
                          a1: (char *)this + 4160,
                          a2: &RakNet::UNASSIGNED_SYSTEM_ADDRESS) != 0 )
    RakNet::SystemAddress::operator=(a1: v36, a2: (char *)this + 4160); /*0x1039e1ba9*/
  v27 = v37->i64[1]; /*0x1039e1bb2*/
  v39 = _mm_loadu_si128(v37); /*0x1039e1bba*/
  if ( v27 != 0 ) /*0x1039e1bc2*/
    _InterlockedIncrement64((volatile signed __int64 *)(v27 + 8)); /*0x1039e1bc4*/
  v28 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a4 + 16LL))(a1: a4); /*0x1039e1bcf*/
  v29 = RakNet::SocketLayer::SendToOrDelay( /*0x1039e1c20*/
          a1: &v39,
          a2: v28,
          a3: v12,
          a4: v36,
          a5: v38,
          a6: 1,
          a7: *((_QWORD *)this + 518),
          a8: this,
          a9: v42,
          a10: "",
          a11: 0);
  v30 = (std::__shared_weak_count *)v39.i64[1]; /*0x1039e1c23*/
  if ( v39.i64[1] != 0 /*0x1039e1c3c*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(v39.i64[1] + 8), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v30 + 16LL))(a1: v30); /*0x1039e1c44*/
    std::__shared_weak_count::__release_weak(this: v30); /*0x1039e1c4a*/
  }
  RakNet::RakPeer::trackSocketSendResult(this: *((RakNet::RakPeer **)this + 518), a2: v29); /*0x1039e1c59*/
  result = DFFlag::RakNetUseSlidingWindow4 & v41; /*0x1039e1c61*/
  if ( ((unsigned __int8)DFFlag::RakNetUseSlidingWindow4 & (unsigned __int8)v41) == 1 ) /*0x1039e1c69*/
  {
    v32 = *((_QWORD *)this + 379); /*0x1039e1c6b*/
    v33 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a4 + 16LL))(a1: a4); /*0x1039e1c78*/
    result = (*(__int64 (__fastcall **)(__int64, unsigned __int64, __int64, _QWORD, _QWORD))(*(_QWORD *)v32 + 96LL))( /*0x1039e1c91*/
               a1: v32,
               a2: v42,
               a3: v33 + v43,
               a4: v12,
               a5: 0);
  }
  if ( *((_BYTE *)a4 + 8) == 1 ) /*0x1039e1c99*/
    *((_QWORD *)this + 117) += v12; /*0x1039e1c9b*/
  if ( DFFlag::RakNetUseSlidingWindow4 == 1 ) /*0x1039e1ca9*/
    *((_DWORD *)this + 270) += v12; /*0x1039e1cab*/
  if ( v29 == 0 || v29 == -3 ) /*0x1039e1cbb*/
    *((_QWORD *)this + 113) += v12; /*0x1039e1cbd*/
  return result; /*0x1039e1cc4*/
}

// Address: 0x1039e1dac | Name: __ZN6RakNet16ReliabilityLayer38prepareUnreliableWithAckReceiptHistoryEy
__int64 __fastcall RakNet::ReliabilityLayer::prepareUnreliableWithAckReceiptHistory(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 a2)
{
  __int64 result; // rax
  __int64 *v3; // r15
  unsigned int v4; // r12d
  __int64 v5; // r14
  __int64 v6; // r13
  unsigned __int64 v7; // rsi
  __int64 v8; // rax
  unsigned __int64 v9; // [rsp+0h] [rbp-50h]
  __int64 v11[6]; // [rsp+20h] [rbp-30h] BYREF

  result = *((unsigned int *)this + 32); /*0x1039e1dc1*/
  if ( (_DWORD)result != 0 ) /*0x1039e1dc9*/
  {
    v3 = (__int64 *)((char *)this + 120); /*0x1039e1dd3*/
    v4 = 0; /*0x1039e1dec*/
    v9 = a2; /*0x1039e1def*/
    do /*0x1039e1eb4*/
    {
      v5 = 16LL * v4; /*0x1039e1df9*/
      if ( *(_QWORD *)(*v3 + v5 + 8) >= a2 ) /*0x1039e1e02*/
      {
        ++v4; /*0x1039e1eae*/
      }
      else
      {
        v6 = DataStructures::MemoryPool<RakNet::InternalPacket>::Allocate( /*0x1039e1e1a*/
               a1: (__int64 *)this + 18,
               a2: (unsigned __int64)"",
               a3: 0);
        *(_DWORD *)v6 = 0xFFFFFF; /*0x1039e1e1d*/
        *(_BYTE *)(v6 + 36) = 0; /*0x1039e1e23*/
        *(_QWORD *)(v6 + 48) = 0; /*0x1039e1e26*/
        *(_DWORD *)(v6 + 20) = 0; /*0x1039e1e2a*/
        *(_QWORD *)(v6 + 64) = 0; /*0x1039e1e2d*/
        *(_WORD *)(v6 + 88) = 0; /*0x1039e1e31*/
        *(_BYTE *)(v6 + 90) = 0; /*0x1039e1e37*/
        *(_QWORD *)(v6 + 264) = 0; /*0x1039e1e3a*/
        v11[0] = v6; /*0x1039e1e41*/
        *(_DWORD *)(v6 + 72) = 0; /*0x1039e1e45*/
        *(_QWORD *)(v6 + 64) = RBX::Memory::allocateOrCrash(this: (RBX::Memory *)5, a2: v7); /*0x1039e1e52*/
        v8 = v11[0]; /*0x1039e1e56*/
        *(_DWORD *)(v11[0] + 24) = 40; /*0x1039e1e5a*/
        **(_BYTE **)(v8 + 64) = 15; /*0x1039e1e65*/
        *(_DWORD *)(*(_QWORD *)(v11[0] + 64) + 1LL) = *(_DWORD *)(*((_QWORD *)this + 15) + v5 + 4); /*0x1039e1e7d*/
        DataStructures::Queue<RakNet::InternalPacket *>::Push(a1: (__int64)this + 16, a2: v11); /*0x1039e1e91*/
        DataStructures::List<RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode>::RemoveAtIndex(a1: v3, a2: v4); /*0x1039e1e9c*/
        a2 = v9; /*0x1039e1ea1*/
        result = *((unsigned int *)this + 32); /*0x1039e1ea5*/
      }
    }
    while ( v4 < (unsigned int)result ); /*0x1039e1eb4*/
  }
  return result; /*0x1039e1eba*/
}

// Address: 0x1039e1eca | Name: __ZN6RakNet16ReliabilityLayer28cleanExpiredResendLinkedListEy
void __fastcall RakNet::ReliabilityLayer::cleanExpiredResendLinkedList(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 a2)
{
  _QWORD *v3; // r12
  _QWORD *v5; // r13
  _DWORD *v6; // rcx
  unsigned int v7; // eax
  _DWORD *v8; // r15
  __int64 v9; // rax
  _QWORD *v10; // rcx
  _QWORD *v11; // rax
  bool v12; // zf
  char *v13; // [rsp-40h] [rbp-40h]
  char *v14; // [rsp-38h] [rbp-38h]

  if ( DFFlag::GameLoadDataStatistics == 1 ) /*0x1039e1ed1*/
  {
    v3 = *((_QWORD **)this + 30); /*0x1039e1eeb*/
    if ( v3 != nullptr ) /*0x1039e1ef5*/
    {
      v13 = (char *)this + 216; /*0x1039e1f05*/
      v5 = (_QWORD *)((char *)this + 224); /*0x1039e1f09*/
      v14 = (char *)this + 144; /*0x1039e1f17*/
      do /*0x1039e1fcc*/
      {
        if ( v3[6] >= a2 ) /*0x1039e1f20*/
          break; /*0x1039e1f20*/
        v6 = (_DWORD *)*v5; /*0x1039e1f26*/
        if ( *v5 == 0 ) /*0x1039e1f2d*/
          goto LABEL_12; /*0x1039e1f2d*/
        v7 = *(_DWORD *)v3; /*0x1039e1f2f*/
        v8 = (_DWORD *)((char *)this + 224); /*0x1039e1f33*/
        do /*0x1039e1f49*/
        {
          if ( v6[8] >= v7 ) /*0x1039e1f3e*/
            v8 = v6; /*0x1039e1f3e*/
          v6 = *(_DWORD **)&v6[2 * (v6[8] < v7)]; /*0x1039e1f42*/
        }
        while ( v6 != nullptr ); /*0x1039e1f49*/
        if ( v8 == (_DWORD *)v5 || v7 < v8[8] ) /*0x1039e1f54*/
LABEL_12:
          v8 = (_DWORD *)((char *)this + 224); /*0x1039e1f56*/
        std::__tree<std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>,std::__map_value_compare<RakNet::uint24_t,std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>,std::less<RakNet::uint24_t>,true>,std::allocator<std::__value_type<RakNet::uint24_t,RakNet::InternalPacket *>>>::__remove_node_pointer( /*0x1039e1f60*/
          a1: v13,
          a2: v8);
        operator delete(a1: v8); /*0x1039e1f68*/
        v9 = v3[13]; /*0x1039e1f6d*/
        v10 = (_QWORD *)v3[14]; /*0x1039e1f72*/
        *(_QWORD *)(v9 + 112) = v10; /*0x1039e1f77*/
        v10[13] = v9; /*0x1039e1f7b*/
        v11 = *((_QWORD **)this + 30); /*0x1039e1f7f*/
        v12 = v11 == v3; /*0x1039e1f86*/
        if ( v11 == v3 ) /*0x1039e1f89*/
          v11 = v10; /*0x1039e1f89*/
        if ( v11 == v3 || v12 ) /*0x1039e1f8d*/
        {
          if ( v11 == v3 ) /*0x1039e1fa2*/
            v11 = nullptr; /*0x1039e1fa2*/
          *((_QWORD *)this + 30) = v11; /*0x1039e1fa6*/
        }
        DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: (__int64)v14, a2: v3); /*0x1039e1fbd*/
        v3 = *((_QWORD **)this + 30); /*0x1039e1fc2*/
      }
      while ( v3 != nullptr ); /*0x1039e1fcc*/
    }
  }
}

// Address: 0x1039e1fe2 | Name: __ZN6RakNet16ReliabilityLayer28createDatagramsUpToBandwidthEyyRNS_20DatagramHeaderFormatEij
__int64 __fastcall RakNet::ReliabilityLayer::createDatagramsUpToBandwidth(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 a2,
        __int64 a3,
        RakNet::DatagramHeaderFormat *a4,
        int a5,
        unsigned int a6)
{
  int v10; // r13d
  int v11; // eax
  int v12; // eax
  char v13; // al
  int v14; // eax
  __int64 result; // rax
  _BYTE v16[48]; // [rsp+0h] [rbp-60h] BYREF
  unsigned int v17; // [rsp+30h] [rbp-30h]
  int v18; // [rsp+34h] [rbp-2Ch]

  v17 = a6; /*0x1039e1ff3*/
  v18 = a5; /*0x1039e1ff7*/
  memset(v16, 0, 44); /*0x1039e2018*/
  v10 = (*(__int64 (__fastcall **)(_QWORD, unsigned __int64, __int64, _QWORD, _QWORD, _BYTE *))(**((_QWORD **)this + 379) /*0x1039e2036*/
                                                                                              + 56LL))(
          a1: *((_QWORD *)this + 379),
          a2,
          a3,
          a4: *((unsigned int *)this + 760),
          a5: *((unsigned __int8 *)a4 + 19),
          a6: v16);
  if ( DFFlag::RakNetUseSlidingWindow4 == 1 ) /*0x1039e2040*/
  {
    v11 = 0; /*0x1039e2042*/
    *((_DWORD *)this + 779) = 0; /*0x1039e2044*/
    if ( v10 > 0 ) /*0x1039e204f*/
      v11 = v10; /*0x1039e204f*/
    *((_DWORD *)this + 269) += v11; /*0x1039e2053*/
    RakNet::TxBwInfluencers::operator+=(a1: (char *)this + 1108, a2: v16); /*0x1039e2067*/
    v12 = v10; /*0x1039e206c*/
  }
  else
  {
    v12 = (*(__int64 (__fastcall **)(_QWORD, unsigned __int64, __int64, _QWORD, _QWORD, _BYTE *))(**((_QWORD **)this + 379) /*0x1039e2093*/
                                                                                                + 48LL))(
            a1: *((_QWORD *)this + 379),
            a2,
            a3,
            a4: *((unsigned int *)this + 760),
            a5: *((unsigned __int8 *)a4 + 19),
            a6: v16);
  }
  if ( v12 > 0 || v10 > 0 ) /*0x1039e209e*/
  {
    RakNet::ReliabilityLayer::fillToRetransmissionBandwidth(this, a2, a3: v12, a4: v18); /*0x1039e20b3*/
    v13 = DFFlag::RakNetUseSlidingWindow4; /*0x1039e20b8*/
    if ( DFFlag::RakNetUseSlidingWindow4 == 1 ) /*0x1039e20c0*/
    {
      v10 -= (unsigned int)(*((_DWORD *)this + 779) + 7) >> 3; /*0x1039e20d0*/
      *((_DWORD *)this + 779) = 0; /*0x1039e20d3*/
    }
  }
  else
  {
    *((_BYTE *)this + 792) = 1; /*0x1039e20e1*/
    v13 = DFFlag::RakNetUseSlidingWindow4; /*0x1039e20ea*/
  }
  if ( (v13 & 1) != 0 ) /*0x1039e20f2*/
  {
    v14 = 0; /*0x1039e20f4*/
    if ( v10 > 0 ) /*0x1039e20f9*/
      v14 = v10; /*0x1039e20f9*/
    *((_DWORD *)this + 268) += v14; /*0x1039e20fd*/
  }
  result = (unsigned int)(*((_DWORD *)this + 779) + 7) >> 3; /*0x1039e2110*/
  if ( (int)result < v10 ) /*0x1039e2116*/
  {
    *((_DWORD *)this + 779) = 0; /*0x1039e2118*/
    return RakNet::ReliabilityLayer::fillToTransmissionBandwidth(this, a2, a3: v17, a4: v10, a5: v18); /*0x1039e2134*/
  }
  return result; /*0x1039e2139*/
}

// Address: 0x1039e218e | Name: __ZN6RakNet16ReliabilityLayer29fillToRetransmissionBandwidthEyii
void __fastcall RakNet::ReliabilityLayer::fillToRetransmissionBandwidth(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 a2,
        int a3,
        int a4)
{
  __int64 v6; // r14
  _QWORD *v7; // rax
  char v8; // r13
  int v9; // r12d
  int v10; // eax
  bool v11; // zf
  char v12; // al
  _QWORD *v13; // [rsp+0h] [rbp-40h]
  RakNet::BPSTracker *v14; // [rsp+8h] [rbp-38h]

  *((_BYTE *)this + 792) = 0; /*0x1039e21a2*/
  *((_DWORD *)this + 779) = 0; /*0x1039e21a9*/
  if ( a3 <= 0 ) /*0x1039e21b8*/
    return; /*0x1039e21b8*/
  v14 = (RakNet::ReliabilityLayer *)((char *)this + 3440); /*0x1039e21cb*/
  do /*0x1039e2387*/
  {
    v6 = *((_QWORD *)this + 25); /*0x1039e21cf*/
    if ( v6 == 0 ) /*0x1039e21d9*/
      return; /*0x1039e21d9*/
    if ( *(_QWORD *)(v6 + 48) >= a2 ) /*0x1039e21e3*/
    {
      RakNet::ReliabilityLayer::PushDatagram(this); /*0x1039e23ad*/
      return; /*0x1039e23ad*/
    }
    v7 = (_QWORD *)(v6 + 48); /*0x1039e21e9*/
    v8 = 0; /*0x1039e21ed*/
    while ( 1 ) /*0x1039e21f0*/
    {
      v13 = v7; /*0x1039e21f0*/
      if ( DFFlag::NetworkTracerRespectMTU == 0 ) /*0x1039e2203*/
      {
        v10 = *((_DWORD *)this + 778); /*0x1039e2224*/
        goto LABEL_11; /*0x1039e2224*/
      }
      v10 = *((_DWORD *)this + 778); /*0x1039e220d*/
      if ( *(_QWORD *)(v6 + 264) != 0 ) /*0x1039e2214*/
      {
        v11 = v10 == 0; /*0x1039e2216*/
        v10 = 0; /*0x1039e2218*/
        if ( !v11 ) /*0x1039e221d*/
          break; /*0x1039e221d*/
      }
LABEL_11:
      v9 = *(_DWORD *)(v6 + 60) + *(_DWORD *)(v6 + 24); /*0x1039e222b*/
      if ( v10 + v9 > 8 /*0x1039e223f*/
                    * (unsigned int)RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes(
                                      this,
                                      a2: a4) )
        break; /*0x1039e223f*/
      RakNet::ReliabilityLayer::ResendListRemove(a1: this, a2: *((_QWORD *)this + 25), a3: 0); /*0x1039e2251*/
      RakNet::BPSTracker::Push1(this: v14, a2, a3: (unsigned int)(*(_DWORD *)(v6 + 24) + 7) >> 3); /*0x1039e2267*/
      RakNet::ReliabilityLayer::PushPacket(a1: this, a2, a3: v6, a4: 1); /*0x1039e227a*/
      if ( DFFlag::NetworkTracerRespectMTU == 1 && *(_QWORD *)(v6 + 264) != 0 ) /*0x1039e2290*/
        RakNet::ReliabilityLayer::PushDatagram(this); /*0x1039e2295*/
      v12 = *(_BYTE *)(v6 + 88) + 1; /*0x1039e229e*/
      *(_BYTE *)(v6 + 88) = v12; /*0x1039e22a0*/
      if ( (DFFlag::EnablePingPongPerformanceTraceCLI != 0 || DFFlag::RakNetPingTrace != 0 || DFFlag::DataPingTrace == 1) /*0x1039e22ca*/
        && v12 == 0 )
      {
        *(_BYTE *)(v6 + 88) = 2; /*0x1039e22cc*/
      }
      if ( *(_BYTE *)(v6 + 90) == 1 ) /*0x1039e22d6*/
      {
        if ( *(_BYTE *)(v6 + 56) == 1 ) /*0x1039e22dd*/
          ++*((_DWORD *)this + 243); /*0x1039e22df*/
        else
          ++*((_DWORD *)this + 244); /*0x1039e22e8*/
      }
      *(_BYTE *)(v6 + 56) = 0; /*0x1039e22ef*/
      *v13 = a2 + (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 184LL))(a1: *((_QWORD *)this + 379)); /*0x1039e230b*/
      (*(void (__fastcall **)(_QWORD, unsigned __int64))(**((_QWORD **)this + 379) + 112LL))( /*0x1039e231b*/
        a1: *((_QWORD *)this + 379),
        a2);
      if ( *(_DWORD *)(v6 + 20) != 0 ) /*0x1039e2323*/
        ++*((_DWORD *)this + 267); /*0x1039e2325*/
      else
        ++*((_DWORD *)this + 266); /*0x1039e232e*/
      RakNet::ReliabilityLayer::ResendListAddTail(a1: this, a2: v6, a3: 0); /*0x1039e233d*/
      v6 = *((_QWORD *)this + 25); /*0x1039e2342*/
      if ( v6 == 0 ) /*0x1039e234c*/
        goto LABEL_31; /*0x1039e234c*/
      v7 = (_QWORD *)(v6 + 48); /*0x1039e234e*/
      v8 = 1; /*0x1039e2352*/
      if ( *(_QWORD *)(v6 + 48) >= a2 ) /*0x1039e2359*/
      {
        RakNet::ReliabilityLayer::PushDatagram(this); /*0x1039e2362*/
        goto LABEL_31; /*0x1039e2367*/
      }
    }
    RakNet::ReliabilityLayer::PushDatagram(this); /*0x1039e2369*/
    if ( (v8 & 1) == 0 ) /*0x1039e2375*/
      return; /*0x1039e2375*/
LABEL_31:
    ; /*0x1039e2377*/
  }
  while ( (int)((unsigned int)(*((_DWORD *)this + 779) + 7) >> 3) < a3 ); /*0x1039e2387*/
}

// Address: 0x1039e23b2 | Name: __ZN6RakNet16ReliabilityLayer27fillToTransmissionBandwidthEyjii
__int64 __fastcall RakNet::ReliabilityLayer::fillToTransmissionBandwidth(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 a2,
        int a3,
        int a4,
        unsigned int a5)
{
  std::mutex *v8; // rbx
  unsigned int v9; // eax
  __int64 v10; // rcx
  unsigned __int64 v11; // rsi
  int v12; // edx
  __int64 result; // rax
  unsigned __int64 v14; // r12
  bool v15; // al
  unsigned __int64 v17; // [rsp+8h] [rbp-38h]

  v17 = (unsigned int)(a3 + 7) >> 3; /*0x1039e23db*/
  v8 = (RakNet::ReliabilityLayer *)((char *)this + 3352); /*0x1039e23df*/
  while ( 1 )
  {
    v9 = *((_DWORD *)this + 107); /*0x1039e23e6*/
    v10 = *((_QWORD *)this + 22); /*0x1039e23ed*/
    v11 = (unsigned __int64)(*((_QWORD *)this + 23) - v10) >> 3; /*0x1039e23fe*/
    v12 = (((_DWORD)v11 - 1) & (unsigned int)v11) != 0 ? v9 % (unsigned int)v11 : v9 & (v11 - 1);
    result = v12; /*0x1039e2411*/
    if ( *(_QWORD *)(v10 + 8LL * v12) != 0 ) /*0x1039e2419*/
      break; /*0x1039e2419*/
    result = (unsigned int)(*((_DWORD *)this + 779) + 7) >> 3; /*0x1039e2425*/
    if ( (int)result >= a4 ) /*0x1039e242b*/
      break; /*0x1039e242b*/
    if ( a3 != 0 ) /*0x1039e2430*/
    {
      std::mutex::lock(this: v8); /*0x1039e2435*/
      v14 = *((_QWORD *)this + 418); /*0x1039e243a*/
      std::mutex::unlock(this: v8); /*0x1039e2444*/
      v15 = v14 > v17; /*0x1039e244d*/
    }
    else
    {
      v15 = false; /*0x1039e2452*/
    }
    *((_BYTE *)this + 808) = v15; /*0x1039e2454*/
    result = RakNet::ReliabilityLayer::addToResendBuffer(this, a2, a3: a5); /*0x1039e2465*/
    if ( *((_DWORD *)this + 778) == 0 ) /*0x1039e2472*/
      break; /*0x1039e2472*/
    RakNet::ReliabilityLayer::PushDatagram(this); /*0x1039e2477*/
  }
  return result; /*0x1039e2481*/
}

// Address: 0x1039e2490 | Name: __ZNK6RakNet16ReliabilityLayer17ResendListIsEmptyEv
bool __fastcall RakNet::ReliabilityLayer::ResendListIsEmpty(RakNet::ReliabilityLayer *this)
{
  return *((_QWORD *)this + 25) == 0; /*0x1039e249f*/
}

// Address: 0x1039e24a2 | Name: __ZN6RakNet16ReliabilityLayer12PushDatagramEv
__int64 __fastcall RakNet::ReliabilityLayer::PushDatagram(RakNet::ReliabilityLayer *this)
{
  __int64 result; // rax
  unsigned int v3; // [rsp-20h] [rbp-20h] BYREF
  unsigned int v4; // [rsp-1Ch] [rbp-1Ch] BYREF

  if ( *((_DWORD *)this + 778) != 0 ) /*0x1039e24a9*/
  {
    v3 = *((_DWORD *)this + 764); /*0x1039e24ca*/
    DataStructures::List<unsigned int>::Insert(a1: (__int64)this + 3080, a2: &v3); /*0x1039e24d8*/
    v4 = (unsigned int)(*((_DWORD *)this + 778) + 7) >> 3; /*0x1039e24f4*/
    result = DataStructures::List<unsigned int>::Insert(a1: (__int64)this + 3096, a2: &v4); /*0x1039e24fb*/
    *((_DWORD *)this + 778) = 0; /*0x1039e2500*/
  }
  return result; /*0x1039e2512*/
}

// Address: 0x1039e2514 | Name: __ZN6RakNet16ReliabilityLayer17ResendListPopHeadEb
__int64 __fastcall RakNet::ReliabilityLayer::ResendListPopHead(RakNet::ReliabilityLayer *this, unsigned int a2)
{
  return RakNet::ReliabilityLayer::ResendListRemove(a1: this, a2: *((_QWORD *)this + 25), a3: a2); /*0x1039e2521*/
}

// Address: 0x1039e2528 | Name: __ZN6RakNet16ReliabilityLayer10PushPacketEyPNS_14InternalPacketEb
__int64 __fastcall RakNet::ReliabilityLayer::PushPacket(__int64 a1, __int64 a2, __int64 a3, char a4)
{
  unsigned int v6; // ebx
  __int64 v7; // rax
  int v8; // ebx
  __int64 v10; // [rsp+0h] [rbp-40h] BYREF
  __int64 v11; // [rsp+8h] [rbp-38h]
  char v12[41]; // [rsp+17h] [rbp-29h] BYREF

  v11 = a2; /*0x1039e253c*/
  v10 = a3; /*0x1039e2547*/
  v6 = *(_DWORD *)(a3 + 60) + ((*(_DWORD *)(a3 + 24) + 7) & 0xFFFFFFF8) + 7; /*0x1039e255a*/
  *(_QWORD *)(a1 + 3112) = _mm_add_epi32( /*0x1039e2577*/
                             _mm_shuffle_epi32(_mm_cvtsi32_si128(v6 & 0xFFFFFFF8), 80),
                             _mm_loadl_epi64((const __m128i *)(a1 + 3112))).u64[0];
  DataStructures::List<RakNet::InternalPacket *>::Insert(a1: a1 + 3048, a2: &v10); /*0x1039e2595*/
  v12[0] = a4 ^ 1; /*0x1039e25aa*/
  DataStructures::List<bool>::Insert(a1: a1 + 3064, a2: v12); /*0x1039e25b1*/
  v7 = v10; /*0x1039e25b6*/
  if ( DFFlag::RakNetUseSlidingWindow4 == 1 ) /*0x1039e25c1*/
  {
    v8 = v6 >> 3; /*0x1039e25c7*/
    if ( *(_BYTE *)(v10 + 88) != 0 ) /*0x1039e25ce*/
    {
      *(_QWORD *)(a1 + 1092) = _mm_add_epi32( /*0x1039e25ec*/
                                 _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v8, 0),
                                 _mm_loadl_epi64((const __m128i *)(a1 + 1092))).u64[0];
    }
    else if ( a4 != 0 ) /*0x1039e25fa*/
    {
      *(_QWORD *)(a1 + 1084) = _mm_add_epi32( /*0x1039e2618*/
                                 _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v8, 0),
                                 _mm_loadl_epi64((const __m128i *)(a1 + 1084))).u64[0];
    }
    else
    {
      *(_QWORD *)(a1 + 1100) = _mm_add_epi32( /*0x1039e263f*/
                                 _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v8, 0),
                                 _mm_loadl_epi64((const __m128i *)(a1 + 1100))).u64[0];
    }
  }
  return (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(**(_QWORD **)(a1 + 3032) + 88LL))( /*0x1039e266d*/
           a1: *(_QWORD *)(a1 + 3032),
           a2: v11,
           a3: ((unsigned int)(*(_DWORD *)(v7 + 24) + 7) >> 3) + ((unsigned int)(*(_DWORD *)(v7 + 60) + 7) >> 3));
}

// Address: 0x1039e267c | Name: __ZN6RakNet16ReliabilityLayer23UpdateSplitMessageStatsEPNS_14InternalPacketE
void __fastcall RakNet::ReliabilityLayer::UpdateSplitMessageStats(__int64 a1, __int64 a2)
{
  if ( *(_DWORD *)(a2 + 20) != 0 ) /*0x1039e2684*/
    ++*(_DWORD *)(a1 + 1068); /*0x1039e2686*/
  else
    ++*(_DWORD *)(a1 + 1064); /*0x1039e268e*/
}

// Address: 0x1039e2696 | Name: __ZN6RakNet16ReliabilityLayer26InsertPacketIntoResendListEPNS_14InternalPacketEybb
__int64 __fastcall RakNet::ReliabilityLayer::InsertPacketIntoResendList(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        unsigned int a5)
{
  return RakNet::ReliabilityLayer::ResendListAddTail(a1, a2, a3: a5); /*0x1039e269d*/
}

// Address: 0x1039e26a4 | Name: __ZN6RakNet16ReliabilityLayer17addToResendBufferEyi
void __fastcall RakNet::ReliabilityLayer::addToResendBuffer(
        RakNet::ReliabilityLayer *this,
        unsigned __int64 a2,
        int a3)
{
  int v3; // r14d
  __int64 v6; // r13
  int MessageHeaderLengthBits; // eax
  int v8; // ebx
  int v9; // eax
  bool v10; // zf
  __int64 v11; // rax
  char v12; // bl
  __int64 v13; // rax
  unsigned int v14; // eax
  __int64 v15; // rcx
  unsigned __int64 v16; // rsi
  unsigned int v17; // edx
  int v18; // r14d
  __int64 v19; // rax
  char v20; // al
  unsigned int v21; // eax
  __int64 v22; // rcx
  unsigned __int64 v23; // rsi
  int v24; // edx
  _QWORD v25[2]; // [rsp-70h] [rbp-70h] BYREF
  RakNet::BPSTracker *v26; // [rsp-60h] [rbp-60h]
  __int64 v27; // [rsp-58h] [rbp-58h]
  __int64 *v28; // [rsp-50h] [rbp-50h]
  __int64 *v29; // [rsp-48h] [rbp-48h]
  int v30; // [rsp-3Ch] [rbp-3Ch] BYREF
  unsigned int v31; // [rsp-38h] [rbp-38h]
  int v32; // [rsp-34h] [rbp-34h]

  if ( *((_DWORD *)this + 90) != 0 )
  {
    v3 = a3; /*0x1039e26c2*/
    v29 = (__int64 *)((char *)this + 352); /*0x1039e26d2*/
    v28 = (__int64 *)((char *)this + 120); /*0x1039e26da*/
    v26 = (RakNet::ReliabilityLayer *)((char *)this + 3336); /*0x1039e26e5*/
    v27 = (__int64)this + 144; /*0x1039e26f0*/
    v32 = a3; /*0x1039e26f4*/
    while ( *((_BYTE *)this + 808) == 0 )
    {
      v6 = *(_QWORD *)(*v29 + 8); /*0x1039e270c*/
      if ( *(_QWORD *)(v6 + 64) != 0 )
      {
        MessageHeaderLengthBits = GetMessageHeaderLengthBits(a1: *(_QWORD *)(*v29 + 8)); /*0x1039e271a*/
        *(_DWORD *)(v6 + 60) = MessageHeaderLengthBits; /*0x1039e2721*/
        v8 = *(_DWORD *)(v6 + 24) + MessageHeaderLengthBits; /*0x1039e2725*/
        if ( DFFlag::NetworkTracerRespectMTU != 0 ) /*0x1039e2730*/
        {
          v9 = *((_DWORD *)this + 778); /*0x1039e273a*/
          if ( *(_QWORD *)(v6 + 264) != 0 ) /*0x1039e2741*/
          {
            v10 = v9 == 0; /*0x1039e2743*/
            v9 = 0; /*0x1039e2745*/
            if ( !v10 ) /*0x1039e274a*/
              return; /*0x1039e274a*/
          }
        }
        else
        {
          v9 = *((_DWORD *)this + 778); /*0x1039e27a7*/
        }
        if ( v9 + v8 > 8 /*0x1039e27c0*/
                     * (unsigned int)RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes(
                                       this,
                                       a2: v3) )
          return; /*0x1039e27c0*/
        v12 = (*(_DWORD *)(v6 + 28) < 8u) & (0xDCu >> *(_DWORD *)(v6 + 28)); /*0x1039e27d4*/
        DataStructures::Heap<unsigned long long,RakNet::InternalPacket *,false>::Pop(a1: v29, a2: 0); /*0x1039e27dc*/
        v13 = *(int *)(v6 + 92); /*0x1039e27e1*/
        --*((_DWORD *)this + v13 + 206); /*0x1039e27e5*/
        *((double *)this + v13 + 105) = *((double *)this + v13 + 105) /*0x1039e280c*/
                                      - (double)((unsigned int)(*(_DWORD *)(v6 + 24) + 7) >> 3);
        if ( v12 == 1 ) /*0x1039e2819*/
        {
          *(_BYTE *)(v6 + 36) = 1; /*0x1039e281b*/
          *(_DWORD *)v6 = *((_DWORD *)this + 107); /*0x1039e2827*/
          *(_QWORD *)(v6 + 48) = a2 /*0x1039e283e*/
                               + (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 184LL))(a1: *((_QWORD *)this + 379));
          *(_BYTE *)(v6 + 56) = 0; /*0x1039e2842*/
          v14 = *(_DWORD *)v6; /*0x1039e2847*/
          v15 = *((_QWORD *)this + 22); /*0x1039e284b*/
          v16 = (unsigned __int64)(*((_QWORD *)this + 23) - v15) >> 3; /*0x1039e285c*/
          if ( (((_DWORD)v16 - 1) & (unsigned int)v16) != 0 ) /*0x1039e2865*/
            v17 = v14 % (unsigned int)v16; /*0x1039e28df*/
          else
            v17 = v14 & (v16 - 1); /*0x1039e2867*/
          *(_QWORD *)(v15 + 8LL * v17) = v6; /*0x1039e28e3*/
          if ( *(_BYTE *)(v6 + 90) == 1 ) /*0x1039e28ec*/
          {
            ++*((_DWORD *)this + 230); /*0x1039e28ee*/
            ++*((_DWORD *)this + 242); /*0x1039e28f5*/
          }
          ++*((_DWORD *)this + 218); /*0x1039e28fc*/
          *((_QWORD *)this + 110) += (unsigned int)(*(_DWORD *)(v6 + 24) + 7) >> 3; /*0x1039e290d*/
          RakNet::ReliabilityLayer::ResendListAddTail(a1: this, a2: v6, a3: 1); /*0x1039e291f*/
          *((_DWORD *)this + 107) = (*((_DWORD *)this + 107) + 1) & 0xFFFFFF; /*0x1039e2932*/
        }
        else if ( *(_DWORD *)(v6 + 28) == 5 ) /*0x1039e2870*/
        {
          (*(void (__fastcall **)(int *))(**((_QWORD **)this + 379) + 80LL))(a1: &v30); /*0x1039e2884*/
          v18 = (*((_DWORD *)this + 772) + v30) & 0xFFFFFF; /*0x1039e2892*/
          v31 = *(_DWORD *)(v6 + 96); /*0x1039e289d*/
          v19 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 184LL))(a1: *((_QWORD *)this + 379)); /*0x1039e28aa*/
          v25[0] = __PAIR64__(v31, v18); /*0x1039e28b3*/
          v3 = v32; /*0x1039e28b7*/
          v25[1] = a2 + v19; /*0x1039e28c1*/
          DataStructures::List<RakNet::ReliabilityLayer::UnreliableWithAckReceiptNode>::Insert( /*0x1039e28d6*/
            a1: v28,
            a2: (__int64)v25);
        }
        RakNet::BPSTracker::Push1(this: v26, a2, a3: (unsigned int)(*(_DWORD *)(v6 + 24) + 7) >> 3); /*0x1039e294a*/
        RakNet::ReliabilityLayer::PushPacket(a1: (__int64)this, a2, a3: v6, a4: v12); /*0x1039e295b*/
        v20 = *(_BYTE *)(v6 + 88) + 1; /*0x1039e2964*/
        *(_BYTE *)(v6 + 88) = v20; /*0x1039e2966*/
        if ( (DFFlag::EnablePingPongPerformanceTraceCLI != 0 /*0x1039e2990*/
           || DFFlag::RakNetPingTrace != 0
           || DFFlag::DataPingTrace == 1)
          && v20 == 0 )
        {
          *(_BYTE *)(v6 + 88) = 2; /*0x1039e2992*/
        }
        if ( *(_DWORD *)(v6 + 20) != 0 ) /*0x1039e299c*/
          ++*((_DWORD *)this + 267); /*0x1039e299e*/
        else
          ++*((_DWORD *)this + 266); /*0x1039e29a7*/
        v21 = *((_DWORD *)this + 107); /*0x1039e29ae*/
        v22 = *((_QWORD *)this + 22); /*0x1039e29b5*/
        v23 = (unsigned __int64)(*((_QWORD *)this + 23) - v22) >> 3; /*0x1039e29c6*/
        v24 = (((_DWORD)v23 - 1) & (unsigned int)v23) != 0 ? v21 % (unsigned int)v23 : v21 & (v23 - 1);
        if ( *(_QWORD *)(v22 + 8LL * v24) != 0 || DFFlag::NetworkTracerRespectMTU == 1 && *(_QWORD *)(v6 + 264) != 0 ) /*0x1039e29f4*/
          return; /*0x1039e29f4*/
      }
      else
      {
        DataStructures::Heap<unsigned long long,RakNet::InternalPacket *,false>::Pop(a1: v29, a2: 0); /*0x1039e2753*/
        v11 = *(int *)(v6 + 92); /*0x1039e2758*/
        --*((_DWORD *)this + v11 + 206); /*0x1039e275c*/
        *((double *)this + v11 + 105) = *((double *)this + v11 + 105) /*0x1039e2783*/
                                      - (double)((unsigned int)(*(_DWORD *)(v6 + 24) + 7) >> 3);
        DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: v27, a2: (_QWORD *)v6); /*0x1039e279d*/
      }
      if ( *((_DWORD *)this + 90) == 0 ) /*0x1039e29fe*/
        return; /*0x1039e29fe*/
    }
  }
}

// Address: 0x1039e2adc | Name: __ZNK6RakNet16ReliabilityLayer20ResendBufferOverflowEv
bool __fastcall RakNet::ReliabilityLayer::ResendBufferOverflow(RakNet::ReliabilityLayer *this)
{
  unsigned int v1; // eax
  __int64 v2; // rcx
  unsigned __int64 v3; // rsi
  signed int v4; // edx

  v1 = *((_DWORD *)this + 107); /*0x1039e2ae0*/
  v2 = *((_QWORD *)this + 22); /*0x1039e2ae6*/
  v3 = (unsigned __int64)(*((_QWORD *)this + 23) - v2) >> 3; /*0x1039e2af7*/
  if ( (((_DWORD)v3 - 1) & (unsigned int)v3) != 0 ) /*0x1039e2b00*/
    v4 = v1 % (unsigned int)v3; /*0x1039e2b08*/
  else
    v4 = v1 & (v3 - 1); /*0x1039e2b02*/
  return *(_QWORD *)(v2 + 8LL * v4) != 0; /*0x1039e2b15*/
}

// Address: 0x1039e2b18 | Name: __ZN6RakNet16ReliabilityLayer16writeOutMessagesEjjyRNS_20DatagramHeaderFormatERNS_9BitStreamE
__int64 __fastcall RakNet::ReliabilityLayer::writeOutMessages(
        RakNet::ReliabilityLayer *this,
        __int64 a2,
        unsigned int a3,
        __int64 a4,
        RakNet::DatagramHeaderFormat *a5,
        RakNet::BitStream *a6)
{
  int v6; // r15d
  __int64 v8; // rbx
  __int64 v9; // rcx
  __int64 v10; // r14
  int *v11; // rax
  int v12; // r13d
  __int64 v13; // r14
  __int64 v14; // rax
  __int64 v15; // rcx
  __int64 v16; // r13
  __int64 v17; // rdx
  unsigned __int8 v18; // al
  unsigned int v19; // ecx
  bool v20; // cc
  __int64 v23; // [rsp+8h] [rbp-48h]
  __int64 *v24; // [rsp+10h] [rbp-40h]
  int v26[11]; // [rsp+24h] [rbp-2Ch] BYREF

  v6 = a3 - a2; /*0x1039e2b34*/
  if ( a3 <= (unsigned int)a2 ) /*0x1039e2b37*/
    return 0; /*0x1039e2c22*/
  v24 = (__int64 *)((char *)this + 80); /*0x1039e2b44*/
  v8 = (unsigned int)a2; /*0x1039e2b48*/
  v9 = 0; /*0x1039e2b4a*/
  v10 = 0; /*0x1039e2b4c*/
  do /*0x1039e2c17*/
  {
    v11 = *(int **)(*((_QWORD *)this + 381) + 8 * v8); /*0x1039e2b57*/
    if ( (unsigned int)v11[7] >= 2 ) /*0x1039e2b5f*/
    {
      if ( v9 != 0 ) /*0x1039e2b64*/
      {
        v23 = v10; /*0x1039e2b66*/
        v12 = *v11; /*0x1039e2b6a*/
        v13 = v9; /*0x1039e2b7a*/
        v14 = DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Allocate( /*0x1039e2b7d*/
                a1: v24,
                a2: (unsigned __int64)"",
                a3: 0);
        v15 = v13; /*0x1039e2b82*/
        *(_QWORD *)(v13 + 8) = v14; /*0x1039e2b85*/
        *(_DWORD *)v14 = v12; /*0x1039e2b89*/
        v10 = v23; /*0x1039e2b8c*/
        *(_QWORD *)(v14 + 8) = 0; /*0x1039e2b90*/
        v9 = *(_QWORD *)(v15 + 8); /*0x1039e2b98*/
      }
      else
      {
        v26[0] = *v11; /*0x1039e2ba0*/
        v9 = RakNet::ReliabilityLayer::AddFirstToDatagramHistory(a1: this, a2, a3: v26, a4, a5: 0); /*0x1039e2bb6*/
      }
    }
    v16 = v9; /*0x1039e2bb9*/
    v17 = *(_QWORD *)(*((_QWORD *)this + 381) + 8 * v8); /*0x1039e2bc4*/
    if ( *(_BYTE *)(v17 + 90) == 1 ) /*0x1039e2bcc*/
    {
      v18 = *(_BYTE *)(v17 + 88); /*0x1039e2bce*/
      v19 = (unsigned __int8)v10; /*0x1039e2bd2*/
      v20 = (unsigned __int8)v10 <= v18; /*0x1039e2bd6*/
      v10 = v18; /*0x1039e2bd8*/
      if ( !v20 ) /*0x1039e2bdb*/
        v10 = v19; /*0x1039e2bdb*/
      v9 = v18 != 1; /*0x1039e2be3*/
      *((_QWORD *)this + v9 + 118) += ((unsigned int)(*(_DWORD *)(v17 + 60) + 7) >> 3) /*0x1039e2bfa*/
                                    + ((unsigned int)(*(_DWORD *)(v17 + 24) + 7) >> 3);
    }
    RakNet::ReliabilityLayer::WriteToBitStreamFromInternalPacket(a1: this, a2: a6, a3: v17, a4: v9, a5); /*0x1039e2c09*/
    ++v8; /*0x1039e2c0e*/
    --v6; /*0x1039e2c11*/
    v9 = v16; /*0x1039e2c14*/
  }
  while ( v6 != 0 ); /*0x1039e2c17*/
  return v9; /*0x1039e2c2a*/
}

// Address: 0x1039e2c3a | Name: __ZN6RakNet16ReliabilityLayer25AddFirstToDatagramHistoryENS_8uint24_tES1_yj
__int64 __fastcall RakNet::ReliabilityLayer::AddFirstToDatagramHistory(
        __int64 a1,
        __int64 a2,
        _DWORD *a3,
        __int64 a4,
        int a5)
{
  unsigned int v8; // edx
  unsigned int v9; // ecx
  bool v10; // cf
  int v11; // ecx
  int v12; // ecx
  int v13; // edx
  __int64 v14; // r13
  __int64 v15; // r12
  _QWORD v17[3]; // [rsp+8h] [rbp-48h] BYREF
  int v18; // [rsp+24h] [rbp-2Ch]

  v18 = a5; /*0x1039e2c4b*/
  v8 = *(_DWORD *)(a1 + 64); /*0x1039e2c58*/
  v9 = *(_DWORD *)(a1 + 68); /*0x1039e2c5e*/
  v10 = v9 < v8; /*0x1039e2c60*/
  v11 = v9 - v8; /*0x1039e2c60*/
  if ( v10 ) /*0x1039e2c62*/
    v11 = *(_DWORD *)(a1 + 72) + *(_DWORD *)(a1 + 68) - v8; /*0x1039e2c6b*/
  if ( v11 > FInt::RakNetDatagramMessageIdArrayLength ) /*0x1039e2c73*/
  {
    LODWORD(v17[0]) = *(_DWORD *)(a1 + 136); /*0x1039e2c81*/
    RakNet::ReliabilityLayer::RemoveFromDatagramHistory(a1, a2: v17); /*0x1039e2c86*/
    v12 = *(_DWORD *)(a1 + 136); /*0x1039e2c90*/
    v13 = 0; /*0x1039e2c9a*/
    if ( *(_DWORD *)(a1 + 64) + 1 != *(_DWORD *)(a1 + 72) ) /*0x1039e2ca1*/
      v13 = *(_DWORD *)(a1 + 64) + 1; /*0x1039e2ca1*/
    *(_DWORD *)(a1 + 64) = v13; /*0x1039e2ca4*/
    *(_DWORD *)(a1 + 136) = (v12 + 1) & 0xFFFFFF; /*0x1039e2cb1*/
  }
  v14 = a1 + 56; /*0x1039e2cb9*/
  v15 = DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Allocate( /*0x1039e2cd6*/
          a1: (__int64 *)(a1 + 80),
          a2: (unsigned __int64)"",
          a3: 0);
  *(_QWORD *)(v15 + 8) = 0; /*0x1039e2cd9*/
  *(_DWORD *)v15 = *a3; /*0x1039e2ce4*/
  v17[0] = v15; /*0x1039e2cec*/
  v17[1] = a4; /*0x1039e2cef*/
  LODWORD(v17[2]) = v18; /*0x1039e2cf6*/
  DataStructures::Queue<RakNet::ReliabilityLayer::DatagramHistoryNode>::Push(a1: v14, a2: (__int64)v17); /*0x1039e2d01*/
  return v15; /*0x1039e2d09*/
}

// Address: 0x1039e2d18 | Name: __ZN6RakNet16ReliabilityLayer30AddSubsequentToDatagramHistoryEPNS0_17MessageNumberNodeENS_8uint24_tE
__int64 __fastcall RakNet::ReliabilityLayer::AddSubsequentToDatagramHistory(__int64 a1, __int64 a2, _DWORD *a3)
{
  __int64 v5; // rax

  v5 = DataStructures::MemoryPool<RakNet::ReliabilityLayer::MessageNumberNode>::Allocate( /*0x1039e2d32*/
         a1: (__int64 *)(a1 + 80),
         a2: (unsigned __int64)"",
         a3: 0);
  *(_QWORD *)(a2 + 8) = v5; /*0x1039e2d37*/
  *(_DWORD *)v5 = *a3; /*0x1039e2d3d*/
  *(_QWORD *)(v5 + 8) = 0; /*0x1039e2d3f*/
  return *(_QWORD *)(a2 + 8); /*0x1039e2d4b*/
}

// Address: 0x1039e2d50 | Name: __ZN6RakNet16ReliabilityLayer34WriteToBitStreamFromInternalPacketEPNS_9BitStreamEPKNS_14InternalPacketEy
__int64 __fastcall RakNet::ReliabilityLayer::WriteToBitStreamFromInternalPacket(__int64 a1, __int64 a2, __int64 a3)
{
  int v6; // eax
  int v7; // eax
  unsigned __int64 v8; // rsi
  RBX::Network::NetworkTracer *v9; // rdi
  __int64 TracerObject; // rax
  RBX::Network *v11; // rdi
  __int64 v12; // r12
  char v13; // al
  __int64 v14; // rcx
  char v15; // r15
  char v16; // r13
  unsigned __int8 v17; // al
  RakNet *v18; // rdi
  unsigned __int8 v19; // al
  unsigned __int8 v20; // r15
  __int64 TimeMS; // rcx
  unsigned __int8 v22; // r15
  RakNet *v23; // rdi
  unsigned int v24; // eax
  __int64 v25; // rsi
  unsigned __int64 v26; // rsi
  RBX::Network::NetworkTracer *v27; // rdi
  __int64 v28; // rax
  RBX::Network::NetworkTracerObject *v29; // r13
  RBX::Network::NetworkTracer *v30; // r12
  int SerializedSize; // r13d
  int v32; // r15d
  unsigned int v33; // eax
  int v34; // ecx
  int v35; // ecx
  __int16 v37; // [rsp+2h] [rbp-3Eh] BYREF
  int v38; // [rsp+4h] [rbp-3Ch]
  __int64 v39; // [rsp+8h] [rbp-38h]
  char v40[41]; // [rsp+17h] [rbp-29h] BYREF

  v6 = -*(_DWORD *)(a2 + 12) & 7; /*0x1039e2d71*/
  v38 = *(_DWORD *)(a2 + 12); /*0x1039e2d74*/
  *(_DWORD *)(a2 + 12) = v38 + v6; /*0x1039e2d79*/
  v7 = *(_DWORD *)(a3 + 28); /*0x1039e2d7c*/
  switch ( v7 ) /*0x1039e2d82*/
  {
    case 7: /*0x1039e2d82*/
      v40[0] = 3; /*0x1039e2d9a*/
      break;
    case 6: /*0x1039e2d82*/
      v40[0] = 2; /*0x1039e2d94*/
      break;
    case 5: /*0x1039e2d82*/
      v40[0] = 0; /*0x1039e2d8e*/
      break;
    default:
      v40[0] = *(_DWORD *)(a3 + 28); /*0x1039e2da0*/
      break;
  }
  RakNet::BitStream::WriteBits(this: (RakNet::BitStream *)a2, a2: (const unsigned __int8 *)v40, a3: 3u, a4: true); /*0x1039e2db4*/
  if ( *(_DWORD *)(a3 + 20) != 0 ) /*0x1039e2dbe*/
    RakNet::BitStream::Write1(this: (RakNet::BitStream *)a2); /*0x1039e2dc3*/
  else
    RakNet::BitStream::Write0(this: (RakNet::BitStream *)a2); /*0x1039e2dcd*/
  if ( DFFlag::EnablePingPongPerformanceTraceCLI != 0 || DFFlag::RakNetPingTrace != 0 || DFFlag::DataPingTrace == 1 )
  {
    v8 = *(_QWORD *)(a3 + 264); /*0x1039e2dfa*/
    if ( v8 != 0 )
    {
      v9 = RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0
         ? *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24)
         : nullptr;
      TracerObject = RBX::Network::NetworkTracer::getTracerObject(this: v9, a2: v8); /*0x1039e2e1e*/
      if ( TracerObject != 0 ) /*0x1039e2e26*/
      {
        v12 = TracerObject; /*0x1039e2e2c*/
        v13 = RBX::Network::flagsSendsGoThroughConnection(this: v11); /*0x1039e2e2f*/
        v14 = a1; /*0x1039e2e34*/
        v15 = v13; /*0x1039e2e37*/
        v16 = *(_BYTE *)(a3 + 88); /*0x1039e2e3a*/
        v39 = v14; /*0x1039e2e3e*/
        v17 = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(v14 + 4144) + 200LL))(a1: *(_QWORD *)(v14 + 4144)); /*0x1039e2e4c*/
        if ( v15 != 0 ) /*0x1039e2e55*/
        {
          if ( v16 == 1 ) /*0x1039e2e5e*/
          {
            RBX::Network::NetworkTracerObject::addCheckpoint(a1: v12, a2: v17, a3: 66); /*0x1039e2e6c*/
            a1 = v39; /*0x1039e2e71*/
            v19 = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(v39 + 4144) + 200LL))(a1: *(_QWORD *)(v39 + 4144)); /*0x1039e2e7f*/
            RBX::Network::NetworkTracerObject::addCheckpoint(a1: v12, a2: v19, a3: 67); /*0x1039e2e90*/
            goto LABEL_27; /*0x1039e2e95*/
          }
          RBX::Network::NetworkTracerObject::modifyLastCheckpoint(a1: v12, a2: v17, a3: 67); /*0x1039e2ef4*/
        }
        else
        {
          v20 = v17; /*0x1039e2e97*/
          TimeMS = (unsigned int)RakNet::GetTimeMS(this: v18); /*0x1039e2e9f*/
          if ( v16 == 1 ) /*0x1039e2ea9*/
          {
            RBX::Network::NetworkTracerObject::addCheckpoint_deprecated(a1: v12, a2: v20, a3: 66, a4: TimeMS); /*0x1039e2eb3*/
            v22 = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(v39 + 4144) + 200LL))(a1: *(_QWORD *)(v39 + 4144)); /*0x1039e2ecc*/
            v24 = RakNet::GetTimeMS(this: v23); /*0x1039e2ecf*/
            v25 = v22; /*0x1039e2ed6*/
            a1 = v39; /*0x1039e2eda*/
            RBX::Network::NetworkTracerObject::addCheckpoint_deprecated(a1: v12, a2: v25, a3: 67, a4: v24); /*0x1039e2ee5*/
            goto LABEL_27; /*0x1039e2eea*/
          }
          RBX::Network::NetworkTracerObject::modifyLastCheckpoint_deprecated(a1: v12, a2: v20, a3: 67, a4: TimeMS); /*0x1039e2f03*/
        }
        a1 = v39; /*0x1039e2f08*/
      }
    }
  }
LABEL_27:
  v26 = *(_QWORD *)(a3 + 264); /*0x1039e2f0c*/
  if ( v26 != 0 )
  {
    v27 = RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0
        ? *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24)
        : nullptr;
    v28 = RBX::Network::NetworkTracer::getTracerObject(this: v27, a2: v26); /*0x1039e2f30*/
    if ( v28 != 0 && *(_QWORD *)(a3 + 264) != 0 && (*(_BYTE *)(a1 + 4114) & 8) != 0 ) /*0x1039e2f54*/
    {
      v29 = (RBX::Network::NetworkTracerObject *)v28; /*0x1039e2f5a*/
      if ( (*(unsigned int (__fastcall **)(_QWORD))(**(_QWORD **)(a1 + 3032) + 200LL))(a1: *(_QWORD *)(a1 + 3032)) > DFInt::RakNetPacketTracingMinMTUSize ) /*0x1039e2f73*/
      {
        RakNet::BitStream::Write1(this: (RakNet::BitStream *)a2); /*0x1039e2f7c*/
        *(_DWORD *)(a2 + 12) += -*(_DWORD *)(a2 + 12) & 7; /*0x1039e2f8d*/
        v30 = nullptr; /*0x1039e2f90*/
        SerializedSize = RBX::Network::NetworkTracerObject::getSerializedSize(this: v29, a2: 0); /*0x1039e2f9d*/
        v32 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1039e2fa9*/
        RakNet::BitStream::AddBitsAndReallocate(this: (RakNet::BitStream *)a2, a2: 8 * SerializedSize); /*0x1039e2fb7*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1039e2fc2*/
        if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x1039e2fd8*/
          v30 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x1039e2fda*/
        RBX::Network::NetworkTracer::serializeTracerObject(this: v30, a2: *(_QWORD *)(a3 + 264)); /*0x1039e2feb*/
        RakNet::BitStream::SetWriteOffset(this: (RakNet::BitStream *)a2, a2: 8 * (SerializedSize + v32), a3: false); /*0x1039e2fff*/
      }
    }
  }
  *(_DWORD *)(a2 + 12) += -*(_DWORD *)(a2 + 12) & 7; /*0x1039e3010*/
  v37 = *(_WORD *)(a3 + 24); /*0x1039e301c*/
  RakNet::BitStream::WriteAlignedVar16(this: (RakNet::BitStream *)a2, a2: (const char *)&v37); /*0x1039e3022*/
  v33 = *(_DWORD *)(a3 + 28); /*0x1039e3027*/
  if ( v33 <= 7 ) /*0x1039e302e*/
  {
    v34 = 220; /*0x1039e3030*/
    if ( _bittest(&v34, v33) ) /*0x1039e3035*/
    {
      RakNet::BitStream::Write<RakNet::uint24_t>(a1: a2, a2: a3); /*0x1039e3040*/
      v33 = *(_DWORD *)(a3 + 28); /*0x1039e3045*/
    }
  }
  *(_DWORD *)(a2 + 12) += -*(_DWORD *)(a2 + 12) & 7; /*0x1039e3055*/
  if ( v33 == 4 || v33 == 1 ) /*0x1039e3060*/
  {
    RakNet::BitStream::Write<RakNet::uint24_t>(a1: a2, a2: a3 + 8); /*0x1039e3069*/
    v33 = *(_DWORD *)(a3 + 28); /*0x1039e306e*/
  }
  if ( v33 <= 7 ) /*0x1039e3079*/
  {
    v35 = 154; /*0x1039e307b*/
    if ( _bittest(&v35, v33) ) /*0x1039e3080*/
    {
      RakNet::BitStream::Write<RakNet::uint24_t>(a1: a2, a2: a3 + 4); /*0x1039e308c*/
      v40[0] = *(_BYTE *)(a3 + 12); /*0x1039e3099*/
      RakNet::BitStream::WriteAlignedVar8(this: (RakNet::BitStream *)a2, a2: v40); /*0x1039e309e*/
    }
  }
  if ( *(_DWORD *)(a3 + 20) != 0 ) /*0x1039e30a7*/
  {
    RakNet::BitStream::WriteAlignedVar32(this: (RakNet::BitStream *)a2, a2: (const char *)(a3 + 20)); /*0x1039e30af*/
    RakNet::BitStream::WriteAlignedVar16(this: (RakNet::BitStream *)a2, a2: (const char *)(a3 + 14)); /*0x1039e30bb*/
    RakNet::BitStream::WriteAlignedVar32(this: (RakNet::BitStream *)a2, a2: (const char *)(a3 + 16)); /*0x1039e30c7*/
  }
  RakNet::BitStream::WriteAlignedBytes( /*0x1039e30dd*/
    this: (RakNet::BitStream *)a2,
    a2: *(const unsigned __int8 **)(a3 + 64),
    a3: (unsigned int)(*(_DWORD *)(a3 + 24) + 7) >> 3);
  if ( *(_BYTE *)(a3 + 90) == 1 ) /*0x1039e30e7*/
    *(_BYTE *)(a2 + 8) = 1; /*0x1039e30e9*/
  return (unsigned int)(*(_DWORD *)(a2 + 12) - v38); /*0x1039e30f3*/
}

// Address: 0x1039e3102 | Name: __ZN6RakNet16ReliabilityLayer13sendDatagramsENSt3__110shared_ptrINS_12RakNetSocketEEERNS_13SystemAddressERNS_9BitStreamERKNS2_IN3RBX4Rupp4RuppEEERKS5_RNS_20DatagramHeaderFormatE
void __fastcall RakNet::ReliabilityLayer::sendDatagrams(
        RakNet::ReliabilityLayer *this,
        __m128i *a2,
        const RakNet::SystemAddress *a3,
        RakNet::BitStream *a4,
        RBX::Rupp::Rupp **a5,
        __int64 a6,
        RakNet::DatagramHeaderFormat *a7)
{
  RakNet::BitStream *v7; // r15
  const RakNet::SystemAddress *v8; // r13
  __int64 v10; // r12
  bool v11; // si
  unsigned int *v12; // rax
  __int64 TimeUS; // r12
  bool v14; // si
  __int64 v15; // rsi
  unsigned int v16; // eax
  char v17; // cl
  char v18; // dl
  __int64 v19; // rdi
  bool v20; // r15
  char v21; // al
  RakNet::BitStream *v22; // r13
  RakNet::DatagramHeaderFormat *v23; // r8
  __int64 v24; // rax
  __int64 v25; // rsi
  char v26; // dl
  char v27; // r15
  bool v28; // zf
  __int64 v29; // r15
  unsigned __int8 v30; // al
  volatile signed __int64 *v31; // r15
  __m128i v32; // [rsp+20h] [rbp-80h] BYREF
  __int64 v33; // [rsp+38h] [rbp-68h]
  __int64 v34; // [rsp+40h] [rbp-60h]
  __m128i *v35; // [rsp+48h] [rbp-58h]
  const RakNet::SystemAddress *v36; // [rsp+50h] [rbp-50h]
  RBX::Rupp::Rupp **v37; // [rsp+58h] [rbp-48h]
  RakNet::BitStream *v38; // [rsp+60h] [rbp-40h]
  unsigned int v39; // [rsp+6Ch] [rbp-34h]
  unsigned int v40; // [rsp+70h] [rbp-30h]
  unsigned int v41[11]; // [rsp+74h] [rbp-2Ch] BYREF

  v34 = a6; /*0x1039e3113*/
  v37 = a5; /*0x1039e3117*/
  v35 = a2; /*0x1039e311b*/
  if ( *((_DWORD *)this + 772) != 0 ) /*0x1039e3126*/
  {
    v7 = a4; /*0x1039e312c*/
    v8 = a3; /*0x1039e312f*/
    v10 = 0; /*0x1039e3139*/
    v38 = a4; /*0x1039e313c*/
    v36 = a3; /*0x1039e3140*/
    do /*0x1039e338c*/
    {
      v33 = v10; /*0x1039e3147*/
      if ( v10 != 0 ) /*0x1039e314b*/
      {
        *((_BYTE *)a7 + 19) = 1; /*0x1039e314d*/
        (*(void (__fastcall **)(unsigned int *))(**((_QWORD **)this + 379) + 72LL))(a1: v41); /*0x1039e3160*/
        *((_DWORD *)a7 + 2) = v41[0]; /*0x1039e3166*/
        v12 = (unsigned int *)(*((_QWORD *)this + 385) + 4 * v10); /*0x1039e3171*/
        v40 = *(v12 - 1); /*0x1039e3178*/
      }
      else
      {
        (*(void (__fastcall **)(unsigned int *))(**((_QWORD **)this + 379) + 72LL))(a1: v41); /*0x1039e318b*/
        *((_DWORD *)a7 + 2) = v41[0]; /*0x1039e3191*/
        v12 = *((unsigned int **)this + 385); /*0x1039e3195*/
        v40 = 0; /*0x1039e319c*/
      }
      v39 = *v12; /*0x1039e31a5*/
      TimeUS = RakNet::GetTimeUS(this: nullptr, a2: v11); /*0x1039e31af*/
      if ( (*(unsigned __int8 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 232LL))(a1: *((_QWORD *)this + 379)) != 0 ) /*0x1039e31c4*/
        *(_QWORD *)a7 = RakNet::GetTimeUS(this: nullptr, a2: v14); /*0x1039e31cd*/
      RakNet::ReliabilityLayer::startOnlineBitStream(this, a2: v8, a3: v7, a4: *v37, a5: TimeUS); /*0x1039e31e3*/
      v16 = v39 - v40; /*0x1039e31eb*/
      if ( v39 > v40 ) /*0x1039e31ee*/
      {
        v17 = *((_BYTE *)a7 + 26); /*0x1039e31f0*/
        v18 = *((_BYTE *)a7 + 27); /*0x1039e31f4*/
        v15 = v40; /*0x1039e31f8*/
        do /*0x1039e322b*/
        {
          if ( (v17 & 1) != 0 && (v18 & 1) != 0 ) /*0x1039e3203*/
            break; /*0x1039e3203*/
          v19 = *(_QWORD *)(*((_QWORD *)this + 381) + 8 * v15); /*0x1039e320c*/
          v17 |= *(_BYTE *)(v19 + 90); /*0x1039e3210*/
          *((_BYTE *)a7 + 26) = v17; /*0x1039e3213*/
          v18 |= *(_BYTE *)(v19 + 88) >= 2u; /*0x1039e321f*/
          *((_BYTE *)a7 + 27) = v18; /*0x1039e3222*/
          ++v15; /*0x1039e3226*/
          --v16; /*0x1039e3229*/
        }
        while ( v16 != 0 ); /*0x1039e322b*/
      }
      v20 = *((_BYTE *)this + 4112) >= 0; /*0x1039e3237*/
      v21 = (*(__int64 (__fastcall **)(_QWORD, __int64))(**((_QWORD **)this + 379) + 232LL))( /*0x1039e3245*/
              a1: *((_QWORD *)this + 379),
              a2: v15);
      v22 = v38; /*0x1039e326f*/
      RakNet::DatagramHeaderFormat::Serialize( /*0x1039e327a*/
        this: a7,
        a2: v38,
        a3: v21,
        a4: v41,
        a5: (*((_DWORD *)this + 1028) & 0x200000) != 0,
        a6: (*((_DWORD *)this + 1028) & 0x800000) != 0,
        a7: v20);
      v24 = RakNet::ReliabilityLayer::writeOutMessages(this, a2: v40, a3: v39, a4: TimeUS, a5: v23, a6: v22); /*0x1039e328e*/
      v27 = v26; /*0x1039e3293*/
      if ( v24 == 0 ) /*0x1039e3299*/
        RakNet::ReliabilityLayer::AddFirstToDatagramHistory(a1: this, a2: v25, a3: TimeUS, a4: 0); /*0x1039e32a3*/
      v28 = *((_BYTE *)v22 + 8) == 1; /*0x1039e32a8*/
      v8 = v36; /*0x1039e32ad*/
      if ( v28 ) /*0x1039e32b1*/
      {
        if ( v27 == 1 ) /*0x1039e32b7*/
          ++*((_DWORD *)this + 240); /*0x1039e32b9*/
        else
          ++*((_DWORD *)this + 241); /*0x1039e32c1*/
      }
      v29 = *((_QWORD *)this + 379); /*0x1039e32c7*/
      v30 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v29 + 232LL))(a1: v29); /*0x1039e32d4*/
      (*(void (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)v29 + 88LL))( /*0x1039e32ed*/
        a1: v29,
        a2: TimeUS,
        a3: 4 * (unsigned int)v30 + 49);
      v31 = (volatile signed __int64 *)v35->i64[1]; /*0x1039e32f4*/
      v32 = *v35; /*0x1039e32fb*/
      if ( v31 != nullptr ) /*0x1039e3302*/
        _InterlockedIncrement64(v31 + 1); /*0x1039e3304*/
      RakNet::ReliabilityLayer::SendBitStream( /*0x1039e332d*/
        this,
        a2: &v32,
        a3: (const __m128i *)v8,
        a4: v38,
        a5: TimeUS,
        a6: v37,
        a7: v34,
        a8: v41[0]);
      if ( v31 != nullptr && _InterlockedExchangeAdd64(v31 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039e3347*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v31 + 16))(a1: v31); /*0x1039e334f*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v31); /*0x1039e3355*/
      }
      v28 = *((_DWORD *)this + 90) == 0; /*0x1039e335a*/
      *((_BYTE *)this + 2976) = *((_DWORD *)this + 90) != 0; /*0x1039e3361*/
      if ( v28 ) /*0x1039e336d*/
        TimeUS = 0; /*0x1039e336d*/
      *((_QWORD *)this + 391) = TimeUS; /*0x1039e3371*/
      v10 = v33 + 1; /*0x1039e337c*/
      v7 = v38; /*0x1039e3388*/
    }
    while ( v33 + 1 < (unsigned __int64)*((unsigned int *)this + 772) ); /*0x1039e338c*/
  }
}

// Address: 0x1039e33b6 | Name: __ZN6RakNet16ReliabilityLayer25AddFirstToDatagramHistoryENS_8uint24_tEyj
void __fastcall RakNet::ReliabilityLayer::AddFirstToDatagramHistory(_DWORD *a1, __int64 a2, __int64 a3, int a4)
{
  unsigned int v7; // edx
  unsigned int v8; // ecx
  bool v9; // cf
  int v10; // ecx
  int v11; // ecx
  int v12; // edx
  _QWORD v13[6]; // [rsp+0h] [rbp-30h] BYREF

  v7 = a1[16]; /*0x1039e33cc*/
  v8 = a1[17]; /*0x1039e33d2*/
  v9 = v8 < v7; /*0x1039e33d4*/
  v10 = v8 - v7; /*0x1039e33d4*/
  if ( v9 ) /*0x1039e33d6*/
    v10 = a1[18] + a1[17] - v7; /*0x1039e33dd*/
  if ( v10 > FInt::RakNetDatagramMessageIdArrayLength ) /*0x1039e33e5*/
  {
    LODWORD(v13[0]) = a1[34]; /*0x1039e33f1*/
    RakNet::ReliabilityLayer::RemoveFromDatagramHistory((__int64)a1, a2: v13); /*0x1039e33f6*/
    v11 = a1[34]; /*0x1039e33fe*/
    v12 = 0; /*0x1039e3406*/
    if ( a1[16] + 1 != a1[18] ) /*0x1039e340b*/
      v12 = a1[16] + 1; /*0x1039e340b*/
    a1[16] = v12; /*0x1039e340e*/
    a1[34] = (v11 + 1) & 0xFFFFFF; /*0x1039e3419*/
  }
  v13[0] = 0; /*0x1039e3427*/
  v13[1] = a3; /*0x1039e342e*/
  LODWORD(v13[2]) = a4; /*0x1039e3432*/
  DataStructures::Queue<RakNet::ReliabilityLayer::DatagramHistoryNode>::Push(a1: (__int64)(a1 + 14), a2: (__int64)v13); /*0x1039e3442*/
}

// Address: 0x1039e3452 | Name: __ZN6RakNet16ReliabilityLayer12fillSendDataENSt3__110shared_ptrINS_12RakNetSocketEEERNS_13SystemAddressEyjRNS_9BitStreamERKNS2_IN3RBX4Rupp4RuppEEERKS5_yiRNS_20DatagramHeaderFormatE
void __fastcall RakNet::ReliabilityLayer::fillSendData(
        RakNet::ReliabilityLayer *this,
        __m128i *a2,
        const RakNet::SystemAddress *a3,
        unsigned __int64 a4,
        unsigned int a5,
        RakNet::BitStream *a6,
        RBX::Rupp::Rupp **a7,
        __int64 a8,
        unsigned __int64 a9,
        int a10,
        RakNet::DatagramHeaderFormat *a11)
{
  volatile signed __int64 *v15; // r15
  __m128i v16; // [rsp+10h] [rbp-50h] BYREF
  RakNet::BitStream *v17; // [rsp+28h] [rbp-38h]
  const RakNet::SystemAddress *v18; // [rsp+30h] [rbp-30h]

  v17 = a6; /*0x1039e3463*/
  v18 = a3; /*0x1039e346d*/
  *((_WORD *)a11 + 8) = 0; /*0x1039e347b*/
  *((_BYTE *)a11 + 18) = 0; /*0x1039e3482*/
  RakNet::ReliabilityLayer::ResetPacketsAndDatagrams(this); /*0x1039e3487*/
  RakNet::ReliabilityLayer::createDatagramsUpToBandwidth(this, a2: a4, a3: a9, a4: a11, a5: a10, a6: a5); /*0x1039e34a0*/
  v15 = (volatile signed __int64 *)a2->i64[1]; /*0x1039e34a5*/
  v16 = *a2; /*0x1039e34af*/
  if ( v15 != nullptr ) /*0x1039e34b6*/
    _InterlockedIncrement64(v15 + 1); /*0x1039e34b8*/
  RakNet::ReliabilityLayer::sendDatagrams(this, a2: &v16, a3: v18, a4: v17, a5: a7, a6: a8, a7: a11); /*0x1039e34d8*/
  if ( v15 != nullptr && _InterlockedExchangeAdd64(v15 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039e34f2*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v15 + 16))(a1: v15); /*0x1039e34fa*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v15); /*0x1039e3500*/
  }
  RakNet::ReliabilityLayer::ClearPacketsAndDatagrams(this); /*0x1039e3508*/
  *((_BYTE *)this + 2976) = *((_DWORD *)this + 90) != 0; /*0x1039e3514*/
}

// Address: 0x1039e353e | Name: __ZN6RakNet16ReliabilityLayer24ResetPacketsAndDatagramsEv
void __fastcall RakNet::ReliabilityLayer::ResetPacketsAndDatagrams(RakNet::ReliabilityLayer *this)
{
  unsigned int v2; // eax
  void *v3; // rdi
  unsigned int v4; // eax
  void *v5; // rdi
  unsigned int v6; // eax
  void *v7; // rdi
  unsigned int v8; // eax
  void *v9; // rdi

  v2 = *((_DWORD *)this + 765); /*0x1039e3547*/
  if ( v2 != 0 ) /*0x1039e354f*/
  {
    if ( v2 >= 0x201 ) /*0x1039e3556*/
    {
      v3 = *((void **)this + 381); /*0x1039e3558*/
      if ( v3 != nullptr ) /*0x1039e3562*/
        operator delete[](a1: v3); /*0x1039e3564*/
      *((_DWORD *)this + 765) = 0; /*0x1039e3569*/
      *((_QWORD *)this + 381) = 0; /*0x1039e3573*/
    }
    *((_DWORD *)this + 764) = 0; /*0x1039e357e*/
  }
  v4 = *((_DWORD *)this + 769); /*0x1039e3588*/
  if ( v4 != 0 ) /*0x1039e3590*/
  {
    if ( v4 >= 0x201 ) /*0x1039e3597*/
    {
      v5 = *((void **)this + 383); /*0x1039e3599*/
      if ( v5 != nullptr ) /*0x1039e35a3*/
        operator delete[](a1: v5); /*0x1039e35a5*/
      *((_DWORD *)this + 769) = 0; /*0x1039e35aa*/
      *((_QWORD *)this + 383) = 0; /*0x1039e35b4*/
    }
    *((_DWORD *)this + 768) = 0; /*0x1039e35bf*/
  }
  v6 = *((_DWORD *)this + 773); /*0x1039e35c9*/
  if ( v6 != 0 ) /*0x1039e35d1*/
  {
    if ( v6 >= 0x201 ) /*0x1039e35d8*/
    {
      v7 = *((void **)this + 385); /*0x1039e35da*/
      if ( v7 != nullptr ) /*0x1039e35e4*/
        operator delete[](a1: v7); /*0x1039e35e6*/
      *((_DWORD *)this + 773) = 0; /*0x1039e35eb*/
      *((_QWORD *)this + 385) = 0; /*0x1039e35f5*/
    }
    *((_DWORD *)this + 772) = 0; /*0x1039e3600*/
  }
  v8 = *((_DWORD *)this + 777); /*0x1039e360a*/
  if ( v8 != 0 ) /*0x1039e3612*/
  {
    if ( v8 >= 0x201 ) /*0x1039e3619*/
    {
      v9 = *((void **)this + 387); /*0x1039e361b*/
      if ( v9 != nullptr ) /*0x1039e3625*/
        operator delete[](a1: v9); /*0x1039e3627*/
      *((_DWORD *)this + 777) = 0; /*0x1039e362c*/
      *((_QWORD *)this + 387) = 0; /*0x1039e3636*/
    }
    *((_DWORD *)this + 776) = 0; /*0x1039e3641*/
  }
  *((_DWORD *)this + 778) = 0; /*0x1039e364b*/
}

// Address: 0x1039e365c | Name: __ZN6RakNet16ReliabilityLayer6UpdateENSt3__110shared_ptrINS_12RakNetSocketEEERNS_13SystemAddressEiyjRNS_9BitStreamERKNS2_IN3RBX4Rupp4RuppEEERKS5_
__int64 __fastcall RakNet::ReliabilityLayer::Update(
        RakNet::ReliabilityLayer *this,
        __int64 a2,
        const RakNet::SystemAddress *a3,
        __int64 a4,
        unsigned __int64 a5,
        unsigned int a6,
        RakNet::BitStream *a7,
        RBX::Rupp::Rupp **a8,
        __int64 a9)
{
  unsigned __int64 v12; // rax
  __int64 v13; // r13
  unsigned __int64 v14; // r14
  __int64 v15; // rdx
  __int64 v16; // rcx
  int v17; // r8d
  int v18; // r9d
  char isConnectionDead; // cl
  __int64 result; // rax
  volatile signed __int64 *v21; // r12
  unsigned int HeaderTotalByteLength; // ecx
  volatile signed __int64 *v23; // r12
  bool v24; // zf
  __int64 v25; // rsi
  bool v26; // r12
  __int64 i; // r12
  volatile signed __int64 *v28; // r12
  _BYTE v29[26]; // [rsp+30h] [rbp-A0h] BYREF
  __int16 v30; // [rsp+4Ah] [rbp-86h]
  __m128i v31; // [rsp+50h] [rbp-80h]
  __m128i v32; // [rsp+60h] [rbp-70h] BYREF
  __m128i v33; // [rsp+70h] [rbp-60h] BYREF
  __int64 v34; // [rsp+80h] [rbp-50h]
  int v35; // [rsp+8Ch] [rbp-44h]
  __int64 v36; // [rsp+90h] [rbp-40h]
  const RakNet::SystemAddress *v37; // [rsp+98h] [rbp-38h]
  bool v38; // [rsp+A7h] [rbp-29h]

  v12 = *((_QWORD *)this + 360); /*0x1039e368d*/
  if ( v12 >= a5 ) /*0x1039e3697*/
  {
    *((_QWORD *)this + 360) = a5; /*0x1039e379b*/
    return 1; /*0x1039e37a2*/
  }
  else
  {
    v13 = a6; /*0x1039e369d*/
    v36 = a2; /*0x1039e36a0*/
    if ( DFFlag::RakNetUseSlidingWindow4 == 1 ) /*0x1039e36ab*/
    {
      RakNet::ReliabilityLayer::SnapshotTxBwData(this, a2: a5 / 0x3E8, a3: a5 / 0x3E8, a4: 0x20C49BA5E353F7CFLL, a5, a6); /*0x1039e36b6*/
      v12 = *((_QWORD *)this + 360); /*0x1039e36bb*/
    }
    v14 = a5 - v12; /*0x1039e36c5*/
    *((_QWORD *)this + 360) = a5; /*0x1039e36c8*/
    if ( a5 - v12 >= 0x186A0 ) /*0x1039e36d7*/
      v14 = 100000; /*0x1039e36d7*/
    RakNet::ReliabilityLayer::cleanExpiredUnreliable(this, a2: a5, a3: v14); /*0x1039e36e4*/
    isConnectionDead = RakNet::ReliabilityLayer::isConnectionDead(this, a2: a5, a3: v15, a4: v16, a5: v17, a6: v18); /*0x1039e36f4*/
    result = 1; /*0x1039e36f6*/
    if ( isConnectionDead == 0 ) /*0x1039e36fd*/
    {
      v37 = a3; /*0x1039e3703*/
      if ( (*(unsigned __int8 (__fastcall **)(_QWORD, unsigned __int64, unsigned __int64))(**((_QWORD **)this + 379) /*0x1039e371c*/
                                                                                         + 64LL))(
             a1: *((_QWORD *)this + 379),
             a2: a5,
             a3: v14) != 0 )
      {
        v21 = *(volatile signed __int64 **)(v36 + 8); /*0x1039e3722*/
        v31 = *(__m128i *)v36; /*0x1039e3729*/
        if ( v21 != nullptr ) /*0x1039e3730*/
          _InterlockedIncrement64(v21 + 1); /*0x1039e3732*/
        RakNet::ReliabilityLayer::SendACKs(this, a2: a9); /*0x1039e3756*/
        if ( v21 != nullptr && _InterlockedExchangeAdd64(v21 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039e3771*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v21 + 16))(a1: v21); /*0x1039e377a*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v21); /*0x1039e3780*/
        }
      }
      if ( *a8 != nullptr ) /*0x1039e378f*/
        HeaderTotalByteLength = (unsigned __int16)RBX::Rupp::Rupp::getHeaderTotalByteLength(this: *a8); /*0x1039e3796*/
      else
        HeaderTotalByteLength = 0; /*0x1039e37ac*/
      v23 = *(volatile signed __int64 **)(v36 + 8); /*0x1039e37b2*/
      v32 = *(__m128i *)v36; /*0x1039e37b9*/
      if ( v23 != nullptr ) /*0x1039e37c0*/
        _InterlockedIncrement64(v23 + 1); /*0x1039e37c2*/
      v35 = HeaderTotalByteLength; /*0x1039e37c8*/
      RakNet::ReliabilityLayer::checkSendNak( /*0x1039e37ed*/
        this,
        a2: (__int128 *)v32.i8,
        a3: v37,
        a4: a5,
        a5: a7,
        a6: a8,
        a7: a9,
        a8: HeaderTotalByteLength);
      if ( v23 != nullptr && _InterlockedExchangeAdd64(v23 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039e3808*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v23 + 16))(a1: v23); /*0x1039e3811*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v23); /*0x1039e3817*/
      }
      v30 = 0; /*0x1039e381c*/
      v29[20] = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 216LL))(a1: *((_QWORD *)this + 379)); /*0x1039e3835*/
      v29[19] = *((_BYTE *)this + 2976); /*0x1039e3841*/
      v24 = *((_DWORD *)this + 90) == 0; /*0x1039e3847*/
      *((_BYTE *)this + 2976) = *((_DWORD *)this + 90) != 0; /*0x1039e384e*/
      if ( DFFlag::RakNetCalculateApplicationFeedback2 == 1 ) /*0x1039e3875*/
        v25 = *((_QWORD *)this + 82); /*0x1039e3877*/
      else
        v25 = 0; /*0x1039e3880*/
      v26 = !v24 || *((_QWORD *)this + 25) != 0; /*0x1039e3882*/
      (*(void (__fastcall **)(_QWORD, __int64))(**((_QWORD **)this + 379) + 40LL))(a1: *((_QWORD *)this + 379), a2: v25); /*0x1039e3888*/
      *((_QWORD *)this + 102) = (unsigned int)(v13 + 7) >> 3; /*0x1039e3892*/
      *((_QWORD *)this + 100) = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 224LL))(a1: *((_QWORD *)this + 379)); /*0x1039e38a9*/
      if ( *((_QWORD *)this + 508) + 100000LL < a5 ) /*0x1039e38bf*/
      {
        v38 = v26; /*0x1039e38c1*/
        v34 = v13; /*0x1039e38c5*/
        for ( i = 0; i != 832; i += 104 ) /*0x1039e38d0*/
          RakNet::BPSTracker::ClearExpired1(this: (RakNet::ReliabilityLayer *)((char *)this + i + 3232), a2: a5); /*0x1039e38da*/
        *((_QWORD *)this + 508) = a5; /*0x1039e38ec*/
        LODWORD(v13) = v34; /*0x1039e38f3*/
        v26 = v38; /*0x1039e38f7*/
      }
      RakNet::ReliabilityLayer::prepareUnreliableWithAckReceiptHistory(this, a2: a5); /*0x1039e3901*/
      RakNet::ReliabilityLayer::cleanExpiredResendLinkedList(this, a2: a5); /*0x1039e390c*/
      if ( v26 ) /*0x1039e3911*/
      {
        v28 = *(volatile signed __int64 **)(v36 + 8); /*0x1039e391f*/
        v33 = *(__m128i *)v36; /*0x1039e3926*/
        if ( v28 != nullptr ) /*0x1039e392d*/
          _InterlockedIncrement64(v28 + 1); /*0x1039e392f*/
        RakNet::ReliabilityLayer::fillSendData( /*0x1039e3973*/
          this,
          a2: &v33,
          a3: v37,
          a4: a5,
          a5: v13,
          a6: a7,
          a7: a8,
          a8: a9,
          a9: v14,
          a10: v35,
          a11: (RakNet::DatagramHeaderFormat *)v29);
        if ( v28 != nullptr && _InterlockedExchangeAdd64(v28 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039e398e*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v28 + 16))(a1: v28); /*0x1039e3997*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v28); /*0x1039e399d*/
        }
      }
      return *((unsigned int *)this + 90); /*0x1039e39a2*/
    }
  }
  return result; /*0x1039e39a8*/
}

// Address: 0x1039e39e0 | Name: __ZN6RakNet16ReliabilityLayer8SendACKsENSt3__110shared_ptrINS_12RakNetSocketEEERKNS_13SystemAddressEyRNS_9BitStreamERKNS2_IN3RBX4Rupp4RuppEEES7_
__int64 __fastcall RakNet::ReliabilityLayer::SendACKs(
        RakNet::ReliabilityLayer *this,
        __m128i *a2,
        RakNet::SystemAddress *a3,
        unsigned __int64 a4,
        RakNet::BitStream *a5,
        RBX::Rupp::Rupp **a6,
        __int64 a7)
{
  int HeaderTotalByteLength; // esi
  unsigned int v11; // ebx
  __int64 result; // rax
  char v13; // r12
  float v14; // xmm0_4
  char v15; // al
  bool v16; // bl
  char v17; // al
  __int64 v18; // rdx
  unsigned __int64 v19; // rcx
  unsigned __int64 v20; // rax
  int v21; // eax
  volatile signed __int64 *v22; // r12
  __int64 v23; // rbx
  unsigned int v24; // eax
  _BYTE v25[8]; // [rsp+18h] [rbp-B8h] BYREF
  __m128i v26; // [rsp+20h] [rbp-B0h] BYREF
  unsigned __int64 v27; // [rsp+30h] [rbp-A0h] BYREF
  float v28; // [rsp+3Ch] [rbp-94h]
  __int16 v29; // [rsp+40h] [rbp-90h]
  char v30; // [rsp+42h] [rbp-8Eh]
  char v31; // [rsp+46h] [rbp-8Ah]
  __int16 v32; // [rsp+4Ah] [rbp-86h]
  double v33; // [rsp+50h] [rbp-80h] BYREF
  __m128i *v34; // [rsp+58h] [rbp-78h]
  unsigned __int64 v35; // [rsp+60h] [rbp-70h]
  __int64 *v36; // [rsp+68h] [rbp-68h]
  __int64 v37; // [rsp+70h] [rbp-60h] BYREF
  RBX::Rupp::Rupp **v38; // [rsp+78h] [rbp-58h]
  RakNet::SystemAddress *v39; // [rsp+80h] [rbp-50h]
  unsigned int v40; // [rsp+8Ch] [rbp-44h] BYREF
  __int64 v41; // [rsp+90h] [rbp-40h] BYREF
  int v42; // [rsp+9Ch] [rbp-34h] BYREF
  unsigned int v43; // [rsp+A0h] [rbp-30h] BYREF
  _BYTE v44[41]; // [rsp+A7h] [rbp-29h] BYREF

  v39 = a3; /*0x1039e39fa*/
  v34 = a2; /*0x1039e39fe*/
  v38 = a6; /*0x1039e3a05*/
  if ( *a6 != nullptr ) /*0x1039e3a0f*/
    HeaderTotalByteLength = (unsigned __int16)RBX::Rupp::Rupp::getHeaderTotalByteLength(this: *a6); /*0x1039e3a16*/
  else
    HeaderTotalByteLength = 0; /*0x1039e3a1b*/
  v11 = 8 * RakNet::ReliabilityLayer::GetMaxDatagramSizeExcludingMessageHeaderBytes(this, a2: HeaderTotalByteLength); /*0x1039e3a27*/
  v43 = v11; /*0x1039e3a2a*/
  result = (*(__int64 (__fastcall **)(_QWORD, __int64 *, __int64 *))(**((_QWORD **)this + 379) + 176LL))( /*0x1039e3a3f*/
             a1: *((_QWORD *)this + 379),
             a2: &v37,
             a3: &v41);
  v13 = result; /*0x1039e3a45*/
  if ( (_BYTE)result != 0 ) /*0x1039e3a4a*/
    v43 = v11 - 6; /*0x1039e3a4f*/
  if ( *((_DWORD *)this + 792) != 0 ) /*0x1039e3a5a*/
  {
    v36 = (__int64 *)((char *)this + 3160); /*0x1039e3a7b*/
    v35 = a4 / 0x3E8; /*0x1039e3a83*/
    do /*0x1039e3cf5*/
    {
      RakNet::ReliabilityLayer::startOnlineBitStream(this, a2: v39, a3: a5, a4: *v38, a5: a4); /*0x1039e3a9b*/
      v32 = 0; /*0x1039e3aa0*/
      v29 = 1; /*0x1039e3aa9*/
      v31 = v13; /*0x1039e3ab2*/
      if ( (*(unsigned __int8 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 232LL))(a1: *((_QWORD *)this + 379)) != 0 ) /*0x1039e3acb*/
        v27 = a4; /*0x1039e3acd*/
      if ( *((_BYTE *)this + 3192) == 1 ) /*0x1039e3adc*/
      {
        (*(void (__fastcall **)(_QWORD, unsigned __int64, _BYTE *, _BYTE *, double *))(**((_QWORD **)this + 379) + 152LL))( /*0x1039e3afa*/
          a1: *((_QWORD *)this + 379),
          a2: a4,
          a3: v44,
          a4: v25,
          a5: &v33);
        v14 = v33; /*0x1039e3b03*/
        v28 = v14; /*0x1039e3b08*/
        v15 = v44[0]; /*0x1039e3b10*/
      }
      else
      {
        v15 = 0; /*0x1039e3b15*/
      }
      v30 = v15; /*0x1039e3b17*/
      if ( (*(unsigned __int8 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 232LL))(a1: *((_QWORD *)this + 379)) != 0 ) /*0x1039e3b2f*/
        v27 = *((_QWORD *)this + 378); /*0x1039e3b38*/
      v16 = *((_BYTE *)this + 4112) >= 0; /*0x1039e3b49*/
      v17 = (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 379) + 232LL))(a1: *((_QWORD *)this + 379)); /*0x1039e3b56*/
      RakNet::DatagramHeaderFormat::Serialize( /*0x1039e3b8a*/
        this: (RakNet::DatagramHeaderFormat *)&v27,
        a2: a5,
        a3: v17,
        a4: &v40,
        a5: (*((_DWORD *)this + 1028) & 0x200000) != 0,
        a6: (*((_DWORD *)this + 1028) & 0x800000) != 0,
        a7: v16);
      if ( DFFlag::RakNetEnsureAckSendLoopIsFinite == 1 ) /*0x1039e3b96*/
      {
        result = RakNet::ReliabilityLayer::SerializeSomeAcknowlegements(this, a2: a5, a3: &v43); /*0x1039e3ba2*/
        if ( (_BYTE)result == 0 ) /*0x1039e3ba9*/
          return result; /*0x1039e3ba9*/
      }
      else
      {
        DataStructures::RangeList<RakNet::uint24_t>::Serialize(a1: v36, a2: a5, a3: v43, a4: 1u); /*0x1039e3bbf*/
      }
      if ( (v13 & 1) != 0 && *((_DWORD *)this + 792) == 0 ) /*0x1039e3bd2*/
      {
        v18 = v41; /*0x1039e3bd4*/
        v19 = a4 - v41; /*0x1039e3bdb*/
        v41 = a4 - v41; /*0x1039e3be1*/
        v20 = a4 - v37; /*0x1039e3be5*/
        v37 = a4 - v37; /*0x1039e3be9*/
        if ( v37 != 0 && v20 <= 0xFFFFFF && a4 != v18 && v19 <= 0xFFFFFF ) /*0x1039e3c03*/
        {
          v42 = v20; /*0x1039e3c05*/
          RakNet::BitStream::Write<RakNet::uint24_t>(a1: a5, a2: &v42); /*0x1039e3c12*/
          v42 = v41 & 0xFFFFFF; /*0x1039e3c21*/
          RakNet::BitStream::Write<RakNet::uint24_t>(a1: a5, a2: &v42); /*0x1039e3c2a*/
        }
      }
      v21 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a5 + 24LL))(a1: a5); /*0x1039e3c35*/
      if ( *((_DWORD *)this + 63) > v21 ) /*0x1039e3c41*/
        v21 = *((_DWORD *)this + 63); /*0x1039e3c41*/
      *((_DWORD *)this + 63) = v21; /*0x1039e3c44*/
      *((_DWORD *)this + 64) = v35; /*0x1039e3c4f*/
      v22 = (volatile signed __int64 *)v34->i64[1]; /*0x1039e3c5a*/
      v26 = *v34; /*0x1039e3c61*/
      if ( v22 != nullptr ) /*0x1039e3c6b*/
        _InterlockedIncrement64(v22 + 1); /*0x1039e3c6d*/
      RakNet::ReliabilityLayer::SendBitStream( /*0x1039e3c9a*/
        this,
        a2: &v26,
        a3: (const __m128i *)v39,
        a4: a5,
        a5: a4,
        a6: v38,
        a7,
        a8: v40);
      if ( v22 != nullptr && _InterlockedExchangeAdd64(v22 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1039e3cb5*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v22 + 16))(a1: v22); /*0x1039e3cbe*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v22); /*0x1039e3cc4*/
      }
      v23 = *((_QWORD *)this + 379); /*0x1039e3cc9*/
      v24 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a5 + 24LL))(a1: a5); /*0x1039e3cd6*/
      result = (*(__int64 (__fastcall **)(__int64, unsigned __int64, _QWORD))(*(_QWORD *)v23 + 160LL))( /*0x1039e3ce4*/
                 a1: v23,
                 a2: a4,
                 a3: v24);
      v13 = 0; /*0x1039e3cea*/
    }
    while ( *((_DWORD *)this + 792) != 0 ); /*0x1039e3cf5*/
  }
  return result; /*0x1039e3cfb*/
}

// Address: 0x1039e3d24 | Name: __ZN6RakNet16ReliabilityLayer27modifyForAvoidedPacketSizesEPNS_9BitStreamEii
__int64 __fastcall RakNet::ReliabilityLayer::modifyForAvoidedPacketSizes(
        RakNet::ReliabilityLayer *this,
        RakNet::BitStream *a2,
        unsigned int a3,
        unsigned int a4)
{
  unsigned int v7; // eax
  unsigned int v8; // r15d
  unsigned int v9; // r14d
  char *v10; // r15
  char *v11; // r12
  unsigned int v12; // eax
  unsigned __int64 v13; // rdx
  unsigned __int64 v14; // rsi
  unsigned __int64 v15; // rcx
  __int64 v16; // rcx
  unsigned int v17; // eax
  int v18; // eax
  unsigned int v19; // r12d
  unsigned int v20; // ecx
  unsigned __int8 *v21; // rsi
  RakNet::BitStream *v22; // rdi
  RakNet::BitStream *v24; // rdi
  unsigned __int8 v25[2]; // [rsp+Ah] [rbp-36h] BYREF
  unsigned int v26; // [rsp+Ch] [rbp-34h]
  unsigned int v27; // [rsp+10h] [rbp-30h]
  _WORD v28[21]; // [rsp+16h] [rbp-2Ah] BYREF

  v27 = a4; /*0x1039e3d35*/
  v7 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1039e3d47*/
  v8 = 0; /*0x1039e3d4a*/
  v26 = a3; /*0x1039e3d4d*/
  if ( v7 < a3 ) /*0x1039e3d54*/
  {
    v9 = 0; /*0x1039e3d56*/
    while ( 1 ) /*0x1039e3d59*/
    {
      v10 = *((char **)this + 515); /*0x1039e3d59*/
      v11 = *((char **)this + 516); /*0x1039e3d60*/
      v12 = v9 + (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1039e3d70*/
      v15 = v11 - v10; /*0x1039e3d76*/
      if ( v11 != v10 ) /*0x1039e3d79*/
      {
        v15 = (__int64)v15 >> 2; /*0x1039e3d7b*/
        do /*0x1039e3da7*/
        {
          v13 = v15 >> 1; /*0x1039e3d82*/
          v14 = v15 + ~(v15 >> 1); /*0x1039e3d8b*/
          v16 = (__int64)&v10[4 * (v15 >> 1) + 4]; /*0x1039e3d92*/
          if ( *(_DWORD *)(v16 - 4) < v12 ) /*0x1039e3d99*/
            v10 = (char *)v16; /*0x1039e3d9d*/
          else
            v14 = v13; /*0x1039e3d99*/
          v15 = v14; /*0x1039e3da1*/
        }
        while ( v14 != 0 ); /*0x1039e3da7*/
      }
      if ( v10 == v11 || v12 < *(_DWORD *)v10 ) /*0x1039e3db1*/
        break; /*0x1039e3db1*/
      v8 = v9 + 1; /*0x1039e3db3*/
      v17 = v9 /*0x1039e3dc3*/
          + (*(__int64 (__fastcall **)(RakNet::BitStream *, unsigned __int64, unsigned __int64, unsigned __int64))(*(_QWORD *)a2 + 24LL))(
              a1: a2,
              a2: v14,
              a3: v13,
              a4: v15)
          + 1;
      ++v9; /*0x1039e3dc5*/
      if ( v17 >= v26 ) /*0x1039e3dcb*/
        goto LABEL_14; /*0x1039e3dcb*/
    }
    v8 = v9; /*0x1039e3dcf*/
  }
LABEL_14:
  v18 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1039e3dd2*/
  RakNet::BitStream::PadWithZeroToByteLength(this: a2, a2: v18 + v8); /*0x1039e3de2*/
  v19 = *((_DWORD *)a2 + 3); /*0x1039e3de7*/
  RakNet::BitStream::SetWriteOffset(this: a2, a2: v27, a3: false); /*0x1039e3df3*/
  v28[0] = v8; /*0x1039e3df8*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039e3e70*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v24); /*0x1039e3e77*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039e3e84*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039e3e0e*/
  {
    v21 = (unsigned __int8 *)v28; /*0x1039e3e10*/
    v22 = a2; /*0x1039e3e14*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v28, a2: v25, a3: (unsigned __int8 *)2, a4: v20); /*0x1039e3e29*/
    v22 = a2; /*0x1039e3e2e*/
    v21 = v25; /*0x1039e3e31*/
  }
  RakNet::BitStream::WriteBits(this: v22, a2: v21, a3: 0x10u, a4: true); /*0x1039e3e3e*/
  RakNet::BitStream::SetWriteOffset(this: a2, a2: v19, a3: false); /*0x1039e3e4b*/
  return v8; /*0x1039e3e53*/
}

// Address: 0x1039e3ea8 | Name: __ZNK6RakNet16ReliabilityLayer30reportEncryptionFailureCounterEN3RBX8Security13SessionCrypto16EncryptionResultE
void __fastcall RakNet::ReliabilityLayer::reportEncryptionFailureCounter(
        RBX::Security::SessionCrypto **a1,
        unsigned int a2)
{
  unsigned __int8 IsAesGcm; // al
  _BYTE v5[72]; // [rsp+0h] [rbp-270h] BYREF
  _BYTE v6[552]; // [rsp+48h] [rbp-228h] BYREF

  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)4,std::enable_if<false,void>>( /*0x1039e3ecc*/
    a1: v5,
    a2: &RBX::Telemetry::kRakNetEncryptionResultCounter);
  RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v6); /*0x1039e3edb*/
  RBX::Telemetry::FieldsContainer::addArchitectureInfo(this: (RBX::Telemetry::FieldsContainer *)v6); /*0x1039e3ee3*/
  RBX::Telemetry::FieldsContainer::addField(a1: v6, a2: "encryptionResult", a3: 16, a4: a2, a5: 1); /*0x1039e3f00*/
  RBX::Telemetry::FieldsContainer::addField(a1: v6, a2: "datacenter", a3: 10, a4: RBX::Analytics::datacenterId, a5: 1); /*0x1039e3f24*/
  IsAesGcm = RBX::Security::SessionCrypto::rakIsAesGcm(this: *a1); /*0x1039e3f2c*/
  RBX::Telemetry::FieldsContainer::addField(a1: v6, a2: "rakIsAesGcm", a3: 11, a4: IsAesGcm, a5: 1); /*0x1039e3f49*/
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v5); /*0x1039e3f55*/
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v5); /*0x1039e3f68*/
}

// Address: 0x1039e3f9a | Name: __ZN6RakNet16ReliabilityLayer29reportEncryptionFailureKibanaERKNS_13SystemAddressEN3RBX8Security13SessionCrypto16EncryptionResultEj
void __fastcall RakNet::ReliabilityLayer::reportEncryptionFailureKibana(
        __int64 a1,
        const RakNet::SystemAddress *a2,
        unsigned int a3,
        unsigned int a4)
{
  __int64 v8; // r15
  __int64 RemoteSystem; // rax
  unsigned int v10; // ebx
  unsigned __int8 IsAesGcm; // al
  __int64 TxNonce; // rax
  __int64 RxNonce; // rax
  _BYTE v14[72]; // [rsp+18h] [rbp-2C8h] BYREF
  _BYTE v15[528]; // [rsp+60h] [rbp-280h] BYREF
  _QWORD v16[14]; // [rsp+270h] [rbp-70h] BYREF

  if ( *(_BYTE *)(a1 + 4200) == 0 )
  {
    *(_BYTE *)(a1 + 4200) = 1; /*0x1039e3fc6*/
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1039e3fdb*/
      a1: (__int64)v14,
      a2: (__int64)&RBX::Telemetry::kRakNetEncryptionResultKibana);
    RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v15); /*0x1039e3fea*/
    RBX::Telemetry::FieldsContainer::addArchitectureInfo(this: (RBX::Telemetry::FieldsContainer *)v15); /*0x1039e3ff2*/
    v8 = *(_QWORD *)(a1 + 4144); /*0x1039e3ff7*/
    RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v16, a2); /*0x1039e4006*/
    RemoteSystem = RakNet::RakPeer::GetRemoteSystem(a1: v8, a2: (__int64)v16, a3: 1, a4: 1u); /*0x1039e401f*/
    if ( RemoteSystem != 0 ) /*0x1039e4027*/
      RBX::Telemetry::FieldsContainer::addField( /*0x1039e404b*/
        a1: v15,
        a2: "connectionTime",
        a3: 14,
        a4: a4 - *(_QWORD *)(RemoteSystem + 5184),
        a5: 1);
    RBX::Telemetry::FieldsContainer::addField(a1: v15, a2: "encryptionResult", a3: 16, a4: a3, a5: 1); /*0x1039e406f*/
    v10 = a4 - *(_DWORD *)(a1 + 296); /*0x1039e4074*/
    RBX::Telemetry::FieldsContainer::addField(a1: v15, a2: "timeSinceLastSuccessfulEncrypt", a3: 30, a4: v10, a5: 1); /*0x1039e4098*/
    RBX::Telemetry::FieldsContainer::addField(a1: v15, a2: "userId", a3: 6, a4: *(_QWORD *)(a1 + 4208), a5: 1); /*0x1039e40be*/
    IsAesGcm = RBX::Security::SessionCrypto::rakIsAesGcm(this: *(RBX::Security::SessionCrypto **)a1); /*0x1039e40c7*/
    RBX::Telemetry::FieldsContainer::addField(a1: v15, a2: "rakIsAesGcm", a3: 11, a4: IsAesGcm, a5: 1); /*0x1039e40e8*/
    TxNonce = RBX::Security::RakPeerCrypto::unitTestGetTxNonce(this: *(RBX::Security::RakPeerCrypto **)a1); /*0x1039e40f1*/
    RBX::Telemetry::FieldsContainer::addField(a1: v15, a2: "txNonce", a3: 7, a4: TxNonce, a5: 1); /*0x1039e4112*/
    RxNonce = RBX::Security::RakPeerCrypto::unitTestGetRxNonce(this: *(RBX::Security::RakPeerCrypto **)a1); /*0x1039e411b*/
    RBX::Telemetry::FieldsContainer::addField(a1: v15, a2: "rxNonce", a3: 7, a4: RxNonce, a5: 1); /*0x1039e413c*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v14); /*0x1039e4148*/
    if ( (unsigned __int8)DFLog::SessionCrypto >= 6u && (DFLog::SessionCrypto & 0xFE00) != 0 )
    {
      v16[0] = a3; /*0x1039e416f*/
      v16[2] = v10; /*0x1039e4173*/
      v16[7] = 65; /*0x1039e4177*/
      v16[8] = v16; /*0x1039e417f*/
      FLog::detail::FastLogSafeFormattedInternal(
        a1: DFLog::SessionCrypto,
        a2: qword_10D7BB210,
        a3: 2,
        a4: (unsigned int)"[DFLog::SessionCrypto] Encryption failure detected. Result: {}, timeSinceLastSuccessfulEncryptMs ",
        a5: 97,
        a6: 1,
        65,
        v16);
    }
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v14); /*0x1039e41b6*/
  }
}

// Address: 0x1039e41f2 | Name: __ZN6RakNet16ReliabilityLayer21IsOutgoingDataWaitingEv
bool __fastcall RakNet::ReliabilityLayer::IsOutgoingDataWaiting(RakNet::ReliabilityLayer *this)
{
  bool result; // al

  result = true; /*0x1039e41f6*/
  if ( *((_DWORD *)this + 90) == 0 ) /*0x1039e41ff*/
    return *((_DWORD *)this + 218) != 0; /*0x1039e4208*/
  return result; /*0x1039e420b*/
}

// Address: 0x1039e420e | Name: __ZN6RakNet16ReliabilityLayer14AreAcksWaitingEv
bool __fastcall RakNet::ReliabilityLayer::AreAcksWaiting(RakNet::ReliabilityLayer *this)
{
  return *((_DWORD *)this + 792) != 0; /*0x1039e421c*/
}

// Address: 0x1039e421e | Name: __ZN6RakNet16ReliabilityLayer31SetSplitMessageProgressIntervalEi
void __fastcall RakNet::ReliabilityLayer::SetSplitMessageProgressInterval(RakNet::ReliabilityLayer *this, int a2)
{
  *((_DWORD *)this + 10) = a2; /*0x1039e4222*/
}

// Address: 0x1039e4228 | Name: __ZN6RakNet16ReliabilityLayer20SetUnreliableTimeoutEj
__int64 __fastcall RakNet::ReliabilityLayer::SetUnreliableTimeout(RakNet::ReliabilityLayer *this, unsigned int a2)
{
  __int64 result; // rax

  result = 1000LL * a2; /*0x1039e422e*/
  *((_QWORD *)this + 6) = result; /*0x1039e4235*/
  return result; /*0x1039e4239*/
}

// Address: 0x1039e423c | Name: __ZN6RakNet16ReliabilityLayer15IsSendThrottledEi
__int64 __fastcall RakNet::ReliabilityLayer::IsSendThrottled(RakNet::ReliabilityLayer *this)
{
  return 0; /*0x1039e4242*/
}

// Address: 0x1039e4244 | Name: __ZN6RakNet16ReliabilityLayer26UpdateWindowFromPacketlossEy
void __fastcall RakNet::ReliabilityLayer::UpdateWindowFromPacketloss(RakNet::ReliabilityLayer *this)
{
  ; /*0x1039e4244*/
}

// Address: 0x1039e424a | Name: __ZN6RakNet16ReliabilityLayer19UpdateWindowFromAckEy
void __fastcall RakNet::ReliabilityLayer::UpdateWindowFromAck(RakNet::ReliabilityLayer *this)
{
  ; /*0x1039e424a*/
}

// Address: 0x1039e4250 | Name: __ZN6RakNet16ReliabilityLayer16ResendListRemoveEPNS_14InternalPacketEb
__int64 __fastcall RakNet::ReliabilityLayer::ResendListRemove(__int64 a1, __int64 a2, char a3)
{
  __int64 v3; // rax
  __int64 v4; // rcx
  __int64 result; // rax
  bool v6; // zf
  __int64 v7; // rax
  __int64 v8; // rcx
  bool v9; // zf
  __int64 v10; // rcx

  if ( DFFlag::GameLoadDataStatistics != 0 ) /*0x1039e425b*/
  {
    v3 = *(_QWORD *)(a2 + 104); /*0x1039e425d*/
    v4 = *(_QWORD *)(a2 + 112); /*0x1039e4261*/
    *(_QWORD *)(v3 + 112) = v4; /*0x1039e4265*/
    *(_QWORD *)(v4 + 104) = v3; /*0x1039e4269*/
    result = *(_QWORD *)(a1 + 200); /*0x1039e426d*/
    v6 = result == a2; /*0x1039e4274*/
    if ( result == a2 ) /*0x1039e4277*/
      result = v4; /*0x1039e4277*/
    if ( result != a2 && !v6 ) /*0x1039e427b*/
      goto LABEL_12; /*0x1039e4288*/
LABEL_9:
    v10 = 0; /*0x1039e42b9*/
    if ( result != a2 ) /*0x1039e42be*/
      v10 = result; /*0x1039e42be*/
    *(_QWORD *)(a1 + 200) = v10; /*0x1039e42c2*/
    goto LABEL_12; /*0x1039e42c2*/
  }
  v7 = *(_QWORD *)(a2 + 104); /*0x1039e428c*/
  v8 = *(_QWORD *)(a2 + 112); /*0x1039e4290*/
  *(_QWORD *)(v7 + 112) = v8; /*0x1039e4294*/
  *(_QWORD *)(v8 + 104) = v7; /*0x1039e4298*/
  result = *(_QWORD *)(a1 + 200); /*0x1039e429c*/
  v9 = result == a2; /*0x1039e42a3*/
  if ( result == a2 ) /*0x1039e42a6*/
    result = v8; /*0x1039e42a6*/
  if ( v9 || result == a2 ) /*0x1039e42b0*/
    goto LABEL_9; /*0x1039e42b7*/
LABEL_12:
  if ( a3 != 0 ) /*0x1039e42cb*/
  {
    result = (unsigned int)(*(_DWORD *)(a2 + 60) + *(_DWORD *)(a2 + 24) + 7) >> 3; /*0x1039e42d8*/
    *(_DWORD *)(a1 + 3040) -= result; /*0x1039e42db*/
  }
  return result; /*0x1039e42e1*/
}

// Address: 0x1039e42e4 | Name: __ZN6RakNet16ReliabilityLayer28DeleteSequencedPacketsInListEhRN14DataStructures4ListIPNS_14InternalPacketEEEi
__int64 __fastcall RakNet::ReliabilityLayer::DeleteSequencedPacketsInList(__int64 a1, char a2, __int64 a3, int a4)
{
  __int64 result; // rax
  unsigned int v7; // r12d
  __int64 v8; // rcx
  __int64 v9; // r13
  int v10; // edx
  unsigned int v11; // eax
  char v13; // [rsp+14h] [rbp-2Ch]

  result = *(unsigned int *)(a3 + 8); /*0x1039e42f9*/
  if ( (_DWORD)result != 0 ) /*0x1039e42fe*/
  {
    v7 = 0; /*0x1039e4319*/
    v13 = a2; /*0x1039e431c*/
    do /*0x1039e43aa*/
    {
      v8 = v7; /*0x1039e4322*/
      v9 = *(_QWORD *)(*(_QWORD *)a3 + 8LL * v7); /*0x1039e4325*/
      v10 = *(_DWORD *)(v9 + 28); /*0x1039e4329*/
      if ( (v10 == 4 || v10 == 1) && *(_BYTE *)(v9 + 12) == a2 && (a4 == -1 || *(unsigned __int16 *)(v9 + 14) != a4) ) /*0x1039e434b*/
      {
        v11 = result - 1; /*0x1039e4352*/
        if ( v11 > v7 ) /*0x1039e4357*/
        {
          do /*0x1039e4371*/
          {
            *(_QWORD *)(*(_QWORD *)a3 + 8 * v8) = *(_QWORD *)(*(_QWORD *)a3 + 8 * v8 + 8); /*0x1039e4363*/
            ++v8; /*0x1039e436b*/
          }
          while ( v11 != v8 ); /*0x1039e4371*/
        }
        *(_DWORD *)(a3 + 8) = v11; /*0x1039e4373*/
        RakNet::ReliabilityLayer::FreeInternalPacketData(a1, a2: v9); /*0x1039e438a*/
        DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: a1 + 144, a2: (_QWORD *)v9); /*0x1039e439b*/
        result = *(unsigned int *)(a3 + 8); /*0x1039e43a0*/
        a2 = v13; /*0x1039e43a4*/
      }
      else
      {
        ++v7; /*0x1039e434d*/
      }
    }
    while ( v7 < (unsigned int)result ); /*0x1039e43aa*/
  }
  return result; /*0x1039e43b0*/
}

// Address: 0x1039e43c0 | Name: __ZN6RakNet16ReliabilityLayer28DeleteSequencedPacketsInListEhRN14DataStructures5QueueIPNS_14InternalPacketEEE
unsigned __int64 __fastcall RakNet::ReliabilityLayer::DeleteSequencedPacketsInList(__int64 a1, char a2, __int64 a3)
{
  char v4; // r8
  unsigned int v5; // eax
  int v6; // ecx
  bool v7; // cf
  unsigned __int64 result; // rax
  signed int v9; // r12d
  signed int v10; // r15d
  unsigned int v11; // eax
  unsigned int v12; // ecx
  __int64 v13; // r13

  v4 = a2; /*0x1039e43d4*/
  v5 = *(_DWORD *)(a3 + 12); /*0x1039e43db*/
  v6 = 0; /*0x1039e43de*/
  v7 = v5 < *(_DWORD *)(a3 + 8); /*0x1039e43e0*/
  result = v5 - *(_DWORD *)(a3 + 8); /*0x1039e43e0*/
  if ( v7 ) /*0x1039e43e3*/
    v6 = *(_DWORD *)(a3 + 16); /*0x1039e43e5*/
  v9 = result + v6; /*0x1039e43e8*/
  if ( (int)result + v6 > 0 ) /*0x1039e43ef*/
  {
    v10 = 0; /*0x1039e4405*/
    do /*0x1039e447c*/
    {
      v11 = v10 + *(_DWORD *)(a3 + 8); /*0x1039e440f*/
      v12 = *(_DWORD *)(a3 + 16); /*0x1039e4412*/
      if ( v11 < v12 ) /*0x1039e441a*/
        v12 = 0; /*0x1039e441a*/
      v13 = *(_QWORD *)(*(_QWORD *)a3 + 8LL * (v11 - v12)); /*0x1039e441f*/
      result = *(unsigned int *)(v13 + 28); /*0x1039e4423*/
      if ( ((_DWORD)result == 4 || (_DWORD)result == 1) && *(_BYTE *)(v13 + 12) == v4 ) /*0x1039e4435*/
      {
        DataStructures::Queue<RakNet::InternalPacket *>::RemoveAtIndex(a1: a3, a2: v10); /*0x1039e443d*/
        RakNet::ReliabilityLayer::FreeInternalPacketData(a1, a2: v13); /*0x1039e4455*/
        result = DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: a1 + 144, a2: (_QWORD *)v13); /*0x1039e4466*/
        v4 = a2; /*0x1039e446b*/
        --v9; /*0x1039e4471*/
      }
      else
      {
        ++v10; /*0x1039e4476*/
      }
    }
    while ( v10 < v9 ); /*0x1039e447c*/
  }
  return result; /*0x1039e447e*/
}

// Address: 0x1039e44fc | Name: __ZN6RakNet16ReliabilityLayer23AllocInternalPacketDataEPNS_14InternalPacketEPPNS_28InternalPacketRefCountedDataEPhS6_
__int64 __fastcall RakNet::ReliabilityLayer::AllocInternalPacketData(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        __int64 a5)
{
  __int64 result; // rax
  __int64 v9; // rax

  *(_DWORD *)(a2 + 72) = 1; /*0x1039e4509*/
  *(_QWORD *)(a2 + 64) = a5; /*0x1039e4510*/
  result = *a3; /*0x1039e4514*/
  if ( *a3 != 0 ) /*0x1039e451a*/
  {
    ++*(_DWORD *)(result + 8); /*0x1039e451c*/
  }
  else
  {
    v9 = DataStructures::MemoryPool<RakNet::InternalPacketRefCountedData>::Allocate( /*0x1039e4537*/
           a1: (__int64 *)(a1 + 3200),
           a2: (unsigned __int64)"",
           a3: 0);
    *a3 = v9; /*0x1039e453c*/
    *(_DWORD *)(v9 + 8) = 1; /*0x1039e453f*/
    *(_QWORD *)v9 = a4; /*0x1039e4546*/
    result = *a3; /*0x1039e4549*/
  }
  *(_QWORD *)(a2 + 80) = result; /*0x1039e454c*/
  return result; /*0x1039e4554*/
}

// Address: 0x1039e4714 | Name: __ZN6RakNet16ReliabilityLayer30BuildPacketFromSplitPacketListEPNS_18SplitPacketChannelEy
__int64 __fastcall RakNet::ReliabilityLayer::BuildPacketFromSplitPacketList(__int64 a1, __int64 a2, __int64 a3)
{
  _QWORD *v4; // rax
  unsigned int v5; // r14d
  unsigned __int64 v6; // rsi
  __int64 InternalPacketCopy; // r15
  __int64 v8; // rax
  __int64 v9; // rcx
  __int64 v10; // rdx
  int v11; // r14d
  __int64 v12; // rax
  __int64 v13; // rcx
  unsigned __int64 v14; // r12
  int v15; // r13d
  unsigned __int64 v16; // rdx
  unsigned __int64 v17; // r14
  __int64 v18; // rax
  __int64 v19; // rax
  void *v20; // rdi
  char *exception; // r13
  __int128 v23; // [rsp+0h] [rbp-50h] BYREF
  __int64 v24; // [rsp+10h] [rbp-40h]
  __int64 v25; // [rsp+20h] [rbp-30h]

  v25 = a1; /*0x1039e4728*/
  v4 = *(_QWORD **)(a2 + 8); /*0x1039e472c*/
  if ( *(_QWORD **)(a2 + 16) == v4 ) /*0x1039e4734*/
LABEL_21:
    std::vector<RakNet::InternalPacket *>::__throw_out_of_range[abi:ne200100](); /*0x1039e48df*/
  v5 = 0; /*0x1039e4740*/
  InternalPacketCopy = RakNet::ReliabilityLayer::CreateInternalPacketCopy(a1: v25, a2: *v4, a3: 0, a4: 0, a5: a3); /*0x1039e4750*/
  *(_DWORD *)(InternalPacketCopy + 24) = 0; /*0x1039e4753*/
  v8 = *(unsigned int *)(a2 + 32); /*0x1039e475a*/
  if ( *(_DWORD *)(a2 + 32) != 0 ) /*0x1039e4760*/
  {
    v9 = *(_QWORD *)(a2 + 8); /*0x1039e4762*/
    v10 = (*(_QWORD *)(a2 + 16) - v9) >> 3; /*0x1039e476d*/
    v11 = 0; /*0x1039e4771*/
    v6 = 0; /*0x1039e4774*/
    do /*0x1039e4791*/
    {
      if ( v10 == v6 ) /*0x1039e4779*/
        goto LABEL_21; /*0x1039e4779*/
      v11 += *(_DWORD *)(*(_QWORD *)(v9 + 8 * v6) + 24LL); /*0x1039e4783*/
      *(_DWORD *)(InternalPacketCopy + 24) = v11; /*0x1039e4787*/
      ++v6; /*0x1039e478b*/
    }
    while ( v8 != v6 ); /*0x1039e4791*/
    v5 = (unsigned int)(v11 + 7) >> 3; /*0x1039e4797*/
    if ( v5 > **(_DWORD **)(v25 + 456) ) /*0x1039e47a9*/
    {
      exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x1039e48f3*/
      RBX::format( /*0x1039e491a*/
        this: (RBX *)&v23,
        a2: "Reconstructed packet too large %u > %u",
        (unsigned int)(*(_DWORD *)(InternalPacketCopy + 24) + 7) >> 3,
        **(_DWORD **)(v25 + 456));
      *(_QWORD *)exception = off_10CAA98E0; /*0x1039e4926*/
      *((_QWORD *)exception + 3) = v24; /*0x1039e492e*/
      *(_OWORD *)(exception + 8) = v23; /*0x1039e4936*/
      v23 = 0; /*0x1039e493e*/
      v24 = 0; /*0x1039e4942*/
      __cxa_throw( /*0x1039e495b*/
        a1: exception,
        lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
        a3: RBX::network_stream_exception::~network_stream_exception);
    }
  }
  *(_QWORD *)(InternalPacketCopy + 64) = RBX::Memory::allocateOrCrash(this: (RBX::Memory *)v5, a2: v6); /*0x1039e47b7*/
  *(_DWORD *)(InternalPacketCopy + 72) = 0; /*0x1039e47bb*/
  if ( *(_DWORD *)(a2 + 32) != 0 ) /*0x1039e47c7*/
  {
    v12 = *(_QWORD *)(a2 + 8); /*0x1039e47cd*/
    v13 = *(_QWORD *)(a2 + 16); /*0x1039e47d1*/
    v14 = 0; /*0x1039e47d5*/
    v15 = 0; /*0x1039e47d8*/
    do /*0x1039e4838*/
    {
      if ( (v13 - v12) >> 3 <= v14 ) /*0x1039e47e5*/
        goto LABEL_20; /*0x1039e47e5*/
      memcpy( /*0x1039e4807*/
        __dst: (void *)(*(_QWORD *)(InternalPacketCopy + 64) + ((unsigned int)(v15 + 7) >> 3)),
        __src: *(const void **)(*(_QWORD *)(v12 + 8 * v14) + 64LL),
        __n: (unsigned int)(*(_DWORD *)(*(_QWORD *)(v12 + 8 * v14) + 24LL) + 7) >> 3);
      v12 = *(_QWORD *)(a2 + 8); /*0x1039e480c*/
      v13 = *(_QWORD *)(a2 + 16); /*0x1039e4810*/
      if ( (v13 - v12) >> 3 <= v14 ) /*0x1039e4821*/
        goto LABEL_20; /*0x1039e4821*/
      v15 += *(_DWORD *)(*(_QWORD *)(v12 + 8 * v14++) + 24LL); /*0x1039e482b*/
      v16 = *(unsigned int *)(a2 + 32); /*0x1039e4832*/
    }
    while ( v14 < v16 ); /*0x1039e4838*/
    if ( (_DWORD)v16 != 0 ) /*0x1039e483c*/
    {
      v17 = 0; /*0x1039e4849*/
      while ( 1 ) /*0x1039e4853*/
      {
        v18 = *(_QWORD *)(a2 + 8); /*0x1039e4853*/
        if ( (*(_QWORD *)(a2 + 16) - v18) >> 3 <= v17 ) /*0x1039e4865*/
          break; /*0x1039e4865*/
        RakNet::ReliabilityLayer::FreeInternalPacketData(a1: v25, a2: *(_QWORD *)(v18 + 8 * v17)); /*0x1039e4874*/
        v19 = *(_QWORD *)(a2 + 8); /*0x1039e4879*/
        if ( (*(_QWORD *)(a2 + 16) - v19) >> 3 <= v17 ) /*0x1039e488b*/
          break; /*0x1039e488b*/
        DataStructures::MemoryPool<RakNet::InternalPacket>::Release(a1: v25 + 144, a2: *(_QWORD **)(v19 + 8 * v17++)); /*0x1039e4899*/
        if ( v17 >= *(unsigned int *)(a2 + 32) ) /*0x1039e48a7*/
          goto LABEL_17; /*0x1039e48a7*/
      }
LABEL_20:
      std::vector<RakNet::InternalPacket *>::__throw_out_of_range[abi:ne200100](); /*0x1039e48d5*/
    }
  }
LABEL_17:
  v20 = *(void **)(a2 + 8); /*0x1039e48a9*/
  if ( v20 != nullptr ) /*0x1039e48b0*/
  {
    *(_QWORD *)(a2 + 16) = v20; /*0x1039e48b2*/
    operator delete(a1: v20); /*0x1039e48b6*/
  }
  operator delete(a1: (void *)a2); /*0x1039e48be*/
  return InternalPacketCopy; /*0x1039e48c6*/
}

// Address: 0x1039e4a76 | Name: __ZN6RakNet16ReliabilityLayer24CreateInternalPacketCopyEPNS_14InternalPacketEiiy
__int64 __fastcall RakNet::ReliabilityLayer::CreateInternalPacketCopy(
        __int64 a1,
        __int64 a2,
        int a3,
        int a4,
        __int64 a5)
{
  unsigned __int64 v8; // rsi
  __int64 v9; // r15
  void *v10; // rax

  v9 = DataStructures::MemoryPool<RakNet::InternalPacket>::Allocate( /*0x1039e4aa9*/
         a1: (__int64 *)(a1 + 144),
         a2: (unsigned __int64)"",
         a3: 0);
  *(_DWORD *)v9 = 0xFFFFFF; /*0x1039e4aac*/
  *(_BYTE *)(v9 + 36) = 0; /*0x1039e4ab2*/
  *(_QWORD *)(v9 + 48) = 0; /*0x1039e4ab6*/
  *(_DWORD *)(v9 + 20) = 0; /*0x1039e4aba*/
  *(_DWORD *)(v9 + 72) = 0; /*0x1039e4abe*/
  *(_QWORD *)(v9 + 64) = 0; /*0x1039e4ac2*/
  *(_WORD *)(v9 + 88) = 0; /*0x1039e4ac6*/
  *(_BYTE *)(v9 + 90) = 0; /*0x1039e4acc*/
  *(_QWORD *)(v9 + 264) = 0; /*0x1039e4ad0*/
  if ( a4 > 0 ) /*0x1039e4ada*/
  {
    v10 = (void *)RBX::Memory::allocateOrCrash(this: (RBX::Memory *)((unsigned int)(a4 + 7) >> 3), a2: v8); /*0x1039e4ae4*/
    *(_QWORD *)(v9 + 64) = v10; /*0x1039e4ae9*/
    memcpy(__dst: v10, __src: (const void *)(*(_QWORD *)(a2 + 64) + a3), __n: (unsigned int)a4); /*0x1039e4afa*/
  }
  *(_DWORD *)(v9 + 24) = 8 * a4; /*0x1039e4b03*/
  *(_QWORD *)(v9 + 40) = a5; /*0x1039e4b0b*/
  *(_QWORD *)(v9 + 48) = 0; /*0x1039e4b0f*/
  *(_DWORD *)(v9 + 4) = *(_DWORD *)(a2 + 4); /*0x1039e4b1a*/
  *(_DWORD *)(v9 + 8) = *(_DWORD *)(a2 + 8); /*0x1039e4b21*/
  *(_BYTE *)(v9 + 12) = *(_BYTE *)(a2 + 12); /*0x1039e4b28*/
  *(_DWORD *)v9 = *(_DWORD *)a2; /*0x1039e4b2e*/
  *(_DWORD *)(v9 + 92) = *(_DWORD *)(a2 + 92); /*0x1039e4b34*/
  *(_DWORD *)(v9 + 28) = *(_DWORD *)(a2 + 28); /*0x1039e4b3b*/
  return v9; /*0x1039e4b46*/
}

// Address: 0x1039e4b54 | Name: __ZN6RakNet16ReliabilityLayer17ResendListAddTailEPNS_14InternalPacketEb
__int64 __fastcall RakNet::ReliabilityLayer::ResendListAddTail(__int64 a1, __int64 a2, int a3)
{
  __int64 result; // rax
  __int64 v4; // rdi
  __int64 v5; // rcx

  if ( a3 != 0 ) /*0x1039e4b5a*/
    *(_DWORD *)(a1 + 3040) += (unsigned int)(*(_DWORD *)(a2 + 60) + *(_DWORD *)(a2 + 24) + 7) >> 3; /*0x1039e4b6a*/
  result = *(_QWORD *)(a1 + 200); /*0x1039e4b70*/
  v4 = a1 + 200; /*0x1039e4b77*/
  if ( DFFlag::GameLoadDataStatistics == 0 ) /*0x1039e4b85*/
  {
    if ( result != 0 ) /*0x1039e4bab*/
    {
      *(_QWORD *)(a2 + 112) = result; /*0x1039e4bad*/
      v5 = *(_QWORD *)(result + 104); /*0x1039e4bb1*/
      result += 104; /*0x1039e4bb5*/
      *(_QWORD *)(a2 + 104) = v5; /*0x1039e4bb9*/
      *(_QWORD *)(v5 + 112) = a2; /*0x1039e4bbd*/
      v4 = result; /*0x1039e4bc1*/
      goto LABEL_9; /*0x1039e4bc4*/
    }
LABEL_8:
    *(_QWORD *)(a2 + 112) = a2; /*0x1039e4bc6*/
    *(_QWORD *)(a2 + 104) = a2; /*0x1039e4bca*/
    goto LABEL_9; /*0x1039e4bca*/
  }
  if ( result == 0 ) /*0x1039e4b8a*/
    goto LABEL_8; /*0x1039e4b8a*/
  *(_QWORD *)(a2 + 112) = result; /*0x1039e4b8c*/
  result = *(_QWORD *)(*(_QWORD *)v4 + 104LL); /*0x1039e4b93*/
  *(_QWORD *)(a2 + 104) = result; /*0x1039e4b97*/
  *(_QWORD *)(result + 112) = a2; /*0x1039e4b9b*/
  v4 = *(_QWORD *)v4 + 104LL; /*0x1039e4ba2*/
LABEL_9:
  *(_QWORD *)v4 = a2; /*0x1039e4bce*/
  return result; /*0x1039e4bd1*/
}

// Address: 0x1039e4bd4 | Name: __ZNK6RakNet16ReliabilityLayer16IsDeadConnectionEv
char __fastcall RakNet::ReliabilityLayer::IsDeadConnection(RakNet::ReliabilityLayer *this)
{
  return *((_BYTE *)this + 436); /*0x1039e4bde*/
}

// Address: 0x1039e4be0 | Name: __ZN6RakNet16ReliabilityLayer13GetStatisticsEPNS_16RakNetStatisticsE
RakNet::RakNetStatistics *__fastcall RakNet::ReliabilityLayer::GetStatistics(
        RakNet::ReliabilityLayer *this,
        RakNet::RakNetStatistics *a2)
{
  std::mutex *v3; // r12
  __int64 i; // r13
  __int64 v5; // r14
  __int64 v6; // rbx
  __int128 v7; // xmm0
  __m128i v8; // xmm1
  __int128 v9; // xmm2
  char *v10; // r12
  char *v11; // r15
  __int64 j; // r13
  float v13; // xmm0_4
  __m128i v14; // xmm0
  __m128d v15; // xmm1
  __m128i v16; // xmm0
  __m128d v17; // xmm0
  double v18; // xmm1_8
  float v19; // xmm0_4
  char *__src; // [rsp+10h] [rbp-30h]

  __src = (char *)this + 656; /*0x1039e4bff*/
  v3 = (RakNet::ReliabilityLayer *)((char *)this + 3248); /*0x1039e4c03*/
  for ( i = 90; i != 98; ++i ) /*0x1039e4c0a*/
  {
    std::mutex::lock(this: v3); /*0x1039e4c13*/
    v5 = *((_QWORD *)v3 - 2); /*0x1039e4c18*/
    v6 = *((_QWORD *)v3 - 1); /*0x1039e4c1d*/
    std::mutex::unlock(this: v3); /*0x1039e4c25*/
    *((_QWORD *)this + i - 8) = v6; /*0x1039e4c2a*/
    *((_QWORD *)this + i) = v5; /*0x1039e4c2f*/
    v3 = (std::mutex *)((char *)v3 + 104); /*0x1039e4c33*/
  }
  v7 = *((_OWORD *)this + 29); /*0x1039e4c40*/
  v8 = _mm_loadu_si128((const __m128i *)this + 30); /*0x1039e4c48*/
  v9 = *((_OWORD *)this + 31); /*0x1039e4c51*/
  *(_OWORD *)((char *)a2 + 45) = *(_OWORD *)((char *)this + 509); /*0x1039e4c66*/
  *((_OWORD *)a2 + 2) = v9; /*0x1039e4c6a*/
  *((__m128i *)a2 + 1) = v8; /*0x1039e4c6f*/
  *(_OWORD *)a2 = v7; /*0x1039e4c74*/
  v10 = (char *)a2 + 64; /*0x1039e4c77*/
  v11 = (char *)this + 528; /*0x1039e4c7b*/
  for ( j = 4; j != 0; --j ) /*0x1039e4c82*/
  {
    RBX::SmallVectorImpl<unsigned short>::operator=(a1: v10, a2: v11); /*0x1039e4c8e*/
    v11 += 32; /*0x1039e4c93*/
    v10 += 32; /*0x1039e4c97*/
  }
  memcpy(__dst: (char *)a2 + 192, __src, __n: 0x1A0u); /*0x1039e4cb0*/
  v13 = 0.0; /*0x1039e4cbc*/
  if ( *((_QWORD *)a2 + 26) + *((_QWORD *)a2 + 25) != 0 ) /*0x1039e4cc6*/
  {
    v14 = _mm_loadu_si128((const __m128i *)((char *)a2 + 200)); /*0x1039e4cc8*/
    v15 = _mm_add_pd( /*0x1039e4cfb*/
            _mm_sub_pd(
              (__m128d)_mm_or_si128(_mm_srli_epi64(v14, 0x20u), (__m128i)xmmword_109A07E80),
              (__m128d)xmmword_109A07E90),
            (__m128d)_mm_or_si128(_mm_blend_epi16((__m128i)0LL, v14, 51), (__m128i)xmmword_108F49AE0));
    v13 = _mm_unpackhi_pd(v15, v15).f64[0] / _mm_hadd_pd(v15, v15).f64[0]; /*0x1039e4d0e*/
  }
  *((float *)a2 + 106) = v13; /*0x1039e4d12*/
  *((_DWORD *)a2 + 107) = 0; /*0x1039e4d1a*/
  if ( *((_QWORD *)a2 + 33) > -*((_QWORD *)a2 + 34) ) /*0x1039e4d34*/
  {
    v16 = _mm_loadu_si128((const __m128i *)((char *)a2 + 264)); /*0x1039e4d36*/
    v17 = _mm_add_pd( /*0x1039e4d65*/
            _mm_sub_pd(
              (__m128d)_mm_or_si128(_mm_srli_epi64(v16, 0x20u), (__m128i)xmmword_109A07E80),
              (__m128d)xmmword_109A07E90),
            (__m128d)_mm_or_si128(_mm_blend_epi16((__m128i)0LL, v16, 51), (__m128i)xmmword_108F49AE0));
    v18 = _mm_hadd_pd(v17, v17).f64[0]; /*0x1039e4d6d*/
    if ( v18 != 0.0 ) /*0x1039e4d79*/
    {
      v19 = _mm_unpackhi_pd(v17, v17).f64[0] / v18; /*0x1039e4d85*/
      *((float *)a2 + 107) = v19; /*0x1039e4d89*/
    }
  }
  return a2; /*0x1039e4d94*/
}

// Address: 0x1039e4da4 | Name: __ZNK6RakNet16ReliabilityLayer27GetBandwidthManagerFeedbackERNS_28BandwidthManagerFeedbackDataE
__int8 __fastcall RakNet::ReliabilityLayer::GetBandwidthManagerFeedback(__int64 a1, __m128i *a2)
{
  __int8 result; // al
  __m128i v4[3]; // [rsp+0h] [rbp-30h] BYREF

  memset(v4, 0, 25); /*0x1039e4dbe*/
  (*(void (__fastcall **)(_QWORD, __m128i *))(**(_QWORD **)(a1 + 3032) + 240LL))(a1: *(_QWORD *)(a1 + 3032), a2: v4); /*0x1039e4dcf*/
  *a2 = _mm_max_epi32(_mm_load_si128(v4), (__m128i)0LL); /*0x1039e4de3*/
  a2[1].i64[0] = _mm_max_epi32(_mm_loadl_epi64(&v4[1]), (__m128i)0LL).u64[0]; /*0x1039e4df2*/
  result = v4[1].i8[8]; /*0x1039e4df7*/
  a2[1].i8[8] = v4[1].i8[8]; /*0x1039e4dfb*/
  return result; /*0x1039e4dfe*/
}

// Address: 0x1039e4e08 | Name: __ZN6RakNet16ReliabilityLayer42getAvaliableNetworkCapacityInBytesInNextMsEf
__int64 __fastcall RakNet::ReliabilityLayer::getAvaliableNetworkCapacityInBytesInNextMs(
        RakNet::ReliabilityLayer *this,
        double a2)
{
  __int64 v3; // rdi
  double v4; // xmm1_8
  __m128i v5; // xmm1
  __m128d v6; // xmm2

  v3 = *((_QWORD *)this + 379); /*0x1039e4e0f*/
  if ( v3 == 0 ) /*0x1039e4e19*/
    return 0; /*0x1039e4e90*/
  v4 = 0.0; /*0x1039e4e22*/
  if ( *((_QWORD *)this + 84) + *((_QWORD *)this + 83) != 0 ) /*0x1039e4e2c*/
  {
    v5 = _mm_loadu_si128((const __m128i *)((char *)this + 664)); /*0x1039e4e2e*/
    v6 = _mm_add_pd( /*0x1039e4e61*/
           _mm_sub_pd(
             (__m128d)_mm_or_si128(_mm_srli_epi64(v5, 0x20u), (__m128i)xmmword_109A07E80),
             (__m128d)xmmword_109A07E90),
           (__m128d)_mm_or_si128(_mm_blend_epi16((__m128i)0LL, v5, 51), (__m128i)xmmword_108F49AE0));
    HIDWORD(v4) = 0; /*0x1039e4e71*/
    *(float *)&v4 = _mm_unpackhi_pd(v6, v6).f64[0] / _mm_hadd_pd(v6, v6).f64[0]; /*0x1039e4e74*/
  }
  return (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD, double, double))(*(_QWORD *)v3 + 16LL))( /*0x1039e4e92*/
           a1: v3,
           a2: *((_QWORD *)this + 110),
           a3: *((_QWORD *)this + 82),
           a4: a2,
           a5: v4);
}

// Address: 0x1039e4e94 | Name: __ZNK6RakNet16ReliabilityLayer21GetResendListDataSizeEv
__int64 __fastcall RakNet::ReliabilityLayer::GetResendListDataSize(RakNet::ReliabilityLayer *this)
{
  return *((unsigned int *)this + 218); /*0x1039e4e9e*/
}

// Address: 0x1039e4ea0 | Name: __ZNK6RakNet16ReliabilityLayer15GetNextSendTimeEv
__int64 __fastcall RakNet::ReliabilityLayer::GetNextSendTime(RakNet::ReliabilityLayer *this)
{
  return *((_QWORD *)this + 362); /*0x1039e4eab*/
}

// Address: 0x1039e4eae | Name: __ZNK6RakNet16ReliabilityLayer21GetTimeBetweenPacketsEv
__int64 __fastcall RakNet::ReliabilityLayer::GetTimeBetweenPackets(RakNet::ReliabilityLayer *this)
{
  return *((_QWORD *)this + 361); /*0x1039e4eb9*/
}

// Address: 0x1039e4ebc | Name: __ZNK6RakNet16ReliabilityLayer10GetAckPingEv
__int64 __fastcall RakNet::ReliabilityLayer::GetAckPing(RakNet::ReliabilityLayer *this)
{
  return *((_QWORD *)this + 363); /*0x1039e4ec7*/
}

// Address: 0x1039e4eca | Name: __ZNK6RakNet16ReliabilityLayer19GetAverageAckPingMsEv
__int64 __fastcall RakNet::ReliabilityLayer::GetAverageAckPingMs(RakNet::ReliabilityLayer *this, __m128i a2)
{
  __int64 v2; // rax
  __int64 v3; // rcx
  __int64 v4; // rdx

  v2 = 0; /*0x1039e4ece*/
  v3 = 0; /*0x1039e4ed0*/
  while ( 1 ) /*0x1039e4ed2*/
  {
    v4 = *((_QWORD *)this + v2 + 364); /*0x1039e4ed2*/
    if ( v4 == 0 ) /*0x1039e4edd*/
      break; /*0x1039e4edd*/
    v3 += v4; /*0x1039e4edf*/
    if ( ++v2 == 5 ) /*0x1039e4ee9*/
    {
      LODWORD(v2) = 5; /*0x1039e4eeb*/
      goto LABEL_6; /*0x1039e4ef0*/
    }
  }
  if ( v2 == 0 ) /*0x1039e4ef5*/
    return 0; /*0x1039e4f31*/
LABEL_6:
  if ( v3 < 0 ) /*0x1039e4efa*/
    *(float *)a2.i32 = (float)(int)(((unsigned __int64)v3 >> 1) | v3 & 1) /*0x1039e4f14*/
                     + (float)(int)(((unsigned __int64)v3 >> 1) | v3 & 1);
  else
    *(float *)a2.i32 = (float)(int)v3; /*0x1039e4efc*/
  *(float *)a2.i32 = *(float *)a2.i32 / (float)(1000 * v2); /*0x1039e4f22*/
  return (unsigned int)_mm_cvtsi128_si32(a2) | 0x100000000LL; /*0x1039e4f2f*/
}

// Address: 0x1039e4f36 | Name: __ZNK6RakNet16ReliabilityLayer18GetAckPingJitterMsEv
__int64 __fastcall RakNet::ReliabilityLayer::GetAckPingJitterMs(RakNet::ReliabilityLayer *this, __m128i a2)
{
  unsigned __int64 v2; // rcx
  unsigned __int64 v3; // rdx
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // rsi
  __int64 v6; // rax

  v2 = -1; /*0x1039e4f36*/
  v3 = 0; /*0x1039e4f3d*/
  v4 = 0; /*0x1039e4f3f*/
  while ( 1 ) /*0x1039e4f41*/
  {
    v5 = *((_QWORD *)this + v3 + 364); /*0x1039e4f41*/
    if ( v5 == 0 ) /*0x1039e4f4c*/
      break; /*0x1039e4f4c*/
    if ( v4 <= v5 ) /*0x1039e4f51*/
      v4 = *((_QWORD *)this + v3 + 364); /*0x1039e4f51*/
    if ( v5 < v2 ) /*0x1039e4f58*/
      v2 = *((_QWORD *)this + v3 + 364); /*0x1039e4f58*/
    if ( ++v3 == 5 ) /*0x1039e4f63*/
      goto LABEL_10; /*0x1039e4f63*/
  }
  if ( v3 < 2 ) /*0x1039e4f6b*/
    return 0; /*0x1039e4fa5*/
LABEL_10:
  v6 = v4 - v2; /*0x1039e4f6d*/
  if ( v6 < 0 ) /*0x1039e4f70*/
    *(float *)a2.i32 = (float)(int)(((unsigned __int64)v6 >> 1) | v6 & 1) /*0x1039e4f8a*/
                     + (float)(int)(((unsigned __int64)v6 >> 1) | v6 & 1);
  else
    *(float *)a2.i32 = (float)(int)v6; /*0x1039e4f72*/
  *(float *)a2.i32 = *(float *)a2.i32 / 1000.0; /*0x1039e4f92*/
  return (unsigned int)_mm_cvtsi128_si32(a2) | 0x100000000LL; /*0x1039e4fa4*/
}

// Address: 0x1039e4fa8 | Name: __ZN6RakNet16ReliabilityLayer20ResendListMoveToHeadEPNS_14InternalPacketE
void __fastcall RakNet::ReliabilityLayer::ResendListMoveToHead(__int64 a1, __int64 a2)
{
  __int64 v2; // rcx
  __int64 *v3; // rax
  __int64 *v4; // rdx
  __int64 v5; // r8
  __int64 v6; // r9
  __int64 v7; // rax

  v2 = *(_QWORD *)(a1 + 200); /*0x1039e4fa8*/
  if ( v2 != a2 ) /*0x1039e4fb2*/
  {
    v3 = (__int64 *)(a2 + 112); /*0x1039e4fb8*/
    v4 = (__int64 *)(a2 + 104); /*0x1039e4fbc*/
    if ( v2 != 0 ) /*0x1039e4fc3*/
    {
      v5 = *v3; /*0x1039e4fc5*/
      v6 = *v4; /*0x1039e4fc8*/
      *(_QWORD *)(v6 + 112) = *v3; /*0x1039e4fcb*/
      *(_QWORD *)(v5 + 104) = v6; /*0x1039e4fcf*/
      *v3 = v2; /*0x1039e4fd3*/
      v7 = *(_QWORD *)(v2 + 104); /*0x1039e4fd6*/
      *v4 = v7; /*0x1039e4fde*/
      v3 = (__int64 *)(v7 + 112); /*0x1039e4fe1*/
      v4 = (__int64 *)(v2 + 104); /*0x1039e4fe5*/
    }
    *v3 = a2; /*0x1039e4fe8*/
    *v4 = a2; /*0x1039e4feb*/
    *(_QWORD *)(a1 + 200) = a2; /*0x1039e4fee*/
  }
}

// Address: 0x1039e4ff8 | Name: __ZN6RakNet16ReliabilityLayer28SerializeSomeAcknowlegementsEPNS_9BitStreamEPj
bool __fastcall RakNet::ReliabilityLayer::SerializeSomeAcknowlegements(
        RakNet::ReliabilityLayer *this,
        RakNet::BitStream *a2,
        unsigned int *a3)
{
  unsigned int v5; // edx
  int v6; // ebx
  unsigned int v7; // r13d
  unsigned int v8; // r15d
  _QWORD v10[2]; // [rsp+10h] [rbp-70h] BYREF
  __int64 v11; // [rsp+20h] [rbp-60h]
  __int64 v12; // [rsp+30h] [rbp-50h]
  _QWORD *v13; // [rsp+38h] [rbp-48h]
  __int64 *v14; // [rsp+40h] [rbp-40h]
  RakNet::ReliabilityLayer *v15; // [rsp+48h] [rbp-38h]
  unsigned int v16; // [rsp+54h] [rbp-2Ch]

  v14 = (__int64 *)((char *)this + 3160); /*0x1039e5016*/
  v15 = this; /*0x1039e501a*/
  v16 = *((_DWORD *)this + 792); /*0x1039e5024*/
  v5 = *a3; /*0x1039e5027*/
  v6 = 23; /*0x1039e5029*/
  while ( 1 ) /*0x1039e502e*/
  {
    v7 = *((_DWORD *)a2 + 3); /*0x1039e502e*/
    DataStructures::RangeList<RakNet::uint24_t>::Serialize(a1: v14, a2, a3: v5, a4: 1u); /*0x1039e503f*/
    v8 = *((_DWORD *)v15 + 792); /*0x1039e5048*/
    if ( v8 < v16 ) /*0x1039e5053*/
      break; /*0x1039e5053*/
    RakNet::BitStream::SetWriteOffset(this: a2, a2: v7, a3: true); /*0x1039e5064*/
    if ( (unsigned __int8)DFLog::ReliabilityLayerLog >= 6u && BYTE1(DFLog::ReliabilityLayerLog) >= 3u ) /*0x1039e507e*/
    {
      v10[0] = *a3 >> 3; /*0x1039e5092*/
      v11 = 64; /*0x1039e5096*/
      v12 = 34; /*0x1039e509e*/
      v13 = v10; /*0x1039e50aa*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x1039e50ce*/
        a1: DFLog::ReliabilityLayerLog,
        a2: qword_10D7BBAB8,
        a3: 3,
        a4: (unsigned int)"[DFLog::ReliabilityLayerLog] An attempt to serialize RakNet ACKs failed. Increasing maxDatagramPayload ({}) by {}",
        a5: 113,
        a6: 1,
        34,
        v10,
        v10[0]);
    }
    v5 = *a3 + 512; /*0x1039e50db*/
    *a3 = v5; /*0x1039e50dd*/
    if ( --v6 == 0 ) /*0x1039e50e2*/
    {
      v8 = *((_DWORD *)v15 + 792); /*0x1039e50ec*/
      break; /*0x1039e50ec*/
    }
  }
  if ( v8 == v16 ) /*0x1039e50f7*/
  {
    if ( (unsigned __int8)DFLog::ReliabilityLayerLog >= 6u && BYTE1(DFLog::ReliabilityLayerLog) >= 3u ) /*0x1039e510e*/
    {
      v11 = *a3 >> 3; /*0x1039e512a*/
      v12 = 34; /*0x1039e512e*/
      v13 = v10; /*0x1039e513a*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x1039e515e*/
        a1: DFLog::ReliabilityLayerLog,
        a2: qword_10D7BBAB8,
        a3: 3,
        a4: (unsigned int)"[DFLog::ReliabilityLayerLog] {} attempts to serialize RakNet ACKs failed. maxDatagramPayload {}. D"
                      "ropping these ACKs",
        a5: 116,
        a6: 1,
        34,
        v10,
        23);
    }
    DataStructures::RangeList<RakNet::uint24_t>::Clear(a1: v14); /*0x1039e5167*/
  }
  return v8 != v16; /*0x1039e5173*/
}

// Address: 0x1039e5350 | Name: __ZNK6RakNet16ReliabilityLayer18ResendListValidateEv
void __fastcall RakNet::ReliabilityLayer::ResendListValidate(RakNet::ReliabilityLayer *this)
{
  ; /*0x1039e5350*/
}

// Address: 0x1039e56aa | Name: __ZN6RakNet16ReliabilityLayer22DropOldDatagramHistoryEv
__int64 __fastcall RakNet::ReliabilityLayer::DropOldDatagramHistory(RakNet::ReliabilityLayer *this)
{
  __int64 result; // rax
  unsigned int v3; // edx
  bool v4; // cf
  int v5; // edx
  unsigned int v6; // edx
  int v7; // ecx
  _DWORD v8[5]; // [rsp+Ch] [rbp-14h] BYREF

  result = *((unsigned int *)this + 16); /*0x1039e56b8*/
  v3 = *((_DWORD *)this + 17); /*0x1039e56be*/
  v4 = v3 < (unsigned int)result; /*0x1039e56c0*/
  v5 = v3 - result; /*0x1039e56c0*/
  if ( v4 ) /*0x1039e56c2*/
    v5 = *((_DWORD *)this + 18) + *((_DWORD *)this + 17) - result; /*0x1039e56c9*/
  if ( v5 >= FInt::RakNetDatagramMessageIdArrayLength ) /*0x1039e56d3*/
  {
    v6 = *((_DWORD *)this + 18); /*0x1039e56d5*/
    if ( (unsigned int)result < v6 ) /*0x1039e56e1*/
      v6 = 0; /*0x1039e56e1*/
    result = 3LL * ((unsigned int)result - v6); /*0x1039e56e7*/
    if ( *(_QWORD *)(*((_QWORD *)this + 7) + 8 * result) == 0 /*0x1039e56f5*/
      || *((_DWORD *)this + 28) >= FInt::RakNetDatagramMessageIdArrayLength )
    {
      v8[0] = *((_DWORD *)this + 34); /*0x1039e5701*/
      RakNet::ReliabilityLayer::RemoveFromDatagramHistory(a1: (__int64)this, a2: v8); /*0x1039e5706*/
      v7 = *((_DWORD *)this + 34); /*0x1039e570e*/
      result = (unsigned int)(*((_DWORD *)this + 16) + 1); /*0x1039e5714*/
      if ( (_DWORD)result == *((_DWORD *)this + 18) ) /*0x1039e5719*/
        result = 0; /*0x1039e5719*/
      *((_DWORD *)this + 16) = result; /*0x1039e571d*/
      *((_DWORD *)this + 34) = (v7 + 1) & 0xFFFFFF; /*0x1039e5728*/
    }
  }
  return result; /*0x1039e572e*/
}

// Address: 0x1039e5904 | Name: __ZNK6RakNet16ReliabilityLayer25GetOldestSentPacketTimeMsEv
unsigned __int64 __fastcall RakNet::ReliabilityLayer::GetOldestSentPacketTimeMs(RakNet::ReliabilityLayer *this)
{
  unsigned int v1; // eax
  __int64 v2; // rcx
  unsigned __int64 v3; // rsi
  unsigned int v4; // edx
  __int64 v5; // rax

  v1 = *((_DWORD *)this + 106); /*0x1039e5908*/
  v2 = *((_QWORD *)this + 22); /*0x1039e590e*/
  v3 = (unsigned __int64)(*((_QWORD *)this + 23) - v2) >> 3; /*0x1039e591f*/
  if ( (((_DWORD)v3 - 1) & (unsigned int)v3) != 0 ) /*0x1039e5928*/
    v4 = v1 % (unsigned int)v3; /*0x1039e5930*/
  else
    v4 = v1 & (v3 - 1); /*0x1039e592a*/
  v5 = *(_QWORD *)(v2 + 8LL * v4); /*0x1039e5934*/
  if ( v5 != 0 ) /*0x1039e593b*/
    return *(_QWORD *)(v5 + 40) / 0x3E8uLL; /*0x1039e5955*/
  else
    return 0xFFFFFFFFLL; /*0x1039e595b*/
}

// END ReliabilityLayer part 1/1, 105 functions
