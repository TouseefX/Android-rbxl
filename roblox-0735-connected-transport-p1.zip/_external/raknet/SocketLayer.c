// SocketLayer -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 18 functions


// Address: 0x1039e7e90 | Name: __ZN6RakNet11SocketLayer20PrepareAddrInfoHintsER8addrinfot
__int64 __fastcall RakNet::SocketLayer::PrepareAddrInfoHints(RakNet::SocketLayer *this, addrinfo *a2)
{
  __int64 result; // rax

  *(_OWORD *)this = 0; /*0x1039e7e97*/
  *((_OWORD *)this + 2) = 0; /*0x1039e7e9a*/
  *((_OWORD *)this + 1) = 0; /*0x1039e7e9e*/
  *((_DWORD *)this + 2) = 2; /*0x1039e7ea2*/
  *(_DWORD *)this = 1536; /*0x1039e7ea9*/
  if ( (_DWORD)a2 != 0 ) /*0x1039e7eb1*/
  {
    *((_DWORD *)this + 1) = (unsigned __int16)a2; /*0x1039e7eb6*/
    return (unsigned __int16)a2; /*0x1039e7eb3*/
  }
  return result; /*0x1039e7eb9*/
}

// Address: 0x1039e7ebc | Name: __ZN6RakNet11SocketLayer19GetAddrInfoAllocateEt
addrinfo *__fastcall RakNet::SocketLayer::GetAddrInfoAllocate(RakNet::SocketLayer *this)
{
  int v1; // eax
  int v2; // r8d
  int v3; // r9d
  addrinfo v5; // [rsp+0h] [rbp-40h] BYREF
  addrinfo *v6; // [rsp+38h] [rbp-8h] BYREF

  v6 = nullptr; /*0x1039e7ec4*/
  memset(&v5, 0, sizeof(v5)); /*0x1039e7ecf*/
  v5.ai_socktype = 2; /*0x1039e7edb*/
  if ( (_DWORD)this != 0 ) /*0x1039e7ee4*/
    v5.ai_family = (unsigned __int16)this; /*0x1039e7ee9*/
  v5.ai_flags = 3328; /*0x1039e7ef0*/
  v1 = getaddrinfo(a1: nullptr, a2: "0", a3: &v5, a4: &v6); /*0x1039e7f03*/
  if ( v1 != 0 && (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1039e7f26*/
    FLog::FastLogFormatted( /*0x1039e7f3d*/
      a1: FLog::Network,
      a2: qword_10D7BBAA8,
      a3: (unsigned int)"[FLog::Network] getaddrinfo(...) failed:Error code - %d\n",
      a4: v1,
      a5: v2,
      a6: v3);
  return v6; /*0x1039e7f46*/
}

// Address: 0x1039e7f4c | Name: __ZN6RakNet11SocketLayer16SetDoNotFragmentEiii
void __fastcall RakNet::SocketLayer::SetDoNotFragment(RakNet::SocketLayer *this)
{
  ; /*0x1039e7f4c*/
}

// Address: 0x1039e7f52 | Name: __ZN6RakNet11SocketLayer20SetSocketSendTimeoutEiNSt3__16chrono8durationIxNS1_5ratioILl1ELl1000EEEEE
bool __fastcall RakNet::SocketLayer::SetSocketSendTimeout(int a1, __int64 a2)
{
  _QWORD v3[2]; // [rsp+0h] [rbp-10h] BYREF

  v3[0] = (int)(a2 / 1000 - (1000 * (a2 / 1000) > a2)); /*0x1039e7f9f*/
  LODWORD(v3[1]) = 1000 * a2 - 1000000 * (a2 / 1000 - (1000 * (a2 / 1000) > a2)); /*0x1039e7fa2*/
  return setsockopt(a1, a2: 0xFFFF, a3: 4101, a4: v3, a5: 0x10u) == 0; /*0x1039e7fbf*/
}

// Address: 0x1039e7fc6 | Name: __ZN6RakNet11SocketLayer17DurationToTimevalENSt3__16chrono8durationIxNS1_5ratioILl1ELl1000EEEEE
__int64 __fastcall RakNet::SocketLayer::DurationToTimeval(__int64 a1)
{
  return (int)(a1 / 1000 - (1000 * (a1 / 1000) > a1)); /*0x1039e800b*/
}

// Address: 0x1039e800e | Name: __ZN6RakNet11SocketLayer20SetSocketRecvTimeoutEiNSt3__16chrono8durationIxNS1_5ratioILl1ELl1000EEEEE
bool __fastcall RakNet::SocketLayer::SetSocketRecvTimeout(int a1, __int64 a2)
{
  _QWORD v3[2]; // [rsp+0h] [rbp-10h] BYREF

  v3[0] = (int)(a2 / 1000 - (1000 * (a2 / 1000) > a2)); /*0x1039e805b*/
  LODWORD(v3[1]) = 1000 * a2 - 1000000 * (a2 / 1000 - (1000 * (a2 / 1000) > a2)); /*0x1039e805e*/
  return setsockopt(a1, a2: 0xFFFF, a3: 4102, a4: v3, a5: 0x10u) == 0; /*0x1039e807b*/
}

// Address: 0x1039e8082 | Name: __ZN6RakNet11SocketLayer18GetLastSystemErrorEv
__int64 __fastcall RakNet::SocketLayer::GetLastSystemError(RakNet::SocketLayer *this)
{
  unsigned int v1; // ebx

  v1 = *__error(); /*0x1039e808d*/
  std::system_category(); /*0x1039e808f*/
  return v1; /*0x1039e809d*/
}

// Address: 0x1039e80a0 | Name: __ZN6RakNet11SocketLayer16SetSocketOptionsEitb
__int64 __fastcall RakNet::SocketLayer::SetSocketOptions(RakNet::SocketLayer *this, int a2, unsigned __int8 a3)
{
  int v5; // ebx
  int v6; // eax
  unsigned int v7; // r12d
  int v8; // r13d
  int v9; // r9d
  _BYTE *v10; // r8
  unsigned int v11; // r12d
  int v12; // r13d
  int v13; // r9d
  _BYTE *v14; // r8
  unsigned int v15; // r12d
  int v16; // r13d
  int v17; // r9d
  _BYTE *v18; // r8
  unsigned int v19; // esi
  int v20; // r14d
  int v21; // r15d
  unsigned int v22; // ebx
  int v23; // r14d
  int v24; // r15d
  int v25; // r9d
  _BYTE *v26; // r8
  __int64 v28; // [rsp+18h] [rbp-68h] BYREF
  int v29; // [rsp+24h] [rbp-5Ch] BYREF
  int v30; // [rsp+28h] [rbp-58h] BYREF
  int v31; // [rsp+2Ch] [rbp-54h] BYREF
  __int64 v32; // [rsp+30h] [rbp-50h]
  unsigned __int8 v33; // [rsp+38h] [rbp-48h] BYREF
  _BYTE v34[15]; // [rsp+39h] [rbp-47h] BYREF
  void *v35; // [rsp+48h] [rbp-38h]
  int v36; // [rsp+50h] [rbp-30h]
  unsigned int v37[11]; // [rsp+54h] [rbp-2Ch] BYREF

  v5 = (int)this; /*0x1039e80b7*/
  v6 = fcntl(a1: (int)this, a2: 1); /*0x1039e80c0*/
  fcntl(a1: v5, a2: 2, v6 | 1u); /*0x1039e80d3*/
  v37[0] = 0; /*0x1039e80d8*/
  v31 = DFInt::RaknetSocketRxBufferSize; /*0x1039e80e9*/
  if ( setsockopt(a1: v5, a2: 0xFFFF, a3: 4098, a4: &v31, a5: 4u) == -1 )
  {
    v7 = *__error(); /*0x1039e8110*/
    v37[0] = v7; /*0x1039e8113*/
    v8 = FLog::Network; /*0x1039e811e*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
    {
      v36 = a2; /*0x1039e8138*/
      v32 = qword_10D7BBAA8; /*0x1039e8140*/
      RBX::systemErrorToString(this: (RBX *)&v33, a2: v7); /*0x1039e814e*/
      if ( (v33 & 1) != 0 ) /*0x1039e8157*/
        LODWORD(v10) = (_DWORD)v35; /*0x1039e8159*/
      else
        v10 = v34; /*0x1039e815f*/
      FLog::FastLogFormatted(
        a1: v8,
        a2: v32,
        a3: (unsigned int)"[FLog::Network] setsockopt SO_RCVBUF failed : errno=%d, errString=%s",
        a4: v7,
        a5: (_DWORD)v10,
        a6: v9);
      a2 = v36; /*0x1039e817b*/
      if ( (v33 & 1) != 0 ) /*0x1039e8183*/
        operator delete(a1: v35); /*0x1039e8189*/
    }
  }
  v28 = 0; /*0x1039e8192*/
  if ( setsockopt(a1: v5, a2: 0xFFFF, a3: 128, a4: &v28, a5: 8u) == -1 )
  {
    v11 = *__error(); /*0x1039e81be*/
    v37[0] = v11; /*0x1039e81c1*/
    v12 = FLog::Network; /*0x1039e81cc*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
    {
      v36 = a2; /*0x1039e81e6*/
      v32 = qword_10D7BBAA8; /*0x1039e81ee*/
      RBX::systemErrorToString(this: (RBX *)&v33, a2: v11); /*0x1039e81fc*/
      if ( (v33 & 1) != 0 ) /*0x1039e8205*/
        LODWORD(v14) = (_DWORD)v35; /*0x1039e8207*/
      else
        v14 = v34; /*0x1039e820d*/
      FLog::FastLogFormatted(
        a1: v12,
        a2: v32,
        a3: (unsigned int)"[FLog::Network] setsockopt SO_LINGER failed : errno=%d, errString=%s",
        a4: v11,
        a5: (_DWORD)v14,
        a6: v13);
      a2 = v36; /*0x1039e8229*/
      if ( (v33 & 1) != 0 ) /*0x1039e8231*/
        operator delete(a1: v35); /*0x1039e8237*/
    }
  }
  v29 = 1; /*0x1039e8240*/
  setsockopt(a1: v5, a2: 0xFFFF, a3: 512, a4: &v29, a5: 4u); /*0x1039e8258*/
  v31 = DFInt::RaknetSocketTxBufferSize; /*0x1039e8267*/
  if ( setsockopt(a1: v5, a2: 0xFFFF, a3: 4097, a4: &v31, a5: 4u) == -1 )
  {
    v15 = *__error(); /*0x1039e828e*/
    v37[0] = v15; /*0x1039e8291*/
    v16 = FLog::Network; /*0x1039e829c*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
    {
      v36 = a2; /*0x1039e82b6*/
      v32 = qword_10D7BBAA8; /*0x1039e82be*/
      RBX::systemErrorToString(this: (RBX *)&v33, a2: v15); /*0x1039e82cc*/
      if ( (v33 & 1) != 0 ) /*0x1039e82d5*/
        LODWORD(v18) = (_DWORD)v35; /*0x1039e82d7*/
      else
        v18 = v34; /*0x1039e82dd*/
      FLog::FastLogFormatted(
        a1: v16,
        a2: v32,
        a3: (unsigned int)"[FLog::Network] setsockopt SO_SNDBUF failed : errno=%d, errString=%s",
        a4: v15,
        a5: (_DWORD)v18,
        a6: v17);
      LOWORD(a2) = v36; /*0x1039e82f9*/
      if ( (v33 & 1) != 0 ) /*0x1039e8301*/
        operator delete(a1: v35); /*0x1039e8307*/
    }
  }
  if ( (_WORD)a2 == 30 )
  {
    v30 = a3 ^ 1; /*0x1039e8323*/
    if ( setsockopt(a1: v5, a2: 41, a3: 27, a4: &v30, a5: 4u) == -1 )
    {
      v19 = *__error(); /*0x1039e8346*/
      v37[0] = v19; /*0x1039e8348*/
      v20 = FLog::Network; /*0x1039e8352*/
      if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
      {
        v21 = qword_10D7BBAA8; /*0x1039e836c*/
        RBX::systemErrorToString(this: (RBX *)&v33, a2: v19); /*0x1039e8377*/
        FLog::DEPRECATED_FastLogSafeFormatted<int &,int &,std::string>(
          a1: v20,
          a2: v21,
          a3: 3,
          a4: (int)"[FLog::Network] setsockopt IPV6_V6ONLY to {} failed : errno={}, errString={}",
          a5: 76,
          a6: (unsigned int *)&v30,
          a7: v37,
          a8: &v33);
        if ( (v33 & 1) != 0 ) /*0x1039e83ae*/
          operator delete(a1: v35); /*0x1039e83b4*/
      }
    }
  }
  v31 = 1; /*0x1039e83bd*/
  if ( setsockopt(a1: v5, a2: 0xFFFF, a3: 32, a4: &v31, a5: 4u) == -1 )
  {
    v22 = *__error(); /*0x1039e83e4*/
    v37[0] = v22; /*0x1039e83e6*/
    v23 = FLog::Network; /*0x1039e83f0*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
    {
      v24 = qword_10D7BBAA8; /*0x1039e840a*/
      RBX::systemErrorToString(this: (RBX *)&v33, a2: v22); /*0x1039e8417*/
      if ( (v33 & 1) != 0 ) /*0x1039e8421*/
        LODWORD(v26) = (_DWORD)v35; /*0x1039e8423*/
      else
        v26 = v34; /*0x1039e8429*/
      FLog::FastLogFormatted(
        a1: v23,
        a2: v24,
        a3: (unsigned int)"[FLog::Network] setsockopt SO_BROADCAST failed : errno=%d, errString=%s",
        a4: v22,
        a5: (_DWORD)v26,
        a6: v25);
      if ( (v33 & 1) != 0 ) /*0x1039e8447*/
        operator delete(a1: v35); /*0x1039e844d*/
    }
  }
  return 0; /*0x1039e8454*/
}

// Address: 0x1039e8870 | Name: __ZN6RakNet11SocketLayer17CreateBoundSocketEP8addrinfotttt
__int64 __fastcall RakNet::SocketLayer::CreateBoundSocket(
        addrinfo *this,
        addrinfo *a2,
        unsigned __int16 a3,
        unsigned __int16 a4,
        unsigned __int16 a5,
        int a6)
{
  int v9; // r15d
  unsigned __int16 v10; // r13
  int v11; // eax
  unsigned int v12; // ebx
  sockaddr *ai_addr; // rax
  unsigned __int16 ai_family; // ax
  int v15; // eax
  unsigned __int16 v18; // [rsp+4h] [rbp-2Ch]

  v18 = (unsigned __int16)a2; /*0x1039e88a7*/
  if ( (unsigned __int8)DFLog::NetworkDetailed >= 6u && BYTE1(DFLog::NetworkDetailed) >= 3u ) /*0x1039e889f*/
    FLog::FastLogFormatted( /*0x1039e88c4*/
      a1: DFLog::NetworkDetailed,
      a2: qword_10D7BBE20,
      a3: (unsigned int)"[DFLog::NetworkDetailed] CreateBoundSocket() forcePort=%d, socketFamily=%d",
      a4: (unsigned __int16)a2,
      a5,
      a6);
  v9 = 0; /*0x1039e88c9*/
  if ( this != nullptr ) /*0x1039e88cf*/
  {
    v10 = a4; /*0x1039e88d9*/
    do /*0x1039e88e9*/
    {
      v11 = socket(a1: this->ai_family, a2: this->ai_socktype, a3: this->ai_protocol); /*0x1039e88e9*/
      if ( v11 != -1 ) /*0x1039e88f1*/
      {
        v12 = v11; /*0x1039e88f3*/
        ai_addr = this->ai_addr; /*0x1039e88fa*/
        if ( this->ai_family == 2 ) /*0x1039e88fe*/
        {
          *(_DWORD *)&ai_addr->sa_data[2] = 0; /*0x1039e8900*/
          ai_family = 2; /*0x1039e8907*/
        }
        else
        {
          *(in6_addr *)&ai_addr->sa_data[6] = in6addr_any; /*0x1039e8917*/
          ai_family = this->ai_family; /*0x1039e891b*/
        }
        RakNet::SocketLayer::SetSocketOptions(this: (RakNet::SocketLayer *)v12, a2: ai_family, a3: a5 == 0); /*0x1039e892f*/
        v15 = TryBindOnAllPorts(a1: v12, a2: this, a3: v18, a4: a3, a5: v10); /*0x1039e8942*/
        if ( v15 >= 0 ) /*0x1039e8949*/
          return v12; /*0x1039e8949*/
        v9 = v15; /*0x1039e894b*/
        if ( DFFlag::EnableSocketPortSharding == 1 ) /*0x1039e8955*/
          close(a1: v12); /*0x1039e8959*/
      }
      this = this->ai_next; /*0x1039e895e*/
    }
    while ( this != nullptr ); /*0x1039e88e9*/
  }
  DebugFailedSocketBind(a1: v9); /*0x1039e896b*/
  return (unsigned int)-1; /*0x1039e897e*/
}

// Address: 0x1039e898a | Name: __ZN6RakNet11SocketLayer5WriteEiPKci
ssize_t __fastcall RakNet::SocketLayer::Write(RakNet::SocketLayer *this, const void *a2, const char *a3)
{
  return send(a1: (int)this, a2, (int)a3, a4: 0); /*0x1039e8993*/
}

// Address: 0x1039e899a | Name: __ZN6RakNet11SocketLayer16RecvFromBlockingEiPNS_7RakPeerEPcPiPNS_13SystemAddressEPyS6_
__int64 __fastcall RakNet::SocketLayer::RecvFromBlocking(
        RakNet::SocketLayer *this,
        int a2,
        RakNet::RakPeer *a3,
        char *a4,
        int *a5,
        RakNet::SystemAddress *a6)
{
  unsigned int v10; // r13d
  int v11; // eax
  bool v12; // si
  int v13; // eax
  __int32_t v14; // eax
  int v15; // r14d
  int v16; // r15d
  timeval v18; // [rsp+10h] [rbp-100h] BYREF
  fd_set v19; // [rsp+20h] [rbp-F0h] BYREF
  sockaddr v20[2]; // [rsp+A0h] [rbp-70h] BYREF
  unsigned __int64 v21; // [rsp+C8h] [rbp-48h]
  socklen_t v22; // [rsp+D4h] [rbp-3Ch] BYREF
  pollfd v23; // [rsp+D8h] [rbp-38h] BYREF

  v10 = (unsigned int)this; /*0x1039e89ba*/
  memset(v20, 0, 28); /*0x1039e89ce*/
  v22 = 28; /*0x1039e89d6*/
  if ( DFFlag::RakNetDisablePollAndSelect == 0 ) /*0x1039e89e4*/
  {
    if ( DFFlag::RakNetEnablePoll == 1 ) /*0x1039e8a32*/
    {
      v23.fd = (int)this; /*0x1039e8a3e*/
      *(_DWORD *)&v23.events = 1; /*0x1039e8a41*/
      v13 = poll(a1: &v23, a2: 1u, a3: DFInt::RakNetSelectTimeoutMs); /*0x1039e8a4d*/
      if ( v13 == -1 ) /*0x1039e8a55*/
      {
        v15 = DFLog::NetworkSocketReceiveError; /*0x1039e8b91*/
        if ( (unsigned __int8)DFLog::NetworkSocketReceiveError >= 6u && BYTE1(DFLog::NetworkSocketReceiveError) >= 6u ) /*0x1039e8ba7*/
        {
          v16 = qword_10D7BBE40; /*0x1039e8bae*/
          v18.tv_sec = (unsigned int)*__error(); /*0x1039e8bc3*/
          *(_QWORD *)v19.fds_bits = 1; /*0x1039e8bc6*/
          *(_QWORD *)&v19.fds_bits[2] = &v18; /*0x1039e8bd1*/
          FLog::detail::FastLogSafeFormattedInternal( /*0x1039e8c01*/
            a1: v15,
            a2: v16,
            a3: 6,
            a4: (unsigned int)"[DFLog::NetworkSocketReceiveError] poll failed with errno {}",
            a5: 60,
            a6: 1,
            1,
            &v18,
            v18.tv_sec);
        }
      }
      else if ( v13 == 1 ) /*0x1039e8a5e*/
      {
        goto LABEL_2; /*0x1039e8a5e*/
      }
    }
    else
    {
      memset(&v19, 0, sizeof(v19)); /*0x1039e8a93*/
      v21 = (int)this; /*0x1039e8aa5*/
      if ( &___darwin_check_fd_set_overflow == nullptr /*0x1039e8abe*/
        || (unsigned int)__darwin_check_fd_set_overflow(a1: (unsigned int)this, a2: &v19, a3: 0) != 0 )
      {
        v19.fds_bits[v21 >> 5] |= 1 << v10; /*0x1039e8ad2*/
      }
      v18.tv_sec = DFInt::RakNetSelectTimeoutMs / 1000; /*0x1039e8afe*/
      v18.tv_usec = 1000 * (DFInt::RakNetSelectTimeoutMs % 1000); /*0x1039e8b0f*/
      if ( select_1050(a1: v10 + 1, a2: &v19, a3: nullptr, a4: nullptr, a5: &v18) > 0 /*0x1039e8b4c*/
        && (&___darwin_check_fd_set_overflow == nullptr
         || (unsigned int)__darwin_check_fd_set_overflow(a1: v10, a2: &v19, a3: 0) != 0) )
      {
        v14 = v19.fds_bits[v21 >> 5]; /*0x1039e8b5a*/
        if ( _bittest(&v14, v10) ) /*0x1039e8b65*/
          goto LABEL_2; /*0x1039e8b65*/
      }
    }
    *(_DWORD *)a4 = 0; /*0x1039e8c06*/
    return __stack_chk_guard; /*0x1039e8c06*/
  }
LABEL_2:
  v11 = recvfrom(a1: v10, a2: a3, a3: 0x5D4u, a4: 0, a5: v20, a6: &v22); /*0x1039e89e6*/
  *(_DWORD *)a4 = v11; /*0x1039e8a00*/
  if ( v11 > 0 ) /*0x1039e8a04*/
  {
    *(_QWORD *)a6 = RakNet::GetTimeUS(this: nullptr, a2: v12); /*0x1039e8a11*/
    if ( v20[0].sa_family == 2 ) /*0x1039e8a18*/
    {
      *(sockaddr *)a5 = v20[0]; /*0x1039e8a22*/
    }
    else
    {
      *(sockaddr *)a5 = v20[0]; /*0x1039e8b74*/
      *(sockaddr *)(a5 + 3) = *(sockaddr *)&v20[0].sa_data[10]; /*0x1039e8b7c*/
    }
    *((_WORD *)a5 + 14) = __ROL2__(*((_WORD *)a5 + 1), 8); /*0x1039e8b8a*/
  }
  return __stack_chk_guard; /*0x1039e8c1c*/
}

// Address: 0x1039e8c34 | Name: __ZN6RakNet11SocketLayer13SendToOrDelayENSt3__110shared_ptrINS_12RakNetSocketEEEPKciRKNS_13SystemAddressES9_bPNS_7RakPeerEPNS_16ReliabilityLayerEyS6_l
__int64 __fastcall RakNet::SocketLayer::SendToOrDelay(
        unsigned int **a1,
        const void *a2,
        unsigned int a3,
        __int64 a4,
        const RakNet::SystemAddress *a5,
        unsigned __int8 a6,
        RakNet::RakPeer *a7,
        __int64 a8,
        __int64 a9,
        _BOOL8 a10,
        char *a11)
{
  __int64 v16; // rax
  bool v17; // si
  __int64 TimeUS; // r12
  __int64 QueueTxPacket; // r15
  __int128 v20; // xmm0
  unsigned int *v21; // rax
  std::__shared_weak_count *v22; // rdi
  __int64 v24; // [rsp+0h] [rbp-50h]
  __int64 v25; // [rsp+10h] [rbp-40h]
  unsigned __int8 v27; // [rsp+20h] [rbp-30h]
  unsigned int v28; // [rsp+24h] [rbp-2Ch]

  v16 = (*(__int64 (__fastcall **)(RakNet::RakPeer *))(*(_QWORD *)a7 + 904LL))(a1: a7); /*0x1039e8c5f*/
  if ( v16 == 0 ) /*0x1039e8c68*/
    return RakNet::SocketLayer::SendTo( /*0x1039e8d6b*/
             this: (RakNet::SocketLayer *)**a1,
             (int)a2,
             (const char *)a3,
             a4,
             a5,
             (const RakNet::SystemAddress *)a6,
             a7: a10,
             a8: a11,
             a9: v24);
  v28 = a3; /*0x1039e8c6e*/
  v25 = v16; /*0x1039e8c72*/
  v27 = a6; /*0x1039e8c7a*/
  TimeUS = a9; /*0x1039e8c7e*/
  if ( a9 == 0 ) /*0x1039e8c85*/
    TimeUS = RakNet::GetTimeUS(this: nullptr, a2: v17); /*0x1039e8c8e*/
  QueueTxPacket = RakNet::RakPeer::AllocateQueueTxPacket(this: a7); /*0x1039e8c9a*/
  v20 = *(_OWORD *)a1; /*0x1039e8c9d*/
  v21 = a1[1]; /*0x1039e8ca0*/
  if ( v21 != nullptr ) /*0x1039e8caa*/
    _InterlockedIncrement64((volatile signed __int64 *)v21 + 2); /*0x1039e8cac*/
  v22 = *(std::__shared_weak_count **)(QueueTxPacket + 8); /*0x1039e8cb5*/
  *(_OWORD *)QueueTxPacket = v20; /*0x1039e8cb9*/
  if ( v22 != nullptr ) /*0x1039e8cc3*/
    std::__shared_weak_count::__release_weak(this: v22); /*0x1039e8cc5*/
  memcpy(__dst: (void *)(QueueTxPacket + 16), __src: a2, __n: (int)v28); /*0x1039e8cd7*/
  *(_DWORD *)(QueueTxPacket + 1508) = v28; /*0x1039e8cdc*/
  RakNet::SystemAddress::operator=(a1: QueueTxPacket + 1512, a2: a4); /*0x1039e8cee*/
  RakNet::SystemAddress::operator=(a1: QueueTxPacket + 1544, a2: a5); /*0x1039e8d01*/
  *(_BYTE *)(QueueTxPacket + 1576) = v27; /*0x1039e8d09*/
  *(_QWORD *)(QueueTxPacket + 1584) = a10; /*0x1039e8d14*/
  *(_QWORD *)(QueueTxPacket + 1592) = a11; /*0x1039e8d1f*/
  *(_QWORD *)(QueueTxPacket + 1600) = v25 + TimeUS; /*0x1039e8d2a*/
  *(_QWORD *)(QueueTxPacket + 1608) = a8; /*0x1039e8d31*/
  RakNet::RakPeer::QueueTxPacketForDelay(a1: a7, a2: QueueTxPacket); /*0x1039e8d3f*/
  return 4294967293LL; /*0x1039e8d49*/
}

// Address: 0x1039e8d80 | Name: __ZN6RakNet11SocketLayer6SendToEiPKciRKNS_13SystemAddressES5_bS2_l
__int64 __fastcall RakNet::SocketLayer::SendTo(
        RakNet::SocketLayer *this,
        void *a2,
        const char *a3,
        __int128 *a4,
        const RakNet::SystemAddress *a5,
        const RakNet::SystemAddress *a6)
{
  int v6; // ebx
  unsigned int v7; // r14d
  unsigned int v9; // r12d
  __int128 v10; // xmm0
  unsigned int v11; // r13d
  int *v13[2]; // [rsp+0h] [rbp-B0h]
  __int64 v14; // [rsp+10h] [rbp-A0h]
  int *v15[2]; // [rsp+60h] [rbp-50h] BYREF
  __int64 v16[8]; // [rsp+70h] [rbp-40h]

  v6 = (int)a4; /*0x1039e8d94*/
  v7 = (unsigned int)a3; /*0x1039e8d97*/
  v9 = (unsigned int)this; /*0x1039e8d9d*/
  if ( (_BYTE)DFLog::RakNetPktTrace != 0 && ((_BYTE)a6 == 0 || DFFlag::DebugRakNetLogAllPackets == 1) ) /*0x1039e8dbb*/
  {
    v10 = *a4; /*0x1039e8dbd*/
    *(_OWORD *)v16 = a4[1]; /*0x1039e8dc4*/
    *(_OWORD *)v15 = v10; /*0x1039e8dc8*/
    v14 = v16[0]; /*0x1039e8df7*/
    *(_OWORD *)v13 = v10; /*0x1039e8dfc*/
    RakNet::LogPkt(a1: a2, a2: (unsigned int)a3, a3: "Tx", a4: 0); /*0x1039e8e0f*/
  }
  if ( v9 == -1 ) /*0x1039e8e18*/
  {
    return (unsigned int)-1; /*0x1039e8e40*/
  }
  else
  {
    v11 = 0; /*0x1039e8e1a*/
    LODWORD(v15[0]) = 0; /*0x1039e8e21*/
    if ( (unsigned int)RakNet::SocketLayer::SendTo_PC( /*0x1039e8e38*/
                         this: (RakNet::SocketLayer *)v9,
                         a2,
                         a3: (const char *)v7,
                         a4: v6,
                         a5,
                         a6: (const RakNet::SystemAddress *)v15,
                         a7: v13[0],
                         a8: (const char *)v13[1],
                         a9: v14) == -1 )
      return LODWORD(v15[0]); /*0x1039e8e3a*/
  }
  return v11; /*0x1039e8e49*/
}

// Address: 0x1039e8e5c | Name: __ZN6RakNet11SocketLayer16SendToAfterDelayEiPNS_19DelayTransmitStructE
__int64 __fastcall RakNet::SocketLayer::SendToAfterDelay(RakNet::SocketLayer *a1, __int64 a2)
{
  return RakNet::SocketLayer::SendTo( /*0x1039e8e97*/
           this: a1,
           a2: (void *)(a2 + 16),
           a3: (const char *)*(unsigned int *)(a2 + 1508),
           a4: (__int128 *)(a2 + 1512),
           a5: (const RakNet::SystemAddress *)(a2 + 1544),
           a6: (const RakNet::SystemAddress *)*(unsigned __int8 *)(a2 + 1576));
}

// Address: 0x1039e8e9e | Name: __ZN6RakNet11SocketLayer9SendTo_PCEiPKciRKNS_13SystemAddressES5_RiS2_l
__int64 __fastcall RakNet::SocketLayer::SendTo_PC(
        RakNet::SocketLayer *this,
        char *a2,
        const char *a3,
        const sockaddr *a4,
        const RakNet::SystemAddress *a5,
        const RakNet::SystemAddress *a6)
{
  int v8; // r14d
  size_t v9; // r13
  socklen_t v10; // r9d
  int v11; // eax
  unsigned int v12; // ebx
  unsigned int v13; // esi
  int v14; // r13d
  int v15; // r13d
  int *v16; // rax
  int v17; // r12d
  int *v18; // rax
  char *v19; // rax
  int v20; // r14d
  int v21; // r15d
  int *v22; // rax
  int v23; // r8d
  int v24; // r9d
  int v25; // r14d
  int v26; // r15d
  int *v27; // rax
  int v28; // r8d
  int v29; // r9d
  int *v30; // rax
  int v32; // [rsp+18h] [rbp-78h]
  socklen_t v33; // [rsp+24h] [rbp-6Ch] BYREF
  unsigned int *v34; // [rsp+28h] [rbp-68h]
  __int64 v35; // [rsp+30h] [rbp-60h]
  unsigned int v36; // [rsp+3Ch] [rbp-54h] BYREF
  sockaddr v37; // [rsp+40h] [rbp-50h] BYREF
  void *v38; // [rsp+50h] [rbp-40h]

  v8 = (int)this; /*0x1039e8eb5*/
  v36 = (unsigned int)a3; /*0x1039e8ec6*/
  v34 = (unsigned int *)a6; /*0x1039e8ec9*/
  *(_DWORD *)a6 = 0; /*0x1039e8ecd*/
  LODWORD(v35) = (_DWORD)a3; /*0x1039e8ed4*/
  v9 = (int)a3; /*0x1039e8ed7*/
  while ( 1 ) /*0x1039e8edf*/
  {
    v10 = 16; /*0x1039e8edf*/
    if ( a4->sa_family != 2 ) /*0x1039e8ee5*/
      v10 = 28; /*0x1039e8ee7*/
    v11 = sendto(a1: v8, a2, a3: v9, a4: 0, a5: a4, a6: v10); /*0x1039e8efb*/
    v12 = v11; /*0x1039e8f00*/
    if ( v11 < 0 ) /*0x1039e8f05*/
      break; /*0x1039e8f05*/
    if ( v11 != 0 ) /*0x1039e8f07*/
      return v12; /*0x1039e8f07*/
  }
  v13 = (2 * (*__error() != 35)) | 0xFFFFFFFC; /*0x1039e8f1e*/
  *v34 = v13; /*0x1039e8f25*/
  v14 = DFLog::NetworkTrace; /*0x1039e8f2e*/
  if ( (unsigned __int8)DFLog::NetworkTrace >= 6u && (DFLog::NetworkTrace & 0xFE00) != 0 ) /*0x1039e8f3f*/
  {
    v35 = qword_10D7BB068; /*0x1039e8f4a*/
    RBX::systemErrorToString(this: (RBX *)&v37, a2: v13); /*0x1039e8f52*/
    FLog::FastLogSafeFormatted<int &,int &,std::string>( /*0x1039e8f85*/
      a1: v14,
      a2: v35,
      a3: 2,
      a4: (int)"[DFLog::NetworkTrace] sendto failed with code {} msg len {} errno {}",
      a5: 68,
      a6: v34,
      a7: &v36,
      a8: &v37.sa_len);
    if ( (v37.sa_len & 1) != 0 ) /*0x1039e8f8e*/
      operator delete(a1: v38); /*0x1039e8f94*/
    LODWORD(v35) = v36; /*0x1039e8f9c*/
  }
  v15 = DFLog::NetworkSocketSendError; /*0x1039e8f9f*/
  if ( (unsigned __int8)DFLog::NetworkSocketSendError >= 6u && BYTE1(DFLog::NetworkSocketSendError) >= 3u ) /*0x1039e8fb5*/
  {
    v32 = qword_10D7BBE30; /*0x1039e8fc3*/
    LODWORD(v34) = *a2; /*0x1039e8fcc*/
    v16 = __error(); /*0x1039e8fcf*/
    strerror(__errnum: *v16); /*0x1039e8fd6*/
    FLog::FastLogFormatted( /*0x1039e8ff9*/
      a1: v15,
      a2: v32,
      a3: (unsigned int)"[DFLog::NetworkSocketSendError] sendto failed with code %i for char %i and length %i.errno %s",
      a4: v12,
      a5: (_DWORD)v34,
      a6: v35);
    LODWORD(v35) = v36; /*0x1039e9001*/
  }
  v17 = *a2; /*0x1039e9004*/
  v18 = __error(); /*0x1039e9009*/
  v19 = strerror(__errnum: *v18); /*0x1039e9010*/
  printf(a1: "sendto failed with code %i for char %i and length %i.errno %s\n", v12, v17, v35, v19); /*0x1039e9029*/
  if ( a4->sa_family == 2 ) /*0x1039e9033*/
  {
    v33 = 16; /*0x1039e9039*/
    if ( getsockname(a1: v8, a2: &v37, a3: &v33) != 0 ) /*0x1039e904d*/
    {
      v20 = DFLog::NetworkSocketSendError; /*0x1039e9053*/
      if ( (unsigned __int8)DFLog::NetworkSocketSendError >= 6u && BYTE1(DFLog::NetworkSocketSendError) >= 3u ) /*0x1039e9069*/
      {
        v21 = qword_10D7BBE30; /*0x1039e9070*/
        v22 = __error(); /*0x1039e9077*/
        FLog::FastLogFormatted( /*0x1039e908d*/
          a1: v20,
          a2: v21,
          a3: (unsigned int)"[DFLog::NetworkSocketSendError] getsockname returned errno 0x%x",
          a4: *v22,
          a5: v23,
          a6: v24);
      }
LABEL_21:
      v30 = __error(); /*0x1039e90f7*/
      printf(a1: "getsockname returned errno 0x%x\n", *v30); /*0x1039e9102*/
    }
  }
  else
  {
    v33 = 28; /*0x1039e909d*/
    if ( getsockname(a1: v8, a2: &v37, a3: &v33) != 0 ) /*0x1039e90b1*/
    {
      v25 = DFLog::NetworkSocketSendError; /*0x1039e90b3*/
      if ( (unsigned __int8)DFLog::NetworkSocketSendError >= 6u && BYTE1(DFLog::NetworkSocketSendError) >= 3u ) /*0x1039e90c9*/
      {
        v26 = qword_10D7BBE30; /*0x1039e90d0*/
        v27 = __error(); /*0x1039e90d7*/
        FLog::FastLogFormatted( /*0x1039e90ed*/
          a1: v25,
          a2: v26,
          a3: (unsigned int)"[DFLog::NetworkSocketSendError] getsockname returned errno 0x%x",
          a4: *v27,
          a5: v28,
          a6: v29);
      }
      goto LABEL_21; /*0x1039e90ed*/
    }
  }
  return v12; /*0x1039e9119*/
}

// Address: 0x1039e932c | Name: __ZN6RakNet11SocketLayer7GetMyIPEPNS_13SystemAddressE
__int64 __fastcall RakNet::SocketLayer::GetMyIP(RakNet::SocketLayer *this, RakNet::SystemAddress *a2)
{
  return GetMyIP_Win32(a1: this); /*0x1039e9330*/
}

// Address: 0x1039e9336 | Name: __ZN6RakNet11SocketLayer12GetLocalPortEi
__int64 __fastcall RakNet::SocketLayer::GetLocalPort(RakNet::SocketLayer *this)
{
  unsigned int v1; // ebx
  RakNet::SystemAddress *v2; // rdx
  int v4[12]; // [rsp+0h] [rbp-30h] BYREF

  v1 = (unsigned int)this; /*0x1039e9341*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v4); /*0x1039e934a*/
  RakNet::SocketLayer::GetSystemAddress(this: (RakNet::SocketLayer *)v1, a2: (int)v4, a3: v2); /*0x1039e9354*/
  return (unsigned __int16)RakNet::SystemAddress::GetPort(this: (RakNet::SystemAddress *)v4); /*0x1039e9364*/
}

// Address: 0x1039e936e | Name: __ZN6RakNet11SocketLayer16GetSystemAddressEiPNS_13SystemAddressE
__int64 __fastcall RakNet::SocketLayer::GetSystemAddress(
        RakNet::SocketLayer *this,
        __m128i *a2,
        RakNet::SystemAddress *a3)
{
  RakNet::SystemAddress *v5; // rdi
  unsigned __int8 v6; // si
  __m128i v7; // xmm0
  _BYTE v8[28]; // [rsp+0h] [rbp-40h] BYREF
  socklen_t v9; // [rsp+1Ch] [rbp-24h] BYREF
  __int128 v10; // [rsp+20h] [rbp-20h]

  v9 = 28; /*0x1039e938c*/
  if ( getsockname(a1: (int)this, a2: (sockaddr *)v8, a3: &v9) == 0 ) /*0x1039e939d*/
  {
    if ( v8[1] == 2 ) /*0x1039e93c9*/
    {
      *a2 = _mm_loadu_si128((const __m128i *)v8); /*0x1039e93d0*/
      a2[1].i16[6] = __ROL2__(a2->i16[1], 8); /*0x1039e93dc*/
      LODWORD(v10) = 0; /*0x1039e93e0*/
      if ( a2->i32[1] != 0 ) /*0x1039e93eb*/
        return __stack_chk_guard; /*0x1039e93eb*/
      v5 = (RakNet::SystemAddress *)a2; /*0x1039e93ed*/
      v6 = 4; /*0x1039e93f0*/
    }
    else
    {
      qmemcpy(a2, v8, 28); /*0x1039e93ff*/
      a2[1].i16[6] = __ROL2__(a2->i16[1], 8); /*0x1039e940e*/
      v10 = 0; /*0x1039e9415*/
      v7 = _mm_loadu_si128((const __m128i *)&a2->u64[1]); /*0x1039e9419*/
      if ( !_mm_testz_si128(v7, v7) ) /*0x1039e9423*/
        return __stack_chk_guard; /*0x1039e9423*/
      v5 = (RakNet::SystemAddress *)a2; /*0x1039e9425*/
      v6 = 6; /*0x1039e9428*/
    }
    RakNet::SystemAddress::SetToLoopback(this: v5, a2: v6); /*0x1039e942d*/
    return __stack_chk_guard; /*0x1039e9432*/
  }
  RakNet::SystemAddress::FromString(this: (RakNet::SystemAddress *)a2, a2: nullptr, a3: 124); /*0x1039e93a9*/
  return __stack_chk_guard; /*0x1039e93be*/
}

// END SocketLayer part 1/1, 18 functions
