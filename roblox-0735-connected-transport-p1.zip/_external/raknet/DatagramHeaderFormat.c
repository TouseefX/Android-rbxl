// DatagramHeaderFormat -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 3 functions


// Address: 0x1039d9b80 | Name: __ZN6RakNet20DatagramHeaderFormat23GetDataHeaderByteLengthEb
__int64 __fastcall RakNet::DatagramHeaderFormat::GetDataHeaderByteLength(RakNet::DatagramHeaderFormat *this)
{
  return (unsigned int)(4 * (_DWORD)this + 9); /*0x1039d9b8b*/
}

// Address: 0x1039d9b8e | Name: __ZN6RakNet20DatagramHeaderFormat9SerializeEPNS_9BitStreamEbRjbbb
__int64 __fastcall RakNet::DatagramHeaderFormat::Serialize(
        RakNet::DatagramHeaderFormat *this,
        RakNet::BitStream *a2,
        char a3,
        unsigned int *a4,
        char a5,
        char a6,
        bool a7)
{
  char v12; // r12
  __int64 result; // rax
  unsigned int v14; // ecx
  unsigned __int8 *v15; // rsi
  RakNet::BitStream *v16; // rdi
  unsigned __int8 *v17; // rsi
  RakNet::BitStream *v18; // rdi
  unsigned int v19; // ecx
  unsigned __int8 *v20; // rsi
  RakNet::BitStream *v21; // rdi
  RakNet::BitStream *v22; // r14
  RakNet::BitStream *v23; // rdi
  unsigned __int8 *v24; // rsi
  RakNet::BitStream *v25; // rdi
  RakNet::BitStream *v26; // rdi
  RakNet::BitStream *v27; // rdi
  RakNet::BitStream *v28; // rdi
  unsigned int *v29; // [rsp+0h] [rbp-40h]
  unsigned __int8 v31[4]; // [rsp+10h] [rbp-30h] BYREF
  _DWORD v32[11]; // [rsp+14h] [rbp-2Ch] BYREF

  RakNet::BitStream::Write1(this: a2); /*0x1039d9bb4*/
  if ( *((_BYTE *)this + 16) == 1 ) /*0x1039d9bbe*/
  {
    RakNet::BitStream::Write1(this: a2); /*0x1039d9bc3*/
    if ( *((_BYTE *)this + 18) == 1 ) /*0x1039d9bcd*/
      RakNet::BitStream::Write1(this: a2); /*0x1039d9bd2*/
    else
      RakNet::BitStream::Write0(this: a2); /*0x1039d9c12*/
    if ( *((_BYTE *)this + 22) == 1 ) /*0x1039d9c1c*/
      RakNet::BitStream::Write1(this: a2); /*0x1039d9c21*/
    else
      RakNet::BitStream::Write0(this: a2); /*0x1039d9c55*/
    result = *((unsigned int *)a2 + 3); /*0x1039d9c5a*/
    v14 = result + (-*((_DWORD *)a2 + 3) & 7); /*0x1039d9c64*/
    *((_DWORD *)a2 + 3) = v14; /*0x1039d9c66*/
    if ( a3 != 0 ) /*0x1039d9c6d*/
    {
      v32[0] = *(_DWORD *)this; /*0x1039d9c72*/
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039d9e84*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v26); /*0x1039d9e8f*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039d9e9c*/
      }
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039d9c8a*/
      {
        v15 = (unsigned __int8 *)v32; /*0x1039d9c8c*/
        v16 = a2; /*0x1039d9c90*/
      }
      else
      {
        RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v32, a2: v31, a3: (unsigned __int8 *)4, a4: v14); /*0x1039d9ca5*/
        v16 = a2; /*0x1039d9caa*/
        v15 = v31; /*0x1039d9cad*/
      }
      result = RakNet::BitStream::WriteBits(this: v16, a2: v15, a3: 0x20u, a4: true); /*0x1039d9cba*/
    }
    if ( *((_BYTE *)this + 18) == 1 ) /*0x1039d9cc4*/
    {
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039d9eb4*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v27); /*0x1039d9ebf*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039d9ecc*/
      }
      v17 = (unsigned __int8 *)this + 12; /*0x1039d9cd8*/
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039d9ce3*/
      {
        v18 = a2; /*0x1039d9ce5*/
      }
      else
      {
        RakNet::BitStream::ReverseBytes( /*0x1039d9cf9*/
          this: (RakNet::DatagramHeaderFormat *)((char *)this + 12),
          a2: v31,
          a3: (unsigned __int8 *)4,
          a4: v14);
        v18 = a2; /*0x1039d9cfe*/
        v17 = v31; /*0x1039d9d01*/
      }
      result = RakNet::BitStream::WriteBits(this: v18, a2: v17, a3: 0x20u, a4: true); /*0x1039d9d0e*/
    }
  }
  else
  {
    v29 = a4; /*0x1039d9bd9*/
    v12 = *((_BYTE *)this + 17); /*0x1039d9bdd*/
    RakNet::BitStream::Write0(this: a2); /*0x1039d9be4*/
    if ( v12 == 1 ) /*0x1039d9bf0*/
    {
      RakNet::BitStream::Write1(this: a2); /*0x1039d9bf2*/
      result = *((unsigned int *)a2 + 3); /*0x1039d9bf7*/
      v14 = result + (-*((_DWORD *)a2 + 3) & 7); /*0x1039d9c01*/
      *((_DWORD *)a2 + 3) = v14; /*0x1039d9c03*/
      a4 = v29; /*0x1039d9c06*/
    }
    else
    {
      RakNet::BitStream::Write0(this: a2); /*0x1039d9c28*/
      a4 = v29; /*0x1039d9c30*/
      if ( a5 != 0 ) /*0x1039d9c34*/
      {
        if ( *((_BYTE *)this + 26) == 1 ) /*0x1039d9c3f*/
          RakNet::BitStream::Write1(this: a2); /*0x1039d9c48*/
        else
          RakNet::BitStream::Write0(this: a2); /*0x1039d9d1b*/
      }
      if ( a6 != 0 ) /*0x1039d9d23*/
      {
        if ( *((_BYTE *)this + 27) == 1 ) /*0x1039d9d2a*/
          RakNet::BitStream::Write1(this: a2); /*0x1039d9d2f*/
        else
          RakNet::BitStream::Write0(this: a2); /*0x1039d9d39*/
      }
      RakNet::BitStream::Write0(this: a2); /*0x1039d9d41*/
      if ( *((_BYTE *)this + 19) == 1 ) /*0x1039d9d4b*/
        RakNet::BitStream::Write1(this: a2); /*0x1039d9d50*/
      else
        RakNet::BitStream::Write0(this: a2); /*0x1039d9d5a*/
      if ( *((_BYTE *)this + 20) == 1 ) /*0x1039d9d64*/
        RakNet::BitStream::Write1(this: a2); /*0x1039d9d69*/
      else
        RakNet::BitStream::Write0(this: a2); /*0x1039d9d73*/
      v19 = *((_DWORD *)a2 + 3) + (-*((_DWORD *)a2 + 3) & 7); /*0x1039d9d82*/
      *((_DWORD *)a2 + 3) = v19; /*0x1039d9d84*/
      if ( a3 != 0 ) /*0x1039d9d8b*/
      {
        v32[0] = *(_DWORD *)this; /*0x1039d9d90*/
        if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039d9ee4*/
          && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
        {
          RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v28); /*0x1039d9eef*/
          __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039d9efc*/
          a4 = v29; /*0x1039d9f01*/
        }
        if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039d9da8*/
        {
          v20 = (unsigned __int8 *)v32; /*0x1039d9daa*/
          v21 = a2; /*0x1039d9dae*/
        }
        else
        {
          RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v32, a2: v31, a3: (unsigned __int8 *)4, a4: v19); /*0x1039d9dc3*/
          v21 = a2; /*0x1039d9dc8*/
          v20 = v31; /*0x1039d9dcb*/
        }
        RakNet::BitStream::WriteBits(this: v21, a2: v20, a3: 0x20u, a4: true); /*0x1039d9dd8*/
      }
      result = RakNet::BitStream::Write<RakNet::uint24_t>(a1: a2, a2: (char *)this + 8); /*0x1039d9de4*/
    }
  }
  if ( a7 ) /*0x1039d9ded*/
  {
    *a4 = *((_DWORD *)a2 + 3); /*0x1039d9df2*/
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039d9e5b*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v25); /*0x1039d9e62*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039d9e6f*/
    }
    v22 = (RakNet::DatagramHeaderFormat *)((char *)this + 24); /*0x1039d9e00*/
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039d9e0b*/
    {
      v23 = a2; /*0x1039d9e0d*/
      v24 = (unsigned __int8 *)v22; /*0x1039d9e10*/
    }
    else
    {
      RakNet::BitStream::ReverseBytes(this: v22, a2: v31, a3: (unsigned __int8 *)2, a4: v14); /*0x1039d9e24*/
      v23 = a2; /*0x1039d9e29*/
      v24 = v31; /*0x1039d9e2c*/
    }
    return RakNet::BitStream::WriteBits(this: v23, a2: v24, a3: 0x10u, a4: true); /*0x1039d9e39*/
  }
  return result; /*0x1039d9e3e*/
}

// Address: 0x1039da004 | Name: __ZN6RakNet20DatagramHeaderFormat11DeserializeEPNS_9BitStreamEbbbb
__int64 __fastcall RakNet::DatagramHeaderFormat::Deserialize(
        RakNet::DatagramHeaderFormat *this,
        RakNet::BitStream *a2,
        char a3,
        char a4,
        char a5,
        char a6)
{
  unsigned int v10; // edi
  unsigned int v11; // r10d
  __int64 result; // rax
  unsigned int v13; // esi
  unsigned int v14; // esi
  unsigned int v15; // esi
  unsigned int v16; // r12d
  int v17; // ecx
  unsigned int v18; // esi
  unsigned int v19; // r8d
  int v20; // r10d
  unsigned __int8 *v21; // rbx
  unsigned int v22; // ecx
  unsigned int v23; // ecx
  RakNet::BitStream *v24; // rdi
  unsigned int v25; // r8d
  unsigned int v26; // ecx
  unsigned int v27; // eax
  unsigned int v28; // esi
  unsigned int v29; // ecx
  unsigned int v30; // ecx
  RakNet::BitStream *v31; // rdi
  RakNet::BitStream *v32; // rdi
  RakNet::BitStream *v33; // rdi
  RakNet::BitStream *v34; // rdi
  unsigned __int8 v35[4]; // [rsp+8h] [rbp-28h] BYREF
  unsigned __int8 v36[36]; // [rsp+Ch] [rbp-24h] BYREF

  v10 = *((_DWORD *)a2 + 3); /*0x1039da01f*/
  v11 = *((_DWORD *)a2 + 5); /*0x1039da022*/
  result = v11 + 1; /*0x1039da026*/
  if ( (unsigned int)result <= v10 ) /*0x1039da02c*/
  {
    *((_BYTE *)this + 21) = (unsigned __int8)(*(unsigned __int8 *)(*((_QWORD *)a2 + 3) + (v11 >> 3)) << (v11 & 7)) >> 7; /*0x1039da04f*/
    *((_DWORD *)a2 + 5) = result; /*0x1039da053*/
    v13 = v11 + 2; /*0x1039da05b*/
  }
  else
  {
    v13 = v11 + 1; /*0x1039da02e*/
    result = v11; /*0x1039da030*/
  }
  if ( v13 <= v10 ) /*0x1039da060*/
  {
    v16 = 0x80u >> (result & 7); /*0x1039da0a5*/
    v17 = *(unsigned __int8 *)(*((_QWORD *)a2 + 3) + ((unsigned int)result >> 3)); /*0x1039da0ac*/
    result = v13; /*0x1039da0b1*/
    *((_BYTE *)this + 16) = (v17 & v16) != 0; /*0x1039da0b6*/
    *((_DWORD *)a2 + 5) = v13; /*0x1039da0ba*/
    if ( (v17 & v16) == 0 ) /*0x1039da0be*/
    {
LABEL_6:
      v14 = result + 1; /*0x1039da068*/
      if ( (int)result + 1 <= v10 ) /*0x1039da06d*/
      {
        v20 = *(unsigned __int8 *)(*((_QWORD *)a2 + 3) + ((unsigned int)result >> 3)) << (result & 7); /*0x1039da186*/
        *((_BYTE *)this + 17) = (unsigned __int8)v20 >> 7; /*0x1039da18f*/
        *((_DWORD *)a2 + 5) = v14; /*0x1039da192*/
        result = v14; /*0x1039da196*/
        if ( (v20 & 0x80u) == 0 ) /*0x1039da19b*/
          goto LABEL_8; /*0x1039da19b*/
      }
      else if ( (*((_BYTE *)this + 17) & 1) == 0 ) /*0x1039da077*/
      {
LABEL_8:
        if ( a4 != 0 && (v15 = result + 1, (int)result + 1 <= v10) ) /*0x1039da087*/
        {
          *((_BYTE *)this + 26) = (unsigned int)(*(unsigned __int8 *)(*((_QWORD *)a2 + 3) + ((unsigned int)result >> 3)) << (result & 7)) >> 7; /*0x1039da2dc*/
          *((_DWORD *)a2 + 5) = v15; /*0x1039da2e0*/
        }
        else
        {
          v15 = result; /*0x1039da08d*/
        }
        if ( a5 != 0 && (v25 = v15 + 1, v15 + 1 <= v10) ) /*0x1039da2f0*/
        {
          *((_BYTE *)this + 27) = (unsigned __int8)(*(unsigned __int8 *)(*((_QWORD *)a2 + 3) + (v15 >> 3)) << (v15 & 7)) >> 7; /*0x1039da30f*/
          *((_DWORD *)a2 + 5) = v25; /*0x1039da312*/
        }
        else
        {
          v25 = v15; /*0x1039da2f2*/
        }
        v26 = v25 + 1; /*0x1039da316*/
        if ( v25 + 1 <= v10 ) /*0x1039da31c*/
        {
          *((_DWORD *)a2 + 5) = v26; /*0x1039da325*/
          v27 = v25 + 2; /*0x1039da32d*/
        }
        else
        {
          v27 = v25 + 1; /*0x1039da31e*/
          v26 = v25; /*0x1039da320*/
        }
        if ( v27 <= v10 ) /*0x1039da332*/
        {
          *((_BYTE *)this + 19) = (unsigned __int8)(*(unsigned __int8 *)(*((_QWORD *)a2 + 3) + (v26 >> 3)) << (v26 & 7)) >> 7; /*0x1039da353*/
          *((_DWORD *)a2 + 5) = v27; /*0x1039da357*/
          v28 = v27 + 1; /*0x1039da35b*/
        }
        else
        {
          v28 = v27; /*0x1039da334*/
          v27 = v26; /*0x1039da336*/
        }
        if ( v28 <= v10 ) /*0x1039da360*/
        {
          *((_BYTE *)this + 20) = (unsigned __int8)(*(unsigned __int8 *)(*((_QWORD *)a2 + 3) + (v27 >> 3)) << (v27 & 7)) >> 7; /*0x1039da37d*/
          *((_DWORD *)a2 + 5) = v28; /*0x1039da381*/
        }
        else
        {
          v28 = v27; /*0x1039da362*/
        }
        *((_DWORD *)a2 + 5) = v28 + (-v28 & 7); /*0x1039da38e*/
        if ( a3 != 0 ) /*0x1039da394*/
        {
          if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039da510*/
            && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
          {
            RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v34); /*0x1039da51b*/
            __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039da528*/
          }
          if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039da3ab*/
          {
            RakNet::BitStream::ReadBits(this: a2, a2: v35, a3: 0x20u, a4: true); /*0x1039da3be*/
          }
          else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: a2, a2: v36, a3: 0x20u, a4: true) != 0 ) /*0x1039da3dd*/
          {
            RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v36, a2: v35, a3: (unsigned __int8 *)4, a4: v29); /*0x1039da3ec*/
          }
          *(_QWORD *)this = *(unsigned int *)v35; /*0x1039da3f4*/
        }
        result = RakNet::BitStream::Read<RakNet::uint24_t>(a1: a2, a2: (char *)this + 8); /*0x1039da3fe*/
        if ( a6 != 0 ) /*0x1039da406*/
        {
          if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039da540*/
            && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
          {
LABEL_77:
            RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v24); /*0x1039da546*/
            __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039da558*/
          }
LABEL_63:
          v21 = (unsigned __int8 *)this + 24; /*0x1039da416*/
          if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039da421*/
            return RakNet::BitStream::ReadBits(this: a2, a2: v21, a3: 0x10u, a4: true); /*0x1039da438*/
LABEL_65:
          result = RakNet::BitStream::ReadBits(this: a2, a2: v36, a3: 0x10u, a4: true); /*0x1039da43a*/
          if ( (_BYTE)result != 0 ) /*0x1039da452*/
            return RakNet::BitStream::ReverseBytes( /*0x1039da460*/
                     this: (RakNet::BitStream *)v36,
                     a2: v21,
                     a3: (unsigned __int8 *)2,
                     a4: v30);
          return result; /*0x1039da460*/
        }
        return result; /*0x1039da406*/
      }
      *((_DWORD *)a2 + 5) = result + (-(int)result & 7); /*0x1039da1aa*/
      if ( a6 == 0 ) /*0x1039da1b1*/
        return result; /*0x1039da1b1*/
      if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039da4e0*/
        && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
      {
        RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v33); /*0x1039da4eb*/
        __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039da4f8*/
      }
      v21 = (unsigned __int8 *)this + 24; /*0x1039da1c5*/
      if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039da1d0*/
        return RakNet::BitStream::ReadBits(this: a2, a2: v21, a3: 0x10u, a4: true); /*0x1039da1f2*/
      goto LABEL_65; /*0x1039da1d0*/
    }
  }
  else if ( (*((_BYTE *)this + 16) & 1) == 0 ) /*0x1039da066*/
  {
    goto LABEL_6; /*0x1039da066*/
  }
  *((_BYTE *)this + 17) = 0; /*0x1039da0c0*/
  v18 = result + 1; /*0x1039da0c4*/
  if ( (int)result + 1 <= v10 ) /*0x1039da0c9*/
  {
    *((_BYTE *)this + 18) = (unsigned __int8)(*(unsigned __int8 *)(*((_QWORD *)a2 + 3) + ((unsigned int)result >> 3)) << (result & 7)) >> 7; /*0x1039da0ee*/
    *((_DWORD *)a2 + 5) = v18; /*0x1039da0f2*/
    v19 = result + 2; /*0x1039da0f9*/
  }
  else
  {
    v19 = result + 1; /*0x1039da0cb*/
    v18 = result; /*0x1039da0ce*/
  }
  if ( v19 <= v10 ) /*0x1039da0ff*/
  {
    *((_BYTE *)this + 22) = (unsigned __int8)(*(unsigned __int8 *)(*((_QWORD *)a2 + 3) + (v18 >> 3)) << (v18 & 7)) >> 7; /*0x1039da11e*/
    *((_DWORD *)a2 + 5) = v19; /*0x1039da121*/
  }
  else
  {
    v19 = v18; /*0x1039da101*/
  }
  result = v19 + (-v19 & 7); /*0x1039da12d*/
  *((_DWORD *)a2 + 5) = result; /*0x1039da130*/
  if ( a3 != 0 ) /*0x1039da136*/
  {
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039da480*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v31); /*0x1039da48b*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039da498*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039da151*/
    {
      RakNet::BitStream::ReadBits(this: a2, a2: v35, a3: 0x20u, a4: true); /*0x1039da168*/
    }
    else if ( (unsigned __int8)RakNet::BitStream::ReadBits(this: a2, a2: v36, a3: 0x20u, a4: true) != 0 ) /*0x1039da20f*/
    {
      RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v36, a2: v35, a3: (unsigned __int8 *)4, a4: v22); /*0x1039da21e*/
    }
    result = *(unsigned int *)v35; /*0x1039da223*/
    *(_QWORD *)this = *(unsigned int *)v35; /*0x1039da226*/
  }
  if ( *((_BYTE *)this + 18) == 1 ) /*0x1039da22d*/
  {
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039da4b0*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v32); /*0x1039da4bb*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039da4c8*/
    }
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039da248*/
    {
      result = RakNet::BitStream::ReadBits(this: a2, a2: (unsigned __int8 *)this + 12, a3: 0x20u, a4: true); /*0x1039da25a*/
    }
    else
    {
      result = RakNet::BitStream::ReadBits(this: a2, a2: v36, a3: 0x20u, a4: true); /*0x1039da272*/
      if ( (_BYTE)result != 0 ) /*0x1039da279*/
        result = RakNet::BitStream::ReverseBytes( /*0x1039da287*/
                   this: (RakNet::BitStream *)v36,
                   a2: (unsigned __int8 *)this + 12,
                   a3: (unsigned __int8 *)4,
                   a4: v23);
    }
  }
  if ( a6 != 0 ) /*0x1039da28f*/
  {
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039da2b1*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      goto LABEL_77; /*0x1039da2b1*/
    }
    goto LABEL_63; /*0x1039da2b1*/
  }
  return result; /*0x1039da1e6*/
}

// END DatagramHeaderFormat part 1/1, 3 functions
