// SplitPacketList -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 7 functions


// Address: 0x1039d967c | Name: __ZN6RakNet15SplitPacketListC2Ev
void __fastcall RakNet::SplitPacketList::SplitPacketList(RakNet::SplitPacketList *this)
{
  *((_OWORD *)this + 1) = 0; /*0x1039d9683*/
  *(_OWORD *)this = 0; /*0x1039d9687*/
}

// Address: 0x1039d968c | Name: __ZN6RakNet15SplitPacketListC1Ev
void __fastcall RakNet::SplitPacketList::SplitPacketList(RakNet::SplitPacketList *this)
{
  *((_OWORD *)this + 1) = 0; /*0x1039d9693*/
  *(_OWORD *)this = 0; /*0x1039d9697*/
}

// Address: 0x1039d969c | Name: __ZN6RakNet15SplitPacketListC2Ej
__int64 __fastcall RakNet::SplitPacketList::SplitPacketList(RakNet::SplitPacketList *this, unsigned int a2)
{
  __int64 v3; // r14
  __int64 result; // rax
  _QWORD v5[3]; // [rsp+8h] [rbp-18h] BYREF

  *(_OWORD *)this = 0; /*0x1039d96ad*/
  *((_QWORD *)this + 2) = 0; /*0x1039d96b2*/
  v3 = 0x80000000LL; /*0x1039d96c2*/
  if ( DFFlag::RakNetCapSplitPacketAllocation != 0 ) /*0x1039d96c8*/
    v3 = 0x10000; /*0x1039d96c8*/
  if ( (unsigned int)v3 >= a2 ) /*0x1039d96cf*/
    v3 = a2; /*0x1039d96cf*/
  v5[0] = 0; /*0x1039d96d7*/
  result = std::vector<RakNet::InternalPacket *>::resize(a1: this, a2: v3, a3: v5); /*0x1039d96dd*/
  *((_DWORD *)this + 6) = 0; /*0x1039d96e2*/
  *((_DWORD *)this + 7) = v3; /*0x1039d96e9*/
  return result; /*0x1039d96ed*/
}

// Address: 0x1039d9742 | Name: __ZN6RakNet15SplitPacketListC1Ej
__int64 __fastcall RakNet::SplitPacketList::SplitPacketList(RakNet::SplitPacketList *this, unsigned int a2)
{
  return RakNet::SplitPacketList::SplitPacketList(this, a2); /*0x1039d9746*/
}

// Address: 0x1039d974c | Name: __ZN6RakNet15SplitPacketListD2Ev
void __fastcall RakNet::SplitPacketList::~SplitPacketList(RakNet::SplitPacketList *this)
{
  void *v2; // rdi

  v2 = *(void **)this; /*0x1039d9753*/
  if ( v2 != nullptr ) /*0x1039d9759*/
  {
    *((_QWORD *)this + 1) = v2; /*0x1039d975b*/
    operator delete(a1: v2); /*0x1039d9760*/
  }
}

// Address: 0x1039d9768 | Name: __ZN6RakNet15SplitPacketListD1Ev
void __fastcall RakNet::SplitPacketList::~SplitPacketList(RakNet::SplitPacketList *this)
{
  void *v2; // rdi

  v2 = *(void **)this; /*0x1039d976f*/
  if ( v2 != nullptr ) /*0x1039d9775*/
  {
    *((_QWORD *)this + 1) = v2; /*0x1039d9777*/
    operator delete(a1: v2); /*0x1039d977c*/
  }
}

// Address: 0x1039d9784 | Name: __ZN6RakNet15SplitPacketList12assignToListEPNS_14InternalPacketEj
__int64 __fastcall RakNet::SplitPacketList::assignToList(__int64 *a1, __int64 a2, unsigned int a3)
{
  __int64 result; // rax
  __int64 v4; // rcx

  result = a3; /*0x1039d9788*/
  v4 = *a1; /*0x1039d978a*/
  if ( *(_QWORD *)(*a1 + 8LL * a3) == 0 ) /*0x1039d9792*/
    ++*((_DWORD *)a1 + 6); /*0x1039d9794*/
  *(_QWORD *)(v4 + 8LL * a3) = a2; /*0x1039d9797*/
  return result; /*0x1039d979b*/
}

// END SplitPacketList part 1/1, 7 functions
