// CCRakNetBase -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 5 functions


// Address: 0x1039ae436 | Name: __ZN6RakNet12CCRakNetBase11OnSendBytesEyPKcib
void __fastcall RakNet::CCRakNetBase::OnSendBytes(RakNet::CCRakNetBase *this, unsigned __int64 a2, const char *a3)
{
  ; /*0x1039ae436*/
}

// Address: 0x1039ae43c | Name: __ZN6RakNet12CCRakNetBase8OnAckEndEjj
void __fastcall RakNet::CCRakNetBase::OnAckEnd(RakNet::CCRakNetBase *this)
{
  ; /*0x1039ae43c*/
}

// Address: 0x1039ae442 | Name: __ZN6RakNet12CCRakNetBase16GetAckTimestampsERyS1_
__int64 __fastcall RakNet::CCRakNetBase::GetAckTimestamps(
        RakNet::CCRakNetBase *this,
        unsigned __int64 *a2,
        unsigned __int64 *a3)
{
  return 0; /*0x1039ae448*/
}

// Address: 0x1039ae47a | Name: __ZN6RakNet12CCRakNetBase25GetCongestionManagerStatsERNS_13CCRakNetStatsE
void RakNet::CCRakNetBase::GetCongestionManagerStats()
{
  ; /*0x1039ae47a*/
}

// Address: 0x1039b199c | Name: __ZNK6RakNet12CCRakNetBase18GetOldestUnsentAckEv
__int64 __fastcall RakNet::CCRakNetBase::GetOldestUnsentAck(RakNet::CCRakNetBase *this)
{
  return 0; /*0x1039b19a2*/
}

// END CCRakNetBase part 1/1, 5 functions
