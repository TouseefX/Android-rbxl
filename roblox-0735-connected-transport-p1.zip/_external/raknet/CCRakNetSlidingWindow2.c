// CCRakNetSlidingWindow2 -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 64 functions


// Address: 0x1039ae7ae | Name: __ZN6RakNet22CCRakNetSlidingWindow2C2Ev
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::CCRakNetSlidingWindow2(RakNet::CCRakNetSlidingWindow2 *this)
{
  *(_QWORD *)this = off_10C902B18; /*0x1039ae7b9*/
  *((_OWORD *)this + 8) = 0; /*0x1039ae7bf*/
  *((_QWORD *)this + 18) = 0; /*0x1039ae7c6*/
  *((_QWORD *)this + 22) = (char *)this + 176; /*0x1039ae7d8*/
  *((_QWORD *)this + 23) = (char *)this + 176; /*0x1039ae7df*/
  *(_OWORD *)((char *)this + 264) = 0; /*0x1039ae7ed*/
  *((_OWORD *)this + 12) = 0; /*0x1039ae7f4*/
  *((_OWORD *)this + 13) = 0; /*0x1039ae7fb*/
  *((_OWORD *)this + 14) = 0; /*0x1039ae802*/
  *((_QWORD *)this + 32) = (char *)this + 264; /*0x1039ae809*/
  *(_OWORD *)((char *)this + 280) = 0; /*0x1039ae810*/
  *(_OWORD *)((char *)this + 296) = 0; /*0x1039ae817*/
  *((_DWORD *)this + 78) = 1065353216; /*0x1039ae81e*/
  *((_QWORD *)this + 31) = (char *)this + 176; /*0x1039ae828*/
  return (__int64)this + 176; /*0x1039ae82f*/
}

// Address: 0x1039ae832 | Name: __ZN6RakNet22CCRakNetSlidingWindow2C1Ev
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::CCRakNetSlidingWindow2(RakNet::CCRakNetSlidingWindow2 *this)
{
  *(_QWORD *)this = off_10C902B18; /*0x1039ae83d*/
  *((_OWORD *)this + 8) = 0; /*0x1039ae843*/
  *((_QWORD *)this + 18) = 0; /*0x1039ae84a*/
  *((_QWORD *)this + 22) = (char *)this + 176; /*0x1039ae85c*/
  *((_QWORD *)this + 23) = (char *)this + 176; /*0x1039ae863*/
  *(_OWORD *)((char *)this + 264) = 0; /*0x1039ae871*/
  *((_OWORD *)this + 12) = 0; /*0x1039ae878*/
  *((_OWORD *)this + 13) = 0; /*0x1039ae87f*/
  *((_OWORD *)this + 14) = 0; /*0x1039ae886*/
  *((_QWORD *)this + 32) = (char *)this + 264; /*0x1039ae88d*/
  *(_OWORD *)((char *)this + 280) = 0; /*0x1039ae894*/
  *(_OWORD *)((char *)this + 296) = 0; /*0x1039ae89b*/
  *((_DWORD *)this + 78) = 1065353216; /*0x1039ae8a2*/
  *((_QWORD *)this + 31) = (char *)this + 176; /*0x1039ae8ac*/
  return (__int64)this + 176; /*0x1039ae8b3*/
}

// Address: 0x1039ae8b6 | Name: __ZN6RakNet22CCRakNetSlidingWindow2D2Ev
void __fastcall RakNet::CCRakNetSlidingWindow2::~CCRakNetSlidingWindow2(RakNet::CCRakNetSlidingWindow2 *this)
{
  void *v2; // rdi

  *(_QWORD *)this = off_10C902B18; /*0x1039ae8c6*/
  std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::~__hash_table(a1: (char *)this + 280); /*0x1039ae8d0*/
  std::__tree<std::__value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__map_value_compare<unsigned int,std::__value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::less<unsigned int>,true>,std::allocator<std::__value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::destroy( /*0x1039ae8e3*/
    a1: (char *)this + 256,
    a2: *((_QWORD *)this + 33));
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::destroy(a1: (void **)this + 25); /*0x1039ae8ef*/
  std::__list_imp<RakNet::PktInfo>::clear(a1: (char *)this + 176); /*0x1039ae8fb*/
  v2 = *((void **)this + 16); /*0x1039ae900*/
  if ( v2 != nullptr ) /*0x1039ae90a*/
  {
    *((_QWORD *)this + 17) = v2; /*0x1039ae90c*/
    operator delete(a1: v2); /*0x1039ae919*/
  }
}

// Address: 0x1039ae926 | Name: __ZN6RakNet22CCRakNetSlidingWindow2D1Ev
void __fastcall RakNet::CCRakNetSlidingWindow2::~CCRakNetSlidingWindow2(RakNet::CCRakNetSlidingWindow2 *this)
{
  RakNet::CCRakNetSlidingWindow2::~CCRakNetSlidingWindow2(this); /*0x1039ae92b*/
}

// Address: 0x1039ae930 | Name: __ZN6RakNet22CCRakNetSlidingWindow2D0Ev
void __fastcall RakNet::CCRakNetSlidingWindow2::~CCRakNetSlidingWindow2(RakNet::CCRakNetSlidingWindow2 *this)
{
  RakNet::CCRakNetSlidingWindow2::~CCRakNetSlidingWindow2(this); /*0x1039ae939*/
  operator delete(a1: this); /*0x1039ae947*/
}

// Address: 0x1039ae94c | Name: __ZN6RakNet22CCRakNetSlidingWindow24InitEyj
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::Init(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned __int64 a2,
        int a3)
{
  __int64 *v4; // r14
  __int64 v5; // rax
  __int64 v6; // rdx
  __int64 result; // rax
  _BYTE v8[160]; // [rsp+0h] [rbp-A0h] BYREF

  *((_QWORD *)this + 2) = 0xBFF0000000000000LL; /*0x1039ae96b*/
  *((_DWORD *)this + 2) = a3; /*0x1039ae96f*/
  *((double *)this + 3) = (double)(32 * a3); /*0x1039ae97a*/
  *((_DWORD *)this + 20) = 0; /*0x1039ae982*/
  *((_DWORD *)this + 17) = 0; /*0x1039ae986*/
  *((_BYTE *)this + 72) = 0; /*0x1039ae98a*/
  *((_OWORD *)this + 2) = 0; /*0x1039ae992*/
  *((_OWORD *)this + 3) = 0; /*0x1039ae997*/
  *((_WORD *)this + 32) = 0; /*0x1039ae99c*/
  *((_DWORD *)this + 109) = DFInt::RakNetUseSlidingWindow2_startInitSpeed; /*0x1039ae9a8*/
  *((_DWORD *)this + 19) = 0; /*0x1039ae9ae*/
  v4 = (__int64 *)((char *)this + 200); /*0x1039ae9b2*/
  *((_OWORD *)this + 20) = 0; /*0x1039ae9b9*/
  *((_OWORD *)this + 21) = 0; /*0x1039ae9c1*/
  *((_OWORD *)this + 22) = 0; /*0x1039ae9c9*/
  *((_OWORD *)this + 23) = 0; /*0x1039ae9d1*/
  *((_OWORD *)this + 24) = 0; /*0x1039ae9d9*/
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::set_capacity( /*0x1039ae9ee*/
    a1: (__int64 *)this + 25,
    a2: DFInt::RakNetUseSlidingWindow2_rangeCount + 1LL);
  v5 = *((_QWORD *)this + 29); /*0x1039ae9f3*/
  if ( v5 != 0 ) /*0x1039ae9fd*/
  {
    v6 = *((_QWORD *)this + 27); /*0x1039aea06*/
    do /*0x1039aea1c*/
    {
      v6 += 128; /*0x1039aea0d*/
      if ( v6 == *((_QWORD *)this + 26) ) /*0x1039aea14*/
        v6 = *v4; /*0x1039aea16*/
      --v5; /*0x1039aea19*/
    }
    while ( v5 != 0 ); /*0x1039aea1c*/
    *((_QWORD *)this + 27) = v6; /*0x1039aea1e*/
  }
  *((_QWORD *)this + 29) = 0; /*0x1039aea25*/
  std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::clear(a1: (char *)this + 280); /*0x1039aea33*/
  std::__list_imp<RakNet::PktInfo>::clear(a1: (char *)this + 176); /*0x1039aea42*/
  *((_QWORD *)this + 31) = (char *)this + 176; /*0x1039aea47*/
  memset(v8, 0, 128); /*0x1039aea7c*/
  boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::resize( /*0x1039aea88*/
    a1: v4,
    a2: 1u,
    a3: (__int64)v8);
  *(_OWORD *)((char *)this + 152) = 0; /*0x1039aea91*/
  *((_DWORD *)this + 42) = -1; /*0x1039aea99*/
  *(_OWORD *)((char *)this + 440) = 0; /*0x1039aeaa3*/
  *((_DWORD *)this + 114) = 0; /*0x1039aeaab*/
  _InterlockedExchange((volatile __int32 *)this + 115, DFInt::RakNetApplicationFeedbackInitialSpeedBPS); /*0x1039aeab8*/
  *((_QWORD *)this + 11) = 0; /*0x1039aeabe*/
  *((_QWORD *)this + 13) = 0; /*0x1039aeac2*/
  *(_OWORD *)((char *)this + 408) = 0; /*0x1039aeac6*/
  result = RakNet::GetTimeUS(this: nullptr); /*0x1039aead0*/
  *((_QWORD *)this + 53) = result; /*0x1039aead5*/
  *((_DWORD *)this + 108) = 0; /*0x1039aeadc*/
  *((_DWORD *)this + 28) = 0; /*0x1039aeae3*/
  *((_QWORD *)this + 50) = 0; /*0x1039aeae7*/
  *(_QWORD *)((char *)this + 116) = 0; /*0x1039aeaee*/
  return result; /*0x1039aeaf2*/
}

// Address: 0x1039aed00 | Name: __ZN6RakNet22CCRakNetSlidingWindow220ResetCCWindowToDFIntEj
void __fastcall RakNet::CCRakNetSlidingWindow2::ResetCCWindowToDFInt(RakNet::CCRakNetSlidingWindow2 *this)
{
  ; /*0x1039aed00*/
}

// Address: 0x1039aed06 | Name: __ZN6RakNet22CCRakNetSlidingWindow26UpdateEy
void __fastcall RakNet::CCRakNetSlidingWindow2::Update(RakNet::CCRakNetSlidingWindow2 *this, __int64 a2)
{
  unsigned __int64 v2; // rcx
  int v3; // r8d

  if ( DFFlag::RakNetCalculateApplicationFeedback2 == 1 ) /*0x1039aed11*/
  {
    if ( *((_QWORD *)this + 53) != 0 ) /*0x1039aed1f*/
    {
      v2 = *((int *)this + 114); /*0x1039aed21*/
      if ( *((_DWORD *)this + 114) != 0 ) /*0x1039aed2b*/
      {
        if ( DFInt::RakNetApplicationFeedbackScaleUpFactorHundredthPercent > 0 /*0x1039aed5c*/
          && a2 * DFInt::RakNetApplicationFeedbackScaleUpThresholdPercent / 0x64uLL >= v2 )
        {
          v3 = v2 * DFInt::RakNetApplicationFeedbackScaleUpFactorHundredthPercent; /*0x1039aed5e*/
          *((_DWORD *)this + 114) = v2 + (int)v2 * DFInt::RakNetApplicationFeedbackScaleUpFactorHundredthPercent / 10000; /*0x1039aed7b*/
          LODWORD(v2) = v2 + v3 / 10000; /*0x1039aed81*/
        }
      }
      else
      {
        LODWORD(v2) = *((_DWORD *)this + 109); /*0x1039aed93*/
      }
    }
    else
    {
      LODWORD(v2) = *((_DWORD *)this + 109); /*0x1039aed85*/
      *((_DWORD *)this + 114) = v2; /*0x1039aed8b*/
    }
    if ( DFInt::RakNetApplicationFeedbackMaxSpeedBPS > 0 ) /*0x1039aeda1*/
    {
      if ( DFInt::RakNetApplicationFeedbackMaxSpeedBPS < (int)v2 ) /*0x1039aeda5*/
        LODWORD(v2) = DFInt::RakNetApplicationFeedbackMaxSpeedBPS; /*0x1039aeda5*/
      _InterlockedExchange((volatile __int32 *)this + 115, v2); /*0x1039aeda8*/
    }
  }
}

// Address: 0x1039aedb0 | Name: __ZN6RakNet22CCRakNetSlidingWindow226GetRetransmissionBandwidthEyyjbRNS_15TxBwInfluencersE
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::GetRetransmissionBandwidth(__int64 a1)
{
  return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 56LL))(a1);
}

// Address: 0x1039aedbe | Name: __ZN6RakNet22CCRakNetSlidingWindow224GetTransmissionBandwidthEyyjbRNS_15TxBwInfluencersE
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::GetTransmissionBandwidth(
        RakNet::CCRakNetSlidingWindow2 *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        char a5,
        _DWORD *a6)
{
  __int64 v9; // rdx
  __int64 v10; // rax
  int v11; // eax
  int v12; // ecx
  int v13; // eax
  __int64 RttMicroMin; // r12
  int v15; // eax
  int v16; // r13d
  __int64 v17; // rax
  __int64 v18; // rcx
  __int64 v19; // rax
  int v20; // eax
  int v21; // esi
  int v22; // r8d
  int v23; // r10d
  __int64 v24; // r9
  __int64 v25; // rdx
  __int64 v26; // rdx
  __int64 v27; // rdx
  int v28; // r11d
  __int64 v29; // rdx
  __int64 v30; // rax
  __int64 v31; // rdx
  __int64 v32; // rax
  __int64 v33; // rax
  int v34; // edx
  int v35; // r10d
  int v36; // edx
  int v37; // r13d
  int v38; // r10d
  __int64 v39; // rdi
  __int64 v40; // rcx
  __int64 v41; // rdx
  bool v42; // cc
  __int64 v43; // rcx
  int v44; // r10d
  __int64 v45; // rsi
  __int64 v46; // rdi
  int v47; // edx
  __int64 v49; // rax
  int v50; // [rsp+10h] [rbp-30h]
  int v51; // [rsp+14h] [rbp-2Ch]

  *((_BYTE *)this + 72) = a5; /*0x1039aedd8*/
  v9 = 10; /*0x1039aedf2*/
  if ( DFInt::RakNetLoopMs >= 11 ) /*0x1039aedf7*/
    v9 = (unsigned int)DFInt::RakNetLoopMs; /*0x1039aedf7*/
  if ( a2 - *((_QWORD *)this + 52) > (unsigned __int64)(2000 * v9) ) /*0x1039aee04*/
    goto LABEL_4; /*0x1039aee04*/
  v11 = *((_DWORD *)this + 102); /*0x1039aee3e*/
  if ( v11 <= 0 ) /*0x1039aee46*/
    goto LABEL_13; /*0x1039aee46*/
  v12 = *((_DWORD *)this + 103); /*0x1039aee48*/
  if ( v12 != 0 && *((_DWORD *)this + 2) + v12 >= v11 ) /*0x1039aee57*/
  {
    v13 = *((_DWORD *)this + 108); /*0x1039aee59*/
    *((_DWORD *)this + 108) = v13 + 1; /*0x1039aee62*/
    if ( *((_QWORD *)this + 53) != 0 && v13 >= 2 ) /*0x1039aee76*/
      *((_QWORD *)this + 53) = 0; /*0x1039aee7f*/
  }
  else
  {
LABEL_4:
    *((_DWORD *)this + 108) = 0; /*0x1039aee06*/
    if ( *((_QWORD *)this + 53) == 0 ) /*0x1039aee18*/
    {
      *((_QWORD *)this + 53) = a2; /*0x1039aee1a*/
      v10 = *((_QWORD *)this + 28); /*0x1039aee21*/
      if ( v10 == *((_QWORD *)this + 25) ) /*0x1039aee2f*/
        v10 = *((_QWORD *)this + 26); /*0x1039aee31*/
      *(_BYTE *)(v10 - 4) = 1; /*0x1039aee38*/
    }
  }
LABEL_13:
  *((_QWORD *)this + 52) = a2; /*0x1039aee8a*/
  *((_QWORD *)this + 51) = 0; /*0x1039aee91*/
  RttMicroMin = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this); /*0x1039aeea4*/
  v15 = *((_DWORD *)this + 19); /*0x1039aeea7*/
  v50 = *((_DWORD *)this + 83); /*0x1039aeeb0*/
  v16 = *((_DWORD *)this + 89); /*0x1039aeeb3*/
  v51 = *((_DWORD *)this + 91); /*0x1039aeec0*/
  if ( v15 == 1 ) /*0x1039aeec6*/
  {
    if ( (unsigned int)RakNet::CCRakNetSlidingWindow2::calculateDrainSpeed(this, a2: -1) == -1 ) /*0x1039aeee9*/
      RakNet::CCRakNetSlidingWindow2::setCurrentState(this); /*0x1039aeef8*/
  }
  else if ( v15 != 0 ) /*0x1039aeeca*/
  {
    RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this, a2: *((_DWORD *)this + 109)); /*0x1039aef08*/
  }
  else
  {
    RakNet::CCRakNetSlidingWindow2::updateStartTargetSpeed(this, a2); /*0x1039aeed2*/
  }
  v17 = *((_QWORD *)this + 55); /*0x1039aef0d*/
  if ( v17 != 0 ) /*0x1039aef21*/
  {
    v18 = (a2 - v17) * *((int *)this + 109) / 1000000 - *((_QWORD *)this + 56); /*0x1039aef48*/
    v19 = 3; /*0x1039aef4f*/
  }
  else
  {
    v18 = *((int *)this + 2) - 12LL; /*0x1039aef5a*/
    v19 = 2; /*0x1039aef5e*/
  }
  ++a6[v19]; /*0x1039aef63*/
  ++*a6; /*0x1039aef67*/
  v20 = 0; /*0x1039aef6a*/
  if ( v18 > 0 ) /*0x1039aef6f*/
    v20 = v18; /*0x1039aef6f*/
  a6[4] += v20; /*0x1039aef73*/
  if ( *((_QWORD *)this + 53) != 0 ) /*0x1039aef7f*/
    ++a6[1]; /*0x1039aef81*/
  v21 = *((_DWORD *)this + 82) - (*((_DWORD *)this + 90) + *((_DWORD *)this + 88)); /*0x1039aef97*/
  v22 = FInt::RakNetResendBufferArrayLength; /*0x1039aefa0*/
  v23 = 100 * v21; /*0x1039aefa3*/
  if ( 100 * v21 < 80 * FInt::RakNetResendBufferArrayLength ) /*0x1039aefb3*/
  {
    v24 = *((int *)this + 109); /*0x1039aefb5*/
    v25 = 2; /*0x1039aefc8*/
    if ( DFInt::RakNetLoopMs >= 3 ) /*0x1039aefcd*/
      v25 = (unsigned int)DFInt::RakNetLoopMs; /*0x1039aefcd*/
    v26 = (unsigned __int128)(0x431BDE82D7B634DBLL * (__int128)(2000 * v24 * v25)) >> 64; /*0x1039aefdb*/
    v27 = ((unsigned __int64)v26 >> 63) + (v26 >> 18); /*0x1039aefe9*/
    a6[5] += v27; /*0x1039aefec*/
    if ( v18 <= v27 ) /*0x1039aeff3*/
      goto LABEL_39; /*0x1039aeff3*/
    goto LABEL_37; /*0x1039aeff3*/
  }
  v28 = 95 * FInt::RakNetResendBufferArrayLength; /*0x1039af008*/
  v29 = 1000; /*0x1039af014*/
  if ( v23 < 95 * FInt::RakNetResendBufferArrayLength ) /*0x1039af019*/
    v29 = 2000; /*0x1039af019*/
  v24 = *((int *)this + 109); /*0x1039af01d*/
  v30 = 1; /*0x1039af030*/
  if ( DFInt::RakNetLoopMs >= 2 ) /*0x1039af035*/
    v30 = (unsigned int)DFInt::RakNetLoopMs; /*0x1039af035*/
  v31 = (unsigned __int128)(0x431BDE82D7B634DBLL * (__int128)(v29 * v24 * v30)) >> 64; /*0x1039af040*/
  v27 = ((unsigned __int64)v31 >> 63) + (v31 >> 18); /*0x1039af04e*/
  a6[5] += v27; /*0x1039af054*/
  if ( v18 > v27 ) /*0x1039af05b*/
  {
    v32 = 6; /*0x1039af05d*/
    if ( v23 >= v28 ) /*0x1039af079*/
    {
LABEL_38:
      ++a6[v32]; /*0x1039af080*/
      v18 = v27; /*0x1039af084*/
      goto LABEL_39; /*0x1039af084*/
    }
LABEL_37:
    v32 = 7; /*0x1039af07b*/
    goto LABEL_38; /*0x1039af07b*/
  }
LABEL_39:
  if ( v18 <= 0 ) /*0x1039af0a3*/
  {
    v35 = *((_DWORD *)this + 2); /*0x1039af0d7*/
  }
  else
  {
    v33 = RttMicroMin + DFInt::RakNetUseSlidingWindow2_minRtt / 2; /*0x1039af0b7*/
    v34 = *((_DWORD *)this + 19); /*0x1039af0ba*/
    if ( (unsigned int)(v34 - 4) >= 2 ) /*0x1039af0c3*/
    {
      if ( v34 == 0 ) /*0x1039af0df*/
        v33 *= 2; /*0x1039af0e1*/
    }
    else
    {
      v33 += v33 / 2; /*0x1039af0d2*/
    }
    v35 = *((_DWORD *)this + 2); /*0x1039af0e4*/
    v36 = (int)v24 * v33 / 1000000; /*0x1039af102*/
    if ( 2 * v35 - 24 > v36 ) /*0x1039af106*/
      v36 = 2 * v35 - 24; /*0x1039af106*/
    v37 = v36 + v51 + v16 - v50; /*0x1039af111*/
    if ( v18 > v37 ) /*0x1039af11a*/
    {
      ++a6[8]; /*0x1039af11c*/
      v18 = v37; /*0x1039af120*/
    }
  }
  v38 = v35 - 12; /*0x1039af123*/
  v39 = v38; /*0x1039af127*/
  v40 = v38 + v18 - 1; /*0x1039af12d*/
  v41 = v40 % v38; /*0x1039af135*/
  v42 = v40 <= v41; /*0x1039af138*/
  v43 = v40 - v41; /*0x1039af138*/
  if ( !v42 ) /*0x1039af13b*/
  {
    v44 = (v22 - v21) * v38; /*0x1039af140*/
    if ( v43 > v44 ) /*0x1039af14a*/
    {
      ++a6[9]; /*0x1039af14c*/
      v43 = v44; /*0x1039af150*/
    }
  }
  v45 = 2000000 * v39 / (int)v24; /*0x1039af166*/
  if ( DFInt::RakNetUseSlidingWindow2_minRtt > (int)v45 ) /*0x1039af16c*/
    LODWORD(v45) = DFInt::RakNetUseSlidingWindow2_minRtt; /*0x1039af16c*/
  v46 = 80; /*0x1039af179*/
  if ( *((_DWORD *)this + 19) == 1 ) /*0x1039af17e*/
    v46 = 120; /*0x1039af17e*/
  v47 = RttMicroMin * v46 / 100; /*0x1039af1a4*/
  if ( (int)v45 > v47 ) /*0x1039af1a8*/
    v47 = v45; /*0x1039af1a8*/
  if ( v47 >= 1000000 ) /*0x1039af1b2*/
    v47 = 1000000; /*0x1039af1b2*/
  if ( v43 <= 0 ) /*0x1039af1b8*/
  {
    v49 = *((_QWORD *)this + 50); /*0x1039af1d1*/
    if ( v49 != 0 && a2 - v49 > v47 ) /*0x1039af1e6*/
    {
      ++a6[10]; /*0x1039af1e8*/
      LODWORD(v43) = 1; /*0x1039af1ec*/
    }
  }
  *((_DWORD *)this + 102) = v43; /*0x1039af1ba*/
  return (unsigned int)v43; /*0x1039af1c2*/
}

// Address: 0x1039af1f4 | Name: __ZNK6RakNet22CCRakNetSlidingWindow214getRttMicroMinEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::getRttMicroMin(RakNet::CCRakNetSlidingWindow2 *this)
{
  unsigned int v1; // eax
  unsigned __int64 v2; // rcx
  unsigned __int64 v3; // r9
  __int64 v4; // rdx
  __int64 result; // rax
  __int64 v6; // rsi
  __int64 v7; // r9
  __int64 v8; // r10
  __int64 v9; // r10
  __int64 v10; // r11
  __int64 v11; // r10

  v1 = *((_DWORD *)this + 30); /*0x1039af1f4*/
  v2 = 12; /*0x1039af1f9*/
  if ( v1 != 0 ) /*0x1039af1fe*/
    v2 = v1; /*0x1039af1fe*/
  v3 = *((_QWORD *)this + 29); /*0x1039af201*/
  v4 = 0; /*0x1039af208*/
  if ( v3 >= v2 ) /*0x1039af210*/
    v4 = v3 - v2; /*0x1039af210*/
  result = -1; /*0x1039af214*/
  if ( v4 < v3 ) /*0x1039af21e*/
  {
    v6 = *((_QWORD *)this + 27); /*0x1039af232*/
    if ( v3 < v2 ) /*0x1039af246*/
      v2 = *((_QWORD *)this + 29); /*0x1039af246*/
    v7 = 0; /*0x1039af24a*/
    do /*0x1039af2ac*/
    {
      v8 = v4; /*0x1039af24d*/
      if ( (*((_QWORD *)this + 26) - v6) >> 7 <= v4 ) /*0x1039af253*/
        v8 = v4 - ((__int64)(*((_QWORD *)this + 26) - *((_QWORD *)this + 25)) >> 7); /*0x1039af266*/
      v9 = v8 << 7; /*0x1039af269*/
      v10 = *(_QWORD *)(v6 + v9 + 48); /*0x1039af26d*/
      if ( v10 != 0 /*0x1039af2a1*/
        && (v10 < v7 || v7 == 0)
        && (v2 != 1 || *(int *)((v11 = v6 + v9) + 8) > 4 || *(_DWORD *)(v11 + 96) >= *((_DWORD *)this + 2)) )
      {
        v7 = v10; /*0x1039af2a3*/
      }
      ++v4; /*0x1039af2a6*/
      --v2; /*0x1039af2a9*/
    }
    while ( v2 != 0 ); /*0x1039af2ac*/
    result = -1; /*0x1039af2b1*/
    if ( v7 > 0 ) /*0x1039af2b8*/
      return v7; /*0x1039af2b8*/
  }
  return result; /*0x1039af2c0*/
}

// Address: 0x1039af2c2 | Name: __ZN6RakNet22CCRakNetSlidingWindow222updateStartTargetSpeedEx
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::updateStartTargetSpeed(
        RakNet::CCRakNetSlidingWindow2 *this,
        __int64 a2)
{
  __int64 v3; // rcx
  __int64 result; // rax
  int v5; // eax
  unsigned __int64 v6; // r12
  unsigned __int64 v7; // rcx
  __int64 v8; // rdx
  __int64 v9; // rdi
  unsigned __int64 v10; // rdi
  __int64 v11; // rdx
  __int64 v12; // rax
  __int64 v13; // rsi
  __int64 v14; // rdi
  __int64 v15; // r12
  double v16; // xmm0_8
  int SpeedLimit; // eax
  double v18; // xmm1_8
  long double v19; // [rsp+0h] [rbp-30h]
  double v20; // [rsp+8h] [rbp-28h]
  double v21; // [rsp+8h] [rbp-28h]

  v3 = *((_QWORD *)this + 55); /*0x1039af2d7*/
  if ( v3 == 0 /*0x1039af313*/
    || (result = v3
               + (1000000 * (*((_QWORD *)this + 56) + *((int *)this + 2)) - 12000000LL) / *((int *)this + 109)
               + 20000) < a2 )
  {
    result = (__int64)this + 440; /*0x1039af315*/
    *((_QWORD *)this + 11) = 0; /*0x1039af31c*/
    *(_OWORD *)((char *)this + 440) = 0; /*0x1039af327*/
  }
  if ( *((_QWORD *)this + 53) != 0 ) /*0x1039af332*/
  {
    *((_QWORD *)this + 11) = 0; /*0x1039af334*/
  }
  else if ( *((_QWORD *)this + 11) != 0 ) /*0x1039af350*/
  {
    v5 = DFInt::RakNetUseSlidingWindow2_startUpdateMs; /*0x1039af356*/
    v6 = *((_QWORD *)this + 29); /*0x1039af35c*/
    if ( v6 >= 2 ) /*0x1039af367*/
    {
      v7 = v6 - 2; /*0x1039af369*/
      v8 = *((_QWORD *)this + 27); /*0x1039af375*/
      if ( (*((_QWORD *)this + 26) - v8) >> 7 <= (__int64)(v6 - 2) ) /*0x1039af389*/
        v7 -= (__int64)(*((_QWORD *)this + 26) - *((_QWORD *)this + 25)) >> 7; /*0x1039af396*/
      if ( *(_QWORD *)(v8 + (v7 << 7) + 48) < 2LL * DFInt::RakNetUseSlidingWindow2_minRtt ) /*0x1039af3ac*/
        v5 = DFInt::RakNetUseSlidingWindow2_startUpdateMs / 2; /*0x1039af3b7*/
    }
    result = 1000LL * v5; /*0x1039af3c2*/
    if ( a2 - *((_QWORD *)this + 13) >= result ) /*0x1039af3cc*/
    {
      *((_QWORD *)this + 13) = a2; /*0x1039af3d2*/
      RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this); /*0x1039af3d9*/
      if ( v6 >= 3 ) /*0x1039af405*/
      {
        v10 = v6 - 2; /*0x1039af407*/
        v11 = *((_QWORD *)this + 26); /*0x1039af40c*/
        v12 = *((_QWORD *)this + 27); /*0x1039af413*/
        v13 = (v11 - v12) >> 7; /*0x1039af420*/
        if ( v13 <= (__int64)(v6 - 2) ) /*0x1039af427*/
          v10 -= (v11 - *((_QWORD *)this + 25)) >> 7; /*0x1039af437*/
        v14 = *(_QWORD *)(v12 + (v10 << 7) + 88); /*0x1039af43e*/
        v15 = v6 - 3; /*0x1039af443*/
        if ( v13 <= v15 ) /*0x1039af44a*/
          v15 -= (v11 - *((_QWORD *)this + 25)) >> 7; /*0x1039af457*/
        v9 = v14 - *(_QWORD *)(v12 + (v15 << 7) + 88); /*0x1039af45e*/
      }
      *((double *)&v19 + 1) = (double)*((int *)this + 24); /*0x1039af486*/
      pow(__x: v19, __n: v9); /*0x1039af49e*/
      v21 = v16 * v20; /*0x1039af4a8*/
      SpeedLimit = RakNet::CCRakNetSlidingWindow2::getSpeedLimit(this); /*0x1039af4b0*/
      if ( SpeedLimit == -1 ) /*0x1039af4b8*/
      {
        v18 = v21; /*0x1039af4e8*/
      }
      else
      {
        v18 = v21; /*0x1039af4c1*/
        if ( v21 > (double)SpeedLimit ) /*0x1039af4ca*/
          v18 = (double)SpeedLimit; /*0x1039af4cc*/
      }
      return RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this, a2: (int)v18); /*0x1039af500*/
    }
  }
  else
  {
    *((_QWORD *)this + 11) = a2; /*0x1039af4d2*/
    *((_QWORD *)this + 13) = a2; /*0x1039af4d6*/
    result = *((unsigned int *)this + 109); /*0x1039af4da*/
    *((_DWORD *)this + 24) = result; /*0x1039af4e0*/
  }
  return result; /*0x1039af33c*/
}

// Address: 0x1039af510 | Name: __ZN6RakNet22CCRakNetSlidingWindow219calculateDrainSpeedEi
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::calculateDrainSpeed(RakNet::CCRakNetSlidingWindow2 *this, int a2)
{
  unsigned int v2; // r15d
  int v3; // ebx
  __int64 RttMicroMin; // rcx
  int v6; // edx
  int v7; // edi
  int v8; // eax
  int v9; // eax
  __int64 v10; // rax
  unsigned __int64 v11; // rcx
  __int64 v12; // rcx
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // rdx

  v2 = -1; /*0x1039af52e*/
  if ( *((_DWORD *)this + 82) - (*((_DWORD *)this + 90) + *((_DWORD *)this + 88)) >= 3 )
  {
    v3 = a2; /*0x1039af53d*/
    if ( a2 == -1 ) /*0x1039af545*/
      v3 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1039af54f*/
    RttMicroMin = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this); /*0x1039af559*/
    v6 = v3 * RttMicroMin / 1000000; /*0x1039af58d*/
    v7 = *((_DWORD *)this + 83) - (v6 + *((_DWORD *)this + 91) + *((_DWORD *)this + 89)); /*0x1039af599*/
    if ( v7 >= *((_DWORD *)this + 2) + 58 )
    {
      v8 = *((_DWORD *)this + 19); /*0x1039af5a8*/
      if ( (unsigned int)(v8 - 4) >= 2 )
        v9 = v8 == 1 ? v6 / 16 : v6 / 4;
      else
        v9 = v6 / 2; /*0x1039af5bd*/
      if ( v7 > v9 ) /*0x1039af5e0*/
      {
        v10 = RttMicroMin + RttMicroMin / 8; /*0x1039af5f5*/
        v11 = *((_QWORD *)this + 29); /*0x1039af5f8*/
        if ( v11 >= 2 ) /*0x1039af603*/
        {
          v12 = v11 - 1; /*0x1039af605*/
          v13 = *((_QWORD *)this + 27); /*0x1039af60f*/
          if ( (*((_QWORD *)this + 26) - v13) >> 7 <= v12 ) /*0x1039af623*/
            v12 -= (*((_QWORD *)this + 26) - *((_QWORD *)this + 25)) >> 7; /*0x1039af630*/
          v14 = *(_QWORD *)(v13 + (v12 << 7) + 48); /*0x1039af637*/
          if ( v10 < v14 ) /*0x1039af63f*/
            v10 = v14; /*0x1039af641*/
        }
        v15 = v3 * v10 / 1000000; /*0x1039af656*/
        if ( v7 <= 3 * (int)v15 / 2 ) /*0x1039af667*/
        {
          if ( v7 >= 3 * (int)v15 / 4 ) /*0x1039af686*/
            return (unsigned int)(v3 / 4); /*0x1039af6a8*/
          else
            return v3 - (unsigned int)(v3 * (__int64)v7 / (int)v15); /*0x1039af699*/
        }
        else
        {
          return (unsigned int)(v3 / 8); /*0x1039af673*/
        }
      }
    }
  }
  return v2; /*0x1039af6b3*/
}

// Address: 0x1039af6ba | Name: __ZN6RakNet22CCRakNetSlidingWindow215setCurrentStateENS0_14OperationStateEi
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::setCurrentState(
        RakNet::CCRakNetSlidingWindow2 *this,
        int a2,
        int a3)
{
  __int64 result; // rax
  int v4; // r12d
  int v5; // r15d
  int v6; // r14d
  int v8; // eax
  int v9; // ecx
  int v10; // r15d

  v4 = *((_DWORD *)this + 19); /*0x1039af6c5*/
  if ( v4 != a2 ) /*0x1039af6cc*/
  {
    v5 = a3; /*0x1039af6d7*/
    v6 = a2; /*0x1039af6da*/
    if ( a3 == -1 ) /*0x1039af6e3*/
    {
      v5 = -1; /*0x1039af778*/
      switch ( a2 ) /*0x1039af799*/
      {
        case 0: /*0x1039af799*/
        case 3: /*0x1039af799*/
          v5 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1039af7a3*/
          break; /*0x1039af7a6*/
        case 4: /*0x1039af799*/
          v9 = 5 * RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1039af7c8*/
          v10 = v9 + 3; /*0x1039af7cf*/
          goto LABEL_19; /*0x1039af7cf*/
        case 5: /*0x1039af799*/
          v9 = 3 * RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1039af7b3*/
          v10 = v9 + 3; /*0x1039af7ba*/
LABEL_19:
          if ( v9 >= 0 ) /*0x1039af7d5*/
            v10 = v9; /*0x1039af7d5*/
          v5 = v10 >> 2; /*0x1039af7d9*/
          break; /*0x1039af7dd*/
        default:
          break;
      }
    }
    if ( v6 == 1 || (v4 | v6 ^ 3) == 0 ) /*0x1039af6fd*/
    {
      v8 = RakNet::CCRakNetSlidingWindow2::calculateDrainSpeed(this, a2: v5); /*0x1039af705*/
      if ( v8 != -1 ) /*0x1039af712*/
        v5 = v8; /*0x1039af712*/
      v6 = 2 * (v8 == -1) + 1; /*0x1039af716*/
    }
    if ( v5 == -1 ) /*0x1039af722*/
      v5 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this); /*0x1039af72c*/
    if ( v4 == v6 || v6 != 3 ) /*0x1039af739*/
    {
      if ( v4 != v6 && v6 == 0 ) /*0x1039af752*/
        *((_QWORD *)this + 11) = 0; /*0x1039af759*/
    }
    else
    {
      *((_DWORD *)this + 20) = 0; /*0x1039af740*/
    }
    *((_DWORD *)this + 19) = v6; /*0x1039af761*/
    return RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this, a2: v5); /*0x1039af773*/
  }
  return result; /*0x1039af6ce*/
}

// Address: 0x1039af7fc | Name: __ZN6RakNet22CCRakNetSlidingWindow214setTargetSpeedEi
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::setTargetSpeed(RakNet::CCRakNetSlidingWindow2 *this, int a2)
{
  int SpeedLimit; // eax
  int v5; // r15d
  __int64 result; // rax
  unsigned int v7; // r15d
  __int64 TimeUS; // rcx
  __int64 v9; // r9
  __int64 v10; // rdi
  __int64 v11; // rsi

  SpeedLimit = RakNet::CCRakNetSlidingWindow2::getSpeedLimit(this); /*0x1039af80c*/
  v5 = a2; /*0x1039af814*/
  if ( SpeedLimit < a2 ) /*0x1039af817*/
    v5 = SpeedLimit; /*0x1039af817*/
  if ( SpeedLimit == -1 ) /*0x1039af81e*/
    v5 = a2; /*0x1039af81e*/
  result = (unsigned int)DFInt::RakNetUseSlidingWindow2_minSpeed; /*0x1039af822*/
  if ( v5 <= DFInt::RakNetUseSlidingWindow2_minSpeed ) /*0x1039af82b*/
    v5 = DFInt::RakNetUseSlidingWindow2_minSpeed; /*0x1039af82b*/
  v7 = v5 & 0xFFFFFF00; /*0x1039af82f*/
  if ( v7 != *((_DWORD *)this + 109) ) /*0x1039af83d*/
  {
    if ( *((_QWORD *)this + 55) != 0 ) /*0x1039af84b*/
    {
      TimeUS = RakNet::GetTimeUS(this: nullptr); /*0x1039af858*/
      v9 = *((_QWORD *)this + 55); /*0x1039af862*/
      v10 = *((_QWORD *)this + 56); /*0x1039af869*/
      v11 = *((int *)this + 109) * (TimeUS - v9) / 1000000; /*0x1039af892*/
      result = v9 + 1000000 * v10 / *((int *)this + 109); /*0x1039af8a1*/
      if ( result >= TimeUS - 20000 || (result = v10 + 2 * *((_DWORD *)this + 2) + 116) >= v11 ) /*0x1039af8c2*/
      {
        *((_QWORD *)this + 55) = TimeUS; /*0x1039af8d3*/
        *((_QWORD *)this + 56) = v10 - v11; /*0x1039af8dd*/
      }
      else
      {
        result = (__int64)this + 440; /*0x1039af8c4*/
        *(_OWORD *)((char *)this + 440) = 0; /*0x1039af8ce*/
      }
    }
    *((_DWORD *)this + 109) = v7; /*0x1039af8e4*/
  }
  return result; /*0x1039af8ef*/
}

// Address: 0x1039af8f6 | Name: __ZNK6RakNet22CCRakNetSlidingWindow23uszEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::usz(RakNet::CCRakNetSlidingWindow2 *this)
{
  return (unsigned int)(*((_DWORD *)this + 2) - 12); /*0x1039af900*/
}

// Address: 0x1039af902 | Name: __ZN6RakNet22CCRakNetSlidingWindow249GetAvailableTransmissionCapacityBytesWithinWindowEffyy
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::GetAvailableTransmissionCapacityBytesWithinWindow(
        RakNet::CCRakNetSlidingWindow2 *this,
        float a2,
        float a3,
        int a4)
{
  int v4; // ecx
  int v5; // edx
  __int64 result; // rax

  v4 = (int)(float)((float)((float)*((int *)this + 115) * a2) / 1000.0); /*0x1039af91c*/
  v5 = (int)(float)((float)a4 * a3); /*0x1039af92b*/
  result = (unsigned int)(v4 - v5); /*0x1039af931*/
  if ( v4 - v5 <= 0 ) /*0x1039af937*/
    result = 0; /*0x1039af937*/
  if ( v4 < v5 ) /*0x1039af93c*/
    return 0; /*0x1039af93c*/
  return result; /*0x1039af93f*/
}

// Address: 0x1039af942 | Name: __ZN6RakNet22CCRakNetSlidingWindow214ShouldSendACKsEyy
bool __fastcall RakNet::CCRakNetSlidingWindow2::ShouldSendACKs(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned __int64 a2)
{
  bool result; // al

  result = true; /*0x1039af953*/
  if ( *((double *)this + 2) != -1.0 ) /*0x1039af955*/
    return *((_QWORD *)this + 5) + 10000LL <= a2; /*0x1039af992*/
  return result; /*0x1039af995*/
}

// Address: 0x1039af998 | Name: __ZNK6RakNet22CCRakNetSlidingWindow218GetSenderRTOForACKEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::GetSenderRTOForACK(RakNet::CCRakNetSlidingWindow2 *this)
{
  double v1; // xmm0_8
  __int64 result; // rax

  v1 = *((double *)this + 2); /*0x1039af99c*/
  result = -1; /*0x1039af9d4*/
  if ( v1 != -1.0 ) /*0x1039af9db*/
    return (unsigned int)(int)(v1 + 10000.0); /*0x1039af9db*/
  return result; /*0x1039af9e3*/
}

// Address: 0x1039af9e6 | Name: __ZN6RakNet22CCRakNetSlidingWindow229GetNextDatagramSequenceNumberEv
RakNet::CCRakNetSlidingWindow2 *__fastcall RakNet::CCRakNetSlidingWindow2::GetNextDatagramSequenceNumber(
        RakNet::CCRakNetSlidingWindow2 *this,
        __int64 a2)
{
  *(_DWORD *)this = *(_DWORD *)(a2 + 56); /*0x1039af9f0*/
  return this; /*0x1039af9f2*/
}

// Address: 0x1039af9f4 | Name: __ZN6RakNet22CCRakNetSlidingWindow241GetAndIncrementNextDatagramSequenceNumberEv
RakNet::CCRakNetSlidingWindow2 *__fastcall RakNet::CCRakNetSlidingWindow2::GetAndIncrementNextDatagramSequenceNumber(
        RakNet::CCRakNetSlidingWindow2 *this,
        __int64 a2)
{
  int v3; // ecx

  v3 = *(_DWORD *)(a2 + 56); /*0x1039af9fb*/
  *(_DWORD *)this = v3; /*0x1039af9fe*/
  *(_DWORD *)(a2 + 56) = (v3 + 1) & 0xFFFFFF; /*0x1039afa08*/
  return this; /*0x1039afa0b*/
}

// Address: 0x1039afa0e | Name: __ZN6RakNet22CCRakNetSlidingWindow211OnSendBytesEyj
void __fastcall RakNet::CCRakNetSlidingWindow2::OnSendBytes(RakNet::CCRakNetSlidingWindow2 *this)
{
  ; /*0x1039afa0e*/
}

// Address: 0x1039afa14 | Name: __ZN6RakNet22CCRakNetSlidingWindow211OnSendBytesEyPKcib
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::OnSendBytes(
        RakNet::CCRakNetSlidingWindow2 *this,
        __int64 a2,
        char *a3,
        int a4,
        int a5)
{
  int v7; // r14d
  unsigned int v8; // edi
  unsigned int v9; // eax
  bool v10; // si
  unsigned int v11; // r8d
  unsigned __int8 v12; // di
  unsigned int v13; // r9d
  char v14; // r8
  unsigned int v15; // esi
  __int64 v16; // rsi
  __int64 v17; // rdi
  int v18; // ecx
  unsigned __int8 *v19; // rsi
  int v20; // edx
  unsigned __int8 *v21; // r8
  int v22; // esi
  int v23; // edi
  RakNet::BitStream *v25; // rdi
  _BYTE v26[12]; // [rsp+8h] [rbp-148h] BYREF
  unsigned int v27; // [rsp+14h] [rbp-13Ch]
  unsigned int v28; // [rsp+1Ch] [rbp-134h]
  __int64 v29; // [rsp+20h] [rbp-130h]

  v7 = a4 + 18; /*0x1039afa38*/
  if ( a5 == 0 ) /*0x1039afa3f*/
    v7 = a4; /*0x1039afa3f*/
  if ( a4 < 5 ) /*0x1039afa46*/
    goto LABEL_20; /*0x1039afa46*/
  RakNet::BitStream::BitStream(this: (RakNet::BitStream *)v26, a2: (unsigned __int8 *)a3, a3: 4u, a4: false); /*0x1039afa5d*/
  v8 = v28; /*0x1039afa68*/
  v9 = v28 + 1; /*0x1039afa6e*/
  v10 = true; /*0x1039afa71*/
  if ( v28 + 1 <= v27 ) /*0x1039afa76*/
  {
    v10 = ((*(unsigned __int8 *)(v29 + (v28 >> 3)) << (v28 & 7)) & 0x80u) == 0; /*0x1039afa99*/
    ++v28; /*0x1039afa9d*/
    v11 = v8 + 2; /*0x1039afaa6*/
  }
  else
  {
    v11 = v28 + 1; /*0x1039afa78*/
    v9 = v28; /*0x1039afa7b*/
  }
  if ( v11 <= v27 ) /*0x1039afaac*/
  {
    v12 = (unsigned __int8)(*(unsigned __int8 *)(v29 + (v9 >> 3)) << (v9 & 7)) >> 7; /*0x1039afacb*/
    v28 = v11; /*0x1039afacf*/
    v13 = v11 + 1; /*0x1039afad6*/
    v9 = v11; /*0x1039afada*/
  }
  else
  {
    v12 = 0; /*0x1039afaae*/
    v13 = v11; /*0x1039afab0*/
  }
  if ( v13 <= v27 ) /*0x1039afae0*/
  {
    v14 = (unsigned __int8)(*(unsigned __int8 *)(v29 + (v9 >> 3)) << (v9 & 7)) >> 7; /*0x1039afb01*/
    v28 = v13; /*0x1039afb05*/
    v9 = v13; /*0x1039afb0c*/
  }
  else
  {
    v14 = 0; /*0x1039afae2*/
  }
  if ( ((v12 | v10) & 1) != 0 || v14 != 0 ) /*0x1039afb1b*/
  {
    RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v26); /*0x1039afb95*/
LABEL_20:
    RakNet::CCRakNetSlidingWindow2::addPkt(this, a2: 0xFFFFFFFF, a3: v7, a4: a2); /*0x1039afb9a*/
    return __stack_chk_guard; /*0x1039afbad*/
  }
  v28 = (-(v9 + (-v9 & 7)) & 7) + v9 + (-v9 & 7); /*0x1039afb30*/
  v15 = 0; /*0x1039afb3b*/
  if ( v28 + 24 <= v27 ) /*0x1039afb3f*/
  {
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039afc1c*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v25); /*0x1039afc27*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039afc34*/
    }
    v16 = v28 >> 3; /*0x1039afb62*/
    v17 = v29 + v16 + 1; /*0x1039afb69*/
    v18 = *(unsigned __int8 *)(v29 + v16); /*0x1039afb6c*/
    v19 = (unsigned __int8 *)(v29 + v16 + 2); /*0x1039afb73*/
    v20 = 0; /*0x1039afb77*/
    if ( RakNet::BitStream::IsNetworkOrder(void)::r == 1 ) /*0x1039afb80*/
    {
      v20 = v18 << 24; /*0x1039afb85*/
      v21 = (unsigned __int8 *)v17; /*0x1039afb87*/
      v18 = 0; /*0x1039afb8a*/
    }
    else
    {
      v21 = v19; /*0x1039afbaf*/
      v19 = (unsigned __int8 *)v17; /*0x1039afbb2*/
    }
    v22 = *v19; /*0x1039afbb5*/
    v23 = *v21; /*0x1039afbb8*/
    v28 += 24; /*0x1039afbbf*/
    v15 = v20 | (v23 << 16) | v18 | (v22 << 8); /*0x1039afbcf*/
  }
  RakNet::CCRakNetSlidingWindow2::addPkt(this, a2: v15, a3: v7, a4: a2); /*0x1039afbda*/
  RakNet::BitStream::~BitStream(this: (RakNet::BitStream *)v26); /*0x1039afbe6*/
  return __stack_chk_guard; /*0x1039afbfb*/
}

// Address: 0x1039afc6c | Name: __ZN6RakNet22CCRakNetSlidingWindow26addPktEjix
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::addPkt(__m128i *this, unsigned int a2, int a3, __int64 a4)
{
  int v5; // eax
  __int64 v7; // rbx
  bool v8; // zf
  __int64 v10; // r13
  int v11; // r12d
  __int64 v12; // rax
  __int64 v13; // rdx
  __int64 v14; // rsi
  __int64 v15; // rbx
  unsigned int *v17; // [rsp+8h] [rbp-58h] BYREF
  __int64 v18; // [rsp+10h] [rbp-50h]
  char *v19; // [rsp+18h] [rbp-48h]
  __int64 v20; // [rsp+20h] [rbp-40h]
  unsigned int v21; // [rsp+2Ch] [rbp-34h] BYREF
  int v22; // [rsp+30h] [rbp-30h]
  char v23[41]; // [rsp+37h] [rbp-29h] BYREF

  v21 = a2; /*0x1039afc82*/
  v5 = a3 + 40; /*0x1039afc85*/
  v18 = a4; /*0x1039afc8b*/
  if ( a2 == -1 ) /*0x1039afc8f*/
  {
    v13 = 0xFFFFFFFFLL; /*0x1039afd96*/
  }
  else
  {
    *((_QWORD *)this + 50) = a4; /*0x1039afc98*/
    *((_DWORD *)this + 103) += v5; /*0x1039afc9f*/
    *((_QWORD *)this + 56) += v5; /*0x1039afca9*/
    *((_DWORD *)this + 83) += v5; /*0x1039afcb0*/
    v7 = *((_QWORD *)this + 46) + v5; /*0x1039afcb7*/
    *((_QWORD *)this + 46) = v7; /*0x1039afcbe*/
    ++*((_DWORD *)this + 82); /*0x1039afcc5*/
    v8 = *((_QWORD *)this + 55) == 0; /*0x1039afccc*/
    v22 = a3 + 40; /*0x1039afcd4*/
    if ( v8 ) /*0x1039afcd7*/
    {
      *((_QWORD *)this + 55) = a4; /*0x1039afcd9*/
      *((_QWORD *)this + 56) = 0; /*0x1039afce2*/
      *((_QWORD *)this + 11) = 0; /*0x1039afce9*/
    }
    v20 = *((unsigned int *)this + 28); /*0x1039afcf1*/
    *((_DWORD *)this + 28) = v20 + 1; /*0x1039afcf7*/
    v19 = (char *)(this + 11); /*0x1039afd02*/
    v10 = operator new(a1: 0x48u); /*0x1039afd13*/
    *(_DWORD *)(v10 + 16) = a2; /*0x1039afd16*/
    v11 = v22; /*0x1039afd1a*/
    *(_DWORD *)(v10 + 20) = v22; /*0x1039afd1e*/
    *(_QWORD *)(v10 + 24) = a4; /*0x1039afd22*/
    *(_OWORD *)(v10 + 32) = 0; /*0x1039afd29*/
    *(_DWORD *)(v10 + 48) = v20; /*0x1039afd31*/
    *(_QWORD *)(v10 + 56) = v7; /*0x1039afd35*/
    *(_QWORD *)(v10 + 64) = 0; /*0x1039afd39*/
    *(_QWORD *)(v10 + 8) = v19; /*0x1039afd45*/
    v12 = *((_QWORD *)this + 22); /*0x1039afd49*/
    *(_QWORD *)v10 = v12; /*0x1039afd50*/
    *(_QWORD *)(v12 + 8) = v10; /*0x1039afd54*/
    *((_QWORD *)this + 22) = v10; /*0x1039afd58*/
    ++*((_QWORD *)this + 24); /*0x1039afd5f*/
    v17 = &v21; /*0x1039afd75*/
    *(_QWORD *)(std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::__emplace_unique_key_args<unsigned int,std::piecewise_construct_t const&,std::tuple<unsigned int const&>,std::tuple<>>( /*0x1039afd8b*/
                  a1: (char *)this + 280,
                  a2: &v21,
                  a3: std::piecewise_construct,
                  a4: &v17,
                  a5: v23)
              + 24) = v10;
    v13 = v21; /*0x1039afd8f*/
    v5 = v11; /*0x1039afd91*/
  }
  *((_QWORD *)this + 40) = _mm_add_epi32( /*0x1039afdb7*/
                             _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v5, 1),
                             _mm_loadl_epi64(this + 20)).u64[0];
  v14 = *((_QWORD *)this + 28); /*0x1039afdc0*/
  if ( v14 == *((_QWORD *)this + 25) ) /*0x1039afdce*/
    v14 = *((_QWORD *)this + 26); /*0x1039afdd0*/
  v15 = v18; /*0x1039afddd*/
  RakNet::CCRakNetSlidingWindow2::updateRange(a1: this, a2: v14 - 128, a3: v13, a4: (unsigned int)v5, a5: v18); /*0x1039afde4*/
  return RakNet::CCRakNetSlidingWindow2::cleanUp((RakNet::CCRakNetSlidingWindow2 *)this, a2: v15); /*0x1039afdf4*/
}

// Address: 0x1039afe04 | Name: __ZN6RakNet22CCRakNetSlidingWindow26addPktEix
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::addPkt(__m128i *this, int a2, __int64 a3)
{
  return RakNet::CCRakNetSlidingWindow2::addPkt(this, a2: 0xFFFFFFFF, a3: a2, a4: a3); /*0x1039afe12*/
}

// Address: 0x1039afe18 | Name: __ZN6RakNet22CCRakNetSlidingWindow211OnGotPacketENS_8uint24_tEbyjPj
char __fastcall RakNet::CCRakNetSlidingWindow2::OnGotPacket(
        __int64 a1,
        _DWORD *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        unsigned int *a6)
{
  int v6; // edx
  unsigned int v8; // eax

  if ( *(_QWORD *)(a1 + 40) == 0 ) /*0x1039afe21*/
    *(_QWORD *)(a1 + 40) = a4; /*0x1039afe23*/
  *(_QWORD *)(a1 + 48) = a4; /*0x1039afe27*/
  v6 = *(_DWORD *)(a1 + 68); /*0x1039afe2d*/
  if ( *a2 == v6 ) /*0x1039afe34*/
  {
    *a6 = 0; /*0x1039afe36*/
    goto LABEL_5; /*0x1039afe36*/
  }
  if ( ((v6 - *a2) & 0x800000) == 0 ) /*0x1039afe51*/
  {
    *a6 = 0; /*0x1039afe53*/
    return 1; /*0x1039afe53*/
  }
  v8 = (*a2 - v6) & 0xFFFFFF; /*0x1039afe5e*/
  *a6 = v8; /*0x1039afe63*/
  if ( v8 < 0x3E9 ) /*0x1039afe6b*/
  {
LABEL_5:
    *(_DWORD *)(a1 + 68) = (*a2 + 1) & 0xFFFFFF; /*0x1039afe3d*/
    return 1; /*0x1039afe5d*/
  }
  if ( v8 <= 0xC350 ) /*0x1039afe72*/
  {
    *a6 = 1000; /*0x1039afe78*/
    goto LABEL_5; /*0x1039afe7f*/
  }
  return 0; /*0x1039afe5c*/
}

// Address: 0x1039afe82 | Name: __ZN6RakNet22CCRakNetSlidingWindow211GreaterThanENS_8uint24_tES1_
_BOOL8 __fastcall RakNet::CCRakNetSlidingWindow2::GreaterThan(_DWORD *a1, _DWORD *a2)
{
  return ((*a2 - *a1) & 0x800000) != 0; /*0x1039afe90*/
}

// Address: 0x1039afe92 | Name: __ZN6RakNet22CCRakNetSlidingWindow28OnResendEy
void __fastcall RakNet::CCRakNetSlidingWindow2::OnResend(RakNet::CCRakNetSlidingWindow2 *this)
{
  double v1; // xmm0_8
  int v2; // eax

  if ( *((_BYTE *)this + 72) == 1 && *((_BYTE *)this + 64) == 0 ) /*0x1039afe9c*/
  {
    v1 = *((double *)this + 3); /*0x1039afe9f*/
    v2 = *((_DWORD *)this + 2); /*0x1039afea4*/
    if ( v1 > (double)(2 * v2) ) /*0x1039afeb2*/
    {
      *((double *)this + 4) = fmax((double)v2, v1 * 0.5); /*0x1039afecf*/
      *((double *)this + 3) = (double)v2; /*0x1039afed4*/
      *((_BYTE *)this + 64) = 1; /*0x1039afed9*/
    }
  }
}

// Address: 0x1039afee0 | Name: __ZN6RakNet22CCRakNetSlidingWindow25OnNAKEyNS_8uint24_tE
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::OnNAK(
        RakNet::CCRakNetSlidingWindow2 *a1,
        __int64 a2,
        unsigned int *a3)
{
  RakNet::CCRakNetSlidingWindow2::onNak(this: a1, a2: *a3, a3: a2); /*0x1039afef2*/
  return (*(__int64 (__fastcall **)(RakNet::CCRakNetSlidingWindow2 *, __int64))(*(_QWORD *)a1 + 112LL))(a1, a2); /*0x1039aff05*/
}

// Address: 0x1039aff0a | Name: __ZN6RakNet22CCRakNetSlidingWindow25onNakEjx
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::onNak(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned int a2,
        __int64 a3)
{
  __int64 result; // rax
  __int64 v7; // rdi
  int v8; // r15d

  ++*((_DWORD *)this + 99); /*0x1039aff1a*/
  result = std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::find<unsigned int>(a1: (char *)this + 280); /*0x1039aff31*/
  if ( result != 0 ) /*0x1039aff39*/
  {
    result = *(_QWORD *)(result + 24); /*0x1039aff3b*/
    if ( *(_QWORD *)(result + 40) == 0 ) /*0x1039aff44*/
    {
      *(_QWORD *)(result + 40) = a3; /*0x1039aff46*/
      *((_QWORD *)this + 50) = a3; /*0x1039aff4a*/
      v8 = *(_DWORD *)(result + 20); /*0x1039aff58*/
      result = RakNet::CCRakNetSlidingWindow2::findRange(a1: v7, a2: (char *)this + 200, a3: a2); /*0x1039aff5f*/
      if ( result != 0 ) /*0x1039aff67*/
        *(_QWORD *)(result + 36) = _mm_add_epi32( /*0x1039aff82*/
                                     _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v8, 1),
                                     _mm_loadl_epi64((const __m128i *)(result + 36))).u64[0];
      *((_QWORD *)this + 45) = _mm_add_epi32( /*0x1039affa3*/
                                 _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v8, 1),
                                 _mm_loadl_epi64((const __m128i *)((char *)this + 360))).u64[0];
    }
  }
  return result; /*0x1039affaf*/
}

// Address: 0x1039affb6 | Name: __ZN6RakNet22CCRakNetSlidingWindow25OnAckEyybdddbNS_8uint24_tE
double *__fastcall RakNet::CCRakNetSlidingWindow2::OnAck(
        __int64 a1,
        __int64 a2,
        unsigned __int64 a3,
        __int64 a4,
        int a5,
        _DWORD *a6)
{
  double *result; // rax
  __m128d v11; // xmm0
  double v12; // xmm0_8
  double v13; // xmm1_8
  double v14; // xmm0_8
  bool v15; // cc

  *(_QWORD *)(a1 + 152) = a2; /*0x1039affd4*/
  *(_QWORD *)(a1 + 400) = a2; /*0x1039affdb*/
  result = (double *)std::vector<std::pair<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>::push_back[abi:ne200100](a1: a1 + 128); /*0x1039afffa*/
  v11 = _mm_sub_pd((__m128d)_mm_unpacklo_epi32((__m128i)a3, (__m128i)xmmword_108F2F9A0), (__m128d)xmmword_108F2F9B0); /*0x1039b000c*/
  *(_QWORD *)(a1 + 16) = (unsigned __int64)_mm_hadd_pd(v11, v11); /*0x1039b0018*/
  *(_BYTE *)(a1 + 72) = a5; /*0x1039b001d*/
  if ( a5 != 0 ) /*0x1039b0024*/
  {
    if ( ((*(_DWORD *)(a1 + 60) - *a6) & 0x800000) != 0 ) /*0x1039b0034*/
    {
      *(_DWORD *)(a1 + 60) = *(_DWORD *)(a1 + 56); /*0x1039b005b*/
      *(_WORD *)(a1 + 64) = 0; /*0x1039b005e*/
      result = (double *)(a1 + 24); /*0x1039b0064*/
      v12 = *(double *)(a1 + 24); /*0x1039b0068*/
      v13 = *(double *)(a1 + 32); /*0x1039b006d*/
      if ( v13 < v12 && v13 != 0.0 ) /*0x1039b0080*/
        goto LABEL_11; /*0x1039b0080*/
    }
    else
    {
      result = (double *)(a1 + 24); /*0x1039b0036*/
      v12 = *(double *)(a1 + 24); /*0x1039b003a*/
      v13 = *(double *)(a1 + 32); /*0x1039b003f*/
      if ( v13 < v12 && v13 != 0.0 ) /*0x1039b0052*/
        return result; /*0x1039b0052*/
    }
    if ( v12 < 10000000.0 ) /*0x1039b0090*/
    {
      v14 = v12 + v12; /*0x1039b0092*/
      *result = v14; /*0x1039b0096*/
      if ( v13 != 0.0 ) /*0x1039b00a2*/
      {
        v15 = v14 <= v13; /*0x1039b00a6*/
        v12 = v13; /*0x1039b00aa*/
        if ( !v15 ) /*0x1039b00ae*/
        {
LABEL_11:
          result = (double *)(unsigned int)(*(_DWORD *)(a1 + 8) * *(_DWORD *)(a1 + 8)); /*0x1039b00b0*/
          *(double *)(a1 + 24) = (double)(int)result / v12 + v12; /*0x1039b00c5*/
        }
      }
    }
  }
  return result; /*0x1039b00ca*/
}

// Address: 0x1039b00d8 | Name: __ZN6RakNet22CCRakNetSlidingWindow25onAckEjx
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::onAck(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned int a2,
        __int64 a3)
{
  *((_QWORD *)this + 19) = a3; /*0x1039b00e0*/
  *((_QWORD *)this + 50) = a3; /*0x1039b00e7*/
  return std::vector<std::pair<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>::push_back[abi:ne200100](a1: (char *)this + 128); /*0x1039b0111*/
}

// Address: 0x1039b0118 | Name: __ZNK6RakNet22CCRakNetSlidingWindow213IsInSlowStartEv
char __fastcall RakNet::CCRakNetSlidingWindow2::IsInSlowStart(RakNet::CCRakNetSlidingWindow2 *this)
{
  return _mm_cvtsi128_si32((__m128i)_mm_or_pd( /*0x1039b013e*/
                                      _mm_cmple_pd(
                                        (__m128d)*((unsigned __int64 *)this + 3),
                                        (__m128d)*((unsigned __int64 *)this + 4)),
                                      _mm_cmpeq_pd((__m128d)0LL, (__m128d)*((unsigned __int64 *)this + 4))))
       & 1;
}

// Address: 0x1039b0140 | Name: __ZN6RakNet22CCRakNetSlidingWindow214OnDuplicateAckEyNS_8uint24_tE
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::OnDuplicateAck(__int64 a1)
{
  return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 112LL))(a1);
}

// Address: 0x1039b014e | Name: __ZN6RakNet22CCRakNetSlidingWindow218OnSendAckGetBAndASEyPbPdS2_
void __fastcall RakNet::CCRakNetSlidingWindow2::OnSendAckGetBAndAS(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned __int64 a2,
        bool *a3,
        double *a4,
        double *a5)
{
  *a3 = false; /*0x1039b0152*/
}

// Address: 0x1039b0158 | Name: __ZN6RakNet22CCRakNetSlidingWindow29OnSendAckEyj
void __fastcall RakNet::CCRakNetSlidingWindow2::OnSendAck(RakNet::CCRakNetSlidingWindow2 *this)
{
  *(_OWORD *)((char *)this + 40) = 0; /*0x1039b015f*/
}

// Address: 0x1039b0166 | Name: __ZN6RakNet22CCRakNetSlidingWindow210OnSendNACKEyj
void __fastcall RakNet::CCRakNetSlidingWindow2::OnSendNACK(RakNet::CCRakNetSlidingWindow2 *this)
{
  ; /*0x1039b0166*/
}

// Address: 0x1039b016c | Name: __ZNK6RakNet22CCRakNetSlidingWindow223GetRTOForRetransmissionEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::GetRTOForRetransmission(RakNet::CCRakNetSlidingWindow2 *this)
{
  __int64 result; // rax
  double v2; // xmm0_8
  __m128d v3; // xmm2
  double v4; // xmm1_8
  __m128d v5; // xmm2

  result = DFInt::RakNetResendMaxThresholdTimeInUs; /*0x1039b0177*/
  v2 = *((double *)this + 2); /*0x1039b017a*/
  if ( v2 != -1.0 ) /*0x1039b0187*/
  {
    v3 = _mm_sub_pd( /*0x1039b01aa*/
           (__m128d)_mm_unpacklo_epi32(
                      (__m128i)(unsigned __int64)DFInt::RakNetResendMaxThresholdTimeInUs,
                      (__m128i)xmmword_108F2F9A0),
           (__m128d)xmmword_108F2F9B0);
    v4 = (double)DFInt::RakNetResendRttMultiple * v2; /*0x1039b01b6*/
    if ( v4 <= _mm_hadd_pd(v3, v3).f64[0] ) /*0x1039b01be*/
    {
      result = DFInt::RakNetResendMinThresholdTimeInUs; /*0x1039b01c7*/
      v5 = _mm_sub_pd( /*0x1039b01d7*/
             (__m128d)_mm_unpacklo_epi32(
                        (__m128i)(unsigned __int64)DFInt::RakNetResendMinThresholdTimeInUs,
                        (__m128i)xmmword_108F2F9A0),
             (__m128d)xmmword_108F2F9B0);
      if ( _mm_hadd_pd(v5, v5).f64[0] <= v4 ) /*0x1039b01e7*/
        return (unsigned int)(int)v2 * (__int64)DFInt::RakNetResendRttMultiple; /*0x1039b020c*/
    }
  }
  return result; /*0x1039b020f*/
}

// Address: 0x1039b0212 | Name: __ZN6RakNet22CCRakNetSlidingWindow26SetMTUEj
void __fastcall RakNet::CCRakNetSlidingWindow2::SetMTU(RakNet::CCRakNetSlidingWindow2 *this, int a2)
{
  *((_DWORD *)this + 2) = a2; /*0x1039b0216*/
}

// Address: 0x1039b021c | Name: __ZNK6RakNet22CCRakNetSlidingWindow26GetMTUEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::GetMTU(RakNet::CCRakNetSlidingWindow2 *this)
{
  return *((unsigned int *)this + 2); /*0x1039b0223*/
}

// Address: 0x1039b0226 | Name: __ZNK6RakNet22CCRakNetSlidingWindow219GetLocalReceiveRateEy
double __fastcall RakNet::CCRakNetSlidingWindow2::GetLocalReceiveRate(RakNet::CCRakNetSlidingWindow2 *this)
{
  return 0.0; /*0x1039b022d*/
}

// Address: 0x1039b0230 | Name: __ZNK6RakNet22CCRakNetSlidingWindow26GetRTTEv
__m128d __fastcall RakNet::CCRakNetSlidingWindow2::GetRTT(RakNet::CCRakNetSlidingWindow2 *this)
{
  return _mm_andn_pd( /*0x1039b024a*/
           _mm_cmpeq_sd((__m128d)0xBFF0000000000000LL, (__m128d)*((unsigned __int64 *)this + 2)),
           (__m128d)*((unsigned __int64 *)this + 2));
}

// Address: 0x1039b024c | Name: __ZN6RakNet22CCRakNetSlidingWindow28LessThanENS_8uint24_tES1_
bool __fastcall RakNet::CCRakNetSlidingWindow2::LessThan(_DWORD *a1, _DWORD *a2)
{
  return *a2 != *a1 && ((*a2 - *a1) & 0xFFFFFFu) < 0x7FFFFF; /*0x1039b0266*/
}

// Address: 0x1039b0268 | Name: __ZNK6RakNet22CCRakNetSlidingWindow241GetBytesPerSecondLimitByCongestionControlEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::GetBytesPerSecondLimitByCongestionControl(
        RakNet::CCRakNetSlidingWindow2 *this)
{
  if ( FFlag::LargeReplicatorUseDynamicBandwidthTarget == 1 ) /*0x1039b0273*/
    return *((int *)this + 109); /*0x1039b0275*/
  else
    return 0; /*0x1039b027e*/
}

// Address: 0x1039b0282 | Name: __ZN6RakNet22CCRakNetSlidingWindow216GetAckTimestampsERyS1_
bool __fastcall RakNet::CCRakNetSlidingWindow2::GetAckTimestamps(
        RakNet::CCRakNetSlidingWindow2 *this,
        unsigned __int64 *a2,
        unsigned __int64 *a3)
{
  unsigned __int64 v3; // rax

  *a2 = *((_QWORD *)this + 5); /*0x1039b028a*/
  v3 = *((_QWORD *)this + 6); /*0x1039b028d*/
  *a3 = v3; /*0x1039b0291*/
  return *a2 != 0 && v3 != 0; /*0x1039b02a3*/
}

// Address: 0x1039b02a6 | Name: __ZN6RakNet22CCRakNetSlidingWindow29findRangeERN5boost15circular_bufferINS0_12RttRangeInfoENSt3__19allocatorIS3_EEEEj
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::findRange(__int64 a1, __int64 a2, int a3)
{
  __int64 v3; // r8
  __int64 v4; // rax
  __int64 v5; // rdi
  __int64 v6; // rcx
  __int64 v7; // rsi
  __int64 result; // rax
  __int64 v9; // r9
  __int64 v10; // r10
  __int64 v11; // r11
  __int64 v12; // r10
  __int64 v13; // rsi

  v3 = *(unsigned int *)(a2 + 32); /*0x1039b02aa*/
  v4 = *(_QWORD *)(a2 + 16); /*0x1039b02b2*/
  v5 = (*(_QWORD *)(a2 + 8) - v4) >> 7; /*0x1039b02bc*/
  v6 = (__int64)(*(_QWORD *)(a2 + 8) - *(_QWORD *)a2) >> 7; /*0x1039b02c3*/
  v7 = v4 + (v3 << 7); /*0x1039b02ce*/
  result = 0; /*0x1039b02d1*/
  while ( (int)v3 > 0 ) /*0x1039b02d6*/
  {
    v9 = v7; /*0x1039b02d8*/
    v10 = 0; /*0x1039b02de*/
    if ( v5 < v3 ) /*0x1039b02e4*/
      v10 = v6; /*0x1039b02e4*/
    v11 = v3 - 1; /*0x1039b02e8*/
    v12 = v10 << 7; /*0x1039b02ec*/
    v7 -= 128; /*0x1039b02f6*/
    --v3; /*0x1039b0300*/
    if ( *(_DWORD *)(v9 - v12 - 108) != 0 ) /*0x1039b0303*/
    {
      v3 = v11; /*0x1039b0308*/
      if ( *(_DWORD *)(v9 - v12 - 128) <= a3 ) /*0x1039b030f*/
      {
        v13 = v7 - v12; /*0x1039b0311*/
        result = 0; /*0x1039b0314*/
        if ( *(_DWORD *)(v13 + 4) >= a3 ) /*0x1039b0319*/
          return v13; /*0x1039b0319*/
        return result; /*0x1039b0319*/
      }
    }
  }
  return result; /*0x1039b031d*/
}

// Address: 0x1039b0320 | Name: __ZN6RakNet22CCRakNetSlidingWindow211updateRangeERNS0_12RttRangeInfoEjiy
void __fastcall RakNet::CCRakNetSlidingWindow2::updateRange(__int64 a1, __int64 a2, int a3, int a4, __int64 a5)
{
  __m128i inserted; // xmm0

  inserted = _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), a4, 1); /*0x1039b032d*/
  *(_QWORD *)(a2 + 12) = _mm_add_epi32(_mm_loadl_epi64((const __m128i *)(a2 + 12)), inserted).u64[0]; /*0x1039b033c*/
  if ( a3 != -1 ) /*0x1039b0344*/
  {
    *(_QWORD *)(a2 + 20) = _mm_add_epi32(_mm_loadl_epi64((const __m128i *)(a2 + 20)), inserted).u64[0]; /*0x1039b034f*/
    *(_QWORD *)(a2 + 72) = a5; /*0x1039b0354*/
    *(_DWORD *)(a2 + 4) = a3; /*0x1039b0358*/
    if ( *(_QWORD *)(a2 + 64) == 0 ) /*0x1039b0360*/
    {
      *(_QWORD *)(a2 + 64) = a5; /*0x1039b0362*/
      *(_DWORD *)a2 = a3; /*0x1039b0366*/
    }
  }
}

// Address: 0x1039b036a | Name: __ZN6RakNet22CCRakNetSlidingWindow211updateRangeERN5boost15circular_bufferINS0_12RttRangeInfoENSt3__19allocatorIS3_EEEEjiy
void __fastcall RakNet::CCRakNetSlidingWindow2::updateRange(__int64 a1, _QWORD *a2, int a3, int a4, __int64 a5)
{
  __int64 v6; // rsi

  v6 = a2[3]; /*0x1039b0371*/
  if ( v6 == *a2 ) /*0x1039b0378*/
    v6 = a2[1]; /*0x1039b037a*/
  RakNet::CCRakNetSlidingWindow2::updateRange(a1, a2: v6 - 128, a3, a4, a5); /*0x1039b0383*/
}

// Address: 0x1039b0388 | Name: __ZN6RakNet22CCRakNetSlidingWindow214updateRangeAckERN5boost15circular_bufferINS0_12RttRangeInfoENSt3__19allocatorIS3_EEEEjiyx
unsigned __int64 __fastcall RakNet::CCRakNetSlidingWindow2::updateRangeAck(
        RakNet::CCRakNetSlidingWindow2 *this,
        __int64 *a2,
        __int64 a3,
        int a4,
        __int64 a5,
        __int64 a6)
{
  RakNet::CCRakNetSlidingWindow2 *v7; // r15
  unsigned __int64 result; // rax
  __int64 v9; // rdi
  __int64 v10; // r12
  int v11; // r13d
  __int64 Range; // rbx
  __int64 v13; // rdi
  __int64 v14; // rdx
  __int64 v15; // rcx
  __int64 v16; // rax
  unsigned __int64 v17; // rdx
  __int64 v18; // rdx
  __int64 v19; // rsi
  unsigned __int64 v20; // rax
  unsigned __int64 v21; // rcx
  __int64 v22; // r13
  int v23; // r12d
  __int64 v24; // r14
  int v25; // esi
  __int64 v26; // rax
  int v27; // ecx
  __int64 *v28; // rcx
  __int64 *v29; // rax
  int v30; // edx
  __int64 v31; // r14
  RakNet::CCRakNetSlidingWindow2 *v32; // rcx
  __int64 v33; // r15
  __int64 v34; // rax
  __int64 v35; // rdx
  __int64 v36; // rax
  int v37; // edx
  int v38; // r14d
  __int64 v39; // rax
  __int64 v40; // r15
  unsigned int v41; // eax
  __m128i v42; // xmm0
  bool v43; // zf
  __int64 v44; // rax
  __int64 *v45; // rsi
  __int64 v46; // rax
  __int64 *v47; // r14
  unsigned __int64 v48; // rsi
  __int64 v49; // rax
  __int64 v50; // rcx
  unsigned __int64 v51; // rcx
  __int64 v52; // rdx
  int v53; // eax
  unsigned __int64 v54; // rax
  int v55; // edx
  int v56; // ecx
  _DWORD v57[32]; // [rsp+0h] [rbp-E0h] BYREF
  char *v58; // [rsp+80h] [rbp-60h]
  int v59; // [rsp+8Ch] [rbp-54h]
  __int64 *v60; // [rsp+90h] [rbp-50h]
  __int64 v61; // [rsp+98h] [rbp-48h]
  RakNet::CCRakNetSlidingWindow2 *v62; // [rsp+A0h] [rbp-40h]
  __int64 v63; // [rsp+A8h] [rbp-38h]
  __int64 v64; // [rsp+B0h] [rbp-30h]

  v63 = a6; /*0x1039b039c*/
  v61 = a5; /*0x1039b03a0*/
  v59 = a4; /*0x1039b03a4*/
  v7 = this; /*0x1039b03aa*/
  v64 = a3; /*0x1039b03ad*/
  result = RakNet::CCRakNetSlidingWindow2::findRange(a1: (__int64)this, (__int64)a2, a3); /*0x1039b03b1*/
  if ( result == 0 ) /*0x1039b03b9*/
    return result; /*0x1039b03b9*/
  v10 = result; /*0x1039b03bf*/
  v11 = *(_DWORD *)result; /*0x1039b03c2*/
  Range = RakNet::CCRakNetSlidingWindow2::findRange(a1: v9, (__int64)a2, a3: *(_DWORD *)result - 1); /*0x1039b03d1*/
  v14 = a2[3]; /*0x1039b03d4*/
  v15 = *a2; /*0x1039b03d8*/
  v16 = a2[1]; /*0x1039b03db*/
  if ( v14 == *a2 ) /*0x1039b03e2*/
    v14 = a2[1]; /*0x1039b03e2*/
  v62 = v7; /*0x1039b03ed*/
  v60 = a2; /*0x1039b03f1*/
  if ( v10 != v14 - 128 || *(_QWORD *)(v10 + 80) != 0 || Range == 0 ) /*0x1039b0403*/
    goto LABEL_11; /*0x1039b040e*/
  if ( *(_DWORD *)(Range + 8) != *(_DWORD *)(Range + 4) ) /*0x1039b0416*/
    goto LABEL_40; /*0x1039b0416*/
  v17 = a2[4]; /*0x1039b041c*/
  if ( v17 < 3 ) /*0x1039b0424*/
    goto LABEL_11; /*0x1039b0424*/
  v18 = v17 - 3; /*0x1039b0426*/
  v19 = a2[2]; /*0x1039b042a*/
  v13 = (v16 - v19) >> 7; /*0x1039b0434*/
  v20 = (unsigned __int64)(v16 - v15) >> 7; /*0x1039b043b*/
  v21 = 0; /*0x1039b043f*/
  if ( v13 <= v18 ) /*0x1039b0444*/
    v21 = v20; /*0x1039b0444*/
  if ( *(_QWORD *)(v19 + ((v18 - v21) << 7) + 88) >= *(_QWORD *)(Range + 88) ) /*0x1039b0458*/
  {
LABEL_40:
    if ( v11 <= (int)v64 ) /*0x1039b05e1*/
    {
      v58 = (char *)v7 + 280; /*0x1039b05ee*/
      v38 = v64 + 1; /*0x1039b05f6*/
      do /*0x1039b0696*/
      {
        v57[0] = v11; /*0x1039b05fa*/
        v39 = std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::find<unsigned int>(a1: v58); /*0x1039b060c*/
        if ( v39 != 0 ) /*0x1039b0614*/
        {
          v40 = *(_QWORD *)(v39 + 24); /*0x1039b0616*/
          RakNet::CCRakNetSlidingWindow2::updateRange( /*0x1039b0628*/
            a1: v13,
            a2: Range,
            a3: v11,
            a4: *(_DWORD *)(v40 + 20),
            a5: *(_QWORD *)(v40 + 24));
          v41 = *(_DWORD *)(v40 + 20); /*0x1039b062d*/
          v42 = _mm_loadu_si128((const __m128i *)(v10 + 12)); /*0x1039b0631*/
          *(__m128i *)(v10 + 12) = _mm_blend_epi16( /*0x1039b0657*/
                                     _mm_sub_epi32(v42, _mm_shuffle_epi32(_mm_cvtsi32_si128(v41), 0)),
                                     _mm_add_epi32(v42, (__m128i)xmmword_109105A10),
                                     51);
          v43 = *(_QWORD *)(v40 + 40) == 0; /*0x1039b065e*/
          v7 = v62; /*0x1039b0663*/
          if ( !v43 ) /*0x1039b0667*/
          {
            *(_DWORD *)(v10 + 40) -= v41; /*0x1039b0669*/
            --*(_DWORD *)(v10 + 36); /*0x1039b066e*/
            *(_QWORD *)(Range + 36) = _mm_add_epi32( /*0x1039b068b*/
                                        _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v41, 1),
                                        _mm_loadl_epi64((const __m128i *)(Range + 36))).u64[0];
          }
        }
        ++v11; /*0x1039b0690*/
      }
      while ( v38 != v11 ); /*0x1039b0696*/
    }
    if ( *(_DWORD *)(v10 + 4) <= (int)v64 ) /*0x1039b06a5*/
    {
      *(_QWORD *)v10 = 0; /*0x1039b06e1*/
      *(_OWORD *)(v10 + 64) = 0; /*0x1039b06ed*/
      v45 = v60; /*0x1039b06f4*/
      v24 = v63; /*0x1039b06f8*/
    }
    else
    {
      v57[0] = v64 + 1; /*0x1039b06b0*/
      v44 = std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::find<unsigned int>(a1: (char *)v7 + 280); /*0x1039b06b9*/
      v45 = v60; /*0x1039b06c1*/
      v24 = v63; /*0x1039b06c5*/
      if ( v44 != 0 ) /*0x1039b06c9*/
      {
        v46 = *(_QWORD *)(v44 + 24); /*0x1039b06cb*/
        *(_QWORD *)(v10 + 64) = *(_QWORD *)(v46 + 24); /*0x1039b06d3*/
        *(_DWORD *)v10 = *(_DWORD *)(v46 + 16); /*0x1039b06db*/
      }
    }
    v22 = RakNet::CCRakNetSlidingWindow2::findRange(a1: v13, a2: (__int64)v45, a3: *(_DWORD *)Range - 1); /*0x1039b0705*/
    v23 = v64; /*0x1039b0708*/
  }
  else
  {
LABEL_11:
    v22 = Range; /*0x1039b045e*/
    Range = v10; /*0x1039b0461*/
    v23 = v64; /*0x1039b0464*/
    v24 = v63; /*0x1039b0468*/
  }
  v25 = v59; /*0x1039b047a*/
  *(_QWORD *)(Range + 28) = _mm_add_epi32( /*0x1039b0487*/
                              _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v59, 1),
                              _mm_loadl_epi64((const __m128i *)(Range + 28))).u64[0];
  if ( *(_DWORD *)(Range + 8) < v23 ) /*0x1039b0490*/
    *(_DWORD *)(Range + 8) = v23; /*0x1039b0492*/
  if ( *(_QWORD *)(Range + 80) == 0 ) /*0x1039b049b*/
  {
    *(_QWORD *)(Range + 80) = v61; /*0x1039b04e2*/
    *(_QWORD *)(Range + 56) = v24; /*0x1039b04e6*/
LABEL_24:
    *(_QWORD *)(Range + 48) = v24; /*0x1039b04ea*/
    *(_DWORD *)(Range + 96) = v25; /*0x1039b04ee*/
    v26 = v24; /*0x1039b04f1*/
    goto LABEL_25; /*0x1039b04f1*/
  }
  if ( *(_QWORD *)(Range + 56) < v24 ) /*0x1039b04a1*/
    *(_QWORD *)(Range + 56) = v24; /*0x1039b04a3*/
  v26 = *(_QWORD *)(Range + 48); /*0x1039b04a7*/
  v27 = *((_DWORD *)v7 + 2); /*0x1039b04ab*/
  if ( v26 > v24 && (v27 / 4 <= v25 || *(_DWORD *)(Range + 96) < v27) || v27 <= v25 && *(_DWORD *)(Range + 96) < v27 / 4 ) /*0x1039b04da*/
    goto LABEL_24; /*0x1039b04da*/
LABEL_25:
  *(_QWORD *)(Range + 88) = v61; /*0x1039b04f4*/
  if ( (unsigned __int64)(v26 - 2) <= 0xBB5 && *((int *)v7 + 109) <= 499999 ) /*0x1039b0517*/
    RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this: v7, a2: 10000000); /*0x1039b0521*/
  v28 = (__int64 *)(v22 + 88); /*0x1039b0526*/
  v29 = (__int64 *)(Range + 64); /*0x1039b052e*/
  if ( v22 != 0 ) /*0x1039b0535*/
    v29 = (__int64 *)(v22 + 72); /*0x1039b0539*/
  else
    v28 = (__int64 *)(Range + 80); /*0x1039b0535*/
  v30 = *(_DWORD *)(Range + 120); /*0x1039b053d*/
  if ( v30 != 0 ) /*0x1039b0542*/
    goto LABEL_56; /*0x1039b0542*/
  if ( *((_DWORD *)v7 + 19) == 0 && *(__int64 *)(Range + 48) >= 100000 && *(int *)(Range + 28) >= 21 ) /*0x1039b0565*/
  {
    v31 = *v28; /*0x1039b056b*/
    if ( *(_QWORD *)(Range + 88) - *v28 >= 30001 ) /*0x1039b057c*/
    {
      v32 = v7; /*0x1039b0582*/
      v33 = *v29; /*0x1039b0585*/
      v57[0] = v23; /*0x1039b058f*/
      v34 = std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::find<unsigned int>(a1: (char *)v32 + 280); /*0x1039b0599*/
      if ( v34 != 0 ) /*0x1039b05a1*/
      {
        v35 = 2 * (*(_QWORD *)(*(_QWORD *)(v34 + 24) + 24LL) - v33); /*0x1039b05b2*/
        v36 = *(_QWORD *)(Range + 88); /*0x1039b05b5*/
        if ( v35 >= v36 - v31 ) /*0x1039b05c2*/
        {
          v37 = *(_DWORD *)(Range + 32); /*0x1039b0717*/
          v7 = v62; /*0x1039b0722*/
          if ( 4 * *(_DWORD *)(Range + 40) <= v37 || v36 == v31 ) /*0x1039b072b*/
            goto LABEL_55; /*0x1039b072b*/
          goto LABEL_54; /*0x1039b072b*/
        }
        v7 = v62; /*0x1039b05cb*/
        if ( v36 != v31 ) /*0x1039b05cf*/
        {
          v37 = *(_DWORD *)(Range + 32); /*0x1039b05d5*/
LABEL_54:
          RakNet::CCRakNetSlidingWindow2::setCurrentState(this: v7, a2: 3, a3: 1000000LL * v37 / (v36 - v31)); /*0x1039b072d*/
        }
      }
      else
      {
        v7 = v62; /*0x1039b0711*/
      }
    }
  }
LABEL_55:
  v30 = *(_DWORD *)(Range + 120); /*0x1039b074b*/
LABEL_56:
  if ( v30 == 2 /*0x1039b077e*/
    && *((_DWORD *)v7 + 19) == 2
    && *((_DWORD *)v7 + 83) - (*((_DWORD *)v7 + 91) + *((_DWORD *)v7 + 89)) < 2 * *((_DWORD *)v7 + 2) + 116 )
  {
    RakNet::CCRakNetSlidingWindow2::setCurrentState(this: v7, a2: 3, a3: -1); /*0x1039b078d*/
    *((_DWORD *)v7 + 20) = 9; /*0x1039b0792*/
  }
  v47 = v60; /*0x1039b079a*/
  result = v60[3]; /*0x1039b079e*/
  if ( result == *v60 ) /*0x1039b07a5*/
    result = v60[1]; /*0x1039b07a7*/
  if ( Range == result - 128 /*0x1039b07ec*/
    && v61 - *(_QWORD *)(result - 64) >= (unsigned __int64)DFInt::RakNetUseSlidingWindow2_minRtt
    && (*(int *)(result - 108) > 2
     || *(_DWORD *)(result - 104) > (int)(((unsigned int)(*((_DWORD *)v7 + 2) - 12) >> 31) + *((_DWORD *)v7 + 2) - 12) >> 1) )
  {
    RakNet::CCRakNetSlidingWindow2::updateLastRecvStats(a1: v7, a2: v60); /*0x1039b07f8*/
    v48 = v60[4] + 1; /*0x1039b0801*/
    memset(v57, 0, sizeof(v57)); /*0x1039b0832*/
    boost::circular_buffer<RakNet::CCRakNetSlidingWindow2::RttRangeInfo,std::allocator<RakNet::CCRakNetSlidingWindow2::RttRangeInfo>>::resize( /*0x1039b0839*/
      a1: v60,
      a2: v48,
      a3: (__int64)v57);
    v49 = *v47; /*0x1039b0842*/
    v50 = v47[3]; /*0x1039b0845*/
    if ( v50 == *v47 ) /*0x1039b084c*/
      v50 = v47[1]; /*0x1039b084e*/
    *(_DWORD *)(v50 - 8) = *((_DWORD *)v7 + 19); /*0x1039b0852*/
    *(_DWORD *)(v50 - 28) = *((_DWORD *)v7 + 109); /*0x1039b085c*/
    if ( *((_QWORD *)v7 + 53) != 0 ) /*0x1039b0867*/
      *(_BYTE *)(v50 - 4) = 1; /*0x1039b0869*/
    v51 = v47[4]; /*0x1039b086d*/
    if ( DFInt::RakNetUseSlidingWindow2_rangeCount < (int)v51 ) /*0x1039b0877*/
    {
      v52 = v47[2] + 128; /*0x1039b087d*/
      if ( v52 == v47[1] ) /*0x1039b0885*/
        v52 = v49; /*0x1039b0885*/
      v47[2] = v52; /*0x1039b0889*/
      v47[4] = --v51; /*0x1039b0890*/
    }
    v53 = *((_DWORD *)v7 + 29); /*0x1039b0894*/
    if ( v53 != 0 ) /*0x1039b089a*/
    {
      v54 = (unsigned int)(v53 + 1); /*0x1039b089c*/
      v55 = 0; /*0x1039b089e*/
      if ( v51 > v54 ) /*0x1039b08a3*/
        v55 = v54; /*0x1039b08a3*/
      *((_DWORD *)v7 + 29) = v55; /*0x1039b08a6*/
    }
    result = *((unsigned int *)v7 + 30); /*0x1039b08aa*/
    if ( (_DWORD)result != 0 ) /*0x1039b08b0*/
    {
      result = (unsigned int)(result + 1); /*0x1039b08b2*/
      v56 = 0; /*0x1039b08b4*/
      if ( v47[4] > result ) /*0x1039b08ba*/
        v56 = result; /*0x1039b08ba*/
      *((_DWORD *)v7 + 30) = v56; /*0x1039b08bd*/
    }
  }
  return result; /*0x1039b08c1*/
}

// Address: 0x1039b08d4 | Name: __ZN6RakNet22CCRakNetSlidingWindow211findPktInfoEj
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::findPktInfo(RakNet::CCRakNetSlidingWindow2 *this)
{
  __int64 v1; // rax

  v1 = std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::find<unsigned int>(a1: (char *)this + 280); /*0x1039b08ec*/
  if ( v1 != 0 ) /*0x1039b08f4*/
    return *(_QWORD *)(v1 + 24) + 16LL; /*0x1039b08fa*/
  else
    return 0; /*0x1039b0900*/
}

// Address: 0x1039b0908 | Name: __ZNK6RakNet22CCRakNetSlidingWindow23mtuEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::mtu(RakNet::CCRakNetSlidingWindow2 *this)
{
  return (unsigned int)(*((_DWORD *)this + 2) + 58); /*0x1039b0912*/
}

// Address: 0x1039b0914 | Name: __ZN6RakNet22CCRakNetSlidingWindow219updateLastRecvStatsERN5boost15circular_bufferINS0_12RttRangeInfoENSt3__19allocatorIS3_EEEE
void __fastcall RakNet::CCRakNetSlidingWindow2::updateLastRecvStats(RakNet::CCRakNetSlidingWindow2 *a1, _QWORD *a2)
{
  unsigned __int64 v2; // rbx
  __int64 v4; // rbx
  __int64 v5; // r14
  __int64 v6; // rdx
  __int64 v7; // r13
  char *v9; // r12
  __int64 v10; // rax
  _QWORD *v11; // r14
  _QWORD *v12; // r14
  RakNet::CCRakNetSlidingWindow2 *v13; // rdi
  __int64 v14; // rax
  _QWORD *v15; // rsi
  __int64 v16; // rcx
  bool v17; // cc
  __int64 v18; // rcx
  __int64 v19; // r8
  __int64 v20; // rdx
  __int64 v21; // rax
  __int64 v22; // rcx
  __int64 v23; // rsi
  int v24; // r14d
  int v25; // eax
  int v26; // ecx
  unsigned __int8 v27; // r10
  __int64 v28; // r8
  int v29; // eax
  __int64 v30; // rsi
  __int64 v31; // rcx
  __int64 v32; // r9
  __int64 v33; // rsi
  __int64 v34; // rbx
  unsigned __int64 v35; // r12
  __int64 RttMicroMin; // rax
  int v37; // ecx
  int v38; // edx
  __int64 v39; // rdx
  __int64 v40; // r12
  __int64 v41; // rcx
  __int64 v42; // rsi
  __int64 v43; // r12
  int v44; // ebx
  int v45; // ecx
  int v46; // eax
  int v47; // edx
  int v48; // esi
  int v49; // esi
  RakNet::CCRakNetSlidingWindow2 *v50; // rbx
  int v51; // eax
  __m128d v52; // xmm1
  __m128d v53; // xmm0
  __int64 v54; // rax
  __int64 v55; // rcx
  RakNet::CCRakNetSlidingWindow2 *v56; // r14
  int v57; // esi
  __int64 v58; // rcx
  int v59; // eax
  int v60; // [rsp+Ch] [rbp-34h]
  RakNet::CCRakNetSlidingWindow2 *v61; // [rsp+10h] [rbp-30h]

  v2 = a2[4]; /*0x1039b0925*/
  if ( v2 < 2 ) /*0x1039b092d*/
    return; /*0x1039b092d*/
  v4 = v2 - 2; /*0x1039b0936*/
  v5 = a2[2]; /*0x1039b093e*/
  v6 = 0; /*0x1039b0953*/
  if ( (a2[1] - v5) >> 7 <= v4 ) /*0x1039b0958*/
    v6 = (a2[1] - *a2) >> 7; /*0x1039b0958*/
  v7 = v5 + ((v4 - v6) << 7); /*0x1039b0963*/
  v60 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this: a1); /*0x1039b096f*/
  v61 = a1; /*0x1039b097d*/
  v9 = (char *)a1 + 280; /*0x1039b0981*/
  v10 = std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::find<unsigned int>(a1: v9); /*0x1039b098b*/
  if ( v10 == 0 ) /*0x1039b0993*/
  {
    v13 = v61; /*0x1039b09b5*/
    if ( a2[4] < 3u ) /*0x1039b09b9*/
      goto LABEL_21; /*0x1039b09b9*/
    v12 = nullptr; /*0x1039b09bf*/
LABEL_9:
    v14 = std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::find<unsigned int>(a1: v9); /*0x1039b09e8*/
    if ( v14 != 0 ) /*0x1039b0a04*/
    {
      v13 = v61; /*0x1039b0a0d*/
      if ( v12 != nullptr ) /*0x1039b0a11*/
      {
        v15 = *(_QWORD **)(v14 + 24); /*0x1039b0a17*/
        v16 = v12[2]; /*0x1039b0a1b*/
        v17 = v16 <= v15[4]; /*0x1039b0a1f*/
        v18 = v16 - v15[4]; /*0x1039b0a1f*/
        if ( !v17 && (__int64)(v12[1] - v15[3]) > 0 ) /*0x1039b0a34*/
        {
          v19 = v12[1] - v15[3]; /*0x1039b0a2d*/
          *(_DWORD *)(v7 + 104) = ((1000000LL * (v12[5] - v15[7]) + 32 * v19) / v19) & 0xFFFFFFC0; /*0x1039b0a5b*/
          v20 = 1000000LL * (v12[6] - v15[8]); /*0x1039b0a67*/
LABEL_19:
          *(_DWORD *)(v7 + 108) = ((v20 + 32 * v18) / v18) & 0xFFFFFFC0; /*0x1039b0abe*/
          goto LABEL_21; /*0x1039b0ad4*/
        }
      }
    }
    else
    {
      v13 = v61; /*0x1039b0ad6*/
    }
    goto LABEL_21; /*0x1039b0a34*/
  }
  v11 = *(_QWORD **)(v10 + 24); /*0x1039b0995*/
  if ( a2[4] > 2u ) /*0x1039b09a1*/
  {
    v12 = v11 + 2; /*0x1039b09a7*/
    goto LABEL_9; /*0x1039b09ab*/
  }
  v21 = a2[3]; /*0x1039b0a70*/
  if ( v21 == *a2 ) /*0x1039b0a77*/
    v21 = a2[1]; /*0x1039b0a79*/
  v22 = *(_QWORD *)(v21 - 48); /*0x1039b0a7d*/
  v17 = v22 <= *(_QWORD *)(v7 + 80); /*0x1039b0a81*/
  v18 = v22 - *(_QWORD *)(v7 + 80); /*0x1039b0a81*/
  v13 = v61; /*0x1039b0a85*/
  if ( !v17 && (__int64)(*(_QWORD *)(v21 - 64) - *(_QWORD *)(v7 + 64)) > 0 ) /*0x1039b0a96*/
  {
    v23 = *(_QWORD *)(v21 - 64) - *(_QWORD *)(v7 + 64); /*0x1039b0a8f*/
    *(_DWORD *)(v7 + 104) = ((1000000LL * v11[7] + 32 * v23) / v23) & 0xFFFFFFC0; /*0x1039b0ab2*/
    v20 = 1000000LL * v11[8]; /*0x1039b0ab6*/
    goto LABEL_19; /*0x1039b0ab6*/
  }
LABEL_21:
  v24 = *(_DWORD *)(v7 + 108); /*0x1039b0ada*/
  if ( v24 <= 0 ) /*0x1039b0ae1*/
  {
    *(_DWORD *)(v7 + 108) = 1; /*0x1039b0ae3*/
    v24 = 1; /*0x1039b0aeb*/
  }
  v25 = *(_DWORD *)(v7 + 24); /*0x1039b0af1*/
  if ( v25 > 0 ) /*0x1039b0af7*/
  {
    v26 = *(_DWORD *)(v7 + 40); /*0x1039b0af9*/
    if ( v26 != 0 ) /*0x1039b0aff*/
      *(double *)(v7 + 112) = (double)v26 * 100.0 / (double)v25; /*0x1039b0b15*/
  }
  v27 = *(_BYTE *)(v7 + 124); /*0x1039b0b1b*/
  if ( v27 == 0 ) /*0x1039b0b22*/
  {
    v28 = *(unsigned int *)(v7 + 96); /*0x1039b0b24*/
    v29 = *((_DWORD *)v13 + 2); /*0x1039b0b28*/
    if ( (int)v28 < v29 && (int)v28 > 0 ) /*0x1039b0b34*/
    {
      v30 = v29 + 58; /*0x1039b0b3e*/
      v31 = 1000000 * v30 / (unsigned int)v24; /*0x1039b0b50*/
      v32 = *(_QWORD *)(v7 + 48); /*0x1039b0b53*/
      v33 = v32 * v30; /*0x1039b0b57*/
      if ( v33 / v28 < v31 ) /*0x1039b0b66*/
        v31 = v33 / v28; /*0x1039b0b66*/
      if ( v32 < v31 ) /*0x1039b0b6d*/
        *(_QWORD *)(v7 + 48) = v31; /*0x1039b0b6f*/
    }
  }
  v34 = *(_QWORD *)(v7 + 48); /*0x1039b0b73*/
  if ( v34 != 0 ) /*0x1039b0b7a*/
    *((double *)v13 + 2) = (double)(int)v34; /*0x1039b0b84*/
  v35 = a2[4]; /*0x1039b0b89*/
  if ( v35 < 3 ) /*0x1039b0b91*/
    return; /*0x1039b0b91*/
  if ( (v27 | ((unsigned int)(*(_DWORD *)(v7 + 120) - 6) < 0xFFFFFFFD)) == 0 ) /*0x1039b0ba7*/
  {
    RttMicroMin = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this: v13); /*0x1039b0bad*/
    v37 = *(_DWORD *)(v7 + 100); /*0x1039b0bb2*/
    if ( v37 <= (int)(v24 + ((unsigned int)v24 >> 2)) ) /*0x1039b0bc1*/
      goto LABEL_45; /*0x1039b0bc1*/
    v38 = 5 * *(_DWORD *)(v7 + 104) + 3; /*0x1039b0bcd*/
    if ( 5 * *(_DWORD *)(v7 + 104) >= 0 ) /*0x1039b0bd2*/
      v38 = 5 * *(_DWORD *)(v7 + 104); /*0x1039b0bd2*/
    if ( v37 <= v38 >> 2 ) /*0x1039b0bda*/
    {
LABEL_45:
      v13 = v61; /*0x1039b0c2d*/
    }
    else
    {
      v39 = 5 * RttMicroMin + 3; /*0x1039b0be4*/
      if ( 5 * RttMicroMin >= 0 ) /*0x1039b0beb*/
        v39 = 5 * RttMicroMin; /*0x1039b0beb*/
      v13 = v61; /*0x1039b0bf6*/
      if ( v34 > v39 >> 2 && v34 - RttMicroMin > DFInt::RakNetUseSlidingWindow2_minRtt ) /*0x1039b0c09*/
      {
        *((_DWORD *)v61 + 30) = 2; /*0x1039b0c0b*/
        RakNet::CCRakNetSlidingWindow2::setCurrentState(this: v61, a2: 2, a3: (unsigned int)(3 * v24) >> 2); /*0x1039b0c1e*/
        v13 = v61; /*0x1039b0c23*/
        v35 = a2[4]; /*0x1039b0c27*/
      }
    }
  }
  v40 = v35 - 3; /*0x1039b0c31*/
  v41 = a2[2]; /*0x1039b0c39*/
  v42 = 0; /*0x1039b0c4e*/
  if ( (a2[1] - v41) >> 7 <= v40 ) /*0x1039b0c53*/
    v42 = (a2[1] - *a2) >> 7; /*0x1039b0c53*/
  v43 = v41 + ((v40 - v42) << 7); /*0x1039b0c5e*/
  v44 = *((_DWORD *)v13 + 19); /*0x1039b0c61*/
  if ( v44 == 0 ) /*0x1039b0c66*/
  {
    if ( *(int *)(v7 + 36) < 2 /*0x1039b0e5a*/
      || ((v52 = (__m128d)*(unsigned __int64 *)(v7 + 112),
           v53 = (__m128d)*(unsigned __int64 *)(v43 + 112),
           v52.f64[0] <= 15.0)
       || v52.f64[0] <= v53.f64[0] + v53.f64[0])
      && (*(_DWORD *)(v43 + 120) != 0
       || ((v52.f64[0] <= 6.0)
         & (unsigned __int8)_mm_cvtsi128_si32((__m128i)_mm_or_pd(
                                                         _mm_cmpnlt_pd((__m128d)0LL, v53),
                                                         _mm_cmpnlt_pd((__m128d)0x4008000000000000uLL, v52)))) != 0
       || v53.f64[0] >= 0.5) )
    {
      v54 = *(int *)(v7 + 104); /*0x1039b0d56*/
      v55 = *(int *)(v43 + 104); /*0x1039b0d5e*/
      if ( 100 * v54 < 110 * v55 /*0x1039b0daf*/
        || (int)v54 - (int)v55 < 10001
        || *(_DWORD *)(v43 + 120) != 0
        || 100 * *(int *)(v7 + 108) * v55 >= *(int *)(v43 + 108) * v54 * DFInt::RakNetMinAckGrowthPercent )
      {
        return; /*0x1039b0daf*/
      }
    }
    goto LABEL_75; /*0x1039b0daf*/
  }
  if ( v44 == 1 ) /*0x1039b0c6f*/
  {
    v50 = v13; /*0x1039b0cfa*/
    v51 = RakNet::CCRakNetSlidingWindow2::calculateDrainSpeed(this: v13, a2: -1); /*0x1039b0cfd*/
    if ( v51 != -1 ) /*0x1039b0d05*/
      goto LABEL_61; /*0x1039b0d05*/
    v13 = v50; /*0x1039b0dd5*/
    goto LABEL_75; /*0x1039b0dd5*/
  }
  if ( v44 != 2 ) /*0x1039b0c78*/
  {
    v56 = v13; /*0x1039b0dbb*/
    if ( (unsigned int)RakNet::CCRakNetSlidingWindow2::calculateDrainSpeed(this: v13, a2: -1) != -1 ) /*0x1039b0dc6*/
    {
      v13 = v56; /*0x1039b0dc8*/
      v57 = 1; /*0x1039b0dcb*/
LABEL_90:
      RakNet::CCRakNetSlidingWindow2::setCurrentState(this: v13, a2: v57, a3: -1); /*0x1039b0e81*/
      return; /*0x1039b0e86*/
    }
    if ( *(_DWORD *)(v7 + 120) == 4 ) /*0x1039b0df3*/
      v58 = 115LL * v60; /*0x1039b0df5*/
    else
      v58 = 120LL * v60; /*0x1039b0dfb*/
    v13 = v61; /*0x1039b0e02*/
    if ( 100LL * *(int *)(v7 + 108) > v58 ) /*0x1039b0e06*/
    {
      v57 = 0; /*0x1039b0e08*/
      goto LABEL_90; /*0x1039b0e0a*/
    }
    if ( v44 != 5 ) /*0x1039b0e0f*/
    {
      if ( v44 == 4 ) /*0x1039b0e14*/
      {
        v57 = 5; /*0x1039b0e16*/
        goto LABEL_90; /*0x1039b0e1b*/
      }
      if ( *((_QWORD *)v61 + 53) == 0 ) /*0x1039b0e6d*/
      {
        v59 = *((_DWORD *)v61 + 20) + 1; /*0x1039b0e72*/
        *((_DWORD *)v61 + 20) = v59; /*0x1039b0e74*/
        if ( v59 == 10 ) /*0x1039b0e7a*/
        {
LABEL_89:
          v57 = 4; /*0x1039b0e7c*/
          goto LABEL_90; /*0x1039b0e7c*/
        }
      }
      v50 = v61; /*0x1039b0e9a*/
      v51 = RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this: v61); /*0x1039b0e9d*/
LABEL_61:
      v13 = v50; /*0x1039b0d0b*/
      v49 = v51; /*0x1039b0d0e*/
LABEL_62:
      RakNet::CCRakNetSlidingWindow2::setTargetSpeed(this: v13, a2: v49); /*0x1039b0d10*/
      return; /*0x1039b0d15*/
    }
LABEL_75:
    v57 = 3; /*0x1039b0dd8*/
    goto LABEL_90; /*0x1039b0ddd*/
  }
  if ( *(_DWORD *)(v7 + 120) != 2 ) /*0x1039b0c83*/
    return; /*0x1039b0c83*/
  if ( *(_QWORD *)(v7 + 48) >= *(_QWORD *)(v43 + 48) ) /*0x1039b0c92*/
    goto LABEL_89; /*0x1039b0c92*/
  v45 = *(_DWORD *)(v7 + 104); /*0x1039b0c98*/
  v46 = *(_DWORD *)(v7 + 108); /*0x1039b0c9c*/
  v47 = v46 + 15; /*0x1039b0ca0*/
  if ( v46 - v46 / 16 <= v45 ) /*0x1039b0cb6*/
    goto LABEL_89; /*0x1039b0cb6*/
  if ( v46 >= 0 ) /*0x1039b0cbe*/
    v47 = *(_DWORD *)(v7 + 108); /*0x1039b0cbe*/
  if ( v45 <= (v47 >> 4) + v46 && v45 >= v46 - (v47 >> 4) ) /*0x1039b0cd6*/
  {
    v48 = 3 * v46 + 3; /*0x1039b0ce8*/
    if ( 3 * v46 >= 0 ) /*0x1039b0ced*/
      v48 = 3 * v46; /*0x1039b0ced*/
    v49 = v48 >> 2; /*0x1039b0cf0*/
    goto LABEL_62; /*0x1039b0cf3*/
  }
}

// Address: 0x1039b0ea8 | Name: __ZN6RakNet22CCRakNetSlidingWindow214updateRangeNakERN5boost15circular_bufferINS0_12RttRangeInfoENSt3__19allocatorIS3_EEEEji
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::updateRangeNak(__int64 a1, __int64 a2, int a3, int a4)
{
  __int64 result; // rax

  result = RakNet::CCRakNetSlidingWindow2::findRange(a1, a2, a3); /*0x1039b0eb0*/
  if ( result != 0 ) /*0x1039b0eb8*/
    *(_QWORD *)(result + 36) = _mm_add_epi32( /*0x1039b0ed2*/
                                 _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), a4, 1),
                                 _mm_loadl_epi64((const __m128i *)(result + 36))).u64[0];
  return result; /*0x1039b0edb*/
}

// Address: 0x1039b0ede | Name: __ZN6RakNet22CCRakNetSlidingWindow214ackSpeed_last4Ev
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(RakNet::CCRakNetSlidingWindow2 *this)
{
  unsigned __int64 v1; // rcx
  __int64 result; // rax
  int v3; // edx
  int v4; // esi
  int v5; // ecx
  int v6; // r8d
  int v7; // eax
  __int64 v8; // r9
  __int64 v9; // r10
  unsigned int v10; // edx

  v1 = *((_QWORD *)this + 29); /*0x1039b0ede*/
  result = 0xFFFFFFFFLL; /*0x1039b0ee5*/
  if ( v1 >= 2 && (int)v1 >= 2 ) /*0x1039b0ef7*/
  {
    v3 = v1 - 2; /*0x1039b0f02*/
    v4 = *((_DWORD *)this + 29); /*0x1039b0f05*/
    v5 = v1 - v4; /*0x1039b0f08*/
    v6 = 0; /*0x1039b0f0a*/
    v7 = -1; /*0x1039b0f0d*/
    do /*0x1039b0f75*/
    {
      if ( v4 != 0 && v3 < v5 ) /*0x1039b0f18*/
        break; /*0x1039b0f18*/
      v8 = (unsigned int)v3; /*0x1039b0f1a*/
      v9 = *((_QWORD *)this + 27); /*0x1039b0f24*/
      if ( (*((_QWORD *)this + 26) - v9) >> 7 <= (unsigned int)v3 ) /*0x1039b0f38*/
        v8 = (unsigned int)v3 - ((__int64)(*((_QWORD *)this + 26) - *((_QWORD *)this + 25)) >> 7); /*0x1039b0f45*/
      if ( v7 <= *(_DWORD *)(v9 + (v8 << 7) + 108) ) /*0x1039b0f57*/
        v7 = *(_DWORD *)(v9 + (v8 << 7) + 108); /*0x1039b0f57*/
      if ( v3 <= 0 ) /*0x1039b0f5d*/
        break; /*0x1039b0f5d*/
      --v3; /*0x1039b0f6c*/
      v6 = v6 - *(unsigned __int8 *)(v9 + (v8 << 7) + 124) + 1; /*0x1039b0f6e*/
    }
    while ( v6 < 4 ); /*0x1039b0f75*/
    v10 = 0; /*0x1039b0f7c*/
    if ( v7 >= 32769 ) /*0x1039b0f83*/
      v10 = (unsigned int)v7 >> 6; /*0x1039b0f83*/
    return v7 - v10; /*0x1039b0f86*/
  }
  return result; /*0x1039b0f8a*/
}

// Address: 0x1039b0f8c | Name: __ZN6RakNet22CCRakNetSlidingWindow213getSpeedLimitEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::getSpeedLimit(RakNet::CCRakNetSlidingWindow2 *this)
{
  __int64 RttMicroMin; // rax
  __int64 result; // rax

  RttMicroMin = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this); /*0x1039b0f95*/
  if ( RttMicroMin == -1 ) /*0x1039b0f9e*/
    return 0xFFFFFFFFLL; /*0x1039b0fdd*/
  result = 1000000 * FInt::RakNetResendBufferArrayLength * (__int64)(*((_DWORD *)this + 2) + 58) / (RttMicroMin + 20000); /*0x1039b0fc9*/
  if ( DFInt::RakNetUseSlidingWindow2_maxSpeed != 0 && DFInt::RakNetUseSlidingWindow2_maxSpeed < (int)result ) /*0x1039b0fd8*/
    return (unsigned int)DFInt::RakNetUseSlidingWindow2_maxSpeed; /*0x1039b0fd8*/
  return result; /*0x1039b0fe6*/
}

// Address: 0x1039b0fea | Name: __ZN6RakNet22CCRakNetSlidingWindow27cleanUpEx
unsigned __int64 __fastcall RakNet::CCRakNetSlidingWindow2::cleanUp(RakNet::CCRakNetSlidingWindow2 *this, __int64 a2)
{
  unsigned __int64 result; // rax
  signed __int64 v4; // r14
  __int64 v5; // rax
  __int64 v6; // rcx

  result = *((_QWORD *)this + 29); /*0x1039b0fea*/
  if ( result >= 3 ) /*0x1039b0ff5*/
  {
    v4 = a2 - 1000LL * DFInt::RakNetUseSlidingWindow2_trackLengthMs; /*0x1039b1016*/
    v5 = result - 3; /*0x1039b1019*/
    v6 = *((_QWORD *)this + 27); /*0x1039b1024*/
    if ( (*((_QWORD *)this + 26) - v6) >> 7 <= v5 ) /*0x1039b1038*/
      v5 -= (*((_QWORD *)this + 26) - *((_QWORD *)this + 25)) >> 7; /*0x1039b1045*/
    result = *(_QWORD *)(v6 + (v5 << 7) + 64); /*0x1039b104c*/
    if ( (__int64)result < v4 ) /*0x1039b1054*/
      v4 = result; /*0x1039b1056*/
    while ( *((_QWORD *)this + 24) != 0 ) /*0x1039b1070*/
    {
      result = *((_QWORD *)this + 23); /*0x1039b105b*/
      if ( *(_QWORD *)(result + 24) >= v4 ) /*0x1039b1066*/
        break; /*0x1039b1066*/
      result = RakNet::CCRakNetSlidingWindow2::removeFront(this); /*0x1039b106b*/
    }
  }
  return result; /*0x1039b107e*/
}

// Address: 0x1039b1080 | Name: __ZN6RakNet22CCRakNetSlidingWindow211removeFrontEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::removeFront(RakNet::CCRakNetSlidingWindow2 *this)
{
  char *v2; // rax
  char *v3; // rdi
  __int128 v4; // xmm0
  __int128 v5; // xmm1
  char *v6; // rcx
  int v7; // eax
  __int64 v8; // rax
  _QWORD *v9; // rcx
  __int64 result; // rax
  __int128 v11; // [rsp+0h] [rbp-50h] BYREF
  __int128 v12; // [rsp+10h] [rbp-40h]
  __int128 v13; // [rsp+20h] [rbp-30h]
  __int64 v14; // [rsp+30h] [rbp-20h]

  v2 = (char *)this + 176; /*0x1039b108e*/
  v3 = *((char **)this + 23); /*0x1039b1095*/
  v14 = *((_QWORD *)v3 + 8); /*0x1039b10a0*/
  v4 = *((_OWORD *)v3 + 1); /*0x1039b10a4*/
  v5 = *((_OWORD *)v3 + 2); /*0x1039b10a8*/
  v13 = *((_OWORD *)v3 + 3); /*0x1039b10b0*/
  v12 = v5; /*0x1039b10b4*/
  v11 = v4; /*0x1039b10b8*/
  v6 = *((char **)this + 31); /*0x1039b10bc*/
  if ( v6 != v2 ) /*0x1039b10c6*/
  {
    if ( v6 == v3 ) /*0x1039b10cb*/
    {
      *((_OWORD *)this + 21) = 0; /*0x1039b10fa*/
      *((_QWORD *)this + 31) = v2; /*0x1039b10fd*/
    }
    else
    {
      --*((_DWORD *)this + 84); /*0x1039b10cd*/
      v7 = DWORD1(v11); /*0x1039b10d3*/
      *((_DWORD *)this + 85) -= DWORD1(v11); /*0x1039b10d6*/
      if ( (_DWORD)v11 != -1 ) /*0x1039b10e0*/
      {
        --*((_DWORD *)this + 86); /*0x1039b10e2*/
        *((_DWORD *)this + 87) -= v7; /*0x1039b10e8*/
      }
    }
  }
  v8 = *(_QWORD *)v3; /*0x1039b1104*/
  v9 = *((_QWORD **)v3 + 1); /*0x1039b1107*/
  *(_QWORD *)(v8 + 8) = v9; /*0x1039b110b*/
  *v9 = v8; /*0x1039b110f*/
  --*((_QWORD *)this + 24); /*0x1039b1112*/
  operator delete(a1: v3); /*0x1039b1119*/
  if ( (_DWORD)v11 == -1 ) /*0x1039b1122*/
  {
    result = DWORD1(v11); /*0x1039b116f*/
  }
  else
  {
    std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::__erase_unique<unsigned int>( /*0x1039b1132*/
      a1: (char *)this + 280,
      a2: &v11);
    --*((_DWORD *)this + 82); /*0x1039b1137*/
    result = DWORD1(v11); /*0x1039b113d*/
    *((_DWORD *)this + 83) -= DWORD1(v11); /*0x1039b1141*/
    if ( (_QWORD)v12 != 0 ) /*0x1039b114c*/
    {
      --*((_DWORD *)this + 88); /*0x1039b114e*/
      *((_DWORD *)this + 89) -= result; /*0x1039b1154*/
    }
    if ( *((_QWORD *)&v12 + 1) != 0 ) /*0x1039b115f*/
    {
      --*((_DWORD *)this + 90); /*0x1039b1161*/
      *((_DWORD *)this + 91) -= result; /*0x1039b1167*/
    }
  }
  --*((_DWORD *)this + 80); /*0x1039b1172*/
  *((_DWORD *)this + 81) -= result; /*0x1039b1178*/
  return result; /*0x1039b117e*/
}

// Address: 0x1039b1188 | Name: __ZN6RakNet22CCRakNetSlidingWindow28lossRateEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::lossRate(RakNet::CCRakNetSlidingWindow2 *this)
{
  int v1; // ecx

  v1 = *((_DWORD *)this + 86); /*0x1039b118c*/
  if ( v1 != 0 ) /*0x1039b1194*/
    return (unsigned int)(100 - 100 * *((_DWORD *)this + 88) / v1); /*0x1039b11a7*/
  else
    return 0; /*0x1039b11ab*/
}

// Address: 0x1039b11b0 | Name: __ZN6RakNet22CCRakNetSlidingWindow225GetCongestionManagerStatsERNS_13CCRakNetStatsE
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::GetCongestionManagerStats(
        RakNet::CCRakNetSlidingWindow2 *this,
        __int64 a2)
{
  __int64 RttMicroMin; // rax
  int v5; // ecx
  __int64 result; // rax

  *(_DWORD *)a2 = 8 * (*((_DWORD *)this + 102) / DFInt::RakNetLoopMs / 1000); /*0x1039b11e6*/
  *(_DWORD *)(a2 + 4) = 8 * ((int)RakNet::CCRakNetSlidingWindow2::ackSpeed_last4(this) / 1000); /*0x1039b1206*/
  RttMicroMin = RakNet::CCRakNetSlidingWindow2::getRttMicroMin(this); /*0x1039b120c*/
  *(_DWORD *)(a2 + 8) = ((unsigned __int64)((unsigned __int128)(0x20C49BA5E353F7CFLL * (__int128)RttMicroMin) >> 64) >> 63) /*0x1039b122b*/
                      + RttMicroMin / 1000;
  LODWORD(RttMicroMin) = *((_DWORD *)this + 83); /*0x1039b122e*/
  *(_DWORD *)(a2 + 12) = (int)RttMicroMin / 1000; /*0x1039b1249*/
  v5 = *((_DWORD *)this + 89); /*0x1039b124c*/
  *(_DWORD *)(a2 + 16) = v5 / 1000; /*0x1039b1267*/
  result = (unsigned int)(RttMicroMin - (v5 + *((_DWORD *)this + 91))); /*0x1039b1273*/
  *(_DWORD *)(a2 + 20) = result; /*0x1039b1275*/
  *(_BYTE *)(a2 + 24) = *((_QWORD *)this + 53) != 0; /*0x1039b1280*/
  return result; /*0x1039b1284*/
}

// Address: 0x1039b128a | Name: __ZN6RakNet22CCRakNetSlidingWindow216sortAckedSeqenceERNSt3__16vectorINS1_4pairIjNS1_15__list_iteratorINS_7PktInfoEPvEEEENS1_9allocatorIS8_EEEE
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::sortAckedSeqence(__int64 a1, __int64 *a2)
{
  __int64 v2; // rdi
  __int64 v3; // rsi
  __int64 result; // rax
  __int64 v5; // rcx
  __int64 v6; // rdx
  unsigned __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rdx

  v2 = *a2; /*0x1039b128e*/
  v3 = a2[1]; /*0x1039b1291*/
  result = v2; /*0x1039b1295*/
  if ( v2 == v3 ) /*0x1039b129b*/
  {
LABEL_6:
    if ( result != v3 ) /*0x1039b12c3*/
    {
      _BitScanReverse64(&v7, (v3 - v2) >> 4); /*0x1039b12cf*/
      v8 = (2 * ((unsigned int)v7 ^ 0x3F)) ^ 0x7ELL; /*0x1039b12d8*/
      v9 = 0; /*0x1039b12dc*/
      if ( v3 != v2 ) /*0x1039b12e1*/
        v9 = v8; /*0x1039b12e1*/
      return std::__introsort<std::_ClassicAlgPolicy,RakNet::CCRakNetSlidingWindow2::sortAckedSeqence(std::vector<std::pair<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>> &)::$_1 &,std::pair<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>*,false>( /*0x1039b12eb*/
               a1: v2,
               a2: v3,
               a3: v9,
               a4: 1);
    }
  }
  else
  {
    result = v2 + 16; /*0x1039b129d*/
    while ( result != v3 ) /*0x1039b12a4*/
    {
      v5 = *(_QWORD *)(result - 8); /*0x1039b12a6*/
      v6 = *(_QWORD *)(*(_QWORD *)(result + 8) + 24LL); /*0x1039b12ae*/
      result += 16; /*0x1039b12b2*/
      if ( v6 < *(_QWORD *)(v5 + 24) ) /*0x1039b12ba*/
      {
        result -= 16; /*0x1039b12bc*/
        goto LABEL_6; /*0x1039b12bc*/
      }
    }
  }
  return result; /*0x1039b12ea*/
}

// Address: 0x1039b13e8 | Name: __ZN6RakNet22CCRakNetSlidingWindow28OnAckEndEjj
unsigned __int64 __fastcall RakNet::CCRakNetSlidingWindow2::OnAckEnd(__m128i *this, unsigned int a2, unsigned int a3)
{
  __int64 v4; // rsi
  unsigned __int64 result; // rax
  unsigned int v6; // r12d
  __m128i *v7; // rbx
  __int64 *v8; // r9
  __int64 v9; // r14
  __int64 v10; // r15
  __int64 v11; // r14
  __int64 *v12; // r12
  __int64 v13; // rax
  __int64 v14; // rcx
  unsigned int *v15; // rdx
  char *v16; // rsi
  __int64 *v17; // r15
  __int64 v18; // rdx
  __int64 v19; // rdi
  __int64 v20; // r8
  __int64 v21; // rax
  __int64 v22; // rsi
  __int64 v23; // r14
  __int64 v24; // r12
  __int64 v25; // r13
  __int64 v26; // r15
  __int64 v27; // rbx
  __int64 Range; // rax
  __int64 v29; // rcx
  __int64 v30; // rax
  __int64 v31; // rax
  __int64 v32; // r13
  __int64 v33; // r14
  unsigned __int64 v34; // r12
  __int64 v35; // r15
  __int64 v36; // rax
  __m128i *v37; // [rsp+8h] [rbp-78h]
  __int64 v38; // [rsp+10h] [rbp-70h]
  __int64 v39; // [rsp+18h] [rbp-68h]
  __int64 v40; // [rsp+20h] [rbp-60h]
  char *v41; // [rsp+28h] [rbp-58h]
  __int64 v42; // [rsp+28h] [rbp-58h]
  __int64 v43; // [rsp+30h] [rbp-50h]
  int v44; // [rsp+30h] [rbp-50h]
  __int64 v46; // [rsp+38h] [rbp-48h]
  __int64 v47; // [rsp+40h] [rbp-40h]
  unsigned __int64 v48; // [rsp+48h] [rbp-38h]
  unsigned __int64 v49; // [rsp+48h] [rbp-38h]
  char v50; // [rsp+50h] [rbp-30h]
  __int64 v51; // [rsp+50h] [rbp-30h]

  v4 = *((_QWORD *)this + 16); /*0x1039b13fc*/
  result = *((_QWORD *)this + 17); /*0x1039b1403*/
  if ( v4 != result ) /*0x1039b140d*/
  {
    v6 = a3; /*0x1039b1413*/
    v7 = this; /*0x1039b1416*/
    v8 = (__int64 *)(this + 8); /*0x1039b1419*/
    v9 = *((_QWORD *)this + 20); /*0x1039b1427*/
    v48 = *((_QWORD *)this + 19); /*0x1039b142e*/
    *((_QWORD *)this + 20) = v48; /*0x1039b1432*/
    *((_DWORD *)this + 42) = *(_DWORD *)(result - 16); /*0x1039b1445*/
    *((_QWORD *)this + 19) = 0; /*0x1039b144b*/
    if ( (int)((result - v4) >> 4) > 0 ) /*0x1039b1462*/
    {
      v43 = v9; /*0x1039b1470*/
      v41 = (char *)(this + 11); /*0x1039b1482*/
      v10 = 0; /*0x1039b1486*/
      v11 = 0; /*0x1039b1489*/
      v50 = 0; /*0x1039b148c*/
      do /*0x1039b14f1*/
      {
        v12 = v8; /*0x1039b1494*/
        v13 = std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::find<unsigned int>(a1: &v7[17].u64[1]); /*0x1039b149d*/
        v8 = v12; /*0x1039b14a2*/
        if ( v13 != 0 ) /*0x1039b14a8*/
        {
          *(_QWORD *)(*v12 + v10 + 8) = *(_QWORD *)(v13 + 24); /*0x1039b14b2*/
        }
        else
        {
          *(_QWORD *)(*v12 + v10 + 8) = v41; /*0x1039b14c1*/
          v50 = 1; /*0x1039b14c8*/
        }
        ++v11; /*0x1039b14cc*/
        v4 = v7[8].i64[0]; /*0x1039b14cf*/
        result = v7[8].u64[1]; /*0x1039b14d6*/
        v10 += 16; /*0x1039b14ea*/
      }
      while ( v11 < (int)((result - v4) >> 4) ); /*0x1039b14f1*/
      if ( (v50 & 1) != 0 ) /*0x1039b14f7*/
      {
        v14 = v7[8].i64[0]; /*0x1039b14fd*/
        v9 = v43; /*0x1039b1503*/
        v6 = a3; /*0x1039b1507*/
        if ( v4 != result ) /*0x1039b1513*/
        {
          v14 = v7[8].i64[0]; /*0x1039b1515*/
          do /*0x1039b1525*/
          {
            if ( *(char **)(v14 + 8) == v41 ) /*0x1039b151c*/
              break; /*0x1039b151c*/
            v14 += 16; /*0x1039b151e*/
          }
          while ( v14 != result ); /*0x1039b1525*/
        }
        LOBYTE(this) = v14 == result; /*0x1039b152a*/
        v15 = (unsigned int *)(v14 + 16); /*0x1039b152e*/
        if ( v14 != result && v14 + 16 != result ) /*0x1039b1535*/
        {
          do /*0x1039b155a*/
          {
            v16 = *((char **)v15 + 1); /*0x1039b153e*/
            if ( v16 != v41 ) /*0x1039b1545*/
            {
              this = (__m128i *)*v15; /*0x1039b1547*/
              *(_DWORD *)v14 = (_DWORD)this; /*0x1039b1549*/
              *(_QWORD *)(v14 + 8) = v16; /*0x1039b154b*/
              v14 += 16; /*0x1039b154f*/
            }
            v15 += 4; /*0x1039b1553*/
          }
          while ( v15 != (unsigned int *)result ); /*0x1039b155a*/
          v4 = v7[8].i64[0]; /*0x1039b155c*/
          result = v7[8].u64[1]; /*0x1039b1563*/
        }
        if ( v14 != result ) /*0x1039b156d*/
        {
          v7[8].i64[1] = v14; /*0x1039b15b8*/
          result = v14; /*0x1039b15bf*/
        }
      }
      else
      {
        v9 = v43; /*0x1039b15a1*/
        v6 = a3; /*0x1039b15a5*/
      }
    }
    if ( v4 != result ) /*0x1039b15c5*/
    {
      v17 = v8; /*0x1039b15ce*/
      RakNet::CCRakNetSlidingWindow2::sortAckedSeqence(a1: (__int64)this, a2: v8); /*0x1039b15d1*/
      if ( a2 == 0 || v6 == 0 ) /*0x1039b15df*/
      {
        if ( v9 != 0 /*0x1039b164d*/
          && (__int64)(v48 - v9) < 30000
          && (v21 = std::__hash_table<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::__unordered_map_hasher<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::hash<unsigned int>,std::equal_to<unsigned int>,true>,std::__unordered_map_equal<unsigned int,std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>,std::equal_to<unsigned int>,std::hash<unsigned int>,true>,std::allocator<std::__hash_value_type<unsigned int,std::__list_iterator<RakNet::PktInfo,void *>>>>::find<unsigned int>(a1: &v7[17].u64[1])) != 0
          && (result = *(_QWORD *)(v21 + 24), (v19 = *(_QWORD *)(result + 24)) != 0) )
        {
          v18 = *v17; /*0x1039b164f*/
        }
        else
        {
          v18 = *v17; /*0x1039b1654*/
          v19 = *(_QWORD *)(*(_QWORD *)(*v17 + 8) + 24LL); /*0x1039b165b*/
          result = v48; /*0x1039b165f*/
          v9 = v48 - 10000; /*0x1039b1663*/
        }
        v20 = v19 + 1; /*0x1039b166a*/
        if ( v9 >= v19 ) /*0x1039b1671*/
          v20 = v9; /*0x1039b1671*/
      }
      else
      {
        v18 = *v17; /*0x1039b15e6*/
        v19 = *(_QWORD *)(*(_QWORD *)(*v17 + 8) + 24LL); /*0x1039b15ed*/
        v20 = v48 - a2; /*0x1039b15fb*/
        result = v6; /*0x1039b15fe*/
        v48 -= v6; /*0x1039b1604*/
      }
      v22 = v7[8].i64[1]; /*0x1039b1675*/
      if ( v22 == v18 ) /*0x1039b167f*/
      {
        v7[24].i64[0] = 1; /*0x1039b17f0*/
      }
      else
      {
        v49 = v48 - v20; /*0x1039b1694*/
        v42 = *(_QWORD *)(*(_QWORD *)(v22 - 8) + 24LL); /*0x1039b1698*/
        v38 = v42 - v19; /*0x1039b169f*/
        v23 = ((v22 - v18) >> 4 == 0) + ((v22 - v18) >> 4); /*0x1039b16a7*/
        v40 = (__int64)&v7[12].i64[1]; /*0x1039b16b2*/
        v39 = v18; /*0x1039b16b6*/
        v24 = v18 + 8; /*0x1039b16ba*/
        v51 = 0; /*0x1039b16be*/
        v37 = v7; /*0x1039b16c6*/
        v46 = v7[8].i64[1]; /*0x1039b16ca*/
        v47 = v20; /*0x1039b16ce*/
        do /*0x1039b17c7*/
        {
          v25 = *(_QWORD *)v24; /*0x1039b16d2*/
          if ( *(_QWORD *)(*(_QWORD *)v24 + 32LL) != 0 ) /*0x1039b16db*/
          {
            *(_DWORD *)(v24 - 8) = -1; /*0x1039b16dd*/
          }
          else
          {
            ++v7[24].i32[2]; /*0x1039b16eb*/
            v26 = v20; /*0x1039b16f1*/
            if ( v42 != v19 ) /*0x1039b16f8*/
              v26 = v20 + (__int64)(v49 * (*(_QWORD *)(v25 + 24) - v19)) / v38; /*0x1039b170f*/
            if ( *(_QWORD *)(v25 + 40) != 0 ) /*0x1039b1717*/
            {
              *(_QWORD *)(v25 + 40) = 0; /*0x1039b1719*/
              --v7[22].i32[2]; /*0x1039b1721*/
              v44 = *(_DWORD *)(v25 + 20); /*0x1039b172b*/
              v7[22].i32[3] -= v44; /*0x1039b172e*/
              v27 = v19; /*0x1039b173c*/
              Range = RakNet::CCRakNetSlidingWindow2::findRange(a1: v19, a2: v40, a3: *(_DWORD *)(v25 + 16)); /*0x1039b173f*/
              v20 = v47; /*0x1039b1744*/
              v19 = v27; /*0x1039b1748*/
              v22 = v46; /*0x1039b174b*/
              v7 = v37; /*0x1039b174f*/
              if ( Range != 0 ) /*0x1039b1756*/
              {
                --*(_DWORD *)(Range + 36); /*0x1039b1758*/
                *(_DWORD *)(Range + 40) -= v44; /*0x1039b175e*/
              }
            }
            if ( v26 > *(_QWORD *)(v25 + 24) ) /*0x1039b1768*/
            {
              v29 = v26 - *(_QWORD *)(v25 + 24); /*0x1039b1771*/
              if ( v51 < v29 ) /*0x1039b1774*/
                v29 = v51; /*0x1039b1774*/
              if ( v51 == 0 ) /*0x1039b177b*/
                v29 = v26 - *(_QWORD *)(v25 + 24); /*0x1039b177b*/
              v51 = v29; /*0x1039b177f*/
            }
            *(_QWORD *)(v25 + 32) = v26; /*0x1039b1783*/
            v30 = *(int *)(v25 + 20); /*0x1039b1787*/
            v7[22].i64[0] = _mm_add_epi32( /*0x1039b17a6*/
                              _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), v30, 1),
                              _mm_loadl_epi64(v7 + 22)).u64[0];
            v31 = v7[23].i64[1] + v30; /*0x1039b17ae*/
            v7[23].i64[1] = v31; /*0x1039b17b5*/
            *(_QWORD *)(v25 + 64) = v31; /*0x1039b17bc*/
          }
          v24 += 16; /*0x1039b17c0*/
          --v23; /*0x1039b17c4*/
        }
        while ( v23 != 0 ); /*0x1039b17c7*/
        v32 = v51; /*0x1039b17cd*/
        result = 1; /*0x1039b17d5*/
        if ( v51 >= 2 ) /*0x1039b17da*/
          result = v51; /*0x1039b17da*/
        v7[24].i64[0] = result; /*0x1039b17de*/
        v18 = v39; /*0x1039b17e8*/
        if ( v51 > 0 ) /*0x1039b17ec*/
          goto LABEL_54; /*0x1039b17ec*/
      }
      v32 = 5000; /*0x1039b17fb*/
LABEL_54:
      if ( v22 != v18 ) /*0x1039b1804*/
      {
        v33 = 8; /*0x1039b1815*/
        v34 = 0; /*0x1039b181b*/
        do /*0x1039b188d*/
        {
          if ( *(_DWORD *)(v18 + v33 - 8) != -1 ) /*0x1039b1824*/
          {
            v35 = *(_QWORD *)(v18 + v33); /*0x1039b1826*/
            v36 = *(_QWORD *)(v35 + 24); /*0x1039b182a*/
            if ( v32 > *(_QWORD *)(v35 + 32) - v36 ) /*0x1039b1838*/
              *(_QWORD *)(v35 + 32) = v32 + v36; /*0x1039b183d*/
            RakNet::CCRakNetSlidingWindow2::setLastAck(a1: v7, a2: v35); /*0x1039b1847*/
            RakNet::CCRakNetSlidingWindow2::updateRangeAck( /*0x1039b1866*/
              this: (RakNet::CCRakNetSlidingWindow2 *)v7,
              a2: &v7[12].i64[1],
              a3: *(unsigned int *)(v35 + 16),
              a4: *(_DWORD *)(v35 + 20),
              a5: *(_QWORD *)(v35 + 32),
              a6: *(_QWORD *)(v35 + 32) - *(_QWORD *)(v35 + 24));
            v18 = v7[8].i64[0]; /*0x1039b186b*/
            v22 = v7[8].i64[1]; /*0x1039b1872*/
          }
          ++v34; /*0x1039b1879*/
          result = (v22 - v18) >> 4; /*0x1039b1882*/
          v33 += 16; /*0x1039b1886*/
        }
        while ( v34 < result ); /*0x1039b188d*/
      }
      v7[8].i64[1] = v18; /*0x1039b188f*/
    }
  }
  return result; /*0x1039b1896*/
}

// Address: 0x1039b18a6 | Name: __ZN6RakNet22CCRakNetSlidingWindow210setLastAckENSt3__115__list_iteratorINS_7PktInfoEPvEE
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::setLastAck(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  __m128i inserted; // xmm0
  __m128i v4; // xmm0
  __m128i v5; // xmm1
  __m128i v6; // xmm2

  result = *(_QWORD *)(a1 + 248); /*0x1039b18ad*/
  if ( result == a1 + 176 ) /*0x1039b18b7*/
  {
    result = *(_QWORD *)(a1 + 184); /*0x1039b18c2*/
    *(_QWORD *)(a1 + 248) = result; /*0x1039b18c9*/
    inserted = _mm_insert_epi32(_mm_cvtepi8_epi32(16843009), *(_DWORD *)(result + 20), 1); /*0x1039b18e1*/
    *(_QWORD *)(a1 + 336) = _mm_add_epi32(_mm_loadl_epi64((const __m128i *)(a1 + 336)), inserted).u64[0]; /*0x1039b18ec*/
    if ( *(_DWORD *)(result + 16) != -1 ) /*0x1039b18f8*/
      *(_QWORD *)(a1 + 344) = _mm_add_epi32(_mm_loadl_epi64((const __m128i *)(a1 + 344)), inserted).u64[0]; /*0x1039b1906*/
  }
  else if ( *(_DWORD *)(a2 + 48) <= *(_DWORD *)(result + 48) ) /*0x1039b18bf*/
  {
    return result; /*0x1039b18bf*/
  }
  if ( result != a2 ) /*0x1039b1911*/
  {
    v4 = _mm_loadl_epi64((const __m128i *)(a1 + 336)); /*0x1039b1917*/
    v5 = _mm_cvtepi8_epi32(16843009); /*0x1039b191f*/
    do /*0x1039b1958*/
    {
      result = *(_QWORD *)(result + 8); /*0x1039b1928*/
      v6 = _mm_insert_epi32(v5, *(_DWORD *)(result + 20), 1); /*0x1039b1930*/
      if ( *(_DWORD *)(result + 16) != -1 ) /*0x1039b193b*/
        *(_QWORD *)(a1 + 344) = _mm_add_epi32(_mm_loadl_epi64((const __m128i *)(a1 + 344)), v6).u64[0]; /*0x1039b1949*/
      v4 = _mm_add_epi32(v4, v6); /*0x1039b1951*/
    }
    while ( result != a2 ); /*0x1039b1958*/
    *(_QWORD *)(a1 + 248) = result; /*0x1039b195a*/
    *(_QWORD *)(a1 + 336) = v4.i64[0]; /*0x1039b1961*/
  }
  return result; /*0x1039b18c1*/
}

// Address: 0x1039b196c | Name: __ZNK6RakNet22CCRakNetSlidingWindow216GetIsInSlowStartEv
char __fastcall RakNet::CCRakNetSlidingWindow2::GetIsInSlowStart(RakNet::CCRakNetSlidingWindow2 *this)
{
  return _mm_cvtsi128_si32((__m128i)_mm_or_pd( /*0x1039b1992*/
                                      _mm_cmple_pd(
                                        (__m128d)*((unsigned __int64 *)this + 3),
                                        (__m128d)*((unsigned __int64 *)this + 4)),
                                      _mm_cmpeq_pd((__m128d)0LL, (__m128d)*((unsigned __int64 *)this + 4))))
       & 1;
}

// Address: 0x1039b1994 | Name: __ZNK6RakNet22CCRakNetSlidingWindow229includeTimestampWithDatagramsEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow2::includeTimestampWithDatagrams(RakNet::CCRakNetSlidingWindow2 *this)
{
  return 0; /*0x1039b199a*/
}

// END CCRakNetSlidingWindow2 part 1/1, 64 functions
