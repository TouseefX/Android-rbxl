// CCRakNetSlidingWindow -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 36 functions


// Address: 0x1039adef6 | Name: __ZN6RakNet21CCRakNetSlidingWindowC2Ev
void (__fastcall **__fastcall RakNet::CCRakNetSlidingWindow::CCRakNetSlidingWindow(
        RakNet::CCRakNetSlidingWindow *this))(RakNet::CCRakNetSlidingWindow *__hidden this)
{
  *(_QWORD *)this = off_10C9029F0; /*0x1039adf01*/
  return off_10C9029F0; /*0x1039adf04*/
}

// Address: 0x1039adf06 | Name: __ZN6RakNet21CCRakNetSlidingWindowC1Ev
void (__fastcall **__fastcall RakNet::CCRakNetSlidingWindow::CCRakNetSlidingWindow(
        RakNet::CCRakNetSlidingWindow *this))(RakNet::CCRakNetSlidingWindow *__hidden this)
{
  *(_QWORD *)this = off_10C9029F0; /*0x1039adf11*/
  return off_10C9029F0; /*0x1039adf14*/
}

// Address: 0x1039adf16 | Name: __ZN6RakNet21CCRakNetSlidingWindowD2Ev
void __fastcall RakNet::CCRakNetSlidingWindow::~CCRakNetSlidingWindow(RakNet::CCRakNetSlidingWindow *this)
{
  ; /*0x1039adf16*/
}

// Address: 0x1039adf1c | Name: __ZN6RakNet21CCRakNetSlidingWindowD1Ev
void __fastcall RakNet::CCRakNetSlidingWindow::~CCRakNetSlidingWindow(RakNet::CCRakNetSlidingWindow *this)
{
  ; /*0x1039adf1c*/
}

// Address: 0x1039adf22 | Name: __ZN6RakNet21CCRakNetSlidingWindowD0Ev
void __fastcall RakNet::CCRakNetSlidingWindow::~CCRakNetSlidingWindow(RakNet::CCRakNetSlidingWindow *this)
{
  operator delete(a1: this); /*0x1039adf27*/
}

// Address: 0x1039adf2c | Name: __ZN6RakNet21CCRakNetSlidingWindow4InitEyj
__int64 __fastcall RakNet::CCRakNetSlidingWindow::Init(
        RakNet::CCRakNetSlidingWindow *this,
        unsigned __int64 a2,
        int a3)
{
  __int64 result; // rax

  *((_QWORD *)this + 2) = 0xBFF0000000000000LL; /*0x1039adf36*/
  *((_DWORD *)this + 2) = a3; /*0x1039adf41*/
  *((double *)this + 3) = (double)a3; /*0x1039adf44*/
  result = (unsigned int)DFInt::RakNetConnectionStartWindow_HundredthsPercentage; /*0x1039adf49*/
  if ( DFInt::RakNetConnectionStartWindow_HundredthsPercentage != 0 /*0x1039adf59*/
    && DFInt::RakNetConnectionStartWindow_HundredthsPercentage < 10001 )
  {
    *((double *)this + 3) = (double)DFInt::RakNetConnectionStartWindow_HundredthsPercentage /*0x1039adf83*/
                          / 10000.0
                          * (double)FInt::RakNetResendBufferArrayLength
                          * (double)a3;
  }
  *((_DWORD *)this + 15) = 0; /*0x1039adf89*/
  *((_BYTE *)this + 64) = 0; /*0x1039adf90*/
  *((_OWORD *)this + 2) = 0; /*0x1039adf98*/
  *(_OWORD *)((char *)this + 42) = 0; /*0x1039adf9d*/
  return result; /*0x1039adfa2*/
}

// Address: 0x1039adfa4 | Name: __ZN6RakNet21CCRakNetSlidingWindow20ResetCCWindowToDFIntEj
__int64 __fastcall RakNet::CCRakNetSlidingWindow::ResetCCWindowToDFInt(RakNet::CCRakNetSlidingWindow *this, int a2)
{
  __int64 result; // rax
  double v3; // xmm0_8

  result = (unsigned int)DFInt::RakNetConnectionStartWindow_HundredthsPercentage; /*0x1039adfa4*/
  if ( DFInt::RakNetConnectionStartWindow_HundredthsPercentage != 0 /*0x1039adfb4*/
    && DFInt::RakNetConnectionStartWindow_HundredthsPercentage < 10001 )
  {
    v3 = (double)DFInt::RakNetConnectionStartWindow_HundredthsPercentage /*0x1039adfda*/
       / 10000.0
       * (double)(FInt::RakNetResendBufferArrayLength * a2);
    if ( v3 > *((double *)this + 3) ) /*0x1039adfe3*/
      *((double *)this + 3) = v3; /*0x1039adfe5*/
  }
  return result; /*0x1039adfeb*/
}

// Address: 0x1039adfec | Name: __ZN6RakNet21CCRakNetSlidingWindow6UpdateEy
void __fastcall RakNet::CCRakNetSlidingWindow::Update(RakNet::CCRakNetSlidingWindow *this)
{
  ; /*0x1039adfec*/
}

// Address: 0x1039adff2 | Name: __ZN6RakNet21CCRakNetSlidingWindow26GetRetransmissionBandwidthEyyjbRNS_15TxBwInfluencersE
__int64 __fastcall RakNet::CCRakNetSlidingWindow::GetRetransmissionBandwidth(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        unsigned int a4)
{
  return a4; /*0x1039adff8*/
}

// Address: 0x1039adffa | Name: __ZN6RakNet21CCRakNetSlidingWindow24GetTransmissionBandwidthEyyjbRNS_15TxBwInfluencersE
__int64 __fastcall RakNet::CCRakNetSlidingWindow::GetTransmissionBandwidth(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        int a4,
        char a5)
{
  double v5; // xmm1_8
  __int64 result; // rax

  *(_BYTE *)(a1 + 64) = a5; /*0x1039adffe*/
  v5 = *(double *)(a1 + 24); /*0x1039ae009*/
  result = (unsigned int)(int)(v5 - (double)a4); /*0x1039ae018*/
  if ( v5 < (double)a4 ) /*0x1039ae01c*/
    return 0; /*0x1039ae01c*/
  return result; /*0x1039ae01f*/
}

// Address: 0x1039ae022 | Name: __ZN6RakNet21CCRakNetSlidingWindow49GetAvailableTransmissionCapacityBytesWithinWindowEffyy
__int64 __fastcall RakNet::CCRakNetSlidingWindow::GetAvailableTransmissionCapacityBytesWithinWindow(
        RakNet::CCRakNetSlidingWindow *this,
        float a2,
        float a3)
{
  return (unsigned int)(int)(float)((float)(a2 * 65536.0) / 1000.0); /*0x1039ae03a*/
}

// Address: 0x1039ae03c | Name: __ZN6RakNet21CCRakNetSlidingWindow14ShouldSendACKsEyy
bool __fastcall RakNet::CCRakNetSlidingWindow::ShouldSendACKs(RakNet::CCRakNetSlidingWindow *this, unsigned __int64 a2)
{
  bool result; // al

  result = true; /*0x1039ae04d*/
  if ( *((double *)this + 2) != -1.0 ) /*0x1039ae04f*/
    return *((_QWORD *)this + 5) + 10000LL <= a2; /*0x1039ae08c*/
  return result; /*0x1039ae08f*/
}

// Address: 0x1039ae092 | Name: __ZNK6RakNet21CCRakNetSlidingWindow18GetSenderRTOForACKEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow::GetSenderRTOForACK(RakNet::CCRakNetSlidingWindow *this)
{
  double v1; // xmm0_8
  __int64 result; // rax

  v1 = *((double *)this + 2); /*0x1039ae096*/
  result = -1; /*0x1039ae0ce*/
  if ( v1 != -1.0 ) /*0x1039ae0d5*/
    return (unsigned int)(int)(v1 + 10000.0); /*0x1039ae0d5*/
  return result; /*0x1039ae0dd*/
}

// Address: 0x1039ae0e0 | Name: __ZN6RakNet21CCRakNetSlidingWindow29GetNextDatagramSequenceNumberEv
RakNet::CCRakNetSlidingWindow *__fastcall RakNet::CCRakNetSlidingWindow::GetNextDatagramSequenceNumber(
        RakNet::CCRakNetSlidingWindow *this,
        __int64 a2)
{
  *(_DWORD *)this = *(_DWORD *)(a2 + 48); /*0x1039ae0ea*/
  return this; /*0x1039ae0ec*/
}

// Address: 0x1039ae0ee | Name: __ZN6RakNet21CCRakNetSlidingWindow41GetAndIncrementNextDatagramSequenceNumberEv
RakNet::CCRakNetSlidingWindow *__fastcall RakNet::CCRakNetSlidingWindow::GetAndIncrementNextDatagramSequenceNumber(
        RakNet::CCRakNetSlidingWindow *this,
        __int64 a2)
{
  int v3; // ecx

  v3 = *(_DWORD *)(a2 + 48); /*0x1039ae0f5*/
  *(_DWORD *)this = v3; /*0x1039ae0f8*/
  *(_DWORD *)(a2 + 48) = (v3 + 1) & 0xFFFFFF; /*0x1039ae102*/
  return this; /*0x1039ae105*/
}

// Address: 0x1039ae108 | Name: __ZN6RakNet21CCRakNetSlidingWindow11OnSendBytesEyj
void __fastcall RakNet::CCRakNetSlidingWindow::OnSendBytes(RakNet::CCRakNetSlidingWindow *this)
{
  ; /*0x1039ae108*/
}

// Address: 0x1039ae10e | Name: __ZN6RakNet21CCRakNetSlidingWindow11OnGotPacketENS_8uint24_tEbyjPj
char __fastcall RakNet::CCRakNetSlidingWindow::OnGotPacket(
        __int64 a1,
        _DWORD *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        unsigned int *a6)
{
  int v6; // edx
  unsigned int v8; // eax

  if ( *(_QWORD *)(a1 + 40) == 0 ) /*0x1039ae117*/
    *(_QWORD *)(a1 + 40) = a4; /*0x1039ae119*/
  v6 = *(_DWORD *)(a1 + 60); /*0x1039ae11f*/
  if ( *a2 == v6 ) /*0x1039ae126*/
  {
    *a6 = 0; /*0x1039ae128*/
    goto LABEL_5; /*0x1039ae128*/
  }
  if ( ((v6 - *a2) & 0x800000) == 0 ) /*0x1039ae143*/
  {
    *a6 = 0; /*0x1039ae145*/
    return 1; /*0x1039ae145*/
  }
  v8 = (*a2 - v6) & 0xFFFFFF; /*0x1039ae150*/
  *a6 = v8; /*0x1039ae155*/
  if ( v8 < 0x3E9 ) /*0x1039ae15d*/
  {
LABEL_5:
    *(_DWORD *)(a1 + 60) = (*a2 + 1) & 0xFFFFFF; /*0x1039ae12f*/
    return 1; /*0x1039ae14f*/
  }
  if ( v8 <= 0xC350 ) /*0x1039ae164*/
  {
    *a6 = 1000; /*0x1039ae16a*/
    goto LABEL_5; /*0x1039ae171*/
  }
  return 0; /*0x1039ae14e*/
}

// Address: 0x1039ae174 | Name: __ZN6RakNet21CCRakNetSlidingWindow11GreaterThanENS_8uint24_tES1_
_BOOL8 __fastcall RakNet::CCRakNetSlidingWindow::GreaterThan(_DWORD *a1, _DWORD *a2)
{
  return ((*a2 - *a1) & 0x800000) != 0; /*0x1039ae182*/
}

// Address: 0x1039ae184 | Name: __ZN6RakNet21CCRakNetSlidingWindow8OnResendEy
void __fastcall RakNet::CCRakNetSlidingWindow::OnResend(RakNet::CCRakNetSlidingWindow *this)
{
  double v1; // xmm0_8
  int v2; // eax
  double v3; // xmm1_8
  double v4; // xmm2_8

  if ( *((_BYTE *)this + 64) == 1 && *((_BYTE *)this + 56) == 0 ) /*0x1039ae18e*/
  {
    v1 = *((double *)this + 3); /*0x1039ae191*/
    v2 = *((_DWORD *)this + 2); /*0x1039ae196*/
    if ( v1 > (double)(2 * v2) ) /*0x1039ae1a5*/
    {
      if ( (unsigned int)(DFInt::RakNetResendScaleBackFactorHundredthsPercent - 1) > 0x270E ) /*0x1039ae1ba*/
      {
        v3 = (double)v2; /*0x1039ae1fc*/
        v4 = fmax((double)v2, v1 * 0.5); /*0x1039ae205*/
      }
      else
      {
        v3 = fmax((double)v2, v1 * ((10000.0 - (double)DFInt::RakNetResendScaleBackFactorHundredthsPercent) / 10000.0)); /*0x1039ae1e5*/
        v4 = v3; /*0x1039ae1e9*/
      }
      *((double *)this + 3) = v3; /*0x1039ae209*/
      *((double *)this + 4) = v4; /*0x1039ae20e*/
      *((_BYTE *)this + 56) = 1; /*0x1039ae213*/
    }
  }
}

// Address: 0x1039ae21a | Name: __ZN6RakNet21CCRakNetSlidingWindow5OnNAKEyNS_8uint24_tE
__int64 __fastcall RakNet::CCRakNetSlidingWindow::OnNAK(__int64 a1)
{
  return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 112LL))(a1);
}

// Address: 0x1039ae228 | Name: __ZN6RakNet21CCRakNetSlidingWindow5OnAckEyybdddbNS_8uint24_tE
void __fastcall RakNet::CCRakNetSlidingWindow::OnAck(
        __int64 a1,
        __int64 a2,
        unsigned __int64 a3,
        __int64 a4,
        int a5,
        _DWORD *a6)
{
  __m128d v6; // xmm0
  double *v7; // rax
  double v8; // xmm1_8
  double v9; // xmm0_8
  double v10; // xmm1_8

  v6 = _mm_sub_pd((__m128d)_mm_unpacklo_epi32((__m128i)a3, (__m128i)xmmword_108F2F9A0), (__m128d)xmmword_108F2F9B0); /*0x1039ae239*/
  *(_QWORD *)(a1 + 16) = (unsigned __int64)_mm_hadd_pd(v6, v6); /*0x1039ae245*/
  *(_BYTE *)(a1 + 64) = a5; /*0x1039ae24a*/
  if ( a5 != 0 ) /*0x1039ae251*/
  {
    if ( ((*(_DWORD *)(a1 + 52) - *a6) & 0x800000) != 0 ) /*0x1039ae261*/
    {
      *(_DWORD *)(a1 + 52) = *(_DWORD *)(a1 + 48); /*0x1039ae288*/
      *(_WORD *)(a1 + 56) = 0; /*0x1039ae28b*/
      *(_QWORD *)(a1 + 32) = 0; /*0x1039ae291*/
      v7 = (double *)(a1 + 24); /*0x1039ae299*/
      v8 = *(double *)(a1 + 24); /*0x1039ae29d*/
      v9 = 0.0; /*0x1039ae2a2*/
    }
    else
    {
      v7 = (double *)(a1 + 24); /*0x1039ae263*/
      v8 = *(double *)(a1 + 24); /*0x1039ae267*/
      v9 = *(double *)(a1 + 32); /*0x1039ae26c*/
      if ( v9 < v8 && v9 != 0.0 ) /*0x1039ae27f*/
        return; /*0x1039ae27f*/
    }
    if ( v8 < 10000000.0 ) /*0x1039ae2b2*/
    {
      v10 = v8 + v8; /*0x1039ae2b4*/
      *v7 = v10; /*0x1039ae2b8*/
      if ( v9 != 0.0 && v10 > v9 ) /*0x1039ae2cc*/
        *(double *)(a1 + 24) = (double)(*(_DWORD *)(a1 + 8) * *(_DWORD *)(a1 + 8)) / v9 + v9; /*0x1039ae2e4*/
    }
  }
}

// Address: 0x1039ae2ec | Name: __ZNK6RakNet21CCRakNetSlidingWindow13IsInSlowStartEv
char __fastcall RakNet::CCRakNetSlidingWindow::IsInSlowStart(RakNet::CCRakNetSlidingWindow *this)
{
  return _mm_cvtsi128_si32((__m128i)_mm_or_pd( /*0x1039ae312*/
                                      _mm_cmple_pd(
                                        (__m128d)*((unsigned __int64 *)this + 3),
                                        (__m128d)*((unsigned __int64 *)this + 4)),
                                      _mm_cmpeq_pd((__m128d)0LL, (__m128d)*((unsigned __int64 *)this + 4))))
       & 1;
}

// Address: 0x1039ae314 | Name: __ZN6RakNet21CCRakNetSlidingWindow14OnDuplicateAckEyNS_8uint24_tE
__int64 __fastcall RakNet::CCRakNetSlidingWindow::OnDuplicateAck(__int64 a1)
{
  return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 112LL))(a1);
}

// Address: 0x1039ae322 | Name: __ZN6RakNet21CCRakNetSlidingWindow18OnSendAckGetBAndASEyPbPdS2_
void __fastcall RakNet::CCRakNetSlidingWindow::OnSendAckGetBAndAS(
        RakNet::CCRakNetSlidingWindow *this,
        unsigned __int64 a2,
        bool *a3,
        double *a4,
        double *a5)
{
  *a3 = false; /*0x1039ae326*/
}

// Address: 0x1039ae32c | Name: __ZN6RakNet21CCRakNetSlidingWindow9OnSendAckEyj
void __fastcall RakNet::CCRakNetSlidingWindow::OnSendAck(RakNet::CCRakNetSlidingWindow *this)
{
  *((_QWORD *)this + 5) = 0; /*0x1039ae330*/
}

// Address: 0x1039ae33a | Name: __ZN6RakNet21CCRakNetSlidingWindow10OnSendNACKEyj
void __fastcall RakNet::CCRakNetSlidingWindow::OnSendNACK(RakNet::CCRakNetSlidingWindow *this)
{
  ; /*0x1039ae33a*/
}

// Address: 0x1039ae340 | Name: __ZNK6RakNet21CCRakNetSlidingWindow23GetRTOForRetransmissionEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow::GetRTOForRetransmission(RakNet::CCRakNetSlidingWindow *this)
{
  __int64 result; // rax
  double v2; // xmm0_8
  __m128d v3; // xmm2
  double v4; // xmm1_8
  __m128d v5; // xmm2

  result = DFInt::RakNetResendMaxThresholdTimeInUs; /*0x1039ae344*/
  v2 = *((double *)this + 2); /*0x1039ae34b*/
  if ( v2 != -1.0 ) /*0x1039ae358*/
  {
    v3 = _mm_sub_pd( /*0x1039ae374*/
           (__m128d)_mm_unpacklo_epi32(
                      (__m128i)(unsigned __int64)DFInt::RakNetResendMaxThresholdTimeInUs,
                      (__m128i)xmmword_108F2F9A0),
           (__m128d)xmmword_108F2F9B0);
    v4 = (double)DFInt::RakNetResendRttMultiple * v2; /*0x1039ae380*/
    if ( v4 <= _mm_hadd_pd(v3, v3).f64[0] ) /*0x1039ae388*/
    {
      result = DFInt::RakNetResendMinThresholdTimeInUs; /*0x1039ae38a*/
      v5 = _mm_sub_pd( /*0x1039ae39e*/
             (__m128d)_mm_unpacklo_epi32(
                        (__m128i)(unsigned __int64)DFInt::RakNetResendMinThresholdTimeInUs,
                        (__m128i)xmmword_108F2F9A0),
             (__m128d)xmmword_108F2F9B0);
      if ( _mm_hadd_pd(v5, v5).f64[0] <= v4 ) /*0x1039ae3ae*/
        return (unsigned int)(int)v2 * (__int64)DFInt::RakNetResendRttMultiple; /*0x1039ae3d3*/
    }
  }
  return result; /*0x1039ae3d6*/
}

// Address: 0x1039ae3d8 | Name: __ZN6RakNet21CCRakNetSlidingWindow6SetMTUEj
void __fastcall RakNet::CCRakNetSlidingWindow::SetMTU(RakNet::CCRakNetSlidingWindow *this, int a2)
{
  *((_DWORD *)this + 2) = a2; /*0x1039ae3dc*/
}

// Address: 0x1039ae3e2 | Name: __ZNK6RakNet21CCRakNetSlidingWindow6GetMTUEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow::GetMTU(RakNet::CCRakNetSlidingWindow *this)
{
  return *((unsigned int *)this + 2); /*0x1039ae3e9*/
}

// Address: 0x1039ae3ec | Name: __ZNK6RakNet21CCRakNetSlidingWindow19GetLocalReceiveRateEy
double __fastcall RakNet::CCRakNetSlidingWindow::GetLocalReceiveRate(RakNet::CCRakNetSlidingWindow *this)
{
  return 0.0; /*0x1039ae3f3*/
}

// Address: 0x1039ae3f6 | Name: __ZNK6RakNet21CCRakNetSlidingWindow6GetRTTEv
__m128d __fastcall RakNet::CCRakNetSlidingWindow::GetRTT(RakNet::CCRakNetSlidingWindow *this)
{
  return _mm_andn_pd( /*0x1039ae410*/
           _mm_cmpeq_sd((__m128d)0xBFF0000000000000LL, (__m128d)*((unsigned __int64 *)this + 2)),
           (__m128d)*((unsigned __int64 *)this + 2));
}

// Address: 0x1039ae412 | Name: __ZN6RakNet21CCRakNetSlidingWindow8LessThanENS_8uint24_tES1_
bool __fastcall RakNet::CCRakNetSlidingWindow::LessThan(_DWORD *a1, _DWORD *a2)
{
  return *a2 != *a1 && ((*a2 - *a1) & 0xFFFFFFu) < 0x7FFFFF; /*0x1039ae42c*/
}

// Address: 0x1039ae42e | Name: __ZNK6RakNet21CCRakNetSlidingWindow41GetBytesPerSecondLimitByCongestionControlEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow::GetBytesPerSecondLimitByCongestionControl(
        RakNet::CCRakNetSlidingWindow *this)
{
  return 0; /*0x1039ae434*/
}

// Address: 0x1039ae44a | Name: __ZNK6RakNet21CCRakNetSlidingWindow16GetIsInSlowStartEv
char __fastcall RakNet::CCRakNetSlidingWindow::GetIsInSlowStart(RakNet::CCRakNetSlidingWindow *this)
{
  return _mm_cvtsi128_si32((__m128i)_mm_or_pd( /*0x1039ae470*/
                                      _mm_cmple_pd(
                                        (__m128d)*((unsigned __int64 *)this + 3),
                                        (__m128d)*((unsigned __int64 *)this + 4)),
                                      _mm_cmpeq_pd((__m128d)0LL, (__m128d)*((unsigned __int64 *)this + 4))))
       & 1;
}

// Address: 0x1039ae472 | Name: __ZNK6RakNet21CCRakNetSlidingWindow29includeTimestampWithDatagramsEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow::includeTimestampWithDatagrams(RakNet::CCRakNetSlidingWindow *this)
{
  return 0; /*0x1039ae478*/
}

// Address: 0x1039ae480 | Name: __ZNK6RakNet21CCRakNetSlidingWindow18GetOldestUnsentAckEv
__int64 __fastcall RakNet::CCRakNetSlidingWindow::GetOldestUnsentAck(RakNet::CCRakNetSlidingWindow *this)
{
  return *((_QWORD *)this + 5); /*0x1039ae488*/
}

// END CCRakNetSlidingWindow part 1/1, 36 functions
