// RemoteSystemStruct -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 3 functions


// Address: 0x1039bb1f6 | Name: __ZN6RakNet7RakPeer18RemoteSystemStructD1Ev
void __fastcall RakNet::RakPeer::RemoteSystemStruct::~RemoteSystemStruct(void **this)
{
  char *v2; // r14
  __int64 i; // r15
  char *v4; // rdi

  operator delete(a1: *(this + 667)); /*0x1039bb20a*/
  std::shared_ptr<RBX::Rupp::Rupp>::~shared_ptr[abi:ne200100](a1: this + 660); /*0x1039bb216*/
  std::shared_ptr<RakNet::RakNetSocket>::~shared_ptr[abi:ne200100](a1: this + 654); /*0x1039bb222*/
  v2 = (char *)(this + 635); /*0x1039bb227*/
  for ( i = -128; i != 0; i += 32 ) /*0x1039bb22e*/
  {
    v4 = *((char **)v2 - 3); /*0x1039bb235*/
    if ( v2 != v4 ) /*0x1039bb23c*/
      operator delete(a1: v4); /*0x1039bb23e*/
    v2 -= 32; /*0x1039bb243*/
  }
  RakNet::ReliabilityLayer::~ReliabilityLayer(this: (RakNet::ReliabilityLayer *)(this + 49)); /*0x1039bb261*/
}

// Address: 0x1039d1ba8 | Name: __ZN6RakNet7RakPeer18RemoteSystemStructC2Ev
__int64 __fastcall RakNet::RakPeer::RemoteSystemStruct::RemoteSystemStruct(RakNet::RakPeer::RemoteSystemStruct *this)
{
  __int64 i; // r14
  char *v3; // rax
  __int64 j; // rcx

  RakNet::SystemAddress::SystemAddress(this: (RakNet::RakPeer::RemoteSystemStruct *)((char *)this + 4)); /*0x1039d1bb9*/
  RakNet::SystemAddress::SystemAddress(this: (RakNet::RakPeer::RemoteSystemStruct *)((char *)this + 36)); /*0x1039d1bc2*/
  for ( i = 68; i != 388; i += 32 ) /*0x1039d1bc7*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::RakPeer::RemoteSystemStruct *)((char *)this + i)); /*0x1039d1bd1*/
  RakNet::ReliabilityLayer::ReliabilityLayer(this: (RakNet::RakPeer::RemoteSystemStruct *)((char *)this + 392)); /*0x1039d1bed*/
  v3 = (char *)this + 4984; /*0x1039d1bf2*/
  for ( j = 128; j != 0; j -= 32 ) /*0x1039d1bf9*/
  {
    *((_QWORD *)v3 - 3) = v3; /*0x1039d1bfe*/
    *((_QWORD *)v3 - 2) = 0; /*0x1039d1c02*/
    *((_QWORD *)v3 - 1) = 4; /*0x1039d1c0a*/
    v3 += 32; /*0x1039d1c12*/
  }
  *(_OWORD *)((char *)this + 5160) = 0; /*0x1039d1c26*/
  *(_OWORD *)((char *)this + 5144) = 0; /*0x1039d1c2d*/
  *(_OWORD *)((char *)this + 5128) = 0; /*0x1039d1c34*/
  *(_OWORD *)((char *)this + 5112) = 0; /*0x1039d1c3b*/
  *(_OWORD *)((char *)this + 5096) = 0; /*0x1039d1c42*/
  RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakPeer::RemoteSystemStruct *)((char *)this + 5200)); /*0x1039d1c49*/
  *((_BYTE *)this + 5220) = 0; /*0x1039d1c50*/
  *((_DWORD *)this + 1306) = 0; /*0x1039d1c56*/
  *((_OWORD *)this + 327) = 0; /*0x1039d1c5f*/
  *((_BYTE *)this + 5264) = 0; /*0x1039d1c66*/
  *((_DWORD *)this + 1317) = 0; /*0x1039d1c6c*/
  *((_BYTE *)this + 5272) = 0; /*0x1039d1c72*/
  *((_BYTE *)this + 5276) = 0; /*0x1039d1c78*/
  *((_OWORD *)this + 330) = 0; /*0x1039d1c7e*/
  *((_DWORD *)this + 1328) = 0; /*0x1039d1c85*/
  *((_BYTE *)this + 5316) = 0; /*0x1039d1c8b*/
  *((_BYTE *)this + 5360) = 0; /*0x1039d1c91*/
  *(_OWORD *)((char *)this + 5320) = 0; /*0x1039d1c97*/
  *(_OWORD *)((char *)this + 5336) = 0; /*0x1039d1c9e*/
  *((_DWORD *)this + 1338) = 0; /*0x1039d1ca5*/
  return 0; /*0x1039d1caf*/
}

// Address: 0x1086699cb | Name: __ZN6RakNet7RakPeer18RemoteSystemStructC2Ev.cold.1
void __fastcall RakNet::RakPeer::RemoteSystemStruct::RemoteSystemStruct(RakNet::RakPeer::RemoteSystemStruct *this)
{
  char *v1; // rbx
  __int64 i; // r14
  char *v3; // rdi

  v1 = (char *)this + 5080; /*0x1086699d5*/
  for ( i = -128; i != 0; i += 32 ) /*0x1086699de*/
  {
    v3 = *((char **)v1 - 3); /*0x1086699e0*/
    if ( v1 != v3 ) /*0x1086699e7*/
      operator delete(a1: v3); /*0x1086699e9*/
    v1 -= 32; /*0x1086699ee*/
  }
}

// END RemoteSystemStruct part 1/1, 3 functions
