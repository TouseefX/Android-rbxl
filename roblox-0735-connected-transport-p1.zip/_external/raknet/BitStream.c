// BitStream -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 83 functions


// Address: 0x1039ac874 | Name: __ZN6RakNet9BitStream11GetInstanceEv
__int64 __fastcall RakNet::BitStream::GetInstance(RakNet::BitStream *this)
{
  __int64 result; // rax

  result = operator new(a1: 0x128u); /*0x1039ac87d*/
  *(_QWORD *)result = off_10C9029A8; /*0x1039ac889*/
  *(_BYTE *)(result + 8) = 0; /*0x1039ac88c*/
  *(_QWORD *)(result + 12) = 0x80000000000LL; /*0x1039ac89a*/
  *(_DWORD *)(result + 20) = 0; /*0x1039ac89e*/
  *(_QWORD *)(result + 24) = result + 33; /*0x1039ac8a9*/
  *(_BYTE *)(result + 32) = 1; /*0x1039ac8ad*/
  return result; /*0x1039ac8b1*/
}

// Address: 0x1039ac8b4 | Name: __ZN6RakNet9BitStreamC1Ev
__int64 __fastcall RakNet::BitStream::BitStream(RakNet::BitStream *this)
{
  *(_QWORD *)this = off_10C9029A8; /*0x1039ac8bf*/
  *((_BYTE *)this + 8) = 0; /*0x1039ac8c2*/
  *(_QWORD *)((char *)this + 12) = 0x80000000000LL; /*0x1039ac8d0*/
  *((_DWORD *)this + 5) = 0; /*0x1039ac8d4*/
  *((_QWORD *)this + 3) = (char *)this + 33; /*0x1039ac8df*/
  *((_BYTE *)this + 32) = 1; /*0x1039ac8e3*/
  return (__int64)this + 33; /*0x1039ac8e7*/
}

// Address: 0x1039ac8ea | Name: __ZN6RakNet9BitStream15DestroyInstanceEPS0_
__int64 __fastcall RakNet::BitStream::DestroyInstance(RakNet::BitStream *this, RakNet::BitStream *a2)
{
  __int64 result; // rax

  if ( this != nullptr ) /*0x1039ac8f1*/
    return (*(__int64 (__fastcall **)(RakNet::BitStream *, RakNet::BitStream *))(*(_QWORD *)this + 8LL))(a1: this, a2); /*0x1039ac8f7*/
  return result; /*0x1039ac8fa*/
}

// Address: 0x1039ac8fc | Name: __ZN6RakNet9BitStreamC2Ev
__int64 __fastcall RakNet::BitStream::BitStream(RakNet::BitStream *this)
{
  *(_QWORD *)this = off_10C9029A8; /*0x1039ac907*/
  *((_BYTE *)this + 8) = 0; /*0x1039ac90a*/
  *(_QWORD *)((char *)this + 12) = 0x80000000000LL; /*0x1039ac918*/
  *((_DWORD *)this + 5) = 0; /*0x1039ac91c*/
  *((_QWORD *)this + 3) = (char *)this + 33; /*0x1039ac927*/
  *((_BYTE *)this + 32) = 1; /*0x1039ac92b*/
  return (__int64)this + 33; /*0x1039ac92f*/
}

// Address: 0x1039ac932 | Name: __ZN6RakNet9BitStreamC2Ej
__int64 __fastcall RakNet::BitStream::BitStream(RakNet::BitStream *this, unsigned __int64 a2)
{
  __int64 result; // rax
  int v4; // r14d
  int v5; // r14d

  *(_QWORD *)this = off_10C9029A8; /*0x1039ac943*/
  *((_BYTE *)this + 8) = 0; /*0x1039ac946*/
  *((_DWORD *)this + 3) = 0; /*0x1039ac94c*/
  *((_DWORD *)this + 5) = 0; /*0x1039ac94f*/
  if ( (unsigned int)a2 > 0x100 ) /*0x1039ac958*/
  {
    v5 = a2; /*0x1039ac966*/
    result = RBX::Memory::allocateOrCrash(this: (RBX::Memory *)(unsigned int)a2, a2); /*0x1039ac96b*/
    v4 = 8 * v5; /*0x1039ac970*/
  }
  else
  {
    result = (__int64)this + 33; /*0x1039ac95a*/
    v4 = 2048; /*0x1039ac95e*/
  }
  *((_QWORD *)this + 3) = result; /*0x1039ac974*/
  *((_DWORD *)this + 4) = v4; /*0x1039ac978*/
  *((_BYTE *)this + 32) = 1; /*0x1039ac97c*/
  return result; /*0x1039ac980*/
}

// Address: 0x1039ac986 | Name: __ZN6RakNet9BitStreamC1Ej
__int64 __fastcall RakNet::BitStream::BitStream(RakNet::BitStream *this, unsigned __int64 a2)
{
  __int64 result; // rax
  int v4; // r14d
  int v5; // r14d

  *(_QWORD *)this = off_10C9029A8; /*0x1039ac997*/
  *((_BYTE *)this + 8) = 0; /*0x1039ac99a*/
  *((_DWORD *)this + 3) = 0; /*0x1039ac9a0*/
  *((_DWORD *)this + 5) = 0; /*0x1039ac9a3*/
  if ( (unsigned int)a2 > 0x100 ) /*0x1039ac9ac*/
  {
    v5 = a2; /*0x1039ac9ba*/
    result = RBX::Memory::allocateOrCrash(this: (RBX::Memory *)(unsigned int)a2, a2); /*0x1039ac9bf*/
    v4 = 8 * v5; /*0x1039ac9c4*/
  }
  else
  {
    result = (__int64)this + 33; /*0x1039ac9ae*/
    v4 = 2048; /*0x1039ac9b2*/
  }
  *((_QWORD *)this + 3) = result; /*0x1039ac9c8*/
  *((_DWORD *)this + 4) = v4; /*0x1039ac9cc*/
  *((_BYTE *)this + 32) = 1; /*0x1039ac9d0*/
  return result; /*0x1039ac9d4*/
}

// Address: 0x1039ac9da | Name: __ZN6RakNet9BitStreamC2EPhjb
void *__fastcall RakNet::BitStream::BitStream(RakNet::BitStream *this, unsigned __int8 *a2, unsigned int a3, int a4)
{
  void *result; // rax
  char *v7; // rdi
  size_t v8; // r15

  *(_QWORD *)this = off_10C9029A8; /*0x1039ac9f1*/
  *((_BYTE *)this + 8) = 0; /*0x1039ac9f4*/
  result = (void *)(8 * a3); /*0x1039ac9f8*/
  *((_DWORD *)this + 3) = (_DWORD)result; /*0x1039ac9ff*/
  *((_DWORD *)this + 5) = 0; /*0x1039aca02*/
  *((_BYTE *)this + 32) = a4; /*0x1039aca09*/
  *((_DWORD *)this + 4) = (_DWORD)result; /*0x1039aca0c*/
  if ( a4 != 0 ) /*0x1039aca11*/
  {
    if ( a3 != 0 ) /*0x1039aca15*/
    {
      if ( a3 > 0xFF ) /*0x1039aca1d*/
      {
        v8 = a3; /*0x1039aca49*/
        v7 = (char *)RBX::Memory::allocateOrCrash(this: (RBX::Memory *)a3, (unsigned __int64)a2); /*0x1039aca54*/
      }
      else
      {
        v7 = (char *)this + 33; /*0x1039aca1f*/
        *((_DWORD *)this + 4) = 2048; /*0x1039aca23*/
        v8 = a3; /*0x1039aca2b*/
      }
      *((_QWORD *)this + 3) = v7; /*0x1039aca57*/
      return memcpy(__dst: v7, __src: a2, __n: v8); /*0x1039aca6b*/
    }
    else
    {
      *((_QWORD *)this + 3) = 0; /*0x1039aca36*/
    }
  }
  else
  {
    *((_QWORD *)this + 3) = a2; /*0x1039aca30*/
  }
  return result; /*0x1039aca42*/
}

// Address: 0x1039aca70 | Name: __ZN6RakNet9BitStreamC1EPhjb
void *__fastcall RakNet::BitStream::BitStream(RakNet::BitStream *this, unsigned __int8 *a2, unsigned int a3, int a4)
{
  return RakNet::BitStream::BitStream(this, a2, a3, a4); /*0x1039aca74*/
}

// Address: 0x1039aca7a | Name: __ZN6RakNet9BitStream24SetNumberOfBitsAllocatedEj
void __fastcall RakNet::BitStream::SetNumberOfBitsAllocated(RakNet::BitStream *this, int a2)
{
  *((_DWORD *)this + 4) = a2; /*0x1039aca7e*/
}

// Address: 0x1039aca84 | Name: __ZN6RakNet9BitStreamD2Ev
void __fastcall RakNet::BitStream::~BitStream(RakNet::BitStream *this, void *a2)
{
  unsigned int v2; // eax
  RBX::Memory *v3; // rax

  *(_QWORD *)this = off_10C9029A8; /*0x1039aca8f*/
  if ( *((_BYTE *)this + 32) == 1 ) /*0x1039aca96*/
  {
    v2 = *((_DWORD *)this + 4); /*0x1039aca98*/
    if ( v2 >= 0x801 ) /*0x1039acaa0*/
    {
      v3 = *((RBX::Memory **)this + 3); /*0x1039acaa2*/
LABEL_6:
      RBX::Memory::deallocate(this: v3, a2); /*0x1039acab9*/
      return; /*0x1039acabc*/
    }
    if ( v2 != 0 ) /*0x1039acaaa*/
    {
      v3 = *((RBX::Memory **)this + 3); /*0x1039acaac*/
      if ( v3 != (RakNet::BitStream *)((char *)this + 33) ) /*0x1039acab7*/
        goto LABEL_6; /*0x1039acab7*/
    }
  }
}

// Address: 0x1039acacc | Name: __ZN6RakNet9BitStreamD1Ev
void __fastcall RakNet::BitStream::~BitStream(RakNet::BitStream *this, void *a2)
{
  RakNet::BitStream::~BitStream(this, a2); /*0x1039acad1*/
}

// Address: 0x1039acad6 | Name: __ZN6RakNet9BitStreamD0Ev
void __fastcall RakNet::BitStream::~BitStream(RakNet::BitStream *this, void *a2)
{
  RakNet::BitStream::~BitStream(this, a2); /*0x1039acadf*/
  operator delete(a1: this); /*0x1039acaed*/
}

// Address: 0x1039acaf2 | Name: __ZN6RakNet9BitStream5ResetEv
__int64 __fastcall RakNet::BitStream::Reset(RakNet::BitStream *this)
{
  *((_DWORD *)this + 3) = 0; /*0x1039acaf8*/
  *((_DWORD *)this + 5) = 0; /*0x1039acafb*/
  *((_BYTE *)this + 8) = 0; /*0x1039acafe*/
  return 0; /*0x1039acb02*/
}

// Address: 0x1039acb04 | Name: __ZN6RakNet9BitStream5WriteEPKcj
void *__fastcall RakNet::BitStream::Write(RakNet::BitStream *this, const char *a2, unsigned int a3)
{
  unsigned int v6; // r15d
  void *result; // rax

  if ( a3 != 0 ) /*0x1039acb11*/
  {
    v6 = 8 * a3; /*0x1039acb1c*/
    if ( (*((_BYTE *)this + 12) & 7) != 0 ) /*0x1039acb28*/
    {
      return (void *)RakNet::BitStream::WriteBits(this, (const unsigned __int8 *)a2, a3: v6, a4: true); /*0x1039acb40*/
    }
    else
    {
      RakNet::BitStream::AddBitsAndReallocate(this, a2: v6); /*0x1039acb4b*/
      result = memcpy( /*0x1039acb63*/
                 __dst: (void *)(*((_QWORD *)this + 3) + ((unsigned int)(*((_DWORD *)this + 3) + 7) >> 3)),
                 __src: a2,
                 __n: a3);
      *((_DWORD *)this + 3) += v6; /*0x1039acb68*/
    }
  }
  return result; /*0x1039acb38*/
}

// Address: 0x1039acb76 | Name: __ZN6RakNet9BitStream20AddBitsAndReallocateEj
__int64 __fastcall RakNet::BitStream::AddBitsAndReallocate(
        RakNet::BitStream *this,
        unsigned __int64 a2,
        unsigned __int64 a3)
{
  __int64 result; // rax
  unsigned int v4; // r14d
  int v6; // eax
  bool v7; // cf
  RBX::Memory *v8; // rdi
  void *v9; // rax

  v4 = *((_DWORD *)this + 3) + a2; /*0x1039acb83*/
  if ( v4 != 0 ) /*0x1039acb87*/
  {
    result = (unsigned int)(*((_DWORD *)this + 4) - 1) >> 3; /*0x1039acb95*/
    if ( (unsigned int)result < (v4 - 1) >> 3 ) /*0x1039acba1*/
    {
      v6 = 2 * v4; /*0x1039acba3*/
      v7 = v4 < 0x100001; /*0x1039acba7*/
      v4 += 0x100000; /*0x1039acbb5*/
      if ( v7 ) /*0x1039acbb8*/
        v4 = v6; /*0x1039acbb8*/
      result = (v4 + 7) >> 3; /*0x1039acbc2*/
      v8 = *((RBX::Memory **)this + 3); /*0x1039acbc5*/
      if ( v8 == (RakNet::BitStream *)((char *)this + 33) ) /*0x1039acbd0*/
      {
        if ( v4 + 7 >= 0x808 ) /*0x1039acbe5*/
        {
          v9 = (void *)RBX::Memory::allocateOrCrash(this: (RBX::Memory *)(unsigned int)result, a2); /*0x1039acbe9*/
          *((_QWORD *)this + 3) = v9; /*0x1039acbee*/
          result = (__int64)memcpy( /*0x1039acc01*/
                              __dst: v9,
                              __src: (char *)this + 33,
                              __n: (unsigned int)(*((_DWORD *)this + 4) + 7) >> 3);
        }
      }
      else
      {
        result = RBX::Memory::reallocateOrCrash(this: v8, a2: (void *)(unsigned int)result, a3); /*0x1039acbd4*/
        *((_QWORD *)this + 3) = result; /*0x1039acbd9*/
      }
    }
    if ( v4 > *((_DWORD *)this + 4) ) /*0x1039acc0a*/
      *((_DWORD *)this + 4) = v4; /*0x1039acc0c*/
  }
  return result; /*0x1039acc14*/
}

// Address: 0x1039acc1c | Name: __ZN6RakNet9BitStream9WriteBitsEPKhjb
void *__fastcall RakNet::BitStream::WriteBits(
        RakNet::BitStream *this,
        const unsigned __int8 *a2,
        unsigned __int64 a3,
        char a4)
{
  unsigned int v5; // r15d
  unsigned int v8; // edi
  void *result; // rax
  unsigned int v10; // esi
  char v11; // dl
  unsigned int v12; // r8d
  int v13; // r9d
  bool v14; // cf

  v5 = a3; /*0x1039acc2a*/
  RakNet::BitStream::AddBitsAndReallocate(this, a2: (unsigned int)a3, a3); /*0x1039acc35*/
  v8 = *((_DWORD *)this + 3); /*0x1039acc3a*/
  result = (void *)(v5 | v8); /*0x1039acc3f*/
  if ( (((unsigned __int8)v5 | *((_BYTE *)this + 12)) & 7) != 0 ) /*0x1039acc44*/
  {
    if ( v5 == 0 ) /*0x1039acc4d*/
      return result; /*0x1039acc4d*/
    result = (void *)(v8 & 7); /*0x1039acc55*/
    v10 = 8 - (_DWORD)result; /*0x1039acc62*/
    v11 = 8 - v5; /*0x1039acc64*/
    v12 = v5; /*0x1039acc67*/
    while ( 1 ) /*0x1039acc73*/
    {
      v13 = *a2 << v11; /*0x1039acc73*/
      if ( a4 == 0 ) /*0x1039acc79*/
        LOBYTE(v13) = *a2; /*0x1039acc79*/
      v14 = v12 < 8; /*0x1039acc7d*/
      v12 -= 8; /*0x1039acc7d*/
      if ( !v14 ) /*0x1039acc81*/
        LOBYTE(v13) = *a2; /*0x1039acc81*/
      if ( (_DWORD)result != 0 ) /*0x1039acc87*/
      {
        *(_BYTE *)(*((_QWORD *)this + 3) + (v8 >> 3)) |= (unsigned __int8)v13 >> (char)result; /*0x1039acc9c*/
        if ( v10 >= v5 ) /*0x1039acca3*/
          break; /*0x1039acca3*/
        *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3) + 1LL) = (unsigned __int8)v13 << v10; /*0x1039accb4*/
      }
      else
      {
        *(_BYTE *)(*((_QWORD *)this + 3) + (v8 >> 3)) = v13; /*0x1039accc2*/
      }
      if ( v5 < 8 ) /*0x1039accca*/
        break; /*0x1039accca*/
      ++a2; /*0x1039acccc*/
      v8 = *((_DWORD *)this + 3) + 8; /*0x1039accd2*/
      *((_DWORD *)this + 3) = v8; /*0x1039accd5*/
      v11 += 8; /*0x1039accd8*/
      v5 = v12; /*0x1039accdb*/
      if ( v12 == 0 ) /*0x1039acce1*/
        return result; /*0x1039acce1*/
    }
  }
  else
  {
    result = memcpy(__dst: (void *)(*((_QWORD *)this + 3) + (v8 >> 3)), __src: a2, __n: v5 >> 3); /*0x1039accf5*/
  }
  *((_DWORD *)this + 3) += v5; /*0x1039accfa*/
  return result; /*0x1039accfe*/
}

// Address: 0x1039acd08 | Name: __ZN6RakNet9BitStream5WriteEPS0_
__int64 __fastcall RakNet::BitStream::Write(RakNet::BitStream *this, RakNet::BitStream *a2)
{
  return RakNet::BitStream::Write(this, a2, a3: *((_DWORD *)a2 + 3) - *((_DWORD *)a2 + 5)); /*0x1039acd12*/
}

// Address: 0x1039acd18 | Name: __ZN6RakNet9BitStream5WriteEPS0_j
__int64 __fastcall RakNet::BitStream::Write(RakNet::BitStream *this, RakNet::BitStream *a2, unsigned __int64 a3)
{
  unsigned int v3; // ebx
  __int64 result; // rax
  unsigned int v7; // r12d
  unsigned int v8; // r13d
  __int64 v9; // r12
  void *v10; // r13
  __int64 v11; // rax
  void *v12; // rdi
  size_t v13; // r13
  unsigned int v14; // edx
  int v15; // ecx
  __int64 v16; // rcx

  v3 = a3; /*0x1039acd26*/
  result = RakNet::BitStream::AddBitsAndReallocate(this, a2: (unsigned int)a3, a3); /*0x1039acd30*/
  v7 = *((_DWORD *)a2 + 5); /*0x1039acd35*/
  if ( (v7 & 7) == 0 ) /*0x1039acd3d*/
  {
    v8 = *((_DWORD *)this + 3); /*0x1039acd43*/
    if ( (v8 & 7) == 0 ) /*0x1039acd4b*/
    {
      v9 = v7 >> 3; /*0x1039acd51*/
      v10 = (void *)(*((_QWORD *)this + 3) + (v8 >> 3)); /*0x1039acd62*/
      v11 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1039acd6c*/
      v12 = v10; /*0x1039acd73*/
      v13 = v3 >> 3; /*0x1039acd76*/
      memcpy(__dst: v12, __src: (const void *)(v9 + v11), __n: v13); /*0x1039acd7d*/
      result = v3 & 0xFFFFFFF8; /*0x1039acd84*/
      v3 &= 7u; /*0x1039acd87*/
      LODWORD(v13) = 8 * (v9 + v13); /*0x1039acd8d*/
      *((_DWORD *)a2 + 5) = v13; /*0x1039acd91*/
      *((_DWORD *)this + 3) += result; /*0x1039acd95*/
      v7 = v13; /*0x1039acd99*/
    }
  }
  while ( v3 != 0 ) /*0x1039ace11*/
  {
    result = v7 + 1; /*0x1039acd9e*/
    if ( (unsigned int)result > *((_DWORD *)a2 + 3) ) /*0x1039acda7*/
      break; /*0x1039acda7*/
    result = *((unsigned int *)this + 3); /*0x1039acda9*/
    v14 = *(unsigned __int8 *)(*((_QWORD *)a2 + 3) + (v7 >> 3)) & (0x80u >> (v7 & 7)); /*0x1039acdc9*/
    v15 = *((_DWORD *)this + 3) & 7; /*0x1039acdcd*/
    if ( v15 != 0 ) /*0x1039acdd0*/
    {
      if ( v14 != 0 ) /*0x1039acdd4*/
      {
        result = (unsigned int)result >> 3; /*0x1039acde1*/
        *(_BYTE *)(*((_QWORD *)this + 3) + result) |= 0x80u >> v15; /*0x1039acde4*/
      }
    }
    else
    {
      result = (unsigned int)result >> 3; /*0x1039acde9*/
      v16 = *((_QWORD *)this + 3); /*0x1039acdec*/
      if ( v14 != 0 ) /*0x1039acdf2*/
        *(_BYTE *)(v16 + result) = 0x80; /*0x1039acdf4*/
      else
        *(_BYTE *)(v16 + result) = 0; /*0x1039acdfa*/
    }
    --v3; /*0x1039acdfe*/
    v7 = *((_DWORD *)a2 + 5) + 1; /*0x1039ace04*/
    *((_DWORD *)a2 + 5) = v7; /*0x1039ace07*/
    ++*((_DWORD *)this + 3); /*0x1039ace0b*/
  }
  return result; /*0x1039ace17*/
}

// Address: 0x1039ace22 | Name: __ZN6RakNet9BitStream5WriteERS0_j
__int64 __fastcall RakNet::BitStream::Write(RakNet::BitStream *this, RakNet::BitStream *a2, unsigned __int64 a3)
{
  return RakNet::BitStream::Write(this, a2, a3); /*0x1039ace26*/
}

// Address: 0x1039ace2c | Name: __ZN6RakNet9BitStream5WriteERS0_
__int64 __fastcall RakNet::BitStream::Write(RakNet::BitStream *this, RakNet::BitStream *a2)
{
  return RakNet::BitStream::Write(this, a2, a3: (unsigned int)(*((_DWORD *)a2 + 3) - *((_DWORD *)a2 + 5))); /*0x1039ace36*/
}

// Address: 0x1039ace3c | Name: __ZN6RakNet9BitStream4ReadEPS0_j
bool __fastcall RakNet::BitStream::Read(RakNet::BitStream *this, RakNet::BitStream *a2, unsigned int a3)
{
  unsigned int v4; // r14d

  v4 = *((_DWORD *)this + 3) - *((_DWORD *)this + 5); /*0x1039ace49*/
  if ( v4 >= a3 ) /*0x1039ace50*/
    RakNet::BitStream::Write(this: a2, a2: this, a3); /*0x1039ace5d*/
  return v4 >= a3; /*0x1039ace68*/
}

// Address: 0x1039ace6e | Name: __ZN6RakNet9BitStream4ReadEPS0_
char __fastcall RakNet::BitStream::Read(RakNet::BitStream *this, RakNet::BitStream *a2)
{
  RakNet::BitStream::Write(this: a2, a2: this, a3: (unsigned int)(*((_DWORD *)this + 3) - *((_DWORD *)this + 5))); /*0x1039ace81*/
  return 1; /*0x1039ace88*/
}

// Address: 0x1039ace8a | Name: __ZN6RakNet9BitStream4ReadERS0_j
bool __fastcall RakNet::BitStream::Read(RakNet::BitStream *this, RakNet::BitStream *a2, unsigned int a3)
{
  unsigned int v4; // r14d

  v4 = *((_DWORD *)this + 3) - *((_DWORD *)this + 5); /*0x1039ace97*/
  if ( v4 >= a3 ) /*0x1039ace9e*/
    RakNet::BitStream::Write(this: a2, a2: this, a3); /*0x1039aceab*/
  return v4 >= a3; /*0x1039aceb6*/
}

// Address: 0x1039acebc | Name: __ZN6RakNet9BitStream4ReadERS0_
char __fastcall RakNet::BitStream::Read(RakNet::BitStream *this, RakNet::BitStream *a2)
{
  RakNet::BitStream::Write(this: a2, a2: this, a3: (unsigned int)(*((_DWORD *)this + 3) - *((_DWORD *)this + 5))); /*0x1039acecf*/
  return 1; /*0x1039aced6*/
}

// Address: 0x1039aced8 | Name: __ZN6RakNet9BitStream4ReadEPcj
char __fastcall RakNet::BitStream::Read(RakNet::BitStream *this, char *__dst, size_t __n)
{
  unsigned int v4; // eax
  unsigned int v5; // r14d

  v4 = *((_DWORD *)this + 5); /*0x1039acee2*/
  v5 = 8 * __n; /*0x1039acee5*/
  if ( (v4 & 7) != 0 ) /*0x1039aceef*/
    return RakNet::BitStream::ReadBits(this, a2: (unsigned __int8 *)__dst, a3: v5, a4: true); /*0x1039acf00*/
  if ( v4 + v5 > *((_DWORD *)this + 3) ) /*0x1039acf0c*/
    return 0; /*0x1039acf0e*/
  memcpy(__dst, __src: (const void *)(*((_QWORD *)this + 3) + (v4 >> 3)), (unsigned int)__n); /*0x1039acf21*/
  *((_DWORD *)this + 5) += v5; /*0x1039acf26*/
  return 1; /*0x1039acefc*/
}

// Address: 0x1039acf32 | Name: __ZN6RakNet9BitStream8ReadBitsEPhjb
char __fastcall RakNet::BitStream::ReadBits(RakNet::BitStream *this, unsigned __int8 *a2, unsigned int a3, char a4)
{
  unsigned int v5; // ebx
  unsigned __int8 *v6; // r15
  unsigned int v8; // eax
  bool v9; // cf
  unsigned int v10; // eax
  unsigned int v11; // r13d
  int v12; // r13d
  unsigned int v13; // eax
  unsigned int v14; // ecx
  unsigned __int8 v15; // dl

  if ( a3 == 0 ) /*0x1039acf34*/
    return 0; /*0x1039acff9*/
  v5 = a3; /*0x1039acf4b*/
  v6 = a2; /*0x1039acf4d*/
  if ( DFFlag::BitStreamReadBitsOverflowCheck == 1 ) /*0x1039acf5a*/
  {
    v8 = *((_DWORD *)this + 3); /*0x1039acf60*/
    v9 = v8 < a3; /*0x1039acf64*/
    v10 = v8 - a3; /*0x1039acf64*/
    if ( !v9 ) /*0x1039acf66*/
    {
      v11 = *((_DWORD *)this + 5); /*0x1039acf6c*/
      if ( v11 <= v10 ) /*0x1039acf73*/
        goto LABEL_5; /*0x1039acf73*/
    }
    return 0; /*0x1039ad00e*/
  }
  v11 = *((_DWORD *)this + 5); /*0x1039acffa*/
  if ( a3 + v11 > *((_DWORD *)this + 3) ) /*0x1039ad006*/
    return 0; /*0x1039ad006*/
LABEL_5:
  if ( (((unsigned __int8)a3 | (unsigned __int8)v11) & 7) != 0 ) /*0x1039acf80*/
  {
    v12 = v11 & 7; /*0x1039acf86*/
    __bzero(a1: a2, a2: (a3 + 7) >> 3); /*0x1039acf93*/
    v13 = 8 - v12; /*0x1039acf9d*/
    v14 = *((_DWORD *)this + 5); /*0x1039acfa0*/
    while ( 1 ) /*0x1039acfb4*/
    {
      v15 = *v6 | (*(unsigned __int8 *)(*((_QWORD *)this + 3) + (v14 >> 3)) << v12); /*0x1039acfb4*/
      *v6 = v15; /*0x1039acfb7*/
      if ( v12 != 0 ) /*0x1039acfbd*/
      {
        if ( v5 <= v13 ) /*0x1039acfc1*/
          break; /*0x1039acfc1*/
        v15 |= *(unsigned __int8 *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 5) >> 3) + 1LL) >> v13; /*0x1039acfd7*/
        *v6 = v15; /*0x1039acfda*/
      }
      if ( v5 <= 7 ) /*0x1039acfe0*/
        break; /*0x1039acfe0*/
      v14 = *((_DWORD *)this + 5) + 8; /*0x1039acfe6*/
      ++v6; /*0x1039acfe9*/
      *((_DWORD *)this + 5) = v14; /*0x1039acfec*/
      v5 -= 8; /*0x1039acff0*/
      if ( v5 == 0 ) /*0x1039acff3*/
        return 1; /*0x1039acff3*/
    }
    if ( a4 != 0 ) /*0x1039ad013*/
      *v6 = v15 >> (8 - v5); /*0x1039ad01e*/
  }
  else
  {
    memcpy(__dst: a2, __src: (const void *)(*((_QWORD *)this + 3) + (v11 >> 3)), __n: a3 >> 3); /*0x1039ad036*/
  }
  *((_DWORD *)this + 5) += v5; /*0x1039ad03b*/
  return 1; /*0x1039acff9*/
}

// Address: 0x1039ad050 | Name: __ZN6RakNet9BitStream16ResetReadPointerEv
void __fastcall RakNet::BitStream::ResetReadPointer(RakNet::BitStream *this)
{
  *((_DWORD *)this + 5) = 0; /*0x1039ad054*/
}

// Address: 0x1039ad05e | Name: __ZN6RakNet9BitStream17ResetWritePointerEv
void __fastcall RakNet::BitStream::ResetWritePointer(RakNet::BitStream *this)
{
  *((_DWORD *)this + 3) = 0; /*0x1039ad062*/
}

// Address: 0x1039ad06c | Name: __ZN6RakNet9BitStream6Write0Ev
__int64 __fastcall RakNet::BitStream::Write0(RakNet::BitStream *this, __int64 a2, unsigned __int64 a3)
{
  unsigned int v4; // eax
  __int64 result; // rax

  RakNet::BitStream::AddBitsAndReallocate(this, a2: 1u, a3); /*0x1039ad07a*/
  v4 = *((_DWORD *)this + 3); /*0x1039ad07f*/
  if ( (v4 & 7) == 0 ) /*0x1039ad084*/
  {
    *(_BYTE *)(*((_QWORD *)this + 3) + (v4 >> 3)) = 0; /*0x1039ad08d*/
    v4 = *((_DWORD *)this + 3); /*0x1039ad091*/
  }
  result = v4 + 1; /*0x1039ad094*/
  *((_DWORD *)this + 3) = result; /*0x1039ad096*/
  return result; /*0x1039ad09d*/
}

// Address: 0x1039ad0a0 | Name: __ZN6RakNet9BitStream6Write1Ev
__int64 __fastcall RakNet::BitStream::Write1(RakNet::BitStream *this, __int64 a2, unsigned __int64 a3)
{
  unsigned int v4; // eax
  char v5; // cl
  __int64 result; // rax

  RakNet::BitStream::AddBitsAndReallocate(this, a2: 1u, a3); /*0x1039ad0ae*/
  v4 = *((_DWORD *)this + 3); /*0x1039ad0b3*/
  v5 = v4 & 7; /*0x1039ad0b8*/
  if ( (v4 & 7) != 0 ) /*0x1039ad0bb*/
  {
    result = v4 >> 3; /*0x1039ad0c8*/
    *(_BYTE *)(*((_QWORD *)this + 3) + result) |= 0x80u >> v5; /*0x1039ad0cb*/
  }
  else
  {
    result = v4 >> 3; /*0x1039ad0d4*/
    *(_BYTE *)(*((_QWORD *)this + 3) + (unsigned int)result) = 0x80; /*0x1039ad0d7*/
  }
  ++*((_DWORD *)this + 3); /*0x1039ad0db*/
  return result; /*0x1039ad0e2*/
}

// Address: 0x1039ad0e6 | Name: __ZN6RakNet9BitStream7ReadBitEv
__int64 __fastcall RakNet::BitStream::ReadBit(RakNet::BitStream *this)
{
  __int64 result; // rax

  result = (unsigned int)(*(unsigned __int8 *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 5) >> 3)) << (*((_DWORD *)this + 5) & 7)) >> 7; /*0x1039ad0ff*/
  ++*((_DWORD *)this + 5); /*0x1039ad103*/
  return result; /*0x1039ad109*/
}

// Address: 0x1039ad10c | Name: __ZN6RakNet9BitStream17WriteAlignedBytesEPKhj
void *__fastcall RakNet::BitStream::WriteAlignedBytes(RakNet::BitStream *this, const char *a2, unsigned int a3)
{
  *((_DWORD *)this + 3) += -*((_DWORD *)this + 3) & 7; /*0x1039ad11c*/
  return RakNet::BitStream::Write(this, a2, a3); /*0x1039ad11f*/
}

// Address: 0x1039ad126 | Name: __ZN6RakNet9BitStream15EndianSwapBytesEii
char __fastcall RakNet::BitStream::EndianSwapBytes(RakNet::BitStream *this, int a2, unsigned int a3)
{
  __int64 v6; // rax
  __int64 v7; // rcx
  unsigned int v8; // ebx
  __int64 v9; // rdx
  char v10; // si

  LOBYTE(v6) = `guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r; /*0x1039ad138*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 ) /*0x1039ad140*/
    LOBYTE(v6) = RakNet::BitStream::EndianSwapBytes(this, a2, a3); /*0x1039ad186*/
  if ( RakNet::BitStream::IsNetworkOrder(void)::r == 0 && a3 >= 2 ) /*0x1039ad14e*/
  {
    v6 = *((_QWORD *)this + 3) + a2; /*0x1039ad153*/
    v7 = a3 >> 1; /*0x1039ad159*/
    v8 = a3 - 1; /*0x1039ad15b*/
    v9 = 0; /*0x1039ad15d*/
    do /*0x1039ad179*/
    {
      v10 = *(_BYTE *)(v6 + v9); /*0x1039ad15f*/
      *(_BYTE *)(v6 + v9) = *(_BYTE *)(v6 + v8); /*0x1039ad169*/
      *(_BYTE *)(v6 + v8) = v10; /*0x1039ad16d*/
      ++v9; /*0x1039ad171*/
      --v8; /*0x1039ad174*/
    }
    while ( v7 != v9 ); /*0x1039ad179*/
  }
  return v6; /*0x1039ad17f*/
}

// Address: 0x1039ad18e | Name: __ZN6RakNet9BitStream19ReverseBytesInPlaceEPhj
void __fastcall RakNet::BitStream::ReverseBytesInPlace(RakNet::BitStream *this, unsigned __int8 *a2)
{
  __int64 v2; // rax
  unsigned int v3; // esi
  __int64 v4; // rcx
  char v5; // dl

  if ( (unsigned int)a2 >= 2 ) /*0x1039ad195*/
  {
    v2 = (unsigned int)a2 >> 1; /*0x1039ad199*/
    v3 = (_DWORD)a2 - 1; /*0x1039ad19b*/
    v4 = 0; /*0x1039ad19d*/
    do /*0x1039ad1b9*/
    {
      v5 = *((_BYTE *)this + v4); /*0x1039ad19f*/
      *((_BYTE *)this + v4) = *((_BYTE *)this + v3); /*0x1039ad1a9*/
      *((_BYTE *)this + v3) = v5; /*0x1039ad1ad*/
      ++v4; /*0x1039ad1b1*/
      --v3; /*0x1039ad1b4*/
    }
    while ( v2 != v4 ); /*0x1039ad1b9*/
  }
}

// Address: 0x1039ad1be | Name: __ZN6RakNet9BitStream16ReadAlignedBytesEPhj
char __fastcall RakNet::BitStream::ReadAlignedBytes(RakNet::BitStream *this, unsigned __int8 *a2, unsigned int a3)
{
  unsigned int v4; // ecx
  int v5; // r14d
  unsigned int v6; // edi
  char result; // al
  bool v8; // cf
  unsigned int v9; // edi

  if ( a3 == 0 ) /*0x1039ad1c0*/
    return 0; /*0x1039ad206*/
  v4 = *((_DWORD *)this + 5) + (-*((_DWORD *)this + 5) & 7); /*0x1039ad1d6*/
  *((_DWORD *)this + 5) = v4; /*0x1039ad1d8*/
  if ( DFFlag::BitStreamReadBitsOverflowCheck != 1 ) /*0x1039ad1e2*/
  {
    if ( v4 + 8 * a3 <= *((_DWORD *)this + 3) ) /*0x1039ad20d*/
    {
      v5 = 8 * a3; /*0x1039ad213*/
LABEL_11:
      memcpy(__dst: a2, __src: (const void *)(*((_QWORD *)this + 3) + (v4 >> 3)), __n: a3); /*0x1039ad21b*/
      *((_DWORD *)this + 5) += v5; /*0x1039ad22f*/
      return 1; /*0x1039ad233*/
    }
    return 0; /*0x1039ad211*/
  }
  if ( a3 > 0x1FFFFFFF ) /*0x1039ad1ea*/
    return 0; /*0x1039ad1ea*/
  v5 = 8 * a3; /*0x1039ad1ec*/
  v6 = *((_DWORD *)this + 3); /*0x1039ad1f4*/
  result = 0; /*0x1039ad1f7*/
  v8 = v6 < 8 * a3; /*0x1039ad1f9*/
  v9 = v6 - 8 * a3; /*0x1039ad1f9*/
  if ( !v8 && v4 <= v9 ) /*0x1039ad200*/
    goto LABEL_11; /*0x1039ad200*/
  return result; /*0x1039ad206*/
}

// Address: 0x1039ad23a | Name: __ZN6RakNet9BitStream9WriteBitsEPKhjj
void *__fastcall RakNet::BitStream::WriteBits(
        RakNet::BitStream *this,
        const unsigned __int8 *a2,
        unsigned __int64 a3,
        unsigned int a4)
{
  unsigned int v4; // ebx
  unsigned int v5; // r15d
  __int64 v8; // rsi
  int v9; // r15d
  int v10; // edx
  unsigned int v11; // eax
  const unsigned __int8 *v12; // rsi
  int v13; // ecx
  RakNet::BitStream *v14; // rdi
  const unsigned __int8 *v15; // rsi

  v4 = a4; /*0x1039ad245*/
  v5 = a3; /*0x1039ad247*/
  RakNet::BitStream::AddBitsAndReallocate(this, a2: a4, a3); /*0x1039ad252*/
  if ( v5 == 0 ) /*0x1039ad25a*/
    goto LABEL_9; /*0x1039ad25a*/
  v8 = 0; /*0x1039ad263*/
  if ( v5 >= 8 ) /*0x1039ad269*/
    v8 = (v5 + 7) >> 3; /*0x1039ad269*/
  v9 = v5 & 7; /*0x1039ad26c*/
  if ( v9 == 0 ) /*0x1039ad270*/
  {
    a2 += v8; /*0x1039ad2bf*/
LABEL_9:
    v14 = this; /*0x1039ad2c2*/
    v15 = a2; /*0x1039ad2c5*/
    return RakNet::BitStream::WriteBits(this: v14, a2: v15, a3: v4, a4: 0); /*0x1039ad2c8*/
  }
  v10 = a2[v8] << v9; /*0x1039ad27a*/
  v11 = *((_DWORD *)this + 3); /*0x1039ad27c*/
  v12 = &a2[v8]; /*0x1039ad280*/
  v13 = v11 & 7; /*0x1039ad285*/
  if ( (v11 & 7) != 0 ) /*0x1039ad288*/
  {
    *(_BYTE *)(*((_QWORD *)this + 3) + (v11 >> 3)) |= (unsigned __int8)(v10 & 0xFE) >> v13; /*0x1039ad29b*/
    if ( 8 - v13 < v4 ) /*0x1039ad2a8*/
      *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3) + 1LL) = v10 << (8 - v13); /*0x1039ad2b9*/
  }
  else
  {
    *(_BYTE *)(*((_QWORD *)this + 3) + (v11 >> 3)) = v10; /*0x1039ad2d1*/
  }
  *((_DWORD *)this + 3) += 8 - v9; /*0x1039ad2dc*/
  v15 = v12 + 1; /*0x1039ad2e0*/
  v4 -= 8 - v9; /*0x1039ad2e3*/
  v14 = this; /*0x1039ad2e5*/
  return RakNet::BitStream::WriteBits(this: v14, a2: v15, a3: v4, a4: 0); /*0x1039ad2ec*/
}

// Address: 0x1039ad2fa | Name: __ZN6RakNet9BitStream7SetDataEPh
void __fastcall RakNet::BitStream::SetData(RakNet::BitStream *this, unsigned __int8 *a2)
{
  *((_QWORD *)this + 3) = a2; /*0x1039ad2fe*/
  *((_BYTE *)this + 32) = 0; /*0x1039ad302*/
}

// Address: 0x1039ad308 | Name: __ZNK6RakNet9BitStream24GetNumberOfBitsAllocatedEv
__int64 __fastcall RakNet::BitStream::GetNumberOfBitsAllocated(RakNet::BitStream *this)
{
  return *((unsigned int *)this + 4); /*0x1039ad30f*/
}

// Address: 0x1039ad312 | Name: __ZN6RakNet9BitStream23PadWithZeroToByteLengthEj
void __fastcall RakNet::BitStream::PadWithZeroToByteLength(RakNet::BitStream *this, unsigned int a2)
{
  unsigned int v4; // r14d
  unsigned __int64 v5; // rdx

  if ( (*(unsigned int (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)this + 24LL))(a1: this) < a2 ) /*0x1039ad32b*/
  {
    *((_DWORD *)this + 3) += -*((_DWORD *)this + 3) & 7; /*0x1039ad339*/
    v4 = a2 - (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)this + 24LL))(a1: this); /*0x1039ad345*/
    RakNet::BitStream::AddBitsAndReallocate(this, a2: 8 * v4, a3: v5); /*0x1039ad356*/
    __bzero(a1: *((_QWORD *)this + 3) + ((unsigned int)(*((_DWORD *)this + 3) + 7) >> 3), a2: v4); /*0x1039ad36b*/
    *((_DWORD *)this + 3) += 8 * v4; /*0x1039ad370*/
  }
}

// Address: 0x1039ad380 | Name: __ZN6RakNet9BitStream21NumberOfLeadingZeroesEa
__int64 __fastcall RakNet::BitStream::NumberOfLeadingZeroes(RakNet::BitStream *this)
{
  int v1; // ecx
  unsigned __int8 v2; // al
  int v3; // edx
  unsigned __int8 v4; // si
  int v5; // ecx
  int v6; // eax

  v1 = 0; /*0x1039ad389*/
  v2 = (unsigned __int8)this >> 4; /*0x1039ad38f*/
  if ( (unsigned __int8)this < 0x10u ) /*0x1039ad392*/
    v2 = (unsigned __int8)this; /*0x1039ad392*/
  LOBYTE(v1) = (unsigned __int8)this < 0x10u; /*0x1039ad395*/
  v3 = 4 * v1 + 4; /*0x1039ad398*/
  v4 = v2 >> 2; /*0x1039ad3a7*/
  if ( v2 < 4u ) /*0x1039ad3ab*/
    v4 = v2; /*0x1039ad3ab*/
  v5 = 4 * v1 + 2; /*0x1039ad3ae*/
  if ( v2 < 4u ) /*0x1039ad3b5*/
    v5 = v3; /*0x1039ad3b5*/
  v6 = -2; /*0x1039ad3c2*/
  if ( v4 < 2u ) /*0x1039ad3c7*/
    v6 = -v4; /*0x1039ad3c7*/
  return (unsigned int)(v5 + v6); /*0x1039ad3cc*/
}

// Address: 0x1039ad3ce | Name: __ZN6RakNet9BitStream21NumberOfLeadingZeroesEh
__int64 __fastcall RakNet::BitStream::NumberOfLeadingZeroes(RakNet::BitStream *this)
{
  int v1; // ecx
  unsigned __int8 v2; // al
  int v3; // edx
  unsigned __int8 v4; // si
  int v5; // ecx
  int v6; // eax

  v1 = 0; /*0x1039ad3d7*/
  v2 = (unsigned __int8)this >> 4; /*0x1039ad3dd*/
  if ( (unsigned __int8)this < 0x10u ) /*0x1039ad3e0*/
    v2 = (unsigned __int8)this; /*0x1039ad3e0*/
  LOBYTE(v1) = (unsigned __int8)this < 0x10u; /*0x1039ad3e3*/
  v3 = 4 * v1 + 4; /*0x1039ad3e6*/
  v4 = v2 >> 2; /*0x1039ad3f5*/
  if ( v2 < 4u ) /*0x1039ad3f9*/
    v4 = v2; /*0x1039ad3f9*/
  v5 = 4 * v1 + 2; /*0x1039ad3fc*/
  if ( v2 < 4u ) /*0x1039ad403*/
    v5 = v3; /*0x1039ad403*/
  v6 = -2; /*0x1039ad410*/
  if ( v4 < 2u ) /*0x1039ad415*/
    v6 = -v4; /*0x1039ad415*/
  return (unsigned int)(v5 + v6); /*0x1039ad41a*/
}

// Address: 0x1039ad41c | Name: __ZN6RakNet9BitStream21NumberOfLeadingZeroesEs
__int64 __fastcall RakNet::BitStream::NumberOfLeadingZeroes(RakNet::BitStream *this)
{
  int v1; // edx
  _BOOL4 v2; // esi
  int v3; // edi
  int v4; // ecx
  int v5; // esi
  int v6; // edx
  bool v7; // cf
  int v8; // ecx
  int v9; // eax

  v1 = (unsigned __int16)this >> 8; /*0x1039ad42b*/
  v2 = (unsigned __int16)this < 0x100u; /*0x1039ad436*/
  if ( (unsigned __int16)this < 0x100u ) /*0x1039ad43a*/
    LOWORD(v1) = (_WORD)this; /*0x1039ad43a*/
  v3 = 8 * v2 + 8; /*0x1039ad441*/
  v4 = (unsigned __int16)v1 >> 4; /*0x1039ad448*/
  v5 = 8 * v2 + 4; /*0x1039ad44f*/
  if ( (unsigned __int16)v1 < 0x10u ) /*0x1039ad456*/
  {
    LOWORD(v4) = v1; /*0x1039ad456*/
    v5 = v3; /*0x1039ad459*/
  }
  v6 = (unsigned __int16)v4 >> 2; /*0x1039ad460*/
  v7 = (unsigned __int16)v4 < 4u; /*0x1039ad463*/
  if ( (unsigned __int16)v4 < 4u ) /*0x1039ad467*/
    LOWORD(v6) = v4; /*0x1039ad467*/
  v8 = v5 - 2; /*0x1039ad46a*/
  if ( v7 ) /*0x1039ad46d*/
    v8 = v5; /*0x1039ad46d*/
  v9 = -2; /*0x1039ad47a*/
  if ( (unsigned __int16)v6 < 2u ) /*0x1039ad47f*/
    v9 = -(unsigned __int16)v6; /*0x1039ad47f*/
  return (unsigned int)(v8 + v9); /*0x1039ad484*/
}

// Address: 0x1039ad486 | Name: __ZN6RakNet9BitStream21NumberOfLeadingZeroesEt
__int64 __fastcall RakNet::BitStream::NumberOfLeadingZeroes(RakNet::BitStream *this)
{
  unsigned int v1; // eax
  _BOOL4 v2; // ecx
  int v3; // edx
  unsigned int v4; // esi
  int v5; // ecx
  unsigned int v6; // eax
  int v7; // edx
  int v8; // ecx
  bool v9; // cf
  int v10; // eax

  v1 = (unsigned int)this >> 8; /*0x1039ad48c*/
  v2 = (unsigned int)this < 0x100; /*0x1039ad497*/
  if ( (unsigned int)this < 0x100 ) /*0x1039ad49a*/
    v1 = (unsigned int)this; /*0x1039ad49a*/
  v3 = 8 * v2 + 8; /*0x1039ad49d*/
  v4 = v1 >> 4; /*0x1039ad4a6*/
  v5 = 8 * v2 + 4; /*0x1039ad4ad*/
  if ( (unsigned __int16)v1 < 0x10u ) /*0x1039ad4b4*/
  {
    v4 = v1; /*0x1039ad4b4*/
    v5 = v3; /*0x1039ad4b7*/
  }
  v6 = v4 >> 2; /*0x1039ad4bc*/
  v7 = v5 - 2; /*0x1039ad4bf*/
  if ( (unsigned __int16)v4 < 4u ) /*0x1039ad4c6*/
  {
    v6 = v4; /*0x1039ad4c6*/
    v7 = v5; /*0x1039ad4c9*/
  }
  v8 = -v6; /*0x1039ad4ce*/
  v9 = (unsigned __int16)v6 < 2u; /*0x1039ad4d0*/
  v10 = -2; /*0x1039ad4d4*/
  if ( v9 ) /*0x1039ad4d9*/
    v10 = v8; /*0x1039ad4d9*/
  return (unsigned int)(v7 + v10); /*0x1039ad4de*/
}

// Address: 0x1039ad4e0 | Name: __ZN6RakNet9BitStream21NumberOfLeadingZeroesEi
__int64 __fastcall RakNet::BitStream::NumberOfLeadingZeroes(RakNet::BitStream *this, unsigned int a2)
{
  return RakNet::BitStream::NumberOfLeadingZeroes(this, a2); /*0x1039ad4e4*/
}

// Address: 0x1039ad4ea | Name: __ZN6RakNet9BitStream21NumberOfLeadingZeroesEj
__int64 __fastcall RakNet::BitStream::NumberOfLeadingZeroes(RakNet::BitStream *this)
{
  unsigned int v1; // eax
  int v2; // ecx
  int v3; // edx
  unsigned int v4; // esi
  int v5; // ecx
  unsigned int v6; // eax
  int v7; // edx
  unsigned int v8; // ecx
  int v9; // esi
  int v10; // eax

  v1 = (unsigned int)this >> 16; /*0x1039ad4f0*/
  if ( (unsigned int)this < 0x10000 ) /*0x1039ad4fe*/
    v1 = (unsigned int)this; /*0x1039ad4fe*/
  v2 = 16 * ((unsigned int)this < 0x10000); /*0x1039ad501*/
  v3 = v2 + 16; /*0x1039ad504*/
  v4 = v1 >> 8; /*0x1039ad509*/
  v5 = v2 | 8; /*0x1039ad50c*/
  if ( v1 < 0x100 ) /*0x1039ad514*/
  {
    v4 = v1; /*0x1039ad514*/
    v5 = v3; /*0x1039ad517*/
  }
  v6 = v4 >> 4; /*0x1039ad51c*/
  v7 = v5 - 4; /*0x1039ad51f*/
  if ( v4 < 0x10 ) /*0x1039ad525*/
  {
    v6 = v4; /*0x1039ad525*/
    v7 = v5; /*0x1039ad528*/
  }
  v8 = v6 >> 2; /*0x1039ad52d*/
  v9 = v7 - 2; /*0x1039ad530*/
  if ( v6 < 4 ) /*0x1039ad536*/
  {
    v8 = v6; /*0x1039ad536*/
    v9 = v7; /*0x1039ad539*/
  }
  v10 = -2; /*0x1039ad543*/
  if ( v8 < 2 ) /*0x1039ad548*/
    v10 = -v8; /*0x1039ad548*/
  return (unsigned int)(v9 + v10); /*0x1039ad54d*/
}

// Address: 0x1039ad550 | Name: __ZN6RakNet9BitStream21NumberOfLeadingZeroesEx
__int64 __fastcall RakNet::BitStream::NumberOfLeadingZeroes(RakNet::BitStream *this, unsigned __int64 a2)
{
  return RakNet::BitStream::NumberOfLeadingZeroes(this, a2); /*0x1039ad554*/
}

// Address: 0x1039ad55a | Name: __ZN6RakNet9BitStream21NumberOfLeadingZeroesEy
__int64 __fastcall RakNet::BitStream::NumberOfLeadingZeroes(unsigned __int64 this)
{
  unsigned __int64 v1; // rcx
  int v2; // eax
  int v3; // edx
  unsigned __int64 v4; // rsi
  int v5; // eax
  unsigned __int64 v6; // rcx
  int v7; // edx
  unsigned __int64 v8; // rax
  int v9; // esi
  unsigned __int64 v10; // rcx
  int v11; // edx
  int v12; // eax

  v1 = HIDWORD(this); /*0x1039ad563*/
  if ( HIDWORD(this) == 0 ) /*0x1039ad56a*/
    v1 = this; /*0x1039ad56a*/
  v2 = 32 * (HIDWORD(this) == 0); /*0x1039ad56e*/
  v3 = v2 + 32; /*0x1039ad571*/
  v4 = v1 >> 16; /*0x1039ad577*/
  v5 = v2 | 0x10; /*0x1039ad57b*/
  if ( v1 < 0x10000 ) /*0x1039ad585*/
  {
    v4 = v1; /*0x1039ad585*/
    v5 = v3; /*0x1039ad589*/
  }
  v6 = v4 >> 8; /*0x1039ad58f*/
  v7 = v5 - 8; /*0x1039ad593*/
  if ( v4 < 0x100 ) /*0x1039ad59d*/
  {
    v6 = v4; /*0x1039ad59d*/
    v7 = v5; /*0x1039ad5a1*/
  }
  v8 = v6 >> 4; /*0x1039ad5a7*/
  v9 = v7 - 4; /*0x1039ad5ab*/
  if ( v6 < 0x10 ) /*0x1039ad5b2*/
  {
    v8 = v6; /*0x1039ad5b2*/
    v9 = v7; /*0x1039ad5b6*/
  }
  v10 = v8 >> 2; /*0x1039ad5bc*/
  v11 = v9 - 2; /*0x1039ad5c0*/
  if ( v8 < 4 ) /*0x1039ad5c7*/
  {
    v10 = v8; /*0x1039ad5c7*/
    v11 = v9; /*0x1039ad5cb*/
  }
  v12 = -2; /*0x1039ad5d6*/
  if ( v10 < 2 ) /*0x1039ad5db*/
    v12 = -(int)v10; /*0x1039ad5db*/
  return (unsigned int)(v11 + v12); /*0x1039ad5e0*/
}

// Address: 0x1039ad5e2 | Name: __ZN6RakNet9BitStream17AssertStreamEmptyEv
void __fastcall RakNet::BitStream::AssertStreamEmpty(RakNet::BitStream *this)
{
  ; /*0x1039ad5e2*/
}

// Address: 0x1039ad5e8 | Name: __ZNK6RakNet9BitStream9PrintBitsEPc
__int64 __fastcall RakNet::BitStream::PrintBits(RakNet::BitStream *this, char *a2)
{
  int v2; // eax
  unsigned int v3; // edx
  unsigned __int64 v4; // rcx
  unsigned int v5; // r10d
  int v6; // r8d
  __int64 v7; // rax
  unsigned int v8; // r8d
  unsigned int v9; // r9d
  unsigned int v10; // edx
  int v11; // r11d
  unsigned __int8 v12; // cf
  __int64 v13; // r14
  bool v14; // r11

  v2 = *((_DWORD *)this + 3); /*0x1039ad5ef*/
  if ( v2 != 0 ) /*0x1039ad5f4*/
  {
    v3 = 0; /*0x1039ad5fd*/
    if ( (unsigned int)(v2 + 7) >= 8 ) /*0x1039ad602*/
    {
      v4 = 0; /*0x1039ad608*/
      v5 = 0; /*0x1039ad60a*/
      do /*0x1039ad685*/
      {
        v6 = -v2; /*0x1039ad610*/
        v7 = (unsigned int)(v2 - 1) >> 3; /*0x1039ad615*/
        v8 = v6 & 7; /*0x1039ad618*/
        v9 = 7; /*0x1039ad61c*/
        v10 = v5; /*0x1039ad622*/
        do /*0x1039ad65f*/
        {
          v11 = *(unsigned __int8 *)(*((_QWORD *)this + 3) + v4); /*0x1039ad630*/
          v12 = _bittest(&v11, v9); /*0x1039ad635*/
          v13 = v10++; /*0x1039ad63f*/
          v14 = v8 > v9 - 1; /*0x1039ad64b*/
          a2[v13] = !v12 ^ 0x31; /*0x1039ad64f*/
          if ( v9 == 0 ) /*0x1039ad657*/
            break; /*0x1039ad657*/
          --v9; /*0x1039ad659*/
        }
        while ( !v14 || v4 != v7 ); /*0x1039ad65f*/
        v5 = v10 + 1; /*0x1039ad661*/
        a2[v10] = 32; /*0x1039ad667*/
        if ( v10 + 1 > 0x7CF ) /*0x1039ad672*/
          break; /*0x1039ad672*/
        ++v4; /*0x1039ad674*/
        v2 = *((_DWORD *)this + 3); /*0x1039ad677*/
      }
      while ( v4 < (unsigned int)(v2 + 7) >> 3 ); /*0x1039ad685*/
      v3 = v10 + 1; /*0x1039ad687*/
    }
    a2[v3] = 10; /*0x1039ad68d*/
    a2[v3 + 1] = 0; /*0x1039ad691*/
    return v3; /*0x1039ad689*/
  }
  else
  {
    strcpy(a2, "No bits\n"); /*0x1039ad6a1*/
    return 0xA73746962206F4ELL; /*0x1039ad697*/
  }
}

// Address: 0x1039ad6ae | Name: __ZNK6RakNet9BitStream9PrintBitsEv
__int64 __fastcall RakNet::BitStream::PrintBits(RakNet::BitStream *this)
{
  char v2[2048]; // [rsp+0h] [rbp-810h] BYREF

  RakNet::BitStream::PrintBits(this, a2: v2); /*0x1039ad6d2*/
  printf(a1: "%s", v2); /*0x1039ad6e3*/
  return __stack_chk_guard; /*0x1039ad6f8*/
}

// Address: 0x1039ad708 | Name: __ZNK6RakNet9BitStream8PrintHexEPc
__int64 __fastcall RakNet::BitStream::PrintHex(RakNet::BitStream *this, char *a2)
{
  __int64 result; // rax
  unsigned int v5; // r12d
  int v6; // r13d
  unsigned __int64 v7; // r15

  result = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)this + 24LL))(a1: this); /*0x1039ad71f*/
  if ( (_DWORD)result != 0 ) /*0x1039ad724*/
  {
    v5 = 2048; /*0x1039ad726*/
    v6 = 0; /*0x1039ad72c*/
    v7 = 0; /*0x1039ad72f*/
    do /*0x1039ad76b*/
    {
      snprintf(__str: &a2[v6], __size: v5, __format: "%02x ", *(unsigned __int8 *)(*((_QWORD *)this + 3) + v7++)); /*0x1039ad74d*/
      result = (*(unsigned int (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)this + 24LL))(a1: this); /*0x1039ad75e*/
      v5 -= 3; /*0x1039ad760*/
      v6 += 3; /*0x1039ad764*/
    }
    while ( v7 < (unsigned int)result ); /*0x1039ad76b*/
  }
  return result; /*0x1039ad771*/
}

// Address: 0x1039ad77c | Name: __ZNK6RakNet9BitStream8PrintHexEv
__int64 __fastcall RakNet::BitStream::PrintHex(RakNet::BitStream *this)
{
  char v2[2048]; // [rsp+0h] [rbp-810h] BYREF

  RakNet::BitStream::PrintHex(this, a2: v2); /*0x1039ad7a0*/
  printf(a1: "%s", v2); /*0x1039ad7b1*/
  return __stack_chk_guard; /*0x1039ad7c6*/
}

// Address: 0x1039ad7d6 | Name: __ZN6RakNet9BitStream10IgnoreBitsEj
void __fastcall RakNet::BitStream::IgnoreBits(RakNet::BitStream *this, int a2)
{
  *((_DWORD *)this + 5) += a2; /*0x1039ad7da*/
}

// Address: 0x1039ad7e0 | Name: __ZN6RakNet9BitStream11IgnoreBytesEj
void __fastcall RakNet::BitStream::IgnoreBytes(RakNet::BitStream *this, int a2)
{
  *((_DWORD *)this + 5) += 8 * a2; /*0x1039ad7e7*/
}

// Address: 0x1039ad7ec | Name: __ZN6RakNet9BitStream14SetWriteOffsetEjb
void __fastcall RakNet::BitStream::SetWriteOffset(RakNet::BitStream *this, unsigned int a2, int a3)
{
  unsigned int v5; // esi
  char v6; // cl
  __int64 v7; // rdx
  int v8; // eax
  __int64 v9; // rsi
  unsigned int v10; // edi
  __int64 v11; // rsi

  if ( a3 != 0 ) /*0x1039ad7fa*/
  {
    v5 = *((_DWORD *)this + 3); /*0x1039ad7fc*/
    if ( v5 > a2 ) /*0x1039ad802*/
    {
      v6 = a2 & 7; /*0x1039ad806*/
      v7 = a2 >> 3; /*0x1039ad80b*/
      v8 = *((_DWORD *)this + 3) & 7; /*0x1039ad810*/
      v9 = v5 >> 3; /*0x1039ad813*/
      if ( (_DWORD)v9 == (_DWORD)v7 ) /*0x1039ad818*/
      {
        v10 = 0xFFu >> v8; /*0x1039ad828*/
        if ( v8 == 0 ) /*0x1039ad82c*/
          LOBYTE(v10) = 0; /*0x1039ad82c*/
        *(_BYTE *)(*((_QWORD *)this + 3) + v7) &= (unsigned __int8)(0xFF00u >> v6) | (unsigned __int8)v10; /*0x1039ad835*/
      }
      else
      {
        if ( (a2 & 7) != 0 ) /*0x1039ad83d*/
        {
          *(_BYTE *)(*((_QWORD *)this + 3) + v7) &= 0xFF00u >> v6; /*0x1039ad84a*/
          LODWORD(v7) = v7 + 1; /*0x1039ad84e*/
        }
        if ( v8 != 0 ) /*0x1039ad852*/
          *(_BYTE *)(*((_QWORD *)this + 3) + v9) &= 0xFFu >> v8; /*0x1039ad861*/
        v11 = (unsigned int)(v9 - v7); /*0x1039ad865*/
        if ( (_DWORD)v11 != 0 ) /*0x1039ad867*/
          __bzero(a1: *((_QWORD *)this + 3) + (unsigned int)v7, a2: v11); /*0x1039ad86f*/
      }
    }
  }
  *((_DWORD *)this + 3) = a2; /*0x1039ad874*/
}

// Address: 0x1039ad87e | Name: __ZN6RakNet9BitStream14AssertCopyDataEv
void __fastcall RakNet::BitStream::AssertCopyData(RakNet::BitStream *this, unsigned __int64 a2)
{
  int v3; // edi
  void *v4; // r14

  if ( *((_BYTE *)this + 32) == 0 ) /*0x1039ad882*/
  {
    *((_BYTE *)this + 32) = 1; /*0x1039ad88f*/
    v3 = *((_DWORD *)this + 4); /*0x1039ad893*/
    if ( v3 != 0 ) /*0x1039ad898*/
    {
      v4 = (void *)RBX::Memory::allocateOrCrash(this: (RBX::Memory *)((unsigned int)(v3 + 7) >> 3), a2); /*0x1039ad8a5*/
      memcpy(__dst: v4, __src: *((const void **)this + 3), __n: (unsigned int)(*((_DWORD *)this + 4) + 7) >> 3); /*0x1039ad8b8*/
      *((_QWORD *)this + 3) = v4; /*0x1039ad8bd*/
    }
    else
    {
      *((_QWORD *)this + 3) = 0; /*0x1039ad8c3*/
    }
  }
}

// Address: 0x1039ad8d0 | Name: __ZN6RakNet9BitStream22IsNetworkOrderInternalEv
__int64 __fastcall RakNet::BitStream::IsNetworkOrderInternal(RakNet::BitStream *this)
{
  return 0; /*0x1039ad8d6*/
}

// Address: 0x1039ad8d8 | Name: __ZN6RakNet9BitStream12ReverseBytesEPhS1_j
void __fastcall RakNet::BitStream::ReverseBytes(RakNet::BitStream *this, unsigned __int8 *a2, unsigned __int8 *a3)
{
  __int64 v3; // rax
  unsigned int v4; // edx
  __int64 i; // rcx

  if ( (_DWORD)a3 != 0 ) /*0x1039ad8de*/
  {
    v3 = (unsigned int)a3; /*0x1039ad8e0*/
    v4 = (_DWORD)a3 - 1; /*0x1039ad8e2*/
    for ( i = 0; i != v3; ++i ) /*0x1039ad8e4*/
      a2[i] = *((_BYTE *)this + v4--); /*0x1039ad8ed*/
  }
}

// Address: 0x1039ad8fe | Name: __ZN6RakNet9BitStream4ReadEPc
__int64 __fastcall RakNet::BitStream::Read(RakNet::BitStream *this, RakNet::RakString *a2, RakNet::BitStream *a3)
{
  return RakNet::RakString::Deserialize(this: a2, a2: this, a3); /*0x1039ad90b*/
}

// Address: 0x1039ad912 | Name: __ZN6RakNet9BitStream4ReadEPh
__int64 __fastcall RakNet::BitStream::Read(RakNet::BitStream *this, RakNet::RakString *a2, RakNet::BitStream *a3)
{
  return RakNet::RakString::Deserialize(this: a2, a2: this, a3); /*0x1039ad91f*/
}

// Address: 0x1039ad926 | Name: __ZN6RakNet9BitStream16WriteAlignedVar8EPKc
char __fastcall RakNet::BitStream::WriteAlignedVar8(RakNet::BitStream *this, char *a2, unsigned __int64 a3)
{
  char result; // al

  RakNet::BitStream::AddBitsAndReallocate(this, a2: 8u, a3); /*0x1039ad938*/
  result = *a2; /*0x1039ad93d*/
  *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3)) = *a2; /*0x1039ad94a*/
  *((_DWORD *)this + 3) += 8; /*0x1039ad94d*/
  return result; /*0x1039ad952*/
}

// Address: 0x1039ad958 | Name: __ZN6RakNet9BitStream15ReadAlignedVar8EPc
bool __fastcall RakNet::BitStream::ReadAlignedVar8(RakNet::BitStream *this, char *a2)
{
  unsigned int v2; // eax
  unsigned int v3; // edx

  v2 = *((_DWORD *)this + 3); /*0x1039ad958*/
  v3 = *((_DWORD *)this + 5); /*0x1039ad95b*/
  if ( v3 + 8 <= v2 ) /*0x1039ad963*/
  {
    *a2 = *(_BYTE *)(*((_QWORD *)this + 3) + (v3 >> 3)); /*0x1039ad974*/
    *((_DWORD *)this + 5) += 8; /*0x1039ad976*/
  }
  return v3 + 8 <= v2; /*0x1039ad980*/
}

// Address: 0x1039ad982 | Name: __ZN6RakNet9BitStream17WriteAlignedVar16EPKc
char __fastcall RakNet::BitStream::WriteAlignedVar16(RakNet::BitStream *this, char *a2, unsigned __int64 a3)
{
  RakNet::BitStream *v5; // rdi
  const char *v6; // rsi
  char result; // al

  RakNet::BitStream::AddBitsAndReallocate(this, a2: 0x10u, a3); /*0x1039ad994*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 ) /*0x1039ad9a1*/
    RakNet::BitStream::WriteAlignedVar16(this: v5, a2: v6); /*0x1039ad9ec*/
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ad9aa*/
    *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3)) = *a2++; /*0x1039ad9b9*/
  else
    *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3)) = a2[1]; /*0x1039ad9cf*/
  result = *a2; /*0x1039ad9d2*/
  *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3) + 1LL) = *a2; /*0x1039ad9df*/
  *((_DWORD *)this + 3) += 16; /*0x1039ad9e3*/
  return result; /*0x1039ad9e7*/
}

// Address: 0x1039ad9f4 | Name: __ZN6RakNet9BitStream16ReadAlignedVar16EPc
bool __fastcall RakNet::BitStream::ReadAlignedVar16(RakNet::BitStream *this, char *a2)
{
  unsigned int v2; // r15d
  unsigned int v3; // r12d
  __int64 v6; // rax
  __int64 v7; // rcx
  char *v8; // rax

  v2 = *((_DWORD *)this + 3); /*0x1039ad9ff*/
  v3 = *((_DWORD *)this + 5) + 16; /*0x1039ada07*/
  if ( v3 <= v2 ) /*0x1039ada0e*/
  {
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 ) /*0x1039ada1e*/
      RakNet::BitStream::ReadAlignedVar16(this, a2); /*0x1039ada75*/
    v6 = *((_QWORD *)this + 3); /*0x1039ada20*/
    v7 = *((_DWORD *)this + 5) >> 3; /*0x1039ada27*/
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039ada31*/
    {
      *a2 = *(_BYTE *)(v6 + v7); /*0x1039ada36*/
      v8 = (char *)((*((_DWORD *)this + 5) >> 3) + *((_QWORD *)this + 3) + 1LL); /*0x1039ada46*/
    }
    else
    {
      *a2 = *(_BYTE *)(v6 + v7 + 1); /*0x1039ada4f*/
      v8 = (char *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 5) >> 3)); /*0x1039ada58*/
    }
    a2[1] = *v8; /*0x1039ada5e*/
    *((_DWORD *)this + 5) += 16; /*0x1039ada62*/
  }
  return v3 <= v2; /*0x1039ada6c*/
}

// Address: 0x1039ada7c | Name: __ZN6RakNet9BitStream17WriteAlignedVar32EPKc
char __fastcall RakNet::BitStream::WriteAlignedVar32(RakNet::BitStream *this, const char *a2, unsigned __int64 a3)
{
  RakNet::BitStream *v5; // rdi
  const char *v6; // rsi
  char result; // al

  RakNet::BitStream::AddBitsAndReallocate(this, a2: 0x20u, a3); /*0x1039ada8e*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 ) /*0x1039ada9b*/
    RakNet::BitStream::WriteAlignedVar32(this: v5, a2: v6); /*0x1039adb33*/
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039adaa8*/
  {
    *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3)) = *a2; /*0x1039adab7*/
    *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3) + 1LL) = a2[1]; /*0x1039adac8*/
    *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3) + 2LL) = a2[2]; /*0x1039adada*/
    a2 += 3; /*0x1039adade*/
  }
  else
  {
    *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3)) = a2[3]; /*0x1039adaf2*/
    *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3) + 1LL) = a2[2]; /*0x1039adb03*/
    *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3) + 2LL) = a2[1]; /*0x1039adb15*/
  }
  result = *a2; /*0x1039adb19*/
  *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 3) >> 3) + 3LL) = *a2; /*0x1039adb26*/
  *((_DWORD *)this + 3) += 32; /*0x1039adb2a*/
  return result; /*0x1039adb2e*/
}

// Address: 0x1039adb3e | Name: __ZN6RakNet9BitStream16ReadAlignedVar32EPc
bool __fastcall RakNet::BitStream::ReadAlignedVar32(RakNet::BitStream *this, char *a2)
{
  unsigned int v2; // r15d
  unsigned int v3; // r12d
  __int64 v6; // rax
  __int64 v7; // rcx
  char *v8; // rax

  v2 = *((_DWORD *)this + 3); /*0x1039adb49*/
  v3 = *((_DWORD *)this + 5) + 32; /*0x1039adb51*/
  if ( v3 <= v2 ) /*0x1039adb58*/
  {
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 ) /*0x1039adb6c*/
      RakNet::BitStream::ReadAlignedVar32(this, a2); /*0x1039adc10*/
    v6 = *((_QWORD *)this + 3); /*0x1039adb72*/
    v7 = *((_DWORD *)this + 5) >> 3; /*0x1039adb79*/
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039adb83*/
    {
      *a2 = *(_BYTE *)(v6 + v7); /*0x1039adb88*/
      a2[1] = *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 5) >> 3) + 1LL); /*0x1039adb99*/
      a2[2] = *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 5) >> 3) + 2LL); /*0x1039adbab*/
      v8 = (char *)((*((_DWORD *)this + 5) >> 3) + *((_QWORD *)this + 3) + 3LL); /*0x1039adbbc*/
    }
    else
    {
      *a2 = *(_BYTE *)(v6 + v7 + 3); /*0x1039adbc6*/
      a2[1] = *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 5) >> 3) + 2LL); /*0x1039adbd7*/
      a2[2] = *(_BYTE *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 5) >> 3) + 1LL); /*0x1039adbe9*/
      v8 = (char *)(*((_QWORD *)this + 3) + (*((_DWORD *)this + 5) >> 3)); /*0x1039adbf3*/
    }
    a2[3] = *v8; /*0x1039adbf9*/
    *((_DWORD *)this + 5) += 32; /*0x1039adbfd*/
  }
  return v3 <= v2; /*0x1039adc07*/
}

// Address: 0x1039adc1a | Name: __ZN6RakNet9BitStream11ReadFloat16ERfff
char __fastcall RakNet::BitStream::ReadFloat16(RakNet::BitStream *this, float *a2, float a3, float a4)
{
  float v6; // xmm0_4
  char result; // al
  __int16 v10; // [rsp+Ch] [rbp-14h] BYREF
  unsigned __int16 v11; // [rsp+Eh] [rbp-12h] BYREF

  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 ) /*0x1039adc3d*/
    RakNet::BitStream::ReadFloat16(this, a2, a3, a4); /*0x1039adce3*/
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039adc4a*/
  {
    if ( RakNet::BitStream::ReadBits(this, a2: (unsigned __int8 *)&v11, a3: 0x10u, a4: 1) == 0 ) /*0x1039adc64*/
      return 0; /*0x1039adc64*/
  }
  else
  {
    if ( RakNet::BitStream::ReadBits(this, a2: (unsigned __int8 *)&v10, a3: 0x10u, a4: 1) == 0 ) /*0x1039adc80*/
      return 0; /*0x1039adccb*/
    v11 = __ROL2__(v10, 8); /*0x1039adc8a*/
  }
  v6 = (float)((float)(a4 - a3) * (float)((float)v11 / 65535.0)) + a3; /*0x1039adcb6*/
  *a2 = v6; /*0x1039adcba*/
  if ( a3 <= v6 ) /*0x1039adcc1*/
  {
    result = 1; /*0x1039adcd6*/
    if ( v6 > a4 ) /*0x1039adcdb*/
      *a2 = a4; /*0x1039adcdd*/
  }
  else
  {
    *a2 = a3; /*0x1039adcc3*/
    return 1; /*0x1039adcc7*/
  }
  return result; /*0x1039adccd*/
}

// Address: 0x1039adcee | Name: __ZN6RakNet9BitStream16SerializeFloat16EbRfff
char __fastcall RakNet::BitStream::SerializeFloat16(RakNet::BitStream *this, int a2, float *a3, float a4, float a5)
{
  if ( a2 == 0 ) /*0x1039adcf6*/
    return RakNet::BitStream::ReadFloat16(this, a2: a3, a3: a4, a4: a5); /*0x1039add12*/
  RakNet::BitStream::WriteFloat16(this, a2: *a3, a3: a4, a4: a5); /*0x1039add00*/
  return 1; /*0x1039add08*/
}

// Address: 0x1039add18 | Name: __ZN6RakNet9BitStream12WriteFloat16Efff
void *__fastcall RakNet::BitStream::WriteFloat16(RakNet::BitStream *this, float a2, float a3, float a4)
{
  __int64 v4; // rax
  float v5; // xmm2_4
  float v6; // xmm0_4
  float v7; // xmm1_4
  const unsigned __int8 *v9; // rsi
  __int16 v11; // [rsp+0h] [rbp-Ch] BYREF
  __int16 v12; // [rsp+2h] [rbp-Ah] BYREF

  v11 = WORD2(v4); /*0x1039add1d*/
  v5 = a4 - a3; /*0x1039add2e*/
  v6 = (float)((float)(a2 - a3) * 65535.0) / v5; /*0x1039add32*/
  v7 = fmaxf(0.0, v6); /*0x1039add39*/
  v12 = (int)fminf(65535.0, v7); /*0x1039add48*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 ) /*0x1039add54*/
    RakNet::BitStream::WriteFloat16(this, a2: v6, a3: v7, a4: v5); /*0x1039add8d*/
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039add5d*/
  {
    v9 = (const unsigned __int8 *)&v12; /*0x1039add5f*/
  }
  else
  {
    v9 = (const unsigned __int8 *)&v11; /*0x1039add6d*/
    v11 = __ROL2__(v12, 8); /*0x1039add71*/
  }
  return RakNet::BitStream::WriteBits(this, a2: v9, a3: 0x10u, a4: 1); /*0x1039add8a*/
}

// Address: 0x1039add94 | Name: __ZNK6RakNet9BitStream7GetDataEv
__int64 __fastcall RakNet::BitStream::GetData(RakNet::BitStream *this)
{
  return *((_QWORD *)this + 3); /*0x1039add9c*/
}

// Address: 0x1039add9e | Name: __ZNK6RakNet9BitStream20GetNumberOfBytesUsedEv
__int64 __fastcall RakNet::BitStream::GetNumberOfBytesUsed(RakNet::BitStream *this)
{
  return (unsigned int)(*((_DWORD *)this + 3) + 7) >> 3; /*0x1039addab*/
}

// Address: 0x1039c0266 | Name: __ZN6RakNet9BitStream4ReadINS_10RakNetGUIDEEEbRT_
char __fastcall RakNet::BitStream::Read<RakNet::RakNetGUID>(RakNet::BitStream *this, unsigned __int8 *a2)
{
  char Bits; // r14
  RakNet::BitStream *v6; // rdi
  unsigned __int8 v7[8]; // [rsp+0h] [rbp-20h] BYREF

  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039c0325*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v6); /*0x1039c0330*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039c033d*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039c029a*/
    return RakNet::BitStream::ReadBits(this, a2, a3: 0x40u, a4: 1); /*0x1039c02c8*/
  Bits = RakNet::BitStream::ReadBits(this, a2: v7, a3: 0x40u, a4: 1); /*0x1039c02e3*/
  if ( Bits != 0 ) /*0x1039c02e8*/
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v7, a2, a3: (unsigned __int8 *)8); /*0x1039c02f6*/
  return Bits; /*0x1039c02c0*/
}

// Address: 0x1039c924e | Name: __ZN6RakNet9BitStream4ReadINS_13SystemAddressEEEbRT_
char __fastcall RakNet::BitStream::Read<RakNet::SystemAddress>(RakNet::BitStream *this, __int64 a2)
{
  __int64 v2; // rax
  char result; // al
  unsigned __int8 v6[32]; // [rsp+0h] [rbp-20h] BYREF

  *(_QWORD *)v6 = v2; /*0x1039c9257*/
  RakNet::BitStream::ReadBits(this, a2: &v6[7], a3: 8u, a4: 1); /*0x1039c926f*/
  if ( v6[7] != 4 ) /*0x1039c9278*/
    return 0; /*0x1039c92c3*/
  *(_BYTE *)(a2 + 1) = 2; /*0x1039c927a*/
  RakNet::BitStream::ReadBits(this, a2: v6, a3: 0x20u, a4: 1); /*0x1039c9292*/
  *(_DWORD *)(a2 + 4) = ~*(_DWORD *)v6; /*0x1039c929c*/
  result = RakNet::BitStream::ReadBits(this, a2: (unsigned __int8 *)(a2 + 2), a3: 0x10u, a4: 1); /*0x1039c92b0*/
  *(_WORD *)(a2 + 28) = __ROL2__(*(_WORD *)(a2 + 2), 8); /*0x1039c92bd*/
  return result; /*0x1039c92c9*/
}

// Address: 0x1039cab82 | Name: __ZN6RakNet9BitStream4ReadItEEbRT_
char __fastcall RakNet::BitStream::Read<unsigned short>(RakNet::BitStream *this, unsigned __int8 *a2)
{
  char Bits; // r14
  RakNet::BitStream *v6; // rdi
  unsigned __int8 v7[18]; // [rsp+Eh] [rbp-12h] BYREF

  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039cac0b*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v6); /*0x1039cac12*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cac1f*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039caba4*/
    return RakNet::BitStream::ReadBits(this, a2, a3: 0x10u, a4: 1); /*0x1039cabbe*/
  Bits = RakNet::BitStream::ReadBits(this, a2: v7, a3: 0x10u, a4: 1); /*0x1039cabd9*/
  if ( Bits != 0 ) /*0x1039cabde*/
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v7, a2, a3: (unsigned __int8 *)2); /*0x1039cabec*/
  return Bits; /*0x1039cabb6*/
}

// Address: 0x1039d9f28 | Name: __ZN6RakNet9BitStream5WriteINS_8uint24_tEEEvRKT_
char __fastcall RakNet::BitStream::Write<RakNet::uint24_t>(__int64 a1, _BYTE *a2, unsigned __int64 a3)
{
  _BYTE *v5; // rcx
  __int64 v6; // rax
  char result; // al
  RakNet::BitStream *v8; // rdi

  *(_DWORD *)(a1 + 12) += -*(_DWORD *)(a1 + 12) & 7; /*0x1039d9f41*/
  RakNet::BitStream::AddBitsAndReallocate(this: (RakNet::BitStream *)a1, a2: 0x18u, a3); /*0x1039d9f49*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039d9fcf*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v8); /*0x1039d9fd6*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039d9fe3*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039d9f5f*/
  {
    *(_BYTE *)(*(_QWORD *)(a1 + 24) + (*(_DWORD *)(a1 + 12) >> 3)) = a2[3]; /*0x1039d9f6f*/
    v5 = a2 + 2; /*0x1039d9f72*/
    v6 = 1; /*0x1039d9f76*/
  }
  else
  {
    *(_BYTE *)(*(_QWORD *)(a1 + 24) + (*(_DWORD *)(a1 + 12) >> 3)) = *a2; /*0x1039d9f8a*/
    v5 = a2 + 1; /*0x1039d9f8d*/
    v6 = 2; /*0x1039d9f91*/
  }
  *(_BYTE *)(*(_QWORD *)(a1 + 24) + (*(_DWORD *)(a1 + 12) >> 3) + 1LL) = *v5; /*0x1039d9fa2*/
  result = a2[v6]; /*0x1039d9fa6*/
  *(_BYTE *)(*(_QWORD *)(a1 + 24) + (*(_DWORD *)(a1 + 12) >> 3) + 2LL) = result; /*0x1039d9fb4*/
  *(_DWORD *)(a1 + 12) += 24; /*0x1039d9fb8*/
  return result; /*0x1039d9fbc*/
}

// Address: 0x1039da584 | Name: __ZN6RakNet9BitStream4ReadINS_8uint24_tEEEbRT_
bool __fastcall RakNet::BitStream::Read<RakNet::uint24_t>(__int64 a1, _BYTE *a2)
{
  unsigned int v2; // r15d
  int v3; // eax
  int v4; // ecx
  unsigned int v5; // r12d
  char v8; // al
  RakNet::BitStream *v10; // rdi

  v2 = *(_DWORD *)(a1 + 12); /*0x1039da58f*/
  v3 = *(_DWORD *)(a1 + 20); /*0x1039da593*/
  v4 = -v3 & 7; /*0x1039da59a*/
  *(_DWORD *)(a1 + 20) = v4 + v3; /*0x1039da5a0*/
  v5 = v4 + v3 + 24; /*0x1039da5a7*/
  if ( v5 <= v2 ) /*0x1039da5ae*/
  {
    if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039da659*/
      && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
    {
      RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v10); /*0x1039da664*/
      __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039da671*/
    }
    v8 = *(_BYTE *)(*(_QWORD *)(a1 + 24) + (*(_DWORD *)(a1 + 20) >> 3)); /*0x1039da5d2*/
    if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039da5dc*/
    {
      a2[3] = v8; /*0x1039da5de*/
      a2[2] = *(_BYTE *)(*(_QWORD *)(a1 + 24) + (*(_DWORD *)(a1 + 20) >> 3) + 1LL); /*0x1039da5f0*/
      a2[1] = *(_BYTE *)(*(_QWORD *)(a1 + 24) + (*(_DWORD *)(a1 + 20) >> 3) + 2LL); /*0x1039da602*/
      *a2 = 0; /*0x1039da606*/
    }
    else
    {
      *a2 = v8; /*0x1039da60c*/
      a2[1] = *(_BYTE *)(*(_QWORD *)(a1 + 24) + (*(_DWORD *)(a1 + 20) >> 3) + 1LL); /*0x1039da61d*/
      a2[2] = *(_BYTE *)(*(_QWORD *)(a1 + 24) + (*(_DWORD *)(a1 + 20) >> 3) + 2LL); /*0x1039da62f*/
      a2[3] = 0; /*0x1039da633*/
    }
    *(_DWORD *)(a1 + 20) += 24; /*0x1039da638*/
  }
  return v5 <= v2; /*0x1039da642*/
}

// Address: 0x1086697dd | Name: __ZN6RakNet9BitStream15EndianSwapBytesEii.cold.1
void __fastcall RakNet::BitStream::EndianSwapBytes(RakNet::BitStream *this)
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 ) /*0x1086697ef*/
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = 0; /*0x1086697f1*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x108669800*/
  }
}

// Address: 0x108669807 | Name: __ZN6RakNet9BitStream17WriteAlignedVar16EPKc.cold.1
void __fastcall RakNet::BitStream::WriteAlignedVar16(RakNet::BitStream *this, const char *a2)
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 ) /*0x108669819*/
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = 0; /*0x10866981b*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x10866982a*/
  }
}

// Address: 0x108669831 | Name: __ZN6RakNet9BitStream16ReadAlignedVar16EPc.cold.1
void __fastcall RakNet::BitStream::ReadAlignedVar16(RakNet::BitStream *this, char *a2)
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 ) /*0x108669843*/
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = 0; /*0x108669845*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x108669854*/
  }
}

// Address: 0x10866985b | Name: __ZN6RakNet9BitStream17WriteAlignedVar32EPKc.cold.1
void __fastcall RakNet::BitStream::WriteAlignedVar32(RakNet::BitStream *this, const char *a2)
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 ) /*0x10866986d*/
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = 0; /*0x10866986f*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x10866987e*/
  }
}

// Address: 0x108669885 | Name: __ZN6RakNet9BitStream16ReadAlignedVar32EPc.cold.1
void __fastcall RakNet::BitStream::ReadAlignedVar32(RakNet::BitStream *this, char *a2)
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 ) /*0x108669897*/
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = 0; /*0x108669899*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1086698a8*/
  }
}

// Address: 0x1086698af | Name: __ZN6RakNet9BitStream11ReadFloat16ERfff.cold.1
void __fastcall RakNet::BitStream::ReadFloat16(RakNet::BitStream *this, float *a2, float a3, float a4)
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 ) /*0x1086698c1*/
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = 0; /*0x1086698c3*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1086698d2*/
  }
}

// Address: 0x1086698d9 | Name: __ZN6RakNet9BitStream12WriteFloat16Efff.cold.1
void __fastcall RakNet::BitStream::WriteFloat16(RakNet::BitStream *this, float a2, float a3, float a4)
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 ) /*0x1086698eb*/
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = 0; /*0x1086698ed*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1086698fc*/
  }
}

// END BitStream part 1/1, 83 functions
