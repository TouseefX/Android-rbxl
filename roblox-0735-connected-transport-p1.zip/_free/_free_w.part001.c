// _free_w -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 400 functions, part 1 of 4


// Address: 0x102b1ebab | Name: __ZL21writeInferredHangFilePKc
__int64 __fastcall writeInferredHangFile(const char *__s)
{
  const char *v2; // r12
  size_t v3; // rax
  char v5; // [rsp+0h] [rbp-280h] BYREF
  char v6; // [rsp+1h] [rbp-27Fh] BYREF
  void *v7; // [rsp+10h] [rbp-270h]
  __int64 (__fastcall **v8)(); // [rsp+18h] [rbp-268h] BYREF
  _QWORD v9[51]; // [rsp+20h] [rbp-260h] BYREF
  _QWORD v10[18]; // [rsp+1B8h] [rbp-C8h] BYREF
  int v11; // [rsp+248h] [rbp-38h]

  RBX::FileSystem::getCacheDirectory(this: (RBX::FileSystem *)&v5, a2: true, a3: nullptr); /*0x102b1ebde*/
  boost::filesystem::path::operator/=(this: (boost::filesystem::path *)&v5, a2: "RobloxInferredHang.txt"); /*0x102b1ebf1*/
  if ( (v5 & 1) != 0 ) /*0x102b1ebfd*/
    v2 = (const char *)v7; /*0x102b1ebff*/
  else
    v2 = &v6; /*0x102b1ec08*/
  v10[6] = 0; /*0x102b1ec16*/
  v8 = (__int64 (__fastcall **)())&off_10C447CA8; /*0x102b1ec30*/
  v10[0] = &off_10C447CD0; /*0x102b1ec38*/
  std::ios_base::init(this: (std::ios_base *)v10, a2: v9); /*0x102b1ec3e*/
  v10[17] = 0; /*0x102b1ec43*/
  v11 = -1; /*0x102b1ec4b*/
  v8 = &off_10C447C38; /*0x102b1ec5d*/
  v10[0] = off_10C447C60; /*0x102b1ec68*/
  std::filebuf::basic_filebuf(a1: v9); /*0x102b1ec72*/
  if ( std::filebuf::open(a1: (__int64)v9, a2: v2, a3: 0x14u) == 0 ) /*0x102b1ec8a*/
    std::ios_base::clear( /*0x102b1eca8*/
      this: (std::ios_base *)((char *)&v9[-1] + (_QWORD)*(v8 - 3)),
      a2: *(_DWORD *)((char *)&v9[3] + (_QWORD)*(v8 - 3)) | 4);
  if ( v9[15] != 0 ) /*0x102b1ecb5*/
  {
    v3 = strlen(__s); /*0x102b1ecba*/
    std::__put_character_sequence[abi:ne200100]<char,std::char_traits<char>>(a1: &v8, a2: __s, a3: v3); /*0x102b1eccc*/
    if ( std::filebuf::close(a1: v9) == nullptr ) /*0x102b1ecdc*/
      std::ios_base::clear( /*0x102b1ecfa*/
        this: (std::ios_base *)((char *)&v9[-1] + (_QWORD)*(v8 - 3)),
        a2: *(_DWORD *)((char *)&v9[3] + (_QWORD)*(v8 - 3)) | 4);
  }
  v8 = &off_10C447C38; /*0x102b1ed06*/
  v10[0] = off_10C447C60; /*0x102b1ed09*/
  std::filebuf::~filebuf(a1: (__int64)v9); /*0x102b1ed13*/
  std::ostream::~ostream(a1: &v8, a2: off_10C447C78); /*0x102b1ed26*/
  std::ios::~ios(a1: v10); /*0x102b1ed32*/
  if ( (v5 & 1) != 0 ) /*0x102b1ed3e*/
    operator delete(a1: v7); /*0x102b1ed47*/
  return __stack_chk_guard; /*0x102b1ed5c*/
}

// Address: 0x102c0fca0 | Name: _write_fp
size_t __fastcall write_fp(const void *a1, size_t a2, FILE *a3)
{
  return fwrite(a1, a2, a3: 1u, a4: a3); /*0x102c0fcac*/
}

// Address: 0x102c0fd00 | Name: _write_bio
int __fastcall write_bio(const void *a1, int a2, BIO *a3)
{
  return BIO_write(b: a3, data: a1, len: a2); /*0x102c0fd10*/
}

// Address: 0x102cc4a90 | Name: _wp_init
__int64 wp_init()
{
  __int64 v0; // rax

  v0 = EVP_MD_CTX_get0_md_data(); /*0x102cc4a94*/
  return WHIRLPOOL_Init(a1: v0); /*0x102cc4a9c*/
}

// Address: 0x102cc4ab0 | Name: _wp_update
__int64 __fastcall wp_update(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v5; // rax

  v5 = EVP_MD_CTX_get0_md_data(); /*0x102cc4abd*/
  return WHIRLPOOL_Update(a1: v5, a2, a3); /*0x102cc4acb*/
}

// Address: 0x102cc4ae0 | Name: _wp_final
__int64 __fastcall wp_final(__int64 a1, __int64 a2)
{
  __int64 v3; // rax

  v3 = EVP_MD_CTX_get0_md_data(a1); /*0x102cc4ae9*/
  return WHIRLPOOL_Final(a1: a2, a2: v3); /*0x102cc4af8*/
}

// Address: 0x102ce8a30 | Name: _WPACKET_sub_allocate_bytes__
__int64 __fastcall WPACKET_sub_allocate_bytes__(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  _QWORD *v8; // rax
  __int64 result; // rax
  __int64 v10; // rcx
  int v11; // ecx
  _QWORD *v12; // rsi
  int v13; // ecx
  int bytes; // ecx
  _BYTE v15[40]; // [rsp+8h] [rbp-28h] BYREF

  if ( *(_QWORD *)(a1 + 40) == 0 || a4 != 0 && (*(_BYTE *)(a1 + 48) & 1) != 0 ) /*0x102ce8a5b*/
    return 0; /*0x102ce8a5b*/
  v8 = (_QWORD *)CRYPTO_zalloc(__size: 0x28u, __s: "crypto/packet.c", line: 379); /*0x102ce8a6e*/
  if ( v8 == nullptr ) /*0x102ce8a76*/
    return 0; /*0x102ce8a76*/
  *v8 = *(_QWORD *)(a1 + 40); /*0x102ce8a8b*/
  v10 = *(_QWORD *)(a1 + 24); /*0x102ce8a8e*/
  *(_QWORD *)(a1 + 40) = v8; /*0x102ce8a96*/
  v8[3] = v10 + a4; /*0x102ce8a9a*/
  v8[2] = a4; /*0x102ce8a9e*/
  if ( a4 != 0 ) /*0x102ce8aa5*/
  {
    v8[1] = v10; /*0x102ce8aee*/
    bytes = WPACKET_allocate_bytes(a1, a2: a4, a3: v15); /*0x102ce8b01*/
    result = 0; /*0x102ce8b03*/
    if ( bytes == 0 ) /*0x102ce8b07*/
      return result; /*0x102ce8b07*/
  }
  else
  {
    v8[1] = 0; /*0x102ce8aa7*/
  }
  v11 = WPACKET_allocate_bytes(a1, a2, a3); /*0x102ce8abd*/
  result = 0; /*0x102ce8abf*/
  if ( v11 != 0 ) /*0x102ce8ac3*/
  {
    v12 = *(_QWORD **)(a1 + 40); /*0x102ce8ac5*/
    if ( v12 == nullptr ) /*0x102ce8acc*/
      return 0; /*0x102ce8acc*/
    if ( *v12 == 0 ) /*0x102ce8ad2*/
      return 0; /*0x102ce8ad2*/
    v13 = wpacket_intern_close(a1, a2: v12, a3: 1); /*0x102ce8ae1*/
    result = 1; /*0x102ce8ae3*/
    if ( v13 == 0 ) /*0x102ce8aea*/
      return 0; /*0x102ce8a78*/
  }
  return result; /*0x102ce8a7a*/
}

// Address: 0x102ce8b10 | Name: _WPACKET_close
__int64 __fastcall WPACKET_close(__int64 a1)
{
  _QWORD *v1; // rsi

  v1 = *(_QWORD **)(a1 + 40); /*0x102ce8b14*/
  if ( v1 != nullptr && *v1 != 0 ) /*0x102ce8b21*/
    return wpacket_intern_close(a1, a2: v1, a3: 1); /*0x102ce8b2d*/
  else
    return 0; /*0x102ce8b23*/
}

// Address: 0x102ce8b40 | Name: _WPACKET_get_curr
__int64 __fastcall WPACKET_get_curr(__int64 a1)
{
  __int64 v1; // rax

  v1 = *(_QWORD *)(a1 + 8); /*0x102ce8b44*/
  if ( v1 == 0 ) /*0x102ce8b4b*/
  {
    if ( *(_QWORD *)a1 == 0 ) /*0x102ce8b69*/
      return 0; /*0x102ce8b69*/
    v1 = *(_QWORD *)(*(_QWORD *)a1 + 8LL); /*0x102ce8b6b*/
    if ( v1 == 0 ) /*0x102ce8b72*/
      return 0; /*0x102ce8b74*/
  }
  if ( (*(_BYTE *)(a1 + 48) & 1) != 0 ) /*0x102ce8b51*/
    return *(_QWORD *)(a1 + 32) + v1 - *(_QWORD *)(a1 + 16); /*0x102ce8b5d*/
  return *(_QWORD *)(a1 + 16) + v1; /*0x102ce8b57*/
}

// Address: 0x102ce8b80 | Name: _WPACKET_init_null
_BOOL8 __fastcall WPACKET_init_null(__int64 a1, __int64 a2)
{
  __int64 v2; // r8
  __int64 v4; // rax

  v2 = a2 + ~(-1LL << (8 * (unsigned __int8)a2)); /*0x102ce8ba5*/
  if ( (unsigned __int64)(a2 - 8) < 0xFFFFFFFFFFFFFFF9LL ) /*0x102ce8bac*/
    v2 = -1; /*0x102ce8bac*/
  *(_OWORD *)a1 = 0; /*0x102ce8bb6*/
  *(_QWORD *)(a1 + 32) = v2; /*0x102ce8bb9*/
  *(_BYTE *)(a1 + 48) &= ~1u; /*0x102ce8bbd*/
  *(_OWORD *)(a1 + 16) = 0; /*0x102ce8bc1*/
  v4 = CRYPTO_zalloc(__size: 0x28u, __s: "crypto/packet.c", line: 110); /*0x102ce8bd6*/
  *(_QWORD *)(a1 + 40) = v4; /*0x102ce8bdb*/
  return v4 != 0; /*0x102ce8bed*/
}

// Address: 0x102ce8bf0 | Name: _WPACKET_init_null_der
_BOOL8 __fastcall WPACKET_init_null_der(__int64 a1)
{
  __int64 v2; // rax

  *(_OWORD *)a1 = 0; /*0x102ce8bfc*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102ce8bff*/
  *(_BYTE *)(a1 + 48) |= 1u; /*0x102ce8c07*/
  *(_OWORD *)(a1 + 16) = 0; /*0x102ce8c0b*/
  v2 = CRYPTO_zalloc(__size: 0x28u, __s: "crypto/packet.c", line: 110); /*0x102ce8c20*/
  *(_QWORD *)(a1 + 40) = v2; /*0x102ce8c25*/
  return v2 != 0; /*0x102ce8c37*/
}

// Address: 0x102ce8c40 | Name: _WPACKET_finish
__int64 __fastcall WPACKET_finish(__int64 a1)
{
  _QWORD *v1; // rsi
  __int64 result; // rax
  int v4; // ecx

  v1 = *(_QWORD **)(a1 + 40); /*0x102ce8c40*/
  result = 0; /*0x102ce8c44*/
  if ( v1 != nullptr && *v1 == 0 ) /*0x102ce8c55*/
  {
    v4 = wpacket_intern_close(a1, a2: v1, a3: 1); /*0x102ce8c6b*/
    result = 0; /*0x102ce8c6d*/
    if ( v4 != 0 ) /*0x102ce8c71*/
    {
      CRYPTO_free(a1: *(void **)(a1 + 40)); /*0x102ce8c83*/
      *(_QWORD *)(a1 + 40) = 0; /*0x102ce8c88*/
      return 1; /*0x102ce8c90*/
    }
  }
  return result; /*0x102ce8c5d*/
}

// Address: 0x102ce8ca0 | Name: _WPACKET_memset
__int64 __fastcall WPACKET_memset(__int64 a1, int a2, size_t a3)
{
  __int64 result; // rax
  void *v6; // [rsp-20h] [rbp-20h] BYREF

  result = 1; /*0x102ce8ca0*/
  if ( a3 != 0 ) /*0x102ce8ca8*/
  {
    if ( (unsigned int)WPACKET_allocate_bytes(a1, a2: a3, a3: &v6) != 0 ) /*0x102ce8ccc*/
    {
      if ( v6 != nullptr ) /*0x102ce8cd5*/
        memset(__b: v6, __c: a2, __len: a3); /*0x102ce8cdc*/
      return 1; /*0x102ce8ce1*/
    }
    else
    {
      return 0; /*0x102ce8ce8*/
    }
  }
  return result; /*0x102ce8caa*/
}

// Address: 0x102ce8d00 | Name: _WPACKET_memcpy
__int64 __fastcall WPACKET_memcpy(__int64 a1, const void *a2, size_t a3)
{
  __int64 result; // rax
  void *v6; // [rsp-20h] [rbp-20h] BYREF

  result = 1; /*0x102ce8d00*/
  if ( a3 != 0 ) /*0x102ce8d08*/
  {
    if ( (unsigned int)WPACKET_allocate_bytes(a1, a2: a3, a3: &v6) != 0 ) /*0x102ce8d2d*/
    {
      if ( v6 != nullptr ) /*0x102ce8d36*/
        memcpy(__dst: v6, __src: a2, __n: a3); /*0x102ce8d3e*/
      return 1; /*0x102ce8d43*/
    }
    else
    {
      return 0; /*0x102ce8d4a*/
    }
  }
  return result; /*0x102ce8d0a*/
}

// Address: 0x102ce8d60 | Name: _WPACKET_sub_memcpy__
__int64 __fastcall WPACKET_sub_memcpy__(__int64 a1, const void *a2, size_t a3, __int64 a4)
{
  _QWORD *v8; // rax
  __int64 v9; // rcx
  _QWORD *v10; // rsi
  __int64 result; // rax
  int v12; // ecx
  void *__dst[5]; // [rsp+8h] [rbp-28h] BYREF

  if ( *(_QWORD *)(a1 + 40) == 0 || a4 != 0 && (*(_BYTE *)(a1 + 48) & 1) != 0 ) /*0x102ce8d8b*/
    return 0; /*0x102ce8d8b*/
  v8 = (_QWORD *)CRYPTO_zalloc(__size: 0x28u, __s: "crypto/packet.c", line: 379); /*0x102ce8d9e*/
  if ( v8 == nullptr ) /*0x102ce8da6*/
    return 0; /*0x102ce8da6*/
  *v8 = *(_QWORD *)(a1 + 40); /*0x102ce8dac*/
  v9 = *(_QWORD *)(a1 + 24); /*0x102ce8daf*/
  *(_QWORD *)(a1 + 40) = v8; /*0x102ce8db7*/
  v8[3] = v9 + a4; /*0x102ce8dbb*/
  v8[2] = a4; /*0x102ce8dbf*/
  if ( a4 != 0 ) /*0x102ce8dc6*/
  {
    v8[1] = v9; /*0x102ce8df3*/
    if ( (unsigned int)WPACKET_allocate_bytes(a1, a2: a4, a3: __dst) == 0 ) /*0x102ce8e08*/
      return 0; /*0x102ce8e08*/
  }
  else
  {
    v8[1] = 0; /*0x102ce8dc8*/
  }
  if ( a3 != 0 ) /*0x102ce8dd3*/
  {
    if ( (unsigned int)WPACKET_allocate_bytes(a1, a2: a3, a3: __dst) == 0 ) /*0x102ce8e1d*/
      return 0; /*0x102ce8de4*/
    if ( __dst[0] != nullptr ) /*0x102ce8e26*/
      memcpy(__dst: __dst[0], __src: a2, __n: a3); /*0x102ce8e2e*/
  }
  v10 = *(_QWORD **)(a1 + 40); /*0x102ce8dd5*/
  if ( v10 == nullptr ) /*0x102ce8ddc*/
    return 0; /*0x102ce8ddc*/
  if ( *v10 == 0 ) /*0x102ce8de2*/
    return 0; /*0x102ce8de2*/
  v12 = wpacket_intern_close(a1, a2: v10, a3: 1); /*0x102ce8e42*/
  result = 1; /*0x102ce8e44*/
  if ( v12 == 0 ) /*0x102ce8e4b*/
    return 0; /*0x102ce8e4b*/
  return result; /*0x102ce8de6*/
}

// Address: 0x102ce8e50 | Name: _WPACKET_is_null_buf
_BOOL8 __fastcall WPACKET_is_null_buf(_QWORD *a1)
{
  _BOOL8 result; // rax

  result = false; /*0x102ce8e54*/
  if ( *a1 == 0 ) /*0x102ce8e5a*/
    return a1[1] == 0; /*0x102ce8e65*/
  return result; /*0x102ce8e5c*/
}

// Address: 0x102ce8e70 | Name: _WPACKET_cleanup
void __fastcall WPACKET_cleanup(__int64 a1)
{
  _QWORD *v2; // rdi
  _QWORD *v3; // r15

  v2 = *(_QWORD **)(a1 + 40); /*0x102ce8e7d*/
  if ( v2 != nullptr ) /*0x102ce8e84*/
  {
    do /*0x102ce8ea6*/
    {
      v3 = (_QWORD *)*v2; /*0x102ce8e90*/
      CRYPTO_free(a1: v2); /*0x102ce8e9b*/
      v2 = v3; /*0x102ce8ea0*/
    }
    while ( v3 != nullptr ); /*0x102ce8ea6*/
  }
  *(_QWORD *)(a1 + 40) = 0; /*0x102ce8ea8*/
}

// Address: 0x102e1bc70 | Name: _write_string
__int64 __fastcall write_string(__int64 a1, UI_STRING *a2)
{
  const char *v3; // rax

  if ( (UI_get_string_type(uis: a2) & 0xFFFFFFFE) == 4 ) /*0x102e1bc87*/
  {
    v3 = UI_get0_output_string(uis: a2); /*0x102e1bc8c*/
    fputs(a1: v3, a2: tty_out); /*0x102e1bc9b*/
    fflush(a1: tty_out); /*0x102e1bca7*/
  }
  return 1; /*0x102e1bcb5*/
}

// Address: 0x102e1c6e0 | Name: _whirlpool_block
__int64 __fastcall whirlpool_block(__int64 *a1, _QWORD *a2, __int64 a3)
{
  __int64 v3; // r8
  __int64 v4; // r9
  __int64 v5; // r10
  __int64 v6; // r11
  __int64 v7; // r12
  __int64 v8; // r13
  __int64 v9; // r14
  __int64 v10; // r15
  __int64 v11; // rsi
  __int64 v12; // r15
  __int64 v13; // r9
  __int64 v14; // r10
  __int64 v15; // r11
  __int64 v16; // r12
  __int64 v17; // r13
  __int64 v18; // r14
  __int64 v19; // r15
  __int64 v20; // r9
  __int64 v21; // r10
  __int64 v22; // r11
  __int64 v23; // r12
  __int64 v24; // r13
  __int64 v25; // r14
  __int64 result; // rax
  __int64 v27; // [rsp+0h] [rbp-D8h]
  __int64 v28; // [rsp+8h] [rbp-D0h]
  __int64 v29; // [rsp+10h] [rbp-C8h]
  __int64 v30; // [rsp+18h] [rbp-C0h]
  __int64 v31; // [rsp+20h] [rbp-B8h]
  __int64 v32; // [rsp+28h] [rbp-B0h]
  __int64 v33; // [rsp+30h] [rbp-A8h]
  __int64 v34; // [rsp+38h] [rbp-A0h]
  __int64 v35; // [rsp+40h] [rbp-98h]
  __int64 v36; // [rsp+48h] [rbp-90h]
  __int64 v37; // [rsp+50h] [rbp-88h]
  __int64 v38; // [rsp+58h] [rbp-80h]
  __int64 v39; // [rsp+60h] [rbp-78h]
  __int64 v40; // [rsp+68h] [rbp-70h]
  __int64 v41; // [rsp+70h] [rbp-68h]
  __int64 v42; // [rsp+78h] [rbp-60h]
  _QWORD *v43; // [rsp+88h] [rbp-50h]
  __int64 v45; // [rsp+98h] [rbp-40h]

  v43 = a2; /*0x102e1c703*/
  v3 = *a1; /*0x102e1c71f*/
  v4 = a1[1]; /*0x102e1c722*/
  v5 = a1[2]; /*0x102e1c726*/
  v6 = a1[3]; /*0x102e1c72a*/
  v7 = a1[4]; /*0x102e1c72e*/
  v8 = a1[5]; /*0x102e1c732*/
  v9 = a1[6]; /*0x102e1c736*/
  v10 = a1[7]; /*0x102e1c73a*/
  while ( 1 ) /*0x102e1c73e*/
  {
    v27 = v3; /*0x102e1c73e*/
    v28 = v4; /*0x102e1c742*/
    v29 = v5; /*0x102e1c747*/
    v30 = v6; /*0x102e1c74c*/
    v31 = v7; /*0x102e1c751*/
    v32 = v8; /*0x102e1c756*/
    v33 = v9; /*0x102e1c75b*/
    v34 = v10; /*0x102e1c760*/
    v35 = *a2 ^ v3; /*0x102e1c784*/
    v36 = a2[1] ^ v4; /*0x102e1c789*/
    v37 = a2[2] ^ v5; /*0x102e1c78e*/
    v38 = a2[3] ^ v6; /*0x102e1c793*/
    v39 = a2[4] ^ v7; /*0x102e1c798*/
    v40 = a2[5] ^ v8; /*0x102e1c79d*/
    v41 = a2[6] ^ v9; /*0x102e1c7a2*/
    v42 = a2[7] ^ v10; /*0x102e1c7a7*/
    v11 = 0; /*0x102e1c7ac*/
    v45 = 0; /*0x102e1c7af*/
    while ( 1 ) /*0x102e1cae8*/
    {
      v12 = qword_10C873F00[2 * (unsigned __int8)v34] /*0x102e1cae8*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v33)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v32)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v31)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v30)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v29)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v28)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v27)] + 1);
      v13 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v34)] + 6) /*0x102e1cb04*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v33)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v32)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v31)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v30)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v29)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v28]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v27)] + 7);
      v14 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v34)] + 5) /*0x102e1cb09*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v33)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v32)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v31)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v30)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v29]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v28)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v27)] + 6);
      v15 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v34)] + 4) /*0x102e1cb1f*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v33)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v32)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v31)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v30]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v29)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v28)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v27)] + 5);
      v16 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v34)] + 3) /*0x102e1cb24*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v33)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v32)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v31]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v30)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v29)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v28)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v27)] + 4);
      v17 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v34)] + 2) /*0x102e1cb3b*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v33)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v32]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v31)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v30)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v29)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v28)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v27)] + 3);
      v18 = *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v34)] + 1) /*0x102e1cb40*/
          ^ qword_10C873F00[2 * (unsigned __int8)v33]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v32)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v31)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v30)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v29)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v28)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v27)] + 2);
      v27 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v34)] + 7) /*0x102e1cb45*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v33)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v32)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v31)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v30)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v29)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v28)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v27]
          ^ qword_10C873F00[v11 + 512];
      v28 = v13; /*0x102e1cb49*/
      v29 = v14; /*0x102e1cb4e*/
      v30 = v15; /*0x102e1cb53*/
      v31 = v16; /*0x102e1cb58*/
      v32 = v17; /*0x102e1cb5d*/
      v33 = v18; /*0x102e1cb62*/
      v34 = v12; /*0x102e1cb67*/
      v19 = qword_10C873F00[2 * (unsigned __int8)v42] /*0x102e1ce7f*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v41)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v40)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v39)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v38)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v37)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v36)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v35)] + 1)
          ^ v12;
      v20 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v42)] + 6) /*0x102e1ce97*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v41)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v40)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v39)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v38)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v37)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v36]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v35)] + 7)
          ^ v13;
      v21 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v42)] + 5) /*0x102e1ce9c*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v41)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v40)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v39)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v38)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v37]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v36)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v35)] + 6)
          ^ v14;
      v22 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v42)] + 4) /*0x102e1ceb2*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v41)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v40)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v39)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v38]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v37)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v36)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v35)] + 5)
          ^ v15;
      v23 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v42)] + 3) /*0x102e1ceb7*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v41)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v40)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v39]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v38)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v37)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v36)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v35)] + 4)
          ^ v16;
      v24 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v42)] + 2) /*0x102e1ceca*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v41)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v40]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v39)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v38)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v37)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v36)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v35)] + 3)
          ^ v17;
      v25 = *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v42)] + 1) /*0x102e1cecf*/
          ^ qword_10C873F00[2 * (unsigned __int8)v41]
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v40)] + 7)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v39)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v38)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v37)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v36)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v35)] + 2)
          ^ v18;
      v11 = v45 + 1; /*0x102e1cee0*/
      if ( v45 == 9 ) /*0x102e1cee8*/
        break; /*0x102e1cee8*/
      ++v45; /*0x102e1ceea*/
      v35 = *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v42)] + 7) /*0x102e1ceee*/
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v41)] + 6)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v40)] + 5)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v39)] + 4)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v38)] + 3)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v37)] + 2)
          ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v36)] + 1)
          ^ qword_10C873F00[2 * (unsigned __int8)v35]
          ^ v27;
      v36 = v20; /*0x102e1cef3*/
      v37 = v21; /*0x102e1cef8*/
      v38 = v22; /*0x102e1cefd*/
      v39 = v23; /*0x102e1cf02*/
      v40 = v24; /*0x102e1cf07*/
      v41 = v25; /*0x102e1cf0c*/
      v42 = v19; /*0x102e1cf11*/
    }
    v3 = *a1 /*0x102e1cf4a*/
       ^ *v43
       ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE1(v42)] + 7)
       ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE2(v41)] + 6)
       ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE3(v40)] + 5)
       ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE4(v39)] + 4)
       ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE5(v38)] + 3)
       ^ *(_QWORD *)((char *)&qword_10C873F00[2 * BYTE6(v37)] + 2)
       ^ *(_QWORD *)((char *)&qword_10C873F00[2 * HIBYTE(v36)] + 1)
       ^ qword_10C873F00[2 * (unsigned __int8)v35]
       ^ v27;
    v4 = a1[1] ^ v43[1] ^ v20; /*0x102e1cf4d*/
    v5 = a1[2] ^ v43[2] ^ v21; /*0x102e1cf51*/
    v6 = a1[3] ^ v43[3] ^ v22; /*0x102e1cf55*/
    v7 = a1[4] ^ v43[4] ^ v23; /*0x102e1cf59*/
    v8 = a1[5] ^ v43[5] ^ v24; /*0x102e1cf5d*/
    v9 = a1[6] ^ v43[6] ^ v25; /*0x102e1cf61*/
    v10 = a1[7] ^ v43[7] ^ v19; /*0x102e1cf65*/
    *a1 = v3; /*0x102e1cf69*/
    a1[1] = v4; /*0x102e1cf6c*/
    a1[2] = v5; /*0x102e1cf70*/
    a1[3] = v6; /*0x102e1cf74*/
    a1[4] = v7; /*0x102e1cf78*/
    a1[5] = v8; /*0x102e1cf7c*/
    a1[6] = v9; /*0x102e1cf80*/
    a1[7] = v10; /*0x102e1cf84*/
    a2 = v43 + 8; /*0x102e1cf88*/
    result = a3 - 1; /*0x102e1cf8c*/
    if ( a3 == 1 ) /*0x102e1cf90*/
      break; /*0x102e1cf90*/
    v43 += 8; /*0x102e1cf92*/
    --a3; /*0x102e1cf96*/
  }
  return result; /*0x102e1cfbe*/
}

// Address: 0x102e1cfc0 | Name: _WHIRLPOOL_Init
__int64 __fastcall WHIRLPOOL_Init(__int64 a1)
{
  *(_OWORD *)(a1 + 144) = 0; /*0x102e1cfc7*/
  *(_OWORD *)(a1 + 128) = 0; /*0x102e1cfce*/
  *(_OWORD *)(a1 + 112) = 0; /*0x102e1cfd5*/
  *(_OWORD *)(a1 + 96) = 0; /*0x102e1cfd9*/
  *(_OWORD *)(a1 + 80) = 0; /*0x102e1cfdd*/
  *(_OWORD *)(a1 + 64) = 0; /*0x102e1cfe1*/
  *(_OWORD *)(a1 + 48) = 0; /*0x102e1cfe5*/
  *(_OWORD *)(a1 + 32) = 0; /*0x102e1cfe9*/
  *(_OWORD *)(a1 + 16) = 0; /*0x102e1cfed*/
  *(_OWORD *)a1 = 0; /*0x102e1cff1*/
  *(_QWORD *)(a1 + 160) = 0; /*0x102e1cff4*/
  return 1; /*0x102e1d004*/
}

// Address: 0x102e1d010 | Name: _WHIRLPOOL_Update
__int64 __fastcall WHIRLPOOL_Update(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // rbx

  v3 = a3; /*0x102e1d01e*/
  if ( a3 >> 60 != 0 ) /*0x102e1d02e*/
  {
    do /*0x102e1d078*/
    {
      v3 -= 0x1000000000000000LL; /*0x102e1d050*/
      WHIRLPOOL_BitUpdate(a1, a2, a3: 0x8000000000000000LL); /*0x102e1d063*/
      a2 += 0x1000000000000000LL; /*0x102e1d068*/
    }
    while ( v3 > 0xFFFFFFFFFFFFFFFLL ); /*0x102e1d078*/
  }
  if ( v3 != 0 ) /*0x102e1d07d*/
    WHIRLPOOL_BitUpdate(a1, a2, a3: 8 * v3); /*0x102e1d08c*/
  return 1; /*0x102e1d09a*/
}

// Address: 0x102e1d0b0 | Name: _WHIRLPOOL_BitUpdate
__int64 __fastcall WHIRLPOOL_BitUpdate(__int64 a1, char *a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // rbx
  __int64 *v5; // r13
  unsigned int v6; // r12d
  __int64 v7; // r8
  int v8; // edi
  bool v9; // cf
  bool v10; // zf
  __int64 result; // rax
  _QWORD *v12; // rsi
  int v13; // r13d
  int v14; // r14d
  char *v15; // r14
  unsigned __int64 v16; // r13
  __int64 v17; // rdi
  unsigned __int64 v18; // r15
  size_t v19; // r13
  int v20; // [rsp+0h] [rbp-50h]
  _QWORD *v21; // [rsp+8h] [rbp-48h]
  char v22; // [rsp+10h] [rbp-40h]
  int v23; // [rsp+14h] [rbp-3Ch]
  __int64 *v24; // [rsp+18h] [rbp-38h]
  __int64 v25; // [rsp+20h] [rbp-30h]
  _QWORD *v26; // [rsp+20h] [rbp-30h]

  v3 = a3; /*0x102e1d0c1*/
  v5 = (__int64 *)a1; /*0x102e1d0c7*/
  v6 = *(_DWORD *)(a1 + 128); /*0x102e1d0ca*/
  v7 = v6 & 7; /*0x102e1d0d4*/
  v8 = -(int)a3 & 7; /*0x102e1d0dc*/
  v9 = __CFADD__(a3, v5[17]); /*0x102e1d0df*/
  v5[17] += a3; /*0x102e1d0df*/
  if ( v9 ) /*0x102e1d0e6*/
  {
    v10 = v5[18]++ == -1; /*0x102e1d0e8*/
    if ( v10 ) /*0x102e1d0ef*/
    {
      v10 = v5[19]++ == -1; /*0x102e1d0f1*/
      if ( v10 ) /*0x102e1d0f8*/
        ++v5[20]; /*0x102e1d0fa*/
    }
  }
  result = (unsigned int)v7 | v8; /*0x102e1d103*/
  v24 = v5; /*0x102e1d106*/
  if ( ((unsigned int)v7 | v8) == 0 ) /*0x102e1d10a*/
    goto LABEL_29; /*0x102e1d10a*/
  if ( a3 != 0 ) /*0x102e1d113*/
  {
    v12 = v5 + 8; /*0x102e1d119*/
    v25 = 8 - v7; /*0x102e1d125*/
    v22 = 8 - v8; /*0x102e1d130*/
    v20 = v6 & 7; /*0x102e1d133*/
    v23 = -(int)a3 & 7; /*0x102e1d137*/
    v21 = v5 + 8; /*0x102e1d13a*/
    do /*0x102e1d160*/
    {
      result = v6 >> 3; /*0x102e1d160*/
      if ( (_DWORD)v7 == v8 ) /*0x102e1d166*/
      {
        *((_BYTE *)v12 + result) |= *a2 & (0xFFu >> v7); /*0x102e1d286*/
        v6 += v25; /*0x102e1d289*/
        if ( v6 == 512 ) /*0x102e1d294*/
        {
          result = whirlpool_block(a1: v5, a2: v12, a3: 1); /*0x102e1d29e*/
          v6 = 0; /*0x102e1d2a3*/
        }
        v3 -= v25; /*0x102e1d2a6*/
        ++a2; /*0x102e1d2aa*/
        *((_DWORD *)v5 + 32) = v6; /*0x102e1d2ad*/
LABEL_29:
        if ( v3 != 0 ) /*0x102e1d2b7*/
        {
          v26 = v5 + 8; /*0x102e1d2c1*/
          do /*0x102e1d390*/
          {
            while ( v6 == 0 && v3 >= 0x200 ) /*0x102e1d30e*/
            {
              whirlpool_block(a1: v5, a2, a3: v3 >> 9); /*0x102e1d2dd*/
              result = (v3 >> 3) & 0x1FFFFFFFFFFFFFC0LL; /*0x102e1d2e9*/
              a2 += result; /*0x102e1d2ed*/
              v3 &= 0x1FFu; /*0x102e1d2f0*/
              v6 = 0; /*0x102e1d2f6*/
              if ( v3 == 0 ) /*0x102e1d2fc*/
                return result; /*0x102e1d2fc*/
            }
            v15 = a2; /*0x102e1d310*/
            v16 = 512 - v6; /*0x102e1d31f*/
            v17 = v6 >> 3; /*0x102e1d325*/
            v18 = v3 - v16; /*0x102e1d327*/
            if ( v3 >= v16 ) /*0x102e1d32a*/
            {
              v19 = (unsigned int)v16 >> 3; /*0x102e1d350*/
              memcpy(__dst: (char *)v26 + v17, __src: v15, __n: v19); /*0x102e1d361*/
              v15 += v19; /*0x102e1d366*/
              v5 = v24; /*0x102e1d36e*/
              result = whirlpool_block(a1: v24, a2: v26, a3: 1); /*0x102e1d378*/
              v6 = 0; /*0x102e1d37d*/
            }
            else
            {
              result = (__int64)memcpy(__dst: (char *)v26 + v17, __src: v15, __n: v3 >> 3); /*0x102e1d33a*/
              v6 += v3; /*0x102e1d33f*/
              v18 = 0; /*0x102e1d342*/
              v5 = v24; /*0x102e1d345*/
            }
            *((_DWORD *)v5 + 32) = v6; /*0x102e1d380*/
            v3 = v18; /*0x102e1d387*/
            a2 = v15; /*0x102e1d38a*/
          }
          while ( v3 != 0 ); /*0x102e1d390*/
        }
        return result; /*0x102e1d390*/
      }
      v13 = (unsigned __int8)*a2 << v8; /*0x102e1d172*/
      if ( v3 >= 9 ) /*0x102e1d179*/
      {
        v14 = v13 | ((unsigned __int8)a2[1] >> v22); /*0x102e1d186*/
        if ( (_DWORD)v7 != 0 ) /*0x102e1d18c*/
        {
          *((_BYTE *)v12 + result) |= (unsigned __int8)v14 >> v7; /*0x102e1d19b*/
          v5 = v24; /*0x102e1d19e*/
          v6 += 8; /*0x102e1d1a2*/
          if ( v6 >= 0x200 ) /*0x102e1d1ad*/
            goto LABEL_14; /*0x102e1d1ad*/
LABEL_19:
          result = (unsigned int)(result + 1); /*0x102e1d236*/
        }
        else
        {
          *((_BYTE *)v12 + result) = v14; /*0x102e1d21d*/
          v5 = v24; /*0x102e1d221*/
          v6 += 8; /*0x102e1d225*/
          if ( v6 < 0x200 ) /*0x102e1d230*/
            goto LABEL_19; /*0x102e1d230*/
LABEL_14:
          whirlpool_block(a1: v5, a2: v12, a3: 1); /*0x102e1d1b3*/
          v12 = v21; /*0x102e1d1c0*/
          v8 = v23; /*0x102e1d1c4*/
          LODWORD(v7) = v20; /*0x102e1d1c7*/
          v6 &= 0x1FFu; /*0x102e1d1cb*/
          result = 0; /*0x102e1d1d2*/
        }
        ++a2; /*0x102e1d238*/
        v3 -= 8LL; /*0x102e1d23b*/
        if ( (_DWORD)v7 == 0 ) /*0x102e1d242*/
          goto LABEL_9; /*0x102e1d242*/
        goto LABEL_8; /*0x102e1d242*/
      }
      if ( (_DWORD)v7 != 0 ) /*0x102e1d1e3*/
      {
        *((_BYTE *)v12 + result) |= (unsigned __int8)v13 >> v7; /*0x102e1d1ee*/
        v6 += v3; /*0x102e1d1f1*/
        if ( v6 == 512 ) /*0x102e1d1fb*/
          goto LABEL_17; /*0x102e1d1fb*/
      }
      else
      {
        *((_BYTE *)v12 + result) = v13; /*0x102e1d24d*/
        v6 += v3; /*0x102e1d251*/
        if ( v6 == 512 ) /*0x102e1d25b*/
        {
LABEL_17:
          whirlpool_block(a1: v24, a2: v12, a3: 1); /*0x102e1d1fd*/
          v12 = v21; /*0x102e1d20b*/
          v8 = v23; /*0x102e1d20f*/
          LODWORD(v7) = v20; /*0x102e1d212*/
          v6 = 0; /*0x102e1d216*/
          result = 0; /*0x102e1d219*/
          goto LABEL_24; /*0x102e1d21b*/
        }
      }
      result = (unsigned int)(result + 1); /*0x102e1d25d*/
LABEL_24:
      v14 = v13; /*0x102e1d25f*/
      v3 = 0; /*0x102e1d262*/
      v5 = v24; /*0x102e1d26a*/
      if ( (_DWORD)v7 != 0 ) /*0x102e1d26e*/
      {
LABEL_8:
        result = (unsigned int)result; /*0x102e1d140*/
        *((_BYTE *)v12 + (unsigned int)result) = v14 << v25; /*0x102e1d149*/
      }
LABEL_9:
      *((_DWORD *)v5 + 32) = v6; /*0x102e1d14d*/
    }
    while ( v3 != 0 ); /*0x102e1d160*/
  }
  return result; /*0x102e1d396*/
}

// Address: 0x102e1d3b0 | Name: _WHIRLPOOL_Final
__int64 __fastcall WHIRLPOOL_Final(_OWORD *a1, __int128 *a2)
{
  unsigned int v4; // edx
  __int64 v5; // rax
  unsigned int v6; // ecx
  unsigned __int64 v7; // rcx
  __int128 v8; // xmm0
  __int128 v9; // xmm1
  __int128 v10; // xmm2

  v4 = *((_DWORD *)a2 + 32); /*0x102e1d3bd*/
  v5 = v4 >> 3; /*0x102e1d3c5*/
  if ( (v4 & 7) == 0 ) /*0x102e1d3cd*/
  {
    *((_BYTE *)a2 + v5 + 64) = 0x80; /*0x102e1d419*/
    v6 = v5 + 1; /*0x102e1d41e*/
    if ( v4 >= 0x100 ) /*0x102e1d427*/
      goto LABEL_3; /*0x102e1d427*/
LABEL_7:
    if ( v4 > 0xF7 ) /*0x102e1d42f*/
      goto LABEL_9; /*0x102e1d42f*/
    goto LABEL_8; /*0x102e1d42f*/
  }
  *((_BYTE *)a2 + v5 + 64) |= 0x80u >> (v4 & 7); /*0x102e1d3d6*/
  v6 = v5 + 1; /*0x102e1d3db*/
  if ( v4 < 0x100 ) /*0x102e1d3e4*/
    goto LABEL_7; /*0x102e1d3e4*/
LABEL_3:
  if ( v4 <= 0x1F7 ) /*0x102e1d3ec*/
    __bzero(a1: (char *)a2 + v6 + 64, a2: (unsigned int)(63 - v5)); /*0x102e1d3ff*/
  whirlpool_block(a1: (__int64 *)a2, a2: (_QWORD *)a2 + 8, a3: 1); /*0x102e1d410*/
  v6 = 0; /*0x102e1d415*/
LABEL_8:
  __bzero(a1: (char *)a2 + v6 + 64, a2: 32 - v6); /*0x102e1d431*/
LABEL_9:
  v7 = *((_QWORD *)a2 + 18); /*0x102e1d447*/
  *((_QWORD *)a2 + 15) = _byteswap_uint64(*((_QWORD *)a2 + 17)); /*0x102e1d458*/
  *((_QWORD *)a2 + 14) = _byteswap_uint64(v7); /*0x102e1d45f*/
  *((_QWORD *)a2 + 13) = _byteswap_uint64(*((_QWORD *)a2 + 19)); /*0x102e1d46d*/
  *((_QWORD *)a2 + 12) = _byteswap_uint64(*((_QWORD *)a2 + 20)); /*0x102e1d47b*/
  whirlpool_block(a1: (__int64 *)a2, a2: (_QWORD *)a2 + 8, a3: 1); /*0x102e1d48b*/
  if ( a1 == nullptr ) /*0x102e1d493*/
    return 0; /*0x102e1d4ce*/
  v8 = *a2; /*0x102e1d495*/
  v9 = a2[1]; /*0x102e1d498*/
  v10 = a2[2]; /*0x102e1d49c*/
  a1[3] = a2[3]; /*0x102e1d4a4*/
  a1[2] = v10; /*0x102e1d4a9*/
  a1[1] = v9; /*0x102e1d4ae*/
  *a1 = v8; /*0x102e1d4b3*/
  OPENSSL_cleanse(ptr: a2, len: 0xA8u); /*0x102e1d4bf*/
  return 1; /*0x102e1d4c9*/
}

// Address: 0x102e1d4e0 | Name: _WHIRLPOOL
_OWORD *__fastcall WHIRLPOOL(char *a1, unsigned __int64 a2, _OWORD *a3)
{
  unsigned __int64 v3; // r14
  _OWORD *v5; // r14
  __int128 v8[10]; // [rsp+10h] [rbp-E0h] BYREF
  __int64 v9; // [rsp+B0h] [rbp-40h]

  v3 = a2; /*0x102e1d4fb*/
  memset(v8, 0, sizeof(v8)); /*0x102e1d545*/
  v9 = 0; /*0x102e1d54c*/
  if ( a2 >> 60 != 0 ) /*0x102e1d55b*/
  {
    do /*0x102e1d5a5*/
    {
      v3 -= 0x1000000000000000LL; /*0x102e1d580*/
      WHIRLPOOL_BitUpdate(a1: (__int64)v8, a2: a1, a3: 0x8000000000000000LL); /*0x102e1d590*/
      a1 += 0x1000000000000000LL; /*0x102e1d595*/
    }
    while ( v3 > 0xFFFFFFFFFFFFFFFLL ); /*0x102e1d5a5*/
  }
  if ( v3 != 0 ) /*0x102e1d5aa*/
    WHIRLPOOL_BitUpdate(a1: (__int64)v8, a2: a1, a3: 8 * v3); /*0x102e1d5bd*/
  v5 = &WHIRLPOOL_m; /*0x102e1d5cc*/
  if ( a3 != nullptr ) /*0x102e1d5d3*/
    v5 = a3; /*0x102e1d5d3*/
  WHIRLPOOL_Final(a1: v5, a2: v8); /*0x102e1d5e1*/
  return v5; /*0x102e1d5f9*/
}

// Address: 0x102fc0769 | Name: __ZL15wslayBufferPoolv
__int64 __fastcall wslayBufferPool()
{
  __int64 v1; // rbx
  __int64 v2; // r14
  unsigned __int64 v3; // rdx

  if ( (_BYTE)`guard variable for'wslayBufferPool(void)::pool == 0 /*0x102fc0794*/
    && __cxa_guard_acquire(a1: &`guard variable for'wslayBufferPool(void)::pool) != 0 )
  {
    v1 = operator new(a1: 0x20u); /*0x102fc07a0*/
    v2 = (unsigned int)FInt::HttpWslayPoolSize; /*0x102fc07a3*/
    *(_DWORD *)v1 = 0; /*0x102fc07aa*/
    *(_QWORD *)(v1 + 8) = 0xFFFFFFFFLL; /*0x102fc07b5*/
    *(_QWORD *)(v1 + 16) = RBX::Memory::allocateAligned(this: (RBX::Memory *)(40 * v2), a2: 8u, a3: v3); /*0x102fc07cf*/
    *(_DWORD *)(v1 + 24) = v2; /*0x102fc07d3*/
    wslayBufferPool(void)::pool = v1; /*0x102fc07d7*/
    __cxa_guard_release(a1: &`guard variable for'wslayBufferPool(void)::pool); /*0x102fc07e5*/
  }
  return wslayBufferPool(void)::pool; /*0x102fc0781*/
}

// Address: 0x10304d78f | Name: _walFindFrame
__int64 __fastcall walFindFrame(__int64 a1, int a2, unsigned int *a3)
{
  unsigned int v3; // ebx
  unsigned __int64 v5; // r12
  unsigned __int64 v6; // r13
  __int64 result; // rax
  unsigned int v8; // r11d
  _QWORD *v9; // rdx
  _QWORD *v10; // r14
  unsigned __int16 v11; // r9
  int v12; // esi
  __int64 v13; // r8
  __int64 v14; // r10
  unsigned int v15; // r9d
  bool v16; // cc
  _QWORD v17[2]; // [rsp+8h] [rbp-58h] BYREF
  int v18; // [rsp+18h] [rbp-48h]
  __int64 v19; // [rsp+20h] [rbp-40h]
  unsigned int *v20; // [rsp+28h] [rbp-38h]
  int v21; // [rsp+34h] [rbp-2Ch]

  v3 = *(_DWORD *)(a1 + 88); /*0x10304d7a0*/
  if ( v3 != 0 && (*(_WORD *)(a1 + 60) != 0 || *(_BYTE *)(a1 + 70) != 0) ) /*0x10304d7b6*/
  {
    v21 = a2; /*0x10304d7b8*/
    v5 = ((unsigned __int64)(unsigned int)(*(_DWORD *)(a1 + 120) + 4096) + 0xFFFFFFFF021LL) >> 12; /*0x10304d7d6*/
    v6 = ((unsigned __int64)(v3 + 4096) + 0xFFFFFFFF021LL) >> 12; /*0x10304d7dd*/
    result = 0; /*0x10304d7e1*/
    v8 = 0; /*0x10304d7e3*/
    if ( (int)v6 >= (int)v5 ) /*0x10304d7ec*/
    {
      v20 = a3; /*0x10304d803*/
      v19 = (383 * (_WORD)v21) & 0x1FFF; /*0x10304d813*/
      v9 = v17; /*0x10304d817*/
      while ( 1 ) /*0x10304d821*/
      {
        v10 = v9; /*0x10304d821*/
        result = walHashGet(a1, a2: (unsigned int)v6); /*0x10304d824*/
        if ( (_DWORD)result != 0 ) /*0x10304d82b*/
          break; /*0x10304d82b*/
        v11 = *(_WORD *)(v17[0] + 2 * v19); /*0x10304d839*/
        if ( v11 != 0 ) /*0x10304d842*/
        {
          v8 = 0; /*0x10304d847*/
          v12 = -8193; /*0x10304d84a*/
          LOWORD(v13) = v19; /*0x10304d853*/
          do /*0x10304d890*/
          {
            v14 = v11; /*0x10304d85a*/
            v15 = v18 + v11; /*0x10304d85e*/
            if ( v15 <= v3 && v15 >= *(_DWORD *)(a1 + 120) && *(_DWORD *)(v17[1] + 4 * v14 - 4) == v21 ) /*0x10304d875*/
              v8 = v15; /*0x10304d875*/
            if ( ++v12 == 0 ) /*0x10304d87b*/
            {
              *v20 = 0; /*0x10304d8bc*/
              sqlite3_log( /*0x10304d8e3*/
                iErrCode: 11,
                zFormat: "%s at line %d of [%.10s]",
                "database corruption",
                70333,
                "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
              return 11; /*0x10304d8e8*/
            }
            v13 = ((_WORD)v13 + 1) & 0x1FFF; /*0x10304d880*/
            v11 = *(_WORD *)(v17[0] + 2 * v13); /*0x10304d887*/
          }
          while ( v11 != 0 ); /*0x10304d890*/
          if ( v8 != 0 ) /*0x10304d895*/
            goto LABEL_20; /*0x10304d895*/
        }
        v16 = (int)v6 <= (int)v5; /*0x10304d89b*/
        LODWORD(v6) = v6 - 1; /*0x10304d89e*/
        v9 = v10; /*0x10304d8a1*/
        if ( v16 ) /*0x10304d8a4*/
        {
          v8 = 0; /*0x10304d8aa*/
LABEL_20:
          a3 = v20; /*0x10304d8ad*/
          result = 0; /*0x10304d8b1*/
          goto LABEL_5; /*0x10304d8b3*/
        }
      }
    }
    else
    {
LABEL_5:
      *a3 = v8; /*0x10304d7ee*/
    }
  }
  else
  {
    *a3 = 0; /*0x10304d7f6*/
    return 0; /*0x10304d7fc*/
  }
  return result; /*0x10304d8ed*/
}

// Address: 0x10304d8fc | Name: _walHashGet
__int64 __fastcall walHashGet(__int64 a1, unsigned int a2, __int64 a3)
{
  __int64 *v5; // r15
  __int64 v6; // rcx
  __int64 result; // rax

  v5 = (__int64 *)(a3 + 8); /*0x10304d90c*/
  if ( *(_DWORD *)(a1 + 40) <= (signed int)a2 /*0x10304d928*/
    || (v6 = *(_QWORD *)(*(_QWORD *)(a1 + 48) + 8LL * (int)a2), *v5 = v6, result = 0, v6 == 0) )
  {
    result = walIndexPageRealloc(a1, a2, a3: a3 + 8); /*0x10304d930*/
    v6 = *v5; /*0x10304d935*/
    if ( *v5 == 0 ) /*0x10304d93b*/
      return ((_DWORD)result == 0) + (unsigned int)result; /*0x10304d971*/
  }
  *(_QWORD *)a3 = v6 + 0x4000; /*0x10304d944*/
  if ( a2 != 0 ) /*0x10304d94a*/
  {
    *(_DWORD *)(a3 + 16) = (a2 << 12) - 34; /*0x10304d954*/
  }
  else
  {
    *(_QWORD *)(a3 + 8) = v6 + 136; /*0x10304d961*/
    *(_DWORD *)(a3 + 16) = 0; /*0x10304d965*/
  }
  return result; /*0x10304d978*/
}

// Address: 0x10304d97f | Name: _walIndexPage
__int64 __fastcall walIndexPage(__int64 a1, __int64 a2, _QWORD *a3)
{
  __int64 v3; // rax

  if ( *(_DWORD *)(a1 + 40) > (int)a2 && (v3 = *(_QWORD *)(*(_QWORD *)(a1 + 48) + 8LL * (int)a2), *a3 = v3, v3 != 0) ) /*0x10304d999*/
    return 0; /*0x10304d99b*/
  else
    return walIndexPageRealloc(a1, a2, a3); /*0x10304d9a0*/
}

// Address: 0x10304d9a5 | Name: _walIndexPageRealloc
__int64 __fastcall walIndexPageRealloc(__int64 a1, __int64 a2, _QWORD *a3, __int64 a4, __int64 a5, __int64 a6)
{
  int v7; // r15d
  __int64 v9; // rax
  __int64 v10; // r12
  __int64 v11; // r13
  __int64 v12; // rax
  __int64 v13; // r12
  __int64 v14; // r13
  unsigned int v15; // r12d
  unsigned int v16; // eax
  __int64 v17; // rax

  v7 = a2; /*0x10304d9b6*/
  if ( *(_DWORD *)(a1 + 40) <= (int)a2 ) /*0x10304d9bf*/
  {
    v9 = sqlite3Realloc(a1: *(void **)(a1 + 48)); /*0x10304d9d0*/
    if ( v9 == 0 ) /*0x10304d9d8*/
    {
      v15 = 7; /*0x10304da8f*/
      v17 = 0; /*0x10304da95*/
      goto LABEL_21; /*0x10304da97*/
    }
    v10 = v9; /*0x10304d9de*/
    v11 = v7 + 1LL; /*0x10304d9e9*/
    __bzero(a1: v9 + 8LL * *(int *)(a1 + 40), a2: 8 * (v11 - *(int *)(a1 + 40))); /*0x10304d9f6*/
    *(_QWORD *)(a1 + 48) = v10; /*0x10304d9fb*/
    *(_DWORD *)(a1 + 40) = v11; /*0x10304d9ff*/
  }
  if ( *(_BYTE *)(a1 + 63) == 2 ) /*0x10304da08*/
  {
    v12 = sqlite3Malloc(a1: 0x8000, a2, a3, a4, a5, a6); /*0x10304da0f*/
    v13 = v12; /*0x10304da14*/
    if ( v12 != 0 ) /*0x10304da1a*/
      __bzero(a1: v12, a2: 0x8000); /*0x10304da24*/
    v14 = v7; /*0x10304da2d*/
    *(_QWORD *)(*(_QWORD *)(a1 + 48) + 8LL * v7) = v13; /*0x10304da30*/
    v15 = 7; /*0x10304da3f*/
    if ( *(_QWORD *)(*(_QWORD *)(a1 + 48) + 8LL * v7) != 0 ) /*0x10304da45*/
      v15 = 0; /*0x10304da45*/
  }
  else
  {
    v14 = v7; /*0x10304da54*/
    v16 = (*(__int64 (__fastcall **)(_QWORD, _QWORD, __int64, _QWORD, __int64))(**(_QWORD **)(a1 + 8) + 104LL))( /*0x10304da6e*/
            a1: *(_QWORD *)(a1 + 8),
            a2: (unsigned int)v7,
            a3: 0x8000,
            a4: *(unsigned __int8 *)(a1 + 64),
            a5: *(_QWORD *)(a1 + 48) + 8LL * v7);
    if ( v16 != 0 ) /*0x10304da73*/
    {
      v15 = v16; /*0x10304da75*/
      if ( (_BYTE)v16 == 8 ) /*0x10304da7c*/
      {
        *(_BYTE *)(a1 + 66) |= 2u; /*0x10304da7e*/
        if ( v16 == 8 ) /*0x10304da89*/
          v15 = 0; /*0x10304da89*/
      }
    }
    else
    {
      v15 = 0; /*0x10304da99*/
      if ( v7 > 0 && qword_10CD98350 != nullptr && (unsigned int)qword_10CD98350(a1: 600) != 0 ) /*0x10304dab6*/
        v15 = 7; /*0x10304dab8*/
    }
  }
  v17 = *(_QWORD *)(*(_QWORD *)(a1 + 48) + 8 * v14); /*0x10304dac2*/
LABEL_21:
  *a3 = v17; /*0x10304dac6*/
  return v15; /*0x10304dad0*/
}

// Address: 0x10304e62a | Name: _walCleanupHash
__int64 __fastcall walCleanupHash(__int64 a1)
{
  __int64 result; // rax
  int v3; // ecx
  __int64 v4; // rax
  __int64 i; // rdx
  __int64 v6; // [rsp+0h] [rbp-20h] BYREF
  __int64 v7; // [rsp+8h] [rbp-18h]
  int v8; // [rsp+10h] [rbp-10h]

  result = *(unsigned int *)(a1 + 88); /*0x10304e633*/
  if ( (_DWORD)result != 0 ) /*0x10304e638*/
  {
    result = walHashGet( /*0x10304e657*/
               a1,
               a2: ((unsigned __int64)(unsigned int)(result + 4096) + 0xFFFFFFFF021LL) >> 12,
               a3: (__int64)&v6);
    if ( (_DWORD)result == 0 ) /*0x10304e65e*/
    {
      v3 = *(_DWORD *)(a1 + 88) - v8; /*0x10304e66a*/
      v4 = v6; /*0x10304e66d*/
      for ( i = 0; i != 0x2000; ++i ) /*0x10304e671*/
      {
        if ( v3 < *(unsigned __int16 *)(v4 + 2 * i) ) /*0x10304e679*/
          *(_WORD *)(v4 + 2 * i) = 0; /*0x10304e67b*/
      }
      return __bzero(a1: v7 + 4LL * v3, a2: (int)v4 - ((int)v7 + 4 * v3)); /*0x10304e6a3*/
    }
  }
  return result; /*0x10304e660*/
}

// Address: 0x10304e6eb | Name: _walTryBeginRead
__int64 __fastcall walTryBeginRead(__int64 a1, _DWORD *a2, int a3, _DWORD *a4)
{
  int v6; // eax
  unsigned int v7; // edi
  __int64 v8; // rsi
  __int64 v9; // r12
  const void ***v10; // r13
  __int64 v11; // r15
  unsigned int v12; // ebx
  unsigned int v13; // r14d
  __int64 v14; // rax
  __int64 v15; // r8
  __int64 v16; // r13
  unsigned int v17; // r15d
  unsigned int v18; // eax
  __int64 v19; // rdi
  void *v20; // r12
  unsigned int v21; // eax
  unsigned int v22; // r14d
  __int64 v23; // rdi
  _OWORD *v24; // rax
  __int128 v25; // xmm1
  __int128 v26; // xmm2
  unsigned int v27; // eax
  unsigned int Hdr; // eax
  unsigned int v29; // eax
  bool v30; // zf
  unsigned int v31; // eax
  int v32; // r13d
  unsigned int v33; // r15d
  int v34; // eax
  int v35; // ebx
  __int16 v36; // bx
  __int64 *v37; // rdi
  __int64 v38; // rax
  __int64 v39; // rsi
  int v40; // ebx
  __int64 v41; // rbx
  __int64 v43; // r15
  int v44; // eax
  char v45; // al
  unsigned int v46; // ebx
  __int64 v47; // rax
  __int64 v48; // rdx
  __int64 v49; // rcx
  __int64 v50; // rsi
  __int64 v51; // r8
  __int64 v52; // r9
  int v53; // r14d
  __int64 v54; // rax
  __int64 v55; // rcx
  unsigned __int64 v56; // r13
  unsigned __int64 v57; // r13
  __int64 v58; // rbx
  int v59; // eax
  _BYTE v60[12]; // [rsp+0h] [rbp-A0h] BYREF
  _BYTE v61[4]; // [rsp+Ch] [rbp-94h] BYREF
  __m128 v62; // [rsp+10h] [rbp-90h]
  int v63; // [rsp+2Ch] [rbp-74h] BYREF
  __int64 v64; // [rsp+30h] [rbp-70h] BYREF
  __int64 v65; // [rsp+38h] [rbp-68h]
  _DWORD *v66; // [rsp+40h] [rbp-60h]
  __int64 v67; // [rsp+48h] [rbp-58h]
  _BYTE v68[16]; // [rsp+50h] [rbp-50h] BYREF
  __int64 v69; // [rsp+60h] [rbp-40h]

  v67 = a1; /*0x10304e702*/
  v6 = (*a4)++; /*0x10304e714*/
  if ( v6 >= 5 ) /*0x10304e71e*/
  {
    v7 = 15; /*0x10304e720*/
    if ( (unsigned int)v6 > 0x63 ) /*0x10304e728*/
      return v7; /*0x10304e728*/
    v8 = 1; /*0x10304e73a*/
    if ( (unsigned int)v6 >= 9 ) /*0x10304e73f*/
      v8 = (unsigned int)(39 * (v6 - 8) * (v6 - 8)); /*0x10304e73f*/
    (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)v67 + 112LL))(a1: *(_QWORD *)v67, a2: v8); /*0x10304e749*/
  }
  if ( a3 != 0 ) /*0x10304e74f*/
  {
    v9 = v67; /*0x10304e755*/
    v10 = (const void ***)(v67 + 48); /*0x10304e759*/
    v11 = **(_QWORD **)(v67 + 48) + 96LL; /*0x10304e766*/
    v7 = 0; /*0x10304e76a*/
    goto LABEL_8; /*0x10304e76a*/
  }
  v9 = v67; /*0x10304e83a*/
  if ( *(_BYTE *)(v67 + 70) == 0 )
  {
    Hdr = walIndexReadHdr(a1: v67, a2); /*0x10304e8e4*/
    if ( Hdr != 0 ) /*0x10304e8eb*/
    {
      v7 = Hdr; /*0x10304e8f1*/
      if ( Hdr != 5 ) /*0x10304e8f6*/
        return v7; /*0x10304e8f6*/
      v7 = -1; /*0x10304e904*/
      if ( **(_QWORD **)(v67 + 48) == 0 || *(_BYTE *)(v67 + 63) != 0 ) /*0x10304e917*/
        return v7; /*0x10304e917*/
      v29 = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, __int64))(**(_QWORD **)(v67 + 8) + 112LL))( /*0x10304e933*/
              a1: *(_QWORD *)(v67 + 8),
              a2: 2,
              a3: 1,
              a4: 6);
      if ( v29 == 0 ) /*0x10304e938*/
      {
        v7 = -1; /*0x10304ec95*/
        if ( *(_BYTE *)(v67 + 63) != 0 ) /*0x10304ec9a*/
          return v7; /*0x10304ec9a*/
        v37 = *(__int64 **)(v67 + 8); /*0x10304eca0*/
        v38 = *v37; /*0x10304eca4*/
        v39 = 2; /*0x10304eca7*/
        goto LABEL_49; /*0x10304ecac*/
      }
      v30 = v29 == 5; /*0x10304e93e*/
      v7 = 261; /*0x10304e941*/
      goto LABEL_52; /*0x10304e946*/
    }
    if ( *(_BYTE *)(v67 + 70) == 0 )
    {
      v10 = (const void ***)(v67 + 48); /*0x10304eb3b*/
      v43 = **(_QWORD **)(v67 + 48); /*0x10304eb45*/
      v44 = *(_DWORD *)(v43 + 96); /*0x10304eb48*/
      v11 = v43 + 96; /*0x10304eb4c*/
      v7 = 0; /*0x10304eb50*/
      if ( v44 == *(_DWORD *)(v67 + 88) ) /*0x10304eb57*/
      {
        v45 = *(_BYTE *)(v67 + 63); /*0x10304eb5d*/
        v7 = 0; /*0x10304eb62*/
        if ( v45 == 0 ) /*0x10304eb66*/
        {
          v7 = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, __int64))(**(_QWORD **)(v67 + 8) + 112LL))( /*0x10304eb82*/
                 a1: *(_QWORD *)(v67 + 8),
                 a2: 3,
                 a3: 1,
                 a4: 6);
          v45 = *(_BYTE *)(v67 + 63); /*0x10304eb84*/
        }
        if ( v45 != 2 ) /*0x10304eb8b*/
        {
          v46 = v7; /*0x10304eb8d*/
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v67 + 8) + 120LL))(a1: *(_QWORD *)(v67 + 8)); /*0x10304eb97*/
          v7 = v46; /*0x10304eb9a*/
        }
        if ( v7 != 5 ) /*0x10304eb9f*/
        {
          if ( v7 != 0 ) /*0x10304eba7*/
            return v7; /*0x10304eba7*/
          if ( memcmp(__s1: **v10, __s2: (const void *)(v67 + 72), __n: 0x30u) != 0 ) /*0x10304ebc8*/
          {
            v7 = -1; /*0x10304ebce*/
            if ( *(_BYTE *)(v67 + 63) != 0 ) /*0x10304ebd7*/
              return v7; /*0x10304ebd7*/
            v37 = *(__int64 **)(v67 + 8); /*0x10304ebdd*/
            v38 = *v37; /*0x10304ebe1*/
            v39 = 3; /*0x10304ebe4*/
            goto LABEL_49; /*0x10304ebe9*/
          }
          *(_WORD *)(v67 + 60) = 0; /*0x10304ecb1*/
          return 0; /*0x10304eafb*/
        }
      }
LABEL_8:
      v12 = *(_DWORD *)(v9 + 88); /*0x10304e76c*/
      v13 = 0; /*0x10304e771*/
      v14 = 2; /*0x10304e774*/
      v15 = 0; /*0x10304e779*/
      do /*0x10304e79f*/
      {
        if ( v13 <= *(_DWORD *)(v11 + 4 * v14) && *(_DWORD *)(v11 + 4 * v14) <= v12 ) /*0x10304e788*/
        {
          v15 = (unsigned int)(v14 - 1); /*0x10304e791*/
          v13 = *(_DWORD *)(v11 + 4 * v14); /*0x10304e795*/
        }
        ++v14; /*0x10304e798*/
      }
      while ( v14 != 6 ); /*0x10304e79f*/
      v30 = (*(_BYTE *)(v9 + 66) & 2) == 0; /*0x10304e7a1*/
      v66 = (_DWORD *)v11; /*0x10304e7a7*/
      if ( v30 )
      {
        if ( v13 < v12 || (_DWORD)v15 == 0 ) /*0x10304e7b5*/
        {
          v62.i64[0] = (__int64)v10; /*0x10304e7bb*/
          v16 = 0; /*0x10304e7c2*/
          v65 = v15; /*0x10304e7c5*/
          v9 = v67; /*0x10304e7c9*/
          while ( 1 ) /*0x10304e7cd*/
          {
            v17 = v16 + 4; /*0x10304e7cd*/
            if ( *(_BYTE *)(v67 + 63) != 0 ) /*0x10304e7d7*/
              break; /*0x10304e7d7*/
            v18 = (*(__int64 (__fastcall **)(_QWORD, _QWORD, __int64, __int64))(**(_QWORD **)(v67 + 8) + 112LL))( /*0x10304e7f2*/
                    a1: *(_QWORD *)(v67 + 8),
                    a2: v17,
                    a3: 1,
                    a4: 10);
            if ( v18 != 5 ) /*0x10304e7f8*/
            {
              v7 = v18; /*0x10304e97f*/
              v9 = v67; /*0x10304e983*/
              if ( v18 != 0 ) /*0x10304e987*/
                return v7; /*0x10304e987*/
              break; /*0x10304e987*/
            }
            ++v16; /*0x10304e7fe*/
            LODWORD(v15) = v65; /*0x10304e805*/
            if ( (_DWORD)v16 == 4 ) /*0x10304e809*/
            {
              v7 = 5; /*0x10304e80b*/
              v9 = v67; /*0x10304e810*/
              v10 = (const void ***)v62.i64[0]; /*0x10304e814*/
              goto LABEL_20; /*0x10304e814*/
            }
          }
          v66[v16 + 2] = v12; /*0x10304e98d*/
          v32 = v16 + 1; /*0x10304e996*/
          if ( *(_BYTE *)(v9 + 63) == 0 ) /*0x10304e99f*/
            (*(void (__fastcall **)(_QWORD, _QWORD, __int64, __int64))(**(_QWORD **)(v9 + 8) + 112LL))( /*0x10304e9b6*/
              a1: *(_QWORD *)(v9 + 8),
              a2: v17,
              a3: 1,
              a4: 9);
          v13 = v12; /*0x10304e9b9*/
          LODWORD(v15) = v32; /*0x10304e9bc*/
          v10 = (const void ***)v62.i64[0]; /*0x10304e9bf*/
        }
      }
      else
      {
LABEL_20:
        if ( (_DWORD)v15 == 0 )
          return v7 == 5 ? -1 : 0x508;
      }
      v33 = v15 + 3; /*0x10304e9c6*/
      LOBYTE(v34) = *(_BYTE *)(v9 + 63); /*0x10304e9ca*/
      if ( (_BYTE)v34 == 0 ) /*0x10304e9d1*/
      {
        v40 = v15; /*0x10304ea5d*/
        v29 = (*(__int64 (__fastcall **)(_QWORD, _QWORD, __int64, __int64))(**(_QWORD **)(v9 + 8) + 112LL))( /*0x10304ea75*/
                a1: *(_QWORD *)(v9 + 8),
                a2: v33,
                a3: 1,
                a4: 6);
        if ( v29 == 0 ) /*0x10304ea7a*/
        {
          v34 = *(unsigned __int8 *)(v9 + 63); /*0x10304eb22*/
          LODWORD(v15) = v40; /*0x10304eb27*/
          goto LABEL_43; /*0x10304eb2a*/
        }
        v30 = (_BYTE)v29 == 5; /*0x10304ea80*/
        v7 = -1; /*0x10304ea82*/
LABEL_52:
        if ( !v30 ) /*0x10304ea87*/
          return v29; /*0x10304ea87*/
        return v7; /*0x10304ea87*/
      }
LABEL_43:
      *(_DWORD *)(v9 + 120) = *v66 + 1; /*0x10304e9d7*/
      if ( (_BYTE)v34 != 2 ) /*0x10304e9e6*/
      {
        v35 = v15; /*0x10304e9f0*/
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(v9 + 8) + 120LL))(a1: *(_QWORD *)(v9 + 8)); /*0x10304e9f3*/
        LODWORD(v15) = v35; /*0x10304e9f6*/
      }
      if ( v66[(int)v15 + 1] == v13 ) /*0x10304ea07*/
      {
        v36 = v15; /*0x10304ea1a*/
        if ( memcmp(__s1: **v10, __s2: (const void *)(v9 + 72), __n: 0x30u) == 0 ) /*0x10304ea24*/
        {
          *(_WORD *)(v9 + 60) = v36; /*0x10304eaf5*/
          return 0; /*0x10304eaf5*/
        }
      }
      v7 = -1; /*0x10304ea2a*/
      if ( *(_BYTE *)(v9 + 63) == 0 ) /*0x10304ea35*/
      {
        v37 = *(__int64 **)(v9 + 8); /*0x10304ea3b*/
        v38 = *v37; /*0x10304ea40*/
        v39 = v33; /*0x10304ea43*/
LABEL_49:
        (*(void (__fastcall **)(__int64 *, __int64, __int64, __int64))(v38 + 112))(a1: v37, a2: v39, a3: 1, a4: 5); /*0x10304ea46*/
        return (unsigned int)-1; /*0x10304ea53*/
      }
      return v7; /*0x10304eb13*/
    }
  }
  if ( *(_BYTE *)(v67 + 63) == 0 ) /*0x10304e850*/
  {
    v31 = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, __int64))(**(_QWORD **)(v67 + 8) + 112LL))( /*0x10304e962*/
            a1: *(_QWORD *)(v67 + 8),
            a2: 3,
            a3: 1,
            a4: 6);
    if ( v31 != 0 ) /*0x10304e967*/
    {
      v22 = -1; /*0x10304e970*/
      if ( v31 != 5 ) /*0x10304e976*/
        v22 = v31; /*0x10304e976*/
      goto LABEL_58; /*0x10304e976*/
    }
  }
  *(_WORD *)(v67 + 60) = 0; /*0x10304e856*/
  v19 = *(_QWORD *)(v9 + 8); /*0x10304e85e*/
  v20 = nullptr; /*0x10304e866*/
  v21 = (*(__int64 (__fastcall **)(__int64, _QWORD, __int64, _QWORD, _BYTE *))(*(_QWORD *)v19 + 104LL))( /*0x10304e879*/
          a1: v19,
          a2: 0,
          a3: 0x8000,
          a4: 0,
          a5: v60);
  v22 = -1; /*0x10304e87c*/
  if ( v21 == 8 ) /*0x10304e885*/
  {
    v9 = v67; /*0x10304ea8c*/
    goto LABEL_58; /*0x10304ea90*/
  }
  if ( v21 == 1288 ) /*0x10304e890*/
  {
    v9 = v67; /*0x10304e896*/
    v23 = *(_QWORD *)(v67 + 16); /*0x10304e89a*/
    v24 = **(_OWORD ***)(v67 + 48); /*0x10304e8a4*/
    v25 = v24[1]; /*0x10304e8aa*/
    v26 = v24[2]; /*0x10304e8ae*/
    *(_OWORD *)(v67 + 72) = *v24; /*0x10304e8b2*/
    *(_OWORD *)(v9 + 88) = v25; /*0x10304e8b8*/
    *(_OWORD *)(v9 + 104) = v26; /*0x10304e8be*/
    v27 = (*(__int64 (__fastcall **)(__int64, __int64 *))(*(_QWORD *)v23 + 48LL))(a1: v23, a2: &v64); /*0x10304e8cb*/
    if ( v27 != 0 ) /*0x10304e8d0*/
    {
LABEL_27:
      v22 = v27; /*0x10304e8d6*/
      goto LABEL_58; /*0x10304e8d9*/
    }
    if ( v64 > 31 ) /*0x10304ebf3*/
    {
      v27 = (*(__int64 (__fastcall **)(_QWORD, _BYTE *, __int64, _QWORD))(**(_QWORD **)(v9 + 16) + 16LL))( /*0x10304ec27*/
              a1: *(_QWORD *)(v9 + 16),
              a2: v68,
              a3: 32,
              a4: 0);
      if ( v27 != 0 ) /*0x10304ec2c*/
        goto LABEL_27; /*0x10304ec2c*/
      if ( *(_QWORD *)(v9 + 104) != v69 ) /*0x10304ec3b*/
        goto LABEL_58; /*0x10304ec3b*/
      v53 = *(_DWORD *)(v9 + 56) + 24; /*0x10304ec46*/
      v54 = sqlite3Malloc(a1: v53, a2: v50, a3: v48, a4: v49, a5: v51, a6: v52); /*0x10304ec50*/
      v55 = v9; /*0x10304ec55*/
      if ( v54 == 0 ) /*0x10304ec5b*/
      {
        v22 = 7; /*0x10304ecbc*/
        goto LABEL_58; /*0x10304ecc5*/
      }
      v20 = (void *)v54; /*0x10304ec5d*/
      v62 = (__m128)*(unsigned __int64 *)(v55 + 96); /*0x10304ec65*/
      v56 = *(unsigned int *)(v55 + 88) * (unsigned __int64)(unsigned int)(*(_DWORD *)(v55 + 56) + 24); /*0x10304ec77*/
      if ( (__int64)(v53 + v56 + 32) <= v64 ) /*0x10304ec87*/
      {
        v65 = v53; /*0x10304ecca*/
        v66 = (_DWORD *)(v54 + 24); /*0x10304ecd5*/
        v57 = v56 + 32; /*0x10304ecd9*/
        v58 = v67; /*0x10304ecdd*/
        while ( 1 ) /*0x10304ecf1*/
        {
          v59 = (*(__int64 (__fastcall **)(_QWORD, void *, _QWORD, unsigned __int64))(**(_QWORD **)(v58 + 16) + 16LL))( /*0x10304ecf1*/
                  a1: *(_QWORD *)(v58 + 16),
                  a2: v20,
                  a3: (unsigned int)v53,
                  a4: v57);
          if ( v59 != 0 ) /*0x10304ecf6*/
            break; /*0x10304ecf6*/
          if ( (unsigned int)walDecodeFrame(a1: v58, a2: v61, a3: &v63, a4: v66, a5: v20) == 0 ) /*0x10304ed14*/
          {
            v59 = 0; /*0x10304ed31*/
            break; /*0x10304ed33*/
          }
          if ( v63 != 0 ) /*0x10304ed1e*/
          {
            v59 = -1; /*0x10304ed35*/
            break; /*0x10304ed35*/
          }
          v57 += v65; /*0x10304ed20*/
          if ( (__int64)(v57 + v65) > v64 ) /*0x10304ed2a*/
            goto LABEL_83; /*0x10304ed2a*/
        }
        v22 = v59; /*0x10304ed3a*/
      }
      else
      {
LABEL_83:
        v22 = 0; /*0x10304ec89*/
      }
      _mm_storel_ps((double *)(v67 + 96), v62); /*0x10304ed48*/
    }
    else
    {
      *a2 = 1; /*0x10304ebf5*/
      v47 = v9; /*0x10304ebfc*/
      v20 = nullptr; /*0x10304ebff*/
      v22 = -(*(_DWORD *)(v47 + 88) != 0); /*0x10304ec0c*/
    }
  }
  else
  {
    v22 = v21; /*0x10304ea92*/
  }
  sqlite3_free(a1: v20); /*0x10304ea98*/
  v9 = v67; /*0x10304eaa0*/
  if ( v22 == 0 ) /*0x10304eaa4*/
    return 0; /*0x10304eaa4*/
LABEL_58:
  if ( *(int *)(v9 + 40) > 0 ) /*0x10304eaac*/
  {
    v41 = 0; /*0x10304eaae*/
    do /*0x10304ead6*/
    {
      sqlite3_free(a1: *(void **)(*(_QWORD *)(v9 + 48) + 8 * v41)); /*0x10304eab9*/
      *(_QWORD *)(*(_QWORD *)(v9 + 48) + 8 * v41++) = 0; /*0x10304eac3*/
    }
    while ( v41 < *(int *)(v9 + 40) ); /*0x10304ead6*/
  }
  *(_BYTE *)(v9 + 70) = 0; /*0x10304ead8*/
  sqlite3WalEndReadTransaction(a1: v9); /*0x10304eae1*/
  *a2 = 1; /*0x10304eae6*/
  return v22; /*0x10304eaf0*/
}

// Address: 0x10304ed56 | Name: _walIndexReadHdr
__int64 __fastcall walIndexReadHdr(__int64 a1, _DWORD *a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6)
{
  unsigned int v8; // r13d
  __int64 v9; // rcx
  __int64 v10; // r8
  __int64 v11; // r9
  char v12; // r12
  char v13; // r15
  unsigned int v14; // eax
  int v15; // r15d
  unsigned int v16; // ecx
  unsigned int v17; // r15d
  int v18; // r13d
  unsigned int v19; // r15d
  int v20; // edi
  __int64 v21; // rdx
  __int64 v22; // rcx
  __int64 v23; // rsi
  __int64 v24; // r8
  __int64 v25; // r9
  __int64 v26; // rax
  void *v27; // rdi
  unsigned int v28; // eax
  __int64 v29; // rax
  __int64 v30; // rsi
  unsigned __int64 v31; // rcx
  int v32; // r15d
  unsigned __int64 v33; // rcx
  __int64 v34; // rdi
  unsigned int v35; // r15d
  unsigned int v36; // edx
  __int64 v37; // rsi
  unsigned int v38; // eax
  __int64 v39; // rcx
  void *v40; // r15
  unsigned int v41; // eax
  unsigned int v42; // ecx
  __int64 v43; // rax
  unsigned int v44; // r15d
  unsigned int v45; // r15d
  void *v46; // rdi
  unsigned __int64 v47; // r15
  unsigned int v48; // eax
  unsigned int v49; // eax
  bool v50; // zf
  __int64 v51; // r15
  int v52; // eax
  unsigned int v53; // eax
  unsigned int v54; // r13d
  unsigned int v55; // eax
  _DWORD *v56; // r15
  __int64 v57; // r12
  int v58; // eax
  __int64 v60; // [rsp+8h] [rbp-108h] BYREF
  __int64 v61; // [rsp+10h] [rbp-100h]
  unsigned __int64 v62; // [rsp+18h] [rbp-F8h]
  unsigned __int64 v63; // [rsp+20h] [rbp-F0h]
  unsigned __int64 v64; // [rsp+28h] [rbp-E8h]
  __m128 v65; // [rsp+30h] [rbp-E0h]
  __int64 v66; // [rsp+40h] [rbp-D0h] BYREF
  unsigned __int64 v67; // [rsp+48h] [rbp-C8h]
  __int64 v68; // [rsp+50h] [rbp-C0h]
  __int64 v69; // [rsp+58h] [rbp-B8h]
  __int64 v70; // [rsp+60h] [rbp-B0h]
  unsigned int v71; // [rsp+6Ch] [rbp-A4h]
  unsigned __int64 v72; // [rsp+70h] [rbp-A0h]
  __int64 v73; // [rsp+78h] [rbp-98h] BYREF
  __int64 v74; // [rsp+80h] [rbp-90h]
  unsigned int v75; // [rsp+88h] [rbp-88h] BYREF
  unsigned int v76; // [rsp+8Ch] [rbp-84h] BYREF
  __int64 v77; // [rsp+90h] [rbp-80h]
  __int64 v78; // [rsp+98h] [rbp-78h]
  unsigned int v79; // [rsp+A4h] [rbp-6Ch]
  void *v80; // [rsp+A8h] [rbp-68h]
  unsigned int v81; // [rsp+B4h] [rbp-5Ch]
  unsigned int v82; // [rsp+B8h] [rbp-58h]
  unsigned int v83; // [rsp+BCh] [rbp-54h]
  unsigned int v84[2]; // [rsp+C0h] [rbp-50h] BYREF
  int v85; // [rsp+C8h] [rbp-48h]
  unsigned int v86; // [rsp+CCh] [rbp-44h]
  __int64 v87; // [rsp+D0h] [rbp-40h]
  unsigned int v88; // [rsp+D8h] [rbp-38h]
  unsigned int v89; // [rsp+DCh] [rbp-34h]

  if ( *(int *)(a1 + 40) > 0 ) /*0x10304ed82*/
  {
    v73 = **(_QWORD **)(a1 + 48); /*0x10304ed8b*/
    v8 = 0; /*0x10304ed92*/
    if ( v73 != 0 ) /*0x10304ed98*/
      goto LABEL_7; /*0x10304ed98*/
  }
  v8 = walIndexPageRealloc(a1, a2: 0, a3: &v73, a4, a5, a6); /*0x10304edab*/
  if ( v8 != 0 ) /*0x10304edb0*/
  {
    if ( v8 != 1288 ) /*0x10304edb9*/
      return v8; /*0x10304edb9*/
    *(_BYTE *)(a1 + 70) = 1; /*0x10304edbf*/
    *(_BYTE *)(a1 + 63) = 2; /*0x10304edc3*/
    *a2 = 1; /*0x10304edc7*/
  }
  if ( v73 != 0 ) /*0x10304edd6*/
  {
LABEL_7:
    if ( (unsigned int)walIndexTryHdr(a1, a2) == 0 ) /*0x10304ede5*/
      goto LABEL_92; /*0x10304ede5*/
  }
  if ( *(_BYTE *)(a1 + 70) == 0 && (*(_BYTE *)(a1 + 66) & 2) != 0 ) /*0x10304edf5*/
  {
    v8 = 264; /*0x10304f2ee*/
    if ( *(_BYTE *)(a1 + 63) != 0 ) /*0x10304f2f8*/
      goto LABEL_93; /*0x10304f2f8*/
    v53 = (*(__int64 (__fastcall **)(_QWORD, _QWORD, __int64, __int64))(**(_QWORD **)(a1 + 8) + 112LL))( /*0x10304f311*/
            a1: *(_QWORD *)(a1 + 8),
            a2: 0,
            a3: 1,
            a4: 6);
    if ( v53 == 0 ) /*0x10304f316*/
    {
      if ( *(_BYTE *)(a1 + 63) == 0 ) /*0x10304f31c*/
        (*(void (__fastcall **)(_QWORD, _QWORD, __int64, __int64))(**(_QWORD **)(a1 + 8) + 112LL))( /*0x10304f335*/
          a1: *(_QWORD *)(a1 + 8),
          a2: 0,
          a3: 1,
          a4: 5);
      goto LABEL_93; /*0x10304f338*/
    }
LABEL_66:
    v8 = v53; /*0x10304f366*/
    goto LABEL_93; /*0x10304f369*/
  }
  v12 = *(_BYTE *)(a1 + 64); /*0x10304edfb*/
  if ( v12 == 0 ) /*0x10304ee02*/
  {
    if ( *(_BYTE *)(a1 + 63) == 0 ) /*0x10304ee08*/
    {
      v53 = (*(__int64 (__fastcall **)(_QWORD, _QWORD, __int64, __int64))(**(_QWORD **)(a1 + 8) + 112LL))( /*0x10304f35b*/
              a1: *(_QWORD *)(a1 + 8),
              a2: 0,
              a3: 1,
              a4: 10);
      if ( v53 != 0 ) /*0x10304f360*/
        goto LABEL_66; /*0x10304f360*/
    }
    *(_BYTE *)(a1 + 64) = 2; /*0x10304ee0e*/
  }
  if ( *(int *)(a1 + 40) <= 0 || (v73 = **(_QWORD **)(a1 + 48)) == 0 ) /*0x10304ee29*/
  {
    v13 = 0; /*0x10304ee2b*/
    v14 = walIndexPageRealloc(a1, a2: 0, a3: &v73, a4: v9, a5: v10, a6: v11); /*0x10304ee3a*/
    if ( v14 != 0 ) /*0x10304ee41*/
    {
      v8 = v14; /*0x10304ee43*/
      goto LABEL_88; /*0x10304ee46*/
    }
  }
  if ( (unsigned int)walIndexTryHdr(a1, a2) == 0 ) /*0x10304ee58*/
  {
    v13 = 1; /*0x10304f33d*/
    v8 = 0; /*0x10304f340*/
    goto LABEL_88; /*0x10304f343*/
  }
  v15 = *(unsigned __int8 *)(a1 + 65); /*0x10304ee5e*/
  v16 = 2 - v15; /*0x10304ee68*/
  v17 = v15 + 1; /*0x10304ee6b*/
  if ( *(_BYTE *)(a1 + 63) == 0 ) /*0x10304ee72*/
  {
    v54 = v16; /*0x10304f378*/
    v55 = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD, __int64))(**(_QWORD **)(a1 + 8) + 112LL))( /*0x10304f382*/
            a1: *(_QWORD *)(a1 + 8),
            a2: v17,
            a3: v16,
            a4: 10);
    v16 = v54; /*0x10304f385*/
    v8 = v55; /*0x10304f388*/
    if ( v55 != 0 ) /*0x10304f38d*/
      goto LABEL_87; /*0x10304f38d*/
  }
  v71 = v16; /*0x10304ee78*/
  *(_OWORD *)(a1 + 104) = 0; /*0x10304ee81*/
  *(_OWORD *)(a1 + 88) = 0; /*0x10304ee85*/
  v65 = 0; /*0x10304ee8c*/
  *(_OWORD *)(a1 + 72) = 0; /*0x10304ee93*/
  v8 = (*(__int64 (__fastcall **)(_QWORD, __int64 *))(**(_QWORD **)(a1 + 16) + 48LL))( /*0x10304eea8*/
         a1: *(_QWORD *)(a1 + 16),
         a2: &v66);
  if ( v8 != 0 ) /*0x10304eead*/
    goto LABEL_85; /*0x10304eead*/
  if ( v66 < 33 ) /*0x10304eebb*/
    goto LABEL_70; /*0x10304eebb*/
  v8 = (*(__int64 (__fastcall **)(_QWORD, unsigned int *, __int64, _QWORD))(**(_QWORD **)(a1 + 16) + 16LL))( /*0x10304eed6*/
         a1: *(_QWORD *)(a1 + 16),
         a2: v84,
         a3: 32,
         a4: 0);
  if ( v8 != 0 ) /*0x10304eedb*/
    goto LABEL_85; /*0x10304eedb*/
  v83 = v17; /*0x10304eee1*/
  if ( ((v84[0] << 24) | (BYTE1(v84[0]) << 16) | (BYTE2(v84[0]) << 8) | HIBYTE(v84[0]) & 0xFE) == 0x377F0682 ) /*0x10304ef0e*/
  {
    v18 = BYTE2(v85) << 8; /*0x10304ef28*/
    v79 = (v85 << 24) | (BYTE1(v85) << 16); /*0x10304ef31*/
    v19 = v18 | v79 | HIBYTE(v85); /*0x10304ef37*/
    if ( ((v19 - 1) & v19) == 0 && v19 - 65537 >= 0xFFFF01FF ) /*0x10304ef51*/
    {
      v20 = HIBYTE(v84[0]) & 1; /*0x10304ef5c*/
      *(_BYTE *)(a1 + 85) = v20; /*0x10304ef5f*/
      *(_DWORD *)(a1 + 56) = v19; /*0x10304ef63*/
      *(_DWORD *)(a1 + 136) = _byteswap_ulong(v86); /*0x10304ef70*/
      *(_QWORD *)(a1 + 104) = v87; /*0x10304ef7d*/
      walChecksumBytes(a1: v20 ^ 1u, a2: v84, a3: 24, a4: 0, a5: a1 + 96); /*0x10304ef8f*/
      if ( *(_DWORD *)(a1 + 96) == _byteswap_ulong(v88) && *(_DWORD *)(a1 + 100) == _byteswap_ulong(v89) ) /*0x10304efae*/
      {
        if ( _byteswap_ulong(v84[1]) != 3007000 ) /*0x10304efbe*/
        {
          v8 = 14; /*0x10304f579*/
          sqlite3_log( /*0x10304f58b*/
            iErrCode: 14,
            zFormat: "%s at line %d of [%.10s]",
            "cannot open file",
            68223,
            "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
          goto LABEL_84; /*0x10304f590*/
        }
        v26 = sqlite3Malloc(a1: v19 + 32792LL, a2: v23, a3: v21, a4: v22, a5: v24, a6: v25); /*0x10304efce*/
        if ( v26 == 0 ) /*0x10304efd6*/
        {
          v8 = 7; /*0x10304f5b0*/
          goto LABEL_84; /*0x10304f5b6*/
        }
        v27 = (void *)v26; /*0x10304efdc*/
        v68 = v19 + v26 + 24; /*0x10304efea*/
        v70 = v26 + 24; /*0x10304eff8*/
        v74 = v19 + 24LL; /*0x10304f00c*/
        v28 = (v66 - 32) / v74; /*0x10304f013*/
        v64 = ((unsigned __int64)(v28 + 4096) + 0xFFFFFFFF021LL) >> 12; /*0x10304f02d*/
        v63 = v28; /*0x10304f036*/
        v79 = v18 | HIWORD(v79); /*0x10304f046*/
        v65 = 0; /*0x10304f04c*/
        v29 = 0; /*0x10304f053*/
        v30 = 0; /*0x10304f055*/
        v80 = v27; /*0x10304f057*/
        while ( 1 ) /*0x10304f05b*/
        {
          v82 = v30; /*0x10304f05b*/
          v61 = v29; /*0x10304f05e*/
          v31 = (unsigned int)v29 + 4062LL; /*0x10304f067*/
          if ( v31 >= v63 ) /*0x10304f078*/
            v31 = v63; /*0x10304f078*/
          v62 = v31; /*0x10304f07c*/
          v32 = (_DWORD)v30 << 12; /*0x10304f086*/
          v33 = (unsigned int)(((_DWORD)v30 << 12) + 4062); /*0x10304f08a*/
          if ( v63 < v33 ) /*0x10304f094*/
            v33 = v63; /*0x10304f094*/
          v67 = v33; /*0x10304f098*/
          v8 = walIndexPage(a1, a2: v30, a3: &v60); /*0x10304f0ae*/
          v34 = v60; /*0x10304f0b1*/
          if ( v60 == 0 ) /*0x10304f0bb*/
            break; /*0x10304f0bb*/
          v35 = v32 - 33; /*0x10304f0c1*/
          v36 = v82; /*0x10304f0c5*/
          if ( v82 == 0 ) /*0x10304f0cf*/
            v35 = 1; /*0x10304f0cf*/
          v37 = v82; /*0x10304f0d7*/
          *(_QWORD *)(*(_QWORD *)(a1 + 48) + 8LL * v82) = v68; /*0x10304f0e0*/
          v38 = v67; /*0x10304f0e4*/
          if ( v35 > (unsigned int)v67 ) /*0x10304f0ee*/
          {
            LOBYTE(v38) = 1; /*0x10304f0f0*/
            v81 = v38; /*0x10304f0f2*/
            goto LABEL_42; /*0x10304f0f5*/
          }
          v78 = v36; /*0x10304f0f7*/
          v77 = v34; /*0x10304f0fb*/
          v72 = v35; /*0x10304f102*/
          v39 = v74 * (v35 - 1LL) + 32; /*0x10304f118*/
          v40 = v80; /*0x10304f123*/
          v41 = (*(__int64 (__fastcall **)(_QWORD, void *, __int64, __int64))(**(_QWORD **)(a1 + 16) + 16LL))( /*0x10304f12a*/
                  a1: *(_QWORD *)(a1 + 16),
                  a2: v80,
                  a3: v74,
                  a4: v39);
          v8 = 0; /*0x10304f12d*/
          if ( v41 != 0 ) /*0x10304f132*/
          {
            v42 = 0; /*0x10304f134*/
            v8 = v41; /*0x10304f136*/
            goto LABEL_40; /*0x10304f136*/
          }
          if ( (unsigned int)walDecodeFrame(a1, a2: &v75, a3: &v76, a4: v70, a5: v40) == 0 ) /*0x10304f1d1*/
          {
            v42 = 0; /*0x10304f2be*/
LABEL_40:
            v36 = v82; /*0x10304f139*/
            v34 = v77; /*0x10304f13c*/
            v37 = v78; /*0x10304f140*/
LABEL_41:
            v81 = v42; /*0x10304f144*/
            goto LABEL_42; /*0x10304f144*/
          }
          v47 = v72; /*0x10304f1de*/
          v69 = v72 * v74 + 32; /*0x10304f1ed*/
          v81 = 0; /*0x10304f1f4*/
          while ( 1 ) /*0x10304f207*/
          {
            v48 = walIndexAppend(a1, a2: (unsigned int)v47, a3: v75); /*0x10304f207*/
            if ( v48 != 0 ) /*0x10304f20e*/
            {
LABEL_57:
              v8 = v48; /*0x10304f2c5*/
              goto LABEL_58; /*0x10304f2c5*/
            }
            v49 = v76; /*0x10304f214*/
            if ( v76 != 0 ) /*0x10304f21c*/
            {
              *(_DWORD *)(a1 + 88) = v47; /*0x10304f21e*/
              *(_DWORD *)(a1 + 92) = v49; /*0x10304f222*/
              v49 = v79; /*0x10304f225*/
              *(_WORD *)(a1 + 86) = v79; /*0x10304f228*/
              v65 = (__m128)*(unsigned __int64 *)(a1 + 96); /*0x10304f231*/
            }
            LOBYTE(v49) = v47 >= v67; /*0x10304f23f*/
            v81 = v49; /*0x10304f242*/
            v72 = v47; /*0x10304f245*/
            v50 = v62 == v47; /*0x10304f24c*/
            v51 = v69; /*0x10304f25a*/
            if ( v50 ) /*0x10304f261*/
              break; /*0x10304f261*/
            v48 = (*(__int64 (__fastcall **)(_QWORD, void *, __int64, __int64))(**(_QWORD **)(a1 + 16) + 16LL))( /*0x10304f271*/
                    a1: *(_QWORD *)(a1 + 16),
                    a2: v80,
                    a3: v74,
                    a4: v69);
            if ( v48 != 0 ) /*0x10304f276*/
              goto LABEL_57; /*0x10304f276*/
            v52 = walDecodeFrame(a1, a2: &v75, a3: &v76, a4: v70, a5: v80); /*0x10304f294*/
            v69 = v74 + v51; /*0x10304f2a0*/
            v47 = v72 + 1; /*0x10304f2ae*/
            if ( v52 == 0 ) /*0x10304f2b3*/
            {
              v8 = 0; /*0x10304f2b9*/
LABEL_58:
              v36 = v82; /*0x10304f2c8*/
              v34 = v77; /*0x10304f2cb*/
              v37 = v78; /*0x10304f2cf*/
              v42 = v81; /*0x10304f2d3*/
              goto LABEL_41; /*0x10304f2d6*/
            }
          }
          v8 = 0; /*0x10304f2db*/
          v36 = v82; /*0x10304f2de*/
          v34 = v77; /*0x10304f2e1*/
          v37 = v78; /*0x10304f2e5*/
LABEL_42:
          *(_QWORD *)(*(_QWORD *)(a1 + 48) + 8 * v37) = v34; /*0x10304f147*/
          v43 = 0; /*0x10304f151*/
          if ( v36 == 0 ) /*0x10304f15b*/
            v43 = 136; /*0x10304f15b*/
          v44 = v36; /*0x10304f16d*/
          memcpy(__dst: (void *)(v43 + v34), __src: (const void *)(v68 + v43), __n: 0x8000 - v43); /*0x10304f178*/
          if ( (v81 & 1) == 0 ) /*0x10304f181*/
            break; /*0x10304f181*/
          v45 = v44 + 1; /*0x10304f187*/
          v29 = (unsigned int)(v61 + 4096); /*0x10304f191*/
          v30 = v45; /*0x10304f19d*/
          v46 = v80; /*0x10304f1a0*/
          if ( v45 > (unsigned int)v64 ) /*0x10304f1a4*/
            goto LABEL_105; /*0x10304f1a4*/
        }
        v46 = v80; /*0x10304f595*/
LABEL_105:
        sqlite3_free(a1: v46); /*0x10304f599*/
        v17 = v83; /*0x10304f5a1*/
        if ( v8 != 0 ) /*0x10304f5a5*/
          goto LABEL_85; /*0x10304f5a5*/
LABEL_70:
        v83 = v17; /*0x10304f39c*/
        LOBYTE(v80) = v12; /*0x10304f3a0*/
        _mm_storel_ps((double *)(a1 + 96), v65); /*0x10304f3ab*/
        walIndexWriteHdr(a1); /*0x10304f3b2*/
        v56 = **(_DWORD ***)(a1 + 48); /*0x10304f3bb*/
        v57 = 0; /*0x10304f3be*/
        v56[24] = 0; /*0x10304f3c1*/
        v56[32] = *(_DWORD *)(a1 + 88); /*0x10304f3c8*/
        v56[25] = 0; /*0x10304f3cf*/
        while ( 2 ) /*0x10304f3d7*/
        {
          if ( *(_BYTE *)(a1 + 63) != 0 ) /*0x10304f3d7*/
          {
LABEL_74:
            if ( v57 != 0 || (v58 = *(_DWORD *)(a1 + 88)) == 0 ) /*0x10304f414*/
              v56[v57 + 26] = -1; /*0x10304f404*/
            else
              v56[26] = v58; /*0x10304f416*/
            v8 = 0; /*0x10304f41a*/
            if ( *(_BYTE *)(a1 + 63) == 0 ) /*0x10304f421*/
              (*(void (__fastcall **)(_QWORD, _QWORD, __int64, __int64))(**(_QWORD **)(a1 + 8) + 112LL))( /*0x10304f439*/
                a1: *(_QWORD *)(a1 + 8),
                a2: (unsigned int)(v57 + 4),
                a3: 1,
                a4: 9);
          }
          else
          {
            v8 = (*(__int64 (__fastcall **)(_QWORD, _QWORD, __int64, __int64))(**(_QWORD **)(a1 + 8) + 112LL))( /*0x10304f3f2*/
                   a1: *(_QWORD *)(a1 + 8),
                   a2: (unsigned int)(v57 + 4),
                   a3: 1,
                   a4: 10);
            if ( v8 != 5 ) /*0x10304f3f8*/
            {
              if ( v8 != 0 ) /*0x10304f3fd*/
                goto LABEL_83; /*0x10304f3fd*/
              goto LABEL_74; /*0x10304f3fd*/
            }
          }
          if ( ++v57 != 4 ) /*0x10304f443*/
            continue; /*0x10304f443*/
          break;
        }
        if ( *(_DWORD *)(a1 + 92) != 0 ) /*0x10304f449*/
          sqlite3_log( /*0x10304f463*/
            iErrCode: 283,
            zFormat: "recovered %d frames from WAL file %s",
            *(_DWORD *)(a1 + 88),
            *(const char **)(a1 + 128));
LABEL_83:
        v12 = (char)v80; /*0x10304f468*/
LABEL_84:
        v17 = v83; /*0x10304f46c*/
LABEL_85:
        if ( *(_BYTE *)(a1 + 63) == 0 ) /*0x10304f47a*/
          (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD, __int64))(**(_QWORD **)(a1 + 8) + 112LL))( /*0x10304f48b*/
            a1: *(_QWORD *)(a1 + 8),
            a2: v17,
            a3: v71,
            a4: 9);
LABEL_87:
        *a2 = 1; /*0x10304f48e*/
        v13 = 0; /*0x10304f495*/
LABEL_88:
        if ( v12 == 0 ) /*0x10304f49b*/
        {
          *(_BYTE *)(a1 + 64) = 0; /*0x10304f49d*/
          if ( *(_BYTE *)(a1 + 63) == 0 ) /*0x10304f4a5*/
            (*(void (__fastcall **)(_QWORD, _QWORD, __int64, __int64))(**(_QWORD **)(a1 + 8) + 112LL))( /*0x10304f4ba*/
              a1: *(_QWORD *)(a1 + 8),
              a2: 0,
              a3: 1,
              a4: 9);
        }
        if ( v13 != 0 ) /*0x10304f4c0*/
        {
LABEL_92:
          if ( *(_DWORD *)(a1 + 72) == 3007000 ) /*0x10304f4c9*/
            goto LABEL_93; /*0x10304f4c9*/
          v8 = 14; /*0x10304f50b*/
          sqlite3_log( /*0x10304f51d*/
            iErrCode: 14,
            zFormat: "%s at line %d of [%.10s]",
            "cannot open file",
            69483,
            "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
          if ( *(_BYTE *)(a1 + 70) != 0 ) /*0x10304f526*/
          {
            walIndexClose(a1, a2: 0); /*0x10304f52d*/
            *(_BYTE *)(a1 + 70) = 0; /*0x10304f532*/
            goto LABEL_101; /*0x10304f536*/
          }
          return v8; /*0x10304f526*/
        }
LABEL_93:
        if ( *(_BYTE *)(a1 + 70) != 0 ) /*0x10304f4cf*/
        {
          if ( v8 != 0 ) /*0x10304f4d4*/
          {
            walIndexClose(a1, a2: 0); /*0x10304f4db*/
            *(_BYTE *)(a1 + 70) = 0; /*0x10304f4e0*/
            if ( v8 == 522 ) /*0x10304f4f0*/
              v8 = -1; /*0x10304f4f0*/
          }
          else
          {
            v8 = 0; /*0x10304f538*/
          }
LABEL_101:
          *(_BYTE *)(a1 + 63) = 0; /*0x10304f53b*/
        }
        return v8; /*0x10304f552*/
      }
    }
  }
  v17 = v83; /*0x10304f398*/
  goto LABEL_70; /*0x10304f398*/
}

// Address: 0x10304f5c0 | Name: _walIndexTryHdr
__int64 __fastcall walIndexTryHdr(__int64 a1, _DWORD *a2)
{
  __int128 **v4; // rax
  __int128 *v5; // r15
  __int128 v6; // xmm0
  __int128 v7; // xmm1
  __int128 v8; // xmm0
  __int128 v9; // xmm1
  int v10; // ecx
  __int64 result; // rax
  unsigned int v12; // ecx
  unsigned __int64 v13; // rdx
  unsigned int v14; // esi
  int v15; // ecx
  __int128 v16; // xmm0
  __int128 v17; // xmm1
  _OWORD __s2[3]; // [rsp+0h] [rbp-80h] BYREF
  _QWORD __s1[2]; // [rsp+30h] [rbp-50h] BYREF
  __int128 v20; // [rsp+40h] [rbp-40h]
  __int128 v21; // [rsp+50h] [rbp-30h]

  v4 = *(__int128 ***)(a1 + 48); /*0x10304f5d3*/
  v5 = *v4; /*0x10304f5d7*/
  v6 = **v4; /*0x10304f5da*/
  v7 = (*v4)[1]; /*0x10304f5de*/
  v21 = (*v4)[2]; /*0x10304f5e8*/
  v20 = v7; /*0x10304f5ec*/
  *(_OWORD *)__s1 = v6; /*0x10304f5f0*/
  if ( *(_BYTE *)(a1 + 63) != 2 ) /*0x10304f5f8*/
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(a1 + 8) + 120LL))(a1: *(_QWORD *)(a1 + 8)); /*0x10304f601*/
  v8 = v5[3]; /*0x10304f604*/
  v9 = v5[4]; /*0x10304f609*/
  __s2[2] = v5[5]; /*0x10304f617*/
  __s2[1] = v9; /*0x10304f61b*/
  __s2[0] = v8; /*0x10304f61f*/
  v10 = memcmp(__s1, __s2, __n: 0x30u); /*0x10304f630*/
  result = 1; /*0x10304f632*/
  if ( v10 == 0 && BYTE4(__s1[1]) != 0 ) /*0x10304f643*/
  {
    v12 = 0; /*0x10304f645*/
    v13 = 0x1FFFFFFFFFFFFFFFLL; /*0x10304f647*/
    v14 = 0; /*0x10304f64e*/
    do /*0x10304f664*/
    {
      v14 += LODWORD(__s1[v13 + 1]) + v12; /*0x10304f652*/
      v12 += v14 + HIDWORD(__s1[++v13]); /*0x10304f65a*/
    }
    while ( v13 < 4 ); /*0x10304f664*/
    if ( __PAIR64__(v12, v14) == *((_QWORD *)&v21 + 1) ) /*0x10304f669*/
    {
      v15 = memcmp(__s1: (const void *)(a1 + 72), __s2: __s1, __n: 0x30u); /*0x10304f685*/
      result = 0; /*0x10304f687*/
      if ( v15 != 0 ) /*0x10304f68b*/
      {
        *a2 = 1; /*0x10304f68d*/
        v16 = *(_OWORD *)__s1; /*0x10304f694*/
        v17 = v20; /*0x10304f698*/
        *(_OWORD *)(a1 + 104) = v21; /*0x10304f6a0*/
        *(_OWORD *)(a1 + 88) = v17; /*0x10304f6a5*/
        *(_OWORD *)(a1 + 72) = v16; /*0x10304f6aa*/
        *(_DWORD *)(a1 + 56) = *(_WORD *)(a1 + 86) & 0xFE00 | (*(unsigned __int16 *)(a1 + 86) << 16) & 0x1FE00; /*0x10304f6bf*/
      }
    }
  }
  return result; /*0x10304f6c2*/
}

// Address: 0x10304f6cd | Name: _walIndexClose
char __fastcall walIndexClose(__int64 a1, unsigned int a2)
{
  char result; // al
  __int64 v5; // r15

  result = *(_BYTE *)(a1 + 63); /*0x10304f6dc*/
  if ( result != 2 && *(_BYTE *)(a1 + 70) == 0 ) /*0x10304f6e8*/
    return (*(__int64 (__fastcall **)(_QWORD, _QWORD))(**(_QWORD **)(a1 + 8) + 128LL))(a1: *(_QWORD *)(a1 + 8), a2); /*0x10304f6e8*/
  if ( *(int *)(a1 + 40) > 0 ) /*0x10304f6ef*/
  {
    v5 = 0; /*0x10304f6f1*/
    do /*0x10304f717*/
    {
      sqlite3_free(a1: *(void **)(*(_QWORD *)(a1 + 48) + 8 * v5)); /*0x10304f6fc*/
      *(_QWORD *)(*(_QWORD *)(a1 + 48) + 8 * v5++) = 0; /*0x10304f705*/
    }
    while ( v5 < *(int *)(a1 + 40) ); /*0x10304f717*/
    result = *(_BYTE *)(a1 + 63); /*0x10304f719*/
  }
  if ( result != 2 ) /*0x10304f71f*/
    return (*(__int64 (__fastcall **)(_QWORD, _QWORD))(**(_QWORD **)(a1 + 8) + 128LL))(a1: *(_QWORD *)(a1 + 8), a2); /*0x10304f746*/
  return result; /*0x10304f725*/
}

// Address: 0x10304f748 | Name: _walChecksumBytes
unsigned int *__fastcall walChecksumBytes(int a1, unsigned int *a2, int a3, int *a4, _DWORD *a5)
{
  int v5; // r9d
  int v6; // r10d
  unsigned int *result; // rax
  int v8; // ecx
  int v9; // ecx
  int v10; // r9d
  unsigned int v11; // ecx
  unsigned int v12; // r9d
  unsigned int v13; // ecx
  unsigned int v14; // r9d
  unsigned int v15; // ecx
  unsigned int v16; // r9d
  unsigned int v17; // ecx
  unsigned int v18; // r9d
  unsigned int v19; // ecx
  int v20; // r9d
  int v21; // ecx
  int v22; // r9d
  int v23; // ecx
  int v24; // ecx

  if ( a4 != nullptr ) /*0x10304f74e*/
  {
    v5 = *a4; /*0x10304f750*/
    v6 = a4[1]; /*0x10304f753*/
  }
  else
  {
    v6 = 0; /*0x10304f759*/
    v5 = 0; /*0x10304f75c*/
  }
  result = (unsigned int *)((char *)a2 + a3); /*0x10304f763*/
  if ( a1 != 0 ) /*0x10304f768*/
  {
    v8 = v6; /*0x10304f76a*/
    if ( (a3 & 0x3F) != 0 ) /*0x10304f770*/
    {
      do /*0x10304f785*/
      {
        v5 += *a2 + v8; /*0x10304f775*/
        v9 = a2[1] + v8; /*0x10304f778*/
        a2 += 2; /*0x10304f77b*/
        v8 = v5 + v9; /*0x10304f77f*/
      }
      while ( a2 < result ); /*0x10304f785*/
    }
    else
    {
      do /*0x10304f81d*/
      {
        v10 = *a2 + v8 + v5; /*0x10304f7b2*/
        v11 = v10 + a2[1] + v8; /*0x10304f7b8*/
        v12 = v11 + a2[2] + v10; /*0x10304f7bf*/
        v13 = v12 + a2[3] + v11; /*0x10304f7c5*/
        v14 = v13 + a2[4] + v12; /*0x10304f7cc*/
        v15 = v14 + a2[5] + v13; /*0x10304f7d2*/
        v16 = v15 + a2[6] + v14; /*0x10304f7d9*/
        v17 = v16 + a2[7] + v15; /*0x10304f7df*/
        v18 = v17 + a2[8] + v16; /*0x10304f7e6*/
        v19 = v18 + a2[9] + v17; /*0x10304f7ec*/
        v20 = v19 + a2[10] + v18; /*0x10304f7f3*/
        v21 = v20 + a2[11] + v19; /*0x10304f7f9*/
        v22 = v21 + a2[12] + v20; /*0x10304f800*/
        v23 = v22 + a2[13] + v21; /*0x10304f806*/
        v5 = v23 + a2[14] + v22; /*0x10304f80d*/
        v24 = a2[15] + v23; /*0x10304f810*/
        a2 += 16; /*0x10304f813*/
        v8 = v5 + v24; /*0x10304f817*/
      }
      while ( a2 < result ); /*0x10304f81d*/
    }
  }
  else
  {
    do /*0x10304f7ab*/
    {
      v5 += _byteswap_ulong(*a2) + v6; /*0x10304f796*/
      v8 = v5 + v6 + _byteswap_ulong(a2[1]); /*0x10304f79e*/
      a2 += 2; /*0x10304f7a1*/
      v6 = v8; /*0x10304f7a5*/
    }
    while ( a2 < result ); /*0x10304f7ab*/
  }
  *a5 = v5; /*0x10304f81f*/
  a5[1] = v8; /*0x10304f822*/
  return result; /*0x10304f827*/
}

// Address: 0x10304f828 | Name: _walDecodeFrame
__int64 __fastcall walDecodeFrame(__int64 a1, unsigned __int32 *a2, _DWORD *a3, unsigned int *a4, __int64 a5)
{
  unsigned int v5; // ebx
  unsigned __int32 v8; // eax
  int *v10; // r12
  _BOOL4 v11; // r14d
  unsigned __int32 v15; // [rsp+24h] [rbp-2Ch]

  v5 = 0; /*0x10304f83d*/
  if ( *(_QWORD *)(a1 + 104) == *(_QWORD *)(a5 + 8) ) /*0x10304f843*/
  {
    v8 = _byteswap_ulong(*(_DWORD *)a5); /*0x10304f85c*/
    if ( v8 != 0 ) /*0x10304f860*/
    {
      v15 = v8; /*0x10304f865*/
      v10 = (int *)(a1 + 96); /*0x10304f870*/
      v11 = *(_BYTE *)(a1 + 85) == 0; /*0x10304f87b*/
      walChecksumBytes(a1: v11, a2: (unsigned int *)a5, a3: 8, a4: v10, a5: v10); /*0x10304f894*/
      walChecksumBytes(a1: v11, a2: a4, a3: *(_DWORD *)(a1 + 56), a4: v10, a5: v10); /*0x10304f8aa*/
      if ( *(_DWORD *)(a1 + 96) == _byteswap_ulong(*(_DWORD *)(a5 + 16)) /*0x10304f8c5*/
        && *(_DWORD *)(a1 + 100) == _byteswap_ulong(*(_DWORD *)(a5 + 20)) )
      {
        *a2 = v15; /*0x10304f8d2*/
        *a3 = _byteswap_ulong(*(_DWORD *)(a5 + 4)); /*0x10304f8de*/
        return 1; /*0x10304f8e0*/
      }
    }
  }
  return v5; /*0x10304f847*/
}

// Address: 0x10304f8ea | Name: _walIndexAppend
__int64 __fastcall walIndexAppend(__int64 a1, int a2, int a3)
{
  unsigned int v6; // r15d
  int v7; // r13d
  __int64 v8; // r15
  __int64 v9; // rcx
  __int64 v10; // rax
  int v11; // r14d
  __int64 v13; // [rsp+8h] [rbp-48h] BYREF
  __int64 v14; // [rsp+10h] [rbp-40h]
  int v15; // [rsp+18h] [rbp-38h]
  int v16; // [rsp+20h] [rbp-30h]
  int v17; // [rsp+24h] [rbp-2Ch]

  v6 = walHashGet(a1, a2: ((unsigned __int64)(unsigned int)(a2 + 4096) + 0xFFFFFFFF021LL) >> 12, a3: (__int64)&v13); /*0x10304f924*/
  if ( v6 == 0 ) /*0x10304f929*/
  {
    v16 = a3; /*0x10304f92f*/
    v17 = v15; /*0x10304f938*/
    v7 = a2 - v15; /*0x10304f93b*/
    v8 = v14; /*0x10304f947*/
    if ( a2 - v15 == 1 ) /*0x10304f942*/
      __bzero(a1: v14, a2: (int)v13 - (int)v14 + 0x4000); /*0x10304f959*/
    if ( *(_DWORD *)(v8 + 4LL * v7 - 4) != 0 ) /*0x10304f96d*/
      walCleanupHash(a1); /*0x10304f972*/
    v9 = v13; /*0x10304f980*/
    v10 = (383 * (_WORD)v16) & 0x1FFF; /*0x10304f984*/
    if ( *(_WORD *)(v13 + 2 * v10) != 0 ) /*0x10304f98e*/
    {
      v11 = v17 + ~a2; /*0x10304f993*/
      while ( ++v11 != 0 ) /*0x10304f997*/
      {
        v10 = ((_WORD)v10 + 1) & 0x1FFF; /*0x10304f99e*/
        if ( *(_WORD *)(v13 + 2 * v10) == 0 ) /*0x10304f9a8*/
          goto LABEL_10; /*0x10304f9a8*/
      }
      v6 = 11; /*0x10304f9ce*/
      sqlite3_log( /*0x10304f9e0*/
        iErrCode: 11,
        zFormat: "%s at line %d of [%.10s]",
        "database corruption",
        68091,
        "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
    }
    else
    {
LABEL_10:
      *(_DWORD *)(v8 + 4LL * v7 - 4) = v16; /*0x10304f9aa*/
      *(_WORD *)(v9 + 2 * v10) = v7; /*0x10304f9af*/
      return 0; /*0x10304f9b4*/
    }
  }
  return v6; /*0x10304f9e8*/
}

// Address: 0x10304f9f7 | Name: _walIndexWriteHdr
__int64 __fastcall walIndexWriteHdr(__int64 a1)
{
  _OWORD *v1; // rbx
  __int128 *v2; // r14
  __int64 result; // rax
  unsigned __int64 v4; // rcx
  int v5; // edx
  __int128 v6; // xmm0
  __int128 v7; // xmm1
  __int128 v8; // xmm0
  __int128 v9; // xmm1

  v1 = **(_OWORD ***)(a1 + 48); /*0x10304fa02*/
  v2 = (__int128 *)(a1 + 72); /*0x10304fa05*/
  *(_BYTE *)(a1 + 84) = 1; /*0x10304fa09*/
  *(_DWORD *)(a1 + 72) = 3007000; /*0x10304fa0d*/
  LODWORD(result) = 0; /*0x10304fa14*/
  v4 = 64; /*0x10304fa16*/
  v5 = 0; /*0x10304fa1b*/
  do /*0x10304fa31*/
  {
    v5 += *(_DWORD *)(a1 + v4 + 8) + result; /*0x10304fa1f*/
    result = (unsigned int)(v5 + *(_DWORD *)(a1 + v4 + 12) + result); /*0x10304fa27*/
    v4 += 8LL; /*0x10304fa29*/
  }
  while ( v4 < 0x68 ); /*0x10304fa31*/
  *(_DWORD *)(a1 + 112) = v5; /*0x10304fa33*/
  *(_DWORD *)(a1 + 116) = result; /*0x10304fa36*/
  v6 = *v2; /*0x10304fa39*/
  v7 = *(_OWORD *)(a1 + 88); /*0x10304fa3d*/
  v1[5] = *(_OWORD *)(a1 + 104); /*0x10304fa47*/
  v1[4] = v7; /*0x10304fa4b*/
  v1[3] = v6; /*0x10304fa4f*/
  if ( *(_BYTE *)(a1 + 63) != 2 ) /*0x10304fa57*/
    result = (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a1 + 8) + 120LL))(a1: *(_QWORD *)(a1 + 8)); /*0x10304fa60*/
  v8 = *v2; /*0x10304fa63*/
  v9 = v2[1]; /*0x10304fa67*/
  v1[2] = v2[2]; /*0x10304fa71*/
  v1[1] = v9; /*0x10304fa75*/
  *v1 = v8; /*0x10304fa79*/
  return result; /*0x10304fa7c*/
}

// Address: 0x1030510f2 | Name: _writeJournalHdr
__int64 __fastcall writeJournalHdr(__int64 a1, __int64 a2)
{
  __int64 v3; // r14
  __int64 v4; // rcx
  unsigned int v5; // r15d
  __int64 v6; // rdx
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rax
  __int64 v10; // rdi
  unsigned int v11; // r13d
  __int64 result; // rax

  v3 = *(_QWORD *)(a1 + 280); /*0x103051103*/
  v4 = *(unsigned int *)(a1 + 184); /*0x10305110a*/
  v5 = *(_DWORD *)(a1 + 200); /*0x103051110*/
  if ( (unsigned int)v4 < v5 ) /*0x10305111a*/
    v5 = *(_DWORD *)(a1 + 184); /*0x10305111a*/
  v6 = *(int *)(a1 + 128); /*0x10305111e*/
  if ( v6 > 0 ) /*0x103051128*/
  {
    v7 = *(_QWORD *)(a1 + 120); /*0x10305112a*/
    v6 *= 56; /*0x10305112e*/
    a2 = 0; /*0x103051132*/
    do /*0x10305114c*/
    {
      if ( *(_QWORD *)(v7 + a2 + 8) == 0 ) /*0x10305113a*/
        *(_QWORD *)(v7 + a2 + 8) = *(_QWORD *)(a1 + 96); /*0x103051140*/
      a2 += 56; /*0x103051145*/
    }
    while ( v6 != a2 ); /*0x10305114c*/
  }
  v8 = *(_QWORD *)(a1 + 96); /*0x10305114e*/
  if ( v8 != 0 ) /*0x103051155*/
  {
    v6 = (v8 - 1) % v4; /*0x10305115c*/
    v9 = v4 * ((v8 - 1) / v4 + 1); /*0x103051162*/
  }
  else
  {
    v9 = 0; /*0x103051168*/
  }
  *(_QWORD *)(a1 + 96) = v9; /*0x10305116a*/
  *(_QWORD *)(a1 + 104) = v9; /*0x10305116e*/
  if ( *(_BYTE *)(a1 + 11) != 0 /*0x103051191*/
    || *(_BYTE *)(a1 + 9) == 4
    || *(_QWORD *)(v10 = *(_QWORD *)(a1 + 72)) != 0
    && ((*(__int64 (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v10 + 96LL))(a1: v10, a2, a3: v6) & 0x200) != 0 )
  {
    *(_QWORD *)v3 = 0xD763A120F905D5D9LL; /*0x1030511ae*/
    *(_DWORD *)(v3 + 8) = -1; /*0x1030511b1*/
  }
  else
  {
    *(_DWORD *)(v3 + 8) = 0; /*0x103051193*/
    *(_QWORD *)v3 = 0; /*0x10305119b*/
  }
  if ( *(_BYTE *)(a1 + 9) != 4 ) /*0x1030511bd*/
    sqlite3_randomness(N: 4, P: (void *)(a1 + 56)); /*0x1030511c8*/
  *(_DWORD *)(v3 + 12) = _byteswap_ulong(*(_DWORD *)(a1 + 56)); /*0x1030511d2*/
  *(_DWORD *)(v3 + 16) = _byteswap_ulong(*(_DWORD *)(a1 + 36)); /*0x1030511db*/
  *(_DWORD *)(v3 + 20) = _byteswap_ulong(*(_DWORD *)(a1 + 184)); /*0x1030511e7*/
  *(_DWORD *)(v3 + 24) = _byteswap_ulong(*(_DWORD *)(a1 + 200)); /*0x1030511f3*/
  __bzero(a1: v3 + 28, a2: v5 - 28LL); /*0x103051203*/
  v11 = -v5; /*0x10305120b*/
  while ( 1 ) /*0x10305120e*/
  {
    v11 += v5; /*0x10305120e*/
    if ( v11 >= *(_DWORD *)(a1 + 184) ) /*0x103051218*/
      break; /*0x103051218*/
    result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD, _QWORD))(**(_QWORD **)(a1 + 80) + 24LL))( /*0x10305122b*/
               a1: *(_QWORD *)(a1 + 80),
               a2: v3,
               a3: v5,
               a4: *(_QWORD *)(a1 + 96));
    *(_QWORD *)(a1 + 96) += v5; /*0x10305122e*/
    if ( (_DWORD)result != 0 ) /*0x103051234*/
      return result; /*0x103051234*/
  }
  return 0; /*0x10305123e*/
}

// Address: 0x103051b5e | Name: _writeSuperJournal
__int64 __fastcall writeSuperJournal(__int64 a1, char *a2)
{
  __int64 result; // rax
  __int64 *v4; // rdi
  __int64 v5; // r8
  char v7; // al
  __int64 v8; // r14
  unsigned int v9; // r13d
  __int64 v10; // r12
  __int64 v11; // r12
  __int64 v12; // rdi
  __int64 v13; // r12
  __int64 v14; // rdi
  __int64 v15; // rdi
  unsigned int v16; // [rsp-40h] [rbp-40h]
  _QWORD v17[7]; // [rsp-38h] [rbp-38h] BYREF

  result = 0; /*0x103051b5e*/
  if ( a2 != nullptr && *(_BYTE *)(a1 + 9) != 4 ) /*0x103051b81*/
  {
    v4 = *(__int64 **)(a1 + 80); /*0x103051b87*/
    v5 = *v4; /*0x103051b8b*/
    if ( *v4 != 0 ) /*0x103051b91*/
    {
      *(_BYTE *)(a1 + 24) = 1; /*0x103051b9a*/
      v7 = *a2; /*0x103051b9e*/
      if ( *a2 != 0 ) /*0x103051ba2*/
      {
        v8 = 0; /*0x103051ba4*/
        v9 = 0; /*0x103051ba7*/
        do /*0x103051bba*/
        {
          v9 += v7; /*0x103051bad*/
          v7 = a2[++v8]; /*0x103051bb0*/
        }
        while ( v7 != 0 ); /*0x103051bba*/
        v16 = v8; /*0x103051bbf*/
      }
      else
      {
        v16 = 0; /*0x103051bc5*/
        v9 = 0; /*0x103051bcd*/
        v8 = 0; /*0x103051bd0*/
      }
      v10 = *(_QWORD *)(a1 + 96); /*0x103051bd7*/
      if ( *(_BYTE *)(a1 + 12) != 0 ) /*0x103051bdb*/
      {
        if ( v10 != 0 ) /*0x103051be0*/
          v10 = *(unsigned int *)(a1 + 184) * ((v10 - 1) / *(unsigned int *)(a1 + 184) + 1); /*0x103051bf9*/
        else
          v10 = 0; /*0x103051bff*/
        *(_QWORD *)(a1 + 96) = v10; /*0x103051c02*/
      }
      LODWORD(v17[0]) = _byteswap_ulong(*(_DWORD *)(a1 + 192)); /*0x103051c12*/
      result = (*(__int64 (__fastcall **)(__int64 *, _QWORD *, __int64, __int64))(v5 + 24))( /*0x103051c1c*/
                 a1: v4,
                 a2: v17,
                 a3: 4,
                 a4: v10);
      if ( (_DWORD)result == 0 ) /*0x103051c22*/
      {
        v11 = v10 + 4; /*0x103051c2c*/
        result = (*(__int64 (__fastcall **)(_QWORD, char *, _QWORD, __int64))(**(_QWORD **)(a1 + 80) + 24LL))( /*0x103051c40*/
                   a1: *(_QWORD *)(a1 + 80),
                   a2,
                   a3: v16,
                   a4: v11);
        if ( (_DWORD)result == 0 ) /*0x103051c45*/
        {
          v12 = *(_QWORD *)(a1 + 80); /*0x103051c4b*/
          v13 = v8 + v11; /*0x103051c4f*/
          LODWORD(v17[0]) = _byteswap_ulong(v16); /*0x103051c5b*/
          result = (*(__int64 (__fastcall **)(__int64, _QWORD *, __int64, __int64))(*(_QWORD *)v12 + 24LL))( /*0x103051c68*/
                     a1: v12,
                     a2: v17,
                     a3: 4,
                     a4: v13);
          if ( (_DWORD)result == 0 ) /*0x103051c6d*/
          {
            v14 = *(_QWORD *)(a1 + 80); /*0x103051c6f*/
            LODWORD(v17[0]) = _byteswap_ulong(v9); /*0x103051c7f*/
            result = (*(__int64 (__fastcall **)(__int64, _QWORD *, __int64, __int64))(*(_QWORD *)v14 + 24LL))( /*0x103051c8a*/
                       a1: v14,
                       a2: v17,
                       a3: 4,
                       a4: v13 + 4);
            if ( (_DWORD)result == 0 ) /*0x103051c8f*/
            {
              result = (*(__int64 (__fastcall **)(_QWORD, void *, __int64, __int64))(**(_QWORD **)(a1 + 80) + 24LL))( /*0x103051cab*/
                         a1: *(_QWORD *)(a1 + 80),
                         a2: &aJournalMagic,
                         a3: 8,
                         a4: v13 + 8);
              if ( (_DWORD)result == 0 ) /*0x103051cb0*/
              {
                v15 = *(_QWORD *)(a1 + 80); /*0x103051cb5*/
                *(_QWORD *)(a1 + 96) += v16 + 20LL; /*0x103051cc4*/
                result = (*(__int64 (__fastcall **)(__int64, _QWORD *))(*(_QWORD *)v15 + 48LL))(a1: v15, a2: v17); /*0x103051ccf*/
                if ( (_DWORD)result == 0 ) /*0x103051cd4*/
                {
                  result = 0; /*0x103051cda*/
                  if ( v17[0] > *(__int64 *)(a1 + 96) ) /*0x103051ce0*/
                    return (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a1 + 80) + 32LL))(a1: *(_QWORD *)(a1 + 80)); /*0x103051ce9*/
                }
              }
            }
          }
        }
      }
    }
  }
  return result; /*0x103051cfa*/
}

// Address: 0x10305207d | Name: _walWriteOneFrame
__int64 __fastcall walWriteOneFrame(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v6; // r15
  __int64 result; // rax
  _BYTE v8[24]; // [rsp+0h] [rbp-40h] BYREF

  v6 = *(_QWORD *)(a2 + 8); /*0x1030520a0*/
  walEncodeFrame(a1: *(_QWORD *)a1, a2: *(unsigned int *)(a2 + 48), a3, a4: v6, a5: v8); /*0x1030520b4*/
  result = walWriteToLog(a1, a2: v8, a3: 24, a4); /*0x1030520c7*/
  if ( (_DWORD)result == 0 ) /*0x1030520ce*/
    return walWriteToLog(a1, a2: v6, a3: *(unsigned int *)(a1 + 28), a4: a4 + 24); /*0x1030520e1*/
  return result; /*0x1030520f6*/
}

// Address: 0x103052108 | Name: _walLimitSize
void __fastcall walLimitSize(__int64 a1, __int64 a2)
{
  __int64 v2; // rax
  int v5; // r15d
  _QWORD v6[4]; // [rsp+0h] [rbp-20h] BYREF

  v6[0] = v2; /*0x103052111*/
  if ( sqlite3Hooks_0 != nullptr ) /*0x103052122*/
    sqlite3Hooks_0(); /*0x103052124*/
  v5 = (*(__int64 (__fastcall **)(_QWORD, _QWORD *))(**(_QWORD **)(a1 + 16) + 48LL))(a1: *(_QWORD *)(a1 + 16), a2: v6); /*0x103052134*/
  if ( v5 == 0 ) /*0x103052139*/
  {
    v5 = 0; /*0x10305213b*/
    if ( v6[0] > a2 ) /*0x103052142*/
      v5 = (*(__int64 (__fastcall **)(_QWORD, __int64))(**(_QWORD **)(a1 + 16) + 32LL))(a1: *(_QWORD *)(a1 + 16), a2); /*0x103052151*/
  }
  if ( sqlite3Hooks_1 != nullptr ) /*0x10305215e*/
    sqlite3Hooks_1(); /*0x103052160*/
  if ( v5 != 0 )
    sqlite3_log(iErrCode: v5, zFormat: "cannot limit WAL size: %s", *(const char **)(a1 + 128));
}

// Address: 0x10305218a | Name: _walRestartHdr
__int64 __fastcall walRestartHdr(__int64 a1, int a2)
{
  _DWORD *v2; // rbx
  __int64 v3; // r14
  unsigned __int32 v4; // eax
  __int64 result; // rax

  v2 = **(_DWORD ***)(a1 + 48); /*0x103052195*/
  ++*(_DWORD *)(a1 + 136); /*0x103052198*/
  v3 = 0; /*0x10305219e*/
  *(_DWORD *)(a1 + 88) = 0; /*0x1030521a1*/
  v4 = _byteswap_ulong(*(_DWORD *)(a1 + 104)) + 1; /*0x1030521aa*/
  *(_BYTE *)(a1 + 104) = HIBYTE(v4); /*0x1030521b1*/
  *(_BYTE *)(a1 + 105) = BYTE2(v4); /*0x1030521b9*/
  *(_BYTE *)(a1 + 106) = BYTE1(v4); /*0x1030521bc*/
  *(_BYTE *)(a1 + 107) = v4; /*0x1030521bf*/
  *(_DWORD *)(a1 + 108) = a2; /*0x1030521c2*/
  result = walIndexWriteHdr(a1); /*0x1030521c5*/
  v2[24] = 0; /*0x1030521ca*/
  v2[32] = 0; /*0x1030521d1*/
  v2[26] = 0; /*0x1030521d8*/
  do /*0x1030521ec*/
    v2[v3++ + 27] = -1; /*0x1030521dc*/
  while ( v3 != 3 ); /*0x1030521ec*/
  return result; /*0x1030521ee*/
}

// Address: 0x1030521f3 | Name: _walEncodeFrame
__int64 __fastcall walEncodeFrame(__int64 a1, int a2, unsigned int a3, unsigned int *a4, __int64 a5)
{
  __int64 result; // rax
  int *v9; // r12
  _BOOL4 v10; // r13d

  *(_BYTE *)a5 = HIBYTE(a2); /*0x10305220e*/
  *(_BYTE *)(a5 + 1) = BYTE2(a2); /*0x103052216*/
  *(_BYTE *)(a5 + 2) = BYTE1(a2); /*0x10305221a*/
  *(_BYTE *)(a5 + 3) = a2; /*0x10305221d*/
  *(_BYTE *)(a5 + 4) = HIBYTE(a3); /*0x103052226*/
  result = HIWORD(a3); /*0x10305222c*/
  *(_BYTE *)(a5 + 5) = BYTE2(a3); /*0x10305222f*/
  *(_BYTE *)(a5 + 6) = BYTE1(a3); /*0x103052233*/
  *(_BYTE *)(a5 + 7) = a3; /*0x103052236*/
  if ( *(_DWORD *)(a1 + 124) != 0 ) /*0x10305223e*/
  {
    *(_OWORD *)(a5 + 8) = 0; /*0x103052243*/
  }
  else
  {
    v9 = (int *)(a1 + 96); /*0x10305224c*/
    *(_QWORD *)(a5 + 8) = *(_QWORD *)(a1 + 104); /*0x103052254*/
    v10 = *(_BYTE *)(a1 + 85) == 0; /*0x10305225f*/
    walChecksumBytes(a1: v10, a2: (unsigned int *)a5, a3: 8, a4: v9, a5: v9); /*0x103052274*/
    walChecksumBytes(a1: v10, a2: a4, a3: *(_DWORD *)(a1 + 56), a4: v9, a5: v9); /*0x103052289*/
    *(_DWORD *)(a5 + 16) = _byteswap_ulong(*(_DWORD *)(a1 + 96)); /*0x103052294*/
    result = _byteswap_ulong(*(_DWORD *)(a1 + 100)); /*0x10305229b*/
    *(_DWORD *)(a5 + 20) = result; /*0x10305229d*/
  }
  return result; /*0x1030522a4*/
}

// Address: 0x1030522af | Name: _walWriteToLog
__int64 __fastcall walWriteToLog(__int64 a1, __int64 a2, unsigned int a3, __int64 a4)
{
  __int64 v4; // rbx
  unsigned int v5; // r14d
  __int64 v6; // r15
  __int64 v8; // r13
  bool v9; // cc
  unsigned int v10; // r13d
  __int64 result; // rax

  v4 = a4; /*0x1030522bd*/
  v5 = a3; /*0x1030522c0*/
  v6 = a2; /*0x1030522c3*/
  v8 = *(_QWORD *)(a1 + 16); /*0x1030522cd*/
  v9 = v8 <= a4; /*0x1030522d0*/
  v10 = v8 - a4; /*0x1030522d0*/
  if ( v9 || a4 + (int)a3 < *(_QWORD *)(a1 + 16) ) /*0x1030522de*/
    return (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD, __int64))(**(_QWORD **)(a1 + 8) + 24LL))( /*0x1030522de*/
             a1: *(_QWORD *)(a1 + 8),
             a2: v6,
             a3: v5,
             a4: v4);
  result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD, __int64))(**(_QWORD **)(a1 + 8) + 24LL))( /*0x103052316*/
             a1: *(_QWORD *)(a1 + 8),
             a2,
             a3: v10,
             a4);
  if ( (_DWORD)result == 0 )
  {
    v5 -= v10; /*0x10305232c*/
    result = (*(_DWORD *)(a1 + 24) & 3) != 0
           ? (*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)(a1 + 8) + 40LL))(a1: *(_QWORD *)(a1 + 8))
           : 0LL;
    if ( v5 != 0 && (_DWORD)result == 0 ) /*0x10305234f*/
    {
      v4 += (int)v10; /*0x103052354*/
      v6 += (int)v10; /*0x103052357*/
      return (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD, __int64))(**(_QWORD **)(a1 + 8) + 24LL))( /*0x1030522e0*/
               a1: *(_QWORD *)(a1 + 8),
               a2: v6,
               a3: v5,
               a4: v4);
    }
  }
  return result; /*0x1030522fa*/
}

// Address: 0x10305717a | Name: _walMerge
void *__fastcall walMerge(__int64 a1, unsigned __int16 *a2, int a3, _QWORD *a4, int *a5, _WORD *a6)
{
  int v6; // r10d
  bool v7; // r15
  bool v8; // r12
  __int64 v9; // rax
  __int64 v10; // rcx
  int v11; // r14d
  int v12; // ebx
  __int64 v13; // r12
  __int64 v14; // r15
  unsigned __int16 *v15; // r15
  __int64 v16; // r11
  int v17; // r15d
  _QWORD *v19; // [rsp+0h] [rbp-30h]

  v6 = *a5; /*0x103057187*/
  v7 = *a5 > 0; /*0x10305718d*/
  v8 = a3 > 0; /*0x103057193*/
  LODWORD(v9) = 0; /*0x10305719d*/
  if ( a3 > 0 || v7 ) /*0x10305719a*/
  {
    v19 = a4; /*0x1030571a9*/
    v10 = *a4; /*0x1030571ad*/
    v9 = 0; /*0x1030571b0*/
    v11 = 0; /*0x1030571b2*/
    v12 = 0; /*0x1030571b5*/
    while ( v8 ) /*0x1030571bb*/
    {
      v13 = v11; /*0x1030571bd*/
      if ( v7 ) /*0x1030571c0*/
      {
        v14 = v12; /*0x1030571cf*/
        if ( *(_DWORD *)(a1 + 4LL * a2[v11]) >= *(_DWORD *)(a1 + 4LL * *(unsigned __int16 *)(v10 + 2LL * v12)) ) /*0x1030571db*/
          goto LABEL_8; /*0x1030571db*/
      }
      ++v11; /*0x1030571dd*/
      v15 = &a2[v13]; /*0x1030571e2*/
LABEL_9:
      v16 = *v15; /*0x1030571f1*/
      v17 = *(_DWORD *)(a1 + 4 * v16); /*0x1030571f5*/
      a6[v9] = v16; /*0x1030571f9*/
      if ( v11 < a3 ) /*0x103057201*/
        v11 += *(_DWORD *)(a1 + 4LL * a2[v11]) == v17; /*0x103057216*/
      v8 = v11 < a3; /*0x10305721c*/
      ++v9; /*0x103057220*/
      v7 = v12 < v6; /*0x103057226*/
      if ( v12 >= v6 && v11 >= a3 ) /*0x10305722f*/
      {
        a4 = v19; /*0x103057231*/
        goto LABEL_14; /*0x103057231*/
      }
    }
    v14 = v12; /*0x1030571e8*/
LABEL_8:
    ++v12; /*0x1030571eb*/
    v15 = (unsigned __int16 *)(v10 + 2 * v14); /*0x1030571ed*/
    goto LABEL_9; /*0x1030571ed*/
  }
LABEL_14:
  *a4 = a2; /*0x103057235*/
  *a5 = v9; /*0x103057238*/
  return memcpy(__dst: a2, __src: a6, __n: (unsigned int)(2 * v9)); /*0x103057246*/
}

// Address: 0x10308fff5 | Name: _walkWindowList
__int64 __fastcall walkWindowList(__int64 a1, _QWORD *a2, int a3)
{
  unsigned int v3; // ebx
  _QWORD *v4; // r15
  _DWORD *v6; // r13
  int v7; // r14d
  _QWORD *v8; // r13
  int v9; // r14d
  _DWORD *v10; // r13
  int v11; // r14d
  _QWORD *v12; // r13
  int v13; // r14d
  int v14; // eax

  v3 = 0; /*0x103090006*/
  if ( a2 != nullptr ) /*0x10309000b*/
  {
    v4 = a2; /*0x103090011*/
    while ( 1 ) /*0x103090017*/
    {
      v6 = (_DWORD *)v4[3]; /*0x103090017*/
      if ( v6 != nullptr ) /*0x10309001e*/
      {
        v7 = *v6; /*0x103090020*/
        if ( (int)*v6 > 0 ) /*0x103090027*/
          break; /*0x103090027*/
      }
LABEL_8:
      v10 = (_DWORD *)v4[2]; /*0x103090051*/
      if ( v10 != nullptr ) /*0x103090058*/
      {
        v11 = *v10; /*0x10309005a*/
        if ( (int)*v10 > 0 ) /*0x103090061*/
        {
          v12 = v10 + 2; /*0x103090063*/
          v13 = v11 + 1; /*0x103090067*/
          while ( (unsigned int)sqlite3WalkExpr(a1, a2: *v12) == 0 ) /*0x103090078*/
          {
            v12 += 3; /*0x10309007a*/
            if ( --v13 <= 1 ) /*0x103090085*/
              goto LABEL_13; /*0x103090085*/
          }
          return 2; /*0x103090078*/
        }
      }
LABEL_13:
      if ( v4[9] != 0 && (unsigned int)sqlite3WalkExprNN(a1) != 0 /*0x1030900af*/
        || v4[5] != 0 && (unsigned int)sqlite3WalkExprNN(a1) != 0 )
      {
        return 2; /*0x1030900af*/
      }
      if ( v4[6] != 0 ) /*0x1030900b8*/
      {
        v14 = sqlite3WalkExprNN(a1); /*0x1030900bd*/
        if ( (a3 | v14) != 0 ) /*0x1030900c7*/
          return 2 * (unsigned int)(v14 != 0); /*0x1030900ff*/
      }
      else if ( a3 != 0 ) /*0x1030900cf*/
      {
        return v3; /*0x1030900cf*/
      }
      v4 = (_QWORD *)v4[8]; /*0x1030900d1*/
      if ( v4 == nullptr ) /*0x1030900d8*/
        return v3; /*0x1030900d8*/
    }
    v8 = v6 + 2; /*0x103090029*/
    v9 = v7 + 1; /*0x10309002d*/
    while ( (unsigned int)sqlite3WalkExpr(a1, a2: *v8) == 0 ) /*0x10309003e*/
    {
      v8 += 3; /*0x103090044*/
      if ( --v9 <= 1 ) /*0x10309004f*/
        goto LABEL_8; /*0x10309004f*/
    }
    return 2; /*0x1030900e0*/
  }
  return v3; /*0x1030900eb*/
}

// Address: 0x1030977cb | Name: _windowFind
__int64 *__fastcall windowFind(int a1, __int64 *a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6)
{
  __int64 *i; // rbx
  __int64 j; // rsi

  if ( a2 != nullptr ) /*0x1030977d4*/
  {
    for ( i = a2; i != nullptr; i = (__int64 *)i[8] ) /*0x1030977d6*/
    {
      a4 = *i; /*0x1030977e0*/
      for ( j = 0; ; ++j ) /*0x1030977e3*/
      {
        a5 = *(unsigned __int8 *)(a4 + j); /*0x1030977e5*/
        a6 = *(unsigned __int8 *)(a3 + j); /*0x1030977ea*/
        if ( (_BYTE)a5 != (_BYTE)a6 ) /*0x1030977f2*/
          break; /*0x1030977f2*/
        if ( *(_BYTE *)(a4 + j) == 0 ) /*0x1030977f7*/
          return i; /*0x1030977f7*/
LABEL_8:
        ; /*0x103097805*/
      }
      LOBYTE(a5) = sqlite3UpperToLower[a5]; /*0x1030977fb*/
      if ( (_BYTE)a5 == sqlite3UpperToLower[a6] ) /*0x103097803*/
        goto LABEL_8; /*0x103097803*/
    }
  }
  i = nullptr; /*0x103097813*/
  sqlite3ErrorMsg(a1, a2: (unsigned int)"no such window: %s", a3, a4, a5, a6);
  return i; /*0x10309782a*/
}

// Address: 0x1030a70d0 | Name: _wherePathSolver
// bad sp value at call has been detected, the output may be wrong!
__int64 __fastcall wherePathSolver(__int64 a1, __int64 a2)
{
  __int64 v2; // r15
  _DWORD *v3; // r14
  unsigned __int64 v4; // rbx
  __int64 v5; // r8
  char v6; // al
  __int64 v7; // rdi
  __int64 v8; // rax
  __int64 v9; // rcx
  unsigned __int64 v10; // rdx
  __int64 v11; // rsi
  _DWORD *v12; // r13
  unsigned __int64 v13; // r12
  __int64 v14; // r8
  __int64 v15; // r11
  int v16; // r9d
  __int64 v17; // rbx
  __int64 v18; // r14
  __int64 v19; // rbx
  __int64 v20; // r10
  unsigned __int64 v21; // r11
  int v22; // r11d
  int v23; // r10d
  __int16 v24; // r9
  __int64 i; // r10
  int *v26; // rax
  int v27; // esi
  __int64 v28; // rsi
  unsigned __int64 v29; // rdx
  char *v30; // rax
  __int64 v31; // rdi
  char *v32; // r12
  char *v33; // rdi
  unsigned int v34; // eax
  char **v35; // rdx
  char v36; // r13
  char *v37; // rdi
  __int16 v38; // ax
  int v39; // r10d
  __int64 v40; // rdx
  __int64 v41; // r9
  __int64 v42; // r8
  __int64 v43; // rcx
  char *v44; // rax
  size_t v45; // rsi
  __int64 v46; // rcx
  char *v47; // r14
  __int64 j; // rbx
  __int64 v49; // r12
  __int64 v50; // r13
  __int16 v51; // cx
  __int16 v52; // r15
  __int16 v53; // ax
  __int16 v54; // cx
  __int16 v55; // r11
  char v56; // di
  __int16 v57; // r15
  char v58; // al
  int v59; // r15d
  __int64 v60; // rdx
  __int64 v61; // rsi
  __int16 v62; // ax
  __int64 v63; // rcx
  int v64; // eax
  __int64 v65; // rdx
  __int64 v66; // rcx
  __int64 v67; // rsi
  __int64 v68; // r8
  __int64 v69; // r9
  __int64 v70; // rax
  __int64 v71; // rdx
  __int16 v72; // ax
  __int16 v73; // r15
  __int64 v74; // rcx
  __int16 v75; // ax
  __int16 v76; // ax
  int v77; // eax
  __int64 v78; // r13
  int v79; // eax
  char *v80; // r12
  int v81; // eax
  unsigned int v82; // r13d
  signed int v83; // r15d
  char v84; // cl
  int v85; // eax
  unsigned __int16 *v86; // rcx
  __int16 v87; // dx
  unsigned int v88; // esi
  char v89; // r13
  __int16 v90; // r15
  int IsNoBetter; // eax
  char *v92; // r8
  __int64 v93; // rax
  __int64 v94; // rcx
  _QWORD *v95; // rdx
  __int64 v96; // rsi
  __int64 v97; // rdi
  __int64 v98; // rdi
  char *v99; // r14
  char v100; // cl
  _DWORD *v101; // rsi
  int v102; // edx
  __int16 v103; // ax
  __int64 v104; // r9
  __int64 v105; // rbx
  __int64 v106; // r9
  int v107; // r8d
  char *v108; // rbx
  char *v110; // r14
  char v111; // al
  __int64 v112; // [rsp+0h] [rbp-100h] BYREF
  size_t __n; // [rsp+8h] [rbp-F8h]
  __int64 v114; // [rsp+10h] [rbp-F0h]
  unsigned __int16 *v115; // [rsp+18h] [rbp-E8h]
  unsigned __int64 v116; // [rsp+20h] [rbp-E0h]
  _DWORD *v117; // [rsp+28h] [rbp-D8h]
  __int64 v118; // [rsp+30h] [rbp-D0h]
  __int64 v119; // [rsp+38h] [rbp-C8h]
  __int64 v120; // [rsp+40h] [rbp-C0h]
  int v121; // [rsp+48h] [rbp-B8h]
  int v122; // [rsp+4Ch] [rbp-B4h]
  int v123; // [rsp+50h] [rbp-B0h]
  int v124; // [rsp+54h] [rbp-ACh]
  char *v125; // [rsp+58h] [rbp-A8h]
  __int64 v126; // [rsp+60h] [rbp-A0h]
  __int64 v127; // [rsp+68h] [rbp-98h]
  __int64 v128; // [rsp+70h] [rbp-90h]
  char *v129; // [rsp+78h] [rbp-88h]
  __int64 v130; // [rsp+80h] [rbp-80h]
  char *v131; // [rsp+88h] [rbp-78h]
  __int64 v132; // [rsp+90h] [rbp-70h]
  __int16 v133; // [rsp+9Ah] [rbp-66h]
  int v134; // [rsp+9Ch] [rbp-64h]
  __int64 v135; // [rsp+A0h] [rbp-60h] BYREF
  int v136; // [rsp+ACh] [rbp-54h]
  __int64 v137; // [rsp+B0h] [rbp-50h]
  __int64 v138; // [rsp+B8h] [rbp-48h]
  int v139; // [rsp+C4h] [rbp-3Ch]
  int v140; // [rsp+C8h] [rbp-38h]
  char v141; // [rsp+CFh] [rbp-31h]

  v132 = a2; /*0x1030a70e4*/
  v2 = a1; /*0x1030a70e8*/
  v3 = *(_DWORD **)a1; /*0x1030a70f9*/
  v4 = *(unsigned __int8 *)(a1 + 64); /*0x1030a70fc*/
  v5 = 1; /*0x1030a7100*/
  v137 = a1; /*0x1030a7109*/
  if ( (unsigned int)v4 >= 2 ) /*0x1030a710d*/
  {
    v5 = 5; /*0x1030a7113*/
    if ( (_DWORD)v4 != 2 ) /*0x1030a711c*/
    {
      v5 = 1; /*0x1030a7127*/
      if ( v3[14] == 0 ) /*0x1030a712d*/
      {
        if ( (unsigned __int8)v4 >= 5u ) /*0x1030a7136*/
        {
          v6 = *(_BYTE *)(a1 + 68); /*0x1030a713c*/
          if ( (v6 & 0x10) == 0 && (*(_BYTE *)(*(_QWORD *)v3 + 99LL) & 0x20) == 0 ) /*0x1030a714f*/
          {
            *(_BYTE *)(a1 + 68) = v6 | 0x10; /*0x1030a7157*/
            v7 = *(_QWORD *)(a1 + 80); /*0x1030a715f*/
            v8 = *(_QWORD *)(v2 + 8) + 8LL; /*0x1030a7163*/
            v9 = 1; /*0x1030a7167*/
            v10 = 0; /*0x1030a716c*/
            v11 = 0; /*0x1030a716e*/
            do /*0x1030a7170*/
            {
              if ( (*(_BYTE *)(v8 + 72 * v10 + 24) & 0x22) != 0 ) /*0x1030a717a*/
              {
                if ( v10 + 4 > v4 ) /*0x1030a7183*/
                  break; /*0x1030a7183*/
                while ( v7 != 0 ) /*0x1030a718c*/
                {
                  if ( *(_BYTE *)(v7 + 16) > (unsigned __int8)v10 ) /*0x1030a7195*/
                    goto LABEL_14; /*0x1030a7195*/
                  v7 = *(_QWORD *)(v7 + 72); /*0x1030a7197*/
                }
              }
              else if ( v7 != 0 ) /*0x1030a71a0*/
              {
LABEL_14:
                v12 = v3; /*0x1030a71a2*/
                v13 = v4; /*0x1030a71a5*/
                v14 = 0; /*0x1030a71ac*/
                v15 = v7; /*0x1030a71af*/
                v16 = 0; /*0x1030a71b2*/
                do /*0x1030a7204*/
                {
                  v17 = *(unsigned __int8 *)(v15 + 16); /*0x1030a71b5*/
                  v18 = 9 * v17; /*0x1030a71ba*/
                  if ( (*(_BYTE *)(v8 + 72 * v17 + 24) & 0x22) != 0 ) /*0x1030a71c4*/
                    break; /*0x1030a71c4*/
                  if ( (v9 & *(_QWORD *)v15) != 0 ) /*0x1030a71c9*/
                  {
                    v19 = *(_QWORD *)(v15 + 8); /*0x1030a71cb*/
                    if ( ((v11 | v14) & v19) != 0 ) /*0x1030a71d8*/
                    {
                      v2 = v137; /*0x1030a71f4*/
                    }
                    else
                    {
                      v2 = v137; /*0x1030a71e6*/
                      if ( *(_QWORD *)(v8 + 8 * v18 + 16) == *(_QWORD *)(v8 + 72 * v10 + 16) ) /*0x1030a71ea*/
                      {
                        v11 |= v9; /*0x1030a71fa*/
                      }
                      else
                      {
                        ++v16; /*0x1030a71ec*/
                        v14 |= v19; /*0x1030a71ef*/
                      }
                    }
                  }
                  v15 = *(_QWORD *)(v15 + 72); /*0x1030a71fd*/
                }
                while ( v15 != 0 ); /*0x1030a7204*/
                if ( v16 >= 4 ) /*0x1030a720a*/
                {
                  *(_BYTE *)(v2 + 68) |= 0x20u; /*0x1030a7218*/
                  LOWORD(v16) = 0x8000; /*0x1030a721d*/
                  v20 = v7; /*0x1030a7222*/
                  v4 = v13; /*0x1030a7225*/
                  v3 = v12; /*0x1030a7228*/
                  do /*0x1030a724d*/
                  {
                    v21 = *(unsigned __int8 *)(v20 + 16); /*0x1030a722b*/
                    if ( v10 <= v21 ) /*0x1030a7233*/
                    {
                      if ( v10 < v21 ) /*0x1030a7235*/
                        break; /*0x1030a7235*/
                      v22 = *(_DWORD *)(v20 + 20); /*0x1030a7237*/
                      if ( (__int16)v22 <= (__int16)v16 ) /*0x1030a723f*/
                        v22 = v16; /*0x1030a723f*/
                      v16 = v22; /*0x1030a7243*/
                    }
                    v20 = *(_QWORD *)(v20 + 72); /*0x1030a7246*/
                  }
                  while ( v20 != 0 ); /*0x1030a724d*/
                  v23 = (unsigned __int16)v16; /*0x1030a724f*/
                  v24 = v16 + 1; /*0x1030a7253*/
                  if ( v23 == 0x7FFF ) /*0x1030a725d*/
                    v24 = 0x7FFF; /*0x1030a725d*/
                  for ( i = v7; i != 0; i = *(_QWORD *)(i + 72) ) /*0x1030a7261*/
                  {
                    if ( (v14 & *(_QWORD *)(i + 8)) != 0 && *(_WORD *)(i + 52) == 0 && *(__int16 *)(i + 20) < v24 ) /*0x1030a7277*/
                      *(_WORD *)(i + 20) = v24; /*0x1030a7279*/
                  }
                }
                else
                {
                  v4 = v13; /*0x1030a720c*/
                  v3 = v12; /*0x1030a720f*/
                }
                goto LABEL_41; /*0x1030a7212*/
              }
              v7 = 0; /*0x1030a7214*/
LABEL_41:
              ++v10; /*0x1030a7287*/
              v9 *= 2; /*0x1030a728a*/
            }
            while ( v10 != v4 ); /*0x1030a7170*/
          }
        }
        v5 = 18; /*0x1030a7296*/
        if ( (*(_BYTE *)(v2 + 68) & 0x20) == 0 ) /*0x1030a72a6*/
          v5 = 12; /*0x1030a72a6*/
      }
    }
  }
  v26 = *(int **)(v2 + 16); /*0x1030a72aa*/
  v27 = 0; /*0x1030a72bc*/
  if ( v26 != nullptr && (_WORD)v132 != 0 ) /*0x1030a72b9*/
    v27 = *v26; /*0x1030a72c2*/
  v134 = v27; /*0x1030a72d0*/
  v28 = 2LL * v27; /*0x1030a72d6*/
  v29 = ((int)v28 + (int)v5 * (16 * (int)v4 + 64) + 15LL) & 0xFFFFFFFFFFFFFFF0LL; /*0x1030a72e2*/
  v30 = (char *)&v112 - v29; /*0x1030a72ec*/
  v31 = (unsigned int)(32 * v5); /*0x1030a72f5*/
  *(_OWORD *)&v30[v31 + 16] = 0; /*0x1030a72ff*/
  v129 = (char *)&v112 - v29; /*0x1030a7304*/
  *(_OWORD *)&v30[v31] = 0; /*0x1030a730b*/
  v32 = (char *)&v112 + v31 - v29; /*0x1030a730f*/
  v33 = &v32[v31]; /*0x1030a7312*/
  v34 = 2 * v5 + 1; /*0x1030a7315*/
  v35 = (char **)((char *)&v112 - v29 + 24); /*0x1030a732a*/
  do /*0x1030a733d*/
  {
    *v35 = v33; /*0x1030a732e*/
    --v34; /*0x1030a7331*/
    v33 += (unsigned int)(8 * v4); /*0x1030a7333*/
    v35 += 4; /*0x1030a7336*/
  }
  while ( v34 > 1 ); /*0x1030a733d*/
  v126 = v5; /*0x1030a733f*/
  v36 = v134; /*0x1030a7346*/
  if ( v134 != 0 )
  {
    v125 = v33; /*0x1030a734f*/
    __bzero(a1: v33, a2: v28); /*0x1030a7356*/
    v37 = v32; /*0x1030a735b*/
    v38 = 48; /*0x1030a7366*/
    if ( (__int16)v3[7] < 48 ) /*0x1030a736b*/
      v38 = v3[7]; /*0x1030a736b*/
    v32[22] = v4 != 0 ? -1 : v36;
  }
  else
  {
    v38 = 48; /*0x1030a738a*/
    if ( (__int16)v3[7] < 48 ) /*0x1030a738f*/
      v38 = v3[7]; /*0x1030a738f*/
    v125 = nullptr; /*0x1030a7392*/
    v37 = v32; /*0x1030a739d*/
  }
  *((_WORD *)v37 + 8) = v38; /*0x1030a73a0*/
  if ( (_DWORD)v4 == 0 ) /*0x1030a73a6*/
  {
LABEL_139:
    if ( (*(_WORD *)(v2 + 60) & 0x180) == 0x100 && (_WORD)v132 != 0 && *(_BYTE *)(v2 + 67) == 0 ) /*0x1030a79cb*/
    {
      v99 = v37; /*0x1030a79f0*/
      if ( **(_DWORD **)(v2 + 24) == (char)wherePathSatisfiesOrderBy( /*0x1030a7a0c*/
                                             a1: v2,
                                             a2: *(_QWORD *)(v2 + 24),
                                             a3: (_DWORD)v37,
                                             a4: 128,
                                             a5: (unsigned __int16)(v4 - 1),
                                             a6: *(_QWORD *)(*((_QWORD *)v37 + 3) + 8 * v4 - 8),
                                             a7: (__int64)&v135) )
        *(_BYTE *)(v2 + 67) = 2; /*0x1030a7a0e*/
      v37 = v99; /*0x1030a7a13*/
    }
    v100 = *(_BYTE *)(v2 + 68); /*0x1030a7a16*/
    *(_BYTE *)(v2 + 68) = v100 & 0xFB; /*0x1030a7a1e*/
    v101 = *(_DWORD **)(v2 + 16); /*0x1030a7a22*/
    if ( v101 != nullptr ) /*0x1030a7a29*/
    {
      v102 = v37[22]; /*0x1030a7a2f*/
      *(_BYTE *)(v2 + 65) = v37[22]; /*0x1030a7a33*/
      v103 = *(_WORD *)(v2 + 60); /*0x1030a7a37*/
      if ( (v103 & 0x80u) != 0 ) /*0x1030a7a3e*/
      {
        if ( *v101 == v102 ) /*0x1030a7a8a*/
          *(_BYTE *)(v2 + 67) = 2; /*0x1030a7a8c*/
      }
      else
      {
        *(_QWORD *)(v2 + 96) = *((_QWORD *)v37 + 1); /*0x1030a7a47*/
        if ( (char)v102 <= 0 ) /*0x1030a7a4d*/
        {
          *(_BYTE *)(v2 + 65) = 0; /*0x1030a7a93*/
          if ( (_BYTE)v4 != 0 ) /*0x1030a7a9a*/
          {
            v104 = *(_QWORD *)(*((_QWORD *)v37 + 3) + 8LL * (unsigned int)(v4 - 1)); /*0x1030a7aa6*/
            if ( (*(_DWORD *)(v104 + 48) & 0x1000) == 0 && (~*(_DWORD *)(v104 + 48) & 0x104) != 0 ) /*0x1030a7ac1*/
            {
              v135 = 0; /*0x1030a7b63*/
              v110 = v37; /*0x1030a7b75*/
              v111 = wherePathSatisfiesOrderBy( /*0x1030a7b7e*/
                       a1: v2,
                       a2: (_DWORD)v101,
                       a3: (_DWORD)v37,
                       a4: 2048,
                       a5: (unsigned __int16)(v4 - 1),
                       a6: v104,
                       a7: (__int64)&v135);
              v101 = *(_DWORD **)(v2 + 16); /*0x1030a7b8a*/
              if ( *v101 == v111 ) /*0x1030a7b90*/
              {
                *(_BYTE *)(v2 + 68) |= 4u; /*0x1030a7b92*/
                *(_QWORD *)(v2 + 96) = v135; /*0x1030a7b9b*/
              }
              v103 = *(_WORD *)(v2 + 60); /*0x1030a7b9f*/
              v37 = v110; /*0x1030a7ba4*/
            }
          }
        }
        else if ( (_BYTE)v102 == 1 && (_BYTE)v4 != 0 && (v103 & 3) != 0 ) /*0x1030a7a5d*/
        {
          *(_BYTE *)(v2 + 68) = v100 | 4; /*0x1030a7a6c*/
        }
      }
      if ( (v103 & 0x200) != 0 && v4 != 0 && *v101 == *(char *)(v2 + 65) ) /*0x1030a7ae8*/
      {
        v135 = 0; /*0x1030a7aee*/
        v105 = (unsigned int)(v4 - 1); /*0x1030a7af5*/
        v106 = *(_QWORD *)(*((_QWORD *)v37 + 3) + 8 * v105); /*0x1030a7afb*/
        v107 = (unsigned __int16)v105; /*0x1030a7b03*/
        v108 = v37; /*0x1030a7b0d*/
        if ( **(_DWORD **)(v2 + 16) == (char)wherePathSatisfiesOrderBy( /*0x1030a7b25*/
                                               a1: v2,
                                               a2: (_DWORD)v101,
                                               a3: (_DWORD)v37,
                                               a4: 0,
                                               a5: v107,
                                               a6: v106,
                                               a7: (__int64)&v135) )
        {
          *(_BYTE *)(v2 + 68) |= 8u; /*0x1030a7b27*/
          *(_QWORD *)(v2 + 96) = v135; /*0x1030a7b30*/
        }
        v37 = v108; /*0x1030a7b34*/
      }
    }
    *(_WORD *)(v2 + 70) = *((_WORD *)v37 + 8); /*0x1030a7b3b*/
    return __stack_chk_guard; /*0x1030a7b3b*/
  }
  v124 = v132 - 10; /*0x1030a73b3*/
  v118 = -(__int64)(unsigned int)(v4 - 1); /*0x1030a73bf*/
  v120 = -(__int64)v4; /*0x1030a73cc*/
  v39 = 1; /*0x1030a73d3*/
  v40 = 0; /*0x1030a73d9*/
  v139 = 0; /*0x1030a73db*/
  v41 = 0; /*0x1030a73e2*/
  v42 = 0; /*0x1030a73e5*/
  do /*0x1030a795e*/
  {
    v43 = 8 * v40++; /*0x1030a73f0*/
    v44 = v129; /*0x1030a73f6*/
    v129 = v37; /*0x1030a73fd*/
    v45 = v43; /*0x1030a7404*/
    while ( 1 ) /*0x1030a7407*/
    {
      v37 = v44; /*0x1030a7407*/
      if ( v39 > 0 ) /*0x1030a740d*/
        break; /*0x1030a740d*/
      v45 += 8LL; /*0x1030a740f*/
      v46 = v120 + v40++ + 1; /*0x1030a741e*/
      v39 = 0; /*0x1030a7424*/
      v44 = v129; /*0x1030a7427*/
      v129 = v37; /*0x1030a742e*/
      if ( v46 == 1 ) /*0x1030a7439*/
        goto LABEL_150; /*0x1030a7439*/
    }
    v122 = v39; /*0x1030a7440*/
    __n = v45; /*0x1030a7447*/
    v117 = v3; /*0x1030a744e*/
    v116 = v4; /*0x1030a7455*/
    v115 = (unsigned __int16 *)(v44 + 52); /*0x1030a746f*/
    LODWORD(v46) = 0; /*0x1030a7476*/
    v123 = (unsigned __int16)(v40 - 1); /*0x1030a747b*/
    v47 = v129; /*0x1030a7481*/
    v39 = 0; /*0x1030a7488*/
    v131 = v44; /*0x1030a748b*/
    v138 = v40; /*0x1030a748f*/
    v119 = v118 + v40; /*0x1030a7493*/
    do /*0x1030a7940*/
    {
      v121 = v46; /*0x1030a749a*/
      for ( j = *(_QWORD *)(v2 + 80); j != 0; j = *(_QWORD *)(j + 72) ) /*0x1030a74a0*/
      {
        v49 = *(_QWORD *)v47; /*0x1030a74ad*/
        if ( (~*(_QWORD *)v47 & *(_QWORD *)j) != 0 ) /*0x1030a74b9*/
          continue; /*0x1030a74b9*/
        v50 = *(_QWORD *)(j + 8); /*0x1030a74bf*/
        if ( (v49 & v50) != 0 ) /*0x1030a74c6*/
          continue; /*0x1030a74c6*/
        v51 = *((_WORD *)v47 + 8); /*0x1030a74d0*/
        if ( (*(_BYTE *)(j + 49) & 0x40) != 0 && v51 < 3 ) /*0x1030a74db*/
          continue; /*0x1030a74db*/
        v136 = v39; /*0x1030a74e1*/
        v128 = v41; /*0x1030a74e5*/
        v127 = v42; /*0x1030a74ec*/
        v52 = v51; /*0x1030a74f7*/
        v53 = v51 + *(_WORD *)(j + 20); /*0x1030a74fa*/
        v54 = *(_WORD *)(j + 18); /*0x1030a74fd*/
        if ( v54 != 0 ) /*0x1030a7504*/
          v53 = sqlite3LogEstAdd(a1: (unsigned int)v54, a2: (unsigned int)v53); /*0x1030a750c*/
        v140 = sqlite3LogEstAdd(a1: (unsigned int)v53, a2: (unsigned int)*((__int16 *)v47 + 10)); /*0x1030a751e*/
        v55 = *(_WORD *)(j + 22) + v52; /*0x1030a7524*/
        v56 = v47[22]; /*0x1030a7529*/
        if ( v56 < 0 ) /*0x1030a7530*/
        {
          v135 = 0; /*0x1030a753c*/
          v57 = v55; /*0x1030a7554*/
          v58 = wherePathSatisfiesOrderBy( /*0x1030a7569*/
                  a1: v137,
                  a2: *(_QWORD *)(v137 + 16),
                  a3: (_DWORD)v47,
                  a4: *(unsigned __int16 *)(v137 + 60),
                  a5: v123,
                  a6: j,
                  a7: (__int64)&v135);
          v55 = v57; /*0x1030a756e*/
          v56 = v58; /*0x1030a7575*/
        }
        else
        {
          v135 = *((_QWORD *)v47 + 1); /*0x1030a7536*/
        }
        v59 = v134 - v56; /*0x1030a7584*/
        v60 = v126; /*0x1030a7592*/
        v42 = v127; /*0x1030a7599*/
        v41 = v128; /*0x1030a75a0*/
        v39 = v136; /*0x1030a75a7*/
        v61 = v119; /*0x1030a75ab*/
        v141 = v56; /*0x1030a75b2*/
        if ( v56 >= 0 && v134 > v56 ) /*0x1030a7587*/
        {
          v133 = v55; /*0x1030a75bc*/
          v62 = *(_WORD *)&v125[2 * (unsigned __int8)v56]; /*0x1030a75cc*/
          if ( v62 == 0 ) /*0x1030a75d3*/
          {
            v130 = (unsigned __int8)v56; /*0x1030a75d9*/
            v63 = (unsigned int)(((unsigned __int64)(-2004318071LL * (**(_DWORD **)(*(_QWORD *)(v137 + 32) + 32LL) + 59)) >> 32) /*0x1030a7605*/
                               + **(_DWORD **)(*(_QWORD *)(v137 + 32) + 32LL)
                               + 59) >> 31;
            v64 = sqlite3LogEst( /*0x1030a7610*/
                    a1: (int)v63
                  + ((int)(((unsigned __int64)(-2004318071LL * (**(_DWORD **)(*(_QWORD *)(v137 + 32) + 32LL) + 59)) >> 32)
                         + **(_DWORD **)(*(_QWORD *)(v137 + 32) + 32LL)
                         + 59) >> 4),
                    a2: v119,
                    a3: v126,
                    a4: v63,
                    a5: v127,
                    a6: v128);
            v70 = (unsigned int)(v132 + v64); /*0x1030a7615*/
            if ( v141 != 0 ) /*0x1030a761c*/
            {
              v114 = v70; /*0x1030a761e*/
              v71 = (unsigned int)((100 * v59) >> 31); /*0x1030a7629*/
              LODWORD(v71) = 100 * v59 % v134; /*0x1030a762a*/
              v72 = sqlite3LogEst(a1: 100 * v59 / v134, a2: v67, a3: v71, a4: v66, a5: v68, a6: v69); /*0x1030a7630*/
              v73 = v72 + v114 - 66; /*0x1030a763f*/
            }
            else
            {
              v73 = v70; /*0x1030a765b*/
            }
            if ( (*(_WORD *)(v137 + 60) & 0x4000) != 0 ) /*0x1030a766a*/
            {
              v76 = v73 + 16; /*0x1030a7687*/
              v73 += 10; /*0x1030a768b*/
              if ( v141 != 0 ) /*0x1030a7693*/
                v73 = v76; /*0x1030a7693*/
              v75 = *(_WORD *)(v137 + 62); /*0x1030a7697*/
              v74 = v132; /*0x1030a769b*/
              if ( v75 >= (__int16)v132 ) /*0x1030a76a2*/
                v75 = v132; /*0x1030a76a2*/
            }
            else
            {
              v74 = v132; /*0x1030a7671*/
              v75 = v132; /*0x1030a7675*/
              if ( (*(_WORD *)(v137 + 60) & 0x100) != 0 ) /*0x1030a7677*/
                v75 = v124; /*0x1030a7677*/
              if ( (__int16)v132 < 11 ) /*0x1030a7682*/
                v75 = v132; /*0x1030a7682*/
            }
            if ( v75 >= 11 ) /*0x1030a76a9*/
              v77 = sqlite3LogEst(a1: (unsigned __int16)v75, a2: v67, a3: v65, a4: v74, a5: v68, a6: v69) - 33; /*0x1030a76b7*/
            else
              LOWORD(v77) = 0; /*0x1030a76ab*/
            v62 = v73 + v77; /*0x1030a76ba*/
            *(_WORD *)&v125[2 * v130] = v62; /*0x1030a76c8*/
          }
          LODWORD(v130) = sqlite3LogEstAdd(a1: (unsigned int)(__int16)v140, a2: (unsigned int)v62) + 3; /*0x1030a76db*/
          v37 = v131; /*0x1030a76de*/
          v60 = v126; /*0x1030a76e2*/
          v42 = v127; /*0x1030a76e9*/
          v41 = v128; /*0x1030a76f0*/
          v39 = v136; /*0x1030a76f7*/
          v61 = v119; /*0x1030a76fb*/
          v55 = v133; /*0x1030a7702*/
        }
        else
        {
          LODWORD(v130) = v140; /*0x1030a764a*/
          v140 -= 2; /*0x1030a7650*/
          v37 = v131; /*0x1030a7653*/
        }
        v2 = v137; /*0x1030a770a*/
        if ( v39 <= 0 ) /*0x1030a770e*/
        {
LABEL_100:
          v81 = v39; /*0x1030a773f*/
          if ( v39 >= (int)v60 ) /*0x1030a7745*/
          {
            if ( (__int16)v130 > (__int16)v41 ) /*0x1030a77e5*/
              goto LABEL_121; /*0x1030a77e5*/
            v81 = v139; /*0x1030a77eb*/
            if ( (_WORD)v130 == (_WORD)v41 ) /*0x1030a77ee*/
            {
              v81 = v139; /*0x1030a77f4*/
              if ( (__int16)v140 >= (__int16)v42 ) /*0x1030a77fc*/
                goto LABEL_121; /*0x1030a77fc*/
            }
          }
          v39 += v39 < (int)v60; /*0x1030a7753*/
          v80 = &v37[32 * v81]; /*0x1030a775d*/
        }
        else
        {
          v78 = v49 | v50; /*0x1030a7710*/
          v79 = v39; /*0x1030a7713*/
          v80 = v37; /*0x1030a7716*/
          while ( *(_QWORD *)v80 != v78 || ((v141 ^ v80[22]) & 0x80u) != 0 && v61 != 1 ) /*0x1030a7731*/
          {
            v80 += 32; /*0x1030a7737*/
            if ( --v79 == 0 ) /*0x1030a773d*/
              goto LABEL_100; /*0x1030a773d*/
          }
          if ( *((__int16 *)v80 + 9) < (__int16)v130 ) /*0x1030a7879*/
          {
LABEL_121:
            v40 = v138; /*0x1030a787b*/
            continue; /*0x1030a787b*/
          }
          if ( *((_WORD *)v80 + 9) == (_WORD)v130 ) /*0x1030a7888*/
          {
            v84 = v141; /*0x1030a7894*/
            if ( *((__int16 *)v80 + 8) < v55 ) /*0x1030a7897*/
              goto LABEL_121; /*0x1030a7897*/
            if ( *((_WORD *)v80 + 8) == v55 ) /*0x1030a7899*/
            {
              if ( *((__int16 *)v80 + 10) < (__int16)v140 ) /*0x1030a78a4*/
              {
                v37 = v131; /*0x1030a78a6*/
                v40 = v138; /*0x1030a78aa*/
                v42 = v127; /*0x1030a78ae*/
                v41 = v128; /*0x1030a78b5*/
                continue; /*0x1030a78bc*/
              }
              if ( *((_WORD *)v80 + 10) == (_WORD)v140 ) /*0x1030a78c9*/
              {
                v89 = v141; /*0x1030a78d0*/
                v90 = v55; /*0x1030a78dc*/
                IsNoBetter = whereLoopIsNoBetter(a1: j, a2: *(_QWORD *)(*((_QWORD *)v80 + 3) + 8 * v138 - 8), a3: v60); /*0x1030a78e2*/
                v84 = v89; /*0x1030a78e7*/
                v55 = v90; /*0x1030a78ea*/
                v82 = v126; /*0x1030a78ef*/
                v83 = v136; /*0x1030a78f6*/
                if ( IsNoBetter != 0 ) /*0x1030a78fa*/
                {
                  v37 = v131; /*0x1030a7900*/
                  v40 = v138; /*0x1030a7904*/
                  v42 = v127; /*0x1030a7908*/
                  v41 = v128; /*0x1030a790f*/
                  v39 = v136; /*0x1030a7916*/
                  goto LABEL_105; /*0x1030a7919*/
                }
              }
              else
              {
                v82 = v126; /*0x1030a791e*/
                v83 = v136; /*0x1030a7925*/
              }
            }
            else
            {
              v82 = v60; /*0x1030a78be*/
              v83 = v39; /*0x1030a78c1*/
            }
            goto LABEL_103; /*0x1030a78fa*/
          }
        }
        v82 = v60; /*0x1030a7760*/
        v83 = v39; /*0x1030a7763*/
        v84 = v141; /*0x1030a7766*/
LABEL_103:
        *(_QWORD *)v80 = *(_QWORD *)v47 | *(_QWORD *)(j + 8); /*0x1030a7769*/
        *((_QWORD *)v80 + 1) = v135; /*0x1030a7778*/
        *((_WORD *)v80 + 8) = v55; /*0x1030a777d*/
        *((_WORD *)v80 + 9) = v130; /*0x1030a7786*/
        *((_WORD *)v80 + 10) = v140; /*0x1030a778f*/
        v80[22] = v84; /*0x1030a7795*/
        memcpy(__dst: *((void **)v80 + 3), __src: *((const void **)v47 + 3), __n); /*0x1030a77aa*/
        v40 = v138; /*0x1030a77b4*/
        *(_QWORD *)(*((_QWORD *)v80 + 3) + 8 * v138 - 8) = j; /*0x1030a77b8*/
        v39 = v83; /*0x1030a77c0*/
        if ( v83 < (int)v82 ) /*0x1030a77c3*/
        {
          v37 = v131; /*0x1030a77c5*/
          v42 = v127; /*0x1030a77c9*/
          v41 = v128; /*0x1030a77d0*/
LABEL_105:
          v2 = v137; /*0x1030a77d7*/
          continue; /*0x1030a77db*/
        }
        v139 = 0; /*0x1030a7806*/
        v42 = *((unsigned __int16 *)v131 + 8); /*0x1030a7811*/
        v41 = *((unsigned __int16 *)v131 + 9); /*0x1030a7819*/
        v2 = v137; /*0x1030a7821*/
        if ( v82 < 2 ) /*0x1030a7825*/
          goto LABEL_119; /*0x1030a7825*/
        v139 = 0; /*0x1030a7827*/
        v85 = 1; /*0x1030a782e*/
        v86 = v115; /*0x1030a7833*/
        do /*0x1030a7865*/
        {
          v87 = *(v86 - 1); /*0x1030a783a*/
          if ( v87 > (__int16)v41 ) /*0x1030a7842*/
          {
            v88 = *v86; /*0x1030a7844*/
LABEL_114:
            v42 = v88; /*0x1030a7847*/
            v41 = *(v86 - 1); /*0x1030a784a*/
            v139 = v85; /*0x1030a784d*/
            goto LABEL_117; /*0x1030a7850*/
          }
          if ( v87 == (_WORD)v41 ) /*0x1030a7852*/
          {
            v88 = *v86; /*0x1030a7854*/
            if ( (__int16)v88 > (__int16)v42 ) /*0x1030a785b*/
              goto LABEL_114; /*0x1030a785b*/
          }
LABEL_117:
          ++v85; /*0x1030a785d*/
          v86 += 16; /*0x1030a785f*/
        }
        while ( v82 != v85 ); /*0x1030a7865*/
        v40 = v138; /*0x1030a7867*/
LABEL_119:
        v37 = v131; /*0x1030a786b*/
      }
      LODWORD(v46) = v121 + 1; /*0x1030a7934*/
      v47 += 32; /*0x1030a7936*/
    }
    while ( v121 + 1 != v122 ); /*0x1030a7940*/
    v4 = v116; /*0x1030a7950*/
    v3 = v117; /*0x1030a7957*/
  }
  while ( v40 + v120 != 0 ); /*0x1030a795e*/
  if ( v39 != 0 ) /*0x1030a7967*/
  {
    v92 = v37; /*0x1030a796d*/
    v93 = *((_QWORD *)v37 + 3); /*0x1030a7970*/
    v94 = *(_QWORD *)(v2 + 8) + 8LL; /*0x1030a7978*/
    v95 = (_QWORD *)(v2 + 952); /*0x1030a797c*/
    v96 = 0; /*0x1030a7983*/
    do /*0x1030a79a9*/
    {
      v97 = *(_QWORD *)(v93 + 8 * v96); /*0x1030a7985*/
      *v95 = v97; /*0x1030a7989*/
      v98 = *(unsigned __int8 *)(v97 + 16); /*0x1030a798c*/
      *((_BYTE *)v95 - 32) = v98; /*0x1030a7990*/
      *((_DWORD *)v95 - 23) = *(_DWORD *)(v94 + 72 * v98 + 28); /*0x1030a799c*/
      ++v96; /*0x1030a799f*/
      v95 += 14; /*0x1030a79a2*/
    }
    while ( v4 != v96 ); /*0x1030a79a9*/
    v37 = v92; /*0x1030a79ab*/
    goto LABEL_139; /*0x1030a79ab*/
  }
LABEL_150:
  sqlite3ErrorMsg(a1: (_DWORD)v3, a2: (unsigned int)"no query solution", a3: v40, a4: v46, a5: v42, a6: v41); /*0x1030a7a72*/
  return __stack_chk_guard; /*0x1030a7b50*/
}

// Address: 0x1030a7bb1 | Name: _whereInterstageHeuristic
void __fastcall whereInterstageHeuristic(__int64 a1)
{
  unsigned __int8 v1; // dl
  unsigned __int64 i; // rcx
  __int64 v3; // r8
  int v4; // esi
  __int64 v5; // rsi
  char v6; // dl

  v1 = *(_BYTE *)(a1 + 64); /*0x1030a7bb1*/
  if ( v1 != 0 ) /*0x1030a7bb6*/
  {
    for ( i = 0; i < v1; ++i ) /*0x1030a7bc3*/
    {
      v3 = *(_QWORD *)(a1 + 856 + 112 * i + 96); /*0x1030a7bc9*/
      if ( v3 == 0 ) /*0x1030a7bd1*/
        break; /*0x1030a7bd1*/
      v4 = *(_DWORD *)(v3 + 48); /*0x1030a7bd3*/
      if ( (v4 & 0x400) != 0 || (v4 & 0xD) == 0 ) /*0x1030a7be0*/
        break; /*0x1030a7be0*/
      v5 = *(_QWORD *)(a1 + 80); /*0x1030a7be2*/
      if ( v5 != 0 ) /*0x1030a7be9*/
      {
        v6 = *(_BYTE *)(v3 + 16); /*0x1030a7beb*/
        do /*0x1030a7c10*/
        {
          if ( *(_BYTE *)(v5 + 16) == v6 && (*(_WORD *)(v5 + 48) & 0x400F) == 0 ) /*0x1030a7c00*/
            *(_QWORD *)v5 = -1; /*0x1030a7c02*/
          v5 = *(_QWORD *)(v5 + 72); /*0x1030a7c09*/
        }
        while ( v5 != 0 ); /*0x1030a7c10*/
        v1 = *(_BYTE *)(a1 + 64); /*0x1030a7c12*/
      }
    }
  }
}

// Address: 0x1030a7c22 | Name: _whereReverseScanOrder
int *__fastcall whereReverseScanOrder(__int64 a1)
{
  int *result; // rax
  __int64 v2; // rdx
  __int64 i; // rcx
  __int16 v4; // si

  result = *(int **)(a1 + 8); /*0x1030a7c26*/
  v2 = *result; /*0x1030a7c2a*/
  if ( v2 > 0 ) /*0x1030a7c30*/
  {
    result += 18; /*0x1030a7c32*/
    for ( i = 0; i != v2; ++i ) /*0x1030a7c36*/
    {
      v4 = *(_WORD *)((char *)result - 39); /*0x1030a7c38*/
      if ( (v4 & 0x200) == 0 /*0x1030a7c77*/
        || (v4 & 4) == 0
        || *(_BYTE *)(*((_QWORD *)result - 2) + 18LL) != 0
        || *(_QWORD *)(**(_QWORD **)result + 72LL) == 0 )
      {
        *(_QWORD *)(a1 + 96) |= 1LL << i; /*0x1030a7c4a*/
      }
      result += 18; /*0x1030a7c51*/
    }
  }
  return result; /*0x1030a7c7b*/
}

// Address: 0x1030a7c7d | Name: _whereOmitNoopJoin
__int64 __fastcall whereOmitNoopJoin(__int64 a1)
{
  __int64 v2; // r15
  __int64 v3; // r12
  __int64 v4; // rsi
  unsigned __int64 v5; // r14
  __int64 result; // rax
  char v7; // r13
  __int64 v8; // rsi
  __int64 v9; // r15
  __int64 v10; // rdx
  __int64 v11; // r10
  __int64 v12; // rcx
  __int64 v13; // r11
  __int64 v14; // rcx
  unsigned __int64 v15; // rsi
  __int64 v16; // r9
  unsigned __int64 v17; // r8
  __int64 v18; // r10
  _QWORD *v19; // r11
  __int64 v20; // r12
  unsigned __int8 v21; // cl
  __int64 v22; // [rsp+8h] [rbp-48h]
  __int64 v23; // [rsp+10h] [rbp-40h]
  unsigned __int8 v24; // [rsp+27h] [rbp-29h]

  v2 = a1 + 592; /*0x1030a7c91*/
  v3 = sqlite3WhereExprListUsage(a1: a1 + 592, a2: *(_QWORD *)(a1 + 24)); /*0x1030a7ca4*/
  v4 = *(_QWORD *)(a1 + 16); /*0x1030a7ca7*/
  if ( v4 != 0 ) /*0x1030a7cae*/
    v3 |= sqlite3WhereExprListUsage(a1: v2, a2: v4); /*0x1030a7cb8*/
  v5 = *(unsigned __int8 *)(a1 + 64); /*0x1030a7cbb*/
  result = -1; /*0x1030a7cc0*/
  if ( v5 >= 2 ) /*0x1030a7ccb*/
  {
    v7 = *(_BYTE *)(*(_QWORD *)(a1 + 8) + 32LL); /*0x1030a7cd5*/
    v8 = a1 + 856; /*0x1030a7cd9*/
    result = -1; /*0x1030a7ce0*/
    v24 = *(_BYTE *)(a1 + 64); /*0x1030a7ce7*/
    v23 = v3; /*0x1030a7ceb*/
    do /*0x1030a7e4c*/
    {
      v9 = v5--; /*0x1030a7cf3*/
      v10 = *(_QWORD *)(v8 + 112 * v5 + 96); /*0x1030a7cfd*/
      v11 = *(_QWORD *)(a1 + 8); /*0x1030a7d02*/
      v12 = *(unsigned __int8 *)(v10 + 16); /*0x1030a7d06*/
      v13 = 9 * v12; /*0x1030a7d0a*/
      if ( (*(_BYTE *)(v11 + 72 * v12 + 32) & 0x18) == 8 /*0x1030a7d29*/
        && ((*(_BYTE *)(a1 + 61) & 1) != 0 || (*(_BYTE *)(v10 + 49) & 0x10) != 0) )
      {
        v14 = *(_QWORD *)(v10 + 8); /*0x1030a7d2f*/
        if ( (v3 & v14) == 0 ) /*0x1030a7d36*/
        {
          v22 = result; /*0x1030a7d3c*/
          v15 = *(_QWORD *)(a1 + 136); /*0x1030a7d40*/
          v16 = *(int *)(a1 + 124); /*0x1030a7d47*/
          v17 = v15 + 56 * v16; /*0x1030a7d4f*/
          if ( v16 <= 0 ) /*0x1030a7d55*/
          {
LABEL_18:
            *(_QWORD *)(a1 + 96) ^= (*(_QWORD *)(a1 + 96) ^ (*(_QWORD *)(a1 + 96) >> 1)) >> v5 << v5; /*0x1030a7daf*/
            v20 = *(_QWORD *)(v10 + 8); /*0x1030a7dcc*/
            if ( (int)v16 > 0 ) /*0x1030a7dd3*/
            {
              do /*0x1030a7de6*/
              {
                if ( (v20 & *(_QWORD *)(v15 + 48)) != 0 ) /*0x1030a7dd9*/
                  *(_BYTE *)(v15 + 18) |= 4u; /*0x1030a7ddb*/
                v15 += 56LL; /*0x1030a7ddf*/
              }
              while ( v15 < v17 ); /*0x1030a7de6*/
              v24 = *(_BYTE *)(a1 + 64); /*0x1030a7deb*/
            }
            v21 = v24; /*0x1030a7dee*/
            if ( v24 != v9 ) /*0x1030a7df7*/
            {
              memmove( /*0x1030a7e1c*/
                __dst: (void *)(a1 + 856 + 112 * v5),
                __src: (const void *)(a1 + 856 + 112 * v9),
                __len: 112 * (v24 - (int)v9));
              v21 = *(_BYTE *)(a1 + 64); /*0x1030a7e21*/
            }
            result = ~v20 & v22; /*0x1030a7e2b*/
            v24 = v21 - 1; /*0x1030a7e30*/
            *(_BYTE *)(a1 + 64) = v21 - 1; /*0x1030a7e33*/
            v3 = v23; /*0x1030a7e36*/
          }
          else
          {
            v18 = v11 + 8 * v13 + 8; /*0x1030a7d5b*/
            v19 = *(_QWORD **)(a1 + 136); /*0x1030a7d5f*/
            while ( ((v14 & v19[6]) == 0 /*0x1030a7da0*/
                  || (*(_BYTE *)(*v19 + 4LL) & 1) != 0 && *(_DWORD *)(*v19 + 48LL) == *(_DWORD *)(v18 + 28))
                 && ((v7 & 0x40) == 0
                  || (*(_BYTE *)(*v19 + 4LL) & 2) == 0
                  || *(_DWORD *)(*v19 + 48LL) != *(_DWORD *)(v18 + 28)) )
            {
              v19 += 7; /*0x1030a7da6*/
              if ( (unsigned __int64)v19 >= v17 ) /*0x1030a7dad*/
                goto LABEL_18; /*0x1030a7dad*/
            }
            v3 = v23; /*0x1030a7e3c*/
          }
          v8 = a1 + 856; /*0x1030a7e44*/
        }
      }
    }
    while ( v9 > 2 ); /*0x1030a7e4c*/
  }
  return result; /*0x1030a7e52*/
}

// Address: 0x1030a7e61 | Name: _whereCheckIfBloomFilterIsUseful
void __fastcall whereCheckIfBloomFilterIsUseful(__int64 a1)
{
  __int64 v1; // rax
  __int64 *v2; // rcx
  unsigned __int64 v3; // rdx
  __int16 v4; // si
  __int64 v5; // r8
  __int64 v6; // r9
  int v7; // r10d
  int v8; // r10d

  if ( *(_BYTE *)(a1 + 64) != 0 ) /*0x1030a7e65*/
  {
    v1 = *(_QWORD *)(a1 + 8) + 8LL; /*0x1030a7e74*/
    v2 = (__int64 *)(a1 + 952); /*0x1030a7e78*/
    v3 = 0; /*0x1030a7e7f*/
    v4 = 0; /*0x1030a7e81*/
    do /*0x1030a7eff*/
    {
      v5 = *v2; /*0x1030a7e83*/
      v6 = *(_QWORD *)(v1 + 72LL * *(unsigned __int8 *)(*v2 + 16) + 16); /*0x1030a7e8f*/
      v7 = *(_DWORD *)(v6 + 48); /*0x1030a7e94*/
      if ( (v7 & 0x10) == 0 ) /*0x1030a7e9c*/
        break; /*0x1030a7e9c*/
      *(_DWORD *)(v6 + 48) = v7 | 0x100; /*0x1030a7ea5*/
      if ( v3 != 0 ) /*0x1030a7eac*/
      {
        v8 = *(_DWORD *)(v5 + 48); /*0x1030a7eae*/
        if ( (~v8 & 0x800001) == 0 && (v8 & 0x300) != 0 && v4 > *(__int16 *)(v6 + 58) ) /*0x1030a7ed7*/
          *(_DWORD *)(v5 + 48) = v8 & 0xFFBFFFBF | 0x400000; /*0x1030a7ee7*/
      }
      v4 += *(_WORD *)(v5 + 22); /*0x1030a7eeb*/
      ++v3; /*0x1030a7ef0*/
      v2 += 14; /*0x1030a7ef8*/
    }
    while ( v3 < *(unsigned __int8 *)(a1 + 64) ); /*0x1030a7eff*/
  }
}

// Address: 0x1030a7f04 | Name: _whereAddIndexedExpr
void __fastcall whereAddIndexedExpr(_QWORD *a1, __int64 a2, int a3, __int64 a4)
{
  __int64 v5; // rbx
  unsigned __int64 v6; // r12
  __int64 v7; // rax
  __int64 *v8; // rax
  __int64 v9; // r13
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // rsi
  __int64 v13; // r8
  __int64 v14; // r9
  _QWORD *v15; // rax
  __int64 v16; // rcx
  __int64 v17; // rax
  __int64 v18; // rcx
  int v19; // eax
  _DWORD *v20; // rcx
  _QWORD *v21; // r14
  _QWORD *v22; // rcx
  __int64 v23; // rcx
  __int64 v24; // rax
  __int64 v25; // [rsp+0h] [rbp-80h] BYREF
  __int64 (__fastcall *v26)(); // [rsp+8h] [rbp-78h]
  __int64 (__fastcall *v27)(); // [rsp+10h] [rbp-70h]
  __int16 v28; // [rsp+24h] [rbp-5Ch]
  __int64 v29; // [rsp+30h] [rbp-50h]
  _QWORD *v30; // [rsp+38h] [rbp-48h]
  int v31; // [rsp+44h] [rbp-3Ch]
  __int64 v32; // [rsp+48h] [rbp-38h]
  _QWORD *v33; // [rsp+50h] [rbp-30h]

  v29 = a4; /*0x1030a7f15*/
  v31 = a3; /*0x1030a7f19*/
  v33 = a1; /*0x1030a7f1c*/
  if ( *(_WORD *)(a2 + 96) != 0 ) /*0x1030a7f25*/
  {
    v32 = *(_QWORD *)(a2 + 24); /*0x1030a7f32*/
    v30 = v33 + 13; /*0x1030a7f3e*/
    v5 = 8; /*0x1030a7f42*/
    v6 = 0; /*0x1030a7f47*/
    while ( 1 ) /*0x1030a7f4e*/
    {
      v7 = *(__int16 *)(*(_QWORD *)(a2 + 8) + 2 * v6); /*0x1030a7f4e*/
      if ( v7 == -2 ) /*0x1030a7f57*/
      {
        v8 = (__int64 *)(v5 + *(_QWORD *)(a2 + 80)); /*0x1030a7f5d*/
      }
      else
      {
        if ( (v7 & 0x8000u) != 0LL ) /*0x1030a7fc2*/
          goto LABEL_24; /*0x1030a7fc2*/
        v16 = *(_QWORD *)(v32 + 8); /*0x1030a7fcc*/
        v17 = 16 * v7; /*0x1030a7fd0*/
        if ( (*(_BYTE *)(v16 + v17 + 14) & 0x20) == 0 ) /*0x1030a7fd9*/
          goto LABEL_24; /*0x1030a7fd9*/
        v18 = v17 + v16; /*0x1030a7fdf*/
        v19 = *(unsigned __int16 *)(v18 + 12); /*0x1030a7fe2*/
        if ( *(_WORD *)(v18 + 12) == 0 ) /*0x1030a7fe8*/
          goto LABEL_24; /*0x1030a7fe8*/
        if ( *(_BYTE *)(v32 + 63) != 0 ) /*0x1030a7ff6*/
          goto LABEL_24; /*0x1030a7ff6*/
        v20 = *(_DWORD **)(v32 + 80); /*0x1030a8000*/
        if ( v20 == nullptr || *v20 < v19 ) /*0x1030a800f*/
          goto LABEL_24; /*0x1030a800f*/
        v8 = (__int64 *)&v20[6 * (v19 - 1) + 2]; /*0x1030a801f*/
      }
      v9 = *v8; /*0x1030a7f60*/
      v28 = 1; /*0x1030a7f63*/
      v25 = 0; /*0x1030a7f69*/
      v26 = exprNodeIsConstant; /*0x1030a7f78*/
      v27 = sqlite3SelectWalkFail; /*0x1030a7f83*/
      if ( v9 != 0 ) /*0x1030a7f8a*/
      {
        sqlite3WalkExprNN(a1: &v25); /*0x1030a7f97*/
        if ( v28 == 0 ) /*0x1030a7fa1*/
          break; /*0x1030a7fa1*/
      }
LABEL_24:
      ++v6; /*0x1030a80c6*/
      v5 += 24; /*0x1030a80ce*/
      if ( v6 >= *(unsigned __int16 *)(a2 + 96) ) /*0x1030a80d5*/
        return; /*0x1030a80d5*/
    }
    if ( *v33 != 0 ) /*0x1030a7fb1*/
      v15 = (_QWORD *)sqlite3DbMallocRawNN( /*0x1030a7fb8*/
                        a1: *v33,
                        a2: 32,
                        a3: v10,
                        a4: v11,
                        a5: v13,
                        a6: v14,
                        a7: v25,
                        a8: v26,
                        a9: v27);
    else
      v15 = (_QWORD *)sqlite3Malloc(a1: 32, a2: v12, a3: v10, a4: v11, a5: v13, a6: v14); /*0x1030a802d*/
    v21 = v15; /*0x1030a8032*/
    if ( v15 == nullptr ) /*0x1030a8038*/
      return; /*0x1030a8038*/
    v22 = v33; /*0x1030a803e*/
    v15[3] = v33[13]; /*0x1030a8046*/
    *v15 = exprDup(a1: *v22, a2: v9, a3: 0, a4: 0); /*0x1030a8059*/
    v23 = v29; /*0x1030a805c*/
    *((_DWORD *)v21 + 2) = *(_DWORD *)(v29 + 28); /*0x1030a8063*/
    *((_DWORD *)v21 + 3) = v31; /*0x1030a806a*/
    *((_DWORD *)v21 + 4) = v6; /*0x1030a806e*/
    *((_BYTE *)v21 + 20) = (*(_BYTE *)(v23 + 24) & 0x58) != 0; /*0x1030a8076*/
    v24 = *(_QWORD *)(a2 + 32); /*0x1030a807b*/
    if ( v24 == 0 ) /*0x1030a8082*/
    {
      if ( computeIndexAffStr(a1: *v33, a2) == 0 ) /*0x1030a8096*/
        goto LABEL_22; /*0x1030a8096*/
      v24 = *(_QWORD *)(a2 + 32); /*0x1030a8098*/
    }
    *((_BYTE *)v21 + 21) = *(_BYTE *)(v24 + v6); /*0x1030a80a0*/
LABEL_22:
    *v30 = v21; /*0x1030a80a4*/
    if ( v21[3] == 0 ) /*0x1030a80b0*/
      sqlite3ParserAddCleanup(a1: v33, a2: whereIndexedExprCleanup, a3: v30); /*0x1030a80c1*/
    goto LABEL_24; /*0x1030a80c1*/
  }
}

// Address: 0x1030a80ea | Name: _wherePartIdxExpr
char __fastcall wherePartIdxExpr(_QWORD *a1, __int64 a2, __int64 a3, _QWORD *a4, int a5, __int64 a6)
{
  __int64 v7; // r14
  __int64 v9; // rax
  bool v10; // zf
  __int64 v11; // rbx
  __int64 v12; // rsi
  __int64 v13; // rsi
  __int64 v14; // r8
  __int64 v15; // r9
  __int64 v16; // rcx
  __int64 v17; // rdx
  unsigned __int8 v18; // r15
  __int64 v19; // r13
  __int64 v20; // r12
  __int64 v21; // r14
  char v22; // dl
  __int64 v23; // rdi
  char v24; // r12
  __int64 v25; // rax
  __int64 v26; // rcx
  _QWORD *v27; // rcx
  _QWORD v29[4]; // [rsp+8h] [rbp-78h] BYREF
  __int16 v30; // [rsp+2Ch] [rbp-54h]
  __int64 v31; // [rsp+38h] [rbp-48h]
  __int64 v32; // [rsp+40h] [rbp-40h]
  int v33; // [rsp+4Ch] [rbp-34h]
  _QWORD *v34; // [rsp+50h] [rbp-30h]

  v7 = a3; /*0x1030a80fe*/
  LOBYTE(v9) = *(_BYTE *)a3; /*0x1030a8104*/
  v10 = *(_BYTE *)a3 == 44; /*0x1030a8106*/
  v34 = a1; /*0x1030a8108*/
  v33 = a5; /*0x1030a810c*/
  v31 = a6; /*0x1030a8110*/
  if ( v10 ) /*0x1030a8114*/
  {
    wherePartIdxExpr(a1, a2, a3: *(_QWORD *)(a3 + 24), a4); /*0x1030a8120*/
    v7 = *(_QWORD *)(v7 + 16); /*0x1030a8125*/
    LOBYTE(v9) = *(_BYTE *)v7; /*0x1030a8129*/
  }
  if ( (_BYTE)v9 == 54 || (unsigned __int8)v9 == 45 ) /*0x1030a8136*/
  {
    v11 = *(_QWORD *)(v7 + 16); /*0x1030a813c*/
    if ( *(_BYTE *)v11 == 0xA8 ) /*0x1030a8143*/
    {
      v12 = *(_QWORD *)(v7 + 24); /*0x1030a8149*/
      v30 = 1; /*0x1030a814d*/
      v29[0] = 0; /*0x1030a8153*/
      v29[1] = exprNodeIsConstant; /*0x1030a8162*/
      v29[2] = sqlite3SelectWalkFail; /*0x1030a816d*/
      v32 = v12; /*0x1030a8174*/
      if ( v12 == 0 || (LOBYTE(v9) = sqlite3WalkExprNN(a1: v29), v30 != 0) ) /*0x1030a818c*/
      {
        v9 = sqlite3BinaryCompareCollSeq( /*0x1030a81b1*/
               a1: v34,
               a2: *(_QWORD *)(v7 + ((*(_DWORD *)(v7 + 4) & 0x400u) >> 7) + 16),
               a3: *(_QWORD *)(v7 + 8LL * ((*(_DWORD *)(v7 + 4) & 0x400) == 0) + 16));
        if ( v9 == 0 || *(_UNKNOWN **)(v9 + 24) == &binCollFunc ) /*0x1030a81c6*/
        {
          v16 = *(__int16 *)(v11 + 44); /*0x1030a81cc*/
          if ( v16 >= 0 ) /*0x1030a81d4*/
          {
            v9 = *(_QWORD *)(*(_QWORD *)(a2 + 24) + 8LL); /*0x1030a81de*/
            v17 = 16 * v16; /*0x1030a81e5*/
            v18 = *(_BYTE *)(v9 + 16 * v16 + 9); /*0x1030a81e9*/
            if ( v18 >= 0x42u ) /*0x1030a81f2*/
            {
              v19 = v31; /*0x1030a81f8*/
              if ( v31 != 0 ) /*0x1030a81ff*/
              {
                v20 = *v34; /*0x1030a8205*/
                if ( *v34 != 0 ) /*0x1030a820b*/
                  v9 = sqlite3DbMallocRawNN(a1: *v34, a2: 32, a3: v17, a4: v16, a5: v14, a6: v15); /*0x1030a8215*/
                else
                  v9 = sqlite3Malloc(a1: 32, a2: v13, a3: v17, a4: v16, a5: v14, a6: v15); /*0x1030a823e*/
                v21 = v9; /*0x1030a8243*/
                if ( v9 != 0 ) /*0x1030a8249*/
                {
                  v22 = *(_BYTE *)(v19 + 24); /*0x1030a824b*/
                  if ( v32 != 0 ) /*0x1030a8256*/
                  {
                    v23 = v20; /*0x1030a8258*/
                    v24 = *(_BYTE *)(v19 + 24); /*0x1030a825b*/
                    v25 = exprDup(a1: v23, a2: v32, a3: 0, a4: 0); /*0x1030a8262*/
                    v22 = v24; /*0x1030a8267*/
                    v26 = v19; /*0x1030a826a*/
                  }
                  else
                  {
                    v26 = v19; /*0x1030a826f*/
                    v25 = 0; /*0x1030a8272*/
                  }
                  *(_QWORD *)v21 = v25; /*0x1030a8277*/
                  *(_DWORD *)(v21 + 8) = *(_DWORD *)(v26 + 28); /*0x1030a827d*/
                  *(_DWORD *)(v21 + 12) = v33; /*0x1030a8284*/
                  *(_DWORD *)(v21 + 16) = *(__int16 *)(v11 + 44); /*0x1030a828c*/
                  *(_BYTE *)(v21 + 20) = (v22 & 0x48) != 0; /*0x1030a8290*/
                  v27 = v34; /*0x1030a8295*/
                  v9 = v34[14]; /*0x1030a8299*/
                  *(_QWORD *)(v21 + 24) = v9; /*0x1030a829d*/
                  *(_BYTE *)(v21 + 21) = v18; /*0x1030a82a1*/
                  v27[14] = v21; /*0x1030a82a5*/
                  if ( v9 == 0 ) /*0x1030a82ac*/
                    LOBYTE(v9) = sqlite3ParserAddCleanup(a1: v27, a2: whereIndexedExprCleanup, a3: v27 + 14); /*0x1030a82bc*/
                }
              }
              else if ( (unsigned __int16)v16 <= 0x3Eu ) /*0x1030a8220*/
              {
                v9 = __ROL8__(-2, v16); /*0x1030a822d*/
                *a4 &= v9; /*0x1030a8230*/
              }
            }
          }
        }
      }
    }
  }
  return v9; /*0x1030a82c1*/
}

// Address: 0x1030ab447 | Name: _whereInfoFree
__int64 __fastcall whereInfoFree(__int64 a1, __int64 a2)
{
  __int64 v4; // r15
  _QWORD *v5; // rsi
  _QWORD *v6; // r15

  sqlite3WhereClauseClear(a1: a2 + 104); /*0x1030ab45b*/
  while ( 1 ) /*0x1030ab460*/
  {
    v4 = *(_QWORD *)(a2 + 80); /*0x1030ab460*/
    if ( v4 == 0 ) /*0x1030ab467*/
      break; /*0x1030ab467*/
    *(_QWORD *)(a2 + 80) = *(_QWORD *)(v4 + 72); /*0x1030ab46d*/
    whereLoopClear(a1, a2: v4); /*0x1030ab477*/
    sqlite3DbNNFreeNN(a1, a2: v4); /*0x1030ab482*/
  }
  v5 = *(_QWORD **)(a2 + 88); /*0x1030ab489*/
  if ( v5 != nullptr ) /*0x1030ab490*/
  {
    do /*0x1030ab4a7*/
    {
      v6 = (_QWORD *)*v5; /*0x1030ab492*/
      sqlite3DbNNFreeNN(a1, a2: v5); /*0x1030ab498*/
      *(_QWORD *)(a2 + 88) = v6; /*0x1030ab49d*/
      v5 = v6; /*0x1030ab4a1*/
    }
    while ( v6 != nullptr ); /*0x1030ab4a7*/
  }
  return sqlite3DbNNFreeNN(a1, a2); /*0x1030ab4b3*/
}

// Address: 0x1030ab4be | Name: _whereClauseInsert
__int64 __fastcall whereClauseInsert(__int64 ***a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6)
{
  __int16 v6; // r15
  __int64 v7; // r14
  int v9; // r12d
  __int64 v10; // rax
  __int64 **v11; // r12
  __int64 v12; // r13
  __int64 v13; // r15
  _QWORD *v14; // rax
  __int64 **v15; // rax
  __int64 v16; // r13
  __int16 v17; // ax
  int v18; // eax
  __int64 *v19; // r14
  __int64 **__src; // [rsp+8h] [rbp-38h]
  __int16 v22; // [rsp+14h] [rbp-2Ch]

  v6 = a3; /*0x1030ab4cf*/
  v7 = a2; /*0x1030ab4d2*/
  v9 = *((_DWORD *)a1 + 5); /*0x1030ab4d8*/
  v10 = *((int *)a1 + 6); /*0x1030ab4dc*/
  if ( v9 >= (int)v10 ) /*0x1030ab4e3*/
  {
    v22 = a3; /*0x1030ab4e5*/
    v11 = *a1; /*0x1030ab4e9*/
    __src = a1[4]; /*0x1030ab4f0*/
    v12 = ***a1; /*0x1030ab4f8*/
    v13 = 112 * v10; /*0x1030ab4fb*/
    v14 = (_QWORD *)sqlite3DbMallocRawNN(a1: v12, a2: 112 * v10 + 16, a3, a4: **a1, a5, a6); /*0x1030ab506*/
    if ( v14 == nullptr ) /*0x1030ab50e*/
    {
      a1[4] = nullptr; /*0x1030ab5fc*/
      if ( (v22 & 1) != 0 && v7 != 0 ) /*0x1030ab60e*/
        sqlite3ExprDeleteNN(a1: v12, a2: v7); /*0x1030ab61b*/
      a1[4] = __src; /*0x1030ab620*/
      return 0; /*0x1030ab627*/
    }
    *v14 = v11[11]; /*0x1030ab519*/
    v14[1] = v13; /*0x1030ab51c*/
    v11[11] = v14; /*0x1030ab520*/
    v15 = (__int64 **)(v14 + 2); /*0x1030ab525*/
    a1[4] = v15; /*0x1030ab529*/
    memcpy(__dst: v15, __src, __n: 56LL * *((int *)a1 + 5)); /*0x1030ab53c*/
    *((_DWORD *)a1 + 6) *= 2; /*0x1030ab541*/
    v9 = *((_DWORD *)a1 + 5); /*0x1030ab544*/
    v6 = v22; /*0x1030ab548*/
  }
  *((_DWORD *)a1 + 5) = v9 + 1; /*0x1030ab551*/
  if ( (v6 & 2) == 0 ) /*0x1030ab55f*/
    *((_DWORD *)a1 + 7) = v9 + 1; /*0x1030ab561*/
  v16 = (__int64)&a1[4][7 * v9]; /*0x1030ab564*/
  if ( v7 != 0 ) /*0x1030ab56b*/
  {
    v17 = 1; /*0x1030ab56d*/
    if ( (*(_BYTE *)(v7 + 6) & 8) != 0 ) /*0x1030ab576*/
      v17 = sqlite3LogEst(a1: *(int *)(v7 + 40), a2, a3, a4: v9, a5, a6) - 270; /*0x1030ab581*/
    *(_WORD *)(v16 + 16) = v17; /*0x1030ab586*/
    while ( 1 ) /*0x1030ab58b*/
    {
      v18 = *(_DWORD *)(v7 + 4); /*0x1030ab58b*/
      if ( (v18 & 0x82000) == 0 ) /*0x1030ab594*/
        break; /*0x1030ab594*/
      if ( (v18 & 0x80000) != 0 ) /*0x1030ab59a*/
      {
        v19 = (__int64 *)(*(_QWORD *)(v7 + 32) + 8LL); /*0x1030ab5ac*/
      }
      else
      {
        if ( *(_BYTE *)v7 != 114 ) /*0x1030ab5a0*/
          break; /*0x1030ab5a0*/
        v19 = (__int64 *)(v7 + 16); /*0x1030ab5a2*/
      }
      v7 = *v19; /*0x1030ab5b0*/
      if ( v7 == 0 ) /*0x1030ab5b6*/
        goto LABEL_18; /*0x1030ab5b6*/
    }
  }
  else
  {
    *(_WORD *)(v16 + 16) = 1; /*0x1030ab5ba*/
LABEL_18:
    v7 = 0; /*0x1030ab5c1*/
  }
  *(_QWORD *)v16 = v7; /*0x1030ab5c4*/
  *(_WORD *)(v16 + 18) = v6; /*0x1030ab5c8*/
  *(_QWORD *)(v16 + 8) = a1; /*0x1030ab5cd*/
  *(_OWORD *)(v16 + 20) = 0; /*0x1030ab5d4*/
  *(_OWORD *)(v16 + 36) = 0; /*0x1030ab5d9*/
  *(_DWORD *)(v16 + 52) = 0; /*0x1030ab5de*/
  return (unsigned int)v9; /*0x1030ab5e9*/
}

// Address: 0x1030add7d | Name: _whereAddLimitExpr
__int64 __fastcall whereAddLimitExpr(__int64 ***a1, int a2, __int64 a3, int a4, int a5)
{
  __int64 *v7; // r12
  __int64 v8; // rbx
  int IsInteger; // eax
  int v10; // r14d
  __int64 result; // rax
  __int64 v12; // rcx
  __int64 v13; // r8
  __int64 v14; // r9
  int v15; // eax
  __int64 **v16; // rcx
  _QWORD v17[2]; // [rsp+8h] [rbp-48h] BYREF
  int v18; // [rsp+1Ch] [rbp-34h] BYREF
  int v19; // [rsp+20h] [rbp-30h]
  int v20; // [rsp+24h] [rbp-2Ch]

  v19 = a5; /*0x1030add8e*/
  v20 = a4; /*0x1030add92*/
  v7 = **a1; /*0x1030add9e*/
  v8 = *v7; /*0x1030adda1*/
  v18 = 0; /*0x1030adda9*/
  IsInteger = sqlite3ExprIsInteger(a1: a3, a2: &v18, a3: v7); /*0x1030addb9*/
  v10 = v18; /*0x1030addc3*/
  if ( IsInteger != 0 && v18 >= 0 ) /*0x1030addc9*/
  {
    v17[0] = 0; /*0x1030addd7*/
    LODWORD(v17[1]) = 0; /*0x1030addde*/
    result = sqlite3ExprAlloc(a1: v8, a2: 156, a3: v17, a4: 0); /*0x1030addef*/
    if ( result == 0 ) /*0x1030addf7*/
      return result; /*0x1030addf7*/
    *(_BYTE *)(result + 5) |= 8u; /*0x1030addf9*/
    *(_DWORD *)(result + 8) = v10; /*0x1030addfd*/
  }
  else
  {
    v17[0] = 0; /*0x1030ade03*/
    LODWORD(v17[1]) = 0; /*0x1030ade0a*/
    result = sqlite3ExprAlloc(a1: v8, a2: 176, a3: v17, a4: 0); /*0x1030ade1b*/
    if ( result == 0 ) /*0x1030ade23*/
      return result; /*0x1030ade23*/
    *(_DWORD *)(result + 40) = a2; /*0x1030ade25*/
  }
  result = sqlite3PExpr(a1: v7, a2: 47, a3: 0, a4: result); /*0x1030ade36*/
  if ( result != 0 ) /*0x1030ade3e*/
  {
    v15 = whereClauseInsert(a1, a2: result, a3: 3, a4: v12, a5: v13, a6: v14); /*0x1030ade4b*/
    v16 = a1[4]; /*0x1030ade50*/
    result = 56LL * v15; /*0x1030ade56*/
    *(_DWORD *)((char *)v16 + result + 28) = v20; /*0x1030ade5d*/
    *(_WORD *)((char *)v16 + result + 20) = 64; /*0x1030ade61*/
    *((_BYTE *)v16 + result + 23) = v19; /*0x1030ade6b*/
  }
  return result; /*0x1030ade6f*/
}

// Address: 0x1030adf1d | Name: _whereScanInit
__int64 __fastcall whereScanInit(__int64 a1, __int64 a2, int a3, int a4, int a5, _QWORD *a6)
{
  __int64 v6; // rax
  __int64 v7; // rsi
  unsigned int v8; // edx

  *(_QWORD *)a1 = a2; /*0x1030adf21*/
  *(_QWORD *)(a1 + 8) = a2; /*0x1030adf24*/
  *(_BYTE *)(a1 + 40) = 0; /*0x1030adf28*/
  *(_OWORD *)(a1 + 16) = 0; /*0x1030adf2f*/
  *(_DWORD *)(a1 + 36) = a5; /*0x1030adf33*/
  *(_DWORD *)(a1 + 32) = 0; /*0x1030adf37*/
  *(_DWORD *)(a1 + 44) = a3; /*0x1030adf3e*/
  *(_WORD *)(a1 + 41) = 257; /*0x1030adf41*/
  if ( a6 != nullptr ) /*0x1030adf4a*/
  {
    v6 = a4; /*0x1030adf4c*/
    v7 = a6[3]; /*0x1030adf53*/
    v8 = *(__int16 *)(a6[1] + 2LL * a4); /*0x1030adf57*/
    LOWORD(a4) = -1; /*0x1030adf5b*/
    if ( (_WORD)v8 != *(_WORD *)(v7 + 52) ) /*0x1030adf64*/
    {
      if ( (v8 & 0x8000u) != 0 ) /*0x1030adf69*/
      {
        LOWORD(a4) = v8; /*0x1030adf95*/
        if ( (_WORD)v8 == 0xFFFE ) /*0x1030adf9b*/
        {
          *(_QWORD *)(a1 + 24) = *(_QWORD *)(a6[10] + 24 * v6 + 8); /*0x1030adfaa*/
          *(_QWORD *)(a1 + 16) = *(_QWORD *)(a6[8] + 8 * v6); /*0x1030adfb6*/
          *(_WORD *)(a1 + 88) = -2; /*0x1030adfba*/
          return whereScanInitIndexExpr(); /*0x1030adfc1*/
        }
      }
      else
      {
        *(_BYTE *)(a1 + 40) = *(_BYTE *)(*(_QWORD *)(v7 + 8) + 16LL * v8 + 9); /*0x1030adf79*/
        *(_QWORD *)(a1 + 16) = *(_QWORD *)(a6[8] + 8 * v6); /*0x1030adf84*/
        LOWORD(a4) = v8; /*0x1030adf88*/
      }
    }
  }
  else if ( a4 == -2 ) /*0x1030adf8f*/
  {
    return 0; /*0x1030adf94*/
  }
  *(_WORD *)(a1 + 88) = a4; /*0x1030adfc6*/
  return whereScanNext(); /*0x1030adf93*/
}

// Address: 0x1030adfd0 | Name: _whereScanNext
__int64 *__fastcall whereScanNext(__int64 ***a1, __int64 a2, __int64 i, __int64 a4, _BYTE *a5)
{
  int v6; // r13d
  __int64 **v7; // r12
  unsigned __int8 v8; // al
  __int64 v9; // r9
  unsigned int v10; // r14d
  __int64 *v11; // r15
  int v12; // eax
  int v13; // eax
  __int64 v14; // rcx
  int v15; // esi
  char v16; // di
  __int64 *v17; // rdx
  __int64 v18; // rsi
  __int64 v19; // rcx
  unsigned __int8 v20; // al
  int v21; // eax
  __int64 v22; // rax
  const char **v23; // rcx
  const char *v24; // rax
  __int64 v25; // rsi
  __int64 v26; // rdi
  __int64 v27; // rax
  unsigned __int8 v28; // al
  __int64 v30; // [rsp+0h] [rbp-40h]
  __int64 v31; // [rsp+8h] [rbp-38h]
  unsigned int v32; // [rsp+14h] [rbp-2Ch]

  v6 = *((_DWORD *)a1 + 8); /*0x1030adfe4*/
  v7 = a1[1]; /*0x1030adfe8*/
  v8 = *((_BYTE *)a1 + 41); /*0x1030adfec*/
LABEL_2:
  v9 = (unsigned int)*((__int16 *)a1 + v8 + 43); /*0x1030adfef*/
  v10 = *((_DWORD *)a1 + v8 + 10); /*0x1030adff8*/
  v32 = *((__int16 *)a1 + v8 + 43); /*0x1030adffd*/
  while ( v6 >= *((_DWORD *)v7 + 5) ) /*0x1030ae006*/
  {
LABEL_53:
    v7 = (__int64 **)v7[1]; /*0x1030ae22f*/
    v6 = 0; /*0x1030ae234*/
    if ( v7 == nullptr ) /*0x1030ae23a*/
    {
      v28 = *((_BYTE *)a1 + 41); /*0x1030ae240*/
      if ( v28 >= *((_BYTE *)a1 + 42) ) /*0x1030ae246*/
        return nullptr; /*0x1030ae278*/
      v7 = *a1; /*0x1030ae248*/
      v8 = v28 + 1; /*0x1030ae24b*/
      *((_BYTE *)a1 + 41) = v8; /*0x1030ae24d*/
      v6 = 0; /*0x1030ae250*/
      goto LABEL_2; /*0x1030ae253*/
    }
  }
  v11 = &v7[4][7 * v6]; /*0x1030ae013*/
  while ( 1 ) /*0x1030ae018*/
  {
    if ( *((_DWORD *)v11 + 7) == v10 && *((_DWORD *)v11 + 8) == (_DWORD)v9 ) /*0x1030ae026*/
    {
      if ( (_WORD)v9 != 0xFFFE /*0x1030ae04c*/
        || (v12 = sqlite3ExprCompareSkip(a1: *(_QWORD *)(*v11 + 16), a2: a1[3], a3: v10), v9 = v32, v12 == 0) )
      {
        if ( *((_BYTE *)a1 + 41) < 2u || (*(_BYTE *)(*v11 + 4) & 1) == 0 ) /*0x1030ae05f*/
        {
          v13 = *((_DWORD *)v11 + 5); /*0x1030ae065*/
          if ( (v13 & 0x800) != 0 ) /*0x1030ae06d*/
          {
            v14 = *((unsigned __int8 *)a1 + 42); /*0x1030ae073*/
            if ( (unsigned int)v14 <= 0xA ) /*0x1030ae07a*/
            {
              for ( i = *(_QWORD *)(*v11 + 24); i != 0; i = *v17 ) /*0x1030ae083*/
              {
                v15 = *(_DWORD *)(i + 4); /*0x1030ae090*/
                if ( (v15 & 0x82000) == 0 ) /*0x1030ae099*/
                {
                  v16 = *(_BYTE *)i; /*0x1030ae0bd*/
LABEL_22:
                  if ( (v15 & 0x20) == 0 && v16 == -88 ) /*0x1030ae0ca*/
                  {
                    if ( *((_BYTE *)a1 + 42) != 0 ) /*0x1030ae0cf*/
                    {
                      v18 = 0; /*0x1030ae0d4*/
                      while ( 1 ) /*0x1030ae0d6*/
                      {
                        if ( *((_DWORD *)a1 + v18 + 11) == *(_DWORD *)(i + 40) ) /*0x1030ae0da*/
                        {
                          a5 = (_BYTE *)*((unsigned __int16 *)a1 + v18 + 44); /*0x1030ae0dc*/
                          if ( (_WORD)a5 == *(_WORD *)(i + 44) ) /*0x1030ae0e7*/
                            break; /*0x1030ae0e7*/
                        }
                        if ( v14 == ++v18 ) /*0x1030ae0ef*/
                          goto LABEL_32; /*0x1030ae0ef*/
                      }
                    }
                    else
                    {
                      LODWORD(v18) = 0; /*0x1030ae0f3*/
                    }
                    if ( (_DWORD)v18 == (_DWORD)v14 ) /*0x1030ae0f7*/
                    {
LABEL_32:
                      *((_DWORD *)a1 + *((unsigned __int8 *)a1 + 42) + 11) = *(_DWORD *)(i + 40); /*0x1030ae0f9*/
                      *((_WORD *)a1 + (unsigned int)v14 + 44) = *(_WORD *)(i + 44); /*0x1030ae106*/
                      *((_BYTE *)a1 + 42) = v14 + 1; /*0x1030ae10e*/
                      LOWORD(v13) = *((_WORD *)v11 + 10); /*0x1030ae111*/
                    }
                  }
                  break; /*0x1030ae111*/
                }
                if ( (v15 & 0x80000) != 0 ) /*0x1030ae09f*/
                {
                  v17 = (__int64 *)(*(_QWORD *)(i + 32) + 8LL); /*0x1030ae0b4*/
                }
                else
                {
                  v16 = *(_BYTE *)i; /*0x1030ae0a1*/
                  if ( *(_BYTE *)i != 114 ) /*0x1030ae0a8*/
                    goto LABEL_22; /*0x1030ae0a8*/
                  v17 = (__int64 *)(i + 16); /*0x1030ae0aa*/
                }
              }
            }
          }
          v19 = (unsigned __int16)v13; /*0x1030ae116*/
          if ( ((unsigned __int16)v13 & *((_DWORD *)a1 + 9)) != 0 ) /*0x1030ae11c*/
          {
            if ( (v13 & 0x100) == 0 && a1[2] != nullptr ) /*0x1030ae131*/
            {
              v20 = *((_BYTE *)a1 + 40); /*0x1030ae13e*/
              if ( (v19 & 1) != 0 ) /*0x1030ae144*/
              {
                v24 = (const char *)indexInAffinityOk(a1: **v7, a2: v11, a3: v20, a4: v19, a5, a6: v9); /*0x1030ae1b3*/
                a5 = sqlite3UpperToLower; /*0x1030ae1bb*/
                v9 = v32; /*0x1030ae1c2*/
                if ( v24 != nullptr ) /*0x1030ae1c6*/
                  goto LABEL_41; /*0x1030ae1c6*/
              }
              else
              {
                v30 = **v7; /*0x1030ae146*/
                v31 = *v11; /*0x1030ae150*/
                v21 = sqlite3IndexAffinityOk(a1: *v11, a2: (unsigned int)(char)v20, a3: i, a4: v19, a5, a6: v9); /*0x1030ae154*/
                v9 = v32; /*0x1030ae15b*/
                if ( v21 != 0 ) /*0x1030ae15f*/
                {
                  v22 = sqlite3BinaryCompareCollSeq( /*0x1030ae189*/
                          a1: v30,
                          a2: *(_QWORD *)(v31 + ((*(_DWORD *)(v31 + 4) & 0x400u) >> 7) + 16),
                          a3: *(_QWORD *)(v31 + 8LL * ((*(_DWORD *)(v31 + 4) & 0x400) == 0) + 16));
                  v9 = v32; /*0x1030ae18e*/
                  a5 = sqlite3UpperToLower; /*0x1030ae192*/
                  v23 = (const char **)v22; /*0x1030ae199*/
                  v24 = "BINARY"; /*0x1030ae19c*/
                  if ( v23 != nullptr ) /*0x1030ae1a6*/
                    v24 = *v23; /*0x1030ae1a8*/
LABEL_41:
                  for ( i = 0; ; ++i ) /*0x1030ae1cc*/
                  {
                    v25 = (unsigned __int8)v24[i]; /*0x1030ae1ce*/
                    v26 = *((unsigned __int8 *)a1[2] + i); /*0x1030ae1d2*/
                    if ( (_BYTE)v25 == (_BYTE)v26 ) /*0x1030ae1d9*/
                    {
                      if ( v24[i] == 0 ) /*0x1030ae1de*/
                      {
                        LOWORD(v13) = *((_WORD *)v11 + 10); /*0x1030ae1f1*/
                        goto LABEL_47; /*0x1030ae1e0*/
                      }
                    }
                    else if ( sqlite3UpperToLower[v25] != sqlite3UpperToLower[v26] ) /*0x1030ae1ea*/
                    {
                      goto LABEL_52; /*0x1030ae1ea*/
                    }
                  }
                }
              }
              goto LABEL_52; /*0x1030ae15f*/
            }
LABEL_47:
            if ( (v13 & 0x82) == 0 ) /*0x1030ae1f8*/
              break; /*0x1030ae1f8*/
            v27 = *(_QWORD *)(*v11 + 24); /*0x1030ae1fd*/
            if ( v27 == 0 /*0x1030ae21b*/
              || *(_BYTE *)v27 != 0xA8
              || *(_DWORD *)(v27 + 40) != *((_DWORD *)a1 + 11)
              || *(_WORD *)(v27 + 44) != *((_WORD *)a1 + 44) )
            {
              break; /*0x1030ae21b*/
            }
          }
        }
      }
    }
LABEL_52:
    ++v6; /*0x1030ae21d*/
    v11 += 7; /*0x1030ae220*/
    if ( v6 >= *((_DWORD *)v7 + 5) ) /*0x1030ae229*/
      goto LABEL_53; /*0x1030ae229*/
  }
  a1[1] = v7; /*0x1030ae258*/
  *((_DWORD *)a1 + 8) = v6 + 1; /*0x1030ae25f*/
  return v11; /*0x1030ae266*/
}

// Address: 0x1030ae27a | Name: _whereScanInitIndexExpr
__int64 *__fastcall whereScanInitIndexExpr(__int64 a1)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // rsi
  _BYTE *v5; // r8

  *(_BYTE *)(a1 + 40) = sqlite3ExprAffinity(a1: *(_QWORD *)(a1 + 24)); /*0x1030ae28c*/
  return whereScanNext((__int64 ***)a1, a2: v4, i: v2, a4: v3, a5: v5); /*0x1030ae296*/
}

// Address: 0x1030ae3c2 | Name: _whereLoopAddVirtual
__int64 __fastcall whereLoopAddVirtual(_QWORD ***a1, __int64 a2, __int64 a3)
{
  unsigned int *v3; // r8
  _QWORD **v4; // rsi
  _QWORD *v5; // rax
  __int64 v6; // r14
  __int64 v7; // rax
  _QWORD **i; // rcx
  int v9; // esi
  int v10; // r8d
  _QWORD *v11; // rdi
  __int16 v12; // r9
  char v13; // r10
  __int64 v14; // rbx
  int v15; // r11d
  int v16; // r13d
  __int64 v17; // r14
  __int64 v18; // r12
  int *v19; // rbx
  unsigned __int8 *v20; // r15
  int v21; // eax
  __int64 v22; // rax
  __int64 v23; // rcx
  __int64 v24; // rdx
  __int64 v25; // rcx
  __int16 v26; // ax
  const char *v27; // rax
  __int64 v28; // rcx
  __int64 v29; // rax
  __int64 v30; // rcx
  __int64 j; // rdx
  __int64 v32; // rsi
  __int64 v33; // rdi
  __int16 v34; // ax
  __int64 v35; // rax
  _QWORD *v36; // r14
  __int64 v37; // rbx
  __int64 v38; // r12
  __int64 v39; // rax
  int v40; // edx
  int v41; // ecx
  int v42; // r8d
  int v43; // r9d
  __int64 v44; // r13
  __int64 v45; // rdx
  __int64 v46; // rcx
  _QWORD **v47; // r10
  __int64 v48; // rbx
  __int64 v49; // rdi
  __int64 v50; // rsi
  __int16 v51; // dx
  __int64 v52; // rdx
  __int64 v53; // rsi
  __int64 v54; // rdi
  __int16 v55; // r9
  int v56; // esi
  int v57; // ecx
  int v58; // r12d
  _QWORD **v59; // rdi
  int v60; // r8d
  int v61; // r8d
  _DWORD *v62; // r9
  __int16 v63; // r14
  __int64 v64; // r10
  __int16 v65; // r15
  int v66; // r11d
  int v67; // r11d
  unsigned __int8 *v68; // r14
  unsigned __int8 v69; // r15
  int v70; // r14d
  __int64 v71; // r12
  unsigned __int64 v72; // rbx
  __int64 v73; // r14
  __int64 v74; // rdx
  __int64 v75; // rcx
  unsigned int *v76; // rbx
  _QWORD **v77; // rsi
  __int64 v78; // r14
  _QWORD *v79; // r15
  unsigned int v80; // ebx
  int v81; // r15d
  int v82; // r13d
  int v83; // r12d
  int v84; // r9d
  int v85; // edi
  __int64 v86; // r12
  int v87; // ebx
  unsigned int v88; // eax
  bool v89; // zf
  _BOOL4 v90; // eax
  unsigned __int64 v91; // r15
  unsigned __int64 v92; // rax
  __int64 k; // rsi
  int v94; // r11d
  _QWORD **v95; // r8
  int m; // r10d
  unsigned __int64 v97; // r10
  unsigned __int64 v98; // r8
  _QWORD *v99; // r13
  int v100; // eax
  int v101; // eax
  int v102; // ebx
  unsigned int v103; // eax
  int v104; // ecx
  __int64 v106; // [rsp+0h] [rbp-C0h] BYREF
  __int64 (__fastcall *v107)(); // [rsp+8h] [rbp-B8h]
  __int64 (__fastcall *v108)(); // [rsp+10h] [rbp-B0h]
  __int16 v109; // [rsp+24h] [rbp-9Ch]
  int v110; // [rsp+34h] [rbp-8Ch]
  _QWORD **v111; // [rsp+38h] [rbp-88h]
  _QWORD *v112; // [rsp+40h] [rbp-80h]
  _QWORD **v113; // [rsp+48h] [rbp-78h]
  _QWORD ***v114; // [rsp+50h] [rbp-70h]
  int v115; // [rsp+5Ch] [rbp-64h] BYREF
  __int64 v116; // [rsp+60h] [rbp-60h]
  __int64 v117; // [rsp+68h] [rbp-58h]
  __int64 v118; // [rsp+70h] [rbp-50h]
  unsigned int *v119; // [rsp+78h] [rbp-48h]
  int *v120; // [rsp+80h] [rbp-40h]
  __int64 v121; // [rsp+88h] [rbp-38h]
  __int64 v122; // [rsp+90h] [rbp-30h]

  v118 = a2; /*0x1030ae3d6*/
  v114 = a1; /*0x1030ae3da*/
  v115 = 0; /*0x1030ae3de*/
  v3 = (unsigned int *)*a1; /*0x1030ae3e5*/
  v4 = a1[1]; /*0x1030ae3e8*/
  v112 = **a1; /*0x1030ae3ef*/
  v5 = *((_QWORD **)v3 + 1); /*0x1030ae3f3*/
  v113 = a1[2]; /*0x1030ae3fb*/
  v6 = (__int64)&v5[9 * *((unsigned __int8 *)v113 + 16) + 1]; /*0x1030ae407*/
  v119 = v3; /*0x1030ae40c*/
  v120 = *((int **)v3 + 2); /*0x1030ae414*/
  v116 = *(_QWORD *)(v6 + 16); /*0x1030ae41c*/
  v122 = 0; /*0x1030ae420*/
  v111 = v4; /*0x1030ae42b*/
  v121 = v6; /*0x1030ae432*/
  if ( v4 != nullptr ) /*0x1030ae436*/
  {
    LODWORD(v7) = 0; /*0x1030ae43c*/
    for ( i = v4; i != nullptr; i = (_QWORD **)i[1] ) /*0x1030ae43e*/
    {
      v9 = *((_DWORD *)i + 5); /*0x1030ae441*/
      if ( v9 > 0 ) /*0x1030ae446*/
      {
        v10 = *(_DWORD *)(v6 + 28); /*0x1030ae450*/
        v11 = i[4] + 5; /*0x1030ae454*/
        do /*0x1030ae4cf*/
        {
          v12 = *((_WORD *)v11 - 11); /*0x1030ae458*/
          *((_WORD *)v11 - 11) = v12 & 0xFFBF; /*0x1030ae464*/
          if ( *((_DWORD *)v11 - 3) == v10 /*0x1030ae487*/
            && (a3 & *v11) == 0
            && (*((_WORD *)v11 - 10) & 0xF7FF) != 0
            && (v12 & 0x80u) == 0 )
          {
            v13 = *(_BYTE *)(v6 + 24); /*0x1030ae494*/
            if ( (v13 & 0x58) == 0 /*0x1030ae4bc*/
              || (v14 = *(v11 - 5), ((v15 = *(_DWORD *)(v14 + 4)) & 3) != 0)
              && *(_DWORD *)(v14 + 48) == v10
              && ((v13 & 0x18) == 0 || (v15 & 2) == 0) )
            {
              LODWORD(v7) = v7 + 1; /*0x1030ae4be*/
              *((_WORD *)v11 - 11) = v12 | 0x40; /*0x1030ae4c4*/
            }
          }
          v11 += 7; /*0x1030ae4c9*/
          --v9; /*0x1030ae4cd*/
        }
        while ( v9 != 0 ); /*0x1030ae4cf*/
      }
    }
    v7 = (int)v7; /*0x1030ae4de*/
  }
  else
  {
    v7 = 0; /*0x1030ae4e2*/
  }
  v117 = v7; /*0x1030ae4e4*/
  v16 = 0; /*0x1030ae4e8*/
  if ( v120 != nullptr ) /*0x1030ae4f3*/
  {
    v17 = *v120; /*0x1030ae4fd*/
    v122 = 0; /*0x1030ae500*/
    LODWORD(v18) = 0; /*0x1030ae508*/
    if ( v17 > 0 ) /*0x1030ae511*/
    {
      v19 = v120 + 2; /*0x1030ae51b*/
      v18 = 0; /*0x1030ae51f*/
      while ( 1 ) /*0x1030ae526*/
      {
        v20 = *(unsigned __int8 **)&v19[6 * v18]; /*0x1030ae526*/
        v109 = 1; /*0x1030ae52a*/
        v106 = 0; /*0x1030ae533*/
        v107 = exprNodeIsConstant; /*0x1030ae545*/
        v108 = sqlite3SelectWalkFail; /*0x1030ae553*/
        if ( v20 != nullptr ) /*0x1030ae55d*/
        {
          sqlite3WalkExprNN(a1: &v106); /*0x1030ae56d*/
          if ( v109 == 0 ) /*0x1030ae57a*/
          {
            if ( (v19[6 * v18 + 4] & 2) != 0 ) /*0x1030ae588*/
              break; /*0x1030ae588*/
            v21 = *v20; /*0x1030ae58e*/
            if ( v21 == 114 ) /*0x1030ae595*/
            {
              v22 = *((_QWORD *)v20 + 2); /*0x1030ae5b8*/
              if ( *(_BYTE *)v22 != 0xA8 || *(_DWORD *)(v22 + 40) != *(_DWORD *)(v121 + 28) ) /*0x1030ae5cf*/
                break; /*0x1030ae5cf*/
              v23 = *(__int16 *)(v22 + 44); /*0x1030ae5d5*/
              *((_WORD *)v20 + 22) = v23; /*0x1030ae5da*/
              if ( v23 >= 0 ) /*0x1030ae5e2*/
              {
                v24 = *(_QWORD *)(v116 + 8); /*0x1030ae5ec*/
                v25 = 16 * v23; /*0x1030ae5f0*/
                v26 = *(_WORD *)(v24 + v25 + 14); /*0x1030ae5f4*/
                if ( (v26 & 0x200) != 0 ) /*0x1030ae5fd*/
                {
                  v28 = *(_QWORD *)(v25 + v24) - 1LL; /*0x1030ae609*/
                  do /*0x1030ae614*/
                    v89 = *(_BYTE *)++v28 == 0; /*0x1030ae60c*/
                  while ( !v89 ); /*0x1030ae614*/
                  if ( (v26 & 4) != 0 ) /*0x1030ae618*/
                  {
                    do /*0x1030ae62a*/
                    {
                      v29 = v28 + 1; /*0x1030ae61f*/
                      v89 = *(_BYTE *)++v28 == 0; /*0x1030ae623*/
                    }
                    while ( !v89 ); /*0x1030ae62a*/
                  }
                  else
                  {
                    v29 = v28; /*0x1030ae61a*/
                  }
                  v27 = (const char *)(v29 + 1); /*0x1030ae62c*/
                }
                else
                {
                  v27 = nullptr; /*0x1030ae5ff*/
                }
                v30 = *((_QWORD *)v20 + 1); /*0x1030ae62f*/
                if ( v30 != 0 ) /*0x1030ae636*/
                {
                  if ( v27 == nullptr ) /*0x1030ae642*/
                    v27 = "BINARY"; /*0x1030ae642*/
                  for ( j = 0; ; ++j ) /*0x1030ae646*/
                  {
                    v32 = *(unsigned __int8 *)(v30 + j); /*0x1030ae648*/
                    v33 = (unsigned __int8)v27[j]; /*0x1030ae64c*/
                    if ( (_BYTE)v32 == (_BYTE)v33 ) /*0x1030ae653*/
                    {
                      if ( *(_BYTE *)(v30 + j) == 0 ) /*0x1030ae658*/
                        goto LABEL_48; /*0x1030ae658*/
                    }
                    else if ( sqlite3UpperToLower[v32] != sqlite3UpperToLower[v33] ) /*0x1030ae66b*/
                    {
                      goto LABEL_50; /*0x1030ae66b*/
                    }
                  }
                }
                break; /*0x1030ae636*/
              }
            }
            else if ( v21 != 168 || *((_DWORD *)v20 + 10) != *(_DWORD *)(v121 + 28) ) /*0x1030ae5ad*/
            {
              break; /*0x1030ae5ad*/
            }
          }
        }
LABEL_48:
        if ( ++v18 == v17 ) /*0x1030ae678*/
          goto LABEL_51; /*0x1030ae678*/
      }
    }
LABEL_50:
    v16 = 0; /*0x1030ae680*/
    if ( (_DWORD)v18 == (_DWORD)v17 ) /*0x1030ae689*/
    {
LABEL_51:
      v34 = *((_WORD *)v119 + 30); /*0x1030ae68b*/
      if ( (v34 & 0x80u) == 0 || *(__int16 *)(v121 + 25) < 0 ) /*0x1030ae6a0*/
        v35 = (v34 & 0x40) != 0; /*0x1030ae6b0*/
      else
        v35 = ((v34 & 0x200) != 0) | 2u; /*0x1030ae6a8*/
      v122 = v35; /*0x1030ae6b3*/
      v16 = v17; /*0x1030ae6b7*/
    }
  }
  v36 = v112; /*0x1030ae6ba*/
  v37 = v117; /*0x1030ae6c1*/
  v38 = v16; /*0x1030ae6c9*/
  v39 = sqlite3DbMallocZero(a1: *v112, a2: 8 * (v117 + v16) + 20 * v117 + 128); /*0x1030ae6df*/
  if ( v39 != 0 ) /*0x1030ae6e7*/
  {
    v110 = v16; /*0x1030ae6ed*/
    v44 = v39 + 8 * v37 + 128; /*0x1030ae6fc*/
    v45 = v39 + 8 * v37 + 12 * v37 + 128; /*0x1030ae707*/
    *(_QWORD *)(v39 + 8) = v44; /*0x1030ae713*/
    v117 = v45; /*0x1030ae717*/
    *(_QWORD *)(v39 + 24) = v45; /*0x1030ae71b*/
    *(_QWORD *)(v39 + 32) = v45 + 8 * v38; /*0x1030ae71f*/
    v46 = *(_QWORD *)(v121 + 32); /*0x1030ae727*/
    *(_QWORD *)(v39 + 88) = v46; /*0x1030ae72b*/
    v47 = v111; /*0x1030ae737*/
    v48 = v38; /*0x1030ae73e*/
    if ( *(char *)(v116 + 48) < 0 ) /*0x1030ae741*/
    {
      v49 = v116 + 16; /*0x1030ae743*/
      do /*0x1030ae759*/
      {
        v50 = *(_QWORD *)v49; /*0x1030ae747*/
        v51 = *(_WORD *)(*(_QWORD *)v49 + 99LL) & 3; /*0x1030ae74e*/
        v49 = *(_QWORD *)v49 + 40LL; /*0x1030ae751*/
      }
      while ( v51 != 2 ); /*0x1030ae759*/
      v52 = *(unsigned __int16 *)(v50 + 94); /*0x1030ae75b*/
      if ( *(_WORD *)(v50 + 94) != 0 ) /*0x1030ae762*/
      {
        v53 = *(_QWORD *)(v50 + 8); /*0x1030ae764*/
        v54 = 0; /*0x1030ae768*/
        do /*0x1030ae788*/
        {
          v55 = *(_WORD *)(v53 + 2 * v54); /*0x1030ae770*/
          if ( v55 >= 63 ) /*0x1030ae77a*/
            LOBYTE(v55) = 63; /*0x1030ae77a*/
          v46 |= 1LL << v55; /*0x1030ae77e*/
          ++v54; /*0x1030ae782*/
        }
        while ( v52 != v54 ); /*0x1030ae788*/
        *(_QWORD *)(v39 + 88) = v46; /*0x1030ae78a*/
      }
    }
    v121 = 0; /*0x1030ae78e*/
    *(_QWORD *)(v39 + 96) = v47; /*0x1030ae796*/
    *(_QWORD *)(v39 + 104) = v36; /*0x1030ae79a*/
    *(_QWORD *)(v39 + 112) = (unsigned int)v122; /*0x1030ae7a2*/
    if ( v47 != nullptr ) /*0x1030ae7af*/
    {
      v56 = 0; /*0x1030ae7b7*/
      v57 = 0; /*0x1030ae7b9*/
      v58 = 0; /*0x1030ae7bb*/
      v59 = v47; /*0x1030ae7be*/
      while ( 1 ) /*0x1030ae7c1*/
      {
        v60 = *((_DWORD *)v59 + 5); /*0x1030ae7c1*/
        if ( v60 > 0 ) /*0x1030ae7c8*/
          break; /*0x1030ae7c8*/
LABEL_99:
        v59 = (_QWORD **)v59[1]; /*0x1030ae8f8*/
        if ( v59 == nullptr ) /*0x1030ae8ff*/
          goto LABEL_103; /*0x1030ae8ff*/
      }
      v61 = v56 + v60; /*0x1030ae7ce*/
      v62 = v59[4] + 4; /*0x1030ae7d5*/
      while ( 1 ) /*0x1030ae7d9*/
      {
        v63 = *((_WORD *)v62 - 7); /*0x1030ae7d9*/
        if ( (v63 & 0x40) != 0 ) /*0x1030ae7e2*/
          break; /*0x1030ae7e2*/
LABEL_96:
        ++v56; /*0x1030ae8e0*/
        v62 += 14; /*0x1030ae8e2*/
        if ( v56 >= v61 ) /*0x1030ae8e9*/
          goto LABEL_99; /*0x1030ae8e9*/
      }
      v64 = v44 + 12LL * v57; /*0x1030ae7fa*/
      *(_DWORD *)v64 = *v62; /*0x1030ae7fd*/
      *(_DWORD *)(v64 + 8) = v56; /*0x1030ae800*/
      v65 = *((_WORD *)v62 - 6); /*0x1030ae804*/
      v66 = v65 & 0x3FFF; /*0x1030ae80c*/
      if ( v66 == 1 ) /*0x1030ae817*/
      {
        if ( v63 >= 0 ) /*0x1030ae81d*/
        {
          v67 = 1 << v57; /*0x1030ae825*/
          if ( v57 >= 32 ) /*0x1030ae82b*/
            v67 = 0; /*0x1030ae82b*/
          *(_DWORD *)(v39 + 116) |= v67; /*0x1030ae82f*/
        }
        *(_BYTE *)(v64 + 4) = 2; /*0x1030ae833*/
        goto LABEL_95; /*0x1030ae838*/
      }
      if ( (_WORD)v66 == 64 ) /*0x1030ae842*/
      {
        *(_BYTE *)(v64 + 4) = *((_BYTE *)v62 - 9); /*0x1030ae848*/
      }
      else
      {
        if ( (v65 & 0x180) != 0 ) /*0x1030ae858*/
        {
          if ( (unsigned __int16)v66 == 256 ) /*0x1030ae865*/
            *(_BYTE *)(v64 + 4) = 71; /*0x1030ae867*/
          else
            *(_BYTE *)(v64 + 4) = 72; /*0x1030ae8d9*/
          goto LABEL_95; /*0x1030ae86c*/
        }
        *(_BYTE *)(v64 + 4) = v65; /*0x1030ae86e*/
        if ( (v65 & 0x3C) != 0 ) /*0x1030ae876*/
        {
          v68 = *(unsigned __int8 **)(*((_QWORD *)v62 - 4) + 24LL); /*0x1030ae87c*/
          v69 = *v68; /*0x1030ae880*/
          if ( *v68 == 0xB0 ) /*0x1030ae887*/
            v69 = v68[2]; /*0x1030ae889*/
          if ( v69 != 0xB1 ) /*0x1030ae891*/
          {
            if ( v69 != 139 ) /*0x1030ae89e*/
              goto LABEL_95; /*0x1030ae89e*/
            v68 = *((unsigned __int8 **)v68 + 4); /*0x1030ae8a0*/
          }
          if ( **((int **)v68 + 4) >= 2 ) /*0x1030ae8ac*/
          {
            v70 = 1 << v57; /*0x1030ae8b4*/
            if ( v57 >= 16 ) /*0x1030ae8ba*/
              v70 = 0; /*0x1030ae8ba*/
            v58 |= v70; /*0x1030ae8be*/
            if ( (_WORD)v66 == 4 ) /*0x1030ae8c6*/
            {
              *(_BYTE *)(v64 + 4) = 32; /*0x1030ae8f1*/
            }
            else if ( (unsigned __int16)v66 == 16 ) /*0x1030ae8d0*/
            {
              *(_BYTE *)(v64 + 4) = 8; /*0x1030ae8d2*/
            }
          }
        }
      }
LABEL_95:
      ++v57; /*0x1030ae8de*/
      goto LABEL_96; /*0x1030ae8de*/
    }
    v58 = 0; /*0x1030ae91d*/
    v57 = 0; /*0x1030ae920*/
LABEL_103:
    LODWORD(v122) = v58; /*0x1030ae922*/
    v119 = (unsigned int *)v39; /*0x1030ae926*/
    *(_DWORD *)v39 = v57; /*0x1030ae92a*/
    if ( v110 > 0 ) /*0x1030ae933*/
    {
      v71 = 24 * v48; /*0x1030ae93d*/
      v72 = 0; /*0x1030ae941*/
      v121 = 0; /*0x1030ae951*/
      do /*0x1030ae9d0*/
      {
        v73 = *(_QWORD *)&v120[v72 / 4 + 2]; /*0x1030ae95d*/
        v109 = 1; /*0x1030ae962*/
        v106 = 0; /*0x1030ae96b*/
        v107 = exprNodeIsConstant; /*0x1030ae976*/
        v108 = sqlite3SelectWalkFail; /*0x1030ae97d*/
        if ( v73 != 0 ) /*0x1030ae987*/
        {
          sqlite3WalkExprNN(a1: &v106); /*0x1030ae993*/
          if ( v109 == 0 ) /*0x1030ae9a0*/
          {
            v74 = (int)v121; /*0x1030ae9ab*/
            v75 = v117; /*0x1030ae9ae*/
            *(_DWORD *)(v117 + 8LL * (int)v121) = *(__int16 *)(v73 + 44); /*0x1030ae9b2*/
            *(_BYTE *)(v75 + 8 * v74 + 4) = v120[v72 / 4 + 6] & 1; /*0x1030ae9bf*/
            v121 = (unsigned int)(v74 + 1); /*0x1030ae9c5*/
          }
        }
        v72 += 24LL; /*0x1030ae9c9*/
      }
      while ( v71 != v72 ); /*0x1030ae9d0*/
    }
    v76 = v119; /*0x1030ae9d2*/
    v119[4] = v121; /*0x1030ae9da*/
    v77 = v113; /*0x1030ae9df*/
    *((_WORD *)v113 + 9) = 0; /*0x1030ae9e3*/
    *((_DWORD *)v77 + 12) = 1024; /*0x1030ae9e7*/
    *((_WORD *)v77 + 26) = 0; /*0x1030ae9ee*/
    *((_BYTE *)v77 + 28) &= ~1u; /*0x1030ae9f2*/
    v78 = *v76; /*0x1030ae9f6*/
    v79 = v112; /*0x1030ae9f9*/
    if ( (unsigned int)whereLoopResize(a1: *v112, a2: v77, a3: v78) != 0 ) /*0x1030aea0a*/
    {
      freeIndexInfo(a1: *v79, a2: v76); /*0x1030aea12*/
      return 7; /*0x1030aea12*/
    }
    v81 = (unsigned __int16)v122; /*0x1030aea2c*/
    v82 = (int)v114; /*0x1030aea31*/
    v83 = v118; /*0x1030aea38*/
    v80 = whereLoopAddVirtualOne( /*0x1030aea5a*/
            a1: (_DWORD)v114,
            a2: v118,
            a3: -1,
            a4: 0,
            a5: (_DWORD)v76,
            a6: (unsigned __int16)v122,
            a7: (__int64)&v106,
            a8: (__int64)&v115);
    LODWORD(v120) = v81; /*0x1030aea63*/
    if ( v115 != 0 ) /*0x1030aea67*/
      v80 = whereLoopAddVirtualOne( /*0x1030aea93*/
              a1: v82,
              a2: v83,
              a3: -1,
              a4: 0,
              a5: (_DWORD)v119,
              a6: v81,
              a7: (__int64)&v106,
              a8: 0);
    v84 = (int)v120; /*0x1030aeaa0*/
    v85 = (int)v114; /*0x1030aeaa4*/
    if ( v80 == 0 ) /*0x1030aeaa8*/
    {
      v86 = ~v118; /*0x1030aeab2*/
      v89 = (~v118 & (unsigned __int64)*v113) == 0; /*0x1030aeabc*/
      v121 = ~v118 & (unsigned __int64)*v113; /*0x1030aeabf*/
      v80 = 0; /*0x1030aead3*/
      if ( !v89 || (_DWORD)v106 != 0 ) /*0x1030aeace*/
      {
        if ( (_DWORD)v106 == 0 ) /*0x1030aeae0*/
        {
          v117 = 0; /*0x1030aeb30*/
          v90 = false; /*0x1030aeb38*/
LABEL_120:
          v91 = 0; /*0x1030aeb3a*/
          LODWORD(v122) = v90; /*0x1030aeb3d*/
          LODWORD(v116) = v90; /*0x1030aeb40*/
          while ( (int)v78 > 0 ) /*0x1030aeb46*/
          {
            v92 = v91; /*0x1030aeb4c*/
            v91 = -1; /*0x1030aeb61*/
            for ( k = 0; k != v78; ++k ) /*0x1030aeb68*/
            {
              v94 = *(_DWORD *)(*((_QWORD *)v119 + 1) + 12 * k + 8); /*0x1030aeb6e*/
              v95 = v111; /*0x1030aeb73*/
              for ( m = *((_DWORD *)v111 + 5); v94 >= m; m = *((_DWORD *)v95 + 5) ) /*0x1030aeb80*/
              {
                v94 -= m; /*0x1030aeb82*/
                v95 = (_QWORD **)v95[1]; /*0x1030aeb85*/
              }
              v97 = v86 & v95[4][7 * v94 + 5]; /*0x1030aeba2*/
              v98 = v91; /*0x1030aeba8*/
              if ( v97 < v91 ) /*0x1030aebab*/
                v98 = v97; /*0x1030aebab*/
              if ( v97 > v92 ) /*0x1030aebb2*/
                v91 = v98; /*0x1030aebb2*/
            }
            if ( v91 == -1 ) /*0x1030aebc2*/
              break; /*0x1030aebc2*/
            v80 = 0; /*0x1030aebc4*/
            if ( v91 != v121 && v91 != v117 ) /*0x1030aebd0*/
            {
              v99 = (_QWORD *)v118; /*0x1030aebd8*/
              v80 = whereLoopAddVirtualOne( /*0x1030aebf4*/
                      a1: v85,
                      a2: v118,
                      a3: (unsigned int)v118 | (unsigned int)v91,
                      a4: 0,
                      a5: (_DWORD)v119,
                      a6: v84,
                      a7: (__int64)&v106,
                      a8: 0);
              if ( *v113 == v99 ) /*0x1030aebfd*/
              {
                v100 = v122; /*0x1030aec0b*/
                LODWORD(v116) = 1; /*0x1030aec0e*/
                if ( (_DWORD)v106 == 0 ) /*0x1030aec15*/
                  v100 = 1; /*0x1030aec15*/
                LODWORD(v122) = v100; /*0x1030aec18*/
              }
              v85 = (int)v114; /*0x1030aec1b*/
              v84 = (int)v120; /*0x1030aec26*/
            }
            if ( v80 != 0 ) /*0x1030aec2c*/
              goto LABEL_146; /*0x1030aec2c*/
          }
          v80 = 0; /*0x1030aec34*/
          v101 = v122; /*0x1030aec3a*/
          if ( (_DWORD)v116 == 0 ) /*0x1030aec3d*/
          {
            v102 = v85; /*0x1030aec50*/
            v103 = whereLoopAddVirtualOne( /*0x1030aec53*/
                     a1: v85,
                     a2: v118,
                     a3: v118,
                     a4: 0,
                     a5: (_DWORD)v119,
                     a6: v84,
                     a7: (__int64)&v106,
                     a8: 0);
            v85 = v102; /*0x1030aec58*/
            v84 = (int)v120; /*0x1030aec5b*/
            v80 = v103; /*0x1030aec6a*/
            v104 = v122; /*0x1030aec71*/
            if ( (_DWORD)v106 == 0 ) /*0x1030aec74*/
              v104 = 1; /*0x1030aec74*/
            LODWORD(v122) = v104; /*0x1030aec77*/
            v101 = v104; /*0x1030aec7a*/
          }
          if ( (v80 | v101) == 0 ) /*0x1030aec7f*/
            v80 = whereLoopAddVirtualOne( /*0x1030aec9e*/
                    a1: v85,
                    a2: v118,
                    a3: v118,
                    a4: 1,
                    a5: (_DWORD)v119,
                    a6: v84,
                    a7: (__int64)&v106,
                    a8: 0);
          goto LABEL_146; /*0x1030aec9e*/
        }
        v87 = (int)v114; /*0x1030aeafa*/
        v88 = whereLoopAddVirtualOne( /*0x1030aeafd*/
                a1: (_DWORD)v114,
                a2: v118,
                a3: -1,
                a4: 1,
                a5: (_DWORD)v119,
                a6: (_DWORD)v120,
                a7: (__int64)&v106,
                a8: 0);
        v85 = v87; /*0x1030aeb02*/
        v84 = (int)v120; /*0x1030aeb05*/
        v80 = v88; /*0x1030aeb0d*/
        v89 = (v86 & (unsigned __int64)*v113) == 0; /*0x1030aeb16*/
        v117 = v86 & (unsigned __int64)*v113; /*0x1030aeb19*/
        if ( v88 == 0 ) /*0x1030aeb22*/
        {
          v90 = v89; /*0x1030aeb2c*/
          goto LABEL_120; /*0x1030aeb2e*/
        }
      }
    }
LABEL_146:
    freeIndexInfo(a1: *v112, a2: v119); /*0x1030aeca0*/
    return v80; /*0x1030aecab*/
  }
  sqlite3ErrorMsg(a1: (_DWORD)v36, a2: (unsigned int)"out of memory", a3: v40, a4: v41, a5: v42, a6: v43); /*0x1030ae913*/
  return 7; /*0x1030aecb2*/
}

// Address: 0x1030aecc4 | Name: _whereLoopAddBtree
__int64 __fastcall whereLoopAddBtree(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6)
{
  __int64 v6; // rsi
  __int64 v7; // r8
  __int16 v8; // ax
  __int64 *v9; // rbx
  unsigned int v10; // r14d
  bool v11; // zf
  _BYTE *v12; // r13
  __int64 v13; // r15
  __int64 v14; // r12
  __int64 v15; // rdx
  int *v16; // rcx
  int v17; // eax
  __int64 v18; // r14
  char *i; // r12
  int v20; // ecx
  unsigned __int8 v21; // cl
  char **v22; // r12
  __int16 v23; // cx
  __int64 v24; // rdi
  __int64 v25; // r15
  unsigned __int16 v26; // cx
  _QWORD *v27; // r15
  unsigned __int64 v28; // r13
  __int16 v29; // ax
  char v30; // al
  __int16 v31; // ax
  __int64 v32; // rax
  __int64 v33; // rdx
  __int64 **v34; // r14
  __int64 v35; // rcx
  int IsCoveringIndex; // eax
  int v37; // r14d
  char v38; // al
  int v39; // r14d
  __int16 v40; // cx
  __int64 **v41; // rdx
  int v42; // r12d
  __int64 v43; // r15
  __int64 v44; // r13
  __int64 *v45; // r14
  int v46; // eax
  int v47; // eax
  unsigned int v48; // eax
  __int64 v49; // rcx
  int v50; // r12d
  __int64 v51; // r13
  __int64 v52; // r15
  int v53; // eax
  unsigned __int64 v54; // r15
  __int64 v55; // rcx
  unsigned __int64 v56; // r13
  __int64 v57; // rax
  __int16 v58; // ax
  __int16 v59; // cx
  __int64 v60; // r14
  bool v61; // cf
  __int64 v63; // [rsp+0h] [rbp-110h] BYREF
  __int16 *v64; // [rsp+8h] [rbp-108h]
  int *v65; // [rsp+10h] [rbp-100h]
  __int64 v66; // [rsp+18h] [rbp-F8h]
  __int128 v67; // [rsp+20h] [rbp-F0h]
  __int128 v68; // [rsp+30h] [rbp-E0h]
  __int128 v69; // [rsp+40h] [rbp-D0h]
  __int128 v70; // [rsp+50h] [rbp-C0h]
  __int128 v71; // [rsp+60h] [rbp-B0h]
  int v72; // [rsp+7Ch] [rbp-94h] BYREF
  _DWORD *v73; // [rsp+80h] [rbp-90h]
  int *v74; // [rsp+88h] [rbp-88h]
  __int64 v75; // [rsp+90h] [rbp-80h]
  __int64 v76; // [rsp+98h] [rbp-78h]
  _BYTE *v77; // [rsp+A0h] [rbp-70h]
  __int64 v78; // [rsp+A8h] [rbp-68h] BYREF
  __int16 v79; // [rsp+B6h] [rbp-5Ah] BYREF
  __int64 **v80; // [rsp+B8h] [rbp-58h]
  __int64 v81; // [rsp+C0h] [rbp-50h]
  __int64 v82; // [rsp+C8h] [rbp-48h]
  __int64 v83; // [rsp+D0h] [rbp-40h]
  __int64 v84; // [rsp+D8h] [rbp-38h]
  unsigned int v85; // [rsp+E0h] [rbp-30h]
  unsigned int v86; // [rsp+E4h] [rbp-2Ch]

  v75 = a2; /*0x1030aecd8*/
  v79 = -1; /*0x1030aecdc*/
  v84 = *(_QWORD *)(a1 + 16); /*0x1030aece6*/
  v80 = *(__int64 ***)a1; /*0x1030aeced*/
  v6 = (__int64)&v80[1][9 * *(unsigned __int8 *)(v84 + 16) + 1]; /*0x1030aed01*/
  v7 = v80[1][9 * *(unsigned __int8 *)(v84 + 16) + 3]; /*0x1030aed05*/
  v8 = *(_WORD *)((char *)&v80[1][9 * *(unsigned __int8 *)(v84 + 16) + 4] + 1); /*0x1030aed09*/
  if ( (v8 & 2) != 0 ) /*0x1030aed0f*/
  {
    v9 = (__int64 *)v80[1][9 * *(unsigned __int8 *)(v84 + 16) + 7]; /*0x1030aed8a*/
  }
  else if ( *(char *)(v7 + 48) < 0 ) /*0x1030aed16*/
  {
    v9 = *(__int64 **)(v7 + 16); /*0x1030aed90*/
  }
  else
  {
    v9 = &v63; /*0x1030aed1b*/
    v71 = 0; /*0x1030aed22*/
    v63 = 0; /*0x1030aed26*/
    v70 = 0; /*0x1030aed2d*/
    v69 = 0; /*0x1030aed31*/
    v68 = 0; /*0x1030aed35*/
    v67 = 0; /*0x1030aed39*/
    LOWORD(v71) = 1; /*0x1030aed3d*/
    v64 = &v79; /*0x1030aed47*/
    v65 = &v72; /*0x1030aed52*/
    BYTE2(v71) = 5; /*0x1030aed56*/
    v66 = v7; /*0x1030aed5a*/
    HIDWORD(v70) = 65539; /*0x1030aed5e*/
    *(_WORD *)((char *)&v71 + 3) = 3; /*0x1030aed65*/
    v72 = *(unsigned __int16 *)(v7 + 58); /*0x1030aed70*/
    if ( (v8 & 1) == 0 ) /*0x1030aed7b*/
      *((_QWORD *)&v67 + 1) = *(_QWORD *)(v7 + 16); /*0x1030aed81*/
  }
  v81 = v7; /*0x1030aed94*/
  v76 = *(_QWORD *)(a1 + 8); /*0x1030aed9c*/
  v10 = 0; /*0x1030aeda0*/
  v11 = *(_QWORD *)(a1 + 24) == 0; /*0x1030aeda3*/
  v77 = (_BYTE *)a1; /*0x1030aeda8*/
  v83 = v6; /*0x1030aedac*/
  if ( v11 && (*((_WORD *)v80 + 30) & 0x1020) == 0 ) /*0x1030aedc0*/
  {
    v49 = **v80; /*0x1030af341*/
    if ( *(char *)(v49 + 49) < 0 && (v8 & 0x93) == 0 && (*(_BYTE *)(v83 + 24) & 0x10) == 0 ) /*0x1030af361*/
    {
      v50 = *(unsigned __int16 *)(v81 + 58); /*0x1030af36b*/
      v51 = *(_QWORD *)(v76 + 32); /*0x1030af374*/
      v52 = *(int *)(v76 + 20); /*0x1030af378*/
      v10 = 0; /*0x1030af37c*/
      v53 = 0; /*0x1030af37f*/
      if ( (__int16)v50 >= 11 ) /*0x1030af389*/
        v53 = sqlite3LogEst(a1: *(unsigned __int16 *)(v81 + 58), a2: v6, a3: v80, a4: v49, a5: v7, a6) - 33; /*0x1030af393*/
      if ( (int)v52 > 0 ) /*0x1030af399*/
      {
        v54 = v51 + 56 * v52; /*0x1030af3a3*/
        LODWORD(v82) = v53 + v50 + 28; /*0x1030af3ad*/
        v55 = (unsigned int)(v53 + v50 - 25); /*0x1030af3b4*/
        v86 = v53 + v50 - 25; /*0x1030af3b7*/
        v56 = v51 + 56; /*0x1030af3ba*/
        v85 = (__int16)v53; /*0x1030af3bf*/
        do /*0x1030af48f*/
        {
          v10 = 0; /*0x1030af3ca*/
          if ( (*(_QWORD *)(v84 + 8) & *(_QWORD *)(v56 - 16)) == 0 ) /*0x1030af3d4*/
          {
            v10 = 0; /*0x1030af3de*/
            if ( (unsigned int)termCanDriveIndex( /*0x1030af3f1*/
                                 a1: v56 - 56,
                                 a2: v83,
                                 a3: 0,
                                 a4: v55,
                                 a5: v7,
                                 a6,
                                 a7: v63,
                                 a8: v64,
                                 a9: v65,
                                 a10: v66,
                                 a11: v67,
                                 a12: *((_QWORD *)&v67 + 1),
                                 a13: v68,
                                 a14: *((_QWORD *)&v68 + 1),
                                 a15: v69,
                                 a16: *((_QWORD *)&v69 + 1),
                                 a17: v70,
                                 a18: *((_QWORD *)&v70 + 1),
                                 a19: v71,
                                 a20: *((_QWORD *)&v71 + 1)) != 0 )
            {
              v57 = v84; /*0x1030af3f7*/
              *(_WORD *)(v84 + 24) = 1; /*0x1030af3fb*/
              *(_QWORD *)(v57 + 32) = 0; /*0x1030af401*/
              *(_DWORD *)(v57 + 52) = 1; /*0x1030af409*/
              **(_QWORD **)(v57 + 64) = v56 - 56; /*0x1030af414*/
              if ( *(_BYTE *)(v81 + 63) == 2 || (v58 = v82, (*(_BYTE *)(v81 + 49) & 0x40) != 0) ) /*0x1030af428*/
                v58 = v86; /*0x1030af42a*/
              v59 = 0; /*0x1030af430*/
              if ( v58 > 0 ) /*0x1030af435*/
                v59 = v58; /*0x1030af435*/
              v60 = v84; /*0x1030af438*/
              *(_WORD *)(v84 + 18) = v59; /*0x1030af43c*/
              *(_WORD *)(v60 + 22) = 43; /*0x1030af441*/
              *(_WORD *)(v60 + 20) = sqlite3LogEstAdd(a1: v85, a2: 43); /*0x1030af455*/
              *(_DWORD *)(v60 + 48) = 0x4000; /*0x1030af45a*/
              *(_QWORD *)v60 = v75 | *(_QWORD *)(v56 - 16); /*0x1030af46a*/
              v10 = whereLoopInsert(a1: v77, a2: v60); /*0x1030af479*/
            }
          }
          if ( v10 != 0 ) /*0x1030af47f*/
            break; /*0x1030af47f*/
          v61 = v56 < v54; /*0x1030af489*/
          v56 += 56LL; /*0x1030af48c*/
        }
        while ( v61 ); /*0x1030af48f*/
      }
    }
  }
  if ( v10 == 0 )
  {
    v12 = v77; /*0x1030aedd2*/
    v13 = v84; /*0x1030aedd6*/
    v14 = v83; /*0x1030aedda*/
    if ( v9 != nullptr )
    {
      v85 = 1; /*0x1030aede4*/
      while ( v9[9] != 0 /*0x1030aee14*/
           && (unsigned int)whereUsablePartialIndex(
                              a1: *(unsigned int *)(v14 + 28),
                              a2: *(unsigned __int8 *)(v14 + 24),
                              a3: v76) == 0
           || (*((_BYTE *)v9 + 100) & 1) != 0 )
      {
        v10 = 0; /*0x1030aefae*/
LABEL_104:
        if ( (*(_BYTE *)(v14 + 25) & 2) == 0 && v10 == 0 ) /*0x1030af31c*/
        {
          v9 = (__int64 *)v9[5]; /*0x1030af322*/
          ++v85; /*0x1030af326*/
          if ( v9 != nullptr ) /*0x1030af32c*/
            continue; /*0x1030af32c*/
        }
        return v10; /*0x1030af32c*/
      }
      v15 = *(unsigned __int16 *)v9[2]; /*0x1030aee1e*/
      *(_DWORD *)(v13 + 52) = 0; /*0x1030aee21*/
      *(_BYTE *)(v13 + 17) = 0; /*0x1030aee29*/
      *(_WORD *)(v13 + 18) = 0; /*0x1030aee2e*/
      *(_QWORD *)(v13 + 24) = 0; /*0x1030aee37*/
      *(_QWORD *)v13 = v75; /*0x1030aee3f*/
      *(_WORD *)(v13 + 22) = v15; /*0x1030aee42*/
      *(_QWORD *)(v13 + 32) = v9; /*0x1030aee47*/
      *(_QWORD *)(v13 + 40) = 0; /*0x1030aee4b*/
      LOBYTE(v6) = 1; /*0x1030aee4f*/
      v11 = (*((_BYTE *)v9 + 99) & 4) == 0; /*0x1030aee52*/
      v82 = v15; /*0x1030aee56*/
      if ( v11 ) /*0x1030aee5a*/
      {
        v16 = *(int **)(*(_QWORD *)v12 + 16LL); /*0x1030aee64*/
        if ( v16 != nullptr ) /*0x1030aee6b*/
        {
          v17 = *v16; /*0x1030aee71*/
          if ( *v16 > 0 ) /*0x1030aee75*/
          {
            v86 = *(_DWORD *)(v14 + 28); /*0x1030aee80*/
            v74 = v16; /*0x1030aee83*/
            v73 = v16 + 2; /*0x1030aee8e*/
            v18 = 0; /*0x1030aee95*/
            while ( 2 ) /*0x1030aeea3*/
            {
              for ( i = *(char **)&v73[6 * v18]; ; i = *v22 ) /*0x1030aeea3*/
              {
                if ( i == nullptr ) /*0x1030aeeaa*/
                  goto LABEL_44; /*0x1030aeeaa*/
                v20 = *((_DWORD *)i + 1); /*0x1030aeeb0*/
                if ( (v20 & 0x82000) == 0 ) /*0x1030aeebb*/
                  break; /*0x1030aeebb*/
                if ( (v20 & 0x80000) != 0 ) /*0x1030aeec1*/
                {
                  v22 = (char **)(*((_QWORD *)i + 4) + 8LL); /*0x1030aeed7*/
                }
                else
                {
                  v21 = *i; /*0x1030aeec3*/
                  if ( *i != 114 ) /*0x1030aeeca*/
                    goto LABEL_28; /*0x1030aeeca*/
                  v22 = (char **)(i + 16); /*0x1030aeecc*/
                }
              }
              v21 = *i; /*0x1030aeee1*/
LABEL_28:
              if ( (v21 | 2) == 0xAA && *((_DWORD *)i + 10) == v86 ) /*0x1030aeefb*/
              {
                v23 = *((_WORD *)i + 22); /*0x1030aeefd*/
                if ( v23 < 0 ) /*0x1030aef06*/
                {
                  LODWORD(v6) = 0; /*0x1030af337*/
LABEL_49:
                  v13 = v84; /*0x1030aefc0*/
                  v14 = v83; /*0x1030aefc4*/
                  goto LABEL_50; /*0x1030aefc4*/
                }
                v13 = v84; /*0x1030aef13*/
                v14 = v83; /*0x1030aef17*/
                if ( *((_WORD *)v9 + 47) != 0 ) /*0x1030aef1b*/
                {
                  v6 = v9[1]; /*0x1030aef1d*/
                  v24 = 0; /*0x1030aef21*/
                  while ( v23 != *(_WORD *)(v6 + 2 * v24) ) /*0x1030aef27*/
                  {
                    if ( *((unsigned __int16 *)v9 + 47) == ++v24 ) /*0x1030aef33*/
                      goto LABEL_44; /*0x1030aef33*/
                  }
                  LODWORD(v6) = 0; /*0x1030aefb6*/
LABEL_50:
                  LOWORD(v15) = v82; /*0x1030aefc8*/
                  goto LABEL_51; /*0x1030aefc8*/
                }
              }
              else
              {
                v25 = v9[10]; /*0x1030aef37*/
                if ( v25 != 0 ) /*0x1030aef3e*/
                {
                  v26 = *((_WORD *)v9 + 47); /*0x1030aef40*/
                  if ( v26 != 0 ) /*0x1030aef47*/
                  {
                    v27 = (_QWORD *)(v25 + 8); /*0x1030aef49*/
                    v28 = 0; /*0x1030aef4d*/
                    while ( 1 ) /*0x1030aef50*/
                    {
                      if ( *(_WORD *)(v9[1] + 2 * v28) == 0xFFFE ) /*0x1030aef5a*/
                      {
                        if ( (unsigned int)sqlite3ExprCompareSkip(a1: i, a2: *v27, a3: v86) == 0 ) /*0x1030aef6c*/
                        {
                          LODWORD(v6) = 0; /*0x1030aefba*/
                          v12 = v77; /*0x1030aefbc*/
                          goto LABEL_49; /*0x1030aefbc*/
                        }
                        v26 = *((_WORD *)v9 + 47); /*0x1030aef6e*/
                      }
                      ++v28; /*0x1030aef72*/
                      v27 += 3; /*0x1030aef78*/
                      if ( v28 >= v26 ) /*0x1030aef7f*/
                      {
                        v17 = *v74; /*0x1030aef88*/
                        v12 = v77; /*0x1030aef8a*/
                        break; /*0x1030aef8a*/
                      }
                    }
                  }
                }
              }
LABEL_44:
              if ( ++v18 < v17 ) /*0x1030aef97*/
                continue; /*0x1030aef97*/
              break;
            }
            v13 = v84; /*0x1030aef9d*/
            v14 = v83; /*0x1030aefa1*/
            LOWORD(v15) = v82; /*0x1030aefa5*/
            LOBYTE(v6) = 1; /*0x1030aefa9*/
          }
        }
      }
LABEL_51:
      v29 = *(_WORD *)((char *)v9 + 99); /*0x1030aefcc*/
      if ( (~(_BYTE)v29 & 3) == 0 ) /*0x1030aefd7*/
      {
        v30 = v85; /*0x1030aefdc*/
        if ( (_BYTE)v6 != 0 ) /*0x1030aefe4*/
          v30 = 0; /*0x1030aefe4*/
        *(_DWORD *)(v13 + 48) = 256; /*0x1030aefe7*/
        *(_BYTE *)(v13 + 17) = v30; /*0x1030aefef*/
        *(_WORD *)(v13 + 20) = v15 + 16; /*0x1030aeff6*/
        whereLoopOutputAdjust(a1: v76, a2: v13, a3: (unsigned int)(__int16)v15); /*0x1030af005*/
        v31 = *(_WORD *)(v14 + 25); /*0x1030af00a*/
        if ( (v31 & 4) != 0 ) /*0x1030af012*/
        {
          if ( (v31 & 0x40) != 0 ) /*0x1030af016*/
            *(_BYTE *)(v13 + 51) |= 2u; /*0x1030af018*/
          *(_QWORD *)(v13 + 40) = *(_QWORD *)(**(_QWORD **)(v14 + 64) + 72LL); /*0x1030af029*/
        }
        v10 = whereLoopInsert(a1: v12, a2: v13); /*0x1030af038*/
        *(_WORD *)(v13 + 22) = v82; /*0x1030af03f*/
        if ( v10 != 0 ) /*0x1030af047*/
          return v10; /*0x1030af047*/
LABEL_102:
        v12[32] = 0; /*0x1030af2e6*/
        v10 = whereLoopAddBtreeIndex(a1: v12, a2: v14, a3: v9, a4: 0); /*0x1030af2fb*/
        if ( v12[32] == 1 ) /*0x1030af303*/
          *(_BYTE *)(v81 + 49) |= 1u; /*0x1030af309*/
        goto LABEL_104; /*0x1030af309*/
      }
      v86 = v6; /*0x1030af052*/
      if ( (v29 & 0x20) != 0 )
      {
        v78 = 0; /*0x1030af0c5*/
        v37 = 576; /*0x1030af0cd*/
      }
      else
      {
        v32 = *(_QWORD *)(v14 + 32) & v9[13]; /*0x1030af05d*/
        v78 = v32; /*0x1030af062*/
        v33 = v9[9]; /*0x1030af066*/
        v34 = v80; /*0x1030af06d*/
        if ( v33 != 0 ) /*0x1030af071*/
        {
          wherePartIdxExpr(a1: *v80, a2: (__int64)v9, a3: v33, a4: &v78, a5: 0, a6: 0); /*0x1030af083*/
          v32 = v78; /*0x1030af088*/
        }
        *(_DWORD *)(v13 + 48) = 512; /*0x1030af08c*/
        v35 = -v32; /*0x1030af097*/
        if ( __OFSUB__(-v32, 1)
          || (*(_WORD *)((_BYTE *)v9 + 99) & 0x800) != 0
          && ((unsigned __int8)(v35 = (*(_WORD *)((_BYTE *)v9 + 99) & 0x400) != 0) | (v32 == 0)) == 0 )
        {
          IsCoveringIndex = whereIsCoveringIndex(a1: v34, a2: v9, a3: *(unsigned int *)(v14 + 28), a4: v35); /*0x1030af0ab*/
          if ( IsCoveringIndex == 0 ) /*0x1030af0b2*/
            goto LABEL_68; /*0x1030af0b2*/
          v78 = 0; /*0x1030af0b7*/
          v37 = *(_DWORD *)(v13 + 48) | IsCoveringIndex; /*0x1030af0bf*/
        }
        else if ( v32 != 0
               || (v37 = 576, *(char *)(v81 + 48) < 0)
               && v80[4] == nullptr
               && (qword_10CD98350 == nullptr || (unsigned int)qword_10CD98350(a1: 700) == 0) )
        {
LABEL_68:
          v38 = v85; /*0x1030af0d7*/
          v39 = v82; /*0x1030af0de*/
          if ( (_BYTE)v86 == 0
            || (v38 = 0, *(char *)(v81 + 48) < 0)
            || v9[9] != 0
            || (*(_BYTE *)(v14 + 25) & 2) != 0
            || v78 == 0
            && (*((_BYTE *)v9 + 99) & 4) == 0
            && *((_WORD *)v9 + 46) < *(_WORD *)(v81 + 60)
            && (*((_BYTE *)v80 + 60) & 4) == 0
            && byte_10CD981C7 != 0
            && (*(_BYTE *)(**v80 + 96) & 0x20) == 0 )
          {
            *(_BYTE *)(v13 + 17) = v38; /*0x1030af159*/
            v40 = 15 * *((__int16 *)v9 + 46) / *(__int16 *)(v81 + 60) + v39 + 1; /*0x1030af174*/
            *(_WORD *)(v13 + 20) = v40; /*0x1030af176*/
            v41 = v80; /*0x1030af180*/
            if ( v78 != 0 )
            {
              v42 = v39 + 16; /*0x1030af18a*/
              if ( *((int *)v80 + 31) <= 0 )
              {
                v13 = v84; /*0x1030af273*/
              }
              else
              {
                v86 = *(_DWORD *)(v83 + 28); /*0x1030af19f*/
                v43 = 20; /*0x1030af1a2*/
                v44 = 0; /*0x1030af1a8*/
                while ( 1 )
                {
                  v45 = v41[17]; /*0x1030af1ab*/
                  if ( (unsigned int)sqlite3ExprCoveredByIndex( /*0x1030af1c4*/
                                       a1: *(__int64 *)((char *)v45 + v43 - 20),
                                       a2: v86,
                                       a3: v9) == 0 )
                    break; /*0x1030af1c4*/
                  v46 = *(unsigned __int16 *)((char *)v45 + v43 - 4); /*0x1030af1ca*/
                  if ( (__int16)v46 > 0 )
                    v46 = (*((_BYTE *)v45 + v43) & 0x82) == 0 ? -1 : 0xFFEC;
                  v47 = v42 + v46; /*0x1030af1e9*/
                  ++v44; /*0x1030af1ec*/
                  v41 = v80; /*0x1030af1ef*/
                  v43 += 56; /*0x1030af1f7*/
                  v42 = v47; /*0x1030af1fb*/
                  if ( v44 >= *((int *)v80 + 31) ) /*0x1030af201*/
                    goto LABEL_96; /*0x1030af201*/
                }
                LOWORD(v47) = v42; /*0x1030af279*/
LABEL_96:
                v13 = v84; /*0x1030af27c*/
                v40 = *(_WORD *)(v84 + 20); /*0x1030af280*/
                LOWORD(v42) = v47; /*0x1030af285*/
                v12 = v77; /*0x1030af288*/
                LOWORD(v39) = v82; /*0x1030af28c*/
              }
              *(_WORD *)(v13 + 20) = sqlite3LogEstAdd(a1: (unsigned int)v40, a2: (unsigned int)(__int16)v42); /*0x1030af29c*/
              v14 = v83; /*0x1030af2a1*/
            }
            whereLoopOutputAdjust(a1: v76, a2: v13, a3: (unsigned int)(__int16)v39); /*0x1030af2b0*/
            if ( (*(_BYTE *)(v14 + 24) & 0x10) != 0 && v9[10] != 0 ) /*0x1030af2c2*/
            {
              *(_WORD *)(v13 + 22) = v39; /*0x1030af2c4*/
            }
            else
            {
              v48 = whereLoopInsert(a1: v12, a2: v13); /*0x1030af2d1*/
              *(_WORD *)(v13 + 22) = v39; /*0x1030af2d9*/
              if ( v48 != 0 ) /*0x1030af2e0*/
                return v48; /*0x1030af49a*/
            }
          }
          goto LABEL_102; /*0x1030af2c9*/
        }
      }
      *(_DWORD *)(v13 + 48) = v37; /*0x1030af0d3*/
      goto LABEL_68; /*0x1030af0d3*/
    }
  }
  return v10; /*0x1030af4a0*/
}

// Address: 0x1030af4b2 | Name: _whereLoopAddOr
__int64 __fastcall whereLoopAddOr(_QWORD *a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6)
{
  _QWORD *v6; // r15
  __int64 v7; // rcx
  __int64 v8; // rax
  __int64 v9; // rdx
  unsigned __int64 v10; // r12
  __int64 v11; // r8
  __int64 v12; // rcx
  __int64 v13; // rdx
  __int64 result; // rax
  __int64 v15; // rdx
  unsigned __int64 v16; // rax
  __int128 v17; // xmm0
  unsigned __int64 v18; // rdx
  __int64 v19; // rcx
  unsigned __int64 v20; // rax
  int v21; // r15d
  bool v22; // zf
  unsigned __int64 v23; // rax
  _QWORD *v24; // rax
  int v25; // eax
  int v26; // r15d
  __int16 v27; // ax
  char *v28; // rbx
  unsigned __int64 v29; // r12
  _QWORD *v30; // r14
  __int64 v31; // r15
  __int16 v32; // r13
  __int16 v33; // ax
  unsigned int v34; // edx
  __int64 v35; // rcx
  _OWORD *v36; // rax
  unsigned __int64 v37; // rbx
  _WORD *v38; // r14
  __int64 v39; // rsi
  _QWORD v41[2]; // [rsp+8h] [rbp-368h] BYREF
  char v42; // [rsp+18h] [rbp-358h]
  int v43; // [rsp+1Ch] [rbp-354h]
  int v44; // [rsp+24h] [rbp-34Ch]
  unsigned __int64 v45; // [rsp+28h] [rbp-348h]
  __int16 v46; // [rsp+1F0h] [rbp-180h]
  _QWORD v47[6]; // [rsp+1F8h] [rbp-178h] BYREF
  unsigned __int16 v48; // [rsp+228h] [rbp-148h] BYREF
  char v49[10]; // [rsp+230h] [rbp-140h] BYREF
  char v50; // [rsp+23Ah] [rbp-136h] BYREF
  __int128 v51; // [rsp+260h] [rbp-110h] BYREF
  __int128 v52; // [rsp+270h] [rbp-100h]
  __int64 v53; // [rsp+280h] [rbp-F0h]
  _QWORD *v54; // [rsp+290h] [rbp-E0h]
  unsigned __int64 v55; // [rsp+298h] [rbp-D8h]
  unsigned __int64 v56; // [rsp+2A0h] [rbp-D0h]
  unsigned __int64 v57; // [rsp+2A8h] [rbp-C8h]
  __int64 v58; // [rsp+2B0h] [rbp-C0h]
  unsigned __int64 v59; // [rsp+2B8h] [rbp-B8h]
  _QWORD *v60; // [rsp+2C0h] [rbp-B0h]
  _OWORD *v61; // [rsp+2C8h] [rbp-A8h]
  _QWORD v62[6]; // [rsp+2D0h] [rbp-A0h] BYREF
  __int64 v63; // [rsp+300h] [rbp-70h]
  __int64 v64; // [rsp+310h] [rbp-60h]
  _QWORD *v65; // [rsp+318h] [rbp-58h]
  int v66; // [rsp+324h] [rbp-4Ch]
  __int64 v67; // [rsp+328h] [rbp-48h]
  unsigned __int64 v68; // [rsp+330h] [rbp-40h]
  __int64 v69; // [rsp+338h] [rbp-38h]
  unsigned int v70; // [rsp+344h] [rbp-2Ch]

  v64 = a3; /*0x1030af4c6*/
  v67 = a2; /*0x1030af4ca*/
  v6 = a1; /*0x1030af4ce*/
  v7 = *a1; /*0x1030af4d1*/
  v8 = a1[1]; /*0x1030af4d4*/
  v9 = a1[2]; /*0x1030af4d8*/
  v10 = *(_QWORD *)(v8 + 32); /*0x1030af4dc*/
  v60 = (_QWORD *)v8; /*0x1030af4e0*/
  v11 = *(unsigned int *)(v8 + 20); /*0x1030af4e7*/
  memset(v62, 0, sizeof(v62)); /*0x1030af4f9*/
  v63 = 0; /*0x1030af500*/
  v12 = *(_QWORD *)(v7 + 8); /*0x1030af508*/
  v69 = v9; /*0x1030af50c*/
  v13 = 9LL * *(unsigned __int8 *)(v9 + 16); /*0x1030af514*/
  result = 0; /*0x1030af52b*/
  if ( (*(_BYTE *)(v12 + 8 * v13 + 32) & 0x10) == 0 && (int)v11 > 0 ) /*0x1030af524*/
  {
    v59 = v10 + 56LL * (int)v11; /*0x1030af541*/
    v58 = v12 + 8 * v13 + 8; /*0x1030af550*/
    v66 = *(_DWORD *)(v12 + 8 * v13 + 36); /*0x1030af55a*/
    v61 = (_OWORD *)(v69 + 24); /*0x1030af565*/
    v65 = a1; /*0x1030af56c*/
    while ( 1 ) /*0x1030af576*/
    {
      result = 0; /*0x1030af576*/
      if ( (*(_BYTE *)(v10 + 21) & 2) != 0 ) /*0x1030af57b*/
      {
        v15 = *(_QWORD *)(v10 + 32); /*0x1030af581*/
        if ( (*(_QWORD *)(v69 + 8) & *(_QWORD *)(v15 + 488)) != 0 ) /*0x1030af595*/
        {
          v16 = *(_QWORD *)(v15 + 32) + 56LL * *(int *)(v15 + 20); /*0x1030af5a3*/
          v17 = *(_OWORD *)v6; /*0x1030af5a7*/
          v52 = *((_OWORD *)v6 + 1); /*0x1030af5b0*/
          v53 = v6[4]; /*0x1030af5bb*/
          v51 = v17; /*0x1030af5c2*/
          *((_QWORD *)&v52 + 1) = &v48; /*0x1030af5d0*/
          v18 = *(_QWORD *)(v15 + 32); /*0x1030af5d7*/
          LODWORD(v19) = 0; /*0x1030af5db*/
          v57 = v16; /*0x1030af5dd*/
          if ( v18 < v16 ) /*0x1030af5e7*/
          {
            v20 = v18; /*0x1030af5ed*/
            v19 = 0; /*0x1030af5f0*/
            v21 = 1; /*0x1030af5f2*/
            v56 = v10; /*0x1030af5f8*/
            do /*0x1030af5ff*/
            {
              v22 = (*(_BYTE *)(v20 + 21) & 4) == 0; /*0x1030af5ff*/
              v68 = v20; /*0x1030af603*/
              if ( v22 ) /*0x1030af607*/
              {
                v18 = v68; /*0x1030af60c*/
                v23 = v68; /*0x1030af613*/
                if ( *(_DWORD *)(v68 + 28) != v66 ) /*0x1030af617*/
                  goto LABEL_29; /*0x1030af617*/
                v19 = (__int64)v60; /*0x1030af61d*/
                v18 = v68; /*0x1030af624*/
                v41[0] = *v60; /*0x1030af62a*/
                v41[1] = v60; /*0x1030af631*/
                v42 = 44; /*0x1030af638*/
                v43 = 1; /*0x1030af644*/
                v44 = 1; /*0x1030af64a*/
                v45 = v68; /*0x1030af650*/
                v24 = v41; /*0x1030af657*/
              }
              else
              {
                v24 = *(_QWORD **)(v20 + 32); /*0x1030af660*/
              }
              *((_QWORD *)&v51 + 1) = v24; /*0x1030af664*/
              v48 = 0; /*0x1030af66b*/
              if ( *(_BYTE *)(*(_QWORD *)(v58 + 16) + 63LL) == 1 ) /*0x1030af683*/
                v25 = whereLoopAddVirtual(a1: (_QWORD ***)&v51, a2: v67, a3: v64); /*0x1030af694*/
              else
                v25 = whereLoopAddBtree(a1: (__int64)&v51, a2: v67, a3: v18, a4: v19, a5: v11, a6); /*0x1030af6a6*/
              LODWORD(v19) = v25; /*0x1030af6ab*/
              if ( v25 == 0 ) /*0x1030af6af*/
                LODWORD(v19) = whereLoopAddOr(a1: &v51, a2: v67, a3: v64, a4: 0); /*0x1030af6c5*/
              if ( v48 == 0 ) /*0x1030af6d1*/
              {
                LOWORD(v62[0]) = 0; /*0x1030af818*/
                break; /*0x1030af818*/
              }
              v70 = v19; /*0x1030af6d7*/
              if ( v21 != 0 ) /*0x1030af6dd*/
              {
                LOWORD(v62[0]) = v48; /*0x1030af7d9*/
                __memcpy_chk(a1: &v62[1], a2: v49, a3: 16 * (unsigned int)v48, a4: 48); /*0x1030af7f6*/
              }
              else
              {
                v26 = LOWORD(v62[0]); /*0x1030af6e3*/
                v46 = v62[0]; /*0x1030af6eb*/
                __memcpy_chk(a1: v47, a2: &v62[1], a3: 16 * (unsigned int)LOWORD(v62[0]), a4: 48); /*0x1030af70c*/
                LOWORD(v62[0]) = 0; /*0x1030af711*/
                if ( v26 != 0 ) /*0x1030af71d*/
                {
                  v27 = 1; /*0x1030af723*/
                  v18 = 0; /*0x1030af727*/
                  do /*0x1030af7d1*/
                  {
                    if ( v27 != 0 ) /*0x1030af72c*/
                    {
                      v55 = v18; /*0x1030af732*/
                      v54 = &v47[2 * v18]; /*0x1030af747*/
                      v28 = &v50; /*0x1030af74e*/
                      v29 = 0; /*0x1030af755*/
                      do /*0x1030af7ab*/
                      {
                        v30 = v54; /*0x1030af75c*/
                        v31 = *v54 | *(_QWORD *)(v28 - 10); /*0x1030af763*/
                        v32 = sqlite3LogEstAdd( /*0x1030af774*/
                                a1: (unsigned int)*((__int16 *)v54 + 4),
                                a2: (unsigned int)*((__int16 *)v28 - 1));
                        v33 = sqlite3LogEstAdd( /*0x1030af77f*/
                                a1: (unsigned int)*((__int16 *)v30 + 5),
                                a2: (unsigned int)*(__int16 *)v28);
                        whereOrInsert(a1: v62, a2: v31, a3: (unsigned int)v32, a4: (unsigned int)v33); /*0x1030af795*/
                        ++v29; /*0x1030af79a*/
                        v27 = v48; /*0x1030af79d*/
                        v28 += 16; /*0x1030af7a4*/
                      }
                      while ( v29 < v48 ); /*0x1030af7ab*/
                      LOWORD(v26) = v46; /*0x1030af7ad*/
                      v10 = v56; /*0x1030af7b5*/
                      v18 = v55; /*0x1030af7bc*/
                    }
                    else
                    {
                      v27 = 0; /*0x1030af7c5*/
                    }
                    ++v18; /*0x1030af7c7*/
                  }
                  while ( v18 < (unsigned __int16)v26 ); /*0x1030af7d1*/
                }
              }
              v21 = 0; /*0x1030af7fb*/
              v19 = v70; /*0x1030af7fe*/
              v23 = v68; /*0x1030af801*/
LABEL_29:
              v20 = v23 + 56; /*0x1030af805*/
            }
            while ( v20 < v57 ); /*0x1030af5ff*/
          }
          v34 = v19; /*0x1030af821*/
          v35 = v69; /*0x1030af823*/
          *(_WORD *)(v69 + 52) = 1; /*0x1030af827*/
          **(_QWORD **)(v35 + 64) = v10; /*0x1030af831*/
          *(_DWORD *)(v35 + 48) = 0x2000; /*0x1030af834*/
          *(_WORD *)(v35 + 18) = 0; /*0x1030af83b*/
          *(_BYTE *)(v35 + 17) = 0; /*0x1030af841*/
          v36 = v61; /*0x1030af848*/
          *v61 = 0; /*0x1030af84f*/
          *((_QWORD *)v36 + 2) = 0; /*0x1030af852*/
          result = v34; /*0x1030af85a*/
          if ( v34 != 0 ) /*0x1030af85e*/
          {
            v6 = v65; /*0x1030af8bc*/
          }
          else
          {
            v6 = v65; /*0x1030af868*/
            if ( LOWORD(v62[0]) != 0 ) /*0x1030af86c*/
            {
              v37 = 1; /*0x1030af86e*/
              v38 = (_WORD *)&v62[2] + 1; /*0x1030af873*/
              do /*0x1030af8b8*/
              {
                v39 = v69; /*0x1030af880*/
                *(_WORD *)(v69 + 20) = *(_DWORD *)(v38 - 1) + 1; /*0x1030af884*/
                *(_WORD *)(v39 + 22) = *v38; /*0x1030af88c*/
                *(_QWORD *)v39 = *(_QWORD *)(v38 - 5); /*0x1030af894*/
                result = whereLoopInsert(a1: v6, a2: v39); /*0x1030af89a*/
                if ( (_DWORD)result != 0 ) /*0x1030af8a1*/
                  break; /*0x1030af8a1*/
                v38 += 8; /*0x1030af8a3*/
              }
              while ( v37++ < LOWORD(v62[0]) ); /*0x1030af8b8*/
            }
          }
        }
      }
      if ( (_DWORD)result == 0 ) /*0x1030af8c2*/
      {
        v10 += 56LL; /*0x1030af8c4*/
        if ( v10 < v59 ) /*0x1030af8cf*/
          continue; /*0x1030af8cf*/
      }
      return result; /*0x1030af8cf*/
    }
  }
  return result; /*0x1030af8d5*/
}

// Address: 0x1030af8e7 | Name: _whereLoopClear
__int64 __fastcall whereLoopClear(__int64 a1, __int64 a2)
{
  __int64 v4; // rsi
  __int64 result; // rax

  v4 = *(_QWORD *)(a2 + 64); /*0x1030af8f7*/
  if ( v4 != a2 + 80 ) /*0x1030af902*/
  {
    sqlite3DbFreeNN(a1, a2: v4); /*0x1030af907*/
    *(_QWORD *)(a2 + 64) = a2 + 80; /*0x1030af90c*/
    *(_WORD *)(a2 + 56) = 3; /*0x1030af910*/
  }
  result = whereLoopClearUnion(a1, a2); /*0x1030af91c*/
  *(_WORD *)(a2 + 52) = 0; /*0x1030af921*/
  *(_DWORD *)(a2 + 48) = 0; /*0x1030af927*/
  return result; /*0x1030af932*/
}

// Address: 0x1030af939 | Name: _whereLoopResize
__int64 __fastcall whereLoopResize(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6)
{
  unsigned int v6; // ebx
  __int64 v9; // r14
  void *v10; // rax
  void *v11; // r13
  __int64 v12; // rsi

  v6 = 0; /*0x1030af94b*/
  if ( *(unsigned __int16 *)(a2 + 56) < (int)a3 ) /*0x1030af94f*/
  {
    v9 = ((_DWORD)a3 + 7) & 0xFFFFFFF8; /*0x1030af95e*/
    v10 = (void *)sqlite3DbMallocRawNN(a1, a2: 8 * v9, a3, a4, a5, a6); /*0x1030af96a*/
    if ( v10 != nullptr ) /*0x1030af972*/
    {
      v11 = v10; /*0x1030af974*/
      memcpy(__dst: v10, __src: *(const void **)(a2 + 64), __n: 8 * (unsigned int)*(unsigned __int16 *)(a2 + 56)); /*0x1030af986*/
      v12 = *(_QWORD *)(a2 + 64); /*0x1030af98b*/
      if ( v12 != a2 + 80 ) /*0x1030af996*/
        sqlite3DbFreeNN(a1, a2: v12); /*0x1030af99b*/
      *(_QWORD *)(a2 + 64) = v11; /*0x1030af9a0*/
      *(_WORD *)(a2 + 56) = v9; /*0x1030af9a4*/
    }
    else
    {
      return 7; /*0x1030af9ab*/
    }
  }
  return v6; /*0x1030af9b6*/
}

// Address: 0x1030afa30 | Name: _whereLoopAddVirtualOne
__int64 __fastcall whereLoopAddVirtualOne(
        __int64 *a1,
        __int64 a2,
        __int64 a3,
        unsigned __int16 a4,
        int *a5,
        unsigned __int16 a6,
        _DWORD *a7,
        _DWORD *a8)
{
  __int64 v8; // rax
  __int64 v9; // rbx
  __int64 v10; // rdi
  _DWORD *v11; // r12
  __int64 v12; // r14
  __int64 v13; // r13
  __int64 v14; // r15
  __int64 v15; // r14
  __int64 v16; // rax
  int v17; // esi
  __int64 v18; // rdx
  int v19; // r9d
  __int64 v20; // r10
  int v21; // edi
  bool v22; // cc
  __int64 v23; // rdi
  __int64 v24; // rax
  __int64 v25; // r13
  _QWORD **v26; // rcx
  _QWORD *v27; // rdx
  __int64 v28; // rdi
  __int64 v29; // rcx
  int v30; // r8d
  int v31; // r9d
  unsigned int v32; // r14d
  __int64 v33; // rdi
  const char *v34; // rdx
  int v35; // r14d
  unsigned int i; // r13d
  unsigned int j; // r13d
  unsigned int v38; // r14d
  unsigned __int64 v39; // rdx
  unsigned __int64 v40; // rcx
  __int64 v41; // rsi
  __int64 v42; // r8
  __int64 v43; // r9
  int *v44; // r11
  __int64 v45; // rdi
  unsigned __int64 k; // rax
  __int64 v47; // r10
  int v48; // r11d
  __int64 v49; // r10
  __int64 v50; // r11
  __int64 v51; // r10
  int v52; // r11d
  void **v53; // rax
  void **v54; // rbx
  char v56; // al
  double v57; // xmm0_8
  __int16 v58; // ax
  int *v59; // rbx
  int *v60; // rbx
  __int64 v61; // [rsp+8h] [rbp-68h]
  __int64 v62; // [rsp+18h] [rbp-58h]
  _QWORD *v63; // [rsp+20h] [rbp-50h]
  unsigned int v65; // [rsp+30h] [rbp-40h]
  _DWORD *v67; // [rsp+38h] [rbp-38h]

  v8 = *a1; /*0x1030afa49*/
  v9 = a1[1]; /*0x1030afa4c*/
  v67 = *((_DWORD **)a5 + 4); /*0x1030afa54*/
  v10 = a1[2]; /*0x1030afa5c*/
  v11 = *(_DWORD **)v8; /*0x1030afa60*/
  v12 = *(_QWORD *)(v8 + 8); /*0x1030afa63*/
  v13 = *(unsigned __int8 *)(v10 + 16); /*0x1030afa67*/
  v14 = *a5; /*0x1030afa6c*/
  *a7 = 0; /*0x1030afa6f*/
  v61 = v10; /*0x1030afa76*/
  *(_QWORD *)v10 = a2; /*0x1030afa7a*/
  v15 = v12 + 8; /*0x1030afa7d*/
  if ( v14 > 0 ) /*0x1030afa84*/
  {
    v16 = *((_QWORD *)a5 + 1); /*0x1030afa86*/
    v17 = 0; /*0x1030afa8a*/
    v18 = ~a3; /*0x1030afa8c*/
    do /*0x1030afaf1*/
    {
      if ( v9 != 0 ) /*0x1030afa92*/
      {
        v19 = *(_DWORD *)(v16 + 8); /*0x1030afa94*/
        v20 = v9; /*0x1030afa98*/
        v21 = v19; /*0x1030afa9b*/
        while ( 1 ) /*0x1030afa9e*/
        {
          v22 = v21 < *(_DWORD *)(v20 + 20); /*0x1030afa9e*/
          v21 -= *(_DWORD *)(v20 + 20); /*0x1030afa9e*/
          if ( v22 ) /*0x1030afaa2*/
            break; /*0x1030afaa2*/
          v20 = *(_QWORD *)(v20 + 8); /*0x1030afaa4*/
          v19 = v21; /*0x1030afaa8*/
          if ( v20 == 0 ) /*0x1030afaae*/
            goto LABEL_7; /*0x1030afaae*/
        }
        v23 = *(_QWORD *)(v20 + 32) + 56LL * v19; /*0x1030afabb*/
      }
      else
      {
LABEL_7:
        v23 = 0; /*0x1030afab0*/
      }
      *(_BYTE *)(v16 + 5) = 0; /*0x1030afabf*/
      if ( (v18 & *(_QWORD *)(v23 + 40)) == 0 /*0x1030afae2*/
        && (a4 & *(_WORD *)(v23 + 20)) == 0
        && (a8 != nullptr || (unsigned __int8)(*(_BYTE *)(v23 + 23) - 75) <= 0xFDu) )
      {
        *(_BYTE *)(v16 + 5) = 1; /*0x1030afae4*/
      }
      ++v17; /*0x1030afae8*/
      v16 += 12; /*0x1030afaea*/
    }
    while ( v17 != (_DWORD)v14 ); /*0x1030afaf1*/
  }
  __bzero(a1: v67, a2: 8 * v14); /*0x1030afb07*/
  *((_QWORD *)a5 + 6) = 0; /*0x1030afb10*/
  a5[10] = 0; /*0x1030afb1a*/
  a5[15] = 0; /*0x1030afb1d*/
  *((_QWORD *)a5 + 8) = 0x546D42AEA2879F2ELL; /*0x1030afb2a*/
  *((_QWORD *)a5 + 9) = 25; /*0x1030afb2e*/
  a5[20] = 0; /*0x1030afb36*/
  a5[30] = 0; /*0x1030afb39*/
  v63 = (_QWORD *)(v15 + 72 * v13 + 16); /*0x1030afb46*/
  v24 = *(_QWORD *)v11; /*0x1030afb4d*/
  v25 = *v63 + 80LL; /*0x1030afb51*/
  v26 = (_QWORD **)v25; /*0x1030afb55*/
  do /*0x1030afb62*/
  {
    v27 = *v26; /*0x1030afb58*/
    v26 = (_QWORD **)(*v26 + 5); /*0x1030afb5b*/
  }
  while ( *v27 != v24 ); /*0x1030afb62*/
  v28 = v27[2]; /*0x1030afb64*/
  ++*(_DWORD *)(v24 + 72); /*0x1030afb68*/
  v62 = v28; /*0x1030afb6e*/
  v32 = (*(__int64 (**)(void))(*(_QWORD *)v28 + 24LL))(); /*0x1030afb75*/
  v33 = *(_QWORD *)v11; /*0x1030afb78*/
  --*(_DWORD *)(*(_QWORD *)v11 + 72LL); /*0x1030afb7c*/
  if ( v32 != 0 && v32 != 19 ) /*0x1030afb87*/
  {
    if ( v32 == 7 ) /*0x1030afb8d*/
    {
      sqlite3OomFault(a1: v33); /*0x1030afb8f*/
    }
    else
    {
      v34 = *(const char **)(v62 + 16); /*0x1030afb9a*/
      if ( v34 == nullptr ) /*0x1030afba1*/
      {
        switch ( v32 ) /*0x1030afea0*/
        {
          case 0x204u: /*0x1030afea0*/
            v34 = "abort due to ROLLBACK"; /*0x1030affe9*/
            break;
          case 0x65u: /*0x1030afea0*/
            v34 = "no more rows available"; /*0x1030affdd*/
            break;
          case 0x64u: /*0x1030afea0*/
            v34 = "another row available"; /*0x1030afeba*/
            break;
          default:
            v34 = "unknown error"; /*0x1030afff9*/
            if ( (unsigned __int8)v32 <= 0x1Cu ) /*0x1030b0003*/
            {
              v29 = 21037060; /*0x1030b0009*/
              if ( !_bittest64(&v29, (unsigned __int8)v32) ) /*0x1030b0012*/
              {
                v29 = (__int64)sqlite3ErrStr_aMsg; /*0x1030b001a*/
                v34 = sqlite3ErrStr_aMsg[(unsigned __int8)v32]; /*0x1030b0021*/
              }
            }
            break;
        }
      }
      sqlite3ErrorMsg(a1: (_DWORD)v11, a2: (unsigned int)"%s", a3: (_DWORD)v34, a4: v29, a5: v30, a6: v31); /*0x1030afbb3*/
    }
  }
  v65 = v32; /*0x1030afbb8*/
  if ( *(_BYTE *)(*(_QWORD *)v25 + 29LL) != 0 ) /*0x1030afbc4*/
  {
    v35 = *(_DWORD *)(*(_QWORD *)v11 + 40LL); /*0x1030afbca*/
    if ( v35 > 0 ) /*0x1030afbd1*/
    {
      for ( i = 0; i != v35; ++i ) /*0x1030afbd3*/
        sqlite3CodeVerifySchema(a1: v11, a2: i); /*0x1030afbdc*/
      if ( v11[30] != 0 ) /*0x1030afbef*/
      {
        for ( j = 0; j != v35; ++j ) /*0x1030afbf1*/
          sqlite3BeginWriteOperation(a1: v11, a2: 0, a3: j); /*0x1030afbfc*/
      }
    }
  }
  sqlite3_free(a1: *(void **)(v62 + 16)); /*0x1030afc11*/
  *(_QWORD *)(v62 + 16) = 0; /*0x1030afc16*/
  v38 = v65; /*0x1030afc1e*/
  if ( v65 != 0 ) /*0x1030afc25*/
  {
    if ( v65 != 19 ) /*0x1030afc2b*/
      return v38; /*0x1030afc2b*/
    v38 = 0; /*0x1030afc31*/
LABEL_73:
    v53 = (void **)a5; /*0x1030afe1f*/
    goto LABEL_74; /*0x1030afe1f*/
  }
  __bzero(a1: *(_QWORD *)(v61 + 64), a2: 8 * v14); /*0x1030afc45*/
  *(_OWORD *)(v61 + 24) = 0; /*0x1030afc4e*/
  *(_QWORD *)(v61 + 40) = 0; /*0x1030afc54*/
  if ( (int)v14 > 0 ) /*0x1030afc5f*/
  {
    v44 = a5; /*0x1030afc65*/
    v45 = *((_QWORD *)a5 + 1); /*0x1030afc69*/
    v42 = a6; /*0x1030afc6d*/
    v41 = 0xFFFFFFFFLL; /*0x1030afc72*/
    v43 = 0; /*0x1030afc77*/
    for ( k = 0; k != v14; ++k ) /*0x1030afc7a*/
    {
      v40 = (unsigned __int64)v67; /*0x1030afc7c*/
      v39 = (unsigned int)v67[2 * k]; /*0x1030afc80*/
      if ( (int)v39 > 0 ) /*0x1030afc85*/
      {
        if ( (int)v39 > (int)v14 ) /*0x1030afc8e*/
          goto LABEL_72; /*0x1030afc8e*/
        LODWORD(v40) = *(_DWORD *)(v45 + 8); /*0x1030afc94*/
        if ( (v40 & 0x80000000) != 0LL || v9 == 0 ) /*0x1030afca2*/
          goto LABEL_72; /*0x1030afca2*/
        v39 = (unsigned int)(v39 - 1); /*0x1030afca8*/
        v47 = v9; /*0x1030afcaa*/
        v48 = *(_DWORD *)(v45 + 8); /*0x1030afcad*/
        while ( 1 ) /*0x1030afcb0*/
        {
          v22 = v48 < *(_DWORD *)(v47 + 20); /*0x1030afcb0*/
          v48 -= *(_DWORD *)(v47 + 20); /*0x1030afcb0*/
          if ( v22 ) /*0x1030afcb4*/
            break; /*0x1030afcb4*/
          v47 = *(_QWORD *)(v47 + 8); /*0x1030afcb6*/
          LODWORD(v40) = v48; /*0x1030afcba*/
          if ( v47 == 0 ) /*0x1030afcc0*/
            goto LABEL_72; /*0x1030afcc0*/
        }
        v49 = *(_QWORD *)(v47 + 32); /*0x1030afcc7*/
        if ( v49 == 0 /*0x1030afcea*/
          || *(_QWORD *)((v50 = *(_QWORD *)(v61 + 64)) + 8LL * (unsigned int)v39) != 0
          || *(_BYTE *)(v45 + 5) == 0 )
        {
LABEL_72:
          sqlite3ErrorMsg( /*0x1030afdfe*/
            a1: (_DWORD)v11,
            a2: (unsigned int)"%s.xBestIndex malfunction",
            a3: *(_QWORD *)*v63,
            a4: v40,
            a5: a6,
            a6: 0);
          v38 = 1; /*0x1030afe19*/
          goto LABEL_73; /*0x1030afe19*/
        }
        v51 = 56LL * (int)v40 + v49; /*0x1030afcf7*/
        *(_QWORD *)v61 |= *(_QWORD *)(v51 + 40); /*0x1030afcfe*/
        *(_QWORD *)(v50 + 8LL * (unsigned int)v39) = v51; /*0x1030afd02*/
        if ( (int)v39 > (int)v41 ) /*0x1030afd08*/
          v41 = (unsigned int)v39; /*0x1030afd08*/
        if ( LOBYTE(v67[2 * k + 1]) != 0 ) /*0x1030afd14*/
        {
          if ( k <= 0xF && !_bittest((const int *)&v42, k) ) /*0x1030afd20*/
            *(_WORD *)(v61 + 30) |= 1 << v39; /*0x1030afd2d*/
          if ( *(_BYTE *)(v51 + 23) == 74 ) /*0x1030afd37*/
            *(_BYTE *)(v61 + 28) |= 2u; /*0x1030afd39*/
        }
        v52 = 1 << k; /*0x1030afd46*/
        if ( k >= 0x20 ) /*0x1030afd4d*/
          v52 = 0; /*0x1030afd4d*/
        v40 = (unsigned __int64)a5; /*0x1030afd51*/
        if ( (v52 & a5[30]) != 0 ) /*0x1030afd59*/
        {
          v40 = (unsigned int)v39; /*0x1030afd61*/
          *(_DWORD *)(v61 + 40) |= 1 << v39; /*0x1030afd66*/
          v44 = a5; /*0x1030afd6a*/
        }
        else
        {
          v44 = a5; /*0x1030afd70*/
          if ( (*(_BYTE *)(v51 + 20) & 1) != 0 ) /*0x1030afd78*/
          {
            a5[15] = 0; /*0x1030afd7a*/
            *((_BYTE *)a5 + 80) &= ~1u; /*0x1030afd82*/
            v40 = (unsigned __int64)a7; /*0x1030afd87*/
            *a7 = 1; /*0x1030afd8b*/
          }
        }
        if ( (unsigned __int8)(*(_BYTE *)(v51 + 23) - 75) >= 0xFEu ) /*0x1030afd9b*/
        {
          v40 = (unsigned __int64)a7; /*0x1030afd9d*/
          if ( *a7 != 0 ) /*0x1030afda4*/
            goto LABEL_92; /*0x1030afda4*/
          if ( k != 0 ) /*0x1030afdad*/
          {
            v40 = 0; /*0x1030afdaf*/
            while ( 1 ) /*0x1030afdb1*/
            {
              v39 = (unsigned __int64)v67; /*0x1030afdb1*/
              if ( (int)v67[2 * v40] <= 0 ) /*0x1030afdb9*/
                break; /*0x1030afdb9*/
              if ( k == ++v40 ) /*0x1030afdc5*/
                goto LABEL_66; /*0x1030afdc5*/
            }
LABEL_92:
            if ( v44[14] != 0 ) /*0x1030affae*/
            {
              v60 = v44; /*0x1030affb4*/
              sqlite3_free(a1: *((void **)v44 + 6)); /*0x1030affb7*/
              *((_QWORD *)v60 + 6) = 0; /*0x1030affbc*/
              v60[14] = 0; /*0x1030affc4*/
            }
            *a8 = 1; /*0x1030affcf*/
            return 0; /*0x1030affd8*/
          }
        }
      }
LABEL_66:
      v45 += 12; /*0x1030afdca*/
    }
    *(_WORD *)(v61 + 52) = v41 + 1; /*0x1030afdda*/
    if ( (int)v41 < 0 ) /*0x1030afde1*/
      goto LABEL_78; /*0x1030afde1*/
    v40 = *(_QWORD *)(v61 + 64); /*0x1030afde3*/
    v39 = 0; /*0x1030afde7*/
    while ( *(_QWORD *)(v40 + 8 * v39) != 0 ) /*0x1030afdee*/
    {
      if ( (_DWORD)v41 + 1 == ++v39 ) /*0x1030afdfa*/
        goto LABEL_78; /*0x1030afdfa*/
    }
    sqlite3ErrorMsg( /*0x1030b0040*/
      a1: (_DWORD)v11,
      a2: (unsigned int)"%s.xBestIndex malfunction",
      a3: *(_QWORD *)*v63,
      a4: v40,
      a5: a6,
      a6: 0);
    v53 = (void **)a5; /*0x1030b0045*/
    v38 = 1; /*0x1030b0049*/
LABEL_74:
    if ( *((_DWORD *)v53 + 14) != 0 ) /*0x1030afe27*/
    {
      v54 = v53; /*0x1030afe2d*/
      sqlite3_free(a1: v53[6]); /*0x1030afe30*/
      v54[6] = nullptr; /*0x1030afe35*/
      *((_DWORD *)v54 + 14) = 0; /*0x1030afe3d*/
    }
    return v38; /*0x1030afe3d*/
  }
  *(_WORD *)(v61 + 52) = 0; /*0x1030afe56*/
  v44 = a5; /*0x1030afe5d*/
LABEL_78:
  *(_DWORD *)(v61 + 24) = v44[10]; /*0x1030afe61*/
  *(_BYTE *)(v61 + 28) = v44[14] & 1 | *(_BYTE *)(v61 + 28) & 0xFE; /*0x1030afe78*/
  v44[14] = 0; /*0x1030afe7c*/
  *(_QWORD *)(v61 + 32) = *((_QWORD *)v44 + 6); /*0x1030afe88*/
  if ( v44[15] != 0 ) /*0x1030afe91*/
    v56 = *((_BYTE *)v44 + 16); /*0x1030afe93*/
  else
    v56 = 0; /*0x1030afec6*/
  *(_BYTE *)(v61 + 29) = v56; /*0x1030afecc*/
  LOBYTE(v40) = (2 * *((_BYTE *)v44 + 80)) & 4 | *(_BYTE *)(v61 + 28) & 0xFB; /*0x1030afedf*/
  *(_BYTE *)(v61 + 28) = v40; /*0x1030afee1*/
  *(_WORD *)(v61 + 18) = 0; /*0x1030afee5*/
  v57 = *((double *)v44 + 8); /*0x1030afeec*/
  if ( v57 <= 1.0 ) /*0x1030afefe*/
  {
    v58 = 0; /*0x1030aff23*/
  }
  else if ( v57 <= 2000000000.0 ) /*0x1030aff0c*/
  {
    v58 = sqlite3LogEst(a1: (unsigned int)(int)v57, a2: v41, a3: v39, a4: 0, a5: v42, a6: v43); /*0x1030aff46*/
    v44 = a5; /*0x1030aff4b*/
  }
  else
  {
    v58 = 10 * (*(_QWORD *)&v57 >> 52) - 10220; /*0x1030aff1c*/
  }
  *(_WORD *)(v61 + 20) = v58; /*0x1030aff4f*/
  v59 = v44; /*0x1030aff58*/
  *(_WORD *)(v61 + 22) = sqlite3LogEst(a1: *((_QWORD *)v44 + 9), a2: v41, a3: v39, a4: v40, a5: v42, a6: v43); /*0x1030aff60*/
  *(_DWORD *)(v61 + 48) = *(_DWORD *)(v61 + 48) & 0xFFFFEFFF | ((v59[20] & 1) << 12); /*0x1030aff79*/
  v38 = whereLoopInsert(a1, a2: v61); /*0x1030aff88*/
  if ( (*(_BYTE *)(v61 + 28) & 1) != 0 ) /*0x1030aff90*/
  {
    sqlite3_free(a1: *(void **)(v61 + 32)); /*0x1030aff9a*/
    *(_BYTE *)(v61 + 28) &= ~1u; /*0x1030aff9f*/
  }
  return v38; /*0x1030afe47*/
}

// Address: 0x1030b0054 | Name: _whereLoopInsert
__int64 __fastcall whereLoopInsert(__int64 a1, __int128 *a2)
{
  int v3; // eax
  __int64 **v5; // r15
  __int64 *v6; // r13
  char v7; // r14
  int v8; // ecx
  __int16 v9; // ax
  int v10; // ecx
  __int64 v11; // rdi
  unsigned int v12; // r14d
  _WORD *v13; // rax
  __int64 *Lesser; // rax
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // r8
  __int64 v18; // r9
  __int64 *v19; // r12
  __int64 v20; // r15
  __int64 v21; // r14
  __int64 *v22; // r12
  __int64 *v23; // rax
  __int64 v24; // r13
  __int64 v25; // rax
  __int64 v26; // rcx
  __int64 v27; // r8
  __int64 v28; // r9
  __int64 v29; // rdx
  __int128 v30; // xmm0
  __int128 v31; // xmm1
  int v32; // eax
  __int64 v33; // rax
  __int64 v35; // [rsp+0h] [rbp-30h]

  v3 = *(_DWORD *)(a1 + 36); /*0x1030b0065*/
  if ( v3 != 0 ) /*0x1030b006a*/
  {
    v5 = *(__int64 ***)a1; /*0x1030b0073*/
    v35 = ***(_QWORD ***)a1; /*0x1030b007d*/
    *(_DWORD *)(a1 + 36) = v3 - 1; /*0x1030b0083*/
    v6 = v5[10]; /*0x1030b0088*/
    if ( v6 != nullptr && (a2[3] & 0x200) != 0 ) /*0x1030b009d*/
    {
      v7 = *((_BYTE *)a2 + 16); /*0x1030b00a3*/
      while ( 1 ) /*0x1030b00a7*/
      {
        if ( *((_BYTE *)v6 + 16) == v7 && (*((_BYTE *)v6 + 49) & 2) != 0 ) /*0x1030b00b2*/
        {
          if ( (unsigned int)whereLoopCheaperProperSubset(a1: v6, a2) != 0 ) /*0x1030b00c1*/
            break; /*0x1030b00c1*/
          if ( (unsigned int)whereLoopCheaperProperSubset(a1: a2, a2: v6) != 0 ) /*0x1030b00f6*/
          {
            v10 = *((_DWORD *)a2 + 5); /*0x1030b00fc*/
            if ( (__int16)*((_DWORD *)v6 + 5) > (__int16)v10 ) /*0x1030b0102*/
              LOWORD(v10) = *((_DWORD *)v6 + 5); /*0x1030b0102*/
            *((_WORD *)a2 + 10) = v10; /*0x1030b0105*/
            v9 = *((_WORD *)v6 + 11) + 1; /*0x1030b0114*/
            if ( *((_WORD *)v6 + 11) < *((_WORD *)a2 + 11) ) /*0x1030b0119*/
              v9 = *((_WORD *)a2 + 11); /*0x1030b0119*/
            goto LABEL_18; /*0x1030b0119*/
          }
        }
LABEL_19:
        v6 = (__int64 *)v6[9]; /*0x1030b0120*/
        if ( v6 == nullptr ) /*0x1030b0127*/
          goto LABEL_20; /*0x1030b0127*/
      }
      v8 = *((_DWORD *)a2 + 5); /*0x1030b00c7*/
      if ( (__int16)*((_DWORD *)v6 + 5) < (__int16)v8 ) /*0x1030b00cd*/
        LOWORD(v8) = *((_DWORD *)v6 + 5); /*0x1030b00cd*/
      *((_WORD *)a2 + 10) = v8; /*0x1030b00d0*/
      v9 = *((_WORD *)v6 + 11) - 1; /*0x1030b00df*/
      if ( *((_WORD *)v6 + 11) > *((_WORD *)a2 + 11) ) /*0x1030b00e4*/
        v9 = *((_WORD *)a2 + 11); /*0x1030b00e4*/
LABEL_18:
      *((_WORD *)a2 + 11) = v9; /*0x1030b011c*/
      goto LABEL_19; /*0x1030b011c*/
    }
LABEL_20:
    v11 = *(_QWORD *)(a1 + 24); /*0x1030b012d*/
    if ( v11 != 0 ) /*0x1030b0135*/
    {
      v12 = 0; /*0x1030b0137*/
      if ( *((_WORD *)a2 + 26) != 0 ) /*0x1030b013f*/
        whereOrInsert( /*0x1030b0150*/
          a1: v11,
          a2: *(_QWORD *)a2,
          a3: (unsigned int)*((__int16 *)a2 + 10),
          a4: (unsigned int)*((__int16 *)a2 + 11));
    }
    else
    {
      Lesser = (__int64 *)whereLoopFindLesser(a1: v5 + 10, a2); /*0x1030b0182*/
      if ( Lesser != nullptr ) /*0x1030b018a*/
      {
        v19 = Lesser; /*0x1030b018c*/
        v20 = *Lesser; /*0x1030b018f*/
        if ( *Lesser != 0 ) /*0x1030b0195*/
        {
          v21 = v35; /*0x1030b019c*/
          if ( *(_QWORD *)(v20 + 72) != 0 ) /*0x1030b01a0*/
          {
            v22 = (__int64 *)(v20 + 72); /*0x1030b01a6*/
            do /*0x1030b01ec*/
            {
              v23 = (__int64 *)whereLoopFindLesser(a1: v22, a2); /*0x1030b01b0*/
              if ( v23 == nullptr ) /*0x1030b01b8*/
                break; /*0x1030b01b8*/
              v22 = v23; /*0x1030b01be*/
              v24 = *v23; /*0x1030b01c1*/
              if ( *v23 == 0 ) /*0x1030b01c7*/
                break; /*0x1030b01c7*/
              *v23 = *(_QWORD *)(v24 + 72); /*0x1030b01cd*/
              whereLoopClear(a1: v35, a2: v24); /*0x1030b01d7*/
              sqlite3DbNNFreeNN(a1: v35, a2: v24); /*0x1030b01e2*/
            }
            while ( *v22 != 0 ); /*0x1030b01ec*/
          }
        }
        else
        {
          v21 = v35; /*0x1030b01fd*/
          v25 = sqlite3DbMallocRawNN(a1: v35, a2: 104, a3: v15, a4: v16, a5: v17, a6: v18); /*0x1030b0204*/
          *v19 = v25; /*0x1030b0209*/
          if ( v25 == 0 ) /*0x1030b0210*/
            return 7; /*0x1030b0302*/
          v20 = v25; /*0x1030b0216*/
          *(_QWORD *)(v25 + 64) = v25 + 80; /*0x1030b021d*/
          *(_WORD *)(v25 + 52) = 0; /*0x1030b0221*/
          *(_WORD *)(v25 + 56) = 3; /*0x1030b0228*/
          *(_DWORD *)(v25 + 48) = 0; /*0x1030b022f*/
          *(_QWORD *)(v25 + 72) = 0; /*0x1030b0237*/
        }
        whereLoopClearUnion(a1: v21, a2: v20); /*0x1030b0245*/
        v29 = *((unsigned __int16 *)a2 + 26); /*0x1030b024a*/
        if ( (unsigned __int16)v29 > *(_WORD *)(v20 + 56) /*0x1030b0262*/
          && (unsigned int)whereLoopResize(a1: v21, a2: v20, a3: v29, a4: v26, a5: v27, a6: v28) != 0 )
        {
          *(_OWORD *)(v20 + 32) = 0; /*0x1030b0267*/
          *(_OWORD *)(v20 + 16) = 0; /*0x1030b026c*/
          *(_OWORD *)v20 = 0; /*0x1030b0271*/
          *(_QWORD *)(v20 + 48) = 0; /*0x1030b0275*/
          v12 = 7; /*0x1030b027d*/
        }
        else
        {
          *(_QWORD *)(v20 + 48) = *((_QWORD *)a2 + 6); /*0x1030b0289*/
          v30 = *a2; /*0x1030b028d*/
          v31 = a2[1]; /*0x1030b0290*/
          *(_OWORD *)(v20 + 32) = a2[2]; /*0x1030b0298*/
          *(_OWORD *)(v20 + 16) = v31; /*0x1030b029d*/
          *(_OWORD *)v20 = v30; /*0x1030b02a2*/
          memcpy( /*0x1030b02b6*/
            __dst: *(void **)(v20 + 64),
            __src: *((const void **)a2 + 8),
            __n: 8 * (unsigned int)*(unsigned __int16 *)(v20 + 52));
          v32 = *((_DWORD *)a2 + 12); /*0x1030b02bb*/
          if ( (v32 & 0x400) != 0 ) /*0x1030b02c2*/
          {
            *((_BYTE *)a2 + 28) &= ~1u; /*0x1030b02d7*/
            v12 = 0; /*0x1030b02db*/
          }
          else
          {
            v12 = 0; /*0x1030b02c4*/
            if ( (v32 & 0x4000) != 0 ) /*0x1030b02cb*/
              *((_QWORD *)a2 + 4) = 0; /*0x1030b02cd*/
          }
        }
        if ( (*(_BYTE *)(v20 + 49) & 4) == 0 ) /*0x1030b02e3*/
        {
          v33 = *(_QWORD *)(v20 + 32); /*0x1030b02e5*/
          if ( v33 != 0 && (~*(_BYTE *)(v33 + 99) & 3) == 0 ) /*0x1030b02f6*/
            *(_QWORD *)(v20 + 32) = 0; /*0x1030b02f8*/
        }
      }
      else
      {
        return 0; /*0x1030b01f0*/
      }
    }
  }
  else
  {
    v13 = *(_WORD **)(a1 + 24); /*0x1030b015a*/
    v12 = 101; /*0x1030b015f*/
    if ( v13 != nullptr ) /*0x1030b0168*/
      *v13 = 0; /*0x1030b016e*/
  }
  return v12; /*0x1030b030f*/
}

// Address: 0x1030b031a | Name: _whereOrInsert
__int64 __fastcall whereOrInsert(unsigned __int16 *a1, __int64 a2, signed __int16 a3, signed __int16 a4)
{
  __int64 result; // rax
  unsigned __int16 *v5; // r8
  unsigned __int16 *v6; // r9
  __int16 v7; // r11
  signed __int16 v8; // bx
  unsigned __int16 *v9; // rdi

  result = *a1; /*0x1030b0321*/
  v5 = a1 + 4; /*0x1030b0324*/
  if ( *a1 != 0 ) /*0x1030b032b*/
  {
    v6 = a1 + 4; /*0x1030b0333*/
    v7 = *a1; /*0x1030b0336*/
    while ( 1 ) /*0x1030b0339*/
    {
      v8 = v6[4]; /*0x1030b0339*/
      if ( v8 >= a3 && (~*(_QWORD *)v6 & a2) == 0 ) /*0x1030b034c*/
        break; /*0x1030b034c*/
      if ( v8 <= a3 && (~a2 & *(_QWORD *)v6) == 0 ) /*0x1030b0356*/
        return result; /*0x1030b0356*/
      v6 += 8; /*0x1030b0358*/
      if ( --v7 == 0 ) /*0x1030b0360*/
      {
        if ( (unsigned __int16)result < 3u ) /*0x1030b0366*/
          goto LABEL_9; /*0x1030b0366*/
        v9 = a1 + 12; /*0x1030b0396*/
        --result; /*0x1030b039a*/
        do /*0x1030b03b9*/
        {
          v6 = v9; /*0x1030b03a2*/
          if ( (__int16)v5[4] <= (__int16)v9[4] ) /*0x1030b03aa*/
            v6 = v5; /*0x1030b03ac*/
          v9 += 8; /*0x1030b03af*/
          v5 = v6; /*0x1030b03b3*/
          --result; /*0x1030b03b6*/
        }
        while ( result != 0 ); /*0x1030b03b9*/
        if ( (__int16)v6[4] > a3 ) /*0x1030b03c0*/
          break; /*0x1030b03c0*/
        return result; /*0x1030b03c0*/
      }
    }
  }
  else
  {
LABEL_9:
    *a1 = result + 1; /*0x1030b0368*/
    result = (unsigned int)(16 * result); /*0x1030b0370*/
    v6 = (unsigned __int16 *)((char *)v5 + (unsigned int)result); /*0x1030b0373*/
    v6[5] = a4; /*0x1030b0377*/
  }
  *(_QWORD *)v6 = a2; /*0x1030b037d*/
  v6[4] = a3; /*0x1030b0380*/
  if ( (__int16)v6[5] > a4 ) /*0x1030b038a*/
    v6[5] = a4; /*0x1030b038c*/
  return result; /*0x1030b0391*/
}

// Address: 0x1030b03c4 | Name: _whereLoopFindLesser
_QWORD *__fastcall whereLoopFindLesser(_QWORD *a1, __int64 a2)
{
  _QWORD *result; // rax
  __int64 i; // rcx
  __int64 v4; // r8

  result = a1; /*0x1030b03c4*/
  for ( i = *a1; i != 0; i = *(_QWORD *)(i + 72) ) /*0x1030b03cd*/
  {
    if ( *(_BYTE *)(i + 16) == *(_BYTE *)(a2 + 16) && *(_BYTE *)(i + 17) == *(_BYTE *)(a2 + 17) ) /*0x1030b03e7*/
    {
      if ( (*(_BYTE *)(i + 49) & 0x40) != 0 /*0x1030b040c*/
        && *(_WORD *)(a2 + 54) == 0
        && (~*(_DWORD *)(a2 + 48) & 0x201) == 0
        && (~*(_QWORD *)i & *(_QWORD *)a2) == 0 )
      {
        return result; /*0x1030b040c*/
      }
      v4 = *(_QWORD *)i & *(_QWORD *)a2; /*0x1030b0417*/
      if ( v4 == *(_QWORD *)i /*0x1030b0441*/
        && *(_WORD *)(i + 18) <= *(_WORD *)(a2 + 18)
        && *(_WORD *)(i + 20) <= *(_WORD *)(a2 + 20)
        && *(_WORD *)(i + 22) <= *(_WORD *)(a2 + 22) )
      {
        return nullptr; /*0x1030b0475*/
      }
      if ( v4 == *(_QWORD *)a2 && *(_WORD *)(i + 20) >= *(_WORD *)(a2 + 20) && *(_WORD *)(i + 22) >= *(_WORD *)(a2 + 22) ) /*0x1030b045a*/
        return result; /*0x1030b045a*/
    }
    result = (_QWORD *)(i + 72); /*0x1030b0463*/
  }
  return result; /*0x1030b0474*/
}

// Address: 0x1030b0479 | Name: _whereLoopCheaperProperSubset
__int64 __fastcall whereLoopCheaperProperSubset(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  int v3; // edx
  int v4; // r8d
  __int64 v5; // rcx
  __int64 v6; // r9
  __int64 v7; // r10

  if ( *(_WORD *)(a1 + 20) <= *(_WORD *)(a2 + 20) || (result = 0, *(_WORD *)(a1 + 22) <= *(_WORD *)(a2 + 22)) ) /*0x1030b048d*/
  {
    if ( *(_WORD *)(a1 + 24) >= *(_WORD *)(a2 + 24) /*0x1030b04b3*/
      || *(_QWORD *)(a1 + 32) != *(_QWORD *)(a2 + 32)
      || *(_WORD *)(a1 + 54) != 0
      || *(_WORD *)(a2 + 54) != 0 )
    {
      v3 = *(unsigned __int16 *)(a1 + 54); /*0x1030b04b5*/
      v4 = *(unsigned __int16 *)(a2 + 54); /*0x1030b04b9*/
      result = 0; /*0x1030b04be*/
      if ( (unsigned __int16)v4 <= (unsigned __int16)v3 ) /*0x1030b04c4*/
      {
        v5 = *(unsigned __int16 *)(a1 + 52); /*0x1030b04c6*/
        if ( *(unsigned __int16 *)(a1 + 52) - v3 < *(unsigned __int16 *)(a2 + 52) - v4 ) /*0x1030b04dd*/
        {
          if ( *(_WORD *)(a1 + 52) != 0 ) /*0x1030b04e7*/
          {
            while ( 1 ) /*0x1030b04ed*/
            {
              v6 = *(_QWORD *)(*(_QWORD *)(a1 + 64) + 8 * v5 - 8); /*0x1030b04ed*/
              if ( v6 != 0 ) /*0x1030b04f5*/
                break; /*0x1030b04f5*/
LABEL_14:
              if ( v5-- <= 1 ) /*0x1030b0515*/
                goto LABEL_15; /*0x1030b051c*/
            }
            v7 = *(unsigned __int16 *)(a2 + 52); /*0x1030b04f7*/
            while ( v7 > 0 ) /*0x1030b04fd*/
            {
              if ( *(_QWORD *)(*(_QWORD *)(a2 + 64) + 8 * v7-- - 8) == v6 ) /*0x1030b0507*/
                goto LABEL_14; /*0x1030b050f*/
            }
          }
          else
          {
LABEL_15:
            if ( (*(_BYTE *)(a1 + 48) & 0x40) == 0 || (*(_BYTE *)(a2 + 48) & 0x40) != 0 ) /*0x1030b0528*/
              return 1; /*0x1030b052a*/
          }
        }
      }
    }
    else
    {
      return 1; /*0x1030b0532*/
    }
  }
  return result; /*0x1030b0531*/
}

// Address: 0x1030b0538 | Name: _whereLoopClearUnion
void __fastcall whereLoopClearUnion(__int64 a1, __int64 a2)
{
  int v2; // eax
  __int64 v5; // rsi
  __int64 *v6; // rbx

  v2 = *(_DWORD *)(a2 + 48); /*0x1030b0538*/
  if ( (v2 & 0x4400) != 0 ) /*0x1030b0540*/
  {
    if ( (v2 & 0x400) != 0 && (*(_BYTE *)(a2 + 28) & 1) != 0 ) /*0x1030b0559*/
    {
      sqlite3_free(a1: *(void **)(a2 + 32)); /*0x1030b0597*/
      *(_BYTE *)(a2 + 28) &= ~1u; /*0x1030b059c*/
      v6 = (__int64 *)(a2 + 32); /*0x1030b05a0*/
LABEL_10:
      *v6 = 0; /*0x1030b05a3*/
      return; /*0x1030b05a3*/
    }
    if ( (v2 & 0x4000) != 0 ) /*0x1030b055f*/
    {
      v5 = *(_QWORD *)(a2 + 32); /*0x1030b0561*/
      if ( v5 != 0 ) /*0x1030b0568*/
      {
        v6 = (__int64 *)(a2 + 32); /*0x1030b056a*/
        if ( *(_QWORD *)(v5 + 32) != 0 ) /*0x1030b0575*/
        {
          sqlite3DbFreeNN(a1, a2: *(_QWORD *)(v5 + 32)); /*0x1030b057d*/
          v5 = *v6; /*0x1030b0582*/
        }
        sqlite3DbFreeNN(a1, a2: v5); /*0x1030b0588*/
        goto LABEL_10; /*0x1030b058d*/
      }
    }
  }
}

// Address: 0x1030b0639 | Name: _whereUsablePartialIndex
__int64 __fastcall whereUsablePartialIndex(unsigned int a1, unsigned __int8 a2, int *a3, _BYTE *a4)
{
  unsigned int v4; // r12d
  _BYTE *v5; // rbx
  char *v7; // r13
  int v8; // r12d
  __int64 v9; // r15
  __int64 v11; // [rsp+8h] [rbp-38h]

  v4 = 0; /*0x1030b064d*/
  if ( (a2 & 0x40) != 0 ) /*0x1030b0657*/
    return v4; /*0x1030b0657*/
  v5 = a4; /*0x1030b065d*/
  v11 = **(_QWORD **)a3; /*0x1030b0669*/
  if ( *a4 != 44 ) /*0x1030b0670*/
  {
LABEL_5:
    if ( a3[5] <= 0 ) /*0x1030b069b*/
      return v4; /*0x1030b069b*/
    v7 = *((char **)a3 + 4); /*0x1030b069d*/
    v8 = 0; /*0x1030b06a1*/
    while ( 1 ) /*0x1030b06a4*/
    {
      v9 = *(_QWORD *)v7; /*0x1030b06a4*/
      if ( (*(_BYTE *)(*(_QWORD *)v7 + 4LL) & 1) != 0 ) /*0x1030b06ad*/
      {
        if ( *(_DWORD *)(v9 + 48) != a1 ) /*0x1030b06be*/
          goto LABEL_14; /*0x1030b06be*/
      }
      else if ( (a2 & 0x20) != 0 ) /*0x1030b06b3*/
      {
        goto LABEL_14; /*0x1030b06b3*/
      }
      if ( (unsigned int)sqlite3ExprImpliesExpr(a1: v11, a2: *(_QWORD *)v7, a3: v5, a4: a1) != 0 /*0x1030b06f3*/
        && (unsigned int)sqlite3ExprImpliesExpr(a1: v11, a2: v9, a3: v5, a4: 0xFFFFFFFFLL) == 0
        && v7[18] >= 0 )
      {
        return 1; /*0x1030b071d*/
      }
LABEL_14:
      ++v8; /*0x1030b06f5*/
      v7 += 56; /*0x1030b06f8*/
      if ( v8 >= a3[5] ) /*0x1030b0700*/
        return 0; /*0x1030b0702*/
    }
  }
  while ( (unsigned int)whereUsablePartialIndex(a1, a2, a3) != 0 ) /*0x1030b068b*/
  {
    v5 = *((_BYTE **)v5 + 3); /*0x1030b068d*/
    if ( *v5 != 44 ) /*0x1030b0694*/
      goto LABEL_5; /*0x1030b0694*/
  }
  return v4; /*0x1030b0708*/
}

// Address: 0x1030b071f | Name: _whereLoopOutputAdjust
__int64 __fastcall whereLoopOutputAdjust(__int64 a1, __int64 a2, int a3)
{
  int v4; // r13d
  __int64 v6; // r12
  __int64 v7; // r14
  __int64 v8; // r9
  __int64 v9; // rax
  __int64 v11; // rcx
  __int64 v12; // r8
  __int64 v13; // rdi
  __int64 v14; // rdi
  _DWORD **v15; // r8
  _DWORD *v16; // r10
  __int16 v17; // cx
  __int16 v18; // ax
  __int64 v19; // rdi
  int IsInteger; // eax
  unsigned int v21; // ecx
  __int64 result; // rax
  int v23; // ecx
  __int64 v24; // [rsp+8h] [rbp-38h]
  int v25; // [rsp+10h] [rbp-30h]
  _DWORD v26[11]; // [rsp+14h] [rbp-2Ch] BYREF

  v4 = *(_DWORD *)(a1 + 28); /*0x1030b0733*/
  if ( v4 <= 0 ) /*0x1030b073a*/
  {
    result = 0; /*0x1030b088e*/
  }
  else
  {
    v6 = ~(*(_QWORD *)a2 | *(_QWORD *)(a2 + 8)); /*0x1030b074a*/
    v7 = *(_QWORD *)(a1 + 32); /*0x1030b074d*/
    v8 = 0; /*0x1030b0751*/
    do /*0x1030b0770*/
    {
      v9 = *(_QWORD *)(v7 + 48); /*0x1030b0758*/
      if ( (v6 & v9) == 0 ) /*0x1030b075f*/
      {
        v11 = *(_QWORD *)(a2 + 8); /*0x1030b0777*/
        if ( (v9 & v11) != 0 && (*(_BYTE *)(v7 + 18) & 2) == 0 ) /*0x1030b0785*/
        {
          v12 = *(unsigned __int16 *)(a2 + 52); /*0x1030b0787*/
          if ( *(_WORD *)(a2 + 52) != 0 ) /*0x1030b078f*/
          {
            while ( 1 ) /*0x1030b0795*/
            {
              v13 = *(_QWORD *)(*(_QWORD *)(a2 + 64) + 8 * v12 - 8); /*0x1030b0795*/
              if ( v13 != 0 ) /*0x1030b079d*/
              {
                if ( v13 == v7 ) /*0x1030b07a2*/
                  break; /*0x1030b07a2*/
                v14 = *(int *)(v13 + 24); /*0x1030b07a4*/
                if ( v14 >= 0 && *(_QWORD *)(a1 + 32) + 56 * v14 == v7 ) /*0x1030b07b8*/
                  break; /*0x1030b07b8*/
              }
              if ( --v12 == 0 ) /*0x1030b07bd*/
                goto LABEL_14; /*0x1030b07bd*/
            }
          }
          else
          {
LABEL_14:
            v15 = *(_DWORD ***)a1; /*0x1030b07bf*/
            v16 = **(_DWORD ***)a1; /*0x1030b07c2*/
            if ( *(_DWORD *)(*(_QWORD *)v16 + 384LL) != 0 ) /*0x1030b07d0*/
            {
              ++v16[14]; /*0x1030b07d2*/
              v16[6] = 9; /*0x1030b07d6*/
            }
            if ( v11 == v9 /*0x1030b0801*/
              && ((*(_BYTE *)(v7 + 20) & 0x3F) != 0 || (v15[1][18 * *(unsigned __int8 *)(a2 + 16) + 8] & 0x48) == 0) )
            {
              *(_BYTE *)(a2 + 50) |= 0x80u; /*0x1030b07ea*/
            }
            v17 = *(_WORD *)(v7 + 16); /*0x1030b0803*/
            v18 = *(_WORD *)(a2 + 22); /*0x1030b0808*/
            if ( v17 <= 0 ) /*0x1030b080f*/
            {
              *(_WORD *)(a2 + 22) = v17 + v18; /*0x1030b087f*/
            }
            else
            {
              *(_WORD *)(a2 + 22) = v18 - 1; /*0x1030b0813*/
              if ( (*(_BYTE *)(v7 + 20) & 0x82) != 0 ) /*0x1030b081c*/
              {
                v25 = a3; /*0x1030b0822*/
                v19 = *(_QWORD *)(*(_QWORD *)v7 + 24LL); /*0x1030b0828*/
                v26[0] = 0; /*0x1030b082c*/
                v24 = v8; /*0x1030b0835*/
                IsInteger = sqlite3ExprIsInteger(a1: v19, a2: v26, a3: 0); /*0x1030b0839*/
                v8 = v24; /*0x1030b0848*/
                v21 = 20; /*0x1030b0854*/
                if ( (unsigned int)(v26[0] + 1) < 3 ) /*0x1030b0859*/
                  v21 = 10; /*0x1030b0859*/
                if ( IsInteger == 0 ) /*0x1030b085e*/
                  v21 = 20; /*0x1030b085e*/
                if ( v21 > (unsigned __int16)v24 ) /*0x1030b0867*/
                {
                  *(_BYTE *)(v7 + 19) |= 0x20u; /*0x1030b0869*/
                  v8 = v21; /*0x1030b086e*/
                }
                a3 = v25; /*0x1030b0871*/
              }
            }
          }
        }
      }
      v7 += 56; /*0x1030b0765*/
    }
    while ( v4-- > 1 ); /*0x1030b0770*/
    result = (unsigned __int16)v8; /*0x1030b0888*/
  }
  v23 = (__int16)a3 - (_DWORD)result; /*0x1030b0897*/
  if ( v23 < *(__int16 *)(a2 + 22) ) /*0x1030b089b*/
    *(_WORD *)(a2 + 22) = v23; /*0x1030b089d*/
  return result; /*0x1030b08a1*/
}

// Address: 0x1030b08b0 | Name: _whereIsCoveringIndex
__int64 __fastcall whereIsCoveringIndex(__int64 a1, __int64 a2, int a3)
{
  __int64 result; // rax
  __int64 v4; // r8
  unsigned int v5; // ecx
  _QWORD v6[7]; // [rsp+0h] [rbp-50h] BYREF
  _DWORD v7[3]; // [rsp+38h] [rbp-18h] BYREF
  __int16 v8; // [rsp+44h] [rbp-Ch]

  result = 0; /*0x1030b08c0*/
  if ( *(_QWORD *)(a1 + 32) != 0 ) /*0x1030b08c5*/
  {
    if ( (*(_BYTE *)(a2 + 100) & 8) == 0 ) /*0x1030b08cf*/
    {
      if ( *(_WORD *)(a2 + 96) == 0 ) /*0x1030b08d8*/
        return result; /*0x1030b08d8*/
      v4 = 0; /*0x1030b08de*/
      while ( *(__int16 *)(*(_QWORD *)(a2 + 8) + 2 * v4) < 63 ) /*0x1030b08e7*/
      {
        if ( *(unsigned __int16 *)(a2 + 96) == ++v4 ) /*0x1030b08ef*/
          return 0; /*0x1030b08f3*/
      }
    }
    *(_QWORD *)v7 = a2; /*0x1030b08f9*/
    v7[2] = a3; /*0x1030b08fc*/
    v8 = 0; /*0x1030b08ff*/
    v6[0] = 0; /*0x1030b090c*/
    memset(&v6[2], 0, 24); /*0x1030b090f*/
    v6[1] = whereIsCoveringIndexWalkCallback; /*0x1030b0922*/
    v6[2] = sqlite3SelectWalkNoop; /*0x1030b092d*/
    v6[5] = v7; /*0x1030b0931*/
    ((void (__fastcall *)(_QWORD *))sqlite3WalkSelect)(a1: v6); /*0x1030b0935*/
    v5 = 0x4000000; /*0x1030b0943*/
    if ( (_BYTE)v8 == 0 ) /*0x1030b0948*/
      v5 = 64; /*0x1030b0948*/
    result = 0; /*0x1030b094b*/
    if ( HIBYTE(v8) == 0 ) /*0x1030b0951*/
      return v5; /*0x1030b0951*/
  }
  return result; /*0x1030b0954*/
}

// Address: 0x1030b09bf | Name: _whereLoopAddBtreeIndex
__int64 __fastcall whereLoopAddBtreeIndex(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  _DWORD *v6; // rsi
  unsigned int v7; // r14d
  __int64 v8; // r15
  int v9; // ecx
  int v10; // r8d
  __int64 v11; // rsi
  int v12; // edx
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // rsi
  __int64 v16; // r8
  __int64 v17; // r9
  __int64 v18; // r12
  __int64 v19; // rax
  int v20; // r13d
  __int64 v21; // rcx
  int v22; // eax
  char v23; // al
  char v24; // al
  int v25; // edx
  int v26; // eax
  __int64 v27; // rsi
  __int16 v28; // dx
  int v29; // eax
  int v30; // r14d
  int v31; // ecx
  int v32; // edx
  int v33; // eax
  int v34; // r10d
  int *v35; // rax
  __int64 v36; // rdi
  bool v37; // zf
  __int16 v38; // bx
  __int16 v39; // ax
  int v40; // r14d
  __int16 v41; // ax
  bool v42; // sf
  int v43; // eax
  __int16 v44; // bx
  int v45; // ebx
  __int16 v46; // cx
  __int64 v47; // rdi
  __int16 v48; // dx
  __int16 v49; // dx
  unsigned __int8 *v50; // rax
  unsigned __int8 v51; // cl
  int v52; // edx
  __int64 v53; // rcx
  int v54; // esi
  __int64 v55; // r9
  int v56; // edi
  __int64 v57; // rax
  __int64 v58; // r14
  __int64 v59; // rbx
  char v60; // al
  char v61; // al
  __int64 v62; // rdx
  __int64 v63; // rsi
  __int64 *v64; // rax
  __int64 v65; // rax
  __int64 v66; // rdx
  __int64 v67; // rsi
  __int64 v68; // rdi
  int v69; // eax
  __int16 v70; // si
  __int16 v71; // si
  __int16 v72; // si
  unsigned __int16 v73; // cx
  __int64 v74; // r12
  __int16 v75; // r13
  __int16 v76; // ax
  __int16 v77; // ax
  __int16 v78; // cx
  __int16 v79; // r13
  __int64 v80; // r14
  int v81; // eax
  unsigned __int16 v82; // ax
  _DWORD *v83; // rax
  __int64 *v84; // rax
  int v85; // r14d
  __int64 v86; // rax
  __int64 v87; // rcx
  unsigned __int16 v88; // dx
  __int16 v89; // cx
  unsigned __int16 v90; // di
  __int64 v91; // rcx
  __int64 v92; // r12
  __int64 v93; // rax
  unsigned int v94; // ecx
  unsigned __int16 v95; // ax
  __int64 **v97[5]; // [rsp+8h] [rbp-138h] BYREF
  unsigned __int8 v98; // [rsp+31h] [rbp-10Fh]
  __int64 v99; // [rsp+78h] [rbp-C8h]
  __int64 v100; // [rsp+80h] [rbp-C0h]
  __int64 v101; // [rsp+88h] [rbp-B8h]
  __int64 v102; // [rsp+90h] [rbp-B0h]
  __int64 v103; // [rsp+98h] [rbp-A8h]
  unsigned int v104; // [rsp+A0h] [rbp-A0h]
  int v105; // [rsp+A4h] [rbp-9Ch]
  _DWORD *v106; // [rsp+A8h] [rbp-98h]
  __int64 v107; // [rsp+B0h] [rbp-90h]
  __int64 v108; // [rsp+B8h] [rbp-88h]
  __int64 v109; // [rsp+C0h] [rbp-80h]
  __int64 v110; // [rsp+C8h] [rbp-78h]
  __int16 v111; // [rsp+D6h] [rbp-6Ah]
  int v112; // [rsp+D8h] [rbp-68h]
  unsigned int v113; // [rsp+DCh] [rbp-64h]
  __int64 v114; // [rsp+E0h] [rbp-60h]
  int v115; // [rsp+E8h] [rbp-58h]
  int v116; // [rsp+ECh] [rbp-54h]
  __int64 v117; // [rsp+F0h] [rbp-50h]
  __int64 v118; // [rsp+F8h] [rbp-48h]
  unsigned __int16 v119; // [rsp+102h] [rbp-3Eh]
  __int16 v120; // [rsp+104h] [rbp-3Ch]
  __int16 v121; // [rsp+106h] [rbp-3Ah]
  __int64 v122; // [rsp+108h] [rbp-38h]
  unsigned __int16 v123; // [rsp+116h] [rbp-2Ah]

  v6 = **(_DWORD ***)a1; /*0x1030b09dc*/
  if ( v6[14] != 0 ) /*0x1030b09e3*/
    return (unsigned int)v6[6]; /*0x1030b09e9*/
  v108 = a4; /*0x1030b09ee*/
  v8 = *(_QWORD *)(a1 + 16); /*0x1030b09f5*/
  v112 = *(_DWORD *)(v8 + 48); /*0x1030b09fd*/
  v9 = 24; /*0x1030b0a07*/
  if ( (v112 & 0x20) == 0 ) /*0x1030b0a0c*/
    v9 = 447; /*0x1030b0a0c*/
  v10 = v9 & 0x183; /*0x1030b0a16*/
  if ( (*(_WORD *)(a3 + 99) & 4) == 0 ) /*0x1030b0a1c*/
    v10 = v9; /*0x1030b0a1c*/
  v106 = v6; /*0x1030b0a20*/
  v110 = *(_QWORD *)v6; /*0x1030b0a2a*/
  v123 = *(_WORD *)(v8 + 24); /*0x1030b0a33*/
  v120 = *(_WORD *)(v8 + 26); /*0x1030b0a3f*/
  v121 = *(_WORD *)(v8 + 28); /*0x1030b0a48*/
  v111 = *(_WORD *)(v8 + 54); /*0x1030b0a51*/
  v119 = *(_WORD *)(v8 + 52); /*0x1030b0a5a*/
  v113 = v119; /*0x1030b0a61*/
  v102 = *(_QWORD *)v8; /*0x1030b0a67*/
  v115 = *(unsigned __int16 *)(v8 + 22); /*0x1030b0a73*/
  v107 = a1; /*0x1030b0a76*/
  v11 = *(_QWORD *)(a1 + 8); /*0x1030b0a7d*/
  v109 = a2; /*0x1030b0a81*/
  v12 = *(_DWORD *)(a2 + 28); /*0x1030b0a85*/
  v117 = v123; /*0x1030b0a8f*/
  v18 = whereScanInit(a1: (__int64)v97, a2: v11, a3: v12, a4: v123, a5: v10, a6: (_QWORD *)a3); /*0x1030b0a9b*/
  *(_WORD *)(v8 + 18) = 0; /*0x1030b0a9e*/
  v19 = **(__int16 **)(a3 + 16); /*0x1030b0aa9*/
  v7 = 0; /*0x1030b0aad*/
  v116 = 0; /*0x1030b0ab0*/
  v103 = v19; /*0x1030b0ab7*/
  if ( v19 >= 11 ) /*0x1030b0ac2*/
    v116 = sqlite3LogEst(a1: v103, a2: v15, a3: v13, a4: v14, a5: v16, a6: v17) - 33; /*0x1030b0ad3*/
  ++v113; /*0x1030b0ad6*/
  if ( v18 == 0 ) /*0x1030b0adc*/
    goto LABEL_164; /*0x1030b0adc*/
  v99 = (unsigned __int16)v116; /*0x1030b0ae6*/
  v122 = 0; /*0x1030b0aed*/
  v114 = 0; /*0x1030b0af5*/
  v118 = a3; /*0x1030b0afd*/
  while ( 1 ) /*0x1030b0b01*/
  {
    v20 = *(unsigned __int16 *)(v18 + 20); /*0x1030b0b01*/
    if ( v20 == 256 || *(char *)(v18 + 18) < 0 ) /*0x1030b0b16*/
    {
      v21 = *(__int16 *)(*(_QWORD *)(a3 + 8) + 2 * v117); /*0x1030b0b20*/
      if ( v21 < 0 ) /*0x1030b0b28*/
      {
        v22 = (_WORD)v21 == 0xFFFF; /*0x1030b0b46*/
      }
      else
      {
        v21 *= 16; /*0x1030b0b32*/
        v22 = *(_BYTE *)(*(_QWORD *)(*(_QWORD *)(a3 + 24) + 8LL) + v21 + 8) & 0xF; /*0x1030b0b3b*/
      }
      v7 = 0; /*0x1030b0b49*/
      if ( v22 != 0 ) /*0x1030b0b4e*/
        goto LABEL_149; /*0x1030b0b4e*/
    }
    v21 = *(_QWORD *)(v8 + 8); /*0x1030b0b54*/
    v7 = 0; /*0x1030b0b58*/
    if ( (v21 & *(_QWORD *)(v18 + 40)) != 0 || v20 == 16 && (*(_WORD *)(v18 + 18) & 0x100) != 0 ) /*0x1030b0b77*/
      goto LABEL_149; /*0x1030b0b77*/
    v23 = *(_BYTE *)(v109 + 24); /*0x1030b0b81*/
    if ( (v23 & 0x58) != 0 ) /*0x1030b0b86*/
    {
      v15 = *(_QWORD *)v18; /*0x1030b0b88*/
      v13 = *(unsigned int *)(*(_QWORD *)v18 + 4LL); /*0x1030b0b8c*/
      if ( (v13 & 3) == 0 ) /*0x1030b0b92*/
        goto LABEL_149; /*0x1030b0b92*/
      v15 = *(unsigned int *)(v15 + 48); /*0x1030b0b98*/
      if ( (_DWORD)v15 != *(_DWORD *)(v109 + 28) ) /*0x1030b0ba2*/
        goto LABEL_149; /*0x1030b0ba2*/
      if ( (v23 & 0x18) != 0 ) /*0x1030b0baa*/
      {
        v13 &= 2u; /*0x1030b0bac*/
        if ( (_DWORD)v13 != 0 ) /*0x1030b0baf*/
          goto LABEL_149; /*0x1030b0baf*/
      }
    }
    if ( *(_BYTE *)(a3 + 98) == 0 || (v24 = 2, *(unsigned __int16 *)(a3 + 94) - 1 != (_DWORD)v117) ) /*0x1030b0bc6*/
      v24 = 1; /*0x1030b0bc8*/
    *(_BYTE *)(v107 + 32) |= v24; /*0x1030b0bd1*/
    *(_DWORD *)(v8 + 48) = v112; /*0x1030b0bd7*/
    *(_WORD *)(v8 + 24) = v123; /*0x1030b0bdf*/
    *(_WORD *)(v8 + 26) = v120; /*0x1030b0be8*/
    *(_WORD *)(v8 + 28) = v121; /*0x1030b0bf1*/
    v25 = v119; /*0x1030b0bf6*/
    *(_WORD *)(v8 + 52) = v119; /*0x1030b0bfa*/
    v26 = v25; /*0x1030b0bff*/
    if ( (unsigned __int16)v25 >= *(_WORD *)(v8 + 56) ) /*0x1030b0c06*/
    {
      if ( (unsigned int)whereLoopResize(a1: v110, a2: v8, a3: v113, a4: v21, a5: v16, a6: v17) != 0 ) /*0x1030b0c19*/
        goto LABEL_163; /*0x1030b0c19*/
      v26 = *(unsigned __int16 *)(v8 + 52); /*0x1030b0c1f*/
      v21 = *(_QWORD *)(v8 + 8); /*0x1030b0c24*/
    }
    v27 = *(_QWORD *)(v8 + 64); /*0x1030b0c28*/
    v13 = (unsigned int)(v26 + 1); /*0x1030b0c2c*/
    *(_WORD *)(v8 + 52) = v26 + 1; /*0x1030b0c2f*/
    *(_QWORD *)(v27 + 8LL * (unsigned __int16)v26) = v18; /*0x1030b0c37*/
    v15 = v102 | *(_QWORD *)(v18 + 40); /*0x1030b0c40*/
    *(_QWORD *)v8 = v15 & ~v21; /*0x1030b0c4d*/
    if ( (v20 & 1) == 0 ) /*0x1030b0c54*/
      break; /*0x1030b0c54*/
    v21 = *(_QWORD *)v18; /*0x1030b0ce7*/
    if ( (*(_BYTE *)(*(_QWORD *)v18 + 5LL) & 0x10) != 0 ) /*0x1030b0cef*/
    {
      v34 = 46; /*0x1030b0d10*/
      if ( (unsigned __int16)(v26 + 1) >= 2u ) /*0x1030b0d1a*/
      {
        v13 = (unsigned int)(unsigned __int16)(v26 + 1) - 1; /*0x1030b0d1f*/
        v15 = *(_QWORD *)(v8 + 64); /*0x1030b0d21*/
        v34 = 46; /*0x1030b0d25*/
        v36 = 0; /*0x1030b0d2b*/
        v16 = 0; /*0x1030b0d2d*/
        do /*0x1030b0d5a*/
        {
          v17 = *(_QWORD *)(v15 + 8 * v36); /*0x1030b0d30*/
          if ( v17 != 0 && *(_QWORD *)v17 == v21 ) /*0x1030b0d3c*/
          {
            v37 = *(_DWORD *)(v17 + 36) == *(_DWORD *)(v18 + 36); /*0x1030b0d42*/
            v17 = 1; /*0x1030b0d47*/
            if ( v37 ) /*0x1030b0d4d*/
              v16 = 1; /*0x1030b0d4d*/
            v34 = 0; /*0x1030b0d51*/
          }
          ++v36; /*0x1030b0d54*/
        }
        while ( v13 != v36 ); /*0x1030b0d5a*/
        if ( (_DWORD)v16 != 0 ) /*0x1030b0d5f*/
        {
          *(_WORD *)(v8 + 52) = v26; /*0x1030b0d61*/
          v7 = 0; /*0x1030b0d66*/
          goto LABEL_149; /*0x1030b0d69*/
        }
      }
    }
    else
    {
      v35 = *(int **)(v21 + 32); /*0x1030b0cf1*/
      v34 = 0; /*0x1030b0cf5*/
      if ( v35 != nullptr && *v35 != 0 ) /*0x1030b0d03*/
        v34 = (__int16)sqlite3LogEst(a1: *v35, a2: v15, a3: v13, a4: v21, a5: v16, a6: v17); /*0x1030b0d0a*/
    }
    if ( *(char *)(a3 + 99) >= 0 || (__int16)v116 < 10 ) /*0x1030b0d79*/
      goto LABEL_64; /*0x1030b0d79*/
    v38 = *(_WORD *)(*(_QWORD *)(a3 + 16) + 2 * v117); /*0x1030b0d83*/
    v39 = 0; /*0x1030b0d87*/
    if ( v34 >= 11 ) /*0x1030b0d8d*/
    {
      v40 = v34; /*0x1030b0d99*/
      v41 = sqlite3LogEst(a1: (unsigned __int16)v34, a2: v15, a3: v13, a4: v117, a5: v16, a6: v17); /*0x1030b0d9c*/
      v34 = v40; /*0x1030b0da1*/
      v39 = v41 - 33; /*0x1030b0dac*/
    }
    v21 = (unsigned int)(v34 + v99); /*0x1030b0db5*/
    v42 = (__int16)(v39 + v38 - (v34 + v99) + 10) < 0; /*0x1030b0dbc*/
    a3 = v118; /*0x1030b0dc0*/
    if ( !v42 ) /*0x1030b0dc4*/
      goto LABEL_64; /*0x1030b0dc4*/
    v7 = 0; /*0x1030b104e*/
    if ( (__int16)v108 <= 1 && (*(_BYTE *)(v110 + 98) & 2) == 0 ) /*0x1030b1067*/
    {
      *(_BYTE *)(v8 + 50) |= 0x10u; /*0x1030b106d*/
LABEL_64:
      v30 = *(_DWORD *)(v8 + 48) | 4; /*0x1030b0dca*/
LABEL_65:
      *(_DWORD *)(v8 + 48) = v30; /*0x1030b0dd2*/
LABEL_66:
      if ( (v30 & 2) == 0 ) /*0x1030b0dda*/
      {
        v43 = *(_DWORD *)(v8 + 24) + 1; /*0x1030b0de0*/
        ++*(_WORD *)(v8 + 24); /*0x1030b0de2*/
        v44 = *(_WORD *)(v18 + 16); /*0x1030b0de7*/
        if ( v44 > 0 || *(__int16 *)(*(_QWORD *)(v118 + 8) + 2 * v117) < 0 ) /*0x1030b1027*/
        {
          LOWORD(v45) = *(_WORD *)(v8 + 22) /*0x1030b0e0a*/
                      + *(_WORD *)(*(_QWORD *)(v118 + 16) + 2LL * (unsigned __int16)v43)
                      - *(_WORD *)(*(_QWORD *)(v118 + 16) + 2LL * (unsigned __int16)v43 - 2);
          *(_WORD *)(v8 + 22) = v45; /*0x1030b0e0f*/
          if ( (v20 & 0x100) != 0 ) /*0x1030b0e19*/
          {
            LOWORD(v45) = v45 + 10; /*0x1030b0e1f*/
            goto LABEL_107; /*0x1030b0e22*/
          }
        }
        else
        {
          LOWORD(v45) = *(_WORD *)(v8 + 22) + v44 - v34; /*0x1030b1030*/
LABEL_107:
          v69 = v30; /*0x1030b1035*/
          v18 = v122; /*0x1030b1038*/
LABEL_132:
          *(_WORD *)(v8 + 22) = v45; /*0x1030b10eb*/
          v30 = v69; /*0x1030b10f0*/
          v122 = v18; /*0x1030b10f3*/
        }
        v74 = v109; /*0x1030b1103*/
        v75 = v34; /*0x1030b1107*/
        if ( (~(unsigned __int8)*(_WORD *)(v118 + 99) & 3) != 0 ) /*0x1030b110a*/
          v76 = v45 + 15 * *(__int16 *)(v118 + 92) / *(__int16 *)(*(_QWORD *)(v109 + 16) + 60LL) + 1; /*0x1030b1129*/
        else
          v76 = v45 + 16; /*0x1030b110c*/
        v77 = sqlite3LogEstAdd(a1: (unsigned int)(__int16)v116, a2: (unsigned int)v76); /*0x1030b1132*/
        if ( (v30 & 0x4000140) == 0 ) /*0x1030b113e*/
          v77 = sqlite3LogEstAdd(a1: (unsigned int)v77, a2: (unsigned int)(__int16)(v45 + 16)); /*0x1030b1149*/
        v78 = v108 + v75; /*0x1030b1151*/
        *(_WORD *)(v8 + 20) = v108 + v75 + v77; /*0x1030b1159*/
        v79 = v78; /*0x1030b115e*/
        *(_WORD *)(v8 + 22) = v45 + v78; /*0x1030b1164*/
        v80 = v107; /*0x1030b1169*/
        whereLoopOutputAdjust(a1: *(_QWORD *)(v107 + 8), a2: v8, a3: v103); /*0x1030b117e*/
        v7 = whereLoopInsert(a1: v80, a2: (__int128 *)v8); /*0x1030b118e*/
        v81 = *(_DWORD *)(v8 + 48); /*0x1030b1191*/
        if ( (v81 & 2) != 0 ) /*0x1030b1197*/
          LOWORD(v45) = v115; /*0x1030b1197*/
        *(_WORD *)(v8 + 22) = v45; /*0x1030b119b*/
        a3 = v118; /*0x1030b11a2*/
        if ( (v81 & 0x10) == 0 ) /*0x1030b11a6*/
        {
          v82 = *(_WORD *)(v8 + 24); /*0x1030b11a8*/
          if ( v82 < *(_WORD *)(v118 + 96) ) /*0x1030b11b1*/
          {
            if ( v82 < *(_WORD *)(v118 + 94) || (v21 = *(_WORD *)(v118 + 99) & 3, (*(_WORD *)(v118 + 99) & 3) != 2) ) /*0x1030b11c4*/
            {
              if ( v82 >= 4u && *(_DWORD *)(*(_QWORD *)v106 + 384LL) != 0 ) /*0x1030b11de*/
              {
                v83 = v106; /*0x1030b11e0*/
                ++v106[14]; /*0x1030b11e7*/
                v83[6] = 9; /*0x1030b11ea*/
              }
              whereLoopAddBtreeIndex(a1: v107, a2: v74, a3, a4: (unsigned int)v79); /*0x1030b1202*/
            }
          }
        }
        *(_WORD *)(v8 + 22) = v115; /*0x1030b120a*/
        goto LABEL_149; /*0x1030b120a*/
      }
      v46 = *(_WORD *)(v8 + 22); /*0x1030b0e27*/
      v47 = v114; /*0x1030b0e2c*/
      if ( v114 != 0 ) /*0x1030b0e33*/
      {
        v48 = *(_WORD *)(v114 + 16); /*0x1030b0e39*/
        if ( v48 <= 0 ) /*0x1030b0e40*/
        {
          v49 = v46 + v48; /*0x1030b1077*/
        }
        else
        {
          v49 = v46 - 20; /*0x1030b0e46*/
          if ( *(char *)(v114 + 18) < 0 ) /*0x1030b0e4d*/
            v49 = *(_WORD *)(v8 + 22); /*0x1030b0e4d*/
        }
        v69 = v30; /*0x1030b1079*/
        v18 = v122; /*0x1030b107c*/
        goto LABEL_115; /*0x1030b107c*/
      }
      v69 = v30; /*0x1030b1041*/
      v47 = 0; /*0x1030b1044*/
      v18 = v122; /*0x1030b1046*/
LABEL_109:
      v49 = v46; /*0x1030b104a*/
LABEL_115:
      if ( v18 != 0 ) /*0x1030b1083*/
      {
        v70 = *(_WORD *)(v18 + 16); /*0x1030b1085*/
        if ( v70 <= 0 ) /*0x1030b108e*/
        {
          v71 = v49 + v70; /*0x1030b109e*/
        }
        else
        {
          v71 = v49 - 20; /*0x1030b1096*/
          if ( *(char *)(v18 + 18) < 0 ) /*0x1030b1099*/
            v71 = v49; /*0x1030b1099*/
        }
        v49 = v71; /*0x1030b10a0*/
      }
      if ( v47 != 0 && v18 != 0 && *(__int16 *)(v47 + 16) > 0 ) /*0x1030b10b1*/
      {
        v72 = v49 - 20; /*0x1030b10ba*/
        if ( *(__int16 *)(v18 + 16) <= 0 ) /*0x1030b10bd*/
          v72 = v49; /*0x1030b10bd*/
        v49 = v72; /*0x1030b10c0*/
      }
      v114 = v47; /*0x1030b10c5*/
      v45 = (v18 == 0) + (v47 == 0) + v46 - 1 - 1; /*0x1030b10d4*/
      v73 = 10; /*0x1030b10db*/
      if ( v49 >= 11 ) /*0x1030b10e0*/
        v73 = v49; /*0x1030b10e0*/
      if ( v45 >= v73 ) /*0x1030b10e8*/
        LOWORD(v45) = v73; /*0x1030b10e8*/
      goto LABEL_132; /*0x1030b10e8*/
    }
LABEL_149:
    v84 = whereScanNext(a1: v97, a2: v15, i: v13, a4: v21, a5: (_BYTE *)v16); /*0x1030b120f*/
    if ( v7 == 0 ) /*0x1030b121e*/
    {
      v18 = (__int64)v84; /*0x1030b1224*/
      if ( v84 != nullptr ) /*0x1030b122a*/
        continue; /*0x1030b122a*/
    }
    goto LABEL_164; /*0x1030b122a*/
  }
  if ( (v20 & 0x82) != 0 ) /*0x1030b0c5e*/
  {
    v28 = *(_WORD *)(*(_QWORD *)(a3 + 8) + 2 * v117); /*0x1030b0c6c*/
    v29 = *(_DWORD *)(v8 + 48); /*0x1030b0c70*/
    v30 = v29 | 1; /*0x1030b0c77*/
    *(_DWORD *)(v8 + 48) = v29 | 1; /*0x1030b0c7b*/
    v31 = 4097; /*0x1030b0c7f*/
    if ( v28 == -1 ) /*0x1030b0c88*/
      goto LABEL_42; /*0x1030b0c88*/
    if ( (_WORD)v108 == 0 && v28 >= 0 ) /*0x1030b0c97*/
    {
      v32 = *(unsigned __int16 *)(a3 + 94); /*0x1030b0c99*/
      if ( v32 - 1 == (_DWORD)v117 ) /*0x1030b0ca3*/
      {
        if ( (*(_BYTE *)(a3 + 99) & 8) == 0 && ((_WORD)v32 != 1 || (v20 & 2) == 0 || *(_BYTE *)(a3 + 98) == 0) ) /*0x1030b0cbb*/
          v31 = 65537; /*0x1030b0cbd*/
LABEL_42:
        v33 = v31 | v29; /*0x1030b0cc2*/
        *(_DWORD *)(v8 + 48) = v33; /*0x1030b0cc4*/
        v30 = v33; /*0x1030b0cc8*/
      }
    }
    LOWORD(v34) = 0; /*0x1030b0ccb*/
    if ( v98 >= 2u ) /*0x1030b0cd5*/
    {
      v30 |= 0x200000u; /*0x1030b0cdb*/
      goto LABEL_65; /*0x1030b0ce2*/
    }
    goto LABEL_66; /*0x1030b0cd5*/
  }
  if ( (v20 & 0x100) != 0 ) /*0x1030b0e5a*/
  {
    v30 = *(_DWORD *)(v8 + 48) | 8; /*0x1030b1239*/
    *(_DWORD *)(v8 + 48) = v30; /*0x1030b123d*/
    LOWORD(v34) = 0; /*0x1030b1241*/
    goto LABEL_66; /*0x1030b1244*/
  }
  v50 = *(unsigned __int8 **)(*(_QWORD *)v18 + 16LL); /*0x1030b0e64*/
  v51 = *v50; /*0x1030b0e68*/
  if ( *v50 == 0xB0 ) /*0x1030b0e6d*/
    v51 = v50[2]; /*0x1030b0e6f*/
  if ( v51 == 0xB1 ) /*0x1030b0e75*/
  {
LABEL_81:
    v53 = **((unsigned int **)v50 + 4); /*0x1030b0e8b*/
  }
  else
  {
    v52 = v51; /*0x1030b0e77*/
    v53 = 1; /*0x1030b0e7a*/
    if ( v52 == 139 ) /*0x1030b0e85*/
    {
      v50 = *((unsigned __int8 **)v50 + 4); /*0x1030b0e87*/
      goto LABEL_81; /*0x1030b0e87*/
    }
  }
  v54 = *(unsigned __int16 *)(a3 + 96) - (_DWORD)v117; /*0x1030b0e95*/
  if ( (int)v53 < v54 ) /*0x1030b0e9a*/
    v54 = v53; /*0x1030b0e9a*/
  v55 = 1; /*0x1030b0e9d*/
  if ( v54 >= 2 ) /*0x1030b0ea6*/
  {
    v56 = *(_DWORD *)(v109 + 28); /*0x1030b0eb0*/
    v101 = (unsigned int)v54; /*0x1030b0eb5*/
    v55 = 1; /*0x1030b0ebc*/
    v104 = v54; /*0x1030b0ec2*/
    v105 = v56; /*0x1030b0ec8*/
    while ( 1 ) /*0x1030b0ed2*/
    {
      v57 = *(_QWORD *)(*(_QWORD *)v18 + 24LL); /*0x1030b0ed2*/
      if ( (*(_BYTE *)(v57 + 5) & 0x10) != 0 ) /*0x1030b0eda*/
        v57 = *(_QWORD *)(v57 + 32); /*0x1030b0edc*/
      v53 = 3 * v55; /*0x1030b0ee8*/
      v58 = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)(*(_QWORD *)v18 + 16LL) + 32LL) + 24 * v55 + 8); /*0x1030b0eec*/
      if ( *(_BYTE *)v58 != 0xA8 ) /*0x1030b0ef5*/
        break; /*0x1030b0ef5*/
      if ( *(_DWORD *)(v58 + 40) != v56 ) /*0x1030b0eff*/
        break; /*0x1030b0eff*/
      v16 = v117; /*0x1030b0f0e*/
      if ( *(_WORD *)(v58 + 44) != *(_WORD *)(*(_QWORD *)(a3 + 8) + 2 * (v55 + v117)) ) /*0x1030b0f1b*/
        break; /*0x1030b0f1b*/
      if ( *(_BYTE *)(*(_QWORD *)(a3 + 56) + v55 + v117) != *(_BYTE *)(*(_QWORD *)(a3 + 56) + v117) ) /*0x1030b0f2d*/
      {
        a3 = v118; /*0x1030b1253*/
        break; /*0x1030b1253*/
      }
      v100 = v55 + v117; /*0x1030b0f33*/
      v122 = v55; /*0x1030b0f3a*/
      v59 = *(_QWORD *)(*(_QWORD *)(v57 + 32) + 24 * v55 + 8); /*0x1030b0f42*/
      v60 = sqlite3ExprAffinity(a1: v58); /*0x1030b0f4a*/
      v114 = v59; /*0x1030b0f52*/
      v61 = sqlite3CompareAffinity(a1: v59, a2: (unsigned int)v60); /*0x1030b0f59*/
      v62 = *(__int16 *)(v58 + 44); /*0x1030b0f5e*/
      LOBYTE(v53) = 68; /*0x1030b0f63*/
      if ( v62 >= 0 ) /*0x1030b0f68*/
      {
        v63 = *(_QWORD *)(v118 + 24); /*0x1030b0f6e*/
        if ( *(__int16 *)(v63 + 54) > (__int16)v62 ) /*0x1030b0f76*/
        {
          v53 = *(_QWORD *)(v63 + 8); /*0x1030b0f78*/
          LOBYTE(v53) = *(_BYTE *)(v53 + 16 * v62 + 9); /*0x1030b0f80*/
        }
      }
      if ( v61 != (_BYTE)v53 || (v64 = (__int64 *)sqlite3BinaryCompareCollSeq(a1: v106, a2: v58, a3: v114)) == nullptr ) /*0x1030b0fa2*/
      {
        a3 = v118; /*0x1030b1249*/
        v55 = v122; /*0x1030b124d*/
        break; /*0x1030b1251*/
      }
      v65 = *v64; /*0x1030b0fa8*/
      a3 = v118; /*0x1030b0fab*/
      v53 = *(_QWORD *)(*(_QWORD *)(v118 + 64) + 8 * v100); /*0x1030b0fba*/
      v66 = 0; /*0x1030b0fbe*/
      v16 = (__int64)sqlite3UpperToLower; /*0x1030b0fc0*/
      v55 = v122; /*0x1030b0fc7*/
      while ( 1 ) /*0x1030b0fcb*/
      {
        v67 = *(unsigned __int8 *)(v65 + v66); /*0x1030b0fcb*/
        v68 = *(unsigned __int8 *)(v53 + v66); /*0x1030b0fcf*/
        if ( (_BYTE)v67 == (_BYTE)v68 ) /*0x1030b0fd6*/
          break; /*0x1030b0fd6*/
        if ( sqlite3UpperToLower[v67] != sqlite3UpperToLower[v68] ) /*0x1030b0fe7*/
          goto LABEL_155; /*0x1030b0fe7*/
LABEL_102:
        ++v66; /*0x1030b0fed*/
      }
      if ( *(_BYTE *)(v65 + v66) != 0 ) /*0x1030b0fdb*/
        goto LABEL_102; /*0x1030b0fdb*/
      v55 = v122 + 1; /*0x1030b0ff2*/
      v56 = v105; /*0x1030b1002*/
      if ( v122 + 1 == v101 ) /*0x1030b1008*/
      {
        v55 = v104; /*0x1030b100e*/
        break; /*0x1030b1011*/
      }
    }
  }
LABEL_155:
  v85 = *(_DWORD *)(v8 + 48); /*0x1030b1257*/
  if ( (v20 & 0x24) == 0 ) /*0x1030b125f*/
  {
    v69 = v85 | 0x12; /*0x1030b128d*/
    *(_DWORD *)(v8 + 48) = v85 | 0x12; /*0x1030b1290*/
    *(_WORD *)(v8 + 28) = v55; /*0x1030b1294*/
    if ( (v85 & 0x20) != 0 ) /*0x1030b129d*/
    {
      v114 = *(_QWORD *)(*(_QWORD *)(v8 + 64) + 8LL * *(unsigned __int16 *)(v8 + 52) - 16); /*0x1030b1310*/
      LOWORD(v34) = 0; /*0x1030b1314*/
      v30 = v85 | 0x12; /*0x1030b1317*/
      v122 = v18; /*0x1030b131a*/
      goto LABEL_66; /*0x1030b131e*/
    }
    v46 = *(_WORD *)(v8 + 22); /*0x1030b129f*/
    LOWORD(v34) = 0; /*0x1030b12a4*/
    v47 = 0; /*0x1030b12a7*/
    goto LABEL_109; /*0x1030b12a9*/
  }
  v30 = v85 | 0x22; /*0x1030b1261*/
  *(_DWORD *)(v8 + 48) = v30; /*0x1030b1265*/
  *(_WORD *)(v8 + 26) = v55; /*0x1030b1269*/
  if ( (*(_BYTE *)(v18 + 19) & 1) == 0 ) /*0x1030b1274*/
  {
    LOWORD(v34) = 0; /*0x1030b1276*/
    v114 = v18; /*0x1030b1279*/
    v122 = 0; /*0x1030b127d*/
    goto LABEL_66; /*0x1030b1285*/
  }
  if ( (unsigned int)whereLoopResize( /*0x1030b12c3*/
                       a1: v110,
                       a2: v8,
                       a3: (unsigned int)*(unsigned __int16 *)(v8 + 52) + 1,
                       a4: v53,
                       a5: v16,
                       a6: v55) == 0 )
  {
    v86 = *(_QWORD *)(v8 + 64); /*0x1030b12ca*/
    v87 = *(unsigned __int16 *)(v8 + 52); /*0x1030b12ce*/
    *(_WORD *)(v8 + 52) = v87 + 1; /*0x1030b12d6*/
    v122 = v18 + 56; /*0x1030b12db*/
    *(_QWORD *)(v86 + 8 * v87) = v18 + 56; /*0x1030b12df*/
    v30 = *(_DWORD *)(v8 + 48) | 0x10; /*0x1030b12e7*/
    *(_DWORD *)(v8 + 48) = v30; /*0x1030b12eb*/
    *(_WORD *)(v8 + 28) = 1; /*0x1030b12ef*/
    LOWORD(v34) = 0; /*0x1030b12f6*/
    v114 = v18; /*0x1030b12f9*/
    goto LABEL_66; /*0x1030b12fd*/
  }
LABEL_163:
  v7 = 0; /*0x1030b1323*/
LABEL_164:
  *(_QWORD *)v8 = v102; /*0x1030b1326*/
  v88 = v123; /*0x1030b1330*/
  *(_WORD *)(v8 + 24) = v123; /*0x1030b1334*/
  *(_WORD *)(v8 + 26) = v120; /*0x1030b133d*/
  *(_WORD *)(v8 + 28) = v121; /*0x1030b1346*/
  v89 = v111; /*0x1030b134b*/
  *(_WORD *)(v8 + 54) = v111; /*0x1030b134f*/
  *(_DWORD *)(v8 + 48) = v112; /*0x1030b1357*/
  *(_WORD *)(v8 + 22) = v115; /*0x1030b135e*/
  v90 = v119; /*0x1030b1363*/
  *(_WORD *)(v8 + 52) = v119; /*0x1030b1367*/
  if ( v88 == v89 ) /*0x1030b136f*/
  {
    v91 = *(unsigned __int16 *)(a3 + 94); /*0x1030b137c*/
    LOBYTE(v91) = (int)v117 + 1 < (unsigned int)v91 && v88 == v90; /*0x1030b138b*/
    if ( (_BYTE)v91 == 1 /*0x1030b13c2*/
      && (*(_WORD *)(a3 + 99) & 0xC0) == 0x80
      && (*(_BYTE *)(v110 + 97) & 0x40) == 0
      && *(__int16 *)(*(_QWORD *)(a3 + 16) + 2 * v117 + 2) >= 42 )
    {
      v92 = v109; /*0x1030b13c8*/
      if ( (*(_BYTE *)(v109 + 27) & 4) == 0 ) /*0x1030b13d2*/
      {
        v7 = whereLoopResize(a1: v110, a2: v8, a3: v113, a4: v91, a5: v16, a6: v17); /*0x1030b13e7*/
        if ( v7 == 0 ) /*0x1030b13ec*/
        {
          ++*(_WORD *)(v8 + 24); /*0x1030b13f2*/
          v93 = *(_QWORD *)(v8 + 64); /*0x1030b13f7*/
          v94 = *(_DWORD *)(v8 + 52); /*0x1030b13fb*/
          *(_DWORD *)(v8 + 52) = _mm_cvtsi128_si32(_mm_sub_epi16(_mm_cvtsi32_si128(v94), (__m128i)-1LL)); /*0x1030b140b*/
          *(_QWORD *)(v93 + 8LL * (unsigned __int16)v94) = 0; /*0x1030b1414*/
          *(_BYTE *)(v8 + 49) |= 0x80u; /*0x1030b141c*/
          LOWORD(v94) = *(_WORD *)(*(_QWORD *)(a3 + 16) + 2 * v117) - *(_WORD *)(*(_QWORD *)(a3 + 16) + 2 * v117 + 2); /*0x1030b142d*/
          *(_WORD *)(v8 + 22) -= v94; /*0x1030b1432*/
          whereLoopAddBtreeIndex(a1: v107, a2: v92, a3, a4: (unsigned int)(__int16)(v94 + v108 + 5)); /*0x1030b1453*/
          *(_WORD *)(v8 + 22) = v115; /*0x1030b145b*/
          v95 = v123; /*0x1030b1460*/
          *(_WORD *)(v8 + 24) = v123; /*0x1030b1464*/
          *(_WORD *)(v8 + 54) = v95; /*0x1030b1469*/
          *(_DWORD *)(v8 + 48) = v112; /*0x1030b1471*/
          return 0; /*0x1030b1475*/
        }
      }
    }
  }
  return v7; /*0x1030b147b*/
}

// Address: 0x1030b14ec | Name: _whereIsCoveringIndexWalkCallback
__int64 __fastcall whereIsCoveringIndexWalkCallback(__int64 a1, unsigned __int8 *a2)
{
  __int64 *v3; // r15
  __int64 v4; // r12
  __int16 v5; // si
  __int64 result; // rax
  __int64 v7; // rdi
  unsigned __int16 v8; // cx
  __int64 v9; // r13
  unsigned __int64 v10; // r14
  unsigned int v11; // [rsp+0h] [rbp-2Ch]

  v3 = *(__int64 **)(a1 + 40); /*0x1030b14fd*/
  v4 = *v3; /*0x1030b1501*/
  if ( (*a2 | 2) == 0xAA ) /*0x1030b150f*/
  {
    if ( *((_DWORD *)a2 + 10) == *((_DWORD *)v3 + 2) ) /*0x1030b1518*/
    {
      if ( *(_WORD *)(v4 + 96) != 0 ) /*0x1030b1527*/
      {
        v5 = *((_WORD *)a2 + 22); /*0x1030b152e*/
        result = 0; /*0x1030b1532*/
        v7 = 0; /*0x1030b1534*/
        while ( *(_WORD *)(*(_QWORD *)(v4 + 8) + 2 * v7) != v5 ) /*0x1030b153a*/
        {
          if ( *(unsigned __int16 *)(v4 + 96) == ++v7 ) /*0x1030b1542*/
            goto LABEL_7; /*0x1030b1542*/
        }
      }
      else
      {
LABEL_7:
        *((_BYTE *)v3 + 13) = 1; /*0x1030b1544*/
        return 2; /*0x1030b1549*/
      }
    }
    else
    {
      return 0; /*0x1030b15b1*/
    }
  }
  else
  {
    result = 0; /*0x1030b1550*/
    if ( (*(_BYTE *)(v4 + 100) & 8) != 0 ) /*0x1030b1558*/
    {
      v8 = *(_WORD *)(v4 + 96); /*0x1030b155a*/
      if ( v8 != 0 ) /*0x1030b1563*/
      {
        v11 = *((_DWORD *)v3 + 2); /*0x1030b1569*/
        v9 = 4; /*0x1030b156c*/
        v10 = 0; /*0x1030b1572*/
        while ( 1 ) /*0x1030b1575*/
        {
          if ( *(_WORD *)(*(_QWORD *)(v4 + 8) + 2 * v10) == 0xFFFE ) /*0x1030b1580*/
          {
            if ( (unsigned int)sqlite3ExprCompare(a1: 0, a2, a3: *(_QWORD *)(*(_QWORD *)(v4 + 80) + 2 * v9), a4: v11) == 0 ) /*0x1030b159a*/
            {
              *((_BYTE *)v3 + 12) = 1; /*0x1030b15c2*/
              return 1; /*0x1030b15c7*/
            }
            v8 = *(_WORD *)(v4 + 96); /*0x1030b159c*/
          }
          ++v10; /*0x1030b15a2*/
          v9 += 12; /*0x1030b15a8*/
          if ( v10 >= v8 ) /*0x1030b15af*/
            return 0; /*0x1030b15af*/
        }
      }
    }
  }
  return result; /*0x1030b15b7*/
}

// Address: 0x1030b161a | Name: _wherePathSatisfiesOrderBy
__int64 __fastcall wherePathSatisfiesOrderBy(
        __int64 **a1,
        unsigned __int16 *a2,
        __int64 a3,
        unsigned __int16 a4,
        unsigned __int64 a5,
        __int64 a6,
        _QWORD *a7)
{
  __int64 **v7; // r13
  unsigned __int64 v8; // r10
  __int64 v9; // rcx
  unsigned __int16 *v11; // r14
  int v12; // eax
  __int64 v13; // r12
  __int64 v14; // rbx
  unsigned __int64 v15; // r15
  unsigned __int64 v16; // r11
  int matched; // eax
  __int64 v18; // r9
  unsigned __int64 v19; // r13
  char *v20; // rbx
  int v21; // eax
  unsigned __int8 v22; // al
  char **v23; // rbx
  unsigned __int64 v24; // r12
  __int64 Term; // rax
  __int64 v26; // rdx
  __int64 v27; // rcx
  __int64 v28; // r14
  __int16 v29; // ax
  __int64 v30; // rsi
  __int64 *v31; // rbx
  __int64 v32; // rax
  __int64 *v33; // rdi
  _QWORD *v34; // rbx
  __int64 *v35; // rax
  __int64 v36; // rax
  __int64 v37; // rdx
  __int64 v38; // rsi
  __int64 v39; // rdi
  __int64 v40; // rsi
  __int64 v41; // rdx
  unsigned __int64 v42; // rdx
  unsigned __int64 v43; // rcx
  bool v44; // al
  char v45; // r15
  __int64 v46; // rdx
  __int64 *v47; // rsi
  int v48; // edi
  int v49; // ecx
  __int64 v50; // rsi
  unsigned __int64 v51; // rdi
  _QWORD *v52; // r9
  __int64 v53; // rdx
  __int16 v54; // si
  bool v55; // zf
  int v56; // edx
  unsigned __int64 v57; // rdx
  unsigned __int64 v58; // r13
  unsigned __int64 v59; // r12
  __int64 v60; // rsi
  unsigned __int8 *v61; // rdi
  int v62; // eax
  unsigned __int8 **v63; // rdi
  __int64 v64; // rcx
  __int64 *v65; // r14
  __int64 *v66; // rax
  __int64 v67; // rax
  __int64 v68; // rdx
  __int64 v69; // rsi
  __int64 v70; // rdi
  __int64 v71; // rsi
  unsigned int v72; // ecx
  int v73; // edx
  unsigned int v74; // edx
  __int64 v75; // rsi
  int v76; // ecx
  __int64 v77; // rbx
  unsigned __int16 *v78; // r13
  unsigned __int64 i; // r15
  __int64 v80; // r12
  unsigned __int64 v81; // rbx
  __int64 v82; // rax
  bool v83; // cf
  _QWORD v84[4]; // [rsp+10h] [rbp-140h] BYREF
  __int16 v85; // [rsp+34h] [rbp-11Ch]
  _QWORD **v86; // [rsp+40h] [rbp-110h]
  __int64 v87; // [rsp+48h] [rbp-108h]
  __int64 v88; // [rsp+50h] [rbp-100h]
  _QWORD **v89; // [rsp+58h] [rbp-F8h]
  __int64 v90; // [rsp+60h] [rbp-F0h]
  __int64 v91; // [rsp+68h] [rbp-E8h]
  unsigned __int64 v92; // [rsp+70h] [rbp-E0h]
  unsigned __int64 v93; // [rsp+78h] [rbp-D8h]
  __int64 v94; // [rsp+80h] [rbp-D0h]
  __int64 v95; // [rsp+88h] [rbp-C8h]
  unsigned __int16 *v96; // [rsp+90h] [rbp-C0h]
  __int64 v97; // [rsp+98h] [rbp-B8h]
  __int64 v98; // [rsp+A0h] [rbp-B0h]
  unsigned __int64 v99; // [rsp+A8h] [rbp-A8h]
  __int64 v100; // [rsp+B0h] [rbp-A0h]
  __int64 **v101; // [rsp+B8h] [rbp-98h]
  _QWORD *v102; // [rsp+C0h] [rbp-90h]
  unsigned int v103; // [rsp+CCh] [rbp-84h]
  unsigned __int64 v104; // [rsp+D0h] [rbp-80h] BYREF
  __int64 v105; // [rsp+D8h] [rbp-78h]
  int v106; // [rsp+E4h] [rbp-6Ch]
  unsigned __int16 *v107; // [rsp+E8h] [rbp-68h]
  unsigned __int16 *v108; // [rsp+F0h] [rbp-60h]
  unsigned __int64 v109; // [rsp+F8h] [rbp-58h]
  __int64 v110; // [rsp+100h] [rbp-50h]
  signed __int32 v111; // [rsp+108h] [rbp-48h] BYREF
  int v112; // [rsp+10Ch] [rbp-44h]
  unsigned int v113; // [rsp+110h] [rbp-40h]
  bool v114; // [rsp+117h] [rbp-39h]
  unsigned __int64 v115; // [rsp+118h] [rbp-38h]
  int v116; // [rsp+124h] [rbp-2Ch]

  v87 = a6; /*0x1030b162e*/
  v88 = a3; /*0x1030b1637*/
  v7 = a1; /*0x1030b163e*/
  if ( (_DWORD)a5 != 0 && (*(_BYTE *)(**a1 + 96) & 0x40) != 0 ) /*0x1030b1650*/
    goto LABEL_4; /*0x1030b1650*/
  v90 = **a1; /*0x1030b1652*/
  v96 = a2; /*0x1030b1659*/
  v8 = *a2; /*0x1030b1660*/
  if ( (unsigned int)v8 > 0x3F ) /*0x1030b1668*/
    goto LABEL_4; /*0x1030b1668*/
  v111 = a4; /*0x1030b1691*/
  v103 = 387 - ((a4 & 0x803) == 0); /*0x1030b16a4*/
  v99 = ~(-1LL << v8); /*0x1030b16ad*/
  v114 = (_DWORD)v8 != 0; /*0x1030b16b7*/
  if ( (_DWORD)v8 == 0 ) /*0x1030b16bb*/
  {
    v16 = 0; /*0x1030b1f90*/
LABEL_168:
    if ( v16 != v99 ) /*0x1030b1f9a*/
    {
      LOBYTE(v9) = -1; /*0x1030b1fa4*/
      if ( !v114 ) /*0x1030b1faa*/
        return (unsigned int)(char)v9; /*0x1030b1faa*/
LABEL_174:
      v9 = v8; /*0x1030b1fda*/
      while ( v9 >= 2 ) /*0x1030b1fe1*/
      {
        if ( (v16 | (-1LL << --v9)) == 0xFFFFFFFFFFFFFFFFLL ) /*0x1030b1ffb*/
          return (unsigned int)(char)v9; /*0x1030b1ffb*/
      }
      goto LABEL_4; /*0x1030b1fe1*/
    }
LABEL_169:
    LOBYTE(v9) = v8; /*0x1030b1f9c*/
    return (unsigned int)(char)v9; /*0x1030b1f9f*/
  }
  v11 = v96 + 4; /*0x1030b16c8*/
  v89 = a1 + 13; /*0x1030b16d0*/
  v86 = a1 + 74; /*0x1030b16de*/
  v12 = (unsigned __int16)a5; /*0x1030b16e5*/
  v92 = (unsigned __int16)a5; /*0x1030b16e9*/
  LOBYTE(v12) = 1; /*0x1030b16f0*/
  v116 = v12; /*0x1030b16f2*/
  v13 = 0; /*0x1030b16f5*/
  v14 = 0; /*0x1030b16f8*/
  v98 = 0; /*0x1030b16fa*/
  v15 = 0; /*0x1030b1705*/
  v16 = 0; /*0x1030b1708*/
  v109 = v8; /*0x1030b170b*/
  v108 = v96 + 4; /*0x1030b170f*/
  v101 = a1; /*0x1030b1713*/
LABEL_8:
  if ( v15 != 0 ) /*0x1030b171d*/
    v98 |= *(_QWORD *)(v13 + 8); /*0x1030b172b*/
  v13 = v87; /*0x1030b1732*/
  if ( v15 < v92 ) /*0x1030b1740*/
  {
    v13 = *(_QWORD *)(*(_QWORD *)(v88 + 24) + 8 * v15); /*0x1030b1752*/
    if ( _bittest(&v111, 0xBu) ) /*0x1030b1756*/
      goto LABEL_165; /*0x1030b1756*/
  }
  matched = *(_DWORD *)(v13 + 48); /*0x1030b175c*/
  if ( (matched & 0x400) != 0 ) /*0x1030b1765*/
  {
    if ( (*(_BYTE *)(v13 + 29) == 0 || (v111 & 0x280) == 128) && v16 != v99 ) /*0x1030b1fd8*/
      goto LABEL_174; /*0x1030b1fd8*/
    goto LABEL_169; /*0x1030b1fd8*/
  }
  v18 = HIDWORD(v7[1][9 * *(unsigned __int8 *)(v13 + 16) + 4]); /*0x1030b1779*/
  v110 = v13; /*0x1030b1781*/
  v93 = v15; /*0x1030b1785*/
  v113 = v18; /*0x1030b178c*/
  v105 = v14; /*0x1030b1790*/
  if ( (_DWORD)v8 == 0 ) /*0x1030b1794*/
    goto LABEL_50; /*0x1030b1794*/
  v115 = ~v98; /*0x1030b17a4*/
  v19 = 0; /*0x1030b17a8*/
  do /*0x1030b17c3*/
  {
    if ( !_bittest64((const __int64 *)&v16, v19) ) /*0x1030b17b7*/
    {
      v20 = *(char **)&v11[12 * v19]; /*0x1030b17d5*/
      if ( v20 != nullptr ) /*0x1030b17dc*/
      {
        while ( 1 ) /*0x1030b17e2*/
        {
          v21 = *((_DWORD *)v20 + 1); /*0x1030b17e2*/
          if ( (v21 & 0x82000) == 0 ) /*0x1030b17ea*/
            break; /*0x1030b17ea*/
          if ( (v21 & 0x80000) != 0 ) /*0x1030b17f0*/
          {
            v23 = (char **)(*((_QWORD *)v20 + 4) + 8LL); /*0x1030b1802*/
          }
          else
          {
            v22 = *v20; /*0x1030b17f2*/
            if ( *v20 != 114 ) /*0x1030b17f6*/
              goto LABEL_27; /*0x1030b17f6*/
            v23 = (char **)(v20 + 16); /*0x1030b17f8*/
          }
          v20 = *v23; /*0x1030b1806*/
          if ( v20 == nullptr ) /*0x1030b180c*/
            goto LABEL_16; /*0x1030b180c*/
        }
        v22 = *v20; /*0x1030b1810*/
LABEL_27:
        if ( (v22 | 2) == 0xAA && *((_DWORD *)v20 + 10) == (_DWORD)v18 ) /*0x1030b1823*/
        {
          v107 = &v11[12 * v19]; /*0x1030b1825*/
          v24 = v16; /*0x1030b1829*/
          Term = sqlite3WhereFindTerm( /*0x1030b1848*/
                   a1: v89,
                   a2: (unsigned int)v18,
                   a3: (unsigned int)*((__int16 *)v20 + 22),
                   a4: v115,
                   a5: v103,
                   a6: 0);
          if ( Term == 0 ) /*0x1030b1850*/
            goto LABEL_47; /*0x1030b1850*/
          v28 = Term; /*0x1030b1856*/
          v29 = *(_WORD *)(Term + 20); /*0x1030b1859*/
          v8 = v109; /*0x1030b1861*/
          v16 = v24; /*0x1030b1865*/
          v18 = v113; /*0x1030b1868*/
          if ( v29 == 1 ) /*0x1030b186c*/
          {
            v27 = *(unsigned __int16 *)(v110 + 52); /*0x1030b1872*/
            if ( *(_WORD *)(v110 + 52) == 0 ) /*0x1030b1879*/
            {
LABEL_49:
              v11 = v108; /*0x1030b1953*/
              goto LABEL_16; /*0x1030b1957*/
            }
            v26 = *(_QWORD *)(v110 + 64); /*0x1030b187f*/
            v30 = 0; /*0x1030b1883*/
            while ( v28 != *(_QWORD *)(v26 + 8 * v30) ) /*0x1030b1889*/
            {
              if ( v27 == ++v30 ) /*0x1030b1891*/
                goto LABEL_49; /*0x1030b1891*/
            }
          }
          if ( (v29 & 0x82) != 0 && *((__int16 *)v20 + 22) >= 0 ) /*0x1030b18a5*/
          {
            v31 = *v101; /*0x1030b18b2*/
            v32 = sqlite3ExprCollSeq(a1: *v101, a2: *(_QWORD *)v107, a3: v26, a4: v27, a5, a6: v113); /*0x1030b18bf*/
            v33 = v31; /*0x1030b18c4*/
            v34 = (_QWORD *)v32; /*0x1030b18c7*/
            if ( v32 == 0 ) /*0x1030b18cd*/
              v34 = *(_QWORD **)(*v33 + 16); /*0x1030b18d2*/
            v35 = (__int64 *)sqlite3BinaryCompareCollSeq( /*0x1030b18f5*/
                               a1: v33,
                               a2: *(_QWORD *)(*(_QWORD *)v28 + ((*(_DWORD *)(*(_QWORD *)v28 + 4LL) & 0x400u) >> 7) + 16LL),
                               a3: *(_QWORD *)(*(_QWORD *)v28 + 8LL * ((*(_DWORD *)(*(_QWORD *)v28 + 4LL) & 0x400) == 0) + 16));
            if ( v35 != nullptr ) /*0x1030b18fd*/
            {
              v36 = *v35; /*0x1030b1902*/
              v37 = 0; /*0x1030b1905*/
              v8 = v109; /*0x1030b1907*/
              v16 = v24; /*0x1030b190b*/
              v18 = v113; /*0x1030b190e*/
              while ( 1 ) /*0x1030b1912*/
              {
                v38 = *(unsigned __int8 *)(*v34 + v37); /*0x1030b1912*/
                v39 = *(unsigned __int8 *)(v36 + v37); /*0x1030b1916*/
                if ( (_BYTE)v38 == (_BYTE)v39 ) /*0x1030b191d*/
                {
                  if ( *(_BYTE *)(*v34 + v37) == 0 ) /*0x1030b1922*/
                    goto LABEL_48; /*0x1030b1922*/
                }
                else
                {
                  a5 = (unsigned __int64)sqlite3UpperToLower; /*0x1030b1926*/
                  if ( sqlite3UpperToLower[v38] != sqlite3UpperToLower[v39] ) /*0x1030b1935*/
                    goto LABEL_49; /*0x1030b1935*/
                }
                ++v37; /*0x1030b1937*/
              }
            }
LABEL_47:
            v8 = v109; /*0x1030b193c*/
            v16 = v24; /*0x1030b1940*/
            v11 = v108; /*0x1030b1943*/
            v18 = v113; /*0x1030b1947*/
            goto LABEL_16; /*0x1030b194b*/
          }
LABEL_48:
          v16 |= 1LL << v19; /*0x1030b1950*/
          goto LABEL_49; /*0x1030b1950*/
        }
      }
    }
LABEL_16:
    ++v19; /*0x1030b17bd*/
  }
  while ( v19 != v8 ); /*0x1030b17c3*/
  v13 = v110; /*0x1030b195c*/
  matched = *(_DWORD *)(v110 + 48); /*0x1030b1960*/
  v14 = v105; /*0x1030b1965*/
  LODWORD(v15) = v93; /*0x1030b1969*/
  LODWORD(v7) = (_DWORD)v101; /*0x1030b1970*/
LABEL_50:
  v104 = v16; /*0x1030b1977*/
  if ( (matched & 0x1000) != 0 ) /*0x1030b197f*/
    goto LABEL_150; /*0x1030b197f*/
  if ( (matched & 0x100) != 0 ) /*0x1030b1989*/
  {
    if ( *(_QWORD *)(v13 + 40) != 0 && (*(_BYTE *)(v90 + 99) & 0x10) == 0 ) /*0x1030b19f3*/
    {
      matched = wherePathMatchSubqueryOB( /*0x1030b1a14*/
                  a1: (_DWORD)v7,
                  a2: v13,
                  a3: v15,
                  a4: v18,
                  a5: (_DWORD)v96,
                  a6: (_DWORD)a7,
                  a7: (__int64)&v104);
      v18 = v113; /*0x1030b1a19*/
      v8 = v109; /*0x1030b1a1d*/
      if ( matched != 0 ) /*0x1030b1a23*/
      {
        v16 = v104; /*0x1030b1a25*/
        v112 = 0; /*0x1030b1a29*/
        v116 = 0; /*0x1030b1a30*/
        goto LABEL_147; /*0x1030b1a37*/
      }
    }
    v94 = 1; /*0x1030b1a41*/
    v95 = 0; /*0x1030b1a48*/
    v16 = v104; /*0x1030b1a53*/
    v102 = nullptr; /*0x1030b1a57*/
LABEL_61:
    v91 = 1LL << v15; /*0x1030b1a62*/
    v42 = 0; /*0x1030b1a74*/
    v100 = 0; /*0x1030b1a76*/
    v97 = 0; /*0x1030b1a81*/
    v112 = 0; /*0x1030b1a8c*/
    while ( 1 ) /*0x1030b1a93*/
    {
      v43 = *(unsigned __int16 *)(v13 + 24); /*0x1030b1a93*/
      v44 = true; /*0x1030b1a99*/
      v45 = 1; /*0x1030b1a9b*/
      v115 = v42; /*0x1030b1a9e*/
      if ( v42 >= v43 ) /*0x1030b1aa5*/
        break; /*0x1030b1aa5*/
      v45 = 1; /*0x1030b1aad*/
      if ( v115 < *(unsigned __int16 *)(v13 + 54) ) /*0x1030b1ab4*/
        break; /*0x1030b1ab4*/
      v46 = *(_QWORD *)(v13 + 64); /*0x1030b1ab6*/
      v47 = *(__int64 **)(v46 + 8 * v115); /*0x1030b1abf*/
      v48 = *((unsigned __int16 *)v47 + 10); /*0x1030b1ac3*/
      if ( (v48 & v103) == 0 ) /*0x1030b1acd*/
      {
        v44 = true; /*0x1030b1aeb*/
        if ( (v48 & 1) != 0 ) /*0x1030b1af1*/
        {
          v50 = *v47; /*0x1030b1af8*/
          v51 = (unsigned int)(v43 - 1); /*0x1030b1afb*/
          a5 = v115; /*0x1030b1afe*/
          while ( 1 ) /*0x1030b1b05*/
          {
            v44 = v51 == a5; /*0x1030b1b05*/
            if ( v51 == a5 ) /*0x1030b1b08*/
              break; /*0x1030b1b08*/
            v52 = *(_QWORD **)(v46 + 8 * a5++ + 8); /*0x1030b1b0a*/
            v45 = 0; /*0x1030b1b12*/
            v55 = *v52 == v50; /*0x1030b1b15*/
            v18 = v113; /*0x1030b1b18*/
            if ( v55 ) /*0x1030b1b1c*/
              goto LABEL_73; /*0x1030b1b1c*/
          }
        }
        v45 = 1; /*0x1030b1af3*/
        break; /*0x1030b1af6*/
      }
      v49 = (unsigned __int8)v116; /*0x1030b1ad8*/
      matched = 0; /*0x1030b1adb*/
      if ( (v48 & 0x180) != 0 ) /*0x1030b1ae0*/
        v49 = 0; /*0x1030b1ae0*/
      v116 = v49; /*0x1030b1ae3*/
LABEL_135:
      v42 = v115 + 1; /*0x1030b1dc8*/
      if ( v115 + 1 == v94 ) /*0x1030b1dd6*/
        goto LABEL_147; /*0x1030b1dd6*/
    }
LABEL_73:
    if ( v102 != nullptr ) /*0x1030b1b28*/
    {
      v53 = v102[3]; /*0x1030b1b2e*/
      a5 = v115; /*0x1030b1b32*/
      v54 = *(_WORD *)(v102[1] + 2 * v115); /*0x1030b1b36*/
      v106 = *(_BYTE *)(v102[7] + v115) & 1; /*0x1030b1b47*/
      if ( v54 == *(_WORD *)(v53 + 52) ) /*0x1030b1b53*/
        v54 = -1; /*0x1030b1b53*/
      LODWORD(v107) = v54; /*0x1030b1b59*/
      if ( (_BYTE)v116 != 0 ) /*0x1030b1b60*/
      {
        if ( v54 < 0 ) /*0x1030b1b65*/
        {
          v55 = v54 == -2; /*0x1030b1b9c*/
          goto LABEL_83; /*0x1030b1b9c*/
        }
        if ( v115 >= v43 ) /*0x1030b1b6b*/
        {
          v55 = (*(_BYTE *)(*(_QWORD *)(v53 + 8) + 16LL * (unsigned int)v107 + 8) & 0xF) == 0; /*0x1030b1b78*/
LABEL_83:
          v56 = (unsigned __int8)v116; /*0x1030b1ba0*/
          if ( v55 ) /*0x1030b1bab*/
            v56 = 0; /*0x1030b1bab*/
          v116 = v56; /*0x1030b1bae*/
        }
LABEL_86:
        v57 = v115; /*0x1030b1bb1*/
        if ( (_DWORD)v8 == 0 || !v44 ) /*0x1030b1bbb*/
        {
          v104 = v16; /*0x1030b1e31*/
          goto LABEL_142; /*0x1030b1e31*/
        }
        v58 = 0; /*0x1030b1bc5*/
        v59 = v16; /*0x1030b1bc8*/
        while ( 1 ) /*0x1030b1bcb*/
        {
          if ( !_bittest64((const __int64 *)&v16, v58) ) /*0x1030b1bcb*/
          {
            v60 = *(_QWORD *)&v11[12 * v58]; /*0x1030b1bf2*/
            if ( v60 != 0 ) /*0x1030b1bf9*/
            {
              v61 = *(unsigned __int8 **)&v11[12 * v58]; /*0x1030b1bff*/
              while ( 1 ) /*0x1030b1c02*/
              {
                v62 = *((_DWORD *)v61 + 1); /*0x1030b1c02*/
                if ( (v62 & 0x82000) == 0 ) /*0x1030b1c0a*/
                  break; /*0x1030b1c0a*/
                if ( (v62 & 0x80000) != 0 ) /*0x1030b1c10*/
                {
                  v63 = (unsigned __int8 **)(*((_QWORD *)v61 + 4) + 8LL); /*0x1030b1c21*/
                }
                else
                {
                  if ( *v61 != 114 ) /*0x1030b1c15*/
                    break; /*0x1030b1c15*/
                  v63 = (unsigned __int8 **)(v61 + 16); /*0x1030b1c17*/
                }
                v61 = *v63; /*0x1030b1c25*/
                if ( v61 == nullptr ) /*0x1030b1c2b*/
                  goto LABEL_89; /*0x1030b1c2b*/
              }
              if ( (v111 & 0xC0) == 0 ) /*0x1030b1c3b*/
                v45 = 0; /*0x1030b1c3b*/
              if ( (int)v107 < -1 ) /*0x1030b1c43*/
              {
                if ( (unsigned int)sqlite3ExprCompareSkip( /*0x1030b1c97*/
                                     a1: v61,
                                     a2: *(_QWORD *)(v102[10] + 24 * v57 + 8),
                                     a3: (unsigned int)v18) == 0 )
                {
                  v60 = *(_QWORD *)&v11[12 * v58]; /*0x1030b1cad*/
LABEL_113:
                  v65 = *v101; /*0x1030b1cb0*/
                  v66 = (__int64 *)sqlite3ExprCollSeq(a1: *v101, a2: v60, a3: v57, a4: v64, a5, a6: v18); /*0x1030b1cbd*/
                  if ( v66 == nullptr ) /*0x1030b1cc5*/
                    v66 = *(__int64 **)(*v65 + 16); /*0x1030b1cca*/
                  v67 = *v66; /*0x1030b1cce*/
                  v68 = 0; /*0x1030b1ce4*/
                  v8 = v109; /*0x1030b1ce6*/
                  v16 = v59; /*0x1030b1cea*/
                  v11 = v108; /*0x1030b1ced*/
                  v18 = v113; /*0x1030b1cf1*/
                  while ( 1 ) /*0x1030b1cf5*/
                  {
                    v69 = *(unsigned __int8 *)(v67 + v68); /*0x1030b1cf5*/
                    v70 = *(unsigned __int8 *)(*(_QWORD *)(v102[8] + 8 * v115) + v68); /*0x1030b1cf9*/
                    if ( (_BYTE)v69 == (_BYTE)v70 ) /*0x1030b1d00*/
                    {
                      if ( *(_BYTE *)(v67 + v68) == 0 ) /*0x1030b1d05*/
                        goto LABEL_121; /*0x1030b1d05*/
                    }
                    else
                    {
                      a5 = (unsigned __int64)sqlite3UpperToLower; /*0x1030b1d09*/
                      if ( sqlite3UpperToLower[v69] != sqlite3UpperToLower[v70] ) /*0x1030b1d18*/
                        goto LABEL_111; /*0x1030b1d18*/
                    }
                    ++v68; /*0x1030b1d1a*/
                  }
                }
                v8 = v109; /*0x1030b1c99*/
                v16 = v59; /*0x1030b1c9d*/
                v18 = v113; /*0x1030b1ca0*/
LABEL_111:
                v57 = v115; /*0x1030b1ca4*/
              }
              else if ( (*v61 | 2) == 0xAA && *((_DWORD *)v61 + 10) == (_DWORD)v18 ) /*0x1030b1c5a*/
              {
                v64 = (unsigned int)v107; /*0x1030b1c64*/
                if ( (_DWORD)v107 == *((__int16 *)v61 + 22) ) /*0x1030b1c69*/
                {
                  if ( (_DWORD)v107 != -1 ) /*0x1030b1c72*/
                    goto LABEL_113; /*0x1030b1c72*/
LABEL_121:
                  v57 = v115; /*0x1030b1d1f*/
                  if ( (v111 & 0x80u) != 0 ) /*0x1030b1d27*/
                    *(_WORD *)(v110 + 30) = v115 + 1; /*0x1030b1d30*/
                  if ( (v111 & 0x40) != 0 ) /*0x1030b1d38*/
                  {
                    matched = v58; /*0x1030b1d7d*/
                    LOBYTE(v72) = v11[12 * (unsigned int)v58 + 8]; /*0x1030b1d84*/
LABEL_128:
                    v13 = v110; /*0x1030b1d89*/
                  }
                  else
                  {
                    if ( (_BYTE)v100 != 0 ) /*0x1030b1d41*/
                    {
                      v71 = (unsigned __int8)v97 ^ (unsigned int)v106; /*0x1030b1d51*/
                      matched = v58; /*0x1030b1d53*/
                      LOBYTE(v72) = v11[12 * (unsigned int)v58 + 8]; /*0x1030b1d5a*/
                      v57 = v115; /*0x1030b1d67*/
                      if ( (_DWORD)v71 == (v72 & 1) ) /*0x1030b1d6b*/
                      {
                        LOBYTE(v71) = 1; /*0x1030b1d71*/
                        v100 = v71; /*0x1030b1d74*/
                        goto LABEL_128; /*0x1030b1d7b*/
                      }
LABEL_142:
                      v76 = (unsigned __int8)v116; /*0x1030b1e35*/
                      matched = 0; /*0x1030b1e41*/
                      if ( (unsigned int)v95 > (unsigned int)v57 ) /*0x1030b1e46*/
                        v76 = 0; /*0x1030b1e46*/
                      if ( (_DWORD)v57 == 0 ) /*0x1030b1e4b*/
                        v76 = 0; /*0x1030b1e4b*/
                      v116 = v76; /*0x1030b1e4e*/
                      v14 = v105; /*0x1030b1e51*/
                      v13 = v110; /*0x1030b1e55*/
LABEL_147:
                      if ( (_BYTE)v112 != 0 ) /*0x1030b1e5d*/
                      {
                        LOBYTE(matched) = 1; /*0x1030b1e5f*/
                        v116 = matched; /*0x1030b1e61*/
                        goto LABEL_150; /*0x1030b1e64*/
                      }
                      if ( (_BYTE)v116 == 0 ) /*0x1030b1e6a*/
                        goto LABEL_168; /*0x1030b1e6a*/
LABEL_150:
                      v77 = *(_QWORD *)(v13 + 8) | v14; /*0x1030b1e70*/
                      v105 = v77; /*0x1030b1e78*/
                      if ( (_DWORD)v8 != 0 ) /*0x1030b1e7c*/
                      {
                        v115 = ~v77; /*0x1030b1e85*/
                        v78 = v11; /*0x1030b1e89*/
                        for ( i = 0; v8 != i; ++i ) /*0x1030b1e8c*/
                        {
                          v80 = 1LL << i; /*0x1030b1e98*/
                          if ( !_bittest64((const __int64 *)&v16, i) ) /*0x1030b1e9f*/
                          {
                            if ( *(_QWORD *)v78 == 0 ) /*0x1030b1eac*/
                            {
                              v82 = 0; /*0x1030b1f20*/
                              goto LABEL_158; /*0x1030b1f20*/
                            }
                            v81 = v16; /*0x1030b1eb8*/
                            v82 = sqlite3WhereExprUsageNN(a1: v86, a2: *(_QWORD *)v78); /*0x1030b1ebb*/
                            v16 = v81; /*0x1030b1ec0*/
                            v8 = v109; /*0x1030b1ec3*/
                            if ( v82 != 0 ) /*0x1030b1eca*/
                              goto LABEL_158; /*0x1030b1eca*/
                            v85 = 1; /*0x1030b1ecc*/
                            v84[0] = 0; /*0x1030b1ed5*/
                            v84[1] = exprNodeIsConstant; /*0x1030b1ee7*/
                            v84[2] = sqlite3SelectWalkFail; /*0x1030b1ef5*/
                            sqlite3WalkExprNN(a1: v84); /*0x1030b1f06*/
                            if ( v85 != 0 ) /*0x1030b1f13*/
                            {
                              v82 = 0; /*0x1030b1f15*/
                              v8 = v109; /*0x1030b1f17*/
                              v16 = v81; /*0x1030b1f1b*/
LABEL_158:
                              v11 = v108; /*0x1030b1f22*/
                              if ( (v82 & v115) != 0 ) /*0x1030b1f2a*/
                                v80 = 0; /*0x1030b1f2c*/
                              v16 |= v80; /*0x1030b1f2f*/
                              goto LABEL_161; /*0x1030b1f2f*/
                            }
                            v8 = v109; /*0x1030b1f44*/
                            v16 = v81; /*0x1030b1f48*/
                            v11 = v108; /*0x1030b1f4b*/
                          }
LABEL_161:
                          v78 += 12; /*0x1030b1f35*/
                        }
                      }
                      v104 = v16; /*0x1030b1f51*/
                      v7 = v101; /*0x1030b1f55*/
                      v14 = v105; /*0x1030b1f5c*/
                      v13 = v110; /*0x1030b1f60*/
                      v15 = v93; /*0x1030b1f64*/
LABEL_165:
                      v83 = v15++ < v92; /*0x1030b1f6b*/
                      v114 = v16 < v99 && v83; /*0x1030b1f85*/
                      if ( !v114 ) /*0x1030b1f88*/
                        goto LABEL_168; /*0x1030b1f88*/
                      goto LABEL_8; /*0x1030b1f88*/
                    }
                    matched = v58; /*0x1030b1dde*/
                    v72 = 3 * v58; /*0x1030b1de1*/
                    LOBYTE(v72) = v11[12 * (unsigned int)v58 + 8]; /*0x1030b1de5*/
                    v74 = v72; /*0x1030b1dea*/
                    LOBYTE(v74) = v72 & 1; /*0x1030b1dec*/
                    v75 = v74; /*0x1030b1def*/
                    LOBYTE(v75) = v106 ^ v72 & 1; /*0x1030b1df4*/
                    v97 = v75; /*0x1030b1df7*/
                    LOBYTE(v75) = 1; /*0x1030b1dfe*/
                    v100 = v75; /*0x1030b1e01*/
                    if ( (v72 & 1) != (_BYTE)v106 ) /*0x1030b1e0b*/
                      *a7 |= v91; /*0x1030b1e18*/
                    v13 = v110; /*0x1030b1e1b*/
                    v57 = v115; /*0x1030b1e1f*/
                  }
                  if ( (v72 & 2) != 0 ) /*0x1030b1d90*/
                  {
                    if ( v57 != *(unsigned __int16 *)(v13 + 24) ) /*0x1030b1d9b*/
                      goto LABEL_142; /*0x1030b1d9b*/
                    v13 = v110; /*0x1030b1da1*/
                    *(_BYTE *)(v110 + 50) |= 8u; /*0x1030b1da5*/
                  }
                  v73 = (unsigned __int8)v112; /*0x1030b1db2*/
                  if ( (_DWORD)v107 == -1 ) /*0x1030b1dba*/
                    v73 = 1; /*0x1030b1dba*/
                  v112 = v73; /*0x1030b1dbd*/
                  v16 |= 1LL << matched; /*0x1030b1dc0*/
                  v14 = v105; /*0x1030b1dc4*/
                  goto LABEL_135; /*0x1030b1dc4*/
                }
              }
            }
          }
LABEL_89:
          if ( v45 != 0 && ++v58 < v8 ) /*0x1030b1be0*/
            continue; /*0x1030b1be0*/
          goto LABEL_142; /*0x1030b1be0*/
        }
      }
    }
    else
    {
      LODWORD(v107) = -1; /*0x1030b1b7f*/
      v106 = 0; /*0x1030b1b86*/
      if ( (_BYTE)v116 != 0 ) /*0x1030b1b91*/
        goto LABEL_86; /*0x1030b1b91*/
    }
    v116 = 0; /*0x1030b1b93*/
    goto LABEL_86; /*0x1030b1b9a*/
  }
  v40 = *(_QWORD *)(v13 + 32); /*0x1030b198b*/
  if ( v40 != 0 && (*(_BYTE *)(v40 + 99) & 4) == 0 ) /*0x1030b199d*/
  {
    v41 = *(unsigned __int16 *)(v40 + 96); /*0x1030b19a3*/
    LOBYTE(matched) = *(_BYTE *)(v40 + 98) != 0 && (matched & 0x8000u) == 0; /*0x1030b19b4*/
    v116 = matched; /*0x1030b19b6*/
    v94 = v41; /*0x1030b19b9*/
    if ( v41 == 0 ) /*0x1030b19c3*/
    {
      v112 = 0; /*0x1030b1e28*/
      goto LABEL_147; /*0x1030b1e2f*/
    }
    v102 = (_QWORD *)v40; /*0x1030b19c9*/
    v95 = *(unsigned __int16 *)(v40 + 94); /*0x1030b19d4*/
    goto LABEL_61; /*0x1030b19db*/
  }
LABEL_4:
  LOBYTE(v9) = 0; /*0x1030b166a*/
  return (unsigned int)(char)v9; /*0x1030b166f*/
}

// Address: 0x1030b2002 | Name: _whereLoopIsNoBetter
_BOOL8 __fastcall whereLoopIsNoBetter(__int64 a1, __int64 a2)
{
  _BOOL8 result; // rax

  result = true; /*0x1030b2002*/
  if ( (*(_BYTE *)(a1 + 49) & 2) != 0 && (*(_BYTE *)(a2 + 49) & 2) != 0 ) /*0x1030b2011*/
    return *(_WORD *)(*(_QWORD *)(a1 + 32) + 92LL) >= *(_WORD *)(*(_QWORD *)(a2 + 32) + 92LL); /*0x1030b2029*/
  return result; /*0x1030b202d*/
}

// Address: 0x1030b202e | Name: _wherePathMatchSubqueryOB
_BOOL8 __fastcall wherePathMatchSubqueryOB(__int64 a1, __int64 a2, char a3, int a4, int *a5, _QWORD *a6, __int64 *a7)
{
  int *v8; // r11
  __int64 v9; // r15
  unsigned __int64 v10; // rbx
  _BYTE *v11; // r14
  __int64 v12; // r12
  int v13; // edx
  unsigned int v14; // edx
  _WORD *v15; // r11
  __int64 v16; // r12
  __int64 v17; // rcx
  int v18; // r8d
  __int64 v19; // rsi
  char v20; // r10
  char v21; // si
  __int64 v24; // [rsp+10h] [rbp-30h]

  v8 = *(int **)(a2 + 40); /*0x1030b2041*/
  v9 = *a7; /*0x1030b2045*/
  v10 = -1; /*0x1030b2048*/
  v11 = a5; /*0x1030b204f*/
  do /*0x1030b205d*/
  {
    ++v10; /*0x1030b2052*/
    v11 += 24; /*0x1030b2055*/
  }
  while ( _bittest64(&v9, v10) ); /*0x1030b205d*/
  v12 = *v8; /*0x1030b205f*/
  if ( v12 <= 0 ) /*0x1030b2065*/
    return false; /*0x1030b2175*/
  v24 = 1LL << a3; /*0x1030b2081*/
  v13 = v10; /*0x1030b2085*/
  if ( *a5 > (__int64)(int)v10 ) /*0x1030b208b*/
    v13 = *a5; /*0x1030b208b*/
  v14 = v13 - v10; /*0x1030b208f*/
  v15 = v8 + 7; /*0x1030b2098*/
  v16 = -v12; /*0x1030b209c*/
  v17 = 0; /*0x1030b209f*/
  LOBYTE(v18) = 0; /*0x1030b20a1*/
  while ( -(__int64)v14 != v17 ) /*0x1030b20a7*/
  {
    if ( *v15 == 0 /*0x1030b20e6*/
      || (*(unsigned __int8 *)(v19 = *((_QWORD *)v11 - 2)) | 2) != 0xAA
      || *(_DWORD *)(v19 + 40) != a4
      || (unsigned __int16)*v15 - 1 != *(__int16 *)(v19 + 44) )
    {
LABEL_22:
      v18 = -(int)v17; /*0x1030b216e*/
      return v18 != 0; /*0x1030b2173*/
    }
    if ( (*(_BYTE *)(a1 + 60) & 0x40) == 0 ) /*0x1030b20f0*/
    {
      v20 = *((_BYTE *)v15 - 4); /*0x1030b20f5*/
      v21 = *v11 ^ v20; /*0x1030b20fc*/
      if ( (v21 & 2) != 0 ) /*0x1030b2103*/
        goto LABEL_22; /*0x1030b2103*/
      if ( v17 != 0 ) /*0x1030b2108*/
      {
        if ( ((unsigned __int8)v18 ^ v20 & 1) != (*v11 & 1) ) /*0x1030b2118*/
          goto LABEL_21; /*0x1030b2118*/
      }
      else
      {
        v18 = 0; /*0x1030b211c*/
        if ( (v21 & 1) != 0 ) /*0x1030b2123*/
        {
          if ( (*(_BYTE *)(a2 + 51) & 2) != 0 ) /*0x1030b212d*/
            return v18 != 0; /*0x1030b212d*/
          *a6 |= v24; /*0x1030b2137*/
          v9 = *a7; /*0x1030b213e*/
          LOBYTE(v18) = 1; /*0x1030b2141*/
        }
      }
    }
    v9 |= 1LL << v10; /*0x1030b2144*/
    *a7 = v9; /*0x1030b214c*/
    ++v10; /*0x1030b214f*/
    --v17; /*0x1030b2152*/
    v15 += 12; /*0x1030b2155*/
    v11 += 24; /*0x1030b2159*/
    if ( v16 == v17 ) /*0x1030b2160*/
    {
LABEL_21:
      v18 = 1; /*0x1030b2166*/
      return v18 != 0; /*0x1030b216c*/
    }
  }
  v18 = v14; /*0x1030b2179*/
  return v18 != 0; /*0x1030b2184*/
}

// Address: 0x1030b218f | Name: _whereIndexedExprCleanup
__int64 __fastcall whereIndexedExprCleanup(__int64 a1, _QWORD *a2)
{
  _QWORD *i; // r15
  __int64 result; // rax

  for ( i = (_QWORD *)*a2; *a2 != 0; i = (_QWORD *)*a2 ) /*0x1030b219f*/
  {
    *a2 = i[3]; /*0x1030b21ab*/
    if ( *i != 0 ) /*0x1030b21b4*/
      sqlite3ExprDeleteNN(a1, a2: *i); /*0x1030b21b9*/
    result = sqlite3DbFreeNN(a1, a2: i); /*0x1030b21c4*/
  }
  return result; /*0x1030b21d5*/
}

// Address: 0x1030b2b4b | Name: _whereApplyPartialIndexConstraints
__int64 __fastcall whereApplyPartialIndexConstraints(__int64 a1, unsigned int a2, __int64 a3)
{
  __int64 i; // r15
  __int64 result; // rax
  _BYTE *v7; // r12
  int v8; // r13d

  for ( i = a1; *(_BYTE *)i == 44; i = *(_QWORD *)(i + 24) ) /*0x1030b2b65*/
    result = whereApplyPartialIndexConstraints(a1: *(_QWORD *)(i + 16), a2, a3); /*0x1030b2b71*/
  if ( *(int *)(a3 + 20) > 0 ) /*0x1030b2b84*/
  {
    v7 = (_BYTE *)(*(_QWORD *)(a3 + 32) + 18LL); /*0x1030b2b8a*/
    v8 = 0; /*0x1030b2b8e*/
    do /*0x1030b2bbe*/
    {
      if ( (*v7 & 4) == 0 ) /*0x1030b2b96*/
      {
        result = sqlite3ExprCompare(a1: 0, a2: *(_QWORD *)(v7 - 18), a3: i, a4: a2); /*0x1030b2ba5*/
        if ( (_DWORD)result == 0 ) /*0x1030b2bac*/
          *v7 |= 4u; /*0x1030b2bae*/
      }
      ++v8; /*0x1030b2bb3*/
      v7 += 56; /*0x1030b2bb6*/
    }
    while ( v8 < *(_DWORD *)(a3 + 20) ); /*0x1030b2bbe*/
  }
  return result; /*0x1030b2bc4*/
}

// Address: 0x1030b2bcf | Name: _whereLoopIsOneRow
__int64 __fastcall whereLoopIsOneRow(__int64 a1)
{
  __int64 v1; // rdx
  __int64 result; // rax
  __int64 v3; // rcx
  __int64 v4; // rsi

  v1 = *(_QWORD *)(a1 + 32); /*0x1030b2bd3*/
  result = 0; /*0x1030b2bd7*/
  if ( *(_BYTE *)(v1 + 98) != 0 && *(_WORD *)(a1 + 54) == 0 ) /*0x1030b2be4*/
  {
    v3 = *(unsigned __int16 *)(a1 + 24); /*0x1030b2be6*/
    if ( (_WORD)v3 == *(_WORD *)(v1 + 94) ) /*0x1030b2bee*/
    {
      result = 1; /*0x1030b2bf0*/
      if ( *(_WORD *)(a1 + 24) != 0 ) /*0x1030b2bf8*/
      {
        v4 = 0; /*0x1030b2bfe*/
        while ( (*(_WORD *)(*(_QWORD *)(*(_QWORD *)(a1 + 64) + 8 * v4) + 20LL) & 0x180) == 0 ) /*0x1030b2c0e*/
        {
          if ( v3 == ++v4 ) /*0x1030b2c16*/
            return result; /*0x1030b2c16*/
        }
        return 0; /*0x1030b2c1a*/
      }
    }
  }
  return result; /*0x1030b2c1c*/
}

// Address: 0x1030b3721 | Name: _windowExprGtZero
_BOOL8 __fastcall windowExprGtZero(__int64 *a1, unsigned __int8 *a2)
{
  __int64 v2; // rdi
  __int64 v3; // rbx
  _BOOL4 v4; // r14d
  _QWORD v6[3]; // [rsp+8h] [rbp-18h] BYREF

  v2 = *a1; /*0x1030b372c*/
  v6[0] = 0; /*0x1030b372f*/
  if ( a2 != nullptr /*0x1030b3757*/
    && (valueFromExpr(a1: v2, a2, a3: *(unsigned __int8 *)(v2 + 100), a4: 67, a5: v6), v3 = v6[0], v6[0] != 0) )
  {
    v4 = (int)sqlite3VdbeIntValue(a1: v6[0]) > 0; /*0x1030b3766*/
  }
  else
  {
    v3 = 0; /*0x1030b376c*/
    v4 = false; /*0x1030b376e*/
  }
  sqlite3ValueFree(a1: v3); /*0x1030b3774*/
  return v4; /*0x1030b377c*/
}

// Address: 0x1030b3785 | Name: _windowCheckValue
unsigned __int64 __fastcall windowCheckValue(__int64 a1, unsigned int a2, int a3)
{
  __int64 Vdbe; // r15
  char v7; // al
  unsigned __int8 v8; // al
  unsigned int v9; // r14d
  char v10; // al
  unsigned __int8 v11; // al
  unsigned int v12; // r12d
  __int64 v13; // rcx
  unsigned int v14; // eax
  __int64 v15; // rdx
  __int64 v16; // rax
  __int64 v17; // rax
  unsigned __int64 result; // rax
  __int64 v19; // rcx
  __int64 v20; // rdx
  unsigned int v21; // [rsp+0h] [rbp-2Ch]

  Vdbe = sqlite3GetVdbe(a1); /*0x1030b37a1*/
  v7 = *(_BYTE *)(a1 + 31); /*0x1030b37a4*/
  if ( v7 != 0 ) /*0x1030b37a9*/
  {
    v8 = v7 - 1; /*0x1030b37ab*/
    *(_BYTE *)(a1 + 31) = v8; /*0x1030b37ad*/
    v9 = *(_DWORD *)(a1 + 4LL * v8 + 176); /*0x1030b37b3*/
  }
  else
  {
    v9 = *(_DWORD *)(a1 + 64) + 1; /*0x1030b37c1*/
    *(_DWORD *)(a1 + 64) = v9; /*0x1030b37c4*/
  }
  sqlite3VdbeAddOp3(a1: Vdbe, a2: 72, a3: 0, a4: v9, a5: 0); /*0x1030b37d8*/
  if ( a3 < 3 ) /*0x1030b37e1*/
  {
    sqlite3VdbeAddOp3(a1: Vdbe, a2: 13, a3: a2, a4: (unsigned int)(*(_DWORD *)(Vdbe + 144) + 2), a5: 0); /*0x1030b3818*/
    LODWORD(v13) = *(_DWORD *)(Vdbe + 144); /*0x1030b381d*/
  }
  else
  {
    v21 = a2; /*0x1030b37e3*/
    v10 = *(_BYTE *)(a1 + 31); /*0x1030b37e7*/
    if ( v10 != 0 ) /*0x1030b37ec*/
    {
      v11 = v10 - 1; /*0x1030b37ee*/
      *(_BYTE *)(a1 + 31) = v11; /*0x1030b37f0*/
      v12 = *(_DWORD *)(a1 + 4LL * v11 + 176); /*0x1030b37f6*/
    }
    else
    {
      v12 = *(_DWORD *)(a1 + 64) + 1; /*0x1030b382a*/
      *(_DWORD *)(a1 + 64) = v12; /*0x1030b382d*/
    }
    v14 = sqlite3VdbeAddOp3(a1: Vdbe, a2: 118, a3: 0, a4: v12, a5: 0); /*0x1030b3841*/
    sqlite3VdbeChangeP4(a1: Vdbe, a2: v14, a3: ""); /*0x1030b3857*/
    v15 = v12; /*0x1030b386e*/
    a2 = v21; /*0x1030b3871*/
    sqlite3VdbeAddOp3(a1: Vdbe, a2: 58, a3: v15, a4: (unsigned int)(*(_DWORD *)(Vdbe + 144) + 2), a5: v21); /*0x1030b3878*/
    v13 = *(int *)(Vdbe + 144); /*0x1030b387d*/
    if ( v13 > 0 ) /*0x1030b3887*/
      *(_WORD *)(*(_QWORD *)(Vdbe + 136) + 24 * v13 - 22) = 83; /*0x1030b3894*/
  }
  sqlite3VdbeAddOp3(a1: Vdbe, a2: windowCheckValue_aOp[a3], a3: v9, a4: (unsigned int)(v13 + 2), a5: a2); /*0x1030b38b5*/
  v16 = *(int *)(Vdbe + 144); /*0x1030b38ba*/
  if ( v16 > 0 ) /*0x1030b38c4*/
    *(_WORD *)(*(_QWORD *)(Vdbe + 136) + 24 * v16 - 22) = 67; /*0x1030b38d1*/
  v17 = *(_QWORD *)(a1 + 144); /*0x1030b38d8*/
  if ( v17 == 0 ) /*0x1030b38e2*/
    v17 = a1; /*0x1030b38e2*/
  *(_BYTE *)(v17 + 33) = 1; /*0x1030b38e6*/
  sqlite3VdbeAddOp3(a1: Vdbe, a2: 71, a3: 1, a4: 2, a5: 0); /*0x1030b38ff*/
  result = *(_QWORD *)Vdbe; /*0x1030b3904*/
  if ( *(_BYTE *)(*(_QWORD *)Vdbe + 103LL) == 0 ) /*0x1030b390b*/
  {
    v19 = windowCheckValue_azErr_rel[a3]; /*0x1030b3914*/
    result = *(_QWORD *)(Vdbe + 136); /*0x1030b391b*/
    v20 = 3LL * *(int *)(Vdbe + 144); /*0x1030b3929*/
    *(_BYTE *)(result + 8 * v20 - 23) = -1; /*0x1030b392d*/
    *(_QWORD *)(result + 8 * v20 - 8) = (char *)windowCheckValue_azErr_rel + v19; /*0x1030b3932*/
  }
  if ( v9 != 0 ) /*0x1030b393a*/
  {
    result = *(unsigned __int8 *)(a1 + 31); /*0x1030b393c*/
    if ( result <= 7 ) /*0x1030b3944*/
    {
      *(_BYTE *)(a1 + 31) = result + 1; /*0x1030b3949*/
      *(_DWORD *)(a1 + 4 * result + 176) = v9; /*0x1030b394c*/
    }
  }
  return result; /*0x1030b3958*/
}

// Address: 0x1030b3963 | Name: _windowAggFinal
__int64 __fastcall windowAggFinal(_QWORD *a1, int a2)
{
  __int64 v3; // r15
  __int64 result; // rax
  _QWORD *v5; // r14
  __int64 i; // r13
  unsigned int *v7; // rax
  __int64 v8; // rcx
  __int64 v9; // rdx
  __int64 v10; // rsi
  __int64 v11; // rsi
  _DWORD *v12; // rcx
  __int64 v13; // rax
  __int64 v14; // rcx
  __int64 v15; // rcx

  v3 = a1[1]; /*0x1030b3976*/
  result = sqlite3GetVdbe(a1: *a1); /*0x1030b397d*/
  if ( v3 != 0 ) /*0x1030b3985*/
  {
    v5 = (_QWORD *)result; /*0x1030b398b*/
    for ( i = v3; i != 0; i = *(_QWORD *)(i + 64) ) /*0x1030b3995*/
    {
      if ( *(_DWORD *)(v3 + 132) != 0 /*0x1030b39b1*/
        || (*(_BYTE *)((result = *(_QWORD *)(i + 80)) + 5) & 0x10) == 0
        || *(_BYTE *)(i + 33) == 91 )
      {
        if ( *(_DWORD *)(i + 104) == 0 ) /*0x1030b39bc*/
        {
          v7 = *(unsigned int **)(*(_QWORD *)(i + 112) + 32LL); /*0x1030b39c6*/
          if ( v7 != nullptr ) /*0x1030b39cd*/
            v8 = *v7; /*0x1030b39cf*/
          else
            v8 = 0; /*0x1030b39d3*/
          v9 = *(unsigned int *)(i + 92); /*0x1030b39d5*/
          if ( a2 != 0 ) /*0x1030b39db*/
          {
            sqlite3VdbeAddOp3(a1: v5, a2: 166, a3: v9, a4: v8, a5: 0); /*0x1030b39e8*/
            v10 = *(_QWORD *)(i + 80); /*0x1030b39ed*/
            if ( *(_BYTE *)(*v5 + 103LL) != 0 ) /*0x1030b39f8*/
            {
              if ( (*(_BYTE *)(v10 + 4) & 0x10) != 0 ) /*0x1030b3a02*/
                sqlite3DbNNFreeNN(a1: *v5, a2: v10); /*0x1030b3a08*/
            }
            else
            {
              v13 = v5[17]; /*0x1030b3ab9*/
              v14 = 3LL * *((int *)v5 + 36); /*0x1030b3ac7*/
              *(_BYTE *)(v13 + 8 * v14 - 23) = -7; /*0x1030b3acb*/
              *(_QWORD *)(v13 + 8 * v14 - 8) = v10; /*0x1030b3ad0*/
            }
            sqlite3VdbeAddOp3(a1: v5, a2: 81, a3: *(unsigned int *)(i + 92), a4: *(unsigned int *)(i + 96), a5: 0); /*0x1030b3ae8*/
            result = sqlite3VdbeAddOp3(a1: v5, a2: 76, a3: 0, a4: *(unsigned int *)(i + 92), a5: 0); /*0x1030b3afe*/
          }
          else
          {
            result = sqlite3VdbeAddOp3(a1: v5, a2: 165, a3: v9, a4: v8, a5: *(unsigned int *)(i + 96)); /*0x1030b3a1e*/
            v11 = *(_QWORD *)(i + 80); /*0x1030b3a23*/
            if ( *(_BYTE *)(*v5 + 103LL) != 0 ) /*0x1030b3a2e*/
            {
              if ( (*(_BYTE *)(v11 + 4) & 0x10) != 0 ) /*0x1030b3a38*/
                result = sqlite3DbNNFreeNN(a1: *v5, a2: v11); /*0x1030b3a3e*/
            }
            else
            {
              result = v5[17]; /*0x1030b3b12*/
              v15 = 3LL * *((int *)v5 + 36); /*0x1030b3b20*/
              *(_BYTE *)(result + 8 * v15 - 23) = -7; /*0x1030b3b24*/
              *(_QWORD *)(result + 8 * v15 - 8) = v11; /*0x1030b3b29*/
            }
          }
        }
      }
      else
      {
        sqlite3VdbeAddOp3(a1: v5, a2: 76, a3: 0, a4: *(unsigned int *)(i + 96), a5: 0); /*0x1030b3a59*/
        sqlite3VdbeAddOp3(a1: v5, a2: 32, a3: *(unsigned int *)(i + 100), a4: 0, a5: 0); /*0x1030b3a6f*/
        sqlite3VdbeAddOp3(a1: v5, a2: 95, a3: *(unsigned int *)(i + 100), a4: 0, a5: *(unsigned int *)(i + 96)); /*0x1030b3a86*/
        result = *((unsigned int *)v5 + 36); /*0x1030b3a8b*/
        v12 = &sqlite3VdbeGetOp_dummy; /*0x1030b3a99*/
        if ( *(_BYTE *)(*v5 + 103LL) == 0 ) /*0x1030b3a9c*/
          v12 = (_DWORD *)(v5[17] + 24LL * (int)result - 48); /*0x1030b3ab0*/
        v12[2] = result; /*0x1030b3ab4*/
      }
    }
  }
  return result; /*0x1030b3b34*/
}

// Address: 0x1030b3b3f | Name: _windowReturnOneRow
__int64 __fastcall windowReturnOneRow(__int64 *a1)
{
  __int64 v2; // rdi
  __int64 v3; // rcx
  __int64 v4; // r15
  unsigned int *v5; // rax
  unsigned int v6; // r13d
  __int64 v7; // r14
  __int64 v8; // r13
  const char *v9; // rax
  unsigned int v10; // r12d
  char v11; // al
  unsigned __int8 v12; // al
  unsigned int v13; // ebx
  int v14; // r15d
  char v15; // al
  unsigned __int8 v16; // al
  unsigned __int8 v17; // al
  unsigned int v18; // r12d
  int v19; // r15d
  bool v20; // al
  char v21; // cl
  unsigned __int8 v22; // cl
  unsigned int v23; // r13d
  __int64 v24; // rsi
  unsigned __int64 v25; // rax
  unsigned int v26; // r12d
  char v27; // al
  unsigned __int8 v28; // al
  int v29; // eax
  int v30; // eax
  __int64 v31; // rbx
  __int64 v32; // r14
  __int64 v33; // r13
  int v34; // eax
  unsigned int v35; // r12d
  __int64 v36; // rsi
  __int64 v37; // r12
  __int64 v39; // rdi
  __int64 v40; // rsi
  __int64 v41; // rdx
  __int64 v42; // rcx
  __int64 v43; // r8
  __int64 v44; // rax
  __int64 v45; // rcx
  _DWORD *v46; // rcx
  int v47; // eax
  _DWORD *v48; // rcx
  unsigned __int64 v49; // rax
  unsigned __int64 v50; // rax
  unsigned __int64 v51; // rax
  unsigned __int64 v52; // rax
  __int64 *v54; // [rsp+0h] [rbp-70h]
  int v55; // [rsp+8h] [rbp-68h]
  __int64 v56; // [rsp+10h] [rbp-60h]
  unsigned int v57; // [rsp+1Ch] [rbp-54h]
  __int64 v58; // [rsp+20h] [rbp-50h]
  unsigned int v59; // [rsp+2Ch] [rbp-44h]
  unsigned int TempRange; // [rsp+30h] [rbp-40h]
  unsigned int v61; // [rsp+34h] [rbp-3Ch]
  __int64 v62; // [rsp+38h] [rbp-38h]
  int v63; // [rsp+38h] [rbp-38h]
  unsigned int v64; // [rsp+38h] [rbp-38h]
  unsigned int v65; // [rsp+40h] [rbp-30h]
  unsigned int v66; // [rsp+40h] [rbp-30h]
  unsigned int v67; // [rsp+44h] [rbp-2Ch]
  unsigned int v68; // [rsp+44h] [rbp-2Ch]
  unsigned int v69; // [rsp+44h] [rbp-2Ch]

  v2 = *a1; /*0x1030b3b53*/
  v3 = a1[1]; /*0x1030b3b56*/
  v4 = a1[2]; /*0x1030b3b5a*/
  v54 = a1; /*0x1030b3b65*/
  v58 = v2; /*0x1030b3b69*/
  v56 = v3; /*0x1030b3b6d*/
  if ( *(_DWORD *)(v3 + 132) == 0 ) /*0x1030b3b71*/
  {
    v7 = a1[1]; /*0x1030b3b88*/
    v62 = v4; /*0x1030b3b8b*/
    while ( 1 ) /*0x1030b3b8f*/
    {
      v8 = *(_QWORD *)(v7 + 80); /*0x1030b3b8f*/
      v9 = *(const char **)(v8 + 56); /*0x1030b3b93*/
      if ( v9 == "first_value" || v9 == "nth_value" ) /*0x1030b3ba1*/
        break; /*0x1030b3bb3*/
      if ( v9 == "lag" || v9 == "lead" ) /*0x1030b3be9*/
      {
        v14 = **(_DWORD **)(*(_QWORD *)(v7 + 112) + 32LL); /*0x1030b3c09*/
        v65 = *(_DWORD *)(v7 + 100); /*0x1030b3c10*/
        v68 = *(_DWORD *)(v2 + 76) - 1; /*0x1030b3c18*/
        *(_DWORD *)(v2 + 76) = v68; /*0x1030b3c1b*/
        v15 = *(_BYTE *)(v2 + 31); /*0x1030b3c1e*/
        if ( v15 != 0 ) /*0x1030b3c23*/
        {
          v16 = v15 - 1; /*0x1030b3c29*/
          *(_BYTE *)(v2 + 31) = v16; /*0x1030b3c2b*/
          v13 = *(_DWORD *)(v2 + 4LL * v16 + 176); /*0x1030b3c31*/
        }
        else
        {
          v13 = *(_DWORD *)(v2 + 64) + 1; /*0x1030b3d3c*/
          *(_DWORD *)(v2 + 64) = v13; /*0x1030b3d3e*/
        }
        v18 = *(_DWORD *)(v56 + 88); /*0x1030b3d45*/
        if ( v14 >= 3 ) /*0x1030b3d4d*/
        {
          sqlite3VdbeAddOp3( /*0x1030b3dd8*/
            a1: v62,
            a2: 95,
            a3: v18,
            a4: (unsigned int)(*(_DWORD *)(v7 + 124) + 2),
            a5: *(unsigned int *)(v7 + 96));
          sqlite3VdbeAddOp3(a1: v62, a2: 136, a3: v18, a4: v13, a5: 0); /*0x1030b3ded*/
        }
        else
        {
          sqlite3VdbeAddOp3(a1: v62, a2: 76, a3: 0, a4: *(unsigned int *)(v7 + 96), a5: 0); /*0x1030b3d68*/
          sqlite3VdbeAddOp3(a1: v62, a2: 136, a3: v18, a4: v13, a5: 0); /*0x1030b3d81*/
          if ( v14 != 2 ) /*0x1030b3d8a*/
          {
            v4 = v62; /*0x1030b3da3*/
            sqlite3VdbeAddOp3( /*0x1030b3db4*/
              a1: v62,
              a2: 87,
              a3: v13,
              a4: 2 * (unsigned int)(*(_QWORD *)(v8 + 56) == (_QWORD)"lead") - 1,
              a5: 0);
LABEL_29:
            sqlite3VdbeAddOp3(a1: v4, a2: 30, a3: v65, a4: v68, a5: v13); /*0x1030b3e8a*/
            sqlite3VdbeAddOp3(a1: v4, a2: 95, a3: v65, a4: *(unsigned int *)(v7 + 124), a5: *(unsigned int *)(v7 + 96)); /*0x1030b3ebb*/
            sqlite3VdbeResolveLabel(a1: v4, a2: v68); /*0x1030b3ec6*/
            v2 = v58; /*0x1030b3ecd*/
            if ( v13 == 0 ) /*0x1030b3ed1*/
              goto LABEL_32; /*0x1030b3ed1*/
            v17 = *(_BYTE *)(v58 + 31); /*0x1030b3ed3*/
            if ( v17 > 7u ) /*0x1030b3ed8*/
              goto LABEL_32; /*0x1030b3ed8*/
LABEL_31:
            *(_BYTE *)(v2 + 31) = v17 + 1; /*0x1030b3eda*/
            *(_DWORD *)(v2 + 4LL * v17 + 176) = v13; /*0x1030b3ee3*/
            goto LABEL_32; /*0x1030b3ee3*/
          }
        }
        v19 = 0; /*0x1030b3df2*/
        v20 = *(_QWORD *)(v8 + 56) != (_QWORD)"lead"; /*0x1030b3e00*/
        v21 = *(_BYTE *)(v58 + 31); /*0x1030b3e07*/
        if ( v21 != 0 ) /*0x1030b3e0f*/
        {
          v22 = v21 - 1; /*0x1030b3e11*/
          *(_BYTE *)(v58 + 31) = v22; /*0x1030b3e13*/
          v23 = *(_DWORD *)(v58 + 4LL * v22 + 176); /*0x1030b3e19*/
        }
        else
        {
          v23 = *(_DWORD *)(v58 + 64) + 1; /*0x1030b3e27*/
          *(_DWORD *)(v58 + 64) = v23; /*0x1030b3e2a*/
        }
        LOBYTE(v19) = v20; /*0x1030b3e2e*/
        sqlite3VdbeAddOp3(a1: v62, a2: 95, a3: v18, a4: (unsigned int)(*(_DWORD *)(v7 + 124) + 1), a5: v23); /*0x1030b3e4a*/
        v24 = (unsigned int)(v19 + 107); /*0x1030b3e52*/
        v4 = v62; /*0x1030b3e55*/
        sqlite3VdbeAddOp3(a1: v62, a2: v24, a3: v23, a4: v13, a5: v13); /*0x1030b3e60*/
        if ( v23 != 0 ) /*0x1030b3e68*/
        {
          v25 = *(unsigned __int8 *)(v58 + 31); /*0x1030b3e6e*/
          if ( v25 <= 7 ) /*0x1030b3e76*/
          {
            *(_BYTE *)(v58 + 31) = v25 + 1; /*0x1030b3e7f*/
            *(_DWORD *)(v58 + 4 * v25 + 176) = v23; /*0x1030b3e82*/
          }
        }
        goto LABEL_29; /*0x1030b3e82*/
      }
LABEL_32:
      v7 = *(_QWORD *)(v7 + 64); /*0x1030b3eea*/
      if ( v7 == 0 ) /*0x1030b3ef1*/
        return sqlite3VdbeAddOp3(a1: v4, a2: 10, a3: *((unsigned int *)v54 + 7), a4: *((unsigned int *)v54 + 6), a5: 0); /*0x1030b3ef1*/
    }
    v67 = *(_DWORD *)(v7 + 100); /*0x1030b3bb9*/
    v10 = *(_DWORD *)(v2 + 76) - 1; /*0x1030b3bc0*/
    *(_DWORD *)(v2 + 76) = v10; /*0x1030b3bc3*/
    v11 = *(_BYTE *)(v2 + 31); /*0x1030b3bc7*/
    if ( v11 != 0 ) /*0x1030b3bcc*/
    {
      v12 = v11 - 1; /*0x1030b3bce*/
      *(_BYTE *)(v2 + 31) = v12; /*0x1030b3bd0*/
      v13 = *(_DWORD *)(v2 + 4LL * v12 + 176); /*0x1030b3bd6*/
    }
    else
    {
      v13 = *(_DWORD *)(v2 + 64) + 1; /*0x1030b3c40*/
      *(_DWORD *)(v2 + 64) = v13; /*0x1030b3c42*/
    }
    v4 = v62; /*0x1030b3c49*/
    sqlite3VdbeAddOp3(a1: v62, a2: 76, a3: 0, a4: *(unsigned int *)(v7 + 96), a5: 0); /*0x1030b3c5a*/
    if ( *(char **)(v8 + 56) == "nth_value" ) /*0x1030b3c6a*/
    {
      sqlite3VdbeAddOp3( /*0x1030b3c9d*/
        a1: v62,
        a2: 95,
        a3: *(unsigned int *)(v56 + 88),
        a4: (unsigned int)(*(_DWORD *)(v7 + 124) + 1),
        a5: v13);
      windowCheckValue(a1: v58, a2: v13, a3: 2); /*0x1030b3cad*/
    }
    else
    {
      sqlite3VdbeAddOp3(a1: v62, a2: 72, a3: 1, a4: v13, a5: 0); /*0x1030b3c7e*/
    }
    sqlite3VdbeAddOp3(a1: v62, a2: 107, a3: v13, a4: *(unsigned int *)(v7 + 104), a5: v13); /*0x1030b3cc3*/
    sqlite3VdbeAddOp3(a1: v62, a2: 55, a3: (unsigned int)(*(_DWORD *)(v7 + 104) + 1), a4: v10, a5: v13); /*0x1030b3cdc*/
    sqlite3VdbeAddOp3(a1: v62, a2: 30, a3: v67, a4: 0, a5: v13); /*0x1030b3cf5*/
    sqlite3VdbeAddOp3(a1: v62, a2: 95, a3: v67, a4: *(unsigned int *)(v7 + 124), a5: *(unsigned int *)(v7 + 96)); /*0x1030b3d0d*/
    sqlite3VdbeResolveLabel(a1: v62, a2: v10); /*0x1030b3d18*/
    v2 = v58; /*0x1030b3d1f*/
    if ( v13 == 0 ) /*0x1030b3d23*/
      goto LABEL_32; /*0x1030b3d23*/
    v17 = *(_BYTE *)(v58 + 31); /*0x1030b3d29*/
    if ( v17 >= 8u ) /*0x1030b3d2e*/
      goto LABEL_32; /*0x1030b3d2e*/
    goto LABEL_31; /*0x1030b3d2e*/
  }
  v5 = *(unsigned int **)(v3 + 24); /*0x1030b3b73*/
  if ( v5 != nullptr ) /*0x1030b3b7a*/
    v6 = *v5; /*0x1030b3b80*/
  else
    v6 = 0; /*0x1030b3efc*/
  v59 = *(_DWORD *)(v3 + 100); /*0x1030b3f02*/
  v63 = *(_DWORD *)(v2 + 76); /*0x1030b3f08*/
  v26 = v63 - 2; /*0x1030b3f0c*/
  *(_DWORD *)(v2 + 76) = v63 - 2; /*0x1030b3f10*/
  v27 = *(_BYTE *)(v2 + 31); /*0x1030b3f14*/
  if ( v27 == 0 ) /*0x1030b3f19*/
  {
    v30 = *(_DWORD *)(v2 + 64) + 1; /*0x1030b3f46*/
    v69 = v30; /*0x1030b3f48*/
LABEL_40:
    v29 = v30 + 1; /*0x1030b3f50*/
    *(_DWORD *)(v2 + 64) = v29; /*0x1030b3f52*/
    goto LABEL_41; /*0x1030b3f52*/
  }
  *(_BYTE *)(v2 + 31) = v27 - 1; /*0x1030b3f1e*/
  v69 = *(_DWORD *)(v2 + 4LL * (unsigned __int8)(v27 - 1) + 176); /*0x1030b3f2b*/
  if ( v27 == 1 ) /*0x1030b3f30*/
  {
    v30 = *(_DWORD *)(v2 + 64); /*0x1030b3f4d*/
    goto LABEL_40; /*0x1030b3f4d*/
  }
  v28 = v27 - 2; /*0x1030b3f32*/
  *(_BYTE *)(v2 + 31) = v28; /*0x1030b3f34*/
  v29 = *(_DWORD *)(v2 + 4LL * v28 + 176); /*0x1030b3f3a*/
LABEL_41:
  v66 = v29; /*0x1030b3f55*/
  v57 = v6; /*0x1030b3f5b*/
  if ( v6 != 0 ) /*0x1030b3f5f*/
  {
    v31 = v2; /*0x1030b3f61*/
    TempRange = sqlite3GetTempRange(a1: v2, a2: v6); /*0x1030b3f6c*/
    v61 = sqlite3GetTempRange(a1: v31, a2: v6); /*0x1030b3f7a*/
  }
  else
  {
    v61 = 0; /*0x1030b3f7f*/
    TempRange = 0; /*0x1030b3f86*/
  }
  v64 = v63 - 1; /*0x1030b3f93*/
  sqlite3VdbeAddOp3(a1: v4, a2: 136, a3: *(unsigned int *)(v56 + 88), a4: v69, a5: 0); /*0x1030b3fac*/
  windowReadPeerValues(a1, a2: *(unsigned int *)(v56 + 88), a3: TempRange); /*0x1030b3fba*/
  v32 = v56; /*0x1030b3fbf*/
  do /*0x1030b3fdf*/
  {
    sqlite3VdbeAddOp3(a1: v4, a2: 76, a3: 0, a4: *(unsigned int *)(v32 + 92), a5: 0); /*0x1030b3fd3*/
    v32 = *(_QWORD *)(v32 + 64); /*0x1030b3fd8*/
  }
  while ( v32 != 0 ); /*0x1030b3fdf*/
  sqlite3VdbeAddOp3(a1: v4, a2: 23, a3: v59, a4: v26, a5: *(unsigned int *)(v56 + 132)); /*0x1030b3ffe*/
  v33 = *(int *)(v4 + 144); /*0x1030b4003*/
  sqlite3VdbeAddOp3(a1: v4, a2: 136, a3: v59, a4: v66, a5: 0); /*0x1030b401f*/
  sqlite3VdbeAddOp3(a1: v4, a2: 55, a3: *(unsigned int *)(v56 + 136), a4: v26, a5: v66); /*0x1030b4038*/
  v34 = *(unsigned __int8 *)(v56 + 36); /*0x1030b403d*/
  v35 = v64; /*0x1030b4048*/
  if ( v34 != 67 ) /*0x1030b404c*/
  {
    if ( v34 == 86 ) /*0x1030b4055*/
    {
      sqlite3VdbeAddOp3(a1: v4, a2: 54, a3: v69, a4: v64, a5: v66); /*0x1030b4069*/
    }
    else
    {
      v36 = *(_QWORD *)(v56 + 24); /*0x1030b4077*/
      v55 = 0; /*0x1030b407b*/
      if ( v36 != 0 ) /*0x1030b4086*/
      {
        v37 = sqlite3KeyInfoFromExprList(a1: v58, a2: v36, a3: 0, a4: 0); /*0x1030b4095*/
        LOBYTE(v34) = *(_BYTE *)(v56 + 36); /*0x1030b4098*/
      }
      else
      {
        v37 = 0; /*0x1030b409d*/
      }
      if ( (_BYTE)v34 == 95 ) /*0x1030b40a2*/
        v55 = sqlite3VdbeAddOp3(a1: v4, a2: 54, a3: v69, a4: 0, a5: v66); /*0x1030b40ba*/
      if ( v37 != 0 ) /*0x1030b40c1*/
      {
        windowReadPeerValues(a1: v54, a2: v59, a3: v61); /*0x1030b40ce*/
        sqlite3VdbeAddOp3(a1: v4, a2: 91, a3: v61, a4: TempRange, a5: v57); /*0x1030b40e4*/
        if ( *(_BYTE *)(*(_QWORD *)v4 + 103LL) != 0 ) /*0x1030b40f0*/
        {
          if ( *(_QWORD *)(*(_QWORD *)v4 + 736LL) == 0 && (*(_DWORD *)v37)-- == 1 ) /*0x1030b40fc*/
            sqlite3DbNNFreeNN(a1: *(_QWORD *)(v37 + 16), a2: v37); /*0x1030b410a*/
        }
        else
        {
          v44 = *(_QWORD *)(v4 + 136); /*0x1030b4127*/
          v45 = 3LL * *(int *)(v4 + 144); /*0x1030b4135*/
          *(_BYTE *)(v44 + 8 * v45 - 23) = -8; /*0x1030b4139*/
          *(_QWORD *)(v44 + 8 * v45 - 8) = v37; /*0x1030b413e*/
        }
        v41 = (unsigned int)(*(_DWORD *)(v4 + 144) + 1); /*0x1030b414a*/
        v39 = v4; /*0x1030b414c*/
        v40 = 14; /*0x1030b414f*/
        v35 = v64; /*0x1030b4154*/
        v42 = v64; /*0x1030b4158*/
        v43 = (unsigned int)v41; /*0x1030b415b*/
      }
      else
      {
        v39 = v4; /*0x1030b4111*/
        v40 = 9; /*0x1030b4114*/
        v41 = 0; /*0x1030b4119*/
        v35 = v64; /*0x1030b411b*/
        v42 = v64; /*0x1030b411f*/
        v43 = 0; /*0x1030b4122*/
      }
      sqlite3VdbeAddOp3(a1: v39, a2: v40, a3: v41, a4: v42, a5: v43); /*0x1030b415e*/
      if ( v55 != 0 ) /*0x1030b4167*/
      {
        if ( *(_BYTE *)(*(_QWORD *)v4 + 103LL) != 0 ) /*0x1030b4177*/
          v46 = &sqlite3VdbeGetOp_dummy; /*0x1030b4179*/
        else
          v46 = (_DWORD *)(*(_QWORD *)(v4 + 136) + 24LL * v55); /*0x1030b418e*/
        v46[2] = *(_DWORD *)(v4 + 144); /*0x1030b4195*/
      }
    }
  }
  windowAggStep(a1: v54, a2: v56, a3: v59, a4: 0, a5: *((unsigned int *)v54 + 8)); /*0x1030b41aa*/
  sqlite3VdbeResolveLabel(a1: v4, a2: v35); /*0x1030b41b5*/
  sqlite3VdbeAddOp3(a1: v4, a2: 40, a3: v59, a4: (unsigned int)v33, a5: 0); /*0x1030b41ca*/
  v47 = *(_DWORD *)(v4 + 144); /*0x1030b41cf*/
  if ( *(_BYTE *)(*(_QWORD *)v4 + 103LL) != 0 ) /*0x1030b41dd*/
  {
    dword_10D2F8ED0 = *(_DWORD *)(v4 + 144); /*0x1030b41df*/
    v48 = &sqlite3VdbeGetOp_dummy; /*0x1030b41e5*/
  }
  else
  {
    v48 = (_DWORD *)(*(_QWORD *)(v4 + 136) + 24 * v33 + 24); /*0x1030b4204*/
    *(_DWORD *)(*(_QWORD *)(v4 + 136) + 24 * v33 - 16) = v47; /*0x1030b4208*/
  }
  v48[2] = v47; /*0x1030b4215*/
  if ( v66 != 0 ) /*0x1030b421a*/
  {
    v49 = *(unsigned __int8 *)(v58 + 31); /*0x1030b421c*/
    if ( v49 <= 7 ) /*0x1030b4224*/
    {
      *(_BYTE *)(v58 + 31) = v49 + 1; /*0x1030b4229*/
      *(_DWORD *)(v58 + 4 * v49 + 176) = v66; /*0x1030b422c*/
    }
  }
  if ( v69 != 0 ) /*0x1030b4237*/
  {
    v50 = *(unsigned __int8 *)(v58 + 31); /*0x1030b4239*/
    if ( v50 <= 7 ) /*0x1030b4241*/
    {
      *(_BYTE *)(v58 + 31) = v50 + 1; /*0x1030b4246*/
      *(_DWORD *)(v58 + 4 * v50 + 176) = v69; /*0x1030b424c*/
    }
  }
  if ( v57 != 0 ) /*0x1030b4255*/
  {
    if ( v57 == 1 ) /*0x1030b425a*/
    {
      if ( v61 != 0 ) /*0x1030b4260*/
      {
        v51 = *(unsigned __int8 *)(v58 + 31); /*0x1030b4262*/
        if ( v51 <= 7 ) /*0x1030b426a*/
        {
          *(_BYTE *)(v58 + 31) = v51 + 1; /*0x1030b426f*/
          *(_DWORD *)(v58 + 4 * v51 + 176) = v61; /*0x1030b4275*/
        }
      }
      if ( TempRange != 0 ) /*0x1030b4280*/
      {
        v52 = *(unsigned __int8 *)(v58 + 31); /*0x1030b4282*/
        if ( v52 <= 7 ) /*0x1030b428a*/
        {
          *(_BYTE *)(v58 + 31) = v52 + 1; /*0x1030b428f*/
          *(_DWORD *)(v58 + 4 * v52 + 176) = TempRange; /*0x1030b4295*/
        }
      }
    }
    else if ( *(_DWORD *)(v58 + 48) < (signed int)v57 ) /*0x1030b42a1*/
    {
      *(_DWORD *)(v58 + 48) = v57; /*0x1030b42a3*/
      *(_DWORD *)(v58 + 52) = v61; /*0x1030b42a9*/
    }
  }
  windowAggFinal(a1: v54, a2: 1); /*0x1030b42b4*/
  return sqlite3VdbeAddOp3(a1: v4, a2: 10, a3: *((unsigned int *)v54 + 7), a4: *((unsigned int *)v54 + 6), a5: 0); /*0x1030b42ce*/
}

// Address: 0x1030b42e1 | Name: _windowIfNewPeer
__int64 __fastcall windowIfNewPeer(__int64 a1, unsigned int *a2, unsigned int a3, unsigned int a4, unsigned int a5)
{
  __int64 Vdbe; // rax
  _DWORD *v10; // r12
  unsigned int v11; // r13d
  __int64 v12; // r15
  __int64 v14; // rax
  __int64 v15; // rcx
  unsigned int v17; // [rsp+4h] [rbp-2Ch]

  Vdbe = sqlite3GetVdbe(a1); /*0x1030b42fe*/
  v10 = (_DWORD *)Vdbe; /*0x1030b4303*/
  if ( a2 == nullptr ) /*0x1030b4309*/
    return sqlite3VdbeAddOp3(a1: Vdbe, a2: 9, a3: 0, a4: a5, a5: 0); /*0x1030b4365*/
  v17 = a5; /*0x1030b430b*/
  v11 = *a2; /*0x1030b430f*/
  v12 = sqlite3KeyInfoFromExprList(a1, a2, a3: 0, a4: 0); /*0x1030b4321*/
  sqlite3VdbeAddOp3(a1: v10, a2: 91, a3: a4, a4: a3, a5: v11); /*0x1030b4337*/
  if ( *(_BYTE *)(*(_QWORD *)v10 + 103LL) != 0 ) /*0x1030b4344*/
  {
    freeP4(a1: *(_QWORD *)v10, a2: 4294967288LL, a3: v12); /*0x1030b434e*/
  }
  else
  {
    v14 = *((_QWORD *)v10 + 17); /*0x1030b4367*/
    v15 = 3LL * (int)v10[36]; /*0x1030b4377*/
    *(_BYTE *)(v14 + 8 * v15 - 23) = -8; /*0x1030b437b*/
    *(_QWORD *)(v14 + 8 * v15 - 8) = v12; /*0x1030b4380*/
  }
  sqlite3VdbeAddOp3(a1: v10, a2: 14, a3: (unsigned int)(v10[36] + 1), a4: v17, a5: (unsigned int)(v10[36] + 1)); /*0x1030b439d*/
  return sqlite3VdbeAddOp3(a1: v10, a2: 81, a3, a4, a5: v11 - 1); /*0x1030b43b9*/
}

// Address: 0x1030b43c8 | Name: _windowCodeOp
__int64 __fastcall windowCodeOp(__int64 a1, int a2, unsigned int a3, int a4)
{
  __int64 v7; // rdx
  __int64 v8; // rsi
  __int64 v9; // rbx
  unsigned int v10; // eax
  unsigned int v11; // r12d
  __int64 v12; // r8
  __int64 v13; // rdx
  __int64 v14; // rsi
  char v15; // al
  unsigned int v16; // r13d
  unsigned __int8 v17; // al
  unsigned int v18; // r12d
  int v19; // r12d
  __int64 v20; // rdx
  unsigned __int64 v21; // rax
  unsigned __int64 v22; // rax
  unsigned int v23; // r12d
  unsigned int v24; // r13d
  __int64 v25; // rdx
  __int64 v26; // r8
  __int64 v27; // rdi
  __int64 v28; // rdx
  __int64 v29; // rcx
  __int64 v30; // rcx
  __int64 v31; // rdx
  unsigned int *v32; // rax
  int v33; // ebx
  unsigned int v34; // r13d
  unsigned int TempRange; // r14d
  unsigned __int64 v36; // rax
  unsigned int *v37; // r15
  unsigned int v39; // [rsp+Ch] [rbp-54h]
  unsigned int v40; // [rsp+10h] [rbp-50h]
  unsigned int v41; // [rsp+14h] [rbp-4Ch]
  unsigned int v42; // [rsp+18h] [rbp-48h]
  unsigned int v44; // [rsp+1Ch] [rbp-44h]
  __int64 v45; // [rsp+20h] [rbp-40h]
  char v46; // [rsp+28h] [rbp-38h]
  __int64 v47; // [rsp+28h] [rbp-38h]
  __int64 v48; // [rsp+30h] [rbp-30h]

  v7 = *(_QWORD *)a1; /*0x1030b43e5*/
  v8 = *(_QWORD *)(a1 + 8); /*0x1030b43e8*/
  v9 = *(_QWORD *)(a1 + 16); /*0x1030b43ec*/
  v46 = *(_BYTE *)(v8 + 32); /*0x1030b43f3*/
  v10 = *(_DWORD *)(*(_QWORD *)a1 + 76LL) - 1; /*0x1030b43f9*/
  *(_DWORD *)(*(_QWORD *)a1 + 76LL) = v10; /*0x1030b43fb*/
  if ( a2 == 2 ) /*0x1030b4402*/
  {
    v11 = 0; /*0x1030b4404*/
    if ( *(_BYTE *)(v8 + 33) == 91 ) /*0x1030b440b*/
      return v11; /*0x1030b440b*/
  }
  v41 = 0; /*0x1030b4411*/
  v48 = v7; /*0x1030b441b*/
  v45 = v8; /*0x1030b441f*/
  v42 = v10; /*0x1030b4423*/
  if ( (int)a3 > 0 ) /*0x1030b4426*/
  {
    if ( v46 == 90 ) /*0x1030b442c*/
    {
      v41 = *(_DWORD *)(v9 + 144); /*0x1030b4434*/
      if ( a2 == 2 ) /*0x1030b443b*/
      {
        if ( *(_BYTE *)(v8 + 33) == 87 ) /*0x1030b4441*/
        {
          v12 = *(unsigned int *)(a1 + 44); /*0x1030b4443*/
          v13 = *(unsigned int *)(a1 + 52); /*0x1030b4447*/
          v14 = 56; /*0x1030b444e*/
        }
        else
        {
          v13 = *(unsigned int *)(a1 + 44); /*0x1030b44b5*/
          v12 = *(unsigned int *)(a1 + 52); /*0x1030b44b9*/
          v14 = 58; /*0x1030b44c0*/
        }
        windowCodeRangeTest(a1, a2: v14, a3: v13, a4: a3, a5: v12, a6: v10); /*0x1030b44cb*/
        v7 = v48; /*0x1030b44d0*/
        v8 = v45; /*0x1030b44d4*/
        goto LABEL_16; /*0x1030b44d4*/
      }
      windowCodeRangeTest(a1, a2: 55, a3: *(unsigned int *)(a1 + 60), a4: a3, a5: *(unsigned int *)(a1 + 52), a6: v10); /*0x1030b4485*/
    }
    else
    {
      sqlite3VdbeAddOp3(a1: v9, a2: 60, a3, a4: v10, a5: 1); /*0x1030b4468*/
    }
    v8 = v45; /*0x1030b448a*/
    v7 = v48; /*0x1030b448e*/
  }
  if ( a2 == 1 && *(_DWORD *)(v8 + 132) == 0 ) /*0x1030b449f*/
  {
    windowAggFinal((_QWORD *)a1, a2: 0); /*0x1030b44a6*/
    v8 = v45; /*0x1030b44ab*/
    v7 = v48; /*0x1030b44af*/
  }
LABEL_16:
  v39 = *(_DWORD *)(v9 + 144); /*0x1030b44d8*/
  if ( a3 == 0 || *(_BYTE *)(v8 + 33) != *(_BYTE *)(v8 + 34) || *(_BYTE *)(v8 + 32) != 90 ) /*0x1030b44fa*/
    goto LABEL_36; /*0x1030b44fa*/
  v15 = *(_BYTE *)(v7 + 31); /*0x1030b4500*/
  if ( v15 != 0 ) /*0x1030b4505*/
  {
    *(_BYTE *)(v7 + 31) = v15 - 1; /*0x1030b450a*/
    v16 = *(_DWORD *)(v7 + 4LL * (unsigned __int8)(v15 - 1) + 176); /*0x1030b4510*/
    if ( v15 != 1 ) /*0x1030b451a*/
    {
      v17 = v15 - 2; /*0x1030b451c*/
      *(_BYTE *)(v7 + 31) = v17; /*0x1030b451e*/
      v18 = *(_DWORD *)(v7 + 4LL * v17 + 176); /*0x1030b4524*/
      goto LABEL_25; /*0x1030b452c*/
    }
    v19 = *(_DWORD *)(v7 + 64); /*0x1030b453a*/
  }
  else
  {
    v19 = *(_DWORD *)(v7 + 64) + 1; /*0x1030b4532*/
    v16 = v19; /*0x1030b4535*/
  }
  v18 = v19 + 1; /*0x1030b453e*/
  *(_DWORD *)(v7 + 64) = v18; /*0x1030b4541*/
LABEL_25:
  if ( a2 == 2 ) /*0x1030b4549*/
  {
    sqlite3VdbeAddOp3(a1: v9, a2: 136, a3: *(unsigned int *)(a1 + 44), a4: v16, a5: 0); /*0x1030b455d*/
    sqlite3VdbeAddOp3(a1: v9, a2: 136, a3: *(unsigned int *)(a1 + 60), a4: v18, a5: 0); /*0x1030b4574*/
    v20 = v18; /*0x1030b4579*/
  }
  else
  {
    if ( *(_DWORD *)(a1 + 40) == 0 ) /*0x1030b4583*/
      goto LABEL_30; /*0x1030b4583*/
    sqlite3VdbeAddOp3(a1: v9, a2: 136, a3: *(unsigned int *)(a1 + 60), a4: v16, a5: 0); /*0x1030b4597*/
    v20 = *(unsigned int *)(a1 + 40); /*0x1030b459c*/
  }
  sqlite3VdbeAddOp3(a1: v9, a2: 58, a3: v20, a4: v42, a5: v16); /*0x1030b45ae*/
  v7 = v48; /*0x1030b45b3*/
  v8 = v45; /*0x1030b45b7*/
LABEL_30:
  if ( v16 != 0 ) /*0x1030b45be*/
  {
    v21 = *(unsigned __int8 *)(v7 + 31); /*0x1030b45c0*/
    if ( v21 <= 7 ) /*0x1030b45c8*/
    {
      *(_BYTE *)(v7 + 31) = v21 + 1; /*0x1030b45cd*/
      *(_DWORD *)(v7 + 4 * v21 + 176) = v16; /*0x1030b45d0*/
    }
  }
  if ( v18 != 0 ) /*0x1030b45db*/
  {
    v22 = *(unsigned __int8 *)(v7 + 31); /*0x1030b45dd*/
    if ( v22 <= 7 ) /*0x1030b45e5*/
    {
      *(_BYTE *)(v7 + 31) = v22 + 1; /*0x1030b45ea*/
      *(_DWORD *)(v7 + 4 * v22 + 176) = v18; /*0x1030b45ed*/
    }
  }
LABEL_36:
  if ( a2 == 2 ) /*0x1030b45f9*/
  {
    v23 = *(_DWORD *)(a1 + 44); /*0x1030b4613*/
    v24 = *(_DWORD *)(a1 + 48); /*0x1030b4617*/
    v25 = *(unsigned int *)(v8 + 132); /*0x1030b461b*/
    if ( (_DWORD)v25 != 0 ) /*0x1030b4623*/
    {
LABEL_43:
      sqlite3VdbeAddOp3(a1: v9, a2: 87, a3: v25, a4: 1, a5: 0); /*0x1030b464d*/
      goto LABEL_46; /*0x1030b4662*/
    }
    v26 = *(unsigned int *)(a1 + 32); /*0x1030b4625*/
    v27 = a1; /*0x1030b4629*/
    v28 = v23; /*0x1030b462c*/
    v29 = 1; /*0x1030b462f*/
  }
  else
  {
    if ( a2 == 1 ) /*0x1030b45ff*/
    {
      v23 = *(_DWORD *)(a1 + 52); /*0x1030b4601*/
      v24 = *(_DWORD *)(a1 + 56); /*0x1030b4605*/
      windowReturnOneRow((__int64 *)a1); /*0x1030b460c*/
      goto LABEL_46; /*0x1030b4611*/
    }
    v23 = *(_DWORD *)(a1 + 60); /*0x1030b4636*/
    v24 = *(_DWORD *)(a1 + 64); /*0x1030b463a*/
    if ( *(_DWORD *)(v8 + 132) != 0 ) /*0x1030b4645*/
    {
      v25 = *(unsigned int *)(v8 + 136); /*0x1030b4647*/
      goto LABEL_43; /*0x1030b4647*/
    }
    v26 = *(unsigned int *)(a1 + 32); /*0x1030b4664*/
    v27 = a1; /*0x1030b4668*/
    v28 = v23; /*0x1030b466b*/
    v29 = 0; /*0x1030b466e*/
  }
  windowAggStep(a1: v27, a2: v8, a3: v28, a4: v29, a5: v26); /*0x1030b4670*/
LABEL_46:
  if ( *(_DWORD *)(a1 + 36) == a2 ) /*0x1030b4679*/
  {
    sqlite3VdbeAddOp3(a1: v9, a2: 131, a3: v23, a4: 0, a5: 0); /*0x1030b468b*/
    v30 = *(int *)(v9 + 144); /*0x1030b4690*/
    if ( v30 > 0 ) /*0x1030b469a*/
      *(_WORD *)(*(_QWORD *)(v9 + 136) + 24 * v30 - 22) = 2; /*0x1030b46a7*/
  }
  else
  {
    LODWORD(v30) = *(_DWORD *)(v9 + 144); /*0x1030b46b0*/
  }
  v40 = v23; /*0x1030b46ba*/
  if ( a4 != 0 ) /*0x1030b46be*/
  {
    sqlite3VdbeAddOp3(a1: v9, a2: 40, a3: v23, a4: (unsigned int)(v30 + 2), a5: 0); /*0x1030b46d1*/
    v11 = sqlite3VdbeAddOp3(a1: v9, a2: 9, a3: 0, a4: 0, a5: 0); /*0x1030b46ea*/
    if ( v46 == 77 ) /*0x1030b46f1*/
      goto LABEL_67; /*0x1030b46f1*/
  }
  else
  {
    v31 = v23; /*0x1030b470a*/
    v11 = 0; /*0x1030b470d*/
    sqlite3VdbeAddOp3(a1: v9, a2: 40, a3: v31, a4: (unsigned int)v30 - (v46 == 77) + 2, a5: 0); /*0x1030b471b*/
    if ( v46 == 77 ) /*0x1030b4724*/
      goto LABEL_67; /*0x1030b4724*/
    v11 = 0; /*0x1030b472a*/
    sqlite3VdbeAddOp3(a1: v9, a2: 9, a3: 0, a4: v42, a5: 0); /*0x1030b473d*/
  }
  v44 = v24; /*0x1030b4742*/
  v47 = v9; /*0x1030b4746*/
  v32 = *(unsigned int **)(v45 + 24); /*0x1030b474e*/
  v33 = 0; /*0x1030b4752*/
  if ( v32 != nullptr ) /*0x1030b4757*/
  {
    v34 = *v32; /*0x1030b4759*/
    TempRange = 0; /*0x1030b475c*/
    if ( *v32 != 0 ) /*0x1030b4765*/
    {
      TempRange = sqlite3GetTempRange(a1: v48, a2: v34); /*0x1030b4773*/
      v33 = v34; /*0x1030b4776*/
    }
  }
  else
  {
    TempRange = 0; /*0x1030b477b*/
  }
  windowReadPeerValues(a1, a2: v40, a3: TempRange); /*0x1030b4787*/
  windowIfNewPeer(a1: v48, a2: *(unsigned int **)(v45 + 24), a3: TempRange, a4: v44, a5: v39); /*0x1030b47a5*/
  if ( v33 != 1 ) /*0x1030b47ad*/
  {
    if ( *(_DWORD *)(v48 + 48) < v33 ) /*0x1030b47df*/
    {
      *(_DWORD *)(v48 + 48) = v33; /*0x1030b47e1*/
      v37 = (unsigned int *)(v48 + 52); /*0x1030b47e5*/
      v9 = v47; /*0x1030b47e9*/
      goto LABEL_65; /*0x1030b47e9*/
    }
LABEL_66:
    v9 = v47; /*0x1030b47f2*/
    goto LABEL_67; /*0x1030b47f2*/
  }
  if ( TempRange == 0 ) /*0x1030b47b2*/
    goto LABEL_66; /*0x1030b47b2*/
  v36 = *(unsigned __int8 *)(v48 + 31); /*0x1030b47b8*/
  v9 = v47; /*0x1030b47c1*/
  if ( v36 <= 7 ) /*0x1030b47c5*/
  {
    *(_BYTE *)(v48 + 31) = v36 + 1; /*0x1030b47ca*/
    v37 = (unsigned int *)(v48 + 4 * v36 + 176); /*0x1030b47d2*/
LABEL_65:
    *v37 = TempRange; /*0x1030b47ed*/
  }
LABEL_67:
  if ( v41 != 0 ) /*0x1030b47fb*/
    sqlite3VdbeAddOp3(a1: v9, a2: 9, a3: 0, a4: v41, a5: 0); /*0x1030b480a*/
  sqlite3VdbeResolveLabel(a1: v9, a2: v42); /*0x1030b4815*/
  return v11; /*0x1030b481d*/
}

// Address: 0x1030b482c | Name: _windowCodeRangeTest
unsigned __int64 __fastcall windowCodeRangeTest(
        _QWORD *a1,
        unsigned int a2,
        unsigned int a3,
        unsigned int a4,
        unsigned int a5,
        unsigned int a6)
{
  __int64 v8; // rbx
  __int64 Vdbe; // r15
  char v10; // al
  unsigned __int8 v11; // al
  unsigned int v12; // r13d
  __int64 v13; // rax
  int v14; // ebx
  unsigned int v15; // ebx
  __int64 v16; // rsi
  unsigned int v17; // r14d
  __int64 v18; // rsi
  char v19; // al
  unsigned int v20; // r12d
  int v21; // r13d
  int v22; // r14d
  __int64 v23; // rdi
  __int64 v24; // rsi
  __int64 v25; // rdx
  _DWORD *v26; // rdx
  __int64 v27; // rcx
  unsigned int v28; // r13d
  unsigned int v29; // eax
  _DWORD *v30; // rcx
  __int64 v31; // rdx
  __int64 v32; // rcx
  __int64 v33; // r8
  __int64 v34; // r9
  __int64 v35; // rax
  __int64 v36; // rcx
  __int64 v37; // rdx
  __int64 v38; // rax
  unsigned __int64 result; // rax
  unsigned __int8 *v40; // [rsp+0h] [rbp-50h]
  __int64 v41; // [rsp+8h] [rbp-48h]
  unsigned int v44; // [rsp+18h] [rbp-38h]
  unsigned int v45; // [rsp+1Ch] [rbp-34h]
  int v46; // [rsp+1Ch] [rbp-34h]
  unsigned int v49; // [rsp+24h] [rbp-2Ch]

  v8 = *a1; /*0x1030b4851*/
  Vdbe = sqlite3GetVdbe(a1: *a1); /*0x1030b485c*/
  v41 = *(_QWORD *)(a1[1] + 24LL); /*0x1030b4868*/
  v10 = *(_BYTE *)(v8 + 31); /*0x1030b486c*/
  if ( v10 != 0 ) /*0x1030b4871*/
  {
    *(_BYTE *)(v8 + 31) = v10 - 1; /*0x1030b4876*/
    v45 = *(_DWORD *)(v8 + 4LL * (unsigned __int8)(v10 - 1) + 176); /*0x1030b4883*/
    if ( v10 != 1 ) /*0x1030b4888*/
    {
      v11 = v10 - 2; /*0x1030b488a*/
      *(_BYTE *)(v8 + 31) = v11; /*0x1030b488c*/
      v12 = *(_DWORD *)(v8 + 4LL * v11 + 176); /*0x1030b4892*/
      v13 = v8; /*0x1030b489a*/
      v14 = *(_DWORD *)(v8 + 64); /*0x1030b489d*/
      goto LABEL_6; /*0x1030b48a0*/
    }
  }
  else
  {
    v45 = *(_DWORD *)(v8 + 64) + 1; /*0x1030b48a7*/
    *(_DWORD *)(v8 + 64) = v45; /*0x1030b48aa*/
  }
  v13 = v8; /*0x1030b48ad*/
  v14 = *(_DWORD *)(v8 + 64) + 1; /*0x1030b48b3*/
  v12 = v14; /*0x1030b48b5*/
LABEL_6:
  v15 = v14 + 1; /*0x1030b48b8*/
  *(_DWORD *)(v13 + 64) = v15; /*0x1030b48ba*/
  v40 = (unsigned __int8 *)v13; /*0x1030b48c2*/
  v44 = *(_DWORD *)(v13 + 76) - 1; /*0x1030b48c6*/
  *(_DWORD *)(v13 + 76) = v44; /*0x1030b48c9*/
  v16 = a3; /*0x1030b48cf*/
  v17 = v45; /*0x1030b48d2*/
  windowReadPeerValues(a1, a2: v16, a3: v45); /*0x1030b48d9*/
  v18 = a5; /*0x1030b48e1*/
  v49 = v12; /*0x1030b48e4*/
  windowReadPeerValues(a1, a2: v18, a3: v12); /*0x1030b48eb*/
  v19 = *(_BYTE *)(v41 + 24); /*0x1030b48f4*/
  v20 = 56; /*0x1030b4909*/
  if ( a2 != 58 ) /*0x1030b490f*/
    v20 = (a2 != 55) + 57; /*0x1030b490f*/
  v21 = v19 & 1; /*0x1030b4916*/
  if ( (v19 & 1) == 0 ) /*0x1030b491a*/
    v20 = a2; /*0x1030b491a*/
  if ( (v19 & 2) != 0 ) /*0x1030b4920*/
  {
    v22 = sqlite3VdbeAddOp3(a1: Vdbe, a2: 52, a3: v45, a4: 0, a5: 0); /*0x1030b493b*/
    switch ( v20 ) /*0x1030b4942*/
    {
      case '7': /*0x1030b4942*/
        v23 = Vdbe; /*0x1030b4966*/
        v24 = 52; /*0x1030b4969*/
        break;
      case '8': /*0x1030b4942*/
        v23 = Vdbe; /*0x1030b495c*/
        v24 = 51; /*0x1030b495f*/
        break;
      case ':': /*0x1030b4942*/
        v23 = Vdbe; /*0x1030b4950*/
        v24 = 9; /*0x1030b4953*/
        v25 = 0; /*0x1030b4958*/
LABEL_18:
        sqlite3VdbeAddOp3(a1: v23, a2: v24, a3: v25, a4: a6, a5: 0); /*0x1030b4971*/
        goto LABEL_19; /*0x1030b4977*/
      default:
LABEL_19:
        sqlite3VdbeAddOp3(a1: Vdbe, a2: 9, a3: 0, a4: v44, a5: 0); /*0x1030b497c*/
        if ( *(_BYTE *)(*(_QWORD *)Vdbe + 103LL) != 0 ) /*0x1030b499f*/
          v26 = &sqlite3VdbeGetOp_dummy; /*0x1030b49a1*/
        else
          v26 = (_DWORD *)(*(_QWORD *)(Vdbe + 136) + 24LL * v22); /*0x1030b49b5*/
        v27 = a6; /*0x1030b49c0*/
        if ( v20 == 58 ) /*0x1030b49c6*/
          v27 = v44; /*0x1030b49c6*/
        v26[2] = *(_DWORD *)(Vdbe + 144); /*0x1030b49c9*/
        if ( v20 == 55 ) /*0x1030b49d0*/
          v27 = v44; /*0x1030b49d0*/
        sqlite3VdbeAddOp3(a1: Vdbe, a2: 51, a3: v49, a4: v27, a5: 0); /*0x1030b49e1*/
        v17 = v45; /*0x1030b49e6*/
        goto LABEL_27; /*0x1030b49e6*/
    }
    v25 = v49; /*0x1030b496e*/
    goto LABEL_18; /*0x1030b496e*/
  }
LABEL_27:
  v28 = v21 + 107; /*0x1030b49ea*/
  v29 = sqlite3VdbeAddOp3(a1: Vdbe, a2: 118, a3: 0, a4: v15, a5: 0); /*0x1030b49fd*/
  sqlite3VdbeChangeP4(a1: Vdbe, a2: v29, a3: ""); /*0x1030b4a13*/
  v46 = sqlite3VdbeAddOp3(a1: Vdbe, a2: 58, a3: v15, a4: 0, a5: v17); /*0x1030b4a2c*/
  if ( a2 == 58 ) /*0x1030b4a33*/
    sqlite3VdbeAddOp3(a1: Vdbe, a2: v20, a3: v49, a4: a6, a5: v17); /*0x1030b4a44*/
  sqlite3VdbeAddOp3(a1: Vdbe, a2: v28, a3: a4, a4: v17, a5: v17); /*0x1030b4a58*/
  if ( *(_BYTE *)(*(_QWORD *)Vdbe + 103LL) != 0 ) /*0x1030b4a6f*/
    v30 = &sqlite3VdbeGetOp_dummy; /*0x1030b4a71*/
  else
    v30 = (_DWORD *)(*(_QWORD *)(Vdbe + 136) + 24LL * v46); /*0x1030b4a86*/
  v30[2] = *(_DWORD *)(Vdbe + 144); /*0x1030b4a8d*/
  sqlite3VdbeAddOp3(a1: Vdbe, a2: v20, a3: v49, a4: a6, a5: v17); /*0x1030b4aa3*/
  v35 = sqlite3ExprCollSeq(a1: v40, a2: *(_QWORD *)(v41 + 8), a3: v31, a4: v32, a5: v33, a6: v34); /*0x1030b4ab3*/
  if ( v35 == 0 ) /*0x1030b4abb*/
    v35 = *(_QWORD *)(*(_QWORD *)v40 + 16LL); /*0x1030b4ac0*/
  if ( *(_BYTE *)(*(_QWORD *)Vdbe + 103LL) == 0 ) /*0x1030b4acb*/
  {
    v36 = *(_QWORD *)(Vdbe + 136); /*0x1030b4acd*/
    v37 = 3LL * *(int *)(Vdbe + 144); /*0x1030b4adb*/
    *(_BYTE *)(v36 + 8 * v37 - 23) = -2; /*0x1030b4adf*/
    *(_QWORD *)(v36 + 8 * v37 - 8) = v35; /*0x1030b4ae4*/
  }
  v38 = *(int *)(Vdbe + 144); /*0x1030b4ae9*/
  if ( v38 > 0 ) /*0x1030b4af3*/
    *(_WORD *)(*(_QWORD *)(Vdbe + 136) + 24 * v38 - 22) = 128; /*0x1030b4b00*/
  result = sqlite3VdbeResolveLabel(a1: Vdbe, a2: v44); /*0x1030b4b0d*/
  if ( v17 != 0 ) /*0x1030b4b15*/
  {
    result = v40[31]; /*0x1030b4b17*/
    if ( result <= 7 ) /*0x1030b4b1f*/
    {
      v40[31] = result + 1; /*0x1030b4b24*/
      *(_DWORD *)&v40[4 * result + 176] = v17; /*0x1030b4b27*/
    }
  }
  if ( v49 != 0 ) /*0x1030b4b32*/
  {
    result = v40[31]; /*0x1030b4b34*/
    if ( result <= 7 ) /*0x1030b4b3c*/
    {
      v40[31] = result + 1; /*0x1030b4b41*/
      *(_DWORD *)&v40[4 * result + 176] = v49; /*0x1030b4b44*/
    }
  }
  return result; /*0x1030b4b4c*/
}

// Address: 0x1030b4b5b | Name: _windowReadPeerValues
int *__fastcall windowReadPeerValues(_QWORD *a1, unsigned int a2, unsigned int a3)
{
  int *result; // rax
  __int64 v4; // rbx
  int *v5; // r12
  unsigned __int64 v6; // r14
  __int64 Vdbe; // r15
  int v8; // r13d
  __int64 v9; // rdx
  int v10; // r13d
  int v11; // ebx

  v4 = a1[1]; /*0x1030b4b69*/
  v5 = *(int **)(v4 + 24); /*0x1030b4b6d*/
  if ( v5 != nullptr ) /*0x1030b4b74*/
  {
    v6 = a3; /*0x1030b4b76*/
    Vdbe = sqlite3GetVdbe(a1: *a1); /*0x1030b4b84*/
    result = *(int **)(v4 + 16); /*0x1030b4b87*/
    if ( result != nullptr ) /*0x1030b4b8e*/
      v8 = *result; /*0x1030b4b90*/
    else
      v8 = 0; /*0x1030b4b95*/
    v9 = a2; /*0x1030b4b9d*/
    if ( *v5 > 0 ) /*0x1030b4ba0*/
    {
      LODWORD(result) = v6; /*0x1030b4ba2*/
      v10 = *(_DWORD *)(v4 + 120) + v8; /*0x1030b4ba5*/
      v11 = 0; /*0x1030b4ba9*/
      do /*0x1030b4bcc*/
      {
        sqlite3VdbeAddOp3( /*0x1030b4bbb*/
          a1: Vdbe,
          a2: 95,
          a3: v9,
          a4: (unsigned int)(v11 + v10),
          a5: (unsigned int)((_DWORD)result + v11));
        v9 = a2; /*0x1030b4bc0*/
        result = (int *)v6; /*0x1030b4bc3*/
        ++v11; /*0x1030b4bc6*/
      }
      while ( v11 < *v5 ); /*0x1030b4bcc*/
    }
  }
  return result; /*0x1030b4bd2*/
}

// Address: 0x1030b4bdd | Name: _windowAggStep
__int64 __fastcall windowAggStep(__int64 *a1, __int64 a2, unsigned int a3, unsigned int a4, unsigned int a5)
{
  __int64 result; // rax
  __int64 v8; // r8
  __int64 v9; // r9
  __int64 *v10; // r14
  __int64 v11; // rcx
  __int64 v12; // r13
  int v13; // r12d
  char v14; // al
  unsigned __int8 v15; // al
  unsigned int v16; // ebx
  int *v17; // rax
  int v18; // ebx
  __int64 v19; // rcx
  __int64 v20; // r8
  __int64 *v21; // rdi
  __int64 v22; // rdx
  int v23; // esi
  unsigned __int64 v24; // rax
  __int64 v25; // rdx
  int v26; // r12d
  __int64 v27; // rax
  __int64 v28; // rax
  _DWORD *v29; // rsi
  int v30; // r13d
  int v31; // r12d
  _DWORD *v32; // rdx
  __int64 v33; // rbx
  unsigned int v34; // eax
  __int64 v35; // rax
  _DWORD *v36; // rdx
  __int64 v37; // [rsp+0h] [rbp-70h]
  unsigned int v38; // [rsp+18h] [rbp-58h]
  __int64 v39; // [rsp+20h] [rbp-50h]
  int v41; // [rsp+2Ch] [rbp-44h]
  unsigned int v42; // [rsp+30h] [rbp-40h]
  unsigned int TempRange; // [rsp+3Ch] [rbp-34h]
  __int64 v45; // [rsp+40h] [rbp-30h]

  v45 = *a1; /*0x1030b4bfd*/
  result = sqlite3GetVdbe(a1: *a1); /*0x1030b4c01*/
  v39 = a2; /*0x1030b4c06*/
  if ( a2 != 0 ) /*0x1030b4c0d*/
  {
    v10 = (__int64 *)result; /*0x1030b4c13*/
    v38 = a5 + 1; /*0x1030b4c19*/
    v11 = (unsigned int)(a4 == 0) + 162; /*0x1030b4c31*/
    v42 = a5; /*0x1030b4c46*/
    while ( 1 ) /*0x1030b4c4a*/
    {
      v12 = *(_QWORD *)(a2 + 80); /*0x1030b4c4a*/
      v13 = 0; /*0x1030b4c56*/
      if ( *(_BYTE *)(a2 + 140) == 0 ) /*0x1030b4c5c*/
      {
        v17 = *(int **)(*(_QWORD *)(a2 + 112) + 32LL); /*0x1030b4c8d*/
        if ( v17 != nullptr ) /*0x1030b4c94*/
        {
          v13 = *v17; /*0x1030b4c96*/
          if ( *v17 > 0 ) /*0x1030b4c9c*/
          {
            v18 = 0; /*0x1030b4c9e*/
            do /*0x1030b4cd5*/
            {
              if ( v18 == 1 && *(char **)(v12 + 56) == "nth_value" ) /*0x1030b4cb0*/
              {
                v22 = *(unsigned int *)(v39 + 88); /*0x1030b4ce0*/
                v19 = (unsigned int)(*(_DWORD *)(a2 + 124) + 1); /*0x1030b4ce7*/
                v21 = v10; /*0x1030b4ce9*/
                v20 = v38; /*0x1030b4cf1*/
              }
              else
              {
                v19 = (unsigned int)(v18 + *(_DWORD *)(a2 + 124)); /*0x1030b4cb6*/
                v20 = v42 + v18; /*0x1030b4cbc*/
                v21 = v10; /*0x1030b4cc0*/
                v22 = a3; /*0x1030b4cc8*/
              }
              sqlite3VdbeAddOp3(a1: v21, a2: 95, a3: v22, a4: v19, a5: v20); /*0x1030b4ccb*/
              ++v18; /*0x1030b4cd0*/
            }
            while ( v13 != v18 ); /*0x1030b4cd5*/
            a5 = v42; /*0x1030b4ea9*/
          }
        }
      }
      if ( *(_QWORD *)(a2 + 72) != 0 ) /*0x1030b4c63*/
      {
        v14 = *(_BYTE *)(v45 + 31); /*0x1030b4c6d*/
        if ( v14 != 0 ) /*0x1030b4c72*/
        {
          v15 = v14 - 1; /*0x1030b4c78*/
          *(_BYTE *)(v45 + 31) = v15; /*0x1030b4c7a*/
          v16 = *(_DWORD *)(v45 + 4LL * v15 + 176); /*0x1030b4c80*/
        }
        else
        {
          v16 = *(_DWORD *)(v45 + 64) + 1; /*0x1030b4cfe*/
          *(_DWORD *)(v45 + 64) = v16; /*0x1030b4d00*/
        }
        sqlite3VdbeAddOp3(a1: v10, a2: 95, a3, a4: (unsigned int)(v13 + *(_DWORD *)(a2 + 124)), a5: v16); /*0x1030b4d18*/
        v23 = sqlite3VdbeAddOp3(a1: v10, a2: 17, a3: v16, a4: 0, a5: 1); /*0x1030b4d34*/
        if ( v16 != 0 ) /*0x1030b4d38*/
        {
          v24 = *(unsigned __int8 *)(v45 + 31); /*0x1030b4d3e*/
          if ( v24 <= 7 ) /*0x1030b4d46*/
          {
            v11 = (unsigned int)(v24 + 1); /*0x1030b4d48*/
            *(_BYTE *)(v45 + 31) = v24 + 1; /*0x1030b4d4b*/
            *(_DWORD *)(v45 + 4 * v24 + 176) = v16; /*0x1030b4d4e*/
          }
        }
        a5 = v42; /*0x1030b4d55*/
      }
      else
      {
        v23 = 0; /*0x1030b4cf7*/
      }
      if ( *(_DWORD *)(v39 + 132) == 0 && (*(_BYTE *)(v12 + 5) & 0x10) != 0 && *(_BYTE *)(a2 + 33) != 91 ) /*0x1030b4d72*/
      {
        v30 = v23; /*0x1030b4eb2*/
        v31 = sqlite3VdbeAddOp3(a1: v10, a2: 51, a3: a5, a4: 0, a5: 0); /*0x1030b4ec9*/
        if ( a4 != 0 ) /*0x1030b4ed0*/
        {
          sqlite3VdbeAddOp4Int(a1: v10, a2: 23, a3: *(unsigned int *)(a2 + 100), a4: 0, a5, a6: 1); /*0x1030b4eed*/
          sqlite3VdbeAddOp3(a1: v10, a2: 131, a3: *(unsigned int *)(a2 + 100), a4: 0, a5: 0); /*0x1030b4f03*/
          result = *((unsigned int *)v10 + 36); /*0x1030b4f08*/
          v11 = *v10; /*0x1030b4f0f*/
          LOBYTE(v11) = *(_BYTE *)(*v10 + 103); /*0x1030b4f12*/
          v32 = &sqlite3VdbeGetOp_dummy; /*0x1030b4f15*/
          if ( (_BYTE)v11 == 0 ) /*0x1030b4f1e*/
            v32 = (_DWORD *)(v10[17] + 24LL * (int)result - 48); /*0x1030b4f32*/
          v32[2] = result; /*0x1030b4f36*/
        }
        else
        {
          sqlite3VdbeAddOp3(a1: v10, a2: 87, a3: (unsigned int)(*(_DWORD *)(a2 + 104) + 1), a4: 1, a5: 0); /*0x1030b5087*/
          sqlite3VdbeAddOp3(a1: v10, a2: 82, a3: a5, a4: *(unsigned int *)(a2 + 104), a5: 0); /*0x1030b509d*/
          sqlite3VdbeAddOp3( /*0x1030b50b7*/
            a1: v10,
            a2: 98,
            a3: *(unsigned int *)(a2 + 104),
            a4: 2,
            a5: (unsigned int)(*(_DWORD *)(a2 + 104) + 2));
          sqlite3VdbeAddOp3( /*0x1030b50d2*/
            a1: v10,
            a2: 139,
            a3: *(unsigned int *)(a2 + 100),
            a4: (unsigned int)(*(_DWORD *)(a2 + 104) + 2),
            a5: 0);
          result = *((unsigned int *)v10 + 36); /*0x1030b50d7*/
          v11 = *v10; /*0x1030b50de*/
          LOBYTE(v11) = *(_BYTE *)(*v10 + 103); /*0x1030b50e1*/
        }
        v36 = &sqlite3VdbeGetOp_dummy; /*0x1030b50e4*/
        v23 = v30; /*0x1030b50ed*/
        if ( (_BYTE)v11 == 0 ) /*0x1030b50f0*/
        {
          v11 = v31; /*0x1030b50f2*/
          v36 = (_DWORD *)(v10[17] + 24LL * v31); /*0x1030b50fd*/
        }
        v36[2] = result; /*0x1030b5104*/
        goto LABEL_27; /*0x1030b5107*/
      }
      v25 = *(unsigned int *)(a2 + 104); /*0x1030b4d78*/
      if ( (_DWORD)v25 != 0 ) /*0x1030b4d7e*/
      {
        v26 = v23; /*0x1030b4d88*/
        result = sqlite3VdbeAddOp3(a1: v10, a2: 87, a3: (unsigned int)v25 - a4 + 1, a4: 1, a5: 0); /*0x1030b4d98*/
        v23 = v26; /*0x1030b4d9d*/
        goto LABEL_27; /*0x1030b4d9d*/
      }
      result = (__int64)noopStepFunc; /*0x1030b4de2*/
      if ( *(__int64 (__fastcall **)())(v12 + 24) == noopStepFunc ) /*0x1030b4ded*/
        goto LABEL_27; /*0x1030b4ded*/
      v41 = v23; /*0x1030b4def*/
      TempRange = a5; /*0x1030b4dfa*/
      if ( *(_BYTE *)(a2 + 140) != 0 ) /*0x1030b4dfd*/
      {
        v37 = *((int *)v10 + 36); /*0x1030b4e0a*/
        v13 = **(_DWORD **)(*(_QWORD *)(a2 + 112) + 32LL); /*0x1030b4e16*/
        TempRange = sqlite3GetTempRange(a1: v45, a2: (unsigned int)v13); /*0x1030b4e35*/
        sqlite3ExprCodeExprList(a1: v45, a2: *(_QWORD *)(*(_QWORD *)(a2 + 112) + 32LL), a3: TempRange, a4: 0, a5: 0); /*0x1030b4e3d*/
        v27 = *((int *)v10 + 36); /*0x1030b4e46*/
        if ( (int)v37 >= (int)v27 ) /*0x1030b4e4f*/
        {
          a5 = v42; /*0x1030b4f3e*/
        }
        else
        {
          v11 = *v10; /*0x1030b4e55*/
          LOBYTE(v11) = *(_BYTE *)(*v10 + 103); /*0x1030b4e58*/
          v25 = 24 * v37; /*0x1030b4e63*/
          v28 = v27 - v37; /*0x1030b4e67*/
          a5 = v42; /*0x1030b4e6a*/
          do /*0x1030b4ea2*/
          {
            v29 = &sqlite3VdbeGetOp_dummy; /*0x1030b4e6e*/
            if ( (_BYTE)v11 == 0 ) /*0x1030b4e77*/
              v29 = (_DWORD *)(v25 + v10[17]); /*0x1030b4e80*/
            if ( *(_BYTE *)v29 == 95 ) /*0x1030b4e86*/
            {
              v8 = v39; /*0x1030b4e8b*/
              if ( v29[1] == *(_DWORD *)(v39 + 88) ) /*0x1030b4e93*/
                v29[1] = a3; /*0x1030b4e98*/
            }
            v25 += 24; /*0x1030b4e9b*/
            --v28; /*0x1030b4e9f*/
          }
          while ( v28 != 0 ); /*0x1030b4ea2*/
        }
      }
      if ( (*(_BYTE *)(v12 + 4) & 0x20) != 0 ) /*0x1030b4f47*/
      {
        v33 = sqlite3ExprCollSeq( /*0x1030b4f5e*/
                a1: v45,
                a2: *(_QWORD *)(*(_QWORD *)(*(_QWORD *)(a2 + 112) + 32LL) + 8LL),
                a3: v25,
                a4: v11,
                a5: v8,
                a6: v9);
        if ( v33 == 0 ) /*0x1030b4f64*/
          v33 = *(_QWORD *)(*(_QWORD *)v45 + 16LL); /*0x1030b4f6d*/
        v34 = sqlite3VdbeAddOp3(a1: v10, a2: 86, a3: 0, a4: 0, a5: 0); /*0x1030b4f80*/
        sqlite3VdbeChangeP4(a1: v10, a2: v34, a3: v33); /*0x1030b4f92*/
        a5 = v42; /*0x1030b4f97*/
      }
      sqlite3VdbeAddOp3( /*0x1030b4fab*/
        a1: v10,
        a2: (unsigned int)(a4 == 0) + 162,
        a3: a4,
        a4: TempRange,
        a5: *(unsigned int *)(a2 + 92));
      if ( *(_BYTE *)(*v10 + 103) == 0 ) /*0x1030b4fb7*/
        break; /*0x1030b4fb7*/
      v23 = v41; /*0x1030b4fbe*/
      if ( (*(_BYTE *)(v12 + 4) & 0x10) != 0 ) /*0x1030b4fc1*/
      {
        sqlite3DbNNFreeNN(a1: *v10, a2: v12); /*0x1030b4fc6*/
LABEL_57:
        v23 = v41; /*0x1030b4fe9*/
      }
      result = *((int *)v10 + 36); /*0x1030b4fec*/
      if ( result > 0 ) /*0x1030b4ff6*/
      {
        v11 = v10[17]; /*0x1030b4ff8*/
        result *= 3; /*0x1030b4fff*/
        *(_WORD *)(v11 + 8 * result - 22) = v13; /*0x1030b5003*/
      }
      if ( *(_BYTE *)(a2 + 140) == 0 ) /*0x1030b5011*/
        goto LABEL_27; /*0x1030b5011*/
      if ( v13 == 1 ) /*0x1030b501b*/
      {
        if ( TempRange == 0 ) /*0x1030b5021*/
          goto LABEL_27; /*0x1030b5021*/
        result = *(unsigned __int8 *)(v45 + 31); /*0x1030b502b*/
        if ( (unsigned __int64)result > 7 ) /*0x1030b5033*/
          goto LABEL_27; /*0x1030b5033*/
        *(_BYTE *)(v45 + 31) = result + 1; /*0x1030b5040*/
        result = v45 + 176 + 4 * result; /*0x1030b5047*/
        goto LABEL_67; /*0x1030b504b*/
      }
      result = v45; /*0x1030b504d*/
      if ( *(_DWORD *)(v45 + 48) < v13 ) /*0x1030b5055*/
      {
        *(_DWORD *)(v45 + 48) = v13; /*0x1030b505f*/
        result = v45 + 52; /*0x1030b5063*/
LABEL_67:
        v11 = TempRange; /*0x1030b5067*/
        *(_DWORD *)result = TempRange; /*0x1030b506a*/
      }
LABEL_27:
      if ( v23 != 0 ) /*0x1030b4da2*/
      {
        result = (__int64)&sqlite3VdbeGetOp_dummy; /*0x1030b4dab*/
        if ( *(_BYTE *)(*v10 + 103) == 0 ) /*0x1030b4db2*/
          result = v10[17] + 24LL * v23; /*0x1030b4dbf*/
        v11 = *((unsigned int *)v10 + 36); /*0x1030b4dc6*/
        *(_DWORD *)(result + 8) = v11; /*0x1030b4dcd*/
      }
      a2 = *(_QWORD *)(a2 + 64); /*0x1030b4dd0*/
      if ( a2 == 0 ) /*0x1030b4dd7*/
        return result; /*0x1030b4dd7*/
    }
    v35 = v10[17]; /*0x1030b4fcd*/
    v11 = 3LL * *((int *)v10 + 36); /*0x1030b4fdb*/
    *(_BYTE *)(v35 + 8 * v11 - 23) = -7; /*0x1030b4fdf*/
    *(_QWORD *)(v35 + 8 * v11 - 8) = v12; /*0x1030b4fe4*/
    goto LABEL_57; /*0x1030b4fe4*/
  }
  return result; /*0x1030b510c*/
}

// Address: 0x1031195f8 | Name: _ws_conn_dtor
void __fastcall ws_conn_dtor(__int64 a1, __int64 a2, char *a3)
{
  Curl_bufq_free(a1: a3 + 96); /*0x103119605*/
  Curl_bufq_free(a1: a3 + 160); /*0x103119611*/
  Curl_cfree(a1: a3); /*0x103119626*/
}

// Address: 0x10311985b | Name: _ws_dec_pass
__int64 __fastcall ws_dec_pass(
        unsigned int *a1,
        __int64 a2,
        __int64 a3,
        __int64 (__fastcall *a4)(unsigned __int64 *, unsigned __int64, _QWORD, _QWORD, _QWORD, _QWORD, __int64, _BYTE **),
        __int64 a5)
{
  unsigned int v8; // r14d
  unsigned int v10; // eax
  __int64 v11; // rax
  unsigned __int64 v12; // rdi
  __int64 v13; // rax
  unsigned __int64 v14; // r15
  unsigned __int64 v15; // rsi
  unsigned int v16; // eax
  __int64 v17; // rdi
  __int64 v18; // rax
  int *v19; // r15
  __int64 v20; // rcx
  __int64 v21; // rdx
  int v22; // eax
  __int64 v23; // rcx
  char v24; // al
  unsigned int v25; // ecx
  int v26; // eax
  int v27; // ecx
  bool v28; // zf
  __int64 v29; // r12
  __int64 v30; // rax
  const char *v31; // rsi
  __int64 v32; // [rsp+8h] [rbp-58h] BYREF
  __int64 (__fastcall *v33)(unsigned __int64 *, unsigned __int64, _QWORD, _QWORD, _QWORD, _QWORD, __int64, _BYTE **); // [rsp+10h] [rbp-50h]
  __int64 v34; // [rsp+18h] [rbp-48h]
  unsigned __int64 v35; // [rsp+20h] [rbp-40h] BYREF
  unsigned __int64 *v36; // [rsp+28h] [rbp-38h] BYREF
  __int64 v37; // [rsp+30h] [rbp-30h]

  v34 = a5; /*0x10311986c*/
  v33 = a4; /*0x103119870*/
  v8 = 81; /*0x103119885*/
  if ( (unsigned __int8)Curl_bufq_is_empty(a1: a3) != 0 ) /*0x10311988d*/
    return v8; /*0x10311988d*/
  v10 = a1[11]; /*0x1031198a1*/
  if ( v10 != 0 ) /*0x1031198a6*/
  {
    if ( v10 != 1 ) /*0x1031198af*/
    {
      v8 = 2; /*0x1031198b5*/
      if ( v10 != 2 ) /*0x1031198be*/
        return v8; /*0x1031198be*/
      v11 = *((_QWORD *)a1 + 1); /*0x1031198c0*/
      v12 = *((_QWORD *)a1 + 2); /*0x1031198c4*/
      goto LABEL_7; /*0x1031198c4*/
    }
  }
  else
  {
    *((_QWORD *)a1 + 5) = &_mh_execute_header; /*0x10311998a*/
    a1[9] = 0; /*0x10311998e*/
    *(_OWORD *)a1 = 0; /*0x103119998*/
    *((_QWORD *)a1 + 2) = 0; /*0x10311999b*/
  }
  v37 = a2; /*0x1031199a3*/
  if ( (unsigned __int8)Curl_bufq_peek(a1: a3, a2: &v36, a3: &v35) == 0 ) /*0x1031199b9*/
    return v8; /*0x1031199b9*/
  v19 = (int *)(a1 + 9); /*0x1031199bf*/
  while ( 1 ) /*0x1031199ca*/
  {
    v20 = *v19; /*0x1031199ca*/
    if ( v20 != 1 ) /*0x1031199d1*/
      break; /*0x1031199d1*/
    *((_BYTE *)a1 + 25) = *(_BYTE *)v36; /*0x103119a2c*/
    Curl_bufq_skip(a1: a3, a2: 1); /*0x103119a37*/
    a1[9] = 2; /*0x103119a3c*/
    v24 = *((_BYTE *)a1 + 25); /*0x103119a43*/
    if ( v24 < 0 ) /*0x103119a48*/
    {
      v31 = "[WS] masked input frame"; /*0x103119bb2*/
      goto LABEL_68; /*0x103119bb9*/
    }
    v25 = a1[1]; /*0x103119a4e*/
    if ( (v25 & 0x10) != 0 && (unsigned __int8)v24 >= 0x7Eu ) /*0x103119a59*/
    {
      v31 = "[WS] received PING frame is too big"; /*0x103119bbe*/
      goto LABEL_68; /*0x103119bc5*/
    }
    if ( (v25 & 0x40) != 0 ) /*0x103119a69*/
    {
      if ( (unsigned __int8)v24 >= 0x7Eu ) /*0x103119abb*/
      {
        v31 = "[WS] received PONG frame is too big"; /*0x103119c44*/
        goto LABEL_68; /*0x103119c44*/
      }
    }
    else if ( (unsigned __int8)v24 >= 0x7Eu && (v25 & 8) != 0 ) /*0x103119a73*/
    {
      v31 = "[WS] received CLOSE frame is too big"; /*0x103119c4d*/
LABEL_68:
      v29 = v37; /*0x103119c54*/
      Curl_failf(a1: v37, a2: v31); /*0x103119c5d*/
      *(_OWORD *)a1 = 0; /*0x103119c65*/
      *((_QWORD *)a1 + 2) = 0; /*0x103119c68*/
      *(_OWORD *)v19 = 0; /*0x103119c70*/
      goto LABEL_85; /*0x103119c74*/
    }
    if ( v24 == 127 ) /*0x103119ac7*/
    {
      a1[10] = 10; /*0x103119ade*/
    }
    else
    {
      if ( v24 != 126 ) /*0x103119acc*/
      {
        a1[10] = 2; /*0x103119c79*/
LABEL_70:
        v12 = (unsigned __int8)v24; /*0x103119c80*/
        goto LABEL_71; /*0x103119c80*/
      }
      a1[10] = 4; /*0x103119ad2*/
    }
LABEL_54:
    if ( (unsigned __int8)Curl_bufq_peek(a1: a3, a2: &v36, a3: &v35) == 0 ) /*0x103119b7d*/
      return v8; /*0x103119b7d*/
  }
  if ( (_DWORD)v20 == 0 )
  {
    *((_BYTE *)a1 + 24) = *(_BYTE *)v36; /*0x1031199e1*/
    Curl_bufq_skip(a1: a3, a2: 1); /*0x1031199ec*/
    v21 = *((unsigned __int8 *)a1 + 24); /*0x1031199f1*/
    v22 = a1[12]; /*0x1031199f5*/
    v23 = (unsigned int)(v21 - 128); /*0x1031199f8*/
    switch ( *((_BYTE *)a1 + 24) )
    {
      case 0x80:
        if ( (v22 & 4) == 0 ) /*0x103119a0f*/
        {
LABEL_77:
          Curl_failf(a1: v37, a2: "[WS] no ongoing fragmented message to resume", v21, v23); /*0x103119cf0*/
LABEL_84:
          *(_OWORD *)a1 = 0; /*0x103119d3e*/
          *((_QWORD *)a1 + 2) = 0; /*0x103119d44*/
          *(_OWORD *)v19 = 0; /*0x103119d4c*/
          v29 = v37; /*0x103119d50*/
          goto LABEL_85; /*0x103119d50*/
        }
        v22 &= ~4u; /*0x103119a15*/
        a1[1] = v22; /*0x103119a18*/
        if ( v22 == 0 ) /*0x103119a1b*/
          goto LABEL_84; /*0x103119a1b*/
LABEL_51:
        if ( (v22 & 3) != 0 ) /*0x103119b5f*/
          a1[12] = v22; /*0x103119b61*/
        *v19 = 1; /*0x103119b64*/
        break; /*0x103119b64*/
      case 0x81:
        v28 = (v22 & 4) == 0; /*0x103119b15*/
        v22 = 1; /*0x103119b17*/
        if ( v28 ) /*0x103119b1c*/
          goto LABEL_50; /*0x103119b1c*/
LABEL_75:
        Curl_failf(a1: v37, a2: "[WS] fragmented message interrupted by new TEXT msg", v21, v23); /*0x103119cde*/
        goto LABEL_84; /*0x103119ce5*/
      case 0x82:
        v28 = (v22 & 4) == 0; /*0x103119b23*/
        v22 = 2; /*0x103119b25*/
        if ( v28 ) /*0x103119b2a*/
          goto LABEL_50; /*0x103119b2a*/
LABEL_76:
        Curl_failf(a1: v37, a2: "[WS] fragmented message interrupted by new BINARY msg", v21, v23); /*0x103119ce7*/
        goto LABEL_84; /*0x103119cee*/
      case 0x83:
      case 0x84:
      case 0x85:
      case 0x86:
      case 0x87:
LABEL_79:
        if ( (v21 & 0x70) != 0 )
          Curl_failf(a1: v37, a2: "[WS] invalid reserved bits: %02x", v21, v23);
        else
          Curl_failf(a1: v37, a2: "[WS] invalid opcode: %02x", v21, v23);
        goto LABEL_84; /*0x103119d18*/
      case 0x88:
        v22 = 8; /*0x103119b38*/
        goto LABEL_50; /*0x103119b3d*/
      case 0x89:
        v22 = 16; /*0x103119b0e*/
        goto LABEL_50; /*0x103119b13*/
      case 0x8A:
        v22 = 64; /*0x103119b31*/
LABEL_50:
        a1[1] = v22; /*0x103119b5a*/
        goto LABEL_51; /*0x103119b5a*/
      default:
        v23 = *((unsigned __int8 *)a1 + 24); /*0x103119af3*/
        switch ( *((_BYTE *)a1 + 24) ) /*0x103119b03*/
        {
          case 0: /*0x103119b03*/
            if ( (v22 & 4) == 0 ) /*0x103119b07*/
              goto LABEL_77; /*0x103119b07*/
            goto LABEL_50; /*0x103119b07*/
          case 1: /*0x103119b03*/
            v28 = (v22 & 4) == 0; /*0x103119b3f*/
            v22 = 5; /*0x103119b41*/
            if ( !v28 ) /*0x103119b46*/
              goto LABEL_75; /*0x103119b46*/
            goto LABEL_50; /*0x103119b46*/
          case 2: /*0x103119b03*/
            v28 = (v22 & 4) == 0; /*0x103119b4d*/
            v22 = 6; /*0x103119b4f*/
            if ( v28 ) /*0x103119b54*/
              goto LABEL_50; /*0x103119b54*/
            goto LABEL_76; /*0x103119b54*/
          case 8: /*0x103119b03*/
            Curl_failf( /*0x103119d2a*/
              a1: v37,
              a2: "[WS] invalid fragmented CLOSE frame",
              *((unsigned __int8 *)a1 + 24),
              *((unsigned __int8 *)a1 + 24));
            goto LABEL_84; /*0x103119d2a*/
          case 9: /*0x103119b03*/
            Curl_failf( /*0x103119d21*/
              a1: v37,
              a2: "[WS] invalid fragmented PING frame",
              *((unsigned __int8 *)a1 + 24),
              *((unsigned __int8 *)a1 + 24));
            goto LABEL_84; /*0x103119d21*/
          case 0xA: /*0x103119b03*/
            Curl_failf( /*0x103119d39*/
              a1: v37,
              a2: "[WS] invalid fragmented PONG frame",
              *((unsigned __int8 *)a1 + 24),
              *((unsigned __int8 *)a1 + 24));
            goto LABEL_84; /*0x103119d39*/
          default:
            v23 = (unsigned int)(v21 - 128); /*0xf1c0000000000004*/
            goto LABEL_79; /*0xf1c0000000000004*/
        }
    }
    goto LABEL_54; /*0x103119b64*/
  }
  v26 = a1[10]; /*0x103119a7f*/
  if ( (int)v20 < v26 ) /*0x103119a84*/
  {
    *((_BYTE *)a1 + v20 + 24) = *(_BYTE *)v36; /*0x103119a90*/
    Curl_bufq_skip(a1: a3, a2: 1); /*0x103119a9c*/
    v26 = a1[10]; /*0x103119aa4*/
    v27 = a1[9] + 1; /*0x103119aa7*/
    a1[9] = v27; /*0x103119aa9*/
    if ( v27 < v26 ) /*0x103119aae*/
      goto LABEL_54; /*0x103119aae*/
  }
  if ( v26 == 10 ) /*0x103119b96*/
  {
    v30 = *((char *)a1 + 26); /*0x103119bda*/
    v29 = v37; /*0x103119be2*/
    if ( v30 < 0 ) /*0x103119be6*/
    {
      Curl_failf(a1: v37, a2: "[WS] frame length longer than 63 bits not supported"); /*0x103119d05*/
      goto LABEL_85; /*0x103119d0a*/
    }
    v12 = (v30 << 56) /*0x103119c33*/
        | ((unsigned __int64)*((unsigned __int8 *)a1 + 27) << 48)
        | ((unsigned __int64)*((unsigned __int8 *)a1 + 28) << 40)
        | ((unsigned __int64)*((unsigned __int8 *)a1 + 29) << 32)
        | (*((unsigned __int8 *)a1 + 30) << 24)
        | (*((unsigned __int8 *)a1 + 31) << 16)
        | (*((unsigned __int8 *)a1 + 32) << 8)
        | *((unsigned __int8 *)a1 + 33);
    goto LABEL_71; /*0x103119c36*/
  }
  v29 = v37; /*0x103119b9b*/
  if ( v26 == 4 ) /*0x103119b9f*/
  {
    v12 = (unsigned __int16)__ROL2__(*((_WORD *)a1 + 13), 8); /*0x103119bd2*/
LABEL_71:
    *((_QWORD *)a1 + 2) = v12; /*0x103119c83*/
    *a1 = 0; /*0x103119c87*/
    *((_QWORD *)a1 + 1) = 0; /*0x103119c8d*/
    a1[11] = 2; /*0x103119c95*/
    if ( v12 == 0 ) /*0x103119c9f*/
    {
      LOBYTE(v35) = 0; /*0x103119cac*/
      v8 = 0; /*0x103119cb2*/
      v16 = v33(a1: &v35, a2: 0, a3: 0, a4: a1[1], a5: 0, a6: 0, a7: v34, a8: (_BYTE **)&v36); /*0x103119cc7*/
      if ( v16 != 0 ) /*0x103119cd0*/
        return v16; /*0x103119cd9*/
      goto LABEL_14; /*0x103119cd0*/
    }
    v11 = 0; /*0x103119ca1*/
LABEL_7:
    v8 = 0; /*0x1031198c8*/
    v13 = curlx_sotouz_range(a1: v12 - v11, a2: 0, a3: -1); /*0x1031198d7*/
    if ( v13 != 0 ) /*0x1031198df*/
    {
      v14 = v13; /*0x1031198e5*/
      while ( (unsigned __int8)Curl_bufq_peek(a1: a3, a2: &v36, a3: &v35) != 0 ) /*0x1031198fd*/
      {
        v15 = v35; /*0x103119903*/
        if ( v35 > v14 ) /*0x10311990a*/
        {
          v35 = v14; /*0x10311990c*/
          v15 = v14; /*0x103119910*/
        }
        v16 = v33( /*0x10311992c*/
                a1: v36,
                a2: v15,
                a3: *a1,
                a4: a1[1],
                a5: *((_QWORD *)a1 + 1),
                a6: *((_QWORD *)a1 + 2),
                a7: v34,
                a8: (_BYTE **)&v32);
        if ( v16 != 0 ) /*0x103119935*/
          return v16; /*0x103119935*/
        Curl_bufq_skip(a1: a3, a2: v32); /*0x103119942*/
        v17 = *((_QWORD *)a1 + 2); /*0x10311994b*/
        v18 = v32 + *((_QWORD *)a1 + 1); /*0x10311994f*/
        *((_QWORD *)a1 + 1) = v18; /*0x103119953*/
        v14 = curlx_sotouz_range(a1: v17 - v18, a2: 0, a3: -1); /*0x103119968*/
        if ( v14 == 0 ) /*0x10311996e*/
          goto LABEL_14; /*0x10311996e*/
      }
      return 81; /*0x103119b8e*/
    }
LABEL_14:
    a1[11] = 0; /*0x103119974*/
    return v8; /*0x10311997b*/
  }
  if ( v26 == 2 ) /*0x103119ba4*/
  {
    v24 = *((_BYTE *)a1 + 25); /*0x103119baa*/
    goto LABEL_70; /*0x103119bad*/
  }
  Curl_failf(a1: v37, a2: "[WS] unexpected frame header length"); /*0x103119c3f*/
LABEL_85:
  v8 = 56; /*0x103119d54*/
  Curl_failf(a1: v29, a2: "[WS] decode frame error %d", 56); /*0x103119d6b*/
  return v8; /*0x103119892*/
}

// Address: 0x103119de4 | Name: _ws_client_collect
__int64 __fastcall ws_client_collect(
        void *a1,
        size_t a2,
        int a3,
        int a4,
        __int64 a5,
        __int64 a6,
        _QWORD *a7,
        size_t *a8)
{
  signed __int64 v10; // r9
  __int64 v11; // r12
  unsigned int v12; // r14d
  __int64 v14; // rax
  __int64 v15; // rdi
  int v16; // edx
  size_t v17; // r14
  signed __int64 v19; // [rsp+0h] [rbp-40h] BYREF
  void *__src; // [rsp+8h] [rbp-38h]
  int v21; // [rsp+10h] [rbp-30h]
  int v22; // [rsp+14h] [rbp-2Ch]

  v10 = *(_QWORD *)(*a7 + 1843LL); /*0x103119e06*/
  *a8 = 0; /*0x103119e0d*/
  v11 = a6 - a5; /*0x103119e17*/
  v12 = 43; /*0x103119e20*/
  if ( ((a6 - a5) | a5 | a6) >= 0 ) /*0x103119e29*/
  {
    v19 = v10; /*0x103119e2f*/
    v22 = a3; /*0x103119e33*/
    v21 = a4; /*0x103119e36*/
    __src = a1; /*0x103119e39*/
    v14 = curlx_uztoso(a1: a2); /*0x103119e43*/
    if ( v11 >= v14 ) /*0x103119e4b*/
    {
      v15 = a7[4]; /*0x103119e58*/
      v16 = v21; /*0x103119e5f*/
      if ( v15 == 0 ) /*0x103119e62*/
      {
        *((_DWORD *)a7 + 10) = v22; /*0x103119e67*/
        *((_DWORD *)a7 + 11) = v16; /*0x103119e6a*/
        a7[6] = a5; /*0x103119e6d*/
        a7[7] = a6; /*0x103119e71*/
      }
      if ( !_bittest64(&v19, 0x29u) && (v16 & 0x10) != 0 && v11 == v14 ) /*0x103119e86*/
      {
        v12 = ws_enc_add_cntrl(a1: *a7, a2: a7[1], a3: __src); /*0x103119ee8*/
        if ( v12 != 0 ) /*0x103119eed*/
          return v12; /*0x103119eed*/
        *a8 = a2; /*0x103119f05*/
        return 0; /*0x103119f08*/
      }
      *((_BYTE *)a7 + 64) = 1; /*0x103119e8d*/
      v17 = a7[3] - v15; /*0x103119e95*/
      if ( v17 >= a2 ) /*0x103119e9b*/
        v17 = a2; /*0x103119e9b*/
      if ( v17 != 0 ) /*0x103119ea2*/
      {
        memcpy(__dst: (void *)(a7[2] + v15), __src, __n: v17); /*0x103119eaf*/
        a7[4] += v17; /*0x103119eb4*/
        *a8 = v17; /*0x103119ebc*/
        return 0; /*0x103119ec2*/
      }
      v12 = 81; /*0x103119ec9*/
      if ( a2 == 0 ) /*0x103119ecf*/
        return 0; /*0x103119ecf*/
    }
  }
  return v12; /*0x103119ef2*/
}

// Address: 0x103119f0a | Name: _ws_enc_add_pending
__int64 __fastcall ws_enc_add_pending(__int64 a1, __int64 a2)
{
  __int64 v2; // rdx
  __int64 result; // rax
  _OWORD *v5; // rbx
  __int64 v6; // [rsp-28h] [rbp-28h] BYREF

  v2 = *(unsigned int *)(a2 + 256); /*0x103119f0a*/
  result = 0; /*0x103119f10*/
  if ( (_DWORD)v2 != 0 ) /*0x103119f14*/
  {
    v6 = 0; /*0x103119f23*/
    result = 81; /*0x103119f27*/
    if ( *(_QWORD *)(a2 + 72) == 0 ) /*0x103119f31*/
    {
      result = ws_enc_add_frame(a1, a2: a2 + 64, a3: v2, a4: *(_QWORD *)(a2 + 264), a5: a2 + 160); /*0x103119f4f*/
      if ( (_DWORD)result == 0 ) /*0x103119f56*/
      {
        result = ws_enc_write_payload(a1: a2 + 64, a2: a2 + 272, a3: *(_QWORD *)(a2 + 264), a4: a2 + 160, a5: &v6); /*0x103119f70*/
        if ( (_DWORD)result == 0 ) /*0x103119f77*/
        {
          result = 55; /*0x103119f7d*/
          if ( v6 == *(_QWORD *)(a2 + 264) ) /*0x103119f89*/
          {
            v5 = (_OWORD *)(a2 + 256); /*0x103119f8b*/
            v5[8] = 0; /*0x103119f95*/
            v5[7] = 0; /*0x103119f9c*/
            v5[6] = 0; /*0x103119fa0*/
            v5[5] = 0; /*0x103119fa4*/
            v5[4] = 0; /*0x103119fa8*/
            v5[3] = 0; /*0x103119fac*/
            v5[2] = 0; /*0x103119fb0*/
            v5[1] = 0; /*0x103119fb4*/
            *v5 = 0; /*0x103119fb8*/
            return 0; /*0x103119fbb*/
          }
        }
      }
    }
  }
  return result; /*0x103119fc7*/
}

// Address: 0x103119fc8 | Name: _ws_flush
__int64 __fastcall ws_flush(__int64 a1, __int64 a2, char a3)
{
  __int64 v5; // r15
  unsigned int v6; // r13d
  __int64 i; // rdi
  unsigned int v8; // r12d
  __int64 v9; // rax
  __int64 v11; // [rsp+0h] [rbp-40h] BYREF
  __int64 v12; // [rsp+8h] [rbp-38h] BYREF
  _QWORD v13[6]; // [rsp+10h] [rbp-30h] BYREF

  v5 = a2 + 160; /*0x103119fe2*/
  v6 = 0; /*0x103119ff1*/
  if ( (unsigned __int8)Curl_bufq_is_empty(a1: a2 + 160) == 0 ) /*0x103119ff6*/
  {
    for ( i = v5; ; i = v5 ) /*0x10311a004*/
    {
      if ( (unsigned __int8)Curl_bufq_peek(a1: i, a2: &v11, a3: v13) == 0 ) /*0x10311a00e*/
        return v6; /*0x10311a00e*/
      if ( a3 != 0 ) /*0x10311a017*/
      {
        v8 = ws_send_raw_blocking(a1, a2: v11, a3: v13[0]); /*0x10311a029*/
        if ( v8 != 0 ) /*0x10311a02e*/
          v9 = 0; /*0x10311a064*/
        else
          v9 = v13[0]; /*0x10311a030*/
        v12 = v9; /*0x10311a066*/
      }
      else if ( (*(_BYTE *)(a1 + 1843) & 1) != 0 || (unsigned __int8)Curl_is_in_callback(a1) != 0 ) /*0x10311a049*/
      {
        v8 = Curl_senddata(a1, a2: v11, a3: v13[0], a4: &v12); /*0x10311a05f*/
      }
      else
      {
        v8 = Curl_xfer_send(a1, a2: v11, a3: v13[0], a4: 0, a5: &v12); /*0x10311a0a1*/
        if ( v8 == 0 && v12 == 0 && v13[0] != 0 ) /*0x10311a0b4*/
          return 81; /*0x10311a0d8*/
      }
      if ( v8 != 0 ) /*0x10311a06d*/
      {
        if ( v8 != 81 ) /*0x10311a0c2*/
          Curl_failf(a1, a2: "[WS] flush, write error %d", v8); /*0x10311a0d3*/
        return v8; /*0x10311a0d3*/
      }
      Curl_bufq_skip(a1: v5, a2: v12); /*0x10311a076*/
    }
  }
  return v6; /*0x10311a0de*/
}

// Address: 0x10311a4e1 | Name: _ws_send_raw
__int64 __fastcall ws_send_raw(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v8; // rax
  __int64 v9; // r13
  __int64 result; // rax

  v8 = Curl_conn_meta_get(a1: *(_QWORD *)(a1 + 32), a2: "meta:proto:ws:conn"); /*0x10311a506*/
  if ( v8 != 0 ) /*0x10311a50e*/
  {
    if ( a3 != 0 ) /*0x10311a513*/
    {
      v9 = v8; /*0x10311a515*/
      if ( (unsigned __int8)Curl_is_in_callback(a1) != 0 ) /*0x10311a528*/
      {
        result = ws_flush(a1, a2: v9, a3: 1); /*0x10311a52f*/
        if ( (_DWORD)result == 0 ) /*0x10311a536*/
          return ws_send_raw_blocking(a1, a2, a3); /*0x10311a54f*/
      }
      else
      {
        result = ws_flush(a1, a2: v9, a3: 0); /*0x10311a572*/
        if ( (_DWORD)result == 0 ) /*0x10311a579*/
          return Curl_senddata(a1, a2, a3, a4); /*0x10311a5a4*/
      }
    }
    else
    {
      return 0; /*0x10311a56c*/
    }
  }
  else
  {
    Curl_failf(a1, a2: "[WS] Not a websocket transfer"); /*0x10311a560*/
    return 55; /*0x10311a565*/
  }
  return result; /*0x10311a545*/
}

// Address: 0x10311a6e6 | Name: _ws_enc_write_head
__int64 __fastcall ws_enc_write_head(__int64 a1, __int64 a2, __int64 a3, unsigned int a4, __int64 a5, __int64 a6)
{
  __int64 result; // rax

  if ( *(_DWORD *)(a2 + 256) == 0 ) /*0x10311a70a*/
    return ws_enc_add_frame(a1, a2: a3, a3: a4, a4: a5, a5: a6); /*0x10311a70a*/
  result = ws_enc_add_pending(a1, a2); /*0x10311a70f*/
  if ( (_DWORD)result == 0 ) /*0x10311a716*/
    return ws_enc_add_frame(a1, a2: a3, a3: a4, a4: a5, a5: a6); /*0x10311a744*/
  return result; /*0x10311a71c*/
}

// Address: 0x10311a749 | Name: _ws_cw_init
__int64 __fastcall ws_cw_init(__int64 a1, __int64 a2)
{
  Curl_bufq_init2(a1: *(_QWORD *)(a2 + 16) + 32LL, a2: 0xFFFF, a3: 1, a4: 1); /*0x10311a764*/
  return 0; /*0x10311a76b*/
}

// Address: 0x10311a76d | Name: _ws_cw_write
__int64 __fastcall ws_cw_write(__int64 a1, __int64 a2, unsigned int a3, __int64 a4, __int64 a5)
{
  unsigned int *v10; // rcx
  unsigned int v11; // eax
  unsigned int v12; // r15d
  __int64 v13; // r13
  int v14; // eax
  __int64 v15; // rax
  _QWORD v17[3]; // [rsp+8h] [rbp-58h] BYREF
  unsigned int v18; // [rsp+20h] [rbp-40h]
  __int64 v19; // [rsp+28h] [rbp-38h]
  unsigned int *v20; // [rsp+30h] [rbp-30h]

  if ( (a3 & 1) == 0 || (*(_BYTE *)(a1 + 1848) & 1) != 0 ) /*0x10311a79e*/
    return Curl_cwriter_write(a1, a2: *(_QWORD *)(a2 + 8), a3, a4, a5); /*0x10311a8b6*/
  v20 = *(unsigned int **)(a2 + 16); /*0x10311a7a9*/
  v19 = Curl_conn_meta_get(a1: *(_QWORD *)(a1 + 32), a2: "meta:proto:ws:conn"); /*0x10311a7bd*/
  if ( v19 != 0 ) /*0x10311a7c4*/
  {
    v10 = v20; /*0x10311a7cd*/
    if ( a5 == 0 || (v11 = Curl_bufq_write(a1: v20 + 8, a2: a4, a3: a5, a4: v17), v10 = v20, v12 = v11, v11 == 0) ) /*0x10311a7f3*/
    {
      v13 = (__int64)(v10 + 8); /*0x10311a7fd*/
      if ( (unsigned __int8)Curl_bufq_is_empty(a1: v10 + 8) != 0 ) /*0x10311a80a*/
      {
LABEL_10:
        v12 = 0; /*0x10311a85f*/
        if ( (a3 & 0x80u) != 0 && (unsigned __int8)Curl_bufq_is_empty(a1: v13) == 0 ) /*0x10311a871*/
        {
          v15 = Curl_bufq_len(a1: v13); /*0x10311a876*/
          Curl_failf(a1, a2: "[WS] decode ending with %zd frame bytes remaining", v15); /*0x10311a88a*/
          return 56; /*0x10311a88f*/
        }
      }
      else
      {
        v20 = (unsigned int *)(v19 + 8); /*0x10311a814*/
        while ( 1 ) /*0x10311a818*/
        {
          v17[0] = a1; /*0x10311a818*/
          v17[1] = v19; /*0x10311a820*/
          v17[2] = *(_QWORD *)(a2 + 8); /*0x10311a829*/
          v18 = a3; /*0x10311a82d*/
          v14 = ws_dec_pass( /*0x10311a846*/
                  a1: v20,
                  a2: a1,
                  a3: v13,
                  a4: (__int64 (__fastcall *)(unsigned __int64 *, unsigned __int64, _QWORD, _QWORD, _QWORD, _QWORD, __int64, _BYTE **))ws_cw_dec_next,
                  a5: (__int64)v17);
          if ( v14 != 0 ) /*0x10311a84d*/
            break; /*0x10311a84d*/
          if ( (unsigned __int8)Curl_bufq_is_empty(a1: v13) != 0 ) /*0x10311a85d*/
            goto LABEL_10; /*0x10311a85d*/
        }
        v12 = v14; /*0x10311a8e4*/
        if ( v14 == 81 ) /*0x10311a8ea*/
          return 0; /*0x10311a8ec*/
        else
          Curl_failf(a1, a2: "[WS] decode payload error %d", v14); /*0x10311a900*/
      }
    }
  }
  else
  {
    Curl_failf(a1, a2: "[WS] not a websocket transfer"); /*0x10311a8c7*/
    return 2; /*0x10311a8cc*/
  }
  return v12; /*0x10311a8a8*/
}

// Address: 0x10311a907 | Name: _ws_cw_close
__int64 __fastcall ws_cw_close(__int64 a1, __int64 a2)
{
  return Curl_bufq_free(a1: *(_QWORD *)(a2 + 16) + 32LL); /*0x10311a913*/
}

// Address: 0x10311a919 | Name: _ws_cw_dec_next
__int64 __fastcall ws_cw_dec_next(
        __int64 a1,
        __int64 a2,
        int a3,
        int a4,
        __int64 a5,
        __int64 a6,
        __int64 *a7,
        _QWORD *a8)
{
  __int64 v10; // r8
  __int64 v11; // r9
  __int64 v12; // r15
  __int64 v13; // r12
  unsigned int v14; // r14d
  __int64 v15; // rax
  __int64 v16; // rdx
  unsigned int v17; // eax
  __int64 v20; // [rsp+8h] [rbp-48h]
  __int64 v21; // [rsp+10h] [rbp-40h]

  v10 = *a7; /*0x10311a938*/
  v11 = a7[1]; /*0x10311a93b*/
  v12 = *(_QWORD *)(*a7 + 1843); /*0x10311a93f*/
  *a8 = 0; /*0x10311a946*/
  v13 = a6 - a5; /*0x10311a950*/
  v14 = 43; /*0x10311a95c*/
  if ( ((a6 - a5) | a5 | a6) >= 0 ) /*0x10311a962*/
  {
    v21 = v11; /*0x10311a96b*/
    v20 = v10; /*0x10311a972*/
    v15 = curlx_uztoso(a1: a2); /*0x10311a981*/
    if ( v13 >= v15 ) /*0x10311a989*/
    {
      if ( (v12 & 0x20000000000LL) != 0 || (a4 & 0x10) == 0 || v13 != v15 ) /*0x10311a9a3*/
      {
        v16 = a2; /*0x10311a9aa*/
        if ( v13 != v15 && a2 == 0 ) /*0x10311a9b1*/
          goto LABEL_10; /*0x10311a9bc*/
        *(_DWORD *)(v21 + 224) = a3; /*0x10311a9cb*/
        *(_DWORD *)(v21 + 228) = a4; /*0x10311a9d1*/
        *(_QWORD *)(v21 + 232) = a5; /*0x10311a9d7*/
        *(_QWORD *)(v21 + 248) = a2; /*0x10311a9de*/
        *(_QWORD *)(v21 + 240) = a6 - a5 - a2; /*0x10311a9e5*/
        v17 = Curl_cwriter_write(a1: v20, a2: a7[2], a3: *((_DWORD *)a7 + 6) | 0x100u, a4: a1, a5: a2); /*0x10311aa08*/
        v16 = a2; /*0x10311aa0d*/
      }
      else
      {
        v17 = ws_enc_add_cntrl(a1: v20, a2: v21, a3: a1); /*0x10311aa26*/
        v16 = a2; /*0x10311aa2b*/
      }
      if ( v17 != 0 ) /*0x10311aa30*/
        return v17; /*0x10311aa35*/
LABEL_10:
      *a8 = v16; /*0x10311aa37*/
      return 0; /*0x10311aa3e*/
    }
  }
  return v14; /*0x10311aa44*/
}

// Address: 0x10311aa53 | Name: _ws_enc_add_cntrl
__int64 __fastcall ws_enc_add_cntrl(__int64 a1, __int64 a2, const void *a3, size_t a4)
{
  __int64 result; // rax
  char v7; // al

  result = 43; /*0x10311aa53*/
  if ( a4 <= 0x7D ) /*0x10311aa5c*/
  {
    *(_DWORD *)(a2 + 256) = 64; /*0x10311aa6b*/
    *(_QWORD *)(a2 + 264) = a4; /*0x10311aa75*/
    memcpy(__dst: (void *)(a2 + 272), __src: a3, __n: a4); /*0x10311aa89*/
    result = 0; /*0x10311aa8e*/
    if ( *(_QWORD *)(a2 + 72) == 0 ) /*0x10311aa95*/
    {
      result = ws_enc_add_pending(a1, a2); /*0x10311aa9d*/
      if ( (_DWORD)result == 0 ) /*0x10311aaa4*/
      {
        v7 = Curl_is_in_callback(a1); /*0x10311aaa9*/
        ws_flush(a1, a2, a3: v7); /*0x10311aab7*/
        return 0; /*0x10311aabc*/
      }
    }
  }
  return result; /*0x10311aac2*/
}

// Address: 0x10311ad09 | Name: _ws_enc_write_payload
__int64 __fastcall ws_enc_write_payload(__int64 a1, __int64 a2, unsigned __int64 a3, __int64 a4, unsigned __int64 *a5)
{
  char is_full; // cl
  __int64 result; // rax
  unsigned __int64 v11; // r15
  unsigned __int64 v12; // rax
  unsigned int v13; // eax
  char v14[8]; // [rsp+0h] [rbp-40h] BYREF
  unsigned __int64 *v15; // [rsp+8h] [rbp-38h]
  char v16[41]; // [rsp+17h] [rbp-29h] BYREF

  v15 = a5; /*0x10311ad26*/
  *a5 = 0; /*0x10311ad2a*/
  is_full = Curl_bufq_is_full(a1: a4); /*0x10311ad39*/
  result = 81; /*0x10311ad3b*/
  if ( is_full == 0 ) /*0x10311ad42*/
  {
    v11 = 0; /*0x10311ad4c*/
    v12 = curlx_sotouz_range(a1: *(_QWORD *)(a1 + 8), a2: 0, a3: -1); /*0x10311ad58*/
    if ( v12 < a3 ) /*0x10311ad60*/
      a3 = v12; /*0x10311ad60*/
    if ( a3 == 0 ) /*0x10311ad67*/
      goto LABEL_10; /*0x10311ad67*/
    v13 = *(_DWORD *)(a1 + 16); /*0x10311ad69*/
    v11 = 0; /*0x10311ad6d*/
    while ( 1 ) /*0x10311ad7c*/
    {
      v16[0] = *(_BYTE *)(a2 + v11) ^ *(_BYTE *)(a1 + v13 + 20); /*0x10311ad7c*/
      result = Curl_bufq_write(a1: a4, a2: v16, a3: 1, a4: v14); /*0x10311ad8f*/
      if ( (_DWORD)result != 0 ) /*0x10311ad96*/
        break; /*0x10311ad96*/
      v13 = ((unsigned __int8)*(_DWORD *)(a1 + 16) + 1) & 3; /*0x10311ad9e*/
      *(_DWORD *)(a1 + 16) = v13; /*0x10311ada1*/
      if ( a3 == ++v11 ) /*0x10311adab*/
      {
        v11 = a3; /*0x10311adad*/
        goto LABEL_10; /*0x10311adb0*/
      }
    }
    if ( (_DWORD)result == 81 && v11 != 0 ) /*0x10311adbb*/
    {
LABEL_10:
      *v15 = v11; /*0x10311adc2*/
      *(_QWORD *)(a1 + 8) -= v11; /*0x10311adc9*/
      return 0; /*0x10311adcd*/
    }
  }
  return result; /*0x10311adcf*/
}

// Address: 0x10311adde | Name: _ws_enc_add_frame
__int64 __fastcall ws_enc_add_frame(__int64 a1, __int64 a2, int a3, unsigned __int64 a4, __int64 a5)
{
  __int64 v6; // rax
  __int64 result; // rax
  char v9; // al
  unsigned int v10; // esi
  char v11; // r8
  char v12; // si
  char v13; // r8
  char *v14; // r12
  char *v15; // rax
  __int64 v16; // r15
  char v17; // dl
  __int64 v18; // [rsp+0h] [rbp-40h] BYREF
  char v19; // [rsp+Ah] [rbp-36h] BYREF
  char v20; // [rsp+Bh] [rbp-35h] BYREF
  char v21; // [rsp+Ch] [rbp-34h] BYREF
  char v22; // [rsp+Dh] [rbp-33h] BYREF
  _BYTE v23[5]; // [rsp+Eh] [rbp-32h] BYREF
  char v24; // [rsp+13h] [rbp-2Dh] BYREF
  char v25; // [rsp+14h] [rbp-2Ch] BYREF

  if ( (a4 & 0x8000000000000000LL) != 0LL ) /*0x10311adfe*/
  {
    Curl_failf(a1, a2: "[WS] starting new frame with negative payload length %ld", a4); /*0x10311ae24*/
    return 55; /*0x10311ae24*/
  }
  v6 = *(_QWORD *)(a2 + 8); /*0x10311ae03*/
  if ( v6 > 0 ) /*0x10311ae0a*/
  {
    Curl_failf(a1, a2: "[WS] starting new frame with %ld bytes from last one remaining to be sent", v6); /*0x10311ae16*/
    return 55; /*0x10311ae29*/
  }
  v9 = *(_BYTE *)(a2 + 25); /*0x10311ae52*/
  v10 = a3 & 0xFFFFFFDF; /*0x10311ae58*/
  v11 = v9 & 1; /*0x10311ae63*/
  switch ( a3 & 0xFFFFFFDF )
  {
    case 0u:
      v12 = 0x80; /*0x10311ae77*/
      if ( v11 != 0 ) /*0x10311ae7d*/
        goto LABEL_28; /*0x10311ae7d*/
      Curl_failf(a1, a2: "[WS] no flags given"); /*0x10311ae8a*/
      return 43; /*0x10311ae8a*/
    case 1u:
      v13 = v11 ^ 0x81; /*0x10311aecb*/
      goto LABEL_23; /*0x10311aecf*/
    case 2u:
      v12 = (2 * (v11 == 0)) | 0x80; /*0x10311aedb*/
      goto LABEL_28; /*0x10311aedf*/
    case 3u:
    case 7u:
    case 9u:
    case 0xAu:
    case 0xBu:
    case 0xDu:
    case 0xEu:
    case 0xFu:
    case 0x11u:
    case 0x12u:
    case 0x13u:
      goto LABEL_13;
    case 4u:
      if ( v11 == 0 ) /*0x10311aec0*/
      {
        Curl_failf(a1, a2: "[WS] No ongoing fragmented message to continue"); /*0x10311aec9*/
        return 43; /*0x10311aec9*/
      }
      v12 = 0; /*0x10311af15*/
      goto LABEL_28; /*0x10311af15*/
    case 5u:
      v13 = !(v9 & 1); /*0x10311aee1*/
      goto LABEL_23; /*0x10311aee5*/
    case 6u:
      v13 = (2 * v11) ^ 2; /*0x10311aeef*/
LABEL_23:
      v12 = v13; /*0x10311aef3*/
      goto LABEL_28; /*0x10311aef6*/
    case 8u:
      v12 = -120; /*0x10311aee7*/
      goto LABEL_28; /*0x10311aeea*/
    case 0xCu:
      Curl_failf(a1, a2: "[WS] CLOSE frame must not be fragmented"); /*0x10311aeb6*/
      return 43; /*0x10311aeb6*/
    case 0x10u:
      v12 = -119; /*0x10311aeb8*/
      goto LABEL_28; /*0x10311aebb*/
    case 0x14u:
      Curl_failf(a1, a2: "[WS] PING frame must not be fragmented"); /*0x10311af01*/
      return 43; /*0x10311af01*/
    default:
      if ( v10 == 64 ) /*0x10311ae8f*/
      {
        v12 = -118; /*0x10311af10*/
LABEL_28:
        if ( (a3 & 3) != 0 ) /*0x10311af1a*/
          *(_BYTE *)(a2 + 25) = ((a3 & 4) != 0) | v9 & 0xFE; /*0x10311af2c*/
        if ( (a3 & 0x10) != 0 && a4 >= 0x7E ) /*0x10311af3a*/
        {
          Curl_failf(a1, a2: "[WS] given PING frame is too big"); /*0x10311af4a*/
          return 100; /*0x10311af8c*/
        }
        if ( a4 >= 0x7E && (a3 & 0x40) != 0 ) /*0x10311af56*/
        {
          Curl_failf(a1, a2: "[WS] given PONG frame is too big"); /*0x10311af66*/
          return 100; /*0x10311af66*/
        }
        if ( a4 >= 0x7E && (a3 & 8) != 0 ) /*0x10311af72*/
        {
          Curl_failf(a1, a2: "[WS] given CLOSE frame is too big"); /*0x10311af82*/
          return 100; /*0x10311af82*/
        }
        *(_BYTE *)(a2 + 24) = v12; /*0x10311af91*/
        v19 = v12; /*0x10311af95*/
        if ( a4 < 0x10000 ) /*0x10311afa0*/
        {
          if ( a4 < 0x7E ) /*0x10311aff5*/
          {
            v14 = &v21; /*0x10311b010*/
            v15 = &v20; /*0x10311b014*/
            v17 = a4 | 0x80; /*0x10311b01a*/
            v16 = 6; /*0x10311b01d*/
            goto LABEL_43; /*0x10311b01d*/
          }
          v14 = v23; /*0x10311aff7*/
          v15 = &v22; /*0x10311affb*/
          v20 = -2; /*0x10311afff*/
          v21 = BYTE1(a4); /*0x10311b003*/
          v16 = 8; /*0x10311b006*/
        }
        else
        {
          v14 = &v25; /*0x10311afa2*/
          v15 = &v24; /*0x10311afa6*/
          v20 = -1; /*0x10311afaa*/
          v21 = HIBYTE(a4); /*0x10311afb5*/
          v22 = BYTE6(a4); /*0x10311afbf*/
          v23[0] = BYTE5(a4); /*0x10311afc9*/
          v23[1] = BYTE4(a4); /*0x10311afd3*/
          v23[2] = BYTE3(a4); /*0x10311afdb*/
          v23[3] = BYTE2(a4); /*0x10311afe3*/
          v23[4] = BYTE1(a4); /*0x10311afe6*/
          v16 = 14; /*0x10311afe9*/
        }
        v17 = a4; /*0x10311b00c*/
LABEL_43:
        *v15 = v17; /*0x10311b023*/
        *(_QWORD *)a2 = a4; /*0x10311b025*/
        *(_QWORD *)(a2 + 8) = a4; /*0x10311b028*/
        result = Curl_rand_bytes(a1, a2: a2 + 20, a3: 4); /*0x10311b035*/
        if ( (_DWORD)result == 0 ) /*0x10311b03c*/
        {
          *(_DWORD *)v14 = *(_DWORD *)(a2 + 20); /*0x10311b046*/
          *(_DWORD *)(a2 + 16) = 0; /*0x10311b04a*/
          result = Curl_bufq_write(a1: a5, a2: &v19, a3: v16, a4: &v18); /*0x10311b060*/
          if ( (_DWORD)result == 0 ) /*0x10311b067*/
          {
            result = 55; /*0x10311b073*/
            if ( v18 == v16 ) /*0x10311b078*/
              return 0; /*0x10311b078*/
          }
        }
        return result; /*0x10311b078*/
      }
      if ( v10 == 68 )
        Curl_failf(a1, a2: "[WS] PONG frame must not be fragmented"); /*0x10311ae9d*/
      else
LABEL_13:
        Curl_failf(a1, a2: "[WS] unknown flags: %x", a3);
      return 43; /*0x10311ae42*/
  }
}

// Address: 0x10311b0dc | Name: _ws_send_raw_blocking
__int64 __fastcall ws_send_raw_blocking(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v3; // rax
  __int64 v4; // r15
  __int64 result; // rax
  __int64 v8; // r13
  unsigned int v9; // r14d
  __int64 v10; // rax
  __int64 v11; // [rsp-38h] [rbp-38h] BYREF

  if ( a3 != 0 ) /*0x10311b0df*/
  {
    v11 = v3; /*0x10311b0f2*/
    v4 = a3; /*0x10311b0f3*/
    while ( 1 ) /*0x10311b10b*/
    {
      result = Curl_xfer_send(a1, a2, a3: v4, a4: 0, a5: &v11); /*0x10311b10b*/
      if ( (_DWORD)result != 0 ) /*0x10311b112*/
        return result; /*0x10311b112*/
      v8 = v11; /*0x10311b114*/
      v4 -= v11; /*0x10311b118*/
      if ( v4 == 0 ) /*0x10311b11b*/
        return 0; /*0x10311b171*/
      v9 = *(_DWORD *)(*(_QWORD *)(a1 + 32) + 400LL); /*0x10311b121*/
      v10 = Curl_timeleft_ms(a1); /*0x10311b12b*/
      if ( v10 < 0 ) /*0x10311b133*/
        break; /*0x10311b133*/
      if ( v9 == -1 ) /*0x10311b139*/
        return 55; /*0x10311b139*/
      a2 += v8; /*0x10311b13b*/
      if ( v10 == 0 ) /*0x10311b146*/
        v10 = 500; /*0x10311b146*/
      if ( (int)Curl_socket_check(a1: 0xFFFFFFFFLL, a2: 0xFFFFFFFFLL, a3: v9, a4: v10) < 0 ) /*0x10311b161*/
      {
        Curl_failf(a1, a2: "[WS] Error while waiting for socket becoming writable"); /*0x10311b16a*/
        return 55; /*0x10311b184*/
      }
    }
    Curl_failf(a1, a2: "[WS] Timeout waiting for socket becoming writable"); /*0x10311b17f*/
    return 55; /*0x10311b17f*/
  }
  return 0; /*0x10311b16e*/
}

// Address: 0x10311b198 | Name: _ws_setup_conn
__int64 __fastcall ws_setup_conn(__int64 a1)
{
  *(_BYTE *)(a1 + 4084) &= 0xF3u; /*0x10311b19c*/
  *(_WORD *)(a1 + 4081) = 257; /*0x10311b1a3*/
  return Curl_http_setup_conn(); /*0x10311b1ac*/
}

// Address: 0x1031613c0 | Name: _write_reset_stream_frame
_BYTE *__fastcall write_reset_stream_frame(__int64 a1, _QWORD *a2)
{
  _BYTE *v3; // rax
  __int64 v4; // r14
  _WORD *v5; // rax
  _BYTE *v6; // rax
  __int64 v7; // r14
  _WORD *v8; // rax
  _BYTE *v9; // rax
  __int64 v10; // rbx
  _WORD *v11; // rax
  _BYTE *v12; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"reset_stream\",", a3: 29); /*0x1031613dd*/
  v4 = a2[1]; /*0x1031613e2*/
  *v3 = 34; /*0x1031613e9*/
  v5 = (_WORD *)ngtcp2_cpymem(a1: v3 + 1, a2: "stream_id", a3: 9); /*0x1031613fc*/
  *v5 = 14882; /*0x103161406*/
  v6 = (_BYTE *)ngtcp2_encode_uint(a1: v5 + 1, a2: v4); /*0x103161411*/
  *v6 = 44; /*0x103161419*/
  v7 = a2[2]; /*0x10316141c*/
  v6[1] = 34; /*0x103161420*/
  v8 = (_WORD *)ngtcp2_cpymem(a1: v6 + 2, a2: "error_code", a3: 10); /*0x103161434*/
  *v8 = 14882; /*0x103161439*/
  v9 = (_BYTE *)ngtcp2_encode_uint(a1: v8 + 1, a2: v7); /*0x103161444*/
  *v9 = 44; /*0x103161449*/
  v10 = a2[3]; /*0x10316144c*/
  v9[1] = 34; /*0x103161450*/
  v11 = (_WORD *)ngtcp2_cpymem(a1: v9 + 2, a2: "final_size", a3: 10); /*0x103161464*/
  *v11 = 14882; /*0x103161469*/
  v12 = (_BYTE *)ngtcp2_encode_uint(a1: v11 + 1, a2: v10); /*0x103161474*/
  *v12 = 125; /*0x103161479*/
  return v12 + 1; /*0x103161483*/
}

// Address: 0x10316148e | Name: _write_stop_sending_frame
_BYTE *__fastcall write_stop_sending_frame(__int64 a1, __int64 a2)
{
  _BYTE *v3; // rax
  __int64 v4; // r14
  _WORD *v5; // rax
  _BYTE *v6; // rax
  __int64 v7; // rbx
  _WORD *v8; // rax
  _BYTE *v9; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"stop_sending\",", a3: 29); /*0x1031614a8*/
  v4 = *(_QWORD *)(a2 + 8); /*0x1031614ad*/
  *v3 = 34; /*0x1031614b4*/
  v5 = (_WORD *)ngtcp2_cpymem(a1: v3 + 1, a2: "stream_id", a3: 9); /*0x1031614c7*/
  *v5 = 14882; /*0x1031614d1*/
  v6 = (_BYTE *)ngtcp2_encode_uint(a1: v5 + 1, a2: v4); /*0x1031614dc*/
  *v6 = 44; /*0x1031614e1*/
  v7 = *(_QWORD *)(a2 + 16); /*0x1031614e4*/
  v6[1] = 34; /*0x1031614e8*/
  v8 = (_WORD *)ngtcp2_cpymem(a1: v6 + 2, a2: "error_code", a3: 10); /*0x1031614fc*/
  *v8 = 14882; /*0x103161501*/
  v9 = (_BYTE *)ngtcp2_encode_uint(a1: v8 + 1, a2: v7); /*0x10316150c*/
  *v9 = 125; /*0x103161511*/
  return v9 + 1; /*0x103161517*/
}

// Address: 0x103161520 | Name: _write_crypto_frame
_BYTE *__fastcall write_crypto_frame(__int64 a1, _QWORD *a2)
{
  _BYTE *v3; // rax
  __int64 v4; // r14
  _WORD *v5; // rax
  _BYTE *v6; // r14
  __int64 v7; // rbx
  _WORD *v8; // rax
  _BYTE *v9; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"crypto\",", a3: 23); /*0x10316153a*/
  v4 = a2[3]; /*0x10316153f*/
  *v3 = 34; /*0x103161546*/
  v5 = (_WORD *)ngtcp2_cpymem(a1: v3 + 1, a2: "offset", a3: 6); /*0x103161559*/
  *v5 = 14882; /*0x103161563*/
  v6 = (_BYTE *)ngtcp2_encode_uint(a1: v5 + 1, a2: v4); /*0x103161573*/
  *v6 = 44; /*0x103161576*/
  v7 = ngtcp2_vec_len(a1: a2[5], a2: a2[4]); /*0x103161586*/
  v6[1] = 34; /*0x103161589*/
  v8 = (_WORD *)ngtcp2_cpymem(a1: v6 + 2, a2: "length", a3: 6); /*0x1031615a0*/
  *v8 = 14882; /*0x1031615a5*/
  v9 = (_BYTE *)ngtcp2_encode_uint(a1: v8 + 1, a2: v7); /*0x1031615b0*/
  *v9 = 125; /*0x1031615b5*/
  return v9 + 1; /*0x1031615bb*/
}

// Address: 0x1031615c4 | Name: _write_new_token_frame
__int64 __fastcall write_new_token_frame(__int64 a1, __int64 a2)
{
  _BYTE *v3; // rax
  __int64 v4; // r14
  _WORD *v5; // rax
  __int64 v6; // rax
  _BYTE *v7; // rax
  __int64 v8; // r14
  __int64 v9; // rbx
  __int64 v10; // rax
  __int64 v11; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"new_token\",", a3: 26); /*0x1031615de*/
  v4 = *(_QWORD *)(a2 + 16); /*0x1031615e3*/
  *v3 = 34; /*0x1031615ea*/
  v5 = (_WORD *)ngtcp2_cpymem(a1: v3 + 1, a2: "length", a3: 6); /*0x1031615fd*/
  *v5 = 14882; /*0x103161607*/
  v6 = ngtcp2_encode_uint(a1: v5 + 1, a2: v4); /*0x103161612*/
  v7 = (_BYTE *)ngtcp2_cpymem(a1: v6, a2: ",\"token\":{", a3: 10); /*0x103161626*/
  v8 = *(_QWORD *)(a2 + 8); /*0x10316162b*/
  v9 = *(_QWORD *)(a2 + 16); /*0x10316162f*/
  *v7 = 34; /*0x103161633*/
  v10 = ngtcp2_cpymem(a1: v7 + 1, a2: "data", a3: 4); /*0x103161646*/
  *(_WORD *)v10 = 14882; /*0x10316164b*/
  *(_BYTE *)(v10 + 2) = 34; /*0x10316164f*/
  v11 = ngtcp2_encode_hex(a1: v10 + 3, a2: v8, a3: v9); /*0x10316165d*/
  *(_WORD *)v11 = 32034; /*0x103161662*/
  *(_BYTE *)(v11 + 2) = 125; /*0x103161667*/
  return v11 + 3; /*0x10316166f*/
}

// Address: 0x103161678 | Name: _write_stream_frame
char *__fastcall write_stream_frame(__int64 a1, __int64 a2)
{
  _BYTE *v3; // rax
  __int64 v4; // r14
  _WORD *v5; // rax
  _BYTE *v6; // rax
  __int64 v7; // r14
  _WORD *v8; // rax
  _BYTE *v9; // r14
  __int64 v10; // r15
  _WORD *v11; // rax
  _WORD *v12; // rax
  _WORD *v13; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"stream\",", a3: 23); /*0x103161695*/
  v4 = *(_QWORD *)(a2 + 16); /*0x10316169a*/
  *v3 = 34; /*0x1031616a1*/
  v5 = (_WORD *)ngtcp2_cpymem(a1: v3 + 1, a2: "stream_id", a3: 9); /*0x1031616b4*/
  *v5 = 14882; /*0x1031616be*/
  v6 = (_BYTE *)ngtcp2_encode_uint(a1: v5 + 1, a2: v4); /*0x1031616c9*/
  *v6 = 44; /*0x1031616d1*/
  v7 = *(_QWORD *)(a2 + 24); /*0x1031616d4*/
  v6[1] = 34; /*0x1031616d8*/
  v8 = (_WORD *)ngtcp2_cpymem(a1: v6 + 2, a2: "offset", a3: 6); /*0x1031616ec*/
  *v8 = 14882; /*0x1031616f1*/
  v9 = (_BYTE *)ngtcp2_encode_uint(a1: v8 + 1, a2: v7); /*0x103161701*/
  *v9 = 44; /*0x103161704*/
  v10 = ngtcp2_vec_len(a1: *(_QWORD *)(a2 + 40), a2: *(_QWORD *)(a2 + 32)); /*0x103161714*/
  v9[1] = 34; /*0x103161717*/
  v11 = (_WORD *)ngtcp2_cpymem(a1: v9 + 2, a2: "length", a3: 6); /*0x10316172e*/
  *v11 = 14882; /*0x103161733*/
  v12 = (_WORD *)ngtcp2_encode_uint(a1: v11 + 1, a2: v10); /*0x10316173e*/
  if ( *(_DWORD *)(a2 + 12) != 0 ) /*0x103161747*/
  {
    *v12 = 8748; /*0x103161749*/
    v13 = (_WORD *)ngtcp2_cpymem(a1: v12 + 1, a2: "fin", a3: 3); /*0x103161761*/
    *v13 = 14882; /*0x103161766*/
    v12 = (_WORD *)ngtcp2_cpymem(a1: v13 + 1, a2: "true", a3: 4); /*0x10316177b*/
  }
  *(_BYTE *)v12 = 125; /*0x103161780*/
  return (char *)v12 + 1; /*0x10316178a*/
}

// Address: 0x103161795 | Name: _write_max_data_frame
_BYTE *__fastcall write_max_data_frame(__int64 a1, __int64 a2)
{
  _BYTE *v3; // rax
  __int64 v4; // rbx
  _WORD *v5; // rax
  _BYTE *v6; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"max_data\",", a3: 25); /*0x1031617aa*/
  v4 = *(_QWORD *)(a2 + 8); /*0x1031617af*/
  *v3 = 34; /*0x1031617b3*/
  v5 = (_WORD *)ngtcp2_cpymem(a1: v3 + 1, a2: "maximum", a3: 7); /*0x1031617c6*/
  *v5 = 14882; /*0x1031617cb*/
  v6 = (_BYTE *)ngtcp2_encode_uint(a1: v5 + 1, a2: v4); /*0x1031617d7*/
  *v6 = 125; /*0x1031617dc*/
  return v6 + 1; /*0x1031617e6*/
}

// Address: 0x1031617e9 | Name: _write_max_stream_data_frame
_BYTE *__fastcall write_max_stream_data_frame(__int64 a1, __int64 a2)
{
  _BYTE *v3; // rax
  __int64 v4; // r14
  _WORD *v5; // rax
  _BYTE *v6; // rax
  __int64 v7; // rbx
  _WORD *v8; // rax
  _BYTE *v9; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"max_stream_data\",", a3: 32); /*0x103161803*/
  v4 = *(_QWORD *)(a2 + 8); /*0x103161808*/
  *v3 = 34; /*0x10316180f*/
  v5 = (_WORD *)ngtcp2_cpymem(a1: v3 + 1, a2: "stream_id", a3: 9); /*0x103161822*/
  *v5 = 14882; /*0x10316182c*/
  v6 = (_BYTE *)ngtcp2_encode_uint(a1: v5 + 1, a2: v4); /*0x103161837*/
  *v6 = 44; /*0x10316183c*/
  v7 = *(_QWORD *)(a2 + 16); /*0x10316183f*/
  v6[1] = 34; /*0x103161843*/
  v8 = (_WORD *)ngtcp2_cpymem(a1: v6 + 2, a2: "maximum", a3: 7); /*0x103161857*/
  *v8 = 14882; /*0x10316185c*/
  v9 = (_BYTE *)ngtcp2_encode_uint(a1: v8 + 1, a2: v7); /*0x103161867*/
  *v9 = 125; /*0x10316186c*/
  return v9 + 1; /*0x103161872*/
}

// Address: 0x10316187b | Name: _write_data_blocked_frame
_BYTE *__fastcall write_data_blocked_frame(__int64 a1, __int64 a2)
{
  _BYTE *v3; // rax
  __int64 v4; // rbx
  _WORD *v5; // rax
  _BYTE *v6; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"data_blocked\",", a3: 29); /*0x103161890*/
  v4 = *(_QWORD *)(a2 + 8); /*0x103161895*/
  *v3 = 34; /*0x103161899*/
  v5 = (_WORD *)ngtcp2_cpymem(a1: v3 + 1, a2: "limit", a3: 5); /*0x1031618ac*/
  *v5 = 14882; /*0x1031618b1*/
  v6 = (_BYTE *)ngtcp2_encode_uint(a1: v5 + 1, a2: v4); /*0x1031618bd*/
  *v6 = 125; /*0x1031618c2*/
  return v6 + 1; /*0x1031618cc*/
}

// Address: 0x1031618cf | Name: _write_stream_data_blocked_frame
_BYTE *__fastcall write_stream_data_blocked_frame(__int64 a1, __int64 a2)
{
  _BYTE *v3; // rax
  __int64 v4; // r14
  _WORD *v5; // rax
  _BYTE *v6; // rax
  __int64 v7; // rbx
  _WORD *v8; // rax
  _BYTE *v9; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"stream_data_blocked\",", a3: 36); /*0x1031618e9*/
  v4 = *(_QWORD *)(a2 + 8); /*0x1031618ee*/
  *v3 = 34; /*0x1031618f5*/
  v5 = (_WORD *)ngtcp2_cpymem(a1: v3 + 1, a2: "stream_id", a3: 9); /*0x103161908*/
  *v5 = 14882; /*0x103161912*/
  v6 = (_BYTE *)ngtcp2_encode_uint(a1: v5 + 1, a2: v4); /*0x10316191d*/
  *v6 = 44; /*0x103161922*/
  v7 = *(_QWORD *)(a2 + 16); /*0x103161925*/
  v6[1] = 34; /*0x103161929*/
  v8 = (_WORD *)ngtcp2_cpymem(a1: v6 + 2, a2: "limit", a3: 5); /*0x10316193d*/
  *v8 = 14882; /*0x103161942*/
  v9 = (_BYTE *)ngtcp2_encode_uint(a1: v8 + 1, a2: v7); /*0x10316194d*/
  *v9 = 125; /*0x103161952*/
  return v9 + 1; /*0x103161958*/
}

// Address: 0x103161961 | Name: _write_new_connection_id_frame
__int64 __fastcall write_new_connection_id_frame(__int64 a1, _QWORD *a2)
{
  _BYTE *v3; // rax
  __int64 v4; // r14
  _WORD *v5; // rax
  _BYTE *v6; // rax
  __int64 v7; // r14
  _WORD *v8; // rax
  _BYTE *v9; // rax
  __int64 v10; // r14
  _WORD *v11; // rax
  _WORD *v12; // rax
  __int64 v13; // rax
  __int64 v14; // rdx
  _BYTE *v15; // rax
  _BYTE *v16; // rax
  __int64 v17; // rax
  __int64 v18; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"new_connection_id\",", a3: 34); /*0x10316197e*/
  v4 = a2[1]; /*0x103161983*/
  *v3 = 34; /*0x10316198a*/
  v5 = (_WORD *)ngtcp2_cpymem(a1: v3 + 1, a2: "sequence_number", a3: 15); /*0x10316199d*/
  *v5 = 14882; /*0x1031619a7*/
  v6 = (_BYTE *)ngtcp2_encode_uint(a1: v5 + 1, a2: v4); /*0x1031619b2*/
  *v6 = 44; /*0x1031619ba*/
  v7 = a2[2]; /*0x1031619bd*/
  v6[1] = 34; /*0x1031619c1*/
  v8 = (_WORD *)ngtcp2_cpymem(a1: v6 + 2, a2: "retire_prior_to", a3: 15); /*0x1031619d5*/
  *v8 = 14882; /*0x1031619da*/
  v9 = (_BYTE *)ngtcp2_encode_uint(a1: v8 + 1, a2: v7); /*0x1031619e5*/
  *v9 = 44; /*0x1031619ea*/
  v10 = a2[3]; /*0x1031619ed*/
  v9[1] = 34; /*0x1031619f1*/
  v11 = (_WORD *)ngtcp2_cpymem(a1: v9 + 2, a2: "connection_id_length", a3: 20); /*0x103161a05*/
  *v11 = 14882; /*0x103161a0a*/
  v12 = (_WORD *)ngtcp2_encode_uint(a1: v11 + 1, a2: v10); /*0x103161a15*/
  *v12 = 8748; /*0x103161a1a*/
  v13 = ngtcp2_cpymem(a1: v12 + 1, a2: "connection_id", a3: 13); /*0x103161a2f*/
  *(_WORD *)v13 = 14882; /*0x103161a34*/
  v14 = a2[3]; /*0x103161a3c*/
  *(_BYTE *)(v13 + 2) = 34; /*0x103161a40*/
  v15 = (_BYTE *)ngtcp2_encode_hex(a1: v13 + 3, a2: a2 + 4, a3: v14); /*0x103161a48*/
  *v15 = 34; /*0x103161a4d*/
  v16 = (_BYTE *)ngtcp2_cpymem(a1: v15 + 1, a2: ",\"stateless_reset_token\":{", a3: 26); /*0x103161a60*/
  *v16 = 34; /*0x103161a69*/
  v17 = ngtcp2_cpymem(a1: v16 + 1, a2: "data", a3: 4); /*0x103161a7c*/
  *(_WORD *)v17 = 14882; /*0x103161a81*/
  *(_BYTE *)(v17 + 2) = 34; /*0x103161a85*/
  v18 = ngtcp2_encode_hex(a1: v17 + 3, a2: a2 + 7, a3: 16); /*0x103161a95*/
  *(_WORD *)v18 = 32034; /*0x103161a9a*/
  *(_BYTE *)(v18 + 2) = 125; /*0x103161a9f*/
  return v18 + 3; /*0x103161aab*/
}

// Address: 0x103161ab6 | Name: _write_retire_connection_id_frame
_BYTE *__fastcall write_retire_connection_id_frame(__int64 a1, __int64 a2)
{
  _BYTE *v3; // rax
  __int64 v4; // rbx
  _WORD *v5; // rax
  _BYTE *v6; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"retire_connection_id\",", a3: 37); /*0x103161acb*/
  v4 = *(_QWORD *)(a2 + 8); /*0x103161ad0*/
  *v3 = 34; /*0x103161ad4*/
  v5 = (_WORD *)ngtcp2_cpymem(a1: v3 + 1, a2: "sequence_number", a3: 15); /*0x103161ae7*/
  *v5 = 14882; /*0x103161aec*/
  v6 = (_BYTE *)ngtcp2_encode_uint(a1: v5 + 1, a2: v4); /*0x103161af8*/
  *v6 = 125; /*0x103161afd*/
  return v6 + 1; /*0x103161b07*/
}

// Address: 0x103161b0a | Name: _write_path_challenge_frame
_WORD *__fastcall write_path_challenge_frame(__int64 a1, __int64 a2)
{
  _BYTE *v3; // rax
  __int64 v4; // rax
  _WORD *v5; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"path_challenge\",", a3: 31); /*0x103161b20*/
  *v3 = 34; /*0x103161b2c*/
  v4 = ngtcp2_cpymem(a1: v3 + 1, a2: "data", a3: 4); /*0x103161b3f*/
  *(_WORD *)v4 = 14882; /*0x103161b44*/
  *(_BYTE *)(v4 + 2) = 34; /*0x103161b49*/
  v5 = (_WORD *)ngtcp2_encode_hex(a1: v4 + 3, a2: a2 + 8, a3: 8); /*0x103161b59*/
  *v5 = 32034; /*0x103161b5e*/
  return v5 + 1; /*0x103161b67*/
}

// Address: 0x103161b6c | Name: _write_path_response_frame
_WORD *__fastcall write_path_response_frame(__int64 a1, __int64 a2)
{
  _BYTE *v3; // rax
  __int64 v4; // rax
  _WORD *v5; // rax

  v3 = (_BYTE *)ngtcp2_cpymem(a1, a2: "{\"frame_type\":\"path_response\",", a3: 30); /*0x103161b82*/
  *v3 = 34; /*0x103161b8e*/
  v4 = ngtcp2_cpymem(a1: v3 + 1, a2: "data", a3: 4); /*0x103161ba1*/
  *(_WORD *)v4 = 14882; /*0x103161ba6*/
  *(_BYTE *)(v4 + 2) = 34; /*0x103161bab*/
  v5 = (_WORD *)ngtcp2_encode_hex(a1: v4 + 3, a2: a2 + 8, a3: 8); /*0x103161bbb*/
  *v5 = 32034; /*0x103161bc0*/
  return v5 + 1; /*0x103161bc9*/
}

// Address: 0x103162460 | Name: _write_pair_bool_impl
__int64 __fastcall write_pair_bool_impl(_BYTE *a1, __int64 a2, __int64 a3, int a4)
{
  _WORD *v5; // rdi
  _WORD *v6; // rdi
  const char *v7; // rsi
  __int64 v8; // rdx

  *a1 = 34; /*0x103162468*/
  v5 = a1 + 1; /*0x10316246b*/
  if ( a3 != 0 ) /*0x103162471*/
    v5 = (_WORD *)ngtcp2_cpymem(a1: v5, a2, a3); /*0x103162478*/
  *v5 = 14882; /*0x10316247b*/
  v6 = v5 + 1; /*0x103162480*/
  if ( a4 != 0 ) /*0x103162486*/
  {
    v7 = "true"; /*0x103162488*/
    v8 = 4; /*0x10316248f*/
  }
  else
  {
    v7 = "false"; /*0x103162496*/
    v8 = 5; /*0x10316249d*/
  }
  return ngtcp2_cpymem(a1: v6, a2: v7, a3: v8); /*0x1031624a6*/
}

// Address: 0x103162824 | Name: _write_pkt_hd
_BYTE *__fastcall write_pkt_hd(_BYTE *a1, __int64 a2)
{
  unsigned int v3; // eax
  char **v4; // r14
  __int64 v5; // rax
  char *v6; // rsi
  char *v7; // rdx
  __int64 v8; // rax
  __int64 v9; // r14
  _WORD *v10; // rax
  _BYTE *v11; // rax
  _BYTE *v12; // rax
  __int64 v13; // r14
  __int64 v14; // rbx
  __int64 v15; // rax
  _WORD *v16; // rax

  *a1 = 123; /*0x103162831*/
  v3 = *(unsigned __int8 *)(a2 + 108); /*0x103162834*/
  if ( v3 > 0x3F ) /*0x10316283b*/
  {
    switch ( v3 ) /*0x103162861*/
    {
      case 0x40u: /*0x103162861*/
        v4 = &vec_pkt_type_1rtt; /*0x10316287a*/
        break;
      case 0x80u: /*0x103162861*/
        v4 = &vec_pkt_type_version_negotiation; /*0x1031628a7*/
        break;
      case 0x81u: /*0x103162861*/
        v4 = &vec_pkt_type_stateless_reset; /*0x103162871*/
        break;
      default:
LABEL_12:
        v4 = &vec_pkt_type_unknown; /*0x10316289e*/
        break;
    }
  }
  else
  {
    switch ( *(_BYTE *)(a2 + 108) ) /*0x103162853*/
    {
      case 0x10: /*0x103162853*/
        v4 = &vec_pkt_type_initial; /*0x103162855*/
        break; /*0x10316285c*/
      case 0x11: /*0x103162853*/
        v4 = &vec_pkt_type_0rtt; /*0x103162895*/
        break; /*0x10316289c*/
      case 0x12: /*0x103162853*/
        v4 = &vec_pkt_type_handshake; /*0x103162883*/
        break; /*0x10316288a*/
      case 0x13: /*0x103162853*/
        v4 = &vec_pkt_type_retry; /*0x10316288c*/
        break; /*0x103162893*/
      default:
        goto LABEL_12;
    }
  }
  a1[1] = 34; /*0x1031628b1*/
  v5 = ngtcp2_cpymem(a1: a1 + 2, a2: "packet_type", a3: 11); /*0x1031628c5*/
  *(_WORD *)v5 = 14882; /*0x1031628ca*/
  v6 = *v4; /*0x1031628cf*/
  v7 = v4[1]; /*0x1031628d2*/
  *(_BYTE *)(v5 + 2) = 34; /*0x1031628d6*/
  v8 = v5 + 3; /*0x1031628da*/
  if ( v7 != nullptr ) /*0x1031628e1*/
    v8 = ngtcp2_cpymem(a1: v8, a2: v6, a3: v7); /*0x1031628e6*/
  *(_WORD *)v8 = 11298; /*0x1031628eb*/
  v9 = *(_QWORD *)(a2 + 64); /*0x1031628f0*/
  *(_BYTE *)(v8 + 2) = 34; /*0x1031628f4*/
  v10 = (_WORD *)ngtcp2_cpymem(a1: v8 + 3, a2: "packet_number", a3: 13); /*0x10316290b*/
  *v10 = 14882; /*0x103162910*/
  v11 = (_BYTE *)ngtcp2_encode_uint(a1: v10 + 1, a2: v9); /*0x10316291c*/
  if ( *(_BYTE *)(a2 + 108) == 16 && *(_QWORD *)(a2 + 80) != 0 ) /*0x10316292c*/
  {
    v12 = (_BYTE *)ngtcp2_cpymem(a1: v11, a2: ",\"token\":{", a3: 10); /*0x10316293d*/
    v13 = *(_QWORD *)(a2 + 72); /*0x103162942*/
    v14 = *(_QWORD *)(a2 + 80); /*0x103162946*/
    *v12 = 34; /*0x10316294a*/
    v15 = ngtcp2_cpymem(a1: v12 + 1, a2: "data", a3: 4); /*0x10316295d*/
    *(_WORD *)v15 = 14882; /*0x103162962*/
    *(_BYTE *)(v15 + 2) = 34; /*0x103162967*/
    v16 = (_WORD *)ngtcp2_encode_hex(a1: v15 + 3, a2: v13, a3: v14); /*0x103162975*/
    *v16 = 32034; /*0x10316297a*/
    v11 = v16 + 1; /*0x10316297f*/
  }
  *v11 = 125; /*0x103162983*/
  return v11 + 1; /*0x10316298d*/
}

// Address: 0x1031664bb | Name: _write_hex_zsup
_BYTE *__fastcall write_hex_zsup(_BYTE *a1, __int64 a2)
{
  _BYTE *result; // rax
  char v3; // dl
  __int64 v4; // rcx
  unsigned __int64 v5; // rdi
  bool v6; // zf
  unsigned __int8 v7; // di

  result = a1; /*0x1031664bb*/
  v3 = 1; /*0x1031664be*/
  v4 = 0; /*0x1031664c0*/
  while ( 1 ) /*0x1031664c2*/
  {
    v5 = *(unsigned __int8 *)(a2 + v4); /*0x1031664c2*/
    if ( v5 > 0xF ) /*0x1031664ca*/
      break; /*0x1031664ca*/
    if ( *(_BYTE *)(a2 + v4) != 0 ) /*0x1031664cf*/
    {
      *result++ = a0123456789abcd_6[v5]; /*0x1031664f1*/
      v4 = 1; /*0x1031664f6*/
      if ( (v3 & 1) == 0 ) /*0x1031664fe*/
        return result; /*0x1031664fe*/
      goto LABEL_8; /*0x1031664fe*/
    }
    v4 = 1; /*0x1031664d1*/
    v6 = (v3 & 1) == 0; /*0x1031664d6*/
    v3 = 0; /*0x1031664d9*/
    if ( v6 ) /*0x1031664de*/
    {
      *result++ = 48; /*0x1031664e0*/
      return result; /*0x1031664e3*/
    }
  }
  do /*0x103166534*/
  {
LABEL_8:
    v7 = *(_BYTE *)(a2 + v4); /*0x10316650b*/
    *result = a0123456789abcd_6[v7 >> 4]; /*0x10316651a*/
    result[1] = a0123456789abcd_6[v7 & 0xF]; /*0x103166524*/
    result += 2; /*0x103166528*/
    v6 = v4 == 0; /*0x10316652c*/
    v4 = 1; /*0x10316652f*/
  }
  while ( v6 ); /*0x103166534*/
  return result; /*0x1031664e6*/
}

// Address: 0x103167de4 | Name: _write_cid_param
__int64 __fastcall write_cid_param(__int64 a1, __int64 a2, _QWORD *a3)
{
  __int64 v4; // rax
  __int64 result; // rax

  v4 = ngtcp2_put_uvarint(a1); /*0x103167ded*/
  result = ngtcp2_put_uvarint(a1: v4); /*0x103167df8*/
  if ( *a3 != 0 ) /*0x103167e03*/
    return ngtcp2_cpymem(a1: result, a2: a3 + 1, a3: *a3); /*0x103167e15*/
  return result; /*0x103167e13*/
}

// Address: 0x103167e21 | Name: _write_varint_param
__int64 __fastcall write_varint_param(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v4; // r14
  __int64 v5; // rax

  v4 = ngtcp2_put_uvarint(a1); /*0x103167e30*/
  ngtcp2_put_uvarintlen(a1: a3); /*0x103167e36*/
  v5 = ngtcp2_put_uvarint(a1: v4); /*0x103167e41*/
  return ngtcp2_put_uvarint(a1: v5); /*0x103167e4c*/
}

// Address: 0x103168ff6 | Name: _wslay_event_queue_close
__int64 __fastcall wslay_event_queue_close(__int64 a1, __int16 a2, __int64 a3, unsigned __int64 a4)
{
  __int64 result; // rax
  unsigned __int64 v7; // r14
  _QWORD v8[3]; // [rsp+8h] [rbp-B8h] BYREF
  __int16 v9; // [rsp+20h] [rbp-A0h] BYREF
  _BYTE v10[134]; // [rsp+22h] [rbp-9Eh] BYREF

  result = 4294966994LL; /*0x103169012*/
  if ( *(_BYTE *)(a1 + 33) != 0 && (*(_BYTE *)(a1 + 17) & 2) == 0 ) /*0x103169024*/
  {
    result = 4294966996LL; /*0x103169029*/
    if ( a4 <= 0x7B ) /*0x103169032*/
    {
      if ( a2 != 0 ) /*0x103169037*/
      {
        v9 = __ROL2__(a2, 8); /*0x10316903d*/
        if ( a4 != 0 ) /*0x103169047*/
          __memcpy_chk(a1: v10, a2: a3, a3: a4, a4: 126); /*0x10316905b*/
        v7 = a4 + 2; /*0x103169060*/
      }
      else
      {
        v7 = 0; /*0x103169066*/
      }
      LOBYTE(v8[0]) = 8; /*0x103169070*/
      v8[1] = &v9; /*0x10316907a*/
      v8[2] = v7; /*0x10316907e*/
      result = wslay_event_queue_msg_ex(a1, a2: v8, a3: 0); /*0x103169087*/
      if ( (_DWORD)result == 0 ) /*0x10316908e*/
        *(_BYTE *)(a1 + 17) |= 2u; /*0x103169090*/
    }
  }
  return result; /*0x1031690a4*/
}

// Address: 0x1031690b5 | Name: _wslay_event_queue_msg
__int64 __fastcall wslay_event_queue_msg(__int64 a1, __int64 a2)
{
  return wslay_event_queue_msg_ex(a1, a2, a3: 0); /*0x1031690bb*/
}

// Address: 0x1031690c1 | Name: _wslay_event_queue_msg_ex
__int64 __fastcall wslay_event_queue_msg_ex(const __m128i *a1, char *a2, unsigned __int8 a3)
{
  unsigned int v3; // r15d
  char v7; // r13
  __int64 v9; // rax
  __int64 v10; // r12
  void *v11; // rax
  __int64 v12; // rdi
  unsigned int v13; // eax
  RBX::Memory *__n; // [rsp+8h] [rbp-38h]
  void *__src; // [rsp+10h] [rbp-30h]

  v3 = -302; /*0x1031690d2*/
  if ( a1[2].i8[1] != 0 && (a1[1].i8[1] & 2) == 0 ) /*0x1031690e5*/
  {
    v7 = *a2; /*0x1031690ed*/
    if ( (*a2 & 8) == 0 || (v3 = -300, (a3 & 4) == 0) && *((_QWORD *)a2 + 2) <= 0x7Du ) /*0x103169107*/
    {
      v3 = -300; /*0x103169115*/
      if ( (a3 & ~a1[273].i32[0]) == 0 ) /*0x10316911d*/
      {
        __src = *((void **)a2 + 1); /*0x103169135*/
        __n = *((RBX::Memory **)a2 + 2); /*0x10316913d*/
        v9 = RBX_wslay_malloc(this: (RBX::Memory *)0x28); /*0x103169146*/
        v3 = -500; /*0x10316914b*/
        if ( v9 != 0 ) /*0x103169154*/
        {
          *(_OWORD *)v9 = 0; /*0x10316915a*/
          *(_OWORD *)(v9 + 16) = 0; /*0x10316915e*/
          *(_QWORD *)(v9 + 32) = 0; /*0x103169163*/
          *(_BYTE *)v9 = 1; /*0x10316916b*/
          *(_BYTE *)(v9 + 1) = v7; /*0x10316916e*/
          *(_BYTE *)(v9 + 2) = a3; /*0x103169172*/
          *(_DWORD *)(v9 + 4) = 0; /*0x103169176*/
          if ( __n != nullptr ) /*0x103169184*/
          {
            v10 = v9; /*0x103169189*/
            v11 = (void *)RBX_wslay_malloc(this: __n); /*0x10316918c*/
            *(_QWORD *)(v10 + 8) = v11; /*0x103169191*/
            if ( v11 == nullptr ) /*0x103169199*/
            {
              RBX_wslay_free(a1: v10); /*0x10316920c*/
              return v3; /*0x103169211*/
            }
            memcpy(__dst: v11, __src, (size_t)__n); /*0x1031691a5*/
            v9 = v10; /*0x1031691aa*/
            *(_QWORD *)(v10 + 16) = __n; /*0x1031691ad*/
          }
          if ( (*a2 & 8) != 0 ) /*0x1031691b6*/
            v12 = a1[8].i64[1]; /*0x1031691c1*/
          else
            v12 = a1[8].i64[0]; /*0x1031691b8*/
          v13 = wslay_queue_push(a1: v12, a2: v9); /*0x1031691cb*/
          if ( v13 != 0 ) /*0x1031691d2*/
          {
            return v13; /*0x1031691d4*/
          }
          else
          {
            a1[9] = _mm_add_epi64( /*0x1031691f9*/
                      _mm_insert_epi64(_mm_cvtepi8_epi64(257), *((_QWORD *)a2 + 2), 1),
                      _mm_loadu_si128(a1 + 9));
            return 0; /*0x103169201*/
          }
        }
      }
    }
  }
  return v3; /*0x103169122*/
}

// Address: 0x103169216 | Name: _wslay_event_queue_fragmented_msg
__int64 __fastcall wslay_event_queue_fragmented_msg(__int64 a1, __int64 a2)
{
  return wslay_event_queue_fragmented_msg_ex(a1, a2, a3: 0); /*0x10316921c*/
}

// Address: 0x103169222 | Name: _wslay_event_queue_fragmented_msg_ex
__int64 __fastcall wslay_event_queue_fragmented_msg_ex(__int64 a1, char *a2, unsigned __int8 a3)
{
  __int64 result; // rax
  char v5; // r15
  __int64 v7; // rax
  __int128 v8; // [rsp-38h] [rbp-38h]

  result = 4294966994LL; /*0x103169222*/
  if ( *(_BYTE *)(a1 + 33) != 0 && (*(_BYTE *)(a1 + 17) & 2) == 0 ) /*0x103169241*/
  {
    v5 = *a2; /*0x103169243*/
    result = 4294966996LL; /*0x103169246*/
    if ( (*a2 & 8) == 0 && (a3 & ~*(_DWORD *)(a1 + 4368)) == 0 ) /*0x103169262*/
    {
      v8 = *(_OWORD *)(a2 + 8); /*0x103169273*/
      v7 = RBX_wslay_malloc(this: (RBX::Memory *)0x28); /*0x10316927c*/
      if ( v7 != 0 ) /*0x103169284*/
      {
        *(_OWORD *)v7 = 0; /*0x103169289*/
        *(_OWORD *)(v7 + 16) = 0; /*0x10316928c*/
        *(_QWORD *)(v7 + 32) = 0; /*0x103169290*/
        *(_BYTE *)(v7 + 1) = v5; /*0x103169298*/
        *(_BYTE *)(v7 + 2) = a3; /*0x10316929c*/
        *(_DWORD *)(v7 + 4) = 1; /*0x1031692a0*/
        *(_OWORD *)(v7 + 24) = v8; /*0x1031692ab*/
        result = wslay_queue_push(a1: *(_QWORD *)(a1 + 128), a2: v7); /*0x1031692b9*/
        if ( (_DWORD)result == 0 ) /*0x1031692c0*/
        {
          ++*(_QWORD *)(a1 + 144); /*0x1031692c2*/
          return 0; /*0x1031692c9*/
        }
      }
      else
      {
        return 4294966796LL; /*0x1031692cd*/
      }
    }
  }
  return result; /*0x10316926e*/
}

// Address: 0x1031692d4 | Name: _wslay_event_config_set_callbacks
__int64 __fastcall wslay_event_config_set_callbacks(__int64 a1, __int128 *a2)
{
  __int64 result; // rax
  __int128 v3; // xmm0
  __int128 v4; // xmm1

  result = *((_QWORD *)a2 + 6); /*0x1031692d8*/
  *(_QWORD *)(a1 + 4336) = result; /*0x1031692dc*/
  v3 = *a2; /*0x1031692e3*/
  v4 = a2[1]; /*0x1031692e6*/
  *(_OWORD *)(a1 + 4320) = a2[2]; /*0x1031692ee*/
  *(_OWORD *)(a1 + 4304) = v4; /*0x1031692f5*/
  *(_OWORD *)(a1 + 4288) = v3; /*0x1031692fc*/
  return result; /*0x103169303*/
}

// Address: 0x103169305 | Name: _wslay_event_context_server_init
__int64 __fastcall wslay_event_context_server_init(__int64 a1)
{
  __int64 result; // rax

  result = wslay_event_context_init(a1); /*0x10316930e*/
  if ( (_DWORD)result == 0 ) /*0x103169315*/
    *(_BYTE *)(*(_QWORD *)a1 + 16LL) = 1; /*0x10316931a*/
  return result; /*0x103169322*/
}

// Address: 0x103169325 | Name: _wslay_event_context_init
__int64 __fastcall wslay_event_context_init(__int64 *a1, __int128 *a2, __int64 a3)
{
  __int64 v6; // rax
  unsigned int v7; // ebx
  __int64 v8; // rax
  __int128 v9; // xmm0
  __int128 v10; // xmm1
  __int64 v11; // rax
  unsigned int v12; // eax
  __int64 v13; // rdx
  __int64 v14; // rsi
  __int64 v15; // rdi
  unsigned int v16; // r15d
  __int64 v17; // rdx
  __int64 v18; // rsi
  __int64 v19; // rdi
  __int64 v20; // rdx
  __int64 v21; // rsi
  char v22; // r15
  __int64 v23; // rax
  __int64 v24; // r12
  __int64 v25; // rdi
  __int64 v26; // rdx
  __int64 v27; // rdi
  __int64 v28; // rsi
  bool v29; // zf
  __int64 v30; // rcx
  __int64 v31; // rax
  __int128 v33; // [rsp+0h] [rbp-40h] BYREF
  __int64 (__fastcall *v34)(); // [rsp+10h] [rbp-30h]

  v34 = off_10C8C02D8; /*0x103169344*/
  v33 = *(_OWORD *)off_10C8C02C8; /*0x10316934f*/
  v6 = RBX_wslay_malloc(this: (RBX::Memory *)0x1118); /*0x103169358*/
  *a1 = v6; /*0x10316935d*/
  v7 = -500; /*0x103169360*/
  if ( v6 != 0 ) /*0x103169368*/
  {
    __bzero(a1: v6, a2: 4376); /*0x103169376*/
    v8 = *a1; /*0x10316937b*/
    *(_QWORD *)(v8 + 4336) = *((_QWORD *)a2 + 6); /*0x103169383*/
    v9 = *a2; /*0x10316938a*/
    v10 = a2[1]; /*0x10316938f*/
    *(_OWORD *)(v8 + 4320) = a2[2]; /*0x10316939b*/
    *(_OWORD *)(v8 + 4304) = v10; /*0x1031693a2*/
    *(_OWORD *)(v8 + 4288) = v9; /*0x1031693a9*/
    *(_QWORD *)(*a1 + 4360) = a3; /*0x1031693b3*/
    v11 = *a1; /*0x1031693ba*/
    *(_QWORD *)(v11 + 4344) = v11; /*0x1031693bd*/
    *(_QWORD *)(v11 + 4352) = a3; /*0x1031693c4*/
    v12 = ((__int64 (__fastcall *)(__int64, __int128 *, __int64))wslay_frame_context_init)( /*0x1031693dd*/
            a1: *a1 + 24,
            a2: &v33,
            a3: *a1 + 4344);
    v15 = *a1; /*0x1031693e2*/
    if ( v12 != 0 ) /*0x1031693e7*/
    {
      v16 = v12; /*0x1031693e9*/
      wslay_event_context_free(a1: v15); /*0x1031693ec*/
      return v16; /*0x1031693f1*/
    }
    else
    {
      *(_WORD *)(v15 + 32) = 257; /*0x1031693f9*/
      *(_QWORD *)(*a1 + 128) = wslay_queue_new(a1: v15, a2: v14, a3: v13); /*0x103169407*/
      v19 = *a1; /*0x10316940e*/
      if ( *(_QWORD *)(*a1 + 128) != 0 ) /*0x103169419*/
      {
        *(_QWORD *)(*a1 + 136) = wslay_queue_new(a1: v19, a2: v18, a3: v17); /*0x103169427*/
        v19 = *a1; /*0x10316942e*/
        if ( *(_QWORD *)(*a1 + 136) != 0 ) /*0x103169439*/
        {
          *(_OWORD *)(v19 + 144) = 0; /*0x103169442*/
          v22 = 1; /*0x103169449*/
          v23 = 0; /*0x10316944c*/
          while ( 1 ) /*0x103169452*/
          {
            v24 = 24 * v23; /*0x103169452*/
            v25 = 24 * v23 + v19 + 40; /*0x103169459*/
            *(_BYTE *)(v25 + 2) = -1; /*0x10316945d*/
            *(_DWORD *)(v25 + 4) = 0; /*0x103169461*/
            wslay_event_imsg_chunks_free(a1: v25, a2: v21, a3: v20); /*0x103169468*/
            *(_QWORD *)(*a1 + v24 + 48) = wslay_queue_new(a1: v27, a2: v28, a3: v26); /*0x103169475*/
            v19 = *a1; /*0x10316947a*/
            if ( *(_QWORD *)(*a1 + v24 + 48) == 0 ) /*0x103169483*/
              break; /*0x103169483*/
            v23 = 1; /*0x103169485*/
            v29 = (v22 & 1) == 0; /*0x10316948a*/
            v22 = 0; /*0x10316948e*/
            if ( v29 ) /*0x103169494*/
            {
              *(_QWORD *)(v19 + 88) = v19 + 40; /*0x10316949a*/
              v30 = *a1 + 160; /*0x1031694a1*/
              *(_QWORD *)(*a1 + 4256) = v30; /*0x1031694a8*/
              *(_QWORD *)(*a1 + 4264) = v30; /*0x1031694b2*/
              v31 = *a1; /*0x1031694b9*/
              *(_DWORD *)(v31 + 18) = 65930222; /*0x1031694bc*/
              *(_QWORD *)(v31 + 8) = 0x7FFFFFFF; /*0x1031694c3*/
              return 0; /*0x1031694cd*/
            }
          }
        }
      }
      wslay_event_context_free(a1: v19); /*0x1031694cf*/
    }
  }
  return v7; /*0x1031694d6*/
}

// Address: 0x1031694e3 | Name: _wslay_event_context_client_init
__int64 __fastcall wslay_event_context_client_init(__int64 *a1, __int128 *a2, __int64 a3)
{
  __int64 result; // rax

  result = wslay_event_context_init(a1, a2, a3); /*0x1031694ec*/
  if ( (_DWORD)result == 0 ) /*0x1031694f3*/
    *(_BYTE *)(*a1 + 16) = 0; /*0x1031694f8*/
  return result; /*0x103169500*/
}

// Address: 0x103169503 | Name: _wslay_event_context_free
__int64 __fastcall wslay_event_context_free(_QWORD *a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rdx
  __int64 v5; // rsi
  __int64 v6; // rdi
  unsigned int v7; // eax
  __int64 v8; // rdi
  unsigned int v9; // eax
  __int64 result; // rax

  if ( a1 != nullptr ) /*0x103169506*/
  {
    wslay_event_imsg_chunks_free(a1: a1 + 5, a2, a3); /*0x103169519*/
    wslay_queue_free(a1: a1[6]); /*0x103169522*/
    wslay_event_imsg_chunks_free(a1: a1 + 8, a2: v5, a3: v4); /*0x10316952b*/
    wslay_queue_free(a1: a1[9]); /*0x103169534*/
    v6 = a1[16]; /*0x103169539*/
    if ( v6 != 0 ) /*0x103169543*/
    {
      while ( (unsigned int)wslay_queue_empty(a1: v6) == 0 ) /*0x103169575*/
      {
        v7 = wslay_queue_top(a1: a1[16]); /*0x10316954e*/
        wslay_event_omsg_free(a1: v7); /*0x103169556*/
        wslay_queue_pop(a1: a1[16]); /*0x103169562*/
        v6 = a1[16]; /*0x103169567*/
      }
      wslay_queue_free(a1: a1[16]); /*0x10316957e*/
    }
    v8 = a1[17]; /*0x103169583*/
    if ( v8 != 0 ) /*0x10316958d*/
    {
      while ( (unsigned int)wslay_queue_empty(a1: v8) == 0 ) /*0x1031695bf*/
      {
        v9 = wslay_queue_top(a1: a1[17]); /*0x103169598*/
        wslay_event_omsg_free(a1: v9); /*0x1031695a0*/
        wslay_queue_pop(a1: a1[17]); /*0x1031695ac*/
        v8 = a1[17]; /*0x1031695b1*/
      }
      wslay_queue_free(a1: a1[17]); /*0x1031695c8*/
    }
    wslay_frame_context_free(a1: a1[3]); /*0x1031695d1*/
    wslay_event_omsg_free(a1: a1[15]); /*0x1031695da*/
    return RBX_wslay_free((unsigned int)a1); /*0x1031695e8*/
  }
  return result; /*0x1031695ed*/
}

// Address: 0x1031695ee | Name: _wslay_event_imsg_chunks_free
__int64 __fastcall wslay_event_imsg_chunks_free(__int64 a1)
{
  __int64 v2; // rdi
  unsigned int v3; // eax
  __int64 result; // rax

  v2 = *(_QWORD *)(a1 + 8); /*0x1031695f7*/
  if ( v2 != 0 ) /*0x1031695fe*/
  {
    while ( 1 ) /*0x103169620*/
    {
      result = wslay_queue_empty(a1: v2); /*0x103169620*/
      if ( (_DWORD)result != 0 ) /*0x103169627*/
        break; /*0x103169627*/
      v3 = wslay_queue_top(a1: *(_QWORD *)(a1 + 8)); /*0x103169606*/
      wslay_event_byte_chunk_free(a1: v3); /*0x10316960e*/
      wslay_queue_pop(a1: *(_QWORD *)(a1 + 8)); /*0x103169617*/
      v2 = *(_QWORD *)(a1 + 8); /*0x10316961c*/
    }
  }
  return result; /*0x10316962d*/
}

// Address: 0x103169630 | Name: _wslay_event_omsg_free
__int64 __fastcall wslay_event_omsg_free(__int64 a1)
{
  unsigned int v1; // ebx
  __int64 result; // rax

  if ( a1 != 0 ) /*0x103169633*/
  {
    v1 = a1; /*0x10316963b*/
    RBX_wslay_free(a1: *(_QWORD *)(a1 + 8)); /*0x103169642*/
    return RBX_wslay_free(a1: v1); /*0x103169650*/
  }
  return result; /*0x103169655*/
}

// Address: 0x103169656 | Name: _wslay_event_recv
__int64 __fastcall wslay_event_recv(__int64 a1)
{
  unsigned int v1; // r14d
  _QWORD *v3; // r13
  int v4; // eax
  unsigned __int64 v5; // r8
  char v6; // al
  size_t v7; // rdx
  char v8; // cl
  char v9; // si
  int v10; // esi
  RBX::Memory *v11; // rdi
  RBX::Memory *v12; // r12
  __int64 v13; // r14
  __int64 *v14; // rax
  unsigned int v15; // r13d
  __int64 *v16; // r15
  __int64 v17; // rax
  unsigned int v18; // eax
  __int64 v19; // rax
  unsigned __int64 v20; // rsi
  size_t v21; // rcx
  unsigned __int8 *v22; // r9
  int v23; // edi
  unsigned int v24; // eax
  void (__fastcall *v25)(__int64, void **, _QWORD, _QWORD, unsigned __int64, unsigned __int8 *); // rcx
  size_t v26; // rax
  _QWORD *v27; // rax
  size_t v28; // rax
  int v29; // r12d
  __int64 v30; // rdi
  char v31; // al
  int v32; // ecx
  void (__fastcall *v33)(__int64, _QWORD, size_t, _QWORD, unsigned __int64, unsigned __int8 *); // rcx
  bool v34; // zf
  _WORD *v35; // r8
  _QWORD *v36; // r9
  __int64 v37; // r12
  __int64 v38; // rax
  _WORD *v39; // r14
  __int64 v40; // r13
  __int64 v41; // r15
  int v42; // eax
  unsigned __int64 v43; // rcx
  __int16 v44; // ax
  __int16 v45; // r15
  unsigned int v46; // eax
  int v47; // ecx
  _WORD *v48; // r14
  int v49; // r12d
  unsigned __int64 v50; // rcx
  __int64 v51; // rdx
  __int16 v52; // si
  int v53; // eax
  int v54; // r12d
  void (__fastcall *v55)(__int64, void **, _QWORD); // rax
  __int64 v56; // rdi
  __int16 v57; // si
  unsigned int v58; // eax
  int v60; // eax
  unsigned int v61; // eax
  char v62[8]; // [rsp+8h] [rbp-A8h] BYREF
  _WORD *v63; // [rsp+10h] [rbp-A0h]
  __int64 v64; // [rsp+18h] [rbp-98h]
  __int64 v65; // [rsp+20h] [rbp-90h]
  size_t v66; // [rsp+28h] [rbp-88h]
  void *v67; // [rsp+30h] [rbp-80h] BYREF
  size_t v68; // [rsp+38h] [rbp-78h]
  _QWORD *v69; // [rsp+40h] [rbp-70h]
  __int16 v70; // [rsp+48h] [rbp-68h]
  RBX::Memory *v71[2]; // [rsp+50h] [rbp-60h]
  void *__src[2]; // [rsp+60h] [rbp-50h]
  size_t __n; // [rsp+70h] [rbp-40h]
  _QWORD *v74; // [rsp+78h] [rbp-38h]
  int v75; // [rsp+84h] [rbp-2Ch]

  v3 = (_QWORD *)(a1 + 96); /*0x10316966d*/
  v66 = a1 + 64; /*0x103169675*/
  v65 = a1 + 40; /*0x103169680*/
  while ( 1 ) /*0x10316968b*/
  {
    if ( *(_BYTE *)(a1 + 32) == 0 ) /*0x10316968f*/
      return 0; /*0x10316968f*/
    *(_OWORD *)__src = 0; /*0x103169698*/
    *(_OWORD *)v71 = 0; /*0x10316969c*/
    __n = 0; /*0x1031696a0*/
    v4 = wslay_frame_recv(__dst: *(void **)(a1 + 24)); /*0x1031696af*/
    if ( v4 < 0 ) /*0x1031696b6*/
    {
      if ( v4 != -100 || (v60 = *(_DWORD *)(a1 + 112)) != -401 && v60 != 0 ) /*0x103169d3a*/
      {
        *(_BYTE *)(a1 + 32) = 0; /*0x103169d3c*/
        v61 = wslay_event_queue_close(a1, a2: 0, a3: 0, a4: 0); /*0x103169d49*/
        if ( v61 == 0 ) /*0x103169d50*/
          return (unsigned int)-400; /*0x103169d50*/
        v1 = v61; /*0x103169d52*/
        if ( v61 == -302 ) /*0x103169d5a*/
          return (unsigned int)-400; /*0x103169d5c*/
        return v1; /*0x103169d62*/
      }
      return 0; /*0x103169d3a*/
    }
    v6 = BYTE1(v71[0]); /*0x1031696bc*/
    if ( (BYTE1(v71[0]) & ~*(_DWORD *)(a1 + 4368)) != 0 /*0x1031696f8*/
      || (BYTE1(v71[0]) & 4) != 0 && (BYTE2(v71[0]) == 0 || (BYTE2(v71[0]) & 8) != 0)
      || (*(_BYTE *)(a1 + 16) != 0) != (LOBYTE(__src[0]) != 0) )
    {
LABEL_107:
      *(_BYTE *)(a1 + 32) = 0; /*0x103169cee*/
      v56 = a1; /*0x103169cf2*/
      v57 = 1002; /*0x103169cf5*/
      goto LABEL_108; /*0x103169cf5*/
    }
    v7 = *(_QWORD *)(a1 + 88); /*0x1031696fe*/
    if ( *(_BYTE *)(v7 + 2) == 0xFF ) /*0x103169706*/
    {
      v8 = BYTE2(v71[0]); /*0x103169753*/
      if ( BYTE2(v71[0]) > 0xAu ) /*0x10316975a*/
        goto LABEL_107; /*0x10316975a*/
      v10 = 1798; /*0x103169760*/
      if ( !_bittest(&v10, BYTE2(v71[0])) ) /*0x103169765*/
        goto LABEL_107; /*0x103169768*/
      v9 = (char)v71[0]; /*0x10316976e*/
      *(_BYTE *)v7 = v71[0]; /*0x103169772*/
      *(_BYTE *)(v7 + 1) = v6; /*0x103169775*/
      *(_BYTE *)(v7 + 2) = v8; /*0x103169778*/
      *(_QWORD *)(v7 + 16) = 0; /*0x10316977b*/
    }
    else
    {
      if ( *v3 != 0 || *(_QWORD *)(a1 + 104) != 0 ) /*0x103169718*/
        goto LABEL_27; /*0x103169718*/
      v8 = BYTE2(v71[0]); /*0x10316971e*/
      if ( (unsigned int)BYTE2(v71[0]) - 8 >= 3 ) /*0x10316972a*/
      {
        if ( BYTE2(v71[0]) != 0 ) /*0x103169be3*/
          goto LABEL_107; /*0x103169be3*/
        v9 = (char)v71[0]; /*0x103169be9*/
        *(_BYTE *)v7 = v71[0]; /*0x103169bed*/
        v8 = 0; /*0x103169bf0*/
      }
      else
      {
        v7 = v66; /*0x103169730*/
        *(_QWORD *)(a1 + 88) = v66; /*0x103169737*/
        v9 = (char)v71[0]; /*0x10316973b*/
        *(_BYTE *)(a1 + 64) = v71[0]; /*0x10316973f*/
        *(_BYTE *)(a1 + 65) = v6; /*0x103169743*/
        *(_BYTE *)(a1 + 66) = v8; /*0x103169746*/
        *(_QWORD *)(a1 + 80) = 0; /*0x103169749*/
      }
    }
    v11 = v71[1]; /*0x103169783*/
    v7 = (size_t)v71[1] + *(_QWORD *)(v7 + 16); /*0x10316978b*/
    if ( v7 > *(_QWORD *)(a1 + 8) ) /*0x103169792*/
    {
      *(_BYTE *)(a1 + 32) = 0; /*0x103169d64*/
      v56 = a1; /*0x103169d68*/
      v57 = 1009; /*0x103169d6b*/
      goto LABEL_108; /*0x103169d70*/
    }
    *(RBX::Memory **)(a1 + 96) = v71[1]; /*0x103169798*/
    v5 = *(_QWORD *)(a1 + 4312); /*0x10316979c*/
    if ( v5 != 0 ) /*0x1031697a6*/
    {
      LOBYTE(v67) = v9; /*0x1031697a8*/
      BYTE1(v67) = v6; /*0x1031697ac*/
      BYTE2(v67) = v8; /*0x1031697af*/
      v68 = (size_t)v11; /*0x1031697b2*/
      ((void (__fastcall *)(__int64, void **, _QWORD))v5)(a1, a2: &v67, a3: *(_QWORD *)(a1 + 4360)); /*0x1031697c4*/
    }
    if ( (*(_BYTE *)a1 & 1) == 0 || (BYTE2(v71[0]) & 8) != 0 ) /*0x1031697d0*/
    {
      v12 = v71[1]; /*0x1031697d2*/
      if ( v71[1] != nullptr ) /*0x1031697d9*/
        break; /*0x1031697d9*/
    }
LABEL_27:
    v19 = *(_QWORD *)(a1 + 88); /*0x103169845*/
    LOBYTE(v7) = *(_BYTE *)(v19 + 2); /*0x10316984c*/
    v20 = (unsigned int)v7; /*0x103169852*/
    LOBYTE(v20) = *(_BYTE *)(v19 + 1) & 4 | v7 ^ 1; /*0x103169858*/
    if ( (_BYTE)v20 != 0 ) /*0x10316985b*/
    {
      v21 = 2; /*0x103169868*/
      v22 = utf8d_0; /*0x103169870*/
      if ( (_BYTE)v7 != 8 ) /*0x103169877*/
        goto LABEL_37; /*0x103169877*/
    }
    else
    {
      v21 = 0; /*0x10316985d*/
      v22 = utf8d_0; /*0x10316985f*/
    }
    v7 = __n; /*0x103169879*/
    if ( v21 < __n ) /*0x103169880*/
    {
      v20 = (unsigned __int64)__src[1]; /*0x103169882*/
      v23 = *(_DWORD *)(v19 + 4); /*0x103169886*/
      while ( 1 ) /*0x10316988e*/
      {
        v5 = utf8d_0[*(unsigned __int8 *)(v20 + v21)]; /*0x10316988e*/
        v23 = utf8d_0[(unsigned int)(v5 + v23 + 256)]; /*0x10316989c*/
        *(_DWORD *)(v19 + 4) = v23; /*0x1031698a1*/
        if ( v23 == 12 ) /*0x1031698a7*/
          break; /*0x1031698a7*/
        if ( v7 == ++v21 ) /*0x1031698af*/
          goto LABEL_37; /*0x1031698af*/
      }
      *(_BYTE *)(a1 + 32) = 0; /*0x1031698b3*/
      v24 = wslay_event_queue_close(a1, a2: 1007, a3: 0, a4: 0); /*0x1031698c3*/
      if ( v24 != 0 && v24 != -302 ) /*0x1031698d1*/
        return v24; /*0x103169d9c*/
    }
LABEL_37:
    if ( *(_DWORD *)(*(_QWORD *)(a1 + 88) + 4LL) == 12 ) /*0x1031698df*/
      return 0; /*0x1031698df*/
    v25 = *(void (__fastcall **)(__int64, void **, _QWORD, _QWORD, unsigned __int64, unsigned __int8 *))(a1 + 4320); /*0x1031698e5*/
    v26 = __n; /*0x1031698ec*/
    if ( v25 != nullptr ) /*0x1031698f3*/
    {
      v67 = __src[1]; /*0x1031698f9*/
      v68 = __n; /*0x1031698fd*/
      v25(a1, a2: &v67, a3: *(_QWORD *)(a1 + 4360), a4: v25, a5: v5, a6: v22); /*0x10316990f*/
      v26 = __n; /*0x103169911*/
    }
    if ( v26 != 0 ) /*0x103169918*/
    {
      if ( (*(_BYTE *)a1 & 1) == 0 || (BYTE2(v71[0]) & 8) != 0 ) /*0x103169923*/
      {
        v27 = (_QWORD *)wslay_queue_tail( /*0x10316992d*/
                          a1: *(_QWORD *)(*(_QWORD *)(a1 + 88) + 8LL),
                          a2: v20,
                          a3: v7,
                          a4: v25,
                          a5: v5,
                          a6: v22);
        memcpy(__dst: (void *)(*(_QWORD *)(a1 + 104) + *v27), __src: __src[1], __n); /*0x103169941*/
        v26 = __n; /*0x103169946*/
      }
      v28 = *(_QWORD *)(a1 + 104) + v26; /*0x10316994a*/
      *(_QWORD *)(a1 + 104) = v28; /*0x10316994e*/
    }
    else
    {
      v28 = *(_QWORD *)(a1 + 104); /*0x103169954*/
    }
    v29 = 0; /*0x103169958*/
    if ( v28 != *v3 ) /*0x10316995f*/
      goto LABEL_104; /*0x10316995f*/
    v30 = *(_QWORD *)(a1 + 88); /*0x103169965*/
    v31 = *(_BYTE *)v30; /*0x103169969*/
    if ( *(_BYTE *)v30 != 0 ) /*0x10316996d*/
    {
      v32 = *(unsigned __int8 *)(v30 + 2); /*0x10316996f*/
      if ( (v32 == 8 || v32 == 1) && *(_DWORD *)(v30 + 4) != 0 ) /*0x103169981*/
      {
        *(_BYTE *)(a1 + 32) = 0; /*0x103169d88*/
        v56 = a1; /*0x103169d8c*/
        v57 = 1007; /*0x103169d8f*/
LABEL_108:
        v58 = wslay_event_queue_close(a1: v56, a2: v57, a3: 0, a4: 0); /*0x103169cfa*/
        if ( v58 != -302 ) /*0x103169d08*/
        {
          v1 = v58; /*0x103169d0a*/
          if ( v58 != 0 ) /*0x103169d0f*/
            return v1; /*0x103169d0f*/
        }
        return 0; /*0x103169d11*/
      }
    }
    v33 = *(void (__fastcall **)(__int64, _QWORD, size_t, _QWORD, unsigned __int64, unsigned __int8 *))(a1 + 4328); /*0x103169987*/
    if ( v33 != nullptr ) /*0x103169991*/
    {
      v33(a1, a2: *(_QWORD *)(a1 + 4360), a3: v7, a4: v33, a5: v5, a6: v22); /*0x10316999d*/
      v30 = *(_QWORD *)(a1 + 88); /*0x10316999f*/
      v31 = *(_BYTE *)v30; /*0x1031699a3*/
    }
    if ( v31 == 0 ) /*0x1031699a7*/
      goto LABEL_101; /*0x1031699a7*/
    if ( *(_QWORD *)(a1 + 4336) != 0 || (*(_BYTE *)(v30 + 2) & 0xFE) == 8 ) /*0x1031699be*/
    {
      v34 = (*(_BYTE *)a1 & 1) == 0; /*0x1031699c4*/
      v75 = v1; /*0x1031699c7*/
      if ( !v34 && (BYTE2(v71[0]) & 8) == 0 ) /*0x1031699d1*/
      {
        v35 = nullptr; /*0x1031699d3*/
        v36 = nullptr; /*0x1031699d6*/
        goto LABEL_70; /*0x1031699d9*/
      }
      if ( *(_QWORD *)(v30 + 16) != 0 ) /*0x1031699e5*/
      {
        v37 = *(_QWORD *)(v30 + 8); /*0x1031699e7*/
        v38 = RBX_wslay_malloc(this: *(RBX::Memory **)(v30 + 16)); /*0x1031699ee*/
        if ( v38 != 0 ) /*0x1031699f6*/
        {
          v39 = (_WORD *)v38; /*0x1031699f8*/
          if ( (unsigned int)wslay_queue_empty(a1: v37) != 0 ) /*0x103169a05*/
          {
            v30 = *(_QWORD *)(a1 + 88); /*0x103169a07*/
            v36 = *(_QWORD **)(v30 + 16); /*0x103169a0b*/
            v35 = v39; /*0x103169a0f*/
            v1 = v75; /*0x103169a12*/
            goto LABEL_70; /*0x103169a16*/
          }
          v74 = v3; /*0x103169a22*/
          v40 = 0; /*0x103169a26*/
          do /*0x103169a6a*/
          {
            v41 = wslay_queue_top(a1: v37); /*0x103169a31*/
            memcpy(__dst: (char *)v39 + v40, __src: *(const void **)v41, __n: *(_QWORD *)(v41 + 8)); /*0x103169a3f*/
            v40 += *(_QWORD *)(v41 + 8); /*0x103169a44*/
            RBX_wslay_free(a1: *(_QWORD *)v41); /*0x103169a4b*/
            RBX_wslay_free(a1: v41); /*0x103169a53*/
            wslay_queue_pop(a1: v37); /*0x103169a5b*/
          }
          while ( (unsigned int)wslay_queue_empty(a1: v37) == 0 ); /*0x103169a6a*/
          v3 = v74; /*0x103169a6c*/
          v35 = v39; /*0x103169a70*/
        }
        else
        {
          v35 = nullptr; /*0x103169a1d*/
        }
        v1 = v75; /*0x103169a73*/
      }
      else
      {
        v35 = nullptr; /*0x103169a18*/
      }
      v30 = *(_QWORD *)(a1 + 88); /*0x103169a77*/
      v36 = *(_QWORD **)(v30 + 16); /*0x103169a7b*/
      if ( v36 == nullptr || v35 != nullptr ) /*0x103169a88*/
      {
LABEL_70:
        v42 = *(unsigned __int8 *)(v30 + 2); /*0x103169a93*/
        v74 = v36; /*0x103169a9a*/
        if ( v42 == 9 ) /*0x103169a9e*/
        {
          v62[0] = 10; /*0x103169b5a*/
          v48 = v35; /*0x103169b61*/
          v63 = v35; /*0x103169b64*/
          v64 = *(_QWORD *)(v30 + 16); /*0x103169b6f*/
          v49 = wslay_event_queue_msg_ex((const __m128i *)a1, a2: v62, a3: 0); /*0x103169b87*/
          if ( v49 != -302 && v49 != 0 ) /*0x103169b94*/
          {
            *(_BYTE *)(a1 + 32) = 0; /*0x103169b96*/
            RBX_wslay_free(a1: (unsigned int)v48); /*0x103169b9d*/
            v75 = v49; /*0x103169ba2*/
          }
          v45 = 0; /*0x103169ba6*/
          if ( v49 != 0 ) /*0x103169bac*/
          {
            v47 = 1; /*0x103169bb2*/
            if ( v49 != -302 ) /*0x103169bbe*/
              goto LABEL_103; /*0x103169bbe*/
          }
          goto LABEL_96; /*0x103169bbe*/
        }
        if ( v42 != 8 ) /*0x103169aa7*/
        {
          v48 = v35; /*0x103169bc5*/
          v45 = 0; /*0x103169bc8*/
LABEL_96:
          v55 = *(void (__fastcall **)(__int64, void **, _QWORD))(a1 + 4336); /*0x103169c34*/
          if ( v55 != nullptr ) /*0x103169c3e*/
          {
            LOWORD(v67) = *(_WORD *)(*(_QWORD *)(a1 + 88) + 1LL); /*0x103169c47*/
            v68 = (size_t)v48; /*0x103169c50*/
            v69 = v74; /*0x103169c58*/
            v70 = v45; /*0x103169c5c*/
            *(_DWORD *)(a1 + 112) = 0; /*0x103169c61*/
            v55(a1, a2: &v67, a3: *(_QWORD *)(a1 + 4360)); /*0x103169c76*/
          }
          RBX_wslay_free(a1: (unsigned int)v48); /*0x103169c7b*/
          v30 = *(_QWORD *)(a1 + 88); /*0x103169c80*/
          v29 = 0; /*0x103169c88*/
          v1 = v75; /*0x103169c8b*/
          goto LABEL_99; /*0x103169c8b*/
        }
        v43 = *(_QWORD *)(v30 + 16); /*0x103169aad*/
        if ( v43 <= 1 ) /*0x103169ab5*/
        {
          v48 = v35; /*0x103169bcd*/
          *(_BYTE *)(a1 + 17) |= 1u; /*0x103169bd0*/
          v50 = 0; /*0x103169bd4*/
          v51 = 0; /*0x103169bd6*/
        }
        else
        {
          v44 = *v35; /*0x103169abb*/
          v45 = __ROL2__(*v35, 8); /*0x103169ac2*/
          if ( (unsigned __int16)(v45 - 5000) <= 0xF82Fu /*0x103169ad2*/
            && ((unsigned __int16)(v45 - 1004) < 3u || (unsigned __int16)(v45 - 1012) < 0xFFF4u) )
          {
            RBX_wslay_free(a1: (unsigned int)v35); /*0x103169b06*/
            *(_BYTE *)(a1 + 32) = 0; /*0x103169b0b*/
            v46 = wslay_event_queue_close(a1, a2: 1002, a3: 0, a4: 0); /*0x103169b1b*/
            if ( v46 == 0 || v46 == -302 ) /*0x103169b29*/
              v46 = 0; /*0x103169b2b*/
            v47 = 2 * (v46 == 0) + 1; /*0x103169b34*/
            if ( v46 != 0 ) /*0x103169b38*/
              v1 = v46; /*0x103169b38*/
            v75 = v1; /*0x103169b3c*/
            goto LABEL_103; /*0x103169b40*/
          }
          *(_BYTE *)(a1 + 17) |= 1u; /*0x103169bf7*/
          v48 = v35; /*0x103169bfb*/
          v51 = (__int64)(v35 + 1); /*0x103169bfe*/
          v50 = v43 - 2; /*0x103169c02*/
          v52 = v45; /*0x103169c06*/
          if ( v44 != 0 ) /*0x103169c0c*/
          {
LABEL_94:
            *(_WORD *)(a1 + 18) = v52; /*0x103169c0e*/
            *(_BYTE *)(a1 + 32) = 0; /*0x103169c12*/
            v53 = wslay_event_queue_close(a1, a2: v45, a3: v51, a4: v50); /*0x103169c1d*/
            if ( v53 == -302 ) /*0x103169c27*/
              goto LABEL_96; /*0x103169c27*/
            v54 = v53; /*0x103169c29*/
            if ( v53 == 0 ) /*0x103169c2e*/
              goto LABEL_96; /*0x103169c2e*/
            RBX_wslay_free(a1: (unsigned int)v48); /*0x103169cc4*/
            v47 = 1; /*0x103169cc9*/
            v75 = v54; /*0x103169cce*/
LABEL_103:
            v29 = v47; /*0x103169cd2*/
            v1 = v75; /*0x103169cd9*/
            goto LABEL_104; /*0x103169cd9*/
          }
        }
        v52 = 1005; /*0x103169bd8*/
        v45 = 0; /*0x103169bdc*/
        goto LABEL_94; /*0x103169bdf*/
      }
      *(_BYTE *)(a1 + 32) = 0; /*0x103169b45*/
      v75 = -500; /*0x103169b49*/
      v47 = 1; /*0x103169b50*/
      goto LABEL_103; /*0x103169b55*/
    }
LABEL_99:
    *(_BYTE *)(v30 + 2) = -1; /*0x103169c8f*/
    *(_DWORD *)(v30 + 4) = 0; /*0x103169c93*/
    wslay_event_imsg_chunks_free(a1: v30); /*0x103169c9a*/
    if ( *(_QWORD *)(a1 + 88) == v66 ) /*0x103169caa*/
      *(_QWORD *)(a1 + 88) = v65; /*0x103169cb3*/
LABEL_101:
    *(_OWORD *)v3 = 0; /*0x103169cb7*/
LABEL_104:
    if ( v29 != 0 ) /*0x103169ce0*/
    {
      if ( v29 != 3 ) /*0x103169cea*/
        return v1; /*0x103169cea*/
      return 0; /*0x103169cea*/
    }
  }
  v74 = v3; /*0x1031697db*/
  v75 = v1; /*0x1031697df*/
  v13 = *(_QWORD *)(a1 + 88); /*0x1031697e3*/
  v14 = (__int64 *)RBX_wslay_malloc(this: (RBX::Memory *)0x10); /*0x1031697ec*/
  v15 = -500; /*0x1031697f1*/
  if ( v14 == nullptr ) /*0x1031697fa*/
    goto LABEL_121; /*0x1031697fa*/
  v16 = v14; /*0x103169800*/
  *(_OWORD *)v14 = 0; /*0x103169806*/
  v17 = RBX_wslay_malloc(this: v12); /*0x10316980c*/
  *v16 = v17; /*0x103169811*/
  if ( v17 == 0 ) /*0x103169817*/
  {
    RBX_wslay_free(a1: (unsigned int)v16); /*0x103169d75*/
    goto LABEL_121; /*0x103169d7a*/
  }
  v16[1] = (__int64)v12; /*0x10316981d*/
  v18 = wslay_queue_push(a1: *(_QWORD *)(v13 + 8), a2: v16); /*0x103169828*/
  if ( v18 == 0 ) /*0x10316982f*/
  {
    *(_QWORD *)(v13 + 16) += v12; /*0x103169835*/
    v1 = v75; /*0x103169839*/
    v3 = v74; /*0x10316983d*/
    goto LABEL_27; /*0x10316983d*/
  }
  v15 = v18; /*0x103169d7c*/
LABEL_121:
  *(_BYTE *)(a1 + 32) = 0; /*0x103169d7f*/
  return v15; /*0x103169d17*/
}

// Address: 0x103169da1 | Name: _wslay_event_send
__int64 __fastcall wslay_event_send(__int64 a1)
{
  unsigned int v1; // ebx
  __int64 v3; // r15
  __int64 v4; // r8
  __int64 v5; // r9
  int v6; // ecx
  __int64 v7; // rax
  int v8; // ecx
  unsigned int v9; // eax
  __int64 v10; // rcx
  __int64 v11; // rdx
  int v12; // eax
  __int64 v13; // rdx
  int v14; // eax
  __int64 v15; // rax
  __int64 v16; // rdi
  __int64 v17; // rcx
  __int64 v18; // rax
  __int64 v19; // rax
  unsigned __int64 v20; // rax
  __int16 v21; // ax
  __int16 v22; // ax
  int v23; // eax
  __int128 v25; // [rsp+0h] [rbp-60h] BYREF
  __int128 v26; // [rsp+10h] [rbp-50h]
  __int64 v27; // [rsp+20h] [rbp-40h]
  _DWORD v28[11]; // [rsp+34h] [rbp-2Ch] BYREF

  v1 = 0; /*0x103169db2*/
  if ( *(_BYTE *)(a1 + 33) == 0 ) /*0x103169db8*/
    return v1; /*0x103169db8*/
  v3 = a1 + 160; /*0x103169dc1*/
  while ( 1 ) /*0x103169dde*/
  {
    if ( (unsigned int)wslay_queue_empty(a1: *(_QWORD *)(a1 + 128)) != 0 ) /*0x103169dde*/
    {
      v6 = wslay_queue_empty(a1: *(_QWORD *)(a1 + 136)); /*0x103169dec*/
      v7 = *(_QWORD *)(a1 + 120); /*0x103169dee*/
      if ( v6 != 0 ) /*0x103169df4*/
      {
        if ( v7 == 0 ) /*0x103169df9*/
          return v1; /*0x103169df9*/
        goto LABEL_9; /*0x103169df9*/
      }
    }
    else
    {
      v7 = *(_QWORD *)(a1 + 120); /*0x103169e00*/
    }
    if ( v7 == 0 ) /*0x103169e07*/
    {
      if ( (unsigned int)wslay_queue_empty(a1: *(_QWORD *)(a1 + 136)) != 0 ) /*0x103169e79*/
      {
        *(_QWORD *)(a1 + 120) = wslay_queue_top(a1: *(_QWORD *)(a1 + 128)); /*0x103169e87*/
        wslay_queue_pop(a1: *(_QWORD *)(a1 + 128)); /*0x103169e92*/
        v7 = *(_QWORD *)(a1 + 120); /*0x103169e97*/
      }
      else
      {
        v7 = wslay_event_send_ctrl_queue_pop(a1); /*0x103169ea0*/
        *(_QWORD *)(a1 + 120) = v7; /*0x103169ea5*/
        if ( v7 == 0 ) /*0x103169eac*/
          return v1; /*0x103169eac*/
      }
      if ( *(_DWORD *)(v7 + 4) == 0 ) /*0x103169eb6*/
        goto LABEL_19; /*0x103169eb6*/
      goto LABEL_20; /*0x103169eb6*/
    }
LABEL_9:
    if ( (*(_BYTE *)(v7 + 1) & 8) == 0 && *(_DWORD *)(*(_QWORD *)(a1 + 24) + 4216LL) == 0 ) /*0x103169e1e*/
    {
      v8 = wslay_queue_empty(a1: *(_QWORD *)(a1 + 136)); /*0x103169e30*/
      v7 = *(_QWORD *)(a1 + 120); /*0x103169e32*/
      if ( v8 == 0 ) /*0x103169e38*/
      {
        v9 = wslay_queue_push_front(a1: *(_QWORD *)(a1 + 128), a2: *(_QWORD *)(a1 + 120)); /*0x103169e48*/
        if ( v9 != 0 ) /*0x103169e4f*/
        {
          *(_BYTE *)(a1 + 33) = 0; /*0x10316a122*/
          return v9; /*0x10316a129*/
        }
        v7 = wslay_event_send_ctrl_queue_pop(a1); /*0x103169e58*/
        *(_QWORD *)(a1 + 120) = v7; /*0x103169e5d*/
        if ( v7 == 0 ) /*0x103169e64*/
          return v1; /*0x103169e64*/
LABEL_19:
        *(_BYTE *)v7 = 1; /*0x103169eb8*/
        *(_QWORD *)(a1 + 4272) = *(_QWORD *)(v7 + 16); /*0x103169ebf*/
        *(_QWORD *)(a1 + 4280) = 0; /*0x103169ec6*/
      }
    }
LABEL_20:
    if ( *(_DWORD *)(v7 + 4) == 0 ) /*0x103169ed5*/
      break; /*0x103169ed5*/
    v10 = *(_QWORD *)(a1 + 4256); /*0x103169ee2*/
    v11 = *(_QWORD *)(a1 + 4264); /*0x103169ee9*/
    if ( *(_BYTE *)v7 == 0 && v10 == v11 ) /*0x103169ef3*/
    {
      v28[0] = 0; /*0x103169f00*/
      v12 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, __int64, _DWORD *, _QWORD))(v7 + 32))( /*0x103169f20*/
              a1,
              a2: v3,
              a3: 4096,
              a4: v7 + 24,
              a5: v28,
              a6: *(_QWORD *)(a1 + 4360));
      if ( v12 == 0 ) /*0x103169f25*/
        return v1; /*0x103169f25*/
      if ( v12 < 0 ) /*0x103169f2b*/
        goto LABEL_46; /*0x103169f2b*/
      v13 = (unsigned int)v12; /*0x103169f31*/
      v10 = v3 + (unsigned int)v12; /*0x103169f33*/
      *(_QWORD *)(a1 + 4256) = v10; /*0x103169f37*/
      v7 = *(_QWORD *)(a1 + 120); /*0x103169f42*/
      if ( v28[0] != 0 ) /*0x103169f46*/
        *(_BYTE *)v7 = 1; /*0x103169f48*/
      *(_QWORD *)(a1 + 4272) = v13; /*0x103169f4b*/
      *(_QWORD *)(a1 + 4280) = 0; /*0x103169f52*/
      v11 = *(_QWORD *)(a1 + 4264); /*0x103169f5d*/
    }
    v26 = 0; /*0x103169f67*/
    v25 = 0; /*0x103169f6b*/
    v27 = 0; /*0x103169f6f*/
    LOBYTE(v25) = *(_BYTE *)v7; /*0x103169f7a*/
    BYTE2(v25) = *(_BYTE *)(v7 + 1); /*0x103169f82*/
    BYTE1(v25) = *(_BYTE *)(v7 + 2); /*0x103169f89*/
    LOBYTE(v26) = *(_BYTE *)(a1 + 16) == 0; /*0x103169f91*/
    *((_QWORD *)&v26 + 1) = v11; /*0x103169f95*/
    v27 = v10 - v11; /*0x103169f9c*/
    *((_QWORD *)&v25 + 1) = *(_QWORD *)(a1 + 4272); /*0x103169fa7*/
    v14 = ((__int64 (__fastcall *)(_QWORD, __int128 *, __int64, __int64, __int64, __int64))wslay_frame_send)( /*0x103169fb2*/
            a1: *(_QWORD *)(a1 + 24),
            a2: &v25,
            a3: v11,
            a4: v10 - v11,
            a5: v4,
            a6: v5);
    if ( v14 < 0 ) /*0x103169fb9*/
      goto LABEL_43; /*0x103169fb9*/
    v15 = *(_QWORD *)(a1 + 4264) + (unsigned int)v14; /*0x103169fc1*/
    *(_QWORD *)(a1 + 4264) = v15; /*0x103169fc8*/
    if ( v15 != *(_QWORD *)(a1 + 4256) ) /*0x103169fd6*/
      return v1; /*0x103169fd6*/
    *(_QWORD *)(a1 + 4256) = v3; /*0x103169fdc*/
    *(_QWORD *)(a1 + 4264) = v3; /*0x103169fe3*/
    v16 = *(_QWORD *)(a1 + 120); /*0x103169fea*/
    if ( *(_BYTE *)v16 != 0 ) /*0x103169ff1*/
    {
      --*(_QWORD *)(a1 + 144); /*0x103169ff7*/
LABEL_40:
      wslay_event_omsg_free(a1: v16); /*0x10316a0d9*/
      *(_QWORD *)(a1 + 120) = 0; /*0x10316a0de*/
      goto LABEL_41; /*0x10316a0de*/
    }
    *(_BYTE *)(v16 + 1) = 0; /*0x10316a0c6*/
    *(_BYTE *)(v16 + 2) &= ~4u; /*0x10316a0ca*/
LABEL_41:
    if ( *(_BYTE *)(a1 + 33) == 0 ) /*0x10316a0eb*/
      return v1; /*0x10316a0eb*/
  }
  v25 = 0; /*0x10316a006*/
  v26 = 0; /*0x10316a00a*/
  v27 = 0; /*0x10316a00e*/
  LOBYTE(v25) = 1; /*0x10316a016*/
  BYTE2(v25) = *(_BYTE *)(v7 + 1); /*0x10316a01d*/
  BYTE1(v25) = *(_BYTE *)(v7 + 2); /*0x10316a023*/
  LOBYTE(v26) = *(_BYTE *)(a1 + 16) ^ 1; /*0x10316a02d*/
  v17 = *(_QWORD *)(a1 + 4280); /*0x10316a030*/
  *((_QWORD *)&v26 + 1) = v17 + *(_QWORD *)(v7 + 8); /*0x10316a03e*/
  v18 = *(_QWORD *)(a1 + 4272); /*0x10316a042*/
  v27 = v18 - v17; /*0x10316a04f*/
  *((_QWORD *)&v25 + 1) = v18; /*0x10316a053*/
  v14 = ((__int64 (__fastcall *)(_QWORD, __int128 *))wslay_frame_send)(a1: *(_QWORD *)(a1 + 24), a2: &v25); /*0x10316a05e*/
  if ( v14 >= 0 ) /*0x10316a065*/
  {
    v19 = *(_QWORD *)(a1 + 4280) + (unsigned int)v14; /*0x10316a06d*/
    *(_QWORD *)(a1 + 4280) = v19; /*0x10316a074*/
    if ( v19 != *(_QWORD *)(a1 + 4272) ) /*0x10316a082*/
      return v1; /*0x10316a082*/
    --*(_QWORD *)(a1 + 144); /*0x10316a088*/
    v16 = *(_QWORD *)(a1 + 120); /*0x10316a08f*/
    v20 = *(_QWORD *)(v16 + 16); /*0x10316a093*/
    *(_QWORD *)(a1 + 152) -= v20; /*0x10316a097*/
    if ( *(_BYTE *)(v16 + 1) == 8 ) /*0x10316a0a2*/
    {
      *(_BYTE *)(a1 + 33) = 0; /*0x10316a0a4*/
      *(_BYTE *)(a1 + 17) |= 4u; /*0x10316a0a9*/
      if ( v20 >= 2 && (v21 = **(_WORD **)(v16 + 8)) != 0 ) /*0x10316a0be*/
        v22 = __ROL2__(v21, 8); /*0x10316a0c0*/
      else
        v22 = 1005; /*0x10316a0d0*/
      *(_WORD *)(a1 + 20) = v22; /*0x10316a0d4*/
    }
    goto LABEL_40; /*0x10316a0d4*/
  }
LABEL_43:
  if ( v14 != -101 || (v23 = *(_DWORD *)(a1 + 112)) != -401 && v23 != 0 ) /*0x10316a105*/
  {
LABEL_46:
    *(_BYTE *)(a1 + 33) = 0; /*0x10316a107*/
    return (unsigned int)-400; /*0x10316a10c*/
  }
  return v1; /*0x10316a113*/
}

// Address: 0x10316a12b | Name: _wslay_event_send_ctrl_queue_pop
__int64 __fastcall wslay_event_send_ctrl_queue_pop(__int64 a1)
{
  bool v2; // zf
  __int64 v3; // rdi
  __int64 v4; // r14

  v2 = (*(_BYTE *)(a1 + 17) & 2) == 0; /*0x10316a135*/
  v3 = *(_QWORD *)(a1 + 136); /*0x10316a139*/
  if ( v2 ) /*0x10316a140*/
  {
    v4 = wslay_queue_top(a1: v3); /*0x10316a147*/
    wslay_queue_pop(a1: *(_QWORD *)(a1 + 136)); /*0x10316a151*/
  }
  else
  {
    while ( (unsigned int)wslay_queue_empty(a1: v3) == 0 ) /*0x10316a15f*/
    {
      v4 = wslay_queue_top(a1: *(_QWORD *)(a1 + 136)); /*0x10316a16d*/
      wslay_queue_pop(a1: *(_QWORD *)(a1 + 136)); /*0x10316a177*/
      if ( *(_BYTE *)(v4 + 1) == 8 ) /*0x10316a181*/
        return v4; /*0x10316a181*/
      wslay_event_omsg_free(a1: v4); /*0x10316a186*/
      v3 = *(_QWORD *)(a1 + 136); /*0x10316a18b*/
    }
    return 0; /*0x10316a194*/
  }
  return v4; /*0x10316a19a*/
}

// Address: 0x10316a19f | Name: _wslay_event_set_error
void __fastcall wslay_event_set_error(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 112) = a2; /*0x10316a1a3*/
}

// Address: 0x10316a1a8 | Name: _wslay_event_want_read
__int64 __fastcall wslay_event_want_read(__int64 a1)
{
  return *(unsigned __int8 *)(a1 + 32); /*0x10316a1b0*/
}

// Address: 0x10316a1b2 | Name: _wslay_event_want_write
__int64 __fastcall wslay_event_want_write(__int64 a1)
{
  unsigned int v2; // ebx

  if ( *(_BYTE *)(a1 + 33) != 0 ) /*0x10316a1bd*/
  {
    v2 = 1; /*0x10316a1ce*/
    if ( (unsigned int)wslay_queue_empty(a1: *(_QWORD *)(a1 + 128)) != 0 /*0x10316a1e5*/
      && (unsigned int)wslay_queue_empty(a1: *(_QWORD *)(a1 + 136)) != 0 )
    {
      return *(_QWORD *)(a1 + 120) != 0; /*0x10316a1ee*/
    }
  }
  else
  {
    return 0; /*0x10316a1f3*/
  }
  return v2; /*0x10316a1f7*/
}

// Address: 0x10316a1fc | Name: _wslay_event_shutdown_read
void __fastcall wslay_event_shutdown_read(__int64 a1)
{
  *(_BYTE *)(a1 + 32) = 0; /*0x10316a200*/
}

// Address: 0x10316a206 | Name: _wslay_event_shutdown_write
void __fastcall wslay_event_shutdown_write(__int64 a1)
{
  *(_BYTE *)(a1 + 33) = 0; /*0x10316a20a*/
}

// Address: 0x10316a210 | Name: _wslay_event_get_read_enabled
__int64 __fastcall wslay_event_get_read_enabled(__int64 a1)
{
  return *(unsigned __int8 *)(a1 + 32); /*0x10316a218*/
}

// Address: 0x10316a21a | Name: _wslay_event_get_write_enabled
__int64 __fastcall wslay_event_get_write_enabled(__int64 a1)
{
  return *(unsigned __int8 *)(a1 + 33); /*0x10316a222*/
}

// Address: 0x10316a224 | Name: _wslay_event_get_close_received
__int64 __fastcall wslay_event_get_close_received(__int64 a1)
{
  return *(_BYTE *)(a1 + 17) & 1; /*0x10316a22f*/
}

// Address: 0x10316a231 | Name: _wslay_event_get_close_sent
_BOOL8 __fastcall wslay_event_get_close_sent(__int64 a1)
{
  return (*(_BYTE *)(a1 + 17) & 4) != 0; /*0x10316a23f*/
}

// Address: 0x10316a241 | Name: _wslay_event_config_set_allowed_rsv_bits
void __fastcall wslay_event_config_set_allowed_rsv_bits(__int64 a1, char a2)
{
  *(_BYTE *)(a1 + 4368) = a2 & 4; /*0x10316a249*/
}

// Address: 0x10316a252 | Name: _wslay_event_config_set_no_buffering
__int64 __fastcall wslay_event_config_set_no_buffering(_DWORD *a1, int a2)
{
  __int64 result; // rax

  result = *a1 & 0xFFFFFFFE | (a2 != 0); /*0x10316a262*/
  *a1 = result; /*0x10316a264*/
  return result; /*0x10316a266*/
}

// Address: 0x10316a268 | Name: _wslay_event_config_set_max_recv_msg_length
void __fastcall wslay_event_config_set_max_recv_msg_length(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a1 + 8) = a2; /*0x10316a26c*/
}

// Address: 0x10316a272 | Name: _wslay_event_get_status_code_received
__int64 __fastcall wslay_event_get_status_code_received(__int64 a1)
{
  return *(unsigned __int16 *)(a1 + 18); /*0x10316a27a*/
}

// Address: 0x10316a27c | Name: _wslay_event_get_status_code_sent
__int64 __fastcall wslay_event_get_status_code_sent(__int64 a1)
{
  return *(unsigned __int16 *)(a1 + 20); /*0x10316a284*/
}

// Address: 0x10316a286 | Name: _wslay_event_get_queued_msg_count
__int64 __fastcall wslay_event_get_queued_msg_count(__int64 a1)
{
  return *(_QWORD *)(a1 + 144); /*0x10316a291*/
}

// Address: 0x10316a293 | Name: _wslay_event_get_queued_msg_length
__int64 __fastcall wslay_event_get_queued_msg_length(__int64 a1)
{
  return *(_QWORD *)(a1 + 152); /*0x10316a29e*/
}

// Address: 0x10316a2a0 | Name: _wslay_event_frame_send_callback
__int64 __fastcall wslay_event_frame_send_callback(__int64 a1, __int64 a2, unsigned int a3, _QWORD *a4)
{
  return (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, _QWORD, _QWORD))(*a4 + 4296LL))(
           a1: *a4,
           a2: a1,
           a3: a2,
           a4: a3,
           a5: a4[1]);
}

// Address: 0x10316a2c0 | Name: _wslay_event_frame_recv_callback
__int64 __fastcall wslay_event_frame_recv_callback(__int64 a1, __int64 a2, unsigned int a3, _QWORD *a4)
{
  return (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, _QWORD, _QWORD))(*a4 + 4288LL))(
           a1: *a4,
           a2: a1,
           a3: a2,
           a4: a3,
           a5: a4[1]);
}

// Address: 0x10316a2e0 | Name: _wslay_event_frame_genmask_callback
__int64 __fastcall wslay_event_frame_genmask_callback(__int64 a1, __int64 a2, _QWORD *a3)
{
  return (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, _QWORD))(*a3 + 4304LL))(
           a1: *a3,
           a2: a1,
           a3: a2,
           a4: a3[1]);
}

// Address: 0x10316a2ff | Name: _wslay_event_byte_chunk_free
__int64 __fastcall wslay_event_byte_chunk_free(_QWORD *a1)
{
  unsigned int v1; // ebx
  __int64 result; // rax

  if ( a1 != nullptr ) /*0x10316a302*/
  {
    v1 = (unsigned int)a1; /*0x10316a30a*/
    RBX_wslay_free(a1: *a1); /*0x10316a310*/
    return RBX_wslay_free(a1: v1); /*0x10316a31e*/
  }
  return result; /*0x10316a323*/
}

// Address: 0x10316a324 | Name: _wslay_frame_context_init
__int64 __fastcall wslay_frame_context_init(__int64 *a1, __int64 a2, __int64 a3)
{
  __int64 v6; // rax
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rax

  v6 = RBX_wslay_malloc(this: (RBX::Memory *)0x10A0); /*0x10316a33c*/
  *a1 = v6; /*0x10316a341*/
  if ( v6 == 0 ) /*0x10316a347*/
    return 0xFFFFFFFFLL; /*0x10316a3ac*/
  __bzero(a1: v6, a2: 4256); /*0x10316a351*/
  v7 = *a1; /*0x10316a356*/
  *(_DWORD *)(v7 + 4144) = 3; /*0x10316a359*/
  *(_QWORD *)(v7 + 4152) = 2; /*0x10316a363*/
  *(_DWORD *)(v7 + 4216) = 0; /*0x10316a36e*/
  *(_QWORD *)(v7 + 4248) = a3; /*0x10316a378*/
  v8 = *a1; /*0x10316a37f*/
  *(_QWORD *)(v8 + 4104) = v8; /*0x10316a382*/
  *(_QWORD *)(v8 + 4096) = v8; /*0x10316a389*/
  v9 = *a1; /*0x10316a390*/
  *(_QWORD *)(v9 + 4240) = *(_QWORD *)(a2 + 16); /*0x10316a397*/
  *(_OWORD *)(v9 + 4224) = *(_OWORD *)a2; /*0x10316a3a1*/
  return 0; /*0x10316a3b5*/
}

// Address: 0x10316a3bc | Name: _wslay_frame_context_free
__int64 __fastcall wslay_frame_context_free(unsigned int a1)
{
  return RBX_wslay_free(a1); /*0x10316a3c0*/
}

// Address: 0x10316a3c6 | Name: _wslay_frame_send
__int64 __fastcall wslay_frame_send(__int64 a1, __int64 a2)
{
  __int64 v2; // r14
  int v6; // eax
  int v7; // eax
  char v8; // cl
  char v9; // al
  unsigned __int64 v10; // rdi
  __int64 v11; // r12
  _DWORD *v12; // r12
  __int64 v13; // rdi
  __int64 v14; // r12
  int v15; // eax
  __int64 v16; // rax
  __int64 v17; // r12
  unsigned __int64 v18; // r15
  unsigned __int64 v19; // r12
  unsigned __int64 v20; // r13
  __int64 v21; // rax
  __int64 v22; // rdx
  unsigned int v23; // eax
  int v24; // eax
  __int64 v25; // rax
  _BYTE v26[4096]; // [rsp+0h] [rbp-1030h] BYREF

  LODWORD(v2) = -300; /*0x10316a3ec*/
  if ( *(_QWORD *)(a2 + 32) > *(_QWORD *)(a2 + 8) ) /*0x10316a3f6*/
    return (unsigned int)v2; /*0x10316a3f6*/
  v6 = *(_DWORD *)(a1 + 4216); /*0x10316a427*/
  if ( v6 != 2 ) /*0x10316a430*/
  {
    if ( v6 == 1 ) /*0x10316a439*/
    {
LABEL_16:
      v13 = *(_QWORD *)(a1 + 4176); /*0x10316a55f*/
      v14 = *(_QWORD *)(a1 + 4184) - v13; /*0x10316a56d*/
      v15 = (*(__int64 (__fastcall **)(__int64, __int64, bool, _QWORD))(a1 + 4224))( /*0x10316a584*/
              a1: v13,
              a2: v14,
              a3: *(_QWORD *)(a2 + 32) != 0,
              a4: *(_QWORD *)(a1 + 4248));
      LODWORD(v2) = -101; /*0x10316a58a*/
      if ( v15 <= 0 ) /*0x10316a592*/
        return (unsigned int)v2; /*0x10316a592*/
      LODWORD(v2) = -301; /*0x10316a59a*/
      if ( v14 < (unsigned int)v15 ) /*0x10316a5a3*/
        return (unsigned int)v2; /*0x10316a5a3*/
      v16 = *(_QWORD *)(a1 + 4176) + (unsigned int)v15; /*0x10316a5a9*/
      *(_QWORD *)(a1 + 4176) = v16; /*0x10316a5b0*/
      LODWORD(v2) = -101; /*0x10316a5b7*/
      if ( v16 != *(_QWORD *)(a1 + 4184) ) /*0x10316a5c4*/
        return (unsigned int)v2; /*0x10316a5c4*/
      *(_DWORD *)(a1 + 4216) = 2; /*0x10316a5ca*/
      goto LABEL_20; /*0x10316a5ca*/
    }
    if ( v6 != 0 ) /*0x10316a441*/
      return (unsigned int)v2; /*0x10316a441*/
    *(_QWORD *)(a1 + 4166) = 0; /*0x10316a445*/
    *(_QWORD *)(a1 + 4160) = 0; /*0x10316a44c*/
    v7 = (unsigned __int8)(*(_BYTE *)a2 << 7); /*0x10316a456*/
    *(_BYTE *)(a1 + 4160) = v7; /*0x10316a459*/
    v8 = v7 | (16 * *(_BYTE *)(a2 + 1)) & 0x70; /*0x10316a469*/
    *(_BYTE *)(a1 + 4160) = v8; /*0x10316a46b*/
    *(_BYTE *)(a1 + 4160) = v8 | *(_BYTE *)(a2 + 2) & 0xF; /*0x10316a479*/
    v9 = *(_BYTE *)(a1 + 4161) | (*(_BYTE *)(a2 + 16) << 7); /*0x10316a486*/
    *(_BYTE *)(a1 + 4161) = v9; /*0x10316a48c*/
    v10 = *(_QWORD *)(a2 + 8); /*0x10316a497*/
    if ( (*(_BYTE *)(a2 + 2) & 8) != 0 ) /*0x10316a49b*/
    {
      if ( v10 > 0x7D ) /*0x10316a4cf*/
        return (unsigned int)v2; /*0x10316a4cf*/
    }
    else if ( v10 > 0x7D ) /*0x10316a4a1*/
    {
      if ( v10 > 0xFFFF ) /*0x10316a4aa*/
      {
        if ( (v10 & 0x8000000000000000LL) != 0LL ) /*0x10316a6f3*/
          return (unsigned int)v2; /*0x10316a6f3*/
        v25 = wslay_byteswap64(); /*0x10316a6f9*/
        *(_BYTE *)(a1 + 4161) |= 0x7Fu; /*0x10316a6fe*/
        *(_QWORD *)(a1 + 4162) = v25; /*0x10316a705*/
        v11 = 4170; /*0x10316a70c*/
      }
      else
      {
        *(_BYTE *)(a1 + 4161) = v9 | 0x7E; /*0x10316a4b6*/
        *(_WORD *)(a1 + 4162) = __ROL2__(v10, 8); /*0x10316a4bc*/
        v11 = 4164; /*0x10316a4c3*/
      }
      goto LABEL_12; /*0x10316a4c9*/
    }
    *(_BYTE *)(a1 + 4161) = v10 | v9; /*0x10316a4d8*/
    v11 = 4162; /*0x10316a4de*/
LABEL_12:
    v12 = (_DWORD *)(a1 + v11); /*0x10316a4e4*/
    if ( *(_BYTE *)(a2 + 16) != 0 ) /*0x10316a4ec*/
    {
      LODWORD(v2) = -301; /*0x10316a507*/
      if ( (*(unsigned int (__fastcall **)(__int64, __int64, _QWORD))(a1 + 4240))( /*0x10316a50f*/
             a1: a1 + 4209,
             a2: 4,
             a3: *(_QWORD *)(a1 + 4248)) != 0 )
        return (unsigned int)v2; /*0x10316a50f*/
      *(_BYTE *)(a1 + 4208) = 1; /*0x10316a515*/
      *v12++ = *(_DWORD *)(a1 + 4209); /*0x10316a522*/
    }
    *(_DWORD *)(a1 + 4216) = 1; /*0x10316a531*/
    *(_QWORD *)(a1 + 4176) = a1 + 4160; /*0x10316a53b*/
    *(_QWORD *)(a1 + 4184) = v12; /*0x10316a542*/
    *(_QWORD *)(a1 + 4192) = *(_QWORD *)(a2 + 8); /*0x10316a54d*/
    *(_QWORD *)(a1 + 4200) = 0; /*0x10316a554*/
    goto LABEL_16; /*0x10316a554*/
  }
LABEL_20:
  v17 = *(_QWORD *)(a2 + 32); /*0x10316a5d4*/
  if ( v17 == 0 ) /*0x10316a5db*/
  {
LABEL_33:
    LODWORD(v2) = 0; /*0x10316a692*/
    goto LABEL_34; /*0x10316a692*/
  }
  if ( *(_BYTE *)(a1 + 4208) != 0 ) /*0x10316a5e8*/
  {
    if ( v17 > 0 ) /*0x10316a5f1*/
    {
      v18 = *(_QWORD *)(a2 + 24); /*0x10316a5f7*/
      v19 = v18 + v17; /*0x10316a5fb*/
      v2 = 0; /*0x10316a5fe*/
      while ( 1 ) /*0x10316a604*/
      {
        v20 = v19 - v18; /*0x10316a604*/
        if ( v19 - v18 >= 0x1000 ) /*0x10316a60f*/
          v20 = 4096; /*0x10316a60f*/
        if ( v19 != v18 ) /*0x10316a616*/
        {
          v21 = *(_QWORD *)(a1 + 4200); /*0x10316a618*/
          v22 = 0; /*0x10316a62a*/
          do /*0x10316a64c*/
          {
            v26[v22] = *(_BYTE *)(v18 + v22) ^ *(_BYTE *)(a1 + (((_BYTE)v21 + (_BYTE)v22) & 3) + 4209); /*0x10316a63e*/
            ++v22; /*0x10316a646*/
          }
          while ( (v20 == 0) + v20 != v22 ); /*0x10316a64c*/
        }
        v23 = (*(__int64 (__fastcall **)(_BYTE *, unsigned __int64, _QWORD, _QWORD))(a1 + 4224))( /*0x10316a661*/
                a1: v26,
                a2: v20,
                a3: 0,
                a4: *(_QWORD *)(a1 + 4248));
        if ( (int)v23 <= 0 ) /*0x10316a669*/
          break; /*0x10316a669*/
        if ( v20 < v23 ) /*0x10316a674*/
        {
          LODWORD(v2) = -301; /*0x10316a72b*/
          return (unsigned int)v2; /*0x10316a731*/
        }
        *(_QWORD *)(a1 + 4200) += v23; /*0x10316a67a*/
        v18 += v23; /*0x10316a681*/
        v2 += v23; /*0x10316a684*/
        if ( v18 >= v19 ) /*0x10316a68a*/
          goto LABEL_34; /*0x10316a68a*/
      }
      if ( v2 != 0 ) /*0x10316a71a*/
        goto LABEL_34; /*0x10316a71a*/
      goto LABEL_42; /*0x10316a71a*/
    }
    goto LABEL_33; /*0x10316a5f1*/
  }
  v24 = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD, _QWORD))(a1 + 4224))( /*0x10316a6c8*/
          a1: *(_QWORD *)(a2 + 24),
          a2: *(_QWORD *)(a2 + 32),
          a3: 0,
          a4: *(_QWORD *)(a1 + 4248));
  if ( v24 <= 0 ) /*0x10316a6d0*/
  {
LABEL_42:
    LODWORD(v2) = -101; /*0x10316a720*/
    return (unsigned int)v2; /*0x10316a726*/
  }
  LODWORD(v2) = -301; /*0x10316a6d4*/
  if ( *(_QWORD *)(a2 + 32) < (unsigned __int64)(unsigned int)v24 ) /*0x10316a6de*/
    return (unsigned int)v2; /*0x10316a6de*/
  *(_QWORD *)(a1 + 4200) += (unsigned int)v24; /*0x10316a6e4*/
  LODWORD(v2) = v24; /*0x10316a6eb*/
LABEL_34:
  if ( *(_QWORD *)(a1 + 4200) == *(_QWORD *)(a1 + 4192) ) /*0x10316a6a3*/
    *(_DWORD *)(a1 + 4216) = 0; /*0x10316a6a9*/
  return (unsigned int)v2; /*0x10316a40f*/
}

// Address: 0x10316a73b | Name: _wslay_frame_recv
__int64 __fastcall wslay_frame_recv(char *__dst, __int64 a2)
{
  __int64 result; // rax
  char *v5; // rcx
  unsigned __int64 v6; // rdx
  unsigned __int64 v7; // rsi
  char v8; // si
  char v9; // al
  char v10; // dl
  char v11; // dl
  __int64 v12; // rdi
  __int64 v13; // rax
  const void *v14; // rsi
  size_t v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rax
  char *v18; // rdx
  unsigned __int64 v19; // rax
  char *v20; // rcx
  unsigned __int64 v21; // r15
  char *v22; // rax
  char v23; // si
  signed __int64 v24; // rcx
  char *v25; // rsi
  __int64 v26; // rcx
  __int64 v27; // rdi

  result = 4294966996LL; /*0x10316a74b*/
  switch ( *((_DWORD *)__dst + 1036) ) /*0x10316a770*/
  {
    case 3: /*0x10316a770*/
      v5 = *((char **)__dst + 512); /*0x10316a772*/
      v6 = *((_QWORD *)__dst + 513) - (_QWORD)v5; /*0x10316a780*/
      v7 = *((_QWORD *)__dst + 519); /*0x10316a783*/
      if ( v6 < v7 ) /*0x10316a78d*/
      {
        result = wslay_recv(__dst); /*0x10316a792*/
        if ( (int)result <= 0 ) /*0x10316a799*/
          return result; /*0x10316a799*/
        v5 = *((char **)__dst + 512); /*0x10316a79f*/
        v7 = *((_QWORD *)__dst + 519); /*0x10316a7ad*/
        v6 = *((_QWORD *)__dst + 513) - (_QWORD)v5; /*0x10316a7b4*/
      }
      result = 4294967196LL; /*0x10316a7b7*/
      if ( v6 < v7 ) /*0x10316a7bf*/
        return result; /*0x10316a7bf*/
      v8 = *v5; /*0x10316a7c5*/
      v9 = (unsigned __int8)*v5 >> 7; /*0x10316a7ca*/
      v10 = ((unsigned __int8)*v5 >> 4) & 7; /*0x10316a7d2*/
      __dst[4113] = *v5 & 0xF; /*0x10316a7db*/
      __dst[4112] = v9; /*0x10316a7e2*/
      __dst[4114] = v10; /*0x10316a7e8*/
      *((_QWORD *)__dst + 512) = v5 + 1; /*0x10316a7f2*/
      v11 = v5[1]; /*0x10316a7f9*/
      __dst[4136] = (unsigned __int8)v11 >> 7; /*0x10316a801*/
      v12 = v5[1] & 0x7F; /*0x10316a80b*/
      *((_QWORD *)__dst + 512) = v5 + 2; /*0x10316a812*/
      if ( (v8 & 8) != 0 ) /*0x10316a81d*/
      {
        result = 4294967096LL; /*0x10316a81f*/
        if ( v8 >= 0 || (unsigned __int8)v12 > 0x7Du ) /*0x10316a831*/
          return result; /*0x10316a831*/
      }
      if ( (_BYTE)v12 == 126 ) /*0x10316a83b*/
      {
        v13 = 2; /*0x10316a851*/
        goto LABEL_13; /*0x10316a851*/
      }
      if ( (unsigned __int8)v12 == 127 ) /*0x10316a844*/
      {
        v13 = 8; /*0x10316a84a*/
LABEL_13:
        *((_DWORD *)__dst + 1036) = 5; /*0x10316a856*/
        *((_QWORD *)__dst + 519) = v13; /*0x10316a860*/
        goto LABEL_14; /*0x10316a860*/
      }
      *((_QWORD *)__dst + 515) = v12; /*0x10316a956*/
      *((_QWORD *)__dst + 516) = 0; /*0x10316a95d*/
      if ( v11 < 0 ) /*0x10316a96a*/
      {
        *((_DWORD *)__dst + 1036) = 6; /*0x10316a982*/
        *((_QWORD *)__dst + 519) = 4; /*0x10316a98c*/
LABEL_27:
        v18 = *((char **)__dst + 512); /*0x10316a997*/
        v19 = *((_QWORD *)__dst + 519); /*0x10316a99e*/
LABEL_28:
        if ( *((_QWORD *)__dst + 513) - (_QWORD)v18 < v19 ) /*0x10316a9b2*/
        {
          result = wslay_recv(__dst); /*0x10316a9b7*/
          if ( (int)result <= 0 ) /*0x10316a9be*/
            return result; /*0x10316a9be*/
          v18 = *((char **)__dst + 512); /*0x10316a9c4*/
          result = 4294967196LL; /*0x10316a9d5*/
          if ( *((_QWORD *)__dst + 513) - (_QWORD)v18 < *((_QWORD *)__dst + 519) ) /*0x10316a9e1*/
            return result; /*0x10316a9e1*/
        }
        *(_DWORD *)(__dst + 4137) = *(_DWORD *)v18; /*0x10316a9e9*/
        v18 += 4; /*0x10316a9ef*/
        *((_QWORD *)__dst + 512) = v18; /*0x10316a9f3*/
LABEL_32:
        *((_DWORD *)__dst + 1036) = 7; /*0x10316a9fa*/
      }
      else
      {
        *((_DWORD *)__dst + 1036) = 7; /*0x10316a96c*/
LABEL_25:
        v18 = *((char **)__dst + 512); /*0x10316a976*/
      }
      v20 = *((char **)__dst + 513); /*0x10316aa04*/
      v21 = *((_QWORD *)__dst + 515) - *((_QWORD *)__dst + 516); /*0x10316aa18*/
      if ( v20 == v18 && *((_QWORD *)__dst + 515) != *((_QWORD *)__dst + 516) ) /*0x10316aa1f*/
      {
        result = wslay_recv(__dst); /*0x10316aa2f*/
        if ( (int)result <= 0 ) /*0x10316aa36*/
          return result; /*0x10316aa36*/
        v18 = *((char **)__dst + 512); /*0x10316aa3c*/
        v20 = *((char **)__dst + 513); /*0x10316aa43*/
      }
      v22 = &v18[v21]; /*0x10316aa50*/
      if ( v20 - v18 < v21 ) /*0x10316aa57*/
        v22 = v20; /*0x10316aa57*/
      v23 = __dst[4136]; /*0x10316aa5b*/
      if ( v23 != 0 ) /*0x10316aa65*/
      {
        v24 = *((_QWORD *)__dst + 516); /*0x10316aa67*/
        if ( v18 == v22 ) /*0x10316aa71*/
        {
          v22 = v18; /*0x10316aad1*/
        }
        else
        {
          v25 = v18; /*0x10316aa73*/
          do /*0x10316aaa7*/
          {
            *v25 ^= __dst[(v24 & 3) + 4137]; /*0x10316aa80*/
            v26 = *((_QWORD *)__dst + 516); /*0x10316aa89*/
            v25 = (char *)(*((_QWORD *)__dst + 512) + 1LL); /*0x10316aa90*/
            *((_QWORD *)__dst + 512) = v25; /*0x10316aa93*/
            v24 = v26 + 1; /*0x10316aa9a*/
            *((_QWORD *)__dst + 516) = v24; /*0x10316aa9d*/
          }
          while ( v25 != v22 ); /*0x10316aaa7*/
          v23 = __dst[4136]; /*0x10316aaa9*/
        }
      }
      else
      {
        *((_QWORD *)__dst + 512) = v22; /*0x10316aab2*/
        v24 = *((_QWORD *)__dst + 516) + v22 - v18; /*0x10316aabf*/
        *((_QWORD *)__dst + 516) = v24; /*0x10316aac6*/
        v23 = 0; /*0x10316aacd*/
      }
      *(_BYTE *)a2 = __dst[4112]; /*0x10316aadb*/
      *(_BYTE *)(a2 + 1) = __dst[4114]; /*0x10316aae5*/
      *(_BYTE *)(a2 + 2) = __dst[4113]; /*0x10316aaf0*/
      v27 = *((_QWORD *)__dst + 515); /*0x10316aaf4*/
      *(_QWORD *)(a2 + 8) = v27; /*0x10316aafb*/
      *(_BYTE *)(a2 + 16) = v23; /*0x10316aaff*/
      *(_QWORD *)(a2 + 24) = v18; /*0x10316ab03*/
      result = v22 - v18; /*0x10316ab07*/
      *(_QWORD *)(a2 + 32) = result; /*0x10316ab0a*/
      if ( v27 == v24 ) /*0x10316ab11*/
      {
        *((_DWORD *)__dst + 1036) = 3; /*0x10316ab13*/
        *((_QWORD *)__dst + 519) = 2; /*0x10316ab1d*/
      }
      return result; /*0x10316ab2c*/
    case 5: /*0x10316a770*/
LABEL_14:
      v14 = *((const void **)__dst + 512); /*0x10316a867*/
      v15 = *((_QWORD *)__dst + 519); /*0x10316a878*/
      if ( *((_QWORD *)__dst + 513) - (_QWORD)v14 < v15 ) /*0x10316a882*/
      {
        result = wslay_recv(__dst); /*0x10316a887*/
        if ( (int)result <= 0 ) /*0x10316a88e*/
          return result; /*0x10316a88e*/
        v14 = *((const void **)__dst + 512); /*0x10316a894*/
        v15 = *((_QWORD *)__dst + 519); /*0x10316a8a5*/
        result = 4294967196LL; /*0x10316a8ac*/
        if ( *((_QWORD *)__dst + 513) - (_QWORD)v14 < v15 ) /*0x10316a8b4*/
          return result; /*0x10316a8b4*/
      }
      *(_OWORD *)(__dst + 4120) = 0; /*0x10316a8cb*/
      memcpy(__dst: &__dst[-v15 + 4128], __src: v14, __n: v15); /*0x10316a8d2*/
      v16 = wslay_byteswap64(a1: *((_QWORD *)__dst + 515)); /*0x10316a8e3*/
      *((_QWORD *)__dst + 515) = v16; /*0x10316a8e6*/
      v17 = *((_QWORD *)__dst + 519); /*0x10316a8ed*/
      v18 = (char *)(v17 + *((_QWORD *)__dst + 512)); /*0x10316a8fb*/
      *((_QWORD *)__dst + 512) = v18; /*0x10316a8fe*/
      if ( v17 == 8 ) /*0x10316a909*/
      {
        result = 4294967096LL; /*0x10316a90b*/
        if ( v16 <= 0xFFFF ) /*0x10316a917*/
          return result; /*0x10316a917*/
      }
      else
      {
        result = 4294967096LL; /*0x10316a91e*/
        if ( (unsigned __int64)v16 < 0x7E ) /*0x10316a927*/
          return result; /*0x10316a927*/
      }
      if ( __dst[4136] == 0 ) /*0x10316a934*/
        goto LABEL_32; /*0x10316a934*/
      *((_DWORD *)__dst + 1036) = 6; /*0x10316a93a*/
      *((_QWORD *)__dst + 519) = 4; /*0x10316a944*/
      v19 = 4; /*0x10316a94f*/
      goto LABEL_28; /*0x10316a954*/
    case 6: /*0x10316a770*/
      goto LABEL_27;
    case 7: /*0x10316a770*/
      goto LABEL_25;
    default:
      return result;
  }
}

// Address: 0x10316ab48 | Name: _wslay_recv
__int64 __fastcall wslay_recv(char *__dst)
{
  char *v2; // r14
  char *v3; // rsi
  char *v4; // r15
  size_t v5; // r15
  __int64 result; // rax

  v2 = __dst + 4096; /*0x10316ab55*/
  v3 = *((char **)__dst + 512); /*0x10316ab5c*/
  v4 = *((char **)__dst + 513); /*0x10316ab63*/
  if ( v3 != __dst ) /*0x10316ab6d*/
  {
    v5 = v4 - v3; /*0x10316ab6f*/
    memmove(__dst, __src: v3, __len: v5); /*0x10316ab78*/
    v4 = &__dst[v5]; /*0x10316ab7d*/
    *((_QWORD *)__dst + 513) = v4; /*0x10316ab80*/
    *((_QWORD *)__dst + 512) = __dst; /*0x10316ab87*/
  }
  result = (*((__int64 (__fastcall **)(char *, signed __int64, _QWORD, _QWORD))__dst + 529))( /*0x10316aba0*/
             a1: v4,
             a2: v2 - v4,
             a3: 0,
             a4: *((_QWORD *)__dst + 531));
  if ( (int)result <= 0 ) /*0x10316aba8*/
    return 4294967196LL; /*0x10316abb5*/
  *((_QWORD *)__dst + 513) += (unsigned int)result; /*0x10316abac*/
  return result; /*0x10316abbe*/
}

// Address: 0x10316abc5 | Name: _wslay_byteswap64
unsigned __int64 __fastcall wslay_byteswap64(unsigned __int64 a1)
{
  return _byteswap_uint64(a1); /*0x10316abcf*/
}

// Address: 0x10316abd1 | Name: _wslay_queue_new
_OWORD *wslay_queue_new()
{
  _OWORD *result; // rax

  result = (_OWORD *)RBX_wslay_malloc(this: (RBX::Memory *)0x10); /*0x10316abda*/
  if ( result != nullptr ) /*0x10316abe2*/
    *result = 0; /*0x10316abe7*/
  return result; /*0x10316abea*/
}

// Address: 0x10316abec | Name: _wslay_queue_free
__int64 __fastcall wslay_queue_free(__int64 *a1)
{
  unsigned int v1; // ebx
  __int64 v2; // rdi
  __int64 v3; // r14
  __int64 result; // rax

  if ( a1 != nullptr ) /*0x10316abef*/
  {
    v1 = (unsigned int)a1; /*0x10316abf8*/
    v2 = *a1; /*0x10316abfb*/
    if ( v2 != 0 ) /*0x10316ac01*/
    {
      do /*0x10316ac12*/
      {
        v3 = *(_QWORD *)(v2 + 8); /*0x10316ac03*/
        RBX_wslay_free(a1: v2); /*0x10316ac07*/
        v2 = v3; /*0x10316ac0c*/
      }
      while ( v3 != 0 ); /*0x10316ac12*/
    }
    return RBX_wslay_free(a1: v1); /*0x10316ac1b*/
  }
  return result; /*0x10316ac20*/
}

// Address: 0x10316ac21 | Name: _wslay_queue_push
__int64 __fastcall wslay_queue_push(__int64 a1, __int64 a2)
{
  _QWORD *v4; // rax
  __int64 v5; // rcx
  __int64 v6; // rdx
  bool v7; // zf

  v4 = (_QWORD *)RBX_wslay_malloc(this: (RBX::Memory *)0x10); /*0x10316ac33*/
  if ( v4 == nullptr ) /*0x10316ac3b*/
    return 4294966796LL; /*0x10316ac64*/
  *v4 = a2; /*0x10316ac3d*/
  v4[1] = 0; /*0x10316ac40*/
  v5 = *(_QWORD *)(a1 + 8); /*0x10316ac48*/
  v6 = 0; /*0x10316ac4c*/
  v7 = v5 == 0; /*0x10316ac4e*/
  if ( v5 == 0 ) /*0x10316ac51*/
    v5 = a1; /*0x10316ac51*/
  LOBYTE(v6) = !v7; /*0x10316ac55*/
  *(_QWORD *)(v5 + 8) = v4; /*0x10316ac58*/
  *(_QWORD *)(a1 + 8 * v6) = v4; /*0x10316ac5c*/
  return 0; /*0x10316ac69*/
}

// Address: 0x10316ac6e | Name: _wslay_queue_push_front
__int64 __fastcall wslay_queue_push_front(_QWORD *a1, __int64 a2)
{
  _QWORD *v4; // rax
  _QWORD *v5; // rcx
  __int64 result; // rax

  v4 = (_QWORD *)RBX_wslay_malloc(this: (RBX::Memory *)0x10); /*0x10316ac80*/
  if ( v4 == nullptr ) /*0x10316ac88*/
    return 4294966796LL; /*0x10316aca9*/
  v5 = v4; /*0x10316ac8a*/
  *v4 = a2; /*0x10316ac8d*/
  v4[1] = *a1; /*0x10316ac93*/
  *a1 = v4; /*0x10316ac97*/
  result = 0; /*0x10316ac9a*/
  if ( a1[1] == 0 ) /*0x10316aca1*/
    a1[1] = v5; /*0x10316aca3*/
  return result; /*0x10316acae*/
}

// Address: 0x10316acb3 | Name: _wslay_queue_pop
__int64 __fastcall wslay_queue_pop(__int64 *a1)
{
  __int64 v2; // rdi

  v2 = *a1; /*0x10316acba*/
  *a1 = *(_QWORD *)(v2 + 8); /*0x10316acc1*/
  if ( v2 == a1[1] ) /*0x10316acc8*/
    a1[1] = 0; /*0x10316acca*/
  return RBX_wslay_free(a1: v2); /*0x10316acd2*/
}

// Address: 0x10316acd8 | Name: _wslay_queue_top
__int64 __fastcall wslay_queue_top(__int64 a1)
{
  return **(_QWORD **)a1; /*0x10316ace2*/
}

// Address: 0x10316ace4 | Name: _wslay_queue_tail
__int64 __fastcall wslay_queue_tail(__int64 a1)
{
  return **(_QWORD **)(a1 + 8); /*0x10316acef*/
}

// Address: 0x10316acf1 | Name: _wslay_queue_empty
_BOOL8 __fastcall wslay_queue_empty(_QWORD *a1)
{
  return *a1 == 0; /*0x10316acfe*/
}

// Address: 0x10345963a | Name: _Write_CVT_Stretched
__int64 __fastcall Write_CVT_Stretched(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  __int64 v7; // rax

  result = Modify_CVT_Check(a1); /*0x10345964d*/
  if ( *(_DWORD *)(a1 + 32) == 0 ) /*0x103459657*/
  {
    v7 = Current_Ratio(a1); /*0x10345965c*/
    result = FT_DivFix(a1: a3, a2: v7); /*0x103459667*/
    *(_QWORD *)(*(_QWORD *)(a1 + 632) + 8 * a2) = result; /*0x103459673*/
  }
  return result; /*0x10345967b*/
}

// Address: 0x1034596f5 | Name: _Write_CVT
__int64 __fastcall Write_CVT(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax

  result = Modify_CVT_Check(a1); /*0x103459708*/
  if ( *(_DWORD *)(a1 + 32) == 0 ) /*0x103459712*/
  {
    result = *(_QWORD *)(a1 + 632); /*0x103459714*/
    *(_QWORD *)(result + 8 * a2) = a3; /*0x10345971b*/
  }
  return result; /*0x103459723*/
}

// Address: 0x1034647d3 | Name: _winfnt_get_service
__int64 winfnt_get_service()
{
  return ft_service_list_lookup(a1: winfnt_services); /*0x1034647de*/
}

// Address: 0x103465622 | Name: _winfnt_get_header
__int64 __fastcall winfnt_get_header(__int64 a1, void *a2)
{
  memcpy(__dst: a2, __src: (const void *)(*(_QWORD *)(a1 + 248) + 8LL), __n: 0xD0u); /*0x10346563c*/
  return 0; /*0x103465643*/
}

// Address: 0x103541038 | Name: _write_extension_payload
__int64 __fastcall write_extension_payload(__int64 a1, int a2, int a3, __int64 a4, int a5)
{
  unsigned int v6; // eax
  unsigned int v7; // ebx
  int v8; // ecx
  __int64 result; // rax
  unsigned int v10; // r9d
  __int64 v11; // rax

  v6 = *(_DWORD *)a4; /*0x103541042*/
  if ( (unsigned int)(*(_DWORD *)a4 - 3) >= 0x7D )
    celt_fatal(a1: "assertion failed: ext->id >= 3 && ext->id <= 127", a2: "extensions.c", a3: 410);
  v7 = a3; /*0x103541050*/
  v8 = *(_DWORD *)(a4 + 16); /*0x103541052*/
  if ( v6 > 0x1F ) /*0x103541059*/
  {
    if ( v8 < 0 ) /*0x103541096*/
    {
      return 0xFFFFFFFFLL; /*0x103541161*/
    }
    else
    {
      v10 = 0; /*0x1035410ad*/
      if ( a5 == 0 ) /*0x1035410b3*/
        v10 = v8 / 0xFFu + 1; /*0x1035410b3*/
      result = 4294967294LL; /*0x1035410bc*/
      if ( a2 - a3 >= (int)(v8 + v10) ) /*0x1035410c4*/
      {
        if ( a5 == 0 ) /*0x1035410cd*/
        {
          if ( (unsigned int)v8 >= 0xFF ) /*0x1035410d5*/
          {
            v11 = 0; /*0x1035410dd*/
            do /*0x10354110f*/
            {
              if ( a1 != 0 ) /*0x1035410e2*/
              {
                *(_BYTE *)(a1 + a3 + v11) = -1; /*0x1035410e4*/
                v8 = *(_DWORD *)(a4 + 16); /*0x1035410e8*/
              }
              ++v11; /*0x10354110a*/
            }
            while ( (int)v11 < v8 / 255 ); /*0x10354110f*/
            v7 = v11 + a3; /*0x103541111*/
          }
          if ( a1 != 0 ) /*0x103541116*/
          {
            *(_BYTE *)(a1 + (int)v7) = v8 + v8 / -16777216; /*0x103541137*/
            v8 = *(_DWORD *)(a4 + 16); /*0x10354113a*/
          }
          ++v7; /*0x10354113e*/
        }
        if ( a1 != 0 ) /*0x103541143*/
        {
          memcpy(__dst: (void *)((int)v7 + a1), __src: *(const void **)(a4 + 8), __n: v8); /*0x103541152*/
          v8 = *(_DWORD *)(a4 + 16); /*0x103541157*/
        }
        return v7 + v8; /*0x10354115d*/
      }
    }
  }
  else
  {
    result = 0xFFFFFFFFLL; /*0x10354105b*/
    if ( (unsigned int)v8 <= 1 ) /*0x103541063*/
    {
      if ( v8 == 0 ) /*0x10354106b*/
        return v7; /*0x10354108f*/
      result = 4294967294LL; /*0x10354106d*/
      if ( a2 > a3 ) /*0x103541074*/
      {
        if ( a1 != 0 ) /*0x10354107d*/
          *(_BYTE *)(a1 + a3) = **(_BYTE **)(a4 + 8); /*0x103541088*/
        return (unsigned int)(a3 + 1); /*0x10354108b*/
      }
    }
  }
  return result; /*0x103541166*/
}

// Address: 0x10374d798 | Name: _worker
__int64 __fastcall worker(__int64 a1)
{
  _QWORD *v1; // r14
  bool v2; // r13
  __int64 *v3; // rax
  __int64 v4; // rax
  __int64 v5; // rax
  _QWORD *v6; // rax
  _QWORD *v7; // rax

  uv_sem_post(a1); /*0x10374d7a6*/
  uv_mutex_lock(a1: &mutex); /*0x10374d7b5*/
  while ( 1 ) /*0x10374d7e4*/
  {
    while ( 1 ) /*0x10374d7c8*/
    {
      v1 = (_QWORD *)wq; /*0x10374d7c8*/
      if ( (__int64 *)wq != &wq ) /*0x10374d7d2*/
      {
        v2 = wq == (_QWORD)&run_slow_work_message; /*0x10374d7d7*/
        if ( (__int64 *)wq != &run_slow_work_message || (__int64 *)run_slow_work_message != &wq ) /*0x10374d7e4*/
          break; /*0x10374d7e4*/
        v2 = true; /*0x10374d7f0*/
        v3 = &wq; /*0x10374d7f3*/
        if ( slow_io_work_running < (unsigned int)(nthreads + 1) >> 1 ) /*0x10374d7fc*/
          goto LABEL_9; /*0x10374d7fc*/
      }
      ++idle_threads; /*0x10374d7fe*/
      uv_cond_wait(a1: &cond, a2: &mutex); /*0x10374d80e*/
      --idle_threads; /*0x10374d813*/
    }
    if ( (_UNKNOWN *)wq == &exit_message ) /*0x10374d825*/
      break; /*0x10374d825*/
    v3 = *(__int64 **)wq; /*0x10374d82b*/
LABEL_9:
    **(_QWORD **)(wq + 8) = v3; /*0x10374d82e*/
    *(_QWORD *)(*v1 + 8LL) = v1[1]; /*0x10374d83c*/
    *v1 = v1; /*0x10374d840*/
    v1[1] = v1; /*0x10374d843*/
    if ( !v2 ) /*0x10374d84a*/
      goto LABEL_15; /*0x10374d84a*/
    if ( slow_io_work_running >= (unsigned int)(nthreads + 1) >> 1 ) /*0x10374d862*/
    {
      run_slow_work_message = (__int64)&wq; /*0x10374d972*/
      v7 = (_QWORD *)qword_10D3130E8; /*0x10374d979*/
      v1[1] = qword_10D3130E8; /*0x10374d980*/
      *v7 = &run_slow_work_message; /*0x10374d984*/
      qword_10D3130E8 = (__int64)&run_slow_work_message; /*0x10374d987*/
    }
    else
    {
      v1 = (_QWORD *)slow_io_pending_wq; /*0x10374d868*/
      if ( (__int64 *)slow_io_pending_wq != &slow_io_pending_wq ) /*0x10374d879*/
      {
        ++slow_io_work_running; /*0x10374d881*/
        v4 = *(_QWORD *)slow_io_pending_wq; /*0x10374d887*/
        **(_QWORD **)(slow_io_pending_wq + 8) = *(_QWORD *)slow_io_pending_wq; /*0x10374d88e*/
        *(_QWORD *)(v4 + 8) = v1[1]; /*0x10374d895*/
        *v1 = v1; /*0x10374d899*/
        v1[1] = v1; /*0x10374d89c*/
        if ( (__int64 *)slow_io_pending_wq != &slow_io_pending_wq ) /*0x10374d8ae*/
        {
          run_slow_work_message = (__int64)&wq; /*0x10374d8b0*/
          qword_10D3130D8 = qword_10D3130E8; /*0x10374d8be*/
          *(_QWORD *)qword_10D3130E8 = &run_slow_work_message; /*0x10374d8c5*/
          qword_10D3130E8 = (__int64)&run_slow_work_message; /*0x10374d8c8*/
          if ( idle_threads != 0 ) /*0x10374d8d6*/
            uv_cond_signal(a1: &cond); /*0x10374d8df*/
        }
LABEL_15:
        uv_mutex_unlock(a1: &mutex); /*0x10374d8e4*/
        ((void (__fastcall *)(_QWORD *))*(v1 - 3))(a1: v1 - 3); /*0x10374d8f0*/
        uv_mutex_lock(a1: *(v1 - 1) + 136LL); /*0x10374d901*/
        *(v1 - 3) = 0; /*0x10374d906*/
        v5 = *(v1 - 1); /*0x10374d90e*/
        *v1 = v5 + 120; /*0x10374d916*/
        v6 = *(_QWORD **)(v5 + 128); /*0x10374d919*/
        v1[1] = v6; /*0x10374d920*/
        *v6 = v1; /*0x10374d924*/
        *(_QWORD *)(*(v1 - 1) + 128LL) = v1; /*0x10374d92b*/
        uv_async_send(a1: *(v1 - 1) + 200LL); /*0x10374d93e*/
        uv_mutex_unlock(a1: *(v1 - 1) + 136LL); /*0x10374d94a*/
        uv_mutex_lock(a1: &mutex); /*0x10374d952*/
        if ( v2 ) /*0x10374d961*/
          --slow_io_work_running; /*0x10374d967*/
      }
    }
  }
  uv_cond_signal(a1: &cond); /*0x10374d99a*/
  return uv_mutex_unlock(a1: &mutex); /*0x10374d9aa*/
}

// Address: 0x1039cefe7 | Name: __ZL24writeRakPeerCapabilitiesRN6RakNet9BitStreamEy
__int64 __fastcall writeRakPeerCapabilities(RakNet::BitStream *this, __int64 a2, __int64 a3, unsigned int a4)
{
  RakNet::BitStream *v6; // rdi
  unsigned __int8 v7[8]; // [rsp+0h] [rbp-20h] BYREF
  unsigned __int8 v8[8]; // [rsp+8h] [rbp-18h] BYREF

  *(_QWORD *)v7 = a2; /*0x1039cf001*/
  if ( (_BYTE)`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r == 0 /*0x1039cf07d*/
    && __cxa_guard_acquire(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r) != 0 )
  {
    RakNet::BitStream::IsNetworkOrder(void)::r = RakNet::BitStream::IsNetworkOrderInternal(this: v6); /*0x1039cf084*/
    __cxa_guard_release(a1: &`guard variable for'RakNet::BitStream::IsNetworkOrder(void)::r); /*0x1039cf091*/
  }
  if ( RakNet::BitStream::IsNetworkOrder(void)::r != 0 ) /*0x1039cf016*/
  {
    RakNet::BitStream::WriteBits(this, a2: v7, a3: 0x40u, a4: true); /*0x1039cf029*/
  }
  else
  {
    RakNet::BitStream::ReverseBytes(this: (RakNet::BitStream *)v7, a2: v8, a3: (unsigned __int8 *)8, a4); /*0x1039cf03d*/
    RakNet::BitStream::WriteBits(this, a2: v8, a3: 0x40u, a4: true); /*0x1039cf053*/
  }
  return __stack_chk_guard; /*0x1039cf068*/
}

// Address: 0x103a45151 | Name: _WebRtc_CreateBuffer
_OWORD *__fastcall WebRtc_CreateBuffer(__int64 a1, __int64 a2)
{
  _OWORD *v4; // rax
  _OWORD *v5; // rbx
  void *v6; // rax

  if ( a1 == 0 || a2 == 0 ) /*0x103a45165*/
    return nullptr; /*0x103a4516a*/
  v4 = malloc(__size: 0x30u); /*0x103a45177*/
  if ( v4 == nullptr ) /*0x103a4517f*/
    return nullptr; /*0x103a4517f*/
  v5 = v4; /*0x103a45181*/
  v6 = malloc(__size: a1 * a2); /*0x103a4518e*/
  *((_QWORD *)v5 + 5) = v6; /*0x103a45193*/
  if ( v6 == nullptr ) /*0x103a4519a*/
  {
    free(a1: v5); /*0x103a451c1*/
    return nullptr; /*0x103a451c6*/
  }
  *((_QWORD *)v5 + 2) = a1; /*0x103a4519c*/
  *((_QWORD *)v5 + 3) = a2; /*0x103a451a0*/
  *((_DWORD *)v5 + 8) = 0; /*0x103a451a4*/
  *v5 = 0; /*0x103a451ae*/
  __bzero(a1: v6, a2: a1 * a2); /*0x103a451b7*/
  return v5; /*0x103a451cb*/
}

// Address: 0x103a451d4 | Name: _WebRtc_InitBuffer
__int64 __fastcall WebRtc_InitBuffer(__int64 a1)
{
  *(_DWORD *)(a1 + 32) = 0; /*0x103a451d8*/
  *(_OWORD *)a1 = 0; /*0x103a451e2*/
  return __bzero(a1: *(_QWORD *)(a1 + 40), a2: *(_QWORD *)(a1 + 16) * *(_QWORD *)(a1 + 24)); /*0x103a451f5*/
}

// Address: 0x103a451fb | Name: _WebRtc_FreeBuffer
void __fastcall WebRtc_FreeBuffer(void **a1)
{
  if ( a1 != nullptr ) /*0x103a451fe*/
  {
    free(a1: a1[5]); /*0x103a4520d*/
    free(a1); /*0x103a4521b*/
  }
}

// Address: 0x103a45221 | Name: _WebRtc_ReadBuffer
unsigned __int64 __fastcall WebRtc_ReadBuffer(__int64 *a1, _QWORD *a2, char *a3, unsigned __int64 a4)
{
  unsigned __int64 v4; // r12
  char *v5; // r15
  __int64 v8; // rsi
  unsigned __int64 v9; // r13
  unsigned __int64 v10; // rax
  __int64 v11; // rax
  char *v12; // rsi
  unsigned __int64 v13; // rbx
  size_t v14; // r13
  size_t v15; // rbx
  _QWORD *v17; // [rsp+8h] [rbp-38h]
  void *__src; // [rsp+10h] [rbp-30h]

  v4 = a4; /*0x103a45232*/
  v5 = a3; /*0x103a45235*/
  if ( a1 != nullptr && a3 != nullptr ) /*0x103a45241*/
  {
    v8 = *a1; /*0x103a45256*/
    if ( *((_DWORD *)a1 + 8) != 0 ) /*0x103a4525d*/
    {
      v9 = a1[2] - v8; /*0x103a45263*/
      v10 = v9 + a1[1]; /*0x103a4526a*/
    }
    else
    {
      v10 = a1[1] - v8; /*0x103a45277*/
      v9 = a1[2] - v8; /*0x103a4527a*/
    }
    if ( v10 < a4 ) /*0x103a45280*/
      v4 = v10; /*0x103a45280*/
    v11 = a1[3]; /*0x103a45284*/
    v12 = (char *)(a1[5] + v11 * v8); /*0x103a45290*/
    v13 = v4 - v9; /*0x103a45296*/
    if ( v4 <= v9 ) /*0x103a45299*/
    {
      v14 = v4 * v11; /*0x103a452dc*/
    }
    else
    {
      v14 = v11 * v9; /*0x103a4529b*/
      v15 = v11 * v13; /*0x103a4529f*/
      if ( v15 != 0 ) /*0x103a452a6*/
      {
        v17 = a2; /*0x103a452ab*/
        __src = (void *)a1[5]; /*0x103a452b2*/
        memcpy(__dst: v5, __src: v12, __n: v14); /*0x103a452b6*/
        memcpy(__dst: &v5[v14], __src, __n: v15); /*0x103a452c8*/
        a2 = v17; /*0x103a452cd*/
        if ( v17 == nullptr ) /*0x103a452d4*/
          goto LABEL_19; /*0x103a452d4*/
        goto LABEL_15; /*0x103a452d4*/
      }
    }
    if ( a2 == nullptr ) /*0x103a452e2*/
    {
      memcpy(__dst: v5, __src: v12, __n: v14); /*0x103a452f9*/
LABEL_19:
      WebRtc_MoveReadPtr(a1, a2: (unsigned int)v4); /*0x103a452fe*/
      return v4; /*0x103a45304*/
    }
    v5 = v12; /*0x103a452e4*/
LABEL_15:
    if ( v4 == 0 ) /*0x103a452ea*/
      v5 = nullptr; /*0x103a452ea*/
    *a2 = v5; /*0x103a452ee*/
    goto LABEL_19; /*0x103a452f1*/
  }
  return 0; /*0x103a4530c*/
}

// Address: 0x103a4531b | Name: _WebRtc_MoveReadPtr
__int64 __fastcall WebRtc_MoveReadPtr(__int64 *a1, unsigned int a2)
{
  __int64 result; // rax
  __int64 v3; // rcx
  __int64 v4; // rdx
  __int64 v5; // rsi
  int v6; // r8d
  int v7; // esi
  int v8; // edx
  int v9; // esi
  int v10; // r8d
  int v11; // esi

  if ( a1 == nullptr ) /*0x103a45322*/
    return 0; /*0x103a4534c*/
  result = a2; /*0x103a45324*/
  v3 = a1[2]; /*0x103a45326*/
  v4 = *a1; /*0x103a4532e*/
  v5 = a1[1]; /*0x103a45331*/
  if ( *((_DWORD *)a1 + 8) != 0 ) /*0x103a45335*/
  {
    v6 = v5 - v4; /*0x103a4533e*/
    v7 = v3 - v4 + v5; /*0x103a45347*/
  }
  else
  {
    v6 = v5 - v4 - v3; /*0x103a45356*/
    v7 = v5 - v4; /*0x103a45359*/
  }
  if ( v7 < (int)result ) /*0x103a4535e*/
    result = (unsigned int)v7; /*0x103a4535e*/
  if ( (int)result <= v6 ) /*0x103a45364*/
    result = (unsigned int)v6; /*0x103a45364*/
  v8 = result + v4; /*0x103a45368*/
  v9 = 0; /*0x103a4536a*/
  if ( v8 > (int)v3 ) /*0x103a4536e*/
    v9 = a1[2]; /*0x103a4536e*/
  v10 = v8 - v9; /*0x103a45374*/
  v11 = v8 - v9 + (v3 & ((v8 - v9) >> 31)); /*0x103a4537f*/
  if ( v8 > (int)v3 || v10 < 0 ) /*0x103a45389*/
    *((_DWORD *)a1 + 8) = (unsigned int)v10 >> 31; /*0x103a4538f*/
  *a1 = v11; /*0x103a45396*/
  return result; /*0x103a45399*/
}

// Address: 0x103a4539b | Name: _WebRtc_WriteBuffer
unsigned __int64 __fastcall WebRtc_WriteBuffer(__int64 *a1, char *a2, unsigned __int64 a3)
{
  unsigned __int64 v4; // r15
  __int64 v7; // rsi
  __int64 v8; // rdx
  __int64 v9; // rdi
  __int64 v10; // rcx
  unsigned __int64 v11; // rdx
  unsigned __int64 v12; // r12

  if ( a1 == nullptr || a2 == nullptr ) /*0x103a453b2*/
    return 0; /*0x103a453b9*/
  v7 = *a1; /*0x103a453c7*/
  v8 = a1[2]; /*0x103a453ca*/
  if ( *((_DWORD *)a1 + 8) != 0 ) /*0x103a453d2*/
  {
    v9 = a1[1]; /*0x103a453da*/
    v10 = v9 + v8 - v7; /*0x103a453de*/
  }
  else
  {
    v9 = a1[1]; /*0x103a453e3*/
    v10 = a1[1] - v7; /*0x103a453ea*/
  }
  v4 = v8 - v10; /*0x103a453f0*/
  if ( v8 - v10 >= a3 ) /*0x103a453f6*/
    v4 = a3; /*0x103a453f6*/
  v11 = v8 - v9; /*0x103a453fa*/
  v12 = v4 - v11; /*0x103a45400*/
  if ( v4 <= v11 ) /*0x103a45403*/
  {
    v12 = v4; /*0x103a45430*/
  }
  else
  {
    memcpy(__dst: (void *)(a1[5] + a1[3] * v9), __src: a2, __n: a1[3] * v11); /*0x103a45418*/
    a1[1] = 0; /*0x103a4541d*/
    *((_DWORD *)a1 + 8) = 1; /*0x103a45425*/
    v9 = 0; /*0x103a4542c*/
  }
  memcpy(__dst: (void *)(a1[5] + a1[3] * v9), __src: &a2[a1[3] * (v4 - v12)], __n: v12 * a1[3]); /*0x103a45453*/
  a1[1] += v12; /*0x103a45458*/
  return v4; /*0x103a4545f*/
}

// Address: 0x103a45468 | Name: _WebRtc_available_write
__int64 __fastcall WebRtc_available_write(__int64 *a1)
{
  __int64 v1; // rdx
  __int64 v2; // rax
  __int64 v3; // rcx

  if ( a1 == nullptr ) /*0x103a4546f*/
    return 0; /*0x103a4548a*/
  v1 = *a1; /*0x103a45471*/
  v2 = a1[2]; /*0x103a45474*/
  if ( *((_DWORD *)a1 + 8) != 0 ) /*0x103a4547c*/
    v3 = a1[1] + v2 - v1; /*0x103a45484*/
  else
    v3 = a1[1] - v1; /*0x103a45492*/
  return v2 - v3; /*0x103a45498*/
}

// Address: 0x103a4549a | Name: _WebRtc_available_read
__int64 __fastcall WebRtc_available_read(__int64 *a1)
{
  __int64 v1; // rcx

  if ( a1 == nullptr ) /*0x103a454a1*/
    return 0; /*0x103a454b9*/
  v1 = *a1; /*0x103a454a7*/
  if ( *((_DWORD *)a1 + 8) != 0 ) /*0x103a454aa*/
    return a1[1] + a1[2] - v1; /*0x103a454b3*/
  else
    return a1[1] - v1; /*0x103a454c1*/
}

// Address: 0x103a454c6 | Name: _WebRtcSpl_ComplexBitReverse
unsigned __int64 __fastcall WebRtcSpl_ComplexBitReverse(__int64 a1, int a2)
{
  int v2; // eax
  char *(__cdecl *v3)(const char *, int); // rcx
  unsigned __int64 result; // rax
  unsigned __int64 i; // rdx
  __int64 v6; // rsi
  int v7; // r8d
  __int64 v8; // r9
  unsigned __int64 v9; // rdx
  unsigned __int64 v10; // rsi
  int v11; // r8d
  int v12; // r8d

  if ( (unsigned int)(a2 - 7) > 1 ) /*0x103a454cc*/
  {
    result = (unsigned int)(1 << a2); /*0x103a45522*/
    if ( (int)result >= 2 ) /*0x103a45527*/
    {
      LODWORD(v9) = 0; /*0x103a4552b*/
      v10 = 1; /*0x103a4552d*/
      do /*0x103a4556e*/
      {
        v11 = result; /*0x103a4553b*/
        do /*0x103a45544*/
          v11 = (unsigned int)v11 >> 1; /*0x103a4553e*/
        while ( v11 > (int)result + ~(_DWORD)v9 ); /*0x103a45544*/
        v9 = v11 + ((unsigned int)v9 & (v11 - 1)); /*0x103a45550*/
        if ( v10 < v9 ) /*0x103a45556*/
        {
          v12 = *(_DWORD *)(a1 + 4 * v10); /*0x103a45558*/
          *(_DWORD *)(a1 + 4 * v10) = *(_DWORD *)(a1 + 4 * v9); /*0x103a45560*/
          *(_DWORD *)(a1 + 4 * v9) = v12; /*0x103a45564*/
        }
        ++v10; /*0x103a45568*/
      }
      while ( v10 != (unsigned int)result ); /*0x103a4556e*/
    }
  }
  else
  {
    v2 = 0; /*0x103a454d2*/
    v3 = index_7; /*0x103a454de*/
    if ( a2 == 8 ) /*0x103a454e5*/
      v3 = index_8; /*0x103a454e5*/
    LOBYTE(v2) = a2 == 8; /*0x103a454e9*/
    result = (unsigned int)(v2 << 7) | 0x70LL; /*0x103a454ef*/
    for ( i = 0; i < result; i += 2LL ) /*0x103a454f3*/
    {
      v6 = *((__int16 *)v3 + i); /*0x103a454f5*/
      v7 = *(_DWORD *)(a1 + 4 * v6); /*0x103a454fa*/
      v8 = *((__int16 *)v3 + i + 1); /*0x103a454fe*/
      *(_DWORD *)(a1 + 4 * v6) = *(_DWORD *)(a1 + 4 * v8); /*0x103a45508*/
      *(_DWORD *)(a1 + 4 * v8) = v7; /*0x103a4550c*/
    }
  }
  return result; /*0x103a4551a*/
}

// Address: 0x103a45571 | Name: _WebRtcSpl_ComplexFFT
__int64 __fastcall WebRtcSpl_ComplexFFT(__int64 a1, char a2, int a3)
{
  int v3; // r14d
  __int64 result; // rax
  __int64 v5; // rax
  __int64 v6; // rdi
  int v7; // edx
  char v8; // cl
  __int64 v9; // rbx
  __int64 v10; // rdx
  __int64 v11; // r13
  __int64 v12; // rdx
  int v13; // r15d
  int v14; // r11d
  int v15; // esi
  int v16; // r9d
  int v17; // edx
  int v18; // r12d
  int v19; // esi
  __int64 v20; // rax
  __int64 v21; // rdi
  int v22; // esi
  char v23; // cl
  __int64 v24; // r11
  __int64 i; // rbx
  __int64 v26; // rsi
  int v27; // r14d
  int v28; // r15d
  __int64 v29; // r12
  int v30; // r13d
  int v31; // r8d
  int v32; // r10d
  int v33; // esi
  __int64 v34; // [rsp+0h] [rbp-40h]
  __int64 v35; // [rsp+0h] [rbp-40h]
  __int64 v36; // [rsp+8h] [rbp-38h]
  int v37; // [rsp+8h] [rbp-38h]
  int v38; // [rsp+10h] [rbp-30h]
  int v39; // [rsp+14h] [rbp-2Ch]

  v3 = 1 << a2; /*0x103a45586*/
  result = 0xFFFFFFFFLL; /*0x103a45589*/
  if ( 1 << a2 <= 1024 ) /*0x103a45595*/
  {
    v38 = 1 << a2; /*0x103a4559d*/
    if ( a3 != 0 ) /*0x103a455a1*/
    {
      if ( v3 >= 2 ) /*0x103a455ab*/
      {
        v5 = (unsigned int)v3; /*0x103a455b1*/
        v6 = a1 + 2; /*0x103a455b4*/
        v7 = 1; /*0x103a455b8*/
        v8 = 9; /*0x103a455bd*/
        do /*0x103a456d0*/
        {
          v39 = 2 * v7; /*0x103a455cb*/
          if ( v7 > 0 ) /*0x103a455d0*/
          {
            v36 = (unsigned int)v7; /*0x103a455dc*/
            v9 = v6 + 4LL * (unsigned int)v7; /*0x103a455e0*/
            v10 = 0; /*0x103a455e4*/
            do /*0x103a456c0*/
            {
              v34 = v10; /*0x103a455e6*/
              if ( v3 > (int)v10 ) /*0x103a455ed*/
              {
                v11 = v10; /*0x103a455f3*/
                v12 = (int)((_DWORD)v10 << v8); /*0x103a455fc*/
                v13 = kSinTable1024[v12 + 256]; /*0x103a45612*/
                v14 = (__int16)-kSinTable1024[v12]; /*0x103a4561b*/
                do /*0x103a456ab*/
                {
                  v15 = *(__int16 *)(v9 + 4 * v11); /*0x103a4562c*/
                  v16 = (v13 * *(__int16 *)(v9 + 4 * v11 - 2) - v15 * v14 + 1) >> 1; /*0x103a4564a*/
                  v17 = (v13 * v15 + v14 * *(__int16 *)(v9 + 4 * v11 - 2) + 1) >> 1; /*0x103a4564d*/
                  v18 = *(__int16 *)(v6 + 4 * v11 - 2) << 14; /*0x103a45655*/
                  v19 = *(__int16 *)(v6 + 4 * v11) << 14; /*0x103a4565e*/
                  *(_WORD *)(v9 + 4 * v11 - 2) = (unsigned int)(v18 + 0x4000 - v16) >> 15; /*0x103a4566c*/
                  *(_WORD *)(v9 + 4 * v11) = (unsigned int)(v19 - v17 + 0x4000) >> 15; /*0x103a4567f*/
                  *(_WORD *)(v6 + 4 * v11 - 2) = (unsigned int)(v18 + v16 + 0x4000) >> 15; /*0x103a45692*/
                  *(_WORD *)(v6 + 4 * v11) = (unsigned int)(v17 + v19 + 0x4000) >> 15; /*0x103a456a0*/
                  v11 += v39; /*0x103a456a5*/
                }
                while ( v11 < v5 ); /*0x103a456ab*/
              }
              v10 = v34 + 1; /*0x103a456b5*/
              v3 = v38; /*0x103a456bc*/
            }
            while ( v34 + 1 != v36 ); /*0x103a456c0*/
          }
          --v8; /*0x103a456c6*/
          v7 = v39; /*0x103a456cb*/
        }
        while ( v39 < v3 ); /*0x103a456d0*/
      }
    }
    else if ( v3 >= 2 ) /*0x103a456df*/
    {
      v20 = (unsigned int)v3; /*0x103a456e5*/
      v21 = a1 + 2; /*0x103a456e8*/
      v22 = 1; /*0x103a456ec*/
      v23 = 9; /*0x103a456f1*/
      do /*0x103a457d4*/
      {
        v37 = 2 * v22; /*0x103a456f9*/
        if ( v22 > 0 ) /*0x103a456fe*/
        {
          v35 = (unsigned int)v22; /*0x103a4570a*/
          v24 = v21 + 4LL * (unsigned int)v22; /*0x103a4570e*/
          for ( i = 0; i != v35; ++i ) /*0x103a45712*/
          {
            if ( v3 > (int)i ) /*0x103a45717*/
            {
              v26 = (int)((_DWORD)i << v23); /*0x103a45721*/
              v27 = kSinTable1024[v26 + 256]; /*0x103a45737*/
              v28 = (__int16)-kSinTable1024[v26]; /*0x103a45740*/
              v29 = i; /*0x103a45744*/
              do /*0x103a457b7*/
              {
                v30 = (v27 * *(__int16 *)(v24 + 4 * v29 - 2) - v28 * *(__int16 *)(v24 + 4 * v29)) >> 15; /*0x103a45762*/
                v31 = (v27 * *(__int16 *)(v24 + 4 * v29) + v28 * *(__int16 *)(v24 + 4 * v29 - 2)) >> 15; /*0x103a45771*/
                v32 = *(__int16 *)(v21 + 4 * v29 - 2); /*0x103a45775*/
                v33 = *(__int16 *)(v21 + 4 * v29); /*0x103a4577b*/
                *(_WORD *)(v24 + 4 * v29 - 2) = (unsigned int)(v32 - v30) >> 1; /*0x103a45788*/
                *(_WORD *)(v24 + 4 * v29) = (unsigned int)(v33 - v31) >> 1; /*0x103a45795*/
                *(_WORD *)(v21 + 4 * v29 - 2) = (unsigned int)(v32 + v30) >> 1; /*0x103a457a0*/
                *(_WORD *)(v21 + 4 * v29) = (unsigned int)(v33 + v31) >> 1; /*0x103a457ac*/
                v29 += v37; /*0x103a457b1*/
              }
              while ( v29 < v20 ); /*0x103a457b7*/
            }
            v3 = v38; /*0x103a457c0*/
          }
        }
        --v23; /*0x103a457ca*/
        v22 = v37; /*0x103a457cf*/
      }
      while ( v37 < v3 ); /*0x103a457d4*/
    }
    return 0; /*0x103a457da*/
  }
  return result; /*0x103a457dc*/
}

// Address: 0x103a457e7 | Name: _WebRtcSpl_ComplexIFFT
__int64 __fastcall WebRtcSpl_ComplexIFFT(__int64 a1, unsigned int a2, int a3)
{
  unsigned __int64 v3; // rbx
  __int64 result; // rax
  __int64 v5; // r14
  __int64 v6; // r12
  int v7; // r15d
  __int16 v8; // ax
  unsigned __int8 v9; // dl
  unsigned __int8 v10; // cl
  int v11; // r9d
  unsigned __int64 v12; // r8
  char v13; // dl
  __int64 v14; // r10
  unsigned __int64 v15; // rax
  unsigned __int64 v16; // r11
  int v17; // eax
  int v18; // edi
  int v19; // esi
  int v20; // r13d
  int v21; // r15d
  int v22; // esi
  int v23; // r12d
  __int64 v24; // r9
  unsigned __int64 v25; // rax
  unsigned __int64 v26; // rdi
  int v27; // eax
  int v28; // esi
  int v29; // r15d
  int v30; // r12d
  int v31; // r11d
  int v32; // ebx
  int v33; // r11d
  int v34; // [rsp+8h] [rbp-78h]
  __int64 v35; // [rsp+10h] [rbp-70h]
  __int64 (__fastcall *v36)(); // [rsp+18h] [rbp-68h]
  unsigned __int64 v37; // [rsp+20h] [rbp-60h]
  int v39; // [rsp+30h] [rbp-50h]
  __int64 v41; // [rsp+38h] [rbp-48h]
  __int64 v42; // [rsp+38h] [rbp-48h]
  int v43; // [rsp+40h] [rbp-40h]
  unsigned __int64 v44; // [rsp+48h] [rbp-38h]
  unsigned __int64 v45; // [rsp+48h] [rbp-38h]

  v3 = 1LL << a2; /*0x103a457ff*/
  result = 0xFFFFFFFFLL; /*0x103a45809*/
  if ( a2 <= 0xA ) /*0x103a45811*/
  {
    if ( a2 != 0 ) /*0x103a45819*/
    {
      v35 = 2LL << a2; /*0x103a45829*/
      v36 = WebRtcSpl_MaxAbsValueW16[0]; /*0x103a45837*/
      v5 = a1 + 2; /*0x103a4583f*/
      v6 = 1; /*0x103a45843*/
      v7 = 9; /*0x103a45849*/
      LODWORD(result) = 0; /*0x103a4584f*/
      v37 = 1LL << a2; /*0x103a45851*/
      do /*0x103a45a81*/
      {
        v34 = result; /*0x103a45855*/
        v8 = ((__int64 (__fastcall *)(__int64, __int64))v36)(a1, a2: v35); /*0x103a45861*/
        v9 = v8 >= 13574; /*0x103a4586c*/
        v10 = v8 >= 27147; /*0x103a45882*/
        v39 = v9; /*0x103a45885*/
        if ( v8 >= 27147 ) /*0x103a4588d*/
          v9 = 2; /*0x103a4588d*/
        v11 = (((v8 >= 13574) << 13) + 0x2000) << v10; /*0x103a45893*/
        v12 = 2 * v6; /*0x103a45896*/
        v43 = v7; /*0x103a4589d*/
        if ( a3 != 0 ) /*0x103a458a5*/
        {
          v13 = v9 + 14; /*0x103a458ab*/
          v14 = v5 + 4 * v6; /*0x103a458b2*/
          v15 = 0; /*0x103a458ba*/
          v41 = (v6 == 0) + v6; /*0x103a458bc*/
          do /*0x103a4598a*/
          {
            v44 = v15; /*0x103a458c0*/
            if ( v15 < v3 ) /*0x103a458c7*/
            {
              v16 = v15; /*0x103a458cd*/
              v17 = kSinTable1024[v15 << v43]; /*0x103a458e2*/
              v18 = kSinTable1024[(v44 << v43) + 256]; /*0x103a458e6*/
              do /*0x103a45976*/
              {
                v19 = *(__int16 *)(v14 + 4 * v16); /*0x103a458fb*/
                v20 = (v18 * *(__int16 *)(v14 + 4 * v16 - 2) - v19 * v17 + 1) >> 1; /*0x103a45918*/
                v21 = (v17 * *(__int16 *)(v14 + 4 * v16 - 2) + v18 * v19 + 1) >> 1; /*0x103a4591b*/
                v22 = *(__int16 *)(v5 + 4 * v16) << 14; /*0x103a4592d*/
                v23 = v11 + (*(__int16 *)(v5 + 4 * v16 - 2) << 14); /*0x103a45930*/
                *(_WORD *)(v14 + 4 * v16 - 2) = (v23 - v20) >> v13; /*0x103a4593d*/
                *(_WORD *)(v14 + 4 * v16) = (v22 + v11 - v21) >> v13; /*0x103a4594d*/
                v3 = v37; /*0x103a45952*/
                *(_WORD *)(v5 + 4 * v16 - 2) = (v20 + v23) >> v13; /*0x103a45965*/
                *(_WORD *)(v5 + 4 * v16) = (v22 + v11 + v21) >> v13; /*0x103a4596b*/
                v16 += v12; /*0x103a45970*/
              }
              while ( v16 < v37 ); /*0x103a45976*/
            }
            v15 = v44 + 1; /*0x103a45980*/
          }
          while ( v44 + 1 != v41 ); /*0x103a4598a*/
        }
        else
        {
          v24 = v5 + 4 * v6; /*0x103a45999*/
          v25 = 0; /*0x103a459a1*/
          v42 = (v6 == 0) + v6; /*0x103a459a3*/
          do /*0x103a45a5e*/
          {
            v45 = v25; /*0x103a459a7*/
            if ( v25 < v3 ) /*0x103a459ae*/
            {
              v26 = v25; /*0x103a459b4*/
              v27 = kSinTable1024[v25 << v43]; /*0x103a459c9*/
              v28 = kSinTable1024[(v45 << v43) + 256]; /*0x103a459cd*/
              do /*0x103a45a4e*/
              {
                v29 = (v28 * *(__int16 *)(v24 + 4 * v26 - 2) - v27 * *(__int16 *)(v24 + 4 * v26)) >> 15; /*0x103a459f1*/
                v30 = *(__int16 *)(v5 + 4 * v26 - 2); /*0x103a459ff*/
                v31 = (v28 * *(__int16 *)(v24 + 4 * v26) + v27 * *(__int16 *)(v24 + 4 * v26 - 2)) >> 15; /*0x103a45a10*/
                v32 = *(__int16 *)(v5 + 4 * v26); /*0x103a45a14*/
                *(_WORD *)(v24 + 4 * v26 - 2) = (v30 - v29) >> v9; /*0x103a45a22*/
                *(_WORD *)(v24 + 4 * v26) = (v32 - v31) >> v9; /*0x103a45a28*/
                v33 = v32 + v31; /*0x103a45a30*/
                v3 = v37; /*0x103a45a33*/
                *(_WORD *)(v5 + 4 * v26 - 2) = (v30 + v29) >> v9; /*0x103a45a3d*/
                *(_WORD *)(v5 + 4 * v26) = v33 >> v9; /*0x103a45a43*/
                v26 += v12; /*0x103a45a48*/
              }
              while ( v26 < v37 ); /*0x103a45a4e*/
            }
            v25 = v45 + 1; /*0x103a45a54*/
          }
          while ( v45 + 1 != v42 ); /*0x103a45a5e*/
        }
        result = (unsigned int)v10 + v39 + v34; /*0x103a45a72*/
        v7 = v43 - 1; /*0x103a45a78*/
        v6 = v12; /*0x103a45a7b*/
      }
      while ( v12 < v3 ); /*0x103a45a81*/
    }
    else
    {
      return 0; /*0x103a45a89*/
    }
  }
  return result; /*0x103a45a8b*/
}

// Address: 0x103a45a9a | Name: _WebRtcSpl_MemSetW16
void __fastcall WebRtcSpl_MemSetW16(__int64 a1, __int16 a2, __int64 a3)
{
  unsigned __int64 v3; // rcx
  __m128i v4; // xmm1
  __m128i v5; // xmm2
  __m128i v6; // xmm3
  __m128i v7; // xmm4
  __m128i si128; // xmm5
  __m128i v9; // xmm0
  __m128i v10; // xmm7
  __m128i v11; // xmm8
  __m128i v12; // xmm10
  __m128i v13; // xmm9
  __m128i v14; // xmm8
  __m128i v15; // xmm10
  __m128i v16; // xmm11
  __m128i v17; // xmm8
  __m128i v18; // xmm8
  __m128i v19; // xmm9
  __m128i v20; // xmm10
  __m128i v21; // xmm8
  __m128i v22; // xmm9
  __m128i v23; // xmm10
  __m128i v24; // xmm11
  __m128i v25; // xmm11
  __m128i v26; // xmm8
  __m128i v27; // xmm8
  __m128i v28; // xmm10
  __m128i v29; // xmm9
  __m128i v30; // xmm8
  __m128i v31; // xmm10
  __m128i v32; // xmm11
  __m128i v33; // xmm8
  __m128i v34; // xmm8
  __m128i v35; // xmm7
  __m128i v36; // xmm9
  __m128i v37; // xmm8
  __m128i v38; // xmm7
  __m128i v39; // xmm9
  __m128i v40; // xmm10
  __m128i v41; // xmm10
  __m128i v42; // xmm7

  if ( a3 != 0 ) /*0x103a45a9d*/
  {
    v3 = 0; /*0x103a45abc*/
    v4 = _mm_cvtepi8_epi64(1798); /*0x103a45abe*/
    v5 = _mm_cvtepi8_epi64(1284); /*0x103a45ac7*/
    v6 = _mm_cvtepi8_epi64(770); /*0x103a45ad0*/
    v7 = _mm_cvtepi8_epi64(256); /*0x103a45ad9*/
    si128 = _mm_load_si128((const __m128i *)&xmmword_108F246C0); /*0x103a45ae2*/
    v9 = _mm_xor_si128(_mm_shuffle_epi32((__m128i)(unsigned __int64)(a3 - 1), 68), si128); /*0x103a45aea*/
    do /*0x103a45d43*/
    {
      v10 = _mm_shuffle_epi32((__m128i)v3, 68); /*0x103a45af7*/
      v11 = _mm_xor_si128(_mm_or_si128(v10, v7), si128); /*0x103a45b06*/
      v12 = _mm_cmpgt_epi32(v11, v9); /*0x103a45b10*/
      v13 = _mm_shuffle_epi32(v12, 160); /*0x103a45b15*/
      v14 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v11, v9), 245); /*0x103a45b26*/
      v15 = _mm_shuffle_epi32(v12, 245); /*0x103a45b37*/
      v16 = _mm_xor_si128( /*0x103a45b48*/
              _mm_or_si128(
                _mm_shufflelo_epi16(v15, 232),
                _mm_and_si128(_mm_shufflelo_epi16(v14, 232), _mm_shufflelo_epi16(v13, 232))),
              (__m128i)-1LL);
      if ( (_mm_cvtsi128_si32(_mm_packs_epi32(v16, v16)) & 1) != 0 ) /*0x103a45b5a*/
        *(_WORD *)(a1 + 2 * v3) = a2; /*0x103a45b5c*/
      v17 = _mm_or_si128(_mm_and_si128(v14, v13), v15); /*0x103a45b65*/
      v18 = _mm_xor_si128(_mm_packs_epi32(v17, v17), (__m128i)-1LL); /*0x103a45b6f*/
      if ( (_mm_extract_epi8(_mm_packs_epi32(v18, v18), 2) & 1) != 0 ) /*0x103a45b83*/
        *(_WORD *)(a1 + 2 * v3 + 2) = a2; /*0x103a45b85*/
      v19 = _mm_xor_si128(_mm_or_si128(v10, v6), si128); /*0x103a45b94*/
      v20 = _mm_cmpgt_epi32(v19, v9); /*0x103a45b9e*/
      v21 = _mm_shuffle_epi32(v20, 160); /*0x103a45ba3*/
      v22 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v19, v9), 245); /*0x103a45bae*/
      v23 = _mm_shuffle_epi32(v20, 245); /*0x103a45bbe*/
      v24 = _mm_or_si128(_mm_and_si128(v22, v21), v23); /*0x103a45bc4*/
      v25 = _mm_xor_si128(_mm_packs_epi32(v24, v24), (__m128i)-1LL); /*0x103a45bce*/
      if ( (_mm_extract_epi8(_mm_packs_epi32(v25, v25), 4) & 1) != 0 ) /*0x103a45be2*/
        *(_WORD *)(a1 + 2 * v3 + 4) = a2; /*0x103a45be4*/
      v26 = _mm_xor_si128( /*0x103a45c05*/
              _mm_or_si128(
                _mm_shufflehi_epi16(v23, 132),
                _mm_and_si128(_mm_shufflehi_epi16(v22, 132), _mm_shufflehi_epi16(v21, 132))),
              (__m128i)-1LL);
      if ( (_mm_extract_epi8(_mm_packs_epi32(v26, v26), 6) & 1) != 0 ) /*0x103a45c19*/
        *(_WORD *)(a1 + 2 * v3 + 6) = a2; /*0x103a45c1b*/
      v27 = _mm_xor_si128(_mm_or_si128(v10, v5), si128); /*0x103a45c2a*/
      v28 = _mm_cmpgt_epi32(v27, v9); /*0x103a45c34*/
      v29 = _mm_shuffle_epi32(v28, 160); /*0x103a45c39*/
      v30 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v27, v9), 245); /*0x103a45c4a*/
      v31 = _mm_shuffle_epi32(v28, 245); /*0x103a45c5b*/
      v32 = _mm_xor_si128( /*0x103a45c6c*/
              _mm_or_si128(
                _mm_shufflelo_epi16(v31, 232),
                _mm_and_si128(_mm_shufflelo_epi16(v30, 232), _mm_shufflelo_epi16(v29, 232))),
              (__m128i)-1LL);
      if ( (_mm_extract_epi8(_mm_packs_epi32(v32, v32), 8) & 1) != 0 ) /*0x103a45c80*/
        *(_WORD *)(a1 + 2 * v3 + 8) = a2; /*0x103a45c82*/
      v33 = _mm_or_si128(_mm_and_si128(v30, v29), v31); /*0x103a45c8c*/
      v34 = _mm_xor_si128(_mm_packs_epi32(v33, v33), (__m128i)-1LL); /*0x103a45c96*/
      if ( (_mm_extract_epi8(_mm_packs_epi32(v34, v34), 10) & 1) != 0 ) /*0x103a45caa*/
        *(_WORD *)(a1 + 2 * v3 + 10) = a2; /*0x103a45cac*/
      v35 = _mm_xor_si128(_mm_or_si128(v10, v4), si128); /*0x103a45cb5*/
      v36 = _mm_cmpgt_epi32(v35, v9); /*0x103a45cbe*/
      v37 = _mm_shuffle_epi32(v36, 160); /*0x103a45cc3*/
      v38 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v35, v9), 245); /*0x103a45ccd*/
      v39 = _mm_shuffle_epi32(v36, 245); /*0x103a45cdc*/
      v40 = _mm_or_si128(_mm_and_si128(v38, v37), v39); /*0x103a45ce2*/
      v41 = _mm_xor_si128(_mm_packs_epi32(v40, v40), (__m128i)-1LL); /*0x103a45cec*/
      if ( (_mm_extract_epi8(_mm_packs_epi32(v41, v41), 12) & 1) != 0 ) /*0x103a45d00*/
        *(_WORD *)(a1 + 2 * v3 + 12) = a2; /*0x103a45d02*/
      v42 = _mm_and_si128(_mm_shufflehi_epi16(v38, 132), _mm_shufflehi_epi16(v37, 132)); /*0x103a45d12*/
      if ( (_mm_extract_epi8( /*0x103a45d35*/
              _mm_packs_epi32(v42, _mm_xor_si128(_mm_or_si128(_mm_shufflehi_epi16(v39, 132), v42), (__m128i)-1LL)),
              14)
          & 1) != 0 )
        *(_WORD *)(a1 + 2 * v3 + 14) = a2; /*0x103a45d37*/
      v3 += 8LL; /*0x103a45d3c*/
    }
    while ( ((a3 + 7) & 0xFFFFFFFFFFFFFFF8LL) != v3 ); /*0x103a45d43*/
  }
}

// Address: 0x103a45d4b | Name: _WebRtcSpl_MemSetW32
void __fastcall WebRtcSpl_MemSetW32(__int64 a1, int a2, __int64 a3)
{
  unsigned __int64 v3; // rcx
  __m128i v4; // xmm1
  __m128i v5; // xmm2
  __m128i si128; // xmm3
  __m128i v7; // xmm0
  __m128i v8; // xmm5
  __m128i v9; // xmm6
  __m128i v10; // xmm7
  __m128i v11; // xmm6
  __m128i v12; // xmm5
  __m128i v13; // xmm6
  __m128i v14; // xmm5

  if ( a3 != 0 ) /*0x103a45d4e*/
  {
    v3 = 0; /*0x103a45d6d*/
    v4 = _mm_cvtepi8_epi64(770); /*0x103a45d6f*/
    v5 = _mm_cvtepi8_epi64(256); /*0x103a45d78*/
    si128 = _mm_load_si128((const __m128i *)&xmmword_108F246C0); /*0x103a45d81*/
    v7 = _mm_xor_si128(_mm_shuffle_epi32((__m128i)(unsigned __int64)(a3 - 1), 68), si128); /*0x103a45d89*/
    do /*0x103a45e38*/
    {
      v8 = _mm_shuffle_epi32((__m128i)v3, 68); /*0x103a45d96*/
      v9 = _mm_xor_si128(_mm_or_si128(v8, v5), si128); /*0x103a45da3*/
      v10 = _mm_cmpgt_epi32(v9, v7); /*0x103a45dab*/
      v11 = _mm_or_si128( /*0x103a45dc3*/
              _mm_shuffle_epi32(v10, 245),
              _mm_and_si128(_mm_shuffle_epi32(_mm_cmpeq_epi32(v9, v7), 245), v10));
      if ( (~_mm_cvtsi128_si32(v11) & 1) != 0 ) /*0x103a45dd1*/
        *(_DWORD *)(a1 + 4 * v3) = a2; /*0x103a45dd3*/
      if ( (_mm_extract_epi8(_mm_xor_si128(v11, (__m128i)-1LL), 8) & 1) != 0 ) /*0x103a45de3*/
        *(_DWORD *)(a1 + 4 * v3 + 4) = a2; /*0x103a45de5*/
      v12 = _mm_xor_si128(_mm_or_si128(v8, v4), si128); /*0x103a45ded*/
      v13 = _mm_cmpgt_epi32(v12, v7); /*0x103a45df5*/
      v14 = _mm_xor_si128( /*0x103a45e0f*/
              _mm_or_si128(
                _mm_shuffle_epi32(v13, 245),
                _mm_and_si128(_mm_shuffle_epi32(_mm_cmpeq_epi32(v12, v7), 245), v13)),
              (__m128i)-1LL);
      if ( (_mm_extract_epi8(v14, 0) & 1) != 0 ) /*0x103a45e1c*/
        *(_DWORD *)(a1 + 4 * v3 + 8) = a2; /*0x103a45e1e*/
      if ( (_mm_extract_epi8(v14, 8) & 1) != 0 ) /*0x103a45e2b*/
        *(_DWORD *)(a1 + 4 * v3 + 12) = a2; /*0x103a45e2d*/
      v3 += 4LL; /*0x103a45e31*/
    }
    while ( ((a3 + 3) & 0xFFFFFFFFFFFFFFFCLL) != v3 ); /*0x103a45e38*/
  }
}

// Address: 0x103a45e40 | Name: _WebRtcSpl_MemCpyReversedOrder
void __fastcall WebRtcSpl_MemCpyReversedOrder(_WORD *a1, __int64 a2, __int64 a3)
{
  __int64 i; // rax

  if ( a3 != 0 ) /*0x103a45e43*/
  {
    for ( i = 0; i != a3; ++i ) /*0x103a45e49*/
      *a1-- = *(_WORD *)(a2 + 2 * i); /*0x103a45e4f*/
  }
}

// Address: 0x103a45e60 | Name: _WebRtcSpl_CopyFromEndW16
void *__fastcall WebRtcSpl_CopyFromEndW16(__int64 a1, __int64 a2, __int64 a3, void *a4)
{
  return memcpy(__dst: a4, __src: (const void *)(a1 + 2 * (a2 - a3)), __n: 2 * a3); /*0x103a45e71*/
}

// Address: 0x103a45e77 | Name: _WebRtcSpl_ZerosArrayW16
__int64 __fastcall WebRtcSpl_ZerosArrayW16(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  if ( a2 != 0 ) /*0x103a45e7e*/
    return __bzero(a1, a2: 2 * a2); /*0x103a45e84*/
  return result; /*0x103a45e83*/
}

// Address: 0x103a45e8b | Name: _WebRtcSpl_ZerosArrayW32
__int64 __fastcall WebRtcSpl_ZerosArrayW32(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  if ( a2 != 0 ) /*0x103a45e92*/
    return __bzero(a1, a2: 4 * a2); /*0x103a45e99*/
  return result; /*0x103a45e98*/
}

// Address: 0x103a45ea0 | Name: _WebRtcSpl_CrossCorrelationC
void __fastcall WebRtcSpl_CrossCorrelationC(
        _DWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        char a6,
        int a7)
{
  __int64 i; // r11
  int v8; // ebx
  __int64 j; // r14

  if ( a5 != 0 ) /*0x103a45ea3*/
  {
    for ( i = 0; i != a5; ++i ) /*0x103a45eb8*/
    {
      v8 = 0; /*0x103a45ebb*/
      if ( a4 != 0 ) /*0x103a45ec3*/
      {
        v8 = 0; /*0x103a45ec5*/
        for ( j = 0; j != a4; ++j ) /*0x103a45ec7*/
          v8 += (*(__int16 *)(a2 + 2 * j) * *(__int16 *)(a3 + 2 * j)) >> a6; /*0x103a45ede*/
      }
      *a1++ = v8; /*0x103a45ee9*/
      a3 += 2LL * a7; /*0x103a45ef2*/
    }
  }
}

// Address: 0x103a45f04 | Name: _WebRtcSpl_DotProductWithScale
__int64 __fastcall WebRtcSpl_DotProductWithScale(
        webrtc::webrtc_checks_impl *a1,
        __int64 a2,
        unsigned __int64 a3,
        char a4)
{
  __int64 v4; // r9
  __m128i v5; // xmm0
  __int64 result; // rax
  __m128i v7; // xmm2
  __m128i v8; // xmm2
  unsigned __int64 v9; // r8
  bool v10; // cf

  if ( a3 < 4 ) /*0x103a45f08*/
  {
    result = 0; /*0x103a45f64*/
    v9 = 0; /*0x103a45f66*/
  }
  else
  {
    v4 = 0; /*0x103a45f0e*/
    v5 = _mm_cvtepu32_epi64(_mm_cvtsi32_si128(a4)); /*0x103a45f11*/
    result = 0; /*0x103a45f16*/
    do /*0x103a45f60*/
    {
      v7 = _mm_sra_epi32( /*0x103a45f2a*/
             _mm_madd_epi16(
               _mm_cvtepu16_epi32(*(__m64 *)(a2 + 2 * v4)),
               _mm_cvtepu16_epi32(*(__m64 *)((char *)a1 + 2 * v4))),
             v5);
      v8 = _mm_add_epi64(_mm_cvtepi32_epi64(_mm_shuffle_epi32(v7, 238)), _mm_cvtepi32_epi64(v7)); /*0x103a45f3d*/
      result += _mm_add_epi64(_mm_shuffle_epi32(v8, 238), v8).u64[0]; /*0x103a45f4f*/
      v9 = v4 + 4; /*0x103a45f52*/
      v10 = v4 + 7 < a3; /*0x103a45f5a*/
      v4 += 4; /*0x103a45f5d*/
    }
    while ( v10 ); /*0x103a45f60*/
  }
  if ( v9 < a3 ) /*0x103a45f6c*/
  {
    do /*0x103a45f8b*/
    {
      result += (*((__int16 *)a1 + v9) * *(__int16 *)(a2 + 2 * v9)) >> a4; /*0x103a45f82*/
      ++v9; /*0x103a45f85*/
    }
    while ( a3 != v9 ); /*0x103a45f8b*/
  }
  switch ( (result < (__int64)0xFFFFFFFF80000000LL) + 2 * (result > 0x7FFFFFFF) ) /*0x103a45fb4*/
  {
    case 0: /*0x103a45fb4*/
      return result;
    case 1: /*0x103a45fb4*/
      result = 0x80000000LL; /*0x103a45fb6*/
      break; /*0x103a45fbb*/
    case 2: /*0x103a45fb4*/
      result = 0x7FFFFFFF; /*0x103a45fbc*/
      break; /*0x103a45fc1*/
    case 3: /*0x103a45fb4*/
      webrtc::webrtc_checks_impl::UnreachableCodeReached(this: a1); /*0x103a45fc6*/
  }
  return result; /*0x103a45fbb*/
}

// Address: 0x103a45fdc | Name: _WebRtcSpl_DownsampleFastC
__int64 __fastcall WebRtcSpl_DownsampleFastC(
        __int64 a1,
        unsigned __int64 a2,
        _WORD *a3,
        __int64 a4,
        __int16 *a5,
        __int64 a6,
        int a7,
        unsigned __int64 a8)
{
  unsigned __int64 v8; // r10
  bool v9; // cf
  unsigned __int64 v10; // rcx
  __int64 result; // rax
  __int64 v12; // r9
  __int64 v13; // rax
  int v14; // r14d
  __int16 *v15; // r15
  __int64 v16; // r12
  int v17; // r14d

  v8 = a8; /*0x103a45fe9*/
  v9 = a4 == 0; /*0x103a45ff1*/
  v10 = a8 + a7 * (a4 - 1) + 1; /*0x103a45fff*/
  result = 0xFFFFFFFFLL; /*0x103a46012*/
  if ( !v9 && a6 != 0 && v10 <= a2 ) /*0x103a4600d*/
  {
    if ( v10 > a8 ) /*0x103a4601c*/
    {
      v12 = -a6; /*0x103a4601e*/
      v13 = a1 + 2 * a8; /*0x103a46021*/
      do /*0x103a46082*/
      {
        v14 = 2048; /*0x103a4602e*/
        v15 = a5; /*0x103a46034*/
        v16 = 0; /*0x103a46037*/
        do /*0x103a46054*/
          v14 += *v15++ * *(__int16 *)(v13 + 2 * v16--); /*0x103a46047*/
        while ( v12 != v16 ); /*0x103a46054*/
        v17 = v14 >> 12; /*0x103a46056*/
        if ( v17 < -32767 ) /*0x103a46066*/
          v17 = -32768; /*0x103a46066*/
        if ( v17 >= 0x7FFF ) /*0x103a4606d*/
          LOWORD(v17) = 0x7FFF; /*0x103a4606d*/
        *a3++ = v17; /*0x103a46071*/
        v8 += a7; /*0x103a46079*/
        v13 += 2LL * a7; /*0x103a4607c*/
      }
      while ( v8 < v10 ); /*0x103a46082*/
    }
    return 0; /*0x103a46084*/
  }
  return result; /*0x103a46086*/
}

// Address: 0x103a46091 | Name: _WebRtcSpl_DivU32U16
__int64 __fastcall WebRtcSpl_DivU32U16(unsigned int a1, int a2)
{
  if ( a2 != 0 ) /*0x103a46097*/
    return a1 / (unsigned __int16)a2; /*0x103a460a0*/
  else
    return 0xFFFFFFFFLL; /*0x103a460a4*/
}

// Address: 0x103a460ab | Name: _WebRtcSpl_DivW32W16
__int64 __fastcall WebRtcSpl_DivW32W16(int a1, __int16 a2)
{
  if ( a2 != 0 ) /*0x103a460b2*/
    return (unsigned int)(a1 / a2); /*0x103a460ba*/
  else
    return 0x7FFFFFFF; /*0x103a460be*/
}

// Address: 0x103a460c5 | Name: _WebRtcSpl_DivW32W16ResW16
int __fastcall WebRtcSpl_DivW32W16ResW16(int a1, __int16 a2)
{
  int result; // eax

  if ( a2 != 0 ) /*0x103a460cc*/
    return (__int16)(a1 / a2); /*0x103a460d4*/
  else
    LOWORD(result) = 0x7FFF; /*0x103a460d8*/
  return (__int16)result; /*0x103a460dd*/
}

// Address: 0x103a460df | Name: _WebRtcSpl_DivResultInQ31
__int64 __fastcall WebRtcSpl_DivResultInQ31(int a1, int a2)
{
  int v2; // eax
  int v3; // edx
  unsigned int v4; // esi
  unsigned int v5; // ecx
  int i; // r8d
  int v7; // eax
  int v8; // r9d
  int v9; // r10d
  __int64 result; // rax

  if ( a1 == 0 ) /*0x103a460e5*/
    return 0; /*0x103a46132*/
  v2 = -a1; /*0x103a460e9*/
  if ( a1 > 0 ) /*0x103a460eb*/
    v2 = a1; /*0x103a460eb*/
  v3 = -a2; /*0x103a460f0*/
  if ( a2 > 0 ) /*0x103a460f2*/
    v3 = a2; /*0x103a460f2*/
  v4 = (unsigned int)a2 >> 31; /*0x103a460f5*/
  v5 = 0; /*0x103a460f8*/
  for ( i = -31; i != 0; ++i ) /*0x103a460fa*/
  {
    v7 = 2 * v2; /*0x103a46100*/
    v8 = 0; /*0x103a46102*/
    v9 = 0; /*0x103a46107*/
    if ( v7 >= v3 ) /*0x103a4610d*/
      v9 = v3; /*0x103a4610d*/
    LOBYTE(v8) = v7 >= v3; /*0x103a46111*/
    v2 = v7 - v9; /*0x103a46115*/
    v5 = v8 + 2 * v5; /*0x103a46118*/
  }
  result = -v5; /*0x103a46128*/
  if ( ((unsigned int)a1 >> 31) + v4 != 1 ) /*0x103a4612d*/
    return v5; /*0x103a4612d*/
  return result; /*0x103a46134*/
}

// Address: 0x103a46136 | Name: _WebRtcSpl_DivW32HiLow
__int64 __fastcall WebRtcSpl_DivW32HiLow(int a1, __int16 a2, __int16 a3)
{
  int v3; // eax
  int v4; // esi
  signed int v5; // esi
  unsigned int v6; // esi

  if ( a2 != 0 ) /*0x103a4613f*/
  {
    v3 = 0x1FFFFFFF / a2; /*0x103a4614d*/
    v4 = -2 * a2; /*0x103a46150*/
  }
  else
  {
    v3 = -1; /*0x103a46154*/
    v4 = 0; /*0x103a46159*/
  }
  v5 = v3 * v4 - (((v3 * a3) >> 14) & 0xFFFFFFFE) + 0x7FFFFFFF; /*0x103a4616c*/
  v6 = v3 * (v5 >> 16) + ((v3 * ((unsigned __int16)v5 >> 1)) >> 15); /*0x103a46189*/
  return (unsigned int)(8 /*0x103a461b4*/
                      * ((a1 >> 16) * (__int16)(v6 >> 15)
                       + ((int)((v6 & 0x7FFF) * (a1 >> 16)) >> 15)
                       + (((__int16)(v6 >> 15) * ((unsigned __int16)a1 >> 1)) >> 15)));
}

// Address: 0x103a461b6 | Name: _WebRtcSpl_Energy
__int64 __fastcall WebRtcSpl_Energy(__int64 a1, __int64 a2, _DWORD *a3)
{
  int ScalingSquare; // ecx
  __int64 result; // rax
  __int64 v8; // rdx

  ScalingSquare = (__int16)WebRtcSpl_GetScalingSquare(a1, a2, a3: a2); /*0x103a461d1*/
  result = 0; /*0x103a461d4*/
  if ( a2 != 0 ) /*0x103a461d9*/
  {
    v8 = 0; /*0x103a461db*/
    do /*0x103a461ef*/
    {
      result = ((unsigned int)(*(__int16 *)(a1 + 2 * v8) * *(__int16 *)(a1 + 2 * v8)) >> ScalingSquare) /*0x103a461e7*/
             + (unsigned int)result;
      ++v8; /*0x103a461e9*/
    }
    while ( a2 != v8 ); /*0x103a461ef*/
  }
  *a3 = ScalingSquare; /*0x103a461f1*/
  return result; /*0x103a461f7*/
}

// Address: 0x103a461fe | Name: _WebRtcSpl_GetScalingSquare
__int64 __fastcall WebRtcSpl_GetScalingSquare(__int64 a1, __int64 a2, unsigned int a3)
{
  __int16 v3; // ax
  __int64 i; // rcx
  __int16 v5; // r9
  unsigned int v6; // esi
  __int16 v7; // si
  __int16 v8; // r8
  unsigned int v9; // r8d
  __int16 v10; // di

  v3 = -1; /*0x103a46202*/
  if ( a2 != 0 ) /*0x103a46209*/
  {
    for ( i = 0; i != a2; ++i ) /*0x103a4620b*/
    {
      v5 = -*(_WORD *)(a1 + 2 * i); /*0x103a46215*/
      if ( *(__int16 *)(a1 + 2 * i) > 0 ) /*0x103a46219*/
        v5 = *(_WORD *)(a1 + 2 * i); /*0x103a46219*/
      if ( v5 > v3 ) /*0x103a46222*/
        v3 = v5; /*0x103a46222*/
    }
  }
  _BitScanReverse(&v6, v3 * v3); /*0x103a46236*/
  v7 = (v6 ^ 0x1F) - 1; /*0x103a4623c*/
  if ( v3 == 0 ) /*0x103a46243*/
    v7 = 0; /*0x103a46243*/
  v8 = 32; /*0x103a4624b*/
  if ( a3 != 0 ) /*0x103a46253*/
  {
    _BitScanReverse(&v9, a3); /*0x103a46255*/
    v8 = v9 ^ 0x1F; /*0x103a46259*/
  }
  v10 = 32 - v8 - v7; /*0x103a46260*/
  if ( (__int16)(32 - v8) < v7 ) /*0x103a46263*/
    v10 = 0; /*0x103a46263*/
  if ( v3 == 0 ) /*0x103a46269*/
    return 0; /*0x103a46269*/
  return (unsigned int)v10; /*0x103a4626f*/
}

// Address: 0x103a46271 | Name: _WebRtcSpl_MaxAbsValueW16C
__int64 __fastcall WebRtcSpl_MaxAbsValueW16C(__int64 a1, __int64 a2)
{
  unsigned int v2; // ecx
  __int64 i; // rax
  unsigned __int16 v4; // r8
  __int64 result; // rax

  v2 = 0; /*0x103a46275*/
  if ( a2 != 0 ) /*0x103a4627a*/
  {
    for ( i = 0; i != a2; ++i ) /*0x103a4627c*/
    {
      v4 = -*(_WORD *)(a1 + 2 * i); /*0x103a46285*/
      if ( *(__int16 *)(a1 + 2 * i) > 0 ) /*0x103a46289*/
        v4 = *(_WORD *)(a1 + 2 * i); /*0x103a46289*/
      if ( (int)v2 <= v4 ) /*0x103a46294*/
        v2 = v4; /*0x103a46294*/
    }
  }
  result = 0x7FFF; /*0x103a4629f*/
  if ( v2 < 0x7FFF ) /*0x103a462a6*/
    return v2; /*0x103a462a6*/
  return result; /*0x103a462a9*/
}

// Address: 0x103a462ab | Name: _WebRtcSpl_MaxAbsValueW32C
__int64 __fastcall WebRtcSpl_MaxAbsValueW32C(__int64 a1, __int64 a2)
{
  __int64 v2; // rax
  unsigned int v3; // ecx
  unsigned int v4; // r9d
  __int64 result; // rax

  if ( a2 != 0 ) /*0x103a462b2*/
  {
    v2 = 0; /*0x103a462b4*/
    v3 = 0; /*0x103a462bb*/
    do /*0x103a462dc*/
    {
      v4 = -*(_DWORD *)(a1 + 4 * v2); /*0x103a462c4*/
      if ( *(int *)(a1 + 4 * v2) > 0 ) /*0x103a462c7*/
        v4 = *(_DWORD *)(a1 + 4 * v2); /*0x103a462c7*/
      if ( __OFSUB__(-*(_DWORD *)(a1 + 4 * v2), 1) ) /*0x103a462c4*/
        v4 = 0x80000000; /*0x103a462cb*/
      if ( v4 > v3 ) /*0x103a462d2*/
        v3 = v4; /*0x103a462d2*/
      ++v2; /*0x103a462d6*/
    }
    while ( a2 != v2 ); /*0x103a462dc*/
  }
  else
  {
    v3 = 0; /*0x103a462e0*/
  }
  result = 0x7FFFFFFF; /*0x103a462e2*/
  if ( v3 < 0x7FFFFFFF ) /*0x103a462e9*/
    return v3; /*0x103a462e9*/
  return result; /*0x103a462ec*/
}

// Address: 0x103a462ee | Name: _WebRtcSpl_MaxValueW16C
__int64 __fastcall WebRtcSpl_MaxValueW16C(__int64 a1, __int64 a2, int a3)
{
  __int64 i; // rax
  int v4; // ecx

  if ( a2 != 0 ) /*0x103a462f5*/
  {
    LOWORD(a3) = 0x8000; /*0x103a462f7*/
    for ( i = 0; i != a2; ++i ) /*0x103a462fb*/
    {
      v4 = *(unsigned __int16 *)(a1 + 2 * i); /*0x103a462fd*/
      if ( (__int16)v4 <= (__int16)a3 ) /*0x103a46304*/
        v4 = a3; /*0x103a46304*/
      a3 = v4; /*0x103a4630a*/
    }
  }
  else
  {
    LOWORD(v4) = 0x8000; /*0x103a46313*/
  }
  return (unsigned int)(__int16)v4; /*0x103a4631a*/
}

// Address: 0x103a4631c | Name: _WebRtcSpl_MaxValueW32C
__int64 __fastcall WebRtcSpl_MaxValueW32C(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  __int64 i; // rcx
  int v4; // edx

  result = 0x80000000LL; /*0x103a46320*/
  if ( a2 != 0 ) /*0x103a46328*/
  {
    for ( i = 0; i != a2; ++i ) /*0x103a4632a*/
    {
      v4 = *(_DWORD *)(a1 + 4 * i); /*0x103a4632c*/
      if ( v4 > (int)result ) /*0x103a46331*/
        result = (unsigned int)v4; /*0x103a46331*/
    }
  }
  return result; /*0x103a4633c*/
}

// Address: 0x103a4633e | Name: _WebRtcSpl_MinValueW16C
__int64 __fastcall WebRtcSpl_MinValueW16C(__int64 a1, __int64 a2, int a3)
{
  __int64 i; // rax
  int v4; // ecx

  if ( a2 != 0 ) /*0x103a46345*/
  {
    LOWORD(a3) = 0x7FFF; /*0x103a46347*/
    for ( i = 0; i != a2; ++i ) /*0x103a4634b*/
    {
      v4 = *(unsigned __int16 *)(a1 + 2 * i); /*0x103a4634d*/
      if ( (__int16)v4 >= (__int16)a3 ) /*0x103a46354*/
        v4 = a3; /*0x103a46354*/
      a3 = v4; /*0x103a4635a*/
    }
  }
  else
  {
    LOWORD(v4) = 0x7FFF; /*0x103a46363*/
  }
  return (unsigned int)(__int16)v4; /*0x103a4636a*/
}

// Address: 0x103a4636c | Name: _WebRtcSpl_MinValueW32C
__int64 __fastcall WebRtcSpl_MinValueW32C(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  __int64 i; // rcx
  int v4; // edx

  result = 0x7FFFFFFF; /*0x103a46370*/
  if ( a2 != 0 ) /*0x103a46378*/
  {
    for ( i = 0; i != a2; ++i ) /*0x103a4637a*/
    {
      v4 = *(_DWORD *)(a1 + 4 * i); /*0x103a4637c*/
      if ( v4 < (int)result ) /*0x103a46381*/
        result = (unsigned int)v4; /*0x103a46381*/
    }
  }
  return result; /*0x103a4638c*/
}

// Address: 0x103a4638e | Name: _WebRtcSpl_MaxAbsIndexW16
__int64 __fastcall WebRtcSpl_MaxAbsIndexW16(__int64 a1, __int64 a2)
{
  int v2; // ecx
  __int64 result; // rax
  __int64 i; // rdx
  unsigned __int16 v5; // r9

  v2 = 0; /*0x103a46392*/
  result = 0; /*0x103a46394*/
  if ( a2 != 0 ) /*0x103a46399*/
  {
    for ( i = 0; i != a2; ++i ) /*0x103a4639b*/
    {
      v5 = -*(_WORD *)(a1 + 2 * i); /*0x103a463a5*/
      if ( *(__int16 *)(a1 + 2 * i) > 0 ) /*0x103a463a9*/
        v5 = *(_WORD *)(a1 + 2 * i); /*0x103a463a9*/
      if ( v2 < (unsigned int)v5 ) /*0x103a463b5*/
        result = i; /*0x103a463b5*/
      if ( v2 <= v5 ) /*0x103a463b9*/
        v2 = v5; /*0x103a463b9*/
    }
  }
  return result; /*0x103a463c5*/
}

// Address: 0x103a463c7 | Name: _WebRtcSpl_MaxAbsElementW16
__int64 __fastcall WebRtcSpl_MaxAbsElementW16(__int64 a1, __int64 a2, __int64 a3, __int64 a4, int a5)
{
  __int16 v5; // ax
  __int64 i; // rcx
  int v7; // edx
  __int16 v8; // cx

  if ( a2 != 0 ) /*0x103a463ce*/
  {
    v5 = 0x7FFF; /*0x103a463d0*/
    LOWORD(a5) = 0x8000; /*0x103a463d4*/
    for ( i = 0; i != a2; ++i ) /*0x103a463d9*/
    {
      v7 = *(unsigned __int16 *)(a1 + 2 * i); /*0x103a463db*/
      if ( (__int16)v7 < v5 ) /*0x103a463e2*/
        v5 = *(_WORD *)(a1 + 2 * i); /*0x103a463e2*/
      if ( (__int16)v7 <= (__int16)a5 ) /*0x103a463e9*/
        v7 = a5; /*0x103a463e9*/
      a5 = v7; /*0x103a463f0*/
    }
  }
  else
  {
    LOWORD(v7) = 0x8000; /*0x103a463fa*/
    v5 = 0x7FFF; /*0x103a463fe*/
  }
  v8 = v7; /*0x103a46402*/
  if ( v5 < -(__int16)v7 ) /*0x103a4640e*/
    LOWORD(v7) = v5; /*0x103a4640e*/
  if ( v5 == v8 ) /*0x103a46414*/
    LOWORD(v7) = v5; /*0x103a46414*/
  return (unsigned int)(__int16)v7; /*0x103a4641a*/
}

// Address: 0x103a4641c | Name: _WebRtcSpl_MinMaxW16
__int16 __fastcall WebRtcSpl_MinMaxW16(__int64 a1, __int64 a2, __int16 *a3, _WORD *a4)
{
  int v4; // r10d
  __int16 result; // ax
  __int64 i; // r9
  int v7; // r8d

  if ( a2 != 0 ) /*0x103a46423*/
  {
    result = 0x7FFF; /*0x103a46425*/
    LOWORD(v4) = 0x8000; /*0x103a46429*/
    for ( i = 0; i != a2; ++i ) /*0x103a4642e*/
    {
      v7 = *(unsigned __int16 *)(a1 + 2 * i); /*0x103a46431*/
      if ( (__int16)v7 < result ) /*0x103a4643a*/
        result = *(_WORD *)(a1 + 2 * i); /*0x103a4643a*/
      if ( (__int16)v7 <= (__int16)v4 ) /*0x103a46442*/
        v7 = v4; /*0x103a46442*/
      v4 = v7; /*0x103a46449*/
    }
  }
  else
  {
    LOWORD(v7) = 0x8000; /*0x103a46453*/
    result = 0x7FFF; /*0x103a46458*/
  }
  *a3 = result; /*0x103a4645c*/
  *a4 = v7; /*0x103a4645f*/
  return result; /*0x103a46463*/
}

// Address: 0x103a46465 | Name: _WebRtcSpl_MaxIndexW16
__int64 __fastcall WebRtcSpl_MaxIndexW16(__int64 a1, __int64 a2)
{
  __int16 v2; // cx
  __int64 result; // rax
  __int64 i; // rdx

  if ( a2 == 0 ) /*0x103a4646c*/
    return 0; /*0x103a46491*/
  v2 = 0x8000; /*0x103a4646e*/
  result = 0; /*0x103a46472*/
  for ( i = 0; i != a2; ++i ) /*0x103a46474*/
  {
    if ( *(__int16 *)(a1 + 2 * i) > v2 ) /*0x103a4647f*/
    {
      result = i; /*0x103a4647f*/
      v2 = *(_WORD *)(a1 + 2 * i); /*0x103a46483*/
    }
  }
  return result; /*0x103a46493*/
}

// Address: 0x103a46495 | Name: _WebRtcSpl_MaxIndexW32
__int64 __fastcall WebRtcSpl_MaxIndexW32(__int64 a1, __int64 a2)
{
  signed int v2; // ecx
  __int64 result; // rax
  __int64 i; // rdx

  if ( a2 == 0 ) /*0x103a4649c*/
    return 0; /*0x103a464c0*/
  v2 = 0x80000000; /*0x103a4649e*/
  result = 0; /*0x103a464a3*/
  for ( i = 0; i != a2; ++i ) /*0x103a464a5*/
  {
    if ( *(_DWORD *)(a1 + 4 * i) > v2 ) /*0x103a464ae*/
    {
      result = i; /*0x103a464ae*/
      v2 = *(_DWORD *)(a1 + 4 * i); /*0x103a464b2*/
    }
  }
  return result; /*0x103a464c2*/
}

// Address: 0x103a464c4 | Name: _WebRtcSpl_MinIndexW16
__int64 __fastcall WebRtcSpl_MinIndexW16(__int64 a1, __int64 a2)
{
  __int16 v2; // cx
  __int64 result; // rax
  __int64 i; // rdx

  if ( a2 == 0 ) /*0x103a464cb*/
    return 0; /*0x103a464f0*/
  v2 = 0x7FFF; /*0x103a464cd*/
  result = 0; /*0x103a464d1*/
  for ( i = 0; i != a2; ++i ) /*0x103a464d3*/
  {
    if ( *(__int16 *)(a1 + 2 * i) < v2 ) /*0x103a464de*/
    {
      result = i; /*0x103a464de*/
      v2 = *(_WORD *)(a1 + 2 * i); /*0x103a464e2*/
    }
  }
  return result; /*0x103a464f2*/
}

// Address: 0x103a464f4 | Name: _WebRtcSpl_MinIndexW32
__int64 __fastcall WebRtcSpl_MinIndexW32(__int64 a1, __int64 a2)
{
  int v2; // ecx
  __int64 result; // rax
  __int64 i; // rdx

  if ( a2 == 0 ) /*0x103a464fb*/
    return 0; /*0x103a4651f*/
  v2 = 0x7FFFFFFF; /*0x103a464fd*/
  result = 0; /*0x103a46502*/
  for ( i = 0; i != a2; ++i ) /*0x103a46504*/
  {
    if ( *(_DWORD *)(a1 + 4 * i) < v2 ) /*0x103a4650d*/
    {
      result = i; /*0x103a4650d*/
      v2 = *(_DWORD *)(a1 + 4 * i); /*0x103a46511*/
    }
  }
  return result; /*0x103a46521*/
}

// Address: 0x103a46523 | Name: _WebRtcSpl_RandU
__int64 __fastcall WebRtcSpl_RandU(unsigned int *a1)
{
  unsigned int v1; // eax

  v1 = (69069 * *a1 + 1) & 0x7FFFFFFF; /*0x103a4652f*/
  *a1 = v1; /*0x103a46534*/
  return HIWORD(v1); /*0x103a46539*/
}

// Address: 0x103a4653b | Name: _WebRtcSpl_RandN
__int64 __fastcall WebRtcSpl_RandN(unsigned int *a1)
{
  unsigned int v1; // eax

  v1 = 69069 * *a1 + 1; /*0x103a46545*/
  *a1 = v1 & 0x7FFFFFFF; /*0x103a4654f*/
  return (unsigned int)*(__int16 *)((char *)&kRandNTable + ((v1 >> 22) & 0x1FE)); /*0x103a46564*/
}

// Address: 0x103a46566 | Name: _WebRtcSpl_RandUArray
__int64 __fastcall WebRtcSpl_RandUArray(__int64 a1, __int16 a2, int *a3)
{
  int v3; // ecx
  __int64 i; // r8

  if ( a2 > 0 ) /*0x103a4656d*/
  {
    v3 = *a3; /*0x103a46572*/
    for ( i = 0; i != (unsigned __int16)a2; *(_WORD *)(a1 + 2 * i++) = HIWORD(v3) ) /*0x103a46574*/
      v3 = (69069 * v3 + 1) & 0x7FFFFFFF; /*0x103a4657f*/
    *a3 = v3; /*0x103a46599*/
  }
  return (unsigned int)a2; /*0x103a4659e*/
}

// Address: 0x103a465a0 | Name: _WebRtcSpl_CreateRealFFT
_DWORD *__fastcall WebRtcSpl_CreateRealFFT(unsigned int a1)
{
  _DWORD *result; // rax

  if ( a1 > 0xA ) /*0x103a465a3*/
    return nullptr; /*0x103a465a5*/
  result = malloc(__size: 4u); /*0x103a465b5*/
  if ( result == nullptr ) /*0x103a465bd*/
    return nullptr; /*0x103a465c3*/
  *result = a1; /*0x103a465bf*/
  return result; /*0x103a465a7*/
}

// Address: 0x103a465cc | Name: _WebRtcSpl_FreeRealFFT
void __fastcall WebRtcSpl_FreeRealFFT(void *a1)
{
  if ( a1 != nullptr ) /*0x103a465d3*/
    free(a1); /*0x103a465d6*/
}

// Address: 0x103a465dd | Name: _WebRtcSpl_RealForwardFFT
__int64 __fastcall WebRtcSpl_RealForwardFFT(int *a1, __int64 a2, void *a3)
{
  int v5; // ecx
  __int64 v6; // rax
  int v7; // r12d
  __int64 i; // rdx
  unsigned int v9; // r14d
  _WORD __src[2052]; // [rsp+0h] [rbp-1030h] BYREF

  v5 = *a1; /*0x103a46603*/
  v6 = 1; /*0x103a46605*/
  v7 = 1 << *a1; /*0x103a46610*/
  if ( *a1 != 31 ) /*0x103a46616*/
  {
    if ( v7 >= 2 ) /*0x103a4661c*/
      v6 = (unsigned int)v7; /*0x103a4661c*/
    for ( i = 0; i != v6; ++i ) /*0x103a46620*/
    {
      __src[2 * i] = *(_WORD *)(a2 + 2 * i); /*0x103a46626*/
      __src[2 * i + 1] = 0; /*0x103a4662e*/
    }
  }
  WebRtcSpl_ComplexBitReverse(a1: (__int64)__src, a2: v5); /*0x103a4664c*/
  v9 = WebRtcSpl_ComplexFFT(a1: (__int64)__src, a2: *a1, a3: 1); /*0x103a46661*/
  memcpy(__dst: a3, __src, __n: 2LL * v7 + 4); /*0x103a46675*/
  return v9; /*0x103a4668d*/
}

// Address: 0x103a466a2 | Name: _WebRtcSpl_RealInverseFFT
__int64 __fastcall WebRtcSpl_RealInverseFFT(unsigned int *a1, __int64 a2, __int64 a3)
{
  int v4; // r14d
  int v5; // r13d
  int v6; // edx
  __int64 v7; // rax
  __int64 v8; // rcx
  _WORD *v9; // rdx
  __int64 v10; // r15
  __int64 result; // rax
  __int64 i; // rcx
  _WORD v15[2048]; // [rsp+10h] [rbp-1030h] BYREF

  v4 = *a1; /*0x103a466ce*/
  v5 = 1 << *a1; /*0x103a466da*/
  __memcpy_chk(a1: v15, a2, a3: 2LL * v5 + 4, a4: 4096); /*0x103a466ff*/
  v6 = 2 << v4; /*0x103a4670c*/
  if ( v5 + 2 < 2 << v4 ) /*0x103a46711*/
  {
    v7 = v5 + 2LL; /*0x103a46713*/
    v8 = v6; /*0x103a46717*/
    v9 = (_WORD *)(a2 + 2LL * v6 - 2LL * v5 - 2); /*0x103a4672e*/
    do /*0x103a46756*/
    {
      v15[v7] = *(v9 - 1); /*0x103a46736*/
      v15[v7 + 1] = -*v9; /*0x103a46743*/
      v7 += 2; /*0x103a4674b*/
      v9 -= 2; /*0x103a4674f*/
    }
    while ( v7 < v8 ); /*0x103a46756*/
  }
  WebRtcSpl_ComplexBitReverse(a1: (__int64)v15, a2: v4); /*0x103a46765*/
  v10 = 1; /*0x103a46773*/
  result = WebRtcSpl_ComplexIFFT(a1: (__int64)v15, a2: *a1, a3: 1); /*0x103a46781*/
  if ( v4 != 31 ) /*0x103a4678a*/
  {
    if ( v5 >= 2 ) /*0x103a46790*/
      v10 = (unsigned int)v5; /*0x103a46790*/
    for ( i = 0; i != v10; ++i ) /*0x103a46794*/
      *(_WORD *)(a3 + 2 * i) = v15[2 * i]; /*0x103a4679e*/
  }
  return result; /*0x103a467ba*/
}

// Address: 0x103a467d1 | Name: _WebRtcSpl_Resample22khzTo16khz
__int64 __fastcall WebRtcSpl_Resample22khzTo16khz(__int64 a1, __int64 a2, _DWORD *a3, _DWORD *a4)
{
  __int64 v7; // r13
  __int64 result; // rax
  _DWORD *v10; // [rsp+10h] [rbp-40h]
  _DWORD *v11; // [rsp+18h] [rbp-38h]
  _DWORD *v12; // [rsp+20h] [rbp-30h]

  v10 = a4 + 16; /*0x103a467f3*/
  v11 = a4 + 8; /*0x103a467fb*/
  v12 = a3 + 16; /*0x103a46803*/
  v7 = 0; /*0x103a46807*/
  do /*0x103a468e2*/
  {
    WebRtcSpl_UpBy2ShortToInt(a1, a2: 44, a3: v10, a4: a3); /*0x103a46821*/
    a4[8] = a3[8]; /*0x103a4682a*/
    a4[9] = a3[9]; /*0x103a46831*/
    a4[10] = a3[10]; /*0x103a46838*/
    a4[11] = a3[11]; /*0x103a4683f*/
    a4[12] = a3[12]; /*0x103a46846*/
    a4[13] = a3[13]; /*0x103a4684d*/
    a4[14] = a3[14]; /*0x103a46854*/
    a4[15] = a3[15]; /*0x103a4685b*/
    a3[8] = a4[96]; /*0x103a46864*/
    a3[9] = a4[97]; /*0x103a4686e*/
    a3[10] = a4[98]; /*0x103a46878*/
    a3[11] = a4[99]; /*0x103a46882*/
    a3[12] = a4[100]; /*0x103a4688c*/
    a3[13] = a4[101]; /*0x103a46896*/
    a3[14] = a4[102]; /*0x103a468a0*/
    a3[15] = a4[103]; /*0x103a468aa*/
    WebRtcSpl_Resample44khzTo32khz(a1: v11, a2: a4, a3: 8); /*0x103a468ba*/
    result = WebRtcSpl_DownBy2IntToShort(a1: a4, a2: 64, a3: a2 + v7, a4: v12); /*0x103a468ce*/
    a1 += 88; /*0x103a468d3*/
    v7 += 64; /*0x103a468d7*/
  }
  while ( (_DWORD)v7 != 320 ); /*0x103a468e2*/
  return result; /*0x103a468e8*/
}

// Address: 0x103a468f7 | Name: _WebRtcSpl_ResetResample22khzTo16khz
void __fastcall WebRtcSpl_ResetResample22khzTo16khz(_OWORD *a1)
{
  a1[5] = 0; /*0x103a468fe*/
  a1[4] = 0; /*0x103a46902*/
  a1[3] = 0; /*0x103a46906*/
  a1[2] = 0; /*0x103a4690a*/
  a1[1] = 0; /*0x103a4690e*/
  *a1 = 0; /*0x103a46912*/
}

// Address: 0x103a46917 | Name: _WebRtcSpl_Resample16khzTo22khz
__int64 __fastcall WebRtcSpl_Resample16khzTo22khz(__int64 a1, _WORD *a2, _DWORD *a3, _DWORD *a4)
{
  __int64 result; // rax
  __int64 v7; // r13
  _WORD *v8; // r15
  int v9; // eax
  __int64 v10; // [rsp+8h] [rbp-48h]
  int v11; // [rsp+10h] [rbp-40h]
  _DWORD *v13; // [rsp+20h] [rbp-30h]

  v13 = a4 + 8; /*0x103a46936*/
  LODWORD(result) = 0; /*0x103a4693a*/
  do /*0x103a46ae4*/
  {
    v11 = result; /*0x103a46942*/
    v10 = a1; /*0x103a46946*/
    WebRtcSpl_UpBy2ShortToInt(a1, a2: 40, a3: v13, a4: a3); /*0x103a4695a*/
    *a4 = a3[8]; /*0x103a46963*/
    a4[1] = a3[9]; /*0x103a46969*/
    a4[2] = a3[10]; /*0x103a46970*/
    a4[3] = a3[11]; /*0x103a46977*/
    a4[4] = a3[12]; /*0x103a4697e*/
    a4[5] = a3[13]; /*0x103a46985*/
    a4[6] = a3[14]; /*0x103a4698c*/
    a4[7] = a3[15]; /*0x103a46993*/
    a3[8] = a4[80]; /*0x103a4699c*/
    a3[9] = a4[81]; /*0x103a469a6*/
    a3[10] = a4[82]; /*0x103a469b0*/
    a3[11] = a4[83]; /*0x103a469ba*/
    a3[12] = a4[84]; /*0x103a469c4*/
    a3[13] = a4[85]; /*0x103a469ce*/
    a3[14] = a4[86]; /*0x103a469d8*/
    a3[15] = a4[87]; /*0x103a469e2*/
    v7 = 0; /*0x103a469e6*/
    v8 = a2; /*0x103a469ed*/
    do /*0x103a46ac5*/
    {
      v9 = a4[v7 + 3]; /*0x103a469f8*/
      if ( v9 >= 0x7FFF ) /*0x103a469ff*/
        v9 = 0x7FFF; /*0x103a469ff*/
      if ( v9 < -32767 ) /*0x103a46a11*/
        LOWORD(v9) = 0x8000; /*0x103a46a11*/
      *v8 = v9; /*0x103a46a14*/
      WebRtcSpl_DotProdIntToShort(a1: &a4[v7], a2: &a4[v7 + 22], a3: &kCoefficients32To22, a4: v8 + 1, a5: v8 + 10); /*0x103a46a2f*/
      WebRtcSpl_DotProdIntToShort(a1: &a4[v7 + 2], a2: &a4[v7 + 20], a3: &unk_10958E182, a4: v8 + 2, a5: v8 + 9); /*0x103a46a50*/
      WebRtcSpl_DotProdIntToShort(a1: &a4[v7 + 3], a2: &a4[v7 + 19], a3: &unk_10958E194, a4: v8 + 3, a5: v8 + 8); /*0x103a46a6f*/
      WebRtcSpl_DotProdIntToShort(a1: &a4[v7 + 5], a2: &a4[v7 + 17], a3: &unk_10958E1A6, a4: v8 + 4, a5: v8 + 7); /*0x103a46a90*/
      WebRtcSpl_DotProdIntToShort(a1: &a4[v7 + 6], a2: &a4[v7 + 16], a3: &unk_10958E1B8, a4: v8 + 5, a5: v8 + 6); /*0x103a46ab1*/
      v7 += 16; /*0x103a46ab6*/
      v8 += 11; /*0x103a46aba*/
    }
    while ( (_DWORD)(v7 * 4) != 320 ); /*0x103a46ac5*/
    a1 = v10 + 80; /*0x103a46acf*/
    a2 += 55; /*0x103a46ad7*/
    result = (unsigned int)(v11 + 1); /*0x103a46adf*/
  }
  while ( v11 != 3 ); /*0x103a46ae4*/
  return result; /*0x103a46aea*/
}

// Address: 0x103a46af9 | Name: _WebRtcSpl_ResetResample16khzTo22khz
void __fastcall WebRtcSpl_ResetResample16khzTo22khz(_OWORD *a1)
{
  a1[3] = 0; /*0x103a46b00*/
  a1[2] = 0; /*0x103a46b04*/
  a1[1] = 0; /*0x103a46b08*/
  *a1 = 0; /*0x103a46b0c*/
}

// Address: 0x103a46b11 | Name: _WebRtcSpl_Resample22khzTo8khz
__int64 __fastcall WebRtcSpl_Resample22khzTo8khz(__int64 a1, __int64 a2, _DWORD *a3, _DWORD *a4)
{
  char v8; // r13
  __int64 result; // rax
  bool v10; // zf
  _DWORD *v11; // [rsp+0h] [rbp-40h]
  _DWORD *v12; // [rsp+8h] [rbp-38h]
  _DWORD *v13; // [rsp+10h] [rbp-30h]

  v11 = a4 + 16; /*0x103a46b32*/
  v12 = a4 + 8; /*0x103a46b3a*/
  v13 = a3 + 24; /*0x103a46b42*/
  v8 = 1; /*0x103a46b46*/
  do /*0x103a46c1f*/
  {
    WebRtcSpl_LPBy2ShortToInt(a1, a2: 110, a3: v11, a4: a3); /*0x103a46b58*/
    a4[8] = a3[16]; /*0x103a46b61*/
    a4[9] = a3[17]; /*0x103a46b68*/
    a4[10] = a3[18]; /*0x103a46b6f*/
    a4[11] = a3[19]; /*0x103a46b76*/
    a4[12] = a3[20]; /*0x103a46b7d*/
    a4[13] = a3[21]; /*0x103a46b84*/
    a4[14] = a3[22]; /*0x103a46b8b*/
    a4[15] = a3[23]; /*0x103a46b92*/
    a3[16] = a4[118]; /*0x103a46b9b*/
    a3[17] = a4[119]; /*0x103a46ba5*/
    a3[18] = a4[120]; /*0x103a46baf*/
    a3[19] = a4[121]; /*0x103a46bb9*/
    a3[20] = a4[122]; /*0x103a46bc3*/
    a3[21] = a4[123]; /*0x103a46bcd*/
    a3[22] = a4[124]; /*0x103a46bd7*/
    a3[23] = a4[125]; /*0x103a46be1*/
    WebRtcSpl_Resample44khzTo32khz(a1: v12, a2: a4, a3: 10); /*0x103a46bf1*/
    result = WebRtcSpl_DownBy2IntToShort(a1: a4, a2: 80, a3: a2, a4: v13); /*0x103a46c05*/
    a1 += 220; /*0x103a46c0a*/
    a2 += 80; /*0x103a46c11*/
    v10 = (v8 & 1) == 0; /*0x103a46c15*/
    v8 = 0; /*0x103a46c19*/
  }
  while ( !v10 ); /*0x103a46c1f*/
  return result; /*0x103a46c25*/
}

// Address: 0x103a46c34 | Name: _WebRtcSpl_ResetResample22khzTo8khz
void __fastcall WebRtcSpl_ResetResample22khzTo8khz(_OWORD *a1)
{
  a1[7] = 0; /*0x103a46c3b*/
  a1[6] = 0; /*0x103a46c3f*/
  a1[5] = 0; /*0x103a46c43*/
  a1[4] = 0; /*0x103a46c47*/
  a1[3] = 0; /*0x103a46c4b*/
  a1[2] = 0; /*0x103a46c4f*/
  a1[1] = 0; /*0x103a46c53*/
  *a1 = 0; /*0x103a46c57*/
}

// Address: 0x103a46c5c | Name: _WebRtcSpl_Resample8khzTo22khz
__int64 __fastcall WebRtcSpl_Resample8khzTo22khz(__int64 a1, __int64 a2, _DWORD *a3, _DWORD *a4)
{
  char v8; // r13
  __int64 result; // rax
  bool v10; // zf
  _DWORD *v11; // [rsp+0h] [rbp-40h]
  _DWORD *v12; // [rsp+8h] [rbp-38h]
  _DWORD *v13; // [rsp+10h] [rbp-30h]

  v11 = a4 + 18; /*0x103a46c7d*/
  v12 = a4 + 10; /*0x103a46c85*/
  v13 = a3 + 16; /*0x103a46c8d*/
  v8 = 1; /*0x103a46c91*/
  do /*0x103a46d6a*/
  {
    WebRtcSpl_UpBy2ShortToInt(a1, a2: 40, a3: v11, a4: a3); /*0x103a46ca3*/
    a4[10] = a3[8]; /*0x103a46cac*/
    a4[11] = a3[9]; /*0x103a46cb3*/
    a4[12] = a3[10]; /*0x103a46cba*/
    a4[13] = a3[11]; /*0x103a46cc1*/
    a4[14] = a3[12]; /*0x103a46cc8*/
    a4[15] = a3[13]; /*0x103a46ccf*/
    a4[16] = a3[14]; /*0x103a46cd6*/
    a4[17] = a3[15]; /*0x103a46cdd*/
    a3[8] = a4[90]; /*0x103a46ce6*/
    a3[9] = a4[91]; /*0x103a46cf0*/
    a3[10] = a4[92]; /*0x103a46cfa*/
    a3[11] = a4[93]; /*0x103a46d04*/
    a3[12] = a4[94]; /*0x103a46d0e*/
    a3[13] = a4[95]; /*0x103a46d18*/
    a3[14] = a4[96]; /*0x103a46d22*/
    a3[15] = a4[97]; /*0x103a46d2c*/
    WebRtcSpl_32khzTo22khzIntToInt(a1: v12, a2: a4, a3: 5); /*0x103a46d3c*/
    result = WebRtcSpl_UpBy2IntToShort(a1: a4, a2: 55, a3: a2, a4: v13); /*0x103a46d50*/
    a1 += 80; /*0x103a46d55*/
    a2 += 220; /*0x103a46d59*/
    v10 = (v8 & 1) == 0; /*0x103a46d60*/
    v8 = 0; /*0x103a46d64*/
  }
  while ( !v10 ); /*0x103a46d6a*/
  return result; /*0x103a46d70*/
}

// Address: 0x103a46d7f | Name: _WebRtcSpl_32khzTo22khzIntToInt
__int64 __fastcall WebRtcSpl_32khzTo22khzIntToInt(__int64 a1, int *a2, int a3)
{
  int i; // ebx
  __int64 v6; // rdi
  __int64 result; // rax

  if ( a3 > 0 ) /*0x103a46d81*/
  {
    for ( i = a3; i != 0; --i ) /*0x103a46d95*/
    {
      *a2 = (*(_DWORD *)(a1 + 12) << 15) | 0x4000; /*0x103a46db4*/
      WebRtcSpl_DotProdIntToInt(a1, a2: a1 + 88, a3: &kCoefficients32To22, a4: a2 + 1, a5: a2 + 10); /*0x103a46dcd*/
      WebRtcSpl_DotProdIntToInt(a1: a1 + 8, a2: a1 + 80, a3: &unk_10958E182, a4: a2 + 2, a5: a2 + 9); /*0x103a46de9*/
      WebRtcSpl_DotProdIntToInt(a1: a1 + 12, a2: a1 + 76, a3: &unk_10958E194, a4: a2 + 3, a5: a2 + 8); /*0x103a46e04*/
      WebRtcSpl_DotProdIntToInt(a1: a1 + 20, a2: a1 + 68, a3: &unk_10958E1A6, a4: a2 + 4, a5: a2 + 7); /*0x103a46e20*/
      v6 = a1 + 24; /*0x103a46e25*/
      a1 += 64; /*0x103a46e29*/
      result = WebRtcSpl_DotProdIntToInt(a1: v6, a2: a1, a3: &unk_10958E1B8, a4: a2 + 5, a5: a2 + 6); /*0x103a46e3b*/
      a2 += 11; /*0x103a46e40*/
    }
  }
  return result; /*0x103a46e5a*/
}

// Address: 0x103a46e5b | Name: _WebRtcSpl_ResetResample8khzTo22khz
void __fastcall WebRtcSpl_ResetResample8khzTo22khz(_OWORD *a1)
{
  a1[5] = 0; /*0x103a46e62*/
  a1[4] = 0; /*0x103a46e66*/
  a1[3] = 0; /*0x103a46e6a*/
  a1[2] = 0; /*0x103a46e6e*/
  a1[1] = 0; /*0x103a46e72*/
  *a1 = 0; /*0x103a46e76*/
}

// Address: 0x103a46e7b | Name: _WebRtcSpl_DotProdIntToInt
__int64 __fastcall WebRtcSpl_DotProdIntToInt(const __m128i *a1, __int64 a2, __m64 *a3, _DWORD *a4, _DWORD *a5)
{
  __m128i v5; // xmm0
  __m128i v6; // xmm1
  __m128i v7; // xmm3
  __m128i v8; // xmm2
  __int32 v9; // eax
  __m128i v10; // xmm3
  __m128i v11; // xmm2
  __int64 result; // rax

  v5 = _mm_cvtepi16_epi32(a3[1]); /*0x103a46e7f*/
  v6 = _mm_cvtepi16_epi32(*a3); /*0x103a46e85*/
  v7 = _mm_hadd_epi32(_mm_mullo_epi32(_mm_loadu_si128(a1 + 1), v5), _mm_mullo_epi32(_mm_loadu_si128(a1), v6)); /*0x103a46e9d*/
  v8 = _mm_hadd_epi32( /*0x103a46ec0*/
         _mm_mullo_epi32(_mm_shuffle_epi32(_mm_loadu_si128((const __m128i *)(a2 - 28)), 27), v5),
         _mm_mullo_epi32(_mm_shuffle_epi32(_mm_loadu_si128((const __m128i *)(a2 - 12)), 27), v6));
  v9 = a3[2].i32[0]; /*0x103a46ec5*/
  v10 = _mm_hadd_epi32(v7, v7); /*0x103a46ec9*/
  *a4 = _mm_cvtsi128_si32(_mm_hadd_epi32(v10, v10)) + v9 * a1[2].i32[0] + 0x4000; /*0x103a46ee8*/
  v11 = _mm_hadd_epi32(v8, v8); /*0x103a46eee*/
  result = (unsigned int)(_mm_cvtsi128_si32(_mm_hadd_epi32(v11, v11)) + *(_DWORD *)(a2 - 32) * v9 + 0x4000); /*0x103a46eff*/
  *a5 = result; /*0x103a46f01*/
  return result; /*0x103a46f04*/
}

// Address: 0x103a46f06 | Name: _WebRtcSpl_DotProdIntToShort
__int64 __fastcall WebRtcSpl_DotProdIntToShort(const __m128i *a1, __int64 a2, __m64 *a3, _WORD *a4, _WORD *a5)
{
  __m128i v5; // xmm1
  __m128i v6; // xmm2
  __m128i v7; // xmm3
  __m128i v8; // xmm0
  __m128i v9; // xmm3
  __int32 v10; // eax
  int v11; // edx
  __m128i v12; // xmm0
  int v13; // eax
  int v14; // edx
  __int64 result; // rax

  v5 = _mm_cvtepi16_epi32(a3[1]); /*0x103a46f0a*/
  v6 = _mm_cvtepi16_epi32(*a3); /*0x103a46f10*/
  v7 = _mm_hadd_epi32(_mm_mullo_epi32(_mm_loadu_si128(a1 + 1), v5), _mm_mullo_epi32(_mm_loadu_si128(a1), v6)); /*0x103a46f28*/
  v8 = _mm_hadd_epi32( /*0x103a46f4b*/
         _mm_mullo_epi32(_mm_shuffle_epi32(_mm_loadu_si128((const __m128i *)(a2 - 28)), 27), v5),
         _mm_mullo_epi32(_mm_shuffle_epi32(_mm_loadu_si128((const __m128i *)(a2 - 12)), 27), v6));
  v9 = _mm_hadd_epi32(v7, v7); /*0x103a46f50*/
  v10 = a3[2].i32[0]; /*0x103a46f55*/
  v11 = v10 * a1[2].i32[0]; /*0x103a46f61*/
  v12 = _mm_hadd_epi32(v8, v8); /*0x103a46f71*/
  v13 = _mm_cvtsi128_si32(_mm_hadd_epi32(v12, v12)) + *(_DWORD *)(a2 - 32) * v10 + 0x4000; /*0x103a46f88*/
  v14 = (_mm_cvtsi128_si32(_mm_hadd_epi32(v9, v9)) + v11 + 0x4000) >> 15; /*0x103a46f8a*/
  if ( v14 >= 0x7FFF ) /*0x103a46f94*/
    v14 = 0x7FFF; /*0x103a46f94*/
  if ( v14 < -32767 ) /*0x103a46fa4*/
    LOWORD(v14) = 0x8000; /*0x103a46fa4*/
  result = (unsigned int)(v13 >> 15); /*0x103a46fa8*/
  if ( (int)result >= 0x7FFF ) /*0x103a46fad*/
    result = 0x7FFF; /*0x103a46fad*/
  if ( (int)result < -32767 ) /*0x103a46fb2*/
    result = 4294934528LL; /*0x103a46fb2*/
  *a4 = v14; /*0x103a46fb6*/
  *a5 = result; /*0x103a46fb9*/
  return result; /*0x103a46fbd*/
}

// Address: 0x103a46fbf | Name: _WebRtcSpl_Resample48khzTo16khz
__int64 __fastcall WebRtcSpl_Resample48khzTo16khz(__int64 a1, __int64 a2, __int64 a3, _OWORD *a4)
{
  __int128 v7; // xmm0
  __int128 v8; // xmm1

  WebRtcSpl_LPBy2ShortToInt(a1, a2: 480, a3: a4 + 4, a4: a3); /*0x103a46fde*/
  v7 = *(_OWORD *)(a3 + 64); /*0x103a46fe7*/
  a4[3] = *(_OWORD *)(a3 + 80); /*0x103a46fef*/
  a4[2] = v7; /*0x103a46ff4*/
  v8 = a4[123]; /*0x103a47001*/
  *(_OWORD *)(a3 + 64) = a4[122]; /*0x103a47009*/
  *(_OWORD *)(a3 + 80) = v8; /*0x103a4700d*/
  WebRtcSpl_Resample48khzTo32khz(a1: a4 + 2, a2: a4, a3: 160); /*0x103a47019*/
  return WebRtcSpl_DownBy2IntToShort(a1: a4, a2: 320, a3: a2, a4: a3 + 96); /*0x103a47034*/
}

// Address: 0x103a4703f | Name: _WebRtcSpl_ResetResample48khzTo16khz
void __fastcall WebRtcSpl_ResetResample48khzTo16khz(_OWORD *a1)
{
  a1[3] = 0; /*0x103a47046*/
  a1[2] = 0; /*0x103a4704a*/
  a1[1] = 0; /*0x103a4704e*/
  *a1 = 0; /*0x103a47052*/
  a1[4] = 0; /*0x103a47055*/
  a1[5] = 0; /*0x103a47059*/
  a1[6] = 0; /*0x103a4705d*/
  a1[7] = 0; /*0x103a47061*/
}

// Address: 0x103a47067 | Name: _WebRtcSpl_Resample16khzTo48khz
__int64 __fastcall WebRtcSpl_Resample16khzTo48khz(__int64 a1, __int64 a2, __int64 a3, _OWORD *a4)
{
  __int128 v7; // xmm0
  __int128 v8; // xmm1

  WebRtcSpl_UpBy2ShortToInt(a1, a2: 160, a3: a4 + 4, a4: a3); /*0x103a47086*/
  v7 = *(_OWORD *)(a3 + 32); /*0x103a4708f*/
  a4[3] = *(_OWORD *)(a3 + 48); /*0x103a47097*/
  a4[2] = v7; /*0x103a4709c*/
  v8 = a4[83]; /*0x103a470a9*/
  *(_OWORD *)(a3 + 32) = a4[82]; /*0x103a470b1*/
  *(_OWORD *)(a3 + 48) = v8; /*0x103a470b5*/
  WebRtcSpl_Resample32khzTo24khz(a1: a4 + 2, a2: a4, a3: 80); /*0x103a470c1*/
  return WebRtcSpl_UpBy2IntToShort(a1: a4, a2: 240, a3: a2, a4: a3 + 64); /*0x103a470dc*/
}

// Address: 0x103a470e7 | Name: _WebRtcSpl_ResetResample16khzTo48khz
void __fastcall WebRtcSpl_ResetResample16khzTo48khz(_OWORD *a1)
{
  a1[1] = 0; /*0x103a470ee*/
  *a1 = 0; /*0x103a470f2*/
  a1[2] = 0; /*0x103a470f5*/
  a1[3] = 0; /*0x103a470f9*/
  a1[4] = 0; /*0x103a470fd*/
  a1[5] = 0; /*0x103a47101*/
}

// Address: 0x103a47107 | Name: _WebRtcSpl_Resample48khzTo8khz
__int64 __fastcall WebRtcSpl_Resample48khzTo8khz(__int64 a1, __int64 a2, __int64 a3, _OWORD *a4)
{
  _OWORD *v7; // r12
  __int128 v8; // xmm0
  __int128 v9; // xmm1

  v7 = a4 + 64; /*0x103a4711b*/
  WebRtcSpl_DownBy2ShortToInt(a1, a2: 480, a3: a4 + 64, a4: a3); /*0x103a4712d*/
  WebRtcSpl_LPBy2IntToInt(a1: v7, a2: 240, a3: a4 + 4, a4: a3 + 32); /*0x103a47142*/
  v8 = *(_OWORD *)(a3 + 96); /*0x103a4714b*/
  a4[3] = *(_OWORD *)(a3 + 112); /*0x103a47153*/
  a4[2] = v8; /*0x103a47158*/
  v9 = a4[63]; /*0x103a47165*/
  *(_OWORD *)(a3 + 96) = a4[62]; /*0x103a4716d*/
  *(_OWORD *)(a3 + 112) = v9; /*0x103a47171*/
  WebRtcSpl_Resample48khzTo32khz(a1: a4 + 2, a2: a4, a3: 80); /*0x103a4717d*/
  return WebRtcSpl_DownBy2IntToShort(a1: a4, a2: 160, a3: a2, a4: a3 + 128); /*0x103a47194*/
}

// Address: 0x103a471a1 | Name: _WebRtcSpl_ResetResample48khzTo8khz
void __fastcall WebRtcSpl_ResetResample48khzTo8khz(_OWORD *a1)
{
  a1[1] = 0; /*0x103a471a8*/
  *a1 = 0; /*0x103a471ac*/
  a1[2] = 0; /*0x103a471af*/
  a1[3] = 0; /*0x103a471b3*/
  a1[4] = 0; /*0x103a471b7*/
  a1[5] = 0; /*0x103a471bb*/
  a1[6] = 0; /*0x103a471bf*/
  a1[7] = 0; /*0x103a471c3*/
  a1[8] = 0; /*0x103a471c7*/
  a1[9] = 0; /*0x103a471ce*/
}

// Address: 0x103a471d7 | Name: _WebRtcSpl_Resample8khzTo48khz
__int64 __fastcall WebRtcSpl_Resample8khzTo48khz(__int64 a1, __int64 a2, __int64 a3, _OWORD *a4)
{
  __int128 v7; // xmm0
  __int128 v8; // xmm1

  WebRtcSpl_UpBy2ShortToInt(a1, a2: 80, a3: a4 + 66, a4: a3); /*0x103a471fa*/
  v7 = *(_OWORD *)(a3 + 32); /*0x103a47206*/
  a4[65] = *(_OWORD *)(a3 + 48); /*0x103a4720e*/
  a4[64] = v7; /*0x103a47216*/
  v8 = a4[105]; /*0x103a47226*/
  *(_OWORD *)(a3 + 32) = a4[104]; /*0x103a4722e*/
  *(_OWORD *)(a3 + 48) = v8; /*0x103a47232*/
  WebRtcSpl_Resample32khzTo24khz(a1: a4 + 64, a2: a4 + 60, a3: 40); /*0x103a47245*/
  WebRtcSpl_UpBy2IntToInt(a1: a4 + 60, a2: 120, a3: a4, a4: a3 + 64); /*0x103a47259*/
  return WebRtcSpl_UpBy2IntToShort(a1: a4, a2: 240, a3: a2, a4: a3 + 96); /*0x103a47270*/
}

// Address: 0x103a4727d | Name: _WebRtcSpl_ResetResample8khzTo48khz
void __fastcall WebRtcSpl_ResetResample8khzTo48khz(_OWORD *a1)
{
  a1[1] = 0; /*0x103a47284*/
  *a1 = 0; /*0x103a47288*/
  a1[2] = 0; /*0x103a4728b*/
  a1[3] = 0; /*0x103a4728f*/
  a1[4] = 0; /*0x103a47293*/
  a1[5] = 0; /*0x103a47297*/
  a1[6] = 0; /*0x103a4729b*/
  a1[7] = 0; /*0x103a4729f*/
}

// Address: 0x103a472a5 | Name: _WebRtcSpl_DownsampleBy2
__int64 __fastcall WebRtcSpl_DownsampleBy2(__int64 a1, unsigned __int64 a2, __int64 a3, int *a4)
{
  int v4; // r9d
  unsigned int v5; // edi
  unsigned int v6; // edx
  unsigned int v7; // r8d
  int v8; // r15d
  unsigned int v9; // r12d
  unsigned int v10; // r13d
  __int64 result; // rax
  __int64 v12; // r11
  unsigned int v13; // r10d
  unsigned int v14; // ebx
  unsigned int v15; // ecx
  unsigned int v16; // esi
  int v17; // ecx
  unsigned __int64 v20; // [rsp+10h] [rbp-40h]
  int v22; // [rsp+20h] [rbp-30h]
  int v23; // [rsp+24h] [rbp-2Ch]

  v4 = *a4; /*0x103a472ba*/
  v5 = a4[1]; /*0x103a472bd*/
  v6 = a4[2]; /*0x103a472c0*/
  v7 = a4[3]; /*0x103a472c3*/
  v8 = a4[4]; /*0x103a472c7*/
  v9 = a4[5]; /*0x103a472cb*/
  v10 = a4[6]; /*0x103a472cf*/
  result = (unsigned int)a4[7]; /*0x103a472d7*/
  if ( a2 >= 2 ) /*0x103a472de*/
  {
    v12 = 0; /*0x103a472e7*/
    v20 = a2 >> 1; /*0x103a472ea*/
    do /*0x103a4743d*/
    {
      v13 = v5; /*0x103a472f4*/
      v14 = v6; /*0x103a472f7*/
      v23 = v8; /*0x103a472f9*/
      v15 = v9; /*0x103a472fd*/
      v22 = *(__int16 *)(a1 + 4 * v12) << 10; /*0x103a4730c*/
      v5 = v4 + 12199 * ((int)(v22 - v5) >> 16) + ((12199 * (unsigned int)(unsigned __int16)(v22 - v5)) >> 16); /*0x103a4732c*/
      v6 = v13 + 37471 * ((int)(v5 - v6) >> 16) + ((37471 * (unsigned int)(unsigned __int16)(v5 - v6)) >> 16); /*0x103a47350*/
      v7 = v14 + 60255 * ((int)(v6 - v7) >> 16) + ((60255 * (unsigned int)(unsigned __int16)(v6 - v7)) >> 16); /*0x103a47378*/
      v8 = *(__int16 *)(a1 + 4 * v12 + 2) << 10; /*0x103a47381*/
      v9 = v23 /*0x103a473ab*/
         + 3284 * ((int)(v8 - v9) >> 16)
         + ((3284 * (unsigned int)(unsigned __int16)((*(_WORD *)(a1 + 4 * v12 + 2) << 10) - v9)) >> 16);
      v16 = v10; /*0x103a473b1*/
      v10 = v15 + 24441 * ((int)(v9 - v10) >> 16) + ((24441 * (unsigned int)(unsigned __int16)(v9 - v10)) >> 16); /*0x103a473d6*/
      result = v16 /*0x103a473f9*/
             + 49528 * ((int)(v10 - result) >> 16)
             + ((49528 * (unsigned int)(unsigned __int16)(v10 - result)) >> 16);
      v17 = (int)(v7 + result + 1024) >> 11; /*0x103a47406*/
      if ( v17 < -32767 ) /*0x103a4740f*/
        v17 = -32768; /*0x103a47411*/
      if ( v17 >= 0x7FFF ) /*0x103a4741f*/
        LOWORD(v17) = 0x7FFF; /*0x103a47421*/
      *(_WORD *)(a3 + 2 * v12++) = v17; /*0x103a4742a*/
      v4 = v22; /*0x103a47439*/
    }
    while ( v20 != v12 ); /*0x103a4743d*/
  }
  *a4 = v4; /*0x103a47447*/
  a4[1] = v5; /*0x103a4744a*/
  a4[2] = v6; /*0x103a4744d*/
  a4[3] = v7; /*0x103a47450*/
  a4[4] = v8; /*0x103a47454*/
  a4[5] = v9; /*0x103a47458*/
  a4[6] = v10; /*0x103a4745c*/
  a4[7] = result; /*0x103a47460*/
  return result; /*0x103a47463*/
}

// Address: 0x103a4746e | Name: _WebRtcSpl_UpsampleBy2
__int64 __fastcall WebRtcSpl_UpsampleBy2(__int64 a1, __int64 a2, __int64 a3, int *a4)
{
  int v4; // r9d
  unsigned int v5; // r10d
  unsigned int v6; // r14d
  __int64 result; // rax
  int v8; // r15d
  unsigned int v9; // edi
  int v10; // r12d
  unsigned int v11; // r8d
  __int64 v12; // r11
  int v13; // r13d
  unsigned int v14; // ebx
  unsigned int v15; // ecx
  int v16; // ecx
  unsigned int v17; // ecx
  unsigned int v18; // esi
  int v19; // r15d
  int v20; // r13d
  int v21; // edi

  v4 = *a4; /*0x103a47483*/
  v5 = a4[1]; /*0x103a47486*/
  v6 = a4[2]; /*0x103a4748a*/
  result = (unsigned int)a4[3]; /*0x103a4748e*/
  v8 = a4[4]; /*0x103a47491*/
  v9 = a4[5]; /*0x103a47495*/
  v10 = a4[6]; /*0x103a47498*/
  v11 = a4[7]; /*0x103a474a0*/
  if ( a2 != 0 ) /*0x103a474ab*/
  {
    v12 = 0; /*0x103a474b1*/
    do /*0x103a4761b*/
    {
      v13 = v4; /*0x103a474b9*/
      v14 = v5; /*0x103a474bc*/
      v15 = v6; /*0x103a474bf*/
      v4 = *(__int16 *)(a1 + 2 * v12) << 10; /*0x103a474cb*/
      v5 = v13 + 3284 * ((int)(v4 - v5) >> 16) + ((3284 * (unsigned int)(unsigned __int16)(v4 - v5)) >> 16); /*0x103a474f4*/
      v6 = v14 + 24441 * ((int)(v5 - v6) >> 16) + ((24441 * (unsigned int)(unsigned __int16)(v5 - v6)) >> 16); /*0x103a4751c*/
      result = v15 /*0x103a4753e*/
             + 49528 * ((int)(v6 - result) >> 16)
             + ((49528 * (unsigned int)(unsigned __int16)(v6 - result)) >> 16);
      v16 = ((int)result + 512) >> 10; /*0x103a47548*/
      if ( v16 < -32767 ) /*0x103a47552*/
        v16 = -32768; /*0x103a47554*/
      if ( v16 >= 0x7FFF ) /*0x103a47560*/
        LOWORD(v16) = 0x7FFF; /*0x103a47562*/
      *(_WORD *)(a3 + 4 * v12) = v16; /*0x103a4756b*/
      v17 = v8 + 12199 * ((int)(v4 - v9) >> 16) + ((12199 * (unsigned int)(unsigned __int16)(v4 - v9)) >> 16); /*0x103a47591*/
      v18 = v9 + 37471 * ((int)(v17 - v10) >> 16); /*0x103a475a8*/
      v19 = (unsigned __int16)(v17 - v10); /*0x103a475aa*/
      v20 = v18 + ((unsigned int)(37471 * v19) >> 16); /*0x103a475b8*/
      v11 = v10 /*0x103a475dc*/
          + 60255 * ((int)(v20 - v11) >> 16)
          + ((60255
            * (unsigned int)(unsigned __int16)(v9
                                             - 28065 * ((v17 - v10) >> 16)
                                             + ((unsigned int)(37471 * v19) >> 16)
                                             - v11)) >> 16);
      v21 = (int)(v11 + 512) >> 10; /*0x103a475e8*/
      if ( v21 < -32767 ) /*0x103a475f2*/
        v21 = -32768; /*0x103a475f4*/
      if ( v21 >= 0x7FFF ) /*0x103a475fb*/
        LOWORD(v21) = 0x7FFF; /*0x103a475fd*/
      *(_WORD *)(a3 + 4 * v12++ + 2) = v21; /*0x103a47606*/
      v10 = v18 + ((unsigned int)(37471 * v19) >> 16); /*0x103a4760f*/
      v9 = v17; /*0x103a47612*/
      v8 = v4; /*0x103a47614*/
    }
    while ( a2 != v12 ); /*0x103a4761b*/
  }
  else
  {
    v17 = a4[5]; /*0x103a47623*/
    v20 = v10; /*0x103a47625*/
  }
  *a4 = v4; /*0x103a4762c*/
  a4[1] = v5; /*0x103a4762f*/
  a4[2] = v6; /*0x103a47633*/
  a4[3] = result; /*0x103a47637*/
  a4[4] = v8; /*0x103a4763a*/
  a4[5] = v17; /*0x103a4763e*/
  a4[6] = v20; /*0x103a47641*/
  a4[7] = v11; /*0x103a47645*/
  return result; /*0x103a47649*/
}

// Address: 0x103a47654 | Name: _WebRtcSpl_DownBy2IntToShort
void __fastcall WebRtcSpl_DownBy2IntToShort(__int64 a1, int a2, __int64 a3, _DWORD *a4)
{
  int v4; // esi
  unsigned __int64 v5; // rax
  __int64 i; // rsi
  int v7; // r9d
  int v8; // r8d
  int v9; // r11d
  int v10; // r10d
  int v11; // r9d
  __int64 j; // rsi
  int v13; // r9d
  int v14; // r8d
  int v15; // r11d
  int v16; // r10d
  int v17; // r9d
  unsigned __int64 k; // rcx
  int v19; // r8d
  int v20; // r10d

  v4 = a2 >> 1; /*0x103a47658*/
  if ( v4 > 0 ) /*0x103a4765c*/
  {
    v5 = (unsigned int)v4; /*0x103a47662*/
    for ( i = 0; i != v5; ++i ) /*0x103a47664*/
    {
      v7 = a4[1]; /*0x103a4766a*/
      v8 = a4[2]; /*0x103a4766e*/
      v9 = *a4 + 3050 * ((*(_DWORD *)(a1 + 8 * i) - v7 + 0x2000) >> 14); /*0x103a4768a*/
      *a4 = *(_DWORD *)(a1 + 8 * i); /*0x103a4768d*/
      a4[1] = v9; /*0x103a47690*/
      v10 = v7 + 9368 * (((v9 - v8) >> 14) + ((unsigned int)(v9 - v8) >> 31)); /*0x103a476ac*/
      v11 = v8 + 15063 * (((v10 - a4[3]) >> 14) + ((unsigned int)(v10 - a4[3]) >> 31)); /*0x103a476cb*/
      a4[3] = v11; /*0x103a476ce*/
      a4[2] = v10; /*0x103a476d2*/
      *(_DWORD *)(a1 + 8 * i) = v11 >> 1; /*0x103a476d9*/
    }
    for ( j = 0; j != v5; ++j ) /*0x103a476e5*/
    {
      v13 = a4[5]; /*0x103a476ec*/
      v14 = a4[6]; /*0x103a476f0*/
      v15 = a4[4] + 821 * ((*(_DWORD *)(a1 + 8 * j + 4) - v13 + 0x2000) >> 14); /*0x103a4770c*/
      a4[4] = *(_DWORD *)(a1 + 8 * j + 4); /*0x103a47710*/
      a4[5] = v15; /*0x103a47714*/
      v16 = v13 + 6110 * (((v15 - v14) >> 14) + ((unsigned int)(v15 - v14) >> 31)); /*0x103a47730*/
      v17 = v14 + 12382 * (((v16 - a4[7]) >> 14) + ((unsigned int)(v16 - a4[7]) >> 31)); /*0x103a4774f*/
      a4[7] = v17; /*0x103a47752*/
      a4[6] = v16; /*0x103a47756*/
      *(_DWORD *)(a1 + 8 * j + 4) = v17 >> 1; /*0x103a4775d*/
    }
    for ( k = 0; k < v5; k += 2LL ) /*0x103a4776e*/
    {
      v19 = (*(_DWORD *)(a1 + 8 * k) + *(_DWORD *)(a1 + 8 * k + 4)) >> 15; /*0x103a47784*/
      if ( v19 >= 0x7FFF ) /*0x103a4778b*/
        v19 = 0x7FFF; /*0x103a4778d*/
      if ( v19 < -32767 ) /*0x103a47796*/
        LOWORD(v19) = 0x8000; /*0x103a47798*/
      v20 = (*(_DWORD *)(a1 + 8 * k + 8) + *(_DWORD *)(a1 + 8 * k + 12)) >> 15; /*0x103a477a8*/
      *(_WORD *)(a3 + 2 * k) = v19; /*0x103a477ac*/
      if ( v20 >= 0x7FFF ) /*0x103a477b4*/
        v20 = 0x7FFF; /*0x103a477b6*/
      if ( v20 < -32767 ) /*0x103a477bf*/
        LOWORD(v20) = 0x8000; /*0x103a477c1*/
      *(_WORD *)(a3 + 2 * k + 2) = v20; /*0x103a477c7*/
    }
  }
}

// Address: 0x103a477d8 | Name: _WebRtcSpl_DownBy2ShortToInt
void __fastcall WebRtcSpl_DownBy2ShortToInt(__int64 a1, int a2, __int64 a3, int *a4)
{
  int v4; // esi
  __int64 v5; // rax
  __int64 i; // rsi
  int v7; // r9d
  int v8; // r8d
  int v9; // r11d
  int v10; // r10d
  int v11; // r9d
  __int64 j; // rsi
  int v13; // r9d
  int v14; // r8d
  int v15; // r11d
  int v16; // r10d
  int v17; // r9d

  v4 = a2 >> 1; /*0x103a477dc*/
  if ( v4 > 0 ) /*0x103a477e0*/
  {
    v5 = (unsigned int)v4; /*0x103a477e6*/
    for ( i = 0; i != v5; ++i ) /*0x103a477e8*/
    {
      v7 = a4[1]; /*0x103a477fa*/
      v8 = a4[2]; /*0x103a477fe*/
      v9 = *a4 + 3050 * ((((*(__int16 *)(a1 + 4 * i) << 15) | 0x4000) - v7 + 0x2000) >> 14); /*0x103a4781a*/
      *a4 = (*(__int16 *)(a1 + 4 * i) << 15) | 0x4000; /*0x103a4781d*/
      a4[1] = v9; /*0x103a47820*/
      v10 = v7 + 9368 * (((v9 - v8) >> 14) + ((unsigned int)(v9 - v8) >> 31)); /*0x103a4783c*/
      v11 = v8 + 15063 * (((v10 - a4[3]) >> 14) + ((unsigned int)(v10 - a4[3]) >> 31)); /*0x103a4785b*/
      a4[3] = v11; /*0x103a4785e*/
      a4[2] = v10; /*0x103a47862*/
      *(_DWORD *)(a3 + 4 * i) = v11 >> 1; /*0x103a47869*/
    }
    for ( j = 0; j != v5; ++j ) /*0x103a47879*/
    {
      v13 = a4[5]; /*0x103a4788c*/
      v14 = a4[6]; /*0x103a47890*/
      v15 = a4[4] + 821 * ((((*(__int16 *)(a1 + 4 * j + 2) << 15) | 0x4000) - v13 + 0x2000) >> 14); /*0x103a478ac*/
      a4[4] = (*(__int16 *)(a1 + 4 * j + 2) << 15) | 0x4000; /*0x103a478b0*/
      a4[5] = v15; /*0x103a478b4*/
      v16 = v13 + 6110 * (((v15 - v14) >> 14) + ((unsigned int)(v15 - v14) >> 31)); /*0x103a478d0*/
      v17 = v14 + 12382 * (((v16 - a4[7]) >> 14) + ((unsigned int)(v16 - a4[7]) >> 31)); /*0x103a478ef*/
      a4[7] = v17; /*0x103a478f2*/
      a4[6] = v16; /*0x103a478f6*/
      *(_DWORD *)(a3 + 4 * j) += v17 >> 1; /*0x103a478fd*/
    }
  }
}

// Address: 0x103a4790f | Name: _WebRtcSpl_UpBy2ShortToInt
void __fastcall WebRtcSpl_UpBy2ShortToInt(__int64 a1, int a2, __int64 a3, int *a4)
{
  __int64 v4; // rax
  __int64 v5; // rsi
  int v6; // r9d
  int v7; // r8d
  int v8; // r11d
  int v9; // r10d
  int v10; // r9d
  __int64 v11; // rsi
  int v12; // r9d
  int v13; // r8d
  int v14; // r11d
  int v15; // r10d
  int v16; // r9d

  if ( a2 > 0 ) /*0x103a47915*/
  {
    v4 = 2LL * (unsigned int)a2; /*0x103a4791d*/
    v5 = 0; /*0x103a47920*/
    do /*0x103a479b2*/
    {
      v6 = a4[5]; /*0x103a47932*/
      v7 = a4[6]; /*0x103a47936*/
      v8 = a4[4] + 821 * ((((*(__int16 *)(a1 + v5) << 15) | 0x4000) - v6 + 0x2000) >> 14); /*0x103a47952*/
      a4[4] = (*(__int16 *)(a1 + v5) << 15) | 0x4000; /*0x103a47956*/
      a4[5] = v8; /*0x103a4795a*/
      v9 = v6 + 6110 * (((v8 - v7) >> 14) + ((unsigned int)(v8 - v7) >> 31)); /*0x103a47976*/
      v10 = v7 + 12382 * (((v9 - a4[7]) >> 14) + ((unsigned int)(v9 - a4[7]) >> 31)); /*0x103a47995*/
      a4[7] = v10; /*0x103a47998*/
      a4[6] = v9; /*0x103a4799c*/
      *(_DWORD *)(a3 + 4LL * (int)v5) = v10 >> 15; /*0x103a479a7*/
      v5 += 2; /*0x103a479ab*/
    }
    while ( v4 != v5 ); /*0x103a479b2*/
    v11 = 0; /*0x103a479b8*/
    do /*0x103a47a49*/
    {
      v12 = a4[1]; /*0x103a479ca*/
      v13 = a4[2]; /*0x103a479ce*/
      v14 = *a4 + 3050 * ((((*(__int16 *)(a1 + v11) << 15) | 0x4000) - v12 + 0x2000) >> 14); /*0x103a479ea*/
      *a4 = (*(__int16 *)(a1 + v11) << 15) | 0x4000; /*0x103a479ed*/
      a4[1] = v14; /*0x103a479f0*/
      v15 = v12 + 9368 * (((v14 - v13) >> 14) + ((unsigned int)(v14 - v13) >> 31)); /*0x103a47a0c*/
      v16 = v13 + 15063 * (((v15 - a4[3]) >> 14) + ((unsigned int)(v15 - a4[3]) >> 31)); /*0x103a47a2b*/
      a4[3] = v16; /*0x103a47a2e*/
      a4[2] = v15; /*0x103a47a32*/
      *(_DWORD *)(a3 + 4LL * (int)v11 + 4) = v16 >> 15; /*0x103a47a3d*/
      v11 += 2; /*0x103a47a42*/
    }
    while ( v4 != v11 ); /*0x103a47a49*/
  }
}

// Address: 0x103a47a51 | Name: _WebRtcSpl_UpBy2IntToInt
void __fastcall WebRtcSpl_UpBy2IntToInt(__int64 a1, int a2, __int64 a3, _DWORD *a4)
{
  __int64 v4; // rax
  __int64 v5; // rsi
  int v6; // r9d
  int v7; // r8d
  int v8; // r11d
  int v9; // r10d
  int v10; // r9d
  __int64 v11; // rsi
  int v12; // r9d
  int v13; // r8d
  int v14; // r11d
  int v15; // r10d
  int v16; // r9d

  if ( a2 > 0 ) /*0x103a47a57*/
  {
    v4 = 2LL * (unsigned int)a2; /*0x103a47a5f*/
    v5 = 0; /*0x103a47a62*/
    do /*0x103a47ae4*/
    {
      v6 = a4[5]; /*0x103a47a68*/
      v7 = a4[6]; /*0x103a47a6c*/
      v8 = a4[4] + 821 * ((*(_DWORD *)(a1 + 2 * v5) - v6 + 0x2000) >> 14); /*0x103a47a88*/
      a4[4] = *(_DWORD *)(a1 + 2 * v5); /*0x103a47a8c*/
      a4[5] = v8; /*0x103a47a90*/
      v9 = v6 + 6110 * (((v8 - v7) >> 14) + ((unsigned int)(v8 - v7) >> 31)); /*0x103a47aac*/
      v10 = v7 + 12382 * (((v9 - a4[7]) >> 14) + ((unsigned int)(v9 - a4[7]) >> 31)); /*0x103a47acb*/
      a4[7] = v10; /*0x103a47ace*/
      a4[6] = v9; /*0x103a47ad2*/
      *(_DWORD *)(a3 + 4LL * (int)v5) = v10; /*0x103a47ad9*/
      v5 += 2; /*0x103a47add*/
    }
    while ( v4 != v5 ); /*0x103a47ae4*/
    v11 = 0; /*0x103a47aea*/
    do /*0x103a47b6b*/
    {
      v12 = a4[1]; /*0x103a47af0*/
      v13 = a4[2]; /*0x103a47af4*/
      v14 = *a4 + 3050 * ((*(_DWORD *)(a1 + 2 * v11) - v12 + 0x2000) >> 14); /*0x103a47b10*/
      *a4 = *(_DWORD *)(a1 + 2 * v11); /*0x103a47b13*/
      a4[1] = v14; /*0x103a47b16*/
      v15 = v12 + 9368 * (((v14 - v13) >> 14) + ((unsigned int)(v14 - v13) >> 31)); /*0x103a47b32*/
      v16 = v13 + 15063 * (((v15 - a4[3]) >> 14) + ((unsigned int)(v15 - a4[3]) >> 31)); /*0x103a47b51*/
      a4[3] = v16; /*0x103a47b54*/
      a4[2] = v15; /*0x103a47b58*/
      *(_DWORD *)(a3 + 4LL * (int)v11 + 4) = v16; /*0x103a47b5f*/
      v11 += 2; /*0x103a47b64*/
    }
    while ( v4 != v11 ); /*0x103a47b6b*/
  }
}

// Address: 0x103a47b73 | Name: _WebRtcSpl_UpBy2IntToShort
void __fastcall WebRtcSpl_UpBy2IntToShort(__int64 a1, int a2, __int64 a3, int *a4)
{
  int v4; // r8d
  int v5; // r10d
  int v6; // r11d
  int v7; // r9d
  __int64 v8; // rax
  __int64 v9; // rsi
  int v10; // r14d
  int v11; // r15d
  int v12; // ebx
  int v13; // ebx
  int v14; // r8d
  int v15; // r10d
  int v16; // r11d
  int v17; // r9d
  __int64 v18; // rsi
  int v19; // r14d
  int v20; // r15d
  int v21; // ebx
  int v22; // ebx

  if ( a2 > 0 ) /*0x103a47b75*/
  {
    v4 = a4[4]; /*0x103a47b84*/
    v5 = a4[5]; /*0x103a47b88*/
    v6 = a4[6]; /*0x103a47b8c*/
    v7 = a4[7]; /*0x103a47b90*/
    v8 = 2LL * (unsigned int)a2; /*0x103a47b96*/
    v9 = 0; /*0x103a47b99*/
    do /*0x103a47c41*/
    {
      v10 = v5; /*0x103a47b9b*/
      v11 = v4; /*0x103a47b9e*/
      v12 = v6; /*0x103a47ba1*/
      v4 = *(_DWORD *)(a1 + 2 * v9); /*0x103a47ba4*/
      v5 = v11 + 821 * ((v4 - v5 + 0x2000) >> 14); /*0x103a47bc0*/
      a4[4] = v4; /*0x103a47bc3*/
      v6 = v10 + 6110 * (((v5 - v6) >> 14) + ((unsigned int)(v5 - v6) >> 31)); /*0x103a47be2*/
      a4[5] = v5; /*0x103a47be5*/
      v7 = v12 + 12382 * (((v6 - v7) >> 14) + ((unsigned int)(v6 - v7) >> 31)); /*0x103a47c04*/
      a4[7] = v7; /*0x103a47c07*/
      a4[6] = v6; /*0x103a47c0b*/
      v13 = v7 >> 15; /*0x103a47c12*/
      if ( v7 >> 15 >= 0x7FFF ) /*0x103a47c1e*/
        v13 = 0x7FFF; /*0x103a47c20*/
      if ( v13 < -32767 ) /*0x103a47c2b*/
        LOWORD(v13) = 0x8000; /*0x103a47c2d*/
      *(_WORD *)(a3 + 2LL * (int)v9) = v13; /*0x103a47c35*/
      v9 += 2; /*0x103a47c3a*/
    }
    while ( v8 != v9 ); /*0x103a47c41*/
    v14 = *a4; /*0x103a47c47*/
    v15 = a4[1]; /*0x103a47c4a*/
    v16 = a4[2]; /*0x103a47c4e*/
    v17 = a4[3]; /*0x103a47c52*/
    v18 = 0; /*0x103a47c56*/
    do /*0x103a47cfe*/
    {
      v19 = v15; /*0x103a47c58*/
      v20 = v14; /*0x103a47c5b*/
      v21 = v16; /*0x103a47c5e*/
      v14 = *(_DWORD *)(a1 + 2 * v18); /*0x103a47c61*/
      v15 = v20 + 3050 * ((v14 - v15 + 0x2000) >> 14); /*0x103a47c7d*/
      *a4 = v14; /*0x103a47c80*/
      v16 = v19 + 9368 * (((v15 - v16) >> 14) + ((unsigned int)(v15 - v16) >> 31)); /*0x103a47c9e*/
      a4[1] = v15; /*0x103a47ca1*/
      v17 = v21 + 15063 * (((v16 - v17) >> 14) + ((unsigned int)(v16 - v17) >> 31)); /*0x103a47cc0*/
      a4[3] = v17; /*0x103a47cc3*/
      a4[2] = v16; /*0x103a47cc7*/
      v22 = v17 >> 15; /*0x103a47cce*/
      if ( v17 >> 15 >= 0x7FFF ) /*0x103a47cda*/
        v22 = 0x7FFF; /*0x103a47cdc*/
      if ( v22 < -32767 ) /*0x103a47ce7*/
        LOWORD(v22) = 0x8000; /*0x103a47ce9*/
      *(_WORD *)(a3 + 2LL * (int)v18 + 2) = v22; /*0x103a47cf1*/
      v18 += 2; /*0x103a47cf7*/
    }
    while ( v8 != v18 ); /*0x103a47cfe*/
  }
}

// Address: 0x103a47d0b | Name: _WebRtcSpl_LPBy2ShortToInt
void __fastcall WebRtcSpl_LPBy2ShortToInt(__int64 a1, int a2, __int64 a3, int *a4)
{
  int v4; // esi
  int v5; // r9d
  __int64 v6; // rax
  __int64 i; // rsi
  int v8; // r10d
  int v9; // r8d
  int v10; // r11d
  int v11; // r9d
  int v12; // r10d
  __int64 j; // rsi
  int v14; // r9d
  int v15; // r8d
  int v16; // r11d
  int v17; // r10d
  int v18; // r9d
  __int64 k; // rsi
  int v20; // r9d
  int v21; // r8d
  int v22; // r11d
  int v23; // r10d
  int v24; // r9d
  __int64 m; // rsi
  int v26; // r9d
  int v27; // r8d
  int v28; // r11d
  int v29; // r10d
  int v30; // r9d

  v4 = a2 >> 1; /*0x103a47d0f*/
  if ( v4 > 0 ) /*0x103a47d13*/
  {
    v5 = a4[12]; /*0x103a47d19*/
    v6 = (unsigned int)v4; /*0x103a47d1d*/
    for ( i = 0; i != v6; ++i ) /*0x103a47d1f*/
    {
      v8 = a4[1]; /*0x103a47d21*/
      v9 = a4[2]; /*0x103a47d25*/
      v10 = *a4 + 3050 * ((v5 - v8 + 0x2000) >> 14); /*0x103a47d41*/
      *a4 = v5; /*0x103a47d44*/
      a4[1] = v10; /*0x103a47d47*/
      v11 = v8 + 9368 * (((v10 - v9) >> 14) + ((unsigned int)(v10 - v9) >> 31)); /*0x103a47d63*/
      v12 = v9 + 15063 * (((v11 - a4[3]) >> 14) + ((unsigned int)(v11 - a4[3]) >> 31)); /*0x103a47d82*/
      a4[3] = v12; /*0x103a47d85*/
      a4[2] = v11; /*0x103a47d89*/
      *(_DWORD *)(a3 + 8 * i) = v12 >> 1; /*0x103a47d90*/
      v5 = (*(__int16 *)(a1 + 4 * i + 2) << 15) | 0x4000; /*0x103a47d9e*/
    }
    for ( j = 0; j != v6; ++j ) /*0x103a47db1*/
    {
      v14 = a4[5]; /*0x103a47dc3*/
      v15 = a4[6]; /*0x103a47dc7*/
      v16 = a4[4] + 821 * ((((*(__int16 *)(a1 + 4 * j) << 15) | 0x4000) - v14 + 0x2000) >> 14); /*0x103a47de3*/
      a4[4] = (*(__int16 *)(a1 + 4 * j) << 15) | 0x4000; /*0x103a47de7*/
      a4[5] = v16; /*0x103a47deb*/
      v17 = v14 + 6110 * (((v16 - v15) >> 14) + ((unsigned int)(v16 - v15) >> 31)); /*0x103a47e07*/
      v18 = v15 + 12382 * (((v17 - a4[7]) >> 14) + ((unsigned int)(v17 - a4[7]) >> 31)); /*0x103a47e26*/
      a4[7] = v18; /*0x103a47e29*/
      a4[6] = v17; /*0x103a47e2d*/
      *(_DWORD *)(a3 + 8 * j) = (*(_DWORD *)(a3 + 8 * j) + (v18 >> 1)) >> 15; /*0x103a47e3c*/
    }
    for ( k = 0; k != v6; ++k ) /*0x103a47e4c*/
    {
      v20 = a4[9]; /*0x103a47e5e*/
      v21 = a4[10]; /*0x103a47e62*/
      v22 = a4[8] + 3050 * ((((*(__int16 *)(a1 + 4 * k) << 15) | 0x4000) - v20 + 0x2000) >> 14); /*0x103a47e7e*/
      a4[8] = (*(__int16 *)(a1 + 4 * k) << 15) | 0x4000; /*0x103a47e82*/
      a4[9] = v22; /*0x103a47e86*/
      v23 = v20 + 9368 * (((v22 - v21) >> 14) + ((unsigned int)(v22 - v21) >> 31)); /*0x103a47ea2*/
      v24 = v21 + 15063 * (((v23 - a4[11]) >> 14) + ((unsigned int)(v23 - a4[11]) >> 31)); /*0x103a47ec1*/
      a4[11] = v24; /*0x103a47ec4*/
      a4[10] = v23; /*0x103a47ec8*/
      *(_DWORD *)(a3 + 8 * k + 4) = v24 >> 1; /*0x103a47ecf*/
    }
    for ( m = 0; m != v6; ++m ) /*0x103a47ee0*/
    {
      v26 = a4[13]; /*0x103a47ef3*/
      v27 = a4[14]; /*0x103a47ef7*/
      v28 = a4[12] + 821 * ((((*(__int16 *)(a1 + 4 * m + 2) << 15) | 0x4000) - v26 + 0x2000) >> 14); /*0x103a47f13*/
      a4[12] = (*(__int16 *)(a1 + 4 * m + 2) << 15) | 0x4000; /*0x103a47f17*/
      a4[13] = v28; /*0x103a47f1b*/
      v29 = v26 + 6110 * (((v28 - v27) >> 14) + ((unsigned int)(v28 - v27) >> 31)); /*0x103a47f37*/
      v30 = v27 + 12382 * (((v29 - a4[15]) >> 14) + ((unsigned int)(v29 - a4[15]) >> 31)); /*0x103a47f56*/
      a4[15] = v30; /*0x103a47f59*/
      a4[14] = v29; /*0x103a47f5d*/
      *(_DWORD *)(a3 + 8 * m + 4) = (*(_DWORD *)(a3 + 8 * m + 4) + (v30 >> 1)) >> 15; /*0x103a47f6d*/
    }
  }
}

// Address: 0x103a47f80 | Name: _WebRtcSpl_LPBy2IntToInt
void __fastcall WebRtcSpl_LPBy2IntToInt(__int64 a1, int a2, __int64 a3, _DWORD *a4)
{
  int v4; // esi
  __int64 v5; // rax
  int *v6; // r10
  __int64 v7; // r9
  int v8; // ebx
  int v9; // r11d
  int v10; // r10d
  int v11; // r14d
  int v12; // ebx
  int v13; // r11d
  __int64 i; // r8
  int v15; // r10d
  int v16; // r9d
  int v17; // ebx
  int v18; // r11d
  int v19; // r10d
  __int64 j; // r8
  int v21; // r10d
  int v22; // r9d
  int v23; // ebx
  int v24; // r11d
  int v25; // r10d
  __int64 k; // rdi
  int v27; // r9d
  int v28; // r8d
  int v29; // r11d
  int v30; // r10d
  int v31; // r9d

  v4 = a2 >> 1; /*0x103a47f80*/
  if ( v4 > 0 ) /*0x103a47f84*/
  {
    v5 = a1 + 4; /*0x103a47f91*/
    v6 = a4 + 12; /*0x103a47f95*/
    v7 = 0; /*0x103a47fa3*/
    do /*0x103a48024*/
    {
      v8 = *v6; /*0x103a47fa6*/
      v9 = a4[1]; /*0x103a47fa9*/
      v10 = a4[2]; /*0x103a47fad*/
      v11 = *a4 + 3050 * ((v8 - v9 + 0x2000) >> 14); /*0x103a47fc9*/
      *a4 = v8; /*0x103a47fcc*/
      a4[1] = v11; /*0x103a47fce*/
      v12 = v9 + 9368 * (((v11 - v10) >> 14) + ((unsigned int)(v11 - v10) >> 31)); /*0x103a47fe9*/
      v13 = v10 + 15063 * (((v12 - a4[3]) >> 14) + ((unsigned int)(v12 - a4[3]) >> 31)); /*0x103a48008*/
      a4[3] = v13; /*0x103a4800b*/
      a4[2] = v12; /*0x103a4800f*/
      *(_DWORD *)(a3 + v7) = v13 >> 1; /*0x103a48015*/
      v6 = (int *)(v5 + v7); /*0x103a48019*/
      v7 += 8; /*0x103a4801d*/
    }
    while ( 8LL * (unsigned int)v4 != v7 ); /*0x103a48024*/
    for ( i = 0; i != v4; ++i ) /*0x103a48026*/
    {
      v15 = a4[5]; /*0x103a4802d*/
      v16 = a4[6]; /*0x103a48031*/
      v17 = a4[4] + 821 * ((*(_DWORD *)(a1 + 8 * i) - v15 + 0x2000) >> 14); /*0x103a4804a*/
      a4[4] = *(_DWORD *)(a1 + 8 * i); /*0x103a4804d*/
      a4[5] = v17; /*0x103a48051*/
      v18 = v15 + 6110 * (((v17 - v16) >> 14) + ((unsigned int)(v17 - v16) >> 31)); /*0x103a4806b*/
      v19 = v16 + 12382 * (((v18 - a4[7]) >> 14) + ((unsigned int)(v18 - a4[7]) >> 31)); /*0x103a48089*/
      a4[7] = v19; /*0x103a4808c*/
      a4[6] = v18; /*0x103a48090*/
      *(_DWORD *)(a3 + 8 * i) = (*(_DWORD *)(a3 + 8 * i) + (v19 >> 1)) >> 15; /*0x103a4809f*/
    }
    for ( j = 0; j != v4; *(_DWORD *)(a3 + 8 * j++ + 4) = v25 >> 1 ) /*0x103a480af*/
    {
      v21 = a4[9]; /*0x103a480b6*/
      v22 = a4[10]; /*0x103a480ba*/
      v23 = a4[8] + 3050 * ((*(_DWORD *)(a1 + 8 * j) - v21 + 0x2000) >> 14); /*0x103a480d3*/
      a4[8] = *(_DWORD *)(a1 + 8 * j); /*0x103a480d6*/
      a4[9] = v23; /*0x103a480da*/
      v24 = v21 + 9368 * (((v23 - v22) >> 14) + ((unsigned int)(v23 - v22) >> 31)); /*0x103a480f4*/
      v25 = v22 + 15063 * (((v24 - a4[11]) >> 14) + ((unsigned int)(v24 - a4[11]) >> 31)); /*0x103a48112*/
      a4[11] = v25; /*0x103a48115*/
      a4[10] = v24; /*0x103a48119*/
    }
    for ( k = 0; k != v4; ++k ) /*0x103a4812d*/
    {
      v27 = a4[13]; /*0x103a48137*/
      v28 = a4[14]; /*0x103a4813b*/
      v29 = a4[12] + 821 * ((*(_DWORD *)(v5 + 8 * k) - v27 + 0x2000) >> 14); /*0x103a48157*/
      a4[12] = *(_DWORD *)(v5 + 8 * k); /*0x103a4815b*/
      a4[13] = v29; /*0x103a4815f*/
      v30 = v27 + 6110 * (((v29 - v28) >> 14) + ((unsigned int)(v29 - v28) >> 31)); /*0x103a4817b*/
      v31 = v28 + 12382 * (((v30 - a4[15]) >> 14) + ((unsigned int)(v30 - a4[15]) >> 31)); /*0x103a4819a*/
      a4[15] = v31; /*0x103a4819d*/
      a4[14] = v30; /*0x103a481a1*/
      *(_DWORD *)(a3 + 8 * k + 4) = (*(_DWORD *)(a3 + 8 * k + 4) + (v31 >> 1)) >> 15; /*0x103a481b1*/
    }
  }
}

// Address: 0x103a481c3 | Name: _WebRtcSpl_Resample48khzTo32khz
void __fastcall WebRtcSpl_Resample48khzTo32khz(_DWORD *a1, __int64 a2, __int64 a3)
{
  __int64 i; // rax
  int v4; // r10d
  int v5; // r11d
  int v6; // r9d
  int v7; // r8d

  if ( a3 != 0 ) /*0x103a481c6*/
  {
    for ( i = 0; i != a3; ++i ) /*0x103a481d0*/
    {
      *(_DWORD *)(a2 + 8 * i) = 778 * *a1 /*0x103a4822e*/
                              - 2050 * a1[1]
                              + 1087 * a1[2]
                              + 23285 * a1[3]
                              + 12903 * a1[4]
                              - 3783 * a1[5]
                              + 441 * a1[6]
                              + 222 * a1[7]
                              + 0x4000;
      v4 = 222 * a1[1] + 441 * a1[2] + -3783 * a1[3] + 12903 * a1[4]; /*0x103a48258*/
      v5 = -2050 * a1[7]; /*0x103a4826b*/
      v6 = 23285 * a1[5] + 1087 * a1[6]; /*0x103a48273*/
      v7 = 778 * a1[8]; /*0x103a48276*/
      a1 += 3; /*0x103a4827e*/
      *(_DWORD *)(a2 + 8 * i + 4) = v4 + v6 + v5 + v7 + 0x4000; /*0x103a4828e*/
    }
  }
}

// Address: 0x103a482a1 | Name: _WebRtcSpl_Resample32khzTo24khz
__int64 __fastcall WebRtcSpl_Resample32khzTo24khz(_DWORD *a1, _DWORD *a2, __int64 a3)
{
  __int64 result; // rax
  int v4; // r9d
  int v5; // ecx
  int v6; // r8d
  int v7; // r10d
  int v8; // r11d

  if ( a3 != 0 ) /*0x103a482a4*/
  {
    result = 0x4000; /*0x103a482ae*/
    do /*0x103a483b1*/
    {
      *a2 = 767 * *a1 /*0x103a48304*/
          - 2362 * a1[1]
          + 2434 * a1[2]
          + 24406 * a1[3]
          + 10620 * a1[4]
          - 3838 * a1[5]
          + 721 * a1[6]
          + 90 * a1[7]
          + 0x4000;
      a2[1] = 19062 * (a1[4] + a1[5]) - 2646 * (a1[3] + a1[6]) + -381 * (a1[2] + a1[7]) + 386 * (a1[1] + a1[8]) + 0x4000; /*0x103a4834c*/
      v4 = 90 * a1[2] + 721 * a1[3] + -3838 * a1[4] + 10620 * a1[5]; /*0x103a48371*/
      v5 = 24406 * a1[6]; /*0x103a48374*/
      v6 = 2434 * a1[7]; /*0x103a4837b*/
      v7 = -2362 * a1[8]; /*0x103a48383*/
      v8 = 767 * a1[9]; /*0x103a4838b*/
      a1 += 4; /*0x103a48393*/
      a2[2] = v4 + v5 + v6 + v7 + v8 + 0x4000; /*0x103a483a6*/
      a2 += 3; /*0x103a483aa*/
      --a3; /*0x103a483ae*/
    }
    while ( a3 != 0 ); /*0x103a483b1*/
  }
  return result; /*0x103a483b8*/
}

// Address: 0x103a483b9 | Name: _WebRtcSpl_Resample44khzTo32khz
__int64 __fastcall WebRtcSpl_Resample44khzTo32khz(_DWORD *a1, int *a2, __int64 a3)
{
  __int64 i; // rbx
  __int64 result; // rax

  if ( a3 != 0 ) /*0x103a483bc*/
  {
    for ( i = a3; i != 0; --i ) /*0x103a483d0*/
    {
      *a2 = (a1[3] << 15) | 0x4000; /*0x103a483eb*/
      a2[4] = -156 * a1[5] /*0x103a48450*/
            + 974 * a1[6]
            + -3863 * a1[7]
            + 18603 * a1[8]
            + 21691 * a1[9]
            - 6246 * a1[10]
            + 2353 * a1[11]
            + -712 * a1[12]
            + 126 * a1[13]
            + 0x4000;
      WebRtcSpl_ResampDotProduct(a1, a2: a1 + 17, a3: &kCoefficients44To32, a4: a2 + 1, a5: a2 + 7); /*0x103a4846a*/
      WebRtcSpl_ResampDotProduct(a1: a1 + 2, a2: a1 + 15, a3: &unk_10958E1E2, a4: a2 + 2, a5: a2 + 6); /*0x103a48486*/
      result = WebRtcSpl_ResampDotProduct(a1: a1 + 3, a2: a1 + 14, a3: &unk_10958E1F4, a4: a2 + 3, a5: a2 + 5); /*0x103a484a4*/
      a2 += 8; /*0x103a484a9*/
      a1 += 11; /*0x103a484ad*/
    }
  }
  return result; /*0x103a484c7*/
}

// Address: 0x103a484c8 | Name: _WebRtcSpl_ResampDotProduct
__int64 __fastcall WebRtcSpl_ResampDotProduct(const __m128i *a1, __int64 a2, __m64 *a3, _DWORD *a4, _DWORD *a5)
{
  __m128i v5; // xmm0
  __m128i v6; // xmm1
  __m128i v7; // xmm3
  __m128i v8; // xmm2
  __int32 v9; // eax
  __m128i v10; // xmm3
  __m128i v11; // xmm2
  __int64 result; // rax

  v5 = _mm_cvtepi16_epi32(a3[1]); /*0x103a484cc*/
  v6 = _mm_cvtepi16_epi32(*a3); /*0x103a484d2*/
  v7 = _mm_hadd_epi32(_mm_mullo_epi32(_mm_loadu_si128(a1 + 1), v5), _mm_mullo_epi32(_mm_loadu_si128(a1), v6)); /*0x103a484ea*/
  v8 = _mm_hadd_epi32( /*0x103a4850d*/
         _mm_mullo_epi32(_mm_shuffle_epi32(_mm_loadu_si128((const __m128i *)(a2 - 28)), 27), v5),
         _mm_mullo_epi32(_mm_shuffle_epi32(_mm_loadu_si128((const __m128i *)(a2 - 12)), 27), v6));
  v9 = a3[2].i32[0]; /*0x103a48512*/
  v10 = _mm_hadd_epi32(v7, v7); /*0x103a48516*/
  *a4 = _mm_cvtsi128_si32(_mm_hadd_epi32(v10, v10)) + v9 * a1[2].i32[0] + 0x4000; /*0x103a48535*/
  v11 = _mm_hadd_epi32(v8, v8); /*0x103a4853b*/
  result = (unsigned int)(_mm_cvtsi128_si32(_mm_hadd_epi32(v11, v11)) + *(_DWORD *)(a2 - 32) * v9 + 0x4000); /*0x103a4854c*/
  *a5 = result; /*0x103a4854e*/
  return result; /*0x103a48551*/
}

// Address: 0x103a48553 | Name: _WebRtcSpl_SqrtLocal
__int64 __fastcall WebRtcSpl_SqrtLocal(int a1)
{
  unsigned int v1; // ecx

  v1 = ((a1 / 2 - 0x40000000) >> 16) * ((a1 / 2 - 0x40000000) >> 16); /*0x103a4856b*/
  return ((a1 / 2 - 0x40000000) >> 16) * (v1 >> 15) /*0x103a485ac*/
       + a1 / 2
       + ((int)(-2 * v1) >> 1)
       - 40960 * ((unsigned int)(((int)(-2 * v1) >> 16) * ((int)(-2 * v1) >> 16)) >> 15)
       + 57344
       * ((int)(((a1 / 2 - 0x40000000) >> 16) * ((unsigned int)(((int)(-2 * v1) >> 16) * ((int)(-2 * v1) >> 16)) >> 15)) >> 15)
       + 1073774592;
}

// Address: 0x103a485ae | Name: _WebRtcSpl_Sqrt
__int64 __fastcall WebRtcSpl_Sqrt(signed int a1)
{
  int v2; // edi
  int v3; // eax
  unsigned int v4; // edx
  unsigned __int16 v5; // dx
  int v6; // edi
  unsigned int v7; // eax
  bool v8; // cc
  int v9; // edi
  unsigned int v10; // eax
  unsigned int v11; // r8d
  unsigned int v12; // eax
  signed int v13; // eax
  unsigned int v14; // eax

  if ( a1 < 0 ) /*0x103a485b4*/
  {
    v2 = -a1; /*0x103a485bf*/
    v3 = 0x7FFFFFFF; /*0x103a485c1*/
    if ( !__OFSUB__(v2, 1) ) /*0x103a485c6*/
      v3 = v2; /*0x103a485c6*/
    a1 = v3; /*0x103a485c9*/
  }
  else if ( a1 == 0 ) /*0x103a485b6*/
  {
    return 0; /*0x103a485ba*/
  }
  _BitScanReverse(&v4, a1); /*0x103a485cb*/
  v5 = (v4 ^ 0x1F) - 1; /*0x103a485d1*/
  v6 = a1 << v5; /*0x103a485d8*/
  v7 = (v6 + 0x8000) & 0xFFFF0000; /*0x103a485e0*/
  v8 = v6 < 2147450880; /*0x103a485e5*/
  v9 = 2147418112; /*0x103a485eb*/
  if ( v8 ) /*0x103a485f0*/
    v9 = v7; /*0x103a485f0*/
  v10 = -v9; /*0x103a485f9*/
  if ( v9 > 0 ) /*0x103a485fb*/
    v10 = v9; /*0x103a485fb*/
  v11 = v10 >> 1; /*0x103a48601*/
  v12 = (v10 >> 17) | 0xFFFFC000; /*0x103a48607*/
  v13 = v11 /*0x103a48657*/
      + ((int)(-2 * v12 * v12) >> 1)
      + v12 * ((v12 * v12) >> 15)
      - 40960 * ((unsigned int)(((int)(-2 * v12 * v12) >> 16) * ((int)(-2 * v12 * v12) >> 16)) >> 15)
      + 57344
      * ((int)(v12 * ((unsigned int)(((int)(-2 * v12 * v12) >> 16) * ((int)(-2 * v12 * v12) >> 16)) >> 15)) >> 15)
      + 1073774592;
  if ( (v5 & 0xFFFE) == v5 ) /*0x103a48664*/
    v14 = ((unsigned int)(46340 * (v13 >> 16) + 0x8000) >> 15) & 0xFFFE; /*0x103a48677*/
  else
    v14 = HIWORD(v13); /*0x103a4867e*/
  return v14 >> (v5 >> 1); /*0x103a48683*/
}

// Address: 0x103a48685 | Name: _WebRtcSpl_AnalysisQMF
__int64 __fastcall WebRtcSpl_AnalysisQMF(__int64 a1, unsigned __int64 a2, __int64 a3, __int64 a4)
{
  unsigned __int64 v4; // rbx
  __int64 v7; // rax
  unsigned __int64 v8; // rcx
  __int64 v9; // rax
  int v10; // edi
  int v11; // r8d
  int v12; // r9d
  int v13; // edi
  int v14; // r9d
  int v15; // edi
  _DWORD v17[320]; // [rsp+0h] [rbp-1430h] BYREF
  _DWORD v18[320]; // [rsp+500h] [rbp-F30h] BYREF
  _DWORD v19[320]; // [rsp+A00h] [rbp-A30h] BYREF
  _DWORD v20[320]; // [rsp+F00h] [rbp-530h] BYREF

  v4 = a2 >> 1; /*0x103a486ad*/
  if ( a2 >= 2 ) /*0x103a486b4*/
  {
    v7 = 0; /*0x103a48701*/
    v8 = a2 >> 1; /*0x103a48703*/
    do /*0x103a4872e*/
    {
      v19[v7] = *(__int16 *)(a1 + 2LL * (__int16)(v7 * 2)) << 10; /*0x103a48711*/
      v20[v7] = *(__int16 *)(a1 + 2LL * (__int16)(v7 * 2) + 2) << 10; /*0x103a48720*/
      ++v7; /*0x103a48727*/
      --v8; /*0x103a4872b*/
    }
    while ( v8 != 0 ); /*0x103a4872e*/
    WebRtcSpl_AllPassQMF(a1: v20, a2: v4, a3: v18, a4: &WebRtcSpl_kAllPassFilter1); /*0x103a48748*/
    WebRtcSpl_AllPassQMF(a1: v19, a2: v4, a3: v17, a4: &WebRtcSpl_kAllPassFilter2); /*0x103a48768*/
    v9 = 0; /*0x103a48773*/
    do /*0x103a487d6*/
    {
      v10 = v18[v9]; /*0x103a48784*/
      v11 = v17[v9]; /*0x103a4878b*/
      v12 = v10 + v11 + 1024; /*0x103a48797*/
      v13 = v10 + 1024; /*0x103a4879e*/
      v14 = v12 >> 11; /*0x103a487a4*/
      if ( v14 < -32767 ) /*0x103a487ab*/
        v14 = -32768; /*0x103a487ab*/
      if ( v14 >= 0x7FFF ) /*0x103a487b2*/
        LOWORD(v14) = 0x7FFF; /*0x103a487b2*/
      v15 = (v13 - v11) >> 11; /*0x103a487b9*/
      if ( v15 < -32767 ) /*0x103a487be*/
        v15 = -32768; /*0x103a487be*/
      if ( v15 >= 0x7FFF ) /*0x103a487c3*/
        LOWORD(v15) = 0x7FFF; /*0x103a487c3*/
      *(_WORD *)(a3 + 2 * v9) = v14; /*0x103a487c6*/
      *(_WORD *)(a4 + 2 * v9++) = v15; /*0x103a487cb*/
    }
    while ( v4 != v9 ); /*0x103a487d6*/
  }
  else
  {
    WebRtcSpl_AllPassQMF(a1: v20, a2: a2 >> 1, a3: v18, a4: &WebRtcSpl_kAllPassFilter1); /*0x103a486ce*/
    WebRtcSpl_AllPassQMF(a1: v19, a2: v4, a3: v17, a4: &WebRtcSpl_kAllPassFilter2); /*0x103a486ee*/
  }
  return __stack_chk_guard; /*0x103a487e8*/
}

// Address: 0x103a487ff | Name: _WebRtcSpl_AllPassQMF
__int64 __fastcall WebRtcSpl_AllPassQMF(
        unsigned int *a1,
        unsigned __int64 a2,
        unsigned int *a3,
        unsigned __int16 *a4,
        _DWORD *a5)
{
  unsigned int v5; // r10d
  unsigned int v6; // r11d
  unsigned int v7; // r9d
  unsigned int v8; // r10d
  signed int v9; // ebx
  int v10; // r9d
  unsigned int v11; // r10d
  __int64 i; // r11
  unsigned int v13; // r14d
  unsigned int v14; // ebx
  unsigned int v15; // r10d
  signed int v16; // r12d
  unsigned int v17; // r10d
  unsigned int v18; // r11d
  unsigned int v19; // r9d
  unsigned int v20; // r10d
  signed int v21; // eax
  int v22; // r9d
  unsigned int v23; // eax
  __int64 j; // r10
  unsigned int v25; // ebx
  unsigned int v26; // r11d
  unsigned int v27; // eax
  signed int v28; // r15d
  unsigned int v29; // r9d
  unsigned int v30; // r10d
  unsigned int v31; // eax
  unsigned int v32; // r9d
  signed int v33; // ebx
  int v34; // eax
  unsigned int v35; // r9d
  __int64 k; // rcx
  unsigned int v37; // r11d
  unsigned int v38; // r10d
  unsigned int v39; // r9d
  signed int v40; // r14d
  __int64 result; // rax

  v5 = a5[1]; /*0x103a4880d*/
  v6 = *a1 - v5; /*0x103a48814*/
  v7 = *a1 >> 31; /*0x103a48817*/
  v8 = v5 >> 31; /*0x103a4881b*/
  v9 = 0x80000000 - (v6 >> 31); /*0x103a4882a*/
  if ( v7 == v6 >> 31 ) /*0x103a4882f*/
    v9 = v6; /*0x103a4882f*/
  if ( v7 == v8 ) /*0x103a4883b*/
    v9 = v6; /*0x103a4883b*/
  v10 = *a4; /*0x103a48846*/
  v11 = *a5 + v10 * (v9 >> 16) + ((v10 * (unsigned int)(unsigned __int16)v9) >> 16); /*0x103a48859*/
  *a3 = v11; /*0x103a4885c*/
  if ( a2 >= 2 ) /*0x103a48863*/
  {
    for ( i = 1; i != a2; ++i ) /*0x103a48865*/
    {
      v13 = a1[i] - v11; /*0x103a48872*/
      v14 = a1[i] >> 31; /*0x103a48875*/
      v15 = v11 >> 31; /*0x103a48878*/
      v16 = 0x80000000 - (v13 >> 31); /*0x103a48889*/
      if ( v14 == v13 >> 31 ) /*0x103a4888f*/
        v16 = v13; /*0x103a4888f*/
      if ( v14 == v15 ) /*0x103a48896*/
        v16 = v13; /*0x103a48896*/
      v11 = a1[i - 1] + v10 * (v16 >> 16) + ((v10 * (unsigned int)(unsigned __int16)v16) >> 16); /*0x103a488b3*/
      a3[i] = v11; /*0x103a488b6*/
    }
  }
  *a5 = a1[a2 - 1]; /*0x103a488c7*/
  a5[1] = a3[a2 - 1]; /*0x103a488cf*/
  v17 = a5[3]; /*0x103a488d6*/
  v18 = *a3 - v17; /*0x103a488dd*/
  v19 = *a3 >> 31; /*0x103a488e0*/
  v20 = v17 >> 31; /*0x103a488e4*/
  v21 = 0x80000000 - (v18 >> 31); /*0x103a488ee*/
  if ( v19 == v18 >> 31 ) /*0x103a488f3*/
    v21 = v18; /*0x103a488f3*/
  if ( v19 == v20 ) /*0x103a488fa*/
    v21 = v18; /*0x103a488fa*/
  v22 = a4[1]; /*0x103a48905*/
  v23 = a5[2] + v22 * (v21 >> 16) + ((v22 * (unsigned int)(unsigned __int16)v21) >> 16); /*0x103a4891c*/
  *a1 = v23; /*0x103a4891f*/
  if ( a2 >= 2 ) /*0x103a48925*/
  {
    for ( j = 1; j != a2; ++j ) /*0x103a48927*/
    {
      v25 = a3[j] - v23; /*0x103a48934*/
      v26 = a3[j] >> 31; /*0x103a48936*/
      v27 = v23 >> 31; /*0x103a4893a*/
      v28 = 0x80000000 - (v25 >> 31); /*0x103a4894a*/
      if ( v26 == v25 >> 31 ) /*0x103a48950*/
        v28 = v25; /*0x103a48950*/
      if ( v26 == v27 ) /*0x103a48957*/
        v28 = v25; /*0x103a48957*/
      v23 = a3[j - 1] + v22 * (v28 >> 16) + ((v22 * (unsigned int)(unsigned __int16)v28) >> 16); /*0x103a48973*/
      a1[j] = v23; /*0x103a48976*/
    }
  }
  a5[2] = a3[a2 - 1]; /*0x103a48986*/
  a5[3] = a1[a2 - 1]; /*0x103a4898e*/
  v29 = a5[5]; /*0x103a48994*/
  v30 = *a1 - v29; /*0x103a4899b*/
  v31 = *a1 >> 31; /*0x103a4899e*/
  v32 = v29 >> 31; /*0x103a489a1*/
  v33 = 0x80000000 - (v30 >> 31); /*0x103a489b1*/
  if ( v31 == v30 >> 31 ) /*0x103a489b7*/
    v33 = v30; /*0x103a489b7*/
  if ( v31 == v32 ) /*0x103a489be*/
    v33 = v30; /*0x103a489be*/
  v34 = a4[2]; /*0x103a489c9*/
  v35 = a5[4] + v34 * (v33 >> 16) + ((v34 * (unsigned int)(unsigned __int16)v33) >> 16); /*0x103a489dc*/
  *a3 = v35; /*0x103a489df*/
  if ( a2 >= 2 ) /*0x103a489e6*/
  {
    for ( k = 1; k != a2; ++k ) /*0x103a489e8*/
    {
      v37 = a1[k] - v35; /*0x103a489f4*/
      v38 = a1[k] >> 31; /*0x103a489f7*/
      v39 = v35 >> 31; /*0x103a489fb*/
      v40 = 0x80000000 - (v37 >> 31); /*0x103a48a0b*/
      if ( v38 == v37 >> 31 ) /*0x103a48a11*/
        v40 = v37; /*0x103a48a11*/
      if ( v38 == v39 ) /*0x103a48a18*/
        v40 = v37; /*0x103a48a18*/
      v35 = a1[k - 1] + v34 * (v40 >> 16) + ((v34 * (unsigned int)(unsigned __int16)v40) >> 16); /*0x103a48a35*/
      a3[k] = v35; /*0x103a48a38*/
    }
  }
  a5[4] = a1[a2 - 1]; /*0x103a48a48*/
  result = a3[a2 - 1]; /*0x103a48a4c*/
  a5[5] = result; /*0x103a48a50*/
  return result; /*0x103a48a54*/
}

// Address: 0x103a48a5d | Name: _WebRtcSpl_SynthesisQMF
__int64 __fastcall WebRtcSpl_SynthesisQMF(
        __int64 a1,
        __int64 a2,
        unsigned __int64 a3,
        __int64 a4,
        _DWORD *a5,
        _DWORD *a6)
{
  unsigned __int64 v7; // rbx
  __int64 v9; // rax
  int v10; // ecx
  int v11; // edx
  __int64 v12; // rax
  __m128i v13; // xmm0
  __m128i v14; // xmm1
  unsigned int v16[320]; // [rsp+0h] [rbp-1420h] BYREF
  unsigned int v17[320]; // [rsp+500h] [rbp-F20h] BYREF
  unsigned int v18[320]; // [rsp+A00h] [rbp-A20h] BYREF
  unsigned int v19[320]; // [rsp+F00h] [rbp-520h] BYREF

  v7 = a3; /*0x103a48a70*/
  if ( a3 != 0 ) /*0x103a48a84*/
  {
    v9 = 0; /*0x103a48a8d*/
    do /*0x103a48ab9*/
    {
      v10 = *(__int16 *)(a1 + 2 * v9); /*0x103a48a8f*/
      v11 = *(__int16 *)(a2 + 2 * v9); /*0x103a48a93*/
      v19[v9] = (v11 + v10) << 10; /*0x103a48a9f*/
      v18[v9++] = (v10 - v11) << 10; /*0x103a48aac*/
    }
    while ( v7 != v9 ); /*0x103a48ab9*/
    WebRtcSpl_AllPassQMF(a1: v19, a2: v7, a3: v17, a4: WebRtcSpl_kAllPassFilter2, a5); /*0x103a48ad3*/
    WebRtcSpl_AllPassQMF(a1: v18, a2: v7, a3: v16, a4: WebRtcSpl_kAllPassFilter1, a5: a6); /*0x103a48af3*/
    v12 = 0; /*0x103a48af8*/
    v13 = _mm_cvtepi16_epi32((__m64)0x200020002000200LL); /*0x103a48afa*/
    do /*0x103a48b35*/
    {
      v14 = _mm_srai_epi32(_mm_add_epi32(_mm_insert_epi32(_mm_cvtsi32_si128(v16[v12]), v17[v12], 1), v13), 0xAu); /*0x103a48b1f*/
      *(_DWORD *)(a4 + 2LL * (__int16)(v12 * 2)) = _mm_cvtsi128_si32(_mm_packs_epi32(v14, v14)); /*0x103a48b28*/
      ++v12; /*0x103a48b2e*/
      --v7; /*0x103a48b32*/
    }
    while ( v7 != 0 ); /*0x103a48b35*/
  }
  else
  {
    WebRtcSpl_AllPassQMF(a1: v19, a2: 0, a3: v17, a4: WebRtcSpl_kAllPassFilter2, a5); /*0x103a48b51*/
    WebRtcSpl_AllPassQMF(a1: v18, a2: 0, a3: v16, a4: WebRtcSpl_kAllPassFilter1, a5: a6); /*0x103a48b71*/
  }
  return __stack_chk_guard; /*0x103a48b86*/
}

// Address: 0x103a48b99 | Name: _WebRtcSpl_VectorBitShiftW16
void __fastcall WebRtcSpl_VectorBitShiftW16(__int64 a1, __int64 a2, __int64 a3, int a4)
{
  __int64 j; // rax
  int v5; // ecx
  __int64 i; // rax

  if ( (__int16)a4 <= 0 ) /*0x103a48ba0*/
  {
    if ( a2 != 0 ) /*0x103a48bc3*/
    {
      v5 = -a4; /*0x103a48bc5*/
      for ( i = 0; i != a2; ++i ) /*0x103a48bc7*/
        *(_WORD *)(a1 + 2 * i) = *(unsigned __int16 *)(a3 + 2 * i) << v5; /*0x103a48bd1*/
    }
  }
  else if ( a2 != 0 ) /*0x103a48ba5*/
  {
    for ( j = 0; j != a2; ++j ) /*0x103a48ba7*/
      *(_WORD *)(a1 + 2 * j) = *(__int16 *)(a3 + 2 * j) >> a4; /*0x103a48bb1*/
  }
}

// Address: 0x103a48be0 | Name: _WebRtcSpl_VectorBitShiftW32
void __fastcall WebRtcSpl_VectorBitShiftW32(__int64 a1, __int64 a2, __int64 a3, int a4)
{
  __int64 j; // rax
  int v5; // ecx
  __int64 i; // rax

  if ( (__int16)a4 <= 0 ) /*0x103a48be7*/
  {
    if ( a2 != 0 ) /*0x103a48c08*/
    {
      v5 = -a4; /*0x103a48c0a*/
      for ( i = 0; i != a2; ++i ) /*0x103a48c0c*/
        *(_DWORD *)(a1 + 4 * i) = *(_DWORD *)(a3 + 4 * i) << v5; /*0x103a48c15*/
    }
  }
  else if ( a2 != 0 ) /*0x103a48bec*/
  {
    for ( j = 0; j != a2; ++j ) /*0x103a48bee*/
      *(_DWORD *)(a1 + 4 * j) = *(int *)(a3 + 4 * j) >> a4; /*0x103a48bf7*/
  }
}

// Address: 0x103a48c23 | Name: _WebRtcSpl_VectorBitShiftW32ToW16
void __fastcall WebRtcSpl_VectorBitShiftW32ToW16(__int64 a1, __int64 a2, __int64 a3, int a4)
{
  __int64 j; // rax
  int v5; // r10d
  int v6; // ecx
  __int64 i; // rax
  int v8; // r10d

  if ( a4 < 0 ) /*0x103a48c29*/
  {
    if ( a2 != 0 ) /*0x103a48c69*/
    {
      v6 = -a4; /*0x103a48c6b*/
      for ( i = 0; i != a2; ++i ) /*0x103a48c6d*/
      {
        v8 = *(_DWORD *)(a3 + 4 * i) << v6; /*0x103a48c7f*/
        if ( v8 < -32767 ) /*0x103a48c89*/
          v8 = -32768; /*0x103a48c89*/
        if ( v8 >= 0x7FFF ) /*0x103a48c90*/
          LOWORD(v8) = 0x7FFF; /*0x103a48c90*/
        *(_WORD *)(a1 + 2 * i) = v8; /*0x103a48c94*/
      }
    }
  }
  else if ( a2 != 0 ) /*0x103a48c2e*/
  {
    for ( j = 0; j != a2; ++j ) /*0x103a48c30*/
    {
      v5 = *(int *)(a3 + 4 * j) >> a4; /*0x103a48c42*/
      if ( v5 < -32767 ) /*0x103a48c4c*/
        v5 = -32768; /*0x103a48c4c*/
      if ( v5 >= 0x7FFF ) /*0x103a48c53*/
        LOWORD(v5) = 0x7FFF; /*0x103a48c53*/
      *(_WORD *)(a1 + 2 * j) = v5; /*0x103a48c57*/
    }
  }
}

// Address: 0x103a48ca3 | Name: _WebRtcSpl_ScaleVector
void __fastcall WebRtcSpl_ScaleVector(__int64 a1, __int64 a2, __int16 a3, __int64 a4, char a5)
{
  __int64 v7; // r8

  if ( a4 != 0 ) /*0x103a48caa*/
  {
    v7 = 0; /*0x103a48cb6*/
    do /*0x103a48cd0*/
    {
      *(_WORD *)(a2 + 2 * v7) = (a3 * *(__int16 *)(a1 + 2 * v7)) >> a5; /*0x103a48cc5*/
      ++v7; /*0x103a48cca*/
    }
    while ( a4 != v7 ); /*0x103a48cd0*/
  }
}

// Address: 0x103a48cd4 | Name: _WebRtcSpl_ScaleVectorWithSat
void __fastcall WebRtcSpl_ScaleVectorWithSat(__int64 a1, __int64 a2, __int16 a3, __int64 a4, char a5)
{
  __int64 v7; // r8
  int v8; // r10d

  if ( a4 != 0 ) /*0x103a48cdb*/
  {
    v7 = 0; /*0x103a48ce7*/
    do /*0x103a48d23*/
    {
      v8 = (a3 * *(__int16 *)(a1 + 2 * v7)) >> a5; /*0x103a48cff*/
      if ( v8 < -32767 ) /*0x103a48d09*/
        v8 = -32768; /*0x103a48d09*/
      if ( v8 >= 0x7FFF ) /*0x103a48d10*/
        LOWORD(v8) = 0x7FFF; /*0x103a48d12*/
      *(_WORD *)(a2 + 2 * v7++) = v8; /*0x103a48d18*/
    }
    while ( a4 != v7 ); /*0x103a48d23*/
  }
}

// Address: 0x103a48d27 | Name: _WebRtcSpl_ScaleAndAddVectors
void __fastcall WebRtcSpl_ScaleAndAddVectors(
        __int64 a1,
        __int16 a2,
        char a3,
        __int64 a4,
        __int16 a5,
        char a6,
        __int64 a7,
        __int64 a8)
{
  __int64 i; // rbx

  if ( a8 != 0 ) /*0x103a48d37*/
  {
    for ( i = 0; i != a8; ++i ) /*0x103a48d47*/
      *(_WORD *)(a7 + 2 * i) = ((a2 * *(__int16 *)(a1 + 2 * i)) >> a3) + ((a5 * *(__int16 *)(a4 + 2 * i)) >> a6); /*0x103a48d69*/
  }
}

// Address: 0x103a48d7d | Name: _WebRtcSpl_ScaleAndAddVectorsWithRoundC
__int64 __fastcall WebRtcSpl_ScaleAndAddVectorsWithRoundC(
        __int64 a1,
        __int16 a2,
        __int64 a3,
        __int16 a4,
        int a5,
        __int64 a6,
        __int64 a7)
{
  __int64 result; // rax
  __int64 i; // r14

  result = 0xFFFFFFFFLL; /*0x103a48d8c*/
  if ( a5 >= 0 && a1 != 0 && a3 != 0 && a6 != 0 && a7 != 0 ) /*0x103a48db5*/
  {
    result = 0; /*0x103a48dc1*/
    for ( i = 0; i != a7; ++i ) /*0x103a48dc3*/
      *(_WORD *)(a6 + 2 * i) = ((1 << a5 >> 1) + a2 * *(__int16 *)(a1 + 2 * i) + a4 * *(__int16 *)(a3 + 2 * i)) >> a5; /*0x103a48de3*/
  }
  return result; /*0x103a48df6*/
}

// Address: 0x103a48df7 | Name: _WebRtcSpl_ReverseOrderMultArrayElements
void __fastcall WebRtcSpl_ReverseOrderMultArrayElements(__int64 a1, __int64 a2, __int16 *a3, __int64 a4, char a5)
{
  __int64 v7; // r8
  int v8; // r10d

  if ( a4 != 0 ) /*0x103a48dfa*/
  {
    v7 = 0; /*0x103a48e07*/
    do /*0x103a48e29*/
    {
      v8 = (*(__int16 *)(a2 + 2 * v7) * *a3--) >> a5; /*0x103a48e17*/
      *(_WORD *)(a1 + 2 * v7++) = v8; /*0x103a48e1e*/
    }
    while ( a4 != v7 ); /*0x103a48e29*/
  }
}

// Address: 0x103a48e2d | Name: _WebRtcSpl_ElementwiseVectorMult
void __fastcall WebRtcSpl_ElementwiseVectorMult(__int64 a1, __int64 a2, __int64 a3, __int64 a4, char a5)
{
  __int64 v7; // r8

  if ( a4 != 0 ) /*0x103a48e34*/
  {
    v7 = 0; /*0x103a48e3d*/
    do /*0x103a48e5c*/
    {
      *(_WORD *)(a1 + 2 * v7) = (*(__int16 *)(a2 + 2 * v7) * *(__int16 *)(a3 + 2 * v7)) >> a5; /*0x103a48e51*/
      ++v7; /*0x103a48e56*/
    }
    while ( a4 != v7 ); /*0x103a48e5c*/
  }
}

// Address: 0x103a48e60 | Name: _WebRtcSpl_AddVectorsAndShift
void __fastcall WebRtcSpl_AddVectorsAndShift(__int64 a1, __int64 a2, __int64 a3, __int64 a4, char a5)
{
  __int64 v7; // r8

  if ( a4 != 0 ) /*0x103a48e67*/
  {
    v7 = 0; /*0x103a48e70*/
    do /*0x103a48e8e*/
    {
      *(_WORD *)(a1 + 2 * v7) = (*(__int16 *)(a2 + 2 * v7) + *(__int16 *)(a3 + 2 * v7)) >> a5; /*0x103a48e83*/
      ++v7; /*0x103a48e88*/
    }
    while ( a4 != v7 ); /*0x103a48e8e*/
  }
}

// Address: 0x103a48e92 | Name: _WebRtcSpl_AddAffineVectorToVector
void __fastcall WebRtcSpl_AddAffineVectorToVector(__int64 a1, __int64 a2, __int16 a3, int a4, char a5, __int64 a6)
{
  __int64 i; // r8

  if ( a6 != 0 ) /*0x103a48e99*/
  {
    for ( i = 0; i != a6; ++i ) /*0x103a48ea4*/
      *(_WORD *)(a1 + 2 * i) += (a4 + a3 * *(__int16 *)(a2 + 2 * i)) >> a5; /*0x103a48eb6*/
  }
}

// Address: 0x103a48ec5 | Name: _WebRtcSpl_AffineTransformVector
void __fastcall WebRtcSpl_AffineTransformVector(__int64 a1, __int64 a2, __int16 a3, int a4, char a5, __int64 a6)
{
  __int64 i; // r8

  if ( a6 != 0 ) /*0x103a48ecc*/
  {
    for ( i = 0; i != a6; ++i ) /*0x103a48ed7*/
      *(_WORD *)(a1 + 2 * i) = (a4 + a3 * *(__int16 *)(a2 + 2 * i)) >> a5; /*0x103a48ee9*/
  }
}

// Address: 0x103a4b166 | Name: _WebRtcSpl_SqrtFloor
__int64 __fastcall WebRtcSpl_SqrtFloor(int a1)
{
  int v1; // ecx
  int v2; // edx
  int v3; // esi
  int v4; // edx
  int v5; // edi
  int v6; // ecx
  int v7; // esi
  int v8; // r8d
  int v9; // ecx
  int v10; // esi
  int v11; // edi
  int v12; // ecx
  int v13; // r8d
  int v14; // r9d
  int v15; // ecx
  int v16; // edi
  int v17; // r8d
  int v18; // ecx
  int v19; // r9d
  int v20; // r10d
  int v21; // ecx
  int v22; // r8d
  int v23; // r9d
  int v24; // ecx
  int v25; // r8d
  int v26; // r10d
  int v27; // ecx
  int v28; // r8d
  int v29; // esi
  int v30; // ecx
  int v31; // r8d
  int v32; // edi
  int v33; // ecx
  int v34; // esi
  int v35; // edx
  int v36; // ecx
  int v37; // esi
  int v38; // edi
  int v39; // ecx
  int v40; // edx
  int v41; // esi
  int v42; // ecx
  int v43; // edx
  int v44; // edi

  v1 = a1 - 0x40000000; /*0x103a4b16a*/
  v2 = 0; /*0x103a4b170*/
  if ( a1 < 0x40000000 ) /*0x103a4b178*/
    v1 = a1; /*0x103a4b178*/
  LOBYTE(v2) = a1 >= 0x40000000; /*0x103a4b17b*/
  v3 = v2 << 16; /*0x103a4b180*/
  v4 = (v2 << 30) | 0x10000000; /*0x103a4b186*/
  v5 = v3 + 0x8000; /*0x103a4b18c*/
  if ( v1 < v4 ) /*0x103a4b196*/
  {
    v4 = 0; /*0x103a4b196*/
    v5 = v3; /*0x103a4b199*/
  }
  v6 = v1 - v4; /*0x103a4b19c*/
  v7 = (v5 << 13) | 0x4000000; /*0x103a4b1a3*/
  v8 = v5 | 0x4000; /*0x103a4b1b1*/
  if ( v6 < v7 ) /*0x103a4b1b6*/
  {
    v7 = 0; /*0x103a4b1b6*/
    v8 = v5; /*0x103a4b1b9*/
  }
  v9 = v6 - v7; /*0x103a4b1bd*/
  v10 = (v8 << 12) | 0x1000000; /*0x103a4b1c5*/
  v11 = v8 + 0x2000; /*0x103a4b1cb*/
  if ( v9 < v10 ) /*0x103a4b1d4*/
  {
    v10 = 0; /*0x103a4b1d4*/
    v11 = v8; /*0x103a4b1d7*/
  }
  v12 = v9 - v10; /*0x103a4b1db*/
  v13 = (v11 << 11) + 0x400000; /*0x103a4b1e4*/
  v14 = v11 | 0x1000; /*0x103a4b1f3*/
  if ( v12 < v13 ) /*0x103a4b1f9*/
  {
    v13 = 0; /*0x103a4b1f9*/
    v14 = v11; /*0x103a4b1fd*/
  }
  v15 = v12 - v13; /*0x103a4b201*/
  v16 = (v14 << 10) + 0x100000; /*0x103a4b20a*/
  v17 = v14 | 0x800; /*0x103a4b213*/
  if ( v15 < v16 ) /*0x103a4b21c*/
  {
    v16 = 0; /*0x103a4b21c*/
    v17 = v14; /*0x103a4b21f*/
  }
  v18 = v15 - v16; /*0x103a4b223*/
  v19 = (v17 << 9) + 0x40000; /*0x103a4b22c*/
  v20 = v17 | 0x400; /*0x103a4b23b*/
  if ( v18 < v19 ) /*0x103a4b241*/
  {
    v19 = 0; /*0x103a4b241*/
    v20 = v17; /*0x103a4b245*/
  }
  v21 = v18 - v19; /*0x103a4b249*/
  v22 = (v20 << 8) + 0x10000; /*0x103a4b253*/
  v23 = v20 | 0x200; /*0x103a4b25d*/
  if ( v21 < v22 ) /*0x103a4b267*/
  {
    v22 = 0; /*0x103a4b267*/
    v23 = v20; /*0x103a4b26b*/
  }
  v24 = v21 - v22; /*0x103a4b26f*/
  v25 = (v23 << 7) + 0x4000; /*0x103a4b279*/
  v26 = v23 | 0x100; /*0x103a4b284*/
  if ( v24 < v25 ) /*0x103a4b28a*/
  {
    v25 = 0; /*0x103a4b28a*/
    v26 = v23; /*0x103a4b28e*/
  }
  v27 = v24 - v25; /*0x103a4b292*/
  v28 = (v26 << 6) + 4096; /*0x103a4b29c*/
  v29 = v26 | 0x80; /*0x103a4b2a2*/
  if ( v27 < v28 ) /*0x103a4b2ab*/
  {
    v28 = 0; /*0x103a4b2ab*/
    v29 = v26; /*0x103a4b2af*/
  }
  v30 = v27 - v28; /*0x103a4b2b3*/
  v31 = 32 * v29 + 1024; /*0x103a4b2bd*/
  v32 = v29 | 0x40; /*0x103a4b2c2*/
  if ( v30 < v31 ) /*0x103a4b2c8*/
  {
    v31 = 0; /*0x103a4b2c8*/
    v32 = v29; /*0x103a4b2cc*/
  }
  v33 = v30 - v31; /*0x103a4b2cf*/
  v34 = 16 * v32 + 256; /*0x103a4b2d7*/
  v35 = v32 | 0x20; /*0x103a4b2db*/
  if ( v33 < v34 ) /*0x103a4b2e0*/
  {
    v34 = 0; /*0x103a4b2e0*/
    v35 = v32; /*0x103a4b2e3*/
  }
  v36 = v33 - v34; /*0x103a4b2e6*/
  v37 = 8 * v35 + 64; /*0x103a4b2e8*/
  v38 = v35 | 0x10; /*0x103a4b2f1*/
  if ( v36 < v37 ) /*0x103a4b2f6*/
  {
    v37 = 0; /*0x103a4b2f6*/
    v38 = v35; /*0x103a4b2f9*/
  }
  v39 = v36 - v37; /*0x103a4b2fc*/
  v40 = 4 * v38 + 16; /*0x103a4b2fe*/
  v41 = v38 | 8; /*0x103a4b307*/
  if ( v39 < v40 ) /*0x103a4b30c*/
  {
    v40 = 0; /*0x103a4b30c*/
    v41 = v38; /*0x103a4b30f*/
  }
  v42 = v39 - v40; /*0x103a4b312*/
  v43 = 2 * v41 + 4; /*0x103a4b314*/
  v44 = v41 | 4; /*0x103a4b31d*/
  if ( v42 < v43 ) /*0x103a4b322*/
  {
    v43 = 0; /*0x103a4b322*/
    v44 = v41; /*0x103a4b325*/
  }
  return ((unsigned int)v44 >> 1) | (v42 - v43 > v44); /*0x103a4b335*/
}

// Address: 0x103a4b337 | Name: _WebRtcVad_InitCore
__int64 __fastcall WebRtcVad_InitCore(__int64 a1)
{
  unsigned int v2; // ebx

  if ( a1 != 0 ) /*0x103a4b341*/
  {
    *(_DWORD *)a1 = 1; /*0x103a4b34a*/
    v2 = 0; /*0x103a4b350*/
    *(_QWORD *)(a1 + 276) = 0; /*0x103a4b352*/
    *(_OWORD *)(a1 + 4) = 0; /*0x103a4b35c*/
    WebRtcSpl_ResetResample48khzTo8khz(a1: (_OWORD *)(a1 + 20)); /*0x103a4b364*/
    *(_QWORD *)(a1 + 196) = 0x110A139C1C621E8CLL; /*0x103a4b373*/
    *(_OWORD *)(a1 + 180) = kNoiseDataMeans; /*0x103a4b381*/
    *(_QWORD *)(a1 + 220) = 0x1D3B1FF41D9D2A7FLL; /*0x103a4b393*/
    *(_OWORD *)(a1 + 204) = kSpeechDataMeans; /*0x103a4b3a1*/
    *(_QWORD *)(a1 + 244) = 0x1C701A502B001DBLL; /*0x103a4b3b3*/
    *(_OWORD *)(a1 + 228) = kNoiseDataStds; /*0x103a4b3c1*/
    *(_QWORD *)(a1 + 268) = 0x3520437060401ECLL; /*0x103a4b3d3*/
    *(_OWORD *)(a1 + 252) = kSpeechDataStds; /*0x103a4b3e1*/
    *(_OWORD *)(a1 + 284) = 0; /*0x103a4b3f3*/
    *(_OWORD *)(a1 + 300) = 0; /*0x103a4b3fb*/
    *(_OWORD *)(a1 + 316) = 0; /*0x103a4b403*/
    *(_OWORD *)(a1 + 332) = 0; /*0x103a4b40b*/
    *(_OWORD *)(a1 + 348) = 0; /*0x103a4b413*/
    *(_OWORD *)(a1 + 364) = 0; /*0x103a4b41b*/
    *(_OWORD *)(a1 + 380) = 0; /*0x103a4b423*/
    *(_OWORD *)(a1 + 396) = 0; /*0x103a4b42b*/
    *(_OWORD *)(a1 + 412) = 0; /*0x103a4b433*/
    *(_OWORD *)(a1 + 428) = 0; /*0x103a4b43b*/
    *(_OWORD *)(a1 + 444) = 0; /*0x103a4b443*/
    *(_OWORD *)(a1 + 460) = 0; /*0x103a4b44b*/
    memset_pattern16(__b: (void *)(a1 + 476), __pattern16: &unk_10958E5A0, __len: 0xC0u); /*0x103a4b45f*/
    *(_WORD *)(a1 + 688) = 0; /*0x103a4b464*/
    *(_QWORD *)(a1 + 680) = 0; /*0x103a4b46c*/
    *(_QWORD *)(a1 + 690) = 0; /*0x103a4b473*/
    *(_WORD *)(a1 + 698) = 0; /*0x103a4b47a*/
    *(_QWORD *)(a1 + 700) = 0; /*0x103a4b482*/
    memset_pattern16(__b: (void *)(a1 + 668), __pattern16: &unk_10958E5B0, __len: 0xCu); /*0x103a4b49c*/
    *(_WORD *)(a1 + 712) = 3; /*0x103a4b4a1*/
    *(_DWORD *)(a1 + 708) = 262152; /*0x103a4b4ab*/
    *(_DWORD *)(a1 + 714) = 458766; /*0x103a4b4b6*/
    *(_WORD *)(a1 + 718) = 5; /*0x103a4b4c1*/
    *(_DWORD *)(a1 + 720) = 1376280; /*0x103a4b4cb*/
    *(_WORD *)(a1 + 724) = 24; /*0x103a4b4d6*/
    *(_DWORD *)(a1 + 726) = 3145785; /*0x103a4b4e0*/
    *(_WORD *)(a1 + 730) = 57; /*0x103a4b4eb*/
    *(_DWORD *)(a1 + 732) = 42; /*0x103a4b4f5*/
  }
  else
  {
    return (unsigned int)-1; /*0x103a4b502*/
  }
  return v2; /*0x103a4b509*/
}

// Address: 0x103a4b50e | Name: _WebRtcVad_set_mode_core
__int64 __fastcall WebRtcVad_set_mode_core(__int64 a1, unsigned int a2)
{
  __int64 result; // rax
  __int64 v3; // rdx
  __int64 v4; // r8
  __int64 v5; // r10
  __int64 v6; // rax

  result = 0xFFFFFFFFLL; /*0x103a4b50e*/
  if ( a2 <= 3 ) /*0x103a4b516*/
  {
    v3 = dword_10958E55C[a2]; /*0x103a4b52a*/
    v4 = dword_10958E56C[a2]; /*0x103a4b535*/
    v5 = dword_10958E57C[a2]; /*0x103a4b540*/
    v6 = dword_10958E58C[a2]; /*0x103a4b54b*/
    *(_WORD *)(a1 + 712) = *(_WORD *)((char *)&dword_10958E55C[1] + v3); /*0x103a4b554*/
    *(_DWORD *)(a1 + 708) = *(int *)((char *)dword_10958E55C + v3); /*0x103a4b55e*/
    *(_DWORD *)(a1 + 714) = *(int *)((char *)dword_10958E56C + v4); /*0x103a4b568*/
    *(_WORD *)(a1 + 718) = *(_WORD *)((char *)&dword_10958E56C[1] + v4); /*0x103a4b574*/
    *(_DWORD *)(a1 + 720) = *(int *)((char *)dword_10958E57C + v5); /*0x103a4b57f*/
    *(_WORD *)(a1 + 724) = *(_WORD *)((char *)&dword_10958E57C[1] + v5); /*0x103a4b58b*/
    *(_DWORD *)(a1 + 726) = *(int *)((char *)dword_10958E58C + v6); /*0x103a4b596*/
    *(_WORD *)(a1 + 730) = *(_WORD *)((char *)&dword_10958E58C[1] + v6); /*0x103a4b5a2*/
    return 0; /*0x103a4b5a9*/
  }
  return result; /*0x103a4b5ad*/
}

// Address: 0x103a4b5ae | Name: _WebRtcVad_CalcVad48khz
__int64 __fastcall WebRtcVad_CalcVad48khz(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  unsigned __int64 v5; // r12
  _BYTE *v6; // rbx
  unsigned __int64 v8; // [rsp+0h] [rbp-DA0h]
  _OWORD v10[184]; // [rsp+10h] [rbp-D90h] BYREF
  _BYTE v11[480]; // [rsp+B90h] [rbp-210h] BYREF

  __bzero(a1: v10, a2: 2944); /*0x103a4b5e9*/
  v8 = a3; /*0x103a4b5fe*/
  if ( a3 >= 0x1E0 ) /*0x103a4b60c*/
  {
    v5 = a3 / 0x1E0; /*0x103a4b611*/
    v6 = v11; /*0x103a4b620*/
    do /*0x103a4b649*/
    {
      WebRtcSpl_Resample48khzTo8khz(a1: a2, a2: (__int64)v6, a3: a1 + 20, a4: v10); /*0x103a4b63a*/
      v6 += 160; /*0x103a4b63f*/
      --v5; /*0x103a4b646*/
    }
    while ( v5 != 0 ); /*0x103a4b649*/
  }
  return WebRtcVad_CalcVad8khz(a1, a2: v11, a3: v8 / 6); /*0x103a4b686*/
}

// Address: 0x103a4b69d | Name: _WebRtcVad_CalcVad8khz
__int64 __fastcall WebRtcVad_CalcVad8khz(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rbx
  __int16 v5; // ax
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // rsi
  __int64 v9; // rdi
  int v10; // eax
  __int64 v11; // rdx
  __int64 v12; // r8
  __int64 v13; // r12
  int v14; // ecx
  int *v15; // r12
  int *v16; // r14
  __int64 v17; // r15
  int v18; // r9d
  int v19; // ebx
  __int64 v20; // r13
  __int64 v21; // r15
  int v22; // ecx
  int v23; // eax
  int v24; // r9d
  int v25; // ecx
  __int64 v26; // r12
  int v27; // eax
  int v28; // r14d
  unsigned int v29; // esi
  unsigned int v30; // r14d
  unsigned int v31; // r14d
  unsigned int v32; // eax
  unsigned int v33; // eax
  int v34; // r14d
  int v35; // ebx
  unsigned int v36; // esi
  int v37; // r13d
  unsigned int v38; // r9d
  int v39; // eax
  __int64 v40; // rdx
  int Minimum; // eax
  __int64 v42; // rdx
  __int64 v43; // r11
  __int64 v44; // r15
  __int16 *v45; // rbx
  char v46; // r8
  __int64 v47; // rsi
  int v48; // ecx
  bool v49; // zf
  char v50; // r12
  __int64 v51; // rcx
  __int64 v52; // rax
  __int16 v53; // r10
  _WORD *v54; // r13
  int v55; // r14d
  __int64 v56; // r9
  int v57; // esi
  __int16 v58; // r10
  __int16 v59; // di
  __int16 v60; // r8
  int v61; // edi
  int v62; // r10d
  int v63; // r8d
  __int16 v64; // cx
  int v65; // edi
  int v66; // eax
  int v67; // edi
  int v68; // esi
  __int16 v69; // r9
  __int16 v70; // cx
  int v71; // edi
  char v72; // cl
  int v73; // edx
  int v74; // r14d
  unsigned int v75; // eax
  char v76; // di
  __int64 v77; // rsi
  unsigned int v78; // ecx
  __int64 v79; // r14
  __int64 v80; // r13
  __int16 *v81; // rsi
  char v82; // di
  __int64 v83; // r8
  int v84; // r8d
  int v85; // edi
  __int64 v86; // r10
  char v87; // r9
  __int16 v88; // ax
  unsigned int v89; // edx
  char v90; // si
  __int64 v91; // rdi
  __int16 v92; // r8
  int v93; // ecx
  __int16 v94; // si
  int v95; // ecx
  int v96; // eax
  __int16 v97; // ax
  __int16 v98; // ax
  __int16 v99; // ax
  __int16 v100; // ax
  __int64 result; // rax
  char v102; // [rsp+0h] [rbp-120h] BYREF
  char v103; // [rsp+4h] [rbp-11Ch] BYREF
  __int64 v104; // [rsp+8h] [rbp-118h]
  __int64 v105; // [rsp+10h] [rbp-110h]
  int v106; // [rsp+18h] [rbp-108h] BYREF
  int v107; // [rsp+1Ch] [rbp-104h] BYREF
  int v108; // [rsp+20h] [rbp-100h]
  int v109; // [rsp+24h] [rbp-FCh]
  __int64 v110; // [rsp+28h] [rbp-F8h]
  __int64 v111; // [rsp+30h] [rbp-F0h]
  __int64 v112; // [rsp+38h] [rbp-E8h]
  __int64 v113; // [rsp+40h] [rbp-E0h]
  __int64 v114; // [rsp+48h] [rbp-D8h]
  __int64 v115; // [rsp+50h] [rbp-D0h]
  __int16 v116; // [rsp+58h] [rbp-C8h]
  __int16 v117; // [rsp+5Ah] [rbp-C6h]
  int v118; // [rsp+5Ch] [rbp-C4h]
  int v119; // [rsp+60h] [rbp-C0h]
  _WORD v120[6]; // [rsp+64h] [rbp-BCh] BYREF
  _QWORD v121[2]; // [rsp+70h] [rbp-B0h]
  __int64 v122; // [rsp+80h] [rbp-A0h]
  _QWORD v123[2]; // [rsp+90h] [rbp-90h]
  __int64 v124; // [rsp+A0h] [rbp-80h]
  _WORD v125[32]; // [rsp+B0h] [rbp-70h]
  __int64 savedregs; // [rsp+120h] [rbp+0h] BYREF

  v4 = a1; /*0x103a4b6b4*/
  v5 = WebRtcVad_CalculateFeatures(a1, a2, a3, a4: v120); /*0x103a4b6cc*/
  v124 = 0; /*0x103a4b6d3*/
  *(_OWORD *)v123 = 0; /*0x103a4b6da*/
  v122 = 0; /*0x103a4b6e1*/
  *(_OWORD *)v121 = 0; /*0x103a4b6e8*/
  if ( a3 == 80 ) /*0x103a4b6f3*/
  {
    v6 = 726; /*0x103a4b714*/
    v7 = 720; /*0x103a4b719*/
    v8 = 714; /*0x103a4b71e*/
    v9 = 708; /*0x103a4b723*/
  }
  else if ( a3 == 160 ) /*0x103a4b6fc*/
  {
    v6 = 728; /*0x103a4b6fe*/
    v7 = 722; /*0x103a4b703*/
    v8 = 716; /*0x103a4b708*/
    v9 = 710; /*0x103a4b70d*/
  }
  else
  {
    v6 = 730; /*0x103a4b72a*/
    v7 = 724; /*0x103a4b72f*/
    v8 = 718; /*0x103a4b734*/
    v9 = 712; /*0x103a4b739*/
  }
  if ( v5 < 11 ) /*0x103a4b742*/
    goto LABEL_74; /*0x103a4b742*/
  v109 = *(__int16 *)(v4 + v6); /*0x103a4b74c*/
  v116 = *(_WORD *)(v4 + v8); /*0x103a4b756*/
  v117 = *(_WORD *)(v4 + v9); /*0x103a4b761*/
  v10 = *(__int16 *)(v4 + v7); /*0x103a4b768*/
  v108 = v10; /*0x103a4b76c*/
  v11 = v4 + 180; /*0x103a4b772*/
  v12 = v4 + 228; /*0x103a4b779*/
  v105 = v4; /*0x103a4b787*/
  v13 = 0; /*0x103a4b795*/
  v14 = 0; /*0x103a4b798*/
  v118 = 0; /*0x103a4b79a*/
  v113 = v4 + 180; /*0x103a4b7a4*/
  v112 = v4 + 228; /*0x103a4b7ab*/
  v110 = v4 + 204; /*0x103a4b7b2*/
  v104 = v4 + 252; /*0x103a4b7b9*/
  do /*0x103a4b9eb*/
  {
    v115 = v13; /*0x103a4b7c0*/
    v119 = v14; /*0x103a4b7c7*/
    LOBYTE(v10) = 1; /*0x103a4b7cd*/
    v15 = &v107; /*0x103a4b7cf*/
    v16 = &v106; /*0x103a4b7d6*/
    v17 = 0; /*0x103a4b7dd*/
    v18 = 0; /*0x103a4b7e0*/
    v19 = 0; /*0x103a4b7e3*/
    do /*0x103a4b8b2*/
    {
      LODWORD(v111) = v10; /*0x103a4b7e5*/
      LODWORD(v114) = v18; /*0x103a4b7eb*/
      v20 = v115; /*0x103a4b7f2*/
      v21 = v115 + v17; /*0x103a4b7f9*/
      v22 = WebRtcVad_GaussianProbability( /*0x103a4b82b*/
              a1: (unsigned int)(__int16)v120[v115],
              a2: (unsigned int)*(__int16 *)(v11 + 2 * v21),
              a3: (unsigned int)*(__int16 *)(v12 + 2 * v21),
              a4: (char *)&savedregs + 2 * v21 - 80)
          * kNoiseDataWeights[v21];
      *v16 = v22; /*0x103a4b82e*/
      v19 += v22; /*0x103a4b831*/
      v23 = WebRtcVad_GaussianProbability( /*0x103a4b85f*/
              a1: (unsigned int)(__int16)v120[v20],
              a2: (unsigned int)*(__int16 *)(v110 + 2 * v21),
              a3: (unsigned int)*(__int16 *)(v104 + 2 * v21),
              a4: (char *)&savedregs + 2 * v21 - 112);
      v24 = v114; /*0x103a4b864*/
      v16 = (int *)&v102; /*0x103a4b872*/
      v12 = v112; /*0x103a4b879*/
      v11 = v113; /*0x103a4b880*/
      v25 = v23 * kSpeechDataWeights[v21]; /*0x103a4b893*/
      *v15 = v25; /*0x103a4b896*/
      v18 = v25 + v24; /*0x103a4b89a*/
      v17 = 6; /*0x103a4b89d*/
      v15 = (int *)&v103; /*0x103a4b8a3*/
      v10 = 0; /*0x103a4b8ad*/
    }
    while ( (v111 & 1) != 0 ); /*0x103a4b8b2*/
    v26 = v115; /*0x103a4b8b8*/
    v27 = 31; /*0x103a4b8bf*/
    v28 = 31; /*0x103a4b8c4*/
    v29 = v19; /*0x103a4b8cc*/
    if ( v19 != 0 ) /*0x103a4b8ce*/
    {
      if ( v19 != v19 >> 31 ) /*0x103a4b8d5*/
      {
        _BitScanReverse(&v30, v19 ^ (v19 >> 31)); /*0x103a4b8d9*/
        v31 = v30 ^ 0x1F; /*0x103a4b8dd*/
      }
      else
      {
        v31 = 32; /*0x103a4b8e3*/
      }
      v28 = v31 - 1; /*0x103a4b8e9*/
    }
    if ( v18 != 0 ) /*0x103a4b8ef*/
    {
      if ( v18 != v18 >> 31 ) /*0x103a4b8f7*/
      {
        _BitScanReverse(&v32, v18 ^ (v18 >> 31)); /*0x103a4b8fc*/
        v33 = v32 ^ 0x1F; /*0x103a4b8ff*/
      }
      else
      {
        v33 = 32; /*0x103a4b904*/
      }
      v27 = v33 - 1; /*0x103a4b909*/
    }
    v34 = v28 - v27; /*0x103a4b90b*/
    v35 = kSpectrumWeight[v115]; /*0x103a4b915*/
    v10 = v118; /*0x103a4b928*/
    if ( 4 * v34 > v108 ) /*0x103a4b933*/
      v10 = 1; /*0x103a4b933*/
    v118 = v10; /*0x103a4b936*/
    v36 = v29 >> 12; /*0x103a4b93c*/
    if ( (__int16)v36 <= 0 ) /*0x103a4b942*/
    {
      LOWORD(v10) = 0x4000; /*0x103a4b981*/
    }
    else
    {
      v37 = v18; /*0x103a4b956*/
      v10 = WebRtcSpl_DivW32W16(a1: (4 * v106) & 0xFFFFC000, a2: v36); /*0x103a4b959*/
      v18 = v37; /*0x103a4b95e*/
      v12 = v112; /*0x103a4b961*/
      v11 = v113; /*0x103a4b968*/
      *((_WORD *)&v123[1] + v26 + 2) = 0x4000 - v10; /*0x103a4b976*/
    }
    *((_WORD *)v123 + v26) = v10; /*0x103a4b985*/
    v38 = (unsigned int)v18 >> 12; /*0x103a4b98e*/
    if ( (__int16)v38 > 0 ) /*0x103a4b996*/
    {
      v10 = WebRtcSpl_DivW32W16(a1: (4 * v107) & 0xFFFFC000, a2: v38); /*0x103a4b9ab*/
      v12 = v112; /*0x103a4b9b0*/
      v11 = v113; /*0x103a4b9b7*/
      *((_WORD *)v121 + v26) = v10; /*0x103a4b9be*/
      *((_WORD *)&v121[1] + v26 + 2) = 0x4000 - v10; /*0x103a4b9ce*/
    }
    v14 = v35 * v34 + v119; /*0x103a4b9e1*/
    v13 = v26 + 1; /*0x103a4b9e4*/
  }
  while ( v13 != 6 ); /*0x103a4b9eb*/
  v39 = v14 >= v109; /*0x103a4b9f9*/
  v118 |= v39; /*0x103a4b9fc*/
  LOWORD(v39) = 12800; /*0x103a4ba02*/
  v119 = v39; /*0x103a4ba06*/
  v40 = 0; /*0x103a4ba0c*/
  v4 = v105; /*0x103a4ba0e*/
  do /*0x103a4be5f*/
  {
    v114 = v40; /*0x103a4ba1c*/
    Minimum = WebRtcVad_FindMinimum(a1: v4, a2: (unsigned int)(__int16)v120[v40]); /*0x103a4ba2e*/
    v42 = v114; /*0x103a4ba33*/
    v43 = v113; /*0x103a4ba3a*/
    v44 = v113 + 2 * v114; /*0x103a4ba41*/
    v45 = &kNoiseDataWeights[v114]; /*0x103a4ba45*/
    v46 = 1; /*0x103a4ba49*/
    v47 = 0; /*0x103a4ba4c*/
    v48 = 0; /*0x103a4ba4e*/
    do /*0x103a4ba6d*/
    {
      v48 += *(__int16 *)(v44 + 2 * v47) * v45[v47]; /*0x103a4ba5c*/
      v47 = 6; /*0x103a4ba5e*/
      v49 = (v46 & 1) == 0; /*0x103a4ba63*/
      v46 = 0; /*0x103a4ba67*/
    }
    while ( !v49 ); /*0x103a4ba6d*/
    v111 = (unsigned int)(19712 * ((int)((Minimum << 20) - ((v48 & 0xFFFFFFC0) << 10)) >> 16)) >> 16; /*0x103a4ba86*/
    v115 = 72 - v114; /*0x103a4ba95*/
    v119 += 640; /*0x103a4ba9c*/
    v50 = 1; /*0x103a4baa6*/
    v51 = 0; /*0x103a4baa9*/
    do /*0x103a4bcdd*/
    {
      v52 = v42 + 6 * v51; /*0x103a4baaf*/
      v53 = *(_WORD *)(v43 + 2 * v52); /*0x103a4bab3*/
      if ( (_WORD)v118 != 0 ) /*0x103a4bac0*/
      {
        v54 = (_WORD *)(v104 + 2 * v52); /*0x103a4bacd*/
        v55 = (unsigned __int16)*v54; /*0x103a4bad1*/
        v56 = v110; /*0x103a4bad6*/
        v57 = *(__int16 *)(v110 + 2 * v52); /*0x103a4badd*/
        v58 = v111 + v53; /*0x103a4bae2*/
        v59 = ((_WORD)v51 << 7) + 640; /*0x103a4baee*/
        if ( v58 > v59 ) /*0x103a4baf8*/
          v59 = v58; /*0x103a4baf8*/
        v60 = ((_WORD)v51 + (_WORD)v115) << 7; /*0x103a4bb06*/
        if ( v59 < v60 ) /*0x103a4bb0e*/
          v60 = v59; /*0x103a4bb0e*/
        *(_WORD *)(v43 + 2 * v52) = v60; /*0x103a4bb12*/
        v61 = *((__int16 *)v121 + v52); /*0x103a4bb17*/
        v62 = (__int16)v125[v52]; /*0x103a4bb1f*/
        v63 = v57 + ((unsigned int)(((6554 * (__int16)((unsigned int)(v62 * v61) >> 11)) >> 21) + 1) >> 1); /*0x103a4bb45*/
        v64 = kMinimumMean[v51]; /*0x103a4bb4f*/
        if ( (__int16)(v57 + ((unsigned int)(((6554 * (__int16)((unsigned int)(v62 * v61) >> 11)) >> 21) + 1) >> 1)) <= v64 ) /*0x103a4bb58*/
          LOWORD(v63) = v64; /*0x103a4bb58*/
        if ( (__int16)v63 >= (__int16)v119 ) /*0x103a4bb66*/
          LOWORD(v63) = v119; /*0x103a4bb66*/
        *(_WORD *)(v56 + 2 * v52) = v63; /*0x103a4bb6a*/
        v65 = ((((v62 * (__int16)(v120[v42] - ((unsigned int)((v57 << 13) + 0x8000) >> 16))) >> 3) - 4096) * (v61 >> 2)) >> 4; /*0x103a4bb98*/
        if ( v65 <= 0 ) /*0x103a4bb9d*/
          v66 = -(int)WebRtcSpl_DivW32W16(a1: -v65, a2: 10 * (unsigned __int16)v55); /*0x103a4bc7c*/
        else
          v66 = WebRtcSpl_DivW32W16(a1: v65, a2: 10 * (unsigned __int16)v55); /*0x103a4bbad*/
        v72 = 24; /*0x103a4bc7e*/
        v73 = 0x800000; /*0x103a4bc83*/
      }
      else
      {
        v67 = *((__int16 *)v123 + v52); /*0x103a4bbb7*/
        v68 = (__int16)v125[v52 + 16]; /*0x103a4bbbf*/
        v69 = ((_WORD)v51 << 7) + 640; /*0x103a4bbf2*/
        if ( (__int16)(v53 /*0x103a4bbfd*/
                     + v111
                     + ((__int16)((unsigned int)(655 * (__int16)((unsigned int)(v68 * v67) >> 11)) >> 16) >> 6)) > v69 )
          v69 = v53 + v111 + ((__int16)((unsigned int)(655 * (__int16)((unsigned int)(v68 * v67) >> 11)) >> 16) >> 6); /*0x103a4bbfd*/
        v54 = (_WORD *)(v112 + 2 * v52); /*0x103a4bc08*/
        v70 = ((_WORD)v115 + (_WORD)v51) << 7; /*0x103a4bc16*/
        if ( v69 < v70 ) /*0x103a4bc1d*/
          v70 = v69; /*0x103a4bc1d*/
        v55 = (unsigned __int16)*v54; /*0x103a4bc21*/
        *(_WORD *)(v43 + 2 * v52) = v70; /*0x103a4bc26*/
        v71 = ((((v68 * (__int16)(v120[v42] - (v53 >> 3))) >> 3) - 4096) * (((v67 << 14) + 0x8000) >> 16)) >> 14; /*0x103a4bc59*/
        if ( v71 <= 0 ) /*0x103a4bc62*/
          v66 = -(int)WebRtcSpl_DivW32W16(a1: -v71, a2: v55); /*0x103a4bc91*/
        else
          v66 = WebRtcSpl_DivW32W16(a1: v71, a2: v55); /*0x103a4bc64*/
        v72 = 22; /*0x103a4bc93*/
        v73 = 0x200000; /*0x103a4bc98*/
      }
      v74 = ((v73 + (v66 << 16)) >> v72) + v55; /*0x103a4bca4*/
      if ( (__int16)v74 < 385 ) /*0x103a4bcb5*/
        LOWORD(v74) = 384; /*0x103a4bcb5*/
      *v54 = v74; /*0x103a4bcb9*/
      v51 = 1; /*0x103a4bcbe*/
      v75 = 0; /*0x103a4bcc3*/
      v49 = (v50 & 1) == 0; /*0x103a4bcc5*/
      v50 = 0; /*0x103a4bcc9*/
      v43 = v113; /*0x103a4bccf*/
      v42 = v114; /*0x103a4bcd6*/
    }
    while ( !v49 ); /*0x103a4bcdd*/
    v76 = 1; /*0x103a4bce3*/
    v77 = 0; /*0x103a4bce6*/
    do /*0x103a4bd06*/
    {
      v75 += *(__int16 *)(v44 + 2 * v77) * v45[v77]; /*0x103a4bcf4*/
      v77 = 6; /*0x103a4bcf6*/
      v78 = 0; /*0x103a4bcfb*/
      v49 = (v76 & 1) == 0; /*0x103a4bcfd*/
      v76 = 0; /*0x103a4bd01*/
    }
    while ( !v49 ); /*0x103a4bd06*/
    v79 = v110; /*0x103a4bd08*/
    v80 = v110 + 2 * v114; /*0x103a4bd0f*/
    v81 = &kSpeechDataWeights[v114]; /*0x103a4bd1a*/
    v82 = 1; /*0x103a4bd1e*/
    v83 = 0; /*0x103a4bd21*/
    do /*0x103a4bd4c*/
    {
      v78 += *(__int16 *)(v80 + 2 * v83) * v81[v83]; /*0x103a4bd3a*/
      v83 = 6; /*0x103a4bd3d*/
      v49 = (v82 & 1) == 0; /*0x103a4bd43*/
      v82 = 0; /*0x103a4bd47*/
    }
    while ( !v49 ); /*0x103a4bd4c*/
    v84 = kMinimumDifference[v114]; /*0x103a4bd68*/
    if ( (__int16)((v78 >> 9) - (v75 >> 9)) < v84 ) /*0x103a4bd70*/
    {
      v85 = (__int16)(v84 - ((v78 >> 9) - (v75 >> 9))); /*0x103a4bd79*/
      v86 = 0; /*0x103a4bd88*/
      v87 = 1; /*0x103a4bd8b*/
      v78 = 0; /*0x103a4bd8e*/
      do /*0x103a4bdbf*/
      {
        v88 = ((unsigned int)(13 * v85) >> 2) + *(_WORD *)(v80 + 2 * v86); /*0x103a4bd96*/
        *(_WORD *)(v80 + 2 * v86) = v88; /*0x103a4bd9a*/
        v78 += v88 * v81[v86]; /*0x103a4bdaa*/
        v86 = 6; /*0x103a4bdad*/
        v75 = 0; /*0x103a4bdb3*/
        v49 = (v87 & 1) == 0; /*0x103a4bdb5*/
        v87 = 0; /*0x103a4bdb9*/
      }
      while ( !v49 ); /*0x103a4bdbf*/
      v89 = (unsigned int)(49152 * v85) >> 16; /*0x103a4bdc7*/
      v90 = 1; /*0x103a4bdca*/
      v91 = 0; /*0x103a4bdcd*/
      do /*0x103a4bdf8*/
      {
        v92 = *(_WORD *)(v44 + 2 * v91) - v89; /*0x103a4bdd4*/
        *(_WORD *)(v44 + 2 * v91) = v92; /*0x103a4bdd7*/
        v75 += v92 * v45[v91]; /*0x103a4bde8*/
        v91 = 6; /*0x103a4bdea*/
        v49 = (v90 & 1) == 0; /*0x103a4bdef*/
        v90 = 0; /*0x103a4bdf3*/
      }
      while ( !v49 ); /*0x103a4bdf8*/
      v42 = v114; /*0x103a4bdfa*/
    }
    v93 = (__int16)(v78 >> 7); /*0x103a4be0f*/
    v119 = kMaximumSpeech[v42]; /*0x103a4be12*/
    if ( v93 > v119 ) /*0x103a4be1a*/
    {
      v94 = v119 - v93; /*0x103a4be22*/
      *(_WORD *)(v79 + 2 * v42) += v119 - v93; /*0x103a4be24*/
      *(_WORD *)(v79 + 2 * v42 + 12) += v94; /*0x103a4be29*/
    }
    v95 = (__int16)(v75 >> 7); /*0x103a4be32*/
    v96 = kMaximumNoise[v42]; /*0x103a4be3c*/
    v4 = v105; /*0x103a4be42*/
    if ( v95 > v96 ) /*0x103a4be49*/
    {
      v97 = v96 - v95; /*0x103a4be4b*/
      *(_WORD *)(v43 + 2 * v42) += v97; /*0x103a4be4d*/
      *(_WORD *)(v43 + 2 * v42 + 12) += v97; /*0x103a4be52*/
    }
    v40 = v42 + 1; /*0x103a4be58*/
  }
  while ( v40 != 6 ); /*0x103a4be5f*/
  ++*(_DWORD *)(v4 + 276); /*0x103a4be65*/
  if ( (_WORD)v118 != 0 ) /*0x103a4be73*/
  {
    v98 = *(_WORD *)(v4 + 282) + 1; /*0x103a4be7c*/
    *(_WORD *)(v4 + 282) = v98; /*0x103a4be7e*/
    if ( v98 < 7 ) /*0x103a4be89*/
    {
      v99 = v117; /*0x103a4bec7*/
    }
    else
    {
      *(_WORD *)(v4 + 282) = 6; /*0x103a4be8b*/
      v99 = v116; /*0x103a4be94*/
    }
    *(_WORD *)(v4 + 280) = v99; /*0x103a4bece*/
    result = 1; /*0x103a4bed5*/
  }
  else
  {
LABEL_74:
    v100 = *(_WORD *)(v4 + 280); /*0x103a4be9d*/
    if ( v100 <= 0 ) /*0x103a4bea7*/
    {
      result = 0; /*0x103a4beba*/
    }
    else
    {
      *(_WORD *)(v4 + 280) = v100 - 1; /*0x103a4beae*/
      result = (unsigned int)(__int16)(v100 + 2); /*0x103a4beb5*/
    }
    *(_WORD *)(v4 + 282) = 0; /*0x103a4bebc*/
  }
  *(_DWORD *)v4 = result; /*0x103a4beda*/
  return result; /*0x103a4beec*/
}

// Address: 0x103a4bf03 | Name: _WebRtcVad_CalcVad32khz
__int64 __fastcall WebRtcVad_CalcVad32khz(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  __int64 v5; // r15
  _BYTE v7[480]; // [rsp+0h] [rbp-5D0h] BYREF
  _BYTE v8[960]; // [rsp+1E0h] [rbp-3F0h] BYREF

  v5 = a1 + 4; /*0x103a4bf2b*/
  WebRtcVad_Downsampling(a1: a2, a2: v8, a3: a1 + 12, a4: a3); /*0x103a4bf43*/
  WebRtcVad_Downsampling(a1: v8, a2: v7, a3: v5, a4: a3 >> 1); /*0x103a4bf5e*/
  return WebRtcVad_CalcVad8khz(a1, a2: (__int64)v7, a3: a3 >> 2); /*0x103a4bf85*/
}

// Address: 0x103a4bf9c | Name: _WebRtcVad_CalcVad16khz
__int64 __fastcall WebRtcVad_CalcVad16khz(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  _BYTE v6[480]; // [rsp+0h] [rbp-200h] BYREF

  WebRtcVad_Downsampling(a1: a2, a2: v6, a3: a1 + 4, a4: a3); /*0x103a4bfd4*/
  return WebRtcVad_CalcVad8khz(a1, a2: (__int64)v6, a3: a3 >> 1); /*0x103a4bffa*/
}

// Address: 0x103a4c00d | Name: _WebRtcVad_CalculateFeatures
__int64 __fastcall WebRtcVad_CalculateFeatures(_WORD *a1, __int64 a2, unsigned __int64 a3, __int64 a4)
{
  unsigned __int64 v5; // r13
  unsigned __int64 v7; // r15
  __int64 v8; // r13
  unsigned __int64 v9; // r12
  int v10; // eax
  __int16 v11; // r9
  unsigned int v12; // edi
  __int16 v13; // r8
  __int64 v14; // rcx
  __int16 v15; // si
  __int16 v16; // dx
  __int16 v19; // [rsp+1Eh] [rbp-312h] BYREF
  _WORD v20[64]; // [rsp+20h] [rbp-310h] BYREF
  _BYTE v21[128]; // [rsp+A0h] [rbp-290h] BYREF
  _BYTE v22[240]; // [rsp+120h] [rbp-210h] BYREF
  _WORD v23[120]; // [rsp+210h] [rbp-120h] BYREF

  v5 = a3; /*0x103a4c024*/
  v19 = 0; /*0x103a4c03f*/
  v7 = a3 >> 1; /*0x103a4c047*/
  SplitFilter(a1: a2, a2: a3, a3: a1 + 340, a4: a1 + 345, a5: v23, a6: v22); /*0x103a4c076*/
  SplitFilter(a1: v23, a2: v7, a3: a1 + 341, a4: a1 + 346, a5: v21, a6: v20); /*0x103a4c0a0*/
  v5 >>= 2; /*0x103a4c0a5*/
  LogOfEnergy(a1: v21, a2: v5, a3: 176, a4: &v19, a5: a4 + 10); /*0x103a4c0c3*/
  LogOfEnergy(a1: v20, a2: v5, a3: 176, a4: &v19, a5: a4 + 8); /*0x103a4c0df*/
  SplitFilter(a1: v22, a2: v7, a3: a1 + 342, a4: a1 + 347, a5: v21, a6: v20); /*0x103a4c110*/
  LogOfEnergy(a1: v21, a2: v5, a3: 176, a4: &v19, a5: a4 + 6); /*0x103a4c12c*/
  SplitFilter(a1: v20, a2: v5, a3: a1 + 343, a4: a1 + 348, a5: v23, a6: v22); /*0x103a4c156*/
  LogOfEnergy(a1: v23, a2: a3 >> 3, a3: 272, a4: &v19, a5: a4 + 4); /*0x103a4c180*/
  v8 = a4; /*0x103a4c19d*/
  SplitFilter(a1: v22, a2: a3 >> 3, a3: a1 + 344, a4: a1 + 349, a5: v21, a6: v20); /*0x103a4c1b1*/
  v9 = a3 >> 4; /*0x103a4c1b9*/
  LogOfEnergy(a1: v21, a2: a3 >> 4, a3: 368, a4: &v19, a5: v8 + 2); /*0x103a4c1da*/
  if ( a3 >= 0x10 ) /*0x103a4c1e3*/
  {
    LOWORD(v10) = a1[350]; /*0x103a4c1e9*/
    v11 = a1[351]; /*0x103a4c1f1*/
    LOWORD(v12) = a1[352]; /*0x103a4c1f9*/
    v13 = a1[353]; /*0x103a4c201*/
    v14 = 0; /*0x103a4c209*/
    do /*0x103a4c264*/
    {
      v15 = v10; /*0x103a4c20b*/
      v16 = v12; /*0x103a4c20d*/
      v10 = (__int16)v20[v14]; /*0x103a4c20f*/
      v12 = (unsigned int)(1073728562 * v15 + 7756 * (__int16)v12 + 1073736204 * v13 + 6631 * (v10 + v11)) >> 14; /*0x103a4c24d*/
      v23[v14++] = v12; /*0x103a4c250*/
      v13 = v16; /*0x103a4c25b*/
      v11 = v15; /*0x103a4c25e*/
    }
    while ( v9 != v14 ); /*0x103a4c264*/
    a1[350] = v10; /*0x103a4c266*/
    a1[351] = v15; /*0x103a4c26e*/
    a1[352] = v12; /*0x103a4c276*/
    a1[353] = v16; /*0x103a4c27e*/
  }
  LogOfEnergy(a1: v23, a2: v9, a3: 368, a4: &v19, a5: v8); /*0x103a4c2a6*/
  return (unsigned int)v19; /*0x103a4c2be*/
}

// Address: 0x103a4c44d | Name: _WebRtcVad_GaussianProbability
__int64 __fastcall WebRtcVad_GaussianProbability(__int16 a1, __int16 a2, int a3, _WORD *a4)
{
  signed int v7; // eax
  __int16 v8; // r15
  unsigned int v9; // ecx
  int v10; // ecx
  unsigned int v11; // edx

  v7 = (unsigned int)WebRtcSpl_DivW32W16(a1: (a3 >> 1) + 0x20000, a2: a3) << 16; /*0x103a4c471*/
  v8 = 8 * a1 - a2; /*0x103a4c47d*/
  v9 = (unsigned int)(v8 * (__int16)((unsigned int)((v7 >> 18) * (v7 >> 18)) >> 2)) >> 10; /*0x103a4c490*/
  *a4 = v9; /*0x103a4c493*/
  v10 = (v8 * (__int16)v9) >> 9; /*0x103a4c49c*/
  v11 = 0; /*0x103a4c49f*/
  if ( v10 <= 22004 ) /*0x103a4c4a7*/
    v11 = ((-((94544 * v10) & 0xFFFF0000) >> 16) & 0x3FF | 0x400) >> -((signed int)-((94544 * v10) & 0xFFFF0000) >> 26); /*0x103a4c4cd*/
  return v11 * (v7 >> 16); /*0x103a4c4d9*/
}

// Address: 0x103a4c4e0 | Name: _WebRtcVad_Downsampling
__int64 __fastcall WebRtcVad_Downsampling(__int64 a1, __int64 a2, unsigned int *a3, unsigned __int64 a4)
{
  __int64 result; // rax
  unsigned int v5; // r8d
  unsigned __int64 v6; // rcx
  __int64 v7; // r9
  unsigned int v8; // r10d
  unsigned int v9; // r11d

  result = *a3; /*0x103a4c4e0*/
  v5 = a3[1]; /*0x103a4c4e2*/
  if ( a4 >= 2 ) /*0x103a4c4ea*/
  {
    v6 = a4 >> 1; /*0x103a4c4f1*/
    v7 = 0; /*0x103a4c4f4*/
    do /*0x103a4c565*/
    {
      v8 = ((unsigned int)result >> 1) + ((unsigned int)(5243 * *(__int16 *)(a1 + 4 * v7)) >> 14); /*0x103a4c509*/
      *(_WORD *)(a2 + 2 * v7) = v8; /*0x103a4c50c*/
      result = (unsigned int)(*(__int16 *)(a1 + 4 * v7) - ((5243 * (__int16)v8) >> 12)); /*0x103a4c525*/
      v9 = (v5 >> 1) + ((unsigned int)(1392 * *(__int16 *)(a1 + 4 * v7 + 2)) >> 14); /*0x103a4c53c*/
      *(_WORD *)(a2 + 2 * v7) = v8 + v9; /*0x103a4c546*/
      v5 = *(__int16 *)(a1 + 4 * v7++ + 2) - ((1392 * (__int16)v9) >> 12); /*0x103a4c55c*/
    }
    while ( v6 != v7 ); /*0x103a4c565*/
  }
  *a3 = result; /*0x103a4c569*/
  a3[1] = v5; /*0x103a4c56b*/
  return result; /*0x103a4c56f*/
}

// Address: 0x103a4c570 | Name: _WebRtcVad_FindMinimum
__int64 __fastcall WebRtcVad_FindMinimum(__int64 a1, __int16 a2, int a3)
{
  __int64 v3; // r8
  __int64 v4; // rcx
  __int16 *v5; // rax
  __int64 v6; // r9
  __int64 v7; // r10
  unsigned __int64 i; // r11
  __int64 v9; // rbx
  __int16 v10; // r14
  __int64 v11; // rbx
  __int64 v12; // r14
  __int16 v13; // r15
  unsigned __int64 v14; // r9
  int v15; // r10d
  __int64 v16; // r8
  __int64 v17; // r10
  __int16 v18; // r11
  bool v19; // cc
  __int64 v20; // r10
  int v21; // ecx
  int v22; // ecx
  __int64 v23; // rax
  __int16 v24; // si
  int v25; // edx
  unsigned int v26; // ecx

  v3 = 16 * a3; /*0x103a4c580*/
  v4 = a1 + 2 * v3 + 284; /*0x103a4c587*/
  v5 = (__int16 *)(a1 + 2 * v3 + 476); /*0x103a4c592*/
  v6 = a1 + 2 * v3 + 478; /*0x103a4c59c*/
  v7 = 1; /*0x103a4c5a3*/
  for ( i = 0; i != 16; ++i ) /*0x103a4c5a9*/
  {
    v9 = 14; /*0x103a4c5b0*/
    if ( i >= 0xF ) /*0x103a4c5b5*/
      v9 = i; /*0x103a4c5b5*/
    v10 = *(_WORD *)(v4 + 2 * i); /*0x103a4c5b9*/
    if ( v10 == 100 ) /*0x103a4c5c3*/
    {
      if ( i != 15 ) /*0x103a4c5c9*/
      {
        v11 = v7 + v9; /*0x103a4c5cb*/
        v12 = 0; /*0x103a4c5ce*/
        do /*0x103a4c5f4*/
        {
          v13 = *(_WORD *)(v6 + 2 * v12 - 192); /*0x103a4c5d1*/
          *(_WORD *)(v6 + 2 * v12 - 2) = *(_WORD *)(v6 + 2 * v12); /*0x103a4c5df*/
          *(_WORD *)(v6 + 2 * v12++ - 194) = v13; /*0x103a4c5e5*/
        }
        while ( v11 != v12 ); /*0x103a4c5f4*/
      }
      *(_WORD *)(a1 + 2 * v3 + 314) = 101; /*0x103a4c5f6*/
      *(_WORD *)(a1 + 2 * v3 + 506) = 10000; /*0x103a4c5fc*/
    }
    else
    {
      *(_WORD *)(v4 + 2 * i) = v10 + 1; /*0x103a4c607*/
    }
    v6 += 2; /*0x103a4c60f*/
    --v7; /*0x103a4c613*/
  }
  if ( *(__int16 *)(a1 + 2 * v3 + 490) > a2 ) /*0x103a4c620*/
  {
    if ( *(__int16 *)(a1 + 2 * v3 + 482) <= a2 ) /*0x103a4c626*/
    {
      if ( *(__int16 *)(a1 + 2 * v3 + 486) <= a2 ) /*0x103a4c668*/
        v14 = (*(_WORD *)(a1 + 2 * v3 + 488) > (unsigned __int16)a2) ^ 7LL; /*0x103a4c6ae*/
      else
        v14 = (*(_WORD *)(a1 + 2 * v3 + 484) > (unsigned __int16)a2) ^ 5LL; /*0x103a4c675*/
    }
    else if ( *(__int16 *)(a1 + 2 * v3 + 478) <= a2 ) /*0x103a4c62c*/
    {
      v14 = (*(_WORD *)(a1 + 2 * v3 + 480) > (unsigned __int16)a2) ^ 3LL; /*0x103a4c686*/
    }
    else
    {
      v14 = *v5 <= a2; /*0x103a4c634*/
    }
    goto LABEL_27; /*0x103a4c638*/
  }
  if ( *(__int16 *)(a1 + 2 * v3 + 506) <= a2 ) /*0x103a4c641*/
    goto LABEL_31; /*0x103a4c641*/
  if ( *(__int16 *)(a1 + 2 * v3 + 498) > a2 ) /*0x103a4c64b*/
  {
    if ( *(__int16 *)(a1 + 2 * v3 + 494) <= a2 ) /*0x103a4c651*/
      v14 = (*(_WORD *)(a1 + 2 * v3 + 496) > (unsigned __int16)a2) ^ 0xBLL; /*0x103a4c6bf*/
    else
      v14 = (*(_WORD *)(a1 + 2 * v3 + 492) > (unsigned __int16)a2) ^ 9LL; /*0x103a4c65e*/
    goto LABEL_27; /*0x103a4c662*/
  }
  if ( *(__int16 *)(a1 + 2 * v3 + 502) > a2 ) /*0x103a4c690*/
  {
    v14 = (*(_WORD *)(a1 + 2 * v3 + 500) > (unsigned __int16)a2) ^ 0xDLL; /*0x103a4c69d*/
    goto LABEL_27; /*0x103a4c6a1*/
  }
  v15 = 15; /*0x103a4c6c5*/
  v14 = 14; /*0x103a4c6cb*/
  if ( *(__int16 *)(a1 + 2 * v3 + 504) > a2 ) /*0x103a4c6d5*/
  {
LABEL_27:
    v16 = a1 + 2 * v3; /*0x103a4c6d7*/
    v17 = 253; /*0x103a4c6db*/
    do /*0x103a4c70f*/
    {
      v18 = *(_WORD *)(v16 + 2 * v17 - 194); /*0x103a4c6e1*/
      *(_WORD *)(v16 + 2 * v17) = *(_WORD *)(v16 + 2 * v17 - 2); /*0x103a4c6f0*/
      *(_WORD *)(v16 + 2 * v17 - 192) = v18; /*0x103a4c6f5*/
      v19 = v17 - 239 <= v14; /*0x103a4c709*/
      --v17; /*0x103a4c70c*/
    }
    while ( !v19 ); /*0x103a4c70f*/
    v15 = v14; /*0x103a4c711*/
  }
  v20 = (unsigned int)(2 * v15); /*0x103a4c714*/
  *(__int16 *)((char *)v5 + v20) = a2; /*0x103a4c717*/
  *(_WORD *)(v4 + v20) = 1; /*0x103a4c71c*/
LABEL_31:
  v21 = *(_DWORD *)(a1 + 276); /*0x103a4c723*/
  if ( v21 < 3 ) /*0x103a4c72c*/
  {
    if ( v21 <= 0 ) /*0x103a4c736*/
    {
      v23 = a3; /*0x103a4c78c*/
      v24 = *(_WORD *)(a1 + 2LL * a3 + 668); /*0x103a4c78f*/
      v25 = 0; /*0x103a4c797*/
      v22 = 1600; /*0x103a4c799*/
      goto LABEL_36; /*0x103a4c79e*/
    }
  }
  else
  {
    v5 += 2; /*0x103a4c72e*/
  }
  v22 = *v5; /*0x103a4c738*/
  v23 = a3; /*0x103a4c73b*/
  v24 = *(_WORD *)(a1 + 2LL * a3 + 668); /*0x103a4c73e*/
  v25 = 32439; /*0x103a4c74f*/
  if ( (__int16)v22 < v24 ) /*0x103a4c754*/
    v25 = 6553; /*0x103a4c754*/
LABEL_36:
  v26 = (v22 * (v25 ^ 0x7FFFu) + (v25 + 1) * v24 + 0x4000) >> 15; /*0x103a4c758*/
  *(_WORD *)(a1 + 2 * v23 + 668) = v26; /*0x103a4c778*/
  return (unsigned int)(__int16)v26; /*0x103a4c783*/
}

// Address: 0x103a4c7a0 | Name: _WebRtcVad_Create
_DWORD *WebRtcVad_Create()
{
  _DWORD *result; // rax

  result = malloc(__size: 0x2E0u); /*0x103a4c7a9*/
  result[183] = 0; /*0x103a4c7ae*/
  return result; /*0x103a4c7b8*/
}

// Address: 0x103a4c7ba | Name: _WebRtcVad_Free
void __fastcall WebRtcVad_Free(void *a1)
{
  free(a1); /*0x103a4c7bf*/
}

// Address: 0x103a4c7c4 | Name: _WebRtcVad_Init
__int64 __fastcall WebRtcVad_Init(__int64 a1)
{
  return WebRtcVad_InitCore(a1); /*0x103a4c7c8*/
}

// Address: 0x103a4c7ce | Name: _WebRtcVad_set_mode
__int64 __fastcall WebRtcVad_set_mode(__int64 a1, unsigned int a2)
{
  if ( a1 != 0 && *(_DWORD *)(a1 + 732) == 42 ) /*0x103a4c7de*/
    return WebRtcVad_set_mode_core(a1, a2); /*0x103a4c7e1*/
  else
    return 0xFFFFFFFFLL; /*0x103a4c7e6*/
}

// Address: 0x103a4c7ed | Name: _WebRtcVad_Process
__int64 __fastcall WebRtcVad_Process(__int64 a1, int a2, __int64 a3, unsigned __int64 a4)
{
  __int64 v4; // rax
  unsigned __int64 v5; // r8
  unsigned __int64 v6; // r9
  int v8; // eax
  unsigned int v9; // ecx

  if ( a1 == 0 || a3 == 0 || *(_DWORD *)(a1 + 732) != 42 ) /*0x103a4c7fe*/
    return 0xFFFFFFFFLL; /*0x103a4c851*/
  v4 = 0; /*0x103a4c800*/
  while ( *(_DWORD *)((char *)&kValidRates + v4) != a2 ) /*0x103a4c80d*/
  {
    v4 += 4; /*0x103a4c80f*/
    if ( v4 == 16 ) /*0x103a4c817*/
      return 0xFFFFFFFFLL; /*0x103a4c817*/
  }
  v5 = 0; /*0x103a4c83c*/
  v6 = a4; /*0x103a4c83f*/
  while ( 1 ) /*0x103a4c842*/
  {
    v6 -= 10LL * (a2 / 1000); /*0x103a4c842*/
    if ( v6 == 0 ) /*0x103a4c845*/
      break; /*0x103a4c845*/
    v5 += 10LL; /*0x103a4c847*/
    if ( v5 > 0x14 ) /*0x103a4c84f*/
      return 0xFFFFFFFFLL; /*0x103a4c84f*/
  }
  v8 = -1; /*0x103a4c85b*/
  if ( a2 > 31999 ) /*0x103a4c866*/
  {
    if ( a2 == 32000 ) /*0x103a4c88b*/
    {
      v8 = WebRtcVad_CalcVad32khz(a1, a2: a3, a3: a4); /*0x103a4c8b5*/
    }
    else if ( a2 == 48000 ) /*0x103a4c893*/
    {
      v8 = WebRtcVad_CalcVad48khz(a1, a2: a3, a3: a4); /*0x103a4c89b*/
    }
  }
  else if ( a2 == 8000 ) /*0x103a4c86e*/
  {
    v8 = WebRtcVad_CalcVad8khz(a1, a2: a3, a3: a4); /*0x103a4c8a8*/
  }
  else if ( a2 == 16000 ) /*0x103a4c876*/
  {
    v8 = WebRtcVad_CalcVad16khz(a1, a2: a3, a3: a4); /*0x103a4c87e*/
  }
  v9 = 1; /*0x103a4c8bc*/
  if ( v8 <= 0 ) /*0x103a4c8c1*/
    return (unsigned int)v8; /*0x103a4c8c1*/
  return v9; /*0x103a4c856*/
}

// Address: 0x103a4c8c8 | Name: _WebRtcVad_ValidRateAndFrameLength
__int64 __fastcall WebRtcVad_ValidRateAndFrameLength(int a1, __int64 a2)
{
  __int64 v2; // rax
  __int64 result; // rax
  unsigned __int64 v4; // rdx

  v2 = 0; /*0x103a4c8cc*/
  while ( *(_DWORD *)((char *)&kValidRates + v2) != a1 ) /*0x103a4c8d8*/
  {
    v2 += 4; /*0x103a4c8da*/
    if ( v2 == 16 ) /*0x103a4c8e2*/
      return 0xFFFFFFFFLL; /*0x103a4c919*/
  }
  result = 0; /*0x103a4c906*/
  v4 = 0; /*0x103a4c908*/
  while ( 1 ) /*0x103a4c90a*/
  {
    a2 -= 10LL * (a1 / 1000); /*0x103a4c90a*/
    if ( a2 == 0 ) /*0x103a4c90d*/
      break; /*0x103a4c90d*/
    v4 += 10LL; /*0x103a4c90f*/
    if ( v4 > 0x14 ) /*0x103a4c917*/
      return 0xFFFFFFFFLL; /*0x103a4c917*/
  }
  return result; /*0x103a4c91e*/
}

// Address: 0x103a4c920 | Name: _WebRtcIsac_AutoCorr
__int64 __fastcall WebRtcIsac_AutoCorr(__int64 a1, double *a2, __int64 a3, __int64 a4)
{
  __int64 v4; // rcx
  __int64 result; // rax
  double *v6; // r8
  double v7; // xmm0_8
  double v8; // xmm1_8
  unsigned __int64 v9; // r10

  v4 = (a4 == -1) + a4 + 1; /*0x103a4c92c*/
  result = 0; /*0x103a4c930*/
  v6 = a2; /*0x103a4c932*/
  do /*0x103a4c97f*/
  {
    v7 = *a2 * a2[result]; /*0x103a4c939*/
    v8 = 0.0; /*0x103a4c944*/
    if ( (unsigned __int64)(a3 - result) >= 2 ) /*0x103a4c94c*/
    {
      v9 = 1; /*0x103a4c94e*/
      do /*0x103a4c96a*/
      {
        v8 = v8 + v7; /*0x103a4c954*/
        v7 = a2[v9] * v6[v9]; /*0x103a4c95e*/
        ++v9; /*0x103a4c964*/
      }
      while ( v9 < a3 - result ); /*0x103a4c96a*/
    }
    *(double *)(a1 + 8 * result++) = v8 + v7; /*0x103a4c970*/
    ++v6; /*0x103a4c978*/
  }
  while ( result != v4 ); /*0x103a4c97f*/
  return result; /*0x103a4c981*/
}

// Address: 0x103a4c983 | Name: _WebRtcIsac_WeightingFilter
__int64 __fastcall WebRtcIsac_WeightingFilter(void *__src, void *a2, void *a3, _OWORD *a4)
{
  _BYTE *v6; // rbx
  __int128 v7; // xmm1
  __int128 v8; // xmm2
  _QWORD *v9; // r13
  __int128 v10; // xmm1
  __int128 v11; // xmm2
  _QWORD *v12; // r14
  int v13; // eax
  _BYTE *v14; // r12
  __int64 i; // rax
  double v16; // xmm0_8
  double *v17; // rax
  __int64 j; // rcx
  double v19; // xmm1_8
  unsigned __int64 v20; // rsi
  double v21; // xmm2_8
  __int64 v22; // rax
  double v23; // xmm0_8
  double v24; // xmm0_8
  __int128 v25; // xmm0
  __int128 v26; // xmm1
  __int128 v27; // xmm0
  __int128 v28; // xmm1
  int v30; // [rsp+0h] [rbp-2780h]
  double v33[240]; // [rsp+30h] [rbp-2750h] BYREF
  _QWORD v34[14]; // [rsp+7B0h] [rbp-1FD0h] BYREF
  _QWORD v35[246]; // [rsp+820h] [rbp-1F60h] BYREF
  _QWORD v36[240]; // [rsp+FD0h] [rbp-17B0h] BYREF
  double v37[8]; // [rsp+1750h] [rbp-1030h] BYREF
  double v38[8]; // [rsp+1790h] [rbp-FF0h] BYREF
  _BYTE v39[64]; // [rsp+17D0h] [rbp-FB0h] BYREF
  double v40[8]; // [rsp+1810h] [rbp-F70h] BYREF
  _BYTE __dst[1920]; // [rsp+1850h] [rbp-F30h] BYREF
  _BYTE __srca[1920]; // [rsp+1FD0h] [rbp-7B0h] BYREF

  memcpy(__dst, __src: a4, __n: sizeof(__dst)); /*0x103a4c9c8*/
  memcpy(__dst: __srca, __src, __n: sizeof(__srca)); /*0x103a4c9df*/
  v6 = __srca; /*0x103a4c9ec*/
  memcpy(__dst: a4, __src: __srca, __n: 0x780u); /*0x103a4c9f2*/
  memset(v34, 0, 56); /*0x103a4ca25*/
  v7 = a4[124]; /*0x103a4ca30*/
  v8 = a4[125]; /*0x103a4ca38*/
  v9 = v35; /*0x103a4ca40*/
  *(_OWORD *)&v34[8] = a4[123]; /*0x103a4ca47*/
  *(_OWORD *)&v34[10] = v7; /*0x103a4ca4c*/
  *(_OWORD *)&v34[12] = v8; /*0x103a4ca51*/
  v10 = a4[127]; /*0x103a4ca5f*/
  v11 = a4[128]; /*0x103a4ca68*/
  v12 = v36; /*0x103a4ca71*/
  *(_OWORD *)&v35[240] = a4[126]; /*0x103a4ca78*/
  *(_OWORD *)&v35[242] = v10; /*0x103a4ca7e*/
  *(_OWORD *)&v35[244] = v11; /*0x103a4ca84*/
  v34[0] = 0x3FF0000000000000LL; /*0x103a4ca94*/
  v13 = 0; /*0x103a4ca9f*/
  v14 = &__dst[480]; /*0x103a4caa1*/
  do /*0x103a4cc18*/
  {
    v30 = v13; /*0x103a4caa8*/
    for ( i = 0; i != 120; ++i ) /*0x103a4caaf*/
      *(__m128d *)&v33[i * 2] = _mm_mul_pd((__m128d)a4[i + 129], *(__m128d *)&v14[4 * i]); /*0x103a4cac1*/
    v16 = v33[0]; /*0x103a4cad6*/
    v17 = v33; /*0x103a4cade*/
    for ( j = 0; j != 7; ++j ) /*0x103a4cae5*/
    {
      v19 = v33[j] * v16; /*0x103a4caf8*/
      v20 = 1; /*0x103a4cafc*/
      v21 = 0.0; /*0x103a4cb01*/
      do /*0x103a4cb1d*/
      {
        v21 = v21 + v19; /*0x103a4cb05*/
        v19 = v33[v20] * v17[v20]; /*0x103a4cb12*/
        ++v20; /*0x103a4cb17*/
      }
      while ( v20 < 240 - j ); /*0x103a4cb1d*/
      v40[j] = v21 + v19; /*0x103a4cb23*/
      ++v17; /*0x103a4cb2f*/
    }
    v40[0] = v40[0] * 1.01 + 1.0; /*0x103a4cb58*/
    WebRtcIsac_LevDurb(a1: v38, a2: v39, a3: v40, a4: 6); /*0x103a4cb7a*/
    v37[0] = v38[0]; /*0x103a4cb87*/
    v22 = 1; /*0x103a4cb8f*/
    v23 = 0.9; /*0x103a4cb9c*/
    do /*0x103a4cbc1*/
    {
      v37[v22] = v38[v22] * v23; /*0x103a4cbad*/
      v23 = v23 * 0.9; /*0x103a4cbb6*/
      ++v22; /*0x103a4cbba*/
    }
    while ( v22 != 7 ); /*0x103a4cbc1*/
    WebRtcIsac_ZeroPoleFilter(a1: v6, a2: v38, a3: v37, a4: v9, a5: v23); /*0x103a4cbda*/
    WebRtcIsac_ZeroPoleFilter(a1: v6, a2: v37, a3: v34, a4: v12, a5: v24); /*0x103a4cbf6*/
    v6 += 480; /*0x103a4cc00*/
    v9 += 60; /*0x103a4cc03*/
    v12 += 60; /*0x103a4cc06*/
    v13 = v30 + 1; /*0x103a4cc10*/
    v14 += 480; /*0x103a4cc12*/
  }
  while ( v30 != 3 ); /*0x103a4cc18*/
  v25 = *(_OWORD *)&v35[234]; /*0x103a4cc1e*/
  v26 = *(_OWORD *)&v35[236]; /*0x103a4cc25*/
  a4[125] = *(_OWORD *)&v35[238]; /*0x103a4cc3a*/
  a4[124] = v26; /*0x103a4cc3e*/
  a4[123] = v25; /*0x103a4cc42*/
  v27 = *(_OWORD *)&v36[234]; /*0x103a4cc45*/
  v28 = *(_OWORD *)&v36[236]; /*0x103a4cc4c*/
  a4[128] = *(_OWORD *)&v36[238]; /*0x103a4cc61*/
  a4[127] = v28; /*0x103a4cc65*/
  a4[126] = v27; /*0x103a4cc69*/
  memcpy(__dst: a2, __src: v35, __n: 0x780u); /*0x103a4cc7f*/
  memcpy(__dst: a3, __src: v36, __n: 0x780u); /*0x103a4cc97*/
  return __stack_chk_guard; /*0x103a4ccac*/
}

// Address: 0x103a4ccc3 | Name: _WebRtcIsac_ZeroPoleFilter
double *__fastcall WebRtcIsac_ZeroPoleFilter(double *a1, double *a2, double *a3, double *a4)
{
  __int64 v4; // r8
  double *v5; // r9
  double v6; // xmm0_8
  __int64 v7; // r10
  double *v8; // r11
  double v9; // xmm1_8
  double *result; // rax
  __int64 i; // rsi
  double v12; // xmm0_8
  __int64 v13; // rdi
  double *v14; // r8
  double v15; // xmm0_8
  double *v16; // rdx
  double v17; // xmm1_8
  __int64 v18; // rsi
  double *v19; // rdi

  v4 = 0; /*0x103a4cccb*/
  v5 = a4; /*0x103a4ccce*/
  do /*0x103a4cd13*/
  {
    v6 = *a1 * *a2; /*0x103a4ccd5*/
    v7 = -1; /*0x103a4ccd9*/
    v8 = a2 + 1; /*0x103a4cce0*/
    do /*0x103a4ccfd*/
      v6 = v6 + *v8++ * a1[v7--]; /*0x103a4ccee*/
    while ( v7 != -7 ); /*0x103a4ccfd*/
    *v5++ = v6; /*0x103a4ccff*/
    ++a1; /*0x103a4cd08*/
    ++v4; /*0x103a4cd0c*/
  }
  while ( v4 != 60 ); /*0x103a4cd13*/
  v9 = *a3; /*0x103a4cd15*/
  if ( *a3 <= 0.9999 || v9 >= 1.0001 ) /*0x103a4cd2f*/
  {
    v15 = 1.0 / v9; /*0x103a4cd89*/
    v16 = a3 + 1; /*0x103a4cd8d*/
    result = nullptr; /*0x103a4cd91*/
    do /*0x103a4cdd6*/
    {
      v17 = *a4 * v15; /*0x103a4cd97*/
      *a4 = v17; /*0x103a4cd9b*/
      v18 = -1; /*0x103a4cd9f*/
      v19 = v16; /*0x103a4cda6*/
      do /*0x103a4cdc9*/
      {
        v17 = v17 - *v19 * v15 * a4[v18]; /*0x103a4cdb6*/
        *a4 = v17; /*0x103a4cdba*/
        --v18; /*0x103a4cdbe*/
        ++v19; /*0x103a4cdc1*/
      }
      while ( v18 != -7 ); /*0x103a4cdc9*/
      ++a4; /*0x103a4cdcb*/
      result = (double *)((char *)result + 1); /*0x103a4cdcf*/
    }
    while ( result != (double *)60 ); /*0x103a4cdd6*/
  }
  else
  {
    result = a3 + 2; /*0x103a4cd31*/
    for ( i = 0; i != 60; ++i ) /*0x103a4cd35*/
    {
      v12 = a3[1] * *(a4 - 1); /*0x103a4cd3c*/
      v13 = -2; /*0x103a4cd41*/
      v14 = a3 + 2; /*0x103a4cd48*/
      do /*0x103a4cd64*/
        v12 = v12 + *v14++ * a4[v13--]; /*0x103a4cd55*/
      while ( v13 != -7 ); /*0x103a4cd64*/
      *a4 = *a4 - v12; /*0x103a4cd6e*/
      ++a4; /*0x103a4cd72*/
    }
  }
  return result; /*0x103a4cdd8*/
}

// Address: 0x103a4cdda | Name: _WebRtcIsac_InitPitchFilter
__int64 __fastcall WebRtcIsac_InitPitchFilter(__int64 a1)
{
  __int64 result; // rax

  result = __bzero(a1, a2: 1560); /*0x103a4cde8*/
  *(_OWORD *)(a1 + 1560) = 0x4049000000000000uLL; /*0x103a4cdf5*/
  return result; /*0x103a4ce00*/
}

// Address: 0x103a4ce03 | Name: _WebRtcIsac_InitPitchAnalysis
void __fastcall WebRtcIsac_InitPitchAnalysis(__int64 a1)
{
  long double v2; // xmm0
  __int64 i; // r14
  double v4; // xmm0_8
  double v5; // [rsp+0h] [rbp-20h]
  __int64 v6; // [rsp+8h] [rbp-18h]

  __bzero(a1, a2: 2576); /*0x103a4ce16*/
  *(_QWORD *)(a1 + 2576) = 0x4049000000000000LL; /*0x103a4ce25*/
  __bzero(a1: a1 + 2584, a2: 1568); /*0x103a4ce38*/
  *(_QWORD *)(a1 + 4152) = 0x4049000000000000LL; /*0x103a4ce3d*/
  __bzero(a1: a1 + 4160, a2: 2072); /*0x103a4ce50*/
  *(_OWORD *)&v2 = 0x3FE0000000000000uLL; /*0x103a4ce55*/
  for ( i = 0; i != 240; ++i ) /*0x103a4ce5d*/
  {
    sin(__x: v2); /*0x103a4ce9b*/
    *(double *)(a1 + 8 * i + 6232) = v4 * v4; /*0x103a4cea4*/
    *((_QWORD *)&v2 + 1) = v6; /*0x103a4ceae*/
    *(double *)&v2 = v5 + 1.0; /*0x103a4ceb3*/
  }
}

// Address: 0x103a4ced0 | Name: _WebRtcIsac_InitPreFilterbank
__int64 __fastcall WebRtcIsac_InitPreFilterbank(__int64 a1)
{
  return __bzero(a1, a2: 792); /*0x103a4ced9*/
}

// Address: 0x103a4cedf | Name: _WebRtcIsac_LevDurb
__int64 __fastcall WebRtcIsac_LevDurb(__int64 a1, double *a2, double *a3, unsigned __int64 a4)
{
  __int64 result; // rax
  __int64 i; // rdx
  double v6; // xmm1_8
  double v7; // xmm0_8
  __int64 v8; // r10
  unsigned __int64 v9; // r8
  __int64 v10; // r9
  double v11; // xmm2_8
  double *v12; // r14
  __int64 v13; // r15
  double v14; // xmm3_8
  double *v15; // r14
  __int64 v16; // r15
  double v17; // xmm4_8
  double v18; // xmm5_8

  result = 0x3FF0000000000000LL; /*0x103a4cee8*/
  *(_QWORD *)a1 = 0x3FF0000000000000LL; /*0x103a4cef2*/
  if ( *a3 >= 1.0e-10 ) /*0x103a4cf05*/
  {
    v6 = -a3[1] / *a3; /*0x103a4cf3b*/
    *a2 = v6; /*0x103a4cf3f*/
    *(double *)(a1 + 8) = v6; /*0x103a4cf43*/
    v7 = a3[1] * *a2 + *a3; /*0x103a4cf51*/
    if ( a4 >= 2 ) /*0x103a4cf59*/
    {
      result = a1 + 8; /*0x103a4cf5f*/
      v8 = 1; /*0x103a4cf63*/
      v9 = 2; /*0x103a4cf69*/
      v10 = a1 + 8; /*0x103a4cf77*/
      do /*0x103a4d025*/
      {
        v11 = a3[v8 + 1]; /*0x103a4cf87*/
        v12 = (double *)(a1 + 8); /*0x103a4cf8e*/
        v13 = v8; /*0x103a4cf91*/
        do /*0x103a4cfaa*/
          v11 = v11 + *v12++ * a3[v13--]; /*0x103a4cf9f*/
        while ( v13 != 0 ); /*0x103a4cfaa*/
        v14 = -v11 / v7; /*0x103a4cfb4*/
        a2[v8] = v14; /*0x103a4cfb8*/
        v7 = v7 + v14 * v11; /*0x103a4cfc2*/
        v15 = (double *)(a1 + 8); /*0x103a4cfc6*/
        v16 = 0; /*0x103a4cfc9*/
        do /*0x103a4d006*/
        {
          v17 = *(double *)(v10 + 8 * v16); /*0x103a4cfd7*/
          v18 = a2[v8] * v17 + *v15; /*0x103a4cfe5*/
          *(double *)(v10 + 8 * v16) = *v15 * a2[v8] + v17; /*0x103a4cff1*/
          *v15 = v18; /*0x103a4cff7*/
          --v16; /*0x103a4cffc*/
          ++v15; /*0x103a4cfff*/
        }
        while ( -(__int64)(v9 >> 1) != v16 ); /*0x103a4d006*/
        *(double *)(a1 + 8 * (v8 + 1)) = a2[v8]; /*0x103a4d00e*/
        v10 += 8; /*0x103a4d018*/
        ++v8; /*0x103a4d01c*/
      }
      while ( v9++ != a4 ); /*0x103a4d025*/
    }
  }
  else if ( a4 != 0 ) /*0x103a4cf0e*/
  {
    result = 0; /*0x103a4cf14*/
    for ( i = 0; i != a4; ++i ) /*0x103a4cf16*/
    {
      a2[i] = 0.0; /*0x103a4cf18*/
      *(_QWORD *)(a1 + 8 * i + 8) = 0; /*0x103a4cf1c*/
    }
  }
  return result; /*0x103a4d02b*/
}

// Address: 0x103a4d032 | Name: _WebRtcIsac_AllPassFilter2Float
void __fastcall WebRtcIsac_AllPassFilter2Float(__int64 a1, __int64 a2, int a3, int a4, __int64 a5)
{
  __int64 i; // r9
  __int64 j; // r10
  float v7; // xmm1_4
  float v8; // xmm2_4

  if ( a4 > 0 ) /*0x103a4d038*/
  {
    for ( i = 0; i != a4; ++i ) /*0x103a4d03e*/
    {
      if ( a3 > 0 ) /*0x103a4d043*/
      {
        for ( j = 0; j != a3; *(float *)(a1 + 4 * j++) = v8 ) /*0x103a4d045*/
        {
          v7 = *(float *)(a1 + 4 * j); /*0x103a4d04e*/
          v8 = (float)(*(float *)(a2 + 4 * i) * v7) + *(float *)(a5 + 4 * i); /*0x103a4d05b*/
          *(float *)(a5 + 4 * i) = v7 - (float)(*(float *)(a2 + 4 * i) * v8); /*0x103a4d069*/
        }
      }
    }
  }
}

// Address: 0x103a4d087 | Name: _WebRtcIsac_SplitAndFilterFloat
__int64 __fastcall WebRtcIsac_SplitAndFilterFloat(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        _DWORD *a6)
{
  __int128 v6; // xmm5
  __int128 v7; // xmm0
  __int64 i; // rax
  __int128 v9; // xmm6
  float v10; // xmm5_4
  float *v11; // rax
  __int64 j; // rdi
  __int64 k; // rdi
  float v14; // xmm0_4
  float v15; // xmm1_4
  __int64 m; // r10
  float v17; // xmm3_4
  __m128 *v18; // rdi
  __int64 n; // r10
  _DWORD *v20; // rdi
  __int64 ii; // r10
  float v22; // xmm0_4
  float v23; // xmm1_4
  __int64 jj; // r11
  float v25; // xmm3_4
  __int64 kk; // r10
  __int64 v27; // rdi
  float *v28; // r10
  __int64 mm; // rdi
  float v31; // xmm0_4
  float v32; // xmm1_4
  __int64 nn; // r10
  float v34; // xmm3_4
  __m128 *v35; // rdi
  __int64 i1; // r10
  _DWORD *v37; // rdi
  __int64 i2; // r10
  float v39; // xmm0_4
  float v40; // xmm1_4
  __int64 i3; // r11
  float v42; // xmm3_4
  __int64 i4; // rax
  char v44; // al
  __int64 v45; // rdi
  float v46; // xmm0_4
  float v47; // xmm1_4
  __int64 v48; // rbx
  __int64 i5; // r14
  bool v50; // zf
  __int64 i6; // rdi
  float v52; // xmm0_4
  float v53; // xmm1_4
  __int64 i7; // r10
  float v55; // xmm3_4
  __int64 i8; // r10
  float v57; // xmm0_4
  float v58; // xmm1_4
  __int64 i9; // r11
  float v60; // xmm3_4
  __int64 i10; // r10
  float v62; // xmm1_4
  float v63; // xmm2_4
  __int64 i11; // rdx
  __m128 v65; // xmm2
  __m128 v66; // xmm3
  __int64 i12; // rdx
  float v68; // xmm1_4
  float v69; // xmm2_4
  __int64 i13; // rsi
  float v71; // xmm4_4
  __int64 i14; // rax
  float v73; // xmm1_4
  float v74; // xmm2_4
  __int64 i15; // rdx
  float v76; // xmm4_4
  __int64 i16; // rax
  float v78; // xmm1_4
  float v79; // xmm2_4
  _QWORD v81[238]; // [rsp+0h] [rbp-1EE0h]
  _BYTE v82[3940]; // [rsp+77Ch] [rbp-1764h] BYREF
  float v83[492]; // [rsp+16E0h] [rbp-800h] BYREF
  _QWORD v84[2]; // [rsp+1E90h] [rbp-50h]
  _QWORD v85[2]; // [rsp+1EA0h] [rbp-40h]
  _QWORD v86[2]; // [rsp+1EB0h] [rbp-30h]

  v6 = (unsigned int)a6[196]; /*0x103a4d0a5*/
  v7 = (unsigned int)a6[197]; /*0x103a4d0ae*/
  for ( i = 0; i != 480; ++i ) /*0x103a4d0b7*/
  {
    v9 = v6; /*0x103a4d0d9*/
    v10 = *(float *)(a1 + 4 * i); /*0x103a4d0dc*/
    *((float *)v81 + i) = (float)(*(float *)&v7 * 0.050154839) + (float)((float)(*(float *)&v9 * -0.05101826) + v10); /*0x103a4d0fa*/
    *(float *)&v7 = (float)(*(float *)&v7 * -0.94984514) + (float)((float)(*(float *)&v9 * 1.9489596) + v10); /*0x103a4d113*/
    a6[197] = v9; /*0x103a4d117*/
    a6[196] = v7; /*0x103a4d120*/
    v6 = v7; /*0x103a4d12c*/
    v7 = v9; /*0x103a4d12f*/
  }
  *(_OWORD *)v86 = 0; /*0x103a4d13d*/
  v11 = (float *)v82; /*0x103a4d141*/
  for ( j = 0; j != 240; ++j ) /*0x103a4d148*/
  {
    v83[j] = *v11; /*0x103a4d14e*/
    v11 -= 2; /*0x103a4d15a*/
  }
  for ( k = 0; k != 4; ++k ) /*0x103a4d167*/
  {
    v14 = WebRtcIsac_SplitAndFilterFloat_WebRtcIsac_kCompositeApFactorsFloat[k]; /*0x103a4d170*/
    v15 = *((float *)v86 + k); /*0x103a4d175*/
    for ( m = 0; m != 240; ++m ) /*0x103a4d17b*/
    {
      v17 = (float)(v14 * v83[m]) + v15; /*0x103a4d18f*/
      v15 = v83[m] - (float)(v14 * v17); /*0x103a4d19d*/
      v83[m] = v17; /*0x103a4d1a1*/
    }
    *((float *)v86 + k) = v15; /*0x103a4d1b7*/
  }
  v18 = (__m128 *)v83; /*0x103a4d1c6*/
  for ( n = 260; n != 20; n -= 4 ) /*0x103a4d1cd*/
  {
    *(__m128 *)&v82[4 * n + 1972] = _mm_shuffle_ps(*v18, *v18, 27); /*0x103a4d1da*/
    ++v18; /*0x103a4d1e3*/
  }
  *(_OWORD *)v85 = *(_OWORD *)v86; /*0x103a4d1f5*/
  v20 = a6 + 144; /*0x103a4d1f9*/
  for ( ii = 0; ii != 4; ++ii ) /*0x103a4d200*/
  {
    v22 = WebRtcIsac_SplitAndFilterFloat_WebRtcIsac_kCompositeApFactorsFloat[ii]; /*0x103a4d203*/
    v23 = *((float *)v86 + ii); /*0x103a4d209*/
    for ( jj = 0; jj != 24; ++jj ) /*0x103a4d210*/
    {
      v25 = (float)(v22 * *(float *)&v20[jj]) + v23; /*0x103a4d220*/
      v23 = *(float *)&v20[jj] - (float)(v22 * v25); /*0x103a4d22e*/
      *(float *)&v20[jj] = v25; /*0x103a4d232*/
    }
    *((float *)v86 + ii) = v23; /*0x103a4d241*/
  }
  for ( kk = 24; kk != 0; --kk ) /*0x103a4d251*/
  {
    *(_DWORD *)&v82[4 * kk + 1968] = *v20; /*0x103a4d25b*/
    *v20++ = HIDWORD(v81[kk + 215]); /*0x103a4d26f*/
  }
  *(_OWORD *)v86 = 0; /*0x103a4d27f*/
  v27 = 239; /*0x103a4d283*/
  v28 = v83; /*0x103a4d288*/
  do /*0x103a4d2a5*/
    *v28++ = *(float *)&v81[v27]; /*0x103a4d298*/
  while ( v27-- != 0 ); /*0x103a4d2a5*/
  for ( mm = 0; mm != 4; ++mm ) /*0x103a4d2a7*/
  {
    v31 = WebRtcIsac_SplitAndFilterFloat_WebRtcIsac_kCompositeApFactorsFloat[mm]; /*0x103a4d2a9*/
    v32 = *((float *)v86 + mm); /*0x103a4d2ae*/
    for ( nn = 0; nn != 240; ++nn ) /*0x103a4d2b4*/
    {
      v34 = (float)(v31 * v83[nn]) + v32; /*0x103a4d2c8*/
      v32 = v83[nn] - (float)(v31 * v34); /*0x103a4d2d6*/
      v83[nn] = v34; /*0x103a4d2da*/
    }
    *((float *)v86 + mm) = v32; /*0x103a4d2f0*/
  }
  v35 = (__m128 *)v83; /*0x103a4d2ff*/
  for ( i1 = 260; i1 != 20; i1 -= 4 ) /*0x103a4d306*/
  {
    *(__m128 *)&v82[4 * i1 + 4] = _mm_shuffle_ps(*v35, *v35, 27); /*0x103a4d313*/
    ++v35; /*0x103a4d31c*/
  }
  *(_OWORD *)v84 = *(_OWORD *)v86; /*0x103a4d32e*/
  v37 = a6 + 168; /*0x103a4d332*/
  for ( i2 = 0; i2 != 4; ++i2 ) /*0x103a4d339*/
  {
    v39 = WebRtcIsac_SplitAndFilterFloat_WebRtcIsac_kCompositeApFactorsFloat[i2]; /*0x103a4d33c*/
    v40 = *((float *)v86 + i2); /*0x103a4d342*/
    for ( i3 = 0; i3 != 24; ++i3 ) /*0x103a4d349*/
    {
      v42 = (float)(v39 * *(float *)&v37[i3]) + v40; /*0x103a4d359*/
      v40 = *(float *)&v37[i3] - (float)(v39 * v42); /*0x103a4d367*/
      *(float *)&v37[i3] = v42; /*0x103a4d36b*/
    }
    *((float *)v86 + i2) = v40; /*0x103a4d37a*/
  }
  for ( i4 = 239; i4 != 215; --i4 ) /*0x103a4d38a*/
  {
    *((_DWORD *)&v81[132] + i4) = *v37; /*0x103a4d393*/
    *v37++ = v81[i4]; /*0x103a4d3a5*/
  }
  v44 = 1; /*0x103a4d3b8*/
  v45 = 0; /*0x103a4d3ba*/
  do /*0x103a4d439*/
  {
    v46 = *(float *)&a6[v45 + 128]; /*0x103a4d3ca*/
    v47 = *(float *)&a6[v45 + 132]; /*0x103a4d3d4*/
    v48 = 8 * v45; /*0x103a4d3de*/
    for ( i5 = 0; i5 != 16; i5 += 4 ) /*0x103a4d3e6*/
    {
      v46 = v46 /*0x103a4d407*/
          + (float)(*(float *)((char *)v85 + i5)
                  * *(float *)((char *)&WebRtcIsac_SplitAndFilterFloat_WebRtcIsac_kTransform1Float + v48 + i5));
      v47 = v47 /*0x103a4d40b*/
          + (float)(*(float *)((char *)v84 + i5)
                  * *(float *)((char *)&WebRtcIsac_SplitAndFilterFloat_WebRtcIsac_kTransform2Float + v48 + i5));
    }
    *(float *)&a6[v45 + 128] = v46; /*0x103a4d419*/
    *(float *)&a6[v45 + 132] = v47; /*0x103a4d423*/
    v45 = 1; /*0x103a4d42d*/
    v50 = (v44 & 1) == 0; /*0x103a4d432*/
    v44 = 0; /*0x103a4d434*/
  }
  while ( !v50 ); /*0x103a4d439*/
  for ( i6 = 0; i6 != 2; ++i6 ) /*0x103a4d43b*/
  {
    v52 = WebRtcIsac_kUpperApFactorsFloat[i6]; /*0x103a4d444*/
    v53 = *(float *)&a6[i6 + 128]; /*0x103a4d449*/
    for ( i7 = 0; i7 != 240; ++i7 ) /*0x103a4d453*/
    {
      v55 = (float)(v52 * *(float *)&v82[4 * i7 + 1972]) + v53; /*0x103a4d467*/
      v53 = *(float *)&v82[4 * i7 + 1972] - (float)(v52 * v55); /*0x103a4d475*/
      *(float *)&v82[4 * i7 + 1972] = v55; /*0x103a4d479*/
    }
    *(float *)&a6[i6 + 128] = v53; /*0x103a4d48f*/
  }
  for ( i8 = 0; i8 != 2; ++i8 ) /*0x103a4d4a2*/
  {
    v57 = WebRtcIsac_kLowerApFactorsFloat[i8]; /*0x103a4d4ac*/
    v58 = *(float *)&a6[i8 + 132]; /*0x103a4d4b2*/
    for ( i9 = 0; i9 != 240; ++i9 ) /*0x103a4d4bc*/
    {
      v60 = (float)(v57 * *(float *)&v82[4 * i9 + 4]) + v58; /*0x103a4d4d0*/
      v58 = *(float *)&v82[4 * i9 + 4] - (float)(v57 * v60); /*0x103a4d4de*/
      *(float *)&v82[4 * i9 + 4] = v60; /*0x103a4d4e2*/
    }
    *(float *)&a6[i8 + 132] = v58; /*0x103a4d4f8*/
  }
  for ( i10 = 0; i10 != 240; ++i10 ) /*0x103a4d50b*/
  {
    v62 = *(float *)&v82[4 * i10 + 1972]; /*0x103a4d516*/
    v63 = *(float *)&v82[4 * i10 + 4]; /*0x103a4d520*/
    *(float *)(a2 + 4 * i10) = (float)(v62 + v63) * 0.5; /*0x103a4d535*/
    *(float *)(a3 + 4 * i10) = (float)(v62 - v63) * 0.5; /*0x103a4d543*/
  }
  for ( i11 = 0; i11 != 240; i11 += 4 ) /*0x103a4d555*/
  {
    v65 = *(__m128 *)&v81[i11 + 2]; /*0x103a4d55f*/
    v66 = _mm_shuffle_ps(*(__m128 *)&v81[i11], v65, 136); /*0x103a4d56a*/
    *(__m128 *)&v82[4 * i11 + 1972] = _mm_shuffle_ps(*(__m128 *)&v81[i11], v65, 221); /*0x103a4d572*/
    *(__m128 *)&v82[4 * i11 + 4] = v66; /*0x103a4d57a*/
  }
  for ( i12 = 0; i12 != 2; ++i12 ) /*0x103a4d58f*/
  {
    v68 = WebRtcIsac_kUpperApFactorsFloat[i12]; /*0x103a4d591*/
    v69 = *(float *)&a6[i12 + 136]; /*0x103a4d596*/
    for ( i13 = 0; i13 != 240; ++i13 ) /*0x103a4d5a0*/
    {
      v71 = (float)(v68 * *(float *)&v82[4 * i13 + 1972]) + v69; /*0x103a4d5b2*/
      v69 = *(float *)&v82[4 * i13 + 1972] - (float)(v68 * v71); /*0x103a4d5c0*/
      *(float *)&v82[4 * i13 + 1972] = v71; /*0x103a4d5c4*/
    }
    *(float *)&a6[i12 + 136] = v69; /*0x103a4d5d9*/
  }
  for ( i14 = 0; i14 != 2; ++i14 ) /*0x103a4d5ec*/
  {
    v73 = WebRtcIsac_kLowerApFactorsFloat[i14]; /*0x103a4d5ee*/
    v74 = *(float *)&a6[i14 + 140]; /*0x103a4d5f3*/
    for ( i15 = 0; i15 != 240; ++i15 ) /*0x103a4d5fd*/
    {
      v76 = (float)(v73 * *(float *)&v82[4 * i15 + 4]) + v74; /*0x103a4d60f*/
      v74 = *(float *)&v82[4 * i15 + 4] - (float)(v73 * v76); /*0x103a4d61d*/
      *(float *)&v82[4 * i15 + 4] = v76; /*0x103a4d621*/
    }
    *(float *)&a6[i14 + 140] = v74; /*0x103a4d636*/
  }
  for ( i16 = 0; i16 != 240; ++i16 ) /*0x103a4d649*/
  {
    v78 = *(float *)&v82[4 * i16 + 1972]; /*0x103a4d64b*/
    v79 = *(float *)&v82[4 * i16 + 4]; /*0x103a4d654*/
    *(double *)(a4 + 8 * i16) = (float)((float)(v78 + v79) * 0.5); /*0x103a4d66c*/
    *(double *)(a5 + 8 * i16) = (float)((float)(v78 - v79) * 0.5); /*0x103a4d67d*/
  }
  return __stack_chk_guard; /*0x103a4d69e*/
}

// Address: 0x103a4d6b1 | Name: _WebRtcIsac_PitchAnalysis
__int64 __fastcall WebRtcIsac_PitchAnalysis(double *a1, __int64 a2, __int64 a3, __int64 a4, double *a5)
{
  double v8; // xmm5_8
  __int128 v9; // xmm0
  __int64 i; // rax
  double v11; // xmm6_8
  __int128 v12; // xmm7
  double v13; // xmm0_8
  __m128i v14; // xmm0
  __int64 v15; // rax
  __m128i si128; // xmm1
  __m128i v17; // xmm2
  __m128i v18; // xmm3
  __m128i v19; // xmm4
  __m128i v20; // xmm5
  __m128i v21; // xmm6
  __m128i v22; // xmm7
  __m128i v23; // xmm7
  __m128i v24; // xmm8
  char v25; // al
  __int64 v26; // rcx
  double v27; // xmm1_8
  double v28; // xmm0_8
  unsigned __int64 v29; // rsi
  double v30; // xmm2_8
  double v31; // xmm3_8
  bool v32; // zf
  char v33; // al
  __int64 v34; // rcx
  double v35; // xmm1_8
  double v36; // xmm0_8
  unsigned __int64 v37; // rsi
  double v38; // xmm2_8
  double v39; // xmm3_8
  unsigned __int64 j; // rax
  __int64 v41; // rax
  double v42; // xmm2_8
  double v43; // xmm3_8
  double v44; // xmm0_8
  __int64 k; // r14
  double v46; // xmm0_8
  __int64 v47; // rax
  __int64 m; // rcx
  double v49; // xmm0_8
  __int64 v50; // rax
  __int64 v51; // rdx
  __int64 v52; // rsi
  double v53; // xmm0_8
  unsigned __int64 v54; // rcx
  double v55; // xmm1_8
  double v56; // xmm0_8
  __int64 v57; // rdx
  unsigned __int64 v58; // rsi
  __int64 v59; // rax
  double v60; // xmm3_8
  double v61; // xmm3_8
  double v62; // xmm5_8
  int v63; // edi
  double v64; // xmm5_8
  double v65; // xmm0_8
  __int64 v66; // r8
  __int64 v67; // rdx
  __int64 v68; // rsi
  __int64 v69; // rdi
  __int64 v70; // r8
  int v71; // r9d
  unsigned __int64 n; // r10
  double v73; // xmm3_8
  double v74; // xmm4_8
  unsigned __int64 v75; // rax
  double v76; // xmm4_8
  double v77; // xmm0_8
  __int64 v78; // rdx
  __int64 v79; // rsi
  _QWORD *v80; // r8
  __int64 v81; // r9
  __int64 v82; // r10
  int v83; // r11d
  double *v84; // r14
  __int64 v85; // r13
  __int64 v86; // r15
  __int64 v87; // rdi
  __int64 v88; // r15
  int v89; // eax
  unsigned __int64 v90; // rdx
  double v91; // xmm2_8
  double v92; // xmm3_8
  double v93; // xmm2_8
  unsigned __int64 v94; // rsi
  double v95; // xmm2_8
  double v96; // xmm0_8
  double v97; // xmm0_8
  int v98; // edx
  unsigned __int64 v99; // rdi
  __int64 v100; // r8
  unsigned __int64 *v101; // r15
  __int64 v102; // rax
  __int64 v103; // r10
  double v104; // xmm1_8
  __int64 v105; // r14
  __int64 v106; // r14
  __int64 ii; // rcx
  int v108; // r13d
  __m128d v109; // xmm8
  __m128d v110; // xmm9
  __m128d v111; // xmm6
  __m128d v112; // xmm5
  __m128d v113; // xmm7
  __m128d v114; // xmm2
  __m128d v115; // xmm3
  __m128d v116; // xmm11
  __m128d v117; // xmm2
  __m128d v118; // xmm11
  __m128d v119; // xmm12
  __m128d v120; // xmm10
  __m128d v121; // xmm2
  __m128d v122; // xmm8
  __m128d v123; // xmm6
  __m128d v124; // xmm15
  __m128d v125; // xmm2
  __m128d v126; // xmm4
  __m128d v127; // xmm15
  __m128d v128; // xmm9
  __m128d v129; // xmm3
  __m128d v130; // xmm8
  __m128d v131; // xmm5
  double v132; // xmm4_8
  int v133; // esi
  double v134; // xmm1_8
  double v135; // xmm13_8
  __m128d v136; // xmm6
  __m128d v137; // xmm9
  __m128d v138; // xmm1
  __m128d v139; // xmm4
  __m128d v140; // xmm3
  __m128d v141; // xmm1
  __m128d v142; // xmm4
  __m128d v143; // xmm1
  __m128d v144; // xmm1
  __m128d v145; // xmm2
  __m128d v146; // xmm0
  __m128d v147; // xmm0
  __m128d v148; // xmm8
  __m128d v149; // xmm2
  double v150; // xmm6_8
  __m128d v151; // xmm6
  double v152; // xmm0_8
  __m128d v153; // xmm6
  __m128d v154; // xmm4
  __m128d v155; // xmm4
  __m128d v156; // xmm2
  __m128d v157; // xmm1
  __m128d v158; // xmm8
  double v159; // xmm4_8
  __m128d v160; // xmm0
  __m128d v161; // xmm1
  double v162; // xmm4_8
  __m128d v163; // xmm0
  __m128d v164; // xmm12
  __m128d v165; // xmm12
  double v166; // xmm2_8
  __m128d v167; // xmm0
  __m128d v168; // xmm1
  __m128d v169; // xmm12
  double v170; // xmm4_8
  double v171; // xmm3_8
  double v172; // xmm12_8
  double v173; // xmm4_8
  __m128d v174; // xmm5
  double v175; // xmm7_8
  __m128d v176; // xmm5
  __m128d v177; // xmm2
  double v178; // xmm6_8
  double v179; // xmm4_8
  double v180; // xmm3_8
  double v181; // xmm2_8
  double v182; // xmm3_8
  __m128d v183; // xmm4
  double v184; // xmm6_8
  double v185; // xmm6_8
  double v186; // xmm0_8
  __int64 jj; // r15
  int v188; // edi
  double v189; // xmm0_8
  double v190; // xmm0_8
  double v191; // xmm1_8
  __m128d v192; // xmm0
  __m128d v193; // xmm2
  __m128d v194; // xmm1
  double v195; // xmm1_8
  __int64 kk; // rax
  int v197; // eax
  void *v198; // r9
  unsigned __int64 *v199; // r14
  void *v200; // r15
  _BYTE *v201; // rax
  __int64 mm; // rcx
  double v203; // xmm0_8
  __int64 nn; // rdx
  __int64 v205; // rax
  _BYTE *v206; // rcx
  __int64 i1; // rdx
  _BYTE *v208; // rdi
  __int64 v209; // r8
  double v210; // xmm0_8
  __int64 i2; // r9
  double *v212; // rax
  __int64 v213; // rcx
  __int64 v214; // rdx
  double v215; // xmm0_8
  __int64 i3; // rsi
  __int64 v217; // rax
  double *v218; // rcx
  unsigned __int64 *v219; // rdx
  __int64 v220; // rsi
  __int64 v221; // rdi
  double *v222; // rax
  __int64 i4; // rcx
  double v224; // xmm1_8
  double v225; // xmm0_8
  double v226; // xmm3_8
  double v227; // xmm0_8
  double v228; // xmm3_8
  __m128d v229; // xmm0
  double v230; // xmm1_8
  double v231; // xmm2_8
  __m128d v232; // xmm8
  __m128d v233; // xmm4
  __m128d v234; // xmm4
  double v235; // xmm5_8
  double v236; // xmm6_8
  __int64 v237; // rax
  __m128i v238; // xmm7
  double *v239; // rax
  __int64 i5; // rcx
  __m128d v241; // xmm3
  __int64 i6; // rax
  __m128d v243; // xmm0
  __m128d v244; // xmm2
  __m128d v245; // xmm1
  __m128d v246; // xmm0
  __m128d v247; // xmm1
  __m128i v248; // xmm0
  __m128d v249; // xmm1
  unsigned __int64 v251; // rdi
  __int64 v252; // r8
  __int64 v253; // rax
  __int64 v254; // r10
  double v255; // xmm1_8
  __int64 v256; // r14
  int v257; // eax
  int v258; // ecx
  int v259; // esi
  long double v260; // [rsp+0h] [rbp-6360h]
  long double v261; // [rsp+0h] [rbp-6360h]
  long double v262; // [rsp+0h] [rbp-6360h]
  long double v263; // [rsp+0h] [rbp-6360h]
  long double v264; // [rsp+0h] [rbp-6360h]
  double v265; // [rsp+10h] [rbp-6350h]
  double v266; // [rsp+20h] [rbp-6340h]
  __m128d v267; // [rsp+30h] [rbp-6330h]
  __m128d v268; // [rsp+40h] [rbp-6320h]
  __m128d v269; // [rsp+50h] [rbp-6310h]
  __m128d v270; // [rsp+70h] [rbp-62F0h]
  __m128d v271; // [rsp+80h] [rbp-62E0h]
  __m128d v272; // [rsp+90h] [rbp-62D0h]
  __m128d v273; // [rsp+A0h] [rbp-62C0h]
  double v276; // [rsp+C8h] [rbp-6298h]
  __int64 v277; // [rsp+D0h] [rbp-6290h]
  __m128d v278; // [rsp+E0h] [rbp-6280h]
  __int64 v279; // [rsp+F8h] [rbp-6268h]
  double v280; // [rsp+100h] [rbp-6260h]
  int __n[2]; // [rsp+108h] [rbp-6258h]
  double v282; // [rsp+110h] [rbp-6250h]
  __int64 v283; // [rsp+110h] [rbp-6250h]
  __m128d v284; // [rsp+110h] [rbp-6250h]
  double v285; // [rsp+110h] [rbp-6250h]
  __m128d v286; // [rsp+120h] [rbp-6240h]
  _QWORD v287[120]; // [rsp+130h] [rbp-6230h] BYREF
  _BYTE v288[576]; // [rsp+4F0h] [rbp-5E70h] BYREF
  _QWORD v289[264]; // [rsp+970h] [rbp-59F0h] BYREF
  double __dst[24]; // [rsp+11B0h] [rbp-51B0h] BYREF
  _BYTE v291[1920]; // [rsp+1270h] [rbp-50F0h] BYREF
  _QWORD v292[240]; // [rsp+19F0h] [rbp-4970h] BYREF
  _QWORD v293[260]; // [rsp+2170h] [rbp-41F0h] BYREF
  double v294; // [rsp+2990h] [rbp-39D0h]
  double v295; // [rsp+2998h] [rbp-39C8h]
  double v296; // [rsp+29A0h] [rbp-39C0h]
  double v297; // [rsp+29A8h] [rbp-39B8h]
  _DWORD v298[12]; // [rsp+29E0h] [rbp-3980h]
  __int64 v299; // [rsp+2A10h] [rbp-3950h] BYREF
  __int64 v300; // [rsp+2A18h] [rbp-3948h]
  double v301; // [rsp+2A28h] [rbp-3938h]
  __int64 v302; // [rsp+2A68h] [rbp-38F8h]
  __int64 v303; // [rsp+2AB8h] [rbp-38A8h]
  __int64 v304; // [rsp+2AC0h] [rbp-38A0h]
  _BYTE v305[13888]; // [rsp+2AE0h] [rbp-3880h] BYREF
  unsigned __int64 v306; // [rsp+6120h] [rbp-240h] BYREF
  __m128d v307; // [rsp+6128h] [rbp-238h]
  double v308; // [rsp+6138h] [rbp-228h]
  __m128d v309; // [rsp+6140h] [rbp-220h]
  __m128d v310; // [rsp+6150h] [rbp-210h]
  unsigned __int64 v311; // [rsp+6160h] [rbp-200h]
  double v312; // [rsp+6168h] [rbp-1F8h] BYREF
  double v313; // [rsp+6170h] [rbp-1F0h]
  double v314; // [rsp+6178h] [rbp-1E8h]
  double v315; // [rsp+6180h] [rbp-1E0h]
  double v316; // [rsp+6188h] [rbp-1D8h]
  double v317; // [rsp+6190h] [rbp-1D0h]
  double v318; // [rsp+6198h] [rbp-1C8h]
  __int64 savedregs; // [rsp+6360h] [rbp+0h] BYREF

  v8 = *(double *)(a3 + 616); /*0x103a4d6e3*/
  v9 = *(unsigned __int64 *)(a3 + 624); /*0x103a4d6eb*/
  for ( i = 0; i != 240; ++i ) /*0x103a4d6f3*/
  {
    v11 = a1[i]; /*0x103a4d715*/
    *(double *)&v9 = *(double *)&v9 + v11; /*0x103a4d71a*/
    v293[i] = v9; /*0x103a4d71e*/
    *((_QWORD *)&v12 + 1) = *((_QWORD *)&v9 + 1); /*0x103a4d72f*/
    *(double *)&v12 = *(double *)&v9 * 1.86864659625574 + v11 * -1.9952459171827 + v8; /*0x103a4d737*/
    *(_QWORD *)(a3 + 624) = v12; /*0x103a4d73b*/
    v13 = *(double *)&v9 * -0.8836000000000001 + a1[i] * 0.996004; /*0x103a4d752*/
    *(double *)(a3 + 616) = v13; /*0x103a4d756*/
    v8 = v13; /*0x103a4d763*/
    v9 = v12; /*0x103a4d767*/
  }
  memcpy(__dst, __src: (const void *)(a3 + 632), __n: sizeof(__dst)); /*0x103a4d791*/
  WebRtcIsac_WeightingFilter(__src: v293, a2: v292, a3: v291, a4: (_OWORD *)(a3 + 4168)); /*0x103a4d7b3*/
  memcpy(__dst: (void *)(a3 + 632), __src: &v291[1728], __n: 0xC0u); /*0x103a4d7c7*/
  v286.f64[0] = *(double *)(a3 + 2576); /*0x103a4d7d6*/
  v276 = *(double *)(a3 + 2584); /*0x103a4d7e8*/
  v14 = _mm_cvtepi8_epi64(256); /*0x103a4d7f0*/
  v15 = 1; /*0x103a4d7f9*/
  si128 = _mm_load_si128((const __m128i *)&xmmword_108F246C0); /*0x103a4d7fe*/
  v17 = _mm_load_si128((const __m128i *)&xmmword_109597650); /*0x103a4d806*/
  v18 = _mm_shuffle_epi32(v17, 245); /*0x103a4d80e*/
  v19 = _mm_cvtepi8_epi64(17733); /*0x103a4d813*/
  v20 = _mm_cvtepi8_epi64(2570); /*0x103a4d81c*/
  v21 = _mm_cvtepi8_epi64(514); /*0x103a4d825*/
  do /*0x103a4d8ca*/
  {
    v22 = _mm_xor_si128(v14, si128); /*0x103a4d832*/
    v23 = _mm_and_si128(_mm_cmpeq_epi32(_mm_shuffle_epi32(v22, 245), v18), _mm_cmpgt_epi32(v17, v22)); /*0x103a4d849*/
    v24 = _mm_add_epi64( /*0x103a4d873*/
            _mm_add_epi64(
              _mm_slli_epi64(_mm_mul_epu32(_mm_srli_epi64(v14, 0x20u), v19), 0x20u),
              _mm_mul_epu32(v14, v19)),
            v20);
    if ( (_mm_cvtsi128_si32(v23) & 1) != 0 ) /*0x103a4d87f*/
      *(_QWORD *)&v298[2 * v15 + 10] = &savedregs + v24.i64[0] - 1808; /*0x103a4d891*/
    if ( (_mm_extract_epi8(v23, 8) & 1) != 0 ) /*0x103a4d8a2*/
      *(&v299 + v15) = (__int64)(&savedregs + _mm_extract_epi64(v24, 1) - 1808); /*0x103a4d8b6*/
    v14 = _mm_add_epi64(v14, v21); /*0x103a4d8be*/
    v15 += 2; /*0x103a4d8c2*/
  }
  while ( v15 != 27 ); /*0x103a4d8ca*/
  __bzero(a1: v305, a2: 13880); /*0x103a4d8dc*/
  memcpy(__dst: v287, __src: (const void *)a3, __n: 0x240u); /*0x103a4d8f0*/
  memcpy(__dst: &v289[1], __src: v292, __n: 0x778u); /*0x103a4d90e*/
  v289[0] = *(_QWORD *)(a3 + 608); /*0x103a4d91d*/
  *(_QWORD *)(a3 + 608) = v292[239]; /*0x103a4d92c*/
  v25 = 1; /*0x103a4d936*/
  v26 = 0; /*0x103a4d938*/
  do /*0x103a4d9a4*/
  {
    v27 = *(double *)(a3 + 8 * v26 + 576); /*0x103a4d941*/
    v28 = WebRtcIsac_DecimateAllpass_APupper[v26]; /*0x103a4d94b*/
    v29 = -2; /*0x103a4d950*/
    do /*0x103a4d98c*/
    {
      v30 = *(double *)&v289[v29 + 3]; /*0x103a4d957*/
      v31 = v28 * v30 + v27; /*0x103a4d968*/
      *(double *)&v289[v29 + 3] = v31; /*0x103a4d96c*/
      v27 = v30 - v31 * v28; /*0x103a4d97d*/
      v29 += 2LL; /*0x103a4d981*/
    }
    while ( v29 < 0xEE ); /*0x103a4d98c*/
    *(double *)(a3 + 8 * v26 + 576) = v27; /*0x103a4d98e*/
    v26 = 1; /*0x103a4d998*/
    v32 = (v25 & 1) == 0; /*0x103a4d99d*/
    v25 = 0; /*0x103a4d99f*/
  }
  while ( !v32 ); /*0x103a4d9a4*/
  v33 = 1; /*0x103a4d9a6*/
  v34 = 0; /*0x103a4d9a8*/
  do /*0x103a4da14*/
  {
    v35 = *(double *)(a3 + 8 * v34 + 592); /*0x103a4d9b1*/
    v36 = WebRtcIsac_DecimateAllpass_APlower[v34]; /*0x103a4d9bb*/
    v37 = -2; /*0x103a4d9c0*/
    do /*0x103a4d9fc*/
    {
      v38 = *(double *)&v289[v37 + 2]; /*0x103a4d9c7*/
      v39 = v36 * v38 + v35; /*0x103a4d9d8*/
      *(double *)&v289[v37 + 2] = v39; /*0x103a4d9dc*/
      v35 = v38 - v39 * v36; /*0x103a4d9ed*/
      v37 += 2LL; /*0x103a4d9f1*/
    }
    while ( v37 < 0xEE ); /*0x103a4d9fc*/
    *(double *)(a3 + 8 * v34 + 592) = v35; /*0x103a4d9fe*/
    v34 = 1; /*0x103a4da08*/
    v32 = (v33 & 1) == 0; /*0x103a4da0d*/
    v33 = 0; /*0x103a4da0f*/
  }
  while ( !v32 ); /*0x103a4da14*/
  for ( j = 0; j != 240; j += 4LL ) /*0x103a4da16*/
    *(__m128d *)&v287[j / 2 + 72] = _mm_hadd_pd(*(__m128d *)&v289[j], *(__m128d *)&v289[j + 2]); /*0x103a4da2a*/
  v41 = 72; /*0x103a4da3f*/
  v42 = *(double *)&v287[71]; /*0x103a4da44*/
  do /*0x103a4da90*/
  {
    v43 = v286.f64[v41] * -0.25 + v42 * 0.75 + *(double *)&v287[v41]; /*0x103a4da71*/
    *(double *)&v287[v41++] = v43; /*0x103a4da7a*/
    v42 = v43; /*0x103a4da86*/
  }
  while ( v41 != 192 ); /*0x103a4da90*/
  memcpy(__dst: (void *)a3, __src: v288, __n: 0x240u); /*0x103a4daa1*/
  PCorr(a1: v287, a2: v289); /*0x103a4dab4*/
  PCorr(a1: &v287[60], a2: &v306); /*0x103a4dac7*/
  log(__x: v260); /*0x103a4dadc*/
  v286.f64[0] = v44; /*0x103a4dae1*/
  v282 = fmin(0.8, 4.0 * v276 * v276); /*0x103a4db0d*/
  for ( k = 0; k != 65; ++k ) /*0x103a4db15*/
  {
    log(__x: v261); /*0x103a4db23*/
    exp(__x: v262); /*0x103a4db40*/
    *(double *)&v289[k] = (v46 * v282 + 1.0) * *(double *)&v289[k]; /*0x103a4db63*/
  }
  v47 = 64; /*0x103a4db76*/
  for ( m = 0; m != 3; ++m ) /*0x103a4db7b*/
  {
    v49 = *(double *)((char *)&unk_10958E8A0 + m * 8); /*0x103a4db84*/
    *(double *)&v289[m] = *(double *)&v289[m] * v49; /*0x103a4db96*/
    *(double *)((char *)&v306 + m * 8) = *(double *)((char *)&v306 + m * 8) * v49; /*0x103a4dbac*/
    *(double *)&v289[v47] = *(double *)&v289[v47] * v49; /*0x103a4dbc2*/
    *(double *)((char *)&v306 + v47 * 8) = v49 * *(double *)((char *)&v306 + v47 * 8); /*0x103a4dbd4*/
    --v47; /*0x103a4dbe1*/
  }
  v50 = v302; /*0x103a4dbf2*/
  *(_QWORD *)__n = v299; /*0x103a4dbfc*/
  v51 = v302 - v299 + 16; /*0x103a4dc06*/
  v52 = 0; /*0x103a4dc0a*/
  v53 = 0.0; /*0x103a4dc0c*/
  LODWORD(v54) = 0; /*0x103a4dc10*/
  do /*0x103a4dc4c*/
  {
    v55 = v53; /*0x103a4dc12*/
    v56 = *(double *)&v289[v52] + *(double *)((char *)&v306 + v52 * 8); /*0x103a4dc1f*/
    if ( v56 > v55 ) /*0x103a4dc34*/
      LODWORD(v54) = (unsigned __int64)(v51 + v52 * 8) >> 3; /*0x103a4dc34*/
    *(double *)(v50 + v52 * 8 + 16) = v56; /*0x103a4dc37*/
    v53 = fmax(v56, v55); /*0x103a4dc3d*/
    ++v52; /*0x103a4dc41*/
  }
  while ( v52 != 65 ); /*0x103a4dc4c*/
  v279 = a4; /*0x103a4dc55*/
  v57 = v304; /*0x103a4dc5c*/
  v58 = v304 - *(_QWORD *)__n + 104; /*0x103a4dc70*/
  v59 = 0; /*0x103a4dc74*/
  do /*0x103a4dd16*/
  {
    v60 = (double)((int)v59 + 12) / (double)((int)v59 + 23); /*0x103a4dc9a*/
    v61 = v60 * 0.2 * (2.0 - v60); /*0x103a4dcbc*/
    v62 = (*(double *)&v289[v59] + *(&v314 + v59)) * v61; /*0x103a4dcc0*/
    v63 = v59 + 2; /*0x103a4dcc8*/
    if ( v62 <= v53 ) /*0x103a4dccb*/
      v63 = v54; /*0x103a4dccb*/
    *(double *)(*(_QWORD *)__n + 8 * v59 + 16) = v62; /*0x103a4dcce*/
    v64 = fmax(v62, v53); /*0x103a4dcd5*/
    v65 = (*(double *)&v289[v59 + 11] + *((double *)&v306 + v59)) * v61; /*0x103a4dceb*/
    *(double *)(v57 + 8 * v59 + 104) = v65; /*0x103a4dcef*/
    v54 = v58 >> 3; /*0x103a4dcf8*/
    v66 = v59 + 1; /*0x103a4dd00*/
    if ( v65 <= v64 ) /*0x103a4dd04*/
      LODWORD(v54) = v63; /*0x103a4dd04*/
    v53 = fmax(v65, v64); /*0x103a4dd07*/
    v58 += 8LL; /*0x103a4dd0b*/
    ++v59; /*0x103a4dd0f*/
  }
  while ( v66 != 54 ); /*0x103a4dd16*/
  v67 = v300; /*0x103a4dd1c*/
  v68 = v303; /*0x103a4dd23*/
  v69 = v303 - *(_QWORD *)__n + 96; /*0x103a4dd30*/
  v70 = v300 - *(_QWORD *)__n + 16; /*0x103a4dd3a*/
  v71 = 12; /*0x103a4dd3e*/
  for ( n = 0; n != 440; n += 8LL ) /*0x103a4dd44*/
  {
    v73 = (double)v71 / (double)(v71 + 10) * 0.9 * (2.0 - (double)v71 / (double)(v71 + 10)); /*0x103a4dd72*/
    v74 = (*(double *)&v289[n / 8] + *(double *)((char *)&v313 + n)) * v73; /*0x103a4dd8a*/
    *(double *)(v67 + n + 16) = v74; /*0x103a4dd8e*/
    v75 = (v70 + n) >> 3; /*0x103a4dd99*/
    if ( v74 <= v53 ) /*0x103a4dda1*/
      LODWORD(v75) = v54; /*0x103a4dda1*/
    v76 = fmax(v74, v53); /*0x103a4dda4*/
    v77 = (*(double *)&v289[n / 8 + 10] + *(double *)((char *)&v306 + n)) * v73; /*0x103a4ddbc*/
    v54 = (v69 + n) >> 3; /*0x103a4ddc4*/
    *(double *)(v68 + n + 96) = v77; /*0x103a4ddcc*/
    if ( v77 <= v76 ) /*0x103a4ddd3*/
      LODWORD(v54) = v75; /*0x103a4ddd3*/
    v53 = fmax(v77, v76); /*0x103a4ddd6*/
    ++v71; /*0x103a4ddde*/
  }
  v78 = 88; /*0x103a4ddee*/
  v79 = 88LL - *(_QWORD *)__n; /*0x103a4ddf8*/
  v80 = &v289[9]; /*0x103a4de0a*/
  v81 = 2; /*0x103a4de11*/
  v82 = 448; /*0x103a4de17*/
  v83 = 0; /*0x103a4de1d*/
  v84 = &v312; /*0x103a4de20*/
  do /*0x103a4df22*/
  {
    v85 = *(&v299 + v81); /*0x103a4de27*/
    v86 = *(__int64 *)((char *)&v299 + (unsigned int)(8 * (22 - v81))); /*0x103a4de3a*/
    v283 = v79; /*0x103a4de42*/
    v87 = v86 + v79; /*0x103a4de49*/
    *(_QWORD *)&v286.f64[0] = v78; /*0x103a4de4d*/
    v88 = v78 + v86; /*0x103a4de54*/
    v89 = 12; /*0x103a4de62*/
    v90 = 0; /*0x103a4de67*/
    do /*0x103a4def0*/
    {
      v91 = (double)v89 / (double)(v83 + v89 + 9); /*0x103a4de7e*/
      v92 = (2.0 - v91) * v91; /*0x103a4de8a*/
      v93 = (*(double *)&v289[v90 / 8] + v84[v90 / 8]) * v92; /*0x103a4de9d*/
      *(double *)(v85 + v90 + 16) = v93; /*0x103a4dea1*/
      v94 = (16LL - *(_QWORD *)__n + v85 + v90) >> 3; /*0x103a4deac*/
      if ( v93 <= v53 ) /*0x103a4deb4*/
        LODWORD(v94) = v54; /*0x103a4deb4*/
      v95 = fmax(v93, v53); /*0x103a4deb7*/
      v96 = (*(double *)&v80[v90 / 8] + *(double *)((char *)&v306 + v90)) * v92; /*0x103a4deca*/
      v54 = (v87 + v90) >> 3; /*0x103a4ded2*/
      *(double *)(v88 + v90) = v96; /*0x103a4deda*/
      if ( v96 <= v95 ) /*0x103a4dee0*/
        LODWORD(v54) = v94; /*0x103a4dee0*/
      v53 = fmax(v96, v95); /*0x103a4dee3*/
      v90 += 8LL; /*0x103a4dee7*/
      ++v89; /*0x103a4deeb*/
    }
    while ( v82 != v90 ); /*0x103a4def0*/
    ++v81; /*0x103a4def6*/
    v79 = v283 - 8; /*0x103a4df00*/
    v78 = *(_QWORD *)&v286.f64[0] - 8LL; /*0x103a4df0b*/
    v82 += 8; /*0x103a4df0f*/
    --v80; /*0x103a4df13*/
    --v84; /*0x103a4df17*/
    --v83; /*0x103a4df1b*/
  }
  while ( v81 != 11 ); /*0x103a4df22*/
  v277 = a3 + 1016; /*0x103a4df35*/
  v97 = v53 * 0.6; /*0x103a4df3c*/
  v98 = 0; /*0x103a4df50*/
  v99 = 1; /*0x103a4df52*/
  v100 = 408; /*0x103a4df57*/
  v101 = &v306; /*0x103a4df64*/
LABEL_50:
  v102 = *(&v299 + v99); /*0x103a4df6b*/
  v103 = 0; /*0x103a4df77*/
  while ( 1 ) /*0x103a4df7a*/
  {
    v104 = *(double *)(v102 + v103 + 32); /*0x103a4df7a*/
    if ( v104 > v97 /*0x103a4dfb5*/
      && v104 > *(double *)(v102 + v103 - 528)
      && v104 > *(double *)(v102 + v103 - 520)
      && v104 > *(double *)(v102 + v103 + 584)
      && v104 > *(double *)(v102 + v103 + 592) )
    {
      v105 = v98++; /*0x103a4dfbf*/
      v298[v105] = (unsigned __int64)(32LL - *(_QWORD *)__n + v102 + v103) >> 3; /*0x103a4dfc4*/
      if ( v98 == 10 ) /*0x103a4dfcf*/
        break; /*0x103a4dfcf*/
    }
    v103 += 8; /*0x103a4dfd1*/
    if ( v100 == v103 ) /*0x103a4dfd8*/
    {
      if ( v99 <= 0xA ) /*0x103a4dfde*/
      {
        ++v99; /*0x103a4dfe0*/
        v100 += 8; /*0x103a4dfe3*/
        goto LABEL_50; /*0x103a4dfea*/
      }
      v251 = 12; /*0x103a4f15e*/
      v252 = 0; /*0x103a4f163*/
LABEL_120:
      v253 = *(&v299 + v251); /*0x103a4f166*/
      v254 = v252; /*0x103a4f172*/
      while ( 1 ) /*0x103a4f175*/
      {
        v255 = *(double *)(v253 + v254 + 40); /*0x103a4f175*/
        if ( v255 > v97 /*0x103a4f1b0*/
          && v255 > *(double *)(v253 + v254 - 520)
          && v255 > *(double *)(v253 + v254 - 512)
          && v255 > *(double *)(v253 + v254 + 592)
          && v255 > *(double *)(v253 + v254 + 600) )
        {
          v256 = v98++; /*0x103a4f1ba*/
          v298[v256] = (unsigned __int64)(40LL - *(_QWORD *)__n + v253 + v254) >> 3; /*0x103a4f1bf*/
          if ( v98 == 10 ) /*0x103a4f1ca*/
            goto LABEL_61; /*0x103a4f1ca*/
        }
        v254 += 8; /*0x103a4f1d0*/
        if ( v254 == 480 ) /*0x103a4f1db*/
        {
          if ( v251 <= 0x14 ) /*0x103a4f1e1*/
          {
            ++v251; /*0x103a4f1e3*/
            v252 += 8; /*0x103a4f1e6*/
            goto LABEL_120; /*0x103a4f1ed*/
          }
          if ( v98 <= 0 ) /*0x103a4f1f5*/
          {
            v257 = v54; /*0x103a4f1fb*/
            v258 = (int)v54 / 69; /*0x103a4f210*/
            v259 = -69 * v258 + v257; /*0x103a4f215*/
            v192 = 0; /*0x103a4f21d*/
            v192.f64[0] = (double)(v259 + 6); /*0x103a4f220*/
            if ( v259 < 14 ) /*0x103a4f237*/
              v192 = (__m128d)0x4034000000000000uLL; /*0x103a4f239*/
            v191 = (double)(v259 + 6) + 11.0 - (double)v258; /*0x103a4f241*/
            goto LABEL_84; /*0x103a4f245*/
          }
          goto LABEL_62; /*0x103a4f1f5*/
        }
      }
    }
  }
LABEL_61:
  v98 = 10; /*0x103a4dff9*/
LABEL_62:
  v106 = (unsigned int)v98; /*0x103a4dffe*/
  for ( ii = 0; ii != v98; ++ii ) /*0x103a4e001*/
  {
    v108 = v298[ii]; /*0x103a4e013*/
    v109 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 - 584); /*0x103a4e01e*/
    v110 = *(__m128d *)(*(_QWORD *)__n + 8LL * v108 - 576); /*0x103a4e028*/
    v111 = *(__m128d *)(*(_QWORD *)__n + 8LL * v108 - 560); /*0x103a4e032*/
    v112.f64[1] = v111.f64[1]; /*0x103a4e03b*/
    v112.f64[0] = v111.f64[0] * 0.6008648410116; /*0x103a4e03f*/
    v286 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108); /*0x103a4e04d*/
    v113 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 + 8); /*0x103a4e056*/
    v114.f64[0] = *(double *)(*(_QWORD *)__n + 8LL * v108 + 528); /*0x103a4e05c*/
    v265 = v114.f64[0]; /*0x103a4e06f*/
    v114.f64[1] = *(double *)(*(_QWORD *)__n + 8LL * v108 - 32); /*0x103a4e077*/
    v115 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 - 24); /*0x103a4e082*/
    v270 = *(__m128d *)(*(_QWORD *)__n + 8LL * v108 + 536); /*0x103a4e088*/
    v116 = _mm_sub_pd( /*0x103a4e0a3*/
             _mm_mul_pd(_mm_unpacklo_pd(v270, v115), (__m128d)xmmword_10958E700),
             _mm_mul_pd(v114, (__m128d)xmmword_10958E6F0));
    v117 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 - 16); /*0x103a4e0b1*/
    v118 = _mm_sub_pd( /*0x103a4e0c7*/
             v116,
             _mm_mul_pd(
               _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 + 544), v117),
               (__m128d)xmmword_10958E710));
    v273 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 + 560); /*0x103a4e0d6*/
    v119 = _mm_unpacklo_pd(v273, v286); /*0x103a4e0df*/
    v120 = _mm_mul_pd(v119, (__m128d)xmmword_10958E720); /*0x103a4e0f2*/
    v266 = v109.f64[0]; /*0x103a4e0f7*/
    v121 = _mm_sub_pd( /*0x103a4e113*/
             _mm_mul_pd(_mm_unpacklo_pd(v117, v110), (__m128d)xmmword_10958E700),
             _mm_mul_pd(_mm_unpacklo_pd(v115, v109), (__m128d)xmmword_10958E6F0));
    v122 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 - 8); /*0x103a4e117*/
    v271 = v110; /*0x103a4e11e*/
    v115.f64[1] = v110.f64[1]; /*0x103a4e127*/
    v115.f64[0] = v122.f64[0]; /*0x103a4e12c*/
    v284 = v111; /*0x103a4e139*/
    v111.f64[0] = v113.f64[0]; /*0x103a4e141*/
    v123 = _mm_mul_pd(v111, (__m128d)xmmword_10958E720); /*0x103a4e145*/
    v263 = *(long double *)&v112; /*0x103a4e14f*/
    v124 = _mm_add_pd(_mm_shuffle_pd(v120, v112, 1), _mm_sub_pd(v121, _mm_mul_pd(v115, (__m128d)xmmword_10958E710))); /*0x103a4e15d*/
    v125 = *(__m128d *)(*(_QWORD *)__n + 8LL * v108 - 544); /*0x103a4e179*/
    v126 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 + 24); /*0x103a4e194*/
    v112.f64[1] = *(double *)(*(_QWORD *)__n + 8LL * v108 - 536); /*0x103a4e19a*/
    v112.f64[0] = v126.f64[0]; /*0x103a4e19e*/
    v268 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 - 528); /*0x103a4e1bb*/
    v127 = _mm_sub_pd( /*0x103a4e1ce*/
             _mm_add_pd(
               _mm_sub_pd(
                 _mm_add_pd(v124, v123),
                 _mm_mul_pd(
                   _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 + 16), v125),
                   (__m128d)xmmword_10958E710)),
               _mm_mul_pd(v112, (__m128d)xmmword_10958E700)),
             _mm_mul_pd(
               _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 + 32), v268),
               (__m128d)xmmword_10958E6F0));
    v278 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 + 552); /*0x103a4e1dd*/
    v267 = _mm_unpacklo_pd(v278, v122); /*0x103a4e1eb*/
    v128 = _mm_mul_pd(v267, (__m128d)xmmword_10958E720); /*0x103a4e1f4*/
    v272 = *(__m128d *)(*(_QWORD *)__n + 8LL * v108 + 568); /*0x103a4e215*/
    v269 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 + 584); /*0x103a4e23c*/
    v129 = _mm_sub_pd( /*0x103a4e24d*/
             _mm_add_pd(
               _mm_mul_pd(
                 _mm_unpacklo_pd(
                   (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 + 576),
                   (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 + 16)),
                 (__m128d)xmmword_10958E700),
               _mm_sub_pd(
                 _mm_add_pd(_mm_add_pd(v118, v128), v120),
                 _mm_mul_pd(_mm_unpacklo_pd(v272, v113), (__m128d)xmmword_10958E710))),
             _mm_mul_pd(_mm_unpacklo_pd(v269, v126), (__m128d)xmmword_10958E6F0));
    v130 = _mm_unpackhi_pd(v129, v129); /*0x103a4e256*/
    v131 = _mm_unpackhi_pd(v127, v127); /*0x103a4e260*/
    v132 = fmax(v129.f64[0], fmax(v127.f64[0], fmax(v130.f64[0], v131.f64[0]))); /*0x103a4e27c*/
    v133 = v108 % 69 + 6; /*0x103a4e29a*/
    v134 = (double)v133; /*0x103a4e29d*/
    v135 = (double)v133 + 11.0 - (double)(v108 / 69); /*0x103a4e2b8*/
    *(double *)&v293[ii + 250] = (double)v133; /*0x103a4e2bd*/
    *(double *)&v293[ii + 240] = v135; /*0x103a4e2c6*/
    if ( v286.f64[0] <= v132 ) /*0x103a4e2dc*/
    {
      if ( v131.f64[0] == v132 ) /*0x103a4e321*/
      {
        v280 = v134 + -0.5; /*0x103a4e335*/
        *(double *)&v293[ii + 250] = v134 + -0.5; /*0x103a4e33d*/
        v135 = v135 + 0.5; /*0x103a4e346*/
        *(double *)&v293[ii + 240] = v135; /*0x103a4e34b*/
        v138 = *(__m128d *)(*(_QWORD *)__n + 8LL * v108 - 1136); /*0x103a4e355*/
        v139 = _mm_mul_pd(*(__m128d *)(*(_QWORD *)__n + 8LL * v108 - 1120), (__m128d)xmmword_10958E720); /*0x103a4e381*/
        v140 = _mm_add_pd( /*0x103a4e3be*/
                 _mm_sub_pd(
                   _mm_sub_pd(
                     _mm_mul_pd(v138, (__m128d)xmmword_10958E700),
                     _mm_mul_pd(
                       _mm_unpacklo_pd((__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 - 1144), v138),
                       (__m128d)xmmword_10958E6F0)),
                   _mm_mul_pd(
                     _mm_shuffle_pd(v138, *(__m128d *)(*(_QWORD *)__n + 8LL * v108 - 1120), 1),
                     (__m128d)xmmword_10958E710)),
                 v139);
        v141 = *(__m128d *)(*(_QWORD *)__n + 8LL * v108 - 1104); /*0x103a4e3c2*/
        v141.f64[0] = v141.f64[0] * 0.6008648410116; /*0x103a4e3c6*/
        v142 = _mm_sub_pd( /*0x103a4e3df*/
                 _mm_add_pd(_mm_shuffle_pd(v139, v141, 1), v140),
                 _mm_mul_pd(*(__m128d *)(*(_QWORD *)__n + 8LL * v108 - 1104), (__m128d)xmmword_10958E710));
        v143 = *(__m128d *)(*(_QWORD *)__n + 8LL * v108 - 1088); /*0x103a4e3e3*/
        v137 = _mm_unpacklo_pd(v286, v284); /*0x103a4e412*/
        v136 = (__m128d)*(unsigned __int64 *)(*(_QWORD *)__n + 8LL * v108 - 1112); /*0x103a4e417*/
        v113 = _mm_unpackhi_pd(v284, v284); /*0x103a4e420*/
        v119 = v127; /*0x103a4e424*/
        v127 = _mm_sub_pd( /*0x103a4e429*/
                 _mm_add_pd(
                   _mm_mul_pd(
                     _mm_shuffle_pd(*(__m128d *)(*(_QWORD *)__n + 8LL * v108 - 1104), v143, 1),
                     (__m128d)xmmword_10958E700),
                   v142),
                 _mm_mul_pd(v143, (__m128d)xmmword_10958E6F0));
      }
      else if ( v130.f64[0] == v132 ) /*0x103a4e438*/
      {
        v280 = v134 + -0.5; /*0x103a4e450*/
        *(double *)&v293[ii + 250] = v134 + -0.5; /*0x103a4e458*/
        v135 = v135 + -0.5; /*0x103a4e461*/
        *(double *)&v293[ii + 240] = v135; /*0x103a4e466*/
        v144 = _mm_mul_pd(v271, (__m128d)xmmword_10958E740); /*0x103a4e4ad*/
        v145 = _mm_mul_pd(v125, (__m128d)xmmword_10958E760); /*0x103a4e4f7*/
        v146 = _mm_mul_pd(v270, (__m128d)xmmword_10958E740); /*0x103a4e52e*/
        v128.f64[0] = v128.f64[0] /*0x103a4e54f*/
                    + _mm_unpackhi_pd(v146, v146).f64[0]
                    + v265 * 0.02184247643159
                    - *(double *)(*(_QWORD *)__n + 8LL * v108 + 520) * 0.0006755602864
                    - v146.f64[0]
                    - v273.f64[0] * 0.12203175715679;
        v147 = _mm_mul_pd(v272, (__m128d)xmmword_10958E760); /*0x103a4e55c*/
        v128.f64[0] = v128.f64[0] + v147.f64[0] - _mm_unpackhi_pd(v147, v147).f64[0]; /*0x103a4e569*/
        v127.f64[0] = *(double *)&v263 /*0x103a4e56e*/
                    + _mm_unpackhi_pd(v144, v144).f64[0]
                    + v266 * 0.02184247643159
                    - *(double *)(*(_QWORD *)__n + 8LL * v108 - 592) * 0.0006755602864
                    - v144.f64[0]
                    - _mm_unpackhi_pd(v284, v284).f64[0] * 0.12203175715679
                    + v145.f64[0]
                    - _mm_unpackhi_pd(v145, v145).f64[0];
        v113 = v286; /*0x103a4e573*/
        v136 = v284; /*0x103a4e57b*/
        v130 = v128; /*0x103a4e580*/
        v119 = v129; /*0x103a4e585*/
        v137 = v267; /*0x103a4e58a*/
      }
      else
      {
        v280 = v134 + 0.5; /*0x103a4e5a2*/
        *(double *)&v293[ii + 250] = v134 + 0.5; /*0x103a4e5aa*/
        if ( v127.f64[0] == v132 ) /*0x103a4e5b3*/
        {
          v148 = _mm_mul_pd(_mm_shuffle_pd(v271, v284, 1), (__m128d)xmmword_10958E770); /*0x103a4e5e7*/
          v149 = _mm_mul_pd(v125, (__m128d)xmmword_10958E750); /*0x103a4e613*/
          v150 = _mm_unpackhi_pd(v123, v123).f64[0] /*0x103a4e61f*/
               + v148.f64[0]
               - v271.f64[0] * 0.0006755602864
               - _mm_unpackhi_pd(v148, v148).f64[0]
               + v149.f64[0]
               - _mm_unpackhi_pd(v149, v149).f64[0];
          v135 = v135 + 0.5; /*0x103a4e623*/
          *(double *)&v293[ii + 240] = v135; /*0x103a4e628*/
          v148.f64[1] = v268.f64[1]; /*0x103a4e63a*/
          v148.f64[0] = v268.f64[0] * 0.02184247643159 /*0x103a4e65a*/
                      + v150
                      - *(double *)(*(_QWORD *)__n + 8LL * v108 - 520) * 0.0006755602864;
          v151 = _mm_mul_pd(v270, (__m128d)xmmword_10958E730); /*0x103a4e667*/
          v152 = _mm_unpackhi_pd(v151, v151).f64[0] - v151.f64[0] - v278.f64[0] * 0.12203175715679 + v120.f64[0]; /*0x103a4e68f*/
          v153 = _mm_mul_pd(v272, (__m128d)xmmword_10958E750); /*0x103a4e69f*/
          v154.f64[1] = v269.f64[1]; /*0x103a4e6af*/
          v154.f64[0] = v269.f64[0] * 0.02184247643159 /*0x103a4e6cc*/
                      + v152
                      + v153.f64[0]
                      - _mm_unpackhi_pd(v153, v153).f64[0]
                      - *(double *)(*(_QWORD *)__n + 8LL * v108 + 592) * 0.0006755602864;
          v155 = _mm_unpacklo_pd(v154, v127); /*0x103a4e6d0*/
          v127 = _mm_shuffle_pd(v127, v148, 1); /*0x103a4e6d5*/
          v136 = _mm_unpackhi_pd(v284, v284); /*0x103a4e6df*/
          v130 = v129; /*0x103a4e6e3*/
          v137 = v119; /*0x103a4e6e8*/
          v119 = v155; /*0x103a4e6ed*/
        }
        else
        {
          v135 = v135 + -0.5; /*0x103a4e6f7*/
          *(double *)&v293[ii + 240] = v135; /*0x103a4e700*/
          v156 = _mm_mul_pd(*(__m128d *)(*(_QWORD *)__n + 8LL * v108 + 1080), (__m128d)xmmword_10958E730); /*0x103a4e726*/
          v157 = *(__m128d *)(*(_QWORD *)__n + 8LL * v108 + 1112); /*0x103a4e72e*/
          v137 = _mm_unpacklo_pd(v157, v278); /*0x103a4e733*/
          v158 = _mm_mul_pd(*(__m128d *)(*(_QWORD *)__n + 8LL * v108 + 1096), (__m128d)xmmword_10958E740); /*0x103a4e741*/
          v159 = _mm_unpackhi_pd(v156, v156).f64[0] - v156.f64[0] - v158.f64[0]; /*0x103a4e756*/
          v130 = _mm_unpackhi_pd(v158, v158); /*0x103a4e75b*/
          v130.f64[0] = v130.f64[0] + v159; /*0x103a4e760*/
          v160 = _mm_mul_pd(*(__m128d *)(*(_QWORD *)__n + 8LL * v108 + 1096), (__m128d)xmmword_10958E770); /*0x103a4e77a*/
          v161 = _mm_mul_pd(v157, (__m128d)xmmword_10958E750); /*0x103a4e78a*/
          v162 = v160.f64[0] /*0x103a4e7a9*/
               - *(double *)(*(_QWORD *)__n + 8LL * v108 + 1088) * 0.0006755602864
               - _mm_unpackhi_pd(v160, v160).f64[0]
               + v161.f64[0];
          v163 = _mm_mul_pd(*(__m128d *)(*(_QWORD *)__n + 8LL * v108 + 1128), (__m128d)xmmword_10958E760); /*0x103a4e7bb*/
          v130.f64[0] = v130.f64[0] /*0x103a4e7cc*/
                      + v161.f64[0]
                      - _mm_unpackhi_pd(v161, v161).f64[0]
                      + v163.f64[0]
                      - _mm_unpackhi_pd(v163, v163).f64[0];
          v164 = _mm_mul_pd(*(__m128d *)(*(_QWORD *)__n + 8LL * v108 + 1128), (__m128d)xmmword_10958E780); /*0x103a4e7e6*/
          v163.f64[0] = *(double *)(*(_QWORD *)__n + 8LL * v108 + 1120) * 0.6008648410116 + v162 - v164.f64[0]; /*0x103a4e7ef*/
          v165 = _mm_unpackhi_pd(v164, v164); /*0x103a4e7f4*/
          v165.f64[0] = v165.f64[0] + v163.f64[0] - *(double *)(*(_QWORD *)__n + 8LL * v108 + 1144) * 0.0006755602864; /*0x103a4e80b*/
          v119 = _mm_unpacklo_pd(v165, v129); /*0x103a4e810*/
          v113 = v273; /*0x103a4e81b*/
          v127 = _mm_shuffle_pd(v129, v127, 1); /*0x103a4e823*/
          v136 = v286; /*0x103a4e828*/
        }
      }
    }
    else
    {
      v280 = (double)v133; /*0x103a4e2de*/
      v113 = v127; /*0x103a4e2e6*/
      v136 = v131; /*0x103a4e2eb*/
      v137 = v129; /*0x103a4e2ef*/
      v127 = v284; /*0x103a4e2fd*/
      v130 = v278; /*0x103a4e306*/
    }
    v166 = _mm_unpackhi_pd(v137, v137).f64[0]; /*0x103a4e83e*/
    v167 = _mm_mul_pd( /*0x103a4e85e*/
             _mm_sub_pd(
               _mm_sub_pd(_mm_add_pd(_mm_movedup_pd(v113), v137), _mm_shuffle_pd(v137, v136, 1)),
               _mm_unpacklo_pd(v136, v137)),
             (__m128d)xmmword_10903E300);
    v168 = _mm_unpackhi_pd(v119, v119); /*0x103a4e86b*/
    v169 = _mm_sub_pd(_mm_mul_pd(_mm_add_pd(_mm_unpacklo_pd(v119, v130), v127), (__m128d)xmmword_109060A00), v168); /*0x103a4e883*/
    v170 = _mm_unpackhi_pd(v169, v169).f64[0]; /*0x103a4e8b3*/
    v171 = (v168.f64[0] * -4.0 + v137.f64[0] + v166 + v136.f64[0] + v113.f64[0] - v169.f64[0] - v170) * 0.5; /*0x103a4e8c5*/
    v172 = -v169.f64[0] - v171; /*0x103a4e8ca*/
    if ( v172 >= 0.0000001 /*0x103a4e90f*/
      && (v173 = -v170 - v171,
          v174 = _mm_mul_pd(v167, v167),
          v172 * v173 - _mm_unpackhi_pd(v174, v174).f64[0] >= 0.0000001) )
    {
      v175 = (v113.f64[0] + v136.f64[0] - v166 - v137.f64[0]) * 0.5; /*0x103a4e92c*/
      v176 = 0; /*0x103a4e931*/
      v176.f64[0] = sqrt(v172); /*0x103a4e934*/
      v177 = _mm_div_pd(v167, _mm_movedup_pd(v176)); /*0x103a4e941*/
      v178 = _mm_unpackhi_pd(v177, v177).f64[0]; /*0x103a4e949*/
      v179 = sqrt(v173 - v178 * v178); /*0x103a4e959*/
      v180 = (v175 - v177.f64[0] * v178) / v179 / v179; /*0x103a4e974*/
      v181 = (v177.f64[0] - v178 * v180) * 0.5 / v176.f64[0]; /*0x103a4e985*/
      v182 = v180 * 0.5; /*0x103a4e989*/
      v183.f64[0] = v182 * v182 + v181 * v181; /*0x103a4e99e*/
      if ( v183.f64[0] > 1.0 ) /*0x103a4e9ae*/
        v181 = v181 / v183.f64[0]; /*0x103a4e9b0*/
      v184 = _mm_cmplt_sd((__m128d)0x3FF0000000000000uLL, v183).f64[0]; /*0x103a4e9bc*/
      *(_QWORD *)&v185 = ~*(_QWORD *)&v184 & *(_QWORD *)&v182 /*0x103a4e9c9*/
                       | COERCE_UNSIGNED_INT64(v182 / v183.f64[0]) & *(_QWORD *)&v184;
      *(&v294 + ii) = (v175 * v185 + v167.f64[0] * v181) * 0.5 + v168.f64[0]; /*0x103a4e9e2*/
      *(double *)&v293[ii + 250] = v280 + v181; /*0x103a4e9f7*/
      *(double *)&v293[ii + 240] = v135 + v185; /*0x103a4ea05*/
    }
    else
    {
      *(&v294 + ii) = v168.f64[0]; /*0x103a4e911*/
    }
  }
  v186 = 0.0; /*0x103a4ea1b*/
  for ( jj = 0; jj != v106; ++jj ) /*0x103a4ea1f*/
  {
    v286.f64[0] = v186; /*0x103a4ea22*/
    log(__x: v263); /*0x103a4ea3e*/
    pow(__x: v264, __n: v188); /*0x103a4ea4f*/
    v190 = v189 * *(&v294 + jj); /*0x103a4ea54*/
    if ( v190 > v286.f64[0] ) /*0x103a4ea6a*/
      v108 = jj; /*0x103a4ea6a*/
    v186 = fmax(v190, v286.f64[0]); /*0x103a4ea6e*/
  }
  v191 = *(double *)&v293[v108 + 240] + *(double *)&v293[v108 + 240]; /*0x103a4ea93*/
  v192 = (__m128d)0x4034000000000000uLL; /*0x103a4ea97*/
  v192.f64[0] = fmax(20.0, *(double *)&v293[v108 + 250] + *(double *)&v293[v108 + 250]); /*0x103a4ea9f*/
  v101 = &v306; /*0x103a4eaa3*/
LABEL_84:
  v193 = (__m128d)0x4034000000000000uLL; /*0x103a4eaaa*/
  v193.f64[0] = fmax(20.0, v191); /*0x103a4eab2*/
  v194 = _mm_min_pd((__m128d)xmmword_10958E790, _mm_unpacklo_pd(v192, v193)); /*0x103a4eac2*/
  *(double *)v279 = v194.f64[0]; /*0x103a4eacd*/
  *(__m128d *)(v279 + 8) = v194; /*0x103a4ead1*/
  *(double *)(v279 + 24) = v194.f64[1]; /*0x103a4ead6*/
  v195 = 0.0; /*0x103a4eadb*/
  for ( kk = 0; kk != 264; ++kk ) /*0x103a4eadf*/
    v195 = v195 + __dst[kk] * __dst[kk]; /*0x103a4eaee*/
  v286.f64[0] = v195; /*0x103a4eb0c*/
  memset_pattern16(__b: a5, __pattern16: &unk_10958E7B0, __len: 0x20u); /*0x103a4eb14*/
  LOBYTE(v197) = 1; /*0x103a4eb2b*/
  v198 = &unk_10958E800; /*0x103a4eb2d*/
  v285 = 1.0 / v286.f64[0]; /*0x103a4eb3b*/
  do /*0x103a4f08f*/
  {
    LODWORD(v286.f64[0]) = v197; /*0x103a4eb44*/
    v199 = v101; /*0x103a4eb4a*/
    v200 = v198; /*0x103a4eb4d*/
    WebRtcIsac_PitchfilterPre_gains(a1: __dst, a2: v287, a3: v305, a4: v277, a5: v279, a6: a5); /*0x103a4eb72*/
    v201 = v305; /*0x103a4eb80*/
    for ( mm = 0; mm != 4; ++mm ) /*0x103a4eb83*/
    {
      v203 = 0.0; /*0x103a4eb8d*/
      for ( nn = 0; nn != 264; ++nn ) /*0x103a4eb91*/
        v203 = v203 + *(double *)&v287[nn] * *(double *)&v201[8 * nn]; /*0x103a4eba1*/
      *((double *)&v299 + mm) = v203 * v285; /*0x103a4ebb6*/
      v201 += 2112; /*0x103a4ebc2*/
    }
    v205 = 1; /*0x103a4ebce*/
    v206 = v305; /*0x103a4ebd3*/
    for ( i1 = 0; i1 != 4; ++i1 ) /*0x103a4ebd6*/
    {
      v208 = v305; /*0x103a4ec01*/
      v209 = 0; /*0x103a4ec04*/
      do /*0x103a4ec42*/
      {
        v210 = 0.0; /*0x103a4ec07*/
        for ( i2 = 0; i2 != 264; ++i2 ) /*0x103a4ec0b*/
          v210 = v210 + *(double *)&v208[8 * i2] * *(double *)&v206[8 * i2]; /*0x103a4ec1a*/
        *((double *)&v306 + 4 * i1 + v209++) = v210 * v285; /*0x103a4ec2f*/
        v208 += 2112; /*0x103a4ec38*/
      }
      while ( v209 != v205 ); /*0x103a4ec42*/
      ++v205; /*0x103a4ec47*/
      v206 += 2112; /*0x103a4ec4a*/
    }
    v198 = v200; /*0x103a4ec57*/
    v212 = (double *)v200; /*0x103a4ec5a*/
    v213 = 0; /*0x103a4ec5d*/
    v101 = v199; /*0x103a4ec5f*/
    do /*0x103a4ecb3*/
    {
      v214 = v213 + 1; /*0x103a4ec62*/
      v215 = kWeight[5 * v213 + 5] * v276; /*0x103a4ec71*/
      for ( i3 = 0; i3 != 4; ++i3 ) /*0x103a4ec75*/
        v215 = v215 + v212[i3] * a5[i3]; /*0x103a4ec85*/
      *((double *)&v299 + v213) = v215 * 3.0 + *((double *)&v299 + v213); /*0x103a4ec9f*/
      v212 += 5; /*0x103a4eca8*/
      ++v213; /*0x103a4ecac*/
    }
    while ( v214 != 4 ); /*0x103a4ecb3*/
    v217 = 1; /*0x103a4ecb5*/
    v218 = (double *)v198; /*0x103a4ecba*/
    v219 = v199; /*0x103a4ecbd*/
    v220 = 0; /*0x103a4ecc0*/
    do /*0x103a4ecf5*/
    {
      ++v220; /*0x103a4ecc2*/
      v221 = 0; /*0x103a4ecc5*/
      do /*0x103a4ece4*/
      {
        *(double *)&v219[v221] = v218[v221] * 3.0 + *(double *)&v219[v221]; /*0x103a4ecd5*/
        ++v221; /*0x103a4ecde*/
      }
      while ( v217 != v221 ); /*0x103a4ece4*/
      ++v217; /*0x103a4ece6*/
      v219 += 4; /*0x103a4ece9*/
      v218 += 5; /*0x103a4eced*/
    }
    while ( v220 != 4 ); /*0x103a4ecf5*/
    v222 = (double *)v199; /*0x103a4ecf7*/
    for ( i4 = 0; i4 != 3; ++i4 ) /*0x103a4ecfa*/
    {
      v224 = 1.0 / (1.0 - a5[i4]); /*0x103a4ed09*/
      v225 = v224 * v224 * 0.005; /*0x103a4ed15*/
      *((double *)&v299 + i4) = *((double *)&v299 + i4) + v225; /*0x103a4ed26*/
      *v222 = (v224 + v224) * v225 + *v222; /*0x103a4ed3b*/
      v222 += 5; /*0x103a4ed42*/
    }
    v226 = 1.0 / (1.0 - a5[3]); /*0x103a4ed55*/
    v227 = v226 * v226 * 0.005; /*0x103a4ed61*/
    v301 = v227 * 1.33 + v301; /*0x103a4ed81*/
    v228 = v226 * 2.66 * v227 + v318; /*0x103a4ed89*/
    v229 = _mm_div_pd(_mm_unpacklo_pd(v309, (__m128d)v311), _mm_movedup_pd((__m128d)v306)); /*0x103a4edb1*/
    v307 = v229; /*0x103a4edb5*/
    v230 = _mm_unpackhi_pd(v229, v229).f64[0]; /*0x103a4edcd*/
    v231 = v315 / *(double *)&v306; /*0x103a4eddb*/
    v308 = v315 / *(double *)&v306; /*0x103a4eddf*/
    v232 = (__m128d)*(unsigned __int64 *)&v309.f64[1]; /*0x103a4edf3*/
    v309.f64[1] = v309.f64[1] - *(double *)&v306 * v229.f64[0] * v229.f64[0]; /*0x103a4ee01*/
    v232.f64[0] = v309.f64[1]; /*0x103a4edfc*/
    v233.f64[0] = v312; /*0x103a4ee0a*/
    v233.f64[1] = v316; /*0x103a4ee1a*/
    v234 = _mm_div_pd( /*0x103a4ee2b*/
             _mm_sub_pd(
               v233,
               _mm_mul_pd(_mm_unpacklo_pd((__m128d)v311, (__m128d)*(unsigned __int64 *)&v315), _mm_movedup_pd(v229))),
             _mm_movedup_pd(v232));
    v310 = v234; /*0x103a4ee2f*/
    v313 = v313 - (v234.f64[0] * (v309.f64[1] * v234.f64[0]) + *(double *)&v306 * v230 * v230); /*0x103a4ee68*/
    v235 = _mm_unpackhi_pd(v234, v234).f64[0]; /*0x103a4ee82*/
    v236 = (v317 - v230 * v315 - v309.f64[1] * v234.f64[0] * v235) / v313; /*0x103a4ee90*/
    v314 = v236; /*0x103a4ee95*/
    v318 = v228 /*0x103a4eec8*/
         - (v313 * v236 * v236
          + v309.f64[1] * v235 * v235
          + *(double *)&v306 * (v315 / *(double *)&v306) * (v315 / *(double *)&v306));
    v237 = 0; /*0x103a4eed0*/
    v238 = _mm_load_si128((const __m128i *)&xmmword_108F34F50); /*0x103a4eed2*/
    do /*0x103a4eef8*/
    {
      *(__m128i *)(&v294 + v237) = _mm_xor_si128(_mm_load_si128((const __m128i *)(&v299 + v237)), v238); /*0x103a4eee7*/
      v237 += 2; /*0x103a4eef0*/
    }
    while ( v237 != 4 ); /*0x103a4eef8*/
    v295 = v295 - v229.f64[0] * v294; /*0x103a4ef19*/
    v296 = v296 - (v234.f64[0] * v295 + v230 * v294); /*0x103a4ef48*/
    v297 = v297 - (v296 * v236 + v295 * v235 + v294 * v231); /*0x103a4ef74*/
    v239 = (double *)v199; /*0x103a4ef7c*/
    for ( i5 = 0; i5 != 4; i5 += 2 ) /*0x103a4ef7f*/
    {
      v241.f64[0] = *v239; /*0x103a4ef81*/
      v241.f64[1] = v239[5]; /*0x103a4ef85*/
      *(__m128d *)(&v294 + i5) = _mm_div_pd(*(__m128d *)(&v294 + i5), v241); /*0x103a4ef97*/
      v239 += 10; /*0x103a4efa4*/
    }
    v296 = v296 - v236 * v297; /*0x103a4efc6*/
    v295 = v295 - (v234.f64[0] * v296 + v235 * v297); /*0x103a4efee*/
    v294 = v294 - (v295 * v229.f64[0] + v296 * v230 + v231 * v297); /*0x103a4f00e*/
    for ( i6 = 0; i6 != 4; i6 += 2 ) /*0x103a4f016*/
    {
      v243 = _mm_add_pd(*(__m128d *)&a5[i6], *(__m128d *)(&v294 + i6)); /*0x103a4f029*/
      *(__m128d *)&a5[i6] = v243; /*0x103a4f032*/
      v244 = _mm_cmplt_pd((__m128d)xmmword_10958E7A0, v243); /*0x103a4f03b*/
      v245 = _mm_cmpnlt_pd((__m128d)xmmword_10958E7A0, v243); /*0x103a4f044*/
      v246 = _mm_cmplt_pd(v243, (__m128d)0LL); /*0x103a4f049*/
      v247 = _mm_and_pd(v245, v246); /*0x103a4f04e*/
      v248 = (__m128i)_mm_or_pd(v246, v244); /*0x103a4f052*/
      v249 = _mm_andn_pd(v247, (__m128d)xmmword_10958E7A0); /*0x103a4f056*/
      if ( (_mm_cvtsi128_si32(v248) & 1) != 0 ) /*0x103a4f061*/
        a5[i6] = v249.f64[0]; /*0x103a4f063*/
      if ( (_mm_extract_epi8(v248, 8) & 1) != 0 ) /*0x103a4f071*/
        a5[i6 + 1] = v249.f64[1]; /*0x103a4f073*/
    }
    v197 = 0; /*0x103a4f08a*/
  }
  while ( (LOBYTE(v286.f64[0]) & 1) != 0 ); /*0x103a4f08f*/
  WebRtcIsac_PitchfilterPre( /*0x103a4f0ba*/
    a1: __dst,
    a2,
    a3: v277,
    a4: v279,
    a5,
    a6: *(double *)v248.i64,
    a7: v249.f64[0],
    a8: v244.f64[0],
    a9: 0.45,
    a10: 0.0);
  memcpy(__dst: v289, __src: (const void *)(a3 + 824), __n: 0xC0u); /*0x103a4f0dc*/
  memcpy(__dst: &v289[24], __src: a1, __n: 0x780u); /*0x103a4f0f4*/
  WebRtcIsac_PitchfilterPre_la(a1: v289, a2, a3: a3 + 2592, a4: v279, a5); /*0x103a4f113*/
  memcpy(__dst: (void *)(a3 + 824), __src: &v289[240], __n: 0xC0u); /*0x103a4f127*/
  return __stack_chk_guard; /*0x103a4f140*/
}

// Address: 0x103a4f327 | Name: _WebRtcIsac_PitchfilterPre
__int64 __fastcall WebRtcIsac_PitchfilterPre(int a1, int a2, int a3, int a4, int a5)
{
  return FilterFrame(a1, a2: a3, a3: a4, a4: a5, a5: 0, a6: a2, a7: 0); /*0x103a4f34b*/
}

// Address: 0x103a4f75f | Name: _WebRtcIsac_PitchfilterPre_la
__int64 __fastcall WebRtcIsac_PitchfilterPre_la(int a1, int a2, int a3, int a4, int a5)
{
  return FilterFrame(a1, a2: a3, a3: a4, a4: a5, a5: 2, a6: a2, a7: 0); /*0x103a4f786*/
}

// Address: 0x103a4f78c | Name: _WebRtcIsac_PitchfilterPre_gains
__int64 __fastcall WebRtcIsac_PitchfilterPre_gains(int a1, int a2, __int64 a3, int a4, int a5, int a6)
{
  return FilterFrame(a1, a2: a4, a3: a5, a4: a6, a5: 3, a6: a2, a7: a3); /*0x103a4f7b2*/
}

// Address: 0x103a4f7b8 | Name: _WebRtcIsac_PitchfilterPost
__int64 __fastcall WebRtcIsac_PitchfilterPost(int a1, int a2, int a3, int a4, int a5)
{
  return FilterFrame(a1, a2: a3, a3: a4, a4: a5, a5: 1, a6: a2, a7: 0); /*0x103a4f7df*/
}

// Address: 0x103a6cd80 | Name: _WebRtcAecm_Create
_QWORD *WebRtcAecm_Create()
{
  _QWORD *v0; // rbx
  webrtc *v1; // rdi
  __int64 Core; // rax
  _OWORD *Buffer; // rax

  v0 = calloc(__count: 1u, __size: 0x188u); /*0x103a6cd95*/
  Core = webrtc::WebRtcAecm_CreateCore(this: v1); /*0x103a6cd98*/
  v0[48] = Core; /*0x103a6cd9d*/
  if ( Core == 0 || (Buffer = WebRtc_CreateBuffer(a1: 4000, a2: 2), v0[47] = Buffer, Buffer == nullptr) ) /*0x103a6cdc2*/
  {
    WebRtcAecm_Free(a1: v0); /*0x103a6cdc7*/
    return nullptr; /*0x103a6cdcc*/
  }
  return v0; /*0x103a6cdd5*/
}

// Address: 0x103a6cdd8 | Name: _WebRtcAecm_Free
void __fastcall WebRtcAecm_Free(void *a1)
{
  if ( a1 != nullptr ) /*0x103a6cddb*/
  {
    webrtc::WebRtcAecm_FreeCore(a1: *((void **)a1 + 48)); /*0x103a6cded*/
    WebRtc_FreeBuffer(a1: *((void ***)a1 + 47)); /*0x103a6cdf9*/
    free(a1); /*0x103a6ce07*/
  }
}

// Address: 0x103a6ce0d | Name: _WebRtcAecm_Init
__int64 __fastcall WebRtcAecm_Init(__int64 a1, int a2)
{
  unsigned int v3; // r14d
  __int64 v4; // rax

  if ( a1 != 0 ) /*0x103a6ce17*/
  {
    if ( a2 == 16000 || (v3 = 12004, a2 == 8000) ) /*0x103a6ce34*/
    {
      *(_DWORD *)a1 = a2; /*0x103a6ce3a*/
      if ( (unsigned int)webrtc::WebRtcAecm_InitCore(a1: *(_QWORD *)(a1 + 384)) == -1 ) /*0x103a6ce4b*/
      {
        return 12000; /*0x103a6ceff*/
      }
      else
      {
        WebRtc_InitBuffer(a1: *(_QWORD *)(a1 + 376)); /*0x103a6ce58*/
        *(_DWORD *)(a1 + 336) = 42; /*0x103a6ce5d*/
        v3 = 0; /*0x103a6ce67*/
        *(_WORD *)(a1 + 340) = 0; /*0x103a6ce6a*/
        *(_QWORD *)(a1 + 360) = 0x100000001LL; /*0x103a6ce7c*/
        *(_DWORD *)(a1 + 342) = 0; /*0x103a6ce83*/
        *(_WORD *)(a1 + 8) = 0; /*0x103a6ce8d*/
        *(_WORD *)(a1 + 348) = 0; /*0x103a6ce92*/
        *(_QWORD *)(a1 + 352) = &_mh_execute_header; /*0x103a6cea4*/
        *(_WORD *)(a1 + 368) = 0; /*0x103a6ceaf*/
        __bzero(a1: a1 + 12, a2: 324); /*0x103a6cebc*/
        v4 = *(_QWORD *)(a1 + 384); /*0x103a6cec1*/
        *(_WORD *)(v4 + 17230) = 1; /*0x103a6cec8*/
        *(_WORD *)(a1 + 370) = 3; /*0x103a6ced1*/
        *(_QWORD *)(v4 + 17266) = 0x1000C0001000100LL; /*0x103a6cee4*/
        *(_DWORD *)(v4 + 17274) = 83887616; /*0x103a6ceeb*/
      }
    }
  }
  else
  {
    return (unsigned int)-1; /*0x103a6cef7*/
  }
  return v3; /*0x103a6cf08*/
}

// Address: 0x103a6cf0d | Name: _WebRtcAecm_set_config
__int64 __fastcall WebRtcAecm_set_config(__int64 a1, int a2)
{
  __int64 result; // rax
  __int64 v3; // rcx
  int v4; // edx

  if ( a1 == 0 ) /*0x103a6cf10*/
    return 0xFFFFFFFFLL; /*0x103a6cf2f*/
  result = 12002; /*0x103a6cf12*/
  if ( *(_WORD *)(a1 + 336) == 42 ) /*0x103a6cf1f*/
  {
    result = 12004; /*0x103a6cf21*/
    if ( (a2 & 0xFFFE) == 0 ) /*0x103a6cf2c*/
    {
      v3 = *(_QWORD *)(a1 + 384); /*0x103a6cf39*/
      *(_WORD *)(v3 + 17230) = a2; /*0x103a6cf40*/
      v4 = a2 >> 16; /*0x103a6cf49*/
      if ( (unsigned int)(a2 >> 16) <= 4 ) /*0x103a6cf4f*/
      {
        *(_WORD *)(a1 + 370) = HIWORD(a2); /*0x103a6cf56*/
        if ( (unsigned int)a2 > 0xFFFF ) /*0x103a6cf63*/
        {
          switch ( v4 ) /*0x103a6cf87*/
          {
            case 3: /*0x103a6cf87*/
              *(_QWORD *)(v3 + 17266) = 0x1000C0001000100LL; /*0x103a6cfd7*/
              *(_DWORD *)(v3 + 17274) = 83887616; /*0x103a6cfde*/
              break;
            case 2: /*0x103a6cf87*/
              *(_QWORD *)(v3 + 17266) = 0x80060000800080LL; /*0x103a6cfba*/
              *(_DWORD *)(v3 + 17274) = 41943808; /*0x103a6cfc1*/
              break;
            case 1: /*0x103a6cf87*/
              *(_QWORD *)(v3 + 17266) = 0x40030000400040LL; /*0x103a6cf9d*/
              *(_DWORD *)(v3 + 17274) = 20971904; /*0x103a6cfa4*/
              break;
            default:
              *(_QWORD *)(v3 + 17266) = 0x200180002000200LL; /*0x103a6cff4*/
              *(_DWORD *)(v3 + 17274) = 167775232; /*0x103a6cffb*/
              break;
          }
        }
        else
        {
          *(_QWORD *)(v3 + 17266) = 0x20018000200020LL; /*0x103a6cf6f*/
          *(_DWORD *)(v3 + 17274) = 10485952; /*0x103a6cf76*/
        }
        return 0; /*0x103a6cf80*/
      }
    }
  }
  return result; /*0x103a6cf2e*/
}

// Address: 0x103a6d00a | Name: _WebRtcAecm_GetBufferFarendError
__int64 __fastcall WebRtcAecm_GetBufferFarendError(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax

  if ( a1 == 0 ) /*0x103a6d011*/
    return 0xFFFFFFFFLL; /*0x103a6d041*/
  if ( a2 == 0 ) /*0x103a6d016*/
    return 12003; /*0x103a6d048*/
  result = 12002; /*0x103a6d018*/
  if ( *(_WORD *)(a1 + 336) == 42 ) /*0x103a6d025*/
  {
    result = 12004; /*0x103a6d02d*/
    if ( a3 == 80 ) /*0x103a6d032*/
      result = 0; /*0x103a6d032*/
    if ( a3 == 160 ) /*0x103a6d03c*/
      return 0; /*0x103a6d03c*/
  }
  return result; /*0x103a6d04d*/
}

// Address: 0x103a6d04f | Name: _WebRtcAecm_BufferFarend
__int64 __fastcall WebRtcAecm_BufferFarend(__int64 a1, char *a2, unsigned __int64 a3)
{
  __int64 result; // rax
  int v7; // eax
  int v8; // edx
  int v9; // esi

  if ( a1 == 0 ) /*0x103a6d052*/
    return 0xFFFFFFFFLL; /*0x103a6d12e*/
  if ( a2 == nullptr ) /*0x103a6d068*/
    return 12003; /*0x103a6d134*/
  result = 12002; /*0x103a6d071*/
  if ( *(_WORD *)(a1 + 336) == 42 ) /*0x103a6d07e*/
  {
    if ( a3 == 160 || (result = 12004, a3 == 80) ) /*0x103a6d099*/
    {
      if ( *(_DWORD *)(a1 + 356) == 0 ) /*0x103a6d0a7*/
      {
        v7 = WebRtc_available_read(a1: *(__int64 **)(a1 + 376)); /*0x103a6d0b0*/
        v8 = *(__int16 *)(*(_QWORD *)(a1 + 384) + 568LL); /*0x103a6d0c4*/
        if ( 8 * v8 * *(__int16 *)(a1 + 346) - v7 > 256 - 80 * v8 ) /*0x103a6d0e4*/
        {
          v9 = 80; /*0x103a6d0ed*/
          if ( ((8 * v8 * *(__int16 *)(a1 + 346)) >> 1) - v7 >= 81 ) /*0x103a6d0f2*/
            v9 = ((8 * v8 * *(__int16 *)(a1 + 346)) >> 1) - v7; /*0x103a6d0f2*/
          if ( v9 >= 800 ) /*0x103a6d0fc*/
            v9 = 800; /*0x103a6d0fc*/
          WebRtc_MoveReadPtr(a1: *(__int64 **)(a1 + 376), a2: -v9); /*0x103a6d108*/
          *(_DWORD *)(a1 + 364) = 1; /*0x103a6d10d*/
        }
      }
      WebRtc_WriteBuffer(a1: *(__int64 **)(a1 + 376), a2, a3); /*0x103a6d125*/
      return 0; /*0x103a6d12a*/
    }
  }
  return result; /*0x103a6d133*/
}

// Address: 0x103a6d144 | Name: _WebRtcAecm_Process
__int64 __fastcall WebRtcAecm_Process(__int64 a1, char *a2, char *a3, char *a4, __int64 a5, __int16 a6)
{
  char *v6; // r12
  unsigned int v7; // r14d
  __int64 v8; // rbx
  unsigned __int16 v10; // ax
  unsigned __int64 v11; // r15
  __int16 v12; // cx
  int v13; // esi
  __int16 v14; // dx
  __int16 v15; // r8
  __int16 v16; // ax
  __int64 v17; // r14
  __int64 v18; // r15
  __int16 v19; // r12
  __int16 v20; // r12
  int v21; // ecx
  int v22; // eax
  int v23; // edx
  __int16 v24; // cx
  int v25; // edx
  int v26; // eax
  char *v27; // rcx
  int v29; // edi
  int v30; // r8d
  int v31; // r9d
  __int16 v32; // dx
  int v33; // eax
  __int16 v34; // dx
  int v35; // eax
  int v36; // edx
  bool v37; // cc
  __int16 v38; // ax
  __int64 *v39; // r15
  int v40; // eax
  char *v41; // [rsp+0h] [rbp-100h]
  __int64 v42; // [rsp+8h] [rbp-F8h]
  unsigned int v45; // [rsp+24h] [rbp-DCh]
  void *__src; // [rsp+28h] [rbp-D8h] BYREF
  char __dst[160]; // [rsp+30h] [rbp-D0h] BYREF

  if ( a1 == 0 ) /*0x103a6d169*/
    return (unsigned int)-1; /*0x103a6d4ca*/
  v6 = a4; /*0x103a6d16f*/
  v7 = 12003; /*0x103a6d180*/
  if ( a2 != nullptr && a4 != nullptr ) /*0x103a6d17b*/
  {
    v8 = a1; /*0x103a6d18c*/
    v7 = 12002; /*0x103a6d18f*/
    if ( *(_WORD *)(a1 + 336) == 42 ) /*0x103a6d19d*/
    {
      if ( a5 == 160 || (v7 = 12004, a5 == 80) ) /*0x103a6d1b9*/
      {
        v10 = a6; /*0x103a6d1bf*/
        if ( a6 >= 500 ) /*0x103a6d1ca*/
          a6 = 500; /*0x103a6d1ca*/
        v7 = 12100; /*0x103a6d1d8*/
        if ( v10 < 0x1F5u ) /*0x103a6d1de*/
          v7 = 0; /*0x103a6d1de*/
        if ( a6 <= 0 ) /*0x103a6d1e6*/
          a6 = 0; /*0x103a6d1e6*/
        *(_WORD *)(a1 + 346) = a6 + 10; /*0x103a6d1ee*/
        if ( *(_DWORD *)(a1 + 356) != 0 ) /*0x103a6d221*/
        {
          v11 = (unsigned __int8)a5 / 0x50u / (unsigned __int64)*(__int16 *)(*(_QWORD *)(a1 + 384) + 568LL); /*0x103a6d223*/
          if ( a3 != nullptr ) /*0x103a6d229*/
          {
            a2 = a3; /*0x103a6d22f*/
            if ( a4 == a3 ) /*0x103a6d235*/
              goto LABEL_16; /*0x103a6d235*/
          }
          else if ( a4 == a2 ) /*0x103a6d4fc*/
          {
LABEL_16:
            v12 = WebRtc_available_read(a1: *(__int64 **)(v8 + 376)); /*0x103a6d245*/
            if ( *(_DWORD *)(v8 + 360) == 0 ) /*0x103a6d25b*/
              goto LABEL_68; /*0x103a6d25b*/
            v13 = *(_DWORD *)(v8 + 344) + 1; /*0x103a6d267*/
            ++*(_WORD *)(v8 + 344); /*0x103a6d269*/
            v14 = *(_WORD *)(v8 + 338); /*0x103a6d270*/
            if ( v14 != 0 ) /*0x103a6d27a*/
            {
              v15 = *(_WORD *)(v8 + 342); /*0x103a6d280*/
              v16 = *(_WORD *)(v8 + 346); /*0x103a6d288*/
            }
            else
            {
              v16 = *(_WORD *)(v8 + 346); /*0x103a6d507*/
              *(_WORD *)(v8 + 342) = v16; /*0x103a6d50e*/
              *(_WORD *)(v8 + 340) = 0; /*0x103a6d515*/
              v15 = v16; /*0x103a6d51e*/
            }
            v29 = v16; /*0x103a6d521*/
            v30 = v15 - v16; /*0x103a6d528*/
            v31 = -v30; /*0x103a6d52e*/
            if ( v30 > 0 ) /*0x103a6d531*/
              LOWORD(v31) = v30; /*0x103a6d531*/
            if ( fmax((double)v16 * 0.2, 8.0) <= (double)(unsigned __int16)v31 ) /*0x103a6d556*/
            {
              v32 = 0; /*0x103a6d563*/
            }
            else
            {
              *(_WORD *)(v8 + 340) += v16; /*0x103a6d558*/
              v32 = v14 + 1; /*0x103a6d55f*/
            }
            *(_WORD *)(v8 + 338) = v32; /*0x103a6d565*/
            if ( v11 * v32 < 6 ) /*0x103a6d578*/
            {
              if ( (__int16)v13 * v11 < 0x33 ) /*0x103a6d5db*/
                return v7; /*0x103a6d5db*/
            }
            else
            {
              v33 = 3 * *(__int16 *)(v8 + 340) * *(__int16 *)(*(_QWORD *)(v8 + 384) + 568LL) / (40 * v32); /*0x103a6d5a3*/
              v34 = 50; /*0x103a6d5a9*/
              if ( v33 < 50 ) /*0x103a6d5ae*/
                v34 = v33; /*0x103a6d5ae*/
              *(_WORD *)(v8 + 8) = v34; /*0x103a6d5b1*/
              *(_DWORD *)(v8 + 360) = 0; /*0x103a6d5b5*/
              if ( (__int16)v13 * v11 <= 0x32 ) /*0x103a6d5cb*/
              {
LABEL_68:
                if ( v12 / 80 != *(_WORD *)(v8 + 8) ) /*0x103a6d63d*/
                {
                  if ( v12 / 80 <= *(__int16 *)(v8 + 8) ) /*0x103a6d63f*/
                    return v7; /*0x103a6d63f*/
                  v39 = *(__int64 **)(v8 + 376); /*0x103a6d645*/
                  v40 = WebRtc_available_read(a1: v39); /*0x103a6d64f*/
                  WebRtc_MoveReadPtr(a1: v39, a2: v40 - 80 * *(__int16 *)(v8 + 8)); /*0x103a6d665*/
                }
                *(_DWORD *)(v8 + 356) = 0; /*0x103a6d66a*/
                return v7; /*0x103a6d674*/
              }
            }
            v35 = 3 * *(__int16 *)(*(_QWORD *)(v8 + 384) + 568LL) * v29; /*0x103a6d5f5*/
            v36 = v35 / 40; /*0x103a6d609*/
            v37 = v35 < 2000; /*0x103a6d60b*/
            v38 = 50; /*0x103a6d610*/
            if ( v37 ) /*0x103a6d615*/
              v38 = v36; /*0x103a6d615*/
            *(_WORD *)(v8 + 8) = v38; /*0x103a6d618*/
            *(_DWORD *)(v8 + 360) = 0; /*0x103a6d61c*/
            goto LABEL_68; /*0x103a6d61c*/
          }
          memcpy(__dst: a4, __src: a2, __n: 2 * a5); /*0x103a6d240*/
          goto LABEL_16; /*0x103a6d240*/
        }
        v41 = a2; /*0x103a6d294*/
        v45 = v7; /*0x103a6d29b*/
        v17 = 0; /*0x103a6d2a2*/
        v18 = 0; /*0x103a6d2a5*/
        v42 = (unsigned __int8)a5 / 0x50u; /*0x103a6d2af*/
        while ( 1 ) /*0x103a6d2bd*/
        {
          __src = nullptr; /*0x103a6d2bd*/
          if ( (__int16)WebRtc_available_read(a1: *(__int64 **)(v8 + 376)) < 80 ) /*0x103a6d2d8*/
          {
            memcpy(__dst, __src: (const void *)(v8 + v17 + 16), __n: sizeof(__dst)); /*0x103a6d331*/
            __src = __dst; /*0x103a6d336*/
            v8 = a1; /*0x103a6d343*/
          }
          else
          {
            WebRtc_ReadBuffer(a1: *(__int64 **)(v8 + 376), a2: &__src, a3: __dst, a4: 0x50u); /*0x103a6d2f4*/
            memcpy(__dst: (void *)(v8 + v17 + 16), __src, __n: 0xA0u); /*0x103a6d30d*/
          }
          if ( v18 == 1 ) /*0x103a6d34e*/
          {
            if ( *(_DWORD *)v8 != 16000 ) /*0x103a6d36c*/
              goto LABEL_44; /*0x103a6d36c*/
          }
          else if ( v18 != 0 || *(_DWORD *)v8 != 8000 ) /*0x103a6d35f*/
          {
            goto LABEL_44; /*0x103a6d35f*/
          }
          v19 = *(_WORD *)(v8 + 346); /*0x103a6d372*/
          v20 = 8 * *(_WORD *)(*(_QWORD *)(v8 + 384) + 568LL) * v19 - WebRtc_available_read(a1: *(__int64 **)(v8 + 376)); /*0x103a6d39a*/
          if ( v20 <= 79 ) /*0x103a6d3a2*/
          {
            WebRtc_MoveReadPtr(a1: *(__int64 **)(v8 + 376), a2: 0x50u); /*0x103a6d3b0*/
            v20 += 80; /*0x103a6d3b5*/
          }
          v21 = 2 * v20 + 8 * *(__int16 *)(v8 + 348); /*0x103a6d3c9*/
          v22 = v21 / 10; /*0x103a6d3de*/
          if ( v21 < -9 ) /*0x103a6d3e8*/
            LOWORD(v22) = 0; /*0x103a6d3e8*/
          *(_WORD *)(v8 + 348) = v22; /*0x103a6d3eb*/
          v23 = *(_DWORD *)(v8 + 12); /*0x103a6d3f2*/
          v24 = v22 - v23; /*0x103a6d3f7*/
          if ( (__int16)(v22 - v23) < 225 ) /*0x103a6d402*/
          {
            v6 = a4; /*0x103a6d419*/
            if ( v23 > 0 && v24 <= 95 && *(__int16 *)(v8 + 368) < 225 ) /*0x103a6d431*/
            {
LABEL_39:
              v25 = *(_DWORD *)(v8 + 352); /*0x103a6d446*/
              *(_DWORD *)(v8 + 352) = v25 + 1; /*0x103a6d44f*/
              *(_WORD *)(v8 + 368) = v24; /*0x103a6d455*/
              if ( v25 >= 25 ) /*0x103a6d45f*/
              {
                if ( (__int16)v22 >= 161 ) /*0x103a6d467*/
                  v26 = (__int16)v22 - 160; /*0x103a6d46d*/
                else
                  v26 = 0; /*0x103a6d469*/
                *(_DWORD *)(v8 + 12) = v26; /*0x103a6d472*/
              }
              goto LABEL_44; /*0x103a6d472*/
            }
          }
          else
          {
            v6 = a4; /*0x103a6d40c*/
            if ( *(__int16 *)(v8 + 368) >= 96 ) /*0x103a6d413*/
              goto LABEL_39; /*0x103a6d413*/
          }
          *(_DWORD *)(v8 + 352) = 0; /*0x103a6d433*/
          *(_WORD *)(v8 + 368) = v24; /*0x103a6d43d*/
LABEL_44:
          v27 = &a3[v17]; /*0x103a6d475*/
          if ( a3 == nullptr ) /*0x103a6d495*/
            v27 = nullptr; /*0x103a6d495*/
          if ( (unsigned int)webrtc::WebRtcAecm_ProcessFrame( /*0x103a6d4a5*/
                               a1: *(_QWORD *)(v8 + 384),
                               a2: __src,
                               a3: &v41[v17],
                               a4: v27,
                               a5: &v6[v17]) == -1 )
            return (unsigned int)-1; /*0x103a6d4a5*/
          ++v18; /*0x103a6d4a7*/
          v17 += 160; /*0x103a6d4aa*/
          if ( v42 == v18 ) /*0x103a6d4bb*/
            return v45; /*0x103a6d4c8*/
        }
      }
    }
  }
  return v7; /*0x103a6d4e7*/
}

// Address: 0x103a6d67e | Name: _WebRtcAecm_InitEchoPath
__int64 __fastcall WebRtcAecm_InitEchoPath(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax

  if ( a1 == 0 ) /*0x103a6d681*/
    return 0xFFFFFFFFLL; /*0x103a6d6b9*/
  if ( a2 == 0 ) /*0x103a6d686*/
    return 12003; /*0x103a6d6bf*/
  result = 12004; /*0x103a6d688*/
  if ( a3 == 130 ) /*0x103a6d694*/
  {
    result = 12002; /*0x103a6d696*/
    if ( *(_WORD *)(a1 + 336) == 42 ) /*0x103a6d6a3*/
    {
      webrtc::WebRtcAecm_InitEchoPathCore(a1: *(_QWORD *)(a1 + 384)); /*0x103a6d6b0*/
      return 0; /*0x103a6d6b5*/
    }
  }
  return result; /*0x103a6d6b8*/
}

// Address: 0x103a6d6c5 | Name: _WebRtcAecm_echo_path_size_bytes
__int64 WebRtcAecm_echo_path_size_bytes()
{
  return 130; /*0x103a6d6ce*/
}

// Address: 0x103a6d6d0 | Name: _WebRtcAecm_GetEchoPath
__int64 __fastcall WebRtcAecm_GetEchoPath(__int64 a1, void *a2, __int64 a3)
{
  __int64 result; // rax

  if ( a1 == 0 ) /*0x103a6d6d3*/
    return 0xFFFFFFFFLL; /*0x103a6d71d*/
  if ( a2 == nullptr ) /*0x103a6d6d8*/
    return 12003; /*0x103a6d723*/
  result = 12004; /*0x103a6d6da*/
  if ( a3 == 130 ) /*0x103a6d6e6*/
  {
    result = 12002; /*0x103a6d6e8*/
    if ( *(_WORD *)(a1 + 336) == 42 ) /*0x103a6d6f5*/
    {
      memcpy(__dst: a2, __src: *(const void **)(*(_QWORD *)(a1 + 384) + 16000LL), __n: 0x82u); /*0x103a6d714*/
      return 0; /*0x103a6d719*/
    }
  }
  return result; /*0x103a6d71c*/
}

// Address: 0x103aa80dc | Name: _write_mb_features
void __fastcall write_mb_features(__int64 a1, __int64 a2, _BYTE *a3)
{
  unsigned __int64 v5; // rax
  int v6; // edx
  __int64 v7; // rcx
  int v8; // esi
  __int64 v9; // r12
  int v10; // r15d

  if ( a3[3968] != 0 && a3[3969] != 0 ) /*0x103aa80fa*/
  {
    v5 = *(unsigned __int8 *)(a2 + 11); /*0x103aa80ff*/
    v6 = (unsigned __int8)a3[3972]; /*0x103aa8103*/
    if ( v5 > 3 ) /*0x103aa810e*/
    {
      v8 = 0; /*0x103aa8142*/
      v9 = 3973; /*0x103aa8144*/
      v10 = 0; /*0x103aa814a*/
    }
    else
    {
      v7 = (unsigned int)(4 * v5); /*0x103aa8110*/
      v8 = *(_DWORD *)((char *)&xmmword_10978A350 + v7); /*0x103aa811e*/
      v9 = qword_1095971B0[v5]; /*0x103aa8128*/
      v10 = *(_DWORD *)((char *)&xmmword_1099B3CE0 + v7); /*0x103aa8133*/
    }
    vp8_encode_bool(a1, a2: v8, a3: v6); /*0x103aa8150*/
    vp8_encode_bool(a1, a2: v10, a3: (unsigned __int8)a3[v9]); /*0x103aa8168*/
  }
}

// Address: 0x103aa816d | Name: _write_bmode
char __fastcall write_bmode(__int64 a1, int a2, __int64 a3)
{
  int v4; // r12d
  unsigned int v5; // r13d
  char result; // al
  int v7; // r15d
  int v8; // ebx

  v4 = vp8_bmode_encodings[2 * a2]; /*0x103aa818c*/
  v5 = vp8_bmode_encodings[2 * a2 + 1] - 1; /*0x103aa8195*/
  result = 0; /*0x103aa8198*/
  do /*0x103aa81d5*/
  {
    v7 = _bittest(&v4, v5); /*0x103aa81a1*/
    v8 = result; /*0x103aa81a5*/
    vp8_encode_bool(a1, a2: v7, a3: *(unsigned __int8 *)(a3 + (result >> 1))); /*0x103aa81bc*/
    result = vp8_bmode_tree[v8 + v7]; /*0x103aa81ce*/
  }
  while ( v5-- != 0 ); /*0x103aa81d5*/
  return result; /*0x103aa81db*/
}

// Address: 0x103aa81e6 | Name: _write_uv_mode
char __fastcall write_uv_mode(__int64 a1, int a2, __int64 a3)
{
  int v4; // r12d
  unsigned int v5; // r13d
  char result; // al
  int v7; // r15d
  int v8; // ebx

  v4 = vp8_uv_mode_encodings[2 * a2]; /*0x103aa8204*/
  v5 = vp8_uv_mode_encodings[2 * a2 + 1] - 1; /*0x103aa820d*/
  result = 0; /*0x103aa8210*/
  do /*0x103aa824d*/
  {
    v7 = _bittest(&v4, v5); /*0x103aa8219*/
    v8 = result; /*0x103aa821d*/
    vp8_encode_bool(a1, a2: v7, a3: *(unsigned __int8 *)(a3 + (result >> 1))); /*0x103aa8234*/
    result = vp8_uv_mode_tree[v8 + v7]; /*0x103aa8246*/
  }
  while ( v5-- != 0 ); /*0x103aa824d*/
  return result; /*0x103aa8253*/
}

// Address: 0x103aac8a4 | Name: _write_component_probs
__int64 __fastcall write_component_probs(
        __int64 a1,
        __int64 a2,
        const void *a3,
        unsigned __int8 *a4,
        __int64 a5,
        __int64 a6)
{
  int v9; // edx
  int v10; // edi
  unsigned __int64 v11; // rax
  int v12; // ecx
  int v13; // esi
  int v14; // r9d
  int v15; // r10d
  int v16; // r11d
  __int64 v17; // r13
  unsigned __int8 *v18; // r15
  __int64 v19; // r12
  __int64 v20; // rbx
  char *v21; // r14
  unsigned int v23; // edi
  unsigned int v24; // ecx
  _QWORD *v25; // r13
  __int64 v26; // rcx
  __int64 v27; // r12
  int v28; // edx
  unsigned int v29; // esi
  __int64 i; // rcx
  int v31; // edx
  unsigned int v32; // esi
  __int64 j; // rbx
  __int64 v34; // r15
  _QWORD *v35; // r13
  __int64 k; // r14
  _BYTE v38[7]; // [rsp+1h] [rbp-12Fh] BYREF
  unsigned __int8 *v39; // [rsp+8h] [rbp-128h]
  __int64 v40; // [rsp+10h] [rbp-120h]
  __int64 v41; // [rsp+18h] [rbp-118h]
  _BYTE v42[32]; // [rsp+20h] [rbp-110h]
  _QWORD v43[6]; // [rsp+40h] [rbp-F0h] BYREF
  __int64 v44; // [rsp+70h] [rbp-C0h]
  _QWORD v45[4]; // [rsp+80h] [rbp-B0h] BYREF
  _QWORD v46[10]; // [rsp+A0h] [rbp-90h] BYREF
  _DWORD v47[2]; // [rsp+F0h] [rbp-40h] BYREF
  _DWORD v48[2]; // [rsp+F8h] [rbp-38h] BYREF
  __int64 savedregs; // [rsp+130h] [rbp+0h] BYREF

  v40 = a1; /*0x103aac8c1*/
  qmemcpy(v42, a3, 19); /*0x103aac8d9*/
  memset(v46, 0, sizeof(v46)); /*0x103aac8ec*/
  memset(v45, 0, sizeof(v45)); /*0x103aac903*/
  memset(v43, 0, sizeof(v43)); /*0x103aac911*/
  v44 = 0; /*0x103aac926*/
  v9 = *(_DWORD *)(a5 + 4092); /*0x103aac931*/
  LODWORD(v45[0]) = v9; /*0x103aac938*/
  v10 = 0; /*0x103aac93e*/
  v11 = 1; /*0x103aac940*/
  v12 = 0; /*0x103aac945*/
  v13 = 0; /*0x103aac947*/
  do /*0x103aac9c1*/
  {
    v14 = *(_DWORD *)(a5 + 4 * v11 + 4092); /*0x103aac949*/
    v15 = *(_DWORD *)(a5 + (unsigned int)(4 * (1023 - v11))); /*0x103aac95e*/
    v16 = v15 + v14; /*0x103aac962*/
    if ( v11 > 7 ) /*0x103aac96a*/
    {
      v17 = a2; /*0x103aac979*/
      v18 = a4; /*0x103aac97c*/
      v19 = a6; /*0x103aac97f*/
      v20 = 9; /*0x103aac982*/
      do /*0x103aac9a4*/
      {
        v21 = (char *)&savedregs + 4 * _bittest((const int *)&v11, v20) - 144; /*0x103aac999*/
        *(_DWORD *)&v21[8 * v20] += v16; /*0x103aac99c*/
      }
      while ( v20-- != 0 ); /*0x103aac9a4*/
      v10 += v16; /*0x103aac9a6*/
      a6 = v19; /*0x103aac9a9*/
      a4 = v18; /*0x103aac9ac*/
      a2 = v17; /*0x103aac9af*/
    }
    else
    {
      v9 += v16; /*0x103aac96c*/
      *((_DWORD *)v45 + v11) += v16; /*0x103aac96f*/
    }
    v13 += v14; /*0x103aac9b2*/
    v12 += v15; /*0x103aac9b5*/
    ++v11; /*0x103aac9b8*/
  }
  while ( v11 != 1024 ); /*0x103aac9c1*/
  v48[1] = v10; /*0x103aac9c3*/
  v47[0] = v13; /*0x103aac9c6*/
  v47[1] = v12; /*0x103aac9c9*/
  v48[0] = v9; /*0x103aac9cc*/
  v23 = v9 + v10; /*0x103aac9cf*/
  if ( v23 != 0 ) /*0x103aac9d1*/
    v42[0] = (((255 * v9 / v23) & 0xFE) == 0) + ((255 * v9 / v23) & 0xFE); /*0x103aac9e9*/
  v24 = v13 + v12; /*0x103aac9ef*/
  if ( v24 != 0 ) /*0x103aac9f1*/
    v42[1] = (((255 * v13 / v24) & 0xFE) == 0) + ((255 * v13 / v24) & 0xFE); /*0x103aaca09*/
  v25 = v43; /*0x103aaca24*/
  vp8_tree_probs_from_distribution( /*0x103aaca41*/
    a1: 8,
    a2: (__int64)&vp8_small_mvencodings,
    a3: (__int64)&vp8_small_mvtree,
    a4: (__int64)v38,
    a5: (__int64)v43,
    a6: (__int64)v45,
    a7: 256,
    a8: 1);
  v26 = 0; /*0x103aaca4a*/
  v27 = v40; /*0x103aaca4c*/
  do /*0x103aaca89*/
  {
    v28 = v43[v26]; /*0x103aaca53*/
    v29 = v28 + HIDWORD(v43[v26]); /*0x103aaca61*/
    if ( v29 != 0 ) /*0x103aaca63*/
      v42[v26 + 2] = (((255 * v28 / v29) & 0xFE) == 0) + ((255 * v28 / v29) & 0xFE); /*0x103aaca7b*/
    ++v26; /*0x103aaca82*/
  }
  while ( v26 != 7 ); /*0x103aaca89*/
  for ( i = 0; i != 10; ++i ) /*0x103aaca8b*/
  {
    v31 = v46[i]; /*0x103aaca8d*/
    v32 = v31 + HIDWORD(v46[i]); /*0x103aaca9b*/
    if ( v32 != 0 ) /*0x103aaca9d*/
      v42[i + 9] = (((255 * v31 / v32) & 0xFE) == 0) + ((255 * v31 / v32) & 0xFE); /*0x103aacab5*/
  }
  update_1(a1: v27, a2: v48, a3: a2, a4: v42[0], a5: *a4, a6); /*0x103aacadd*/
  update_1(a1: v27, a2: v47, a3: a2 + 1, a4: v42[1], a5: a4[1], a6); /*0x103aacafc*/
  v41 = a6; /*0x103aacb01*/
  for ( j = 2; j != 9; ++j ) /*0x103aacb08*/
    update_1(a1: v27, a2: v25++, a3: a2 + j, a4: (unsigned __int8)v42[j], a5: a4[j], a6: v41); /*0x103aacb2b*/
  v34 = a2 + 9; /*0x103aacb3d*/
  v35 = v46; /*0x103aacb41*/
  v39 = a4; /*0x103aacb48*/
  for ( k = 0; k != 10; ++k ) /*0x103aacb4f*/
    update_1(a1: v27, a2: v35++, a3: v34 + k, a4: (unsigned __int8)v42[k + 9], a5: v39[k + 9], a6: v41); /*0x103aacb7b*/
  return __stack_chk_guard; /*0x103aacb9d*/
}

// Address: 0x103af3107 | Name: _write_sync_code
__int64 __fastcall write_sync_code(__int64 *a1, __int64 a2, __int64 a3, int a4)
{
  int v5; // ecx
  int v6; // ecx

  vpx_wb_write_literal(a1, a2: 73, a3: 8, a4); /*0x103af311a*/
  vpx_wb_write_literal(a1, a2: 131, a3: 8, a4: v5); /*0x103af312c*/
  return vpx_wb_write_literal(a1, a2: 66, a3: 8, a4: v6); /*0x103af3142*/
}

// Address: 0x103af3149 | Name: _write_bitdepth_colorspace_sampling
__int64 __fastcall write_bitdepth_colorspace_sampling(int *a1, __int64 *a2, __int64 a3, int a4)
{
  __int64 v6; // rdx
  int v7; // ecx
  __int64 v8; // rdx
  int v9; // ecx
  __int64 result; // rax
  __int64 v11; // rdx
  int v12; // ecx

  if ( (unsigned int)a1[4479] >= 2 ) /*0x103af315d*/
    vpx_wb_write_bit(a1: a2, a2: a1[4480] != 10, a3, a4); /*0x103af3170*/
  vpx_wb_write_literal(a1: a2, a2: a1[60], a3: 3, a4); /*0x103af3184*/
  if ( a1[60] != 7 ) /*0x103af3191*/
  {
    vpx_wb_write_bit(a1: a2, a2: a1[61], a3: v6, a4: v7); /*0x103af319d*/
    result = a1[4479] | 2u; /*0x103af31a9*/
    if ( (_DWORD)result != 3 ) /*0x103af31af*/
      return result; /*0x103af31af*/
    vpx_wb_write_bit(a1: a2, a2: a1[68], a3: v8, a4: v9); /*0x103af31bb*/
    vpx_wb_write_bit(a1: a2, a2: a1[69], a3: v11, a4: v12); /*0x103af31ca*/
  }
  return vpx_wb_write_bit(a1: a2, a2: 0, a3: v6, a4: v7); /*0x103af31d4*/
}

// Address: 0x103af31e2 | Name: _write_frame_size
__int64 __fastcall write_frame_size(__int64 a1, __int64 *a2, __int64 a3, int a4)
{
  int v6; // ecx

  vpx_wb_write_literal(a1: a2, a2: *(_DWORD *)(a1 + 248) - 1, a3: 16, a4); /*0x103af31ff*/
  vpx_wb_write_literal(a1: a2, a2: *(_DWORD *)(a1 + 252) - 1, a3: 16, a4: v6); /*0x103af3215*/
  return write_render_size(a1, a2); /*0x103af3220*/
}

// Address: 0x103af3229 | Name: _write_render_size
__int64 __fastcall write_render_size(_DWORD *a1, __int64 *a2, __int64 a3, int a4)
{
  int v6; // r15d
  int v7; // r12d
  __int64 result; // rax
  int v9; // ecx
  int v10; // ecx

  if ( a1[62] != a1[64] ) /*0x103af3246*/
  {
    vpx_wb_write_bit(a1: a2, a2: 1, a3, a4); /*0x103af327d*/
    goto LABEL_5; /*0x103af327d*/
  }
  v6 = a1[63]; /*0x103af3248*/
  v7 = a1[65]; /*0x103af324f*/
  result = vpx_wb_write_bit(a1: a2, a2: v6 != v7, a3, a4); /*0x103af3262*/
  if ( v6 != v7 ) /*0x103af326a*/
  {
LABEL_5:
    vpx_wb_write_literal(a1: a2, a2: a1[64] - 1, a3: 16, a4: v9); /*0x103af3282*/
    return vpx_wb_write_literal(a1: a2, a2: a1[65] - 1, a3: 16, a4: v10); /*0x103af32b1*/
  }
  return result; /*0x103af326c*/
}

// Address: 0x103af32b6 | Name: _write_delta_q
__int64 __fastcall write_delta_q(__int64 *a1, int a2, __int64 a3, int a4)
{
  int v6; // ecx
  int v7; // esi
  int v8; // ebx

  if ( a2 != 0 ) /*0x103af32c2*/
  {
    vpx_wb_write_bit(a1, a2: 1, a3, a4); /*0x103af32ce*/
    v7 = -a2; /*0x103af32d5*/
    if ( a2 > 0 ) /*0x103af32d7*/
      v7 = a2; /*0x103af32d7*/
    vpx_wb_write_literal(a1, a2: v7, a3: 4, a4: v6); /*0x103af32e2*/
    v8 = (unsigned int)a2 >> 31; /*0x103af32e7*/
  }
  else
  {
    v8 = 0; /*0x103af32ec*/
  }
  return vpx_wb_write_bit(a1, a2: v8, a3, a4); /*0x103af32f3*/
}

// Address: 0x103af337c | Name: _write_modes
__int64 __fastcall write_modes(
        __int64 a1,
        __int64 a2,
        unsigned int *a3,
        int a4,
        int a5,
        int a6,
        __int64 a7,
        __int64 a8)
{
  int v9; // r13d
  __int64 result; // rax
  __int64 v11; // r10
  __int64 v12; // r11
  __int64 v13; // r14
  __int64 v14; // r8
  __int64 v15; // rax
  signed int v16; // r12d
  __int64 v17; // rbx
  __int64 v18; // r14
  __int64 v19; // [rsp-18h] [rbp-68h]
  unsigned int *v20; // [rsp+8h] [rbp-48h]
  __int64 *v21; // [rsp+10h] [rbp-40h]
  __int64 v22; // [rsp+18h] [rbp-38h]
  int v23; // [rsp+18h] [rbp-38h]
  __int64 v24; // [rsp+20h] [rbp-30h] BYREF

  v9 = a1; /*0x103af3390*/
  v24 = 0; /*0x103af3393*/
  result = (__int64)&vp9_kf_partition_probs; /*0x103af339b*/
  if ( *(_DWORD *)(a1 + 172716) != 0 && *(_BYTE *)(a1 + 172732) == 0 ) /*0x103af33b3*/
    result = *(_QWORD *)(a1 + 176344) + 126LL; /*0x103af33bc*/
  *(_QWORD *)(a2 + 480) = result; /*0x103af33c0*/
  v11 = *a3; /*0x103af33c7*/
  if ( (int)v11 < (int)a3[1] ) /*0x103af33ce*/
  {
    v12 = a8; /*0x103af33d4*/
    v13 = a7; /*0x103af33d8*/
    v21 = (__int64 *)(a1 + ((__int64)a5 << 9) + 8LL * a6 + 196576); /*0x103af33f3*/
    v20 = a3; /*0x103af33fb*/
    do /*0x103af3497*/
    {
      v14 = *v21; /*0x103af340e*/
      v15 = 3LL * ((int)(v11 - *a3 + 7) >> 3); /*0x103af3413*/
      v22 = *(_QWORD *)(*v21 + 24LL * ((int)(v11 - *a3 + 7) >> 3)); /*0x103af341b*/
      v24 = v22; /*0x103af341f*/
      result = *(unsigned int *)(v14 + 8 * v15 + 16); /*0x103af3423*/
      *(_QWORD *)(a2 + 616) = 0; /*0x103af3428*/
      v16 = a3[2]; /*0x103af3433*/
      if ( v16 < (int)a3[3] ) /*0x103af343b*/
      {
        v23 = 16 * result + v22; /*0x103af3441*/
        do /*0x103af348d*/
        {
          v17 = a2; /*0x103af344c*/
          v19 = v13; /*0x103af345b*/
          v18 = v11; /*0x103af3463*/
          result = write_modes_sb( /*0x103af3466*/
                     a1: v9,
                     a2,
                     (_DWORD)a3,
                     a4,
                     a5: (unsigned int)&v24,
                     a6: v23,
                     a7: v11,
                     a8: v16,
                     a9: 12,
                     a10: v19,
                     a11: v12);
          v12 = a8; /*0x103af346f*/
          a3 = v20; /*0x103af3473*/
          v11 = v18; /*0x103af3477*/
          v13 = a7; /*0x103af347a*/
          a2 = v17; /*0x103af347e*/
          v16 += 8; /*0x103af3485*/
        }
        while ( v16 < (int)v20[3] ); /*0x103af348d*/
      }
      v11 = (unsigned int)(v11 + 8); /*0x103af348f*/
    }
    while ( (int)v11 < (int)a3[1] ); /*0x103af3497*/
  }
  return result; /*0x103af349d*/
}

// Address: 0x103af3517 | Name: _write_modes_sb
__int64 __fastcall write_modes_sb(
        __int64 a1,
        __int64 a2,
        int a3,
        unsigned int *a4,
        int a5,
        int a6,
        int a7,
        int a8,
        unsigned __int8 a9,
        __int64 a10,
        __int64 a11)
{
  __int64 v12; // rcx
  __int64 result; // rax
  int v14; // ebx
  int v15; // r12d
  int v16; // ebx
  int v18; // esi
  __int64 v19; // rdx
  __int64 v20; // rbx
  unsigned int v21; // ebx
  int v22; // eax
  unsigned int v23; // edx
  unsigned int v24; // esi
  unsigned int v25; // r10d
  char v26; // di
  int v27; // ecx
  int v28; // r15d
  unsigned int v29; // r14d
  __int64 v30; // r10
  unsigned int v31; // r14d
  int v32; // esi
  unsigned int v33; // r11d
  unsigned int v34; // ecx
  __int64 v35; // rdi
  __int64 v36; // r12
  int v37; // edi
  unsigned int v38; // r12d
  __int64 v39; // rcx
  __int64 v40; // rdx
  unsigned __int8 v41; // dl
  unsigned int v42; // r14d
  unsigned int v43; // edi
  unsigned int v44; // edx
  unsigned int v45; // ecx
  __int64 v46; // rdi
  unsigned int v47; // r8d
  unsigned int v48; // r8d
  int v49; // eax
  unsigned int v50; // ebx
  int v51; // esi
  unsigned int v52; // ecx
  __int64 v53; // r10
  __int64 v54; // r11
  unsigned int v55; // r10d
  __int64 v56; // rcx
  __int64 v57; // rdx
  unsigned __int8 v58; // dl
  unsigned int v59; // edi
  unsigned int v60; // edx
  unsigned int v61; // ecx
  __int64 v62; // rdi
  unsigned int v63; // r8d
  unsigned int v64; // r8d
  int v65; // eax
  unsigned int v66; // r9d
  int v67; // esi
  unsigned int v68; // ecx
  __int64 v69; // r10
  __int64 v70; // r11
  unsigned int v71; // r10d
  __int64 v72; // rcx
  __int64 v73; // rdx
  unsigned __int8 v74; // dl
  unsigned int v75; // edi
  unsigned int v76; // r8d
  __int64 v77; // r15
  unsigned __int64 v78; // r10
  int v79; // edi
  __int64 v80; // rbx
  int v81; // esi
  int v82; // edx
  int v83; // ecx
  int v84; // r8d
  int v85; // r9d
  void *v86; // r14
  void *v87; // rdi
  size_t v88; // rbx
  int v89; // [rsp-18h] [rbp-C8h]
  __int64 v90; // [rsp-10h] [rbp-C0h]
  __int64 v91; // [rsp-8h] [rbp-B8h]
  __int64 v92; // [rsp+18h] [rbp-98h]
  __int64 v93; // [rsp+20h] [rbp-90h]
  __int64 v94; // [rsp+28h] [rbp-88h]
  __int64 v95; // [rsp+30h] [rbp-80h]
  __int64 v97; // [rsp+58h] [rbp-58h]
  unsigned __int64 v98; // [rsp+58h] [rbp-58h]

  v12 = (unsigned __int8)b_width_log2_lookup[a9]; /*0x103af353d*/
  result = (unsigned int)(1 << v12); /*0x103af3547*/
  v14 = result + 3; /*0x103af354d*/
  if ( (int)result >= 0 ) /*0x103af3552*/
    v14 = 1 << v12; /*0x103af3552*/
  v15 = *(_DWORD *)(a1 + 172752); /*0x103af3555*/
  if ( v15 > a7 ) /*0x103af355f*/
  {
    result = *(unsigned int *)(a1 + 172760); /*0x103af3569*/
    if ( (int)result > a8 ) /*0x103af3572*/
    {
      v16 = v14 >> 2; /*0x103af3584*/
      v95 = partition_lookup[13 * v12 /*0x103af35ba*/
                           + **(unsigned __int8 **)(*(_QWORD *)(a1 + 172920) + 8LL
                                                                             * (a8 + a7 * *(_DWORD *)(a1 + 172764)))];
      v18 = *(char *)(*(_QWORD *)(a2 + 608) + a8); /*0x103af35e8*/
      v97 = *(_QWORD *)(a2 + 480) /*0x103af361c*/
          + 3LL
          * (_bittest(&v18, (unsigned __int8)mi_width_log2_lookup[a9])
           + 2 * (((unsigned int)*(char *)(a2 + (a7 & 7) + 616) >> mi_width_log2_lookup[a9]) & 1)
           + 4 * (unsigned __int8)mi_width_log2_lookup[a9]);
      v19 = (unsigned int)(v16 + a7); /*0x103af3624*/
      v20 = (unsigned int)(a8 + v16); /*0x103af3630*/
      v92 = a2; /*0x103af3644*/
      v94 = v20; /*0x103af365d*/
      v93 = v19; /*0x103af3668*/
      if ( (int)v19 < v15 && (int)v20 < (int)result ) /*0x103af3635*/
      {
        v21 = partition_encodings[2 * v95]; /*0x103af3680*/
        v22 = partition_encodings[2 * v95 + 1]; /*0x103af3683*/
        v23 = a4[2]; /*0x103af3687*/
        v24 = *a4; /*0x103af368b*/
        v25 = a4[1]; /*0x103af368f*/
        v26 = 0; /*0x103af3693*/
        do /*0x103af379d*/
        {
          v27 = -_bittest((const int *)&v21, --v22); /*0x103af36a7*/
          v28 = v26; /*0x103af36a9*/
          v29 = ((*(unsigned __int8 *)(v97 + (v26 >> 1)) * (v25 - 1)) >> 8) + 1; /*0x103af36ca*/
          v30 = v25 - v29; /*0x103af36cd*/
          if ( ((v21 >> v22) & 1) == 0 ) /*0x103af36d4*/
            v30 = v29; /*0x103af36d4*/
          v31 = v24 + (v27 & v29); /*0x103af36db*/
          v32 = vpx_norm[v30]; /*0x103af36e5*/
          v33 = v32 + v23; /*0x103af36ed*/
          if ( (int)(v32 + v23) < 0 ) /*0x103af36f0*/
          {
            v41 = vpx_norm[v30]; /*0x103af376c*/
          }
          else
          {
            if ( ((v31 << ~(_BYTE)v23) & 0x80000000) != 0 ) /*0x103af36fd*/
            {
              v34 = a4[3]; /*0x103af36ff*/
              LODWORD(v35) = v34 - 1; /*0x103af3705*/
              if ( (int)(v34 - 1) >= 0 ) /*0x103af3707*/
              {
                while ( 1 ) /*0x103af3709*/
                {
                  v35 = v34 - 1; /*0x103af3709*/
                  v36 = *((_QWORD *)a4 + 2); /*0x103af370c*/
                  if ( *(_BYTE *)(v36 + v35) != 0xFF ) /*0x103af3715*/
                    break; /*0x103af3715*/
                  *(_BYTE *)(v36 + v35) = 0; /*0x103af3717*/
                  if ( (int)--v34 <= 0 ) /*0x103af3720*/
                  {
                    LODWORD(v35) = -1; /*0x103af3722*/
                    break; /*0x103af3722*/
                  }
                }
              }
              ++*(_BYTE *)(*((_QWORD *)a4 + 2) + (int)v35); /*0x103af3727*/
            }
            v37 = -v23; /*0x103af3733*/
            v38 = v31 >> (v23 + 24); /*0x103af373d*/
            v39 = *((_QWORD *)a4 + 2); /*0x103af3740*/
            v40 = a4[3]; /*0x103af3744*/
            a4[3] = v40 + 1; /*0x103af374c*/
            *(_BYTE *)(v39 + v40) = v38; /*0x103af3750*/
            v31 = (v31 << v37) & 0xFFFFFF; /*0x103af3759*/
            v41 = v33; /*0x103af3760*/
            v33 -= 8; /*0x103af3767*/
          }
          v25 = (_DWORD)v30 << v32; /*0x103af3770*/
          v42 = v31 << v41; /*0x103af3775*/
          a4[2] = v33; /*0x103af3778*/
          *a4 = v42; /*0x103af377c*/
          a4[1] = v25; /*0x103af3780*/
          v26 = vp9_partition_tree[v28 + ((v21 >> v22) & 1)]; /*0x103af3791*/
          v24 = v42; /*0x103af3795*/
          v23 = v33; /*0x103af3798*/
        }
        while ( v22 != 0 ); /*0x103af379d*/
      }
      else
      {
        if ( (int)v19 >= v15 && (int)v20 < (int)result ) /*0x103af37aa*/
        {
          v43 = a4[1]; /*0x103af37c9*/
          v44 = a4[2]; /*0x103af37cd*/
          v45 = ((*(unsigned __int8 *)(v97 + 1) * (v43 - 1)) >> 8) + 1; /*0x103af37da*/
          v46 = v43 - v45; /*0x103af37dc*/
          if ( (_DWORD)v95 != 3 ) /*0x103af37e5*/
            v46 = v45; /*0x103af37e5*/
          v47 = 0; /*0x103af37e8*/
          if ( v95 == 3 ) /*0x103af37ef*/
            v47 = v45; /*0x103af37ef*/
          v48 = *a4 + v47; /*0x103af37f3*/
          v49 = vpx_norm[v46]; /*0x103af37fe*/
          v50 = v49 + v44; /*0x103af3804*/
          if ( (int)(v49 + v44) < 0 ) /*0x103af3806*/
          {
            v58 = vpx_norm[v46]; /*0x103af3968*/
          }
          else
          {
            v51 = -v44; /*0x103af380e*/
            if ( ((v48 << ~(_BYTE)v44) & 0x80000000) != 0 ) /*0x103af381d*/
            {
              v52 = a4[3]; /*0x103af381f*/
              LODWORD(v53) = v52 - 1; /*0x103af3826*/
              if ( (int)(v52 - 1) >= 0 ) /*0x103af3829*/
              {
                while ( 1 ) /*0x103af382b*/
                {
                  v53 = v52 - 1; /*0x103af382b*/
                  v54 = *((_QWORD *)a4 + 2); /*0x103af382f*/
                  if ( *(_BYTE *)(v54 + v53) != 0xFF ) /*0x103af3838*/
                    break; /*0x103af3838*/
                  *(_BYTE *)(v54 + v53) = 0; /*0x103af383a*/
                  if ( (int)--v52 <= 0 ) /*0x103af3843*/
                  {
                    LODWORD(v53) = -1; /*0x103af3845*/
                    break; /*0x103af3845*/
                  }
                }
              }
              ++*(_BYTE *)(*((_QWORD *)a4 + 2) + (int)v53); /*0x103af384b*/
            }
            v55 = v48 >> (v44 + 24); /*0x103af385e*/
            v56 = *((_QWORD *)a4 + 2); /*0x103af3861*/
            v57 = a4[3]; /*0x103af3865*/
            a4[3] = v57 + 1; /*0x103af386d*/
            *(_BYTE *)(v56 + v57) = v55; /*0x103af3871*/
            v48 = (v48 << v51) & 0xFFFFFF; /*0x103af387a*/
            v58 = v50; /*0x103af3881*/
            v50 -= 8; /*0x103af3886*/
          }
          v75 = (_DWORD)v46 << v49; /*0x103af396c*/
          v76 = v48 << v58; /*0x103af3970*/
          a4[2] = v50; /*0x103af3973*/
        }
        else
        {
          if ( (int)v20 < (int)result || (int)v19 >= v15 ) /*0x103af37b1*/
            goto LABEL_51; /*0x103af3894*/
          v59 = a4[1]; /*0x103af38a2*/
          v60 = a4[2]; /*0x103af38a6*/
          v61 = ((*(unsigned __int8 *)(v97 + 2) * (v59 - 1)) >> 8) + 1; /*0x103af38b3*/
          v62 = v59 - v61; /*0x103af38b5*/
          if ( (_DWORD)v95 != 3 ) /*0x103af38be*/
            v62 = v61; /*0x103af38be*/
          v63 = 0; /*0x103af38c1*/
          if ( v95 == 3 ) /*0x103af38c8*/
            v63 = v61; /*0x103af38c8*/
          v64 = *a4 + v63; /*0x103af38cc*/
          v65 = vpx_norm[v62]; /*0x103af38d7*/
          v66 = v65 + v60; /*0x103af38de*/
          if ( (int)(v65 + v60) < 0 ) /*0x103af38e1*/
          {
            v74 = vpx_norm[v62]; /*0x103af3979*/
          }
          else
          {
            v67 = -v60; /*0x103af38e9*/
            if ( ((v64 << ~(_BYTE)v60) & 0x80000000) != 0 ) /*0x103af38f8*/
            {
              v68 = a4[3]; /*0x103af38fa*/
              LODWORD(v69) = v68 - 1; /*0x103af3901*/
              if ( (int)(v68 - 1) >= 0 ) /*0x103af3904*/
              {
                while ( 1 ) /*0x103af3906*/
                {
                  v69 = v68 - 1; /*0x103af3906*/
                  v70 = *((_QWORD *)a4 + 2); /*0x103af390a*/
                  if ( *(_BYTE *)(v70 + v69) != 0xFF ) /*0x103af3913*/
                    break; /*0x103af3913*/
                  *(_BYTE *)(v70 + v69) = 0; /*0x103af3915*/
                  if ( (int)--v68 <= 0 ) /*0x103af391e*/
                  {
                    LODWORD(v69) = -1; /*0x103af3920*/
                    break; /*0x103af3920*/
                  }
                }
              }
              ++*(_BYTE *)(*((_QWORD *)a4 + 2) + (int)v69); /*0x103af3926*/
            }
            v71 = v64 >> (v60 + 24); /*0x103af3939*/
            v72 = *((_QWORD *)a4 + 2); /*0x103af393c*/
            v73 = a4[3]; /*0x103af3940*/
            a4[3] = v73 + 1; /*0x103af3948*/
            *(_BYTE *)(v72 + v73) = v71; /*0x103af394c*/
            v64 = (v64 << v67) & 0xFFFFFF; /*0x103af3955*/
            v74 = v66; /*0x103af395c*/
            v66 -= 8; /*0x103af3963*/
          }
          v75 = (_DWORD)v62 << v65; /*0x103af397d*/
          v76 = v64 << v74; /*0x103af3981*/
          a4[2] = v66; /*0x103af3984*/
        }
        *a4 = v76; /*0x103af3988*/
        a4[1] = v75; /*0x103af398c*/
      }
LABEL_51:
      v77 = a9; /*0x103af3990*/
      v78 = subsize_lookup[13 * v95 + a9]; /*0x103af39aa*/
      v98 = v78; /*0x103af39b3*/
      if ( v78 > 2 ) /*0x103af39b7*/
      {
        v80 = v92; /*0x103af3a0f*/
        if ( v95 == 2 ) /*0x103af3a1a*/
        {
          write_modes_b(a1, a2: v92, a3, (_DWORD)a4, a5, a6, a7, a8, a9: a10, a10: a11); /*0x103af3b3a*/
          result = v94; /*0x103af3b43*/
          if ( (int)v94 < *(_DWORD *)(a1 + 172760) ) /*0x103af3b52*/
          {
            v79 = a1; /*0x103af3b58*/
            v81 = v92; /*0x103af3b5b*/
            v82 = a3; /*0x103af3b5e*/
            v83 = (int)a4; /*0x103af3b62*/
            v84 = a5; /*0x103af3b65*/
            v85 = a6; /*0x103af3b69*/
            v91 = a11; /*0x103af3b6d*/
            v90 = a10; /*0x103af3b70*/
            v89 = v94; /*0x103af3b73*/
LABEL_54:
            result = write_modes_b(a1: v79, a2: v81, a3: v82, a4: v83, a5: v84, a6: v85, a7, a8: v89, a9: v90, a10: v91); /*0x103af39df*/
          }
LABEL_55:
          if ( a9 >= 3u && (a9 == 3 || (_DWORD)v95 != 3) ) /*0x103af39f7*/
          {
            v86 = (void *)(v80 + (a7 & 7) + 616); /*0x103af3a57*/
            v87 = (void *)(*(_QWORD *)(v80 + 608) + a8); /*0x103af3a65*/
            v88 = num_8x8_blocks_wide_lookup[v77]; /*0x103af3a73*/
            memset(__b: v87, __c: partition_context_lookup[2 * v98], __len: v88); /*0x103af3a8b*/
            return (__int64)memset(__b: v86, __c: partition_context_lookup[2 * v98 + 1], __len: v88); /*0x103af3aad*/
          }
          return result; /*0x103af3aad*/
        }
        if ( (_DWORD)v95 == 1 ) /*0x103af3a24*/
        {
          write_modes_b(a1, a2: v92, a3, (_DWORD)a4, a5, a6, a7, a8, a9: a10, a10: a11); /*0x103af3ad5*/
          result = v93; /*0x103af3ade*/
          if ( (int)v93 < *(_DWORD *)(a1 + 172752) ) /*0x103af3aed*/
            result = write_modes_b(a1, a2: v92, a3, (_DWORD)a4, a5, a6, a7: v93, a8, a9: a10, a10: a11); /*0x103af3b12*/
          goto LABEL_55; /*0x103af3b12*/
        }
        if ( (_DWORD)v95 != 0 ) /*0x103af3a2d*/
        {
          write_modes_sb(a1, a2: v92, a3, (_DWORD)a4, a5, a6, a7, a8, a9: v78, a10, a11); /*0x103af3ba5*/
          write_modes_sb(a1, a2: v92, a3, (_DWORD)a4, a5, a6, a7, a8: v94, a9: v98, a10, a11); /*0x103af3bd7*/
          write_modes_sb(a1, a2: v92, a3, (_DWORD)a4, a5, a6, a7: v93, a8, a9: v98, a10, a11); /*0x103af3c09*/
          v77 = a9; /*0x103af3c27*/
          result = write_modes_sb(a1, a2: v92, a3, (_DWORD)a4, a5, a6, a7: v93, a8: v94, a9: v98, a10, a11); /*0x103af3c3f*/
          goto LABEL_55; /*0x103af3c48*/
        }
        v79 = a1; /*0x103af3a33*/
        v81 = v92; /*0x103af3a37*/
        v82 = a3; /*0x103af3a3a*/
        v83 = (int)a4; /*0x103af3a3e*/
        v84 = a5; /*0x103af3a41*/
        v85 = a6; /*0x103af3a45*/
        v91 = a11; /*0x103af3a49*/
      }
      else
      {
        v79 = a1; /*0x103af39b9*/
        v80 = v92; /*0x103af39bd*/
        v81 = v92; /*0x103af39c4*/
        v82 = a3; /*0x103af39c7*/
        v83 = (int)a4; /*0x103af39cb*/
        v84 = a5; /*0x103af39ce*/
        v85 = a6; /*0x103af39d2*/
        v91 = a11; /*0x103af39d6*/
      }
      v90 = a10; /*0x103af39d9*/
      v89 = a8; /*0x103af39dc*/
      goto LABEL_54; /*0x103af39dc*/
    }
  }
  return result; /*0x103af39f9*/
}

// Address: 0x103af3c4d | Name: _write_modes_b
unsigned __int8 ***__fastcall write_modes_b(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        unsigned __int8 ***a5,
        unsigned __int8 **a6,
        int a7,
        int a8,
        _DWORD *a9,
        __int64 a10)
{
  __int64 v11; // r14
  int v12; // r12d
  __int64 *v13; // rax
  __int64 v14; // rcx
  int v15; // esi
  int v16; // r10d
  unsigned __int8 *v17; // rsi
  _BYTE *v19; // r13
  __int64 v20; // r15
  __int64 v21; // r14
  __int64 v22; // rbx
  unsigned int v23; // ebx
  unsigned __int8 v24; // r14
  unsigned __int8 v25; // al
  int v26; // eax
  unsigned __int8 *v27; // r15
  __int64 v28; // rdx
  __int64 v29; // rsi
  unsigned __int64 v30; // r12
  int v31; // r14d
  unsigned __int8 v32; // r13
  unsigned __int8 v33; // al
  __int64 v34; // rcx
  unsigned __int8 v35; // dl
  char *v36; // rax
  unsigned int *v37; // rbx
  unsigned __int8 **v38; // r15
  unsigned __int8 **i; // r14
  int v40; // eax
  unsigned int v41; // r13d
  unsigned int v42; // r8d
  __int64 v43; // r13
  unsigned int v44; // r8d
  unsigned int v45; // esi
  int v46; // edx
  unsigned int v47; // eax
  unsigned int v48; // ecx
  __int64 v49; // rdi
  __int64 v50; // r10
  int v51; // edi
  unsigned int v52; // r10d
  __int64 v53; // rcx
  __int64 v54; // rsi
  unsigned __int8 v55; // si
  unsigned int v56; // edx
  unsigned int v57; // edi
  __int64 v58; // r13
  int v59; // eax
  unsigned int v60; // r8d
  unsigned int v61; // ecx
  __int64 v62; // rsi
  __int64 v63; // r10
  int v64; // esi
  unsigned int v65; // r10d
  __int64 v66; // rcx
  __int64 v67; // rdx
  unsigned __int8 v68; // dl
  unsigned int v69; // r13d
  unsigned __int8 v70; // cl
  unsigned int v71; // r13d
  unsigned int v72; // r8d
  __int64 v73; // r12
  unsigned __int8 *v74; // r11
  __int64 v75; // rdi
  int v76; // edx
  int v77; // r10d
  unsigned int v78; // ecx
  __int64 v79; // rsi
  __int64 v80; // r11
  int v81; // esi
  unsigned int v82; // r11d
  __int64 v83; // rax
  __int64 v84; // rbx
  unsigned __int8 v85; // si
  unsigned int v86; // edi
  unsigned __int8 **v87; // rcx
  __int16 v88; // dx
  __int64 v89; // r13
  unsigned int v90; // r8d
  int v91; // edx
  unsigned int v92; // esi
  unsigned int v93; // ecx
  __int64 v94; // rdi
  __int64 v95; // r10
  int v96; // edi
  unsigned int v97; // r10d
  __int64 v98; // rax
  __int64 v99; // rcx
  unsigned __int8 v100; // al
  unsigned int v101; // r13d
  unsigned int v102; // r8d
  __int64 v103; // r13
  int v104; // edx
  unsigned int v105; // eax
  unsigned int v106; // ecx
  __int64 v107; // rdi
  __int64 v108; // r10
  int v109; // edi
  unsigned int v110; // r10d
  __int64 v111; // rcx
  __int64 v112; // rsi
  unsigned __int8 v113; // si
  int v114; // edx
  unsigned int v115; // ecx
  __int64 v116; // r13
  unsigned int v117; // r10d
  int v118; // edi
  unsigned int v119; // eax
  unsigned int v120; // ecx
  __int64 v121; // r8
  __int64 v122; // r14
  int v123; // r8d
  unsigned int v124; // r14d
  __int64 v125; // rcx
  __int64 v126; // rsi
  unsigned __int8 v127; // si
  int v128; // r13d
  unsigned int v129; // r8d
  unsigned int v130; // edi
  __int64 v131; // r13
  int v132; // edx
  unsigned int v133; // ecx
  __int64 v134; // rsi
  __int64 v135; // r10
  int v136; // esi
  unsigned int v137; // r10d
  __int64 v138; // rax
  __int64 v139; // rcx
  unsigned __int8 v140; // al
  unsigned int v141; // r13d
  unsigned int v142; // r10d
  unsigned int v143; // edx
  char v144; // si
  unsigned int v145; // edi
  int v146; // ecx
  int v147; // r15d
  unsigned int v148; // r14d
  __int64 v149; // r13
  unsigned int v150; // r14d
  int v151; // esi
  int v152; // r10d
  unsigned int v153; // ecx
  __int64 v154; // rdi
  __int64 v155; // r8
  int v156; // edi
  unsigned int v157; // r8d
  __int64 v158; // rax
  __int64 v159; // rbx
  unsigned __int8 v160; // di
  unsigned __int8 *v161; // r11
  int v162; // ebx
  unsigned int v163; // r12d
  unsigned int v164; // r8d
  __int64 v165; // r13
  unsigned int v166; // r8d
  int v167; // esi
  unsigned int v168; // edx
  int v169; // ecx
  __int64 v170; // rdi
  __int64 v171; // r10
  int v172; // edi
  unsigned int v173; // r10d
  unsigned int *v174; // r15
  __int64 v175; // rax
  __int64 v176; // rcx
  unsigned __int8 v177; // al
  unsigned int v178; // r8d
  unsigned int v179; // edi
  int v180; // ecx
  __int64 v181; // rsi
  __int64 v182; // r10
  int v183; // esi
  unsigned int v184; // r10d
  __int64 v185; // rcx
  __int64 v186; // rdx
  unsigned __int8 **v187; // rcx
  _BYTE *v188; // r15
  _BYTE *v189; // r13
  __int64 v190; // rdx
  __int64 v191; // rcx
  _BOOL4 v192; // eax
  __int64 v194; // rdi
  char v195; // r15
  __int64 v196; // rsi
  int v197; // ecx
  int v198; // r8d
  int v199; // esi
  unsigned int v200; // r9d
  __int64 v201; // r8
  unsigned int v202; // r9d
  int v203; // eax
  int v204; // r10d
  int v205; // ecx
  __int64 v206; // r11
  __int64 v207; // rbx
  unsigned __int8 v208; // si
  __int64 v209; // rcx
  __int64 v210; // rdx
  bool v211; // zf
  int v212; // eax
  __int64 v213; // rdx
  __int64 v214; // rsi
  char v215; // si
  char v216; // dl
  bool v217; // r8
  bool v218; // cc
  __int64 v219; // rsi
  int v220; // ecx
  int v221; // r8d
  int v222; // esi
  unsigned int v223; // edx
  __int64 v224; // r8
  unsigned int v225; // r9d
  unsigned int v226; // r9d
  int v227; // edx
  int v228; // r10d
  int v229; // edi
  int v230; // ecx
  __int64 v231; // r11
  __int64 v232; // rbx
  unsigned __int8 v233; // si
  unsigned int v234; // r11d
  __int64 v235; // rcx
  __int64 v236; // rsi
  __int64 v237; // rsi
  bool v238; // al
  __int64 v239; // rdx
  __int64 v240; // rcx
  __int64 *v241; // rax
  __int64 v242; // r15
  char v243; // bl
  int reference_mode_context; // eax
  int v245; // edi
  int v246; // edx
  unsigned int v247; // ecx
  __int64 v248; // rdi
  unsigned int v249; // r8d
  unsigned int v250; // r8d
  int v251; // eax
  int v252; // r9d
  int v253; // esi
  int v254; // ecx
  __int64 v255; // r10
  __int64 v256; // r11
  unsigned int v257; // r10d
  _DWORD *v258; // r14
  __int64 v259; // rcx
  __int64 v260; // rdx
  unsigned __int8 v261; // dl
  __int64 v262; // rcx
  unsigned __int8 *v263; // r15
  __int64 v264; // r14
  __int64 v265; // rdx
  unsigned __int64 v266; // r12
  __int64 v267; // r13
  char v268; // bl
  char v269; // r14
  int pred_context_comp_ref_p; // eax
  int v271; // edi
  int v272; // edx
  unsigned int v273; // ecx
  unsigned int v274; // r8d
  __int64 v275; // rdi
  _DWORD *v276; // rbx
  unsigned int v277; // r8d
  int v278; // eax
  int v279; // r9d
  int v280; // esi
  int v281; // ecx
  __int64 v282; // r10
  __int64 v283; // r11
  unsigned int v284; // r10d
  __int64 v285; // rcx
  __int64 v286; // rdx
  char v287; // cl
  char v288; // bl
  __int64 v289; // r14
  int pred_context_single_ref_p1; // eax
  int v291; // edi
  int v292; // edx
  unsigned int v293; // ecx
  __int64 v294; // rdi
  unsigned int v295; // r8d
  unsigned int v296; // r8d
  int v297; // eax
  int v298; // r9d
  int v299; // esi
  int v300; // ecx
  __int64 v301; // r10
  __int64 v302; // r11
  unsigned int v303; // r10d
  _DWORD *v304; // r14
  __int64 v305; // rcx
  __int64 v306; // rdx
  unsigned __int8 v307; // dl
  char v308; // bl
  __int64 v309; // r14
  int pred_context_single_ref_p2; // eax
  int v311; // edi
  unsigned int v312; // ecx
  unsigned int v313; // r8d
  int v314; // esi
  int v315; // edx
  int v316; // ecx
  __int64 v317; // r10
  __int64 v318; // r11
  unsigned int v319; // r10d
  __int64 v320; // rcx
  __int64 v321; // rsi
  char v322; // dl
  __int64 v323; // rax
  bool v324; // cl
  _BYTE *v325; // r15
  __int64 v326; // rdx
  int v327; // ecx
  unsigned int v328; // eax
  __int64 v329; // rdx
  __int64 v330; // rax
  unsigned int v331; // r10d
  int v332; // eax
  unsigned int v333; // edx
  unsigned int v334; // esi
  unsigned int v335; // r11d
  char v336; // di
  int v337; // ecx
  int v338; // r15d
  unsigned int v339; // r8d
  __int64 v340; // r11
  unsigned int v341; // r8d
  int v342; // esi
  unsigned int v343; // r9d
  int v344; // ecx
  __int64 v345; // rdi
  __int64 v346; // r14
  int v347; // edi
  unsigned int v348; // r14d
  unsigned int *v349; // r13
  __int64 v350; // rcx
  __int64 v351; // rdx
  unsigned __int8 v352; // dl
  unsigned int v353; // r8d
  __int16 *v354; // r15
  __int64 v355; // rax
  __int64 v356; // rcx
  __int64 v357; // r15
  unsigned int *v358; // r13
  __int64 v359; // rdx
  char *v360; // rsi
  _DWORD *v361; // rdi
  __int16 *v362; // r15
  __int64 v363; // rbx
  __int16 *v364; // r15
  __int64 v365; // r14
  __int64 v366; // [rsp+8h] [rbp-C8h]
  __int64 v368; // [rsp+20h] [rbp-B0h]
  __int64 v369; // [rsp+20h] [rbp-B0h]
  __int64 v370; // [rsp+28h] [rbp-A8h]
  int v371; // [rsp+28h] [rbp-A8h]
  unsigned __int8 v372; // [rsp+30h] [rbp-A0h]
  __int64 v374; // [rsp+40h] [rbp-90h]
  __int64 v375; // [rsp+40h] [rbp-90h]
  unsigned __int8 v376; // [rsp+48h] [rbp-88h]
  _BYTE *v377; // [rsp+48h] [rbp-88h]
  __int64 v378; // [rsp+50h] [rbp-80h]
  _BYTE *v379; // [rsp+50h] [rbp-80h]
  __int64 v380; // [rsp+50h] [rbp-80h]
  __int64 v381; // [rsp+58h] [rbp-78h]
  int v382; // [rsp+58h] [rbp-78h]
  __int64 v383; // [rsp+58h] [rbp-78h]
  char *v384; // [rsp+60h] [rbp-70h]
  __int64 v385; // [rsp+60h] [rbp-70h]
  __int64 v386; // [rsp+60h] [rbp-70h]
  int v387; // [rsp+68h] [rbp-68h]
  __int64 v388; // [rsp+68h] [rbp-68h]
  _QWORD *v389; // [rsp+68h] [rbp-68h]
  __int64 v390; // [rsp+68h] [rbp-68h]
  __int64 v391; // [rsp+68h] [rbp-68h]
  _BYTE *v392; // [rsp+70h] [rbp-60h]
  __int64 v393; // [rsp+70h] [rbp-60h]
  __int16 *v394; // [rsp+70h] [rbp-60h]
  __int64 v395; // [rsp+78h] [rbp-58h]
  __int64 v396; // [rsp+78h] [rbp-58h]
  __int64 v397; // [rsp+78h] [rbp-58h]
  __int64 v398; // [rsp+80h] [rbp-50h]
  unsigned int v399; // [rsp+80h] [rbp-50h]
  unsigned int v400; // [rsp+80h] [rbp-50h]
  char *v401; // [rsp+80h] [rbp-50h]
  unsigned __int8 *v402; // [rsp+80h] [rbp-50h]
  __int64 v403; // [rsp+88h] [rbp-48h]
  unsigned int v404; // [rsp+88h] [rbp-48h]
  _BYTE *v405; // [rsp+88h] [rbp-48h]
  __int16 *v406; // [rsp+88h] [rbp-48h]
  __int64 v407; // [rsp+90h] [rbp-40h]
  unsigned __int8 *v408; // [rsp+90h] [rbp-40h]
  __int64 v409; // [rsp+90h] [rbp-40h]
  unsigned __int8 *v410; // [rsp+98h] [rbp-38h]
  unsigned __int8 **v411; // [rsp+98h] [rbp-38h]
  char v412; // [rsp+98h] [rbp-38h]
  __int64 v413; // [rsp+98h] [rbp-38h]
  __int64 v414; // [rsp+98h] [rbp-38h]
  __int64 v415; // [rsp+98h] [rbp-38h]
  __int64 v416; // [rsp+A0h] [rbp-30h]

  v11 = a2; /*0x103af3c64*/
  v398 = *(_QWORD *)(a1 + 74768); /*0x103af3c79*/
  v12 = *(_DWORD *)(a1 + 172760); /*0x103af3c7d*/
  v13 = (__int64 *)(*(_QWORD *)(a1 + 172920) + 8LL * (a8 + a7 * *(_DWORD *)(a1 + 172764))); /*0x103af3c9b*/
  *(_QWORD *)(a2 + 448) = v13; /*0x103af3c9f*/
  v14 = *(unsigned __int8 *)*v13; /*0x103af3ca9*/
  v15 = num_8x8_blocks_high_lookup[v14]; /*0x103af3cb3*/
  LODWORD(v14) = num_8x8_blocks_wide_lookup[v14]; /*0x103af3cbe*/
  v16 = *(_DWORD *)(a1 + 172752); /*0x103af3ccd*/
  *(_DWORD *)(v11 + 496) = -64 * a7; /*0x103af3cd4*/
  *(_DWORD *)(v11 + 500) = (v16 - (a7 + v15)) << 6; /*0x103af3ce5*/
  *(_DWORD *)(v11 + 488) = -64 * a8; /*0x103af3cf4*/
  v387 = v12; /*0x103af3cfe*/
  *(_DWORD *)(v11 + 492) = (v12 - (a8 + (_DWORD)v14)) << 6; /*0x103af3d09*/
  if ( a7 != 0 ) /*0x103af3d13*/
    v17 = (unsigned __int8 *)v13[-*(int *)(v11 + 440)]; /*0x103af3d26*/
  else
    v17 = nullptr; /*0x103af3d2b*/
  *(_QWORD *)(v11 + 464) = v17; /*0x103af3d2d*/
  if ( *(_DWORD *)(a3 + 8) >= a8 ) /*0x103af3d3b*/
    v19 = nullptr; /*0x103af3d43*/
  else
    v19 = (_BYTE *)*(v13 - 1); /*0x103af3d3d*/
  v384 = (char *)(a1 + 171680); /*0x103af3d4e*/
  *(_QWORD *)(v11 + 456) = v19; /*0x103af3d52*/
  v416 = a4; /*0x103af3d70*/
  v407 = v11; /*0x103af3d74*/
  v392 = v19; /*0x103af3d78*/
  if ( *(_DWORD *)(a1 + 172716) == 0 || *(_BYTE *)(a1 + 172732) != 0 ) /*0x103af3d87*/
  {
    v410 = v17; /*0x103af3d8d*/
    v20 = *v13; /*0x103af3d91*/
    v21 = a4; /*0x103af3d94*/
    v22 = *(unsigned __int8 *)*v13; /*0x103af3d97*/
    if ( *(_BYTE *)(a1 + 176217) != 0 ) /*0x103af3da4*/
      write_segment_id(a1: v21, a2: a1 + 176216); /*0x103af3db6*/
    write_skip(a1: v384, a2: v407, a3: (unsigned int)*(char *)(v20 + 4), a4: v20, a5: v21); /*0x103af3dce*/
    v403 = v20; /*0x103af3dd6*/
    if ( (unsigned __int8)v22 < 3u ) /*0x103af3dda*/
    {
      v26 = num_4x4_blocks_high_lookup[v22]; /*0x103af3e56*/
      v27 = (unsigned __int8 *)(v20 + 20); /*0x103af3e5a*/
      v378 = (unsigned int)(2 * v26); /*0x103af3e61*/
      v370 = num_4x4_blocks_high_lookup[v22]; /*0x103af3e65*/
      v395 = 3LL * (unsigned int)(8 * v26); /*0x103af3e73*/
      v28 = 0; /*0x103af3e82*/
      v29 = 0; /*0x103af3e84*/
      v381 = num_4x4_blocks_wide_lookup[v22]; /*0x103af3e86*/
      v385 = 12LL * (unsigned int)num_4x4_blocks_wide_lookup[v22]; /*0x103af3e8a*/
      do /*0x103af3f2e*/
      {
        v368 = v29; /*0x103af3e8e*/
        v408 = v27; /*0x103af3e95*/
        v30 = 0; /*0x103af3e99*/
        v388 = v28; /*0x103af3e9c*/
        do /*0x103af3f0e*/
        {
          v399 = *v27; /*0x103af3ea4*/
          v31 = v28 + v30; /*0x103af3ea7*/
          v32 = vp9_above_block_mode(a1: v403, a2: v410, a3: (int)v28 + (int)v30); /*0x103af3ebe*/
          v33 = vp9_left_block_mode(a1: v403, a2: v392, a3: v31); /*0x103af3ed2*/
          write_intra_mode(a1: v416, a2: v399, a3: (char *)&vp9_kf_y_mode_prob + 90 * v32 + 9 * v33); /*0x103af3ef3*/
          LODWORD(v28) = v388; /*0x103af3ef8*/
          v30 += v381; /*0x103af3f04*/
          v27 += v385; /*0x103af3f07*/
        }
        while ( v30 < 2 ); /*0x103af3f0e*/
        v29 = v370 + v368; /*0x103af3f17*/
        v28 = v378 + v388; /*0x103af3f1e*/
        v27 = &v408[v395]; /*0x103af3f26*/
      }
      while ( (unsigned __int64)(v370 + v368) < 2 ); /*0x103af3f2e*/
    }
    else
    {
      if ( *(_DWORD *)(a1 + 172768) == 4 ) /*0x103af3de5*/
        write_selected_tx_size(a1: v384, a2: v407, a3: v416); /*0x103af3df3*/
      v23 = *(unsigned __int8 *)(v20 + 1); /*0x103af3df8*/
      v24 = vp9_above_block_mode(a1: v20, a2: v410, a3: 0); /*0x103af3e0b*/
      v25 = vp9_left_block_mode(a1: v20, a2: v19, a3: 0); /*0x103af3e16*/
      write_intra_mode(a1: v416, a2: v23, a3: (char *)&vp9_kf_y_mode_prob + 90 * v24 + 9 * v25); /*0x103af3e3a*/
    }
    v34 = v403; /*0x103af3f34*/
    v35 = *(_BYTE *)(v403 + 1); /*0x103af3f38*/
    v36 = (char *)&vp9_kf_uv_mode_prob; /*0x103af3f3b*/
    goto LABEL_20; /*0x103af3f3b*/
  }
  v188 = (_BYTE *)(a1 + 176216); /*0x103af4860*/
  v189 = (_BYTE *)*v13; /*0x103af4868*/
  v376 = *(_BYTE *)(*v13 + 1); /*0x103af486f*/
  v412 = *(_BYTE *)(*v13 + 8); /*0x103af4879*/
  v190 = (unsigned int)*(char *)(*v13 + 4); /*0x103af487c*/
  v396 = *(unsigned __int8 *)*v13; /*0x103af4886*/
  v371 = *(_DWORD *)(a1 + 172736); /*0x103af4892*/
  v372 = *(_BYTE *)(*v13 + 9); /*0x103af489c*/
  v369 = *(_QWORD *)(a1 + 176344) + 1970LL; /*0x103af48aa*/
  v379 = (_BYTE *)(a1 + 176216); /*0x103af48ba*/
  if ( *(_BYTE *)(a1 + 176217) != 0 ) /*0x103af48be*/
  {
    v404 = *(char *)(*v13 + 4); /*0x103af48cd*/
    if ( *(_BYTE *)(a1 + 176220) == 0 ) /*0x103af48d0*/
    {
      v194 = a4; /*0x103af4910*/
      v188 = v379; /*0x103af4913*/
LABEL_167:
      write_segment_id(a1: v194, a2: v188); /*0x103af4a38*/
      v190 = v404; /*0x103af4a40*/
      goto LABEL_168; /*0x103af4a40*/
    }
    if ( v17 != nullptr ) /*0x103af48d5*/
      v191 = (char)v17[5]; /*0x103af48d7*/
    else
      v191 = 0; /*0x103af491c*/
    v195 = v189[5]; /*0x103af491e*/
    if ( v392 != nullptr ) /*0x103af492b*/
      v196 = (char)v392[5]; /*0x103af492d*/
    else
      v196 = 0; /*0x103af4934*/
    v197 = *(unsigned __int8 *)(a1 + v191 + v196 + 176228); /*0x103af4939*/
    v198 = *(_DWORD *)(a4 + 4); /*0x103af4942*/
    v199 = *(_DWORD *)(a4 + 8); /*0x103af4946*/
    v200 = ((unsigned int)(v197 * (v198 - 1)) >> 8) + 1; /*0x103af4955*/
    v201 = v198 - v200; /*0x103af4958*/
    if ( v195 == 0 ) /*0x103af495e*/
    {
      v201 = v200; /*0x103af495e*/
      v200 = 0; /*0x103af4962*/
    }
    v202 = *(_DWORD *)a4 + v200; /*0x103af4966*/
    v203 = vpx_norm[v201]; /*0x103af4970*/
    v204 = v203 + v199; /*0x103af4978*/
    if ( v203 + v199 < 0 ) /*0x103af497b*/
    {
      v208 = vpx_norm[v201]; /*0x103af49c1*/
    }
    else
    {
      if ( ((v202 << ~(_BYTE)v199) & 0x80000000) != 0 ) /*0x103af498e*/
      {
        v205 = *(_DWORD *)(a4 + 12); /*0x103af4990*/
        LODWORD(v206) = v205 - 1; /*0x103af4996*/
        if ( v205 - 1 >= 0 ) /*0x103af4999*/
        {
          while ( 1 ) /*0x103af499b*/
          {
            v206 = (unsigned int)(v205 - 1); /*0x103af499b*/
            v207 = *(_QWORD *)(a4 + 16); /*0x103af499f*/
            if ( *(_BYTE *)(v207 + v206) != 0xFF ) /*0x103af49a8*/
              break; /*0x103af49a8*/
            *(_BYTE *)(v207 + v206) = 0; /*0x103af49aa*/
            --v205; /*0x103af49af*/
            a4 = v416; /*0x103af49b3*/
            if ( v205 <= 0 ) /*0x103af49b7*/
            {
              LODWORD(v206) = -1; /*0x103af49b9*/
              goto LABEL_163; /*0x103af49bf*/
            }
          }
          a4 = v416; /*0x103af49c5*/
        }
LABEL_163:
        ++*(_BYTE *)(*(_QWORD *)(a4 + 16) + (int)v206); /*0x103af49c9*/
      }
      v209 = *(_QWORD *)(a4 + 16); /*0x103af49e0*/
      v210 = *(unsigned int *)(a4 + 12); /*0x103af49e4*/
      *(_DWORD *)(v416 + 12) = v210 + 1; /*0x103af49ee*/
      a4 = v416; /*0x103af49f2*/
      *(_BYTE *)(v209 + v210) = v202 >> (v199 + 24); /*0x103af49f6*/
      v202 = (v202 << -(char)v199) & 0xFFFFFF; /*0x103af49ff*/
      v208 = v203 + v199; /*0x103af4a06*/
      v204 -= 8; /*0x103af4a0d*/
      v190 = v404; /*0x103af4a14*/
    }
    *(_DWORD *)(a4 + 8) = v204; /*0x103af4a21*/
    *(_DWORD *)a4 = v202 << v208; /*0x103af4a25*/
    *(_DWORD *)(a4 + 4) = (_DWORD)v201 << v203; /*0x103af4a28*/
    v211 = v195 == 0; /*0x103af4a2c*/
    v188 = (_BYTE *)(a1 + 176216); /*0x103af4a2f*/
    if ( v211 ) /*0x103af4a33*/
    {
      v194 = a4; /*0x103af4a35*/
      goto LABEL_167; /*0x103af4a35*/
    }
  }
LABEL_168:
  v393 = (int)v190; /*0x103af4a43*/
  v212 = write_skip(a1: v384, a2: v11, a3: v190, a4: v189, a5: a4); /*0x103af4a57*/
  if ( *v188 == 0 || (*(_BYTE *)(a1 + 4 * v393 + 176296) & 4) == 0 ) /*0x103af4a73*/
  {
    v213 = *(_QWORD *)(v11 + 456); /*0x103af4a81*/
    v214 = *(_QWORD *)(v11 + 464); /*0x103af4a88*/
    if ( v214 != 0 && v213 != 0 ) /*0x103af4a99*/
    {
      v215 = *(_BYTE *)(v214 + 8); /*0x103af4aa6*/
      v216 = *(_BYTE *)(v213 + 8); /*0x103af4ab1*/
      v217 = v215 <= 0 || v216 <= 0; /*0x103af4aba*/
      v218 = v215 <= 0; /*0x103af4abd*/
      v219 = 3; /*0x103af4ac4*/
      if ( !v218 ) /*0x103af4ac9*/
        v219 = v217; /*0x103af4ac9*/
      if ( v216 > 0 ) /*0x103af4acf*/
        v219 = v217; /*0x103af4acf*/
    }
    else if ( (v213 | v214) != 0 ) /*0x103af4adb*/
    {
      if ( v214 != 0 ) /*0x103af4ae0*/
        v213 = *(_QWORD *)(v11 + 464); /*0x103af4ae0*/
      v219 = 2 * (unsigned int)(*(_BYTE *)(v213 + 8) <= 0); /*0x103af4aee*/
    }
    else
    {
      v219 = 0; /*0x103af4af2*/
    }
    v220 = *(unsigned __int8 *)(*(_QWORD *)(a1 + 176344) + v219 + 1931); /*0x103af4af4*/
    v221 = *(_DWORD *)(a4 + 4); /*0x103af4afc*/
    v222 = *(_DWORD *)(a4 + 8); /*0x103af4b00*/
    v223 = ((unsigned int)(v220 * (v221 - 1)) >> 8) + 1; /*0x103af4b0d*/
    v224 = v221 - v223; /*0x103af4b0f*/
    v225 = 0; /*0x103af4b12*/
    if ( v412 > 0 ) /*0x103af4b19*/
      v225 = v223; /*0x103af4b1d*/
    else
      v224 = v223; /*0x103af4b19*/
    v226 = *(_DWORD *)a4 + v225; /*0x103af4b21*/
    v227 = vpx_norm[v224]; /*0x103af4b2b*/
    v228 = v227 + v222; /*0x103af4b33*/
    if ( v227 + v222 < 0 ) /*0x103af4b36*/
    {
      v233 = vpx_norm[v224]; /*0x103af4b7c*/
    }
    else
    {
      v229 = -v222; /*0x103af4b3a*/
      if ( ((v226 << ~(_BYTE)v222) & 0x80000000) != 0 ) /*0x103af4b49*/
      {
        v230 = *(_DWORD *)(a4 + 12); /*0x103af4b4b*/
        LODWORD(v231) = v230 - 1; /*0x103af4b51*/
        if ( v230 - 1 >= 0 ) /*0x103af4b54*/
        {
          while ( 1 ) /*0x103af4b56*/
          {
            v231 = (unsigned int)(v230 - 1); /*0x103af4b56*/
            v232 = *(_QWORD *)(a4 + 16); /*0x103af4b5a*/
            if ( *(_BYTE *)(v232 + v231) != 0xFF ) /*0x103af4b63*/
              break; /*0x103af4b63*/
            *(_BYTE *)(v232 + v231) = 0; /*0x103af4b65*/
            --v230; /*0x103af4b6a*/
            a4 = v416; /*0x103af4b6e*/
            if ( v230 <= 0 ) /*0x103af4b72*/
            {
              LODWORD(v231) = -1; /*0x103af4b74*/
              goto LABEL_192; /*0x103af4b7a*/
            }
          }
          a4 = v416; /*0x103af4b80*/
        }
LABEL_192:
        ++*(_BYTE *)(*(_QWORD *)(a4 + 16) + (int)v231); /*0x103af4b84*/
      }
      v234 = v226 >> (v222 + 24); /*0x103af4b98*/
      v235 = *(_QWORD *)(a4 + 16); /*0x103af4b9b*/
      v236 = *(unsigned int *)(a4 + 12); /*0x103af4b9f*/
      *(_DWORD *)(v416 + 12) = v236 + 1; /*0x103af4ba9*/
      a4 = v416; /*0x103af4bad*/
      *(_BYTE *)(v235 + v236) = v234; /*0x103af4bb1*/
      v226 = (v226 << v229) & 0xFFFFFF; /*0x103af4bba*/
      v233 = v228; /*0x103af4bc1*/
      v228 -= 8; /*0x103af4bc8*/
    }
    *(_DWORD *)(a4 + 8) = v228; /*0x103af4bd9*/
    *(_DWORD *)a4 = v226 << v233; /*0x103af4bdd*/
    *(_DWORD *)(a4 + 4) = (_DWORD)v224 << v227; /*0x103af4be0*/
  }
  v237 = v396; /*0x103af4be4*/
  v405 = v189; /*0x103af4bec*/
  v383 = a1; /*0x103af4bf0*/
  if ( (unsigned __int8)v396 < 3u ) /*0x103af4bf4*/
  {
    if ( v412 <= 0 ) /*0x103af4c5c*/
    {
      v262 = num_4x4_blocks_wide_lookup[v396]; /*0x103af4dcb*/
      v263 = v189 + 20; /*0x103af4dda*/
      v414 = num_4x4_blocks_high_lookup[v396]; /*0x103af4dde*/
      v264 = 3LL * (unsigned int)(4 * v262); /*0x103af4df8*/
      v265 = 0; /*0x103af4dfc*/
      do /*0x103af4e47*/
      {
        v391 = v265; /*0x103af4e02*/
        v402 = v263; /*0x103af4e06*/
        v266 = 0; /*0x103af4e0a*/
        do /*0x103af4e31*/
        {
          v267 = v262; /*0x103af4e1c*/
          write_intra_mode(a1: v416, a2: *v263, a3: *(_QWORD *)(v383 + 176344)); /*0x103af4e1f*/
          v262 = v267; /*0x103af4e24*/
          v266 += v267; /*0x103af4e27*/
          v263 += v264; /*0x103af4e2a*/
        }
        while ( v266 < 2 ); /*0x103af4e31*/
        v265 = v414 + v391; /*0x103af4e37*/
        v263 = &v402[3 * (unsigned int)(8 * v414)]; /*0x103af4e3f*/
      }
      while ( (unsigned __int64)(v414 + v391) < 2 ); /*0x103af4e47*/
      goto LABEL_221; /*0x103af4e47*/
    }
    v239 = *(_QWORD *)(a1 + 176344); /*0x103af4c62*/
  }
  else
  {
    v238 = v212 != 0; /*0x103af4bff*/
    if ( *(_DWORD *)(a1 + 172768) == 4 && (!v238 || v412 <= 0) ) /*0x103af4bfa*/
    {
      write_selected_tx_size(a1: v384, a2: v11, a3: a4); /*0x103af4c1b*/
      v237 = v396; /*0x103af4c20*/
    }
    v239 = *(_QWORD *)(a1 + 176344); /*0x103af4c24*/
    if ( v412 <= 0 ) /*0x103af4c30*/
    {
      write_intra_mode(a1: a4, a2: v376, a3: 9LL * size_group_lookup[v237] + v239); /*0x103af4c4e*/
LABEL_221:
      v36 = (char *)(*(_QWORD *)(v383 + 176344) + 36LL); /*0x103af4e49*/
      v34 = (__int64)v405; /*0x103af4e58*/
      v35 = v376; /*0x103af4e5c*/
LABEL_20:
      v37 = (unsigned int *)v416; /*0x103af3f42*/
      write_intra_mode(a1: v416, a2: *(unsigned __int8 *)(v34 + 6), a3: &v36[9 * v35]); /*0x103af3f57*/
      goto LABEL_21; /*0x103af3f57*/
    }
  }
  v390 = v398 + 36LL * (a8 + a7 * v387); /*0x103af4c7e*/
  v401 = v189 + 8; /*0x103af4c86*/
  v240 = *(unsigned __int8 *)(v390 + (char)v189[8] + 32); /*0x103af4c8e*/
  v241 = *(__int64 **)(v11 + 448); /*0x103af4c93*/
  v242 = *v241; /*0x103af4c9a*/
  v243 = *(_BYTE *)(*v241 + 9); /*0x103af4c9d*/
  if ( *v379 == 0 || (*(_BYTE *)(a1 + 4LL * *(char *)(v242 + 4) + 176296) & 4) == 0 ) /*0x103af4cba*/
  {
    v374 = *(unsigned __int8 *)(v390 + (char)v189[8] + 32); /*0x103af4cc0*/
    v413 = v239; /*0x103af4cc7*/
    if ( *(_DWORD *)(a1 + 176336) == 2 ) /*0x103af4cd4*/
    {
      reference_mode_context = vp9_get_reference_mode_context(a1: (__int64)v384, a2: v11); /*0x103af4ce1*/
      v245 = *(_DWORD *)(v416 + 4); /*0x103af4cf8*/
      v246 = *(_DWORD *)(v416 + 8); /*0x103af4cfb*/
      v247 = (((unsigned int)*(unsigned __int8 *)(v413 + reference_mode_context + 1935) * (v245 - 1)) >> 8) + 1; /*0x103af4d07*/
      v248 = v245 - v247; /*0x103af4d09*/
      v249 = 0; /*0x103af4d0b*/
      if ( v243 > 0 ) /*0x103af4d10*/
        v249 = v247; /*0x103af4d13*/
      else
        v248 = v247; /*0x103af4d10*/
      v250 = *(_DWORD *)v416 + v249; /*0x103af4d17*/
      v251 = vpx_norm[v248]; /*0x103af4d21*/
      v252 = v251 + v246; /*0x103af4d28*/
      if ( v251 + v246 < 0 ) /*0x103af4d2b*/
      {
        v261 = vpx_norm[v248]; /*0x103af4e67*/
        v258 = (_DWORD *)v416; /*0x103af4e69*/
      }
      else
      {
        v253 = -v246; /*0x103af4d33*/
        if ( ((v250 << ~(_BYTE)v246) & 0x80000000) != 0 ) /*0x103af4d42*/
        {
          v254 = *(_DWORD *)(v416 + 12); /*0x103af4d48*/
          LODWORD(v255) = v254 - 1; /*0x103af4d4e*/
          if ( v254 - 1 >= 0 ) /*0x103af4d51*/
          {
            while ( 1 ) /*0x103af4d53*/
            {
              v255 = (unsigned int)(v254 - 1); /*0x103af4d53*/
              v256 = *(_QWORD *)(v416 + 16); /*0x103af4d5b*/
              if ( *(_BYTE *)(v256 + v255) != 0xFF ) /*0x103af4d64*/
                break; /*0x103af4d64*/
              *(_BYTE *)(v256 + v255) = 0; /*0x103af4d66*/
              if ( --v254 <= 0 ) /*0x103af4d6f*/
              {
                LODWORD(v255) = -1; /*0x103af4d71*/
                break; /*0x103af4d71*/
              }
            }
          }
          ++*(_BYTE *)(*(_QWORD *)(v416 + 16) + (int)v255); /*0x103af4d77*/
        }
        v257 = v250 >> (v246 + 24); /*0x103af4d8e*/
        v258 = (_DWORD *)v416; /*0x103af4d91*/
        v259 = *(_QWORD *)(v416 + 16); /*0x103af4d95*/
        v260 = *(unsigned int *)(v416 + 12); /*0x103af4d99*/
        *(_DWORD *)(v416 + 12) = v260 + 1; /*0x103af4da1*/
        *(_BYTE *)(v259 + v260) = v257; /*0x103af4da5*/
        v250 = (v250 << v253) & 0xFFFFFF; /*0x103af4dae*/
        v261 = v252; /*0x103af4db5*/
        v252 -= 8; /*0x103af4dbc*/
      }
      v258[2] = v252; /*0x103af4e76*/
      *v258 = v250 << v261; /*0x103af4e7a*/
      v258[1] = (_DWORD)v248 << v251; /*0x103af4e7d*/
    }
    if ( v243 <= 0 ) /*0x103af4e83*/
    {
      v288 = *(_BYTE *)(v242 + 8); /*0x103af4f7f*/
      v289 = *(_QWORD *)(a1 + 176344); /*0x103af4f83*/
      pred_context_single_ref_p1 = vp9_get_pred_context_single_ref_p1(a1: v407); /*0x103af4f8f*/
      v291 = *(_DWORD *)(v416 + 4); /*0x103af4fa3*/
      v292 = *(_DWORD *)(v416 + 8); /*0x103af4fa6*/
      v293 = (((unsigned int)*(unsigned __int8 *)(v289 + 2LL * pred_context_single_ref_p1 + 1940) * (v291 - 1)) >> 8) /*0x103af4fb2*/
           + 1;
      v294 = v291 - v293; /*0x103af4fb4*/
      v295 = 0; /*0x103af4fb6*/
      if ( v288 == 1 ) /*0x103af4fbc*/
        v294 = v293; /*0x103af4fbc*/
      else
        v295 = v293; /*0x103af4fbf*/
      v296 = *(_DWORD *)v416 + v295; /*0x103af4fc3*/
      v297 = vpx_norm[v294]; /*0x103af4fcd*/
      v298 = v297 + v292; /*0x103af4fd4*/
      if ( v297 + v292 < 0 ) /*0x103af4fd7*/
      {
        v307 = vpx_norm[v294]; /*0x103af506d*/
        v304 = (_DWORD *)v416; /*0x103af506f*/
      }
      else
      {
        v299 = -v292; /*0x103af4fdf*/
        if ( ((v296 << ~(_BYTE)v292) & 0x80000000) != 0 ) /*0x103af4fee*/
        {
          v300 = *(_DWORD *)(v416 + 12); /*0x103af4ff4*/
          LODWORD(v301) = v300 - 1; /*0x103af4ffa*/
          if ( v300 - 1 >= 0 ) /*0x103af4ffd*/
          {
            while ( 1 ) /*0x103af4fff*/
            {
              v301 = (unsigned int)(v300 - 1); /*0x103af4fff*/
              v302 = *(_QWORD *)(v416 + 16); /*0x103af5007*/
              if ( *(_BYTE *)(v302 + v301) != 0xFF ) /*0x103af5010*/
                break; /*0x103af5010*/
              *(_BYTE *)(v302 + v301) = 0; /*0x103af5012*/
              if ( --v300 <= 0 ) /*0x103af501b*/
              {
                LODWORD(v301) = -1; /*0x103af501d*/
                break; /*0x103af501d*/
              }
            }
          }
          ++*(_BYTE *)(*(_QWORD *)(v416 + 16) + (int)v301); /*0x103af5023*/
        }
        v303 = v296 >> (v292 + 24); /*0x103af503a*/
        v304 = (_DWORD *)v416; /*0x103af503d*/
        v305 = *(_QWORD *)(v416 + 16); /*0x103af5041*/
        v306 = *(unsigned int *)(v416 + 12); /*0x103af5045*/
        *(_DWORD *)(v416 + 12) = v306 + 1; /*0x103af504d*/
        *(_BYTE *)(v305 + v306) = v303; /*0x103af5051*/
        v296 = (v296 << v299) & 0xFFFFFF; /*0x103af505a*/
        v307 = v298; /*0x103af5061*/
        v298 -= 8; /*0x103af5068*/
      }
      v304[2] = v298; /*0x103af507c*/
      *v304 = v296 << v307; /*0x103af5080*/
      v304[1] = (_DWORD)v294 << v297; /*0x103af5083*/
      v237 = v396; /*0x103af508a*/
      v11 = v407; /*0x103af508e*/
      v239 = v413; /*0x103af5092*/
      v240 = v374; /*0x103af5096*/
      if ( v288 == 1 ) /*0x103af509d*/
        goto LABEL_264; /*0x103af509d*/
      v308 = *(_BYTE *)(v242 + 8); /*0x103af50a3*/
      v309 = *(_QWORD *)(a1 + 176344); /*0x103af50aa*/
      pred_context_single_ref_p2 = vp9_get_pred_context_single_ref_p2(a1: v407); /*0x103af50b2*/
      v311 = *(_DWORD *)(v416 + 4); /*0x103af50c6*/
      v312 = (((unsigned int)*(unsigned __int8 *)(v309 + 2LL * pred_context_single_ref_p2 + 1941) * (v311 - 1)) >> 8) /*0x103af50d2*/
           + 1;
      v275 = v311 - v312; /*0x103af50d4*/
      v313 = 0; /*0x103af50d6*/
      v211 = v308 == 2; /*0x103af50d9*/
      v276 = (_DWORD *)v416; /*0x103af50dc*/
      if ( v211 ) /*0x103af50df*/
        v275 = v312; /*0x103af50df*/
      else
        v313 = v312; /*0x103af50e2*/
      v277 = *(_DWORD *)v416 + v313; /*0x103af50e6*/
      v314 = *(_DWORD *)(v416 + 8); /*0x103af50e9*/
      v278 = vpx_norm[v275]; /*0x103af50f3*/
      v279 = v278 + v314; /*0x103af50fa*/
      if ( v278 + v314 >= 0 ) /*0x103af50fd*/
      {
        v315 = -v314; /*0x103af5105*/
        v11 = v407; /*0x103af5114*/
        if ( ((v277 << ~(_BYTE)v314) & 0x80000000) != 0 ) /*0x103af5118*/
        {
          v316 = *(_DWORD *)(v416 + 12); /*0x103af511a*/
          LODWORD(v317) = v316 - 1; /*0x103af5120*/
          if ( v316 - 1 >= 0 ) /*0x103af5123*/
          {
            while ( 1 ) /*0x103af5125*/
            {
              v317 = (unsigned int)(v316 - 1); /*0x103af5125*/
              v318 = *(_QWORD *)(v416 + 16); /*0x103af5129*/
              if ( *(_BYTE *)(v318 + v317) != 0xFF ) /*0x103af5132*/
                break; /*0x103af5132*/
              *(_BYTE *)(v318 + v317) = 0; /*0x103af5134*/
              if ( --v316 <= 0 ) /*0x103af513d*/
              {
                LODWORD(v317) = -1; /*0x103af513f*/
                break; /*0x103af513f*/
              }
            }
          }
          ++*(_BYTE *)(*(_QWORD *)(v416 + 16) + (int)v317); /*0x103af5145*/
        }
        v319 = v277 >> (v314 + 24); /*0x103af5159*/
        v320 = *(_QWORD *)(v416 + 16); /*0x103af515c*/
        v321 = *(unsigned int *)(v416 + 12); /*0x103af5160*/
        *(_DWORD *)(v416 + 12) = v321 + 1; /*0x103af5167*/
        *(_BYTE *)(v320 + v321) = v319; /*0x103af516b*/
        v287 = v315; /*0x103af516f*/
        goto LABEL_261; /*0x103af516f*/
      }
    }
    else
    {
      v268 = *(_BYTE *)((*(_DWORD *)(a1 + 4LL * *(char *)(a1 + 176332) + 176148) == 0) + v242 + 8); /*0x103af4e9f*/
      v269 = *(_BYTE *)(a1 + 176334); /*0x103af4ea2*/
      pred_context_comp_ref_p = vp9_get_pred_context_comp_ref_p(a1: v384, a2: v407); /*0x103af4eb2*/
      v271 = *(_DWORD *)(v416 + 4); /*0x103af4ecd*/
      v272 = *(_DWORD *)(v416 + 8); /*0x103af4ed0*/
      v273 = (((unsigned int)*(unsigned __int8 *)(*(_QWORD *)(a1 + 176344) + pred_context_comp_ref_p + 1950LL) /*0x103af4edc*/
             * (v271 - 1)) >> 8)
           + 1;
      v274 = 0; /*0x103af4ede*/
      if ( v268 == v269 ) /*0x103af4ee4*/
        v274 = (((unsigned int)*(unsigned __int8 *)(*(_QWORD *)(a1 + 176344) + pred_context_comp_ref_p + 1950LL) /*0x103af4ee4*/
               * (v271 - 1)) >> 8)
             + 1;
      v275 = v271 - v273; /*0x103af4ee8*/
      v211 = v268 == v269; /*0x103af4eea*/
      v276 = (_DWORD *)v416; /*0x103af4eed*/
      if ( !v211 ) /*0x103af4ef0*/
        v275 = v273; /*0x103af4ef0*/
      v277 = *(_DWORD *)v416 + v274; /*0x103af4ef3*/
      v278 = vpx_norm[v275]; /*0x103af4efd*/
      v279 = v278 + v272; /*0x103af4f04*/
      if ( v278 + v272 >= 0 ) /*0x103af4f07*/
      {
        v280 = -v272; /*0x103af4f0f*/
        v11 = v407; /*0x103af4f1e*/
        if ( ((v277 << ~(_BYTE)v272) & 0x80000000) != 0 ) /*0x103af4f22*/
        {
          v281 = *(_DWORD *)(v416 + 12); /*0x103af4f24*/
          LODWORD(v282) = v281 - 1; /*0x103af4f2a*/
          if ( v281 - 1 >= 0 ) /*0x103af4f2d*/
          {
            while ( 1 ) /*0x103af4f2f*/
            {
              v282 = (unsigned int)(v281 - 1); /*0x103af4f2f*/
              v283 = *(_QWORD *)(v416 + 16); /*0x103af4f33*/
              if ( *(_BYTE *)(v283 + v282) != 0xFF ) /*0x103af4f3c*/
                break; /*0x103af4f3c*/
              *(_BYTE *)(v283 + v282) = 0; /*0x103af4f3e*/
              if ( --v281 <= 0 ) /*0x103af4f47*/
              {
                LODWORD(v282) = -1; /*0x103af4f49*/
                break; /*0x103af4f49*/
              }
            }
          }
          ++*(_BYTE *)(*(_QWORD *)(v416 + 16) + (int)v282); /*0x103af4f4f*/
        }
        v284 = v277 >> (v272 + 24); /*0x103af4f62*/
        v285 = *(_QWORD *)(v416 + 16); /*0x103af4f65*/
        v286 = *(unsigned int *)(v416 + 12); /*0x103af4f69*/
        *(_DWORD *)(v416 + 12) = v286 + 1; /*0x103af4f70*/
        *(_BYTE *)(v285 + v286) = v284; /*0x103af4f74*/
        v287 = v280; /*0x103af4f78*/
LABEL_261:
        v277 = (v277 << v287) & 0xFFFFFF; /*0x103af5171*/
        v322 = v279; /*0x103af517b*/
        v279 -= 8; /*0x103af5182*/
LABEL_263:
        v276[2] = v279; /*0x103af518d*/
        *v276 = v277 << v322; /*0x103af519a*/
        v276[1] = (_DWORD)v275 << v278; /*0x103af519d*/
        v237 = v396; /*0x103af51a0*/
        v239 = v413; /*0x103af51a4*/
        v240 = v374; /*0x103af51a8*/
        goto LABEL_264; /*0x103af51a8*/
      }
    }
    v322 = v278; /*0x103af5187*/
    v11 = v407; /*0x103af5189*/
    goto LABEL_263; /*0x103af5189*/
  }
LABEL_264:
  v323 = 3 * v240; /*0x103af51af*/
  v324 = *v379 == 0 || (*(_BYTE *)(a1 + 4 * v393 + 176296) & 8) == 0; /*0x103af51c7*/
  v325 = v189; /*0x103af51ce*/
  v380 = v239 + v323 + 1910; /*0x103af51db*/
  v37 = (unsigned int *)v416; /*0x103af51e3*/
  if ( (unsigned __int8)v237 >= 3u && v324 ) /*0x103af51eb*/
  {
    write_inter_mode(a1: v416, a2: v376, a3: v380); /*0x103af51fb*/
    v237 = v396; /*0x103af5200*/
  }
  if ( *(_BYTE *)(a1 + 172996) == 4 ) /*0x103af520d*/
  {
    v326 = *(_QWORD *)(v11 + 456); /*0x103af5213*/
    v327 = 3; /*0x103af521a*/
    v328 = 3; /*0x103af521f*/
    if ( v326 != 0 ) /*0x103af5227*/
      v328 = *(unsigned __int8 *)(v326 + 7); /*0x103af5229*/
    v329 = *(_QWORD *)(v11 + 464); /*0x103af522d*/
    if ( v329 != 0 ) /*0x103af5237*/
      v327 = *(unsigned __int8 *)(v329 + 7); /*0x103af5239*/
    if ( v328 != v327 ) /*0x103af523f*/
    {
      if ( v328 == 3 ) /*0x103af5244*/
      {
        v328 = v327; /*0x103af5246*/
      }
      else if ( v327 != 3 ) /*0x103af5252*/
      {
        v328 = 3; /*0x103af5252*/
      }
    }
    v415 = *(_QWORD *)(a1 + 176344) + 2LL * v328 + 1902; /*0x103af5269*/
    v330 = (unsigned __int8)v189[7]; /*0x103af526d*/
    v331 = switchable_interp_encodings[2 * v330]; /*0x103af5279*/
    v332 = switchable_interp_encodings[2 * v330 + 1]; /*0x103af527d*/
    v333 = *(_DWORD *)(v416 + 8); /*0x103af5281*/
    v334 = *(_DWORD *)v416; /*0x103af5284*/
    v335 = *(_DWORD *)(v416 + 4); /*0x103af5286*/
    v336 = 0; /*0x103af528a*/
    do /*0x103af53aa*/
    {
      v337 = -_bittest((const int *)&v331, --v332); /*0x103af529e*/
      v338 = v336; /*0x103af52a0*/
      v339 = ((*(unsigned __int8 *)(v415 + (v336 >> 1)) * (v335 - 1)) >> 8) + 1; /*0x103af52c1*/
      v340 = v335 - v339; /*0x103af52c4*/
      if ( ((v331 >> v332) & 1) == 0 ) /*0x103af52ca*/
        v340 = v339; /*0x103af52ca*/
      v341 = v334 + (v337 & v339); /*0x103af52d1*/
      v342 = vpx_norm[v340]; /*0x103af52db*/
      v343 = v342 + v333; /*0x103af52e3*/
      if ( (int)(v342 + v333) < 0 ) /*0x103af52e6*/
      {
        v352 = vpx_norm[v340]; /*0x103af5375*/
        v349 = (unsigned int *)v416; /*0x103af5377*/
      }
      else
      {
        if ( ((v341 << ~(_BYTE)v333) & 0x80000000) != 0 ) /*0x103af52f7*/
        {
          v344 = *(_DWORD *)(v416 + 12); /*0x103af52fd*/
          LODWORD(v345) = v344 - 1; /*0x103af5302*/
          if ( v344 - 1 >= 0 ) /*0x103af5304*/
          {
            while ( 1 ) /*0x103af5306*/
            {
              v345 = (unsigned int)(v344 - 1); /*0x103af5306*/
              v346 = *(_QWORD *)(v416 + 16); /*0x103af530d*/
              if ( *(_BYTE *)(v346 + v345) != 0xFF ) /*0x103af5316*/
                break; /*0x103af5316*/
              *(_BYTE *)(v346 + v345) = 0; /*0x103af5318*/
              if ( --v344 <= 0 ) /*0x103af5321*/
              {
                LODWORD(v345) = -1; /*0x103af5323*/
                break; /*0x103af5323*/
              }
            }
          }
          ++*(_BYTE *)(*(_QWORD *)(v416 + 16) + (int)v345); /*0x103af5328*/
        }
        v347 = -v333; /*0x103af5338*/
        v348 = v341 >> (v333 + 24); /*0x103af5342*/
        v349 = (unsigned int *)v416; /*0x103af5345*/
        v350 = *(_QWORD *)(v416 + 16); /*0x103af5349*/
        v351 = *(unsigned int *)(v416 + 12); /*0x103af534d*/
        *(_DWORD *)(v416 + 12) = v351 + 1; /*0x103af5355*/
        *(_BYTE *)(v350 + v351) = v348; /*0x103af5359*/
        v341 = (v341 << v347) & 0xFFFFFF; /*0x103af5362*/
        v352 = v343; /*0x103af5369*/
        v343 -= 8; /*0x103af5370*/
      }
      v335 = (_DWORD)v340 << v342; /*0x103af537d*/
      v353 = v341 << v352; /*0x103af5382*/
      v349[2] = v343; /*0x103af5385*/
      *v349 = v353; /*0x103af5389*/
      v349[1] = v335; /*0x103af538d*/
      v336 = vp9_switchable_interp_tree[v338 + ((v331 >> v332) & 1)]; /*0x103af539e*/
      v334 = v353; /*0x103af53a2*/
      v333 = v343; /*0x103af53a5*/
    }
    while ( v332 != 0 ); /*0x103af53aa*/
    v325 = v405; /*0x103af53b0*/
    ++*(_DWORD *)(a10 + 4LL * (unsigned __int8)v405[7]); /*0x103af53bd*/
    v37 = (unsigned int *)v416; /*0x103af53c0*/
    v237 = v396; /*0x103af53c4*/
  }
  if ( (unsigned __int8)v237 > 2u ) /*0x103af53cc*/
  {
    if ( v376 == 13 ) /*0x103af5537*/
    {
      v364 = (__int16 *)(v325 + 12); /*0x103af554b*/
      v365 = ((char)v372 > 0) + 1LL; /*0x103af554f*/
      do /*0x103af5596*/
      {
        vp9_encode_mv(a1, a2: v37, a3: v364, a4: (__int16 *)(v390 + 8LL * *v401++), a5: v369, a6: v371, a7: a9); /*0x103af5583*/
        v364 += 2; /*0x103af558f*/
        --v365; /*0x103af5593*/
      }
      while ( v365 != 0 ); /*0x103af5596*/
    }
  }
  else
  {
    v377 = v325 + 20; /*0x103af53f8*/
    v354 = (__int16 *)(v325 + 24); /*0x103af5406*/
    v366 = num_4x4_blocks_high_lookup[v237]; /*0x103af540a*/
    v397 = num_4x4_blocks_wide_lookup[v237]; /*0x103af5423*/
    v355 = 0; /*0x103af5439*/
    do /*0x103af5525*/
    {
      v375 = v355; /*0x103af5449*/
      v409 = 2 * v355; /*0x103af5453*/
      v406 = v354; /*0x103af5457*/
      v394 = v354; /*0x103af545b*/
      v356 = 0; /*0x103af545f*/
      do /*0x103af5502*/
      {
        v386 = v356; /*0x103af5465*/
        v357 = (unsigned __int8)v377[12 * v356 + 12 * v409]; /*0x103af5477*/
        write_inter_mode(a1: v37, a2: v357, a3: v380); /*0x103af5486*/
        v358 = v37; /*0x103af548f*/
        v359 = v390; /*0x103af5492*/
        v360 = v401; /*0x103af5496*/
        v361 = a9; /*0x103af549a*/
        if ( (_DWORD)v357 == 13 ) /*0x103af549e*/
        {
          v362 = v394; /*0x103af54a0*/
          v363 = 0; /*0x103af54a4*/
          do /*0x103af54e2*/
          {
            vp9_encode_mv( /*0x103af54c3*/
              a1,
              a2: v358,
              a3: v362,
              a4: (__int16 *)(v359 + 8LL * v360[v363]),
              a5: v369,
              a6: v371,
              a7: v361);
            v361 = a9; /*0x103af54cc*/
            v360 = v401; /*0x103af54d0*/
            v359 = v390; /*0x103af54d4*/
            ++v363; /*0x103af54d8*/
            v362 += 2; /*0x103af54db*/
          }
          while ( ((char)v372 > 0) + 1LL != v363 ); /*0x103af54e2*/
        }
        v356 = v397 + v386; /*0x103af54e8*/
        v394 = (__int16 *)((char *)v394 + 3 * (unsigned int)(4 * v397)); /*0x103af54f7*/
        v37 = v358; /*0x103af54ff*/
      }
      while ( (unsigned __int64)(v397 + v386) < 2 ); /*0x103af5502*/
      v355 = v366 + v375; /*0x103af550f*/
      v354 = (__int16 *)((char *)v406 + 3 * (unsigned int)(8 * v366)); /*0x103af551a*/
    }
    while ( (unsigned __int64)(v366 + v375) < 2 ); /*0x103af5525*/
  }
LABEL_21:
  v38 = *a5; /*0x103af3f5c*/
  for ( i = a6; v38 < i; v38 += 2 ) /*0x103af3f70*/
  {
    v40 = *((unsigned __int16 *)v38 + 4); /*0x103af3f7d*/
    if ( v40 == 11 ) /*0x103af3f85*/
    {
      v56 = v37[2]; /*0x103af4042*/
      v57 = *v37; /*0x103af4045*/
      v58 = (**v38 * (v37[1] - 1)) >> 8; /*0x103af4052*/
      v59 = vpx_norm[v58 + 1]; /*0x103af4056*/
      v60 = v59 + v56; /*0x103af405f*/
      if ( (int)(v59 + v56) < 0 ) /*0x103af4062*/
      {
        v68 = vpx_norm[v58 + 1]; /*0x103af40d9*/
      }
      else
      {
        if ( ((v57 << ~(_BYTE)v56) & 0x80000000) != 0 ) /*0x103af406e*/
        {
          v61 = v37[3]; /*0x103af4070*/
          LODWORD(v62) = v61 - 1; /*0x103af4075*/
          if ( (int)(v61 - 1) >= 0 ) /*0x103af4077*/
          {
            while ( 1 ) /*0x103af4079*/
            {
              v62 = v61 - 1; /*0x103af4079*/
              v63 = *((_QWORD *)v37 + 2); /*0x103af407c*/
              if ( *(_BYTE *)(v63 + v62) != 0xFF ) /*0x103af4085*/
                break; /*0x103af4085*/
              *(_BYTE *)(v63 + v62) = 0; /*0x103af4087*/
              if ( (int)--v61 <= 0 ) /*0x103af4090*/
              {
                LODWORD(v62) = -1; /*0x103af4092*/
                break; /*0x103af4092*/
              }
            }
          }
          ++*(_BYTE *)(*((_QWORD *)v37 + 2) + (int)v62); /*0x103af4097*/
        }
        v64 = -v56; /*0x103af40a3*/
        v65 = v57 >> (v56 + 24); /*0x103af40ad*/
        v66 = *((_QWORD *)v37 + 2); /*0x103af40b0*/
        v67 = v37[3]; /*0x103af40b4*/
        v37[3] = v67 + 1; /*0x103af40bb*/
        *(_BYTE *)(v66 + v67) = v65; /*0x103af40bf*/
        v57 = (v57 << v64) & 0xFFFFFF; /*0x103af40c7*/
        v68 = v60; /*0x103af40cd*/
        v60 -= 8; /*0x103af40d4*/
      }
      LODWORD(v58) = v58 + 1; /*0x103af40db*/
    }
    else
    {
      if ( v40 == 127 ) /*0x103af3f8e*/
        break; /*0x103af3f8e*/
      v41 = v37[1]; /*0x103af3f9a*/
      v42 = ((**v38 * (v41 - 1)) >> 8) + 1; /*0x103af3faa*/
      v43 = v41 - v42; /*0x103af3fad*/
      v44 = *v37 + v42; /*0x103af3fb0*/
      v45 = v37[2]; /*0x103af3fb3*/
      v46 = vpx_norm[v43]; /*0x103af3fb6*/
      v47 = v46 + v45; /*0x103af3fbd*/
      if ( (int)(v46 + v45) < 0 ) /*0x103af3fbf*/
      {
        v55 = vpx_norm[v43]; /*0x103af4103*/
      }
      else
      {
        if ( ((v44 << ~(_BYTE)v45) & 0x80000000) != 0 ) /*0x103af3fd0*/
        {
          v48 = v37[3]; /*0x103af3fd2*/
          LODWORD(v49) = v48 - 1; /*0x103af3fd7*/
          if ( (int)(v48 - 1) >= 0 ) /*0x103af3fd9*/
          {
            while ( 1 ) /*0x103af3fdb*/
            {
              v49 = v48 - 1; /*0x103af3fdb*/
              v50 = *((_QWORD *)v37 + 2); /*0x103af3fde*/
              if ( *(_BYTE *)(v50 + v49) != 0xFF ) /*0x103af3fe7*/
                break; /*0x103af3fe7*/
              *(_BYTE *)(v50 + v49) = 0; /*0x103af3fe9*/
              if ( (int)--v48 <= 0 ) /*0x103af3ff2*/
              {
                LODWORD(v49) = -1; /*0x103af3ff4*/
                break; /*0x103af3ff4*/
              }
            }
          }
          ++*(_BYTE *)(*((_QWORD *)v37 + 2) + (int)v49); /*0x103af3ff9*/
        }
        v51 = -v45; /*0x103af4005*/
        v52 = v44 >> (v45 + 24); /*0x103af4010*/
        v53 = *((_QWORD *)v37 + 2); /*0x103af4013*/
        v54 = v37[3]; /*0x103af4017*/
        v37[3] = v54 + 1; /*0x103af401e*/
        *(_BYTE *)(v53 + v54) = v52; /*0x103af4022*/
        v44 = (v44 << v51) & 0xFFFFFF; /*0x103af402b*/
        v55 = v47; /*0x103af4032*/
        v47 -= 8; /*0x103af4034*/
      }
      v71 = (_DWORD)v43 << v46; /*0x103af4107*/
      v72 = v44 << v55; /*0x103af410c*/
      v37[2] = v47; /*0x103af410f*/
      *v37 = v72; /*0x103af4112*/
      v37[1] = v71; /*0x103af4115*/
      while ( 1 ) /*0x103af4119*/
      {
        v73 = *((__int16 *)v38 + 4); /*0x103af4119*/
        v74 = *v38; /*0x103af411e*/
        v75 = (((*v38)[1] * (v71 - 1)) >> 8) + 1LL; /*0x103af4130*/
        if ( *((_WORD *)v38 + 4) != 0 ) /*0x103af4136*/
          break; /*0x103af4136*/
        v76 = vpx_norm[v75]; /*0x103af413c*/
        v77 = v76 + v47; /*0x103af4144*/
        if ( (int)(v76 + v47) < 0 ) /*0x103af4147*/
        {
          v85 = vpx_norm[v75]; /*0x103af41d3*/
          v47 += v76; /*0x103af41d5*/
        }
        else
        {
          if ( ((v72 << ~(_BYTE)v47) & 0x80000000) != 0 ) /*0x103af4158*/
          {
            v78 = v37[3]; /*0x103af415a*/
            LODWORD(v79) = v78 - 1; /*0x103af415f*/
            if ( (int)(v78 - 1) >= 0 ) /*0x103af4161*/
            {
              while ( 1 ) /*0x103af4163*/
              {
                v79 = v78 - 1; /*0x103af4163*/
                v80 = *((_QWORD *)v37 + 2); /*0x103af4166*/
                if ( *(_BYTE *)(v80 + v79) != 0xFF ) /*0x103af416f*/
                  break; /*0x103af416f*/
                *(_BYTE *)(v80 + v79) = 0; /*0x103af4171*/
                if ( (int)--v78 <= 0 ) /*0x103af417a*/
                {
                  LODWORD(v79) = -1; /*0x103af417c*/
                  break; /*0x103af417c*/
                }
              }
            }
            ++*(_BYTE *)(*((_QWORD *)v37 + 2) + (int)v79); /*0x103af4181*/
          }
          v81 = -v47; /*0x103af418d*/
          v82 = v72 >> (v47 + 24); /*0x103af4196*/
          v83 = *((_QWORD *)v37 + 2); /*0x103af4199*/
          v84 = *(unsigned int *)(v416 + 12); /*0x103af41a1*/
          *(_DWORD *)(v416 + 12) = v84 + 1; /*0x103af41ab*/
          *(_BYTE *)(v83 + v84) = v82; /*0x103af41bb*/
          v37 = (unsigned int *)v416; /*0x103af41bf*/
          v72 = (v72 << v81) & 0xFFFFFF; /*0x103af41c3*/
          v47 = v77 - 8; /*0x103af41ca*/
          v85 = v77; /*0x103af41ce*/
        }
        v86 = (_DWORD)v75 << v76; /*0x103af41da*/
        v72 <<= v85; /*0x103af41de*/
        v37[2] = v47; /*0x103af41e1*/
        *v37 = v72; /*0x103af41e4*/
        v37[1] = v86; /*0x103af41e7*/
        v87 = v38 + 2; /*0x103af41ea*/
        v88 = *((_WORD *)v38 + 12); /*0x103af41ee*/
        if ( v38 + 2 == i ) /*0x103af41f6*/
        {
          v192 = v88 == 127; /*0x103af48e4*/
          goto LABEL_146; /*0x103af48e4*/
        }
        v71 = v86; /*0x103af41fc*/
        v38 += 2; /*0x103af41ff*/
        if ( v88 == 127 ) /*0x103af4206*/
        {
          v192 = true; /*0x103af48e9*/
LABEL_146:
          v187 = (unsigned __int8 **)((char *)v87 + (unsigned int)(16 * v192)); /*0x103af48ee*/
          goto LABEL_147; /*0x103af48f1*/
        }
      }
      v89 = v71 - (unsigned int)v75; /*0x103af4211*/
      v90 = v75 + v72; /*0x103af4214*/
      v91 = vpx_norm[v89]; /*0x103af4217*/
      v92 = v91 + v47; /*0x103af421e*/
      if ( (int)(v91 + v47) < 0 ) /*0x103af4220*/
      {
        v100 = vpx_norm[v89]; /*0x103af42ae*/
      }
      else
      {
        if ( ((v90 << ~(_BYTE)v47) & 0x80000000) != 0 ) /*0x103af4234*/
        {
          v93 = v37[3]; /*0x103af4236*/
          LODWORD(v94) = v93 - 1; /*0x103af423b*/
          if ( (int)(v93 - 1) >= 0 ) /*0x103af423d*/
          {
            while ( 1 ) /*0x103af423f*/
            {
              v94 = v93 - 1; /*0x103af423f*/
              v95 = *((_QWORD *)v37 + 2); /*0x103af4242*/
              if ( *(_BYTE *)(v95 + v94) != 0xFF ) /*0x103af424b*/
                break; /*0x103af424b*/
              *(_BYTE *)(v95 + v94) = 0; /*0x103af424d*/
              if ( (int)--v93 <= 0 ) /*0x103af4256*/
              {
                LODWORD(v94) = -1; /*0x103af4258*/
                break; /*0x103af4258*/
              }
            }
          }
          ++*(_BYTE *)(*((_QWORD *)v37 + 2) + (int)v94); /*0x103af425d*/
        }
        v96 = -v47; /*0x103af4269*/
        v97 = v90 >> (v47 + 24); /*0x103af4272*/
        v98 = *((_QWORD *)v37 + 2); /*0x103af4275*/
        v99 = v37[3]; /*0x103af4279*/
        *(_DWORD *)(v416 + 12) = v99 + 1; /*0x103af4283*/
        v37 = (unsigned int *)v416; /*0x103af4287*/
        *(_BYTE *)(v98 + v99) = v97; /*0x103af428b*/
        v90 = (v90 << v96) & 0xFFFFFF; /*0x103af4294*/
        v100 = v92; /*0x103af429b*/
        v92 -= 8; /*0x103af42a0*/
      }
      v101 = (_DWORD)v89 << v91; /*0x103af42b2*/
      v102 = v90 << v100; /*0x103af42b7*/
      v37[2] = v92; /*0x103af42ba*/
      *v37 = v102; /*0x103af42bd*/
      v37[1] = v101; /*0x103af42c0*/
      if ( (_WORD)v73 == 1 ) /*0x103af42c9*/
      {
        v103 = (v74[2] * (v101 - 1)) >> 8; /*0x103af42db*/
        v104 = vpx_norm[v103 + 1]; /*0x103af42df*/
        v105 = v104 + v92; /*0x103af42e7*/
        if ( (int)(v104 + v92) < 0 ) /*0x103af42e9*/
        {
          v113 = vpx_norm[v103 + 1]; /*0x103af4431*/
        }
        else
        {
          if ( ((v102 << ~(_BYTE)v92) & 0x80000000) != 0 ) /*0x103af42fa*/
          {
            v106 = v37[3]; /*0x103af42fc*/
            LODWORD(v107) = v106 - 1; /*0x103af4301*/
            if ( (int)(v106 - 1) >= 0 ) /*0x103af4303*/
            {
              while ( 1 ) /*0x103af4305*/
              {
                v107 = v106 - 1; /*0x103af4305*/
                v108 = *((_QWORD *)v37 + 2); /*0x103af4308*/
                if ( *(_BYTE *)(v108 + v107) != 0xFF ) /*0x103af4311*/
                  break; /*0x103af4311*/
                *(_BYTE *)(v108 + v107) = 0; /*0x103af4313*/
                if ( (int)--v106 <= 0 ) /*0x103af431c*/
                {
                  LODWORD(v107) = -1; /*0x103af431e*/
                  break; /*0x103af431e*/
                }
              }
            }
            ++*(_BYTE *)(*((_QWORD *)v37 + 2) + (int)v107); /*0x103af4323*/
          }
          v109 = -v92; /*0x103af432f*/
          v110 = v102 >> (v92 + 24); /*0x103af433a*/
          v111 = *((_QWORD *)v37 + 2); /*0x103af433d*/
          v112 = v37[3]; /*0x103af4341*/
          v37[3] = v112 + 1; /*0x103af4348*/
          *(_BYTE *)(v111 + v112) = v110; /*0x103af434c*/
          v102 = (v102 << v109) & 0xFFFFFF; /*0x103af4355*/
          v113 = v105; /*0x103af435c*/
          v105 -= 8; /*0x103af435e*/
        }
        v128 = ((_DWORD)v103 + 1) << v104; /*0x103af4438*/
        v129 = v102 << v113; /*0x103af443d*/
        v37[2] = v105; /*0x103af4440*/
        *v37 = v129; /*0x103af4443*/
        v37[1] = v128; /*0x103af4446*/
        v130 = ((unsigned int)((v128 << 7) - 128) >> 8) + 1; /*0x103af4456*/
        v131 = v128 - v130; /*0x103af4458*/
        if ( (*((_BYTE *)v38 + 10) & 1) == 0 ) /*0x103af4460*/
        {
          v131 = v130; /*0x103af4460*/
          v130 = 0; /*0x103af4469*/
        }
        v57 = v129 + v130; /*0x103af446c*/
        v132 = vpx_norm[v131]; /*0x103af446f*/
        v60 = v132 + v105; /*0x103af4477*/
        if ( (int)(v132 + v105) < 0 ) /*0x103af447a*/
        {
          v140 = vpx_norm[v131]; /*0x103af482c*/
        }
        else
        {
          if ( ((v57 << ~(_BYTE)v105) & 0x80000000) != 0 ) /*0x103af448a*/
          {
            v133 = v37[3]; /*0x103af448c*/
            LODWORD(v134) = v133 - 1; /*0x103af4491*/
            if ( (int)(v133 - 1) >= 0 ) /*0x103af4493*/
            {
              while ( 1 ) /*0x103af4495*/
              {
                v134 = v133 - 1; /*0x103af4495*/
                v135 = *((_QWORD *)v37 + 2); /*0x103af4498*/
                if ( *(_BYTE *)(v135 + v134) != 0xFF ) /*0x103af44a1*/
                  break; /*0x103af44a1*/
                *(_BYTE *)(v135 + v134) = 0; /*0x103af44a3*/
                if ( (int)--v133 <= 0 ) /*0x103af44ac*/
                {
                  LODWORD(v134) = -1; /*0x103af44ae*/
                  break; /*0x103af44ae*/
                }
              }
            }
            ++*(_BYTE *)(*((_QWORD *)v37 + 2) + (int)v134); /*0x103af44b3*/
          }
          v136 = -v105; /*0x103af44bf*/
          v137 = v57 >> (v105 + 24); /*0x103af44c8*/
          v138 = *((_QWORD *)v37 + 2); /*0x103af44cb*/
          v139 = v37[3]; /*0x103af44cf*/
          v37[3] = v139 + 1; /*0x103af44d6*/
          *(_BYTE *)(v138 + v139) = v137; /*0x103af44da*/
          v57 = (v57 << v136) & 0xFFFFFF; /*0x103af44e2*/
          v140 = v60; /*0x103af44e8*/
          v60 -= 8; /*0x103af44ef*/
        }
        v69 = (_DWORD)v131 << v132; /*0x103af4830*/
        v70 = v140; /*0x103af4833*/
        goto LABEL_43; /*0x103af4835*/
      }
      v400 = vp9_coef_encodings[2 * v73]; /*0x103af4371*/
      v114 = vp9_coef_encodings[2 * v73 + 1]; /*0x103af4374*/
      v382 = *((__int16 *)v38 + 5); /*0x103af437e*/
      v115 = (v74[2] * (v101 - 1)) >> 8; /*0x103af438d*/
      v116 = v101 - (v115 + 1); /*0x103af4393*/
      v117 = v115 + v102 + 1; /*0x103af439a*/
      v118 = vpx_norm[v116]; /*0x103af439d*/
      v119 = v118 + v92; /*0x103af43a4*/
      v411 = v38; /*0x103af43a6*/
      if ( (int)(v118 + v92) < 0 ) /*0x103af43aa*/
      {
        v127 = vpx_norm[v116]; /*0x103af44f7*/
      }
      else
      {
        if ( ((v117 << ~(_BYTE)v92) & 0x80000000) != 0 ) /*0x103af43bd*/
        {
          v120 = v37[3]; /*0x103af43bf*/
          LODWORD(v121) = v120 - 1; /*0x103af43c5*/
          if ( (int)(v120 - 1) >= 0 ) /*0x103af43c8*/
          {
            while ( 1 ) /*0x103af43ca*/
            {
              v121 = v120 - 1; /*0x103af43ca*/
              v122 = *((_QWORD *)v37 + 2); /*0x103af43ce*/
              if ( *(_BYTE *)(v122 + v121) != 0xFF ) /*0x103af43d7*/
                break; /*0x103af43d7*/
              *(_BYTE *)(v122 + v121) = 0; /*0x103af43d9*/
              if ( (int)--v120 <= 0 ) /*0x103af43e2*/
              {
                LODWORD(v121) = -1; /*0x103af43e4*/
                break; /*0x103af43e4*/
              }
            }
          }
          ++*(_BYTE *)(*((_QWORD *)v37 + 2) + (int)v121); /*0x103af43ea*/
        }
        v123 = -v92; /*0x103af43f8*/
        v124 = v117 >> (v92 + 24); /*0x103af4404*/
        v125 = *((_QWORD *)v37 + 2); /*0x103af4407*/
        v126 = v37[3]; /*0x103af440b*/
        v37[3] = v126 + 1; /*0x103af4412*/
        *(_BYTE *)(v125 + v126) = v124; /*0x103af4416*/
        v117 = (v117 << v123) & 0xFFFFFF; /*0x103af4420*/
        v127 = v119; /*0x103af4427*/
        v119 -= 8; /*0x103af4429*/
      }
      v141 = (_DWORD)v116 << v118; /*0x103af44fb*/
      v142 = v117 << v127; /*0x103af4500*/
      v37[2] = v119; /*0x103af4503*/
      *v37 = v142; /*0x103af4506*/
      v37[1] = v141; /*0x103af4509*/
      v389 = &vp9_pareto8_full[v74[2] - 1]; /*0x103af4521*/
      v143 = v114 - 3; /*0x103af4525*/
      v144 = 0; /*0x103af4528*/
      do /*0x103af463b*/
      {
        --v143; /*0x103af452a*/
        v145 = v400; /*0x103af452c*/
        v146 = -_bittest((const int *)&v145, v143); /*0x103af453f*/
        v147 = v144; /*0x103af4541*/
        v148 = ((*((unsigned __int8 *)v389 + (v144 >> 1)) * (v141 - 1)) >> 8) + 1; /*0x103af4561*/
        v149 = v141 - v148; /*0x103af4564*/
        if ( ((v400 >> v143) & 1) == 0 ) /*0x103af456b*/
          v149 = v148; /*0x103af456b*/
        v150 = v142 + (v146 & v148); /*0x103af4572*/
        v151 = vpx_norm[v149]; /*0x103af4575*/
        v152 = v151 + v119; /*0x103af457d*/
        if ( (int)(v151 + v119) < 0 ) /*0x103af4580*/
        {
          v160 = vpx_norm[v149]; /*0x103af460c*/
          v119 += v151; /*0x103af460e*/
        }
        else
        {
          if ( ((v150 << ~(_BYTE)v119) & 0x80000000) != 0 ) /*0x103af4591*/
          {
            v153 = v37[3]; /*0x103af4593*/
            LODWORD(v154) = v153 - 1; /*0x103af4598*/
            if ( (int)(v153 - 1) >= 0 ) /*0x103af459a*/
            {
              while ( 1 ) /*0x103af459c*/
              {
                v154 = v153 - 1; /*0x103af459c*/
                v155 = *((_QWORD *)v37 + 2); /*0x103af459f*/
                if ( *(_BYTE *)(v155 + v154) != 0xFF ) /*0x103af45a8*/
                  break; /*0x103af45a8*/
                *(_BYTE *)(v155 + v154) = 0; /*0x103af45aa*/
                if ( (int)--v153 <= 0 ) /*0x103af45b3*/
                {
                  LODWORD(v154) = -1; /*0x103af45b5*/
                  break; /*0x103af45b5*/
                }
              }
            }
            ++*(_BYTE *)(*((_QWORD *)v37 + 2) + (int)v154); /*0x103af45ba*/
          }
          v156 = -v119; /*0x103af45c6*/
          v157 = v150 >> (v119 + 24); /*0x103af45cf*/
          v158 = *((_QWORD *)v37 + 2); /*0x103af45d2*/
          v159 = *(unsigned int *)(v416 + 12); /*0x103af45da*/
          *(_DWORD *)(v416 + 12) = v159 + 1; /*0x103af45e4*/
          *(_BYTE *)(v158 + v159) = v157; /*0x103af45f4*/
          v37 = (unsigned int *)v416; /*0x103af45f8*/
          v150 = (v150 << v156) & 0xFFFFFF; /*0x103af45fc*/
          v119 = v152 - 8; /*0x103af4603*/
          v160 = v152; /*0x103af4607*/
        }
        v141 = (_DWORD)v149 << v151; /*0x103af4613*/
        v142 = v150 << v160; /*0x103af461b*/
        v37[2] = v119; /*0x103af461e*/
        *v37 = v150 << v160; /*0x103af4621*/
        v37[1] = v141; /*0x103af4624*/
        v144 = vp9_coef_con_tree[v147 + ((v400 >> v143) & 1)]; /*0x103af4635*/
      }
      while ( v143 != 0 ); /*0x103af463b*/
      if ( (__int16)v73 < 5 ) /*0x103af4646*/
      {
        v178 = v150 << v160; /*0x103af4769*/
        v168 = v119; /*0x103af476c*/
        i = a6; /*0x103af476e*/
      }
      else
      {
        v161 = *((unsigned __int8 **)&vp9_extra_bits + 3 * v73); /*0x103af4657*/
        v163 = *((_DWORD *)&vp9_extra_bits + 6 * v73 + 2); /*0x103af4660*/
        i = a6; /*0x103af4665*/
        do /*0x103af4761*/
        {
          --v163; /*0x103af466c*/
          v164 = ((*v161 * (v141 - 1)) >> 8) + 1; /*0x103af467f*/
          v165 = v141 - v164; /*0x103af4682*/
          v162 = v382 >> 1; /*0x103af465e*/
          if ( !_bittest(&v162, v163) ) /*0x103af4689*/
          {
            v165 = v164; /*0x103af4689*/
            v164 = 0; /*0x103af4692*/
          }
          v166 = v142 + v164; /*0x103af4696*/
          v167 = vpx_norm[v165]; /*0x103af4699*/
          v168 = v167 + v119; /*0x103af46a0*/
          if ( (int)(v167 + v119) < 0 ) /*0x103af46a2*/
          {
            v177 = vpx_norm[v165]; /*0x103af473b*/
            v174 = (unsigned int *)v416; /*0x103af473d*/
          }
          else
          {
            if ( ((v166 << ~(_BYTE)v119) & 0x80000000) != 0 ) /*0x103af46b3*/
            {
              v169 = *(_DWORD *)(v416 + 12); /*0x103af46b9*/
              LODWORD(v170) = v169 - 1; /*0x103af46be*/
              if ( v169 - 1 >= 0 ) /*0x103af46c0*/
              {
                while ( 1 ) /*0x103af46c2*/
                {
                  v170 = (unsigned int)(v169 - 1); /*0x103af46c2*/
                  v171 = *(_QWORD *)(v416 + 16); /*0x103af46c9*/
                  if ( *(_BYTE *)(v171 + v170) != 0xFF ) /*0x103af46d2*/
                    break; /*0x103af46d2*/
                  *(_BYTE *)(v171 + v170) = 0; /*0x103af46d4*/
                  if ( --v169 <= 0 ) /*0x103af46dd*/
                  {
                    LODWORD(v170) = -1; /*0x103af46df*/
                    break; /*0x103af46df*/
                  }
                }
              }
              ++*(_BYTE *)(*(_QWORD *)(v416 + 16) + (int)v170); /*0x103af46eb*/
            }
            v172 = -v119; /*0x103af46fb*/
            v173 = v166 >> (v119 + 24); /*0x103af4704*/
            v174 = (unsigned int *)v416; /*0x103af4707*/
            v175 = *(_QWORD *)(v416 + 16); /*0x103af470b*/
            v176 = *(unsigned int *)(v416 + 12); /*0x103af470f*/
            *(_DWORD *)(v416 + 12) = v176 + 1; /*0x103af4717*/
            *(_BYTE *)(v175 + v176) = v173; /*0x103af471b*/
            v166 = (v166 << v172) & 0xFFFFFF; /*0x103af4724*/
            v177 = v168; /*0x103af472b*/
            v168 -= 8; /*0x103af4730*/
            i = a6; /*0x103af4732*/
          }
          v141 = (_DWORD)v165 << v167; /*0x103af4743*/
          v178 = v166 << v177; /*0x103af4748*/
          ++v161; /*0x103af474b*/
          v174[2] = v168; /*0x103af474e*/
          *v174 = v178; /*0x103af4752*/
          v174[1] = v141; /*0x103af4755*/
          v142 = v178; /*0x103af4759*/
          v119 = v168; /*0x103af475c*/
        }
        while ( v163 != 0 ); /*0x103af4761*/
      }
      v179 = (((v141 << 7) - 128) >> 8) + 1; /*0x103af478b*/
      v58 = v141 - v179; /*0x103af478d*/
      if ( (v382 & 1) == 0 ) /*0x103af4792*/
        v58 = v179; /*0x103af4792*/
      v57 = v178 + (-(v382 & 1) & v179); /*0x103af4798*/
      v59 = vpx_norm[v58]; /*0x103af479b*/
      v60 = v59 + v168; /*0x103af47a3*/
      v38 = v411; /*0x103af47a6*/
      if ( (int)(v59 + v168) < 0 ) /*0x103af47aa*/
      {
        v68 = vpx_norm[v58]; /*0x103af483a*/
        v37 = (unsigned int *)v416; /*0x103af483c*/
      }
      else
      {
        v37 = (unsigned int *)v416; /*0x103af47ba*/
        if ( ((v57 << ~(_BYTE)v168) & 0x80000000) != 0 ) /*0x103af47be*/
        {
          v180 = *(_DWORD *)(v416 + 12); /*0x103af47c0*/
          LODWORD(v181) = v180 - 1; /*0x103af47c5*/
          if ( v180 - 1 >= 0 ) /*0x103af47c7*/
          {
            while ( 1 ) /*0x103af47c9*/
            {
              v181 = (unsigned int)(v180 - 1); /*0x103af47c9*/
              v182 = *(_QWORD *)(v416 + 16); /*0x103af47cc*/
              if ( *(_BYTE *)(v182 + v181) != 0xFF ) /*0x103af47d5*/
                break; /*0x103af47d5*/
              *(_BYTE *)(v182 + v181) = 0; /*0x103af47d7*/
              if ( --v180 <= 0 ) /*0x103af47e0*/
              {
                LODWORD(v181) = -1; /*0x103af47e2*/
                break; /*0x103af47e2*/
              }
            }
          }
          ++*(_BYTE *)(*(_QWORD *)(v416 + 16) + (int)v181); /*0x103af47e7*/
        }
        v183 = -v168; /*0x103af47f3*/
        v184 = v57 >> (v168 + 24); /*0x103af47fd*/
        v185 = *(_QWORD *)(v416 + 16); /*0x103af4800*/
        v186 = *(unsigned int *)(v416 + 12); /*0x103af4804*/
        *(_DWORD *)(v416 + 12) = v186 + 1; /*0x103af480b*/
        *(_BYTE *)(v185 + v186) = v184; /*0x103af480f*/
        v57 = (v57 << v183) & 0xFFFFFF; /*0x103af4817*/
        v68 = v60; /*0x103af481d*/
        v60 -= 8; /*0x103af4824*/
      }
    }
    v69 = (_DWORD)v58 << v59; /*0x103af40e0*/
    v70 = v68; /*0x103af40e3*/
LABEL_43:
    v37[2] = v60; /*0x103af40e5*/
    *v37 = v57 << v70; /*0x103af40eb*/
    v37[1] = v69; /*0x103af40ed*/
  }
  v187 = &v38[2 * (unsigned int)(*((_WORD *)v38 + 4) == 127)]; /*0x103af4845*/
LABEL_147:
  *a5 = v187; /*0x103af48f4*/
  return a5; /*0x103af48fe*/
}

// Address: 0x103af559d | Name: _write_segment_id
void __fastcall write_segment_id(unsigned int *a1, _BYTE *a2, unsigned int a3)
{
  unsigned int v3; // r8d
  unsigned int v4; // r9d
  unsigned int v5; // r11d
  int v6; // eax
  char v7; // r10
  int v8; // ecx
  int v9; // esi
  unsigned int v10; // r13d
  __int64 v11; // r11
  unsigned int v12; // r13d
  int v13; // r9d
  unsigned int v14; // ebx
  unsigned int v15; // ecx
  __int64 v16; // r10
  __int64 v17; // r14
  int v18; // r10d
  unsigned int v19; // r14d
  __int64 v20; // rcx
  __int64 v21; // r8
  unsigned __int8 v22; // r8
  unsigned int v23; // r13d

  if ( *a2 != 0 && a2[1] != 0 ) /*0x103af55bf*/
  {
    v3 = a1[2]; /*0x103af55c5*/
    v4 = *a1; /*0x103af55c9*/
    v5 = a1[1]; /*0x103af55cc*/
    v6 = 3; /*0x103af55d0*/
    v7 = 0; /*0x103af55d5*/
    do /*0x103af56f1*/
    {
      v8 = -_bittest((const int *)&a3, --v6); /*0x103af55ea*/
      v9 = v7; /*0x103af55ec*/
      v10 = (((unsigned __int8)a2[(v7 >> 1) + 5] * (v5 - 1)) >> 8) + 1; /*0x103af560f*/
      v11 = v5 - v10; /*0x103af5612*/
      if ( ((a3 >> v6) & 1) == 0 ) /*0x103af5619*/
        v11 = v10; /*0x103af5619*/
      v12 = v4 + (v8 & v10); /*0x103af5620*/
      v13 = vpx_norm[v11]; /*0x103af562a*/
      v14 = v13 + v3; /*0x103af5632*/
      if ( (int)(v13 + v3) < 0 ) /*0x103af5635*/
      {
        v22 = vpx_norm[v11]; /*0x103af56bf*/
      }
      else
      {
        if ( ((v12 << ~(_BYTE)v3) & 0x80000000) != 0 ) /*0x103af5649*/
        {
          v15 = a1[3]; /*0x103af564b*/
          LODWORD(v16) = v15 - 1; /*0x103af5651*/
          if ( (int)(v15 - 1) >= 0 ) /*0x103af5654*/
          {
            while ( 1 ) /*0x103af5656*/
            {
              v16 = v15 - 1; /*0x103af5656*/
              v17 = *((_QWORD *)a1 + 2); /*0x103af565a*/
              if ( *(_BYTE *)(v17 + v16) != 0xFF ) /*0x103af5663*/
                break; /*0x103af5663*/
              *(_BYTE *)(v17 + v16) = 0; /*0x103af5665*/
              if ( (int)--v15 <= 0 ) /*0x103af566e*/
              {
                LODWORD(v16) = -1; /*0x103af5670*/
                break; /*0x103af5670*/
              }
            }
          }
          ++*(_BYTE *)(*((_QWORD *)a1 + 2) + (int)v16); /*0x103af5676*/
        }
        v18 = -v3; /*0x103af5684*/
        v19 = v12 >> (v3 + 24); /*0x103af5691*/
        v20 = *((_QWORD *)a1 + 2); /*0x103af5694*/
        v21 = a1[3]; /*0x103af5698*/
        a1[3] = v21 + 1; /*0x103af56a0*/
        *(_BYTE *)(v20 + v21) = v19; /*0x103af56a4*/
        v12 = (v12 << v18) & 0xFFFFFF; /*0x103af56ae*/
        v22 = v14; /*0x103af56b5*/
        v14 -= 8; /*0x103af56bb*/
      }
      v5 = (_DWORD)v11 << v13; /*0x103af56c5*/
      v23 = v12 << v22; /*0x103af56cb*/
      a1[2] = v14; /*0x103af56ce*/
      *a1 = v23; /*0x103af56d1*/
      a1[1] = v5; /*0x103af56d4*/
      v7 = vp9_segment_tree[v9 + ((a3 >> v6) & 1)]; /*0x103af56e5*/
      v4 = v23; /*0x103af56e9*/
      v3 = v14; /*0x103af56ec*/
    }
    while ( v6 != 0 ); /*0x103af56f1*/
  }
}

// Address: 0x103af5702 | Name: _write_skip
__int64 __fastcall write_skip(__int64 a1, __int64 a2, int a3, __int64 a4, __int64 a5)
{
  __int64 result; // rax
  __int64 v6; // r9
  __int64 v7; // rax
  __int64 v8; // rdx
  __int64 v9; // rsi
  __int64 v10; // rdi
  int v11; // edx
  int v12; // r9d
  int v13; // esi
  unsigned int v14; // r10d
  __int64 v15; // r9
  unsigned int v16; // r10d
  int v17; // edx
  int v18; // r11d
  int v19; // edi
  int v20; // ecx
  __int64 v21; // rbx
  __int64 v22; // r14
  unsigned int v23; // ebx
  __int64 v24; // rcx
  __int64 v25; // rsi
  unsigned __int8 v26; // si

  if ( *(_BYTE *)(a1 + 4536) == 0 || (result = 1, (*(_BYTE *)(a1 + 4LL * a3 + 4616) & 8) == 0) ) /*0x103af571b*/
  {
    v6 = *(_QWORD *)(a2 + 456); /*0x103af5721*/
    v7 = *(_QWORD *)(a2 + 464); /*0x103af5728*/
    if ( v7 != 0 ) /*0x103af5732*/
      v8 = *(char *)(v7 + 3); /*0x103af5734*/
    else
      v8 = 0; /*0x103af573b*/
    result = (unsigned int)*(char *)(a4 + 3); /*0x103af573d*/
    v9 = *(_QWORD *)(a1 + 4664); /*0x103af5741*/
    if ( v6 != 0 ) /*0x103af574d*/
      v10 = *(char *)(v6 + 3); /*0x103af574f*/
    else
      v10 = 0; /*0x103af5756*/
    v11 = *(unsigned __int8 *)(v9 + v8 + v10 + 1967); /*0x103af575b*/
    v12 = *(_DWORD *)(a5 + 4); /*0x103af5763*/
    v13 = *(_DWORD *)(a5 + 8); /*0x103af5767*/
    v14 = ((unsigned int)(v11 * (v12 - 1)) >> 8) + 1; /*0x103af5777*/
    v15 = v12 - v14; /*0x103af577a*/
    if ( *(_BYTE *)(a4 + 3) == 0 ) /*0x103af577f*/
    {
      v15 = v14; /*0x103af577f*/
      v14 = 0; /*0x103af5783*/
    }
    v16 = *(_DWORD *)a5 + v14; /*0x103af5787*/
    v17 = vpx_norm[v15]; /*0x103af5791*/
    v18 = v17 + v13; /*0x103af5799*/
    if ( v17 + v13 < 0 ) /*0x103af579c*/
    {
      v26 = vpx_norm[v15]; /*0x103af5826*/
    }
    else
    {
      v19 = -v13; /*0x103af57ab*/
      if ( ((v16 << ~(_BYTE)v13) & 0x80000000) != 0 ) /*0x103af57b8*/
      {
        v20 = *(_DWORD *)(a5 + 12); /*0x103af57ba*/
        LODWORD(v21) = v20 - 1; /*0x103af57c0*/
        if ( v20 - 1 >= 0 ) /*0x103af57c2*/
        {
          while ( 1 ) /*0x103af57c4*/
          {
            v21 = (unsigned int)(v20 - 1); /*0x103af57c4*/
            v22 = *(_QWORD *)(a5 + 16); /*0x103af57c7*/
            if ( *(_BYTE *)(v22 + v21) != 0xFF ) /*0x103af57d0*/
              break; /*0x103af57d0*/
            *(_BYTE *)(v22 + v21) = 0; /*0x103af57d2*/
            if ( --v20 <= 0 ) /*0x103af57db*/
            {
              LODWORD(v21) = -1; /*0x103af57dd*/
              break; /*0x103af57dd*/
            }
          }
        }
        ++*(_BYTE *)(*(_QWORD *)(a5 + 16) + (int)v21); /*0x103af57e2*/
      }
      v23 = v16 >> (v13 + 24); /*0x103af57f5*/
      v24 = *(_QWORD *)(a5 + 16); /*0x103af57f7*/
      v25 = *(unsigned int *)(a5 + 12); /*0x103af57fb*/
      *(_DWORD *)(a5 + 12) = v25 + 1; /*0x103af5803*/
      *(_BYTE *)(v24 + v25) = v23; /*0x103af5807*/
      v16 = (v16 << v19) & 0xFFFFFF; /*0x103af580f*/
      v26 = v18; /*0x103af5816*/
      v18 -= 8; /*0x103af581d*/
    }
    *(_DWORD *)(a5 + 8) = v18; /*0x103af5832*/
    *(_DWORD *)a5 = v16 << v26; /*0x103af5836*/
    *(_DWORD *)(a5 + 4) = (_DWORD)v15 << v17; /*0x103af5839*/
  }
  return result; /*0x103af583d*/
}

// Address: 0x103af583e | Name: _write_selected_tx_size
__int64 __fastcall write_selected_tx_size(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v3; // r8
  unsigned __int8 *v4; // rcx
  int v5; // r10d
  __int64 v6; // rsi
  int v7; // eax
  int v8; // r9d
  unsigned __int8 v9; // r11
  unsigned int v10; // eax
  __int64 v11; // rbx
  unsigned __int8 *v12; // rbx
  int v13; // r9d
  int v14; // edi
  unsigned int v15; // ecx
  __int64 v16; // r9
  unsigned int v17; // r15d
  unsigned int v18; // r15d
  int v19; // esi
  __int64 result; // rax
  int v21; // r8d
  int v22; // ecx
  __int64 v23; // r12
  __int64 v24; // r13
  unsigned int v25; // r12d
  __int64 v26; // rcx
  __int64 v27; // rdi
  unsigned __int8 v28; // di
  int v29; // r9d
  unsigned int v30; // r15d
  unsigned int v31; // esi
  __int64 v32; // r9
  unsigned int v33; // r12d
  unsigned int v34; // r12d
  int v35; // edi
  unsigned int v36; // esi
  int v37; // r8d
  int v38; // ecx
  __int64 v39; // r15
  __int64 v40; // r13
  unsigned int v41; // r15d
  __int64 v42; // rax
  __int64 v43; // rcx
  int v44; // r9d
  unsigned int v45; // r12d
  unsigned int v46; // ecx
  __int64 v47; // r9
  unsigned int v48; // r8d
  unsigned int v49; // r8d
  int v50; // r10d
  int v51; // edi
  int v52; // ecx
  __int64 v53; // r11
  __int64 v54; // rbx
  unsigned int v55; // r11d
  __int64 v56; // rcx
  __int64 v57; // rsi
  unsigned __int8 v58; // si

  v3 = *(_QWORD *)(a2 + 456); /*0x103af5845*/
  v4 = **(unsigned __int8 ***)(a2 + 448); /*0x103af584c*/
  v5 = max_txsize_lookup[*v4]; /*0x103af5859*/
  v6 = *(_QWORD *)(a2 + 464); /*0x103af585e*/
  v7 = v5; /*0x103af5865*/
  if ( v6 != 0 ) /*0x103af586b*/
  {
    v7 = max_txsize_lookup[*v4]; /*0x103af5871*/
    if ( *(_BYTE *)(v6 + 3) == 0 ) /*0x103af5874*/
      v7 = *(unsigned __int8 *)(v6 + 2); /*0x103af5876*/
  }
  v8 = v7; /*0x103af587a*/
  if ( v3 != 0 ) /*0x103af5880*/
  {
    v8 = max_txsize_lookup[*v4]; /*0x103af5887*/
    if ( *(_BYTE *)(v3 + 3) == 0 ) /*0x103af588a*/
      v8 = *(unsigned __int8 *)(v3 + 2); /*0x103af588c*/
  }
  if ( v6 == 0 ) /*0x103af58a1*/
    v7 = v8; /*0x103af58a1*/
  v9 = v4[2]; /*0x103af58a5*/
  v10 = v8 + v7; /*0x103af58a9*/
  v11 = *(_QWORD *)(a1 + 4664); /*0x103af58ac*/
  switch ( v5 ) /*0x103af58b7*/
  {
    case 3: /*0x103af58b7*/
      v12 = (unsigned __int8 *)(3LL * (v10 > 3) + v11 + 1955); /*0x103af58f5*/
      break;
    case 2: /*0x103af58b7*/
      v12 = (unsigned __int8 *)(v11 + 2LL * (v10 > 2) + 1961); /*0x103af58dd*/
      break;
    case 1: /*0x103af58b7*/
      v12 = (unsigned __int8 *)((v10 > 1) + v11 + 1965); /*0x103af58c8*/
      break;
    default:
      v12 = nullptr; /*0x103af58fe*/
      break;
  }
  v13 = *(_DWORD *)(a3 + 4); /*0x103af5903*/
  v14 = *(_DWORD *)(a3 + 8); /*0x103af5907*/
  v15 = (((unsigned int)*v12 * (v13 - 1)) >> 8) + 1; /*0x103af5914*/
  v16 = v13 - v15; /*0x103af5916*/
  v17 = 0; /*0x103af5919*/
  if ( v9 != 0 ) /*0x103af591f*/
    v17 = v15; /*0x103af5923*/
  else
    v16 = v15; /*0x103af591f*/
  v18 = *(_DWORD *)a3 + v17; /*0x103af5927*/
  v19 = vpx_norm[v16]; /*0x103af5931*/
  result = (unsigned int)(v19 + v14); /*0x103af5938*/
  if ( v19 + v14 < 0 ) /*0x103af593a*/
  {
    v28 = vpx_norm[v16]; /*0x103af59c0*/
  }
  else
  {
    v21 = -v14; /*0x103af5943*/
    if ( ((v18 << ~(_BYTE)v14) & 0x80000000) != 0 ) /*0x103af5953*/
    {
      v22 = *(_DWORD *)(a3 + 12); /*0x103af5955*/
      LODWORD(v23) = v22 - 1; /*0x103af595b*/
      if ( v22 - 1 >= 0 ) /*0x103af595e*/
      {
        while ( 1 ) /*0x103af5960*/
        {
          v23 = (unsigned int)(v22 - 1); /*0x103af5960*/
          v24 = *(_QWORD *)(a3 + 16); /*0x103af5964*/
          if ( *(_BYTE *)(v24 + v23) != 0xFF ) /*0x103af596e*/
            break; /*0x103af596e*/
          *(_BYTE *)(v24 + v23) = 0; /*0x103af5970*/
          if ( --v22 <= 0 ) /*0x103af597a*/
          {
            LODWORD(v23) = -1; /*0x103af597c*/
            break; /*0x103af597c*/
          }
        }
      }
      ++*(_BYTE *)(*(_QWORD *)(a3 + 16) + (int)v23); /*0x103af5982*/
    }
    v25 = v18 >> (v14 + 24); /*0x103af5996*/
    v26 = *(_QWORD *)(a3 + 16); /*0x103af5999*/
    v27 = *(unsigned int *)(a3 + 12); /*0x103af599d*/
    *(_DWORD *)(a3 + 12) = v27 + 1; /*0x103af59a4*/
    *(_BYTE *)(v26 + v27) = v25; /*0x103af59a8*/
    v18 = (v18 << v21) & 0xFFFFFF; /*0x103af59b2*/
    v28 = result; /*0x103af59b9*/
    result = (unsigned int)(result - 8); /*0x103af59bb*/
  }
  v29 = (_DWORD)v16 << v19; /*0x103af59c4*/
  v30 = v18 << v28; /*0x103af59c9*/
  *(_DWORD *)(a3 + 8) = result; /*0x103af59cc*/
  *(_DWORD *)a3 = v30; /*0x103af59cf*/
  *(_DWORD *)(a3 + 4) = v29; /*0x103af59d2*/
  if ( v9 != 0 && (unsigned __int8)v5 >= 2u ) /*0x103af59e3*/
  {
    v31 = (((unsigned int)v12[1] * (v29 - 1)) >> 8) + 1; /*0x103af59f7*/
    v32 = v29 - v31; /*0x103af59f9*/
    v33 = 0; /*0x103af59fc*/
    if ( v9 == 1 ) /*0x103af5a03*/
      v32 = v31; /*0x103af5a03*/
    else
      v33 = v31; /*0x103af5a07*/
    v34 = v30 + v33; /*0x103af5a0b*/
    v35 = vpx_norm[v32]; /*0x103af5a0e*/
    v36 = v35 + result; /*0x103af5a15*/
    if ( v35 + (int)result < 0 ) /*0x103af5a17*/
    {
      result = vpx_norm[v32]; /*0x103af5a9d*/
    }
    else
    {
      v37 = -(int)result; /*0x103af5a20*/
      if ( ((v34 << ~(_BYTE)result) & 0x80000000) != 0 ) /*0x103af5a30*/
      {
        v38 = *(_DWORD *)(a3 + 12); /*0x103af5a32*/
        LODWORD(v39) = v38 - 1; /*0x103af5a38*/
        if ( v38 - 1 >= 0 ) /*0x103af5a3b*/
        {
          while ( 1 ) /*0x103af5a3d*/
          {
            v39 = (unsigned int)(v38 - 1); /*0x103af5a3d*/
            v40 = *(_QWORD *)(a3 + 16); /*0x103af5a41*/
            if ( *(_BYTE *)(v40 + v39) != 0xFF ) /*0x103af5a4b*/
              break; /*0x103af5a4b*/
            *(_BYTE *)(v40 + v39) = 0; /*0x103af5a4d*/
            if ( --v38 <= 0 ) /*0x103af5a57*/
            {
              LODWORD(v39) = -1; /*0x103af5a59*/
              break; /*0x103af5a59*/
            }
          }
        }
        ++*(_BYTE *)(*(_QWORD *)(a3 + 16) + (int)v39); /*0x103af5a5f*/
      }
      v41 = v34 >> (result + 24); /*0x103af5a71*/
      v42 = *(_QWORD *)(a3 + 16); /*0x103af5a74*/
      v43 = *(unsigned int *)(a3 + 12); /*0x103af5a78*/
      *(_DWORD *)(a3 + 12) = v43 + 1; /*0x103af5a7f*/
      *(_BYTE *)(v42 + v43) = v41; /*0x103af5a83*/
      v34 = (v34 << v37) & 0xFFFFFF; /*0x103af5a8d*/
      result = v36; /*0x103af5a94*/
      v36 -= 8; /*0x103af5a99*/
    }
    v44 = (_DWORD)v32 << v35; /*0x103af5aa1*/
    v45 = v34 << result; /*0x103af5aa6*/
    *(_DWORD *)(a3 + 8) = v36; /*0x103af5aa9*/
    *(_DWORD *)a3 = v45; /*0x103af5aac*/
    *(_DWORD *)(a3 + 4) = v44; /*0x103af5aaf*/
    if ( v9 != 1 && (unsigned __int8)v5 >= 3u ) /*0x103af5ac1*/
    {
      v46 = (((unsigned int)v12[2] * (v44 - 1)) >> 8) + 1; /*0x103af5ad5*/
      v47 = v44 - v46; /*0x103af5ad7*/
      v48 = 0; /*0x103af5ada*/
      if ( v9 == 2 ) /*0x103af5ae1*/
        v47 = v46; /*0x103af5ae1*/
      else
        v48 = v46; /*0x103af5ae5*/
      v49 = v45 + v48; /*0x103af5ae9*/
      result = vpx_norm[v47]; /*0x103af5aec*/
      v50 = result + v36; /*0x103af5af4*/
      if ( (int)(result + v36) < 0 ) /*0x103af5af7*/
      {
        v58 = vpx_norm[v47]; /*0x103af5b77*/
      }
      else
      {
        v51 = -v36; /*0x103af5afb*/
        if ( ((v49 << ~(_BYTE)v36) & 0x80000000) != 0 ) /*0x103af5b0a*/
        {
          v52 = *(_DWORD *)(a3 + 12); /*0x103af5b0c*/
          LODWORD(v53) = v52 - 1; /*0x103af5b12*/
          if ( v52 - 1 >= 0 ) /*0x103af5b15*/
          {
            while ( 1 ) /*0x103af5b17*/
            {
              v53 = (unsigned int)(v52 - 1); /*0x103af5b17*/
              v54 = *(_QWORD *)(a3 + 16); /*0x103af5b1b*/
              if ( *(_BYTE *)(v54 + v53) != 0xFF ) /*0x103af5b24*/
                break; /*0x103af5b24*/
              *(_BYTE *)(v54 + v53) = 0; /*0x103af5b26*/
              if ( --v52 <= 0 ) /*0x103af5b2f*/
              {
                LODWORD(v53) = -1; /*0x103af5b31*/
                break; /*0x103af5b31*/
              }
            }
          }
          ++*(_BYTE *)(*(_QWORD *)(a3 + 16) + (int)v53); /*0x103af5b37*/
        }
        v55 = v49 >> (v36 + 24); /*0x103af5b4b*/
        v56 = *(_QWORD *)(a3 + 16); /*0x103af5b4e*/
        v57 = *(unsigned int *)(a3 + 12); /*0x103af5b52*/
        *(_DWORD *)(a3 + 12) = v57 + 1; /*0x103af5b58*/
        *(_BYTE *)(v56 + v57) = v55; /*0x103af5b5b*/
        v49 = (v49 << v51) & 0xFFFFFF; /*0x103af5b64*/
        v58 = v50; /*0x103af5b6b*/
        v50 -= 8; /*0x103af5b72*/
      }
      *(_DWORD *)(a3 + 8) = v50; /*0x103af5b83*/
      *(_DWORD *)a3 = v49 << v58; /*0x103af5b87*/
      *(_DWORD *)(a3 + 4) = (_DWORD)v47 << result; /*0x103af5b8a*/
    }
  }
  return result; /*0x103af5b98*/
}

// Address: 0x103af5b99 | Name: _write_intra_mode
__int64 __fastcall write_intra_mode(unsigned int *a1, int a2, __int64 a3)
{
  unsigned int v3; // edx
  __int64 result; // rax
  unsigned int v5; // esi
  unsigned int v6; // r8d
  unsigned int v7; // r11d
  char v8; // r9
  int v9; // ecx
  int v10; // r12d
  unsigned int v11; // r13d
  __int64 v12; // r11
  unsigned int v13; // r13d
  int v14; // r8d
  unsigned int v15; // ebx
  unsigned int v16; // ecx
  __int64 v17; // r9
  __int64 v18; // r14
  int v19; // r9d
  unsigned int v20; // r14d
  __int64 v21; // rcx
  __int64 v22; // rsi
  unsigned __int8 v23; // si
  unsigned int v24; // r13d

  v3 = intra_mode_encodings[2 * a2]; /*0x103af5bb3*/
  LODWORD(result) = intra_mode_encodings[2 * a2 + 1]; /*0x103af5bb6*/
  v5 = a1[2]; /*0x103af5bba*/
  v6 = *a1; /*0x103af5bbd*/
  v7 = a1[1]; /*0x103af5bc0*/
  v8 = 0; /*0x103af5bc4*/
  do /*0x103af5cd8*/
  {
    result = (unsigned int)(result - 1); /*0x103af5bc7*/
    v9 = -_bittest((const int *)&v3, result); /*0x103af5bd9*/
    v10 = v8; /*0x103af5bdb*/
    v11 = ((*(unsigned __int8 *)(a3 + (v8 >> 1)) * (v7 - 1)) >> 8) + 1; /*0x103af5bfd*/
    v12 = v7 - v11; /*0x103af5c00*/
    if ( ((v3 >> result) & 1) == 0 ) /*0x103af5c07*/
      v12 = v11; /*0x103af5c07*/
    v13 = v6 + (v9 & v11); /*0x103af5c0e*/
    v14 = vpx_norm[v12]; /*0x103af5c18*/
    v15 = v14 + v5; /*0x103af5c1f*/
    if ( (int)(v14 + v5) < 0 ) /*0x103af5c22*/
    {
      v23 = vpx_norm[v12]; /*0x103af5ca8*/
    }
    else
    {
      if ( ((v13 << ~(_BYTE)v5) & 0x80000000) != 0 ) /*0x103af5c35*/
      {
        v16 = a1[3]; /*0x103af5c37*/
        LODWORD(v17) = v16 - 1; /*0x103af5c3d*/
        if ( (int)(v16 - 1) >= 0 ) /*0x103af5c40*/
        {
          while ( 1 ) /*0x103af5c42*/
          {
            v17 = v16 - 1; /*0x103af5c42*/
            v18 = *((_QWORD *)a1 + 2); /*0x103af5c46*/
            if ( *(_BYTE *)(v18 + v17) != 0xFF ) /*0x103af5c4f*/
              break; /*0x103af5c4f*/
            *(_BYTE *)(v18 + v17) = 0; /*0x103af5c51*/
            if ( (int)--v16 <= 0 ) /*0x103af5c5a*/
            {
              LODWORD(v17) = -1; /*0x103af5c5c*/
              break; /*0x103af5c5c*/
            }
          }
        }
        ++*(_BYTE *)(*((_QWORD *)a1 + 2) + (int)v17); /*0x103af5c62*/
      }
      v19 = -v5; /*0x103af5c70*/
      v20 = v13 >> (v5 + 24); /*0x103af5c7c*/
      v21 = *((_QWORD *)a1 + 2); /*0x103af5c7f*/
      v22 = a1[3]; /*0x103af5c83*/
      a1[3] = v22 + 1; /*0x103af5c8a*/
      *(_BYTE *)(v21 + v22) = v20; /*0x103af5c8e*/
      v13 = (v13 << v19) & 0xFFFFFF; /*0x103af5c98*/
      v23 = v15; /*0x103af5c9f*/
      v15 -= 8; /*0x103af5ca4*/
    }
    v7 = (_DWORD)v12 << v14; /*0x103af5cae*/
    v24 = v13 << v23; /*0x103af5cb3*/
    a1[2] = v15; /*0x103af5cb6*/
    *a1 = v24; /*0x103af5cb9*/
    a1[1] = v7; /*0x103af5cbc*/
    v8 = vp9_intra_mode_tree[v10 + ((v3 >> result) & 1)]; /*0x103af5ccd*/
    v6 = v24; /*0x103af5cd1*/
    v5 = v15; /*0x103af5cd4*/
  }
  while ( (_DWORD)result != 0 ); /*0x103af5cd8*/
  return result; /*0x103af5cde*/
}

// Address: 0x103af5ce9 | Name: _write_inter_mode
__int64 __fastcall write_inter_mode(unsigned int *a1, int a2, __int64 a3)
{
  unsigned int v3; // edx
  __int64 result; // rax
  unsigned int v5; // esi
  unsigned int v6; // r8d
  unsigned int v7; // r11d
  char v8; // r9
  int v9; // ecx
  int v10; // r12d
  unsigned int v11; // r13d
  __int64 v12; // r11
  unsigned int v13; // r13d
  int v14; // r8d
  unsigned int v15; // ebx
  unsigned int v16; // ecx
  __int64 v17; // r9
  __int64 v18; // r14
  int v19; // r9d
  unsigned int v20; // r14d
  __int64 v21; // rcx
  __int64 v22; // rsi
  unsigned __int8 v23; // si
  unsigned int v24; // r13d

  v3 = inter_mode_encodings[2 * a2 - 20]; /*0x103af5d03*/
  LODWORD(result) = inter_mode_encodings[2 * a2 - 19]; /*0x103af5d07*/
  v5 = a1[2]; /*0x103af5d0b*/
  v6 = *a1; /*0x103af5d0e*/
  v7 = a1[1]; /*0x103af5d11*/
  v8 = 0; /*0x103af5d15*/
  do /*0x103af5e29*/
  {
    result = (unsigned int)(result - 1); /*0x103af5d18*/
    v9 = -_bittest((const int *)&v3, result); /*0x103af5d2a*/
    v10 = v8; /*0x103af5d2c*/
    v11 = ((*(unsigned __int8 *)(a3 + (v8 >> 1)) * (v7 - 1)) >> 8) + 1; /*0x103af5d4e*/
    v12 = v7 - v11; /*0x103af5d51*/
    if ( ((v3 >> result) & 1) == 0 ) /*0x103af5d58*/
      v12 = v11; /*0x103af5d58*/
    v13 = v6 + (v9 & v11); /*0x103af5d5f*/
    v14 = vpx_norm[v12]; /*0x103af5d69*/
    v15 = v14 + v5; /*0x103af5d70*/
    if ( (int)(v14 + v5) < 0 ) /*0x103af5d73*/
    {
      v23 = vpx_norm[v12]; /*0x103af5df9*/
    }
    else
    {
      if ( ((v13 << ~(_BYTE)v5) & 0x80000000) != 0 ) /*0x103af5d86*/
      {
        v16 = a1[3]; /*0x103af5d88*/
        LODWORD(v17) = v16 - 1; /*0x103af5d8e*/
        if ( (int)(v16 - 1) >= 0 ) /*0x103af5d91*/
        {
          while ( 1 ) /*0x103af5d93*/
          {
            v17 = v16 - 1; /*0x103af5d93*/
            v18 = *((_QWORD *)a1 + 2); /*0x103af5d97*/
            if ( *(_BYTE *)(v18 + v17) != 0xFF ) /*0x103af5da0*/
              break; /*0x103af5da0*/
            *(_BYTE *)(v18 + v17) = 0; /*0x103af5da2*/
            if ( (int)--v16 <= 0 ) /*0x103af5dab*/
            {
              LODWORD(v17) = -1; /*0x103af5dad*/
              break; /*0x103af5dad*/
            }
          }
        }
        ++*(_BYTE *)(*((_QWORD *)a1 + 2) + (int)v17); /*0x103af5db3*/
      }
      v19 = -v5; /*0x103af5dc1*/
      v20 = v13 >> (v5 + 24); /*0x103af5dcd*/
      v21 = *((_QWORD *)a1 + 2); /*0x103af5dd0*/
      v22 = a1[3]; /*0x103af5dd4*/
      a1[3] = v22 + 1; /*0x103af5ddb*/
      *(_BYTE *)(v21 + v22) = v20; /*0x103af5ddf*/
      v13 = (v13 << v19) & 0xFFFFFF; /*0x103af5de9*/
      v23 = v15; /*0x103af5df0*/
      v15 -= 8; /*0x103af5df5*/
    }
    v7 = (_DWORD)v12 << v14; /*0x103af5dff*/
    v24 = v13 << v23; /*0x103af5e04*/
    a1[2] = v15; /*0x103af5e07*/
    *a1 = v24; /*0x103af5e0a*/
    a1[1] = v7; /*0x103af5e0d*/
    v8 = vp9_inter_mode_tree[v10 + ((v3 >> result) & 1)]; /*0x103af5e1e*/
    v6 = v24; /*0x103af5e22*/
    v5 = v15; /*0x103af5e25*/
  }
  while ( (_DWORD)result != 0 ); /*0x103af5e29*/
  return result; /*0x103af5e2f*/
}

// Address: 0x103b089e1 | Name: _write_mv_update
__int64 __fastcall write_mv_update(__int64 a1, __int64 a2, __int64 a3, int a4, __int64 a5)
{
  _BYTE *v8; // r12
  __int64 v9; // r14
  _BYTE v11[264]; // [rsp+0h] [rbp-130h] BYREF

  v8 = v11; /*0x103b08a0a*/
  vp9_tree_probs_from_distribution(a1, a2: (__int64)v11, a3); /*0x103b08a14*/
  if ( a4 >= 2 ) /*0x103b08a1d*/
  {
    v9 = (unsigned int)(a4 - 1); /*0x103b08a1f*/
    do /*0x103b08a3a*/
    {
      update_mv(a1: a5, a2: v8, a3: a2++); /*0x103b08a2b*/
      v8 += 8; /*0x103b08a33*/
      --v9; /*0x103b08a37*/
    }
    while ( v9 != 0 ); /*0x103b08a3a*/
  }
  return __stack_chk_guard; /*0x103b08a4c*/
}

// Address: 0x103bcd17f | Name: __ZN6webrtceqERKNS_14SdpAudioFormatES2_
char __fastcall webrtc::operator==(unsigned __int8 *a1, unsigned __int8 *a2)
{
  unsigned int v4; // esi
  absl::lts_20240116::strings_internal *v5; // rdi
  const char *v6; // rsi
  unsigned int v7; // ecx
  const char *v8; // rdx
  unsigned __int64 v9; // rcx
  unsigned __int8 *v10; // r15
  unsigned __int8 *v11; // rbx
  _QWORD *v12; // r12
  char result; // al
  unsigned __int8 *v14; // rcx
  unsigned __int8 *v15; // rdx
  bool v16; // zf
  _QWORD *v17; // rdx
  _QWORD *v18; // rcx
  char v19[33]; // [rsp+Fh] [rbp-21h] BYREF

  v4 = *a1; /*0x103bcd194*/
  if ( (v4 & 1) != 0 ) /*0x103bcd19b*/
  {
    v5 = *((absl::lts_20240116::strings_internal **)a1 + 2); /*0x103bcd19d*/
    v6 = *((const char **)a1 + 1); /*0x103bcd1a1*/
  }
  else
  {
    v5 = (absl::lts_20240116::strings_internal *)(a1 + 1); /*0x103bcd1a7*/
    v6 = (const char *)(v4 >> 1); /*0x103bcd1ab*/
  }
  v7 = *a2; /*0x103bcd1ad*/
  if ( (v7 & 1) != 0 ) /*0x103bcd1b4*/
  {
    v8 = *((const char **)a2 + 2); /*0x103bcd1b6*/
    v9 = *((_QWORD *)a2 + 1); /*0x103bcd1ba*/
  }
  else
  {
    v8 = (const char *)(a2 + 1); /*0x103bcd1c0*/
    v9 = v7 >> 1; /*0x103bcd1c4*/
  }
  if ( !absl::lts_20240116::EqualsIgnoreCase(a1: v5, a2: v6, a3: v8, a4: v9) /*0x103bcd1f6*/
    || *((_DWORD *)a1 + 6) != *((_DWORD *)a2 + 6)
    || *((_QWORD *)a1 + 4) != *((_QWORD *)a2 + 4)
    || *((_QWORD *)a1 + 7) != *((_QWORD *)a2 + 7) )
  {
    return 0; /*0x103bcd283*/
  }
  v10 = *((unsigned __int8 **)a1 + 5); /*0x103bcd1f8*/
  v11 = a1 + 48; /*0x103bcd1fc*/
  if ( v10 != v11 ) /*0x103bcd203*/
  {
    v12 = *((_QWORD **)a2 + 5); /*0x103bcd205*/
    while ( 1 ) /*0x103bcd219*/
    {
      result = std::__equal_to::operator()[abi:ne200100]<std::pair<std::string const,std::string>,std::pair<std::string const,std::string>>( /*0x103bcd219*/
                 a1: v19,
                 a2: v10 + 32,
                 a3: v12 + 4);
      if ( result == 0 ) /*0x103bcd220*/
        break; /*0x103bcd220*/
      v14 = *((unsigned __int8 **)v10 + 1); /*0x103bcd222*/
      v15 = v10; /*0x103bcd226*/
      if ( v14 != nullptr ) /*0x103bcd22c*/
      {
        do /*0x103bcd237*/
        {
          v10 = v14; /*0x103bcd22e*/
          v14 = *(unsigned __int8 **)v14; /*0x103bcd231*/
        }
        while ( v14 != nullptr ); /*0x103bcd237*/
      }
      else
      {
        do /*0x103bcd245*/
        {
          v10 = *((unsigned __int8 **)v15 + 2); /*0x103bcd23b*/
          v16 = *(_QWORD *)v10 == (_QWORD)v15; /*0x103bcd23f*/
          v15 = v10; /*0x103bcd242*/
        }
        while ( !v16 ); /*0x103bcd245*/
      }
      v17 = (_QWORD *)v12[1]; /*0x103bcd247*/
      if ( v17 != nullptr ) /*0x103bcd24f*/
      {
        do /*0x103bcd25a*/
        {
          v18 = v17; /*0x103bcd251*/
          v17 = (_QWORD *)*v17; /*0x103bcd254*/
        }
        while ( v17 != nullptr ); /*0x103bcd25a*/
      }
      else
      {
        do /*0x103bcd269*/
        {
          v18 = (_QWORD *)v12[2]; /*0x103bcd25e*/
          v16 = *v18 == (_QWORD)v12; /*0x103bcd263*/
          v12 = v18; /*0x103bcd266*/
        }
        while ( !v16 ); /*0x103bcd269*/
      }
      v12 = v18; /*0x103bcd26b*/
      if ( v10 == v11 ) /*0x103bcd271*/
        return result; /*0x103bcd271*/
    }
    return 0; /*0x103bcd220*/
  }
  return 1; /*0x103bcd277*/
}

// Address: 0x103bd7dfc | Name: __ZN6webrtceqERKNS_13RtpPacketInfoES2_
bool __fastcall webrtc::operator==(__int64 a1, __int64 a2)
{
  const void *v4; // rdi
  size_t v5; // rdx
  const void *v6; // rsi
  unsigned __int16 v7; // ax
  unsigned __int16 v8; // cx
  bool result; // al
  unsigned __int8 v10; // cl
  bool v11; // al
  unsigned __int8 v12; // cl
  unsigned __int8 v13; // cl

  if ( *(_DWORD *)a1 != *(_DWORD *)a2 ) /*0x103bd7e00*/
    return false; /*0x103bd7e7a*/
  v4 = *(const void **)(a1 + 8); /*0x103bd7e0f*/
  v5 = *(_QWORD *)(a1 + 16) - (_QWORD)v4; /*0x103bd7e17*/
  v6 = *(const void **)(a2 + 8); /*0x103bd7e1a*/
  if ( v5 != *(_QWORD *)(a2 + 16) - (_QWORD)v6 /*0x103bd7e48*/
    || memcmp(__s1: v4, __s2: v6, __n: v5) != 0
    || *(_DWORD *)(a1 + 32) != *(_DWORD *)(a2 + 32)
    || *(_QWORD *)(a1 + 40) != *(_QWORD *)(a2 + 40) )
  {
    return false; /*0x103bd7e48*/
  }
  v7 = *(_WORD *)(a1 + 48); /*0x103bd7e4a*/
  v8 = *(_WORD *)(a2 + 48); /*0x103bd7e54*/
  if ( (v7 & 0x100) == 0 || HIBYTE(v7) != HIBYTE(v8) ) /*0x103bd7e6c*/
  {
    if ( HIBYTE(v7) != HIBYTE(v8) ) /*0x103bd7e7e*/
      return false; /*0x103bd7e7e*/
  }
  else if ( (_BYTE)v7 != (_BYTE)v8 ) /*0x103bd7e74*/
  {
    return false; /*0x103bd7e74*/
  }
  v10 = *(_BYTE *)(a1 + 80); /*0x103bd7e80*/
  v11 = v10 == *(_BYTE *)(a2 + 80); /*0x103bd7e87*/
  if ( (v11 & v10) != 1 ) /*0x103bd7e8f*/
    goto LABEL_17; /*0x103bd7e8f*/
  if ( *(_QWORD *)(a1 + 56) != *(_QWORD *)(a2 + 56) ) /*0x103bd7e99*/
    return false; /*0x103bd7eb6*/
  v12 = *(_BYTE *)(a1 + 72); /*0x103bd7e9b*/
  v11 = v12 == *(_BYTE *)(a2 + 72); /*0x103bd7ea2*/
  if ( (v11 & v12) != 1 ) /*0x103bd7eaa*/
  {
LABEL_17:
    if ( !v11 ) /*0x103bd7ebf*/
      return false; /*0x103bd7ebf*/
    goto LABEL_18; /*0x103bd7ebf*/
  }
  if ( *(_QWORD *)(a1 + 64) != *(_QWORD *)(a2 + 64) ) /*0x103bd7eb4*/
    return false; /*0x103bd7eb4*/
LABEL_18:
  v13 = *(_BYTE *)(a1 + 96); /*0x103bd7ec1*/
  result = v13 == *(_BYTE *)(a2 + 96); /*0x103bd7ec8*/
  if ( (result & v13) == 1 ) /*0x103bd7ed0*/
    return *(_QWORD *)(a1 + 88) == *(_QWORD *)(a2 + 88); /*0x103bd7eda*/
  return result; /*0x103bd7e7a*/
}

// Address: 0x103bec40c | Name: __ZN6webrtceqERKNS_14SdpVideoFormatES2_
bool __fastcall webrtc::operator==(_QWORD *a1, _QWORD *a2)
{
  __int64 v2; // rax
  unsigned int v5; // eax
  size_t v6; // rdx
  unsigned int v7; // ecx
  __int64 v8; // rsi
  char *v9; // rdi
  char *v10; // rsi
  _QWORD *v11; // r13
  _QWORD *v12; // r15
  _QWORD *v13; // rax
  _QWORD *v14; // rcx
  bool v15; // zf
  _QWORD *v16; // rcx
  _QWORD *v17; // rax
  _BYTE v19[41]; // [rsp+1h] [rbp-29h] BYREF

  v19[0] = HIBYTE(v2); /*0x103bec419*/
  v5 = *(unsigned __int8 *)a1; /*0x103bec420*/
  if ( (v5 & 1) != 0 ) /*0x103bec425*/
    v6 = a1[1]; /*0x103bec427*/
  else
    v6 = v5 >> 1; /*0x103bec42f*/
  v7 = *(unsigned __int8 *)a2; /*0x103bec431*/
  if ( (v7 & 1) != 0 ) /*0x103bec437*/
    v8 = a2[1]; /*0x103bec439*/
  else
    v8 = v7 >> 1; /*0x103bec441*/
  if ( v6 == v8 )
  {
    v9 = (v5 & 1) != 0 ? (char *)a1[2] : (char *)a1 + 1;
    v10 = (v7 & 1) != 0 ? (char *)a2[2] : (char *)a2 + 1;
    if ( memcmp(__s1: v9, __s2: v10, __n: v6) == 0 && a1[5] == a2[5] ) /*0x103bec47e*/
    {
      v11 = (_QWORD *)a1[3]; /*0x103bec484*/
      if ( v11 == a1 + 4 ) /*0x103bec48f*/
        return absl::lts_20240116::operator==<webrtc::ScalabilityMode,34ul,std::allocator<webrtc::ScalabilityMode>>( /*0x103bec50d*/
                 a1: a1 + 6,
                 a2: a2 + 6);
      v12 = (_QWORD *)a2[3]; /*0x103bec491*/
      while ( (unsigned __int8)std::__equal_to::operator()[abi:ne200100]<std::pair<std::string const,std::string>,std::pair<std::string const,std::string>>( /*0x103bec4a8*/
                                 a1: v19,
                                 a2: v11 + 4,
                                 a3: v12 + 4) != 0 )
      {
        v13 = (_QWORD *)v11[1]; /*0x103bec4aa*/
        v14 = v11; /*0x103bec4ae*/
        if ( v13 != nullptr ) /*0x103bec4b4*/
        {
          do /*0x103bec4bf*/
          {
            v11 = v13; /*0x103bec4b6*/
            v13 = (_QWORD *)*v13; /*0x103bec4b9*/
          }
          while ( v13 != nullptr ); /*0x103bec4bf*/
        }
        else
        {
          do /*0x103bec4ce*/
          {
            v11 = (_QWORD *)v14[2]; /*0x103bec4c3*/
            v15 = *v11 == (_QWORD)v14; /*0x103bec4c7*/
            v14 = v11; /*0x103bec4cb*/
          }
          while ( !v15 ); /*0x103bec4ce*/
        }
        v16 = (_QWORD *)v12[1]; /*0x103bec4d0*/
        if ( v16 != nullptr ) /*0x103bec4d7*/
        {
          do /*0x103bec4e2*/
          {
            v17 = v16; /*0x103bec4d9*/
            v16 = (_QWORD *)*v16; /*0x103bec4dc*/
          }
          while ( v16 != nullptr ); /*0x103bec4e2*/
        }
        else
        {
          do /*0x103bec4f0*/
          {
            v17 = (_QWORD *)v12[2]; /*0x103bec4e6*/
            v15 = *v17 == (_QWORD)v12; /*0x103bec4ea*/
            v12 = v17; /*0x103bec4ed*/
          }
          while ( !v15 ); /*0x103bec4f0*/
        }
        v12 = v17; /*0x103bec4f2*/
        if ( v11 == a1 + 4 ) /*0x103bec4f8*/
          return absl::lts_20240116::operator==<webrtc::ScalabilityMode,34ul,std::allocator<webrtc::ScalabilityMode>>( /*0x103bec4f8*/
                   a1: a1 + 6,
                   a2: a2 + 6);
      }
    }
  }
  return false; /*0x103bec515*/
}

// Address: 0x103c25508 | Name: _WebRtcSpl_AutoCorrelation
__int64 __fastcall WebRtcSpl_AutoCorrelation(__int64 a1, unsigned __int64 a2, __int64 a3, _DWORD *a4, unsigned int *a5)
{
  __int16 v8; // ax
  __int16 v9; // dx
  unsigned int v10; // edx
  unsigned int v11; // ecx
  int v12; // eax
  int v13; // edx
  unsigned int v14; // ecx
  __int64 result; // rax
  __int64 v16; // rdx
  __int64 v17; // rsi
  __m128i v18; // xmm0
  __int64 v19; // rdi
  int v20; // r8d
  unsigned __int64 v21; // r9
  __m128i v22; // xmm2
  __m128i v23; // xmm2
  unsigned __int64 v24; // r11

  v8 = ((__int64 (__fastcall *)(__int64, __int64))WebRtcSpl_MaxAbsValueW16[0])(a1, a2); /*0x103c25531*/
  if ( v8 != 0 ) /*0x103c25536*/
  {
    v9 = 32; /*0x103c25540*/
    if ( (_DWORD)a2 != 0 ) /*0x103c25548*/
    {
      _BitScanReverse(&v10, a2); /*0x103c2554a*/
      v9 = v10 ^ 0x1F; /*0x103c2554e*/
    }
    _BitScanReverse(&v11, v8 * v8); /*0x103c25556*/
    v12 = (unsigned __int16)(32 - v9); /*0x103c2555e*/
    v13 = (__int16)((v11 ^ 0x1F) - 1); /*0x103c25561*/
    v14 = 0; /*0x103c25568*/
    if ( (__int16)v13 <= (__int16)v12 ) /*0x103c2556d*/
      v14 = v12 - v13; /*0x103c2556d*/
  }
  else
  {
    v14 = 0; /*0x103c25572*/
  }
  result = a3 + 1; /*0x103c25578*/
  if ( a3 != -1 ) /*0x103c2557b*/
  {
    v16 = 3; /*0x103c25585*/
    v17 = 0; /*0x103c2558a*/
    v18 = _mm_cvtepu32_epi64(_mm_cvtsi32_si128(v14)); /*0x103c2558c*/
    v19 = 0; /*0x103c25591*/
    do /*0x103c2562d*/
    {
      if ( v19 + 3 >= a2 ) /*0x103c2559a*/
      {
        v21 = 0; /*0x103c255e2*/
        v20 = 0; /*0x103c255e5*/
      }
      else
      {
        v20 = 0; /*0x103c255a0*/
        v21 = 0; /*0x103c255a3*/
        do /*0x103c255de*/
        {
          v22 = _mm_sra_epi32( /*0x103c255b9*/
                  _mm_madd_epi16(
                    _mm_cvtepu16_epi32(*(__m64 *)(v17 + a1 + 2 * v21)),
                    _mm_cvtepu16_epi32(*(__m64 *)(a1 + 2 * v21))),
                  v18);
          v23 = _mm_hadd_epi32(v22, v22); /*0x103c255bd*/
          v20 += _mm_cvtsi128_si32(_mm_hadd_epi32(v23, v23)); /*0x103c255cc*/
          v24 = v16 + v21 + 4; /*0x103c255d3*/
          v21 += 4LL; /*0x103c255d7*/
        }
        while ( v24 < a2 ); /*0x103c255de*/
      }
      for ( ; v21 < a2 - v19; ++v21 ) /*0x103c255f1*/
        v20 += (*(__int16 *)(a1 + 2 * v21) * *(__int16 *)(v17 + a1 + 2 * v21)) >> v14; /*0x103c25609*/
      *a4++ = v20; /*0x103c25614*/
      ++v16; /*0x103c2561f*/
      v17 += 2; /*0x103c25622*/
    }
    while ( v19++ != a3 ); /*0x103c2562d*/
  }
  *a5 = v14; /*0x103c25637*/
  return result; /*0x103c25639*/
}

// Address: 0x103c25648 | Name: _WebRtcSpl_FilterAR
unsigned __int64 __fastcall WebRtcSpl_FilterAR(
        __int64 a1,
        unsigned __int64 a2,
        __int16 *a3,
        __int64 a4,
        __int16 *a5,
        unsigned __int64 a6,
        __int16 *a7,
        __int64 a8,
        __int64 a9)
{
  unsigned __int64 result; // rax
  __int64 v11; // r11
  unsigned __int64 v12; // r13
  __int64 v13; // rsi
  __int64 v14; // rdi
  int v15; // r15d
  unsigned __int64 v16; // r12
  __int64 v17; // rsi
  __int64 v18; // r12
  int v19; // edi
  __int64 v20; // rcx
  __int16 *v21; // r10
  int v22; // edx
  __int64 v23; // rsi
  __int64 v24; // r10
  unsigned __int64 v25; // r9
  int v26; // ecx
  unsigned __int64 v27; // rcx
  int v28; // edi
  __int16 v29; // si
  __int16 v30; // cx
  __int64 v31; // rsi
  unsigned __int64 v32; // rcx
  unsigned __int64 v33; // rdi
  char *v34; // r8
  __int64 i; // rdx
  __int64 v36; // rbx
  __int64 v37; // r15
  __int16 *v38; // [rsp+0h] [rbp-70h]
  _WORD *v39; // [rsp+8h] [rbp-68h]
  _WORD *v40; // [rsp+10h] [rbp-60h]
  unsigned __int64 v41; // [rsp+18h] [rbp-58h]

  result = a4; /*0x103c2565d*/
  v11 = a9; /*0x103c25667*/
  if ( a4 != 0 ) /*0x103c25676*/
  {
    v12 = 0; /*0x103c25693*/
    v13 = a9; /*0x103c25696*/
    v14 = a8; /*0x103c25699*/
    do /*0x103c257b1*/
    {
      v40 = (_WORD *)v14; /*0x103c2569d*/
      v39 = (_WORD *)v13; /*0x103c256a1*/
      v15 = *a3 << 12; /*0x103c256a9*/
      v16 = a2; /*0x103c256b4*/
      v41 = v12 + 1; /*0x103c256b7*/
      if ( v12 < a2 ) /*0x103c256bb*/
        v16 = v12 + 1; /*0x103c256bb*/
      v38 = a3; /*0x103c256c3*/
      if ( v16 < 2 ) /*0x103c256c7*/
      {
        v19 = 0; /*0x103c25722*/
        v23 = a1 + 2; /*0x103c25724*/
      }
      else
      {
        v17 = 2 * v16; /*0x103c256d8*/
        v18 = -(__int64)v16; /*0x103c256dc*/
        v19 = 0; /*0x103c256df*/
        v20 = -1; /*0x103c256e1*/
        v21 = (__int16 *)(a1 + 2); /*0x103c256e8*/
        do /*0x103c25712*/
        {
          v22 = *v21; /*0x103c256ec*/
          v15 -= v22 * *(__int16 *)(a8 + 2LL * (int)v12 + 2 * v20); /*0x103c256f9*/
          v19 -= v22 * *(__int16 *)(v11 + 2LL * (int)v12 + 2 * v20); /*0x103c25705*/
          ++v21; /*0x103c25708*/
          --v20; /*0x103c2570c*/
        }
        while ( v18 != v20 ); /*0x103c25712*/
        v23 = a1 + v17; /*0x103c25714*/
        result = a4; /*0x103c25718*/
        v11 = a9; /*0x103c2571c*/
      }
      if ( v41 < a2 ) /*0x103c2572f*/
      {
        v24 = 1; /*0x103c25731*/
        v25 = a6 - 1; /*0x103c25737*/
        do /*0x103c25766*/
        {
          v26 = *(__int16 *)(v23 + 2 * v24 - 2); /*0x103c2573b*/
          v15 -= v26 * a5[v25]; /*0x103c25749*/
          v19 -= v26 * a7[v25--]; /*0x103c25754*/
          v27 = v24 + v12 + 1; /*0x103c2575d*/
          ++v24; /*0x103c25760*/
        }
        while ( v27 < a2 ); /*0x103c25766*/
      }
      a3 = v38 + 1; /*0x103c2576c*/
      v28 = v19 >> 12; /*0x103c25770*/
      v29 = v15 + v28; /*0x103c25773*/
      v30 = v15 + v28 + 2048; /*0x103c2577b*/
      *v40 = (unsigned int)(v15 + v28 + 2048) >> 12; /*0x103c2578a*/
      v14 = (__int64)(v40 + 1); /*0x103c25791*/
      *v39 = v29 - (v30 & 0xF000); /*0x103c257a1*/
      v13 = (__int64)(v39 + 1); /*0x103c257a7*/
      ++v12; /*0x103c257ab*/
    }
    while ( v41 != result ); /*0x103c257b1*/
  }
  if ( result >= a6 ) /*0x103c257be*/
  {
    v36 = a2 - 1; /*0x103c2581c*/
    v37 = v11; /*0x103c2582c*/
    WebRtcSpl_CopyFromEndW16(a1: a8, a2: result, a3: v36, a4: a5); /*0x103c2582f*/
    WebRtcSpl_CopyFromEndW16(a1: v37, a2: a4, a3: v36, a4: a7); /*0x103c25841*/
    return a4; /*0x103c25846*/
  }
  else
  {
    v31 = 0; /*0x103c257c0*/
    v32 = result; /*0x103c257c2*/
    do /*0x103c257e3*/
    {
      a5[v31] = a5[v32]; /*0x103c257ca*/
      a7[v31++] = a7[v32++]; /*0x103c257d4*/
    }
    while ( a6 != v32 ); /*0x103c257e3*/
    if ( result != 0 ) /*0x103c257ec*/
    {
      v33 = 2 * a6 - result - result; /*0x103c257f4*/
      v34 = (char *)a5 + v33; /*0x103c257fa*/
      for ( i = 0; i != result; ++i ) /*0x103c257fd*/
      {
        *(_WORD *)&v34[2 * i] = *(_WORD *)(a8 + 2 * i); /*0x103c25803*/
        *(__int16 *)((char *)&a7[i] + v33) = *(_WORD *)(v11 + 2 * i); /*0x103c2580d*/
      }
    }
  }
  return result; /*0x103c2584a*/
}

// Address: 0x103c25859 | Name: _WebRtcSpl_FilterARFastQ12
void __fastcall WebRtcSpl_FilterARFastQ12(__int64 a1, __int64 a2, __int16 *a3, __int64 a4, __int64 a5)
{
  __int64 v5; // rax
  __int64 v6; // r9
  __int64 v7; // r10
  __int64 v8; // rdx
  __int64 v9; // r14
  __int16 *v10; // r12
  __int64 v11; // r13
  __int64 v12; // r15
  __int64 v13; // rcx
  __int64 v14; // [rsp-8h] [rbp-8h]

  if ( a5 != 0 ) /*0x103c2585c*/
  {
    v5 = a4 - 1; /*0x103c2586f*/
    v6 = *a3; /*0x103c25873*/
    v7 = 1 - a4; /*0x103c2587d*/
    *(&v14 - 6) = (__int64)&a3[a4 - 1]; /*0x103c25888*/
    v8 = 0; /*0x103c2588c*/
    v9 = a2; /*0x103c25893*/
    do /*0x103c25900*/
    {
      if ( v5 != 0 ) /*0x103c25899*/
      {
        v10 = (__int16 *)*(&v14 - 6); /*0x103c2589b*/
        v11 = v7; /*0x103c2589f*/
        v12 = 0; /*0x103c258a2*/
        do /*0x103c258bd*/
          v12 += *v10-- * (__int64)*(__int16 *)(v9 + 2 * v11++); /*0x103c258b3*/
        while ( v11 != 0 ); /*0x103c258bd*/
      }
      else
      {
        v12 = 0; /*0x103c258c1*/
      }
      v13 = v6 * *(__int16 *)(a1 + 2 * v8) - v12; /*0x103c258cd*/
      if ( v13 < -134217727 ) /*0x103c258de*/
        v13 = -134217728; /*0x103c258de*/
      if ( v13 >= 134215679 ) /*0x103c258e5*/
        LODWORD(v13) = 134215679; /*0x103c258e5*/
      *(_WORD *)(a2 + 2 * v8++) = (unsigned int)(v13 + 2048) >> 12; /*0x103c258f2*/
      v9 += 2; /*0x103c258f9*/
    }
    while ( v8 != a5 ); /*0x103c25900*/
  }
}

// Address: 0x103c2590d | Name: _WebRtcSpl_FilterMAFastQ12
void __fastcall WebRtcSpl_FilterMAFastQ12(__int64 a1, _WORD *a2, __int16 *a3, __int64 a4, __int64 a5)
{
  __int64 i; // r9
  int v6; // ebx
  __int64 v7; // r14
  __int16 *v8; // r15

  if ( a5 != 0 ) /*0x103c25910*/
  {
    for ( i = 0; i != a5; ++i ) /*0x103c25929*/
    {
      v6 = 0; /*0x103c25938*/
      if ( a4 != 0 ) /*0x103c25940*/
      {
        v7 = 0; /*0x103c25942*/
        v8 = a3; /*0x103c25945*/
        v6 = 0; /*0x103c25948*/
        do /*0x103c25964*/
          v6 += *v8++ * *(__int16 *)(a1 + 2 * v7--); /*0x103c25957*/
        while ( -a4 != v7 ); /*0x103c25964*/
      }
      if ( v6 < -134217727 ) /*0x103c2596c*/
        v6 = -134217728; /*0x103c2596c*/
      if ( v6 >= 134215679 ) /*0x103c25973*/
        v6 = 134215679; /*0x103c25973*/
      *a2++ = (unsigned int)(v6 + 2048) >> 12; /*0x103c25980*/
      a1 += 2; /*0x103c2598a*/
    }
  }
}

// Address: 0x103c2599e | Name: _WebRtcSpl_GetHanningWindow
__int64 __fastcall WebRtcSpl_GetHanningWindow(__int64 a1, unsigned __int64 a2)
{
  __int64 result; // rax
  int v5; // ecx
  __int64 v6; // rdx

  result = WebRtcSpl_DivW32W16(a1: 0x40000000, a2); /*0x103c259b3*/
  if ( a2 != 0 ) /*0x103c259bb*/
  {
    v5 = result + (((a2 >= 0x201) | 0xFFFFFFFE) << 20); /*0x103c259cf*/
    v6 = 0; /*0x103c259d1*/
    do /*0x103c259f3*/
    {
      *(_WORD *)(a1 + 2 * v6++) = kHanningTable[v5 >> 22]; /*0x103c259e6*/
      v5 += result; /*0x103c259ee*/
    }
    while ( a2 != v6 ); /*0x103c259f3*/
  }
  return result; /*0x103c259f5*/
}

// Address: 0x103c259fa | Name: _WebRtcSpl_LevinsonDurbin
__int64 __fastcall WebRtcSpl_LevinsonDurbin(int *a1, _WORD *a2, _WORD *a3, unsigned __int64 a4)
{
  int v5; // eax
  char v6; // cl
  __int64 v7; // rdx
  int v8; // esi
  int v9; // ebx
  int v10; // edi
  int v11; // r12d
  int v12; // r14d
  int v13; // eax
  int v14; // ecx
  int v15; // eax
  unsigned int v16; // esi
  unsigned int v17; // edx
  int v18; // ecx
  int v19; // eax
  int v20; // edx
  signed int v21; // r15d
  unsigned int v22; // r12d
  unsigned int v23; // r12d
  unsigned int v24; // r12d
  int v25; // r15d
  __int64 v26; // rdx
  unsigned __int64 v27; // r13
  __int64 v28; // rax
  size_t v29; // rbx
  int v30; // ecx
  __int64 v31; // rsi
  int v32; // r14d
  int v33; // r12d
  int v34; // edi
  int v35; // eax
  int v36; // edx
  unsigned int v37; // eax
  __int16 v38; // ax
  __int16 v39; // ax
  unsigned int v40; // r12d
  int v41; // ecx
  int v42; // eax
  unsigned int v43; // edx
  int v44; // edx
  __int64 v45; // rsi
  __int64 v46; // rdi
  unsigned int v47; // r9d
  unsigned int v48; // esi
  int v49; // ecx
  int v50; // eax
  int v51; // ecx
  signed int v52; // eax
  int v53; // r15d
  unsigned int v54; // eax
  unsigned int v55; // r14d
  unsigned int v56; // r14d
  unsigned int v57; // r14d
  __int64 result; // rax
  __int64 v60; // rcx
  __int64 i; // rdx
  __int64 v62; // [rsp+8h] [rbp-198h]
  unsigned __int64 v63; // [rsp+10h] [rbp-190h]
  unsigned __int64 v65; // [rsp+20h] [rbp-180h]
  __int64 v66; // [rsp+28h] [rbp-178h]
  unsigned __int64 v68; // [rsp+38h] [rbp-168h]
  __int64 v69; // [rsp+40h] [rbp-160h]
  unsigned int v70; // [rsp+4Ch] [rbp-154h]
  _BYTE v72[48]; // [rsp+52h] [rbp-14Eh] BYREF
  _BYTE __src[48]; // [rsp+82h] [rbp-11Eh] BYREF
  _WORD v74[24]; // [rsp+B2h] [rbp-EEh] BYREF
  _WORD __dst[23]; // [rsp+E2h] [rbp-BEh] BYREF
  __int16 v76[24]; // [rsp+110h] [rbp-90h]
  __int16 v77[24]; // [rsp+140h] [rbp-60h]

  v5 = *a1; /*0x103c25a26*/
  if ( *a1 != 0 ) /*0x103c25a31*/
  {
    if ( v5 != v5 >> 31 ) /*0x103c25a38*/
    {
      _BitScanReverse((unsigned int *)&v5, v5 ^ (v5 >> 31)); /*0x103c25a3c*/
      LOBYTE(v5) = v5 ^ 0x1F; /*0x103c25a3f*/
    }
    else
    {
      LOBYTE(v5) = 32; /*0x103c25a48*/
    }
    v6 = v5 - 1; /*0x103c25a4f*/
  }
  else
  {
    v6 = 0; /*0x103c25a44*/
  }
  v65 = a4 + 1; /*0x103c25a56*/
  v7 = 0; /*0x103c25a68*/
  do /*0x103c25a8d*/
  {
    v8 = a1[v7] << v6; /*0x103c25a6d*/
    v77[v7] = HIWORD(v8); /*0x103c25a76*/
    v76[v7++] = (unsigned __int16)v8 >> 1; /*0x103c25a7e*/
  }
  while ( (a4 == -1) + a4 + 1 != v7 ); /*0x103c25a8d*/
  v9 = a1[1] << v6; /*0x103c25a92*/
  v10 = -v9; /*0x103c25a96*/
  if ( v9 > 0 ) /*0x103c25a98*/
    v10 = v9; /*0x103c25a98*/
  v11 = v77[0]; /*0x103c25a9b*/
  v12 = v76[0]; /*0x103c25aa0*/
  v13 = WebRtcSpl_DivW32HiLow(a1: v10, a2: v77[0], a3: v76[0]); /*0x103c25aae*/
  v14 = -v13; /*0x103c25ab5*/
  if ( v9 <= 0 ) /*0x103c25ab9*/
    v14 = v13; /*0x103c25ab9*/
  v15 = v14 >> 16; /*0x103c25ac3*/
  v16 = (unsigned int)v14 >> 1; /*0x103c25ac8*/
  *a3 = HIWORD(v14); /*0x103c25ad1*/
  v17 = (unsigned int)v14 >> 4; /*0x103c25ad6*/
  v18 = v14 >> 20; /*0x103c25ad9*/
  __dst[0] = v18; /*0x103c25adc*/
  v74[0] = (v17 - (v18 << 16)) >> 1; /*0x103c25aea*/
  v19 = 2 * (((int)(v15 * (v16 & 0x7FFF)) >> 14) + v15 * v15); /*0x103c25b03*/
  v20 = -v19; /*0x103c25b07*/
  if ( v19 > 0 ) /*0x103c25b09*/
    v20 = v19; /*0x103c25b09*/
  v21 = 2 /*0x103c25b39*/
      * (((v11 * ((unsigned __int16)~(_WORD)v20 >> 1)) >> 15)
       + v11 * ((v20 ^ 0x7FFFFFFFu) >> 16)
       + ((int)(v12 * ((v20 ^ 0x7FFFFFFFu) >> 16)) >> 15));
  if ( v21 != 0 ) /*0x103c25b3c*/
  {
    if ( v21 != v21 >> 31 ) /*0x103c25b44*/
    {
      _BitScanReverse(&v22, v21 ^ (v21 >> 31)); /*0x103c25b49*/
      v23 = v22 ^ 0x1F; /*0x103c25b4d*/
    }
    else
    {
      v23 = 32; /*0x103c25b58*/
    }
    v24 = v23 - 1; /*0x103c25b5e*/
  }
  else
  {
    v24 = 0; /*0x103c25b53*/
  }
  v68 = a4; /*0x103c25b61*/
  if ( a4 < 2 ) /*0x103c25b6c*/
  {
LABEL_55:
    *a2 = 4096; /*0x103c25e62*/
    LOWORD(result) = 1; /*0x103c25e6f*/
    if ( v68 != 0 ) /*0x103c25e7b*/
    {
      v60 = 2; /*0x103c25e88*/
      if ( v65 >= 3 ) /*0x103c25e8d*/
        v60 = v65; /*0x103c25e8d*/
      for ( i = 1; i != v60; ++i ) /*0x103c25e91*/
        a2[i] = (unsigned int)(((unsigned __int16)v74[i + 23] << 17) + 4 * *(__int16 *)&__src[2 * i + 46] + 0x8000) >> 16; /*0x103c25eb5*/
    }
  }
  else
  {
    v25 = v21 << v24; /*0x103c25b75*/
    v63 = a4 - 2; /*0x103c25b83*/
    v26 = 1; /*0x103c25b8a*/
    v66 = 0; /*0x103c25b8f*/
    v27 = 0; /*0x103c25b9a*/
    v69 = 2; /*0x103c25ba2*/
    while ( 1 ) /*0x103c25ba9*/
    {
      v70 = v24; /*0x103c25ba9*/
      v28 = v27 + 3; /*0x103c25bb0*/
      if ( v27 >= 0xFFFFFFFFFFFFFFFDLL ) /*0x103c25bbd*/
        v28 = 2; /*0x103c25bbd*/
      v29 = 2 * v28 - 2; /*0x103c25bc1*/
      v62 = v26; /*0x103c25bcf*/
      v30 = 0; /*0x103c25bd6*/
      v31 = 1; /*0x103c25bd8*/
      do /*0x103c25c21*/
      {
        v30 += 2 /*0x103c25c17*/
             * (v77[v31] * (__int16)v74[v26 + 23]
              + ((v77[v31] * *(__int16 *)&__src[2 * v26 + 46]) >> 15)
              + (((__int16)v74[v26 + 23] * v76[v31]) >> 15));
        ++v31; /*0x103c25c1b*/
        --v26; /*0x103c25c1e*/
      }
      while ( v26 != 0 ); /*0x103c25c21*/
      v32 = (unsigned __int16)v25 >> 1; /*0x103c25c27*/
      v33 = 16 * v30 + ((unsigned __int16)v77[v69] << 16) + 2 * v76[v69]; /*0x103c25c46*/
      v34 = -v33; /*0x103c25c4d*/
      if ( v33 > 0 ) /*0x103c25c4f*/
        v34 = 16 * v30 + ((unsigned __int16)v77[v69] << 16) + 2 * v76[v69]; /*0x103c25c4f*/
      v35 = WebRtcSpl_DivW32HiLow(a1: v34, a2: SHIWORD(v25), a3: v32); /*0x103c25c59*/
      v36 = -v35; /*0x103c25c60*/
      if ( v33 <= 0 ) /*0x103c25c65*/
        v36 = v35; /*0x103c25c65*/
      if ( v36 != 0 ) /*0x103c25c6a*/
      {
        if ( v36 != v36 >> 31 ) /*0x103c25c71*/
        {
          _BitScanReverse(&v37, v36 ^ (v36 >> 31)); /*0x103c25c75*/
          v38 = v37 ^ 0x1F; /*0x103c25c78*/
        }
        else
        {
          v38 = 32; /*0x103c25c88*/
        }
        v40 = v70; /*0x103c25c8d*/
        v39 = v38 - 1; /*0x103c25c94*/
      }
      else
      {
        v39 = 0; /*0x103c25c7d*/
        v40 = v70; /*0x103c25c7f*/
      }
      v41 = (v36 <= 0) + 0x7FFFFFFF; /*0x103c25ca4*/
      if ( (__int16)v40 <= v39 ) /*0x103c25cae*/
        v41 = v36 << v40; /*0x103c25cae*/
      if ( v36 == 0 ) /*0x103c25cb3*/
        v41 = 0; /*0x103c25cb3*/
      v42 = v41 >> 16; /*0x103c25cbd*/
      a3[v69 - 1] = HIWORD(v41); /*0x103c25cce*/
      v43 = -(v41 >> 16); /*0x103c25cd5*/
      if ( v41 >> 16 > 0 ) /*0x103c25cd7*/
        v43 = v41 >> 16; /*0x103c25cd7*/
      if ( v43 > 0x7FEE ) /*0x103c25ce0*/
        break; /*0x103c25ce0*/
      v44 = (unsigned __int16)v41 >> 1; /*0x103c25cea*/
      v45 = -1; /*0x103c25cf0*/
      v46 = v66; /*0x103c25cf7*/
      do /*0x103c25d6c*/
      {
        v47 = (__int16)v74[v45 + 1] /*0x103c25d36*/
            + ((v42 * *(__int16 *)((char *)v74 + v46)) >> 15)
            + *(__int16 *)((char *)__dst + v46) * v42
            + ((v44 * *(__int16 *)((char *)__dst + v46)) >> 15);
        *(_WORD *)&__src[2 * v45 + 2] = __dst[v45 + 1] + (v47 >> 15); /*0x103c25d49*/
        *(_WORD *)&v72[2 * v45++ + 2] = v47 & 0x7FFF; /*0x103c25d59*/
        v46 -= 2; /*0x103c25d65*/
      }
      while ( v27 != v45 ); /*0x103c25d6c*/
      v48 = (unsigned int)v41 >> 4; /*0x103c25d70*/
      v49 = v41 >> 20; /*0x103c25d73*/
      *(_WORD *)&v72[2 * v69 + 46] = v49; /*0x103c25d7d*/
      *(_WORD *)&v72[2 * v69 - 2] = (v48 - (v49 << 16)) >> 1; /*0x103c25d8c*/
      v50 = 2 * (((v42 * v44) >> 14) + v42 * v42); /*0x103c25d9f*/
      v51 = -v50; /*0x103c25da3*/
      if ( v50 > 0 ) /*0x103c25da5*/
        v51 = v50; /*0x103c25da5*/
      v52 = (((v25 >> 16) * ((unsigned __int16)~(_WORD)v51 >> 1)) >> 15) /*0x103c25dd6*/
          + (v25 >> 16) * ((v51 ^ 0x7FFFFFFFu) >> 16)
          + ((((v51 ^ 0x7FFFFFFFu) >> 16) * (unsigned __int16)v32) >> 15);
      v53 = 2 * v52; /*0x103c25dd8*/
      if ( v52 != 0 ) /*0x103c25dde*/
      {
        v54 = v53 ^ (v52 >> 30); /*0x103c25de3*/
        if ( v54 != 0 ) /*0x103c25de6*/
        {
          _BitScanReverse(&v55, v54); /*0x103c25de8*/
          v56 = v55 ^ 0x1F; /*0x103c25dec*/
        }
        else
        {
          v56 = 32; /*0x103c25df7*/
        }
        v57 = v56 - 1; /*0x103c25dfd*/
      }
      else
      {
        v57 = 0; /*0x103c25df2*/
      }
      v25 = v53 << v57; /*0x103c25e03*/
      memcpy(__dst, __src, __n: v29); /*0x103c25e17*/
      memcpy(__dst: v74, __src: v72, __n: v29); /*0x103c25e2d*/
      v24 = v57 + v40; /*0x103c25e32*/
      ++v69; /*0x103c25e35*/
      v26 = v62 + 1; /*0x103c25e47*/
      v66 += 2; /*0x103c25e4a*/
      if ( v27++ == v63 ) /*0x103c25e52*/
        goto LABEL_55; /*0x103c25e5c*/
    }
    LOWORD(result) = 0; /*0x103c25ec4*/
  }
  return (unsigned __int16)result; /*0x103c25ed9*/
}

// Address: 0x103c5400c | Name: _WebRtcG711_EncodeA
__int64 __fastcall WebRtcG711_EncodeA(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 i; // r9
  int v5; // r11d
  unsigned int v6; // ebx
  __int64 v7; // rdx
  unsigned int v8; // r11d
  char v9; // r11
  char v10; // cl

  if ( a2 != 0 ) /*0x103c5400f*/
  {
    for ( i = 0; i != a2; ++i ) /*0x103c5401f*/
    {
      v5 = *(__int16 *)(a1 + 2 * i); /*0x103c54028*/
      v6 = v5 ^ (v5 >> 31); /*0x103c54033*/
      _BitScanReverse64((unsigned __int64 *)&v7, v6 | 0xFF); /*0x103c54044*/
      v8 = ((unsigned int)~v5 >> 24) & 0x80 | 0x55; /*0x103c54053*/
      if ( (int)v7 < 15 ) /*0x103c5405a*/
      {
        v10 = v7 - 4; /*0x103c54073*/
        if ( (_DWORD)v7 == 7 ) /*0x103c54076*/
          v10 = 4; /*0x103c54076*/
        v9 = v8 ^ ((16 * (v7 - 7)) | (v6 >> v10) & 0xF); /*0x103c54085*/
      }
      else
      {
        v9 = v8 ^ 0x7F; /*0x103c5405c*/
      }
      *(_BYTE *)(a3 + i) = v9; /*0x103c54088*/
    }
  }
  return a2; /*0x103c5409b*/
}

// Address: 0x103c5409c | Name: _WebRtcG711_EncodeU
__int64 __fastcall WebRtcG711_EncodeU(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 i; // r9
  int v5; // eax
  unsigned int v6; // r11d
  __int64 v7; // rdx
  char v8; // r10

  if ( a2 != 0 ) /*0x103c540a3*/
  {
    for ( i = 0; i != a2; ++i ) /*0x103c540a8*/
    {
      v5 = *(__int16 *)(a1 + 2 * i); /*0x103c540ab*/
      v6 = v5 + 132; /*0x103c540b7*/
      if ( v5 < 0 ) /*0x103c540ce*/
        v6 = 131 - v5; /*0x103c540ce*/
      _BitScanReverse64((unsigned __int64 *)&v7, v6 | 0xFF); /*0x103c540e1*/
      if ( (int)v7 < 15 ) /*0x103c540e8*/
        v8 = (((unsigned int)~v5 >> 24) | 0x7F) ^ (((v6 >> (v7 - 4)) & 0xF) + 16 * v7 - 112); /*0x103c5410a*/
      else
        v8 = ((unsigned int)~v5 >> 24) & 0x80; /*0x103c540ea*/
      *(_BYTE *)(a3 + i) = v8; /*0x103c5410d*/
    }
  }
  return a2; /*0x103c5411c*/
}

// Address: 0x103c5411e | Name: _WebRtcG711_DecodeA
__int64 __fastcall WebRtcG711_DecodeA(__int64 a1, __int64 a2, __int64 a3, _WORD *a4)
{
  __int64 i; // r8
  int v6; // r11d
  int v7; // ebx
  int v8; // r11d
  int v9; // ecx

  if ( a2 != 0 ) /*0x103c54124*/
  {
    for ( i = 0; i != a2; ++i ) /*0x103c5412b*/
    {
      v6 = (unsigned __int8)(16 * (*(_BYTE *)(a1 + i) ^ 0x55)); /*0x103c54140*/
      v7 = (v6 + 264) << ((((*(unsigned __int8 *)(a1 + i) ^ 0x55u) >> 4) & 7) - 1); /*0x103c54157*/
      v8 = v6 | 8; /*0x103c54159*/
      if ( (((*(unsigned __int8 *)(a1 + i) ^ 0x55u) >> 4) & 7) != 0 ) /*0x103c54161*/
        v8 = v7; /*0x103c54161*/
      v9 = -v8; /*0x103c54168*/
      if ( *(char *)(a1 + i) < 0 ) /*0x103c5416d*/
        LOWORD(v9) = v8; /*0x103c5416d*/
      *(_WORD *)(a3 + 2 * i) = v9; /*0x103c54171*/
    }
  }
  *a4 = 1; /*0x103c54180*/
  return a2; /*0x103c54188*/
}

// Address: 0x103c54189 | Name: _WebRtcG711_DecodeU
__int64 __fastcall WebRtcG711_DecodeU(__int64 a1, __int64 a2, __int64 a3, _WORD *a4)
{
  __int64 i; // r8
  int v6; // r11d
  __int16 v7; // cx
  __int16 v8; // r11

  if ( a2 != 0 ) /*0x103c54193*/
  {
    for ( i = 0; i != a2; ++i ) /*0x103c54195*/
    {
      v6 = ((unsigned __int8)(8 * ~*(_BYTE *)(a1 + i)) | 0x84) << (((unsigned __int8)~*(_BYTE *)(a1 + i) >> 4) & 7); /*0x103c541bf*/
      v7 = 132 - v6; /*0x103c541c7*/
      v8 = v6 - 132; /*0x103c541ca*/
      if ( *(char *)(a1 + i) >= 0 ) /*0x103c541d4*/
        v8 = v7; /*0x103c541d4*/
      *(_WORD *)(a3 + 2 * i) = v8; /*0x103c541d8*/
    }
  }
  *a4 = 1; /*0x103c541e5*/
  return a2; /*0x103c541ed*/
}

// Address: 0x103c541ef | Name: _WebRtcG711_Version
__int64 __fastcall WebRtcG711_Version(char *a1, int a2)
{
  strncpy(__dst: a1, __src: "2.0.0", __n: a2); /*0x103c541fd*/
  return 0; /*0x103c54204*/
}

// Address: 0x103c54e20 | Name: _WebRtcG722_CreateEncoder
__int64 __fastcall WebRtcG722_CreateEncoder(_QWORD *a1)
{
  void *v2; // rax

  v2 = malloc(__size: 0x1E8u); /*0x103c54e2e*/
  *a1 = v2; /*0x103c54e33*/
  return (unsigned int)-(v2 == nullptr); /*0x103c54e44*/
}

// Address: 0x103c54e47 | Name: _WebRtcG722_EncoderInit
__int64 __fastcall WebRtcG722_EncoderInit(__int64 a1)
{
  return (unsigned int)-(WebRtc_g722_encode_init(a1, a2: 64000, a3: 2) == 0); /*0x103c54e64*/
}

// Address: 0x103c54e66 | Name: _WebRtcG722_FreeEncoder
__int64 WebRtcG722_FreeEncoder()
{
  return WebRtc_g722_encode_release(); /*0x103c54e6a*/
}

// Address: 0x103c54e70 | Name: _WebRtcG722_Encode
__int64 __fastcall WebRtcG722_Encode(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  return WebRtc_g722_encode(a1, a2: a4, a3: a2, a4: a3); /*0x103c54e80*/
}

// Address: 0x103c54e86 | Name: _WebRtcG722_CreateDecoder
__int64 __fastcall WebRtcG722_CreateDecoder(_QWORD *a1)
{
  void *v2; // rax

  v2 = malloc(__size: 0x1E8u); /*0x103c54e94*/
  *a1 = v2; /*0x103c54e99*/
  return (unsigned int)-(v2 == nullptr); /*0x103c54eaa*/
}

// Address: 0x103c54ead | Name: _WebRtcG722_DecoderInit
__int64 __fastcall WebRtcG722_DecoderInit(__int64 a1)
{
  return WebRtc_g722_decode_init(a1, a2: 64000, a3: 2); /*0x103c54ebb*/
}

// Address: 0x103c54ec1 | Name: _WebRtcG722_FreeDecoder
__int64 WebRtcG722_FreeDecoder()
{
  return WebRtc_g722_decode_release(); /*0x103c54ec5*/
}

// Address: 0x103c54ecb | Name: _WebRtcG722_Decode
__int64 __fastcall WebRtcG722_Decode(__int64 a1, __int64 a2, __int64 a3, __int64 a4, _WORD *a5)
{
  *a5 = 1; /*0x103c54ed5*/
  return WebRtc_g722_decode(a1, a2: a4, a3: a2, a4: a3); /*0x103c54ee1*/
}

// Address: 0x103c54ee7 | Name: _WebRtcG722_Version
int __fastcall WebRtcG722_Version(char *a1, unsigned int a2)
{
  int result; // eax

  LOWORD(result) = -1; /*0x103c54eeb*/
  if ( a2 >= 7 ) /*0x103c54ef2*/
  {
    strcpy(a1, "2.0.0\n"); /*0x103c54efb*/
    LOWORD(result) = 0; /*0x103c54f01*/
  }
  return (__int16)result; /*0x103c54f04*/
}

// Address: 0x103c5a732 | Name: _WebRtcOpus_EncoderCreate
int __fastcall WebRtcOpus_EncoderCreate(_QWORD *a1, __int64 a2, int a3, unsigned int a4)
{
  __int64 v4; // rax
  int result; // eax
  unsigned int v9; // r13d
  _QWORD *v10; // r12
  __int64 v11; // rax
  int v12; // [rsp-34h] [rbp-34h]

  LOWORD(result) = -1; /*0x103c5a732*/
  if ( a1 != nullptr ) /*0x103c5a739*/
  {
    v12 = HIDWORD(v4); /*0x103c5a74c*/
    if ( a3 != 0 ) /*0x103c5a757*/
    {
      if ( a3 != 1 ) /*0x103c5a75c*/
        return (__int16)result; /*0x103c5a75c*/
      v9 = 2049; /*0x103c5a75e*/
    }
    else
    {
      v9 = 2048; /*0x103c5a766*/
    }
    v10 = calloc(__count: 1u, __size: 0x20u); /*0x103c5a77b*/
    v11 = opus_encoder_create(a1: a4, (unsigned int)a2, a3: v9); /*0x103c5a78d*/
    *v10 = v11; /*0x103c5a792*/
    if ( v12 != 0 || v11 == 0 ) /*0x103c5a7a1*/
    {
      WebRtcOpus_EncoderFree(a1: v10); /*0x103c5a7ad*/
      LOWORD(result) = -1; /*0x103c5a7b2*/
    }
    else
    {
      v10[2] = a2; /*0x103c5a7b8*/
      *((_DWORD *)v10 + 7) = a4; /*0x103c5a7bd*/
      *a1 = v10; /*0x103c5a7c2*/
      LOWORD(result) = 0; /*0x103c5a7c5*/
    }
  }
  return (__int16)result; /*0x103c5a7d6*/
}

// Address: 0x103c5a7d7 | Name: _WebRtcOpus_EncoderFree
int __fastcall WebRtcOpus_EncoderFree(__int64 *a1)
{
  __int64 v2; // rdi
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5a7da*/
  {
    v2 = *a1; /*0x103c5a7e5*/
    if ( v2 != 0 ) /*0x103c5a7eb*/
      opus_encoder_destroy(a1: v2); /*0x103c5a7ed*/
    else
      opus_multistream_encoder_destroy(a1: a1[1]); /*0x103c5a7fe*/
    free(a1); /*0x103c5a806*/
    LOWORD(result) = 0; /*0x103c5a80b*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5a7f4*/
  }
  return (__int16)result; /*0x103c5a814*/
}

// Address: 0x103c5a815 | Name: _WebRtcOpus_MultistreamEncoderCreate
int __fastcall WebRtcOpus_MultistreamEncoderCreate(__int64 **a1, __int64 a2, int a3, int a4, int a5, int a6)
{
  int result; // eax
  __int64 v10; // r15
  __int64 *v11; // r14
  __int64 v12; // rax
  int v13; // [rsp+8h] [rbp-40h]
  int v14; // [rsp+10h] [rbp-38h] BYREF
  int v15; // [rsp+14h] [rbp-34h]

  LOWORD(result) = -1; /*0x103c5a815*/
  if ( a1 != nullptr ) /*0x103c5a81c*/
  {
    if ( a3 != 0 ) /*0x103c5a83e*/
    {
      if ( a3 != 1 ) /*0x103c5a843*/
        return (__int16)result; /*0x103c5a843*/
      v13 = a6; /*0x103c5a849*/
      v10 = a2; /*0x103c5a84d*/
      v15 = 2049; /*0x103c5a850*/
    }
    else
    {
      v13 = a6; /*0x103c5a859*/
      v10 = a2; /*0x103c5a85d*/
      v15 = 2048; /*0x103c5a860*/
    }
    v11 = (__int64 *)calloc(__count: 1u, __size: 0x20u); /*0x103c5a876*/
    v12 = opus_multistream_encoder_create(a1: 48000, a2: v10, a3: a4, a4: a5, a5: v13, a6: v15, a7: (__int64)&v14); /*0x103c5a897*/
    v11[1] = v12; /*0x103c5a89c*/
    if ( v14 != 0 || v12 == 0 ) /*0x103c5a8ad*/
    {
      WebRtcOpus_EncoderFree(a1: v11); /*0x103c5a8b9*/
      LOWORD(result) = -1; /*0x103c5a8be*/
    }
    else
    {
      v11[2] = v10; /*0x103c5a8c4*/
      *((_DWORD *)v11 + 7) = 48000; /*0x103c5a8c8*/
      *a1 = v11; /*0x103c5a8d0*/
      LOWORD(result) = 0; /*0x103c5a8d3*/
    }
  }
  return (__int16)result; /*0x103c5a8e4*/
}

// Address: 0x103c5a8e5 | Name: _WebRtcOpus_Encode
__int64 __fastcall WebRtcOpus_Encode(__int64 *a1, __int64 a2, unsigned __int64 a3, unsigned int a4, __int64 a5)
{
  unsigned int v5; // r14d
  __int64 v7; // rdi
  int v8; // eax
  int v9; // ecx

  v5 = -1; /*0x103c5a8ec*/
  if ( a3 <= 0xB40 )
  {
    v7 = *a1; /*0x103c5a901*/
    v8 = v7 != 0
       ? opus_encode(a1: v7, a2, a3, a4: a5, a5: a4)
       : opus_multistream_encode(a1: a1[1], a2, a3, a4: a5, a5: a4);
    if ( v8 > 0 ) /*0x103c5a927*/
    {
      v9 = 0; /*0x103c5a929*/
      if ( (unsigned int)v8 > 2 ) /*0x103c5a92e*/
      {
LABEL_9:
        *((_DWORD *)a1 + 6) = v9; /*0x103c5a93e*/
        return (unsigned int)v8; /*0x103c5a941*/
      }
      v5 = 0; /*0x103c5a930*/
      if ( *((_DWORD *)a1 + 6) == 0 ) /*0x103c5a937*/
      {
        v9 = 1; /*0x103c5a939*/
        goto LABEL_9; /*0x103c5a939*/
      }
    }
  }
  return v5; /*0x103c5a947*/
}

// Address: 0x103c5a94c | Name: _WebRtcOpus_SetBitRate
int __fastcall WebRtcOpus_SetBitRate(_QWORD *a1, int a2, __int64 a3, int a4, int a5, int a6)
{
  char v6; // bp
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5a94f*/
  {
    if ( *a1 != 0 ) /*0x103c5a95d*/
      LOWORD(result) = opus_encoder_ctl(a1: *a1, a2: 4002, a3: a2, a4, a5, a6, a7: v6); /*0x103c5a969*/
    else
      LOWORD(result) = opus_multistream_encoder_ctl(a1: a1[1], a2: 4002, a3: a2, a4, a5, a6, a7: v6); /*0x103c5a981*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5a970*/
  }
  return (__int16)result; /*0x103c5a988*/
}

// Address: 0x103c5a989 | Name: _WebRtcOpus_SetPacketLossRate
int __fastcall WebRtcOpus_SetPacketLossRate(_QWORD *a1, int a2, __int64 a3, int a4, int a5, int a6)
{
  char v6; // bp
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5a98c*/
  {
    if ( *a1 != 0 ) /*0x103c5a99a*/
      LOWORD(result) = opus_encoder_ctl(a1: *a1, a2: 4014, a3: a2, a4, a5, a6, a7: v6); /*0x103c5a9a6*/
    else
      LOWORD(result) = opus_multistream_encoder_ctl(a1: a1[1], a2: 4014, a3: a2, a4, a5, a6, a7: v6); /*0x103c5a9be*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5a9ad*/
  }
  return (__int16)result; /*0x103c5a9c5*/
}

// Address: 0x103c5a9c6 | Name: _WebRtcOpus_SetMaxPlaybackRate
int __fastcall WebRtcOpus_SetMaxPlaybackRate(_QWORD *a1, unsigned int a2, __int64 a3, int a4, int a5, int a6)
{
  char v6; // bp
  int v7; // edx
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5a9c9*/
  {
    v7 = 1101; /*0x103c5a9cb*/
    if ( (int)a2 >= 8001 ) /*0x103c5a9d6*/
    {
      v7 = 1102; /*0x103c5a9d8*/
      if ( a2 >= 0x2EE1 ) /*0x103c5a9e3*/
      {
        v7 = 1103; /*0x103c5a9e5*/
        if ( a2 >= 0x3E81 ) /*0x103c5a9f0*/
          v7 = ((a2 | 0x45100000000uLL) - 24001) >> 32; /*0x103c5a9fd*/
      }
    }
    if ( *a1 != 0 ) /*0x103c5aa0a*/
      LOWORD(result) = opus_encoder_ctl(a1: *a1, a2: 4004, a3: v7, a4, a5, a6, a7: v6); /*0x103c5aa16*/
    else
      LOWORD(result) = opus_multistream_encoder_ctl(a1: a1[1], a2: 4004, a3: v7, a4, a5, a6, a7: v6); /*0x103c5aa2e*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5aa1d*/
  }
  return (__int16)result; /*0x103c5aa35*/
}

// Address: 0x103c5aa36 | Name: _WebRtcOpus_GetMaxPlaybackRate
__int64 __fastcall WebRtcOpus_GetMaxPlaybackRate(__int64 *a1, int *a2, __int64 a3, int a4, int a5, int a6)
{
  __int64 v7; // rdi
  int v8; // ebx
  __int64 v9; // rdi
  int i; // r13d
  int v11; // eax
  int v12; // ecx
  int v13; // r8d
  int v14; // r9d
  __int64 v16; // [rsp+0h] [rbp-40h] BYREF
  int *v17; // [rsp+8h] [rbp-38h]
  int v18; // [rsp+14h] [rbp-2Ch] BYREF

  v7 = *a1; /*0x103c5aa4d*/
  if ( v7 != 0 )
  {
    v8 = -((unsigned int)opus_encoder_ctl(a1: v7, a2: 4005, a3: (_DWORD)a2, a4, a5, a6, a7: v16) != 0); /*0x103c5aa65*/
  }
  else
  {
    v17 = a2; /*0x103c5aa6c*/
    v9 = 0; /*0x103c5aa78*/
    v8 = 0; /*0x103c5aa7a*/
    for ( i = 0; ; ++i )
    {
      v11 = v9 != 0
          ? opus_encoder_ctl(a1: v9, a2: 5120, a3: i, a4: (unsigned int)&v16, a5, a6, a7: v16)
          : opus_multistream_encoder_ctl(a1: a1[1], a2: 5120, a3: i, a4: (unsigned int)&v16, a5, a6, a7: v16);
      if ( v11 != 0 ) /*0x103c5aab0*/
        break; /*0x103c5aab0*/
      if ( (unsigned int)opus_encoder_ctl(a1: v16, a2: 4005, a3: (unsigned int)&v18, a4: v12, a5: v13, a6: v14, a7: v16) != 0 /*0x103c5aad3*/
        || v8 != 0 && v8 != v18 )
      {
        goto LABEL_13; /*0x103c5aad8*/
      }
      v9 = *a1; /*0x103c5aadd*/
      v8 = v18; /*0x103c5aae0*/
    }
    if ( v11 == -1 ) /*0x103c5aae7*/
    {
      *v17 = v8; /*0x103c5aaed*/
      LOWORD(v8) = 0; /*0x103c5aaef*/
      return (unsigned int)(__int16)v8; /*0x103c5aaf1*/
    }
LABEL_13:
    LOWORD(v8) = -1; /*0x103c5aaf3*/
  }
  return (unsigned int)(__int16)v8; /*0x103c5aafa*/
}

// Address: 0x103c5ab09 | Name: _WebRtcOpus_EnableFec
int __fastcall WebRtcOpus_EnableFec(_QWORD *a1, __int64 a2, __int64 a3, int a4, int a5, int a6)
{
  char v6; // bp
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5ab0c*/
  {
    if ( *a1 != 0 ) /*0x103c5ab18*/
      LOWORD(result) = opus_encoder_ctl(a1: *a1, a2: 4012, a3: 1, a4, a5, a6, a7: v6); /*0x103c5ab29*/
    else
      LOWORD(result) = opus_multistream_encoder_ctl(a1: a1[1], a2: 4012, a3: 1, a4, a5, a6, a7: v6); /*0x103c5ab46*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5ab30*/
  }
  return (__int16)result; /*0x103c5ab4d*/
}

// Address: 0x103c5ab4e | Name: _WebRtcOpus_DisableFec
int __fastcall WebRtcOpus_DisableFec(_QWORD *a1, __int64 a2, __int64 a3, int a4, int a5, int a6)
{
  char v6; // bp
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5ab51*/
  {
    if ( *a1 != 0 ) /*0x103c5ab5d*/
      LOWORD(result) = opus_encoder_ctl(a1: *a1, a2: 4012, a3: 0, a4, a5, a6, a7: v6); /*0x103c5ab6b*/
    else
      LOWORD(result) = opus_multistream_encoder_ctl(a1: a1[1], a2: 4012, a3: 0, a4, a5, a6, a7: v6); /*0x103c5ab85*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5ab72*/
  }
  return (__int16)result; /*0x103c5ab8c*/
}

// Address: 0x103c5ab8d | Name: _WebRtcOpus_EnableDtx
int __fastcall WebRtcOpus_EnableDtx(_QWORD *a1, __int64 a2, __int64 a3, int a4, int a5, int a6)
{
  char v6; // bp
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5ab90*/
  {
    if ( *a1 != 0 ) /*0x103c5ab9c*/
      LOWORD(result) = opus_encoder_ctl(a1: *a1, a2: 4016, a3: 1, a4, a5, a6, a7: v6); /*0x103c5abad*/
    else
      LOWORD(result) = opus_multistream_encoder_ctl(a1: a1[1], a2: 4016, a3: 1, a4, a5, a6, a7: v6); /*0x103c5abca*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5abb4*/
  }
  return (__int16)result; /*0x103c5abd1*/
}

// Address: 0x103c5abd2 | Name: _WebRtcOpus_DisableDtx
int __fastcall WebRtcOpus_DisableDtx(_QWORD *a1, __int64 a2, __int64 a3, int a4, int a5, int a6)
{
  char v6; // bp
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5abd5*/
  {
    if ( *a1 != 0 ) /*0x103c5abe1*/
      LOWORD(result) = opus_encoder_ctl(a1: *a1, a2: 4016, a3: 0, a4, a5, a6, a7: v6); /*0x103c5abef*/
    else
      LOWORD(result) = opus_multistream_encoder_ctl(a1: a1[1], a2: 4016, a3: 0, a4, a5, a6, a7: v6); /*0x103c5ac09*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5abf6*/
  }
  return (__int16)result; /*0x103c5ac10*/
}

// Address: 0x103c5ac11 | Name: _WebRtcOpus_GetUseDtx
int __fastcall WebRtcOpus_GetUseDtx(_QWORD *a1, __int64 a2, __int64 a3, int a4, int a5, int a6)
{
  int v6; // eax
  int result; // eax
  _WORD v8[2]; // [rsp+Ch] [rbp-4h] BYREF

  if ( a1 != nullptr
    && (*a1 == 0
      ? (v6 = opus_multistream_encoder_ctl(a1: a1[1], a2: 4017, a3: (unsigned int)v8, a4, a5, a6))
      : (v6 = opus_encoder_ctl(a1: *a1, a2: 4017, a3: (unsigned int)v8, a4, a5, a6)),
        v6 == 0) )
  {
    LOWORD(result) = v8[0]; /*0x103c5ac59*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5ac53*/
  }
  return (__int16)result; /*0x103c5ac5e*/
}

// Address: 0x103c5ac64 | Name: _WebRtcOpus_GetInDtx
int __fastcall WebRtcOpus_GetInDtx(_QWORD *a1, __int64 a2, __int64 a3, int a4, int a5, int a6)
{
  int v6; // eax
  int result; // eax
  _WORD v8[2]; // [rsp+Ch] [rbp-4h] BYREF

  if ( a1 != nullptr
    && (*a1 == 0
      ? (v6 = opus_multistream_encoder_ctl(a1: a1[1], a2: 4049, a3: (unsigned int)v8, a4, a5, a6))
      : (v6 = opus_encoder_ctl(a1: *a1, a2: 4049, a3: (unsigned int)v8, a4, a5, a6)),
        v6 == 0) )
  {
    LOWORD(result) = v8[0]; /*0x103c5acac*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5aca6*/
  }
  return (__int16)result; /*0x103c5acb1*/
}

// Address: 0x103c5acb7 | Name: _WebRtcOpus_EnableCbr
int __fastcall WebRtcOpus_EnableCbr(_QWORD *a1, __int64 a2, __int64 a3, int a4, int a5, int a6)
{
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5acba*/
  {
    if ( *a1 != 0 ) /*0x103c5acc6*/
      LOWORD(result) = opus_encoder_ctl(a1: *a1, a2: 4006, a3: 0, a4, a5, a6); /*0x103c5acd4*/
    else
      LOWORD(result) = opus_multistream_encoder_ctl(a1: a1[1], a2: 4006, a3: 0, a4, a5, a6); /*0x103c5acee*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5acdb*/
  }
  return (__int16)result; /*0x103c5acf5*/
}

// Address: 0x103c5acf6 | Name: _WebRtcOpus_DisableCbr
int __fastcall WebRtcOpus_DisableCbr(_QWORD *a1, __int64 a2, __int64 a3, int a4, int a5, int a6)
{
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5acf9*/
  {
    if ( *a1 != 0 ) /*0x103c5ad05*/
      LOWORD(result) = opus_encoder_ctl(a1: *a1, a2: 4006, a3: 1, a4, a5, a6); /*0x103c5ad16*/
    else
      LOWORD(result) = opus_multistream_encoder_ctl(a1: a1[1], a2: 4006, a3: 1, a4, a5, a6); /*0x103c5ad33*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5ad1d*/
  }
  return (__int16)result; /*0x103c5ad3a*/
}

// Address: 0x103c5ad3b | Name: _WebRtcOpus_SetComplexity
int __fastcall WebRtcOpus_SetComplexity(_QWORD *a1, int a2, __int64 a3, int a4, int a5, int a6)
{
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5ad3e*/
  {
    if ( *a1 != 0 ) /*0x103c5ad4c*/
      LOWORD(result) = opus_encoder_ctl(a1: *a1, a2: 4010, a3: a2, a4, a5, a6); /*0x103c5ad58*/
    else
      LOWORD(result) = opus_multistream_encoder_ctl(a1: a1[1], a2: 4010, a3: a2, a4, a5, a6); /*0x103c5ad70*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5ad5f*/
  }
  return (__int16)result; /*0x103c5ad77*/
}

// Address: 0x103c5ad78 | Name: _WebRtcOpus_GetBandwidth
__int64 __fastcall WebRtcOpus_GetBandwidth(__int64 *a1, __int64 a2, __int64 a3, int a4, int a5, int a6)
{
  __int64 v7; // rdi
  int v8; // eax
  _DWORD v10[3]; // [rsp-Ch] [rbp-Ch] BYREF

  if ( a1 == nullptr ) /*0x103c5ad7b*/
    return 0xFFFFFFFFLL; /*0x103c5ada2*/
  v7 = *a1; /*0x103c5ad88*/
  if ( v7 != 0 ) /*0x103c5ad8e*/
    v8 = opus_encoder_ctl(a1: v7, a2: 4009, a3: (unsigned int)v10, a4, a5, a6); /*0x103c5ad9b*/
  else
    v8 = opus_multistream_encoder_ctl(a1: a1[1], a2: 4009, a3: (unsigned int)v10, a4, a5, a6); /*0x103c5adb7*/
  return v10[0] | (unsigned int)-(v8 != 0); /*0x103c5ada7*/
}

// Address: 0x103c5adcd | Name: _WebRtcOpus_SetBandwidth
int __fastcall WebRtcOpus_SetBandwidth(_QWORD *a1, int a2, __int64 a3, int a4, int a5, int a6)
{
  int result; // eax

  if ( a1 != nullptr ) /*0x103c5add0*/
  {
    if ( *a1 != 0 ) /*0x103c5adde*/
      LOWORD(result) = opus_encoder_ctl(a1: *a1, a2: 4008, a3: a2, a4, a5, a6); /*0x103c5adea*/
    else
      LOWORD(result) = opus_multistream_encoder_ctl(a1: a1[1], a2: 4008, a3: a2, a4, a5, a6); /*0x103c5ae02*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5adf1*/
  }
  return (__int16)result; /*0x103c5ae09*/
}

// Address: 0x103c5ae0a | Name: _WebRtcOpus_SetForceChannels
int __fastcall WebRtcOpus_SetForceChannels(__int64 *a1, unsigned __int64 a2, __int64 a3, int a4, int a5, int a6)
{
  int result; // eax
  int v7; // edx
  __int64 v8; // rdi
  __int64 v9; // rdi

  LOWORD(result) = -1; /*0x103c5ae0e*/
  if ( a1 != nullptr ) /*0x103c5ae15*/
  {
    v7 = a2; /*0x103c5ae17*/
    if ( a2 == 0 ) /*0x103c5ae1d*/
    {
      if ( *a1 != 0 ) /*0x103c5ae3d*/
      {
        v8 = *a1; /*0x103c5ae3f*/
        v7 = -1000; /*0x103c5ae47*/
        goto LABEL_8; /*0x103c5ae47*/
      }
      v9 = a1[1]; /*0x103c5ae55*/
      v7 = -1000; /*0x103c5ae5e*/
LABEL_11:
      LOWORD(result) = opus_multistream_encoder_ctl(a1: v9, a2: 4022, a3: v7, a4, a5, a6); /*0x103c5ae6e*/
      return (__int16)result; /*0x103c5ae70*/
    }
    if ( a2 <= 2 ) /*0x103c5ae23*/
    {
      if ( *a1 != 0 ) /*0x103c5ae2b*/
      {
        v8 = *a1; /*0x103c5ae2d*/
LABEL_8:
        LOWORD(result) = opus_encoder_ctl(a1: v8, a2: 4022, a3: v7, a4, a5, a6); /*0x103c5ae4c*/
        return (__int16)result; /*0x103c5ae53*/
      }
      v9 = a1[1]; /*0x103c5ae65*/
      goto LABEL_11; /*0x103c5ae65*/
    }
  }
  return (__int16)result; /*0x103c5ae76*/
}

// Address: 0x103c5ae78 | Name: _WebRtcOpus_DecoderCreate
__int64 __fastcall WebRtcOpus_DecoderCreate(__int64 **a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rax
  __int16 v4; // r13
  __int64 *v8; // rax
  __int64 *v9; // rbx
  __int64 v10; // rax
  int v12[11]; // [rsp+0h] [rbp-2Ch] BYREF

  v12[0] = HIDWORD(v3); /*0x103c5ae85*/
  v4 = -1; /*0x103c5ae86*/
  if ( a1 != nullptr ) /*0x103c5ae8e*/
  {
    v8 = (__int64 *)calloc(__count: 1u, __size: 0x28u); /*0x103c5aea3*/
    if ( v8 != nullptr ) /*0x103c5aeab*/
    {
      v9 = v8; /*0x103c5aead*/
      v10 = opus_decoder_create(a1: a3, (unsigned int)a2, a3: v12); /*0x103c5aeba*/
      *v9 = v10; /*0x103c5aebf*/
      if ( v12[0] != 0 || v10 == 0 ) /*0x103c5aecf*/
      {
        if ( v10 != 0 ) /*0x103c5aed9*/
          opus_decoder_destroy(a1: v10); /*0x103c5aede*/
        free(a1: v9); /*0x103c5aee6*/
      }
      else
      {
        v9[2] = a2; /*0x103c5aeed*/
        *((_DWORD *)v9 + 7) = a3; /*0x103c5aef1*/
        *((_DWORD *)v9 + 8) = a2; /*0x103c5aef5*/
        *a1 = v9; /*0x103c5aef9*/
        return 0; /*0x103c5aefc*/
      }
    }
  }
  return (unsigned int)v4; /*0x103c5af07*/
}

// Address: 0x103c5af12 | Name: _WebRtcOpus_MultistreamDecoderCreate
int __fastcall WebRtcOpus_MultistreamDecoderCreate(
        _QWORD *a1,
        __int64 a2,
        unsigned int a3,
        unsigned int a4,
        __int64 a5)
{
  int result; // eax
  _QWORD *v10; // rax
  _QWORD *v11; // r15
  __int64 v12; // rax
  int v13; // [rsp-3Ch] [rbp-3Ch]

  LOWORD(result) = -1; /*0x103c5af12*/
  if ( a1 != nullptr ) /*0x103c5af19*/
  {
    v10 = calloc(__count: 1u, __size: 0x28u); /*0x103c5af4a*/
    if ( v10 != nullptr ) /*0x103c5af52*/
    {
      v11 = v10; /*0x103c5af54*/
      v12 = opus_multistream_decoder_create(a1: 48000, a2, a3, a4, a5); /*0x103c5af70*/
      v11[1] = v12; /*0x103c5af75*/
      if ( v13 == 0 && v12 != 0 ) /*0x103c5af83*/
      {
        v11[2] = a2; /*0x103c5afa4*/
        *((_DWORD *)v11 + 7) = 48000; /*0x103c5afa8*/
        *a1 = v11; /*0x103c5afb0*/
        LOWORD(result) = 0; /*0x103c5afb3*/
        return (__int16)result; /*0x103c5afb3*/
      }
      opus_multistream_decoder_destroy(a1: v12); /*0x103c5af8d*/
      free(a1: v11); /*0x103c5af95*/
    }
    LOWORD(result) = -1; /*0x103c5af9a*/
  }
  return (__int16)result; /*0x103c5afc4*/
}

// Address: 0x103c5afc5 | Name: _WebRtcOpus_DecoderFree
int __fastcall WebRtcOpus_DecoderFree(__int64 *a1)
{
  __int64 v2; // rdi
  int result; // eax
  __int64 v4; // rdi

  if ( a1 != nullptr ) /*0x103c5afc8*/
  {
    v2 = *a1; /*0x103c5afd3*/
    if ( v2 != 0 ) /*0x103c5afd9*/
    {
      opus_decoder_destroy(a1: v2); /*0x103c5afdb*/
    }
    else
    {
      v4 = a1[1]; /*0x103c5afe8*/
      if ( v4 != 0 ) /*0x103c5afef*/
        opus_multistream_decoder_destroy(a1: v4); /*0x103c5aff1*/
    }
    free(a1); /*0x103c5aff9*/
    LOWORD(result) = 0; /*0x103c5affe*/
  }
  else
  {
    LOWORD(result) = -1; /*0x103c5afe2*/
  }
  return (__int16)result; /*0x103c5b007*/
}

// Address: 0x103c5b008 | Name: _WebRtcOpus_DecoderChannels
__int64 __fastcall WebRtcOpus_DecoderChannels(__int64 a1)
{
  return *(_QWORD *)(a1 + 16); /*0x103c5b010*/
}

// Address: 0x103c5b012 | Name: _WebRtcOpus_DecoderInit
__int64 __fastcall WebRtcOpus_DecoderInit(__int64 *a1, __int64 a2, int a3, int a4, int a5, int a6)
{
  char v6; // al
  __int64 v8; // rdi
  __int64 result; // rax

  v8 = *a1; /*0x103c5b01b*/
  if ( v8 != 0 ) /*0x103c5b021*/
    result = opus_decoder_ctl(a1: v8, a2: 4028, a3, a4, a5, a6, a7: v6); /*0x103c5b02a*/
  else
    result = opus_multistream_decoder_ctl(a1: a1[1], a2: 4028, a3, a4, a5, a6, a7: v6); /*0x103c5b03c*/
  *((_DWORD *)a1 + 6) = 0; /*0x103c5b041*/
  return result; /*0x103c5b04c*/
}

// Address: 0x103c5b04f | Name: _WebRtcOpus_Decode
__int64 __fastcall WebRtcOpus_Decode(__int64 a1, int a2, __int64 a3, int a4, _WORD *a5)
{
  char v6; // [rsp+Eh] [rbp-2h] BYREF

  if ( a3 != 0 ) /*0x103c5b060*/
    return DecodeNative(a1, a2, a3, a4: 120 * (*(_DWORD *)(a1 + 28) / 1000), a5: a4, a6: (_DWORD)a5, a7: 0); /*0x103c5b084*/
  *a5 = 2 * (*(_DWORD *)(a1 + 24) != 0); /*0x103c5b091*/
  return DecodeNative(a1, a2: 0, a3: 0, a4: 10 * (*(_DWORD *)(a1 + 28) / 1000), a5: a4, a6: (unsigned int)&v6, a7: 0); /*0x103c5b0c6*/
}

// Address: 0x103c5b1ae | Name: _WebRtcOpus_DecodeFec
__int64 __fastcall WebRtcOpus_DecodeFec(__int64 a1, unsigned __int8 *a2, int a3, int a4, int a5)
{
  int samples_per_frame; // eax

  if ( (unsigned int)WebRtcOpus_PacketHasFec(a1: a2) == 0 ) /*0x103c5b1d8*/
    return 0; /*0x103c5b205*/
  samples_per_frame = opus_packet_get_samples_per_frame(a1: a2, a2: *(unsigned int *)(a1 + 28)); /*0x103c5b1e1*/
  return DecodeNative(a1, (_DWORD)a2, a3, a4: samples_per_frame, a5: a4, a6: a5, a7: 1); /*0x103c5b20b*/
}

// Address: 0x103c5b216 | Name: _WebRtcOpus_PacketHasFec
__int64 __fastcall WebRtcOpus_PacketHasFec(unsigned __int8 *a1, __int64 a2)
{
  unsigned int v2; // r14d
  unsigned int v4; // r12d
  int v5; // eax
  int v6; // ebx
  int nb_channels; // r15d
  int v8; // ecx
  int v9; // ebx
  int v10; // edi
  int v11; // edx
  int v12; // esi
  int v13; // r8d
  unsigned __int8 *v15; // [rsp+0h] [rbp-210h] BYREF
  __int16 v16[48]; // [rsp+180h] [rbp-90h] BYREF

  v2 = 0; /*0x103c5b244*/
  if ( a1 != nullptr && a2 != 0 && (*a1 & 0x80u) == 0 ) /*0x103c5b255*/
  {
    v4 = a2; /*0x103c5b25b*/
    v5 = WebRtcOpus_NumSilkFrames(a1); /*0x103c5b261*/
    if ( v5 != 0 ) /*0x103c5b268*/
    {
      v6 = v5; /*0x103c5b26a*/
      nb_channels = opus_packet_get_nb_channels(a1); /*0x103c5b274*/
      v2 = 0; /*0x103c5b277*/
      if ( (int)opus_packet_parse(a1, a2: v4, a3: 0, a4: &v15, a5: v16, a6: 0) >= 0 && v16[0] > 0 ) /*0x103c5b2a4*/
      {
        v8 = v6; /*0x103c5b2a6*/
        v9 = v6 + 1; /*0x103c5b2af*/
        v10 = 0; /*0x103c5b2b1*/
        v11 = 0; /*0x103c5b2b6*/
        if ( nb_channels > 0 ) /*0x103c5b2bb*/
          v11 = nb_channels; /*0x103c5b2bb*/
        do /*0x103c5b2d4*/
        {
          v12 = v10; /*0x103c5b2bf*/
          if ( v11 == v10 ) /*0x103c5b2c3*/
            break; /*0x103c5b2c3*/
          v13 = *v15 << v8; /*0x103c5b2c9*/
          ++v10; /*0x103c5b2cc*/
          v8 += v9; /*0x103c5b2cf*/
        }
        while ( (v13 & 0x80u) == 0 ); /*0x103c5b2d4*/
        return v12 < nb_channels; /*0x103c5b2dc*/
      }
    }
  }
  return v2; /*0x103c5b2f3*/
}

// Address: 0x103c5b30a | Name: _WebRtcOpus_DurationEst
__int64 __fastcall WebRtcOpus_DurationEst(__int64 a1, __int64 a2, __int64 a3)
{
  int nb_frames; // eax
  int v6; // ecx
  __int64 result; // rax

  if ( a3 == 0 ) /*0x103c5b31a*/
    return (unsigned int)(10 * (*(_DWORD *)(a1 + 28) / 1000)); /*0x103c5b37e*/
  nb_frames = opus_packet_get_nb_frames(a1: a2, a2: (unsigned int)a3); /*0x103c5b324*/
  if ( nb_frames < 0 ) /*0x103c5b32b*/
    return 0; /*0x103c5b383*/
  v6 = nb_frames * opus_packet_get_samples_per_frame(a1: a2, a2: *(unsigned int *)(a1 + 28)); /*0x103c5b33d*/
  result = 0; /*0x103c5b35b*/
  if ( v6 <= 120 * *(_DWORD *)(a1 + 28) / 1000 ) /*0x103c5b35f*/
    return (unsigned int)v6; /*0x103c5b35f*/
  return result; /*0x103c5b389*/
}

// Address: 0x103c5b390 | Name: _WebRtcOpus_PlcDuration
__int64 __fastcall WebRtcOpus_PlcDuration(__int64 a1)
{
  return (unsigned int)(10 * (*(_DWORD *)(a1 + 28) / 1000)); /*0x103c5b3b1*/
}

// Address: 0x103c5b3b3 | Name: _WebRtcOpus_FecDurationEst
__int64 __fastcall WebRtcOpus_FecDurationEst(unsigned __int8 *a1, __int64 a2, signed int a3)
{
  int samples_per_frame; // ecx
  __int64 result; // rax

  if ( (unsigned int)WebRtcOpus_PacketHasFec(a1, a2) == 0 ) /*0x103c5b3c6*/
    return 0; /*0x103c5b404*/
  samples_per_frame = opus_packet_get_samples_per_frame(a1, a2: (unsigned int)a3); /*0x103c5b3d2*/
  result = (unsigned int)samples_per_frame; /*0x103c5b3f5*/
  if ( samples_per_frame > 120 * (a3 / 1000) ) /*0x103c5b3f7*/
    result = 0; /*0x103c5b3f7*/
  if ( samples_per_frame < 10 * (a3 / 1000) ) /*0x103c5b3ff*/
    return 0; /*0x103c5b3ff*/
  return result; /*0x103c5b406*/
}

// Address: 0x103c5b40b | Name: __Z24WebRtcOpus_NumSilkFramesPKh
__int64 __fastcall WebRtcOpus_NumSilkFrames(const unsigned __int8 *a1)
{
  int v1; // eax
  int v2; // edx
  __int64 result; // rax
  unsigned int v4; // ecx

  v1 = (int)opus_packet_get_samples_per_frame(a1, a2: 48000) / 48; /*0x103c5b42d*/
  v2 = 10; /*0x103c5b432*/
  if ( v1 >= 11 ) /*0x103c5b437*/
    v2 = v1; /*0x103c5b437*/
  result = 0; /*0x103c5b43a*/
  if ( v2 > 39 ) /*0x103c5b43f*/
  {
    if ( v2 == 60 ) /*0x103c5b455*/
    {
      return 3; /*0x103c5b463*/
    }
    else
    {
      if ( v2 != 40 ) /*0x103c5b45a*/
        return result; /*0x103c5b45a*/
      return 2; /*0x103c5b45c*/
    }
  }
  v4 = 1; /*0x103c5b441*/
  if ( v2 == 10 || v2 == 20 ) /*0x103c5b44e*/
    return v4; /*0x103c5b468*/
  return result; /*0x103c5b46a*/
}

// Address: 0x103c5b46c | Name: _WebRtcOpus_PacketHasVoiceActivity
__int64 __fastcall WebRtcOpus_PacketHasVoiceActivity(unsigned __int8 *a1, __int64 a2)
{
  unsigned int v2; // r15d
  unsigned int v4; // r12d
  int v5; // eax
  char v6; // bl
  int nb_channels; // r14d
  int v8; // eax
  char v9; // dl
  char v10; // bl
  bool v11; // si
  unsigned __int64 v12; // r8
  __int64 v13; // rcx
  _BYTE v16[384]; // [rsp+8h] [rbp-210h] BYREF
  _BYTE v17[96]; // [rsp+188h] [rbp-90h] BYREF

  v2 = 0; /*0x103c5b49a*/
  if ( a1 != nullptr && a2 != 0 ) /*0x103c5b497*/
  {
    v2 = -1; /*0x103c5b4a8*/
    if ( (*a1 & 0x80u) == 0 ) /*0x103c5b4b1*/
    {
      v4 = a2; /*0x103c5b4b7*/
      v5 = WebRtcOpus_NumSilkFrames(a1); /*0x103c5b4bd*/
      if ( v5 != 0 ) /*0x103c5b4c4*/
      {
        v6 = v5; /*0x103c5b4ca*/
        nb_channels = opus_packet_get_nb_channels(a1); /*0x103c5b4d4*/
        v2 = 0; /*0x103c5b4d7*/
        v8 = opus_packet_parse(a1, a2: v4, a3: 0, a4: v16, a5: v17, a6: 0); /*0x103c5b4f3*/
        if ( v8 < 0 ) /*0x103c5b4fa*/
        {
          return (unsigned int)-1; /*0x103c5b573*/
        }
        else if ( v8 != 0 ) /*0x103c5b4fc*/
        {
          v9 = 8 - v6; /*0x103c5b503*/
          v10 = v6 + 1; /*0x103c5b505*/
          v11 = true; /*0x103c5b50f*/
          v12 = 1; /*0x103c5b512*/
          do /*0x103c5b567*/
          {
            if ( *(__int16 *)&v16[2 * v12 + 382] > 0 /*0x103c5b550*/
              && (**(unsigned __int8 **)&v16[8 * v12 - 8] >> v9 != 0
               || nb_channels == 2 && (unsigned int)(**(unsigned __int8 **)&v16[8 * v12 - 8] << v10) >> v9 != 0) )
            {
              break; /*0x103c5b550*/
            }
            v11 = v12 < (unsigned int)v8; /*0x103c5b555*/
            v13 = v12 - (unsigned int)v8 + 1; /*0x103c5b55d*/
            ++v12; /*0x103c5b560*/
          }
          while ( v13 != 1 ); /*0x103c5b567*/
          return v11; /*0x103c5b56d*/
        }
      }
    }
  }
  return v2; /*0x103c5b58c*/
}

// Address: 0x103c5b77a | Name: _WebRtcPcm16b_Encode
__int64 __fastcall WebRtcPcm16b_Encode(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 i; // rcx

  if ( a2 != 0 ) /*0x103c5b784*/
  {
    for ( i = 0; i != a2; ++i ) /*0x103c5b786*/
      *(_WORD *)(a3 + 2 * i) = __ROL2__(*(_WORD *)(a1 + 2 * i), 8); /*0x103c5b790*/
  }
  return 2 * a2; /*0x103c5b79f*/
}

// Address: 0x103c5b7a1 | Name: _WebRtcPcm16b_Decode
unsigned __int64 __fastcall WebRtcPcm16b_Decode(__int64 a1, unsigned __int64 a2, __int64 a3)
{
  unsigned __int64 result; // rax
  __int64 v4; // rcx

  result = a2 >> 1; /*0x103c5b7a8*/
  if ( a2 >= 2 ) /*0x103c5b7af*/
  {
    v4 = 0; /*0x103c5b7b1*/
    do /*0x103c5b7c5*/
    {
      *(_WORD *)(a3 + 2 * v4) = __ROL2__(*(_WORD *)(a1 + 2 * v4), 8); /*0x103c5b7bb*/
      ++v4; /*0x103c5b7bf*/
    }
    while ( result != v4 ); /*0x103c5b7c5*/
  }
  return result; /*0x103c5b7c7*/
}

// Address: 0x103cd1944 | Name: __ZN6webrtceqERKNS_24FrameDependencyStructureES2_
char __fastcall webrtc::operator==(__int64 a1, __int64 a2)
{
  __int64 v4; // rbx
  __int64 v5; // r12
  __int64 v6; // r15
  char result; // al

  if ( *(_DWORD *)(a1 + 4) != *(_DWORD *)(a2 + 4) ) /*0x103cd194a*/
    return 0; /*0x103cd19c8*/
  if ( *(_DWORD *)(a1 + 8) != *(_DWORD *)(a2 + 8) ) /*0x103cd1963*/
    return 0; /*0x103cd1963*/
  if ( !absl::lts_20240116::operator==<int,10ul,std::allocator<int>>(a1: (_QWORD *)(a1 + 16), a2: (_QWORD *)(a2 + 16)) ) /*0x103cd196d*/
    return 0; /*0x103cd196d*/
  if ( !absl::lts_20240116::operator==<webrtc::RenderResolution,4ul,std::allocator<webrtc::RenderResolution>>( /*0x103cd197e*/
          a1: (unsigned __int64 *)(a1 + 64),
          a2: (unsigned __int64 *)(a2 + 64)) )
    return 0; /*0x103cd197e*/
  v4 = *(_QWORD *)(a1 + 104); /*0x103cd1987*/
  v5 = *(_QWORD *)(a1 + 112); /*0x103cd198b*/
  v6 = *(_QWORD *)(a2 + 104); /*0x103cd1995*/
  if ( v5 - v4 != *(_QWORD *)(a2 + 112) - v6 ) /*0x103cd19a3*/
    return 0; /*0x103cd19cb*/
  if ( v4 == v5 ) /*0x103cd19a8*/
    return 1; /*0x103cd19d6*/
  do /*0x103cd19c4*/
  {
    result = webrtc::operator==(a1: v4, a2: v6); /*0x103cd19b0*/
    if ( result == 0 ) /*0x103cd19b7*/
      break; /*0x103cd19b7*/
    v4 += 104; /*0x103cd19b9*/
    v6 += 104; /*0x103cd19bd*/
  }
  while ( v4 != v5 ); /*0x103cd19c4*/
  return result; /*0x103cd19ca*/
}

// Address: 0x103cd3f55 | Name: __ZN6webrtceqERKNS_23FrameDependencyTemplateES2_
bool __fastcall webrtc::operator==(__int64 a1, __int64 a2)
{
  return *(_DWORD *)a1 == *(_DWORD *)a2 /*0x103cd3fa0*/
      && *(_DWORD *)(a1 + 4) == *(_DWORD *)(a2 + 4)
      && absl::lts_20240116::operator==<webrtc::DecodeTargetIndication,10ul,std::allocator<webrtc::DecodeTargetIndication>>(
           a1: (unsigned __int64 *)(a1 + 8),
           a2: (unsigned __int64 *)(a2 + 8))
      && absl::lts_20240116::operator==<int,4ul,std::allocator<int>>(a1: (_QWORD *)(a1 + 56), a2: (_QWORD *)(a2 + 56))
      && absl::lts_20240116::operator==<int,4ul,std::allocator<int>>(a1: (_QWORD *)(a1 + 80), a2: (_QWORD *)(a2 + 80));
}

// Address: 0x103cd40a2 | Name: __ZN6webrtceqERKNS_10ColorSpaceES2_
__int64 __fastcall webrtc::operator==(__int64 a1, __int64 a2)
{
  if ( *(_BYTE *)a1 == *(_BYTE *)a2 /*0x103cd40d2*/
    && *(_BYTE *)(a1 + 1) == *(_BYTE *)(a2 + 1)
    && *(_BYTE *)(a1 + 2) == *(_BYTE *)(a2 + 2)
    && *(_DWORD *)(a1 + 4) == *(_DWORD *)(a2 + 4)
    && *(_DWORD *)(a1 + 8) == *(_DWORD *)(a2 + 8)
    && *(_DWORD *)(a1 + 12) == *(_DWORD *)(a2 + 12) )
  {
    return std::operator==[abi:ne200100]<webrtc::HdrMetadata,webrtc::HdrMetadata>(a1: a1 + 16, a2: a2 + 16); /*0x103cd40dd*/
  }
  else
  {
    return 0; /*0x103cd40e2*/
  }
}

// Address: 0x103cde608 | Name: _WebRtc_g722_decode_init
_DWORD *__fastcall WebRtc_g722_decode_init(_DWORD *a1, int a2, unsigned __int8 a3)
{
  _DWORD *v5; // r14
  char v6; // al
  int v7; // ecx

  v5 = a1; /*0x103cde617*/
  if ( a1 == nullptr ) /*0x103cde61d*/
    v5 = malloc(__size: 0x1E8u); /*0x103cde629*/
  __bzero(a1: v5, a2: 488); /*0x103cde634*/
  v6 = 1; /*0x103cde639*/
  if ( a2 == 48000 ) /*0x103cde642*/
  {
    v7 = 6; /*0x103cde654*/
  }
  else if ( a2 == 56000 ) /*0x103cde64b*/
  {
    v7 = 7; /*0x103cde64d*/
  }
  else
  {
    v7 = 8; /*0x103cde65b*/
    v6 = 0; /*0x103cde660*/
  }
  v5[3] = v7; /*0x103cde662*/
  if ( (a3 & 1) != 0 ) /*0x103cde669*/
    v5[2] = 1; /*0x103cde66b*/
  v5[1] = (unsigned __int8)v6 & (a3 >> 1); /*0x103cde67a*/
  v5[72] = 32; /*0x103cde67e*/
  v5[117] = 8; /*0x103cde689*/
  return v5; /*0x103cde69b*/
}

// Address: 0x103cde6a2 | Name: _WebRtc_g722_decode_release
__int64 __fastcall WebRtc_g722_decode_release(void *a1)
{
  free(a1); /*0x103cde6a6*/
  return 0; /*0x103cde6ad*/
}

// END _free_w part 1/4, 400 functions
