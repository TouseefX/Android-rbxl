// DeserializingJoinDataItemV2 -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 8 functions


// Address: 0x1067f0302 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV227DeserializingJoinDataItemV28prepWorkERNS0_13NetworkStreamE
void __fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::prepWork(
        const __m128i **this,
        RBX::Network::NetworkStream *a2)
{
  int v4; // ecx
  int v5; // eax
  float v6; // xmm0_4
  const __m128i *v7; // rcx
  const __m128i *v8; // rcx
  int UInt32; // eax
  RBX::Network::NetworkStream *v10; // rdx
  int v11; // r15d
  __int64 v12; // rsi
  unsigned int v13; // eax
  RBX::Network::NetworkStream *v14; // rdx
  __int64 v15; // rdi
  __int64 v16; // r13
  unsigned __int64 v17; // r15
  RBX::Network::NetworkStream *v18; // rdx
  unsigned int v19; // eax
  unsigned int v20; // ecx
  __int64 v21; // rsi
  unsigned __int64 v22; // rax
  __int64 v23; // rax
  __int64 v24; // rdx
  char *exception; // rbx
  __int64 v26; // rdx
  __int64 v27; // rcx
  __int64 v28; // [rsp+8h] [rbp-58h] BYREF
  __m128i v29; // [rsp+10h] [rbp-50h] BYREF
  __int64 v30; // [rsp+20h] [rbp-40h]
  int v31; // [rsp+2Ch] [rbp-34h]
  __int64 *v32; // [rsp+30h] [rbp-30h]

  if ( *((_BYTE *)this + 80) == 0 ) /*0x1067f0317*/
  {
    if ( (*this)[1168].i8[13] == 0 ) /*0x1067f0338*/
      (*this)[982].i64[1] = _mm_add_epi32( /*0x1067f0361*/
                              _mm_insert_epi32(
                                _mm_cvtepi8_epi32(16843009),
                                (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)a2 + 24LL))(a1: a2),
                                0),
                              _mm_loadl_epi64((const __m128i *)((char *)*this + 15720))).u64[0];
    *((_BYTE *)this + 80) = 1; /*0x1067f0369*/
    *((_DWORD *)this + 2) = (unsigned __int8)RBX::Network::NetworkStream::readByte(this: a2); /*0x1067f0378*/
    *((float *)this + 40) = (float)(*((_DWORD *)a2 + 12) - *((_DWORD *)a2 + 14)); /*0x1067f038b*/
    RBX::Network::Replicator::decompressBitStream(this: a2); /*0x1067f039c*/
    v4 = *((_DWORD *)this + 2); /*0x1067f03a1*/
    v5 = *((_DWORD *)this + 16); /*0x1067f03a4*/
    v6 = *((float *)this + 40); /*0x1067f03af*/
    *((float *)this + 39) = (float)v5 / v6; /*0x1067f03bb*/
    if ( ((unsigned __int8)DFFlag::BatchNetAssetJoinBlobEnable & (v4 == 5)) == 1 ) /*0x1067f03d8*/
    {
      v7 = *this; /*0x1067f03da*/
      v7[979].i32[3] = (int)(float)((float)(*this)[979].i32[3] + v6); /*0x1067f03f4*/
      v7[980].i32[0] += v5; /*0x1067f03fa*/
      RBX::Network::LargeReplicator::addBatchRecvCompressedBytes( /*0x1067f041a*/
        this: (RBX::Network::LargeReplicator *)v7[700].i64[0],
        a2: (int)v6);
    }
    else if ( v4 == 1 ) /*0x1067f0422*/
    {
      v8 = *this; /*0x1067f0424*/
      v8[979].i32[0] = (int)(float)(v6 + (float)(*this)[979].i32[0]); /*0x1067f043e*/
      v8[979].i32[1] += v5; /*0x1067f0444*/
    }
    else
    {
      UInt32 = RBX::Network::NetworkStream::readUInt32(this: a2); /*0x1067f0452*/
      *((_DWORD *)this + 21) = UInt32; /*0x1067f0457*/
      (*this)[978].i32[3] += 4; /*0x1067f045d*/
      LOBYTE(v10) = (unsigned __int8)DFLog::ReplicationDataCaching < 6u; /*0x1067f0478*/
      if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u ) /*0x1067f047e*/
        FLog::FastLog( /*0x1067f0493*/
          a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
          a2: qword_10D7F3E28,
          a3: "[DFLog::ReplicationDataCaching] Expecting %d instances",
          UInt32);
      v11 = *((_DWORD *)a2 + 14); /*0x1067f0498*/
      RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)(this + 12), (unsigned int *)a2, a3: v10); /*0x1067f04a6*/
      v12 = *((unsigned int *)this + 24); /*0x1067f04af*/
      v28 = 0; /*0x1067f04b6*/
      v32 = (__int64 *)(this + 13); /*0x1067f04bd*/
      std::vector<RBX::Network::InvalidReplicationMetaData>::assign(a1: this + 13, a2: v12, a3: &v28); /*0x1067f04c1*/
      v13 = *((_DWORD *)this + 24); /*0x1067f04c9*/
      (*this)[981].i64[0] = _mm_add_epi32( /*0x1067f04e3*/
                              _mm_insert_epi32(_mm_cvtsi32_si128(v13), *((_DWORD *)this + 21), 1),
                              _mm_loadl_epi64(*this + 981)).u64[0];
      LOBYTE(v14) = (unsigned __int8)DFLog::ReplicationDataCaching < 6u; /*0x1067f04f8*/
      if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u ) /*0x1067f04fe*/
      {
        FLog::FastLog( /*0x1067f0514*/
          a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
          a2: qword_10D7F3E28,
          a3: "[DFLog::ReplicationDataCaching] Expecting #%d invalid metaData in this blob",
          v13);
        v13 = *((_DWORD *)this + 24); /*0x1067f0519*/
      }
      if ( v13 != 0 ) /*0x1067f0522*/
      {
        v31 = v11; /*0x1067f0528*/
        v15 = *v32; /*0x1067f0530*/
        v16 = 4; /*0x1067f0533*/
        v17 = 0; /*0x1067f0539*/
        do /*0x1067f05db*/
        {
          RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)(v16 + v15 - 4), (unsigned int *)a2, a3: v14); /*0x1067f0546*/
          RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)(v16 + *v32), (unsigned int *)a2, a3: v18); /*0x1067f0558*/
          if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u ) /*0x1067f0575*/
            FLog::FastLog( /*0x1067f05a1*/
              a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
              a2: qword_10D7F3E28,
              a3: "[DFLog::ReplicationDataCaching] Invalid offset %d  length %d",
              *(_DWORD *)(*v32 + v16 - 4),
              *(_DWORD *)(*v32 + v16));
          v15 = (__int64)*(this + 13); /*0x1067f05a9*/
          v19 = *(_DWORD *)(v15 + v16); /*0x1067f05ad*/
          (*this)[980].i32[3] += v19; /*0x1067f05b1*/
          v20 = *(_DWORD *)(v15 + v16 - 4); /*0x1067f05b7*/
          v14 = (RBX::Network::NetworkStream *)*((unsigned int *)this + 16); /*0x1067f05bc*/
          if ( v20 > (unsigned int)v14 || v19 > (unsigned int)v14 || v19 + v20 > (unsigned int)v14 ) /*0x1067f05cb*/
          {
            exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x1067f0632*/
            std::string::basic_string[abi:ne200100]<0>( /*0x1067f0640*/
              a1: &v29,
              a2: "Offset index of JDIv2 larger than bitstream length",
              a3: v26,
              a4: v27);
            *(_QWORD *)exception = off_10CAA98E0; /*0x1067f064c*/
            *((_QWORD *)exception + 3) = v30; /*0x1067f0653*/
            *(__m128i *)(exception + 8) = _mm_load_si128(&v29); /*0x1067f065c*/
            v29 = 0; /*0x1067f0665*/
            v30 = 0; /*0x1067f066a*/
            __cxa_throw( /*0x1067f0683*/
              a1: exception,
              lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
              a3: RBX::network_stream_exception::~network_stream_exception);
          }
          ++v17; /*0x1067f05cd*/
          v16 += 8; /*0x1067f05d4*/
        }
        while ( v17 < *((unsigned int *)this + 24) ); /*0x1067f05db*/
        v21 = (__int64)*(this + 14); /*0x1067f05e1*/
        _BitScanReverse64(&v22, (v21 - v15) >> 3); /*0x1067f05ef*/
        v23 = (2 * ((unsigned int)v22 ^ 0x3F)) ^ 0x7ELL; /*0x1067f05f8*/
        v24 = 0; /*0x1067f05fc*/
        if ( v21 != v15 ) /*0x1067f0601*/
          v24 = v23; /*0x1067f0601*/
        std::__introsort<std::_ClassicAlgPolicy,RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::prepWork(RBX::Network::NetworkStream &)::$_0 &,RBX::Network::InvalidReplicationMetaData *,false>( /*0x1067f060a*/
          a1: v15,
          a2: v21,
          a3: v24,
          a4: 1);
        v11 = v31; /*0x1067f060f*/
      }
      (*this)[978].i32[3] += *((_DWORD *)a2 + 14) - v11; /*0x1067f061d*/
    }
  }
}

// Address: 0x1067f06b2 | Name: __ZNK3RBX7Network10Replicator14JoinDataItemV227DeserializingJoinDataItemV236getIsStillDeserializingCurrentStreamEv
char __fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::getIsStillDeserializingCurrentStream(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this)
{
  return *((_BYTE *)this + 80); /*0x1067f06b9*/
}

// Address: 0x1067f07e4 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV227DeserializingJoinDataItemV24readERNS0_13NetworkStreamE
RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *__fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::read(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this,
        const __m128i **a2,
        RBX::Network::NetworkStream *a3)
{
  unsigned int v6; // ebx
  __int64 v7; // rdi
  __int64 v8; // rdi
  int v9; // eax
  bool v10; // zf
  RBX::TaskScheduler *v11; // rdi
  __int64 v12; // rax
  const __m128i *v13; // rcx
  RakNet *v14; // rdi
  unsigned int v15; // esi
  float v16; // xmm0_4
  float *v17; // rax
  int v18; // ecx
  double v20; // [rsp+0h] [rbp-30h]
  _QWORD v21[5]; // [rsp+8h] [rbp-28h] BYREF

  v6 = RBX::Memory::setCurrentCategory( /*0x1067f080a*/
         this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkReplicatedInstances,
         (unsigned int)a2);
  v20 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v7); /*0x1067f0811*/
  RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::prepWork(this: a2, a2: a3); /*0x1067f081c*/
  *(_QWORD *)this = 0; /*0x1067f0821*/
  v9 = *((_DWORD *)a2 + 2); /*0x1067f0828*/
  if ( (unsigned int)(v9 - 2) < 3 ) /*0x1067f0832*/
  {
    RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::readAnInstance(this: (RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *)v21); /*0x1067f083b*/
    *(_QWORD *)this = v21[0]; /*0x1067f0844*/
    v10 = *((_DWORD *)a2 + 22) == *((_DWORD *)a2 + 21); /*0x1067f084b*/
LABEL_6:
    *((_BYTE *)a2 + 80) = !v10; /*0x1067f087d*/
    goto LABEL_8; /*0x1067f0882*/
  }
  if ( v9 != 1 ) /*0x1067f0854*/
  {
    if ( v9 != 5 ) /*0x1067f0859*/
      goto LABEL_8; /*0x1067f0859*/
    RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::readBatchedNetAssets(this: (RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *)v21); /*0x1067f0866*/
    *(_QWORD *)this = v21[0]; /*0x1067f086f*/
    v10 = (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: (RBX::Network::NetworkStream *)(a2 + 2)) == 0; /*0x1067f087b*/
    goto LABEL_6; /*0x1067f087b*/
  }
  RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::readASharedString(this: (RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *)v21); /*0x1067f088b*/
  *(_QWORD *)this = v21[0]; /*0x1067f0894*/
  *((_BYTE *)a2 + 80) = (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: (RBX::Network::NetworkStream *)(a2 + 2)) != 0; /*0x1067f08a2*/
  (*a2)[999].i64[1] = (*a2)[1149].i64[1]; /*0x1067f08b1*/
  v12 = RBX::TaskScheduler::cycle(this: v11); /*0x1067f08b8*/
  v13 = *a2; /*0x1067f08bd*/
  v13[1000].i64[0] = v12; /*0x1067f08c0*/
  v13[1000].i32[2] = v13[1150].i32[0]; /*0x1067f08cd*/
  (*a2)[1000].i32[3] = RakNet::GetTimeMS(this: v14); /*0x1067f08db*/
LABEL_8:
  v16 = (RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v8) - v20) * 1000.0; /*0x1067f08e6*/
  v17 = (float *)*a2; /*0x1067f08fc*/
  *(float *)(*a2)[977].i32 = *(float *)(*a2)[977].i32 + v16; /*0x1067f090b*/
  v18 = *((_DWORD *)a2 + 2); /*0x1067f0913*/
  if ( (unsigned int)(v18 - 2) >= 3 ) /*0x1067f091d*/
  {
    if ( v18 == 1 ) /*0x1067f0934*/
    {
      v17[3909] = v16 + v17[3909]; /*0x1067f0955*/
    }
    else if ( v18 == 5 ) /*0x1067f0939*/
    {
      v17[3922] = v16 + v17[3922]; /*0x1067f0943*/
    }
  }
  else
  {
    v17[3910] = v16 + v17[3910]; /*0x1067f0927*/
  }
  if ( *((_BYTE *)a2 + 80) == 0 ) /*0x1067f0962*/
    RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::reset(this: (RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *)a2); /*0x1067f0967*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v6, a2: v15); /*0x1067f096e*/
  return this; /*0x1067f0976*/
}

// Address: 0x1067f09ce | Name: __ZN3RBX7Network10Replicator14JoinDataItemV227DeserializingJoinDataItemV217readASharedStringEv
RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *__fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::readASharedString(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this,
        RBX::Network::Replicator **a2)
{
  __int64 v2; // rax
  RBX::Network::NetworkStream *v5; // r15
  _QWORD v7[6]; // [rsp+0h] [rbp-30h] BYREF

  v7[0] = v2; /*0x1067f09db*/
  v5 = (RBX::Network::NetworkStream *)(a2 + 2); /*0x1067f09e2*/
  while ( (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: v5) != 0 ) /*0x1067f09f0*/
  {
    if ( (unsigned __int8)RBX::Network::Replicator::deserializationTimeLimitReached(this: *a2) != 0 ) /*0x1067f0a04*/
      break; /*0x1067f0a04*/
    ++*((_DWORD *)*a2 + 3918); /*0x1067f0a09*/
    RBX::SharedString::SharedString(this: (RBX::SharedString *)v7); /*0x1067f0a12*/
    RBX::Network::Replicator::readANewSharedString( /*0x1067f0a2a*/
      a1: *a2,
      a2: v5,
      a3: v7,
      a4: (char *)*a2 + 11720,
      a5: (char *)a2 + 81);
    RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v7); /*0x1067f0a32*/
  }
  *(_QWORD *)this = 0; /*0x1067f0a43*/
  return this; /*0x1067f0a51*/
}

// Address: 0x1067f0a70 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV227DeserializingJoinDataItemV220readBatchedNetAssetsEv
RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *__fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::readBatchedNetAssets(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this,
        __int64 a2)
{
  RBX::Network::NetworkStream *v3; // r15
  unsigned int UInt32VarInt; // r13d
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // r9
  void *v9; // rsi
  RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *result; // rax
  char *exception; // r14
  __int64 v12; // rdx
  __int64 v13; // rcx
  _BYTE v14[24]; // [rsp+18h] [rbp-A8h] BYREF
  _BYTE v15[8]; // [rsp+30h] [rbp-90h] BYREF
  void *v16; // [rsp+38h] [rbp-88h]
  void *v17; // [rsp+40h] [rbp-80h]
  __int64 v18; // [rsp+60h] [rbp-60h] BYREF
  __int64 v19; // [rsp+68h] [rbp-58h]
  __int64 v20; // [rsp+70h] [rbp-50h]
  RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *v21; // [rsp+78h] [rbp-48h]
  __int128 v22; // [rsp+80h] [rbp-40h] BYREF
  __int64 v23; // [rsp+90h] [rbp-30h]

  v21 = this; /*0x1067f0a87*/
  v3 = (RBX::Network::NetworkStream *)(a2 + 16); /*0x1067f0a8b*/
  while ( (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: v3) != 0 ) /*0x1067f0a99*/
  {
    if ( (unsigned __int8)RBX::Network::Replicator::deserializationTimeLimitReached(this: *(RBX::Network::Replicator **)a2) != 0 ) /*0x1067f0ab7*/
      break; /*0x1067f0ab7*/
    RBX::Network::NetworkStreamContext::NetworkStreamContext( /*0x1067f0ad8*/
      a1: v14,
      a2: *(unsigned int *)(*(_QWORD *)(*(_QWORD *)a2 + 11200LL) + 6900LL),
      a3: *(unsigned int *)(*(_QWORD *)(*(_QWORD *)a2 + 11200LL) + 6904LL),
      a4: 0);
    v18 = 0; /*0x1067f0add*/
    LODWORD(v19) = 0; /*0x1067f0ae5*/
    LOWORD(v20) = 0; /*0x1067f0aec*/
    RBX::Network::Serializer<RBX::Network::NetAssetHandle>::deserialize(a1: v14, a2: v3, a3: &v18); /*0x1067f0afc*/
    UInt32VarInt = RBX::Network::NetworkStream::readUInt32VarInt(this: v3); /*0x1067f0b09*/
    if ( UInt32VarInt > (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: v3) ) /*0x1067f0b17*/
    {
      exception = (char *)__cxa_allocate_exception(thrown_size: 0x20u); /*0x1067f0bb5*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v22, a2: "NetAsset Batch Size Issue", a3: v12, a4: v13); /*0x1067f0bc3*/
      *(_QWORD *)exception = off_10CAA98E0; /*0x1067f0bcf*/
      *((_QWORD *)exception + 3) = v23; /*0x1067f0bd6*/
      *(_OWORD *)(exception + 8) = v22; /*0x1067f0bde*/
      v22 = 0; /*0x1067f0be6*/
      v23 = 0; /*0x1067f0bea*/
      __cxa_throw( /*0x1067f0c03*/
        a1: exception,
        lptinfo: (struct type_info *)&`typeinfo for'RBX::network_stream_exception,
        a3: RBX::network_stream_exception::~network_stream_exception);
    }
    RBX::Network::NetworkStreamContent::NetworkStreamContent( /*0x1067f0b2d*/
      this: (RBX::Network::NetworkStreamContent *)v15,
      a2: (unsigned __int8 *)(*(_QWORD *)(a2 + 32) + *(unsigned int *)(a2 + 72)),
      a3: UInt32VarInt,
      a4: false);
    RBX::Network::NetworkStream::IgnoreBytes(this: v3, a2: UInt32VarInt); /*0x1067f0b38*/
    RBX::Network::LargeReplicator::fastInlineReceive( /*0x1067f0b5b*/
      a1: *(_QWORD *)(*(_QWORD *)a2 + 11200LL),
      a2: v15,
      a3: v5,
      a4: v6,
      a5: v7,
      a6: v8,
      a7: v18,
      a8: v19,
      a9: v20);
    ++*(_DWORD *)(*(_QWORD *)a2 + 15684LL); /*0x1067f0b63*/
    if ( v16 != nullptr ) /*0x1067f0b73*/
    {
      v17 = v16; /*0x1067f0b75*/
      operator delete(a1: (RBX::Memory *)v16, a2: v9); /*0x1067f0b79*/
    }
  }
  result = v21; /*0x1067f0b8e*/
  *(_QWORD *)v21 = 0; /*0x1067f0b92*/
  return result; /*0x1067f0b99*/
}

// Address: 0x1067f0c46 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV227DeserializingJoinDataItemV214readAnInstanceEv
RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *__fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::readAnInstance(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this,
        __int64 a2)
{
  RBX::Network::NetworkStream *v3; // r12
  __int64 v4; // r13
  unsigned __int64 v5; // rsi
  __int64 v6; // rax
  int v7; // ecx
  __int64 v8; // rdx
  unsigned __int64 v9; // rax
  __int64 v10; // rdx
  bool v11; // cl
  RBX::Network::DeserializedNewObjectItem *v12; // rcx
  FLog *v13; // rbx
  void *v14; // rsi
  void *v15; // rsi
  RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *result; // rax
  char v17; // [rsp+10h] [rbp-130h] BYREF
  void *v18; // [rsp+20h] [rbp-120h]
  __int64 v19; // [rsp+28h] [rbp-118h]
  RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *v20; // [rsp+30h] [rbp-110h]
  _BYTE v21[16]; // [rsp+38h] [rbp-108h] BYREF
  float v22; // [rsp+48h] [rbp-F8h]
  int v23; // [rsp+88h] [rbp-B8h] BYREF
  __int64 v24; // [rsp+A4h] [rbp-9Ch]

  v20 = this; /*0x1067f0c68*/
  *(_QWORD *)this = 0; /*0x1067f0c6f*/
  if ( *(_DWORD *)(a2 + 88) >= *(_DWORD *)(a2 + 84) )
  {
    v4 = 0; /*0x1067f0efb*/
  }
  else
  {
    v3 = (RBX::Network::NetworkStream *)(a2 + 16); /*0x1067f0c85*/
    v4 = 0; /*0x1067f0c89*/
    do
    {
      if ( (unsigned __int8)RBX::Network::Replicator::deserializationTimeLimitReached(this: *(RBX::Network::Replicator **)a2) != 0 ) /*0x1067f0ca4*/
        break; /*0x1067f0ca4*/
      if ( v4 == 0 ) /*0x1067f0cad*/
      {
        v4 = operator new(a1: (RBX::Memory *)0x40, a2: v5); /*0x1067f0cb9*/
        RBX::Network::DeserializedJoinDataItem::DeserializedJoinDataItem(a1: v4, a2: 22); /*0x1067f0cc4*/
      }
      RBX::Network::DeserializedNewObjectItem::DeserializedNewObjectItem(this: (RBX::Network::DeserializedNewObjectItem *)v21); /*0x1067f0ccc*/
      while ( 1 )
      {
        LODWORD(v6) = *(_DWORD *)(a2 + 92); /*0x1067f0cd1*/
        if ( (unsigned int)v6 >= *(_DWORD *)(a2 + 96) ) /*0x1067f0cd9*/
          break; /*0x1067f0cd9*/
        v7 = *(_DWORD *)(a2 + 72); /*0x1067f0cdf*/
        v6 = (unsigned int)v6; /*0x1067f0ce3*/
        v8 = *(_QWORD *)(a2 + 104); /*0x1067f0ce5*/
        if ( v7 != *(_DWORD *)(v8 + 8LL * (unsigned int)v6) ) /*0x1067f0cec*/
          break; /*0x1067f0cec*/
        if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u )
        {
          FLog::FastLog(
            a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
            a2: qword_10D7F3E28,
            a3: "[DFLog::ReplicationDataCaching] Skipping offset %u  length : %u",
            v7,
            *(_DWORD *)(v8 + 8LL * (unsigned int)v6 + 4));
          v6 = *(unsigned int *)(a2 + 92); /*0x1067f0d27*/
          v8 = *(_QWORD *)(a2 + 104); /*0x1067f0d2b*/
        }
        RBX::Network::NetworkStream::IgnoreBytes(this: v3, a2: *(_DWORD *)(v8 + 8 * v6 + 4)); /*0x1067f0d36*/
        v9 = (unsigned int)(*(_DWORD *)(a2 + 92) + 1); /*0x1067f0d3f*/
        *(_DWORD *)(a2 + 92) = v9; /*0x1067f0d41*/
        v10 = *(_QWORD *)(a2 + 104); /*0x1067f0d49*/
        v11 = (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u; /*0x1067f0d6a*/
        if ( (*(_QWORD *)(a2 + 112) - v10) >> 3 <= v9 )
        {
          if ( v11 ) /*0x1067f0d9d*/
            FLog::FastLog( /*0x1067f0db0*/
              a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
              a2: qword_10D7F3E28,
              a3: "[DFLog::ReplicationDataCaching] No more invalid caches in blob",
              0);
        }
        else if ( v11 )
        {
          FLog::FastLog(
            a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
            a2: qword_10D7F3E28,
            a3: "[DFLog::ReplicationDataCaching] Next anticipated read at offset %d  (unless invalid),  next invalid offset : %u",
            *(_DWORD *)(a2 + 72),
            *(_DWORD *)(v10 + 8 * v9 + 4));
        }
      }
      v12 = (RBX::Network::DeserializedNewObjectItem *)*(unsigned int *)(a2 + 72); /*0x1067f0dba*/
      *(_DWORD *)(a2 + 152) = (_DWORD)v12; /*0x1067f0dbe*/
      if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u ) /*0x1067f0dd6*/
        FLog::FastLog( /*0x1067f0de8*/
          a1: *(_QWORD *)&DFLog::ReplicationDataCaching,
          a2: qword_10D7F3E28,
          a3: "[DFLog::ReplicationDataCaching] Reading instance @ offset=%d",
          (_DWORD)v12);
      RBX::Network::Replicator::JoinDataItemV2::readInstance( /*0x1067f0df6*/
        this: *(RBX::Network::Replicator::JoinDataItemV2 **)a2,
        a2: v3,
        a3: (RBX::Network::NetworkStream *)v21,
        a4: v12);
      v22 = (float)(*(_DWORD *)(a2 + 72) - *(_DWORD *)(a2 + 152)) / *(float *)(a2 + 156); /*0x1067f0e17*/
      *(float *)(v4 + 16) = v22 + *(float *)(v4 + 16); /*0x1067f0e25*/
      v13 = *(FLog **)&DFLog::ReplicationDataCaching; /*0x1067f0e2b*/
      if ( (unsigned __int8)DFLog::ReplicationDataCaching >= 6u && BYTE1(DFLog::ReplicationDataCaching) >= 3u ) /*0x1067f0e3b*/
      {
        v19 = v4; /*0x1067f0e46*/
        RBX::Guid::readableString(this: (RBX::Guid *)&v17, a2: (int)&v23); /*0x1067f0e64*/
        FLog::FastLog(this: v13, a2: (unsigned int)v24, a3: 0); /*0x1067f0eab*/
        v4 = v19; /*0x1067f0eb7*/
        if ( (v17 & 1) != 0 ) /*0x1067f0ebe*/
          operator delete(a1: (RBX::Memory *)v18, a2: v14); /*0x1067f0ec7*/
      }
      std::vector<RBX::Network::DeserializedNewObjectItem>::push_back[abi:ne200100](a1: v4 + 32, a2: v21); /*0x1067f0eda*/
      ++*(_DWORD *)(a2 + 88); /*0x1067f0edf*/
      RBX::Network::DeserializedNewObjectItem::~DeserializedNewObjectItem( /*0x1067f0ee6*/
        this: (RBX::Network::DeserializedNewObjectItem *)v21,
        a2: v15);
    }
    while ( *(_DWORD *)(a2 + 88) < *(_DWORD *)(a2 + 84) );
  }
  result = v20; /*0x1067f0efe*/
  *(_QWORD *)v20 = v4; /*0x1067f0f05*/
  return result; /*0x1067f0f18*/
}

// Address: 0x1067f0fe8 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV227DeserializingJoinDataItemV25resetEv
__int64 __fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::reset(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this)
{
  __int64 result; // rax
  __int64 v3; // rcx
  _BYTE v4[80]; // [rsp+0h] [rbp-50h] BYREF

  *((_DWORD *)this + 2) = 6; /*0x1067f0ff6*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v4); /*0x1067f1004*/
  RBX::Network::NetworkStream::operator=(a1: (char *)this + 16, a2: v4); /*0x1067f1010*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v4); /*0x1067f1018*/
  *((_BYTE *)this + 81) = 0; /*0x1067f101d*/
  *(_OWORD *)((char *)this + 84) = 0; /*0x1067f1024*/
  result = *((_QWORD *)this + 13); /*0x1067f1028*/
  v3 = *((_QWORD *)this + 16); /*0x1067f102c*/
  *((_QWORD *)this + 14) = result; /*0x1067f1033*/
  *((_QWORD *)this + 17) = v3; /*0x1067f1037*/
  *((_DWORD *)this + 38) = 0; /*0x1067f103e*/
  *(_QWORD *)((char *)this + 156) = 0; /*0x1067f1048*/
  return result; /*0x1067f1053*/
}

// Address: 0x10685ddd8 | Name: __ZN3RBX7Network10Replicator14JoinDataItemV227DeserializingJoinDataItemV2D1Ev
void __fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::~DeserializingJoinDataItemV2(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this,
        void *a2)
{
  RBX::Memory *v3; // rdi
  RBX::Memory *v4; // rdi

  v3 = *((RBX::Memory **)this + 16); /*0x10685dde1*/
  if ( v3 != nullptr ) /*0x10685ddeb*/
  {
    *((_QWORD *)this + 17) = v3; /*0x10685dded*/
    operator delete(a1: v3, a2); /*0x10685ddf4*/
  }
  v4 = *((RBX::Memory **)this + 13); /*0x10685ddf9*/
  if ( v4 != nullptr ) /*0x10685de00*/
  {
    *((_QWORD *)this + 14) = v4; /*0x10685de02*/
    operator delete(a1: v4, a2); /*0x10685de06*/
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *)((char *)this + 16)); /*0x10685de18*/
}

// END DeserializingJoinDataItemV2 part 1/1, 8 functions
