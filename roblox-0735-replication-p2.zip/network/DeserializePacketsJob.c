// DeserializePacketsJob -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 15 functions


// Address: 0x10685ba5e | Name: __ZN3RBX7Network21DeserializePacketsJob20pushIncomingPacketV2ENS0_14IncomingPacketE
__int64 __fastcall RBX::Network::DeserializePacketsJob::pushIncomingPacketV2(__int64 a1, __int128 *a2)
{
  RSL::Mutex *v4; // rbx
  __int128 v5; // xmm0
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // r9
  __int64 v10; // [rsp+0h] [rbp-C0h]
  _QWORD v11[5]; // [rsp+10h] [rbp-B0h] BYREF
  _BYTE v12[8]; // [rsp+38h] [rbp-88h] BYREF
  _BYTE v13[96]; // [rsp+40h] [rbp-80h] BYREF
  _QWORD v14[4]; // [rsp+A0h] [rbp-20h] BYREF

  v4 = (RSL::Mutex *)(a1 + 392); /*0x10685ba82*/
  v10 = a1 + 392; /*0x10685ba89*/
  RSL::Mutex::lock(this: (RSL::Mutex *)(a1 + 392)); /*0x10685ba9a*/
  v11[4] = *((_QWORD *)a2 + 4); /*0x10685baaa*/
  v5 = *a2; /*0x10685baae*/
  *(_OWORD *)&v11[2] = a2[1]; /*0x10685bab7*/
  *(_OWORD *)v11 = v5; /*0x10685babb*/
  std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x10685bac6*/
    a1: v12,
    a2: (char *)a2 + 40);
  ((void (__fastcall *)(__int64, _QWORD *, _QWORD *, __int64, __int64, __int64, __int64, char))RBX::UnboundedCircularBuffer<RBX::Network::IncomingPacket>::push_back<std::move_iterator<RBX::Network::IncomingPacket*>>)( /*0x10685bae0*/
    a1: a1 + 432,
    a2: v11,
    a3: v14,
    a4: v6,
    a5: v7,
    a6: v8,
    a7: v10,
    a8: 1);
  if ( v13[88] == 1 ) /*0x10685bae9*/
    RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v13); /*0x10685baef*/
  RSL::Mutex::unlock(this: v4); /*0x10685baf7*/
  return __stack_chk_guard; /*0x10685bb0c*/
}

// Address: 0x10685bd44 | Name: __ZN3RBX7Network21DeserializePacketsJob29pushIncomingPacket_deprecatedEPN6RakNet6PacketE
__int64 __fastcall RBX::Network::DeserializePacketsJob::pushIncomingPacket_deprecated(__int64 a1, __int64 a2)
{
  RSL::Mutex *v4; // r15

  v4 = (RSL::Mutex *)(a1 + 392); /*0x10685bd54*/
  RSL::Mutex::lock(this: (RSL::Mutex *)(a1 + 392)); /*0x10685bd5e*/
  RBX::UnboundedCircularBuffer<RakNet::Packet *>::push_back(a1: a1 + 400, a2); /*0x10685bd70*/
  return RSL::Mutex::unlock(this: v4); /*0x10685bd81*/
}

// Address: 0x10685c0d4 | Name: __ZN3RBX7Network21DeserializePacketsJob23numPacketsToDeserializeEv
__int64 __fastcall RBX::Network::DeserializePacketsJob::numPacketsToDeserialize(
        RBX::Network::DeserializePacketsJob *this)
{
  RSL::Mutex *v2; // r14
  __int64 v3; // rbx

  v2 = (RBX::Network::DeserializePacketsJob *)((char *)this + 392); /*0x10685c0de*/
  RSL::Mutex::lock(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 392)); /*0x10685c0e8*/
  v3 = *((_QWORD *)this + 4 * (unsigned int)(unsigned __int8)FFlag::RefactorIngressFlow + 53); /*0x10685c0fa*/
  RSL::Mutex::unlock(this: v2); /*0x10685c105*/
  return v3; /*0x10685c10d*/
}

// Address: 0x10685d452 | Name: __ZN3RBX7Network21DeserializePacketsJob25cacheReceivedSharedStringERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS_12SharedStringE
__int64 __fastcall RBX::Network::DeserializePacketsJob::cacheReceivedSharedString(
        __int64 a1,
        unsigned __int64 a2,
        __int64 a3)
{
  RBX::Network::DeserializedSharedStringItem *v6; // r12
  __int64 v7; // rdi
  __int64 v8; // rdx
  __int64 v9; // rcx
  const char *v10; // rsi
  __int64 v11; // r8
  __int64 v12; // r9
  __m128 v13; // xmm0
  __m128 v14; // xmm1
  __m128 v15; // xmm2
  __m128 v16; // xmm3
  __m128 v17; // xmm4
  __m128 v18; // xmm5
  __m128 v19; // xmm6
  __m128 v20; // xmm7
  __int64 v21; // r14
  char v23; // [rsp+0h] [rbp-30h]
  _BYTE v24[40]; // [rsp+8h] [rbp-28h] BYREF

  if ( *(_QWORD *)(a1 + 968) == 0 ) /*0x10685d472*/
  {
    v6 = (RBX::Network::DeserializedSharedStringItem *)operator new(a1: (RBX::Memory *)0x38, a2); /*0x10685d47e*/
    RBX::Network::DeserializedSharedStringItem::DeserializedSharedStringItem(this: v6); /*0x10685d484*/
    v7 = *(_QWORD *)(a1 + 968); /*0x10685d489*/
    *(_QWORD *)(a1 + 968) = v6; /*0x10685d490*/
    if ( v7 != 0 ) /*0x10685d49a*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v7 + 8LL))(a1: v7); /*0x10685d49f*/
  }
  std::__hash_table<std::__hash_value_type<std::string,RBX::SharedString>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::SharedString>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::SharedString>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::SharedString>>>::__emplace_unique_key_args<std::string,std::string const&,RBX::SharedString&>( /*0x10685d4b2*/
    a1: a1 + 928,
    a2,
    a3: a2,
    a4: a3);
  if ( (v8 & 1) == 0 ) /*0x10685d4ba*/
    RBX::throw_runtime_error( /*0x10685d4fc*/
      this: (RBX *)"Shared string receiver dictionary got duplicate entry",
      a2: v10,
      a3: v8,
      a4: v9,
      a5: v11,
      a6: v12,
      a7: v13,
      a8: v14,
      a9: v15,
      a10: v16,
      a11: v17,
      a12: v18,
      a13: v19,
      a14: v20,
      a15: v23);
  v21 = *(_QWORD *)(a1 + 968); /*0x10685d4bc*/
  RBX::Flyweight<RBX::SharedString::Data,void,true>::Flyweight(a1: v24, a2: a3); /*0x10685d4cd*/
  RBX::Network::DeserializedSharedStringItem::insertSharedString(a1: v21, a2: v24); /*0x10685d4d8*/
  return RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v24); /*0x10685d4e6*/
}

// Address: 0x10685dbf0 | Name: __ZN3RBX7Network21DeserializePacketsJob24findReceivedSharedStringERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
_BYTE *__fastcall RBX::Network::DeserializePacketsJob::findReceivedSharedString(_BYTE *a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rax
  char v5; // al

  v4 = std::__hash_table<std::__hash_value_type<std::string,RBX::SharedString>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::SharedString>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::SharedString>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::SharedString>>>::find<std::string>( /*0x10685dc03*/
         a1: a2 + 928,
         a2: a3);
  if ( v4 != 0 ) /*0x10685dc0b*/
  {
    RBX::Flyweight<RBX::SharedString::Data,void,true>::Flyweight(a1, a2: v4 + 40); /*0x10685dc17*/
    v5 = 1; /*0x10685dc1c*/
  }
  else
  {
    *a1 = 0; /*0x10685dc20*/
    v5 = 0; /*0x10685dc23*/
  }
  a1[8] = v5; /*0x10685dc25*/
  return a1; /*0x10685dc2f*/
}

// Address: 0x10685dcd2 | Name: __ZN3RBX7Network21DeserializePacketsJobD1Ev
void __fastcall RBX::Network::DeserializePacketsJob::~DeserializePacketsJob(RBX::Network::DeserializePacketsJob *this)
{
  RBX::Network::DeserializePacketsJob::~DeserializePacketsJob(this); /*0x10685dcd7*/
}

// Address: 0x10685dcdc | Name: __ZN3RBX7Network21DeserializePacketsJobD2Ev
void __fastcall RBX::Network::DeserializePacketsJob::~DeserializePacketsJob(
        RBX::Network::DeserializePacketsJob *this,
        void *a2)
{
  RBX::Memory *v3; // rdi
  RBX::Memory *v4; // rdi
  __int64 v5; // rdi

  *(_QWORD *)this = &off_10CAADB98; /*0x10685dcec*/
  v3 = *((RBX::Memory **)this + 139); /*0x10685dcef*/
  if ( v3 != nullptr ) /*0x10685dcf9*/
  {
    *((_QWORD *)this + 140) = v3; /*0x10685dcfb*/
    operator delete(a1: v3, a2); /*0x10685dd02*/
  }
  v4 = *((RBX::Memory **)this + 136); /*0x10685dd07*/
  if ( v4 != nullptr ) /*0x10685dd11*/
  {
    *((_QWORD *)this + 137) = v4; /*0x10685dd13*/
    operator delete(a1: v4, a2); /*0x10685dd1a*/
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 1000)); /*0x10685dd26*/
  v5 = *((_QWORD *)this + 121); /*0x10685dd2b*/
  *((_QWORD *)this + 121) = 0; /*0x10685dd32*/
  if ( v5 != 0 ) /*0x10685dd40*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(a1: v5); /*0x10685dd45*/
  std::__hash_table<std::__hash_value_type<std::string,RBX::SharedString>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::SharedString>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::SharedString>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::SharedString>>>::~__hash_table(a1: (char *)this + 928); /*0x10685dd4f*/
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: (__int64 *)this + 109); /*0x10685dd5b*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 808)); /*0x10685dd67*/
  if ( *((_BYTE *)this + 792) == 1 ) /*0x10685dd73*/
    RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 704)); /*0x10685dd7c*/
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: (__int64 *)this + 77); /*0x10685dd88*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 552)); /*0x10685dd94*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 464)); /*0x10685dda0*/
  RBX::UnboundedCircularBuffer<RBX::Network::IncomingPacket>::~UnboundedCircularBuffer(a1: (char *)this + 432); /*0x10685ddac*/
  RBX::UnboundedCircularBuffer<RakNet::Packet *>::~UnboundedCircularBuffer(a1: (char *)this + 400); /*0x10685ddb8*/
  RSL::Mutex::~Mutex(a1: (char *)this + 392); /*0x10685ddc4*/
  RBX::TaskScheduler::Job::~Job(this); /*0x10685ddd2*/
}

// Address: 0x10685de1e | Name: __ZN3RBX7Network21DeserializePacketsJob4stepERKNS_13TaskScheduler3Job5StatsE
__int64 RBX::Network::DeserializePacketsJob::step()
{
  return 1; /*0x10685de27*/
}

// Address: 0x10685de2a | Name: __ZN3RBX7Network21DeserializePacketsJobD0Ev
void __fastcall RBX::Network::DeserializePacketsJob::~DeserializePacketsJob(
        RBX::Network::DeserializePacketsJob *this,
        void *a2)
{
  void *v3; // rsi

  RBX::Network::DeserializePacketsJob::~DeserializePacketsJob(this, a2); /*0x10685de33*/
  operator delete(a1: this, a2: v3); /*0x10685de41*/
}

// Address: 0x106861ed4 | Name: __ZN3RBX7Network21DeserializePacketsJob29deallocatePacketsOnDisconnectEv
__int64 __fastcall RBX::Network::DeserializePacketsJob::deallocatePacketsOnDisconnect(
        RBX::Network::DeserializePacketsJob *this)
{
  _QWORD *v2; // r15
  __int64 RakNetPacket; // rax
  RBX::Network::NetworkTracer *v4; // r13
  __int64 v5; // rax
  _QWORD *v6; // r13
  __int64 v7; // rax
  __int64 v8; // rdi
  __int64 v9; // rdi
  __int64 v10; // r8
  unsigned __int64 v11; // r9
  unsigned __int64 v12; // rtt
  __int64 v13; // r14
  unsigned __int64 v14; // rsi
  RBX::Network::NetworkTracer *v15; // rdi
  __int64 v16; // rdi
  _BYTE v18[48]; // [rsp+0h] [rbp-130h] BYREF
  _BYTE v19[80]; // [rsp+30h] [rbp-100h] BYREF
  __int128 v20; // [rsp+80h] [rbp-B0h]
  __int64 v21[14]; // [rsp+90h] [rbp-A0h] BYREF

  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v18); /*0x106861f00*/
  RBX::Network::NetworkStream::operator=(a1: (char *)this + 464, a2: v18); /*0x106861f16*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v18); /*0x106861f1e*/
  if ( FFlag::RefactorIngressFlow == 1 ) /*0x106861f2d*/
  {
    if ( RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 656)) != 0 ) /*0x106861f45*/
    {
      v2 = *(_QWORD **)(*((_QWORD *)this + 48) + 224LL); /*0x106861f4e*/
      RakNetPacket = RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 656)); /*0x106861f58*/
      (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v2 + 240LL))(a1: *v2, a2: RakNetPacket); /*0x106861f66*/
    }
    memset(v21, 0, sizeof(v21)); /*0x106861fa0*/
    v20 = 0; /*0x106861fa7*/
    memset(v19, 0, sizeof(v19)); /*0x106861fbe*/
    memset(v18, 0, sizeof(v18)); /*0x106861fca*/
    RBX::Network::ProcessingPacketV2::ProcessingPacketV2(this: (RBX::Network::ProcessingPacketV2 *)v18); /*0x106861fcd*/
    RBX::Network::ProcessingPacketV2::operator=(a1: (char *)this + 656, a2: v18); /*0x106861fdc*/
    RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: &v21[9]); /*0x106861fe5*/
    RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v21[1]); /*0x106861ff4*/
    if ( BYTE8(v20) == 1 ) /*0x106861ffe*/
      RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v19); /*0x106862007*/
    while ( *((_QWORD *)this + 57) != 0 ) /*0x106862014*/
    {
      RBX::UnboundedCircularBuffer<RBX::Network::IncomingPacket>::pop_front(a1: v18, a2: (char *)this + 432); /*0x106862035*/
      if ( RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::IncomingPacket *)v18) != 0 ) /*0x106862045*/
      {
        if ( DFFlag::DataPingTrace == 1 /*0x10686205a*/
          && *(_QWORD *)(RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::IncomingPacket *)v18) + 96) != 0 )
        {
          if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x106862066*/
            v4 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x106862068*/
          else
            v4 = nullptr; /*0x10686206e*/
          v5 = RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::IncomingPacket *)v18); /*0x106862074*/
          RBX::Network::NetworkTracer::removeTracerObject(this: v4, a2: *(_QWORD *)(v5 + 96)); /*0x106862080*/
        }
        v6 = *(_QWORD **)(*((_QWORD *)this + 48) + 224LL); /*0x10686208c*/
        v7 = RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::IncomingPacket *)v18); /*0x106862096*/
        (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v6 + 240LL))(a1: *v6, a2: v7); /*0x1068620a5*/
      }
      if ( BYTE8(v20) == 1 ) /*0x1068620b2*/
        RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v19); /*0x1068620bb*/
    }
  }
  else
  {
    if ( *((_QWORD *)this + 67) != 0 ) /*0x1068620dd*/
    {
      v8 = **(_QWORD **)(*((_QWORD *)this + 48) + 224LL); /*0x1068620ed*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 240LL))(a1: v8); /*0x1068620f3*/
      *((_QWORD *)this + 67) = 0; /*0x1068620f9*/
    }
    v9 = *((_QWORD *)this + 53); /*0x106862104*/
    while ( v9 != 0 ) /*0x10686210e*/
    {
      v10 = *((_QWORD *)this + 50); /*0x106862122*/
      v11 = *((_QWORD *)this + 51); /*0x106862129*/
      v12 = *((_QWORD *)this + 52); /*0x106862135*/
      *((_QWORD *)this + 52) = (v12 + 1) % v11; /*0x106862146*/
      v13 = *(_QWORD *)(v10 + 8 * (v12 % v11)); /*0x10686214d*/
      *((_QWORD *)this + 53) = --v9; /*0x106862154*/
      if ( v13 != 0 ) /*0x10686215e*/
      {
        if ( DFFlag::DataPingTrace == 1 ) /*0x106862164*/
        {
          v14 = *(_QWORD *)(v13 + 96); /*0x106862166*/
          if ( v14 != 0 ) /*0x10686216d*/
          {
            if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x106862179*/
              v15 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle /*0x10686217b*/
                                                    + 24);
            else
              v15 = nullptr; /*0x106862181*/
            RBX::Network::NetworkTracer::removeTracerObject(this: v15, a2: v14); /*0x106862183*/
          }
        }
        v16 = **(_QWORD **)(*((_QWORD *)this + 48) + 224LL); /*0x106862196*/
        (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v16 + 240LL))(a1: v16, a2: v13); /*0x10686219f*/
        v9 = *((_QWORD *)this + 53); /*0x1068621a5*/
      }
    }
  }
  return __stack_chk_guard; /*0x1068621c5*/
}

// Address: 0x10686c47e | Name: __ZN3RBX7Network21DeserializePacketsJobC2ERNS0_10ReplicatorE
void __fastcall RBX::Network::DeserializePacketsJob::DeserializePacketsJob(
        RBX::Network::DeserializePacketsJob *this,
        RBX::Network::Replicator *a2)
{
  RBX::Network::DeserializePacketsJob::DummyArbiter *v4; // r14
  __int64 v5; // rdi
  std::__shared_weak_count *v6; // r14
  RBX::Instance *v7; // rsi
  __int64 v8; // r8
  __int64 v9; // r9
  __m128 v10; // xmm1
  __m128 v11; // xmm2
  __m128 v12; // xmm3
  __m128 v13; // xmm4
  __m128 v14; // xmm5
  __m128 v15; // xmm6
  __m128 v16; // xmm7
  __m128 v17; // xmm0
  __int64 v18; // rax
  __int64 v19; // rax
  __int64 v20; // rcx
  __int64 v21; // rdx
  __int64 v22; // rcx
  void *v23; // rsi
  int PairIntValue; // r14d
  __int64 v25; // rax
  __int64 v26; // rdx
  __int64 v27; // rcx
  void *v28; // rsi
  int v29; // r14d
  bool v30; // zf
  int *v31; // rcx
  unsigned __int8 *v32; // rcx
  unsigned __int8 v33; // al
  void **v34; // rcx
  __int64 *v35; // rdx
  void *v36; // r14
  __int64 v37; // r15
  __int64 v38; // rax
  __int64 v39; // rdx
  __int64 v40; // rcx
  unsigned int v41; // r12d
  void *v42; // rsi
  int v43; // r14d
  unsigned __int8 *v44; // rcx
  unsigned __int8 v45; // al
  void **v46; // rcx
  __int64 *v47; // rdx
  void *v48; // r14
  __int64 v49; // r15
  __int64 v50; // r13
  void *v51; // rsi
  int v52; // r14d
  char v53[8]; // [rsp+0h] [rbp-A0h] BYREF
  std::__shared_weak_count *v54; // [rsp+8h] [rbp-98h]
  char *v55; // [rsp+10h] [rbp-90h]
  char *v56; // [rsp+18h] [rbp-88h]
  char *v57; // [rsp+20h] [rbp-80h]
  char *v58; // [rsp+28h] [rbp-78h]
  char *v59; // [rsp+30h] [rbp-70h]
  char *v60; // [rsp+38h] [rbp-68h]
  char *v61; // [rsp+40h] [rbp-60h]
  _BYTE v62[16]; // [rsp+48h] [rbp-58h] BYREF
  void *v63; // [rsp+58h] [rbp-48h]
  _BYTE v64[16]; // [rsp+60h] [rbp-40h] BYREF
  void *v65; // [rsp+70h] [rbp-30h]

  v4 = (RBX::Network::DeserializePacketsJob::DummyArbiter *)operator new(a1: (RBX::Memory *)0x1E0, (unsigned __int64)a2); /*0x10686c49f*/
  __bzero(a1: v4, a2: 480); /*0x10686c4aa*/
  RBX::Network::DeserializePacketsJob::DummyArbiter::DummyArbiter(this: v4); /*0x10686c4b2*/
  std::shared_ptr<RBX::TaskScheduler::Arbiter>::shared_ptr[abi:ne200100]<RBX::Network::DeserializePacketsJob::DummyArbiter,0>( /*0x10686c4c4*/
    a1: v53,
    a2: v4);
  RBX::TaskScheduler::Job::Job(a1: this, a2: "DeserializePacketsJob", a3: v53, a4: 19); /*0x10686c4db*/
  v6 = v54; /*0x10686c4e0*/
  if ( v54 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v54 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10686c4fc*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x10686c504*/
    std::__shared_weak_count::__release_weak(this: v6); /*0x10686c50a*/
  }
  *(_QWORD *)this = &off_10CAADB98; /*0x10686c516*/
  *(_OWORD *)((char *)this + 360) = 0; /*0x10686c51c*/
  *((double *)this + 47) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v5); /*0x10686c528*/
  *((_QWORD *)this + 48) = a2; /*0x10686c530*/
  RSL::Mutex::Mutex(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 392), a2: "DpjMutex"); /*0x10686c548*/
  RBX::UnboundedCircularBuffer<RakNet::Packet *>::UnboundedCircularBuffer(a1: (char *)this + 400, a2: 8); /*0x10686c55c*/
  v57 = (char *)this + 432; /*0x10686c56d*/
  RBX::UnboundedCircularBuffer<RBX::Network::IncomingPacket>::UnboundedCircularBuffer(a1: (char *)this + 432, a2: 8); /*0x10686c571*/
  v58 = (char *)this + 464; /*0x10686c57d*/
  v55 = (char *)this + 392; /*0x10686c581*/
  v56 = (char *)this + 400; /*0x10686c588*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 464)); /*0x10686c58f*/
  *(_OWORD *)((char *)this + 536) = 0; /*0x10686c59e*/
  v59 = (char *)this + 552; /*0x10686c5a5*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 552)); /*0x10686c5a9*/
  v60 = (char *)this + 616; /*0x10686c5ba*/
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::UnboundedCircularBuffer( /*0x10686c5be*/
    a1: (__int64)this + 616,
    a2: 8u);
  *(_DWORD *)((char *)this + 651) = 0; /*0x10686c5c5*/
  *((_DWORD *)this + 162) = 0; /*0x10686c5cb*/
  v61 = (char *)this + 656; /*0x10686c5d8*/
  RBX::Network::ProcessingPacketV2::ProcessingPacketV2(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 656)); /*0x10686c5dc*/
  *((_OWORD *)this + 59) = 0; /*0x10686c5e4*/
  *((_OWORD *)this + 58) = 0; /*0x10686c5eb*/
  *((_OWORD *)this + 57) = 0; /*0x10686c5f2*/
  *((_DWORD *)this + 240) = 1065353216; /*0x10686c5f9*/
  *(_OWORD *)((char *)this + 968) = 0; /*0x10686c603*/
  *((_QWORD *)this + 123) = a2; /*0x10686c60a*/
  *((_DWORD *)this + 248) = 6; /*0x10686c611*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 1000)); /*0x10686c622*/
  *((_WORD *)this + 532) = 0; /*0x10686c627*/
  v17 = 0; /*0x10686c630*/
  *(_OWORD *)((char *)this + 1068) = 0; /*0x10686c633*/
  *((_OWORD *)this + 68) = 0; /*0x10686c63a*/
  *((_OWORD *)this + 69) = 0; /*0x10686c641*/
  *((_OWORD *)this + 70) = 0; /*0x10686c648*/
  *(_OWORD *)((char *)this + 1132) = 0; /*0x10686c64f*/
  if ( DFInt::NetworkStopProducingPacketsToProcessThresholdMs > 0 ) /*0x10686c65e*/
    *((_DWORD *)this + 244) = DFInt::NetworkStopProducingPacketsToProcessThresholdMs; /*0x10686c660*/
  if ( (DFString::JdiDeserializerConfigPerDC & 1) != 0 ) /*0x10686c66f*/
    v18 = qword_10D80DA00; /*0x10686c671*/
  else
    v18 = (unsigned __int8)DFString::JdiDeserializerConfigPerDC >> 1; /*0x10686c67a*/
  if ( v18 != 0 ) /*0x10686c67f*/
  {
    v19 = RBX::DataModel::get(this: a2, a2: v7); /*0x10686c684*/
    if ( v19 != 0 ) /*0x10686c68c*/
    {
      RBX::format( /*0x10686c6a1*/
        this: (RBX *)v64,
        a2: "%d",
        a3: *(unsigned int *)(v19 + 2184),
        a4: v20,
        a5: v8,
        a6: v9,
        a7: v17,
        a8: v10,
        a9: v11,
        a10: v12,
        a11: v13,
        a12: v14,
        a13: v15,
        a14: v16,
        a15: v53[0]);
      std::string::basic_string[abi:ne200100]<0>(a1: v62, a2: ",", a3: v21, a4: v22); /*0x10686c6b1*/
      PairIntValue = RBX::Network::getPairIntValue(a1: v64, a2: &DFString::JdiDeserializerConfigPerDC, a3: v62); /*0x10686c6ca*/
      if ( (v62[0] & 1) != 0 ) /*0x10686c6d1*/
        operator delete(a1: (RBX::Memory *)v63, a2: v23); /*0x10686c6d7*/
      if ( (v64[0] & 1) != 0 ) /*0x10686c6e0*/
        operator delete(a1: (RBX::Memory *)v65, a2: v23); /*0x10686c6e6*/
      if ( PairIntValue != -1 ) /*0x10686c6ef*/
        *((_DWORD *)this + 244) = PairIntValue; /*0x10686c6f1*/
    }
  }
  if ( (DFString::JdiDeserializerConfigUserIdPer100 & 1) != 0 ) /*0x10686c701*/
    v25 = qword_10D80D9E8; /*0x10686c703*/
  else
    v25 = (unsigned __int8)DFString::JdiDeserializerConfigUserIdPer100 >> 1; /*0x10686c70c*/
  if ( v25 != 0 ) /*0x10686c711*/
  {
    RBX::format( /*0x10686c752*/
      this: (RBX *)v64,
      a2: "%d",
      a3: (unsigned int)(*((_QWORD *)a2 + 2700) % 100LL),
      a4: (unsigned int)(*((_QWORD *)a2 + 2700) % 100LL),
      a5: v8,
      a6: v9,
      a7: v17,
      a8: v10,
      a9: v11,
      a10: v12,
      a11: v13,
      a12: v14,
      a13: v15,
      a14: v16,
      a15: v53[0]);
    std::string::basic_string[abi:ne200100]<0>(a1: v62, a2: ",", a3: v26, a4: v27); /*0x10686c762*/
    v29 = RBX::Network::getPairIntValue(a1: v64, a2: &DFString::JdiDeserializerConfigUserIdPer100, a3: v62); /*0x10686c77b*/
    if ( (v62[0] & 1) != 0 ) /*0x10686c782*/
      operator delete(a1: (RBX::Memory *)v63, a2: v28); /*0x10686c788*/
    if ( (v64[0] & 1) != 0 ) /*0x10686c791*/
      operator delete(a1: (RBX::Memory *)v65, a2: v28); /*0x10686c797*/
    if ( v29 != -1 ) /*0x10686c7a0*/
      *((_DWORD *)this + 244) = v29; /*0x10686c7a2*/
  }
  *((_DWORD *)a2 + 3946) = *((_DWORD *)this + 244); /*0x10686c7af*/
  v30 = *((_DWORD *)a2 + 69) == 0; /*0x10686c7b6*/
  v31 = &DFInt::NetworkInDeserializeLimitGameplayMsRcc; /*0x10686c7c5*/
  if ( *((_DWORD *)a2 + 69) == 0 ) /*0x10686c7cc*/
    v31 = &DFInt::NetworkInDeserializeLimitGameplayMsClient; /*0x10686c7cc*/
  *((_DWORD *)this + 245) = *v31; /*0x10686c7d2*/
  v32 = (unsigned __int8 *)&DFString::NetworkInDeserializeLimitGameplayMsRccPerDc; /*0x10686c7df*/
  if ( v30 ) /*0x10686c7e6*/
    v32 = (unsigned __int8 *)&DFString::NetworkInDeserializeLimitGameplayMsClientPerDc; /*0x10686c7e6*/
  v33 = *v32; /*0x10686c7ea*/
  v34 = (void **)&unk_10D80D490; /*0x10686c7f3*/
  if ( v30 ) /*0x10686c7fa*/
    v34 = (void **)&unk_10D80D478; /*0x10686c7fa*/
  v35 = (__int64 *)&unk_10D80D488; /*0x10686c805*/
  if ( v30 ) /*0x10686c80c*/
    v35 = (__int64 *)&unk_10D80D470; /*0x10686c80c*/
  v36 = &unk_10D80D481; /*0x10686c817*/
  if ( v30 ) /*0x10686c81e*/
    v36 = &unk_10D80D469; /*0x10686c81e*/
  if ( (v33 & 1) != 0 ) /*0x10686c824*/
  {
    v36 = *v34; /*0x10686c826*/
    v37 = *v35; /*0x10686c829*/
  }
  else
  {
    v37 = v33 >> 1; /*0x10686c830*/
  }
  if ( v37 != 0 ) /*0x10686c837*/
  {
    v38 = RBX::DataModel::get(this: a2, a2: (RBX::Instance *)&unk_10D80D469); /*0x10686c83c*/
    if ( v38 != 0 ) /*0x10686c844*/
    {
      v41 = *(_DWORD *)(v38 + 2184); /*0x10686c846*/
      std::string::basic_string[abi:ne200100]<0>(a1: v64, a2: ",", a3: v39, a4: v40); /*0x10686c858*/
      v43 = RBX::Network::getPairIntValue(a1: v41, a2: v36, a3: v37, a4: v64); /*0x10686c86f*/
      if ( (v64[0] & 1) != 0 ) /*0x10686c876*/
        operator delete(a1: (RBX::Memory *)v65, a2: v42); /*0x10686c87c*/
      if ( v43 != -1 ) /*0x10686c885*/
        *((_DWORD *)this + 245) = v43; /*0x10686c887*/
    }
  }
  v44 = (unsigned __int8 *)&DFString::NetworkInDeserializeLimitGameplayMsRccPer100; /*0x10686c89d*/
  if ( *((_DWORD *)a2 + 69) == 0 ) /*0x10686c8a4*/
    v44 = (unsigned __int8 *)&DFString::NetworkInDeserializeLimitGameplayMsClientPer100; /*0x10686c8a4*/
  v45 = *v44; /*0x10686c8a8*/
  v46 = (void **)&unk_10D80D4C0; /*0x10686c8b1*/
  if ( *((_DWORD *)a2 + 69) == 0 ) /*0x10686c8b8*/
    v46 = (void **)&unk_10D80D4A8; /*0x10686c8b8*/
  v47 = (__int64 *)&unk_10D80D4B8; /*0x10686c8c3*/
  if ( *((_DWORD *)a2 + 69) == 0 ) /*0x10686c8ca*/
    v47 = (__int64 *)&unk_10D80D4A0; /*0x10686c8ca*/
  v48 = &unk_10D80D4B1; /*0x10686c8d5*/
  if ( *((_DWORD *)a2 + 69) == 0 ) /*0x10686c8dc*/
    v48 = &unk_10D80D499; /*0x10686c8dc*/
  if ( (v45 & 1) != 0 ) /*0x10686c8e2*/
  {
    v48 = *v46; /*0x10686c8e4*/
    v49 = *v47; /*0x10686c8e7*/
  }
  else
  {
    v49 = v45 >> 1; /*0x10686c8ee*/
  }
  if ( v49 != 0 ) /*0x10686c8f5*/
  {
    v50 = *((_QWORD *)a2 + 2700); /*0x10686c8f7*/
    std::string::basic_string[abi:ne200100]<0>(a1: v64, a2: ",", a3: v47, a4: v46); /*0x10686c909*/
    v52 = RBX::Network::getPairIntValue(a1: (unsigned int)(v50 % 100), a2: v48, a3: v49, a4: v64); /*0x10686c946*/
    if ( (v64[0] & 1) != 0 ) /*0x10686c94d*/
      operator delete(a1: (RBX::Memory *)v65, a2: v51); /*0x10686c953*/
    if ( v52 != -1 ) /*0x10686c95c*/
      *((_DWORD *)this + 245) = v52; /*0x10686c95e*/
  }
}

// Address: 0x10686ce28 | Name: __ZN3RBX7Network21DeserializePacketsJob10threadStepEv
__int64 __fastcall RBX::Network::DeserializePacketsJob::threadStep(RBX::Network::Replicator **this, unsigned int a2)
{
  unsigned int v3; // ebx
  RBX::TaskScheduler *v4; // rdi
  unsigned __int64 v5; // rax
  unsigned int v6; // esi
  __int64 v7; // rax
  int v8; // ecx

  v3 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkReplicator, a2); /*0x10686ce40*/
  if ( DFFlag::TrackDPJProgress == 1 ) /*0x10686ce49*/
    RBX::Network::DeserializePacketsJob::trackPause((RBX::Network::DeserializePacketsJob *)this); /*0x10686ce4e*/
  if ( FFlag::ReportTypeBandwidthStatsInterval == 1 /*0x10686ce79*/
    && RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v4) - *((double *)this + 47) > (double)DFInt::ReportTypeBandwidthStatsEveryNSec )
  {
    *((double *)this + 47) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v4); /*0x10686ce80*/
    RBX::Network::TwoWayBandwidthMetrics::reportOnInterval(a1: (char *)*(this + 48) + 288, a2: 1); /*0x10686ce9a*/
  }
  v5 = RBX::TaskScheduler::cycle(this: v4); /*0x10686ce9f*/
  if ( v5 > (unsigned __int64)*(this + 46) ) /*0x10686ceab*/
  {
    *(this + 45) = nullptr; /*0x10686cead*/
    *(this + 46) = (RBX::Network::Replicator *)v5; /*0x10686ceb8*/
    RBX::Network::Replicator::recordLastFrameTimespan(this: *(this + 48)); /*0x10686cec6*/
    RBX::Network::Replicator::reportAndResetFrameDataWithJdi(this: *(this + 48)); /*0x10686ced2*/
    v7 = (__int64)*(this + 48); /*0x10686ced7*/
LABEL_10:
    *(_BYTE *)(v7 + 15728) = 0; /*0x10686cf10*/
    RBX::Network::DeserializePacketsJob::stepGranular((RBX::Network::DeserializePacketsJob *)this); /*0x10686cf1a*/
    return RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v3, a2: v6); /*0x10686cf1a*/
  }
  v7 = (__int64)*(this + 48); /*0x10686cee0*/
  v8 = *((_DWORD *)this + *(unsigned __int8 *)(v7 + 18702) + 244); /*0x10686ceee*/
  if ( v8 <= 0 || *((double *)this + 45) <= (double)v8 ) /*0x10686cf0e*/
    goto LABEL_10; /*0x10686cf0e*/
  return RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v3, a2: v6); /*0x10686cf26*/
}

// Address: 0x10686cf4c | Name: __ZN3RBX7Network21DeserializePacketsJob10trackPauseEv
__int64 __fastcall RBX::Network::DeserializePacketsJob::trackPause(RBX::Network::DeserializePacketsJob *this)
{
  RSL::Mutex *v2; // rbx
  __int64 v3; // r12
  __int64 RakNetPacket; // rax
  __int64 v5; // rsi
  __int64 v6; // rsi

  v2 = (RBX::Network::DeserializePacketsJob *)((char *)this + 392); /*0x10686cf5e*/
  RSL::Mutex::lock(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 392)); /*0x10686cf70*/
  if ( FFlag::RefactorIngressFlow == 1 ) /*0x10686cf7f*/
  {
    if ( RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 656)) != 0 ) /*0x10686cf93*/
    {
      v3 = *((_QWORD *)this + 48); /*0x10686cf95*/
      RakNetPacket = RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 656)); /*0x10686cf9f*/
      RBX::Network::StuckPacketTracker::updateAndReportOnThreshold(a1: v3 + 10760, a2: RakNetPacket); /*0x10686cfb1*/
    }
    if ( *((_QWORD *)this + 57) != 0 ) /*0x10686cfbe*/
      v5 = RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::IncomingPacket *)(*((_QWORD *)this + 54) /*0x10686cfe8*/
                                                                                              + 144LL
                                                                                              * (*((_QWORD *)this + 56)
                                                                                               % *((_QWORD *)this + 55))));
    else
      v5 = 0; /*0x10686d059*/
    RBX::Network::StuckPacketTracker::updateAndReportOnThreshold(a1: *((_QWORD *)this + 48) + 10792LL, a2: v5); /*0x10686d067*/
    RBX::Network::EmptyQueueTracker::updateAndReportOnThreshold( /*0x10686d07f*/
      this: (RBX::Network::EmptyQueueTracker *)(*((_QWORD *)this + 48) + 10744LL),
      a2: *((_QWORD *)this + 57));
  }
  else
  {
    RBX::Network::StuckPacketTracker::updateAndReportOnThreshold( /*0x10686d000*/
      a1: *((_QWORD *)this + 48) + 10760LL,
      a2: *((_QWORD *)this + 67));
    if ( *((_QWORD *)this + 53) != 0 ) /*0x10686d00d*/
      v6 = *(_QWORD *)(*((_QWORD *)this + 50) + 8LL * (*((_QWORD *)this + 52) % *((_QWORD *)this + 51))); /*0x10686d026*/
    else
      v6 = 0; /*0x10686d02c*/
    RBX::Network::StuckPacketTracker::updateAndReportOnThreshold(a1: *((_QWORD *)this + 48) + 10792LL, a2: v6); /*0x10686d03a*/
    RBX::Network::EmptyQueueTracker::updateAndReportOnThreshold( /*0x10686d052*/
      this: (RBX::Network::EmptyQueueTracker *)(*((_QWORD *)this + 48) + 10744LL),
      a2: *((_QWORD *)this + 53));
  }
  return RSL::Mutex::unlock(this: v2); /*0x10686d08c*/
}

// Address: 0x10686d0ba | Name: __ZN3RBX7Network21DeserializePacketsJob12stepGranularEv
__int64 __fastcall RBX::Network::DeserializePacketsJob::stepGranular(RBX::Network::DeserializePacketsJob *this)
{
  __int64 v2; // r14
  RBX::Time *v3; // rdi
  unsigned int v4; // r14d
  __int64 v5; // xmm0_8
  RBX::Instance *v6; // rsi
  const RBX::DataModel *Dangerous_DEPRECATED; // rax
  void (__fastcall ***v8)(_QWORD); // rdi
  __int64 v9; // rdi
  unsigned __int8 *v10; // r13
  unsigned int v11; // eax
  unsigned __int8 v12; // r13
  unsigned int v13; // eax
  double v14; // xmm0_8
  __int64 v15; // rax
  int v16; // ecx
  RBX::Network::Replicator *v17; // rdi
  __int64 v18; // rdx
  __int64 v19; // rcx
  char v20; // r15
  __int64 v21; // rdx
  __int64 v22; // rcx
  char v23; // r15
  __int64 v24; // r8
  unsigned __int64 v25; // r9
  unsigned __int64 v26; // rtt
  unsigned __int64 v27; // r13
  unsigned __int64 v28; // rsi
  __int64 v29; // rax
  __int64 v30; // rcx
  __int64 v31; // rdx
  __int128 v32; // xmm0
  __int128 v33; // xmm1
  __int64 v34; // rax
  int v35; // eax
  _DWORD *v36; // rdx
  unsigned int v37; // edx
  __int64 v38; // rax
  __int64 v39; // rdi
  __int64 v40; // rdi
  __int64 v41; // r13
  __int64 v42; // rax
  __int64 v43; // rdi
  __int64 v44; // rdi
  __int64 v45; // r13
  unsigned __int64 v46; // rsi
  __int64 v47; // rax
  __int64 v48; // rcx
  __int64 v49; // rdx
  __int128 v50; // xmm0
  __int128 v51; // xmm1
  __int64 v52; // rax
  int v53; // eax
  _DWORD *v54; // rdx
  double v55; // xmm3_8
  double v56; // xmm0_8
  __int64 v57; // rdi
  unsigned __int8 v59; // r8
  __int64 Token; // r14
  __int64 v61; // [rsp+0h] [rbp-BA0h] BYREF
  _BYTE v62[2080]; // [rsp+8h] [rbp-B98h] BYREF
  char v63; // [rsp+828h] [rbp-378h]
  _QWORD v64[13]; // [rsp+830h] [rbp-370h] BYREF
  _BYTE v65[16]; // [rsp+898h] [rbp-308h] BYREF
  _BYTE v66[24]; // [rsp+8A8h] [rbp-2F8h] BYREF
  char v67; // [rsp+8C0h] [rbp-2E0h]
  __int64 *v68; // [rsp+8C8h] [rbp-2D8h]
  __int64 *v69; // [rsp+8D0h] [rbp-2D0h]
  char *v70; // [rsp+8D8h] [rbp-2C8h]
  _QWORD v71[2]; // [rsp+8E0h] [rbp-2C0h] BYREF
  char *v72; // [rsp+8F0h] [rbp-2B0h]
  char *v73; // [rsp+8F8h] [rbp-2A8h]
  __int64 v74; // [rsp+900h] [rbp-2A0h] BYREF
  __int64 v75; // [rsp+908h] [rbp-298h] BYREF
  RSL::Mutex *v76; // [rsp+910h] [rbp-290h] BYREF
  char v77; // [rsp+918h] [rbp-288h]
  __int64 v78; // [rsp+920h] [rbp-280h]
  __int64 *v79; // [rsp+928h] [rbp-278h]
  RBX::Network::NetworkStream *v80; // [rsp+930h] [rbp-270h]
  RBX::Network::ProcessingPacket *v81; // [rsp+938h] [rbp-268h]
  RBX::Time *v82; // [rsp+940h] [rbp-260h]
  RBX::Network::IncomingPacket *v83; // [rsp+948h] [rbp-258h]
  _QWORD v84[4]; // [rsp+950h] [rbp-250h] BYREF
  __int64 v85; // [rsp+970h] [rbp-230h]
  _BYTE v86[8]; // [rsp+978h] [rbp-228h] BYREF
  _BYTE v87[96]; // [rsp+980h] [rbp-220h] BYREF
  __int128 v88; // [rsp+9E0h] [rbp-1C0h] BYREF
  __int128 v89; // [rsp+9F0h] [rbp-1B0h] BYREF
  __int128 v90; // [rsp+A00h] [rbp-1A0h]
  __int128 v91; // [rsp+A10h] [rbp-190h] BYREF
  __int128 v92; // [rsp+A20h] [rbp-180h]
  __int64 v93[6]; // [rsp+A30h] [rbp-170h] BYREF
  __int128 v94; // [rsp+A60h] [rbp-140h]
  _QWORD v95[14]; // [rsp+A70h] [rbp-130h] BYREF
  __int64 v96; // [rsp+AE0h] [rbp-C0h] BYREF
  _BYTE v97[24]; // [rsp+AE8h] [rbp-B8h]
  __int64 v98; // [rsp+B00h] [rbp-A0h]
  _BYTE v99[8]; // [rsp+B08h] [rbp-98h] BYREF
  _BYTE v100[96]; // [rsp+B10h] [rbp-90h] BYREF

  if ( (_BYTE)`guard variable for'RBX::Network::DeserializePacketsJob::stepGranular(void)::proftoken1840 == 0 /*0x10686df39*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::DeserializePacketsJob::stepGranular(void)::proftoken1840) != 0 )
  {
    Token = RBX::Profiler::getToken( /*0x10686df5c*/
              this: (RBX::Profiler *)"Network",
              a2: "deserializeBufferedPackets",
              a3: (const char *)0xFFFFFFFFLL,
              a4: 255,
              a5: v59);
    RBX::Profiler::PerFrameTelemetry::activateForTelemetry(a1: Token); /*0x10686df62*/
    RBX::Network::DeserializePacketsJob::stepGranular(void)::proftoken1840 = Token; /*0x10686df67*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::DeserializePacketsJob::stepGranular(void)::proftoken1840); /*0x10686df75*/
  }
  v2 = RBX::Network::DeserializePacketsJob::stepGranular(void)::proftoken1840; /*0x10686d0ed*/
  *(_OWORD *)v64 = 0; /*0x10686d0ff*/
  v64[3] = -1; /*0x10686d103*/
  memset(&v64[4], 0, 52); /*0x10686d10b*/
  *(_OWORD *)&v64[11] = 0; /*0x10686d121*/
  v64[2] = RBX::Network::DeserializePacketsJob::stepGranular(void)::proftoken1840; /*0x10686d126*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v64); /*0x10686d12a*/
  v64[3] = RBX::Profiler::PerFrameTelemetry::enterTelemetryRegion(a1: v2, a2: v65, a3: 1); /*0x10686d14a*/
  v65[8] = 1; /*0x10686d14d*/
  v4 = 0; /*0x10686d15e*/
  if ( *(_DWORD *)(*((_QWORD *)this + 48) + 18792LL) != 0 ) /*0x10686d163*/
    goto LABEL_86; /*0x10686d163*/
  LOBYTE(v61) = 0; /*0x10686d16b*/
  v63 = 0; /*0x10686d171*/
  if ( DFFlag::DebugNetworkProfiler == 1 /*0x10686d19d*/
    && *(_BYTE *)(*((_QWORD *)this + 48) + 15568LL) == 1
    && DFFlag::DebugNetworkProfilerDeserialize == 1 )
  {
    v61 = *((_QWORD *)this + 48); /*0x10686d1a6*/
    __bzero(a1: v62, a2: 2080); /*0x10686d1b2*/
    v63 = 1; /*0x10686d1b7*/
  }
  RBX::Time::nowFast(this: v3); /*0x10686d1bf*/
  *((_QWORD *)this + 115) = v5; /*0x10686d1c4*/
  v76 = (RBX::Network::DeserializePacketsJob *)((char *)this + 392); /*0x10686d1d3*/
  v77 = 1; /*0x10686d1da*/
  RSL::Mutex::lock(this: (RBX::Network::DeserializePacketsJob *)((char *)this + 392)); /*0x10686d1e1*/
  v66[0] = 0; /*0x10686d1e8*/
  v67 = 0; /*0x10686d1ee*/
  Dangerous_DEPRECATED = (const RBX::DataModel *)RBX::DataModel::getDangerous_DEPRECATED( /*0x10686d1fb*/
                                                   this: *((RBX::DataModel **)this + 48),
                                                   a2: v6);
  RBX::DataModel::getScopedEngineContextRef(this: (RBX::DataModel *)&v88, a2: Dangerous_DEPRECATED); /*0x10686d20a*/
  std::__optional_storage_base<RBX::ScopedEngineContextRef,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::ScopedEngineContextRef,false>>(this: (RBX::ScopedEngineContextRef *)v66); /*0x10686d220*/
  if ( BYTE8(v89) == 1 ) /*0x10686d22c*/
    RBX::ScopedEngineContextRef::~ScopedEngineContextRef(this: (RBX::ScopedEngineContextRef *)&v88); /*0x10686d235*/
  v8 = *(void (__fastcall ****)(_QWORD))(*((_QWORD *)this + 48) + 21752LL); /*0x10686d241*/
  if ( v8 != nullptr ) /*0x10686d24b*/
    (**v8)(a1: v8); /*0x10686d250*/
  v82 = (RBX::Network::DeserializePacketsJob *)((char *)this + 464); /*0x10686d259*/
  v81 = (RBX::Network::DeserializePacketsJob *)((char *)this + 536); /*0x10686d267*/
  v72 = (char *)this + 552; /*0x10686d275*/
  v68 = (__int64 *)((char *)this + 616); /*0x10686d283*/
  v73 = (char *)this + 648; /*0x10686d291*/
  v83 = (RBX::Network::DeserializePacketsJob *)((char *)this + 656); /*0x10686d29f*/
  v70 = (char *)this + 432; /*0x10686d2ad*/
  v79 = &v95[9]; /*0x10686d2bb*/
  v80 = (RBX::Network::NetworkStream *)&v95[1]; /*0x10686d2c9*/
  v71[1] = (char *)this + 528; /*0x10686d2d7*/
  v69 = (__int64 *)((char *)this + 872); /*0x10686d2e5*/
  while ( (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: v82) != 0
       || *((_QWORD *)this + 4 * (FFlag::RefactorIngressFlow & 1u) + 53) != 0 )
  {
    if ( (FFlag::RefactorIngressFlow & 1) != 0 ) /*0x10686d327*/
    {
      if ( RBX::Network::IncomingPacket::data(this: v83) == 0 /*0x10686d358*/
        && *((_QWORD *)this + 4 * (unsigned int)(unsigned __int8)FFlag::RefactorIngressFlow + 53) != 0 )
      {
        RBX::UnboundedCircularBuffer<RBX::Network::IncomingPacket>::pop_front(a1: &v96, a2: v70); /*0x10686d368*/
        if ( RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::IncomingPacket *)&v96) != 0 ) /*0x10686d378*/
          *((_QWORD *)this + 114) = *(_QWORD *)(RBX::Network::IncomingPacket::getRakNetPacket(this: (RBX::Network::IncomingPacket *)&v96) /*0x10686d386*/
                                              + 96);
        v10 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: (RBX::Network::IncomingPacket *)&v96); /*0x10686d395*/
        v11 = RBX::Network::IncomingPacket::size(this: (RBX::Network::IncomingPacket *)&v96); /*0x10686d39b*/
        RBX::Network::NetworkStream::NetworkStream( /*0x10686d3aa*/
          this: (RBX::Network::NetworkStream *)&v88,
          a2: v10,
          a3: v11,
          a4: false);
        RBX::Network::NetworkStream::operator=(a1: v82, a2: &v88); /*0x10686d3b9*/
        RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v88); /*0x10686d3c1*/
        *(__m128i *)v84 = _mm_loadu_si128((const __m128i *)&v96); /*0x10686d3d6*/
        *(_OWORD *)&v84[2] = *(_OWORD *)&v97[8]; /*0x10686d3de*/
        v85 = v98; /*0x10686d3ed*/
        std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x10686d402*/
          a1: v86,
          a2: v99);
        RBX::Network::ProcessingPacketV2::ProcessingPacketV2(a1: &v88, a2: v84); /*0x10686d411*/
        RBX::Network::ProcessingPacketV2::operator=(a1: v83, a2: &v88); /*0x10686d420*/
        RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: v79); /*0x10686d42c*/
        RBX::Network::NetworkStream::~NetworkStream(this: v80); /*0x10686d438*/
        if ( BYTE8(v94) == 1 ) /*0x10686d444*/
          RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)&v91); /*0x10686d44d*/
        if ( v87[88] == 1 ) /*0x10686d459*/
          RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v87); /*0x10686d462*/
        if ( v63 == 1 && (unsigned int)RBX::Network::IncomingPacket::size(this: v83) != 0 ) /*0x10686d47e*/
        {
          v12 = RBX::Network::IncomingPacket::operator[](a1: v83, a2: 0); /*0x10686d48e*/
          v13 = RBX::Network::IncomingPacket::size(this: v83); /*0x10686d498*/
          RBX::NetworkProfiler::CapturePackets::record( /*0x10686d4aa*/
            this: (RBX::NetworkProfiler::CapturePackets *)v62,
            a2: v12,
            a3: v13);
        }
        if ( RBX::Network::IncomingPacket::getRakNetPacket(this: v83) != 0 ) /*0x10686d4be*/
        {
          *(_QWORD *)(*((_QWORD *)this + 48) + 18392LL) = *(_QWORD *)(RBX::Network::IncomingPacket::getRakNetPacket(this: v83) /*0x10686d4d7*/
                                                                    + 88);
          *(_QWORD *)(*((_QWORD *)this + 48) + 18400LL) = *(_QWORD *)(RBX::Network::IncomingPacket::getRakNetPacket(this: v83) /*0x10686d4f5*/
                                                                    + 80);
        }
        if ( v100[88] == 1 ) /*0x10686d500*/
          RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v100); /*0x10686d509*/
      }
    }
    else if ( *(_QWORD *)v81 == 0 ) /*0x10686d51b*/
    {
      v9 = *((_QWORD *)this + 53); /*0x10686d67e*/
      if ( v9 != 0 ) /*0x10686d688*/
      {
        v24 = *((_QWORD *)this + 50); /*0x10686d695*/
        v25 = *((_QWORD *)this + 51); /*0x10686d69c*/
        v26 = *((_QWORD *)this + 52); /*0x10686d6a8*/
        *((_QWORD *)this + 52) = (v26 + 1) % v25; /*0x10686d6b9*/
        v27 = *(_QWORD *)(v24 + 8 * (v26 % v25)); /*0x10686d6c0*/
        *((_QWORD *)this + 53) = v9 - 1; /*0x10686d6c7*/
        *((_QWORD *)this + 114) = *(_QWORD *)(v27 + 96); /*0x10686d6d2*/
        RBX::Network::NetworkStream::NetworkStream( /*0x10686d6e6*/
          this: (RBX::Network::NetworkStream *)&v88,
          a2: *(unsigned __int8 **)(v27 + 56),
          a3: *(_DWORD *)(v27 + 48),
          a4: false);
        RBX::Network::NetworkStream::operator=(a1: v82, a2: &v88); /*0x10686d6f5*/
        RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v88); /*0x10686d6fd*/
        v88 = v27; /*0x10686d702*/
        RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)&v89); /*0x10686d71b*/
        v93[0] = operator new[](a1: (RBX::Memory *)0x40, a2: v28); /*0x10686d72a*/
        v93[1] = 8; /*0x10686d731*/
        memset(&v93[2], 0, 23); /*0x10686d74e*/
        *(_OWORD *)v81 = v88; /*0x10686d762*/
        RBX::Network::NetworkStream::operator=(a1: v72, a2: &v89); /*0x10686d76f*/
        v29 = v93[0]; /*0x10686d774*/
        v30 = v93[3]; /*0x10686d77b*/
        v93[0] = 0; /*0x10686d782*/
        v93[3] = 0; /*0x10686d789*/
        v31 = *((_QWORD *)this + 77); /*0x10686d790*/
        *((_QWORD *)this + 77) = v29; /*0x10686d797*/
        v96 = v31; /*0x10686d79e*/
        v32 = *(_OWORD *)&v93[1]; /*0x10686d7a5*/
        *(_OWORD *)&v93[1] = 0; /*0x10686d7af*/
        v33 = *((_OWORD *)this + 39); /*0x10686d7b6*/
        *((_OWORD *)this + 39) = v32; /*0x10686d7be*/
        *(_OWORD *)v97 = v33; /*0x10686d7c5*/
        v34 = *((_QWORD *)this + 80); /*0x10686d7cd*/
        *((_QWORD *)this + 80) = v30; /*0x10686d7d4*/
        *(_QWORD *)&v97[16] = v34; /*0x10686d7db*/
        RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: &v96); /*0x10686d7e9*/
        v35 = v93[4]; /*0x10686d7ee*/
        v36 = v73; /*0x10686d7f6*/
        *(_DWORD *)(v73 + 3) = *(_DWORD *)((char *)&v93[4] + 3); /*0x10686d7fd*/
        *v36 = v35; /*0x10686d800*/
        RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: v93); /*0x10686d809*/
        RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v89); /*0x10686d811*/
        *(__m128i *)(*((_QWORD *)this + 48) + 18392LL) = _mm_shuffle_epi32( /*0x10686d828*/
                                                           _mm_loadu_si128((const __m128i *)(v27 + 80)),
                                                           78);
        if ( v63 == 1 ) /*0x10686d837*/
        {
          v37 = *(_DWORD *)(v27 + 48); /*0x10686d83d*/
          if ( v37 != 0 ) /*0x10686d843*/
            RBX::NetworkProfiler::CapturePackets::record( /*0x10686d857*/
              this: (RBX::NetworkProfiler::CapturePackets *)v62,
              a2: **(_BYTE **)(v27 + 56),
              a3: v37);
        }
      }
    }
    RBX::Time::nowFast(this: (RBX::Time *)v9); /*0x10686d521*/
    *(double *)&v78 = v14; /*0x10686d526*/
    *(double *)v71 = v14; /*0x10686d536*/
    v9 = *((_QWORD *)this + 48); /*0x10686d53e*/
    v15 = *(unsigned __int8 *)(v9 + 18702); /*0x10686d545*/
    v16 = *((_DWORD *)this + v15 + 244); /*0x10686d54c*/
    if ( v16 != 0 && (v14 - *((double *)this + 115)) * 1000.0 + *((double *)this + 45) > (double)v16 ) /*0x10686d57a*/
      goto LABEL_75; /*0x10686d57a*/
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v9 + 752LL))(a1: v9) != 0 ) /*0x10686d58b*/
    {
      v9 = *((_QWORD *)this + 48); /*0x10686ddb2*/
      LOBYTE(v15) = *(_BYTE *)(v9 + 18702); /*0x10686ddb9*/
LABEL_75:
      if ( (v15 & 1) == 0 ) /*0x10686ddc1*/
      {
        v55 = (*(double *)&v78 - *((double *)this + 115)) * 1000.0 + *((double *)this + 45); /*0x10686dde3*/
        _InterlockedExchange64( /*0x10686de16*/
          (volatile __int64 *)(*((_QWORD *)this + 48) + 15832LL),
          COERCE__INT64(v55 - (double)*((int *)this + 244) + *(double *)(v9 + 15832)));
        _InterlockedExchange64( /*0x10686de3c*/
          (volatile __int64 *)(*((_QWORD *)this + 48) + 15840LL),
          COERCE__INT64(fmax(v55, *(double *)(*((_QWORD *)this + 48) + 15840LL))));
        _InterlockedExchange( /*0x10686de59*/
          (volatile __int32 *)(*((_QWORD *)this + 48) + 15848LL),
          *(_DWORD *)(*((_QWORD *)this + 48) + 15848LL) + 1);
      }
      break; /*0x10686de59*/
    }
    if ( v77 == 0 )
    {
      std::__throw_system_error(a1: 1, a2: "unique_lock::unlock: not locked");
      BUG(); /*0x10686df29*/
    }
    RSL::Mutex::unlock(this: v76); /*0x10686d5a5*/
    v77 = 0; /*0x10686d5aa*/
    v17 = *((RBX::Network::Replicator **)this + 48); /*0x10686d5b1*/
    if ( FFlag::RefactorIngressFlow == 1 ) /*0x10686d5c2*/
    {
      if ( (unsigned __int8)RBX::Network::Replicator::deserializeStreamAsyncV2(this: v17, a2: v82) == 0 ) /*0x10686d5e0*/
        goto LABEL_79; /*0x10686d5e0*/
      if ( (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: v82) != 0 ) /*0x10686d5f4*/
      {
        v20 = *((_BYTE *)this + 909); /*0x10686d602*/
        if ( (v20 & 1 | (*((_QWORD *)this + 112) != 0)) == 0 ) /*0x10686d611*/
        {
          if ( DFFlag::DoNotMoveOnIfNotDoneReadingPacket != 0 ) /*0x10686d625*/
            goto LABEL_73; /*0x10686d625*/
LABEL_61:
          if ( *(_BYTE *)(*((_QWORD *)this + 48) + 10391LL) != 1 ) /*0x10686da40*/
            goto LABEL_73; /*0x10686da40*/
          goto LABEL_62; /*0x10686da40*/
        }
      }
      else
      {
        v20 = 1; /*0x10686d861*/
      }
      v38 = *((_QWORD *)this + 121); /*0x10686d864*/
      if ( v38 != 0 ) /*0x10686d86e*/
      {
        *((_QWORD *)this + 121) = 0; /*0x10686d873*/
        v74 = v38; /*0x10686d87a*/
        RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::push_front( /*0x10686d88f*/
          a1: v69,
          a2: &v74,
          a3: v18,
          a4: v19);
        v39 = v74; /*0x10686d894*/
        v74 = 0; /*0x10686d89b*/
        if ( v39 != 0 ) /*0x10686d8a5*/
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v39 + 8LL))(a1: v39); /*0x10686d8aa*/
        v40 = *((_QWORD *)this + 121); /*0x10686d8ad*/
        *((_QWORD *)this + 121) = 0; /*0x10686d8b4*/
        if ( v40 != 0 ) /*0x10686d8c2*/
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v40 + 8LL))(a1: v40); /*0x10686d8c7*/
      }
      v41 = *((_QWORD *)this + 48); /*0x10686d8ca*/
      RBX::Network::ProcessingPacketV2::moveFromV2( /*0x10686d8e9*/
        this: (RBX::Network::ProcessingPacketV2 *)&v88,
        a2: v83,
        a3: (const RBX::Time *)v71,
        a4: v20 & 1);
      rbx::timestamped_safe_queue<RBX::Network::ProcessingPacketV2>::push(a1: v41 + 18848, a2: &v88); /*0x10686d8fb*/
      RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: v79); /*0x10686d907*/
      RBX::Network::NetworkStream::~NetworkStream(this: v80); /*0x10686d913*/
      if ( BYTE8(v94) == 1 ) /*0x10686d91f*/
        RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)&v91); /*0x10686d928*/
      _InterlockedExchange64((volatile __int64 *)(*((_QWORD *)this + 48) + 12464LL), v78); /*0x10686d941*/
      if ( DFFlag::DoNotMoveOnIfNotDoneReadingPacket != 0 ) /*0x10686d94f*/
      {
        if ( (v20 & 1) == 0 ) /*0x10686d960*/
          goto LABEL_73; /*0x10686d960*/
      }
      else if ( (v20 & 1) == 0 ) /*0x10686da30*/
      {
        goto LABEL_61; /*0x10686da30*/
      }
LABEL_62:
      RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)&v88); /*0x10686da46*/
      RBX::Network::NetworkStream::operator=(a1: v82, a2: &v88); /*0x10686da58*/
      RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v88); /*0x10686da60*/
      memset(v95, 0, sizeof(v95)); /*0x10686da99*/
      v94 = 0; /*0x10686daa1*/
      memset(v93, 0, sizeof(v93)); /*0x10686dab9*/
      v92 = 0; /*0x10686dac1*/
      v91 = 0; /*0x10686dac9*/
      v90 = 0; /*0x10686dad1*/
      v89 = 0; /*0x10686dad9*/
      v88 = 0; /*0x10686dae1*/
      RBX::Network::ProcessingPacketV2::ProcessingPacketV2(this: (RBX::Network::ProcessingPacketV2 *)&v88); /*0x10686daec*/
      RBX::Network::ProcessingPacketV2::operator=(a1: v83, a2: &v88); /*0x10686dafb*/
      RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: v79); /*0x10686db07*/
      RBX::Network::NetworkStream::~NetworkStream(this: v80); /*0x10686db13*/
      if ( BYTE8(v94) == 1 ) /*0x10686db1f*/
        RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)&v91); /*0x10686db2c*/
      goto LABEL_73; /*0x10686db31*/
    }
    if ( (unsigned __int8)RBX::Network::Replicator::deserializeStreamAsync_deprecated(this: v17, a2: v82) == 0 ) /*0x10686d64c*/
    {
LABEL_79:
      v4 = 0; /*0x10686dea5*/
      goto LABEL_80; /*0x10686dea5*/
    }
    if ( (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: v82) != 0 /*0x10686d669*/
      && *((_BYTE *)this + 654) != 1 )
    {
      if ( *((_QWORD *)this + 80) == 0 ) /*0x10686db45*/
        goto LABEL_73; /*0x10686db45*/
      v23 = 0; /*0x10686db4b*/
    }
    else
    {
      *((_BYTE *)this + 653) = 1; /*0x10686d66f*/
      v23 = 1; /*0x10686d676*/
    }
    v42 = *((_QWORD *)this + 121); /*0x10686db4e*/
    if ( v42 != 0 ) /*0x10686db58*/
    {
      *((_QWORD *)this + 121) = 0; /*0x10686db5d*/
      v75 = v42; /*0x10686db64*/
      RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::push_front( /*0x10686db79*/
        a1: v68,
        a2: &v75,
        a3: v21,
        a4: v22);
      v43 = v75; /*0x10686db7e*/
      v75 = 0; /*0x10686db85*/
      if ( v43 != 0 ) /*0x10686db8f*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v43 + 8LL))(a1: v43); /*0x10686db94*/
      v44 = *((_QWORD *)this + 121); /*0x10686db97*/
      *((_QWORD *)this + 121) = 0; /*0x10686db9e*/
      if ( v44 != 0 ) /*0x10686dbac*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v44 + 8LL))(a1: v44); /*0x10686dbb1*/
    }
    v45 = *((_QWORD *)this + 48) + 18800LL; /*0x10686dbc0*/
    RBX::Network::ProcessingPacket::moveFrom( /*0x10686dbd4*/
      this: (RBX::Network::ProcessingPacket *)&v88,
      a2: v81,
      a3: (const RBX::Time *)v71);
    rbx::timestamped_safe_queue<RBX::Network::ProcessingPacket>::push(a1: v45, a2: &v88); /*0x10686dbdf*/
    RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: v93); /*0x10686dbeb*/
    RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v89); /*0x10686dbf7*/
    _InterlockedExchange64((volatile __int64 *)(*((_QWORD *)this + 48) + 12464LL), v78); /*0x10686dc10*/
    if ( v23 != 0 ) /*0x10686dc21*/
    {
      RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)&v88); /*0x10686dc2a*/
      RBX::Network::NetworkStream::operator=(a1: v82, a2: &v88); /*0x10686dc39*/
      RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v88); /*0x10686dc41*/
      memset(v93, 0, 40); /*0x10686dc52*/
      v92 = 0; /*0x10686dc5a*/
      v91 = 0; /*0x10686dc62*/
      v90 = 0; /*0x10686dc6a*/
      v89 = 0; /*0x10686dc72*/
      v88 = 0; /*0x10686dc7a*/
      RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)&v89); /*0x10686dc94*/
      v93[0] = operator new[](a1: (RBX::Memory *)0x40, a2: v46); /*0x10686dca3*/
      v93[1] = 8; /*0x10686dcaa*/
      memset(&v93[2], 0, 23); /*0x10686dcc8*/
      *(_OWORD *)v81 = v88; /*0x10686dcdd*/
      RBX::Network::NetworkStream::operator=(a1: v72, a2: &v89); /*0x10686dcf1*/
      v47 = v93[0]; /*0x10686dcf6*/
      v48 = v93[3]; /*0x10686dcfd*/
      v93[0] = 0; /*0x10686dd04*/
      v93[3] = 0; /*0x10686dd0b*/
      v49 = *((_QWORD *)this + 77); /*0x10686dd12*/
      *((_QWORD *)this + 77) = v47; /*0x10686dd19*/
      v96 = v49; /*0x10686dd20*/
      v50 = *(_OWORD *)&v93[1]; /*0x10686dd27*/
      *(_OWORD *)&v93[1] = 0; /*0x10686dd33*/
      v51 = *((_OWORD *)this + 39); /*0x10686dd3b*/
      *((_OWORD *)this + 39) = v50; /*0x10686dd43*/
      *(_OWORD *)v97 = v51; /*0x10686dd4b*/
      v52 = *((_QWORD *)this + 80); /*0x10686dd53*/
      *((_QWORD *)this + 80) = v48; /*0x10686dd5a*/
      *(_QWORD *)&v97[16] = v52; /*0x10686dd61*/
      RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: &v96); /*0x10686dd72*/
      v53 = v93[4]; /*0x10686dd77*/
      v54 = v73; /*0x10686dd81*/
      *(_DWORD *)(v73 + 3) = *(_DWORD *)((char *)&v93[4] + 3); /*0x10686dd88*/
      *v54 = v53; /*0x10686dd8b*/
      RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: v93); /*0x10686dd94*/
      RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v89); /*0x10686dd9c*/
    }
LABEL_73:
    std::unique_lock<RSL::Mutex>::lock[abi:ne200100](a1: (__int64)&v76); /*0x10686dda1*/
  }
  RBX::Time::nowFast(this: (RBX::Time *)v9); /*0x10686de5f*/
  *((double *)this + 45) = (v56 - *((double *)this + 115)) * 1000.0 + *((double *)this + 45); /*0x10686de7c*/
  v57 = *(_QWORD *)(*((_QWORD *)this + 48) + 21752LL); /*0x10686de8b*/
  v4 = 1; /*0x10686de92*/
  if ( v57 != 0 ) /*0x10686de9b*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v57 + 16LL))(a1: v57); /*0x10686dea0*/
LABEL_80:
  if ( v67 == 1 ) /*0x10686deaf*/
    RBX::ScopedEngineContextRef::~ScopedEngineContextRef(this: (RBX::ScopedEngineContextRef *)v66); /*0x10686deb8*/
  if ( v77 == 1 ) /*0x10686dec4*/
    RSL::Mutex::unlock(this: v76); /*0x10686decd*/
  if ( v63 == 1 ) /*0x10686ded9*/
    RBX::Network::DeserializeProfilerScope::~DeserializeProfilerScope(this: (RBX::Network::DeserializeProfilerScope *)&v61); /*0x10686dee2*/
LABEL_86:
  RBX::Profiler::PotentialTelemetryScope::~PotentialTelemetryScope(this: (RBX::Profiler::PotentialTelemetryScope *)v64); /*0x10686dee7*/
  return v4; /*0x10686df06*/
}

// Address: 0x10686e0c2 | Name: __ZN3RBX7Network21DeserializePacketsJob37getNextPacketToDeserialize_deprecatedEv
__int64 __fastcall RBX::Network::DeserializePacketsJob::getNextPacketToDeserialize_deprecated(
        RBX::Network::DeserializePacketsJob *this)
{
  __int64 v1; // r8
  unsigned __int64 v2; // r9
  unsigned __int64 v3; // rtt
  __int64 result; // rax

  v1 = *((_QWORD *)this + 50); /*0x10686e0cd*/
  v2 = *((_QWORD *)this + 51); /*0x10686e0d4*/
  v3 = *((_QWORD *)this + 52); /*0x10686e0e0*/
  *((_QWORD *)this + 52) = (v3 + 1) % v2; /*0x10686e0f1*/
  result = *(_QWORD *)(v1 + 8 * (v3 % v2)); /*0x10686e0f8*/
  --*((_QWORD *)this + 53); /*0x10686e0fc*/
  return result; /*0x10686e103*/
}

// END DeserializePacketsJob part 1/1, 15 functions
