// ReplicatorStats -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 16 functions


// Address: 0x101543bf2 | Name: __ZN3RBX7Network15ReplicatorStatsC2ERKS1_
__int64 __fastcall RBX::Network::ReplicatorStats::ReplicatorStats(
        RBX::Network::ReplicatorStats *this,
        const RBX::Network::ReplicatorStats *a2)
{
  __int128 v4; // xmm1
  __int128 v5; // xmm2
  __int128 v6; // xmm3
  __int64 i; // r13
  __int64 j; // r12
  __int64 k; // r12
  __int64 m; // r12
  __int64 result; // rax
  __int128 v12; // xmm0
  __int128 v13; // xmm1
  __int128 v14; // xmm2

  memcpy(__dst: this, __src: a2, __n: 0x1164u); /*0x101543c0b*/
  *((_DWORD *)this + 1116) = *((_DWORD *)a2 + 1116); /*0x101543c22*/
  std::__function::__value_func<void ()(RBX::Network::ConnectionStats const&)>::__value_func[abi:ne200100]( /*0x101543c37*/
    a1: (char *)this + 4480,
    a2: (char *)a2 + 4480);
  memcpy(__dst: (char *)this + 4528, __src: (char *)a2 + 4528, __n: 0xE1u); /*0x101543c4d*/
  v4 = *(_OWORD *)((char *)a2 + 4776); /*0x101543c5a*/
  v5 = *(_OWORD *)((char *)a2 + 4792); /*0x101543c62*/
  v6 = *(_OWORD *)((char *)a2 + 4805); /*0x101543c6a*/
  *(_OWORD *)((char *)this + 4760) = *(_OWORD *)((char *)a2 + 4760); /*0x101543c72*/
  *(_OWORD *)((char *)this + 4776) = v4; /*0x101543c79*/
  *(_OWORD *)((char *)this + 4792) = v5; /*0x101543c80*/
  *(_OWORD *)((char *)this + 4805) = v6; /*0x101543c87*/
  for ( i = 0; i != 128; i += 32 ) /*0x101543c95*/
    RBX::SmallVector<unsigned short,4u>::SmallVector(a1: (char *)this + i + 4824, a2: (char *)a2 + i + 4824); /*0x101543ca7*/
  memcpy(__dst: (char *)this + 4952, __src: (char *)a2 + 4952, __n: 0x1A0u); /*0x101543cca*/
  memcpy(__dst: (char *)this + 5376, __src: (char *)a2 + 5376, __n: 0xA41u); /*0x101543ce0*/
  for ( j = 0; j != 96; j += 8 ) /*0x101543cf2*/
    RBX::KllSketch::KllSketch( /*0x101543cfd*/
      this: (RBX::Network::ReplicatorStats *)((char *)this + j + 8008),
      a2: (const RBX::Network::ReplicatorStats *)((char *)a2 + j + 8008));
  for ( k = 0; k != 96; k += 8 ) /*0x101543d19*/
    RBX::KllSketch::KllSketch( /*0x101543d24*/
      this: (RBX::Network::ReplicatorStats *)((char *)this + k + 8104),
      a2: (const RBX::Network::ReplicatorStats *)((char *)a2 + k + 8104));
  for ( m = 0; m != 96; m += 8 ) /*0x101543d40*/
    result = RBX::KllSketch::KllSketch( /*0x101543d4b*/
               this: (RBX::Network::ReplicatorStats *)((char *)this + m + 8200),
               a2: (const RBX::Network::ReplicatorStats *)((char *)a2 + m + 8200));
  *(_OWORD *)((char *)this + 8388) = *(_OWORD *)((char *)a2 + 8388); /*0x101543d62*/
  *(_OWORD *)((char *)this + 8376) = *(_OWORD *)((char *)a2 + 8376); /*0x101543d71*/
  *(_OWORD *)((char *)this + 8360) = *(_OWORD *)((char *)a2 + 8360); /*0x101543d80*/
  v12 = *(_OWORD *)((char *)a2 + 8296); /*0x101543d87*/
  v13 = *(_OWORD *)((char *)a2 + 8312); /*0x101543d8f*/
  v14 = *(_OWORD *)((char *)a2 + 8328); /*0x101543d97*/
  *(_OWORD *)((char *)this + 8344) = *(_OWORD *)((char *)a2 + 8344); /*0x101543da7*/
  *(_OWORD *)((char *)this + 8328) = v14; /*0x101543dae*/
  *(_OWORD *)((char *)this + 8312) = v13; /*0x101543db5*/
  *(_OWORD *)((char *)this + 8296) = v12; /*0x101543dbc*/
  return result; /*0x101543dc7*/
}

// Address: 0x10681c5c0 | Name: __ZN3RBX7Network15ReplicatorStatsD1Ev
void __fastcall RBX::Network::ReplicatorStats::~ReplicatorStats(RBX::Network::ReplicatorStats *this)
{
  char *v2; // r14
  __int64 i; // r15
  __int64 j; // r15
  __int64 k; // r15
  char *v6; // r14
  __int64 m; // r15
  char *v8; // rdi
  RBX::Network::ReplicatorStats *v9; // rdi
  __int64 v10; // rax

  v2 = (char *)this + 8288; /*0x10681c5cd*/
  for ( i = 0; i != -96; i -= 8 ) /*0x10681c5d4*/
    RBX::KllSketch::~KllSketch(this: (RBX::KllSketch *)&v2[i]); /*0x10681c5db*/
  for ( j = 0; j != -96; j -= 8 ) /*0x10681c5f1*/
    RBX::KllSketch::~KllSketch(this: (RBX::Network::ReplicatorStats *)((char *)this + j + 0x2000)); /*0x10681c5f8*/
  for ( k = 0; k != -96; k -= 8 ) /*0x10681c60e*/
    RBX::KllSketch::~KllSketch(this: (RBX::Network::ReplicatorStats *)((char *)this + k + 8096)); /*0x10681c615*/
  v6 = (char *)this + 4944; /*0x10681c624*/
  for ( m = -128; m != 0; m += 32 ) /*0x10681c62b*/
  {
    v8 = *((char **)v6 - 3); /*0x10681c632*/
    if ( v6 != v8 ) /*0x10681c639*/
      operator delete(a1: v8); /*0x10681c63b*/
    v6 -= 32; /*0x10681c640*/
  }
  v9 = *((RBX::Network::ReplicatorStats **)this + 564); /*0x10681c64a*/
  if ( v9 == (RBX::Network::ReplicatorStats *)((char *)this + 4480) ) /*0x10681c65b*/
  {
    v10 = 32; /*0x10681c672*/
    goto LABEL_15; /*0x10681c672*/
  }
  v10 = 40; /*0x10681c65d*/
  if ( v9 != nullptr ) /*0x10681c665*/
LABEL_15:
    (*(void (**)(void))(*(_QWORD *)v9 + v10))(); /*0x10681c677*/
}

// Address: 0x106876ba4 | Name: __ZN3RBX7Network15ReplicatorStatsC2Ev
__int64 __fastcall RBX::Network::ReplicatorStats::ReplicatorStats(RBX::Network::ReplicatorStats *this)
{
  __int64 i; // r14
  __int64 j; // r14
  char *v4; // rax
  __int64 k; // rcx
  char *v6; // rax
  __int64 m; // rcx
  double v8; // xmm0_8
  double v9; // xmm0_8
  __int64 v10; // rdi
  __int64 v11; // rdi
  RakNet *v12; // rdi
  __int64 v13; // rax
  RakNet *v14; // rdi
  RakNet *v15; // rdi
  RakNet *v16; // rdi
  RBX::Time *v17; // rdi
  __int64 v18; // xmm0_8
  __int64 v19; // r12
  __int64 n; // r12
  __int64 v21; // r13
  char *v22; // r12
  __int64 ii; // r13
  __int64 jj; // r13
  __int64 kk; // r13
  _BYTE v27[8]; // [rsp+0h] [rbp-70h] BYREF
  char *v28; // [rsp+8h] [rbp-68h]
  _BYTE v29[32]; // [rsp+10h] [rbp-60h] BYREF
  RBX::Time *v30; // [rsp+30h] [rbp-40h]

  for ( i = 20; i != 308; i += 24 ) /*0x106876bc6*/
  {
    *(double *)((char *)this + i - 20) = ((double (*)(void))RBX::Time::now<(RBX::Time::SampleMethod)1>)(); /*0x106876bdb*/
    *(_QWORD *)((char *)this + i - 12) = 0x3FF0000000000000LL; /*0x106876be2*/
    *(_QWORD *)((char *)this + i - 4) = 0; /*0x106876be7*/
  }
  for ( j = 0; j != 288; j += 24 ) /*0x106876bfd*/
  {
    *(double *)((char *)this + j + 288) = ((double (*)(void))RBX::Time::now<(RBX::Time::SampleMethod)1>)(); /*0x106876c05*/
    *(_QWORD *)((char *)this + j + 296) = 0x3FF0000000000000LL; /*0x106876c0f*/
    *(_QWORD *)((char *)this + j + 304) = 0; /*0x106876c17*/
  }
  v4 = (char *)this + 608; /*0x106876c30*/
  for ( k = 0; k != 480; k += 40 ) /*0x106876c37*/
  {
    *(_QWORD *)&v4[k - 32] = 0x3FA999999999999ALL; /*0x106876c46*/
    *(_DWORD *)&v4[k - 24] = 0; /*0x106876c4b*/
    *(_OWORD *)&v4[k - 16] = 0; /*0x106876c53*/
    v4[k] = 1; /*0x106876c58*/
  }
  v6 = (char *)this + 1088; /*0x106876c69*/
  for ( m = 0; m != 480; m += 40 ) /*0x106876c70*/
  {
    *(_QWORD *)&v6[m - 32] = 0x3FA999999999999ALL; /*0x106876c75*/
    *(_DWORD *)&v6[m - 24] = 0; /*0x106876c7a*/
    *(_OWORD *)&v6[m - 16] = 0; /*0x106876c82*/
    v6[m] = 1; /*0x106876c87*/
  }
  *((_QWORD *)this + 192) = 0x3FA999999999999ALL; /*0x106876c98*/
  *((double *)this + 193) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: 0.0); /*0x106876ca4*/
  *((_BYTE *)this + 1552) = 1; /*0x106876caf*/
  *((_QWORD *)this + 195) = 0x3FA999999999999ALL; /*0x106876cb6*/
  *((_OWORD *)this + 98) = 0; /*0x106876cc0*/
  *((_QWORD *)this + 198) = 0; /*0x106876cca*/
  *((_BYTE *)this + 1592) = 1; /*0x106876cd1*/
  *((_QWORD *)this + 200) = &RBX::Network::packetStatsHandleBursts; /*0x106876cdf*/
  *((double *)this + 201) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: 0.0); /*0x106876ceb*/
  *((_BYTE *)this + 1616) = 1; /*0x106876cf3*/
  *((_QWORD *)this + 203) = 0x3FA999999999999ALL; /*0x106876cfa*/
  *((_OWORD *)this + 102) = 0; /*0x106876d04*/
  *((_QWORD *)this + 206) = 0; /*0x106876d0b*/
  *((_BYTE *)this + 1656) = 1; /*0x106876d12*/
  *((_QWORD *)this + 208) = &RBX::Network::packetStatsHandleBursts; /*0x106876d20*/
  *((_QWORD *)this + 209) = 0x3FA999999999999ALL; /*0x106876d27*/
  *((_OWORD *)this + 105) = 0; /*0x106876d2e*/
  *((_QWORD *)this + 212) = 0; /*0x106876d35*/
  *((_BYTE *)this + 1704) = 1; /*0x106876d3c*/
  *((double *)this + 214) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: 0.0); /*0x106876d48*/
  *((_BYTE *)this + 1720) = 1; /*0x106876d50*/
  *((_QWORD *)this + 216) = 0x3FA999999999999ALL; /*0x106876d57*/
  *(_OWORD *)((char *)this + 1736) = 0; /*0x106876d61*/
  *((_QWORD *)this + 219) = 0; /*0x106876d68*/
  *((_BYTE *)this + 1760) = 1; /*0x106876d6f*/
  *((_QWORD *)this + 221) = 0; /*0x106876d76*/
  *((_QWORD *)this + 222) = 0x3FA999999999999ALL; /*0x106876d7d*/
  *(_OWORD *)((char *)this + 1784) = 0; /*0x106876d84*/
  *((_QWORD *)this + 225) = 0; /*0x106876d8b*/
  *((_BYTE *)this + 1808) = 1; /*0x106876d92*/
  *((double *)this + 227) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: 0.0); /*0x106876d9e*/
  *((_BYTE *)this + 1824) = 1; /*0x106876da6*/
  *((_QWORD *)this + 229) = 0x3FA999999999999ALL; /*0x106876dad*/
  *((_OWORD *)this + 115) = 0; /*0x106876db7*/
  *((_QWORD *)this + 232) = 0; /*0x106876dbe*/
  *((_BYTE *)this + 1864) = 1; /*0x106876dc5*/
  *((_QWORD *)this + 234) = 0; /*0x106876dcc*/
  *((_QWORD *)this + 235) = 0x3FA999999999999ALL; /*0x106876dd3*/
  *((_OWORD *)this + 118) = 0; /*0x106876dda*/
  *((_QWORD *)this + 238) = 0; /*0x106876de1*/
  *((_BYTE *)this + 1912) = 1; /*0x106876de8*/
  *((double *)this + 240) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: 0.0); /*0x106876df4*/
  *((_BYTE *)this + 1928) = 1; /*0x106876dfc*/
  *((_QWORD *)this + 242) = 0x3FA999999999999ALL; /*0x106876e03*/
  *(_OWORD *)((char *)this + 1944) = 0; /*0x106876e0d*/
  *((_QWORD *)this + 245) = 0; /*0x106876e14*/
  *((_BYTE *)this + 1968) = 1; /*0x106876e1b*/
  *((_QWORD *)this + 247) = &RBX::Network::packetStatsHandleBursts; /*0x106876e29*/
  *((_QWORD *)this + 248) = 0x3FA999999999999ALL; /*0x106876e30*/
  *(_OWORD *)((char *)this + 1992) = 0; /*0x106876e37*/
  *((_QWORD *)this + 251) = 0; /*0x106876e3e*/
  *((_BYTE *)this + 2016) = 1; /*0x106876e45*/
  *((double *)this + 253) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: 0.0); /*0x106876e51*/
  *((_BYTE *)this + 2032) = 1; /*0x106876e59*/
  *((_QWORD *)this + 255) = 0x3FA999999999999ALL; /*0x106876e60*/
  *((_OWORD *)this + 128) = 0; /*0x106876e6a*/
  *((_QWORD *)this + 258) = 0; /*0x106876e71*/
  *((_BYTE *)this + 2072) = 1; /*0x106876e78*/
  *((_QWORD *)this + 260) = &RBX::Network::packetStatsHandleBursts; /*0x106876e86*/
  *((_QWORD *)this + 261) = 0x3FA999999999999ALL; /*0x106876e8d*/
  *((_OWORD *)this + 131) = 0; /*0x106876e94*/
  *((_QWORD *)this + 264) = 0; /*0x106876e9b*/
  *((_BYTE *)this + 2120) = 1; /*0x106876ea2*/
  *((double *)this + 266) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: 0.0); /*0x106876eae*/
  *((_BYTE *)this + 2136) = 1; /*0x106876eb6*/
  *((_QWORD *)this + 268) = 0x3FA999999999999ALL; /*0x106876ebd*/
  *(_OWORD *)((char *)this + 2152) = 0; /*0x106876ec7*/
  *((_QWORD *)this + 271) = 0; /*0x106876ece*/
  *((_BYTE *)this + 2176) = 1; /*0x106876ed5*/
  *((_QWORD *)this + 273) = 0; /*0x106876edc*/
  *((_QWORD *)this + 274) = 0x3FA999999999999ALL; /*0x106876ee3*/
  *(_OWORD *)((char *)this + 2200) = 0; /*0x106876eea*/
  *((_QWORD *)this + 277) = 0; /*0x106876ef1*/
  *((_BYTE *)this + 2224) = 1; /*0x106876ef8*/
  *(_OWORD *)((char *)this + 2232) = xmmword_109A035F0; /*0x106876f06*/
  *((double *)this + 281) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: 0.05); /*0x106876f12*/
  *((_BYTE *)this + 2256) = 1; /*0x106876f1a*/
  *((_QWORD *)this + 283) = 0x3FA999999999999ALL; /*0x106876f21*/
  *((_OWORD *)this + 142) = 0; /*0x106876f2b*/
  *((_QWORD *)this + 286) = 0; /*0x106876f32*/
  *((_BYTE *)this + 2296) = 1; /*0x106876f39*/
  *((_QWORD *)this + 288) = &RBX::Network::packetStatsHandleBursts; /*0x106876f47*/
  *((_QWORD *)this + 289) = 0x3FA999999999999ALL; /*0x106876f4e*/
  *((_OWORD *)this + 145) = 0; /*0x106876f55*/
  *((_QWORD *)this + 292) = 0; /*0x106876f5c*/
  *((_BYTE *)this + 2344) = 1; /*0x106876f63*/
  *((_QWORD *)this + 294) = 0x3FA999999999999ALL; /*0x106876f6a*/
  *((_DWORD *)this + 590) = 0; /*0x106876f71*/
  *((_OWORD *)this + 148) = 0; /*0x106876f78*/
  *((_BYTE *)this + 2384) = 1; /*0x106876f7f*/
  *((_QWORD *)this + 299) = 0x3FA999999999999ALL; /*0x106876f86*/
  *((_OWORD *)this + 150) = 0; /*0x106876f8d*/
  *((_QWORD *)this + 302) = 0; /*0x106876f94*/
  *((_BYTE *)this + 2424) = 1; /*0x106876f9b*/
  *((_QWORD *)this + 304) = 0x3FA999999999999ALL; /*0x106876fa2*/
  *(_OWORD *)((char *)this + 2440) = 0; /*0x106876fa9*/
  *((_QWORD *)this + 307) = 0; /*0x106876fb0*/
  *((_BYTE *)this + 2464) = 1; /*0x106876fb7*/
  v8 = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: 0.0); /*0x106876fbe*/
  *((double *)this + 309) = v8; /*0x106876fc3*/
  *((_QWORD *)this + 310) = 0x3FF0000000000000LL; /*0x106876fcb*/
  *((_QWORD *)this + 311) = 0; /*0x106876fd2*/
  v9 = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v8); /*0x106876fd9*/
  *((double *)this + 312) = v9; /*0x106876fde*/
  *((_QWORD *)this + 313) = 0x3FF0000000000000LL; /*0x106876fe6*/
  *((_QWORD *)this + 314) = 0; /*0x106876fed*/
  *((double *)this + 315) = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: v9); /*0x106876ff9*/
  *((_BYTE *)this + 2528) = 1; /*0x106877001*/
  *((_QWORD *)this + 317) = 0x3FA999999999999ALL; /*0x106877008*/
  *((_OWORD *)this + 159) = 0; /*0x106877012*/
  *((_QWORD *)this + 320) = 0; /*0x106877019*/
  *((_BYTE *)this + 2568) = 1; /*0x106877020*/
  *((_QWORD *)this + 322) = &RBX::Network::packetStatsHandleBursts; /*0x10687702e*/
  *((_QWORD *)this + 323) = 0x3FA999999999999ALL; /*0x106877035*/
  *((_DWORD *)this + 648) = 0; /*0x10687703c*/
  *(_OWORD *)((char *)this + 2600) = 0; /*0x106877043*/
  *((_BYTE *)this + 2616) = 1; /*0x10687704a*/
  *((_QWORD *)this + 328) = 0x3FD0000000000000LL; /*0x10687705b*/
  *((_DWORD *)this + 658) = 0; /*0x106877062*/
  *((_OWORD *)this + 165) = 0; /*0x106877069*/
  *((_BYTE *)this + 2656) = 1; /*0x106877070*/
  *((_QWORD *)this + 333) = 0xF424000000000LL; /*0x106877081*/
  *((_QWORD *)this + 334) = 0x3FD0000000000000LL; /*0x106877088*/
  *((_DWORD *)this + 670) = 0; /*0x10687708f*/
  *((_OWORD *)this + 168) = 0; /*0x106877096*/
  *((_BYTE *)this + 2704) = 1; /*0x10687709d*/
  *(_OWORD *)((char *)this + 2712) = 0xF424000000000uLL; /*0x1068770ac*/
  *((double *)this + 341) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v10); /*0x1068770b8*/
  RBX::Network::ReplicatorStats::PhysicsSenderStats::PhysicsSenderStats(this: (RBX::Network::ReplicatorStats *)((char *)this + 2736)); /*0x1068770c7*/
  *((_QWORD *)this + 446) = 0x3FA999999999999ALL; /*0x1068770cc*/
  *(_OWORD *)((char *)this + 3576) = 0; /*0x1068770d6*/
  *((_QWORD *)this + 449) = 0; /*0x1068770dd*/
  *((_BYTE *)this + 3600) = 1; /*0x1068770e4*/
  *((_QWORD *)this + 451) = 0x3FA999999999999ALL; /*0x1068770eb*/
  *((_OWORD *)this + 226) = 0; /*0x1068770f2*/
  *((_QWORD *)this + 454) = 0; /*0x1068770f9*/
  *((_BYTE *)this + 3640) = 1; /*0x106877100*/
  RBX::Network::ReplicatorStats::PhysicsPacketDetailedStats::PhysicsPacketDetailedStats(this: (RBX::Network::ReplicatorStats *)((char *)this + 3648)); /*0x10687710e*/
  *((_QWORD *)this + 527) = 0; /*0x106877113*/
  *(_OWORD *)((char *)this + 4200) = 0; /*0x10687711d*/
  *(_OWORD *)((char *)this + 4184) = 0; /*0x106877124*/
  *(_OWORD *)((char *)this + 4168) = 0; /*0x10687712b*/
  *(_OWORD *)((char *)this + 4152) = 0; /*0x106877132*/
  *(_OWORD *)((char *)this + 4136) = 0; /*0x106877139*/
  *(_OWORD *)((char *)this + 4120) = 0; /*0x106877140*/
  *(_OWORD *)((char *)this + 4104) = 0; /*0x106877147*/
  *(_OWORD *)((char *)this + 4088) = 0; /*0x10687714e*/
  *((_QWORD *)this + 528) = 0x3FA999999999999ALL; /*0x106877155*/
  *((_DWORD *)this + 1058) = 0; /*0x10687715c*/
  *((_OWORD *)this + 265) = 0; /*0x106877163*/
  *((_BYTE *)this + 4256) = 1; /*0x10687716a*/
  *((_QWORD *)this + 533) = 0x3FA999999999999ALL; /*0x106877171*/
  *((_DWORD *)this + 1068) = 0; /*0x106877178*/
  *(_OWORD *)((char *)this + 4280) = 0; /*0x10687717f*/
  *((_BYTE *)this + 4296) = 1; /*0x106877186*/
  *((_OWORD *)this + 269) = 0; /*0x10687718d*/
  *(_OWORD *)((char *)this + 4313) = 0; /*0x106877194*/
  *((_QWORD *)this + 542) = 0; /*0x10687719b*/
  *((_DWORD *)this + 1086) = 0; /*0x1068771a2*/
  *((double *)this + 544) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: v11); /*0x1068771ae*/
  *((_QWORD *)this + 545) = 0x3FA999999999999ALL; /*0x1068771b6*/
  *((_OWORD *)this + 273) = 0; /*0x1068771c0*/
  *((_QWORD *)this + 548) = 0; /*0x1068771c7*/
  *((_BYTE *)this + 4392) = 1; /*0x1068771ce*/
  *((_QWORD *)this + 550) = 0x3FA999999999999ALL; /*0x1068771d5*/
  *(_OWORD *)((char *)this + 4408) = 0; /*0x1068771dc*/
  *((_QWORD *)this + 553) = 0; /*0x1068771e3*/
  *((_BYTE *)this + 4432) = 1; /*0x1068771ea*/
  *((_QWORD *)this + 555) = 0; /*0x1068771f1*/
  *((_DWORD *)this + 1112) = 0; /*0x1068771f8*/
  v30 = nullptr; /*0x10687720a*/
  v28 = (char *)this + 4464; /*0x10687720f*/
  RBX::Network::ConnectionStats::ConnectionStats(a1: (char *)this + 4464, a2: 0xFFFFFFFFLL, a3: v29); /*0x10687721b*/
  v12 = v30; /*0x106877220*/
  if ( v30 == (RBX::Time *)v29 ) /*0x106877227*/
  {
    v13 = 32; /*0x106877235*/
  }
  else
  {
    v13 = 40; /*0x106877229*/
    if ( v30 == nullptr ) /*0x106877231*/
      goto LABEL_14; /*0x106877231*/
  }
  (*(void (**)(void))(*(_QWORD *)v30 + v13))(); /*0x10687723d*/
LABEL_14:
  *((_QWORD *)this + 672) = (unsigned int)RakNet::GetTimeMS(this: v12); /*0x106877240*/
  *((_QWORD *)this + 673) = 0; /*0x10687724e*/
  *((_QWORD *)this + 674) = (unsigned int)RakNet::GetTimeMS(this: v14); /*0x106877260*/
  *((_QWORD *)this + 675) = (unsigned int)RakNet::GetTimeMS(this: v15); /*0x10687726e*/
  *((_QWORD *)this + 676) = (unsigned int)RakNet::GetTimeMS(this: v16); /*0x10687727c*/
  *(_OWORD *)((char *)this + 5416) = 0; /*0x106877286*/
  *(_OWORD *)((char *)this + 5432) = 0; /*0x10687728d*/
  *((_QWORD *)this + 681) = 0xFFFFFFFF00000000LL; /*0x10687729e*/
  RBX::Time::nowFast(this: v17); /*0x1068772a5*/
  *((_QWORD *)this + 682) = v18; /*0x1068772aa*/
  *((_QWORD *)this + 683) = 0x3FD0000000000000LL; /*0x1068772bc*/
  v19 = 0; /*0x1068772c3*/
  *((_DWORD *)this + 1368) = 0; /*0x1068772c6*/
  *(_OWORD *)((char *)this + 5480) = 0; /*0x1068772d0*/
  *((_BYTE *)this + 5496) = 1; /*0x1068772d9*/
  *((_QWORD *)this + 688) = 0xF424000000000LL; /*0x1068772e9*/
  *((_QWORD *)this + 689) = 0x3FD0000000000000LL; /*0x1068772f0*/
  *((_DWORD *)this + 1380) = 0; /*0x1068772f7*/
  *(_OWORD *)((char *)this + 5528) = 0; /*0x1068772fe*/
  *((_BYTE *)this + 5544) = 1; /*0x106877305*/
  *((_QWORD *)this + 694) = 0xF424000000000LL; /*0x10687730b*/
  *((_QWORD *)this + 695) = 0x3FD0000000000000LL; /*0x106877312*/
  *((_DWORD *)this + 1392) = 0; /*0x106877319*/
  *(_OWORD *)((char *)this + 5576) = 0; /*0x106877320*/
  *((_BYTE *)this + 5592) = 1; /*0x106877327*/
  *((_OWORD *)this + 350) = 0xF424000000000uLL; /*0x106877335*/
  do /*0x106877357*/
  {
    RBX::Network::TimeIntervalMeter::TimeIntervalMeter(this: (RBX::Network::ReplicatorStats *)((char *)this + v19 + 5616)); /*0x106877347*/
    v19 += 16; /*0x10687734c*/
  }
  while ( v19 != 1136 ); /*0x106877357*/
  for ( n = 0; n != 1136; n += 16 ) /*0x106877360*/
    RBX::Network::TimeIntervalMeter::TimeIntervalMeter(this: (RBX::Network::ReplicatorStats *)((char *)this + n + 6752)); /*0x106877367*/
  *((_QWORD *)this + 986) = 0; /*0x106877379*/
  RBX::Network::TimeIntervalMeter::TimeIntervalMeter(this: (RBX::Network::ReplicatorStats *)((char *)this + 7896)); /*0x10687738b*/
  *(_OWORD *)((char *)this + 7912) = 0; /*0x106877393*/
  *((_QWORD *)this + 991) = 0x3FA999999999999ALL; /*0x10687739a*/
  v21 = 0; /*0x1068773a1*/
  *((_DWORD *)this + 1984) = 0; /*0x1068773a4*/
  *(_OWORD *)((char *)this + 7944) = 0; /*0x1068773ab*/
  *((_BYTE *)this + 7960) = 1; /*0x1068773b4*/
  *((_QWORD *)this + 996) = 0x3FA999999999999ALL; /*0x1068773ba*/
  *((_DWORD *)this + 1994) = 0; /*0x1068773c1*/
  *((_OWORD *)this + 499) = 0; /*0x1068773c8*/
  *((_BYTE *)this + 8000) = 1; /*0x1068773cf*/
  v22 = (char *)this + 8008; /*0x1068773dc*/
  do /*0x1068773fb*/
  {
    RBX::KllSketch::KllSketch(this: (RBX::KllSketch *)&v22[v21], a2: RBX::KllSketch::kDefaultK); /*0x1068773ee*/
    v21 += 8; /*0x1068773f3*/
  }
  while ( v21 != 96 ); /*0x1068773fb*/
  for ( ii = 0; ii != 96; ii += 8 ) /*0x106877404*/
    RBX::KllSketch::KllSketch( /*0x10687740e*/
      this: (RBX::Network::ReplicatorStats *)((char *)this + ii + 8104),
      a2: RBX::KllSketch::kDefaultK);
  for ( jj = 0; jj != 96; jj += 8 ) /*0x106877424*/
    RBX::KllSketch::KllSketch( /*0x10687742e*/
      this: (RBX::Network::ReplicatorStats *)((char *)this + jj + 8200),
      a2: RBX::KllSketch::kDefaultK);
  *(_OWORD *)((char *)this + 8388) = 0; /*0x106877440*/
  *(_OWORD *)((char *)this + 8376) = 0; /*0x106877447*/
  *(_OWORD *)((char *)this + 8360) = 0; /*0x10687744e*/
  *(_OWORD *)((char *)this + 8344) = 0; /*0x106877455*/
  *(_OWORD *)((char *)this + 8328) = 0; /*0x10687745c*/
  *(_OWORD *)((char *)this + 8312) = 0; /*0x106877463*/
  *(_OWORD *)((char *)this + 8296) = 0; /*0x10687746a*/
  for ( kk = 0; kk != 96; kk += 8 ) /*0x106877471*/
  {
    RBX::KllSketch::KllSketch(this: (RBX::KllSketch *)v27, a2: DFInt::ReplicatorStatsSketchK); /*0x106877482*/
    RBX::KllSketch::operator=(a1: &v22[kk], a2: v27); /*0x10687748e*/
    RBX::KllSketch::~KllSketch(this: (RBX::KllSketch *)v27); /*0x106877496*/
  }
  return __stack_chk_guard; /*0x1068774b5*/
}

// Address: 0x1068775ca | Name: __ZN3RBX7Network15ReplicatorStatsC1Ev
__int64 __fastcall RBX::Network::ReplicatorStats::ReplicatorStats(RBX::Network::ReplicatorStats *this)
{
  return RBX::Network::ReplicatorStats::ReplicatorStats(this); /*0x1068775ce*/
}

// Address: 0x106877646 | Name: __ZN3RBX7Network15ReplicatorStats20incrementPacketsSentENS1_10PacketTypeE
__int64 __fastcall RBX::Network::ReplicatorStats::incrementPacketsSent(__int64 a1, unsigned int a2)
{
  return RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::increment(a1: a1 + 24LL * a2, a2: 1); /*0x106877659*/
}

// Address: 0x106877660 | Name: __ZN3RBX7Network15ReplicatorStats20incrementPacketsSentERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
int __fastcall RBX::Network::ReplicatorStats::incrementPacketsSent(__int64 a1, unsigned __int8 *a2)
{
  char v3; // r15
  __int64 v4; // r12
  __int64 v5; // r13
  size_t v6; // rax
  unsigned __int8 *v7; // rdi
  unsigned __int8 *v9; // [rsp+0h] [rbp-40h]
  __int64 v10; // [rsp+8h] [rbp-38h]
  unsigned __int8 *__s1; // [rsp+10h] [rbp-30h]

  v3 = *a2; /*0x106877674*/
  v4 = *a2 >> 1; /*0x10687767b*/
  v9 = a2 + 1; /*0x106877682*/
  v10 = *((_QWORD *)a2 + 1); /*0x10687768a*/
  __s1 = *((unsigned __int8 **)a2 + 2); /*0x106877692*/
  v5 = 0; /*0x106877696*/
  while ( 1 ) /*0x1068776a8*/
  {
    v6 = strlen(__s: RBX::Network::ReplicatorStats::kPacketTypeNames[v5]); /*0x1068776a8*/
    if ( (v3 & 1) == 0 ) /*0x1068776b1*/
      break; /*0x1068776b1*/
    if ( v6 == v10 ) /*0x1068776c2*/
    {
      v7 = __s1; /*0x1068776c4*/
      if ( v6 == -1 ) /*0x1068776cc*/
        std::string::__throw_out_of_range[abi:ne200100](); /*0x106877715*/
      goto LABEL_7; /*0x1068776cc*/
    }
LABEL_8:
    a1 += 24; /*0x1068776dd*/
    if ( ++v5 == 12 ) /*0x1068776e9*/
      return v6; /*0x1068776e9*/
  }
  v7 = v9; /*0x1068776b3*/
  if ( v6 != v4 ) /*0x1068776ba*/
    goto LABEL_8; /*0x1068776ba*/
LABEL_7:
  LODWORD(v6) = memcmp(__s1: v7, __s2: RBX::Network::ReplicatorStats::kPacketTypeNames[v5], __n: v6); /*0x1068776ce*/
  if ( (_DWORD)v6 != 0 ) /*0x1068776db*/
    goto LABEL_8; /*0x1068776db*/
  LODWORD(v6) = RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::increment(a1, a2: 1); /*0x106877710*/
  return v6; /*0x1068776eb*/
}

// Address: 0x106877724 | Name: __ZN3RBX7Network15ReplicatorStats17samplePacketsSentENS1_10PacketTypeEi
__int64 __fastcall RBX::Network::ReplicatorStats::samplePacketsSent(__int64 a1, unsigned int a2, unsigned int a3)
{
  return RBX::RunningAverage<int,double>::sample(a1: a1 + 40LL * a2 + 576, a2: a3); /*0x10687773b*/
}

// Address: 0x106877742 | Name: __ZN3RBX7Network15ReplicatorStats17samplePacketsSentERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEi
int __fastcall RBX::Network::ReplicatorStats::samplePacketsSent(__int64 a1, unsigned __int8 *a2, unsigned int a3)
{
  char v3; // r12
  __int64 v4; // r13
  __int64 v5; // r14
  __int64 v6; // rbx
  size_t v7; // rax
  unsigned __int8 *v8; // rdi
  unsigned __int8 *v10; // [rsp+8h] [rbp-48h]
  __int64 v11; // [rsp+10h] [rbp-40h]
  unsigned __int8 *__s1; // [rsp+18h] [rbp-38h]

  v3 = *a2; /*0x106877759*/
  v4 = *a2 >> 1; /*0x106877760*/
  v10 = a2 + 1; /*0x106877767*/
  v11 = *((_QWORD *)a2 + 1); /*0x10687776f*/
  __s1 = *((unsigned __int8 **)a2 + 2); /*0x106877777*/
  v5 = a1 + 576; /*0x10687777b*/
  v6 = 0; /*0x106877782*/
  while ( 1 ) /*0x106877792*/
  {
    v7 = strlen(__s: RBX::Network::ReplicatorStats::kPacketTypeNames[v6]); /*0x106877792*/
    if ( (v3 & 1) == 0 ) /*0x10687779b*/
      break; /*0x10687779b*/
    if ( v7 == v11 ) /*0x1068777ac*/
    {
      v8 = __s1; /*0x1068777ae*/
      if ( v7 == -1 ) /*0x1068777b6*/
        std::string::__throw_out_of_range[abi:ne200100](); /*0x1068777fd*/
      goto LABEL_7; /*0x1068777b6*/
    }
LABEL_8:
    v5 += 40; /*0x1068777c7*/
    if ( ++v6 == 12 ) /*0x1068777d3*/
      return v7; /*0x1068777d3*/
  }
  v8 = v10; /*0x10687779d*/
  if ( v7 != v4 ) /*0x1068777a4*/
    goto LABEL_8; /*0x1068777a4*/
LABEL_7:
  LODWORD(v7) = memcmp(__s1: v8, __s2: RBX::Network::ReplicatorStats::kPacketTypeNames[v6], __n: v7); /*0x1068777b8*/
  if ( (_DWORD)v7 != 0 ) /*0x1068777c5*/
    goto LABEL_8; /*0x1068777c5*/
  LODWORD(v7) = RBX::RunningAverage<int,double>::sample(a1: v5, a2: a3); /*0x1068777f8*/
  return v7; /*0x1068777d5*/
}

// Address: 0x10687780c | Name: __ZN3RBX7Network15ReplicatorStats24incrementPacketsReceivedENS1_10PacketTypeE
__int64 __fastcall RBX::Network::ReplicatorStats::incrementPacketsReceived(__int64 a1, unsigned int a2)
{
  return RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::increment(a1: a1 + 24LL * a2 + 288, a2: 1); /*0x106877826*/
}

// Address: 0x10687782c | Name: __ZN3RBX7Network15ReplicatorStats24incrementPacketsReceivedERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
int __fastcall RBX::Network::ReplicatorStats::incrementPacketsReceived(__int64 a1, unsigned __int8 *a2)
{
  char v2; // r15
  __int64 v3; // r12
  __int64 v4; // rbx
  __int64 v5; // r13
  size_t v6; // rax
  unsigned __int8 *v7; // rdi
  unsigned __int8 *v9; // [rsp+0h] [rbp-40h]
  __int64 v10; // [rsp+8h] [rbp-38h]
  unsigned __int8 *__s1; // [rsp+10h] [rbp-30h]

  v2 = *a2; /*0x106877840*/
  v3 = *a2 >> 1; /*0x106877847*/
  v9 = a2 + 1; /*0x10687784e*/
  v10 = *((_QWORD *)a2 + 1); /*0x106877856*/
  __s1 = *((unsigned __int8 **)a2 + 2); /*0x10687785e*/
  v4 = a1 + 288; /*0x106877862*/
  v5 = 0; /*0x106877869*/
  while ( 1 ) /*0x10687787b*/
  {
    v6 = strlen(__s: RBX::Network::ReplicatorStats::kPacketTypeNames[v5]); /*0x10687787b*/
    if ( (v2 & 1) == 0 ) /*0x106877884*/
      break; /*0x106877884*/
    if ( v6 == v10 ) /*0x106877895*/
    {
      v7 = __s1; /*0x106877897*/
      if ( v6 == -1 ) /*0x10687789f*/
        std::string::__throw_out_of_range[abi:ne200100](); /*0x1068778e8*/
      goto LABEL_7; /*0x10687789f*/
    }
LABEL_8:
    v4 += 24; /*0x1068778b0*/
    if ( ++v5 == 12 ) /*0x1068778bc*/
      return v6; /*0x1068778bc*/
  }
  v7 = v9; /*0x106877886*/
  if ( v6 != v3 ) /*0x10687788d*/
    goto LABEL_8; /*0x10687788d*/
LABEL_7:
  LODWORD(v6) = memcmp(__s1: v7, __s2: RBX::Network::ReplicatorStats::kPacketTypeNames[v5], __n: v6); /*0x1068778a1*/
  if ( (_DWORD)v6 != 0 ) /*0x1068778ae*/
    goto LABEL_8; /*0x1068778ae*/
  LODWORD(v6) = RBX::TotalCountTimeInterval<int,(RBX::Time::SampleMethod)1>::increment(a1: v4, a2: 1); /*0x1068778e3*/
  return v6; /*0x1068778be*/
}

// Address: 0x1068778f8 | Name: __ZN3RBX7Network15ReplicatorStats21samplePacketsReceivedENS1_10PacketTypeEi
__int64 __fastcall RBX::Network::ReplicatorStats::samplePacketsReceived(__int64 a1, unsigned int a2, unsigned int a3)
{
  return RBX::RunningAverage<int,double>::sample(a1: a1 + 40LL * a2 + 1056, a2: a3); /*0x10687790f*/
}

// Address: 0x106877916 | Name: __ZN3RBX7Network15ReplicatorStats21samplePacketsReceivedERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEi
int __fastcall RBX::Network::ReplicatorStats::samplePacketsReceived(__int64 a1, unsigned __int8 *a2, unsigned int a3)
{
  char v3; // r12
  __int64 v4; // r13
  __int64 v5; // r14
  __int64 v6; // rbx
  size_t v7; // rax
  unsigned __int8 *v8; // rdi
  unsigned __int8 *v10; // [rsp+8h] [rbp-48h]
  __int64 v11; // [rsp+10h] [rbp-40h]
  unsigned __int8 *__s1; // [rsp+18h] [rbp-38h]

  v3 = *a2; /*0x10687792d*/
  v4 = *a2 >> 1; /*0x106877934*/
  v10 = a2 + 1; /*0x10687793b*/
  v11 = *((_QWORD *)a2 + 1); /*0x106877943*/
  __s1 = *((unsigned __int8 **)a2 + 2); /*0x10687794b*/
  v5 = a1 + 1056; /*0x10687794f*/
  v6 = 0; /*0x106877956*/
  while ( 1 ) /*0x106877966*/
  {
    v7 = strlen(__s: RBX::Network::ReplicatorStats::kPacketTypeNames[v6]); /*0x106877966*/
    if ( (v3 & 1) == 0 ) /*0x10687796f*/
      break; /*0x10687796f*/
    if ( v7 == v11 ) /*0x106877980*/
    {
      v8 = __s1; /*0x106877982*/
      if ( v7 == -1 ) /*0x10687798a*/
        std::string::__throw_out_of_range[abi:ne200100](); /*0x1068779d1*/
      goto LABEL_7; /*0x10687798a*/
    }
LABEL_8:
    v5 += 40; /*0x10687799b*/
    if ( ++v6 == 12 ) /*0x1068779a7*/
      return v7; /*0x1068779a7*/
  }
  v8 = v10; /*0x106877971*/
  if ( v7 != v4 ) /*0x106877978*/
    goto LABEL_8; /*0x106877978*/
LABEL_7:
  LODWORD(v7) = memcmp(__s1: v8, __s2: RBX::Network::ReplicatorStats::kPacketTypeNames[v6], __n: v7); /*0x10687798c*/
  if ( (_DWORD)v7 != 0 ) /*0x106877999*/
    goto LABEL_8; /*0x106877999*/
  LODWORD(v7) = RBX::RunningAverage<int,double>::sample(a1: v5, a2: a3); /*0x1068779cc*/
  return v7; /*0x1068779a9*/
}

// Address: 0x1068779e0 | Name: __ZN3RBX7Network15ReplicatorStats18resetSecurityTimesEv
__int64 __fastcall RBX::Network::ReplicatorStats::resetSecurityTimes(RBX::Network::ReplicatorStats *this)
{
  __int64 result; // rax

  result = (unsigned int)RakNet::GetTimeMS(this); /*0x1068779ee*/
  *((_QWORD *)this + 672) = (unsigned int)result; /*0x1068779f0*/
  *((_QWORD *)this + 674) = (unsigned int)result; /*0x1068779f7*/
  *((_QWORD *)this + 675) = (unsigned int)result; /*0x1068779fe*/
  return result; /*0x106877a09*/
}

// Address: 0x106877a0c | Name: __ZN3RBX7Network15ReplicatorStats34recordPropertyCoalesceWithPropertyENS0_18NetworkValueFormatEd
void __fastcall RBX::Network::ReplicatorStats::recordPropertyCoalesceWithProperty(__int64 a1, int a2, double a3)
{
  __int64 v3; // rsi

  v3 = (unsigned int)(16 * a2); /*0x106877a10*/
  ++*(_QWORD *)(a1 + v3 + 5616); /*0x106877a13*/
  ++*(_QWORD *)(a1 + v3 + 6752); /*0x106877a1b*/
  if ( a3 > *(double *)(a1 + 7888) ) /*0x106877a2b*/
    *(double *)(a1 + 7888) = a3; /*0x106877a2d*/
}

// Address: 0x106877a38 | Name: __ZN3RBX7Network15ReplicatorStats20recordPropertyChangeENS0_18NetworkValueFormatE
void __fastcall RBX::Network::ReplicatorStats::recordPropertyChange(__int64 a1, int a2)
{
  ++*(_QWORD *)(a1 + (unsigned int)(16 * a2) + 5616); /*0x106877a3f*/
}

// Address: 0x106877a4a | Name: __ZN3RBX7Network15ReplicatorStats34recordPropertyCoalesceWithInstanceENS0_18NetworkValueFormatE
void __fastcall RBX::Network::ReplicatorStats::recordPropertyCoalesceWithInstance(__int64 a1, int a2)
{
  ++*(_QWORD *)(a1 + (unsigned int)(16 * a2) + 5616); /*0x106877a51*/
  ++*(_QWORD *)(a1 + 7896); /*0x106877a59*/
}

// END ReplicatorStats part 1/1, 16 functions
