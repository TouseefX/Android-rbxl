// ReplicatorItems -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 1 functions


// Address: 0x106808bc5 | Name: __ZN3RBX7Network15ReplicatorItemsL15accumulateValueENSt3__110shared_ptrINS_8InstanceEEEPd
__int64 __fastcall RBX::Network::ReplicatorItems::accumulateValue(double **a1, double *a2)
{
  double *v3; // r14
  __int64 v4; // r15
  __int64 result; // rax
  unsigned int v6; // ecx

  v3 = *a1; /*0x106808bd2*/
  v4 = *((_QWORD *)*a1 + 3); /*0x106808bd5*/
  result = RBX::Reflection::Class_getDescriptorPtr<RBX::Stats::Item>(a1); /*0x106808bd9*/
  if ( v3 != nullptr ) /*0x106808be1*/
  {
    v6 = *(unsigned __int16 *)(v4 + 440) - *(unsigned __int16 *)(result + 440); /*0x106808bf2*/
    result = *(unsigned __int16 *)(result + 442); /*0x106808bf4*/
    if ( v6 <= (unsigned int)result ) /*0x106808bfd*/
    {
      result = (*(__int64 (__fastcall **)(double *))(*(_QWORD *)v3 + 616LL))(a1: v3); /*0x106808c05*/
      *a2 = v3[22] + *a2; /*0x106808c18*/
    }
  }
  return result; /*0x106808c20*/
}

// END ReplicatorItems part 1/1, 1 functions
