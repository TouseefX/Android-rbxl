// ServerReplicator -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 136 functions


// Address: 0x1068994f2 | Name: __ZN3RBX7Network16ServerReplicator15createStatsItemEv
RBX::Network::ServerReplicator *__fastcall RBX::Network::ServerReplicator::createStatsItem(
        RBX::Network::ServerReplicator *this)
{
  RBX::EngineContext *v2; // rdi
  std::__shared_weak_count *v3; // r14
  _QWORD v5[2]; // [rsp+0h] [rbp-40h] BYREF
  __int128 v6; // [rsp+10h] [rbp-30h] BYREF
  _BYTE v7[8]; // [rsp+20h] [rbp-20h] BYREF
  std::__shared_weak_count *v8; // [rsp+28h] [rbp-18h]

  RBX::shared_from<RBX::Network::ServerReplicator>(a1: v7); /*0x106899504*/
  v5[0] = RBX::EngineContext::getThreadLocal(this: v2); /*0x106899512*/
  LODWORD(v5[1]) = 14900; /*0x106899515*/
  RBX::Creatable::createImpl<RBX::Network::ServerStatsItem,RBX::ForceConstructionInCreatable &,std::shared_ptr<RBX::Network::ServerReplicator>>( /*0x106899524*/
    a1: &v6,
    a2: v5,
    a3: v7);
  *(_OWORD *)this = v6; /*0x10689952d*/
  v6 = 0; /*0x106899533*/
  v3 = v8; /*0x106899537*/
  if ( v8 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v8 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106899550*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(a1: v3); /*0x106899558*/
    std::__shared_weak_count::__release_weak(this: v3); /*0x10689955e*/
  }
  return this; /*0x106899566*/
}

// Address: 0x1068995fc | Name: __ZNK3RBX7Network16ServerReplicator21canUseProtocolVersionEi
__int64 __fastcall RBX::Network::ServerReplicator::canUseProtocolVersion(RBX::Network::ServerReplicator *this, int a2)
{
  __int64 result; // rax

  result = *((unsigned int *)this + 5523); /*0x106899600*/
  LOBYTE(result) = (_DWORD)result == 0 || (int)result >= a2; /*0x106899610*/
  return result; /*0x106899612*/
}

// Address: 0x106899614 | Name: __ZN3RBX7Network16ServerReplicatorC2ERNS_28ForceConstructionInCreatableENS0_10Replicator18ReplicatorPeerInfoEPNS0_6ServerENSt3__110unique_ptrINS_11NetworkBase18ConnectionInternalENS8_14default_deleteISB_EEEE
char __fastcall RBX::Network::ServerReplicator::ServerReplicator(
        RBX::Network::Replicator *a1,
        __int64 a2,
        _DWORD *a3,
        RBX::Network::Server *a4)
{
  RBX::Time *v7; // rdi
  __int64 v8; // xmm0_8
  RBX::Time *v9; // rdi
  __int64 v10; // xmm0_8
  __int64 v11; // r14
  RSL::Arena *v12; // rdi
  RBX::Time *v13; // rdi
  __int64 v14; // xmm0_8
  __int64 v15; // rdx
  __int64 v16; // rcx
  RBX::Network::NetworkFilter *v17; // r14
  RBX *v18; // rdi
  signed int v19; // eax
  _QWORD v21[4]; // [rsp+8h] [rbp-A8h] BYREF
  _QWORD v22[4]; // [rsp+28h] [rbp-88h] BYREF
  _DWORD v23[3]; // [rsp+4Ch] [rbp-64h] BYREF
  void *v24[3]; // [rsp+58h] [rbp-58h] BYREF
  RBX *v25; // [rsp+70h] [rbp-40h]
  RBX::Network::Server *v26; // [rsp+78h] [rbp-38h]
  bool isCloudEdit; // [rsp+87h] [rbp-29h]

  isCloudEdit = RBX::Network::Server::isCloudEdit(this: a4); /*0x106899643*/
  v26 = a4; /*0x106899645*/
  v24[0] = (void *)RBX::Network::Server::getMegaReplicator(this: a4); /*0x106899658*/
  v23[0] = 1; /*0x10689965f*/
  RBX::Described<RBX::Network::ServerReplicator,RBX::Network::Replicator>::Described<RBX::ForceConstructionInCreatable &,RBX::Network::Replicator::ReplicatorPeerInfo &,bool,RBX::Network::MegaReplicator *,std::unique_ptr<RBX::NetworkBase::ConnectionInternal>,RBX::Network::ReplicatorType>( /*0x106899679*/
    a1,
    a2: (__int64)v23);
  *(_QWORD *)a1 = off_10CAF2EF8; /*0x10689968f*/
  *((_QWORD *)a1 + 25) = off_10CAF35F0; /*0x106899699*/
  *((_QWORD *)a1 + 26) = off_10CAF3620; /*0x1068996a7*/
  *((_QWORD *)a1 + 27) = off_10CAF3668; /*0x1068996b4*/
  *((_DWORD *)a1 + 5446) = *a3; /*0x1068996bf*/
  *((_QWORD *)a1 + 2724) = 0x4000000000000000LL; /*0x1068996cf*/
  *((_BYTE *)a1 + 21800) = 0; /*0x1068996d9*/
  *((_QWORD *)a1 + 2726) = 16; /*0x1068996e0*/
  *((_QWORD *)a1 + 2727) = 0; /*0x1068996e7*/
  *((_DWORD *)a1 + 5456) = 1065353216; /*0x1068996f4*/
  *(_OWORD *)((char *)a1 + 21832) = 0; /*0x1068996fe*/
  RBX::UnboundedCircularBuffer<rbx::implementation::timestamped_safe_queue_item<RBX::Network::PropSync::detail::PropertyKey>>::UnboundedCircularBuffer( /*0x106899711*/
    a1: (char *)a1 + 21848,
    a2: 8);
  *((_BYTE *)a1 + 21880) = 0; /*0x106899716*/
  *((_QWORD *)a1 + 2737) = 0; /*0x10689971d*/
  *((_OWORD *)a1 + 1369) = xmmword_10A4E7F70; /*0x10689972b*/
  *((_BYTE *)a1 + 21920) = 0; /*0x106899732*/
  *((_QWORD *)a1 + 2741) = 16; /*0x106899739*/
  *((_QWORD *)a1 + 2742) = 0; /*0x106899740*/
  *((_DWORD *)a1 + 5486) = 1065353216; /*0x106899747*/
  *((_OWORD *)a1 + 1372) = 0; /*0x106899751*/
  RBX::UnboundedCircularBuffer<rbx::implementation::timestamped_safe_queue_item<RBX::Network::Sync::AttributeKey const*>>::UnboundedCircularBuffer( /*0x106899764*/
    a1: (char *)a1 + 21968,
    a2: 8);
  *((_BYTE *)a1 + 22000) = 0; /*0x106899769*/
  v25 = (RBX::Network::Replicator *)((char *)a1 + 22016); /*0x106899777*/
  *((_BYTE *)a1 + 22044) = 0; /*0x10689977b*/
  *((_OWORD *)a1 + 1376) = 0; /*0x106899785*/
  *(_OWORD *)((char *)a1 + 22025) = 0; /*0x10689978c*/
  *(_OWORD *)((char *)a1 + 22056) = 0; /*0x106899793*/
  *(_OWORD *)((char *)a1 + 22072) = 0; /*0x10689979a*/
  *((_QWORD *)a1 + 2761) = 0x2400000000LL; /*0x1068997ab*/
  RBX::Time::nowFast(this: v7); /*0x1068997b2*/
  *((_QWORD *)a1 + 2762) = v8; /*0x1068997b7*/
  RBX::Time::nowFast(this: v9); /*0x1068997bf*/
  *((_QWORD *)a1 + 2763) = v10; /*0x1068997c4*/
  RBX::Analytics::InfluxDb::Points::Points(a1: (char *)a1 + 22112, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1068997df*/
  *((_BYTE *)a1 + 22584) = 0; /*0x1068997e4*/
  *((_OWORD *)a1 + 1412) = 0; /*0x1068997ee*/
  *((_OWORD *)a1 + 1413) = 0; /*0x1068997f5*/
  *((_QWORD *)a1 + 2828) = v26; /*0x106899800*/
  *(_QWORD *)&v23[1] = (char *)a1 + 22112; /*0x10689980c*/
  v11 = operator new(a1: 0x60u); /*0x106899815*/
  RBX::Network::SecurityChannel::SecurityChannel(a1: v11, a2: 87); /*0x106899820*/
  *((_QWORD *)a1 + 2829) = v11; /*0x106899825*/
  *((_BYTE *)a1 + 22640) = 1; /*0x10689982e*/
  *(_DWORD *)((char *)a1 + 22641) = 0; /*0x106899836*/
  *((_DWORD *)a1 + 5661) = 0; /*0x10689983c*/
  *((_WORD *)a1 + 11324) = 1; /*0x106899842*/
  *((_OWORD *)a1 + 1416) = 0; /*0x10689984e*/
  *(_QWORD *)((char *)a1 + 22670) = 0; /*0x106899855*/
  *(_OWORD *)((char *)a1 + 22680) = 0; /*0x10689985c*/
  *(_OWORD *)((char *)a1 + 22696) = 0; /*0x106899863*/
  *(_OWORD *)((char *)a1 + 22712) = 0; /*0x10689986a*/
  *(_OWORD *)((char *)a1 + 22728) = 0; /*0x106899871*/
  *((_QWORD *)a1 + 2843) = 0; /*0x106899878*/
  *((_QWORD *)a1 + 2844) = 0x3FA999999999999ALL; /*0x106899889*/
  *((_DWORD *)a1 + 5690) = 0; /*0x106899890*/
  *((_OWORD *)a1 + 1423) = 0; /*0x106899896*/
  *((_BYTE *)a1 + 22784) = 1; /*0x10689989d*/
  *((_QWORD *)a1 + 2849) = 0x3FA999999999999ALL; /*0x1068998a3*/
  *((_DWORD *)a1 + 5700) = 0; /*0x1068998aa*/
  *(_OWORD *)((char *)a1 + 22808) = 0; /*0x1068998b0*/
  *((_BYTE *)a1 + 22824) = 1; /*0x1068998b7*/
  *((_QWORD *)a1 + 2854) = 0x3FA999999999999ALL; /*0x1068998bd*/
  *((_DWORD *)a1 + 5710) = 0; /*0x1068998c4*/
  *((_OWORD *)a1 + 1428) = 0; /*0x1068998ca*/
  *((_BYTE *)a1 + 22864) = 1; /*0x1068998d1*/
  *((_DWORD *)a1 + 5718) = 0; /*0x1068998d7*/
  *((_BYTE *)a1 + 22904) = 0; /*0x1068998dd*/
  *((_BYTE *)a1 + 22960) = 0; /*0x1068998e3*/
  *(_OWORD *)((char *)a1 + 22977) = 0; /*0x1068998f0*/
  *(_OWORD *)((char *)a1 + 22968) = 0; /*0x1068998f7*/
  v21[0] = RBX::Time::nowFast; /*0x10689990c*/
  v21[3] = (char *)&RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::unique_function<RBX::Time (*)(void)>(RBX::Time (*)(void))::Callback /*0x10689991e*/
         + 2;
  RBX::LeakyBucket::LeakyBucket(a1: (char *)a1 + 23000, a2: v21, a3: (float)DFInt::ChatCap, a4: (float)DFInt::ChatTime); /*0x106899930*/
  RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::~unique_function(a1: v21); /*0x10689993c*/
  v22[0] = RBX::Time::nowFast; /*0x10689994f*/
  v22[3] = (char *)&RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::unique_function<RBX::Time (*)(void)>(RBX::Time (*)(void))::Callback /*0x10689995d*/
         + 2;
  RBX::LeakyBucket::LeakyBucket( /*0x10689996f*/
    a1: (char *)a1 + 23056,
    a2: v22,
    a3: (float)DFInt::RejoinRateLimitCap,
    a4: (float)DFInt::RejoinRateLimitTime);
  RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::~unique_function(a1: v22); /*0x10689997b*/
  *((_QWORD *)a1 + 2893) = RSL::Arena::getDefaultArena(this: v12); /*0x106899985*/
  *(_OWORD *)((char *)a1 + 23112) = 0; /*0x10689998f*/
  *(_OWORD *)((char *)a1 + 23128) = 0; /*0x106899996*/
  RBX::Time::nowFast(this: v13); /*0x10689999d*/
  *((_QWORD *)a1 + 2894) = v14; /*0x1068999a2*/
  *((_DWORD *)a1 + 5790) = 0; /*0x1068999aa*/
  std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "ServerReplicator", a3: v15, a4: v16); /*0x1068999bf*/
  RBX::Instance::setName(a1, a2: v24); /*0x1068999cb*/
  if ( ((__int64)v24[0] & 1) != 0 ) /*0x1068999d4*/
    operator delete(a1: v24[2]); /*0x1068999da*/
  *((_DWORD *)a1 + 4072) = *a3; /*0x1068999e3*/
  v17 = (RBX::Network::NetworkFilter *)operator new(a1: 8u); /*0x1068999f3*/
  RBX::Network::NetworkFilter::NetworkFilter(this: v17, a2: a1); /*0x1068999fc*/
  std::unique_ptr<RBX::Network::NetworkFilter>::reset[abi:ne200100](a1: v25, a2: v17); /*0x106899a08*/
  *((_BYTE *)a1 + 15550) = 0; /*0x106899a0d*/
  *((_QWORD *)a1 + 859) = *((_QWORD *)a1 + 2762); /*0x106899a1b*/
  v19 = (unsigned int)RBX::globalRand(this: v18) % 0x186A0; /*0x106899a3d*/
  if ( v19 < FInt::EventReportLagThrottleHundredThousandths ) /*0x106899a48*/
  {
    LOBYTE(v19) = RBX::Network::Server::isCloudEdit(this: v26); /*0x106899a4e*/
    if ( (_BYTE)v19 == 0 ) /*0x106899a55*/
      *((_BYTE *)a1 + 18600) = 1; /*0x106899a57*/
  }
  return v19; /*0x106899a5e*/
}

// Address: 0x106899db6 | Name: __ZN3RBX7Network16ServerReplicatorC1ERNS_28ForceConstructionInCreatableENS0_10Replicator18ReplicatorPeerInfoEPNS0_6ServerENSt3__110unique_ptrINS_11NetworkBase18ConnectionInternalENS8_14default_deleteISB_EEEE
char __fastcall RBX::Network::ServerReplicator::ServerReplicator(
        RBX::Network::Replicator *a1,
        __int64 a2,
        _DWORD *a3,
        RBX::Network::Server *a4)
{
  return RBX::Network::ServerReplicator::ServerReplicator(a1, a2, a3, a4); /*0x106899dba*/
}

// Address: 0x106899dc0 | Name: __ZN3RBX7Network16ServerReplicatorD2Ev
void __fastcall RBX::Network::ServerReplicator::~ServerReplicator(RBX::Network::ServerReplicator *this)
{
  void *v2; // rdi

  *(_QWORD *)this = off_10CAF2EF8; /*0x106899dd4*/
  *((_QWORD *)this + 25) = off_10CAF35F0; /*0x106899dde*/
  *((_QWORD *)this + 26) = off_10CAF3620; /*0x106899dec*/
  *((_QWORD *)this + 27) = off_10CAF3668; /*0x106899df9*/
  if ( *((_BYTE *)this + 18600) == 1 ) /*0x106899e07*/
    RBX::Network::Replicator::sendStatsToEventIngest(this); /*0x106899e0c*/
  RBX::details::SplitHashTable<RBX::Instance const*,std::pair<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Instance const*>,RBX::details::DefaultEqualTo<RBX::Instance const*>,RBX::details::GetMapKey<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>>::freeInternalMemoryAndLeaveUninitialized(a1: (char *)this + 23112); /*0x106899e18*/
  RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::~unique_function(a1: (char *)this + 23080); /*0x106899e24*/
  RBX::unique_function<RBX::Time ()(void),24ul,8ul,true>::~unique_function(a1: (char *)this + 23024); /*0x106899e30*/
  v2 = *((void **)this + 2871); /*0x106899e35*/
  if ( v2 != nullptr ) /*0x106899e3f*/
  {
    *((_QWORD *)this + 2872) = v2; /*0x106899e41*/
    operator delete(a1: v2); /*0x106899e48*/
  }
  std::__optional_destruct_base<RBX::Security::EarlyAuthData,false>::~__optional_destruct_base[abi:ne200100](a1: (char *)this + 22904); /*0x106899e54*/
  if ( (*((_BYTE *)this + 22720) & 1) != 0 ) /*0x106899e60*/
    operator delete(a1: *((void **)this + 2842)); /*0x106899e69*/
  std::shared_ptr<RBX::Player>::~shared_ptr[abi:ne200100](a1: (char *)this + 22704); /*0x106899e75*/
  if ( (*((_BYTE *)this + 22680) & 1) != 0 ) /*0x106899e81*/
    operator delete(a1: *((void **)this + 2837)); /*0x106899e8a*/
  std::shared_ptr<RBX::Reflection::ValueTable const>::~shared_ptr[abi:ne200100](a1: (__int64)this + 22656); /*0x106899e96*/
  std::unique_ptr<RBX::Network::SecurityChannel>::reset[abi:ne200100](a1: (char *)this + 22632, a2: 0); /*0x106899ea4*/
  std::shared_ptr<RBX::PlayerGui>::~shared_ptr[abi:ne200100](a1: (char *)this + 22608); /*0x106899eb0*/
  std::shared_ptr<RBX::Player>::~shared_ptr[abi:ne200100](a1: (char *)this + 22592); /*0x106899ebc*/
  RBX::Analytics::InfluxDb::Points::~Points(this: (void **)this + 2764); /*0x106899ec8*/
  std::shared_ptr<RBX::TaskScheduler::Job>::~shared_ptr[abi:ne200100](a1: (char *)this + 22072); /*0x106899ed4*/
  std::shared_ptr<RBX::Network::ServerSchemaInfo const>::~shared_ptr[abi:ne200100](a1: (char *)this + 22024); /*0x106899ee0*/
  std::unique_ptr<RBX::Network::NetworkFilter>::reset[abi:ne200100](a1: (char *)this + 22016, a2: 0); /*0x106899eee*/
  RBX::UnboundedCircularBuffer<rbx::implementation::timestamped_safe_queue_item<RBX::Network::Sync::AttributeKey const*>>::~UnboundedCircularBuffer(a1: (char *)this + 21968); /*0x106899efa*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::Sync::AttributeKey const,RBX::Network::Sync::MasterItem>>,RBX::Network::Sync::AttributeKey,RBX::Network::Sync::MasterItem,boost::hash<RBX::Network::Sync::AttributeKey>,std::equal_to<RBX::Network::Sync::AttributeKey>>>::delete_buckets(a1: (__int64)this + 21920); /*0x106899f06*/
  RBX::UnboundedCircularBuffer<rbx::implementation::timestamped_safe_queue_item<RBX::Network::PropSync::detail::PropertyKey>>::~UnboundedCircularBuffer(a1: (char *)this + 21848); /*0x106899f12*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const,RBX::Network::PropSync::detail::MasterItem>>,RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::MasterItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey>>>::delete_buckets(a1: (__int64)this + 21800); /*0x106899f1e*/
  RBX::Network::Replicator::~Replicator(this); /*0x106899f2c*/
}

// Address: 0x106899f40 | Name: __ZN3RBX7Network16ServerReplicatorD1Ev
void __fastcall RBX::Network::ServerReplicator::~ServerReplicator(RBX::Network::ServerReplicator *this)
{
  RBX::Network::ServerReplicator::~ServerReplicator(this); /*0x106899f45*/
}

// Address: 0x106899f4a | Name: __ZThn200_N3RBX7Network16ServerReplicatorD1Ev
void __fastcall `non-virtual thunk to'RBX::Network::ServerReplicator::~ServerReplicator(
        RBX::Network::ServerReplicator *this)
{
  RBX::Network::ServerReplicator::~ServerReplicator(this: (RBX::Network::ServerReplicator *)((char *)this - 200)); /*0x106899f56*/
}

// Address: 0x106899f5c | Name: __ZThn208_N3RBX7Network16ServerReplicatorD1Ev
void __fastcall `non-virtual thunk to'RBX::Network::ServerReplicator::~ServerReplicator(
        RBX::Network::ServerReplicator *this)
{
  RBX::Network::ServerReplicator::~ServerReplicator(this: (RBX::Network::ServerReplicator *)((char *)this - 208)); /*0x106899f68*/
}

// Address: 0x106899f6e | Name: __ZThn216_N3RBX7Network16ServerReplicatorD1Ev
void __fastcall `non-virtual thunk to'RBX::Network::ServerReplicator::~ServerReplicator(
        RBX::Network::ServerReplicator *this)
{
  RBX::Network::ServerReplicator::~ServerReplicator(this: (RBX::Network::ServerReplicator *)((char *)this - 216)); /*0x106899f7a*/
}

// Address: 0x106899f80 | Name: __ZN3RBX7Network16ServerReplicatorD0Ev
void __fastcall RBX::Network::ServerReplicator::~ServerReplicator(RBX::Network::ServerReplicator *this)
{
  RBX::Network::ServerReplicator::~ServerReplicator(this); /*0x106899f89*/
  operator delete(a1: this); /*0x106899f97*/
}

// Address: 0x106899f9c | Name: __ZThn200_N3RBX7Network16ServerReplicatorD0Ev
void __fastcall `non-virtual thunk to'RBX::Network::ServerReplicator::~ServerReplicator(
        RBX::Network::ServerReplicator *this)
{
  char *v1; // rbx

  v1 = (char *)this - 200; /*0x106899fa5*/
  RBX::Network::ServerReplicator::~ServerReplicator(this: (RBX::Network::ServerReplicator *)((char *)this - 200)); /*0x106899faf*/
  operator delete(a1: v1); /*0x106899fbd*/
}

// Address: 0x106899fc2 | Name: __ZThn208_N3RBX7Network16ServerReplicatorD0Ev
void __fastcall `non-virtual thunk to'RBX::Network::ServerReplicator::~ServerReplicator(
        RBX::Network::ServerReplicator *this)
{
  char *v1; // rbx

  v1 = (char *)this - 208; /*0x106899fcb*/
  RBX::Network::ServerReplicator::~ServerReplicator(this: (RBX::Network::ServerReplicator *)((char *)this - 208)); /*0x106899fd5*/
  operator delete(a1: v1); /*0x106899fe3*/
}

// Address: 0x106899fe8 | Name: __ZThn216_N3RBX7Network16ServerReplicatorD0Ev
void __fastcall `non-virtual thunk to'RBX::Network::ServerReplicator::~ServerReplicator(
        RBX::Network::ServerReplicator *this)
{
  char *v1; // rbx

  v1 = (char *)this - 216; /*0x106899ff1*/
  RBX::Network::ServerReplicator::~ServerReplicator(this: (RBX::Network::ServerReplicator *)((char *)this - 216)); /*0x106899ffb*/
  operator delete(a1: v1); /*0x10689a009*/
}

// Address: 0x10689a00e | Name: __ZN3RBX7Network16ServerReplicator43readPlayerFocusInstantAndSimulationRegion3dERNS_21Region3SimulationCellE
__int64 __fastcall RBX::Network::ServerReplicator::readPlayerFocusInstantAndSimulationRegion3d(__int64 a1, __int64 a2)
{
  RBX::Player *v3; // rax
  RBX::Player *v4; // r14
  __int64 result; // rax
  _DWORD v6[9]; // [rsp+0h] [rbp-40h] BYREF
  __int64 v7; // [rsp+24h] [rbp-1Ch]
  int v8; // [rsp+2Ch] [rbp-14h]

  v3 = (RBX::Player *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 688LL))(a1); /*0x10689a01f*/
  if ( v3 == nullptr ) /*0x10689a028*/
    return 0; /*0x10689a028*/
  v4 = v3; /*0x10689a02a*/
  *(_OWORD *)v6 = 0x3F800000u; /*0x10689a039*/
  *(_OWORD *)&v6[4] = 0x3F800000u; /*0x10689a03c*/
  v6[8] = 1065353216; /*0x10689a040*/
  v7 = 0; /*0x10689a047*/
  v8 = 0; /*0x10689a04f*/
  result = RBX::Player::getReplicationFocusCFrame2(this: v3, a2: (RBX::CoordinateFrame *)v6); /*0x10689a059*/
  if ( result == 0 ) /*0x10689a061*/
    return 0; /*0x10689a083*/
  *(_DWORD *)(a2 + 8) = v8; /*0x10689a06a*/
  *(_QWORD *)a2 = v7; /*0x10689a070*/
  *(_DWORD *)(a2 + 12) = *((_DWORD *)v4 + 216); /*0x10689a07c*/
  return result; /*0x10689a085*/
}

// Address: 0x10689a0c0 | Name: __ZN3RBX7Network16ServerReplicator23checkDistributedReceiveEPNS_8BasePartE
char __fastcall RBX::Network::ServerReplicator::checkDistributedReceive(
        RBX::Network::ServerReplicator *this,
        RBX::Mechanism **a2)
{
  RBX::BasePart *RootMovingPrimitive; // rax
  RBX::Primitive *v5; // rsi
  RBX::Mechanism **v6; // rax

  RootMovingPrimitive = (RBX::BasePart *)RBX::Mechanism::getRootMovingPrimitive(this: a2[47], (RBX::Primitive *)a2); /*0x10689a0d4*/
  v6 = (RBX::Mechanism **)RBX::BasePart::fromPrimitive(this: RootMovingPrimitive, a2: v5); /*0x10689a0dc*/
  return (v6 == a2) /*0x10689a0ff*/
       & ((unsigned int)RBX::BasePartProp::getNetworkOwner(this: (RBX::BasePartProp *)(v6 + 23)) == *((_DWORD *)this + 68));
}

// Address: 0x10689a104 | Name: __ZN3RBX7Network16ServerReplicator16rebroadcastEventEPNS0_31DeserializedEventInvocationItemE
void __fastcall RBX::Network::ServerReplicator::rebroadcastEvent(
        RBX::Network::MegaReplicator **this,
        RBX::Network::DeserializedEventInvocationItem *a2)
{
  __int128 v2; // [rsp+8h] [rbp-48h] BYREF
  char v3; // [rsp+18h] [rbp-38h]
  void *v4; // [rsp+28h] [rbp-28h]
  char v5; // [rsp+40h] [rbp-10h]

  if ( *((_QWORD *)a2 + 6) != 0 && *((_QWORD *)a2 + 4) != 0 ) /*0x10689a121*/
  {
    RBX::Network::MegaReplicator::addToRebroadcastList(this: *(this + 1801)); /*0x10689a138*/
  }
  else
  {
    LOBYTE(v2) = 0; /*0x10689a143*/
    v5 = 0; /*0x10689a145*/
    RBX::Network::Replicator::requestDisconnect(a1: (__int64)this, a2: 0x104u, a3: &v2); /*0x10689a150*/
    if ( v5 == 1 && (v3 & 1) != 0 ) /*0x10689a15f*/
      operator delete(a1: v4); /*0x10689a165*/
  }
}

// Address: 0x10689a18c | Name: __ZN3RBX7Network16ServerReplicator20stageGraphParamRelayEPNS0_31DeserializedEventInvocationItemE
void __fastcall RBX::Network::ServerReplicator::stageGraphParamRelay(
        RBX::Network::ServerReplicator *this,
        RBX::Network::DeserializedEventInvocationItem *a2)
{
  __int64 v4; // rbx
  __int64 v5; // r12
  __int64 v6; // rax
  __int64 v7; // rdi
  unsigned int v8; // ecx
  unsigned int v9; // eax
  __int64 v10; // rdx
  __int64 *v11; // rax
  __int64 v12; // rbx
  __int64 v13; // rdi
  __int64 v14; // rbx
  __int64 v15; // rdi
  __int64 *v16; // rbx
  __int64 v17; // r12
  const char *v18; // rsi
  __int64 v19; // rax
  _QWORD *v20; // rbx
  __int128 *v21; // rdi
  _QWORD *v22; // rbx
  void *v23; // rdi
  _QWORD *v24; // rbx
  __int64 v25; // r12
  const char *v26; // rsi
  __int64 v27; // rax
  __int64 *v28; // rbx
  __int64 v29; // r13
  volatile signed __int64 *v30; // rbx
  __int64 v31; // rax
  int v32; // edx
  __int64 v33; // rax
  _QWORD *v34; // r12
  _DWORD *v35; // r12
  __int64 v36; // rax
  unsigned int v37; // edx
  _QWORD *v38; // r14
  _QWORD *i; // r13
  _QWORD v40[68]; // [rsp+0h] [rbp-2C0h] BYREF
  __int128 v41; // [rsp+220h] [rbp-A0h] BYREF
  char v42; // [rsp+230h] [rbp-90h]
  void *v43; // [rsp+240h] [rbp-80h]
  char v44; // [rsp+258h] [rbp-68h]
  __int64 v45; // [rsp+260h] [rbp-60h]
  volatile signed __int64 *v46; // [rsp+268h] [rbp-58h]
  __int16 v47; // [rsp+270h] [rbp-50h] BYREF
  __int128 v48; // [rsp+278h] [rbp-48h] BYREF
  void *v49; // [rsp+288h] [rbp-38h]
  __int64 v50[6]; // [rsp+290h] [rbp-30h] BYREF

  if ( *((_QWORD *)a2 + 6) != 0 ) /*0x10689a1a8*/
  {
    v4 = *((_QWORD *)a2 + 4); /*0x10689a1b1*/
    if ( v4 != 0 ) /*0x10689a1b8*/
    {
      v5 = *(_QWORD *)(v4 + 24); /*0x10689a1be*/
      v6 = RBX::Instance::classDescriptor(this); /*0x10689a1c2*/
      v8 = *(unsigned __int16 *)(v5 + 440) - *(unsigned __int16 *)(v6 + 440); /*0x10689a1d7*/
      v9 = *(unsigned __int16 *)(v6 + 442); /*0x10689a1d9*/
      v10 = 0; /*0x10689a1e0*/
      if ( v8 <= v9 ) /*0x10689a1e4*/
        v10 = v4; /*0x10689a1e4*/
      v50[0] = v10; /*0x10689a1e8*/
      if ( v8 > v9 ) /*0x10689a1ec*/
        return; /*0x10689a1ec*/
      v11 = *((__int64 **)a2 + 7); /*0x10689a1f2*/
      if ( 0xCCCCCCCCCCCCCCCDLL * ((__int64)(*((_QWORD *)a2 + 8) - (_QWORD)v11) >> 4) < 2 ) /*0x10689a213*/
        return; /*0x10689a213*/
      v12 = *v11; /*0x10689a219*/
      if ( RBX::Reflection::Type::getSingleton<RBX::ContentId>(a1: v7) != v12 ) /*0x10689a224*/
        return; /*0x10689a224*/
      v14 = *(_QWORD *)(*((_QWORD *)a2 + 7) + 80LL); /*0x10689a22e*/
      if ( RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::ValueTable const>>(a1: v13) != v14 ) /*0x10689a23a*/
        return; /*0x10689a23a*/
      v16 = *((__int64 **)a2 + 7); /*0x10689a23c*/
      v17 = *v16; /*0x10689a240*/
      if ( RBX::Reflection::Type::getSingleton<RBX::ContentId>(a1: v15) != v17 ) /*0x10689a24b*/
        RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v18); /*0x10689a4dd*/
      v19 = v16[1]; /*0x10689a251*/
      v20 = v16 + 2; /*0x10689a255*/
      if ( v19 == 0 ) /*0x10689a25c*/
        v20 = nullptr; /*0x10689a25c*/
      v21 = &v48; /*0x10689a263*/
      v47 = *(_WORD *)v20; /*0x10689a267*/
      if ( (v20[1] & 1) != 0 ) /*0x10689a26f*/
      {
        std::string::__init_copy_ctor_external(a1: &v48, a2: v20[3], a3: v20[2]); /*0x10689a2d2*/
      }
      else
      {
        v22 = v20 + 1; /*0x10689a271*/
        v49 = (void *)v22[2]; /*0x10689a279*/
        v48 = *(_OWORD *)v22; /*0x10689a280*/
      }
      v24 = *((_QWORD **)a2 + 7); /*0x10689a2d7*/
      v25 = v24[10]; /*0x10689a2db*/
      if ( RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::ValueTable const>>(a1: v21) != v25 ) /*0x10689a2e7*/
        RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v26); /*0x10689a4eb*/
      v27 = v24[11]; /*0x10689a2ed*/
      v28 = v24 + 12; /*0x10689a2f1*/
      if ( v27 == 0 ) /*0x10689a2f8*/
        v28 = nullptr; /*0x10689a2f8*/
      v29 = *v28; /*0x10689a2fc*/
      v45 = *v28; /*0x10689a2ff*/
      v30 = (volatile signed __int64 *)v28[1]; /*0x10689a303*/
      v46 = v30; /*0x10689a307*/
      if ( v30 != nullptr ) /*0x10689a30e*/
        _InterlockedIncrement64(v30 + 1); /*0x10689a310*/
      if ( v29 == 0 || *(_QWORD *)(v29 + 24) == 0 ) /*0x10689a323*/
        goto LABEL_43; /*0x10689a323*/
      v31 = RBX::details::SplitHashTable<RBX::Instance const*,std::pair<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Instance const*>,RBX::details::DefaultEqualTo<RBX::Instance const*>,RBX::details::GetMapKey<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>>::find_as<RBX::Instance const*>( /*0x10689a337*/
              a1: (char *)this + 23112,
              a2: v50);
      if ( v31 != 0 || v32 != 0 || *((_DWORD *)this + 5778) < DFInt::ReplicatorAnimationTrackLimitPerAnimator ) /*0x10689a35b*/
      {
        v33 = RBX::details::SplitHashTable<RBX::Instance const*,std::pair<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Instance const*>,RBX::details::DefaultEqualTo<RBX::Instance const*>,RBX::details::GetMapKey<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>>::emplace<RBX::Instance const*>(this: (RBX::Network::ServerReplicator *)((char *)this + 23112)); /*0x10689a368*/
        v34 = (_QWORD *)(*((_QWORD *)this + 2891) + ((unsigned __int64)(unsigned int)v33 << 6)); /*0x10689a374*/
        if ( (v33 & 0x100000000LL) != 0 ) /*0x10689a380*/
          *v34 = v50[0]; /*0x10689a386*/
        if ( v34[1] == 0 ) /*0x10689a390*/
          std::shared_ptr<RBX::Object>::operator=[abi:ne200100](a1: v34 + 1, a2: (char *)a2 + 32); /*0x10689a39e*/
        v35 = v34 + 3; /*0x10689a3a3*/
        v36 = RBX::details::SplitHashTable<RBX::ContentId,std::pair<RBX::ContentId,std::shared_ptr<RBX::Reflection::ValueTable>>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::ContentId>,RBX::details::DefaultEqualTo<RBX::ContentId>,RBX::details::GetMapKey<RBX::ContentId,std::shared_ptr<RBX::Reflection::ValueTable>>>::find_as<RBX::ContentId>( /*0x10689a3ae*/
                a1: v35,
                a2: &v47);
        if ( v36 != 0 || v37 != 0 ) /*0x10689a3bb*/
        {
          v38 = (_QWORD *)(*(_QWORD *)(v36 + 16) + 48LL * v37 + 32); /*0x10689a3fe*/
          goto LABEL_37; /*0x10689a3fe*/
        }
        if ( *v35 < DFInt::ReplicatorAnimationTrackLimitPerAnimator ) /*0x10689a3d5*/
        {
          v38 = (_QWORD *)RBX::SmallSplitHashMap<RBX::ContentId,std::shared_ptr<RBX::Reflection::ValueTable>,0u,(RBX::SplitHashPolicy)10,RBX::details::DefaultHash<RBX::ContentId>,RBX::details::DefaultEqualTo<RBX::ContentId>>::operator[]( /*0x10689a3e7*/
                            a1: v35,
                            a2: &v47);
LABEL_37:
          if ( *v38 == 0 ) /*0x10689a406*/
          {
            RBX::make_shared<RBX::Reflection::ValueTable>(a1: (RSL::Arena *)v40); /*0x10689a40f*/
            std::shared_ptr<RBX::Reflection::ValueTable>::operator=[abi:ne200100](a1: v38, a2: v40); /*0x10689a421*/
            std::shared_ptr<RBX::Reflection::ValueTable>::~shared_ptr[abi:ne200100](a1: (__int64)v40); /*0x10689a429*/
          }
          for ( i = (_QWORD *)(v29 + 16); /*0x10689a42e*/
                ;
                std::unordered_map<std::string,RBX::Reflection::Variant>::insert_or_assign[abi:ne200100]<RBX::Reflection::Variant const&>(
                  a1: *v38,
                  a2: i + 2,
                  a3: i + 5) )
          {
            i = (_QWORD *)*i; /*0x10689a432*/
            if ( i == nullptr ) /*0x10689a439*/
              break; /*0x10689a439*/
          }
LABEL_43:
          if ( v30 != nullptr && _InterlockedExchangeAdd64(v30 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689a4ae*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v30 + 16))(a1: v30); /*0x10689a4b6*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v30); /*0x10689a4bc*/
          }
          if ( (v48 & 1) != 0 ) /*0x10689a4c5*/
          {
            v23 = v49; /*0x10689a4cb*/
            goto LABEL_17; /*0x10689a4cf*/
          }
          return; /*0x10689a4c5*/
        }
      }
      RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x10689a47c*/
        a1: v40,
        a2: (__int64)RBX::Telemetry::kGraphParamRelayDropped);
      RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v40); /*0x10689a488*/
      RBX::Telemetry::RobloxTelemetryCounter::~RobloxTelemetryCounter(this: (RBX::Telemetry::RobloxTelemetryCounter *)v40); /*0x10689a494*/
      goto LABEL_43; /*0x10689a494*/
    }
  }
  LOBYTE(v41) = 0; /*0x10689a28e*/
  v44 = 0; /*0x10689a290*/
  RBX::Network::Replicator::requestDisconnect(a1: (__int64)this, a2: 0x104u, a3: &v41); /*0x10689a29b*/
  if ( v44 == 1 && (v42 & 1) != 0 ) /*0x10689a2ad*/
  {
    v23 = v43; /*0x10689a2af*/
LABEL_17:
    operator delete(a1: v23); /*0x10689a2b3*/
  }
}

// Address: 0x10689a5c2 | Name: __ZN3RBX7Network16ServerReplicator20drainGraphParamRelayEv
void __fastcall RBX::Network::ServerReplicator::drainGraphParamRelay(RBX::Network::MegaReplicator **this)
{
  _QWORD *v2; // rax
  unsigned int v3; // ecx
  __int64 v4; // r15
  unsigned __int64 v5; // r12
  _QWORD *v6; // rax
  unsigned int v7; // ecx
  __int64 v8; // r13
  __int64 v9; // rbx
  __int64 v10; // rax
  _QWORD *v11; // r15
  __int64 v12; // rdi
  __int64 v13; // r13
  __int64 v14; // rdi
  __int64 v15; // rax
  _QWORD *v16; // r15
  std::__shared_weak_count *v17; // r13
  char *v18; // [rsp+10h] [rbp-80h]
  _QWORD *v19; // [rsp+18h] [rbp-78h] BYREF
  unsigned int i; // [rsp+20h] [rbp-70h]
  _QWORD *v21; // [rsp+28h] [rbp-68h] BYREF
  unsigned int j; // [rsp+30h] [rbp-60h]
  _QWORD *v23; // [rsp+38h] [rbp-58h] BYREF
  unsigned int v24; // [rsp+40h] [rbp-50h]
  std::__shared_weak_count *v25[2]; // [rsp+50h] [rbp-40h] BYREF

  if ( *((_DWORD *)this + 5778) != 0 ) /*0x10689a5da*/
  {
    v18 = (char *)(this + 2889); /*0x10689a5f1*/
    RBX::details::SplitHashTableIterator<std::pair<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>,RBX::details::SplitHashTable<RBX::Instance const*,std::pair<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Instance const*>,RBX::details::DefaultEqualTo<RBX::Instance const*>,RBX::details::GetMapKey<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>>,true>::SplitHashTableIterator( /*0x10689a5f7*/
      a1: &v23,
      a2: this + 2889,
      a3: 0);
    v2 = v23; /*0x10689a5fc*/
    v3 = v24; /*0x10689a5ff*/
    v19 = v23; /*0x10689a602*/
    for ( i = v24; v19 != nullptr || i != 0; v3 = i ) /*0x10689a611*/
    {
      v4 = v2[2]; /*0x10689a633*/
      v5 = (unsigned __int64)v3 << 6; /*0x10689a63a*/
      if ( *(_QWORD *)(v4 + v5 + 8) != 0 ) /*0x10689a644*/
      {
        RBX::details::SplitHashTableIterator<std::pair<RBX::ContentId,std::shared_ptr<RBX::Reflection::ValueTable>>,RBX::details::SplitHashTable<RBX::ContentId,std::pair<RBX::ContentId,std::shared_ptr<RBX::Reflection::ValueTable>>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::ContentId>,RBX::details::DefaultEqualTo<RBX::ContentId>,RBX::details::GetMapKey<RBX::ContentId,std::shared_ptr<RBX::Reflection::ValueTable>>>,true>::SplitHashTableIterator( /*0x10689a658*/
          a1: &v23,
          a2: v4 + v5 + 24,
          a3: 0);
        v6 = v23; /*0x10689a65d*/
        v7 = v24; /*0x10689a661*/
        v21 = v23; /*0x10689a664*/
        for ( j = v24; v21 != nullptr || j != 0; v7 = j ) /*0x10689a673*/
        {
          v8 = v6[2]; /*0x10689a68b*/
          v9 = 48LL * v7; /*0x10689a695*/
          v10 = *(_QWORD *)(v8 + v9 + 32); /*0x10689a699*/
          if ( v10 != 0 && *(_QWORD *)(v10 + 24) != 0 ) /*0x10689a6ac*/
          {
            std::vector<RBX::Reflection::Variant>::vector[abi:ne200100](a1: &v23, a2: 2); /*0x10689a6bb*/
            v11 = v23; /*0x10689a6c0*/
            v13 = v9 + v8; /*0x10689a6c9*/
            *v11 = RBX::Reflection::Type::getSingleton<RBX::ContentId>(a1: v12); /*0x10689a6cc*/
            RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<RBX::ContentId>(a1: v11 + 1, a2: v13); /*0x10689a6d9*/
            v15 = *(_QWORD *)(v13 + 40); /*0x10689a6de*/
            *(_OWORD *)v25 = *(_OWORD *)(v13 + 32); /*0x10689a6e7*/
            if ( v15 != 0 ) /*0x10689a6ee*/
              _InterlockedIncrement64((volatile signed __int64 *)(v15 + 8)); /*0x10689a6f0*/
            v16 = v23; /*0x10689a6f5*/
            v16[10] = RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::ValueTable const>>(a1: v14); /*0x10689a6fe*/
            RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::shared_ptr<RBX::Reflection::ValueTable const>,(std::shared_ptr<RBX::Reflection::ValueTable const>*)0>( /*0x10689a70d*/
              a1: v16 + 11,
              a2: v25);
            v17 = v25[1]; /*0x10689a712*/
            if ( v25[1] != nullptr /*0x10689a72b*/
              && _InterlockedExchangeAdd64((volatile signed __int64 *)v25[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
            {
              (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x10689a734*/
              std::__shared_weak_count::__release_weak(this: v17); /*0x10689a73a*/
            }
            RBX::Network::MegaReplicator::addToRebroadcastList(this: *(this + 1801)); /*0x10689a757*/
            v25[0] = (std::__shared_weak_count *)&v23; /*0x10689a760*/
            std::vector<RBX::Reflection::Variant>::__destroy_vector::operator()[abi:ne200100](a1: (void ***)v25); /*0x10689a768*/
          }
          RBX::details::SplitHashTableIterator<std::pair<RBX::ContentId,std::shared_ptr<RBX::Reflection::ValueTable>>,RBX::details::SplitHashTable<RBX::ContentId,std::pair<RBX::ContentId,std::shared_ptr<RBX::Reflection::ValueTable>>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::ContentId>,RBX::details::DefaultEqualTo<RBX::ContentId>,RBX::details::GetMapKey<RBX::ContentId,std::shared_ptr<RBX::Reflection::ValueTable>>>,true>::operator++(a1: &v21); /*0x10689a771*/
          v6 = v21; /*0x10689a776*/
        }
      }
      RBX::details::SplitHashTableIterator<std::pair<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>,RBX::details::SplitHashTable<RBX::Instance const*,std::pair<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Instance const*>,RBX::details::DefaultEqualTo<RBX::Instance const*>,RBX::details::GetMapKey<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>>,true>::operator++(a1: &v19); /*0x10689a796*/
      v2 = v19; /*0x10689a79b*/
    }
    RBX::details::SplitHashTable<RBX::Instance const*,std::pair<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<RBX::Instance const*>,RBX::details::DefaultEqualTo<RBX::Instance const*>,RBX::details::GetMapKey<RBX::Instance const*,RBX::Network::ServerReplicator::GraphParamRelayEntry>>::clear(a1: v18); /*0x10689a7bb*/
  }
}

// Address: 0x10689a944 | Name: __ZN3RBX7Network16ServerReplicator18joinMarkerReceivedEv
__int64 __fastcall RBX::Network::ServerReplicator::joinMarkerReceived(RBX::Network::ServerReplicator *this)
{
  RBX::Player *v2; // r15
  __int64 v3; // rax
  __int64 v4; // rax
  __int128 v6; // [rsp+0h] [rbp-B0h] BYREF
  void *v7; // [rsp+10h] [rbp-A0h]
  char v8; // [rsp+20h] [rbp-90h] BYREF
  char *v9; // [rsp+40h] [rbp-70h]
  char v10; // [rsp+50h] [rbp-60h] BYREF
  char *v11; // [rsp+70h] [rbp-40h]

  if ( (unsigned __int8)RBX::Players::getShouldAutoSpawnCharacter(this: *((RBX::Players **)this + 1808)) == 0 ) /*0x10689a977*/
    goto LABEL_18; /*0x10689a977*/
  v2 = *((RBX::Player **)this + 2824); /*0x10689a97d*/
  if ( v2 == nullptr ) /*0x10689a987*/
    goto LABEL_18; /*0x10689a987*/
  if ( (*((_BYTE *)this + 22720) & 1) != 0 ) /*0x10689a994*/
  {
    std::string::__init_copy_ctor_external(a1: &v6, a2: *((_QWORD *)this + 2842), a3: *((_QWORD *)this + 2841)); /*0x10689a9c9*/
  }
  else
  {
    v7 = *((void **)this + 2842); /*0x10689a9a1*/
    v6 = *((_OWORD *)this + 1420); /*0x10689a9ab*/
  }
  v11 = nullptr; /*0x10689a9d4*/
  v9 = nullptr; /*0x10689a9de*/
  RBX::Player::loadCharacterWithAvatarFetch(this: v2); /*0x10689a9f6*/
  if ( v9 == &v8 ) /*0x10689aa02*/
  {
    v3 = 32; /*0x10689aa10*/
    goto LABEL_10; /*0x10689aa10*/
  }
  v3 = 40; /*0x10689aa04*/
  if ( v9 != nullptr ) /*0x10689aa0c*/
LABEL_10:
    (*(void (**)(void))(*(_QWORD *)v9 + v3))(); /*0x10689aa15*/
  if ( v11 == &v10 ) /*0x10689aa22*/
  {
    v4 = 32; /*0x10689aa30*/
    goto LABEL_15; /*0x10689aa30*/
  }
  v4 = 40; /*0x10689aa24*/
  if ( v11 != nullptr ) /*0x10689aa2c*/
LABEL_15:
    (*(void (**)(void))(*(_QWORD *)v11 + v4))(); /*0x10689aa35*/
  if ( (v6 & 1) != 0 ) /*0x10689aa42*/
    operator delete(a1: v7); /*0x10689aa4b*/
LABEL_18:
  if ( FFlag::DebugHashTableMetrics != 0 /*0x10689aa72*/
    || (FFlag::SAuthWorkspaceFlagged & 1) != 0
    || FFlag::NextGenReplicatorEnabledRead == 1 )
  {
    RBX::Network::InstanceReplication::RbxInstanceReplicatorManager::onConnectionReady( /*0x10689aa8f*/
      a1: *(_QWORD *)(*((_QWORD *)this + 1801) + 920LL),
      a2: *(unsigned int *)(*((_QWORD *)this + 35) + 1408LL));
  }
  *((_BYTE *)this + 18703) = 1; /*0x10689aa94*/
  return __stack_chk_guard; /*0x10689aaab*/
}

// Address: 0x10689ab04 | Name: __ZN3RBX7Network16ServerReplicator26processMicroProfileRequestEiib
__int64 __fastcall RBX::Network::ServerReplicator::processMicroProfileRequest(
        RBX::Network::ServerReplicator *this,
        RBX::Instance *a2,
        int a3,
        unsigned __int8 a4)
{
  int v7; // r13d
  __int64 v8; // rax
  bool v9; // si
  __int64 v10; // r14
  int v11; // eax
  __int64 v12; // rax
  __int64 v13; // rdi
  __int64 UserID; // rdx
  bool *v15; // rdi
  __int64 v16; // rsi
  __int64 v17; // rcx
  void *v18; // r14
  char isStringIncludedWithSeparator; // r14
  __int64 v20; // rax
  __int64 v21; // r14
  __int64 v22; // rax
  __int64 v23; // rax
  __int128 v25; // [rsp+10h] [rbp-D0h]
  char v26[8]; // [rsp+28h] [rbp-B8h] BYREF
  std::__shared_weak_count *v27; // [rsp+30h] [rbp-B0h]
  char v28[8]; // [rsp+38h] [rbp-A8h] BYREF
  std::__shared_weak_count *v29; // [rsp+40h] [rbp-A0h]
  _BYTE v30[16]; // [rsp+48h] [rbp-98h] BYREF
  __int64 v31; // [rsp+58h] [rbp-88h]
  __int64 v32; // [rsp+60h] [rbp-80h]
  std::__shared_weak_count *v33; // [rsp+68h] [rbp-78h]
  bool v34[16]; // [rsp+70h] [rbp-70h] BYREF
  void *v35; // [rsp+80h] [rbp-60h]
  bool *v36; // [rsp+90h] [rbp-50h]

  if ( DFFlag::DebugEnableRemoteProfiling2 != 1 ) /*0x10689ab2d*/
    return __stack_chk_guard; /*0x10689ab2d*/
  if ( *((_DWORD *)this + 5790) == 1 ) /*0x10689ab3d*/
    return __stack_chk_guard; /*0x10689ab3d*/
  if ( *((_QWORD *)this + 2824) == 0 ) /*0x10689ab4b*/
    return __stack_chk_guard; /*0x10689ab4b*/
  if ( *((_BYTE *)this + 18384) != 0 ) /*0x10689ab58*/
    return __stack_chk_guard; /*0x10689ab58*/
  v7 = (int)a2; /*0x10689ab64*/
  v8 = RBX::DataModel::get(this, a2); /*0x10689ab6a*/
  if ( v8 == 0 ) /*0x10689ab72*/
    return __stack_chk_guard; /*0x10689ab72*/
  v10 = v8; /*0x10689ab78*/
  v11 = *((_DWORD *)this + 5790); /*0x10689ab7b*/
  v31 = v10; /*0x10689ab83*/
  if ( v11 != 0 ) /*0x10689ab8a*/
    goto LABEL_35; /*0x10689ab8a*/
  if ( (DFString::DebugServerProfilerIdList & 1) != 0 ) /*0x10689ab9d*/
    v12 = qword_10D7E2050; /*0x10689ab9f*/
  else
    v12 = (unsigned __int8)DFString::DebugServerProfilerIdList >> 1; /*0x10689aba5*/
  if ( v12 != 0 ) /*0x10689abaa*/
  {
    v13 = *((_QWORD *)this + 2824); /*0x10689abb7*/
    if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x10689abc1*/
      UserID = *(_QWORD *)(v13 + 208); /*0x10689abc3*/
    else
      UserID = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v13 + 176)); /*0x10689abd8*/
    RBX::format(this: (RBX *)v34, a2: "%lld", UserID); /*0x10689abe8*/
    if ( v34[0] ) /*0x10689abf1*/
    {
      v15 = (bool *)v35; /*0x10689abf7*/
      v16 = *(_QWORD *)&v34[8]; /*0x10689abfb*/
    }
    else
    {
      v16 = (unsigned __int8)v34[0] >> 1; /*0x10689ac01*/
      v15 = &v34[1]; /*0x10689ac03*/
    }
    if ( (DFString::DebugServerProfilerIdList & 1) != 0 ) /*0x10689ac0e*/
    {
      v17 = qword_10D7E2050; /*0x10689ac10*/
      v18 = (void *)qword_10D7E2058; /*0x10689ac14*/
    }
    else
    {
      v17 = (unsigned __int8)DFString::DebugServerProfilerIdList >> 1; /*0x10689ac1a*/
      v18 = &unk_10D7E2049; /*0x10689ac1c*/
    }
    isStringIncludedWithSeparator = RBX::StringUtil::isStringIncludedWithSeparator( /*0x10689ac34*/
                                      a1: v15,
                                      a2: v16,
                                      a3: v18,
                                      a4: v17,
                                      a5: ",",
                                      a6: 1);
    if ( v34[0] ) /*0x10689ac37*/
      operator delete(a1: v35); /*0x10689ac41*/
    if ( isStringIncludedWithSeparator != 0 ) /*0x10689ac49*/
    {
      *((_DWORD *)this + 5790) = 2; /*0x10689ac4b*/
LABEL_36:
      *((_BYTE *)this + 18384) = 1; /*0x10689ad6f*/
      RBX::Profiler::notifyActiveCapture(this: (RBX::Profiler *)a4, a2: v9); /*0x10689ad7a*/
      if ( FFlag::MicroProfilerPlatformInfoJson == 1 ) /*0x10689ad89*/
        RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::MicroProfilerService>(this: (RBX::ServiceProvider *)(v31 + 464)); /*0x10689ad99*/
      RBX::weak_from<RBX::DataModel>(a1: v26, a2: v31); /*0x10689adac*/
      RBX::weak_from<RBX::Network::ServerReplicator>(a1: v28, a2: this); /*0x10689adbb*/
      boost::bind<void,std::weak_ptr<RBX::DataModel>,std::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int,std::weak_ptr<RBX::DataModel>,std::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int>( /*0x10689ade6*/
        a1: (__int64)v34,
        a2: (__int64)RBX::Network::profilerDump,
        a3: (__int64)v26,
        a4: (__int64)v28);
      boost::thread::thread<boost::_bi::bind_t<void,void (*)(std::weak_ptr<RBX::DataModel>,std::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<std::weak_ptr<RBX::DataModel>>,boost::_bi::value<std::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>>( /*0x10689adf6*/
        this: (boost::thread *)v30,
        a2: (__int128 *)v34);
      boost::_bi::bind_t<void,void (*)(std::weak_ptr<RBX::DataModel>,std::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<std::weak_ptr<RBX::DataModel>>,boost::_bi::value<std::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>::~bind_t(a1: (__int64)v34); /*0x10689adff*/
      if ( v29 != nullptr ) /*0x10689ae0e*/
        std::__shared_weak_count::__release_weak(this: v29); /*0x10689ae10*/
      if ( v27 != nullptr ) /*0x10689ae1f*/
        std::__shared_weak_count::__release_weak(this: v27); /*0x10689ae21*/
      if ( (unsigned __int8)boost::thread::joinable(this: (boost::thread *)v30) != 0 ) /*0x10689ae34*/
        boost::thread::detach(this: (boost::thread *)v30); /*0x10689ae3d*/
      boost::thread::~thread(this: (boost::thread *)v30); /*0x10689ae49*/
      return __stack_chk_guard; /*0x10689ae5e*/
    }
  }
  RBX::shared_from<RBX::Network::ServerReplicator>(a1: v34); /*0x10689ac61*/
  v25 = *(_OWORD *)v34; /*0x10689ac6a*/
  v20 = *(_QWORD *)&v34[8]; /*0x10689ac71*/
  v33 = *(std::__shared_weak_count **)&v34[8]; /*0x10689ac78*/
  if ( *(_QWORD *)&v34[8] != 0 ) /*0x10689ac7c*/
  {
    _InterlockedIncrement64((volatile signed __int64 *)(*(_QWORD *)&v34[8] + 16LL)); /*0x10689ac7e*/
    v21 = v20; /*0x10689ac83*/
    std::shared_ptr<RBX::Network::ServerReplicator>::~shared_ptr[abi:ne200100](a1: v34); /*0x10689ac8a*/
    v32 = *((_QWORD *)this + 2824); /*0x10689ac96*/
    _InterlockedIncrement64((volatile signed __int64 *)(v21 + 16)); /*0x10689ac9a*/
  }
  else
  {
    std::shared_ptr<RBX::Network::ServerReplicator>::~shared_ptr[abi:ne200100](a1: v34); /*0x10689aca5*/
    v32 = *((_QWORD *)this + 2824); /*0x10689acb1*/
  }
  v36 = nullptr; /*0x10689acb5*/
  v22 = operator new(a1: 0x28u); /*0x10689acc2*/
  *(_QWORD *)v22 = &off_10CAAFDD8; /*0x10689acce*/
  *(_OWORD *)(v22 + 8) = v25; /*0x10689acd8*/
  *(_DWORD *)(v22 + 24) = v7; /*0x10689acdc*/
  *(_DWORD *)(v22 + 28) = a3; /*0x10689ace0*/
  *(_BYTE *)(v22 + 32) = a4; /*0x10689ace4*/
  *(_DWORD *)(v22 + 33) = 0; /*0x10689acea*/
  *(_DWORD *)(v22 + 36) = 0; /*0x10689aced*/
  v36 = (bool *)v22; /*0x10689acf4*/
  RBX::Player::callBackWithCachedCanManageStatusAsync(a1: v32, a2: v34); /*0x10689acff*/
  if ( v36 == v34 ) /*0x10689ad0b*/
  {
    v23 = 32; /*0x10689ad19*/
  }
  else
  {
    v23 = 40; /*0x10689ad0d*/
    if ( v36 == nullptr ) /*0x10689ad15*/
      goto LABEL_32; /*0x10689ad15*/
  }
  (*(void (**)(void))(*(_QWORD *)v36 + v23))(); /*0x10689ad21*/
LABEL_32:
  if ( v33 != nullptr ) /*0x10689ad2b*/
    std::__shared_weak_count::__release_weak(this: v33); /*0x10689ad2d*/
  v11 = *((_DWORD *)this + 5790); /*0x10689ad32*/
LABEL_35:
  if ( v11 != 2 ) /*0x10689ad3b*/
    return __stack_chk_guard; /*0x10689ad3b*/
  goto LABEL_36; /*0x10689ad3b*/
}

// Address: 0x10689b5c8 | Name: __ZN3RBX7Network16ServerReplicator26postProcessReceivedPacketsEv
void __fastcall RBX::Network::ServerReplicator::postProcessReceivedPackets(
        RBX::Network::ServerReplicator *this,
        unsigned int a2)
{
  int v3; // r14d
  double v4; // xmm0_8
  unsigned int v5; // r14d
  __int64 v6; // rsi
  unsigned int v7; // esi

  if ( DFFlag::RbxTransportPopulateReplicatorBandwidthStats == 1 && *((_BYTE *)this + 10391) == 1 ) /*0x10689b5e5*/
  {
    RBX::Network::Replicator::updateRbxTransportBandwidthRate(this, a2: 0); /*0x10689b5ec*/
    RBX::Network::Replicator::updateRbxTransportBandwidthRate(this, a2: 1); /*0x10689b5f9*/
  }
  if ( *((_DWORD *)this + 5778) != 0 ) /*0x10689b605*/
  {
    v3 = DFInt::ReplicatorGraphParamRelayIntervalMs; /*0x10689b60e*/
    RBX::Time::nowFast(this); /*0x10689b611*/
    if ( v3 <= 0 || (v4 - *((double *)this + 2894)) * 1000.0 >= (double)v3 ) /*0x10689b638*/
    {
      *((double *)this + 2894) = v4; /*0x10689b63a*/
      RBX::Network::ServerReplicator::drainGraphParamRelay((RBX::Network::MegaReplicator **)this); /*0x10689b645*/
    }
  }
  if ( *((_BYTE *)this + 14888) == 0 ) /*0x10689b651*/
  {
    v5 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkReplicator, a2); /*0x10689b65e*/
    RBX::Network::Replicator::queueCoalescedAnimationEvents(this, a2: v6); /*0x10689b664*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v5, a2: v7); /*0x10689b66c*/
  }
}

// Address: 0x10689b694 | Name: __ZN3RBX7Network16ServerReplicator25forceDisconnectFromRejoinEv
__int64 __fastcall RBX::Network::ServerReplicator::forceDisconnectFromRejoin(RBX::Network::ServerReplicator *this)
{
  return RBX::Network::ServerReplicator::immediateDisconnectFromRejoinInJoinJob(this); /*0x10689b698*/
}

// Address: 0x10689b69e | Name: __ZN3RBX7Network16ServerReplicator38immediateDisconnectFromRejoinInJoinJobEv
__int64 __fastcall RBX::Network::ServerReplicator::immediateDisconnectFromRejoinInJoinJob(
        RBX::Network::MegaReplicator **this)
{
  __int64 result; // rax
  __int64 v3; // rdx

  result = (*((__int64 (__fastcall **)(RBX::Network::MegaReplicator **, __int64))*this + 187))(a1: this, a2: 276); /*0x10689b6af*/
  if ( *((_BYTE *)this + 14416) == 0 ) /*0x10689b6bc*/
  {
    if ( *((_BYTE *)this + 14417) == 1 ) /*0x10689b6cc*/
    {
      RBX::Network::MegaReplicator::removeDisconnectingReplicatorFromCleanUpQueueForImmediateDisconnect( /*0x10689b6d8*/
        this: *(this + 1801),
        a2: (const RBX::Network::Replicator *)this);
    }
    else
    {
      *((_DWORD *)this + 3605) = 276; /*0x10689b6df*/
      *((_BYTE *)this + 14417) = 1; /*0x10689b6e9*/
    }
    return RBX::Network::Replicator::performDisconnect((RBX::Network::Replicator *)this, a2: 0x114u, a3: v3); /*0x10689b6fe*/
  }
  return result; /*0x10689b6c2*/
}

// Address: 0x10689b704 | Name: __ZN3RBX7Network16ServerReplicator38checkForDuplicatePlayerAndKickOrRejectEv
__int64 __fastcall RBX::Network::ServerReplicator::checkForDuplicatePlayerAndKickOrReject(
        RBX::Network::ServerReplicator *this)
{
  unsigned int v1; // r14d
  __int64 v3; // rdi
  __int64 v4; // rax
  __int64 v5; // rcx
  _QWORD *v6; // rax
  volatile signed __int64 *v7; // r12
  __int64 v8; // r15
  char v9; // r12
  __int64 v10; // rax
  char v11; // cl
  __int64 UserID; // r13
  __int64 v13; // rdi
  __int64 v14; // rax
  int v15; // xmm0_4
  __int64 v16; // rax
  char *v17; // rdi
  std::__shared_weak_count *v18; // r13
  _QWORD *v20; // [rsp+0h] [rbp-50h]
  std::__shared_weak_count *v21; // [rsp+8h] [rbp-48h]
  RBX::Network::ServerReplicator *v22; // [rsp+18h] [rbp-38h] BYREF
  std::__shared_weak_count *v23; // [rsp+20h] [rbp-30h]

  v3 = *((_QWORD *)this + 2838); /*0x10689b718*/
  if ( v3 != 0
    && (FFlag::MigrateUserIdAccessors != 1
      ? (v4 = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v3 + 176)))
      : (v4 = *(_QWORD *)(v3 + 208)),
        v4 != 0) )
  {
    v5 = *((_QWORD *)this + 2828); /*0x10689b752*/
    v6 = *(_QWORD **)(v5 + 120); /*0x10689b759*/
    v20 = v6; /*0x10689b75d*/
    v7 = *(volatile signed __int64 **)(v5 + 128); /*0x10689b761*/
    v21 = (std::__shared_weak_count *)v7; /*0x10689b768*/
    if ( v7 != nullptr ) /*0x10689b76f*/
      _InterlockedIncrement64(v7 + 1); /*0x10689b771*/
    if ( v6 == nullptr || (v8 = *v6, *v6 == v6[1]) )
    {
      v1 = 0; /*0x10689b8eb*/
    }
    else
    {
      while ( 1 )
      {
        RBX::Reflection::DescribedBase::fastSharedDynamicCast<RBX::Network::ServerReplicator,RBX::Instance>( /*0x10689b79f*/
          a1: &v22,
          a2: v8);
        v9 = 1; /*0x10689b7a8*/
        if ( v22 != nullptr )
        {
          v10 = (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)v22 + 696LL))(a1: v22); /*0x10689b7b7*/
          if ( v22 != this && v10 != 0 )
          {
            v11 = FFlag::MigrateUserIdAccessors; /*0x10689b7dc*/
            if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x10689b7e1*/
            {
              UserID = *(_QWORD *)(v10 + 208); /*0x10689b7e3*/
            }
            else
            {
              UserID = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v10 + 176)); /*0x10689b7fa*/
              v11 = FFlag::MigrateUserIdAccessors; /*0x10689b804*/
            }
            v13 = *((_QWORD *)this + 2838); /*0x10689b806*/
            v14 = (v11 & 1) != 0
                ? *(_QWORD *)(v13 + 208)
                : RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v13 + 176));
            if ( UserID == v14 ) /*0x10689b82a*/
            {
              v1 = RBX::LeakyBucket::checkAdd(this: (RBX::Network::ServerReplicator *)((char *)v22 + 23056), a2: 1.0); /*0x10689b845*/
              if ( (_BYTE)v1 != 0 ) /*0x10689b84a*/
              {
                RBX::LeakyBucket::getLevel(this: (RBX::Network::ServerReplicator *)((char *)v22 + 23056)); /*0x10689b858*/
                *((_DWORD *)this + 5766) = v15; /*0x10689b85d*/
                v16 = *((_QWORD *)this + 2888); /*0x10689b865*/
                v17 = (char *)this + 23080; /*0x10689b86c*/
                if ( (v16 & 2) == 0 ) /*0x10689b872*/
                  v17 = *((char **)this + 2885); /*0x10689b878*/
                *((double *)this + 2882) = (*(double (__fastcall **)(char *))(v16 & 0xFFFFFFFFFFFFFFF8LL))(a1: v17); /*0x10689b881*/
                RBX::Network::ServerReplicator::immediateDisconnectFromRejoinInJoinJob(this: (RBX::Network::MegaReplicator **)v22); /*0x10689b88d*/
              }
              LOBYTE(v1) = v1 ^ 1; /*0x10689b892*/
              v9 = 0; /*0x10689b896*/
            }
          }
        }
        v18 = v23; /*0x10689b899*/
        if ( v23 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v23 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689b8b2*/
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(a1: v18); /*0x10689b8bb*/
          std::__shared_weak_count::__release_weak(this: v18); /*0x10689b8c1*/
        }
        if ( v9 == 0 ) /*0x10689b8c9*/
          break; /*0x10689b8c9*/
        v8 += 16; /*0x10689b8cb*/
        if ( v8 == v20[1] ) /*0x10689b8d7*/
        {
          v1 = 0; /*0x10689b8dd*/
          break; /*0x10689b8dd*/
        }
      }
      v7 = (volatile signed __int64 *)v21; /*0x10689b8e0*/
    }
    if ( v7 != nullptr && _InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689b904*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(a1: v7); /*0x10689b90d*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v7); /*0x10689b913*/
    }
  }
  else
  {
    v1 = 0; /*0x10689b8e6*/
  }
  LOBYTE(v1) = v1 & 1; /*0x10689b918*/
  return v1; /*0x10689b91f*/
}

// Address: 0x10689b9c0 | Name: __ZN3RBX7Network16ServerReplicator19prepareRemotePlayerERKNSt3__110shared_ptrINS_8InstanceEEE
__int64 __fastcall RBX::Network::ServerReplicator::prepareRemotePlayer(__int64 a1, __int64 a2)
{
  __int64 v3; // r15
  __int64 UserID; // r12
  unsigned int v5; // ebx
  std::__shared_weak_count *v6; // r15
  RBX::Instance *v7; // rdi
  __int64 v8; // rax
  __int64 v9; // rdi
  volatile signed __int64 *v10; // rax
  std::__shared_weak_count *v11; // r14
  __int64 v12; // rax
  __int64 v13; // r14
  std::__shared_weak_count *v14; // r14
  __int64 v15; // r14
  __int64 v16; // rsi
  __int64 v17; // rsi
  RBX::Time *v18; // rdi
  double v19; // xmm0_8
  unsigned int v20; // eax
  std::__shared_weak_count *v21; // r14
  std::runtime_error *exception; // r14
  std::runtime_error *v24; // r14
  std::__shared_weak_count *v25; // [rsp+8h] [rbp-78h]
  __int64 v26; // [rsp+10h] [rbp-70h] BYREF
  std::__shared_weak_count *v27; // [rsp+18h] [rbp-68h]
  std::__shared_weak_count *v28[2]; // [rsp+20h] [rbp-60h] BYREF
  __int64 v29; // [rsp+30h] [rbp-50h] BYREF
  std::__shared_weak_count *v30; // [rsp+38h] [rbp-48h]
  std::__shared_weak_count *v31[2]; // [rsp+40h] [rbp-40h] BYREF

  RBX::Reflection::DescribedBase::fastSharedDynamicCast<RBX::Player,RBX::Instance>(a1: &v29, a2); /*0x10689b9db*/
  if ( v29 != 0 ) /*0x10689b9e4*/
  {
    if ( *(_QWORD *)(a1 + 22592) != 0 ) /*0x10689b9ee*/
    {
      exception = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10689bd00*/
      std::runtime_error::runtime_error(this: exception, a2: "remotePlayer already exists"); /*0x10689bd0d*/
      __cxa_throw( /*0x10689bd23*/
        a1: exception,
        lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
        a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
    }
    std::shared_ptr<RBX::Player>::operator=[abi:ne200100](a1: a1 + 22592, a2: &v29); /*0x10689ba05*/
    v3 = *(_QWORD *)(a1 + 22624); /*0x10689ba0a*/
    if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x10689ba21*/
      UserID = *(_QWORD *)(v29 + 208); /*0x10689ba23*/
    else
      UserID = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v29 + 176)); /*0x10689ba3f*/
    RBX::shared_from<RBX::Network::ServerReplicator>(a1: v28); /*0x10689ba49*/
    *(_OWORD *)v31 = *(_OWORD *)v28; /*0x10689ba57*/
    if ( v28[1] != nullptr ) /*0x10689ba5f*/
      _InterlockedIncrement64((volatile signed __int64 *)v28[1] + 2); /*0x10689ba61*/
    RBX::Network::Server::registerServerReplicatorForPlayerId(a1: v3, a2: UserID, a3: (__int128 *)v31); /*0x10689ba70*/
    if ( v31[1] != nullptr ) /*0x10689ba7c*/
      std::__shared_weak_count::__release_weak(this: v31[1]); /*0x10689ba7e*/
    v6 = v28[1]; /*0x10689ba83*/
    if ( v28[1] != nullptr /*0x10689ba9c*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v28[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x10689baa4*/
      std::__shared_weak_count::__release_weak(this: v6); /*0x10689baaa*/
    }
    RBX::Player::setPeerId(a1: *(_QWORD *)(a1 + 22592), a2: *(unsigned int *)(a1 + 21784)); /*0x10689babc*/
    v7 = *(RBX::Instance **)(a1 + 22608); /*0x10689bac1*/
    if ( v7 != nullptr ) /*0x10689bacb*/
      RBX::Instance::setParent(this: v7, a2: *(RBX::Instance **)(a1 + 22592)); /*0x10689bad0*/
    v8 = *(_QWORD *)(a1 + 14520); /*0x10689bad5*/
    if ( v8 != 0 ) /*0x10689badf*/
    {
      v9 = v29; /*0x10689bae5*/
      v26 = v8 + 424; /*0x10689baef*/
      v10 = *(volatile signed __int64 **)(a1 + 14528); /*0x10689baf3*/
      v27 = (std::__shared_weak_count *)v10; /*0x10689bafa*/
      if ( v10 != nullptr ) /*0x10689bb01*/
        _InterlockedIncrement64(v10 + 1); /*0x10689bb03*/
      RBX::Player::setStreamingInterface(a1: v9, a2: &v26); /*0x10689bb0c*/
      v11 = v27; /*0x10689bb11*/
      if ( v27 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v27 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689bb2a*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(a1: v11); /*0x10689bb32*/
        std::__shared_weak_count::__release_weak(this: v11); /*0x10689bb38*/
      }
      v12 = RBX::ServiceProvider::find<RBX::Workspace>(a1); /*0x10689bb40*/
      if ( v12 == 0 ) /*0x10689bb48*/
      {
        v24 = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10689bd34*/
        std::runtime_error::runtime_error(this: v24, a2: "ServerReplicator unable to find workspace."); /*0x10689bd41*/
        __cxa_throw( /*0x10689bd57*/
          a1: v24,
          lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
          a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
      }
      if ( (*(_DWORD *)(v12 + 1264) & 0xFFFFFFFE) == 2 ) /*0x10689bb5a*/
        RBX::PlayerProp::setGameplayPaused(this: (RBX::PlayerProp *)(v29 + 176), a2: true); /*0x10689bb6a*/
    }
    v13 = v29; /*0x10689bb6f*/
    RBX::shared_from<RBX::Network::ServerReplicator>(a1: v31); /*0x10689bb7a*/
    v25 = v31[1]; /*0x10689bb9c*/
    *(_OWORD *)v31 = 0; /*0x10689bba4*/
    RBX::Player::setNetworkInterface(a1: v13); /*0x10689bbac*/
    if ( v25 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v25 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689bbca*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v25 + 16LL))(a1: v25); /*0x10689bbd2*/
      std::__shared_weak_count::__release_weak(this: v25); /*0x10689bbd8*/
    }
    v14 = v31[1]; /*0x10689bbdd*/
    if ( v31[1] != nullptr /*0x10689bbf6*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v31[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x10689bbfe*/
      std::__shared_weak_count::__release_weak(this: v14); /*0x10689bc04*/
    }
    if ( DFFlag::ConnectionClosedUserIdDiagnostics == 1 ) /*0x10689bc13*/
    {
      v15 = *(_QWORD *)(a1 + 280); /*0x10689bc15*/
      if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x10689bc25*/
        v16 = *(_QWORD *)(v29 + 208); /*0x10689bc27*/
      else
        v16 = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v29 + 176)); /*0x10689bc3c*/
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v15 + 72LL))(a1: v15, a2: v16); /*0x10689bc45*/
    }
    if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x10689bc51*/
      v17 = *(_QWORD *)(v29 + 208); /*0x10689bc53*/
    else
      v17 = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v29 + 176)); /*0x10689bc68*/
    RBX::Analytics::InfluxDb::Points::setUserIdOverride(this: (RBX::Analytics::InfluxDb::Points *)(a1 + 22112), a2: v17); /*0x10689bc75*/
    RBX::Time::nowFast(this: v18); /*0x10689bc7a*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x10689bc91*/
      this: (RBX::Analytics::InfluxDb::Points *)(a1 + 22112),
      a2: "ReceivedPlayer",
      a3: v19 - *(double *)(a1 + 22096));
    if ( *(_BYTE *)(a1 + 22641) == 0 ) /*0x10689bc9d*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)a1 + 1704LL))(a1); /*0x10689bca5*/
    LOBYTE(v20) = RBX::Network::Server::getIsPlayerAuthenticationRequired(this: *(RBX::Network::Server **)(a1 + 22624)); /*0x10689bcb2*/
    v5 = v20; /*0x10689bcb7*/
  }
  else
  {
    v5 = 0; /*0x10689ba2c*/
  }
  v21 = v30; /*0x10689bcb9*/
  if ( v30 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v30 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689bcd2*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(a1: v21); /*0x10689bcda*/
    std::__shared_weak_count::__release_weak(this: v21); /*0x10689bce0*/
  }
  return v5; /*0x10689bce7*/
}

// Address: 0x10689bdce | Name: __ZN3RBX7Network16ServerReplicator21isLegalDeleteInstanceEPNS_8InstanceE
__int64 __fastcall RBX::Network::ServerReplicator::isLegalDeleteInstance(
        RBX::Network::ServerReplicator *this,
        RBX::Instance *a2)
{
  __int64 v2; // rax
  unsigned int v3; // r14d
  RBX::Network::StrictNetworkFilter *v6; // rdi
  __int64 v8; // rdi
  _DWORD v9[7]; // [rsp+0h] [rbp-1Ch] BYREF

  v9[0] = HIDWORD(v2); /*0x10689bdd7*/
  LOBYTE(v3) = 1; /*0x10689bde7*/
  if ( (*(unsigned __int8 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 1032LL))(a1: this) == 0 ) /*0x10689bdec*/
  {
    if ( *((_QWORD *)this + 2824) != 0 /*0x10689be0a*/
      || (*(unsigned int (__fastcall **)(RBX::Network::ServerReplicator *, RBX::Instance *))(*(_QWORD *)this + 1672LL))(
           a1: this,
           a2) != 1 )
    {
      v6 = *((RBX::Network::StrictNetworkFilter **)this + 1567); /*0x10689be11*/
      if ( v6 != nullptr ) /*0x10689be1b*/
      {
        LOBYTE(v3) = (unsigned int)RBX::Network::StrictNetworkFilter::filterDelete(this: v6, a2) != 1; /*0x10689be28*/
      }
      else
      {
        v8 = *((_QWORD *)this + 2752); /*0x10689be3a*/
        LOBYTE(v3) = 1; /*0x10689be41*/
        if ( v8 != 0 && (unsigned __int8)RBX::Network::NetworkFilter::filterDelete(a1: v8, a2, a3: v9) != 0 ) /*0x10689be57*/
          LOBYTE(v3) = v9[0] == 0; /*0x10689be5d*/
      }
    }
    else
    {
      return 0; /*0x10689be0c*/
    }
  }
  return v3; /*0x10689be33*/
}

// Address: 0x10689be6c | Name: __ZN3RBX7Network16ServerReplicator21isLegalReceiveTerrainEPNS_8InstanceE
bool __fastcall RBX::Network::ServerReplicator::isLegalReceiveTerrain(
        RBX::Network::ServerReplicator *this,
        RBX::Instance *a2)
{
  RBX::Network::StrictNetworkFilter *v4; // rdi

  return ((*(unsigned __int8 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 1032LL))(a1: this) != 0 /*0x10689bebf*/
       || (v4 = *((RBX::Network::StrictNetworkFilter **)this + 1567)) == nullptr
       || (unsigned int)RBX::Network::StrictNetworkFilter::filterTerrainCellChange(this: v4) == 0)
      && (*((_QWORD *)this + 2824) != 0
       || (*(unsigned int (__fastcall **)(RBX::Network::ServerReplicator *, RBX::Instance *))(*(_QWORD *)this + 1656LL))(
            a1: this,
            a2) != 1);
}

// Address: 0x10689bec4 | Name: __ZN3RBX7Network16ServerReplicator20isLegalReceiveObjectEPNS_6ObjectEPNS_8InstanceERKNSt3__16vectorINS0_13PropValuePairENS6_9allocatorIS8_EEEE
__int64 __fastcall RBX::Network::ServerReplicator::isLegalReceiveObject(
        __int64 a1,
        const RBX::Object *a2,
        __int64 a3,
        __int64 a4)
{
  __int64 v4; // r14
  __int64 v7; // rax
  __int64 v8; // rdi
  unsigned int v9; // ecx
  const RBX::Object *v10; // r13
  __int64 v11; // r15
  __int64 v12; // rax
  __int64 v13; // r14
  __int64 v14; // rax
  __int64 v15; // rdi
  __int64 v16; // r15
  __int64 v17; // rax
  unsigned int v18; // ecx
  unsigned int v19; // eax
  std::runtime_error *exception; // rbx
  __int64 v21; // rdi
  __int64 v22; // r15
  __int64 v23; // r12
  __int64 v24; // rax
  const RBX::Object *v25; // rsi
  __int128 v26; // xmm0
  std::__shared_weak_count *v27; // rdi
  std::__shared_weak_count *v28; // rax
  __int64 v30; // rdi
  __int128 v31; // [rsp+0h] [rbp-60h] BYREF
  __int64 v32; // [rsp+18h] [rbp-48h]
  __int64 v33; // [rsp+20h] [rbp-40h]
  __int64 v34; // [rsp+28h] [rbp-38h] BYREF
  _BYTE v35[41]; // [rsp+37h] [rbp-29h] BYREF

  v32 = a4; /*0x10689bed5*/
  v33 = a3; /*0x10689bed9*/
  if ( a2 == nullptr ) /*0x10689bee6*/
  {
    v10 = nullptr; /*0x10689bf42*/
    goto LABEL_7; /*0x10689bf42*/
  }
  v4 = *((_QWORD *)a2 + 3); /*0x10689bee8*/
  v7 = RBX::Instance::classDescriptor(this: (RBX::Instance *)a1); /*0x10689beec*/
  v9 = *(unsigned __int16 *)(v4 + 440) - *(unsigned __int16 *)(v7 + 440); /*0x10689bf00*/
  LODWORD(v4) = 0; /*0x10689bf09*/
  v10 = nullptr; /*0x10689bf0e*/
  if ( v9 <= *(unsigned __int16 *)(v7 + 442) ) /*0x10689bf14*/
    v10 = a2; /*0x10689bf14*/
  v11 = *((_QWORD *)a2 + 3); /*0x10689bf18*/
  v12 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(a1: v8); /*0x10689bf1c*/
  if ( *(unsigned __int16 *)(v11 + 440) - (unsigned int)*(unsigned __int16 *)(v12 + 440) > *(unsigned __int16 *)(v12 + 442) ) /*0x10689bf3b*/
  {
LABEL_7:
    LOBYTE(v4) = 1; /*0x10689bf45*/
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)a1 + 1032LL))(a1) != 0 ) /*0x10689bf57*/
      return (unsigned int)v4; /*0x10689bf57*/
    if ( (unsigned __int8)RBX::Network::Server::isLegalReceiveObject(this: *(RBX::Network::Server **)(a1 + 22624), a2) != 0 ) /*0x10689bf6f*/
    {
      if ( a2 == nullptr ) /*0x10689bf78*/
      {
        if ( *(_QWORD *)(a1 + 22592) == 0 ) /*0x10689c014*/
        {
LABEL_17:
          if ( (*(unsigned int (__fastcall **)(__int64, const RBX::Object *))(*(_QWORD *)a1 + 1680LL))(a1, a2) == 1 ) /*0x10689c02f*/
            goto LABEL_18; /*0x10689c02f*/
        }
LABEL_19:
        v21 = *(_QWORD *)(a1 + 12536); /*0x10689c039*/
        if ( v21 != 0 ) /*0x10689c044*/
        {
          v34 = 0; /*0x10689c04e*/
          v35[0] = 0; /*0x10689c059*/
          LODWORD(v4) = RBX::Network::StrictNetworkFilter::filterNew( /*0x10689c06d*/
                          a1: v21,
                          a2: v10,
                          a3: v33,
                          a4: v32,
                          a5: v35,
                          a6: &v34);
          if ( (_DWORD)v4 == 0 ) /*0x10689c072*/
          {
            v22 = v34; /*0x10689c078*/
            if ( (v35[0] & (v34 != 0)) == 1 ) /*0x10689c087*/
            {
              v23 = *((_QWORD *)a2 + 3); /*0x10689c089*/
              v24 = RBX::Reflection::Class_getDescriptorPtr<RBX::Weld>(); /*0x10689c08d*/
              v25 = nullptr; /*0x10689c0ab*/
              if ( *(unsigned __int16 *)(v23 + 440) - (unsigned int)*(unsigned __int16 *)(v24 + 440) <= *(unsigned __int16 *)(v24 + 442) ) /*0x10689c0af*/
                v25 = a2; /*0x10689c0af*/
              RBX::weak_from<RBX::Weld>(a1: &v31, a2: v25); /*0x10689c0ba*/
              v26 = v31; /*0x10689c0bf*/
              v27 = *((std::__shared_weak_count **)&v31 + 1); /*0x10689c0c2*/
              if ( *((_QWORD *)&v31 + 1) != 0 ) /*0x10689c0c9*/
                _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v31 + 1) + 16LL)); /*0x10689c0cb*/
              v28 = *(std::__shared_weak_count **)(v22 + 1136); /*0x10689c0d0*/
              *(_OWORD *)(v22 + 1128) = v26; /*0x10689c0d7*/
              if ( v28 != nullptr ) /*0x10689c0e2*/
              {
                std::__shared_weak_count::__release_weak(this: v28); /*0x10689c0e7*/
                v27 = *((std::__shared_weak_count **)&v31 + 1); /*0x10689c0ec*/
              }
              if ( v27 != nullptr ) /*0x10689c0f3*/
                std::__shared_weak_count::__release_weak(this: v27); /*0x10689c0f5*/
            }
          }
          LOBYTE(v4) = (_DWORD)v4 != 1; /*0x10689c0fe*/
        }
        else
        {
          v30 = *(_QWORD *)(a1 + 22016); /*0x10689c114*/
          LOBYTE(v4) = 1; /*0x10689c11c*/
          if ( v30 != 0 /*0x10689c136*/
            && (unsigned __int8)RBX::Network::NetworkFilter::filterNew(a1: v30, a2: v10, a3: v33, a4: &v34) != 0 )
          {
            LOBYTE(v4) = (_DWORD)v34 == 0; /*0x10689c13c*/
          }
        }
        return (unsigned int)v4; /*0x10689c0fe*/
      }
      v13 = *((_QWORD *)a2 + 3); /*0x10689bf7e*/
      v14 = RBX::Reflection::Class_getDescriptorPtr<RBX::Message>(); /*0x10689bf82*/
      if ( *(unsigned __int16 *)(v13 + 440) - (unsigned int)*(unsigned __int16 *)(v14 + 440) > *(unsigned __int16 *)(v14 + 442) ) /*0x10689bfa1*/
      {
        v4 = *(_QWORD *)(a1 + 22592); /*0x10689bfa7*/
        v16 = *((_QWORD *)a2 + 3); /*0x10689bfaf*/
        v17 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(a1: v15); /*0x10689bfb3*/
        v18 = *(unsigned __int16 *)(v16 + 440) - *(unsigned __int16 *)(v17 + 440); /*0x10689bfc7*/
        v19 = *(unsigned __int16 *)(v17 + 442); /*0x10689bfc9*/
        if ( v4 != 0 ) /*0x10689bfd3*/
        {
          if ( v18 <= v19 ) /*0x10689bfd7*/
          {
            exception = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10689bfe3*/
            std::runtime_error::runtime_error(this: exception, a2: "remotePlayer already exists"); /*0x10689bff0*/
            __cxa_throw( /*0x10689c006*/
              a1: exception,
              lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
              a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
          }
          goto LABEL_19; /*0x10689bfd7*/
        }
        if ( v18 <= v19 ) /*0x10689c01a*/
          goto LABEL_19; /*0x10689c01a*/
        goto LABEL_17; /*0x10689c01a*/
      }
    }
LABEL_18:
    LODWORD(v4) = 0; /*0x10689c031*/
  }
  return (unsigned int)v4; /*0x10689c105*/
}

// Address: 0x10689c206 | Name: __ZN3RBX7Network16ServerReplicator19isLegalReceiveEventEPNS_6ObjectERKNS_10Reflection15EventDescriptorE
__int64 __fastcall RBX::Network::ServerReplicator::isLegalReceiveEvent(
        RBX::Network::ServerReplicator *this,
        RBX::Object *a2,
        const RBX::Reflection::EventDescriptor *a3)
{
  RBX::Network::ServerReplicator *v5; // r15
  __int64 v6; // r12
  __int64 v7; // rax
  RBX::Network::StrictNetworkFilter *v8; // rdi
  bool v9; // zf
  __int64 v11; // rdi
  _DWORD v12[9]; // [rsp+Ch] [rbp-24h] BYREF

  v5 = this; /*0x10689c21b*/
  if ( a2 != nullptr ) /*0x10689c221*/
  {
    v6 = *((_QWORD *)a2 + 3); /*0x10689c223*/
    v7 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(a1: this); /*0x10689c227*/
    if ( *(unsigned __int16 *)(v6 + 440) - (unsigned int)*(unsigned __int16 *)(v7 + 440) <= *(unsigned __int16 *)(v7 + 442) /*0x10689c250*/
      && *((RBX::Object **)v5 + 2824) != a2 )
    {
      LODWORD(v5) = 0; /*0x10689c252*/
      return (unsigned int)v5; /*0x10689c255*/
    }
  }
  v8 = *((RBX::Network::StrictNetworkFilter **)v5 + 1567); /*0x10689c257*/
  if ( v8 != nullptr ) /*0x10689c261*/
  {
    v9 = (unsigned int)RBX::Network::StrictNetworkFilter::filterEvent(this: v8, a2, a3) == 0; /*0x10689c26e*/
LABEL_7:
    LOBYTE(v5) = v9; /*0x10689c270*/
    return (unsigned int)v5; /*0x10689c270*/
  }
  v11 = *((_QWORD *)v5 + 2752); /*0x10689c284*/
  LOBYTE(v5) = 1; /*0x10689c28b*/
  if ( v11 != 0 && (unsigned __int8)RBX::Network::NetworkFilter::filterEvent(a1: v11, a2, a3, a4: v12) != 0 ) /*0x10689c2a4*/
  {
    v9 = v12[0] == 0; /*0x10689c2a6*/
    goto LABEL_7; /*0x10689c2aa*/
  }
  return (unsigned int)v5; /*0x10689c277*/
}

// Address: 0x10689c2ac | Name: __ZN3RBX7Network16ServerReplicator33isLegalReceiveNewInstancePropertyEPNS_6ObjectERKNS_10Reflection18PropertyDescriptorE
bool __fastcall RBX::Network::ServerReplicator::isLegalReceiveNewInstanceProperty(
        RBX::Network::ServerReplicator *this,
        RBX::Object *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  RBX::Network::StrictNetworkFilter *v3; // rdi

  v3 = *((RBX::Network::StrictNetworkFilter **)this + 1567); /*0x10689c2ac*/
  return v3 != nullptr /*0x10689c2c7*/
      && (unsigned int)RBX::Network::StrictNetworkFilter::filterNewInstanceProperty(this: v3, a2, a3) == 0;
}

// Address: 0x10689c2d4 | Name: __ZN3RBX7Network16ServerReplicator44isLegalReceiveNewInstanceProperty_DEPRECATEDERKNS_10Reflection18PropertyDescriptorE
bool __fastcall RBX::Network::ServerReplicator::isLegalReceiveNewInstanceProperty_DEPRECATED(
        RBX::Network::StrictNetworkFilter **this,
        const RBX::Reflection::PropertyDescriptor *a2)
{
  char v4; // cl
  bool result; // al
  RBX::Network::StrictNetworkFilter *v6; // rdi

  v4 = (*((__int64 (__fastcall **)(RBX::Network::StrictNetworkFilter **))*this + 129))(a1: this); /*0x10689c2ea*/
  result = true; /*0x10689c2ec*/
  if ( v4 == 0 ) /*0x10689c2f0*/
  {
    v6 = *(this + 1567); /*0x10689c2f2*/
    if ( v6 != nullptr ) /*0x10689c2fc*/
      return (unsigned int)RBX::Network::StrictNetworkFilter::filterNewInstanceProperty_DEPRECATED(this: v6, a2) == 0; /*0x10689c308*/
  }
  return result; /*0x10689c30b*/
}

// Address: 0x10689c318 | Name: __ZN3RBX7Network16ServerReplicator22isLegalReceivePropertyEPNS_6ObjectERKNS_10Reflection18PropertyDescriptorE
char __fastcall RBX::Network::ServerReplicator::isLegalReceiveProperty(
        RBX::Network::ServerReplicator *this,
        RBX::Object *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  __int64 v6; // r12
  __int64 v7; // rax
  char v8; // cl
  char result; // al
  int v10; // ecx

  if ( a2 != nullptr /*0x10689c355*/
    && (v6 = *((_QWORD *)a2 + 3),
        v7 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(a1: this),
        *(unsigned __int16 *)(v6 + 440) - (unsigned int)*(unsigned __int16 *)(v7 + 440) <= *(unsigned __int16 *)(v7 + 442)) )
  {
    result = 0; /*0x10689c390*/
    if ( DFFlag::DebugFilterAllPlayerPropChanges == 0 /*0x10689c3d1*/
      && RBX::PlayerProperties::prop_UserId != (_UNKNOWN *)a3
      && RBX::PlayerProperties::prop_userId != (_UNKNOWN *)a3
      && RBX::PlayerProperties::prop_User != (_UNKNOWN *)a3
      && RBX::PlayerProperties::prop_UserIdModeReplicate != (_UNKNOWN *)a3 )
    {
      return RBX::Instance::desc_Name != (_QWORD)a3; /*0x10689c3dd*/
    }
  }
  else
  {
    v8 = (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 1032LL))(a1: this); /*0x10689c363*/
    result = 1; /*0x10689c365*/
    if ( v8 != 0 ) /*0x10689c369*/
      return result; /*0x10689c369*/
    if ( *((_QWORD *)this + 2824) != 0 ) /*0x10689c377*/
    {
      if ( RBX::ScriptProperties::prop_Source == (_UNKNOWN *)a3 ) /*0x10689c383*/
        return 0; /*0x10689c38b*/
    }
    else
    {
      v10 = (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *, RBX::Object *, const RBX::Reflection::PropertyDescriptor *))(*(_QWORD *)this + 1688LL))( /*0x10689c3f4*/
              a1: this,
              a2,
              a3);
      result = 0; /*0x10689c3f6*/
      if ( v10 == 1 || RBX::ScriptProperties::prop_Source == (_UNKNOWN *)a3 ) /*0x10689c407*/
        return result; /*0x10689c407*/
    }
    result = 0; /*0x10689c410*/
    if ( RBX::BaseScriptProperties::prop_LinkedSource != (_UNKNOWN *)a3 /*0x10689c421*/
      && RBX::ModuleScriptProperties::prop_Source != (_UNKNOWN *)a3 )
    {
      return RBX::Network::Replicator::isLegalReceiveProperty(this, a2, a3); /*0x10689c434*/
    }
  }
  return result; /*0x10689c42c*/
}

// Address: 0x10689c442 | Name: __ZN3RBX7Network16ServerReplicator23isLegalReceiveAttributeEv
__int64 __fastcall RBX::Network::ServerReplicator::isLegalReceiveAttribute(RBX::Network::ServerReplicator *this)
{
  RBX::Network::Replicator::getAttributeSynchronizationEnabled(this); /*0x10689c44b*/
  return (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 1032LL))(a1: this);
}

// Address: 0x10689c462 | Name: __ZN3RBX7Network16ServerReplicator12onSentMarkerEl
void __fastcall RBX::Network::ServerReplicator::onSentMarker(RBX::Network::ServerReplicator *this)
{
  *((_BYTE *)this + 22640) = 0; /*0x10689c466*/
}

// Address: 0x10689c470 | Name: __ZN3RBX7Network16ServerReplicator9onSentTagENS0_11TagItemTypeE
__int64 __fastcall RBX::Network::ServerReplicator::onSentTag(RBX::Network::Replicator *this, int a2)
{
  RBX::Time *v3; // rdi
  double v4; // xmm0_8
  RBX::Instance *v5; // rsi
  __int64 *EngineNetConfiguration; // rax
  RBX::Network::PhysicsReceiverS2 *v7; // r14
  RBX::Network::Replicator::StreamJob *v8; // rdi
  __int64 v10; // rax
  RBX::Network::PhysicsReceiverS2 *v11; // r14
  RBX::Network::PhysicsSenderS2 *v12; // r14
  RBX::Network::Replicator::StreamJob *v13; // rdi
  __int64 Dangerous_DEPRECATED; // r14
  __int64 v15; // rax
  char v16; // [rsp+0h] [rbp-80h] BYREF
  std::__shared_weak_count *v17; // [rsp+8h] [rbp-78h]
  std::__shared_weak_count *v18[4]; // [rsp+10h] [rbp-70h] BYREF
  __int64 (__fastcall **v19)(); // [rsp+30h] [rbp-50h] BYREF
  _BYTE v20[24]; // [rsp+38h] [rbp-48h]
  __int64 (__fastcall ***v21)(); // [rsp+50h] [rbp-30h]

  switch ( a2 ) /*0x10689c491*/
  {
    case 15: /*0x10689c491*/
      v8 = *((RBX::Network::Replicator::StreamJob **)this + 1815); /*0x10689c56c*/
      if ( v8 != nullptr ) /*0x10689c576*/
        return RBX::Network::Replicator::StreamJob::onMinRegionsCompletedTag(this: v8); /*0x10689c590*/
      break;
    case 14: /*0x10689c491*/
      *((_BYTE *)this + 14888) = 0; /*0x10689c560*/
      break;
    case 13: /*0x10689c491*/
      RBX::Network::TwoWayBandwidthMetrics::onJoin(a1: (char *)this + 288, a2: 0); /*0x10689c4b5*/
      RBX::Network::TwoWayBandwidthMetrics::onJoin(a1: (char *)this + 288, a2: 1); /*0x10689c4c2*/
      RBX::Time::nowFast(this: v3); /*0x10689c4ce*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x10689c4e5*/
        this: (RBX::Network::Replicator *)((char *)this + 22112),
        a2: "TopRepContSent",
        a3: v4 - *((double *)this + 2762));
      *((_BYTE *)this + 18410) = 1; /*0x10689c4ea*/
      RBX::Network::Replicator::addReplicatorState(this, a2: 8); /*0x10689c4f9*/
      if ( (*(unsigned __int8 (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)this + 1032LL))(a1: this) != 0 ) /*0x10689c50c*/
        goto LABEL_19; /*0x10689c50c*/
      EngineNetConfiguration = (__int64 *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::NetworkSchema *)(*((_QWORD *)this + 1801) + 1608LL)); /*0x10689c51e*/
      if ( FFlag::DebugHashTableMetrics != 0 ) /*0x10689c52d*/
        goto LABEL_6; /*0x10689c52d*/
      if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x10689c59f*/
      {
        v10 = *EngineNetConfiguration; /*0x10689c5a1*/
        if ( (v10 & 8) != 0 || (v10 & 1) != 0 || FFlag::NextGenReplicatorEnabledWrite != 0 ) /*0x10689c5b6*/
        {
LABEL_6:
          v7 = (RBX::Network::PhysicsReceiverS2 *)operator new(a1: 0xE8u); /*0x10689c52f*/
          RBX::Network::PhysicsReceiverS2::PhysicsReceiverS2(this: v7, a2: this, a3: true); /*0x10689c547*/
          std::shared_ptr<RBX::Network::PhysicsReceiverS2>::reset[abi:ne200100]<RBX::Network::PhysicsReceiverS2,0>( /*0x10689c556*/
            a1: (char *)this + 18584,
            a2: v7);
LABEL_18:
          RBX::Network::Replicator::getOrCreatePhysicsTouchSerializer(this); /*0x10689c62c*/
LABEL_19:
          v13 = *((RBX::Network::Replicator::StreamJob **)this + 1815); /*0x10689c634*/
          if ( v13 != nullptr ) /*0x10689c63e*/
            RBX::Network::Replicator::StreamJob::setReady(this: v13, a2: true); /*0x10689c645*/
          if ( *((_QWORD *)this + 2824) == 0 ) /*0x10689c652*/
            goto LABEL_31; /*0x10689c652*/
          Dangerous_DEPRECATED = RBX::DataModel::getDangerous_DEPRECATED(this, a2: v5); /*0x10689c660*/
          RBX::weak_from<RBX::Network::ServerReplicator>(a1: &v16, a2: this); /*0x10689c66a*/
          boost::bind<void,std::weak_ptr<RBX::Network::ServerReplicator>,std::weak_ptr<RBX::Network::ServerReplicator>>( /*0x10689c67e*/
            a1: (__int64)v18,
            a2: (__int64)RBX::Network::ServerReplicator::installRemotePlayerSafe,
            a3: (__int128 *)&v16);
          v19 = &off_10CAAFF78; /*0x10689c68e*/
          qmemcpy(v20, v18, sizeof(v20)); /*0x10689c696*/
          *(_OWORD *)&v18[1] = 0; /*0x10689c6a8*/
          v21 = &v19; /*0x10689c6ad*/
          RBX::DataModel::submitTask(a1: Dangerous_DEPRECATED, a2: &v19, a3: 1); /*0x10689c6bc*/
          if ( v21 == &v19 ) /*0x10689c6c8*/
          {
            v15 = 4; /*0x10689c6d6*/
          }
          else
          {
            v15 = 5; /*0x10689c6ca*/
            if ( v21 == nullptr ) /*0x10689c6d2*/
              goto LABEL_27; /*0x10689c6d2*/
          }
          (*v21)[v15](); /*0x10689c6de*/
LABEL_27:
          if ( v18[2] != nullptr ) /*0x10689c6e8*/
            std::__shared_weak_count::__release_weak(this: v18[2]); /*0x10689c6ea*/
          if ( v17 != nullptr ) /*0x10689c6f6*/
            std::__shared_weak_count::__release_weak(this: v17); /*0x10689c6f8*/
LABEL_31:
          if ( RBX::Network::Replicator::getSharedStringCachingEnabled(this) ) /*0x10689c700*/
            RBX::Network::SharedStringSynchronizer::serverSideCleanup(this: *((RBX::Network::SharedStringSynchronizer **)this /*0x10689c710*/
                                                                            + 1927));
          (*(void (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)this + 1720LL))(a1: this); /*0x10689c71b*/
          *((_BYTE *)this + 15550) = (*(__int64 (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)this + 1048LL))(a1: this) /*0x10689c72f*/
                                   ^ 1;
          return __stack_chk_guard; /*0x10689c72f*/
        }
      }
      else if ( FFlag::NextGenReplicatorEnabledRead != 0 && FFlag::NextGenReplicatorEnabledWrite == 1 ) /*0x10689c5d3*/
      {
        goto LABEL_6; /*0x10689c5d3*/
      }
      v11 = (RBX::Network::PhysicsReceiverS2 *)operator new(a1: 0xE8u); /*0x10689c5e3*/
      RBX::Network::PhysicsReceiverS2::PhysicsReceiverS2(this: v11, a2: this, a3: true); /*0x10689c5f1*/
      std::shared_ptr<RBX::Network::PhysicsReceiverS2>::reset[abi:ne200100]<RBX::Network::PhysicsReceiverS2,0>( /*0x10689c600*/
        a1: (char *)this + 18584,
        a2: v11);
      v12 = (RBX::Network::PhysicsSenderS2 *)operator new(a1: 0x148u); /*0x10689c60f*/
      RBX::Network::PhysicsSenderS2::PhysicsSenderS2(this: v12, a2: this); /*0x10689c618*/
      std::shared_ptr<RBX::Network::PhysicsSenderS2>::reset[abi:ne200100]<RBX::Network::PhysicsSenderS2,0>( /*0x10689c627*/
        a1: (char *)this + 18552,
        a2: v12);
      goto LABEL_18; /*0x10689c627*/
    default:
      break; /*0x10689c586*/
  }
  return __stack_chk_guard; /*0x10689c586*/
}

// Address: 0x10689c822 | Name: __ZN3RBX7Network16ServerReplicator23installRemotePlayerSafeENSt3__18weak_ptrIS1_EE
void __fastcall RBX::Network::ServerReplicator::installRemotePlayerSafe(__int64 *a1)
{
  std::__shared_weak_count *v2; // rdi
  volatile signed __int64 *v3; // rax
  volatile signed __int64 *v4; // rbx
  __int64 v5; // r14

  v2 = (std::__shared_weak_count *)a1[1]; /*0x10689c835*/
  if ( v2 != nullptr ) /*0x10689c83c*/
  {
    v3 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v2); /*0x10689c83e*/
    if ( v3 != nullptr ) /*0x10689c84a*/
    {
      v4 = v3; /*0x10689c84c*/
      v5 = *a1; /*0x10689c84f*/
      if ( v5 != 0 ) /*0x10689c859*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 1704LL))(a1: v5); /*0x10689c861*/
      if ( _InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689c877*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(a1: v4); /*0x10689c87f*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v4); /*0x10689c885*/
      }
    }
  }
}

// Address: 0x10689c9a0 | Name: __ZN3RBX7Network16ServerReplicator12canSendItemsEv
char __fastcall RBX::Network::ServerReplicator::canSendItems(RBX::Network::ServerReplicator *this)
{
  return *((_BYTE *)this + 22643); /*0x10689c9aa*/
}

// Address: 0x10689c9ac | Name: __ZN3RBX7Network16ServerReplicator19isLegalSendPropertyEPNS_6ObjectERKNS_10Reflection18PropertyDescriptorE
char __fastcall RBX::Network::ServerReplicator::isLegalSendProperty(
        RBX::Network::ServerReplicator *this,
        RBX::Object *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  return 1; /*0x10689c9b2*/
}

// Address: 0x10689c9b4 | Name: __ZN3RBX7Network16ServerReplicator20isLegalSendAttributeEv
char __fastcall RBX::Network::ServerReplicator::isLegalSendAttribute(RBX::Network::ServerReplicator *this)
{
  return 1; /*0x10689c9ba*/
}

// Address: 0x10689c9bc | Name: __ZNK3RBX7Network16ServerReplicator11isCloudEditEv
bool __fastcall RBX::Network::ServerReplicator::isCloudEdit(RBX::Network::Server **this)
{
  return RBX::Network::Server::isCloudEdit(this: *(this + 2828)); /*0x10689c9c7*/
}

// Address: 0x10689c9ce | Name: __ZNK3RBX7Network16ServerReplicator11isCloudTestEv
char __fastcall RBX::Network::ServerReplicator::isCloudTest(RBX::Network::Server **this)
{
  return RBX::Network::Server::isCloudTest(this: *(this + 2828)); /*0x10689c9d9*/
}

// Address: 0x10689c9e0 | Name: __ZNK3RBX7Network16ServerReplicator20acceptsStudioClientsEv
bool __fastcall RBX::Network::ServerReplicator::acceptsStudioClients(RBX::Network::ServerReplicator *this)
{
  return (unsigned int)(*(_DWORD *)(*((_QWORD *)this + 2828) + 536LL) - 1) < 2; /*0x10689c9f9*/
}

// Address: 0x10689c9fc | Name: __ZN3RBX7Network16ServerReplicator47schemaAddTopReplicationContainerDataToBitstreamERNS0_13NetworkStreamEb
__int64 __fastcall RBX::Network::ServerReplicator::schemaAddTopReplicationContainerDataToBitstream(
        RBX::Network::ServerReplicator *this,
        RBX::Network::NetworkStream *a2,
        int a3)
{
  const RBX::Network::NetworkSchema *v5; // rbx
  char v6; // r12
  char v7; // al
  const RBX::Network::NetworkSchema *v8; // rsi
  RBX::Instance *v9; // rbx
  RBX::Network::NetworkStream *v10; // rdx
  const char *v11; // rsi
  unsigned __int64 v12; // rdi
  unsigned __int16 *v13; // r12
  char v14; // r13
  __int64 v15; // rbx
  __int64 v16; // rax
  RBX::Instance *v17; // rsi
  RBX::Instance *v18; // rbx
  __int64 v19; // rax
  __int64 v20; // rax
  __int64 v21; // rcx
  __int64 v22; // rbx
  unsigned __int64 v23; // rax
  __int64 v24; // rbx
  std::__shared_weak_count *v25; // rbx
  std::__shared_weak_count *v26; // rbx
  RBX *exception; // r14
  __int64 v29; // rdx
  __int64 v30; // rcx
  __int64 v31; // [rsp+10h] [rbp-260h] BYREF
  unsigned __int16 *v32; // [rsp+18h] [rbp-258h]
  void *v33; // [rsp+20h] [rbp-250h] BYREF
  unsigned __int16 *v34; // [rsp+28h] [rbp-248h]
  int v35; // [rsp+3Ch] [rbp-234h]
  std::__shared_weak_count *v36[2]; // [rsp+40h] [rbp-230h] BYREF
  void *v37; // [rsp+50h] [rbp-220h]
  RBX::Instance *v38; // [rsp+58h] [rbp-218h]
  std::__shared_weak_count *v39; // [rsp+60h] [rbp-210h] BYREF
  std::__shared_weak_count *v40; // [rsp+68h] [rbp-208h]
  __int64 v41; // [rsp+70h] [rbp-200h]

  v35 = a3; /*0x10689ca10*/
  v5 = *((const RBX::Network::NetworkSchema **)this + 1560); /*0x10689ca2a*/
  v6 = (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 1032LL))(a1: this); /*0x10689ca3a*/
  v7 = (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 1040LL))(a1: this); /*0x10689ca43*/
  v8 = v5; /*0x10689ca58*/
  v9 = this; /*0x10689ca5b*/
  RBX::Network::TopReplicationContainerConfig::getTop( /*0x10689ca61*/
    this: (RBX::Network::TopReplicationContainerConfig *)&v33,
    a2: v8,
    a3: this,
    a4: v6,
    a5: v7);
  v12 = 0xAAAAAAAAAAAAAAABLL * (((char *)v34 - (_BYTE *)v33) >> 3); /*0x10689ca82*/
  if ( v12 >= (unsigned int)DFInt::ReplicatorTopContainerCountLimit ) /*0x10689ca92*/
  {
    if ( DFInt::ReplicatorCountLimitInfluxHundrethsPercentage != 0 ) /*0x10689ce23*/
    {
      RBX::Analytics::InfluxDb::Points::Points(a1: &v39, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x10689ce4a*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x10689ce75*/
        this: (RBX::Analytics::InfluxDb::Points *)&v39,
        a2: "Count",
        a3: -1431655765 * ((unsigned __int64)((char *)v34 - (_BYTE *)v33) >> 3));
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x10689ce8f*/
        this: (RBX::Analytics::InfluxDb::Points *)&v39,
        a2: "Type",
        a3: "TopReplicationContainer (write)");
      std::string::basic_string[abi:ne200100]<0>(a1: v36, a2: "ReplicatorTopContainerCountLimit", a3: v29, a4: v30); /*0x10689cea2*/
      RBX::Analytics::InfluxDb::Points::report( /*0x10689ceb9*/
        a1: &v39,
        a2: v36,
        a3: (unsigned int)DFInt::ReplicatorCountLimitInfluxHundrethsPercentage,
        a4: 0);
      if ( ((__int64)v36[0] & 1) != 0 ) /*0x10689cec5*/
        operator delete(a1: v37); /*0x10689cece*/
      RBX::Analytics::InfluxDb::Points::~Points(this: (void **)&v39); /*0x10689ceda*/
    }
    RBX::throw_runtime_error(this: (RBX *)"Too many top replication containers", a2: v11); /*0x10689ce2e*/
  }
  RBX::Network::serializeUnsignedVarint(this: (RBX::Network *)v12, (unsigned int)a2, a3: v10); /*0x10689ca9b*/
  v13 = (unsigned __int16 *)v33; /*0x10689caa0*/
  v32 = v34; /*0x10689caae*/
  if ( v33 != v34 )
  {
    v38 = this; /*0x10689cac5*/
    do
    {
      RBX::GuidItem<RBX::Object>::Registry::reg(a1: *((_QWORD *)v9 + 22), a2: *((_QWORD *)v13 + 1)); /*0x10689cad8*/
      v31 = *(_QWORD *)(*((_QWORD *)v13 + 1) + 48LL); /*0x10689cae6*/
      RBX::Network::IdSerializer::serializeId(this: v9, a2, a3: (const RBX::Guid *)&v31); /*0x10689cafa*/
      LOWORD(v39) = *v13; /*0x10689cb04*/
      RBX::Network::NetworkStream::writeBytes(this: a2, a2: &v39, a3: 2u); /*0x10689cb1a*/
      LOBYTE(v39) = *((_BYTE *)v13 + 16); /*0x10689cb24*/
      RBX::Network::NetworkStream::writeBytes(this: a2, a2: &v39, a3: 1u); /*0x10689cb39*/
      v14 = *((_BYTE *)v13 + 17); /*0x10689cb3e*/
      if ( DFFlag::EnablePreloading == 1 && *((int *)v9 + 5668) > 0 )
      {
        v15 = *(_QWORD *)(*((_QWORD *)v13 + 1) + 24LL); /*0x10689cb5d*/
        v16 = RBX::Reflection::Class_getDescriptorPtr<RBX::Preloaded>(); /*0x10689cb61*/
        if ( (unsigned __int8)RBX::Reflection::ClassDescriptor::operator==(a1: v15, a2: v16) != 0 )
        {
          v18 = v38; /*0x10689cb75*/
          v19 = RBX::DataModel::get(this: v38, a2: v17); /*0x10689cb7f*/
          if ( v19 != 0 )
          {
            if ( DFFlag::PreloadingSkipVersionCheck != 0
              || (v20 = *(unsigned int *)(v19 + 868), *((_DWORD *)v18 + 5668) == (_DWORD)v20) )
            {
              v14 = 0; /*0x10689cba9*/
            }
            else if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && (DFLog::NetworkJoin & 0xFE00) != 0 )
            {
              v39 = (std::__shared_weak_count *)*((unsigned int *)v18 + 5668); /*0x10689cd52*/
              v41 = v20; /*0x10689cd59*/
              v36[0] = (std::__shared_weak_count *)17; /*0x10689cd60*/
              v36[1] = (std::__shared_weak_count *)&v39; /*0x10689cd72*/
              FLog::detail::FastLogSafeFormattedInternal(
                a1: DFLog::NetworkJoin,
                a2: qword_10D7F3E08,
                a3: 2,
                a4: (unsigned int)"[DFLog::NetworkJoin] Preloaded version mismatch: client={}, server={}",
                a5: 69,
                a6: 1,
                17,
                &v39);
            }
          }
        }
      }
      LOBYTE(v39) = v14; /*0x10689cbac*/
      RBX::Network::NetworkStream::writeBytes(this: a2, a2: &v39, a3: 1u); /*0x10689cbc2*/
      if ( (_BYTE)v35 == 0 && (v13[8] & 1 | ((v14 & 1) == 0)) == 0 ) /*0x10689cbe0*/
      {
        v21 = *((_QWORD *)v38 + 1560); /*0x10689cbed*/
        v22 = *(_QWORD *)(v21 + 184); /*0x10689cbf4*/
        if ( v22 == 0 || (v23 = *v13, 0xD37A6F4DE9BD37A7LL * ((*(_QWORD *)(v21 + 192) - v22) >> 3) <= v23) ) /*0x10689cc28*/
        {
          exception = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10689cded*/
          RBX::runtime_error( /*0x10689cdfc*/
            this: exception,
            a2: "Top replication container definition included invalid class network id");
          __cxa_throw( /*0x10689ce12*/
            a1: exception,
            lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
            a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
        }
        v24 = 184 * v23 + v22; /*0x10689cc35*/
        RBX::ServiceProvider::create( /*0x10689cc4e*/
          this: (RBX::ServiceProvider *)&v39,
          a2: v38,
          a3: *(const RBX::Name **)(*(_QWORD *)(v24 + 8) + 8LL));
        if ( v39 != nullptr ) /*0x10689cc5d*/
        {
          v36[0] = v39; /*0x10689cc63*/
          v36[1] = v40; /*0x10689cc71*/
          if ( v40 != nullptr ) /*0x10689cc7b*/
            _InterlockedIncrement64((volatile signed __int64 *)v40 + 1); /*0x10689cc7d*/
          RBX::Network::Replicator::addReplicationData( /*0x10689ccb4*/
            a1: v38,
            a2: v24,
            a3: (const void **)v36,
            a4: *((unsigned __int8 *)v13 + 16),
            a5: *((unsigned __int8 *)v13 + 17),
            a6: 1,
            a7: 0,
            a8: 1);
          v25 = v36[1]; /*0x10689ccb9*/
          if ( v36[1] != nullptr /*0x10689ccd5*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v36[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v25 + 16LL))(a1: v25); /*0x10689ccdd*/
            std::__shared_weak_count::__release_weak(this: v25); /*0x10689cce3*/
          }
        }
        v26 = v40; /*0x10689cce8*/
        if ( v40 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v40 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689cd04*/
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v26 + 16LL))(a1: v26); /*0x10689cd0c*/
          std::__shared_weak_count::__release_weak(this: v26); /*0x10689cd12*/
        }
      }
      v13 += 12; /*0x10689cd17*/
      v9 = v38; /*0x10689cd22*/
    }
    while ( v13 != v32 );
    v13 = (unsigned __int16 *)v33; /*0x10689cda6*/
  }
  if ( v13 != nullptr ) /*0x10689cdb0*/
  {
    v34 = v13; /*0x10689cdb2*/
    operator delete(a1: v13); /*0x10689cdbc*/
  }
  return __stack_chk_guard; /*0x10689cdd1*/
}

// Address: 0x10689cf74 | Name: __ZN3RBX7Network16ServerReplicator36sendGlobalMetadataAndTopContainersV2Eb
void __fastcall RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainersV2(
        RBX::Network::ServerReplicator *this,
        unsigned __int8 a2)
{
  __int64 v4; // r15
  const char *v5; // rsi
  const RBX::Instance *v6; // rsi
  RBX::ServiceProvider *ServiceProvider; // rax
  RBX::PermissionsService *v8; // r15
  RBX::Network::NetworkStream *v9; // rdx
  unsigned int v10; // r15d
  __int64 v11; // r14
  __int64 v12; // r15
  std::__shared_weak_count *v13; // r14
  unsigned __int8 v14; // r8
  _QWORD v15[14]; // [rsp+0h] [rbp-F0h] BYREF
  __int64 v16; // [rsp+70h] [rbp-80h] BYREF
  std::__shared_weak_count *v17; // [rsp+78h] [rbp-78h]
  _DWORD v18[17]; // [rsp+80h] [rbp-70h] BYREF
  char v19[41]; // [rsp+C7h] [rbp-29h] BYREF

  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
    FLog::FastLog(
      a1: FLog::Network,
      a2: qword_10D7BBAA8,
      a3: "[FLog::Network] ServerReplicator: Start sending join for peer: %d",
      *((_DWORD *)this + 4072));
  if ( (_BYTE)`guard variable for'RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainersV2(bool)::proftoken1513 == 0 /*0x10689d28c*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainersV2(bool)::proftoken1513) != 0 )
  {
    v15[0] = "on}"; /*0x10689d2b5*/
    RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainersV2(bool)::proftoken1513 = RBX::Profiler::getToken( /*0x10689d2d9*/
                                                                                                  this: (RBX::Profiler *)&aIndexArrayForm[-405460],
                                                                                                  a2: &aDisconnection_0[-212597],
                                                                                                  a3: (const char *)0xFFFFFFFFLL,
                                                                                                  a4: 255,
                                                                                                  a5: v14);
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainersV2(bool)::proftoken1513); /*0x10689d2e7*/
  }
  v4 = RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainersV2(bool)::proftoken1513; /*0x10689cfd2*/
  *(_OWORD *)v15 = 0; /*0x10689cfe3*/
  v15[3] = -1; /*0x10689cfe8*/
  memset(&v15[4], 0, 52); /*0x10689cff1*/
  *(_OWORD *)&v15[11] = 0; /*0x10689d00c*/
  v15[2] = RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainersV2(bool)::proftoken1513; /*0x10689d012*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v15); /*0x10689d01a*/
  v15[3] = RBX::Profiler::enterRegion(a1: v4, a2: -1, a3: 0); /*0x10689d030*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v18); /*0x10689d039*/
  v19[0] = -127; /*0x10689d042*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v18, a2: v19, a3: 1u); /*0x10689d04e*/
  v19[0] = *((_QWORD *)this + 1815) != 0; /*0x10689d05f*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v18, a2: v19, a3: 1u); /*0x10689d06b*/
  if ( RBX::ServiceProvider::find<RBX::Workspace>(a1: this) == 0 ) /*0x10689d07b*/
    RBX::throw_runtime_error(this: (RBX *)"ServerReplicator unable to find workspace.", a2: v5); /*0x10689d2fa*/
  v19[0] = (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 1032LL))(a1: this) ^ 1; /*0x10689d093*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v18, a2: v19, a3: 1u); /*0x10689d09e*/
  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2: v6); /*0x10689d0a6*/
  if ( ServiceProvider != nullptr ) /*0x10689d0ae*/
    v8 = (RBX::PermissionsService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::PermissionsService>(this: ServiceProvider); /*0x10689d0b8*/
  else
    v8 = nullptr; /*0x10689d0bd*/
  v19[0] = RBX::PermissionsService::isThirdPartyAssetAllowed(this: v8); /*0x10689d0cc*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v18, a2: v19, a3: 1u); /*0x10689d0d7*/
  v19[0] = RBX::PermissionsService::isThirdPartyPurchaseAllowed(this: v8); /*0x10689d0e8*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v18, a2: v19, a3: 1u); /*0x10689d0f3*/
  v19[0] = RBX::PermissionsService::isThirdPartyTeleportAllowed(this: v8); /*0x10689d104*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v18, a2: v19, a3: 1u); /*0x10689d10f*/
  if ( RBX::Network::Replicator::getIsOnDemandAdsCapabilityEnabled(this) ) /*0x10689d117*/
  {
    v19[0] = RBX::PermissionsService::isOnDemandAdsAllowed(this: v8); /*0x10689d12c*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v18, a2: v19, a3: 1u); /*0x10689d137*/
  }
  v19[0] = *(_BYTE *)(*((_QWORD *)this + 1808) + 317LL); /*0x10689d14d*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v18, a2: v19, a3: 1u); /*0x10689d158*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x10689d16f*/
    FLog::FastLog( /*0x10689d187*/
      a1: FLog::Network,
      a2: qword_10D7BBAA8,
      a3: "[FLog::Network] Sending peer id = %u",
      *((_DWORD *)this + 5446));
  RBX::Network::serializeUnsignedVarint( /*0x10689d196*/
    this: (RBX::Network *)*((unsigned int *)this + 5446),
    a2: (unsigned int)v18,
    a3: v9);
  v10 = v18[12]; /*0x10689d19f*/
  RBX::Network::ServerReplicator::schemaAddTopReplicationContainerDataToBitstream( /*0x10689d1aa*/
    this,
    a2: (RBX::Network::NetworkStream *)v18,
    a3: a2);
  if ( a2 != 0 ) /*0x10689d1b2*/
  {
    RBX::Network::NetworkStream::SetReadOffsetBytes(this: (RBX::Network::NetworkStream *)v18, a2: v10); /*0x10689d1bb*/
    RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream( /*0x10689d1c9*/
      this,
      a2: (RBX::Network::NetworkStream *)v18,
      a3: 0);
  }
  v11 = *((_QWORD *)this + 35); /*0x10689d1ce*/
  v12 = operator new(a1: 0x58u); /*0x10689d1df*/
  *(_OWORD *)(v12 + 8) = 0; /*0x10689d1e5*/
  *(_QWORD *)v12 = &off_10CAAE190; /*0x10689d1f0*/
  RBX::Network::NetworkStream::NetworkStream(a1: v12 + 24, a2: v18); /*0x10689d201*/
  v16 = v12 + 24; /*0x10689d20a*/
  v17 = (std::__shared_weak_count *)v12; /*0x10689d20d*/
  (*(void (__fastcall **)(__int64, __int64, __int64 *, _QWORD, _QWORD))(*(_QWORD *)v11 + 48LL))( /*0x10689d221*/
    a1: v11,
    a2: 1,
    a3: &v16,
    a4: 0,
    a5: 0);
  v13 = v17; /*0x10689d224*/
  if ( v17 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v17 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689d23d*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x10689d245*/
    std::__shared_weak_count::__release_weak(this: v13); /*0x10689d24b*/
  }
  *((_BYTE *)this + 22643) = 1; /*0x10689d250*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v18); /*0x10689d25b*/
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v15); /*0x10689d267*/
}

// Address: 0x10689d34e | Name: __ZN3RBX7Network16ServerReplicator45sendGlobalMetadataAndTopContainers_deprecatedEPN6RakNet16RakPeerInterfaceEb
void __fastcall RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainers_deprecated(
        RBX::Network::ServerReplicator *this,
        RakNet::RakPeerInterface *a2,
        unsigned __int8 a3)
{
  __int64 v6; // r12
  const RBX::Instance *v7; // rsi
  RBX::ServiceProvider *ServiceProvider; // rax
  RBX::PermissionsService *v9; // r12
  RBX::Network::NetworkStream *v10; // rdx
  unsigned int v11; // r12d
  unsigned __int8 v12; // r8
  std::runtime_error *exception; // r14
  _QWORD v14[13]; // [rsp+20h] [rbp-100h] BYREF
  _BYTE v15[48]; // [rsp+88h] [rbp-98h] BYREF
  _DWORD v16[26]; // [rsp+B8h] [rbp-68h] BYREF

  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u )
    FLog::FastLog(
      a1: FLog::Network,
      a2: qword_10D7BBAA8,
      a3: "[FLog::Network] ServerReplicator: Start sending join for peer: %p",
      a2);
  if ( (_BYTE)`guard variable for'RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainers_deprecated(RakNet::RakPeerInterface *,bool)::proftoken1567 == 0 /*0x10689d646*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainers_deprecated(RakNet::RakPeerInterface *,bool)::proftoken1567) != 0 )
  {
    v14[0] = "hatNumPublishingHandshakeCompletedEventSent"; /*0x10689d66f*/
    RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainers_deprecated(RakNet::RakPeerInterface *,bool)::proftoken1567 = RBX::Profiler::getToken(this: (RBX::Profiler *)&aNetstreamtxlar_0[-351784], a2: &aVoicechatnumpu_0[-40323], a3: (const char *)0xFFFFFFFFLL, a4: 255, a5: v12); /*0x10689d693*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainers_deprecated(RakNet::RakPeerInterface *,bool)::proftoken1567); /*0x10689d6a1*/
  }
  v6 = RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainers_deprecated(RakNet::RakPeerInterface *,bool)::proftoken1567; /*0x10689d3ab*/
  *(_OWORD *)v14 = 0; /*0x10689d3bc*/
  v14[3] = -1; /*0x10689d3c1*/
  memset(&v14[4], 0, 52); /*0x10689d3c9*/
  *(_OWORD *)&v14[11] = 0; /*0x10689d3e0*/
  v14[2] = RBX::Network::ServerReplicator::sendGlobalMetadataAndTopContainers_deprecated(RakNet::RakPeerInterface *,bool)::proftoken1567; /*0x10689d3e5*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v14); /*0x10689d3ec*/
  v14[3] = RBX::Profiler::enterRegion(a1: v6, a2: -1, a3: 0); /*0x10689d402*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v16); /*0x10689d40a*/
  v15[0] = -127; /*0x10689d416*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v16, a2: v15, a3: 1u); /*0x10689d422*/
  v15[0] = *((_QWORD *)this + 1815) != 0; /*0x10689d436*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v16, a2: v15, a3: 1u); /*0x10689d442*/
  if ( RBX::ServiceProvider::find<RBX::Workspace>(a1: this) == 0 ) /*0x10689d459*/
  {
    exception = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x10689d6b5*/
    std::runtime_error::runtime_error(this: exception, a2: "ServerReplicator unable to find workspace."); /*0x10689d6c2*/
    __cxa_throw( /*0x10689d6d8*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  v15[0] = (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 1032LL))(a1: this) ^ 1; /*0x10689d474*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v16, a2: v15, a3: 1u); /*0x10689d47f*/
  ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(this, a2: v7); /*0x10689d487*/
  if ( ServiceProvider != nullptr ) /*0x10689d48f*/
    v9 = (RBX::PermissionsService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::PermissionsService>(this: ServiceProvider); /*0x10689d499*/
  else
    v9 = nullptr; /*0x10689d49e*/
  v15[0] = RBX::PermissionsService::isThirdPartyAssetAllowed(this: v9); /*0x10689d4b0*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v16, a2: v15, a3: 1u); /*0x10689d4bb*/
  v15[0] = RBX::PermissionsService::isThirdPartyPurchaseAllowed(this: v9); /*0x10689d4cf*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v16, a2: v15, a3: 1u); /*0x10689d4da*/
  v15[0] = RBX::PermissionsService::isThirdPartyTeleportAllowed(this: v9); /*0x10689d4ee*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v16, a2: v15, a3: 1u); /*0x10689d4f9*/
  if ( RBX::Network::Replicator::getIsOnDemandAdsCapabilityEnabled(this) ) /*0x10689d501*/
  {
    v15[0] = RBX::PermissionsService::isOnDemandAdsAllowed(this: v9); /*0x10689d519*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v16, a2: v15, a3: 1u); /*0x10689d524*/
  }
  v15[0] = *(_BYTE *)(*((_QWORD *)this + 1808) + 317LL); /*0x10689d53d*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v16, a2: v15, a3: 1u); /*0x10689d548*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x10689d55f*/
    FLog::FastLog( /*0x10689d577*/
      a1: FLog::Network,
      a2: qword_10D7BBAA8,
      a3: "[FLog::Network] Sending peer id = %u",
      *((_DWORD *)this + 5446));
  RBX::Network::serializeUnsignedVarint( /*0x10689d586*/
    this: (RBX::Network *)*((unsigned int *)this + 5446),
    a2: (unsigned int)v16,
    a3: v10);
  v11 = v16[12]; /*0x10689d58f*/
  RBX::Network::ServerReplicator::schemaAddTopReplicationContainerDataToBitstream( /*0x10689d59a*/
    this,
    a2: (RBX::Network::NetworkStream *)v16,
    a3);
  if ( a3 != 0 ) /*0x10689d5a2*/
  {
    RBX::Network::NetworkStream::SetReadOffsetBytes(this: (RBX::Network::NetworkStream *)v16, a2: v11); /*0x10689d5ab*/
    RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream( /*0x10689d5b9*/
      this,
      a2: (RBX::Network::NetworkStream *)v16,
      a3: 0);
  }
  RakNet::AddressOrGUID::AddressOrGUID( /*0x10689d5cc*/
    this: (RakNet::AddressOrGUID *)v15,
    a2: (RBX::Network::ServerReplicator *)((char *)this + 240));
  (*(void (__fastcall **)(RakNet::RakPeerInterface *, _DWORD *, __int64, __int64, _QWORD, _BYTE *, _DWORD, _DWORD, _QWORD))(*(_QWORD *)a2 + 184LL))( /*0x10689d608*/
    a1: a2,
    a2: v16,
    a3: 2,
    a4: 3,
    a5: 0,
    a6: v15,
    a7: 0,
    a8: 0,
    a9: 0);
  *((_BYTE *)this + 22643) = 1; /*0x10689d60a*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v16); /*0x10689d615*/
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v14); /*0x10689d621*/
}

// Address: 0x10689d72a | Name: __ZN3RBX7Network16ServerReplicator46copyAndQueuePreserializedJoinItemAndMarkActiveERNSt3__110shared_ptrINS0_29PreserializedReplicationCacheEEEb
__int64 __fastcall RBX::Network::ServerReplicator::copyAndQueuePreserializedJoinItemAndMarkActive(
        __int64 a1,
        __int64 a2)
{
  __int64 v4; // r15
  __int64 v5; // rax
  unsigned __int8 v6; // r13
  __int64 v7; // r12
  RBX::Network::Item *v8; // r15
  __int64 v9; // rax
  std::__shared_weak_count *v10; // r14
  RBX::Network::Item *v11; // r14
  __int64 v12; // rax
  unsigned __int8 v14; // r8
  _QWORD v15[14]; // [rsp+0h] [rbp-E0h] BYREF
  std::__shared_weak_count *v16[2]; // [rsp+70h] [rbp-70h] BYREF
  _QWORD v17[4]; // [rsp+80h] [rbp-60h] BYREF
  _QWORD *v18; // [rsp+A0h] [rbp-40h]

  if ( (_BYTE)`guard variable for'RBX::Network::ServerReplicator::copyAndQueuePreserializedJoinItemAndMarkActive(std::shared_ptr<RBX::Network::PreserializedReplicationCache> &,bool)::proftoken1618 == 0 /*0x10689d942*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::ServerReplicator::copyAndQueuePreserializedJoinItemAndMarkActive(std::shared_ptr<RBX::Network::PreserializedReplicationCache> &,bool)::proftoken1618) != 0 )
  {
    v15[0] = "tition {}"; /*0x10689d96b*/
    RBX::Network::ServerReplicator::copyAndQueuePreserializedJoinItemAndMarkActive(std::shared_ptr<RBX::Network::PreserializedReplicationCache> &,bool)::proftoken1618 = RBX::Profiler::getToken(this: (RBX::Profiler *)&aFlogRobloxtele_22[-159118], a2: &aFlogStudioacti_9[-825816], a3: (const char *)0xFFFFFFFFLL, a4: 255, a5: v14); /*0x10689d98f*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::ServerReplicator::copyAndQueuePreserializedJoinItemAndMarkActive(std::shared_ptr<RBX::Network::PreserializedReplicationCache> &,bool)::proftoken1618); /*0x10689d99d*/
  }
  v4 = RBX::Network::ServerReplicator::copyAndQueuePreserializedJoinItemAndMarkActive(std::shared_ptr<RBX::Network::PreserializedReplicationCache> &,bool)::proftoken1618; /*0x10689d760*/
  *(_OWORD *)v15 = 0; /*0x10689d771*/
  v15[3] = -1; /*0x10689d774*/
  memset(&v15[4], 0, 52); /*0x10689d77c*/
  *(_OWORD *)&v15[11] = 0; /*0x10689d78f*/
  v15[2] = RBX::Network::ServerReplicator::copyAndQueuePreserializedJoinItemAndMarkActive(std::shared_ptr<RBX::Network::PreserializedReplicationCache> &,bool)::proftoken1618; /*0x10689d793*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v15); /*0x10689d797*/
  v15[3] = RBX::Profiler::enterRegion(a1: v4, a2: -1, a3: 0); /*0x10689d7b4*/
  v5 = *(_QWORD *)(a1 + 14408); /*0x10689d7b7*/
  v6 = *(_BYTE *)(v5 + 3761); /*0x10689d7be*/
  v7 = *(unsigned int *)(v5 + 424); /*0x10689d7c5*/
  v8 = (RBX::Network::Item *)operator new(a1: 0xB0u); /*0x10689d7d6*/
  v9 = *(_QWORD *)(a2 + 8); /*0x10689d7d9*/
  *(_OWORD *)v16 = *(_OWORD *)a2; /*0x10689d7e1*/
  if ( v9 != 0 ) /*0x10689d7e8*/
    _InterlockedIncrement64((volatile signed __int64 *)(v9 + 8)); /*0x10689d7ea*/
  RBX::Network::Replicator::JoinDataItemV2::JoinDataItemV2(a1: v8, a2: a1, a3: v16, a4: v6, a5: v7); /*0x10689d800*/
  v10 = v16[1]; /*0x10689d805*/
  if ( v16[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v16[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689d81e*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x10689d826*/
    std::__shared_weak_count::__release_weak(this: v10); /*0x10689d82c*/
  }
  RBX::Network::ItemQueue::push_back(this: (RBX::Network::ItemQueue *)(a1 + 14536), a2: v8); /*0x10689d83e*/
  ++*(_DWORD *)(*(_QWORD *)(a1 + 14408) + 3244LL); /*0x10689d84a*/
  *(_BYTE *)(a1 + 18700) = 1; /*0x10689d852*/
  *(_BYTE *)(a1 + 18702) = 1; /*0x10689d858*/
  if ( *(_BYTE *)(a1 + 10391) == 1 ) /*0x10689d864*/
    (*(void (__fastcall **)(_QWORD))(**(_QWORD **)(a1 + 280) + 88LL))(a1: *(_QWORD *)(a1 + 280)); /*0x10689d870*/
  v11 = (RBX::Network::Item *)operator new(a1: 0x80u); /*0x10689d87d*/
  v17[0] = off_10CAAFFF8; /*0x10689d88b*/
  v17[1] = RBX::Network::Replicator::isInitialDataSent; /*0x10689d895*/
  v17[2] = 0; /*0x10689d899*/
  v17[3] = a1; /*0x10689d8a1*/
  v18 = v17; /*0x10689d8a5*/
  RBX::Network::Replicator::TagItem::TagItem(a1: v11, a2: a1, a3: 13, a4: v17); /*0x10689d8ba*/
  RBX::Network::ItemQueue::push_back(this: (RBX::Network::ItemQueue *)(a1 + 14536), a2: v11); /*0x10689d8c8*/
  if ( v18 == v17 ) /*0x10689d8d4*/
  {
    v12 = 32; /*0x10689d8e2*/
  }
  else
  {
    v12 = 40; /*0x10689d8d6*/
    if ( v18 == nullptr ) /*0x10689d8de*/
      goto LABEL_14; /*0x10689d8de*/
  }
  (*(void (**)(void))(*v18 + v12))(); /*0x10689d8ea*/
LABEL_14:
  *(_QWORD *)(a1 + 15584) = *(_QWORD *)(*(_QWORD *)(a1 + 14408) + 2848LL); /*0x10689d8ed*/
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v15); /*0x10689d909*/
  return __stack_chk_guard; /*0x10689d922*/
}

// Address: 0x10689da1a | Name: __ZN3RBX7Network16ServerReplicator13addServerTimeEv
__int64 __fastcall RBX::Network::ServerReplicator::addServerTime(RBX::Network::ServerReplicator *this)
{
  __int64 v2; // r14
  RBX::Network::Replicator::InitialServerTimeItem *v3; // r15
  _BYTE v5[24]; // [rsp+10h] [rbp-40h] BYREF
  __int64 v6; // [rsp+28h] [rbp-28h]
  _BYTE *v7; // [rsp+30h] [rbp-20h]

  v2 = RBX::Time::epochTimeMs(this); /*0x10689da2f*/
  if ( (unsigned __int8)DFLog::PeerMonotonicClock >= 6u && BYTE1(DFLog::PeerMonotonicClock) >= 5u ) /*0x10689da4b*/
  {
    v6 = 3; /*0x10689da5d*/
    v7 = v5; /*0x10689da65*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x10689da89*/
      a1: DFLog::PeerMonotonicClock,
      a2: qword_10D7B1378,
      a3: 5,
      a4: (unsigned int)"[DFLog::PeerMonotonicClock] Sending initial server time {}",
      a5: 58,
      a6: 1,
      3,
      v5,
      v2);
  }
  v3 = (RBX::Network::Replicator::InitialServerTimeItem *)operator new(a1: 0x48u); /*0x10689da98*/
  RBX::Network::Replicator::InitialServerTimeItem::InitialServerTimeItem(this: v3, a2: this, a3: v2); /*0x10689daa4*/
  return RBX::Network::ItemQueue::push_back(this: (RBX::Network::ServerReplicator *)((char *)this + 14584), a2: v3); /*0x10689dabb*/
}

// Address: 0x10689dada | Name: __ZN3RBX7Network16ServerReplicator19parentPlayerAndSendERNS_5TimerILNS_4Time12SampleMethodE2EEE
__int64 __fastcall RBX::Network::ServerReplicator::parentPlayerAndSend(
        RBX::Network::ServerReplicator *this,
        double *a2)
{
  __int64 v4; // r15
  __int64 v5; // rax
  std::__shared_weak_count *v6; // r15
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rax
  std::__shared_weak_count *v10; // r15
  __int64 v11; // rax
  std::__shared_weak_count *v12; // r15
  std::__shared_weak_count *v13; // r15
  RBX::Instance *v14; // rsi
  __int64 v15; // r15
  __int64 v16; // rax
  RBX::Network::Item *v17; // r15
  __int64 v18; // rax
  __int64 v19; // rax
  RBX::Network::Item *v20; // r15
  __int64 v21; // rax
  void *v22; // rdi
  std::__shared_weak_count *v23; // r15
  __int64 v24; // r12
  __int64 v25; // rax
  float v26; // xmm0_4
  __int64 v27; // rax
  void *v28; // rdi
  std::__shared_weak_count *v29; // rbx
  unsigned __int8 v31; // r8
  _QWORD v32[14]; // [rsp+0h] [rbp-180h] BYREF
  __int128 v33; // [rsp+70h] [rbp-110h] BYREF
  void *v34; // [rsp+88h] [rbp-F8h] BYREF
  std::__shared_weak_count *v35[2]; // [rsp+90h] [rbp-F0h] BYREF
  void *v36; // [rsp+A8h] [rbp-D8h] BYREF
  std::__shared_weak_count *v37[2]; // [rsp+B0h] [rbp-D0h] BYREF
  void *v38; // [rsp+C0h] [rbp-C0h]
  std::__shared_weak_count *v39[2]; // [rsp+D0h] [rbp-B0h] BYREF
  void *v40; // [rsp+E0h] [rbp-A0h]
  _BYTE v41[32]; // [rsp+F0h] [rbp-90h] BYREF
  _BYTE *v42; // [rsp+110h] [rbp-70h]
  _BYTE v43[32]; // [rsp+120h] [rbp-60h] BYREF
  _BYTE *v44; // [rsp+140h] [rbp-40h]

  if ( (_BYTE)`guard variable for'RBX::Network::ServerReplicator::parentPlayerAndSend(RBX::Timer<(RBX::Time::SampleMethod)2> &)::proftoken1656 == 0
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::ServerReplicator::parentPlayerAndSend(RBX::Timer<(RBX::Time::SampleMethod)2> &)::proftoken1656) != 0 )
  {
    v32[0] = "            height: 8px;\n                border-radius: 4px;\n            }\n            QSlider::handle:horizontal {\n                border-image:url(:16x16/images/Studio 2.0 icons/16x16/slider_handle.png);\n                margin-left: -14px;\n                margin-right: -14px;\n                margin-top: -10px;\n                margin-bottom: -10px;\n            }\n            QSlider::handle:horizontal:hover {\n                border-image:url(:16x16/images/Studio 2.0 icons/16x16/slider_handle_hover.png);\n                margin-left: -14px;\n                margin-right: -14px;\n                margin-top: -10px;\n                margin-bottom: -10px;\n            }\n        ";
    RBX::Network::ServerReplicator::parentPlayerAndSend(RBX::Timer<(RBX::Time::SampleMethod)2> &)::proftoken1656 = RBX::Profiler::getToken(this: (RBX::Profiler *)&aAssertionFaile_163[-246714], a2: &aQsliderHorizon[-717564], a3: (const char *)0xFFFFFFFFLL, a4: 255, a5: v31); /*0x10689e11a*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::ServerReplicator::parentPlayerAndSend(RBX::Timer<(RBX::Time::SampleMethod)2> &)::proftoken1656); /*0x10689e128*/
  }
  v4 = RBX::Network::ServerReplicator::parentPlayerAndSend(RBX::Timer<(RBX::Time::SampleMethod)2> &)::proftoken1656; /*0x10689db10*/
  *(_OWORD *)v32 = 0; /*0x10689db22*/
  v32[3] = -1; /*0x10689db26*/
  memset(&v32[4], 0, 52); /*0x10689db2e*/
  *(_OWORD *)&v32[11] = 0; /*0x10689db44*/
  v32[2] = RBX::Network::ServerReplicator::parentPlayerAndSend(RBX::Timer<(RBX::Time::SampleMethod)2> &)::proftoken1656; /*0x10689db49*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v32); /*0x10689db4d*/
  v32[3] = RBX::Profiler::enterRegion(a1: v4, a2: -1, a3: 0); /*0x10689db6a*/
  v5 = *((_QWORD *)this + 2839); /*0x10689db6d*/
  *(_OWORD *)v39 = *((_OWORD *)this + 1419); /*0x10689db7c*/
  if ( v5 != 0 ) /*0x10689db87*/
    _InterlockedIncrement64((volatile signed __int64 *)(v5 + 8)); /*0x10689db89*/
  RBX::Network::ServerReplicator::prepareRemotePlayer(a1: (__int64)this, a2: (__int64)v39); /*0x10689db98*/
  v6 = v39[1]; /*0x10689db9d*/
  if ( v39[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v39[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689dbb9*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x10689dbc1*/
    std::__shared_weak_count::__release_weak(this: v6); /*0x10689dbc7*/
  }
  if ( *((_BYTE *)this + 14417) == 0 )
  {
    if ( RBX::Network::Replicator::getInitialServerTimeItemEnabled(this) ) /*0x10689dbdc*/
      RBX::Network::ServerReplicator::addServerTime(this); /*0x10689dbe8*/
    RBX::Player::getOsPlatformServerOnly(this: (RBX::Player *)v39); /*0x10689dbfb*/
    v7 = *((_QWORD *)this + 2838); /*0x10689dc00*/
    if ( (*(_BYTE *)(v7 + 264) & 1) != 0 ) /*0x10689dc0e*/
    {
      std::string::__init_copy_ctor_external(a1: v37, a2: *(_QWORD *)(v7 + 280), a3: *(_QWORD *)(v7 + 272)); /*0x10689dc44*/
    }
    else
    {
      v8 = v7 + 264; /*0x10689dc10*/
      v38 = *(void **)(v8 + 16); /*0x10689dc1a*/
      *(_OWORD *)v37 = *(_OWORD *)v8; /*0x10689dc25*/
    }
    RBX::Network::NetworkBandwidthManager::setReplicatorReportInfo(a1: (char *)this + 12688, a2: v39, a3: v37); /*0x10689dc5e*/
    if ( ((__int64)v37[0] & 1) != 0 ) /*0x10689dc6a*/
      operator delete(a1: v38); /*0x10689dc73*/
    if ( ((__int64)v39[0] & 1) != 0 ) /*0x10689dc7f*/
      operator delete(a1: v40); /*0x10689dc88*/
    v9 = *((_QWORD *)this + 2839); /*0x10689dc8d*/
    *(_OWORD *)v35 = *((_OWORD *)this + 1419); /*0x10689dc9c*/
    if ( v9 != 0 ) /*0x10689dca7*/
      _InterlockedIncrement64((volatile signed __int64 *)(v9 + 8)); /*0x10689dca9*/
    RBX::Network::ServerReplicator::addToHighPriorityItemsListAsNewInstance(a1: this, a2: v35); /*0x10689dcb8*/
    v10 = v35[1]; /*0x10689dcbd*/
    if ( v35[1] != nullptr /*0x10689dcd9*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v35[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x10689dce1*/
      std::__shared_weak_count::__release_weak(this: v10); /*0x10689dce7*/
    }
    v11 = RBX::Instance::findConstFirstChildOfType<RBX::PlayerGui>(a1: *((_QWORD *)this + 2838)); /*0x10689dcf3*/
    if ( v11 != 0 ) /*0x10689dcfb*/
    {
      RBX::shared_from<RBX::PlayerGui>(a1: v39, a2: v11); /*0x10689dd0b*/
      v33 = *(_OWORD *)v39; /*0x10689dd1f*/
      *(_OWORD *)v39 = 0; /*0x10689dd27*/
      RBX::Network::ServerReplicator::addToHighPriorityItemsListAsNewInstance(a1: this, a2: &v33); /*0x10689dd32*/
      v12 = *((std::__shared_weak_count **)&v33 + 1); /*0x10689dd37*/
      if ( *((_QWORD *)&v33 + 1) != 0 /*0x10689dd53*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v33 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x10689dd5b*/
        std::__shared_weak_count::__release_weak(this: v12); /*0x10689dd61*/
      }
      v13 = v39[1]; /*0x10689dd66*/
      if ( v39[1] != nullptr /*0x10689dd82*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v39[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x10689dd8a*/
        std::__shared_weak_count::__release_weak(this: v13); /*0x10689dd90*/
      }
    }
    if ( DFFlag::EnablePreloading == 1 ) /*0x10689dd9f*/
    {
      v15 = RBX::ServiceProvider::find<RBX::Preloaded>(a1: this); /*0x10689ddad*/
      if ( v15 != 0 /*0x10689ddeb*/
        && (*((int *)this + 5668) <= 0
         || (v16 = RBX::DataModel::get(this, a2: v14)) == 0
         || DFFlag::PreloadingSkipVersionCheck == 0 && *((_DWORD *)this + 5668) != *(_DWORD *)(v16 + 868)) )
      {
        v39[0] = this; /*0x10689ddf4*/
        RBX::Instance::visitDescendants<RBX::Network::ServerReplicator::parentPlayerAndSend(RBX::Timer<(RBX::Time::SampleMethod)2> &)::$_0>(a1: v15); /*0x10689ddfa*/
        v17 = (RBX::Network::Item *)operator new(a1: 0x80u); /*0x10689de09*/
        v44 = nullptr; /*0x10689de10*/
        RBX::Network::Replicator::TagItem::TagItem(a1: v17, a2: this, a3: 16, a4: v43); /*0x10689de2a*/
        RBX::Network::ItemQueue::push_back(this: (RBX::Network::ServerReplicator *)((char *)this + 14584), a2: v17); /*0x10689de3c*/
        if ( v44 == v43 ) /*0x10689de48*/
        {
          v18 = 32; /*0x10689de56*/
        }
        else
        {
          v18 = 40; /*0x10689de4a*/
          if ( v44 == nullptr ) /*0x10689de52*/
            goto LABEL_40; /*0x10689de52*/
        }
        (*(void (**)(void))(*(_QWORD *)v44 + v18))(); /*0x10689de5e*/
      }
    }
LABEL_40:
    v19 = RBX::ServiceProvider::find<RBX::ReplicatedFirst>(a1: this); /*0x10689de61*/
    if ( v19 == 0 ) /*0x10689de6c*/
      goto LABEL_47; /*0x10689de6c*/
    v39[0] = (std::__shared_weak_count *)RBX::Network::ServerReplicator::addToHighPriorityItemsListAsNewInstance; /*0x10689de80*/
    v39[1] = nullptr; /*0x10689de83*/
    v40 = this; /*0x10689de8b*/
    RBX::Instance::visitDescendants<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Network::ServerReplicator,std::shared_ptr<RBX::Instance>>,boost::_bi::list2<boost::_bi::value<RBX::Network::ServerReplicator*>,boost::arg<1>>>>(a1: v19); /*0x10689de92*/
    v20 = (RBX::Network::Item *)operator new(a1: 0x80u); /*0x10689dea1*/
    v42 = nullptr; /*0x10689deab*/
    RBX::Network::Replicator::TagItem::TagItem(a1: v20, a2: this, a3: 12, a4: v41); /*0x10689dec5*/
    RBX::Network::ItemQueue::push_back(this: (RBX::Network::ServerReplicator *)((char *)this + 14584), a2: v20); /*0x10689ded7*/
    if ( v42 == v41 ) /*0x10689dee3*/
    {
      v21 = 32; /*0x10689def1*/
    }
    else
    {
      v21 = 40; /*0x10689dee5*/
      if ( v42 == nullptr ) /*0x10689deed*/
        goto LABEL_46; /*0x10689deed*/
    }
    (*(void (**)(void))(*(_QWORD *)v42 + v21))(); /*0x10689def9*/
LABEL_46:
    RBX::Network::Replicator::addReplicatorState(this, a2: 4); /*0x10689defc*/
LABEL_47:
    RBX::Network::Replicator::sendMarker(this: (RBX::Network::Replicator *)v37, a2: (__int64)this); /*0x10689df09*/
    v23 = v37[0]; /*0x10689df18*/
    if ( v37[0] != nullptr ) /*0x10689df22*/
    {
      v24 = *((_QWORD *)v37[0] + 3); /*0x10689df24*/
      v25 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Marker>(); /*0x10689df28*/
      if ( *(unsigned __int16 *)(v24 + 440) - (unsigned int)*(unsigned __int16 *)(v25 + 440) <= *(unsigned __int16 *)(v25 + 442) ) /*0x10689df48*/
      {
        v39[0] = (std::__shared_weak_count *)RBX::Network::ServerReplicator::joinMarkerReceived; /*0x10689df58*/
        v39[1] = nullptr; /*0x10689df5b*/
        v40 = this; /*0x10689df63*/
        rbx::signal<void ()(void)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::Network::ServerReplicator>,boost::_bi::list1<boost::_bi::value<RBX::Network::ServerReplicator*>>>>( /*0x10689df78*/
          a1: &v34,
          a2: (char *)v23 + 184);
        v22 = v34; /*0x10689df7d*/
        if ( v34 != nullptr && _InterlockedDecrement((volatile signed __int32 *)v34 + 1) == 0 ) /*0x10689df8d*/
          rbx::signals::slot_base::operator delete(a1: v22); /*0x10689df8f*/
      }
    }
    v26 = (RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v22) - *a2) * 1000.0; /*0x10689dfa6*/
    *((float *)this + 3898) = v26; /*0x10689dfaa*/
    v27 = (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 688LL))(a1: this); /*0x10689dfb8*/
    if ( v27 != 0 ) /*0x10689dfc1*/
    {
      v39[0] = (std::__shared_weak_count *)RBX::Network::Replicator::onPlayerRemoving; /*0x10689dfd1*/
      v39[1] = nullptr; /*0x10689dfd4*/
      v40 = this; /*0x10689dfdc*/
      rbx::signal<void ()(std::shared_ptr<RBX::Instance>,std::shared_ptr<RBX::Instance>)>::connect<std::__bind<void (RBX::Network::Replicator::*)(std::shared_ptr<RBX::Instance> const&,std::shared_ptr<RBX::Instance> const&),RBX::Network::ServerReplicator *,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>( /*0x10689dfee*/
        a1: &v36,
        a2: v27 + 96);
      rbx::signals::scoped_connection::operator=(this: (RBX::Network::ServerReplicator *)((char *)this + 12544)); /*0x10689e001*/
      v28 = v36; /*0x10689e006*/
      if ( v36 != nullptr && _InterlockedDecrement((volatile signed __int32 *)v36 + 1) == 0 ) /*0x10689e016*/
        rbx::signals::slot_base::operator delete(a1: v28); /*0x10689e018*/
    }
    if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && BYTE1(DFLog::NetworkJoin) >= 3u )
      FLog::FastLogF(
        a1: *(_QWORD *)&DFLog::NetworkJoin,
        a2: qword_10D7F3E08,
        a3: "[DFLog::NetworkJoin] Server Join snapshot timer: %f",
        COERCE_DOUBLE((unsigned __int64)*((_DWORD *)this + 3898)),
        0.0,
        0.0,
        0.0);
    v29 = v37[1]; /*0x10689e05e*/
    if ( v37[1] != nullptr /*0x10689e07a*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v37[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v29 + 16LL))(a1: v29); /*0x10689e082*/
      std::__shared_weak_count::__release_weak(this: v29); /*0x10689e088*/
    }
  }
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v32); /*0x10689e08d*/
  return __stack_chk_guard; /*0x10689e0ad*/
}

// Address: 0x10689e26a | Name: __ZN3RBX7Network16ServerReplicator39addToHighPriorityItemsListAsNewInstanceENSt3__110shared_ptrINS_8InstanceEEE
__int64 __fastcall RBX::Network::ServerReplicator::addToHighPriorityItemsListAsNewInstance(
        __int64 a1,
        const RBX::Object **a2)
{
  __int64 v4; // rdi
  __int64 result; // rax
  __int64 v6; // rcx
  unsigned __int64 v7; // rax
  __int64 v8; // rdx
  unsigned __int64 v9; // rsi
  __int64 v10; // r15
  std::__shared_weak_count *v11; // r13
  std::__shared_weak_count *v12; // rax
  __int64 **v13; // rdi
  __int64 *v14; // r12
  RBX::Network::Item *v15; // r12
  std::__shared_weak_count *v16; // rbx
  std::__shared_weak_count *v17; // rbx
  std::__shared_weak_count *v18; // rbx
  std::__shared_weak_count *v19; // [rsp+10h] [rbp-80h] BYREF
  std::__shared_weak_count *v20; // [rsp+18h] [rbp-78h]
  std::__shared_weak_count *v21; // [rsp+20h] [rbp-70h] BYREF
  std::__shared_weak_count *v22; // [rsp+28h] [rbp-68h]
  __int128 v23; // [rsp+30h] [rbp-60h] BYREF
  std::__shared_weak_count *v24; // [rsp+40h] [rbp-50h]
  __int64 ***v25; // [rsp+48h] [rbp-48h]
  std::__shared_weak_count *v26[2]; // [rsp+50h] [rbp-40h]

  if ( DFFlag::DebugNeverReplicateQueueingCrash == 1 ) /*0x10689e28b*/
    RBX::Network::MegaReplicator::crashIfQueueingNoReplicateObject( /*0x10689e297*/
      this: *(RBX::Network::MegaReplicator **)(a1 + 14408),
      a2: *a2);
  v4 = *(_QWORD *)(a1 + 12480) + 64LL; /*0x10689e2aa*/
  v26[0] = *((std::__shared_weak_count **)*a2 + 3); /*0x10689e2b2*/
  result = RBX::detail::DenseHashTable<RBX::Reflection::ClassDescriptor const*,std::pair<RBX::Reflection::ClassDescriptor const*,unsigned short>,std::pair<RBX::Reflection::ClassDescriptor const* const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::ClassDescriptor const*,unsigned short>,RBX::Hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>::find(a1: v4); /*0x10689e2b5*/
  if ( result != 0 ) /*0x10689e2bd*/
  {
    v6 = *(_QWORD *)(a1 + 12480); /*0x10689e2c3*/
    v7 = *(unsigned __int16 *)(result + 8); /*0x10689e2ca*/
    v8 = *(_QWORD *)(v6 + 184); /*0x10689e2ce*/
    v9 = 0xD37A6F4DE9BD37A7LL * ((*(_QWORD *)(v6 + 192) - v8) >> 3); /*0x10689e2ed*/
    v10 = v8 + 184 * v7; /*0x10689e2f8*/
    v11 = nullptr; /*0x10689e2fb*/
    if ( v9 <= v7 ) /*0x10689e301*/
      v10 = 0; /*0x10689e301*/
    *(_OWORD *)v26 = 0; /*0x10689e308*/
    v12 = nullptr; /*0x10689e313*/
    if ( *(_BYTE *)(a1 + 14416) == 0 ) /*0x10689e318*/
    {
      RBX::Network::MegaReplicator::getNewInstanceStreamCacheSeparateFromReplicationData( /*0x10689e328*/
        this: (RBX::Network::MegaReplicator *)&v19,
        a2: *(RBX::Instance **)(a1 + 14408));
      v12 = v19; /*0x10689e32d*/
      v11 = v20; /*0x10689e331*/
      v26[0] = v19; /*0x10689e335*/
      v26[1] = v20; /*0x10689e339*/
    }
    v24 = v12; /*0x10689e33d*/
    v25 = *(__int64 ****)(a1 + 11792); /*0x10689e348*/
    v13 = *v25; /*0x10689e34c*/
    v14 = **v25; /*0x10689e34f*/
    if ( v14 != nullptr ) /*0x10689e355*/
      *v13 = (__int64 *)*v14; /*0x10689e35b*/
    else
      v14 = boost::pool<RBX::TrackedAllocator>::malloc_need_resize(a1: v13, a2: v9); /*0x10689e365*/
    *v14 = (__int64)v25; /*0x10689e36c*/
    v15 = (RBX::Network::Item *)(v14 + 1); /*0x10689e370*/
    v23 = *(_OWORD *)a2; /*0x10689e37c*/
    *(_OWORD *)a2 = 0; /*0x10689e382*/
    v21 = v24; /*0x10689e38e*/
    v22 = v11; /*0x10689e391*/
    *(_OWORD *)v26 = 0; /*0x10689e395*/
    RBX::Network::NewObjectItem::NewObjectItem(a1: v15, a2: a1, a3: v10, a4: &v23, a5: &v21, a6: 0, a7: 1); /*0x10689e3af*/
    result = RBX::Network::ItemQueue::push_back(this: (RBX::Network::ItemQueue *)(a1 + 14584), a2: v15); /*0x10689e3c4*/
    v16 = v22; /*0x10689e3c9*/
    if ( v22 != nullptr ) /*0x10689e3d0*/
    {
      result = _InterlockedExchangeAdd64((volatile signed __int64 *)v22 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x10689e3d9*/
      if ( result == 0 ) /*0x10689e3e2*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x10689e3ea*/
        result = std::__shared_weak_count::__release_weak(this: v16); /*0x10689e3f0*/
      }
    }
    v17 = *((std::__shared_weak_count **)&v23 + 1); /*0x10689e3f5*/
    if ( *((_QWORD *)&v23 + 1) != 0 ) /*0x10689e3fc*/
    {
      result = _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v23 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL); /*0x10689e405*/
      if ( result == 0 ) /*0x10689e40e*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x10689e416*/
        result = std::__shared_weak_count::__release_weak(this: v17); /*0x10689e41c*/
      }
    }
    v18 = v26[1]; /*0x10689e421*/
    if ( v26[1] != nullptr ) /*0x10689e428*/
    {
      result = _InterlockedExchangeAdd64((volatile signed __int64 *)v26[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x10689e431*/
      if ( result == 0 ) /*0x10689e43a*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(a1: v18); /*0x10689e442*/
        return std::__shared_weak_count::__release_weak(this: v18); /*0x10689e448*/
      }
    }
  }
  return result; /*0x10689e44d*/
}

// Address: 0x10689e82c | Name: __ZN3RBX7Network16ServerReplicator25queueStreamDataInfoUpdateENS_12StreamRegion2IdEij
__int64 __fastcall RBX::Network::ServerReplicator::queueStreamDataInfoUpdate(
        __int64 a1,
        __int64 a2,
        int a3,
        int a4,
        int a5)
{
  __int64 v9; // r14

  v9 = operator new(a1: 0x58u); /*0x10689e854*/
  RBX::Network::Item::Item(this: (RBX::Network::Item *)v9, a2: (RBX::Network::Replicator *)a1); /*0x10689e85d*/
  *(_QWORD *)v9 = off_10CAB31F8; /*0x10689e86d*/
  *(_QWORD *)(v9 + 64) = a2; /*0x10689e870*/
  *(_DWORD *)(v9 + 72) = a3; /*0x10689e874*/
  *(_DWORD *)(v9 + 76) = a4; /*0x10689e878*/
  *(_DWORD *)(v9 + 80) = a5; /*0x10689e87f*/
  return RBX::Network::ItemQueue::push_back(this: (RBX::Network::ItemQueue *)(a1 + 14536), a2: (RBX::Network::Item *)v9); /*0x10689e894*/
}

// Address: 0x10689e8b6 | Name: __ZN3RBX7Network16ServerReplicator20doSecurityChannelJobEv
__int64 __fastcall RBX::Network::ServerReplicator::doSecurityChannelJob(RBX::Network::ServerReplicator *this)
{
  __m128i *v1; // rdi
  __int64 result; // rax

  v1 = *((__m128i **)this + 2829); /*0x10689e8ba*/
  if ( v1 != nullptr ) /*0x10689e8c4*/
    return RBX::Network::SecurityChannel::clearExpiredItems(this: v1); /*0x10689e8c7*/
  return result; /*0x10689e8c6*/
}

// Address: 0x10689e8ce | Name: __ZN3RBX7Network16ServerReplicator19installRemotePlayerEv
void __fastcall RBX::Network::ServerReplicator::installRemotePlayer(RBX::Network::ServerReplicator *this)
{
  __int64 v2; // r14
  __int64 v3; // r14
  __int64 v4; // r14
  __int64 v5; // rdi
  __int64 UserID; // rcx
  bool v7; // al
  bool v8; // r14
  __int64 v9; // rdi
  unsigned __int8 v10; // r8
  __int64 Token; // r14
  _QWORD v12[13]; // [rsp+0h] [rbp-A0h] BYREF
  _BYTE v13[8]; // [rsp+68h] [rbp-38h] BYREF
  __int128 v14; // [rsp+70h] [rbp-30h] BYREF
  void *v15; // [rsp+80h] [rbp-20h]

  if ( *((_BYTE *)this + 22641) == 0 )
  {
    v2 = *((_QWORD *)this + 2824); /*0x10689e8ee*/
    if ( (*((_BYTE *)this + 22680) & 1) != 0 ) /*0x10689e8fc*/
    {
      std::string::__init_copy_ctor_external(a1: &v14, a2: *((_QWORD *)this + 2837), a3: *((_QWORD *)this + 2836)); /*0x10689e928*/
    }
    else
    {
      v15 = *((void **)this + 2837); /*0x10689e909*/
      v14 = *(_OWORD *)((char *)this + 22680); /*0x10689e910*/
    }
    RBX::Player::setGameSessionID(a1: v2, a2: &v14); /*0x10689e934*/
    if ( (v14 & 1) != 0 ) /*0x10689e93d*/
      operator delete(a1: v15); /*0x10689e943*/
    *(_BYTE *)(*((_QWORD *)this + 2824) + 4322LL) = 1; /*0x10689e94f*/
    if ( (_BYTE)`guard variable for'RBX::Network::ServerReplicator::installRemotePlayer(void)::proftoken1799 == 0 /*0x10689eaf3*/
      && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::ServerReplicator::installRemotePlayer(void)::proftoken1799) != 0 )
    {
      v12[0] = "ent has no layout"; /*0x10689eb1c*/
      Token = RBX::Profiler::getToken( /*0x10689eb40*/
                this: (RBX::Profiler *)&aFlogDynamicfas_106[-637998],
                a2: &aFlogStudioplug_201[-892865],
                a3: (const char *)0xFFFFFFFFLL,
                a4: 255,
                a5: v10);
      RBX::Profiler::PerFrameTelemetry::activateForTelemetry(a1: Token); /*0x10689eb46*/
      RBX::Network::ServerReplicator::installRemotePlayer(void)::proftoken1799 = Token; /*0x10689eb4b*/
      __cxa_guard_release(a1: &`guard variable for'RBX::Network::ServerReplicator::installRemotePlayer(void)::proftoken1799); /*0x10689eb59*/
    }
    v3 = RBX::Network::ServerReplicator::installRemotePlayer(void)::proftoken1799; /*0x10689e964*/
    *(_OWORD *)v12 = 0; /*0x10689e975*/
    v12[3] = -1; /*0x10689e978*/
    memset(&v12[4], 0, 52); /*0x10689e980*/
    *(_OWORD *)&v12[11] = 0; /*0x10689e993*/
    v12[2] = RBX::Network::ServerReplicator::installRemotePlayer(void)::proftoken1799; /*0x10689e997*/
    RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v12); /*0x10689e99b*/
    v12[3] = RBX::Profiler::PerFrameTelemetry::enterTelemetryRegion(a1: v3, a2: v13, a3: 1); /*0x10689e9b4*/
    RBX::Instance::setParent(this: *((RBX::Instance **)this + 2824), a2: *((RBX::Instance **)this + 1808)); /*0x10689e9c6*/
    RBX::Profiler::TelemetryScope::~TelemetryScope(this: (RBX::Profiler::TelemetryScope *)v12); /*0x10689e9d2*/
    if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x10689e9f0*/
      FLog::FastLog( /*0x10689ea04*/
        a1: FLog::Network,
        a2: qword_10D7BBAA8,
        a3: "[FLog::Network] ServerReplicator:InstallRemotePlayer - LoadCharacter",
        0);
    *((_BYTE *)this + 22641) = 1; /*0x10689ea09*/
    RBX::Network::Replicator::addReplicatorState(this, a2: 16); /*0x10689ea18*/
    if ( DFFlag::DebugNetworkProfiler == 1 )
    {
      v4 = *((_QWORD *)this + 1945); /*0x10689ea2d*/
      v5 = *((_QWORD *)this + 2824); /*0x10689ea34*/
      v7 = v5 != 0
        && (FFlag::MigrateUserIdAccessors != 1
          ? (UserID = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v5 + 176)))
          : (UserID = *(_QWORD *)(v5 + 208)),
            UserID > 0)
        && (__int64)(UserID % 0x2710uLL) < DFInt::DebugNetworkProfilerSamplingHundredthsPercentage;
      v8 = v7 || (v4 & 0x2000000000000000LL) != 0; /*0x10689eaa6*/
      *((_BYTE *)this + 15568) = v8; /*0x10689eaaa*/
      if ( v8 && DFFlag::DebugNetworkProfilerRakPeer == 1 ) /*0x10689eabd*/
      {
        v9 = *((_QWORD *)this + 35); /*0x10689eabf*/
        if ( v9 != 0 ) /*0x10689eac9*/
          (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v9 + 24LL))(a1: v9, a2: *((unsigned int *)this + 4072)); /*0x10689ead4*/
      }
    }
  }
}

// Address: 0x10689eba0 | Name: __ZNK3RBX7Network16ServerReplicator11sendSFFlagsEv
__int64 __fastcall RBX::Network::ServerReplicator::sendSFFlags(RBX::Network::ServerReplicator *this)
{
  RBX::Network *v2; // rdi
  char v3; // al
  RBX::Network::NetworkStream *v4; // rcx
  std::__shared_weak_count *v5; // r14
  __int64 result; // rax
  std::__shared_weak_count *v7; // rbx
  _BYTE v8[48]; // [rsp+10h] [rbp-70h] BYREF
  _QWORD v9[2]; // [rsp+40h] [rbp-40h] BYREF
  _QWORD v10[2]; // [rsp+50h] [rbp-30h] BYREF
  RBX::Network::NetworkStream *v11; // [rsp+60h] [rbp-20h] BYREF
  std::__shared_weak_count *v12; // [rsp+68h] [rbp-18h]

  RBX::make_shared<RBX::Network::NetworkStream>(a1: &v11); /*0x10689ebb5*/
  v8[0] = -109; /*0x10689ebc1*/
  RBX::Network::NetworkStream::writeBytes(this: v11, a2: v8, a3: 1u); /*0x10689ebc9*/
  v8[0] = 0; /*0x10689ebd6*/
  RBX::Network::NetworkStream::writeBytes(this: v11, a2: v8, a3: 1u); /*0x10689ebde*/
  (*(void (__fastcall **)(RBX::Network::ServerReplicator *, RBX::Network::NetworkStream *))(*(_QWORD *)this + 1360LL))( /*0x10689ebed*/
    a1: this,
    a2: v11);
  v3 = RBX::Network::flagsSendsGoThroughConnection(this: v2); /*0x10689ebf3*/
  v4 = v11; /*0x10689ebf8*/
  if ( v3 != 0 ) /*0x10689ebfe*/
  {
    v9[0] = v11; /*0x10689ec00*/
    v5 = v12; /*0x10689ec04*/
    v9[1] = v12; /*0x10689ec08*/
    if ( v12 != nullptr ) /*0x10689ec0f*/
      _InterlockedIncrement64((volatile signed __int64 *)v12 + 1); /*0x10689ec11*/
    result = RBX::Network::ServerReplicator::safeSend(a1: this, a2: v9, a3: 1, a4: v4); /*0x10689ec22*/
  }
  else
  {
    v10[0] = v11; /*0x10689ec29*/
    v5 = v12; /*0x10689ec2d*/
    v10[1] = v12; /*0x10689ec31*/
    if ( v12 != nullptr ) /*0x10689ec38*/
      _InterlockedIncrement64((volatile signed __int64 *)v12 + 1); /*0x10689ec3a*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x10689ec4a*/
      this: (RakNet::AddressOrGUID *)v8,
      a2: (RBX::Network::ServerReplicator *)((char *)this + 240));
    result = RBX::Network::ServerReplicator::safeSend_deprecated( /*0x10689ec6e*/
               a1: (_DWORD)this,
               a2: (unsigned int)v10,
               a3: 2,
               a4: 3,
               a5: 0,
               a6: (unsigned int)v8,
               a7: 0);
  }
  if ( v5 != nullptr ) /*0x10689ec76*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v5 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x10689ec7f*/
    if ( result == 0 ) /*0x10689ec88*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x10689ec90*/
      result = std::__shared_weak_count::__release_weak(this: v5); /*0x10689ec96*/
    }
  }
  v7 = v12; /*0x10689ec9b*/
  if ( v12 != nullptr ) /*0x10689eca2*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v12 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x10689ecab*/
    if ( result == 0 ) /*0x10689ecb4*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x10689ecbc*/
      return std::__shared_weak_count::__release_weak(this: v7); /*0x10689ecc2*/
    }
  }
  return result; /*0x10689ecc7*/
}

// Address: 0x10689ed44 | Name: __ZNK3RBX7Network16ServerReplicator8safeSendENSt3__110shared_ptrINS0_13NetworkStreamEEENS_11NetworkBase7ChannelE
bool __fastcall RBX::Network::ServerReplicator::safeSend(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rbx
  __int64 v4; // rax
  std::__shared_weak_count *v5; // r14
  std::__shared_weak_count *v7[2]; // [rsp+0h] [rbp-20h] BYREF

  v3 = *(_QWORD *)(a1 + 280); /*0x10689ed4f*/
  if ( v3 != 0 ) /*0x10689ed59*/
  {
    v4 = *(_QWORD *)(a2 + 8); /*0x10689ed5b*/
    *(_OWORD *)v7 = *(_OWORD *)a2; /*0x10689ed62*/
    if ( v4 != 0 ) /*0x10689ed69*/
      _InterlockedIncrement64((volatile signed __int64 *)(v4 + 8)); /*0x10689ed6b*/
    (*(void (__fastcall **)(__int64, _QWORD, std::__shared_weak_count **, _QWORD, _QWORD))(*(_QWORD *)v3 + 48LL))( /*0x10689ed84*/
      a1: v3,
      a2: a3,
      a3: v7,
      a4: 0,
      a5: 0);
    v5 = v7[1]; /*0x10689ed88*/
    if ( v7[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v7[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689eda1*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x10689eda9*/
      std::__shared_weak_count::__release_weak(this: v5); /*0x10689edaf*/
    }
  }
  return v3 != 0; /*0x10689edba*/
}

// Address: 0x10689edd8 | Name: __ZNK3RBX7Network16ServerReplicator19safeSend_deprecatedENSt3__110shared_ptrIKNS0_13NetworkStreamEEE14PacketPriority17PacketReliabilitycN6RakNet13AddressOrGUIDEb
bool __fastcall RBX::Network::ServerReplicator::safeSend_deprecated(
        __int64 a1,
        __int64 a2,
        int a3,
        int a4,
        char a5,
        __int64 a6,
        unsigned __int8 a7)
{
  __int64 v7; // rbx
  __int64 v8; // rdi
  std::__shared_weak_count *v9; // r14
  std::__shared_weak_count *v11[2]; // [rsp+40h] [rbp-20h] BYREF

  v7 = *(_QWORD *)(a1 + 224); /*0x10689ede3*/
  if ( v7 != 0 ) /*0x10689eded*/
  {
    v8 = *(_QWORD *)(a2 + 8); /*0x10689edf2*/
    *(_OWORD *)v11 = *(_OWORD *)a2; /*0x10689edf9*/
    if ( v8 != 0 ) /*0x10689ee00*/
      _InterlockedIncrement64((volatile signed __int64 *)(v8 + 8)); /*0x10689ee02*/
    RBX::Network::ConcurrentRakPeer::Send_deprecated( /*0x10689ee3d*/
      a1: v7,
      a2: (unsigned int)v11,
      a3,
      a4,
      a5,
      a6: a7,
      a7: *(_OWORD *)(a6 + 16),
      a8: *(_QWORD *)(a6 + 24),
      a9: *(_OWORD *)(a6 + 32),
      a10: *(_QWORD *)(a6 + 40),
      a11: 0,
      a12: 1,
      a13: 0);
    v9 = v11[1]; /*0x10689ee42*/
    if ( v11[1] != nullptr /*0x10689ee5b*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v11[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x10689ee63*/
      std::__shared_weak_count::__release_weak(this: v9); /*0x10689ee69*/
    }
  }
  return v7 != 0; /*0x10689ee74*/
}

// Address: 0x10689ee92 | Name: __ZN3RBX7Network16ServerReplicator27sendNetworkSchemaDefinitionEv
void __fastcall RBX::Network::ServerReplicator::sendNetworkSchemaDefinition(const RBX::Network::NetworkSchema **this)
{
  __int64 v2; // r14
  __int64 v3; // r14
  _QWORD **v4; // r14
  RBX::Network *v5; // rdi
  std::__shared_weak_count *v6; // r15
  int v7; // r13d
  int v8; // r12d
  int v9; // eax
  int v10; // r15d
  unsigned int i; // ebx
  int v12; // r13d
  __int64 v13; // rax
  __int64 v14; // r13
  char *v15; // rsi
  volatile signed __int64 *v16; // rdx
  int v17; // r8d
  int v18; // r9d
  char *v19; // rcx
  char v20; // al
  __int64 v21; // rcx
  volatile signed __int64 *v22; // r14
  unsigned __int8 v23; // r8
  _QWORD v24[13]; // [rsp+10h] [rbp-100h] BYREF
  _QWORD v25[2]; // [rsp+78h] [rbp-98h] BYREF
  _QWORD v26[2]; // [rsp+88h] [rbp-88h] BYREF
  const RBX::Network::NetworkSchema **v27; // [rsp+98h] [rbp-78h]
  __int64 v28; // [rsp+A0h] [rbp-70h] BYREF
  volatile signed __int64 *v29; // [rsp+A8h] [rbp-68h]
  void *v30; // [rsp+B0h] [rbp-60h]
  _QWORD v31[2]; // [rsp+D0h] [rbp-40h] BYREF
  void *v32; // [rsp+E0h] [rbp-30h]

  if ( (_BYTE)`guard variable for'RBX::Network::ServerReplicator::sendNetworkSchemaDefinition(void)::proftoken1862 == 0 /*0x10689f230*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::ServerReplicator::sendNetworkSchemaDefinition(void)::proftoken1862) != 0 )
  {
    v24[0] = "t_privacy"; /*0x10689f259*/
    RBX::Network::ServerReplicator::sendNetworkSchemaDefinition(void)::proftoken1862 = RBX::Profiler::getToken( /*0x10689f27d*/
                                                                                         this: (RBX::Profiler *)&aConnectionOnco_0[-550806],
                                                                                         a2: &aCanaryClientPr[-156381],
                                                                                         a3: (const char *)0xFFFFFFFFLL,
                                                                                         a4: 255,
                                                                                         a5: v23);
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::ServerReplicator::sendNetworkSchemaDefinition(void)::proftoken1862); /*0x10689f28b*/
  }
  v2 = RBX::Network::ServerReplicator::sendNetworkSchemaDefinition(void)::proftoken1862; /*0x10689eeb7*/
  *(_OWORD *)v24 = 0; /*0x10689eec8*/
  v24[3] = -1; /*0x10689eecc*/
  memset(&v24[4], 0, 52); /*0x10689eed4*/
  *(_OWORD *)&v24[11] = 0; /*0x10689eeeb*/
  v24[2] = RBX::Network::ServerReplicator::sendNetworkSchemaDefinition(void)::proftoken1862; /*0x10689eef0*/
  RBX::Profiler::ActiveRegion::enter(this: (RBX::Profiler::ActiveRegion *)v24); /*0x10689eef7*/
  v24[3] = RBX::Profiler::enterRegion(a1: v2, a2: -1, a3: 0); /*0x10689ef0d*/
  RBX::Network::Replicator::addReplicatorState((RBX::Network::Replicator *)this, a2: 2); /*0x10689ef19*/
  v3 = (__int64)*(this + 2828); /*0x10689ef1e*/
  v31[0] = *(_QWORD *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (const RBX::Network::NetworkSchema *)((char *)*(this + 1801) + 1608)); /*0x10689ef3d*/
  RBX::Network::Server::getNetworkSchemaInfo(a1: &v28, a2: v3); /*0x10689ef47*/
  v4 = (_QWORD **)(this + 2753); /*0x10689ef4c*/
  std::shared_ptr<RBX::Network::ServerSchemaInfo const>::operator=[abi:ne200100](a1: this + 2753, a2: &v28); /*0x10689ef5d*/
  v6 = (std::__shared_weak_count *)v29; /*0x10689ef62*/
  if ( v29 != nullptr && _InterlockedExchangeAdd64(v29 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689ef7b*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x10689ef83*/
    std::__shared_weak_count::__release_weak(this: v6); /*0x10689ef89*/
  }
  if ( (FFlag::LatencyLogging1 != 0 || FFlag::NLSMAddLatencyMetrics == 1)
    && DFFlag::NLSMDumpNetworkSchema == 1
    && *((_BYTE *)*(this + 2828) + 5065) == 0 )
  {
    v7 = DFLog::RCCNetLatency; /*0x10689efd2*/
    if ( (unsigned __int8)DFLog::RCCNetLatency >= 6u && BYTE1(DFLog::RCCNetLatency) >= 3u )
    {
      v8 = qword_10D816198; /*0x10689eff2*/
      v9 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)**v4 + 24LL))(a1: **v4); /*0x10689efff*/
      FLog::FastLogFormatted(
        a1: v7,
        a2: v8,
        a3: (unsigned int)"[DFLog::RCCNetLatency] %s: bytes: %u, id: %u elapsedMs: %u",
        a4: (unsigned int)"ServerReplicator::sendNetworkSchemaDefinition",
        a5: v9,
        a6: 151);
    }
    v27 = this; /*0x10689f02d*/
    v10 = 0; /*0x10689f037*/
    for ( i = 0; i < (*(unsigned int (__fastcall **)(_QWORD))(*(_QWORD *)**v4 + 24LL))(a1: **v4); i += 400 )
    {
      v12 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)**v4 + 24LL))(a1: **v4); /*0x10689f05c*/
      v13 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)**v4 + 16LL))(a1: **v4); /*0x10689f068*/
      v14 = (unsigned int)(v10 + v12); /*0x10689f06b*/
      if ( (unsigned int)v14 >= 0x190 ) /*0x10689f071*/
        v14 = 400; /*0x10689f071*/
      std::string::basic_string[abi:ne200100](a1: &v28, a2: i + v13, a3: v14); /*0x10689f084*/
      if ( (v28 & 1) != 0 ) /*0x10689f090*/
      {
        v15 = (char *)v30; /*0x10689f092*/
        v16 = v29; /*0x10689f096*/
      }
      else
      {
        v16 = (volatile signed __int64 *)((unsigned __int8)v28 >> 1); /*0x10689f09c*/
        v15 = (char *)&v28 + 1; /*0x10689f09e*/
      }
      RBX::Crypto::convertToHex(a1: v31, a2: v15, a3: v16, a4: 0); /*0x10689f0a8*/
      if ( (unsigned __int8)DFLog::RCCNetLatency >= 6u && BYTE1(DFLog::RCCNetLatency) >= 3u )
      {
        v19 = (char *)v31 + 1; /*0x10689f0d0*/
        if ( (v31[0] & 1) != 0 ) /*0x10689f0d4*/
          LODWORD(v19) = (_DWORD)v32; /*0x10689f0d6*/
        FLog::FastLogFormatted(
          a1: DFLog::RCCNetLatency,
          a2: qword_10D816198,
          a3: (unsigned int)"[DFLog::RCCNetLatency] Buffer: %s",
          a4: (_DWORD)v19,
          a5: v17,
          a6: v18);
      }
      if ( (v31[0] & 1) != 0 ) /*0x10689f0f7*/
        operator delete(a1: v32); /*0x10689f0fd*/
      if ( (v28 & 1) != 0 ) /*0x10689f106*/
        operator delete(a1: v30); /*0x10689f10c*/
      v10 -= 400; /*0x10689f111*/
    }
    this = v27; /*0x10689f123*/
    *((_BYTE *)v27[2828] + 5065) = 1; /*0x10689f12e*/
  }
  v20 = RBX::Network::flagsSendsGoThroughConnection(this: v5); /*0x10689f135*/
  v21 = (__int64)*v4; /*0x10689f13a*/
  if ( v20 != 0 ) /*0x10689f142*/
  {
    v25[0] = **v4; /*0x10689f144*/
    v22 = *(volatile signed __int64 **)(v21 + 8); /*0x10689f14b*/
    v25[1] = v22; /*0x10689f14f*/
    if ( v22 != nullptr ) /*0x10689f159*/
      _InterlockedIncrement64(v22 + 1); /*0x10689f15b*/
    RBX::Network::ServerReplicator::safeSend(a1: (__int64)this, a2: (__int64)v25, a3: 1u); /*0x10689f16f*/
  }
  else
  {
    v26[0] = **v4; /*0x10689f176*/
    v22 = *(volatile signed __int64 **)(v21 + 8); /*0x10689f17d*/
    v26[1] = v22; /*0x10689f181*/
    if ( v22 != nullptr ) /*0x10689f188*/
      _InterlockedIncrement64(v22 + 1); /*0x10689f18a*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x10689f19a*/
      this: (RakNet::AddressOrGUID *)&v28,
      a2: (const RakNet::SystemAddress *)(this + 30));
    RBX::Network::ServerReplicator::safeSend_deprecated( /*0x10689f1c1*/
      a1: (__int64)this,
      a2: (__int64)v26,
      a3: 2,
      a4: 3,
      a5: 0,
      a6: (__int64)&v28,
      a7: 0);
  }
  if ( v22 != nullptr && _InterlockedExchangeAdd64(v22 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10689f1db*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v22 + 16))(a1: v22); /*0x10689f1e3*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v22); /*0x10689f1e9*/
  }
  RBX::Network::TwoWayBandwidthMetrics::setSchema( /*0x10689f1ff*/
    this: (RBX::Network::TwoWayBandwidthMetrics *)(this + 36),
    a2: *(this + 1560));
  RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)v24); /*0x10689f20b*/
}

// Address: 0x10689f35a | Name: __ZN3RBX7Network16ServerReplicator28reportGameLoadDataStatisticsEb
__int64 __fastcall RBX::Network::ServerReplicator::reportGameLoadDataStatistics(
        RBX::Network::ServerReplicator *this,
        unsigned __int8 a2)
{
  RBX::Network::ConcurrentRakPeer *v3; // rdi
  __int64 v5; // rax
  RBX::Instance *v6; // rsi
  int v7; // r15d
  __int64 v8; // r12
  int v9; // r13d
  __int64 v10; // rax
  double v11; // xmm0_8
  __int64 v12; // r15
  unsigned int v13; // r14d
  double v14; // xmm0_8
  RBX *v15; // rdi
  __int64 v16; // rdx
  __int64 v17; // rcx
  _BYTE v19[32]; // [rsp+0h] [rbp-2B0h] BYREF
  __int64 v20; // [rsp+20h] [rbp-290h]
  __int64 v21; // [rsp+28h] [rbp-288h]
  __int64 v22; // [rsp+30h] [rbp-280h]
  __int64 v23; // [rsp+38h] [rbp-278h]
  int v24; // [rsp+40h] [rbp-270h]
  int v25; // [rsp+44h] [rbp-26Ch]
  unsigned int v26; // [rsp+48h] [rbp-268h]
  unsigned int v27; // [rsp+4Ch] [rbp-264h]
  unsigned int v28; // [rsp+50h] [rbp-260h]
  _BYTE v29[16]; // [rsp+58h] [rbp-258h] BYREF
  void *v30; // [rsp+68h] [rbp-248h]
  double v31; // [rsp+70h] [rbp-240h]
  double v32; // [rsp+78h] [rbp-238h]
  __int128 v33; // [rsp+80h] [rbp-230h] BYREF
  __int64 v34; // [rsp+90h] [rbp-220h]
  double v35; // [rsp+A0h] [rbp-210h]
  void *v36[59]; // [rsp+A8h] [rbp-208h] BYREF

  *((_BYTE *)this + 22992) = 1; /*0x10689f37f*/
  v3 = *((RBX::Network::ConcurrentRakPeer **)this + 28); /*0x10689f386*/
  if ( v3 != nullptr && RBX::Network::ConcurrentRakPeer::rawPeer(this: v3) != 0 ) /*0x10689f3a0*/
  {
    v5 = RBX::Network::ConcurrentRakPeer::rawPeer(this: *((RBX::Network::ConcurrentRakPeer **)this + 28)); /*0x10689f3ad*/
    if ( (*(unsigned __int8 (__fastcall **)(__int64, char *, _BYTE *, _QWORD))(*(_QWORD *)v5 + 600LL))( /*0x10689f3d4*/
           a1: v5,
           a2: (char *)this + 240,
           a3: v19,
           a4: a2) != 0 )
    {
      v33 = 0; /*0x10689f3de*/
      v34 = 0; /*0x10689f3e6*/
      v7 = v20; /*0x10689f3f1*/
      if ( v20 != 0 ) /*0x10689f3fb*/
      {
        v8 = v22 + (unsigned int)(4 * v24); /*0x10689f40c*/
        if ( v8 != 0 ) /*0x10689f413*/
        {
          v35 = (double)(int)v21; /*0x10689f425*/
          v9 = v23 + 4 * v25; /*0x10689f438*/
          v10 = RBX::DataModel::get(this, a2: v6); /*0x10689f442*/
          v11 = (double)v7; /*0x10689f44a*/
          v12 = *(_QWORD *)(v10 + 840); /*0x10689f44f*/
          RBX::Network::addGameLoadStat(a1: &v33, a2: "GameLoadDataStatistics_RakNetSent", a3: v12, a4: a2, a5: v11); /*0x10689f469*/
          RBX::Network::addGameLoadStat( /*0x10689f489*/
            a1: &v33,
            a2: "GameLoadDataStatistics_SocketSentTotal",
            a3: v12,
            a4: a2,
            a5: v35);
          RBX::Network::addGameLoadStat( /*0x10689f4b2*/
            a1: &v33,
            a2: "GameLoadDataStatistics_ResentRatio",
            a3: v12,
            a4: a2,
            a5: (double)v9 / (double)(int)v8);
          v13 = v28 + v27; /*0x10689f4ca*/
          v35 = (double)(int)(v28 + v27); /*0x10689f4d5*/
          v14 = (double)(int)v26; /*0x10689f4e0*/
          v32 = 0.0; /*0x10689f4e9*/
          v31 = 0.0; /*0x10689f4f1*/
          if ( v26 != 0 ) /*0x10689f4fb*/
            v31 = v35 / v14; /*0x10689f509*/
          if ( v13 != 0 ) /*0x10689f514*/
            v32 = (double)(int)v28 / v35; /*0x10689f526*/
          RBX::Network::addGameLoadStat( /*0x10689f541*/
            a1: &v33,
            a2: "GameLoadDataStatistics_InternalSentCount",
            a3: v12,
            a4: a2,
            a5: v14);
          RBX::Network::addGameLoadStat( /*0x10689f561*/
            a1: &v33,
            a2: "GameLoadDataStatistics_InternalResentCount",
            a3: v12,
            a4: a2,
            a5: v35);
          RBX::Network::addGameLoadStat( /*0x10689f587*/
            a1: &v33,
            a2: "GameLoadDataStatistics_InternalNakCount",
            a3: v12,
            a4: a2,
            a5: (double)(int)v27);
          RBX::Network::addGameLoadStat( /*0x10689f5ad*/
            a1: &v33,
            a2: "GameLoadDataStatistics_InternalTimeoutCount",
            a3: v12,
            a4: a2,
            a5: (double)(int)v28);
          RBX::Network::addGameLoadStat( /*0x10689f5cd*/
            a1: &v33,
            a2: "GameLoadDataStatistics_InternalResentRatio",
            a3: v12,
            a4: a2,
            a5: v31);
          RBX::Network::addGameLoadStat( /*0x10689f5ed*/
            a1: &v33,
            a2: "GameLoadDataStatistics_InternalTimeoutResentRatio",
            a3: v12,
            a4: a2,
            a5: v32);
          if ( (unsigned int)RBX::globalRand(this: v15) % 0x2710 < DFInt::RCCJoinTransmissionStatsHundredthsPercentage ) /*0x10689f614*/
          {
            RBX::Analytics::InfluxDb::Points::Points(a1: v36, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x10689f62a*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x10689f643*/
              this: (RBX::Analytics::InfluxDb::Points *)v36,
              a2: "InternalSentCount",
              a3: v26);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x10689f659*/
              this: (RBX::Analytics::InfluxDb::Points *)v36,
              a2: "InternalResentCount",
              a3: v13);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x10689f672*/
              this: (RBX::Analytics::InfluxDb::Points *)v36,
              a2: "InternalNakCount",
              a3: v27);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x10689f68b*/
              this: (RBX::Analytics::InfluxDb::Points *)v36,
              a2: "InternalTimeoutCount",
              a3: v28);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x10689f6a6*/
              this: (RBX::Analytics::InfluxDb::Points *)v36,
              a2: "InternalResentRatio",
              a3: v31);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x10689f6c1*/
              this: (RBX::Analytics::InfluxDb::Points *)v36,
              a2: "InternalTimeoutResentRatio",
              a3: v32);
            std::string::basic_string[abi:ne200100]<0>(a1: v29, a2: "RCCJoinTransmissionStats", a3: v16, a4: v17); /*0x10689f6d4*/
            RBX::Analytics::InfluxDb::Points::report(a1: v36, a2: v29, a3: 10000, a4: 0); /*0x10689f6ee*/
            if ( (v29[0] & 1) != 0 ) /*0x10689f6fa*/
              operator delete(a1: v30); /*0x10689f703*/
            RBX::Analytics::InfluxDb::Points::~Points(this: v36); /*0x10689f70f*/
          }
          RBX::Analytics::EphemeralCounter::bulkReportStats(a1: &v33, a2: 0); /*0x10689f71d*/
        }
      }
      v36[0] = &v33; /*0x10689f730*/
      std::vector<std::pair<std::string,double>>::__destroy_vector::operator()[abi:ne200100](a1: v36); /*0x10689f733*/
    }
  }
  return __stack_chk_guard; /*0x10689f748*/
}

// Address: 0x10689fa9e | Name: __ZN3RBX7Network16ServerReplicator28updateConnectionAcceptedTimeEv
__int64 __fastcall RBX::Network::ServerReplicator::updateConnectionAcceptedTime(RBX::Network::ServerReplicator *this)
{
  __int64 result; // rax
  __int64 v3; // xmm0_8

  result = RBX::Time::nowFast(this); /*0x10689faa7*/
  *((_QWORD *)this + 2843) = v3; /*0x10689faac*/
  return result; /*0x10689fab8*/
}

// Address: 0x10689fabc | Name: __ZN3RBX7Network16ServerReplicator24processAckPacketServerV2ENS0_14IncomingPacketE
__int64 __fastcall RBX::Network::ServerReplicator::processAckPacketServerV2(
        __int64 a1,
        RBX::Network::IncomingPacket *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  unsigned __int8 *v8; // r15
  unsigned int v9; // eax
  __int128 v10; // xmm0
  _BYTE v12[68]; // [rsp+8h] [rbp-F8h] BYREF
  unsigned int v13; // [rsp+4Ch] [rbp-B4h] BYREF
  _QWORD v14[5]; // [rsp+50h] [rbp-B0h] BYREF
  _BYTE v15[8]; // [rsp+78h] [rbp-88h] BYREF
  _BYTE v16[96]; // [rsp+80h] [rbp-80h] BYREF

  if ( DFFlag::GameLoadDataStatistics == 1 && *(_BYTE *)(a1 + 22992) == 0 && *(_DWORD *)(a1 + 18724) != -1 ) /*0x10689fb04*/
  {
    v8 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: a2); /*0x10689fb12*/
    v9 = RBX::Network::IncomingPacket::size(this: a2); /*0x10689fb18*/
    RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v12, a2: v8, a3: v9, a4: false); /*0x10689fb2b*/
    RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v12, a2: 1u); /*0x10689fb3c*/
    RBX::Network::NetworkStream::readBytes(this: (RBX::Network::NetworkStream *)v12, a2: &v13, a3: 4u); /*0x10689fb54*/
    if ( RBX::Network::Replicator::getCheckAndClearSpecialStatsReceipt(this: (RBX::Network::Replicator *)a1, a2: &v13) ) /*0x10689fb63*/
    {
      RBX::Network::ServerReplicator::reportGameLoadDataStatistics(this: (RBX::Network::ServerReplicator *)a1, a2: 0); /*0x10689fb71*/
      RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v12); /*0x10689fb7d*/
      return __stack_chk_guard; /*0x10689fb82*/
    }
    RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v12); /*0x10689fb8b*/
  }
  v14[4] = *((_QWORD *)a2 + 4); /*0x10689fb9b*/
  v10 = *(_OWORD *)a2; /*0x10689fb9f*/
  *(_OWORD *)&v14[2] = *((_OWORD *)a2 + 1); /*0x10689fba8*/
  *(_OWORD *)v14 = v10; /*0x10689fbac*/
  std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x10689fbb7*/
    a1: v15,
    a2: (char *)a2 + 40,
    a3,
    a4,
    a5,
    a6);
  RBX::Network::Replicator::processAckPacketV2(a1, a2: (RBX::Network::IncomingPacket *)v14); /*0x10689fbc6*/
  if ( v16[88] == 1 ) /*0x10689fbcf*/
    RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v16); /*0x10689fbd5*/
  return __stack_chk_guard; /*0x10689fbea*/
}

// Address: 0x10689fc2e | Name: __ZN3RBX7Network16ServerReplicator33processAckPacketServer_deprecatedEPN6RakNet6PacketE
void __fastcall RBX::Network::ServerReplicator::processAckPacketServer_deprecated(
        RBX::Network::ServerReplicator *this,
        __int64 a2)
{
  _BYTE v4[68]; // [rsp+0h] [rbp-60h] BYREF
  unsigned int v5[7]; // [rsp+44h] [rbp-1Ch] BYREF

  if ( DFFlag::GameLoadDataStatistics == 1 && *((_BYTE *)this + 22992) == 0 && *((_DWORD *)this + 4681) != -1 ) /*0x10689fc5d*/
  {
    RBX::Network::NetworkStream::NetworkStream( /*0x10689fc70*/
      this: (RBX::Network::NetworkStream *)v4,
      a2: *(unsigned __int8 **)(a2 + 56),
      a3: *(_DWORD *)(a2 + 48),
      a4: false);
    RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v4, a2: 1u); /*0x10689fc7d*/
    RBX::Network::NetworkStream::readBytes(this: (RBX::Network::NetworkStream *)v4, a2: v5, a3: 4u); /*0x10689fc8f*/
    if ( RBX::Network::Replicator::getCheckAndClearSpecialStatsReceipt(this, a2: v5) ) /*0x10689fc9b*/
    {
      RBX::Network::ServerReplicator::reportGameLoadDataStatistics(this, a2: 0); /*0x10689fca9*/
      RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v4); /*0x10689fcb2*/
      return; /*0x10689fcb7*/
    }
    RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v4); /*0x10689fcbd*/
  }
  RBX::Network::Replicator::processAckPacket_deprecated(a1: (__int64)this, a2); /*0x10689fcc8*/
}

// Address: 0x10689fcec | Name: __ZN3RBX7Network16ServerReplicator28getAndHandleConnectionEventsEv
__int64 __fastcall RBX::Network::ServerReplicator::getAndHandleConnectionEvents(RBX::Network::ServerReplicator *this)
{
  _DWORD *v1; // r12
  __int64 v2; // rdx
  _DWORD *v3; // r15
  _BYTE v5[24]; // [rsp+10h] [rbp-170h] BYREF
  _BYTE v6[48]; // [rsp+28h] [rbp-158h] BYREF
  RBX::Network::Replicator *v7; // [rsp+58h] [rbp-128h]
  _BYTE v8[32]; // [rsp+60h] [rbp-120h] BYREF
  _QWORD v9[4]; // [rsp+80h] [rbp-100h] BYREF
  _DWORD *v10; // [rsp+A0h] [rbp-E0h] BYREF
  int v11; // [rsp+A8h] [rbp-D8h]
  unsigned int v12; // [rsp+B0h] [rbp-D0h]
  _BYTE v13[136]; // [rsp+B8h] [rbp-C8h] BYREF
  unsigned __int8 v14; // [rsp+140h] [rbp-40h]
  char v15; // [rsp+148h] [rbp-38h]

  v7 = this; /*0x10689fd0e*/
  (*(void (__fastcall **)(_BYTE *))(**((_QWORD **)this + 35) + 152LL))(a1: v6); /*0x10689fd26*/
  while ( 1 ) /*0x10689fd44*/
  {
    RBX::RbxTransport::EventsQueue<RBX::RbxTransport::ConnectionEvent>::getNextEvent(a1: &v10, a2: v6); /*0x10689fd44*/
    if ( v15 == 0 ) /*0x10689fd4d*/
      break; /*0x10689fd4d*/
    if ( (unsigned int)v14 - 5 >= 3 ) /*0x10689fd5d*/
    {
      if ( v14 == 4 ) /*0x10689fdbe*/
      {
        if ( v11 != 0 ) /*0x10689fe40*/
        {
          v1 = v10; /*0x10689fe4f*/
          if ( v12 != 0 ) /*0x10689fe55*/
          {
            v2 = 4LL * v12; /*0x10689fe57*/
            v1 = v10; /*0x10689fe5f*/
            while ( *v1 >= 0xFFFFFFFE ) /*0x10689fe67*/
            {
              ++v1; /*0x10689fe69*/
              v2 -= 4; /*0x10689fe6d*/
              if ( v2 == 0 ) /*0x10689fe71*/
                goto LABEL_17; /*0x10689fe71*/
            }
          }
          v3 = &v10[v12]; /*0x10689fe87*/
          while ( v1 != v3 ) /*0x10689fe8e*/
          {
            (*(void (__fastcall **)(_QWORD *, _QWORD, _QWORD))(**((_QWORD **)v7 + 35) + 168LL))( /*0x10689feaf*/
              a1: v9,
              a2: *((_QWORD *)v7 + 35),
              a3: (unsigned int)*v1);
            RBX::RangeList<unsigned long long>::RangeList(a1: v8, a2: v9); /*0x10689febb*/
            RBX::Network::Replicator::processAckRanges(a1: (__int64)v7, a2: (__int64)v8); /*0x10689feca*/
            RBX::RangeList<unsigned long long>::~RangeList(a1: v8); /*0x10689fed2*/
            RBX::RangeList<unsigned long long>::~RangeList(a1: v9); /*0x10689fede*/
            do /*0x10689fef1*/
              ++v1; /*0x10689fee3*/
            while ( v1 != v3 && *v1 >= 0xFFFFFFFE ); /*0x10689fef1*/
          }
        }
      }
      else if ( v14 == 8 /*0x10689fde0*/
             && (unsigned __int8)DFLog::RbxTransportIntegration >= 6u
             && (DFLog::RbxTransportIntegration & 0xFC00) != 0 )
      {
        v9[0] = 0; /*0x10689fdf6*/
        v9[1] = v5; /*0x10689fe08*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x10689fe32*/
          a1: DFLog::RbxTransportIntegration,
          a2: qword_10D7F15F8,
          a3: 4,
          a4: (unsigned int)"[DFLog::RbxTransportIntegration] Received invalid RbxTransport Connection Event!",
          a5: 80,
          a6: 1,
          0,
          v5);
      }
    }
    else
    {
      RBX::NetworkBase::ConnectionInternal::setDisconnectReason( /*0x10689fd74*/
        this: *((RBX::NetworkBase::ConnectionInternal **)v7 + 35),
        a2: (const RBX::Network::StateReason *)v13);
      if ( DFFlag::UpdateConnectionStateWhenSettingDisconnectReason == 0 /*0x10689fd8f*/
        && DFFlag::FixOverwriteDisconnectReasonInServerStop == 1 )
      {
        _InterlockedExchange((volatile __int32 *)(*((_QWORD *)v7 + 35) + 1412LL), 4); /*0x10689fda4*/
      }
      RBX::Network::Replicator::onRemoteDisconnect(this: (RBX::NetworkBase::ConnectionInternal **)v7); /*0x10689fdb1*/
    }
LABEL_17:
    std::__optional_destruct_base<RBX::RbxTransport::ConnectionEvent,false>::~__optional_destruct_base[abi:ne200100](a1: &v10); /*0x10689fe73*/
  }
  std::__optional_destruct_base<RBX::RbxTransport::ConnectionEvent,false>::~__optional_destruct_base[abi:ne200100](a1: &v10); /*0x10689fefc*/
  std::deque<RBX::RbxTransport::ConnectionEvent>::~deque[abi:ne200100](a1: v6); /*0x10689ff08*/
  return __stack_chk_guard; /*0x10689ff1d*/
}

// Address: 0x10689ff86 | Name: __ZN3RBX7Network16ServerReplicator11OnReceiveV2ENS0_14IncomingPacketE
__int64 __fastcall RBX::Network::ServerReplicator::OnReceiveV2(__int64 a1, __int128 *a2)
{
  unsigned int v4; // r12d
  unsigned __int8 v5; // al
  __int64 v6; // rdx
  __int64 v7; // rcx
  const char *v8; // rsi
  __int64 v9; // r8
  __int64 v10; // r9
  __int64 v11; // rdx
  __int64 v12; // rcx
  __int64 v13; // r8
  __int64 v14; // r9
  __int128 v15; // xmm0
  RBX::RbxTransport::NetStreamBuffer *v16; // rdi
  __int128 v17; // xmm0
  unsigned __int8 *v18; // rbx
  unsigned int v19; // eax
  unsigned __int8 Bool; // bl
  unsigned int Int32; // r12d
  __int128 v22; // xmm0
  unsigned __int8 *v23; // rbx
  unsigned int v24; // eax
  unsigned int PayloadLimit; // eax
  char v26; // al
  unsigned __int64 v27; // rcx
  bool NetAssetCachingEnabled; // al
  __int64 v29; // r13
  __int64 v30; // rbx
  unsigned int v31; // eax
  unsigned __int8 *v32; // rbx
  unsigned int v33; // eax
  int v34; // eax
  unsigned int v35; // ebx
  int v36; // eax
  __int64 v37; // rdx
  __int64 v38; // rcx
  void *v39; // rdi
  __int128 v40; // xmm0
  __int128 v41; // xmm0
  __int64 v42; // rdx
  __int64 v43; // rcx
  __int64 v44; // r8
  __int64 v45; // r9
  __int128 v46; // xmm0
  __int64 v47; // rbx
  unsigned int v48; // eax
  unsigned __int8 *v49; // rbx
  unsigned int v50; // eax
  RBX::Time *v51; // rdi
  RBX::Network::NetworkStream *v52; // rsi
  double v53; // xmm0_8
  unsigned __int8 Byte; // bl
  Luau::BytecodeBuilder *v55; // rdi
  __int64 v56; // rax
  char v57; // al
  __int128 v58; // xmm0
  __int64 v59; // rdx
  __int64 v60; // rcx
  __int64 v61; // rbx
  unsigned int v62; // eax
  unsigned __int8 Version; // al
  unsigned __int8 v64; // cl
  unsigned __int8 v65; // dl
  unsigned __int16 UInt16; // ax
  int i; // ebx
  unsigned int v68; // eax
  unsigned int v69; // eax
  const char *v70; // rsi
  unsigned __int64 v71; // rax
  int v72; // r8d
  int v73; // r9d
  __int64 v74; // rdx
  __int64 v75; // rcx
  char *v76; // rcx
  unsigned int v77; // ebx
  int v78; // r12d
  unsigned __int8 v79; // al
  char v81; // al
  void *v82; // rcx
  __int64 v83; // rsi
  __int64 v84; // rax
  __int64 v85; // rax
  __int64 v86; // rdx
  __int64 v87; // rcx
  __int64 v88; // rcx
  unsigned __int64 v89; // rax
  char *v90; // rdi
  __int64 v91; // rsi
  char *v92; // rdi
  __int64 v93; // rsi
  __int64 v94; // rdx
  __int128 *v95; // rdi
  RBX::Reflection::ValueTable *v96; // rdi
  __int64 v97; // rax
  unsigned int v98; // eax
  RBX::Player *v99; // rdi
  __int64 PlayerGui; // rax
  __int64 v101; // rbx
  __int64 v102; // rdi
  __int64 UserID; // rdx
  __int64 v104; // rcx
  __int64 v105; // rdx
  __int64 v106; // rcx
  void *v107; // rdi
  __int128 v108; // [rsp+10h] [rbp-8C0h] BYREF
  char v109; // [rsp+20h] [rbp-8B0h]
  _BYTE v110[15]; // [rsp+21h] [rbp-8AFh]
  void *v111; // [rsp+30h] [rbp-8A0h]
  __int128 v112; // [rsp+38h] [rbp-898h]
  char v113; // [rsp+48h] [rbp-888h]
  __int128 v114; // [rsp+50h] [rbp-880h] BYREF
  char v115; // [rsp+60h] [rbp-870h]
  void *v116; // [rsp+70h] [rbp-860h]
  char v117; // [rsp+88h] [rbp-848h]
  __int128 v118; // [rsp+90h] [rbp-840h] BYREF
  char v119; // [rsp+A0h] [rbp-830h]
  void *v120; // [rsp+B0h] [rbp-820h]
  char v121; // [rsp+C8h] [rbp-808h]
  __int128 v122; // [rsp+110h] [rbp-7C0h] BYREF
  __int128 v123; // [rsp+120h] [rbp-7B0h]
  void *v124; // [rsp+130h] [rbp-7A0h]
  __int128 v125; // [rsp+138h] [rbp-798h]
  char v126; // [rsp+148h] [rbp-788h]
  __int128 v127; // [rsp+150h] [rbp-780h] BYREF
  _BYTE v128[8]; // [rsp+160h] [rbp-770h] BYREF
  std::__shared_weak_count *v129; // [rsp+168h] [rbp-768h]
  std::__shared_weak_count *v130[2]; // [rsp+170h] [rbp-760h] BYREF
  _BYTE v131[16]; // [rsp+180h] [rbp-750h] BYREF
  __int64 v132; // [rsp+190h] [rbp-740h]
  unsigned int v133; // [rsp+1B0h] [rbp-720h]
  unsigned int v134; // [rsp+1B8h] [rbp-718h]
  __int128 v135; // [rsp+1C0h] [rbp-710h] BYREF
  void *v136; // [rsp+1D0h] [rbp-700h]
  __int128 v137; // [rsp+1E0h] [rbp-6F0h] BYREF
  void *v138[2]; // [rsp+1F0h] [rbp-6E0h]
  _QWORD v139[4]; // [rsp+200h] [rbp-6D0h] BYREF
  unsigned int v140; // [rsp+22Ch] [rbp-6A4h]
  __int128 v141; // [rsp+230h] [rbp-6A0h] BYREF
  void *v142; // [rsp+240h] [rbp-690h]
  unsigned __int8 v143; // [rsp+24Fh] [rbp-681h]
  _QWORD v144[5]; // [rsp+250h] [rbp-680h] BYREF
  _BYTE v145[8]; // [rsp+278h] [rbp-658h] BYREF
  _BYTE v146[96]; // [rsp+280h] [rbp-650h] BYREF
  _QWORD v147[5]; // [rsp+2E0h] [rbp-5F0h] BYREF
  _BYTE v148[8]; // [rsp+308h] [rbp-5C8h] BYREF
  _BYTE v149[96]; // [rsp+310h] [rbp-5C0h] BYREF
  _QWORD v150[5]; // [rsp+370h] [rbp-560h] BYREF
  _BYTE v151[8]; // [rsp+398h] [rbp-538h] BYREF
  _BYTE v152[96]; // [rsp+3A0h] [rbp-530h] BYREF
  _QWORD v153[5]; // [rsp+400h] [rbp-4D0h] BYREF
  _BYTE v154[8]; // [rsp+428h] [rbp-4A8h] BYREF
  _BYTE v155[96]; // [rsp+430h] [rbp-4A0h] BYREF
  _QWORD v156[5]; // [rsp+490h] [rbp-440h] BYREF
  _BYTE v157[8]; // [rsp+4B8h] [rbp-418h] BYREF
  _BYTE v158[96]; // [rsp+4C0h] [rbp-410h] BYREF
  std::__shared_weak_count *v159[2]; // [rsp+520h] [rbp-3B0h] BYREF
  __int128 v160; // [rsp+530h] [rbp-3A0h] BYREF
  unsigned __int64 v161; // [rsp+540h] [rbp-390h]
  __int128 v162; // [rsp+548h] [rbp-388h]
  _BYTE v163[536]; // [rsp+568h] [rbp-368h] BYREF
  _QWORD v164[5]; // [rsp+780h] [rbp-150h] BYREF
  _BYTE v165[8]; // [rsp+7A8h] [rbp-128h] BYREF
  _BYTE v166[96]; // [rsp+7B0h] [rbp-120h] BYREF
  _QWORD v167[5]; // [rsp+810h] [rbp-C0h] BYREF
  _BYTE v168[8]; // [rsp+838h] [rbp-98h] BYREF
  _BYTE v169[96]; // [rsp+840h] [rbp-90h] BYREF

  v140 = RBX::Memory::setCurrentCategory( /*0x10689ffbc*/
           this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkOnReceive,
           (unsigned int)a2);
  v4 = 0; /*0x10689ffc2*/
  v5 = RBX::Network::IncomingPacket::operator[](a1: a2, a2: 0); /*0x10689ffca*/
  if ( v5 > 0x86u )
  {
    switch ( v5 )
    {
      case 0x87u:
      case 0x88u:
      case 0x8Bu:
      case 0x8Cu:
        RBX::LeakyBucket::updateParameters( /*0x1068a0015*/
          this: (RBX::LeakyBucket *)(a1 + 23000),
          a2: (float)DFInt::ChatCap,
          a3: (float)DFInt::ChatTime);
        if ( (unsigned __int8)RBX::LeakyBucket::checkAdd(this: (RBX::LeakyBucket *)(a1 + 23000), a2: 1.0) == 0 ) /*0x1068a002c*/
          goto LABEL_98; /*0x1068a002c*/
        v153[4] = *((_QWORD *)a2 + 4); /*0x1068a003d*/
        v15 = *a2; /*0x1068a0041*/
        *(_OWORD *)&v153[2] = a2[1]; /*0x1068a004a*/
        *(_OWORD *)v153 = v15; /*0x1068a004e*/
        std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1068a0056*/
          a1: v154,
          a2: (char *)a2 + 40,
          a3: v11,
          a4: v12,
          a5: v13,
          a6: v14);
        v4 = RBX::Network::Replicator::OnReceiveV2(a1, a2: (RBX::Network::IncomingPacket *)v153); /*0x1068a006a*/
        if ( v155[88] != 1 ) /*0x1068a0074*/
          goto LABEL_98; /*0x1068a0074*/
        v16 = (RBX::RbxTransport::NetStreamBuffer *)v155; /*0x1068a007a*/
        goto LABEL_69; /*0x1068a0081*/
      case 0x8Du:
        if ( DFFlag::BlockInvalidClusterPacket != 1 /*0x1068a0444*/
          || (*(unsigned __int8 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 936LL))(a1, a2: 0) != 0 )
        {
          v147[4] = *((_QWORD *)a2 + 4); /*0x1068a0455*/
          v40 = *a2; /*0x1068a0459*/
          *(_OWORD *)&v147[2] = a2[1]; /*0x1068a0462*/
          *(_OWORD *)v147 = v40; /*0x1068a0466*/
          std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1068a046e*/
            a1: v148,
            a2: (char *)a2 + 40,
            a3: v6,
            a4: v7,
            a5: v9,
            a6: v10);
          v4 = RBX::Network::Replicator::OnReceiveV2(a1, a2: (RBX::Network::IncomingPacket *)v147); /*0x1068a0482*/
          if ( v149[88] != 1 ) /*0x1068a048c*/
            goto LABEL_98; /*0x1068a048c*/
          v16 = (RBX::RbxTransport::NetStreamBuffer *)v149; /*0x1068a0492*/
          goto LABEL_69; /*0x1068a0499*/
        }
        std::string::basic_string[abi:ne200100]<0>(a1: v159, a2: "TerrainRecvOnGameServer", a3: v6, a4: v7); /*0x1068a0794*/
        std::string::basic_string[abi:ne200100]<0>( /*0x1068a07a7*/
          a1: &v137,
          a2: "Received a Terrain packet from a Client on a GameServer",
          a3: v59,
          a4: v60);
        RBX::Network::Replicator::logPacketErrorV2( /*0x1068a07c3*/
          a1,
          (RBX::Network::IncomingPacket *)a2,
          a3: (unsigned __int8 *)v159,
          a4: (char *)&v137,
          a5: 0);
        if ( (v137 & 1) != 0 ) /*0x1068a07cf*/
          operator delete(a1: v138[0]); /*0x1068a07d8*/
        if ( ((__int64)v159[0] & 1) != 0 ) /*0x1068a07e4*/
          operator delete(a1: (void *)v160); /*0x1068a07ed*/
        v4 = 0; /*0x1068a07f2*/
        LOBYTE(v118) = 0; /*0x1068a07fc*/
        v121 = 0; /*0x1068a07ff*/
        RBX::Network::Replicator::requestDisconnectWithSignal(a1, a2: 0x104u, a3: &v118); /*0x1068a080b*/
        if ( v121 == 1 && (v119 & 1) != 0 ) /*0x1068a0824*/
        {
          v39 = v120; /*0x1068a082a*/
          goto LABEL_36; /*0x1068a0831*/
        }
        goto LABEL_98; /*0x1068a0824*/
      case 0x8Fu:
        v23 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a021f*/
        v24 = RBX::Network::IncomingPacket::size(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a0225*/
        RBX::Network::NetworkStream::NetworkStream( /*0x1068a0238*/
          this: (RBX::Network::NetworkStream *)v159,
          a2: v23,
          a3: v24,
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v159, a2: 1u); /*0x1068a0249*/
        v137 = 0; /*0x1068a0252*/
        v138[0] = nullptr; /*0x1068a025a*/
        PayloadLimit = RBX::Network::Replicator::getReadPayloadLimit(this: (RBX::Network::Replicator *)a1); /*0x1068a0268*/
        RBX::Network::deserializeString(a1: &v137, a2: v159, a3: PayloadLimit); /*0x1068a027d*/
        v26 = v137; /*0x1068a0282*/
        if ( (v137 & 1) != 0 ) /*0x1068a028b*/
          v27 = *((_QWORD *)&v137 + 1); /*0x1068a0291*/
        else
          v27 = (unsigned __int8)v137 >> 1; /*0x1068a066b*/
        if ( v27 <= DFInt::SpawnNameLimit ) /*0x1068a0677*/
        {
          if ( (*(_BYTE *)(a1 + 22720) & 1) != 0 ) /*0x1068a0688*/
            operator delete(a1: *(void **)(a1 + 22736)); /*0x1068a0691*/
          *(void **)(a1 + 22736) = v138[0]; /*0x1068a069d*/
          *(_OWORD *)(a1 + 22720) = v137; /*0x1068a06a9*/
          LOWORD(v137) = 0; /*0x1068a06ad*/
          v26 = 0; /*0x1068a06b6*/
        }
        if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && BYTE1(DFLog::NetworkJoin) >= 3u )
        {
          FLog::FastLogS(
            a1: *(FLog **)&DFLog::NetworkJoin,
            a2: qword_10D7F3E08,
            a3: "[DFLog::NetworkJoin] initialSpawnName: %s",
            a4: a1 + 22720);
          v26 = v137; /*0x1068a06f1*/
        }
        if ( (v26 & 1) != 0 ) /*0x1068a06f9*/
          operator delete(a1: v138[0]); /*0x1068a0706*/
        goto LABEL_96; /*0x1068a070b*/
      case 0x90u:
        memset(v139, 0, 28); /*0x1068a0398*/
        *(_OWORD *)v138 = 0; /*0x1068a03a0*/
        v137 = 0; /*0x1068a03a8*/
        RBX::Network::Replicator::addReplicatorState(this: (RBX::Network::Replicator *)a1, a2: 1); /*0x1068a03b8*/
        if ( *(_BYTE *)(a1 + 22644) == 1 ) /*0x1068a03c5*/
        {
          *(_BYTE *)(a1 + 22645) = 1; /*0x1068a03cb*/
          std::string::basic_string[abi:ne200100]<0>(a1: v159, a2: "AlreadySeen", a3: v37, a4: v38); /*0x1068a03e1*/
          RBX::Network::Replicator::reportServerJoinReject(a1, a2: (__int64)v159); /*0x1068a03f0*/
          if ( ((__int64)v159[0] & 1) != 0 ) /*0x1068a03fc*/
            operator delete(a1: (void *)v160); /*0x1068a0405*/
          if ( (v137 & 1) != 0 ) /*0x1068a0411*/
          {
            v39 = v138[0]; /*0x1068a0417*/
LABEL_36:
            operator delete(a1: v39); /*0x1068a041e*/
          }
          goto LABEL_98; /*0x1068a0423*/
        }
        *(_BYTE *)(a1 + 22644) = 1; /*0x1068a0550*/
        if ( DFFlag::ReportLuauConnIssue == 1 ) /*0x1068a0564*/
        {
          v139[0] = (unsigned int)RBX::Network::IncomingPacket::size(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a0570*/
          v47 = RBX::Network::IncomingPacket::data(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a057f*/
          v48 = RBX::Network::IncomingPacket::size(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a0585*/
          HIDWORD(v139[1]) = XXH32(a1: v47, a2: v48, a3: 1); /*0x1068a0599*/
        }
        v49 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a05a7*/
        v50 = RBX::Network::IncomingPacket::size(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a05ad*/
        RBX::Network::NetworkStream::NetworkStream( /*0x1068a05c0*/
          this: (RBX::Network::NetworkStream *)v131,
          a2: v49,
          a3: v50,
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v131, a2: 1u); /*0x1068a05d1*/
        if ( *(_BYTE *)(a1 + 18600) == 1 ) /*0x1068a05de*/
        {
          RBX::Time::nowFast(this: v51); /*0x1068a05e0*/
          *(double *)(a1 + 18608) = (v53 - *(double *)(a1 + 22744)) * 1000.0; /*0x1068a05f6*/
        }
        if ( *(_BYTE *)(a1 + 10391) == 0 ) /*0x1068a0607*/
          RBX::Network::Peer::decryptDataPart(this: (RBX::Network::Peer *)v131, a2: v52); /*0x1068a0610*/
        Byte = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v131); /*0x1068a0621*/
        *(_DWORD *)(a1 + 22092) = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v131); /*0x1068a062f*/
        v56 = *(_QWORD *)(a1 + 15560); /*0x1068a0636*/
        if ( (v56 & 0x100000) != 0 )
        {
          *(_BYTE *)(a1 + 22676) = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v131); /*0x1068a0867*/
          v57 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v131); /*0x1068a0875*/
        }
        else
        {
          if ( (v56 & 0x800) == 0 )
          {
LABEL_80:
            Version = Luau::BytecodeBuilder::getVersion(this: v55); /*0x1068a0881*/
            v64 = *(_BYTE *)(a1 + 22676); /*0x1068a0886*/
            v65 = *(_BYTE *)(a1 + 22677); /*0x1068a088d*/
            if ( v65 < v64 || Version > v65 || Version < v64 )
            {
              v159[0] = (std::__shared_weak_count *)Version; /*0x1068a09b5*/
              *(_QWORD *)&v160 = v64; /*0x1068a09b8*/
              v161 = v65; /*0x1068a09bc*/
              fmt::v8::vformat(
                a1: &v141,
                a2: "Unsupported Luau version requested: {} not in [{}..{}]",
                a3: 54,
                a4: 546,
                a5: v159);
              v75 = (unsigned int)DFLog::NetworkJoin >> 8; /*0x1068a09e9*/
              LOBYTE(v74) = (unsigned __int8)DFLog::NetworkJoin < 6u; /*0x1068a09f0*/
              LOBYTE(v75) = (unsigned __int8)DFLog::NetworkJoin < 6u || BYTE1(DFLog::NetworkJoin) < 3u; /*0x1068a09f9*/
              if ( (_BYTE)v75 == 0 ) /*0x1068a09fb*/
              {
                if ( (v141 & 1) != 0 ) /*0x1068a0a0c*/
                  LODWORD(v76) = (_DWORD)v142; /*0x1068a0a12*/
                else
                  v76 = (char *)&v141 + 1; /*0x1068a0a9a*/
                FLog::FastLogFormatted( /*0x1068a0aaa*/
                  a1: DFLog::NetworkJoin,
                  a2: qword_10D7F3E08,
                  a3: (unsigned int)"[DFLog::NetworkJoin] %s",
                  a4: (_DWORD)v76,
                  a5: v72,
                  a6: v73);
              }
              std::string::basic_string[abi:ne200100]<0>(a1: v159, a2: "UnsupportedLuauVersion", a3: v74, a4: v75); /*0x1068a0abd*/
              RBX::Network::Replicator::reportServerJoinReject(a1, a2: (__int64)v159); /*0x1068a0acc*/
              if ( ((__int64)v159[0] & 1) != 0 ) /*0x1068a0ad8*/
                operator delete(a1: (void *)v160); /*0x1068a0ae1*/
              v81 = v141; /*0x1068a0ae6*/
              v159[0] = *(std::__shared_weak_count **)((char *)&v141 + 1); /*0x1068a0af3*/
              *(std::__shared_weak_count **)((char *)v159 + 7) = *((std::__shared_weak_count **)&v141 + 1); /*0x1068a0b01*/
              v82 = v142; /*0x1068a0b08*/
              v141 = 0; /*0x1068a0b13*/
              v142 = nullptr; /*0x1068a0b1b*/
              v112 = 0; /*0x1068a0b2d*/
              *(_QWORD *)&v108 = "Security"; /*0x1068a0b39*/
              *((_QWORD *)&v108 + 1) = 8; /*0x1068a0b3c*/
              v109 = v81; /*0x1068a0b44*/
              qmemcpy(v110, v159, sizeof(v110)); /*0x1068a0b55*/
              v111 = v82; /*0x1068a0b5d*/
              v113 = 1; /*0x1068a0b61*/
              RBX::Network::Replicator::requestDisconnectWithSignal(a1, a2: 0x106u, a3: &v108); /*0x1068a0b6d*/
              if ( v113 == 1 && (v109 & 1) != 0 ) /*0x1068a0b82*/
                operator delete(a1: v111); /*0x1068a0b8b*/
              if ( DFFlag::ReportLuauConnIssue == 1 ) /*0x1068a0b95*/
              {
                v138[1] = (void *)(unsigned int)RBX::Network::IncomingPacket::size(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a0ba5*/
                v83 = 100; /*0x1068a0bbc*/
                if ( v133 < 0x64 ) /*0x1068a0bc1*/
                  v83 = v133; /*0x1068a0bc1*/
                LODWORD(v139[1]) = XXH32(a1: v132, a2: v83, a3: 1); /*0x1068a0bce*/
                LOWORD(v139[3]) = *(_WORD *)(a1 + 22676); /*0x1068a0be8*/
                v84 = *(_QWORD *)(a1 + 18520); /*0x1068a0bee*/
                if ( (*(_BYTE *)(v84 + 744) & 1) != 0 ) /*0x1068a0bfc*/
                {
                  std::string::__init_copy_ctor_external( /*0x1068a0c32*/
                    a1: v159,
                    a2: *(_QWORD *)(v84 + 760),
                    a3: *(_QWORD *)(v84 + 752));
                }
                else
                {
                  v85 = v84 + 744; /*0x1068a0bfe*/
                  *(_QWORD *)&v160 = *(_QWORD *)(v85 + 16); /*0x1068a0c08*/
                  *(_OWORD *)v159 = *(_OWORD *)v85; /*0x1068a0c13*/
                }
                if ( (v137 & 1) != 0 ) /*0x1068a0c3e*/
                  operator delete(a1: v138[0]); /*0x1068a0c47*/
                v138[0] = (void *)v160; /*0x1068a0c53*/
                v137 = *(_OWORD *)v159; /*0x1068a0c62*/
                v139[2] = *(_QWORD *)(a1 + 15560); /*0x1068a0c71*/
                WORD1(v139[3]) = RBX::Network::NetworkStream::readUInt16(this: (RBX::Network::NetworkStream *)v131); /*0x1068a0c84*/
                RBX::Network::ReportDebugConnectionIssueMetrics(a1: &v137); /*0x1068a0c92*/
              }
              goto LABEL_178; /*0x1068a0c97*/
            }
            v143 = Byte; /*0x1068a08ac*/
            if ( v134 < v133 ) /*0x1068a08be*/
            {
              UInt16 = RBX::Network::NetworkStream::readUInt16(this: (RBX::Network::NetworkStream *)v131); /*0x1068a08c7*/
              if ( UInt16 != 0 ) /*0x1068a08cf*/
              {
                for ( i = UInt16; i != 0; --i ) /*0x1068a08d1*/
                {
                  *(_OWORD *)v159 = 0; /*0x1068a08e6*/
                  *(_QWORD *)&v160 = 0; /*0x1068a08ee*/
                  v68 = RBX::Network::Replicator::getReadPayloadLimit(this: (RBX::Network::Replicator *)a1); /*0x1068a08fc*/
                  RBX::Network::deserializeString(a1: v159, a2: v131, a3: v68); /*0x1068a090d*/
                  std::__hash_table<std::string,std::hash<std::string>,std::equal_to<std::string>,std::allocator<std::string>>::__emplace_unique_key_args<std::string,std::string const&>( /*0x1068a091b*/
                    a1: a1 + 12496,
                    a2: (unsigned __int8 *)v159,
                    a3: (__int64)v159);
                  if ( ((__int64)v159[0] & 1) != 0 ) /*0x1068a0927*/
                    operator delete(a1: (void *)v160); /*0x1068a0930*/
                }
              }
            }
            *(_BYTE *)(a1 + 12488) = 1; /*0x1068a093b*/
            *(_BYTE *)(a1 + 22584) = 1; /*0x1068a0942*/
            v141 = 0; /*0x1068a094d*/
            v142 = nullptr; /*0x1068a0955*/
            v69 = RBX::Network::Replicator::getReadPayloadLimit(this: (RBX::Network::Replicator *)a1); /*0x1068a0963*/
            RBX::Network::deserializeString(a1: &v141, a2: v131, a3: v69); /*0x1068a0978*/
            if ( DFFlag::JoinInfoCheckLength == 1 )
            {
              if ( (v141 & 1) != 0 ) /*0x1068a0993*/
                v71 = *((_QWORD *)&v141 + 1); /*0x1068a0999*/
              else
                v71 = (unsigned __int8)v141 >> 1; /*0x1068a0c9c*/
              if ( v71 > DFInt::JoinInfoReportingLength ) /*0x1068a0ca8*/
              {
                RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1068a0cbc*/
                  a1: (__int64)v159,
                  a2: (__int64)&RBX::Telemetry::kJoinInfoLengthLimit);
                std::string::basic_string[abi:ne200100]<0>(a1: &v135, a2: "", a3: v86, a4: v87); /*0x1068a0ccf*/
                RBX::Telemetry::FieldsContainer::addPlaceId(this: (RBX::Analytics *)v163); /*0x1068a0ce5*/
                if ( (v135 & 1) != 0 ) /*0x1068a0cf1*/
                  operator delete(a1: v136); /*0x1068a0cfa*/
                if ( (v141 & 1) != 0 ) /*0x1068a0d09*/
                  v88 = *((_QWORD *)&v141 + 1); /*0x1068a0d0b*/
                else
                  v88 = (unsigned __int8)v141 >> 1; /*0x1068a0d14*/
                RBX::Telemetry::FieldsContainer::addField(a1: v163, a2: "JoinInfoLength", a3: 14, a4: v88, a5: 1); /*0x1068a0d2b*/
                RBX::Telemetry::FieldsContainer::addField( /*0x1068a0d4c*/
                  a1: v163,
                  a2: "JoinInfoLengthLimit",
                  a3: 19,
                  a4: DFInt::JoinInfoMaxLength,
                  a5: 1);
                RBX::Telemetry::FieldsContainer::addField( /*0x1068a0d6d*/
                  a1: v163,
                  a2: "JoinInfoReportingLengthLimit",
                  a3: 28,
                  a4: DFInt::JoinInfoReportingLength,
                  a5: 1);
                RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v159); /*0x1068a0d79*/
                RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v159); /*0x1068a0d8c*/
              }
              if ( DFFlag::JoinInfoCheckLengthThrow == 1 )
              {
                v89 = (v141 & 1) != 0 ? *((_QWORD *)&v141 + 1) : (unsigned __int8)v141 >> 1;
                if ( v89 > DFInt::JoinInfoMaxLength ) /*0x1068a0dba*/
                  RBX::throw_runtime_error(this: (RBX *)"player info json blob max length exceeded", a2: v70); /*0x1068a12ed*/
              }
            }
            if ( DFFlag::JoinInfoJsonLimits == 1 ) /*0x1068a0dc7*/
            {
              RBX::WebParser::withDefaultLimits(this: (RBX::WebParser *)v159); /*0x1068a0dd0*/
              *(_QWORD *)&v162 = DFInt::JoinInfoVariantCountLimit; /*0x1068a0ddc*/
              *((_QWORD *)&v162 + 1) = DFInt::JoinInfoVariantCountReportingLimit; /*0x1068a0dea*/
              if ( (v141 & 1) != 0 ) /*0x1068a0dfc*/
              {
                v90 = (char *)v142; /*0x1068a0e02*/
                v91 = *((_QWORD *)&v141 + 1); /*0x1068a0e09*/
              }
              else
              {
                v91 = (unsigned __int8)v141 >> 1; /*0x1068a0ea4*/
                v90 = (char *)&v141 + 1; /*0x1068a0ea6*/
              }
              if ( (unsigned __int8)RBX::WebParser::parseJSONTable(a1: v90, a2: v91, a3: a1 + 22656, a4: 0, a5: v159) == 0 ) /*0x1068a0ec7*/
                goto LABEL_148; /*0x1068a0ec7*/
              RBX::Players::createServerPlayer(a1: &v127, a2: *(_QWORD *)(a1 + 14464), a3: a1 + 22656, a4: v159); /*0x1068a0ee5*/
              if ( (_QWORD)v127 != 0 ) /*0x1068a0ef4*/
              {
                v135 = v127; /*0x1068a0ef6*/
                if ( *((_QWORD *)&v127 + 1) != 0 ) /*0x1068a0f0e*/
                  _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v127 + 1) + 8LL)); /*0x1068a0f10*/
              }
              else
              {
                v135 = 0; /*0x1068a0f4e*/
              }
              std::shared_ptr<RBX::Player>::operator=[abi:ne200100](a1: a1 + 22704, a2: &v135); /*0x1068a0f67*/
              std::shared_ptr<RBX::Player>::~shared_ptr[abi:ne200100](a1: &v135); /*0x1068a0f6f*/
              v95 = &v127; /*0x1068a0f74*/
            }
            else
            {
              if ( (v141 & 1) != 0 ) /*0x1068a0e20*/
              {
                v92 = (char *)v142; /*0x1068a0e22*/
                v93 = *((_QWORD *)&v141 + 1); /*0x1068a0e29*/
              }
              else
              {
                v93 = (unsigned __int8)v141 >> 1; /*0x1068a0e32*/
                v92 = (char *)&v141 + 1; /*0x1068a0e34*/
              }
              if ( (unsigned __int8)RBX::WebParser::parseJSONTable(a1: v92, a2: v93, a3: a1 + 22656, a4: 0, a5: 0) == 0 ) /*0x1068a0e51*/
                goto LABEL_148; /*0x1068a0e51*/
              RBX::Players::createServerPlayer(a1: &v135, a2: *(_QWORD *)(a1 + 14464), a3: a1 + 22656, a4: 0); /*0x1068a0e6a*/
              if ( (_QWORD)v135 != 0 ) /*0x1068a0e79*/
              {
                *(_OWORD *)v159 = v135; /*0x1068a0e86*/
                if ( *((_QWORD *)&v135 + 1) != 0 ) /*0x1068a0e97*/
                  _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v135 + 1) + 8LL)); /*0x1068a0e9d*/
              }
              else
              {
                *(_OWORD *)v159 = 0; /*0x1068a0f1b*/
              }
              std::shared_ptr<RBX::Player>::operator=[abi:ne200100](a1: a1 + 22704, a2: v159); /*0x1068a0f34*/
              std::shared_ptr<RBX::Player>::~shared_ptr[abi:ne200100](a1: v159); /*0x1068a0f3c*/
              v95 = &v135; /*0x1068a0f41*/
            }
            std::shared_ptr<RBX::Player>::~shared_ptr[abi:ne200100](a1: v95); /*0x1068a0f7b*/
LABEL_148:
            if ( DFFlag::EnablePreloading == 1 )
            {
              v96 = *(RBX::Reflection::ValueTable **)(a1 + 22656); /*0x1068a0f90*/
              if ( v96 != nullptr )
              {
                v97 = RBX::Reflection::ValueTable::find(this: v96, a2: "PreloadedVersion"); /*0x1068a0fa7*/
                if ( v97 != 0 && *(_BYTE *)(*(_QWORD *)(v97 + 40) + 53LL) == 1 )
                {
                  v98 = RBX::Reflection::Variant::get<int>(a1: v97 + 40); /*0x1068a0fc6*/
                  *(_DWORD *)(a1 + 22672) = v98; /*0x1068a0fcb*/
                  if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && (DFLog::NetworkJoin & 0xFC00) != 0 )
                  {
                    *(_QWORD *)&v135 = v98; /*0x1068a0fff*/
                    v159[0] = (std::__shared_weak_count *)1; /*0x1068a1002*/
                    v159[1] = (std::__shared_weak_count *)&v135; /*0x1068a100d*/
                    FLog::detail::FastLogSafeFormattedInternal(
                      a1: DFLog::NetworkJoin,
                      a2: qword_10D7F3E08,
                      a3: 4,
                      a4: (unsigned int)"[DFLog::NetworkJoin] ClientPreloadedVersion received: {}",
                      a5: 56,
                      a6: 1,
                      1,
                      &v135);
                  }
                }
              }
            }
            v99 = *(RBX::Player **)(a1 + 22704); /*0x1068a103e*/
            if ( v99 != nullptr ) /*0x1068a1048*/
            {
              PlayerGui = RBX::Player::getPlayerGui(this: v99); /*0x1068a104e*/
              RBX::shared_from<RBX::PlayerGui>(a1: v159, a2: PlayerGui); /*0x1068a105d*/
              std::shared_ptr<RBX::PlayerGui>::operator=[abi:ne200100](a1: a1 + 22608, a2: v159); /*0x1068a1073*/
              std::shared_ptr<RBX::PlayerGui>::~shared_ptr[abi:ne200100](a1: v159); /*0x1068a107b*/
              (*(void (__fastcall **)(__int64, _QWORD, _BYTE *))(*(_QWORD *)a1 + 1752LL))(a1, a2: v143, a3: v131); /*0x1068a1094*/
              RBX::weak_from<RBX::Network::ServerReplicator>(a1: v159, a2: a1); /*0x1068a10a4*/
              v101 = *(_QWORD *)(a1 + 14408); /*0x1068a10a9*/
              *(_OWORD *)v130 = *(_OWORD *)v159; /*0x1068a10bf*/
              if ( v159[1] != nullptr ) /*0x1068a10ca*/
                _InterlockedIncrement64((volatile signed __int64 *)v159[1] + 2); /*0x1068a10cc*/
              v102 = *(_QWORD *)(a1 + 22704); /*0x1068a10d8*/
              if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x1068a10e2*/
                UserID = *(_QWORD *)(v102 + 208); /*0x1068a10e8*/
              else
                UserID = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v102 + 176)); /*0x1068a1221*/
              RBX::Network::MegaReplicator::addReplicatorToJoinQueue(a1: v101, a2: v130, a3: UserID); /*0x1068a122e*/
              if ( v130[1] != nullptr ) /*0x1068a123d*/
                std::__shared_weak_count::__release_weak(this: v130[1]); /*0x1068a123f*/
              if ( v159[1] != nullptr ) /*0x1068a124e*/
                std::__shared_weak_count::__release_weak(this: v159[1]); /*0x1068a1250*/
              goto LABEL_178; /*0x1068a1255*/
            }
            v104 = (unsigned int)DFLog::NetworkJoin >> 8; /*0x1068a1100*/
            LOBYTE(v94) = (unsigned __int8)DFLog::NetworkJoin < 6u; /*0x1068a1107*/
            LOBYTE(v104) = (unsigned __int8)DFLog::NetworkJoin < 6u || BYTE1(DFLog::NetworkJoin) < 3u; /*0x1068a1110*/
            if ( (_BYTE)v104 == 0 ) /*0x1068a1112*/
              FLog::FastLog( /*0x1068a1121*/
                a1: *(_QWORD *)&DFLog::NetworkJoin,
                a2: qword_10D7F3E08,
                a3: "[DFLog::NetworkJoin] Player Creation Error",
                0);
            std::string::basic_string[abi:ne200100]<0>(a1: v159, a2: "FailedCreatePlayer", a3: v94, a4: v104); /*0x1068a1134*/
            RBX::Network::Replicator::reportServerJoinReject(a1, a2: (__int64)v159); /*0x1068a1143*/
            if ( ((__int64)v159[0] & 1) != 0 ) /*0x1068a114f*/
              operator delete(a1: (void *)v160); /*0x1068a1158*/
            if ( DFFlag::FixDiscoReportingOnTwoServerCases != 1 ) /*0x1068a1164*/
            {
              LOBYTE(v114) = 0; /*0x1068a1260*/
              v117 = 0; /*0x1068a1262*/
              RBX::Network::Replicator::requestDisconnectWithSignal(a1, a2: 0x106u, a3: &v114); /*0x1068a126d*/
              if ( v117 != 1 || (v115 & 1) == 0 ) /*0x1068a1282*/
                goto LABEL_178; /*0x1068a1282*/
              v107 = v116; /*0x1068a1284*/
LABEL_177:
              operator delete(a1: v107); /*0x1068a128b*/
              goto LABEL_178; /*0x1068a128b*/
            }
            v159[0] = (std::__shared_weak_count *)"PlayerInstall"; /*0x1068a1178*/
            v159[1] = (std::__shared_weak_count *)13; /*0x1068a117c*/
            std::string::basic_string[abi:ne200100]<0>(a1: &v160, a2: "Player Creation Error", a3: v105, a4: v106); /*0x1068a118e*/
            v162 = 0; /*0x1068a1197*/
            v122 = *(_OWORD *)v159; /*0x1068a11ad*/
            v124 = (void *)v161; /*0x1068a11b4*/
            v123 = v160; /*0x1068a11bb*/
            v160 = 0; /*0x1068a11bf*/
            v161 = 0; /*0x1068a11c3*/
            v125 = 0; /*0x1068a11cb*/
            v126 = 1; /*0x1068a11d0*/
            RBX::Network::Replicator::requestDisconnectWithSignal(a1, a2: 0x106u, a3: &v122); /*0x1068a11dc*/
            if ( v126 == 1 && (v123 & 1) != 0 ) /*0x1068a11f1*/
              operator delete(a1: v124); /*0x1068a11fa*/
            if ( (v160 & 1) != 0 ) /*0x1068a1206*/
            {
              v107 = (void *)v161; /*0x1068a120c*/
              goto LABEL_177; /*0x1068a1213*/
            }
LABEL_178:
            if ( (v141 & 1) != 0 ) /*0x1068a1297*/
              operator delete(a1: v142); /*0x1068a12a0*/
            RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v131); /*0x1068a12ac*/
            if ( (v137 & 1) != 0 ) /*0x1068a12b8*/
              operator delete(a1: v138[0]); /*0x1068a12c5*/
LABEL_97:
            v4 = 0; /*0x1068a0a63*/
            goto LABEL_98; /*0x1068a0a63*/
          }
          v57 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v131); /*0x1068a0658*/
          *(_BYTE *)(a1 + 22676) = v57; /*0x1068a065d*/
        }
        *(_BYTE *)(a1 + 22677) = v57; /*0x1068a087a*/
        goto LABEL_80; /*0x1068a087a*/
      case 0x92u:
      case 0x9Eu:
      case 0x9Fu:
      case 0xA0u:
      case 0xA2u:
      case 0xA3u:
      case 0xA4u:
        goto LABEL_98;
      case 0x96u:
        v18 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a0132*/
        v19 = RBX::Network::IncomingPacket::size(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a0138*/
        RBX::Network::NetworkStream::NetworkStream( /*0x1068a014b*/
          this: (RBX::Network::NetworkStream *)v159,
          a2: v18,
          a3: v19,
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v159, a2: 1u); /*0x1068a015c*/
        Bool = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v159); /*0x1068a016d*/
        Int32 = 0; /*0x1068a016f*/
        if ( Bool != 0 ) /*0x1068a0174*/
          Int32 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v159); /*0x1068a0182*/
        RBX::weak_from<RBX::Network::ServerReplicator>(a1: v128, a2: a1); /*0x1068a018f*/
        RBX::Network::ServerReplicator::toggleSendStatsJob(a1: v128, a2: Bool, a3: Int32); /*0x1068a01a1*/
        if ( v129 != nullptr ) /*0x1068a01b0*/
          std::__shared_weak_count::__release_weak(this: v129); /*0x1068a01b6*/
        goto LABEL_96; /*0x1068a01bb*/
      case 0x99u:
        if ( DFFlag::DebugEnableRemoteProfiling2 != 1 ) /*0x1068a0304*/
          goto LABEL_98; /*0x1068a0304*/
        v32 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a0312*/
        v33 = RBX::Network::IncomingPacket::size(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a0318*/
        RBX::Network::NetworkStream::NetworkStream( /*0x1068a032b*/
          this: (RBX::Network::NetworkStream *)v159,
          a2: v32,
          a3: v33,
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v159, a2: 1u); /*0x1068a033c*/
        v34 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v159); /*0x1068a0348*/
        if ( v34 == 2 ) /*0x1068a0350*/
        {
          v77 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v159); /*0x1068a0a2a*/
          v78 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v159); /*0x1068a0a38*/
          v79 = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v159); /*0x1068a0a42*/
          RBX::Network::ServerReplicator::processMicroProfileRequest( /*0x1068a0a52*/
            this: (RBX::Network::ServerReplicator *)a1,
            a2: (RBX::Instance *)v77,
            a3: v78,
            a4: v79);
        }
        else if ( v34 == 1 ) /*0x1068a0359*/
        {
          v35 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v159); /*0x1068a036b*/
          v36 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v159); /*0x1068a0374*/
          RBX::Network::ServerReplicator::processMicroProfileRequest( /*0x1068a0382*/
            this: (RBX::Network::ServerReplicator *)a1,
            a2: (RBX::Instance *)v35,
            a3: v36,
            a4: 0);
        }
LABEL_96:
        RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v159); /*0x1068a0a57*/
        goto LABEL_97; /*0x1068a0a5e*/
      case 0x9Cu:
        v150[4] = *((_QWORD *)a2 + 4); /*0x1068a01cb*/
        v22 = *a2; /*0x1068a01cf*/
        *(_OWORD *)&v150[2] = a2[1]; /*0x1068a01d8*/
        *(_OWORD *)v150 = v22; /*0x1068a01dc*/
        std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1068a01e4*/
          a1: v151,
          a2: (char *)a2 + 40,
          a3: v6,
          a4: v7,
          a5: v9,
          a6: v10);
        RBX::Network::ServerReplicator::processExtAntiCheatV2(a1, a2: v150); /*0x1068a01f3*/
        v4 = 1; /*0x1068a01f8*/
        if ( v152[88] != 1 ) /*0x1068a0205*/
          goto LABEL_98; /*0x1068a0205*/
        v16 = (RBX::RbxTransport::NetStreamBuffer *)v152; /*0x1068a020b*/
        goto LABEL_69; /*0x1068a0212*/
      case 0xA7u:
        if ( RBX::Network::Replicator::getSharedStringCachingEnabled(this: (RBX::Network::Replicator *)a1) ) /*0x1068a02a0*/
        {
          if ( *(_BYTE *)(*(_QWORD *)(a1 + 15416) + 344LL) != 0 ) /*0x1068a02bb*/
            RBX::throw_runtime_error(this: (RBX *)"Too many shared string hash packets", a2: v8); /*0x1068a12dd*/
          NetAssetCachingEnabled = RBX::Network::Replicator::getNetAssetCachingEnabled(this: (RBX::Network::Replicator *)a1); /*0x1068a02c4*/
          v29 = *(_QWORD *)(a1 + 15416); /*0x1068a02c9*/
          if ( NetAssetCachingEnabled ) /*0x1068a02d2*/
          {
            v30 = RBX::Network::IncomingPacket::data(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a02e0*/
            v31 = RBX::Network::IncomingPacket::size(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a02e6*/
            RBX::Network::SharedStringSynchronizer::processMixedHashPacket(a1: v29, a2: v30, a3: v31); /*0x1068a02f3*/
          }
          else
          {
            v61 = RBX::Network::IncomingPacket::data(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a083e*/
            v62 = RBX::Network::IncomingPacket::size(this: (RBX::Network::IncomingPacket *)a2); /*0x1068a0844*/
            RBX::Network::SharedStringSynchronizer::processSharedStringHashPacket(a1: v29, a2: v61, a3: v62); /*0x1068a0851*/
          }
        }
        goto LABEL_98; /*0x1068a02f8*/
      default:
        goto LABEL_44;
    }
  }
  v7 = (unsigned int)v5 - 21; /*0x1068a0086*/
  if ( (unsigned int)v7 < 2 ) /*0x1068a008c*/
  {
    if ( DFFlag::GameLoadDataStatistics == 1 && *(_BYTE *)(a1 + 22992) == 0 ) /*0x1068a00c7*/
      RBX::Network::ServerReplicator::reportGameLoadDataStatistics(this: (RBX::Network::ServerReplicator *)a1, a2: 1u); /*0x1068a00d1*/
    v156[4] = *((_QWORD *)a2 + 4); /*0x1068a00e1*/
    v17 = *a2; /*0x1068a00e5*/
    *(_OWORD *)&v156[2] = a2[1]; /*0x1068a00ee*/
    *(_OWORD *)v156 = v17; /*0x1068a00f2*/
    std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1068a00fa*/
      a1: v157,
      a2: (char *)a2 + 40,
      a3: v6,
      a4: v7,
      a5: v9,
      a6: v10);
    v4 = RBX::Network::Replicator::OnReceiveV2(a1, a2: (RBX::Network::IncomingPacket *)v156); /*0x1068a010e*/
    if ( v158[88] == 1 ) /*0x1068a0118*/
    {
      v16 = (RBX::RbxTransport::NetStreamBuffer *)v158; /*0x1068a011e*/
      goto LABEL_69; /*0x1068a0125*/
    }
  }
  else
  {
    if ( v5 != 14 ) /*0x1068a0091*/
    {
      if ( v5 == 19 ) /*0x1068a009a*/
      {
        v4 = 1; /*0x1068a00a0*/
        RBX::Network::ServerReplicator::sendSFFlags(this: (RBX::Network::ServerReplicator *)a1); /*0x1068a00a9*/
        goto LABEL_98; /*0x1068a00ae*/
      }
LABEL_44:
      v144[4] = *((_QWORD *)a2 + 4); /*0x1068a04fc*/
      v46 = *a2; /*0x1068a050b*/
      *(_OWORD *)&v144[2] = a2[1]; /*0x1068a0514*/
      *(_OWORD *)v144 = v46; /*0x1068a0518*/
      std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1068a0520*/
        a1: v145,
        a2: (char *)a2 + 40,
        a3: v6,
        a4: v7,
        a5: v9,
        a6: v10);
      v4 = RBX::Network::Replicator::OnReceiveV2(a1, a2: (RBX::Network::IncomingPacket *)v144); /*0x1068a0534*/
      if ( v146[88] != 1 ) /*0x1068a053e*/
        goto LABEL_98; /*0x1068a053e*/
      v16 = (RBX::RbxTransport::NetStreamBuffer *)v146; /*0x1068a0544*/
LABEL_69:
      RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: v16); /*0x1068a077c*/
      goto LABEL_98; /*0x1068a0781*/
    }
    if ( FFlag::GameStatsHasSpecificAckISR == 1 ) /*0x1068a04a8*/
    {
      v167[4] = *((_QWORD *)a2 + 4); /*0x1068a04b9*/
      v41 = *a2; /*0x1068a04bd*/
      *(_OWORD *)&v167[2] = a2[1]; /*0x1068a04c6*/
      *(_OWORD *)v167 = v41; /*0x1068a04ca*/
      std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1068a04d2*/
        a1: v168,
        a2: (char *)a2 + 40,
        a3: v6,
        a4: v7,
        a5: v9,
        a6: v10);
      RBX::Network::ServerReplicator::processAckPacketServerV2( /*0x1068a04e1*/
        a1,
        a2: (RBX::Network::IncomingPacket *)v167,
        a3: v42,
        a4: v43,
        a5: v44,
        a6: v45);
      if ( v169[88] != 1 ) /*0x1068a04ea*/
        goto LABEL_98; /*0x1068a04ea*/
      v16 = (RBX::RbxTransport::NetStreamBuffer *)v169; /*0x1068a04f0*/
      goto LABEL_69; /*0x1068a04f7*/
    }
    if ( DFFlag::GameLoadDataStatistics == 1 && *(_BYTE *)(a1 + 22992) == 0 ) /*0x1068a0724*/
      RBX::Network::ServerReplicator::reportGameLoadDataStatistics(this: (RBX::Network::ServerReplicator *)a1, a2: 0); /*0x1068a072b*/
    v164[4] = *((_QWORD *)a2 + 4); /*0x1068a073b*/
    v58 = *a2; /*0x1068a073f*/
    *(_OWORD *)&v164[2] = a2[1]; /*0x1068a0748*/
    *(_OWORD *)v164 = v58; /*0x1068a074c*/
    std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x1068a0754*/
      a1: v165,
      a2: (char *)a2 + 40,
      a3: v6,
      a4: v7,
      a5: v9,
      a6: v10);
    RBX::Network::Replicator::processAckPacketV2(a1, a2: (RBX::Network::IncomingPacket *)v164); /*0x1068a0763*/
    if ( v166[88] == 1 ) /*0x1068a076f*/
    {
      v16 = (RBX::RbxTransport::NetStreamBuffer *)v166; /*0x1068a0775*/
      goto LABEL_69; /*0x1068a0775*/
    }
  }
LABEL_98:
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v140, a2: (unsigned int)v8); /*0x1068a0a66*/
  return v4; /*0x1068a0a88*/
}

// Address: 0x1068a1906 | Name: __ZN3RBX7Network16ServerReplicator18toggleSendStatsJobENSt3__18weak_ptrIS1_EEbi
void __fastcall RBX::Network::ServerReplicator::toggleSendStatsJob(std::__shared_weak_count **a1, char a2, int a3)
{
  std::__shared_weak_count *v4; // rdi
  std::__shared_weak_count *v7; // r15
  __int64 v8; // r12
  std::__shared_weak_count *v9; // r14
  std::__shared_weak_count *v10; // rbx
  _QWORD v11[2]; // [rsp+0h] [rbp-40h] BYREF
  std::__shared_weak_count *v12[2]; // [rsp+10h] [rbp-30h]

  *(_OWORD *)v12 = 0; /*0x1068a191b*/
  v4 = a1[1]; /*0x1068a191f*/
  if ( v4 != nullptr ) /*0x1068a1926*/
  {
    v12[1] = (std::__shared_weak_count *)std::__shared_weak_count::lock(this: v4); /*0x1068a1937*/
    if ( v12[1] != nullptr ) /*0x1068a193e*/
    {
      v7 = *a1; /*0x1068a1944*/
      v12[0] = v7; /*0x1068a1947*/
      if ( v7 != nullptr ) /*0x1068a194e*/
      {
        if ( a2 != 0 ) /*0x1068a195e*/
        {
          if ( *((_QWORD *)v7 + 2759) == 0 ) /*0x1068a1968*/
          {
            v8 = operator new(a1: 0x1B0u); /*0x1068a1978*/
            RBX::Network::ReplicatorJob::ReplicatorJob( /*0x1068a1993*/
              a1: (_QWORD *)v8,
              a2: (RBX::Instance *)"Replicator StatsSender",
              a3: v7,
              a4: 4u,
              a5: 0x13u);
            *(_QWORD *)v8 = &off_10CAAF3A0; /*0x1068a199f*/
            *(_DWORD *)(v8 + 424) = a3; /*0x1068a19a3*/
            std::shared_ptr<RBX::Network::Replicator::SendStatsJob>::shared_ptr[abi:ne200100]<RBX::Network::Replicator::SendStatsJob,0>( /*0x1068a19b2*/
              a1: v11,
              a2: v8);
            std::shared_ptr<RBX::TaskScheduler::Job>::operator=[abi:ne200100]<RBX::Network::Replicator::SendStatsJob,0>( /*0x1068a19c1*/
              a1: (char *)v7 + 22072,
              a2: v11);
            v9 = (std::__shared_weak_count *)v11[1]; /*0x1068a19c6*/
            if ( v11[1] != 0 /*0x1068a19df*/
              && _InterlockedExchangeAdd64((volatile signed __int64 *)(v11[1] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
            {
              (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x1068a19e7*/
              std::__shared_weak_count::__release_weak(this: v9); /*0x1068a19ed*/
            }
            RBX::TaskScheduler::add(a1: (char *)v7 + 22072); /*0x1068a19f5*/
          }
        }
        else
        {
          RBX::TaskScheduler::remove(a1: (char *)v7 + 22072); /*0x1068a19ff*/
          std::shared_ptr<RBX::TaskScheduler::Job>::reset[abi:ne200100](a1: (char *)v7 + 22072); /*0x1068a1a07*/
        }
      }
    }
  }
  v10 = v12[1]; /*0x1068a1a0c*/
  if ( v12[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v12[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068a1a25*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x1068a1a2d*/
    std::__shared_weak_count::__release_weak(this: v10); /*0x1068a1a33*/
  }
}

// Address: 0x1068a1a6a | Name: __ZN3RBX7Network16ServerReplicator21processExtAntiCheatV2ENS0_14IncomingPacketE
void __fastcall RBX::Network::ServerReplicator::processExtAntiCheatV2(_QWORD *a1, RBX::Network::IncomingPacket *a2)
{
  __int64 v4; // rax
  __int64 v5; // r14
  __int64 v6; // rax
  __int128 *v7; // rax
  RBX::Network::Peer *v8; // r13
  RBX::NetworkBase::ConnectionInternal *v9; // r12
  __int64 v10; // rax
  __int64 UserID; // rax
  char v12; // r15
  char *v13; // rbx
  char *v14; // rax
  std::__shared_weak_count *v15; // rbx
  RBX::Network::IncomingPacket *v16; // [rsp+8h] [rbp-88h]
  std::__shared_weak_count *v17[2]; // [rsp+10h] [rbp-80h] BYREF
  char v18; // [rsp+28h] [rbp-68h] BYREF
  char v19; // [rsp+29h] [rbp-67h] BYREF
  void *v20; // [rsp+38h] [rbp-58h]
  __int128 v21; // [rsp+40h] [rbp-50h] BYREF
  void *v22; // [rsp+50h] [rbp-40h]
  __int64 v23; // [rsp+60h] [rbp-30h]

  v4 = (*(__int64 (__fastcall **)(_QWORD *))(*a1 + 688LL))(a1); /*0x1068a1a84*/
  if ( v4 != 0 ) /*0x1068a1a8d*/
  {
    v5 = v4; /*0x1068a1a93*/
    v6 = *(_QWORD *)(v4 + 112); /*0x1068a1a96*/
    if ( (*(_BYTE *)(v6 + 8) & 1) != 0 ) /*0x1068a1a9e*/
    {
      std::string::__init_copy_ctor_external(a1: &v21, a2: *(_QWORD *)(v6 + 24), a3: *(_QWORD *)(v6 + 16)); /*0x1068a1ac1*/
    }
    else
    {
      v7 = (__int128 *)(v6 + 8); /*0x1068a1aa0*/
      v22 = *((void **)v7 + 2); /*0x1068a1aa8*/
      v21 = *v7; /*0x1068a1aaf*/
    }
    v8 = (RBX::Network::Peer *)a1[2828]; /*0x1068a1ac6*/
    v9 = (RBX::NetworkBase::ConnectionInternal *)a1[35]; /*0x1068a1ace*/
    v10 = *(_QWORD *)(v5 + 2376); /*0x1068a1ad6*/
    *(_OWORD *)v17 = *(_OWORD *)(v5 + 2368); /*0x1068a1ae5*/
    if ( v10 != 0 ) /*0x1068a1aec*/
      _InterlockedIncrement64((volatile signed __int64 *)(v10 + 8)); /*0x1068a1aee*/
    v16 = a2; /*0x1068a1afd*/
    if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x1068a1b04*/
      UserID = *(_QWORD *)(v5 + 208); /*0x1068a1b06*/
    else
      UserID = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v5 + 176)); /*0x1068a1b19*/
    v23 = UserID; /*0x1068a1b1e*/
    v12 = v21; /*0x1068a1b22*/
    v13 = (char *)v22; /*0x1068a1b26*/
    RBX::Player::getOsPlatformServerOnly(this: (RBX::Player *)&v18); /*0x1068a1b31*/
    if ( (v12 & 1) == 0 ) /*0x1068a1b3e*/
      v13 = (char *)&v21 + 1; /*0x1068a1b3e*/
    if ( (v18 & 1) != 0 ) /*0x1068a1b46*/
      v14 = (char *)v20; /*0x1068a1b48*/
    else
      v14 = &v19; /*0x1068a1b4e*/
    RBX::Network::Server::handleExtAntiCheatV2( /*0x1068a1b6e*/
      this: v8,
      a2: v9,
      a3: v16,
      a4: (int)v17,
      a5: v23,
      a6: (__int64)v13,
      a7: (__int64)v14);
    if ( (v18 & 1) != 0 ) /*0x1068a1b77*/
      operator delete(a1: v20); /*0x1068a1b7d*/
    v15 = v17[1]; /*0x1068a1b82*/
    if ( v17[1] != nullptr /*0x1068a1b9b*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v17[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x1068a1ba3*/
      std::__shared_weak_count::__release_weak(this: v15); /*0x1068a1ba9*/
    }
    if ( (v21 & 1) != 0 ) /*0x1068a1bb2*/
      operator delete(a1: v22); /*0x1068a1bb8*/
  }
}

// Address: 0x1068a1c06 | Name: __ZN3RBX7Network16ServerReplicator20OnReceive_deprecatedEPN6RakNet6PacketE
__int64 __fastcall RBX::Network::ServerReplicator::OnReceive_deprecated(void **this, RakNet::SystemAddress *a2)
{
  unsigned __int8 *v4; // rsi
  unsigned int v5; // eax
  unsigned int v6; // r12d
  char Bool; // bl
  int Int32; // r12d
  unsigned int PayloadLimit; // eax
  char v10; // al
  unsigned __int64 v11; // rcx
  bool NetAssetCachingEnabled; // al
  __int64 v13; // rdi
  int v14; // eax
  unsigned int v15; // ebx
  int v16; // eax
  __int64 v17; // rdx
  __int64 v18; // rcx
  void *v19; // rdi
  __int64 v20; // rdx
  __int64 v21; // rcx
  __int64 v22; // rsi
  RBX::Time *v23; // rdi
  RBX::Network::NetworkStream *v24; // rsi
  double v25; // xmm0_8
  unsigned __int8 Byte; // r12
  Luau::BytecodeBuilder *v27; // rdi
  __int64 v28; // rax
  char v29; // al
  __int64 v30; // rdx
  __int64 v31; // rcx
  unsigned __int8 Version; // al
  unsigned __int8 v33; // cl
  unsigned __int8 v34; // dl
  unsigned __int16 UInt16; // ax
  int i; // ebx
  unsigned int v37; // eax
  unsigned int v38; // eax
  unsigned __int8 v39; // r12
  const char *v40; // rsi
  unsigned __int64 v41; // rax
  int v42; // r8d
  int v43; // r9d
  __int64 v44; // rdx
  __int64 v45; // rcx
  char *v46; // rcx
  unsigned int v47; // ebx
  int v48; // r12d
  unsigned __int8 v49; // al
  char v51; // al
  void *v52; // rcx
  __int64 v53; // rsi
  __int64 v54; // rax
  __int64 v55; // rax
  __int64 v56; // rdx
  __int64 v57; // rcx
  __int64 v58; // rcx
  unsigned __int64 v59; // rax
  char *v60; // rdi
  __int64 v61; // rsi
  char *v62; // rdi
  __int64 v63; // rsi
  __int64 v64; // rdx
  __int128 *v65; // rdi
  RBX::Reflection::ValueTable *v66; // rdi
  __int64 v67; // rax
  unsigned int v68; // eax
  RBX::Player *v69; // rdi
  __int64 PlayerGui; // rax
  __int64 v71; // rbx
  __int64 v72; // rdi
  __int64 UserID; // rdx
  __int64 v74; // rcx
  __int64 v75; // rdx
  __int64 v76; // rcx
  __int128 v77; // [rsp+10h] [rbp-4D0h] BYREF
  char v78; // [rsp+20h] [rbp-4C0h]
  _BYTE v79[15]; // [rsp+21h] [rbp-4BFh]
  void *v80; // [rsp+30h] [rbp-4B0h]
  __int128 v81; // [rsp+38h] [rbp-4A8h]
  char v82; // [rsp+48h] [rbp-498h]
  __int128 v83; // [rsp+50h] [rbp-490h] BYREF
  char v84; // [rsp+60h] [rbp-480h]
  void *v85; // [rsp+70h] [rbp-470h]
  char v86; // [rsp+88h] [rbp-458h]
  __int128 v87; // [rsp+90h] [rbp-450h] BYREF
  char v88; // [rsp+A0h] [rbp-440h]
  void *v89; // [rsp+B0h] [rbp-430h]
  char v90; // [rsp+C8h] [rbp-418h]
  __int128 v91; // [rsp+110h] [rbp-3D0h] BYREF
  __int128 v92; // [rsp+120h] [rbp-3C0h]
  void *v93; // [rsp+130h] [rbp-3B0h]
  __int128 v94; // [rsp+138h] [rbp-3A8h]
  char v95; // [rsp+148h] [rbp-398h]
  __int128 v96; // [rsp+150h] [rbp-390h] BYREF
  std::__shared_weak_count *v97; // [rsp+160h] [rbp-380h] BYREF
  std::__shared_weak_count *v98; // [rsp+168h] [rbp-378h]
  std::__shared_weak_count *v99[2]; // [rsp+170h] [rbp-370h] BYREF
  _BYTE v100[16]; // [rsp+180h] [rbp-360h] BYREF
  __int64 v101; // [rsp+190h] [rbp-350h]
  unsigned int v102; // [rsp+1B0h] [rbp-330h]
  unsigned int v103; // [rsp+1B8h] [rbp-328h]
  __int128 v104; // [rsp+1C0h] [rbp-320h] BYREF
  void *v105; // [rsp+1D0h] [rbp-310h]
  __int128 v106; // [rsp+1E0h] [rbp-300h] BYREF
  void *v107[2]; // [rsp+1F0h] [rbp-2F0h]
  _QWORD v108[4]; // [rsp+200h] [rbp-2E0h] BYREF
  unsigned int v109; // [rsp+22Ch] [rbp-2B4h]
  __int128 v110; // [rsp+230h] [rbp-2B0h] BYREF
  void *v111; // [rsp+240h] [rbp-2A0h]
  unsigned __int8 v112; // [rsp+24Fh] [rbp-291h]
  std::__shared_weak_count *v113[2]; // [rsp+250h] [rbp-290h] BYREF
  __int128 v114; // [rsp+260h] [rbp-280h] BYREF
  void *v115; // [rsp+270h] [rbp-270h]
  __int128 v116; // [rsp+278h] [rbp-268h]
  _BYTE v117[536]; // [rsp+298h] [rbp-248h] BYREF

  v109 = RBX::Memory::setCurrentCategory( /*0x1068a1c3c*/
           this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkOnReceive,
           (unsigned int)a2);
  v4 = *((unsigned __int8 **)a2 + 7); /*0x1068a1c42*/
  v5 = *v4; /*0x1068a1c46*/
  v6 = 0; /*0x1068a1c49*/
  if ( v5 > 0x86 )
  {
    switch ( *v4 )
    {
      case 0x87u:
      case 0x88u:
      case 0x8Bu:
      case 0x8Cu:
        RBX::LeakyBucket::updateParameters( /*0x1068a1c8b*/
          this: (RBX::LeakyBucket *)(this + 2875),
          a2: (float)DFInt::ChatCap,
          a3: (float)DFInt::ChatTime);
        if ( (unsigned __int8)RBX::LeakyBucket::checkAdd(this: (RBX::LeakyBucket *)(this + 2875), a2: 1.0) != 0 ) /*0x1068a1ca2*/
          goto LABEL_35; /*0x1068a1ca2*/
        goto LABEL_86; /*0x1068a1ca2*/
      case 0x8Du:
        if ( DFFlag::BlockInvalidClusterPacket != 1 /*0x1068a1f8f*/
          || (*((unsigned __int8 (__fastcall **)(void **, _QWORD))*this + 117))(a1: this, a2: 0) != 0 )
        {
          goto LABEL_35; /*0x1068a1f8f*/
        }
        std::string::basic_string[abi:ne200100]<0>(a1: v113, a2: "TerrainRecvOnGameServer", a3: v20, a4: v21); /*0x1068a2191*/
        std::string::basic_string[abi:ne200100]<0>( /*0x1068a21a4*/
          a1: &v106,
          a2: "Received a Terrain packet from a Client on a GameServer",
          a3: v30,
          a4: v31);
        RBX::Network::Replicator::logPacketError( /*0x1068a21c0*/
          a1: this,
          (__int64)a2,
          a3: (unsigned __int8 *)v113,
          a4: (__int64)&v106,
          a5: 0);
        if ( (v106 & 1) != 0 ) /*0x1068a21cc*/
          operator delete(a1: v107[0]); /*0x1068a21d5*/
        if ( ((__int64)v113[0] & 1) != 0 ) /*0x1068a21e1*/
          operator delete(a1: (void *)v114); /*0x1068a21ea*/
        v6 = 0; /*0x1068a21ef*/
        LOBYTE(v87) = 0; /*0x1068a21f9*/
        v90 = 0; /*0x1068a21fc*/
        RBX::Network::Replicator::requestDisconnectWithSignal(a1: (__int64)this, a2: 0x104u, a3: &v87); /*0x1068a2208*/
        if ( v90 != 1 || (v88 & 1) == 0 ) /*0x1068a2221*/
          goto LABEL_86; /*0x1068a2221*/
        v19 = v89; /*0x1068a2227*/
        goto LABEL_32; /*0x1068a222e*/
      case 0x8Fu:
        RBX::Network::NetworkStream::NetworkStream( /*0x1068a1daf*/
          this: (RBX::Network::NetworkStream *)v113,
          a2: v4,
          a3: *((_DWORD *)a2 + 12),
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v113, a2: 1u); /*0x1068a1dc0*/
        v106 = 0; /*0x1068a1dc9*/
        v107[0] = nullptr; /*0x1068a1dd1*/
        PayloadLimit = RBX::Network::Replicator::getReadPayloadLimit((RBX::Network::Replicator *)this); /*0x1068a1ddf*/
        RBX::Network::deserializeString(a1: &v106, a2: v113, a3: PayloadLimit); /*0x1068a1df4*/
        v10 = v106; /*0x1068a1df9*/
        if ( (v106 & 1) != 0 ) /*0x1068a1e02*/
          v11 = *((_QWORD *)&v106 + 1); /*0x1068a1e08*/
        else
          v11 = (unsigned __int8)v106 >> 1; /*0x1068a20ae*/
        if ( v11 <= DFInt::SpawnNameLimit ) /*0x1068a20ba*/
        {
          if ( (*(_BYTE *)(this + 2840) & 1) != 0 ) /*0x1068a20cb*/
            operator delete(a1: *(this + 2842)); /*0x1068a20d4*/
          *(this + 2842) = v107[0]; /*0x1068a20e0*/
          *((_OWORD *)this + 1420) = v106; /*0x1068a20ec*/
          LOWORD(v106) = 0; /*0x1068a20f0*/
          v10 = 0; /*0x1068a20f9*/
        }
        if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && BYTE1(DFLog::NetworkJoin) >= 3u )
        {
          FLog::FastLogS(
            a1: *(FLog **)&DFLog::NetworkJoin,
            a2: qword_10D7F3E08,
            a3: "[DFLog::NetworkJoin] initialSpawnName: %s",
            a4: (__int64)(this + 2840));
          v10 = v106; /*0x1068a2134*/
        }
        if ( (v10 & 1) != 0 ) /*0x1068a213c*/
          operator delete(a1: v107[0]); /*0x1068a2149*/
        goto LABEL_84; /*0x1068a214e*/
      case 0x90u:
        memset(v108, 0, 28); /*0x1068a1ee3*/
        *(_OWORD *)v107 = 0; /*0x1068a1eeb*/
        v106 = 0; /*0x1068a1ef3*/
        RBX::Network::Replicator::addReplicatorState((RBX::Network::Replicator *)this, a2: 1); /*0x1068a1f03*/
        if ( *((_BYTE *)this + 22644) == 1 ) /*0x1068a1f10*/
        {
          *((_BYTE *)this + 22645) = 1; /*0x1068a1f16*/
          std::string::basic_string[abi:ne200100]<0>(a1: v113, a2: "AlreadySeen", a3: v17, a4: v18); /*0x1068a1f2c*/
          RBX::Network::Replicator::reportServerJoinReject(a1: (__int64)this, a2: (__int64)v113); /*0x1068a1f3b*/
          if ( ((__int64)v113[0] & 1) != 0 ) /*0x1068a1f47*/
            operator delete(a1: (void *)v114); /*0x1068a1f50*/
          if ( (v106 & 1) != 0 ) /*0x1068a1f5c*/
          {
            v19 = v107[0]; /*0x1068a1f62*/
LABEL_32:
            operator delete(a1: v19); /*0x1068a1f69*/
          }
          goto LABEL_86; /*0x1068a1f6e*/
        }
        *((_BYTE *)this + 22644) = 1; /*0x1068a1fc8*/
        if ( DFFlag::ReportLuauConnIssue == 1 ) /*0x1068a1fda*/
        {
          v22 = *((unsigned int *)a2 + 12); /*0x1068a1fdc*/
          v108[0] = v22; /*0x1068a1fe0*/
          HIDWORD(v108[1]) = XXH32(a1: *((_QWORD *)a2 + 7), a2: v22, a3: 1); /*0x1068a1ff5*/
        }
        RBX::Network::NetworkStream::NetworkStream( /*0x1068a200c*/
          this: (RBX::Network::NetworkStream *)v100,
          a2: *((unsigned __int8 **)a2 + 7),
          a3: *((_DWORD *)a2 + 12),
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v100, a2: 1u); /*0x1068a201d*/
        if ( *((_BYTE *)this + 18600) == 1 ) /*0x1068a202a*/
        {
          RBX::Time::nowFast(this: v23); /*0x1068a202c*/
          *((double *)this + 2326) = (v25 - *((double *)this + 2843)) * 1000.0; /*0x1068a2042*/
        }
        RBX::Network::Peer::decryptDataPart(this: (RBX::Network::Peer *)v100, a2: v24); /*0x1068a2052*/
        Byte = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v100); /*0x1068a2063*/
        *((_DWORD *)this + 5523) = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v100); /*0x1068a2072*/
        v28 = (__int64)*(this + 1945); /*0x1068a2079*/
        if ( (v28 & 0x100000) != 0 )
        {
          *((_BYTE *)this + 22676) = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v100); /*0x1068a224c*/
          v29 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v100); /*0x1068a225a*/
        }
        else
        {
          if ( (v28 & 0x800) == 0 )
          {
LABEL_68:
            Version = Luau::BytecodeBuilder::getVersion(this: v27); /*0x1068a2266*/
            v33 = *((_BYTE *)this + 22676); /*0x1068a226b*/
            v34 = *((_BYTE *)this + 22677); /*0x1068a2272*/
            if ( v34 < v33 || Version > v34 || Version < v33 )
            {
              v113[0] = (std::__shared_weak_count *)Version; /*0x1068a23a2*/
              *(_QWORD *)&v114 = v33; /*0x1068a23a5*/
              v115 = (void *)v34; /*0x1068a23a9*/
              fmt::v8::vformat(
                a1: &v110,
                a2: "Unsupported Luau version requested: {} not in [{}..{}]",
                a3: 54,
                a4: 546,
                a5: v113);
              v45 = (unsigned int)DFLog::NetworkJoin >> 8; /*0x1068a23d6*/
              LOBYTE(v44) = (unsigned __int8)DFLog::NetworkJoin < 6u; /*0x1068a23dd*/
              LOBYTE(v45) = (unsigned __int8)DFLog::NetworkJoin < 6u || BYTE1(DFLog::NetworkJoin) < 3u; /*0x1068a23e6*/
              if ( (_BYTE)v45 == 0 ) /*0x1068a23e8*/
              {
                if ( (v110 & 1) != 0 ) /*0x1068a23f9*/
                  LODWORD(v46) = (_DWORD)v111; /*0x1068a23ff*/
                else
                  v46 = (char *)&v110 + 1; /*0x1068a2487*/
                FLog::FastLogFormatted( /*0x1068a2497*/
                  a1: DFLog::NetworkJoin,
                  a2: qword_10D7F3E08,
                  a3: (unsigned int)"[DFLog::NetworkJoin] %s",
                  a4: (_DWORD)v46,
                  a5: v42,
                  a6: v43);
              }
              std::string::basic_string[abi:ne200100]<0>(a1: v113, a2: "UnsupportedLuauVersion", a3: v44, a4: v45); /*0x1068a24aa*/
              RBX::Network::Replicator::reportServerJoinReject(a1: (__int64)this, a2: (__int64)v113); /*0x1068a24b9*/
              if ( ((__int64)v113[0] & 1) != 0 ) /*0x1068a24c5*/
                operator delete(a1: (void *)v114); /*0x1068a24ce*/
              v51 = v110; /*0x1068a24d3*/
              v113[0] = *(std::__shared_weak_count **)((char *)&v110 + 1); /*0x1068a24e0*/
              *(std::__shared_weak_count **)((char *)v113 + 7) = *((std::__shared_weak_count **)&v110 + 1); /*0x1068a24ee*/
              v52 = v111; /*0x1068a24f5*/
              v110 = 0; /*0x1068a2500*/
              v111 = nullptr; /*0x1068a2508*/
              v81 = 0; /*0x1068a251a*/
              *(_QWORD *)&v77 = "Security"; /*0x1068a2526*/
              *((_QWORD *)&v77 + 1) = 8; /*0x1068a2529*/
              v78 = v51; /*0x1068a2531*/
              qmemcpy(v79, v113, sizeof(v79)); /*0x1068a2542*/
              v80 = v52; /*0x1068a254a*/
              v82 = 1; /*0x1068a254e*/
              RBX::Network::Replicator::requestDisconnectWithSignal(a1: (__int64)this, a2: 0x106u, a3: &v77); /*0x1068a255a*/
              if ( v82 == 1 && (v78 & 1) != 0 ) /*0x1068a256f*/
                operator delete(a1: v80); /*0x1068a2578*/
              if ( DFFlag::FixDiscoReportingOnTwoServerCases == 0 ) /*0x1068a2584*/
              {
                LOBYTE(v83) = 0; /*0x1068a258f*/
                v86 = 0; /*0x1068a2591*/
                RBX::Network::Replicator::requestDisconnectWithSignal(a1: (__int64)this, a2: 0x106u, a3: &v83); /*0x1068a259c*/
                if ( v86 == 1 && (v84 & 1) != 0 ) /*0x1068a25b1*/
                  operator delete(a1: v85); /*0x1068a25ba*/
              }
              if ( DFFlag::ReportLuauConnIssue == 1 ) /*0x1068a25c2*/
              {
                v107[1] = (void *)*((unsigned int *)a2 + 12); /*0x1068a25cc*/
                v53 = 100; /*0x1068a25e3*/
                if ( v102 < 0x64 ) /*0x1068a25e8*/
                  v53 = v102; /*0x1068a25e8*/
                LODWORD(v108[1]) = XXH32(a1: v101, a2: v53, a3: 1); /*0x1068a25f5*/
                LOWORD(v108[3]) = *((_WORD *)this + 11338); /*0x1068a260f*/
                v54 = (__int64)*(this + 2315); /*0x1068a2615*/
                if ( (*(_BYTE *)(v54 + 744) & 1) != 0 ) /*0x1068a2623*/
                {
                  std::string::__init_copy_ctor_external( /*0x1068a2659*/
                    a1: v113,
                    a2: *(_QWORD *)(v54 + 760),
                    a3: *(_QWORD *)(v54 + 752));
                }
                else
                {
                  v55 = v54 + 744; /*0x1068a2625*/
                  *(_QWORD *)&v114 = *(_QWORD *)(v55 + 16); /*0x1068a262f*/
                  *(_OWORD *)v113 = *(_OWORD *)v55; /*0x1068a263a*/
                }
                if ( (v106 & 1) != 0 ) /*0x1068a2665*/
                  operator delete(a1: v107[0]); /*0x1068a266e*/
                v107[0] = (void *)v114; /*0x1068a267a*/
                v106 = *(_OWORD *)v113; /*0x1068a2689*/
                v108[2] = *(this + 1945); /*0x1068a2698*/
                WORD1(v108[3]) = RBX::Network::NetworkStream::readUInt16(this: (RBX::Network::NetworkStream *)v100); /*0x1068a26ab*/
                RBX::Network::ReportDebugConnectionIssueMetrics(a1: &v106); /*0x1068a26b9*/
              }
LABEL_165:
              if ( (v110 & 1) != 0 ) /*0x1068a2c74*/
                operator delete(a1: v111); /*0x1068a2c7d*/
              RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v100); /*0x1068a2c89*/
              if ( (v106 & 1) != 0 ) /*0x1068a2c95*/
                operator delete(a1: v107[0]); /*0x1068a2ca2*/
LABEL_85:
              v6 = 0; /*0x1068a2450*/
              goto LABEL_86; /*0x1068a2450*/
            }
            v112 = Byte; /*0x1068a2291*/
            if ( v103 < v102 ) /*0x1068a22a4*/
            {
              UInt16 = RBX::Network::NetworkStream::readUInt16(this: (RBX::Network::NetworkStream *)v100); /*0x1068a22ad*/
              if ( UInt16 != 0 ) /*0x1068a22b5*/
              {
                for ( i = UInt16; i != 0; --i ) /*0x1068a22b7*/
                {
                  *(_OWORD *)v113 = 0; /*0x1068a22cc*/
                  *(_QWORD *)&v114 = 0; /*0x1068a22d4*/
                  v37 = RBX::Network::Replicator::getReadPayloadLimit((RBX::Network::Replicator *)this); /*0x1068a22e2*/
                  RBX::Network::deserializeString(a1: v113, a2: v100, a3: v37); /*0x1068a22f3*/
                  std::__hash_table<std::string,std::hash<std::string>,std::equal_to<std::string>,std::allocator<std::string>>::__emplace_unique_key_args<std::string,std::string const&>( /*0x1068a2301*/
                    a1: (__int64)(this + 1562),
                    a2: (unsigned __int8 *)v113,
                    a3: (__int64)v113);
                  if ( ((__int64)v113[0] & 1) != 0 ) /*0x1068a230d*/
                    operator delete(a1: (void *)v114); /*0x1068a2316*/
                }
              }
            }
            *((_BYTE *)this + 12488) = 1; /*0x1068a2321*/
            *((_BYTE *)this + 22584) = 1; /*0x1068a2328*/
            v110 = 0; /*0x1068a2333*/
            v111 = nullptr; /*0x1068a233b*/
            v38 = RBX::Network::Replicator::getReadPayloadLimit((RBX::Network::Replicator *)this); /*0x1068a2349*/
            v39 = v112; /*0x1068a234e*/
            RBX::Network::deserializeString(a1: &v110, a2: v100, a3: v38); /*0x1068a2365*/
            if ( DFFlag::JoinInfoCheckLength == 1 )
            {
              if ( (v110 & 1) != 0 ) /*0x1068a2380*/
                v41 = *((_QWORD *)&v110 + 1); /*0x1068a2386*/
              else
                v41 = (unsigned __int8)v110 >> 1; /*0x1068a26c3*/
              if ( v41 > DFInt::JoinInfoReportingLength ) /*0x1068a26cf*/
              {
                RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1068a26e3*/
                  a1: (__int64)v113,
                  a2: (__int64)&RBX::Telemetry::kJoinInfoLengthLimit);
                std::string::basic_string[abi:ne200100]<0>(a1: &v104, a2: "", a3: v56, a4: v57); /*0x1068a26f6*/
                RBX::Telemetry::FieldsContainer::addPlaceId(this: (RBX::Analytics *)v117); /*0x1068a270c*/
                if ( (v104 & 1) != 0 ) /*0x1068a2718*/
                  operator delete(a1: v105); /*0x1068a2721*/
                if ( (v110 & 1) != 0 ) /*0x1068a2730*/
                  v58 = *((_QWORD *)&v110 + 1); /*0x1068a2732*/
                else
                  v58 = (unsigned __int8)v110 >> 1; /*0x1068a273b*/
                RBX::Telemetry::FieldsContainer::addField(a1: v117, a2: "JoinInfoLength", a3: 14, a4: v58, a5: 1); /*0x1068a2752*/
                RBX::Telemetry::FieldsContainer::addField( /*0x1068a2773*/
                  a1: v117,
                  a2: "JoinInfoLengthLimit",
                  a3: 19,
                  a4: DFInt::JoinInfoMaxLength,
                  a5: 1);
                RBX::Telemetry::FieldsContainer::addField( /*0x1068a2794*/
                  a1: v117,
                  a2: "JoinInfoReportingLengthLimit",
                  a3: 28,
                  a4: DFInt::JoinInfoReportingLength,
                  a5: 1);
                RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v113); /*0x1068a27a0*/
                RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v113); /*0x1068a27b3*/
              }
              if ( DFFlag::JoinInfoCheckLengthThrow == 1 )
              {
                v59 = (v110 & 1) != 0 ? *((_QWORD *)&v110 + 1) : (unsigned __int8)v110 >> 1;
                if ( v59 > DFInt::JoinInfoMaxLength ) /*0x1068a27e1*/
                  RBX::throw_runtime_error(this: (RBX *)"player info json blob max length exceeded", a2: v40); /*0x1068a2cca*/
              }
            }
            if ( DFFlag::JoinInfoJsonLimits == 1 ) /*0x1068a27ee*/
            {
              RBX::WebParser::withDefaultLimits(this: (RBX::WebParser *)v113); /*0x1068a27f7*/
              *(_QWORD *)&v116 = DFInt::JoinInfoVariantCountLimit; /*0x1068a2803*/
              *((_QWORD *)&v116 + 1) = DFInt::JoinInfoVariantCountReportingLimit; /*0x1068a2811*/
              if ( (v110 & 1) != 0 ) /*0x1068a2823*/
              {
                v60 = (char *)v111; /*0x1068a2829*/
                v61 = *((_QWORD *)&v110 + 1); /*0x1068a2830*/
              }
              else
              {
                v61 = (unsigned __int8)v110 >> 1; /*0x1068a28cb*/
                v60 = (char *)&v110 + 1; /*0x1068a28cd*/
              }
              if ( (unsigned __int8)RBX::WebParser::parseJSONTable(a1: v60, a2: v61, a3: this + 2832, a4: 0, a5: v113) == 0 ) /*0x1068a28ee*/
                goto LABEL_140; /*0x1068a28ee*/
              RBX::Players::createServerPlayer(a1: &v96, a2: *(this + 1808), a3: this + 2832, a4: v113); /*0x1068a290c*/
              if ( (_QWORD)v96 != 0 ) /*0x1068a291b*/
              {
                v104 = v96; /*0x1068a291d*/
                if ( *((_QWORD *)&v96 + 1) != 0 ) /*0x1068a2935*/
                  _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v96 + 1) + 8LL)); /*0x1068a2937*/
              }
              else
              {
                v104 = 0; /*0x1068a2975*/
              }
              std::shared_ptr<RBX::Player>::operator=[abi:ne200100](a1: this + 2838, a2: &v104); /*0x1068a298e*/
              std::shared_ptr<RBX::Player>::~shared_ptr[abi:ne200100](a1: &v104); /*0x1068a2996*/
              v65 = &v96; /*0x1068a299b*/
            }
            else
            {
              if ( (v110 & 1) != 0 ) /*0x1068a2847*/
              {
                v62 = (char *)v111; /*0x1068a2849*/
                v63 = *((_QWORD *)&v110 + 1); /*0x1068a2850*/
              }
              else
              {
                v63 = (unsigned __int8)v110 >> 1; /*0x1068a2859*/
                v62 = (char *)&v110 + 1; /*0x1068a285b*/
              }
              if ( (unsigned __int8)RBX::WebParser::parseJSONTable(a1: v62, a2: v63, a3: this + 2832, a4: 0, a5: 0) == 0 ) /*0x1068a2878*/
                goto LABEL_140; /*0x1068a2878*/
              RBX::Players::createServerPlayer(a1: &v104, a2: *(this + 1808), a3: this + 2832, a4: 0); /*0x1068a2891*/
              if ( (_QWORD)v104 != 0 ) /*0x1068a28a0*/
              {
                *(_OWORD *)v113 = v104; /*0x1068a28ad*/
                if ( *((_QWORD *)&v104 + 1) != 0 ) /*0x1068a28be*/
                  _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v104 + 1) + 8LL)); /*0x1068a28c4*/
              }
              else
              {
                *(_OWORD *)v113 = 0; /*0x1068a2942*/
              }
              std::shared_ptr<RBX::Player>::operator=[abi:ne200100](a1: this + 2838, a2: v113); /*0x1068a295b*/
              std::shared_ptr<RBX::Player>::~shared_ptr[abi:ne200100](a1: v113); /*0x1068a2963*/
              v65 = &v104; /*0x1068a2968*/
            }
            std::shared_ptr<RBX::Player>::~shared_ptr[abi:ne200100](a1: v65); /*0x1068a29a2*/
LABEL_140:
            if ( DFFlag::EnablePreloading == 1 )
            {
              v66 = (RBX::Reflection::ValueTable *)*(this + 2832); /*0x1068a29b7*/
              if ( v66 != nullptr )
              {
                v67 = RBX::Reflection::ValueTable::find(this: v66, a2: "PreloadedVersion"); /*0x1068a29ce*/
                if ( v67 != 0 && *(_BYTE *)(*(_QWORD *)(v67 + 40) + 53LL) == 1 )
                {
                  v68 = RBX::Reflection::Variant::get<int>(a1: v67 + 40); /*0x1068a29ed*/
                  *((_DWORD *)this + 5668) = v68; /*0x1068a29f2*/
                  if ( (unsigned __int8)DFLog::NetworkJoin >= 6u && (DFLog::NetworkJoin & 0xFC00) != 0 )
                  {
                    *(_QWORD *)&v104 = v68; /*0x1068a2a26*/
                    v113[0] = (std::__shared_weak_count *)1; /*0x1068a2a29*/
                    v113[1] = (std::__shared_weak_count *)&v104; /*0x1068a2a34*/
                    FLog::detail::FastLogSafeFormattedInternal(
                      a1: DFLog::NetworkJoin,
                      a2: qword_10D7F3E08,
                      a3: 4,
                      a4: (unsigned int)"[DFLog::NetworkJoin] ClientPreloadedVersion received: {}",
                      a5: 56,
                      a6: 1,
                      1,
                      &v104);
                  }
                }
              }
            }
            v69 = (RBX::Player *)*(this + 2838); /*0x1068a2a65*/
            if ( v69 != nullptr ) /*0x1068a2a6f*/
            {
              PlayerGui = RBX::Player::getPlayerGui(this: v69); /*0x1068a2a75*/
              RBX::shared_from<RBX::PlayerGui>(a1: v113, a2: PlayerGui); /*0x1068a2a84*/
              std::shared_ptr<RBX::PlayerGui>::operator=[abi:ne200100](a1: this + 2826, a2: v113); /*0x1068a2a9a*/
              std::shared_ptr<RBX::PlayerGui>::~shared_ptr[abi:ne200100](a1: v113); /*0x1068a2aa2*/
              (*((void (__fastcall **)(void **, _QWORD, _BYTE *))*this + 219))(a1: this, a2: v39, a3: v100); /*0x1068a2ab8*/
              RBX::weak_from<RBX::Network::ServerReplicator>(a1: v113, a2: this); /*0x1068a2ac8*/
              v71 = (__int64)*(this + 1801); /*0x1068a2acd*/
              *(_OWORD *)v99 = *(_OWORD *)v113; /*0x1068a2ae3*/
              if ( v113[1] != nullptr ) /*0x1068a2aee*/
                _InterlockedIncrement64((volatile signed __int64 *)v113[1] + 2); /*0x1068a2af0*/
              v72 = (__int64)*(this + 2838); /*0x1068a2afc*/
              if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x1068a2b06*/
                UserID = *(_QWORD *)(v72 + 208); /*0x1068a2b0c*/
              else
                UserID = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v72 + 176)); /*0x1068a2c39*/
              RBX::Network::MegaReplicator::addReplicatorToJoinQueue(a1: v71, a2: v99, a3: UserID); /*0x1068a2c46*/
              if ( v99[1] != nullptr ) /*0x1068a2c55*/
                std::__shared_weak_count::__release_weak(this: v99[1]); /*0x1068a2c57*/
              if ( v113[1] != nullptr ) /*0x1068a2c66*/
                std::__shared_weak_count::__release_weak(this: v113[1]); /*0x1068a2c68*/
            }
            else
            {
              v74 = (unsigned int)DFLog::NetworkJoin >> 8; /*0x1068a2b24*/
              LOBYTE(v64) = (unsigned __int8)DFLog::NetworkJoin < 6u; /*0x1068a2b2b*/
              LOBYTE(v74) = (unsigned __int8)DFLog::NetworkJoin < 6u || BYTE1(DFLog::NetworkJoin) < 3u; /*0x1068a2b34*/
              if ( (_BYTE)v74 == 0 ) /*0x1068a2b36*/
                FLog::FastLog( /*0x1068a2b45*/
                  a1: *(_QWORD *)&DFLog::NetworkJoin,
                  a2: qword_10D7F3E08,
                  a3: "[DFLog::NetworkJoin] Player Creation Error",
                  0);
              std::string::basic_string[abi:ne200100]<0>(a1: v113, a2: "FailedCreatePlayer", a3: v64, a4: v74); /*0x1068a2b58*/
              RBX::Network::Replicator::reportServerJoinReject(a1: (__int64)this, a2: (__int64)v113); /*0x1068a2b67*/
              if ( ((__int64)v113[0] & 1) != 0 ) /*0x1068a2b73*/
                operator delete(a1: (void *)v114); /*0x1068a2b7c*/
              v113[0] = (std::__shared_weak_count *)"PlayerInstall"; /*0x1068a2b8f*/
              v113[1] = (std::__shared_weak_count *)13; /*0x1068a2b93*/
              std::string::basic_string[abi:ne200100]<0>(a1: &v114, a2: "Player Creation Error", a3: v75, a4: v76); /*0x1068a2ba5*/
              v116 = 0; /*0x1068a2bae*/
              v91 = *(_OWORD *)v113; /*0x1068a2bc4*/
              v93 = v115; /*0x1068a2bcb*/
              v92 = v114; /*0x1068a2bd2*/
              v114 = 0; /*0x1068a2bd6*/
              v115 = nullptr; /*0x1068a2bda*/
              v94 = 0; /*0x1068a2be2*/
              v95 = 1; /*0x1068a2be7*/
              RBX::Network::Replicator::requestDisconnectWithSignal(a1: (__int64)this, a2: 0x106u, a3: &v91); /*0x1068a2bf3*/
              if ( v95 == 1 && (v92 & 1) != 0 ) /*0x1068a2c08*/
                operator delete(a1: v93); /*0x1068a2c11*/
              if ( (v114 & 1) != 0 ) /*0x1068a2c1d*/
                operator delete(a1: v115); /*0x1068a2c26*/
            }
            goto LABEL_165; /*0x1068a2c68*/
          }
          v29 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v100); /*0x1068a209b*/
          *((_BYTE *)this + 22676) = v29; /*0x1068a20a0*/
        }
        *((_BYTE *)this + 22677) = v29; /*0x1068a225f*/
        goto LABEL_68; /*0x1068a225f*/
      case 0x92u:
      case 0x9Eu:
      case 0x9Fu:
      case 0xA0u:
      case 0xA2u:
      case 0xA3u:
      case 0xA4u:
        goto LABEL_86;
      case 0x96u:
        RBX::Network::NetworkStream::NetworkStream( /*0x1068a1d17*/
          this: (RBX::Network::NetworkStream *)v113,
          a2: v4,
          a3: *((_DWORD *)a2 + 12),
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v113, a2: 1u); /*0x1068a1d28*/
        Bool = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v113); /*0x1068a1d39*/
        Int32 = 0; /*0x1068a1d3b*/
        if ( Bool != 0 ) /*0x1068a1d40*/
          Int32 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v113); /*0x1068a1d4e*/
        RBX::weak_from<RBX::Network::ServerReplicator>(a1: &v97, a2: this); /*0x1068a1d5b*/
        RBX::Network::ServerReplicator::toggleSendStatsJob(a1: &v97, a2: Bool, a3: Int32); /*0x1068a1d6d*/
        if ( v98 != nullptr ) /*0x1068a1d7c*/
          std::__shared_weak_count::__release_weak(this: v98); /*0x1068a1d82*/
        goto LABEL_84; /*0x1068a1d87*/
      case 0x99u:
        if ( DFFlag::DebugEnableRemoteProfiling2 != 1 ) /*0x1068a1e63*/
          goto LABEL_86; /*0x1068a1e63*/
        RBX::Network::NetworkStream::NetworkStream( /*0x1068a1e76*/
          this: (RBX::Network::NetworkStream *)v113,
          a2: v4,
          a3: *((_DWORD *)a2 + 12),
          a4: false);
        RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)v113, a2: 1u); /*0x1068a1e87*/
        v14 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v113); /*0x1068a1e93*/
        if ( v14 == 2 ) /*0x1068a1e9b*/
        {
          v47 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v113); /*0x1068a2417*/
          v48 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v113); /*0x1068a2425*/
          v49 = RBX::Network::NetworkStream::readBool(this: (RBX::Network::NetworkStream *)v113); /*0x1068a242f*/
          RBX::Network::ServerReplicator::processMicroProfileRequest( /*0x1068a243f*/
            (RBX::Network::ServerReplicator *)this,
            a2: (RBX::Instance *)v47,
            a3: v48,
            a4: v49);
        }
        else if ( v14 == 1 ) /*0x1068a1ea4*/
        {
          v15 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v113); /*0x1068a1eb6*/
          v16 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)v113); /*0x1068a1ebf*/
          RBX::Network::ServerReplicator::processMicroProfileRequest( /*0x1068a1ecd*/
            (RBX::Network::ServerReplicator *)this,
            a2: (RBX::Instance *)v15,
            a3: v16,
            a4: 0);
        }
LABEL_84:
        RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v113); /*0x1068a2444*/
        goto LABEL_85; /*0x1068a244b*/
      case 0x9Cu:
        v6 = 1; /*0x1068a1d8c*/
        RBX::Network::ServerReplicator::processExtAntiCheat_deprecated(a1: this, a2); /*0x1068a1d98*/
        goto LABEL_86; /*0x1068a1d9d*/
      case 0xA7u:
        if ( RBX::Network::Replicator::getSharedStringCachingEnabled((RBX::Network::Replicator *)this) ) /*0x1068a1e17*/
        {
          if ( *((_BYTE *)*(this + 1927) + 344) != 0 ) /*0x1068a1e32*/
            RBX::throw_runtime_error(this: (RBX *)"Too many shared string hash packets", a2: (const char *)v4); /*0x1068a2cba*/
          NetAssetCachingEnabled = RBX::Network::Replicator::getNetAssetCachingEnabled((RBX::Network::Replicator *)this); /*0x1068a1e3b*/
          v13 = (__int64)*(this + 1927); /*0x1068a1e40*/
          if ( NetAssetCachingEnabled ) /*0x1068a1e49*/
            RBX::Network::SharedStringSynchronizer::processMixedHashPacket(a1: v13, a2); /*0x1068a1e52*/
          else
            RBX::Network::SharedStringSynchronizer::processSharedStringHashPacket(a1: v13, a2); /*0x1068a2236*/
        }
        goto LABEL_86; /*0x1068a1e57*/
      default:
        goto LABEL_35;
    }
  }
  if ( v5 - 21 < 2 ) /*0x1068a1cb3*/
  {
    if ( DFFlag::GameLoadDataStatistics == 1 && *((_BYTE *)this + 22992) == 0 ) /*0x1068a1cf2*/
      RBX::Network::ServerReplicator::reportGameLoadDataStatistics((RBX::Network::ServerReplicator *)this, a2: 1u); /*0x1068a1d00*/
    goto LABEL_35; /*0x1068a1d05*/
  }
  if ( v5 != 14 ) /*0x1068a1cb8*/
  {
    if ( v5 == 19 ) /*0x1068a1cc1*/
    {
      v6 = 1; /*0x1068a1cc7*/
      RBX::Network::ServerReplicator::sendSFFlags((RBX::Network::ServerReplicator *)this); /*0x1068a1cd0*/
      goto LABEL_86; /*0x1068a1cd5*/
    }
LABEL_35:
    v6 = RBX::Network::Replicator::OnReceive_deprecated((RBX::Network::Replicator *)this, a2); /*0x1068a1f95*/
    goto LABEL_86; /*0x1068a1fa3*/
  }
  if ( FFlag::GameStatsHasSpecificAckISR == 1 ) /*0x1068a1fb2*/
  {
    RBX::Network::ServerReplicator::processAckPacketServer_deprecated( /*0x1068a1fbe*/
      (RBX::Network::ServerReplicator *)this,
      (__int64)a2);
  }
  else
  {
    if ( DFFlag::GameLoadDataStatistics == 1 && *((_BYTE *)this + 22992) == 0 ) /*0x1068a2167*/
      RBX::Network::ServerReplicator::reportGameLoadDataStatistics((RBX::Network::ServerReplicator *)this, a2: 0); /*0x1068a216e*/
    RBX::Network::Replicator::processAckPacket_deprecated(a1: (__int64)this, (__int64)a2); /*0x1068a2179*/
  }
LABEL_86:
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v109, a2: (unsigned int)v4); /*0x1068a2453*/
  return v6; /*0x1068a2475*/
}

// Address: 0x1068a3198 | Name: __ZN3RBX7Network16ServerReplicator30processExtAntiCheat_deprecatedEPN6RakNet6PacketE
void __fastcall RBX::Network::ServerReplicator::processExtAntiCheat_deprecated(_QWORD *a1, __int64 a2)
{
  __int64 v4; // rax
  __int64 v5; // r15
  __int64 v6; // rax
  __int64 v7; // rax
  __int64 v8; // r13
  __int64 v9; // rax
  __int64 UserID; // rax
  char v11; // r12
  char *v12; // rbx
  void *v13; // r9
  std::__shared_weak_count *v14; // rbx
  __int64 v15; // [rsp+8h] [rbp-88h]
  std::__shared_weak_count *v16[2]; // [rsp+10h] [rbp-80h] BYREF
  char v17; // [rsp+28h] [rbp-68h] BYREF
  int v18; // [rsp+29h] [rbp-67h] BYREF
  void *v19; // [rsp+38h] [rbp-58h]
  int v20[4]; // [rsp+40h] [rbp-50h] BYREF
  void *v21; // [rsp+50h] [rbp-40h]
  int v22[2]; // [rsp+60h] [rbp-30h]

  v4 = (*(__int64 (__fastcall **)(_QWORD *))(*a1 + 688LL))(a1); /*0x1068a31b2*/
  if ( v4 != 0 ) /*0x1068a31bb*/
  {
    v5 = v4; /*0x1068a31c1*/
    v6 = *(_QWORD *)(v4 + 112); /*0x1068a31c4*/
    if ( (*(_BYTE *)(v6 + 8) & 1) != 0 ) /*0x1068a31cc*/
    {
      std::string::__init_copy_ctor_external(a1: v20, a2: *(_QWORD *)(v6 + 24), a3: *(_QWORD *)(v6 + 16)); /*0x1068a31ef*/
    }
    else
    {
      v7 = v6 + 8; /*0x1068a31ce*/
      v21 = *(void **)(v7 + 16); /*0x1068a31d6*/
      *(_OWORD *)v20 = *(_OWORD *)v7; /*0x1068a31dd*/
    }
    v8 = a1[2828]; /*0x1068a31f4*/
    v9 = *(_QWORD *)(v5 + 2376); /*0x1068a31fb*/
    *(_OWORD *)v16 = *(_OWORD *)(v5 + 2368); /*0x1068a320a*/
    if ( v9 != 0 ) /*0x1068a3211*/
      _InterlockedIncrement64((volatile signed __int64 *)(v9 + 8)); /*0x1068a3213*/
    v15 = a2; /*0x1068a3222*/
    if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x1068a3229*/
      UserID = *(_QWORD *)(v5 + 208); /*0x1068a322b*/
    else
      UserID = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v5 + 176)); /*0x1068a323e*/
    *(_QWORD *)v22 = UserID; /*0x1068a3243*/
    v11 = v20[0]; /*0x1068a3247*/
    v12 = (char *)v21; /*0x1068a324b*/
    RBX::Player::getOsPlatformServerOnly(this: (RBX::Player *)&v17); /*0x1068a3256*/
    if ( (v11 & 1) == 0 ) /*0x1068a3263*/
      v12 = (char *)v20 + 1; /*0x1068a3263*/
    if ( (v17 & 1) != 0 ) /*0x1068a326b*/
      v13 = v19; /*0x1068a326d*/
    else
      v13 = &v18; /*0x1068a3273*/
    RBX::Network::Server::handleExtAntiCheat_deprecated( /*0x1068a3297*/
      a1: v8,
      a2: v15,
      a3: (int)v16,
      a4: *(__int64 *)v22,
      a5: (__int64)v12,
      a6: (__int64)v13,
      a7: (RakNet::SystemAddress *)(a1 + 30));
    if ( (v17 & 1) != 0 ) /*0x1068a32a0*/
      operator delete(a1: v19); /*0x1068a32a6*/
    v14 = v16[1]; /*0x1068a32ab*/
    if ( v16[1] != nullptr /*0x1068a32c4*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v16[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x1068a32cc*/
      std::__shared_weak_count::__release_weak(this: v14); /*0x1068a32d2*/
    }
    if ( (v20[0] & 1) != 0 ) /*0x1068a32db*/
      operator delete(a1: v21); /*0x1068a32e1*/
  }
}

// Address: 0x1068a332e | Name: __ZNK3RBX7Network16ServerReplicator12joinDataSentEv
char __fastcall RBX::Network::ServerReplicator::joinDataSent(RBX::Network::ServerReplicator *this)
{
  if ( *(_BYTE *)(*((_QWORD *)this + 2828) + 4497LL) != 0 ) /*0x1068a3340*/
    return 0; /*0x1068a3342*/
  else
    return *((_BYTE *)this + 18410); /*0x1068a3346*/
}

// Address: 0x1068a334e | Name: __ZN3RBX7Network16ServerReplicator17sendClusterPacketEi
__int64 __fastcall RBX::Network::ServerReplicator::sendClusterPacket(RBX::Network::ServerReplicator *this, int a2)
{
  unsigned int v4; // eax
  unsigned int v5; // ebx
  __int64 v6; // rax
  int v7; // eax

  v4 = RBX::Network::Replicator::sendClusterPacket(this, a2); /*0x1068a335e*/
  if ( v4 != 0 ) /*0x1068a3365*/
  {
    v5 = v4; /*0x1068a3367*/
    if ( *(_BYTE *)(*((_QWORD *)this + 2828) + 4497LL) == 1 ) /*0x1068a3377*/
    {
      while ( *((_BYTE *)this + 10540) == 0 ) /*0x1068a3379*/
      {
        v6 = *((_QWORD *)this + 1315); /*0x1068a3383*/
        if ( v6 == 0 ) /*0x1068a338d*/
          break; /*0x1068a338d*/
        if ( *(_DWORD *)(v6 + 64) != 2 ) /*0x1068a3393*/
          break; /*0x1068a3393*/
        v7 = RBX::Network::Replicator::sendClusterPacket(this, a2); /*0x1068a339b*/
        if ( v7 == 0 ) /*0x1068a33a2*/
          break; /*0x1068a33a2*/
        v5 += v7; /*0x1068a33a4*/
      }
    }
  }
  else
  {
    return 0; /*0x1068a33a8*/
  }
  return v5; /*0x1068a33b0*/
}

// Address: 0x1068a33b8 | Name: __ZN3RBX7Network16ServerReplicator23readHashItem_DEPRECATEDERNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::ServerReplicator::readHashItem_DEPRECATED(
        RBX::Network::ServerReplicator *this,
        RBX::Network::NetworkStream *a2)
{
  unsigned __int8 Byte; // al
  __int64 i; // r15
  __int64 result; // rax
  unsigned __int8 v7; // al

  Byte = RBX::Network::NetworkStream::readByte(this: a2); /*0x1068a33cb*/
  if ( Byte == 0xFF ) /*0x1068a33d2*/
  {
    v7 = RBX::Network::NetworkStream::readByte(this: a2); /*0x1068a3410*/
    return RBX::Network::NetworkStream::IgnoreBytes(this: a2, a2: 4 * (unsigned int)v7 + 4); /*0x1068a342c*/
  }
  else
  {
    RBX::Network::NetworkStream::IgnoreBytes(this: a2, a2: 4 * Byte + 4); /*0x1068a33e1*/
    for ( i = 0; i != 3; ++i ) /*0x1068a33e6*/
    {
      result = RBX::Network::NetworkStream::readUInt64(this: a2); /*0x1068a33ec*/
      *((_QWORD *)this + i + 2860) = result; /*0x1068a33f1*/
    }
  }
  return result; /*0x1068a3406*/
}

// Address: 0x1068a3432 | Name: __ZN3RBX7Network16ServerReplicator24readRockyItem_DEPRECATEDERNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::ServerReplicator::readRockyItem_DEPRECATED(
        RBX::Network::ServerReplicator *this,
        RBX::Network::NetworkStream *a2)
{
  __int64 result; // rax

  result = RBX::Network::NetworkStream::readByte(this: a2); /*0x1068a343e*/
  if ( (_BYTE)result == 0 ) /*0x1068a3445*/
  {
    RBX::Network::NetworkStream::readUInt32(this: a2); /*0x1068a3451*/
    RBX::Network::NetworkStream::readUInt32(this: a2); /*0x1068a3459*/
    RBX::Network::NetworkStream::readUInt32(this: a2); /*0x1068a3461*/
    RBX::Network::NetworkStream::readUInt32(this: a2); /*0x1068a3469*/
    return RBX::Network::NetworkStream::readUInt32(this: a2); /*0x1068a3477*/
  }
  return result; /*0x1068a344b*/
}

// Address: 0x1068a347c | Name: __ZN3RBX7Network16ServerReplicator17getClientFpsStatsERfS2_S2_
void __fastcall RBX::Network::ServerReplicator::getClientFpsStats(
        RBX::Network::ServerReplicator *this,
        float *a2,
        float *a3,
        float *a4)
{
  float v4; // xmm0_4
  float v5; // xmm0_4
  float v6; // xmm0_4

  v4 = *((double *)this + 2846); /*0x1068a3480*/
  *a2 = v4; /*0x1068a3488*/
  v5 = *((double *)this + 2851); /*0x1068a348f*/
  *a3 = v5; /*0x1068a3497*/
  v6 = *((double *)this + 2856); /*0x1068a349e*/
  *a4 = v6; /*0x1068a34a6*/
}

// Address: 0x1068a34ac | Name: __ZN3RBX7Network16ServerReplicator15processDataPingEPKNS0_20DeserializedPingItemE
__int64 __fastcall RBX::Network::ServerReplicator::processDataPing(
        RBX::Network::ServerReplicator *this,
        const RBX::Network::DeserializedPingItem *a2)
{
  unsigned __int64 v4; // r15
  __int64 result; // rax
  float v6; // xmm0_4

  v4 = RakNet::GetTime(this: nullptr, (bool)a2) - *((_QWORD *)this + 854); /*0x1068a34c6*/
  result = RBX::Network::Replicator::processDataPing(this, a2); /*0x1068a34d3*/
  if ( v4 >= 0x12D ) /*0x1068a34df*/
  {
    RBX::RunningAverage<float,double>::sample( /*0x1068a34ee*/
      a1: (char *)this + 22752,
      a2: COERCE_DOUBLE((unsigned __int64)*((_DWORD *)a2 + 20)));
    RBX::RunningAverage<float,double>::sample( /*0x1068a3500*/
      a1: (char *)this + 22792,
      a2: COERCE_DOUBLE((unsigned __int64)*((_DWORD *)a2 + 21)));
    result = RBX::RunningAverage<float,double>::sample( /*0x1068a3512*/
               a1: (char *)this + 22832,
               a2: COERCE_DOUBLE((unsigned __int64)*((_DWORD *)a2 + 22)));
  }
  v6 = *((float *)a2 + 23); /*0x1068a3517*/
  if ( v6 > 0.0 ) /*0x1068a3523*/
  {
    result = *((_QWORD *)this + 2838); /*0x1068a3525*/
    if ( result != 0 ) /*0x1068a352f*/
      *(float *)(result + 1624) = v6; /*0x1068a3531*/
  }
  return result; /*0x1068a353d*/
}

// Address: 0x1068a360a | Name: __ZN3RBX7Network16ServerReplicator31processDeserializedJoinDataItemEPNS0_24DeserializedJoinDataItemE
__int64 __fastcall RBX::Network::ServerReplicator::processDeserializedJoinDataItem(
        RBX::Network::ServerReplicator *this,
        RBX::Network::DeserializedJoinDataItem *a2)
{
  __int64 i; // rax
  RBX *exception; // rbx

  for ( i = *((_QWORD *)a2 + 4); i != *((_QWORD *)a2 + 5); i += 216 ) /*0x1068a3611*/
  {
    if ( *(_BYTE *)(i + 144) == 0 ) /*0x1068a3625*/
    {
      exception = (RBX *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x1068a3642*/
      RBX::runtime_error(this: exception, a2: "Malformed Join"); /*0x1068a3651*/
      __cxa_throw( /*0x1068a3667*/
        a1: exception,
        lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
        a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
    }
  }
  return RBX::Network::Replicator::processDeserializedJoinDataItem(this, a2); /*0x1068a362f*/
}

// Address: 0x1068a3680 | Name: __ZN3RBX7Network16ServerReplicator8readItemERNS0_13NetworkStreamENS0_4Item8ItemTypeEy
RBX::Network::ServerReplicator *__fastcall RBX::Network::ServerReplicator::readItem(
        RBX::Network::ServerReplicator *a1,
        RBX::Network::ServerReplicator *a2,
        RBX::Network::NetworkStream *a3,
        __int64 a4,
        __int64 a5)
{
  RBX::Network::Replicator::StreamJob *v7; // rdi
  RBX::Network::Replicator::StreamJob *v8; // rdi
  RBX::Network::Replicator::StreamJob *v9; // rdi
  void *v10; // rdi
  __int64 v11; // rcx
  __int128 v13; // [rsp+0h] [rbp-110h] BYREF
  __int128 v14; // [rsp+10h] [rbp-100h]
  void *v15; // [rsp+20h] [rbp-F0h]
  __int128 v16; // [rsp+28h] [rbp-E8h]
  char v17; // [rsp+38h] [rbp-D8h]
  __int128 v18; // [rsp+40h] [rbp-D0h] BYREF
  __int128 v19; // [rsp+50h] [rbp-C0h]
  void *v20; // [rsp+60h] [rbp-B0h]
  __int128 v21; // [rsp+68h] [rbp-A8h]
  char v22; // [rsp+78h] [rbp-98h]
  __int128 v23; // [rsp+80h] [rbp-90h] BYREF
  __int128 v24; // [rsp+90h] [rbp-80h]
  void *v25; // [rsp+A0h] [rbp-70h]
  __int128 v26; // [rsp+A8h] [rbp-68h]
  char v27; // [rsp+B8h] [rbp-58h]
  __int128 v28; // [rsp+C0h] [rbp-50h]
  __int128 v29; // [rsp+D0h] [rbp-40h] BYREF
  void *v30; // [rsp+E0h] [rbp-30h]
  __int128 v31; // [rsp+E8h] [rbp-28h]

  switch ( (int)a4 ) /*0x1068a36ac*/
  {
    case 8: /*0x1068a36ac*/
      RBX::Network::ServerReplicator::readRequestCharacter(this: a2, a2: a3); /*0x1068a36b4*/
      goto LABEL_33; /*0x1068a36b9*/
    case 9: /*0x1068a36ac*/
      RBX::Network::ServerReplicator::readRockyItem_DEPRECATED(this: a1, a2: a3); /*0x1068a3725*/
      goto LABEL_33; /*0x1068a372a*/
    case 10: /*0x1068a36ac*/
      RBX::Network::ServerReplicator::readCFrameAcknowledgement(this: a2, a2: a3); /*0x1068a3752*/
      goto LABEL_33; /*0x1068a3757*/
    case 11: /*0x1068a36ac*/
    case 12: /*0x1068a36ac*/
    case 13: /*0x1068a36ac*/
    case 16: /*0x1068a36ac*/
    case 17: /*0x1068a36ac*/
      goto LABEL_6;
    case 14: /*0x1068a36ac*/
      v7 = *((RBX::Network::Replicator::StreamJob **)a2 + 1815); /*0x1068a3705*/
      if ( v7 != nullptr ) /*0x1068a370f*/
      {
        RBX::Network::Replicator::StreamJob::readRegionRemoval(this: v7, a2: a3); /*0x1068a3718*/
        goto LABEL_33; /*0x1068a371d*/
      }
      *(_QWORD *)&v28 = "Streaming"; /*0x1068a37a4*/
      *((_QWORD *)&v28 + 1) = 9; /*0x1068a37a8*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v29, a2: "No StreamJob when recv RegionRemovalItem", a3, a4); /*0x1068a37ba*/
      v31 = 0; /*0x1068a37c2*/
      v13 = v28; /*0x1068a37d7*/
      v14 = v29; /*0x1068a37da*/
      v15 = v30; /*0x1068a37e2*/
      v29 = 0; /*0x1068a37e6*/
      v30 = nullptr; /*0x1068a37ea*/
      v16 = 0; /*0x1068a37f2*/
      v17 = 1; /*0x1068a37f6*/
      RBX::Network::Replicator::requestDisconnect(a1: (__int64)a2, a2: 0x106u, a3: &v13); /*0x1068a3802*/
      if ( v17 != 1 || (v14 & 1) == 0 ) /*0x1068a381b*/
        goto LABEL_31; /*0x1068a381b*/
      v10 = v15; /*0x1068a3821*/
      goto LABEL_30; /*0x1068a3828*/
    case 15: /*0x1068a36ac*/
      v8 = *((RBX::Network::Replicator::StreamJob **)a2 + 1815); /*0x1068a372f*/
      if ( v8 != nullptr ) /*0x1068a3739*/
      {
        RBX::Network::Replicator::StreamJob::readInstanceRemoval(this: v8, a2: a3); /*0x1068a3742*/
        goto LABEL_33; /*0x1068a3747*/
      }
      *(_QWORD *)&v28 = "Streaming"; /*0x1068a3838*/
      *((_QWORD *)&v28 + 1) = 9; /*0x1068a383c*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v29, a2: "No StreamJob when recv InstanceRemovalItem", a3, a4); /*0x1068a384e*/
      v31 = 0; /*0x1068a3856*/
      v23 = v28; /*0x1068a386b*/
      v24 = v29; /*0x1068a386e*/
      v25 = v30; /*0x1068a3876*/
      v29 = 0; /*0x1068a387a*/
      v30 = nullptr; /*0x1068a387e*/
      v26 = 0; /*0x1068a3886*/
      v27 = 1; /*0x1068a388a*/
      RBX::Network::Replicator::requestDisconnect(a1: (__int64)a2, a2: 0x106u, a3: &v23); /*0x1068a3896*/
      if ( v27 != 1 || (v24 & 1) == 0 ) /*0x1068a38a9*/
        goto LABEL_31; /*0x1068a38a9*/
      v10 = v25; /*0x1068a38af*/
      goto LABEL_30; /*0x1068a38b3*/
    case 18: /*0x1068a36ac*/
      RBX::Network::ServerReplicator::readHashItem_DEPRECATED(this: a2, a2: a3); /*0x1068a3762*/
      goto LABEL_33; /*0x1068a3767*/
    default:
      if ( (_DWORD)a4 == 25 ) /*0x1068a36c1*/
      {
        v9 = *((RBX::Network::Replicator::StreamJob **)a2 + 1815); /*0x1068a376c*/
        if ( v9 != nullptr ) /*0x1068a3776*/
        {
          RBX::Network::Replicator::StreamJob::readPrefetchRequest(this: v9, a2: a3); /*0x1068a377f*/
        }
        else
        {
          v11 = (unsigned int)FLog::Network >> 8; /*0x1068a38c4*/
          LOBYTE(a3) = (unsigned __int8)FLog::Network < 6u; /*0x1068a38cb*/
          LOBYTE(v11) = (unsigned __int8)FLog::Network < 6u || BYTE1(FLog::Network) < 3u; /*0x1068a38d4*/
          if ( (_BYTE)v11 == 0 ) /*0x1068a38d6*/
            FLog::FastLog( /*0x1068a38e5*/
              a1: FLog::Network,
              a2: qword_10D7BBAA8,
              a3: "[FLog::Network] Disconnecting because got prefetch request but not streaming enabled.",
              0);
          *(_QWORD *)&v28 = "Streaming"; /*0x1068a38f5*/
          *((_QWORD *)&v28 + 1) = 9; /*0x1068a38f9*/
          std::string::basic_string[abi:ne200100]<0>( /*0x1068a390b*/
            a1: &v29,
            a2: "Disconnecting because got prefetch request but not streaming enabled.",
            a3,
            a4: v11);
          v31 = 0; /*0x1068a3913*/
          v18 = v28; /*0x1068a3928*/
          v19 = v29; /*0x1068a392b*/
          v20 = v30; /*0x1068a3933*/
          v29 = 0; /*0x1068a3937*/
          v30 = nullptr; /*0x1068a393b*/
          v21 = 0; /*0x1068a3943*/
          v22 = 1; /*0x1068a3947*/
          RBX::Network::Replicator::requestDisconnect(a1: (__int64)a2, a2: 0x106u, a3: &v18); /*0x1068a3953*/
          if ( v22 == 1 && (v19 & 1) != 0 ) /*0x1068a3968*/
          {
            v10 = v20; /*0x1068a396a*/
LABEL_30:
            operator delete(a1: v10); /*0x1068a3971*/
          }
LABEL_31:
          if ( (v29 & 1) != 0 ) /*0x1068a397a*/
            operator delete(a1: v30); /*0x1068a3980*/
        }
        goto LABEL_33; /*0x1068a3784*/
      }
      if ( (_DWORD)a4 == 28 ) /*0x1068a36ca*/
      {
        RBX::Network::ServerReplicator::readClientStreamQuotaUpdate(this: a2, a2: a3); /*0x1068a36d2*/
LABEL_33:
        *(_DWORD *)a1 = 1; /*0x1068a3985*/
        *((_QWORD *)a1 + 1) = 0; /*0x1068a398b*/
        return a1; /*0x1068a398b*/
      }
LABEL_6:
      if ( (_DWORD)a4 == 7 && DFFlag::LatencyLoggingRemoteName != 0 ) /*0x1068a36ef*/
        LODWORD(a4) = 7; /*0x1068a36fb*/
      RBX::Network::Replicator::readItem((__int64)a1, (__int64)a2, a3, a4, a5); /*0x1068a378f*/
      return a1; /*0x1068a3996*/
  }
}

// Address: 0x1068a3a3c | Name: __ZN3RBX7Network16ServerReplicator27readClientStreamQuotaUpdateERNS0_13NetworkStreamE
char __fastcall RBX::Network::ServerReplicator::readClientStreamQuotaUpdate(
        RBX::Network::ServerReplicator *this,
        RBX::Network::NetworkStream *a2)
{
  char Int8; // r14
  __int16 Int16; // r15
  int UInt32; // eax
  char Byte; // bl
  __int64 v8; // rdi
  __int64 v9; // rdi
  unsigned int Int32; // [rsp+14h] [rbp-2Ch]

  Int8 = RBX::Network::NetworkStream::readInt8(this: a2); /*0x1068a3a5b*/
  Int32 = RBX::Network::NetworkStream::readInt32(this: a2); /*0x1068a3a66*/
  Int16 = RBX::Network::NetworkStream::readInt16(this: a2); /*0x1068a3a71*/
  LOBYTE(UInt32) = RBX::Network::Replicator::getGcRegionQuotaSourceCapability(this); /*0x1068a3a77*/
  if ( (_BYTE)UInt32 != 0 ) /*0x1068a3a7e*/
  {
    Byte = RBX::Network::NetworkStream::readByte(this: a2); /*0x1068a3a88*/
    UInt32 = RBX::Network::NetworkStream::readUInt32(this: a2); /*0x1068a3a8d*/
    v8 = *((_QWORD *)this + 1815); /*0x1068a3a92*/
    if ( v8 != 0 ) /*0x1068a3a9d*/
      LOBYTE(UInt32) = RBX::Network::Replicator::StreamJob::updateClientQuota( /*0x1068a3abf*/
                         a1: v8,
                         a2: Int32,
                         a3: (unsigned int)Int16,
                         a4: (unsigned int)Int8,
                         a5: Byte & 1,
                         a6: (Byte & 2) != 0,
                         a7: UInt32);
  }
  else
  {
    v9 = *((_QWORD *)this + 1815); /*0x1068a3ac1*/
    if ( v9 != 0 ) /*0x1068a3acc*/
      LOBYTE(UInt32) = RBX::Network::Replicator::StreamJob::updateClientQuota( /*0x1068a3ae6*/
                         a1: v9,
                         a2: Int32,
                         a3: (unsigned int)Int16,
                         a4: (unsigned int)Int8,
                         a5: 0,
                         a6: 0,
                         a7: 0);
  }
  return UInt32; /*0x1068a3aeb*/
}

// Address: 0x1068a3afa | Name: __ZN3RBX7Network16ServerReplicator20readRequestCharacterERNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::ServerReplicator::readRequestCharacter(
        RBX::Network::ServerReplicator *this,
        RBX::Network::NetworkStream *a2)
{
  RBX::Analytics::InfluxDb::Points *v4; // r15
  double v5; // xmm0_8
  __int64 result; // rax
  std::__shared_weak_count *v7; // rbx
  void *exception; // rbx
  char v9; // r12
  const char *v10; // r15
  const char *v11; // rcx
  _BYTE v12[16]; // [rsp+0h] [rbp-A0h] BYREF
  void *v13; // [rsp+10h] [rbp-90h]
  _BYTE v14[24]; // [rsp+18h] [rbp-88h] BYREF
  __int128 v15; // [rsp+30h] [rbp-70h] BYREF
  __int64 v16; // [rsp+48h] [rbp-58h] BYREF
  char v17; // [rsp+50h] [rbp-50h] BYREF
  char v18; // [rsp+51h] [rbp-4Fh] BYREF
  const char *v19; // [rsp+60h] [rbp-40h]
  char v20; // [rsp+68h] [rbp-38h] BYREF
  char v21; // [rsp+69h] [rbp-37h] BYREF
  const char *v22; // [rsp+78h] [rbp-28h]

  v4 = (RBX::Network::ServerReplicator *)((char *)this + 22112); /*0x1068a3b12*/
  RBX::Time::nowFast(this); /*0x1068a3b19*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068a3b31*/
    this: v4,
    a2: "CharacterRequestReceived",
    a3: v5 - *((double *)this + 2762));
  RBX::Network::NetworkStream::readUInt32(this: a2); /*0x1068a3b39*/
  RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1068a3b41*/
  RBX::Network::NetworkStream::readString(this: (RBX::Network::NetworkStream *)v12, (int)a2); /*0x1068a3b55*/
  if ( (v12[0] & 1) != 0 ) /*0x1068a3b5e*/
    operator delete(a1: v13); /*0x1068a3b67*/
  v15 = 0; /*0x1068a3b74*/
  v16 = 0xFFFFFFFFLL; /*0x1068a3b81*/
  result = RBX::Network::IdSerializer::deserializeObjectRef(a1: this, a2, a3: &v15, a4: &v16); /*0x1068a3b8a*/
  if ( (_BYTE)result == 0 ) /*0x1068a3b91*/
  {
    if ( (unsigned __int8)FLog::Error >= 6u && BYTE1(FLog::Error) >= 3u ) /*0x1068a3be8*/
      FLog::FastLog( /*0x1068a3bfc*/
        a1: *(_QWORD *)&FLog::Error,
        a2: qword_10D7BE948,
        a3: "[FLog::Error] RequestCharacter - could not resolve RemotePlayer",
        0);
    exception = __cxa_allocate_exception(thrown_size: 0x10u); /*0x1068a3c0b*/
    RBX::Guid::readableString(this: (RBX::Guid *)&v20, a2: (int)&v16); /*0x1068a3c1b*/
    v9 = v20; /*0x1068a3c20*/
    v10 = v22; /*0x1068a3c24*/
    RBX::Network::RakNetAddressToString( /*0x1068a3c40*/
      this: (RBX::Network *)&v17,
      a2: (RBX::Network::ServerReplicator *)((char *)this + 240),
      a3: true,
      a4: 124);
    if ( (v9 & 1) == 0 ) /*0x1068a3c4d*/
      v10 = &v21; /*0x1068a3c4d*/
    if ( (v17 & 1) != 0 ) /*0x1068a3c55*/
      v11 = v19; /*0x1068a3c57*/
    else
      v11 = &v18; /*0x1068a3c5d*/
    RBX::format(this: (RBX *)v14, a2: "Couldn't resolve remotePlayer %s from %s", v10, v11); /*0x1068a3c74*/
    std::runtime_error::runtime_error(a1: exception, a2: v14); /*0x1068a3c86*/
    __cxa_throw( /*0x1068a3c9f*/
      a1: exception,
      lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
      a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
  }
  v7 = *((std::__shared_weak_count **)&v15 + 1); /*0x1068a3b93*/
  if ( *((_QWORD *)&v15 + 1) != 0 ) /*0x1068a3b9a*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v15 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL); /*0x1068a3ba3*/
    if ( result == 0 ) /*0x1068a3bac*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x1068a3bb4*/
      return std::__shared_weak_count::__release_weak(this: v7); /*0x1068a3bba*/
    }
  }
  return result; /*0x1068a3bbf*/
}

// Address: 0x1068a3d1e | Name: __ZN3RBX7Network16ServerReplicator25readCFrameAcknowledgementERNS0_13NetworkStreamE
char __fastcall RBX::Network::ServerReplicator::readCFrameAcknowledgement(
        RBX::Network::ServerReplicator *this,
        RBX::Network::NetworkStream *a2)
{
  unsigned __int16 UInt16; // r15
  __int64 v5; // r13
  int Int32; // r14d
  __int64 EngineNetConfiguration; // rax
  __int64 v8; // rdi
  __int64 v9; // rsi
  RBX::BasePart *v10; // r15
  __int64 v11; // r12
  unsigned int v12; // ecx
  RBX::Workspace *v13; // r12
  RBX::Network::InstanceReplication::RbxInstanceReplicatorManager *v14; // rdi
  int LocalTimestampFromRemote; // eax
  std::__shared_weak_count *v16; // rbx
  RBX::BasePart *v18; // [rsp+10h] [rbp-40h] BYREF
  std::__shared_weak_count *v19; // [rsp+18h] [rbp-38h]
  _BYTE v20[4]; // [rsp+20h] [rbp-30h] BYREF
  int v21; // [rsp+24h] [rbp-2Ch]

  RBX::Network::IdSerializer::deserializeId(this, a2); /*0x1068a3d35*/
  UInt16 = RBX::Network::NetworkStream::readUInt16(this: a2); /*0x1068a3d46*/
  (*(void (__fastcall **)(RBX::Network::ServerReplicator *, RBX::Network::NetworkStream *, _BYTE *))(*(_QWORD *)this + 1104LL))( /*0x1068a3d56*/
    a1: this,
    a2,
    a3: v20);
  v5 = *((_QWORD *)this + 1945); /*0x1068a3d5c*/
  Int32 = 0; /*0x1068a3d63*/
  if ( (v5 & 0x200000000LL) != 0 ) /*0x1068a3d6b*/
    Int32 = RBX::Network::NetworkStream::readInt32(this: a2); /*0x1068a3d75*/
  LOBYTE(EngineNetConfiguration) = RBX::GuidItem<RBX::Object>::Registry::getByGuid(a1: &v18, a2: *((_QWORD *)this + 22)); /*0x1068a3d8a*/
  if ( v18 != nullptr && v20[1] == 1 ) /*0x1068a3da0*/
  {
    RBX::Network::PropSync::Master::masterOnReceivedAcknowledgement( /*0x1068a3db4*/
      this: (RBX::Network::ServerReplicator *)((char *)this + 21792),
      a2: v18,
      a3: UInt16,
      a4: v21);
    EngineNetConfiguration = RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::NetworkSchema *)(*((_QWORD *)this + 1801) + 1608LL)); /*0x1068a3dc5*/
    if ( FFlag::DebugHashTableMetrics == 0 ) /*0x1068a3dd4*/
    {
      if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x1068a3e65*/
      {
        EngineNetConfiguration = *(_QWORD *)EngineNetConfiguration; /*0x1068a3e67*/
        if ( (EngineNetConfiguration & 8) == 0 && (EngineNetConfiguration & 1) == 0 ) /*0x1068a3e74*/
        {
          EngineNetConfiguration = (__int64)&FFlag::NextGenReplicatorEnabledWrite; /*0x1068a3e7a*/
          if ( FFlag::NextGenReplicatorEnabledWrite == 0 ) /*0x1068a3e84*/
            goto LABEL_18; /*0x1068a3e84*/
        }
      }
      else
      {
        EngineNetConfiguration = (__int64)&FFlag::NextGenReplicatorEnabledRead; /*0x1068a3e8b*/
        if ( FFlag::NextGenReplicatorEnabledRead == 0 ) /*0x1068a3e95*/
          goto LABEL_18; /*0x1068a3e95*/
        EngineNetConfiguration = (__int64)&FFlag::NextGenReplicatorEnabledWrite; /*0x1068a3e97*/
        if ( FFlag::NextGenReplicatorEnabledWrite != 1 ) /*0x1068a3ea1*/
          goto LABEL_18; /*0x1068a3ea1*/
      }
    }
    v10 = v18; /*0x1068a3dda*/
    if ( v18 != nullptr ) /*0x1068a3de1*/
    {
      v11 = *((_QWORD *)v18 + 3); /*0x1068a3de7*/
      EngineNetConfiguration = RBX::Reflection::Class_getDescriptorPtr<RBX::BasePart>(a1: v8, a2: v9); /*0x1068a3deb*/
      v12 = *(unsigned __int16 *)(v11 + 440) - *(unsigned __int16 *)(EngineNetConfiguration + 440); /*0x1068a3e00*/
      LODWORD(EngineNetConfiguration) = *(unsigned __int16 *)(EngineNetConfiguration + 442); /*0x1068a3e02*/
      if ( v12 <= (unsigned int)EngineNetConfiguration ) /*0x1068a3e0b*/
      {
        v13 = (RBX::Workspace *)RBX::ServiceProvider::find<RBX::Workspace>(a1: v10); /*0x1068a3e19*/
        LOBYTE(EngineNetConfiguration) = (v5 & 0x200000000LL) == 0; /*0x1068a3e21*/
        if ( ((unsigned __int8)EngineNetConfiguration | (v13 == nullptr)) == 0 ) /*0x1068a3e2c*/
        {
          EngineNetConfiguration = *((_QWORD *)this + 1801); /*0x1068a3e2e*/
          v14 = *(RBX::Network::InstanceReplication::RbxInstanceReplicatorManager **)(EngineNetConfiguration + 920); /*0x1068a3e35*/
          if ( v14 != nullptr ) /*0x1068a3e3f*/
          {
            LocalTimestampFromRemote = RBX::Network::InstanceReplication::RbxInstanceReplicatorManager::getLocalTimestampFromRemote( /*0x1068a3e47*/
                                         this: v14,
                                         a2: this,
                                         a3: Int32);
            LOBYTE(EngineNetConfiguration) = RBX::Workspace::blockStaleInstanceSynchDataAtTimestamp( /*0x1068a3e54*/
                                               this: v13,
                                               a2: v10,
                                               a3: LocalTimestampFromRemote);
          }
        }
      }
    }
  }
LABEL_18:
  v16 = v19; /*0x1068a3ea7*/
  if ( v19 != nullptr ) /*0x1068a3eae*/
  {
    EngineNetConfiguration = _InterlockedExchangeAdd64((volatile signed __int64 *)v19 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x1068a3eb7*/
    if ( EngineNetConfiguration == 0 ) /*0x1068a3ec0*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x1068a3ec8*/
      LOBYTE(EngineNetConfiguration) = std::__shared_weak_count::__release_weak(this: v16); /*0x1068a3ece*/
    }
  }
  return EngineNetConfiguration; /*0x1068a3ed3*/
}

// Address: 0x1068a3efc | Name: __ZN3RBX7Network16ServerReplicator18resetSecurityTimesEv
__int64 __fastcall RBX::Network::ServerReplicator::resetSecurityTimes(RBX::Network::ServerReplicator *this)
{
  return RBX::Network::ReplicatorStats::resetSecurityTimes(this: (RBX::Network::ServerReplicator *)((char *)this + 1456)); /*0x1068a3f07*/
}

// Address: 0x1068a3f0e | Name: __ZN3RBX7Network16ServerReplicator29filterReceivedChangedPropertyEPNS_6ObjectERKNS_10Reflection18PropertyDescriptorEtRKNS0_17ChangeVersionInfoE
__int64 __fastcall RBX::Network::ServerReplicator::filterReceivedChangedProperty(
        RBX::Network::StrictNetworkFilter **this,
        RBX::Object *a2,
        const RBX::Reflection::PropertyDescriptor *a3,
        unsigned __int16 a4,
        __int64 a5)
{
  unsigned int v9; // r14d
  __int64 v10; // r14
  __int64 v11; // rax
  const RBX::Humanoid *v12; // rsi
  RBX::Network::StrictNetworkFilter *v13; // rdi
  __int64 v15; // rdi
  __int64 ConstCharacterFromHumanoid; // [rsp+0h] [rbp-40h]
  __int64 v17; // [rsp+8h] [rbp-38h] BYREF
  RBX::Object *v18; // [rsp+10h] [rbp-30h]

  v18 = a2; /*0x1068a3f28*/
  if ( RBX::HumanoidProperties::prop_JumpReplicate == (_UNKNOWN *)a3 /*0x1068a3f45*/
    || RBX::HumanoidProperties::prop_Sit == (_UNKNOWN *)a3 )
  {
    if ( v18 != nullptr ) /*0x1068a3f82*/
    {
      v10 = *((_QWORD *)v18 + 3); /*0x1068a3f88*/
      v11 = RBX::Reflection::Class_getDescriptorPtr<RBX::Humanoid>(a1: this); /*0x1068a3f8c*/
      if ( *(unsigned __int16 *)(v10 + 440) - (unsigned int)*(unsigned __int16 *)(v11 + 440) <= *(unsigned __int16 *)(v11 + 442) /*0x1068a3fb5*/
        && *(this + 2824) != nullptr )
      {
        ConstCharacterFromHumanoid = RBX::Humanoid::getConstCharacterFromHumanoid(this: v18, a2: v12); /*0x1068a3fc0*/
        v9 = 1; /*0x1068a3fd5*/
        if ( ConstCharacterFromHumanoid != RBX::PlayerProp::getCharacter(this: (RBX::Network::StrictNetworkFilter *)((char *)*(this + 2824) + 176)) ) /*0x1068a3fdf*/
          return v9; /*0x1068a3fdf*/
      }
    }
  }
  else
  {
    v9 = 1; /*0x1068a3f4e*/
    if ( RBX::BasePartProperties::prop_DraggingV1 == (_UNKNOWN *)a3 /*0x1068a3f76*/
      || (const RBX::Reflection::PropertyDescriptor *)RBX::Instance::propParent != a3
      && (unsigned __int8)RBX::Network::Replicator::canReplicateProperty((RBX::Network::Replicator *)this, a2: a3) == 0 )
    {
      return v9; /*0x1068a3f76*/
    }
  }
  if ( *(_BYTE *)(a5 + 1) == 1 ) /*0x1068a3fef*/
    RBX::Network::PropSync::Master::masterOnReceivedAcknowledgement( /*0x1068a4004*/
      this: (RBX::Network::PropSync::Master *)(this + 2724),
      a2: v18,
      a3: a4,
      a4: *(_DWORD *)(a5 + 4));
  if ( (FFlag::DebugHashTableMetrics != 0 /*0x1068a4099*/
     || (FFlag::SAuthWorkspaceFlagged & 1) != 0
     || FFlag::NextGenReplicatorEnabledRead == 1)
    && (v17 = *(_QWORD *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::StrictNetworkFilter *)((char *)*(this + 1801) + 1608)),
        (unsigned __int8)RBX::Network::InstanceReplication::InstanceStateReplicationBridge::isPropertyNextGenRepProperty(a1: a3) != 0)
    && (v17 = *(_QWORD *)RBX::Network::NetworkSchema::getEngineNetConfiguration(this: (RBX::Network::StrictNetworkFilter *)((char *)*(this + 1801) + 1608)),
        (unsigned __int8)RBX::Network::InstanceReplication::InstanceStateReplicationBridge::isPropertyClientAuthoritative(a1: a3) != 0)
    || (v9 = 1,
        (unsigned int)RBX::Network::PropSync::Master::masterOnReceivedPropertyChanged(
                        this: (RBX::Network::PropSync::Master *)(this + 2724),
                        a2: v18,
                        a3: a4) != 1) )
  {
    if ( FFlag::CloudEditPropertiesToNetworkFilter == 0 ) /*0x1068a40a5*/
    {
      v9 = 0; /*0x1068a40b3*/
      if ( (*((unsigned __int8 (__fastcall **)(RBX::Network::StrictNetworkFilter **))*this + 129))(a1: this) != 0 ) /*0x1068a40b8*/
        return v9; /*0x1068a40b8*/
      if ( RBX::ModuleScriptProperties::prop_Confidential == (_UNKNOWN *)a3 ) /*0x1068a40c4*/
        return 1; /*0x1068a4122*/
    }
    v13 = *(this + 1567); /*0x1068a40c6*/
    if ( v13 != nullptr ) /*0x1068a40d0*/
    {
      return (unsigned int)RBX::Network::StrictNetworkFilter::filterChangedProperty(this: v13, a2: v18, a3); /*0x1068a40de*/
    }
    else
    {
      v15 = (__int64)*(this + 2752); /*0x1068a40f3*/
      if ( v15 != 0 ) /*0x1068a40fd*/
      {
        v9 = 0; /*0x1068a410f*/
        if ( (unsigned __int8)RBX::Network::NetworkFilter::filterChangedProperty(a1: v15, a2: v18, a3, a4: &v17) != 0 ) /*0x1068a4114*/
          return (unsigned int)v17; /*0x1068a4116*/
      }
      else
      {
        return 0; /*0x1068a4124*/
      }
    }
  }
  return v9; /*0x1068a40e4*/
}

// Address: 0x1068a4256 | Name: __ZN3RBX7Network16ServerReplicator30filterReceivedChangedAttributeEPNS_8InstanceERKNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS0_17ChangeVersionInfoE
_BOOL8 __fastcall RBX::Network::ServerReplicator::filterReceivedChangedAttribute(
        __int64 a1,
        __int64 a2,
        __int128 *a3,
        __int64 a4)
{
  __int64 v7; // rax
  int v8; // r14d
  __int64 node; // rax
  __int64 v10; // rax
  _BOOL4 v11; // ebx
  __int128 v13; // [rsp+0h] [rbp-60h] BYREF
  void *v14; // [rsp+10h] [rbp-50h]
  __int128 v15; // [rsp+20h] [rbp-40h] BYREF
  void *v16; // [rsp+30h] [rbp-30h]
  __int64 v17; // [rsp+38h] [rbp-28h]

  if ( (*(_BYTE *)a3 & 1) != 0 ) /*0x1068a426f*/
  {
    std::string::__init_copy_ctor_external(a1: &v13, a2: *((_QWORD *)a3 + 2), a3: *((_QWORD *)a3 + 1)); /*0x1068a4291*/
  }
  else
  {
    v14 = *((void **)a3 + 2); /*0x1068a4275*/
    v13 = *a3; /*0x1068a427c*/
  }
  v16 = v14; /*0x1068a429a*/
  v15 = v13; /*0x1068a42a2*/
  v13 = 0; /*0x1068a42a9*/
  v14 = nullptr; /*0x1068a42ad*/
  if ( a2 != 0 ) /*0x1068a42b8*/
    v7 = *(_QWORD *)(a2 + 48); /*0x1068a42ba*/
  else
    v7 = 0xFFFFFFFFLL; /*0x1068a42c0*/
  v17 = v7; /*0x1068a42c5*/
  if ( (*(_BYTE *)(a4 + 1) & 1) != 0 ) /*0x1068a42ce*/
  {
    v8 = *(_DWORD *)(a4 + 4); /*0x1068a42d0*/
    node = boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::Sync::AttributeKey const,RBX::Network::Sync::MasterItem>>,RBX::Network::Sync::AttributeKey,RBX::Network::Sync::MasterItem,boost::hash<RBX::Network::Sync::AttributeKey>,std::equal_to<RBX::Network::Sync::AttributeKey>>>::find_node( /*0x1068a42df*/
             a1: (unsigned __int8 *)(a1 + 21920),
             a2: (__int64)&v15);
    if ( node != 0 ) /*0x1068a42e7*/
      *(_DWORD *)(node + 56) = v8; /*0x1068a42e9*/
  }
  v10 = boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::Sync::AttributeKey const,RBX::Network::Sync::MasterItem>>,RBX::Network::Sync::AttributeKey,RBX::Network::Sync::MasterItem,boost::hash<RBX::Network::Sync::AttributeKey>,std::equal_to<RBX::Network::Sync::AttributeKey>>>::find_node( /*0x1068a42fb*/
          a1: (unsigned __int8 *)(a1 + 21920),
          a2: (__int64)&v15);
  v11 = v10 != 0 && *(_DWORD *)(v10 + 56) != *(_DWORD *)(v10 + 48); /*0x1068a430d*/
  if ( (v15 & 1) != 0 ) /*0x1068a4318*/
    operator delete(a1: v16); /*0x1068a431e*/
  return v11; /*0x1068a4325*/
}

// Address: 0x1068a434a | Name: __ZN3RBX7Network16ServerReplicator20filterReceivedParentEPNS_8InstanceES3_
__int64 __fastcall RBX::Network::ServerReplicator::filterReceivedParent(
        RBX::Network::ServerReplicator *this,
        RBX::Instance *a2,
        RBX::Instance *a3)
{
  unsigned int v6; // ebx
  RBX::Network::StrictNetworkFilter *v7; // rdi
  __int64 v8; // rdi
  __int64 v9; // rsi
  unsigned int v10; // r12d
  __int64 v11; // r15
  __int64 v12; // rax
  RBX::Player *v13; // rax
  __int64 v15; // rdi
  unsigned int v16[9]; // [rsp+Ch] [rbp-24h] BYREF

  v6 = 0; /*0x1068a436b*/
  if ( (*(unsigned __int8 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 1032LL))(a1: this) == 0 ) /*0x1068a436f*/
  {
    v6 = 1; /*0x1068a4384*/
    if ( (unsigned __int8)RBX::Network::Server::isScriptLegal(this: *((RBX::Network::Server **)this + 2828), a2) != 0 ) /*0x1068a438b*/
    {
      v7 = *((RBX::Network::StrictNetworkFilter **)this + 1567); /*0x1068a438d*/
      if ( v7 != nullptr ) /*0x1068a4397*/
      {
        v10 = RBX::Network::StrictNetworkFilter::filterParent(this: v7, a2, a3); /*0x1068a43a4*/
        if ( v10 != 0 || a2 == nullptr ) /*0x1068a43af*/
          return v10; /*0x1068a43b4*/
        v11 = *((_QWORD *)a2 + 3); /*0x1068a43b6*/
        v12 = RBX::Reflection::Class_getDescriptorPtr<RBX::Tool>(a1: v8, a2: v9); /*0x1068a43ba*/
        if ( *(unsigned __int16 *)(v11 + 440) - (unsigned int)*(unsigned __int16 *)(v12 + 440) > *(unsigned __int16 *)(v12 + 442) ) /*0x1068a43d9*/
          return v10; /*0x1068a43d9*/
        if ( (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 688LL))(a1: this) == 0 ) /*0x1068a43ea*/
          return v10; /*0x1068a43ea*/
        v13 = (RBX::Player *)(*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 688LL))(a1: this); /*0x1068a43f2*/
        if ( (unsigned __int8)RBX::Player::checkToolRateLimiter(this: v13) != 0 ) /*0x1068a4402*/
          return v10; /*0x1068a4404*/
      }
      else
      {
        v15 = *((_QWORD *)this + 2752); /*0x1068a4416*/
        if ( v15 != 0 ) /*0x1068a4420*/
        {
          v6 = 0; /*0x1068a4431*/
          if ( (unsigned __int8)RBX::Network::NetworkFilter::filterParent(a1: v15, a2, a3, a4: v16) != 0 ) /*0x1068a4435*/
            return v16[0]; /*0x1068a4437*/
        }
        else
        {
          return 0; /*0x1068a443c*/
        }
      }
    }
  }
  return v6; /*0x1068a4409*/
}

// Address: 0x1068a4440 | Name: __ZN3RBX7Network16ServerReplicator13filterPhysicsEPNS_8BasePartE
__int64 __fastcall RBX::Network::ServerReplicator::filterPhysics(
        RBX::Network::ServerReplicator *this,
        RBX::Primitive **a2)
{
  const RBX::Primitive *v4; // rsi
  unsigned int v5; // r15d
  __int64 ConstRootMovingPrimitive; // rax
  RBX::Player *v7; // rdi
  int v8; // r12d
  __int64 v9; // rax

  v5 = 1; /*0x1068a445a*/
  if ( (unsigned int)RBX::Network::Replicator::filterPhysics(this, (RBX::BasePart *)a2) != 1 /*0x1068a4485*/
    && (*((_QWORD *)this + 2824) != 0
     || (*(unsigned int (__fastcall **)(RBX::Network::ServerReplicator *, RBX::Primitive **))(*(_QWORD *)this + 1664LL))(
          a1: this,
          a2) != 1) )
  {
    ConstRootMovingPrimitive = RBX::Primitive::getConstRootMovingPrimitive(this: a2[47], a2: v4); /*0x1068a448e*/
    v7 = *((RBX::Player **)this + 2824); /*0x1068a4493*/
    if ( v7 == nullptr ) /*0x1068a449d*/
      goto LABEL_8; /*0x1068a449d*/
    if ( ConstRootMovingPrimitive == 0 ) /*0x1068a44a2*/
      ConstRootMovingPrimitive = (__int64)a2[47]; /*0x1068a44a4*/
    v8 = *(_DWORD *)(ConstRootMovingPrimitive + 584); /*0x1068a44ab*/
    if ( (unsigned int)RBX::Player::getRemoteAddressAsRbxAddress(this: v7) == v8 ) /*0x1068a44ba*/
    {
LABEL_8:
      v9 = RBX::detail::DenseHashTable<RBX::Reflection::ClassDescriptor const*,std::pair<RBX::Reflection::ClassDescriptor const*,unsigned short>,std::pair<RBX::Reflection::ClassDescriptor const* const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::ClassDescriptor const*,unsigned short>,RBX::Hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>::find(a1: *((_QWORD *)this + 1560) + 112LL); /*0x1068a44d2*/
      if ( v9 != 0 ) /*0x1068a44da*/
        return (unsigned int)RBX::Network::PropSync::Master::masterOnReceivedPropertyChanged( /*0x1068a44f2*/
                               this: (RBX::Network::ServerReplicator *)((char *)this + 21792),
                               (const RBX::Object *)a2,
                               a3: *(unsigned __int16 *)(v9 + 8));
      else
        return 0; /*0x1068a44f7*/
    }
  }
  return v5; /*0x1068a44fd*/
}

// Address: 0x1068a450a | Name: __ZN3RBX7Network16ServerReplicator11dataOutStepEi
__int64 __fastcall RBX::Network::ServerReplicator::dataOutStep(RBX::Network::ServerReplicator *this, unsigned int a2)
{
  unsigned int v4; // ebx
  unsigned int v5; // r14d
  unsigned int v6; // esi

  v4 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::NetworkReplicator, a2); /*0x1068a4525*/
  RBX::Network::PropSync::detail::Base<RBX::Network::PropSync::detail::MasterItem>::expireItems(a1: (char *)this + 21792); /*0x1068a452e*/
  RBX::Network::Sync::Base<RBX::Network::Sync::MasterItem,RBX::Network::Sync::AttributeKey>::expireItems(a1: (char *)this + 21912); /*0x1068a453a*/
  v5 = RBX::Network::Replicator::dataOutStep(this, a2); /*0x1068a454a*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v4, a2: v6); /*0x1068a454f*/
  return v5; /*0x1068a455b*/
}

// Address: 0x1068a45ea | Name: __ZN3RBX7Network16ServerReplicator21testSetSyncExpirationEd
bool __fastcall RBX::Network::ServerReplicator::testSetSyncExpiration(RBX::Network::ServerReplicator *this, double a2)
{
  bool result; // al

  result = RBX::Network::Replicator::getAttributeSynchronizationEnabled(this); /*0x1068a45f8*/
  if ( result ) /*0x1068a4604*/
    *((double *)this + 2739) = a2; /*0x1068a4606*/
  *((double *)this + 2724) = a2; /*0x1068a460e*/
  return result; /*0x1068a461a*/
}

// Address: 0x1068a461e | Name: __ZN3RBX7Network16ServerReplicator23testClearSyncExpirationEv
void __fastcall RBX::Network::ServerReplicator::testClearSyncExpiration(RBX::Network::ServerReplicator *this)
{
  rbx::timestamped_safe_queue<RBX::Network::PropSync::detail::PropertyKey>::clear(a1: (char *)this + 21848); /*0x1068a462e*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const,RBX::Network::PropSync::detail::MasterItem>>,RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::MasterItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey>>>::clear(a1: (_QWORD *)this + 2725); /*0x1068a463a*/
  rbx::timestamped_safe_queue<RBX::Network::Sync::AttributeKey const*>::clear(a1: (char *)this + 21968); /*0x1068a4646*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::Sync::AttributeKey const,RBX::Network::Sync::MasterItem>>,RBX::Network::Sync::AttributeKey,RBX::Network::Sync::MasterItem,boost::hash<RBX::Network::Sync::AttributeKey>,std::equal_to<RBX::Network::Sync::AttributeKey>>>::clear(a1: (_QWORD *)this + 2740); /*0x1068a465b*/
}

// Address: 0x1068a4660 | Name: __ZNK3RBX7Network16ServerReplicator17sucessfullyJoinedEPKNS_7PlayersE
bool __fastcall RBX::Network::ServerReplicator::sucessfullyJoined(
        RBX::Network::ServerReplicator *this,
        const RBX::Players *a2)
{
  __int64 v2; // rax

  return *((_BYTE *)this + 14417) == 0 /*0x1068a468c*/
      && (v2 = *((_QWORD *)this + 2838)) != 0
      && a2 != nullptr
      && *(_QWORD *)(v2 + 104) == (_QWORD)a2;
}

// Address: 0x1068a4690 | Name: __ZN3RBX7Network16ServerReplicator28isPropertyConfidentialHelperEPKNS_6ObjectERKNS_10Reflection18PropertyDescriptorE
char __fastcall RBX::Network::ServerReplicator::isPropertyConfidentialHelper(
        RBX::Network::ServerReplicator *this,
        const RBX::Object *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  __int64 v5; // r15
  __int64 v6; // rax
  char result; // al
  __int64 v8; // r15
  __int64 v9; // rax

  if ( RBX::TextBoxProperties::prop_Text == (_UNKNOWN *)a2 ) /*0x1068a46aa*/
  {
    if ( this != nullptr ) /*0x1068a46fe*/
      return *((_BYTE *)this + 3777); /*0x1068a4707*/
  }
  else if ( this != nullptr && RBX::ModuleScriptProperties::prop_Source == (_UNKNOWN *)a2 ) /*0x1068a46bb*/
  {
    v5 = *((_QWORD *)this + 3); /*0x1068a46bd*/
    v6 = RBX::Reflection::Class_getDescriptorPtr<RBX::ModuleScript>(a1: this, a2); /*0x1068a46c1*/
    if ( *(unsigned __int16 *)(v5 + 440) - (unsigned int)*(unsigned __int16 *)(v6 + 440) <= *(unsigned __int16 *)(v6 + 442) ) /*0x1068a46e0*/
      return RBX::ModuleScriptProp::getConfidential(this: (RBX::Network::ServerReplicator *)((char *)this + 248)); /*0x1068a46f6*/
  }
  v8 = *((_QWORD *)this + 3); /*0x1068a4709*/
  v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(a1: this); /*0x1068a470d*/
  if ( this == nullptr ) /*0x1068a4715*/
    return 0; /*0x1068a4715*/
  if ( *(unsigned __int16 *)(v8 + 440) - (unsigned int)*(unsigned __int16 *)(v9 + 440) > *(unsigned __int16 *)(v9 + 442) ) /*0x1068a4731*/
    return 0; /*0x1068a4731*/
  result = 1; /*0x1068a473a*/
  if ( RBX::PlayerProperties::prop_VRDevice != (_UNKNOWN *)a2 /*0x1068a474b*/
    && RBX::PlayerProperties::prop_CountryRegionCodeReplicate != (_UNKNOWN *)a2 )
  {
    return 0; /*0x1068a474d*/
  }
  return result; /*0x1068a46f0*/
}

// Address: 0x1068a475a | Name: __ZN3RBX7Network16ServerReplicator26sendReplicatorCloseStatsExERNS_9Telemetry20RobloxTelemetryEventE
__int64 __fastcall RBX::Network::ServerReplicator::sendReplicatorCloseStatsEx(
        RBX::Network::ServerReplicator *this,
        RBX::Telemetry::RobloxTelemetryEvent *a2)
{
  char *v4; // rbx
  __int64 v5; // rax
  RBX::Time *v6; // rdi
  double v7; // xmm0_8

  v4 = (char *)a2 + 72; /*0x1068a476a*/
  v5 = RBX::Time::epochTime(this); /*0x1068a476e*/
  (**((void (__fastcall ***)(char *, const char *, __int64, __int64, __int64))a2 + 9))( /*0x1068a478f*/
    a1: v4,
    a2: "started",
    a3: 7,
    a4: v5,
    a5: 1);
  RBX::Time::nowFast(this: v6); /*0x1068a4792*/
  return (*(__int64 (__fastcall **)(char *, const char *, __int64, __int64, double))(*((_QWORD *)a2 + 9) + 16LL))( /*0x1068a47c1*/
           a1: v4,
           a2: "sessionTime",
           a3: 11,
           a4: 1,
           a5: v7 - *((double *)this + 864));
}

// Address: 0x1068a47c8 | Name: __ZNK3RBX7Network16ServerReplicator22isPropertyConfidentialEPKNS_6ObjectERKNS_10Reflection18PropertyDescriptorE
char __fastcall RBX::Network::ServerReplicator::isPropertyConfidential(
        RBX::Network::ServerReplicator *this,
        const RBX::Object *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  return RBX::Network::ServerReplicator::isPropertyConfidentialHelper(this: a2, a2: a3, a3); /*0x1068a47d2*/
}

// Address: 0x1068a47d8 | Name: __ZN3RBX7Network16ServerReplicator29isPropertyInvalidNetworkOwnerEPKNS_6ObjectERKNS_10Reflection18PropertyDescriptorERKNS_13SystemAddressE
__int64 __fastcall RBX::Network::ServerReplicator::isPropertyInvalidNetworkOwner(__int64 a1, void *a2, _DWORD *a3)
{
  __int64 result; // rax
  __int64 v6; // r15
  __int64 v7; // rax
  unsigned int v8; // ecx
  int NetworkOwner; // eax
  RBX::NetworkOwner *v10; // rdi
  int v11; // r14d

  if ( RBX::BasePartProperties::prop_NetworkOwnerV3 != a2 ) /*0x1068a47ec*/
    return 0; /*0x1068a47ec*/
  if ( a1 == 0 ) /*0x1068a47f8*/
    return 0; /*0x1068a47f8*/
  v6 = *(_QWORD *)(a1 + 24); /*0x1068a47fd*/
  v7 = RBX::Reflection::Class_getDescriptorPtr<RBX::BasePart>(a1, a2); /*0x1068a4801*/
  if ( *(unsigned __int16 *)(v6 + 440) - (unsigned int)*(unsigned __int16 *)(v7 + 440) > *(unsigned __int16 *)(v7 + 442) ) /*0x1068a4820*/
    return 0; /*0x1068a4824*/
  NetworkOwner = RBX::BasePartProp::getNetworkOwner(this: (RBX::BasePartProp *)(a1 + 184)); /*0x1068a483b*/
  if ( NetworkOwner == 3 ) /*0x1068a4843*/
    return 0; /*0x1068a47f0*/
  v11 = NetworkOwner; /*0x1068a4845*/
  v8 = RBX::NetworkOwner::Unassigned(this: v10); /*0x1068a484d*/
  result = 0; /*0x1068a4853*/
  if ( (unsigned int)(v11 - 3) <= 0xFFFFFFFD && v11 != v8 ) /*0x1068a485d*/
  {
    LOBYTE(v8) = 1; /*0x1068a485f*/
    if ( v11 != *a3 ) /*0x1068a4864*/
      return v8; /*0x1068a4864*/
  }
  return result; /*0x1068a482a*/
}

// Address: 0x1068a4868 | Name: __ZNK3RBX7Network16ServerReplicator25shouldUseFullPropertySyncEPKNS_6ObjectEtPKNS_10Reflection18PropertyDescriptorE
__int64 __fastcall RBX::Network::ServerReplicator::shouldUseFullPropertySync(
        RBX::Network::StrictNetworkFilter **this,
        const RBX::Object *a2,
        __int16 a3,
        const RBX::Reflection::PropertyDescriptor *a4)
{
  unsigned int v4; // ebx
  char v9; // al
  RBX::Network::StrictNetworkFilter *v10; // rdi
  __int64 v11; // rax

  v9 = (*((__int64 (__fastcall **)(RBX::Network::StrictNetworkFilter **))*this + 129))(a1: this); /*0x1068a4885*/
  LOBYTE(v4) = 1; /*0x1068a488b*/
  if ( a4 != nullptr && v9 == 0 ) /*0x1068a4894*/
  {
    v10 = *(this + 1567); /*0x1068a4896*/
    if ( v10 != nullptr /*0x1068a48b0*/
      && (unsigned int)RBX::Network::StrictNetworkFilter::filterChangedProperty(this: v10, a2, a3: a4) != 0 )
    {
      v11 = RBX::detail::DenseHashTable<RBX::Reflection::ClassDescriptor const*,std::pair<RBX::Reflection::ClassDescriptor const*,unsigned short>,std::pair<RBX::Reflection::ClassDescriptor const* const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::ClassDescriptor const*,unsigned short>,RBX::Hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>::find(a1: (char *)*(this + 1560) + 112); /*0x1068a48c9*/
      if ( v11 == 0 || *(_WORD *)(v11 + 8) != a3 ) /*0x1068a48d8*/
        return 0; /*0x1068a48da*/
    }
  }
  return v4; /*0x1068a48e2*/
}

// Address: 0x1068a48ee | Name: __ZN3RBX7Network16ServerReplicator28serializePropertyVersionInfoERNS0_13NetworkStreamEPKNS_6ObjectEtPKNS_10Reflection18PropertyDescriptorE
__int64 __fastcall RBX::Network::ServerReplicator::serializePropertyVersionInfo(
        RBX::Network::StrictNetworkFilter **this,
        RBX::Network::NetworkStream *a2,
        const RBX::Object *a3,
        unsigned __int16 a4,
        const RBX::Reflection::PropertyDescriptor *a5)
{
  char shouldUseFullPropertySync; // al
  bool v10; // cl
  bool v12[33]; // [rsp+Fh] [rbp-21h] BYREF

  shouldUseFullPropertySync = RBX::Network::ServerReplicator::shouldUseFullPropertySync(this, a2: a3, a3: a4, a4: a5); /*0x1068a4911*/
  v10 = true; /*0x1068a4916*/
  if ( shouldUseFullPropertySync != 0 ) /*0x1068a491a*/
    v10 = (unsigned int)RBX::Network::PropSync::Master::masterOnSendProperty( /*0x1068a4934*/
                          this: (RBX::Network::PropSync::Master *)(this + 2724),
                          a2: a3,
                          a3: a4) == 0;
  v12[0] = v10; /*0x1068a493b*/
  return RBX::Network::NetworkStream::writeBytes(this: a2, a2: v12, a3: 1u); /*0x1068a494a*/
}

// Address: 0x1068a4a56 | Name: __ZN3RBX7Network16ServerReplicator30deserializePropertyVersionInfoERNS0_13NetworkStreamERNS0_17ChangeVersionInfoE
__int64 __fastcall RBX::Network::ServerReplicator::deserializePropertyVersionInfo(
        __int64 a1,
        RBX::Network::NetworkStream *a2,
        __int64 a3)
{
  __int64 result; // rax
  RBX::Network::NetworkStream *v6; // rdx

  result = RBX::Network::NetworkStream::readBool(this: a2); /*0x1068a4a66*/
  *(_BYTE *)(a3 + 1) = result; /*0x1068a4a6b*/
  if ( (_BYTE)result != 0 ) /*0x1068a4a71*/
    return RBX::Network::deserializeSignedVarint(this: (RBX::Network *)(a3 + 4), (int *)a2, a3: v6); /*0x1068a4a81*/
  return result; /*0x1068a4a7d*/
}

// Address: 0x1068a4a8c | Name: __ZN3RBX7Network16ServerReplicator25writeAttributeVersionInfoERNS0_13NetworkStreamEPKNS_8InstanceERKNSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEE
char __fastcall RBX::Network::ServerReplicator::writeAttributeVersionInfo(
        RBX::Network::Replicator *a1,
        RBX::Network::NetworkStream *a2,
        __int64 a3,
        __int128 *a4)
{
  char result; // al
  __int64 v9; // rax
  int v10; // r14d
  __int128 v11; // [rsp+0h] [rbp-60h] BYREF
  void *v12; // [rsp+10h] [rbp-50h]
  __int64 v13; // [rsp+18h] [rbp-48h]
  __int128 v14; // [rsp+20h] [rbp-40h] BYREF
  void *v15; // [rsp+30h] [rbp-30h]
  bool v16[33]; // [rsp+3Fh] [rbp-21h] BYREF

  result = RBX::Network::Replicator::getAttributeSynchronizationEnabled(this: a1); /*0x1068a4aa7*/
  if ( result != 0 ) /*0x1068a4aae*/
  {
    result = (*(__int64 (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)a1 + 1032LL))(a1); /*0x1068a4aba*/
    if ( result != 0 ) /*0x1068a4ac2*/
    {
      if ( (*(_BYTE *)a4 & 1) != 0 ) /*0x1068a4acd*/
      {
        std::string::__init_copy_ctor_external(a1: &v14, a2: *((_QWORD *)a4 + 2), a3: *((_QWORD *)a4 + 1)); /*0x1068a4af1*/
      }
      else
      {
        v15 = *((void **)a4 + 2); /*0x1068a4ad4*/
        v14 = *a4; /*0x1068a4add*/
      }
      v12 = v15; /*0x1068a4afa*/
      v11 = v14; /*0x1068a4b02*/
      v14 = 0; /*0x1068a4b09*/
      v15 = nullptr; /*0x1068a4b0d*/
      if ( a3 != 0 ) /*0x1068a4b18*/
        v9 = *(_QWORD *)(a3 + 48); /*0x1068a4b1a*/
      else
        v9 = 0xFFFFFFFFLL; /*0x1068a4b20*/
      v13 = v9; /*0x1068a4b25*/
      v10 = RBX::Network::Sync::Master<RBX::Network::Sync::AttributeKey>::masterAtSend(a1: (char *)a1 + 21912, a2: &v11); /*0x1068a4b3c*/
      if ( (v11 & 1) != 0 ) /*0x1068a4b43*/
        operator delete(a1: v12); /*0x1068a4b49*/
      if ( (v14 & 1) != 0 ) /*0x1068a4b52*/
        operator delete(a1: v15); /*0x1068a4b58*/
      v16[0] = v10 == 0; /*0x1068a4b64*/
      return RBX::Network::NetworkStream::writeBytes(this: a2, a2: v16, a3: 1u); /*0x1068a4b6f*/
    }
  }
  return result; /*0x1068a4b74*/
}

// Address: 0x1068a4c20 | Name: __ZN3RBX7Network16ServerReplicator24readAttributeVersionInfoERNS0_13NetworkStreamERNS0_17ChangeVersionInfoE
char __fastcall RBX::Network::ServerReplicator::readAttributeVersionInfo(
        RBX::Network::Replicator *a1,
        RBX::Network::NetworkStream *a2,
        __int64 a3)
{
  char result; // al
  RBX::Network::NetworkStream *v7; // rdx

  result = RBX::Network::Replicator::getAttributeSynchronizationEnabled(this: a1); /*0x1068a4c33*/
  if ( result != 0 ) /*0x1068a4c3a*/
  {
    result = (*(__int64 (__fastcall **)(RBX::Network::Replicator *))(*(_QWORD *)a1 + 1032LL))(a1); /*0x1068a4c42*/
    if ( result != 0 ) /*0x1068a4c4a*/
    {
      result = RBX::Network::NetworkStream::readBool(this: a2); /*0x1068a4c4f*/
      *(_BYTE *)(a3 + 1) = result; /*0x1068a4c54*/
      if ( result != 0 ) /*0x1068a4c5a*/
        return RBX::Network::deserializeSignedVarint(this: (RBX::Network *)(a3 + 4), (int *)a2, a3: v7); /*0x1068a4c70*/
    }
  }
  return result; /*0x1068a4c6a*/
}

// Address: 0x1068a4c80 | Name: __ZN3RBX7Network16ServerReplicator17onServiceProviderEPNS_15ServiceProviderES3_
__int64 __fastcall RBX::Network::ServerReplicator::onServiceProvider(
        RBX::Network::ServerReplicator *this,
        RBX::ServiceProvider *a2,
        RBX::ServiceProvider *a3)
{
  RBX::ServiceProvider *v4; // r15
  __int64 *v6; // r12
  __int64 v7; // rdi
  char canSend; // al
  __int64 v9; // rdi
  std::__shared_weak_count *v10; // r13
  __int64 v11; // rdi
  std::__shared_weak_count *v12; // r13
  RBX::Network::Replicator::StreamJob *v13; // r13
  std::__shared_weak_count *v14; // r12
  __int64 *v15; // r12
  __int64 v16; // rax
  __int64 v17; // rsi
  __int64 v18; // r12
  __int64 v19; // rax
  __int64 v20; // rcx
  __int64 v21; // rcx
  RBX::Instance *v22; // rsi
  std::__shared_weak_count *v23; // r12
  std::__shared_weak_count *v24; // r12
  __int64 v25; // rdi
  __int64 v26; // rcx
  __int64 v27; // rax
  std::__shared_weak_count *v28; // r12
  RBX::DataModel *v29; // rax
  RBX::DataModelPeer *v30; // r12
  const RBX::DataModel *v31; // rsi
  double v32; // xmm0_8
  RBX::Network::SharedStringSynchronizer *v33; // r12
  _QWORD *v34; // rdi
  char v35; // al
  __int64 v36; // rdx
  __int64 v37; // rcx
  RBX::Network::Server *v38; // rdi
  const RakNet::SystemAddress *v39; // rsi
  __int64 v40; // r14
  unsigned __int64 UserID; // r15
  std::__shared_weak_count *v42; // r14
  double v43; // xmm0_8
  std::runtime_error *exception; // r14
  __int64 v46; // [rsp+8h] [rbp-2F8h] BYREF
  std::__shared_weak_count *v47; // [rsp+10h] [rbp-2F0h]
  _BYTE v48[528]; // [rsp+50h] [rbp-2B0h] BYREF
  __int128 v49; // [rsp+260h] [rbp-A0h] BYREF
  __int128 v50; // [rsp+270h] [rbp-90h]
  _BYTE v51[16]; // [rsp+280h] [rbp-80h] BYREF
  void *v52; // [rsp+290h] [rbp-70h]
  RBX::ServiceProvider *v53; // [rsp+298h] [rbp-68h]
  std::__shared_weak_count *v54[2]; // [rsp+2A0h] [rbp-60h] BYREF
  std::__shared_weak_count *v55[2]; // [rsp+2B0h] [rbp-50h] BYREF
  std::__shared_weak_count *v56[2]; // [rsp+2C0h] [rbp-40h] BYREF

  v4 = a2; /*0x1068a4c97*/
  v6 = (__int64 *)((char *)this + 14520); /*0x1068a4c9d*/
  v7 = *((_QWORD *)this + 1815); /*0x1068a4ca4*/
  if ( v7 != 0 ) /*0x1068a4cae*/
  {
    if ( FFlag::PredictedSpawnStreamFocus != 0 || FFlag::SessionStreamTotalStats == 1 ) /*0x1068a4cca*/
    {
      if ( a3 == nullptr ) /*0x1068a4ccf*/
        RBX::Network::Replicator::StreamJob::reportSessionEndTelemetry(this: (RBX::Network::Replicator::StreamJob *)v7); /*0x1068a4cd1*/
    }
    else if ( a3 == nullptr ) /*0x1068a4cdb*/
    {
      if ( FFlag::EnableFrustumAutomation == 1 ) /*0x1068a4ce7*/
      {
        canSend = RBX::Analytics::InfluxDb::canSend( /*0x1068a4cf2*/
                    this: (RBX::Analytics::InfluxDb *)(unsigned int)FInt::FrustumStreamingAutomationStatsThrottleHP,
                    (int)a2);
        v7 = *v6; /*0x1068a4cf7*/
        if ( canSend != 0 ) /*0x1068a4cfd*/
        {
          RBX::Network::FrustumAutomationSystem::reportFrustumStreamingAutomationStats(this: (RBX::Network::FrustumAutomationSystem *)(v7 + 12016)); /*0x1068a4d06*/
          v7 = *v6; /*0x1068a4d0b*/
        }
      }
      RBX::Network::Replicator::StreamJob::reportVelocityAwareStreamingStats(this: (RBX::Network::Replicator::StreamJob *)v7); /*0x1068a4d0f*/
    }
    std::shared_ptr<RBX::Network::Replicator::StreamJob>::reset[abi:ne200100](a1: v6); /*0x1068a4d17*/
    v9 = *((_QWORD *)this + 2824); /*0x1068a4d1c*/
    if ( v9 != 0 ) /*0x1068a4d26*/
    {
      v49 = 0; /*0x1068a4d33*/
      RBX::Player::setStreamingInterface(a1: v9, a2: &v49); /*0x1068a4d37*/
      v10 = *((std::__shared_weak_count **)&v49 + 1); /*0x1068a4d3c*/
      if ( *((_QWORD *)&v49 + 1) != 0 /*0x1068a4d58*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v49 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x1068a4d61*/
        std::__shared_weak_count::__release_weak(this: v10); /*0x1068a4d67*/
      }
    }
  }
  v11 = *((_QWORD *)this + 2824); /*0x1068a4d6c*/
  if ( v11 != 0 ) /*0x1068a4d76*/
  {
    v50 = 0; /*0x1068a4d83*/
    RBX::Player::setNetworkInterface(a1: v11); /*0x1068a4d87*/
    v12 = *((std::__shared_weak_count **)&v50 + 1); /*0x1068a4d8c*/
    if ( *((_QWORD *)&v50 + 1) != 0 /*0x1068a4da8*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v50 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(a1: v12); /*0x1068a4db1*/
      std::__shared_weak_count::__release_weak(this: v12); /*0x1068a4db7*/
    }
  }
  if ( *((_QWORD *)this + 2759) != 0 ) /*0x1068a4dc4*/
  {
    RBX::TaskScheduler::remove(a1: (char *)this + 22072); /*0x1068a4dd0*/
    std::shared_ptr<RBX::TaskScheduler::Job>::reset[abi:ne200100](a1: (char *)this + 22072); /*0x1068a4dd8*/
  }
  if ( a3 != nullptr ) /*0x1068a4de0*/
  {
    if ( RBX::ServiceProvider::find<RBX::Workspace>(a1: a3, a2: 0) == 0 ) /*0x1068a4df3*/
    {
      exception = (std::runtime_error *)__cxa_allocate_exception(thrown_size: 0x10u); /*0x1068a5307*/
      std::runtime_error::runtime_error(this: exception, a2: "ServerReplicator unable to find workspace."); /*0x1068a5314*/
      __cxa_throw( /*0x1068a532a*/
        a1: exception,
        lptinfo: (struct type_info *)&`typeinfo for'std::runtime_error,
        a3: (void (__fastcall *)(void *))&std::runtime_error::~runtime_error);
    }
    if ( *(_BYTE *)(*((_QWORD *)this + 1801) + 3761LL) == 1 ) /*0x1068a4e07*/
    {
      v53 = v4; /*0x1068a4e0d*/
      *((_BYTE *)this + 15544) = 1; /*0x1068a4e11*/
      v13 = (RBX::Network::Replicator::StreamJob *)operator new(a1: 0x3310u); /*0x1068a4e22*/
      RBX::Network::Replicator::StreamJob::StreamJob(this: v13, a2: this); /*0x1068a4e2b*/
      std::shared_ptr<RBX::Network::Replicator::StreamJob>::shared_ptr[abi:ne200100]<RBX::Network::Replicator::StreamJob,0>( /*0x1068a4e3d*/
        a1: &v46,
        a2: v13);
      std::shared_ptr<RBX::Network::Replicator::StreamJob>::operator=[abi:ne200100](a1: v6, a2: &v46); /*0x1068a4e48*/
      v14 = v47; /*0x1068a4e4d*/
      if ( v47 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v47 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068a4e67*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x1068a4e70*/
        std::__shared_weak_count::__release_weak(this: v14); /*0x1068a4e76*/
      }
      v15 = (__int64 *)operator new(a1: 8u); /*0x1068a4e85*/
      *v15 = 0; /*0x1068a4e88*/
      v16 = operator new(a1: 0x38u); /*0x1068a4e94*/
      v4 = v53; /*0x1068a4e99*/
      *(_OWORD *)v16 = 0; /*0x1068a4ea1*/
      *(_QWORD *)(v16 + 16) = 0; /*0x1068a4ea7*/
      *(_QWORD *)(v16 + 24) = 104; /*0x1068a4eab*/
      *(_QWORD *)(v16 + 32) = 32; /*0x1068a4eb8*/
      *(_QWORD *)(v16 + 40) = 32; /*0x1068a4ebc*/
      *(_QWORD *)(v16 + 48) = 0; /*0x1068a4ec0*/
      *v15 = v16; /*0x1068a4ec4*/
      v17 = *((_QWORD *)this + 1483); /*0x1068a4ec8*/
      *((_QWORD *)this + 1483) = v15; /*0x1068a4ecf*/
      if ( v17 != 0 ) /*0x1068a4ed9*/
        std::default_delete<RBX::AutoMemPool>::operator()[abi:ne200100](a1: (char *)this + 11864); /*0x1068a4ee2*/
    }
    v18 = operator new(a1: 0x70u); /*0x1068a4ef1*/
    v19 = *((_QWORD *)this + 2828); /*0x1068a4ef4*/
    v20 = *(_QWORD *)(v19 + 400); /*0x1068a4efb*/
    *(_OWORD *)v54 = *(_OWORD *)(v19 + 392); /*0x1068a4f09*/
    if ( v20 != 0 ) /*0x1068a4f10*/
    {
      _InterlockedIncrement64((volatile signed __int64 *)(v20 + 8)); /*0x1068a4f12*/
      v19 = *((_QWORD *)this + 2828); /*0x1068a4f17*/
    }
    v21 = *(_QWORD *)(v19 + 416); /*0x1068a4f1e*/
    *(_OWORD *)v55 = *(_OWORD *)(v19 + 408); /*0x1068a4f2d*/
    if ( v21 != 0 ) /*0x1068a4f35*/
      _InterlockedIncrement64((volatile signed __int64 *)(v21 + 8)); /*0x1068a4f37*/
    RBX::Network::StrictNetworkFilter::StrictNetworkFilter(a1: v18, a2: this, a3: v54, a4: v55); /*0x1068a4f4a*/
    std::unique_ptr<RBX::Network::StrictNetworkFilter>::reset[abi:ne200100](a1: (char *)this + 12536, a2: v18); /*0x1068a4f59*/
    v23 = v55[1]; /*0x1068a4f5e*/
    if ( v55[1] != nullptr /*0x1068a4f78*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v55[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v23 + 16LL))(a1: v23); /*0x1068a4f81*/
      std::__shared_weak_count::__release_weak(this: v23); /*0x1068a4f87*/
    }
    v24 = v54[1]; /*0x1068a4f8c*/
    if ( v54[1] != nullptr /*0x1068a4fa6*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v54[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v24 + 16LL))(a1: v24); /*0x1068a4faf*/
      std::__shared_weak_count::__release_weak(this: v24); /*0x1068a4fb5*/
    }
    if ( FFlag::NetworkFilterTelemetry == 1 ) /*0x1068a4fc4*/
    {
      v25 = *((_QWORD *)this + 1567); /*0x1068a4fc6*/
      v26 = *((_QWORD *)this + 2828); /*0x1068a4fcd*/
      v27 = *(_QWORD *)(v26 + 384); /*0x1068a4fd4*/
      *(_OWORD *)v56 = *(_OWORD *)(v26 + 376); /*0x1068a4fe3*/
      if ( v27 != 0 ) /*0x1068a4feb*/
        _InterlockedIncrement64((volatile signed __int64 *)(v27 + 8)); /*0x1068a4fed*/
      RBX::Network::StrictNetworkFilter::setGlobalStats(a1: v25, a2: v56); /*0x1068a4ff6*/
      v28 = v56[1]; /*0x1068a4ffb*/
      if ( v56[1] != nullptr /*0x1068a5015*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v56[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v28 + 16LL))(a1: v28); /*0x1068a501e*/
        std::__shared_weak_count::__release_weak(this: v28); /*0x1068a5024*/
      }
    }
    v29 = (RBX::DataModel *)RBX::DataModel::get(this: a3, a2: v22); /*0x1068a502c*/
    if ( v29 != nullptr ) /*0x1068a5034*/
    {
      v30 = v29; /*0x1068a5036*/
      RBX::DataModel::setIsSFFlagsLoaded(this: v29, a2: true); /*0x1068a5041*/
      *((_DWORD *)this + 48) = RBX::DataModelPeer::getLocalPeerId(this: v30, a2: v31); /*0x1068a504e*/
    }
    if ( (unsigned __int8)RBX::Network::Replicator::useConfigurablePropSync(this) != 0 ) /*0x1068a505e*/
    {
      v32 = (double)DFInt::ServerPropSyncExpiryTeamCreateTimeSec; /*0x1068a5063*/
      *((double *)this + 2724) = (double)DFInt::ServerPropSyncExpiryTeamCreateTimeSec; /*0x1068a506b*/
      *((double *)this + 2739) = v32; /*0x1068a5073*/
      if ( DFFlag::PropertyRejectionCountTelemetry == 1 ) /*0x1068a5082*/
        *((double *)this + 2738) = (double)DFInt::OldServerPropSyncExpiryTeamCreateTimeSec; /*0x1068a508f*/
    }
    if ( RBX::Network::Replicator::getSharedStringCachingEnabled(this) ) /*0x1068a509a*/
    {
      v33 = (RBX::Network::SharedStringSynchronizer *)operator new(a1: 0x210u); /*0x1068a50ad*/
      __bzero(a1: v33, a2: 528); /*0x1068a50b8*/
      RBX::Network::SharedStringSynchronizer::SharedStringSynchronizer(this: v33); /*0x1068a50c0*/
      std::unique_ptr<RBX::Network::SharedStringSynchronizer>::reset[abi:ne200100](a1: (char *)this + 15416, a2: v33); /*0x1068a50cf*/
    }
  }
  RBX::Network::Replicator::onServiceProvider(this, a2: v4, a3); /*0x1068a50dd*/
  if ( DFFlag::PropertyRejectionCountTelemetry == 1 /*0x1068a510b*/
    && (v35 = RBX::Network::Replicator::useConfigurablePropSync(this), a3 == nullptr)
    && v4 != nullptr
    && v35 != 0 )
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)3,std::enable_if<true,void>>( /*0x1068a5122*/
      a1: &v46,
      a2: &RBX::Telemetry::kPropRejectedCount);
    if ( (unsigned __int8)RBX::Telemetry::RobloxTelemetryEvent::willThrottlePoints(this: (RBX::Telemetry::RobloxTelemetryEvent *)&v46) == 0 ) /*0x1068a5131*/
    {
      RBX::Telemetry::FieldsContainer::addField( /*0x1068a5159*/
        a1: v48,
        a2: "propertyRejectionCount",
        a3: 22,
        a4: *((unsigned int *)this + 5474),
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField( /*0x1068a5179*/
        a1: v48,
        a2: "acceptedByOldRejectedByNewCount",
        a3: 31,
        a4: *((unsigned int *)this + 5475),
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField( /*0x1068a519c*/
        a1: v48,
        a2: "NewExpirySec",
        a3: 12,
        a4: (unsigned int)(int)*((double *)this + 2724),
        a5: 1);
      RBX::Telemetry::FieldsContainer::addField( /*0x1068a51bf*/
        a1: v48,
        a2: "OldExpirySec",
        a3: 12,
        a4: (unsigned int)(int)*((double *)this + 2738),
        a5: 1);
      std::string::basic_string[abi:ne200100]<0>(a1: v51, a2: "", a3: v36, a4: v37); /*0x1068a51cf*/
      RBX::Telemetry::FieldsContainer::addPlaceId(this: (RBX::Analytics *)v48); /*0x1068a51db*/
      if ( (v51[0] & 1) != 0 ) /*0x1068a51e4*/
        operator delete(a1: v52); /*0x1068a51ea*/
      RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)&v46); /*0x1068a51f6*/
    }
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)&v46); /*0x1068a5209*/
  }
  else if ( a3 != nullptr ) /*0x1068a5213*/
  {
    goto LABEL_72; /*0x1068a5213*/
  }
  v38 = *((RBX::Network::Server **)this + 2828); /*0x1068a5220*/
  v39 = (RBX::Network::ServerReplicator *)((char *)this + 240); /*0x1068a5227*/
  if ( FFlag::SeparateRakNetAndRbxTransportRouting == 1 ) /*0x1068a5231*/
    RBX::Network::Server::detachRakNetReplicatorFromPeer(this: v38, a2: v39, a3: this); /*0x1068a5236*/
  else
    RBX::Network::Server::detachReplicatorFromPeer(this: v38, a2: v39); /*0x1068a523d*/
  v34 = *((_QWORD **)this + 2824); /*0x1068a5242*/
  if ( v34 != nullptr ) /*0x1068a524c*/
  {
    v40 = *((_QWORD *)this + 2828); /*0x1068a524e*/
    if ( FFlag::MigrateUserIdAccessors == 1 ) /*0x1068a525f*/
      UserID = v34[26]; /*0x1068a5261*/
    else
      UserID = RBX::PlayerProp::getUserID(this: (RBX::PlayerProp *)(v34 + 22)); /*0x1068a5276*/
    RBX::shared_from<RBX::Network::ServerReplicator>(a1: &v46); /*0x1068a5286*/
    RBX::Network::Server::unregisterServerReplicatorForPlayerId(a1: v40, a2: UserID, a3: &v46); /*0x1068a5294*/
    v42 = v47; /*0x1068a5299*/
    if ( v47 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v47 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068a52b5*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v42 + 16LL))(a1: v42); /*0x1068a52bd*/
      std::__shared_weak_count::__release_weak(this: v42); /*0x1068a52c3*/
    }
  }
LABEL_72:
  RBX::Time::nowFast(this: (RBX::Time *)v34); /*0x1068a52c8*/
  return RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068a52eb*/
           this: (RBX::Network::ServerReplicator *)((char *)this + 22112),
           a2: "ReplicatorAdded",
           a3: v43 - *((double *)this + 2762));
}

// Address: 0x1068a5476 | Name: __ZNK3RBX7Network16ServerReplicator16serializeSFFlagsERNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::ServerReplicator::serializeSFFlags(
        RBX::Network::ServerReplicator *this,
        RBX::Network::NetworkStream *a2)
{
  _WORD v4[5]; // [rsp+0h] [rbp-Ah] BYREF

  v4[0] = FLog::GetNumSynchronizedVariable(this); /*0x1068a5488*/
  RBX::Network::NetworkStream::writeBytes(this: a2, a2: v4, a3: 2u); /*0x1068a5493*/
  if ( FFlag::UniverseFilters == 1 ) /*0x1068a54a2*/
    return FLog::ForEachVariable( /*0x1068a54b3*/
             a1: (void (__fastcall *)(__int64, __int64, __int64, __int64, __int64, __int64))&RBX::Network::serializeSFFlag,
             (__int64)a2,
             a3: 4);
  else
    return FLog::DEPRECATED_ForEachVariable( /*0x1068a54c9*/
             a1: (void (__fastcall *)(__int64, __int64, __int64, __int64, __int64))&RBX::Network::DEPRECATED_serializeSFFlag,
             (__int64)a2,
             a3: 4);
}

// Address: 0x1068a562e | Name: __ZN3RBX7Network16ServerReplicator24isProtectedStringEnabledEv
__int64 __fastcall RBX::Network::ServerReplicator::isProtectedStringEnabled(RBX::Network::ServerReplicator *this)
{
  return 0; /*0x1068a5634*/
}

// Address: 0x1068a5636 | Name: __ZN3RBX7Network16ServerReplicator26schemaGetBytecodeForSourceERKNS_15ProtectedStringEPKNS0_6ServerE
RBX::Network::ServerReplicator *__fastcall RBX::Network::ServerReplicator::schemaGetBytecodeForSource(
        RBX::Network::ServerReplicator *this,
        const RBX::ProtectedString *a2,
        const RBX::Network::Server *a3)
{
  __int64 ScriptIndexForSharedSource; // rax
  _BYTE v7[40]; // [rsp+8h] [rbp-28h] BYREF

  ScriptIndexForSharedSource = RBX::Network::Server::getScriptIndexForSharedSource(this: a3, a2); /*0x1068a564c*/
  if ( (ScriptIndexForSharedSource & 0x100000000LL) != 0 ) /*0x1068a5656*/
  {
    RBX::Network::Server::getSharedScriptBytecodeForIndex( /*0x1068a566e*/
      this: (RBX::Network::Server *)v7,
      a2: (__int64)a3,
      a3: ScriptIndexForSharedSource);
    RBX::Flyweight<RBX::SharedString::Data,void,true>::Flyweight(a1: this, a2: v7); /*0x1068a5679*/
    if ( v7[8] == 1 ) /*0x1068a5683*/
      RBX::Flyweight<RBX::SharedString::Data,void,true>::~Flyweight(a1: v7); /*0x1068a5689*/
  }
  else
  {
    RBX::SharedString::SharedString(this); /*0x1068a565b*/
  }
  return this; /*0x1068a5691*/
}

// Address: 0x1068a569c | Name: __ZNK3RBX7Network16ServerReplicator25reportProtectedStringHackEv
__int64 __fastcall RBX::Network::ServerReplicator::reportProtectedStringHack(RBX::DataModel **this, RBX::Instance *a2)
{
  __int64 v2; // rax
  __int64 v3; // rbx
  __int64 v4; // rax
  std::__shared_weak_count *v5; // rbx
  std::__shared_weak_count *v7[4]; // [rsp+0h] [rbp-90h] BYREF
  __int128 v8; // [rsp+20h] [rbp-70h] BYREF
  __int128 v9; // [rsp+30h] [rbp-60h] BYREF
  __int64 (__fastcall **v10)(); // [rsp+40h] [rbp-50h] BYREF
  _BYTE v11[24]; // [rsp+48h] [rbp-48h]
  __int64 (__fastcall ***v12)(); // [rsp+60h] [rbp-30h]

  v2 = RBX::DataModel::get(this: *(this + 2828), a2); /*0x1068a56bf*/
  RBX::shared_from<RBX::DataModel>(a1: &v8, a2: v2); /*0x1068a56cb*/
  v3 = v8; /*0x1068a56d0*/
  if ( (_QWORD)v8 == 0 ) /*0x1068a56d7*/
    goto LABEL_13; /*0x1068a56d7*/
  v9 = v8; /*0x1068a56dd*/
  if ( *((_QWORD *)&v8 + 1) != 0 ) /*0x1068a56ec*/
    _InterlockedIncrement64((volatile signed __int64 *)(*((_QWORD *)&v8 + 1) + 16LL)); /*0x1068a56ee*/
  boost::bind<void,std::weak_ptr<RBX::DataModel>,std::weak_ptr<RBX::DataModel>>( /*0x1068a5705*/
    a1: (__int64)v7,
    a2: (__int64)RBX::Network::Replicator::RemoteCheatHelper2,
    a3: &v9);
  v10 = &off_10CAB0118; /*0x1068a5715*/
  qmemcpy(v11, v7, sizeof(v11)); /*0x1068a571f*/
  *(_OWORD *)&v7[1] = 0; /*0x1068a572f*/
  v12 = &v10; /*0x1068a5736*/
  RBX::DataModel::submitTask(a1: v3, a2: &v10, a3: 1); /*0x1068a5745*/
  if ( v12 == &v10 ) /*0x1068a5751*/
  {
    v4 = 4; /*0x1068a575f*/
  }
  else
  {
    v4 = 5; /*0x1068a5753*/
    if ( v12 == nullptr ) /*0x1068a575b*/
      goto LABEL_9; /*0x1068a575b*/
  }
  (*v12)[v4](); /*0x1068a5767*/
LABEL_9:
  if ( v7[2] != nullptr ) /*0x1068a5771*/
    std::__shared_weak_count::__release_weak(this: v7[2]); /*0x1068a5773*/
  if ( *((_QWORD *)&v9 + 1) != 0 ) /*0x1068a577f*/
    std::__shared_weak_count::__release_weak(this: *((std::__shared_weak_count **)&v9 + 1)); /*0x1068a5781*/
LABEL_13:
  v5 = *((std::__shared_weak_count **)&v8 + 1); /*0x1068a5786*/
  if ( *((_QWORD *)&v8 + 1) != 0 /*0x1068a579f*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v8 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x1068a57a7*/
    std::__shared_weak_count::__release_weak(this: v5); /*0x1068a57ad*/
  }
  return __stack_chk_guard; /*0x1068a57c2*/
}

// Address: 0x1068a5894 | Name: __ZN3RBX7Network16ServerReplicator29schemaCanUseObjectPacketCacheEPKNS_6ObjectERKNS0_18NetworkSchemaTypes9ClassInfoE
char __fastcall RBX::Network::ServerReplicator::schemaCanUseObjectPacketCache(__int64 a1, __int64 a2)
{
  __int64 v3; // rdi
  __int64 v4; // rsi
  char result; // al
  __int64 v6; // r14
  __int64 v7; // rax
  __int64 v8; // r14
  __int64 v9; // rax
  __int64 v10; // rdi
  __int64 v11; // r14
  __int64 v12; // rax
  __int64 v13; // rbx
  __int64 v14; // rax

  if ( RBX::detail::DenseHashTable<RBX::Reflection::ClassDescriptor const*,RBX::Reflection::ClassDescriptor const*,RBX::Reflection::ClassDescriptor const*,RBX::detail::ItemInterfaceSet<RBX::Reflection::ClassDescriptor const*>,RBX::Hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>::find(a1: *(_QWORD *)(a1 + 22024) + 80LL) != 0 ) /*0x1068a58c0*/
    return 0; /*0x1068a58c0*/
  v6 = *(_QWORD *)(a2 + 24); /*0x1068a58cd*/
  v7 = RBX::Reflection::Class_getDescriptorPtr<RBX::BasePart>(a1: v3, a2: v4); /*0x1068a58d1*/
  if ( *(unsigned __int16 *)(v6 + 440) - (unsigned int)*(unsigned __int16 *)(v7 + 440) > *(unsigned __int16 *)(v7 + 442) ) /*0x1068a58f0*/
  {
    v8 = *(_QWORD *)(a2 + 24); /*0x1068a58f2*/
    v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::Soundscape::Sound>(); /*0x1068a58f6*/
    if ( *(unsigned __int16 *)(v8 + 440) - (unsigned int)*(unsigned __int16 *)(v9 + 440) > *(unsigned __int16 *)(v9 + 442) ) /*0x1068a5915*/
    {
      v11 = *(_QWORD *)(a2 + 24); /*0x1068a5917*/
      v12 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(a1: v10); /*0x1068a591b*/
      if ( *(unsigned __int16 *)(v11 + 440) - (unsigned int)*(unsigned __int16 *)(v12 + 440) > *(unsigned __int16 *)(v12 + 442) ) /*0x1068a593a*/
      {
        v13 = *(_QWORD *)(a2 + 24); /*0x1068a593c*/
        v14 = RBX::Reflection::Class_getDescriptorPtr<RBX::VideoFrame>(); /*0x1068a5940*/
        return *(unsigned __int16 *)(v13 + 440) - (unsigned int)*(unsigned __int16 *)(v14 + 440) > *(unsigned __int16 *)(v14 + 442); /*0x1068a5961*/
      }
    }
    return 0; /*0x1068a593a*/
  }
  if ( (*(_BYTE *)(a2 + 400) & 2) != 0 ) /*0x1068a596d*/
    return 0; /*0x1068a58c2*/
  result = 1; /*0x1068a5973*/
  if ( DFFlag::DebugForceBasePartCacheAlways == 0 ) /*0x1068a597c*/
    return RBX::BasePart::getAssemblyRootNetworkIsSleeping(this: (RBX::BasePart *)a2); /*0x1068a5985*/
  return result; /*0x1068a58c4*/
}

// Address: 0x1068a5990 | Name: __ZN3RBX7Network16ServerReplicator25processPacketLimitReachedERKNS_5TimerILNS_4Time12SampleMethodE0EEE
unsigned __int8 __fastcall RBX::Network::ServerReplicator::processPacketLimitReached(RBX *a1, double *a2)
{
  if ( (RBX::Time::now<(RBX::Time::SampleMethod)0>(a1) - *a2) * 1000.0 <= (double)DFInt::ServerItemTimeLimitMs ) /*0x1068a59ba*/
    return RBX::Network::Replicator::processPacketLimitReached(a1, (__int64)a2); /*0x1068a59cd*/
  else
    return 1; /*0x1068a59bc*/
}

// Address: 0x1068a59d2 | Name: __ZN3RBX7Network16ServerReplicator29shouldRateLimitRxRemoteEventsEPKNS_6ObjectERKNS_10Reflection15EventDescriptorERKNSt3__16vectorINS5_7VariantENS9_9allocatorISB_EEEE
bool __fastcall RBX::Network::ServerReplicator::shouldRateLimitRxRemoteEvents(
        RBX::Time *this,
        const RBX::Object *a2,
        const RBX::Reflection::EventDescriptor *a3)
{
  __int64 v4; // r14
  __int64 v5; // r13
  RBX::Time *v6; // rdi
  double v7; // xmm0_8
  __int64 v8; // rax
  const char *v9; // rdx
  RBX::Time *v10; // rdi
  __int64 v11; // r15
  int v12; // r12d
  const char *v13; // rsi
  int v14; // ecx
  int v15; // r8d
  int v16; // r9d
  char *v17; // rsi
  __int64 v18; // rdx
  __int64 v19; // xmm0_8
  char v21; // [rsp+0h] [rbp-40h] BYREF
  char v22; // [rsp+1h] [rbp-3Fh] BYREF
  RBX::Time *v23; // [rsp+10h] [rbp-30h]

  v4 = RBX::Network::Replicator::rateLimitChecks(this, a2, a3); /*0x1068a59eb*/
  v5 = *((_QWORD *)this + 1556); /*0x1068a59ee*/
  if ( (v4 & v5) != 0 ) /*0x1068a59f8*/
  {
    RBX::Network::Replicator::reportRateLimitEventToInflux(this); /*0x1068a5a04*/
    RBX::Time::nowFast(this: v6); /*0x1068a5a09*/
    if ( FInt::AntiSpamSpamLimit > 0 && v7 - *((double *)this + 2763) > (double)FInt::AntiSpamSpamLimit / 1000.0 ) /*0x1068a5a34*/
    {
      v8 = (*(__int64 (__fastcall **)(RBX::Time *))(*(_QWORD *)this + 696LL))(a1: this); /*0x1068a5a40*/
      if ( v8 != 0 ) /*0x1068a5a49*/
      {
        v11 = v8; /*0x1068a5a4b*/
        v12 = v4 & *((_DWORD *)this + 3112); /*0x1068a5a55*/
        std::string::basic_string[abi:ne200100]<0>(a1: &v21, a2: "Player \"%s\" appears to be spamming ", v9); /*0x1068a5a63*/
        v13 = "unreliable remote events."; /*0x1068a5a73*/
        if ( (v12 & 0x20) == 0 ) /*0x1068a5a7a*/
          v13 = "remote events."; /*0x1068a5a7a*/
        std::string::append(a1: &v21, a2: v13); /*0x1068a5a82*/
        if ( (v21 & 1) != 0 ) /*0x1068a5a8b*/
          LODWORD(v17) = (_DWORD)v23; /*0x1068a5a8d*/
        else
          v17 = &v22; /*0x1068a5a93*/
        v18 = *(_QWORD *)(v11 + 112); /*0x1068a5a97*/
        if ( (*(_BYTE *)(v18 + 8) & 1) != 0 ) /*0x1068a5a9f*/
          v18 = *(_QWORD *)(v18 + 24); /*0x1068a5aa7*/
        else
          LODWORD(v18) = v18 + 9; /*0x1068a5aa1*/
        RBX::CreatorLog::printf(a1: 2, a2: (_DWORD)v17, a3: v18, a4: v14, a5: v15, a6: v16); /*0x1068a5ab2*/
        if ( (v21 & 1) != 0 ) /*0x1068a5abb*/
          operator delete(a1: v23); /*0x1068a5ac1*/
      }
      RBX::Time::nowFast(this: v10); /*0x1068a5ac6*/
      *((_QWORD *)this + 2763) = v19; /*0x1068a5acb*/
    }
  }
  return (v4 & v5) != 0; /*0x1068a5ad9*/
}

// Address: 0x1068a5b02 | Name: __ZN3RBX7Network16ServerReplicator13isRateLimitedERKNS0_31DeserializedEventInvocationItemE
char __fastcall RBX::Network::ServerReplicator::isRateLimited(
        RBX::Network::ServerReplicator *this,
        const RBX::Network::DeserializedEventInvocationItem *a2)
{
  if ( *((_QWORD *)this + 1556) != 0 || DFInt::RatePermyriad > 0 ) /*0x1068a5b1f*/
    return (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *, _QWORD, _QWORD, char *))(*(_QWORD *)this + 1080LL))( /*0x1068a5b4e*/
             a1: this,
             a2: *((_QWORD *)a2 + 4),
             a3: *((_QWORD *)a2 + 6),
             a4: (char *)a2 + 56)
         & (*((_QWORD *)this + 1556) != 0);
  else
    return 0; /*0x1068a5b21*/
}

// Address: 0x1068a5b58 | Name: __ZN3RBX7Network16ServerReplicator21sendJoinStatsToInfluxEv
void __fastcall RBX::Network::ServerReplicator::sendJoinStatsToInflux(RBX::Network::ServerReplicator *this)
{
  RBX::MegaClusterInstance *v2; // rdi
  char isAllocated; // al
  __int64 RakNetStats; // rax
  _BYTE v5[16]; // [rsp+8h] [rbp-28h] BYREF
  void *v6; // [rsp+18h] [rbp-18h]

  v2 = *((RBX::MegaClusterInstance **)this + 1570); /*0x1068a5b66*/
  if ( v2 != nullptr ) /*0x1068a5b70*/
    isAllocated = RBX::MegaClusterInstance::isAllocated(this: v2); /*0x1068a5b72*/
  else
    isAllocated = 0; /*0x1068a5b79*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068a5b8f*/
    this: (RBX::Network::ServerReplicator *)((char *)this + 22112),
    a2: "HasTerrain",
    a3: isAllocated);
  if ( *((_BYTE *)this + 10391) == 0 ) /*0x1068a5b9c*/
  {
    RakNetStats = RBX::Network::Replicator::getRakNetStats(this); /*0x1068a5ba1*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1068a5bb7*/
      this: (RBX::Network::ServerReplicator *)((char *)this + 22112),
      a2: "BytesSent",
      a3: *(_QWORD *)(RakNetStats + 296));
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v5, a2: "ServerJoin"); /*0x1068a5bca*/
  RBX::Analytics::InfluxDb::Points::report( /*0x1068a5be0*/
    a1: (char *)this + 22112,
    a2: v5,
    a3: (unsigned int)DFInt::JoinInfluxHundredthsPercentage,
    a4: 0);
  if ( (v5[0] & 1) != 0 ) /*0x1068a5be9*/
    operator delete(a1: v6); /*0x1068a5bef*/
}

// Address: 0x1068a5c18 | Name: __ZN3RBX7Network16ServerReplicator20checkUnprocessedSizeEv
unsigned __int64 __fastcall RBX::Network::ServerReplicator::checkUnprocessedSize(RBX::Network::ServerReplicator *this)
{
  unsigned __int64 result; // rax

  result = (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 1048LL))(a1: this); /*0x1068a5c24*/
  if ( (_BYTE)result == 0 ) /*0x1068a5c2c*/
  {
    result = (unsigned int)(DFInt::QLimit << 20); /*0x1068a5c37*/
    if ( *((_QWORD *)this + 1884) > result ) /*0x1068a5c41*/
    {
      RBX::Network::Replicator::reportRateLimitEventToInflux(this); /*0x1068a5c4b*/
      result = (unsigned int)(DFInt::QKick << 20); /*0x1068a5c59*/
      if ( *((_QWORD *)this + 1884) > result ) /*0x1068a5c63*/
        return (*(__int64 (__fastcall **)(RBX::Network::ServerReplicator *))(*(_QWORD *)this + 840LL))(a1: this); /*0x1068a5c71*/
    }
  }
  return result; /*0x1068a5c7b*/
}

// Address: 0x1068a5c7e | Name: __ZN3RBX7Network16ServerReplicator29sendLuaKickMessageBeforeDiscoERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEESA_
void __fastcall RBX::Network::ServerReplicator::sendLuaKickMessageBeforeDisco(
        RBX::Network::Replicator *this,
        unsigned __int8 *a2,
        unsigned __int8 *a3)
{
  bool LuaKickIncludesMetadata; // al
  RBX::Network::NetworkStream *v7; // r15
  unsigned int v8; // eax
  unsigned int v9; // eax
  __int64 v10; // rcx
  RBX::Network *v11; // rdi
  unsigned __int64 v12; // rdx
  unsigned int v13; // eax
  __int64 v14; // rcx
  RBX::Network::NetworkStream *v15; // r15
  unsigned int v16; // eax
  unsigned __int64 v17; // rdx
  unsigned int v18; // eax
  __int64 v19; // rcx
  volatile signed __int64 *v20; // r14
  std::__shared_weak_count *v21; // rbx
  _QWORD v22[2]; // [rsp+10h] [rbp-80h] BYREF
  _QWORD v23[2]; // [rsp+20h] [rbp-70h] BYREF
  __int128 v24; // [rsp+30h] [rbp-60h] BYREF
  RBX::Network *v25; // [rsp+40h] [rbp-50h]
  RBX::Network::NetworkStream *v26; // [rsp+60h] [rbp-30h] BYREF
  std::__shared_weak_count *v27; // [rsp+68h] [rbp-28h]

  if ( *((_QWORD *)this + 2824) == 0 ) /*0x1068a5c95*/
    return; /*0x1068a5c95*/
  RBX::make_shared<RBX::Network::NetworkStream>(a1: &v26); /*0x1068a5cab*/
  LOBYTE(v24) = -104; /*0x1068a5cb7*/
  RBX::Network::NetworkStream::writeBytes(this: v26, a2: &v24, a3: 1u); /*0x1068a5cbf*/
  LuaKickIncludesMetadata = RBX::Network::Replicator::getLuaKickIncludesMetadata(this); /*0x1068a5cc7*/
  v7 = v26; /*0x1068a5ccc*/
  if ( LuaKickIncludesMetadata ) /*0x1068a5cd2*/
  {
    v8 = *a2; /*0x1068a5cd4*/
    if ( (v8 & 1) != 0 ) /*0x1068a5cdb*/
    {
      v12 = *((_QWORD *)a2 + 1); /*0x1068a5d15*/
      if ( v12 <= DFInt::LuaKickMaxMessageLength ) /*0x1068a5d24*/
      {
        std::string::__init_copy_ctor_external(a1: &v24, a2: *((_QWORD *)a2 + 2), a3: v12); /*0x1068a5d41*/
LABEL_10:
        v13 = RBX::Network::Replicator::getWritePayloadLimit(this); /*0x1068a5d46*/
        RBX::Network::NetworkStream::writeString(a1: v7, a2: &v24, a3: v13, a4: v14); /*0x1068a5d57*/
        if ( (v24 & 1) != 0 ) /*0x1068a5d60*/
          operator delete(a1: v25); /*0x1068a5d66*/
        v15 = v26; /*0x1068a5d6b*/
        v16 = *a3; /*0x1068a5d6f*/
        if ( (v16 & 1) != 0 ) /*0x1068a5d75*/
        {
          v17 = *((_QWORD *)a3 + 1); /*0x1068a5d93*/
          if ( v17 <= DFInt::LuaKickMaxMetadataLength ) /*0x1068a5da1*/
          {
            std::string::__init_copy_ctor_external(a1: &v24, a2: *((_QWORD *)a3 + 2), a3: v17); /*0x1068a5dbd*/
LABEL_18:
            v18 = RBX::Network::Replicator::getWritePayloadLimit(this); /*0x1068a5dc2*/
            RBX::Network::NetworkStream::writeString(a1: v15, a2: &v24, a3: v18, a4: v19); /*0x1068a5dd3*/
            if ( (v24 & 1) != 0 ) /*0x1068a5ddc*/
              operator delete(a1: v25); /*0x1068a5de2*/
            goto LABEL_20; /*0x1068a5de2*/
          }
        }
        else if ( DFInt::LuaKickMaxMetadataLength >= v16 >> 1 ) /*0x1068a5d7f*/
        {
          v25 = *((RBX::Network **)a3 + 2); /*0x1068a5d85*/
          v24 = *(_OWORD *)a3; /*0x1068a5d8d*/
          goto LABEL_18; /*0x1068a5d91*/
        }
        std::string::basic_string[abi:ne200100]<0>(a1: &v24, a2: ""); /*0x1068a5dae*/
        goto LABEL_18; /*0x1068a5db3*/
      }
    }
    else if ( DFInt::LuaKickMaxMessageLength >= v8 >> 1 ) /*0x1068a5ce5*/
    {
      v25 = *((RBX::Network **)a2 + 2); /*0x1068a5cec*/
      v24 = *(_OWORD *)a2; /*0x1068a5cf5*/
      goto LABEL_10; /*0x1068a5cf9*/
    }
    std::string::basic_string[abi:ne200100]<0>(a1: &v24, a2: ""); /*0x1068a5d31*/
    goto LABEL_10; /*0x1068a5d36*/
  }
  v9 = RBX::Network::Replicator::getWritePayloadLimit(this); /*0x1068a5cfe*/
  RBX::Network::NetworkStream::writeString(a1: v7, a2, a3: v9, a4: v10); /*0x1068a5d0b*/
LABEL_20:
  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v11) != 0 ) /*0x1068a5df2*/
  {
    v22[0] = v26; /*0x1068a5df4*/
    v20 = (volatile signed __int64 *)v27; /*0x1068a5df8*/
    v22[1] = v27; /*0x1068a5dfc*/
    if ( v27 != nullptr ) /*0x1068a5e03*/
      _InterlockedIncrement64((volatile signed __int64 *)v27 + 1); /*0x1068a5e05*/
    RBX::Network::ServerReplicator::safeSend(a1: (__int64)this, a2: (__int64)v22, a3: 1u); /*0x1068a5e16*/
  }
  else
  {
    v23[0] = v26; /*0x1068a5e1d*/
    v20 = (volatile signed __int64 *)v27; /*0x1068a5e21*/
    v23[1] = v27; /*0x1068a5e25*/
    if ( v27 != nullptr ) /*0x1068a5e2c*/
      _InterlockedIncrement64((volatile signed __int64 *)v27 + 1); /*0x1068a5e2e*/
    RakNet::AddressOrGUID::AddressOrGUID( /*0x1068a5e3e*/
      this: (RakNet::AddressOrGUID *)&v24,
      a2: (RBX::Network::Replicator *)((char *)this + 240));
    RBX::Network::ServerReplicator::safeSend_deprecated( /*0x1068a5e5f*/
      a1: (__int64)this,
      a2: (__int64)v23,
      a3: 0,
      a4: 3,
      a5: 0,
      a6: (__int64)&v24,
      a7: 0);
  }
  if ( v20 != nullptr && _InterlockedExchangeAdd64(v20 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068a5e79*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v20 + 16))(a1: v20); /*0x1068a5e81*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v20); /*0x1068a5e87*/
  }
  v21 = v27; /*0x1068a5e8c*/
  if ( v27 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v27 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1068a5ea5*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(a1: v21); /*0x1068a5ead*/
    std::__shared_weak_count::__release_weak(this: v21); /*0x1068a5eb3*/
  }
}

// Address: 0x106d73c96 | Name: __ZNK3RBX7Network16ServerReplicator13getAsInternalENS_10Reflection11InterfaceIdE
__int64 RBX::Network::ServerReplicator::getAsInternal()
{
  return 0; /*0x106d73c9c*/
}

// Address: 0x106d73c9e | Name: __ZN3RBX7Network16ServerReplicator35writeAllPropertiesForChangeTrackingEPNS_23DataModelChangeTracking13ChangeTrackerENS2_12DeltaTypeTagE
__int64 __fastcall RBX::Network::ServerReplicator::writeAllPropertiesForChangeTracking(__int64 a1)
{
  return RBX::Network::Replicator::writeAllPropertiesForChangeTracking(a1); /*0x106d73ca2*/
}

// Address: 0x106d73e30 | Name: __ZNK3RBX7Network16ServerReplicator16getTargetAddressEv
__int64 __fastcall RBX::Network::ServerReplicator::getTargetAddress(RBX::Network::ServerReplicator *this)
{
  return *((unsigned int *)this + 68); /*0x106d73e3a*/
}

// Address: 0x106d73e3c | Name: __ZNK3RBX7Network16ServerReplicator16findTargetPlayerEv
__int64 __fastcall RBX::Network::ServerReplicator::findTargetPlayer(RBX::Network::ServerReplicator *this)
{
  return *((_QWORD *)this + 2824); /*0x106d73e47*/
}

// Address: 0x106d73e4a | Name: __ZNK3RBX7Network16ServerReplicator15getRemotePlayerEv
__int64 __fastcall RBX::Network::ServerReplicator::getRemotePlayer(RBX::Network::ServerReplicator *this)
{
  return *((_QWORD *)this + 2824); /*0x106d73e55*/
}

// Address: 0x106d73e58 | Name: __ZNK3RBX7Network16ServerReplicator9getServerEv
__int64 __fastcall RBX::Network::ServerReplicator::getServer(RBX::Network::ServerReplicator *this)
{
  return *((_QWORD *)this + 2828); /*0x106d73e63*/
}

// Address: 0x106d73e66 | Name: __ZNK3RBX7Network16ServerReplicator14getPlatformKeyEv
__int64 __fastcall RBX::Network::ServerReplicator::getPlatformKey(RBX::Network::ServerReplicator *this)
{
  return 0; /*0x106d73e6c*/
}

// Address: 0x106d73e6e | Name: __ZN3RBX7Network16ServerReplicator27trackMaybeUnusedRemoteEventERKNS_10Reflection15EventDescriptorE
void __fastcall RBX::Network::ServerReplicator::trackMaybeUnusedRemoteEvent(
        RBX::Network::ServerReplicator *this,
        const RBX::Reflection::EventDescriptor *a2)
{
  ; /*0x106d73e6e*/
}

// Address: 0x106d73e74 | Name: __ZNK3RBX7Network16ServerReplicator18isSuspectedToBeBotEj
__int64 __fastcall RBX::Network::ServerReplicator::isSuspectedToBeBot(RBX::Network::ServerReplicator *this)
{
  return 0; /*0x106d73e7a*/
}

// Address: 0x106d73e7c | Name: __ZNK3RBX7Network16ServerReplicator20isSuspectedToBeHumanEj
__int64 __fastcall RBX::Network::ServerReplicator::isSuspectedToBeHuman(RBX::Network::ServerReplicator *this)
{
  return 0; /*0x106d73e82*/
}

// Address: 0x106d73e84 | Name: __ZN3RBX7Network16ServerReplicator18updateBotHeuristicEv
void __fastcall RBX::Network::ServerReplicator::updateBotHeuristic(RBX::Network::ServerReplicator *this)
{
  ; /*0x106d73e84*/
}

// Address: 0x106d73e8a | Name: __ZN3RBX7Network16ServerReplicator22addLastNetProcessingUsEj
void __fastcall RBX::Network::ServerReplicator::addLastNetProcessingUs(RBX::Network::ServerReplicator *this)
{
  ; /*0x106d73e8a*/
}

// Address: 0x106d73e90 | Name: __ZN3RBX7Network16ServerReplicator16setAuthenticatedEb
void __fastcall RBX::Network::ServerReplicator::setAuthenticated(RBX::Network::ServerReplicator *this)
{
  ; /*0x106d73e90*/
}

// Address: 0x106d73e96 | Name: __ZN3RBX7Network16ServerReplicator19onPlayerlessClusterEPKNS_8InstanceE
__int64 __fastcall RBX::Network::ServerReplicator::onPlayerlessCluster(
        RBX::Network::ServerReplicator *this,
        const RBX::Instance *a2)
{
  return 0; /*0x106d73e9c*/
}

// Address: 0x106d73e9e | Name: __ZN3RBX7Network16ServerReplicator19onPlayerlessPhysicsEPNS_8BasePartE
__int64 __fastcall RBX::Network::ServerReplicator::onPlayerlessPhysics(
        RBX::Network::ServerReplicator *this,
        RBX::BasePart *a2)
{
  return 0; /*0x106d73ea4*/
}

// Address: 0x106d73ea6 | Name: __ZN3RBX7Network16ServerReplicator18onPlayerlessDeleteEPKNS_8InstanceE
__int64 __fastcall RBX::Network::ServerReplicator::onPlayerlessDelete(
        RBX::Network::ServerReplicator *this,
        const RBX::Instance *a2)
{
  return 0; /*0x106d73eac*/
}

// Address: 0x106d73eae | Name: __ZN3RBX7Network16ServerReplicator15onPlayerlessNewEPKNS_6ObjectE
__int64 __fastcall RBX::Network::ServerReplicator::onPlayerlessNew(
        RBX::Network::ServerReplicator *this,
        const RBX::Object *a2)
{
  return 0; /*0x106d73eb4*/
}

// Address: 0x106d73eb6 | Name: __ZN3RBX7Network16ServerReplicator20onPlayerlessPropertyEPKNS_6ObjectERKNS_10Reflection18PropertyDescriptorE
__int64 __fastcall RBX::Network::ServerReplicator::onPlayerlessProperty(
        RBX::Network::ServerReplicator *this,
        const RBX::Object *a2,
        const RBX::Reflection::PropertyDescriptor *a3)
{
  return 0; /*0x106d73ebc*/
}

// Address: 0x106d73ebe | Name: __ZN3RBX7Network16ServerReplicator20performPostJoinSetupEv
void __fastcall RBX::Network::ServerReplicator::performPostJoinSetup(RBX::Network::ServerReplicator *this)
{
  ; /*0x106d73ebe*/
}

// Address: 0x106d73ec4 | Name: __ZN3RBX7Network16ServerReplicator23setMaxClientBandwithBpsEi
void __fastcall RBX::Network::ServerReplicator::setMaxClientBandwithBps(RBX::Network::ServerReplicator *this, int a2)
{
  *((_DWORD *)this + 4680) = a2; /*0x106d73ec8*/
}

// Address: 0x106d73ed0 | Name: __ZN3RBX7Network16ServerReplicator19onClientSecurityReqENS_9ArrayViewIhEEPKNS0_20SecurityChannelStatsEy
void RBX::Network::ServerReplicator::onClientSecurityReq()
{
  ; /*0x106d73ed0*/
}

// Address: 0x106d73ed6 | Name: __ZN3RBX7Network16ServerReplicator23handleSecurityViolationEPKcNS1_15KickCounterTypeENS1_27ResponseToSecurityViolationES3_PKNS_9Analytics8InfluxDb6PointsE
void RBX::Network::ServerReplicator::handleSecurityViolation()
{
  ; /*0x106d73ed6*/
}

// Address: 0x106d73edc | Name: __ZN3RBX7Network16ServerReplicator33handleSecurityViolationDuringJoinEiPKcNS1_15KickCounterTypeENS1_27ResponseToSecurityViolationEPKNS_9Analytics8InfluxDb6PointsEb
void RBX::Network::ServerReplicator::handleSecurityViolationDuringJoin()
{
  ; /*0x106d73edc*/
}

// Address: 0x106d73ee2 | Name: __ZN3RBX7Network16ServerReplicator21extraIdSyncProcessingEhRNS0_13NetworkStreamE
void __fastcall RBX::Network::ServerReplicator::extraIdSyncProcessing(
        RBX::Network::ServerReplicator *this,
        unsigned __int8 a2,
        RBX::Network::NetworkStream *a3)
{
  ; /*0x106d73ee2*/
}

// Address: 0x106d73ee8 | Name: __ZN3RBX7Network16ServerReplicator17handleDeviceBlockExxb
void __fastcall RBX::Network::ServerReplicator::handleDeviceBlock(RBX::Network::ServerReplicator *this)
{
  ; /*0x106d73ee8*/
}

// Address: 0x106d73eee | Name: __ZThn216_N3RBX7Network16ServerReplicator23setMaxClientBandwithBpsEi
void __fastcall `non-virtual thunk to'RBX::Network::ServerReplicator::setMaxClientBandwithBps(
        RBX::Network::ServerReplicator *this,
        int a2)
{
  *((_DWORD *)this + 4626) = a2; /*0x106d73ef2*/
}

// Address: 0x1087697d1 | Name: __ZN3RBX7Network16ServerReplicator16rebroadcastEventEPNS0_31DeserializedEventInvocationItemE.cold.1
void __fastcall RBX::Network::ServerReplicator::rebroadcastEvent(
        void **this,
        RBX::Network::DeserializedEventInvocationItem *a2)
{
  if ( (*(_BYTE *)(this + 2) & 1) != 0 ) /*0x1087697d5*/
    operator delete(a1: *(this + 4)); /*0x1087697df*/
}

// Address: 0x1087697e6 | Name: __ZN3RBX7Network16ServerReplicator18joinMarkerReceivedEv.cold.1
void __fastcall RBX::Network::ServerReplicator::joinMarkerReceived(
        RBX::Network::ServerReplicator *this,
        _QWORD *a2,
        __int64 a3)
{
  _QWORD *v4; // rdi
  __int64 v5; // [rsp-10h] [rbp-18h]

  v4 = *(_QWORD **)this; /*0x1087697ef*/
  if ( v4 == a2 ) /*0x1087697f5*/
  {
    v5 = 32; /*0x108769800*/
  }
  else
  {
    if ( v4 == nullptr ) /*0x1087697fa*/
      goto LABEL_6; /*0x1087697fa*/
    v5 = 40; /*0x1087697fc*/
  }
  (*(void (__fastcall **)(_QWORD *))(*v4 + v5))(a1: v4); /*0x108769806*/
LABEL_6:
  if ( (*(_BYTE *)a3 & 1) != 0 ) /*0x10876980c*/
    operator delete(a1: *(void **)(a3 + 16)); /*0x108769812*/
}

// Address: 0x108769848 | Name: __ZN3RBX7Network16ServerReplicator25writeAttributeVersionInfoERNS0_13NetworkStreamEPKNS_8InstanceERKNSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEE.cold.1
void __fastcall RBX::Network::ServerReplicator::writeAttributeVersionInfo(__int64 a1)
{
  if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x10876984b*/
    operator delete(a1: *(void **)(a1 + 16)); /*0x108769855*/
}

// END ServerReplicator part 1/1, 136 functions
