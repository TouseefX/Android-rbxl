// RakNetConnection -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 17 functions


// Address: 0x106724050 | Name: __ZN3RBX7Network16RakNetConnectionC2ENS_6PeerIdERN6RakNet16RakPeerInterfaceE
__int64 __fastcall RBX::Network::RakNetConnection::RakNetConnection(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax

  RBX::NetworkBase::ConnectionInternal::ConnectionInternal(); /*0x10672405d*/
  *(_QWORD *)a1 = off_10CAA8EF8; /*0x106724069*/
  *(_QWORD *)(a1 + 1896) = a3; /*0x10672406c*/
  result = RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)(a1 + 1912)); /*0x10672407a*/
  *(_BYTE *)(a1 + 1944) = 0; /*0x10672407f*/
  return result; /*0x106724086*/
}

// Address: 0x106724120 | Name: __ZN3RBX7Network16RakNetConnectionC1ENS_6PeerIdERN6RakNet16RakPeerInterfaceE
__int64 __fastcall RBX::Network::RakNetConnection::RakNetConnection(__int64 a1, __int64 a2, __int64 a3)
{
  return RBX::Network::RakNetConnection::RakNetConnection(a1, a2, a3); /*0x106724124*/
}

// Address: 0x10672412a | Name: __ZN3RBX7Network16RakNetConnectionC2ENS_6PeerIdEPNS0_17ConcurrentRakPeerEN6RakNet13SystemAddressE
__int64 __fastcall RBX::Network::RakNetConnection::RakNetConnection(
        __int64 a1,
        __int64 a2,
        RBX::Network::ConcurrentRakPeer *a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int128 a7,
        __int128 a8)
{
  __int64 result; // rax

  RBX::NetworkBase::ConnectionInternal::ConnectionInternal(); /*0x106724137*/
  *(_QWORD *)a1 = off_10CAA8EF8; /*0x106724143*/
  result = RBX::Network::ConcurrentRakPeer::rawPeer(this: a3); /*0x106724149*/
  *(_QWORD *)(a1 + 1896) = result; /*0x106724152*/
  *(_QWORD *)(a1 + 1904) = a3; /*0x106724159*/
  *(_OWORD *)(a1 + 1912) = a7; /*0x106724167*/
  *(_OWORD *)(a1 + 1928) = a8; /*0x10672416e*/
  *(_BYTE *)(a1 + 1944) = 0; /*0x106724175*/
  return result; /*0x10672417c*/
}

// Address: 0x106724194 | Name: __ZN3RBX7Network16RakNetConnectionC1ENS_6PeerIdEPNS0_17ConcurrentRakPeerEN6RakNet13SystemAddressE
__int64 __fastcall RBX::Network::RakNetConnection::RakNetConnection(
        __int64 a1,
        __int64 a2,
        RBX::Network::ConcurrentRakPeer *a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int128 a7,
        __int128 a8)
{
  return RBX::Network::RakNetConnection::RakNetConnection(a1, a2, a3, a4, a5, a6, a7, a8); /*0x106724198*/
}

// Address: 0x10672419e | Name: __ZN3RBX7Network16RakNetConnection4sendENS_11NetworkBase7ChannelENSt3__110shared_ptrINS0_13NetworkStreamEEENS4_8optionalIyEE
__int64 __fastcall RBX::Network::RakNetConnection::send(
        RBX::NetworkBase::ConnectionInternal *this,
        unsigned int a2,
        RBX::Network::NetworkStream **a3,
        __int64 a4,
        unsigned int a5)
{
  RBX::NetworkBase::ConnectionInternal *v9; // r14
  __int64 v10; // rax
  unsigned int v11; // r13d
  const unsigned __int8 *v12; // r15
  unsigned int v13; // eax
  const unsigned __int8 *v14; // rsi
  unsigned int v15; // r15d
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // rsi
  __int64 v19; // r8
  __int64 v20; // r9
  int v21; // eax
  unsigned __int8 v22; // bl
  _QWORD *v23; // rdi
  RBX::Network::NetworkStream *v24; // rax
  volatile signed __int64 *v25; // rbx
  _QWORD *v26; // rdi
  _QWORD *v27; // rdi
  RBX::Network::NetworkStream *v28; // rax
  unsigned __int8 v29; // cl
  _QWORD *v30; // rdi
  RBX::Network::NetworkStream *v31; // rax
  unsigned int v32; // eax
  unsigned int v33; // r15d
  unsigned int v34; // eax
  unsigned int v35; // edx
  __int64 v36; // r8
  unsigned __int8 v37; // r9
  unsigned int v38; // ecx
  char v39; // al
  __int128 *v40; // r10
  _QWORD *v41; // rdi
  __int128 v43; // [rsp+40h] [rbp-90h] BYREF
  __int128 v44; // [rsp+50h] [rbp-80h] BYREF
  std::__shared_weak_count *v45[2]; // [rsp+60h] [rbp-70h] BYREF
  __int128 v46; // [rsp+70h] [rbp-60h] BYREF
  __int128 v47; // [rsp+80h] [rbp-50h] BYREF
  __int64 v48; // [rsp+90h] [rbp-40h]
  unsigned int v49; // [rsp+9Ch] [rbp-34h]
  __int128 *v50; // [rsp+A0h] [rbp-30h]

  v9 = this; /*0x1067241be*/
  if ( DFFlag::DebugNetworkProfiler == 1 ) /*0x1067241cb*/
  {
    this = *a3; /*0x1067241cd*/
    if ( *a3 != nullptr /*0x1067241de*/
      && (*(unsigned int (__fastcall **)(RBX::NetworkBase::ConnectionInternal *))(*(_QWORD *)this + 24LL))(a1: this) != 0 )
    {
      v10 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)*a3 + 16LL))(a1: *a3); /*0x1067241e7*/
      v49 = a2; /*0x1067241ea*/
      v11 = a5; /*0x1067241ee*/
      v12 = (const unsigned __int8 *)v10; /*0x1067241f1*/
      v13 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)*a3 + 24LL))(a1: *a3); /*0x1067241fb*/
      v14 = v12; /*0x106724201*/
      a5 = v11; /*0x106724204*/
      a2 = v49; /*0x106724207*/
      RBX::NetworkBase::ConnectionInternal::recordPacketCapture(this: v9, a2: v14, a3: v13); /*0x10672420d*/
    }
  }
  if ( RBX::Network::flagsSendsGoThroughConnection(this) == 0 ) /*0x106724219*/
  {
    if ( a2 == 3 ) /*0x1067242b3*/
    {
      v26 = *((_QWORD **)v9 + 238); /*0x106724346*/
      v44 = *(_OWORD *)a3; /*0x106724356*/
      *(_OWORD *)a3 = 0; /*0x10672435e*/
      if ( ((unsigned __int8)a5 & (unsigned __int8)DFFlag::ConnectionSendPushesTracerIdThrough) == 0 ) /*0x10672437a*/
        a4 = 0; /*0x10672437a*/
      v15 = RBX::Network::ConcurrentRakPeer::Send_deprecated( /*0x1067243c0*/
              a1: v26,
              a2: &v44,
              a3: 2 - (unsigned int)(unsigned __int8)DFFlag::PhysicsSendHighPriority,
              a4: 5u,
              a5: 0,
              a6: 0,
              a7: *(_OWORD *)((char *)v9 + 1912),
              a8: *(_OWORD *)((char *)v9 + 1928),
              a9: 0,
              a10: 1,
              a11: a4);
      v25 = *((volatile signed __int64 **)&v44 + 1); /*0x1067243c3*/
    }
    else if ( a2 == 1 ) /*0x1067242bd*/
    {
      v23 = *((_QWORD **)v9 + 238); /*0x1067242c3*/
      v24 = a3[1]; /*0x1067242ca*/
      *(_OWORD *)v45 = *(_OWORD *)a3; /*0x1067242d4*/
      if ( v24 != nullptr ) /*0x1067242db*/
        _InterlockedIncrement64((volatile signed __int64 *)v24 + 1); /*0x1067242dd*/
      if ( ((unsigned __int8)a5 & (unsigned __int8)DFFlag::ConnectionSendPushesTracerIdThrough) == 0 ) /*0x1067242eb*/
        a4 = 0; /*0x1067242eb*/
      v15 = RBX::Network::ConcurrentRakPeer::Send_deprecated( /*0x10672433a*/
              a1: v23,
              a2: v45,
              a3: 2u,
              a4: 3u,
              a5: 0,
              a6: 0,
              a7: *(_OWORD *)((char *)v9 + 1912),
              a8: *(_OWORD *)((char *)v9 + 1928),
              a9: 0,
              a10: 1,
              a11: a4);
      v25 = (volatile signed __int64 *)v45[1]; /*0x10672433d*/
    }
    else if ( a2 == 11 /*0x1067243eb*/
           && (((unsigned __int8)FFlag::DebugHashTableMetrics | (unsigned __int8)FFlag::SAuthWorkspaceFlagged) & 1) != 0 )
    {
      v27 = *((_QWORD **)v9 + 238); /*0x1067243f1*/
      v28 = a3[1]; /*0x1067243f8*/
      v46 = *(_OWORD *)a3; /*0x106724402*/
      if ( v28 != nullptr ) /*0x106724409*/
        _InterlockedIncrement64((volatile signed __int64 *)v28 + 1); /*0x10672440b*/
      if ( ((unsigned __int8)a5 & (unsigned __int8)DFFlag::ConnectionSendPushesTracerIdThrough) == 0 ) /*0x106724419*/
        a4 = 0; /*0x106724419*/
      v15 = RBX::Network::ConcurrentRakPeer::Send_deprecated( /*0x106724468*/
              a1: v27,
              a2: &v46,
              a3: 1u,
              a4: 0,
              a5: 5,
              a6: 0,
              a7: *(_OWORD *)((char *)v9 + 1912),
              a8: *(_OWORD *)((char *)v9 + 1928),
              a9: 0,
              a10: 1,
              a11: a4);
      v25 = *((volatile signed __int64 **)&v46 + 1); /*0x10672446b*/
    }
    else
    {
      v29 = a5; /*0x106724474*/
      v15 = -1; /*0x106724477*/
      if ( a2 != 12 ) /*0x106724481*/
        return v15; /*0x106724481*/
      v30 = *((_QWORD **)v9 + 238); /*0x106724487*/
      v31 = a3[1]; /*0x10672448e*/
      v47 = *(_OWORD *)a3; /*0x106724498*/
      if ( v31 != nullptr ) /*0x10672449f*/
        _InterlockedIncrement64((volatile signed __int64 *)v31 + 1); /*0x1067244a1*/
      if ( (v29 & (unsigned __int8)DFFlag::ConnectionSendPushesTracerIdThrough) == 0 ) /*0x1067244ae*/
        a4 = 0; /*0x1067244ae*/
      v15 = RBX::Network::ConcurrentRakPeer::Send_deprecated( /*0x106724500*/
              a1: v30,
              a2: &v47,
              a3: 2u,
              a4: 3u,
              a5: 6,
              a6: 0,
              a7: *(_OWORD *)((char *)v9 + 1912),
              a8: *(_OWORD *)((char *)v9 + 1928),
              a9: 0,
              a10: 1,
              a11: a4);
      v25 = *((volatile signed __int64 **)&v47 + 1); /*0x106724503*/
    }
    goto LABEL_76; /*0x106724341*/
  }
  v49 = a5; /*0x10672421f*/
  v15 = -1; /*0x106724227*/
  if ( *a3 == nullptr /*0x10672423e*/
    || (*(unsigned int (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)*a3 + 24LL))(a1: *a3) == 0 )
  {
    return v15; /*0x10672423e*/
  }
  v48 = a4; /*0x106724244*/
  if ( *RBX::Profiler::active != 0 && *RBX::Profiler::mpNetVerbosity != 0 ) /*0x106724269*/
  {
    v21 = *(unsigned __int8 *)(*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)*a3 + 16LL))(a1: *a3); /*0x106724279*/
    if ( v21 <= 140 ) /*0x106724281*/
    {
      switch ( v21 ) /*0x10672450f*/
      {
        case 27: /*0x10672450f*/
          if ( ((*(__int64 (__fastcall **)(_QWORD, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(**((_QWORD **)v9 + 237) + 688LL))( /*0x10672457e*/
                  a1: *((_QWORD *)v9 + 237),
                  a2: v18,
                  a3: v16,
                  a4: v17,
                  a5: v19,
                  a6: v20,
                  a7: *((_QWORD *)v9 + 239),
                  a8: *((_QWORD *)v9 + 240),
                  a9: *((_QWORD *)v9 + 241),
                  a10: *((_QWORD *)v9 + 242))
              & 0x2000000) != 0
            && *(_BYTE *)((*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)*a3 + 16LL))(a1: *a3) + 9) != 0x85 )
          {
            break; /*0x10672457e*/
          }
          v22 = 1; /*0x10672458a*/
          if ( *(_BYTE *)((*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)*a3 + 16LL))(a1: *a3) /*0x106724590*/
                        + 17) != 0x85 )
            break; /*0x106724590*/
          goto LABEL_52; /*0x106724590*/
        case 131: /*0x10672450f*/
          v22 = 31; /*0x10672459c*/
          goto LABEL_52; /*0x10672459c*/
        case 134: /*0x10672450f*/
          v22 = 2; /*0x106724527*/
          goto LABEL_52; /*0x106724529*/
        default:
          break; /*0x10672450f*/
      }
    }
    else if ( v21 > 164 ) /*0x10672428c*/
    {
      if ( v21 == 165 ) /*0x106724530*/
      {
        v22 = 30; /*0x106724598*/
        goto LABEL_52; /*0x10672459a*/
      }
      if ( v21 == 166 ) /*0x106724537*/
      {
        v22 = 3; /*0x10672453d*/
        goto LABEL_52; /*0x10672453f*/
      }
    }
    else
    {
      if ( v21 == 141 ) /*0x106724297*/
      {
        v22 = 15; /*0x106724594*/
        goto LABEL_52; /*0x106724596*/
      }
      if ( v21 == 161 ) /*0x1067242a2*/
      {
        v22 = 1; /*0x1067242a8*/
LABEL_52:
        v32 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)*a3 + 24LL))(a1: *a3); /*0x10672459e*/
        RBX::Profiler::MicroProfileNetReplicaEvent(a1: v32, a2: 4, a3: 0, a4: v22, a5: -1); /*0x1067245bb*/
      }
    }
  }
  v33 = a2; /*0x1067245c0*/
  if ( a2 == 1 ) /*0x1067245c7*/
  {
    if ( (*(unsigned int (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)*a3 + 24LL))(a1: *a3) != 0 ) /*0x1067245d5*/
    {
      v33 = 1; /*0x1067245e9*/
      if ( *(_BYTE *)(*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)*a3 + 16LL))(a1: *a3) == 0x8D ) /*0x1067245ef*/
        v33 = 13; /*0x1067245ef*/
    }
    else
    {
      v33 = 1; /*0x1067245f5*/
    }
  }
  if ( ((*(__int64 (__fastcall **)(_QWORD, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(**((_QWORD **)v9 + 237) + 688LL))( /*0x106724628*/
          a1: *((_QWORD *)v9 + 237),
          a2: v18,
          a3: v16,
          a4: v17,
          a5: v19,
          a6: v20,
          a7: *((_QWORD *)v9 + 239),
          a8: *((_QWORD *)v9 + 240),
          a9: *((_QWORD *)v9 + 241),
          a10: *((_QWORD *)v9 + 242))
      & 0x400000) != 0 )
    RBX::NetworkBase::ConnectionInternal::compressNetworkStream(this: v9, a2: *a3, a3: 1.0); /*0x106724639*/
  v50 = (__int128 *)((char *)v9 + 1912); /*0x106724645*/
  v34 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)*a3 + 24LL))(a1: *a3); /*0x106724654*/
  RBX::Network::ChannelsMetrics::onChannelNetworked(a1: (__int64)v9 + 8, a2: v33, a3: v34); /*0x10672465f*/
  v35 = 1; /*0x10672466e*/
  v36 = v48; /*0x106724684*/
  v37 = v49; /*0x106724688*/
  switch ( a2 ) /*0x10672468c*/
  {
    case 0u: /*0x10672468c*/
      v39 = 2; /*0x1067246b1*/
      v38 = 2; /*0x1067246b3*/
      break; /*0x1067246b8*/
    case 1u: /*0x10672468c*/
    case 0xDu: /*0x10672468c*/
      v38 = 3; /*0x10672468e*/
      goto LABEL_71; /*0x106724693*/
    case 2u: /*0x10672468c*/
      v38 = 3; /*0x1067246ba*/
      v35 = 0; /*0x1067246bf*/
      goto LABEL_72; /*0x1067246c1*/
    case 3u: /*0x10672468c*/
      v38 = 0; /*0x1067246a0*/
      goto LABEL_71; /*0x1067246a2*/
    case 4u: /*0x10672468c*/
      v38 = 7; /*0x1067246d5*/
LABEL_71:
      v35 = 2; /*0x1067246da*/
      goto LABEL_72; /*0x1067246da*/
    case 5u: /*0x10672468c*/
      v35 = 2 - (unsigned __int8)DFFlag::PhysicsSendHighPriority; /*0x1067247ad*/
      v38 = 5; /*0x1067247af*/
      goto LABEL_72; /*0x1067247b4*/
    case 6u: /*0x10672468c*/
      v35 = 2 - (unsigned __int8)DFFlag::PhysicsSendHighPriority; /*0x1067246cf*/
      v38 = 0; /*0x1067246d1*/
      goto LABEL_72; /*0x1067246d3*/
    case 7u: /*0x10672468c*/
      v38 = 3; /*0x1067247ca*/
LABEL_72:
      v39 = 0; /*0x1067246df*/
      break; /*0x1067246df*/
    case 8u: /*0x10672468c*/
      v39 = 1; /*0x1067246aa*/
      goto LABEL_81; /*0x1067246ac*/
    case 9u: /*0x10672468c*/
      v39 = 4; /*0x1067247b9*/
      v35 = 3; /*0x1067247bb*/
      v38 = 3; /*0x1067247c0*/
      break; /*0x1067247c5*/
    case 0xAu: /*0x10672468c*/
      v39 = 1; /*0x106724695*/
      v38 = 3; /*0x106724697*/
      v35 = 0; /*0x10672469c*/
      break; /*0x10672469e*/
    case 0xBu: /*0x10672468c*/
      v39 = 5; /*0x1067246a4*/
      v38 = 0; /*0x1067246a6*/
      break; /*0x1067246a8*/
    case 0xCu: /*0x10672468c*/
      v39 = 6; /*0x106724790*/
LABEL_81:
      v38 = 3; /*0x106724792*/
      v35 = 2; /*0x106724797*/
      break; /*0x10672479c*/
    default:
      v39 = -1; /*0x1067247d4*/
      v38 = 8; /*0x1067247d6*/
      v35 = 4; /*0x1067247db*/
      v36 = v48; /*0x1067247e0*/
      v37 = v49; /*0x1067247e4*/
      break; /*0x1067247e8*/
  }
  v40 = v50; /*0x1067246e1*/
  v41 = *((_QWORD **)v9 + 238); /*0x1067246e5*/
  v43 = *(_OWORD *)a3; /*0x1067246f8*/
  *(_OWORD *)a3 = 0; /*0x106724700*/
  if ( (v37 & (unsigned __int8)DFFlag::ConnectionSendPushesTracerIdThrough) == 0 ) /*0x10672470e*/
    v36 = 0; /*0x10672470e*/
  v15 = RBX::Network::ConcurrentRakPeer::Send_deprecated( /*0x106724749*/
          a1: v41,
          a2: &v43,
          a3: v35,
          a4: v38,
          a5: v39,
          a6: 0,
          a7: *v40,
          a8: v40[1],
          a9: 0,
          a10: 1,
          a11: v36);
  v25 = *((volatile signed __int64 **)&v43 + 1); /*0x10672474c*/
LABEL_76:
  if ( v25 != nullptr && _InterlockedExchangeAdd64(v25 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106724768*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v25 + 16))(a1: v25); /*0x106724770*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v25); /*0x106724776*/
  }
  return v15; /*0x10672477e*/
}

// Address: 0x106724840 | Name: __ZNK3RBX7Network16RakNetConnection15getCapabilitiesEv
__int64 __fastcall RBX::Network::RakNetConnection::getCapabilities(
        RBX::Network::RakNetConnection *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  return (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(**((_QWORD **)this + 237) + 688LL))( /*0x106724872*/
           a1: *((_QWORD *)this + 237),
           a2,
           a3,
           a4: **((_QWORD **)this + 237),
           a5,
           a6,
           a7: *((_QWORD *)this + 239),
           a8: *((_QWORD *)this + 240),
           a9: *((_QWORD *)this + 241),
           a10: *((_QWORD *)this + 242));
}

// Address: 0x106724878 | Name: __ZNK3RBX7Network16RakNetConnection10getMtuSizeEv
__int64 __fastcall RBX::Network::RakNetConnection::getMtuSize(
        RBX::Network::RakNetConnection *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  int v6; // eax
  int v7; // edx
  __int64 v8; // rcx

  v6 = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(**((_QWORD **)this + 237) + 472LL))( /*0x1067248a4*/
         a1: *((_QWORD *)this + 237),
         a2,
         a3,
         a4: **((_QWORD **)this + 237),
         a5,
         a6,
         a7: *((_QWORD *)this + 239),
         a8: *((_QWORD *)this + 240),
         a9: *((_QWORD *)this + 241),
         a10: *((_QWORD *)this + 242));
  v7 = 200; /*0x1067248b2*/
  if ( DFInt::ISRMTUAdjust < 200 ) /*0x1067248b9*/
    v7 = DFInt::ISRMTUAdjust; /*0x1067248b9*/
  v8 = 0; /*0x1067248bc*/
  if ( v7 > 0 ) /*0x1067248c0*/
    v8 = (unsigned int)v7; /*0x1067248c0*/
  return v6 - v8; /*0x1067248c6*/
}

// Address: 0x1067248cc | Name: __ZN3RBX7Network16RakNetConnection26updateBandwidthEstimateBpsEv
__int64 __fastcall RBX::Network::RakNetConnection::updateBandwidthEstimateBps(
        RBX::Network::RakNetConnection *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  __int64 result; // rax

  result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(**((_QWORD **)this + 237) + 608LL))( /*0x1067248fb*/
             a1: *((_QWORD *)this + 237),
             a2: 0,
             a3,
             a4,
             a5,
             a6,
             a7: *((_QWORD *)this + 239),
             a8: *((_QWORD *)this + 240),
             a9: *((_QWORD *)this + 241),
             a10: *((_QWORD *)this + 242));
  if ( result != 0 ) /*0x106724904*/
  {
    result = *(_QWORD *)(result + 336); /*0x106724906*/
    *((_QWORD *)this + 175) = result; /*0x10672490d*/
  }
  return result; /*0x106724914*/
}

// Address: 0x106725386 | Name: __ZN3RBX7Network16RakNetConnection10disconnectEi
__int64 __fastcall RBX::Network::RakNetConnection::disconnect(RBX::Network::RakNetConnection *this)
{
  __int64 v2; // r14
  unsigned __int8 v3; // al
  _BYTE v5[72]; // [rsp+8h] [rbp-48h] BYREF

  v2 = *((_QWORD *)this + 237); /*0x106725396*/
  RakNet::AddressOrGUID::AddressOrGUID( /*0x1067253ab*/
    this: (RakNet::AddressOrGUID *)v5,
    a2: (RBX::Network::RakNetConnection *)((char *)this + 1912));
  v3 = (*(__int64 (__fastcall **)(RBX::Network::RakNetConnection *))(*(_QWORD *)this + 208LL))(a1: this); /*0x1067253b6*/
  return (*(__int64 (__fastcall **)(__int64, _BYTE *, __int64, _QWORD, _QWORD, __int64))(*(_QWORD *)v2 + 256LL))( /*0x1067253dd*/
           a1: v2,
           a2: v5,
           a3: 1,
           a4: v3,
           a5: 0,
           a6: 3);
}

// Address: 0x1067253e8 | Name: __ZN3RBX7Network16RakNetConnection17setProfilerPeerIdEj
__int64 __fastcall RBX::Network::RakNetConnection::setProfilerPeerId(
        RBX::Network::RakNetConnection *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  unsigned int v6; // ebx
  __int64 result; // rax

  v6 = a2; /*0x1067253f3*/
  result = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(**((_QWORD **)this + 237) + 272LL))( /*0x10672541b*/
             a1: *((_QWORD *)this + 237),
             a2,
             a3,
             a4,
             a5,
             a6,
             a7: *((_QWORD *)this + 239),
             a8: *((_QWORD *)this + 240),
             a9: *((_QWORD *)this + 241),
             a10: *((_QWORD *)this + 242));
  if ( (int)result >= 0 ) /*0x106725423*/
    return (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(**((_QWORD **)this + 237) + 224LL))( /*0x106725442*/
             a1: *((_QWORD *)this + 237),
             a2: (unsigned int)result,
             a3: v6);
  return result; /*0x10672543a*/
}

// Address: 0x10672544e | Name: __ZN3RBX7Network16RakNetConnection24setProfilerRemoteFrameIdEi
__int64 __fastcall RBX::Network::RakNetConnection::setProfilerRemoteFrameId(
        RBX::Network::RakNetConnection *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  unsigned int v6; // ebx
  __int64 result; // rax

  v6 = a2; /*0x106725459*/
  result = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(**((_QWORD **)this + 237) + 272LL))( /*0x106725481*/
             a1: *((_QWORD *)this + 237),
             a2,
             a3,
             a4,
             a5,
             a6,
             a7: *((_QWORD *)this + 239),
             a8: *((_QWORD *)this + 240),
             a9: *((_QWORD *)this + 241),
             a10: *((_QWORD *)this + 242));
  if ( (int)result >= 0 ) /*0x106725489*/
    return (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(**((_QWORD **)this + 237) + 232LL))( /*0x1067254a8*/
             a1: *((_QWORD *)this + 237),
             a2: (unsigned int)result,
             a3: v6);
  return result; /*0x1067254a0*/
}

// Address: 0x1067254b4 | Name: __ZN3RBX7Network16RakNetConnection23setProfilerLocalFrameIdEi
__int64 __fastcall RBX::Network::RakNetConnection::setProfilerLocalFrameId(RBX::Network::RakNetConnection *this)
{
  return (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 237) + 216LL))(a1: *((_QWORD *)this + 237));
}

// Address: 0x1067254cc | Name: __ZNK3RBX7Network16RakNetConnection18getConnectionStatsEv
RBX::Network::RakNetConnection *__fastcall RBX::Network::RakNetConnection::getConnectionStats(
        RBX::Network::RakNetConnection *this,
        __int64 a2)
{
  __int64 v4; // r12
  double v5; // xmm0_8
  _DWORD v7[12]; // [rsp+0h] [rbp-70h] BYREF
  __m64 v8[8]; // [rsp+30h] [rbp-40h] BYREF

  *((_BYTE *)this + 112) = 0; /*0x1067254e5*/
  *((_BYTE *)this + 120) = 0; /*0x1067254e8*/
  *((_BYTE *)this + 128) = 0; /*0x1067254eb*/
  *((_BYTE *)this + 136) = 0; /*0x1067254f1*/
  *((_BYTE *)this + 144) = 0; /*0x1067254f7*/
  *((_OWORD *)this + 2) = 0; /*0x106725500*/
  *((_OWORD *)this + 3) = 0; /*0x106725504*/
  *((_OWORD *)this + 4) = 0; /*0x106725508*/
  *((_OWORD *)this + 5) = 0; /*0x10672550c*/
  *(_OWORD *)((char *)this + 89) = 0; /*0x106725510*/
  *(_OWORD *)v8 = 0; /*0x106725518*/
  v4 = *(_QWORD *)(a2 + 1896); /*0x10672551c*/
  RakNet::AddressOrGUID::AddressOrGUID( /*0x106725531*/
    this: (RakNet::AddressOrGUID *)v7,
    a2: (const RakNet::SystemAddress *)(a2 + 1912));
  (*(void (__fastcall **)(__int64, _DWORD *, __m64 *))(*(_QWORD *)v4 + 336LL))(a1: v4, a2: v7, a3: v8); /*0x106725543*/
  *((__m128i *)this + 1) = _mm_cvtepu32_epi64(v8[0]); /*0x10672554f*/
  *(__m128i *)((char *)this + 40) = _mm_cvtepu32_epi64(v8[1]); /*0x10672555b*/
  v7[0] = 0; /*0x106725560*/
  (*(void (__fastcall **)(_QWORD, _DWORD *))(**(_QWORD **)(a2 + 1896) + 352LL))(a1: *(_QWORD *)(a2 + 1896), a2: v7); /*0x106725579*/
  v5 = (double)v7[0] * 0.001; /*0x10672558a*/
  *((_BYTE *)this + 8) = 1; /*0x10672559a*/
  *(double *)this = v5 + 0.0; /*0x10672559e*/
  return this; /*0x1067255a5*/
}

// Address: 0x1067255b4 | Name: __ZN3RBX7Network16RakNetConnectionD1Ev
void __fastcall RBX::Network::RakNetConnection::~RakNetConnection(RBX::Network::RakNetConnection *this)
{
  RBX::NetworkBase::ConnectionInternal::~ConnectionInternal(this); /*0x1067255b9*/
}

// Address: 0x1067255be | Name: __ZN3RBX7Network16RakNetConnectionD0Ev
void __fastcall RBX::Network::RakNetConnection::~RakNetConnection(RBX::Network::RakNetConnection *this)
{
  void *v2; // rsi

  RBX::NetworkBase::ConnectionInternal::~ConnectionInternal(this); /*0x1067255c7*/
  operator delete(a1: this, a2: v2); /*0x1067255d5*/
}

// Address: 0x1067255e4 | Name: __ZNK3RBX7Network16RakNetConnection17getConnectionTypeEv
__int64 __fastcall RBX::Network::RakNetConnection::getConnectionType(RBX::Network::RakNetConnection *this)
{
  return 0; /*0x1067255ea*/
}

// Address: 0x10672564c | Name: __ZNK3RBX7Network16RakNetConnection8isServerEv
char __fastcall RBX::Network::RakNetConnection::isServer(RBX::Network::RakNetConnection *this)
{
  return 1; /*0x106725652*/
}

// END RakNetConnection part 1/1, 17 functions
