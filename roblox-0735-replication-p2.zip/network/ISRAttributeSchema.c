// ISRAttributeSchema -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 12 functions


// Address: 0x10673aeae | Name: __ZN3RBX7Network19InstanceReplication18ISRAttributeSchemaC2Ev
__int64 __fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::ISRAttributeSchema(
        RBX::Network::InstanceReplication::ISRAttributeSchema *this,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  char *v5; // r14
  RSL::Arena *v6; // rdi
  void *v7; // rsi
  __int64 result; // rax
  _BYTE v9[16]; // [rsp+8h] [rbp-48h] BYREF
  RSL::Arena *v10; // [rsp+18h] [rbp-38h]
  __int64 v11; // [rsp+20h] [rbp-30h]
  __int64 v12; // [rsp+28h] [rbp-28h]

  *(_DWORD *)this = 0x7FFFFFFF; /*0x10673aec0*/
  *((_BYTE *)this + 4) = 0; /*0x10673aec6*/
  *((_QWORD *)this + 1) = 0; /*0x10673aecd*/
  v5 = (char *)this + 16; /*0x10673aed1*/
  std::string::basic_string[abi:ne200100]<0>(a1: v9, a2: "", a3, a4); /*0x10673aee3*/
  v11 = 4294901761LL; /*0x10673aeed*/
  v12 = 0; /*0x10673aef1*/
  std::vector<RBX::Network::InstanceReplication::ISRAttributeSchemaEntry>::vector[abi:ne200100](a1: v5, a2: 64, a3: v9); /*0x10673af00*/
  if ( (v9[0] & 1) != 0 ) /*0x10673af09*/
    operator delete(a1: v10, a2: v7); /*0x10673af0f*/
  result = RSL::Arena::getDefaultArena(this: v6); /*0x10673af14*/
  *((_QWORD *)this + 9) = result; /*0x10673af19*/
  *(_OWORD *)((char *)this + 40) = 0; /*0x10673af20*/
  *(_OWORD *)((char *)this + 56) = 0; /*0x10673af24*/
  *((_QWORD *)this + 1) = 0; /*0x10673af28*/
  return result; /*0x10673af30*/
}

// Address: 0x10673af58 | Name: __ZN3RBX7Network19InstanceReplication18ISRAttributeSchemaC1Ev
__int64 __fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::ISRAttributeSchema(
        RBX::Network::InstanceReplication::ISRAttributeSchema *this,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  return RBX::Network::InstanceReplication::ISRAttributeSchema::ISRAttributeSchema(this, a2, a3, a4); /*0x10673af5c*/
}

// Address: 0x10673af62 | Name: __ZN3RBX7Network19InstanceReplication18ISRAttributeSchema29removeAttributeSchemaListenerEt
RBX::Network::InstanceReplication::ISRAttributeSchema *__fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::removeAttributeSchemaListener(
        RBX::Network::InstanceReplication::ISRAttributeSchema *this,
        __int64 a2,
        unsigned int a3)
{
  unsigned __int64 v3; // rcx
  __int64 v6; // rax
  __int64 v7; // rdx
  __int64 v8; // rax
  __int64 v9; // rcx
  unsigned __int8 *v10; // rdi
  unsigned int v11; // eax
  __int64 v12; // rax

  v3 = a3; /*0x10673af69*/
  v6 = a3 >> 6; /*0x10673af73*/
  v7 = *(_QWORD *)(a2 + 8 * v6 + 8); /*0x10673af76*/
  if ( _bittest64(&v7, v3) ) /*0x10673af83*/
  {
    --*(_BYTE *)(a2 + 4); /*0x10673af89*/
    v7 &= ~(1LL << v3); /*0x10673af90*/
    *(_QWORD *)(a2 + 8 * v6 + 8) = v7; /*0x10673af93*/
  }
  v8 = (unsigned __int16)v3; /*0x10673af98*/
  v9 = *(_QWORD *)(a2 + 16); /*0x10673af9b*/
  v10 = (unsigned __int8 *)(v9 + 40 * v8); /*0x10673afa3*/
  *((_DWORD *)v10 + 6) = -65535; /*0x10673afa7*/
  *((_QWORD *)v10 + 4) = 0; /*0x10673afae*/
  v11 = *v10; /*0x10673afb6*/
  if ( (v11 & 1) != 0 ) /*0x10673afbb*/
    v12 = *((_QWORD *)v10 + 1); /*0x10673afc1*/
  else
    v12 = v11 >> 1; /*0x10673afbd*/
  if ( v12 != 0 ) /*0x10673afc8*/
  {
    *((_QWORD *)this + 2) = *((_QWORD *)v10 + 2); /*0x10673afce*/
    *(_OWORD *)this = *(_OWORD *)v10; /*0x10673afd5*/
    *(_OWORD *)v10 = 0; /*0x10673afdb*/
    *((_QWORD *)v10 + 2) = 0; /*0x10673afde*/
    std::string::assign(a1: v10, a2: ""); /*0x10673afed*/
    RBX::details::SplitHashTable<std::string,std::pair<std::string,unsigned short>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,unsigned short>>::erase<std::string,10,void>( /*0x10673affc*/
      a1: a2 + 40,
      a2: this);
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: this, a2: "", a3: v7, a4: v9); /*0x10673b00d*/
  }
  return this; /*0x10673b015*/
}

// Address: 0x10673b034 | Name: __ZN3RBX7Network19InstanceReplication18ISRAttributeSchema18releaseAttributeIdEt
__int64 __fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::releaseAttributeId(
        RBX::Network::InstanceReplication::ISRAttributeSchema *this,
        unsigned int a2)
{
  unsigned __int64 v2; // rcx
  __int64 result; // rax
  __int64 v4; // rdx
  __int64 v5; // rsi

  v2 = a2; /*0x10673b038*/
  result = a2 >> 6; /*0x10673b03c*/
  v4 = *((_QWORD *)this + result + 1); /*0x10673b03f*/
  v5 = 1LL << a2; /*0x10673b049*/
  if ( _bittest64(&v4, v2) ) /*0x10673b04c*/
  {
    --*((_BYTE *)this + 4); /*0x10673b052*/
    *((_QWORD *)this + result + 1) = ~v5 & v4; /*0x10673b05b*/
  }
  return result; /*0x10673b060*/
}

// Address: 0x10673b062 | Name: __ZN3RBX7Network19InstanceReplication18ISRAttributeSchema34removeAttributeSchemaAuthoritativeERKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEE
__int64 __fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::removeAttributeSchemaAuthoritative(
        __int64 a1)
{
  __int64 v2; // r15
  __int64 result; // rax
  unsigned int v4; // edx
  unsigned __int64 v5; // r14
  __int64 v6; // rax
  __int64 v7; // rdx
  __int64 v8; // rcx

  v2 = a1 + 40; /*0x10673b06f*/
  result = RBX::details::SplitHashTable<std::string,std::pair<std::string,unsigned short>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,unsigned short>>::find_as<std::string>(a1: a1 + 40); /*0x10673b076*/
  if ( v4 != 0 || result != 0 ) /*0x10673b07e*/
  {
    v5 = *(unsigned __int16 *)(*(_QWORD *)(result + 16) + 32LL * v4 + 24); /*0x10673b096*/
    RBX::details::SplitHashTable<std::string,std::pair<std::string,unsigned short>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,unsigned short>>::erase<10,void>( /*0x10673b0a2*/
      a1: v2,
      a2: result);
    v6 = (unsigned int)v5 >> 6; /*0x10673b0aa*/
    v7 = *(_QWORD *)(a1 + 8 * v6 + 8); /*0x10673b0ad*/
    if ( _bittest64(&v7, v5) ) /*0x10673b0bd*/
    {
      --*(_BYTE *)(a1 + 4); /*0x10673b0c3*/
      *(_QWORD *)(a1 + 8 * v6 + 8) = ~(1LL << v5) & v7; /*0x10673b0cc*/
    }
    result = *(_QWORD *)(a1 + 16); /*0x10673b0d1*/
    v8 = 5 * v5; /*0x10673b0d5*/
    *(_DWORD *)(result + 8 * v8 + 24) = -65535; /*0x10673b0d9*/
    *(_QWORD *)(result + 8 * v8 + 32) = 0; /*0x10673b0e1*/
  }
  return result; /*0x10673b0ee*/
}

// Address: 0x10673b0f6 | Name: __ZN3RBX7Network19InstanceReplication18ISRAttributeSchema29updateAttributeSchemaListenerEtONS1_23ISRAttributeSchemaEntryE
__int64 __fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::updateAttributeSchemaListener(
        __int64 a1,
        __int64 a2,
        unsigned __int16 a3,
        unsigned __int8 *a4)
{
  unsigned int v8; // eax
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rdx
  __int64 v12; // rsi
  __int64 v13; // rcx
  __int64 v14; // r12
  __int64 v15; // r13
  void *v16; // rsi
  size_t v17; // rdx
  __int64 v18; // rcx
  unsigned int v19; // r8d
  __int64 v20; // rsi
  char *v21; // rdi
  __int64 v22; // rsi
  const void *v23; // rsi
  void *v24; // rsi
  __int128 __s1; // [rsp+0h] [rbp-40h] BYREF
  void *v27; // [rsp+10h] [rbp-30h]

  v8 = *a4; /*0x10673b113*/
  if ( (v8 & 1) != 0 ) /*0x10673b118*/
    v9 = *((_QWORD *)a4 + 1); /*0x10673b11a*/
  else
    v9 = v8 >> 1; /*0x10673b120*/
  if ( v9 != 0 ) /*0x10673b125*/
    *(_WORD *)RBX::SmallSplitHashMap<std::string,unsigned short,0u,(RBX::SplitHashPolicy)10,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>>::operator[]( /*0x10673b133*/
                a1: a2 + 40,
                a2: (__int64)a4) = a3;
  v10 = a3; /*0x10673b137*/
  v11 = a3 >> 6; /*0x10673b13d*/
  v12 = *(_QWORD *)(a2 + 8 * v11 + 8); /*0x10673b140*/
  if ( !_bittest64(&v12, a3) ) /*0x10673b154*/
  {
    ++*(_BYTE *)(a2 + 4); /*0x10673b156*/
    *(_QWORD *)(a2 + 8 * v11 + 8) = (1LL << a3) | v12; /*0x10673b15d*/
  }
  v13 = *(_QWORD *)(a2 + 16); /*0x10673b162*/
  v14 = 5LL * a3; /*0x10673b166*/
  v15 = v13 + 40 * v10; /*0x10673b16a*/
  if ( (*(_BYTE *)v15 & 1) != 0 ) /*0x10673b173*/
  {
    std::string::__init_copy_ctor_external(a1: &__s1, a2: *(_QWORD *)(v15 + 16), a3: *(_QWORD *)(v15 + 8)); /*0x10673b194*/
    v15 = *(_QWORD *)(a2 + 16) + 8 * v14; /*0x10673b19d*/
    if ( (*(_BYTE *)v15 & 1) != 0 ) /*0x10673b1a6*/
      operator delete(a1: *(RBX::Memory **)(v15 + 16), a2: v16); /*0x10673b1ac*/
  }
  else
  {
    v27 = *(void **)(v15 + 16); /*0x10673b179*/
    __s1 = *(_OWORD *)v15; /*0x10673b182*/
  }
  *(_QWORD *)(v15 + 16) = *((_QWORD *)a4 + 2); /*0x10673b1b5*/
  *(_OWORD *)v15 = *(_OWORD *)a4; /*0x10673b1bd*/
  *(_WORD *)a4 = 0; /*0x10673b1c2*/
  *(_OWORD *)(v15 + 24) = *(_OWORD *)(a4 + 24); /*0x10673b1cd*/
  if ( (__s1 & 1) != 0 ) /*0x10673b1d8*/
    v17 = *((_QWORD *)&__s1 + 1); /*0x10673b1da*/
  else
    v17 = (unsigned __int8)__s1 >> 1; /*0x10673b1e2*/
  if ( v17 == 0
    || ((v18 = *(_QWORD *)(a2 + 16), ((v19 = *(unsigned __int8 *)(v18 + 8 * v14)) & 1) == 0)
      ? (v20 = v19 >> 1)
      : (v20 = *(_QWORD *)(v18 + 8 * v14 + 8)),
        v17 == v20
     && ((__s1 & 1) == 0 ? (v21 = (char *)&__s1 + 1) : (v21 = (char *)v27),
         (v22 = v18 + 8 * v14, (v19 & 1) == 0) ? (v23 = (const void *)(v22 + 1)) : (v23 = *(const void **)(v22 + 16)),
         memcmp(__s1: v21, __s2: v23, __n: v17) == 0)) )
  {
    std::string::basic_string[abi:ne200100]<0>(a1, a2: "", a3: v17, a4: v13); /*0x10673b25e*/
    if ( (__s1 & 1) != 0 ) /*0x10673b267*/
      operator delete(a1: (RBX::Memory *)v27, a2: v24); /*0x10673b26d*/
  }
  else
  {
    RBX::details::SplitHashTable<std::string,std::pair<std::string,unsigned short>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,unsigned short>>::erase<std::string,10,void>( /*0x10673b23e*/
      a1: a2 + 40,
      a2: &__s1);
    *(_QWORD *)(a1 + 16) = v27; /*0x10673b247*/
    *(_OWORD *)a1 = __s1; /*0x10673b24f*/
  }
  return a1; /*0x10673b275*/
}

// Address: 0x10673b2e2 | Name: __ZN3RBX7Network19InstanceReplication18ISRAttributeSchema16claimAttributeIdEt
__int64 __fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::claimAttributeId(
        RBX::Network::InstanceReplication::ISRAttributeSchema *this,
        unsigned int a2)
{
  unsigned __int64 v2; // rcx
  __int64 result; // rax
  __int64 v4; // rdx
  __int64 v5; // rsi

  v2 = a2; /*0x10673b2e6*/
  result = a2 >> 6; /*0x10673b2ea*/
  v4 = *((_QWORD *)this + result + 1); /*0x10673b2ed*/
  v5 = 1LL << a2; /*0x10673b2f7*/
  if ( !_bittest64(&v4, v2) ) /*0x10673b2fe*/
  {
    ++*((_BYTE *)this + 4); /*0x10673b300*/
    *((_QWORD *)this + result + 1) = v5 | v4; /*0x10673b306*/
  }
  return result; /*0x10673b30b*/
}

// Address: 0x10673b30e | Name: __ZN3RBX7Network19InstanceReplication18ISRAttributeSchema34updateAttributeSchemaAuthoritativeERtONS1_23ISRAttributeSchemaEntryE
__int64 __fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::updateAttributeSchemaAuthoritative(
        __int64 a1,
        unsigned __int16 *a2,
        __int64 a3)
{
  unsigned __int16 v5; // ax
  __int64 v7; // rax
  __int64 v8; // r12
  unsigned __int64 v9; // rcx
  __int64 v10; // rax
  __int64 v11; // rdx
  __int64 v12; // rsi
  __int64 v13; // r14
  __int64 result; // rax

  v5 = *a2; /*0x10673b31f*/
  if ( *a2 == 0xFFFF ) /*0x10673b326*/
  {
    v7 = *(_QWORD *)(a1 + 8); /*0x10673b32b*/
    if ( v7 == -1 ) /*0x10673b333*/
      LOWORD(v8) = -1; /*0x10673b345*/
    else
      _BitScanReverse64((unsigned __int64 *)&v8, (v7 + 1) & ~v7); /*0x10673b33f*/
    *a2 = v8; /*0x10673b34a*/
    *(_WORD *)RBX::SmallSplitHashMap<std::string,unsigned short,0u,(RBX::SplitHashPolicy)10,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>>::operator[]( /*0x10673b35a*/
                a1: a1 + 40,
                a2: a3) = v8;
    v5 = *a2; /*0x10673b35e*/
  }
  v9 = v5; /*0x10673b362*/
  v10 = v5 >> 6; /*0x10673b367*/
  v11 = *(_QWORD *)(a1 + 8 * v10 + 8); /*0x10673b36a*/
  v12 = 1LL << v9; /*0x10673b374*/
  if ( !_bittest64(&v11, v9) ) /*0x10673b37b*/
  {
    ++*(_BYTE *)(a1 + 4); /*0x10673b37d*/
    v12 |= v11; /*0x10673b381*/
    *(_QWORD *)(a1 + 8 * v10 + 8) = v12; /*0x10673b384*/
  }
  v13 = *(_QWORD *)(a1 + 16) + 40 * v9; /*0x10673b391*/
  if ( (*(_BYTE *)v13 & 1) != 0 ) /*0x10673b399*/
    operator delete(a1: *(RBX::Memory **)(v13 + 16), a2: (void *)v12); /*0x10673b39f*/
  result = *(_QWORD *)(a3 + 16); /*0x10673b3a4*/
  *(_QWORD *)(v13 + 16) = result; /*0x10673b3a8*/
  *(_OWORD *)v13 = *(_OWORD *)a3; /*0x10673b3af*/
  *(_WORD *)a3 = 0; /*0x10673b3b3*/
  *(_OWORD *)(v13 + 24) = *(_OWORD *)(a3 + 24); /*0x10673b3bc*/
  return result; /*0x10673b3c1*/
}

// Address: 0x10673b3ca | Name: __ZN3RBX7Network19InstanceReplication18ISRAttributeSchema23getAttributeSchemaEntryEt
RBX::Network::InstanceReplication::ISRAttributeSchema *__fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::getAttributeSchemaEntry(
        RBX::Network::InstanceReplication::ISRAttributeSchema *this,
        __int64 a2,
        unsigned int a3)
{
  __int64 v4; // r14

  v4 = *(_QWORD *)(a2 + 16) + 40LL * a3; /*0x10673b3de*/
  if ( (*(_BYTE *)v4 & 1) != 0 ) /*0x10673b3e6*/
  {
    std::string::__init_copy_ctor_external(a1: this, a2: *(_QWORD *)(v4 + 16), a3: *(_QWORD *)(v4 + 8)); /*0x10673b404*/
  }
  else
  {
    *((_QWORD *)this + 2) = *(_QWORD *)(v4 + 16); /*0x10673b3ec*/
    *(_OWORD *)this = *(_OWORD *)v4; /*0x10673b3f4*/
  }
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)(v4 + 24); /*0x10673b40e*/
  return this; /*0x10673b415*/
}

// Address: 0x10673b41a | Name: __ZNK3RBX7Network19InstanceReplication18ISRAttributeSchema14getAttributeIdERKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEE
__int64 __fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::getAttributeId(__int64 a1)
{
  __int64 v1; // rax
  unsigned int v2; // edx
  unsigned __int16 v3; // cx

  v1 = RBX::details::SplitHashTable<std::string,std::pair<std::string,unsigned short>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,unsigned short>>::find_as<std::string>(a1: a1 + 40); /*0x10673b422*/
  v3 = -1; /*0x10673b434*/
  if ( v2 != 0 || v1 != 0 ) /*0x10673b42a*/
    return *(unsigned __int16 *)(*(_QWORD *)(v1 + 16) + 32LL * v2 + 24); /*0x10673b447*/
  return v3; /*0x10673b44f*/
}

// Address: 0x10673b452 | Name: __ZNK3RBX7Network19InstanceReplication18ISRAttributeSchema4sizeEv
__int64 __fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::size(
        RBX::Network::InstanceReplication::ISRAttributeSchema *this)
{
  return *((unsigned __int8 *)this + 4); /*0x10673b45a*/
}

// Address: 0x106743ae8 | Name: __ZN3RBX7Network19InstanceReplication18ISRAttributeSchemaD1Ev
void __fastcall RBX::Network::InstanceReplication::ISRAttributeSchema::~ISRAttributeSchema(
        RBX::Network::InstanceReplication::ISRAttributeSchema *this)
{
  char *v2; // [rsp+0h] [rbp-10h] BYREF

  RBX::details::SplitHashTable<std::string,std::pair<std::string,unsigned short>,(RBX::SplitHashPolicy)10,0u,RBX::details::DefaultHash<std::string>,RBX::details::DefaultEqualTo<std::string>,RBX::details::GetMapKey<std::string,unsigned short>>::freeInternalMemoryAndLeaveUninitialized(a1: (char *)this + 40); /*0x106743af5*/
  v2 = (char *)this + 16; /*0x106743b02*/
  std::vector<RBX::Network::InstanceReplication::ISRAttributeSchemaEntry>::__destroy_vector::operator()[abi:ne200100](a1: &v2); /*0x106743b05*/
}

// END ISRAttributeSchema part 1/1, 12 functions
