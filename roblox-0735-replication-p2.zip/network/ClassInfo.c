// ClassInfo -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 1 functions


// Address: 0x1067a2636 | Name: __ZN3RBX7Network18NetworkSchemaTypes9ClassInfoC2ERKS2_
__int64 __fastcall RBX::Network::NetworkSchemaTypes::ClassInfo::ClassInfo(__int64 a1, __int64 a2)
{
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x1067a264d*/
  *(_OWORD *)(a1 + 16) = 0; /*0x1067a2657*/
  *(_QWORD *)(a1 + 32) = 0; /*0x1067a265e*/
  std::vector<std::pair<RBX::Reflection::PropertyDescriptor const*,unsigned short>>::__init_with_size[abi:ne200100]<std::pair<RBX::Reflection::PropertyDescriptor const*,unsigned short>*,std::pair<RBX::Reflection::PropertyDescriptor const*,unsigned short>*>( /*0x1067a2679*/
    a1: a1 + 16,
    a2: *(_QWORD *)(a2 + 16),
    a3: *(_QWORD *)(a2 + 24),
    a4: (__int64)(*(_QWORD *)(a2 + 24) - *(_QWORD *)(a2 + 16)) >> 4);
  *(_OWORD *)(a1 + 40) = *(_OWORD *)(a2 + 40); /*0x1067a2684*/
  *(_OWORD *)(a1 + 64) = 0; /*0x1067a268f*/
  *(_QWORD *)(a1 + 80) = 0; /*0x1067a2693*/
  std::vector<std::pair<RBX::Reflection::EventDescriptor const*,unsigned short>>::__init_with_size[abi:ne200100]<std::pair<RBX::Reflection::EventDescriptor const*,unsigned short>*,std::pair<RBX::Reflection::EventDescriptor const*,unsigned short>*>( /*0x1067a26ae*/
    a1: a1 + 64,
    a2: *(_QWORD *)(a2 + 64),
    a3: *(_QWORD *)(a2 + 72),
    a4: (__int64)(*(_QWORD *)(a2 + 72) - *(_QWORD *)(a2 + 64)) >> 4);
  *(_OWORD *)(a1 + 88) = *(_OWORD *)(a2 + 88); /*0x1067a26b9*/
  *(_OWORD *)(a1 + 112) = 0; /*0x1067a26c9*/
  *(_DWORD *)(a1 + 128) = 0; /*0x1067a26cd*/
  RBX::DenseMap<RBX::Network::NetworkSchemaTypes::ClassProperty const*,unsigned short,RBX::DenseMapInfo<RBX::Network::NetworkSchemaTypes::ClassProperty const*,void>,RBX::detail::DenseMapPair<RBX::Network::NetworkSchemaTypes::ClassProperty const*,unsigned short>>::copyFrom( /*0x1067a26da*/
    a1: a1 + 112,
    a2: (const void **)(a2 + 112));
  *(_OWORD *)(a1 + 136) = 0; /*0x1067a26e9*/
  *(_QWORD *)(a1 + 152) = 0; /*0x1067a26f0*/
  std::vector<RBX::Network::NetworkSchemaTypes::ClassProperty const*>::__init_with_size[abi:ne200100]<RBX::Network::NetworkSchemaTypes::ClassProperty const**,RBX::Network::NetworkSchemaTypes::ClassProperty const**>( /*0x1067a2718*/
    a1: a1 + 136,
    a2: *(_QWORD *)(a2 + 136),
    a3: *(_QWORD *)(a2 + 144),
    a4: (__int64)(*(_QWORD *)(a2 + 144) - *(_QWORD *)(a2 + 136)) >> 3);
  *(_OWORD *)(a1 + 160) = 0; /*0x1067a2727*/
  *(_QWORD *)(a1 + 176) = 0; /*0x1067a272e*/
  return std::vector<RBX::Reflection::PropertyDescriptor const*>::__init_with_size[abi:ne200100]<RBX::Reflection::PropertyDescriptor const**,RBX::Reflection::PropertyDescriptor const**>( /*0x1067a275c*/
           a1: a1 + 160,
           a2: *(_QWORD *)(a2 + 160),
           a3: *(_QWORD *)(a2 + 168),
           a4: (__int64)(*(_QWORD *)(a2 + 168) - *(_QWORD *)(a2 + 160)) >> 3);
}

// END ClassInfo part 1/1, 1 functions
