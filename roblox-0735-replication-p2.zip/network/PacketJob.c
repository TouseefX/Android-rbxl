// PacketJob -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 4 functions


// Address: 0x106721e28 | Name: __ZN3RBX7Network17ConcurrentRakPeer9PacketJobC2ENSt3__110shared_ptrIN6RakNet16RakPeerInterfaceEEEPNS_9DataModelE
__int64 __fastcall RBX::Network::ConcurrentRakPeer::PacketJob::PacketJob(
        RBX::DataModelJob *this,
        __int64 a2,
        __int64 a3)
{
  std::__shared_weak_count *v5; // r15
  __int64 v6; // rax
  __int64 v8; // [rsp+8h] [rbp-28h] BYREF
  std::__shared_weak_count *v9; // [rsp+10h] [rbp-20h]

  RBX::shared_from<RBX::DataModel>(a1: &v8, a2: a3); /*0x106721e45*/
  RBX::DataModelJob::DataModelJob(a1: this, a2: "Net Peer Send", a3: 9, a4: 0, a5: &v8, a6: 14); /*0x106721e64*/
  v5 = v9; /*0x106721e69*/
  if ( v9 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v9 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106721e82*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x106721e8a*/
    std::__shared_weak_count::__release_weak(this: v5); /*0x106721e90*/
  }
  *(_QWORD *)this = &off_10CAA8D18; /*0x106721e9c*/
  RBX::UnboundedCircularBuffer<rbx::implementation::timestamped_safe_queue_item<RBX::Network::ConcurrentRakPeer::PacketJob::SendData>>::UnboundedCircularBuffer( /*0x106721eae*/
    a1: (char *)this + 408,
    a2: 8);
  *((_BYTE *)this + 440) = 0; /*0x106721eb3*/
  v6 = *(_QWORD *)(a2 + 8); /*0x106721eba*/
  *(_OWORD *)((char *)this + 456) = *(_OWORD *)a2; /*0x106721ec2*/
  if ( v6 != 0 ) /*0x106721ecc*/
    _InterlockedIncrement64((volatile signed __int64 *)(v6 + 16)); /*0x106721ece*/
  return RBX::DataModelJob::sendProfileDataToTelemetry(this); /*0x106721edb*/
}

// Address: 0x106721f20 | Name: __ZN3RBX7Network17ConcurrentRakPeer9PacketJobD1Ev
void __fastcall RBX::Network::ConcurrentRakPeer::PacketJob::~PacketJob(
        RBX::Network::ConcurrentRakPeer::PacketJob *this)
{
  std::__shared_weak_count *v2; // rdi

  *(_QWORD *)this = &off_10CAA8D18; /*0x106721f30*/
  v2 = *((std::__shared_weak_count **)this + 58); /*0x106721f33*/
  if ( v2 != nullptr ) /*0x106721f3d*/
    std::__shared_weak_count::__release_weak(this: v2); /*0x106721f3f*/
  RBX::UnboundedCircularBuffer<rbx::implementation::timestamped_safe_queue_item<RBX::Network::ConcurrentRakPeer::PacketJob::SendData>>::~UnboundedCircularBuffer(a1: (char *)this + 408); /*0x106721f4b*/
  RBX::TaskScheduler::Job::~Job(this); /*0x106721f59*/
}

// Address: 0x106721f5e | Name: __ZN3RBX7Network17ConcurrentRakPeer9PacketJobD0Ev
void __fastcall RBX::Network::ConcurrentRakPeer::PacketJob::~PacketJob(
        RBX::Network::ConcurrentRakPeer::PacketJob *this)
{
  std::__shared_weak_count *v2; // rdi
  void *v3; // rsi

  *(_QWORD *)this = &off_10CAA8D18; /*0x106721f6e*/
  v2 = *((std::__shared_weak_count **)this + 58); /*0x106721f71*/
  if ( v2 != nullptr ) /*0x106721f7b*/
    std::__shared_weak_count::__release_weak(this: v2); /*0x106721f7d*/
  RBX::UnboundedCircularBuffer<rbx::implementation::timestamped_safe_queue_item<RBX::Network::ConcurrentRakPeer::PacketJob::SendData>>::~UnboundedCircularBuffer(a1: (char *)this + 408); /*0x106721f89*/
  RBX::TaskScheduler::Job::~Job(this); /*0x106721f91*/
  operator delete(a1: this, a2: v3); /*0x106721f9f*/
}

// Address: 0x106721fa4 | Name: __ZN3RBX7Network17ConcurrentRakPeer9PacketJob16stepDataModelJobERKNS_13TaskScheduler3Job5StatsE
__int64 __fastcall RBX::Network::ConcurrentRakPeer::PacketJob::stepDataModelJob(__int64 a1)
{
  int v2; // eax
  int v3; // edx
  char v4; // si
  bool v5; // zf
  std::__shared_weak_count *v6; // rdi
  volatile signed __int64 *v7; // rax
  volatile signed __int64 *v8; // r14
  __int64 v9; // rax
  __int64 v10; // rbx
  __int64 v11; // r15
  unsigned int v12; // r14d
  unsigned int v13; // r13d
  char v14; // r12
  std::__shared_weak_count *v15; // r14
  __int64 result; // rax
  std::__shared_weak_count *v17; // rbx
  _BYTE v18[48]; // [rsp+20h] [rbp-E0h] BYREF
  std::__shared_weak_count *v19[2]; // [rsp+50h] [rbp-B0h] BYREF
  unsigned int v20; // [rsp+60h] [rbp-A0h]
  unsigned int v21; // [rsp+64h] [rbp-9Ch]
  char v22; // [rsp+68h] [rbp-98h]
  _BYTE v23[36]; // [rsp+6Ch] [rbp-94h] BYREF
  __int64 v24; // [rsp+90h] [rbp-70h]
  unsigned __int8 v25; // [rsp+98h] [rbp-68h]
  __int64 v26; // [rsp+A8h] [rbp-58h]
  std::__shared_weak_count *v27[2]; // [rsp+B0h] [rbp-50h] BYREF
  __int64 v28; // [rsp+C0h] [rbp-40h]
  volatile signed __int64 *v29; // [rsp+C8h] [rbp-38h]
  int v30; // [rsp+D4h] [rbp-2Ch]

  v2 = 1; /*0x106721fc7*/
  if ( DFInt::SpinMutexAttemptsBeforeYield >= 2 ) /*0x106721fcc*/
    v2 = DFInt::SpinMutexAttemptsBeforeYield; /*0x106721fcc*/
  v3 = 0; /*0x106721fd1*/
  while ( 1 ) /*0x106721fd6*/
  {
    v4 = *(_BYTE *)(a1 + 440); /*0x106721fd6*/
    *(_BYTE *)(a1 + 440) = 1; /*0x106721fd6*/
    if ( (v4 & 1) == 0 ) /*0x106721fe1*/
      break; /*0x106721fe1*/
    if ( ++v3 == v2 ) /*0x106721fe7*/
      v3 = 0; /*0x106721fe7*/
  }
  v5 = *(_QWORD *)(a1 + 432) == 0; /*0x106721fec*/
  *(_BYTE *)(a1 + 440) = 0; /*0x106721ff4*/
  if ( v5 ) /*0x106721ffb*/
    return 1; /*0x106722132*/
  v6 = *(std::__shared_weak_count **)(a1 + 464); /*0x106722001*/
  if ( v6 != nullptr /*0x10672201d*/
    && (v7 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v6), v29 = v7, v7 != nullptr) )
  {
    v8 = v7; /*0x106722023*/
    v9 = *(_QWORD *)(a1 + 456); /*0x106722026*/
    v28 = v9; /*0x10672202d*/
    v5 = v9 == 0; /*0x106722031*/
    LOBYTE(v9) = v9 != 0; /*0x106722034*/
    v30 = v9; /*0x106722037*/
    if ( v5 ) /*0x10672203a*/
      goto LABEL_26; /*0x10672203a*/
    *(_OWORD *)v19 = 0; /*0x10672204a*/
    RakNet::SystemAddress::SystemAddress(this: (RakNet::SystemAddress *)v23); /*0x10672204e*/
    v10 = a1 + 408; /*0x106722053*/
    v26 = v10; /*0x10672205a*/
    while ( (unsigned __int8)rbx::timestamped_safe_queue<RBX::Network::ConcurrentRakPeer::PacketJob::SendData>::pop_if_present( /*0x10672206f*/
                               a1: v10,
                               a2: v19) != 0 )
    {
      *(_OWORD *)v27 = *(_OWORD *)v19; /*0x106722083*/
      if ( v19[1] != nullptr ) /*0x10672208a*/
        _InterlockedIncrement64((volatile signed __int64 *)v19[1] + 1); /*0x10672208c*/
      v11 = v28; /*0x106722091*/
      v12 = v20; /*0x106722095*/
      v13 = v21; /*0x10672209c*/
      v14 = v22; /*0x1067220a3*/
      RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v18, a2: (const RakNet::SystemAddress *)v23); /*0x1067220bb*/
      (*(void (__fastcall **)(__int64, std::__shared_weak_count **, _QWORD, _QWORD, _QWORD, _BYTE *, _DWORD, _DWORD, __int64))(*(_QWORD *)v11 + 192LL))( /*0x1067220f6*/
        a1: v11,
        a2: v27,
        a3: v12,
        a4: v13,
        a5: (unsigned int)v14,
        a6: v18,
        a7: v25,
        a8: 0,
        a9: v24);
      v15 = v27[1]; /*0x1067220f9*/
      if ( v27[1] != nullptr /*0x106722112*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v27[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x10672211a*/
        std::__shared_weak_count::__release_weak(this: v15); /*0x106722120*/
      }
      v10 = v26; /*0x106722125*/
    }
    v17 = v19[1]; /*0x106722139*/
    if ( v19[1] != nullptr /*0x106722155*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v19[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x10672215d*/
      std::__shared_weak_count::__release_weak(this: v17); /*0x106722163*/
    }
    v8 = v29; /*0x106722168*/
    if ( v29 != nullptr ) /*0x10672216f*/
    {
LABEL_26:
      if ( _InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106722181*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v8 + 16))(a1: v8); /*0x106722189*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v8); /*0x10672218f*/
      }
      LOBYTE(result) = v30; /*0x106722194*/
    }
    else
    {
      LOBYTE(result) = 1; /*0x106722199*/
    }
  }
  else
  {
    LOBYTE(result) = 0; /*0x10672212e*/
  }
  return (unsigned __int8)result; /*0x10672219e*/
}

// END PacketJob part 1/1, 4 functions
