// InstanceReplication -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 7 functions


// Address: 0x106744351 | Name: __ZN3RBX7Network19InstanceReplication36getUseISRImprovedBitSetSerializationERKNS_11NetworkBase19InstanceReplication29ReplicatorSerializationParamsE
bool __fastcall RBX::Network::InstanceReplication::getUseISRImprovedBitSetSerialization(__int64 a1)
{
  return (*(_BYTE *)(a1 + 11) & 0x10) != 0; /*0x10674435d*/
}

// Address: 0x10674435f | Name: __ZN3RBX7Network19InstanceReplication31getUseCompressedPVSerializationERKNS_11NetworkBase19InstanceReplication29ReplicatorSerializationParamsE
bool __fastcall RBX::Network::InstanceReplication::getUseCompressedPVSerialization(__int64 a1)
{
  return (*(_BYTE *)(a1 + 14) & 0x20) != 0; /*0x10674436b*/
}

// Address: 0x106744487 | Name: __ZN3RBX7Network19InstanceReplication18serializeEmptyItemERNS0_13NetworkStreamE
__int64 __fastcall RBX::Network::InstanceReplication::serializeEmptyItem(
        RBX::Network::InstanceReplication *this,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3)
{
  return RBX::Network::serializeUnsignedVarint(this: nullptr, a2: (unsigned int)this, a3); /*0x106744490*/
}

// Address: 0x106744496 | Name: __ZN3RBX7Network19InstanceReplication11serializeIdERNS0_13NetworkStreamERKjRKNS_4GuidE
__int64 __fastcall RBX::Network::InstanceReplication::serializeId(
        RBX::Network::InstanceReplication *this,
        RBX::Network::NetworkStream *a2,
        RBX::Network::NetworkStream *a3,
        const RBX::Guid *a4)
{
  unsigned int v7[5]; // [rsp+Ch] [rbp-14h] BYREF

  if ( *(_DWORD *)a3 == -1 ) /*0x1067444a7*/
    return RBX::Network::serializeUnsignedVarint(this: nullptr, a2: (unsigned int)this, a3); /*0x1067444e3*/
  RBX::Network::CustomSerializers::serializeGuidScope(a1: (unsigned int)this, this: (RBX::Network *)*(unsigned int *)a2); /*0x1067444b1*/
  v7[0] = *((_DWORD *)a3 + 1); /*0x1067444be*/
  return RBX::Network::NetworkStream::writeBytes(this, a2: v7, a3: 4u); /*0x1067444cd*/
}

// Address: 0x1067444e8 | Name: __ZN3RBX7Network19InstanceReplication13deserializeIdERNS0_13NetworkStreamERKj
__int64 __fastcall RBX::Network::InstanceReplication::deserializeId(
        RBX::Network::InstanceReplication *this,
        RBX::Network::NetworkStream *a2,
        const unsigned int *a3)
{
  RBX::Network::CustomSerializers::deserializeGuidScope(a1: (unsigned int *)this); /*0x106744506*/
  return 0xFFFFFFFFLL; /*0x106744540*/
}

// Address: 0x1067506a4 | Name: __ZN3RBX7Network19InstanceReplicationL26getBasePartPhysicsDirtySetERKNS0_13NetworkSchemaERKNS_8BasePartE
RBX::Network::InstanceReplication *__fastcall RBX::Network::InstanceReplication::getBasePartPhysicsDirtySet(
        RBX::Network::InstanceReplication *this,
        const RBX::Network::NetworkSchema *a2,
        const RBX::Network::NetworkSchema **a3)
{
  char v3; // al
  const RBX::Network::NetworkSchema *v7; // r15
  const RBX::Reflection::PropertyDescriptor *v8; // rcx
  __int64 i; // r13
  unsigned __int16 v10; // ax
  __int64 v11; // rdx
  const char *v12; // rsi
  __int64 v13; // r8
  __int64 v14; // r9
  __m128 v15; // xmm0
  __m128 v16; // xmm1
  __m128 v17; // xmm2
  __m128 v18; // xmm3
  __m128 v19; // xmm4
  __m128 v20; // xmm5
  __m128 v21; // xmm6
  __m128 v22; // xmm7
  unsigned __int16 v23; // r12
  unsigned __int16 v24; // ax
  char v26; // [rsp-8h] [rbp-30h]

  v26 = v3; /*0x1067506b1*/
  if ( (_BYTE)`guard variable for'RBX::Network::InstanceReplication::getBasePartPhysicsDirtySet(RBX::Network::NetworkSchema const&,RBX::BasePart const&)::kPhysicsProps == 0 ) /*0x1067506c3*/
    RBX::Network::InstanceReplication::getBasePartPhysicsDirtySet(this, a2, (const RBX::BasePart *)a3); /*0x106750762*/
  v7 = a3[3]; /*0x1067506c9*/
  RBX::NetworkBase::PropertyDirtySet::PropertyDirtySet(this); /*0x1067506d0*/
  for ( i = 0; i != 2; ++i ) /*0x1067506d5*/
  {
    v10 = RBX::Network::InstanceReplication::InstanceStateReplicationBridge::toPropertyDirtySetId( /*0x1067506ea*/
            this: a2,
            a2: v7,
            a3: (const RBX::Reflection::ClassDescriptor *)RBX::Network::InstanceReplication::getBasePartPhysicsDirtySet(RBX::Network::NetworkSchema const&,RBX::BasePart const&)::kPhysicsProps[i],
            a4: v8);
    if ( v10 != 0xFFFF ) /*0x1067506f3*/
    {
      v23 = v10; /*0x1067506f5*/
      v24 = *((_WORD *)this + 16); /*0x1067506f8*/
      if ( v24 <= v23 ) /*0x106750700*/
      {
        RBX::NetworkBase::PropertyDirtySet::resize(this, a2: v23 + 1); /*0x10675070d*/
        v24 = *((_WORD *)this + 16); /*0x106750712*/
      }
      if ( v23 > 0xFFu || v24 <= v23 ) /*0x106750726*/
        RBX::throw_runtime_error( /*0x10675075d*/
          this: (RBX *)"PropertyDirtySet::set - Index out of bounds",
          a2: v12,
          a3: v11,
          a4: v23,
          a5: v13,
          a6: v14,
          a7: v15,
          a8: v16,
          a9: v17,
          a10: v18,
          a11: v19,
          a12: v20,
          a13: v21,
          a14: v22,
          a15: v26);
      v8 = (const RBX::Reflection::PropertyDescriptor *)((unsigned __int64)v23 >> 6); /*0x106750730*/
      *((_QWORD *)this + (_QWORD)v8) |= 1LL << v23; /*0x106750734*/
    }
  }
  return this; /*0x106750749*/
}

// Address: 0x10876305f | Name: __ZN3RBX7Network19InstanceReplicationL26getBasePartPhysicsDirtySetERKNS0_13NetworkSchemaERKNS_8BasePartE.cold.1
void __fastcall RBX::Network::InstanceReplication::getBasePartPhysicsDirtySet(
        RBX::Network::InstanceReplication *this,
        const RBX::Network::NetworkSchema *a2,
        const RBX::BasePart *a3)
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::InstanceReplication::getBasePartPhysicsDirtySet(RBX::Network::NetworkSchema const&,RBX::BasePart const&)::kPhysicsProps) != 0 ) /*0x108763071*/
  {
    RBX::Network::InstanceReplication::getBasePartPhysicsDirtySet(RBX::Network::NetworkSchema const&,RBX::BasePart const&)::kPhysicsProps[0] = (__int64)RBX::BasePartProperties::prop_ReplicationPV; /*0x10876307d*/
    qword_10D47CB28 = (__int64)RBX::BasePartProperties::prop_PhysicsRepRootPart; /*0x10876308e*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::InstanceReplication::getBasePartPhysicsDirtySet(RBX::Network::NetworkSchema const&,RBX::BasePart const&)::kPhysicsProps); /*0x10876309d*/
  }
}

// END InstanceReplication part 1/1, 7 functions
