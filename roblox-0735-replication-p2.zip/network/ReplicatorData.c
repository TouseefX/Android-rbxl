// ReplicatorData -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 4 functions


// Address: 0x106d85364 | Name: __ZN3RBX7Network14ReplicatorData7processERNS0_10ReplicatorE
__int64 __fastcall RBX::Network::ReplicatorData::process(
        RBX::Network::ReplicatorData *this,
        RBX::NetworkBase::ConnectionInternal **a2)
{
  __int64 v4; // r15
  __int64 v5; // r15
  __int64 v6; // r12
  unsigned __int8 TracerPeerId; // al
  __int64 v8; // r12
  __int64 v9; // rax
  unsigned __int8 v10; // r13
  RakNet *v11; // rdi
  unsigned int TimeMS; // eax
  RBX::NetworkBase::ConnectionInternal *v13; // r15
  __int64 v14; // rax

  if ( FFlag::EnableNetworkTracingA1 == 1 ) /*0x106d8537f*/
  {
    if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this) != 0 ) /*0x106d85393*/
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x106d85398*/
        v4 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x106d8539a*/
      else
        v4 = 0; /*0x106d853ab*/
      v6 = *((_QWORD *)this + 3); /*0x106d853ae*/
      TracerPeerId = RBX::NetworkBase::ConnectionInternal::getTracerPeerId(this: a2[35]); /*0x106d853b9*/
      RBX::Network::NetworkTracer::addCheckpointToTracer(a1: v4, a2: v6, a3: TracerPeerId, a4: 81); /*0x106d853cc*/
    }
    else
    {
      if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x106d853a3*/
        v5 = *(_QWORD *)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x106d853a5*/
      else
        v5 = 0; /*0x106d853d3*/
      v8 = *((_QWORD *)this + 3); /*0x106d853d6*/
      v9 = RBX::Network::ConcurrentRakPeer::rawPeer(this: a2[28]); /*0x106d853e1*/
      v10 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v9 + 200LL))(a1: v9); /*0x106d853f2*/
      TimeMS = RakNet::GetTimeMS(this: v11); /*0x106d853f5*/
      RBX::Network::NetworkTracer::addCheckpointToTracer_deprecated(a1: v5, a2: v8, a3: v10, a4: 81, a5: TimeMS); /*0x106d8540c*/
    }
  }
  if ( (unsigned int)(*((_DWORD *)this + 8) - 1) <= 1 ) /*0x106d85419*/
    RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(a1: this); /*0x106d8541b*/
  if ( DFFlag::AndroidSurfaceCompositor == 1 && *((_DWORD *)this + 8) == 4 ) /*0x106d85430*/
    RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(a1: this); /*0x106d85432*/
  if ( DFFlag::NewGfxParser == 1 && *((_DWORD *)this + 8) == 3 ) /*0x106d85444*/
  {
    v13 = a2[3]; /*0x106d85446*/
    v14 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(a1: this); /*0x106d8544a*/
    if ( *((unsigned __int16 *)v13 + 220) - (unsigned int)*(unsigned __int16 *)(v14 + 440) <= *(unsigned __int16 *)(v14 + 442) ) /*0x106d85469*/
      RBX::Network::ClientReplicator::handleRequestGeneric( /*0x106d85474*/
        this: (RBX::Network::ClientReplicator *)a2,
        a2: this,
        a3: *((_DWORD *)this + 8));
  }
  return 1; /*0x106d85482*/
}

// Address: 0x106d85494 | Name: __ZN3RBX7Network14ReplicatorData22readAndroidACChallengeEPNS0_16ClientReplicatorERNS0_13NetworkStreamE
RBX::Network::ReplicatorData *__fastcall RBX::Network::ReplicatorData::readAndroidACChallenge(
        RBX::Network::ReplicatorData *this,
        RBX::NetworkBase::ConnectionInternal **a2,
        RBX::Network::NetworkStream *a3)
{
  __int64 v5; // r12
  __int64 v6; // r15
  unsigned int UInt32; // eax
  char *v8; // rsi
  unsigned __int64 v9; // rdi
  RBX::Network::NetworkTracer *v12; // rdi
  __int64 TracerObject; // rax
  __int64 v14; // rdx
  RBX::Network *v15; // rdi
  __int64 v16; // r15
  unsigned __int8 TracerPeerId; // al
  __int64 v18; // rax
  unsigned __int8 v19; // r13
  RakNet *v20; // rdi
  unsigned int TimeMS; // eax

  if ( FFlag::EnableNetworkTracingA1 == 1 && FFlag::EnableNetworkTracingS == 0 ) /*0x106d854b8*/
  {
    if ( RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle != 0 ) /*0x106d85596*/
      v12 = *(RBX::Network::NetworkTracer **)(RBX::Subsystem<RBX::Network::NetworkTracer,true>::defaultHandle + 24); /*0x106d85598*/
    else
      v12 = nullptr; /*0x106d8559e*/
    TracerObject = RBX::Network::NetworkTracer::createTracerObject(this: v12); /*0x106d855a0*/
    v5 = 0; /*0x106d855a5*/
    if ( a2 != nullptr ) /*0x106d855ab*/
    {
      v16 = v14; /*0x106d855b1*/
      if ( v14 != 0 ) /*0x106d855b7*/
      {
        v5 = TracerObject; /*0x106d855bd*/
        if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v15) != 0 ) /*0x106d855c7*/
        {
          TracerPeerId = RBX::NetworkBase::ConnectionInternal::getTracerPeerId(this: a2[35]); /*0x106d855d0*/
          RBX::Network::NetworkTracerObject::addCheckpoint(a1: v16, a2: TracerPeerId, a3: 80); /*0x106d855e0*/
        }
        else
        {
          v18 = RBX::Network::ConcurrentRakPeer::rawPeer(this: a2[28]); /*0x106d855f1*/
          v19 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v18 + 200LL))(a1: v18); /*0x106d85602*/
          TimeMS = RakNet::GetTimeMS(this: v20); /*0x106d85605*/
          RBX::Network::NetworkTracerObject::addCheckpoint_deprecated(a1: v16, a2: v19, a3: 80, a4: TimeMS); /*0x106d85618*/
        }
      }
    }
  }
  else
  {
    v5 = 0; /*0x106d854be*/
  }
  v6 = operator new(a1: 0x40u); /*0x106d854cb*/
  *(_QWORD *)(v6 + 8) = &stru_100000020; /*0x106d854d8*/
  *(_DWORD *)(v6 + 16) = 0; /*0x106d854dc*/
  *(_QWORD *)(v6 + 24) = 0; /*0x106d854e4*/
  *(_QWORD *)v6 = off_10CAF3C58; /*0x106d854f3*/
  *(_OWORD *)(v6 + 32) = 0; /*0x106d854f9*/
  *(_OWORD *)(v6 + 48) = 0; /*0x106d854fe*/
  *(_DWORD *)(v6 + 32) = RBX::Network::NetworkStream::readUInt32(this: a3); /*0x106d8550f*/
  UInt32 = RBX::Network::NetworkStream::readUInt32(this: a3); /*0x106d85514*/
  *(_DWORD *)(v6 + 36) = UInt32; /*0x106d85519*/
  v8 = *(char **)(v6 + 40); /*0x106d8551f*/
  v9 = *(_QWORD *)(v6 + 48) - (_QWORD)v8; /*0x106d85527*/
  if ( UInt32 <= v9 ) /*0x106d85530*/
  {
    if ( UInt32 < v9 ) /*0x106d8554b*/
      *(_QWORD *)(v6 + 48) = &v8[UInt32]; /*0x106d85550*/
  }
  else
  {
    std::vector<unsigned char>::__append(a1: v6 + 40); /*0x106d8553c*/
    v8 = *(char **)(v6 + 40); /*0x106d85541*/
    UInt32 = *(_DWORD *)(v6 + 36); /*0x106d85545*/
  }
  RBX::Network::NetworkStream::readBytes(this: a3, a2: v8, a3: UInt32); /*0x106d85559*/
  if ( FFlag::EnableNetworkTracingA1 == 1 && FFlag::EnableNetworkTracingS == 0 ) /*0x106d8556e*/
    *(_QWORD *)(v6 + 24) = v5; /*0x106d85570*/
  *(_QWORD *)this = v6; /*0x106d85574*/
  return this; /*0x106d8557e*/
}

// Address: 0x106d85640 | Name: __ZN3RBX7Network14ReplicatorDataD1Ev
void __fastcall RBX::Network::ReplicatorData::~ReplicatorData(RBX::Network::ReplicatorData *this)
{
  void *v2; // rdi

  v2 = *((void **)this + 5); /*0x106d85647*/
  if ( v2 != nullptr ) /*0x106d8564e*/
  {
    *((_QWORD *)this + 6) = v2; /*0x106d85650*/
    operator delete(a1: v2); /*0x106d85655*/
  }
}

// Address: 0x106d8565c | Name: __ZN3RBX7Network14ReplicatorDataD0Ev
void __fastcall RBX::Network::ReplicatorData::~ReplicatorData(RBX::Network::ReplicatorData *this)
{
  void *v2; // rdi

  v2 = *((void **)this + 5); /*0x106d85665*/
  if ( v2 != nullptr ) /*0x106d8566c*/
  {
    *((_QWORD *)this + 6) = v2; /*0x106d8566e*/
    operator delete(a1: v2); /*0x106d85672*/
  }
  operator delete(a1: this); /*0x106d85680*/
}

// END ReplicatorData part 1/1, 4 functions
