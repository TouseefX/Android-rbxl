// NetworkSchema -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 18 functions


// Address: 0x10677daae | Name: __ZN3RBX7Network13NetworkSchemaC2Ev
void __fastcall RBX::Network::NetworkSchema::NetworkSchema(RBX::Network::NetworkSchema *this)
{
  void *v2; // rsi
  __int128 v3; // [rsp+30h] [rbp-40h] BYREF
  void *v4; // [rsp+40h] [rbp-30h]

  *(_WORD *)this = 0; /*0x10677dac2*/
  RBX::EngineNetConfiguration::EngineNetConfiguration(a1: (char *)this + 8, a2: 0); /*0x10677dad0*/
  *((_QWORD *)this + 35) = 0; /*0x10677db0d*/
  *(_OWORD *)((char *)this + 264) = 0; /*0x10677db17*/
  *((_OWORD *)this + 1) = 0; /*0x10677db25*/
  *((_OWORD *)this + 2) = 0; /*0x10677db29*/
  *((_QWORD *)this + 6) = 0; /*0x10677db2d*/
  *((_OWORD *)this + 4) = 0; /*0x10677db31*/
  *((_OWORD *)this + 5) = 0; /*0x10677db35*/
  *((_QWORD *)this + 12) = 0; /*0x10677db39*/
  *((_OWORD *)this + 7) = 0; /*0x10677db3d*/
  *((_OWORD *)this + 8) = 0; /*0x10677db41*/
  *((_QWORD *)this + 18) = 0; /*0x10677db48*/
  *((_OWORD *)this + 10) = 0; /*0x10677db4f*/
  *((_OWORD *)this + 11) = 0; /*0x10677db56*/
  *((_OWORD *)this + 12) = 0; /*0x10677db5d*/
  *((_OWORD *)this + 13) = 0; /*0x10677db64*/
  *((_OWORD *)this + 14) = 0; /*0x10677db6b*/
  *((_OWORD *)this + 15) = 0; /*0x10677db72*/
  v4 = nullptr; /*0x10677db7d*/
  v3 = 0; /*0x10677db81*/
  RBX::detail::DenseHashTable<std::string,std::pair<std::string,unsigned short>,std::pair<std::string const,unsigned short>,RBX::detail::ItemInterfaceMap<std::string,unsigned short>,RBX::Hash<std::string>,std::equal_to<std::string>>::DenseHashTable( /*0x10677db86*/
    a1: (char *)this + 288,
    a2: &v3,
    a3: 0);
  if ( (v3 & 1) != 0 ) /*0x10677db8f*/
    operator delete(a1: (RBX::Memory *)v4, a2: v2); /*0x10677db95*/
  *(_OWORD *)((char *)this + 458) = 0; /*0x10677db9d*/
  *((_OWORD *)this + 28) = 0; /*0x10677dba4*/
  *((_OWORD *)this + 27) = 0; /*0x10677dbab*/
  *((_OWORD *)this + 26) = 0; /*0x10677dbb2*/
  *((_OWORD *)this + 25) = 0; /*0x10677dbb9*/
  *((_OWORD *)this + 24) = 0; /*0x10677dbc0*/
  *((_OWORD *)this + 23) = 0; /*0x10677dbc7*/
  *((_OWORD *)this + 22) = 0; /*0x10677dbce*/
  *((_OWORD *)this + 31) = 0; /*0x10677dbd5*/
  *(_OWORD *)((char *)this + 506) = 0; /*0x10677dbdc*/
}

// Address: 0x10677e50a | Name: __ZN3RBX7Network13NetworkSchemaD2Ev
void __fastcall RBX::Network::NetworkSchema::~NetworkSchema(RBX::Memory **this, void *a2)
{
  __int64 v2; // rax
  RBX::Memory *v4; // rdi
  RBX::Memory *v5; // rdi
  RBX::Memory *v6; // rdi
  RBX::Memory *v7; // rdi
  void *v8; // rsi
  void *v9; // rsi
  RBX::Memory *v10; // rdi
  void *v11; // rsi
  RBX::Memory *v12; // rdi
  RBX::Memory *v13; // rdi
  RBX::Memory *v14; // rdi
  RBX::Memory *v15; // rdi
  _QWORD v16[4]; // [rsp+0h] [rbp-20h] BYREF

  v16[0] = v2; /*0x10677e513*/
  if ( (*(_BYTE *)(this + 62) & 1) != 0 ) /*0x10677e51e*/
    operator delete(a1: *(this + 64), a2); /*0x10677e527*/
  v4 = *(this + 56); /*0x10677e52c*/
  if ( v4 != nullptr ) /*0x10677e536*/
  {
    *(this + 57) = v4; /*0x10677e538*/
    operator delete(a1: v4, a2); /*0x10677e53f*/
  }
  v5 = *(this + 53); /*0x10677e544*/
  if ( v5 != nullptr ) /*0x10677e54e*/
  {
    *(this + 54) = v5; /*0x10677e550*/
    operator delete(a1: v5, a2); /*0x10677e557*/
  }
  v6 = *(this + 50); /*0x10677e55c*/
  if ( v6 != nullptr ) /*0x10677e566*/
  {
    *(this + 51) = v6; /*0x10677e568*/
    operator delete(a1: v6, a2); /*0x10677e56f*/
  }
  v7 = *(this + 47); /*0x10677e574*/
  if ( v7 != nullptr ) /*0x10677e57e*/
  {
    *(this + 48) = v7; /*0x10677e580*/
    operator delete(a1: v7, a2); /*0x10677e587*/
  }
  v16[0] = this + 44; /*0x10677e597*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: v16); /*0x10677e59a*/
  if ( (*(_BYTE *)(this + 40) & 1) != 0 ) /*0x10677e5ad*/
    operator delete(a1: *(this + 42), a2: v8); /*0x10677e5b6*/
  v16[0] = this + 36; /*0x10677e5bf*/
  std::vector<std::pair<std::string,unsigned short>>::__destroy_vector::operator()[abi:ne200100](a1: v16); /*0x10677e5c5*/
  v16[0] = this + 33; /*0x10677e5d1*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: v16); /*0x10677e5d7*/
  v16[0] = this + 29; /*0x10677e5e3*/
  std::vector<RBX::Network::NetworkSchemaTypes::ClassEvent>::__destroy_vector::operator()[abi:ne200100](a1: v16); /*0x10677e5ea*/
  v10 = *(this + 26); /*0x10677e5ef*/
  if ( v10 != nullptr ) /*0x10677e5f9*/
  {
    *(this + 27) = v10; /*0x10677e5fb*/
    operator delete(a1: v10, a2: v9); /*0x10677e602*/
  }
  v16[0] = this + 23; /*0x10677e612*/
  std::vector<RBX::Network::NetworkSchemaTypes::ClassInfo>::__destroy_vector::operator()[abi:ne200100](a1: v16); /*0x10677e615*/
  v12 = *(this + 20); /*0x10677e61a*/
  if ( v12 != nullptr ) /*0x10677e624*/
  {
    *(this + 21) = v12; /*0x10677e626*/
    operator delete(a1: v12, a2: v11); /*0x10677e62d*/
  }
  v13 = *(this + 14); /*0x10677e632*/
  if ( v13 != nullptr ) /*0x10677e639*/
  {
    *(this + 15) = v13; /*0x10677e63b*/
    operator delete(a1: v13, a2: v11); /*0x10677e63f*/
  }
  v14 = *(this + 8); /*0x10677e644*/
  if ( v14 != nullptr ) /*0x10677e64b*/
  {
    *(this + 9) = v14; /*0x10677e64d*/
    operator delete(a1: v14, a2: v11); /*0x10677e651*/
  }
  v15 = *(this + 2); /*0x10677e656*/
  if ( v15 != nullptr ) /*0x10677e65d*/
  {
    *(this + 3) = v15; /*0x10677e65f*/
    operator delete(a1: v15, a2: v11); /*0x10677e663*/
  }
}

// Address: 0x10679c098 | Name: __ZN3RBX7Network13NetworkSchema34defaultSchemaTypeForReflectionTypeERKNS_10Reflection4TypeERKNS_12DenseHashMapIPS4_NS0_18NetworkSchemaTypes4TypeENS_4HashIS7_EENSt3__18equal_toIS7_EEEE
unsigned __int64 __fastcall RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType(
        __int64 a1,
        __int64 a2,
        __int64 a3)
{
  __int64 v4; // rax
  __int64 v5; // r14
  unsigned int v6; // eax
  unsigned __int64 v7; // rsi
  __int64 v8; // rcx
  __int64 v9; // r14
  __int64 v10; // rdi
  bool v12; // zf
  _QWORD v13[3]; // [rsp+8h] [rbp-18h] BYREF

  v13[0] = a1; /*0x10679c0ad*/
  v4 = RBX::detail::DenseHashTable<RBX::Reflection::Type const*,std::pair<RBX::Reflection::Type const*,RBX::Network::NetworkSchemaTypes::Type>,std::pair<RBX::Reflection::Type const* const,RBX::Network::NetworkSchemaTypes::Type>,RBX::detail::ItemInterfaceMap<RBX::Reflection::Type const*,RBX::Network::NetworkSchemaTypes::Type>,RBX::Hash<RBX::Reflection::Type const*>,std::equal_to<RBX::Reflection::Type const*>>::find( /*0x10679c0b3*/
         a1: a2,
         a2: v13,
         a3);
  if ( v4 != 0 ) /*0x10679c0bb*/
  {
    v5 = *(_QWORD *)(v4 + 8); /*0x10679c0bd*/
    v6 = (unsigned int)v5 >> 8; /*0x10679c0c8*/
    v7 = v5 & 0xFFFFFFFF00000000LL; /*0x10679c0d5*/
    v8 = (unsigned __int8)v5; /*0x10679c0d8*/
    v9 = (unsigned int)v5 & 0xFFFF0000; /*0x10679c0dc*/
  }
  else
  {
    v9 = 4294901760LL; /*0x10679c0e5*/
    v10 = *(unsigned int *)(a1 + 48); /*0x10679c0eb*/
    if ( FFlag::ISRSchemaReduceRedundantCode == 1 ) /*0x10679c0f5*/
    {
      LOBYTE(v6) = RBX::Network::NetworkSchema::reflectionTypeToSchemaType(a1: v10); /*0x10679c0f7*/
LABEL_5:
      v8 = 0; /*0x10679c0fc*/
    }
    else
    {
      switch ( (int)v10 ) /*0x10679c12d*/
      {
        case 1: /*0x10679c12d*/
          LOBYTE(v6) = 9; /*0x10679c1f3*/
          goto LABEL_5; /*0x10679c1f5*/
        case 2: /*0x10679c12d*/
          LOBYTE(v6) = 10; /*0x10679c19c*/
          goto LABEL_5; /*0x10679c19e*/
        case 3: /*0x10679c12d*/
          LOBYTE(v6) = 44; /*0x10679c229*/
          goto LABEL_5; /*0x10679c22b*/
        case 4: /*0x10679c12d*/
          LOBYTE(v6) = 11; /*0x10679c237*/
          goto LABEL_5; /*0x10679c239*/
        case 5: /*0x10679c12d*/
          LOBYTE(v6) = 12; /*0x10679c1a3*/
          goto LABEL_5; /*0x10679c1a5*/
        case 6: /*0x10679c12d*/
          LOBYTE(v6) = 2; /*0x10679c1fa*/
          goto LABEL_5; /*0x10679c1fc*/
        case 8: /*0x10679c12d*/
        case 50: /*0x10679c12d*/
        case 51: /*0x10679c12d*/
        case 95: /*0x10679c12d*/
          LOBYTE(v6) = 28; /*0x10679c12f*/
          goto LABEL_5; /*0x10679c131*/
        case 10: /*0x10679c12d*/
          LOBYTE(v6) = 15; /*0x10679c253*/
          goto LABEL_5; /*0x10679c255*/
        case 11: /*0x10679c12d*/
          LOBYTE(v6) = 21; /*0x10679c26f*/
          goto LABEL_5; /*0x10679c271*/
        case 12: /*0x10679c12d*/
          LOBYTE(v6) = 22; /*0x10679c24c*/
          goto LABEL_5; /*0x10679c24e*/
        case 13: /*0x10679c12d*/
          LOBYTE(v6) = 24; /*0x10679c1d7*/
          goto LABEL_5; /*0x10679c1d9*/
        case 14: /*0x10679c12d*/
          LOBYTE(v6) = 25; /*0x10679c1de*/
          goto LABEL_5; /*0x10679c1e0*/
        case 15: /*0x10679c12d*/
          LOBYTE(v6) = 40; /*0x10679c23e*/
          goto LABEL_5; /*0x10679c240*/
        case 16: /*0x10679c12d*/
          LOBYTE(v6) = 27; /*0x10679c208*/
          goto LABEL_5; /*0x10679c20a*/
        case 17: /*0x10679c12d*/
          LOBYTE(v6) = 19; /*0x10679c27d*/
          goto LABEL_5; /*0x10679c27f*/
        case 18: /*0x10679c12d*/
          LOBYTE(v6) = 20; /*0x10679c187*/
          goto LABEL_5; /*0x10679c189*/
        case 19: /*0x10679c12d*/
          LOBYTE(v6) = 13; /*0x10679c261*/
          goto LABEL_5; /*0x10679c263*/
        case 20: /*0x10679c12d*/
          LOBYTE(v6) = 14; /*0x10679c159*/
          goto LABEL_5; /*0x10679c15b*/
        case 21: /*0x10679c12d*/
          LOBYTE(v6) = 16; /*0x10679c180*/
          goto LABEL_5; /*0x10679c182*/
        case 22: /*0x10679c12d*/
          LOBYTE(v6) = 17; /*0x10679c161*/
          goto LABEL_5; /*0x10679c163*/
        case 23: /*0x10679c12d*/
          LOBYTE(v6) = 42; /*0x10679c1aa*/
          goto LABEL_5; /*0x10679c1ac*/
        case 24: /*0x10679c12d*/
          LOBYTE(v6) = 43; /*0x10679c15d*/
          goto LABEL_5; /*0x10679c15f*/
        case 27: /*0x10679c12d*/
          LOBYTE(v6) = 41; /*0x10679c2a4*/
          goto LABEL_5; /*0x10679c2a6*/
        case 28: /*0x10679c12d*/
          LOBYTE(v6) = 18; /*0x10679c29d*/
          goto LABEL_5; /*0x10679c29f*/
        case 29: /*0x10679c12d*/
          LOBYTE(v6) = 34; /*0x10679c169*/
          goto LABEL_5; /*0x10679c16b*/
        case 30: /*0x10679c12d*/
          LOBYTE(v6) = 8; /*0x10679c18e*/
          goto LABEL_5; /*0x10679c190*/
        case 35: /*0x10679c12d*/
          LOBYTE(v6) = 29; /*0x10679c1e5*/
          goto LABEL_5; /*0x10679c1e7*/
        case 36: /*0x10679c12d*/
          LOBYTE(v6) = 30; /*0x10679c195*/
          goto LABEL_5; /*0x10679c197*/
        case 37: /*0x10679c12d*/
          LOBYTE(v6) = 31; /*0x10679c2b9*/
          goto LABEL_5; /*0x10679c2bb*/
        case 38: /*0x10679c12d*/
          LOBYTE(v6) = 32; /*0x10679c165*/
          goto LABEL_5; /*0x10679c167*/
        case 42: /*0x10679c12d*/
          LOBYTE(v6) = 38; /*0x10679c245*/
          goto LABEL_5; /*0x10679c247*/
        case 43: /*0x10679c12d*/
          LOBYTE(v6) = 39; /*0x10679c2b2*/
          goto LABEL_5; /*0x10679c2b4*/
        case 44: /*0x10679c12d*/
          LOBYTE(v6) = 37; /*0x10679c151*/
          goto LABEL_5; /*0x10679c153*/
        case 45: /*0x10679c12d*/
          LOBYTE(v6) = 35; /*0x10679c201*/
          goto LABEL_5; /*0x10679c203*/
        case 46: /*0x10679c12d*/
          LOBYTE(v6) = 36; /*0x10679c14d*/
          goto LABEL_5; /*0x10679c14f*/
        case 49: /*0x10679c12d*/
          LOBYTE(v6) = 33; /*0x10679c145*/
          goto LABEL_5; /*0x10679c147*/
        case 55: /*0x10679c12d*/
          v8 = 0; /*0x10679c16d*/
          v12 = FFlag::TweenInfoNetworkSchema == 0; /*0x10679c16f*/
          LOBYTE(v6) = 70; /*0x10679c176*/
          goto LABEL_59; /*0x10679c17b*/
        case 58: /*0x10679c12d*/
          v8 = 0; /*0x10679c1b8*/
          if ( FFlag::SupportRandomSerialization != 1 ) /*0x10679c1bd*/
            goto LABEL_11; /*0x10679c1bd*/
          v12 = DFFlag::SupportNetworkValueFormatRandom == 0; /*0x10679c1ca*/
          LOBYTE(v6) = 62; /*0x10679c1cd*/
LABEL_59:
          if ( v12 ) /*0x10679c295*/
            LOBYTE(v6) = 0; /*0x10679c295*/
          break; /*0x10679c295*/
        case 59: /*0x10679c12d*/
          LOBYTE(v6) = 53; /*0x10679c25a*/
          goto LABEL_5; /*0x10679c25c*/
        case 63: /*0x10679c12d*/
          LOBYTE(v6) = 46; /*0x10679c2ce*/
          goto LABEL_5; /*0x10679c2d0*/
        case 64: /*0x10679c12d*/
          LOBYTE(v6) = 48; /*0x10679c155*/
          goto LABEL_5; /*0x10679c157*/
        case 71: /*0x10679c12d*/
          LOBYTE(v6) = 51; /*0x10679c1ec*/
          goto LABEL_5; /*0x10679c1ee*/
        case 73: /*0x10679c12d*/
          LOBYTE(v6) = 52; /*0x10679c222*/
          goto LABEL_5; /*0x10679c224*/
        case 74: /*0x10679c12d*/
          LOBYTE(v6) = 54; /*0x10679c2c0*/
          goto LABEL_5; /*0x10679c2c2*/
        case 81: /*0x10679c12d*/
          v8 = 0; /*0x10679c216*/
          v12 = FFlag::InstanceAttributes == 0; /*0x10679c218*/
          LOBYTE(v6) = 69; /*0x10679c21b*/
          goto LABEL_59; /*0x10679c220*/
        case 82: /*0x10679c12d*/
          LOBYTE(v6) = 55; /*0x10679c149*/
          goto LABEL_5; /*0x10679c14b*/
        case 86: /*0x10679c12d*/
          LOBYTE(v6) = 56; /*0x10679c139*/
          goto LABEL_5; /*0x10679c13b*/
        case 87: /*0x10679c12d*/
          LOBYTE(v6) = DFFlag::SerializeLuauInteger << 6; /*0x10679c2de*/
          goto LABEL_5; /*0x10679c2e1*/
        case 89: /*0x10679c12d*/
          LOBYTE(v6) = 57; /*0x10679c2ab*/
          goto LABEL_5; /*0x10679c2ad*/
        case 90: /*0x10679c12d*/
          LOBYTE(v6) = 58; /*0x10679c141*/
          goto LABEL_5; /*0x10679c143*/
        case 92: /*0x10679c12d*/
          LOBYTE(v6) = 61; /*0x10679c230*/
          goto LABEL_5; /*0x10679c232*/
        case 93: /*0x10679c12d*/
          LOBYTE(v6) = 59; /*0x10679c268*/
          goto LABEL_5; /*0x10679c26a*/
        case 94: /*0x10679c12d*/
          LOBYTE(v6) = 60; /*0x10679c13d*/
          goto LABEL_5; /*0x10679c13f*/
        case 98: /*0x10679c12d*/
          v8 = 0; /*0x10679c28b*/
          v12 = FFlag::SlimAnimationReplication == 0; /*0x10679c28d*/
          LOBYTE(v6) = 63; /*0x10679c290*/
          goto LABEL_59; /*0x10679c290*/
        case 99: /*0x10679c12d*/
          LOBYTE(v6) = 68; /*0x10679c276*/
          goto LABEL_5; /*0x10679c278*/
        case 101: /*0x10679c12d*/
          LOBYTE(v6) = 65; /*0x10679c2ed*/
          goto LABEL_5; /*0x10679c2ef*/
        case 102: /*0x10679c12d*/
          LOBYTE(v6) = 66; /*0x10679c2c7*/
          goto LABEL_5; /*0x10679c2c9*/
        case 103: /*0x10679c12d*/
          LOBYTE(v6) = 67; /*0x10679c2e6*/
          goto LABEL_5; /*0x10679c2e8*/
        default:
          v8 = 0; /*0x10679c133*/
LABEL_11:
          LOBYTE(v6) = 0; /*0x10679c135*/
          break; /*0x10679c137*/
      }
    }
    v7 = 0; /*0x10679c0fe*/
  }
  return v8 | v7 | v9 | ((unsigned __int8)v6 << 8); /*0x10679c10f*/
}

// Address: 0x10679c490 | Name: __ZN3RBX7Network13NetworkSchema26reflectionTypeToSchemaTypeERKNS_10Reflection4TypeE
__int64 __fastcall RBX::Network::NetworkSchema::reflectionTypeToSchemaType(
        RBX::Network::NetworkSchema *this,
        const RBX::Reflection::Type *a2)
{
  return RBX::Network::NetworkSchema::reflectionTypeToSchemaType(a1: *((unsigned int *)this + 12)); /*0x10679c497*/
}

// Address: 0x10679c49e | Name: __ZN3RBX7Network13NetworkSchema26reflectionTypeToSchemaTypeENS_10Reflection14ReflectionTypeE
__int64 __fastcall RBX::Network::NetworkSchema::reflectionTypeToSchemaType(int a1)
{
  __int64 result; // rax
  bool v2; // zf

  switch ( a1 ) /*0x10679c4b7*/
  {
    case 1: /*0x10679c4b7*/
      LOBYTE(result) = 9; /*0x10679c5ab*/
      return (unsigned __int8)result; /*0x10679c5ad*/
    case 2: /*0x10679c4b7*/
      LOBYTE(result) = 10; /*0x10679c551*/
      return (unsigned __int8)result; /*0x10679c553*/
    case 3: /*0x10679c4b7*/
      LOBYTE(result) = 44; /*0x10679c5de*/
      return (unsigned __int8)result; /*0x10679c5e0*/
    case 4: /*0x10679c4b7*/
      LOBYTE(result) = 11; /*0x10679c5e6*/
      return (unsigned __int8)result; /*0x10679c5e8*/
    case 5: /*0x10679c4b7*/
      LOBYTE(result) = 12; /*0x10679c558*/
      return (unsigned __int8)result; /*0x10679c55a*/
    case 6: /*0x10679c4b7*/
      LOBYTE(result) = 2; /*0x10679c5b2*/
      return (unsigned __int8)result; /*0x10679c5b4*/
    case 8: /*0x10679c4b7*/
    case 50: /*0x10679c4b7*/
    case 51: /*0x10679c4b7*/
    case 95: /*0x10679c4b7*/
      LOBYTE(result) = 28; /*0x10679c4b9*/
      return (unsigned __int8)result; /*0x10679c4bb*/
    case 10: /*0x10679c4b7*/
      LOBYTE(result) = 15; /*0x10679c5f6*/
      return (unsigned __int8)result; /*0x10679c5f8*/
    case 11: /*0x10679c4b7*/
      LOBYTE(result) = 21; /*0x10679c606*/
      return (unsigned __int8)result; /*0x10679c608*/
    case 12: /*0x10679c4b7*/
      LOBYTE(result) = 22; /*0x10679c5f2*/
      return (unsigned __int8)result; /*0x10679c5f4*/
    case 13: /*0x10679c4b7*/
      LOBYTE(result) = 24; /*0x10679c58f*/
      return (unsigned __int8)result; /*0x10679c591*/
    case 14: /*0x10679c4b7*/
      LOBYTE(result) = 25; /*0x10679c596*/
      return (unsigned __int8)result; /*0x10679c598*/
    case 15: /*0x10679c4b7*/
      LOBYTE(result) = 40; /*0x10679c5ea*/
      return (unsigned __int8)result; /*0x10679c5ec*/
    case 16: /*0x10679c4b7*/
      LOBYTE(result) = 27; /*0x10679c5c0*/
      return (unsigned __int8)result; /*0x10679c5c2*/
    case 17: /*0x10679c4b7*/
      LOBYTE(result) = 19; /*0x10679c60e*/
      return (unsigned __int8)result; /*0x10679c610*/
    case 18: /*0x10679c4b7*/
      LOBYTE(result) = 20; /*0x10679c53c*/
      return (unsigned __int8)result; /*0x10679c53e*/
    case 19: /*0x10679c4b7*/
      LOBYTE(result) = 13; /*0x10679c5fe*/
      return (unsigned __int8)result; /*0x10679c600*/
    case 20: /*0x10679c4b7*/
      LOBYTE(result) = 14; /*0x10679c4ff*/
      return (unsigned __int8)result; /*0x10679c501*/
    case 21: /*0x10679c4b7*/
      LOBYTE(result) = 16; /*0x10679c535*/
      return (unsigned __int8)result; /*0x10679c537*/
    case 22: /*0x10679c4b7*/
      LOBYTE(result) = 17; /*0x10679c50d*/
      return (unsigned __int8)result; /*0x10679c50f*/
    case 23: /*0x10679c4b7*/
      LOBYTE(result) = 42; /*0x10679c55f*/
      return (unsigned __int8)result; /*0x10679c561*/
    case 24: /*0x10679c4b7*/
      LOBYTE(result) = 43; /*0x10679c506*/
      return (unsigned __int8)result; /*0x10679c508*/
    case 27: /*0x10679c4b7*/
      LOBYTE(result) = 41; /*0x10679c62c*/
      return (unsigned __int8)result; /*0x10679c62e*/
    case 28: /*0x10679c4b7*/
      LOBYTE(result) = 18; /*0x10679c628*/
      return (unsigned __int8)result; /*0x10679c62a*/
    case 29: /*0x10679c4b7*/
      LOBYTE(result) = 34; /*0x10679c51b*/
      return (unsigned __int8)result; /*0x10679c51d*/
    case 30: /*0x10679c4b7*/
      LOBYTE(result) = 8; /*0x10679c543*/
      return (unsigned __int8)result; /*0x10679c545*/
    case 35: /*0x10679c4b7*/
      LOBYTE(result) = 29; /*0x10679c59d*/
      return (unsigned __int8)result; /*0x10679c59f*/
    case 36: /*0x10679c4b7*/
      LOBYTE(result) = 30; /*0x10679c54a*/
      return (unsigned __int8)result; /*0x10679c54c*/
    case 37: /*0x10679c4b7*/
      LOBYTE(result) = 31; /*0x10679c638*/
      return (unsigned __int8)result; /*0x10679c63a*/
    case 38: /*0x10679c4b7*/
      LOBYTE(result) = 32; /*0x10679c514*/
      return (unsigned __int8)result; /*0x10679c516*/
    case 42: /*0x10679c4b7*/
      LOBYTE(result) = 38; /*0x10679c5ee*/
      return (unsigned __int8)result; /*0x10679c5f0*/
    case 43: /*0x10679c4b7*/
      LOBYTE(result) = 39; /*0x10679c634*/
      return (unsigned __int8)result; /*0x10679c636*/
    case 44: /*0x10679c4b7*/
      LOBYTE(result) = 37; /*0x10679c4f1*/
      return (unsigned __int8)result; /*0x10679c4f3*/
    case 45: /*0x10679c4b7*/
      LOBYTE(result) = 35; /*0x10679c5b9*/
      return (unsigned __int8)result; /*0x10679c5bb*/
    case 46: /*0x10679c4b7*/
      LOBYTE(result) = 36; /*0x10679c4ea*/
      return (unsigned __int8)result; /*0x10679c4ec*/
    case 49: /*0x10679c4b7*/
      LOBYTE(result) = 33; /*0x10679c4dc*/
      return (unsigned __int8)result; /*0x10679c4de*/
    case 55: /*0x10679c4b7*/
      v2 = FFlag::TweenInfoNetworkSchema == 0; /*0x10679c524*/
      LOBYTE(result) = 70; /*0x10679c52b*/
      goto LABEL_53; /*0x10679c530*/
    case 58: /*0x10679c4b7*/
      LOBYTE(result) = 0; /*0x10679c56d*/
      if ( FFlag::SupportRandomSerialization == 1 && DFFlag::SupportNetworkValueFormatRandom != 0 ) /*0x10679c587*/
        LOBYTE(result) = 62; /*0x10679c587*/
      return (unsigned __int8)result; /*0x10679c587*/
    case 59: /*0x10679c4b7*/
      LOBYTE(result) = 53; /*0x10679c5fa*/
      return (unsigned __int8)result; /*0x10679c5fc*/
    case 63: /*0x10679c4b7*/
      LOBYTE(result) = 46; /*0x10679c644*/
      return (unsigned __int8)result; /*0x10679c646*/
    case 64: /*0x10679c4b7*/
      LOBYTE(result) = 48; /*0x10679c4f8*/
      return (unsigned __int8)result; /*0x10679c4fa*/
    case 71: /*0x10679c4b7*/
      LOBYTE(result) = 51; /*0x10679c5a4*/
      return (unsigned __int8)result; /*0x10679c5a6*/
    case 73: /*0x10679c4b7*/
      LOBYTE(result) = 52; /*0x10679c5da*/
      return (unsigned __int8)result; /*0x10679c5dc*/
    case 74: /*0x10679c4b7*/
      LOBYTE(result) = 54; /*0x10679c63c*/
      return (unsigned __int8)result; /*0x10679c63e*/
    case 81: /*0x10679c4b7*/
      v2 = FFlag::InstanceAttributes == 0; /*0x10679c5d0*/
      LOBYTE(result) = 69; /*0x10679c5d3*/
      goto LABEL_53; /*0x10679c5d8*/
    case 82: /*0x10679c4b7*/
      LOBYTE(result) = 55; /*0x10679c4e3*/
      return (unsigned __int8)result; /*0x10679c4e5*/
    case 86: /*0x10679c4b7*/
      LOBYTE(result) = 56; /*0x10679c4c7*/
      return (unsigned __int8)result; /*0x10679c4c9*/
    case 87: /*0x10679c4b7*/
      LOBYTE(result) = DFFlag::SerializeLuauInteger << 6; /*0x10679c651*/
      return (unsigned __int8)result; /*0x10679c654*/
    case 89: /*0x10679c4b7*/
      LOBYTE(result) = 57; /*0x10679c630*/
      return (unsigned __int8)result; /*0x10679c632*/
    case 90: /*0x10679c4b7*/
      LOBYTE(result) = 58; /*0x10679c4d5*/
      return (unsigned __int8)result; /*0x10679c4d7*/
    case 92: /*0x10679c4b7*/
      LOBYTE(result) = 61; /*0x10679c5e2*/
      return (unsigned __int8)result; /*0x10679c5e4*/
    case 93: /*0x10679c4b7*/
      LOBYTE(result) = 59; /*0x10679c602*/
      return (unsigned __int8)result; /*0x10679c604*/
    case 94: /*0x10679c4b7*/
      LOBYTE(result) = 60; /*0x10679c4ce*/
      return (unsigned __int8)result; /*0x10679c4d0*/
    case 98: /*0x10679c4b7*/
      v2 = FFlag::SlimAnimationReplication == 0; /*0x10679c61b*/
      LOBYTE(result) = 63; /*0x10679c61e*/
LABEL_53:
      if ( v2 ) /*0x10679c623*/
        LOBYTE(result) = 0; /*0x10679c623*/
      break; /*0x10679c623*/
    case 99: /*0x10679c4b7*/
      LOBYTE(result) = 68; /*0x10679c60a*/
      break; /*0x10679c60c*/
    case 101: /*0x10679c4b7*/
      LOBYTE(result) = 65; /*0x10679c65a*/
      break; /*0x10679c65a*/
    case 102: /*0x10679c4b7*/
      LOBYTE(result) = 66; /*0x10679c640*/
      break; /*0x10679c642*/
    case 103: /*0x10679c4b7*/
      LOBYTE(result) = 67; /*0x10679c656*/
      break; /*0x10679c658*/
    default:
      LOBYTE(result) = 0; /*0x10679c4c0*/
      break; /*0x10679c4c2*/
  }
  return (unsigned __int8)result; /*0x10679c65f*/
}

// Address: 0x10679c800 | Name: __ZNK3RBX7Network13NetworkSchema25getEngineNetConfigurationEv
__int64 __fastcall RBX::Network::NetworkSchema::getEngineNetConfiguration(RBX::Network::NetworkSchema *this)
{
  return (__int64)this + 8; /*0x10679c808*/
}

// Address: 0x10679c80a | Name: __ZNK3RBX7Network13NetworkSchema32getEngineNetConfigurationDynamicEv
RBX::Network::NetworkSchema *__fastcall RBX::Network::NetworkSchema::getEngineNetConfigurationDynamic(
        RBX::Network::NetworkSchema *this,
        __int64 a2)
{
  if ( *(_BYTE *)(a2 + 1) != 0 ) /*0x10679c817*/
    *(_QWORD *)this = *(_QWORD *)(a2 + 8); /*0x10679c81d*/
  else
    RBX::EngineNetConfiguration::EngineNetConfiguration(a1: this, a2: 0); /*0x10679c827*/
  return this; /*0x10679c833*/
}

// Address: 0x10679c836 | Name: __ZNK3RBX7Network13NetworkSchema11typeForTypeERKNS_10Reflection4TypeE
unsigned __int64 __fastcall RBX::Network::NetworkSchema::typeForType(
        RBX::Network::NetworkSchema *this,
        const RBX::Reflection::Type *a2,
        __int64 a3)
{
  return RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType(a1: (__int64)a2, a2: (__int64)this + 16, a3); /*0x10679c844*/
}

// Address: 0x10679c84a | Name: __ZNK3RBX7Network13NetworkSchema14typeForVariantERKNS_10Reflection7VariantE
unsigned __int64 __fastcall RBX::Network::NetworkSchema::typeForVariant(
        RBX::Network::NetworkSchema *this,
        const RBX::Reflection::Variant *a2,
        __int64 a3)
{
  return RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType(a1: *(_QWORD *)a2, a2: (__int64)this + 16, a3); /*0x10679c858*/
}

// Address: 0x10679c85e | Name: __ZN3RBX7Network13NetworkSchema20typeForEventArgumentERKNS_10Reflection4TypeERKNS_12DenseHashMapIPS4_NS0_18NetworkSchemaTypes4TypeENS_4HashIS7_EENSt3__18equal_toIS7_EEEE
unsigned __int64 __fastcall RBX::Network::NetworkSchema::typeForEventArgument(__int64 a1, __int64 a2, __int64 a3)
{
  return RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType(a1, a2, a3); /*0x10679c862*/
}

// Address: 0x10679c868 | Name: __ZN3RBX7Network13NetworkSchema15typeForPropertyERKNS_10Reflection15ClassDescriptorERKNS2_18PropertyDescriptorEbRKNS_12DenseHashMapIPKNS2_4TypeENS0_18NetworkSchemaTypes4TypeENS_4HashISC_EENSt3__18equal_toISC_EEEEPb
unsigned __int64 __fastcall RBX::Network::NetworkSchema::typeForProperty(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        _BYTE *a5)
{
  __int64 v5; // rbx
  LuaVM *v6; // rdi
  int v7; // eax
  __int64 v8; // rax
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rsi
  __int64 v11; // rcx
  bool v12; // zf

  v5 = 4294901760LL; /*0x10679c86e*/
  v6 = *(LuaVM **)(a2 + 104); /*0x10679c873*/
  v7 = *((_DWORD *)v6 + 12); /*0x10679c877*/
  if ( v7 <= 11 ) /*0x10679c87d*/
  {
    if ( v7 == 6 ) /*0x10679c8a5*/
    {
      v8 = 512; /*0x10679c8e2*/
      if ( RBX::Instance::desc_Name == a2 ) /*0x10679c8e7*/
        v8 = 12544; /*0x10679c8e7*/
      goto LABEL_18; /*0x10679c8e7*/
    }
    if ( v7 == 7 ) /*0x10679c8aa*/
    {
      *a5 = 1; /*0x10679c8ac*/
      if ( (_BYTE)a3 != 0 ) /*0x10679c8b2*/
      {
        v8 = 1536; /*0x10679c8b4*/
      }
      else
      {
        v12 = (unsigned __int8)LuaVM::useSecureReplication(this: v6) == 0; /*0x10679c919*/
        v8 = 1536; /*0x10679c920*/
        if ( !v12 ) /*0x10679c925*/
          v8 = 12032; /*0x10679c925*/
      }
      goto LABEL_18; /*0x10679c8b9*/
    }
  }
  else
  {
    switch ( v7 ) /*0x10679c882*/
    {
      case 12: /*0x10679c882*/
        v8 = 5632; /*0x10679c8bb*/
        goto LABEL_18; /*0x10679c8c0*/
      case 16: /*0x10679c882*/
        v8 = ((unsigned __int8)(a3 ^ 1) << 8) | 0x1A00LL; /*0x10679c8cb*/
        goto LABEL_18; /*0x10679c8d1*/
      case 71: /*0x10679c882*/
        v8 = ((unsigned __int8)(a3 ^ 1) << 8) | 0x3200LL; /*0x10679c897*/
LABEL_18:
        v11 = 0; /*0x10679c929*/
        v10 = 0; /*0x10679c92b*/
        return v10 | v5 | v8 | v11; /*0x10679c92b*/
      default:
        break; /*0x10679c882*/
    }
  }
  v9 = RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType(a1: (__int64)v6, a2: a4, a3); /*0x10679c8f0*/
  v10 = v9 & 0xFFFFFFFF00000000LL; /*0x10679c8ff*/
  v5 = (unsigned int)v9 & 0xFFFF0000; /*0x10679c904*/
  v11 = (unsigned __int8)v9; /*0x10679c90a*/
  v8 = (unsigned __int16)v9 & 0xFF00; /*0x10679c90d*/
  return v10 | v5 | v8 | v11; /*0x10679c93d*/
}

// Address: 0x10679c940 | Name: __ZN3RBX7Network13NetworkSchema30generateSchemaDefinitionPacketEbPNS0_16ServerSchemaInfoENS_22EngineNetConfigurationE
__int64 __fastcall RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(RSL::Arena *a1, __int64 a2, void **a3)
{
  void *DefaultArena; // rbx
  void *v4; // rsi
  __int64 v5; // rdx
  __int128 v6; // xmm0
  void *v7; // rax
  RSL::Arena *v8; // rdi
  void *v9; // rsi
  __int64 v10; // rdx
  __int64 v11; // rcx
  const char *v12; // rsi
  __int64 v13; // r8
  __int64 v14; // r9
  __m128 v15; // xmm0
  __m128 v16; // xmm1
  __m128 v17; // xmm2
  __m128 v18; // xmm3
  __m128 v19; // xmm4
  __m128 v20; // xmm5
  __m128 v21; // xmm6
  __m128 v22; // xmm7
  RBX::Reflection::EnumDescriptor *v23; // rdi
  __int64 v24; // rbx
  RBX::Network::NetworkStream *v25; // rdx
  RBX::Reflection::EnumDescriptor *v26; // rdi
  RBX::Reflection::EnumDescriptor *v27; // rdi
  __int64 v28; // r15
  int v29; // r12d
  __int64 v30; // rdx
  __int64 v31; // rcx
  RBX::Reflection::ClassDescriptor *v32; // rdi
  const char *v33; // rsi
  __int64 v34; // r8
  __int64 v35; // r9
  __m128 v36; // xmm0
  __m128 v37; // xmm1
  __m128 v38; // xmm2
  __m128 v39; // xmm3
  __m128 v40; // xmm4
  __m128 v41; // xmm5
  __m128 v42; // xmm6
  __m128 v43; // xmm7
  __int64 v44; // r14
  RBX::Reflection::ClassDescriptor *v45; // rdi
  __int64 *v46; // r15
  _BYTE *v47; // r14
  __int128 v48; // rcx
  bool v49; // zf
  const RBX::Name *v50; // rsi
  __int64 v51; // rbx
  __int64 Creator; // rax
  void *v53; // rsi
  __int64 v54; // r8
  __int16 v55; // cx
  __int64 v56; // rdx
  char *v57; // r12
  char *v58; // r12
  RBX::Memory *v59; // rdi
  signed __int64 v60; // rbx
  __int64 v61; // r15
  unsigned __int64 v62; // r12
  __int64 v63; // r14
  __int64 v64; // r12
  RBX::Network *v65; // rcx
  RBX::Memory *v66; // rdi
  char *v67; // r13
  char *v68; // rbx
  RBX::Network *v69; // r15
  char *v70; // rbx
  __int64 v71; // rdx
  const char *v72; // rsi
  __int64 v73; // r8
  __int64 v74; // r9
  __m128 v75; // xmm0
  __m128 v76; // xmm1
  __m128 v77; // xmm2
  __m128 v78; // xmm3
  __m128 v79; // xmm4
  __m128 v80; // xmm5
  __m128 v81; // xmm6
  __m128 v82; // xmm7
  _QWORD *v83; // rax
  char *v84; // r14
  __int64 v85; // rdi
  __int64 v86; // r8
  __int64 v87; // rdx
  char *v88; // r12
  unsigned __int16 v89; // ax
  unsigned __int64 v90; // r14
  unsigned __int64 v91; // rax
  __int64 v92; // rcx
  RBX::Network::NetAssetManagerFactories *v93; // rdi
  __int64 v94; // rdx
  signed __int64 v95; // r14
  __int64 v96; // r13
  unsigned __int64 v97; // rax
  unsigned __int64 v98; // rsi
  unsigned __int64 v99; // r12
  _QWORD *v100; // r14
  __int64 v101; // r12
  RBX::Memory *v102; // r13
  void *v103; // rsi
  __int64 v104; // rdx
  __int64 v105; // r13
  __int64 v106; // r12
  char *v107; // rbx
  char v108; // r14
  unsigned int v109; // ebx
  char *v110; // r12
  char *v111; // rax
  unsigned __int64 v112; // rcx
  RBX::Network::NetworkStream *v113; // rdx
  int v114; // r15d
  unsigned __int64 i; // r14
  __int64 v116; // rax
  RBX::Network::NetAssetManagerFactories *v117; // rdi
  unsigned __int16 DeltaTypeForType; // ax
  __int16 v119; // cx
  RBX::Network::NetworkStream *v120; // rdx
  RBX::Network::NetworkStream *v121; // rdx
  RBX::Network::NetworkStream *v122; // rdx
  char *v123; // rbx
  RBX::Network::NetworkStream *v124; // rdx
  __int64 *v125; // r12
  __int16 v126; // r13
  __int64 v127; // rdi
  int v128; // ebx
  unsigned __int16 v129; // ax
  void *v130; // rbx
  RBX::Network::NetworkStream *v131; // rdx
  RBX::Network *v132; // r12
  __int64 v133; // rbx
  RBX::Network::NetworkStream *v134; // rdx
  __int64 v135; // r13
  __int64 v136; // r15
  unsigned __int64 v137; // rax
  __int16 v138; // ebx^2
  __int64 k; // r14
  __int64 v140; // rdx
  __int64 v141; // rcx
  __int64 v142; // rdx
  __int64 v143; // rcx
  __int64 v144; // rdx
  __int64 v145; // rcx
  __int64 v146; // rdx
  __int64 v147; // rcx
  __int64 v148; // rdx
  __int64 v149; // rcx
  __int64 v150; // rdx
  __int64 v151; // rcx
  __int64 v152; // rdx
  __int64 v153; // rcx
  __int64 v154; // rdx
  __int64 v155; // rcx
  __int64 v156; // rdx
  __int64 v157; // rcx
  __int64 v158; // rdx
  __int64 v159; // rcx
  __int64 v160; // rdx
  __int64 v161; // rcx
  __int64 v162; // rdx
  __int64 v163; // rcx
  __int64 v164; // rdx
  __int64 v165; // rcx
  __int64 v166; // rdx
  __int64 v167; // rcx
  __int64 v168; // rdx
  __int64 v169; // rcx
  __int64 v170; // rdx
  __int64 v171; // rcx
  __int64 v172; // rdx
  __int64 v173; // rcx
  __int64 v174; // rdx
  __int64 v175; // rcx
  __int64 v176; // rdx
  __int64 v177; // rcx
  __int64 v178; // rdx
  __int64 v179; // rcx
  __int64 v180; // rdx
  __int64 v181; // rcx
  __int64 v182; // rdx
  __int64 v183; // rcx
  __int64 v184; // rdx
  __int64 v185; // rcx
  __int64 v186; // rdx
  __int64 v187; // rcx
  __int64 v188; // rdx
  __int64 v189; // rcx
  __int64 v190; // rdx
  __int64 v191; // rcx
  __int64 v192; // rdx
  __int64 v193; // rcx
  __int64 v194; // rdx
  __int64 v195; // rcx
  __int64 v196; // rdx
  __int64 v197; // rcx
  __int64 v198; // rdx
  __int64 v199; // rcx
  __int64 v200; // rdx
  __int64 v201; // rcx
  __int64 v202; // rdx
  __int64 v203; // rcx
  __int64 v204; // rdx
  __int64 v205; // rcx
  __int64 v206; // rdx
  __int64 v207; // rcx
  __int64 v208; // rdx
  __int64 v209; // rcx
  __int64 v210; // rdx
  __int64 v211; // rcx
  __int64 v212; // rdx
  __int64 v213; // rcx
  __int64 v214; // rdx
  __int64 v215; // rcx
  __int64 v216; // rdx
  __int64 v217; // rcx
  __int64 v218; // rdx
  __int64 v219; // rcx
  __int64 v220; // rdx
  __int64 v221; // rcx
  __int64 v222; // rdx
  __int64 v223; // rcx
  __int64 v224; // rdx
  __int64 v225; // rcx
  __int64 v226; // rdx
  __int64 v227; // rcx
  __int64 v228; // rdx
  __int64 v229; // rcx
  __int64 v230; // rdx
  __int64 v231; // rcx
  __int64 v232; // rdx
  __int64 v233; // rcx
  __int64 v234; // rdx
  __int64 v235; // rcx
  __int64 v236; // rdx
  __int64 v237; // rcx
  __int64 v238; // rdx
  __int64 v239; // rcx
  __int64 v240; // rdx
  __int64 v241; // rcx
  __int64 v242; // rdx
  __int64 v243; // rcx
  __int64 v244; // rdx
  __int64 v245; // rcx
  __int64 v246; // rdx
  __int64 v247; // rcx
  __int64 v248; // rdx
  __int64 v249; // rcx
  __int64 v250; // rdx
  __int64 v251; // rcx
  __int64 v252; // rdx
  __int64 v253; // rcx
  __int64 v254; // rdx
  __int64 v255; // rcx
  __int64 v256; // rdx
  __int64 v257; // rcx
  __int64 v258; // rdx
  __int64 v259; // rcx
  __int64 v260; // rdx
  __int64 v261; // rcx
  __int64 v262; // rdx
  __int64 v263; // rcx
  __int64 v264; // rdx
  __int64 v265; // rcx
  __int64 v266; // rdx
  __int64 v267; // rcx
  __int64 v268; // rdx
  __int64 v269; // rcx
  __int64 v270; // rdx
  __int64 v271; // rcx
  __int64 v272; // rdx
  __int64 v273; // rcx
  __int64 v274; // rdx
  __int64 v275; // rcx
  __int64 v276; // rdx
  __int64 v277; // rcx
  __int64 v278; // rdx
  __int64 v279; // rcx
  __int64 v280; // rdx
  __int64 v281; // rcx
  __int64 v282; // rdx
  __int64 v283; // rcx
  __int64 v284; // rdx
  __int64 v285; // rcx
  __int64 v286; // rdx
  __int64 v287; // rcx
  __int64 v288; // rdx
  __int64 v289; // rcx
  __int64 v290; // rdx
  __int64 v291; // rcx
  __int64 v292; // rdx
  __int64 v293; // rcx
  __int64 v294; // rdx
  __int64 v295; // rcx
  __int64 v296; // rdx
  __int64 v297; // rcx
  __int64 v298; // rdx
  __int64 v299; // rcx
  __int64 v300; // rdx
  __int64 v301; // rcx
  __int64 v302; // rdx
  __int64 v303; // rcx
  __int64 v304; // rdx
  __int64 v305; // rcx
  __int64 v306; // rdx
  __int64 v307; // rcx
  __int64 v308; // rdx
  __int64 v309; // rcx
  __int64 v310; // rdx
  __int64 v311; // rcx
  __int64 v312; // rdx
  __int64 v313; // rcx
  __int64 v314; // rdx
  __int64 v315; // rcx
  __int64 v316; // rdx
  __int64 v317; // rcx
  __int64 v318; // rdx
  __int64 v319; // rcx
  __int64 v320; // rdx
  __int64 v321; // rcx
  __int64 v322; // rdx
  __int64 v323; // rcx
  __int64 v324; // rdx
  __int64 v325; // rcx
  __int64 v326; // rdx
  __int64 v327; // rcx
  __int64 v328; // rdx
  __int64 v329; // rcx
  __int64 v330; // rdx
  __int64 v331; // rcx
  __int64 v332; // rdx
  __int64 v333; // rcx
  __int64 v334; // rdx
  __int64 v335; // rcx
  __int64 v336; // rdx
  __int64 v337; // rcx
  __int64 v338; // rdx
  __int64 v339; // rcx
  __int64 v340; // rdx
  __int64 v341; // rcx
  __int64 v342; // rdx
  __int64 v343; // rcx
  __int64 v344; // rdx
  __int64 v345; // rcx
  __int64 v346; // rdx
  __int64 v347; // rcx
  __int64 v348; // rdx
  __int64 v349; // rcx
  __int64 v350; // rdx
  __int64 v351; // rcx
  __int64 v352; // rdx
  __int64 v353; // rcx
  __int64 v354; // rdx
  __int64 v355; // rcx
  __int64 v356; // rdx
  __int64 v357; // rcx
  __int64 v358; // rdx
  __int64 v359; // rcx
  __int64 v360; // rdx
  __int64 v361; // rcx
  __int64 v362; // rdx
  __int64 v363; // rcx
  __int64 v364; // rdx
  __int64 v365; // rcx
  __int64 v366; // rdx
  __int64 v367; // rcx
  __int64 v368; // rdx
  __int64 v369; // rcx
  __int64 v370; // rdx
  __int64 v371; // rcx
  __int64 v372; // rdx
  __int64 v373; // rcx
  __int64 v374; // rdx
  __int64 v375; // rcx
  __int64 v376; // rdx
  __int64 v377; // rcx
  __int64 v378; // rdx
  __int64 v379; // rcx
  __int64 v380; // rdx
  __int64 v381; // rcx
  __int64 v382; // rdx
  __int64 v383; // rcx
  __int64 v384; // rdx
  __int64 v385; // rcx
  __int64 v386; // rdx
  __int64 v387; // rcx
  __int64 v388; // rdx
  __int64 v389; // rcx
  __int64 v390; // rdx
  __int64 v391; // rcx
  RBX::Network::NetworkStream *v392; // rdx
  __int64 v393; // rcx
  void *v394; // rsi
  __int64 m; // rbx
  __int64 v396; // r15
  __int64 v397; // r15
  __int64 v398; // rax
  char *v399; // rcx
  unsigned __int64 v400; // rax
  __int64 v401; // rdi
  char *v402; // rsi
  unsigned __int64 v403; // rax
  char *v404; // r15
  RBX::Network::NetworkStream *v405; // r13
  _OWORD *v406; // r14
  unsigned __int64 v407; // r14
  unsigned __int64 v408; // rsi
  __int64 v409; // rax
  __int64 v410; // rdx
  unsigned __int64 v411; // r14
  __int64 v412; // rbx
  unsigned __int64 v413; // r12
  void *v414; // r14
  void *v415; // rax
  void *v416; // rcx
  void *v417; // rsi
  unsigned __int8 *n; // rbx
  unsigned __int8 *v419; // r14
  _DWORD **v420; // r15
  _DWORD *v421; // r12
  char *v422; // rcx
  __int64 v423; // r8
  __int64 v424; // r9
  __m128 v425; // xmm0
  __m128 v426; // xmm1
  __m128 v427; // xmm2
  __m128 v428; // xmm3
  __m128 v429; // xmm4
  __m128 v430; // xmm5
  __m128 v431; // xmm6
  __m128 v432; // xmm7
  _DWORD *v433; // r13
  _DWORD *v434; // r12
  unsigned __int64 v435; // r15
  char v436; // al
  void *v437; // rax
  __int64 v438; // rsi
  const char *v439; // rsi
  __int64 v440; // rsi
  __int64 ii; // rbx
  __int64 v442; // rax
  RBX::Network::NetAssetManagerFactories *v443; // rdi
  unsigned __int16 v444; // r12
  unsigned __int16 Version; // ax
  unsigned __int16 v446; // ax
  RBX::Network::NetworkStream *v447; // rdi
  unsigned __int8 v448; // cl
  void *v449; // rsi
  void *v450; // rsi
  __int64 v452; // rsi
  const char *v453; // rsi
  char v454; // [rsp+0h] [rbp-DA0h]
  __int64 v455; // [rsp+8h] [rbp-D98h] BYREF
  __int128 v456; // [rsp+10h] [rbp-D90h]
  _BYTE v457[24]; // [rsp+20h] [rbp-D80h] BYREF
  char v458[8]; // [rsp+38h] [rbp-D68h] BYREF
  unsigned __int64 v459; // [rsp+40h] [rbp-D60h]
  RSL::Arena *v460; // [rsp+48h] [rbp-D58h]
  char *v461; // [rsp+78h] [rbp-D28h] BYREF
  RBX::Network::NetworkStream *v462; // [rsp+80h] [rbp-D20h]
  __int64 v463; // [rsp+88h] [rbp-D18h]
  __int128 v464; // [rsp+90h] [rbp-D10h] BYREF
  unsigned __int64 v465; // [rsp+A0h] [rbp-D00h]
  void *v466[3]; // [rsp+B0h] [rbp-CF0h] BYREF
  void **v467; // [rsp+C8h] [rbp-CD8h]
  char *v468; // [rsp+D0h] [rbp-CD0h]
  char *v469; // [rsp+D8h] [rbp-CC8h]
  size_t __n; // [rsp+E0h] [rbp-CC0h]
  char *v471; // [rsp+E8h] [rbp-CB8h]
  _QWORD *v472; // [rsp+F0h] [rbp-CB0h]
  unsigned int v473[2]; // [rsp+F8h] [rbp-CA8h]
  __int128 v474; // [rsp+100h] [rbp-CA0h] BYREF
  void *v475; // [rsp+110h] [rbp-C90h]
  __int128 v476; // [rsp+120h] [rbp-C80h] BYREF
  void *v477; // [rsp+130h] [rbp-C70h] BYREF
  _DWORD v478[3]; // [rsp+13Ch] [rbp-C64h] BYREF
  unsigned __int64 v479; // [rsp+148h] [rbp-C58h]
  char *v480; // [rsp+150h] [rbp-C50h]
  RBX::Network *j; // [rsp+158h] [rbp-C48h]
  void *__src; // [rsp+160h] [rbp-C40h]
  void *v483; // [rsp+168h] [rbp-C38h]
  void *v484[6]; // [rsp+170h] [rbp-C30h] BYREF
  void *v485[12]; // [rsp+1A0h] [rbp-C00h] BYREF
  char v486[24]; // [rsp+200h] [rbp-BA0h] BYREF
  char v487[24]; // [rsp+218h] [rbp-B88h] BYREF
  char v488[24]; // [rsp+230h] [rbp-B70h] BYREF
  char v489[24]; // [rsp+248h] [rbp-B58h] BYREF
  char v490[24]; // [rsp+260h] [rbp-B40h] BYREF
  char v491[24]; // [rsp+278h] [rbp-B28h] BYREF
  char v492[24]; // [rsp+290h] [rbp-B10h] BYREF
  char v493[24]; // [rsp+2A8h] [rbp-AF8h] BYREF
  char v494[24]; // [rsp+2C0h] [rbp-AE0h] BYREF
  char v495[24]; // [rsp+2D8h] [rbp-AC8h] BYREF
  char v496[24]; // [rsp+2F0h] [rbp-AB0h] BYREF
  char v497[24]; // [rsp+308h] [rbp-A98h] BYREF
  char v498[24]; // [rsp+320h] [rbp-A80h] BYREF
  char v499[24]; // [rsp+338h] [rbp-A68h] BYREF
  char v500[24]; // [rsp+350h] [rbp-A50h] BYREF
  char v501[24]; // [rsp+368h] [rbp-A38h] BYREF
  char v502[24]; // [rsp+380h] [rbp-A20h] BYREF
  char v503[24]; // [rsp+398h] [rbp-A08h] BYREF
  char v504[24]; // [rsp+3B0h] [rbp-9F0h] BYREF
  char v505[24]; // [rsp+3C8h] [rbp-9D8h] BYREF
  char v506[24]; // [rsp+3E0h] [rbp-9C0h] BYREF
  char v507[24]; // [rsp+3F8h] [rbp-9A8h] BYREF
  char v508[24]; // [rsp+410h] [rbp-990h] BYREF
  char v509[24]; // [rsp+428h] [rbp-978h] BYREF
  char v510[24]; // [rsp+440h] [rbp-960h] BYREF
  char v511[24]; // [rsp+458h] [rbp-948h] BYREF
  char v512[24]; // [rsp+470h] [rbp-930h] BYREF
  char v513[24]; // [rsp+488h] [rbp-918h] BYREF
  char v514[24]; // [rsp+4A0h] [rbp-900h] BYREF
  char v515[24]; // [rsp+4B8h] [rbp-8E8h] BYREF
  char v516[24]; // [rsp+4D0h] [rbp-8D0h] BYREF
  char v517[24]; // [rsp+4E8h] [rbp-8B8h] BYREF
  char v518[24]; // [rsp+500h] [rbp-8A0h] BYREF
  char v519[24]; // [rsp+518h] [rbp-888h] BYREF
  char v520[24]; // [rsp+530h] [rbp-870h] BYREF
  char v521[24]; // [rsp+548h] [rbp-858h] BYREF
  char v522[24]; // [rsp+560h] [rbp-840h] BYREF
  char v523[24]; // [rsp+578h] [rbp-828h] BYREF
  char v524[24]; // [rsp+590h] [rbp-810h] BYREF
  char v525[24]; // [rsp+5A8h] [rbp-7F8h] BYREF
  char v526[24]; // [rsp+5C0h] [rbp-7E0h] BYREF
  char v527[24]; // [rsp+5D8h] [rbp-7C8h] BYREF
  char v528[24]; // [rsp+5F0h] [rbp-7B0h] BYREF
  char v529[24]; // [rsp+608h] [rbp-798h] BYREF
  char v530[24]; // [rsp+620h] [rbp-780h] BYREF
  char v531[24]; // [rsp+638h] [rbp-768h] BYREF
  char v532[24]; // [rsp+650h] [rbp-750h] BYREF
  char v533[24]; // [rsp+668h] [rbp-738h] BYREF
  char v534[24]; // [rsp+680h] [rbp-720h] BYREF
  char v535[24]; // [rsp+698h] [rbp-708h] BYREF
  char v536[24]; // [rsp+6B0h] [rbp-6F0h] BYREF
  char v537[24]; // [rsp+6C8h] [rbp-6D8h] BYREF
  char v538[24]; // [rsp+6E0h] [rbp-6C0h] BYREF
  char v539[24]; // [rsp+6F8h] [rbp-6A8h] BYREF
  char v540[24]; // [rsp+710h] [rbp-690h] BYREF
  char v541[24]; // [rsp+728h] [rbp-678h] BYREF
  char v542[24]; // [rsp+740h] [rbp-660h] BYREF
  char v543[24]; // [rsp+758h] [rbp-648h] BYREF
  char v544[24]; // [rsp+770h] [rbp-630h] BYREF
  char v545[24]; // [rsp+788h] [rbp-618h] BYREF
  char v546[24]; // [rsp+7A0h] [rbp-600h] BYREF
  char v547[24]; // [rsp+7B8h] [rbp-5E8h] BYREF
  char v548[24]; // [rsp+7D0h] [rbp-5D0h] BYREF
  char v549[24]; // [rsp+7E8h] [rbp-5B8h] BYREF
  char v550[24]; // [rsp+800h] [rbp-5A0h] BYREF
  char v551[24]; // [rsp+818h] [rbp-588h] BYREF
  char v552[24]; // [rsp+830h] [rbp-570h] BYREF
  char v553[24]; // [rsp+848h] [rbp-558h] BYREF
  char v554[24]; // [rsp+860h] [rbp-540h] BYREF
  char v555[24]; // [rsp+878h] [rbp-528h] BYREF
  char v556[24]; // [rsp+890h] [rbp-510h] BYREF
  char v557[24]; // [rsp+8A8h] [rbp-4F8h] BYREF
  char v558[24]; // [rsp+8C0h] [rbp-4E0h] BYREF
  char v559[24]; // [rsp+8D8h] [rbp-4C8h] BYREF
  char v560[24]; // [rsp+8F0h] [rbp-4B0h] BYREF
  char v561[24]; // [rsp+908h] [rbp-498h] BYREF
  char v562[24]; // [rsp+920h] [rbp-480h] BYREF
  char v563[24]; // [rsp+938h] [rbp-468h] BYREF
  char v564[24]; // [rsp+950h] [rbp-450h] BYREF
  char v565[24]; // [rsp+968h] [rbp-438h] BYREF
  char v566[24]; // [rsp+980h] [rbp-420h] BYREF
  char v567[24]; // [rsp+998h] [rbp-408h] BYREF
  char v568[24]; // [rsp+9B0h] [rbp-3F0h] BYREF
  char v569[24]; // [rsp+9C8h] [rbp-3D8h] BYREF
  char v570[24]; // [rsp+9E0h] [rbp-3C0h] BYREF
  char v571[24]; // [rsp+9F8h] [rbp-3A8h] BYREF
  char v572[24]; // [rsp+A10h] [rbp-390h] BYREF
  char v573[24]; // [rsp+A28h] [rbp-378h] BYREF
  char v574[24]; // [rsp+A40h] [rbp-360h] BYREF
  char v575[24]; // [rsp+A58h] [rbp-348h] BYREF
  char v576[24]; // [rsp+A70h] [rbp-330h] BYREF
  char v577[24]; // [rsp+A88h] [rbp-318h] BYREF
  char v578[24]; // [rsp+AA0h] [rbp-300h] BYREF
  char v579[24]; // [rsp+AB8h] [rbp-2E8h] BYREF
  char v580[24]; // [rsp+AD0h] [rbp-2D0h] BYREF
  char v581[24]; // [rsp+AE8h] [rbp-2B8h] BYREF
  char v582[24]; // [rsp+B00h] [rbp-2A0h] BYREF
  char v583[24]; // [rsp+B18h] [rbp-288h] BYREF
  char v584[24]; // [rsp+B30h] [rbp-270h] BYREF
  char v585[24]; // [rsp+B48h] [rbp-258h] BYREF
  char v586[24]; // [rsp+B60h] [rbp-240h] BYREF
  char v587[24]; // [rsp+B78h] [rbp-228h] BYREF
  char v588[24]; // [rsp+B90h] [rbp-210h] BYREF
  char v589[24]; // [rsp+BA8h] [rbp-1F8h] BYREF
  char v590[24]; // [rsp+BC0h] [rbp-1E0h] BYREF
  char v591[24]; // [rsp+BD8h] [rbp-1C8h] BYREF
  char v592[24]; // [rsp+BF0h] [rbp-1B0h] BYREF
  char v593[24]; // [rsp+C08h] [rbp-198h] BYREF
  char v594[24]; // [rsp+C20h] [rbp-180h] BYREF
  char v595[24]; // [rsp+C38h] [rbp-168h] BYREF
  char v596[24]; // [rsp+C50h] [rbp-150h] BYREF
  char v597[24]; // [rsp+C68h] [rbp-138h] BYREF
  char v598[24]; // [rsp+C80h] [rbp-120h] BYREF
  char v599[24]; // [rsp+C98h] [rbp-108h] BYREF
  char v600[24]; // [rsp+CB0h] [rbp-F0h] BYREF
  char v601[24]; // [rsp+CC8h] [rbp-D8h] BYREF
  char v602[24]; // [rsp+CE0h] [rbp-C0h] BYREF
  char v603[24]; // [rsp+CF8h] [rbp-A8h] BYREF
  char v604[24]; // [rsp+D10h] [rbp-90h] BYREF
  char v605[24]; // [rsp+D28h] [rbp-78h] BYREF
  char v606[24]; // [rsp+D40h] [rbp-60h] BYREF
  char v607[24]; // [rsp+D58h] [rbp-48h] BYREF
  __int64 v608[6]; // [rsp+D70h] [rbp-30h] BYREF

  v467 = a3; /*0x10679c954*/
  v463 = a2; /*0x10679c95b*/
  LODWORD(v468) = (_DWORD)a1; /*0x10679c962*/
  DefaultArena = (void *)RSL::Arena::getDefaultArena(this: a1); /*0x10679c97b*/
  *(_QWORD *)v457 = DefaultArena; /*0x10679c97e*/
  *(_OWORD *)&v457[8] = 0; /*0x10679c988*/
  if ( (FString::NetAssetExcludedTypes & 1) != 0 ) /*0x10679c999*/
  {
    v4 = (void *)qword_10D80B178; /*0x10679c99b*/
    v5 = qword_10D80B170; /*0x10679c9a2*/
  }
  else
  {
    v5 = (unsigned __int8)FString::NetAssetExcludedTypes >> 1; /*0x10679c9ab*/
    v4 = &unk_10D80B169; /*0x10679c9ad*/
  }
  RBX::Crypto::hexToBin(a1: v458, a2: v4, a3: v5); /*0x10679c9bb*/
  if ( (v458[0] & 1) == 0 || v459 <= 0x100 ) /*0x10679c9d4*/
  {
    RBX::Network::binaryToBitset(this: v484, a2: (unsigned __int8 *)v458); /*0x10679c9e4*/
    v485[0] = DefaultArena; /*0x10679c9f0*/
    v6 = *(_OWORD *)v484; /*0x10679c9f3*/
    v7 = v484[2]; /*0x10679c9fd*/
    *(_OWORD *)&v484[1] = 0; /*0x10679ca04*/
    *(_OWORD *)v457 = v6; /*0x10679ca0b*/
    *(_OWORD *)&v485[1] = 0; /*0x10679ca12*/
    *(_QWORD *)&v457[16] = v7; /*0x10679ca16*/
    RBX::dynamic_bitset::change_capacity(this: (RBX::dynamic_bitset *)v485, a2: 0); /*0x10679ca1f*/
    RBX::dynamic_bitset::change_capacity(this: (RBX::dynamic_bitset *)v484, a2: 0); /*0x10679ca2d*/
  }
  RBX::dynamic_bitset::resize(this: (RBX::dynamic_bitset *)v457, a2: 0xBu); /*0x10679ca3e*/
  if ( (v458[0] & 1) != 0 ) /*0x10679ca4a*/
    operator delete(a1: v460, a2: v9); /*0x10679ca53*/
  v455 = RSL::Arena::getDefaultArena(this: v8); /*0x10679ca64*/
  v456 = 0; /*0x10679ca6a*/
  RBX::dynamic_bitset::resize(this: (RBX::dynamic_bitset *)&v455, a2: 0xCu); /*0x10679ca73*/
  RBX::Network::NetworkStream::NetworkStream( /*0x10679ca85*/
    this: (RBX::Network::NetworkStream *)v458,
    a2: (unsigned int)DFInt::SchemaNetworkStreamSize);
  if ( FInt::NetworkSchemaVersion != 3 ) /*0x10679ca91*/
    RBX::throw_runtime_error( /*0x10679ea3b*/
      this: (RBX *)"Requesting Invalid Schema Version.",
      a2: v12,
      a3: v10,
      a4: v11,
      a5: v13,
      a6: v14,
      a7: v15,
      a8: v16,
      a9: v17,
      a10: v18,
      a11: v19,
      a12: v20,
      a13: v21,
      a14: v22,
      a15: v454);
  RBX::Network::NetworkStream::writeUInt32VarInt(this: (RBX::Network::NetworkStream *)v458, a2: 3u); /*0x10679caa3*/
  v485[0] = *v467; /*0x10679cab9*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v458, a2: v485, a3: 8u); /*0x10679cac8*/
  memset(v484, 0, 40); /*0x10679cad7*/
  v24 = RBX::Reflection::EnumDescriptor::allEnumSize(this: v23); /*0x10679caee*/
  RBX::Network::serializeUnsignedVarint(this: (RBX::Network *)(unsigned int)v24, a2: (unsigned __int64)v458, a3: v25); /*0x10679cafa*/
  *(_QWORD *)&v478[1] = v24; /*0x10679caff*/
  v28 = RBX::Reflection::EnumDescriptor::enumsBegin(this: v26); /*0x10679cb0b*/
  v29 = 0; /*0x10679cb0e*/
  while ( v28 != RBX::Reflection::EnumDescriptor::enumsEnd(this: v27) ) /*0x10679cb27*/
  {
    v485[0] = *(void **)v28; /*0x10679cb2c*/
    v44 = RBX::DenseHashMap<RBX::Reflection::Type const*,RBX::Network::NetworkSchemaTypes::Type,RBX::Hash<RBX::Reflection::Type const*>,std::equal_to<RBX::Reflection::Type const*>>::operator[]( /*0x10679cb42*/
            a1: v484,
            a2: (__int64)v485);
    *(_WORD *)(v44 + 2) = v29; /*0x10679cb45*/
    *(_BYTE *)(v44 + 1) = 7; /*0x10679cb4a*/
    RBX::Network::serializeString( /*0x10679cb61*/
      a1: *(unsigned __int8 **)(*(_QWORD *)v28 + 8LL),
      a2: (RBX::Network::NetworkStream *)v458,
      a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
    LOBYTE(v485[0]) = *(_BYTE *)(v44 + 1); /*0x10679cb6a*/
    RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v458, a2: v485, a3: 1u); /*0x10679cb7b*/
    v28 += 8; /*0x10679cb80*/
    ++v29; /*0x10679cb84*/
  }
  if ( v478[1] > 0xFFFEu ) /*0x10679cb93*/
    RBX::throw_runtime_error( /*0x10679ea4b*/
      this: (RBX *)"Cannot construct schema, too many enum types",
      a2: v33,
      a3: v30,
      a4: v31,
      a5: v34,
      a6: v35,
      a7: v36,
      a8: v37,
      a9: v38,
      a10: v39,
      a11: v40,
      a12: v41,
      a13: v42,
      a14: v43,
      a15: v454);
  v464 = 0; /*0x10679cb9c*/
  v465 = 0; /*0x10679cba3*/
  v46 = *(__int64 **)RBX::Reflection::ClassDescriptor::allClasses(this: v32); /*0x10679cbbd*/
  v47 = nullptr; /*0x10679cbc0*/
  for ( *((_QWORD *)&v48 + 1) = 0; ; *((_QWORD *)&v48 + 1) = v58 ) /*0x10679cbc3*/
  {
    v49 = v46 == *(__int64 **)(RBX::Reflection::ClassDescriptor::allClasses(this: v45) + 8); /*0x10679cbca*/
    v480 = *((char **)&v48 + 1); /*0x10679cbce*/
    if ( v49 ) /*0x10679cbd5*/
      break; /*0x10679cbd5*/
    v51 = *v46; /*0x10679cbdb*/
    if ( DFFlag::BlockEditableTypeReplication == 1 /*0x10679cc26*/
      && (*(_BYTE *)(v51 + 404) & 0x40) != 0
      && (*(_BYTE *)(v51 + 445) & 2) == 0
      || (Creator = RBX::Creatable::getCreator(this: *(RBX::Creatable **)(v51 + 8), a2: v50),
          v55 = *(_WORD *)(v51 + 444),
          LOBYTE(v56) = Creator != 0 && (v55 & 6) != 0,
          ((unsigned __int8)v56 | ((v55 & 0x200) != 0)) != 1) )
    {
      v58 = v480; /*0x10679cd08*/
    }
    else
    {
      memset(v485, 0, 88); /*0x10679cc4b*/
      v57 = v480; /*0x10679cc64*/
      if ( (unsigned __int64)v480 >= v465 ) /*0x10679cc6e*/
      {
        *(_QWORD *)&v478[1] = v46; /*0x10679cd14*/
        v60 = v480 - v47; /*0x10679cd1e*/
        v61 = 0x2E8BA2E8BA2E8BA3LL * ((v480 - v47) >> 3); /*0x10679cd32*/
        v62 = v61 + 1; /*0x10679cd36*/
        if ( (unsigned __int64)(v61 + 1) > 0x2E8BA2E8BA2E8BALL ) /*0x10679cd3d*/
          std::vector<RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo,std::allocator<RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo>>::__throw_length_error[abi:ne200100](); /*0x10679ea0f*/
        if ( 0x5D1745D1745D1746LL * ((__int64)(v465 - (_QWORD)v47) >> 3) > v62 ) /*0x10679cd55*/
          v62 = 0x5D1745D1745D1746LL * ((__int64)(v465 - (_QWORD)v47) >> 3); /*0x10679cd55*/
        if ( (unsigned __int64)(0x2E8BA2E8BA2E8BA3LL * ((__int64)(v465 - (_QWORD)v47) >> 3)) >= 0x1745D1745D1745DLL ) /*0x10679cd66*/
          v62 = 0x2E8BA2E8BA2E8BALL; /*0x10679cd66*/
        v483 = v47; /*0x10679cd6d*/
        v479 = v62; /*0x10679cd74*/
        if ( v62 != 0 ) /*0x10679cd7b*/
        {
          if ( v62 > 0x2E8BA2E8BA2E8BALL ) /*0x10679cd80*/
            std::__throw_bad_array_new_length[abi:ne200100](a1: v45, a2: v53, a3: v56, a4: 0x1745D1745D1745DLL, a5: v54); /*0x10679ea24*/
          v63 = operator new(a1: (RBX::Memory *)(88 * v62), a2: (unsigned __int64)v53); /*0x10679cd8f*/
        }
        else
        {
          v63 = 0; /*0x10679cd94*/
        }
        v64 = v63 + 88 * v61; /*0x10679cd9b*/
        *(_QWORD *)(v64 + 32) = 0; /*0x10679cda1*/
        *(_OWORD *)(v64 + 16) = 0; /*0x10679cda9*/
        *(_OWORD *)v64 = 0; /*0x10679cdaf*/
        memset(&v485[2], 0, 24); /*0x10679cdbf*/
        *(_QWORD *)(v64 + 56) = 0; /*0x10679cdc2*/
        *(_OWORD *)(v64 + 40) = 0; /*0x10679cdc7*/
        memset(&v485[5], 0, 24); /*0x10679cdd1*/
        *(_QWORD *)(v64 + 80) = 0; /*0x10679cdd5*/
        *(_OWORD *)(v64 + 64) = 0; /*0x10679cdda*/
        memset(&v485[8], 0, 24); /*0x10679cde4*/
        v65 = (RBX::Network *)(v64 - v60); /*0x10679cdeb*/
        v66 = (RBX::Memory *)v483; /*0x10679cdee*/
        v67 = v480; /*0x10679cdf5*/
        if ( v483 == v480 ) /*0x10679cdff*/
        {
          v46 = *(__int64 **)&v478[1]; /*0x10679ce55*/
        }
        else
        {
          v68 = (char *)v483; /*0x10679ce01*/
          j = v65; /*0x10679ce04*/
          v69 = v65; /*0x10679ce0b*/
          do /*0x10679ce24*/
          {
            std::allocator_traits<std::allocator<RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo>>::construct[abi:ne200100]<RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo,RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo,0>( /*0x10679ce14*/
              a1: v69,
              a2: v68);
            v68 += 88; /*0x10679ce19*/
            v69 = (RBX::Network *)((char *)v69 + 88); /*0x10679ce1d*/
          }
          while ( v68 != v67 ); /*0x10679ce24*/
          v70 = (char *)v483; /*0x10679ce26*/
          v46 = *(__int64 **)&v478[1]; /*0x10679ce2d*/
          do /*0x10679ce43*/
          {
            std::allocator_traits<std::allocator<RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo>>::destroy[abi:ne200100]<RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo,0>(a1: v70); /*0x10679ce37*/
            v70 += 88; /*0x10679ce3c*/
          }
          while ( v70 != v67 ); /*0x10679ce43*/
          v66 = (RBX::Memory *)v464; /*0x10679ce45*/
          v65 = j; /*0x10679ce4c*/
        }
        v58 = (char *)(v64 + 88); /*0x10679ce5c*/
        *(_QWORD *)&v464 = v65; /*0x10679ce6b*/
        *((_QWORD *)&v464 + 1) = v58; /*0x10679ce72*/
        v465 = 88 * v479 + v63; /*0x10679ce79*/
        if ( v66 != nullptr ) /*0x10679ce8d*/
          operator delete(a1: v66, a2: v53); /*0x10679ce8f*/
        v59 = (RBX::Memory *)v485[8]; /*0x10679ce94*/
      }
      else
      {
        *((_OWORD *)v480 + 1) = 0; /*0x10679cc74*/
        *(_OWORD *)v57 = 0; /*0x10679cc7a*/
        *((_QWORD *)v57 + 4) = 0; /*0x10679cc81*/
        *((_OWORD *)v57 + 1) = *(_OWORD *)&v485[2]; /*0x10679cc8d*/
        *((void **)v57 + 4) = v485[4]; /*0x10679cc9a*/
        memset(&v485[2], 0, 24); /*0x10679ccaa*/
        *((_QWORD *)v57 + 7) = 0; /*0x10679ccad*/
        *(_OWORD *)(v57 + 40) = 0; /*0x10679ccb2*/
        *(_OWORD *)(v57 + 40) = *(_OWORD *)&v485[5]; /*0x10679ccbf*/
        *((void **)v57 + 7) = v485[7]; /*0x10679cccc*/
        memset(&v485[5], 0, 24); /*0x10679ccd5*/
        *((_QWORD *)v57 + 10) = 0; /*0x10679ccd9*/
        *((_OWORD *)v57 + 4) = 0; /*0x10679ccde*/
        qmemcpy(v57 + 64, &v485[8], 24); /*0x10679cceb*/
        v58 = v57 + 88; /*0x10679ccfd*/
        v59 = nullptr; /*0x10679cd01*/
      }
      *((_QWORD *)&v464 + 1) = v58; /*0x10679ce9b*/
      if ( v59 != nullptr ) /*0x10679cea5*/
        operator delete(a1: v59, a2: v53); /*0x10679cea7*/
      if ( v485[5] != nullptr ) /*0x10679ceb6*/
        operator delete(a1: (RBX::Memory *)v485[5], a2: v53); /*0x10679ceb8*/
      v45 = (RBX::Reflection::ClassDescriptor *)v485[2]; /*0x10679cebd*/
      if ( v485[2] != nullptr ) /*0x10679cec7*/
        operator delete(a1: (RBX::Memory *)v485[2], a2: v53); /*0x10679cec9*/
      *((_QWORD *)v58 - 10) = *v46; /*0x10679ced1*/
      v47 = (_BYTE *)v464; /*0x10679ced6*/
      *((_DWORD *)v58 - 22) = -1171354717 * ((unsigned __int64)&v58[-v464] >> 3) - 1; /*0x10679ceef*/
    }
    ++v46; /*0x10679cef4*/
  }
  v478[0] = 0; /*0x10679cf00*/
  v472 = (_QWORD *)RBX::Subsystem<RBX::Network::NetAssetManagerFactories,false>::startup<RBX::SubsystemDefaultFactory<RBX::Network::NetAssetManagerFactories>>(); /*0x10679cf0f*/
  v478[1] = (unsigned __int8)v468; /*0x10679cf1d*/
  v83 = v47; /*0x10679cf23*/
  if ( v47 == *((_BYTE **)&v48 + 1) ) /*0x10679cf29*/
  {
    v84 = nullptr; /*0x10679d2ed*/
    __src = nullptr; /*0x10679d2f0*/
    LODWORD(j) = 0; /*0x10679d2fb*/
    *(_QWORD *)v473 = 0; /*0x10679d305*/
    *(_QWORD *)&v48 = v83; /*0x10679d310*/
    goto LABEL_97; /*0x10679d310*/
  }
  *(_QWORD *)v473 = 0; /*0x10679cf2f*/
  LODWORD(j) = 0; /*0x10679cf48*/
  __src = nullptr; /*0x10679cf52*/
  v84 = nullptr; /*0x10679cf5d*/
  v469 = nullptr; /*0x10679cf60*/
  do
  {
    v483 = v83; /*0x10679cf6b*/
    v471 = (char *)v83[1]; /*0x10679cf76*/
    RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::PropertyDescriptor>::MemberDescriptorContainerV2Iterator( /*0x10679cf84*/
      a1: v485,
      a2: v471 + 40);
    RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::PropertyDescriptor>::MemberDescriptorContainerV2Iterator( /*0x10679cf92*/
      a1: &v474,
      a2: 0);
    v479 = (unsigned __int64)v483 + 16; /*0x10679cfa2*/
    v468 = (char *)v483 + 64; /*0x10679cfad*/
    while ( (unsigned __int8)RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::PropertyDescriptor>::operator==(
                               a1: v485,
                               a2: &v474) == 0 )
    {
      v466[0] = (void *)RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::PropertyDescriptor>::operator*(a1: v485); /*0x10679cfd3*/
      if ( (unsigned __int8)RBX::Network::Replicator::canReplicateProperty(a1: v478[1], a2: v466[0], a3: 1) == 0 ) /*0x10679cfef*/
        goto LABEL_63; /*0x10679cfef*/
      if ( (*((_BYTE *)v466[0] + 139) & 0x40) != 0 )
      {
        v88 = v84; /*0x10679d069*/
        v89 = (*(__int64 (__fastcall **)(void *))(*(_QWORD *)v466[0] + 80LL))(a1: v466[0]); /*0x10679d06f*/
        if ( (unsigned __int16)(v89 - 1) > 0xAu
          || (v90 = v89,
              v91 = (unsigned int)v89 - 1,
              v92 = *(_QWORD *)(*(_QWORD *)&v457[8] + 8LL * ((unsigned int)v91 >> 6)),
              _bittest64(&v92, v91))
          || (v472 == nullptr ? (v93 = nullptr) : (v93 = (RBX::Network::NetAssetManagerFactories *)v472[3]),
              RBX::Network::NetAssetManagerFactories::getLoader(this: v93, a2: v90) == 0) )
        {
          v84 = v88; /*0x10679d099*/
          goto LABEL_63; /*0x10679d099*/
        }
        v94 = *(_QWORD *)v456; /*0x10679d0d1*/
        if ( !_bittest64(&v94, v90) ) /*0x10679d0e3*/
        {
          *(_QWORD *)v456 = (1LL << v90) | v94; /*0x10679d0e8*/
          *(_QWORD *)v473 = v473[0] + 1; /*0x10679d0f4*/
        }
        v84 = v88; /*0x10679d0fb*/
      }
      else if ( *(_DWORD *)(*((_QWORD *)v466[0] + 13) + 48LL) == 94 ) /*0x10679d00d*/
      {
        goto LABEL_63; /*0x10679d00d*/
      }
      std::vector<RBX::Reflection::PropertyDescriptor const*>::push_back[abi:ne200100](a1: v479, a2: v466); /*0x10679d021*/
      *(_QWORD *)&v476 = *v467; /*0x10679d037*/
      if ( RBX::Network::InstanceReplication::InstanceStateReplicationBridge::isPropertyNextGenRepProperty( /*0x10679d04c*/
             a1: (RBX::Network::InstanceReplication::InstanceStateReplicationBridge *)v466[0],
             a2: (const RBX::Reflection::PropertyDescriptor *)&v476) != 0 )
        std::vector<unsigned int>::push_back[abi:ne200100](a1: v468, a2: v478, a3: v87); /*0x10679d05c*/
      ++v478[0]; /*0x10679d061*/
LABEL_63:
      RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::PropertyDescriptor>::operator++(a1: v485); /*0x10679d09c*/
    }
    if ( *((_QWORD *)v483 + 9) != *((_QWORD *)v483 + 8) ) /*0x10679d112*/
    {
      if ( v84 >= v469 ) /*0x10679d11f*/
      {
        v95 = v84 - (_BYTE *)__src; /*0x10679d13b*/
        v96 = v95 >> 3; /*0x10679d141*/
        v97 = (v95 >> 3) + 1; /*0x10679d145*/
        if ( v97 > 0x1FFFFFFFFFFFFFFFLL ) /*0x10679d156*/
          std::vector<RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo *,std::allocator<RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo *>>::__throw_length_error[abi:ne200100](); /*0x10679ea16*/
        v98 = v469 - (_BYTE *)__src; /*0x10679d163*/
        v99 = (v469 - (_BYTE *)__src) >> 2; /*0x10679d169*/
        if ( v99 <= v97 ) /*0x10679d170*/
          v99 = (v95 >> 3) + 1; /*0x10679d170*/
        if ( v98 >= 0x7FFFFFFFFFFFFFF8LL ) /*0x10679d181*/
          v99 = 0x1FFFFFFFFFFFFFFFLL; /*0x10679d181*/
        __n = v95; /*0x10679d188*/
        if ( v99 != 0 ) /*0x10679d18f*/
        {
          if ( v99 > 0x1FFFFFFFFFFFFFFFLL ) /*0x10679d194*/
            std::__throw_bad_array_new_length[abi:ne200100]( /*0x10679ea2b*/
              a1: v85,
              a2: v98,
              a3: 0x1FFFFFFFFFFFFFFFLL,
              a4: __src,
              a5: v86);
          v100 = (_QWORD *)operator new(a1: (RBX::Memory *)(8 * v99), a2: v98); /*0x10679d1a7*/
        }
        else
        {
          v100 = nullptr; /*0x10679d1ac*/
        }
        v469 = (char *)&v100[v99]; /*0x10679d1b3*/
        v101 = (__int64)&v100[v96 + 1]; /*0x10679d1be*/
        v100[v96] = v483; /*0x10679d1c9*/
        v102 = (RBX::Memory *)__src; /*0x10679d1d1*/
        memcpy(__dst: v100, __src, __n); /*0x10679d1e2*/
        if ( v102 != nullptr ) /*0x10679d1ea*/
          operator delete(a1: v102, a2: v103); /*0x10679d1ef*/
        __src = v100; /*0x10679d1f4*/
        v84 = (char *)v101; /*0x10679d1fb*/
      }
      else
      {
        *(_QWORD *)v84 = v483; /*0x10679d128*/
        v84 += 8; /*0x10679d12b*/
      }
    }
    RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::EventDescriptor>::MemberDescriptorContainerV2Iterator( /*0x10679d213*/
      a1: v485,
      a2: v471 + 112);
    RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::EventDescriptor>::MemberDescriptorContainerV2Iterator( /*0x10679d221*/
      a1: &v474,
      a2: 0);
    v479 = (unsigned __int64)v483 + 40; /*0x10679d231*/
    while ( (unsigned __int8)RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::EventDescriptor>::operator==( /*0x10679d249*/
                               a1: v485,
                               a2: &v474) == 0 )
    {
      v466[0] = (void *)RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::EventDescriptor>::operator*(a1: v485); /*0x10679d253*/
      v105 = *((_QWORD *)v466[0] + 9); /*0x10679d25a*/
      v106 = *((_QWORD *)v466[0] + 10); /*0x10679d25e*/
      if ( v105 == v106 ) /*0x10679d265*/
        goto LABEL_92; /*0x10679d265*/
      v107 = v84; /*0x10679d267*/
      v108 = 1; /*0x10679d26a*/
      do /*0x10679d28b*/
      {
        v108 &= (RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType( /*0x10679d281*/
                   a1: *(_QWORD *)(v105 + 8),
                   a2: (__int64)v484,
                   a3: v104)
               & 0xFF00) != 0;
        v105 += 112; /*0x10679d284*/
      }
      while ( v105 != v106 ); /*0x10679d28b*/
      v49 = v108 == 0; /*0x10679d28d*/
      v84 = v107; /*0x10679d290*/
      *((_QWORD *)&v48 + 1) = v480; /*0x10679d293*/
      if ( !v49 ) /*0x10679d29a*/
      {
LABEL_92:
        std::vector<RBX::Reflection::EventDescriptor const*>::push_back[abi:ne200100](a1: v479, a2: v466); /*0x10679d2aa*/
        LODWORD(j) = (_DWORD)j + 1; /*0x10679d2af*/
      }
      RBX::Reflection::MemberDescriptorContainerV2Iterator<RBX::Reflection::EventDescriptor>::operator++(a1: v485); /*0x10679d2bf*/
    }
    v83 = (char *)v483 + 88; /*0x10679d2d0*/
  }
  while ( (char *)v483 + 88 != *((void **)&v48 + 1) );
  v48 = v464; /*0x10679d2dd*/
LABEL_97:
  v480 = *((char **)&v48 + 1); /*0x10679d313*/
  v109 = -1171354717 * ((*((_QWORD *)&v48 + 1) - (_QWORD)v48) >> 3); /*0x10679d324*/
  if ( v109 > 0xFFFE || v478[0] > 0xFFFEu || (unsigned int)j > 0xFFFE ) /*0x10679d350*/
    RBX::throw_runtime_error( /*0x10679ea5b*/
      this: (RBX *)"Cannot construct schema, too many classes, properties, or events",
      a2: v72,
      a3: v71,
      a4: v48,
      a5: v73,
      a6: v74,
      a7: v75,
      a8: v76,
      a9: v77,
      a10: v78,
      a11: v79,
      a12: v80,
      a13: v81,
      a14: v82,
      a15: v454);
  v110 = (char *)v48; /*0x10679d356*/
  if ( (char *)v48 != v480 ) /*0x10679d360*/
  {
    v111 = (char *)v48; /*0x10679d362*/
    do /*0x10679d385*/
    {
      v112 = *((_QWORD *)v111 + 3) - *((_QWORD *)v111 + 2); /*0x10679d369*/
      if ( v112 >= 0x7F9 ) /*0x10679d374*/
      {
        v452 = *(_QWORD *)(*((_QWORD *)v111 + 1) + 8LL); /*0x10679e9d6*/
        if ( (*(_BYTE *)v452 & 1) != 0 ) /*0x10679e9dd*/
          v453 = *(const char **)(v452 + 16); /*0x10679e9e4*/
        else
          v453 = (const char *)(v452 + 1); /*0x10679e9df*/
        RBX::throw_runtime_error( /*0x10679e9f1*/
          this: (RBX *)"Cannot construct schema, too many properties for %s",
          a2: v453,
          a3: v71,
          a4: v112,
          a5: v73,
          a6: v74,
          a7: v75,
          a8: v76,
          a9: v77,
          a10: v78,
          a11: v79,
          a12: v80,
          a13: v81,
          a14: v82,
          a15: v454);
      }
      v111 += 88; /*0x10679d37a*/
    }
    while ( v111 != v480 ); /*0x10679d385*/
  }
  if ( (*(_QWORD *)v456 & 0x80u) == 0LL ) /*0x10679d393*/
  {
    *(_QWORD *)v456 |= 0x80uLL; /*0x10679d39c*/
    *(_QWORD *)v473 = v473[0] + 1; /*0x10679d3a8*/
  }
  __n = (size_t)v84; /*0x10679d3af*/
  std::vector<unsigned short>::vector[abi:ne200100]( /*0x10679d3c9*/
    a1: v466,
    a2: 11,
    a3: &RBX::Network::NetworkSchemaTypes::kInvalidNetworkId);
  v114 = 0; /*0x10679d3ce*/
  for ( i = 1; i != 12; ++i ) /*0x10679d3d1*/
  {
    v116 = *(_QWORD *)v456; /*0x10679d3de*/
    if ( _bittest64(&v116, i) ) /*0x10679d3e1*/
    {
      *((_WORD *)v466[0] + i - 1) = v114; /*0x10679d3ee*/
      if ( v472 != nullptr ) /*0x10679d3fe*/
        v117 = (RBX::Network::NetAssetManagerFactories *)v472[3]; /*0x10679d400*/
      else
        v117 = nullptr; /*0x10679d406*/
      DeltaTypeForType = RBX::Network::NetAssetManagerFactories::getDeltaTypeForType(this: v117, a2: i); /*0x10679d40c*/
      v119 = v114 + 1; /*0x10679d411*/
      if ( DeltaTypeForType != 0 ) /*0x10679d418*/
      {
        v114 += 2; /*0x10679d41a*/
        v113 = (RBX::Network::NetworkStream *)v466[0]; /*0x10679d423*/
        *((_WORD *)v466[0] + (unsigned int)DeltaTypeForType - 1) = v119; /*0x10679d42a*/
      }
      else
      {
        ++v114; /*0x10679d430*/
      }
    }
  }
  RBX::Network::serializeUnsignedVarint(this: (RBX::Network *)v109, a2: (unsigned __int64)v458, a3: v113); /*0x10679d445*/
  RBX::Network::serializeUnsignedVarint(this: (RBX::Network *)v478[0], a2: (unsigned __int64)v458, a3: v120); /*0x10679d457*/
  RBX::Network::serializeUnsignedVarint(this: (RBX::Network *)(unsigned int)j, a2: (unsigned __int64)v458, a3: v121); /*0x10679d469*/
  if ( v110 != v480 ) /*0x10679d475*/
  {
    v123 = v110; /*0x10679d47b*/
    v469 = (char *)(v463 + 80); /*0x10679d489*/
    v468 = (char *)RBX::BasePartProperties::prop_CFrame; /*0x10679d49a*/
    LODWORD(v479) = 0; /*0x10679d4a1*/
    do /*0x10679d718*/
    {
      RBX::Network::serializeString( /*0x10679d4c6*/
        a1: *(unsigned __int8 **)(*((_QWORD *)v123 + 1) + 8LL),
        a2: (RBX::Network::NetworkStream *)v458,
        a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
      RBX::Network::serializeUnsignedVarint( /*0x10679d4da*/
        this: (RBX::Network *)((*((_QWORD *)v123 + 3) - *((_QWORD *)v123 + 2)) >> 3),
        a2: (unsigned __int64)v458,
        a3: v124);
      v125 = *((__int64 **)v123 + 2); /*0x10679d4df*/
      j = *((RBX::Network **)v123 + 3); /*0x10679d4e7*/
      v483 = v123; /*0x10679d4f1*/
      if ( v125 == (__int64 *)j ) /*0x10679d4f8*/
      {
        v126 = -1; /*0x10679d60c*/
      }
      else
      {
        v471 = v123 + 8; /*0x10679d502*/
        v126 = -1; /*0x10679d509*/
        do /*0x10679d604*/
        {
          RBX::Network::serializeString( /*0x10679d522*/
            a1: *(unsigned __int8 **)(*v125 + 8),
            a2: (RBX::Network::NetworkStream *)v458,
            a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
          LOBYTE(v474) = 0; /*0x10679d527*/
          v128 = RBX::Network::NetworkSchema::typeForProperty( /*0x10679d54b*/
                   a1: v127,
                   a2: *v125,
                   a3: v478[1],
                   a4: (__int64)v484,
                   a5: &v474);
          LOBYTE(v485[0]) = BYTE1(v128); /*0x10679d555*/
          RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v458, a2: v485, a3: 1u); /*0x10679d56b*/
          if ( BYTE1(v128) == 60 ) /*0x10679d574*/
          {
            v129 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)*v125 + 80LL))(a1: *v125); /*0x10679d5a6*/
            RBX::Network::NetworkStream::writeUInt32VarInt( /*0x10679d5bb*/
              this: (RBX::Network::NetworkStream *)v458,
              a2: *((unsigned __int16 *)v466[0] + v129 - 1));
          }
          else if ( BYTE1(v128) == 7 ) /*0x10679d57d*/
          {
            LOWORD(v485[0]) = HIWORD(v128); /*0x10679d582*/
            RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v458, a2: v485, a3: 2u); /*0x10679d598*/
          }
          if ( (_BYTE)v474 == 1 ) /*0x10679d5c7*/
            RBX::DenseHashSet<RBX::Reflection::ClassDescriptor const*,RBX::Hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>::insert( /*0x10679d5d7*/
              a1: v469,
              a2: (__int64)v471);
          if ( (char *)*v125 == v468 ) /*0x10679d5ed*/
            v126 = v479; /*0x10679d5ed*/
          LODWORD(v479) = v479 + 1; /*0x10679d5f3*/
          ++v125; /*0x10679d5f9*/
        }
        while ( v125 != (__int64 *)j ); /*0x10679d604*/
      }
      LOWORD(v485[0]) = v126; /*0x10679d611*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v458, a2: v485, a3: 2u); /*0x10679d628*/
      v130 = v483; /*0x10679d62d*/
      RBX::Network::serializeUnsignedVarint( /*0x10679d643*/
        this: (RBX::Network *)((*((_QWORD *)v483 + 6) - *((_QWORD *)v483 + 5)) >> 3),
        a2: (unsigned __int64)v458,
        a3: v131);
      v132 = *((RBX::Network **)v130 + 5); /*0x10679d648*/
      for ( j = *((RBX::Network **)v130 + 6); v132 != j; v132 = (RBX::Network *)((char *)v132 + 8) ) /*0x10679d65a*/
      {
        RBX::Network::serializeString( /*0x10679d674*/
          a1: *(unsigned __int8 **)(*(_QWORD *)v132 + 8LL),
          a2: (RBX::Network::NetworkStream *)v458,
          a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
        v133 = *(_QWORD *)v132; /*0x10679d679*/
        RBX::Network::serializeUnsignedVarint( /*0x10679d692*/
          this: (RBX::Network *)(-1227133513
                         * (unsigned int)((*(_QWORD *)(*(_QWORD *)v132 + 80LL) - *(_QWORD *)(*(_QWORD *)v132 + 72LL)) >> 4)),
          a2: (unsigned __int64)v458,
          a3: v134);
        v135 = *(_QWORD *)(v133 + 72); /*0x10679d697*/
        v136 = *(_QWORD *)(v133 + 80); /*0x10679d69b*/
        while ( v135 != v136 ) /*0x10679d6a2*/
        {
          v137 = RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType( /*0x10679d6af*/
                   a1: *(_QWORD *)(v135 + 8),
                   a2: (__int64)v484,
                   a3: (__int64)v122);
          v138 = WORD1(v137); /*0x10679d6b4*/
          LOBYTE(v485[0]) = BYTE1(v137); /*0x10679d6b7*/
          RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v458, a2: v485, a3: 1u); /*0x10679d6cc*/
          LOWORD(v485[0]) = v138; /*0x10679d6d4*/
          RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v458, a2: v485, a3: 2u); /*0x10679d6ea*/
          v135 += 112; /*0x10679d6ef*/
        }
      }
      v123 = (char *)v483 + 88; /*0x10679d70d*/
    }
    while ( (char *)v483 + 88 != v480 ); /*0x10679d718*/
  }
  RBX::Network::serializeUnsignedVarint(this: (RBX::Network *)0x1A, a2: (unsigned __int64)v458, a3: v122); /*0x10679d72a*/
  for ( k = 0; k != 52; k += 2 ) /*0x10679d72f*/
    RBX::Network::serializeRbxStringView( /*0x10679d750*/
      a1: (__int64)&(&RBX::Network::knownPrefixes)[k],
      a2: (RBX::Network::NetworkStream *)v458,
      a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
  std::string::basic_string[abi:ne200100]<0>(a1: v485, a2: "AccessoryWeld", a3: v140, a4: v141); /*0x10679d770*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v485[3], a2: "Animate", a3: v142, a4: v143); /*0x10679d786*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v485[6], a2: "Animation", a3: v144, a4: v145); /*0x10679d79c*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v485[9], a2: "Animation1", a3: v146, a4: v147); /*0x10679d7b2*/
  std::string::basic_string[abi:ne200100]<0>(a1: v486, a2: "Animation2", a3: v148, a4: v149); /*0x10679d7c8*/
  std::string::basic_string[abi:ne200100]<0>(a1: v487, a2: "Animation3", a3: v150, a4: v151); /*0x10679d7de*/
  std::string::basic_string[abi:ne200100]<0>(a1: v488, a2: "AvatarPartScaleType", a3: v152, a4: v153); /*0x10679d7f4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v489, a2: "BodyBackAttachment", a3: v154, a4: v155); /*0x10679d80a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v490, a2: "BodyDepthScale", a3: v156, a4: v157); /*0x10679d820*/
  std::string::basic_string[abi:ne200100]<0>(a1: v491, a2: "BodyFrontAttachment", a3: v158, a4: v159); /*0x10679d836*/
  std::string::basic_string[abi:ne200100]<0>(a1: v492, a2: "BodyHeightScale", a3: v160, a4: v161); /*0x10679d84c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v493, a2: "BodyProportionScale", a3: v162, a4: v163); /*0x10679d862*/
  std::string::basic_string[abi:ne200100]<0>(a1: v494, a2: "BodyScales", a3: v164, a4: v165); /*0x10679d878*/
  std::string::basic_string[abi:ne200100]<0>(a1: v495, a2: "BodyTypeScale", a3: v166, a4: v167); /*0x10679d88e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v496, a2: "BodyWidthScale", a3: v168, a4: v169); /*0x10679d8a4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v497, a2: "CheerAnim", a3: v170, a4: v171); /*0x10679d8ba*/
  std::string::basic_string[abi:ne200100]<0>(a1: v498, a2: "ClimbAnim", a3: v172, a4: v173); /*0x10679d8d0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v499, a2: "Climbing", a3: v174, a4: v175); /*0x10679d8e6*/
  std::string::basic_string[abi:ne200100]<0>(a1: v500, a2: "Died", a3: v176, a4: v177); /*0x10679d8fc*/
  std::string::basic_string[abi:ne200100]<0>(a1: v501, a2: "EmitterSize", a3: v178, a4: v179); /*0x10679d912*/
  std::string::basic_string[abi:ne200100]<0>(a1: v502, a2: "FaceCenterAttachment", a3: v180, a4: v181); /*0x10679d928*/
  std::string::basic_string[abi:ne200100]<0>(a1: v503, a2: "FaceFrontAttachment", a3: v182, a4: v183); /*0x10679d93e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v504, a2: "FallAnim", a3: v184, a4: v185); /*0x10679d954*/
  std::string::basic_string[abi:ne200100]<0>(a1: v505, a2: "Fired", a3: v186, a4: v187); /*0x10679d96a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v506, a2: "FreeFalling", a3: v188, a4: v189); /*0x10679d980*/
  std::string::basic_string[abi:ne200100]<0>(a1: v507, a2: "GettingUp", a3: v190, a4: v191); /*0x10679d996*/
  std::string::basic_string[abi:ne200100]<0>(a1: v508, a2: "HairAttachment", a3: v192, a4: v193); /*0x10679d9ac*/
  std::string::basic_string[abi:ne200100]<0>(a1: v509, a2: "Handle", a3: v194, a4: v195); /*0x10679d9c2*/
  std::string::basic_string[abi:ne200100]<0>(a1: v510, a2: "HandleAttachment", a3: v196, a4: v197); /*0x10679d9d8*/
  std::string::basic_string[abi:ne200100]<0>(a1: v511, a2: "HandleWeld", a3: v198, a4: v199); /*0x10679d9ee*/
  std::string::basic_string[abi:ne200100]<0>(a1: v512, a2: "HatAttachment", a3: v200, a4: v201); /*0x10679da04*/
  std::string::basic_string[abi:ne200100]<0>(a1: v513, a2: "Head", a3: v202, a4: v203); /*0x10679da1a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v514, a2: "Health", a3: v204, a4: v205); /*0x10679da30*/
  std::string::basic_string[abi:ne200100]<0>(a1: v515, a2: "HumanoidRootPart", a3: v206, a4: v207); /*0x10679da46*/
  std::string::basic_string[abi:ne200100]<0>(a1: v516, a2: "JumpAnim", a3: v208, a4: v209); /*0x10679da5c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v517, a2: "Jumping", a3: v210, a4: v211); /*0x10679da72*/
  std::string::basic_string[abi:ne200100]<0>(a1: v518, a2: "Landing", a3: v212, a4: v213); /*0x10679da88*/
  std::string::basic_string[abi:ne200100]<0>(a1: v519, a2: "LaughAnim", a3: v214, a4: v215); /*0x10679da9e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v520, a2: "LeftAnkle", a3: v216, a4: v217); /*0x10679dab4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v521, a2: "LeftAnkleRigAttachment", a3: v218, a4: v219); /*0x10679daca*/
  std::string::basic_string[abi:ne200100]<0>(a1: v522, a2: "LeftCollarAttachment", a3: v220, a4: v221); /*0x10679dae0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v523, a2: "LeftElbow", a3: v222, a4: v223); /*0x10679daf6*/
  std::string::basic_string[abi:ne200100]<0>(a1: v524, a2: "LeftElbowRigAttachment", a3: v224, a4: v225); /*0x10679db0c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v525, a2: "LeftFoot", a3: v226, a4: v227); /*0x10679db22*/
  std::string::basic_string[abi:ne200100]<0>(a1: v526, a2: "LeftGripAttachment", a3: v228, a4: v229); /*0x10679db38*/
  std::string::basic_string[abi:ne200100]<0>(a1: v527, a2: "LeftHand", a3: v230, a4: v231); /*0x10679db4e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v528, a2: "LeftHip", a3: v232, a4: v233); /*0x10679db64*/
  std::string::basic_string[abi:ne200100]<0>(a1: v529, a2: "LeftHipRigAttachment", a3: v234, a4: v235); /*0x10679db7a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v530, a2: "LeftKnee", a3: v236, a4: v237); /*0x10679db90*/
  std::string::basic_string[abi:ne200100]<0>(a1: v531, a2: "LeftKneeRigAttachment", a3: v238, a4: v239); /*0x10679dba6*/
  std::string::basic_string[abi:ne200100]<0>(a1: v532, a2: "LeftLowerArm", a3: v240, a4: v241); /*0x10679dbbc*/
  std::string::basic_string[abi:ne200100]<0>(a1: v533, a2: "LeftLowerLeg", a3: v242, a4: v243); /*0x10679dbd2*/
  std::string::basic_string[abi:ne200100]<0>(a1: v534, a2: "LeftShoulder", a3: v244, a4: v245); /*0x10679dbe8*/
  std::string::basic_string[abi:ne200100]<0>(a1: v535, a2: "LeftShoulderAttachment", a3: v246, a4: v247); /*0x10679dbfe*/
  std::string::basic_string[abi:ne200100]<0>(a1: v536, a2: "LeftShoulderRigAttachment", a3: v248, a4: v249); /*0x10679dc14*/
  std::string::basic_string[abi:ne200100]<0>(a1: v537, a2: "LeftUpperArm", a3: v250, a4: v251); /*0x10679dc2a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v538, a2: "LeftUpperLeg", a3: v252, a4: v253); /*0x10679dc40*/
  std::string::basic_string[abi:ne200100]<0>(a1: v539, a2: "LeftWrist", a3: v254, a4: v255); /*0x10679dc56*/
  std::string::basic_string[abi:ne200100]<0>(a1: v540, a2: "LeftWristRigAttachment", a3: v256, a4: v257); /*0x10679dc6c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v541, a2: "Looped", a3: v258, a4: v259); /*0x10679dc82*/
  std::string::basic_string[abi:ne200100]<0>(a1: v542, a2: "LowerTorso", a3: v260, a4: v261); /*0x10679dc98*/
  std::string::basic_string[abi:ne200100]<0>(a1: v543, a2: "Material", a3: v262, a4: v263); /*0x10679dcae*/
  std::string::basic_string[abi:ne200100]<0>(a1: v544, a2: "MaterialTexture", a3: v264, a4: v265); /*0x10679dcc4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v545, a2: "MaxDistance", a3: v266, a4: v267); /*0x10679dcda*/
  std::string::basic_string[abi:ne200100]<0>(a1: v546, a2: "Neck", a3: v268, a4: v269); /*0x10679dcf0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v547, a2: "NeckAttachment", a3: v270, a4: v271); /*0x10679dd06*/
  std::string::basic_string[abi:ne200100]<0>(a1: v548, a2: "NeckRigAttachment", a3: v272, a4: v273); /*0x10679dd1c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v549, a2: "Object", a3: v274, a4: v275); /*0x10679dd32*/
  std::string::basic_string[abi:ne200100]<0>(a1: v550, a2: "OriginalPosition", a3: v276, a4: v277); /*0x10679dd48*/
  std::string::basic_string[abi:ne200100]<0>(a1: v551, a2: "OriginalSize", a3: v278, a4: v279); /*0x10679dd5e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v552, a2: "Part", a3: v280, a4: v281); /*0x10679dd74*/
  std::string::basic_string[abi:ne200100]<0>(a1: v553, a2: "PlayEmote", a3: v282, a4: v283); /*0x10679dd8a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v554, a2: "PlaybackSpeed", a3: v284, a4: v285); /*0x10679dda0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v555, a2: "PointAnim", a3: v286, a4: v287); /*0x10679ddb6*/
  std::string::basic_string[abi:ne200100]<0>(a1: v556, a2: "RagdollBallSocketConstraint", a3: v288, a4: v289); /*0x10679ddcc*/
  std::string::basic_string[abi:ne200100]<0>(a1: v557, a2: "RagdollNoCollisionConstraint", a3: v290, a4: v291); /*0x10679dde2*/
  std::string::basic_string[abi:ne200100]<0>(a1: v558, a2: "RightAnkle", a3: v292, a4: v293); /*0x10679ddf8*/
  std::string::basic_string[abi:ne200100]<0>(a1: v559, a2: "RightAnkleRigAttachment", a3: v294, a4: v295); /*0x10679de0e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v560, a2: "RightCollarAttachment", a3: v296, a4: v297); /*0x10679de24*/
  std::string::basic_string[abi:ne200100]<0>(a1: v561, a2: "RightElbow", a3: v298, a4: v299); /*0x10679de3a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v562, a2: "RightElbowRigAttachment", a3: v300, a4: v301); /*0x10679de50*/
  std::string::basic_string[abi:ne200100]<0>(a1: v563, a2: "RightFoot", a3: v302, a4: v303); /*0x10679de66*/
  std::string::basic_string[abi:ne200100]<0>(a1: v564, a2: "RightGrip", a3: v304, a4: v305); /*0x10679de7c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v565, a2: "RightGripAttachment", a3: v306, a4: v307); /*0x10679de92*/
  std::string::basic_string[abi:ne200100]<0>(a1: v566, a2: "RightHand", a3: v308, a4: v309); /*0x10679dea8*/
  std::string::basic_string[abi:ne200100]<0>(a1: v567, a2: "RightHip", a3: v310, a4: v311); /*0x10679debe*/
  std::string::basic_string[abi:ne200100]<0>(a1: v568, a2: "RightHipRigAttachment", a3: v312, a4: v313); /*0x10679ded4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v569, a2: "RightKnee", a3: v314, a4: v315); /*0x10679deea*/
  std::string::basic_string[abi:ne200100]<0>(a1: v570, a2: "RightKneeRigAttachment", a3: v316, a4: v317); /*0x10679df00*/
  std::string::basic_string[abi:ne200100]<0>(a1: v571, a2: "RightLowerArm", a3: v318, a4: v319); /*0x10679df16*/
  std::string::basic_string[abi:ne200100]<0>(a1: v572, a2: "RightLowerLeg", a3: v320, a4: v321); /*0x10679df2c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v573, a2: "RightShoulder", a3: v322, a4: v323); /*0x10679df42*/
  std::string::basic_string[abi:ne200100]<0>(a1: v574, a2: "RightShoulderAttachment", a3: v324, a4: v325); /*0x10679df58*/
  std::string::basic_string[abi:ne200100]<0>(a1: v575, a2: "RightShoulderRigAttachment", a3: v326, a4: v327); /*0x10679df6e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v576, a2: "RightUpperArm", a3: v328, a4: v329); /*0x10679df84*/
  std::string::basic_string[abi:ne200100]<0>(a1: v577, a2: "RightUpperLeg", a3: v330, a4: v331); /*0x10679df9a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v578, a2: "RightWrist", a3: v332, a4: v333); /*0x10679dfb0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v579, a2: "RightWristRigAttachment", a3: v334, a4: v335); /*0x10679dfc6*/
  std::string::basic_string[abi:ne200100]<0>(a1: v580, a2: "Root", a3: v336, a4: v337); /*0x10679dfdc*/
  std::string::basic_string[abi:ne200100]<0>(a1: v581, a2: "RootPart", a3: v338, a4: v339); /*0x10679dff2*/
  std::string::basic_string[abi:ne200100]<0>(a1: v582, a2: "RootRigAttachment", a3: v340, a4: v341); /*0x10679e008*/
  std::string::basic_string[abi:ne200100]<0>(a1: v583, a2: "RunAnim", a3: v342, a4: v343); /*0x10679e01e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v584, a2: "Running", a3: v344, a4: v345); /*0x10679e034*/
  std::string::basic_string[abi:ne200100]<0>(a1: v585, a2: "ScaleDampeningPercent", a3: v346, a4: v347); /*0x10679e04a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v586, a2: "SeatAttach", a3: v348, a4: v349); /*0x10679e060*/
  std::string::basic_string[abi:ne200100]<0>(a1: v587, a2: "SitAnim", a3: v350, a4: v351); /*0x10679e076*/
  std::string::basic_string[abi:ne200100]<0>(a1: v588, a2: "Sound", a3: v352, a4: v353); /*0x10679e08c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v589, a2: "Swim", a3: v354, a4: v355); /*0x10679e0a2*/
  std::string::basic_string[abi:ne200100]<0>(a1: v590, a2: "SwimIdle", a3: v356, a4: v357); /*0x10679e0b8*/
  std::string::basic_string[abi:ne200100]<0>(a1: v591, a2: "Swimming", a3: v358, a4: v359); /*0x10679e0ce*/
  std::string::basic_string[abi:ne200100]<0>(a1: v592, a2: "TipAttachment", a3: v360, a4: v361); /*0x10679e0e4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v593, a2: "UpperTorso", a3: v362, a4: v363); /*0x10679e0fa*/
  std::string::basic_string[abi:ne200100]<0>(a1: v594, a2: "Volume", a3: v364, a4: v365); /*0x10679e110*/
  std::string::basic_string[abi:ne200100]<0>(a1: v595, a2: "Waist", a3: v366, a4: v367); /*0x10679e126*/
  std::string::basic_string[abi:ne200100]<0>(a1: v596, a2: "WaistBackAttachment", a3: v368, a4: v369); /*0x10679e13c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v597, a2: "WaistCenterAttachment", a3: v370, a4: v371); /*0x10679e152*/
  std::string::basic_string[abi:ne200100]<0>(a1: v598, a2: "WaistFrontAttachment", a3: v372, a4: v373); /*0x10679e168*/
  std::string::basic_string[abi:ne200100]<0>(a1: v599, a2: "WaistRigAttachment", a3: v374, a4: v375); /*0x10679e17e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v600, a2: "WalkAnim", a3: v376, a4: v377); /*0x10679e194*/
  std::string::basic_string[abi:ne200100]<0>(a1: v601, a2: "WaveAnim", a3: v378, a4: v379); /*0x10679e1aa*/
  std::string::basic_string[abi:ne200100]<0>(a1: v602, a2: "Weight", a3: v380, a4: v381); /*0x10679e1c0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v603, a2: "Welded", a3: v382, a4: v383); /*0x10679e1d6*/
  std::string::basic_string[abi:ne200100]<0>(a1: v604, a2: "idle", a3: v384, a4: v385); /*0x10679e1ec*/
  std::string::basic_string[abi:ne200100]<0>(a1: v605, a2: "jump", a3: v386, a4: v387); /*0x10679e1ff*/
  std::string::basic_string[abi:ne200100]<0>(a1: v606, a2: "run", a3: v388, a4: v389); /*0x10679e212*/
  std::string::basic_string[abi:ne200100]<0>(a1: v607, a2: "walk", a3: v390, a4: v391); /*0x10679e225*/
  v476 = 0; /*0x10679e238*/
  v477 = nullptr; /*0x10679e23b*/
  std::vector<std::string>::__init_with_size[abi:ne200100]<std::string const*,std::string const*>( /*0x10679e252*/
    a1: &v476,
    a2: v485,
    a3: v608,
    a4: 126);
  for ( m = 378; m != 0; m -= 3 ) /*0x10679e257*/
  {
    if ( ((__int64)v484[m + 3] & 1) != 0 ) /*0x10679e264*/
      operator delete(a1: (RBX::Memory *)v484[m + 5], a2: v394); /*0x10679e26e*/
  }
  if ( DFFlag::LCRigidConstraintSupport == 1 ) /*0x10679e283*/
  {
    v396 = *((_QWORD *)&v476 + 1); /*0x10679e285*/
    if ( *((_QWORD *)&v476 + 1) >= (unsigned __int64)v477 ) /*0x10679e293*/
    {
      v397 = std::vector<std::string>::__emplace_back_slow_path<char const(&)[25]>( /*0x10679e2bd*/
               a1: &v476,
               a2: "AccessoryRigidConstraint");
    }
    else
    {
      std::string::basic_string[abi:ne200100]<0>( /*0x10679e29f*/
        a1: *((_QWORD *)&v476 + 1),
        a2: "AccessoryRigidConstraint",
        a3: v392,
        a4: v393);
      v397 = v396 + 24; /*0x10679e2a4*/
    }
    *((_QWORD *)&v476 + 1) = v397; /*0x10679e2c0*/
  }
  if ( (FString::NetworkSchemaAdditionalFixedDictionaryEntries & 1) != 0 ) /*0x10679e2d1*/
    v398 = qword_10D80B140; /*0x10679e2d3*/
  else
    v398 = (unsigned __int8)FString::NetworkSchemaAdditionalFixedDictionaryEntries >> 1; /*0x10679e2de*/
  if ( v398 != 0 ) /*0x10679e2e3*/
  {
    if ( (FString::NetworkSchemaAdditionalFixedDictionaryEntries & 1) != 0 ) /*0x10679e2ec*/
      v399 = (char *)qword_10D80B148; /*0x10679e2ee*/
    else
      v399 = (char *)&unk_10D80B139; /*0x10679e2f7*/
    v461 = v399; /*0x10679e30f*/
    v462 = (RBX::Network::NetworkStream *)v398; /*0x10679e313*/
    do /*0x10679e547*/
    {
      LOBYTE(v485[0]) = 59; /*0x10679e31f*/
      v400 = RBX::detail::StringViewBase::find(a1: &v461, a2: v485, a3: 1, a4: 0); /*0x10679e333*/
      if ( v400 == -1 ) /*0x10679e33c*/
      {
        v402 = v461; /*0x10679e369*/
        v392 = v462; /*0x10679e370*/
        v404 = nullptr; /*0x10679e377*/
        v405 = nullptr; /*0x10679e37a*/
      }
      else
      {
        v402 = v461; /*0x10679e33e*/
        v392 = (RBX::Network::NetworkStream *)v400; /*0x10679e34f*/
        if ( (unsigned __int64)v462 < v400 ) /*0x10679e352*/
          v392 = v462; /*0x10679e352*/
        v403 = v400 + 1; /*0x10679e356*/
        if ( (unsigned __int64)v462 < v403 ) /*0x10679e35c*/
          v403 = (unsigned __int64)v462; /*0x10679e35c*/
        v404 = &v461[v403]; /*0x10679e360*/
        v405 = (RBX::Network::NetworkStream *)((char *)v462 - v403); /*0x10679e364*/
      }
      if ( v392 != nullptr ) /*0x10679e380*/
      {
        if ( v402 != nullptr ) /*0x10679e389*/
        {
          std::string::basic_string[abi:ne200100](a1: &v474, a2: v402, a3: v392); /*0x10679e392*/
        }
        else
        {
          v474 = 0; /*0x10679e39c*/
          v475 = nullptr; /*0x10679e3a3*/
        }
        v406 = *((_OWORD **)&v476 + 1); /*0x10679e3ae*/
        if ( *((_QWORD *)&v476 + 1) >= (unsigned __int64)v477 ) /*0x10679e3bf*/
        {
          v407 = 0xAAAAAAAAAAAAAAABLL * ((__int64)(*((_QWORD *)&v476 + 1) - v476) >> 3); /*0x10679e406*/
          v408 = v407 + 1; /*0x10679e40a*/
          if ( v407 + 1 > 0xAAAAAAAAAAAAAAALL ) /*0x10679e411*/
            std::vector<std::string>::__throw_length_error[abi:ne200100](a1: v401); /*0x10679ea1d*/
          if ( 0x5555555555555556LL * (((__int64)v477 - (__int64)v476) >> 3) > v408 ) /*0x10679e429*/
            v408 = 0x5555555555555556LL * (((__int64)v477 - (__int64)v476) >> 3); /*0x10679e429*/
          if ( 0xAAAAAAAAAAAAAAABLL * (((__int64)v477 - (__int64)v476) >> 3) >= 0x555555555555555LL ) /*0x10679e43a*/
            v408 = 0xAAAAAAAAAAAAAAALL; /*0x10679e43a*/
          v485[4] = &v477; /*0x10679e445*/
          if ( v408 != 0 ) /*0x10679e44f*/
          {
            v409 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::string>>( /*0x10679e451*/
                     a1: &v477,
                     a2: v408,
                     a3: 0xAAAAAAAAAAAAAAABLL,
                     a4: 0x555555555555555LL);
          }
          else
          {
            v409 = 0; /*0x10679e458*/
            v410 = 0; /*0x10679e45a*/
          }
          v411 = v409 + 24 * v407; /*0x10679e460*/
          v412 = v409 + 24 * v410; /*0x10679e468*/
          *(_QWORD *)(v411 + 16) = v475; /*0x10679e473*/
          *(_OWORD *)v411 = v474; /*0x10679e47e*/
          v474 = 0; /*0x10679e485*/
          v475 = nullptr; /*0x10679e48c*/
          v413 = v411 + 24; /*0x10679e49b*/
          v414 = (void *)(v411 - (*((_QWORD *)&v476 + 1) - v476)); /*0x10679e4b0*/
          memcpy(__dst: v414, __src: (const void *)v476, __n: *((_QWORD *)&v476 + 1) - v476); /*0x10679e4b6*/
          v415 = (void *)v476; /*0x10679e4bb*/
          v416 = v477; /*0x10679e4c2*/
          *(_QWORD *)&v476 = v414; /*0x10679e4c9*/
          v485[1] = v415; /*0x10679e4d0*/
          *((_QWORD *)&v476 + 1) = v413; /*0x10679e4d7*/
          v485[2] = v415; /*0x10679e4de*/
          v477 = (void *)v412; /*0x10679e4e5*/
          v485[3] = v416; /*0x10679e4ec*/
          v485[0] = v415; /*0x10679e4f3*/
          std::__split_buffer<std::string>::~__split_buffer(a1: v485); /*0x10679e504*/
          *((_QWORD *)&v476 + 1) = v413; /*0x10679e510*/
          if ( (v474 & 1) != 0 ) /*0x10679e528*/
            operator delete(a1: (RBX::Memory *)v475, a2: v417); /*0x10679e531*/
        }
        else
        {
          *(_QWORD *)(*((_QWORD *)&v476 + 1) + 16LL) = v475; /*0x10679e3c8*/
          *v406 = v474; /*0x10679e3d3*/
          *((_QWORD *)&v476 + 1) = (char *)v406 + 24; /*0x10679e3db*/
        }
      }
      v461 = v404; /*0x10679e536*/
      v462 = v405; /*0x10679e53d*/
    }
    while ( v405 != nullptr ); /*0x10679e547*/
  }
  RBX::Network::serializeUnsignedVarint( /*0x10679e56c*/
    this: (RBX::Network *)(-1431655765 * (unsigned int)((*((_QWORD *)&v476 + 1) - (_QWORD)v476) >> 3)),
    a2: (unsigned __int64)v458,
    a3: v392);
  v419 = *((unsigned __int8 **)&v476 + 1); /*0x10679e578*/
  for ( n = (unsigned __int8 *)v476; n != v419; n += 24 ) /*0x10679e582*/
    RBX::Network::serializeString( /*0x10679e59a*/
      a1: n,
      a2: (RBX::Network::NetworkStream *)v458,
      a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
  v485[0] = &v476; /*0x10679e5b6*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: v485); /*0x10679e5bc*/
  LODWORD(v485[0]) = (__n - (unsigned __int64)__src) >> 3; /*0x10679e5d3*/
  RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v458, a2: v485, a3: 4u); /*0x10679e5e8*/
  if ( __src != (void *)__n )
  {
    v420 = (_DWORD **)__src; /*0x10679e60f*/
    while ( 1 )
    {
      v421 = *v420; /*0x10679e616*/
      LODWORD(v485[0]) = **v420; /*0x10679e61d*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v458, a2: v485, a3: 4u); /*0x10679e62e*/
      LODWORD(v485[0]) = (*((_QWORD *)v421 + 9) - *((_QWORD *)v421 + 8)) >> 2; /*0x10679e641*/
      RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v458, a2: v485, a3: 4u); /*0x10679e652*/
      *(_QWORD *)&v478[1] = v420; /*0x10679e657*/
      v433 = *((_DWORD **)v421 + 8); /*0x10679e65e*/
      v479 = (unsigned __int64)v421; /*0x10679e663*/
      v434 = *((_DWORD **)v421 + 9); /*0x10679e66a*/
      if ( v433 != v434 ) /*0x10679e672*/
      {
        v435 = 0; /*0x10679e678*/
        while ( 1 ) /*0x10679e67f*/
        {
          LODWORD(v485[0]) = *v433; /*0x10679e67f*/
          RBX::Network::NetworkStream::writeBytes(this: (RBX::Network::NetworkStream *)v458, a2: v485, a3: 4u); /*0x10679e690*/
          v436 = FFlag::DebugHashTableMetrics; /*0x10679e69c*/
          if ( FFlag::DebugHashTableMetrics == 0 ) /*0x10679e6a0*/
          {
            if ( FFlag::SAuthWorkspaceFlagged == 1 ) /*0x10679e6ba*/
            {
              v422 = (char *)*v467; /*0x10679e6c3*/
              if ( ((unsigned __int8)*v467 & 8) == 0 ) /*0x10679e6c9*/
              {
                if ( ((unsigned __int8)v422 & 1) != 0 || FFlag::NextGenReplicatorEnabledWrite != 0 ) /*0x10679e6da*/
                {
                  if ( ((unsigned __int8)v422 & 2) == 0 ) /*0x10679e70c*/
                  {
                    v422 = &FFlag::DebugNextGenRepAttributeRep; /*0x10679e70e*/
                    if ( FFlag::DebugNextGenRepAttributeRep == 0 ) /*0x10679e718*/
                      goto LABEL_187; /*0x10679e718*/
                  }
                }
                else if ( ((unsigned __int8)v422 & 2) == 0 ) /*0x10679e6df*/
                {
                  goto LABEL_187; /*0x10679e6df*/
                }
              }
            }
            else
            {
              v422 = &FFlag::NextGenReplicatorEnabledRead; /*0x10679e6e3*/
              if ( FFlag::NextGenReplicatorEnabledRead == 0 ) /*0x10679e6ed*/
                goto LABEL_187; /*0x10679e6ed*/
              v422 = &FFlag::NextGenReplicatorEnabledWrite; /*0x10679e6ef*/
              if ( FFlag::NextGenReplicatorEnabledWrite == 0 ) /*0x10679e6f9*/
                goto LABEL_187; /*0x10679e6f9*/
              v422 = &FFlag::DebugNextGenRepAttributeRep; /*0x10679e6fb*/
              if ( FFlag::DebugNextGenRepAttributeRep != 1 ) /*0x10679e705*/
                goto LABEL_187; /*0x10679e705*/
            }
          }
          ++v435; /*0x10679e6a2*/
LABEL_187:
          if ( ++v433 == v434 ) /*0x10679e6ac*/
            goto LABEL_203; /*0x10679e6ac*/
        }
      }
      v436 = FFlag::DebugHashTableMetrics; /*0x10679e723*/
      v435 = 0; /*0x10679e725*/
LABEL_203:
      if ( (v436 & 1) != 0 ) /*0x10679e72a*/
        break; /*0x10679e72a*/
      if ( FFlag::SAuthWorkspaceFlagged == 1 )
      {
        v437 = *v467; /*0x10679e769*/
        if ( ((unsigned __int8)*v467 & 8) != 0 ) /*0x10679e76e*/
          break; /*0x10679e76e*/
        if ( ((unsigned __int8)v437 & 1) != 0 /*0x10679e77e*/
          || (v422 = &FFlag::NextGenReplicatorEnabledWrite, FFlag::NextGenReplicatorEnabledWrite != 0) )
        {
          v422 = &FFlag::DebugNextGenRepAttributeRep; /*0x10679e7ca*/
          LOBYTE(v422) = v435 >= 0xBF; /*0x10679e7da*/
          if ( ((v435 >= 0xBF) & (unsigned __int8)(FFlag::DebugNextGenRepAttributeRep | ((unsigned __int8)v437 >> 1))) != 0 ) /*0x10679e7df*/
            goto LABEL_218; /*0x10679e7df*/
        }
        else
        {
          LOBYTE(v422) = ((unsigned __int8)v437 & 2) == 0 || v435 < 0xBF; /*0x10679e78f*/
          if ( (_BYTE)v422 == 0 ) /*0x10679e791*/
            goto LABEL_218; /*0x10679e791*/
        }
      }
      else if ( FFlag::NextGenReplicatorEnabledRead != 0 && FFlag::NextGenReplicatorEnabledWrite != 0 )
      {
        v422 = &FFlag::DebugNextGenRepAttributeRep; /*0x10679e7b7*/
        if ( ((v435 >= 0xBF) & (unsigned __int8)FFlag::DebugNextGenRepAttributeRep) != 0 )
        {
LABEL_218:
          v438 = *(_QWORD *)(*(_QWORD *)(v479 + 8) + 8LL); /*0x10679e7e5*/
          if ( (*(_BYTE *)v438 & 1) != 0 ) /*0x10679e7f7*/
            v439 = *(const char **)(v438 + 16); /*0x10679e9f8*/
          else
            v439 = (const char *)(v438 + 1); /*0x10679e7fd*/
          RBX::throw_runtime_error(
            this: (RBX *)"Cannot construct schema, too many ISR properties for Attribute use %s - count: %d",
            a2: v439,
            a3: (unsigned int)v435,
            a4: (__int64)v422,
            a5: v423,
            a6: v424,
            a7: v425,
            a8: v426,
            a9: v427,
            a10: v428,
            a11: v429,
            a12: v430,
            a13: v431,
            a14: v432,
            a15: v454);
        }
      }
LABEL_205:
      v420 = (_DWORD **)(*(_QWORD *)&v478[1] + 8LL); /*0x10679e739*/
      if ( *(_QWORD *)&v478[1] + 8LL == __n ) /*0x10679e74b*/
        goto LABEL_220; /*0x10679e74b*/
    }
    if ( v435 >= 0xBF ) /*0x10679e733*/
      goto LABEL_218; /*0x10679e733*/
    goto LABEL_205; /*0x10679e733*/
  }
LABEL_220:
  if ( v472 != nullptr ) /*0x10679e80f*/
    v440 = v472[3]; /*0x10679e811*/
  else
    v440 = 0; /*0x10679e817*/
  RBX::Network::NetAssetManagerFactories::createVersionSet( /*0x10679e820*/
    this: (RBX::Network::NetAssetManagerFactories *)v485,
    a2: v440);
  RBX::Network::NetworkStream::writeUInt32VarInt(this: (RBX::Network::NetworkStream *)v458, a2: v473[0]); /*0x10679e833*/
  for ( ii = 1; ii != 12; ++ii )
  {
    v442 = *(_QWORD *)v456; /*0x10679e852*/
    if ( _bittest64(&v442, ii) )
    {
      v443 = v472 != nullptr ? (RBX::Network::NetAssetManagerFactories *)v472[3] : nullptr;
      v444 = RBX::Network::NetAssetManagerFactories::getDeltaTypeForType(this: v443, a2: ii); /*0x10679e877*/
      RBX::Network::NetworkStream::writeUInt32VarInt(this: (RBX::Network::NetworkStream *)v458, a2: ii); /*0x10679e87f*/
      Version = RBX::Network::NetAssetVersionSet::getVersion(this: (RBX::Network::NetAssetVersionSet *)v485, a2: ii); /*0x10679e88a*/
      RBX::Network::NetworkStream::writeUInt32VarInt(this: (RBX::Network::NetworkStream *)v458, a2: Version); /*0x10679e895*/
      RBX::Network::NetworkStream::writeUInt32VarInt(this: (RBX::Network::NetworkStream *)v458, a2: v444); /*0x10679e8a4*/
      if ( v444 != 0 ) /*0x10679e8ad*/
      {
        v446 = RBX::Network::NetAssetVersionSet::getVersion(this: (RBX::Network::NetAssetVersionSet *)v485, a2: v444); /*0x10679e8b5*/
        RBX::Network::NetworkStream::writeUInt32VarInt(this: (RBX::Network::NetworkStream *)v458, a2: v446); /*0x10679e8c0*/
      }
    }
  }
  v447 = *(RBX::Network::NetworkStream **)v463; /*0x10679e8d9*/
  LOBYTE(v474) = -105; /*0x10679e8e3*/
  RBX::Network::NetworkStream::writeBytes(this: v447, a2: &v474, a3: 1u); /*0x10679e8eb*/
  RBX::Network::Replicator::compressBitStream( /*0x10679e908*/
    this: (RBX::Network::Replicator *)v458,
    a2: *(const RBX::Network::NetworkStream **)v463,
    a3: (RBX::Network::NetworkStream *)(unsigned __int8)DFInt::NetworkSchemaCompressionRatio,
    a4: v448);
  if ( v485[0] != nullptr ) /*0x10679e917*/
  {
    v485[1] = v485[0]; /*0x10679e919*/
    operator delete(a1: (RBX::Memory *)v485[0], a2: v449); /*0x10679e920*/
  }
  if ( v466[0] != nullptr ) /*0x10679e92f*/
  {
    v466[1] = v466[0]; /*0x10679e931*/
    operator delete(a1: (RBX::Memory *)v466[0], a2: v449); /*0x10679e938*/
  }
  if ( v472 != nullptr ) /*0x10679e947*/
    (*(void (__fastcall **)(_QWORD *))(*v472 + 16LL))(a1: v472); /*0x10679e94c*/
  if ( __src != nullptr ) /*0x10679e959*/
    operator delete(a1: (RBX::Memory *)__src, a2: v449); /*0x10679e95b*/
  std::vector<RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo,std::allocator<RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo>>::~vector[abi:ne200100](a1: &v464); /*0x10679e967*/
  if ( v484[0] != nullptr ) /*0x10679e976*/
  {
    v484[1] = v484[0]; /*0x10679e978*/
    operator delete(a1: (RBX::Memory *)v484[0], a2: v450); /*0x10679e97f*/
  }
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v458); /*0x10679e98b*/
  RBX::dynamic_bitset::change_capacity(this: (RBX::dynamic_bitset *)&v455, a2: 0); /*0x10679e999*/
  RBX::dynamic_bitset::change_capacity(this: (RBX::dynamic_bitset *)v457, a2: 0); /*0x10679e9a7*/
  return __stack_chk_guard; /*0x10679e9c0*/
}

// Address: 0x10679ed30 | Name: __ZZN3RBX7Network13NetworkSchema30generateSchemaDefinitionPacketEbPNS0_16ServerSchemaInfoENS_22EngineNetConfigurationEEN12TmpClassInfoD1Ev
void __fastcall RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(bool,RBX::Network::ServerSchemaInfo *,RBX::EngineNetConfiguration)::TmpClassInfo::~TmpClassInfo(
        _QWORD *a1,
        void *a2)
{
  RBX::Memory *v3; // rdi
  RBX::Memory *v4; // rdi
  RBX::Memory *v5; // rdi

  v3 = (RBX::Memory *)a1[8]; /*0x10679ed39*/
  if ( v3 != nullptr ) /*0x10679ed40*/
  {
    a1[9] = v3; /*0x10679ed42*/
    operator delete(a1: v3, a2); /*0x10679ed46*/
  }
  v4 = (RBX::Memory *)a1[5]; /*0x10679ed4b*/
  if ( v4 != nullptr ) /*0x10679ed52*/
  {
    a1[6] = v4; /*0x10679ed54*/
    operator delete(a1: v4, a2); /*0x10679ed58*/
  }
  v5 = (RBX::Memory *)a1[2]; /*0x10679ed5d*/
  if ( v5 != nullptr ) /*0x10679ed64*/
  {
    a1[3] = v5; /*0x10679ed66*/
    operator delete(a1: v5, a2); /*0x10679ed70*/
  }
}

// Address: 0x10679f5ae | Name: __ZN3RBX7Network13NetworkSchema36initializeFromSchemaDefinitionPacketEPNS0_16ClientReplicatorERNS0_13NetworkStreamEb
void __fastcall RBX::Network::NetworkSchema::initializeFromSchemaDefinitionPacket(
        RBX::Network::NetworkSchema *this,
        RBX::Network::ClientReplicator *a2,
        RBX::Network::NetworkStream *a3,
        int a4)
{
  __int64 v6; // r14
  __int64 v7; // r15
  int NumberOfUnreadBytes; // eax
  unsigned int UInt32VarInt; // eax
  __int64 v10; // rdx
  __int64 v11; // rcx
  const char *v12; // rsi
  __int64 v13; // r8
  __int64 v14; // r9
  __m128 v15; // xmm0
  __m128 v16; // xmm1
  __m128 v17; // xmm2
  __m128 v18; // xmm3
  __m128 v19; // xmm4
  __m128 v20; // xmm5
  __m128 v21; // xmm6
  __m128 v22; // xmm7
  __int64 UInt64; // rax
  RBX::Network::NetworkStream *v24; // rdx
  RBX::Network::NetworkStream *v25; // rdx
  unsigned __int16 i; // r13
  char Byte; // r12
  unsigned __int8 *v28; // rbx
  RBX::Reflection::Type *v29; // rdi
  void *v30; // rsi
  unsigned int v31; // eax
  __int64 v32; // rax
  __int64 *AllTypes; // rax
  __int64 v34; // rcx
  __int64 v35; // rax
  __int64 v36; // rax
  __int64 v37; // r15
  __int64 v38; // rax
  RBX::Network::NetworkStream *v39; // rdx
  RBX::Network::NetworkSchema *v40; // r13
  RBX::Network::NetworkStream *v41; // rdx
  unsigned int v42; // ecx
  __int64 v43; // rcx
  __int64 v44; // r14
  RBX::Network::NetworkStream *v45; // rdx
  unsigned __int8 *v46; // rbx
  RBX::Reflection::ClassDescriptor *v47; // rdi
  unsigned int v48; // eax
  __int64 v49; // rax
  __int64 v50; // r14
  RBX::Reflection::ClassDescriptor *v51; // rdi
  __int64 v52; // rax
  const char *v53; // rsi
  __int64 v54; // r8
  __int64 v55; // r9
  __m128 v56; // xmm0
  __m128 v57; // xmm1
  __m128 v58; // xmm2
  __m128 v59; // xmm3
  __m128 v60; // xmm4
  __m128 v61; // xmm5
  __m128 v62; // xmm6
  __m128 v63; // xmm7
  __int64 v64; // rdx
  _QWORD *v65; // rcx
  unsigned __int16 v66; // ax
  __int64 v67; // r13
  int v68; // eax
  char v69; // r15
  int v70; // r14d
  __int64 v71; // rdx
  __int64 v72; // rcx
  const char *v73; // rsi
  __int64 v74; // r8
  __int64 v75; // r9
  __m128 v76; // xmm0
  __m128 v77; // xmm1
  __m128 v78; // xmm2
  __m128 v79; // xmm3
  __m128 v80; // xmm4
  __m128 v81; // xmm5
  __m128 v82; // xmm6
  __m128 v83; // xmm7
  __int64 v84; // r12
  char *v85; // rax
  __int64 v86; // rcx
  __int64 v87; // rsi
  char *v88; // rbx
  __int64 v89; // rax
  int v90; // eax
  __int64 v91; // rdx
  const char *v92; // rsi
  __int64 v93; // r8
  __int64 v94; // r9
  __m128 v95; // xmm0
  __m128 v96; // xmm1
  __m128 v97; // xmm2
  __m128 v98; // xmm3
  __m128 v99; // xmm4
  __m128 v100; // xmm5
  __m128 v101; // xmm6
  __m128 v102; // xmm7
  __int64 v103; // rcx
  char *v104; // rsi
  __int64 PropertyDescriptor; // rax
  const RBX::Reflection::PropertyDescriptor *v106; // r15
  _QWORD *v107; // rbx
  void *v108; // rbx
  _WORD *v109; // rax
  signed __int64 v110; // rbx
  __int64 v111; // r14
  unsigned __int64 v112; // rsi
  __int64 v113; // rax
  __int64 v114; // rdx
  __int64 v115; // r12
  __int64 v116; // rdi
  void *v117; // r12
  void *v118; // r14
  void *v119; // rsi
  RBX::Memory *v120; // rdi
  unsigned __int64 v121; // rax
  RBX::Network::NetworkStream *v122; // rdx
  __int16 UInt16; // bx
  const char *v124; // rsi
  __int64 v125; // r8
  __int64 v126; // r9
  __m128 v127; // xmm0
  __m128 v128; // xmm1
  __m128 v129; // xmm2
  __m128 v130; // xmm3
  __m128 v131; // xmm4
  __m128 v132; // xmm5
  __m128 v133; // xmm6
  __m128 v134; // xmm7
  __int64 v135; // rdx
  __int64 v136; // rbx
  __int64 v137; // r14
  RBX::Network::NetworkStream *v138; // rdx
  __int64 *v139; // r12
  __int64 v140; // r14
  unsigned __int64 j; // rbx
  char v142; // r15
  unsigned __int16 v143; // ax
  __int64 v144; // rcx
  __int64 v145; // rax
  char *v146; // rsi
  __int64 EventDescriptor; // r15
  __int64 v148; // rbx
  __int64 v149; // r14
  char v150; // al
  RBX::Profiler::RomarkMarkers *v151; // rsi
  _WORD *v152; // rax
  RBX::Reflection::ClassDescriptor **v153; // rsi
  _WORD *v154; // rax
  unsigned __int16 v155; // cx
  __int64 v156; // rax
  __int64 v157; // rdx
  __int64 v158; // r14
  __int64 v159; // r15
  __int64 k; // r12
  __int16 v161; // r13
  RBX::Network::NetworkStream *v162; // rdx
  _QWORD *v163; // rbx
  __int64 v164; // r15
  __int64 v165; // rdi
  __int64 v166; // r13
  RBX::Network::NetworkStream *v167; // rdx
  _QWORD *v168; // rbx
  _QWORD *v169; // r14
  __int64 v170; // r12
  unsigned __int64 v171; // r13
  __int64 v172; // rdx
  __int64 v173; // rcx
  unsigned int UInt32; // ebx
  const char *v175; // rsi
  __int64 v176; // r8
  __int64 v177; // r9
  __m128 v178; // xmm0
  __m128 v179; // xmm1
  __m128 v180; // xmm2
  __m128 v181; // xmm3
  __m128 v182; // xmm4
  __m128 v183; // xmm5
  __m128 v184; // xmm6
  __m128 v185; // xmm7
  unsigned int v186; // eax
  __int64 v187; // rdx
  __int64 v188; // r8
  __int64 v189; // r9
  __m128 v190; // xmm0
  __m128 v191; // xmm1
  __m128 v192; // xmm2
  __m128 v193; // xmm3
  __m128 v194; // xmm4
  __m128 v195; // xmm5
  __m128 v196; // xmm6
  __m128 v197; // xmm7
  const char *v198; // rsi
  unsigned __int64 v199; // rcx
  RBX::Profiler::RomarkMarkers *v200; // rdi
  char *v201; // rsi
  __int64 v202; // rax
  __int64 v203; // rdx
  __int64 v204; // rcx
  __int64 v205; // r8
  __int64 v206; // r9
  unsigned int v207; // r15d
  __m128 v208; // xmm0
  __m128 v209; // xmm1
  __m128 v210; // xmm2
  __m128 v211; // xmm3
  __m128 v212; // xmm4
  __m128 v213; // xmm5
  __m128 v214; // xmm6
  __m128 v215; // xmm7
  int v216; // r13d
  __int16 v217; // r14
  RBX::Network::NetAssetManagerFactories *v218; // rdi
  unsigned __int16 v219; // bx
  bool v220; // al
  int v221; // ebx
  __int64 v222; // rax
  RBX::Network::NetAssetManagerFactories *v223; // rdi
  _QWORD **v224; // rbx
  _QWORD **v225; // r14
  _QWORD *m; // r12
  __int16 v227; // ax
  _QWORD *v228; // rsi
  __int16 v229; // r15
  __int64 v230; // r14
  __int64 v231; // r15
  unsigned __int64 v232; // r12
  unsigned __int16 v233; // ax
  __int64 v234; // r13
  __int64 v235; // rcx
  RBX::Network::NetworkSchema *v236; // r15
  __int64 v237; // rax
  RBX::Profiler::RomarkMarkers *v238; // rdi
  __int64 v239; // rax
  RBX::Profiler::RomarkMarkers *v240; // rdi
  __int64 v241; // rax
  RBX::Profiler::RomarkConnectionMonitor *v242; // rdi
  RBX::Profiler::RomarkConnectionMonitor *v243; // rax
  __int64 v244; // rax
  __int64 v245; // r14
  __int64 v246; // rdi
  __int64 v247; // rbx
  __int64 v248; // r14
  double v249; // xmm0_8
  char v250; // [rsp+0h] [rbp-170h]
  __int64 *v251; // [rsp+0h] [rbp-170h]
  __int64 v252; // [rsp+8h] [rbp-168h]
  _QWORD **v253; // [rsp+10h] [rbp-160h]
  _QWORD *v254; // [rsp+18h] [rbp-158h]
  _QWORD *v255; // [rsp+20h] [rbp-150h]
  double v256; // [rsp+28h] [rbp-148h]
  unsigned int v257[16]; // [rsp+30h] [rbp-140h] BYREF
  int v258; // [rsp+70h] [rbp-100h]
  unsigned int v259; // [rsp+74h] [rbp-FCh]
  RBX::Network::Replicator *v260; // [rsp+78h] [rbp-F8h]
  _QWORD *v261; // [rsp+80h] [rbp-F0h]
  char v262[8]; // [rsp+88h] [rbp-E8h] BYREF
  char **v263; // [rsp+90h] [rbp-E0h]
  __int64 v264; // [rsp+98h] [rbp-D8h]
  unsigned int v265; // [rsp+A0h] [rbp-D0h] BYREF
  unsigned int v266; // [rsp+A4h] [rbp-CCh] BYREF
  RBX::Reflection::ClassDescriptor **v267; // [rsp+A8h] [rbp-C8h]
  void *__src[2]; // [rsp+B0h] [rbp-C0h] BYREF
  void *v269; // [rsp+C0h] [rbp-B0h] BYREF
  __int64 v270; // [rsp+C8h] [rbp-A8h]
  __int128 v271; // [rsp+D0h] [rbp-A0h] BYREF
  char *v272; // [rsp+E0h] [rbp-90h]
  unsigned int v273; // [rsp+E8h] [rbp-88h] BYREF
  unsigned int v274; // [rsp+ECh] [rbp-84h] BYREF
  _QWORD *v275; // [rsp+F0h] [rbp-80h]
  _QWORD *v276; // [rsp+F8h] [rbp-78h]
  _QWORD *v277; // [rsp+100h] [rbp-70h]
  RBX::Network::NetworkSchema *v278; // [rsp+108h] [rbp-68h]
  __int64 v279; // [rsp+110h] [rbp-60h]
  RBX::Profiler::RomarkMarkers *v280; // [rsp+118h] [rbp-58h]
  __int16 v281; // [rsp+126h] [rbp-4Ah] BYREF
  unsigned __int64 v282; // [rsp+128h] [rbp-48h]
  int v283; // [rsp+130h] [rbp-40h] BYREF
  unsigned int v284; // [rsp+134h] [rbp-3Ch] BYREF
  __int64 v285; // [rsp+138h] [rbp-38h] BYREF
  unsigned __int16 v286[21]; // [rsp+146h] [rbp-2Ah] BYREF

  v258 = a4; /*0x10679f5c2*/
  v260 = a2; /*0x10679f5cb*/
  v256 = RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: this); /*0x10679f5da*/
  RBX::Network::NetworkStream::readByte(this: a3); /*0x10679f5e5*/
  RBX::Crypto::HashMd5::HashMd5(this: (RBX::Crypto::HashMd5 *)v262); /*0x10679f5f1*/
  v6 = (*(__int64 (__fastcall **)(RBX::Network::NetworkStream *))(*(_QWORD *)a3 + 16LL))(a1: a3); /*0x10679f5ff*/
  v7 = *((unsigned int *)a3 + 14); /*0x10679f602*/
  NumberOfUnreadBytes = RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: a3); /*0x10679f609*/
  RBX::Crypto::Hash::update(this: (RBX::Crypto::Hash *)v262, a2: (const void *)(v7 + v6), a3: NumberOfUnreadBytes); /*0x10679f61d*/
  RBX::Crypto::Hash::result(this: (RBX::Crypto::Hash *)v262, a2: (char *)this + 480, a3: 16); /*0x10679f636*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v257); /*0x10679f642*/
  RBX::Network::Replicator::decompressBitStream(this: a3, a2: (RBX::Network::NetworkStream *)v257, a3: 0); /*0x10679f653*/
  UInt32VarInt = RBX::Network::NetworkStream::readUInt32VarInt(this: (RBX::Network::NetworkStream *)v257); /*0x10679f65f*/
  if ( UInt32VarInt > 0xFFFF || (*((_WORD *)this + 260) = UInt32VarInt, UInt32VarInt != 3) ) /*0x10679f67b*/
    RBX::throw_runtime_error( /*0x1067a0800*/
      this: (RBX *)"Requesting Invalid Schema Version.",
      a2: v12,
      a3: v10,
      a4: v11,
      a5: v13,
      a6: v14,
      a7: v15,
      a8: v16,
      a9: v17,
      a10: v18,
      a11: v19,
      a12: v20,
      a13: v21,
      a14: v22,
      a15: v250);
  UInt64 = RBX::Network::NetworkStream::readUInt64(this: (RBX::Network::NetworkStream *)v257); /*0x10679f688*/
  RBX::EngineNetConfiguration::EngineNetConfiguration(a1: &v271, a2: UInt64); /*0x10679f697*/
  *((_QWORD *)this + 1) = v271; /*0x10679f6a3*/
  if ( FFlag::SAuthWorkspaceFlagged != 0 ) /*0x10679f6b2*/
    *((_BYTE *)this + 1) = 1; /*0x10679f6b4*/
  RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v273, a2: v257, a3: v24); /*0x10679f6c8*/
  v275 = (_QWORD *)((char *)this + 160); /*0x10679f6db*/
  std::vector<RBX::Reflection::EnumDescriptor const*>::resize(a1: (char *)this + 160, a2: v273); /*0x10679f6df*/
  v278 = this; /*0x10679f6e4*/
  if ( v273 != 0 ) /*0x10679f6ef*/
  {
    v276 = (_QWORD *)((char *)v278 + 16); /*0x10679f6fd*/
    for ( i = 0; i < v273; ++i ) /*0x10679f701*/
    {
      v271 = 0; /*0x10679f70f*/
      v272 = nullptr; /*0x10679f717*/
      RBX::Network::deserializeString( /*0x10679f735*/
        a1: (__int64)&v271,
        a2: (RBX::Network::NetworkStream *)v257,
        a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
      Byte = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v257); /*0x10679f742*/
      *(_QWORD *)(*v275 + 8LL * i) = 0; /*0x10679f750*/
      v28 = (unsigned __int8 *)RBX::Name::lookup(a1: &v271); /*0x10679f764*/
      v31 = *v28; /*0x10679f767*/
      if ( (v31 & 1) != 0 ) /*0x10679f76c*/
        v32 = *((_QWORD *)v28 + 1); /*0x10679f76e*/
      else
        v32 = v31 >> 1; /*0x10679f774*/
      if ( v32 != 0 ) /*0x10679f779*/
      {
        AllTypes = (__int64 *)RBX::Reflection::Type::getAllTypes(this: v29); /*0x10679f77b*/
        v34 = *AllTypes; /*0x10679f780*/
        v35 = AllTypes[1] - *AllTypes; /*0x10679f787*/
        if ( v35 != 0 ) /*0x10679f78a*/
        {
          v36 = (v35 >> 3 == 0) + (v35 >> 3); /*0x10679f794*/
          v25 = nullptr; /*0x10679f798*/
          while ( 1 ) /*0x10679f79a*/
          {
            v37 = *(_QWORD *)(v34 + 8LL * (_QWORD)v25); /*0x10679f79a*/
            if ( *(unsigned __int8 **)(v37 + 8) == v28 && *(_BYTE *)(v37 + 54) != 0 ) /*0x10679f7a9*/
              break; /*0x10679f7a9*/
            v25 = (RBX::Network::NetworkStream *)((char *)v25 + 1); /*0x10679f7ab*/
            if ( (RBX::Network::NetworkStream *)v36 == v25 ) /*0x10679f7b1*/
              goto LABEL_18; /*0x10679f7b1*/
          }
          __src[0] = *(void **)(v34 + 8LL * (_QWORD)v25); /*0x10679f7b5*/
          v38 = RBX::DenseHashMap<RBX::Reflection::Type const*,RBX::Network::NetworkSchemaTypes::Type,RBX::Hash<RBX::Reflection::Type const*>,std::equal_to<RBX::Reflection::Type const*>>::operator[]( /*0x10679f7c7*/
                  a1: v276,
                  a2: (__int64)__src);
          *(_BYTE *)(v38 + 1) = Byte; /*0x10679f7cc*/
          *(_WORD *)(v38 + 2) = i; /*0x10679f7d0*/
          *(_QWORD *)(v38 + 8) = v37; /*0x10679f7d5*/
          *(_QWORD *)(*v275 + 8LL * i) = v37; /*0x10679f7e0*/
        }
      }
LABEL_18:
      if ( (v271 & 1) != 0 ) /*0x10679f7eb*/
        operator delete(a1: (RBX::Memory *)v272, a2: v30); /*0x10679f7f4*/
    }
  }
  v274 = 0; /*0x10679f81a*/
  RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v274, a2: v257, a3: v25); /*0x10679f827*/
  v265 = 0; /*0x10679f833*/
  RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v265, a2: v257, a3: v39); /*0x10679f840*/
  v40 = v278; /*0x10679f845*/
  v266 = 0; /*0x10679f850*/
  RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v266, a2: v257, a3: v41); /*0x10679f85d*/
  v253 = (_QWORD **)((char *)v40 + 184); /*0x10679f86f*/
  std::vector<RBX::Network::NetworkSchemaTypes::ClassInfo>::resize(a1: (char *)v40 + 184, a2: v274); /*0x10679f876*/
  v263 = (char **)((char *)v40 + 208); /*0x10679f88a*/
  std::vector<RBX::Network::NetworkSchemaTypes::ClassProperty>::resize(a1: (char *)v40 + 208, a2: v265 + 1); /*0x10679f891*/
  v251 = (__int64 *)((char *)v40 + 232); /*0x10679f8a3*/
  std::vector<RBX::Network::NetworkSchemaTypes::ClassEvent>::resize(a1: (char *)v40 + 232, a2: v266); /*0x10679f8aa*/
  v271 = 0; /*0x10679f8b3*/
  v272 = nullptr; /*0x10679f8bd*/
  v269 = nullptr; /*0x10679f8c4*/
  *(_OWORD *)__src = 0; /*0x10679f8cb*/
  v42 = 0; /*0x10679f8d3*/
  if ( v274 != 0 ) /*0x10679f8e7*/
  {
    LOBYTE(v42) = v260 == nullptr; /*0x10679f8ed*/
    v259 = v42; /*0x10679f8ef*/
    v255 = (_QWORD *)((char *)v40 + 64); /*0x10679f8f9*/
    v276 = (_QWORD *)((char *)v40 + 16); /*0x10679f904*/
    v254 = (_QWORD *)((char *)v40 + 112); /*0x10679f90c*/
    v264 = 0; /*0x10679f913*/
    v282 = 0; /*0x10679f92c*/
    v43 = 0; /*0x10679f934*/
    while ( 1 ) /*0x10679f936*/
    {
      v252 = v43; /*0x10679f936*/
      RBX::Network::deserializeString( /*0x10679f94c*/
        a1: (__int64)&v271,
        a2: (RBX::Network::NetworkStream *)v257,
        a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
      v44 = 23LL * (unsigned __int16)v264; /*0x10679f962*/
      v277 = *v253; /*0x10679f969*/
      LOWORD(v277[v44]) = v264; /*0x10679f96d*/
      v46 = (unsigned __int8 *)RBX::Name::lookup(a1: &v271); /*0x10679f97a*/
      v48 = *v46; /*0x10679f97d*/
      if ( (v48 & 1) != 0 ) /*0x10679f982*/
        v49 = *((_QWORD *)v46 + 1); /*0x10679f984*/
      else
        v49 = v48 >> 1; /*0x10679f98a*/
      v277 = (_QWORD *)((char *)v277 + v44 * 8); /*0x10679f98c*/
      if ( v49 != 0 ) /*0x10679f993*/
      {
        v50 = *(_QWORD *)RBX::Reflection::ClassDescriptor::allClasses(this: v47); /*0x10679f99a*/
        v52 = *(_QWORD *)(RBX::Reflection::ClassDescriptor::allClasses(this: v51) + 8); /*0x10679f9a2*/
        while ( v50 != v52 ) /*0x10679f9a9*/
        {
          if ( *(unsigned __int8 **)(*(_QWORD *)v50 + 8LL) == v46 ) /*0x10679f9b2*/
          {
            v153 = (RBX::Reflection::ClassDescriptor **)(v277 + 1); /*0x10679ffd1*/
            v277[1] = *(_QWORD *)v50; /*0x10679ffd5*/
            v267 = v153; /*0x10679ffe0*/
            v154 = (_WORD *)RBX::DenseHashMap<RBX::Reflection::ClassDescriptor const*,unsigned short,RBX::Hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>::operator[]( /*0x10679ffe7*/
                              a1: v255,
                              a2: (__int64)v153);
            *v154 = v264; /*0x10679fff3*/
            goto LABEL_32; /*0x10679fff6*/
          }
          v50 += 8; /*0x10679f9b8*/
        }
      }
      v267 = (RBX::Reflection::ClassDescriptor **)(v277 + 1); /*0x10679f9c6*/
      v277[1] = 0; /*0x10679f9cd*/
LABEL_32:
      LODWORD(v285) = 0; /*0x10679f9d5*/
      RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v285, a2: v257, a3: v45); /*0x10679f9e3*/
      v64 = v282; /*0x10679f9e8*/
      v65 = v277; /*0x10679f9ec*/
      *((_WORD *)v277 + 1) = v282; /*0x10679f9f0*/
      v66 = v64 + v285; /*0x10679f9f8*/
      *((_WORD *)v65 + 2) = v64 + v285; /*0x10679f9fb*/
      if ( v265 < v66 ) /*0x10679fa08*/
        RBX::throw_runtime_error( /*0x1067a07c9*/
          this: (RBX *)"Invalid Schema",
          a2: v53,
          a3: v64,
          a4: v66,
          a5: v54,
          a6: v55,
          a7: v56,
          a8: v57,
          a9: v58,
          a10: v59,
          a11: v60,
          a12: v61,
          a13: v62,
          a14: v63,
          a15: (char)v251);
      if ( (unsigned __int16)v64 < v66 ) /*0x10679fa11*/
        break; /*0x10679fa11*/
LABEL_69:
      UInt16 = RBX::Network::NetworkStream::readUInt16(this: (RBX::Network::NetworkStream *)v257); /*0x10679fd74*/
      if ( *v267 != nullptr && UInt16 != -1 ) /*0x10679fd90*/
        *(_WORD *)RBX::DenseHashMap<RBX::Reflection::ClassDescriptor const*,unsigned short,RBX::Hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>>::operator[]( /*0x10679fdad*/
                    a1: v254,
                    a2: (__int64)v267) = UInt16;
      v283 = 0; /*0x10679fdb0*/
      RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v283, a2: v257, a3: v122); /*0x10679fdbe*/
      v43 = v252; /*0x10679fdc7*/
      v135 = (unsigned __int16)(v252 + v283); /*0x10679fdd1*/
      v270 = v135; /*0x10679fdd4*/
      if ( v266 < (unsigned int)v135 ) /*0x10679fde1*/
        RBX::throw_runtime_error( /*0x1067a07d9*/
          this: (RBX *)"Invalid Schema",
          a2: v124,
          a3: v135,
          a4: v252,
          a5: v125,
          a6: v126,
          a7: v127,
          a8: v128,
          a9: v129,
          a10: v130,
          a11: v131,
          a12: v132,
          a13: v133,
          a14: v134,
          a15: (char)v251);
      if ( (unsigned __int16)v252 < (unsigned __int16)(v252 + v283) ) /*0x10679fdea*/
      {
        LOWORD(v261) = v252 + v283; /*0x10679fdf0*/
        v277 += 8; /*0x10679fdf7*/
        v279 = (unsigned __int16)v252; /*0x10679fdff*/
        do /*0x10679ff99*/
        {
          RBX::Network::deserializeString( /*0x10679fe12*/
            a1: (__int64)&v271,
            a2: (RBX::Network::NetworkStream *)v257,
            a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
          v136 = *v251; /*0x10679fe1e*/
          v137 = 5 * v279; /*0x10679fe25*/
          *(_WORD *)(*v251 + 40 * v279) = v279; /*0x10679fe29*/
          v284 = 0; /*0x10679fe2e*/
          RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v284, a2: v257, a3: v138); /*0x10679fe3c*/
          v280 = (RBX::Profiler::RomarkMarkers *)(v136 + 8 * v137); /*0x10679fe45*/
          v139 = (__int64 *)((char *)v280 + 8); /*0x10679fe49*/
          std::vector<RBX::Network::NetworkSchemaTypes::Type>::resize(a1: (char *)v280 + 8, a2: v284); /*0x10679fe53*/
          if ( v284 != 0 ) /*0x10679fe5c*/
          {
            v140 = 1; /*0x10679fe5e*/
            for ( j = 0; j < v284; ++j ) /*0x10679fe64*/
            {
              v142 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v257); /*0x10679fe75*/
              v143 = RBX::Network::NetworkStream::readUInt16(this: (RBX::Network::NetworkStream *)v257); /*0x10679fe7b*/
              v144 = *v139; /*0x10679fe80*/
              *(_BYTE *)(v144 + v140) = v142; /*0x10679fe84*/
              *(_WORD *)(v144 + v140 + 1) = v143; /*0x10679fe88*/
              if ( v143 == 0xFFFF ) /*0x10679fe92*/
                v145 = 0; /*0x10679fea4*/
              else
                v145 = *(_QWORD *)(*v275 + 8LL * v143); /*0x10679fe9e*/
              *(_QWORD *)(v144 + v140 + 7) = v145; /*0x10679fea6*/
              v140 += 16; /*0x10679feb1*/
            }
          }
          *((_QWORD *)v280 + 4) = 0; /*0x10679febe*/
          if ( *v267 != nullptr ) /*0x10679fed3*/
          {
            v146 = (char *)&v271 + 1; /*0x10679fee0*/
            if ( (v271 & 1) != 0 ) /*0x10679fee7*/
              v146 = v272; /*0x10679fee9*/
            EventDescriptor = RBX::Reflection::ClassDescriptor::findEventDescriptor(this: *v267, a2: v146); /*0x10679fef5*/
            if ( EventDescriptor != 0 ) /*0x10679fefb*/
            {
              v148 = *(_QWORD *)(EventDescriptor + 72); /*0x10679ff00*/
              if ( 0x6DB6DB6DB6DB6DB7LL * ((*(_QWORD *)(EventDescriptor + 80) - v148) >> 4) == v284 ) /*0x10679ff20*/
              {
                v280 = (RBX::Profiler::RomarkMarkers *)((char *)v280 + 32); /*0x10679ff22*/
                v149 = 4; /*0x10679ff27*/
                while ( v148 != *(_QWORD *)(EventDescriptor + 80) ) /*0x10679ff31*/
                {
                  v150 = RBX::Network::isNetworkValueFormatCompatibleWithLocalType( /*0x10679ff4f*/
                           a1: *(_QWORD *)(v148 + 8),
                           a2: *(unsigned __int8 *)(*v139 + v149 - 3),
                           a3: *(_WORD *)(*v139 + v149 - 2),
                           a4: (__int64)v276,
                           a5: (_DWORD *)(*v139 + v149));
                  v148 += 112; /*0x10679ff54*/
                  v149 += 16; /*0x10679ff58*/
                  if ( v150 == 0 ) /*0x10679ff5e*/
                    goto LABEL_90; /*0x10679ff5e*/
                }
                v151 = v280; /*0x10679ff62*/
                *(_QWORD *)v280 = EventDescriptor; /*0x10679ff66*/
                v152 = (_WORD *)RBX::DenseHashMap<RBX::Reflection::EventDescriptor const*,unsigned short,RBX::Hash<RBX::Reflection::EventDescriptor const*>,std::equal_to<RBX::Reflection::EventDescriptor const*>>::operator[]( /*0x10679ff6d*/
                                  a1: v277,
                                  a2: (__int64)v151);
                *v152 = v279; /*0x10679ff76*/
              }
            }
          }
LABEL_90:
          ++v279; /*0x10679ff79*/
        }
        while ( v279 != v270 ); /*0x10679ff99*/
        v43 = (unsigned __int16)v261; /*0x10679ffa6*/
        v40 = v278; /*0x10679ffa8*/
      }
      v264 = (unsigned int)(v264 + 1); /*0x10679ffb5*/
      if ( v274 <= (unsigned __int16)v264 ) /*0x10679ffc5*/
        goto LABEL_96; /*0x10679ffc5*/
    }
    v261 = v277 + 2; /*0x10679fa1f*/
    v282 = (unsigned __int16)v64; /*0x10679fa29*/
    v67 = 32 * (unsigned int)(unsigned __int16)v64; /*0x10679fa30*/
    while ( 1 ) /*0x10679fa43*/
    {
      RBX::Network::deserializeString( /*0x10679fa43*/
        a1: (__int64)&v271,
        a2: (RBX::Network::NetworkStream *)v257,
        a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
      v68 = RBX::Network::NetworkStream::readByte(this: (RBX::Network::NetworkStream *)v257); /*0x10679fa4b*/
      v69 = v68; /*0x10679fa50*/
      v70 = (unsigned __int8)v68; /*0x10679fa53*/
      if ( (_BYTE)v68 == 60 ) /*0x10679fa5b*/
      {
        v90 = RBX::Network::NetworkStream::readUInt32VarInt(this: (RBX::Network::NetworkStream *)v257); /*0x10679faf4*/
        LOBYTE(v103) = 1; /*0x10679faf9*/
        LODWORD(v280) = v103; /*0x10679fafb*/
        LODWORD(v270) = v90; /*0x10679fafe*/
        if ( (_WORD)v90 == 0xFFFF ) /*0x10679fb08*/
          RBX::throw_runtime_error( /*0x1067a07a9*/
            this: (RBX *)"Invalid Schema",
            a2: v92,
            a3: v91,
            a4: v103,
            a5: v93,
            a6: v94,
            a7: v95,
            a8: v96,
            a9: v97,
            a10: v98,
            a11: v99,
            a12: v100,
            a13: v101,
            a14: v102,
            a15: (char)v251);
      }
      else
      {
        if ( (unsigned __int8)v68 == 7 ) /*0x10679fa65*/
        {
          v68 = RBX::Network::NetworkStream::readUInt16(this: (RBX::Network::NetworkStream *)v257); /*0x10679fa6a*/
          if ( (_WORD)v68 != 0xFFFF ) /*0x10679fa73*/
          {
            v84 = (unsigned __int16)v68; /*0x10679fa75*/
            if ( v273 <= (unsigned __int16)v68 ) /*0x10679fa80*/
              RBX::throw_runtime_error( /*0x1067a07b9*/
                this: (RBX *)"Invalid Schema",
                a2: v73,
                a3: v71,
                a4: v72,
                a5: v74,
                a6: v75,
                a7: v76,
                a8: v77,
                a9: v78,
                a10: v79,
                a11: v80,
                a12: v81,
                a13: v82,
                a14: v83,
                a15: (char)v251);
            v85 = *v263; /*0x10679fa8d*/
            v86 = 32 * v282; /*0x10679fa97*/
            v87 = (__int64)&(*v263)[32 * v282]; /*0x10679fa9b*/
            *(_WORD *)&v85[v67] = v282; /*0x10679fa9f*/
            v88 = &v85[v86 + 24]; /*0x10679faa8*/
            *(_QWORD *)&v85[v67 + 24] = 0; /*0x10679faac*/
            v85[v67 + 9] = v69; /*0x10679fab5*/
            *(_WORD *)&v85[v67 + 10] = v84; /*0x10679faba*/
            v89 = *(_QWORD *)(*v275 + 8 * v84); /*0x10679fac7*/
            LOWORD(v86) = -1; /*0x10679facb*/
            LODWORD(v270) = v86; /*0x10679facf*/
            LODWORD(v280) = 0; /*0x10679fad5*/
            goto LABEL_43; /*0x10679fadc*/
          }
        }
        LOWORD(v68) = -1; /*0x10679fade*/
        LODWORD(v270) = v68; /*0x10679fae2*/
        LODWORD(v280) = 0; /*0x10679fae8*/
      }
      v88 = &(*v263)[v67 + 24]; /*0x10679fb1c*/
      v87 = (__int64)&(*v263)[v67]; /*0x10679fb20*/
      *((_WORD *)v88 - 12) = v282; /*0x10679fb27*/
      *(_QWORD *)v88 = 0; /*0x10679fb2b*/
      *(v88 - 15) = v69; /*0x10679fb32*/
      *((_WORD *)v88 - 7) = -1; /*0x10679fb36*/
      LOWORD(v84) = -1; /*0x10679fb3c*/
      v89 = 0; /*0x10679fb41*/
LABEL_43:
      v279 = v87; /*0x10679fb43*/
      *(_QWORD *)(v87 + 16) = v89; /*0x10679fb47*/
      if ( *v267 != nullptr ) /*0x10679fb58*/
      {
        v104 = (char *)&v271 + 1; /*0x10679fb65*/
        if ( (v271 & 1) != 0 ) /*0x10679fb6c*/
          v104 = v272; /*0x10679fb6e*/
        PropertyDescriptor = RBX::Reflection::ClassDescriptor::findPropertyDescriptor(this: *v267, a2: v104); /*0x10679fb75*/
        v106 = (const RBX::Reflection::PropertyDescriptor *)PropertyDescriptor; /*0x10679fb7a*/
        if ( PropertyDescriptor != 0 /*0x10679fbe2*/
          && RBX::Network::isNetworkValueFormatCompatibleWithLocalType(
               a1: *(_QWORD *)(PropertyDescriptor + 104),
               a2: v70,
               a3: v84,
               a4: (__int64)v276,
               a5: (_DWORD *)(v279 + 12)) != 0
          && (unsigned __int8)RBX::Network::Replicator::canReplicateProperty(
                                a1: (unsigned __int8)v258,
                                a2: v106,
                                a3: v259) != 0
          && (v260 == nullptr
           || (unsigned __int8)RBX::Network::Replicator::canClientReplicateProperty_deprecated(this: v260, a2: v106) != 0) )
        {
          if ( (_BYTE)v280 != 0 ) /*0x10679fbec*/
          {
            if ( (*((_BYTE *)v106 + 139) & 0x40) != 0 ) /*0x10679fbf6*/
            {
              v107 = __src[1]; /*0x10679fbfc*/
              if ( __src[1] >= v269 ) /*0x10679fc0d*/
              {
                v110 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x10679fc65*/
                v111 = v279; /*0x10679fc7a*/
                if ( (unsigned __int64)(v110 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x10679fc7e*/
                  std::vector<RBX::Network::DeferNetAssetPropertyInitialization>::__throw_length_error[abi:ne200100](); /*0x1067a07f0*/
                v112 = (signed __int64)((__int64)v269 - (unsigned __int64)__src[0]) >> 4; /*0x10679fc8a*/
                if ( v112 <= v110 + 1 ) /*0x10679fc91*/
                  v112 = v110 + 1; /*0x10679fc91*/
                if ( (unsigned __int64)v269 - (unsigned __int64)__src[0] >= 0x7FFFFFFFFFFFFFE0LL ) /*0x10679fca2*/
                  v112 = 0x7FFFFFFFFFFFFFFLL; /*0x10679fca2*/
                if ( v112 != 0 ) /*0x10679fca9*/
                {
                  v113 = std::__allocate_at_least[abi:ne200100]<std::allocator<RBX::Network::DeferNetAssetPropertyInitialization>>(a1: &v269); /*0x10679fcb2*/
                  v115 = v114; /*0x10679fcb7*/
                }
                else
                {
                  v113 = 0; /*0x10679fcbc*/
                  v115 = 0; /*0x10679fcbe*/
                }
                v116 = v113 + 32 * v110; /*0x10679fcc5*/
                v117 = (void *)(v113 + 32 * v115); /*0x10679fccd*/
                v108 = (void *)(v116 + 32); /*0x10679fcd3*/
                *(_QWORD *)v116 = v277; /*0x10679fcdb*/
                *(_QWORD *)(v116 + 8) = v111; /*0x10679fcdf*/
                *(_QWORD *)(v116 + 16) = v106; /*0x10679fce3*/
                *(_WORD *)(v116 + 24) = v282; /*0x10679fceb*/
                *(_WORD *)(v116 + 26) = v270; /*0x10679fcf5*/
                v118 = (void *)(v116 - ((char *)__src[1] - (char *)__src[0])); /*0x10679fd0d*/
                memcpy(__dst: v118, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x10679fd10*/
                v120 = (RBX::Memory *)__src[0]; /*0x10679fd15*/
                __src[0] = v118; /*0x10679fd1c*/
                __src[1] = v108; /*0x10679fd23*/
                v269 = v117; /*0x10679fd2a*/
                if ( v120 != nullptr ) /*0x10679fd34*/
                  operator delete(a1: v120, a2: v119); /*0x10679fd36*/
              }
              else
              {
                *(_QWORD *)__src[1] = v277; /*0x10679fc13*/
                v107[1] = v279; /*0x10679fc1a*/
                v107[2] = v106; /*0x10679fc1e*/
                *((_WORD *)v107 + 12) = v282; /*0x10679fc26*/
                *((_WORD *)v107 + 13) = v270; /*0x10679fc30*/
                v108 = v107 + 4; /*0x10679fc34*/
              }
              __src[1] = v108; /*0x10679fd3b*/
            }
          }
          else
          {
            *(_QWORD *)v88 = v106; /*0x10679fc3d*/
            v109 = (_WORD *)RBX::DenseHashMap<RBX::Reflection::PropertyDescriptor const*,unsigned short,RBX::Hash<RBX::Reflection::PropertyDescriptor const*>,std::equal_to<RBX::Reflection::PropertyDescriptor const*>>::operator[]( /*0x10679fc4a*/
                              a1: v261,
                              a2: (__int64)v88);
            *v109 = v282; /*0x10679fc53*/
          }
        }
      }
      v121 = *((unsigned __int16 *)v277 + 2); /*0x10679fd4d*/
      v67 += 32; /*0x10679fd51*/
      if ( ++v282 >= v121 ) /*0x10679fd6a*/
      {
        v40 = v278; /*0x10679fd70*/
        goto LABEL_69; /*0x10679fd70*/
      }
    }
  }
  v282 = 0; /*0x10679fffb*/
LABEL_96:
  v155 = v282; /*0x1067a0003*/
  *((_WORD *)v40 + 128) = v282; /*0x1067a0007*/
  v156 = *((_QWORD *)v40 + 26); /*0x1067a000f*/
  v157 = 32 * (unsigned int)v155; /*0x1067a001b*/
  *(_WORD *)(v156 + v157) = v155; /*0x1067a001e*/
  v158 = RBX::Instance::propParent; /*0x1067a0029*/
  *(_QWORD *)(v156 + v157 + 24) = RBX::Instance::propParent; /*0x1067a002c*/
  *(_BYTE *)(v156 + v157 + 9) = 28; /*0x1067a0031*/
  *(_WORD *)(v156 + v157 + 10) = -1; /*0x1067a0036*/
  v159 = *((_QWORD *)v40 + 23); /*0x1067a003d*/
  for ( k = *((_QWORD *)v40 + 24); v159 != k; v40 = v278 ) /*0x1067a004e*/
  {
    v161 = *((_WORD *)v40 + 128); /*0x1067a0054*/
    v285 = v158; /*0x1067a0060*/
    *(_WORD *)RBX::DenseHashMap<RBX::Reflection::PropertyDescriptor const*,unsigned short,RBX::Hash<RBX::Reflection::PropertyDescriptor const*>,std::equal_to<RBX::Reflection::PropertyDescriptor const*>>::operator[]( /*0x1067a006c*/
                a1: (_QWORD *)(v159 + 16),
                a2: (__int64)&v285) = v161;
    v159 += 184; /*0x1067a0070*/
  }
  if ( (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: (RBX::Network::NetworkStream *)v257) != 0 ) /*0x1067a008e*/
  {
    LODWORD(v285) = 0; /*0x1067a0094*/
    RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v285, a2: v257, a3: v162); /*0x1067a00a1*/
    v163 = (_QWORD *)((char *)v40 + 264); /*0x1067a00a6*/
    std::vector<std::string>::resize(a1: (char *)v40 + 264, a2: (unsigned int)(v285 + 1)); /*0x1067a00b5*/
    std::string::assign(a1: *((_QWORD *)v40 + 33), a2: ""); /*0x1067a00c4*/
    v164 = -1; /*0x1067a00c9*/
    v165 = 24; /*0x1067a00d0*/
    while ( ++v164 < (unsigned __int64)(unsigned int)v285 ) /*0x1067a00e6*/
    {
      v166 = v165 + 24; /*0x1067a00ee*/
      RBX::Network::deserializeString( /*0x1067a00fc*/
        a1: *v163 + v165,
        a2: (RBX::Network::NetworkStream *)v257,
        a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
      v165 = v166; /*0x1067a0101*/
      v40 = v278; /*0x1067a0104*/
    }
  }
  if ( (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: (RBX::Network::NetworkStream *)v257) != 0 ) /*0x1067a0118*/
  {
    LODWORD(v285) = 0; /*0x1067a0122*/
    RBX::Network::deserializeUnsignedVarint(this: (RBX::Network *)&v285, a2: v257, a3: v167); /*0x1067a012f*/
    v168 = (_QWORD *)((char *)v40 + 352); /*0x1067a0134*/
    std::vector<std::string>::resize(a1: (char *)v40 + 352, a2: (unsigned int)v285); /*0x1067a0141*/
    if ( (_DWORD)v285 != 0 ) /*0x1067a014a*/
    {
      v169 = (_QWORD *)((char *)v278 + 288); /*0x1067a0150*/
      v170 = 0; /*0x1067a0157*/
      v171 = 0; /*0x1067a0161*/
      do /*0x1067a019a*/
      {
        RBX::Network::deserializeString( /*0x1067a0176*/
          a1: v170 + *v168,
          a2: (RBX::Network::NetworkStream *)v257,
          a3: (RBX::Network::NetworkStream *)(unsigned int)DFInt::MaxDataPayloadSize);
        *(_WORD *)RBX::DenseHashMap<std::string,unsigned short,RBX::Hash<std::string>,std::equal_to<std::string>>::operator[]( /*0x1067a0189*/
                    a1: v169,
                    a2: v170 + *v168) = v171++;
        v170 += 24; /*0x1067a0193*/
      }
      while ( v171 < (unsigned int)v285 ); /*0x1067a019a*/
    }
    v40 = v278; /*0x1067a019c*/
  }
  if ( (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: (RBX::Network::NetworkStream *)v257) != 0 ) /*0x1067a01ae*/
  {
    UInt32 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v257); /*0x1067a01bc*/
    if ( UInt32 > v274 ) /*0x1067a01c4*/
      RBX::throw_runtime_error( /*0x1067a0810*/
        this: (RBX *)"Cannot construct schema, too many classes with ISR properties",
        a2: v175,
        a3: v172,
        a4: v173,
        a5: v176,
        a6: v177,
        a7: v178,
        a8: v179,
        a9: v180,
        a10: v181,
        a11: v182,
        a12: v183,
        a13: v184,
        a14: v185,
        a15: (char)v251);
    for ( ; UInt32 != 0; --UInt32 ) /*0x1067a01cc*/
    {
      v186 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)v257); /*0x1067a01e2*/
      v198 = *((const char **)v40 + 23); /*0x1067a01e9*/
      v199 = 0xD37A6F4DE9BD37A7LL * ((__int64)(*((_QWORD *)v40 + 24) - (_QWORD)v198) >> 3); /*0x1067a01fe*/
      if ( v199 <= v186 ) /*0x1067a0205*/
        RBX::throw_runtime_error( /*0x1067a07e9*/
          this: (RBX *)"Cannot construct schema, invalid class id for ISR properties",
          a2: v198,
          a3: v187,
          a4: v199,
          a5: v188,
          a6: v189,
          a7: v190,
          a8: v191,
          a9: v192,
          a10: v193,
          a11: v194,
          a12: v195,
          a13: v196,
          a14: v197,
          a15: (char)v251);
      RBX::Network::deserializeIsrProperties( /*0x1067a021f*/
        a1: (RBX::Network::NetworkStream *)v257,
        a2: (__int64)&v198[184 * v186],
        a3: v263);
    }
  }
  if ( (unsigned int)RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this: (RBX::Network::NetworkStream *)v257) != 0 )
  {
    v280 = (RBX::Profiler::RomarkMarkers *)RBX::Subsystem<RBX::Network::NetAssetManagerFactories,false>::startup<RBX::SubsystemDefaultFactory<RBX::Network::NetAssetManagerFactories>>(); /*0x1067a0250*/
    std::vector<unsigned short>::resize(a1: (char *)v40 + 424, a2: 11); /*0x1067a0254*/
    if ( FFlag::LrCache == 1 ) /*0x1067a0263*/
      std::vector<unsigned long>::reserve(a1: (char *)v40 + 448, a2: 11); /*0x1067a0271*/
    v202 = *((_QWORD *)v40 + 53); /*0x1067a0276*/
    *(_OWORD *)v202 = -1; /*0x1067a027d*/
    *(_QWORD *)(v202 + 14) = -1; /*0x1067a0281*/
    v207 = RBX::Network::NetworkStream::readUInt32VarInt(this: (RBX::Network::NetworkStream *)v257); /*0x1067a0295*/
    v282 = (unsigned __int64)v40 + 424; /*0x1067a0298*/
    if ( v207 > 0xFFFF ) /*0x1067a02a1*/
      RBX::throw_runtime_error( /*0x1067a0820*/
        this: (RBX *)"Cannot construct schema, invalid lr type range",
        a2: v201,
        a3: v203,
        a4: v204,
        a5: v205,
        a6: v206,
        a7: v208,
        a8: v209,
        a9: v210,
        a10: v211,
        a11: v212,
        a12: v213,
        a13: v214,
        a14: v215,
        a15: (char)v251);
    if ( v207 != 0 )
    {
      v275 = (_QWORD *)((char *)v278 + 376); /*0x1067a02bb*/
      v276 = (_QWORD *)((char *)v278 + 400); /*0x1067a02c6*/
      v279 = (__int64)v278 + 448; /*0x1067a02d0*/
      v216 = 0; /*0x1067a02de*/
      do
      {
        LOWORD(v283) = 0; /*0x1067a02e1*/
        LOWORD(v284) = 0; /*0x1067a02e6*/
        v286[0] = 0; /*0x1067a02eb*/
        v281 = 0; /*0x1067a02f0*/
        LOWORD(v283) = RBX::Network::NetworkStream::readUInt32VarInt(this: (RBX::Network::NetworkStream *)v257); /*0x1067a02fd*/
        LOWORD(v284) = RBX::Network::NetworkStream::readUInt32VarInt(this: (RBX::Network::NetworkStream *)v257); /*0x1067a0309*/
        v286[0] = RBX::Network::NetworkStream::readUInt32VarInt(this: (RBX::Network::NetworkStream *)v257); /*0x1067a0315*/
        if ( v286[0] != 0 ) /*0x1067a031c*/
        {
          v217 = RBX::Network::NetworkStream::readUInt32VarInt(this: (RBX::Network::NetworkStream *)v257); /*0x1067a0326*/
          v281 = v217; /*0x1067a0329*/
        }
        else
        {
          v217 = v281; /*0x1067a0330*/
        }
        if ( (unsigned __int16)(v283 - 1) <= 0xAu
          && (v280 == nullptr ? (v218 = nullptr) : (v218 = *((RBX::Network::NetAssetManagerFactories **)v280 + 3)),
              (v219 = v286[0]) == (unsigned __int16)RBX::Network::NetAssetManagerFactories::getDeltaTypeForType(
                                                      this: v218,
                                                      a2: v283)) )
        {
          v220 = v286[0] != 0; /*0x1067a0369*/
        }
        else
        {
          v286[0] = 0; /*0x1067a036e*/
          v220 = false; /*0x1067a0374*/
        }
        v221 = v216 + 1; /*0x1067a0384*/
        if ( (unsigned __int16)(v283 - 1) <= 0xAu && (v220 || v217 == 0) ) /*0x1067a037a*/
        {
          *(_WORD *)(*(_QWORD *)v282 + 2LL * (unsigned __int16)v283 - 2) = v216; /*0x1067a039c*/
          std::vector<unsigned short>::push_back[abi:ne200100](a1: v275, a2: &v283); /*0x1067a03aa*/
          std::vector<unsigned short>::push_back[abi:ne200100](a1: v276, a2: &v284); /*0x1067a03b7*/
          if ( FFlag::LrCache == 1 ) /*0x1067a03c6*/
          {
            v222 = DFInt::DebugLrCacheCategoryMax; /*0x1067a03cc*/
            if ( DFInt::DebugLrCacheCategoryMax == 0 ) /*0x1067a03d6*/
            {
              if ( v280 != nullptr ) /*0x1067a03e3*/
                v223 = *((RBX::Network::NetAssetManagerFactories **)v280 + 3); /*0x1067a03e9*/
              else
                v223 = nullptr; /*0x1067a0491*/
              v222 = *(_QWORD *)(RBX::Network::NetAssetManagerFactories::getLoader(this: v223, a2: v283) + 8); /*0x1067a049c*/
            }
            v285 = v222; /*0x1067a04a0*/
            std::vector<unsigned long>::push_back[abi:ne200100](a1: v279, a2: &v285); /*0x1067a04ac*/
          }
          if ( v217 == 0 ) /*0x1067a04b5*/
            goto LABEL_145; /*0x1067a04b5*/
          *(_WORD *)(*(_QWORD *)v282 + 2LL * v286[0] - 2) = v216 + 1; /*0x1067a04c2*/
          std::vector<unsigned short>::push_back[abi:ne200100](a1: v275, a2: v286); /*0x1067a04cf*/
          std::vector<unsigned short>::push_back[abi:ne200100](a1: v276, a2: &v281); /*0x1067a04dc*/
          v221 = v216 + 2; /*0x1067a04e5*/
          if ( FFlag::LrCache != 1 ) /*0x1067a04f2*/
            goto LABEL_145; /*0x1067a04f2*/
        }
        else
        {
          std::vector<unsigned short>::push_back[abi:ne200100](a1: v275, a2: &RBX::Network::kInvalidNetAssetType); /*0x1067a03fd*/
          LOWORD(v285) = 0; /*0x1067a0402*/
          std::vector<unsigned short>::push_back[abi:ne200100](a1: v276, a2: &v285); /*0x1067a0410*/
          if ( FFlag::LrCache == 1 ) /*0x1067a041f*/
          {
            v285 = 0; /*0x1067a0421*/
            std::vector<unsigned long>::push_back[abi:ne200100](a1: v279, a2: &v285); /*0x1067a0431*/
          }
          if ( v217 == 0 ) /*0x1067a043a*/
            goto LABEL_145; /*0x1067a043a*/
          std::vector<unsigned short>::push_back[abi:ne200100](a1: v275, a2: &RBX::Network::kInvalidNetAssetType); /*0x1067a044b*/
          LOWORD(v285) = 0; /*0x1067a0450*/
          std::vector<unsigned short>::push_back[abi:ne200100](a1: v276, a2: &v285); /*0x1067a045e*/
          v221 = v216 + 2; /*0x1067a0467*/
          if ( FFlag::LrCache != 1 ) /*0x1067a0474*/
            goto LABEL_145; /*0x1067a0474*/
        }
        v285 = 0; /*0x1067a04f4*/
        std::vector<unsigned long>::push_back[abi:ne200100](a1: v279, a2: &v285); /*0x1067a0504*/
LABEL_145:
        v216 = v221; /*0x1067a0509*/
        --v207; /*0x1067a050c*/
      }
      while ( v207 != 0 );
    }
    v224 = (_QWORD **)__src[0]; /*0x1067a051c*/
    v225 = (_QWORD **)__src[1]; /*0x1067a0523*/
    v40 = v278; /*0x1067a052d*/
    for ( m = (_QWORD *)v282; v224 != v225; v224 += 4 ) /*0x1067a0535*/
    {
      v227 = *(_WORD *)(*m + 2LL * (*(unsigned __int16 (__fastcall **)(_QWORD *))(*v224[2] + 80LL))(a1: v224[2]) - 2); /*0x1067a0548*/
      if ( v227 != -1 && v227 == *((_WORD *)v224 + 13) ) /*0x1067a0557*/
      {
        v228 = v224[1]; /*0x1067a0559*/
        v228[3] = v224[2]; /*0x1067a0561*/
        v229 = *((_WORD *)v224 + 12); /*0x1067a0569*/
        *(_WORD *)RBX::DenseHashMap<RBX::Reflection::PropertyDescriptor const*,unsigned short,RBX::Hash<RBX::Reflection::PropertyDescriptor const*>,std::equal_to<RBX::Reflection::PropertyDescriptor const*>>::operator[]( /*0x1067a057a*/
                    a1: *v224 + 2,
                    a2: (__int64)(v228 + 3)) = v229;
      }
    }
    v200 = v280; /*0x1067a0587*/
    if ( v280 != nullptr ) /*0x1067a058e*/
      (*(void (__fastcall **)(RBX::Profiler::RomarkMarkers *))(*(_QWORD *)v280 + 16LL))(a1: v280); /*0x1067a0593*/
  }
  v230 = *((_QWORD *)v40 + 23); /*0x1067a0596*/
  v231 = *((_QWORD *)v40 + 24); /*0x1067a059d*/
  while ( v230 != v231 ) /*0x1067a05a7*/
  {
    v232 = *(unsigned __int16 *)(v230 + 2); /*0x1067a05a9*/
    v233 = *(_WORD *)(v230 + 4); /*0x1067a05ae*/
    if ( (unsigned __int16)v232 < v233 ) /*0x1067a05b7*/
    {
      v234 = (unsigned int)(32 * v232) | 0x18LL; /*0x1067a05c7*/
      do /*0x1067a0604*/
      {
        v201 = *v263; /*0x1067a05d2*/
        v235 = *(_QWORD *)&(*v263)[v234]; /*0x1067a05d5*/
        if ( v235 != 0 && (*(_BYTE *)(v235 + 139) & 0x40) != 0 ) /*0x1067a05e5*/
        {
          std::vector<RBX::Reflection::PropertyDescriptor const*>::push_back[abi:ne200100]( /*0x1067a05ed*/
            a1: v230 + 160,
            a2: &v201[v234]);
          v233 = *(_WORD *)(v230 + 4); /*0x1067a05f2*/
        }
        ++v232; /*0x1067a05f7*/
        v234 += 32; /*0x1067a05fd*/
      }
      while ( v232 < v233 ); /*0x1067a0604*/
    }
    v230 += 184; /*0x1067a0606*/
  }
  v236 = v278; /*0x1067a0619*/
  if ( DFFlag::DebugPerfMode != 0 ) /*0x1067a061d*/
  {
    v237 = RBX::Profiler::RomarkMarkers::instance(this: v200); /*0x1067a061f*/
    RBX::Profiler::RomarkMarkers::endSpan(a1: v237, a2: "join", a3: 4); /*0x1067a0633*/
    v239 = RBX::Profiler::RomarkMarkers::instance(this: v238); /*0x1067a0638*/
    RBX::Profiler::RomarkMarkers::endSpan(a1: v239, a2: "rejoin", a3: 6); /*0x1067a064c*/
    v241 = RBX::Profiler::RomarkMarkers::instance(this: v240); /*0x1067a0651*/
    RBX::Profiler::RomarkMarkers::startSpan(a1: v241, a2: "gameload", a3: 8); /*0x1067a0665*/
    v243 = (RBX::Profiler::RomarkConnectionMonitor *)RBX::Profiler::RomarkConnectionMonitor::get(this: v242); /*0x1067a066a*/
    RBX::Profiler::RomarkConnectionMonitor::setConnectionStatus(this: v243, a2: 0); /*0x1067a0674*/
  }
  if ( DFFlag::DebugEnablePhaseTracking != 0 || DFFlag::DebugEnableClientPhaseTracking == 1 )
  {
    v244 = RBX::Subsystem<RBX::RomarkClientPhaseTracker,false>::startup<RBX::SubsystemDefaultFactory<RBX::RomarkClientPhaseTracker>>(); /*0x1067a0691*/
    v245 = v244; /*0x1067a0696*/
    v246 = v244 != 0 ? *(_QWORD *)(v244 + 24) : 0LL;
    RBX::RomarkClientPhaseTracker::changeRomarkClientPhase(a1: v246, a2: 2); /*0x1067a06ab*/
    if ( v245 != 0 ) /*0x1067a06b3*/
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v245 + 16LL))(a1: v245); /*0x1067a06bb*/
  }
  v247 = FLog::Network; /*0x1067a06c5*/
  if ( (unsigned __int8)FLog::Network >= 6u && BYTE1(FLog::Network) >= 3u ) /*0x1067a06d6*/
  {
    v248 = qword_10D7BBAA8; /*0x1067a06dd*/
    v249 = (RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v200) - v256) * 1000.0; /*0x1067a06ee*/
    *(float *)&v249 = v249; /*0x1067a06f6*/
    FLog::FastLogF( /*0x1067a0710*/
      a1: v247,
      a2: v248,
      a3: "[FLog::Network] Time taken to initialize schema = %f ms",
      v249,
      0.0,
      0.0,
      0.0);
  }
  *(_BYTE *)v236 = 1; /*0x1067a0715*/
  if ( FFlag::LrCache == 1 ) /*0x1067a0723*/
    *((_BYTE *)v236 + 472) = 1; /*0x1067a0725*/
  if ( FFlag::CLI184283Pre == 1 ) /*0x1067a0737*/
    *((_BYTE *)v236 + 473) = (*((_BYTE *)v236 + 8) & 0x20) != 0; /*0x1067a0742*/
  if ( __src[0] != nullptr ) /*0x1067a0753*/
  {
    __src[1] = __src[0]; /*0x1067a0755*/
    operator delete(a1: (RBX::Memory *)__src[0], a2: v201); /*0x1067a075c*/
  }
  if ( (v271 & 1) != 0 ) /*0x1067a0768*/
    operator delete(a1: (RBX::Memory *)v272, a2: v201); /*0x1067a0771*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)v257); /*0x1067a077d*/
  RBX::Crypto::Hash::~Hash(this: (RBX::Crypto::Hash *)v262); /*0x1067a0789*/
}

// Address: 0x10680f628 | Name: __ZNK3RBX7Network13NetworkSchema34fixedDictionaryStringFromNetworkIdEt
__int128 *__fastcall RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId(
        RBX::Network::NetworkSchema *this,
        unsigned __int16 a2)
{
  __int64 v4; // rcx
  unsigned __int64 v5; // rsi
  __int64 v6; // rcx
  __int128 *result; // rax

  if ( (_BYTE)`guard variable for'RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId(unsigned short)::kEmpty == 0 ) /*0x10680f63d*/
    RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId(); /*0x10680f681*/
  v4 = *((_QWORD *)this + 44); /*0x10680f643*/
  v5 = 0xAAAAAAAAAAAAAAABLL * ((*((_QWORD *)this + 45) - v4) >> 3); /*0x10680f662*/
  v6 = v4 + 24LL * a2; /*0x10680f66d*/
  result = &RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId(unsigned short)const::kEmpty; /*0x10680f671*/
  if ( v5 > a2 ) /*0x10680f678*/
    return (__int128 *)v6; /*0x10680f678*/
  return result; /*0x10680f67c*/
}

// Address: 0x108764598 | Name: __ZN3RBX7Network13NetworkSchema30generateSchemaDefinitionPacketEbPNS0_16ServerSchemaInfoENS_22EngineNetConfigurationE.cold.1
void __fastcall RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(RBX::Memory **a1, RBX::Memory **a2)
{
  do /*0x1087645bc*/
  {
    if ( (*(_BYTE *)(a1 - 3) & 1) != 0 ) /*0x1087645aa*/
      operator delete(a1: *(a1 - 1), a2); /*0x1087645b0*/
    a1 -= 3; /*0x1087645b5*/
  }
  while ( a1 != a2 ); /*0x1087645bc*/
}

// Address: 0x1087645c3 | Name: __ZN3RBX7Network13NetworkSchema30generateSchemaDefinitionPacketEbPNS0_16ServerSchemaInfoENS_22EngineNetConfigurationE.cold.2
void __fastcall RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(RBX::Memory **a1, RBX::Memory **a2)
{
  do /*0x1087645e7*/
  {
    if ( (*(_BYTE *)(a1 - 3) & 1) != 0 ) /*0x1087645d5*/
      operator delete(a1: *(a1 - 1), a2); /*0x1087645db*/
    a1 -= 3; /*0x1087645e0*/
  }
  while ( a1 != a2 ); /*0x1087645e7*/
}

// Address: 0x108767639 | Name: __ZNK3RBX7Network13NetworkSchema34fixedDictionaryStringFromNetworkIdEt.cold.1
void RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId()
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId(unsigned short)::kEmpty) != 0 ) /*0x10876764b*/
  {
    RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId(unsigned short)const::kEmpty = 0; /*0x108767650*/
    qword_10CDD9A28 = 0; /*0x108767657*/
    __cxa_atexit( /*0x108767674*/
      lpfunc: (void (__fastcall *)(void *))&std::string::~string,
      obj: &RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId(unsigned short)const::kEmpty,
      lpdso_handle: (void *)&_mh_execute_header);
    __cxa_guard_release(a1: &`guard variable for'RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId(unsigned short)::kEmpty); /*0x108767681*/
  }
}

// END NetworkSchema part 1/1, 18 functions
