// ConcurrentRakPeer -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 16 functions


// Address: 0x106720758 | Name: __ZN3RBX7Network17ConcurrentRakPeer8addStatsEN6RakNet13SystemAddressEiNSt3__18functionIFvRKNS0_15ConnectionStatsEEEE
__int64 __fastcall RBX::Network::ConcurrentRakPeer::addStats(
        __int64 a1,
        unsigned int a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  void *v10; // rsi
  __int64 i; // r13
  RBX::Memory *v12; // rdi
  __int64 v13; // rax
  __int64 v14; // rax
  RSL::Mutex *v15; // r15
  __int64 v16; // rdi
  void *v17; // rsi
  __int64 j; // r14
  RBX::Memory *v19; // rdi
  __int64 v20; // rax
  _BYTE v22[32]; // [rsp+0h] [rbp-7A0h] BYREF
  _BYTE *v23; // [rsp+20h] [rbp-780h]
  RSL::Mutex *v24; // [rsp+30h] [rbp-770h] BYREF
  char v25; // [rsp+38h] [rbp-768h]
  char v26; // [rsp+40h] [rbp-760h] BYREF
  char *v27; // [rsp+60h] [rbp-740h]
  void *v28[57]; // [rsp+1F8h] [rbp-5A8h] BYREF
  _BYTE v29[32]; // [rsp+3C0h] [rbp-3E0h] BYREF
  _BYTE v30[16]; // [rsp+3E0h] [rbp-3C0h] BYREF
  char v31; // [rsp+3F0h] [rbp-3B0h] BYREF
  char *v32; // [rsp+410h] [rbp-390h]
  void *v33[57]; // [rsp+5A8h] [rbp-1F8h] BYREF

  std::__function::__value_func<void ()(RBX::Network::ConnectionStats const&)>::__value_func[abi:ne200100]( /*0x10672078d*/
    a1: v22,
    a2: a3);
  RBX::Network::ConnectionStats::ConnectionStats(a1: &v24, a2, a3: v22); /*0x1067207a6*/
  std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>::pair[abi:ne200100]<RakNet::SystemAddress&,RBX::Network::ConnectionStats,0>( /*0x1067207bd*/
    a1: v29,
    a2: &a7,
    a3: &v24);
  for ( i = 0; i != -16; i -= 4 ) /*0x1067207c9*/
  {
    v12 = (RBX::Memory *)v28[i]; /*0x1067207cc*/
    if ( &v28[i + 3] != (void **)v12 ) /*0x1067207db*/
      operator delete(a1: v12, a2: v10); /*0x1067207dd*/
  }
  if ( v27 == &v26 ) /*0x1067207fa*/
  {
    v13 = 32; /*0x106720808*/
    goto LABEL_9; /*0x106720808*/
  }
  v13 = 40; /*0x1067207fc*/
  if ( v27 != nullptr ) /*0x106720804*/
LABEL_9:
    (*(void (**)(void))(*(_QWORD *)v27 + v13))(); /*0x10672080d*/
  if ( v23 == v22 ) /*0x10672081d*/
  {
    v14 = 32; /*0x10672082b*/
    goto LABEL_14; /*0x10672082b*/
  }
  v14 = 40; /*0x10672081f*/
  if ( v23 != nullptr ) /*0x106720827*/
LABEL_14:
    (*(void (**)(void))(*(_QWORD *)v23 + v14))(); /*0x106720830*/
  RBX::Network::ConcurrentRakPeer::StatsUpdateJob::updateStats(a1: *(_QWORD *)(a1 + 32), a2: v29); /*0x106720836*/
  v15 = (RSL::Mutex *)(*(_QWORD *)(a1 + 32) + 408LL); /*0x10672084c*/
  v24 = v15; /*0x106720850*/
  v25 = 1; /*0x106720857*/
  RSL::Mutex::lock(this: v15); /*0x106720861*/
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>>,RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>>::emplace_impl<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats> const&>( /*0x106720879*/
    a1: (_QWORD *)(*(_QWORD *)(a1 + 32) + 416LL),
    a2: (RakNet::SystemAddress *)v29,
    a3: (__int64)v29);
  v16 = *(_QWORD *)(a3 + 32); /*0x10672087e*/
  if ( v16 == 0 ) /*0x106720885*/
    std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x106720913*/
  (*(void (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v16 + 48LL))(a1: v16, a2: v30); /*0x106720895*/
  RSL::Mutex::unlock(this: v15); /*0x10672089b*/
  for ( j = 0; j != -16; j -= 4 ) /*0x1067208a7*/
  {
    v19 = (RBX::Memory *)v33[j]; /*0x1067208aa*/
    if ( &v33[j + 3] != (void **)v19 ) /*0x1067208b9*/
      operator delete(a1: v19, a2: v17); /*0x1067208bb*/
  }
  if ( v32 == &v31 ) /*0x1067208d8*/
  {
    v20 = 32; /*0x1067208e6*/
  }
  else
  {
    v20 = 40; /*0x1067208da*/
    if ( v32 == nullptr ) /*0x1067208e2*/
      return __stack_chk_guard; /*0x1067208e2*/
  }
  (*(void (**)(void))(*(_QWORD *)v32 + v20))(); /*0x1067208ee*/
  return __stack_chk_guard; /*0x106720901*/
}

// Address: 0x106720a96 | Name: __ZN3RBX7Network17ConcurrentRakPeer11removeStatsEN6RakNet13SystemAddressE
__int64 __fastcall RBX::Network::ConcurrentRakPeer::removeStats(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  RSL::Mutex *v8; // rbx

  v8 = (RSL::Mutex *)(*(_QWORD *)(a1 + 32) + 408LL); /*0x106720aa9*/
  RSL::Mutex::lock(this: v8); /*0x106720ab8*/
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>>,RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>>::erase_key( /*0x106720aca*/
    a1: (_QWORD *)(*(_QWORD *)(a1 + 32) + 416LL),
    a2: (RakNet::SystemAddress *)&a7);
  return RSL::Mutex::unlock(this: v8); /*0x106720ad7*/
}

// Address: 0x106720afc | Name: __ZN3RBX7Network17ConcurrentRakPeerC2EPN6RakNet16RakPeerInterfaceEPNS_9DataModelE
__int64 __fastcall RBX::Network::ConcurrentRakPeer::ConcurrentRakPeer(
        RBX::Network::ConcurrentRakPeer *this,
        RakNet::RakPeerInterface *a2,
        RBX::DataModel *a3)
{
  RBX::Time *v5; // rdi
  __int64 v6; // xmm0_8
  unsigned __int64 v7; // rsi
  RBX::DataModelJob *v8; // r13
  __int64 v9; // rax
  unsigned __int64 v10; // rsi
  __int64 v11; // r13
  __int64 v12; // rax
  std::__shared_weak_count *v13; // r12
  __int64 v14; // rax
  std::__shared_weak_count *v15; // r12
  __int64 v16; // rax
  __int64 result; // rax
  std::__shared_weak_count *v18; // rbx
  std::__shared_weak_count *v19[2]; // [rsp+0h] [rbp-60h]
  std::__shared_weak_count *v20[2]; // [rsp+10h] [rbp-50h] BYREF
  std::__shared_weak_count *v21[2]; // [rsp+20h] [rbp-40h] BYREF

  std::shared_ptr<RakNet::RakPeerInterface>::shared_ptr[abi:ne200100]<RakNet::RakPeerInterface,0>(a1: this, a2); /*0x106720b13*/
  *((_OWORD *)this + 2) = 0; /*0x106720b23*/
  *((_OWORD *)this + 1) = 0; /*0x106720b27*/
  *((_QWORD *)this + 6) = a3; /*0x106720b2b*/
  *((_QWORD *)this + 7) = 0; /*0x106720b2f*/
  RBX::Time::nowFast(this: v5); /*0x106720b37*/
  *((_QWORD *)this + 8) = v6; /*0x106720b3c*/
  v8 = (RBX::DataModelJob *)operator new(a1: (RBX::Memory *)0x1D8, a2: v7); /*0x106720b4b*/
  v9 = *((_QWORD *)this + 1); /*0x106720b4e*/
  *(_OWORD *)v19 = *(_OWORD *)this; /*0x106720b55*/
  if ( v9 != 0 ) /*0x106720b5c*/
    _InterlockedIncrement64((volatile signed __int64 *)(v9 + 8)); /*0x106720b5e*/
  RBX::Network::ConcurrentRakPeer::PacketJob::PacketJob(this: v8); /*0x106720b6d*/
  std::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob>::reset[abi:ne200100]<RBX::Network::ConcurrentRakPeer::PacketJob,0>( /*0x106720b78*/
    a1: (char *)this + 16,
    a2: v8);
  if ( v19[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v19[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106720b96*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v19[1] + 16LL))(a1: v19[1]); /*0x106720b9f*/
    std::__shared_weak_count::__release_weak(this: v19[1]); /*0x106720ba5*/
  }
  v11 = operator new(a1: (RBX::Memory *)0x248, a2: v10); /*0x106720bb4*/
  v12 = *((_QWORD *)this + 1); /*0x106720bb7*/
  *(_OWORD *)v20 = *(_OWORD *)this; /*0x106720bbe*/
  if ( v12 != 0 ) /*0x106720bc5*/
    _InterlockedIncrement64((volatile signed __int64 *)(v12 + 8)); /*0x106720bc7*/
  RBX::Network::ConcurrentRakPeer::StatsUpdateJob::StatsUpdateJob(a1: v11, a2: v20, a3); /*0x106720bd6*/
  std::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob>::reset[abi:ne200100]<RBX::Network::ConcurrentRakPeer::StatsUpdateJob,0>( /*0x106720be1*/
    a1: (char *)this + 32,
    a2: v11);
  v13 = v20[1]; /*0x106720be6*/
  if ( v20[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v20[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106720c00*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x106720c09*/
    std::__shared_weak_count::__release_weak(this: v13); /*0x106720c0f*/
  }
  v14 = *((_QWORD *)this + 3); /*0x106720c14*/
  *(_OWORD *)v21 = *((_OWORD *)this + 1); /*0x106720c1c*/
  if ( v14 != 0 ) /*0x106720c23*/
    _InterlockedIncrement64((volatile signed __int64 *)(v14 + 8)); /*0x106720c25*/
  RBX::TaskScheduler::add(a1: v21); /*0x106720c2e*/
  v15 = v21[1]; /*0x106720c33*/
  if ( v21[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v21[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106720c4d*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x106720c56*/
    std::__shared_weak_count::__release_weak(this: v15); /*0x106720c5c*/
  }
  v16 = *((_QWORD *)this + 5); /*0x106720c61*/
  *(_OWORD *)v21 = *((_OWORD *)this + 2); /*0x106720c69*/
  if ( v16 != 0 ) /*0x106720c70*/
    _InterlockedIncrement64((volatile signed __int64 *)(v16 + 8)); /*0x106720c72*/
  result = RBX::TaskScheduler::add(a1: v21); /*0x106720c7b*/
  v18 = v21[1]; /*0x106720c80*/
  if ( v21[1] != nullptr ) /*0x106720c87*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v21[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x106720c90*/
    if ( result == 0 ) /*0x106720c99*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(a1: v18); /*0x106720ca1*/
      return std::__shared_weak_count::__release_weak(this: v18); /*0x106720ca7*/
    }
  }
  return result; /*0x106720cac*/
}

// Address: 0x106720dec | Name: __ZN3RBX7Network17ConcurrentRakPeerC1EPN6RakNet16RakPeerInterfaceEPNS_9DataModelE
__int64 __fastcall RBX::Network::ConcurrentRakPeer::ConcurrentRakPeer(
        RBX::Network::ConcurrentRakPeer *this,
        RakNet::RakPeerInterface *a2,
        RBX::DataModel *a3)
{
  return RBX::Network::ConcurrentRakPeer::ConcurrentRakPeer(this, a2, a3); /*0x106720df0*/
}

// Address: 0x106720df6 | Name: __ZN3RBX7Network17ConcurrentRakPeerC2ENSt3__110shared_ptrIN6RakNet16RakPeerInterfaceEEEPNS_9DataModelE
__int64 __fastcall RBX::Network::ConcurrentRakPeer::ConcurrentRakPeer(__int64 a1, _OWORD *a2, __int64 a3)
{
  __int64 v5; // r14
  __int64 v6; // r15
  __int64 v7; // xmm0_8
  unsigned __int64 v8; // rsi
  RBX::DataModelJob *v9; // r13
  __int64 v10; // rax
  unsigned __int64 v11; // rsi
  __int64 v12; // r13
  __int64 v13; // rax
  std::__shared_weak_count *v14; // r12
  __int64 v15; // rax
  std::__shared_weak_count *v16; // r12
  __int64 v17; // rax
  __int64 result; // rax
  std::__shared_weak_count *v19; // rbx
  std::__shared_weak_count *v20[2]; // [rsp+0h] [rbp-60h]
  std::__shared_weak_count *v21[2]; // [rsp+10h] [rbp-50h] BYREF
  std::__shared_weak_count *v22[2]; // [rsp+20h] [rbp-40h] BYREF

  *(_OWORD *)a1 = *a2; /*0x106720e10*/
  *a2 = 0; /*0x106720e16*/
  v5 = a1 + 16; /*0x106720e19*/
  v6 = a1 + 32; /*0x106720e1d*/
  *(_OWORD *)(a1 + 32) = 0; /*0x106720e21*/
  *(_OWORD *)(a1 + 16) = 0; /*0x106720e25*/
  *(_QWORD *)(a1 + 48) = a3; /*0x106720e29*/
  *(_QWORD *)(a1 + 56) = 0; /*0x106720e2d*/
  RBX::Time::nowFast(this: (RBX::Time *)a1); /*0x106720e35*/
  *(_QWORD *)(a1 + 64) = v7; /*0x106720e3a*/
  v9 = (RBX::DataModelJob *)operator new(a1: (RBX::Memory *)0x1D8, a2: v8); /*0x106720e49*/
  v10 = *(_QWORD *)(a1 + 8); /*0x106720e4c*/
  *(_OWORD *)v20 = *(_OWORD *)a1; /*0x106720e53*/
  if ( v10 != 0 ) /*0x106720e5a*/
    _InterlockedIncrement64((volatile signed __int64 *)(v10 + 8)); /*0x106720e5c*/
  RBX::Network::ConcurrentRakPeer::PacketJob::PacketJob(this: v9); /*0x106720e6b*/
  std::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob>::reset[abi:ne200100]<RBX::Network::ConcurrentRakPeer::PacketJob,0>( /*0x106720e76*/
    a1: v5,
    a2: v9);
  if ( v20[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v20[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106720e94*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20[1] + 16LL))(a1: v20[1]); /*0x106720e9d*/
    std::__shared_weak_count::__release_weak(this: v20[1]); /*0x106720ea3*/
  }
  v12 = operator new(a1: (RBX::Memory *)0x248, a2: v11); /*0x106720eb2*/
  v13 = *(_QWORD *)(a1 + 8); /*0x106720eb5*/
  *(_OWORD *)v21 = *(_OWORD *)a1; /*0x106720ebc*/
  if ( v13 != 0 ) /*0x106720ec3*/
    _InterlockedIncrement64((volatile signed __int64 *)(v13 + 8)); /*0x106720ec5*/
  RBX::Network::ConcurrentRakPeer::StatsUpdateJob::StatsUpdateJob(a1: v12, a2: v21, a3); /*0x106720ed4*/
  std::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob>::reset[abi:ne200100]<RBX::Network::ConcurrentRakPeer::StatsUpdateJob,0>( /*0x106720edf*/
    a1: v6,
    a2: v12);
  v14 = v21[1]; /*0x106720ee4*/
  if ( v21[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v21[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106720efe*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(a1: v14); /*0x106720f07*/
    std::__shared_weak_count::__release_weak(this: v14); /*0x106720f0d*/
  }
  v15 = *(_QWORD *)(v5 + 8); /*0x106720f12*/
  *(_OWORD *)v22 = *(_OWORD *)v5; /*0x106720f1a*/
  if ( v15 != 0 ) /*0x106720f21*/
    _InterlockedIncrement64((volatile signed __int64 *)(v15 + 8)); /*0x106720f23*/
  RBX::TaskScheduler::add(a1: v22); /*0x106720f2c*/
  v16 = v22[1]; /*0x106720f31*/
  if ( v22[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v22[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106720f4b*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x106720f54*/
    std::__shared_weak_count::__release_weak(this: v16); /*0x106720f5a*/
  }
  v17 = *(_QWORD *)(v6 + 8); /*0x106720f5f*/
  *(_OWORD *)v22 = *(_OWORD *)v6; /*0x106720f67*/
  if ( v17 != 0 ) /*0x106720f6e*/
    _InterlockedIncrement64((volatile signed __int64 *)(v17 + 8)); /*0x106720f70*/
  result = RBX::TaskScheduler::add(a1: v22); /*0x106720f79*/
  v19 = v22[1]; /*0x106720f7e*/
  if ( v22[1] != nullptr ) /*0x106720f85*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v22[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x106720f8e*/
    if ( result == 0 ) /*0x106720f97*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v19 + 16LL))(a1: v19); /*0x106720f9f*/
      return std::__shared_weak_count::__release_weak(this: v19); /*0x106720fa5*/
    }
  }
  return result; /*0x106720faa*/
}

// Address: 0x106721022 | Name: __ZN3RBX7Network17ConcurrentRakPeerC1ENSt3__110shared_ptrIN6RakNet16RakPeerInterfaceEEEPNS_9DataModelE
__int64 __fastcall RBX::Network::ConcurrentRakPeer::ConcurrentRakPeer(__int64 a1, _OWORD *a2, __int64 a3)
{
  return RBX::Network::ConcurrentRakPeer::ConcurrentRakPeer(a1, a2, a3); /*0x106721026*/
}

// Address: 0x10672102c | Name: __ZN3RBX7Network17ConcurrentRakPeerD2Ev
void __fastcall RBX::Network::ConcurrentRakPeer::~ConcurrentRakPeer(RBX::Network::ConcurrentRakPeer *this)
{
  __int64 v2; // rax
  std::__shared_weak_count *v3; // r14
  __int64 v4; // rax
  std::__shared_weak_count *v5; // r14
  std::__shared_weak_count *v6[2]; // [rsp+0h] [rbp-20h] BYREF

  if ( DFFlag::BlockingRemoveConcurrentRakPeerJobs == 0 ) /*0x106721044*/
  {
    v2 = *((_QWORD *)this + 3); /*0x10672104a*/
    *(_OWORD *)v6 = *((_OWORD *)this + 1); /*0x106721052*/
    if ( v2 != 0 ) /*0x106721059*/
      _InterlockedIncrement64((volatile signed __int64 *)(v2 + 8)); /*0x10672105b*/
    RBX::TaskScheduler::remove(a1: v6); /*0x106721064*/
    v3 = v6[1]; /*0x106721069*/
    if ( v6[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v6[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106721082*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(a1: v3); /*0x10672108a*/
      std::__shared_weak_count::__release_weak(this: v3); /*0x106721090*/
    }
    v4 = *((_QWORD *)this + 5); /*0x106721095*/
    *(_OWORD *)v6 = *((_OWORD *)this + 2); /*0x10672109d*/
    if ( v4 != 0 ) /*0x1067210a4*/
      _InterlockedIncrement64((volatile signed __int64 *)(v4 + 8)); /*0x1067210a6*/
    RBX::TaskScheduler::remove(a1: v6); /*0x1067210af*/
    v5 = v6[1]; /*0x1067210b4*/
    if ( v6[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v6[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067210cd*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x1067210d5*/
      std::__shared_weak_count::__release_weak(this: v5); /*0x1067210db*/
    }
  }
  std::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob>::~shared_ptr[abi:ne200100](a1: (char *)this + 32); /*0x1067210e4*/
  std::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob>::~shared_ptr[abi:ne200100](a1: (char *)this + 16); /*0x1067210ed*/
  std::shared_ptr<RakNet::RakPeerInterface>::~shared_ptr[abi:ne200100](a1: this); /*0x1067210f5*/
}

// Address: 0x10672110c | Name: __ZN3RBX7Network17ConcurrentRakPeerD1Ev
void __fastcall RBX::Network::ConcurrentRakPeer::~ConcurrentRakPeer(RBX::Network::ConcurrentRakPeer *this)
{
  RBX::Network::ConcurrentRakPeer::~ConcurrentRakPeer(this); /*0x106721111*/
}

// Address: 0x106721116 | Name: __ZN3RBX7Network17ConcurrentRakPeer12shutdownJobsEv
__int64 __fastcall RBX::Network::ConcurrentRakPeer::shutdownJobs(RBX::Network::ConcurrentRakPeer *this)
{
  __int64 v2; // rax
  std::__shared_weak_count *v3; // r14
  __int64 v4; // rax
  __int64 result; // rax
  std::__shared_weak_count *v6; // rbx
  std::__shared_weak_count *v7[2]; // [rsp+0h] [rbp-20h] BYREF

  v2 = *((_QWORD *)this + 3); /*0x106721124*/
  *(_OWORD *)v7 = *((_OWORD *)this + 1); /*0x10672112c*/
  if ( v2 != 0 ) /*0x106721133*/
    _InterlockedIncrement64((volatile signed __int64 *)(v2 + 8)); /*0x106721135*/
  RBX::TaskScheduler::removeBlocking(a1: v7); /*0x10672113e*/
  v3 = v7[1]; /*0x106721143*/
  if ( v7[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v7[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10672115c*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(a1: v3); /*0x106721164*/
    std::__shared_weak_count::__release_weak(this: v3); /*0x10672116a*/
  }
  v4 = *((_QWORD *)this + 5); /*0x10672116f*/
  *(_OWORD *)v7 = *((_OWORD *)this + 2); /*0x106721177*/
  if ( v4 != 0 ) /*0x10672117e*/
    _InterlockedIncrement64((volatile signed __int64 *)(v4 + 8)); /*0x106721180*/
  result = RBX::TaskScheduler::removeBlocking(a1: v7); /*0x106721189*/
  v6 = v7[1]; /*0x10672118e*/
  if ( v7[1] != nullptr ) /*0x106721195*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v7[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x10672119e*/
    if ( result == 0 ) /*0x1067211a7*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x1067211af*/
      return std::__shared_weak_count::__release_weak(this: v6); /*0x1067211b5*/
    }
  }
  return result; /*0x1067211ba*/
}

// Address: 0x1067211da | Name: __ZN3RBX7Network17ConcurrentRakPeer15Send_deprecatedENSt3__110shared_ptrIKNS0_13NetworkStreamEEE14PacketPriority17PacketReliabilitycN6RakNet13SystemAddressEbPNS0_17TimeIntervalMeterEby
__int64 __fastcall RBX::Network::ConcurrentRakPeer::Send_deprecated(
        _QWORD *a1,
        _QWORD *a2,
        unsigned int a3,
        unsigned int a4,
        char a5,
        int a6,
        __int128 a7,
        __int128 a8,
        __int64 a9,
        char a10,
        __int64 a11)
{
  char v14; // r14
  __int64 v15; // r15
  unsigned int v16; // eax
  RBX::Network *v17; // rdi
  _QWORD *v18; // rcx
  int v19; // eax
  __int64 v20; // rdx
  __int64 v21; // r8
  __int64 v22; // r9
  unsigned __int8 v23; // r15
  unsigned int v24; // eax
  __int64 v25; // r15
  __int64 v26; // rax
  __int64 v27; // rbx
  unsigned int v28; // ebx
  __int64 v29; // rax
  __int64 v30; // rbx
  std::__shared_weak_count *v31; // r14
  std::__shared_weak_count *v33[2]; // [rsp+20h] [rbp-A0h] BYREF
  unsigned int v34; // [rsp+30h] [rbp-90h]
  unsigned int v35; // [rsp+34h] [rbp-8Ch]
  char v36; // [rsp+38h] [rbp-88h]
  __int128 v37; // [rsp+3Ch] [rbp-84h]
  __int128 v38; // [rsp+4Ch] [rbp-74h]
  __int64 v39; // [rsp+60h] [rbp-60h]
  char v40; // [rsp+68h] [rbp-58h]
  std::__shared_weak_count *v41[2]; // [rsp+70h] [rbp-50h] BYREF
  unsigned int v42; // [rsp+8Ch] [rbp-34h]
  unsigned int v43; // [rsp+90h] [rbp-30h]
  int v44; // [rsp+94h] [rbp-2Ch]

  v44 = a6; /*0x1067211ee*/
  v42 = a4; /*0x1067211f5*/
  v43 = a3; /*0x1067211f8*/
  v14 = a10; /*0x106721201*/
  v15 = a9; /*0x106721205*/
  v16 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*a2 + 24LL))(a1: *a2); /*0x10672120f*/
  v18 = a1 + 7; /*0x106721212*/
  if ( v15 != 0 ) /*0x106721219*/
    v18 = (_QWORD *)v15; /*0x106721219*/
  *v18 += v16; /*0x10672121f*/
  if ( (unsigned __int8)RBX::Network::flagsSendsGoThroughConnection(this: v17) == 0 /*0x106721250*/
    && *RBX::Profiler::active != 0
    && *RBX::Profiler::mpNetVerbosity != 0 )
  {
    v19 = *(unsigned __int8 *)(*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*a2 + 16LL))(a1: *a2); /*0x10672125f*/
    if ( v19 > 140 ) /*0x106721267*/
    {
      if ( v19 > 164 ) /*0x10672126e*/
      {
        if ( v19 == 165 ) /*0x1067212af*/
        {
          v23 = 30; /*0x106721313*/
        }
        else
        {
          if ( v19 != 166 ) /*0x1067212b6*/
            goto LABEL_26; /*0x1067212b6*/
          v23 = 3; /*0x1067212bc*/
        }
      }
      else if ( v19 == 141 ) /*0x106721275*/
      {
        v23 = 15; /*0x10672130e*/
      }
      else
      {
        if ( v19 != 161 ) /*0x106721280*/
          goto LABEL_26; /*0x106721280*/
        v23 = 1; /*0x106721286*/
      }
      goto LABEL_25; /*0x106721289*/
    }
    if ( v19 != 27 ) /*0x106721291*/
    {
      if ( v19 == 131 ) /*0x106721298*/
      {
        v23 = 31; /*0x106721318*/
      }
      else
      {
        if ( v19 != 134 ) /*0x10672129f*/
          goto LABEL_26; /*0x10672129f*/
        v23 = 2; /*0x1067212a5*/
      }
      goto LABEL_25; /*0x1067212a8*/
    }
    if ( (*(unsigned __int8 (__fastcall **)(_QWORD, __int64, __int64, __int128 *, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD))(*(_QWORD *)*a1 + 696LL))( /*0x1067212f8*/
           a1: *a1,
           a2: 0x2000000,
           a3: v20,
           a4: &a7,
           a5: v21,
           a6: v22,
           a7,
           a8: *((_QWORD *)&a7 + 1),
           a9: a8,
           a10: *((_QWORD *)&a8 + 1)) == 0
      || *(_BYTE *)((*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*a2 + 16LL))(a1: *a2) + 9) == 0x85 )
    {
      v23 = 1; /*0x106721303*/
      if ( *(_BYTE *)((*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*a2 + 16LL))(a1: *a2) + 17) == 0x85 ) /*0x10672130a*/
      {
LABEL_25:
        v24 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*a2 + 24LL))(a1: *a2); /*0x10672131b*/
        RBX::Profiler::MicroProfileNetReplicaEvent(a1: v24, a2: 4, a3: 0, a4: v23, a5: -1); /*0x106721338*/
      }
    }
  }
LABEL_26:
  v25 = a11; /*0x10672133d*/
  if ( ((unsigned __int8)DFFlag::IntegrateSendInPeer | (unsigned __int8)v14) == 1 ) /*0x10672134c*/
  {
    v26 = a2[1]; /*0x106721352*/
    *(_OWORD *)v41 = *(_OWORD *)a2; /*0x106721359*/
    if ( v26 != 0 ) /*0x106721360*/
      _InterlockedIncrement64((volatile signed __int64 *)(v26 + 8)); /*0x106721362*/
    if ( FFlag::DebugHashTableMetrics != 0 /*0x106721399*/
      || (FFlag::SAuthWorkspaceFlagged & 1) != 0
      || FFlag::NextGenReplicatorEnabledRead == 1 && FFlag::NextGenReplicatorEnabledWrite == 1 )
    {
      v27 = *a1; /*0x10672139f*/
      RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v33, a2: (const RakNet::SystemAddress *)&a7); /*0x1067213ae*/
      v28 = (*(__int64 (__fastcall **)(__int64, std::__shared_weak_count **, _QWORD, _QWORD, _QWORD, std::__shared_weak_count **, _DWORD, _DWORD, __int64))(*(_QWORD *)v27 + 192LL))( /*0x1067213eb*/
              a1: v27,
              a2: v41,
              a3: v43,
              a4: v42,
              (unsigned int)a5,
              a6: v33,
              a7: (unsigned __int8)v44,
              a8: 0,
              a9: v25);
    }
    else
    {
      v30 = *a1; /*0x106721482*/
      RakNet::AddressOrGUID::AddressOrGUID(this: (RakNet::AddressOrGUID *)v33, a2: (const RakNet::SystemAddress *)&a7); /*0x106721491*/
      v28 = (*(__int64 (__fastcall **)(__int64, std::__shared_weak_count **, _QWORD, _QWORD, _QWORD, std::__shared_weak_count **, _DWORD, _DWORD, __int64))(*(_QWORD *)v30 + 192LL))( /*0x1067214d2*/
              a1: v30,
              a2: v41,
              a3: v43,
              a4: v42,
              (unsigned int)a5,
              a6: v33,
              a7: (unsigned __int8)v44,
              a8: 0,
              a9: v25) != 0;
    }
    v31 = v41[1]; /*0x1067214d5*/
    if ( v41[1] != nullptr /*0x1067214ee*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v41[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v31 + 16LL))(a1: v31); /*0x1067214f6*/
      std::__shared_weak_count::__release_weak(this: v31); /*0x1067214fc*/
    }
  }
  else
  {
    v29 = a2[1]; /*0x1067213f2*/
    *(_OWORD *)v33 = *(_OWORD *)a2; /*0x1067213f9*/
    if ( v29 != 0 ) /*0x106721403*/
      _InterlockedIncrement64((volatile signed __int64 *)(v29 + 8)); /*0x106721405*/
    v34 = v43; /*0x106721414*/
    v35 = v42; /*0x10672141a*/
    v36 = a5; /*0x10672141d*/
    v37 = a7; /*0x10672142c*/
    v38 = a8; /*0x106721430*/
    v39 = v25; /*0x106721434*/
    v40 = v44; /*0x10672143b*/
    rbx::timestamped_safe_queue<RBX::Network::ConcurrentRakPeer::PacketJob::SendData>::push(a1: a1[2] + 408LL); /*0x106721447*/
    if ( v33[1] != nullptr /*0x106721468*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v33[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v33[1] + 16LL))(a1: v33[1]); /*0x106721470*/
      std::__shared_weak_count::__release_weak(this: v33[1]); /*0x106721476*/
    }
    return (unsigned int)-1; /*0x10672147b*/
  }
  return v28; /*0x106721503*/
}

// Address: 0x10672165a | Name: __ZN3RBX7Network17ConcurrentRakPeer15GetBufferHealthEv
double __fastcall RBX::Network::ConcurrentRakPeer::GetBufferHealth(RBX::Network::ConcurrentRakPeer *this)
{
  RSL::Mutex *v2; // r14
  double v4; // [rsp+8h] [rbp-18h]

  v2 = (RSL::Mutex *)(*((_QWORD *)this + 4) + 408LL); /*0x10672166e*/
  RSL::Mutex::lock(this: v2); /*0x106721675*/
  v4 = *(double *)(*((_QWORD *)this + 4) + 528LL); /*0x106721686*/
  RSL::Mutex::unlock(this: v2); /*0x10672168e*/
  return v4; /*0x106721698*/
}

// Address: 0x1067216aa | Name: __ZNK3RBX7Network17ConcurrentRakPeer13GetStatisticsEN6RakNet13SystemAddressE
_QWORD *__fastcall RBX::Network::ConcurrentRakPeer::GetStatistics(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  RSL::Mutex *v8; // rbx
  _QWORD *v9; // r14

  v8 = (RSL::Mutex *)(*(_QWORD *)(a1 + 32) + 408LL); /*0x1067216bd*/
  RSL::Mutex::lock(this: v8); /*0x1067216cc*/
  v9 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>>,RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>>::operator[]( /*0x1067216e3*/
         a1: (_QWORD *)(*(_QWORD *)(a1 + 32) + 416LL),
         a2: (RakNet::SystemAddress *)&a7);
  RSL::Mutex::unlock(this: v8); /*0x1067216e9*/
  return v9 + 41; /*0x1067216f8*/
}

// Address: 0x10672171e | Name: __ZN3RBX7Network17ConcurrentRakPeer20GetBandwidthExceededEN6RakNet13SystemAddressE
double __fastcall RBX::Network::ConcurrentRakPeer::GetBandwidthExceeded(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  RSL::Mutex *v8; // rbx
  double v10; // [rsp+18h] [rbp-18h]

  v8 = (RSL::Mutex *)(*(_QWORD *)(a1 + 32) + 408LL); /*0x106721731*/
  RSL::Mutex::lock(this: v8); /*0x106721740*/
  v10 = *((double *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>>,RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>>::operator[]( /*0x10672175f*/
                      a1: (_QWORD *)(*(_QWORD *)(a1 + 32) + 416LL),
                      a2: (RakNet::SystemAddress *)&a7)
        + 23);
  RSL::Mutex::unlock(this: v8); /*0x106721767*/
  return v10; /*0x106721771*/
}

// Address: 0x106721796 | Name: __ZN3RBX7Network17ConcurrentRakPeer28GetCongestionControlExceededEN6RakNet13SystemAddressE
double __fastcall RBX::Network::ConcurrentRakPeer::GetCongestionControlExceeded(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        char a7)
{
  RSL::Mutex *v8; // rbx
  double v10; // [rsp+18h] [rbp-18h]

  v8 = (RSL::Mutex *)(*(_QWORD *)(a1 + 32) + 408LL); /*0x1067217a9*/
  RSL::Mutex::lock(this: v8); /*0x1067217b8*/
  v10 = *((double *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>>,RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>>::operator[]( /*0x1067217d7*/
                      a1: (_QWORD *)(*(_QWORD *)(a1 + 32) + 416LL),
                      a2: (RakNet::SystemAddress *)&a7)
        + 28);
  RSL::Mutex::unlock(this: v8); /*0x1067217df*/
  return v10; /*0x1067217e9*/
}

// Address: 0x10672180e | Name: __ZN3RBX7Network17ConcurrentRakPeer7rawPeerEv
__int64 __fastcall RBX::Network::ConcurrentRakPeer::rawPeer(RBX::Network::ConcurrentRakPeer *this)
{
  return *(_QWORD *)this; /*0x106721815*/
}

// Address: 0x106721818 | Name: __ZNK3RBX7Network17ConcurrentRakPeer7rawPeerEv
__int64 __fastcall RBX::Network::ConcurrentRakPeer::rawPeer(RBX::Network::ConcurrentRakPeer *this)
{
  return *(_QWORD *)this; /*0x10672181f*/
}

// END ConcurrentRakPeer part 1/1, 16 functions
