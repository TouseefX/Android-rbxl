// ServerSchemaInfo -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 1 functions


// Address: 0x10689282c | Name: __ZN3RBX7Network16ServerSchemaInfoC2Ev
__int64 __fastcall RBX::Network::ServerSchemaInfo::ServerSchemaInfo(RBX::Network::ServerSchemaInfo *this)
{
  __int64 result; // rax

  RBX::make_shared<RBX::Network::NetworkStream>(a1: this); /*0x106892836*/
  result = RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::ServerSchemaInfo *)((char *)this + 16)); /*0x10689283f*/
  *((_OWORD *)this + 6) = 0; /*0x106892847*/
  *((_OWORD *)this + 5) = 0; /*0x10689284b*/
  *((_QWORD *)this + 14) = 0; /*0x10689284f*/
  return result; /*0x106892857*/
}

// END ServerSchemaInfo part 1/1, 1 functions
