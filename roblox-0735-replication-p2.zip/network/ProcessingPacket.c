// ProcessingPacket -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 8 functions


// Address: 0x10681cd0a | Name: __ZN3RBX7Network16ProcessingPacket8initFromEPN6RakNet6PacketE
__int64 __fastcall RBX::Network::ProcessingPacket::initFrom(__int64 a1, __int64 a2)
{
  *(_QWORD *)a1 = a2; /*0x10681cd17*/
  *(_QWORD *)(a1 + 8) = 0; /*0x10681cd1a*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)(a1 + 16)); /*0x10681cd26*/
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::UnboundedCircularBuffer( /*0x10681cd34*/
    a1: a1 + 80,
    a2: 8u);
  *(_DWORD *)(a1 + 115) = 0; /*0x10681cd3b*/
  *(_DWORD *)(a1 + 112) = 0; /*0x10681cd3f*/
  *(_BYTE *)(a1 + 117) = a2 != 0; /*0x10681cd46*/
  *(_BYTE *)(a1 + 118) = 1; /*0x10681cd4b*/
  return a1; /*0x10681cd53*/
}

// Address: 0x10682daa4 | Name: __ZN3RBX7Network16ProcessingPacketC2EPN6RakNet6PacketE
__int64 __fastcall RBX::Network::ProcessingPacket::ProcessingPacket(__int64 a1, __int64 a2)
{
  *(_QWORD *)a1 = a2; /*0x10682daad*/
  *(_QWORD *)(a1 + 8) = 0; /*0x10682dab0*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)(a1 + 16)); /*0x10682dabc*/
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::UnboundedCircularBuffer( /*0x10682daca*/
    a1: a1 + 80,
    a2: 8u);
  *(_DWORD *)(a1 + 115) = 0; /*0x10682dad1*/
  *(_DWORD *)(a1 + 112) = 0; /*0x10682dad4*/
  return 0; /*0x10682dadb*/
}

// Address: 0x10682dade | Name: __ZN3RBX7Network16ProcessingPacketC1EPN6RakNet6PacketE
__int64 __fastcall RBX::Network::ProcessingPacket::ProcessingPacket(__int64 a1, __int64 a2)
{
  *(_QWORD *)a1 = a2; /*0x10682dae7*/
  *(_QWORD *)(a1 + 8) = 0; /*0x10682daea*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)(a1 + 16)); /*0x10682daf6*/
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::UnboundedCircularBuffer( /*0x10682db04*/
    a1: a1 + 80,
    a2: 8u);
  *(_DWORD *)(a1 + 115) = 0; /*0x10682db0b*/
  *(_DWORD *)(a1 + 112) = 0; /*0x10682db0e*/
  return 0; /*0x10682db15*/
}

// Address: 0x10682db18 | Name: __ZN3RBX7Network16ProcessingPacket8moveFromERS1_RKNS_4TimeE
RBX::Network::ProcessingPacket *__fastcall RBX::Network::ProcessingPacket::moveFrom(
        RBX::Network::ProcessingPacket *this,
        RBX::Network::ProcessingPacket *a2,
        const RBX::Time *a3)
{
  int v6; // ecx
  char v7; // al

  *(_OWORD *)this = 0; /*0x10682db36*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::ProcessingPacket *)((char *)this + 16)); /*0x10682db3a*/
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::UnboundedCircularBuffer( /*0x10682db4b*/
    a1: (__int64)this + 80,
    a2: 8u);
  *(_DWORD *)((char *)this + 115) = 0; /*0x10682db52*/
  *((_DWORD *)this + 28) = 0; /*0x10682db56*/
  *(_QWORD *)this = *(_QWORD *)a2; /*0x10682db5d*/
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::operator=( /*0x10682db6a*/
    a1: (__int64)this + 80,
    a2: (__int64 *)a2 + 10);
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::clear(a1: (__int64 *)a2 + 10); /*0x10682db72*/
  v6 = *((_DWORD *)a2 + 28); /*0x10682db77*/
  v7 = *((_BYTE *)a2 + 118); /*0x10682db7b*/
  if ( v6 == 0 ) /*0x10682db81*/
  {
    if ( (v7 & 1) != 0 ) /*0x10682db85*/
    {
      v6 = 0; /*0x10682db87*/
    }
    else
    {
      v6 = 0; /*0x10682db8e*/
      if ( *(_QWORD *)a2 != 0 ) /*0x10682db96*/
        v6 = *(_DWORD *)(*(_QWORD *)a2 + 48LL); /*0x10682db98*/
    }
  }
  *((_DWORD *)this + 28) = v6; /*0x10682db9b*/
  *((_BYTE *)this + 116) = *((_BYTE *)a2 + 116); /*0x10682dba3*/
  *((_BYTE *)this + 117) = *((_BYTE *)a2 + 117); /*0x10682dbab*/
  *((_BYTE *)this + 118) = v7; /*0x10682dbaf*/
  *((_QWORD *)this + 1) = *(_QWORD *)a3; /*0x10682dbb6*/
  return this; /*0x10682dbc1*/
}

// Address: 0x10682dbcc | Name: __ZNK3RBX7Network16ProcessingPacket10isFinishedEv
bool __fastcall RBX::Network::ProcessingPacket::isFinished(RBX::Network::ProcessingPacket *this)
{
  bool result; // al

  result = true; /*0x10682dbcf*/
  if ( *(_QWORD *)this != 0 ) /*0x10682dbd4*/
  {
    if ( *((_QWORD *)this + 13) != 0 ) /*0x10682dbdb*/
    {
      return false; /*0x10682dbdd*/
    }
    else if ( *((_BYTE *)this + 118) == 1 ) /*0x10682dbe8*/
    {
      return *((_DWORD *)this + 28) == *(_DWORD *)(*(_QWORD *)this + 48LL); /*0x10682dbf2*/
    }
  }
  return result; /*0x10682dbdf*/
}

// Address: 0x10682dbf6 | Name: __ZNK3RBX7Network16ProcessingPacket18hasUnprocessedDataEv
char __fastcall RBX::Network::ProcessingPacket::hasUnprocessedData(RBX::Network::ProcessingPacket *this)
{
  char result; // al

  if ( *(_QWORD *)this == 0 ) /*0x10682dbfc*/
    return 0; /*0x10682dc08*/
  result = 1; /*0x10682dbfe*/
  if ( *((_QWORD *)this + 13) == 0 /*0x10682dc1b*/
    && (*((_BYTE *)this + 118) != 1 || *((_DWORD *)this + 28) == *(_DWORD *)(*(_QWORD *)this + 48LL)) )
  {
    return 0; /*0x10682dc1d*/
  }
  return result; /*0x10682dc07*/
}

// Address: 0x10682dc22 | Name: __ZNK3RBX7Network16ProcessingPacket5emptyEv
bool __fastcall RBX::Network::ProcessingPacket::empty(RBX::Network::ProcessingPacket *this)
{
  return *(_QWORD *)this == 0; /*0x10682dc2d*/
}

// Address: 0x10682dc30 | Name: __ZN3RBX7Network16ProcessingPacket12markFinishedEv
__int64 __fastcall RBX::Network::ProcessingPacket::markFinished(RBX::Network::ProcessingPacket *this)
{
  __int64 result; // rax

  if ( *(_QWORD *)this != 0 ) /*0x10682dc36*/
    result = *(unsigned int *)(*(_QWORD *)this + 48LL); /*0x10682dc3c*/
  else
    result = 0; /*0x10682dc42*/
  *((_DWORD *)this + 28) = result; /*0x10682dc44*/
  return result; /*0x10682dc47*/
}

// END ProcessingPacket part 1/1, 8 functions
