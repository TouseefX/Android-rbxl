// ReplicatorJob -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 3 functions


// Address: 0x106819bce | Name: __ZN3RBX7Network13ReplicatorJobC2EPKcRNS0_10ReplicatorENS_10DMTaskTypeENS_11JobPriorityE
__int64 __fastcall RBX::Network::ReplicatorJob::ReplicatorJob(
        _QWORD *a1,
        RBX::Instance *a2,
        RBX::DataModel *a3,
        unsigned int a4,
        unsigned int a5)
{
  __int64 v9; // rax
  std::__shared_weak_count *v10; // r15
  _BYTE v12[8]; // [rsp+0h] [rbp-40h] BYREF
  std::__shared_weak_count *v13; // [rsp+8h] [rbp-38h]
  RBX::DataModel *v14; // [rsp+10h] [rbp-30h]

  v14 = a3; /*0x106819beb*/
  v9 = RBX::DataModel::get(this: a3, a2); /*0x106819bf2*/
  RBX::shared_from<RBX::DataModel>(a1: v12, a2: v9); /*0x106819c01*/
  ((void (__fastcall *)(_QWORD *, RBX::Instance *, _QWORD, __int64, _BYTE *, _QWORD))RBX::DataModelJob::DataModelJob)( /*0x106819c1a*/
    a1,
    a2,
    a3: a4,
    a4: 1,
    a5: v12,
    a6: a5);
  v10 = v13; /*0x106819c1f*/
  if ( v13 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v13 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x106819c38*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x106819c40*/
    std::__shared_weak_count::__release_weak(this: v10); /*0x106819c46*/
  }
  *a1 = &off_10CAB2260; /*0x106819c52*/
  return RBX::shared_from<RBX::Network::Replicator>(a1: a1 + 51, a2: v14); /*0x106819c65*/
}

// Address: 0x10876756c | Name: __ZN3RBX7Network13ReplicatorJobD1Ev
void __fastcall __noreturn RBX::Network::ReplicatorJob::~ReplicatorJob(RBX::Network::ReplicatorJob *this)
{
  BUG(); /*0x108767570*/
}

// Address: 0x10876ba48 | Name: __ZN3RBX7Network13ReplicatorJobD0Ev
void __fastcall __noreturn RBX::Network::ReplicatorJob::~ReplicatorJob(RBX::Network::ReplicatorJob *this)
{
  BUG(); /*0x10876ba4c*/
}

// END ReplicatorJob part 1/1, 3 functions
