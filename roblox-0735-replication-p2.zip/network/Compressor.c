// Compressor -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 10 functions


// Address: 0x10671f5b4 | Name: __ZN3RBX7Network10Compressor16writeTranslationERNS0_13NetworkStreamERKNS_7Vector3E
__int64 __fastcall RBX::Network::Compressor::writeTranslation(
        RBX::Network::Compressor *this,
        RBX::Network::NetworkStream *a2,
        const RBX::Vector3 *a3)
{
  float v4; // xmm2_4
  _BOOL8 v5; // r12
  float v6; // xmm0_4
  int v7; // r13d
  int v8; // r15d
  int v9; // r14d
  __m128 v10; // xmm0
  float v11; // xmm1_4
  int v12; // r15d
  __m128i v13; // xmm1
  int v14; // r12d
  float v15; // xmm4_4
  __m128 v16; // xmm2
  __m128 v17; // xmm3
  unsigned int v18; // r15d
  __m128i v19; // xmm1
  RBX::Network::NetworkStream *v20; // rdi
  unsigned int v21; // edx
  unsigned int v22; // r13d
  unsigned int v23; // r15d
  float v24; // xmm0_4
  int v25; // r12d
  __m128 v27; // [rsp+0h] [rbp-60h]
  int v28; // [rsp+1Ch] [rbp-44h] BYREF
  __m128i v29; // [rsp+20h] [rbp-40h] BYREF
  _DWORD v30[11]; // [rsp+34h] [rbp-2Ch] BYREF

  v4 = *(float *)a2; /*0x10671f5c8*/
  v5 = *(float *)a2 >= 0.0; /*0x10671f5d5*/
  v29 = (__m128i)*(unsigned int *)a2; /*0x10671f5e0*/
  v27 = (__m128)*(unsigned __int64 *)((char *)a2 + 4); /*0x10671f5f0*/
  v6 = fmaxf(fabs(_mm_movehdup_ps(v27).f32[0]), fmaxf(fabs(COERCE_FLOAT(*(_QWORD *)((char *)a2 + 4))), fabs(v4))); /*0x10671f5fe*/
  v7 = 0; /*0x10671f602*/
  v28 = 0; /*0x10671f609*/
  frexpf(a1: v6, a2: &v28); /*0x10671f60f*/
  v8 = v28; /*0x10671f614*/
  if ( v28 > 0 ) /*0x10671f61a*/
    v7 = v28; /*0x10671f61a*/
  v9 = 31; /*0x10671f622*/
  if ( v7 < 31 ) /*0x10671f628*/
    v9 = v7; /*0x10671f628*/
  v10.f32[0] = ldexpf(a1: 1.0, a2: v9); /*0x10671f637*/
  v11 = flt_1096F7C88[v5]; /*0x10671f643*/
  if ( v8 <= 4 ) /*0x10671f64d*/
  {
    v12 = (int)(float)(v11 + (float)(fminf(fmaxf(*(float *)v29.i32 / v10.f32[0], -1.0), 1.0) * 1023.0)); /*0x10671f677*/
    v29 = _mm_cvttps_epi32( /*0x10671f6c3*/
            _mm_add_ps(
              _mm_blendv_ps((__m128)xmmword_108F302B0, (__m128)xmmword_108F39940, _mm_cmple_ps((__m128)0LL, v27)),
              _mm_mul_ps(
                _mm_min_ps(
                  _mm_max_ps(_mm_div_ps(v27, _mm_moveldup_ps(v10)), (__m128)xmmword_108F4BCC0),
                  (__m128)xmmword_108F2F400),
                (__m128)xmmword_1099FD760)));
    v13 = _mm_and_si128( /*0x10671f6e7*/
            _mm_blend_epi16(_mm_srli_epi32(v29, 9u), _mm_srli_epi32(v29, 0xAu), 12),
            (__m128i)xmmword_1099ED2B0);
    v14 = _mm_extract_epi32(v29, 1) & 0x3FF; /*0x10671f6fb*/
    LOBYTE(v30[0]) = ((BYTE1(v12) & 4) + 8 * v9) | _mm_cvtsi128_si32(v13) | _mm_extract_epi32(v13, 1); /*0x10671f708*/
    RBX::Network::NetworkStream::writeBytes(this, a2: v30, a3: 1u); /*0x10671f716*/
    v30[0] = (v12 << 20) & 0x3FF00000 | v14 | (_mm_cvtsi128_si32(_mm_load_si128(&v29)) << 10) & 0xFFC00; /*0x10671f73d*/
LABEL_10:
    v20 = this; /*0x10671f907*/
    v21 = 4; /*0x10671f90e*/
    return RBX::Network::NetworkStream::writeBytes(this: v20, a2: v30, a3: v21); /*0x10671f90e*/
  }
  v15 = fminf(fmaxf(*(float *)v29.i32 / v10.f32[0], -1.0), 1.0); /*0x10671f755*/
  v16 = _mm_min_ps( /*0x10671f779*/
          _mm_max_ps(_mm_div_ps(v27, _mm_moveldup_ps(v10)), (__m128)xmmword_108F4BCC0),
          (__m128)xmmword_108F2F400);
  v17 = _mm_blendv_ps((__m128)xmmword_108F302B0, (__m128)xmmword_108F39940, _mm_cmple_ps((__m128)0LL, v27)); /*0x10671f787*/
  if ( (unsigned int)v8 > 0xA ) /*0x10671f794*/
  {
    v22 = (int)(float)(v11 + (float)(v15 * 2097151.0)); /*0x10671f869*/
    v23 = (int)(float)((float)(v16.f32[0] * 2097151.0) + v17.f32[0]); /*0x10671f87a*/
    v24 = _mm_movehdup_ps(v17).f32[0] + (float)(_mm_movehdup_ps(v16).f32[0] * 2097151.0); /*0x10671f887*/
    v25 = (int)v24 & 0x1FFFFF; /*0x10671f899*/
    LOBYTE(v30[0]) = (((int)v24 & 0x200000) != 0) | (((v22 >> 19) & 4) + 8 * v9) | (v23 >> 20) & 2; /*0x10671f8be*/
    RBX::Network::NetworkStream::writeBytes(this, a2: v30, a3: 1u); /*0x10671f8cc*/
    v30[0] = (v22 << 11) | (v23 >> 10) & 0x7FF; /*0x10671f8e3*/
    RBX::Network::NetworkStream::writeBytes(this, a2: v30, a3: 4u); /*0x10671f8f1*/
    v30[0] = v25 | (v23 << 21) & 0x7FE00000; /*0x10671f904*/
    goto LABEL_10; /*0x10671f904*/
  }
  v18 = (int)(float)(v11 + (float)(v15 * 65535.0)); /*0x10671f7a6*/
  v29 = _mm_cvttps_epi32(_mm_add_ps(v17, _mm_mul_ps(v16, (__m128)xmmword_1099FD750))); /*0x10671f7c2*/
  v19 = _mm_and_si128( /*0x10671f7db*/
          _mm_blend_epi16(_mm_srli_epi32(v29, 0xFu), _mm_srli_epi32(v29, 0x10u), 12),
          (__m128i)xmmword_1099ED2B0);
  LOBYTE(v30[0]) = (((v18 >> 14) & 4) + 8 * v9) | _mm_cvtsi128_si32(v19) | _mm_extract_epi32(v19, 1); /*0x10671f7f9*/
  RBX::Network::NetworkStream::writeBytes(this, a2: v30, a3: 1u); /*0x10671f807*/
  LOWORD(v30[0]) = v18; /*0x10671f80c*/
  RBX::Network::NetworkStream::writeBytes(this, a2: v30, a3: 2u); /*0x10671f81b*/
  LOWORD(v30[0]) = _mm_extract_epi16(_mm_load_si128(&v29), 0); /*0x10671f825*/
  RBX::Network::NetworkStream::writeBytes(this, a2: v30, a3: 2u); /*0x10671f837*/
  LOWORD(v30[0]) = _mm_extract_epi16(_mm_load_si128(&v29), 2); /*0x10671f841*/
  v20 = this; /*0x10671f84c*/
  v21 = 2; /*0x10671f84f*/
  return RBX::Network::NetworkStream::writeBytes(this: v20, a2: v30, a3: v21); /*0x10671f918*/
}

// Address: 0x10671f928 | Name: __ZN3RBX7Network10Compressor15readTranslationERNS0_13NetworkStreamERNS_7Vector3E
void __fastcall RBX::Network::Compressor::readTranslation(
        RBX::Network::Compressor *this,
        RBX::Network::NetworkStream *a2,
        RBX::Vector3 *a3)
{
  unsigned __int8 Byte; // al
  int v6; // r14d
  int v7; // ebx
  int v8; // r13d
  int v9; // eax
  int v10; // r14d
  int v11; // ebx
  int v12; // r15d
  int v13; // r13d
  int v14; // xmm0_4
  unsigned int UInt32; // r12d
  unsigned int v16; // eax
  float v17; // xmm0_4
  RBX::Network::NetworkStream *v18; // [rsp+0h] [rbp-40h]
  unsigned int v19; // [rsp+Ch] [rbp-34h]
  int v20; // [rsp+14h] [rbp-2Ch]
  float v21; // [rsp+14h] [rbp-2Ch]

  Byte = RBX::Network::NetworkStream::readByte(this); /*0x10671f93f*/
  v6 = Byte >> 2; /*0x10671f94a*/
  v7 = (Byte & 4) != 0; /*0x10671f951*/
  v8 = (Byte & 2) != 0; /*0x10671f95a*/
  v19 = Byte; /*0x10671f963*/
  v20 = Byte & 1; /*0x10671f969*/
  if ( Byte > 0x27u ) /*0x10671f96c*/
  {
    v18 = a2; /*0x10671f9c3*/
    v13 = v8 << 31; /*0x10671f9c7*/
    if ( Byte > 0x57u ) /*0x10671f9d0*/
    {
      UInt32 = RBX::Network::NetworkStream::readUInt32(this); /*0x10671fa31*/
      v16 = RBX::Network::NetworkStream::readUInt32(this); /*0x10671fa37*/
      v10 = (int)(__PAIR64__(v6, UInt32) >> 1) >> 10; /*0x10671fa57*/
      v11 = (int)(v13 | (((UInt32 << 10) & 0x1FFC00 | (v16 >> 21)) << 10)) >> 10; /*0x10671fa61*/
      v12 = (int)((v20 << 31) | (v16 << 10) & 0x7FFFFC00) >> 10; /*0x10671fa78*/
      v14 = 1241513976; /*0x10671fa7c*/
    }
    else
    {
      v10 = ((v7 << 31) | ((unsigned __int16)RBX::Network::NetworkStream::readUInt16(this) << 15)) >> 15; /*0x10671f9fc*/
      v11 = (v13 | ((unsigned __int16)RBX::Network::NetworkStream::readUInt16(this) << 15)) >> 15; /*0x10671fa0a*/
      v12 = ((v20 << 31) | ((unsigned __int16)RBX::Network::NetworkStream::readUInt16(this) << 15)) >> 15; /*0x10671fa1e*/
      v14 = 1199570688; /*0x10671fa22*/
    }
    v21 = *(float *)&v14; /*0x10671fa84*/
    a2 = v18; /*0x10671fa89*/
  }
  else
  {
    v9 = RBX::Network::NetworkStream::readUInt32(this); /*0x10671f971*/
    v10 = ((v7 << 31) | (2 * v9)) >> 21; /*0x10671f983*/
    v11 = ((v8 << 31) | (v9 << 11) & 0x7FE00000) >> 21; /*0x10671f99a*/
    v12 = ((v20 << 31) | (v9 << 21) & 0x7FE00000) >> 21; /*0x10671f9ad*/
    v21 = 1023.0; /*0x10671f9b9*/
  }
  v17 = ldexpf(a1: 1.0, a2: v19 >> 3); /*0x10671fa9b*/
  *(float *)a2 = (float)((float)v10 / v21) * v17; /*0x10671fab2*/
  *((float *)a2 + 1) = (float)((float)v11 / v21) * v17; /*0x10671facc*/
  *((float *)a2 + 2) = (float)((float)v12 / v21) * v17; /*0x10671fadb*/
}

// Address: 0x10671faf2 | Name: __ZN3RBX7Network10Compressor13writeRotationERNS0_13NetworkStreamERKNS_7Matrix3E
__int64 __fastcall RBX::Network::Compressor::writeRotation(
        RBX::Network::Compressor *this,
        RBX::Network::NetworkStream *a2,
        const RBX::Matrix3 *a3)
{
  __m128 v4; // xmm1
  __m128 v5; // xmm1
  float v6; // xmm2_4
  __m128 v7; // xmm1
  __m128 v8; // xmm1
  __m128i v9; // xmm2
  _BOOL8 v10; // rax
  __int64 v11; // rcx
  __int64 v12; // r15
  __m128 v13; // xmm5
  __m128 v14; // xmm6
  int v15; // eax
  __m128 v16; // xmm6
  int v17; // r12d
  __m128 v18; // xmm0
  int v19; // r13d
  __m128 v21; // [rsp+0h] [rbp-60h] BYREF
  int v22; // [rsp+1Ch] [rbp-44h] BYREF
  __m128 v23; // [rsp+20h] [rbp-40h]

  RBX::Quaternion::Quaternion(this: (RBX::Quaternion *)&v21, a2); /*0x10671fb1b*/
  v4 = _mm_mul_ps(v21, v21); /*0x10671fb27*/
  v5 = _mm_hadd_ps(v4, v4); /*0x10671fb2a*/
  v6 = fsqrt(_mm_hadd_ps(v5, v5).f32[0]); /*0x10671fb32*/
  v7 = (__m128)0x3F800000u; /*0x10671fb36*/
  v7.f32[0] = 1.0 / v6; /*0x10671fb3e*/
  v8 = _mm_mul_ps(_mm_shuffle_ps(v7, v7, 0), v21); /*0x10671fb46*/
  v9 = (__m128i)_mm_and_ps(v8, (__m128)xmmword_108F46760); /*0x10671fb53*/
  v10 = *(float *)_mm_shuffle_epi32(v9, 245).i32 > *(float *)v9.i32; /*0x10671fb60*/
  v23 = v8; /*0x10671fb63*/
  v11 = 2; /*0x10671fb7d*/
  if ( fabs(*(float *)_mm_unpackhi_pd((__m128d)v8, (__m128d)v8).f64) <= fabs(v23.f32[v10]) ) /*0x10671fb82*/
    v11 = v10; /*0x10671fb82*/
  v21 = v8; /*0x10671fb85*/
  v12 = 3; /*0x10671fb9f*/
  if ( fabs(_mm_shuffle_ps(v8, v8, 255).f32[0]) <= fabs(v23.f32[v11]) ) /*0x10671fba5*/
    v12 = (unsigned int)v11; /*0x10671fba5*/
  if ( v23.f32[v12] < 0.0 ) /*0x10671fbb2*/
    v23 = _mm_xor_ps(v8, *(__m128 *)&xmmword_108F246C0); /*0x10671fbbb*/
  v13.i32[0] = v23.i32[RBX::Network::kRotationAxisTable[3 * v12]]; /*0x10671fbd8*/
  v14 = _mm_cmple_ss((__m128)0LL, v13); /*0x10671fbe9*/
  v15 = (int)(float)(COERCE_FLOAT(COERCE_UNSIGNED_INT(_mm_andnot_ps(v14, (__m128)0xBF000000).f32[0]) | v14.i32[0] & 0x3F000000) /*0x10671fc1e*/
                   + (float)((float)(v13.f32[0] / 0.70710677) * 16383.0));
  v13.i32[0] = v23.i32[RBX::Network::kRotationAxisTable[3 * v12 + 1]]; /*0x10671fc22*/
  v16 = _mm_cmple_ss((__m128)0LL, v13); /*0x10671fc2b*/
  v17 = (int)(float)(COERCE_FLOAT(COERCE_UNSIGNED_INT(_mm_andnot_ps(v16, (__m128)0xBF000000).f32[0]) | v16.i32[0] & 0x3F000000) /*0x10671fc48*/
                   + (float)((float)(v13.f32[0] / 0.70710677) * 16383.0));
  v13.i32[0] = v23.i32[RBX::Network::kRotationAxisTable[3 * v12 + 2]]; /*0x10671fc4d*/
  v18 = _mm_cmple_ss((__m128)0LL, v13); /*0x10671fc53*/
  v19 = (int)(float)(COERCE_FLOAT(COERCE_UNSIGNED_INT(_mm_andnot_ps(v18, (__m128)0xBF000000).f32[0]) | v18.i32[0] & 0x3F000000) /*0x10671fc77*/
                   + (float)((float)(v13.f32[0] / 0.70710677) * 16383.0))
      & 0x7FFF;
  LOWORD(v22) = v15 & 0x7FFF; /*0x10671fc80*/
  RBX::Network::NetworkStream::writeBytes(this, a2: &v22, a3: 2u); /*0x10671fc8f*/
  v22 = v19 | ((_DWORD)v12 << 30) | (v17 << 15) & 0x3FFF8000; /*0x10671fca9*/
  RBX::Network::NetworkStream::writeBytes(this, a2: &v22, a3: 4u); /*0x10671fcb8*/
  return __stack_chk_guard; /*0x10671fccd*/
}

// Address: 0x10671fce2 | Name: __ZN3RBX7Network10Compressor12readRotationERNS0_13NetworkStreamERNS_7Matrix3E
__int64 __fastcall RBX::Network::Compressor::readRotation(
        RBX::Network::Compressor *this,
        RBX::Network::NetworkStream *a2,
        RBX::Matrix3 *a3)
{
  int UInt16; // r14d
  unsigned int UInt32; // eax
  __m128i v7; // xmm1
  float v8; // xmm0_4
  float v9; // xmm0_4
  __int64 v10; // rdi
  __m128 v11; // xmm1
  __int64 v12; // rcx
  __m128 v13; // xmm1
  float v14; // xmm2_4
  __m128 v15; // xmm0
  __m128 v16; // xmm2
  __m128 v17; // xmm2
  __m128 v19; // [rsp+0h] [rbp-40h] BYREF
  __m128 v20; // [rsp+10h] [rbp-30h]

  UInt16 = RBX::Network::NetworkStream::readUInt16(this); /*0x10671fd08*/
  UInt32 = RBX::Network::NetworkStream::readUInt32(this); /*0x10671fd0e*/
  v7 = _mm_cvtsi32_si128(UInt32); /*0x10671fd21*/
  v8 = (float)((int)(4 * UInt32) >> 17) / 16383.0; /*0x10671fd25*/
  UInt32 >>= 30; /*0x10671fd2d*/
  v9 = v8 * 0.70710677; /*0x10671fd30*/
  v10 = RBX::Network::kRotationAxisTable[3 * UInt32 + 1]; /*0x10671fd4e*/
  v11 = _mm_mul_ps( /*0x10671fd67*/
          _mm_div_ps(
            _mm_cvtepi32_ps(_mm_srai_epi32(_mm_slli_epi32(_mm_insert_epi32(v7, UInt16, 1), 0x11u), 0x11u)),
            (__m128)xmmword_1099FD770),
          (__m128)xmmword_10A44F4F0);
  v12 = RBX::Network::kRotationAxisTable[3 * UInt32 + 2]; /*0x10671fd6e*/
  v20.i32[RBX::Network::kRotationAxisTable[3 * UInt32]] = _mm_extract_ps(v11, 1); /*0x10671fd73*/
  v20.f32[v10] = v9; /*0x10671fd7b*/
  v20.i32[v12] = v11.i32[0]; /*0x10671fd85*/
  v13 = _mm_mul_ps(v11, v11); /*0x10671fd8b*/
  v14 = (float)(_mm_movehdup_ps(v13).f32[0] + (float)(v9 * v9)) + v13.f32[0]; /*0x10671fd96*/
  v15 = (__m128)0x3F800000u; /*0x10671fd9a*/
  v20.f32[UInt32] = fsqrt(fmaxf(1.0 - v14, 0.0)); /*0x10671fdb4*/
  v16 = _mm_mul_ps(v20, v20); /*0x10671fdc1*/
  v17 = _mm_hadd_ps(v16, v16); /*0x10671fdc4*/
  v15.f32[0] = 1.0 / fsqrt(_mm_hadd_ps(v17, v17).f32[0]); /*0x10671fdd0*/
  v19 = _mm_mul_ps(_mm_shuffle_ps(v15, v15, 0), v20); /*0x10671fddf*/
  RBX::Quaternion::toRotationMatrix(this: (RBX::Quaternion *)&v19, a2); /*0x10671fde5*/
  return __stack_chk_guard; /*0x10671fdfa*/
}

// Address: 0x10671fe0a | Name: __ZN3RBX7Network10Compressor20writeRotationCompactERNS0_13NetworkStreamERKNS_7Matrix3E
__int64 __fastcall RBX::Network::Compressor::writeRotationCompact(
        RBX::Network::Compressor *this,
        RBX::Network::NetworkStream *a2,
        const RBX::Matrix3 *a3)
{
  __m128 v4; // xmm0
  __m128 v5; // xmm0
  float v6; // xmm2_4
  __m128 v7; // xmm0
  __m128 v8; // xmm0
  __m128i v9; // xmm2
  _BOOL8 v10; // rax
  __int64 v11; // rcx
  __int64 v12; // rax
  __m128 v13; // xmm0
  __m128 v14; // xmm1
  int v15; // ecx
  __m128 inserted; // xmm1
  __m128i v17; // xmm0
  __m128i v18; // xmm0
  __m128 v20; // [rsp+0h] [rbp-50h] BYREF
  int v21; // [rsp+1Ch] [rbp-34h] BYREF
  __m128 v22; // [rsp+20h] [rbp-30h]

  RBX::Quaternion::Quaternion(this: (RBX::Quaternion *)&v20, a2); /*0x10671fe2d*/
  v4 = _mm_mul_ps(v20, v20); /*0x10671fe39*/
  v5 = _mm_hadd_ps(v4, v4); /*0x10671fe3c*/
  v6 = fsqrt(_mm_hadd_ps(v5, v5).f32[0]); /*0x10671fe44*/
  v7 = (__m128)0x3F800000u; /*0x10671fe48*/
  v7.f32[0] = 1.0 / v6; /*0x10671fe50*/
  v8 = _mm_mul_ps(_mm_shuffle_ps(v7, v7, 0), v20); /*0x10671fe58*/
  v9 = (__m128i)_mm_and_ps(v8, (__m128)xmmword_108F46760); /*0x10671fe65*/
  v10 = *(float *)_mm_shuffle_epi32(v9, 245).i32 > *(float *)v9.i32; /*0x10671fe72*/
  v22 = v8; /*0x10671fe75*/
  v11 = 2; /*0x10671fe8f*/
  if ( fabs(*(float *)_mm_unpackhi_pd((__m128d)v8, (__m128d)v8).f64) <= fabs(v22.f32[v10]) ) /*0x10671fe94*/
    v11 = v10; /*0x10671fe94*/
  v20 = v8; /*0x10671fe97*/
  v12 = 3; /*0x10671feb1*/
  if ( fabs(_mm_shuffle_ps(v8, v8, 255).f32[0]) <= fabs(v22.f32[v11]) ) /*0x10671feb6*/
    v12 = (unsigned int)v11; /*0x10671feb6*/
  if ( v22.f32[v12] < 0.0 ) /*0x10671fec1*/
    v22 = _mm_xor_ps(v8, *(__m128 *)&xmmword_108F246C0); /*0x10671feca*/
  v13.i32[0] = v22.i32[RBX::Network::kRotationAxisTable[3 * v12 + 2]]; /*0x10671fee2*/
  v14 = _mm_cmple_ss((__m128)0LL, v13); /*0x10671fee8*/
  v15 = (int)(float)(COERCE_FLOAT(COERCE_UNSIGNED_INT(_mm_andnot_ps(v14, (__m128)0xBF000000).f32[0]) | v14.i32[0] & 0x3F000000) /*0x10671ff23*/
                   + (float)((float)(v13.f32[0] / 0.70710677) * 511.0))
      & 0x3FF;
  inserted = _mm_insert_ps( /*0x10671ff2f*/
               (__m128)v22.u32[RBX::Network::kRotationAxisTable[3 * v12]],
               (__m128)v22.u32[RBX::Network::kRotationAxisTable[3 * v12 + 1]],
               16);
  v17 = _mm_cvttps_epi32( /*0x10671ff62*/
          _mm_add_ps(
            _mm_blendv_ps((__m128)xmmword_108F302B0, (__m128)xmmword_108F39940, _mm_cmple_ps((__m128)0LL, inserted)),
            _mm_mul_ps(_mm_div_ps(inserted, (__m128)xmmword_10A44F4F0), (__m128)xmmword_1099FD780)));
  v18 = _mm_and_si128( /*0x10671ff7a*/
          _mm_blend_epi16(_mm_slli_epi32(v17, 0x14u), _mm_slli_epi32(v17, 0xAu), 12),
          (__m128i)xmmword_1099FD790);
  v21 = v15 | ((_DWORD)v12 << 30) | _mm_cvtsi128_si32(v18) | _mm_extract_epi32(v18, 1); /*0x10671ff96*/
  RBX::Network::NetworkStream::writeBytes(this, a2: &v21, a3: 4u); /*0x10671ffa0*/
  return __stack_chk_guard; /*0x10671ffb5*/
}

// Address: 0x10671ffc4 | Name: __ZN3RBX7Network10Compressor19readRotationCompactERNS0_13NetworkStreamERNS_7Matrix3E
__int64 __fastcall RBX::Network::Compressor::readRotationCompact(
        RBX::Network::Compressor *this,
        RBX::Network::NetworkStream *a2,
        RBX::Matrix3 *a3)
{
  unsigned int UInt32; // eax
  float v5; // xmm0_4
  __m128i v6; // xmm1
  float v7; // xmm0_4
  __int64 v8; // rdi
  __m128 v9; // xmm1
  __int64 v10; // rcx
  __m128 v11; // xmm1
  __int128 v13; // [rsp+0h] [rbp-30h] BYREF
  _QWORD v14[2]; // [rsp+10h] [rbp-20h]

  UInt32 = RBX::Network::NetworkStream::readUInt32(this); /*0x10671ffde*/
  v5 = (float)((int)(UInt32 << 12) >> 22); /*0x10671ffeb*/
  v6 = _mm_cvtsi32_si128(UInt32); /*0x10671ffef*/
  UInt32 >>= 30; /*0x10671fff3*/
  v7 = (float)(v5 / 511.0) * 0.70710677; /*0x10671fffe*/
  v8 = RBX::Network::kRotationAxisTable[3 * UInt32 + 1]; /*0x106720015*/
  v9 = _mm_mul_ps( /*0x10672003e*/
         _mm_div_ps(
           _mm_cvtepi32_ps(
             _mm_srai_epi32(
               _mm_blend_epi16(_mm_slli_epi32(_mm_shuffle_epi32(v6, 80), 2u), _mm_slli_epi32(v6, 0x16u), 243),
               0x16u)),
           (__m128)xmmword_1099FD780),
         (__m128)xmmword_10A44F4F0);
  v10 = RBX::Network::kRotationAxisTable[3 * UInt32 + 2]; /*0x106720045*/
  *((_DWORD *)v14 + RBX::Network::kRotationAxisTable[3 * UInt32]) = _mm_extract_ps(v9, 1); /*0x10672004a*/
  *((float *)v14 + v8) = v7; /*0x106720052*/
  *((_DWORD *)v14 + v10) = v9.i32[0]; /*0x10672005c*/
  v11 = _mm_mul_ps(v9, v9); /*0x106720062*/
  *((float *)v14 + UInt32) = fsqrt( /*0x106720088*/
                               fmaxf(
                                 1.0 - (float)((float)(_mm_movehdup_ps(v11).f32[0] + (float)(v7 * v7)) + v11.f32[0]),
                                 0.0));
  v13 = *(_OWORD *)v14; /*0x106720096*/
  RBX::Quaternion::toRotationMatrix(this: (RBX::Quaternion *)&v13, a2); /*0x10672009c*/
  return __stack_chk_guard; /*0x1067200b1*/
}

// Address: 0x1067200be | Name: __ZN3RBX7Network10Compressor13writeVelocityERNS0_13NetworkStreamERKNS_7Vector3E
__int64 __fastcall RBX::Network::Compressor::writeVelocity(
        RBX::Network::Compressor *this,
        const __m128i *a2,
        const RBX::Vector3 *a3)
{
  RBX::Network::NetworkStream *v3; // rbx
  __m128i v4; // xmm3
  __m128i si128; // xmm0
  __m128i v6; // xmm1
  __m128i v7; // xmm4
  float v8; // xmm0_4
  int *v9; // rsi
  unsigned int v10; // edx
  int v11; // r15d
  int v12; // r14d
  __m128 v13; // xmm0
  __m128 v14; // xmm1
  unsigned int v15; // r15d
  __m128i v16; // xmm0
  __m128 v18; // [rsp+0h] [rbp-60h]
  __m128 v19; // [rsp+10h] [rbp-50h]
  int v20; // [rsp+28h] [rbp-38h] BYREF
  int v21; // [rsp+2Ch] [rbp-34h] BYREF
  __m128 v22; // [rsp+30h] [rbp-30h]
  char v23; // [rsp+46h] [rbp-1Ah] BYREF
  char v24; // [rsp+47h] [rbp-19h] BYREF

  v3 = this; /*0x1067200cb*/
  v4 = _mm_loadl_epi64(a2); /*0x1067200ce*/
  si128 = _mm_load_si128((const __m128i *)&xmmword_108F46760); /*0x1067200d2*/
  v6 = _mm_and_si128(v4, si128); /*0x1067200de*/
  v7 = _mm_cvtsi32_si128(a2->u32[2]); /*0x1067200e2*/
  v8 = fmaxf(*(float *)_mm_and_si128(si128, v7).i32, fmaxf(*(float *)_mm_shuffle_epi32(v6, 245).i32, *(float *)v6.i32)); /*0x1067200f4*/
  if ( v8 >= 0.001 ) /*0x106720103*/
  {
    v11 = 0; /*0x106720119*/
    v21 = 0; /*0x106720120*/
    v19 = (__m128)v4; /*0x106720126*/
    v22 = (__m128)v7; /*0x10672012b*/
    frexpf(a1: v8, a2: &v21); /*0x106720130*/
    if ( v21 > 0 ) /*0x10672013a*/
      v11 = v21; /*0x10672013a*/
    v12 = 14; /*0x106720142*/
    if ( v11 < 14 ) /*0x106720148*/
      v12 = v11; /*0x106720148*/
    v13.f32[0] = ldexpf(a1: 1.0, a2: v12); /*0x106720157*/
    v18 = v13; /*0x10672015c*/
    v14 = _mm_cmple_ss((__m128)0LL, v22); /*0x10672018a*/
    v15 = (int)(float)(COERCE_FLOAT(COERCE_UNSIGNED_INT(_mm_andnot_ps(v14, (__m128)0xBF000000).f32[0]) | v14.i32[0] & 0x3F000000) /*0x1067201ac*/
                     + (float)(fminf(fmaxf(v22.f32[0] / v13.f32[0], -1.0), 1.0) * 2047.0));
    v22 = _mm_cmple_ps((__m128)0LL, v19); /*0x1067201b6*/
    v23 = ((16 * v12) | v15 & 0xF) + 16; /*0x1067201cd*/
    RBX::Network::NetworkStream::writeBytes(this: v3, a2: &v23, a3: 1u); /*0x1067201d7*/
    v16 = _mm_cvttps_epi32( /*0x106720217*/
            _mm_add_ps(
              _mm_blendv_ps((__m128)xmmword_108F302B0, (__m128)xmmword_108F39940, v22),
              _mm_mul_ps(
                _mm_min_ps(
                  _mm_max_ps(_mm_div_ps(v19, _mm_moveldup_ps(v18)), (__m128)xmmword_108F4BCC0),
                  (__m128)xmmword_108F2F400),
                (__m128)xmmword_1099FD7A0)));
    v9 = &v20; /*0x106720244*/
    v20 = _mm_extract_epi32(_mm_slli_epi32(v16, 8u), 1) & 0xFFF00 /*0x106720248*/
        | _mm_cvtsi128_si32(_mm_slli_epi32(v16, 0x14u))
        | (unsigned __int8)(v15 >> 4);
    this = v3; /*0x10672024a*/
    v10 = 4; /*0x10672024d*/
  }
  else
  {
    v9 = (int *)&v24; /*0x106720105*/
    v24 = 0; /*0x106720109*/
    v10 = 1; /*0x10672010f*/
  }
  return RBX::Network::NetworkStream::writeBytes(this, a2: v9, a3: v10); /*0x106720257*/
}

// Address: 0x106720262 | Name: __ZN3RBX7Network10Compressor12readVelocityERNS0_13NetworkStreamERNS_7Vector3E
void __fastcall RBX::Network::Compressor::readVelocity(
        RBX::Network::Compressor *this,
        RBX::Network::NetworkStream *a2,
        RBX::Vector3 *a3)
{
  unsigned __int8 Byte; // al
  unsigned int v6; // r15d
  unsigned int UInt32; // r14d
  __m128 v8; // xmm0
  __m128 v9; // xmm1
  float v10; // xmm2_4

  Byte = RBX::Network::NetworkStream::readByte(this); /*0x106720273*/
  if ( Byte != 0 ) /*0x10672027a*/
  {
    v6 = Byte; /*0x10672027c*/
    UInt32 = RBX::Network::NetworkStream::readUInt32(this); /*0x106720288*/
    v8.f32[0] = ldexpf(a1: 1.0, a2: (v6 >> 4) - 1); /*0x1067202b4*/
    v9 = _mm_mul_ps( /*0x1067202dd*/
           _mm_moveldup_ps(v8),
           _mm_div_ps(
             _mm_cvtepi32_ps(_mm_srai_epi32(_mm_insert_epi32(_mm_cvtsi32_si128(UInt32), UInt32 << 12, 1), 0x14u)),
             (__m128)xmmword_1099FD7A0));
    v10 = (float)((float)((int)((UInt32 << 24) | ((v6 & 0xF) << 20)) >> 20) / 2047.0) * v8.f32[0]; /*0x1067202e8*/
  }
  else
  {
    v9 = 0; /*0x1067202ee*/
    v10 = 0.0; /*0x1067202f1*/
  }
  *((float *)a2 + 2) = v10; /*0x1067202f4*/
  _mm_storel_ps((double *)a2, v9); /*0x1067202f9*/
}

// Address: 0x106720306 | Name: __ZN3RBX7Network10Compressor20writeVelocityCompactERNS0_13NetworkStreamERKNS_7Vector3E
__int64 __fastcall RBX::Network::Compressor::writeVelocityCompact(
        RBX::Network::Compressor *this,
        RBX::Network::NetworkStream *a2,
        const RBX::Vector3 *a3)
{
  float v4; // xmm5_4
  __m128 v5; // xmm4
  float v6; // xmm0_4
  char *v7; // rsi
  int v8; // ecx
  int v9; // r14d
  __m128 v10; // xmm0
  __m128 v11; // xmm3
  __m128 v12; // xmm2
  int v13; // r15d
  unsigned int v14; // r14d
  float v16; // [rsp+0h] [rbp-50h]
  int v17; // [rsp+1Ch] [rbp-34h] BYREF
  __m128 v18; // [rsp+20h] [rbp-30h] BYREF
  char v19; // [rsp+34h] [rbp-1Ch] BYREF
  char v20; // [rsp+35h] [rbp-1Bh] BYREF
  char v21; // [rsp+36h] [rbp-1Ah] BYREF
  char v22; // [rsp+37h] [rbp-19h] BYREF

  v4 = *(float *)a2; /*0x106720316*/
  v5 = (__m128)*(unsigned __int64 *)((char *)a2 + 4); /*0x106720327*/
  v6 = fmaxf( /*0x10672033d*/
         fabs(_mm_movehdup_ps(v5).f32[0]),
         fmaxf(fabs(COERCE_FLOAT(*(_QWORD *)((char *)a2 + 4))), fabs(*(float *)a2)));
  if ( v6 >= 0.001 ) /*0x10672034c*/
  {
    v17 = 0; /*0x10672035e*/
    v18 = v5; /*0x106720368*/
    v16 = v4; /*0x10672036c*/
    frexpf(a1: v6, a2: &v17); /*0x106720370*/
    v8 = -16; /*0x10672037b*/
    if ( v17 >= -15 ) /*0x106720380*/
      v8 = v17; /*0x106720380*/
    v9 = 15; /*0x106720386*/
    if ( v8 < 15 ) /*0x10672038c*/
      v9 = v8; /*0x10672038c*/
    v10.f32[0] = ldexpf(a1: 1.0, a2: v9); /*0x10672039b*/
    v11.f32[0] = v16; /*0x1067203a0*/
    v12 = _mm_cmple_ss((__m128)0LL, v11); /*0x1067203c6*/
    v13 = (int)(float)(COERCE_FLOAT(COERCE_UNSIGNED_INT(_mm_andnot_ps(v12, (__m128)0xBF000000).f32[0]) | v12.i32[0] & 0x3F000000) /*0x1067203e8*/
                     + (float)(fminf(fmaxf(v16 / v10.f32[0], -1.0), 1.0) * 31.0));
    v18 = _mm_and_ps( /*0x10672043e*/
            (__m128)_mm_cvttps_epi32(
                      _mm_add_ps(
                        _mm_blendv_ps(
                          (__m128)xmmword_108F302B0,
                          (__m128)xmmword_108F39940,
                          _mm_cmple_ps((__m128)0LL, v18)),
                        _mm_mul_ps(
                          _mm_min_ps(
                            _mm_max_ps(_mm_div_ps(v18, _mm_moveldup_ps(v10)), (__m128)xmmword_108F4BCC0),
                            (__m128)xmmword_108F2F400),
                          (__m128)xmmword_1099FD7B0))),
            (__m128)xmmword_1094C01D0);
    v21 = (((unsigned __int8)(v13 & 0x30) >> 4) + 4 * v9) | 0x80; /*0x10672044f*/
    RBX::Network::NetworkStream::writeBytes(this, a2: &v21, a3: 1u); /*0x106720459*/
    v14 = _mm_cvtsi128_si32(_mm_load_si128((const __m128i *)&v18)); /*0x106720467*/
    v20 = (16 * v13) | (v14 >> 2); /*0x106720479*/
    RBX::Network::NetworkStream::writeBytes(this, a2: &v20, a3: 1u); /*0x106720483*/
    v7 = &v19; /*0x106720499*/
    v19 = ((_BYTE)v14 << 6) | _mm_extract_ps(v18, 1); /*0x10672049d*/
  }
  else
  {
    v7 = &v22; /*0x10672034e*/
    v22 = 0; /*0x106720352*/
  }
  return RBX::Network::NetworkStream::writeBytes(this, a2: v7, a3: 1u); /*0x1067204ac*/
}

// Address: 0x1067204b8 | Name: __ZN3RBX7Network10Compressor19readVelocityCompactERNS0_13NetworkStreamERNS_7Vector3E
__int64 __fastcall RBX::Network::Compressor::readVelocityCompact(
        RBX::Network::Compressor *this,
        RBX::Network::NetworkStream *a2,
        RBX::Vector3 *a3)
{
  __int64 result; // rax
  int v6; // r12d
  unsigned __int8 Byte; // r15
  unsigned __int8 v8; // r14
  __m128 v9; // xmm0
  __m128i v10; // xmm1
  __m128i v11; // xmm2
  __m128 v12; // xmm1
  float v13; // xmm2_4

  result = RBX::Network::NetworkStream::readByte(this); /*0x1067204c9*/
  if ( (_BYTE)result != 0 ) /*0x1067204d0*/
  {
    v6 = (unsigned __int8)result; /*0x1067204d6*/
    Byte = RBX::Network::NetworkStream::readByte(this); /*0x1067204e2*/
    v8 = RBX::Network::NetworkStream::readByte(this); /*0x1067204ed*/
    v9.f32[0] = ldexpf(a1: 1.0, a2: v6 << 25 >> 27); /*0x106720501*/
    v10 = _mm_cvtepu8_epi32(_mm_insert_epi8(_mm_cvtsi32_si128(Byte), v8, 1)); /*0x106720518*/
    v11 = _mm_shuffle_epi32(v10, 80); /*0x10672051d*/
    result = (unsigned int)(v8 << 26 >> 26); /*0x10672055d*/
    v12 = _mm_mul_ps( /*0x106720575*/
            _mm_moveldup_ps(v9),
            _mm_div_ps(
              _mm_cvtepi32_ps(
                _mm_srai_epi32(
                  _mm_or_si128(
                    _mm_blend_epi16(_mm_slli_epi32(v10, 0x16u), _mm_slli_epi32(v10, 0x14u), 12),
                    _mm_blend_epi16(_mm_slli_epi32(_mm_insert_epi32(v11, v6, 0), 0x1Eu), _mm_slli_epi32(v11, 0x1Cu), 12)),
                  0x1Au)),
              (__m128)xmmword_1099FD7B0));
    v13 = (float)((float)(int)result / 31.0) * v9.f32[0]; /*0x106720580*/
  }
  else
  {
    v12 = 0; /*0x106720586*/
    v13 = 0.0; /*0x106720589*/
  }
  *((float *)a2 + 2) = v13; /*0x10672058c*/
  _mm_storel_ps((double *)a2, v12); /*0x106720591*/
  return result; /*0x106720594*/
}

// END Compressor part 1/1, 10 functions
