// LargeCompressor -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 3 functions


// Address: 0x1054253d4 | Name: __ZNK3RBX7Network15LargeCompressor14compressStreamERNS0_20NetworkStreamContentEf
__int64 __fastcall RBX::Network::LargeCompressor::compressStream(
        RBX::Network::LargeCompressor *this,
        RBX::Network::NetworkStreamContent *a2,
        float a3)
{
  unsigned int v3; // r14d
  RBX::Network::NetworkStreamContent *v4; // rbx
  int v5; // eax
  __int64 v6; // rdx
  __int64 v7; // rcx
  const char *v8; // rsi
  __int64 v9; // r8
  __int64 v10; // r9
  __m128 v11; // xmm0
  __m128 v12; // xmm1
  __m128 v13; // xmm2
  __m128 v14; // xmm3
  __m128 v15; // xmm4
  __m128 v16; // xmm5
  __m128 v17; // xmm6
  __m128 v18; // xmm7
  int v19; // r15d
  int v20; // eax
  void *v21; // rsi
  signed int v22; // eax
  RBX::Memory *v23; // rdi
  __int64 v24; // rax
  char v26; // [rsp+0h] [rbp-60h]
  RBX::Memory *v27[4]; // [rsp+8h] [rbp-58h] BYREF
  _BYTE v28[13]; // [rsp+28h] [rbp-38h]
  float v29; // [rsp+3Ch] [rbp-24h]

  v3 = *((_DWORD *)a2 + 8); /*0x1054253e3*/
  if ( v3 == 0 ) /*0x1054253ea*/
    goto LABEL_4; /*0x1054253ea*/
  v4 = a2; /*0x1054253ec*/
  v29 = a3; /*0x1054253ef*/
  v5 = LZ4_compressBound(a1: v3); /*0x1054253f7*/
  if ( v5 == 0 ) /*0x1054253fe*/
    RBX::throw_runtime_error( /*0x105425515*/
      this: (RBX *)"Unable to compress net asset",
      a2: v8,
      a3: v6,
      a4: v7,
      a5: v9,
      a6: v10,
      a7: v11,
      a8: v12,
      a9: v13,
      a10: v14,
      a11: v15,
      a12: v16,
      a13: v17,
      a14: v18,
      a15: v26);
  if ( *((_DWORD *)v4 + 8) <= 0xFFFFFFFu ) /*0x105425410*/
  {
    RBX::Network::NetworkStreamContent::NetworkStreamContent( /*0x105425425*/
      this: (RBX::Network::NetworkStreamContent *)v27,
      a2: v5 + 4);
    RBX::Network::NetworkStreamContent::writeUInt32VarInt(this: (RBX::Network::NetworkStreamContent *)v27, a2: v3); /*0x105425430*/
    v19 = *(_DWORD *)v28; /*0x105425435*/
    v20 = LZ4_compress_default( /*0x10542544c*/
            a1: *(_QWORD *)v4,
            a2: (char *)v27[0] + *(unsigned int *)v28,
            a3: v3,
            a4: (unsigned int)(*(_DWORD *)&v28[4] - *(_DWORD *)v28));
    if ( v20 != 0 && (v22 = v19 + v20, (float)((float)(int)v3 * v29) > (float)v22) ) /*0x105425476*/
    {
      RBX::Network::NetworkStreamContent::SetWriteOffsetBytes( /*0x105425480*/
        this: (RBX::Network::NetworkStreamContent *)v27,
        a2: v22,
        a3: false);
      *(RBX::Memory **)v4 = v27[0]; /*0x10542548d*/
      v23 = *((RBX::Memory **)v4 + 1); /*0x105425490*/
      if ( v23 != nullptr ) /*0x105425497*/
      {
        *((_QWORD *)v4 + 2) = v23; /*0x10542549d*/
        operator delete(a1: v23, a2: v21); /*0x1054254a1*/
        *(_OWORD *)((char *)v4 + 8) = 0; /*0x1054254a9*/
        *((_QWORD *)v4 + 3) = 0; /*0x1054254ad*/
      }
      qmemcpy((char *)v4 + 8, &v27[1], 24); /*0x1054254b9*/
      memset(&v27[1], 0, 24); /*0x1054254c8*/
      v24 = *(_QWORD *)v28; /*0x1054254d5*/
      *(_QWORD *)((char *)v4 + 37) = *(_QWORD *)&v28[5]; /*0x1054254dc*/
      *((_QWORD *)v4 + 4) = v24; /*0x1054254e1*/
      LOBYTE(v4) = 1; /*0x1054254e5*/
    }
    else
    {
      LODWORD(v4) = 0; /*0x1054254e9*/
    }
    if ( v27[1] != nullptr ) /*0x1054254f2*/
    {
      v27[2] = v27[1]; /*0x1054254f4*/
      operator delete(a1: v27[1], a2: v21); /*0x1054254f8*/
    }
  }
  else
  {
LABEL_4:
    LODWORD(v4) = 0; /*0x105425412*/
  }
  return (unsigned int)v4; /*0x1054254ff*/
}

// Address: 0x10542553c | Name: __ZN3RBX7Network15LargeCompressorD1Ev
void __fastcall RBX::Network::LargeCompressor::~LargeCompressor(RBX::Network::LargeCompressor *this)
{
  ; /*0x10542553c*/
}

// Address: 0x105425542 | Name: __ZN3RBX7Network15LargeCompressorD0Ev
void __fastcall RBX::Network::LargeCompressor::~LargeCompressor(RBX::Memory *this, void *a2)
{
  operator delete(a1: this, a2); /*0x105425547*/
}

// END LargeCompressor part 1/1, 3 functions
