// PacketReceiveJob -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 4 functions


// Address: 0x1067a7696 | Name: __ZN3RBX7Network16PacketReceiveJobC2ENSt3__110shared_ptrINS0_17ConcurrentRakPeerEEENS3_INS0_4PeerEEEPNS_9DataModelE
__int64 __fastcall RBX::Network::PacketReceiveJob::PacketReceiveJob(
        RBX::DataModelJob *this,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  std::__shared_weak_count *v8; // r13
  RBX::Time *v9; // rdi
  volatile signed __int64 *v10; // r12
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // xmm0_8
  __int64 v15; // [rsp+0h] [rbp-50h] BYREF
  std::__shared_weak_count *v16; // [rsp+8h] [rbp-48h]
  std::__shared_weak_count *v17[2]; // [rsp+10h] [rbp-40h] BYREF

  RBX::shared_from<RBX::DataModel>(a1: &v15, a2: a4); /*0x1067a76bd*/
  RBX::DataModelJob::DataModelJob(a1: this, a2: "Net PacketReceive", a3: 7, a4: 0, a5: &v15, a6: 2); /*0x1067a76dc*/
  v8 = v16; /*0x1067a76e1*/
  if ( v16 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v16 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067a76fa*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x1067a7703*/
    std::__shared_weak_count::__release_weak(this: v8); /*0x1067a7709*/
  }
  *(_QWORD *)this = &off_10CAAB7C0; /*0x1067a7715*/
  RBX::shared_from<RBX::DataModel>(a1: v17, a2: a4); /*0x1067a771f*/
  v10 = (volatile signed __int64 *)v17[1]; /*0x1067a7724*/
  *(_OWORD *)((char *)this + 408) = *(_OWORD *)v17; /*0x1067a772c*/
  if ( v10 != nullptr ) /*0x1067a7736*/
  {
    _InterlockedIncrement64(v10 + 2); /*0x1067a7738*/
    if ( _InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067a774f*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v10 + 16))(a1: v10); /*0x1067a7758*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v10); /*0x1067a775e*/
    }
  }
  v11 = *(_QWORD *)(a2 + 8); /*0x1067a7763*/
  *(_OWORD *)((char *)this + 424) = *(_OWORD *)a2; /*0x1067a776b*/
  if ( v11 != 0 ) /*0x1067a7775*/
    _InterlockedIncrement64((volatile signed __int64 *)(v11 + 16)); /*0x1067a7777*/
  v12 = *(_QWORD *)(a3 + 8); /*0x1067a777c*/
  *(_OWORD *)((char *)this + 440) = *(_OWORD *)a3; /*0x1067a7784*/
  if ( v12 != 0 ) /*0x1067a778e*/
    _InterlockedIncrement64((volatile signed __int64 *)(v12 + 16)); /*0x1067a7790*/
  RBX::Time::nowFast(this: v9); /*0x1067a7795*/
  *((_QWORD *)this + 57) = v13; /*0x1067a779a*/
  return RBX::DataModelJob::sendProfileDataToTelemetry(this); /*0x1067a77aa*/
}

// Address: 0x1067a7812 | Name: __ZN3RBX7Network16PacketReceiveJobD1Ev
void __fastcall RBX::Network::PacketReceiveJob::~PacketReceiveJob(RBX::Network::PacketReceiveJob *this)
{
  std::__shared_weak_count *v2; // rdi
  std::__shared_weak_count *v3; // rdi
  std::__shared_weak_count *v4; // rdi

  *(_QWORD *)this = &off_10CAAB7C0; /*0x1067a7822*/
  v2 = *((std::__shared_weak_count **)this + 56); /*0x1067a7825*/
  if ( v2 != nullptr ) /*0x1067a782f*/
    std::__shared_weak_count::__release_weak(this: v2); /*0x1067a7831*/
  v3 = *((std::__shared_weak_count **)this + 54); /*0x1067a7836*/
  if ( v3 != nullptr ) /*0x1067a7840*/
    std::__shared_weak_count::__release_weak(this: v3); /*0x1067a7842*/
  v4 = *((std::__shared_weak_count **)this + 52); /*0x1067a7847*/
  if ( v4 != nullptr ) /*0x1067a7851*/
    std::__shared_weak_count::__release_weak(this: v4); /*0x1067a7853*/
  RBX::TaskScheduler::Job::~Job(this); /*0x1067a7861*/
}

// Address: 0x1067a7866 | Name: __ZN3RBX7Network16PacketReceiveJobD0Ev
void __fastcall RBX::Network::PacketReceiveJob::~PacketReceiveJob(RBX::Network::PacketReceiveJob *this)
{
  std::__shared_weak_count *v2; // rdi
  std::__shared_weak_count *v3; // rdi
  std::__shared_weak_count *v4; // rdi
  void *v5; // rsi

  *(_QWORD *)this = &off_10CAAB7C0; /*0x1067a7876*/
  v2 = *((std::__shared_weak_count **)this + 56); /*0x1067a7879*/
  if ( v2 != nullptr ) /*0x1067a7883*/
    std::__shared_weak_count::__release_weak(this: v2); /*0x1067a7885*/
  v3 = *((std::__shared_weak_count **)this + 54); /*0x1067a788a*/
  if ( v3 != nullptr ) /*0x1067a7894*/
    std::__shared_weak_count::__release_weak(this: v3); /*0x1067a7896*/
  v4 = *((std::__shared_weak_count **)this + 52); /*0x1067a789b*/
  if ( v4 != nullptr ) /*0x1067a78a5*/
    std::__shared_weak_count::__release_weak(this: v4); /*0x1067a78a7*/
  RBX::TaskScheduler::Job::~Job(this); /*0x1067a78af*/
  operator delete(a1: this, a2: v5); /*0x1067a78bd*/
}

// Address: 0x1067a78c2 | Name: __ZN3RBX7Network16PacketReceiveJob16stepDataModelJobERKNS_13TaskScheduler3Job5StatsE
_BOOL8 __fastcall RBX::Network::PacketReceiveJob::stepDataModelJob(__int64 a1)
{
  std::__shared_weak_count *v2; // rdi
  std::__shared_weak_count *v3; // rax
  __int64 v4; // r14
  bool v5; // r12
  std::__shared_weak_count *v6; // rdi
  volatile signed __int64 *v7; // rax
  __int64 v8; // rdi
  volatile signed __int64 *v9; // r14
  std::__shared_weak_count *v10; // rax
  __int64 v11; // r13
  __int64 v12; // rax
  bool v13; // r13
  std::__shared_weak_count *v14; // rdi
  volatile signed __int64 *v15; // rax
  volatile signed __int64 *v16; // r14
  double v17; // xmm0_8
  unsigned __int8 v18; // r13
  std::__shared_weak_count *v19; // rdi
  volatile signed __int64 *v20; // rax
  volatile signed __int64 *v21; // r14
  RBX::Network::ConcurrentRakPeer *v22; // rdi
  __int64 v23; // rax
  volatile signed __int64 *v24; // r15
  _BYTE v26[40]; // [rsp+0h] [rbp-70h] BYREF
  const void *v27; // [rsp+28h] [rbp-48h]
  std::__shared_weak_count *v28; // [rsp+30h] [rbp-40h]
  std::__shared_weak_count *v29; // [rsp+38h] [rbp-38h]
  volatile signed __int64 *v30; // [rsp+40h] [rbp-30h]

  v2 = *(std::__shared_weak_count **)(a1 + 416); /*0x1067a78d6*/
  if ( v2 != nullptr
    && (v3 = (std::__shared_weak_count *)std::__shared_weak_count::lock(this: v2), v28 = v3, v3 != nullptr) )
  {
    v4 = *(_QWORD *)(a1 + 408); /*0x1067a78f8*/
    v27 = (const void *)v4; /*0x1067a78ff*/
    v5 = v4 != 0; /*0x1067a7906*/
    if ( v4 != 0 )
    {
      if ( (unsigned __int8)FLog::DataModelJobs >= 6u && BYTE1(FLog::DataModelJobs) >= 3u )
        FLog::FastLog(
          a1: *(_QWORD *)&FLog::DataModelJobs,
          a2: qword_10D7F3C10,
          a3: "[FLog::DataModelJobs] Packet receive start, data model: %p",
          (const void *)v4);
      RBX::DataModel::scoped_write_request::scoped_write_request( /*0x1067a7950*/
        this: (RBX::DataModel::scoped_write_request *)v26,
        a2: (RBX::Instance *)(v4 + 464));
      if ( FFlag::UseRbxTransportServer == 1 /*0x1067a7979*/
        && (v6 = *(std::__shared_weak_count **)(a1 + 448)) != nullptr
        && (v7 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v6), v30 = v7, v7 != nullptr) )
      {
        v9 = v7; /*0x1067a797b*/
        v10 = *(std::__shared_weak_count **)(a1 + 440); /*0x1067a797e*/
        v29 = v10; /*0x1067a7985*/
        if ( v10 != nullptr ) /*0x1067a798c*/
        {
          v11 = *((_QWORD *)v10 + 3); /*0x1067a7992*/
          v12 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Server>(a1: v8); /*0x1067a7996*/
          v13 = *(unsigned __int16 *)(v11 + 440) - (unsigned int)*(unsigned __int16 *)(v12 + 440) <= *(unsigned __int16 *)(v12 + 442); /*0x1067a79b5*/
        }
        else
        {
          v13 = false; /*0x1067a7b58*/
        }
        if ( _InterlockedExchangeAdd64(v9 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067a7b6b*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v9 + 16))(a1: v9); /*0x1067a7b77*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v9); /*0x1067a7b7d*/
        }
      }
      else
      {
        v13 = false; /*0x1067a79c6*/
      }
      if ( RBX::Network::useRbxTransport(this: (RBX::Network *)v13) != 0 /*0x1067a79e4*/
        || ((unsigned __int8)FFlag::RakNetConnectionFailureFallbackToRbxTransport ^ 1 | v13) == 0 )
      {
        v14 = *(std::__shared_weak_count **)(a1 + 448); /*0x1067a79e6*/
        if ( v14 != nullptr ) /*0x1067a79f0*/
        {
          v15 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v14); /*0x1067a79f2*/
          v30 = v15; /*0x1067a79f7*/
          if ( v15 != nullptr ) /*0x1067a79fe*/
          {
            v16 = v15; /*0x1067a7a00*/
            v14 = *(std::__shared_weak_count **)(a1 + 440); /*0x1067a7a03*/
            v29 = v14; /*0x1067a7a0a*/
            if ( v14 != nullptr ) /*0x1067a7a11*/
              (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 616LL))(a1: v14); /*0x1067a7a16*/
            if ( _InterlockedExchangeAdd64(v16 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067a7a2c*/
            {
              (*(void (__fastcall **)(volatile signed __int64 *))(*v16 + 16))(a1: v16); /*0x1067a7a34*/
              std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v16); /*0x1067a7a3a*/
            }
          }
        }
      }
      if ( DFFlag::DebugRakPeerReceive == 1 /*0x1067a7a65*/
        && (RBX::Time::nowFast(this: v14), v17 - *(double *)(a1 + 456) > (double)DFInt::DebugRakPeerReceiveAfterSeconds) )
      {
        *(double *)(a1 + 456) = v17; /*0x1067a7a67*/
        v18 = 1; /*0x1067a7a6f*/
      }
      else
      {
        v18 = 0; /*0x1067a7a74*/
      }
      v19 = *(std::__shared_weak_count **)(a1 + 432); /*0x1067a7a77*/
      if ( v19 != nullptr ) /*0x1067a7a81*/
      {
        v20 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v19); /*0x1067a7a83*/
        v30 = v20; /*0x1067a7a88*/
        if ( v20 != nullptr ) /*0x1067a7a8f*/
        {
          v21 = v20; /*0x1067a7a91*/
          v22 = *(RBX::Network::ConcurrentRakPeer **)(a1 + 424); /*0x1067a7a94*/
          v29 = v22; /*0x1067a7a9b*/
          if ( v22 != nullptr ) /*0x1067a7aa2*/
          {
            v23 = RBX::Network::ConcurrentRakPeer::rawPeer(this: v22); /*0x1067a7aa4*/
            (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v23 + 208LL))(a1: v23, a2: v18); /*0x1067a7ab3*/
          }
          if ( _InterlockedExchangeAdd64(v21 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067a7ac9*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v21 + 16))(a1: v21); /*0x1067a7ad1*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v21); /*0x1067a7ad7*/
          }
        }
      }
      if ( (unsigned __int8)FLog::DataModelJobs >= 6u && BYTE1(FLog::DataModelJobs) >= 3u )
        FLog::FastLog(
          a1: *(_QWORD *)&FLog::DataModelJobs,
          a2: qword_10D7F3C10,
          a3: "[FLog::DataModelJobs] Packet receive finish, data model: %p",
          v27);
      RBX::DataModel::scoped_write_request::~scoped_write_request(this: (RBX::DataModel::scoped_write_request *)v26); /*0x1067a7b0c*/
      v24 = (volatile signed __int64 *)v28; /*0x1067a7b11*/
      if ( v28 == nullptr ) /*0x1067a7b18*/
        return true; /*0x1067a7b1d*/
    }
    else
    {
      v24 = (volatile signed __int64 *)v3; /*0x1067a7b1f*/
    }
    if ( _InterlockedExchangeAdd64(v24 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067a7b32*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v24 + 16))(a1: v24); /*0x1067a7b3a*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v24); /*0x1067a7b40*/
    }
  }
  else
  {
    return false; /*0x1067a79be*/
  }
  return v5; /*0x1067a7b49*/
}

// END PacketReceiveJob part 1/1, 4 functions
