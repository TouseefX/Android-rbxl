// ProcessingPacketV2 -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 11 functions


// Address: 0x10681c4fe | Name: __ZN3RBX7Network18ProcessingPacketV2D1Ev
void __fastcall RBX::Network::ProcessingPacketV2::~ProcessingPacketV2(RBX::Network::ProcessingPacketV2 *this)
{
  void *v2; // rsi

  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::~UnboundedCircularBuffer(a1: (__int64 *)this + 27); /*0x10681c50e*/
  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::ProcessingPacketV2 *)((char *)this + 152), a2: v2); /*0x10681c51a*/
  if ( *((_BYTE *)this + 136) == 1 ) /*0x10681c526*/
    RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::Network::ProcessingPacketV2 *)((char *)this + 48)); /*0x10681c535*/
}

// Address: 0x10681ca88 | Name: __ZN3RBX7Network18ProcessingPacketV28initFromENS0_14IncomingPacketE
__int64 __fastcall RBX::Network::ProcessingPacketV2::initFrom(__int64 a1, __int64 a2)
{
  __int128 v3; // xmm1
  _QWORD v5[5]; // [rsp+0h] [rbp-A0h] BYREF
  _BYTE v6[8]; // [rsp+28h] [rbp-78h] BYREF
  _BYTE v7[96]; // [rsp+30h] [rbp-70h] BYREF

  v3 = *(_OWORD *)(a2 + 16); /*0x10681caa8*/
  *(_OWORD *)v5 = *(_OWORD *)a2; /*0x10681cab0*/
  *(_OWORD *)&v5[2] = v3; /*0x10681cab4*/
  v5[4] = *(_QWORD *)(a2 + 32); /*0x10681cabc*/
  std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100](a1: v6, a2: a2 + 40); /*0x10681cac4*/
  RBX::Network::ProcessingPacketV2::ProcessingPacketV2(a1, a2: v5); /*0x10681cad3*/
  if ( v7[88] == 1 ) /*0x10681cadc*/
    RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v7); /*0x10681cae2*/
  *(_BYTE *)(a1 + 253) = 1; /*0x10681cae7*/
  return a1; /*0x10681cb01*/
}

// Address: 0x10682d6e4 | Name: __ZN3RBX7Network18ProcessingPacketV2C2ENS0_14IncomingPacketE
__int64 __fastcall RBX::Network::ProcessingPacketV2::ProcessingPacketV2(__int64 a1, __int128 *a2)
{
  __int128 v3; // xmm0
  __int64 result; // rax

  *(_QWORD *)(a1 + 32) = *((_QWORD *)a2 + 4); /*0x10682d6f2*/
  v3 = *a2; /*0x10682d6f6*/
  *(_OWORD *)(a1 + 16) = a2[1]; /*0x10682d6fd*/
  *(_OWORD *)a1 = v3; /*0x10682d701*/
  std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x10682d70c*/
    a1: a1 + 40,
    a2: (char *)a2 + 40);
  *(_QWORD *)(a1 + 144) = 0; /*0x10682d711*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)(a1 + 152)); /*0x10682d723*/
  result = RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::UnboundedCircularBuffer( /*0x10682d734*/
             a1: a1 + 216,
             a2: 8u);
  *(_DWORD *)(a1 + 248) = 0; /*0x10682d739*/
  *(_WORD *)(a1 + 252) = 0; /*0x10682d743*/
  return result; /*0x10682d74c*/
}

// Address: 0x10682d772 | Name: __ZN3RBX7Network18ProcessingPacketV2C1ENS0_14IncomingPacketE
__int64 __fastcall RBX::Network::ProcessingPacketV2::ProcessingPacketV2(__int64 a1, __int128 *a2)
{
  return RBX::Network::ProcessingPacketV2::ProcessingPacketV2(a1, a2); /*0x10682d776*/
}

// Address: 0x10682d77c | Name: __ZN3RBX7Network18ProcessingPacketV210moveFromV2ERS1_RKNS_4TimeEb
RBX::Network::ProcessingPacketV2 *__fastcall RBX::Network::ProcessingPacketV2::moveFromV2(
        RBX::Network::ProcessingPacketV2 *this,
        RBX::Network::ProcessingPacketV2 *a2,
        const RBX::Time *a3,
        int a4)
{
  __int128 v8; // xmm0
  unsigned __int8 *v9; // r12
  unsigned int v10; // eax
  __int128 v11; // xmm0
  int v12; // r12d
  _QWORD v14[5]; // [rsp+8h] [rbp-B8h] BYREF
  _BYTE v15[8]; // [rsp+30h] [rbp-90h] BYREF
  _BYTE v16[96]; // [rsp+38h] [rbp-88h] BYREF

  RBX::Network::ProcessingPacketV2::ProcessingPacketV2(this); /*0x10682d7a8*/
  if ( a4 != 0 ) /*0x10682d7b0*/
  {
    *((_QWORD *)this + 4) = *((_QWORD *)a2 + 4); /*0x10682d7b6*/
    v8 = *(_OWORD *)a2; /*0x10682d7ba*/
    *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1); /*0x10682d7c3*/
    *(_OWORD *)this = v8; /*0x10682d7c7*/
    std::__optional_storage_base<RBX::RbxTransport::NetStream,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::RbxTransport::NetStream,false>>( /*0x10682d7d2*/
      a1: (char *)this + 40,
      a2: (char *)a2 + 40);
  }
  else
  {
    v9 = (unsigned __int8 *)RBX::Network::IncomingPacket::data(this: a2); /*0x10682d7e1*/
    v10 = RBX::Network::IncomingPacket::size(this: a2); /*0x10682d7e7*/
    RBX::Network::IncomingPacket::IncomingPacket(this: (RBX::Network::IncomingPacket *)v14, a2: v9, a3: v10); /*0x10682d7f8*/
    *((_QWORD *)this + 4) = v14[4]; /*0x10682d808*/
    v11 = *(_OWORD *)v14; /*0x10682d80c*/
    *((_OWORD *)this + 1) = *(_OWORD *)&v14[2]; /*0x10682d814*/
    *(_OWORD *)this = v11; /*0x10682d818*/
    std::__optional_storage_base<RBX::RbxTransport::NetStream,false>::__assign_from[abi:ne200100]<std::__optional_move_assign_base<RBX::RbxTransport::NetStream,false>>( /*0x10682d81f*/
      a1: (char *)this + 40,
      a2: v15);
    if ( v16[88] == 1 ) /*0x10682d828*/
      RBX::RbxTransport::NetStreamBuffer::~NetStreamBuffer(this: (RBX::RbxTransport::NetStreamBuffer *)v16); /*0x10682d831*/
  }
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::operator=( /*0x10682d845*/
    a1: (__int64)this + 216,
    a2: (__int64 *)a2 + 27);
  RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::clear(a1: (__int64 *)a2 + 27); /*0x10682d84d*/
  v12 = *((_DWORD *)a2 + 62); /*0x10682d852*/
  if ( v12 == 0 ) /*0x10682d85c*/
  {
    v12 = 0; /*0x10682d85e*/
    if ( *((_BYTE *)a2 + 253) == 0 && RBX::Network::IncomingPacket::data(this: a2) != 0 ) /*0x10682d876*/
      v12 = RBX::Network::IncomingPacket::size(this: a2); /*0x10682d880*/
  }
  *((_DWORD *)this + 62) = v12; /*0x10682d883*/
  *((_BYTE *)this + 252) = *((_BYTE *)a2 + 252); /*0x10682d891*/
  *((_BYTE *)this + 253) = *((_BYTE *)a2 + 253); /*0x10682d89e*/
  *((_QWORD *)this + 18) = *(_QWORD *)a3; /*0x10682d8a7*/
  return this; /*0x10682d8c1*/
}

// Address: 0x10682d9c4 | Name: __ZNK3RBX7Network18ProcessingPacketV210isFinishedEv
__int64 __fastcall RBX::Network::ProcessingPacketV2::isFinished(RBX::Network::ProcessingPacketV2 *this)
{
  unsigned int v1; // ebx
  int v3; // r15d

  LOBYTE(v1) = 1; /*0x10682d9d6*/
  if ( RBX::Network::IncomingPacket::data(this) != 0 ) /*0x10682d9db*/
  {
    if ( *((_QWORD *)this + 30) != 0 ) /*0x10682d9e5*/
      return 0; /*0x10682d9e5*/
    if ( *((_BYTE *)this + 253) == 1 ) /*0x10682d9f3*/
    {
      v3 = *((_DWORD *)this + 62); /*0x10682d9f5*/
      if ( v3 != (unsigned int)RBX::Network::IncomingPacket::size(this) ) /*0x10682da07*/
        return 0; /*0x10682d9e7*/
    }
  }
  return v1; /*0x10682da0f*/
}

// Address: 0x10682da16 | Name: __ZNK3RBX7Network18ProcessingPacketV218hasUnprocessedDataEv
__int64 __fastcall RBX::Network::ProcessingPacketV2::hasUnprocessedData(RBX::Network::ProcessingPacketV2 *this)
{
  unsigned int v1; // ebx
  int v3; // r15d

  if ( RBX::Network::IncomingPacket::data(this) == 0 ) /*0x10682da2b*/
    return 0; /*0x10682da2b*/
  LOBYTE(v1) = 1; /*0x10682da2d*/
  if ( *((_QWORD *)this + 30) == 0 ) /*0x10682da37*/
  {
    if ( *((_BYTE *)this + 253) != 1 ) /*0x10682da41*/
      return 0; /*0x10682da41*/
    v3 = *((_DWORD *)this + 62); /*0x10682da43*/
    if ( v3 == (unsigned int)RBX::Network::IncomingPacket::size(this) ) /*0x10682da55*/
      return 0; /*0x10682da57*/
  }
  return v1; /*0x10682da5f*/
}

// Address: 0x10682da66 | Name: __ZNK3RBX7Network18ProcessingPacketV25emptyEv
bool __fastcall RBX::Network::ProcessingPacketV2::empty(RBX::Network::ProcessingPacketV2 *this)
{
  return RBX::Network::IncomingPacket::data(this) == 0; /*0x10682da75*/
}

// Address: 0x10682da78 | Name: __ZN3RBX7Network18ProcessingPacketV212markFinishedEv
__int64 __fastcall RBX::Network::ProcessingPacketV2::markFinished(RBX::Network::ProcessingPacketV2 *this)
{
  __int64 result; // rax

  if ( RBX::Network::IncomingPacket::data(this) != 0 ) /*0x10682da89*/
    result = RBX::Network::IncomingPacket::size(this); /*0x10682da8e*/
  else
    result = 0; /*0x10682da95*/
  *((_DWORD *)this + 62) = result; /*0x10682da97*/
  return result; /*0x10682daa1*/
}

// Address: 0x10685a744 | Name: __ZN3RBX7Network18ProcessingPacketV2C2Ev
__int64 __fastcall RBX::Network::ProcessingPacketV2::ProcessingPacketV2(RBX::Network::ProcessingPacketV2 *this)
{
  __int64 result; // rax

  *(_QWORD *)this = -1; /*0x10685a74e*/
  *((_BYTE *)this + 136) = 0; /*0x10685a757*/
  *(_OWORD *)((char *)this + 8) = 0; /*0x10685a760*/
  *(_OWORD *)((char *)this + 24) = 0; /*0x10685a764*/
  *((_BYTE *)this + 40) = 0; /*0x10685a768*/
  *((_QWORD *)this + 18) = 0; /*0x10685a76b*/
  RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::ProcessingPacketV2 *)((char *)this + 152)); /*0x10685a77d*/
  result = RBX::UnboundedCircularBuffer<std::unique_ptr<RBX::Network::DeserializedItem>>::UnboundedCircularBuffer( /*0x10685a78e*/
             a1: (__int64)this + 216,
             a2: 8u);
  *((_DWORD *)this + 62) = 0; /*0x10685a793*/
  *((_WORD *)this + 126) = 0; /*0x10685a79d*/
  return result; /*0x10685a7a6*/
}

// Address: 0x10685acba | Name: __ZN3RBX7Network18ProcessingPacketV2C2EOS1_
__int64 __fastcall RBX::Network::ProcessingPacketV2::ProcessingPacketV2(__int64 a1, __int128 *a2)
{
  __int128 v4; // xmm0
  __int64 v5; // rax
  __int64 v6; // rax
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 result; // rax

  *(_QWORD *)(a1 + 32) = *((_QWORD *)a2 + 4); /*0x10685accb*/
  v4 = *a2; /*0x10685accf*/
  *(_OWORD *)(a1 + 16) = a2[1]; /*0x10685acd6*/
  *(_OWORD *)a1 = v4; /*0x10685acda*/
  std::__optional_move_base<RBX::RbxTransport::NetStream,false>::__optional_move_base[abi:ne200100]( /*0x10685ace5*/
    a1: a1 + 40,
    a2: (char *)a2 + 40);
  *(_QWORD *)(a1 + 144) = *((_QWORD *)a2 + 18); /*0x10685acf1*/
  RBX::Network::NetworkStream::NetworkStream(a1: a1 + 152, a2: (__int64)a2 + 152); /*0x10685ad04*/
  v5 = *((_QWORD *)a2 + 27); /*0x10685ad09*/
  *((_QWORD *)a2 + 27) = 0; /*0x10685ad12*/
  *(_QWORD *)(a1 + 216) = v5; /*0x10685ad19*/
  v6 = *((_QWORD *)a2 + 28); /*0x10685ad20*/
  *((_QWORD *)a2 + 28) = 0; /*0x10685ad27*/
  *(_QWORD *)(a1 + 224) = v6; /*0x10685ad2e*/
  v7 = *((_QWORD *)a2 + 29); /*0x10685ad35*/
  *((_QWORD *)a2 + 29) = 0; /*0x10685ad3c*/
  *(_QWORD *)(a1 + 232) = v7; /*0x10685ad43*/
  v8 = *((_QWORD *)a2 + 30); /*0x10685ad4a*/
  *((_QWORD *)a2 + 30) = 0; /*0x10685ad51*/
  *(_QWORD *)(a1 + 240) = v8; /*0x10685ad58*/
  *(_DWORD *)(a1 + 248) = *((_DWORD *)a2 + 62); /*0x10685ad66*/
  result = *((unsigned __int16 *)a2 + 126); /*0x10685ad6c*/
  *(_WORD *)(a1 + 252) = result; /*0x10685ad74*/
  return result; /*0x10685ad7b*/
}

// END ProcessingPacketV2 part 1/1, 11 functions
