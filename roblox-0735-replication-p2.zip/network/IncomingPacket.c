// IncomingPacket -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 13 functions


// Address: 0x1067fd028 | Name: __ZN3RBX7Network14IncomingPacketC2EPhj
__int64 __fastcall RBX::Network::IncomingPacket::IncomingPacket(
        RBX::Network::IncomingPacket *this,
        unsigned __int8 *a2,
        unsigned int a3)
{
  *(_QWORD *)this = -1; /*0x1067fd02c*/
  *((_QWORD *)this + 1) = a2; /*0x1067fd035*/
  *((_QWORD *)this + 2) = a3; /*0x1067fd039*/
  *((_BYTE *)this + 136) = 0; /*0x1067fd03f*/
  *(_OWORD *)((char *)this + 24) = 0; /*0x1067fd048*/
  *((_BYTE *)this + 40) = 0; /*0x1067fd04c*/
  return 0; /*0x1067fd04f*/
}

// Address: 0x1067fd052 | Name: __ZN3RBX7Network14IncomingPacketC1EPhj
__int64 __fastcall RBX::Network::IncomingPacket::IncomingPacket(
        RBX::Network::IncomingPacket *this,
        unsigned __int8 *a2,
        unsigned int a3)
{
  *(_QWORD *)this = -1; /*0x1067fd056*/
  *((_QWORD *)this + 1) = a2; /*0x1067fd05f*/
  *((_QWORD *)this + 2) = a3; /*0x1067fd063*/
  *((_BYTE *)this + 136) = 0; /*0x1067fd069*/
  *(_OWORD *)((char *)this + 24) = 0; /*0x1067fd072*/
  *((_BYTE *)this + 40) = 0; /*0x1067fd076*/
  return 0; /*0x1067fd079*/
}

// Address: 0x1067fd07c | Name: __ZN3RBX7Network14IncomingPacketC2EPN6RakNet6PacketE
__int64 __fastcall RBX::Network::IncomingPacket::IncomingPacket(__int64 a1, __int64 a2)
{
  __int64 v2; // rcx

  *(_QWORD *)a1 = -1; /*0x1067fd080*/
  v2 = *(unsigned int *)(a2 + 48); /*0x1067fd08b*/
  *(_QWORD *)(a1 + 8) = *(_QWORD *)(a2 + 56); /*0x1067fd08e*/
  *(_QWORD *)(a1 + 16) = v2; /*0x1067fd092*/
  *(_QWORD *)(a1 + 24) = a2; /*0x1067fd096*/
  *(_QWORD *)(a1 + 32) = 0; /*0x1067fd09a*/
  *(_BYTE *)(a1 + 40) = 0; /*0x1067fd0a4*/
  *(_BYTE *)(a1 + 136) = 0; /*0x1067fd0a7*/
  return 0; /*0x1067fd0ad*/
}

// Address: 0x1067fd0b0 | Name: __ZN3RBX7Network14IncomingPacketC1EPN6RakNet6PacketE
__int64 __fastcall RBX::Network::IncomingPacket::IncomingPacket(__int64 a1, __int64 a2)
{
  __int64 v2; // rcx

  *(_QWORD *)a1 = -1; /*0x1067fd0b4*/
  v2 = *(unsigned int *)(a2 + 48); /*0x1067fd0bf*/
  *(_QWORD *)(a1 + 8) = *(_QWORD *)(a2 + 56); /*0x1067fd0c2*/
  *(_QWORD *)(a1 + 16) = v2; /*0x1067fd0c6*/
  *(_QWORD *)(a1 + 24) = a2; /*0x1067fd0ca*/
  *(_QWORD *)(a1 + 32) = 0; /*0x1067fd0ce*/
  *(_BYTE *)(a1 + 40) = 0; /*0x1067fd0d8*/
  *(_BYTE *)(a1 + 136) = 0; /*0x1067fd0db*/
  return 0; /*0x1067fd0e1*/
}

// Address: 0x1067fd0f2 | Name: __ZN3RBX7Network14IncomingPacket4dataEv
__int64 __fastcall RBX::Network::IncomingPacket::data(RBX::Network::IncomingPacket *this)
{
  return *((_QWORD *)this + 1); /*0x1067fd0fa*/
}

// Address: 0x1067fd10a | Name: __ZNK3RBX7Network14IncomingPacket4dataEv
__int64 __fastcall RBX::Network::IncomingPacket::data(RBX::Network::IncomingPacket *this)
{
  return *((_QWORD *)this + 1); /*0x1067fd112*/
}

// Address: 0x1067fd114 | Name: __ZNK3RBX7Network14IncomingPacket14getPacketConstEv
__int64 __fastcall RBX::Network::IncomingPacket::getPacketConst(RBX::Network::IncomingPacket *this)
{
  return *((_QWORD *)this + 1); /*0x1067fd120*/
}

// Address: 0x1067fd122 | Name: __ZN3RBX7Network14IncomingPacket9getPacketEv
__int64 __fastcall RBX::Network::IncomingPacket::getPacket(RBX::Network::IncomingPacket *this)
{
  return *((_QWORD *)this + 1); /*0x1067fd12e*/
}

// Address: 0x1067fd130 | Name: __ZNK3RBX7Network14IncomingPacket4sizeEv
__int64 __fastcall RBX::Network::IncomingPacket::size(RBX::Network::IncomingPacket *this)
{
  return *((unsigned int *)this + 4); /*0x1067fd137*/
}

// Address: 0x1067fd13a | Name: __ZN3RBX7Network14IncomingPacket15getRakNetPacketEv
__int64 __fastcall RBX::Network::IncomingPacket::getRakNetPacket(RBX::Network::IncomingPacket *this)
{
  return *((_QWORD *)this + 3); /*0x1067fd142*/
}

// Address: 0x1067fd144 | Name: __ZNK3RBX7Network14IncomingPacket15getRakNetPacketEv
__int64 __fastcall RBX::Network::IncomingPacket::getRakNetPacket(RBX::Network::IncomingPacket *this)
{
  return *((_QWORD *)this + 3); /*0x1067fd14c*/
}

// Address: 0x1067fd14e | Name: __ZN3RBX7Network14IncomingPacketC2ENS_12RbxTransport9NetStreamE
__int64 __fastcall RBX::Network::IncomingPacket::IncomingPacket(__int64 a1, __int64 a2)
{
  __int64 v3; // rax
  char v4; // cl
  __int64 v5; // rax
  __int64 v6; // rcx
  __int64 v7; // rdx
  __int64 result; // rax

  *(_QWORD *)a1 = -1; /*0x1067fd157*/
  v3 = a2 + 24; /*0x1067fd15e*/
  v4 = *(_BYTE *)(a2 + 64); /*0x1067fd162*/
  if ( v4 == 0 ) /*0x1067fd167*/
    v3 = a2; /*0x1067fd167*/
  v5 = *(_QWORD *)(v3 + 8); /*0x1067fd16b*/
  if ( v4 == 1 ) /*0x1067fd172*/
    v6 = *(_QWORD *)(a2 + 40); /*0x1067fd174*/
  else
    v6 = *(_QWORD *)(a2 + 16) - *(_QWORD *)(a2 + 8); /*0x1067fd17e*/
  v7 = *(_QWORD *)(a2 + 72); /*0x1067fd182*/
  *(_QWORD *)(a1 + 8) = v7 + v5; /*0x1067fd18c*/
  *(_QWORD *)(a1 + 16) = v6 - v7; /*0x1067fd190*/
  *(_OWORD *)(a1 + 24) = 0; /*0x1067fd19b*/
  result = RBX::RbxTransport::NetStream::NetStream(a1: a1 + 40); /*0x1067fd19f*/
  *(_BYTE *)(a1 + 136) = 1; /*0x1067fd1a4*/
  return result; /*0x1067fd1af*/
}

// Address: 0x1067fd1b2 | Name: __ZN3RBX7Network14IncomingPacketC1ENS_12RbxTransport9NetStreamE
__int64 __fastcall RBX::Network::IncomingPacket::IncomingPacket(__int64 a1, __int64 a2)
{
  return RBX::Network::IncomingPacket::IncomingPacket(a1, a2); /*0x1067fd1b6*/
}

// END IncomingPacket part 1/1, 13 functions
